/// BEACON demo — Step. Self-drive + input + per-page effect updates.
/// The ONLY product calls in here are beacon_fx_tick(...) and endpoint mutations — everything
/// else is demo choreography. Every position is a pure function of sim_t: two runs of this
/// demo with the same arguments produce the same frames.

var _dt_s = delta_time / 1000000;   // demo's own clock; the PRODUCT converts time only inside beacon_fx_tick
if (!still_mode) sim_t += _dt_s;
frame_count++;
if (quit_after > 0 && frame_count >= quit_after) game_end();

// Page switching (capture uses -page; a human uses the keys).
for (var _k = 0; _k < 5; _k++) {
    if (keyboard_check_pressed(ord(string(_k + 1)))) page = _k;
}

switch (page) {
    // --- 0 · HERO ---------------------------------------------------------------------------
    case 0: {
        // four orbs on staggered lissajous orbits sweeping the right two-thirds of the frame
        for (var _i = 0; _i < 4; _i++) {
            var _ph = _i * 1.62;
            hero_orbs[_i].ox = 480 + _i * 205 + sin(sim_t * (0.42 + _i * 0.09) + _ph) * 90;
            hero_orbs[_i].oy = 300 + cos(sim_t * (0.31 + _i * 0.07) + _ph * 1.4) * 140;
        }
        beacon_fx_tick(hero_chain);
        break;
    }

    // --- 1 · GALLERY ------------------------------------------------------------------------
    case 1: {
        for (var _i = 0; _i < 4; _i++) {
            beacon_fx_tick(gal_bolt[_i]);
            beacon_fx_tick(gal_beam[_i]);
            beacon_fx_tick(gal_teth[_i]);
            // comet orbits its column plinth
            var _cx = gal_x[_i] + cos(sim_t * 1.3 + _i * 1.9) * 70;
            var _cy = 560 + sin(sim_t * 2.6 + _i * 1.9) * 34;
            gal_trail[_i].a.ox = _cx;
            gal_trail[_i].a.oy = _cy;
            beacon_fx_tick(gal_trail[_i]);
        }
        break;
    }

    // --- 2 · BEAMS --------------------------------------------------------------------------
    case 2: {
        // the cutter sweeps its impact point up and down the right wall
        beam_hit.oy = 330 + sin(sim_t * 0.55) * 200;
        beacon_fx_tick(beam_fx);
        // the pillar drifts slowly across the shrine floor
        pillar_src.ox = 880 + sin(sim_t * 0.22) * 60;
        pillar_hit.ox = pillar_src.ox;
        beacon_fx_tick(pillar_fx);
        break;
    }

    // --- 3 · TETHER -------------------------------------------------------------------------
    case 3: {
        var _rad = [230, 300, 170];
        var _spd = [0.5, -0.34, 0.75];
        var _ph2 = [0, 2.1, 4.2];
        for (var _i = 0; _i < 3; _i++) {
            teth_orbs[_i].ox = 640 + cos(sim_t * _spd[_i] + _ph2[_i]) * _rad[_i];
            teth_orbs[_i].oy = 300 + sin(sim_t * _spd[_i] + _ph2[_i]) * _rad[_i] * 0.55;
            beacon_fx_tick(teth_fx[_i]);
        }
        break;
    }

    // --- 4 · TRAILS -------------------------------------------------------------------------
    case 4: {
        var _fr = [[0.61, 0.83], [0.47, 0.71], [0.79, 0.53], [0.37, 0.97]];
        for (var _i = 0; _i < 4; _i++) {
            trail_pts[_i].ox = 640 + sin(sim_t * _fr[_i][0] + _i * 1.7) * 470;
            trail_pts[_i].oy = 330 + cos(sim_t * _fr[_i][1] + _i * 0.9) * 230;
            beacon_fx_tick(trail_fx[_i]);
        }
        break;
    }
}
