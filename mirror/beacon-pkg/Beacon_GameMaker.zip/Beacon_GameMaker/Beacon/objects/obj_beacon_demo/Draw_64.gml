/// BEACON demo — Draw GUI. Backdrop + per-page composition + footer chrome.
/// Product calls in here: beacon_fx_draw(...). Everything else is demo scenery.

var _w = display_get_gui_width();
var _h = display_get_gui_height();

// --- backdrop: deep-night gradient + faint tech grid ----------------------------------------
draw_rectangle_colour(0, 0, _w, _h * 0.5, col_bg_top, col_bg_top, col_bg_mid, col_bg_mid, false);
draw_rectangle_colour(0, _h * 0.5, _w, _h, col_bg_mid, col_bg_mid, col_bg_bot, col_bg_bot, false);
draw_set_colour(col_grid);
for (var _gx = 64; _gx < _w; _gx += 64) {
    for (var _gy = 64; _gy < _h - 60; _gy += 64) {
        var _tw = 0.10 + 0.10 * abs(sin(sim_t * 0.6 + _gx * 0.031 + _gy * 0.017));
        draw_set_alpha(_tw);
        draw_rectangle(_gx, _gy, _gx + 1, _gy + 1, false);
    }
}
draw_set_alpha(1);

switch (page) {
    // --- 0 · HERO — chain lightning ---------------------------------------------------------
    case 0: {
        // ground shelf
        draw_rectangle_colour(0, 610, _w, 616, col_metal_hi, col_metal_hi, col_metal, col_metal, false);
        draw_rectangle_colour(0, 616, _w, _h, col_ground, col_ground, col_bg_bot, col_bg_bot, false);
        // pylon: mast + insulator rings + emitter head at hero_src
        draw_set_colour(col_metal);
        draw_rectangle(hero_src.ox - 7, hero_src.oy + 14, hero_src.ox + 7, 616, false);
        draw_set_colour(col_metal_hi);
        for (var _i = 0; _i < 3; _i++) {
            var _ry = hero_src.oy + 44 + _i * 52;
            draw_rectangle(hero_src.ox - 13, _ry, hero_src.ox + 13, _ry + 7, false);
        }
        // THE PRODUCT: the arc, THEN the emitter/orb glows on top so contacts read as sources
        beacon_fx_draw(hero_chain);
        __beacon_demo_orb(hero_src.ox, hero_src.oy, 13, pr_arc.style.col_glow);
        for (var _i = 0; _i < 4; _i++) {
            __beacon_demo_orb(hero_orbs[_i].ox, hero_orbs[_i].oy, 9, pr_arc.style.col_glow);
        }
        break;
    }

    // --- 1 · GALLERY — the system, visibly --------------------------------------------------
    case 1: {
        draw_set_font(fnt_beacon);
        draw_set_halign(fa_center);
        for (var _i = 0; _i < 4; _i++) {
            var _x = gal_x[_i];
            // column label + plinth
            draw_set_colour(col_text);
            draw_text(_x, 84, gal_labels[_i]);
            draw_set_colour(col_metal);
            draw_rectangle(_x - 120, 604, _x + 120, 608, false);
            // one of each verb, sharing the column's preset
            beacon_fx_draw(gal_bolt[_i]);
            beacon_fx_draw(gal_beam[_i]);
            beacon_fx_draw(gal_teth[_i]);
            beacon_fx_draw(gal_trail[_i]);
            // endpoint markers so the geometry reads as anchored
            __beacon_demo_orb(_x, 128, 5, gal_presets[_i].style.col_glow);
            __beacon_demo_orb(gal_trail[_i].a.ox, gal_trail[_i].a.oy, 6, gal_presets[_i].style.col_glow);
        }
        // verb row labels down the left edge
        draw_set_halign(fa_left);
        draw_set_colour(col_text_dim);
        draw_text(18, 190, "BOLT");
        draw_text(18, 322, "BEAM");
        draw_text(18, 404, "TETHER");
        draw_text(18, 548, "TRAIL");
        break;
    }

    // --- 2 · BEAMS --------------------------------------------------------------------------
    case 2: {
        // right wall the cutter carves + floor
        draw_rectangle_colour(1130, 60, 1146, 640, col_metal_hi, col_metal, col_metal, col_metal, false);
        draw_rectangle_colour(0, 640, _w, 646, col_metal_hi, col_metal_hi, col_metal, col_metal, false);
        // turret: base + barrel toward the impact point
        draw_set_colour(col_metal);
        draw_rectangle(88, 300, 152, 360, false);
        draw_set_colour(col_metal_hi);
        draw_rectangle(88, 300, 152, 308, false);
        // THE PRODUCT
        beacon_fx_draw(beam_fx);
        beacon_fx_draw(pillar_fx);
        // muzzle + impact glows
        __beacon_demo_orb(beam_src.ox, beam_src.oy, 10, pr_plasma.style.col_glow);
        __beacon_demo_orb(beam_hit.ox, beam_hit.oy, 12, pr_plasma.style.col_glow);
        __beacon_demo_orb(pillar_hit.ox, pillar_hit.oy, 14, pr_holy.style.col_glow);
        break;
    }

    // --- 3 · TETHER -------------------------------------------------------------------------
    case 3: {
        // reactor housing: concentric rings + faint orbit guides ground the composition
        draw_set_alpha(0.35);
        draw_set_colour(col_metal_hi);
        draw_circle(teth_core.ox, teth_core.oy, 34, true);
        draw_set_alpha(0.18);
        draw_circle(teth_core.ox, teth_core.oy, 48, true);
        draw_set_colour(col_grid);
        var _rad2 = [230, 300, 170];
        for (var _i = 0; _i < 3; _i++) {
            draw_set_alpha(0.22);
            draw_ellipse(teth_core.ox - _rad2[_i], teth_core.oy - _rad2[_i] * 0.55,
                         teth_core.ox + _rad2[_i], teth_core.oy + _rad2[_i] * 0.55, true);
        }
        draw_set_alpha(1);
        // leashes first, then the core and orbs on top
        for (var _i = 0; _i < 3; _i++) beacon_fx_draw(teth_fx[_i]);
        __beacon_demo_orb(teth_core.ox, teth_core.oy, 22, pr_arc.style.col_glow);
        __beacon_demo_orb(teth_orbs[0].ox, teth_orbs[0].oy, 10, pr_void.style.col_glow);
        __beacon_demo_orb(teth_orbs[1].ox, teth_orbs[1].oy, 10, pr_arc.style.col_glow);
        __beacon_demo_orb(teth_orbs[2].ox, teth_orbs[2].oy, 10, pr_holy.style.col_glow);
        break;
    }

    // --- 4 · TRAILS -------------------------------------------------------------------------
    case 4: {
        var _tp = [pr_arc, pr_plasma, pr_holy, pr_void];
        for (var _i = 0; _i < 4; _i++) {
            beacon_fx_draw(trail_fx[_i]);
            __beacon_demo_orb(trail_pts[_i].ox, trail_pts[_i].oy, 8, _tp[_i].style.col_glow);
        }
        break;
    }
}

// --- footer chrome --------------------------------------------------------------------------
draw_set_alpha(0.86);
draw_set_colour(col_bg_bot);
draw_rectangle(0, _h - 54, _w, _h, false);
draw_set_alpha(1);
draw_set_colour(col_metal);
draw_rectangle(0, _h - 54, _w, _h - 53, false);
draw_set_font(fnt_beacon_title);
draw_set_halign(fa_left);
draw_set_valign(fa_middle);
draw_set_colour(col_text);
draw_text(24, _h - 27, "BEACON");
draw_set_font(fnt_beacon);
draw_set_colour(col_text_dim);
draw_text(178, _h - 27, page_names[page] + "  ·  " + page_hints[page]);
draw_set_halign(fa_right);
draw_text(_w - 24, _h - 27, "1-5: pages");
draw_set_halign(fa_left);
draw_set_valign(fa_top);
