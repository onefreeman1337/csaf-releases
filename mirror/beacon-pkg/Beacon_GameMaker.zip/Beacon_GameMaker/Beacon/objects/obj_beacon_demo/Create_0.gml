/// BEACON demo — Create.
/// ============================================================================================
/// DEMO SCAFFOLDING, NOT PRODUCT. Everything in obj_beacon_demo exists so the product can be
/// seen: five showcase pages, self-driving motion (every position is a pure function of the
/// demo clock — deterministic end to end), and a command-line parser so unattended captures
/// are reproducible. Copy the beacon_fx_* CALLS into your game; delete the rest.
///
/// Pages (keys 1-5, or launch with -page N):
///   0 HERO      chain lightning arcing from a pylon through four moving orbs — the money shot
///   1 GALLERY   all four presets × bolt/beam/tether/trail — one pipeline, six verbs, visibly
///   2 BEAMS     a sweeping plasma cutter + a holy pillar, both with impact flare
///   3 TETHER    three energy leashes from a core to orbiting orbs (analytic, zero simulation)
///   4 TRAILS    four comets, one per colourway
/// Other args: -still (freeze the demo clock for stills), -quit N (exit after N frames).
/// ============================================================================================

window_set_caption("Beacon — procedural energy for GameMaker");

// --- command line ---------------------------------------------------------------------------
page = 0;
still_mode = false;
quit_after = -1;
var _pc = parameter_count();
for (var _i = 1; _i < _pc; _i++) {
    var _p = parameter_string(_i);
    if (_p == "-page" && _i + 1 < _pc) { page = clamp(real(parameter_string(_i + 1)), 0, 4); _i++; }
    else if (_p == "-still") still_mode = true;
    else if (_p == "-quit" && _i + 1 < _pc) { quit_after = real(parameter_string(_i + 1)); _i++; }
}

frame_count = 0;
sim_t = 0;               // demo clock, seconds — every moving thing below is a function of it

// --- palette (demo chrome only; product colours live in beacon_preset) ----------------------
col_bg_top   = make_colour_rgb(18, 15, 38);
col_bg_mid   = make_colour_rgb(11, 9, 24);
col_bg_bot   = make_colour_rgb(5, 4, 13);
col_grid     = make_colour_rgb(38, 34, 70);
col_ground   = make_colour_rgb(26, 22, 48);
col_metal    = make_colour_rgb(64, 58, 100);
col_metal_hi = make_colour_rgb(112, 104, 160);
col_text     = make_colour_rgb(228, 228, 244);
col_text_dim = make_colour_rgb(128, 128, 160);

// --- presets (one of each colourway; seeds differ so nothing shares a shape) ----------------
pr_arc    = beacon_preset_arc(101);
pr_plasma = beacon_preset_plasma(202);
pr_holy   = beacon_preset_holy(303);
pr_void   = beacon_preset_void(404);

// --- helper: additive emitter orb (demo scenery — the effects are the product) --------------
__beacon_demo_orb = function (_x, _y, _r, _col) {
    var _prev = gpu_get_blendmode_ext();
    gpu_set_blendmode(bm_add);
    draw_circle_colour(_x, _y, _r * 2.4, _col, c_black, false);
    draw_circle_colour(_x, _y, _r, c_white, _col, false);
    gpu_set_blendmode_ext(_prev[0], _prev[1]);
};

// --- page 0: HERO — chain lightning ---------------------------------------------------------
// A pylon at the left; four orbs on lissajous orbits. The chain endpoint structs are created
// ONCE and their coordinates mutated per step — the intended live-endpoint pattern.
hero_src = beacon_pt(170, 360);
hero_orbs = [];
for (var _i = 0; _i < 4; _i++) array_push(hero_orbs, beacon_pt(0, 0));
hero_chain = beacon_fx_create("chain", hero_src, hero_src, pr_arc);
hero_chain.targets = [hero_src, hero_orbs[0], hero_orbs[1], hero_orbs[2], hero_orbs[3]];

// --- page 1: GALLERY — every preset × every verb --------------------------------------------
gal_presets = [pr_arc, pr_plasma, pr_holy, pr_void];
gal_labels  = ["ARC", "PLASMA", "HOLY", "VOID"];
gal_x       = [190, 490, 790, 1090];
gal_bolt = [];   // vertical bolt per column
gal_beam = [];   // short beam per column
gal_teth = [];   // small tether per column
gal_trail = [];  // orbiting comet per column
for (var _i = 0; _i < 4; _i++) {
    var _x = gal_x[_i];
    array_push(gal_bolt, beacon_fx_create("bolt", beacon_pt(_x, 128), beacon_pt(_x, 268), gal_presets[_i]));
    array_push(gal_beam, beacon_fx_create("beam", beacon_pt(_x - 110, 330), beacon_pt(_x + 110, 330), gal_presets[_i]));
    array_push(gal_teth, beacon_fx_create("tether", beacon_pt(_x - 100, 396), beacon_pt(_x + 100, 396), gal_presets[_i]));
    var _tr = beacon_fx_create("trail", beacon_pt(_x, 560), beacon_pt(_x, 560), gal_presets[_i]);
    _tr.trail = beacon_trail_create(48);     // longer ribbon so the comet reads in a still
    array_push(gal_trail, _tr);
}
// gallery bolts read better a touch smaller than the hero's
for (var _i = 0; _i < 4; _i++) {
    gal_bolt[_i].preset = {
        style: gal_presets[_i].style,
        bolt: beacon_cfg_bolt(),
        beam: gal_presets[_i].beam, tether: gal_presets[_i].tether,
        chain: gal_presets[_i].chain, trail: gal_presets[_i].trail,
    };
    gal_bolt[_i].preset.bolt.amp = 26;
    gal_bolt[_i].preset.bolt.branch_len = 40;
    gal_bolt[_i].preset.bolt.seed = 900 + _i;
}

// --- page 2: BEAMS — plasma cutter + holy pillar --------------------------------------------
beam_src   = beacon_pt(150, 330);            // turret muzzle
beam_hit   = beacon_pt(1120, 330);           // sweeps along the right wall
beam_fx    = beacon_fx_create("beam", beam_src, beam_hit, pr_plasma);
pillar_src = beacon_pt(880, -40);            // holy pillar falls from above
pillar_hit = beacon_pt(880, 600);
pillar_fx  = beacon_fx_create("beam", pillar_src, pillar_hit, pr_holy);
pillar_fx.preset = {
    style: pr_holy.style,
    bolt: pr_holy.bolt, tether: pr_holy.tether, chain: pr_holy.chain, trail: pr_holy.trail,
    beam: { n: 24, bloom: 0.2, flare: 1.1, pulse_amp: 0.22, pulse_freq: 2, pulse_hz: 1.1 },
};

// --- page 3: TETHER — core + three leashed orbs ---------------------------------------------
teth_core = beacon_pt(640, 300);
teth_orbs = [beacon_pt(0, 0), beacon_pt(0, 0), beacon_pt(0, 0)];
teth_fx = [
    beacon_fx_create("tether", teth_core, teth_orbs[0], pr_void),
    beacon_fx_create("tether", teth_core, teth_orbs[1], pr_arc),
    beacon_fx_create("tether", teth_core, teth_orbs[2], pr_holy),
];

// --- page 4: TRAILS — four comets -----------------------------------------------------------
trail_pts = [beacon_pt(0, 0), beacon_pt(0, 0), beacon_pt(0, 0), beacon_pt(0, 0)];
trail_fx = [];
var _tp = [pr_arc, pr_plasma, pr_holy, pr_void];
for (var _i = 0; _i < 4; _i++) {
    var _fx = beacon_fx_create("trail", trail_pts[_i], trail_pts[_i], _tp[_i]);
    _fx.trail = beacon_trail_create(70);     // long ribbon for the big open page
    // comets read better fatter than filaments: widen a COPY of the style (demo taste only)
    _fx.preset = {
        style: {
            col_core: _tp[_i].style.col_core, w_core: 4.5,  a_core: 0.95,
            col_glow: _tp[_i].style.col_glow, w_glow: 13,   a_glow: 0.40,
            col_halo: _tp[_i].style.col_halo, w_halo: 32,   a_halo: 0.14,
        },
        bolt: _tp[_i].bolt, beam: _tp[_i].beam, tether: _tp[_i].tether,
        chain: _tp[_i].chain, trail: _tp[_i].trail,
    };
    array_push(trail_fx, _fx);
}

// --- footer chrome --------------------------------------------------------------------------
page_names = ["HERO", "GALLERY", "BEAMS", "TETHER", "TRAILS"];
page_hints = [
    "chain lightning arcing pylon → orb → orb  ·  deterministic flicker, zero random()",
    "four presets × bolt / beam / tether / trail  ·  one BeaconPath pipeline draws them all",
    "sweeping plasma cutter + holy pillar  ·  aperture bloom, travelling pulses, impact flare",
    "analytic energy leashes  ·  closed-form sag + sway, no simulation state",
    "motion trails from a ring buffer  ·  push a position, get a fading ribbon",
];
