/// ============================================================================================
/// BEACON · beacon_render — the one renderer.
///
/// Draws ANY BeaconPath (from bolt, beam, tether, trail or chain — they all emit the same
/// intermediate) as a ribbon of triangle strips in THREE ADDITIVE PASSES:
///
///   1. HALO — wide, faint, deep colour. The atmospheric bleed.
///   2. GLOW — mid width, saturated colour. The body of the effect.
///   3. CORE — thin, near-white, bright. The filament.
///
/// Layered additive passes are what make procedural geometry read as ENERGY instead of as
/// debug lines: the three widths sum into a soft falloff the eye reads as light.
///
/// ⚠️ STATE SAFETY — the reason this file is careful:
///   A renderer that leaks bm_add into the buyer's pipeline is a support ticket you cannot
///   debug remotely (everything they draw after it washes out white). beacon_draw saves the
///   blend state with gpu_get_blendmode_ext and RESTORES it around every call — including the
///   ext form, so a buyer using gpu_set_blendmode_ext gets their exact state back. Vertex
///   colour and alpha ride in the vertices themselves, so global draw colour/alpha are never
///   touched at all.
///
/// Public API:
///   beacon_draw(paths, style)        draw an array of BeaconPath (what every generator returns)
///   beacon_draw_debug(paths)         thin polyline, no glow — DEV ONLY, never used by presets
///
/// style is a plain struct (built by beacon_preset, or by hand):
///   col_core / col_glow / col_halo   the three pass colours (core is near-white)
///   w_core  / w_glow  / w_halo       the three pass widths, px (e.g. 2.5 / 7 / 18)
///   a_core  / a_glow  / a_halo       the three pass alphas   (e.g. 0.95 / 0.42 / 0.16)
/// ============================================================================================

/// @function __beacon_draw_ribbon(_p, _col, _width, _alpha)
/// @description One triangle-strip pass over one BeaconPath. Width per point = _width × the
///              path's envelope; alpha = _alpha × the path's strength. Internal.
function __beacon_draw_ribbon(_p, _col, _width, _alpha) {
    var _n = array_length(_p.px);
    var _a = _alpha * _p.strength;
    if (_n < 2) {
        if (_n == 1) draw_circle_colour(_p.px[0], _p.py[0], _width * 0.5, _col, _col, false);
        return;
    }
    draw_primitive_begin(pr_trianglestrip);
    for (var _i = 0; _i < _n; _i++) {
        // direction from neighbours (central difference; one-sided at the ends)
        var _i0 = max(_i - 1, 0);
        var _i1 = min(_i + 1, _n - 1);
        var _dx = _p.px[_i1] - _p.px[_i0];
        var _dy = _p.py[_i1] - _p.py[_i0];
        var _len = sqrt(_dx * _dx + _dy * _dy);
        if (_len <= 0) { _dx = 1; _dy = 0; _len = 1; }
        var _hw = _width * _p.w[_i] * 0.5;
        var _ox = (-_dy / _len) * _hw;
        var _oy = ( _dx / _len) * _hw;
        draw_vertex_colour(_p.px[_i] + _ox, _p.py[_i] + _oy, _col, _a);
        draw_vertex_colour(_p.px[_i] - _ox, _p.py[_i] - _oy, _col, _a);
    }
    draw_primitive_end();
}

/// @function beacon_draw(_paths, _style)
/// @description Draw an array of BeaconPath (exactly what beacon_bolt / beacon_beam /
///              beacon_tether / beacon_chain / beacon_trail_path return) with the style's
///              three-pass additive pipeline. Saves and restores the gpu blend state — safe
///              to call from any Draw event without touching the caller's pipeline.
/// @param {array} _paths  Array of BeaconPath structs.
/// @param {struct} _style See the header block; beacon_preset builds these.
function beacon_draw(_paths, _style) {
    var _prev = gpu_get_blendmode_ext();
    gpu_set_blendmode(bm_add);
    var _pn = array_length(_paths);
    for (var _i = 0; _i < _pn; _i++) {
        var _p = _paths[_i];
        __beacon_draw_ribbon(_p, _style.col_halo, _style.w_halo, _style.a_halo);
        __beacon_draw_ribbon(_p, _style.col_glow, _style.w_glow, _style.a_glow);
        __beacon_draw_ribbon(_p, _style.col_core, _style.w_core, _style.a_core);
    }
    gpu_set_blendmode_ext(_prev[0], _prev[1]);
}

/// @function beacon_draw_debug(_paths)
/// @description Thin grey polyline of the raw geometry. DEV ONLY — for inspecting generator
///              output. Presets never call this, and no screenshot of it ships (Gate 1).
function beacon_draw_debug(_paths) {
    var _pn = array_length(_paths);
    for (var _i = 0; _i < _pn; _i++) {
        var _p = _paths[_i];
        var _n = array_length(_p.px);
        for (var _j = 0; _j < _n - 1; _j++) {
            draw_line_colour(_p.px[_j], _p.py[_j], _p.px[_j + 1], _p.py[_j + 1], c_grey, c_grey);
        }
    }
}
