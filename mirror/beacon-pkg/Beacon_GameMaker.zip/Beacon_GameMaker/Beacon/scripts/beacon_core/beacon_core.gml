/// ============================================================================================
/// BEACON · beacon_core — the pure generator core.
///
/// ZERO engine calls. Nothing in this file reads an instance, a room, a sprite, the clock or
/// the renderer; the only built-ins used are pure maths (sin/cos/sqrt/floor/min/max/abs/clamp/
/// lerp/pi) and array functions. That is deliberate: GML cannot be unit-tested outside
/// GameMaker, so every algorithm in Beacon lives where it can be read, reasoned about and
/// mirrored numerically in isolation (Internal_Ops/sim_mirror.js is that mirror, and it was
/// written FIRST). Everything impure sits in beacon_bind (time/instances) and beacon_render
/// (drawing).
///
/// THE ONE IDEA — every effect compiles to the same intermediate.
///   A BeaconPath is { px[], py[], w[], strength }: a polyline, a per-point width envelope
///   (0..1), and an overall intensity multiplier. bolt / beam / tether / trail / chain are
///   just different pure functions that EMIT BeaconPaths, and beacon_render draws any of them
///   with the same three-pass additive pipeline. One geometry contract, six effect verbs —
///   that is what makes Beacon a system rather than five snippets.
///
/// DETERMINISM — no random(), anywhere.
///   All jitter comes from a 32-bit integer hash of (seed, level, node, time_bucket). Two runs
///   with the same seed and clock are byte-identical: captures are reproducible, replays are
///   safe, and multiplayer lockstep will not desync on cosmetics. Flicker is TEMPORALLY
///   COHERENT: a bolt holds one shape for cfg.hold_ms milliseconds, then re-rolls — bolts
///   flicker on a cadence, they do not boil every frame. (Mirror check 2 proves both
///   directions: identical inside a hold bucket, different across the boundary.)
///
/// HONEST GEOMETRY NOTES
///   - The tether uses the small-sag PARABOLA approximation of a catenary (y += 4·sag·s·(1−s)),
///     not the cosh closed form. For the sag ranges an energy leash uses they are visually
///     identical and the parabola is branch-free. Documented here rather than pretended away.
///   - Bolt displacement is bounded by the geometric series amp/(1−amp_decay) from the chord
///     (mirror check 3), so a bolt can never leave the neighbourhood of its endpoints.
///
/// Public API (everything else in this file is internal and prefixed __beacon_):
///   beacon_path_create(strength)                    -> empty BeaconPath
///   beacon_cfg_bolt()                               -> default bolt cfg (documented below)
///   beacon_bolt(ax, ay, bx, by, t_ms, cfg)          -> array of BeaconPath (main + branches)
///   beacon_beam(ax, ay, bx, by, t_ms, cfg)          -> array of ONE BeaconPath
///   beacon_tether(ax, ay, bx, by, t_ms, cfg)        -> array of ONE BeaconPath
///   beacon_chain(xs, ys, t_ms, cfg)                 -> array of BeaconPath (link per gap)
///   beacon_trail_create(cap)                        -> trail ring buffer
///   beacon_trail_push(trail, x, y)                  -> record a position (call per step)
///   beacon_trail_path(trail, cfg)                   -> array of ONE fading BeaconPath
///
/// bolt cfg fields (beacon_cfg_bolt() builds the documented default; presets retune it):
///   segs          points-per-curve budget, power of two (32). More = finer filigree.
///   amp           first-level midpoint displacement, px (42).
///   amp_decay     per-level amplitude falloff 0..1 (0.55). Lower = straighter fine detail.
///   seed          integer identity. Two bolts with different seeds never share a shape.
///   hold_ms       flicker cadence in ms (90). The shape re-rolls when the bucket advances.
///   branch_prob   0..1 chance per interior node to spawn a fork (0.35).
///   branch_len    fork length, px (60).
///   branch_amp    fork amplitude as a fraction of the parent's (0.6).
///   branch_levels forks per bolt generation: 0 disables, 1 = single fork layer.
///   taper_pts     points over which the tips fade to a point (3).
/// ============================================================================================

/// @function beacon_path_create(_strength)
/// @description Create an empty BeaconPath — the one intermediate every generator emits and
///              beacon_render draws. Fill px/py/w in lockstep.
/// @param {real} _strength Overall intensity multiplier 0..1 (branches use < 1).
function beacon_path_create(_strength = 1) {
    return { px: [], py: [], w: [], strength: _strength };
}

/// --------------------------------------------------------------------- deterministic noise
/// 32-bit integer hash (murmur3-style finalizer). All values are kept masked to unsigned
/// 32-bit inside GML's int64, so >> behaves as a logical shift. No random() anywhere.

/// @function __beacon_imul32(_a, _b)
/// @description 32-bit overflow-safe integer multiply (the JS Math.imul contract). Splitting
///              into 16-bit halves keeps every intermediate below 2^50, safely exact.
function __beacon_imul32(_a, _b) {
    var _ah = (_a >> 16) & 0xFFFF;
    var _al = _a & 0xFFFF;
    var _bh = (_b >> 16) & 0xFFFF;
    var _bl = _b & 0xFFFF;
    return (_al * _bl + ((_ah * _bl + _al * _bh) << 16)) & 0xFFFFFFFF;
}

/// @function __beacon_hash2(_a, _b)
/// @description Deterministic 32-bit hash of two integers. The only entropy source in Beacon.
function __beacon_hash2(_a, _b) {
    var _h = (_a & 0xFFFFFFFF) ^ 0x9E3779B9;
    _h = __beacon_imul32(_h ^ (_b & 0xFFFFFFFF), 0x85EBCA6B);
    _h = (_h ^ (_h >> 13)) & 0xFFFFFFFF;
    _h = __beacon_imul32(_h, 0xC2B2AE35);
    _h = (_h ^ (_h >> 16)) & 0xFFFFFFFF;
    return _h;
}

/// @function __beacon_noise2(_a, _b)
/// @description Uniform value in [-1, 1) from two integers, via __beacon_hash2.
function __beacon_noise2(_a, _b) {
    return (__beacon_hash2(_a, _b) / 2147483648) - 1;
}

/// @function __beacon_taper(_i, _n, _pts)
/// @description Tip taper: width fades to a point over _pts points at each end of a path.
function __beacon_taper(_i, _n, _pts) {
    if (_pts <= 0) return 1;
    return clamp(min(_i, _n - 1 - _i) / _pts, 0.12, 1);
}

/// --------------------------------------------------------------------------- configuration

/// @function beacon_cfg_bolt()
/// @description The documented default bolt cfg. Copy and retune per effect; beacon_preset
///              ships four tuned colourway variants built on this.
function beacon_cfg_bolt() {
    return {
        segs: 32,
        amp: 42,
        amp_decay: 0.55,
        seed: 1337,
        hold_ms: 90,
        branch_prob: 0.35,
        branch_len: 60,
        branch_amp: 0.6,
        branch_levels: 1,
        taper_pts: 3,
    };
}

/// ------------------------------------------------------------------------------------ bolt

/// @function beacon_bolt(_ax, _ay, _bx, _by, _t_ms, _cfg)
/// @description Midpoint-displacement lightning between two points. Deterministic in
///              (cfg.seed, time bucket): the shape holds for cfg.hold_ms then re-rolls.
///              Returns an array of BeaconPath — index 0 is the main bolt, the rest are
///              forks at strength 0.55.
/// @param {real} _ax Source x.  @param {real} _ay Source y.
/// @param {real} _bx Target x.  @param {real} _by Target y.
/// @param {real} _t_ms Clock in MILLISECONDS (beacon_bind supplies this from delta_time).
/// @param {struct} _cfg See beacon_cfg_bolt().
function beacon_bolt(_ax, _ay, _bx, _by, _t_ms, _cfg) {
    var _bucket = floor(_t_ms / _cfg.hold_ms);
    var _px = [_ax, _bx];
    var _py = [_ay, _by];
    var _amp = _cfg.amp;
    var _level = 0;
    var _segs = 1;

    // midpoint displacement: double the point count each level, displacing every new midpoint
    // perpendicular to its local segment by hash noise scaled with the decaying amplitude
    while (_segs < _cfg.segs) {
        var _n = array_length(_px);
        var _nx = [];
        var _ny = [];
        for (var _i = 0; _i < _n - 1; _i++) {
            var _mx = (_px[_i] + _px[_i + 1]) * 0.5;
            var _my = (_py[_i] + _py[_i + 1]) * 0.5;
            var _dx = _px[_i + 1] - _px[_i];
            var _dy = _py[_i + 1] - _py[_i];
            var _len = sqrt(_dx * _dx + _dy * _dy);
            if (_len <= 0) _len = 1;
            var _nv = __beacon_noise2(__beacon_hash2(_cfg.seed + _level, _i), _bucket);
            array_push(_nx, _px[_i]);
            array_push(_nx, _mx + (-_dy / _len) * _nv * _amp);
            array_push(_ny, _py[_i]);
            array_push(_ny, _my + (_dx / _len) * _nv * _amp);
        }
        array_push(_nx, _px[_n - 1]);
        array_push(_ny, _py[_n - 1]);
        _px = _nx;
        _py = _ny;
        _amp *= _cfg.amp_decay;
        _level++;
        _segs *= 2;
    }

    var _count = array_length(_px);
    var _main = beacon_path_create(1);
    _main.px = _px;
    _main.py = _py;
    for (var _i = 0; _i < _count; _i++) {
        array_push(_main.w, __beacon_taper(_i, _count, _cfg.taper_pts));
    }
    var _out = [_main];

    // forks: spawn at interior nodes where the hash says so, re-using the same generator with
    // a smaller budget, no further branching, and a derived seed
    if (_cfg.branch_prob > 0 && _cfg.branch_levels > 0) {
        for (var _i = 2; _i < _count - 2; _i += 2) {
            var _r = (__beacon_hash2(_cfg.seed ^ 0xB7A7C11, __beacon_hash2(_i, _bucket)) mod 1000) / 1000;
            if (_r < _cfg.branch_prob) {
                var _dirx = _px[_i] - _px[_i - 2];
                var _diry = _py[_i] - _py[_i - 2];
                var _bl = sqrt(_dirx * _dirx + _diry * _diry);
                if (_bl <= 0) _bl = 1;
                var _spread = __beacon_noise2(_cfg.seed ^ 0x51ED, __beacon_hash2(_i, _bucket)) * 0.9;
                var _ca = cos(_spread);
                var _sa = sin(_spread);
                var _ex = _px[_i] + (_dirx / _bl) * _cfg.branch_len * _ca - (_diry / _bl) * _cfg.branch_len * _sa;
                var _ey = _py[_i] + (_diry / _bl) * _cfg.branch_len * _ca + (_dirx / _bl) * _cfg.branch_len * _sa;
                var _sub_cfg = {
                    segs: max(2, _cfg.segs >> 2),
                    amp: _cfg.amp * _cfg.branch_amp,
                    amp_decay: _cfg.amp_decay,
                    seed: __beacon_hash2(_cfg.seed, _i * 7919),
                    hold_ms: _cfg.hold_ms,
                    branch_prob: 0,
                    branch_len: _cfg.branch_len,
                    branch_amp: _cfg.branch_amp,
                    branch_levels: 0,
                    taper_pts: _cfg.taper_pts,
                };
                var _sub = beacon_bolt(_px[_i], _py[_i], _ex, _ey, _t_ms, _sub_cfg);
                _sub[0].strength = 0.55;
                array_push(_out, _sub[0]);
            }
        }
    }
    return _out;
}

/// ------------------------------------------------------------------------------------ beam

/// @function beacon_beam(_ax, _ay, _bx, _by, _t_ms, _cfg)
/// @description Straight energy beam with an aperture bloom at the source, an impact flare at
///              the target, and travelling pulse phases running along it. Returns one path.
/// cfg: n (points, 24) · bloom (source widen 0..1, 0.55) · flare (impact widen 0..1, 0.85) ·
///      pulse_amp (0.35) · pulse_freq (waves along the beam, 3) · pulse_hz (waves per second, 2.2)
function beacon_beam(_ax, _ay, _bx, _by, _t_ms, _cfg) {
    var _n = _cfg.n;
    var _p = beacon_path_create(1);
    var _t_s = _t_ms / 1000;
    for (var _i = 0; _i <= _n; _i++) {
        var _s = _i / _n;
        array_push(_p.px, lerp(_ax, _bx, _s));
        array_push(_p.py, lerp(_ay, _by, _s));
        // envelope: bloom near the source, flare near the impact, pulse everywhere between
        var _w = 1;
        _w += _cfg.bloom * max(0, 1 - _s / 0.10);                       // aperture bloom
        _w += _cfg.flare * max(0, (_s - 0.90) / 0.10);                  // impact flare
        _w *= 1 + _cfg.pulse_amp * sin(2 * pi * (_s * _cfg.pulse_freq - _t_s * _cfg.pulse_hz));
        array_push(_p.w, _w);
    }
    return [_p];
}

/// @function beacon_cfg_beam()
/// @description The documented default beam cfg.
function beacon_cfg_beam() {
    return { n: 24, bloom: 0.55, flare: 0.85, pulse_amp: 0.35, pulse_freq: 3, pulse_hz: 2.2 };
}

/// ---------------------------------------------------------------------------------- tether

/// @function beacon_tether(_ax, _ay, _bx, _by, _t_ms, _cfg)
/// @description Analytic energy leash: parabolic sag (small-sag catenary approximation —
///              documented in the header) plus a sinusoidal sway that is zero at both
///              endpoints. Closed-form: no simulation state, safe to call fresh every frame.
///              Deliberate non-overlap with Loom: simulated rope physics is Loom's product;
///              Beacon's tether is the closed-form ENERGY look.
/// cfg: n (points, 20) · sag (px at the midpoint, 46) · sway_hz (0.6) · sway_amp (px, 10) ·
///      taper_pts (2)
function beacon_tether(_ax, _ay, _bx, _by, _t_ms, _cfg) {
    var _n = _cfg.n;
    var _p = beacon_path_create(1);
    var _t_s = _t_ms / 1000;
    for (var _i = 0; _i <= _n; _i++) {
        var _s = _i / _n;
        var _env = sin(_s * pi);                                        // 0 at ends, 1 mid
        var _sway = sin(_t_s * _cfg.sway_hz * 2 * pi + _s * pi) * _cfg.sway_amp * _env;
        array_push(_p.px, _ax + (_bx - _ax) * _s + _sway * 0.3);
        array_push(_p.py, _ay + (_by - _ay) * _s + 4 * _cfg.sag * _s * (1 - _s) + _sway);
        array_push(_p.w, __beacon_taper(_i, _n + 1, _cfg.taper_pts) * (0.75 + 0.25 * _env));
    }
    return [_p];
}

/// @function beacon_cfg_tether()
/// @description The documented default tether cfg.
function beacon_cfg_tether() {
    return { n: 20, sag: 46, sway_hz: 0.6, sway_amp: 10, taper_pts: 2 };
}

/// ----------------------------------------------------------------------------------- chain

/// @function beacon_chain(_xs, _ys, _t_ms, _cfg)
/// @description Chain lightning: one bolt per consecutive pair in a target list, each link's
///              amplitude and strength decaying by cfg.chain_decay, each link seeded
///              independently so links never share a shape. beacon_bind assembles the target
///              list from live instances; this stays pure.
/// cfg: a bolt cfg plus chain_decay (per-link falloff, 0.82).
function beacon_chain(_xs, _ys, _t_ms, _cfg) {
    var _out = [];
    var _links = array_length(_xs) - 1;
    var _scale = 1;
    for (var _l = 0; _l < _links; _l++) {
        var _link_cfg = {
            segs: _cfg.segs,
            amp: _cfg.amp * _scale,
            amp_decay: _cfg.amp_decay,
            seed: __beacon_hash2(_cfg.seed, _l * 2654435761),
            hold_ms: _cfg.hold_ms,
            branch_prob: _cfg.branch_prob * _scale,
            branch_len: _cfg.branch_len,
            branch_amp: _cfg.branch_amp,
            branch_levels: _cfg.branch_levels,
            taper_pts: _cfg.taper_pts,
        };
        var _paths = beacon_bolt(_xs[_l], _ys[_l], _xs[_l + 1], _ys[_l + 1], _t_ms, _link_cfg);
        var _pn = array_length(_paths);
        for (var _p = 0; _p < _pn; _p++) {
            _paths[_p].strength *= _scale;
            array_push(_out, _paths[_p]);
        }
        _scale *= _cfg.chain_decay;
    }
    return _out;
}

/// @function beacon_cfg_chain()
/// @description The documented default chain cfg — a bolt cfg plus per-link decay.
function beacon_cfg_chain() {
    var _c = beacon_cfg_bolt();
    _c.chain_decay = 0.82;
    return _c;
}

/// ----------------------------------------------------------------------------------- trail

/// @function beacon_trail_create(_cap)
/// @description Ring buffer of past positions for a motion trail. Push once per step from
///              beacon_bind (or your own Step event); capacity caps the trail length.
function beacon_trail_create(_cap) {
    return { cap: _cap, n: 0, head: 0, x: array_create(_cap, 0), y: array_create(_cap, 0) };
}

/// @function beacon_trail_push(_trail, _x, _y)
/// @description Record the current position. Oldest entries fall off past the cap.
function beacon_trail_push(_trail, _x, _y) {
    _trail.x[_trail.head] = _x;
    _trail.y[_trail.head] = _y;
    _trail.head = (_trail.head + 1) mod _trail.cap;
    _trail.n = min(_trail.n + 1, _trail.cap);
}

/// @function beacon_trail_path(_trail, _cfg)
/// @description Emit the trail as one BeaconPath, oldest → newest, width fading 0 → 1 so the
///              ribbon narrows into history (mirror check 6: monotone, capped).
/// cfg: min_w (width at the oldest point, 0.05).
function beacon_trail_path(_trail, _cfg) {
    var _p = beacon_path_create(1);
    var _n = _trail.n;
    for (var _i = 0; _i < _n; _i++) {
        var _idx = (_trail.head - _n + _i + _trail.cap * 2) mod _trail.cap;
        array_push(_p.px, _trail.x[_idx]);
        array_push(_p.py, _trail.y[_idx]);
        array_push(_p.w, (_n <= 1) ? 1 : lerp(_cfg.min_w, 1, _i / (_n - 1)));
    }
    return [_p];
}

/// @function beacon_cfg_trail()
/// @description The documented default trail cfg.
function beacon_cfg_trail() {
    return { min_w: 0.05 };
}
