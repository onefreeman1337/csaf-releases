/// ============================================================================================
/// BEACON · beacon_bind — the engine binding.
///
/// Everything impure on the INPUT side lives here: the wall clock, instance endpoints, and
/// chain target lists. beacon_core stays pure; beacon_render stays draw-only.
///
/// ⚠️ TIME — the microseconds trap, handled in exactly ONE place.
///   GameMaker's delta_time is in MICROSECONDS. Beacon's clocks advance in MILLISECONDS
///   (flicker cadence is stated in ms), and the ONLY µs→ms conversion in the whole product is
///   the `delta_time / 1000` inside beacon_fx_tick. If an effect ever runs 1000× too fast or
///   too slow, this is the line to look at — and it is the only line.
///
/// ENDPOINTS — points or instances, freely mixed.
///   beacon_pt(x, y)                    a fixed world point
///   beacon_anchor(inst, [ox], [oy])    a live instance, plus an optional offset
///   An anchor whose instance has been destroyed resolves to `undefined`, and any effect with
///   a dead endpoint returns [] from beacon_fx_paths — it simply stops drawing, it never
///   crashes. Chain targets are dropped per-node the same way.
///
/// THE BeaconFX WRAPPER — one struct per live effect.
///   fx = beacon_fx_create("bolt" | "beam" | "tether" | "chain" | "trail", a, b, preset)
///   Per frame:  beacon_fx_tick(fx);      (Step — advances the clock, feeds trails)
///               beacon_fx_draw(fx);      (Draw — generate this frame's paths and render)
///   Chains:     fx.targets = [anchorOrPt, ...]  (order = arc order; b is ignored)
///   Trails:     a is the followed endpoint; the ribbon is its history.
///   Advanced:   beacon_fx_paths(fx) returns the raw BeaconPath array to draw yourself.
/// ============================================================================================

/// @function beacon_pt(_x, _y)
/// @description A fixed world-space endpoint.
function beacon_pt(_x, _y) {
    return { inst: noone, ox: _x, oy: _y };
}

/// @function beacon_anchor(_inst, [_ox], [_oy])
/// @description A live-instance endpoint with an optional offset. Resolved every frame, so it
///              follows the instance; a destroyed instance makes the effect vanish safely.
function beacon_anchor(_inst, _ox = 0, _oy = 0) {
    return { inst: _inst, ox: _ox, oy: _oy };
}

/// @function __beacon_resolve(_ep)
/// @description Endpoint → [x, y], or undefined if its instance is gone. Internal.
function __beacon_resolve(_ep) {
    if (_ep.inst == noone) return [_ep.ox, _ep.oy];
    if (!instance_exists(_ep.inst)) return undefined;
    return [_ep.inst.x + _ep.ox, _ep.inst.y + _ep.oy];
}

/// @function beacon_fx_create(_kind, _a, _b, _preset)
/// @description Create a live effect. kind is "bolt", "beam", "tether", "chain" or "trail";
///              a and b are beacon_pt / beacon_anchor endpoints (chain uses fx.targets
///              instead of b; trail uses a only). preset is a beacon_preset_* struct.
function beacon_fx_create(_kind, _a, _b, _preset) {
    return {
        kind: _kind,
        a: _a,
        b: _b,
        preset: _preset,
        targets: [],                                    // chain only: [endpoint, ...]
        trail: beacon_trail_create(26),                 // trail only: position history
        t_ms: 0,                                        // effect clock, milliseconds
    };
}

/// @function beacon_fx_tick(_fx)
/// @description Advance the effect clock — call once per Step. THE single µs→ms conversion
///              in Beacon lives on the next line. Trails also record their followed endpoint
///              here, so trail speed is frame-rate independent.
function beacon_fx_tick(_fx) {
    _fx.t_ms += delta_time / 1000;
    if (_fx.kind == "trail") {
        var _p = __beacon_resolve(_fx.a);
        if (!is_undefined(_p)) beacon_trail_push(_fx.trail, _p[0], _p[1]);
    }
}

/// @function beacon_fx_paths(_fx)
/// @description Generate this frame's BeaconPath array for the effect. Returns [] when an
///              endpoint's instance has been destroyed — draw nothing, crash never. Dead
///              chain targets are dropped individually; the arc simply skips them.
function beacon_fx_paths(_fx) {
    var _pr = _fx.preset;
    switch (_fx.kind) {
        case "bolt": {
            var _a = __beacon_resolve(_fx.a);
            var _b = __beacon_resolve(_fx.b);
            if (is_undefined(_a) || is_undefined(_b)) return [];
            return beacon_bolt(_a[0], _a[1], _b[0], _b[1], _fx.t_ms, _pr.bolt);
        }
        case "beam": {
            var _a = __beacon_resolve(_fx.a);
            var _b = __beacon_resolve(_fx.b);
            if (is_undefined(_a) || is_undefined(_b)) return [];
            return beacon_beam(_a[0], _a[1], _b[0], _b[1], _fx.t_ms, _pr.beam);
        }
        case "tether": {
            var _a = __beacon_resolve(_fx.a);
            var _b = __beacon_resolve(_fx.b);
            if (is_undefined(_a) || is_undefined(_b)) return [];
            return beacon_tether(_a[0], _a[1], _b[0], _b[1], _fx.t_ms, _pr.tether);
        }
        case "chain": {
            var _xs = [];
            var _ys = [];
            var _tn = array_length(_fx.targets);
            for (var _i = 0; _i < _tn; _i++) {
                var _p = __beacon_resolve(_fx.targets[_i]);
                if (is_undefined(_p)) continue;         // dead target: drop, arc skips it
                array_push(_xs, _p[0]);
                array_push(_ys, _p[1]);
            }
            if (array_length(_xs) < 2) return [];
            return beacon_chain(_xs, _ys, _fx.t_ms, _pr.chain);
        }
        case "trail":
            return beacon_trail_path(_fx.trail, _pr.trail);
    }
    return [];
}

/// @function beacon_fx_draw(_fx)
/// @description Generate and draw in one call — the whole per-frame Draw-event cost of an
///              effect. Blend state is saved and restored inside beacon_draw.
function beacon_fx_draw(_fx) {
    beacon_draw(beacon_fx_paths(_fx), _fx.preset.style);
}
