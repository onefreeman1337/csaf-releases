/// ============================================================================================
/// BEACON · beacon_preset — content and taste.
///
/// Four authored colourways × tuned configs for every effect verb. Each preset is a plain
/// struct of plain structs — copy one, retune the numbers, ship your own. Nothing here is
/// engine state; presets are data.
///
///   BEACON_ARC     electric blue-white — storm magic, tesla coils, EMP
///   BEACON_PLASMA  hot magenta-violet — sci-fi weapons, portals, overdrive
///   BEACON_HOLY    warm gold — divine smite, blessings, sunfire
///   BEACON_VOID    acid green — corruption, toxins, eldritch power
///
/// A preset struct carries:
///   style    the three-pass render style (see beacon_render header)
///   bolt     a bolt cfg    (see beacon_cfg_bolt docs in beacon_core)
///   beam     a beam cfg    · tether  a tether cfg
///   chain    a chain cfg   · trail   a trail cfg
///
/// Usage:
///   var _p = beacon_preset_arc();
///   var _paths = beacon_bolt(x1, y1, x2, y2, fx_time_ms, _p.bolt);
///   beacon_draw(_paths, _p.style);
///
/// Seeds: every preset takes an optional seed so two instances of the same preset never share
/// a shape. Pass any integer — an instance id is perfect.
/// ============================================================================================

/// @function __beacon_preset_build(_core, _glow, _halo, _seed)
/// @description Shared assembly: one style + every effect cfg, tuned to read well at 1080p.
///              Internal — the four public presets call this with their colourways.
function __beacon_preset_build(_core, _glow, _halo, _seed) {
    var _bolt = beacon_cfg_bolt();
    _bolt.seed = _seed;

    var _chain = beacon_cfg_chain();
    _chain.seed = _seed;
    _chain.amp = 34;            // links are shorter than a hero bolt; keep filigree in scale
    _chain.branch_prob = 0.28;

    return {
        style: {
            col_core: _core,  w_core: 2.6,  a_core: 0.95,
            col_glow: _glow,  w_glow: 8,    a_glow: 0.40,
            col_halo: _halo,  w_halo: 22,   a_halo: 0.14,
        },
        bolt: _bolt,
        beam: beacon_cfg_beam(),
        tether: beacon_cfg_tether(),
        chain: _chain,
        trail: beacon_cfg_trail(),
    };
}

/// @function beacon_preset_arc([_seed])
/// @description Electric blue-white. Storm magic, tesla coils, EMP.
function beacon_preset_arc(_seed = 1337) {
    return __beacon_preset_build(
        make_colour_rgb(234, 246, 255),
        make_colour_rgb(85, 170, 255),
        make_colour_rgb(30, 60, 190),
        _seed);
}

/// @function beacon_preset_plasma([_seed])
/// @description Hot magenta-violet. Sci-fi weapons, portals, overdrive.
function beacon_preset_plasma(_seed = 4242) {
    return __beacon_preset_build(
        make_colour_rgb(255, 240, 255),
        make_colour_rgb(224, 85, 255),
        make_colour_rgb(120, 20, 180),
        _seed);
}

/// @function beacon_preset_holy([_seed])
/// @description Warm gold. Divine smite, blessings, sunfire.
function beacon_preset_holy(_seed = 7777) {
    return __beacon_preset_build(
        make_colour_rgb(255, 253, 240),
        make_colour_rgb(255, 210, 77),
        make_colour_rgb(190, 110, 20),
        _seed);
}

/// @function beacon_preset_void([_seed])
/// @description Acid green. Corruption, toxins, eldritch power.
function beacon_preset_void(_seed = 9613) {
    return __beacon_preset_build(
        make_colour_rgb(239, 255, 244),
        make_colour_rgb(51, 255, 150),
        make_colour_rgb(10, 120, 70),
        _seed);
}
