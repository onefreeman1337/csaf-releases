# Beacon — Procedural Energy Renderer for GameMaker

**Version 1.0.0 · GameMaker 2024.x (legacy runtime) · pure GML, no native extension**

Lightning, beams, lasers, chains, tethers and motion trails — generated as geometry every frame,
not played back from a sprite sheet.

Six effect verbs compile to **one intermediate** (a `BeaconPath`) and **one renderer** draws them
all in three layered additive passes. That is the whole design, and it is why this is a system
rather than six unrelated snippets: retune the renderer and every effect changes together.

---

## Why not a sprite sheet

This is the first question worth asking, and canned frames genuinely are the right answer for some
work. Here is where they stop being it.

A pre-rendered lightning animation cannot **connect two things that move**. The moment a bolt has
to start at a wand and end at whichever enemy is currently closest, the artwork has to stretch to
an arbitrary length and rotate to an arbitrary angle — and stretched lightning reads as stretched
lightning. Chain arcs that jump between four live targets, a leash that sags between two moving
instances, a trail that follows an actual flight path: none of them have a fixed length or angle,
so none of them can be a fixed image.

Generated geometry has no native resolution and no fixed length. It also recolours from a struct
field, which means one preset change restyles every effect in the game with no re-export.

## Why not the particle system

GameMaker's particle system is real and it is good, and Beacon does not replace it. It emits
**particles** — sprites and shapes thrown from an emitter. It has no bolt, beam, chain or tether
primitive, and no notion of a path that must begin at A and end at B while both are moving.

Use particles for sparks, smoke and debris. Use Beacon for the connecting light between two points.

---

## Quick start

Three calls: create, tick, draw.

```gml
// Create
fx = beacon_fx_create("bolt", beacon_pt(100, 100), beacon_pt(400, 300), beacon_preset_arc());

// Step
beacon_fx_tick(fx);

// Draw
beacon_fx_draw(fx);
```

Endpoints are points or live instances, mixed freely:

```gml
beacon_pt(x, y)                     // a fixed world point
beacon_anchor(inst, [ox], [oy])     // a live instance, plus an optional offset
```

An anchor whose instance has been destroyed makes the effect **stop drawing** — it never crashes,
and chain targets are dropped one at a time the same way.

The five kinds:

```gml
beacon_fx_create("bolt",   a, b, preset)   // jagged, forking lightning
beacon_fx_create("beam",   a, b, preset)   // straight beam / laser with travelling pulses
beacon_fx_create("tether", a, b, preset)   // sagging energy leash
beacon_fx_create("chain",  a, b, preset)   // arcs through fx.targets (BOTH a and b ignored)
beacon_fx_create("trail",  a, b, preset)   // ribbon of a's position history (b ignored)
```

**A chain reads its whole route from `fx.targets`** — `a` and `b` are not used, so the origin has
to be `targets[0]`, not the `a` argument. Pass `undefined` for both and build the list:

```gml
fx = beacon_fx_create("chain", undefined, undefined, beacon_preset_void());
fx.targets = [beacon_anchor(obj_wand),      // targets[0] IS the origin
              beacon_anchor(e1), beacon_anchor(e2), beacon_anchor(e3)];
```

A chain needs at least two targets that still resolve; below that it draws nothing.

Four authored colourways, every number a plain struct field:

```gml
beacon_preset_arc()      // electric blue-white
beacon_preset_plasma()   // magenta-violet
beacon_preset_holy()     // gold-white
beacon_preset_void()     // toxic green-black
```

Retuning is direct — there is no setter layer to learn:

```gml
var p = beacon_preset_arc();
p.w_glow = 12;              // fatter body
p.a_halo = 0.28;            // heavier atmospheric bleed
p.col_core = c_white;
```

## The demo room

`rm_beacon_demo` is a runnable five-page tour: **1** chain lightning arcing from a pylon to four
orbs · **2** the full preset × verb gallery · **3** a sweeping plasma cutter crossing a holy pillar
· **4** three tethers converging on a reactor hub · **5** four long comet trails.

Open the project, press Run, and use the arrow keys to page. It is the quickstart, and it is also
the smoke test — if something is wrong on your machine, it shows there first.

## What ships

- **`beacon_core`** — the generators. **Pure functions, no engine calls at all**: they take
  coordinates, a time in milliseconds and a config struct, and return a `BeaconPath`. Readable and
  reasonable about in isolation.
- **`beacon_bind`** — the engine binding. The wall clock, instance endpoints, chain target lists.
  The **single** microseconds→milliseconds conversion in the product lives here.
- **`beacon_render`** — the one renderer. Halo, glow and core passes as triangle-strip ribbons.
- **`beacon_preset`** — the four colourways, plus the per-verb config builders.
- **`obj_beacon_demo` + `rm_beacon_demo`** — the demo tour.
- Raw, readable `.gml` throughout. Every public script carries a header block.

## Built to be trusted

- **No `random()` anywhere.** Every spark comes from a 32-bit hash of `(seed, node, time-bucket)`.
  Two runs are byte-identical, so captures reproduce, replays stay in sync, and lockstep multiplayer
  cannot desync on cosmetics.
- **Coherent flicker, not boiling noise.** A bolt holds one shape for its hold window and then
  re-rolls, so it flickers on a cadence instead of reshuffling every frame.
- **Bolt displacement is bounded** by a geometric series — arcs jitter, they never wander off toward
  the corner of the room.
- **Blend state is saved and restored** around every draw, including the `_ext` form. Nothing you
  draw afterwards washes out.
- **Everything is namespaced `beacon_`**, including internals (`__beacon_*`). GML's global namespace
  is flat; nothing here can collide with your project.

## Notes and limits, stated plainly

- **Cost is CPU, not GPU.** The generators run once per node per frame; the renderer emits three
  triangle strips per path. Node counts are the knob — a 40-node bolt costs roughly twice a 20-node
  one, and past about 30 nodes the extra detail is not visible at normal zoom.
- **Trails have a fixed ring capacity**, set at create time (`beacon_trail_create`, default 26 in
  `beacon_fx_create`). A longer ribbon means a larger cap, and the cost is linear in it. The demo's
  comet page raises it deliberately.
- **`beacon_fx_tick` must be called once per Step**, before draw. Effect clocks advance from
  `delta_time`, so behaviour is frame-rate independent — but an effect that is never ticked is
  frozen, not broken.
- **`beacon_draw_debug` is development-only.** It draws a thin polyline with no glow so you can see
  the generated path itself. No preset uses it.
- **This is a renderer, not a combat system.** It draws the light between two points. Damage,
  targeting and cooldowns are yours — `beacon_fx_paths(fx)` hands you the raw geometry if you want
  to drive your own hit detection or draw it yourself.
- **2D only.** The paths are world-space 2D; there is no 3D projection.
- **Legacy runtime.** Built and verified on the stable 2024.x runtime. GMRT is not a dependency and
  is not claimed.

## AI disclosure

This product was written with AI assistance. Code: yes. Store graphics: yes. Sounds: no.

---

© 2026 Corey Gallant and Stephanie Thomason — CSAF. See `LICENSE.txt`.
