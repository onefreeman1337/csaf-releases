# Panoply — Loot & Gear Cards for GameMaker

**Version 1.0.0 · GameMaker 2024.x (legacy runtime) · pure GML, no native extension**

A complete loot & gear system whose art is drawn by the product: **30 hand-authored base forms ×
6 materials × 5 rarities = 900 base variants**, **40 affix families with one hand-authored glyph
each**, deterministic seeded rolls, computed stats, and set detection — and every rolled item gets
a **generated item card**: silhouette, material palette by role, affix glyphs on a rail, and a
drawn rarity treatment. No icon pack, no PNG, no atlas, no sprite anywhere in the package.

---

## Why generated cards

A loot system normally ships as logic plus a folder of icons — and the icons are the part that
never fits your game, because affixes are combinatorial and static art cannot cover them. Panoply
has no icons. A card is a **pure function of the roll**, so:

- **A PNG pack cannot draw a card for an item that was just ROLLED. Panoply can** — that is the
  whole product in one sentence.
- **It recolours from data.** Six materials ship; add a seventh by writing fourteen numbers and
  every base gains a variant.
- **It scales without pixelation.** The same card draws at 90 px on an inventory wall and at
  430 px as a drop reveal.
- **Content you add gets art for free.** Register a base form or an affix (a name plus a list of
  strokes) and it rolls, renders and titles like everything shipped.

## Quick start

```gml
// Create (obj Create event) — registry, forge, and the starter content
registry = pan_starter_registry();
forge    = pan_forge_create();
pan_forge_roll(forge, registry, 12345);     // any integer seed

// Step (obj Step event) — advances the card's forge reveal
pan_forge_step(forge);

// Draw GUI — the card draws itself; pass forge.anim_t for the reveal, 1 for finished
pan_draw_card(forge.plan, pan_tables(registry), x, y, 430, current_time / 1000, 1, forge.anim_t);
```

Draw any glyph anywhere — a base silhouette, an affix mark:

```gml
var tables = pan_tables(registry);
pan_draw_glyph(tables.bases[0],   x, y, 120, tables.materials[3], 1, 1);
pan_draw_glyph(tables.affixes[7], x, y,  24, tables.materials[0], 1, 1);
```

## The roll is the save format

`pan_roll(seed, tables)` is deterministic — xorshift32 over the seed, never `random()` — so an
item persists as `{ seed, version }` and re-rolls losslessly on load:

```gml
data = pan_item_pack(item);              // { v, seed } — tiny, versioned
item = pan_item_unpack(registry, data);  // identical item, identical card
```

**The compatibility contract: APPEND content, never reorder or remove it.** The roll draws base,
material and rarity before affixes, so appended content leaves old seeds' identities intact.

## Stats and sets

```gml
stats = pan_item_stats(item, tables, pan_starter_mods());   // { might, ward, grace }

loadout = pan_loadout_create();
pan_loadout_equip(loadout, item);
results = pan_loadout_sets(loadout, registry);   // per set: count + met bonus tiers
```

24 of the 40 affix families ship wired to concrete stat mods as the pattern to copy; unwired
families fall back to +1 grace so no roll is ever statless. Three example sets ship — a set names
its pieces by base id, binds them to a material, and unlocks bonus tiers at piece counts.

## Register your own content

```gml
pan_registry_add_base(registry, __pan_base("scythe", "Scythe", "weapon", 13, 0, 3,
    [pan_line(0, 0.9, 0, -0.6), pan_arc(0.3, -0.55, 0.45, 120, 300)], []));
pan_registry_add_affix(registry, __pan_affix("storming", "Storming", 2,
    [pan_poly([-0.4, 0.3, 0, -0.3, 0.4, 0.3])], []));
pan_registry_add_set(registry, { id: "reaper", name: "Reaper's Toll", material: "umbral",
    pieces: ["scythe", "cloak", "mask"], bonuses: [ { need: 2, text: "+8 might" } ] });
```

## The demo room

`rm_panoply_demo` is the quickstart, the smoke test and the storyboard in one. Run it and press
**1–5** for: the 900-variant armory wall · the forge (a roll drawing itself, stats read out) ·
the 40-glyph affix corpus · the same item at all five rarity tiers · sets lighting up as pieces
equip. Every position is a pure function of the demo clock, so captures reproduce exactly.

## Design guarantees

- **Pure core.** `panoply_core` makes zero engine calls — the corpus, the roll, card composition,
  stats and set detection are all reviewable in isolation, and are mirrored by 39 assertions in
  JS against the exact shipped tables.
- **Deterministic.** No `random()` anywhere: the same seed is the same item and the same card on
  every machine, every session. Measured over 20,000 seeds: every rarity tier lands within 1.5
  percentage points of its weight and no affix exceeds 4.71% of rolls.
- **Blend-state safe.** Every public draw saves and restores blend mode, colour, alpha and text
  alignment. Your lighting will not break because a card was drawn.
- **Namespaced.** Every symbol starts `pan_`, `__pan_` or `PAN_` — nothing collides with your
  globals.

## Files

| Script | What it holds |
| --- | --- |
| `panoply_core` | the corpus (30 bases, 6 materials, 5 rarities, 40 affixes), the roll, card composition, stats, sets — pure |
| `panoply_bind` | registry, forge state, loadout, save/load, the one `delta_time` conversion |
| `panoply_render` | `pan_draw_card`, `pan_draw_glyph`, panel chrome — saves and restores all GPU state |
| `panoply_preset` | starter mods, three example sets, the UI theme — all delete-me data |
| `obj_panoply_demo` / `rm_panoply_demo` | the 5-page demo room |

## Install

**Option A (.yymps):** Tools → Import Local Package → `Panoply.yymps` → Import All.
**Option B (raw):** copy the four script folders (and optionally the demo object/room/fonts) from
the `Panoply/` project folder into your project.

Requires GameMaker 2024.x. Pure GML — every platform GameMaker exports to.

---

Questions or a bug? Leave a comment on the store page — reports come with enough detail to
reproduce (your GameMaker version and what you rolled) and get fixed.

*Panoply is a CSAF product. AI-assisted code and store art, disclosed on every listing.*
