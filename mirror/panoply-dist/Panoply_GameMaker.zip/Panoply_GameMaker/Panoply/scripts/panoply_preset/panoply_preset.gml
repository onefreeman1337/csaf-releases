/// ============================================================================================
/// PANOPLY - panoply_preset: content and taste.
///
/// A starter mod book, three example sets and the UI theme, as plain data. Everything here is
/// meant to be copied, retuned or replaced wholesale - none of it is load-bearing for the
/// system, and the demo scaffolding is commented as delete-me.
///
/// This file is deliberately the SMALLEST of the four. The product's value is the generator in
/// panoply_core; your affix balance and your sets are your own, and Panoply draws cards for
/// content that did not exist when this shipped.
/// ============================================================================================

/// The UI theme. Custom throughout - GameMaker draws none of this, which is the point (a
/// product that looks like the engine gets dismissed on the thumbnail).
function pan_theme() {
    static _t = {
        bg:        { r:  13, g:  14, b:  19 },
        panel:     { r:  21, g:  24, b:  33 },
        rule:      { r:  52, g:  58, b:  76 },
        text:      { r: 216, g: 222, b: 235 },
        text_dim:  { r: 126, g: 136, b: 158 },
        good:      { r: 132, g: 210, b: 148 },
        pad:       28,
        rowH:      42,
    };
    return _t;
}

/// The starter mod book: 24 of the 40 affix families wired to concrete stat mods, as the
/// pattern to copy. Unwired families fall back to +1 grace (pan_item_stats), so no roll is
/// ever statless. DELETE-ME in your project - wire your own numbers.
function pan_starter_mods() {
    static _m = {
        keen:      { stat: "might", add: 5 },
        brutal:    { stat: "might", add: 8 },
        swift:     { stat: "grace", add: 6 },
        warding:   { stat: "ward",  add: 6 },
        vampiric:  { stat: "might", add: 4 },
        echoing:   { stat: "grace", add: 4 },
        burning:   { stat: "might", add: 6 },
        freezing:  { stat: "ward",  add: 4 },
        shocking:  { stat: "grace", add: 5 },
        venomous:  { stat: "might", add: 3 },
        sundering: { stat: "might", add: 7 },
        piercing:  { stat: "might", add: 5 },
        guarding:  { stat: "ward",  add: 8 },
        thorned:   { stat: "ward",  add: 5 },
        blessed:   { stat: "ward",  add: 7 },
        cursed:    { stat: "might", add: 9 },
        lucky:     { stat: "grace", add: 8 },
        greedy:    { stat: "grace", add: 3 },
        stalwart:  { stat: "ward",  add: 9 },
        nimble:    { stat: "grace", add: 7 },
        arcanist:  { stat: "grace", add: 9 },
        leeching:  { stat: "might", add: 4 },
        rending:   { stat: "might", add: 6 },
        crushing:  { stat: "might", add: 7 },
    };
    return _m;
}

/// Three example sets, one per material mood. A set names its pieces by BASE id and binds them
/// to one MATERIAL id; bonuses unlock at piece counts. DELETE-ME - define your own.
function pan_starter_sets() {
    static _s = [
        {
            id: "bulwark", name: "Bulwark of the March", material: "iron",
            pieces: ["helm", "cuirass", "shield"],
            bonuses: [
                { need: 2, text: "+10 ward" },
                { need: 3, text: "+24 ward, immovable stance" },
            ],
        },
        {
            id: "gloaming", name: "Gloaming Regalia", material: "umbral",
            pieces: ["mask", "cloak", "dagger", "ring"],
            bonuses: [
                { need: 2, text: "+8 grace" },
                { need: 3, text: "+14 grace, veiled step" },
                { need: 4, text: "shadow twin on strike" },
            ],
        },
        {
            id: "auriphlegm", name: "Gilded Court", material: "gilt",
            pieces: ["sword", "pauldron", "talisman"],
            bonuses: [
                { need: 2, text: "+6 might, +6 ward" },
                { need: 3, text: "royal decree: all stats +10" },
            ],
        },
    ];
    return _s;
}

/// Convenience: a registry with the three starter sets already registered.
/// DELETE-ME in a buyer's project - register your own content instead.
function pan_starter_registry() {
    var _reg = pan_registry_create();
    var _sets = pan_starter_sets();
    for (var _i = 0; _i < array_length(_sets); _i++) {
        pan_registry_add_set(_reg, _sets[_i]);
    }
    return _reg;
}
