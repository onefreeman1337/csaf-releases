/// ============================================================================================
/// PANOPLY - panoply_core: the pure generator core.
///
/// ZERO engine calls. Nothing in this file reads an instance, a room, a sprite, the clock or the
/// renderer; the only built-ins used are pure maths (sin/cos/floor/min/max/abs/clamp/lerp/pi/
/// degtorad) and array/struct functions. That is deliberate: GML cannot be unit-tested outside
/// GameMaker, so every algorithm in Panoply lives where it can be read, reasoned about and
/// mirrored numerically in isolation. `Internal_Ops/sim_mirror.js` is that mirror - and unlike
/// earlier products it does not transliterate this corpus: it EXTRACTS the tables between the
/// MIRROR markers below and evaluates the exact shipped data, so the two cannot drift.
///
/// THE ONE IDEA - a rolled item is a seed plus data, and the card is a pure function of it.
///   pan_roll(seed, tables) -> { seed, base, material, rarity, affixes[] }, every choice drawn
///   from a deterministic 32-bit xorshift stream seeded by the item's seed. NEVER random().
///   pan_card_compose(item, tables) turns that data into a draw plan, and panoply_render turns
///   the plan into a picture. Same seed -> same item -> same card, in any session, on any
///   machine. A buyer's save file stays visually stable, and content the buyer registers (a new
///   base form, a new affix) gets card art for free - which is the exact demand icon packs prove
///   and structurally cannot serve: a PNG pack cannot draw a card for an item that was just
///   ROLLED.
///
/// THE VOLUME IS THE MOAT (master 1.1 rule 3 - authored in Motif_Corpus.md BEFORE any code).
///   30 hand-authored base silhouettes x 6 material tinctures x 5 rarity treatments = 900 base
///   variants, before the 40 affix glyph families even start. Rules are cheap; a corpus that
///   coheres into one visual language is not.
///
/// Public API (everything else is internal and prefixed __pan_):
///   pan_base_table()                    -> array of 30 base-form PanGlyphs (cached)
///   pan_material_table()                -> array of 6 materials (cached)
///   pan_rarity_table()                  -> array of 5 rarity tiers (cached)
///   pan_affix_table()                   -> array of 40 affix families (cached)
///   pan_tables_default()                -> { bases, materials, rarities, affixes } of the above
///   pan_base_find(tables, id)           -> index of a base by string id, or -1
///   pan_affix_find(tables, id)          -> index of an affix by string id, or -1
///   pan_glyph_flatten(glyph)            -> array of polylines, each a flat [x0,y0,x1,y1,...]
///   pan_roll(seed, tables)              -> deterministic item roll
///   pan_card_compose(item, tables)      -> the card draw plan (title, track, treatment)
///   pan_item_stats(item, tables, mods)  -> { might, ward, grace } computed stats
///   pan_set_progress(set_def, items)    -> how many equipped items count toward a set
/// ============================================================================================

#macro PAN_VERSION        "1.0.0"
#macro PAN_BASE_COUNT     30
#macro PAN_MATERIAL_COUNT 6
#macro PAN_RARITY_COUNT   5
#macro PAN_AFFIX_COUNT    40
#macro PAN_ARC_SEGS       24      // flattening resolution for a full 360 degree arc
#macro PAN_TRACK_MAX      6       // affix glyphs visible on the card track before the +n bead

// ── stroke primitive constructors ────────────────────────────────────────────────────────────
// Kept as tiny structs so the corpus below reads as authored geometry rather than as maths.
// Unit space is [-1..1] on both axes; the renderer maps it to the draw box.

function pan_line(_ax, _ay, _bx, _by) {
    return { k: "line", ax: _ax, ay: _ay, bx: _bx, by: _by };
}
function pan_arc(_cx, _cy, _r, _a0, _a1) {
    return { k: "arc", cx: _cx, cy: _cy, r: _r, a0: _a0, a1: _a1 };
}
function pan_circle(_cx, _cy, _r) {
    return { k: "arc", cx: _cx, cy: _cy, r: _r, a0: 0, a1: 360 };
}
function pan_poly(_pts) {
    return { k: "poly", pts: _pts };          // flat [x0,y0,x1,y1,...]
}
function pan_spiral(_cx, _cy, _r0, _r1, _a0, _a1) {
    return { k: "spiral", cx: _cx, cy: _cy, r0: _r0, r1: _r1, a0: _a0, a1: _a1 };
}

/// Flatten one primitive to a flat polyline [x0,y0,x1,y1,...]. Deterministic.
function __pan_flatten_prim(_p) {
    var _out = [];
    switch (_p.k) {
        case "line":
            _out = [_p.ax, _p.ay, _p.bx, _p.by];
        break;

        case "poly": {
            // copy so a caller cannot mutate the cached corpus
            var _n = array_length(_p.pts);
            for (var _i = 0; _i < _n; _i++) { array_push(_out, _p.pts[_i]); }
        } break;

        case "arc": {
            var _span = _p.a1 - _p.a0;
            var _steps = max(2, round(PAN_ARC_SEGS * abs(_span) / 360));
            for (var _i = 0; _i <= _steps; _i++) {
                var _a = degtorad(_p.a0 + _span * (_i / _steps));
                array_push(_out, _p.cx + cos(_a) * _p.r);
                array_push(_out, _p.cy + sin(_a) * _p.r);
            }
        } break;

        case "spiral": {
            var _span = _p.a1 - _p.a0;
            var _steps = max(2, round(PAN_ARC_SEGS * abs(_span) / 360));
            for (var _i = 0; _i <= _steps; _i++) {
                var _t = _i / _steps;
                var _a = degtorad(_p.a0 + _span * _t);
                var _r = lerp(_p.r0, _p.r1, _t);
                array_push(_out, _p.cx + cos(_a) * _r);
                array_push(_out, _p.cy + sin(_a) * _r);
            }
        } break;
    }
    return _out;
}

/// Flatten a whole PanGlyph -> array of flat polylines.
function pan_glyph_flatten(_glyph) {
    var _out = [];
    var _n = array_length(_glyph.strokes);
    for (var _i = 0; _i < _n; _i++) {
        array_push(_out, __pan_flatten_prim(_glyph.strokes[_i]));
    }
    return _out;
}

// ── authored helpers used by the corpus ──────────────────────────────────────────────────────

/// closed regular n-gon
function __pan_ngon(_cx, _cy, _r, _n, _rot) {
    var _pts = [];
    for (var _i = 0; _i <= _n; _i++) {
        var _a = degtorad(_rot + (360 / _n) * _i);
        array_push(_pts, _cx + cos(_a) * _r);
        array_push(_pts, _cy + sin(_a) * _r);
    }
    return _pts;
}

/// closed n-point star
function __pan_star(_cx, _cy, _ro, _ri, _points, _rot) {
    var _pts = [];
    var _tot = _points * 2;
    for (var _i = 0; _i <= _tot; _i++) {
        var _r = (_i % 2 == 0) ? _ro : _ri;
        var _a = degtorad(_rot + (180 / _points) * _i);
        array_push(_pts, _cx + cos(_a) * _r);
        array_push(_pts, _cy + sin(_a) * _r);
    }
    return _pts;
}

/// sine wave polyline
function __pan_wave(_x0, _x1, _y, _amp, _cycles) {
    var _pts = [];
    for (var _i = 0; _i <= 32; _i++) {
        var _t = _i / 32;
        array_push(_pts, lerp(_x0, _x1, _t));
        array_push(_pts, _y + sin(_t * _cycles * 2 * pi) * _amp);
    }
    return _pts;
}

/// axis-aligned ellipse polyline (Greedy's coin stack)
function __pan_ellipse(_cx, _cy, _rx, _ry) {
    var _pts = [];
    for (var _i = 0; _i <= 24; _i++) {
        var _a = degtorad((360 / 24) * _i);
        array_push(_pts, _cx + cos(_a) * _rx);
        array_push(_pts, _cy + sin(_a) * _ry);
    }
    return _pts;
}

/// Gerono lemniscate - the Eternal figure-eight, one closed stroke
function __pan_lemni(_cx, _cy, _rx, _ry) {
    var _pts = [];
    for (var _i = 0; _i <= 48; _i++) {
        var _a = degtorad((360 / 48) * _i);
        array_push(_pts, _cx + cos(_a) * _rx);
        array_push(_pts, _cy + sin(_a) * cos(_a) * _ry * 2);
    }
    return _pts;
}

/// base form: id, display name, kind (weapon/armour/trinket), base stat block, geometry
function __pan_base(_id, _name, _kind, _might, _ward, _grace, _strokes, _accents) {
    return { id: _id, name: _name, kind: _kind,
             might: _might, ward: _ward, grace: _grace,
             strokes: _strokes, accents: _accents };
}

/// affix family: id, display name, roll weight, glyph geometry
function __pan_affix(_id, _name, _w, _strokes, _accents) {
    return { id: _id, name: _name, w: _w, strokes: _strokes, accents: _accents };
}

/// material: id, name, glow strength, then edge / body / detail / glow as r,g,b triples
function __pan_material(_id, _name, _glow_amt,
                        _er, _eg, _eb, _br, _bg, _bb, _dr, _dg, _db, _gr, _gg, _gb) {
    return {
        id: _id, name: _name, glow_amt: _glow_amt,
        edge:   { r: _er, g: _eg, b: _eb },
        body:   { r: _br, g: _bg, b: _bb },
        detail: { r: _dr, g: _dg, b: _db },
        glow:   { r: _gr, g: _gg, b: _gb },
    };
}

/// rarity tier: id, name, roll weight, affix count range, stat multiplier, frame colour r,g,b
function __pan_rarity(_id, _name, _w, _afx_min, _afx_max, _mult, _fr, _fg, _fb) {
    return { id: _id, name: _name, w: _w, afx_min: _afx_min, afx_max: _afx_max,
             mult: _mult, frame: { r: _fr, g: _fg, b: _fb } };
}

// ── THE 30 BASE FORMS ────────────────────────────────────────────────────────────────────────
// Per Internal_Ops/Motif_Corpus.md. Weapons point UP (tip at negative y). Every silhouette is
// 3-6 strokes in unit space; accents are the small marked points, stored flat as x,y pairs.
// `static` caches the table after the first call - the corpus is immutable.

function pan_base_table() {
    static _tbl =
    // >>> MIRROR BASES
    [
        // ---- weapons (12) ----
        __pan_base("sword", "Sword", "weapon", 12, 0, 4,
            [pan_poly([-0.10, -0.72, 0, -0.95, 0.10, -0.72, 0.10, 0.32, -0.10, 0.32, -0.10, -0.72]),
             pan_line(0, -0.68, 0, 0.24), pan_line(-0.34, 0.32, 0.34, 0.32),
             pan_line(0, 0.32, 0, 0.68), pan_circle(0, 0.78, 0.08)],
            [0, 0.78]),
        __pan_base("axe", "Axe", "weapon", 14, 0, 2,
            [pan_line(0.12, 0.92, 0.12, -0.72),
             pan_poly([0.12, -0.72, -0.28, -0.80, -0.58, -0.58, -0.62, -0.16, -0.34, -0.06, 0.12, -0.30]),
             pan_line(-0.38, -0.56, -0.26, -0.24)],
            []),
        __pan_base("spear", "Spear", "weapon", 11, 0, 6,
            [pan_line(0, 0.95, 0, -0.42),
             pan_poly([0, -0.95, 0.18, -0.62, 0, -0.42, -0.18, -0.62, 0, -0.95]),
             pan_line(0, -0.90, 0, -0.48)],
            []),
        __pan_base("bow", "Bow", "weapon", 9, 0, 9,
            [pan_arc(-0.30, 0, 0.95, -65, 65),
             pan_line(0.10, -0.86, 0.10, 0.86),
             pan_line(-0.52, 0, 0.36, 0),
             pan_poly([0.36, 0, 0.22, -0.09, 0.36, 0, 0.22, 0.09])],
            [0.10, 0]),
        __pan_base("dagger", "Dagger", "weapon", 8, 0, 10,
            [pan_poly([0, -0.70, 0.13, -0.44, 0.06, 0.10, -0.06, 0.10, -0.13, -0.44, 0, -0.70]),
             pan_line(-0.22, 0.10, 0.22, 0.10), pan_line(0, 0.10, 0, 0.38),
             pan_circle(0, 0.58, 0.20)],
            []),
        __pan_base("mace", "Mace", "weapon", 13, 0, 2,
            [pan_line(0, 0.92, 0, -0.14), pan_circle(0, -0.48, 0.34),
             pan_line(-0.20, -0.72, -0.20, -0.24), pan_line(0, -0.84, 0, -0.12),
             pan_line(0.20, -0.72, 0.20, -0.24)],
            []),
        __pan_base("staff", "Staff", "weapon", 7, 0, 8,
            [pan_line(0, 0.95, 0, -0.46), pan_circle(0, -0.68, 0.24), pan_line(-0.12, -0.40, 0.12, -0.40)],
            []),
        __pan_base("wand", "Wand", "weapon", 6, 0, 11,
            [pan_line(-0.28, 0.62, 0.26, -0.38),
             pan_line(0.30, -0.46, 0.30, -0.78), pan_line(0.30, -0.46, 0.04, -0.62),
             pan_line(0.30, -0.46, 0.56, -0.62)],
            [0.30, -0.46]),
        __pan_base("flail", "Flail", "weapon", 12, 0, 4,
            [pan_line(-0.42, 0.86, -0.10, 0.10),
             pan_circle(0.00, -0.05, 0.10), pan_circle(0.13, -0.23, 0.10),
             pan_poly(__pan_star(0.34, -0.52, 0.30, 0.13, 4, -90))],
            []),
        __pan_base("halberd", "Halberd", "weapon", 14, 0, 1,
            [pan_line(0, 0.95, 0, -0.78),
             pan_poly([0, -0.95, 0.11, -0.76, -0.11, -0.76, 0, -0.95]),
             pan_poly([0, -0.70, 0.38, -0.62, 0.44, -0.28, 0, -0.34]),
             pan_poly([0, -0.60, -0.28, -0.54, -0.18, -0.36])],
            []),
        __pan_base("crossbow", "Crossbow", "weapon", 12, 0, 3,
            [pan_arc(0, -0.10, 0.75, 190, 350),
             pan_line(-0.74, -0.22, 0.74, -0.22),
             pan_line(0, -0.85, 0, 0.60), pan_line(0, 0.26, 0.15, 0.40)],
            []),
        __pan_base("sling", "Sling", "weapon", 5, 0, 12,
            [pan_poly([0, 0.86, 0, 0.26, -0.30, -0.14]), pan_line(0, 0.26, 0.30, -0.14),
             pan_poly([-0.30, -0.14, 0, -0.60, 0.30, -0.14]),
             pan_circle(0, -0.68, 0.10)],
            [0, -0.68]),
        // ---- armour (10) ----
        __pan_base("helm", "Helm", "armour", 0, 11, 2,
            [pan_arc(0, 0.05, 0.60, 180, 360),
             pan_line(-0.60, 0.05, -0.54, 0.55), pan_line(0.60, 0.05, 0.54, 0.55),
             pan_line(0, -0.16, 0, 0.46), pan_arc(0.30, 0.55, 0.24, 180, 300)],
            []),
        __pan_base("cuirass", "Cuirass", "armour", 0, 14, 0,
            [pan_poly([-0.50, -0.60, 0.50, -0.60, 0.55, 0.05, 0.30, 0.62, -0.30, 0.62, -0.55, 0.05, -0.50, -0.60]),
             pan_line(0, -0.60, 0, 0.62),
             pan_arc(-0.25, -0.16, 0.20, -70, 120), pan_arc(0.25, -0.16, 0.20, 60, 250)],
            []),
        __pan_base("greaves", "Greaves", "armour", 0, 9, 5,
            [pan_poly([-0.36, -0.28, -0.15, -0.28, -0.12, 0.70, -0.39, 0.70, -0.36, -0.28]),
             pan_poly([0.15, -0.28, 0.36, -0.28, 0.39, 0.70, 0.12, 0.70, 0.15, -0.28]),
             pan_circle(-0.26, -0.45, 0.14), pan_circle(0.26, -0.45, 0.14)],
            []),
        __pan_base("gauntlet", "Gauntlet", "armour", 3, 9, 3,
            [pan_poly([-0.32, -0.14, -0.28, -0.62, 0.28, -0.62, 0.32, -0.14, -0.32, -0.14]),
             pan_line(-0.15, -0.62, -0.15, -0.14), pan_line(0, -0.62, 0, -0.14), pan_line(0.15, -0.62, 0.15, -0.14),
             pan_poly([-0.32, -0.14, -0.46, 0.52, 0.46, 0.52, 0.32, -0.14])],
            []),
        __pan_base("shield", "Shield", "armour", 0, 15, 0,
            [pan_poly([-0.55, -0.55, 0.55, -0.55, 0.50, 0.05, 0, 0.70, -0.50, 0.05, -0.55, -0.55]),
             pan_line(-0.52, -0.28, 0.52, -0.28), pan_circle(0, 0.06, 0.09)],
            [0, 0.06]),
        __pan_base("cloak", "Cloak", "armour", 0, 6, 9,
            [pan_arc(-0.55, -0.05, 0.42, -40, 95), pan_arc(-0.10, 0.42, 0.38, 150, 250),
             pan_arc(0.55, -0.05, 0.42, 85, 220), pan_arc(0.10, 0.42, 0.38, -70, 30),
             pan_circle(0, -0.62, 0.09)],
            [0, -0.62]),
        __pan_base("belt", "Belt", "armour", 0, 7, 7,
            [pan_poly([-0.80, -0.12, 0.80, -0.12, 0.80, 0.12, -0.80, 0.12, -0.80, -0.12]),
             pan_poly([-0.18, -0.24, 0.18, -0.24, 0.18, 0.24, -0.18, 0.24, -0.18, -0.24]),
             pan_line(0, 0.24, -0.06, 0.62)],
            []),
        __pan_base("boot", "Boot", "armour", 0, 8, 6,
            [pan_poly([-0.30, -0.62, 0.05, -0.62, 0.05, 0.24, 0.52, 0.34, 0.56, 0.60, -0.30, 0.60, -0.30, -0.62]),
             pan_line(-0.30, -0.38, 0.05, -0.38),
             pan_line(-0.30, 0.42, -0.06, 0.60)],
            []),
        __pan_base("pauldron", "Pauldron", "armour", 2, 12, 0,
            [pan_arc(0, 0.45, 0.75, 200, 340), pan_arc(0, 0.35, 0.55, 195, 345), pan_arc(0, 0.25, 0.35, 190, 350),
             pan_circle(-0.56, 0.30, 0.05), pan_circle(0.56, 0.30, 0.05)],
            [-0.56, 0.30, 0.56, 0.30]),
        __pan_base("mask", "Mask", "armour", 0, 5, 11,
            [pan_circle(0, 0, 0.62),
             pan_line(-0.30, -0.06, -0.10, -0.02), pan_line(0.30, -0.06, 0.10, -0.02),
             pan_line(-0.40, -0.28, 0.40, -0.28)],
            []),
        // ---- trinkets (8) ----
        __pan_base("ring", "Ring", "trinket", 2, 2, 10,
            [pan_circle(0, 0.15, 0.50),
             pan_poly([0, -0.72, 0.22, -0.48, 0, -0.24, -0.22, -0.48, 0, -0.72]),
             pan_line(-0.22, -0.48, 0.22, -0.48)],
            [0, -0.48]),
        __pan_base("amulet", "Amulet", "trinket", 3, 3, 8,
            [pan_poly([-0.55, -0.28, 0, -0.75, 0.55, -0.28]),
             pan_poly([0, -0.28, 0.28, 0.15, 0, 0.58, -0.28, 0.15, 0, -0.28]),
             pan_arc(-0.06, 0.14, 0.13, 120, 260)],
            [0, -0.75]),
        __pan_base("idol", "Idol", "trinket", 6, 6, 2,
            [pan_circle(0, -0.52, 0.22), pan_line(-0.45, -0.20, 0.45, -0.20),
             pan_line(-0.35, -0.20, -0.25, 0.45), pan_line(0.35, -0.20, 0.25, 0.45),
             pan_poly([-0.45, 0.70, 0.45, 0.70, 0.25, 0.45, -0.25, 0.45, -0.45, 0.70])],
            []),
        __pan_base("phial", "Phial", "trinket", 1, 4, 9,
            [pan_poly([-0.16, -0.74, -0.16, -0.34, -0.38, 0.06, -0.38, 0.64, 0.38, 0.64, 0.38, 0.06, 0.16, -0.34, 0.16, -0.74, -0.16, -0.74]),
             pan_poly([-0.20, -0.74, 0.20, -0.74, 0.20, -0.90, -0.20, -0.90, -0.20, -0.74]),
             pan_line(-0.38, 0.26, 0.38, 0.26)],
            []),
        __pan_base("tome", "Tome", "trinket", 5, 5, 5,
            [pan_poly([-0.50, -0.62, 0.42, -0.62, 0.42, 0.62, -0.50, 0.62, -0.50, -0.62]),
             pan_line(0.46, -0.58, 0.46, 0.58), pan_line(0.50, -0.52, 0.50, 0.52),
             pan_poly([0.30, -0.10, 0.56, -0.10, 0.56, 0.10, 0.30, 0.10, 0.30, -0.10])],
            []),
        __pan_base("lantern", "Lantern", "trinket", 2, 5, 7,
            [pan_poly([-0.25, -0.50, 0.25, -0.50, 0.35, -0.35, -0.35, -0.35, -0.25, -0.50]),
             pan_poly([-0.35, -0.35, 0.35, -0.35, 0.42, 0.50, -0.42, 0.50, -0.35, -0.35]),
             pan_line(-0.14, -0.35, -0.17, 0.50), pan_line(0.14, -0.35, 0.17, 0.50),
             pan_circle(0, -0.68, 0.14),
             pan_poly([0, 0.28, 0.10, 0.05, 0, -0.12, -0.10, 0.05, 0, 0.28])],
            [0, 0.05]),
        __pan_base("orb", "Orb", "trinket", 4, 2, 9,
            [pan_circle(0, -0.05, 0.55), pan_arc(-0.15, -0.20, 0.30, 120, 260),
             pan_line(0, 0.50, 0, 0.62), pan_line(-0.28, 0.62, 0.28, 0.62)],
            []),
        __pan_base("talisman", "Talisman", "trinket", 4, 4, 7,
            [pan_poly(__pan_ngon(0, -0.10, 0.55, 5, -90)),
             pan_arc(0, -0.14, 0.18, 200, 340), pan_line(-0.18, -0.06, 0.18, -0.06),
             pan_line(-0.15, 0.42, -0.20, 0.80), pan_line(0.15, 0.42, 0.20, 0.80)],
            [0, -0.10]),
    ]
    // <<< MIRROR BASES
    ;
    return _tbl;
}

// ── THE 6 MATERIALS ──────────────────────────────────────────────────────────────────────────
// Tinctures applied BY ROLE (edge / body / detail / glow), never per-item hand-colouring. That
// is what makes 30 x 6 a coherent 180 rather than 180 one-offs - and adding a seventh material
// is DATA: append one row and every base gains a variant. Components stay r/g/b so this file is
// free of colour built-ins (GameMaker's make_colour_rgb packs BGR - a render-layer detail).

function pan_material_table() {
    static _tbl =
    // >>> MIRROR MATERIALS
    [
        __pan_material("iron",   "Iron",   0.00, 168, 174, 184,  74,  80,  92, 208, 214, 224,  40,  44,  52),
        __pan_material("bronze", "Bronze", 0.30, 214, 160, 102, 108,  72,  40, 240, 205, 160, 224, 120,  48),
        __pan_material("silver", "Silver", 0.35, 232, 238, 246, 120, 132, 150, 170, 215, 255, 225, 240, 255),
        __pan_material("gilt",   "Gilt",   0.45, 243, 208, 110, 140, 100,  38, 255, 238, 180, 255, 196,  64),
        __pan_material("umbral", "Umbral", 0.55,  92,  76, 128,  38,  28,  56, 226, 120, 214, 150,  70, 200),
        __pan_material("arcane", "Arcane", 0.80,  96, 210, 214,  22,  58,  74, 140, 240, 255,  64, 220, 230),
    ]
    // <<< MIRROR MATERIALS
    ;
    return _tbl;
}

// ── THE 5 RARITY TIERS ───────────────────────────────────────────────────────────────────────
// Weights sum to 100. The treatment (frame + aura) is drawn per tier by panoply_render; here a
// tier is its weight, its affix budget, its stat multiplier and its frame colour.

function pan_rarity_table() {
    static _tbl =
    // >>> MIRROR RARITIES
    [
        __pan_rarity("common",   "Common",   46, 0, 1, 1.00, 150, 155, 165),
        __pan_rarity("uncommon", "Uncommon", 27, 1, 2, 1.15, 110, 200, 120),
        __pan_rarity("rare",     "Rare",     15, 2, 3, 1.35,  90, 160, 240),
        __pan_rarity("epic",     "Epic",      8, 3, 4, 1.60, 185, 105, 240),
        __pan_rarity("mythic",   "Mythic",    4, 4, 6, 2.00, 255, 170,  60),
    ]
    // <<< MIRROR RARITIES
    ;
    return _tbl;
}

// ── THE 40 AFFIX GLYPH FAMILIES ──────────────────────────────────────────────────────────────
// One hand-authored mark per family, drawn on the card's affix track at ~20 px - so every glyph
// is 1-3 strokes and at most 2 accent dots (Motif_Corpus.md's legibility rule; Feral carries its
// third toe as a tiny circle STROKE for that reason). Weights: 24 common families at 3, 16
// scarcer families at 2 - measured dominance stays under the 6% floor in sim_mirror.js.

function pan_affix_table() {
    static _tbl =
    // >>> MIRROR AFFIXES
    [
        __pan_affix("keen",     "Keen",     3, [pan_poly([-0.5, 0.3, 0, -0.4, 0.5, 0.3])], []),
        __pan_affix("brutal",   "Brutal",   3, [pan_line(-0.5, -0.35, 0.5, -0.35), pan_line(0, -0.35, 0, 0.55)], []),
        __pan_affix("swift",    "Swift",    3, [pan_line(-0.6, -0.3, 0.1, -0.3), pan_line(-0.45, 0, 0.3, 0), pan_line(-0.3, 0.3, 0.55, 0.3)], []),
        __pan_affix("warding",  "Warding",  3, [pan_poly([-0.4, -0.45, 0.4, -0.45, 0.35, 0.1, 0, 0.55, -0.35, 0.1, -0.4, -0.45])], []),
        __pan_affix("vampiric", "Vampiric", 3, [pan_poly([0, -0.5, 0.3, 0.05, 0, 0.5, -0.3, 0.05, 0, -0.5]), pan_line(0.15, -0.3, 0.34, -0.55)], []),
        __pan_affix("echoing",  "Echoing",  3, [pan_arc(0, 0, 0.3, -60, 60), pan_arc(0, 0, 0.55, -60, 60)], []),
        __pan_affix("burning",  "Burning",  3, [pan_poly([0, -0.55, 0.26, -0.05, 0.1, 0.2, 0.3, 0.55]), pan_poly([0, -0.55, -0.26, -0.05, -0.1, 0.2, -0.3, 0.55])], []),
        __pan_affix("freezing", "Freezing", 3, [pan_line(0, -0.5, 0, 0.5), pan_line(-0.43, -0.25, 0.43, 0.25), pan_line(-0.43, 0.25, 0.43, -0.25)], []),
        __pan_affix("shocking", "Shocking", 3, [pan_poly([-0.3, -0.55, 0.15, -0.1, -0.1, 0.05, 0.35, 0.55])], []),
        __pan_affix("venomous", "Venomous", 3, [pan_poly([-0.4, -0.4, -0.1, -0.4, -0.25, 0.45, -0.4, -0.4]), pan_poly([0.1, -0.4, 0.4, -0.4, 0.25, 0.45, 0.1, -0.4])], []),
        __pan_affix("sundering","Sundering",3, [pan_line(-0.55, -0.1, -0.05, -0.1), pan_line(0.05, 0.1, 0.55, 0.1), pan_poly([-0.05, -0.35, 0.1, -0.05, -0.1, 0.15, 0.05, 0.4])], []),
        __pan_affix("piercing", "Piercing", 3, [pan_circle(0, -0.05, 0.28), pan_line(0, -0.55, 0, 0.45), pan_poly([0, 0.55, 0.18, 0.25, -0.18, 0.25, 0, 0.55])], []),
        __pan_affix("guarding", "Guarding", 3, [pan_poly([-0.15, -0.45, -0.45, -0.45, -0.45, 0.45, -0.15, 0.45]), pan_poly([0.15, -0.45, 0.45, -0.45, 0.45, 0.45, 0.15, 0.45])], []),
        __pan_affix("thorned",  "Thorned",  3, [pan_line(0, 0.55, 0, -0.55), pan_line(0, 0.15, -0.3, -0.1), pan_line(0, -0.2, 0.3, -0.45)], []),
        __pan_affix("blessed",  "Blessed",  3, [pan_line(0, -0.5, 0, 0.5), pan_line(-0.5, 0, 0.5, 0)], [0, 0]),
        __pan_affix("cursed",   "Cursed",   3, [pan_arc(0, -0.2, 0.42, 20, 160), pan_poly([0, 0.12, 0.09, 0.3, 0, 0.46, -0.09, 0.3, 0, 0.12])], []),
        __pan_affix("lucky",    "Lucky",    3, [pan_circle(0, -0.28, 0.18), pan_circle(-0.22, 0.1, 0.18), pan_circle(0.22, 0.1, 0.18)], []),
        __pan_affix("greedy",   "Greedy",   3, [pan_poly(__pan_ellipse(0, -0.15, 0.42, 0.16)), pan_poly(__pan_ellipse(0, 0.22, 0.42, 0.16))], []),
        __pan_affix("stalwart", "Stalwart", 3, [pan_line(-0.35, -0.5, 0.35, -0.5), pan_poly([-0.14, -0.5, -0.14, 0.5, 0.14, 0.5, 0.14, -0.5]), pan_line(-0.35, 0.5, 0.35, 0.5)], []),
        __pan_affix("nimble",   "Nimble",   3, [pan_spiral(0, 0.05, 0.12, 0.5, -90, 380)], []),
        __pan_affix("arcanist", "Arcanist", 3, [pan_arc(0, 0.15, 0.5, 200, 340), pan_arc(0, -0.15, 0.5, 20, 160)], [0, 0]),
        __pan_affix("leeching", "Leeching", 3, [pan_spiral(0, 0, 0.5, 0.12, -90, 270), pan_line(0, -0.5, 0, -0.62)], []),
        __pan_affix("rending",  "Rending",  3, [pan_line(-0.4, -0.45, -0.2, 0.5), pan_line(-0.05, -0.5, 0.1, 0.5), pan_line(0.3, -0.45, 0.45, 0.5)], []),
        __pan_affix("crushing", "Crushing", 3, [pan_poly([-0.3, -0.5, 0.3, -0.5, 0, 0.1, -0.3, -0.5]), pan_line(-0.5, 0.35, 0.5, 0.35)], []),
        __pan_affix("seeking",  "Seeking",  2, [pan_circle(0, 0, 0.4), pan_line(0, -0.62, 0, -0.2)], [0, 0]),
        __pan_affix("blinking", "Blinking", 2, [pan_poly([-0.45, -0.15, -0.45, -0.45, -0.15, -0.45]), pan_poly([0.45, 0.15, 0.45, 0.45, 0.15, 0.45])], [0.45, -0.45, -0.45, 0.45]),
        __pan_affix("rooted",   "Rooted",   2, [pan_line(-0.5, -0.3, 0.5, -0.3), pan_line(0, -0.3, 0, 0.55), pan_poly([-0.3, 0.5, -0.05, 0.05, 0.05, 0.05, 0.3, 0.5])], []),
        __pan_affix("soaring",  "Soaring",  2, [pan_arc(-0.25, 0.1, 0.3, 200, 340), pan_arc(0.25, 0.1, 0.3, 200, 340)], []),
        __pan_affix("tidal",    "Tidal",    2, [pan_poly(__pan_wave(-0.5, 0.5, -0.15, 0.12, 1.5)), pan_poly(__pan_wave(-0.5, 0.5, 0.2, 0.12, 1.5))], []),
        __pan_affix("stony",    "Stony",    2, [pan_poly([-0.15, -0.45, 0.35, -0.25, 0.4, 0.25, -0.05, 0.45, -0.4, 0.1, -0.15, -0.45])], []),
        __pan_affix("gilded",   "Gilded",   2, [pan_circle(0, 0.12, 0.35), pan_poly([-0.22, -0.3, -0.12, -0.5, 0, -0.32, 0.12, -0.5, 0.22, -0.3])], []),
        __pan_affix("hollow",   "Hollow",   2, [pan_arc(0, 0, 0.4, 0, 100), pan_arc(0, 0, 0.4, 120, 220), pan_arc(0, 0, 0.4, 240, 340)], []),
        __pan_affix("radiant",  "Radiant",  2, [pan_circle(0, 0, 0.25), pan_poly(__pan_star(0, 0, 0.55, 0.32, 6, -90))], []),
        __pan_affix("umbral",   "Umbral",   2, [pan_arc(0.1, 0, 0.4, 60, 300)], [0.34, 0]),
        __pan_affix("feral",    "Feral",    2, [pan_arc(0, 0.1, 0.32, 15, 165), pan_circle(0, -0.32, 0.06)], [-0.3, -0.22, 0.3, -0.22]),
        __pan_affix("patient",  "Patient",  2, [pan_poly([-0.3, -0.45, 0.3, -0.45, 0, -0.05, -0.3, -0.45]), pan_poly([-0.3, 0.45, 0.3, 0.45, 0, 0.05, -0.3, 0.45])], []),
        __pan_affix("furious",  "Furious",  2, [pan_spiral(0, 0, 0.55, 0.08, 0, 720)], []),
        __pan_affix("bound",    "Bound",    2, [pan_circle(-0.18, 0, 0.3), pan_circle(0.18, 0, 0.3)], []),
        __pan_affix("unstable", "Unstable", 2, [pan_line(0, -0.5, 0, -0.05), pan_poly([-0.5, 0.35, -0.3, 0.15, -0.1, 0.35, 0.1, 0.15, 0.3, 0.35, 0.5, 0.15])], [0, 0.5]),
        __pan_affix("eternal",  "Eternal",  2, [pan_poly(__pan_lemni(0, 0, 0.55, 0.28))], []),
    ]
    // <<< MIRROR AFFIXES
    ;
    return _tbl;
}

/// The default table bundle. panoply_bind merges a buyer's registered content over this.
function pan_tables_default() {
    return {
        bases:     pan_base_table(),
        materials: pan_material_table(),
        rarities:  pan_rarity_table(),
        affixes:   pan_affix_table(),
    };
}

/// Index of a base form by string id, or -1. Linear - the corpus is small and this keeps the
/// core free of ds_map lifetime concerns.
function pan_base_find(_tables, _id) {
    var _t = _tables.bases;
    for (var _i = 0; _i < array_length(_t); _i++) {
        if (_t[_i].id == _id) { return _i; }
    }
    return -1;
}

/// Index of an affix family by string id, or -1.
function pan_affix_find(_tables, _id) {
    var _t = _tables.affixes;
    for (var _i = 0; _i < array_length(_t); _i++) {
        if (_t[_i].id == _id) { return _i; }
    }
    return -1;
}

// ── THE DETERMINISTIC ROLL ───────────────────────────────────────────────────────────────────
// xorshift32 over the item's seed. NEVER random(): the same seed yields the same item on every
// machine, so items persist in a save as {seed, version} and re-roll losslessly on load.
// Chosen over a multiplicative hash deliberately - shifts and xors stay exact in GML's number
// model AND in the JS mirror's, so the two streams cannot diverge on precision.

/// Make a rng state from a seed. Mixed so that adjacent small seeds decorrelate.
function __pan_rng(_seed) {
    var _x = (floor(abs(_seed))) & 0xFFFFFFFF;
    _x = (_x ^ 0x9E3779B9) & 0xFFFFFFFF;
    if (_x == 0) { _x = 0x1F123BB5; }
    var _r = { s: _x };
    // three warm-up steps: seeds 1,2,3 must not produce near-identical first draws
    __pan_rng_next(_r); __pan_rng_next(_r); __pan_rng_next(_r);
    return _r;
}

/// Advance the stream, return an integer in [0, 2^32).
function __pan_rng_next(_r) {
    var _x = _r.s;
    _x = (_x ^ (_x << 13)) & 0xFFFFFFFF;
    _x = _x ^ (_x >> 17);
    _x = (_x ^ (_x << 5)) & 0xFFFFFFFF;
    _r.s = _x;
    return _x;
}

/// Integer in [0, n).
function __pan_rng_range(_r, _n) {
    return __pan_rng_next(_r) % _n;
}

/// Weighted index over an array of structs carrying `w`. `_live` marks which entries are still
/// eligible (affix picks are WITHOUT replacement - a duplicate affix on one item is forbidden).
function __pan_rng_weighted(_r, _arr, _live) {
    var _total = 0;
    var _n = array_length(_arr);
    for (var _i = 0; _i < _n; _i++) {
        if (_live[_i]) { _total += _arr[_i].w; }
    }
    var _pick = __pan_rng_range(_r, _total);
    for (var _i = 0; _i < _n; _i++) {
        if (!_live[_i]) { continue; }
        _pick -= _arr[_i].w;
        if (_pick < 0) { return _i; }
    }
    return _n - 1;   // unreachable when weights are positive; kept as a guard
}

/// Roll an item from a seed. Order is fixed and documented because it IS the save format:
/// base -> material -> rarity -> affix count -> affix picks (weighted, no duplicates).
/// Returns { seed, base, material, rarity, affixes[] } - all indices into `_tables`.
function pan_roll(_seed, _tables) {
    var _r = __pan_rng(_seed);

    var _base = __pan_rng_range(_r, array_length(_tables.bases));
    var _mat  = __pan_rng_range(_r, array_length(_tables.materials));

    // rarity: weighted over the tier table
    var _rar_live = [];
    for (var _i = 0; _i < array_length(_tables.rarities); _i++) { array_push(_rar_live, true); }
    var _rar = __pan_rng_weighted(_r, _tables.rarities, _rar_live);
    var _tier = _tables.rarities[_rar];

    // affix count within the tier's budget
    var _span = _tier.afx_max - _tier.afx_min + 1;
    var _count = _tier.afx_min + __pan_rng_range(_r, _span);

    // affix picks: weighted, without replacement
    var _afx_live = [];
    var _an = array_length(_tables.affixes);
    for (var _i = 0; _i < _an; _i++) { array_push(_afx_live, true); }
    var _affixes = [];
    for (var _i = 0; _i < _count; _i++) {
        var _pick = __pan_rng_weighted(_r, _tables.affixes, _afx_live);
        _afx_live[_pick] = false;
        array_push(_affixes, _pick);
    }

    return { seed: _seed, base: _base, material: _mat, rarity: _rar, affixes: _affixes };
}

// ── CARD COMPOSITION ─────────────────────────────────────────────────────────────────────────

/// Compose the draw plan for an item: everything panoply_render needs, and everything the
/// distinctness assertions compare. Pure data - the same item always composes the same plan.
///
/// The title is generated, ASCII, and skips an affix prefix that would repeat the material name
/// ("Umbral Umbral Sword" reads as a bug even when it is not one).
function pan_card_compose(_item, _tables) {
    var _base = _tables.bases[_item.base];
    var _mat  = _tables.materials[_item.material];
    var _tier = _tables.rarities[_item.rarity];

    // title: [first affix] [material] [base]
    var _prefix = "";
    for (var _i = 0; _i < array_length(_item.affixes); _i++) {
        var _nm = _tables.affixes[_item.affixes[_i]].name;
        if (_nm != _mat.name) { _prefix = _nm; break; }
    }
    var _title = ((_prefix != "") ? _prefix + " " : "") + _mat.name + " " + _base.name;

    // the affix track: up to PAN_TRACK_MAX glyphs, then a +n bead
    var _track = [];
    var _n = array_length(_item.affixes);
    var _shown = min(_n, PAN_TRACK_MAX);
    for (var _i = 0; _i < _shown; _i++) { array_push(_track, _item.affixes[_i]); }

    var _key = string(_item.seed) + ":" + _base.id + ":" + _mat.id + ":" + _tier.id;
    for (var _i = 0; _i < _n; _i++) {
        _key += ":" + _tables.affixes[_item.affixes[_i]].id;
    }

    return {
        key:      _key,
        title:    _title,
        base:     _item.base,
        material: _item.material,
        rarity:   _item.rarity,
        track:    _track,
        overflow: _n - _shown,
    };
}

// ── STATS + SETS: the system underneath the picture ──────────────────────────────────────────

/// Compute an item's stat block. `_mods` maps affix id -> { stat, add } (panoply_preset wires a
/// starter book; unwired affixes contribute a small flat bonus so no roll is ever statless).
/// Base stats scale by the rarity multiplier, then affix mods add on top. Deterministic.
function pan_item_stats(_item, _tables, _mods) {
    var _base = _tables.bases[_item.base];
    var _tier = _tables.rarities[_item.rarity];
    var _out = {
        might: round(_base.might * _tier.mult),
        ward:  round(_base.ward  * _tier.mult),
        grace: round(_base.grace * _tier.mult),
    };
    for (var _i = 0; _i < array_length(_item.affixes); _i++) {
        var _id = _tables.affixes[_item.affixes[_i]].id;
        if (is_struct(_mods) && variable_struct_exists(_mods, _id)) {
            var _m = variable_struct_get(_mods, _id);
            variable_struct_set(_out, _m.stat, variable_struct_get(_out, _m.stat) + _m.add);
        } else {
            _out.grace += 1;
        }
    }
    return _out;
}

/// How many of `_items` count toward a set. A set names its pieces by BASE id and binds them to
/// one MATERIAL id; an item counts once per distinct required piece it satisfies (two swords do
/// not complete a two-piece set that wants a sword and a shield).
///   _set   : { pieces: [base ids], material: "material id" }
///   _items : array of rolled items
function pan_set_progress(_set, _tables, _items) {
    var _count = 0;
    for (var _p = 0; _p < array_length(_set.pieces); _p++) {
        var _want_base = _set.pieces[_p];
        for (var _i = 0; _i < array_length(_items); _i++) {
            var _it = _items[_i];
            if (_tables.bases[_it.base].id == _want_base
                && _tables.materials[_it.material].id == _set.material) {
                _count += 1;
                break;   // one credit per required piece
            }
        }
    }
    return _count;
}
