/// ============================================================================================
/// PANOPLY - panoply_bind: the engine binding.
///
/// Everything impure lives here: the clock, the buyer's registered content, the forge's
/// animation state, the equip loadout, and the save/load round-trip. panoply_core stays a pure
/// function library so it can be mirrored and reasoned about; this file is where Panoply meets
/// a running game.
///
/// ⛔ THE delta_time CONVERSION HAPPENS IN EXACTLY ONE PLACE - `__pan_dt()`.
///   GameMaker's delta_time is MICROSECONDS. Dividing by 1000 instead of 1,000,000 yields
///   animations that run 1000x fast, which reads as "the effect just pops" rather than as a
///   bug. This wing has hit that trap before. One conversion, one place, never inline.
///
/// SAVE FORMAT - versioned from day one, and tiny by design.
///   An item persists as { v, seed }: the roll is a pure function of the seed, so the seed IS
///   the item. A save cannot rot when you rebalance stats or add affixes - the item re-rolls
///   against the tables that exist at load time. If you APPEND content (the supported path),
///   old seeds keep their identity for base/material/rarity because those draws happen before
///   the affix picks; if you REORDER or REMOVE corpus entries between builds, rolled items
///   change - append, never reorder, is the compatibility contract and it is stated in the
///   Readme.
///
/// Public API:
///   pan_registry_create()                       -> a content registry (buyer's own additions)
///   pan_registry_add_base(reg, base)            -> register a custom base form
///   pan_registry_add_affix(reg, affix)          -> register a custom affix family
///   pan_registry_add_set(reg, set_def)          -> register a set definition
///   pan_tables(reg)                             -> merged corpus + custom tables (cached)
///   pan_forge_create()                          -> forge state for the reveal animation
///   pan_forge_roll(forge, reg, seed)            -> roll an item, start the reveal
///   pan_forge_step(forge)                       -> advance the reveal (call once per step)
///   pan_loadout_create()                        -> an equip loadout
///   pan_loadout_equip(lo, item)                 -> equip an item
///   pan_loadout_clear(lo)                       -> unequip everything
///   pan_loadout_sets(lo, reg)                   -> per-set progress over equipped items
///   pan_item_pack(item) / pan_item_unpack(reg, data)
///   pan_loadout_pack(lo) / pan_loadout_unpack(reg, data)
/// ============================================================================================

/// The ONLY microseconds -> seconds conversion in Panoply.
function __pan_dt() {
    return delta_time / 1000000;
}

// ── the registry: the buyer's content, merged over the corpus ────────────────────────────────

function pan_registry_create() {
    return {
        bases:   [],
        affixes: [],
        sets:    [],
        _cache:  undefined,   // merged tables, invalidated by every add
    };
}

/// Register a custom base form (build it with __pan_base / pan_line / pan_arc / pan_poly - the
/// same constructors the corpus uses). It rolls, renders and titles exactly like a shipped one.
function pan_registry_add_base(_reg, _base) {
    array_push(_reg.bases, _base);
    _reg._cache = undefined;
}

/// Register a custom affix family. Its glyph appears on card tracks like any shipped affix.
function pan_registry_add_affix(_reg, _affix) {
    array_push(_reg.affixes, _affix);
    _reg._cache = undefined;
}

/// Register a set definition: { id, name, material: "material id", pieces: [base ids],
/// bonuses: [{ need, text }] }.
function pan_registry_add_set(_reg, _set) {
    array_push(_reg.sets, _set);
    _reg._cache = undefined;
}

/// The merged tables the roll and the renderer consume: corpus first, then the buyer's
/// registrations APPENDED (append-only is the save-compatibility contract - see header).
function pan_tables(_reg) {
    if (_reg._cache != undefined) { return _reg._cache; }
    var _d = pan_tables_default();
    var _bases = [];
    for (var _i = 0; _i < array_length(_d.bases); _i++)   { array_push(_bases, _d.bases[_i]); }
    for (var _i = 0; _i < array_length(_reg.bases); _i++) { array_push(_bases, _reg.bases[_i]); }
    var _affixes = [];
    for (var _i = 0; _i < array_length(_d.affixes); _i++)   { array_push(_affixes, _d.affixes[_i]); }
    for (var _i = 0; _i < array_length(_reg.affixes); _i++) { array_push(_affixes, _reg.affixes[_i]); }
    _reg._cache = {
        bases:     _bases,
        materials: _d.materials,
        rarities:  _d.rarities,
        affixes:   _affixes,
    };
    return _reg._cache;
}

// ── the forge: roll + reveal animation ───────────────────────────────────────────────────────

function pan_forge_create() {
    return {
        item:    undefined,
        plan:    undefined,
        anim_t:  0,        // 0..1 reveal, fed to pan_draw_card's _t
        anim_on: false,
    };
}

/// Roll an item from a seed and start the card's forge reveal from zero.
function pan_forge_roll(_forge, _reg, _seed) {
    var _tables = pan_tables(_reg);
    _forge.item    = pan_roll(_seed, _tables);
    _forge.plan    = pan_card_compose(_forge.item, _tables);
    _forge.anim_t  = 0;
    _forge.anim_on = true;
    return _forge.item;
}

/// Advance the reveal. Call once per step from the buyer's controller.
function pan_forge_step(_forge) {
    if (!_forge.anim_on) { return; }
    _forge.anim_t += __pan_dt() / 1.8;       // a full forge reveal takes 1.8 seconds
    if (_forge.anim_t >= 1) {
        _forge.anim_t  = 1;
        _forge.anim_on = false;
    }
}

// ── the loadout: equipped items + set detection ──────────────────────────────────────────────

function pan_loadout_create() {
    return { items: [] };
}

function pan_loadout_equip(_lo, _item) {
    array_push(_lo.items, _item);
}

function pan_loadout_clear(_lo) {
    _lo.items = [];
}

/// Per-set progress over the equipped items. Returns an array of
/// { set, count, active: [bonus texts whose `need` is met] }.
function pan_loadout_sets(_lo, _reg) {
    var _tables = pan_tables(_reg);
    var _out = [];
    for (var _i = 0; _i < array_length(_reg.sets); _i++) {
        var _s = _reg.sets[_i];
        var _count = pan_set_progress(_s, _tables, _lo.items);
        var _active = [];
        for (var _b = 0; _b < array_length(_s.bonuses); _b++) {
            if (_count >= _s.bonuses[_b].need) { array_push(_active, _s.bonuses[_b].text); }
        }
        array_push(_out, { set: _s, count: _count, active: _active });
    }
    return _out;
}

// ── persistence ──────────────────────────────────────────────────────────────────────────────

/// Pack one item for a save file. The seed IS the item (see header).
function pan_item_pack(_item) {
    return { v: PAN_VERSION, seed: _item.seed };
}

/// Re-roll a packed item against the current tables. Returns the item, or undefined if the
/// data is not a packed item.
function pan_item_unpack(_reg, _data) {
    if (!is_struct(_data) || !variable_struct_exists(_data, "seed")) { return undefined; }
    return pan_roll(variable_struct_get(_data, "seed"), pan_tables(_reg));
}

/// Pack a whole loadout.
function pan_loadout_pack(_lo) {
    var _items = [];
    for (var _i = 0; _i < array_length(_lo.items); _i++) {
        array_push(_items, pan_item_pack(_lo.items[_i]));
    }
    return { v: PAN_VERSION, items: _items };
}

/// Unpack a loadout. Entries that fail to unpack are skipped rather than crashing a load.
function pan_loadout_unpack(_reg, _data) {
    var _lo = pan_loadout_create();
    if (!is_struct(_data) || !variable_struct_exists(_data, "items")) { return _lo; }
    var _arr = variable_struct_get(_data, "items");
    for (var _i = 0; _i < array_length(_arr); _i++) {
        var _it = pan_item_unpack(_reg, _arr[_i]);
        if (_it != undefined) { pan_loadout_equip(_lo, _it); }
    }
    return _lo;
}
