/// ============================================================================================
/// PANOPLY - panoply_render: the draw layer.
///
/// ONE renderer draws every mark in the product: a base silhouette, an affix glyph and a full
/// item card all route through pan_draw_glyph / pan_draw_card, so 30 bases, 40 affixes and 900
/// variants read as one product instead of a thousand doodles.
///
/// NO SPRITES. Nothing here reads a sprite, a texture page or an atlas. Every mark is stroked
/// from primitives at draw time, which is why a buyer can recolour, rescale and generate cards
/// for items that did not exist when the product shipped - a rolled item's card is drawn from
/// its data, never looked up in art.
///
/// BLEND-STATE HYGIENE - the rule this wing does not break.
///   Every public draw here SAVES and RESTORES blend mode, colour, alpha and text alignment.
///   A renderer that leaks bm_add into a buyer's pipeline produces a bug they will report as
///   "your asset broke my game's lighting", and you cannot debug it remotely. Every function
///   below is safe to call from anywhere in a buyer's draw event, in any order.
///
/// TEXT: pan_draw_card renders the item title and the +n overflow bead with WHATEVER FONT IS
/// CURRENTLY SET - set your font before calling (the demo sets fnt_panoply). The renderer never
/// calls draw_set_font because fonts are resources and this layer holds no resource ids.
///
/// Public API:
///   pan_colour(rgb)                                   -> GameMaker colour from {r,g,b}
///   pan_draw_polyline(pts, x, y, size, w)             -> one unit-space polyline
///   pan_draw_polyline_partial(pts, x, y, size, w, t)  -> the first t (0..1) of a polyline
///   pan_draw_glyph(glyph, x, y, size, mat, alpha, t)  -> any PanGlyph, staged reveal at t<1
///   pan_draw_card(plan, tables, x, y, h, time, alpha, t) -> the full item card
///   pan_draw_panel(x1, y1, x2, y2, fill, edge, alpha) -> chrome panel (tooltips, lists)
/// ============================================================================================

/// GameMaker packs colour as BGR, which is exactly the kind of detail that belongs in the
/// render layer and nowhere else - panoply_core stays free of colour built-ins for that reason.
function pan_colour(_rgb) {
    return make_colour_rgb(_rgb.r, _rgb.g, _rgb.b);
}

/// Draw a flat [x0,y0,x1,y1,...] polyline in UNIT SPACE, mapped to a box of `_size` at `_x,_y`.
function pan_draw_polyline(_pts, _x, _y, _size, _w) {
    var _n = array_length(_pts);
    if (_n < 4) { return; }
    var _h = _size * 0.5;
    for (var _i = 0; _i < _n - 2; _i += 2) {
        draw_line_width(
            _x + _pts[_i]     * _h, _y + _pts[_i + 1] * _h,
            _x + _pts[_i + 2] * _h, _y + _pts[_i + 3] * _h,
            _w);
    }
}

/// Draw only the first `_t` (0..1) of a polyline - the stroke-in of the forge animation.
/// The partial final segment is interpolated so the line END moves smoothly, not per-vertex.
function pan_draw_polyline_partial(_pts, _x, _y, _size, _w, _t) {
    var _n = array_length(_pts);
    if (_n < 4) { return; }
    var _t01 = clamp(_t, 0, 1);
    if (_t01 >= 1) { pan_draw_polyline(_pts, _x, _y, _size, _w); return; }
    var _segs = (_n - 2) / 2;
    var _reach = _segs * _t01;
    var _full = floor(_reach);
    var _frac = _reach - _full;
    var _h = _size * 0.5;
    for (var _i = 0; _i < _full; _i++) {
        var _j = _i * 2;
        draw_line_width(
            _x + _pts[_j]     * _h, _y + _pts[_j + 1] * _h,
            _x + _pts[_j + 2] * _h, _y + _pts[_j + 3] * _h,
            _w);
    }
    if (_frac > 0 && _full < _segs) {
        var _j = _full * 2;
        var _ex = lerp(_pts[_j],     _pts[_j + 2], _frac);
        var _ey = lerp(_pts[_j + 1], _pts[_j + 3], _frac);
        draw_line_width(_x + _pts[_j] * _h, _y + _pts[_j + 1] * _h,
                        _x + _ex * _h, _y + _ey * _h, _w);
    }
}

/// Draw one PanGlyph centred at (_x,_y) inside a box of _size px, in material _mat.
///
/// Four passes, by palette ROLE - which is what makes six materials read as six METALS rather
/// than six hues:
///   1. GLOW  - wide, additive, scaled by the material's glow_amt (iron carries none).
///   2. BODY  - a broad soft under-stroke that gives the mark physical weight.
///   3. EDGE  - the mark itself at full weight.
///   4. DETAIL- accent points as bright pips, additive.
/// `_t` stages the reveal: strokes draw in over 0..0.7, accents pop after 0.7. Pass 1 for the
/// finished mark.
function pan_draw_glyph(_glyph, _x, _y, _size, _mat, _alpha, _t) {
    // -- save GPU state --
    var _old_blend = gpu_get_blendmode();
    var _old_col   = draw_get_colour();
    var _old_alpha = draw_get_alpha();

    var _t01    = clamp(_t, 0, 1);
    var _lines  = pan_glyph_flatten(_glyph);
    var _n      = array_length(_lines);
    var _wCore  = max(1, _size * 0.032);
    var _wBody  = max(2, _size * 0.070);
    var _wGlow  = max(3, _size * 0.110);
    var _strokeT = (_t01 >= 1) ? 1 : clamp(_t01 / 0.7, 0, 1);

    // strokes reveal one after another: stroke i owns its slice of _strokeT
    var _per = 1 / max(1, _n);

    // 1. glow
    if (_mat.glow_amt > 0) {
        gpu_set_blendmode(bm_add);
        draw_set_colour(pan_colour(_mat.glow));
        draw_set_alpha(_alpha * 0.22 * _mat.glow_amt);
        for (var _i = 0; _i < _n; _i++) {
            var _st = clamp((_strokeT - _i * _per) / _per, 0, 1);
            if (_st > 0) { pan_draw_polyline_partial(_lines[_i], _x, _y, _size, _wGlow, _st); }
        }
    }

    // 2. body under-stroke
    gpu_set_blendmode(bm_normal);
    draw_set_colour(pan_colour(_mat.body));
    draw_set_alpha(_alpha * 0.55);
    for (var _i = 0; _i < _n; _i++) {
        var _st = clamp((_strokeT - _i * _per) / _per, 0, 1);
        if (_st > 0) { pan_draw_polyline_partial(_lines[_i], _x, _y, _size, _wBody, _st); }
    }

    // 3. edge
    draw_set_colour(pan_colour(_mat.edge));
    draw_set_alpha(_alpha);
    for (var _i = 0; _i < _n; _i++) {
        var _st = clamp((_strokeT - _i * _per) / _per, 0, 1);
        if (_st > 0) { pan_draw_polyline_partial(_lines[_i], _x, _y, _size, _wCore, _st); }
    }

    // 4. detail pips - after the strokes have landed
    var _acc = _glyph.accents;
    var _an  = array_length(_acc);
    if (_an >= 2 && _t01 > 0.7) {
        var _pt = clamp((_t01 - 0.7) / 0.3, 0, 1);
        gpu_set_blendmode(bm_add);
        draw_set_colour(pan_colour(_mat.detail));
        draw_set_alpha(_alpha * _pt);
        var _r = max(1.5, _size * 0.038) * (1.6 - 0.6 * _pt);   // pips settle as they land
        var _h = _size * 0.5;
        for (var _i = 0; _i < _an - 1; _i += 2) {
            draw_circle(_x + _acc[_i] * _h, _y + _acc[_i + 1] * _h, _r, false);
        }
    }

    // -- restore GPU state --
    gpu_set_blendmode(_old_blend);
    draw_set_colour(_old_col);
    draw_set_alpha(_old_alpha);
}

/// Chrome panel: fill, edge, and four corner ticks. The product's UI language - used by the
/// demo for lists and tooltips, and offered to buyers so their loot UI matches their cards.
function pan_draw_panel(_x1, _y1, _x2, _y2, _fill, _edge, _alpha) {
    var _old_col   = draw_get_colour();
    var _old_alpha = draw_get_alpha();

    draw_set_colour(pan_colour(_fill));
    draw_set_alpha(_alpha);
    draw_rectangle(_x1, _y1, _x2, _y2, false);
    draw_set_colour(pan_colour(_edge));
    draw_set_alpha(_alpha * 0.9);
    draw_rectangle(_x1, _y1, _x2, _y2, true);
    var _tick = min(10, (_x2 - _x1) * 0.08);
    draw_line_width(_x1, _y1, _x1 + _tick, _y1, 2);
    draw_line_width(_x1, _y1, _x1, _y1 + _tick, 2);
    draw_line_width(_x2, _y1, _x2 - _tick, _y1, 2);
    draw_line_width(_x2, _y1, _x2, _y1 + _tick, 2);
    draw_line_width(_x1, _y2, _x1 + _tick, _y2, 2);
    draw_line_width(_x1, _y2, _x1, _y2 - _tick, 2);
    draw_line_width(_x2, _y2, _x2 - _tick, _y2, 2);
    draw_line_width(_x2, _y2, _x2, _y2 - _tick, 2);

    draw_set_colour(_old_col);
    draw_set_alpha(_old_alpha);
}

/// Draw the full item card from a compose plan. `_h` is the card height; width is 0.72 * h.
///
/// Five passes, per the card grammar in Motif_Corpus.md: plate -> silhouette -> material ->
/// affix track -> rarity treatment. `_time` drives the living treatments (epic's orbiting
/// motes, mythic's breathing aura) and `_t` is the forge reveal:
///   0.00-0.10  plate fades in
///   0.05-0.45  silhouette strokes in
///   0.45-0.60  material floods (body + glow ramp to full)
///   0.55-0.85  affix glyphs stamp onto the track one at a time
///   0.85-1.00  rarity frame + aura ignite
/// Pass _t = 1 for the finished card. Text (title, +n bead) uses the CALLER'S current font.
function pan_draw_card(_plan, _tables, _x, _y, _h, _time, _alpha, _t) {
    // -- save state (including text alignment: the title pass sets it) --
    var _old_blend  = gpu_get_blendmode();
    var _old_col    = draw_get_colour();
    var _old_alpha  = draw_get_alpha();
    var _old_halign = draw_get_halign();
    var _old_valign = draw_get_valign();

    var _t01  = clamp(_t, 0, 1);
    var _w    = _h * 0.72;
    var _x1   = _x - _w * 0.5;
    var _y1   = _y - _h * 0.5;
    var _x2   = _x + _w * 0.5;
    var _y2   = _y + _h * 0.5;
    var _mat  = _tables.materials[_plan.material];
    var _tier = _tables.rarities[_plan.rarity];
    var _rad  = _h * 0.045;

    // -- 1. plate --
    var _plateA = _alpha * clamp(_t01 / 0.10, 0, 1);
    draw_set_colour(pan_colour({ r: 16, g: 18, b: 24 }));
    draw_set_alpha(_plateA);
    draw_roundrect_ext(_x1, _y1, _x2, _y2, _rad, _rad, false);
    // material body tints the plate ground - the "flood" ramps it up mid-reveal
    var _flood = (_t01 >= 1) ? 1 : clamp((_t01 - 0.45) / 0.15, 0, 1);
    draw_set_colour(pan_colour(_mat.body));
    draw_set_alpha(_plateA * (0.10 + 0.14 * _flood));
    draw_roundrect_ext(_x1, _y1, _x2, _y2, _rad, _rad, false);

    // -- 2 + 3. silhouette (reveal 0.05-0.45; material passes scale with the flood) --
    var _silT = (_t01 >= 1) ? 1 : clamp((_t01 - 0.05) / 0.40, 0, 1);
    var _base = _tables.bases[_plan.base];
    var _silSize = _h * 0.52;
    var _silY = _y1 + _h * 0.40;
    if (_silT > 0) {
        pan_draw_glyph(_base, _x, _silY, _silSize, _mat, _alpha * (0.45 + 0.55 * _flood), _silT);
    }

    // -- 4. the affix track (reveal 0.55-0.85, one stamp per glyph) --
    var _tn = array_length(_plan.track);
    if (_tn > 0 || _plan.overflow > 0) {
        var _trackY = _y1 + _h * 0.80;
        // rail
        var _railT = (_t01 >= 1) ? 1 : clamp((_t01 - 0.55) / 0.10, 0, 1);
        if (_railT > 0) {
            draw_set_colour(pan_colour(_mat.edge));
            draw_set_alpha(_alpha * 0.35 * _railT);
            draw_line_width(_x1 + _w * 0.10, _trackY, _x1 + _w * 0.10 + _w * 0.80 * _railT, _trackY, 1);
        }
        var _slots = _tn + ((_plan.overflow > 0) ? 1 : 0);
        var _gsize = min(_h * 0.115, _w * 0.80 / max(1, _slots));
        for (var _i = 0; _i < _tn; _i++) {
            var _gt = (_t01 >= 1) ? 1 : clamp((_t01 - 0.55 - _i * (0.30 / max(1, _tn))) / 0.08, 0, 1);
            if (_gt <= 0) { continue; }
            var _gx = _x + (_i - (_slots - 1) * 0.5) * _gsize * 1.15;
            // stamp: pops in slightly large, settles
            var _gs = _gsize * (1.35 - 0.35 * _gt);
            pan_draw_glyph(_tables.affixes[_plan.track[_i]], _gx, _trackY, _gs, _mat, _alpha * _gt, 1);
        }
        if (_plan.overflow > 0 && _t01 > 0.85) {
            var _bx = _x + (_tn - (_slots - 1) * 0.5) * _gsize * 1.15;
            draw_set_colour(pan_colour(_mat.detail));
            draw_set_alpha(_alpha * 0.9);
            draw_circle(_bx, _trackY, _gsize * 0.34, true);
            draw_set_halign(fa_center);
            draw_set_valign(fa_middle);
            draw_text_transformed(_bx, _trackY, "+" + string(_plan.overflow),
                _gsize / 52, _gsize / 52, 0);
        }
    }

    // -- 5. rarity treatment: frame + aura (ignite 0.85-1.00) --
    var _igniteT = (_t01 >= 1) ? 1 : clamp((_t01 - 0.85) / 0.15, 0, 1);
    var _fc = pan_colour(_tier.frame);
    // base frame is always present once the plate exists
    draw_set_colour(_fc);
    draw_set_alpha(_plateA * (0.35 + 0.65 * _igniteT));
    draw_roundrect_ext(_x1, _y1, _x2, _y2, _rad, _rad, true);

    if (_igniteT > 0) {
        switch (_tier.id) {
            case "uncommon": {
                // edge-light on two sides + a corner tick
                draw_set_alpha(_alpha * _igniteT * 0.9);
                draw_line_width(_x1, _y1 + _rad, _x1, _y2 - _rad, 2);
                draw_line_width(_x1 + _rad, _y1, _x2 - _rad, _y1, 2);
                draw_line_width(_x2 - _h * 0.06, _y1, _x2, _y1 + _h * 0.06 * 0.72, 2);
            } break;

            case "rare": {
                // four corner flares, frame doubled at the corners
                draw_set_alpha(_alpha * _igniteT * 0.9);
                var _fl = _h * 0.07;
                draw_line_width(_x1 - _fl * 0.5, _y1 - _fl * 0.5, _x1 + _fl, _y1 + _fl, 2);
                draw_line_width(_x2 + _fl * 0.5, _y1 - _fl * 0.5, _x2 - _fl, _y1 + _fl, 2);
                draw_line_width(_x1 - _fl * 0.5, _y2 + _fl * 0.5, _x1 + _fl, _y2 - _fl, 2);
                draw_line_width(_x2 + _fl * 0.5, _y2 + _fl * 0.5, _x2 - _fl, _y2 - _fl, 2);
            } break;

            case "epic": {
                // three motes orbiting the silhouette on an elliptical path
                gpu_set_blendmode(bm_add);
                draw_set_alpha(_alpha * _igniteT);
                for (var _i = 0; _i < 3; _i++) {
                    var _a = degtorad(_time * 70 + _i * 120);
                    var _mx = _x + cos(_a) * _w * 0.40;
                    var _my = _silY + sin(_a) * _h * 0.24;
                    draw_circle(_mx, _my, _h * 0.014, false);
                    draw_set_alpha(_alpha * _igniteT * 0.35);
                    draw_circle(_mx, _my, _h * 0.032, false);
                    draw_set_alpha(_alpha * _igniteT);
                }
                gpu_set_blendmode(bm_normal);
            } break;

            case "mythic": {
                // full ring aura behind the silhouette: a wide soft pass + a thin bright pass.
                // (One mid-width pass at half alpha measured DULL on the rarity page - it read
                // as a brown hoop, not an ignition. Found by looking, 2026-08-17.)
                gpu_set_blendmode(bm_add);
                var _pulse = 0.75 + 0.25 * sin(_time * 2.2);
                var _steps = 40;
                var _rr = _h * 0.25;   // 0.30 measured: the ring's lower arc cut through the title
                for (var _i = 0; _i < _steps; _i++) {
                    var _a0 = degtorad((360 / _steps) * _i);
                    var _a1 = degtorad((360 / _steps) * (_i + 1));
                    var _ax0 = _x + cos(_a0) * _rr;  var _ay0 = _silY + sin(_a0) * _rr;
                    var _ax1 = _x + cos(_a1) * _rr;  var _ay1 = _silY + sin(_a1) * _rr;
                    draw_set_alpha(_alpha * _igniteT * 0.30 * _pulse);
                    draw_line_width(_ax0, _ay0, _ax1, _ay1, max(4, _h * 0.030));
                    draw_set_alpha(_alpha * _igniteT * 0.95 * _pulse);
                    draw_line_width(_ax0, _ay0, _ax1, _ay1, max(1, _h * 0.006));
                }
                gpu_set_blendmode(bm_normal);
                // crown mark above the plate: baseline + three peaks, drawn SOLID (the additive
                // version rendered as two disconnected carets - found by looking, 2026-08-17)
                draw_set_alpha(_alpha * _igniteT);
                var _cw = _w * 0.16;
                var _cy = _y1 - _h * 0.030;
                var _pk = _h * 0.045;
                draw_line_width(_x - _cw, _cy, _x - _cw, _cy - _pk * 0.55, 2);
                draw_line_width(_x - _cw, _cy - _pk * 0.55, _x - _cw * 0.5, _cy, 2);
                draw_line_width(_x - _cw * 0.5, _cy, _x, _cy - _pk, 2);
                draw_line_width(_x, _cy - _pk, _x + _cw * 0.5, _cy, 2);
                draw_line_width(_x + _cw * 0.5, _cy, _x + _cw, _cy - _pk * 0.55, 2);
                draw_line_width(_x + _cw, _cy - _pk * 0.55, _x + _cw, _cy, 2);
                draw_line_width(_x - _cw, _cy, _x + _cw, _cy, 3);
                // frame fully lit: a second, inset outline
                draw_set_alpha(_alpha * _igniteT * 0.8);
                draw_roundrect_ext(_x1 + 2, _y1 + 2, _x2 - 2, _y2 - 2, _rad, _rad, true);
            } break;
        }
    }

    // -- title, in the caller's font. Suppressed on small cards: below ~180 px the title and
    // rarity rows collide into a smudge (measured at 168 on the sets page; the armory wall is
    // the extreme case) --
    if (_t01 > 0.5 && _h >= 180) {
        var _titleA = (_t01 >= 1) ? 1 : clamp((_t01 - 0.5) / 0.3, 0, 1);
        draw_set_halign(fa_center);
        draw_set_valign(fa_middle);
        draw_set_colour(pan_colour(_mat.detail));
        draw_set_alpha(_alpha * _titleA);
        var _ts = min(1, _w * 0.92 / max(1, string_width(_plan.title)));
        draw_text_transformed(_x, _y1 + _h * 0.685, _plan.title, _ts, _ts, 0);
        draw_set_colour(_fc);
        draw_set_alpha(_alpha * _titleA * 0.9);
        var _rn = _tables.rarities[_plan.rarity].name;
        var _rs = min(0.8, _w * 0.5 / max(1, string_width(_rn)));
        draw_text_transformed(_x, _y1 + _h * 0.735, _rn, _rs, _rs, 0);
    }

    // -- restore state --
    gpu_set_blendmode(_old_blend);
    draw_set_colour(_old_col);
    draw_set_alpha(_old_alpha);
    draw_set_halign(_old_halign);
    draw_set_valign(_old_valign);
}
