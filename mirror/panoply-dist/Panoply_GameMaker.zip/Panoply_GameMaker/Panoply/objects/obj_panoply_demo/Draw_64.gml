/// PANOPLY demo - Draw GUI.  DEMO SCAFFOLDING, NOT PRODUCT.
/// Every mark on screen is drawn by panoply_render from panoply_core data. No sprites anywhere.

var _W = display_get_gui_width();
var _H = display_get_gui_height();
var _th = theme;

// --- background + chrome (custom, deliberately nothing like stock GameMaker) -----------------
draw_set_colour(pan_colour(_th.bg));
draw_set_alpha(1);
draw_rectangle(0, 0, _W, _H, false);

draw_set_font(fnt_panoply_title);
draw_set_colour(pan_colour(_th.text));
draw_set_halign(fa_left);
draw_set_valign(fa_top);

var _titles = ["THE ARMORY", "THE FORGE", "THE AFFIX CORPUS", "RARITY", "SETS"];
var _subs = [
    "30 base forms x 6 materials x 5 rarities = 900 variants. Every card drawn from its data - no icon pack, no PNG.",
    "A roll becomes a card: the silhouette strokes in, the material floods, affixes stamp, the rarity ignites.",
    "40 hand-authored affix families. Each mark is 1-3 strokes, legible at track scale.",
    "The same roll at all five tiers. The treatment is drawn, not swapped art.",
    "Sets detect over equipped items. Pieces arrive; bonuses light as thresholds are met.",
];
draw_text(_th.pad, _th.pad - 6, _titles[page]);

draw_set_font(fnt_panoply);
draw_set_colour(pan_colour(_th.text_dim));
draw_text(_th.pad, _th.pad + 30, _subs[page]);

draw_set_colour(pan_colour(_th.rule));
draw_line(_th.pad, _th.pad + 58, _W - _th.pad, _th.pad + 58);

var _top = _th.pad + 82;

switch (page) {

// -- 0 - ARMORY: the volume shot ---------------------------------------------------------------
case 0: {
    var _cols = 15;
    var _rows = 6;
    var _cw   = (_W - _th.pad * 2) / _cols;
    var _chh  = (_H - _top - _th.pad * 0.6) / _rows;
    var _ch   = min(_chh * 0.94, _cw * 0.94 / 0.72);
    var _shift = floor(sim_t * 0.35);              // the wall slides through all 30 bases
    for (var _r = 0; _r < _rows; _r++) {
        for (var _c = 0; _c < _cols; _c++) {
            var _b = (_c + _shift) % 30;
            pan_draw_card(armory_plans[_r * 30 + _b], tables,
                _th.pad + _cw * (_c + 0.5),
                _top + _chh * (_r + 0.5),
                _ch, sim_t, 1, 1);
        }
    }
} break;

// -- 1 - FORGE: the money shot -----------------------------------------------------------------
case 1: {
    var _cx = _W * 0.33;
    var _cy = _top + (_H - _th.pad - _top) * 0.5;
    var _ch = 430;
    pan_draw_card(forge.plan, tables, _cx, _cy, _ch, sim_t, 1, forge.anim_t);

    // the readout panel: the SYSTEM under the picture
    var _px = _W * 0.56;
    var _py = _top + 10;
    var _pw = _W - _th.pad - _px;
    var _ph = _H - _th.pad - _py;
    pan_draw_panel(_px, _py, _px + _pw, _py + _ph, _th.panel, _th.rule, 1);

    var _item = forge.item;
    var _mat  = tables.materials[_item.material];
    var _tier = tables.rarities[_item.rarity];
    var _base = tables.bases[_item.base];
    var _lx   = _px + 22;
    var _ly   = _py + 18;

    // the readout arrives WITH the forge, not before it - a fully-described item beside an
    // empty plate read as broken (found by looking at a mid-reveal capture, 2026-08-17)
    var _pa = clamp((forge.anim_t - 0.15) / 0.55, 0, 1);
    draw_set_alpha(_pa);

    draw_set_font(fnt_panoply_title);
    draw_set_colour(pan_colour(_mat.detail));
    draw_text(_lx, _ly, forge.plan.title);
    _ly += 40;

    draw_set_font(fnt_panoply);
    draw_set_colour(pan_colour(_tier.frame));
    draw_text(_lx, _ly, _tier.name + " " + _base.kind + "  -  seed " + string(_item.seed));
    _ly += 34;

    // stat bars: might / ward / grace
    var _st = pan_item_stats(_item, tables, mods);
    var _names = ["might", "ward", "grace"];
    var _vals  = [_st.might, _st.ward, _st.grace];
    var _barW  = _pw - 150;
    for (var _i = 0; _i < 3; _i++) {
        draw_set_colour(pan_colour(_th.text_dim));
        draw_text(_lx, _ly, _names[_i]);
        draw_set_colour(pan_colour(_th.rule));
        draw_rectangle(_lx + 70, _ly + 5, _lx + 70 + _barW, _ly + 13, false);
        draw_set_colour(pan_colour(_mat.edge));
        draw_rectangle(_lx + 70, _ly + 5, _lx + 70 + _barW * clamp(_vals[_i] / 40, 0, 1), _ly + 13, false);
        draw_set_colour(pan_colour(_th.text));
        draw_text(_lx + 78 + _barW, _ly, string(_vals[_i]));
        _ly += 26;
    }
    _ly += 12;

    // the affix list: glyph + name + wired mod (or the fallback)
    for (var _i = 0; _i < array_length(_item.affixes); _i++) {
        var _ai = _item.affixes[_i];
        var _af = tables.affixes[_ai];
        pan_draw_glyph(_af, _lx + 14, _ly + 11, 26, _mat, _pa, 1);
        draw_set_colour(pan_colour(_th.text));
        draw_text(_lx + 36, _ly, _af.name);
        draw_set_colour(pan_colour(_th.text_dim));
        var _mtext = "+1 grace";
        if (variable_struct_exists(mods, _af.id)) {
            var _m = variable_struct_get(mods, _af.id);
            _mtext = "+" + string(_m.add) + " " + _m.stat;
        }
        draw_text(_lx + 190, _ly, _mtext);
        _ly += 30;
    }

    // previous rolls, newest first - every one a different card, drawn from its own data.
    // History does NOT fade with the new item's reveal - restore full alpha first.
    draw_set_alpha(1);
    var _hy = _py + _ph - 140;
    draw_set_colour(pan_colour(_th.text_dim));
    if (array_length(roll_history) > 0) {
        draw_text(_lx, _hy - 22, "previous rolls - a seed always draws the same card");
        for (var _i = 0; _i < array_length(roll_history); _i++) {
            pan_draw_card(roll_history[_i], tables,
                _lx + 48 + _i * 106, _hy + 62, 112, sim_t, 1 - _i * 0.16, 1);
        }
    } else {
        draw_text(_lx, _py + _ph - 34, "deterministic: this seed always draws this card");
    }
} break;

// -- 2 - AFFIXES: the 40-glyph corpus ----------------------------------------------------------
case 2: {
    var _cols = 8;
    var _rows = 5;
    var _cw   = (_W - _th.pad * 2) / _cols;
    var _chh  = (_H - _top - _th.pad * 0.6) / _rows;
    var _size = min(_cw, _chh) * 0.52;
    for (var _i = 0; _i < 40; _i++) {
        var _c = _i % _cols;
        var _r = _i div _cols;
        var _gx = _th.pad + _cw * (_c + 0.5);
        var _gy = _top + _chh * (_r + 0.42);
        pan_draw_glyph(tables.affixes[_i], _gx, _gy, _size,
            tables.materials[affix_row_mats[_r]], 1, 1);
        draw_set_halign(fa_center);
        draw_set_colour(pan_colour(_th.text_dim));
        draw_text(_gx, _gy + _chh * 0.34, tables.affixes[_i].name);
        draw_set_halign(fa_left);
    }
} break;

// -- 3 - RARITY: one roll, five tiers ----------------------------------------------------------
case 3: {
    var _cw = (_W - _th.pad * 2) / 5;
    var _ch = min((_H - _top - _th.pad) * 0.80, _cw * 0.97 / 0.72);
    var _cy = _top + (_H - _th.pad - _top) * 0.44;
    for (var _r = 0; _r < 5; _r++) {
        var _cx = _th.pad + _cw * (_r + 0.5);
        pan_draw_card(rarity_plans[_r], tables, _cx, _cy, _ch, sim_t, 1, 1);
        // the tier's numbers: drop odds and the stat multiplier - the system, stated plainly
        var _tier = tables.rarities[_r];
        draw_set_halign(fa_center);
        draw_set_colour(pan_colour(_th.text_dim));
        draw_text(_cx, _cy + _ch * 0.56 + 14, string(_tier.w) + "% of rolls");
        draw_text(_cx, _cy + _ch * 0.56 + 38, string(_tier.afx_min) + "-" + string(_tier.afx_max)
            + " affixes  -  stats x" + string(_tier.mult));
        draw_set_halign(fa_left);
    }
} break;

// -- 4 - SETS: detection lighting up -----------------------------------------------------------
case 4: {
    var _n = array_length(set_defs);
    var _cw = (_W - _th.pad * 2) / _n;
    for (var _s = 0; _s < _n; _s++) {
        var _def   = set_defs[_s];
        var _plans = set_plans[_s];
        var _pn    = array_length(_plans);
        var _x1    = _th.pad + _cw * _s + 8;
        var _x2    = _th.pad + _cw * (_s + 1) - 8;
        pan_draw_panel(_x1, _top, _x2, _H - _th.pad, _th.panel, _th.rule, 1);

        // pieces equip over time, staggered per set so the three columns breathe out of phase
        var _equipped = (floor(sim_t * 0.5 + _s * 0.7)) % (_pn + 1);

        draw_set_font(fnt_panoply_title);
        draw_set_colour(pan_colour(_th.text));
        draw_text(_x1 + 16, _top + 12, _def.name);
        draw_set_font(fnt_panoply);
        draw_set_colour(pan_colour(_th.text_dim));
        draw_text(_x1 + 16, _top + 46, string(_equipped) + " / " + string(_pn) + " equipped - " + _def.material);

        // the pieces, dim until equipped
        var _ch = 168;
        var _pw = (_x2 - _x1 - 24) / _pn;
        for (var _p = 0; _p < _pn; _p++) {
            var _lit = (_p < _equipped);
            var _px = _x1 + 12 + _pw * (_p + 0.5);
            var _py = _top + 175;
            pan_draw_card(_plans[_p], tables, _px, _py, min(_ch, _pw * 0.92 / 0.72),
                sim_t, _lit ? 1 : 0.22, 1);
            if (_lit) {
                draw_set_colour(pan_colour(_th.good));
                draw_line_width(_px - _pw * 0.3, _py + _ch * 0.56, _px + _pw * 0.3, _py + _ch * 0.56, 2);
            }
        }

        // bonuses light as thresholds are met - pan_loadout_sets is the API doing this for real
        var _by = _top + 290;
        for (var _b = 0; _b < array_length(_def.bonuses); _b++) {
            var _bn  = _def.bonuses[_b];
            var _met = (_equipped >= _bn.need);
            draw_set_colour(pan_colour(_met ? _th.good : _th.text_dim));
            draw_text(_x1 + 16, _by, "(" + string(_bn.need) + ")  " + _bn.text);
            _by += 28;
        }

        // the crest: the set's first piece as a large watermark with a progress ring that
        // sweeps as pieces arrive - fills the lower panel with GENERATED, on-brand structure
        // instead of dead space (found by looking: 45% of each panel was empty)
        var _crx = (_x1 + _x2) * 0.5;
        var _cry = _H - _th.pad - 118;
        var _mat = tables.materials[0];
        for (var _k = 0; _k < array_length(tables.materials); _k++) {
            if (tables.materials[_k].id == _def.material) { _mat = tables.materials[_k]; break; }
        }
        var _bi0 = pan_base_find(tables, _def.pieces[0]);
        pan_draw_glyph(tables.bases[_bi0], _crx, _cry, 168, _mat, 0.16, 1);
        var _frac = _equipped / _pn;
        var _ring = 92;   // 118 measured: the ring's top arc crossed the third bonus line
        var _steps = 48;
        for (var _k = 0; _k < _steps; _k++) {
            var _on = (_k / _steps) < _frac;
            var _a0 = degtorad(-90 + (360 / _steps) * _k);
            var _a1 = degtorad(-90 + (360 / _steps) * (_k + 0.72));
            draw_set_colour(pan_colour(_on ? _th.good : _th.rule));
            draw_set_alpha(_on ? 0.9 : 0.5);
            draw_line_width(_crx + cos(_a0) * _ring, _cry + sin(_a0) * _ring,
                            _crx + cos(_a1) * _ring, _cry + sin(_a1) * _ring, _on ? 3 : 1);
        }
        draw_set_alpha(1);
    }
} break;

}

// --- blend-state leak probe ------------------------------------------------------------------
// Drawn LAST and stock-plain on purpose. If panoply_render ever leaked bm_add or an alpha, this
// bar renders wrong - it is the visual assertion for the restore-state rule, and it is the kind
// of bug that only shows up in a buyer's project.
draw_set_colour(c_white);
draw_set_alpha(1);
draw_rectangle(_W - _th.pad - 60, _H - 18, _W - _th.pad, _H - 10, false);
