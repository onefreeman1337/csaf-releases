/// PANOPLY demo - Create.
/// ============================================================================================
/// DEMO SCAFFOLDING, NOT PRODUCT. Everything in obj_panoply_demo exists so the product can be
/// seen: five showcase pages, deterministic motion (every position is a pure function of the
/// demo clock), and a command-line parser so unattended captures are reproducible. Copy the
/// pan_* CALLS into your game; delete the rest.
///
/// Pages (keys 1-5, or launch with -page N):
///   0 ARMORY   the 900-variant wall: 90 cards on screen, base x material x rarity, all drawn
///   1 FORGE    the money shot: a roll happens and the card DRAWS ITSELF - silhouette strokes
///              in, material floods, affixes stamp, rarity ignites. Stats panel beside it.
///   2 AFFIXES  the 40-glyph corpus, named
///   3 RARITY   the same item at all 5 tiers side by side
///   4 SETS     three sets; pieces equip over time and the bonuses light as tiers are met
/// Other args: -still (freeze the demo clock for stills), -quit N (exit after N frames).
/// ============================================================================================

window_set_caption("Panoply - loot & gear cards for GameMaker");

// --- command line ---------------------------------------------------------------------------
page = 0;
still_mode = false;
quit_after = -1;
var _pc = parameter_count();
for (var _i = 1; _i < _pc; _i++) {
    var _p = parameter_string(_i);
    if (_p == "-page" && _i + 1 < _pc) { page = clamp(real(parameter_string(_i + 1)), 0, 4); _i++; }
    else if (_p == "-still") { still_mode = true; }
    else if (_p == "-quit" && _i + 1 < _pc) { quit_after = real(parameter_string(_i + 1)); _i++; }
}

frame_count = 0;
reveal_hold = 0;         // frames spent resting on the completed forge card before the next roll
sim_t = 0;               // demo clock, seconds - every moving thing below is a function of it

// --- the product ----------------------------------------------------------------------------
// The whole integration surface for a buyer: a registry, a forge, and draw calls.
registry = pan_starter_registry();
tables   = pan_tables(registry);
mods     = pan_starter_mods();
theme    = pan_theme();
forge    = pan_forge_create();

/// Deterministic demo seed sequence - NOT part of the product, just reproducible captures.
function __demo_seed(_i) {
    return 20260817 + _i * 7777;
}

// FORGE page: curate a deterministic HIGHLIGHT REEL rather than raw sequential seeds - raw
// rolls are 46% common (correct for the product, dull for a looping demo). Walk the seed
// sequence once and keep the first few finds per tier, then interleave rich tiers. The card a
// still capture opens on is always an epic-or-better with 3+ affixes.
demo_seq = [];
var _epics = [];
var _mythics = [];
var _rares = [];
for (var _i = 0; _i < 800; _i++) {
    var _probe = pan_roll(__demo_seed(_i), tables);
    var _an = array_length(_probe.affixes);
    if (_probe.rarity == 4 && _an >= 4 && array_length(_mythics) < 2) { array_push(_mythics, _i); }
    else if (_probe.rarity == 3 && _an >= 3 && array_length(_epics) < 2) { array_push(_epics, _i); }
    else if (_probe.rarity == 2 && _an >= 2 && array_length(_rares) < 2) { array_push(_rares, _i); }
    if (array_length(_mythics) >= 2 && array_length(_epics) >= 2 && array_length(_rares) >= 2) { break; }
}
// epic opener (the still), then rare / mythic / rare / epic / mythic - always something rolling
if (array_length(_epics) > 0)   { array_push(demo_seq, _epics[0]); }
if (array_length(_rares) > 0)   { array_push(demo_seq, _rares[0]); }
if (array_length(_mythics) > 0) { array_push(demo_seq, _mythics[0]); }
if (array_length(_rares) > 1)   { array_push(demo_seq, _rares[1]); }
if (array_length(_epics) > 1)   { array_push(demo_seq, _epics[1]); }
if (array_length(_mythics) > 1) { array_push(demo_seq, _mythics[1]); }
if (array_length(demo_seq) == 0) { array_push(demo_seq, 0); }   // cannot happen; belt+braces
seq_ix = 0;
roll_history = [];   // plans of previous rolls, newest first, capped at 4 - the forge sidebar
pan_forge_roll(forge, registry, __demo_seed(demo_seq[0]));

// ARMORY page: pre-compose the full 30x6 wall (rarity woven per cell). 180 plans, built once -
// items are pure data, so a cell is just { base, material, rarity } composed.
armory_plans = [];
for (var _m = 0; _m < 6; _m++) {
    for (var _b = 0; _b < 30; _b++) {
        var _it = { seed: 0, base: _b, material: _m, rarity: (_b + _m) % 5, affixes: [] };
        armory_plans[_m * 30 + _b] = pan_card_compose(_it, tables);
    }
}

// RARITY page: the same item at all five tiers. Halberd in arcane reads well at row scale.
rarity_plans = [];
var _rb = pan_base_find(tables, "halberd");
var _rm = 5;   // arcane
var _ra = [pan_affix_find(tables, "keen"), pan_affix_find(tables, "burning")];
for (var _r = 0; _r < 5; _r++) {
    var _it = { seed: 0, base: _rb, material: _rm, rarity: _r, affixes: _ra };
    rarity_plans[_r] = pan_card_compose(_it, tables);
}

// SETS page: each set's pieces as composed plans, equipped progressively by the demo clock.
set_defs  = pan_starter_sets();
set_plans = [];   // set_plans[s] = array of plans, one per piece
for (var _s = 0; _s < array_length(set_defs); _s++) {
    var _def = set_defs[_s];
    var _mi = 0;
    for (var _k = 0; _k < array_length(tables.materials); _k++) {
        if (tables.materials[_k].id == _def.material) { _mi = _k; break; }
    }
    var _plans = [];
    for (var _p = 0; _p < array_length(_def.pieces); _p++) {
        var _bi = pan_base_find(tables, _def.pieces[_p]);
        // common tier on purpose: rare's corner flares collided across the tight piece row
        var _it = { seed: 0, base: _bi, material: _mi, rarity: 0, affixes: [] };
        array_push(_plans, pan_card_compose(_it, tables));
    }
    array_push(set_plans, _plans);
}

// AFFIXES page: one material per row for tincture variety (iron row reads flat - skip it).
affix_row_mats = [2, 1, 3, 4, 5];   // silver, bronze, gilt, umbral, arcane
