/// PANOPLY demo - Step.  DEMO SCAFFOLDING, NOT PRODUCT.

// Deterministic demo clock. A fixed increment rather than delta_time so an unattended capture
// produces stable frames on a slow machine and a fast one.
if (!still_mode) { sim_t += 1 / 60; }
frame_count++;

// Advance the product's own animation (the one delta_time consumer, inside panoply_bind).
pan_forge_step(forge);

// FORGE page loops its reveal so the GIF has no dead frames - but HOLDS the completed card
// first, because the ignited card is the payoff and re-rolling on the very next frame gives it
// exactly one frame of screen time (the Athanor lesson, found by looking at a capture).
if (page == 1 && !forge.anim_on && !still_mode) {
    if (forge.anim_t >= 1) {
        reveal_hold += 1;
        if (reveal_hold >= 75) {            // ~1.25 s at 60fps
            reveal_hold = 0;
            // remember the finished card, newest first, capped at 4 (the forge sidebar strip)
            array_insert(roll_history, 0, forge.plan);
            if (array_length(roll_history) > 4) { array_pop(roll_history); }
            seq_ix = (seq_ix + 1) % array_length(demo_seq);
            pan_forge_roll(forge, registry, __demo_seed(demo_seq[seq_ix]));
        }
    }
}

// --- page keys -------------------------------------------------------------------------------
if (keyboard_check_pressed(ord("1"))) { page = 0; }
if (keyboard_check_pressed(ord("2"))) { page = 1; }
if (keyboard_check_pressed(ord("3"))) { page = 2; }
if (keyboard_check_pressed(ord("4"))) { page = 3; }
if (keyboard_check_pressed(ord("5"))) { page = 4; }
if (keyboard_check_pressed(vk_escape)) { game_end(); }

// Unattended capture: exit cleanly after N frames.
if (quit_after > 0 && frame_count >= quit_after) { game_end(); }
