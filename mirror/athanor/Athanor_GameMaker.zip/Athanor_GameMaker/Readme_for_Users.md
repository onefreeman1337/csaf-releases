# Athanor — Synthesis & Transmutation for GameMaker

**Version 1.0.0 · GameMaker 2024.x (legacy runtime) · pure GML, no native extension**

A complete synthesis system whose art is drawn by the product: 24 hand-authored reagent motif
families × 6 tinctures = **144 reagent glyphs**, **20 result vessel families**, recipe seals
**composed from their constituent reagents** (276 pairwise combinations before triples even
start), a monotonic discovery loop, and a transmutation-circle animation that draws itself from
the recipe's own seal. No PNG, no atlas, no sprite anywhere in the package.

---

## Why generated art

A crafting system normally ships as logic plus a folder of icons — and the icons are the part
that never fits your game. Athanor has no icons. Every reagent, seal and vessel is generated
line-work drawn from primitives at runtime, so:

- **It recolours from data.** Six tinctures ship; add a seventh by writing fourteen numbers, and
  every glyph in the game restyles.
- **It scales without pixelation.** Draw a reagent at 16 px in a list and at 460 px in a
  transmutation circle from the same definition.
- **New recipes get new art for free.** A seal is composed from its constituents' own motifs and
  a union figure derived from *which* families combined — register a recipe and its seal exists,
  distinct from every other, with no artist in the loop.

## Quick start

Two calls to have a working atelier, one more to draw:

```gml
// Create (obj Create event) — starter book of 12 recipes included
atelier = ath_starter_atelier();

// Step (obj Step event) — advances the reveal animation
ath_atelier_step(atelier);

// Try a synthesis — order and duplicates both honoured (multiset matching)
ath_atelier_attempt(atelier, ["herb", "dew"]);
```

Draw anything, anywhere:

```gml
ath_draw_glyph(ath_motif_find("herb"), x, y, 64, ath_tincture_table()[0], 1);
ath_draw_seal(recipe.seal, x, y, 300, tincture, 1, atelier.anim_t);
```

## Register your own recipes

```gml
ath_atelier_register(atelier, { id: "my_potion", reagents: ["herb", "crystal"], result: "phial" });
```

The seal for `my_potion` is composed automatically from the herb and crystal motifs, with a union
figure derived from the combination. Add your own reagent families to `ath_motif_table()` by
copying any entry — a family is a name plus a list of strokes (`ath_line`, `ath_arc`,
`ath_circle`, `ath_poly`, `ath_spiral`) and accent points.

## Discovery — the book keeps its secrets

Recipes are `unknown` → `glimpsed` (via `ath_atelier_hint`) → `known` (via a successful
`ath_atelier_attempt`). Discovery is monotonic: the book never forgets. Save and load the whole
atelier with `ath_atelier_save` / `ath_atelier_load` — the save is versioned and keyed by
order-insensitive seal keys, so `["herb","dew"]` and `["dew","herb"]` are the same knowledge.

## The demo room

`rm_athanor_demo` is the quickstart, the smoke test and the storyboard in one. Run it and press
**1–5** for: the 144-glyph reagent shelf · the atelier (book + seal + constituents) · the
transmutation animation · the composed-seals gallery · the 20 result vessels. Every position in
it is a pure function of the demo clock, so captures reproduce exactly.

## Design guarantees

- **Pure core.** `athanor_core` makes zero engine calls — every derivation (seal composition,
  union figures, discovery, multiset matching) is reviewable in isolation.
- **Deterministic.** No `random()` anywhere in the core: replays and lockstep cannot desync on
  cosmetics, and two runs of the demo are frame-identical.
- **Blend-state safe.** Every public draw saves and restores blend mode, colour and alpha. Your
  own draws are never contaminated.
- **Namespaced.** Every symbol starts `ath_` / `ATH_` / `__ath_`. GML's global namespace is flat;
  this package keeps out of your way.
- **No absolute paths, no hardcoded room or layer indices.**

## Installing

**Option A — local package:** Tools → Import Local Package → `Athanor.yymps` → import all.
**Option B — raw source:** copy the four scripts (and optionally the demo object/room/fonts) from
the `Athanor/` project folder into your project. The scripts have no dependency on the demo.

## Compatibility

Built and package-verified against GameMaker 2024.14 (legacy GMS2 runtime, supported by YoYo with
critical fixes until at least Q1 2028 per the Spring 2026 roadmap). The code is plain GML with no
native extension, targeting GMRT's stated 99% GML compatibility as well.

## Support

Found a bug? Open a thread on the itch.io product page — reports with the demo room page number
and what you saw are fastest to fix.

---

*Athanor is part of the CSAF GameMaker catalogue: Meridian (constellation skill trees), Trove
(inventory), Kinetic UI (interface motion), Beacon (procedural energy effects), Loom (secondary
animation — capes, hair, tails) and Pliant (sprite bending and soft deformation).*
