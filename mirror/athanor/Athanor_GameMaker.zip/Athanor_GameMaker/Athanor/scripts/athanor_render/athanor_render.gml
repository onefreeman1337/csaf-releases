/// ============================================================================================
/// ATHANOR · athanor_render — the draw layer.
///
/// ONE function draws any AthGlyph, and everything visible in the product routes through it:
/// a reagent mark, a result vessel, and a composed recipe seal are the same data shape, so they
/// are the same draw call with different inputs. That is what keeps 144 glyphs, 20 vessels and
/// 276 seals looking like one product.
///
/// ⛔ BLEND-STATE HYGIENE — the rule this wing does not break.
///   Every public draw here SAVES and RESTORES blend mode, colour and alpha. A renderer that
///   leaks bm_add into a buyer's pipeline produces a bug they will report as "your asset broke my
///   game's lighting", and you cannot debug it remotely. `ath_draw_glyph` is safe to call from
///   anywhere in a buyer's draw event, in any order, and leaves the GPU exactly as it found it.
///
/// NO SPRITES. Nothing here reads a sprite, a texture page or an atlas. Every mark is stroked
/// from primitives at draw time, which is why a buyer can recolour, rescale and generate marks
/// for reagents that did not exist when the product shipped.
///
/// Public API:
///   ath_colour(rgb)                              -> GameMaker colour from an {r,g,b} struct
///   ath_draw_glyph(glyph, x, y, size, tint, a)   -> draw one AthGlyph centred at x,y
///   ath_draw_seal(seal, x, y, size, tint, a, t)  -> draw a composed recipe seal
///   ath_draw_polyline(pts, x, y, size, w)        -> internal-ish helper, exposed for demos
/// ============================================================================================

/// GameMaker packs colour as BGR, which is exactly the kind of detail that belongs in the render
/// layer and nowhere else — athanor_core stays free of colour built-ins for that reason.
function ath_colour(_rgb) {
    return make_colour_rgb(_rgb.r, _rgb.g, _rgb.b);
}

/// Draw a flat [x0,y0,x1,y1,...] polyline in UNIT SPACE, mapped to a box of `_size` at `_x,_y`.
function ath_draw_polyline(_pts, _x, _y, _size, _w) {
    var _n = array_length(_pts);
    if (_n < 4) { return; }
    var _h = _size * 0.5;
    for (var _i = 0; _i < _n - 2; _i += 2) {
        draw_line_width(
            _x + _pts[_i]     * _h, _y + _pts[_i + 1] * _h,
            _x + _pts[_i + 2] * _h, _y + _pts[_i + 3] * _h,
            _w);
    }
}

/// Draw one AthGlyph centred at (_x,_y) inside a box of _size px, in tincture _tint.
///
/// Three passes, which is what makes a stroke drawing read as *made* rather than as debug lines:
///   1. GLOW   — wide, low alpha, additive. The mark's halo.
///   2. STROKE — the mark itself at full weight.
///   3. ACCENT — the family's accent points as bright pips, additive.
function ath_draw_glyph(_glyph, _x, _y, _size, _tint, _alpha) {
    // ── save GPU state ──
    var _old_blend = gpu_get_blendmode();
    var _old_col   = draw_get_colour();
    var _old_alpha = draw_get_alpha();

    var _lines = ath_glyph_flatten(_glyph);
    var _n     = array_length(_lines);
    var _wCore = max(1, _size * 0.030);
    var _wGlow = max(2, _size * 0.085);

    // 1. glow
    gpu_set_blendmode(bm_add);
    draw_set_colour(ath_colour(_tint.glow));
    draw_set_alpha(_alpha * 0.22);
    for (var _i = 0; _i < _n; _i++) { ath_draw_polyline(_lines[_i], _x, _y, _size, _wGlow); }

    // 2. stroke
    gpu_set_blendmode(bm_normal);
    draw_set_colour(ath_colour(_tint.stroke));
    draw_set_alpha(_alpha);
    for (var _i = 0; _i < _n; _i++) { ath_draw_polyline(_lines[_i], _x, _y, _size, _wCore); }

    // 3. accents — stored flat as x,y pairs
    var _acc = _glyph.accents;
    var _an  = array_length(_acc);
    if (_an >= 2) {
        gpu_set_blendmode(bm_add);
        draw_set_colour(ath_colour(_tint.accent));
        draw_set_alpha(_alpha);
        var _r = max(1.5, _size * 0.035);
        var _h = _size * 0.5;
        for (var _i = 0; _i < _an - 1; _i += 2) {
            draw_circle(_x + _acc[_i] * _h, _y + _acc[_i + 1] * _h, _r, false);
        }
    }

    // ── restore GPU state ──
    gpu_set_blendmode(_old_blend);
    draw_set_colour(_old_col);
    draw_set_alpha(_old_alpha);
}

/// Draw a composed recipe seal: outer ring, arc divisions, each constituent's mark in its wedge,
/// and the generated union polygram at centre.
///
/// `_t` is a 0..1 reveal parameter, which is what makes the synthesis animation possible without
/// a second code path: 0 draws nothing, 1 draws the finished seal, and the demo sweeps it.
function ath_draw_seal(_seal, _x, _y, _size, _tint, _alpha, _t) {
    var _old_blend = gpu_get_blendmode();
    var _old_col   = draw_get_colour();
    var _old_alpha = draw_get_alpha();

    var _t01 = clamp(_t, 0, 1);
    var _r   = _size * 0.5;

    // ── outer ring, swept by _t ──
    gpu_set_blendmode(bm_add);
    draw_set_colour(ath_colour(_tint.glow));
    draw_set_alpha(_alpha * 0.30);
    var _sweep = 360 * _t01;
    var _steps = max(2, round(96 * _t01));
    for (var _i = 0; _i < _steps; _i++) {
        var _a0 = degtorad(-90 + _sweep * (_i / _steps));
        var _a1 = degtorad(-90 + _sweep * ((_i + 1) / _steps));
        draw_line_width(_x + cos(_a0) * _r, _y + sin(_a0) * _r,
                        _x + cos(_a1) * _r, _y + sin(_a1) * _r, max(2, _size * 0.020));
    }

    gpu_set_blendmode(bm_normal);
    draw_set_colour(ath_colour(_tint.stroke));
    draw_set_alpha(_alpha);
    for (var _i = 0; _i < _steps; _i++) {
        var _a0 = degtorad(-90 + _sweep * (_i / _steps));
        var _a1 = degtorad(-90 + _sweep * ((_i + 1) / _steps));
        draw_line_width(_x + cos(_a0) * _r, _y + sin(_a0) * _r,
                        _x + cos(_a1) * _r, _y + sin(_a1) * _r, max(1, _size * 0.008));
    }

    // ── arc divisions + each constituent's mark in its own wedge ──
    var _arcs   = _seal.arcs;
    var _an     = array_length(_arcs);
    var _motifs = ath_motif_table();
    // marks fade in over the second half of the reveal
    var _markT  = clamp((_t01 - 0.35) / 0.45, 0, 1);

    for (var _i = 0; _i < _an; _i++) {
        var _arc = _arcs[_i];
        var _mid = degtorad((_arc.a0 + _arc.a1) * 0.5);

        // division spoke
        if (_t01 > 0.3) {
            draw_set_colour(ath_colour(_tint.stroke));
            draw_set_alpha(_alpha * 0.45);
            var _sa = degtorad(_arc.a0);
            draw_line_width(_x, _y, _x + cos(_sa) * _r, _y + sin(_sa) * _r, max(1, _size * 0.005));
        }

        if (_markT > 0 && _arc.index >= 0) {
            ath_draw_glyph(_motifs[_arc.index],
                _x + cos(_mid) * _r * 0.62,
                _y + sin(_mid) * _r * 0.62,
                _size * _arc.scale, _tint, _alpha * _markT);
        }
    }

    // ── the union figure: the seal's focal mark, ignited last ──
    if (_t01 > 0.8) {
        var _ut  = clamp((_t01 - 0.8) / 0.2, 0, 1);
        var _pts = ath_polygram_points(_seal.union.vertices, _seal.union.step, 1.0);

        gpu_set_blendmode(bm_add);
        draw_set_colour(ath_colour(_tint.glow));
        draw_set_alpha(_alpha * 0.55 * _ut);
        ath_draw_polyline(_pts, _x, _y, _size * 0.42, max(2, _size * 0.030));

        gpu_set_blendmode(bm_normal);
        draw_set_colour(ath_colour(_tint.accent));
        draw_set_alpha(_alpha * _ut);
        ath_draw_polyline(_pts, _x, _y, _size * 0.42, max(1, _size * 0.010));
    }

    gpu_set_blendmode(_old_blend);
    draw_set_colour(_old_col);
    draw_set_alpha(_old_alpha);
}
