/// ============================================================================================
/// ATHANOR · athanor_core — the pure generator core.
///
/// ZERO engine calls. Nothing in this file reads an instance, a room, a sprite, the clock or the
/// renderer; the only built-ins used are pure maths (sin/cos/sqrt/floor/min/max/abs/clamp/lerp/pi/
/// degtorad) and array/struct functions. That is deliberate: GML cannot be unit-tested outside
/// GameMaker, so every algorithm in Athanor lives where it can be read, reasoned about and
/// mirrored numerically in isolation. `Internal_Ops/sim_mirror.js` is that mirror and it was
/// written FIRST — 31 assertions over this exact corpus, and it caught two real defects before a
/// line of GML existed (see HONEST NOTES). Everything impure sits in athanor_bind (time, instances,
/// persistence) and athanor_render (drawing).
///
/// THE ONE IDEA — every mark in the product is the same data shape.
///   An AthGlyph is { strokes[], accents[] } in UNIT SPACE ([-1..1] on both axes), where each
///   stroke is a primitive (line / arc / poly / spiral) and each accent is a point. A reagent
///   mark, a result vessel and a composed recipe seal are ALL AthGlyphs, and athanor_render draws
///   any of them with one function. That shared grammar is not tidiness — it is the only reason a
///   recipe seal can EMBED its constituent reagents' marks at all, because a mark is just data.
///   It is also why 144 reagent glyphs read as one product instead of 144 doodles.
///
/// THE VOLUME IS THE MOAT.
///   24 hand-authored reagent families x 6 tinctures = 144 distinct reagent glyphs. 20 result
///   vessel families. 276 pairwise composed seals (24 choose 2), more with triples. The families
///   were authored in Internal_Ops/Motif_Corpus.md BEFORE any code. Rules are cheap; a corpus
///   that coheres into one visual language is not.
///
/// DETERMINISM — no random(), anywhere.
///   Every glyph and every seal is a pure function of its identity. The same reagent SET always
///   yields the same seal, in any order. A buyer's save file therefore stays visually stable
///   across sessions and across machines, captures are reproducible, and nothing desyncs.
///
/// HONEST NOTES — two real defects the mirror caught before this file existed
///   - The Scroll case vessel originally reached 1.05 in unit space (body half-width 0.75 plus an
///     end-cap arc of radius 0.30). On the 144-glyph shelf that overdraws its neighbour. No
///     compiler can see this; a bounds assertion can. Body narrowed to 0.68.
///   - The union figure's vertex count was first specified as (sum of accent points) mod 9, min 3.
///     MEASURED over all 276 pairs, that put 177 of them — 64% — on the same 3-vertex triangle,
///     because most families carry 0-1 accents. The seals would have been uniquely keyed and
///     visually samey, which satisfies the claim in the letter and breaks it in the picture. The
///     shipped derivation folds in WHICH families combined, not merely how many dots they carry.
///     Measured distribution is now {3:46,4:42,5:36,6:43,7:35,8:33,9:41} — top share 16.7%.
///
/// Public API (everything else in this file is internal and prefixed __ath_):
///   ath_motif_table()                  -> array of 24 reagent AthGlyphs (cached)
///   ath_vessel_table()                 -> array of 20 result vessel AthGlyphs (cached)
///   ath_tincture_table()               -> array of 6 tinctures (cached)
///   ath_motif_find(id)                 -> index of a family by string id, or -1
///   ath_glyph_flatten(glyph)           -> array of polylines, each a flat [x0,y0,x1,y1,...]
///   ath_seal_compose(ids)              -> composed seal struct for a reagent SET
///   ath_union_figure(ids)              -> { vertices, step } centre polygram
///   ath_polygram_points(n, step, r)    -> flat [x,y,...] ring for the union figure
///   ath_discover(state, event)         -> monotonic discovery transition
///   ath_recipe_match(recipe, bag)      -> bool, multiset match honouring duplicates
/// ============================================================================================

#macro ATH_VERSION            "1.0.0"
#macro ATH_MOTIF_COUNT        24
#macro ATH_VESSEL_COUNT       20
#macro ATH_TINCTURE_COUNT     6
#macro ATH_ARC_SEGS           24      // flattening resolution for a full 360 degree arc
#macro ATH_STATE_UNKNOWN      0
#macro ATH_STATE_GLIMPSED     1
#macro ATH_STATE_KNOWN        2

// ── stroke primitive constructors ────────────────────────────────────────────────────────────
// Kept as tiny structs so the corpus below reads as authored geometry rather than as maths.

function ath_line(_ax, _ay, _bx, _by) {
    return { k: "line", ax: _ax, ay: _ay, bx: _bx, by: _by };
}
function ath_arc(_cx, _cy, _r, _a0, _a1) {
    return { k: "arc", cx: _cx, cy: _cy, r: _r, a0: _a0, a1: _a1 };
}
function ath_circle(_cx, _cy, _r) {
    return { k: "arc", cx: _cx, cy: _cy, r: _r, a0: 0, a1: 360 };
}
function ath_poly(_pts) {
    return { k: "poly", pts: _pts };          // flat [x0,y0,x1,y1,...]
}
function ath_spiral(_cx, _cy, _r0, _r1, _a0, _a1) {
    return { k: "spiral", cx: _cx, cy: _cy, r0: _r0, r1: _r1, a0: _a0, a1: _a1 };
}

/// Flatten one primitive to a flat polyline [x0,y0,x1,y1,...]. Deterministic.
function __ath_flatten_prim(_p) {
    var _out = [];
    switch (_p.k) {
        case "line":
            _out = [_p.ax, _p.ay, _p.bx, _p.by];
        break;

        case "poly":
            // copy so a caller cannot mutate the cached corpus
            var _n = array_length(_p.pts);
            for (var _i = 0; _i < _n; _i++) { array_push(_out, _p.pts[_i]); }
        break;

        case "arc": {
            var _span = _p.a1 - _p.a0;
            var _steps = max(2, round(ATH_ARC_SEGS * abs(_span) / 360));
            for (var _i = 0; _i <= _steps; _i++) {
                var _a = degtorad(_p.a0 + _span * (_i / _steps));
                array_push(_out, _p.cx + cos(_a) * _p.r);
                array_push(_out, _p.cy + sin(_a) * _p.r);
            }
        } break;

        case "spiral": {
            var _span = _p.a1 - _p.a0;
            var _steps = max(2, round(ATH_ARC_SEGS * abs(_span) / 360));
            for (var _i = 0; _i <= _steps; _i++) {
                var _t = _i / _steps;
                var _a = degtorad(_p.a0 + _span * _t);
                var _r = lerp(_p.r0, _p.r1, _t);
                array_push(_out, _p.cx + cos(_a) * _r);
                array_push(_out, _p.cy + sin(_a) * _r);
            }
        } break;
    }
    return _out;
}

/// Flatten a whole AthGlyph -> array of flat polylines.
function ath_glyph_flatten(_glyph) {
    var _out = [];
    var _n = array_length(_glyph.strokes);
    for (var _i = 0; _i < _n; _i++) {
        array_push(_out, __ath_flatten_prim(_glyph.strokes[_i]));
    }
    return _out;
}

// ── authored helpers used by the corpus ──────────────────────────────────────────────────────

/// sine wave polyline (Brine). Authored parameters, deterministic.
function __ath_wave(_x0, _x1, _y, _amp, _cycles) {
    var _pts = [];
    for (var _i = 0; _i <= 32; _i++) {
        var _t = _i / 32;
        array_push(_pts, lerp(_x0, _x1, _t));
        array_push(_pts, _y + sin(_t * _cycles * 2 * pi) * _amp);
    }
    return _pts;
}

/// closed regular n-gon
function __ath_ngon(_cx, _cy, _r, _n, _rot) {
    var _pts = [];
    for (var _i = 0; _i <= _n; _i++) {
        var _a = degtorad(_rot + (360 / _n) * _i);
        array_push(_pts, _cx + cos(_a) * _r);
        array_push(_pts, _cy + sin(_a) * _r);
    }
    return _pts;
}

/// closed n-point star
function __ath_star(_cx, _cy, _ro, _ri, _points, _rot) {
    var _pts = [];
    var _tot = _points * 2;
    for (var _i = 0; _i <= _tot; _i++) {
        var _r = (_i % 2 == 0) ? _ro : _ri;
        var _a = degtorad(_rot + (180 / _points) * _i);
        array_push(_pts, _cx + cos(_a) * _r);
        array_push(_pts, _cy + sin(_a) * _r);
    }
    return _pts;
}

function __ath_glyph(_id, _name, _strokes, _accents) {
    return { id: _id, name: _name, strokes: _strokes, accents: _accents };
}

// ── THE 24 REAGENT MOTIF FAMILIES ────────────────────────────────────────────────────────────
// Per Internal_Ops/Motif_Corpus.md. `accents` are the small marked points; they also feed the
// composed seal's union figure, which is why they are data and not decoration.
// `static` caches the table after the first call — the corpus is immutable.

function ath_motif_table() {
    static _tbl = [
        __ath_glyph("herb", "Herb",
            [ath_line(0, -0.85, 0, 0.8), ath_arc(-0.05, 0.05, 0.5, -80, 20), ath_arc(0.05, 0.05, 0.5, 160, 260)],
            [0, -0.85]),
        __ath_glyph("root", "Root",
            [ath_spiral(0, 0.1, 0.12, 0.72, 0, 520), ath_line(0, -0.62, 0.22, -0.86)],
            []),
        __ath_glyph("spore", "Spore",
            [ath_circle(0, -0.34, 0.24), ath_circle(-0.32, 0.26, 0.24), ath_circle(0.32, 0.26, 0.24)],
            [0, -0.34, -0.32, 0.26, 0.32, 0.26]),
        __ath_glyph("bloom", "Bloom",
            [ath_arc(0, 0.55, 0.85, 200, 250), ath_arc(0, 0.55, 0.9, 245, 285), ath_arc(0, 0.55, 0.92, 250, 290),
             ath_arc(0, 0.55, 0.9, 255, 295), ath_arc(0, 0.55, 0.85, 290, 340)],
            [0, 0.55]),
        __ath_glyph("bark", "Bark",
            [ath_arc(0.5, 0, 0.55, 130, 230), ath_arc(0.5, 0, 0.75, 135, 225), ath_arc(0.5, 0, 0.95, 140, 220)],
            []),
        __ath_glyph("crystal", "Crystal",
            [ath_poly([0, -0.9, 0.42, -0.3, 0.3, 0.72, -0.3, 0.72, -0.42, -0.3, 0, -0.9]), ath_line(0, -0.9, 0.05, 0.7)],
            [0, -0.9, 0, 0.72]),
        __ath_glyph("salt", "Salt",
            [ath_circle(0, 0, 0.82), ath_poly([0, -0.5, 0.5, 0, 0, 0.5, -0.5, 0, 0, -0.5])],
            [0, -0.5, 0.5, 0, 0, 0.5, -0.5, 0]),
        __ath_glyph("ore", "Ore",
            [ath_arc(0, 0.1, 0.8, 180, 360), ath_poly([-0.7, 0.1, -0.28, -0.4, 0.06, 0.06, 0.4, -0.46, 0.72, 0.06])],
            [-0.28, -0.4, 0.4, -0.46]),
        __ath_glyph("dust", "Dust",
            [ath_circle(-0.5, -0.5, 0.1), ath_circle(0, 0, 0.1), ath_circle(0.5, 0.5, 0.1)],
            [-0.5, -0.5, 0, 0, 0.5, 0.5]),
        __ath_glyph("ember", "Ember",
            [ath_poly([0, -0.92, 0.45, -0.15, 0.2, 0.5, 0, 0.8]), ath_poly([0, -0.92, -0.45, -0.15, -0.2, 0.5, 0, 0.8])],
            [0, -0.92]),
        __ath_glyph("ash", "Ash",
            [ath_line(-0.75, 0.6, 0.75, 0.6), ath_arc(-0.4, 0.6, 0.5, 200, 300), ath_arc(0, 0.6, 0.6, 205, 295),
             ath_arc(0.4, 0.6, 0.5, 210, 290)],
            []),
        __ath_glyph("dew", "Dew",
            [ath_poly([0, -0.85, 0.5, 0.2, 0, 0.78, -0.5, 0.2, 0, -0.85]), ath_arc(-0.12, 0.18, 0.26, 120, 250)],
            [0, -0.85]),
        __ath_glyph("brine", "Brine",
            [ath_poly(__ath_wave(-0.85, 0.85, -0.28, 0.22, 2)), ath_poly(__ath_wave(-0.85, 0.85, 0.32, 0.22, 2))],
            []),
        __ath_glyph("ichor", "Ichor",
            [ath_poly([0, -0.55, 0.55, 0.18, 0, 0.8, -0.55, 0.18, 0, -0.55]), ath_poly([0, -0.55, 0.16, -0.78, -0.04, -0.95])],
            [0, 0.8]),
        __ath_glyph("venom", "Venom",
            [ath_arc(0.55, -0.5, 0.9, 95, 160), ath_arc(-0.55, -0.5, 0.9, 20, 85)],
            [-0.16, 0.32, 0.16, 0.32]),
        __ath_glyph("feather", "Feather",
            [ath_arc(0.7, 0, 1.0, 150, 215), ath_line(-0.24, -0.36, 0.28, -0.5), ath_line(-0.3, -0.02, 0.24, -0.14),
             ath_line(-0.24, 0.32, 0.2, 0.22)],
            [-0.3, 0.55]),
        __ath_glyph("bone", "Bone",
            [ath_line(0, -0.62, 0, 0.62), ath_circle(-0.2, -0.68, 0.2), ath_circle(0.2, -0.68, 0.2),
             ath_circle(-0.2, 0.68, 0.2), ath_circle(0.2, 0.68, 0.2)],
            []),
        __ath_glyph("chitin", "Chitin",
            [ath_arc(0, 0.65, 0.75, 195, 345), ath_arc(0, 0.3, 0.75, 195, 345), ath_arc(0, -0.05, 0.75, 195, 345)],
            []),
        __ath_glyph("silk", "Silk",
            [ath_circle(0, -0.36, 0.36), ath_circle(0, 0.36, 0.36), ath_line(0.3, 0.6, 0.78, 0.86)],
            []),
        __ath_glyph("resin", "Resin",
            [ath_poly(__ath_ngon(0, 0, 0.8, 6, 90)), ath_line(-0.62, 0.18, 0.62, 0.18)],
            [0, 0.18]),
        __ath_glyph("quicksilver", "Quicksilver",
            [ath_arc(0, 0, 0.78, 35, 325), ath_circle(0.78, 0, 0.16)],
            [0.78, 0]),
        __ath_glyph("lodestone", "Lodestone",
            [ath_arc(0, 0.1, 0.62, 180, 360), ath_line(-0.62, 0.1, -0.62, 0.66), ath_line(0.62, 0.1, 0.62, 0.66),
             ath_arc(0, 0.1, 0.86, 200, 250), ath_arc(0, 0.1, 0.86, 290, 340)],
            [-0.62, 0.66, 0.62, 0.66]),
        __ath_glyph("aether", "Aether",
            [ath_arc(0, 0, 0.92, 40, 320), ath_poly(__ath_star(0, 0, 0.55, 0.2, 4, -90))],
            [0, -0.55, 0.55, 0, 0, 0.55, -0.55, 0]),
        __ath_glyph("umbra", "Umbra",
            [ath_circle(0.16, 0, 0.72), ath_arc(-0.18, 0, 0.78, 60, 300)],
            [-0.18, 0]),
    ];
    return _tbl;
}

// ── THE 20 RESULT VESSEL FAMILIES ────────────────────────────────────────────────────────────

function ath_vessel_table() {
    static _tbl = [
        __ath_glyph("phial", "Phial",
            [ath_poly([-0.22, -0.85, -0.22, -0.3, -0.42, 0.2, -0.42, 0.75, 0.42, 0.75, 0.42, 0.2, 0.22, -0.3, 0.22, -0.85, -0.22, -0.85]),
             ath_line(-0.42, 0.34, 0.42, 0.34)], []),
        __ath_glyph("flask", "Flask",
            [ath_poly([-0.18, -0.85, -0.18, -0.25, -0.6, 0.7, 0.6, 0.7, 0.18, -0.25, 0.18, -0.85, -0.18, -0.85]),
             ath_line(-0.44, 0.3, 0.44, 0.3)], []),
        __ath_glyph("orb", "Orb",
            [ath_circle(0, 0.08, 0.72), ath_arc(-0.2, -0.14, 0.3, 130, 250)], []),
        __ath_glyph("ingot", "Ingot",
            [ath_poly([-0.75, 0.12, -0.52, -0.4, 0.52, -0.4, 0.75, 0.12, -0.75, 0.12]),
             ath_poly([-0.75, 0.12, -0.75, 0.5, 0.75, 0.5, 0.75, 0.12])], []),
        __ath_glyph("gem", "Cut gem",
            [ath_poly([0, -0.8, 0.68, -0.2, 0.4, 0.72, -0.4, 0.72, -0.68, -0.2, 0, -0.8]),
             ath_poly([-0.68, -0.2, 0, 0.1, 0.68, -0.2]), ath_line(0, 0.1, 0, 0.72)], []),
        __ath_glyph("talisman", "Talisman",
            [ath_circle(0, 0.16, 0.62), ath_arc(0, -0.52, 0.22, 180, 360), ath_poly(__ath_ngon(0, 0.16, 0.34, 3, -90))], []),
        __ath_glyph("ampoule", "Ampoule",
            [ath_poly([-0.16, -0.9, -0.3, -0.4, -0.3, 0.62, 0.3, 0.62, 0.3, -0.4, 0.16, -0.9]),
             ath_arc(0, 0.62, 0.3, 0, 180)], []),
        __ath_glyph("censer", "Censer",
            [ath_arc(0, 0.1, 0.6, 0, 180), ath_line(-0.6, 0.1, 0.6, 0.1), ath_arc(0, 0.1, 0.6, 190, 350),
             ath_arc(-0.24, -0.4, 0.34, 200, 320), ath_arc(0.24, -0.62, 0.34, 200, 320)], []),
        __ath_glyph("horn", "Elixir horn",
            [ath_spiral(0.1, 0.2, 0.14, 0.82, 200, 480), ath_line(-0.5, -0.42, 0.28, -0.72)], []),
        __ath_glyph("tablet", "Tablet",
            [ath_poly([-0.55, -0.75, 0.55, -0.75, 0.55, 0.75, -0.55, 0.75, -0.55, -0.75]),
             ath_line(-0.34, -0.36, 0.34, -0.36), ath_line(-0.34, 0, 0.34, 0), ath_line(-0.34, 0.36, 0.1, 0.36)], []),
        __ath_glyph("ring", "Ring",
            [ath_circle(0, 0.14, 0.6), ath_circle(0, 0.14, 0.4), ath_poly(__ath_ngon(0, -0.56, 0.22, 3, -90))], []),
        __ath_glyph("sachet", "Powder sachet",
            [ath_poly([-0.5, 0.7, -0.34, -0.3, 0.34, -0.3, 0.5, 0.7, -0.5, 0.7]),
             ath_poly([-0.34, -0.3, -0.16, -0.72, 0.16, -0.72, 0.34, -0.3])], []),
        __ath_glyph("candle", "Candle",
            [ath_poly([-0.28, 0.75, -0.28, -0.3, 0.28, -0.3, 0.28, 0.75, -0.28, 0.75]), ath_line(0, -0.3, 0, -0.52),
             ath_poly([0, -0.92, 0.2, -0.56, 0, -0.4, -0.2, -0.56, 0, -0.92])], []),
        __ath_glyph("lens", "Lens",
            [ath_arc(-0.5, 0, 0.85, -45, 45), ath_arc(0.5, 0, 0.85, 135, 225), ath_line(0, -0.6, 0, 0.6)], []),
        __ath_glyph("bell", "Bell",
            [ath_poly([-0.6, 0.55, -0.44, -0.2, 0, -0.62, 0.44, -0.2, 0.6, 0.55, -0.6, 0.55]),
             ath_line(-0.66, 0.55, 0.66, 0.55), ath_circle(0, 0.7, 0.12)], []),
        __ath_glyph("key", "Key",
            [ath_circle(0, -0.5, 0.3), ath_line(0, -0.2, 0, 0.8), ath_line(0, 0.5, 0.34, 0.5), ath_line(0, 0.68, 0.26, 0.68)], []),
        __ath_glyph("idol", "Idol",
            [ath_circle(0, -0.5, 0.26), ath_poly([-0.4, 0.8, -0.26, -0.16, 0.26, -0.16, 0.4, 0.8, -0.4, 0.8]),
             ath_line(-0.26, 0.1, 0.26, 0.1)], []),
        __ath_glyph("lantern", "Lantern",
            [ath_poly([-0.45, -0.4, 0.45, -0.4, 0.45, 0.55, -0.45, 0.55, -0.45, -0.4]), ath_arc(0, -0.4, 0.3, 180, 360),
             ath_line(-0.45, -0.55, 0.45, -0.55), ath_circle(0, 0.08, 0.2)], []),
        // ⚠️ body half-width 0.68, NOT 0.75: the end-cap arcs add their own radius, and 0.75+0.30
        // = 1.05 escapes unit space and overdraws the neighbouring glyph on the shelf wall.
        // Caught by the mirror's bounds assertion; no compile can see it.
        __ath_glyph("scrollcase", "Scroll case",
            [ath_poly([-0.68, -0.3, 0.68, -0.3, 0.68, 0.3, -0.68, 0.3, -0.68, -0.3]),
             ath_arc(-0.68, 0, 0.3, 90, 270), ath_arc(0.68, 0, 0.3, -90, 90), ath_line(-0.45, -0.3, -0.45, 0.3)], []),
        __ath_glyph("mirror", "Mirror",
            [ath_circle(0, -0.2, 0.55), ath_circle(0, -0.2, 0.4),
             ath_poly([-0.12, 0.35, -0.18, 0.85, 0.18, 0.85, 0.12, 0.35])], []),
    ];
    return _tbl;
}

// ── THE 6 TINCTURES ──────────────────────────────────────────────────────────────────────────
// Applied BY ROLE (stroke / fill / accent / glow), never per-glyph hand-colouring. That is what
// makes 24 x 6 a coherent 144 rather than 144 one-offs — and adding a seventh tincture is DATA,
// not code: append one struct here and the shelf grows by 24 glyphs.
// Components are kept as r/g/b so this file stays free of colour built-ins; athanor_render builds
// the actual colour. (GameMaker's make_colour_rgb packs BGR, which is exactly the kind of detail
// that should live in the render layer and nowhere else.)

function __ath_tint(_id, _name, _sr, _sg, _sb, _fr, _fg, _fb, _ar, _ag, _ab, _gr, _gg, _gb) {
    return {
        id: _id, name: _name,
        stroke: { r: _sr, g: _sg, b: _sb },
        fill:   { r: _fr, g: _fg, b: _fb },
        accent: { r: _ar, g: _ag, b: _ab },
        glow:   { r: _gr, g: _gg, b: _gb },
    };
}

function ath_tincture_table() {
    static _tbl = [
        __ath_tint("verdant", "Verdant", 191, 227, 168,  30,  51,  36, 242, 255, 214, 111, 191,  90),
        __ath_tint("cinder",  "Cinder",  255, 192, 138,  51,  25,  15, 255, 240, 208, 224, 103,  42),
        __ath_tint("tidal",   "Tidal",   168, 216, 240,  17,  36,  46, 228, 248, 255,  62, 159, 208),
        __ath_tint("auric",   "Auric",   240, 217, 153,  46,  36,  16, 255, 246, 218, 212, 166,  42),
        __ath_tint("violet",  "Violet",  213, 184, 240,  36,  26,  51, 246, 234, 255, 154,  95, 208),
        __ath_tint("umbral",  "Umbral",  154, 166, 184,  20,  23,  30, 226, 232, 242,  84,  96, 122),
    ];
    return _tbl;
}

/// Index of a reagent family by string id, or -1. Linear over 24 — the corpus is small and this
/// keeps the core free of ds_map lifetime concerns.
function ath_motif_find(_id) {
    var _t = ath_motif_table();
    for (var _i = 0; _i < array_length(_t); _i++) {
        if (_t[_i].id == _id) { return _i; }
    }
    return -1;
}

// ── SEAL COMPOSITION — the discovery loop's picture ───────────────────────────────────────────

function __ath_gcd(_a, _b) {
    while (_b != 0) {
        var _t = _a % _b;
        _a = _b;
        _b = _t;
    }
    return _a;
}

/// The centre polygram of a composed seal.
///
/// vertices = 3 + ((accents*2 + sum of family indices) mod 7)  ->  3..9
///
/// ⚠️ The index term is not decoration. The first specification used (accents mod 9, min 3), and
/// measured over all 276 pairs that put 64% of seals on the SAME triangle — uniquely keyed,
/// visually identical. Folding in which families combined spreads the distribution to a measured
/// top share of 16.7%.
///
/// ⚠️ The step is chosen COPRIME to the vertex count. A step sharing a factor with n closes the
/// path early and silently draws a smaller polygon with points missing. Nothing about that is a
/// compile error; it just looks wrong.
function ath_union_figure(_ids) {
    var _accents = 0;
    var _idxsum = 0;
    var _t = ath_motif_table();
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _k = ath_motif_find(_ids[_i]);
        if (_k < 0) { continue; }
        _accents += array_length(_t[_k].accents) / 2;   // accents are stored flat as x,y pairs
        _idxsum  += _k + 1;
    }
    var _n = 3 + ((_accents * 2 + _idxsum) % 7);
    var _step = 1;
    for (var _s = floor(_n / 2); _s >= 2; _s--) {
        if (__ath_gcd(_s, _n) == 1) { _step = _s; break; }
    }
    return { vertices: _n, step: _step };
}

/// Flat [x,y,...] ring for a polygram of n vertices walked with the given step.
function ath_polygram_points(_n, _step, _r) {
    var _pts = [];
    var _v = 0;
    for (var _i = 0; _i <= _n; _i++) {
        var _a = degtorad(-90 + (360 / _n) * _v);
        array_push(_pts, cos(_a) * _r);
        array_push(_pts, sin(_a) * _r);
        _v = (_v + _step) % _n;
    }
    return _pts;
}

/// Sort a copy of an id array so a seal is order-insensitive.
function __ath_sorted_ids(_ids) {
    var _c = [];
    for (var _i = 0; _i < array_length(_ids); _i++) { array_push(_c, _ids[_i]); }
    array_sort(_c, true);
    return _c;
}

/// Compose the seal for a reagent SET.
///
/// Deterministic and order-insensitive: the same set always yields the same seal, so a buyer's
/// save file stays visually stable and two players who discover the same recipe see the same mark.
/// Returns { ids, key, arcs[], union } where each arc carries the constituent's family index and
/// the angular wedge its mark is drawn in.
function ath_seal_compose(_ids) {
    var _sorted = __ath_sorted_ids(_ids);
    var _n = array_length(_sorted);
    var _arcs = [];
    var _key = "";
    // Smaller marks as the ingredient count rises, floored so a triple stays legible.
    var _scale = max(0.16, 0.34 - max(0, _n - 2) * 0.03);

    for (var _i = 0; _i < _n; _i++) {
        array_push(_arcs, {
            motif: _sorted[_i],
            index: ath_motif_find(_sorted[_i]),
            a0: -90 + (360 / _n) * _i,
            a1: -90 + (360 / _n) * (_i + 1),
            scale: _scale,
        });
        _key += (_i > 0 ? "+" : "") + _sorted[_i];
    }

    return { ids: _sorted, key: _key, arcs: _arcs, union: ath_union_figure(_sorted) };
}

// ── DISCOVERY + RECIPE MATCHING ──────────────────────────────────────────────────────────────

/// Monotonic discovery transition. A recipe never un-learns itself: whatever the event, the state
/// can only move forward. That is a deliberate save-file guarantee, not an accident of ordering.
///   _event: "hint" -> at least GLIMPSED,  "synthesise" -> KNOWN,  anything else -> unchanged.
function ath_discover(_state, _event) {
    var _target = _state;
    if (_event == "hint")       { _target = ATH_STATE_GLIMPSED; }
    if (_event == "synthesise") { _target = ATH_STATE_KNOWN; }
    return max(_state, _target);
}

/// Multiset match: does `_bag` contain at least the required count of every reagent in `_recipe`?
/// Honouring DUPLICATES is the whole point — a recipe needing 2x Herb must not be satisfied by one.
///   _recipe : { reagents: [id, id, ...] }
///   _bag    : [id, id, ...]
function ath_recipe_match(_recipe, _bag) {
    var _need = {};
    var _rn = array_length(_recipe.reagents);
    for (var _i = 0; _i < _rn; _i++) {
        var _id = _recipe.reagents[_i];
        var _c = variable_struct_exists(_need, _id) ? variable_struct_get(_need, _id) : 0;
        variable_struct_set(_need, _id, _c + 1);
    }

    var _have = {};
    var _bn = array_length(_bag);
    for (var _i = 0; _i < _bn; _i++) {
        var _id = _bag[_i];
        var _c = variable_struct_exists(_have, _id) ? variable_struct_get(_have, _id) : 0;
        variable_struct_set(_have, _id, _c + 1);
    }

    var _keys = variable_struct_get_names(_need);
    for (var _i = 0; _i < array_length(_keys); _i++) {
        var _k = _keys[_i];
        var _h = variable_struct_exists(_have, _k) ? variable_struct_get(_have, _k) : 0;
        if (_h < variable_struct_get(_need, _k)) { return false; }
    }
    return true;
}
