/// ============================================================================================
/// ATHANOR · athanor_preset — content and taste.
///
/// A starter recipe book and the atelier theme, as plain data. Everything here is meant to be
/// copied, retuned or replaced wholesale — none of it is load-bearing for the system, and the
/// demo scaffolding is commented as delete-me.
///
/// This file is deliberately the SMALLEST of the four. The product's value is the generator in
/// athanor_core, not a canned list of potions; a buyer's reagents and recipes are their own, and
/// Athanor draws marks for reagents that did not exist when this shipped.
/// ============================================================================================

/// The atelier's visual theme. Custom throughout — GameMaker draws none of this, which is the
/// point (a product that looks like the engine gets dismissed on the thumbnail).
function ath_theme() {
    static _t = {
        bg:        { r:  14, g:  16, b:  22 },
        panel:     { r:  22, g:  26, b:  35 },
        rule:      { r:  54, g:  62, b:  78 },
        text:      { r: 214, g: 221, b: 234 },
        text_dim:  { r: 128, g: 138, b: 158 },
        pad:       28,
        rowH:      42,
        ease:      0.18,
    };
    return _t;
}

/// A starter book: 12 recipes across pairs and triples, chosen so the composed seals differ
/// visibly from one another (different arc counts AND different union figures).
function ath_starter_recipes() {
    static _r = [
        { id: "tonic",     reagents: ["herb", "dew"],                 result: "phial"     },
        { id: "salve",     reagents: ["herb", "resin"],               result: "sachet"    },
        { id: "draught",   reagents: ["root", "brine"],               result: "flask"     },
        { id: "philtre",   reagents: ["bloom", "silk"],               result: "ampoule"   },
        { id: "arcanum",   reagents: ["crystal", "salt"],             result: "gem"       },
        { id: "ingot",     reagents: ["ore", "ember"],                result: "ingot"     },
        { id: "ward",      reagents: ["bone", "aether"],              result: "talisman"  },
        { id: "lamp",      reagents: ["ember", "quicksilver"],        result: "lantern"   },
        { id: "compass",   reagents: ["lodestone", "feather"],        result: "ring"      },
        { id: "elixir",    reagents: ["herb", "dew", "aether"],       result: "horn"      },
        { id: "antivenin", reagents: ["venom", "herb", "salt"],       result: "phial"     },
        { id: "eclipse",   reagents: ["umbra", "ash", "quicksilver"], result: "mirror"    },
    ];
    return _r;
}

/// Convenience: build an atelier with the starter book already registered.
/// DELETE-ME in a buyer's project — register your own recipes instead.
function ath_starter_atelier() {
    var _at   = ath_atelier_create();
    var _book = ath_starter_recipes();
    for (var _i = 0; _i < array_length(_book); _i++) {
        ath_atelier_register(_at, _book[_i]);
    }
    return _at;
}

/// The tincture a reagent family reads in by default. Purely a presentation choice: any glyph can
/// be drawn in any of the 6 tinctures, and this is just a pleasant default mapping for the demo
/// and for buyers who do not want to choose. Grouped by material family, not by index.
function ath_default_tincture(_motif_id) {
    switch (_motif_id) {
        case "herb": case "root": case "spore": case "bloom": case "bark":
            return 0;   // Verdant
        case "ember": case "ash": case "ore": case "resin":
            return 1;   // Cinder
        case "dew": case "brine": case "ichor": case "silk":
            return 2;   // Tidal
        case "crystal": case "salt": case "dust": case "lodestone":
            return 3;   // Auric
        case "venom": case "aether": case "quicksilver":
            return 4;   // Violet
        default:
            return 5;   // Umbral — bone, chitin, feather, umbra
    }
}
