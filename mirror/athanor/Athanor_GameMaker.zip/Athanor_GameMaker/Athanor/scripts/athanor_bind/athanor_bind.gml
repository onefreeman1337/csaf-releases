/// ============================================================================================
/// ATHANOR · athanor_bind — the engine binding.
///
/// Everything impure lives here: the clock, the atelier's mutable state, and the save/load
/// round-trip. athanor_core stays a pure function library so it can be mirrored and reasoned
/// about; this file is where Athanor meets a running game.
///
/// ⛔ THE delta_time CONVERSION HAPPENS IN EXACTLY ONE PLACE — `__ath_dt()`.
///   GameMaker's delta_time is MICROSECONDS. Dividing by 1000 instead of 1,000,000 yields
///   animations that run 1000x fast, which reads as "the effect just pops" rather than as a bug.
///   This wing has hit that trap before. One conversion, one place, never inline.
///
/// SAVE FORMAT — versioned from day one.
///   ath_atelier_save() emits a struct carrying ATH_VERSION and the discovery map keyed by the
///   seal key (a sorted, order-insensitive reagent list). Keying on the SET rather than on a
///   recipe index means a buyer can reorder or renumber their recipe table between builds without
///   invalidating a player's save.
///
/// Public API:
///   ath_atelier_create()                     -> a new atelier
///   ath_atelier_register(at, recipe)         -> add a recipe { id, reagents[], result }
///   ath_atelier_step(at)                     -> advance animation (call once per step)
///   ath_atelier_attempt(at, bag)             -> try to synthesise from a bag of reagent ids
///   ath_atelier_state(at, recipe)            -> ATH_STATE_* for one recipe
///   ath_atelier_hint(at, recipe)             -> mark a recipe GLIMPSED
///   ath_atelier_save(at) / ath_atelier_load(at, data)
/// ============================================================================================

/// The ONLY microseconds -> seconds conversion in Athanor.
function __ath_dt() {
    return delta_time / 1000000;
}

function ath_atelier_create() {
    return {
        recipes:   [],      // array of { id, reagents[], result, seal }
        discovery: {},      // seal key -> ATH_STATE_*
        anim_t:    0,       // 0..1 reveal for the synthesis animation
        anim_on:   false,
        last_seal: undefined,
        last_ok:   false,
    };
}

/// Register a recipe. `_recipe` is { id, reagents:[motif ids], result:"vessel id" }.
/// The composed seal is computed once here rather than per frame — it is a pure function of the
/// reagent set, so caching it is safe and it is the expensive part.
function ath_atelier_register(_at, _recipe) {
    var _r = {
        id:       _recipe.id,
        reagents: _recipe.reagents,
        result:   _recipe.result,
        seal:     ath_seal_compose(_recipe.reagents),
    };
    array_push(_at.recipes, _r);
    if (!variable_struct_exists(_at.discovery, _r.seal.key)) {
        variable_struct_set(_at.discovery, _r.seal.key, ATH_STATE_UNKNOWN);
    }
    return _r;
}

/// Advance the synthesis animation. Call once per step from the buyer's controller.
function ath_atelier_step(_at) {
    if (!_at.anim_on) { return; }
    _at.anim_t += __ath_dt() / 1.6;          // a full reveal takes 1.6 seconds
    if (_at.anim_t >= 1) {
        _at.anim_t  = 1;
        _at.anim_on = false;
    }
}

function ath_atelier_state(_at, _recipe) {
    var _k = _recipe.seal.key;
    return variable_struct_exists(_at.discovery, _k)
        ? variable_struct_get(_at.discovery, _k)
        : ATH_STATE_UNKNOWN;
}

function ath_atelier_hint(_at, _recipe) {
    var _k = _recipe.seal.key;
    variable_struct_set(_at.discovery, _k, ath_discover(ath_atelier_state(_at, _recipe), "hint"));
}

/// Attempt a synthesis from a bag of reagent ids.
/// Returns { ok, recipe, seal }. On success the recipe becomes KNOWN and the reveal animation
/// starts from zero.
function ath_atelier_attempt(_at, _bag) {
    var _n = array_length(_at.recipes);
    for (var _i = 0; _i < _n; _i++) {
        var _r = _at.recipes[_i];
        if (ath_recipe_match(_r, _bag)) {
            variable_struct_set(_at.discovery, _r.seal.key,
                ath_discover(ath_atelier_state(_at, _r), "synthesise"));
            _at.last_seal = _r.seal;
            _at.last_ok   = true;
            _at.anim_t    = 0;
            _at.anim_on   = true;
            return { ok: true, recipe: _r, seal: _r.seal };
        }
    }
    // A failed attempt still draws: the bag's own composed seal, which is how a player learns
    // that a combination is real but not a recipe. The picture is the feedback.
    _at.last_seal = ath_seal_compose(_bag);
    _at.last_ok   = false;
    _at.anim_t    = 0;
    _at.anim_on   = true;
    return { ok: false, recipe: undefined, seal: _at.last_seal };
}

/// Versioned save. Keyed by seal key (a sorted reagent set), so renumbering recipes between
/// builds cannot invalidate a player's progress.
function ath_atelier_save(_at) {
    var _keys = variable_struct_get_names(_at.discovery);
    var _out  = {};
    for (var _i = 0; _i < array_length(_keys); _i++) {
        variable_struct_set(_out, _keys[_i], variable_struct_get(_at.discovery, _keys[_i]));
    }
    return { version: ATH_VERSION, discovery: _out };
}

/// Load a save. Unknown keys are kept rather than dropped: a player who had discovered a recipe
/// that a later build renamed keeps the entry, and it costs nothing to carry.
function ath_atelier_load(_at, _data) {
    if (!is_struct(_data) || !variable_struct_exists(_data, "discovery")) { return false; }
    var _d    = variable_struct_get(_data, "discovery");
    var _keys = variable_struct_get_names(_d);
    for (var _i = 0; _i < array_length(_keys); _i++) {
        variable_struct_set(_at.discovery, _keys[_i], variable_struct_get(_d, _keys[_i]));
    }
    return true;
}
