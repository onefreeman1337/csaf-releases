/// ATHANOR demo — Clean Up.
/// The demo allocates no sprites, surfaces or data structures — every effect is plain structs
/// and arrays, which GameMaker garbage-collects. Nothing to free. (Kept because a demo that
/// LOOKS like it skipped cleanup teaches the wrong habit; if you add surfaces, free them here.)
