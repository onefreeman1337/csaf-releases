/// ATHANOR demo — Step.  DEMO SCAFFOLDING, NOT PRODUCT.

// Deterministic demo clock. A fixed increment rather than delta_time so an unattended capture
// produces byte-identical frames on a slow machine and a fast one.
if (!still_mode) { sim_t += 1 / 60; }
frame_count++;

// Advance the product's own animation (the one delta_time consumer, inside athanor_bind).
ath_atelier_step(atelier);

// DISCOVERY page loops its reveal so the GIF has no dead frames — but HOLDS the completed
// state first, because the ignited seal + result vessel is the payoff and re-triggering on the
// very next frame gave it exactly one frame of screen time (found by looking at the capture).
if (page == 2 && !atelier.anim_on && !still_mode) {
    if (atelier.anim_t >= 1) {
        reveal_hold += 1;
        if (reveal_hold >= 75) {            // ~1.25 s at 60fps
            reveal_hold = 0;
            ath_atelier_attempt(atelier, demo_recipe.reagents);
        }
    }
}

// SEALS / SHELF pages drift the selection so a still capture at any frame is interesting.
if (!still_mode) {
    selected = floor(sim_t * 0.6) % array_length(atelier.recipes);
}

// --- page keys ---------------------------------------------------------------------------------
if (keyboard_check_pressed(ord("1"))) { page = 0; }
if (keyboard_check_pressed(ord("2"))) { page = 1; }
if (keyboard_check_pressed(ord("3"))) { page = 2; }
if (keyboard_check_pressed(ord("4"))) { page = 3; }
if (keyboard_check_pressed(ord("5"))) { page = 4; }
if (keyboard_check_pressed(vk_escape)) { game_end(); }

// Unattended capture: exit cleanly after N frames.
if (quit_after > 0 && frame_count >= quit_after) { game_end(); }
