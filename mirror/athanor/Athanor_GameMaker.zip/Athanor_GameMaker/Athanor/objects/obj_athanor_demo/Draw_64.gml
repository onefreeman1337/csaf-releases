/// ATHANOR demo — Draw GUI.  DEMO SCAFFOLDING, NOT PRODUCT.
/// Every mark on screen is drawn by athanor_render from athanor_core data. No sprites anywhere.

var _W = display_get_gui_width();
var _H = display_get_gui_height();
var _th = theme;

// --- background + chrome (custom, deliberately nothing like stock GameMaker) --------------------
draw_set_colour(ath_colour(_th.bg));
draw_set_alpha(1);
draw_rectangle(0, 0, _W, _H, false);

draw_set_font(fnt_athanor_title);
draw_set_colour(ath_colour(_th.text));
draw_set_halign(fa_left);
draw_set_valign(fa_top);

var _titles = ["THE REAGENT SHELF", "THE ATELIER", "TRANSMUTATION", "COMPOSED SEALS", "RESULT VESSELS"];
var _subs = [
    "24 hand-authored families x 6 tinctures = 144 glyphs. Every mark drawn from primitives - no sprite, no atlas.",
    "Recipe book, reagent shelf, and the seal composed from the selected recipe's own constituents.",
    "The circle draws itself: arcs divide, constituent marks stroke in, the union figure ignites.",
    "Every recipe generates its own seal. 276 pairwise combinations before triples.",
    "20 result vessel families, drawn by the same renderer as everything else.",
];
draw_text(_th.pad, _th.pad - 6, _titles[page]);

draw_set_font(fnt_athanor);
draw_set_colour(ath_colour(_th.text_dim));
draw_text(_th.pad, _th.pad + 30, _subs[page]);

draw_set_colour(ath_colour(_th.rule));
draw_line(_th.pad, _th.pad + 58, _W - _th.pad, _th.pad + 58);

var _top = _th.pad + 82;

switch (page) {

// ── 0 · SHELF — the volume shot ────────────────────────────────────────────────────────────────
case 0: {
    var _cols = 24;
    var _rows = 6;
    var _cw   = (_W - _th.pad * 2) / _cols;
    var _chh  = (_H - _top - _th.pad) / _rows;
    var _size = min(_cw, _chh) * 0.86;
    for (var _r = 0; _r < _rows; _r++) {
        for (var _c = 0; _c < _cols; _c++) {
            ath_draw_glyph(motifs[_c],
                _th.pad + _cw * (_c + 0.5),
                _top + _chh * (_r + 0.5),
                _size, tinctures[_r], 1);
        }
    }
} break;

// ── 1 · ATELIER — book + shelf + the selected recipe's seal ────────────────────────────────────
case 1: {
    var _bookW = 420;
    // recipe book panel
    draw_set_colour(ath_colour(_th.panel));
    draw_rectangle(_th.pad, _top, _th.pad + _bookW, _H - _th.pad, false);
    draw_set_colour(ath_colour(_th.rule));
    draw_rectangle(_th.pad, _top, _th.pad + _bookW, _H - _th.pad, true);

    var _n = array_length(atelier.recipes);
    for (var _i = 0; _i < _n; _i++) {
        var _rc = atelier.recipes[_i];
        var _st = ath_atelier_state(atelier, _rc);
        var _y  = _top + 14 + _i * _th.rowH;
        if (_i == selected) {
            draw_set_colour(ath_colour(_th.rule));
            draw_rectangle(_th.pad + 4, _y - 4, _th.pad + _bookW - 4, _y + _th.rowH - 10, false);
        }
        // the recipe's own seal as its book icon
        ath_draw_seal(_rc.seal, _th.pad + 34, _y + 12, 40,
            tinctures[ath_default_tincture(_rc.reagents[0])],
            (_st == ATH_STATE_UNKNOWN) ? 0.18 : 1, 1);

        draw_set_font(fnt_athanor);
        draw_set_colour(ath_colour((_st == ATH_STATE_KNOWN) ? _th.text : _th.text_dim));
        var _label = (_st == ATH_STATE_UNKNOWN) ? "- - -" : _rc.id;
        draw_text(_th.pad + 66, _y + 2, _label);
        draw_set_colour(ath_colour(_th.text_dim));
        var _states = ["unknown", "glimpsed", "known"];
        draw_text(_th.pad + _bookW - 92, _y + 2, _states[_st]);
    }

    // the selected recipe, large
    var _sel = atelier.recipes[selected];
    var _cx  = _th.pad + _bookW + (_W - _th.pad - (_th.pad + _bookW)) * 0.5;
    var _cy  = _top + (_H - _th.pad - _top) * 0.5;
    ath_draw_seal(_sel.seal, _cx, _cy, 340,
        tinctures[ath_default_tincture(_sel.reagents[0])], 1, 1);

    // its constituents along the bottom
    var _rn = array_length(_sel.reagents);
    for (var _i = 0; _i < _rn; _i++) {
        var _mi = ath_motif_find(_sel.reagents[_i]);
        if (_mi < 0) { continue; }
        ath_draw_glyph(motifs[_mi],
            _cx + (_i - (_rn - 1) * 0.5) * 92,
            _H - _th.pad - 52, 62,
            tinctures[ath_default_tincture(_sel.reagents[_i])], 1);
    }
} break;

// ── 2 · DISCOVERY — the synthesis animation ────────────────────────────────────────────────────
case 2: {
    var _cx = _W * 0.5;
    var _cy = _top + (_H - _th.pad - _top) * 0.5;
    ath_draw_seal(demo_recipe.seal, _cx, _cy, 460,
        tinctures[ath_default_tincture(demo_recipe.reagents[0])], 1, atelier.anim_t);

    // the resolved vessel, once the union has ignited
    if (atelier.anim_t >= 1) {
        var _vi = -1;
        for (var _i = 0; _i < array_length(vessels); _i++) {
            if (vessels[_i].id == demo_recipe.result) { _vi = _i; }
        }
        if (_vi >= 0) {
            ath_draw_glyph(vessels[_vi], _cx, _cy, 120, tinctures[3], 1);
        }
    }
} break;

// ── 3 · SEALS — they differ, and that is the claim ─────────────────────────────────────────────
case 3: {
    var _cols = 6;
    var _rows = 2;
    var _cw   = (_W - _th.pad * 2) / _cols;
    var _chh  = (_H - _top - _th.pad) / _rows;
    var _size = min(_cw, _chh) * 0.80;
    var _n    = array_length(atelier.recipes);
    for (var _i = 0; _i < _n && _i < _cols * _rows; _i++) {
        var _rc = atelier.recipes[_i];
        ath_draw_seal(_rc.seal,
            _th.pad + _cw * ((_i % _cols) + 0.5),
            _top + _chh * (floor(_i / _cols) + 0.5),
            _size, tinctures[ath_default_tincture(_rc.reagents[0])], 1, 1);
    }
} break;

// ── 4 · VESSELS ────────────────────────────────────────────────────────────────────────────────
case 4: {
    var _cols = 10;
    var _rows = 2;
    var _cw   = (_W - _th.pad * 2) / _cols;
    var _chh  = (_H - _top - _th.pad) / _rows;
    var _size = min(_cw, _chh) * 0.80;
    for (var _i = 0; _i < array_length(vessels); _i++) {
        ath_draw_glyph(vessels[_i],
            _th.pad + _cw * ((_i % _cols) + 0.5),
            _top + _chh * (floor(_i / _cols) + 0.5),
            _size, tinctures[_i % array_length(tinctures)], 1);
    }
} break;

}

// --- blend-state leak probe --------------------------------------------------------------------
// Drawn LAST and stock-plain on purpose. If athanor_render ever leaked bm_add or an alpha, this
// bar renders wrong — it is the visual assertion for the restore-state rule, and it is the kind
// of bug that only shows up in a buyer's project.
draw_set_colour(c_white);
draw_set_alpha(1);
draw_rectangle(_W - _th.pad - 60, _H - 18, _W - _th.pad, _H - 10, false);
