/// ATHANOR demo — Create.
/// ============================================================================================
/// DEMO SCAFFOLDING, NOT PRODUCT. Everything in obj_athanor_demo exists so the product can be
/// seen: five showcase pages, deterministic motion (every position is a pure function of the
/// demo clock), and a command-line parser so unattended captures are reproducible. Copy the
/// ath_* CALLS into your game; delete the rest.
///
/// Pages (keys 1-5, or launch with -page N):
///   0 SHELF     the 144-glyph reagent wall — 24 families x 6 tinctures, all drawn, no sprites
///   1 ATELIER   the bench: recipe book, reagent shelf, and the seal for the selected recipe
///   2 DISCOVERY the synthesis animation resolving a seal — the money shot / the GIF
///   3 SEALS     a gallery of composed recipe seals, showing they differ from one another
///   4 VESSELS   the 20 result vessel families
/// Other args: -still (freeze the demo clock for stills), -quit N (exit after N frames).
/// ============================================================================================

window_set_caption("Athanor — synthesis & transmutation for GameMaker");

// --- command line ---------------------------------------------------------------------------
page = 0;
still_mode = false;
quit_after = -1;
var _pc = parameter_count();
for (var _i = 1; _i < _pc; _i++) {
    var _p = parameter_string(_i);
    if (_p == "-page" && _i + 1 < _pc) { page = clamp(real(parameter_string(_i + 1)), 0, 4); _i++; }
    else if (_p == "-still") { still_mode = true; }
    else if (_p == "-quit" && _i + 1 < _pc) { quit_after = real(parameter_string(_i + 1)); _i++; }
}

frame_count = 0;
reveal_hold = 0;         // frames spent resting on the completed reveal before it loops
sim_t = 0;               // demo clock, seconds — every moving thing below is a function of it

// --- the product ------------------------------------------------------------------------------
// Two calls. This is the whole integration surface for a buyer.
atelier = ath_starter_atelier();
book    = ath_atelier_hint;      // referenced so the hint API is exercised below

motifs   = ath_motif_table();
vessels  = ath_vessel_table();
tinctures = ath_tincture_table();
theme    = ath_theme();

// DISCOVERY page: pre-select a recipe and loop its reveal.
demo_recipe_ix = 9;              // "elixir" — a triple, so the seal has 3 wedges
demo_recipe    = atelier.recipes[demo_recipe_ix];

// Glimpse a few recipes so the book shows all three discovery states at once.
ath_atelier_hint(atelier, atelier.recipes[1]);
ath_atelier_hint(atelier, atelier.recipes[4]);
ath_atelier_hint(atelier, atelier.recipes[7]);
// And mark two as fully known.
ath_atelier_attempt(atelier, ["herb", "dew"]);
ath_atelier_attempt(atelier, ["ore", "ember"]);

selected = 0;
