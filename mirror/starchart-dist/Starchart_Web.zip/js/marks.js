/**
 * marks.js — STARCHART's star-mark generator.
 *
 * ⚠️ THIS FILE IS THE PRODUCT'S MOAT, AND THAT IS A MEASURED CLAIM, NOT A POSE.
 *
 * The only product this factory has ever sold is Meridian, whose value was 60
 * hand-authored motifs x 8 palettes = 480 generated node marks with NO PNG
 * anywhere. Master CLAUDE.md §1.1: "An LLM writes the rules of a skill tree in
 * an afternoon... it does NOT cheaply produce sixty motifs that cohere into one
 * visual language. The volume IS the moat, and it is the first thing throughput
 * pressure destroys."
 *
 * So this file is built FIRST, before any run loop, and it is judged by looking
 * at its contact sheet. If the sheet does not read as ONE visual language, the
 * product stops here rather than shipping a thin roguelite with a gimmick.
 *
 * 48 recipes x 8 palettes = 384 distinct rendered marks. Not one raster asset.
 *
 * DESIGN RULES that keep 48 recipes coherent instead of merely numerous:
 *   · One shared skeleton — every mark is core + corona + rays + sigil. Families
 *     differ by which layer DOMINATES, never by inventing new layers.
 *   · One shared light model — everything glows outward from the core, additive.
 *   · Palette is applied, never baked. A mark must read in all 8.
 *   · Every parameter is DERIVED FROM THE RECIPE INDEX, so the set is stable and
 *     reproducible — no Math.random() anywhere in this file. A star that redraws
 *     differently on reload is not a star, it is a bug (and it would also break
 *     the atlas, which must render identically forever).
 *
 * Pure, dependency-free, and used by the game itself as well as by the contact
 * sheet — one implementation, so what you judge is what ships.
 */
'use strict';

/* ---------------------------------------------------------------------------
 * PALETTES — 8 nebula families. Each must carry every one of the 48 recipes.
 * ------------------------------------------------------------------------- */
const PALETTES = [
  { id: 'ember',    core: '#ffd9a0', mid: '#ff9b3d', edge: '#c2410c', halo: '#ff7a18' },
  { id: 'cyan',     core: '#d6fbff', mid: '#5fd8f0', edge: '#0e7490', halo: '#22d3ee' },
  { id: 'orchid',   core: '#f7dcff', mid: '#c77dff', edge: '#6d28d9', halo: '#a855f7' },
  { id: 'verdant',  core: '#e4ffd9', mid: '#86e05a', edge: '#3f6212', halo: '#65d420' },
  { id: 'ash',      core: '#f2f4f7', mid: '#aab4c4', edge: '#475569', halo: '#94a3b8' },
  { id: 'rose',     core: '#ffe1e6', mid: '#ff7d96', edge: '#9f1239', halo: '#fb5f7d' },
  { id: 'amber',    core: '#fff4cc', mid: '#f2c14e', edge: '#8a5a00', halo: '#ffc93c' },
  { id: 'abyss',    core: '#dce6ff', mid: '#6f8cf5', edge: '#1e2a78', halo: '#4f6bf0' },
];

/* ---------------------------------------------------------------------------
 * FAMILIES — 6 x 8 variants = 48. The family decides which layer dominates.
 * ------------------------------------------------------------------------- */
const FAMILIES = [
  { id: 'core',    label: 'Cores',    coreScale: 1.00, coronaRings: 0, rayLen: 0.00, sigilWeight: 0.25 },
  { id: 'corona',  label: 'Coronae',  coreScale: 0.58, coronaRings: 3, rayLen: 0.18, sigilWeight: 0.15 },
  { id: 'radiant', label: 'Radiants', coreScale: 0.50, coronaRings: 1, rayLen: 1.00, sigilWeight: 0.10 },
  { id: 'binary',  label: 'Binaries', coreScale: 0.62, coronaRings: 1, rayLen: 0.30, sigilWeight: 0.20 },
  // ⚠️ Nebulae: coronaRings 4 -> 1 and rayLen 0.22 -> 0 on 2026-08-17. The first
  // contact sheet showed the family collapsing to "soft blob + rings + short
  // spikes" — indistinguishable from a softened Corona. Its corona layer is now
  // rendered as DRIFTING FILAMENT ARMS (see drawMark), which is the family's own
  // differentiator rather than a removal of geometry.
  { id: 'nebular', label: 'Nebulae',  coreScale: 0.44, coronaRings: 1, rayLen: 0.00, sigilWeight: 0.08 },
  { id: 'ancient', label: 'Ancients', coreScale: 0.70, coronaRings: 1, rayLen: 0.42, sigilWeight: 1.00 },
];

const SIGILS = ['none', 'dot', 'bar', 'cross', 'arc', 'triangle', 'ring', 'chevron'];

/**
 * Build the full deterministic recipe table: 48 entries, index 0..47.
 * Every value is a pure function of (familyIndex, variantIndex).
 */
function buildRecipes() {
  const out = [];
  for (let f = 0; f < FAMILIES.length; f++) {
    const fam = FAMILIES[f];
    for (let v = 0; v < 8; v++) {
      // Spread structural properties across the 8 variants so a family reads as
      // a family (shared dominance) while no two members are the same picture.
      //
      // ⚠️ DECORRELATED FROM `v` ON PURPOSE. The first cut derived every one of
      // these from the variant index alone, which meant variant 0 of ALL SIX
      // families was a 3-point core, variant 4 always a 7-point, and so on — so
      // any cross-family comparison at a fixed variant looked repetitive, and
      // the palette contact sheet (which sampled variant 0 six times) rendered
      // six columns that were near-identical. Caught by LOOKING at the sheet,
      // not by any counter: ink coverage read 98-100% throughout, i.e. the
      // metric was pinned at its ceiling and discriminating nothing.
      // Offsetting by the family index breaks the lockstep while keeping the
      // whole table deterministic.
      const k = v + f * 3;
      const points = 3 + (k % 6);                 // 3..8 point core
      const rayCount = 4 + ((k * 3) % 9);           // 4..12 rays
      const rot = (k * Math.PI) / 8;
      const inset = 0.34 + 0.06 * (k % 4);          // star-polygon waist
      const isNeb = fam.id === 'nebular';
      out.push({
        index: out.length,
        family: fam.id,
        familyLabel: fam.label,
        variant: v,
        name: fam.label.replace(/e?s$/, '') + '-' + String(v + 1).padStart(2, '0'),
        points,
        rayCount,
        rot,
        inset,
        coreScale: fam.coreScale * (0.86 + 0.04 * (v % 5)),
        coronaRings: fam.coronaRings,
        rayLen: fam.rayLen * (0.80 + 0.06 * (v % 4)),
        sigil: fam.sigilWeight > 0.5
          ? SIGILS[1 + (k % (SIGILS.length - 1))]     // Ancients always carry one
          : (k % 3 === 0 ? SIGILS[1 + (k % (SIGILS.length - 1))] : 'none'),
        sigilWeight: fam.sigilWeight,
        binary: fam.id === 'binary',
        softness: isNeb ? 1 : 0,
        // Nebulae differentiator (2026-08-17): 2..4 drifting filament arms, each
        // with its own twist and drift direction, plus asymmetric core density.
        filaments: isNeb ? 2 + (k % 3) : 0,
        filamentTwist: isNeb ? 0.55 + 0.22 * (k % 4) : 0,
        filamentDir: isNeb ? (k % 2 === 0 ? 1 : -1) : 0,
        // Cores second layer (2026-08-17): inner facet + vertex glints + limb
        // highlight, so the family survives below ~40px instead of converging
        // to "polygon". Scoped to the core family — other families' cores stay
        // plain so family identity is preserved.
        coreDetail: fam.id === 'core' ? 1 : 0,
      });
    }
  }
  return out;
}

const RECIPES = buildRecipes();

/* ------------------------------- primitives ------------------------------ */

/**
 * Deterministic 0..1 "noise" from an integer — sin-fract hash, no state, no
 * Math.random(). Used only for filament drift and dust stipple, so a nebula's
 * wisps look organic while rendering identically forever.
 */
function hash01(n) {
  const s = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return s - Math.floor(s);
}

function starPath(ctx, cx, cy, r, points, inset, rot) {
  ctx.beginPath();
  const n = points * 2;
  for (let i = 0; i < n; i++) {
    const rr = i % 2 === 0 ? r : r * inset * 2;
    const a = rot + (i * Math.PI) / points - Math.PI / 2;
    const x = cx + Math.cos(a) * rr;
    const y = cy + Math.sin(a) * rr;
    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  }
  ctx.closePath();
}

function drawSigil(ctx, cx, cy, r, kind, color, weight) {
  if (kind === 'none') return;
  ctx.save();
  ctx.strokeStyle = color;
  ctx.fillStyle = color;
  ctx.lineWidth = Math.max(1, r * 0.10 * (0.6 + weight));
  ctx.lineCap = 'round';
  const s = r * 0.44;
  ctx.beginPath();
  switch (kind) {
    case 'dot':      ctx.arc(cx, cy, s * 0.34, 0, Math.PI * 2); ctx.fill(); break;
    case 'bar':      ctx.moveTo(cx - s, cy); ctx.lineTo(cx + s, cy); ctx.stroke(); break;
    case 'cross':    ctx.moveTo(cx - s, cy); ctx.lineTo(cx + s, cy);
                     ctx.moveTo(cx, cy - s); ctx.lineTo(cx, cy + s); ctx.stroke(); break;
    case 'arc':      ctx.arc(cx, cy, s, Math.PI * 0.15, Math.PI * 0.85); ctx.stroke(); break;
    case 'triangle': ctx.moveTo(cx, cy - s); ctx.lineTo(cx + s, cy + s * 0.8);
                     ctx.lineTo(cx - s, cy + s * 0.8); ctx.closePath(); ctx.stroke(); break;
    case 'ring':     ctx.arc(cx, cy, s * 0.8, 0, Math.PI * 2); ctx.stroke(); break;
    case 'chevron':  ctx.moveTo(cx - s, cy + s * 0.4); ctx.lineTo(cx, cy - s * 0.5);
                     ctx.lineTo(cx + s, cy + s * 0.4); ctx.stroke(); break;
  }
  ctx.restore();
}

/**
 * Draw one mark. `size` is the full box; the mark is centred and fits inside.
 * Additive glow throughout, so marks sit on a dark chart without haloes clashing.
 */
function drawMark(ctx, recipe, palette, cx, cy, size, opts) {
  const o = opts || {};
  const R = size * 0.5;
  const p = palette;

  ctx.save();
  ctx.globalCompositeOperation = o.flat ? 'source-over' : 'lighter';

  // --- outer halo -------------------------------------------------------
  const haloR = R * (0.92 + 0.20 * recipe.softness);
  const halo = ctx.createRadialGradient(cx, cy, R * 0.05, cx, cy, haloR);
  halo.addColorStop(0, hexA(p.halo, recipe.softness ? 0.34 : 0.26));
  halo.addColorStop(0.55, hexA(p.halo, 0.10));
  halo.addColorStop(1, hexA(p.halo, 0));
  ctx.fillStyle = halo;
  ctx.beginPath(); ctx.arc(cx, cy, haloR, 0, Math.PI * 2); ctx.fill();

  // --- rays -------------------------------------------------------------
  if (recipe.rayLen > 0.01) {
    ctx.save();
    ctx.strokeStyle = hexA(p.mid, 0.72);
    ctx.lineCap = 'round';
    for (let i = 0; i < recipe.rayCount; i++) {
      const a = recipe.rot + (i / recipe.rayCount) * Math.PI * 2;
      // Alternating long/short rays give a silhouette that survives at 24px.
      const len = R * recipe.rayLen * (i % 2 === 0 ? 0.95 : 0.58);
      const inner = R * recipe.coreScale * 0.62;
      ctx.lineWidth = Math.max(0.8, R * 0.055 * (i % 2 === 0 ? 1 : 0.66));
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(a) * inner, cy + Math.sin(a) * inner);
      ctx.lineTo(cx + Math.cos(a) * (inner + len), cy + Math.sin(a) * (inner + len));
      ctx.stroke();
    }
    ctx.restore();
  }

  // --- nebular filament arms --------------------------------------------
  // The Nebulae family's own linework: 2..4 spiral wisps drifting out of the
  // core, tapering and fading, with a dust stipple riding each arm. Uneven arm
  // spacing (hash-jittered) gives the asymmetric density a real nebula has.
  if (recipe.filaments) {
    ctx.save();
    ctx.lineCap = 'round';
    for (let arm = 0; arm < recipe.filaments; arm++) {
      const base = recipe.rot + (arm / recipe.filaments) * Math.PI * 2 +
                   hash01(recipe.index * 7 + arm) * 0.9;
      const SEG = 22;
      for (let s = 0; s < SEG; s++) {
        const t0 = s / SEG, t1 = (s + 1) / SEG;
        const r0 = R * (0.28 + t0 * 0.64);
        const r1 = R * (0.28 + t1 * 0.64);
        const a0 = base + recipe.filamentDir * recipe.filamentTwist * t0 * Math.PI;
        const a1 = base + recipe.filamentDir * recipe.filamentTwist * t1 * Math.PI;
        ctx.strokeStyle = hexA(p.mid, 0.40 * (1 - t0) + 0.05);
        ctx.lineWidth = Math.max(0.8, R * 0.085 * (1 - t0 * 0.72));
        ctx.beginPath();
        ctx.moveTo(cx + Math.cos(a0) * r0, cy + Math.sin(a0) * r0);
        ctx.lineTo(cx + Math.cos(a1) * r1, cy + Math.sin(a1) * r1);
        ctx.stroke();
      }
      // dust stipple riding the arm
      for (let d = 0; d < 8; d++) {
        const t = hash01(recipe.index * 31 + arm * 9 + d);
        const rr = R * (0.32 + t * 0.60);
        const an = base + recipe.filamentDir * recipe.filamentTwist * t * Math.PI +
                   (hash01(recipe.index * 53 + arm * 17 + d) - 0.5) * 0.5;
        const dr = R * (0.014 + 0.022 * hash01(recipe.index * 71 + arm * 5 + d));
        ctx.fillStyle = hexA(p.core, 0.55 * (1 - t) + 0.12);
        ctx.beginPath();
        ctx.arc(cx + Math.cos(an) * rr, cy + Math.sin(an) * rr, dr, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.restore();
  }

  // --- corona rings -----------------------------------------------------
  for (let i = 0; i < recipe.coronaRings; i++) {
    const t = (i + 1) / (recipe.coronaRings + 1);
    const rr = R * (0.42 + t * 0.52);
    ctx.strokeStyle = hexA(p.mid, 0.40 - t * 0.16);
    ctx.lineWidth = Math.max(0.7, R * (0.045 - t * 0.012));
    ctx.beginPath(); ctx.arc(cx, cy, rr, 0, Math.PI * 2); ctx.stroke();
  }

  // --- core -------------------------------------------------------------
  const coreR = R * recipe.coreScale * 0.62;
  const bodies = recipe.binary
    ? [[cx - coreR * 0.52, cy, coreR * 0.74], [cx + coreR * 0.62, cy, coreR * 0.52]]
    : [[cx, cy, coreR]];

  for (const [bx, by, br] of bodies) {
    // Nebulae: the luminous center drifts off-axis (asymmetric density) —
    // a nebula lit evenly from its middle is a lamp, not a cloud.
    const offR = recipe.softness ? br * 0.24 : 0;
    const offA = recipe.rot * 1.7;
    const gx = bx + Math.cos(offA) * offR;
    const gy = by + Math.sin(offA) * offR;
    const g = ctx.createRadialGradient(gx, gy, br * 0.08, bx, by, br);
    g.addColorStop(0, p.core);
    g.addColorStop(0.5, p.mid);
    g.addColorStop(1, hexA(p.edge, recipe.softness ? 0.35 : 0.85));
    ctx.fillStyle = g;
    if (recipe.softness) {
      ctx.beginPath(); ctx.arc(bx, by, br, 0, Math.PI * 2); ctx.fill();
    } else {
      starPath(ctx, bx, by, br, recipe.points, recipe.inset, recipe.rot);
      ctx.fill();
    }
  }

  // --- core second layer (Cores family only) ----------------------------
  // Bright-only detail (additive mode cannot draw dark): a counter-rotated
  // inner facet outline, glints at the outer vertices, and an off-axis limb
  // highlight clipped to the disc. This is what keeps a Core reading as a
  // cut gem rather than "polygon" below ~40px.
  if (recipe.coreDetail) {
    ctx.save();
    // limb highlight, clipped inside the star polygon
    const la = recipe.rot * 2.3;
    const lx = cx + Math.cos(la) * coreR * 0.45;
    const ly = cy + Math.sin(la) * coreR * 0.45;
    starPath(ctx, cx, cy, coreR, recipe.points, recipe.inset, recipe.rot);
    ctx.clip();
    const lg = ctx.createRadialGradient(lx, ly, coreR * 0.04, lx, ly, coreR * 0.75);
    lg.addColorStop(0, 'rgba(255,255,255,0.34)');
    lg.addColorStop(0.5, 'rgba(255,255,255,0.10)');
    lg.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = lg;
    ctx.beginPath(); ctx.arc(lx, ly, coreR * 0.8, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    // inner facet — counter-rotated outline
    ctx.strokeStyle = hexA(p.core, 0.78);
    ctx.lineWidth = Math.max(0.9, coreR * 0.065);
    ctx.lineJoin = 'round';
    starPath(ctx, cx, cy, coreR * 0.55, recipe.points, recipe.inset + 0.10,
             recipe.rot + Math.PI / recipe.points);
    ctx.stroke();
    // vertex glints — survive any thumbnail
    for (let j = 0; j < recipe.points; j++) {
      const a = recipe.rot + (2 * Math.PI * j) / recipe.points - Math.PI / 2;
      ctx.fillStyle = hexA(p.core, 0.95);
      ctx.beginPath();
      ctx.arc(cx + Math.cos(a) * coreR, cy + Math.sin(a) * coreR,
              Math.max(1, coreR * 0.085), 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // --- sigil ------------------------------------------------------------
  drawSigil(ctx, cx, cy, coreR, recipe.sigil, hexA(p.core, 0.95), recipe.sigilWeight);

  ctx.restore();
}

function hexA(hex, a) {
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map(c => c + c).join('') : h, 16);
  return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
}

/** Stable lookup used by the atlas: a star id maps to exactly one picture, forever. */
function markFor(starId) {
  return {
    recipe: RECIPES[starId % RECIPES.length],
    palette: PALETTES[Math.floor(starId / RECIPES.length) % PALETTES.length],
  };
}

const API = { PALETTES, FAMILIES, RECIPES, drawMark, markFor, hexA };
if (typeof module !== 'undefined' && module.exports) module.exports = API;
if (typeof window !== 'undefined') window.StarMarks = API;
