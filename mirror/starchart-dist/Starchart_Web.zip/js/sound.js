/* =====================================================================
   sound.js — OTTERBOUND. Every sound, synthesized.

   No audio files ship with this game. Each effect is a ZzFX parameter
   set — sound as code, matching art.js's every-pixel-drawn thesis.
   The register here is wood, water and small furious mammals: wet
   plops, stone-on-scale clacks, and a low river hum under the bosses.

   Contains ZzFXMicro v1.3.2, MIT licence:
     Copyright (c) 2019 Frank Force  (github.com/KilledByAPixel/ZzFX)
     Permission is hereby granted, free of charge, to any person
     obtaining a copy of this software and associated documentation
     files (the "Software"), to deal in the Software without
     restriction, including without limitation the rights to use, copy,
     modify, merge, publish, distribute, sublicense, and/or sell copies
     of the Software. The above notice shall be included in all copies
     or substantial portions of the Software. THE SOFTWARE IS PROVIDED
     "AS IS", WITHOUT WARRANTY OF ANY KIND.
   MODIFIED here (as the MIT licence permits): the AudioContext is
   created LAZILY on the first play instead of at load — browsers block
   audio before a user gesture, and the run begins from a click, so the
   first click both creates and unlocks it. Combat sounds fired by the
   loop are safe because the loop only runs after that click.
   ===================================================================== */
'use strict';

(function (root) {

  var zzfxV = 0.28;         /* master volume */
  var zzfxX = null;         /* AudioContext — created on first play */

  /* ZzFXMicro v1.3.2 by Frank Force, MIT (see header). Reformatted only
     as far as the lazy-context change required; the algorithm is his. */
  function zzfx(p, k, b, e, r, t, q, D, u, y, v, z, l, E, A, F, c, w, m, B, N) {
    p = p === undefined ? 1 : p; k = k || .05; b = b === undefined ? 220 : b;
    e = e || 0; r = r || 0; t = t === undefined ? .1 : t; q = q || 0;
    D = D === undefined ? 1 : D; u = u || 0; y = y || 0; v = v || 0; z = z || 0;
    l = l || 0; E = E || 0; A = A || 0; F = F || 0; c = c || 0;
    w = w === undefined ? 1 : w; m = m || 0; B = B || 0; N = N || 0;
    if (!zzfxX) zzfxX = new (root.AudioContext || root.webkitAudioContext)();
    if (zzfxX.state === 'suspended') zzfxX.resume();
    var M = Math, d = 2 * M.PI, R = 44100, G = u *= 500 * d / R / R,
        C = b *= (1 - k + 2 * k * M.random(k = [])) * d / R,
        g = 0, H = 0, a = 0, n = 1, I = 0, J = 0, f = 0, h = N < 0 ? -1 : 1,
        x = d * h * N * 2 / R, L = M.cos(x), Z = M.sin, K = Z(x) / 4, O = 1 + K,
        X = -2 * L / O, Y = (1 - K) / O, P = (1 + h * L) / 2 / O, Q = -(h + L) / O,
        S = P, T = 0, U = 0, V = 0, W = 0;
    e = R * e + 9; m *= R; r *= R; t *= R; c *= R; y *= 500 * d / R ** 3;
    A *= d / R; v *= d / R; z *= R; l = R * l | 0; p *= zzfxV;
    for (h = e + m + r + t + c | 0; a < h; k[a++] = f * p)
      ++J % (100 * F | 0) || (
        f = q ? 1 < q ? 2 < q ? 3 < q ? 4 < q ?
              (g / d % 1 < D / 2) * 2 - 1 : Z(g ** 3) :
              M.max(M.min(M.tan(g), 1), -1) :
              1 - (2 * g / d % 2 + 2) % 2 :
              1 - 4 * M.abs(M.round(g / d) - g / d) : Z(g),
        f = (l ? 1 - B + B * Z(d * a / l) : 1) *
            (4 < q ? f : (f < 0 ? -1 : 1) * M.abs(f) ** D) *
            (a < e ? a / e : a < e + m ? 1 - (a - e) / m * (1 - w) :
             a < e + m + r ? w : a < h - c ? (h - a - c) / t * w : 0),
        f = c ? f / 2 + (c > a ? 0 : (a < h - c ? 1 : (h - a) / c) * k[a - c | 0] / 2 / p) : f,
        N ? f = W = S * T + Q * (T = U) + P * (U = f) - Y * V - X * (V = W) : 0),
      x = (b += u += y) * M.cos(A * H++), g += x + x * E * Z(a ** 5),
      n && ++n > z && (b += v, C += v, n = 0),
      !l || ++I % l || (b = C, u = G, n = n || 1);
    var buf = zzfxX.createBuffer(1, h, R);
    buf.getChannelData(0).set(k);
    var src = zzfxX.createBufferSource();
    src.buffer = buf;
    src.connect(zzfxX.destination);
    src.start();
  }

    /* --------------------------------------------------- the instrument */

  /*
   * STARCHART's register is GLASS AND DISTANCE, not wood and water. This is a
   * quiet chart-room game: the loudest thing that happens is a line being
   * drawn. So every sound here is a struck or bowed tone with a long tail and
   * no percussion at all — a jump is a soft bell, a hazard is a low struck
   * string, and inscribing a constellation is the only sound allowed to ring.
   *
   * The FAMILY sounds are deliberately a scale rather than six unrelated
   * noises: forge/haven/surge/wreck/nebula/shrine ascend through one chord, so
   * arriving somewhere is legible by EAR as well as by the mark's shape. That
   * is the same argument as the legend panel, one sense across.
   *
   * Audio was the wing's own named gap (Wings/GamesLite/CLAUDE.md section 4:
   * "Audio is the known gap in the first three games"). ZzFX is MIT and
   * VERIFIED — the licence text is reproduced in the header above.
   */
  var MUTE_KEY = 'starchart_mute';
  var muted = false;
  try { muted = localStorage.getItem(MUTE_KEY) === '1'; } catch (e) {}

  var BANK = {
    /* a jump: soft glass strike, long decay */
    jump:    [.45, , 523, .01, .09, .24, 1, 1.7, , , 131, .06, , , , , , .58, .06],
    /* the six star families, ascending through one chord */
    forge:   [.5, , 262, .02, .12, .3, 1, 1.3, , , 87, .07, .04, , , , , .55, .09],
    haven:   [.5, , 330, .02, .14, .32, 1, 1.4, , , 110, .07, .05, , , , , .56, .1],
    surge:   [.55, , 392, .01, .1, .28, 1, 2.1, , , 196, .05, .06, , , .12, , .6, .07],
    wreck:   [.5, .06, 220, .02, .11, .3, 2, 1.1, , , 73, .08, , .4, , .2, , .5, .09],
    nebula:  [.5, .12, 175, .04, .2, .44, 4, .9, , , , , .08, .5, , .3, .06, .46, .14],
    shrine:  [.6, , 440, .03, .22, .46, 1, 1.6, , , 147, .09, .08, , , , , .58, .16],
    /* the hull takes it — a low struck string, no crack */
    hazard:  [.7, , 98, .02, .1, .34, 2, .8, -2, , , , , .8, , .4, , .44, .1],
    /* a ward absorbs the blow — the hit, muffled */
    ward:    [.5, , 147, .03, .12, .3, 4, .7, , , , , .06, .5, , .35, .1, .4, .12],
    /* the chart keeps it: the only sound that rings */
    inscribe:[.8, , 349, .05, .34, .7, 1, 1.5, , , 116, .1, .12, , , , , .6, .24],
    /* a closed route — the seal, a fifth above inscribe */
    seal:    [.85, , 523, .05, .38, .8, 1, 1.7, , , 175, .11, .14, , , .08, , .62, .28],
    /* a route already charted, drawn heavier */
    deepen:  [.7, , 262, .05, .3, .66, 1, 1.2, , , 65, .1, .1, , , , , .56, .22],
    /* adrift — the voyage ends without a figure */
    lost:    [.7, , 131, .06, .26, .72, 2, .7, -1, , , , , .5, , .45, .1, .4, .2],
    /* casting off */
    depart:  [.55, , 196, .03, .16, .38, 1, 1.2, , , 98, .08, .06, , , , , .54, .12],
  };

  /* A player can click fast. Without this a run of quick jumps stacks tones
     into a smear; 70ms lets a fast route sound like a fast route instead. */
  var last = {};
  var LIMIT = { jump: 70, forge: 70, haven: 70, surge: 70, wreck: 70, nebula: 70, shrine: 70 };

  function play(name) {
    if (muted) return;
    var lim = LIMIT[name];
    if (lim) {
      var now = Date.now();
      if (last[name] && now - last[name] < lim) return;
      last[name] = now;
    }
    var s = BANK[name];
    if (!s) return;
    try { zzfx.apply(null, s); } catch (e) { /* audio is never fatal */ }
  }

  function toggleMute() {
    muted = !muted;
    try { localStorage.setItem(MUTE_KEY, muted ? '1' : '0'); } catch (e) {}
    return muted;
  }

  root.Sfx = { play: play, toggleMute: toggleMute, isMuted: function () { return muted; } };

})(typeof window !== 'undefined' ? window : globalThis);
