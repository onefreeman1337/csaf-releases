/**
 * atlas.js — STARCHART's atlas renderer: the artefact the player owns.
 *
 * THIS FILE IS THE GATE-2 CLAIM MADE VISIBLE. The state entry's narrowed claim
 * (checked before code, 2026-08-16): shipped analogues are authored trees the
 * player walks; here the constellation's GEOMETRY IS THE PLAYER'S OWN ROUTE —
 * vertices are the stars visited, edges the order visited. No two players own
 * the same chart, because no two players flew the same runs.
 *
 * It is also where Gate 1 is won or lost: M1's honest verdict was that 48
 * marks alone read as an icon set. The atlas composition — linework, boundary
 * dashes, generated names, chart furniture — is what turns marks into a chart
 * a player screenshots.
 *
 * DESIGN RULES:
 *   · Everything is generated and deterministic. No raster assets, no
 *     Math.random() — a chart that renders differently on reload is corrupt.
 *   · The atlas is INK ON NIGHT: one ink colour for all chart furniture, the
 *     palettes reserved for the marks and their linework. Furniture whispers;
 *     inscriptions speak.
 *   · Linework never pierces a mark — every segment stops short of both ends.
 *
 * Depends on marks.js (StarMarks). Pure canvas, dependency-free.
 */
'use strict';

(function (root, factory) {
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = factory(require('./marks.js'));
  } else {
    root.StarAtlas = factory(root.StarMarks);
  }
})(typeof self !== 'undefined' ? self : this, function (Marks) {

  const INK = '#b9c8e8';           // chart-furniture ink, one colour, whispering
  const BG = '#05070d';

  /* ---------------------- deterministic hashing ------------------------- */

  function hash01(n) {
    const s = Math.sin(n * 127.1 + 311.7) * 43758.5453;
    return s - Math.floor(s);
  }
  /** integer hash of a run (order-sensitive), for names and flourishes */
  function runHash(run) {
    let h = 2166136261 >>> 0;
    for (const s of run.stars) {
      h = Math.imul(h ^ (s.id + 1), 16777619) >>> 0;
      h = Math.imul(h ^ (Math.round(s.x) + 7), 16777619) >>> 0;
      h = Math.imul(h ^ (Math.round(s.y) + 13), 16777619) >>> 0;
    }
    return h >>> 0;
  }

  /* ---------------------- generated constellation names ----------------- */

  const SYL_A = ['Vel', 'Kor', 'Ash', 'Ori', 'Thal', 'Une', 'Syr', 'Mor',
                 'Cael', 'Ith', 'Ard', 'Ophe', 'Lyr', 'Ess', 'Vau', 'Nem'];
  const SYL_B = ['ara', 'ith', 'une', 'os', 'eth', 'ia', 'orn', 'ael',
                 'is', 'ura', 'en', 'ax', 'ir', 'ona', 'um', 'yr'];
  const EPITHETS = ['the Wanderer', 'the Oath', 'the Long Watch', 'the Crossing',
                    'the Quiet Route', 'the Deep Reach', 'the Returning',
                    'the First Light', 'the Broken Course', 'the Far Shore',
                    'the Held Line', 'the Slow Burn', 'the Night Ferry',
                    'the Last Signal', 'the Open Gate', 'the Ember Road'];
  const ROMAN = ['0', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX',
                 'X', 'XI', 'XII', 'XIII', 'XIV', 'XV', 'XVI'];

  /** Deterministic name: geometry in, the same name out, forever. */
  function nameFor(run) {
    const h = runHash(run);
    const a = SYL_A[h % SYL_A.length];
    const b = SYL_B[(h >>> 4) % SYL_B.length];
    const ep = EPITHETS[(h >>> 9) % EPITHETS.length];
    return { title: a + b, epithet: ep, numeral: ROMAN[Math.min(run.stars.length, 16)] };
  }

  /* ---------------------- geometry helpers ------------------------------ */

  /** Andrew monotone-chain convex hull. Points: [{x,y}]. */
  function hull(points) {
    const pts = points.slice().sort((p, q) => p.x - q.x || p.y - q.y);
    if (pts.length < 3) return pts;
    const cross = (o, a, b) => (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);
    const lower = [];
    for (const p of pts) {
      while (lower.length >= 2 && cross(lower[lower.length - 2], lower[lower.length - 1], p) <= 0) lower.pop();
      lower.push(p);
    }
    const upper = [];
    for (let i = pts.length - 1; i >= 0; i--) {
      const p = pts[i];
      while (upper.length >= 2 && cross(upper[upper.length - 2], upper[upper.length - 1], p) <= 0) upper.pop();
      upper.push(p);
    }
    lower.pop(); upper.pop();
    return lower.concat(upper);
  }

  function centroid(points) {
    let x = 0, y = 0;
    for (const p of points) { x += p.x; y += p.y; }
    return { x: x / points.length, y: y / points.length };
  }

  /* ---------------------- chart furniture ------------------------------- */

  /**
   * Layered value-noise nebula wash — 12 seedable backdrops (seed 0..11 in the
   * game's sectors; the atlas uses the sector's). Rendered coarse then scaled,
   * so it stays a wash rather than becoming texture that competes with ink.
   */
  function drawNebulaWash(ctx, W, H, seed, tints) {
    const GX = 24, GY = 15;
    const cellW = W / (GX - 1), cellH = H / (GY - 1);
    const val = (x, y, oct) => hash01(seed * 977 + oct * 131 + y * GX + x);
    for (let o = 0; o < 2; o++) {
      const tint = tints[o % tints.length];
      for (let gy = 0; gy < GY - 1; gy++) {
        for (let gx = 0; gx < GX - 1; gx++) {
          // bilinear-ish patch alpha from corner noise
          const v = (val(gx, gy, o) + val(gx + 1, gy, o) + val(gx, gy + 1, o) + val(gx + 1, gy + 1, o)) / 4;
          const a = Math.max(0, v - 0.62) * (o === 0 ? 0.16 : 0.10);
          if (a <= 0.004) continue;
          const cx = gx * cellW + cellW / 2 + (hash01(seed + gx * 31 + gy * 57) - 0.5) * cellW;
          const cy = gy * cellH + cellH / 2 + (hash01(seed + gx * 71 + gy * 13) - 0.5) * cellH;
          const r = Math.max(cellW, cellH) * (1.1 + v);
          const g = ctx.createRadialGradient(cx, cy, r * 0.1, cx, cy, r);
          g.addColorStop(0, Marks.hexA(tint, a));
          g.addColorStop(1, Marks.hexA(tint, 0));
          ctx.fillStyle = g;
          ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.fill();
        }
      }
    }
  }

  /** Background star dust: hundreds of pin-points, a few with cross sparkles. */
  function drawDust(ctx, W, H, seed, count) {
    for (let i = 0; i < count; i++) {
      const x = hash01(seed * 3 + i * 7.13) * W;
      const y = hash01(seed * 5 + i * 11.7) * H;
      const m = hash01(seed * 7 + i * 3.7);
      const r = 0.4 + m * 1.1;
      const a = 0.10 + m * 0.34;
      ctx.fillStyle = Marks.hexA(INK, a);
      ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
      if (m > 0.93) { // rare sparkle
        ctx.strokeStyle = Marks.hexA(INK, 0.20);
        ctx.lineWidth = 0.6;
        ctx.beginPath();
        ctx.moveTo(x - r * 4, y); ctx.lineTo(x + r * 4, y);
        ctx.moveTo(x, y - r * 4); ctx.lineTo(x, y + r * 4);
        ctx.stroke();
      }
    }
  }

  /** Polar graticule: concentric circles + radial lines, whisper-alpha. */
  function drawGraticule(ctx, W, H, cx, cy) {
    ctx.save();
    ctx.strokeStyle = Marks.hexA(INK, 0.05);
    ctx.lineWidth = 1;
    const maxR = Math.hypot(Math.max(cx, W - cx), Math.max(cy, H - cy));
    for (let r = 120; r < maxR; r += 120) {
      ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
    }
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2;
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(a) * 60, cy + Math.sin(a) * 60);
      ctx.lineTo(cx + Math.cos(a) * maxR, cy + Math.sin(a) * maxR);
      ctx.stroke();
    }
    // one dashed "ecliptic" arc gives the chart a diagonal spine
    ctx.setLineDash([2, 6]);
    ctx.strokeStyle = Marks.hexA(INK, 0.09);
    ctx.beginPath();
    ctx.ellipse(cx, cy, maxR * 0.72, maxR * 0.30, -0.36, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  /** Double-rule frame with corner ticks and a title cartouche. */
  function drawFrame(ctx, W, H, title, subtitle) {
    ctx.save();
    const m = 26, m2 = 34;
    ctx.strokeStyle = Marks.hexA(INK, 0.55);
    ctx.lineWidth = 1.4;
    ctx.strokeRect(m, m, W - m * 2, H - m * 2);
    ctx.strokeStyle = Marks.hexA(INK, 0.22);
    ctx.lineWidth = 0.8;
    ctx.strokeRect(m2, m2, W - m2 * 2, H - m2 * 2);
    // corner ticks
    ctx.strokeStyle = Marks.hexA(INK, 0.7);
    ctx.lineWidth = 1.4;
    const t = 12;
    for (const [cx, cy, sx, sy] of [[m, m, 1, 1], [W - m, m, -1, 1], [m, H - m, 1, -1], [W - m, H - m, -1, -1]]) {
      ctx.beginPath();
      ctx.moveTo(cx + sx * t, cy); ctx.lineTo(cx, cy); ctx.lineTo(cx, cy + sy * t);
      ctx.stroke();
      ctx.fillStyle = Marks.hexA(INK, 0.9);
      ctx.beginPath(); ctx.arc(cx + sx * 5, cy + sy * 5, 1.3, 0, Math.PI * 2); ctx.fill();
    }
    // cartouche
    if (title) {
      ctx.textAlign = 'center';
      ctx.fillStyle = Marks.hexA(INK, 0.92);
      ctx.font = '600 21px Georgia, "Times New Roman", serif';
      try { ctx.letterSpacing = '7px'; } catch (e) {}
      ctx.fillText(title.toUpperCase(), W / 2, m + 27);
      try { ctx.letterSpacing = '0px'; } catch (e) {}
      // flanking rules
      const tw = ctx.measureText(title.toUpperCase()).width + 60;
      ctx.strokeStyle = Marks.hexA(INK, 0.4);
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(W / 2 - tw / 2 - 120, m + 20); ctx.lineTo(W / 2 - tw / 2, m + 20);
      ctx.moveTo(W / 2 + tw / 2, m + 20); ctx.lineTo(W / 2 + tw / 2 + 120, m + 20);
      ctx.stroke();
      // diamond finials
      for (const dx of [-tw / 2 - 130, tw / 2 + 130]) {
        ctx.save();
        ctx.translate(W / 2 + dx, m + 20); ctx.rotate(Math.PI / 4);
        ctx.fillStyle = Marks.hexA(INK, 0.7);
        ctx.fillRect(-2.4, -2.4, 4.8, 4.8);
        ctx.restore();
      }
      if (subtitle) {
        ctx.fillStyle = Marks.hexA(INK, 0.45);
        ctx.font = 'italic 12px Georgia, "Times New Roman", serif';
        ctx.fillText(subtitle, W / 2, m + 45);
      }
      ctx.textAlign = 'left';
    }
    ctx.restore();
  }

  /* ---------------------- the constellation ----------------------------- */

  /**
   * Draw one inscribed constellation.
   * run = { stars: [{ id, x, y }, ...] } — order of array = order flown.
   * opts = { palette, markSize, showName, dim }
   */
  function drawConstellation(ctx, run, opts) {
    const o = opts || {};
    const stars = run.stars;
    if (!stars.length) return;
    const pal = o.palette || Marks.PALETTES[runHash(run) % Marks.PALETTES.length];
    const size = o.markSize || 30;
    const dim = o.dim || 1;
    const gap = size * 0.62;

    // --- boundary: expanded convex hull, dashed, whisper ink -------------
    if (stars.length >= 3 && o.boundary !== false) {
      const h = hull(stars);
      const c = centroid(h);
      ctx.save();
      ctx.strokeStyle = Marks.hexA(INK, 0.14 * dim);
      ctx.lineWidth = 1;
      ctx.setLineDash([5, 7]);
      ctx.beginPath();
      h.forEach((p, i) => {
        const dx = p.x - c.x, dy = p.y - c.y;
        const d = Math.hypot(dx, dy) || 1;
        const ex = p.x + (dx / d) * (size * 1.05);
        const ey = p.y + (dy / d) * (size * 1.05);
        if (i === 0) ctx.moveTo(ex, ey); else ctx.lineTo(ex, ey);
      });
      ctx.closePath(); ctx.stroke();
      ctx.restore();
    }

    // --- linework: glow underlay + hairline, stopping short of marks -----
    ctx.save();
    ctx.lineCap = 'round';
    for (let i = 0; i < stars.length - 1; i++) {
      const a = stars[i], b = stars[i + 1];
      const dx = b.x - a.x, dy = b.y - a.y;
      const d = Math.hypot(dx, dy) || 1;
      const ux = dx / d, uy = dy / d;
      const x0 = a.x + ux * gap, y0 = a.y + uy * gap;
      const x1 = b.x - ux * gap, y1 = b.y - uy * gap;
      // glow underlay
      ctx.strokeStyle = Marks.hexA(pal.halo, 0.16 * dim);
      ctx.lineWidth = 3.4;
      ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
      // bright hairline
      ctx.strokeStyle = Marks.hexA(pal.mid, 0.78 * dim);
      ctx.lineWidth = 1.1;
      ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
      // direction chevron at the midpoint — the route has a direction
      const mx = (x0 + x1) / 2, my = (y0 + y1) / 2;
      const ch = 3.6;
      ctx.strokeStyle = Marks.hexA(pal.core, 0.55 * dim);
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(mx - ux * ch - uy * ch, my - uy * ch + ux * ch);
      ctx.lineTo(mx + ux * ch, my + uy * ch);
      ctx.lineTo(mx - ux * ch + uy * ch, my - uy * ch - ux * ch);
      ctx.stroke();
    }
    ctx.restore();

    // --- the root ring (where the run began) -----------------------------
    const rootStar = stars[0];
    ctx.save();
    ctx.strokeStyle = Marks.hexA(pal.core, 0.5 * dim);
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 4]);
    ctx.beginPath(); ctx.arc(rootStar.x, rootStar.y, size * 0.85, 0, Math.PI * 2); ctx.stroke();
    ctx.restore();

    // --- the marks themselves --------------------------------------------
    for (const s of stars) {
      const m = Marks.markFor(s.id);
      Marks.drawMark(ctx, m.recipe, pal, s.x, s.y, size);
    }

    // --- terminus: a small hollow diamond past the final star ------------
    if (stars.length >= 2) {
      const a = stars[stars.length - 2], b = stars[stars.length - 1];
      const dx = b.x - a.x, dy = b.y - a.y;
      const d = Math.hypot(dx, dy) || 1;
      const tx = b.x + (dx / d) * size * 0.95, ty = b.y + (dy / d) * size * 0.95;
      ctx.save();
      ctx.translate(tx, ty); ctx.rotate(Math.PI / 4);
      ctx.strokeStyle = Marks.hexA(pal.core, 0.8 * dim);
      ctx.lineWidth = 1.1;
      ctx.strokeRect(-3, -3, 6, 6);
      ctx.restore();
    }

    // --- the generated name ----------------------------------------------
    if (o.showName !== false) {
      const nm = nameFor(run);
      const c = centroid(stars);
      // `o.labelY` is supplied by drawAtlas, which is the only caller that can
      // see ALL the figures and therefore the only one that can stop two names
      // landing on each other. Falls back to the local default when a caller
      // draws a single constellation on its own.
      let ly = o.labelY != null ? o.labelY : Math.max(...stars.map(s => s.y)) + size * 1.45;
      ctx.save();
      ctx.textAlign = 'center';
      ctx.fillStyle = Marks.hexA(INK, 0.85 * dim);
      ctx.font = '600 13px Georgia, "Times New Roman", serif';
      try { ctx.letterSpacing = '3px'; } catch (e) {}
      ctx.fillText(nm.title.toUpperCase() + ' · ' + nm.numeral, c.x, ly);
      try { ctx.letterSpacing = '0px'; } catch (e) {}
      ctx.fillStyle = Marks.hexA(INK, 0.42 * dim);
      ctx.font = 'italic 11px Georgia, "Times New Roman", serif';
      ctx.fillText(nm.epithet, c.x, ly + 15);
      ctx.textAlign = 'left';
      ctx.restore();
    }
  }

  /* ---------------------- the whole atlas -------------------------------- */

  /**
   * atlasState = {
   *   seed,                        — sector seed (backdrop + dust)
   *   title, subtitle,             — cartouche text
   *   fieldStars: [{x, y}],        — uninscribed background candidates
   *   constellations: [run, ...],  — inscribed figures, each { stars, palette? }
   * }
   */
  function drawAtlas(ctx, W, H, atlasState) {
    const st = atlasState;
    ctx.save();
    ctx.fillStyle = BG;
    ctx.fillRect(0, 0, W, H);

    const tints = (st.constellations || [])
      .map(r => (r.palette || Marks.PALETTES[runHash(r) % Marks.PALETTES.length]).halo);
    drawNebulaWash(ctx, W, H, st.seed || 1, tints.length ? tints : [INK]);
    drawDust(ctx, W, H, st.seed || 1, Math.round(W * H / 4800));
    drawGraticule(ctx, W, H, W * 0.62, H * 0.42);

    // faint uninscribed field stars — the space still to be flown
    if (st.fieldStars) {
      for (const f of st.fieldStars) {
        ctx.fillStyle = Marks.hexA(INK, 0.30);
        ctx.beginPath(); ctx.arc(f.x, f.y, 1.5, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = Marks.hexA(INK, 0.10);
        ctx.lineWidth = 0.7;
        ctx.beginPath(); ctx.arc(f.x, f.y, 4.4, 0, Math.PI * 2); ctx.stroke();
      }
    }

    /* --- NAME PLACEMENT: resolve collisions before drawing anything -------
     * ⚠️ Found by opening a 6-inscription atlas and reading it: two figures
     * whose centroids were ~40px apart printed their names ON TOP of each
     * other, producing "CA DIPIRE-I AV- V" and "the SlnEEbnr Road" — two
     * legible names destroyed into one illegible smear. Every mechanical check
     * passed: the image was distinct, correctly sized, dense, watermark-free.
     * Only looking finds this, and it gets worse the more the player plays,
     * i.e. exactly as their atlas becomes worth screenshotting.
     *
     * drawConstellation cannot fix it — it sees one figure. This is the only
     * place that sees them all.
     */
    const cons = st.constellations || [];
    const placed = [];
    const LH = 32;                              // title + epithet block
    const layout = cons.map((run) => {
      const size = run.markSize || 26;
      const c = centroid(run.stars);
      const nm = nameFor(run);
      ctx.font = '600 13px Georgia, "Times New Roman", serif';
      const label = nm.title.toUpperCase() + ' · ' + nm.numeral;
      const w = ctx.measureText(label).width + 3 * label.length + 26;
      const below = Math.max(...run.stars.map(s => s.y)) + size * 1.45;
      const above = Math.min(...run.stars.map(s => s.y)) - size * 0.95;
      const clashes = (y) => placed.some(p =>
        Math.abs(p.x - c.x) < (p.w + w) / 2 && Math.abs(p.y - y) < LH);
      // safeBottom: the caller's own chrome. The atlas VIEW puts sector tabs
      // and BEGIN VOYAGE across the bottom 58px, and a name pushed down to
      // avoid one collision landed straight on the tabs — trading a legible
      // collision for an illegible one. A poster render passes nothing and
      // keeps the full plate.
      const floor = (st.safeBottom != null ? st.safeBottom : H - 30);
      let y = below, guard = 0;
      while (guard++ < 12 && (clashes(y) || y > floor)) y += LH;
      if (y > floor) {                          // no room below — go above
        y = above; guard = 0;
        while (guard++ < 12 && (clashes(y) || y < 62)) y -= LH;
        if (y < 62) y = below;                  // give up gracefully, never vanish
      }
      placed.push({ x: c.x, y, w });
      return y;
    });

    cons.forEach((run, i) => {
      drawConstellation(ctx, run, {
        palette: run.palette, markSize: run.markSize, labelY: layout[i],
      });
    });

    drawFrame(ctx, W, H, st.title, st.subtitle);
    ctx.restore();
  }

  // drawNebulaWash/drawDust/drawGraticule are exported so the VOYAGE view can
  // render the same chart furniture as the atlas from ONE implementation. They
  // were private until 2026-08-17, and the cost of that was visible: the voyage
  // screen was flat black while the atlas carried wash, dust and a graticule, so
  // the two halves of the same game did not look like the same product.
  return {
    drawAtlas, drawConstellation, nameFor, runHash, hull, centroid, INK,
    drawNebulaWash, drawDust, drawGraticule,
  };
});
