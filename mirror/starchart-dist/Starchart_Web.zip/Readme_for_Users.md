# STARCHART

**Every voyage you fly is inscribed forever. The route you took *is* the constellation.**

Free. Plays in the browser. Nothing to install, nothing to buy, no timers, no ads.

---

## The one idea

You fly a route between stars. When the voyage ends — however it ends — **the chart keeps
what you drew.** The stars you touched, in the order you touched them, become a permanent
constellation in your atlas: named, bounded, and pointing the way you actually flew.

**There is no full restart, ever.** Death is not a reset. A voyage that ends badly still
leaves a figure on the chart, and that figure is permanent power. The atlas *is* the save
file, and it only ever grows.

---

## A voyage

You have **HULL** (how many hits you survive) and **FLUX** (how far you can travel). Every
jump costs flux in proportion to its distance, and the number under each reachable star is
exactly what it will cost. When you can no longer afford any jump in range, the voyage ends
and the chart takes it.

### Read the sky

**Every star is a generated form, and its shape tells you what it does.** There are 48
distinct forms across six families, each drawn in eight palettes — 384 possible stars, and
not one of them is an image file. The legend in the corner is the key:

| Family | What arriving there does |
| --- | --- |
| **forge** | repairs your hull, or sells the plating for flux if you are whole |
| **haven** | +18 flux |
| **surge** | your next jump is free, at any distance |
| **twin wreck** | a choice: rich salvage at the risk of your hull, or pass by safely |
| **nebula** | a gamble — a hidden reef, or the veil parts kindly |
| **shrine** | tithes flux, and more of it once you hold Covenant |

Learning to read the sky at a glance is the skill. It is why the forms are distinct.

### Three decisions that matter

1. **Which gate you cast off from.** Three gates sit far apart in every sector, and each one
   opens a different region. You are choosing where the next figure goes on your chart.
2. **Where you jump.** Cheap and safe, or a long crossing that strains the hull to reach the
   shrine you actually want.
3. **When to stop.** **SET ANCHOR** ends the voyage on your terms and banks the figure. Push
   on and you might close the route into a loop — but you might also go adrift first.

---

## The chart is the progression

**Every inscribed constellation grants power by its dominant family**, permanently:

| Grant | Effect |
| --- | --- |
| **Bulwark** | +1 max hull |
| **Reserve** | +14 starting flux |
| **Farsight** | +9% jump range |
| **Fortune** | better salvage odds |
| **Ward** | absorbs one hazard per voyage |
| **Covenant** | +10 flux from every shrine |

Grants stack, and they compose: more range reaches stars that were unaffordable, which lets
you draw figures you could not have drawn before.

### Close the loop — the seal

**If your route ends near where it began, the constellation seals, and a sealed figure grants
double.** That is the central tension of every voyage: a straight line out into rich territory
banks safely, but a loop is worth twice as much and you have to survive the way back.

### Re-flying a route deepens it

Fly a figure you have already charted and the chart does not draw a second copy — **the line
deepens.** The grant still accrues and the figure is drawn heavier. Grinding a known route is
a real strategy, just a slower one than charting something new.

---

## Four sectors

**The Verge** is open from the start. **The Drift** unlocks at 5 inscriptions, **The Hollow
Crown** at 12, **The Long Dark** at 21. Each is a larger, differently generated sky, and the
deep sectors hold more shrines.

---

## Everything you see is generated

There are **no image files in this game.** Every star, every constellation, the nebula wash,
the graticule, the chart frame — all of it is drawn by code, deterministically, from the same
48 hand-authored recipes. The same voyage always produces the same picture and the same name,
which is why an atlas can be trusted to look identical forever.

The sound is the same story: every tone is synthesised by [ZzFX](https://github.com/KilledByAPixel/ZzFX)
(MIT, © 2019 Frank Force) — no audio files either. **Sound can be toggled off** with the
control in the corner of both screens, and the setting is remembered.

---

## Saving

Automatic, to your browser's local storage, on **every** arrival. Close the tab mid-voyage and
you resume mid-voyage. Nothing is ever lost to a crash, and there is no manual save to forget.

Clearing your browser's site data for this page will erase the atlas — that is the only way to
lose it.

---

## Controls

**Mouse only.** Click a ringed star to jump to it. Click a gate to cast off. Click the sector
tabs to change sky. Hover a star to read its family and cost.

---

## Made by

**CSAF — Corey Gallant and Stephanie Thomason.**
More free browser games and developer tools: <https://csaf.itch.io>

Built with AI assistance; see the store listing's disclosure for the specifics.
