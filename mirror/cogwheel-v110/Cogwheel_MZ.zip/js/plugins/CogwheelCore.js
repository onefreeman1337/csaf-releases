/*:
 * @target MZ
 * @plugindesc Cogwheel Core v1.1.0 — Zelda-style dungeon objects: push-blocks, plates, ice, holes,
 * boulders, mirrors and light beams. The OBJECT layer that sits on top of your tile control.
 * @author CSAF — Corey & Stephanie's Asset Factory
 *
 * @param blockPushFrames
 * @text Block push duration (frames)
 * @desc How many frames a pushed object takes to travel one tile. Blank is treated as ABSENT, not 0.
 * @type number
 * @min 1
 * @default 12
 *
 * @param beamMaxBounces
 * @text Beam max reflections
 * @desc SAFETY BACKSTOP ONLY — leave it alone unless you know you want a limit. Mirror loops are
 * already detected exactly, so this never fires in normal play. Blank = automatic.
 * @type number
 * @min 1
 * @default 64
 *
 * @help
 * Cogwheel Core — the model layer.
 *
 * POSITIONING: this is the OBJECT layer. It governs things that sit ON tiles — pushing, sliding,
 * sinking, weighing, reflecting, resetting. It does NOT govern tile passability, and it is designed
 * to sit happily on top of a tile-control plugin rather than replace one.
 *
 * LIGHT AND MIRRORS. Beams reflect off mirrors, are stopped by blocks and boulders, pass over
 * pressure plates, cross holes and water, and terminate on receivers. Mirrors are themselves
 * pushable, so "aim the beam" is a pushing puzzle rather than a switch.
 *
 * Mirror loops cannot hang your game, and not because of a retry limit: a beam's whole state is
 * (tile, direction), so a beam that never ends must repeat one — which is what a loop IS. Cogwheel
 * detects the repeat exactly and stops. A ring of four mirrors is reported as a loop rather than
 * silently truncated, so you can see it in the inspector and fix it.
 *
 * FILLED HOLES SURVIVE SAVING. Pushing a block into a hole makes a permanent crossing, and it is
 * still there after a save and reload — the crossing is derived from the block that made it, not
 * from a change to your map. Your map file is never modified.
 *
 * ROOM RESET restores the room exactly as you authored it. If the player is standing on a crossing
 * when they reset, Cogwheel reports it so the room can return them to its entrance instead of
 * leaving them on a hole that has just re-opened.
 *
 * COMPATIBILITY, STATED UP FRONT: Cogwheel is grid-native, exactly like RPG Maker's own events. It
 * is NOT compatible with pixel-movement or action-battle plugins that replace event movement
 * wholesale. Said here rather than discovered later.
 *
 * ARCHITECTURE NOTE: every function in this file is pure with respect to the engine. It takes a
 * grid description and returns a decision. That is deliberate — it is what lets the whole
 * interaction matrix be tested headlessly in Node, which is this wing's primary quality lever.
 * The MZ-facing wrapper lives in the scene/inspector plugin, not here.
 */

'use strict';

var Cogwheel = (function () {
  /* ------------------------------------------------------------------ *
   * Terrain and object vocabulary
   * ------------------------------------------------------------------ */

  /** Terrain kinds a cell may have. */
  var TERRAIN = {
    FLOOR: 'floor',
    HOLE: 'hole',
    ICE: 'ice',
    WATER: 'water',
    WALL: 'wall'
  };

  /** Object kinds Cogwheel manages. */
  var OBJECT = {
    BLOCK: 'block',
    BOULDER: 'boulder',
    MIRROR: 'mirror',
    PLATE: 'plate',
    RECEIVER: 'receiver'
  };

  /** Outcomes a push resolution can produce. */
  var OUTCOME = {
    MOVED: 'moved',
    BLOCKED: 'blocked',
    FELL_IN_HOLE: 'fell_in_hole',
    SANK: 'sank',
    SLID: 'slid',
    BROKE: 'broke'
  };

  var DIRS = {
    2: { dx: 0, dy: 1 },   // down  — RPG Maker numpad directions
    4: { dx: -1, dy: 0 },  // left
    6: { dx: 1, dy: 0 },   // right
    8: { dx: 0, dy: -1 }   // up
  };

  /* ------------------------------------------------------------------ *
   * Parameter reading — wing §16
   * ------------------------------------------------------------------ */

  /**
   * Read a numeric plugin parameter, treating BLANK AS ABSENT rather than as zero.
   *
   * Plugin parameters arrive as STRINGS and `Number('')` is 0, not NaN. A blank duration field
   * silently becoming a real 0 is the class of bug that produces an object which never moves and
   * never errors (wing CLAUDE.md §16).
   *
   * @param {*} raw Raw parameter value, usually a string.
   * @param {number} fallback Value to use when the parameter is absent or blank.
   * @returns {number} The parsed number, or `fallback`.
   */
  function readNumber(raw, fallback) {
    if (raw === undefined || raw === null) return fallback;
    var s = String(raw).trim();
    if (s === '') return fallback;
    var n = Number(s);
    return Number.isFinite(n) ? n : fallback;
  }

  /* ------------------------------------------------------------------ *
   * Grid
   * ------------------------------------------------------------------ */

  /**
   * Create a grid model. Pure data — no engine references.
   *
   * @param {number} width Grid width in tiles.
   * @param {number} height Grid height in tiles.
   * @param {string[][]} [terrain] Optional terrain rows; defaults to all floor.
   * @returns {{width:number,height:number,terrain:string[][],objects:Object[]}} Grid.
   */
  function createGrid(width, height, terrain) {
    var rows = [];
    for (var y = 0; y < height; y++) {
      var row = [];
      for (var x = 0; x < width; x++) {
        row.push(terrain && terrain[y] && terrain[y][x] ? terrain[y][x] : TERRAIN.FLOOR);
      }
      rows.push(row);
    }
    return { width: width, height: height, terrain: rows, objects: [] };
  }

  /**
   * Terrain at a cell. Out-of-bounds reads as WALL so edge handling needs no special case.
   *
   * @param {Object} grid Grid.
   * @param {number} x Column.
   * @param {number} y Row.
   * @returns {string} A TERRAIN value.
   */
  function terrainAt(grid, x, y) {
    if (x < 0 || y < 0 || x >= grid.width || y >= grid.height) return TERRAIN.WALL;
    return grid.terrain[y][x];
  }

  /**
   * The first non-consumed object occupying a cell, if any.
   *
   * @param {Object} grid Grid.
   * @param {number} x Column.
   * @param {number} y Row.
   * @returns {Object|null} The object, or null.
   */
  function objectAt(grid, x, y) {
    for (var i = 0; i < grid.objects.length; i++) {
      var o = grid.objects[i];
      if (o.x === x && o.y === y && !o.consumed) return o;
    }
    return null;
  }

  /**
   * Add an object to the grid.
   *
   * @param {Object} grid Grid.
   * @param {string} kind An OBJECT value.
   * @param {number} x Column.
   * @param {number} y Row.
   * @param {Object} [props] Extra properties (e.g. `facing` for a mirror).
   * @returns {Object} The created object.
   */
  function addObject(grid, kind, x, y, props) {
    // homeX/homeY are AUTHORED data, rebuilt from the map on every load and never persisted. They
    // are what makes `resetRoom` exact rather than approximate.
    var o = { id: grid.objects.length + 1, kind: kind, x: x, y: y, consumed: false, homeX: x, homeY: y };
    if (props) {
      for (var k in props) {
        if (Object.prototype.hasOwnProperty.call(props, k)) o[k] = props[k];
      }
    }
    grid.objects.push(o);
    return o;
  }

  /* ------------------------------------------------------------------ *
   * Push resolution — THE INTERACTION MATRIX
   * ------------------------------------------------------------------ */

  /**
   * Can this terrain stop a sliding or rolling object?
   *
   * @param {string} t A TERRAIN value.
   * @returns {boolean} True if the terrain halts travel.
   */
  function isSolidTerrain(t) {
    return t === TERRAIN.WALL;
  }

  /**
   * The consumed object resting in a cell, if any — i.e. the thing that filled a hazard.
   *
   * Deliberately separate from {@link objectAt}, which skips consumed objects because they are no
   * longer obstructions. A consumed object is not gone; it is *terrain now*.
   *
   * @param {Object} grid Grid.
   * @param {number} x Column.
   * @param {number} y Row.
   * @returns {Object|null} The consumed object, or null.
   */
  function bridgeAt(grid, x, y) {
    for (var i = 0; i < grid.objects.length; i++) {
      var o = grid.objects[i];
      if (o.consumed && o.x === x && o.y === y) return o;
    }
    return null;
  }

  /**
   * Has a hazard at this cell been filled in, making it crossable?
   *
   * ⚠️ THIS IS DERIVED, AND THE DERIVATION IS THE WHOLE POINT. The first implementation filled a
   * hole by writing `grid.terrain[y][x] = FLOOR`, which is a change to TERRAIN — while the save
   * records only OBJECTS. MEASURED with `Internal_Ops/_probe/bridge_save_probe.js` before the fix:
   * the hole read `floor` in the live session and `hole` again after a save/load round-trip, with
   * the block that filled it still consumed. A player who solved that puzzle, saved and reloaded
   * was stranded, with no exception and no log line.
   *
   * Deriving it from the consumed object instead makes the bug UNREPRESENTABLE: the object record
   * is the thing that persists, so the bridge persists with it, and the authored map is never
   * contradicted because it is never touched.
   *
   * @param {Object} grid Grid.
   * @param {number} x Column.
   * @param {number} y Row.
   * @returns {boolean} True when a hazard cell has been filled.
   */
  function isBridged(grid, x, y) {
    var t = terrainAt(grid, x, y);
    if (t !== TERRAIN.HOLE && t !== TERRAIN.WATER) return false;
    return !!bridgeAt(grid, x, y);
  }

  /**
   * Terrain as it currently BEHAVES, as opposed to how the map authored it.
   *
   * @param {Object} grid Grid.
   * @param {number} x Column.
   * @param {number} y Row.
   * @returns {string} A TERRAIN value; a filled hazard reads as FLOOR.
   */
  function effectiveTerrainAt(grid, x, y) {
    var t = terrainAt(grid, x, y);
    if ((t === TERRAIN.HOLE || t === TERRAIN.WATER) && bridgeAt(grid, x, y)) return TERRAIN.FLOOR;
    return t;
  }

  /**
   * May the player stand on this cell?
   *
   * @param {Object} grid Grid.
   * @param {number} x Column.
   * @param {number} y Row.
   * @returns {boolean} True when walkable.
   */
  function isPassable(grid, x, y) {
    if (x < 0 || y < 0 || x >= grid.width || y >= grid.height) return false;
    var t = effectiveTerrainAt(grid, x, y);
    if (t !== TERRAIN.FLOOR && t !== TERRAIN.ICE) return false;
    var o = objectAt(grid, x, y);
    return !o || isFixture(o);
  }

  /**
   * Restore the room to its authored layout — the product's safety net.
   *
   * Exact by construction, and cheaply so: because filling a hazard is derived rather than stored,
   * there is no terrain to put back. Un-consuming every object and returning it to its authored
   * home is the entire operation, and it cannot drift out of step with the push rules because it
   * shares no code with them.
   *
   * ⚠️ RESET CAN PULL THE FLOOR OUT FROM UNDER THE PLAYER, and that is a different question from
   * whether it recovers a dead end. Restoring the map un-fills every bridge — so a player standing
   * on a hole they filled is, the instant they press reset, standing on an open hole.
   * `solvability_probe.js` MEASURED this as reachable in the shipped rooms rather than imagining
   * it, so this function reports it and the MZ wrapper returns the player to the room entrance.
   * (Which is the standard Zelda room-reset feel in any case: you re-enter the room.)
   *
   * @param {Object} grid Grid, mutated in place.
   * @param {number} [playerX] Player column, to test for stranding.
   * @param {number} [playerY] Player row.
   * @returns {{grid:Object, playerStranded:boolean}} The grid, and whether the player's cell became
   *   impassable as a result of the reset.
   */
  function resetRoom(grid, playerX, playerY) {
    var testPlayer = playerX !== undefined && playerY !== undefined;
    var wasPassable = testPlayer ? isPassable(grid, playerX, playerY) : false;

    for (var i = 0; i < grid.objects.length; i++) {
      var o = grid.objects[i];
      o.x = o.homeX;
      o.y = o.homeY;
      o.consumed = false;
    }

    var stranded = false;
    if (testPlayer) {
      // Stranded only if the reset is what broke it — a player already standing somewhere illegal
      // is a different bug and must not be blamed on reset.
      stranded = wasPassable && !isPassable(grid, playerX, playerY);
    }
    return { grid: grid, playerStranded: stranded };
  }

  /**
   * Is this object a floor FIXTURE rather than a solid obstruction?
   *
   * Fixtures are flush with the floor, so a pushed object travels ONTO them rather than being
   * stopped by them. Getting this wrong is not a crash — it is a plate that can never be pressed,
   * which reads to a buyer as an unsolvable puzzle with no error anywhere. Caught by the suite on
   * the first run, which is the entire reason the matrix is tested cell by cell.
   *
   * @param {Object} o An object.
   * @returns {boolean} True for plates and receivers.
   */
  function isFixture(o) {
    return o.kind === OBJECT.PLATE || o.kind === OBJECT.RECEIVER;
  }

  /**
   * Resolve a push of the object at (x, y) in `dir`.
   *
   * This is the single decision point for the whole interaction matrix, and it is deliberately the
   * only place the rules live: a matrix implemented in several places is a matrix that disagrees
   * with itself.
   *
   * Travel rules by kind:
   *   BLOCK   — moves exactly one tile, unless it lands on ice (then it slides until stopped).
   *   BOULDER — rolls until something stops it, and BREAKS against a wall.
   * Terminal cells:
   *   HOLE    — the object falls in, is consumed, and the hole becomes floor (it is now a bridge).
   *   WATER   — the object sinks, is consumed, and the water becomes floor.
   *
   * @param {Object} grid Grid, mutated in place on a successful resolution.
   * @param {number} x Column of the object being pushed.
   * @param {number} y Row of the object being pushed.
   * @param {number} dir RPG Maker direction (2, 4, 6, 8).
   * @returns {{outcome:string, object:(Object|null), from:(Object|null), to:(Object|null), tilesMoved:number}}
   *   The outcome, the object, its start and end cells, and how far it travelled.
   */
  function resolvePush(grid, x, y, dir) {
    var d = DIRS[dir];
    var obj = objectAt(grid, x, y);
    var nothing = { outcome: OUTCOME.BLOCKED, object: null, from: null, to: null, tilesMoved: 0 };
    if (!d || !obj) return nothing;
    if (isFixture(obj)) return nothing; // fixtures are bolted to the floor and never move

    var from = { x: obj.x, y: obj.y };
    var cx = obj.x;
    var cy = obj.y;
    var moved = 0;

    // A boulder rolls until stopped; a block moves one tile, then ice may carry it further.
    var rolling = obj.kind === OBJECT.BOULDER;

    for (;;) {
      var nx = cx + d.dx;
      var ny = cy + d.dy;
      // EFFECTIVE terrain, not authored terrain: a hazard someone already filled is floor to
      // travel over. Reading authored terrain here would drop a second block into a full hole.
      var t = effectiveTerrainAt(grid, nx, ny);
      var blocker = objectAt(grid, nx, ny);

      // Wall: a boulder breaks against it, everything else simply stops.
      if (isSolidTerrain(t)) {
        if (rolling && moved > 0) {
          obj.consumed = true;
          return { outcome: OUTCOME.BROKE, object: obj, from: from, to: { x: cx, y: cy }, tilesMoved: moved };
        }
        break;
      }

      // Another object blocks travel — but a FIXTURE (plate, receiver) is flush with the floor and
      // is travelled onto, not stopped against. Nothing pushes a second solid object in v1:
      // chained pushes are a separate mechanic and shipping them implicitly would make the matrix
      // untestable.
      if (blocker && !isFixture(blocker)) break;

      cx = nx;
      cy = ny;
      moved++;

      // Terminal terrain — the object is consumed and BECOMES the crossing.
      //
      // ⚠️ THE AUTHORED TERRAIN IS DELIBERATELY NOT MUTATED. Writing FLOOR here is the obvious
      // implementation and it is the one that shipped a save/load defect: the fill is a terrain
      // change while the save records only objects, so the bridge vanished on reload and stranded
      // the player. `isBridged` derives the crossing from this consumed object instead, so the
      // bridge persists exactly as long as the record that explains it.
      if (t === TERRAIN.HOLE) {
        obj.x = cx; obj.y = cy; obj.consumed = true;
        return { outcome: OUTCOME.FELL_IN_HOLE, object: obj, from: from, to: { x: cx, y: cy }, tilesMoved: moved };
      }
      if (t === TERRAIN.WATER) {
        obj.x = cx; obj.y = cy; obj.consumed = true;
        return { outcome: OUTCOME.SANK, object: obj, from: from, to: { x: cx, y: cy }, tilesMoved: moved };
      }

      // Ice keeps a block travelling; floor stops it after its single tile.
      if (!rolling && t !== TERRAIN.ICE) break;
    }

    if (moved === 0) {
      return { outcome: OUTCOME.BLOCKED, object: obj, from: from, to: { x: obj.x, y: obj.y }, tilesMoved: 0 };
    }

    obj.x = cx;
    obj.y = cy;
    var slid = moved > 1;
    return {
      outcome: slid ? OUTCOME.SLID : OUTCOME.MOVED,
      object: obj,
      from: from,
      to: { x: cx, y: cy },
      tilesMoved: moved
    };
  }

  /**
   * Resolve a push WITHOUT changing anything — what would happen if you shoved this.
   *
   * ⚠️ IT CALLS `resolvePush` AND PUTS THE STATE BACK, and that is deliberate rather than lazy.
   * The obvious implementation is a second copy of the travel loop with the writes removed, and
   * that is precisely the shape wing CLAUDE.md §11 exists to forbid: two code paths that must agree
   * and agree only by care. Voyage Core shipped that shape and its two paths silently disagreed by
   * a whole simulation step. Here the preview cannot disagree with the push, because it IS the
   * push — the matrix has exactly one implementation and this borrows it.
   *
   * `resolvePush` mutates precisely three fields on precisely one object (`x`, `y`, `consumed`), so
   * restoring them restores the grid exactly. `previewPush` asserts that equivalence in the suite
   * rather than claiming it here.
   *
   * @param {Object} grid Grid. NOT modified — every mutation is undone before returning.
   * @param {number} x Column of the object to test.
   * @param {number} y Row of the object to test.
   * @param {number} dir RPG Maker direction (2, 4, 6, 8).
   * @returns {{outcome:string, object:(Object|null), from:(Object|null), to:(Object|null), tilesMoved:number}}
   *   Exactly what {@link resolvePush} would have returned.
   */
  function previewPush(grid, x, y, dir) {
    var obj = objectAt(grid, x, y);
    if (!obj) return { outcome: OUTCOME.BLOCKED, object: null, from: null, to: null, tilesMoved: 0 };

    var sx = obj.x;
    var sy = obj.y;
    var sc = obj.consumed;
    var res = resolvePush(grid, x, y, dir);
    obj.x = sx;
    obj.y = sy;
    obj.consumed = sc;
    return res;
  }

  /* ------------------------------------------------------------------ *
   * Plates
   * ------------------------------------------------------------------ */

  /**
   * Is the plate at (x, y) currently pressed?
   *
   * A plate is pressed when a non-consumed pushable object shares its cell. Derived on demand and
   * never stored — the same rule that keeps the save shape minimal and makes an inconsistent state
   * unrepresentable.
   *
   * @param {Object} grid Grid.
   * @param {number} x Column.
   * @param {number} y Row.
   * @returns {boolean} True when pressed.
   */
  function isPlatePressed(grid, x, y) {
    for (var i = 0; i < grid.objects.length; i++) {
      var o = grid.objects[i];
      if (o.consumed) continue;
      if (o.x !== x || o.y !== y) continue;
      if (o.kind === OBJECT.BLOCK || o.kind === OBJECT.BOULDER) return true;
    }
    return false;
  }

  /* ------------------------------------------------------------------ *
   * Light beams and mirrors
   * ------------------------------------------------------------------ */

  /**
   * Reflection table. A mirror turns a beam 90 degrees; it never reverses it.
   *
   * That single property is why a pair of mirrors CANNOT bounce a beam back and forth, and why the
   * arrangement that actually hangs a naive tracer is a RING of four — which a level designer
   * builds by accident far more easily than the two-mirror case people expect.
   */
  var MIRROR_REFLECT = {
    '/':  { 6: 8, 8: 6, 4: 2, 2: 4 },
    '\\': { 6: 2, 2: 6, 4: 8, 8: 4 }
  };

  /** Outcomes a beam trace can terminate with. */
  var BEAM = {
    RECEIVER: 'receiver',
    BLOCKED: 'blocked',
    ESCAPED: 'escaped',
    LOOPED: 'looped',
    CAPPED: 'capped'
  };

  /**
   * Trace a light beam from a cell in a direction, through mirrors, to whatever stops it.
   *
   * TERMINATION IS GUARANTEED BY CONSTRUCTION, and that is the whole design of this function.
   * A beam's complete state is `(x, y, direction)`. There are exactly `width * height * 4` such
   * states, so a beam that never terminates must revisit one — and revisiting one is precisely the
   * definition of a cycle. The tracer records every state it occupies and stops the moment it
   * repeats one. It therefore cannot run longer than the number of states in the grid, whatever a
   * designer builds.
   *
   * The bounce cap is a BACKSTOP, not the mechanism. It defaults high enough that it cannot bite on
   * a real map, because a cap that truncates a legitimate 40-bounce puzzle would produce exactly the
   * silent wrongness this plugin exists to avoid: a beam that stops for no visible reason.
   *
   * ⚠️ KEYED ON (cell, DIRECTION), never on cell alone. A beam crossing its own path at right
   * angles shares a cell with itself and is perfectly legal — a detector keyed on cell would reject
   * correct puzzles, and a check that fails on correct input gets deleted by the next person, taking
   * the real rule with it.
   *
   * ⚠️ NOT A PER-FRAME FUNCTION. It allocates a path array and a visited set, so it must be called
   * when the puzzle state CHANGES (a block moved, a mirror turned) and its result cached for the
   * renderer. The zero-allocation rule (wing CLAUDE.md §3) governs the frame loop that draws the
   * cached path, not this.
   *
   * @param {Object} grid Grid. NOT mutated.
   * @param {number} x Emitter column.
   * @param {number} y Emitter row.
   * @param {number} dir Emission direction (2, 4, 6, 8).
   * @param {{maxBounces?:number}} [opts] Optional backstop bounce cap.
   * @returns {{outcome:string, cells:Array<{x:number,y:number,dir:number}>, bounces:number, receiverId:(number|null)}}
   *   The terminating outcome, the contiguous path (origin first, one entry per tile occupied, each
   *   carrying the direction the beam was travelling as it entered), the reflection count, and the
   *   id of the receiver lit, if any.
   */
  function traceBeam(grid, x, y, dir, opts) {
    var empty = { outcome: BEAM.BLOCKED, cells: [], bounces: 0, receiverId: null };
    if (!DIRS[dir]) return empty;
    if (x < 0 || y < 0 || x >= grid.width || y >= grid.height) return empty;
    if (terrainAt(grid, x, y) === TERRAIN.WALL) return empty;

    // Generous by default: the cycle detector is what guarantees termination, so this can only
    // ever fire if the detector itself is broken, or if a caller deliberately lowers it.
    var cap = readNumber(opts && opts.maxBounces, Math.max(64, grid.width * grid.height));

    var cells = [{ x: x, y: y, dir: dir }];
    var visited = new Set();
    visited.add(((y * grid.width + x) * 10) + dir);

    var cx = x;
    var cy = y;
    var cd = dir;
    var bounces = 0;

    for (;;) {
      var d = DIRS[cd];
      var nx = cx + d.dx;
      var ny = cy + d.dy;

      // Off the map — check bounds BEFORE terrainAt, which reports out-of-bounds as WALL and would
      // otherwise report an escaping beam as a blocked one.
      if (nx < 0 || ny < 0 || nx >= grid.width || ny >= grid.height) {
        return { outcome: BEAM.ESCAPED, cells: cells, bounces: bounces, receiverId: null };
      }
      if (terrainAt(grid, nx, ny) === TERRAIN.WALL) {
        return { outcome: BEAM.BLOCKED, cells: cells, bounces: bounces, receiverId: null };
      }

      var occupant = objectAt(grid, nx, ny);
      if (occupant) {
        if (occupant.kind === OBJECT.RECEIVER) {
          cells.push({ x: nx, y: ny, dir: cd });
          return { outcome: BEAM.RECEIVER, cells: cells, bounces: bounces, receiverId: occupant.id };
        }
        if (occupant.kind === OBJECT.MIRROR) {
          var table = MIRROR_REFLECT[occupant.facing];
          // A mirror with no usable facing stops the beam rather than passing it through. Visible to
          // the designer as "my beam stops here", which is findable; silently ignoring the mirror is
          // not.
          if (!table) {
            return { outcome: BEAM.BLOCKED, cells: cells, bounces: bounces, receiverId: null };
          }
          var key = ((ny * grid.width + nx) * 10) + cd;
          if (visited.has(key)) {
            return { outcome: BEAM.LOOPED, cells: cells, bounces: bounces, receiverId: null };
          }
          visited.add(key);
          cells.push({ x: nx, y: ny, dir: cd });
          bounces++;
          if (bounces > cap) {
            return { outcome: BEAM.CAPPED, cells: cells, bounces: cap, receiverId: null };
          }
          cx = nx; cy = ny; cd = table[cd];
          continue;
        }
        // Blocks and boulders are solid and cast a shadow. Plates are floor fixtures, so light
        // travels over them — the same isFixture rule that lets a block be pushed onto a plate.
        if (!isFixture(occupant)) {
          return { outcome: BEAM.BLOCKED, cells: cells, bounces: bounces, receiverId: null };
        }
      }

      var ckey = ((ny * grid.width + nx) * 10) + cd;
      if (visited.has(ckey)) {
        return { outcome: BEAM.LOOPED, cells: cells, bounces: bounces, receiverId: null };
      }
      visited.add(ckey);
      cells.push({ x: nx, y: ny, dir: cd });
      cx = nx;
      cy = ny;
    }
  }

  /* ------------------------------------------------------------------ *
   * Save shape
   * ------------------------------------------------------------------ */

  /**
   * Serialise ONLY what play changed. Authored layout is not persisted, so a save cannot contradict
   * the map it was made on.
   *
   * @param {Object} grid Grid.
   * @returns {{v:number, objects:Object[]}} A minimal versioned record.
   */
  function toSave(grid) {
    var out = [];
    for (var i = 0; i < grid.objects.length; i++) {
      var o = grid.objects[i];
      out.push({ id: o.id, x: o.x, y: o.y, c: o.consumed ? 1 : 0 });
    }
    return { v: 1, objects: out };
  }

  /**
   * Restore a save onto a freshly authored grid.
   *
   * @param {Object} grid Grid built from the map's authored data.
   * @param {Object} save A record from {@link toSave}.
   * @returns {Object} The same grid, mutated.
   */
  function applySave(grid, save) {
    if (!save || !save.objects) return grid;
    for (var i = 0; i < save.objects.length; i++) {
      var rec = save.objects[i];
      for (var j = 0; j < grid.objects.length; j++) {
        var o = grid.objects[j];
        if (o.id === rec.id) {
          o.x = rec.x; o.y = rec.y; o.consumed = !!rec.c;
          break;
        }
      }
    }
    return grid;
  }

  return {
    TERRAIN: TERRAIN,
    OBJECT: OBJECT,
    OUTCOME: OUTCOME,
    BEAM: BEAM,
    DIRS: DIRS,
    traceBeam: traceBeam,
    readNumber: readNumber,
    createGrid: createGrid,
    terrainAt: terrainAt,
    effectiveTerrainAt: effectiveTerrainAt,
    objectAt: objectAt,
    bridgeAt: bridgeAt,
    isBridged: isBridged,
    isPassable: isPassable,
    // Exported because "a plate is flush with the floor" is a RULE, and it was being restated as
    // `kind === PLATE || kind === RECEIVER` in three other places — the push handler, the preview
    // and the map bridge. Three copies of a rule are three chances for it to disagree with itself
    // the day a fourth fixture kind is added (wing §11).
    isFixture: isFixture,
    resetRoom: resetRoom,
    addObject: addObject,
    resolvePush: resolvePush,
    previewPush: previewPush,
    isPlatePressed: isPlatePressed,
    toSave: toSave,
    applySave: applySave
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = Cogwheel;
