//=============================================================================
// CogwheelAtlas.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.1.0] Cogwheel — the atlas. Every object, terrain mark and icon Cogwheel draws, authored as procedural art. 46 marks, zero image files.
 * @author CSAF — Corey & Stephanie's Asset Factory
 * @url https://csaf.itch.io/cogwheel
 * @base CogwheelCore
 * @orderAfter CogwheelCore
 *
 * @help
 * ============================================================================
 * The atlas
 * ============================================================================
 *
 * This file is Cogwheel's artwork. Not a sprite sheet — the artwork itself,
 * authored as drawing routines: 46 distinct marks in one visual language,
 * rendered at any tile size, with no PNG, no atlas page and nothing for you
 * to import.
 *
 *   BODIES     blocks in six materials (stone, wood, ice, iron, gild, rune),
 *              boulders in three (granite, amber, obsidian), mirrors, plates,
 *              emitters, receivers — every object Cogwheel manages, drawn.
 *
 *   AFTERMATH  a block spent bridging a hole is redrawn as that material laid
 *              into the pit. A block sunk into water becomes a ford. A
 *              shattered boulder leaves its shards.
 *
 *   THE LENS   floor, wall, pit, water and ice as drafting-instrument marks,
 *              the player as a surveyor's reticle, and a mechanism cog for
 *              the events Cogwheel does not manage.
 *
 *   ICONS      one mark per push outcome — PUSH, SLIDES, FALLS, SINKS,
 *              SHATTERS, BLOCKED — and the beam-loop alarm.
 *
 * Because every mark is a routine, your dungeon needs no charset authoring at
 * all: leave a Cogwheel event's graphic BLANK and the object draws itself.
 * Give it a graphic and Cogwheel respects your art instead. Both are stated
 * in CogwheelInspector's help.
 *
 * This plugin draws nothing on its own. It is the library the inspector pulls
 * from, and it must sit between CogwheelCore and CogwheelMap in the list.
 */

'use strict';

var CogwheelAtlas = (function () {

  /* ------------------------------------------------------------------ *
   * Palette — the established Cogwheel language: a cold blueprint, one
   * warm light. Every painter draws from here, which is what makes 46
   * marks read as one instrument rather than 46 clip-arts.
   * ------------------------------------------------------------------ */
  var PAL = {
    ink: '#0b1018',          // deepest ground
    slate: '#141b28',        // panel ground
    slateUp: '#1d2738',      // raised ground
    line: '#5ad2ff',         // schematic cyan
    lineDim: '#2a6f8f',
    wire: '#7ee0b8',         // live green
    hazard: '#ff5f6d',       // alarm red
    light: '#ffb454',        // the one warm light
    lightHot: '#ffe2ae',
    white: '#f4f8ff',

    stoneA: '#8a93a6', stoneB: '#5c6577', stoneC: '#3a4152',
    woodA: '#b98a56', woodB: '#8a6238', woodC: '#5c3f22',
    iceA: '#bfeaff', iceB: '#7cc3e8', iceC: '#3e7ea8',
    ironA: '#9aa4b2', ironB: '#5f6873', ironC: '#333a44',
    gildA: '#ffd98a', gildB: '#d4a041', gildC: '#8a6420',
    runeA: '#3b3350', runeB: '#251f38', runeGlow: '#b48cff',

    pitA: '#05070c', pitB: '#10151f',
    waterA: '#2f7fae', waterB: '#123a55', waterC: '#7fd4f0'
  };

  /* ------------------------------------------------------------------ *
   * Shared brushes. Each painter receives a raw 2D context whose origin
   * is the tile's top-left corner and a size `s`; everything below is a
   * fraction of `s`, so the atlas renders at any resolution.
   * ------------------------------------------------------------------ */

  /**
   * Rounded-rectangle path.
   * @param {CanvasRenderingContext2D} c Context.
   * @param {number} x Left. @param {number} y Top.
   * @param {number} w Width. @param {number} h Height. @param {number} r Radius.
   * @returns {void}
   */
  function rr(c, x, y, w, h, r) {
    c.beginPath();
    c.moveTo(x + r, y);
    c.arcTo(x + w, y, x + w, y + h, r);
    c.arcTo(x + w, y + h, x, y + h, r);
    c.arcTo(x, y + h, x, y, r);
    c.arcTo(x, y, x + w, y, r);
    c.closePath();
  }

  /**
   * Vertical linear gradient.
   * @param {CanvasRenderingContext2D} c Context.
   * @param {number} y0 Top. @param {number} y1 Bottom.
   * @param {string} a Top colour. @param {string} b Bottom colour.
   * @returns {CanvasGradient} Gradient.
   */
  function vgrad(c, y0, y1, a, b) {
    var g = c.createLinearGradient(0, y0, 0, y1);
    g.addColorStop(0, a);
    g.addColorStop(1, b);
    return g;
  }

  /**
   * The ground shadow every standing body sits on — what keeps a drawn
   * object from floating over the tile it occupies.
   * @param {CanvasRenderingContext2D} c Context. @param {number} s Tile size.
   * @returns {void}
   */
  function groundShadow(c, s) {
    c.save();
    c.globalAlpha = 0.38;
    var g = c.createRadialGradient(s * 0.5, s * 0.82, s * 0.05, s * 0.5, s * 0.82, s * 0.42);
    g.addColorStop(0, '#000000');
    g.addColorStop(1, 'rgba(0,0,0,0)');
    c.fillStyle = g;
    c.fillRect(0, s * 0.55, s, s * 0.45);
    c.restore();
  }

  /**
   * The cool etched outline that ties a body into the schematic language.
   * @param {CanvasRenderingContext2D} c Context. @param {number} s Tile size.
   * @param {number} inset Border inset. @param {number} alpha Line alpha.
   * @returns {void}
   */
  function schematicRim(c, s, inset, alpha) {
    c.save();
    c.globalAlpha = alpha;
    c.strokeStyle = PAL.line;
    c.lineWidth = Math.max(1, s * 0.02);
    rr(c, inset, inset, s - inset * 2, s - inset * 2, s * 0.06);
    c.stroke();
    c.restore();
  }

  /**
   * A cube body: front face plus a lit top bevel — the shared silhouette of
   * every block material, so a room of mixed blocks still reads as one set.
   * @param {CanvasRenderingContext2D} c Context. @param {number} s Size.
   * @param {string} top Top colour. @param {string} faceA Face top colour.
   * @param {string} faceB Face bottom colour. @param {string} edge Edge colour.
   * @returns {{x:number,y:number,w:number,h:number}} The front-face box.
   */
  function cube(c, s, top, faceA, faceB, edge) {
    var x = s * 0.12, w = s * 0.76;
    var yT = s * 0.08, hT = s * 0.09;
    var yF = yT + hT, hF = s * 0.72;
    groundShadow(c, s);
    // top face as a trapezoid, so the body reads as a cube seen slightly from above
    c.fillStyle = top;
    c.beginPath();
    c.moveTo(x + w * 0.09, yT);
    c.lineTo(x + w * 0.91, yT);
    c.lineTo(x + w, yF);
    c.lineTo(x, yF);
    c.closePath();
    c.fill();
    // front face
    c.fillStyle = vgrad(c, yF, yF + hF, faceA, faceB);
    rr(c, x, yF, w, hF, s * 0.04);
    c.fill();
    // lit leading edge where top meets face
    c.save();
    c.globalAlpha = 0.65;
    c.strokeStyle = PAL.white;
    c.lineWidth = Math.max(1, s * 0.018);
    c.beginPath();
    c.moveTo(x + s * 0.02, yF + s * 0.008);
    c.lineTo(x + w - s * 0.02, yF + s * 0.008);
    c.stroke();
    c.restore();
    // outer edge around the whole body
    c.strokeStyle = edge;
    c.lineWidth = Math.max(1, s * 0.022);
    c.beginPath();
    c.moveTo(x + w * 0.09, yT);
    c.lineTo(x + w * 0.91, yT);
    c.lineTo(x + w, yF);
    c.lineTo(x + w, yF + hF - s * 0.04);
    c.arcTo(x + w, yF + hF, x + w - s * 0.04, yF + hF, s * 0.04);
    c.lineTo(x + s * 0.04, yF + hF);
    c.arcTo(x, yF + hF, x, yF + hF - s * 0.04, s * 0.04);
    c.lineTo(x, yF);
    c.closePath();
    c.stroke();
    return { x: x, y: yF, w: w, h: hF };
  }

  /**
   * The dark pit every bridge mark is laid into.
   * @param {CanvasRenderingContext2D} c Context. @param {number} s Size.
   * @returns {void}
   */
  function pitGround(c, s) {
    c.fillStyle = vgrad(c, 0, s, PAL.pitB, PAL.pitA);
    c.fillRect(0, 0, s, s);
    c.save();
    c.globalAlpha = 0.55;
    c.strokeStyle = '#000000';
    c.lineWidth = s * 0.10;
    c.strokeRect(s * 0.05, s * 0.05, s * 0.9, s * 0.9);
    c.restore();
  }

  /**
   * Ripple rings around a water crossing.
   * @param {CanvasRenderingContext2D} c Context. @param {number} s Size.
   * @returns {void}
   */
  function ripples(c, s) {
    c.save();
    c.strokeStyle = PAL.waterC;
    c.lineWidth = Math.max(1, s * 0.02);
    c.globalAlpha = 0.5;
    c.beginPath(); c.ellipse(s * 0.5, s * 0.62, s * 0.40, s * 0.16, 0, 0, Math.PI * 2); c.stroke();
    c.globalAlpha = 0.28;
    c.beginPath(); c.ellipse(s * 0.5, s * 0.64, s * 0.47, s * 0.20, 0, 0, Math.PI * 2); c.stroke();
    c.restore();
  }

  /* ------------------------------------------------------------------ *
   * BLOCK FACES — six materials, one silhouette
   * ------------------------------------------------------------------ */

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function blockStone(c, s) {
    var f = cube(c, s, PAL.stoneA, PAL.stoneB, PAL.stoneC, '#232837');
    // mortar seams — a running bond, offset per course
    c.strokeStyle = '#232837';
    c.lineWidth = Math.max(1, s * 0.018);
    c.beginPath();
    c.moveTo(f.x, f.y + f.h * 0.34); c.lineTo(f.x + f.w, f.y + f.h * 0.34);
    c.moveTo(f.x, f.y + f.h * 0.67); c.lineTo(f.x + f.w, f.y + f.h * 0.67);
    c.moveTo(f.x + f.w * 0.5, f.y); c.lineTo(f.x + f.w * 0.5, f.y + f.h * 0.34);
    c.moveTo(f.x + f.w * 0.25, f.y + f.h * 0.34); c.lineTo(f.x + f.w * 0.25, f.y + f.h * 0.67);
    c.moveTo(f.x + f.w * 0.75, f.y + f.h * 0.34); c.lineTo(f.x + f.w * 0.75, f.y + f.h * 0.67);
    c.moveTo(f.x + f.w * 0.5, f.y + f.h * 0.67); c.lineTo(f.x + f.w * 0.5, f.y + f.h);
    c.stroke();
    // carved square rune, the stone set's signature
    c.save();
    c.globalAlpha = 0.8;
    c.strokeStyle = PAL.stoneA;
    c.lineWidth = Math.max(1, s * 0.03);
    c.strokeRect(f.x + f.w * 0.38, f.y + f.h * 0.40, f.w * 0.24, f.h * 0.24);
    c.restore();
    schematicRim(c, s, s * 0.06, 0.35);
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function blockWood(c, s) {
    var f = cube(c, s, PAL.woodA, PAL.woodB, PAL.woodC, '#3a2a16');
    // plank seams and grain
    c.strokeStyle = '#3a2a16';
    c.lineWidth = Math.max(1, s * 0.02);
    c.beginPath();
    c.moveTo(f.x, f.y + f.h * 0.5); c.lineTo(f.x + f.w, f.y + f.h * 0.5);
    c.stroke();
    c.save();
    c.globalAlpha = 0.5;
    c.strokeStyle = PAL.woodC;
    c.lineWidth = Math.max(1, s * 0.012);
    c.beginPath();
    c.moveTo(f.x + f.w * 0.1, f.y + f.h * 0.18);
    c.bezierCurveTo(f.x + f.w * 0.4, f.y + f.h * 0.10, f.x + f.w * 0.6, f.y + f.h * 0.28, f.x + f.w * 0.9, f.y + f.h * 0.2);
    c.moveTo(f.x + f.w * 0.1, f.y + f.h * 0.74);
    c.bezierCurveTo(f.x + f.w * 0.35, f.y + f.h * 0.66, f.x + f.w * 0.6, f.y + f.h * 0.86, f.x + f.w * 0.9, f.y + f.h * 0.76);
    c.stroke();
    c.restore();
    // iron corner brackets
    c.strokeStyle = PAL.ironB;
    c.lineWidth = Math.max(1, s * 0.035);
    c.beginPath();
    c.moveTo(f.x + s * 0.015, f.y + f.h * 0.22); c.lineTo(f.x + s * 0.015, f.y); c.lineTo(f.x + f.w * 0.2, f.y);
    c.moveTo(f.x + f.w - s * 0.015, f.y + f.h * 0.22); c.lineTo(f.x + f.w - s * 0.015, f.y); c.lineTo(f.x + f.w * 0.8, f.y);
    c.stroke();
    schematicRim(c, s, s * 0.06, 0.35);
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function blockIce(c, s) {
    var f = cube(c, s, PAL.iceA, PAL.iceB, PAL.iceC, '#20506e');
    // inner facets
    c.save();
    c.globalAlpha = 0.55;
    c.strokeStyle = PAL.iceA;
    c.lineWidth = Math.max(1, s * 0.02);
    c.beginPath();
    c.moveTo(f.x + f.w * 0.18, f.y + f.h * 0.9); c.lineTo(f.x + f.w * 0.44, f.y + f.h * 0.16);
    c.lineTo(f.x + f.w * 0.62, f.y + f.h * 0.55); c.lineTo(f.x + f.w * 0.86, f.y + f.h * 0.12);
    c.stroke();
    c.restore();
    // specular streak
    c.save();
    c.globalAlpha = 0.7;
    c.fillStyle = PAL.white;
    c.beginPath();
    c.moveTo(f.x + f.w * 0.14, f.y + f.h * 0.30);
    c.lineTo(f.x + f.w * 0.26, f.y + f.h * 0.10);
    c.lineTo(f.x + f.w * 0.34, f.y + f.h * 0.12);
    c.lineTo(f.x + f.w * 0.20, f.y + f.h * 0.34);
    c.closePath();
    c.fill();
    c.restore();
    schematicRim(c, s, s * 0.06, 0.4);
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function blockIron(c, s) {
    var f = cube(c, s, PAL.ironA, PAL.ironB, PAL.ironC, '#1d222b');
    // brushed lines
    c.save();
    c.globalAlpha = 0.35;
    c.strokeStyle = PAL.ironA;
    c.lineWidth = Math.max(1, s * 0.012);
    c.beginPath();
    for (var i = 1; i <= 4; i++) {
      c.moveTo(f.x + f.w * 0.08, f.y + f.h * (i / 5));
      c.lineTo(f.x + f.w * 0.92, f.y + f.h * (i / 5));
    }
    c.stroke();
    c.restore();
    // rivets in the corners
    c.fillStyle = PAL.ironA;
    var rv = Math.max(1.5, s * 0.035);
    c.beginPath(); c.arc(f.x + f.w * 0.12, f.y + f.h * 0.14, rv, 0, Math.PI * 2); c.fill();
    c.beginPath(); c.arc(f.x + f.w * 0.88, f.y + f.h * 0.14, rv, 0, Math.PI * 2); c.fill();
    c.beginPath(); c.arc(f.x + f.w * 0.12, f.y + f.h * 0.86, rv, 0, Math.PI * 2); c.fill();
    c.beginPath(); c.arc(f.x + f.w * 0.88, f.y + f.h * 0.86, rv, 0, Math.PI * 2); c.fill();
    schematicRim(c, s, s * 0.06, 0.3);
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function blockGild(c, s) {
    var f = cube(c, s, PAL.gildA, PAL.gildB, PAL.gildC, '#5c451a');
    // filigree border
    c.save();
    c.globalAlpha = 0.85;
    c.strokeStyle = PAL.gildA;
    c.lineWidth = Math.max(1, s * 0.02);
    rr(c, f.x + f.w * 0.12, f.y + f.h * 0.14, f.w * 0.76, f.h * 0.72, s * 0.04);
    c.stroke();
    // corner curls
    c.beginPath();
    c.arc(f.x + f.w * 0.22, f.y + f.h * 0.26, s * 0.045, Math.PI * 0.5, Math.PI * 1.5);
    c.arc(f.x + f.w * 0.78, f.y + f.h * 0.26, s * 0.045, Math.PI * 1.5, Math.PI * 0.5);
    c.stroke();
    c.restore();
    // the gem dot
    c.fillStyle = PAL.lightHot;
    c.beginPath(); c.arc(f.x + f.w * 0.5, f.y + f.h * 0.52, s * 0.05, 0, Math.PI * 2); c.fill();
    c.save();
    c.globalAlpha = 0.35;
    c.fillStyle = PAL.light;
    c.beginPath(); c.arc(f.x + f.w * 0.5, f.y + f.h * 0.52, s * 0.11, 0, Math.PI * 2); c.fill();
    c.restore();
    schematicRim(c, s, s * 0.06, 0.3);
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function blockRune(c, s) {
    var f = cube(c, s, PAL.runeA, PAL.runeA, PAL.runeB, '#171226');
    // glowing circuitry glyph — the rune set's signature
    c.save();
    c.globalAlpha = 0.25;
    c.strokeStyle = PAL.runeGlow;
    c.lineWidth = Math.max(2, s * 0.07);
    circuitry(c, f);
    c.stroke();
    c.globalAlpha = 1;
    c.lineWidth = Math.max(1, s * 0.022);
    circuitry(c, f);
    c.stroke();
    c.fillStyle = PAL.runeGlow;
    c.beginPath(); c.arc(f.x + f.w * 0.5, f.y + f.h * 0.5, s * 0.035, 0, Math.PI * 2); c.fill();
    c.restore();
    schematicRim(c, s, s * 0.06, 0.3);
  }

  /**
   * The rune block's circuit path, shared by its glow and line passes.
   * @param {CanvasRenderingContext2D} c Context.
   * @param {{x:number,y:number,w:number,h:number}} f Face box.
   * @returns {void}
   */
  function circuitry(c, f) {
    c.beginPath();
    c.moveTo(f.x + f.w * 0.5, f.y + f.h * 0.12);
    c.lineTo(f.x + f.w * 0.5, f.y + f.h * 0.34);
    c.lineTo(f.x + f.w * 0.26, f.y + f.h * 0.5);
    c.lineTo(f.x + f.w * 0.5, f.y + f.h * 0.66);
    c.lineTo(f.x + f.w * 0.74, f.y + f.h * 0.5);
    c.lineTo(f.x + f.w * 0.5, f.y + f.h * 0.34);
    c.moveTo(f.x + f.w * 0.5, f.y + f.h * 0.66);
    c.lineTo(f.x + f.w * 0.5, f.y + f.h * 0.88);
  }

  /* ------------------------------------------------------------------ *
   * BRIDGES — the material laid INTO a hole. The pit stays visible at
   * the edges, so a crossing still explains what it crossed.
   * ------------------------------------------------------------------ */

  /**
   * Shared bridge scaffold: pit, then a material deck drawn by `deck`.
   * @param {CanvasRenderingContext2D} c Context. @param {number} s Size.
   * @param {Function} deck Deck painter `(c, s, x, y, w, h)`.
   * @returns {void}
   */
  function bridge(c, s, deck) {
    pitGround(c, s);
    deck(c, s, s * 0.08, s * 0.16, s * 0.84, s * 0.68);
    // depth shadow over the deck ends
    c.save();
    c.globalAlpha = 0.45;
    c.fillStyle = '#000000';
    c.fillRect(s * 0.08, s * 0.16, s * 0.84, s * 0.06);
    c.restore();
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function bridgeStone(c, s) {
    bridge(c, s, function (cc, ss, x, y, w, h) {
      cc.fillStyle = vgrad(cc, y, y + h, PAL.stoneB, PAL.stoneC);
      cc.fillRect(x, y, w, h);
      cc.strokeStyle = '#232837';
      cc.lineWidth = Math.max(1, ss * 0.02);
      cc.beginPath();
      cc.moveTo(x, y + h * 0.5); cc.lineTo(x + w, y + h * 0.5);
      cc.moveTo(x + w * 0.33, y); cc.lineTo(x + w * 0.33, y + h * 0.5);
      cc.moveTo(x + w * 0.66, y + h * 0.5); cc.lineTo(x + w * 0.66, y + h);
      cc.stroke();
      // the crack that says "this slab was dropped here"
      cc.save();
      cc.globalAlpha = 0.6;
      cc.strokeStyle = PAL.ink;
      cc.beginPath();
      cc.moveTo(x + w * 0.2, y + h * 0.14);
      cc.lineTo(x + w * 0.38, y + h * 0.42);
      cc.lineTo(x + w * 0.3, y + h * 0.72);
      cc.stroke();
      cc.restore();
    });
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function bridgeWood(c, s) {
    bridge(c, s, function (cc, ss, x, y, w, h) {
      // planks across the pit, gaps showing dark between them
      var n = 4;
      var ph = h / n;
      for (var i = 0; i < n; i++) {
        cc.fillStyle = i % 2 ? PAL.woodB : PAL.woodA;
        cc.fillRect(x, y + i * ph + ph * 0.08, w, ph * 0.84);
      }
      cc.save();
      cc.globalAlpha = 0.5;
      cc.strokeStyle = PAL.woodC;
      cc.lineWidth = Math.max(1, ss * 0.014);
      cc.beginPath();
      for (var j = 0; j < n; j++) {
        cc.moveTo(x + w * 0.12, y + j * ph + ph * 0.5);
        cc.lineTo(x + w * 0.88, y + j * ph + ph * 0.5);
      }
      cc.stroke();
      cc.restore();
      // nail heads on the rails
      cc.fillStyle = PAL.ironB;
      var rv = Math.max(1, ss * 0.025);
      for (var k = 0; k < n; k++) {
        cc.beginPath(); cc.arc(x + w * 0.08, y + k * ph + ph * 0.5, rv, 0, Math.PI * 2); cc.fill();
        cc.beginPath(); cc.arc(x + w * 0.92, y + k * ph + ph * 0.5, rv, 0, Math.PI * 2); cc.fill();
      }
    });
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function bridgeIce(c, s) {
    bridge(c, s, function (cc, ss, x, y, w, h) {
      cc.save();
      cc.globalAlpha = 0.85;
      cc.fillStyle = vgrad(cc, y, y + h, PAL.iceB, PAL.iceC);
      cc.fillRect(x, y, w, h);
      cc.globalAlpha = 0.5;
      cc.strokeStyle = PAL.iceA;
      cc.lineWidth = Math.max(1, ss * 0.018);
      cc.beginPath();
      cc.moveTo(x + w * 0.1, y + h * 0.75); cc.lineTo(x + w * 0.4, y + h * 0.2);
      cc.moveTo(x + w * 0.45, y + h * 0.85); cc.lineTo(x + w * 0.7, y + h * 0.3);
      cc.lineTo(x + w * 0.9, y + h * 0.6);
      cc.stroke();
      cc.globalAlpha = 0.8;
      cc.fillStyle = PAL.white;
      cc.fillRect(x + w * 0.14, y + h * 0.16, w * 0.16, ss * 0.03);
      cc.restore();
    });
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function bridgeIron(c, s) {
    bridge(c, s, function (cc, ss, x, y, w, h) {
      cc.fillStyle = vgrad(cc, y, y + h, PAL.ironB, PAL.ironC);
      cc.fillRect(x, y, w, h);
      // tread plate: diagonal dashes in two directions
      cc.save();
      cc.globalAlpha = 0.5;
      cc.strokeStyle = PAL.ironA;
      cc.lineWidth = Math.max(1, ss * 0.02);
      cc.beginPath();
      for (var i = 0; i < 3; i++) {
        for (var j = 0; j < 3; j++) {
          var cx = x + w * (0.2 + i * 0.3);
          var cy = y + h * (0.2 + j * 0.3);
          var d = ss * 0.05;
          if ((i + j) % 2) { cc.moveTo(cx - d, cy + d); cc.lineTo(cx + d, cy - d); }
          else { cc.moveTo(cx - d, cy - d); cc.lineTo(cx + d, cy + d); }
        }
      }
      cc.stroke();
      cc.restore();
      cc.strokeStyle = PAL.ironC;
      cc.lineWidth = Math.max(1, ss * 0.025);
      cc.strokeRect(x, y, w, h);
    });
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function bridgeGild(c, s) {
    bridge(c, s, function (cc, ss, x, y, w, h) {
      cc.fillStyle = vgrad(cc, y, y + h, PAL.gildB, PAL.gildC);
      cc.fillRect(x, y, w, h);
      cc.save();
      cc.globalAlpha = 0.8;
      cc.strokeStyle = PAL.gildA;
      cc.lineWidth = Math.max(1, ss * 0.02);
      rr(cc, x + w * 0.1, y + h * 0.15, w * 0.8, h * 0.7, ss * 0.03);
      cc.stroke();
      // inlaid sun disc
      cc.beginPath(); cc.arc(x + w * 0.5, y + h * 0.5, ss * 0.09, 0, Math.PI * 2); cc.stroke();
      cc.globalAlpha = 0.9;
      cc.fillStyle = PAL.lightHot;
      cc.beginPath(); cc.arc(x + w * 0.5, y + h * 0.5, ss * 0.035, 0, Math.PI * 2); cc.fill();
      cc.restore();
    });
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function bridgeRune(c, s) {
    bridge(c, s, function (cc, ss, x, y, w, h) {
      cc.fillStyle = vgrad(cc, y, y + h, PAL.runeA, PAL.runeB);
      cc.fillRect(x, y, w, h);
      cc.save();
      cc.globalAlpha = 0.3;
      cc.strokeStyle = PAL.runeGlow;
      cc.lineWidth = Math.max(2, ss * 0.06);
      runePath(cc, x, y, w, h);
      cc.stroke();
      cc.globalAlpha = 1;
      cc.lineWidth = Math.max(1, ss * 0.02);
      runePath(cc, x, y, w, h);
      cc.stroke();
      cc.restore();
    });
  }

  /**
   * The rune bridge's sigil path.
   * @param {CanvasRenderingContext2D} c Context.
   * @param {number} x Left. @param {number} y Top. @param {number} w Width. @param {number} h Height.
   * @returns {void}
   */
  function runePath(c, x, y, w, h) {
    c.beginPath();
    c.moveTo(x + w * 0.15, y + h * 0.5);
    c.lineTo(x + w * 0.85, y + h * 0.5);
    c.moveTo(x + w * 0.3, y + h * 0.22);
    c.lineTo(x + w * 0.3, y + h * 0.78);
    c.moveTo(x + w * 0.7, y + h * 0.22);
    c.lineTo(x + w * 0.7, y + h * 0.78);
    c.moveTo(x + w * 0.5, y + h * 0.5);
    c.arc(x + w * 0.5, y + h * 0.5, h * 0.18, 0, Math.PI * 2);
  }

  /* ------------------------------------------------------------------ *
   * FORDS — the material sunk into water, ripples closing over it
   * ------------------------------------------------------------------ */

  /**
   * Shared ford scaffold: water, a submerged deck, ripple rings.
   * @param {CanvasRenderingContext2D} c Context. @param {number} s Size.
   * @param {Function} deck Deck painter `(c, s, x, y, w, h)`.
   * @returns {void}
   */
  function ford(c, s, deck) {
    c.fillStyle = vgrad(c, 0, s, PAL.waterA, PAL.waterB);
    c.fillRect(0, 0, s, s);
    c.save();
    c.globalAlpha = 0.9;
    deck(c, s, s * 0.14, s * 0.22, s * 0.72, s * 0.5);
    c.restore();
    // water re-tints whatever sank
    c.save();
    c.globalAlpha = 0.28;
    c.fillStyle = PAL.waterA;
    c.fillRect(s * 0.14, s * 0.22, s * 0.72, s * 0.5);
    c.restore();
    ripples(c, s);
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function fordStone(c, s) {
    ford(c, s, function (cc, ss, x, y, w, h) {
      cc.fillStyle = PAL.stoneB;
      rr(cc, x, y, w, h, ss * 0.05);
      cc.fill();
      cc.strokeStyle = PAL.stoneC;
      cc.lineWidth = Math.max(1, ss * 0.02);
      cc.beginPath();
      cc.moveTo(x + w * 0.5, y); cc.lineTo(x + w * 0.5, y + h);
      cc.moveTo(x, y + h * 0.5); cc.lineTo(x + w, y + h * 0.5);
      cc.stroke();
    });
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function fordWood(c, s) {
    ford(c, s, function (cc, ss, x, y, w, h) {
      var n = 3, ph = h / n;
      for (var i = 0; i < n; i++) {
        cc.fillStyle = i % 2 ? PAL.woodB : PAL.woodA;
        cc.fillRect(x, y + i * ph + ph * 0.1, w, ph * 0.8);
      }
    });
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function fordIce(c, s) {
    ford(c, s, function (cc, ss, x, y, w, h) {
      cc.fillStyle = PAL.iceB;
      rr(cc, x, y, w, h, ss * 0.08);
      cc.fill();
      cc.save();
      cc.globalAlpha = 0.7;
      cc.strokeStyle = PAL.iceA;
      cc.lineWidth = Math.max(1, ss * 0.02);
      cc.beginPath();
      cc.moveTo(x + w * 0.2, y + h * 0.7); cc.lineTo(x + w * 0.5, y + h * 0.2); cc.lineTo(x + w * 0.75, y + h * 0.6);
      cc.stroke();
      cc.restore();
    });
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function fordIron(c, s) {
    ford(c, s, function (cc, ss, x, y, w, h) {
      cc.fillStyle = PAL.ironB;
      rr(cc, x, y, w, h, ss * 0.04);
      cc.fill();
      cc.fillStyle = PAL.ironA;
      var rv = Math.max(1, ss * 0.028);
      cc.beginPath(); cc.arc(x + w * 0.2, y + h * 0.28, rv, 0, Math.PI * 2); cc.fill();
      cc.beginPath(); cc.arc(x + w * 0.8, y + h * 0.28, rv, 0, Math.PI * 2); cc.fill();
      cc.beginPath(); cc.arc(x + w * 0.2, y + h * 0.72, rv, 0, Math.PI * 2); cc.fill();
      cc.beginPath(); cc.arc(x + w * 0.8, y + h * 0.72, rv, 0, Math.PI * 2); cc.fill();
    });
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function fordGild(c, s) {
    ford(c, s, function (cc, ss, x, y, w, h) {
      cc.fillStyle = PAL.gildB;
      rr(cc, x, y, w, h, ss * 0.05);
      cc.fill();
      cc.strokeStyle = PAL.gildA;
      cc.lineWidth = Math.max(1, ss * 0.02);
      rr(cc, x + w * 0.14, y + h * 0.2, w * 0.72, h * 0.6, ss * 0.03);
      cc.stroke();
    });
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function fordRune(c, s) {
    ford(c, s, function (cc, ss, x, y, w, h) {
      cc.fillStyle = PAL.runeA;
      rr(cc, x, y, w, h, ss * 0.05);
      cc.fill();
      cc.save();
      cc.globalAlpha = 0.9;
      cc.strokeStyle = PAL.runeGlow;
      cc.lineWidth = Math.max(1, ss * 0.02);
      cc.beginPath();
      cc.arc(x + w * 0.5, y + h * 0.5, h * 0.28, 0, Math.PI * 2);
      cc.moveTo(x + w * 0.5 - h * 0.28, y + h * 0.5);
      cc.lineTo(x + w * 0.5 + h * 0.28, y + h * 0.5);
      cc.stroke();
      cc.restore();
    });
  }

  /* ------------------------------------------------------------------ *
   * BOULDERS — three materials, one silhouette; plus the shards left
   * where one shattered
   * ------------------------------------------------------------------ */

  /**
   * Shared boulder scaffold: shadow, sphere, then a material dressing.
   * @param {CanvasRenderingContext2D} c Context. @param {number} s Size.
   * @param {string} hi Highlight colour. @param {string} mid Mid colour.
   * @param {string} lo Shadow colour. @param {Function} dress Dressing painter.
   * @returns {void}
   */
  function boulder(c, s, hi, mid, lo, dress) {
    groundShadow(c, s);
    var cx = s * 0.5, cy = s * 0.52, r = s * 0.34;
    var g = c.createRadialGradient(cx - r * 0.45, cy - r * 0.5, r * 0.1, cx, cy, r * 1.15);
    g.addColorStop(0, hi);
    g.addColorStop(0.55, mid);
    g.addColorStop(1, lo);
    c.fillStyle = g;
    c.beginPath(); c.arc(cx, cy, r, 0, Math.PI * 2); c.fill();
    c.strokeStyle = lo;
    c.lineWidth = Math.max(1, s * 0.02);
    c.beginPath(); c.arc(cx, cy, r, 0, Math.PI * 2); c.stroke();
    dress(c, s, cx, cy, r);
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function boulderGranite(c, s) {
    boulder(c, s, PAL.stoneA, PAL.stoneB, PAL.stoneC, function (cc, ss, cx, cy, r) {
      cc.save();
      cc.globalAlpha = 0.6;
      cc.strokeStyle = PAL.stoneC;
      cc.lineWidth = Math.max(1, ss * 0.02);
      cc.beginPath();
      cc.moveTo(cx - r * 0.7, cy - r * 0.1);
      cc.lineTo(cx - r * 0.2, cy - r * 0.35);
      cc.lineTo(cx + r * 0.25, cy - r * 0.05);
      cc.lineTo(cx + r * 0.7, cy - r * 0.3);
      cc.moveTo(cx - r * 0.3, cy + r * 0.45);
      cc.lineTo(cx + r * 0.15, cy + r * 0.2);
      cc.lineTo(cx + r * 0.55, cy + r * 0.5);
      cc.stroke();
      cc.restore();
    });
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function boulderAmber(c, s) {
    boulder(c, s, PAL.lightHot, PAL.light, '#8a5420', function (cc, ss, cx, cy, r) {
      // an inclusion glowing inside translucent amber
      cc.save();
      cc.globalAlpha = 0.5;
      cc.fillStyle = PAL.lightHot;
      cc.beginPath(); cc.arc(cx + r * 0.1, cy + r * 0.05, r * 0.35, 0, Math.PI * 2); cc.fill();
      cc.globalAlpha = 0.85;
      cc.fillStyle = PAL.white;
      cc.beginPath(); cc.ellipse(cx - r * 0.35, cy - r * 0.45, r * 0.18, r * 0.09, -0.6, 0, Math.PI * 2); cc.fill();
      cc.restore();
    });
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function boulderObsidian(c, s) {
    boulder(c, s, '#4a4f66', '#22242f', '#0c0d13', function (cc, ss, cx, cy, r) {
      // conchoidal fracture: sharp arc highlights
      cc.save();
      cc.globalAlpha = 0.8;
      cc.strokeStyle = '#8b93b8';
      cc.lineWidth = Math.max(1, ss * 0.018);
      cc.beginPath();
      cc.arc(cx - r * 0.15, cy - r * 0.1, r * 0.55, Math.PI * 1.15, Math.PI * 1.7);
      cc.stroke();
      cc.beginPath();
      cc.arc(cx + r * 0.2, cy + r * 0.15, r * 0.45, Math.PI * 1.2, Math.PI * 1.75);
      cc.stroke();
      cc.globalAlpha = 0.9;
      cc.fillStyle = PAL.white;
      cc.beginPath(); cc.ellipse(cx - r * 0.3, cy - r * 0.4, r * 0.12, r * 0.05, -0.7, 0, Math.PI * 2); cc.fill();
      cc.restore();
    });
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function boulderShards(c, s) {
    groundShadow(c, s);
    // scattered fragments where the boulder ended
    var frags = [
      { x: 0.32, y: 0.55, r: 0.14, a: 0.4 },
      { x: 0.56, y: 0.44, r: 0.11, a: 2.1 },
      { x: 0.66, y: 0.66, r: 0.09, a: 4.0 },
      { x: 0.42, y: 0.74, r: 0.08, a: 1.2 },
      { x: 0.52, y: 0.60, r: 0.06, a: 5.1 }
    ];
    for (var i = 0; i < frags.length; i++) {
      var f = frags[i];
      var cx = s * f.x, cy = s * f.y, r = s * f.r;
      c.fillStyle = i % 2 ? PAL.stoneB : PAL.stoneC;
      c.beginPath();
      c.moveTo(cx + r * Math.cos(f.a), cy + r * Math.sin(f.a));
      c.lineTo(cx + r * Math.cos(f.a + 2.0), cy + r * Math.sin(f.a + 2.0));
      c.lineTo(cx + r * Math.cos(f.a + 4.2), cy + r * Math.sin(f.a + 4.2));
      c.closePath();
      c.fill();
      c.strokeStyle = PAL.stoneA;
      c.lineWidth = Math.max(1, s * 0.012);
      c.stroke();
    }
    // impact ticks
    c.save();
    c.globalAlpha = 0.45;
    c.strokeStyle = PAL.stoneA;
    c.lineWidth = Math.max(1, s * 0.015);
    c.beginPath();
    c.moveTo(s * 0.24, s * 0.38); c.lineTo(s * 0.18, s * 0.30);
    c.moveTo(s * 0.72, s * 0.40); c.lineTo(s * 0.80, s * 0.33);
    c.moveTo(s * 0.76, s * 0.78); c.lineTo(s * 0.84, s * 0.84);
    c.stroke();
    c.restore();
  }

  /* ------------------------------------------------------------------ *
   * MIRRORS, PLATES, EMITTERS, RECEIVERS
   * ------------------------------------------------------------------ */

  /**
   * Shared mirror scaffold. The silvered band runs along `slash` ? '/' : '\'.
   * @param {CanvasRenderingContext2D} c Context. @param {number} s Size.
   * @param {boolean} slash True for '/'.
   * @returns {void}
   */
  function mirror(c, s, slash) {
    groundShadow(c, s);
    // etched frame
    c.strokeStyle = PAL.ironC;
    c.lineWidth = Math.max(1.5, s * 0.05);
    rr(c, s * 0.12, s * 0.12, s * 0.76, s * 0.76, s * 0.08);
    c.stroke();
    c.strokeStyle = PAL.ironA;
    c.lineWidth = Math.max(1, s * 0.02);
    rr(c, s * 0.12, s * 0.12, s * 0.76, s * 0.76, s * 0.08);
    c.stroke();
    // the silvered surface, angled
    var g;
    c.save();
    c.beginPath();
    if (slash) {
      c.moveTo(s * 0.20, s * 0.80);
      c.lineTo(s * 0.72, s * 0.20);
      c.lineTo(s * 0.80, s * 0.28);
      c.lineTo(s * 0.28, s * 0.86);
      g = c.createLinearGradient(s * 0.2, s * 0.8, s * 0.8, s * 0.2);
    } else {
      c.moveTo(s * 0.20, s * 0.20);
      c.lineTo(s * 0.72, s * 0.80);
      c.lineTo(s * 0.80, s * 0.72);
      c.lineTo(s * 0.28, s * 0.14);
      g = c.createLinearGradient(s * 0.2, s * 0.2, s * 0.8, s * 0.8);
    }
    c.closePath();
    g.addColorStop(0, PAL.iceC);
    g.addColorStop(0.45, PAL.white);
    g.addColorStop(0.55, PAL.iceA);
    g.addColorStop(1, PAL.iceC);
    c.fillStyle = g;
    c.fill();
    c.restore();
    // corner jewels on the frame
    c.fillStyle = PAL.light;
    var jr = Math.max(1.5, s * 0.035);
    if (slash) {
      c.beginPath(); c.arc(s * 0.16, s * 0.84, jr, 0, Math.PI * 2); c.fill();
      c.beginPath(); c.arc(s * 0.84, s * 0.16, jr, 0, Math.PI * 2); c.fill();
    } else {
      c.beginPath(); c.arc(s * 0.16, s * 0.16, jr, 0, Math.PI * 2); c.fill();
      c.beginPath(); c.arc(s * 0.84, s * 0.84, jr, 0, Math.PI * 2); c.fill();
    }
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function mirrorSlash(c, s) { mirror(c, s, true); }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function mirrorBackslash(c, s) { mirror(c, s, false); }

  /**
   * Shared plate scaffold.
   * @param {CanvasRenderingContext2D} c Context. @param {number} s Size.
   * @param {boolean} pressed Pressed state.
   * @returns {void}
   */
  function plate(c, s, pressed) {
    var cx = s * 0.5, cy = s * 0.5;
    var col = pressed ? PAL.wire : PAL.lineDim;
    // recessed housing
    c.fillStyle = vgrad(c, s * 0.2, s * 0.8, PAL.slate, PAL.ink);
    c.beginPath(); c.arc(cx, cy, s * 0.36, 0, Math.PI * 2); c.fill();
    c.strokeStyle = PAL.slateUp;
    c.lineWidth = Math.max(1, s * 0.02);
    c.beginPath(); c.arc(cx, cy, s * 0.36, 0, Math.PI * 2); c.stroke();
    // the disc, sunk when pressed
    var dr = pressed ? s * 0.24 : s * 0.27;
    c.fillStyle = pressed ? '#1d3a30' : PAL.slateUp;
    c.beginPath(); c.arc(cx, cy, dr, 0, Math.PI * 2); c.fill();
    c.strokeStyle = col;
    c.lineWidth = Math.max(1, s * 0.025);
    c.beginPath(); c.arc(cx, cy, dr, 0, Math.PI * 2); c.stroke();
    // radial ticks — lit when live
    c.save();
    c.globalAlpha = pressed ? 1 : 0.5;
    c.strokeStyle = col;
    c.lineWidth = Math.max(1, s * 0.02);
    c.beginPath();
    for (var i = 0; i < 8; i++) {
      var a = (Math.PI * 2 * i) / 8;
      c.moveTo(cx + Math.cos(a) * s * 0.30, cy + Math.sin(a) * s * 0.30);
      c.lineTo(cx + Math.cos(a) * s * 0.36, cy + Math.sin(a) * s * 0.36);
    }
    c.stroke();
    c.restore();
    if (pressed) {
      c.save();
      c.globalAlpha = 0.3;
      c.fillStyle = PAL.wire;
      c.beginPath(); c.arc(cx, cy, s * 0.33, 0, Math.PI * 2); c.fill();
      c.restore();
    } else {
      // idle centre pip, waiting
      c.fillStyle = col;
      c.beginPath(); c.arc(cx, cy, s * 0.04, 0, Math.PI * 2); c.fill();
    }
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function plateIdle(c, s) { plate(c, s, false); }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function platePressed(c, s) { plate(c, s, true); }

  /**
   * Shared emitter scaffold: a lens housing with a directional aperture.
   * `dir` is an RPG Maker direction: 2 down, 4 left, 6 right, 8 up.
   * @param {CanvasRenderingContext2D} c Context. @param {number} s Size.
   * @param {number} dir Direction.
   * @returns {void}
   */
  function emitter(c, s, dir) {
    groundShadow(c, s);
    var cx = s * 0.5, cy = s * 0.48;
    var ang = dir === 2 ? Math.PI * 0.5 : dir === 8 ? -Math.PI * 0.5 : dir === 4 ? Math.PI : 0;
    // housing
    c.fillStyle = vgrad(c, s * 0.14, s * 0.84, PAL.ironB, PAL.ironC);
    c.beginPath(); c.arc(cx, cy, s * 0.30, 0, Math.PI * 2); c.fill();
    c.strokeStyle = PAL.ironC;
    c.lineWidth = Math.max(1, s * 0.03);
    c.beginPath(); c.arc(cx, cy, s * 0.30, 0, Math.PI * 2); c.stroke();
    // rim bolts
    c.fillStyle = PAL.ironA;
    for (var i = 0; i < 4; i++) {
      var a = ang + Math.PI * 0.25 + (Math.PI * 0.5) * i;
      c.beginPath();
      c.arc(cx + Math.cos(a) * s * 0.30, cy + Math.sin(a) * s * 0.30, Math.max(1, s * 0.03), 0, Math.PI * 2);
      c.fill();
    }
    // the aperture cone, opening toward `dir`
    c.save();
    c.translate(cx, cy);
    c.rotate(ang);
    var g = c.createLinearGradient(0, 0, s * 0.5, 0);
    g.addColorStop(0, PAL.lightHot);
    g.addColorStop(1, 'rgba(255,180,84,0)');
    c.fillStyle = g;
    c.beginPath();
    c.moveTo(s * 0.06, -s * 0.10);
    c.lineTo(s * 0.48, -s * 0.20);
    c.lineTo(s * 0.48, s * 0.20);
    c.lineTo(s * 0.06, s * 0.10);
    c.closePath();
    c.fill();
    // aperture lip
    c.strokeStyle = PAL.gildB;
    c.lineWidth = Math.max(1, s * 0.03);
    c.beginPath();
    c.moveTo(s * 0.24, -s * 0.16);
    c.lineTo(s * 0.30, 0);
    c.lineTo(s * 0.24, s * 0.16);
    c.stroke();
    c.restore();
    // the flame in the lens
    c.fillStyle = PAL.lightHot;
    c.beginPath(); c.arc(cx, cy, s * 0.10, 0, Math.PI * 2); c.fill();
    c.save();
    c.globalAlpha = 0.45;
    c.fillStyle = PAL.light;
    c.beginPath(); c.arc(cx, cy, s * 0.17, 0, Math.PI * 2); c.fill();
    c.restore();
    // three radiating light ticks on the open side
    c.save();
    c.translate(cx, cy);
    c.rotate(ang);
    c.strokeStyle = PAL.light;
    c.lineWidth = Math.max(1, s * 0.02);
    c.globalAlpha = 0.8;
    c.beginPath();
    c.moveTo(s * 0.36, -s * 0.13); c.lineTo(s * 0.42, -s * 0.16);
    c.moveTo(s * 0.38, 0); c.lineTo(s * 0.46, 0);
    c.moveTo(s * 0.36, s * 0.13); c.lineTo(s * 0.42, s * 0.16);
    c.stroke();
    c.restore();
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function emitterDown(c, s) { emitter(c, s, 2); }
  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function emitterLeft(c, s) { emitter(c, s, 4); }
  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function emitterRight(c, s) { emitter(c, s, 6); }
  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function emitterUp(c, s) { emitter(c, s, 8); }

  /**
   * Shared receiver scaffold: an iris aperture, open and flooded when lit.
   * @param {CanvasRenderingContext2D} c Context. @param {number} s Size.
   * @param {boolean} lit Lit state.
   * @returns {void}
   */
  function receiver(c, s, lit) {
    groundShadow(c, s);
    var cx = s * 0.5, cy = s * 0.48;
    // housing ring
    c.fillStyle = vgrad(c, s * 0.14, s * 0.84, PAL.slateUp, PAL.ink);
    c.beginPath(); c.arc(cx, cy, s * 0.32, 0, Math.PI * 2); c.fill();
    c.strokeStyle = lit ? PAL.light : PAL.lineDim;
    c.lineWidth = Math.max(1, s * 0.03);
    c.beginPath(); c.arc(cx, cy, s * 0.32, 0, Math.PI * 2); c.stroke();
    // Iris blades. Dim GOLD when dark, not iron-grey: at map scale a grey-bladed ring reads as a
    // gear and collides with mark.mechanism — measured by misreading a real render. The warm tint
    // says "this is waiting for light" even before any light arrives.
    c.save();
    c.strokeStyle = lit ? PAL.gildA : PAL.gildC;
    c.lineWidth = Math.max(1, s * 0.025);
    c.globalAlpha = 0.9;
    var blades = 6;
    var inner = lit ? s * 0.07 : s * 0.16;
    c.beginPath();
    for (var i = 0; i < blades; i++) {
      var a = (Math.PI * 2 * i) / blades + (lit ? 0.5 : 0.1);
      c.moveTo(cx + Math.cos(a) * s * 0.28, cy + Math.sin(a) * s * 0.28);
      c.lineTo(cx + Math.cos(a + (lit ? 0.9 : 0.5)) * inner, cy + Math.sin(a + (lit ? 0.9 : 0.5)) * inner);
    }
    c.stroke();
    // and a faint amber waiting-pip dead centre, the target the beam is owed
    if (!lit) {
      c.globalAlpha = 0.5;
      c.fillStyle = PAL.light;
      c.beginPath(); c.arc(cx, cy, s * 0.035, 0, Math.PI * 2); c.fill();
    }
    c.restore();
    if (lit) {
      // flooded with the beam's own light
      c.save();
      c.globalAlpha = 0.9;
      c.fillStyle = PAL.lightHot;
      c.beginPath(); c.arc(cx, cy, s * 0.09, 0, Math.PI * 2); c.fill();
      c.globalAlpha = 0.4;
      c.fillStyle = PAL.light;
      c.beginPath(); c.arc(cx, cy, s * 0.2, 0, Math.PI * 2); c.fill();
      // bloom rays
      c.globalAlpha = 0.7;
      c.strokeStyle = PAL.light;
      c.lineWidth = Math.max(1, s * 0.02);
      c.beginPath();
      for (var j = 0; j < 4; j++) {
        var ra = Math.PI * 0.25 + (Math.PI * 0.5) * j;
        c.moveTo(cx + Math.cos(ra) * s * 0.34, cy + Math.sin(ra) * s * 0.34);
        c.lineTo(cx + Math.cos(ra) * s * 0.44, cy + Math.sin(ra) * s * 0.44);
      }
      c.stroke();
      c.restore();
    } else {
      // dark centre, waiting
      c.fillStyle = PAL.ink;
      c.beginPath(); c.arc(cx, cy, s * 0.10, 0, Math.PI * 2); c.fill();
      c.strokeStyle = PAL.lineDim;
      c.lineWidth = Math.max(1, s * 0.015);
      c.beginPath(); c.arc(cx, cy, s * 0.10, 0, Math.PI * 2); c.stroke();
    }
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function receiverDark(c, s) { receiver(c, s, false); }
  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function receiverLit(c, s) { receiver(c, s, true); }

  /* ------------------------------------------------------------------ *
   * LENS TERRAIN — the room redrawn as the machine sees it
   * ------------------------------------------------------------------ */

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function lensFloor(c, s) {
    // Distinctly LIGHTER than the wall. The first render put floor at #141b28 over wall #101a2a
    // and the room's shape was illegible — every cell read as the same dark hatch. The lens is a
    // readability instrument; if the floor plan does not read, nothing else about it matters.
    c.fillStyle = vgrad(c, 0, s, '#232e44', '#1a2336');
    c.fillRect(0, 0, s, s);
    c.save();
    // flagstone mottling — two soft tonal patches, so a floor field has quiet
    // texture instead of reading as empty panel
    c.globalAlpha = 0.18;
    c.fillStyle = '#33425f';
    c.beginPath(); c.ellipse(s * 0.32, s * 0.3, s * 0.26, s * 0.18, 0.4, 0, Math.PI * 2); c.fill();
    c.fillStyle = '#121a2a';
    c.beginPath(); c.ellipse(s * 0.7, s * 0.72, s * 0.24, s * 0.16, -0.5, 0, Math.PI * 2); c.fill();
    // faint diagonal grain
    c.globalAlpha = 0.10;
    c.strokeStyle = PAL.lineDim;
    c.lineWidth = Math.max(1, s * 0.012);
    c.beginPath();
    c.moveTo(s * 0.1, s * 0.85); c.lineTo(s * 0.5, s * 0.45);
    c.moveTo(s * 0.55, s * 0.95); c.lineTo(s * 0.9, s * 0.6);
    c.stroke();
    // drafting crosses at all four corners — the survey grid this floor belongs to
    c.strokeStyle = PAL.lineDim;
    c.lineWidth = Math.max(1, s * 0.015);
    c.globalAlpha = 0.45;
    var t = s * 0.1;
    c.beginPath();
    c.moveTo(0, t); c.lineTo(0, 0); c.lineTo(t, 0);
    c.moveTo(s - t, 0); c.lineTo(s, 0); c.lineTo(s, t);
    c.moveTo(s, s - t); c.lineTo(s, s); c.lineTo(s - t, s);
    c.moveTo(t, s); c.lineTo(0, s); c.lineTo(0, s - t);
    c.stroke();
    c.globalAlpha = 0.35;
    c.fillStyle = PAL.lineDim;
    c.beginPath(); c.arc(s * 0.5, s * 0.5, Math.max(1, s * 0.02), 0, Math.PI * 2); c.fill();
    c.restore();
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function lensWall(c, s) {
    c.fillStyle = vgrad(c, 0, s, '#101a2a', PAL.ink);
    c.fillRect(0, 0, s, s);
    c.save();
    // section hatching, two tones — the drafting convention for solid matter,
    // dense enough to read as matter rather than as background
    c.strokeStyle = '#22314a';
    c.globalAlpha = 0.8;
    c.lineWidth = Math.max(1, s * 0.02);
    c.beginPath();
    for (var i = -2; i < 8; i++) {
      c.moveTo(i * s * 0.16, s);
      c.lineTo(i * s * 0.16 + s * 0.5, 0);
    }
    c.stroke();
    c.strokeStyle = PAL.lineDim;
    c.globalAlpha = 0.28;
    c.lineWidth = Math.max(1, s * 0.012);
    c.beginPath();
    for (var j = -2; j < 8; j++) {
      c.moveTo(j * s * 0.16 + s * 0.08, s);
      c.lineTo(j * s * 0.16 + s * 0.58, 0);
    }
    c.stroke();
    // masonry hints: two etched course lines broken mid-tile
    c.strokeStyle = '#2c3a52';
    c.globalAlpha = 0.7;
    c.lineWidth = Math.max(1, s * 0.022);
    c.beginPath();
    c.moveTo(s * 0.04, s * 0.32); c.lineTo(s * 0.58, s * 0.32);
    c.moveTo(s * 0.42, s * 0.68); c.lineTo(s * 0.96, s * 0.68);
    c.stroke();
    // chiselled border
    c.strokeStyle = '#2c3a52';
    c.lineWidth = Math.max(1, s * 0.03);
    c.strokeRect(s * 0.03, s * 0.03, s * 0.94, s * 0.94);
    // top edge catch-light, so a wall face reads as standing proud of the floor
    c.globalAlpha = 0.35;
    c.strokeStyle = PAL.lineDim;
    c.lineWidth = Math.max(1, s * 0.02);
    c.beginPath();
    c.moveTo(s * 0.03, s * 0.045); c.lineTo(s * 0.97, s * 0.045);
    c.stroke();
    c.restore();
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function lensHole(c, s) {
    lensFloor(c, s);
    // the pit: depth rings falling to black
    var g = c.createRadialGradient(s * 0.5, s * 0.5, s * 0.05, s * 0.5, s * 0.5, s * 0.46);
    g.addColorStop(0, '#000000');
    g.addColorStop(0.75, PAL.pitA);
    g.addColorStop(1, PAL.slate);
    c.fillStyle = g;
    rr(c, s * 0.08, s * 0.08, s * 0.84, s * 0.84, s * 0.1);
    c.fill();
    c.save();
    c.strokeStyle = PAL.hazard;
    c.globalAlpha = 0.8;
    c.lineWidth = Math.max(1, s * 0.02);
    rr(c, s * 0.08, s * 0.08, s * 0.84, s * 0.84, s * 0.1);
    c.stroke();
    // depth contour rings
    c.globalAlpha = 0.3;
    c.strokeStyle = PAL.lineDim;
    rr(c, s * 0.2, s * 0.2, s * 0.6, s * 0.6, s * 0.07);
    c.stroke();
    rr(c, s * 0.32, s * 0.32, s * 0.36, s * 0.36, s * 0.05);
    c.stroke();
    // danger ticks at the corners
    c.globalAlpha = 0.9;
    c.strokeStyle = PAL.hazard;
    c.beginPath();
    c.moveTo(s * 0.08, s * 0.2); c.lineTo(s * 0.08, s * 0.08); c.lineTo(s * 0.2, s * 0.08);
    c.moveTo(s * 0.8, s * 0.08); c.lineTo(s * 0.92, s * 0.08); c.lineTo(s * 0.92, s * 0.2);
    c.moveTo(s * 0.92, s * 0.8); c.lineTo(s * 0.92, s * 0.92); c.lineTo(s * 0.8, s * 0.92);
    c.moveTo(s * 0.2, s * 0.92); c.lineTo(s * 0.08, s * 0.92); c.lineTo(s * 0.08, s * 0.8);
    c.stroke();
    c.restore();
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function lensWater(c, s) {
    c.fillStyle = vgrad(c, 0, s, PAL.waterB, '#0a2033');
    c.fillRect(0, 0, s, s);
    // layered waves
    c.save();
    c.lineWidth = Math.max(1, s * 0.025);
    for (var row = 0; row < 3; row++) {
      var y = s * (0.25 + row * 0.25);
      c.strokeStyle = row === 1 ? PAL.waterC : PAL.waterA;
      c.globalAlpha = row === 1 ? 0.8 : 0.5;
      c.beginPath();
      c.moveTo(s * 0.08, y);
      c.quadraticCurveTo(s * 0.25, y - s * 0.08, s * 0.42, y);
      c.quadraticCurveTo(s * 0.6, y + s * 0.08, s * 0.75, y);
      c.quadraticCurveTo(s * 0.85, y - s * 0.05, s * 0.92, y);
      c.stroke();
    }
    // sparkle
    c.globalAlpha = 0.9;
    c.fillStyle = PAL.waterC;
    c.beginPath(); c.arc(s * 0.7, s * 0.3, Math.max(1, s * 0.02), 0, Math.PI * 2); c.fill();
    c.restore();
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function lensIce(c, s) {
    c.fillStyle = vgrad(c, 0, s, '#14344a', '#0d2233');
    c.fillRect(0, 0, s, s);
    // faceted surface: irregular polygon shards
    c.save();
    c.strokeStyle = PAL.iceB;
    c.globalAlpha = 0.7;
    c.lineWidth = Math.max(1, s * 0.02);
    c.beginPath();
    c.moveTo(s * 0.1, s * 0.35); c.lineTo(s * 0.4, s * 0.15); c.lineTo(s * 0.55, s * 0.4);
    c.lineTo(s * 0.3, s * 0.6); c.closePath();
    c.moveTo(s * 0.55, s * 0.4); c.lineTo(s * 0.85, s * 0.28); c.lineTo(s * 0.9, s * 0.62);
    c.lineTo(s * 0.62, s * 0.72); c.closePath();
    c.moveTo(s * 0.3, s * 0.6); c.lineTo(s * 0.62, s * 0.72); c.lineTo(s * 0.5, s * 0.92);
    c.lineTo(s * 0.18, s * 0.8); c.closePath();
    c.stroke();
    // glints
    c.globalAlpha = 0.9;
    c.fillStyle = PAL.iceA;
    c.beginPath(); c.arc(s * 0.4, s * 0.3, Math.max(1, s * 0.025), 0, Math.PI * 2); c.fill();
    c.beginPath(); c.arc(s * 0.72, s * 0.55, Math.max(1, s * 0.02), 0, Math.PI * 2); c.fill();
    c.restore();
    // frame rim, so a sheet reads as one surface
    c.save();
    c.globalAlpha = 0.3;
    c.strokeStyle = PAL.iceB;
    c.lineWidth = Math.max(1, s * 0.015);
    c.strokeRect(s * 0.02, s * 0.02, s * 0.96, s * 0.96);
    c.restore();
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function playerMark(c, s) {
    var cx = s * 0.5, cy = s * 0.5;
    // surveyor's reticle: compass ring, needle, cardinal ticks
    c.save();
    c.globalAlpha = 0.35;
    c.fillStyle = PAL.light;
    c.beginPath(); c.arc(cx, cy, s * 0.34, 0, Math.PI * 2); c.fill();
    c.restore();
    c.strokeStyle = PAL.lightHot;
    c.lineWidth = Math.max(1, s * 0.035);
    c.beginPath(); c.arc(cx, cy, s * 0.28, 0, Math.PI * 2); c.stroke();
    c.save();
    c.strokeStyle = PAL.light;
    c.lineWidth = Math.max(1, s * 0.025);
    c.beginPath();
    c.moveTo(cx, cy - s * 0.40); c.lineTo(cx, cy - s * 0.30);
    c.moveTo(cx, cy + s * 0.30); c.lineTo(cx, cy + s * 0.40);
    c.moveTo(cx - s * 0.40, cy); c.lineTo(cx - s * 0.30, cy);
    c.moveTo(cx + s * 0.30, cy); c.lineTo(cx + s * 0.40, cy);
    c.stroke();
    c.restore();
    // the needle
    c.fillStyle = PAL.white;
    c.beginPath();
    c.moveTo(cx, cy - s * 0.18);
    c.lineTo(cx + s * 0.08, cy + s * 0.12);
    c.lineTo(cx, cy + s * 0.05);
    c.lineTo(cx - s * 0.08, cy + s * 0.12);
    c.closePath();
    c.fill();
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function mechanismMark(c, s) {
    var cx = s * 0.5, cy = s * 0.5;
    // a proper cog with rectangular teeth and a keyhole centre — "a mechanism lives here"
    c.save();
    c.translate(cx, cy);
    var teeth = 8;
    c.fillStyle = PAL.slateUp;
    for (var i = 0; i < teeth; i++) {
      c.save();
      c.rotate((Math.PI * 2 * i) / teeth);
      c.fillRect(-s * 0.055, -s * 0.34, s * 0.11, s * 0.12);
      c.restore();
    }
    c.beginPath(); c.arc(0, 0, s * 0.245, 0, Math.PI * 2); c.fill();
    c.strokeStyle = PAL.lineDim;
    c.lineWidth = Math.max(1, s * 0.025);
    c.beginPath(); c.arc(0, 0, s * 0.245, 0, Math.PI * 2); c.stroke();
    for (var j = 0; j < teeth; j++) {
      c.save();
      c.rotate((Math.PI * 2 * j) / teeth);
      c.strokeRect(-s * 0.055, -s * 0.335, s * 0.11, s * 0.1);
      c.restore();
    }
    // hub ring
    c.save();
    c.globalAlpha = 0.6;
    c.beginPath(); c.arc(0, 0, s * 0.17, 0, Math.PI * 2); c.stroke();
    c.restore();
    // keyhole
    c.fillStyle = PAL.ink;
    c.beginPath(); c.arc(0, -s * 0.035, s * 0.06, 0, Math.PI * 2); c.fill();
    c.beginPath();
    c.moveTo(-s * 0.028, -s * 0.01);
    c.lineTo(s * 0.028, -s * 0.01);
    c.lineTo(s * 0.045, s * 0.1);
    c.lineTo(-s * 0.045, s * 0.1);
    c.closePath();
    c.fill();
    c.restore();
  }

  /* ------------------------------------------------------------------ *
   * OUTCOME ICONS — one mark per word the readout says
   * ------------------------------------------------------------------ */

  /**
   * Shared icon scaffold: a small tile with an accent ring.
   * @param {CanvasRenderingContext2D} c Context. @param {number} s Size.
   * @param {string} col Accent colour.
   * @returns {void}
   */
  function iconGround(c, s, col) {
    c.save();
    c.globalAlpha = 0.18;
    c.fillStyle = col;
    rr(c, s * 0.06, s * 0.06, s * 0.88, s * 0.88, s * 0.16);
    c.fill();
    c.restore();
    c.strokeStyle = col;
    c.lineWidth = Math.max(1, s * 0.03);
    rr(c, s * 0.06, s * 0.06, s * 0.88, s * 0.88, s * 0.16);
    c.stroke();
  }

  /**
   * A rightward arrow shaft used by the movement icons.
   * @param {CanvasRenderingContext2D} c Context. @param {number} s Size.
   * @param {string} col Colour. @param {number} x0 Start x fraction.
   * @param {number} x1 Head x fraction. @param {number} y Y fraction.
   * @returns {void}
   */
  function arrow(c, s, col, x0, x1, y) {
    c.strokeStyle = col;
    c.fillStyle = col;
    c.lineWidth = Math.max(1.5, s * 0.05);
    c.beginPath();
    c.moveTo(s * x0, s * y);
    c.lineTo(s * (x1 - 0.1), s * y);
    c.stroke();
    c.beginPath();
    c.moveTo(s * x1, s * y);
    c.lineTo(s * (x1 - 0.14), s * (y - 0.09));
    c.lineTo(s * (x1 - 0.14), s * (y + 0.09));
    c.closePath();
    c.fill();
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function iconPush(c, s) {
    iconGround(c, s, PAL.line);
    arrow(c, s, PAL.line, 0.18, 0.58, 0.5);
    // the block it moves into
    c.strokeStyle = PAL.line;
    c.lineWidth = Math.max(1.5, s * 0.04);
    c.strokeRect(s * 0.62, s * 0.32, s * 0.22, s * 0.36);
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function iconSlides(c, s) {
    iconGround(c, s, PAL.iceB);
    arrow(c, s, PAL.iceB, 0.3, 0.84, 0.42);
    // speed lines behind
    c.save();
    c.globalAlpha = 0.7;
    c.strokeStyle = PAL.iceB;
    c.lineWidth = Math.max(1, s * 0.03);
    c.beginPath();
    c.moveTo(s * 0.14, s * 0.34); c.lineTo(s * 0.26, s * 0.34);
    c.moveTo(s * 0.14, s * 0.5); c.lineTo(s * 0.24, s * 0.5);
    c.stroke();
    // the ice underline
    c.globalAlpha = 0.9;
    c.beginPath();
    c.moveTo(s * 0.2, s * 0.68); c.lineTo(s * 0.34, s * 0.62); c.lineTo(s * 0.48, s * 0.68);
    c.lineTo(s * 0.62, s * 0.62); c.lineTo(s * 0.76, s * 0.68);
    c.stroke();
    c.restore();
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function iconFalls(c, s) {
    iconGround(c, s, PAL.wire);
    // arrow curving down into a pit V
    c.strokeStyle = PAL.wire;
    c.fillStyle = PAL.wire;
    c.lineWidth = Math.max(1.5, s * 0.05);
    c.beginPath();
    c.moveTo(s * 0.18, s * 0.38);
    c.quadraticCurveTo(s * 0.5, s * 0.36, s * 0.58, s * 0.6);
    c.stroke();
    c.beginPath();
    c.moveTo(s * 0.60, s * 0.72);
    c.lineTo(s * 0.48, s * 0.62);
    c.lineTo(s * 0.66, s * 0.58);
    c.closePath();
    c.fill();
    // the pit rim
    c.lineWidth = Math.max(1.5, s * 0.04);
    c.beginPath();
    c.moveTo(s * 0.4, s * 0.8); c.lineTo(s * 0.56, s * 0.8); ; c.lineTo(s * 0.56, s * 0.86);
    c.moveTo(s * 0.72, s * 0.8); c.lineTo(s * 0.84, s * 0.8);
    c.stroke();
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function iconSinks(c, s) {
    iconGround(c, s, PAL.waterC);
    // arrow dropping into waves
    c.strokeStyle = PAL.waterC;
    c.fillStyle = PAL.waterC;
    c.lineWidth = Math.max(1.5, s * 0.05);
    c.beginPath();
    c.moveTo(s * 0.5, s * 0.2); c.lineTo(s * 0.5, s * 0.5);
    c.stroke();
    c.beginPath();
    c.moveTo(s * 0.5, s * 0.62);
    c.lineTo(s * 0.4, s * 0.48);
    c.lineTo(s * 0.6, s * 0.48);
    c.closePath();
    c.fill();
    c.lineWidth = Math.max(1, s * 0.035);
    c.beginPath();
    c.moveTo(s * 0.16, s * 0.74);
    c.quadraticCurveTo(s * 0.3, s * 0.66, s * 0.44, s * 0.74);
    c.quadraticCurveTo(s * 0.58, s * 0.82, s * 0.7, s * 0.74);
    c.quadraticCurveTo(s * 0.78, s * 0.7, s * 0.86, s * 0.74);
    c.stroke();
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function iconShatters(c, s) {
    iconGround(c, s, PAL.hazard);
    // starburst
    c.strokeStyle = PAL.hazard;
    c.lineWidth = Math.max(1.5, s * 0.04);
    c.beginPath();
    var cx = s * 0.5, cy = s * 0.5;
    for (var i = 0; i < 8; i++) {
      var a = (Math.PI * 2 * i) / 8 + 0.2;
      var r0 = i % 2 ? s * 0.12 : s * 0.16;
      var r1 = i % 2 ? s * 0.24 : s * 0.34;
      c.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0);
      c.lineTo(cx + Math.cos(a) * r1, cy + Math.sin(a) * r1);
    }
    c.stroke();
    c.fillStyle = PAL.hazard;
    c.beginPath(); c.arc(cx, cy, s * 0.06, 0, Math.PI * 2); c.fill();
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function iconBlocked(c, s) {
    iconGround(c, s, PAL.hazard);
    // an arrow stopped dead at a bar
    arrow(c, s, PAL.hazard, 0.16, 0.52, 0.5);
    c.strokeStyle = PAL.hazard;
    c.lineWidth = Math.max(2, s * 0.07);
    c.beginPath();
    c.moveTo(s * 0.68, s * 0.24);
    c.lineTo(s * 0.68, s * 0.76);
    c.stroke();
  }

  /** @param {CanvasRenderingContext2D} c @param {number} s @returns {void} */
  function iconLoop(c, s) {
    iconGround(c, s, PAL.hazard);
    // a closed circular arrow — the beam chasing itself
    var cx = s * 0.5, cy = s * 0.5;
    c.strokeStyle = PAL.hazard;
    c.fillStyle = PAL.hazard;
    c.lineWidth = Math.max(1.5, s * 0.05);
    c.beginPath();
    c.arc(cx, cy, s * 0.24, Math.PI * 0.2, Math.PI * 1.7);
    c.stroke();
    c.beginPath();
    var a = Math.PI * 1.7;
    var hx = cx + Math.cos(a) * s * 0.24;
    var hy = cy + Math.sin(a) * s * 0.24;
    c.moveTo(hx + s * 0.09, hy - s * 0.02);
    c.lineTo(hx - s * 0.05, hy - s * 0.1);
    c.lineTo(hx - s * 0.02, hy + s * 0.09);
    c.closePath();
    c.fill();
    // warning tick in the centre
    c.lineWidth = Math.max(1.5, s * 0.045);
    c.beginPath();
    c.moveTo(cx, cy - s * 0.1); c.lineTo(cx, cy + s * 0.03);
    c.stroke();
    c.beginPath(); c.arc(cx, cy + s * 0.1, Math.max(1, s * 0.025), 0, Math.PI * 2); c.fill();
  }

  /* ------------------------------------------------------------------ *
   * The registry
   * ------------------------------------------------------------------ */

  /**
   * Every mark the atlas can draw. Key convention:
   *   body.<kind>.<material>      standing objects
   *   bridge.<material>           a block spent in a hole
   *   ford.<material>             a block sunk in water
   *   terrain.<terrain>           lens ground marks
   *   icon.<outcome>              readout icons
   * The painters are pure: same key + same size -> same pixels, which is
   * what the distinctness test asserts.
   */
  var MARKS = {
    'body.block.stone': { paint: blockStone, group: 'block', name: 'Stone block' },
    'body.block.wood': { paint: blockWood, group: 'block', name: 'Timber block' },
    'body.block.ice': { paint: blockIce, group: 'block', name: 'Ice block' },
    'body.block.iron': { paint: blockIron, group: 'block', name: 'Iron block' },
    'body.block.gild': { paint: blockGild, group: 'block', name: 'Gilded block' },
    'body.block.rune': { paint: blockRune, group: 'block', name: 'Runic block' },

    'bridge.stone': { paint: bridgeStone, group: 'bridge', name: 'Stone slab bridge' },
    'bridge.wood': { paint: bridgeWood, group: 'bridge', name: 'Plank bridge' },
    'bridge.ice': { paint: bridgeIce, group: 'bridge', name: 'Ice sheet bridge' },
    'bridge.iron': { paint: bridgeIron, group: 'bridge', name: 'Tread-plate bridge' },
    'bridge.gild': { paint: bridgeGild, group: 'bridge', name: 'Inlaid bridge' },
    'bridge.rune': { paint: bridgeRune, group: 'bridge', name: 'Sigil bridge' },

    'ford.stone': { paint: fordStone, group: 'ford', name: 'Stone ford' },
    'ford.wood': { paint: fordWood, group: 'ford', name: 'Timber ford' },
    'ford.ice': { paint: fordIce, group: 'ford', name: 'Ice ford' },
    'ford.iron': { paint: fordIron, group: 'ford', name: 'Iron ford' },
    'ford.gild': { paint: fordGild, group: 'ford', name: 'Gilded ford' },
    'ford.rune': { paint: fordRune, group: 'ford', name: 'Runic ford' },

    'body.boulder.granite': { paint: boulderGranite, group: 'boulder', name: 'Granite boulder' },
    'body.boulder.amber': { paint: boulderAmber, group: 'boulder', name: 'Amber boulder' },
    'body.boulder.obsidian': { paint: boulderObsidian, group: 'boulder', name: 'Obsidian boulder' },
    'body.boulder.shards': { paint: boulderShards, group: 'boulder', name: 'Shattered remains' },

    'body.mirror.slash': { paint: mirrorSlash, group: 'mirror', name: "Mirror '/'" },
    'body.mirror.backslash': { paint: mirrorBackslash, group: 'mirror', name: "Mirror '\\'" },

    'body.plate.idle': { paint: plateIdle, group: 'plate', name: 'Plate, waiting' },
    'body.plate.pressed': { paint: platePressed, group: 'plate', name: 'Plate, live' },

    'body.emitter.down': { paint: emitterDown, group: 'emitter', name: 'Emitter, south' },
    'body.emitter.left': { paint: emitterLeft, group: 'emitter', name: 'Emitter, west' },
    'body.emitter.right': { paint: emitterRight, group: 'emitter', name: 'Emitter, east' },
    'body.emitter.up': { paint: emitterUp, group: 'emitter', name: 'Emitter, north' },

    'body.receiver.dark': { paint: receiverDark, group: 'receiver', name: 'Receiver, dark' },
    'body.receiver.lit': { paint: receiverLit, group: 'receiver', name: 'Receiver, lit' },

    'terrain.floor': { paint: lensFloor, group: 'terrain', name: 'Surveyed floor' },
    'terrain.wall': { paint: lensWall, group: 'terrain', name: 'Solid matter' },
    'terrain.hole': { paint: lensHole, group: 'terrain', name: 'Open pit' },
    'terrain.water': { paint: lensWater, group: 'terrain', name: 'Deep water' },
    'terrain.ice': { paint: lensIce, group: 'terrain', name: 'Sheet ice' },

    'mark.player': { paint: playerMark, group: 'mark', name: "Surveyor's reticle" },
    'mark.mechanism': { paint: mechanismMark, group: 'mark', name: 'Mechanism' },

    'icon.push': { paint: iconPush, group: 'icon', name: 'PUSH' },
    'icon.slides': { paint: iconSlides, group: 'icon', name: 'SLIDES' },
    'icon.falls': { paint: iconFalls, group: 'icon', name: 'FALLS' },
    'icon.sinks': { paint: iconSinks, group: 'icon', name: 'SINKS' },
    'icon.shatters': { paint: iconShatters, group: 'icon', name: 'SHATTERS' },
    'icon.blocked': { paint: iconBlocked, group: 'icon', name: 'BLOCKED' },
    'icon.loop': { paint: iconLoop, group: 'icon', name: 'BEAM LOOP' }
  };

  /** Block/boulder materials the notetags accept, exported for the parser. */
  var BLOCK_MATERIALS = ['stone', 'wood', 'ice', 'iron', 'gild', 'rune'];
  var BOULDER_MATERIALS = ['granite', 'amber', 'obsidian'];

  /**
   * Paint one mark into a 2D context whose origin is the tile's top-left.
   *
   * @param {string} key A MARKS key.
   * @param {CanvasRenderingContext2D} ctx Target context.
   * @param {number} size Tile size in pixels.
   * @returns {boolean} True when the key exists and was painted.
   */
  function paint(key, ctx, size) {
    var m = MARKS[key];
    if (!m) return false;
    ctx.save();
    m.paint(ctx, size);
    ctx.restore();
    return true;
  }

  /**
   * Every mark key, sorted, for tests and the atlas board.
   * @returns {string[]} Keys.
   */
  function keys() {
    return Object.keys(MARKS).sort();
  }

  return {
    PAL: PAL,
    MARKS: MARKS,
    BLOCK_MATERIALS: BLOCK_MATERIALS,
    BOULDER_MATERIALS: BOULDER_MATERIALS,
    paint: paint,
    keys: keys
  };
})();

if (typeof window !== 'undefined') window.CogwheelAtlas = CogwheelAtlas;
if (typeof module !== 'undefined' && module.exports) module.exports = CogwheelAtlas;
