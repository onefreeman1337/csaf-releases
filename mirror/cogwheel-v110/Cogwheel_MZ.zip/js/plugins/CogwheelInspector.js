//=============================================================================
// CogwheelInspector.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.1.0] Cogwheel — the puzzle inspector. Atlas-drawn objects, the Blueprint Lens, real light beams, logic wiring, and a preview of the shove before you commit.
 * @author CSAF — Corey & Stephanie's Asset Factory
 * @url https://csaf.itch.io/cogwheel
 * @base CogwheelMap
 * @base CogwheelAtlas
 * @orderAfter CogwheelMap
 *
 * @param beamColor
 * @text Beam colour
 * @desc Colour of a live light beam, as CSS hex. Blank uses the built-in amber.
 * @type string
 * @default #ffb454
 *
 * @param drawBodies
 * @text Atlas-drawn objects
 * @desc Cogwheel draws every object whose event has NO graphic, from the atlas. Events you gave art to are always respected.
 * @type boolean
 * @default true
 *
 * @param startView
 * @text Starting view
 * @desc The view the map opens in. The toggle key cycles schematic -> lens -> quiet in play.
 * @type select
 * @option schematic
 * @option lens
 * @option quiet
 * @default schematic
 *
 * @param toggleKey
 * @text View toggle key
 * @desc Key that cycles the view: schematic -> lens -> quiet.
 * @type select
 * @option tab
 * @option control
 * @option shift
 * @option pageup
 * @option pagedown
 * @default tab
 *
 * @help
 * ============================================================================
 * The puzzle inspector
 * ============================================================================
 *
 * This is the part of Cogwheel you can see. It draws, directly over your live
 * map and without a single RPG Maker window:
 *
 *   THE BODIES    every object drawn from the atlas — blocks in six
 *                 materials, boulders in three, mirrors, plates, emitters,
 *                 receivers. Leave the event's graphic blank and Cogwheel
 *                 draws it; give it art and yours is respected. A spent
 *                 block is redrawn as the bridge it became, in its own
 *                 material.
 *
 *   THE BEAM      a real light beam with additive blending and a soft bloom,
 *                 bending through every mirror and terminating where it
 *                 actually terminates. A looping beam is drawn as a loop,
 *                 so you can SEE the mistake instead of wondering why the
 *                 door will not open.
 *
 *   THE WIRING    every plate and receiver drawn joined to what it drives,
 *                 as a lit lead while the link is live.
 *
 *   THE LENS      press the toggle again and the whole room is redrawn as
 *                 Cogwheel's own blueprint: surveyed floor, hatched matter,
 *                 open pits, water and sheet ice as drafting marks, you as a
 *                 surveyor's reticle, and every foreign event as a mechanism
 *                 cog. The puzzle, exactly as the machine reads it.
 *
 *   THE SHOVE     hold a direction and the destination is shown before you
 *                 commit, with the outcome named AND drawn: SLIDES, FALLS,
 *                 SINKS, SHATTERS, BLOCKED, each with its own icon. A puzzle
 *                 should be hard because it is a puzzle, not because the
 *                 rules were hidden.
 *
 * Press TAB (configurable) to cycle schematic -> lens -> quiet. The beam and
 * the bodies are always drawn — they are the world, not a debug overlay.
 *
 * THE LENS AND BIG MAPS. The lens builds one drawn cell per map tile. Beyond
 * 2,400 cells (about 60x40) it declines and the toggle skips it, so a huge
 * overworld cannot ask for two hundred thousand sprites. Dungeon rooms are
 * far below the cap.
 *
 * ----------------------------------------------------------------------------
 * IT DRAWS NO RPG MAKER WINDOWS
 * ----------------------------------------------------------------------------
 *
 * Not one. Every glyph, line, label and readout in this plugin is drawn by this
 * plugin, so the inspector does not look like the engine — and that is asserted
 * mechanically rather than promised: a windowskin cannot reach the screen
 * without a Window_Base, so `CogwheelInspector.chromeLeaks()` walking the live
 * scene and returning zero IS the proof.
 *
 * ----------------------------------------------------------------------------
 * PERFORMANCE
 * ----------------------------------------------------------------------------
 *
 * The overlay is vector geometry, rebuilt only when the puzzle CHANGES. A frame
 * in which nothing moved uploads no textures, dirties no bitmaps and rebuilds
 * no geometry — it sets two coordinates and an alpha. That is why the beam can
 * shimmer without costing anything per frame.
 */

(function () {
  'use strict';

  if (typeof Cogwheel === 'undefined' || typeof CogwheelMap === 'undefined' ||
      typeof CogwheelAtlas === 'undefined') {
    console.error('CogwheelInspector: CogwheelCore.js, CogwheelAtlas.js and CogwheelMap.js must be installed ABOVE this plugin.');
    return;
  }

  var PLUGIN = 'CogwheelInspector';
  var P = PluginManager.parameters(PLUGIN);

  /** Cells past which the lens declines to build (see the help block). */
  var LENS_CELL_CAP = 2400;

  /** View modes the toggle key cycles through. */
  var VIEW = { QUIET: 0, SCHEMATIC: 1, LENS: 2 };

  /* ---------------------------------------------------------- look & feel --
   * A deliberately non-RPG-Maker palette: a cold blueprint, one warm light.
   * Nothing here is a windowskin, and none of it is MZ's default anything. */
  var COL = {
    schematic: 0x5ad2ff,
    schematicDim: 0x2a6f8f,
    wire: 0x7ee0b8,
    wireDead: 0x2f4a52,
    hazard: 0xff5f6d,
    preview: 0xffe08a,
    beam: 0xffb454,
    beamLoop: 0xff5f6d
  };

  /**
   * Parse a CSS hex colour into a PIXI numeric colour.
   * @param {*} raw Parameter value.
   * @param {number} fallback Fallback colour.
   * @returns {number} Numeric colour.
   */
  function readColor(raw, fallback) {
    if (raw === undefined || raw === null) return fallback;
    var s = String(raw).trim().replace('#', '');
    if (s === '') return fallback;
    var n = parseInt(s, 16);
    return Number.isFinite(n) ? n : fallback;
  }

  var BEAM_COLOR = readColor(P.beamColor, COL.beam);
  var DRAW_BODIES = String(P.drawBodies) !== 'false';
  var START_VIEW = String(P.startView) === 'lens' ? VIEW.LENS
    : String(P.startView) === 'quiet' ? VIEW.QUIET
    : VIEW.SCHEMATIC;
  var TOGGLE_KEY = String(P.toggleKey || 'tab');

  /* MZ's default font is the loudest "this is RPG Maker" signal there is, so the readout uses
   * none of it. Stacks rather than shipped font files — no licence to redistribute, and these
   * resolve on every platform MZ runs on. */
  var F_LABEL = '"Trebuchet MS", "Avenir Next", "Segoe UI", Verdana, sans-serif';
  var F_MONO = 'Consolas, "SF Mono", Menlo, "DejaVu Sans Mono", monospace';

  /**
   * The bloom stack, widest and faintest first, hot white core last.
   *
   * A frozen module-level constant rather than an array built per draw: `drawBeams` runs on every
   * puzzle state change, and an array literal there is the allocation pattern wing §3 bans and the
   * static scan fails the build for.
   */
  var BEAM_PASSES = [
    { w: 26, a: 0.07, core: false, white: false },
    { w: 16, a: 0.11, core: false, white: false },
    { w: 9, a: 0.20, core: false, white: false },
    { w: 4, a: 0.95, core: true, white: false },
    { w: 1.5, a: 0.85, core: true, white: true }
  ];

  var OUTCOME_WORD = {
    moved: 'PUSH',
    slid: 'SLIDES',
    blocked: 'BLOCKED',
    fell_in_hole: 'FALLS — BRIDGES',
    sank: 'SINKS — BRIDGES',
    broke: 'SHATTERS'
  };

  /** The atlas icon that accompanies each outcome word. */
  var OUTCOME_ICON = {
    moved: 'icon.push',
    slid: 'icon.slides',
    blocked: 'icon.blocked',
    fell_in_hole: 'icon.falls',
    sank: 'icon.sinks',
    broke: 'icon.shatters'
  };

  /**
   * Ease-out cubic.
   * @param {number} t Progress 0..1.
   * @returns {number} Eased progress.
   */
  function easeOutCubic(t) { var u = 1 - t; return 1 - u * u * u; }

  /* ====================================================== the overlay layer */

  /**
   * The schematic + beam overlay, in MAP space.
   *
   * Two `PIXI.Graphics` children, both rebuilt ONLY when the puzzle's revision changes. Per frame
   * this container does three things: set `x`, set `y`, and set the beam's alpha. No allocation, no
   * texture upload, no geometry rebuild — which is what lets the beam shimmer for free and is why
   * the gate's deterministic counters stay flat on an idle frame.
   *
   * @constructor
   */
  function CogwheelOverlay() {
    this.initialize.apply(this, arguments);
  }
  CogwheelOverlay.prototype = Object.create(PIXI.Container.prototype);
  CogwheelOverlay.prototype.constructor = CogwheelOverlay;

  CogwheelOverlay.prototype.initialize = function () {
    PIXI.Container.prototype.constructor.call(this);

    // Bottom-most: the lens ground — the whole room redrawn from the atlas. Populated only in
    // lens view; empty otherwise.
    this._lens = new PIXI.Container();
    this._lens.visible = false;
    this.addChild(this._lens);

    this._schematic = new PIXI.Graphics();
    this.addChild(this._schematic);

    // Atlas-drawn object bodies. Above the wiring (a lead's base tucks behind its body), below
    // the light.
    this._bodies = new PIXI.Container();
    this.addChild(this._bodies);

    // The effect stock MZ cannot produce: real additive light. A beam drawn with ADD blending
    // brightens what is under it instead of covering it, so it reads as light rather than as a
    // coloured rectangle — and it is layered twice, a wide soft pass under a narrow bright core,
    // which is how a bloom is faked without a filter pass.
    this._beamGlow = new PIXI.Graphics();
    this._beamGlow.blendMode = PIXI.BLEND_MODES.ADD;
    this.addChild(this._beamGlow);

    this._beam = new PIXI.Graphics();
    this._beam.blendMode = PIXI.BLEND_MODES.ADD;
    this.addChild(this._beam);

    this._preview = new PIXI.Graphics();
    this.addChild(this._preview);

    this._revision = -1;
    this._previewKey = '';
    this._phase = 0;
    this._reveal = 0;
    this._mode = START_VIEW;

    /* The texture bank: one Bitmap per atlas key actually used, painted on demand and kept for
     * the scene's life. Rebuilds swap textures between existing sprites; they never repaint a
     * bitmap that already exists, so a texture upload happens once per key per scene. */
    this._bank = {};

    /* Body bookkeeping, rebuilt on revision change. `_bodyList` pairs a sprite with the event it
     * shadows so the per-frame position sync is one indexed loop with no allocation. */
    this._bodyList = [];
    this._lensBuiltFor = -1;
    this._mechList = [];
    this._playerMark = null;
  };

  /**
   * A Bitmap for one atlas key, painted once and cached.
   *
   * @param {string} key Atlas mark key.
   * @param {number} tw Tile width.
   * @param {number} th Tile height.
   * @returns {Bitmap} The cached bitmap.
   */
  CogwheelOverlay.prototype.bankBitmap = function (key, tw, th) {
    var b = this._bank[key];
    if (b) return b;
    b = new Bitmap(tw, th);
    CogwheelAtlas.paint(key, b.context, Math.min(tw, th));
    b.baseTexture.update();
    this._bank[key] = b;
    return b;
  };

  /**
   * Rebuild the vector geometry for the current puzzle state.
   *
   * @param {Object} rt Cogwheel runtime.
   * @returns {void}
   */
  CogwheelOverlay.prototype.rebuild = function (rt) {
    var tw = $gameMap.tileWidth();
    var th = $gameMap.tileHeight();
    this.rebuildLens(rt, tw, th);
    this.drawSchematic(rt, tw, th);
    this.rebuildBodies(rt, tw, th);
    this.drawBeams(rt, tw, th);
    this._reveal = 0;
  };

  /**
   * Which atlas mark draws this object in its current state?
   *
   * @param {Object} o A grid object.
   * @param {Object} rt Runtime.
   * @returns {string|null} An atlas key, or null for an unknown kind.
   */
  CogwheelOverlay.prototype.markKeyFor = function (o, rt) {
    var K = Cogwheel.OBJECT;
    if (o.kind === K.BLOCK) {
      var mat = o.material || 'stone';
      if (!o.consumed) return 'body.block.' + mat;
      // What it was spent on decides the face it left behind.
      var t = Cogwheel.terrainAt(rt.grid, o.x, o.y);
      return (t === Cogwheel.TERRAIN.WATER ? 'ford.' : 'bridge.') + mat;
    }
    if (o.kind === K.BOULDER) {
      if (o.consumed) return 'body.boulder.shards';
      return 'body.boulder.' + (o.material || 'granite');
    }
    if (o.kind === K.MIRROR) {
      return o.facing === '\\' ? 'body.mirror.backslash' : 'body.mirror.slash';
    }
    if (o.kind === K.PLATE) {
      return Cogwheel.isPlatePressed(rt.grid, o.x, o.y) ? 'body.plate.pressed' : 'body.plate.idle';
    }
    if (o.kind === K.RECEIVER) {
      return rt.lit[o.id] ? 'body.receiver.lit' : 'body.receiver.dark';
    }
    return null;
  };

  /**
   * Does this event carry its OWN art? Author art always wins over the atlas.
   *
   * @param {Game_Event} ev The event.
   * @returns {boolean} True when the author gave it a graphic.
   */
  function eventHasOwnArt(ev) {
    return !!(ev && (ev.tileId() > 0 || (ev.characterName() && ev.characterName() !== '')));
  }

  /**
   * Rebuild the atlas-drawn bodies for the current puzzle state.
   *
   * Sprites are pooled: the list is rebuilt on revision change (a handful of small allocations on
   * a STATE CHANGE, which is the same budget drawSchematic already spends), and per frame nothing
   * is created — see update().
   *
   * @param {Object} rt Runtime.
   * @param {number} tw Tile width.
   * @param {number} th Tile height.
   * @returns {void}
   */
  CogwheelOverlay.prototype.rebuildBodies = function (rt, tw, th) {
    var i;
    this._bodyList.length = 0;
    // Recycle by index: children beyond the need are hidden, never destroyed.
    var used = 0;
    if (DRAW_BODIES) {
      var objs = rt.grid.objects;
      for (i = 0; i < objs.length; i++) {
        var o = objs[i];
        var evId = rt.eventByObjectId[o.id];
        var ev = evId ? $gameMap.event(evId) : null;
        if (!ev || eventHasOwnArt(ev)) continue;
        var key = this.markKeyFor(o, rt);
        if (!key) continue;
        used = this.takeBodySprite(used, key, evId, tw, th);
      }
      for (i = 0; i < rt.emitters.length; i++) {
        var e = rt.emitters[i];
        var eev = e.eventId ? $gameMap.event(e.eventId) : null;
        if (!eev || eventHasOwnArt(eev)) continue;
        var ekey = e.dir === 8 ? 'body.emitter.up' : e.dir === 4 ? 'body.emitter.left'
          : e.dir === 6 ? 'body.emitter.right' : 'body.emitter.down';
        used = this.takeBodySprite(used, ekey, e.eventId, tw, th);
      }
    }
    for (i = used; i < this._bodies.children.length; i++) {
      this._bodies.children[i].visible = false;
    }
  };

  /**
   * Take (or create) the pooled body sprite at `index`, texture it, register it.
   *
   * @param {number} index Pool index.
   * @param {string} key Atlas key.
   * @param {number} evId Event id the sprite shadows.
   * @param {number} tw Tile width. @param {number} th Tile height.
   * @returns {number} The next pool index.
   */
  CogwheelOverlay.prototype.takeBodySprite = function (index, key, evId, tw, th) {
    var spr = this._bodies.children[index];
    if (!spr) {
      spr = new Sprite();
      this._bodies.addChild(spr);
    }
    spr.bitmap = this.bankBitmap(key, tw, th);
    spr.visible = true;
    this._bodyList.push({ sprite: spr, eventId: evId });
    return index + 1;
  };

  /**
   * Build the lens — the whole room as atlas ground cells, one sprite per tile, five shared
   * bitmaps — plus a mechanism mark per foreign event and the player's reticle.
   *
   * Built once per map (terrain cannot change mid-room; a bridged hole keeps its pit cell and
   * gains a bridge BODY on top, which is the honest picture). Beyond LENS_CELL_CAP cells the lens
   * declines and the toggle skips it.
   *
   * @param {Object} rt Runtime.
   * @param {number} tw Tile width. @param {number} th Tile height.
   * @returns {void}
   */
  CogwheelOverlay.prototype.rebuildLens = function (rt, tw, th) {
    if (this._lensBuiltFor === rt.mapId) return;
    var grid = rt.grid;
    if (grid.width * grid.height > LENS_CELL_CAP) {
      this._lensBuiltFor = rt.mapId;
      this._lensOver = true;
      return;
    }
    this._lensOver = false;
    this._lensBuiltFor = rt.mapId;
    this._lens.removeChildren();
    this._mechList.length = 0;

    var T = Cogwheel.TERRAIN;
    for (var y = 0; y < grid.height; y++) {
      for (var x = 0; x < grid.width; x++) {
        var t = Cogwheel.terrainAt(grid, x, y);
        var key = t === T.WALL ? 'terrain.wall' : t === T.HOLE ? 'terrain.hole'
          : t === T.WATER ? 'terrain.water' : t === T.ICE ? 'terrain.ice' : 'terrain.floor';
        var cell = new Sprite(this.bankBitmap(key, tw, th));
        cell.x = x * tw;
        cell.y = y * th;
        this._lens.addChild(cell);
      }
    }

    // Foreign events — doors, chests, NPCs — become mechanism cogs, so they stay legible when the
    // lens covers their sprites rather than silently vanishing from the room.
    var events = $gameMap.events();
    for (var i = 0; i < events.length; i++) {
      var ev = events[i];
      var evId = ev.eventId();
      if (this.isCogwheelEvent(rt, evId)) continue;
      var mech = new Sprite(this.bankBitmap('mark.mechanism', tw, th));
      this._lens.addChild(mech);
      this._mechList.push({ sprite: mech, eventId: evId });
    }

    // The player, as the surveyor's reticle.
    this._playerMark = new Sprite(this.bankBitmap('mark.player', tw, th));
    this._lens.addChild(this._playerMark);
  };

  /**
   * Is this event one Cogwheel manages (object or emitter)?
   * @param {Object} rt Runtime.
   * @param {number} evId Event id.
   * @returns {boolean} True when managed.
   */
  CogwheelOverlay.prototype.isCogwheelEvent = function (rt, evId) {
    for (var k in rt.eventByObjectId) {
      if (rt.eventByObjectId[k] === evId) return true;
    }
    for (var i = 0; i < rt.emitters.length; i++) {
      if (rt.emitters[i].eventId === evId) return true;
    }
    return false;
  };

  /**
   * Draw every managed object as a vector glyph, plus its logic wiring.
   *
   * @param {Object} rt Runtime.
   * @param {number} tw Tile width.
   * @param {number} th Tile height.
   * @returns {void}
   */
  CogwheelOverlay.prototype.drawSchematic = function (rt, tw, th) {
    var g = this._schematic;
    g.clear();
    if (this._mode === VIEW.QUIET) return;
    // In lens view the atlas ground already draws every hazard cell, so the schematic contributes
    // only what the ground cannot: the wiring and the un-bodied glyphs.
    var lens = this._mode === VIEW.LENS && !this._lensOver;

    var grid = rt.grid;
    var objs = grid.objects;
    var i;

    // Hazard cells first, underneath everything, so a hole reads as a hole even before an object
    // is anywhere near it.
    if (!lens) for (var y = 0; y < grid.height; y++) {
      for (var x = 0; x < grid.width; x++) {
        var t = Cogwheel.terrainAt(grid, x, y);
        if (t !== Cogwheel.TERRAIN.HOLE && t !== Cogwheel.TERRAIN.WATER && t !== Cogwheel.TERRAIN.ICE) continue;
        var bridged = Cogwheel.isBridged(grid, x, y);
        var cx = x * tw;
        var cy = y * th;
        if (t === Cogwheel.TERRAIN.ICE) {
          // ⚠️ ICE HAS TO BE OBVIOUS, and the first version was invisible. A 1px dark-blue
          // cross-hatch at 0.55 alpha over grey dungeon stone measured indistinguishable from
          // plain floor in a render — so the demo showed a mirror sliding five tiles for no
          // visible reason. That is a playability defect, not a styling preference: the whole
          // puzzle is "choose the shove", and the player cannot choose against terrain they
          // cannot see.
          g.beginFill(COL.schematic, 0.13);
          g.drawRect(cx + 1, cy + 1, tw - 2, th - 2);
          g.endFill();
          g.lineStyle(2, COL.schematic, 0.75);
          g.moveTo(cx + 7, cy + th - 7); g.lineTo(cx + tw - 7, cy + 7);
          g.moveTo(cx + 7, cy + 7); g.lineTo(cx + tw - 7, cy + th - 7);
          // A bright rim, so a run of ice reads as one continuous surface rather than as tiles.
          g.lineStyle(1, COL.schematic, 0.35);
          g.drawRect(cx + 1, cy + 1, tw - 2, th - 2);
        } else {
          g.lineStyle(2, bridged ? COL.wire : COL.hazard, bridged ? 0.85 : 0.75);
          if (bridged) {
            // A filled hazard is drawn as planks: the player must be able to trust it.
            g.moveTo(cx + 4, cy + th * 0.35); g.lineTo(cx + tw - 4, cy + th * 0.35);
            g.moveTo(cx + 4, cy + th * 0.65); g.lineTo(cx + tw - 4, cy + th * 0.65);
          } else {
            g.drawRect(cx + 5, cy + 5, tw - 10, th - 10);
          }
        }
      }
    }

    // Outline glyphs remain the annotation for objects the atlas is NOT drawing — author-art
    // events and a bodies-off configuration. A body would make the outline double chrome.
    for (i = 0; i < objs.length; i++) {
      var o = objs[i];
      if (this.bodyCovers(o, rt)) continue;
      this.drawGlyph(g, o, rt, tw, th);
    }

    // Wiring: plate/receiver -> the switch it drives. Drawn to the nearest edge of the room as a
    // short lead with a terminal dot, because the thing it drives is an EVENT somewhere else and
    // pretending to know where would be a lie drawn in confident lines.
    for (i = 0; i < objs.length; i++) {
      var w = objs[i];
      if (!w.switchId) continue;
      var live = w.kind === Cogwheel.OBJECT.PLATE
        ? Cogwheel.isPlatePressed(grid, w.x, w.y)
        : !!rt.lit[w.id];
      var ox = w.x * tw + tw / 2;
      var oy = w.y * th + th / 2;
      var top = oy - th * 0.8;
      // Two passes: a soft halo so the lead survives a busy tileset, then the line itself. A 2px
      // line at 0.4 alpha measured unreadable over stone at thumbnail size, and a wire nobody can
      // see is not a feature the gallery can argue for.
      g.lineStyle(6, live ? COL.wire : COL.wireDead, live ? 0.22 : 0.10);
      g.moveTo(ox, oy); g.lineTo(ox, top);
      g.lineStyle(2, live ? COL.wire : COL.wireDead, live ? 1 : 0.55);
      g.moveTo(ox, oy); g.lineTo(ox, top);
      g.beginFill(live ? COL.wire : COL.wireDead, live ? 1 : 0.55);
      g.drawCircle(ox, top, live ? 4 : 3);
      g.endFill();
      if (live) {
        g.beginFill(COL.wire, 0.20);
        g.drawCircle(ox, top, 9);
        g.endFill();
      }
    }
  };

  /**
   * Will rebuildBodies give this object an atlas body?
   * @param {Object} o A grid object.
   * @param {Object} rt Runtime.
   * @returns {boolean} True when a body covers it.
   */
  CogwheelOverlay.prototype.bodyCovers = function (o, rt) {
    if (!DRAW_BODIES) return false;
    var evId = rt.eventByObjectId[o.id];
    var ev = evId ? $gameMap.event(evId) : null;
    return !!ev && !eventHasOwnArt(ev);
  };

  /**
   * Draw one object's glyph.
   *
   * Vector glyphs rather than sprites, because the whole point of the inspector is that it reads
   * as an instrument laid over the world rather than as more RPG Maker furniture.
   *
   * @param {PIXI.Graphics} g Target.
   * @param {Object} o Object.
   * @param {Object} rt Runtime.
   * @param {number} tw Tile width.
   * @param {number} th Tile height.
   * @returns {void}
   */
  CogwheelOverlay.prototype.drawGlyph = function (g, o, rt, tw, th) {
    var x = o.x * tw;
    var y = o.y * th;
    var cx = x + tw / 2;
    var cy = y + th / 2;
    var K = Cogwheel.OBJECT;

    if (o.consumed) {
      // Spent, and part of the floor now. Faint, so it explains the crossing without shouting.
      g.lineStyle(1, COL.wire, 0.35);
      g.drawRect(x + 8, y + 8, tw - 16, th - 16);
      return;
    }

    if (o.kind === K.BLOCK) {
      g.lineStyle(2, COL.schematic, 0.9);
      g.drawRect(x + 6, y + 6, tw - 12, th - 12);
      g.lineStyle(1, COL.schematicDim, 0.7);
      g.drawRect(x + 11, y + 11, tw - 22, th - 22);
    } else if (o.kind === K.BOULDER) {
      g.lineStyle(2, COL.schematic, 0.9);
      g.drawCircle(cx, cy, Math.min(tw, th) / 2 - 6);
      g.lineStyle(1, COL.schematicDim, 0.7);
      g.drawCircle(cx, cy, Math.min(tw, th) / 2 - 11);
    } else if (o.kind === K.MIRROR) {
      // The mirror is drawn as the actual reflecting surface, at its actual angle. A buyer should
      // be able to read the puzzle off the schematic without touching anything.
      g.lineStyle(3, 0xffffff, 0.95);
      if (o.facing === '/') {
        g.moveTo(x + 8, y + th - 8); g.lineTo(x + tw - 8, y + 8);
      } else {
        g.moveTo(x + 8, y + 8); g.lineTo(x + tw - 8, y + th - 8);
      }
      g.lineStyle(1, COL.schematic, 0.6);
      g.drawRect(x + 5, y + 5, tw - 10, th - 10);
    } else if (o.kind === K.PLATE) {
      var pressed = Cogwheel.isPlatePressed(rt.grid, o.x, o.y);
      g.lineStyle(2, pressed ? COL.wire : COL.schematicDim, pressed ? 1 : 0.6);
      g.drawRect(x + 9, y + 9, tw - 18, th - 18);
      if (pressed) {
        g.beginFill(COL.wire, 0.25);
        g.drawRect(x + 9, y + 9, tw - 18, th - 18);
        g.endFill();
      }
    } else if (o.kind === K.RECEIVER) {
      var lit = !!rt.lit[o.id];
      g.lineStyle(2, lit ? BEAM_COLOR : COL.schematicDim, lit ? 1 : 0.6);
      g.drawCircle(cx, cy, Math.min(tw, th) / 2 - 8);
      if (lit) {
        g.beginFill(BEAM_COLOR, 0.3);
        g.drawCircle(cx, cy, Math.min(tw, th) / 2 - 8);
        g.endFill();
      }
    }
  };

  /**
   * Draw every beam as two additive passes — a wide soft glow and a narrow bright core.
   *
   * @param {Object} rt Runtime.
   * @param {number} tw Tile width.
   * @param {number} th Tile height.
   * @returns {void}
   */
  CogwheelOverlay.prototype.drawBeams = function (rt, tw, th) {
    var core = this._beam;
    var glow = this._beamGlow;
    core.clear();
    glow.clear();

    for (var b = 0; b < rt.beams.length; b++) {
      var trace = rt.beams[b];
      var cells = trace.cells;
      if (!cells || cells.length < 2) continue;

      // A looping beam is drawn in the alarm colour rather than hidden. The model detects the loop
      // exactly (it is a repeated (cell, direction) state), so the inspector can show the designer
      // the mistake instead of silently truncating the beam and leaving them to guess.
      var col = trace.outcome === Cogwheel.BEAM.LOOPED ? COL.beamLoop : BEAM_COLOR;

      // A bloom is stacked passes, widest and faintest first. Three of them rather than one,
      // because a single 10px pass at 0.16 measured almost invisible against a dark map — and
      // "the beam is the showpiece" is the entire Gate 1 argument for this product, so it has to
      // read at thumbnail size, not merely be present. Additive blending makes the overlaps
      // compound into a hot core for free.
      var i, px, py;
      var first = cells[0];
      var fx = first.x * tw + tw / 2;
      var fy = first.y * th + th / 2;

      for (var pass = 0; pass < BEAM_PASSES.length; pass++) {
        var spec = BEAM_PASSES[pass];
        var g = spec.core ? core : glow;
        g.lineStyle(spec.w, spec.white ? 0xffffff : col, spec.a);
        g.moveTo(fx, fy);
        for (i = 1; i < cells.length; i++) {
          px = cells[i].x * tw + tw / 2;
          py = cells[i].y * th + th / 2;
          g.lineTo(px, py);
        }
      }

      // Emitter flare, so the source reads as the source.
      glow.beginFill(col, 0.20);
      glow.drawCircle(fx, fy, tw * 0.60);
      glow.endFill();

      // A mirror is a hot point: the beam visibly turns there rather than merely changing angle.
      for (i = 1; i < cells.length - 1; i++) {
        var a = cells[i];
        var b = cells[i + 1];
        if (a.dir === b.dir) continue; // not a reflection
        glow.beginFill(col, 0.26);
        glow.drawCircle(a.x * tw + tw / 2, a.y * th + th / 2, tw * 0.42);
        glow.endFill();
      }

      // Terminal mark: a burst on a receiver.
      var last = cells[cells.length - 1];
      var lx = last.x * tw + tw / 2;
      var ly = last.y * th + th / 2;
      if (trace.outcome === Cogwheel.BEAM.RECEIVER) {
        glow.beginFill(col, 0.16);
        glow.drawCircle(lx, ly, tw * 0.95);
        glow.endFill();
        glow.beginFill(col, 0.30);
        glow.drawCircle(lx, ly, tw * 0.55);
        glow.endFill();
        core.beginFill(0xffffff, 0.85);
        core.drawCircle(lx, ly, 6);
        core.endFill();
      }
    }
  };

  /**
   * Draw the push preview for the tile the player is facing.
   *
   * @param {Object} rt Runtime.
   * @param {number} tw Tile width.
   * @param {number} th Tile height.
   * @returns {void}
   */
  CogwheelOverlay.prototype.drawPreview = function (rt, tw, th) {
    var g = this._preview;
    g.clear();

    var info = CogwheelInspector.previewInfo(rt);
    if (!info) return;

    var res = info.result;
    if (!res || !res.to) return;

    var dead = res.outcome === Cogwheel.OUTCOME.BLOCKED;
    var col = dead ? COL.hazard : COL.preview;

    // The travel line, then the destination cell.
    if (!dead && res.from) {
      g.lineStyle(2, col, 0.5);
      g.moveTo(res.from.x * tw + tw / 2, res.from.y * th + th / 2);
      g.lineTo(res.to.x * tw + tw / 2, res.to.y * th + th / 2);
    }
    g.lineStyle(2, col, 0.95);
    g.drawRect(res.to.x * tw + 4, res.to.y * th + 4, tw - 8, th - 8);
    g.beginFill(col, dead ? 0.16 : 0.12);
    g.drawRect(res.to.x * tw + 4, res.to.y * th + 4, tw - 8, th - 8);
    g.endFill();
  };

  /**
   * Per-frame update.
   *
   * ⚠️ ZERO ALLOCATION BY CONSTRUCTION. Nothing in this function creates an object, an array or a
   * closure, and nothing rebuilds geometry unless the puzzle's revision actually moved. The
   * shimmer is an alpha ramp on already-built geometry, which costs nothing and is the reason the
   * beam can breathe without appearing in any per-frame counter.
   *
   * @returns {void}
   */
  CogwheelOverlay.prototype.update = function () {
    var rt = CogwheelMap.runtime();
    if (!rt) { this.visible = false; return; }
    this.visible = true;

    if (rt.revision !== this._revision) {
      this._revision = rt.revision;
      this.rebuild(rt);
    }

    var tw = $gameMap.tileWidth();
    var th = $gameMap.tileHeight();

    // Follow the map. `adjustX` returns TILE-space offset from the display origin, so one multiply
    // puts the whole overlay in the right place — and it is the same call MZ's own sprites use, so
    // the overlay cannot drift out of step with the tilemap during a scroll.
    this.x = Math.round($gameMap.adjustX(0) * tw);
    this.y = Math.round($gameMap.adjustY(0) * th);

    // Reveal easing on a state change, then a slow breath.
    if (this._reveal < 1) this._reveal = Math.min(1, this._reveal + 0.08);
    this._phase += 0.045;
    if (this._phase > 6.28318) this._phase -= 6.28318;

    var reveal = easeOutCubic(this._reveal);
    var breath = 0.86 + 0.14 * Math.sin(this._phase);
    this._beam.alpha = reveal * breath;
    this._beamGlow.alpha = reveal * (0.7 + 0.3 * Math.sin(this._phase * 0.7));
    this._schematic.alpha = reveal;

    // Bodies shadow their events every frame — an indexed loop over a pooled list, setting two
    // numbers per body. `_realX` is MZ's own interpolated position, so a push, a slide and a
    // roll all animate for free and the body can never drift from the event it draws.
    var bl = this._bodyList;
    for (var bi = 0; bi < bl.length; bi++) {
      var rec = bl[bi];
      var bev = $gameMap.event(rec.eventId);
      if (!bev) continue;
      rec.sprite.x = bev._realX * tw;
      rec.sprite.y = bev._realY * th;
    }

    // The lens layer: ground cells are static; the reticle and the mechanism cogs track their
    // characters. Visible only in lens view, and never when the map is over the cell cap.
    var lensOn = this._mode === VIEW.LENS && !this._lensOver;
    this._lens.visible = lensOn;
    if (lensOn) {
      var ml = this._mechList;
      for (var mi = 0; mi < ml.length; mi++) {
        var mrec = ml[mi];
        var mev = $gameMap.event(mrec.eventId);
        if (!mev) continue;
        mrec.sprite.x = mev._realX * tw;
        mrec.sprite.y = mev._realY * th;
      }
      if (this._playerMark) {
        this._playerMark.x = $gamePlayer._realX * tw;
        this._playerMark.y = $gamePlayer._realY * th;
      }
    }

    // The preview depends on player facing and input, not on the puzzle revision, so it is rebuilt
    // when the FACING CELL changes rather than every frame. The key is a number, deliberately —
    // building a string key here would allocate on every single frame.
    var key = CogwheelInspector.previewKey(rt);
    if (key !== this._previewKey) {
      this._previewKey = key;
      this.drawPreview(rt, tw, th);
    }
    this._preview.alpha = 0.55 + 0.45 * Math.sin(this._phase * 1.6) * 0.5 + 0.22;
  };

  /**
   * Cycle the view: schematic -> lens -> quiet -> schematic. A map past the lens cell cap skips
   * the lens stop rather than presenting an empty ground.
   * @returns {void}
   */
  CogwheelOverlay.prototype.cycleView = function () {
    if (this._mode === VIEW.SCHEMATIC) this._mode = this._lensOver ? VIEW.QUIET : VIEW.LENS;
    else if (this._mode === VIEW.LENS) this._mode = VIEW.QUIET;
    else this._mode = VIEW.SCHEMATIC;
    this._revision = -1; // force a rebuild on the next update
  };

  /** Kept as an alias: two shipped capture preludes call it. */
  CogwheelOverlay.prototype.toggleSchematic = CogwheelOverlay.prototype.cycleView;

  /**
   * Jump straight to a named view. The capture storyboard drives this; a buyer uses the key.
   * @param {number} mode A VIEW value.
   * @returns {void}
   */
  CogwheelOverlay.prototype.setView = function (mode) {
    this._mode = mode;
    this._revision = -1;
  };

  /* ============================================================== readout == */

  /**
   * The screen-fixed readout: what the shove will do, and what the beam is doing.
   *
   * A Sprite with a Bitmap rather than a Window, because a Window is a windowskin and a windowskin
   * is the thing this product must not look like. Redrawn only when its text changes.
   *
   * @constructor
   */
  function CogwheelReadout() {
    this.initialize.apply(this, arguments);
  }
  CogwheelReadout.prototype = Object.create(Sprite.prototype);
  CogwheelReadout.prototype.constructor = CogwheelReadout;

  CogwheelReadout.prototype.initialize = function () {
    Sprite.prototype.initialize.call(this, new Bitmap(360, 78));
    this._text = null;
    this._sub = null;
    this._alpha = 0;
    this.x = 18;
    this.y = 18;
    this.opacity = 0;
  };

  /**
   * Redraw the readout card.
   *
   * @param {string} title Headline word.
   * @param {string} sub Supporting line.
   * @param {number} accent Accent colour.
   * @returns {void}
   */
  CogwheelReadout.prototype.redraw = function (title, sub, accent, iconKey) {
    var b = this.bitmap;
    var ctx = b.context;
    b.clear();

    var css = '#' + ('000000' + accent.toString(16)).slice(-6);

    // A slab with one bright edge — an instrument label, not a window frame.
    ctx.save();
    ctx.fillStyle = 'rgba(14,18,26,0.82)';
    ctx.fillRect(0, 0, 360, 78);
    ctx.fillStyle = css;
    ctx.fillRect(0, 0, 3, 78);
    ctx.restore();

    // The outcome's atlas icon, painted straight into the card.
    var textX = 16;
    if (iconKey) {
      ctx.save();
      ctx.translate(12, 17);
      CogwheelAtlas.paint(iconKey, ctx, 44);
      ctx.restore();
      textX = 68;
    }

    b.fontFace = F_MONO;
    b.fontSize = 22;
    b.textColor = css;
    b.outlineWidth = 0;
    b.drawText(title, textX, 8, 360 - textX - 14, 28, 'left');

    b.fontFace = F_LABEL;
    b.fontSize = 15;
    b.textColor = '#9fb0c4';
    b.drawText(sub, textX, 40, 360 - textX - 14, 22, 'left');

    b._baseTexture.update();
  };

  CogwheelReadout.prototype.update = function () {
    Sprite.prototype.update.call(this);
    var rt = CogwheelMap.runtime();
    if (!rt) { this.opacity = 0; return; }

    var info = CogwheelInspector.previewInfo(rt);
    var title = null;
    var sub = null;
    var accent = COL.preview;
    var iconKey = null;

    if (info && info.result && info.result.object) {
      var r = info.result;
      title = OUTCOME_WORD[r.outcome] || 'PUSH';
      iconKey = OUTCOME_ICON[r.outcome] || 'icon.push';
      if (r.outcome === Cogwheel.OUTCOME.BLOCKED) {
        sub = 'Nothing gives. Something is behind it.';
        accent = COL.hazard;
      } else if (r.outcome === Cogwheel.OUTCOME.SLID) {
        sub = 'Slides ' + r.tilesMoved + ' tiles — it stops where the ice does.';
      } else if (r.outcome === Cogwheel.OUTCOME.BROKE) {
        sub = 'Rolls ' + r.tilesMoved + ' and shatters against the wall.';
        accent = COL.hazard;
      } else if (r.outcome === Cogwheel.OUTCOME.FELL_IN_HOLE) {
        sub = 'Fills the hole and becomes a crossing. Permanent.';
        accent = COL.wire;
      } else if (r.outcome === Cogwheel.OUTCOME.SANK) {
        sub = 'Sinks and becomes a crossing. Permanent.';
        accent = COL.wire;
      } else {
        sub = 'Moves one tile.';
      }
    }

    if (title !== this._text || sub !== this._sub) {
      this._text = title;
      this._sub = sub;
      if (title) this.redraw(title, sub, accent, iconKey);
    }

    var want = title ? 255 : 0;
    // Ease rather than snap: a readout that pops is the stock-engine tell.
    if (this.opacity < want) this.opacity = Math.min(want, this.opacity + 28);
    else if (this.opacity > want) this.opacity = Math.max(want, this.opacity - 28);
  };

  /* ================================================================= API == */

  var CogwheelInspector = {};
  window.CogwheelInspector = CogwheelInspector;

  /**
   * What would the shove in front of the player do?
   *
   * Uses `Cogwheel.previewPush`, which calls the real resolver and restores the state, so the
   * preview shown to the player cannot disagree with the push they are about to perform. A
   * hand-written "what would happen" would be a second implementation of the interaction matrix,
   * and this wing has already shipped a product whose two paths silently disagreed (wing §11).
   *
   * @param {Object} rt Runtime.
   * @returns {{result:Object, dir:number}|null} Preview, or null when nothing is facing.
   */
  CogwheelInspector.previewInfo = function (rt) {
    if (!rt || typeof $gamePlayer === 'undefined' || !$gamePlayer) return null;
    var dir = $gamePlayer.direction();
    var d = Cogwheel.DIRS[dir];
    if (!d) return null;
    var tx = $gamePlayer.x + d.dx;
    var ty = $gamePlayer.y + d.dy;
    var obj = Cogwheel.objectAt(rt.grid, tx, ty);
    if (!obj) return null;
    if (Cogwheel.isFixture(obj)) return null;
    var res = Cogwheel.previewPush(rt.grid, tx, ty, dir);
    if (!res || !res.object) return null;
    return { result: res, dir: dir };
  };

  /**
   * A cheap NUMERIC key identifying what the preview depends on.
   *
   * Deliberately a number and not a template string: this is read on every frame, and a string
   * built per frame is an allocation in a hot path — exactly what wing §3 bans and what the
   * static scan will fail the build for.
   *
   * @param {Object} rt Runtime.
   * @returns {number} Key.
   */
  CogwheelInspector.previewKey = function (rt) {
    if (!rt || typeof $gamePlayer === 'undefined' || !$gamePlayer) return -1;
    return (($gamePlayer.x * 1024) + $gamePlayer.y) * 16 + $gamePlayer.direction() + rt.revision * 1048576;
  };

  /**
   * Count RPG Maker chrome actually REACHING THE SCREEN — the mechanical half of Gate 1.
   *
   * ⚠️ COUNTING `Window_Base` INSTANCES IS THE WRONG MEASURE FOR AN OVERLAY PRODUCT, and this
   * function said so the hard way on 2026-08-16: it reported **8 leaks** on a clean scene. All
   * eight were MZ's own `Scene_Map` furniture — `Window_Message`, `Window_ChoiceList`,
   * `Window_NumberInput`, `Window_EventItem`, `Window_NameBox`, `Window_Gold`,
   * `Window_ScrollText`, `Window_MapName` — which every MZ map has and none of which was drawing
   * anything. Wing §15's `windowsDrawn: 0` is a per-frame DRAW count; an instance count is a
   * different question that happens to read the same on a product that adds its own scene.
   *
   * A false RED costs exactly as much as a false green (master §4.4 rule 5). Asserting on
   * instances here would have made Gate 1 unpassable for any Scene_Map product, and the fix
   * someone reached for under deadline would have been to delete the check.
   *
   * So the predicate is MZ's OWN render condition, read out of `rmmz_core.js:4313`:
   *     if (win._isWindow && win.visible && win.openness > 0) { ... }
   * narrowed to `opacity > 0`, which is the WINDOWSKIN's own alpha — and the windowskin is the
   * thing that actually looks like RPG Maker.
   *
   * ⚠️ AN EARLIER VERSION ALSO FAILED ON `contentsOpacity > 0`, AND THAT MADE THE GATE FLAKY —
   * which is worse than making it wrong, because a check that passes on the second run teaches
   * everyone to re-run it. `Window_MapName.open()` sets `_showCount = 150` UNCONDITIONALLY
   * (rmmz_windows.js:5338), whether or not the map has a display name, so `contentsOpacity` fades
   * 0 -> 255 on every single map entry. With no display name its `refresh()` draws nothing, so
   * those are 255 units of alpha over an empty bitmap: no pixels, and a failure that depended
   * entirely on which frame the probe sampled.
   *
   * Contents-only painters are therefore REPORTED rather than failed, in `textOnly`. Hiding them
   * would swap a false red for a blind spot, and the caller is expected to account for each one —
   * `in_engine.js` asserts the only entry is `Window_MapName` on a map with no display name, so
   * "it draws nothing" is grounded rather than assumed.
   *
   * ⛔ AND IT CANNOT SEE `Sprite_Button`. MZ's touch-UI menu button is a Sprite, not a Window, so
   * this function honestly returns 0 while a stock RPG Maker hamburger sits in the corner of every
   * frame. Found by LOOKING at a render. `windowsDrawn: 0` is the structural half of Gate 1, never
   * the whole of it (wing §9.5).
   *
   * Reports `instances` alongside `leaks` deliberately: a zero from a blind spot and a zero from a
   * clean product must not read the same (wing §8, on the two counters that had never worked).
   *
   * @returns {{leaks:number, names:string[], textOnly:string[], instances:number, all:string[]}}
   *   Windowskins rendering, contents-only painters, and every window found.
   */
  CogwheelInspector.chromeLeaks = function () {
    var names = [];
    var textOnly = [];
    var all = [];
    if (typeof SceneManager === 'undefined' || !SceneManager._scene) {
      return { leaks: 0, names: names, textOnly: textOnly, instances: 0, all: all };
    }
    var stack = [SceneManager._scene];
    while (stack.length) {
      var node = stack.pop();
      if (!node) continue;
      if (typeof Window_Base !== 'undefined' && node instanceof Window_Base) {
        all.push(node.constructor.name);
        if (node.visible && node.openness > 0) {
          if (node.opacity > 0) names.push(node.constructor.name);
          else if (node.contentsOpacity > 0) textOnly.push(node.constructor.name);
        }
      }
      var kids = node.children;
      if (kids) {
        for (var i = 0; i < kids.length; i++) stack.push(kids[i]);
      }
    }
    return { leaks: names.length, names: names, textOnly: textOnly, instances: all.length, all: all };
  };

  CogwheelInspector.Overlay = CogwheelOverlay;
  CogwheelInspector.Readout = CogwheelReadout;
  CogwheelInspector.VIEW = VIEW;

  /* ============================================================== patching */

  var _Spriteset_Map_createLowerLayer = Spriteset_Map.prototype.createLowerLayer;
  /**
   * Add the overlay above the map's own content.
   *
   * Appended at the END of `createLowerLayer`, which places it over the tilemap, characters,
   * shadow and weather but UNDER pictures and the timer — so a game's own pictures still draw on
   * top, as an author would expect.
   *
   * @returns {void}
   */
  Spriteset_Map.prototype.createLowerLayer = function () {
    _Spriteset_Map_createLowerLayer.call(this);
    this._cogwheelOverlay = new CogwheelOverlay();
    this.addChild(this._cogwheelOverlay);
  };

  var _Spriteset_Map_update = Spriteset_Map.prototype.update;
  /**
   * Drive the overlay from the spriteset's own update.
   * @returns {void}
   */
  Spriteset_Map.prototype.update = function () {
    _Spriteset_Map_update.call(this);
    if (this._cogwheelOverlay) this._cogwheelOverlay.update();
  };

  var _Scene_Map_createDisplayObjects = Scene_Map.prototype.createDisplayObjects;
  /**
   * Add the screen-fixed readout above the spriteset.
   * @returns {void}
   */
  Scene_Map.prototype.createDisplayObjects = function () {
    _Scene_Map_createDisplayObjects.call(this);
    this._cogwheelReadout = new CogwheelReadout();
    this.addChild(this._cogwheelReadout);
  };

  var _Scene_Map_update = Scene_Map.prototype.update;
  /**
   * Update the readout and handle the schematic toggle.
   * @returns {void}
   */
  Scene_Map.prototype.update = function () {
    _Scene_Map_update.call(this);
    if (this._cogwheelReadout) this._cogwheelReadout.update();
    if (Input.isTriggered(TOGGLE_KEY)) {
      var ss = this._spriteset;
      if (ss && ss._cogwheelOverlay) ss._cogwheelOverlay.cycleView();
    }
  };
})();
