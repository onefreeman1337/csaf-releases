//=============================================================================
// CogwheelMap.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.1.0] Cogwheel — the map bridge. Turns your events into pushable blocks, boulders, mirrors, plates and receivers, and wires them to switches.
 * @author CSAF — Corey & Stephanie's Asset Factory
 * @url https://csaf.itch.io/cogwheel
 * @base CogwheelCore
 * @orderAfter CogwheelCore
 *
 * @param holeRegion
 * @text Hole region ID
 * @desc Region ID painted on tiles that are holes. Push a block in to bridge it. Blank = feature off.
 * @type number
 * @min 0
 * @default 1
 *
 * @param iceRegion
 * @text Ice region ID
 * @desc Region ID painted on ice. Objects pushed onto it slide until something stops them.
 * @type number
 * @min 0
 * @default 2
 *
 * @param waterRegion
 * @text Water region ID
 * @desc Region ID painted on water. Objects pushed in sink and become a crossing.
 * @type number
 * @min 0
 * @default 3
 *
 * @param pushSpeed
 * @text Push speed
 * @desc Movement speed for a pushed object (RPG Maker scale, 1-6). Blank is treated as ABSENT, not 0.
 * @type number
 * @min 1
 * @max 6
 * @default 4
 *
 * @command resetRoom
 * @text Reset Room
 * @desc Put every Cogwheel object on this map back where you authored it, and return the player to the room entrance if the reset would strand them.
 *
 * @command setEntrance
 * @text Set Room Entrance
 * @desc Record the player's current tile as this room's entrance. Room reset returns them here.
 *
 * @help
 * ============================================================================
 * Cogwheel — the map bridge
 * ============================================================================
 *
 * This plugin is the layer that connects RPG Maker's map to the Cogwheel model.
 * You author a dungeon the normal way — events on a map, regions painted on
 * tiles — and Cogwheel makes those events behave like physical objects.
 *
 * POSITIONING. Cogwheel governs objects that sit ON tiles. It does NOT govern
 * tile passability, and it is built to sit happily on top of a tile-control
 * plugin rather than replace one.
 *
 * ----------------------------------------------------------------------------
 * AUTHORING — put a note on an event
 * ----------------------------------------------------------------------------
 *
 *   <cog:block>              a pushable block. Moves one tile per push.
 *   <cog:boulder>            rolls until stopped, and SHATTERS against a wall.
 *   <cog:mirror />           a mirror facing '/'   (pushable, like a block)
 *   <cog:mirror \>           a mirror facing '\'
 *   <cog:plate>              a pressure plate. Flush with the floor.
 *   <cog:receiver>           lit when a beam reaches it.
 *   <cog:emitter 2>          emits a beam. 2 down, 4 left, 6 right, 8 up.
 *
 * MATERIALS. A block or boulder can name the material the atlas draws it in:
 *
 *   <cog:block wood>         stone (default), wood, ice, iron, gild, rune
 *   <cog:boulder amber>      granite (default), amber, obsidian
 *
 * The material changes the drawn body — and the face it leaves behind when it
 * is spent: a timber block bridges a hole as planks, a gilded one as an inlaid
 * deck. Purely visual; the interaction matrix does not read it.
 *
 * Plates and receivers can drive a switch:
 *
 *   <cog:plate switch=5>     switch 5 is ON while the plate is pressed
 *   <cog:receiver switch=6>  switch 6 is ON while the receiver is lit
 *
 * TERRAIN comes from regions, because that is what RPG Maker mappers already
 * use. Paint region 1 for holes, 2 for ice, 3 for water (all configurable).
 * Anything the player cannot walk onto in any direction is treated as a wall.
 *
 * ----------------------------------------------------------------------------
 * WHAT IS SAVED, AND WHY IT IS SO LITTLE
 * ----------------------------------------------------------------------------
 *
 * Only what play CHANGED: each object's position and whether it was consumed.
 * Your authored layout is never written into the save, and your map file is
 * never modified. That is what makes a filled hole survive a save/reload — the
 * crossing is derived from the block that made it, so it persists exactly as
 * long as the record that explains it.
 *
 * ----------------------------------------------------------------------------
 * COMPATIBILITY, STATED UP FRONT
 * ----------------------------------------------------------------------------
 *
 * Cogwheel is grid-native, exactly like RPG Maker's own events. It is NOT
 * compatible with pixel-movement or action-battle plugins that replace event
 * movement wholesale. Said here rather than discovered later.
 *
 * Every core method this plugin touches is extended with its original saved and
 * called, never replaced.
 */

(function () {
  'use strict';

  if (typeof Cogwheel === 'undefined') {
    console.error('CogwheelMap: CogwheelCore.js must be installed ABOVE this plugin.');
    return;
  }

  var PLUGIN = 'CogwheelMap';
  var P = PluginManager.parameters(PLUGIN);

  // Blank is ABSENT, never 0 (wing CLAUDE.md §16). A hole region that silently became 0 would
  // match EVERY unpainted tile on the map, turning an entire dungeon floor into holes.
  var REG_HOLE = Cogwheel.readNumber(P.holeRegion, 1);
  var REG_ICE = Cogwheel.readNumber(P.iceRegion, 2);
  var REG_WATER = Cogwheel.readNumber(P.waterRegion, 3);
  var PUSH_SPEED = Cogwheel.readNumber(P.pushSpeed, 4);

  var T = Cogwheel.TERRAIN;
  var O = Cogwheel.OBJECT;

  /* ================================================================== notes */

  /* Material vocabularies. Mirrors CogwheelAtlas.BLOCK_MATERIALS / BOULDER_MATERIALS, but declared
   * here as data rather than read from the atlas, because the PARSER must work — and be testable —
   * whether or not the art plugin is installed. A single unknown word falls back to the default
   * and is NOT reported as a bad tag: `<cog:block heavy>` should still be a block. */
  var BLOCK_MATERIALS = ['stone', 'wood', 'ice', 'iron', 'gild', 'rune'];
  var BOULDER_MATERIALS = ['granite', 'amber', 'obsidian'];

  /**
   * Find a material word in a notetag's remainder.
   *
   * @param {string} rest Text after the kind word.
   * @param {string[]} vocab Accepted material names.
   * @param {string} fallback Material when none is named.
   * @returns {string} A vocabulary entry.
   */
  function readMaterial(rest, vocab, fallback) {
    if (!rest) return fallback;
    var lower = rest.toLowerCase();
    for (var i = 0; i < vocab.length; i++) {
      // Word-ish match: 'wood' must not fire inside 'woodless' — cheap boundary check on both sides.
      var at = lower.indexOf(vocab[i]);
      if (at < 0) continue;
      var before = at === 0 ? ' ' : lower.charAt(at - 1);
      var after = at + vocab[i].length >= lower.length ? ' ' : lower.charAt(at + vocab[i].length);
      if (/[a-z]/.test(before) || /[a-z]/.test(after)) continue;
      return vocab[i];
    }
    return fallback;
  }

  /**
   * Parse a Cogwheel notetag out of an event's note box.
   *
   * Returns a DESCRIPTOR rather than mutating anything, so the same parser can be exercised in a
   * test without an engine. Unknown `<cog:...>` tags return null and are reported once by the
   * caller — a silently ignored typo in a notetag is the shape that ships a dungeon where one
   * block mysteriously is not a block.
   *
   * @param {string} note The event's raw note text.
   * @returns {{kind:string, props:Object}|{emitter:{dir:number}}|null} Descriptor, or null.
   */
  function parseNote(note) {
    if (!note) return null;
    var m = /<cog:\s*([a-zA-Z]+)([^>]*)>/.exec(note);
    if (!m) return null;
    var kind = m[1].toLowerCase();
    var rest = (m[2] || '').trim();

    if (kind === 'emitter') {
      var dm = /(\d)/.exec(rest);
      var dir = dm ? Number(dm[1]) : 2;
      if (!Cogwheel.DIRS[dir]) dir = 2;
      return { emitter: { dir: dir } };
    }

    var props = {};
    var sw = /switch\s*=\s*(\d+)/i.exec(rest);
    if (sw) props.switchId = Number(sw[1]);

    if (kind === 'block') {
      props.material = readMaterial(rest, BLOCK_MATERIALS, 'stone');
      return { kind: O.BLOCK, props: props };
    }
    if (kind === 'boulder') {
      props.material = readMaterial(rest, BOULDER_MATERIALS, 'granite');
      return { kind: O.BOULDER, props: props };
    }
    if (kind === 'plate') return { kind: O.PLATE, props: props };
    if (kind === 'receiver') return { kind: O.RECEIVER, props: props };
    if (kind === 'mirror') {
      // Facing is '/' or '\'. Default '/' so a bare <cog:mirror> is still a working mirror rather
      // than a beam-stopping dead object the author cannot explain.
      props.facing = rest.indexOf('\\') >= 0 ? '\\' : '/';
      return { kind: O.MIRROR, props: props };
    }
    return null;
  }

  /* ============================================================== the bridge */

  var CogwheelMap = {};
  window.CogwheelMap = CogwheelMap;

  /**
   * Is there a LOADED map to read?
   *
   * `$gameMap` existing is not enough: `Game_Map.width()` reads `$dataMap.width`, so with the
   * object present and no map data loaded it throws — and `SceneManager.update` CATCHES that,
   * leaving a half-created scene whose later sprites are undefined. The visible symptom is then a
   * null-property error pointing nowhere near the real cause.
   *
   * @returns {boolean} True when map data is safe to read.
   */
  function mapReady() {
    return typeof $gameMap !== 'undefined' && !!$gameMap &&
      typeof $dataMap !== 'undefined' && !!$dataMap &&
      typeof $dataMap.width === 'number';
  }

  /**
   * Read the persisted per-map record store, creating it on first use.
   *
   * This one IS enumerable: it is the thing that must survive `JsonEx`. Its companion — the live
   * grid — must NOT be, and is handled by {@link runtime}.
   *
   * @returns {Object} Map id -> save record.
   */
  function store() {
    if (!$gameSystem._csafCogwheelSaves) $gameSystem._csafCogwheelSaves = {};
    return $gameSystem._csafCogwheelSaves;
  }

  /**
   * Ensure the runtime slot exists and is NON-ENUMERABLE, whoever touches it first.
   *
   * ⛔ THIS FUNCTION EXISTS BECAUSE THE OBVIOUS VERSION SHIPPED A DEFECT, CAUGHT IN-ENGINE ON
   * 2026-08-16. The slot was defined with `Object.defineProperty` inside `runtime()` — correct in
   * isolation — while `Game_Map.setup` and `DataManager.makeSaveContents` each cleared it with a
   * PLAIN ASSIGNMENT. `$gameMap.setup()` runs at new-game time, before anything calls `runtime()`,
   * and **assigning to a property that does not exist yet creates it as ENUMERABLE**. `runtime()`
   * then saw `hasOwnProperty` return true, skipped its `defineProperty` entirely, and the slot
   * stayed enumerable for the rest of the session.
   *
   * MEASURED consequence, before the fix: `JsonEx.stringify(DataManager.makeSaveContents())`
   * contained the string `_csafCogwheelRuntime`. That is precisely the wing §13 failure — the live
   * grid and the persisted record are the same object records, so serialising both writes the
   * state twice and parsing it back yields two objects that are no longer the same object. Every
   * later mutation lands on one copy and is read from the other. Nothing throws; the puzzle simply
   * stops responding after a load.
   *
   * The lesson generalises past this bug: a property's enumerability is decided by whichever write
   * happens FIRST, so "I defined it correctly somewhere" is not a property of the object. Define it
   * in one place and route every writer through that place.
   *
   * @param {Object} sys `$gameSystem`.
   * @returns {void}
   */
  function defineRuntimeSlot(sys) {
    if (!sys) return;
    var d = Object.getOwnPropertyDescriptor(sys, '_csafCogwheelRuntime');
    if (d && d.enumerable === false) return;
    // Either absent, or present-and-enumerable because someone assigned to it first. Both are
    // repaired the same way, and repairing is safe because the value is carried across.
    var existing = d ? sys._csafCogwheelRuntime : null;
    if (d && !d.configurable) return; // cannot repair; better to leave it than to throw
    Object.defineProperty(sys, '_csafCogwheelRuntime', {
      value: existing, writable: true, enumerable: false, configurable: true
    });
  }

  /**
   * Clear the runtime without ever re-creating it as an enumerable property.
   * @param {Object} sys `$gameSystem`.
   * @returns {void}
   */
  function clearRuntime(sys) {
    if (!sys) return;
    defineRuntimeSlot(sys);
    sys._csafCogwheelRuntime = null;
  }

  /**
   * The live runtime for the current map, built on demand.
   *
   * ⚠️ THE SLOT IS NON-ENUMERABLE, AND THAT IS THE FIX RATHER THAN A TIDINESS CHOICE (wing §13).
   * The runtime's grid holds the same object records as the persisted store, so serialising both
   * writes the state twice — and parsing them back yields two objects that are no longer the same
   * object. Every later mutation then lands on one copy and is read from the other. Nothing throws;
   * the feature simply stops working.
   *
   * `JsonEx._encode` walks `Object.keys`, which returns only ENUMERABLE own properties, so a
   * non-enumerable slot is invisible to every serialisation path at once — including
   * `JsonEx.makeDeepCopy`, which third-party plugins call freely and which goes straight past a
   * `makeSaveContents` hook.
   *
   * @returns {Object|null} `{mapId, grid, emitters, beams, eventByObjectId, dirty}` or null.
   */
  function runtime() {
    if (!mapReady()) return null;
    var sys = $gameSystem;
    defineRuntimeSlot(sys);
    var rt = sys._csafCogwheelRuntime;
    if (rt && rt.mapId === $gameMap.mapId()) return rt;
    rt = build();
    sys._csafCogwheelRuntime = rt;
    return rt;
  }

  /**
   * Is this cell a wall for Cogwheel's purposes?
   *
   * Cogwheel's model has no directional walls, so "wall" means fully blocked — the player cannot
   * enter it from any side. Written as an unrolled loop rather than `[2,4,6,8].some(...)` because
   * grid rebuilds run over every tile of the map and an array literal per tile is exactly the
   * allocation pattern this wing bans (wing §3).
   *
   * @param {number} x Column.
   * @param {number} y Row.
   * @returns {boolean} True when nothing can enter the cell.
   */
  function isWallCell(x, y) {
    if ($gameMap.isPassable(x, y, 2)) return false;
    if ($gameMap.isPassable(x, y, 4)) return false;
    if ($gameMap.isPassable(x, y, 6)) return false;
    if ($gameMap.isPassable(x, y, 8)) return false;
    return true;
  }

  /**
   * Build the live grid for the current map from authored data alone.
   *
   * Called on every map load, and every load rebuilds from the MAP — never from accumulated
   * runtime state. The saved record is then applied on top. That ordering is what makes a corrupt
   * save unrepresentable: the authored layout is always the base.
   *
   * @returns {Object} A fresh runtime.
   */
  function build() {
    var w = $gameMap.width();
    var h = $gameMap.height();

    var terrain = [];
    for (var y = 0; y < h; y++) {
      var row = [];
      for (var x = 0; x < w; x++) {
        var r = $gameMap.regionId(x, y);
        if (REG_HOLE && r === REG_HOLE) row.push(T.HOLE);
        else if (REG_ICE && r === REG_ICE) row.push(T.ICE);
        else if (REG_WATER && r === REG_WATER) row.push(T.WATER);
        else if (isWallCell(x, y)) row.push(T.WALL);
        else row.push(T.FLOOR);
      }
      terrain.push(row);
    }

    var grid = Cogwheel.createGrid(w, h, terrain);
    var emitters = [];
    var eventByObjectId = {};
    var bad = 0;

    // Events in map order, so object ids are reproducible across loads — the same stability rule
    // the fixtures use, and the reason a save record can be keyed on object id at all.
    var events = $gameMap.events();
    for (var i = 0; i < events.length; i++) {
      var ev = events[i];
      var data = ev.event();
      if (!data) continue;
      var note = data.note;
      if (!note || note.indexOf('<cog:') < 0) continue;

      var desc = parseNote(note);
      if (!desc) { bad++; continue; }

      if (desc.emitter) {
        emitters.push({ x: ev.x, y: ev.y, dir: desc.emitter.dir, eventId: ev.eventId() });
        continue;
      }
      var obj = Cogwheel.addObject(grid, desc.kind, ev.x, ev.y, desc.props);
      eventByObjectId[obj.id] = ev.eventId();
    }

    if (bad > 0) {
      console.warn('CogwheelMap: ' + bad + ' event(s) on map ' + $gameMap.mapId() +
        ' carry a <cog:...> note that is not a recognised object. Check the spelling — ' +
        'an unrecognised tag is ignored, which looks exactly like a block that is not a block.');
    }

    var rt = {
      mapId: $gameMap.mapId(),
      grid: grid,
      emitters: emitters,
      eventByObjectId: eventByObjectId,
      beams: [],
      lit: {},
      revision: 0
    };

    var rec = store()[rt.mapId];
    if (rec) Cogwheel.applySave(grid, rec);
    syncEvents(rt);
    recompute(rt);
    return rt;
  }

  /**
   * Push every object's grid position back onto the event that represents it.
   *
   * Used after a load, where the event sits where the author put it and the grid knows where play
   * left it. Consumed objects (a block that filled a hole) are hidden rather than removed, because
   * the event still has to exist for `resetRoom` to bring it back.
   *
   * @param {Object} rt Runtime.
   * @returns {void}
   */
  function syncEvents(rt) {
    var objs = rt.grid.objects;
    for (var i = 0; i < objs.length; i++) {
      var o = objs[i];
      var evId = rt.eventByObjectId[o.id];
      if (!evId) continue;
      var ev = $gameMap.event(evId);
      if (!ev) continue;
      ev.locate(o.x, o.y);
      // A consumed object IS the crossing now, so it must not also be a sprite standing on it.
      ev.setOpacity(o.consumed ? 0 : 255);
      ev.setThrough(o.consumed);

      // ⚠️ FIXTURES MUST NOT BLOCK THE PLAYER, AND MZ DOES NOT KNOW THEY ARE FIXTURES.
      //
      // A plate is flush with the floor: `isFixture` already lets pushed objects travel ONTO it,
      // and `isPassable` already lets the player stand on it. But the thing on the map is an MZ
      // EVENT, and an event authored at the default `priorityType: 1` ("same as characters")
      // blocks the player no matter what this plugin's model believes. The result is a pressure
      // plate the player can never step on — an unsolvable puzzle with no error anywhere, which is
      // the exact silent-wrongness class this plugin exists to avoid.
      //
      // Found 2026-08-16 while composing a demo screenshot, not by any test: every assertion in
      // the suite and in the in-engine probe passed, because all of them push OBJECTS onto
      // fixtures and none of them walks a PLAYER onto one.
      //
      // Forced here rather than left to the author's notetag, because "remember to set priority to
      // Below Characters on every plate" is a step nobody remembers and nothing checks.
      if (Cogwheel.isFixture(o)) ev.setPriorityType(0);
    }
  }

  /**
   * Recompute everything DERIVED — beams, lit receivers, plate switches.
   *
   * Nothing here is persisted. Beams and pressed plates are recomputed from object positions every
   * time those change, which is the same rule that keeps the save shape minimal: if it can be
   * derived, deriving it is cheaper than keeping it honest.
   *
   * ⚠️ NOT a per-frame function. `traceBeam` allocates a path and a visited set by design, so this
   * runs on STATE CHANGE and its result is cached for the renderer to draw.
   *
   * @param {Object} rt Runtime.
   * @returns {void}
   */
  function recompute(rt) {
    var grid = rt.grid;

    rt.beams.length = 0;
    rt.lit = {};
    for (var i = 0; i < rt.emitters.length; i++) {
      var e = rt.emitters[i];
      var trace = Cogwheel.traceBeam(grid, e.x, e.y, e.dir);
      rt.beams.push(trace);
      if (trace.outcome === Cogwheel.BEAM.RECEIVER && trace.receiverId) {
        rt.lit[trace.receiverId] = true;
      }
    }

    // Drive switches from derived state. Written every recompute rather than only on change: a
    // switch someone else flipped by hand should snap back to what the puzzle actually says.
    var objs = grid.objects;
    for (var j = 0; j < objs.length; j++) {
      var o = objs[j];
      if (!o.switchId) continue;
      var on = false;
      if (o.kind === O.PLATE) on = Cogwheel.isPlatePressed(grid, o.x, o.y);
      else if (o.kind === O.RECEIVER) on = !!rt.lit[o.id];
      else continue;
      if ($gameSwitches.value(o.switchId) !== on) $gameSwitches.setValue(o.switchId, on);
    }

    rt.revision++;
  }

  /**
   * Persist the current grid into the save store.
   * @param {Object} rt Runtime.
   * @returns {void}
   */
  function persist(rt) {
    store()[rt.mapId] = Cogwheel.toSave(rt.grid);
  }

  /* ============================================================ interaction */

  /**
   * Attempt to push whatever stands in front of the player.
   *
   * Returns whether the input was CONSUMED, which is the only thing the caller needs to know. A
   * push that resolves to `blocked` still consumes the input — the player shoved something solid
   * and it did not budge, and letting them walk into its cell instead would be a ghost.
   *
   * @param {number} dir RPG Maker direction.
   * @returns {boolean} True when the input was spent on a push.
   */
  function tryPush(dir) {
    var rt = runtime();
    if (!rt) return false;
    var d = Cogwheel.DIRS[dir];
    if (!d) return false;

    var tx = $gamePlayer.x + d.dx;
    var ty = $gamePlayer.y + d.dy;
    var obj = Cogwheel.objectAt(rt.grid, tx, ty);
    // Fixtures are flush with the floor: the player walks onto a plate, never shoves it.
    if (!obj || Cogwheel.isFixture(obj)) return false;

    var res = Cogwheel.resolvePush(rt.grid, tx, ty, dir);
    if (res.outcome === Cogwheel.OUTCOME.BLOCKED) {
      // Face the obstacle so the shove reads as a shove rather than as nothing happening.
      $gamePlayer.setDirection(dir);
      return true;
    }

    var evId = rt.eventByObjectId[res.object.id];
    var ev = evId ? $gameMap.event(evId) : null;
    if (ev) {
      // Reuse MZ's OWN interpolation rather than writing a tween: `updateMove` walks `_realX`
      // toward `_x` at `distancePerFrame()`, so setting the logical position to the destination
      // while leaving the real position at the start produces a smooth slide of ANY length — one
      // tile for a push, the full run of the ice for a slide — with no per-frame code of ours.
      var fromX = res.from.x;
      var fromY = res.from.y;
      ev.setMoveSpeed(PUSH_SPEED);
      ev.locate(res.to.x, res.to.y);
      ev._realX = fromX;
      ev._realY = fromY;

      if (res.outcome === Cogwheel.OUTCOME.BROKE) {
        ev.setOpacity(0);
        ev.setThrough(true);
      } else if (res.outcome === Cogwheel.OUTCOME.FELL_IN_HOLE ||
                 res.outcome === Cogwheel.OUTCOME.SANK) {
        // It becomes the crossing. Keep it faintly visible: a filled hole the player cannot see is
        // a floor tile they will not trust.
        ev.setOpacity(110);
        ev.setThrough(true);
      }
    }

    $gamePlayer.setDirection(dir);
    recompute(rt);
    persist(rt);
    return true;
  }

  /* =============================================================== patching */

  // Every patch below saves its original and calls it. Never clobber a core method outright —
  // wing §3, and the #1 cause of plugin-interoperability support load.

  var _Game_Player_executeMove = Game_Player.prototype.executeMove;
  /**
   * Intercept a move to resolve a push first.
   *
   * `executeMove` is the single choke point for BOTH keyboard input and click-to-move, which is
   * why the patch is here and not in `moveByInput`: hooking the latter would leave a player who
   * clicks a destination walking straight through a block.
   *
   * @param {number} direction RPG Maker direction.
   * @returns {void}
   */
  Game_Player.prototype.executeMove = function (direction) {
    if (tryPush(direction)) return;
    _Game_Player_executeMove.call(this, direction);
  };

  var _Game_CharacterBase_canPass = Game_CharacterBase.prototype.canPass;
  /**
   * Teach passability about Cogwheel's derived terrain.
   *
   * A filled hole is walkable even though the map still says hole, and an unfilled one is not
   * walkable even where the tileset would allow it. Both directions matter: the first is the
   * reward for solving the puzzle, the second is the puzzle.
   *
   * @param {number} x Column.
   * @param {number} y Row.
   * @param {number} d Direction of travel.
   * @returns {boolean} True when passage is allowed.
   */
  Game_CharacterBase.prototype.canPass = function (x, y, d) {
    var base = _Game_CharacterBase_canPass.call(this, x, y, d);
    if (this !== $gamePlayer) return base;
    var rt = runtime();
    if (!rt) return base;

    var dd = Cogwheel.DIRS[d];
    if (!dd) return base;
    var nx = x + dd.dx;
    var ny = y + dd.dy;

    var t = Cogwheel.effectiveTerrainAt(rt.grid, nx, ny);
    if (t === T.HOLE || t === T.WATER) return false;
    // A bridged hazard reads as floor and the tileset would refuse it, so grant it explicitly.
    if (Cogwheel.isBridged(rt.grid, nx, ny)) return true;
    return base;
  };

  var _Game_Map_setup = Game_Map.prototype.setup;
  /**
   * Drop the runtime when the map changes so the next read rebuilds from the new map.
   *
   * ⚠️ THIS IS THE STALE-CACHE TRAP THIS WING HAS ALREADY PAID FOR ONCE. A biome cache held on
   * `Game_Map` — which MZ keeps for the whole playthrough — made every map after the first spawn
   * the FIRST map's creatures, forever, with no error anywhere. A per-map runtime that is not
   * invalidated on setup is that identical bug wearing different clothes.
   *
   * @param {number} mapId Map to set up.
   * @returns {void}
   */
  Game_Map.prototype.setup = function (mapId) {
    _Game_Map_setup.call(this, mapId);
    if (typeof $gameSystem !== 'undefined') clearRuntime($gameSystem);
  };

  var _DataManager_makeSaveContents = DataManager.makeSaveContents;
  /**
   * Backstop for the non-enumerable runtime slot.
   *
   * Kept even though `enumerable: false` already hides the slot from every serialisation path,
   * because it does a second useful thing: it forces a genuine rebuild from the authored map on
   * load rather than trusting whatever happened to be in memory.
   *
   * @returns {Object} Save contents.
   */
  DataManager.makeSaveContents = function () {
    if (typeof $gameSystem !== 'undefined') clearRuntime($gameSystem);
    return _DataManager_makeSaveContents.call(this);
  };

  /* ======================================================= plugin commands */

  PluginManager.registerCommand(PLUGIN, 'resetRoom', function () {
    var rt = runtime();
    if (!rt) return;
    var res = Cogwheel.resetRoom(rt.grid, $gamePlayer.x, $gamePlayer.y);
    syncEvents(rt);
    recompute(rt);
    persist(rt);
    // Reset un-fills every bridge, so a player standing on a hole they filled is now standing on
    // an open hole. `solvability_probe.js` MEASURED this as reachable in the shipped rooms rather
    // than imagining it, so it is handled rather than hoped about.
    if (res.playerStranded && rt.entrance) {
      $gamePlayer.reserveTransfer($gameMap.mapId(), rt.entrance.x, rt.entrance.y, $gamePlayer.direction(), 0);
    }
  });

  PluginManager.registerCommand(PLUGIN, 'setEntrance', function () {
    var rt = runtime();
    if (!rt) return;
    rt.entrance = { x: $gamePlayer.x, y: $gamePlayer.y };
  });

  /* ================================================================== API */

  CogwheelMap.runtime = runtime;
  CogwheelMap.recompute = recompute;
  CogwheelMap.parseNote = parseNote;
  CogwheelMap.tryPush = tryPush;
  CogwheelMap.persist = persist;
  CogwheelMap.syncEvents = syncEvents;
  CogwheelMap.clearRuntime = clearRuntime;
})();
