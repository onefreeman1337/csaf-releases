# Cogwheel — Dungeon Objects, Light Beams & Push Puzzles

**For RPG Maker MZ.** Build Zelda-style dungeon rooms out of pushable blocks, mirrors, light beams,
pressure plates and hazards — authored with notetags and regions instead of eventing every block by
hand. Every shove is previewed before you commit, on the map and in words — and since v1.1.0 the
dungeon **draws itself**: 46 procedural marks, blocks in six materials, and a Blueprint Lens that
redraws the whole room as the machine reads it. No image files anywhere in the product.

---

## The problem this removes

A single pushable block, done properly with events, is a page of eventing: check the tile ahead,
check what is on it, check the terrain, move the event, update a self-switch, handle the case where
it lands on a hole, handle the case where the player pushes it into a corner and the room becomes
unsolvable. Then you copy that page for every block in the dungeon, and when you change the rule you
change it everywhere.

**Cogwheel makes the object a property of the event, not a program inside it.** You put
`<cog:block>` in an event's note box and it is a block, with the whole interaction matrix behind it.

---

## What ships

Four plugins of raw, readable JavaScript with full JSDoc. **No minification** — you can read,
debug and extend every line. **No image files** — every piece of art in the product is a drawing
routine.

| File | What it is |
| --- | --- |
| `CogwheelCore.js` | The rules engine: the interaction matrix, the beam tracer, the save schema. Pure logic, no engine dependency. |
| `CogwheelAtlas.js` | The artwork, as code: 46 procedural marks — bodies, aftermath faces, lens terrain and icons — in one visual language, rendered at your tile size. |
| `CogwheelMap.js` | The RPG Maker bridge: notetags, regions, events, movement, persistence. |
| `CogwheelInspector.js` | The visible layer: atlas-drawn bodies, the Blueprint Lens, the schematic wiring, the additive beam, the push readout. |

Plus four worked demo rooms, seeded from the same fixtures the solvability probe runs against — so
the demo and the proof cannot drift apart.

---

## Installation

1. Copy the contents of `js/plugins/` into your project's `js/plugins/` folder.
2. In the Plugin Manager, add them **in this order**:
   1. `CogwheelCore` — the rules engine (required)
   2. `CogwheelAtlas` — the drawn artwork (required by the inspector)
   3. `CogwheelMap` — the RPG Maker bridge (required)
   4. `CogwheelInspector` — the bodies, lens, overlay and readout (optional, but it is most of the look)
3. Set the three region ids (`holeRegion`, `iceRegion`, `waterRegion`) to region numbers you are not
   already using.
4. Press Play.

---

## Building a room in two steps

### 1. Paint the terrain with regions

Use the region tool for the floor you want to behave differently:

* **hole region** — things fall in. A block pushed in **fills it permanently** and becomes a floor.
* **ice region** — things slide until the ice ends. They stop where the ice stops, not where you
  wanted them to.
* **water region** — things sink, and become a crossing.

Walls need no region at all: Cogwheel asks the tileset the same passability question the engine
asks, so a wall you already drew is already a wall.

### 2. Put a notetag on an event

| Notetag | What the event becomes |
| --- | --- |
| `<cog:block>` | A pushable block. Moves one tile per push. |
| `<cog:boulder>` | Rolls until something stops it, and **shatters** against a wall. |
| `<cog:mirror />` | A mirror facing `/`. Pushable like a block. |
| `<cog:mirror \>` | A mirror facing `\`. |
| `<cog:plate>` | A pressure plate. Flush with the floor — things can sit on it, and so can you. |
| `<cog:receiver>` | Lit when a beam reaches it. |
| `<cog:emitter 2>` | Emits a beam. `2` down, `4` left, `6` right, `8` up. |

**Leave the event's graphic BLANK and Cogwheel draws the object from the atlas.** Give it a
graphic and yours is respected — the atlas never overrides your art.

Blocks and boulders take a **material** word, which changes the drawn body *and* the face it
leaves behind when it is spent — a timber block bridges a hole as planks, a gilded one as an
inlaid deck:

```
<cog:block wood>           stone (default), wood, ice, iron, gild, rune
<cog:boulder amber>        granite (default), amber, obsidian
```

Wire them to your game with switches:

```
<cog:plate switch=5>       switch 5 is ON while the plate is pressed
<cog:receiver switch=6>    switch 6 is ON while the receiver is lit
```

That is the whole authoring surface. Everything else — what happens when a boulder rolls onto ice
toward a hole with a plate under it — is the matrix's problem, not yours.

---

## The two plugin commands

| Command | What it does |
| --- | --- |
| **Reset room** | Restores the room to its authored state. Un-fills every bridge, so a player standing on a hole they filled is safely returned to the room's entrance. |
| **Set entrance** | Marks the current player position as where Reset room returns them to. |

---

## What the player sees

* **Atlas-drawn objects.** Blocks in six materials, boulders in three, mirrors with silvered
  faces, plates that sink and light, receivers whose iris floods open — drawn by the plugin, at
  your tile size, animated by MZ's own movement. A spent block is redrawn as the bridge, ford or
  shards it became.
* **A push preview.** Face an object and the readout names what the shove will do — *moves*,
  *slides N tiles*, *falls and bridges*, *sinks*, *shatters*, *blocked* — with the reason
  underneath **and the outcome's own drawn icon**. It is computed by running the **real** resolver
  and restoring the state, so the preview and the push can never disagree.
* **The Blueprint Lens.** Press the toggle (TAB by default) and the whole room is redrawn as
  Cogwheel's own instrument: surveyed floor, hatched matter, open pits with depth rings, water and
  faceted sheet ice as drafting marks, you as a surveyor's reticle, foreign events as mechanism
  cogs. The puzzle exactly as the machine reads it — and a room readability tool your players will
  keep on. (On maps past ~2,400 cells the lens politely declines rather than building a hundred
  thousand sprites.)
* **A light beam** drawn additively with a bloom at the emitter and a flooded iris at the receiver
  — a PIXI layer, not a windowskin. Cogwheel draws **no RPG Maker windows at all**.

---

## Compatibility — read this before you buy

* ⚠️ **Cogwheel is grid-native.** It resolves pushes in whole tiles against the tile grid. It is
  **not compatible with pixel-movement plugins or action-battle systems** that move the player off
  the tile grid. This is stated up front rather than discovered later.
* **No core method is replaced.** Every engine method Cogwheel extends saves the original and calls
  it, so other plugins touching the same methods keep working. That is enforced by a test that reads
  the shipped source against the real MZ source.
* **Saves are lossless and versioned.** A room stores a small mutation record, and everything else —
  beams, links, bridge state — is recomputed on load. The live runtime object is never serialised.
* **Nothing is allocated in the per-frame path**, enforced by a static scan that is itself proven to
  fire against a deliberately sabotaged copy.

### Not in this version

Stated plainly so nothing here is a surprise:

* **Cranks** and **lift / carry / throw** are not implemented. The kit is push-based.

---

## Verification

* **221/221 checks green** across five suites — the interaction matrix cell by cell, the atlas
  (46 marks proven distinct, deterministic and non-trivial), the notetag parser, the
  zero-allocation scan, and the patch-discipline guard.
* **In-engine verified**, not just unit-tested: 47/47 checks in a real running MZ engine — the
  bodies tracking their events to the pixel, the lens building one cell per tile, zero RPG Maker
  windowskins in every view — with 0 page errors.
* **All four demo rooms proven solvable by exhaustive search**, with room reset proven to recover
  every reachable dead-end state.
* **Frame cost measured in the real engine**: the update half — every line of this plugin's own code
  — costs **0.09 ms/frame mean** against a 2 ms budget, with 13 draw calls per frame and **zero**
  texture uploads, bitmap redraws or window refreshes.

---

## Support

Questions, bugs and compatibility reports are welcome on the itch.io project page.

*Cogwheel is made by CSAF — Corey and Stephanie's Asset Factory.*
