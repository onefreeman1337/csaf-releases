{
  "$GMScript": "v1",
  "%Name": "cls_selftest",
  "name": "cls_selftest",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}