/// cls_selftest.gml - the in-engine suite (`Colosseum.exe -selftest` writes cls_selftest.json).
///
/// Colosseum - Tournaments Your Game Draws, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Stage 99 = the suite reached its end.
/// SESSION 1 SCOPE: the pure core - entering teams and its reported problems, weighted seeding and the classic
/// seed order, the single-elimination draw with byes, reporting results, elimination, levelling, the league and
/// its table, standards, save/load. ⚠️ A suite green on its first run has not proven it can go red: the gate
/// break test runs in the same session, and every threshold here carries a control.

function cls_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 60) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
function cls_st_stage(_st, _n) { _st.stage = _n; global.cls_stage = _n; }
function cls_st_note(_st, _s) { array_push(_st.notes, _s); }

function cls_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, failures: [], stage: 0, notes: [] };

    cls_st_stage(_st, 1);    // entering teams: problems REPORTED, never thrown
    var _t = cls_create();
    cls_st_assert(_st, cls_is_state(_t) && cls_team_count(_t) == 0 && !_t.record.started, "a fresh tournament is empty and undrawn");
    cls_add_team(_t, "a", "Alpha", 60);
    cls_add_team(_t, "a", "Alpha again", 10);
    cls_add_team(_t, "", "No id", 10);
    cls_add_team(_t, "b", "Beta", 40);
    cls_st_assert(_st, cls_team_count(_t) == 2 && array_length(cls_problems(_t)) == 2, "a duplicate id and a missing id are reported, not thrown: " + string(cls_problems(_t)));
    cls_st_assert(_st, cls_team(_t, "a").name == "Alpha" && cls_team(_t, "a").rating == 60 && cls_team(_t, "a").level == 1, "the FIRST team of a duplicate pair is the one kept");
    cls_st_assert(_st, cls_team(_t, "nobody") == undefined && cls_add_team(undefined, "x", "X") == undefined, "refusals: unknown id, non-state");

    cls_st_stage(_st, 2);    // the classic seed order, and weighted seeding
    // ⛔ This asserted the LITERAL [1,8,5,4,3,6,7,2] on the first run and went red over correct code: the
    // generator produces [1,8,4,5,2,7,3,6], which pairs and seeds identically and merely LISTS the first-round
    // ties in another order. An assertion that hard-codes a remembered constant is testing the constant, not the
    // code. What follows are the PROPERTIES that actually make a seed order right, at three field sizes.
    var _o8 = cls__seed_order(8);
    cls_st_note(_st, "seed order for 8: " + string(_o8));
    for (var _sz = 0; _sz < 3; _sz++) {
        var _n8 = [4, 8, 16][_sz], _o = cls__seed_order(_n8);
        // 1. a permutation of 1..n, each seed exactly once
        var _seen8 = array_create(_n8 + 1, 0), _perm = (array_length(_o) == _n8);
        for (var _i = 0; _i < array_length(_o); _i++) { var _v = _o[_i]; if (_v < 1 || _v > _n8) _perm = false; else _seen8[_v]++; }
        for (var _i = 1; _i <= _n8; _i++) if (_seen8[_i] != 1) _perm = false;
        cls_st_assert(_st, _perm, "seed order for " + string(_n8) + " is a permutation of 1.." + string(_n8) + ": " + string(_o));
        // 2. THE defining property: every first-round pair sums to n+1, so the best meets the worst
        var _pairs = true;
        for (var _i = 0; _i < array_length(_o); _i += 2) if (_o[_i] + _o[_i + 1] != _n8 + 1) _pairs = false;
        cls_st_assert(_st, _pairs, "every first-round pair in a " + string(_n8) + " draw sums to " + string(_n8 + 1) + ": " + string(_o));
        // 3. seeds 1 and 2 start in opposite halves, so they can only meet in the final
        var _half = _n8 / 2, _p1 = -1, _p2 = -1;
        for (var _i = 0; _i < array_length(_o); _i++) { if (_o[_i] == 1) _p1 = _i; if (_o[_i] == 2) _p2 = _i; }
        cls_st_assert(_st, (_p1 < _half) != (_p2 < _half), "the top two seeds start in opposite halves of a " + string(_n8) + " draw");
    }
    var _d = cls_demo_state("single");
    var _seeded = cls_seed(_d);
    cls_st_assert(_st, _seeded[0].id == "ironjaw" && _seeded[0].seed == 1 && _seeded[array_length(_seeded) - 1].id == "novice", "seeding sorts by rating, highest first");

    cls_st_stage(_st, 3);    // the single-elimination draw, byes and all
    cls_st_note(_st, "12 teams -> " + string(array_length(cls_matches(_d))) + " matches over " + string(_d.record.rounds) + " rounds");
    cls_st_assert(_st, _d.record.rounds == 4 && array_length(cls_matches(_d)) == 15, "12 teams pad to 16: 15 matches over 4 rounds, got " + string(array_length(cls_matches(_d))) + "/" + string(_d.record.rounds));
    var _byes = 0, _r1 = cls_round_of(_d, 1);
    for (var _i = 0; _i < array_length(_r1); _i++) if (_r1[_i].bye) _byes++;
    cls_st_assert(_st, _byes == 4, "16 slots and 12 teams means exactly 4 byes, got " + string(_byes));
    // a bye must have carried its team into round 2 rather than leaving an empty place
    var _r2 = cls_round_of(_d, 2), _filled = 0;
    for (var _i = 0; _i < array_length(_r2); _i++) { if (_r2[_i].a != "") _filled++; if (_r2[_i].b != "") _filled++; }
    cls_st_assert(_st, _filled == 4, "the four byes carried four teams into round 2, got " + string(_filled) + " places filled");
    cls_st_assert(_st, cls_round_name(_d, 4) == "Final" && cls_round_name(_d, 3) == "Semi-final" && cls_round_name(_d, 2) == "Quarter-final", "round names count back from the final");

    cls_st_stage(_st, 4);    // reporting results, elimination and carrying the winner on
    var _m = cls_next_match(_d);
    cls_st_assert(_st, is_struct(_m) && _m.a != "" && _m.b != "" && !_m.played, "the next match has both places filled");
    var _loser = _m.b;
    cls_st_assert(_st, cls_report(_d, _m.id, _m.a, 2, 0), "a result is accepted");
    cls_st_assert(_st, !cls_report(_d, _m.id, _m.a) && !cls_report(_d, _m.id, "nobody") && !cls_report(_d, "nomatch", _m.a), "a replay, an outsider and an unknown match are all refused");
    cls_st_assert(_st, cls_team(_d, _loser).out && cls_team(_d, _loser).losses == 1 && cls_team(_d, _m.a).wins == 1, "the loser is out of an elimination draw and the winner counted");
    // the winner must APPEAR in the next round, in the right place
    var _carried = false, _next = cls_round_of(_d, _m.round + 1);
    for (var _i = 0; _i < array_length(_next); _i++) if (_next[_i].a == _m.a || _next[_i].b == _m.a) _carried = true;
    cls_st_assert(_st, _carried, "the winner was carried into the next round");

    cls_st_stage(_st, 5);    // a whole tournament, and levelling
    var _full = cls_demo_state("single");
    var _played = cls_demo_play_all(_full);
    cls_st_note(_st, "a full single-elimination ran " + string(_played) + " matches; champion " + cls_champion(_full));
    cls_st_assert(_st, cls_is_over(_full) && cls_champion(_full) != "", "a finished tournament has a champion: " + cls_champion(_full));
    var _champ = cls_team(_full, cls_champion(_full));
    cls_st_assert(_st, !_champ.out && _champ.wins >= 3, "the champion is unbeaten and won at least 3 ties: " + string(_champ.wins));
    cls_st_assert(_st, _champ.level > 1 && _champ.rating > cls_team(_full, _champ.id).rating - 1, "a rival that keeps surviving levels up: level " + string(_champ.level));
    // CONTROL: a team knocked out in round 1 must NOT have levelled, or "levelling" is just a clock
    var _early = undefined;
    for (var _i = 0; _i < array_length(cls_teams(_full)); _i++) { var _q = cls_teams(_full)[_i]; if (_q.out && _q.rounds_survived == 0) _early = _q; }
    cls_st_assert(_st, is_struct(_early) && _early.level == 1, "control: a team out in round one did not level");

    cls_st_stage(_st, 6);    // the league and its table
    var _lg = cls_demo_state("league");
    cls_st_assert(_st, array_length(cls_matches(_lg)) == 66, "12 teams meet once each: 66 matches, got " + string(array_length(cls_matches(_lg))));
    var _first = cls_next_match(_lg);
    cls_st_assert(_st, cls_report(_lg, _first.id, "", 1, 1), "a league accepts a draw");
    cls_st_assert(_st, cls_match(_lg, _first.id).drawn && cls_team(_lg, _first.a).draws == 1 && cls_team(_lg, _first.a).points == _lg.cfg.points_draw, "a draw is recorded for both sides");
    cls_st_assert(_st, !cls_team(_lg, _first.a).out, "nobody is knocked out of a league");
    cls_demo_play_all(_lg);
    var _table = cls_standings(_lg);
    cls_st_assert(_st, array_length(_table) == 12 && cls_champion(_lg) == _table[0].id, "the league champion is the top of its own table");
    var _ordered = true;
    for (var _i = 1; _i < array_length(_table); _i++) if (cls__ranks_below(_table[_i - 1], _table[_i])) _ordered = false;
    cls_st_assert(_st, _ordered, "the table is sorted by its own comparison");
    cls_st_note(_st, "league table head: " + _table[0].name + " " + string(_table[0].points) + "pts, tail: " + _table[11].name + " " + string(_table[11].points) + "pts");

    cls_st_stage(_st, 7);    // standards: one per team, and they must not collapse together
    var _seen = {}, _dupes = 0, _n = cls_team_count(_full);
    for (var _i = 0; _i < _n; _i++) {
        var _sd = cls_standard(_full, cls_teams(_full)[_i].id);
        var _k = string(_sd.family) + "/" + string(_sd.charge) + "/" + string(_sd.division) + "/" + string(_sd.tincture) + "/" + string(_sd.metal) + "/" + string(_sd.ordinary);
        if (variable_struct_exists(_seen, _k)) _dupes++; else _seen[$ _k] = true;
    }
    cls_st_note(_st, "standards: " + string(array_length(variable_struct_get_names(_seen))) + " distinct of " + string(_n) + " teams");
    cls_st_assert(_st, _dupes == 0, "no two teams in the sample field carry the same standard: " + string(_dupes) + " collisions");
    cls_st_assert(_st, cls_standard(_full, "nobody") == undefined && array_length(cls_standard_shapes()) == CLS_STANDARD_FAMILIES, "standard refusals, and the silhouette table is index-parallel with the family macro");
    // a standard can be struck for a bare key, and the same key must give the same arms every run or a saved
    // game reloads under a different banner. Two DIFFERENT keys must differ, or the generator is a constant.
    var _k1 = cls_standard_from_key("housewake"), _k1b = cls_standard_from_key("housewake"), _k2 = cls_standard_from_key("housemourn");
    var _same = (_k1.family == _k1b.family && _k1.charge == _k1b.charge && _k1.division == _k1b.division && _k1.tincture == _k1b.tincture && _k1.metal == _k1b.metal && _k1.ordinary == _k1b.ordinary);
    var _diff = (_k1.family != _k2.family || _k1.charge != _k2.charge || _k1.division != _k2.division || _k1.tincture != _k2.tincture || _k1.metal != _k2.metal || _k1.ordinary != _k2.ordinary);
    cls_st_assert(_st, _same, "the same key strikes the same arms twice (a save must reload under its own banner)");
    cls_st_assert(_st, _diff, "control: two different keys strike different arms, so the generator is not a constant");
    // the space the corpus sheet will draw from, stated as a number rather than believed
    cls_st_note(_st, "standard space = " + string(CLS_STANDARD_FAMILIES * CLS_STANDARD_CHARGES * CLS_STANDARD_DIVISIONS * CLS_STANDARD_TINCTURES * CLS_STANDARD_ORDINARIES * 2) + " combinations");
    cls_st_assert(_st, CLS_STANDARD_FAMILIES * CLS_STANDARD_CHARGES * CLS_STANDARD_DIVISIONS >= 40, "the standard must be able to produce 40+ distinct marks (master 1.1 volume)");

    cls_st_stage(_st, 8);    // save and load
    var _sv = cls_save(_full), _fresh = cls_create();
    cls_st_assert(_st, is_string(_sv) && _sv != "" && cls_save(undefined) == "", "a save is a string, a non-state saves nothing");
    cls_st_assert(_st, cls_load(_fresh, _sv) && cls_team_count(_fresh) == 12 && cls_champion(_fresh) == cls_champion(_full), "a save loads back with its champion");
    cls_st_assert(_st, array_length(cls_matches(_fresh)) == array_length(cls_matches(_full)) && cls_is_over(_fresh), "the whole draw came back");
    var _before = cls_team_count(_fresh);
    cls_st_assert(_st, !cls_load(_fresh, "{bad") && !cls_load(_fresh, "") && !cls_load(_fresh, "[1,2]") && cls_team_count(_fresh) == _before, "unreadable saves are refused and leave the state untouched");

    cls_st_stage(_st, 9);    // the draw refuses what it cannot draw
    var _tiny = cls_create();
    cls_add_team(_tiny, "only", "Only One", 50);
    cls_st_assert(_st, !cls_start(_tiny, "single") && array_length(cls_problems(_tiny)) == 1, "a field of one is refused and reported");
    var _twice = cls_demo_state("single");
    cls_st_assert(_st, !cls_start(_twice, "single"), "the bracket cannot be drawn twice");
    cls_st_assert(_st, cls_add_team(_twice, "late", "Latecomer", 50) == undefined, "a team cannot enter after the draw");

    cls_st_stage(_st, 10);   // the geometry primitives every drawn thing is built from
    // ⛔ Convexity is a PRECONDITION of the half-plane clip and of every triangle fan in cls_board, and a
    // precondition that only lives in a comment is enforced by whoever last read the comment. Asserted here on
    // all six silhouettes, WITH a control, because a convexity test that cannot say no is not a test.
    var _shapes = cls_standard_shapes(), _allconv = true, _badshape = "";
    for (var _i = 0; _i < array_length(_shapes); _i++) {
        var _o = cls_standard_outline(_i, 100, 100, 100, 100);
        if (!cls_is_convex(_o)) { _allconv = false; _badshape = _shapes[_i]; }
    }
    cls_st_assert(_st, _allconv, "all " + string(array_length(_shapes)) + " silhouettes are convex; first failure: " + _badshape);
    cls_st_assert(_st, !cls_is_convex([[0, 0], [10, 0], [10, 10], [5, 5], [0, 10]]), "control: a chevron-notched outline is reported NOT convex");
    cls_st_assert(_st, !cls_is_convex([[0, 0], [10, 0]]) && !cls_is_convex([]), "control: two points and no points are not convex outlines");
    // the clip keeps what is on the positive side and inserts real crossings
    var _sq = cls__rect_pts(0, 0, 100, 100);
    var _half = cls__clip(_sq, 50, 50, 1, 0), _none = cls__clip(_sq, 200, 50, 1, 0), _all = cls__clip(_sq, -50, 50, 1, 0);
    var _halfok = (array_length(_half) == 4);
    for (var _i = 0; _i < array_length(_half); _i++) if (_half[_i][0] < 50 - 0.0001) _halfok = false;
    cls_st_assert(_st, _halfok, "a half-plane clip keeps only the far side and closes it: " + string(array_length(_half)) + " points");
    cls_st_assert(_st, array_length(_none) == 0 && array_length(_all) == 4, "a clip that removes everything returns nothing; one that removes nothing returns the outline");
    cls_st_assert(_st, cls_is_convex(_half), "a clipped convex outline is still convex");
    // the inset is exact on every edge, and every point of it lies inside the original
    var _insetok = true, _insetshape = "";
    for (var _i = 0; _i < array_length(_shapes); _i++) {
        var _o = cls_standard_outline(_i, 200, 200, 120, 130), _in2 = cls__inset(_o, 10);
        if (array_length(_in2) < 3 || !cls_is_convex(_in2)) { _insetok = false; _insetshape = _shapes[_i] + " (degenerate)"; continue; }
        for (var _j = 0; _j < array_length(_in2); _j++) if (!cls_contains(_o, _in2[_j][0], _in2[_j][1])) { _insetok = false; _insetshape = _shapes[_i]; }
    }
    cls_st_assert(_st, _insetok, "an inset of every silhouette stays inside it and stays convex; first failure: " + _insetshape);
    cls_st_assert(_st, array_length(cls__inset(_sq, 80)) == 0, "control: an inset deeper than the shape collapses to nothing rather than turning inside out");

    cls_st_stage(_st, 11);   // the colour contract - the one thing that decides whether a device can be SEEN
    var _minGap = 999, _combos = 0, _bandIsField = 0, _blazonMismatch = 0;
    var _TN = cls_standard_tincture_names();
    for (var _ti = 0; _ti < CLS_STANDARD_TINCTURES; _ti++)
    for (var _mi = 0; _mi < 2; _mi++)
    for (var _fa = 0; _fa < CLS_STANDARD_FAMILIES; _fa++)
    for (var _dv = 0; _dv < CLS_STANDARD_DIVISIONS; _dv++) {
        var _sd = { key: "x", family: _fa, charge: 0, division: _dv, tincture: _ti, metal: _mi, ordinary: 0, level: 1 };
        var _C = cls_standard_colours(_sd);
        _combos++;
        _minGap = min(_minGap, cls_lum(_C.metal) - cls_lum(_C.field), cls_lum(_C.metal) - cls_lum(_C.band));
        if (_C.band == _C.field) _bandIsField++;
        // the blazon must name the SAME band the picture uses - two readers of cls_band_index, never two copies
        if (string_pos(_TN[cls_band_index(_sd)], cls_blazon(_sd)) == 0) _blazonMismatch++;
    }
    cls_st_note(_st, "colour sweep: " + string(_combos) + " field combinations, smallest metal-to-colour gap " + string(_minGap));
    cls_st_assert(_st, _combos == CLS_STANDARD_TINCTURES * 2 * CLS_STANDARD_FAMILIES * CLS_STANDARD_DIVISIONS, "the colour sweep ran over every combination, not a subset: " + string(_combos));
    cls_st_assert(_st, _minGap >= CLS_CONTRAST_FLOOR, "the metal a device is struck in clears every colour it can sit on by " + string(CLS_CONTRAST_FLOOR) + ": worst gap " + string(_minGap));
    cls_st_assert(_st, _bandIsField == 0, "an ordinary is never the same colour as the field under it: " + string(_bandIsField) + " collisions");
    cls_st_assert(_st, _blazonMismatch == 0, "every blazon names the tincture the ordinary is actually drawn in: " + string(_blazonMismatch) + " disagreements");
    // ⛔ CONTROL, and it is also the product's one honest limitation stated as an assertion. The first version of
    // this control compared an invented rgb(240,240,240) against or, and their gap is 0.251 against a floor of
    // 0.250 - so the control went RED over correct code and cost a build. A control has to be a case that is
    // genuinely close, not one guessed to be. The two METALS are that case: they do not clear the floor against
    // each other, which is exactly why a metal device lying on the metal half of a divided field is separated by
    // relief and a dark halo rather than by hue. Nothing here claims that gap is a colour gap.
    var _MM = cls_standard_metals();
    cls_st_assert(_st, abs(cls_lum(_MM[1]) - cls_lum(_MM[0])) < CLS_CONTRAST_FLOOR, "control: the two metals do NOT clear the contrast floor against each other (gap " + string(abs(cls_lum(_MM[1]) - cls_lum(_MM[0]))) + "), so the floor can go red");
    cls_st_assert(_st, cls_standard_colours(undefined) == undefined && cls_standard_colours({}) == undefined && cls_blazon(42) == "", "colour and blazon refusals");

    cls_st_stage(_st, 12);   // a device stays inside the shield it is struck on
    // ⛔ This is a question about TWO functions (cls_standard_outline and cls_charge_parts) and nothing inside
    // either of them can answer it. A device that crosses its own rim is a defect no ink floor can see, because
    // the ink is on the board where the shield already is.
    var _outside = 0, _worst = "", _checked = 0, _nonconvexPart = 0, _parts_seen = 0;
    for (var _fa = 0; _fa < CLS_STANDARD_FAMILIES; _fa++) {
        var _o = cls_standard_outline(_fa, 100, 100, 100, 100);
        var _rim = clamp(min(100, 100) * 0.10, 1.5, 9), _in3 = cls__inset(_o, _rim);
        var _rr = (100 - _rim) * cls_standard_room(_fa);
        for (var _ch2 = 0; _ch2 < CLS_STANDARD_CHARGES; _ch2++) {
            var _PT = cls_charge_parts(_ch2, _rr);
            _checked++;
            for (var _p = 0; _p < array_length(_PT); _p++) {
                _parts_seen++;
                if (_PT[_p].k == "fan" && !cls_is_convex(_PT[_p].p)) _nonconvexPart++;
                var _pp = _PT[_p].p;
                for (var _q = 0; _q < array_length(_pp); _q++)
                    if (!cls_contains(_in3, 100 + _pp[_q][0], 100 + _pp[_q][1])) { _outside++; _worst = _shapes[_fa] + "/" + cls_standard_charges()[_ch2]; }
            }
        }
    }
    cls_st_note(_st, "device containment: " + string(_checked) + " shield-and-device pairs, " + string(_parts_seen) + " parts");
    cls_st_assert(_st, _checked == CLS_STANDARD_FAMILIES * CLS_STANDARD_CHARGES && _parts_seen > 100, "the containment sweep ran over every pair and saw real parts: " + string(_checked) + " pairs, " + string(_parts_seen) + " parts");
    cls_st_assert(_st, _outside == 0, "no device crosses the rim of any silhouette: " + string(_outside) + " points outside, worst " + _worst);
    cls_st_assert(_st, _nonconvexPart == 0, "every fan-filled device part is convex (a concave one would be silently spanned): " + string(_nonconvexPart));
    // CONTROL: an oversized device MUST be caught, or the sweep above is testing nothing
    var _big = cls_charge_parts(1, 400), _bigOut = 0, _oo = cls_standard_outline(0, 100, 100, 100, 100);
    for (var _p = 0; _p < array_length(_big); _p++) for (var _q = 0; _q < array_length(_big[_p].p); _q++)
        if (!cls_contains(_oo, 100 + _big[_p].p[_q][0], 100 + _big[_p].p[_q][1])) _bigOut++;
    cls_st_assert(_st, _bigOut > 0, "control: a device drawn four times too large IS reported outside the shield (" + string(_bigOut) + " points)");

    cls_st_stage(_st, 13);   // every ordinary covers the point the device is struck at
    // ⛔ The chevron did NOT, and the device then sat astride a division boundary with nothing deciding which
    // colour was under it. This is re-derived from the geometry, never read off a table.
    var _bare = 0, _bareWhich = "", _ordChecked = 0;
    for (var _fa = 0; _fa < CLS_STANDARD_FAMILIES; _fa++)
    for (var _od = 0; _od < CLS_STANDARD_ORDINARIES; _od++) {
        var _o = cls_standard_outline(_fa, 100, 100, 90, 100), _in4 = cls__inset(_o, 9);
        var _R2 = cls__ordinary_regions(_in4, _od, 100, 100, 81, 91), _covered = false;
        for (var _p = 0; _p < array_length(_R2); _p++) if (cls_contains(_R2[_p], 100, 100)) _covered = true;
        _ordChecked++;
        if (!_covered) { _bare++; _bareWhich = _shapes[_fa] + "/" + cls_standard_ordinaries()[_od]; }
    }
    cls_st_assert(_st, _ordChecked == CLS_STANDARD_FAMILIES * CLS_STANDARD_ORDINARIES, "the ordinary sweep ran over every pair: " + string(_ordChecked));
    cls_st_assert(_st, _bare == 0, "every ordinary covers the centre the device is struck at: " + string(_bare) + " bare, first " + _bareWhich);
    cls_st_assert(_st, array_length(cls__band(_sq, 50, 50, 1, 0, 0)) == 0, "control: a band of no thickness produces no region");
    // the field is cut into the right number of pieces, and every piece is fillable
    var _divBad = 0;
    for (var _dv = 0; _dv < CLS_STANDARD_DIVISIONS; _dv++) {
        var _F2 = cls__field_regions(cls_standard_outline(0, 100, 100, 90, 100), _dv, 100, 100, 90, 100);
        var _want = [1, 2, 2, 2, 2, 4, 4, 8][_dv];
        if (array_length(_F2) != _want) _divBad++;
        for (var _p = 0; _p < array_length(_F2); _p++) if (!cls_is_convex(_F2[_p].p)) _divBad++;
    }
    cls_st_assert(_st, _divBad == 0, "every division cuts the field into the right number of convex wedges: " + string(_divBad) + " problems");

    cls_st_stage(_st, 14);   // the board layout, proved without drawing it
    var _bd = cls_bake_played("single", 6);
    var _G = cls_board_layout(_bd, 0, 0, 1600, 900);
    cls_st_assert(_st, is_struct(_G) && array_length(_G.ties) == array_length(cls_matches(_bd)), "the layout places every tie: " + string(array_length(_G.ties)) + " of " + string(array_length(cls_matches(_bd))));
    var _outOfRect = 0, _overlap = 0, _offCentre = 0;
    for (var _i = 0; _i < array_length(_G.ties); _i++) {
        var _t2 = _G.ties[_i];
        if (_t2.cy - _t2.ph * 0.5 < 0 || _t2.cy + _t2.ph * 0.5 > 900 || _t2.cx - _t2.pw * 0.5 < 0 || _t2.cx + _t2.pw * 0.5 > 1600) _outOfRect++;
        for (var _j = _i + 1; _j < array_length(_G.ties); _j++) {
            var _u2 = _G.ties[_j];
            if (_u2.round != _t2.round) continue;
            if (abs(_u2.cy - _t2.cy) < (_t2.ph + _u2.ph) * 0.5 - 0.0001) _overlap++;
        }
    }
    // each later tie sits on the mean of the two that feed it - that is what makes a bracket read as a bracket
    for (var _i = 0; _i < array_length(_G.ties); _i++) {
        var _t2 = _G.ties[_i];
        if (_t2.round < 2) continue;
        var _f1 = -1, _f2 = -1;
        for (var _j = 0; _j < array_length(_G.ties); _j++) {
            var _u2 = _G.ties[_j];
            if (_u2.round != _t2.round - 1) continue;
            if (_u2.slot == _t2.slot * 2) _f1 = _u2.cy;
            if (_u2.slot == _t2.slot * 2 + 1) _f2 = _u2.cy;
        }
        if (_f1 >= 0 && _f2 >= 0 && abs(_t2.cy - (_f1 + _f2) * 0.5) > 0.01) _offCentre++;
    }
    cls_st_assert(_st, _outOfRect == 0, "every plate is inside the rect it was given: " + string(_outOfRect) + " outside");
    cls_st_assert(_st, _overlap == 0, "no two plates in a round overlap: " + string(_overlap) + " overlapping pairs");
    cls_st_assert(_st, _offCentre == 0, "every later tie is centred on the two that feed it: " + string(_offCentre) + " off centre");
    cls_st_note(_st, "plate heights by round: " + string(_G.ties[0].ph) + " to " + string(_G.ties[array_length(_G.ties) - 1].ph));
    cls_st_assert(_st, _G.ties[array_length(_G.ties) - 1].ph > _G.ties[0].ph, "a later round's plate is taller than an earlier one, which is what fills the right of the board");
    cls_st_assert(_st, cls_board_layout(_bd, 0, 0, 100, 80) == undefined && cls_board_layout(cls_create(), 0, 0, 1600, 900) == undefined, "the layout refuses a rect too small to read and a tournament not yet drawn");
    // the drawn entry points refuse rather than throw - a buyer's typo must not land in their draw event
    cls_st_assert(_st, !cls_draw_standard(0, 0, 40, 40, undefined) && !cls_draw_standard(0, 0, 2, 2, cls_standard(_bd, "ironjaw")) && !cls_draw_standard(0, 0, 9000, 40, cls_standard(_bd, "ironjaw")), "cls_draw_standard refuses a non-standard, a box too small and a box too large");
    cls_st_assert(_st, cls_board_draw(cls_create(), 0, 0, 1600, 900) == undefined && cls_table_draw(undefined, 0, 0, 1600, 900) == undefined, "the two board entry points refuse an undrawn and a non-state");

    cls_st_stage(_st, 99);
    return _st;
}

function cls_selftest_write(_st) {
    var _f = file_text_open_write("cls_selftest.json");
    file_text_write_string(_f, "{\"total\":" + string(_st.total) + ",\"pass\":" + string(_st.pass) + ",\"fail\":" + string(_st.fail) + ",\"stage\":" + string(_st.stage) + ",\"notes\":[");
    for (var _i = 0; _i < array_length(_st.notes); _i++) { if (_i > 0) file_text_write_string(_f, ","); file_text_write_string(_f, "\"" + string_replace_all(_st.notes[_i], "\"", "'") + "\""); }
    file_text_write_string(_f, "],\"failures\":[");
    for (var _i = 0; _i < array_length(_st.failures); _i++) { if (_i > 0) file_text_write_string(_f, ","); file_text_write_string(_f, "\"" + string_replace_all(_st.failures[_i], "\"", "'") + "\""); }
    file_text_write_string(_f, "]}");
    file_text_close(_f);
}
