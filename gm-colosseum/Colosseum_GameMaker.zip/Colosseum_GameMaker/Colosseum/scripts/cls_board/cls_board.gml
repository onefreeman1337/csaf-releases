/// cls_board.gml - the tournament DRAWN: a struck bracket board, a plate per tie, inked feed lines from round to
/// round, a champion's plate, a ruled league table - and the STANDARD every rival carries, generated from its own
/// key: a shield silhouette, a divided field, an ordinary laid across it, and one of ten struck devices.
///
/// Colosseum - Tournaments Your Game Draws, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Pure GML drawing: no sprite, no shader, no surface kept.
///
/// THE SHAPE OF THE FILE, because the order matters:
///   1. colour        - the tincture and metal tables, relative luminance, and the CONTRACT that says which
///                      colour a device is drawn in (proved in cls_selftest; no assertion can see a picture).
///   2. geometry      - convex outlines, a half-plane clip, an exact inset, a lit fill. Everything below is built
///                      from those four.
///   3. the standard  - silhouette x division x ordinary x charge.
///   4. the board     - layout (pure) and the draw that consumes it.
///
/// ⛔ EVERY OUTLINE IN THIS FILE IS CONVEX, ON PURPOSE. A half-plane clip is exact on a convex subject and leaves
/// degenerate bridges on a concave one, and a triangle fan spans a concavity in silence. The two forms that are
/// not convex (a crescent's lune, an annulus) are drawn as TRIANGLE STRIPS between a rail pair, which is exact
/// where a fan is not. cls_selftest asserts convexity on all six silhouettes rather than trusting this paragraph.

#macro CLS_BOARD_SEGMENTS 34       // points sampled along a curved silhouette edge
#macro CLS_CLIP_EPSILON 0.0001     // ⛔ GML applies a default epsilon of 0.00001 to numeric comparisons, so any
                                   // tolerance at or below ~1e-5 is unusable in BOTH directions. Never lower this.
#macro CLS_CONTRAST_FLOOR 0.25     // the luminance gap two adjacent areas need before a reader separates them

// ---------------------------------------------------------------------------------------------------------------
// 1. COLOUR
// ---------------------------------------------------------------------------------------------------------------

/// @function cls_standard_tinctures()
/// @description The eight heraldic colours, in index order. All eight are dark (relative luminance 0.11 to 0.39),
/// which is what makes contrast with a metal a property of the TABLE rather than of any one standard. Pure.
function cls_standard_tinctures() {
    return [make_colour_rgb(158, 42, 44), make_colour_rgb(34, 62, 128), make_colour_rgb(32, 94, 58),
            make_colour_rgb(28, 26, 30), make_colour_rgb(86, 38, 104), make_colour_rgb(154, 84, 30),
            make_colour_rgb(110, 30, 64), make_colour_rgb(80, 90, 104)];
}

/// @function cls_standard_tincture_names()
/// @description The eight colours by their heraldic names, index-parallel with cls_standard_tinctures. Pure.
function cls_standard_tincture_names() { return ["gules", "azure", "vert", "sable", "purpure", "tenne", "murrey", "cendree"]; }

/// @function cls_standard_metals()
/// @description The two metals, or and argent, in index order. Pure.
function cls_standard_metals() { return [make_colour_rgb(216, 174, 76), make_colour_rgb(214, 219, 228)]; }

/// @function cls_standard_metal_names()
function cls_standard_metal_names() { return ["or", "argent"]; }

/// @function cls_standard_charges()
/// @description The ten devices, in index order. Every one differs from every other by SILHOUETTE, not by an
/// internal detail: line width and fine counts are quantised away at the size a standard is drawn on a bracket. Pure.
function cls_standard_charges() { return ["tower", "sun", "crescent", "spear", "wheel", "skull", "trident", "key", "flame", "anvil"]; }

/// @function cls_standard_divisions()
/// @description The eight field divisions, in index order. Pure.
function cls_standard_divisions() { return ["plain", "per pale", "per fess", "per bend", "per bend sinister", "quarterly", "per saltire", "gyronny"]; }

/// @function cls_standard_ordinaries()
/// @description The six ordinaries laid across the field, in index order. Pure.
function cls_standard_ordinaries() { return ["fess", "pale", "bend", "chevron", "cross", "saltire"]; }

/// @function cls_lum(colour)
/// @description Relative luminance, 0 (black) to 1 (white), by the usual weights. This is the only number in the
/// product that answers "can a reader tell these two apart", so it is public and the suite sweeps it. Pure.
function cls_lum(_col) {
    return (0.2126 * colour_get_red(_col) + 0.7152 * colour_get_green(_col) + 0.0722 * colour_get_blue(_col)) / 255;
}

/// @function cls_standard_colours(standard)
/// @description Every colour one standard is drawn in: { field, metal, ink, band, charge, halo, dark, light }.
///
/// THE CONTRACT. cls_selftest proves all of it over every combination rather than asserting it here in prose:
///   - `field` is always a COLOUR and, on a divided field, the other half is the METAL, so the halves separate.
///   - `band` is the ordinary. On a PLAIN field there is no metal anywhere yet, so the band takes the metal - which
///     is the commonest coat of arms there is. On a divided field the metal is already present, so the band takes a
///     SECOND colour, stepped by the family: (t + 1 + family) can never be congruent to t modulo 8 for family 0..5.
///   - `charge` is always the METAL and `halo` always the ink. A device therefore BRACKETS the lightness range -
///     a bright face with a dark outline drawn all the way round it - which is the only way one device can read on
///     all four things it can sit on (a colour field, a metal field, a colour band and a metal band). Choosing the
///     face colour per backdrop was tried first and is wrong: the device is far wider than its ordinary, so it
///     always overhangs onto something the choice did not consider.
/// Returns undefined for anything that is not a standard from cls_standard.
function cls_standard_colours(_sd) {
    if (!is_struct(_sd) || !is_real(_sd[$ "tincture"]) || !is_real(_sd[$ "metal"])) return undefined;
    var _T = cls_standard_tinctures(), _M = cls_standard_metals();
    var _metal = _M[clamp(floor(_sd.metal), 0, array_length(_M) - 1)];
    var _field = _T[clamp(floor(_sd.tincture), 0, array_length(_T) - 1)];
    var _band = _T[cls_band_index(_sd)];
    var _ink = make_colour_rgb(18, 15, 13);
    return { field: _field, metal: _metal, ink: _ink, band: _band, charge: _metal, halo: _ink,
             dark: merge_colour(_metal, make_colour_rgb(0, 0, 0), 0.58),
             light: merge_colour(_metal, make_colour_rgb(255, 255, 255), 0.44) };
}

/// @function cls_band_index(standard)
/// @description Which tincture the ordinary is drawn in. Always a COLOUR, never the metal. Pure.
///
/// ⛔ It used to take the metal on a plain field, which is correct heraldry and was wrong here for a reason the
/// device sheet showed plainly: the DEVICE is the metal too, so on every plain field the band and the device were
/// literally the same colour and only the halo separated them. A second tincture instead leaves the metal doing
/// exactly one job on a standard, which is what makes a device read on any of them.
/// ⛔ Two things read this - the colours above and the blazon below. Working the same step out twice in two places
/// is how a picture and the sentence describing it drift apart, and the sentence is the one a buyer reads.
function cls_band_index(_sd) {
    var _n = array_length(cls_standard_tinctures());
    if (!is_struct(_sd) || !is_real(_sd[$ "tincture"])) return 0;
    var _ti = clamp(floor(_sd.tincture), 0, _n - 1);
    var _fam = clamp(floor(cls_num(_sd[$ "family"], 0)), 0, CLS_STANDARD_FAMILIES - 1);
    return (_ti + 1 + _fam) mod _n;
}

/// @function cls_blazon(standard)
/// @description One standard described the way a herald would, DERIVED from the same indices the drawing uses:
/// "per pale gules and or, a fess vert, a tower". "" for anything that is not a standard.
///
/// ⛔ A caption is derived, never typed. This is the only text in the product that describes a picture, so it
/// reads its field and its ordinary through cls_band_index - the function the drawing reads - rather than
/// recomputing the step and quietly disagreeing with what is on screen.
function cls_blazon(_sd) {
    if (!is_struct(_sd) || !is_real(_sd[$ "tincture"]) || !is_real(_sd[$ "metal"])) return "";
    var _T = cls_standard_tincture_names(), _M = cls_standard_metal_names();
    var _ti = clamp(floor(_sd.tincture), 0, array_length(_T) - 1);
    var _mi = clamp(floor(_sd.metal), 0, array_length(_M) - 1);
    var _div = clamp(floor(cls_num(_sd[$ "division"], 0)), 0, CLS_STANDARD_DIVISIONS - 1);
    var _ord = clamp(floor(cls_num(_sd[$ "ordinary"], 0)), 0, CLS_STANDARD_ORDINARIES - 1);
    var _ch = clamp(floor(cls_num(_sd[$ "charge"], 0)), 0, CLS_STANDARD_CHARGES - 1);
    var _field = (_div == 0) ? _T[_ti] : (cls_standard_divisions()[_div] + " " + _T[_ti] + " and " + _M[_mi]);
    return _field + ", a " + cls_standard_ordinaries()[_ord] + " " + _T[cls_band_index(_sd)] + ", a " + cls_standard_charges()[_ch];
}

// ---------------------------------------------------------------------------------------------------------------
// 2. GEOMETRY
// ---------------------------------------------------------------------------------------------------------------

/// @function cls__centroid(points)
/// @description The average of an outline's points. Enough to aim a light at and to orient an inset against; it is
/// not the area centroid and nothing here needs one. Internal. Pure.
function cls__centroid(_P) {
    var _n = array_length(_P);
    if (_n == 0) return [0, 0];
    var _sx = 0, _sy = 0;
    for (var _i = 0; _i < _n; _i++) { _sx += _P[_i][0]; _sy += _P[_i][1]; }
    return [_sx / _n, _sy / _n];
}

/// @function cls_is_convex(points)
/// @description True when an outline turns the same way at every vertex. Public because convexity is a precondition
/// of every clip and every fan in this file, and a precondition that is only written down is enforced by whoever
/// last read the prose. Pure.
function cls_is_convex(_P) {
    var _n = array_length(_P);
    if (_n < 3) return false;
    var _pos = 0, _neg = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _p = _P[_i], _q = _P[(_i + 1) mod _n], _r = _P[(_i + 2) mod _n];
        var _z = (_q[0] - _p[0]) * (_r[1] - _q[1]) - (_q[1] - _p[1]) * (_r[0] - _q[0]);
        if (_z > CLS_CLIP_EPSILON) _pos++;
        if (_z < -CLS_CLIP_EPSILON) _neg++;
    }
    return (_pos == 0 || _neg == 0);
}

/// @function cls_contains(points, x, y)
/// @description True when (x, y) is inside a CONVEX outline. Public: the suite uses it to prove that a device stays
/// inside the shield it is struck on, and that an ordinary covers the point a device sits at. Pure.
function cls_contains(_P, _x, _y) {
    var _n = array_length(_P);
    if (_n < 3) return false;
    var _pos = 0, _neg = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _p = _P[_i], _q = _P[(_i + 1) mod _n];
        var _z = (_q[0] - _p[0]) * (_y - _p[1]) - (_q[1] - _p[1]) * (_x - _p[0]);
        if (_z > CLS_CLIP_EPSILON) _pos++;
        if (_z < -CLS_CLIP_EPSILON) _neg++;
    }
    return (_pos == 0 || _neg == 0);
}

/// @function cls__clip(points, ax, ay, nx, ny)
/// @description The part of a convex outline on the positive side of the line through (ax, ay) with normal
/// (nx, ny), by Sutherland and Hodgman: every crossing inserts the real intersection point. Internal. Pure.
///
/// ⛔ NOT a filter. Keeping the points on one side and dropping the rest self-intersects on every outline whose
/// boundary crosses the line twice, which is all of them - this wing has paid for that shortcut once already.
function cls__clip(_P, _ax, _ay, _nx, _ny) {
    var _n = array_length(_P);
    if (_n < 3) return [];
    var _out = [];
    for (var _i = 0; _i < _n; _i++) {
        var _p0 = _P[_i], _p1 = _P[(_i + 1) mod _n];
        var _s0 = (_p0[0] - _ax) * _nx + (_p0[1] - _ay) * _ny;
        var _s1 = (_p1[0] - _ax) * _nx + (_p1[1] - _ay) * _ny;
        if (_s0 >= 0) array_push(_out, _p0);
        if ((_s0 >= 0) != (_s1 >= 0)) {
            var _den = _s0 - _s1;
            if (abs(_den) > CLS_CLIP_EPSILON) {
                var _t = _s0 / _den;
                array_push(_out, [_p0[0] + (_p1[0] - _p0[0]) * _t, _p0[1] + (_p1[1] - _p0[1]) * _t]);
            }
        }
    }
    return _out;
}

/// @function cls__inset(points, depth)
/// @description A convex outline moved inward by `depth` pixels on every edge, exactly: each edge becomes a
/// half-plane offset toward the centroid and the outline is clipped by all of them. Internal. Pure.
///
/// ⛔ NOT a scale about the centre. Scaling moves a far point further than a near one, so a heater shield's rim
/// would come out several times thicker at its point than along its top edge. An inset is a property of the EDGE.
/// The normal is oriented by the centroid rather than by a winding assumption, so it is correct either way round.
function cls__inset(_P, _depth) {
    var _n = array_length(_P);
    if (_n < 3 || _depth <= 0) return _P;
    var _c = cls__centroid(_P), _R = _P;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _P[_i], _b = _P[(_i + 1) mod _n];
        var _dx = _b[0] - _a[0], _dy = _b[1] - _a[1], _len = sqrt(_dx * _dx + _dy * _dy);
        if (_len < CLS_CLIP_EPSILON) continue;
        var _nx = -_dy / _len, _ny = _dx / _len;
        if ((_c[0] - _a[0]) * _nx + (_c[1] - _a[1]) * _ny < 0) { _nx = -_nx; _ny = -_ny; }
        _R = cls__clip(_R, _a[0] + _nx * _depth, _a[1] + _ny * _depth, _nx, _ny);
        if (array_length(_R) < 3) return [];
    }
    return _R;
}

/// @function cls__pie(points, cx, cy, hw, hh, wedges, offset)
/// @description A convex outline cut into `wedges` equal angular slices about (cx, cy), the first starting at
/// `offset` radians. The rays are scaled by (hw, hh) so a cut across a tall shield runs to its corners rather than
/// at a true 45 degrees. Returns an array of outlines. Internal. Pure.
///
/// This one function is all eight field divisions: 1 wedge is plain, 2 at a quarter turn is per pale, 2 at zero is
/// per fess, 2 at an eighth is per bend, 4 at zero is quarterly, 4 at an eighth is per saltire, 8 is gyronny.
function cls__pie(_P, _cx, _cy, _hw, _hh, _k, _off) {
    if (_k <= 1) return [_P];
    var _out = [];
    for (var _i = 0; _i < _k; _i++) {
        var _t0 = _off + 2 * pi * _i / _k, _t1 = _off + 2 * pi * (_i + 1) / _k;
        var _d0x = _hw * cos(_t0), _d0y = _hh * sin(_t0), _d1x = _hw * cos(_t1), _d1y = _hh * sin(_t1);
        var _R = cls__clip(_P, _cx, _cy, -_d0y, _d0x);
        _R = cls__clip(_R, _cx, _cy, _d1y, -_d1x);
        array_push(_out, _R);
    }
    return _out;
}

/// @function cls__band(points, cx, cy, dx, dy, thickness)
/// @description The strip of a convex outline within `thickness` pixels of the line through (cx, cy) along
/// (dx, dy). Internal. Pure.
/// ⛔ `thickness` is a PIXEL width while (dx, dy) is a DIRECTION, so the perpendicular is normalised here. A length
/// and a stroke width are different units and a helper that takes both will eventually be called wrong.
function cls__band(_P, _cx, _cy, _dx, _dy, _t) {
    var _len = sqrt(_dx * _dx + _dy * _dy);
    if (_len < CLS_CLIP_EPSILON || _t <= 0) return [];
    var _nx = -_dy / _len, _ny = _dx / _len, _hf = _t * 0.5;
    var _R = cls__clip(_P, _cx - _nx * _hf, _cy - _ny * _hf, _nx, _ny);
    return cls__clip(_R, _cx + _nx * _hf, _cy + _ny * _hf, -_nx, -_ny);
}

/// @function cls__fill(points, colour, alpha)
/// @description A flat convex outline. Internal.
function cls__fill(_P, _col, _a) {
    var _n = array_length(_P);
    if (_n < 3) return false;
    draw_primitive_begin(pr_trianglefan);
    for (var _i = 0; _i < _n; _i++) draw_vertex_colour(_P[_i][0], _P[_i][1], _col, _a);
    draw_primitive_end();
    return true;
}

/// @function cls__fill_lit(points, lx, ly, hi, lo, alpha)
/// @description A convex outline shaded by SURFACE NORMAL against one fixed lamp: every rim point is coloured by
/// how squarely its outward direction faces the light at the upper left, and the interior sits a little above the
/// mean. That is the whole lighting model in this product - shields, bands and devices all use it, so nothing in a
/// standard is ever lit from a different direction than anything beside it. Internal.
///
/// ⛔ (lx, ly) is the point the surface DOMES ABOUT, and for a field region it is deliberately NOT that region's
/// own centroid: passing the shield's centre makes a divided field read as one object in two colours, while each
/// half doming about itself reads as two objects lying on each other.
/// ⛔ The alpha is passed per vertex because draw_vertex_colour carries its own and ignores draw_set_alpha.
function cls__fill_lit(_P, _lx, _ly, _hi, _lo, _a) {
    var _n = array_length(_P);
    if (_n < 3) return false;
    var _Lx = -0.7071, _Ly = -0.7071;      // the lamp: upper left, the same in every product this wing ships
    draw_primitive_begin(pr_trianglefan);
    draw_vertex_colour(_lx, _ly, merge_colour(_lo, _hi, 0.66), _a);
    for (var _i = 0; _i <= _n; _i++) {
        var _p = _P[_i mod _n], _dx = _p[0] - _lx, _dy = _p[1] - _ly;
        var _len = sqrt(_dx * _dx + _dy * _dy);
        var _f = (_len < CLS_CLIP_EPSILON) ? 0.5 : clamp(0.5 + 0.5 * ((_dx / _len) * _Lx + (_dy / _len) * _Ly), 0, 1);
        draw_vertex_colour(_p[0], _p[1], merge_colour(_lo, _hi, _f), _a);
    }
    draw_primitive_end();
    return true;
}

/// @function cls__fill_strip(rails, colour, alpha)
/// @description A triangle strip between a rail pair: `rails` alternates outer point, inner point. Internal.
/// ⛔ This exists because a crescent and an annulus are CONCAVE. A triangle fan spans a concavity in silence and
/// draws a quarter moon where a crescent belongs, and no assertion about points can see a fill rule.
function cls__fill_strip(_R, _col, _a) {
    var _n = array_length(_R);
    if (_n < 4) return false;
    draw_primitive_begin(pr_trianglestrip);
    for (var _i = 0; _i < _n; _i++) draw_vertex_colour(_R[_i][0], _R[_i][1], _col, _a);
    draw_primitive_end();
    return true;
}

/// @function cls__rect_pts(x0, y0, x1, y1)
/// @description A rectangle as an outline. Internal. Pure.
function cls__rect_pts(_x0, _y0, _x1, _y1) { return [[_x0, _y0], [_x1, _y0], [_x1, _y1], [_x0, _y1]]; }

/// @function cls__disc_pts(cx, cy, rx, ry, segments)
/// @description An ellipse as an outline. Internal. Pure.
function cls__disc_pts(_cx, _cy, _rx, _ry, _seg) {
    var _P = [];
    for (var _i = 0; _i < _seg; _i++) { var _t = 2 * pi * _i / _seg; array_push(_P, [_cx + cos(_t) * _rx, _cy + sin(_t) * _ry]); }
    return _P;
}

/// @function cls__scaled(points, k)
/// @description Every point multiplied by `k`. Internal. Pure - the charge tables are authored in a unit box and
/// scaled once here, so no table entry carries a pixel number.
function cls__scaled(_P, _k) {
    var _o = array_create(array_length(_P));
    for (var _i = 0; _i < array_length(_P); _i++) _o[_i] = [_P[_i][0] * _k, _P[_i][1] * _k];
    return _o;
}

// ---------------------------------------------------------------------------------------------------------------
// 3. THE STANDARD
// ---------------------------------------------------------------------------------------------------------------

/// @function cls_standard_shapes()
/// @description The six shield silhouettes, in family order. Every one is CONVEX: a swallow-tailed banner and a
/// bouche shield were both authored and both dropped, because a notch is a concavity and every clip and fill in
/// this file has convexity as a precondition. What the six buy is a SILHOUETTE difference, which is what a reader
/// actually separates two standards by at the size a bracket draws them. Pure.
function cls_standard_shapes() { return ["heater", "iberian", "banner", "lozenge", "pennon", "cartouche"]; }

/// @function cls_standard_outline(family, cx, cy, hw, hh)
/// @description One silhouette's outline, centred on (cx, cy) inside a box of half-width `hw` and half-height `hh`.
/// Returns an array of [x, y]. Pure - the suite asserts convexity and containment on all six without drawing.
function cls_standard_outline(_fam, _cx, _cy, _hw, _hh) {
    _fam = clamp(floor(cls_num(_fam, 0)), 0, CLS_STANDARD_FAMILIES - 1);
    _hw = max(1, cls_num(_hw, 10)); _hh = max(1, cls_num(_hh, 10));
    var _P = [], _seg = CLS_BOARD_SEGMENTS;
    switch (_fam) {
        case 0:  // heater: a straight top, sides falling away to a point. The classic tournament shield.
            array_push(_P, [-1, -1], [1, -1]);
            for (var _i = 1; _i <= _seg; _i++) {
                var _t = _i / _seg, _u = 1 - _t;
                // a cubic from (1,-1) to (0,1). Both control points sit at or inside x = 1, so the edge never
                // bulges past the top corner and the outline stays convex at any sampling density.
                var _bx = _u * _u * _u + 3 * _u * _u * _t + 3 * _u * _t * _t * 0.92;
                var _by = -(_u * _u * _u) + 3 * _u * _u * _t * 0.10 + 3 * _u * _t * _t * 0.62 + _t * _t * _t;
                array_push(_P, [_bx, _by]);
            }
            for (var _i = _seg - 1; _i >= 1; _i--) {
                var _t = _i / _seg, _u = 1 - _t;
                var _bx = _u * _u * _u + 3 * _u * _u * _t + 3 * _u * _t * _t * 0.92;
                var _by = -(_u * _u * _u) + 3 * _u * _u * _t * 0.10 + 3 * _u * _t * _t * 0.62 + _t * _t * _t;
                array_push(_P, [-_bx, _by]);
            }
            break;
        case 1:  // iberian: a straight top and a half-round base
            array_push(_P, [-1, -1], [1, -1], [1, -0.06]);
            for (var _i = 1; _i < _seg; _i++) { var _t = pi * _i / _seg; array_push(_P, [cos(_t), -0.06 + sin(_t) * 1.06]); }
            array_push(_P, [-1, -0.06]);
            break;
        case 2:  // banner: a hanging rectangle, narrower than its box so it reads as cloth and not as the cell
            _P = cls__rect_pts(-0.78, -1, 0.78, 1);
            break;
        case 3:  // lozenge: a diamond
            _P = [[0, -1], [0.88, 0], [0, 1], [-0.88, 0]];
            break;
        case 4:  // pennon: a flag tapering to a point at the fly
            _P = [[-1, -0.78], [0.34, -0.78], [1, 0], [0.34, 0.78], [-1, 0.78]];
            break;
        default: // cartouche: an oval
            _P = cls__disc_pts(0, 0, 0.94, 1, _seg + 6);
            break;
    }
    var _out = array_create(array_length(_P));
    for (var _i = 0; _i < array_length(_P); _i++) _out[_i] = [_cx + _P[_i][0] * _hw, _cy + _P[_i][1] * _hh];
    return _out;
}

/// @function cls__field_regions(outline, division, cx, cy, hw, hh)
/// @description The field cut into its division, as an array of { p, m } where `m` is 0 for the tincture and 1 for
/// the metal. Internal. Pure.
function cls__field_regions(_P, _div, _cx, _cy, _hw, _hh) {
    _div = clamp(floor(cls_num(_div, 0)), 0, CLS_STANDARD_DIVISIONS - 1);
    var _K = [1, 2, 2, 2, 2, 4, 4, 8];
    var _O = [0, pi * 0.5, 0, pi * 0.25, pi * 0.75, 0, pi * 0.25, 0];
    var _W = cls__pie(_P, _cx, _cy, _hw, _hh, _K[_div], _O[_div]), _out = [];
    for (var _i = 0; _i < array_length(_W); _i++) if (array_length(_W[_i]) >= 3) array_push(_out, { p: _W[_i], m: _i mod 2 });
    return _out;
}

/// @function cls__ordinary_regions(outline, ordinary, cx, cy, hw, hh)
/// @description The ordinary as an array of outlines already clipped to the field. Internal. Pure.
///
/// ⛔ The band's thickness is PROPORTIONAL with a floor and no ceiling, and that is right here where it is wrong
/// almost everywhere else in this wing: a fess IS a third of the shield by definition, so it is a proportion OF the
/// subject rather than a physical detail laid ON it. The floor exists because a proportion under two pixels
/// rasterises to a dashed line.
/// ⛔ The chevron's arms cross ABOVE the centre, not below it. With the apex below, the centre fell in the bare
/// triangle between the arms - and the bare triangle straddles the division boundary, so the device would have sat
/// half on a colour and half on a metal with nothing deciding which. All six ordinaries now cover the centre, and
/// cls_selftest proves that with cls_contains rather than believing this comment.
function cls__ordinary_regions(_P, _ord, _cx, _cy, _hw, _hh) {
    _ord = clamp(floor(cls_num(_ord, 0)), 0, CLS_STANDARD_ORDINARIES - 1);
    var _t = max(2, min(_hw, _hh) * 0.36), _out = [], _r0 = [], _r1 = [];
    switch (_ord) {
        case 0: _r0 = cls__band(_P, _cx, _cy, 1, 0, _t); break;                          // fess
        case 1: _r0 = cls__band(_P, _cx, _cy, 0, 1, _t); break;                          // pale
        case 2: _r0 = cls__band(_P, _cx, _cy, _hw, _hh, _t); break;                      // bend
        case 3:                                                                           // chevron
            _r0 = cls__clip(cls__band(_P, _cx, _cy - _hh * 0.10, _hw, -_hh, _t), _cx, _cy, 1, 0);
            _r1 = cls__clip(cls__band(_P, _cx, _cy - _hh * 0.10, _hw, _hh, _t), _cx, _cy, -1, 0);
            break;
        case 4: _r0 = cls__band(_P, _cx, _cy, 1, 0, _t); _r1 = cls__band(_P, _cx, _cy, 0, 1, _t); break;              // cross
        default: _r0 = cls__band(_P, _cx, _cy, _hw, _hh, _t); _r1 = cls__band(_P, _cx, _cy, _hw, -_hh, _t); break;    // saltire
    }
    if (array_length(_r0) >= 3) array_push(_out, _r0);
    if (array_length(_r1) >= 3) array_push(_out, _r1);
    return _out;
}

/// @function cls_charge_parts(charge, radius)
/// @description One device as an array of parts, each { k, t, p }: `k` is "fan" for a convex outline or "strip" for
/// a rail pair, `t` is 0 for the device's own colour, 1 for its dark and 2 for its light, `p` is the points in
/// pixels about (0, 0). Public so the suite can measure every part without a surface. Pure.
///
/// ⛔ Every "fan" part here is convex and every concave form (a lune, an annulus, a swept horn) is a "strip". A
/// concave outline handed to a fan spans its own concavity and draws a different object entirely.
function cls_charge_parts(_ch, _r) {
    _ch = clamp(floor(cls_num(_ch, 0)), 0, CLS_STANDARD_CHARGES - 1);
    _r = max(1, cls_num(_r, 10));
    var _P = [];
    switch (_ch) {
        case 0:  // TOWER - a crenellated keep. Silhouette: a stepped top over a battered body.
            // ⛔ The merlons were 0.06 apart on the first bake and the crenellation read as two scratches in a
            // slab; the gate was 0.21 wide and 0.48 tall and read as a BOTTLE. A tower is recognisable by a wide
            // low gateway under a coarse-toothed top, so both are sized for that and the arrow slit is gone -
            // it merged into the gate and added a second dark mass nobody could name.
            array_push(_P, { k: "fan", t: 0, p: cls__scaled([[-0.42, -0.30], [0.42, -0.30], [0.50, 0.94], [-0.50, 0.94]], _r) });
            array_push(_P, { k: "fan", t: 0, p: cls__scaled(cls__rect_pts(-0.44, -0.84, -0.18, -0.28), _r) });
            array_push(_P, { k: "fan", t: 0, p: cls__scaled(cls__rect_pts(-0.13, -0.84, 0.13, -0.28), _r) });
            array_push(_P, { k: "fan", t: 0, p: cls__scaled(cls__rect_pts(0.18, -0.84, 0.44, -0.28), _r) });
            array_push(_P, { k: "fan", t: 2, p: cls__scaled(cls__rect_pts(-0.46, -0.08, 0.46, 0.01), _r) });
            // ⛔ The gate was half the tower's width and half its height on the second bake, which cut the body
            // into two uprights and made the device read as a HORSESHOE. A doorway is a doorway: narrow enough
            // that the wall reads as continuous around it.
            var _door = [[-0.16, 0.94], [-0.16, 0.64]];
            for (var _i = 0; _i <= 12; _i++) { var _t = pi * (1 - _i / 12); array_push(_door, [cos(_t) * 0.16, 0.64 - sin(_t) * 0.16]); }
            array_push(_door, [0.16, 0.94]);
            array_push(_P, { k: "fan", t: 1, p: cls__scaled(_door, _r) });
            break;
        case 1:  // SUN in splendour - a disc and twelve rays of two lengths
            for (var _i = 0; _i < 12; _i++) {
                var _a0 = 2 * pi * _i / 12, _sp = 0.132, _ln = (_i mod 2 == 0) ? 1.0 : 0.80;
                array_push(_P, { k: "fan", t: 0, p: cls__scaled([[cos(_a0 - _sp) * 0.42, sin(_a0 - _sp) * 0.42],
                    [cos(_a0) * _ln, sin(_a0) * _ln], [cos(_a0 + _sp) * 0.42, sin(_a0 + _sp) * 0.42]], _r) });
            }
            array_push(_P, { k: "fan", t: 0, p: cls__scaled(cls__disc_pts(0, 0, 0.47, 0.47, 30), _r) });
            array_push(_P, { k: "fan", t: 2, p: cls__scaled(cls__disc_pts(-0.08, -0.08, 0.26, 0.26, 24), _r) });
            break;
        case 2:  // CRESCENT, horns up - a lune, as a strip, because a lune is concave about every point on it
            // ⛔ `_ic` WAS +0.40 and the device baked as a BOWL: subtracting a disc BELOW centre removes the
            // bottom and leaves the top, which is a crescent with its horns pointing DOWN. The subtracted disc
            // has to sit ABOVE centre (y is down here), and the first fix also had to thin the lune - at r 0.82
            // about y 0.40 the widest part was 0.53 of the radius, which reads as a dome and not as a moon.
            var _rail = [], _ro = 0.96, _ic = -0.28, _ir = 0.87;
            for (var _i = 0; _i <= 56; _i++) {
                var _t = -pi + 2 * pi * _i / 56, _ux = cos(_t), _uy = sin(_t);
                // the inner boundary along this ray: the far intersection with the subtracted disc at (0, _ic)
                var _b = _uy * _ic, _cc = _ic * _ic - _ir * _ir, _dsc = _b * _b - _cc;
                if (_dsc <= 0) continue;
                var _tin = _b + sqrt(_dsc);
                if (_tin >= _ro) continue;              // wholly inside the subtracted disc: the gap between horns
                _tin = max(0, _tin);
                array_push(_rail, [_ux * _ro, _uy * _ro], [_ux * _tin, _uy * _tin]);
            }
            array_push(_P, { k: "strip", t: 0, p: cls__scaled(_rail, _r) });
            break;
        case 3:  // SPEAR - a leaf blade on a socketed haft
            array_push(_P, { k: "fan", t: 0, p: cls__scaled(cls__rect_pts(-0.095, 0.44, 0.095, 0.98), _r) });
            array_push(_P, { k: "fan", t: 0, p: cls__scaled(cls__rect_pts(-0.16, 0.26, 0.16, 0.50), _r) });
            array_push(_P, { k: "fan", t: 0, p: cls__scaled([[0, -0.98], [0.22, -0.52], [0.31, 0], [0.13, 0.30], [-0.13, 0.30], [-0.31, 0], [-0.22, -0.52]], _r) });
            array_push(_P, { k: "fan", t: 1, p: cls__scaled(cls__rect_pts(-0.035, -0.74, 0.035, 0.20), _r) });
            break;
        case 4:  // WHEEL - a rim, eight spokes and a hub
            var _wr = [];
            for (var _i = 0; _i <= 40; _i++) { var _t = 2 * pi * _i / 40; array_push(_wr, [cos(_t) * 0.98, sin(_t) * 0.98], [cos(_t) * 0.77, sin(_t) * 0.77]); }
            array_push(_P, { k: "strip", t: 0, p: cls__scaled(_wr, _r) });
            for (var _i = 0; _i < 8; _i++) {
                var _a0 = 2 * pi * _i / 8, _cw = 0.070, _px = -sin(_a0) * _cw, _py = cos(_a0) * _cw;
                array_push(_P, { k: "fan", t: 0, p: cls__scaled([[cos(_a0) * 0.18 + _px, sin(_a0) * 0.18 + _py], [cos(_a0) * 0.80 + _px, sin(_a0) * 0.80 + _py],
                    [cos(_a0) * 0.80 - _px, sin(_a0) * 0.80 - _py], [cos(_a0) * 0.18 - _px, sin(_a0) * 0.18 - _py]], _r) });
            }
            array_push(_P, { k: "fan", t: 0, p: cls__scaled(cls__disc_pts(0, 0, 0.26, 0.26, 24), _r) });
            array_push(_P, { k: "fan", t: 1, p: cls__scaled(cls__disc_pts(0, 0, 0.11, 0.11, 18), _r) });
            break;
        case 5:  // SKULL, horned - a cranium, a muzzle and two swept horns
            array_push(_P, { k: "fan", t: 0, p: cls__scaled(cls__disc_pts(0, -0.14, 0.46, 0.42, 26), _r) });
            array_push(_P, { k: "fan", t: 0, p: cls__scaled([[-0.27, 0.16], [0.27, 0.16], [0.19, 0.76], [-0.19, 0.76]], _r) });
            for (var _sd = -1; _sd <= 1; _sd += 2) {
                // ONE mass from a sampled spine with a tapering half-width. Three tapers end to end would bevel
                // each on its own outline and read as a chain of chevrons rather than as a horn.
                var _hr = [];
                for (var _i = 0; _i <= 14; _i++) {
                    var _t = _i / 14, _u = 1 - _t;
                    var _hx = _u * _u * (_sd * 0.40) + 2 * _u * _t * (_sd * 0.86) + _t * _t * (_sd * 0.98);
                    var _hy = _u * _u * (-0.26) + 2 * _u * _t * (-0.52) + _t * _t * (-0.96);
                    var _hwd = 0.135 * (1 - _t) + 0.012;
                    array_push(_hr, [_hx - _sd * _hwd, _hy - _hwd * 0.55], [_hx + _sd * _hwd * 0.5, _hy + _hwd * 1.05]);
                }
                array_push(_P, { k: "strip", t: 0, p: cls__scaled(_hr, _r) });
            }
            array_push(_P, { k: "fan", t: 1, p: cls__scaled(cls__disc_pts(-0.19, -0.16, 0.115, 0.135, 16), _r) });
            array_push(_P, { k: "fan", t: 1, p: cls__scaled(cls__disc_pts(0.19, -0.16, 0.115, 0.135, 16), _r) });
            array_push(_P, { k: "fan", t: 1, p: cls__scaled([[0, 0.10], [0.10, 0.34], [-0.10, 0.34]], _r) });
            break;
        case 6:  // TRIDENT - three tines on a crossbar over a haft
            array_push(_P, { k: "fan", t: 0, p: cls__scaled(cls__rect_pts(-0.085, -0.14, 0.085, 0.90), _r) });
            array_push(_P, { k: "fan", t: 0, p: cls__scaled([[-0.085, 0.86], [0.085, 0.86], [0, 1.0]], _r) });
            array_push(_P, { k: "fan", t: 0, p: cls__scaled(cls__rect_pts(-0.66, -0.26, 0.66, -0.12), _r) });
            array_push(_P, { k: "fan", t: 0, p: cls__scaled([[-0.66, -0.24], [-0.44, -0.24], [-0.51, -0.98]], _r) });
            array_push(_P, { k: "fan", t: 0, p: cls__scaled([[-0.10, -0.24], [0.10, -0.24], [0, -1.0]], _r) });
            array_push(_P, { k: "fan", t: 0, p: cls__scaled([[0.44, -0.24], [0.66, -0.24], [0.51, -0.98]], _r) });
            break;
        case 7:  // KEY - a ringed bow, a shank and two wards
            var _kb = [];
            for (var _i = 0; _i <= 34; _i++) { var _t = 2 * pi * _i / 34; array_push(_kb, [cos(_t) * 0.40, -0.56 + sin(_t) * 0.40], [cos(_t) * 0.21, -0.56 + sin(_t) * 0.21]); }
            array_push(_P, { k: "strip", t: 0, p: cls__scaled(_kb, _r) });
            array_push(_P, { k: "fan", t: 0, p: cls__scaled(cls__rect_pts(-0.09, -0.30, 0.09, 0.96), _r) });
            array_push(_P, { k: "fan", t: 0, p: cls__scaled(cls__rect_pts(0.07, 0.40, 0.50, 0.55), _r) });
            array_push(_P, { k: "fan", t: 0, p: cls__scaled(cls__rect_pts(0.07, 0.68, 0.40, 0.83), _r) });
            break;
        case 8:  // FLAME - four leaning tongues, the inner one lit, so the device has a hot core not a flat mass
            // ⛔ REBUILT. The first version was a symmetric lens between a base point and a tip point, and it
            // baked as a fleur-de-lis bud on every shield that carried it: what makes fire recognisable is a
            // LEAN and a sharp tip, and a shape symmetric about the line between its own endpoints cannot express
            // a lean at any parameter. The model was the defect, not its numbers. Each tongue is now one mass
            // swept along a curved spine with a half-width tapering to nothing at the tip - the same construction
            // as the skull's horn, which read correctly on its first bake.
            // ⛔ SECOND rebuild. Curved leaning tongues alone baked as a CROWN: three separate spikes standing on
            // a line, because each tongue ended in a flat base of its own and nothing joined them. Fire is one
            // body with tongues rising OUT of it, so the pool goes down first and every tongue is rooted inside
            // it. ⭐ The lesson is the same one the lens version taught: when a shape is wrong in a way no
            // parameter reaches, the model is wrong - and this model was wrong twice for two different reasons.
            array_push(_P, { k: "fan", t: 0, p: cls__scaled([[-0.50, 0.94], [-0.44, 0.62], [-0.18, 0.50], [0.18, 0.50], [0.44, 0.62], [0.50, 0.94]], _r) });
            for (var _g = 0; _g < 4; _g++) {
                var _BX = [0.02, -0.26, 0.30, 0.02], _BY = [0.80, 0.82, 0.82, 0.74];
                var _CX = [0.26, -0.56, 0.60, 0.18], _CY = [0.12, 0.30, 0.34, 0.24];
                var _TX = [-0.10, -0.30, 0.34, -0.04], _TY = [-1.0, -0.44, -0.34, -0.46];
                var _WD = [0.30, 0.20, 0.20, 0.14], _rail = [];
                for (var _i = 0; _i <= 16; _i++) {
                    var _t = _i / 16, _u = 1 - _t;
                    var _px = _u * _u * _BX[_g] + 2 * _u * _t * _CX[_g] + _t * _t * _TX[_g];
                    var _py = _u * _u * _BY[_g] + 2 * _u * _t * _CY[_g] + _t * _t * _TY[_g];
                    var _ddx = 2 * _u * (_CX[_g] - _BX[_g]) + 2 * _t * (_TX[_g] - _CX[_g]);
                    var _ddy = 2 * _u * (_CY[_g] - _BY[_g]) + 2 * _t * (_TY[_g] - _CY[_g]);
                    var _dl = max(CLS_CLIP_EPSILON, sqrt(_ddx * _ddx + _ddy * _ddy));
                    var _hwd = _WD[_g] * power(_u, 1.25);
                    array_push(_rail, [_px + (_ddy / _dl) * _hwd, _py - (_ddx / _dl) * _hwd],
                                      [_px - (_ddy / _dl) * _hwd, _py + (_ddx / _dl) * _hwd]);
                }
                array_push(_P, { k: "strip", t: (_g == 3) ? 2 : 0, p: cls__scaled(_rail, _r) });
            }
            break;
        default: // ANVIL - a face, a horn, a waist and a base
            array_push(_P, { k: "fan", t: 0, p: cls__scaled(cls__rect_pts(-0.84, -0.58, 0.48, -0.16), _r) });
            array_push(_P, { k: "fan", t: 0, p: cls__scaled([[0.48, -0.58], [1.0, -0.37], [0.48, -0.16]], _r) });
            array_push(_P, { k: "fan", t: 0, p: cls__scaled([[-0.30, -0.16], [0.24, -0.16], [0.32, 0.44], [-0.38, 0.44]], _r) });
            array_push(_P, { k: "fan", t: 0, p: cls__scaled([[-0.72, 0.44], [0.66, 0.44], [0.74, 0.92], [-0.80, 0.92]], _r) });
            array_push(_P, { k: "fan", t: 2, p: cls__scaled(cls__rect_pts(-0.84, -0.58, 0.48, -0.50), _r) });
            break;
    }
    return _P;
}

/// @function cls_charge_extent(parts)
/// @description The largest distance from (0, 0) any point of a device reaches. Public so the suite can prove a
/// device stays inside the shield it is struck on, which is a question about two functions and therefore one that
/// nothing inside either of them can answer. Pure.
function cls_charge_extent(_PT) {
    var _mx = 0;
    for (var _i = 0; _i < array_length(_PT); _i++) {
        var _p = _PT[_i].p;
        for (var _j = 0; _j < array_length(_p); _j++) _mx = max(_mx, sqrt(_p[_j][0] * _p[_j][0] + _p[_j][1] * _p[_j][1]));
    }
    return _mx;
}

/// @function cls__draw_parts(parts, cx, cy, colours, alpha)
/// @description Draw one device about (cx, cy): a dark OUTLINE pass under everything, then each part in its tone,
/// lit from the upper left about the DEVICE's centre rather than each part's own - a per-part dome turns a
/// four-block anvil into four separate pebbles. Internal.
///
/// ⛔ The outline pass scales each part about ITS OWN centroid, which is the opposite of the lighting rule above and
/// is right for the opposite reason: an outline is a property of a part's edge, and scaling the whole device about
/// its centre would merely translate a thin spoke outward and thicken it by a tenth of a pixel.
function cls__draw_parts(_PT, _cx, _cy, _C, _a) {
    var _n = array_length(_PT);
    if (_n == 0) return false;
    var _ext = cls_charge_extent(_PT);
    var _halo = clamp(_ext * 0.085, 1.2, 6), _bias = _halo * 0.45;
    for (var _pass = 0; _pass < 2; _pass++) {
        for (var _i = 0; _i < _n; _i++) {
            var _pt = _PT[_i], _src = _pt.p, _m = array_length(_src), _q = array_create(_m);
            if (_pass == 0) {
                var _pc = cls__centroid(_src), _mr = 0;
                for (var _j = 0; _j < _m; _j++) _mr = max(_mr, sqrt(power(_src[_j][0] - _pc[0], 2) + power(_src[_j][1] - _pc[1], 2)));
                var _s = 1 + _halo / max(1, _mr);
                for (var _j = 0; _j < _m; _j++) _q[_j] = [_cx + _pc[0] + (_src[_j][0] - _pc[0]) * _s + _bias, _cy + _pc[1] + (_src[_j][1] - _pc[1]) * _s + _bias];
                if (_pt.k == "strip") cls__fill_strip(_q, _C.halo, _a); else cls__fill(_q, _C.halo, _a);
                continue;
            }
            for (var _j = 0; _j < _m; _j++) _q[_j] = [_cx + _src[_j][0], _cy + _src[_j][1]];
            var _base = (_pt.t == 1) ? _C.dark : ((_pt.t == 2) ? _C.light : _C.charge);
            // ⛔ The device's own ramp is struck against BLACK and WHITE, not against the charge's dark and light
            // stops. Taken through those stops the darkest part of a gold device was gold dimmed by a third, and
            // on the metal half of a divided field the whole device flattened into its own backdrop. A struck
            // device has to BRACKET the lightness range on its own, because half the surfaces it can sit on are
            // the same colour it is.
            if (_pt.k == "strip") cls__fill_strip(_q, _base, _a);
            else cls__fill_lit(_q, _cx, _cy, merge_colour(_base, make_colour_rgb(255, 255, 255), 0.40),
                               merge_colour(_base, make_colour_rgb(0, 0, 0), 0.52), _a);
        }
    }
    return true;
}

/// @function cls_standard_room(family)
/// @description How much of a silhouette's smaller half-axis a device may use. A lozenge has far less room at its
/// centre than a banner, so a single fraction would either overhang a diamond or leave a rectangle mostly empty.
/// Pure - the suite proves every (family, charge) pair stays inside its own outline using this and nothing else.
function cls_standard_room(_fam) {
    var _R = [0.62, 0.62, 0.66, 0.44, 0.52, 0.60];
    return _R[clamp(floor(cls_num(_fam, 0)), 0, CLS_STANDARD_FAMILIES - 1)];
}

/// @function cls_draw_standard(x, y, width, height, standard, [alpha])
/// @description Draw one rival's standard into a box: the silhouette its family gives it, a field divided and
/// coloured from its tincture and metal, an ordinary laid across, a rim, and its device struck in the middle.
/// Returns true when it drew. Refuses a box under 8 px or over 4096, and anything that is not a standard from
/// cls_standard - a refusal is silent and returns false rather than throwing inside a buyer's draw event.
function cls_draw_standard(_x, _y, _w, _h, _sd, _a = 1) {
    if (!is_struct(_sd) || !is_real(_sd[$ "family"]) || !is_real(_sd[$ "tincture"])) return false;
    _x = cls_num(_x, 0); _y = cls_num(_y, 0); _w = cls_num(_w, 0); _h = cls_num(_h, 0); _a = clamp(cls_num(_a, 1), 0, 1);
    if (_w < 8 || _h < 8 || _w > 4096 || _h > 4096) return false;
    var _C = cls_standard_colours(_sd);
    if (_C == undefined) return false;
    var _cx = _x + _w * 0.5, _cy = _y + _h * 0.5, _hw = _w * 0.5, _hh = _h * 0.5;
    var _fam = clamp(floor(_sd.family), 0, CLS_STANDARD_FAMILIES - 1);
    var _out = cls_standard_outline(_fam, _cx, _cy, _hw, _hh);
    // the rim is a physical border: proportional going down and BOUNDED going up, because a bordure on a bracket
    // plate and the same bordure on a hero sheet are the same moulding, not a moulding scaled by the page
    var _rim = clamp(min(_hw, _hh) * 0.10, 1.5, 9);
    var _in = cls__inset(_out, _rim);
    if (array_length(_in) < 3) _in = _out;
    var _ihw = _hw - _rim, _ihh = _hh - _rim;
    // the drop shadow, then the rim itself, lit from the upper left
    var _sh = clamp(min(_hw, _hh) * 0.09, 1, 7), _shp = array_create(array_length(_out));
    for (var _i = 0; _i < array_length(_out); _i++) _shp[_i] = [_out[_i][0] + _sh, _out[_i][1] + _sh * 1.15];
    cls__fill(_shp, make_colour_rgb(0, 0, 0), _a * 0.34);
    cls__fill_lit(_out, _cx, _cy, merge_colour(_C.metal, make_colour_rgb(255, 255, 255), 0.42),
                  merge_colour(_C.metal, make_colour_rgb(0, 0, 0), 0.58), _a);
    // the field, every region domed about the SHIELD's centre so a divided field is one object in two colours
    var _F = cls__field_regions(_in, _sd[$ "division"], _cx, _cy, _ihw, _ihh);
    for (var _i = 0; _i < array_length(_F); _i++) {
        var _base = (_F[_i].m == 0) ? _C.field : _C.metal;
        cls__fill_lit(_F[_i].p, _cx, _cy, merge_colour(_base, make_colour_rgb(255, 255, 255), 0.30),
                      merge_colour(_base, make_colour_rgb(0, 0, 0), 0.42), _a);
    }
    // the ordinary, raised: its own relief is what separates it from the metal half of a divided field, where a
    // flat band of colour would still read but a flat band of metal would not
    var _O = cls__ordinary_regions(_in, _sd[$ "ordinary"], _cx, _cy, _ihw, _ihh);
    for (var _i = 0; _i < array_length(_O); _i++) {
        cls__fill_lit(_O[_i], _cx, _cy, merge_colour(_C.band, make_colour_rgb(255, 255, 255), 0.34),
                      merge_colour(_C.band, make_colour_rgb(0, 0, 0), 0.48), _a);
        var _edge = cls__inset(_O[_i], max(1, _rim * 0.34));
        if (array_length(_edge) >= 3) cls__fill(_edge, merge_colour(_C.band, make_colour_rgb(0, 0, 0), 0.16), _a * 0.85);
    }
    var _r = min(_ihw, _ihh) * cls_standard_room(_fam);
    if (_r >= 3) cls__draw_parts(cls_charge_parts(_sd[$ "charge"], _r), _cx, _cy, _C, _a);
    return true;
}

// ---------------------------------------------------------------------------------------------------------------
// 4. THE BOARD
// ---------------------------------------------------------------------------------------------------------------

/// @function cls_board_styles()
/// @description The board styles, in catalogue order. Pure.
function cls_board_styles() { return ["arena", "vellum", "night"]; }

/// @function cls_board_style(id)
/// @description { board, board_edge, plate, plate_hi, plate_lo, engrave, line, gold, dim } for a style id ("arena"
/// for anything unknown). Pure.
function cls_board_style(_id) {
    switch (_id) {
        case "vellum": return { board: make_colour_rgb(226, 213, 186), board_edge: make_colour_rgb(178, 159, 124), plate: make_colour_rgb(246, 238, 220), plate_hi: make_colour_rgb(255, 253, 246), plate_lo: make_colour_rgb(150, 132, 102), engrave: make_colour_rgb(46, 34, 26), line: make_colour_rgb(86, 68, 48), gold: make_colour_rgb(146, 38, 32), dim: make_colour_rgb(128, 114, 92) };
        case "night":  return { board: make_colour_rgb(15, 20, 32), board_edge: make_colour_rgb(5, 7, 14), plate: make_colour_rgb(38, 50, 74), plate_hi: make_colour_rgb(98, 122, 162), plate_lo: make_colour_rgb(12, 16, 28), engrave: make_colour_rgb(222, 228, 242), line: make_colour_rgb(96, 118, 158), gold: make_colour_rgb(126, 206, 236), dim: make_colour_rgb(72, 92, 124) };
    }
    return { board: make_colour_rgb(38, 28, 22), board_edge: make_colour_rgb(15, 11, 8), plate: make_colour_rgb(84, 62, 44), plate_hi: make_colour_rgb(168, 132, 88), plate_lo: make_colour_rgb(28, 20, 14), engrave: make_colour_rgb(242, 228, 200), line: make_colour_rgb(134, 104, 68), gold: make_colour_rgb(232, 186, 88), dim: make_colour_rgb(120, 100, 80) };
}

/// @function cls_board_layout(state, x, y, width, height)
/// @description Where every tie sits, worked out WITHOUT drawing anything: { x, y, w, h, head, sub, cols, colw, pw,
/// ph, ties, champ }. Each tie is { id, round, slot, cx, cy }. A round's tie sits at the mean of the two ties that
/// feed it, which is what makes a bracket look like a bracket. Returns undefined for a refusal.
///
/// This is a separate pure function because no assertion can see the picture. The suite proves the LAYOUT - every
/// plate inside the rect, no two plates in a column overlapping, each tie centred on its own feeders - and the draw
/// below is then only a question of colour.
function cls_board_layout(_st, _x, _y, _w, _h) {
    if (!cls_is_state(_st) || !_st.record.started) return undefined;
    _x = cls_num(_x, 0); _y = cls_num(_y, 0); _w = cls_num(_w, 0); _h = cls_num(_h, 0);
    if (_w < 240 || _h < 160 || _w > 16384 || _h > 16384) return undefined;
    var _rounds = max(1, _st.record.rounds);
    var _head = clamp(_h * 0.11, 30, 74), _sub = clamp(_h * 0.052, 15, 32), _m = clamp(_w * 0.018, 8, 26);
    var _cols = _rounds + 1;                                       // the champion takes the last column
    var _ix = _x + _m, _iy = _y + _head + _sub, _iw = _w - 2 * _m, _ih = _h - _head - _sub - _m;
    var _colw = _iw / _cols;
    var _n1 = max(1, array_length(cls_round_of(_st, 1)));
    var _pitch = _ih / _n1;
    // the plate is sized from the tie PITCH and capped, so a two-tie draw does not give each tie a plate half the
    // board tall. A dimension bounded only as a proportion is wrong at the top of its range.
    // ⛔ The HEIGHT grows with the round and the WIDTH does not. A bracket halves its ties every round, so a
    // constant plate height leaves the right-hand half of the board empty - the first bake wasted about a third of
    // its area on nothing, with every mechanical floor green because a full-bleed board reports no ink box. The
    // width stays fixed because the columns are fixed, and plates of differing widths break the column rhythm.
    var _ph0 = clamp(_pitch * 0.72, 26, 108), _pw = min(_colw * 0.88, 340), _phLast = _ph0;
    var _ties = [], _prev = [];
    for (var _r = 1; _r <= _rounds; _r++) {
        var _R = cls_round_of(_st, _r), _cur = [];
        var _ph = clamp(_ph0 * (1 + 0.20 * (_r - 1)), 26, min(124, _ih * 0.30));
        _phLast = _ph;
        for (var _i = 0; _i < array_length(_R); _i++) {
            var _cy = (_r == 1) ? (_iy + (_i + 0.5) * _pitch)
                                : ((array_length(_prev) > _i * 2 + 1) ? (_prev[_i * 2] + _prev[_i * 2 + 1]) * 0.5 : _iy + _ih * 0.5);
            array_push(_cur, _cy);
            array_push(_ties, { id: _R[_i].id, round: _r, slot: _R[_i].slot, cx: _ix + (_r - 0.5) * _colw, cy: _cy, pw: _pw, ph: _ph });
        }
        _prev = _cur;
    }
    return { x: _ix, y: _iy, w: _iw, h: _ih, head: _head, sub: _sub, cols: _cols, colw: _colw, pw: _pw, ph: _ph0,
             rounds: _rounds, ties: _ties,
             champ: { cx: _ix + (_cols - 0.5) * _colw, cy: _iy + _ih * 0.5, w: min(_colw * 0.94, 340), h: min(_phLast * 2.4, _ih * 0.58) } };
}

/// @function cls__plate(cx, cy, w, h, style, lit)
/// @description A struck plate: a shadow, a dark rim, a lit face. Internal.
function cls__plate(_cx, _cy, _w, _h, _S, _lit) {
    var _P = cls__rect_pts(_cx - _w * 0.5, _cy - _h * 0.5, _cx + _w * 0.5, _cy + _h * 0.5);
    var _sh = array_create(4);
    for (var _i = 0; _i < 4; _i++) _sh[_i] = [_P[_i][0] + 3, _P[_i][1] + 4];
    cls__fill(_sh, _S.board_edge, 0.42);
    cls__fill(_P, _S.plate_lo, 1);
    var _in = cls__inset(_P, max(1.5, _h * 0.055));
    if (array_length(_in) >= 3) {
        var _face = merge_colour(_S.board, _S.plate, _lit);
        cls__fill_lit(_in, _cx, _cy, merge_colour(_face, _S.plate_hi, 0.42), merge_colour(_face, _S.plate_lo, 0.42), 1);
    }
}

/// @function cls__text_fit(x, y, text, max_width, max_scale, colour, alpha)
/// @description Centred text scaled DOWN to fit a width, so a rival's name can never overrun its column. Internal.
/// ⛔ Texture filtering is turned on for the scaled draw and RESTORED afterwards. The shared atlas draws a capital
/// T's crossbar as one pixel row and nearest sampling below scale 1.0 skips it, so every "The" renders "Ihe" - and
/// forcing the filter off afterwards instead of restoring it silently unfilters everything drawn next.
function cls__text_fit(_x, _y, _s, _mw, _ms, _col, _a) {
    var _tf = gpu_get_texfilter();
    gpu_set_texfilter(true);
    draw_set_halign(fa_center); draw_set_valign(fa_middle);
    var _sc = min(_ms, _mw / max(1, string_width(_s)));
    draw_text_transformed_colour(_x, _y, _s, _sc, _sc, 0, _col, _col, _col, _col, _a);
    draw_set_halign(fa_left); draw_set_valign(fa_top);
    gpu_set_texfilter(_tf);
}

/// @function cls__text_left(x, y, text, max_width, max_scale, colour, alpha)
/// @description Left-aligned text scaled down to fit a width, vertically centred on `y`. Internal.
/// ⛔ A table's name column is LEFT aligned. Centring it inside the space between the standard and the numbers
/// left every rival's name floating in the middle of a band four times its own width, which reads as a layout
/// fault rather than as a table.
function cls__text_left(_x, _y, _s, _mw, _ms, _col, _a) {
    var _tf = gpu_get_texfilter();
    gpu_set_texfilter(true);
    draw_set_halign(fa_left); draw_set_valign(fa_middle);
    var _sc = min(_ms, _mw / max(1, string_width(_s)));
    draw_text_transformed_colour(_x, _y, _s, _sc, _sc, 0, _col, _col, _col, _col, _a);
    draw_set_valign(fa_top);
    gpu_set_texfilter(_tf);
}

/// @function cls__feed(x1, y1, x2, y2, width, colour, alpha)
/// @description The elbow that carries a winner into the next round: out, across, in. Internal.
/// ⛔ A butt-ended quad leaves a wedge of bare board on the outside of every turn, and two of them on one feed line
/// read as a broken wire. A disc of the stroke's own radius fills each join.
function cls__feed(_x1, _y1, _x2, _y2, _wd, _col, _a) {
    var _mx = (_x1 + _x2) * 0.5;
    draw_set_colour(_col); draw_set_alpha(_a);
    draw_line_width(_x1, _y1, _mx, _y1, _wd);
    draw_line_width(_mx, _y1, _mx, _y2, _wd);
    draw_line_width(_mx, _y2, _x2, _y2, _wd);
    if (_wd >= 2) { draw_circle(_mx, _y1, _wd * 0.5, false); draw_circle(_mx, _y2, _wd * 0.5, false); }
    draw_set_alpha(1);
}

/// @function cls__side(state, match, which, x, y, w, h, style)
/// @description One half of a tie: the rival's standard, its name and its score. `which` is "a" or "b". Internal.
function cls__side(_st, _m, _which, _x, _y, _w, _h, _S) {
    var _id = (_which == "a") ? _m.a : _m.b;
    var _sz = _h * 0.86, _sx = _x + _h * 0.10, _sy = _y + (_h - _sz) * 0.5;
    if (_id == "") {
        // ⛔ An empty place is a BLANK SHIELD sunk into the plate, in the plate's own metal. It was a plain dark
        // disc on the first bake and every bye row read as a hole punched through the board - a rendering fault,
        // not an empty place. A blank is the same silhouette as an occupied place, struck and left bare, which is
        // what the eye needs to see it as "nobody here yet".
        var _blank = cls_standard_outline(0, _sx + _sz * 0.5, _y + _h * 0.5, _sz * 0.40, _sz * 0.44);
        cls__fill_lit(_blank, _sx + _sz * 0.5, _y + _h * 0.5, merge_colour(_S.plate_lo, _S.plate, 0.34), _S.plate_lo, 1);
        cls__text_fit(_x + _w * 0.58, _y + _h * 0.5, _st.cfg.bye_label, _w * 0.5, 0.66, merge_colour(_S.dim, _S.engrave, 0.45), 1);
        return;
    }
    var _tm = cls_team(_st, _id);
    if (!is_struct(_tm)) return;
    var _won = (_m.played && _m.winner == _id), _lost = (_m.played && !_m.drawn && _m.winner != _id);
    // ⛔ A knocked-out rival was drawn at 0.48 and the strike-through finished the job: three quarters of a played
    // bracket became unreadable, and recording WHO WENT OUT is half of what a bracket is for. The standard dims;
    // the name stays legible and is struck through instead.
    var _al = _lost ? 0.62 : 1;
    cls_draw_standard(_sx, _sy, _sz, _sz, cls_standard(_st, _id), _al);
    // the name's box is SOLVED from the standard and the score column, never taken as a fraction of the plate, so
    // a long name can never be drawn through the number beside it
    var _tx = _sx + _sz + _h * 0.16, _tw = max(18, _x + _w - _h * 0.92 - _tx);
    var _nameCol = _lost ? merge_colour(_S.dim, _S.engrave, 0.55) : (_won ? _S.gold : _S.engrave);
    cls__text_fit(_tx + _tw * 0.5, _y + _h * 0.5, _tm.name, _tw, 0.78, _nameCol, 1);
    if (_m.played) cls__text_fit(_x + _w - _h * 0.44, _y + _h * 0.5, string((_which == "a") ? _m.score_a : _m.score_b), _h * 0.66, 0.82, _won ? _S.gold : merge_colour(_S.dim, _S.engrave, 0.45), 1);
    // ⛔ The strike is measured from the DRAWN text, not from the column: cls__text_fit centres the name and
    // scales it down only as far as it has to, so a short name in a wide column was struck through a hand's
    // width of empty plate on either side and the rule read as a divider, not as a deletion.
    if (_lost) {
        var _dw = min(_tw, string_width(_tm.name) * 0.78) * 1.06;
        draw_set_colour(_nameCol); draw_set_alpha(0.7);
        draw_line_width(_tx + (_tw - _dw) * 0.5, _y + _h * 0.5, _tx + (_tw + _dw) * 0.5, _y + _h * 0.5, max(1, _h * 0.035));
        draw_set_alpha(1);
    }
}

/// @function cls__head_band(x, y, width, height, title, style)
/// @description The struck band across the head of a board, with its title. Internal.
function cls__head_band(_x, _y, _w, _h, _title, _S) {
    cls__fill(cls__rect_pts(_x, _y, _x + _w, _y + _h), _S.plate_lo, 1);
    var _in = cls__inset(cls__rect_pts(_x, _y, _x + _w, _y + _h), max(1.5, _h * 0.11));
    if (array_length(_in) >= 3) cls__fill_lit(_in, _x + _w * 0.5, _y + _h * 0.5, merge_colour(_S.plate, _S.plate_hi, 0.40), merge_colour(_S.plate, _S.plate_lo, 0.45), 1);
    draw_set_font(fnt_colosseum_title);
    cls__text_fit(_x + _w * 0.5, _y + _h * 0.5, _title, _w * 0.66, 1.0, _S.gold, 1);
    draw_set_font(fnt_colosseum);
}

/// @function cls_board_draw(state, x, y, width, height, [style])
/// @description Draw the whole bracket into a rect: the board and its title, a round header over every column, the
/// feed lines, a plate for every tie carrying both rivals' standards, and the champion's plate. Returns the layout
/// from cls_board_layout for anything you want to draw on top, or undefined for a refusal.
function cls_board_draw(_st, _x, _y, _w, _h, _sid = "arena") {
    var _G = cls_board_layout(_st, _x, _y, _w, _h);
    if (_G == undefined) return undefined;
    var _S = cls_board_style(_sid);
    draw_rectangle_colour(_x, _y, _x + _w, _y + _h, _S.board, _S.board, merge_colour(_S.board, _S.board_edge, 0.62), merge_colour(_S.board, _S.board_edge, 0.62), false);
    var _bh = _G.head * 0.74;
    cls__head_band(_G.x, _y + (_G.head - _bh) * 0.5, _G.w, _bh, _st.cfg.title, _S);
    var _hdr = merge_colour(_S.line, _S.gold, 0.50);
    for (var _r = 1; _r <= _G.rounds; _r++)
        cls__text_fit(_G.x + (_r - 0.5) * _G.colw, _G.y - _G.sub * 0.5, cls_round_name(_st, _r), _G.colw * 0.82, 0.76, _hdr, 1);
    cls__text_fit(_G.x + (_G.cols - 0.5) * _G.colw, _G.y - _G.sub * 0.5, "Champion", _G.colw * 0.82, 0.76, _hdr, 1);
    // feed lines UNDER the plates, so a plate is never crossed by a wire
    for (var _i = 0; _i < array_length(_G.ties); _i++) {
        var _tie = _G.ties[_i], _m = cls_match(_st, _tie.id);
        if (!is_struct(_m)) continue;
        var _dx = _tie.cx + _G.colw - _G.pw * 0.5, _dy = _tie.cy;
        if (_tie.round < _G.rounds) {
            var _want = floor(_tie.slot / 2);
            for (var _j = 0; _j < array_length(_G.ties); _j++)
                if (_G.ties[_j].round == _tie.round + 1 && _G.ties[_j].slot == _want) { _dx = _G.ties[_j].cx - _G.pw * 0.5; _dy = _G.ties[_j].cy; }
        } else { _dx = _G.champ.cx - _G.champ.w * 0.5; _dy = _G.champ.cy; }
        cls__feed(_tie.cx + _G.pw * 0.5, _tie.cy, _dx, _dy, _m.played ? 3 : 2, _m.played ? _S.gold : _S.line, _m.played ? 0.95 : 0.5);
    }
    for (var _i = 0; _i < array_length(_G.ties); _i++) {
        var _tie = _G.ties[_i], _m = cls_match(_st, _tie.id);
        if (!is_struct(_m)) continue;
        cls__plate(_tie.cx, _tie.cy, _tie.pw, _tie.ph, _S, _m.played ? 1 : 0.74);
        var _px = _tie.cx - _tie.pw * 0.5, _py = _tie.cy - _tie.ph * 0.5, _rh = _tie.ph * 0.5;
        cls__side(_st, _m, "a", _px, _py, _tie.pw, _rh, _S);
        cls__side(_st, _m, "b", _px, _py + _rh, _tie.pw, _rh, _S);
        draw_set_colour(_S.plate_lo); draw_set_alpha(0.6);
        draw_line_width(_px + _tie.ph * 0.10, _tie.cy, _px + _tie.pw - _tie.ph * 0.10, _tie.cy, 1);
        draw_set_alpha(1);
    }
    cls__champion_plate(_st, _G, _S);
    return _G;
}

/// @function cls__champion_plate(state, layout, style)
/// @description The last column: the winner's standard at size over a laurel, or an empty blank while the
/// tournament is still running. Internal.
function cls__champion_plate(_st, _G, _S) {
    var _c = _G.champ, _id = cls_champion(_st), _decided = (_id != "");
    cls__plate(_c.cx, _c.cy, _c.w, _c.h, _S, _decided ? 1 : 0.64);
    var _sz = min(_c.w * 0.50, _c.h * 0.56), _sy = _c.cy - _c.h * 0.5 + _c.h * 0.10;
    // the laurel: two sprays of leaves about the standard, under it
    var _lr = _sz * 0.76;
    for (var _sd = -1; _sd <= 1; _sd += 2) for (var _i = 0; _i < 7; _i++) {
        var _t = 0.14 + 0.72 * _i / 6, _an = pi * 0.5 + _sd * (pi * 0.30 + _t * pi * 0.62);
        var _lx = _c.cx + cos(_an) * _lr, _ly = _sy + _sz * 0.5 + sin(_an) * _lr;
        var _ll = _sz * 0.22 * (1 - 0.30 * _t), _lw = _ll * 0.42;
        var _ux = cos(_an + _sd * 1.05), _uy = sin(_an + _sd * 1.05);
        cls__fill([[_lx, _ly], [_lx + _ux * _ll - _uy * _lw, _ly + _uy * _ll + _ux * _lw],
                   [_lx + _ux * _ll * 1.45, _ly + _uy * _ll * 1.45],
                   [_lx + _ux * _ll + _uy * _lw, _ly + _uy * _ll - _ux * _lw]], _decided ? _S.gold : _S.dim, _decided ? 0.9 : 0.45);
    }
    if (!_decided) {
        cls__fill(cls__disc_pts(_c.cx, _sy + _sz * 0.5, _sz * 0.38, _sz * 0.38, 26), _S.plate_lo, 0.85);
        cls__text_fit(_c.cx, _c.cy + _c.h * 0.30, "undecided", _c.w * 0.74, 0.70, _S.dim, 1);
        return;
    }
    cls_draw_standard(_c.cx - _sz * 0.5, _sy, _sz, _sz, cls_standard(_st, _id), 1);
    var _tm = cls_team(_st, _id);
    draw_set_font(fnt_colosseum_title);
    cls__text_fit(_c.cx, _c.cy + _c.h * 0.26, is_struct(_tm) ? _tm.name : _id, _c.w * 0.84, 0.86, _S.gold, 1);
    draw_set_font(fnt_colosseum);
    if (is_struct(_tm)) cls__text_fit(_c.cx, _c.cy + _c.h * 0.41, string(_tm.wins) + " won, level " + string(_tm.level), _c.w * 0.74, 0.64, _S.engrave, 1);
}

/// @function cls_table_draw(state, x, y, width, height, [style])
/// @description Draw the league table into a rect: a ruled board, a header, and a row per rival with its standard,
/// name, played, won, drawn, lost and points. Returns { x, y, w, h, rowh } or undefined for a refusal.
function cls_table_draw(_st, _x, _y, _w, _h, _sid = "arena") {
    if (!cls_is_state(_st)) return undefined;
    _x = cls_num(_x, 0); _y = cls_num(_y, 0); _w = cls_num(_w, 0); _h = cls_num(_h, 0);
    if (_w < 240 || _h < 120 || _w > 16384 || _h > 16384) return undefined;
    var _S = cls_board_style(_sid), _T = cls_standings(_st), _n = max(1, array_length(_T));
    var _head = clamp(_h * 0.11, 26, 66), _sub = clamp(_h * 0.05, 14, 30), _m = clamp(_w * 0.02, 8, 26);
    var _ix = _x + _m, _iy = _y + _head + _sub, _iw = _w - 2 * _m, _ih = _h - _head - _sub - _m;
    var _rowh = min(_ih / _n, 64);
    draw_rectangle_colour(_x, _y, _x + _w, _y + _h, _S.board, _S.board, merge_colour(_S.board, _S.board_edge, 0.62), merge_colour(_S.board, _S.board_edge, 0.62), false);
    var _bh = _head * 0.74;
    cls__head_band(_ix, _y + (_head - _bh) * 0.5, _iw, _bh, _st.cfg.title, _S);
    // the five number columns are solved from the RIGHT edge, so a long rival name can never reach them
    var _cw = clamp(_iw * 0.072, 22, 64), _numx = _ix + _iw - _cw * 4.6, _lbl = ["P", "W", "D", "L", "Pts"];
    var _hdr = merge_colour(_S.line, _S.engrave, 0.42);
    for (var _i = 0; _i < 5; _i++) cls__text_fit(_numx + _cw * _i, _iy - _sub * 0.5, _lbl[_i], _cw * 0.9, 0.70, _hdr, 1);
    cls__text_left(_ix + _rowh * 0.30, _iy - _sub * 0.5, "Rival", _rowh * 2.4, 0.70, _hdr, 1);
    for (var _i = 0; _i < array_length(_T); _i++) {
        var _row = _T[_i], _ry = _iy + _i * _rowh;
        if (_ry + _rowh > _y + _h) break;
        if (_i mod 2 == 0) { draw_set_colour(_S.plate_lo); draw_set_alpha(0.32); draw_rectangle(_ix, _ry, _ix + _iw, _ry + _rowh - 1, false); draw_set_alpha(1); }
        var _sz = _rowh * 0.80;
        cls__text_fit(_ix + _rowh * 0.32, _ry + _rowh * 0.5, string(_i + 1), _rowh * 0.46, 0.76, _hdr, 1);
        cls_draw_standard(_ix + _rowh * 0.58, _ry + (_rowh - _sz) * 0.5, _sz, _sz, cls_standard(_st, _row.id), 1);
        var _tx = _ix + _rowh * 0.58 + _sz + _rowh * 0.22, _tw = max(24, _numx - _cw * 0.6 - _tx);
        cls__text_left(_tx, _ry + _rowh * 0.5, _row.name, _tw, 0.84, (_i == 0) ? _S.gold : _S.engrave, 1);
        var _v = [_row.wins + _row.draws + _row.losses, _row.wins, _row.draws, _row.losses, _row.points];
        for (var _q = 0; _q < 5; _q++) cls__text_fit(_numx + _cw * _q, _ry + _rowh * 0.5, string(_v[_q]), _cw * 0.86, 0.78, (_q == 4) ? _S.gold : _S.engrave, 1);
        draw_set_colour(_S.plate_lo); draw_set_alpha(0.5); draw_line(_ix, _ry + _rowh, _ix + _iw, _ry + _rowh); draw_set_alpha(1);
    }
    return { x: _ix, y: _iy, w: _iw, h: _ih, rowh: _rowh };
}
