{
  "$GMScript": "v1",
  "%Name": "cls_demo",
  "name": "cls_demo",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}