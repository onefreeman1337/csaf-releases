/// cls_demo.gml - the sample field: twelve rivals for the arena, and a demo that runs a tournament.
///
/// Colosseum - Tournaments Your Game Draws, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory.
/// SESSION 1: the field, the draw and a text readout. The DRAWN board and the standards replace the readout next.

/// @function cls_demo_field()
/// @description Twelve rivals: [id, name, rating]. Ratings are spread so seeding has something to do. Pure.
function cls_demo_field() {
    return [
        ["ironjaw",   "Ironjaw of the Pits",   92],
        ["vellis",    "Vellis the Quick",      88],
        ["mourn",     "The Mourning Knight",   81],
        ["braxa",     "Braxa Redhand",         77],
        ["oren",      "Oren Two-Blades",       70],
        ["silt",      "The Silt Widow",        66],
        ["cassel",    "Cassel of Ash",         61],
        ["hollow",    "The Hollow Champion",   55],
        ["tessin",    "Tessin Greenbough",     48],
        ["garrow",    "Garrow the Bell",       41],
        ["pike",      "Pike of the Low Gate",  33],
        ["novice",    "The Nameless Novice",   12]
    ];
}

/// @function cls_demo_state([format])
/// @description A drawn tournament over the sample field. `format` is "single" or "league".
function cls_demo_state(_format = "single") {
    var _st = cls_create({ title: "The Colosseum" });
    var _F = cls_demo_field();
    for (var _i = 0; _i < array_length(_F); _i++) cls_add_team(_st, _F[_i][0], _F[_i][1], _F[_i][2]);
    cls_start(_st, _format);
    return _st;
}

/// @function cls_demo_play_one(state)
/// @description Settle the next match the way a game would: the higher rating wins, with the underdog taking it
/// when the hash says so, so a bracket is not simply the seeding read back. Returns the match id, or "".
function cls_demo_play_one(_st) {
    var _m = cls_next_match(_st);
    if (_m == undefined) return "";
    var _a = cls_team(_st, _m.a), _b = cls_team(_st, _m.b);
    if (!is_struct(_a) || !is_struct(_b)) return "";
    // an upset chance that rises as the ratings converge, drawn from the pair so a replay is identical
    var _gap = abs(_a.rating - _b.rating);
    // a league can be drawn, and two evenly matched rivals sometimes are. ⛔ Without this the demo league's
    // drawn column was twelve zeros on the store sheet - a column of zeros beside a heading that says DRAWN is a
    // feature the product has and the picture denies.
    if (_st.record.format == "league" && _gap <= 8 && cls_pick(_m.id + _a.id + _b.id, "drawn", 100) < 34) {
        cls_report(_st, _m.id, "", 1, 1);
        return _m.id;
    }
    var _upset = cls_pick(_m.id + _a.id + _b.id, "upset", 100) < max(6, 40 - _gap);
    var _fav = (_a.rating >= _b.rating) ? _a : _b;
    var _dog = (_fav == _a) ? _b : _a;
    var _win = _upset ? _dog : _fav;
    var _wa = (_win == _a);
    cls_report(_st, _m.id, _win.id, _wa ? 2 : 1, _wa ? 1 : 2);
    return _m.id;
}

/// @function cls_demo_play_all(state)
/// @description Run the whole tournament. Returns how many matches were settled.
function cls_demo_play_all(_st) {
    var _n = 0, _guard = 0;
    while (cls_next_match(_st) != undefined && _guard++ < 4096) { if (cls_demo_play_one(_st) == "") break; _n++; }
    return _n;
}

/// @function cls_demo_bar(x, y, width, height, style, text, note)
/// @description The demo's own control bar: a struck band in the board's own metal with the keys engraved on it.
/// ⛔ This exists so the demo room never shows a line of engine-default text on a flat background. A buyer who
/// presses Play is looking at the product's craft before they read a word of the Readme, and stock chrome under a
/// drawn board says the drawn board was the only part anyone cared about.
function cls_demo_bar(_x, _y, _w, _h, _sid, _text, _note) {
    var _S = cls_board_style(_sid);
    cls__fill(cls__rect_pts(_x, _y, _x + _w, _y + _h), _S.plate_lo, 1);
    var _in = cls__inset(cls__rect_pts(_x, _y, _x + _w, _y + _h), max(1.5, _h * 0.14));
    if (array_length(_in) >= 3)
        cls__fill_lit(_in, _x + _w * 0.5, _y + _h * 0.5, merge_colour(_S.plate, _S.plate_hi, 0.34), merge_colour(_S.plate, _S.plate_lo, 0.50), 1);
    draw_set_font(fnt_colosseum);
    cls__text_fit(_x + _w * 0.34, _y + _h * 0.5, _text, _w * 0.62, 0.72, _S.engrave, 1);
    cls__text_fit(_x + _w * 0.83, _y + _h * 0.5, _note, _w * 0.30, 0.72, _S.gold, 1);
    return true;
}

/// @function cls_demo_draw(state, width, height, [style])
/// @description The demo screen: the drawn bracket (or the ruled table in a league) over the whole window, with the
/// control bar across the foot. Returns true when it drew.
function cls_demo_draw(_st, _w, _h, _sid = "arena") {
    var _S = cls_board_style(_sid);
    draw_clear(_S.board_edge);
    if (!cls_is_state(_st)) return false;
    var _bar = clamp(_h * 0.072, 26, 54), _bm = clamp(_w * 0.014, 6, 20);
    if (_st.record.format == "league") cls_table_draw(_st, 0, 0, _w, _h - _bar - _bm, _sid);
    else cls_board_draw(_st, 0, 0, _w, _h - _bar - _bm, _sid);
    var _champ = cls_champion(_st);
    var _note = (_champ == "") ? (string(cls_team_count(_st)) + " entered") : ("champion: " + cls_team(_st, _champ).name);
    cls_demo_bar(_bm, _h - _bar - _bm * 0.5, _w - _bm * 2, _bar, _sid,
                 "SPACE settle the next tie    A run it out    R redraw    L single or league    S restyle", _note);
    return true;
}
