/// cls_bake.gml - renders the store sheets THROUGH THE PRODUCT'S OWN DRAW CODE (`Colosseum.exe -bake`), so the
/// listing can truthfully say every image on the page was drawn by the thing being sold.
///
/// Colosseum - Tournaments Your Game Draws, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory.
/// ⛔ The catalogue sheets are laid on a FLAT ground on purpose: the ink scan below compares against ONE colour,
/// and a gradient ground reads as ink everywhere. The board sheets are full-bleed boards by design, so their
/// containment is asserted from GEOMETRY in cls_selftest instead, because nothing in here can see a picture.

/// @function cls_bake_opaque(w, h)
/// @description Force every pixel's alpha to 1 before saving, so a sheet has no transparent ground. Internal.
function cls_bake_opaque(_w, _h) {
    gpu_set_colorwriteenable(false, false, false, true); draw_set_alpha(1);
    draw_rectangle_colour(0, 0, _w, _h, c_white, c_white, c_white, c_white, false);
    gpu_set_colorwriteenable(true, true, true, true);
}

/// @function cls_bake_ink(surface, w, h, ground)
/// @description The ink bounding box and pixel count of a finished sheet: { x0, y0, x1, y1, px, fill_x, fill_y }.
/// ⛔ Every ROW is scanned and every second column. A clipped hairline lands on ONE row, so an even-only y scan
/// walks straight past the exact shape this check exists to catch.
function cls_bake_ink(_sf, _w, _h, _ground) {
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    var _x0 = _w, _y0 = _h, _x1 = -1, _y1 = -1, _n = 0;
    var _gr = colour_get_red(_ground), _gg = colour_get_green(_ground), _gb = colour_get_blue(_ground);
    for (var _y = 0; _y < _h; _y++) for (var _x = 0; _x < _w; _x += 2) {
        var _o = (_y * _w + _x) * 4;
        if (abs(buffer_peek(_b, _o, buffer_u8) - _gr) > 10 || abs(buffer_peek(_b, _o + 1, buffer_u8) - _gg) > 10 || abs(buffer_peek(_b, _o + 2, buffer_u8) - _gb) > 10) {
            _n++;
            if (_x < _x0) _x0 = _x;
            if (_x > _x1) _x1 = _x;
            if (_y < _y0) _y0 = _y;
            if (_y > _y1) _y1 = _y;
        }
    }
    buffer_delete(_b);
    return { x0: _x0, y0: _y0, x1: _x1, y1: _y1, px: _n, fill_x: (_x1 - _x0) / _w, fill_y: (_y1 - _y0) / _h };
}

/// @function cls_bake_sheet(name, w, h, fn, [ground])
/// @description Render one sheet onto a surface, measure it, and save it. Internal.
function cls_bake_sheet(_name, _w, _h, _fn, _ground = -1) {
    var _sf = surface_create(_w, _h);
    surface_set_target(_sf); draw_clear(make_colour_rgb(16, 12, 10)); gpu_set_texfilter(true);
    var _fin = _fn(_w, _h);
    gpu_set_texfilter(false);
    var _ink = (_ground >= 0) ? cls_bake_ink(_sf, _w, _h, _ground) : undefined;
    cls_bake_opaque(_w, _h); surface_reset_target();
    surface_save(_sf, _name + ".png"); surface_free(_sf);
    array_push(global.cls_bake_log, { sheet: _name, w: _w, h: _h, drew_to: is_real(_fin) ? _fin : -1, ink: _ink });
}

/// @function cls_bake_caption(x, y, w, title, sub, style)
/// @description A sheet's head: a title and one sentence under it. Internal.
/// ⛔ Every caption colour here was raised after the first bake: the subtitle and the blazons were set at 0.16 to
/// 0.30 of the way from the board's rule colour toward its gold, and on a dark board that is barely above the
/// ground. Half the blazons on the corpus sheet were unreadable, and a caption a reader cannot read is a claim the
/// sheet does not make. No ink check can see this - a dim caption is ink exactly where ink belongs.
function cls_bake_caption(_x, _y, _w, _title, _sub, _S) {
    draw_set_font(fnt_colosseum_title);
    cls__text_fit(_x + _w * 0.5, _y + 20, _title, _w * 0.70, 1.15, merge_colour(_S.line, _S.gold, 0.88), 1);
    draw_set_font(fnt_colosseum);
    cls__text_fit(_x + _w * 0.5, _y + 56, _sub, _w * 0.76, 0.80, merge_colour(_S.engrave, _S.gold, 0.40), 1);
}

/// @function cls_bake_played(format, settled)
/// @description A demo tournament with `settled` ties already reported. Pure (no drawing).
function cls_bake_played(_format, _settled) {
    var _st = cls_demo_state(_format);
    repeat (_settled) if (cls_demo_play_one(_st) == "") break;
    return _st;
}

/// @function cls_bake_keys(n)
/// @description `n` distinct house keys for the corpus sheet. Real names rather than "key_0", because a corpus
/// sheet is a claim a buyer reads and a page of placeholders is a page of placeholders. Pure.
function cls_bake_keys(_n) {
    var _A = ["iron", "ash", "storm", "raven", "oak", "thorn", "wolf", "amber", "grey", "hollow", "red", "black",
              "gilt", "salt", "bone", "briar", "fen", "crag", "wyrm", "moon", "star", "frost", "ember", "vine"];
    var _B = ["gate", "hall", "march", "watch", "ford", "reach", "hold", "vale", "spire", "banner", "keep", "moor"];
    var _out = [];
    for (var _i = 0; _i < _n; _i++) array_push(_out, _A[_i mod array_length(_A)] + _B[floor(_i / array_length(_A)) mod array_length(_B)]);
    return _out;
}

/// @function cls_bake_corpus(w, h)
/// @description Every standard is different, on one page: a grid of houses with the blazon under each. Returns the
/// y it finished at.
/// ⛔ The count and the size of the space are BOTH derived from the macros, never typed. A sheet that prints its
/// own numbers is a better instrument than a suite, because the suite only asserts what somebody thought to ask.
function cls_bake_corpus(_w, _h) {
    var _S = cls_board_style("arena"), _bg = _S.board;
    draw_set_colour(_bg); draw_rectangle(0, 0, _w, _h, false);
    var _K = cls_bake_keys(48), _cols = 8, _rows = ceil(array_length(_K) / _cols);
    var _head = 118, _cw = _w / _cols, _ch = (_h - _head - 18) / _rows, _sz = min(_cw * 0.62, _ch * 0.60);
    var _space = CLS_STANDARD_FAMILIES * CLS_STANDARD_CHARGES * CLS_STANDARD_DIVISIONS * CLS_STANDARD_TINCTURES * CLS_STANDARD_ORDINARIES * 2;
    cls_bake_caption(0, 14, _w, "EVERY RIVAL CARRIES ITS OWN STANDARD",
        string(array_length(_K)) + " OF THEM HERE, FROM " + string(_space) + " THE PRODUCT CAN COMPOSE, ALL DRAWN IN GML", _S);
    for (var _i = 0; _i < array_length(_K); _i++) {
        var _cx = (_i mod _cols + 0.5) * _cw, _cy = _head + (floor(_i / _cols) + 0.5) * _ch;
        var _sd = cls_standard_from_key(_K[_i]);
        cls_draw_standard(_cx - _sz * 0.5, _cy - _ch * 0.13 - _sz * 0.5, _sz, _sz, _sd, 1);
        draw_set_font(fnt_colosseum);
        cls__text_fit(_cx, _cy + _ch * 0.32, string_upper(_K[_i]), _cw * 0.90, 0.72, merge_colour(_S.engrave, _S.gold, 0.60), 1);
        cls__text_fit(_cx, _cy + _ch * 0.43, cls_blazon(_sd), _cw * 0.96, 0.58, merge_colour(_S.engrave, _S.line, 0.42), 1);
    }
    return _head + _rows * _ch;
}

/// @function cls_bake_anatomy(w, h)
/// @description One standard at hero size with its parts named, and the six silhouettes beside it. Returns the
/// finish y.
function cls_bake_anatomy(_w, _h) {
    var _S = cls_board_style("arena"), _bg = _S.board;
    draw_set_colour(_bg); draw_rectangle(0, 0, _w, _h, false);
    cls_bake_caption(0, 14, _w, "FOUR CHOICES MAKE A COAT OF ARMS",
        "A SILHOUETTE, A DIVIDED FIELD, AN ORDINARY ACROSS IT AND A STRUCK DEVICE", _S);
    // the hero, chosen for a divided field and a device with a clear silhouette rather than picked at random
    var _hero = { key: "hero", family: 0, charge: 5, division: 3, tincture: 1, metal: 0, ordinary: 2, level: 6 };
    var _hs = min(_w * 0.30, _h * 0.58);
    cls_draw_standard(_w * 0.055, 132, _hs, _hs * 1.10, _hero, 1);
    draw_set_font(fnt_colosseum);
    cls__text_fit(_w * 0.055 + _hs * 0.5, 132 + _hs * 1.10 + 26, cls_blazon(_hero), _hs * 1.20, 0.74, merge_colour(_S.engrave, _S.gold, 0.66), 1);
    // the six silhouettes, each at the SAME height so the row is a comparison, captioned with its own name
    var _SH = cls_standard_shapes(), _n = array_length(_SH);
    var _rx = _w * 0.40, _rw = _w - _rx - _w * 0.05, _cw = _rw / _n, _ss = min(_cw * 0.74, _h * 0.22);
    draw_set_font(fnt_colosseum_title);
    cls__text_fit(_rx + _rw * 0.5, 150, "SIX SILHOUETTES", _rw * 0.5, 0.86, merge_colour(_S.line, _S.gold, 0.66), 1);
    draw_set_font(fnt_colosseum);
    for (var _i = 0; _i < _n; _i++) {
        var _sd = { key: "shape", family: _i, charge: (_i * 3 + 1) mod CLS_STANDARD_CHARGES, division: 5, tincture: (_i * 3) mod CLS_STANDARD_TINCTURES, metal: _i mod 2, ordinary: _i mod CLS_STANDARD_ORDINARIES, level: 1 };
        var _cx = _rx + (_i + 0.5) * _cw;
        cls_draw_standard(_cx - _ss * 0.5, 186, _ss, _ss, _sd, 1);
        cls__text_fit(_cx, 186 + _ss + 18, string_upper(_SH[_i]), _cw * 0.94, 0.66, merge_colour(_S.engrave, _S.gold, 0.55), 1);
    }
    // the eight divisions, on one silhouette so the DIVISION is the only thing that changes
    var _DV = cls_standard_divisions(), _dn = array_length(_DV), _dcw = _rw / _dn, _ds = min(_dcw * 0.76, _h * 0.17);
    var _dy = 186 + _ss + 72;
    draw_set_font(fnt_colosseum_title);
    cls__text_fit(_rx + _rw * 0.5, _dy, "EIGHT FIELD DIVISIONS", _rw * 0.56, 0.86, merge_colour(_S.line, _S.gold, 0.66), 1);
    draw_set_font(fnt_colosseum);
    for (var _i = 0; _i < _dn; _i++) {
        var _sd = { key: "div", family: 0, charge: 0, division: _i, tincture: 3, metal: 0, ordinary: 1, level: 1 };
        var _cx = _rx + (_i + 0.5) * _dcw;
        cls_draw_standard(_cx - _ds * 0.5, _dy + 28, _ds, _ds, _sd, 1);
        cls__text_fit(_cx, _dy + 28 + _ds + 16, string_upper(_DV[_i]), _dcw * 0.96, 0.60, merge_colour(_S.engrave, _S.gold, 0.55), 1);
    }
    // the six ordinaries, likewise
    var _OD = cls_standard_ordinaries(), _on = array_length(_OD), _ocw = _rw / _on, _os = min(_ocw * 0.62, _h * 0.17);
    var _oy = _dy + 28 + _ds + 64;
    draw_set_font(fnt_colosseum_title);
    cls__text_fit(_rx + _rw * 0.5, _oy, "SIX ORDINARIES", _rw * 0.44, 0.86, merge_colour(_S.line, _S.gold, 0.66), 1);
    draw_set_font(fnt_colosseum);
    for (var _i = 0; _i < _on; _i++) {
        var _sd = { key: "ord", family: 1, charge: 3, division: 2, tincture: 0, metal: 1, ordinary: _i, level: 1 };
        var _cx = _rx + (_i + 0.5) * _ocw;
        cls_draw_standard(_cx - _os * 0.5, _oy + 28, _os, _os, _sd, 1);
        cls__text_fit(_cx, _oy + 28 + _os + 16, string_upper(_OD[_i]), _ocw * 0.94, 0.62, merge_colour(_S.engrave, _S.gold, 0.55), 1);
    }
    return _oy + 28 + _os + 30;
}

/// @function cls_bake_devices(w, h)
/// @description The ten devices at size, each on the SAME field so the device is the only thing that changes.
/// Returns the finish y.
function cls_bake_devices(_w, _h) {
    var _S = cls_board_style("arena"), _bg = _S.board;
    draw_set_colour(_bg); draw_rectangle(0, 0, _w, _h, false);
    var _CH = cls_standard_charges(), _n = array_length(_CH), _cols = 5, _rows = ceil(_n / _cols);
    var _head = 118, _cw = _w / _cols, _ch = (_h - _head - 18) / _rows, _sz = min(_cw * 0.64, _ch * 0.68);
    cls_bake_caption(0, 14, _w, "TEN DEVICES, STRUCK",
        "EVERY ONE IS GEOMETRY, NOT A SPRITE, AND EVERY ONE READS BY ITS SILHOUETTE", _S);
    for (var _i = 0; _i < _n; _i++) {
        var _cx = (_i mod _cols + 0.5) * _cw, _cy = _head + (floor(_i / _cols) + 0.5) * _ch;
        var _sd = { key: "device", family: 2, charge: _i, division: 0, tincture: 3, metal: 0, ordinary: 0, level: 1 };
        cls_draw_standard(_cx - _sz * 0.5, _cy - _ch * 0.12 - _sz * 0.5, _sz, _sz * 1.06, _sd, 1);
        draw_set_font(fnt_colosseum);
        cls__text_fit(_cx, _cy + _ch * 0.34, string_upper(_CH[_i]), _cw * 0.90, 0.80, merge_colour(_S.engrave, _S.gold, 0.66), 1);
    }
    return _head + _rows * _ch;
}

/// @function cls_bake_gif(w, h, frames)
/// @description A frame sequence of the bracket filling in, one tie at a time, for the listing's animation.
function cls_bake_gif(_w, _h, _frames) {
    var _sf = surface_create(_w, _h), _st = cls_demo_state("single"), _n = 0;
    var _hold = 4;
    for (var _s = 0; _s < _frames; _s++) {
        if (_s > 0 && (_s mod _hold) == 0) cls_demo_play_one(_st);
        surface_set_target(_sf); draw_clear(make_colour_rgb(16, 12, 10)); gpu_set_texfilter(true);
        cls_demo_draw(_st, _w, _h, "arena");
        gpu_set_texfilter(false); cls_bake_opaque(_w, _h); surface_reset_target();
        // ⛔ Pad by ARITHMETIC. string_replace swaps ONE occurrence, so replacing spaces in a formatted number
        // turns "  0" into "0 0" and the frames save as "gif_0 0.png" - which ffmpeg cannot see as a sequence
        // while a glob count still reads every frame present.
        var _p = string(_n);
        while (string_length(_p) < 3) _p = "0" + _p;
        surface_save(_sf, "gif_" + _p + ".png");
        _n++;
    }
    surface_free(_sf);
}

/// @function cls_bake_all()
/// @description Every store sheet plus the GIF frames, and a log naming what each sheet measured.
function cls_bake_all() {
    global.cls_bake_log = [];
    var _arena = cls_board_style("arena");
    cls_bake_sheet("sheet_1_the_board", 1600, 900, function(_w, _h) {
        return (cls_board_draw(cls_bake_played("single", 11), 0, 0, _w, _h, "arena") != undefined) ? _h : -1;
    });
    cls_bake_sheet("sheet_2_every_standard", 1600, 1320, cls_bake_corpus, _arena.board);
    // ⛔ 760, not the 1000 this sheet was first cut at: its content finished at y=692 and the ink box read
    // fillY 0.67, which is a THIRD OF THE PAGE BLACK under a title. The sheet is cut to its content rather than
    // the floor being tuned - a bounding box cannot see the space inside itself, so no threshold would have
    // caught it and no threshold should be moved to let it pass.
    cls_bake_sheet("sheet_3_how_it_is_built", 1600, 760, cls_bake_anatomy, _arena.board);
    cls_bake_sheet("sheet_4_ten_devices", 1600, 820, cls_bake_devices, _arena.board);
    cls_bake_sheet("sheet_5_the_league_table", 1600, 900, function(_w, _h) {
        return (cls_table_draw(cls_bake_played("league", 66), 0, 0, _w, _h, "vellum") != undefined) ? _h : -1;
    });
    cls_bake_sheet("sheet_6_three_styles", 1600, 1380, function(_w, _h) {
        var _ST = cls_board_styles(), _st = cls_bake_played("single", 14);
        for (var _i = 0; _i < array_length(_ST); _i++) cls_board_draw(_st, 0, _i * 460, _w, 450, _ST[_i]);
        return 1380;
    });
    // ⛔ 56, not 72. A 12-team draw pads to 16, resolves 4 byes at the draw and leaves ELEVEN ties to settle, so
    // at a hold of 4 the bracket is finished by frame 44 - the first bake spent 28 of its 72 frames on a picture
    // that had stopped changing, which is 39% of the GIF's bytes buying nothing. The count is derived from the
    // draw, not chosen: 11 ties x 4 frames plus a hold on the champion.
    cls_bake_gif(900, 520, 56);
    var _f = file_text_open_write("cls_bake.json");
    file_text_write_string(_f, "[");
    for (var _i = 0; _i < array_length(global.cls_bake_log); _i++) {
        var _e = global.cls_bake_log[_i];
        if (_i > 0) file_text_write_string(_f, ",");
        file_text_write_string(_f, "{\"sheet\":\"" + _e.sheet + "\",\"w\":" + string(_e.w) + ",\"h\":" + string(_e.h) + ",\"drewTo\":" + string(_e.drew_to));
        if (is_struct(_e.ink)) file_text_write_string(_f, ",\"ink\":{\"x0\":" + string(_e.ink.x0) + ",\"y0\":" + string(_e.ink.y0) + ",\"x1\":" + string(_e.ink.x1) + ",\"y1\":" + string(_e.ink.y1) + ",\"px\":" + string(_e.ink.px) + ",\"fillX\":" + string(_e.ink.fill_x) + ",\"fillY\":" + string(_e.ink.fill_y) + "}");
        file_text_write_string(_f, "}");
    }
    file_text_write_string(_f, "]");
    file_text_close(_f);
}
