{
  "$GMScript": "v1",
  "%Name": "cls_bake",
  "name": "cls_bake",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}
