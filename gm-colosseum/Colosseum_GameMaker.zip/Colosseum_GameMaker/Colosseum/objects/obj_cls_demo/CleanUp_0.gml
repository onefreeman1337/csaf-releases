/// @description Nothing to free: the tournament is plain structs and arrays, and no surface is cached.
demo = undefined;
