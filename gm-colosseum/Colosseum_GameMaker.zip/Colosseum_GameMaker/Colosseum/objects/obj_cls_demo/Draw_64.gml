/// @description The drawn bracket board, or the ruled league table, plus the control bar.
if (!cls_is_state(demo)) exit;
cls_demo_draw(demo, display_get_gui_width(), display_get_gui_height(), cls_board_styles()[style_index]);
