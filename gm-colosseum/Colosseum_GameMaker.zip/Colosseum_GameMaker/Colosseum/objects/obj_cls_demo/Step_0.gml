/// @description Keys: SPACE settles the next tie, A runs the rest, R redraws, L swaps the format, S restyles.
if (!cls_is_state(demo)) exit;
if (keyboard_check_pressed(vk_space)) cls_demo_play_one(demo);
if (keyboard_check_pressed(ord("A"))) cls_demo_play_all(demo);
if (keyboard_check_pressed(ord("R"))) demo = cls_demo_state(demo.record.format);
if (keyboard_check_pressed(ord("L"))) demo = cls_demo_state((demo.record.format == "single") ? "league" : "single");
if (keyboard_check_pressed(ord("S"))) style_index = (style_index + 1) mod array_length(cls_board_styles());
