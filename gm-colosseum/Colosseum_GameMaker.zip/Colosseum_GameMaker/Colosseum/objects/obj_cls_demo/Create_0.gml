/// @description Colosseum demo - and the headless entry point (-selftest).
/// ⛔ The crash handler is installed FIRST, and every variable a later event reads is declared ABOVE the early
/// exits: Clean Up always runs, even when Create leaves early, and it must not free what was never assigned.
exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("cls_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.cls_stage) + ": " + string(_ex.message) + " | " + string(_ex.stacktrace));
    file_text_close(_f);
    game_end();
});
global.cls_stage = 0;
demo = undefined;
style_index = 0;
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";
if (string_pos("-selftest", _args) > 0) { global.cls_stage = 1; cls_selftest_write(cls_selftest_run()); game_end(); exit; }
if (string_pos("-bake", _args) > 0) { global.cls_stage = 200; cls_bake_all(); game_end(); exit; }
demo = cls_demo_state("single");
