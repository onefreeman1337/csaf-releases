# COLOSSEUM - Tournaments Your Game Draws, for GameMaker

**Your game already decides who wins a fight. This runs the tournament around it, and draws it.**

Colosseum seeds a field by rating, draws a single-elimination bracket or a round-robin league, carries winners
forward, knocks losers out, levels the rivals who keep surviving, and then **draws the whole thing** - a struck
board, a plate for every tie, inked feed lines from round to round, a laurelled champion's plate, and a ruled
league table.

And every rival carries a **standard**: a coat of arms generated from its own key.

- **the silhouette** is one of six - heater, iberian, banner, lozenge, pennon, cartouche
- **the field** is divided one of eight ways - plain, per pale, per fess, per bend, per bend sinister, quarterly,
  per saltire, gyronny - between a colour and a metal
- **an ordinary** is laid across it in a second colour - fess, pale, bend, chevron, cross or saltire
- **a device** is struck in the metal - tower, sun, crescent, spear, wheel, skull, trident, key, flame or anvil

That is **46,080 distinct coats of arms**, every one drawn from geometry at whatever size you ask for. No sprite,
no sprite sheet, no atlas, no shader, no surface kept. A rival's arms are the same on every machine and in every
save, because they are hashed from the rival's own key.

Pure GML. Built and tested on GameMaker runtime **2024.14.4.268**.

---

## Quickstart

1. **Tools > Import Local Package**, pick `Colosseum.yymps`, import everything.
2. Enter a field and draw the bracket (Create event):

```gml
my_cup = cls_create({ title: "The Colosseum" });
cls_add_team(my_cup, "ironjaw", "Ironjaw of the Pits", 92);
cls_add_team(my_cup, "vellis",  "Vellis the Quick",    88);
cls_add_team(my_cup, "mourn",   "The Mourning Knight", 81);
cls_add_team(my_cup, "braxa",   "Braxa Redhand",       77);
cls_start(my_cup, "single");        // or "league"
```

`rating` drives the seeding and **nothing else** - your game decides who actually wins. A field that is not a
power of two is padded with byes, and a first-round bye is resolved at the draw, so the board never shows a rival
playing nobody. **Nothing throws**: a duplicate id, a team with no id, a field of one, a second draw, a rival
arriving after the draw - each is kept out and reported in `cls_problems(my_cup)`, so a half-written field still
runs.

3. Ask what to play next, and tell it what happened:

```gml
var _tie = cls_next_match(my_cup);
if (_tie != undefined) {
    // ... run YOUR fight between _tie.a and _tie.b ...
    cls_report(my_cup, _tie.id, winner_id, score_a, score_b);
}
```

`cls_report` carries the winner into the next round, marks the loser out of an elimination draw, counts the
round survived, and levels the rivals who are still standing. Pass `""` as the winner in a **league** to record a
draw. It returns `false` and changes nothing for a replay, an outsider, an unknown tie, or a tie whose places are
not both filled.

4. Draw it (Draw GUI event):

```gml
cls_board_draw(my_cup, 0, 0, display_get_gui_width(), display_get_gui_height(), "arena");
```

That is the whole integration. Three styles ship - `"arena"`, `"vellum"` and `"night"` - and `cls_board_styles()`
lists them. For a league, draw the ruled table instead - the same arguments:

```gml
cls_table_draw(my_cup, 0, 0, display_get_gui_width(), display_get_gui_height(), "vellum");
```

Reading the tournament back, wherever your own UI needs it:

```gml
var _table   = cls_standings(my_cup);              // best first: points, wins, fewer losses, then id
var _winner  = cls_champion(my_cup);               // "" until it is decided
var _done    = cls_is_over(my_cup);
var _ties    = cls_round_of(my_cup, 2);            // every tie in one round, in slot order
var _name    = cls_round_name(my_cup, 2);          // "Final", "Semi-final", "Quarter-final", "Round N"
var _rival   = cls_team(my_cup, "ironjaw");        // wins, losses, draws, points, level, seed, out
var _all     = cls_matches(my_cup);                // the whole draw, in draw order
var _one     = cls_match(my_cup, "m0");            // one tie by id
var _count   = cls_team_count(my_cup);
var _seeded  = cls_seed(my_cup);                   // the field sorted by rating, seeds stamped
var _where   = cls_board_layout(my_cup, 0, 0, 1200, 700);   // every plate's position, without drawing
```

**Give the board room.** Every plate, standard and label is solved from the rect you hand it, so nothing can
overflow at any size, but a sixteen-rival draw wants about **1200 px of width** before the round-one names stop
shrinking. Below roughly 240x160 `cls_board_draw` returns `undefined` and draws nothing rather than drawing
something illegible.

---

## The standard is the part your players will look at

Every entrant's arms come from its `colour_key`, which defaults to its id. Set it and the arms are pinned, so
you can rename a rival freely:

```gml
cls_add_team(my_cup, "r_07", "The Silt Widow", 66, { colour_key: "house_silt" });
```

Draw one anywhere - a roster row, a versus screen, a banner over a gate:

```gml
cls_draw_standard(x, y, 64, 64, cls_standard(my_cup, "r_07"));
```

**A standard does not need a tournament.** `cls_standard_from_key("house_silt")` strikes arms for a guild, a
town, a faction or a player's chosen house name, with no state involved:

```gml
cls_draw_standard(x, y, 128, 128, cls_standard_from_key(player_house_name));
```

And `cls_blazon(std)` describes it the way a herald would - *"per bend azure and or, a bend vert, a skull"* -
derived from the same indices the picture is drawn from, so the words can never drift from the arms.

### How it stays readable

The device is always struck in the **metal** and outlined in a dark ink, so it brackets the lightness range and
reads on every surface it can lie on. Measured over all 768 field combinations, the smallest gap between the
metal and any colour it sits against is **0.32** in relative luminance. The one place hue alone does not separate
them is where a device overlies the metal half of a divided field; there it is separated by its relief and its
outline instead, which is why every device carries both.

---

## What you get

| Script | What is in it |
| --- | --- |
| `cls_core` | the tournament: entrants, weighted seeding, the draw, results, elimination, levelling, standings, save and load. Pure GML - no drawing, no instances, no globals. |
| `cls_board` | the drawn board, the league table, and the standard generator. |
| `cls_demo` | the twelve-rival sample field, a demo that plays itself, and the demo screen. |
| `cls_bake` | renders the store sheets through the product's own draw code. |
| `cls_selftest` | the in-engine suite, 75 assertions. |
| `obj_cls_demo`, `rm_cls_demo` | the runnable demo room. |

**Open `rm_cls_demo` and press Play.** SPACE settles the next tie, A runs the tournament out, R redraws it, L
swaps between a bracket and a league, S cycles the three styles.

### The full API

**The tournament** - `cls_create` · `cls_is_state` · `cls_add_team` · `cls_team` · `cls_teams` ·
`cls_team_count` · `cls_problems` · `cls_seed` · `cls_start` · `cls_matches` · `cls_match` · `cls_next_match` ·
`cls_report` · `cls_standings` · `cls_champion` · `cls_is_over` · `cls_round_of` · `cls_round_name` · `cls_save` ·
`cls_load` · `cls_num` · `cls_hash` · `cls_pick`

**The standard** - `cls_standard` · `cls_standard_from_key` · `cls_draw_standard` · `cls_blazon` ·
`cls_standard_colours` · `cls_band_index` · `cls_standard_shapes` · `cls_standard_charges` ·
`cls_standard_divisions` · `cls_standard_ordinaries` · `cls_standard_tinctures` · `cls_standard_tincture_names` ·
`cls_standard_metals` · `cls_standard_metal_names` · `cls_standard_outline` · `cls_standard_room` ·
`cls_charge_parts` · `cls_charge_extent` · `cls_lum` · `cls_is_convex` · `cls_contains`

**The board** - `cls_board_draw` · `cls_table_draw` · `cls_board_layout` · `cls_board_styles` · `cls_board_style`

**The demo** - `cls_demo_field` · `cls_demo_state` · `cls_demo_play_one` · `cls_demo_play_all` · `cls_demo_draw` ·
`cls_demo_bar`

Every public script carries a header block saying what it takes, what it returns and what it refuses. Every
global and macro is namespaced `cls_` / `CLS_`, so nothing here can collide with your project.

---

## Saving

```gml
var _blob = cls_save(my_cup);        // a JSON string: entrants AND the draw
cls_load(my_cup, _blob);             // true when it loaded
```

A bracket **is** the run, so the save carries both. Anything unreadable is refused and leaves your tournament
untouched rather than half-loaded.

---

## What was actually tested

- **A real Igor build**, runtime `2024.14.4.268`, exit 0, 0 errors, 0 warnings, 179 resources compiled. The gate
  was proven able to fail on this package: a deliberate syntax break took it to *"NOT CLEAN - exit 1, 2 errors"*
  naming the `cls_board` script at line 44, and the file was then restored byte-identical.
- **75 assertions, in engine, on the built executable** (`Colosseum.exe -selftest`), all passing. They cover the
  seed order's defining properties at three field sizes, the draw and its byes, elimination and levelling with a
  control, the league and its table, save and load, the six silhouettes' convexity with a control, the clip and
  the inset with controls, the colour contract over all 768 field combinations, device containment over all 60
  shield-and-device pairs with an oversized control, every ordinary covering the point its device is struck at,
  and the board layout - every plate inside its rect, no two overlapping, each tie centred on the two that feed
  it.
- **Every image on the store page was rendered by this package** (`Colosseum.exe -bake`), through the same
  `cls_board_draw`, `cls_table_draw` and `cls_draw_standard` you will call.

There is one thing the suite cannot check and this Readme will not pretend otherwise: **no assertion can see a
picture.** Every sheet was rendered and looked at, and three devices were rebuilt because of what was on the
screen rather than what a number said - the crescent was drawn upside down, the flame read first as a bud and
then as a crown, and the tower's gateway was wide enough to make it read as a horseshoe.

---

## Licence

One commercial licence, unlimited games, no attribution required. Redistributing the source as an asset is not
permitted. See `LICENSE.txt`.

**AI disclosure:** this package's code and graphics were generated with AI assistance. There are no sound
assets and no authored narrative text.

Core Systems Asset Factory
