//=============================================================================
// StatureCore.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Stature core - re-proportions a side-view battler
 * sheet to a taller body, pose by pose, at native pixels.
 * Place ABOVE Stature.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The pixel rules of Stature. No parameters or commands of its own;
 * Stature.js is the file you configure. Must be installed and listed above
 * Stature.js.
 *
 * Pure logic on RGBA pixel arrays: nothing here touches the screen.
 *
 * HOW A SHEET IS MADE TALLER. MZ's side-view sheet is 9 x 6 cells: 18
 * motions of 3 frames. Stature finds the body once, on the standing frame
 * (motion "wait", middle frame): the top and bottom of the figure, the neck
 * (the narrowest row between the head and the shoulders) and the feet. It
 * then lengthens only the band between the neck and the feet by repeating
 * whole pixel rows, spread evenly through the band. No pixel is resampled or
 * blended, so nothing blurs and no colour is invented; the head and the feet
 * are copied as they are. Every cell becomes taller by the same number of
 * rows and the figure stays on its feet, so MZ lines it up as before.
 *
 * Poses where the body is not upright follow their own rule: "dying" (on one
 * knee) and "abnormal" are lengthened by half as much, and "sleep" and "dead"
 * (lying down) are copied unchanged onto the taller cell's floor.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var StatureCore = (function () {
  'use strict';

  var COLS = 9, ROWS = 6;
  var MOTIONS = ['walk', 'wait', 'chant', 'guard', 'damage', 'evade', 'thrust', 'swing', 'missile', 'skill', 'spell', 'item', 'escape', 'victory', 'dying', 'abnormal', 'sleep', 'dead'];
  /** How much of the added height each motion takes: 1 = all of it, 0.5 = half, 0 = none (copied onto the cell's floor). */
  var RULE = { dying: 0.5, abnormal: 0.5, sleep: 0, dead: 0 };
  var ALPHA = 16;   // a pixel with alpha above this is part of the figure

  /** The cell (column, row) of a motion's frame, exactly as Sprite_Actor.updateFrame computes it (rmmz_sprites.js:817-818). */
  function cellOf(motionIndex, pattern) { return { cx: Math.floor(motionIndex / 6) * 3 + pattern, cy: motionIndex % 6 }; }
  function motionOfCell(cx, cy) { return MOTIONS[Math.floor(cx / 3) * 6 + cy]; }

  /** Opaque pixel count of one row of a cell. */
  function rowWidth(img, x0, y, cw) { var n = 0, d = img.data, W = img.width; for (var x = x0; x < x0 + cw; x++) if (d[(y * W + x) * 4 + 3] > ALPHA) n++; return n; }

  /**
   * The body of a sheet, measured once on the standing frame (motion wait, middle frame): figure top and bottom (cell
   * rows), the neck (the narrowest row in the band 30%..62% of the figure's height from its top, ties to the lower
   * row), and where the feet begin (the bottom 12% of the figure, at least 2 rows). Returns null when that frame is
   * empty (a sheet with no standing figure is left alone).
   */
  function measure(img) {
    var cw = Math.floor(img.width / COLS), ch = Math.floor(img.height / ROWS), c = cellOf(1, 1), x0 = c.cx * cw, y0 = c.cy * ch;
    var top = -1, bottom = -1, y;
    for (y = 0; y < ch; y++) if (rowWidth(img, x0, y0 + y, cw) > 0) { if (top < 0) top = y; bottom = y; }
    if (top < 0) return null;
    var H = bottom - top + 1, lo = top + Math.floor(H * 0.30), hi = top + Math.ceil(H * 0.62), neck = lo, best = Infinity;
    for (y = lo; y <= hi; y++) { var wv = rowWidth(img, x0, y0 + y, cw); if (wv > 0 && wv <= best) { best = wv; neck = y; } }
    var feet = bottom - Math.max(2, Math.round(H * 0.12)) + 1;
    return { cw: cw, ch: ch, top: top, bottom: bottom, height: H, neck: neck, feet: feet, band: Math.max(0, feet - (neck + 1)) };
  }

  /**
   * A taller copy of a whole sheet. factor 1.25 adds a quarter of the FIGURE'S height (not the cell's) to every cell, as
   * whole rows repeated through the band between the neck and the feet. Returns {width, height, data, added, spec}
   * where data is a new RGBA array; the source is never written.
   */
  function stretchSheet(img, factor) {
    var spec = measure(img), f = Math.max(1, Math.min(2, Number(factor) || 1));
    var cw = Math.floor(img.width / COLS), ch = Math.floor(img.height / ROWS);
    var add = spec && spec.band > 0 ? Math.round(spec.height * (f - 1)) : 0;
    var ch2 = ch + add, W = img.width, W2 = cw * COLS, H2 = ch2 * ROWS, out = new Uint8ClampedArray(W2 * H2 * 4), src = img.data;
    for (var cy = 0; cy < ROWS; cy++) for (var cx = 0; cx < COLS; cx++) {
      var m = motionOfCell(cx, cy), share = RULE[m] === undefined ? 1 : RULE[m], a = Math.round(add * share);
      // output row oy (0..ch2) of this cell takes source row map(oy); the cell's floor lines up (bottom-anchored)
      var pad = add - a;   // rows of empty space above the figure for a pose that grows less than the rest
      for (var oy = 0; oy < ch2; oy++) {
        var sy = mapRow(oy - pad, a, spec, ch);
        if (sy < 0) continue;
        var so = ((cy * ch + sy) * W + cx * cw) * 4, oo = ((cy * ch2 + oy) * W2 + cx * cw) * 4;
        for (var i = 0; i < cw * 4; i++) out[oo + i] = src[so + i];
      }
    }
    return { width: W2, height: H2, data: out, added: add, spec: spec, factor: f };
  }
  /**
   * Which source row an output row (in a cell grown by a rows) copies. Rows above the band copy straight across, rows
   * below it copy straight across shifted by a, and the band's L + a output rows take the band's L source rows evenly
   * (row k of the grown band copies row floor(k * L / (L + a))), so each source row appears once or twice, never blended.
   */
  function mapRow(oy, a, spec, ch) {
    if (oy < 0) return -1;
    if (!spec || a <= 0) return oy < ch ? oy : -1;
    var b0 = spec.neck + 1, L = spec.band;
    if (oy < b0) return oy;
    if (oy < b0 + L + a) return b0 + Math.floor((oy - b0) * L / (L + a));
    var sy = oy - a; return sy < ch ? sy : -1;
  }

  return { VERSION: '1.0.0', COLS: COLS, ROWS: ROWS, MOTIONS: MOTIONS, RULE: RULE, ALPHA: ALPHA, cellOf: cellOf, motionOfCell: motionOfCell, measure: measure, stretchSheet: stretchSheet, mapRow: mapRow };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = StatureCore;
