//=============================================================================
// Stature.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Stature - your own side-view battlers re-proportioned
 * to a taller body, pose by pose, at native pixels. No new art needed.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 * @base StatureCore
 * @orderAfter StatureCore
 *
 * @param defaultStature
 * @text Default stature
 * @type number
 * @decimals 2
 * @min 1
 * @max 2
 * @desc How much taller every side-view actor stands (1.25 = a quarter taller). 1 = unchanged. An actor's <Stature> tag wins.
 * @default 1.25
 *
 * @param applyTo
 * @text Apply to
 * @type select
 * @option every actor
 * @option tagged actors only
 * @desc "every actor" uses the default for anyone without a tag; "tagged actors only" leaves untagged actors as they are.
 * @default every actor
 *
 * @help
 * STATURE - taller side-view battlers from the sheets you already have.
 *
 * MZ's side-view battlers are chibi: a big head on a short body. Stature
 * reads each actor's own side-view sheet once, when it loads, and hands the
 * battle a taller copy: the body between the neck and the feet is lengthened
 * by repeating whole pixel rows, the head and the feet are left exactly as
 * they were, and all 18 motions are handled (the ones where the actor lies
 * down or kneels by their own rule). No pixel is blended, so nothing blurs.
 *
 * Your image files are never changed. Turn the plugin off and every sheet is
 * back as it was.
 *
 * INSTALL: StatureCore.js above Stature.js in the Plugin Manager.
 *
 * ACTOR NOTETAG
 *   <Stature: 1.3>   this actor stands 1.3 times as tall (1 to 2)
 *   <Stature: 1>     this actor keeps the original proportions
 *
 * The weapon an actor swings is raised with the hands, so it stays in the
 * grip. Works in battle with side-view on (Database > System 1).
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var Stature = (function () {
  'use strict';

  var NAME = 'Stature';
  var RAW = PluginManager.parameters(NAME);
  var CORE = null;
  /** ⛔ The sibling is resolved at FIRST USE, never at load time: the buyer chooses the load order (wing §8 trap 2). */
  function deps() { if (!CORE) CORE = window.StatureCore; if (!CORE) throw new Error('Stature needs StatureCore.js installed and ON in the Plugin Manager.'); return true; }
  function clamp(f) { f = Number(f); return isFinite(f) ? Math.max(1, Math.min(2, f)) : 1; }
  var P = { def: clamp(RAW.defaultStature === undefined || RAW.defaultStature === '' ? 1.25 : RAW.defaultStature), all: String(RAW.applyTo || 'every actor') !== 'tagged actors only' };

  /** How tall this actor stands: its <Stature: n> tag, else the default (or 1 when only tagged actors change). */
  function factorFor(actor) {
    var a = actor && actor.actor && actor.actor(), meta = a && a.meta;
    if (meta && meta.Stature !== undefined && meta.Stature !== true) return clamp(meta.Stature);
    return P.all ? P.def : 1;
  }

  /** Derived sheets, one per (file, stature), made once from the loaded source. */
  var CACHE = {};
  /**
   * The taller sheet for a loaded source bitmap, or null while the source is still loading. The pixel read happens
   * once per sheet here, never per frame (wing §27a). The result carries the weapon lift for the hands' new height.
   */
  function derive(src, name, f) {
    deps();
    var key = name + '|' + f; if (CACHE[key]) return CACHE[key];
    if (!src || !src.isReady() || !src.width) return null;
    var w = src.width, h = src.height, data = src.context.getImageData(0, 0, w, h).data;
    var out = CORE.stretchSheet({ width: w, height: h, data: data }, f);
    var bmp = new Bitmap(out.width, out.height);
    bmp.context.putImageData(new ImageData(out.data, out.width, out.height), 0, 0);
    bmp._baseTexture.update();
    bmp._csafStature = { added: out.added, factor: out.factor, lift: out.spec ? Math.round(out.added * 0.55) : 0, source: name };
    CACHE[key] = bmp;
    return bmp;
  }

  var _updateBitmap = Sprite_Actor.prototype.updateBitmap;
  /** After the engine picks the actor's sheet, swap in the taller copy (numbers compared, nothing allocated per frame). */
  Sprite_Actor.prototype.updateBitmap = function () {
    _updateBitmap.apply(this, arguments);
    if (!this._actor) return;
    var f = factorFor(this._actor);
    if (f <= 1) { if (this._csafStatureBmp) { this._mainSprite.bitmap = ImageManager.loadSvActor(this._battlerName); this._csafStatureBmp = null; if (this._weaponSprite) this._weaponSprite.y = 0; } return; }
    if (this._csafStatureBmp && this._csafStatureName === this._battlerName && this._csafStatureF === f) return;
    var src = ImageManager.loadSvActor(this._battlerName), d = derive(src, this._battlerName, f);
    if (!d) return;
    this._mainSprite.bitmap = d; this._csafStatureBmp = d; this._csafStatureName = this._battlerName; this._csafStatureF = f;
    if (this._weaponSprite) this._weaponSprite.y = -d._csafStature.lift;
  };

  return { VERSION: '1.0.0', P: P, deps: deps, factorFor: factorFor, derive: derive, CACHE: CACHE };
}());
