//=============================================================================
// RoundupDraw.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Round-up 2/3 - the drawing: livestock generated per round, the trough, the bell clock, the tally board.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * Everything Round-up shows over your map is drawn here at runtime with the
 * canvas: no image files are loaded. No parameters or commands of its own;
 * Roundup.js is the file you configure. Turn it on together with
 * RoundupCore.js and Roundup.js; the order does not matter.
 *
 * THE LIVESTOCK ARE GENERATED. Every animal in a round is drawn fresh from
 * the round's seed, in four facings with a three-step walk, at the size of
 * a stock character:
 *   sheep  6 fleeces (cream, white, grey, brown, black, spotted Jacob)
 *          x 4 faces (white, black, brown, speckled) x horned or polled
 *   hens   7 plumages (white, red, black, buff, speckled, laced, barred)
 *          x single or rose comb x yellow or slate legs
 *   pigs   5 coats (pink, black, ginger, saddleback, spotted)
 *          x prick or lop ears
 *   geese  3 breeds (white, grey Toulouse, brown Chinese with the knob)
 * 89 looks in all, each a little bigger or smaller than the last.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var RoundupDraw = (function () {
  'use strict';

  var FACE = '"Palatino Linotype", "Book Antiqua", Palatino, "Georgia", serif';
  var HAND = '"Segoe Print", "Bradley Hand", "Comic Sans MS", "Palatino Linotype", cursive';
  var INK = '#2b1d12', LINE = 'rgba(42,26,12,0.82)';
  var TAU = 6.283185307179586;
  function hash(s) { var h = 0x811c9dc5; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h >>> 0; }
  function rr(ctx, x, y, w, h, r) { r = Math.max(0, Math.min(r, w / 2, h / 2)); ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
  function ell(ctx, x, y, rx, ry, rot) { ctx.beginPath(); ctx.ellipse(x, y, Math.max(0.1, rx), Math.max(0.1, ry), rot || 0, 0, TAU); }
  /** #rrggbb -> [r,g,b], or null for anything malformed (wing §21c: NEVER NaN channels) */
  function hex(c) { var m = /^#([0-9a-f]{6})$/i.exec(String(c)); if (!m) return null; var n = parseInt(m[1], 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  /** Lighten (k > 0) or darken (k < 0) a #rrggbb by an absolute step (Icon_Doctrine §22e-1). A malformed colour comes back unchanged. */
  function shade(c, k) { var v = hex(c); if (!v) return c; for (var i = 0; i < 3; i++) v[i] = Math.max(0, Math.min(255, Math.round(v[i] + k))); return '#' + ((1 << 24) | (v[0] << 16) | (v[1] << 8) | v[2]).toString(16).slice(1); }
  function fitText(ctx, text, maxW, size, style, face) { ctx.font = (style || '') + ' ' + size + 'px ' + (face || FACE); while (size > 8 && ctx.measureText(text).width > maxW) { size--; ctx.font = (style || '') + ' ' + size + 'px ' + (face || FACE); } return size; }

  // ---------------------------------------------------------------------------------------------------------------
  // Looks
  // ---------------------------------------------------------------------------------------------------------------
  var SHEEP_COATS = [
    { id: 'cream', wool: '#ece2c8' }, { id: 'white', wool: '#f5f2ea' }, { id: 'grey', wool: '#b4b0a6' },
    { id: 'brown', wool: '#8c6a4a' }, { id: 'black', wool: '#433a36' }, { id: 'jacob', wool: '#efe6d2', patch: '#3e3532' },
  ];
  var SHEEP_FACES = [{ id: 'white', skin: '#eadcc6' }, { id: 'black', skin: '#2f2825' }, { id: 'brown', skin: '#7a5436' }, { id: 'speckled', skin: '#eadcc6', speck: '#2f2825' }];
  var HEN_COATS = [
    { id: 'white', body: '#f3efe4', wing: '#e2dccb' }, { id: 'red', body: '#a4522c', wing: '#7e3a1c', tail: '#2a2a2e' },
    { id: 'black', body: '#2c2c33', wing: '#24343a', tail: '#1e2a2a' }, { id: 'buff', body: '#dba65a', wing: '#c48c42' },
    { id: 'speckled', body: '#3a2e2c', wing: '#30262a', dots: '#f2ece0' }, { id: 'laced', body: '#ece4d0', wing: '#e2d8c0', lace: '#3a302c' },
    { id: 'barred', body: '#8a8a90', wing: '#76767e', bars: '#e4e4e4' },
  ];
  var PIG_COATS = [
    { id: 'pink', skin: '#eaa9a0' }, { id: 'black', skin: '#3a3338' }, { id: 'ginger', skin: '#c47640' },
    { id: 'saddleback', skin: '#3a3338', belt: '#eee4da' }, { id: 'spotted', skin: '#eaa9a0', spots: '#3a3338' },
  ];
  var GOOSE_COATS = [
    { id: 'white', body: '#f4f1ea', wing: '#e4dfd4', beak: '#e88a2a', legs: '#e88a2a' },
    { id: 'toulouse', body: '#8c8780', wing: '#6c6862', belly: '#d8d2c8', beak: '#e88a2a', legs: '#e88a2a' },
    { id: 'chinese', body: '#b09070', wing: '#8a6c50', belly: '#e8dcc8', stripe: '#5a4430', beak: '#2e2620', knob: true, legs: '#e88a2a' },
  ];
  /** how many distinct looks each species can take (the product's volume, printed in the Readme) */
  var LOOKS = { sheep: SHEEP_COATS.length * SHEEP_FACES.length * 2, hen: HEN_COATS.length * 2 * 2, pig: PIG_COATS.length * 2, goose: GOOSE_COATS.length };

  /**
   * One animal's look from the round's seed and its index: the same seed is always the same flock.
   * @param {number} seed @param {string} species @param {number} i
   */
  function lookFor(seed, species, i) {
    var h = hash('rl:' + seed + ':' + species + ':' + i), h2 = hash('r2:' + h), L = { species: species, size: 0.92 + (h2 % 17) / 100, key: '' };
    if (species === 'sheep') { L.coat = SHEEP_COATS[h % SHEEP_COATS.length]; L.face = SHEEP_FACES[(h >>> 5) % SHEEP_FACES.length]; L.horns = ((h >>> 9) & 3) === 0; L.key = L.coat.id + '/' + L.face.id + '/' + (L.horns ? 'horned' : 'polled'); }
    else if (species === 'hen') { L.coat = HEN_COATS[h % HEN_COATS.length]; L.comb = (h >>> 5) & 1 ? 'rose' : 'single'; L.legs = (h >>> 7) & 1 ? '#7c8290' : '#e2b444'; L.key = L.coat.id + '/' + L.comb + '/' + (L.legs === '#e2b444' ? 'yellow' : 'slate'); }
    else if (species === 'pig') { L.coat = PIG_COATS[h % PIG_COATS.length]; L.ears = (h >>> 5) & 1 ? 'lop' : 'prick'; L.key = L.coat.id + '/' + L.ears; }
    else { L.coat = GOOSE_COATS[h % GOOSE_COATS.length]; L.key = L.coat.id; }
    L.spotSeed = h2;
    return L;
  }
  /** every look a species can take, enumerated (for the contact sheet and the tests) */
  function allLooks(species) {
    var out = [], i;
    if (species === 'sheep') for (i = 0; i < SHEEP_COATS.length; i++) for (var j = 0; j < SHEEP_FACES.length; j++) for (var k = 0; k < 2; k++) out.push({ species: species, size: 1, coat: SHEEP_COATS[i], face: SHEEP_FACES[j], horns: !!k, key: SHEEP_COATS[i].id + '/' + SHEEP_FACES[j].id + '/' + (k ? 'horned' : 'polled'), spotSeed: i * 7 + j });
    else if (species === 'hen') for (i = 0; i < HEN_COATS.length; i++) for (var c = 0; c < 2; c++) for (var l = 0; l < 2; l++) out.push({ species: species, size: 1, coat: HEN_COATS[i], comb: c ? 'rose' : 'single', legs: l ? '#7c8290' : '#e2b444', key: HEN_COATS[i].id + '/' + (c ? 'rose' : 'single') + '/' + (l ? 'slate' : 'yellow'), spotSeed: i * 5 + c });
    else if (species === 'pig') for (i = 0; i < PIG_COATS.length; i++) for (var e = 0; e < 2; e++) out.push({ species: species, size: 1, coat: PIG_COATS[i], ears: e ? 'lop' : 'prick', key: PIG_COATS[i].id + '/' + (e ? 'lop' : 'prick'), spotSeed: i * 3 + e });
    else for (i = 0; i < GOOSE_COATS.length; i++) out.push({ species: species, size: 1, coat: GOOSE_COATS[i], key: GOOSE_COATS[i].id, spotSeed: i });
    return out;
  }

  // ---------------------------------------------------------------------------------------------------------------
  // The animals. Each is drawn about its FOOT point (0,0) in a 1-unit = 1-pixel space at 48 px tiles; the caller
  // translates and scales. Light from the upper left. dir: 2 down (facing the camera), 4 left, 6 right, 8 up (rear).
  // step: -1, 0, 1 (the walk's two strides and the stand).
  // ---------------------------------------------------------------------------------------------------------------
  function shadowOn(ctx, rx) { ctx.fillStyle = 'rgba(20,14,6,0.28)'; ell(ctx, 1, -0.5, rx, rx * 0.26); ctx.fill(); }
  function bodyShade(ctx, cx, cy, r, base) { var g = ctx.createRadialGradient(cx - r * 0.45, cy - r * 0.55, r * 0.1, cx, cy, r * 1.25); g.addColorStop(0, shade(base, 26)); g.addColorStop(0.55, base); g.addColorStop(1, shade(base, -38)); return g; }
  function leg(ctx, x, y0, len, w, col) { ctx.fillStyle = col; rr(ctx, x - w / 2, y0, w, len, w * 0.45); ctx.fill(); ctx.strokeStyle = LINE; ctx.lineWidth = 0.8; ctx.stroke(); }

  /** a fleece: a ring of puffs round an ellipse, outlined as ONE shape (the outline drawn under the fill), then curls */
  function fleece(ctx, cx, cy, rx, ry, base, L, patchFn) {
    var n = 11, i, a, px, py, pr = Math.min(rx, ry) * 0.42;
    ctx.fillStyle = LINE;
    ell(ctx, cx, cy, rx + 1, ry + 1); ctx.fill();
    for (i = 0; i < n; i++) { a = i / n * TAU; px = cx + Math.cos(a) * rx * 0.86; py = cy + Math.sin(a) * ry * 0.86; ell(ctx, px, py, pr + 1.1, pr + 1.1); ctx.fill(); }
    ctx.save(); ctx.beginPath(); ctx.ellipse(cx, cy, rx, ry, 0, 0, TAU);
    for (i = 0; i < n; i++) { a = i / n * TAU; px = cx + Math.cos(a) * rx * 0.86; py = cy + Math.sin(a) * ry * 0.86; ctx.moveTo(px + pr, py); ctx.ellipse(px, py, pr, pr, 0, 0, TAU); }
    ctx.fillStyle = bodyShade(ctx, cx, cy, Math.max(rx, ry), base); ctx.fill('nonzero'); ctx.clip('nonzero');
    if (patchFn) patchFn(ctx);
    // curls: little arcs in a darker tone, placed on a jittered lattice (a cell decides WHERE, the curl its own shape: Figure_Doctrine §26m)
    ctx.strokeStyle = shade(base, base === '#433a36' || base === '#3e3532' ? 30 : -32); ctx.lineWidth = 0.9; ctx.globalAlpha = 0.55;
    var s = L.spotSeed >>> 0;
    for (var gy = cy - ry; gy < cy + ry; gy += 3.6) for (var gx = cx - rx; gx < cx + rx; gx += 4.2) { s = (Math.imul(s, 1103515245) + 12345) >>> 0; var jx = gx + (s % 30) / 10, jy = gy + ((s >>> 8) % 25) / 10; ctx.beginPath(); ctx.arc(jx, jy, 1.3, 0.3 + (s & 7) * 0.4, 3.6 + (s & 7) * 0.4); ctx.stroke(); }
    ctx.globalAlpha = 1; ctx.restore();
  }
  function jacobPatches(L, cx, cy, rx, ry) {
    return function (ctx) { var s = L.spotSeed >>> 0; ctx.fillStyle = L.coat.patch; for (var k = 0; k < 4; k++) { s = (Math.imul(s, 1103515245) + 12345) >>> 0; ell(ctx, cx - rx * 0.7 + (s % 100) / 100 * rx * 1.4, cy - ry * 0.6 + ((s >>> 9) % 100) / 100 * ry * 1.2, 2.6 + (s & 3), 2 + ((s >>> 3) & 3), (s & 15) / 5); ctx.fill(); } };
  }
  function sheepHead(ctx, hx, hy, L, view) {
    var skin = L.face.skin;
    if (view === 'side') {
      ctx.fillStyle = skin; ctx.strokeStyle = LINE; ctx.lineWidth = 0.9;
      ell(ctx, hx + 3.2, hy - 1.8, 2.6, 1.3, -0.6); ctx.fill(); ctx.stroke();                         // ear, behind
      ctx.beginPath(); ctx.moveTo(hx + 3, hy - 3.2); ctx.quadraticCurveTo(hx - 1, hy - 4.4, hx - 4.6, hy - 1); ctx.quadraticCurveTo(hx - 5.6, hy + 1.6, hx - 3.4, hy + 2.6); ctx.quadraticCurveTo(hx + 1.6, hy + 3.6, hx + 3.6, hy + 0.6); ctx.closePath();
      ctx.fillStyle = bodyShade(ctx, hx, hy, 5, skin); ctx.fill(); ctx.stroke();
      if (L.face.speck) { ctx.fillStyle = L.face.speck; for (var k = 0; k < 5; k++) { ell(ctx, hx - 3 + k * 1.4, hy - 1 + ((k * 7) % 3), 0.55, 0.55); ctx.fill(); } }
      ctx.fillStyle = skin === '#2f2825' ? '#e8e0d0' : '#1c1410'; ell(ctx, hx - 1.4, hy - 1.2, 0.75, 0.8); ctx.fill();
      ctx.fillStyle = 'rgba(30,18,10,0.6)'; ell(ctx, hx - 4.6, hy + 0.8, 0.5, 0.45); ctx.fill();
      // a wool topknot on the poll
      ctx.fillStyle = L.coat.wool; ctx.strokeStyle = LINE; ell(ctx, hx + 1.6, hy - 3.6, 2.4, 1.6); ctx.fill(); ctx.stroke();
      // a ram's horn curls BEHIND the eye, back and down round the ear (contact sheet 2026-10-11: a ring round the eye read
      // as spectacles at product size)
      if (L.horns) { ctx.lineCap = 'round'; ctx.strokeStyle = '#6a5636'; ctx.lineWidth = 2.2; ctx.beginPath(); ctx.arc(hx + 2.9, hy - 0.2, 1.9, -2.0, 1.7); ctx.stroke(); ctx.strokeStyle = '#d4c094'; ctx.lineWidth = 1; ctx.stroke(); ctx.lineCap = 'butt'; }
      return;
    }
    // a ram's horns curl down the SIDES of the head, outside the ears, under the face (contact sheet: loops drawn over the
    // face read as spectacles)
    if (L.horns) { ctx.lineCap = 'round'; for (var hs = -1; hs <= 1; hs += 2) { ctx.strokeStyle = '#6a5636'; ctx.lineWidth = 2.2; ctx.beginPath(); ctx.arc(hx + hs * 5.2, hy - 1.2, 2, -Math.PI / 2, Math.PI / 2, hs < 0); ctx.stroke(); ctx.strokeStyle = '#d4c094'; ctx.lineWidth = 1; ctx.stroke(); } ctx.lineCap = 'butt'; }
    // front
    ctx.strokeStyle = LINE; ctx.lineWidth = 0.9; ctx.fillStyle = skin;
    ell(ctx, hx - 5, hy - 2.4, 2.8, 1.3, 0.3); ctx.fill(); ctx.stroke(); ell(ctx, hx + 5, hy - 2.4, 2.8, 1.3, -0.3); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(hx - 3.6, hy - 3.2); ctx.quadraticCurveTo(hx, hy - 5, hx + 3.6, hy - 3.2); ctx.quadraticCurveTo(hx + 3.4, hy + 3.4, hx, hy + 4.4); ctx.quadraticCurveTo(hx - 3.4, hy + 3.4, hx - 3.6, hy - 3.2); ctx.closePath();
    ctx.fillStyle = bodyShade(ctx, hx, hy, 5, skin); ctx.fill(); ctx.stroke();
    if (L.face.speck) { ctx.fillStyle = L.face.speck; for (var q = 0; q < 6; q++) { ell(ctx, hx - 2.4 + (q % 3) * 2.4, hy + (q >> 1) * 1.4 - 1, 0.5, 0.5); ctx.fill(); } }
    ctx.fillStyle = skin === '#2f2825' ? '#e8e0d0' : '#1c1410'; ell(ctx, hx - 1.7, hy - 0.6, 0.7, 0.8); ctx.fill(); ell(ctx, hx + 1.7, hy - 0.6, 0.7, 0.8); ctx.fill();
    ctx.fillStyle = 'rgba(30,18,10,0.55)'; ell(ctx, hx - 0.8, hy + 3, 0.5, 0.4); ctx.fill(); ell(ctx, hx + 0.8, hy + 3, 0.5, 0.4); ctx.fill();
    ctx.fillStyle = L.coat.wool; ctx.strokeStyle = LINE; ell(ctx, hx, hy - 4.2, 3, 1.8); ctx.fill(); ctx.stroke();
  }
  function drawSheep(ctx, L, dir, step) {
    var legC = L.face.skin === '#eadcc6' ? '#d8c8b0' : L.face.skin, bob = step ? -0.6 : 0, w = L.coat.wool;
    if (dir === 4 || dir === 6) {
      shadowOn(ctx, 14);
      leg(ctx, -7 + step * 1.6, -8, 8, 2.8, shade(legC, -18)); leg(ctx, 7 - step * 1.6, -8, 8, 2.8, shade(legC, -18));
      leg(ctx, -9 - step * 1.6, -8, 8.4, 2.8, legC); leg(ctx, 9 + step * 1.6, -8, 8.4, 2.8, legC);
      fleece(ctx, 1, -15 + bob, 11.5, 8.2, w, L, L.coat.patch ? jacobPatches(L, 1, -15, 11.5, 8.2) : null);
      ctx.fillStyle = w; ctx.strokeStyle = LINE; ctx.lineWidth = 0.9; ell(ctx, 12.4, -17 + bob, 2.2, 2.6); ctx.fill(); ctx.stroke();   // tail
      sheepHead(ctx, -11, -17 + bob, L, 'side');
    } else if (dir === 2) {
      shadowOn(ctx, 11);
      leg(ctx, -6, -8, 7.6, 2.8, shade(legC, -18)); leg(ctx, 6, -8, 7.6, 2.8, shade(legC, -18));
      leg(ctx, -3, -7 + (step > 0 ? -1 : 0), 7.6, 3, legC); leg(ctx, 3, -7 + (step < 0 ? -1 : 0), 7.6, 3, legC);
      fleece(ctx, 0, -15 + bob, 10.4, 8.6, w, L, L.coat.patch ? jacobPatches(L, 0, -15, 10.4, 8.6) : null);
      sheepHead(ctx, 0, -12 + bob, L, 'front');
    } else {
      shadowOn(ctx, 11);
      leg(ctx, -4, -7 + (step > 0 ? -1 : 0), 7.4, 3, legC); leg(ctx, 4, -7 + (step < 0 ? -1 : 0), 7.4, 3, legC);
      fleece(ctx, 0, -14.5 + bob, 10.4, 8.8, w, L, L.coat.patch ? jacobPatches(L, 0, -14.5, 10.4, 8.8) : null);
      // the dock: a soft puff low on the rump, edged in the fleece's own darker tone (an outlined ellipse read as a letter O)
      ctx.fillStyle = shade(w, -14); ctx.strokeStyle = shade(w, -48); ctx.lineWidth = 0.6; ell(ctx, 0, -9.6 + bob, 1.9, 2.3); ctx.fill(); ctx.stroke(); ctx.strokeStyle = LINE; ctx.lineWidth = 0.9;
      // ear tips over the back of the fleece
      ctx.fillStyle = L.face.skin; ell(ctx, -5.6, -22 + bob, 2.4, 1.2, 0.4); ctx.fill(); ctx.stroke(); ell(ctx, 5.6, -22 + bob, 2.4, 1.2, -0.4); ctx.fill(); ctx.stroke();
      ctx.fillStyle = w; ell(ctx, 0, -22.4 + bob, 3.2, 2); ctx.fill(); ctx.stroke();
    }
  }

  function henPattern(ctx, L, cx, cy, rx, ry) {
    var c = L.coat, s = L.spotSeed >>> 0, k;
    if (c.dots) { ctx.fillStyle = c.dots; for (k = 0; k < 14; k++) { s = (Math.imul(s, 1103515245) + 12345) >>> 0; ell(ctx, cx - rx + (s % 100) / 100 * rx * 2, cy - ry + ((s >>> 9) % 100) / 100 * ry * 2, 0.6, 0.6); ctx.fill(); } }
    if (c.lace) { ctx.strokeStyle = c.lace; ctx.lineWidth = 0.7; for (var yy = cy - ry; yy < cy + ry; yy += 2.6) for (var xx = cx - rx + ((yy * 7) % 3); xx < cx + rx; xx += 3) { ctx.beginPath(); ctx.arc(xx, yy, 1.3, 0.2, 2.9); ctx.stroke(); } }
    if (c.bars) { ctx.strokeStyle = c.bars; ctx.lineWidth = 0.9; for (var by = cy - ry; by < cy + ry; by += 2.2) { ctx.beginPath(); ctx.moveTo(cx - rx, by); ctx.lineTo(cx + rx, by + 0.8); ctx.stroke(); } }
  }
  function comb(ctx, hx, hy, L, side) {
    ctx.fillStyle = '#c8282a'; ctx.strokeStyle = 'rgba(80,10,10,0.8)'; ctx.lineWidth = 0.6;
    if (L.comb === 'rose') { ell(ctx, hx + (side ? 0.6 : 0), hy - 2.6, 1.9, 0.9); ctx.fill(); ctx.stroke(); return; }
    for (var k = -1; k <= 1; k++) { ell(ctx, hx + k * 1.2 * (side ? 1 : 0.8) + (side ? 0.4 : 0), hy - 2.8 - (k === 0 ? 0.5 : 0), 0.85, 1.25); ctx.fill(); ctx.stroke(); }
  }
  function drawHen(ctx, L, dir, step) {
    var c = L.coat, bob = step ? -0.5 : 0, lg = L.legs;
    ctx.lineCap = 'round';
    if (dir === 4 || dir === 6) {
      shadowOn(ctx, 7);
      ctx.strokeStyle = lg; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(-1, -5); ctx.lineTo(-1.6 + step * 1.6, 0); ctx.moveTo(1.6, -5); ctx.lineTo(1.4 - step * 1.6, 0); ctx.stroke();
      // tail feathers, then the body, then the wing
      ctx.fillStyle = c.tail || shade(c.body, -18); ctx.strokeStyle = LINE; ctx.lineWidth = 0.8;
      ctx.beginPath(); ctx.moveTo(4, -9 + bob); ctx.quadraticCurveTo(9, -17 + bob, 8.4, -14 + bob); ctx.quadraticCurveTo(10.4, -11 + bob, 6, -6 + bob); ctx.closePath(); ctx.fill(); ctx.stroke();
      ell(ctx, 0.4, -8.6 + bob, 6.6, 5); ctx.fillStyle = bodyShade(ctx, 0, -9, 7, c.body); ctx.fill(); ctx.stroke();
      ctx.save(); ell(ctx, 0.4, -8.6 + bob, 6.6, 5); ctx.clip(); henPattern(ctx, L, 0.4, -8.6 + bob, 6.6, 5); ctx.restore();
      ctx.fillStyle = c.wing; ell(ctx, 1.6, -8.2 + bob, 3.8, 2.6, 0.25); ctx.fill(); ctx.stroke();
      // head and neck
      ctx.fillStyle = bodyShade(ctx, -5, -13, 3.4, c.body); ell(ctx, -5.2, -12.8 + bob, 2.8, 2.9); ctx.fill(); ctx.stroke();
      comb(ctx, -5.4, -13.2 + bob, L, true);
      ctx.fillStyle = '#e8b13a'; ctx.beginPath(); ctx.moveTo(-7.8, -13.4 + bob); ctx.lineTo(-9.6, -12.6 + bob); ctx.lineTo(-7.8, -12 + bob); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#c8282a'; ell(ctx, -7.2, -10.6 + bob, 0.8, 1.1); ctx.fill();
      ctx.fillStyle = '#1c1410'; ell(ctx, -6, -13.4 + bob, 0.55, 0.6); ctx.fill();
    } else if (dir === 2) {
      shadowOn(ctx, 6);
      ctx.strokeStyle = lg; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(-1.8, -4); ctx.lineTo(-1.8, step > 0 ? -1 : 0); ctx.moveTo(1.8, -4); ctx.lineTo(1.8, step < 0 ? -1 : 0); ctx.stroke();
      ctx.strokeStyle = LINE; ctx.lineWidth = 0.8;
      ctx.fillStyle = c.tail || shade(c.body, -18); ell(ctx, 0, -12 + bob, 3.6, 3.6); ctx.fill(); ctx.stroke();
      ell(ctx, 0, -8 + bob, 5.6, 5); ctx.fillStyle = bodyShade(ctx, 0, -8, 6, c.body); ctx.fill(); ctx.stroke();
      ctx.save(); ell(ctx, 0, -8 + bob, 5.6, 5); ctx.clip(); henPattern(ctx, L, 0, -8 + bob, 5.6, 5); ctx.restore();
      ctx.fillStyle = c.wing; ell(ctx, -4.6, -8 + bob, 1.6, 3.2, 0.2); ctx.fill(); ctx.stroke(); ell(ctx, 4.6, -8 + bob, 1.6, 3.2, -0.2); ctx.fill(); ctx.stroke();
      ctx.fillStyle = bodyShade(ctx, 0, -14, 3.4, c.body); ell(ctx, 0, -13.4 + bob, 2.8, 2.8); ctx.fill(); ctx.stroke();
      comb(ctx, 0, -14 + bob, L, false);
      ctx.fillStyle = '#e8b13a'; ctx.beginPath(); ctx.moveTo(-0.9, -12.8 + bob); ctx.lineTo(0.9, -12.8 + bob); ctx.lineTo(0, -11 + bob); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#c8282a'; ell(ctx, -0.6, -10.6 + bob, 0.6, 0.9); ctx.fill(); ell(ctx, 0.6, -10.6 + bob, 0.6, 0.9); ctx.fill();
      ctx.fillStyle = '#1c1410'; ell(ctx, -1.3, -13.8 + bob, 0.5, 0.55); ctx.fill(); ell(ctx, 1.3, -13.8 + bob, 0.5, 0.55); ctx.fill();
    } else {
      shadowOn(ctx, 6);
      ctx.strokeStyle = lg; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(-1.8, -4); ctx.lineTo(-1.8, step > 0 ? -1 : 0); ctx.moveTo(1.8, -4); ctx.lineTo(1.8, step < 0 ? -1 : 0); ctx.stroke();
      ctx.strokeStyle = LINE; ctx.lineWidth = 0.8;
      ctx.fillStyle = bodyShade(ctx, 0, -13, 3.4, c.body); ell(ctx, 0, -13.6 + bob, 2.6, 2.6); ctx.fill(); ctx.stroke(); comb(ctx, 0, -14.2 + bob, L, false);
      ell(ctx, 0, -8 + bob, 5.6, 5); ctx.fillStyle = bodyShade(ctx, 0, -8, 6, c.body); ctx.fill(); ctx.stroke();
      ctx.save(); ell(ctx, 0, -8 + bob, 5.6, 5); ctx.clip(); henPattern(ctx, L, 0, -8 + bob, 5.6, 5); ctx.restore();
      // the tail from behind: a fan of three feathers rising off the back (contact sheet: an outlined triangle read as a sign)
      ctx.fillStyle = c.tail || shade(c.body, -18); ctx.strokeStyle = shade(c.tail || c.body, -46); ctx.lineWidth = 0.6;
      for (var tf = -1; tf <= 1; tf++) { ell(ctx, tf * 1.9, -12.4 + bob - (tf ? 0 : 0.8), 1.5, 3.6, tf * 0.42); ctx.fill(); ctx.stroke(); }
      ctx.strokeStyle = LINE; ctx.lineWidth = 0.8;
    }
    ctx.lineCap = 'butt';
  }

  function pigMarks(ctx, L, cx, cy, rx, ry, view) {
    var c = L.coat, s = L.spotSeed >>> 0;
    if (c.belt) { ctx.fillStyle = c.belt; if (view === 'side') ctx.fillRect(cx - rx * 0.55, cy - ry - 1, rx * 0.42, ry * 2 + 2); else if (view === 'front') ctx.fillRect(cx - rx - 1, cy - ry * 0.35, rx * 2 + 2, ry * 0.45); }
    if (c.spots) { ctx.fillStyle = c.spots; for (var k = 0; k < 4; k++) { s = (Math.imul(s, 1103515245) + 12345) >>> 0; ell(ctx, cx - rx * 0.6 + (s % 100) / 100 * rx * 1.2, cy - ry * 0.5 + ((s >>> 9) % 100) / 100 * ry, 2 + (s & 3) * 0.6, 1.6 + ((s >>> 4) & 3) * 0.5, (s & 7) * 0.4); ctx.fill(); } }
  }
  function pigEar(ctx, x, y, L, side, flip) {
    ctx.fillStyle = shade(L.coat.skin, -14); ctx.strokeStyle = LINE; ctx.lineWidth = 0.8; ctx.beginPath();
    if (L.ears === 'lop') { ctx.moveTo(x - 1.6 * flip, y); ctx.quadraticCurveTo(x - 3.6 * flip, y + 2, x - (side ? 3.6 : 2.4) * flip, y + 4); ctx.lineTo(x + 1.4 * flip, y + 1.2); }
    else { ctx.moveTo(x - 1.8 * flip, y + 0.6); ctx.lineTo(x - 0.6 * flip, y - 4); ctx.lineTo(x + 1.8 * flip, y + 0.4); }
    ctx.closePath(); ctx.fill(); ctx.stroke();
  }
  function curlTail(ctx, x, y, col) { ctx.strokeStyle = shade(col, -26); ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(x, y); ctx.bezierCurveTo(x + 3, y - 1, x + 3, y - 4, x + 1, y - 3.6); ctx.bezierCurveTo(x - 0.6, y - 3.2, x + 0.6, y - 1.2, x + 2.4, y - 1.6); ctx.stroke(); }
  function drawPig(ctx, L, dir, step) {
    var sk = L.coat.skin, bob = step ? -0.5 : 0, legC = shade(sk, -10);
    ctx.strokeStyle = LINE; ctx.lineWidth = 0.9;
    if (dir === 4 || dir === 6) {
      shadowOn(ctx, 14);
      leg(ctx, -6 + step * 1.4, -5.6, 5.6, 3.2, shade(legC, -14)); leg(ctx, 7 - step * 1.4, -5.6, 5.6, 3.2, shade(legC, -14));
      leg(ctx, -8 - step * 1.4, -5.6, 5.8, 3.2, legC); leg(ctx, 9 + step * 1.4, -5.6, 5.8, 3.2, legC);
      curlTail(ctx, 12.4, -11 + bob, sk);
      ctx.strokeStyle = LINE; ctx.lineWidth = 0.9; ell(ctx, 1, -10 + bob, 12.6, 6.8); ctx.fillStyle = bodyShade(ctx, 1, -10, 12, sk); ctx.fill(); ctx.stroke();
      ctx.save(); ell(ctx, 1, -10 + bob, 12.6, 6.8); ctx.clip(); pigMarks(ctx, L, 1, -10 + bob, 12.6, 6.8, 'side'); ctx.restore();
      ell(ctx, -10, -10.6 + bob, 5.6, 5.2); ctx.fillStyle = bodyShade(ctx, -10, -11, 6, sk); ctx.fill(); ctx.stroke();
      pigEar(ctx, -9, -15 + bob, L, true, 1);
      ell(ctx, -15.4, -9.6 + bob, 1.8, 2.6); ctx.fillStyle = shade(sk, 12); ctx.fill(); ctx.stroke();
      ctx.fillStyle = 'rgba(40,16,16,0.7)'; ell(ctx, -15.8, -10.4 + bob, 0.45, 0.6); ctx.fill(); ell(ctx, -15.8, -8.8 + bob, 0.45, 0.6); ctx.fill();
      ctx.fillStyle = sk === '#3a3338' ? '#e8e0d0' : '#1c1410'; ell(ctx, -11.6, -12.2 + bob, 0.7, 0.75); ctx.fill();
    } else if (dir === 2) {
      shadowOn(ctx, 10);
      leg(ctx, -6, -5, 5, 3.2, shade(legC, -14)); leg(ctx, 6, -5, 5, 3.2, shade(legC, -14));
      leg(ctx, -3, -5 + (step > 0 ? -1 : 0), 5.4, 3.4, legC); leg(ctx, 3, -5 + (step < 0 ? -1 : 0), 5.4, 3.4, legC);
      ell(ctx, 0, -11 + bob, 9.4, 7.4); ctx.fillStyle = bodyShade(ctx, 0, -11, 9, sk); ctx.fill(); ctx.stroke();
      ctx.save(); ell(ctx, 0, -11 + bob, 9.4, 7.4); ctx.clip(); pigMarks(ctx, L, 0, -11 + bob, 9.4, 7.4, 'front'); ctx.restore();
      ell(ctx, 0, -10 + bob, 6.4, 5.8); ctx.fillStyle = bodyShade(ctx, 0, -11, 6.5, sk); ctx.fill(); ctx.stroke();
      pigEar(ctx, -4.6, -14.4 + bob, L, false, 1); pigEar(ctx, 4.6, -14.4 + bob, L, false, -1);
      ell(ctx, 0, -7.6 + bob, 3.2, 2.2); ctx.fillStyle = shade(sk, 12); ctx.fill(); ctx.stroke();
      ctx.fillStyle = 'rgba(40,16,16,0.7)'; ell(ctx, -1.1, -7.6 + bob, 0.55, 0.75); ctx.fill(); ell(ctx, 1.1, -7.6 + bob, 0.55, 0.75); ctx.fill();
      ctx.fillStyle = sk === '#3a3338' ? '#e8e0d0' : '#1c1410'; ell(ctx, -2.4, -11.4 + bob, 0.7, 0.8); ctx.fill(); ell(ctx, 2.4, -11.4 + bob, 0.7, 0.8); ctx.fill();
    } else {
      shadowOn(ctx, 10);
      leg(ctx, -4, -5 + (step > 0 ? -1 : 0), 5.2, 3.4, legC); leg(ctx, 4, -5 + (step < 0 ? -1 : 0), 5.2, 3.4, legC);
      pigEar(ctx, -4.6, -17 + bob, L, false, 1); pigEar(ctx, 4.6, -17 + bob, L, false, -1);
      ell(ctx, 0, -11 + bob, 9.4, 7.6); ctx.fillStyle = bodyShade(ctx, 0, -11, 9, sk); ctx.fill(); ctx.stroke();
      ctx.save(); ell(ctx, 0, -11 + bob, 9.4, 7.6); ctx.clip(); pigMarks(ctx, L, 0, -11 + bob, 9.4, 7.6, 'front'); ctx.restore();
      curlTail(ctx, 0, -9 + bob, sk);
    }
  }

  function drawGoose(ctx, L, dir, step) {
    var c = L.coat, bob = step ? -0.5 : 0;
    ctx.lineCap = 'round';
    if (dir === 4 || dir === 6) {
      shadowOn(ctx, 9);
      ctx.strokeStyle = c.legs; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(0, -4); ctx.lineTo(-0.6 + step * 1.8, 0); ctx.moveTo(2.4, -4); ctx.lineTo(2.4 - step * 1.8, 0); ctx.stroke();
      ctx.fillStyle = c.legs; ell(ctx, -1.4 + step * 1.8, 0, 1.8, 0.7); ctx.fill(); ell(ctx, 1.4 - step * 1.8, 0, 1.8, 0.7); ctx.fill();
      ctx.strokeStyle = LINE; ctx.lineWidth = 0.9;
      // body: a teardrop with the tail tip up and back
      ctx.beginPath(); ctx.moveTo(-7, -8 + bob); ctx.quadraticCurveTo(-6, -14.6 + bob, 2, -13.6 + bob); ctx.quadraticCurveTo(8, -13 + bob, 11, -15.6 + bob); ctx.quadraticCurveTo(10.6, -9 + bob, 7, -5.6 + bob); ctx.quadraticCurveTo(0, -3 + bob, -7, -8 + bob); ctx.closePath();
      ctx.fillStyle = bodyShade(ctx, 1, -10, 9, c.body); ctx.fill(); ctx.stroke();
      if (c.belly) { ctx.save(); ctx.clip(); ctx.fillStyle = c.belly; ell(ctx, -1, -5 + bob, 8, 3.4); ctx.fill(); ctx.restore(); }
      ctx.fillStyle = c.wing; ctx.beginPath(); ctx.moveTo(-3, -11 + bob); ctx.quadraticCurveTo(4, -13 + bob, 9.6, -12.8 + bob); ctx.quadraticCurveTo(6, -7.6 + bob, -1, -8.4 + bob); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = shade(c.wing, -24); ctx.lineWidth = 0.6; for (var f = 0; f < 3; f++) { ctx.beginPath(); ctx.moveTo(1 + f * 2.6, -11.6 + bob); ctx.lineTo(3 + f * 2.6, -9 + bob); ctx.stroke(); }
      // neck: a thick S, then the head and beak
      ctx.strokeStyle = LINE; ctx.lineWidth = 4.6; ctx.beginPath(); ctx.moveTo(-5, -10 + bob); ctx.bezierCurveTo(-8, -14 + bob, -4, -18 + bob, -7, -23 + bob); ctx.stroke();
      ctx.strokeStyle = c.body; ctx.lineWidth = 3.2; ctx.stroke();
      if (c.stripe) { ctx.strokeStyle = c.stripe; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(-4.6, -12 + bob); ctx.bezierCurveTo(-6.6, -15 + bob, -3.4, -18 + bob, -6, -23 + bob); ctx.stroke(); }
      ctx.strokeStyle = LINE; ctx.lineWidth = 0.9; ctx.fillStyle = bodyShade(ctx, -7.4, -24.4, 3.4, c.body); ell(ctx, -7.4, -24.4 + bob, 2.9, 2.3); ctx.fill(); ctx.stroke();
      ctx.fillStyle = c.beak; ctx.beginPath(); ctx.moveTo(-9.6, -25.4 + bob); ctx.lineTo(-13.4, -23.8 + bob); ctx.lineTo(-9.4, -23 + bob); ctx.closePath(); ctx.fill(); ctx.stroke();
      if (c.knob) { ctx.fillStyle = c.beak; ell(ctx, -9.6, -26.2 + bob, 1.3, 1.1); ctx.fill(); }
      ctx.fillStyle = '#1c1410'; ell(ctx, -7.6, -25 + bob, 0.6, 0.65); ctx.fill();
    } else {
      var front = dir === 2;
      shadowOn(ctx, 7.4);
      ctx.strokeStyle = c.legs; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(-2.4, -4); ctx.lineTo(-2.4, step > 0 ? -1 : 0); ctx.moveTo(2.4, -4); ctx.lineTo(2.4, step < 0 ? -1 : 0); ctx.stroke();
      ctx.fillStyle = c.legs; ell(ctx, -2.6, 0, 1.8, 0.8); ctx.fill(); ell(ctx, 2.6, 0, 1.8, 0.8); ctx.fill();
      ctx.strokeStyle = LINE; ctx.lineWidth = 0.9;
      if (!front) { ctx.fillStyle = c.wing; ctx.beginPath(); ctx.moveTo(-2.6, -12 + bob); ctx.lineTo(0, -19 + bob); ctx.lineTo(2.6, -12 + bob); ctx.closePath(); ctx.fill(); ctx.stroke(); }
      if (!front) { ctx.lineWidth = 4.4; ctx.beginPath(); ctx.moveTo(0, -12 + bob); ctx.lineTo(0, -22 + bob); ctx.stroke(); ctx.strokeStyle = c.body; ctx.lineWidth = 3; ctx.stroke(); ctx.strokeStyle = LINE; ctx.lineWidth = 0.9; ctx.fillStyle = c.body; ell(ctx, 0, -23.4 + bob, 2.6, 2.4); ctx.fill(); ctx.stroke(); }
      ell(ctx, 0, -9 + bob, 6.8, 6.2); ctx.fillStyle = bodyShade(ctx, 0, -9, 7, c.body); ctx.fill(); ctx.stroke();
      if (c.belly && front) { ctx.save(); ell(ctx, 0, -9 + bob, 6.8, 6.2); ctx.clip(); ctx.fillStyle = c.belly; ell(ctx, 0, -6 + bob, 4.6, 4); ctx.fill(); ctx.restore(); }
      ctx.fillStyle = c.wing; ell(ctx, -5.4, -9 + bob, 1.8, 4, 0.15); ctx.fill(); ctx.stroke(); ell(ctx, 5.4, -9 + bob, 1.8, 4, -0.15); ctx.fill(); ctx.stroke();
      if (front) {
        ctx.lineWidth = 4.4; ctx.beginPath(); ctx.moveTo(0, -13 + bob); ctx.lineTo(0, -21 + bob); ctx.stroke(); ctx.strokeStyle = c.body; ctx.lineWidth = 3; ctx.stroke();
        if (c.stripe) { ctx.strokeStyle = c.stripe; ctx.lineWidth = 0.9; ctx.beginPath(); ctx.moveTo(0, -14 + bob); ctx.lineTo(0, -21 + bob); ctx.stroke(); }
        ctx.strokeStyle = LINE; ctx.lineWidth = 0.9; ctx.fillStyle = bodyShade(ctx, 0, -23, 3, c.body); ell(ctx, 0, -23.2 + bob, 2.7, 2.5); ctx.fill(); ctx.stroke();
        ctx.fillStyle = c.beak; ctx.beginPath(); ctx.moveTo(-1.2, -22.6 + bob); ctx.lineTo(1.2, -22.6 + bob); ctx.lineTo(0, -19.6 + bob); ctx.closePath(); ctx.fill(); ctx.stroke();
        if (c.knob) { ell(ctx, 0, -22.8 + bob, 1.1, 0.9); ctx.fill(); }
        ctx.fillStyle = '#1c1410'; ell(ctx, -1.2, -24 + bob, 0.5, 0.55); ctx.fill(); ell(ctx, 1.2, -24 + bob, 0.5, 0.55); ctx.fill();
      }
    }
    ctx.lineCap = 'butt';
  }

  /**
   * One animal at foot (x, y), facing dir, at walk step (-1, 0, 1), scaled by s (1 = a 48 px tile). Right is the left
   * profile mirrored, so the two sides are the same animal by construction (wing §11).
   */
  function drawAnimal(ctx, x, y, L, dir, step, s) {
    ctx.save(); ctx.translate(x, y); var k = (s || 1) * (L.size || 1); ctx.scale(dir === 6 ? -k : k, k);
    if (L.species === 'sheep') drawSheep(ctx, L, dir, step);
    else if (L.species === 'hen') drawHen(ctx, L, dir, step);
    else if (L.species === 'pig') drawPig(ctx, L, dir, step);
    else drawGoose(ctx, L, dir, step);
    ctx.restore();
  }
  /** a sheet for one animal: 3 steps x 4 facings (rows down, left, right, up: MZ's character order) in CELL x CELL cells */
  var CELL = 48;
  function drawAnimalSheet(ctx, L, cell) {
    cell = cell || CELL; var dirs = [2, 4, 6, 8], steps = [-1, 0, 1];
    for (var r = 0; r < 4; r++) for (var c = 0; c < 3; c++) drawAnimal(ctx, c * cell + cell / 2, r * cell + cell - 4, L, dirs[r], steps[c], cell / 48);
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Props and effects
  // ---------------------------------------------------------------------------------------------------------------
  /** the feed trough: a plank box on trestle legs, heaped with hay, seen from the front-above. w x h canvas. */
  function drawTrough(ctx, w, h) {
    var cx = w / 2, by = h - 6, tw = w * 0.84, th = h * 0.36;
    ctx.fillStyle = 'rgba(20,14,6,0.3)'; ell(ctx, cx + 2, by + 2, tw * 0.55, 4.2); ctx.fill();
    ctx.fillStyle = '#5a3a1e'; ctx.fillRect(cx - tw / 2 + 3, by - 8, 4, 9); ctx.fillRect(cx + tw / 2 - 7, by - 8, 4, 9);
    // hay heaped above the rim
    ctx.save(); ctx.beginPath(); ctx.moveTo(cx - tw / 2 + 2, by - th); ctx.quadraticCurveTo(cx, by - th - h * 0.42, cx + tw / 2 - 2, by - th); ctx.closePath(); ctx.fillStyle = '#d8b25a'; ctx.fill(); ctx.clip();
    ctx.lineWidth = 0.9; for (var k = 0; k < 46; k++) { var a = (k * 37) % 100 / 100, b = (k * 61) % 100 / 100; ctx.strokeStyle = k % 3 ? '#b88a36' : '#f2d88a'; ctx.beginPath(); var sx = cx - tw / 2 + a * tw, sy = by - th - b * h * 0.3; ctx.moveTo(sx, sy); ctx.lineTo(sx + 5 - b * 10, sy + 4 + a * 3); ctx.stroke(); }
    ctx.restore();
    // the box: two planks, nail heads, end boards
    var g = ctx.createLinearGradient(0, by - th, 0, by); g.addColorStop(0, '#a87444'); g.addColorStop(1, '#6a4422');
    ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(cx - tw / 2, by - th); ctx.lineTo(cx + tw / 2, by - th); ctx.lineTo(cx + tw / 2 - 4, by - 2); ctx.lineTo(cx - tw / 2 + 4, by - 2); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = LINE; ctx.lineWidth = 1; ctx.stroke();
    ctx.strokeStyle = 'rgba(40,20,8,0.6)'; ctx.beginPath(); ctx.moveTo(cx - tw / 2 + 2, by - th / 2 - 1); ctx.lineTo(cx + tw / 2 - 2, by - th / 2 - 1); ctx.stroke();
    ctx.fillStyle = 'rgba(255,230,190,0.25)'; ctx.fillRect(cx - tw / 2 + 2, by - th + 1, tw - 4, 1.4);
    ctx.fillStyle = '#2a1a0e'; [0.12, 0.88].forEach(function (f) { ell(ctx, cx - tw / 2 + tw * f, by - th + 3, 0.9, 0.9); ctx.fill(); ell(ctx, cx - tw / 2 + tw * f, by - th / 2 + 2, 0.9, 0.9); ctx.fill(); });
  }
  /** a startle mark (the "!" a startled animal throws) in a small white bubble */
  function drawStartle(ctx, w, h) {
    ctx.fillStyle = '#fbf6ea'; ctx.strokeStyle = LINE; ctx.lineWidth = 1.2; ell(ctx, w / 2, h / 2 - 1, w / 2 - 2, h / 2 - 3); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(w / 2 - 2, h - 5); ctx.lineTo(w / 2, h - 1); ctx.lineTo(w / 2 + 2, h - 5); ctx.fillStyle = '#fbf6ea'; ctx.fill();
    ctx.fillStyle = '#b8261e'; rr(ctx, w / 2 - 1.6, 4, 3.2, h - 13, 1.4); ctx.fill(); ell(ctx, w / 2, h - 6.4, 1.7, 1.7); ctx.fill();
  }
  /** a dust puff, frame f of 4 (bigger and fainter as it ages) */
  function drawDust(ctx, w, h, f) {
    var a = [0.55, 0.45, 0.32, 0.18][f], r = [3.2, 4.4, 5.4, 6.2][f];
    ctx.fillStyle = 'rgba(214,192,150,' + a + ')'; for (var k = 0; k < 3; k++) { ell(ctx, w / 2 + (k - 1) * r * 0.9, h / 2 + (k === 1 ? -r * 0.4 : 0), r, r * 0.8); ctx.fill(); }
  }
  /** a loose feather */
  function drawFeather(ctx, w, h, col) {
    ctx.save(); ctx.translate(w / 2, h / 2); ctx.rotate(-0.6); ctx.fillStyle = col || '#f3efe4'; ctx.strokeStyle = 'rgba(60,40,20,0.6)'; ctx.lineWidth = 0.6;
    ctx.beginPath(); ctx.moveTo(0, -h * 0.4); ctx.quadraticCurveTo(w * 0.3, 0, 0, h * 0.4); ctx.quadraticCurveTo(-w * 0.3, 0, 0, -h * 0.4); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0, -h * 0.4); ctx.lineTo(0, h * 0.45); ctx.stroke(); ctx.restore();
  }
  /** a penned twinkle: a four-point gold star */
  function drawTwinkle(ctx, w, h) {
    var cx = w / 2, cy = h / 2, R = Math.min(w, h) / 2 - 1; ctx.fillStyle = '#f6d466'; ctx.strokeStyle = 'rgba(120,80,10,0.8)'; ctx.lineWidth = 0.8;
    ctx.beginPath(); for (var k = 0; k < 8; k++) { var a = k / 8 * TAU - Math.PI / 2, r = k % 2 ? R * 0.32 : R; ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r); } ctx.closePath(); ctx.fill(); ctx.stroke();
  }
  /** the whistle's ring (drawn once, scaled and faded by the caller) */
  function drawRing(ctx, w, h) { ctx.strokeStyle = 'rgba(255,248,226,0.9)'; ctx.lineWidth = 3; ell(ctx, w / 2, h / 2, w / 2 - 3, h / 2 - 3); ctx.stroke(); ctx.strokeStyle = 'rgba(120,90,40,0.5)'; ctx.lineWidth = 1; ell(ctx, w / 2, h / 2, w / 2 - 5.5, h / 2 - 5.5); ctx.stroke(); }
  /** a musical note (the whistle) */
  function drawNote(ctx, w, h) { ctx.fillStyle = '#3a2410'; ell(ctx, w * 0.36, h * 0.74, w * 0.2, h * 0.14, -0.4); ctx.fill(); ctx.fillRect(w * 0.52, h * 0.16, 1.6, h * 0.58); ctx.beginPath(); ctx.moveTo(w * 0.52, h * 0.16); ctx.quadraticCurveTo(w * 0.9, h * 0.28, w * 0.74, h * 0.5); ctx.lineWidth = 1.6; ctx.strokeStyle = '#3a2410'; ctx.stroke(); }

  /** the touch whistle button: a brass whistle on a wooden roundel, with the cooldown drawn as a dark wedge (0..1 ready) */
  function drawWhistleButton(ctx, w, h, ready) {
    var cx = w / 2, cy = h / 2, R = Math.min(w, h) / 2 - 2;
    ctx.fillStyle = 'rgba(20,12,4,0.35)'; ell(ctx, cx + 2, cy + 3, R, R); ctx.fill();
    var g = ctx.createRadialGradient(cx - R * 0.4, cy - R * 0.4, 2, cx, cy, R); g.addColorStop(0, '#b98650'); g.addColorStop(1, '#6a4422'); ctx.fillStyle = g; ell(ctx, cx, cy, R, R); ctx.fill();
    ctx.strokeStyle = '#3a2410'; ctx.lineWidth = 2; ctx.stroke(); ctx.strokeStyle = 'rgba(255,230,190,0.35)'; ctx.lineWidth = 1; ell(ctx, cx, cy, R - 3, R - 3); ctx.stroke();
    // the whistle: a brass barrel and mouthpiece
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(-0.5);
    g = ctx.createLinearGradient(0, -6, 0, 6); g.addColorStop(0, '#fbe7a0'); g.addColorStop(0.5, '#d4a838'); g.addColorStop(1, '#8a6214'); ctx.fillStyle = g;
    ell(ctx, 3, 0, 7, 6); ctx.fill(); ctx.strokeStyle = '#5a3e0a'; ctx.lineWidth = 1; ctx.stroke(); rr(ctx, -10, -2.6, 10, 5.2, 1.6); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#3a2808'; rr(ctx, -2, -4.6, 3.6, 2.4, 0.8); ctx.fill(); ctx.restore();
    if (ready < 1) { ctx.fillStyle = 'rgba(20,12,4,0.55)'; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.arc(cx, cy, R, -Math.PI / 2 + ready * TAU, -Math.PI / 2 + TAU); ctx.closePath(); ctx.fill(); }
  }

  /** an animal's head as a tally mark: coloured when penned, a pale ghost when not */
  function drawHead(ctx, x, y, L, penned, s) {
    ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
    if (!penned) ctx.globalAlpha = 0.32;
    var sp = L.species;
    if (sp === 'sheep') { ctx.fillStyle = L.coat.wool; ctx.strokeStyle = LINE; ctx.lineWidth = 0.9; ell(ctx, 0, -1, 6.4, 5); ctx.fill(); ctx.stroke(); sheepHead(ctx, 0, 1.6, L, 'front'); }
    else if (sp === 'hen') { ctx.strokeStyle = LINE; ctx.lineWidth = 0.9; ctx.fillStyle = L.coat.body; ell(ctx, 0, 0.6, 4.6, 4.6); ctx.fill(); ctx.stroke(); comb(ctx, 0, 0, L, false); ctx.fillStyle = '#e8b13a'; ctx.beginPath(); ctx.moveTo(-1.2, 1.4); ctx.lineTo(1.2, 1.4); ctx.lineTo(0, 3.6); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#1c1410'; ell(ctx, -1.6, 0, 0.6, 0.6); ctx.fill(); ell(ctx, 1.6, 0, 0.6, 0.6); ctx.fill(); }
    else if (sp === 'pig') { ctx.strokeStyle = LINE; ctx.lineWidth = 0.9; pigEar(ctx, -3.8, -3, L, false, 1); pigEar(ctx, 3.8, -3, L, false, -1); ctx.fillStyle = L.coat.skin; ell(ctx, 0, 0.6, 5.6, 5); ctx.fill(); ctx.stroke(); ctx.fillStyle = shade(L.coat.skin, 12); ell(ctx, 0, 2.2, 2.6, 1.8); ctx.fill(); ctx.stroke(); ctx.fillStyle = '#1c1410'; ell(ctx, -2, -0.6, 0.6, 0.6); ctx.fill(); ell(ctx, 2, -0.6, 0.6, 0.6); ctx.fill(); }
    else { ctx.strokeStyle = LINE; ctx.lineWidth = 0.9; ctx.fillStyle = L.coat.body; ell(ctx, 0, 0, 4, 4.4); ctx.fill(); ctx.stroke(); ctx.fillStyle = L.coat.beak; ctx.beginPath(); ctx.moveTo(-1.6, 1.4); ctx.lineTo(1.6, 1.4); ctx.lineTo(0, 5); ctx.closePath(); ctx.fill(); ctx.stroke(); ctx.fillStyle = '#1c1410'; ell(ctx, -1.6, -0.6, 0.6, 0.6); ctx.fill(); ell(ctx, 1.6, -0.6, 0.6, 0.6); ctx.fill(); }
    ctx.restore();
  }

  /** the HUD board: a bell clock (time left as a brass dial) and one head per animal. info: {looks, penned[], frac, secs} */
  function drawHud(ctx, w, h, info) {
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = 'rgba(20,12,4,0.35)'; rr(ctx, 4, 5, w - 6, h - 6, 8); ctx.fill();
    var g = ctx.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#9a6a3c'); g.addColorStop(1, '#6a4422'); ctx.fillStyle = g; rr(ctx, 1, 1, w - 6, h - 6, 8); ctx.fill();
    ctx.strokeStyle = '#3a2410'; ctx.lineWidth = 2; ctx.stroke();
    ctx.strokeStyle = 'rgba(40,20,8,0.35)'; ctx.lineWidth = 1; for (var gy = 12; gy < h - 8; gy += 9) { ctx.beginPath(); ctx.moveTo(10, gy); ctx.bezierCurveTo(w * 0.3, gy + 2, w * 0.6, gy - 2, w - 14, gy + 1); ctx.stroke(); }
    // the clock: a brass dial; the time left is the cream wedge, the hand points at it
    var cx = 32, cy = (h - 5) / 2, R = 22;
    g = ctx.createRadialGradient(cx - 6, cy - 6, 2, cx, cy, R + 3); g.addColorStop(0, '#fbe7a0'); g.addColorStop(1, '#9a7218'); ctx.fillStyle = g; ell(ctx, cx, cy, R + 3, R + 3); ctx.fill(); ctx.strokeStyle = '#4a3208'; ctx.lineWidth = 1.2; ctx.stroke();
    ctx.fillStyle = '#f6eed8'; ell(ctx, cx, cy, R - 1, R - 1); ctx.fill();
    var fr = Math.max(0, Math.min(1, info.frac)); ctx.fillStyle = fr < 0.2 ? '#d8604a' : '#7a9a4a'; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.arc(cx, cy, R - 3, -Math.PI / 2, -Math.PI / 2 + fr * TAU); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = '#3a2810'; ctx.lineWidth = 1; for (var t = 0; t < 12; t++) { var a = t / 12 * TAU; ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * (R - 1), cy + Math.sin(a) * (R - 1)); ctx.lineTo(cx + Math.cos(a) * (R - 5), cy + Math.sin(a) * (R - 5)); ctx.stroke(); }
    ctx.fillStyle = INK; ctx.font = 'bold 13px ' + FACE; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(String(info.secs), cx, cy + 1);
    // the tally: a head per animal, two rows if needed
    // one row up to ten heads, scaled to fill the plank (contact sheet 2026-10-11: two rows of 1.2x heads read as mud)
    var n = info.looks.length, cols = n > 10 ? Math.ceil(n / 2) : n, rows = n > 10 ? 2 : 1, x0 = 64, cw = Math.min(30, (w - x0 - 14) / cols), rh = (h - 10) / rows;
    var hs = Math.min(rows > 1 ? 1.5 : 2.1, cw / 13.5);
    for (var i = 0; i < n; i++) { var col = i % cols, row = Math.floor(i / cols); drawHead(ctx, x0 + cw * (col + 0.5), 2 + rh * (row + 0.5), info.looks[i], info.penned[i], hs); }
  }

  /** the opening sign: a painted board on two posts */
  function drawBanner(ctx, w, h, title, sub) {
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = '#4a2e16'; ctx.fillRect(w * 0.2 - 4, h * 0.6, 8, h * 0.4); ctx.fillRect(w * 0.8 - 4, h * 0.6, 8, h * 0.4);
    ctx.fillStyle = 'rgba(20,12,4,0.4)'; rr(ctx, 8, 6, w - 12, h * 0.74, 10); ctx.fill();
    var g = ctx.createLinearGradient(0, 0, 0, h * 0.74); g.addColorStop(0, '#b47a42'); g.addColorStop(1, '#7a4c24'); ctx.fillStyle = g; rr(ctx, 4, 2, w - 12, h * 0.74, 10); ctx.fill(); ctx.strokeStyle = '#3a2410'; ctx.lineWidth = 2.5; ctx.stroke();
    ctx.strokeStyle = '#f2e2b8'; ctx.lineWidth = 1.4; rr(ctx, 11, 9, w - 26, h * 0.74 - 14, 7); ctx.stroke();
    ctx.fillStyle = '#fbf0d0'; ctx.strokeStyle = 'rgba(40,20,8,0.9)'; ctx.lineWidth = 4; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    var fs = fitText(ctx, title, w - 60, 30, 'bold italic', FACE); ctx.strokeText(title, w / 2 - 4, h * 0.27); ctx.fillText(title, w / 2 - 4, h * 0.27);
    ctx.fillStyle = '#f2e2b8'; fitText(ctx, sub, w - 60, 15, '', HAND); ctx.lineWidth = 3; ctx.strokeText(sub, w / 2 - 4, h * 0.56); ctx.fillText(sub, w / 2 - 4, h * 0.56);
    return fs;
  }

  /** a prize rosette (filled = won, pale = not) */
  function drawRosette(ctx, x, y, R, won, col) {
    col = col || '#2a5aa8';
    ctx.save(); if (!won) ctx.globalAlpha = 0.28;
    ctx.fillStyle = shade(col, -20); [-0.35, 0.35].forEach(function (a) { ctx.save(); ctx.translate(x, y); ctx.rotate(a); ctx.beginPath(); ctx.moveTo(-R * 0.32, 0); ctx.lineTo(R * 0.32, 0); ctx.lineTo(R * 0.3, R * 2); ctx.lineTo(0, R * 1.7); ctx.lineTo(-R * 0.3, R * 2); ctx.closePath(); ctx.fill(); ctx.restore(); });
    ctx.fillStyle = col; ctx.beginPath(); for (var k = 0; k < 24; k++) { var a = k / 24 * TAU, r = k % 2 ? R * 0.84 : R; ctx.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r); } ctx.closePath(); ctx.fill(); ctx.strokeStyle = shade(col, -50); ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = shade(col, 30); ell(ctx, x, y, R * 0.6, R * 0.6); ctx.fill();
    ctx.fillStyle = '#f6d466'; ell(ctx, x, y, R * 0.42, R * 0.42); ctx.fill(); ctx.strokeStyle = '#8a6214'; ctx.stroke();
    ctx.restore();
  }

  /**
   * The tally board at the bell: a slate on a frame, the title, the count, the time, every animal drawn (penned ones
   * inside a little drawn pen, strays outside it) and three prize rosettes.
   * info: {title, sub, looks[], penned[], pennedCount, total, secsLeft, stars, foot}
   */
  function drawTally(ctx, W, H, info) {
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = 'rgba(10,6,2,0.45)'; ctx.fillRect(0, 0, W, H);
    var w = Math.min(560, W - 40), h = Math.min(420, H - 60), x = (W - w) / 2, y = (H - h) / 2 - 10;
    ctx.fillStyle = 'rgba(0,0,0,0.4)'; rr(ctx, x + 6, y + 8, w, h, 12); ctx.fill();
    var g = ctx.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, '#9a6a3c'); g.addColorStop(1, '#5a3a1c'); ctx.fillStyle = g; rr(ctx, x, y, w, h, 12); ctx.fill(); ctx.strokeStyle = '#2e1a0a'; ctx.lineWidth = 3; ctx.stroke();
    var ix = x + 16, iy = y + 16, iw = w - 32, ih = h - 32;
    g = ctx.createLinearGradient(0, iy, 0, iy + ih); g.addColorStop(0, '#34413c'); g.addColorStop(1, '#262f2c'); ctx.fillStyle = g; rr(ctx, ix, iy, iw, ih, 6); ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.05)'; ctx.lineWidth = 6; for (var sm = 0; sm < 5; sm++) { ctx.beginPath(); ctx.moveTo(ix + 20 + sm * 90, iy + 10); ctx.quadraticCurveTo(ix + 60 + sm * 90, iy + ih / 2, ix + 10 + sm * 95, iy + ih - 10); ctx.stroke(); }
    ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic'; ctx.fillStyle = '#f2ecdc';
    fitText(ctx, info.title, iw - 40, 26, 'bold italic', FACE); ctx.fillText(info.title, x + w / 2, iy + 34);
    ctx.fillStyle = 'rgba(242,236,220,0.75)'; fitText(ctx, info.sub, iw - 40, 14, '', HAND); ctx.fillText(info.sub, x + w / 2, iy + 56);
    // the pen (chalk rails) with the penned animals inside, the strays outside on the right
    var penX = ix + 24, penY = iy + 74, penW = iw * 0.62, penH = ih - 170;
    ctx.strokeStyle = 'rgba(242,236,220,0.85)'; ctx.lineWidth = 2; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(penX + penW * 0.7, penY); ctx.lineTo(penX, penY); ctx.lineTo(penX, penY + penH); ctx.lineTo(penX + penW, penY + penH); ctx.lineTo(penX + penW, penY + penH * 0.55); ctx.stroke();
    for (var pp = penX + 18; pp < penX + penW; pp += 22) { ctx.beginPath(); ctx.moveTo(pp, penY + penH - 6); ctx.lineTo(pp, penY + penH + 6); ctx.stroke(); }
    ctx.lineCap = 'butt';
    var pens = [], strays = [], i; for (i = 0; i < info.looks.length; i++) (info.penned[i] ? pens : strays).push(info.looks[i]);
    // the penned animals fill their pen (contact sheet 2026-10-11: at 1x they floated small in an empty slate), facing
    // alternately so the pen reads as a crowd, not a grid of portraits
    var pc = Math.max(1, Math.ceil(Math.sqrt(pens.length * 1.8))), prow = Math.max(1, Math.ceil(pens.length / pc)), pcw = penW / pc, prh = penH / prow, sc = Math.min(2, pcw / 30, prh / 28);
    if (!pens.length) { ctx.fillStyle = 'rgba(242,236,220,0.45)'; ctx.font = 'italic 22px ' + HAND; ctx.textAlign = 'center'; ctx.fillText('empty', penX + penW / 2, penY + penH / 2 + 8); }
    for (i = 0; i < pens.length; i++) { var c = i % pc, r = Math.floor(i / pc); drawAnimal(ctx, penX + pcw * (c + 0.5) + (r % 2 ? pcw * 0.18 : 0), penY + prh * (r + 0.5) + 13 * sc, pens[i], [2, 4, 6, 2][(i + r) % 4], 0, sc); }
    var sx0 = penX + penW + 26, sw = ix + iw - sx0 - 10, scs = Math.min(1.6, sc);
    if (strays.length) { ctx.fillStyle = 'rgba(242,236,220,0.7)'; ctx.font = 'italic 14px ' + HAND; ctx.textAlign = 'center'; ctx.fillText(strays.length === 1 ? 'one got away' : strays.length + ' got away', sx0 + sw / 2, penY + 10); }
    for (i = 0; i < strays.length; i++) drawAnimal(ctx, sx0 + sw * (((i % 2) + 0.5) / 2), penY + 40 + 28 * scs + Math.floor(i / 2) * 40 * scs, strays[i], i % 2 ? 6 : 4, 0, scs);
    // the count and the time
    var ty = iy + ih - 70; ctx.textAlign = 'left'; ctx.fillStyle = '#f2ecdc'; ctx.font = 'bold 22px ' + FACE; ctx.fillText(info.pennedCount + ' of ' + info.total + ' penned', ix + 24, ty);
    ctx.fillStyle = 'rgba(242,236,220,0.75)'; ctx.font = '15px ' + HAND; ctx.fillText(info.secsLeft > 0 ? info.secsLeft + ' s on the clock' : 'at the bell', ix + 24, ty + 24);
    for (var s = 0; s < 3; s++) drawRosette(ctx, ix + iw - 132 + s * 46, ty - 12, 17, s < info.stars, ['#2a5aa8', '#a8282a', '#d8a028'][s]);
    ctx.textAlign = 'center'; ctx.font = 'italic 13px ' + FACE; ctx.fillStyle = '#e8d4a8'; ctx.fillText(info.foot, W / 2, Math.min(H - 12, y + h + 24));
  }

  return {
    VERSION: '1.0.0', FACE: FACE, HAND: HAND, CELL: CELL, LOOKS: LOOKS, hex: hex, shade: shade, hash: hash,
    SHEEP_COATS: SHEEP_COATS, SHEEP_FACES: SHEEP_FACES, HEN_COATS: HEN_COATS, PIG_COATS: PIG_COATS, GOOSE_COATS: GOOSE_COATS,
    lookFor: lookFor, allLooks: allLooks, drawAnimal: drawAnimal, drawAnimalSheet: drawAnimalSheet, drawHead: drawHead,
    drawTrough: drawTrough, drawStartle: drawStartle, drawDust: drawDust, drawFeather: drawFeather, drawTwinkle: drawTwinkle,
    drawRing: drawRing, drawNote: drawNote, drawWhistleButton: drawWhistleButton, drawHud: drawHud, drawBanner: drawBanner,
    drawRosette: drawRosette, drawTally: drawTally,
  };
}());
if (typeof module !== 'undefined' && module.exports) module.exports = RoundupDraw;
