//=============================================================================
// Roundup.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Round-up 3/3 - a timed herding job on your own map: drive the flock into the pen before the bell.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @param penRegion
 * @text Pen region ID
 * @type number
 * @min 1
 * @max 255
 * @desc Paint the pen's floor tiles with this region ID. An animal that steps onto one is penned for good.
 * @default 9
 *
 * @param yardRegion
 * @text Yard region ID
 * @type number
 * @min 0
 * @max 255
 * @desc 0 = animals start anywhere they can walk to within Yard size of the pen. Or paint the yard with a region ID.
 * @default 0
 *
 * @param yardSize
 * @text Yard size (tiles)
 * @type number
 * @min 4
 * @max 40
 * @desc With no yard region: how far from the pen (walking distance, in tiles) animals may start.
 * @default 12
 *
 * @param trough
 * @text Feed trough
 * @type boolean
 * @on Draw it
 * @off No trough
 * @desc Draw a hay trough just inside the pen's gate. Animals near the gate drift toward it (it makes rounds fairer).
 * @default true
 *
 * @param whistleButton
 * @text Whistle button (touch)
 * @type boolean
 * @desc Show a whistle button for mouse and touch players. The OK key always whistles.
 * @default true
 *
 * @param hudCorner
 * @text Clock corner
 * @type select
 * @option top-left
 * @option top-right
 * @option bottom-left
 * @option bottom-right
 * @desc Where the clock and the tally sit on screen.
 * @default top-left
 *
 * @param allowMenu
 * @text Allow menu in a round
 * @type boolean
 * @desc Can the player open the menu during a round? (The round pauses while it is open.)
 * @default false
 *
 * @param seSheep
 * @text Sound: sheep
 * @type file
 * @dir audio/se/
 * @require 1
 * @desc A sheep's bleat when startled or penned. Blank = silent.
 * @default Sheep
 *
 * @param seHen
 * @text Sound: hen
 * @type file
 * @dir audio/se/
 * @require 1
 * @default Chicken
 *
 * @param sePig
 * @text Sound: pig
 * @type file
 * @dir audio/se/
 * @require 1
 * @default
 *
 * @param seGoose
 * @text Sound: goose
 * @type file
 * @dir audio/se/
 * @require 1
 * @default
 *
 * @param seWhistle
 * @text Sound: whistle
 * @type file
 * @dir audio/se/
 * @require 1
 * @default Horn
 *
 * @param seBell
 * @text Sound: the bell
 * @type file
 * @dir audio/se/
 * @require 1
 * @default Bell1
 *
 * @command start
 * @text Start Round-up
 * @desc Scatters a generated flock over this map and starts the clock. The pen is every tile painted with the Pen region.
 *
 * @arg difficulty
 * @text Difficulty
 * @type select
 * @option easy
 * @option normal
 * @option hard
 * @option custom
 * @desc easy: 6 head, 90 s. normal: 7, 115 s. hard: 9 with geese, 135 s. custom: the counts below.
 * @default normal
 *
 * @arg sheep
 * @text Sheep (custom)
 * @type number
 * @min 0
 * @max 32
 * @default 4
 *
 * @arg hens
 * @text Hens (custom)
 * @type number
 * @min 0
 * @max 32
 * @default 2
 *
 * @arg pigs
 * @text Pigs (custom)
 * @type number
 * @min 0
 * @max 32
 * @default 1
 *
 * @arg geese
 * @text Geese (custom)
 * @type number
 * @min 0
 * @max 32
 * @default 0
 *
 * @arg seconds
 * @text Time (seconds)
 * @type number
 * @min 0
 * @max 900
 * @desc 0 = the difficulty's own time (custom: 15 s a head).
 * @default 0
 *
 * @arg title
 * @text Title
 * @type text
 * @desc Shown on the opening sign and the tally board. Blank = the map's display name.
 * @default
 *
 * @arg pennedVariableId
 * @text Penned -> variable
 * @type variable
 * @default 0
 *
 * @arg starsVariableId
 * @text Stars (0-3) -> variable
 * @type variable
 * @default 0
 *
 * @arg secondsVariableId
 * @text Seconds left -> variable
 * @type variable
 * @default 0
 *
 * @arg switchId
 * @text Switch ON when all penned
 * @type switch
 * @default 0
 *
 * @arg commonEventId
 * @text Common event when done
 * @type common_event
 * @default 0
 *
 * @arg seed
 * @text Seed
 * @type text
 * @desc Blank = a new flock every time. A number replays the same flock in the same places.
 * @default
 *
 * @command end
 * @text Ring the Bell Now
 * @desc Ends the round at once and shows the tally board.
 *
 * @help
 * Round-up turns any farmyard on your map into a herding job. Paint the pen
 * with a region ID, call "Start Round-up" from an event, and the player has
 * until the bell to drive a generated flock through the gate. No new scene:
 * the animals walk your map, behind your trees and in front of your fences,
 * and the player herds them with the movement they already know.
 *
 * EACH SPECIES MOVES BY ITS OWN RULE
 *   Sheep  flock: move one and the rest follow; sheep already in the pen
 *          draw the others in.
 *   Hens   scatter in zig-zags and will not be driven in a straight line.
 *   Pigs   bolt from you in a straight dash, then stop dead to get their
 *          breath: line one up and spook it at the gate.
 *   Geese  take a stand when you crowd them and charge before they run.
 * A cornered animal dodges along the fence past you, so a corner is never a
 * dead end. The whistle (OK, or the button) calls the animals near you into
 * a bunch for a moment, then needs to cool down.
 *
 * SETTING UP A YARD
 *   1. Paint the pen's floor with the Pen region ID (default 9). Leave a
 *      gate two tiles wide: on a one-tile gate rounds are much harder.
 *   2. The yard is everywhere the animals can walk to within Yard size of
 *      the pen, or paint it with the Yard region ID.
 *   3. Fences, walls and water are your map's own passability. Events that
 *      stand on the map when the round starts (and are not "Through")
 *      block the animals too.
 *
 * RESULTS
 *   When every animal is penned, or the bell rings, the tally board shows
 *   who was penned, who got away, the time left and up to three prize
 *   rosettes (all penned with 30% of the time left: 3, all penned: 2, half
 *   of them: 1). Closing the board sets your variables and switch and runs
 *   the common event.
 *
 * SCRIPT
 *   Roundup.isOpen()      true while a round runs (or its board is open)
 *   Roundup.lastResult()  the last round: {penned, total, stars,
 *                         secondsLeft, won, difficulty, seed} or null
 *
 * The round is saved with the game and resumes where it was. It pauses while
 * a message shows, while another event runs, while the menu is open, and
 * whenever the player is on a different map.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var Roundup = (function () {
  'use strict';

  var NAME = 'Roundup';
  var RAW = PluginManager.parameters(NAME);
  var CORE = null, DRAW = null;
  /** ⛔ Sibling files are resolved at FIRST USE, never at load time: the buyer chooses the load order (wing §8 trap 2). */
  function deps() {
    if (!CORE) { CORE = window.RoundupCore; DRAW = window.RoundupDraw; }
    if (!CORE || !DRAW) throw new Error('Round-up needs RoundupCore.js and RoundupDraw.js installed and ON in the Plugin Manager.');
    return true;
  }
  /** ⛔ Parameters arrive as strings and Number('') is 0 (wing §16): coerce, then compare. */
  function num(v, dflt) { var s = String(v === undefined ? '' : v).trim(); if (s === '') return dflt; var n = Number(s); return isFinite(n) ? n : dflt; }
  var P = {
    penRegion: Math.max(1, Math.min(255, num(RAW.penRegion, 9))),
    yardRegion: Math.max(0, Math.min(255, num(RAW.yardRegion, 0))),
    yardSize: Math.max(4, Math.min(40, num(RAW.yardSize, 12))),
    trough: String(RAW.trough === undefined ? 'true' : RAW.trough) !== 'false',
    whistleButton: String(RAW.whistleButton === undefined ? 'true' : RAW.whistleButton) !== 'false',
    hudCorner: ['top-left', 'top-right', 'bottom-left', 'bottom-right'].indexOf(String(RAW.hudCorner)) >= 0 ? String(RAW.hudCorner) : 'top-left',
    allowMenu: String(RAW.allowMenu) === 'true',
    se: { sheep: RAW.seSheep === undefined ? 'Sheep' : String(RAW.seSheep), hen: RAW.seHen === undefined ? 'Chicken' : String(RAW.seHen), pig: String(RAW.sePig || ''), goose: String(RAW.seGoose || ''),
      whistle: RAW.seWhistle === undefined ? 'Horn' : String(RAW.seWhistle), bell: RAW.seBell === undefined ? 'Bell1' : String(RAW.seBell) },
  };

  /** The save record: versioned, created on first use (so a save made before install loads cleanly). */
  function rec() {
    var sys = $gameSystem; if (!sys) return null;
    if (!sys._csafRoundup || sys._csafRoundup.v !== 1) sys._csafRoundup = { v: 1, count: 0, req: null, round: null, tally: null, last: null };
    return sys._csafRoundup;
  }
  /** Runtime-only state (never saved). */
  var RT = { frame: 0, banner: 0, tallyAge: 0, bound: null, field: null, fx: [], calm: null, playSe: 0, button: { x: 0, y: 0, r: 0, held: false } };

  function playSe(name, vol) { if (name) AudioManager.playSe({ name: name, volume: vol || 90, pitch: 100, pan: 0 }); }

  // -------------------------------------------------------------------------------------------------------------------
  // The field: the map's own passability, the pen region, events standing at the start, where animals may start
  // -------------------------------------------------------------------------------------------------------------------
  function reverseDir(d) { return 10 - d; }
  /**
   * Build the field for the current map from the round's request. canStep is the engine's own edge rule
   * (Game_CharacterBase.isMapPassable, rmmz_objects.js:7115: the exit edge here AND the entry edge there), plus the
   * events that stood on the map when the round began.
   */
  function makeField(req) {
    deps();
    var W = $gameMap.width(), H = $gameMap.height(), blocked = new Uint8Array(W * H), pen = req.penRegion;
    for (var i = 0; i < req.blocked.length; i++) blocked[req.blocked[i]] = 1;
    var field = {
      W: W, H: H,
      canStep: function (x, y, d) {
        var x2 = x + (d === 6 ? 1 : d === 4 ? -1 : 0), y2 = y + (d === 2 ? 1 : d === 8 ? -1 : 0);
        if (!$gameMap.isValid(x, y) || !$gameMap.isValid(x2, y2)) return false;
        if (blocked[y2 * W + x2]) return false;
        return $gameMap.isPassable(x, y, d) && $gameMap.isPassable(x2, y2, reverseDir(d));
      },
      isPen: function (x, y) { return x >= 0 && y >= 0 && x < W && y < H && $gameMap.regionId(x, y) === pen; },
      lure: req.lure, box: req.box,
      canSpawn: function (x, y) { return req.spawnSet ? req.spawnSet.indexOf(y * W + x) >= 0 : true; },
    };
    return field;
  }
  /** The pen's tiles, the gate tiles (pen tiles with a walkable edge out), the trough point and where animals may start. */
  function surveyPen(penRegion, playerX, playerY) {
    var W = $gameMap.width(), H = $gameMap.height(), pens = [], gates = [], x, y, d, k;
    var tmp = { W: W, H: H, canStep: function (x, y, d) { var x2 = x + (d === 6 ? 1 : d === 4 ? -1 : 0), y2 = y + (d === 2 ? 1 : d === 8 ? -1 : 0); return $gameMap.isValid(x2, y2) && $gameMap.isPassable(x, y, d) && $gameMap.isPassable(x2, y2, reverseDir(d)); } };
    for (y = 0; y < H; y++) for (x = 0; x < W; x++) if ($gameMap.regionId(x, y) === penRegion) {
      pens.push(y * W + x);
      for (k = 0; k < 4; k++) { d = [2, 4, 6, 8][k]; var x2 = x + (d === 6 ? 1 : d === 4 ? -1 : 0), y2 = y + (d === 2 ? 1 : d === 8 ? -1 : 0); if ($gameMap.isValid(x2, y2) && $gameMap.regionId(x2, y2) !== penRegion && tmp.canStep(x, y, d)) { gates.push({ x: x, y: y, ox: x2, oy: y2 }); break; } }
    }
    if (!pens.length) return null;
    var cx = 0, cy = 0; pens.forEach(function (p) { cx += p % W + 0.5; cy += Math.floor(p / W) + 0.5; }); cx /= pens.length; cy /= pens.length;
    var lure = null, gx = 0, gy = 0;
    if (gates.length) { gates.forEach(function (g) { gx += g.x + 0.5; gy += g.y + 0.5; }); gx /= gates.length; gy /= gates.length;
      // one tile in from the gate, toward the pen's middle, onto a pen tile
      var dx = cx - gx, dy = cy - gy, dl = Math.sqrt(dx * dx + dy * dy) || 1, lx = gx + dx / dl, ly = gy + dy / dl;
      if ($gameMap.regionId(Math.floor(lx), Math.floor(ly)) !== penRegion) { lx = gx; ly = gy; }
      lure = { x: lx, y: ly }; }
    // where animals may start: tiles walkable from outside the gates within yardSize steps (or the yard region), not the pen,
    // not within 2 tiles of the player
    var spawn = [], seen = new Uint8Array(W * H), q = [], dist = new Int16Array(W * H), head = 0, x0 = W, y0 = H, x1 = 0, y1 = 0;
    if (P.yardRegion > 0) { for (y = 0; y < H; y++) for (x = 0; x < W; x++) if ($gameMap.regionId(x, y) === P.yardRegion) spawn.push(y * W + x); }
    else {
      gates.forEach(function (g) { var p = g.oy * W + g.ox; if (!seen[p]) { seen[p] = 1; dist[p] = 0; q.push(p); } });
      while (head < q.length) { var c = q[head++], cxx = c % W, cyy = Math.floor(c / W); if (dist[c] > P.yardSize) continue;
        if ($gameMap.regionId(cxx, cyy) !== penRegion) spawn.push(c);
        for (k = 0; k < 4; k++) { d = [2, 4, 6, 8][k]; if (!tmp.canStep(cxx, cyy, d)) continue; var nx = cxx + (d === 6 ? 1 : d === 4 ? -1 : 0), ny = cyy + (d === 2 ? 1 : d === 8 ? -1 : 0), n = ny * W + nx; if (!seen[n] && $gameMap.regionId(nx, ny) !== penRegion) { seen[n] = 1; dist[n] = dist[c] + 1; q.push(n); } } }
    }
    spawn = spawn.filter(function (p) { var sx = p % W, sy = Math.floor(p / W); return Math.abs(sx - playerX) + Math.abs(sy - playerY) > 2; });
    spawn.forEach(function (p) { var sx = p % W, sy = Math.floor(p / W); x0 = Math.min(x0, sx); y0 = Math.min(y0, sy); x1 = Math.max(x1, sx); y1 = Math.max(y1, sy); });
    return { pens: pens, gates: gates, lure: lure, spawn: spawn, box: spawn.length ? { x0: x0, y0: y0, x1: x1, y1: y1 } : null };
  }
  /** Tiles held by events standing on the map now (normal priority, not Through, drawn): animals walk round them. */
  function standingEvents() {
    var W = $gameMap.width(), out = [];
    $gameMap.events().forEach(function (ev) { if (!ev || ev.isThrough() || !ev.isNormalPriority() || (!ev.characterName() && !ev.tileId())) return; out.push(ev.y * W + ev.x); });
    return out;
  }

  // -------------------------------------------------------------------------------------------------------------------
  // The round
  // -------------------------------------------------------------------------------------------------------------------
  var SPECIES_ORDER = ['sheep', 'hen', 'pig', 'goose'];
  /** The flock for a request: a preset's mix, or the custom counts interleaved so the species are spread over the yard. */
  function flockFor(args) {
    deps();
    var diff = ['easy', 'normal', 'hard', 'custom'].indexOf(args.difficulty) >= 0 ? args.difficulty : 'normal';
    // ⛔ a preset's mix may be SHORTER than its count and repeats (easy: 3 entries, 6 head). The capture found easy
    // spawning 3 animals when this sliced the mix to the count instead of cycling it.
    if (diff !== 'custom') { var D = CORE.DIFFS[diff], m = []; for (var k = 0; k < D.count; k++) m.push(D.mix[k % D.mix.length]); return { diff: diff, mix: m, frames: D.frames }; }
    var counts = { sheep: Math.max(0, Math.min(32, num(args.sheep, 0))), hen: Math.max(0, Math.min(32, num(args.hens, 0))), pig: Math.max(0, Math.min(32, num(args.pigs, 0))), goose: Math.max(0, Math.min(32, num(args.geese, 0))) };
    var mix = [], more = true;
    while (more && mix.length < 32) { more = false; for (var i = 0; i < 4; i++) { var sp = SPECIES_ORDER[i]; if (counts[sp] > 0) { mix.push(sp); counts[sp]--; more = true; } } }
    if (!mix.length) mix.push('sheep');
    return { diff: 'custom', mix: mix.slice(0, 32), frames: mix.length * 15 * 60 };
  }
  /**
   * Start a round on the current map. Returns false (and says why in the console) when the map has no pen tiles or no
   * tile an animal could start on.
   */
  function start(args, mapId, eventId) {
    deps();
    var r = rec(); if (r.round || r.tally) { console.warn('Round-up: a round is already running.'); return false; }
    var pen = num(args.penRegion, 0) > 0 ? num(args.penRegion, 0) : P.penRegion;
    var sv = surveyPen(pen, $gamePlayer.x, $gamePlayer.y);
    if (!sv) { console.warn('Round-up: no tile on this map has region ' + pen + ' (paint the pen with it).'); return false; }
    if (!sv.spawn.length) { console.warn('Round-up: no tile outside the pen can reach its gate within ' + P.yardSize + ' steps.'); return false; }
    var fl = flockFor(args), secs = num(args.seconds, 0);
    var seed = String(args.seed || '').trim() !== '' && isFinite(Number(args.seed)) ? (Number(args.seed) >>> 0) : (CORE.hashString('m' + mapId + 'e' + eventId + 'n' + r.count + 't' + Graphics.frameCount) >>> 0);
    r.req = { mapId: mapId, eventId: eventId, title: String(args.title || '').trim() || ($gameMap.displayName() || 'The round-up'), difficulty: fl.diff, seed: seed,
      penRegion: pen, blocked: standingEvents(), lure: P.trough ? sv.lure : null, box: sv.box, spawnSet: sv.spawn,
      vars: { penned: num(args.pennedVariableId, 0), stars: num(args.starsVariableId, 0), secs: num(args.secondsVariableId, 0) },
      switchId: num(args.switchId, 0), commonEventId: num(args.commonEventId, 0), mix: fl.mix };
    var field = makeField(r.req);
    r.round = CORE.createRound(seed, field, { count: fl.mix.length, mix: fl.mix, frames: secs > 0 ? Math.round(secs * 60) : fl.frames });
    r.tally = null; RT.field = field; RT.bound = r.round; RT.banner = 150; RT.tallyAge = 0; RT.fx.length = 0; RT.calm = null;
    return true;
  }
  /** The live round with its field attached (after a load the field is rebuilt from the saved request: wing §13). */
  function live() {
    var r = rec(); if (!r || !r.round) return null;
    if (RT.bound !== r.round) { deps(); RT.field = makeField(r.req); CORE.bind(r.round, RT.field); RT.bound = r.round; RT.calm = null; }
    return r.round;
  }
  function end() { var r = rec(), g = live(); if (g && g.phase === 'play') { g.phase = 'over'; g.endFrame = g.frame; openTally(); } }
  function isOpen() { var r = rec(); return !!(r && (r.round || r.tally)); }
  function isTallyOpen() { var r = rec(); return !!(r && r.tally); }
  function onYard() { var r = rec(); return !!(r && r.round && !r.tally && $gameMap && $gameMap.mapId() === r.req.mapId); }
  /** the player's centre in the core's tile units (tile centres at +0.5; _realX is the engine's own sub-tile position) */
  function playerX() { return $gamePlayer._realX + 0.5; }
  function playerY() { return $gamePlayer._realY + 0.5; }
  var wantWhistle = false;
  function whistle() { if (onYard()) wantWhistle = true; }

  /** One frame of the round. Paused off the yard, while a message shows, while another event runs, while the board is open. */
  function update() {
    var r = rec(); if (!r) return;
    RT.frame++;
    if (r.tally) { RT.tallyAge++; if (RT.tallyAge > 40 && (Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered())) closeTally(); return; }
    var g = live(); if (!g) return;
    if (g.phase !== 'play') { openTally(); return; }
    if ($gameMap.mapId() !== r.req.mapId || $gameMap.isEventRunning() || $gameMessage.isBusy()) { wantWhistle = false; return; }
    // ⛔ OK is read HERE, every frame: MZ only reaches Game_Player.triggerAction when the player stands still and the
    // scene is not fading (rmmz_objects.js:8377, rmmz_scenes.js:848), and a herder whistles while WALKING. Found by
    // in_engine.js: OK pressed mid-stride did nothing. (The triggerButtonAction seam below only stops OK starting events.)
    if (Input.isTriggered('ok') && $gamePlayer.canMove()) wantWhistle = true;
    if (RT.banner > 0) RT.banner--;
    if (!RT.calm || RT.calm.length !== g.n) { RT.calm = new Uint8Array(g.n); for (var j = 0; j < g.n; j++) RT.calm[j] = g.animals[j].penned ? 2 : 1; }
    var px = playerX(), py = playerY(), was = g.penned;
    var blew = CORE.step(g, px, py, wantWhistle); wantWhistle = false;
    if (blew) { RT.fx.push(1); playSe(P.se.whistle, 70); }
    for (var i = 0; i < g.n; i++) {
      var a = g.animals[i];
      if (a.penned) { if (RT.calm[i] !== 2) { RT.calm[i] = 2; RT.fx.push(100 + i); if (RT.playSe <= RT.frame) { playSe(P.se[a.species], 60); RT.playSe = RT.frame + 20; } } continue; }
      // startled: calm -> near (once per scare); the sound is throttled so a flock does not shout in unison
      if (a.near && RT.calm[i] === 1) { RT.calm[i] = 0; RT.fx.push(200 + i); if (RT.playSe <= RT.frame) { playSe(P.se[a.species], 45); RT.playSe = RT.frame + 30; } }
      else if (!a.near && RT.calm[i] === 0) RT.calm[i] = 1;
    }
    if (g.penned !== was) RT.hudDirty = true;
    if (g.phase !== 'play') { playSe(P.se.bell, 90); openTally(); }
  }
  /** The bell: score it and open the board. */
  function openTally() {
    var r = rec(), g = live(); if (!g || r.tally) return;
    var res = CORE.results(g), looks = [], penned = [];
    for (var i = 0; i < g.n; i++) { penned.push(!!g.animals[i].penned); }
    var dl = { easy: 'Easy', normal: 'Normal', hard: 'Hard', custom: 'Round-up' }[r.req.difficulty] || 'Round-up';
    r.tally = { title: r.req.title, sub: dl + ' · ' + g.n + ' head', penned: penned, pennedCount: res.penned, total: g.n, secsLeft: res.secondsLeft, stars: res.stars, won: res.won, foot: 'Press OK to close the board.' };
    RT.tallyAge = 0;
  }
  /** Close the board: set the variables and switch, run the common event. */
  function closeTally() {
    var r = rec(), T = r.tally; if (!T) return;
    var q = r.req;
    if (q.vars.penned > 0) $gameVariables.setValue(q.vars.penned, T.pennedCount);
    if (q.vars.stars > 0) $gameVariables.setValue(q.vars.stars, T.stars);
    if (q.vars.secs > 0) $gameVariables.setValue(q.vars.secs, T.secsLeft);
    if (q.switchId > 0 && T.won) $gameSwitches.setValue(q.switchId, true);
    if (q.commonEventId > 0) $gameTemp.reserveCommonEvent(q.commonEventId);
    r.last = { penned: T.pennedCount, total: T.total, stars: T.stars, secondsLeft: T.secsLeft, won: T.won, difficulty: q.difficulty, seed: q.seed };
    r.tally = null; r.round = null; r.count++; RT.fx.length = 0; RT.bound = null; RT.field = null;
    // the key that closed the board is still "triggered" this frame (Table Service's in-engine finding): it belongs to the board
    Input.clear(); TouchInput.clear();
  }

  // -------------------------------------------------------------------------------------------------------------------
  // The yard layer: everything drawn over the map while a round is open
  // -------------------------------------------------------------------------------------------------------------------
  var CELL = 48, WALK = [0, 1, 2, 1];   // MZ's own walk cycle (Game_CharacterBase pattern 0,1,2,1); one copy, never a literal per frame
  function bmp(w, h, fn) { var b = new Bitmap(w, h); fn(b.context, w, h); b._baseTexture.update(); return b; }
  function RoundupLayer() { this.initialize.apply(this, arguments); }
  RoundupLayer.prototype = Object.create(Sprite.prototype);
  RoundupLayer.prototype.constructor = RoundupLayer;
  /** Built from the saved state, so a layer rebuilt after the menu or a load shows exactly what was there. */
  RoundupLayer.prototype.initialize = function (spriteset) {
    Sprite.prototype.initialize.call(this);
    deps();
    var r = rec(), g = live(), self = this, i;
    this._ss = spriteset; this._tm = spriteset._tilemap; this._looks = [];
    this._shared = { startle: bmp(22, 28, DRAW.drawStartle), feather: bmp(12, 16, function (c, w, h) { DRAW.drawFeather(c, w, h); }), twinkle: bmp(16, 16, DRAW.drawTwinkle),
      ring: bmp(96, 96, DRAW.drawRing), note: bmp(14, 18, DRAW.drawNote), dust: [] };
    for (i = 0; i < 4; i++) (function (f) { self._shared.dust.push(bmp(22, 18, function (c, w, h) { DRAW.drawDust(c, w, h, f); })); })(i);
    // one sheet per animal: 3 steps x 4 facings, drawn once from the round's seed
    this._animals = [];
    for (i = 0; i < g.n; i++) {
      var a = g.animals[i], L = DRAW.lookFor(r.req.seed, a.species, i); this._looks.push(L);
      var sp = new Sprite(bmp(CELL * 3, CELL * 4, function (c) { DRAW.drawAnimalSheet(c, L, CELL); })); sp.anchor.set(0.5, 1); sp.z = 3; sp.setFrame(CELL, 0, CELL, CELL);
      var mark = new Sprite(this._shared.startle); mark.anchor.set(0.5, 1); mark.z = 8; mark.visible = false;
      this._tm.addChild(sp); this._tm.addChild(mark);
      this._animals.push({ sp: sp, mark: mark, markLife: 0, walk: 0, lastX: a.x, lastY: a.y, hop: 0 });
    }
    // effects pools: dust (6), feathers (6), twinkles (4), the whistle's rings (2) and notes (3)
    this._dust = []; this._feathers = []; this._twinkles = []; this._rings = []; this._notes = [];
    for (i = 0; i < 6; i++) { var d = new Sprite(this._shared.dust[0]); d.anchor.set(0.5, 1); d.z = 2; d.visible = false; d._life = 0; d._f = 0; this._tm.addChild(d); this._dust.push(d); }
    for (i = 0; i < 6; i++) { var f = new Sprite(this._shared.feather); f.anchor.set(0.5, 0.5); f.z = 8; f.visible = false; f._life = 0; f._vx = 0; f._vy = 0; this._tm.addChild(f); this._feathers.push(f); }
    for (i = 0; i < 4; i++) { var t = new Sprite(this._shared.twinkle); t.anchor.set(0.5, 0.5); t.z = 8; t.visible = false; t._life = 0; t._i = 0; this._tm.addChild(t); this._twinkles.push(t); }
    for (i = 0; i < 2; i++) { var rg = new Sprite(this._shared.ring); rg.anchor.set(0.5, 0.5); rg.z = 1; rg.visible = false; rg._life = 0; this._tm.addChild(rg); this._rings.push(rg); }
    for (i = 0; i < 3; i++) { var nt = new Sprite(this._shared.note); nt.anchor.set(0.5, 1); nt.z = 8; nt.visible = false; nt._life = 0; nt._k = i; this._tm.addChild(nt); this._notes.push(nt); }
    // the trough, at the lure point, in the tilemap so it sorts with the animals
    this._trough = null;
    if (r.req.lure) { this._trough = new Sprite(bmp(96, 48, DRAW.drawTrough)); this._trough.anchor.set(0.5, 0.85); this._trough.z = 3; this._tm.addChild(this._trough); }
    // screen layer: the HUD, the whistle button, the banner, the board
    this._over = new Sprite(); spriteset.addChild(this._over);
    this._hud = new Sprite(new Bitmap(330, 66)); this._hudKey = -1; this._over.addChild(this._hud);
    this._hud.x = /right/.test(P.hudCorner) ? Graphics.width - 330 - 8 : 8; this._hud.y = /bottom/.test(P.hudCorner) ? Graphics.height - 66 - 8 : 8;
    this._btn = new Sprite(new Bitmap(64, 64)); this._btnKey = -1; this._btn.visible = P.whistleButton;
    this._btn.x = /right/.test(P.hudCorner) ? 12 : Graphics.width - 64 - 12; this._btn.y = Graphics.height - 64 - 12; this._over.addChild(this._btn);
    RT.button.x = this._btn.x + 32; RT.button.y = this._btn.y + 32; RT.button.r = P.whistleButton ? 30 : 0;
    this._banner = new Sprite(new Bitmap(460, 110)); this._banner.anchor.set(0.5, 0); this._banner.x = Graphics.width / 2; this._banner.visible = false; this._bannerDrawn = false; this._over.addChild(this._banner);
    this._board = new Sprite(); this._board.visible = false; this._boardDrawn = false; this._over.addChild(this._board);
    this._pt = { x: 0, y: 0 };
    this.placeAll(true);
  };
  /** screen position of a point in the core's tile units (the foot of an animal) */
  RoundupLayer.prototype.screenOf = function (x, y, out) {
    var tw = $gameMap.tileWidth(), th = $gameMap.tileHeight();
    out.x = Math.round($gameMap.adjustX(x - 0.5) * tw + tw / 2); out.y = Math.round($gameMap.adjustY(y - 0.5) * th + th / 2 + th * 0.28); return out;
  };
  RoundupLayer.prototype.update = function () {
    Sprite.prototype.update.call(this);
    var r = rec(); if (!r) return;
    var g = r.round ? live() : null;
    if (g) {
      while (RT.fx.length) { var e = RT.fx.shift(); if (e === 1) this.launchWhistle(); else if (e >= 200) this.startle(e - 200, g); else if (e >= 100) this.penned(e - 100, g); }
      this.placeAll(false);
      this.drawHud(r, g);
      this.drawButton(g);
    }
    this.updateEffects();
    this.updateBanner(r, g);
    this.updateBoard(r.tally);
  };
  /** Each animal: position, facing, walk step (from distance actually travelled), a hop when penned, its mark. Allocates nothing. */
  RoundupLayer.prototype.placeAll = function (instant) {
    var g = live(); if (!g) return;
    for (var i = 0; i < this._animals.length && i < g.n; i++) {
      var A = this._animals[i], a = g.animals[i], sp = A.sp, pt = this.screenOf(a.x, a.y, this._pt);
      var mv = Math.abs(a.x - A.lastX) + Math.abs(a.y - A.lastY); A.lastX = a.x; A.lastY = a.y;
      A.walk += mv * 9; var step = mv < 0.004 ? 1 : WALK[Math.floor(A.walk) % 4];
      var row = a.face === 2 ? 0 : a.face === 4 ? 1 : a.face === 6 ? 2 : 3;
      sp.setFrame(step * CELL, row * CELL, CELL, CELL);
      if (A.hop > 0) A.hop--;
      sp.x = pt.x; sp.y = pt.y - (A.hop > 0 ? Math.sin(A.hop / 18 * Math.PI) * 6 : 0);
      // a running animal kicks up dust now and then
      if (!instant && mv > a.S.speed * 0.7 && (RT.frame + i * 7) % 14 === 0) this.dust(pt.x, pt.y);
      if (A.markLife > 0) { A.markLife--; A.mark.visible = true; A.mark.x = pt.x; A.mark.y = pt.y - 30 - (A.markLife > 30 ? (36 - A.markLife) : 6); A.mark.opacity = 255 * Math.min(1, A.markLife / 10); }
      else A.mark.visible = false;
    }
    if (this._trough && rec().req.lure) { var tp = this.screenOf(rec().req.lure.x, rec().req.lure.y, this._pt); this._trough.x = tp.x; this._trough.y = tp.y; }
  };
  RoundupLayer.prototype.startle = function (i, g) {
    var A = this._animals[i]; if (!A) return; A.markLife = 36;
    var a = g.animals[i]; if (a.species === 'hen' || a.species === 'goose') { var pt = this.screenOf(a.x, a.y, this._pt); this.feather(pt.x, pt.y - 14, a.species === 'goose' ? '#f4f1ea' : null); this.feather(pt.x + 4, pt.y - 10, null); }
  };
  RoundupLayer.prototype.penned = function (i, g) {
    var A = this._animals[i]; if (!A) return; A.hop = 18; A.markLife = 0;
    for (var k = 0; k < this._twinkles.length; k++) { var t = this._twinkles[k]; if (!t.visible) { t.visible = true; t._life = 40; t._i = i; break; } }
  };
  RoundupLayer.prototype.dust = function (x, y) {
    for (var k = 0; k < this._dust.length; k++) { var d = this._dust[k]; if (!d.visible) { d.visible = true; d._life = 24; d.x = x; d.y = y; return; } }
  };
  RoundupLayer.prototype.feather = function (x, y, col) {
    for (var k = 0; k < this._feathers.length; k++) { var f = this._feathers[k]; if (!f.visible) { f.visible = true; f._life = 40; f.x = x; f.y = y; f._vx = ((RT.frame * 7 + k * 13) % 11 - 5) * 0.12; f._vy = -0.8; f.rotation = 0; return; } }
  };
  RoundupLayer.prototype.launchWhistle = function () {
    var px = $gamePlayer.screenX(), py = $gamePlayer.screenY() - 20, k;
    for (k = 0; k < this._rings.length; k++) { var rg = this._rings[k]; rg.visible = true; rg._life = 30 + k * 10; rg.x = px; rg.y = py + 14; }
    for (k = 0; k < this._notes.length; k++) { var nt = this._notes[k]; nt.visible = true; nt._life = 40 + k * 8; nt.x = px + (k - 1) * 12; nt.y = py - 14; }
  };
  /** Every pooled effect ages one frame. Allocates nothing. */
  RoundupLayer.prototype.updateEffects = function () {
    var k, g = rec().round ? live() : null;
    for (k = 0; k < this._dust.length; k++) { var d = this._dust[k]; if (!d.visible) continue; d._life--; var fi = Math.min(3, Math.floor((24 - d._life) / 6)); if (d._f !== fi) { d._f = fi; d.bitmap = this._shared.dust[fi]; } d.y -= 0.15; if (d._life <= 0) d.visible = false; }
    for (k = 0; k < this._feathers.length; k++) { var f = this._feathers[k]; if (!f.visible) continue; f._life--; f.x += f._vx + Math.sin(f._life * 0.25) * 0.4; f.y += f._vy; f._vy = Math.min(0.5, f._vy + 0.04); f.rotation = Math.sin(f._life * 0.2) * 0.6; f.opacity = 255 * Math.min(1, f._life / 12); if (f._life <= 0) f.visible = false; }
    for (k = 0; k < this._twinkles.length; k++) { var t = this._twinkles[k]; if (!t.visible) continue; t._life--; var A = this._animals[t._i]; if (A) { t.x = A.sp.x + Math.cos(t._life * 0.3) * 10; t.y = A.sp.y - 34 + Math.sin(t._life * 0.3) * 4; } t.scale.x = t.scale.y = 0.6 + Math.sin(t._life / 40 * Math.PI) * 0.7; t.opacity = 255 * Math.min(1, t._life / 10); if (t._life <= 0) t.visible = false; }
    for (k = 0; k < this._rings.length; k++) { var rg = this._rings[k]; if (!rg.visible) continue; rg._life--; var age = 1 - rg._life / 40; rg.scale.x = rg.scale.y = 0.4 + age * 2.6; rg.opacity = 255 * Math.max(0, 1 - age); rg.x = $gamePlayer.screenX(); rg.y = $gamePlayer.screenY() - 6; if (rg._life <= 0) rg.visible = false; }
    for (k = 0; k < this._notes.length; k++) { var nt = this._notes[k]; if (!nt.visible) continue; nt._life--; nt.y -= 0.7; nt.x += Math.sin((nt._life + nt._k * 9) * 0.25) * 0.6; nt.opacity = 255 * Math.min(1, nt._life / 14); if (nt._life <= 0) nt.visible = false; }
  };
  RoundupLayer.prototype.drawHud = function (r, g) {
    var left = Math.max(0, g.frames - g.frame), secs = Math.ceil(left / 60), key = secs * 100 + g.penned;
    this._hud.visible = !r.tally && !$gameMessage.isBusy();
    if (key === this._hudKey) return; this._hudKey = key;
    var H = this._hudInfo || (this._hudInfo = { looks: this._looks, penned: [], frac: 0, secs: 0 });
    H.penned.length = g.n; for (var i = 0; i < g.n; i++) H.penned[i] = !!g.animals[i].penned;
    H.frac = left / g.frames; H.secs = secs;
    DRAW.drawHud(this._hud.bitmap.context, 330, 66, H); this._hud.bitmap._baseTexture.update();
  };
  RoundupLayer.prototype.drawButton = function (g) {
    if (!P.whistleButton) return;
    var ready = Math.max(0, Math.min(1, 1 - g.whistleCool / CORE.WHISTLE_COOL)), key = Math.round(ready * 40);
    this._btn.visible = !rec().tally && !$gameMessage.isBusy();
    if (key === this._btnKey) return; this._btnKey = key;
    var b = this._btn.bitmap; b.clear(); DRAW.drawWhistleButton(b.context, 64, 64, ready); b._baseTexture.update();
  };
  RoundupLayer.prototype.updateBanner = function (r, g) {
    var on = !!(g && RT.banner > 0 && !r.tally);
    if (on && !this._bannerDrawn) { var dl = { easy: 'Easy', normal: 'Normal', hard: 'Hard', custom: '' }[r.req.difficulty]; DRAW.drawBanner(this._banner.bitmap.context, 460, 110, r.req.title, 'Pen ' + g.n + ' before the bell' + (dl ? ' · ' + dl : '')); this._banner.bitmap._baseTexture.update(); this._bannerDrawn = true; }
    this._banner.visible = on;
    if (on) { var t = 150 - RT.banner; this._banner.y = t < 20 ? -110 + t * 6 : (RT.banner < 20 ? 10 - (20 - RT.banner) * 6 : 10); }
  };
  RoundupLayer.prototype.updateBoard = function (T) {
    if (!T) { this._board.visible = false; this._boardDrawn = false; return; }
    if (!this._boardDrawn) { if (!this._board.bitmap) this._board.bitmap = new Bitmap(Graphics.width, Graphics.height); DRAW.drawTally(this._board.bitmap.context, Graphics.width, Graphics.height, { title: T.title, sub: T.sub, looks: this._looks, penned: T.penned, pennedCount: T.pennedCount, total: T.total, secsLeft: T.secsLeft, stars: T.stars, foot: T.foot }); this._board.bitmap._baseTexture.update(); this._boardDrawn = true; }
    this._board.visible = true; this._board.opacity = Math.min(255, RT.tallyAge * 16);
    this._hud.visible = false; this._btn.visible = false;
  };
  RoundupLayer.prototype.teardown = function () {
    var tm = this._tm, i;
    for (i = 0; i < this._animals.length; i++) { tm.removeChild(this._animals[i].sp); tm.removeChild(this._animals[i].mark); }
    [this._dust, this._feathers, this._twinkles, this._rings, this._notes].forEach(function (pool) { pool.forEach(function (s) { tm.removeChild(s); }); });
    if (this._trough) tm.removeChild(this._trough);
    if (this._over.parent) this._over.parent.removeChild(this._over);
    if (this.parent) this.parent.removeChild(this);
    this._animals = [];
  };

  /** Called by the spriteset each frame: build the layer when a round opens here, tear it down when it closes. */
  function updateSpriteset(ss) {
    var r = rec(), want = !!(r && (r.round || r.tally) && r.req && $gameMap.mapId() === r.req.mapId && r.round);
    if (want && ss._csafRoundup && ss._csafRoundup._round !== r.round) { ss._csafRoundup.teardown(); ss._csafRoundup = null; }
    if (want && !ss._csafRoundup) { ss._csafRoundup = new RoundupLayer(ss); ss._csafRoundup._round = r.round; ss.addChild(ss._csafRoundup); }
    else if (!want && ss._csafRoundup) { ss._csafRoundup.teardown(); ss._csafRoundup = null; }
  }

  // -------------------------------------------------------------------------------------------------------------------
  // Engine seams (each extends a core method and calls the original)
  // -------------------------------------------------------------------------------------------------------------------
  PluginManager.registerCommand(NAME, 'start', function (args) { start(args, $gameMap.mapId(), this.eventId ? this.eventId() : 0); });
  PluginManager.registerCommand(NAME, 'end', function () { end(); });

  var _mapUpdate = Game_Map.prototype.update;
  Game_Map.prototype.update = function (sceneActive) { _mapUpdate.apply(this, arguments); if (sceneActive) update(); };
  /** During a round OK is the whistle (read in update()), so it must not ALSO start the event the player faces. */
  var _trigger = Game_Player.prototype.triggerButtonAction;
  Game_Player.prototype.triggerButtonAction = function () {
    if (onYard() && Input.isTriggered('ok')) return true;
    return _trigger.apply(this, arguments);
  };
  /** A press on the whistle button whistles and does not walk the player there. */
  var _mapTouch = Scene_Map.prototype.processMapTouch;
  Scene_Map.prototype.processMapTouch = function () {
    if (onYard() && RT.button.r > 0) {
      if (TouchInput.isTriggered()) { var dx = TouchInput.x - RT.button.x, dy = TouchInput.y - RT.button.y; RT.button.held = dx * dx + dy * dy <= RT.button.r * RT.button.r; if (RT.button.held) { whistle(); return; } }
      if (RT.button.held) { if (!TouchInput.isPressed()) RT.button.held = false; return; }
    }
    _mapTouch.apply(this, arguments);
  };
  var _canMove = Game_Player.prototype.canMove;
  Game_Player.prototype.canMove = function () { if (isTallyOpen() && $gameMap.mapId() === rec().req.mapId) return false; return _canMove.apply(this, arguments); };
  /** The map's name window closes while a round is open, exactly as MZ closes it under a message (rmmz_scenes.js
   *  updateMapNameWindow): looked at in-engine 2026-10-11, a round started on map entry drew the name over the clock. */
  var _nameWin = Scene_Map.prototype.updateMapNameWindow;
  // at once, not over close()'s 8-frame animation (in_engine: 6 frames in, the name still drew over the clock)
  Scene_Map.prototype.updateMapNameWindow = function () { _nameWin.apply(this, arguments); var w = this._mapNameWindow; if (isOpen() && w) { w._showCount = 0; w.contentsOpacity = 0; w.close(); } };
  var _menuEnabled = Scene_Map.prototype.isMenuEnabled;
  Scene_Map.prototype.isMenuEnabled = function () { if (isOpen() && !P.allowMenu) return false; return _menuEnabled.apply(this, arguments); };
  var _ssUpdate = Spriteset_Map.prototype.update;
  Spriteset_Map.prototype.update = function () { _ssUpdate.apply(this, arguments); updateSpriteset(this); };

  return {
    VERSION: '1.0.0', P: P, RT: RT, deps: deps, rec: rec, start: start, end: end, isOpen: isOpen, isTallyOpen: isTallyOpen, live: live,
    update: update, whistle: whistle, closeTally: closeTally, surveyPen: surveyPen, makeField: makeField, flockFor: flockFor,
    lastResult: function () { var r = rec(); return r ? r.last : null; }, RoundupLayer: RoundupLayer,
  };
}());
