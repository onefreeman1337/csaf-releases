/*:
 * @target MZ
 * @plugindesc [v1.0.0] Round-up 1/3 - the rules: a flock that flees, flocks, bolts and charges, the pen, the bell. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * RoundupCore.js holds the rules Round-up uses and touches no part of the engine. Turn it on together with
 * RoundupDraw.js and Roundup.js; the order does not matter. See Readme_for_Users.md.
 */
/* RoundupCore - pure rules, no engine code, runs in Node for the tests (module.exports) and in MZ (window.RoundupCore).
 * Positions are in TILE units (floats). The field supplies canStep(x, y, d), the engine's own edge rule
 * (Game_CharacterBase.isMapPassable, rmmz_objects.js:7115), and isPen(x, y). Copyright (c) 2026 Core Systems Asset Factory. */
var RoundupCore = (function () {
  'use strict';
  function mix(a, b) { var h = (a ^ Math.imul(b | 0, 0x9E3779B1)) >>> 0; h = Math.imul(h ^ (h >>> 16), 0x85EBCA6B) >>> 0; h = Math.imul(h ^ (h >>> 13), 0xC2B2AE35) >>> 0; return (h ^ (h >>> 16)) >>> 0; }
  function hashString(s) { var h = 2166136261 >>> 0; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; } return h >>> 0; }
  function rand(st) { st.rs = (st.rs + 0x6D2B79F5) | 0; var t = st.rs; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }

  /** speeds in tiles per frame (the MZ player walks 4 / 60 = 0.067 at speed 4), radii in tiles */
  var SPECIES = {
    sheep: { speed: 0.055, flee: 3.2, size: 0.35, flock: 1 },
    hen: { speed: 0.07, flee: 2.4, size: 0.25, flock: 0 },
    pig: { speed: 0.05, bolt: 0.12, flee: 2.2, size: 0.4, flock: 0 },
    goose: { speed: 0.06, flee: 2.6, size: 0.3, flock: 0.4 },
  };
  /** presets: the flock is mix[0..count-1] in order (a mix shorter than count repeats). The counts and clocks are SET FROM
   *  MEASUREMENT (balance_levers.js time, 2026-10-11): ~15 s per animal for a scripted competent herder, so 6/7/9 animals,
   *  and each clock placed where 40-80% of competent rounds pen everything on the recommended yard (Readme). */
  var DIFFS = {
    // clock off, 100 seeds: competent p50/p60 = easy 78/92 s, normal 107/117 s, hard 126/142 s -> 90, 115, 135 s
    easy: { count: 6, mix: ['sheep', 'sheep', 'hen'], frames: 5400 },
    normal: { count: 7, mix: ['sheep', 'hen', 'pig', 'sheep', 'sheep', 'hen', 'pig'], frames: 6900 },
    hard: { count: 9, mix: ['sheep', 'hen', 'pig', 'goose', 'sheep', 'hen', 'pig', 'goose', 'sheep'], frames: 8100 },
  };
  var EPS = 0.001, WHISTLE_R = 4, WHISTLE_T = 40, WHISTLE_COOL = 300, CALM_CAP = 0.33, STUCK_T = 12, DODGE_T = 26, S_MIN = 0.3;
  var CALM = 0, BOLT = 1, STOP = 2, CHARGE = 3;
  var LURE = { sheep: 0.3, hen: 1, pig: 1, goose: 0.5 };

  /** a tile an animal can stand on: it can step out of it in at least one direction */
  function open(f, x, y) { return f.canStep(x, y, 2) || f.canStep(x, y, 4) || f.canStep(x, y, 6) || f.canStep(x, y, 8); }
  /**
   * A round on a field. The flock is generated from the seed: species from the mix, placed on open tiles outside the pen.
   * @param {number} seed @param {{W:number,H:number,canStep:function,isPen:function}} field @param {{count:number,mix:string[],frames:number}} o
   */
  function createRound(seed, field, o) {
    // the field may narrow where animals start: box {x0,y0,x1,y1} (inclusive) to sample in, canSpawn(x, y) to accept a tile
    var st = { rs: mix(hashString('roundup'), seed >>> 0) | 0 }, n = Math.max(1, Math.min(32, o.count | 0)), animals = [], tries = 0;
    var bx0 = field.box ? field.box.x0 : 0, by0 = field.box ? field.box.y0 : 0, bw = field.box ? field.box.x1 - bx0 + 1 : field.W, bh = field.box ? field.box.y1 - by0 + 1 : field.H;
    while (animals.length < n && tries++ < 20000) {
      var x = bx0 + Math.floor(rand(st) * bw), y = by0 + Math.floor(rand(st) * bh);
      if (field.isPen(x, y) || !open(field, x, y) || (field.canSpawn && !field.canSpawn(x, y))) continue;
      var sp = o.mix[animals.length % o.mix.length];
      if (!SPECIES[sp]) sp = 'sheep';
      animals.push({ species: sp, S: null, x: x + 0.2 + rand(st) * 0.6, y: y + 0.2 + rand(st) * 0.6, vx: 0, vy: 0, penned: false, state: CALM, timer: 0, hx: 0, hy: 0, face: 2,
        near: false, hit: false, stuck: 0, dodge: 0, dodges: 0 });
    }
    var g = { f: null, st: st, n: animals.length, animals: animals, frames: Math.max(60, o.frames | 0), frame: 0, endFrame: 0, phase: 'play', penned: 0,
      whistleT: 0, whistleCool: 0, wx: 0, wy: 0, gx: 0, gy: 0 };
    return bind(g, field);
  }
  /**
   * Attach a field and each animal's species table to a round WITHOUT making them part of it: both are defined
   * non-enumerable, so a save (JsonEx walks Object.keys) holds the round's numbers only and never a function or a copy of
   * a table (wing §13). Call it again after a load with a freshly built field.
   */
  function bind(g, field) {
    Object.defineProperty(g, 'f', { value: field, writable: true, enumerable: false, configurable: true });
    for (var i = 0; i < g.animals.length; i++) Object.defineProperty(g.animals[i], 'S', { value: SPECIES[g.animals[i].species] || SPECIES.sheep, writable: true, enumerable: false, configurable: true });
    return g;
  }
  /** the desired change of an unpenned animal's velocity this frame, by species. Allocates nothing. */
  function steer(g, a, i, px, py) {
    var S = a.S, dx = a.x - px, dy = a.y - py, dist = Math.sqrt(dx * dx + dy * dy) || 0.0001, ax = 0, ay = 0, near = dist < S.flee, j, b;
    a.near = near;
    // a DODGE in progress (see dodge()) holds its velocity until it ends
    if (a.dodge > 0) { a.dodge--; return; }
    // species states
    if (a.species === 'pig') {
      if (a.state === BOLT) { a.timer--; a.vx = dx / dist * S.bolt; a.vy = dy / dist * S.bolt; if (a.timer <= 0) { a.state = STOP; a.timer = 60; } return; }
      if (a.state === STOP) { a.timer--; a.vx = 0; a.vy = 0; if (a.timer <= 0) a.state = CALM; return; }
      if (near) { a.state = BOLT; a.timer = 30; return; }
    }
    if (a.species === 'goose') {
      if (a.state === CHARGE) { a.timer--; a.vx = -dx / dist * S.speed * 1.4; a.vy = -dy / dist * S.speed * 1.4; if (a.timer <= 0) a.state = CALM; return; }
      if (dist < 1.4 && rand(g.st) < 0.02) { a.state = CHARGE; a.timer = 18; return; }
    }
    if (near) { var k = (S.flee - dist) / S.flee; ax += dx / dist * k * S.speed * 0.6; ay += dy / dist * k * S.speed * 0.6; }
    // a wander heading, re-drawn every 14-30 frames: calm animals graze along it slowly; a startled hen ZIG-ZAGS along it
    // (a calm hen used to run at full speed all the time: wander x damping capped her at 0.07, faster than a walking
    // player, and trace_round.js showed the scripted herder spending a whole round chasing hens, 2026-10-11)
    if (--a.timer <= 0) { var t = rand(g.st) * Math.PI * 2; a.hx = Math.cos(t); a.hy = Math.sin(t); a.timer = 14 + Math.floor(rand(g.st) * 16); }
    var wander = a.species === 'hen' ? (near ? 0.3 : 0.12) : (near ? 0 : 0.05);
    ax += a.hx * S.speed * wander; ay += a.hy * S.speed * wander;
    if (S.flock) {
      var cx = 0, cy = 0, avx = 0, avy = 0, cn = 0, sx = 0, sy = 0;
      // flock-mates ALREADY IN THE PEN still draw the rest (real sheep follow the ones through the gate): balance_probe v1
      // read a competent herder at 2-5% fully cleared on easy while the cohesion loop ignored penned animals
      for (j = 0; j < g.n; j++) { if (j === i) continue; b = g.animals[j]; if (b.species !== a.species) continue; var ddx = a.x - b.x, ddy = a.y - b.y, d2 = ddx * ddx + ddy * ddy;
        // a flock senses itself across 7 tiles (core.test 4, 2026-10-11: at 3 tiles a scattered flock never regrouped and
        // sheep spread as wide as hens)
        if (d2 < 49) { cx += b.x; cy += b.y; avx += b.vx; avy += b.vy; cn++; } if (d2 < 0.5 && d2 > 0) { sx += ddx / d2; sy += ddy / d2; } }
      if (cn) { ax += ((cx / cn) - a.x) * 0.004 * S.flock + (avx / cn - a.vx) * 0.05 * S.flock; ay += ((cy / cn) - a.y) * 0.004 * S.flock + (avy / cn - a.vy) * 0.05 * S.flock; }
      ax += sx * 0.002; ay += sy * 0.002;
    }
    // the FEED LURE (opt-in: the field supplies lure {x, y}, a point just inside the gate): an animal within 3.5 tiles of it
    // drifts toward it, hens and pigs most (they do not flock); balance_levers measures it (2026-10-11, balance OPEN)
    if (g.f.lure) { var lx = g.f.lure.x - a.x, ly = g.f.lure.y - a.y, ld = Math.sqrt(lx * lx + ly * ly) || 1; if (ld < 3.5) { var lw = LURE[a.species] || 0; ax += lx / ld * 0.004 * lw; ay += ly / ld * 0.004 * lw; } }
    // the whistle: animals near where it blew drift toward the group's centre for its 40 frames
    if (g.whistleT > 0) { var wdx = a.x - g.wx, wdy = a.y - g.wy; if (wdx * wdx + wdy * wdy < WHISTLE_R * WHISTLE_R) { ax += (g.gx - a.x) * 0.012; ay += (g.gy - a.y) * 0.012; } }
    a.vx = a.vx * (near || g.whistleT > 0 ? 0.9 : 0.85) + ax; a.vy = a.vy * (near || g.whistleT > 0 ? 0.9 : 0.85) + ay;
    // a calm animal grazes (a third of its running speed); only a startled one, or one answering the whistle, runs
    var sp = Math.sqrt(a.vx * a.vx + a.vy * a.vy), cap = near ? S.speed : g.whistleT > 0 ? S.speed * 0.6 : S.speed * CALM_CAP; if (sp > cap) { a.vx *= cap / sp; a.vy *= cap / sp; }
  }
  /** move by the velocity, one axis at a time; a tile boundary is crossed only through an edge the field allows, and at
   *  most ONE tile boundary per frame; a penned animal never steps out of the pen. Allocates nothing. */
  function move(g, a) {
    var f = g.f, tx = Math.floor(a.x), ty = Math.floor(a.y), nx = a.x + a.vx, ntx = Math.floor(nx), crossed = false;
    a.hit = false;
    if (ntx !== tx) {
      var d = ntx > tx ? 6 : 4;
      if (f.canStep(tx, ty, d) && (!a.penned || f.isPen(ntx, ty))) { crossed = true; tx = ntx; }
      else { nx = d === 6 ? tx + 1 - EPS : tx + EPS; a.vx = -a.vx * 0.3; a.hit = true; }
    }
    a.x = nx;
    var ny = a.y + a.vy, nty = Math.floor(ny);
    if (nty !== ty) {
      var e = nty > ty ? 2 : 8;
      if (!crossed && f.canStep(tx, ty, e) && (!a.penned || f.isPen(tx, nty))) { /* allowed */ }
      else { ny = e === 2 ? ty + 1 - EPS : ty + EPS; a.vy = crossed ? a.vy : -a.vy * 0.3; if (!crossed) a.hit = true; }
    }
    a.y = ny;
    if (Math.abs(a.vx) > Math.abs(a.vy)) a.face = a.vx > 0 ? 6 : 4; else if (a.vy !== 0) a.face = a.vy > 0 ? 2 : 8;
  }
  /**
   * One frame. The player stands at (px, py) in tile units; `whistle` asks for the whistle (granted when ready).
   * @returns {boolean} whether a whistle blew this frame
   */
  function step(g, px, py, whistle) {
    if (g.phase !== 'play') return false;
    g.frame++; var blew = false, i, a;
    if (g.whistleCool > 0) g.whistleCool--;
    if (g.whistleT > 0) g.whistleT--;
    if (whistle && g.whistleCool <= 0) {
      g.whistleT = WHISTLE_T; g.whistleCool = WHISTLE_COOL; g.wx = px; g.wy = py; blew = true;
      var cx = 0, cy = 0, cn = 0; for (i = 0; i < g.n; i++) { a = g.animals[i]; var dx = a.x - px, dy = a.y - py; if (!a.penned && dx * dx + dy * dy < WHISTLE_R * WHISTLE_R) { cx += a.x; cy += a.y; cn++; } }
      if (cn) { g.gx = cx / cn; g.gy = cy / cn; } else g.whistleT = 0;
    }
    for (i = 0; i < g.n; i++) {
      a = g.animals[i];
      if (a.penned) { a.vx *= 0.8; a.vy *= 0.8; var pdx = a.x - px, pdy = a.y - py, pd = Math.sqrt(pdx * pdx + pdy * pdy) || 1; if (pd < 1.5) { a.vx += pdx / pd * 0.01; a.vy += pdy / pd * 0.01; } move(g, a); }
      else {
        var ox = a.x, oy = a.y; steer(g, a, i, px, py); move(g, a);
        // CORNERED: threatened, pressed into a refused edge and barely moving for STUCK_T frames -> it dodges past the
        // player along the fence (stuck_census.js, 2026-10-11: with the clock off, 19 of 80 easy rounds never finished,
        // the strays piled in a corner and in the pocket beside the gate, where no push from any side can move them)
        if (a.near && a.hit && Math.abs(a.x - ox) + Math.abs(a.y - oy) < S_MIN * a.S.speed) { if (++a.stuck >= STUCK_T) dodge(g, a, px, py); }
        else if (a.stuck > 0) a.stuck--;
      }
      if (!a.penned && g.f.isPen(Math.floor(a.x), Math.floor(a.y))) { a.penned = true; g.penned++; }
    }
    if (g.penned >= g.n) { g.phase = 'won'; g.endFrame = g.frame; }
    else if (g.frame >= g.frames) { g.phase = 'over'; g.endFrame = g.frame; }
    return blew;
  }
  /** a cornered animal breaks along the fence past the player: of the four directions it can actually step, the one most
   *  ACROSS the player's line (ties broken by the seeded RNG), at 1.25x its speed for DODGE_T frames. Allocates nothing. */
  function dodge(g, a, px, py) {
    var dx = a.x - px, dy = a.y - py, dl = Math.sqrt(dx * dx + dy * dy) || 1, tx = Math.floor(a.x), ty = Math.floor(a.y), best = 0, bs = -9, k, d, ux, uy, s;
    for (k = 0; k < 4; k++) {
      d = k === 0 ? 2 : k === 1 ? 4 : k === 2 ? 6 : 8;
      if (!g.f.canStep(tx, ty, d) || (a.penned && !g.f.isPen(tx + (d === 6 ? 1 : d === 4 ? -1 : 0), ty + (d === 2 ? 1 : d === 8 ? -1 : 0)))) continue;
      ux = d === 6 ? 1 : d === 4 ? -1 : 0; uy = d === 2 ? 1 : d === 8 ? -1 : 0;
      s = 1 - Math.abs(ux * dx + uy * dy) / dl + (ux * dx + uy * dy) / dl * 0.3 + rand(g.st) * 0.05;   // across the line, a little away
      if (s > bs) { bs = s; best = d; }
    }
    a.stuck = 0;
    if (!best) return;
    a.vx = (best === 6 ? 1 : best === 4 ? -1 : 0) * a.S.speed * 1.25; a.vy = (best === 2 ? 1 : best === 8 ? -1 : 0) * a.S.speed * 1.25;
    a.dodge = DODGE_T; a.state = CALM; a.dodges = (a.dodges || 0) + 1;
  }
  function whistleReady(g) { return g.whistleCool <= 0; }
  /** the tally: penned, strays, seconds left and stars (all penned with 30% of the time left 3, all penned 2, half 1) */
  function results(g) {
    var left = Math.max(0, g.frames - (g.phase === 'play' ? g.frame : g.endFrame)), all = g.penned >= g.n;
    var stars = all && left >= g.frames * 0.3 ? 3 : all ? 2 : g.penned * 2 >= g.n ? 1 : 0;
    return { won: g.phase === 'won', penned: g.penned, strays: g.n - g.penned, secondsLeft: Math.floor(left / 60), stars: stars };
  }
  return { VERSION: '1.0.0', mix: mix, hashString: hashString, rand: rand, SPECIES: SPECIES, DIFFS: DIFFS, createRound: createRound, bind: bind, step: step, steer: steer, move: move, whistleReady: whistleReady, results: results,
    WHISTLE_COOL: WHISTLE_COOL, WHISTLE_R: WHISTLE_R };
}());
if (typeof module !== 'undefined' && module.exports) module.exports = RoundupCore;
