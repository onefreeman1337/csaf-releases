//=============================================================================
// StrataDraw.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Strata draw - rock strata, cracks and ten families of
 * buried finds, all drawn in code. Place BETWEEN StrataCore and Strata.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * Every picture Strata shows is drawn here onto a canvas: no image file is
 * loaded. No parameters of its own. Must be installed below StrataCore.js and
 * above Strata.js.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var StrataDraw = (function () {
  'use strict';
  var TAU = Math.PI * 2;
  var CELL = 40;
  var FACE = '"Palatino Linotype", "Book Antiqua", Palatino, "Georgia", serif';

  /** Rock palettes per site: outer layer first, deepest last. */
  var SITES = {
    sandstone: { layers: ['#d9a86c', '#c98f55', '#b67945', '#a1663a', '#8a5431', '#734428'], fleck: '#f3d7a8', under: '#2a1a10' },
    shale: { layers: ['#8d96a1', '#7a8390', '#68717f', '#58606e', '#48505e', '#3a414e'], fleck: '#c4ccd6', under: '#15181d' },
    limestone: { layers: ['#e3dcc8', '#d4ccb5', '#c3baa1', '#b0a78c', '#9c9378', '#877f66'], fleck: '#fbf7ea', under: '#231f16' },
    clay: { layers: ['#b86a4b', '#a55b3f', '#924e35', '#7e422d', '#6b3726', '#582d20'], fleck: '#e3a488', under: '#1e0f0a' },
    basalt: { layers: ['#5d5a60', '#4f4c53', '#434047', '#38353c', '#2e2c32', '#252329'], fleck: '#9b97a3', under: '#0c0b0e' },
  };

  function rng(seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function shade(hex, k) {
    var n = parseInt(hex.slice(1), 16), r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    var f = function (c) { return Math.max(0, Math.min(255, Math.round(k >= 0 ? c + (255 - c) * k : c * (1 + k)))); };
    return 'rgb(' + f(r) + ',' + f(g) + ',' + f(b) + ')';
  }

  //===========================================================================
  // The face: one rock cell at a given remaining depth
  //===========================================================================

  /**
   * Draw the WHOLE face as continuous rock. ⛔ Defect found by looking (2026-09-23): drawing each cell with its
   * own bevel and outline made the face read as BATHROOM TILES. Rock has no grid: a cell is filled edge to edge
   * in its layer's colour, grain is laid in FACE coordinates so it runs across cells, bedding bands run across
   * the whole face with a tilt, and an edge is drawn ONLY where two neighbours stand at different depths (a
   * step, lit from above) or where a cell has been cut through to the bed (a ragged lip).
   * @param {number[]} depth current depth per cell @param {number[]} orig original depth per cell
   */
  function drawFace(ctx, site, s, depth, orig) {
    var P = SITES[site] || SITES.sandstone, cols = s.cols, rows = s.rows;
    var r = rng((s.seed ^ 0x3131) >>> 0);
    var tilt = (rng(s.seed >>> 0)() - 0.5) * 0.35;
    var x, y, c;
    var W0 = cols * CELL, H0 = rows * CELL;
    // ⛔ Second defect found by looking: steps keyed on REMAINING depth drew a grid over an untouched wall,
    // because original thickness varies cell to cell. The wall starts FLAT: what is visible is how much has
    // been CUT (layer = orig - depth), so a region cut to the same layer is one continuous surface, striped
    // with bedding bands that run across the whole region.
    var cut = function (i) { return orig[i] - depth[i]; };
    for (var L = 0; L < P.layers.length; L++) {
      var any = false;
      ctx.save(); ctx.beginPath();
      for (y = 0; y < rows; y++) for (x = 0; x < cols; x++) {
        c = y * cols + x;
        if (s.rock[c] || depth[c] <= 0 || Math.min(P.layers.length - 1, cut(c)) !== L) continue;
        ctx.rect(x * CELL, y * CELL, CELL, CELL); any = true;
      }
      if (!any) { ctx.restore(); continue; }
      ctx.clip();
      ctx.fillStyle = P.layers[L]; ctx.fillRect(0, 0, W0, H0);
      var rb = rng((s.seed ^ (L * 7717)) >>> 0);
      for (var sb = -2; sb < 14; sb++) {
        var y0 = sb * 34 + rb() * 10, hgt = 12 + rb() * 22;
        ctx.fillStyle = shade(P.layers[L], (rb() - 0.5) * 0.14);
        ctx.beginPath(); ctx.moveTo(0, y0); ctx.lineTo(W0, y0 + tilt * W0); ctx.lineTo(W0, y0 + hgt + tilt * W0); ctx.lineTo(0, y0 + hgt); ctx.closePath(); ctx.fill();
      }
      ctx.restore();
    }
    // grain in face coordinates: flecks, crossing cell boundaries, only where rock still stands
    ctx.save();
    ctx.beginPath();
    for (y = 0; y < rows; y++) for (x = 0; x < cols; x++) { c = y * cols + x; if (!s.rock[c] && depth[c] > 0) ctx.rect(x * CELL, y * CELL, CELL, CELL); }
    ctx.clip();
    var W = cols * CELL, H = rows * CELL;
    for (var i = 0; i < 1400; i++) {
      ctx.fillStyle = r() < 0.55 ? P.fleck : 'rgba(0,0,0,0.9)';
      ctx.globalAlpha = 0.1 + r() * 0.22;
      ctx.fillRect(r() * W, r() * H, 1 + r() * 2.2, 1 + r() * 1.4);
    }
    // bedding planes: long faint lines across the whole face
    ctx.globalAlpha = 0.22; ctx.strokeStyle = shade(P.layers[3], -0.3); ctx.lineWidth = 1;
    for (var b = 0; b < 9; b++) {
      var by = (b + 0.5) * H / 9;
      ctx.beginPath(); ctx.moveTo(0, by);
      for (var bx = 0; bx <= W; bx += 26) ctx.lineTo(bx, by + tilt * bx + (r() - 0.5) * 3);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
    ctx.restore();
    // steps: where a neighbour stands lower, the upper cell gets a lit lip and the lower one a cast shadow
    for (y = 0; y < rows; y++) for (x = 0; x < cols; x++) {
      c = y * cols + x;
      if (s.rock[c] || depth[c] <= 0) continue;
      // heights in CUT terms: an untouched cell is at 0, each layer removed lowers it by one; a cleared cell is the floor
      var d = -cut(c);
      var nb = [[1, 0], [0, 1], [-1, 0], [0, -1]];
      for (var k = 0; k < 4; k++) {
        var nx = x + nb[k][0], ny = y + nb[k][1];
        if (nx < 0 || ny < 0 || nx >= cols || ny >= rows) continue;
        var nc = ny * cols + nx;
        if (s.rock[nc]) continue;
        var dn = depth[nc] <= 0 ? -99 : -cut(nc);
        if (dn >= d) continue;
        // this cell (depth d) is HIGHER than its neighbour: draw the drop on the shared edge
        var drop = Math.min(4, d - dn), lw = 1 + drop * 0.9;
        var ex0, ey0, ex1, ey1;
        if (k === 0) { ex0 = ex1 = (x + 1) * CELL; ey0 = y * CELL; ey1 = (y + 1) * CELL; }
        else if (k === 2) { ex0 = ex1 = x * CELL; ey0 = y * CELL; ey1 = (y + 1) * CELL; }
        else if (k === 1) { ey0 = ey1 = (y + 1) * CELL; ex0 = x * CELL; ex1 = (x + 1) * CELL; }
        else { ey0 = ey1 = y * CELL; ex0 = x * CELL; ex1 = (x + 1) * CELL; }
        ctx.strokeStyle = dn === -99 ? 'rgba(0,0,0,0.6)' : 'rgba(0,0,0,0.32)';
        ctx.lineWidth = lw;
        ctx.beginPath(); ctx.moveTo(ex0, ey0);
        var steps = 5;
        for (var t = 1; t <= steps; t++) {
          var jx = (k === 1 || k === 3) ? 0 : (r() - 0.5) * 3, jy = (k === 0 || k === 2) ? 0 : (r() - 0.5) * 3;
          ctx.lineTo(ex0 + (ex1 - ex0) * t / steps + jx, ey0 + (ey1 - ey0) * t / steps + jy);
        }
        ctx.stroke();
        // lit lip on the upper cell's side of the edge
        ctx.strokeStyle = 'rgba(255,240,215,0.22)'; ctx.lineWidth = 1;
        var ox = k === 0 ? -1.5 : k === 2 ? 1.5 : 0, oy = k === 1 ? -1.5 : k === 3 ? 1.5 : 0;
        ctx.beginPath(); ctx.moveTo(ex0 + ox, ey0 + oy); ctx.lineTo(ex1 + ox, ey1 + oy); ctx.stroke();
      }
    }
  }

  /** (Kept for callers that paint one cell; draws the same continuous look without a per-cell outline.) */
  function drawCell(ctx, site, col, row, depth, layer, n) {
    if (depth <= 0) return;
    var P = SITES[site] || SITES.sandstone;
    var x = col * CELL, y = row * CELL;
    var r = rng(((col * 73856093) ^ (row * 19349663) ^ (layer * 83492791) ^ n) >>> 0);
    // stratum banding: rows alternate tone a little, like bedding planes
    var li = Math.min(P.layers.length - 1, layer);
    var base = P.layers[li];
    var band = ((row + Math.floor(layer / 2)) % 3 === 0) ? 0.05 : ((row % 3 === 1) ? -0.04 : 0);
    var j = 1.8;
    ctx.beginPath();
    var pts = [[x + r() * j, y + r() * j], [x + CELL / 2, y + r() * j * 0.7], [x + CELL - r() * j, y + r() * j], [x + CELL - r() * j * 0.7, y + CELL / 2],
      [x + CELL - r() * j, y + CELL - r() * j], [x + CELL / 2, y + CELL - r() * j * 0.7], [x + r() * j, y + CELL - r() * j], [x + r() * j * 0.7, y + CELL / 2]];
    ctx.moveTo(pts[0][0], pts[0][1]);
    for (var i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
    ctx.closePath();
    var g = ctx.createLinearGradient(x, y, x + CELL, y + CELL);
    g.addColorStop(0, shade(base, 0.12 + band)); g.addColorStop(1, shade(base, -0.12 + band));
    ctx.fillStyle = g; ctx.fill();
    // bevel: light upper-left, dark lower-right; a deeper cut shows a thicker lip
    ctx.lineWidth = 1.2;
    ctx.strokeStyle = 'rgba(255,255,255,0.22)';
    ctx.beginPath(); ctx.moveTo(pts[6][0] + 1, pts[6][1] - 1); ctx.lineTo(pts[0][0] + 1, pts[0][1] + 1); ctx.lineTo(pts[2][0] - 1, pts[2][1] + 1); ctx.stroke();
    ctx.strokeStyle = 'rgba(0,0,0,0.35)';
    ctx.beginPath(); ctx.moveTo(pts[2][0] - 1, pts[2][1] + 1); ctx.lineTo(pts[4][0] - 1, pts[4][1] - 1); ctx.lineTo(pts[6][0] + 1, pts[6][1] - 1); ctx.stroke();
    // grain: flecks and a few fine strata lines
    for (var f = 0; f < 9; f++) {
      ctx.fillStyle = r() < 0.5 ? P.fleck : shade(base, -0.35);
      ctx.globalAlpha = 0.25 + r() * 0.3;
      ctx.fillRect(x + 3 + r() * (CELL - 6), y + 3 + r() * (CELL - 6), 1 + r() * 1.6, 1 + r() * 1.2);
    }
    ctx.globalAlpha = 0.18; ctx.strokeStyle = shade(base, -0.4); ctx.lineWidth = 0.8;
    var ly = y + 8 + r() * (CELL - 16);
    ctx.beginPath(); ctx.moveTo(x + 3, ly); ctx.quadraticCurveTo(x + CELL / 2, ly + (r() - 0.5) * 5, x + CELL - 3, ly + (r() - 0.5) * 3); ctx.stroke();
    ctx.globalAlpha = 1;
    // depth pips: small chisel marks, one per layer still standing, so the player can read how much is left
    ctx.fillStyle = 'rgba(0,0,0,0.28)';
    for (var d = 0; d < depth; d++) ctx.fillRect(x + 5 + d * 5, y + CELL - 7, 3, 2);
  }

  /** An unbreakable bedrock stone over one cell: dark, glossy, obviously different. */
  function drawBedrock(ctx, col, row, n) {
    var x = col * CELL, y = row * CELL, r = rng((col * 911 + row * 3571 + n) >>> 0);
    ctx.beginPath();
    for (var i = 0; i < 9; i++) {
      var a = i / 9 * TAU, rr = CELL * (0.46 + r() * 0.05);
      var px = x + CELL / 2 + Math.cos(a) * rr, py = y + CELL / 2 + Math.sin(a) * rr;
      if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    }
    ctx.closePath();
    var g = ctx.createRadialGradient(x + CELL * 0.35, y + CELL * 0.3, 2, x + CELL / 2, y + CELL / 2, CELL * 0.6);
    g.addColorStop(0, '#6d6a78'); g.addColorStop(0.5, '#2e2c36'); g.addColorStop(1, '#141319');
    ctx.fillStyle = g; ctx.fill();
    ctx.strokeStyle = '#08070a'; ctx.lineWidth = 1.2; ctx.stroke();
    ctx.strokeStyle = 'rgba(200,200,230,0.25)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(x + 10, y + 14); ctx.lineTo(x + 18, y + 22); ctx.lineTo(x + 15, y + 30); ctx.stroke();
  }

  /** The bed under the face: packed dark soil with pebbles; what a cleared cell shows where nothing is buried. */
  function drawUnder(ctx, site, w, h, seed) {
    var P = SITES[site] || SITES.sandstone, r = rng(seed ^ 0x44);
    var g = ctx.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, shade(P.under, 0.12)); g.addColorStop(1, P.under);
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    for (var i = 0; i < 260; i++) {
      ctx.fillStyle = r() < 0.5 ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.25)';
      var s = 1 + r() * 3.5;
      ctx.beginPath(); ctx.ellipse(r() * w, r() * h, s, s * (0.6 + r() * 0.4), r() * 3, 0, TAU); ctx.fill();
    }
  }

  //===========================================================================
  // Finds. Each draws inside its footprint box (w x h cells), in its NATURAL
  // orientation; a rotated find is drawn in the swapped box and turned.
  //===========================================================================

  function drawFind(ctx, find, cellsW, cellsH) {
    var natW = find.rot ? cellsH : cellsW, natH = find.rot ? cellsW : cellsH;
    var W = natW * CELL, H = natH * CELL, r = rng(find.variant >>> 0);
    ctx.save();
    if (find.rot) { ctx.translate(cellsW * CELL, 0); ctx.rotate(Math.PI / 2); }
    var fn = FINDS[find.family];
    if (fn) fn(ctx, W, H, r);
    ctx.restore();
  }

  function soft(ctx, cx, cy, rx, ry) {
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    ctx.beginPath(); ctx.ellipse(cx + 3, cy + 4, rx, ry, 0, 0, TAU); ctx.fill();
  }

  var FINDS = {
    ammonite: function (ctx, W, H, r) {
      var cx = W / 2, cy = H / 2, R = Math.min(W, H) * 0.46;
      var mat = [['#d9b25e', '#7a5520'], ['#e8e0cc', '#8b7d62'], ['#6fb6a6', '#2d4f6b']][Math.floor(r() * 3)];
      soft(ctx, cx, cy, R, R);
      var g = ctx.createRadialGradient(cx - R * 0.3, cy - R * 0.3, 2, cx, cy, R);
      g.addColorStop(0, mat[0]); g.addColorStop(1, mat[1]);
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.fill();
      // the coil: a logarithmic spiral traced inward, with ribs crossing each whorl
      var k = 0.21, turns = 3.3, a0 = r() * TAU;
      ctx.strokeStyle = 'rgba(40,25,10,0.65)'; ctx.lineWidth = 1.6;
      ctx.beginPath();
      for (var t = 0; t <= turns * TAU; t += 0.05) {
        var rr = R * Math.exp(-k * t), px = cx + rr * Math.cos(a0 + t), py = cy + rr * Math.sin(a0 + t);
        if (t === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
      }
      ctx.stroke();
      ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(40,25,10,0.4)';
      for (var t2 = 0; t2 <= turns * TAU; t2 += 0.28) {
        var r1 = R * Math.exp(-k * t2), r2 = R * Math.exp(-k * (t2 + TAU)), a = a0 + t2;
        ctx.beginPath(); ctx.moveTo(cx + r1 * Math.cos(a), cy + r1 * Math.sin(a));
        ctx.quadraticCurveTo(cx + (r1 + r2) / 2 * Math.cos(a + 0.12), cy + (r1 + r2) / 2 * Math.sin(a + 0.12), cx + r2 * Math.cos(a), cy + r2 * Math.sin(a));
        ctx.stroke();
      }
      ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 1.4;
      ctx.beginPath(); ctx.arc(cx, cy, R - 1.5, Math.PI * 1.05, Math.PI * 1.55); ctx.stroke();
    },
    trilobite: function (ctx, W, H, r) {
      var cx = W / 2, top = H * 0.08, bot = H * 0.94, hw = W * 0.42;
      var col = ['#4a4038', '#5b5048', '#3f4450'][Math.floor(r() * 3)];
      soft(ctx, cx, (top + bot) / 2, hw, (bot - top) / 2);
      ctx.fillStyle = shade(col, 0.15);
      // cephalon: a half-moon head shield with genal spines
      ctx.beginPath(); ctx.moveTo(cx - hw, top + H * 0.26);
      ctx.quadraticCurveTo(cx - hw, top, cx, top); ctx.quadraticCurveTo(cx + hw, top, cx + hw, top + H * 0.26);
      ctx.lineTo(cx + hw * 1.05, top + H * 0.38); ctx.lineTo(cx + hw * 0.8, top + H * 0.28);
      ctx.lineTo(cx - hw * 0.8, top + H * 0.28); ctx.lineTo(cx - hw * 1.05, top + H * 0.38); ctx.closePath(); ctx.fill();
      // thorax segments narrowing to the pygidium
      var segs = 8 + Math.floor(r() * 4), sy = top + H * 0.28, sh = (bot - sy) * 0.78 / segs;
      for (var i = 0; i < segs; i++) {
        var w = hw * (1 - i / segs * 0.45);
        ctx.fillStyle = shade(col, i % 2 ? 0.05 : 0.18);
        ctx.beginPath(); ctx.ellipse(cx, sy + i * sh + sh / 2, w, sh * 0.62, 0, 0, TAU); ctx.fill();
      }
      ctx.fillStyle = shade(col, 0.1);
      ctx.beginPath(); ctx.ellipse(cx, bot - (bot - sy) * 0.12, hw * 0.45, (bot - sy) * 0.13, 0, 0, TAU); ctx.fill();
      // axial lobe and glabella: the raised spine that makes a trilobite a trilobite
      ctx.fillStyle = shade(col, 0.32);
      ctx.beginPath(); ctx.ellipse(cx, top + H * 0.16, hw * 0.28, H * 0.1, 0, 0, TAU); ctx.fill();
      ctx.beginPath(); ctx.moveTo(cx - hw * 0.2, sy); ctx.lineTo(cx + hw * 0.2, sy); ctx.lineTo(cx + hw * 0.1, bot - 6); ctx.lineTo(cx - hw * 0.1, bot - 6); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#15110d';
      ctx.beginPath(); ctx.arc(cx - hw * 0.45, top + H * 0.17, 2.4, 0, TAU); ctx.arc(cx + hw * 0.45, top + H * 0.17, 2.4, 0, TAU); ctx.fill();
    },
    bone: function (ctx, W, H, r) {
      var cy = H / 2, t = H * 0.2, end = H * 0.36;
      var ivory = ['#e9dcc0', '#d8c49a', '#c9b48a'][Math.floor(r() * 3)];
      soft(ctx, W / 2, cy, W * 0.46, H * 0.3);
      var g = ctx.createLinearGradient(0, cy - end, 0, cy + end);
      g.addColorStop(0, shade(ivory, 0.25)); g.addColorStop(1, shade(ivory, -0.3));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(end * 1.6, cy - t);
      ctx.bezierCurveTo(W * 0.4, cy - t * 0.8, W * 0.6, cy - t * 0.8, W - end * 1.6, cy - t);
      ctx.arc(W - end * 1.1, cy - end * 0.45, end * 0.62, Math.PI * 1.1, Math.PI * 0.1);
      ctx.arc(W - end * 1.1, cy + end * 0.45, end * 0.62, -Math.PI * 0.1, Math.PI * 0.9);
      ctx.bezierCurveTo(W * 0.6, cy + t * 0.8, W * 0.4, cy + t * 0.8, end * 1.6, cy + t);
      ctx.arc(end * 1.1, cy + end * 0.45, end * 0.62, Math.PI * 0.1, Math.PI * 1.1);
      ctx.arc(end * 1.1, cy - end * 0.45, end * 0.62, Math.PI * 0.9, Math.PI * 1.9);
      ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(70,50,20,0.55)'; ctx.lineWidth = 1; ctx.stroke();
      ctx.strokeStyle = 'rgba(60,40,15,0.45)';
      var cxk = W * (0.3 + r() * 0.4);
      ctx.beginPath(); ctx.moveTo(cxk, cy - t * 0.8); ctx.lineTo(cxk + 4, cy); ctx.lineTo(cxk - 2, cy + t * 0.8); ctx.stroke();
    },
    tooth: function (ctx, W, H, r) {
      var cx = W / 2, bw = W * 0.34, tip = H * 0.06, base = H * 0.72;
      soft(ctx, cx, H / 2, bw, H * 0.44);
      var g = ctx.createLinearGradient(cx - bw, 0, cx + bw, 0);
      g.addColorStop(0, '#f5efe2'); g.addColorStop(0.5, '#e2d6bb'); g.addColorStop(1, '#9d8a66');
      ctx.fillStyle = '#6b4a2c';
      ctx.beginPath(); ctx.moveTo(cx - bw * 0.85, base); ctx.lineTo(cx - bw * 0.55, H * 0.96); ctx.lineTo(cx + bw * 0.5, H * 0.96); ctx.lineTo(cx + bw * 0.85, base); ctx.closePath(); ctx.fill();
      ctx.fillStyle = g;
      var curl = (r() - 0.5) * bw;
      ctx.beginPath(); ctx.moveTo(cx - bw, base); ctx.quadraticCurveTo(cx - bw * 0.7, H * 0.3, cx + curl, tip);
      ctx.quadraticCurveTo(cx + bw * 0.9, H * 0.35, cx + bw, base); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(80,60,30,0.5)'; ctx.lineWidth = 1;
      for (var s = 0; s < 7; s++) { var yy = tip + 8 + s * (base - tip - 10) / 7; ctx.beginPath(); ctx.moveTo(cx + bw * 0.55 + s * 0.6, yy); ctx.lineTo(cx + bw * 0.75 + s * 0.6, yy + 2); ctx.stroke(); }
      ctx.strokeStyle = 'rgba(255,255,255,0.5)'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(cx - bw * 0.55, base - 4); ctx.quadraticCurveTo(cx - bw * 0.45, H * 0.35, cx + curl * 0.6, tip + 10); ctx.stroke();
    },
    amber: function (ctx, W, H, r) {
      var cx = W / 2, cy = H / 2;
      soft(ctx, cx, cy, W * 0.42, H * 0.38);
      ctx.beginPath();
      for (var i = 0; i < 12; i++) {
        var a = i / 12 * TAU, rr = Math.min(W, H) * (0.36 + r() * 0.08);
        var px = cx + Math.cos(a) * rr * 1.08, py = cy + Math.sin(a) * rr * 0.92;
        if (i === 0) ctx.moveTo(px, py); else ctx.quadraticCurveTo(cx + Math.cos(a - 0.26) * rr * 1.2, cy + Math.sin(a - 0.26) * rr, px, py);
      }
      ctx.closePath();
      var hue = [['#ffd27a', '#c46a0e', '#6b2e05'], ['#ffe39a', '#e09a1c', '#7a4308'], ['#ffb46b', '#b2440d', '#4d1504']][Math.floor(r() * 3)];
      var g = ctx.createRadialGradient(cx - 8, cy - 10, 3, cx, cy, W * 0.45);
      g.addColorStop(0, hue[0]); g.addColorStop(0.55, hue[1]); g.addColorStop(1, hue[2]);
      ctx.fillStyle = g; ctx.fill();
      ctx.save(); ctx.clip();
      // the inclusion: a trapped insect in silhouette, or a drift of bubbles
      ctx.globalAlpha = 0.75;
      if (r() < 0.65) {
        var ix = cx + (r() - 0.5) * 12, iy = cy + (r() - 0.5) * 10, ang = r() * TAU;
        ctx.translate(ix, iy); ctx.rotate(ang);
        ctx.fillStyle = '#3a1a05';
        ctx.beginPath(); ctx.ellipse(0, 0, 7, 3, 0, 0, TAU); ctx.fill();
        ctx.beginPath(); ctx.arc(8, 0, 2.5, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(255,240,210,0.45)';
        ctx.beginPath(); ctx.ellipse(-1, -6, 7, 3, -0.4, 0, TAU); ctx.fill();
        ctx.beginPath(); ctx.ellipse(-1, 6, 7, 3, 0.4, 0, TAU); ctx.fill();
        ctx.strokeStyle = '#3a1a05'; ctx.lineWidth = 0.9;
        for (var l = -1; l <= 1; l++) { ctx.beginPath(); ctx.moveTo(l * 3, 0); ctx.lineTo(l * 4 - 2, 7); ctx.moveTo(l * 3, 0); ctx.lineTo(l * 4 - 2, -7); ctx.stroke(); }
      } else {
        for (var b = 0; b < 9; b++) { ctx.strokeStyle = 'rgba(255,245,220,0.7)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(cx + (r() - 0.5) * W * 0.5, cy + (r() - 0.5) * H * 0.5, 1 + r() * 3, 0, TAU); ctx.stroke(); }
      }
      ctx.restore(); ctx.globalAlpha = 1;
      ctx.fillStyle = 'rgba(255,255,255,0.55)';
      ctx.beginPath(); ctx.ellipse(cx - W * 0.16, cy - H * 0.2, W * 0.1, H * 0.05, -0.5, 0, TAU); ctx.fill();
    },
    geode: function (ctx, W, H, r) {
      var cx = W / 2, cy = H / 2, R = Math.min(W, H) * 0.44;
      var gem = [['#d9b8ff', '#7a3fc0', '#3b1466'], ['#f2f7ff', '#9fb6d6', '#4d6480'], ['#ffe9a6', '#e0a526', '#7a4f07']][Math.floor(r() * 3)];
      soft(ctx, cx, cy, R, R);
      ctx.fillStyle = '#6a625a'; ctx.beginPath();
      for (var i = 0; i < 14; i++) { var a = i / 14 * TAU, rr = R * (0.93 + r() * 0.08); if (i === 0) ctx.moveTo(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr); else ctx.lineTo(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr); }
      ctx.closePath(); ctx.fill();
      // agate banding in the rind
      for (var bnd = 0; bnd < 4; bnd++) { ctx.strokeStyle = bnd % 2 ? 'rgba(230,220,205,0.5)' : 'rgba(90,80,75,0.6)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(cx, cy, R * (0.86 - bnd * 0.06), 0, TAU); ctx.stroke(); }
      // the cavity lined with crystals pointing inward
      var Rc = R * 0.62;
      ctx.fillStyle = gem[2]; ctx.beginPath(); ctx.arc(cx, cy, Rc, 0, TAU); ctx.fill();
      var nC = 18;
      for (var c = 0; c < nC; c++) {
        var a2 = c / nC * TAU + r() * 0.1, len = Rc * (0.45 + r() * 0.4), wdt = 0.14;
        var bx = cx + Math.cos(a2) * Rc, by = cy + Math.sin(a2) * Rc;
        var tx = cx + Math.cos(a2) * (Rc - len), ty = cy + Math.sin(a2) * (Rc - len);
        var g = ctx.createLinearGradient(bx, by, tx, ty);
        g.addColorStop(0, gem[1]); g.addColorStop(1, gem[0]);
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.moveTo(cx + Math.cos(a2 - wdt) * Rc, cy + Math.sin(a2 - wdt) * Rc); ctx.lineTo(tx, ty); ctx.lineTo(cx + Math.cos(a2 + wdt) * Rc, cy + Math.sin(a2 + wdt) * Rc); ctx.closePath(); ctx.fill();
      }
      ctx.fillStyle = 'rgba(255,255,255,0.7)'; ctx.beginPath(); ctx.arc(cx - Rc * 0.3, cy - Rc * 0.35, 2.2, 0, TAU); ctx.fill();
    },
    ore: function (ctx, W, H, r) {
      // ⛔ Defect found by looking: a hard-edged L polygon read as a HANDGUN. Ore is a lumpy rounded nugget: a
      // ring of bulges around the footprint's centre of mass (three cells across the top, two below right).
      var metal = [['#ffe07a', '#b8860b'], ['#ffb58a', '#b1542a'], ['#e6ecf2', '#8e9aa6'], ['#9fe3ff', '#2f7fa8']][Math.floor(r() * 4)];
      var blobs = [[W * 0.2, H * 0.28, H * 0.26], [W * 0.5, H * 0.26, H * 0.3], [W * 0.78, H * 0.3, H * 0.28], [W * 0.55, H * 0.66, H * 0.28], [W * 0.8, H * 0.7, H * 0.26]];
      var pts = [];
      for (var i2 = 0; i2 < 28; i2++) {
        var a = i2 / 28 * TAU, cxm = W * 0.57, cym = H * 0.45, best = 0;
        for (var b2 = 0; b2 < blobs.length; b2++) {
          // furthest point of any bulge along this ray, so the outline hugs the lumps
          var dx = blobs[b2][0] - cxm, dy = blobs[b2][1] - cym, proj = dx * Math.cos(a) + dy * Math.sin(a);
          var perp = Math.abs(-dx * Math.sin(a) + dy * Math.cos(a)), rr0 = blobs[b2][2];
          if (perp < rr0) best = Math.max(best, proj + Math.sqrt(rr0 * rr0 - perp * perp));
        }
        best *= 0.94 + r() * 0.08;
        pts.push([cxm + Math.cos(a) * best, cym + Math.sin(a) * best]);
      }
      ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.beginPath(); pts.forEach(function (p, i) { if (i) ctx.lineTo(p[0] + 3, p[1] + 4); else ctx.moveTo(p[0] + 3, p[1] + 4); }); ctx.closePath(); ctx.fill();
      ctx.beginPath(); pts.forEach(function (p, i) { if (i) ctx.lineTo(p[0], p[1]); else ctx.moveTo(p[0], p[1]); }); ctx.closePath();
      var g = ctx.createLinearGradient(0, 0, W, H); g.addColorStop(0, '#6d655e'); g.addColorStop(1, '#3a3430');
      ctx.fillStyle = g; ctx.fill(); ctx.strokeStyle = '#1e1a17'; ctx.lineWidth = 1.2; ctx.stroke();
      ctx.save(); ctx.clip();
      for (var v = 0; v < 4; v++) {
        var y0 = r() * H, wv = 3 + r() * 4;
        var vg = ctx.createLinearGradient(0, y0 - wv, 0, y0 + wv); vg.addColorStop(0, metal[1]); vg.addColorStop(0.5, metal[0]); vg.addColorStop(1, metal[1]);
        ctx.strokeStyle = vg; ctx.lineWidth = wv;
        ctx.beginPath(); ctx.moveTo(0, y0); ctx.bezierCurveTo(W * 0.3, y0 + (r() - 0.5) * 30, W * 0.7, y0 + (r() - 0.5) * 30, W, y0 + (r() - 0.5) * 20); ctx.stroke();
      }
      for (var f = 0; f < 22; f++) { ctx.fillStyle = metal[0]; ctx.globalAlpha = 0.5 + r() * 0.5; ctx.fillRect(r() * W, r() * H, 2, 2); }
      ctx.restore(); ctx.globalAlpha = 1;
    },
    crystal: function (ctx, W, H, r) {
      var col = [['#e8f6ff', '#8fc7e8', '#2d6f93'], ['#ffd6f0', '#e072b8', '#7a1f5c'], ['#d8ffd9', '#5cc46a', '#1c6630']][Math.floor(r() * 3)];
      // ⛔ Defect found by looking: the fan of prisms bled far outside the footprint. Keep the spread and
      // lengths inside the box (clipped as a guard) so a cleared NEIGHBOUR never shows crystal.
      var cx = W / 2, by = H * 0.92;
      ctx.save(); ctx.beginPath(); ctx.rect(0, 0, W, H); ctx.clip();
      soft(ctx, cx, H * 0.55, W * 0.36, H * 0.4);
      var n = 3 + Math.floor(r() * 3);
      for (var i = 0; i < n; i++) {
        var ang = (i - (n - 1) / 2) * 0.17 + (r() - 0.5) * 0.06, len = H * (0.5 + r() * 0.32), w = W * (0.09 + r() * 0.04);
        ctx.save(); ctx.translate(cx + (i - (n - 1) / 2) * w * 0.7, by); ctx.rotate(ang);
        ctx.beginPath(); ctx.moveTo(-w, 0); ctx.lineTo(-w, -len * 0.78); ctx.lineTo(0, -len); ctx.lineTo(w, -len * 0.78); ctx.lineTo(w, 0); ctx.closePath();
        var g = ctx.createLinearGradient(-w, 0, w, 0); g.addColorStop(0, col[1]); g.addColorStop(0.45, col[0]); g.addColorStop(1, col[2]);
        ctx.fillStyle = g; ctx.fill(); ctx.strokeStyle = shade(col[2], -0.3); ctx.lineWidth = 1; ctx.stroke();
        ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.beginPath(); ctx.moveTo(-w * 0.2, -4); ctx.lineTo(-w * 0.2, -len * 0.78); ctx.lineTo(0, -len); ctx.stroke();
        ctx.restore();
      }
      ctx.restore();
    },
    tablet: function (ctx, W, H, r) {
      var x = W * 0.1, y = H * 0.05, w = W * 0.8, h = H * 0.9;
      var stone = ['#8f8676', '#a69b86', '#766c60'][Math.floor(r() * 3)];
      ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fillRect(x + 3, y + 4, w, h);
      ctx.beginPath(); ctx.moveTo(x, y + h); ctx.lineTo(x, y + w / 2); ctx.arc(x + w / 2, y + w / 2, w / 2, Math.PI, 0); ctx.lineTo(x + w, y + h * 0.82); ctx.lineTo(x + w * 0.78, y + h); ctx.closePath();
      var g = ctx.createLinearGradient(x, y, x + w, y + h); g.addColorStop(0, shade(stone, 0.2)); g.addColorStop(1, shade(stone, -0.25));
      ctx.fillStyle = g; ctx.fill(); ctx.strokeStyle = shade(stone, -0.5); ctx.lineWidth = 1.2; ctx.stroke();
      // an inscription in an unknown script: glyph strokes on ruled lines, different on every tablet
      ctx.strokeStyle = shade(stone, -0.55); ctx.lineWidth = 1.3;
      var rows = 6, gw = 7;
      for (var ro = 0; ro < rows; ro++) {
        var ly = y + w * 0.42 + ro * (h - w * 0.5) / rows;
        for (var gx = x + 7; gx < x + w - 10; gx += gw + 3) {
          var k = Math.floor(r() * 5);
          ctx.beginPath();
          if (k === 0) { ctx.moveTo(gx, ly); ctx.lineTo(gx + gw, ly); ctx.moveTo(gx + gw / 2, ly - 4); ctx.lineTo(gx + gw / 2, ly + 4); }
          else if (k === 1) { ctx.moveTo(gx, ly + 4); ctx.lineTo(gx + gw / 2, ly - 4); ctx.lineTo(gx + gw, ly + 4); }
          else if (k === 2) { ctx.arc(gx + gw / 2, ly, gw / 2.4, 0, TAU); }
          else if (k === 3) { ctx.moveTo(gx, ly - 4); ctx.lineTo(gx + gw, ly + 4); ctx.moveTo(gx + gw, ly - 4); ctx.lineTo(gx + gw / 2, ly); }
          else { ctx.moveTo(gx, ly - 3); ctx.lineTo(gx, ly + 4); ctx.lineTo(gx + gw, ly + 4); }
          ctx.stroke();
        }
      }
      ctx.strokeStyle = shade(stone, -0.6); ctx.beginPath(); ctx.moveTo(x + w, y + h * 0.82); ctx.lineTo(x + w * 0.86, y + h * 0.9); ctx.lineTo(x + w * 0.78, y + h); ctx.stroke();
    },
    shell: function (ctx, W, H, r) {
      // ⛔ Defect found by looking: ribs at R*1.9 bled far outside the 2x2 box. The fan radius is now derived from
      // the box (R*0.95 from a hinge near the bottom edge), so the whole shell fits its footprint.
      var cx = W / 2, hy = H * 0.84, R = Math.min(W, H) * 0.25;
      var col = [['#ffe2c9', '#e59a6a'], ['#f3efe6', '#b8a98f'], ['#ffd0dd', '#d1708c']][Math.floor(r() * 3)];
      soft(ctx, cx, H / 2, R, R * 0.9);
      // ears at the hinge, then a fan of ribs
      ctx.fillStyle = shade(col[1], -0.1);
      ctx.beginPath(); ctx.moveTo(cx - R * 0.45, hy); ctx.lineTo(cx - R * 0.2, hy - R * 0.25); ctx.lineTo(cx + R * 0.2, hy - R * 0.25); ctx.lineTo(cx + R * 0.45, hy); ctx.closePath(); ctx.fill();
      var ribs = 11 + Math.floor(r() * 5), a0 = -Math.PI * 0.92, a1 = -Math.PI * 0.08;
      for (var i = 0; i < ribs; i++) {
        var ta = a0 + (a1 - a0) * (i / ribs), tb = a0 + (a1 - a0) * ((i + 1) / ribs);
        ctx.beginPath(); ctx.moveTo(cx, hy);
        ctx.lineTo(cx + Math.cos(ta) * R * 1.9, hy + Math.sin(ta) * R * 1.9);
        ctx.quadraticCurveTo(cx + Math.cos((ta + tb) / 2) * R * 2.02, hy + Math.sin((ta + tb) / 2) * R * 2.02, cx + Math.cos(tb) * R * 1.9, hy + Math.sin(tb) * R * 1.9);
        ctx.closePath();
        var g = ctx.createLinearGradient(cx, hy, cx, hy - R * 1.9); g.addColorStop(0, col[1]); g.addColorStop(1, i % 2 ? col[0] : shade(col[0], -0.08));
        ctx.fillStyle = g; ctx.fill(); ctx.strokeStyle = shade(col[1], -0.35); ctx.lineWidth = 0.8; ctx.stroke();
      }
      ctx.strokeStyle = 'rgba(120,70,40,0.35)'; ctx.lineWidth = 0.8;
      for (var gr = 1; gr < 4; gr++) { ctx.beginPath(); ctx.arc(cx, hy, R * 0.5 * gr, a0, a1); ctx.stroke(); }
    },
  };

  //===========================================================================
  // Frame, cracks, tools and words
  //===========================================================================

  /** The timbered frame of the dig, with shoring posts and a lantern glow. */
  function drawFrame(ctx, x, y, w, h, seed) {
    var r = rng(seed ^ 0x77);
    ctx.fillStyle = 'rgba(0,0,0,0.55)'; ctx.fillRect(x - 10, y - 10, w + 26, h + 28);
    var wood = function (bx, by, bw, bh) {
      var g = ctx.createLinearGradient(bx, by, bx + bw, by + bh); g.addColorStop(0, '#6e4a2b'); g.addColorStop(1, '#3d2616');
      ctx.fillStyle = g; ctx.fillRect(bx, by, bw, bh);
      ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 1;
      for (var i = 0; i < 6; i++) { ctx.beginPath(); var yy = by + r() * bh, xx = bx + r() * bw; if (bw > bh) { ctx.moveTo(bx, yy); ctx.lineTo(bx + bw, yy + (r() - 0.5) * 3); } else { ctx.moveTo(xx, by); ctx.lineTo(xx + (r() - 0.5) * 3, by + bh); } ctx.stroke(); }
      ctx.strokeStyle = '#1e120a'; ctx.strokeRect(bx + 0.5, by + 0.5, bw - 1, bh - 1);
    };
    wood(x - 18, y - 18, w + 36, 16); wood(x - 18, y + h + 2, w + 36, 16);
    wood(x - 18, y - 2, 16, h + 4); wood(x + w + 2, y - 2, 16, h + 4);
    ctx.fillStyle = '#8a8f96';
    [[x - 10, y - 10], [x + w + 10, y - 10], [x - 10, y + h + 10], [x + w + 10, y + h + 10]].forEach(function (p) { ctx.beginPath(); ctx.arc(p[0], p[1], 3, 0, TAU); ctx.fill(); });
  }

  /** The stability gauge: a crack that runs across a plank as the face weakens. `f` in 0..1. */
  function drawStabilityCrack(ctx, w, f, seed) {
    ctx.clearRect(0, 0, w, 28);
    var r = rng(seed ^ 0x99);
    var g = ctx.createLinearGradient(0, 0, 0, 22); g.addColorStop(0, '#7a5433'); g.addColorStop(1, '#4a311c');
    ctx.fillStyle = g; ctx.fillRect(0, 2, w, 22);
    ctx.strokeStyle = '#1e120a'; ctx.lineWidth = 1; ctx.strokeRect(0.5, 2.5, w - 1, 21);
    var end = w * Math.max(0, Math.min(1, f));
    if (end > 2) {
      ctx.strokeStyle = f > 0.8 ? '#ff5a3c' : '#140b05'; ctx.lineWidth = 2.2;
      ctx.beginPath(); ctx.moveTo(0, 13);
      for (var x = 6; x <= end; x += 6) ctx.lineTo(x, 13 + (r() - 0.5) * 12);
      ctx.stroke();
    }
  }

  /** A tool glyph, drawn at the origin. */
  function drawTool(ctx, tool, s, active) {
    ctx.save();
    ctx.fillStyle = active ? 'rgba(255,222,150,0.25)' : 'rgba(0,0,0,0.25)';
    ctx.beginPath(); ctx.arc(0, 0, s, 0, TAU); ctx.fill();
    ctx.strokeStyle = active ? '#ffe3a1' : '#8c7a5d'; ctx.lineWidth = active ? 2.4 : 1.4; ctx.stroke();
    ctx.rotate(-0.6);
    ctx.fillStyle = '#7a5130'; ctx.fillRect(-2.5, -s * 0.2, 5, s * 0.95);
    var steel = ctx.createLinearGradient(0, -s * 0.6, 0, -s * 0.2); steel.addColorStop(0, '#e6ebf0'); steel.addColorStop(1, '#6e7884');
    ctx.fillStyle = steel;
    if (tool === 'pick') {
      ctx.beginPath(); ctx.moveTo(-s * 0.75, -s * 0.2); ctx.quadraticCurveTo(0, -s * 0.62, s * 0.75, -s * 0.2); ctx.quadraticCurveTo(0, -s * 0.42, -s * 0.75, -s * 0.2); ctx.fill();
    } else {
      ctx.fillRect(-s * 0.42, -s * 0.52, s * 0.84, s * 0.34);
    }
    ctx.restore();
  }

  function drawHeading(ctx, W, title, sub) {
    ctx.clearRect(0, 0, W, 60);
    ctx.font = '30px ' + FACE; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillText(title, W / 2 + 1, 25);
    var g = ctx.createLinearGradient(0, 8, 0, 42); g.addColorStop(0, '#fbe7c0'); g.addColorStop(1, '#c48b4a');
    ctx.fillStyle = g; ctx.fillText(title, W / 2, 24);
    ctx.font = 'italic 13px ' + FACE; ctx.fillStyle = '#b89a70'; ctx.fillText(sub, W / 2, 49);
  }

  function drawStatus(ctx, W, text, tone) {
    ctx.clearRect(0, 0, W, 34);
    ctx.font = 'italic 17px ' + FACE; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillText(text, W / 2 + 1, 18);
    ctx.fillStyle = tone === 'bad' ? '#ff9c86' : tone === 'good' ? '#c8f5a6' : '#f1dfb4';
    ctx.fillText(text, W / 2, 17);
  }

  /** The cave behind everything: dark rock with a warm lantern falloff. */
  function drawBackdrop(ctx, W, H) {
    var g = ctx.createRadialGradient(W / 2, H * 0.45, 40, W / 2, H / 2, W * 0.75);
    g.addColorStop(0, '#3b2b20'); g.addColorStop(0.6, '#1c140e'); g.addColorStop(1, '#070504');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    var r = rng(0xCAFE);
    for (var i = 0; i < 1600; i++) { ctx.fillStyle = r() < 0.5 ? 'rgba(255,220,180,0.03)' : 'rgba(0,0,0,0.12)'; ctx.fillRect(r() * W, r() * H, 1 + r() * 3, 1 + r() * 2); }
  }

  return {
    VERSION: '1.0.0', CELL: CELL, FACE: FACE, SITES: SITES, FINDS: FINDS,
    drawCell: drawCell, drawFace: drawFace, drawBedrock: drawBedrock, drawUnder: drawUnder, drawFind: drawFind, drawFrame: drawFrame,
    drawStabilityCrack: drawStabilityCrack, drawTool: drawTool, drawHeading: drawHeading, drawStatus: drawStatus,
    drawBackdrop: drawBackdrop, shade: shade,
  };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = StrataDraw;
