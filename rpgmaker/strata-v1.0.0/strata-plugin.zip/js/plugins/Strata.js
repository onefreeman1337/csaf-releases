//=============================================================================
// Strata.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Strata - generated excavation digs. A close-up rock
 * face the player works with a pick and a hammer to free buried finds.
 * Place BELOW StrataCore and StrataDraw.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * Strata
 * ============================================================================
 *
 * Give the player a rock face and two tools. Every blow cuts the rock back a
 * layer or two and puts stress on the face; somewhere under it lie fossils,
 * relics, crystals or ore. Free a find completely before the face gives way
 * and it is theirs. Push too hard and it collapses, taking whatever is still
 * buried with it.
 *
 *  - PICK: cuts deep at one spot and a little around it. Light on the face.
 *  - HAMMER: cuts wide. Twice the stress.
 *  - Dark bedrock cannot be cut at all.
 *
 * Every site is GENERATED from a seed: the finds, the bedrock, the thickness
 * of the rock and the stability of the face. The stability is derived from
 * how a careful digger would do on THAT site, so a site is never impossible
 * and the grade decides how forgiving it is. Nothing is loaded from an image
 * file: rock, bedding, cracks and every find are drawn in code.
 *
 * ----------------------------------------------------------------------------
 * INSTALLING
 * ----------------------------------------------------------------------------
 * Plugin Manager order, top to bottom:
 *
 *     StrataCore.js     (the generator and the rules)
 *     StrataDraw.js     (the drawing)
 *     Strata.js         (this file: parameters, commands, the scene)
 *
 * ----------------------------------------------------------------------------
 * USING IT
 * ----------------------------------------------------------------------------
 * On any event, add the plugin command "Open Dig". Choose a grade (1 easy,
 * 5 hard), the rock (sandstone, shale, limestone, clay, basalt or auto) and
 * the ITEMS that can be found there. Each find becomes one of those items.
 * A find's look comes from the item's note:
 *
 *     <Strata: ammonite>
 *
 * Families: ammonite, trilobite, bone, tooth, amber, geode, ore, crystal,
 * tablet, shell. Without a note, the item's name is read for a hint (fossil,
 * amber, crystal, gem, ore, gold, bone, fang, tooth, shell, tablet, rune,
 * geode) and otherwise the seed chooses.
 *
 * The event waits while the player digs. Freed finds go into the party's
 * inventory. A switch can be turned on if EVERY find was freed, and a
 * variable receives how many were.
 *
 * Leave the seed blank and the site is keyed to its map and event. "Dig
 * once" makes a site give nothing the second time (the face is shown worked
 * out). Script call: Strata.dugAt("m3e12") returns {freed, total} or null.
 *
 * ----------------------------------------------------------------------------
 * CONTROLS
 * ----------------------------------------------------------------------------
 * Arrow keys move the mark. OK strikes. Q / W (page up / down) switch
 * between pick and hammer. Escape packs up and leaves, keeping what is free.
 * Mouse and touch: click a cell to strike it; click a tool to take it.
 *
 * ----------------------------------------------------------------------------
 * COMPATIBILITY
 * ----------------------------------------------------------------------------
 * Strata adds its own scene and replaces nothing. It extends one engine
 * method (Game_System.initialize) to create its save record, calling the
 * original first.
 *
 * ============================================================================
 * TERMS OF USE
 * ============================================================================
 * Commercial and non-commercial use permitted in RPG Maker projects, credit
 * appreciated but not required. Do not redistribute the source as an asset
 * pack. Every line of this plugin was written with AI assistance.
 *
 * ============================================================================
 *
 * @param defaultGrade
 * @text Default grade
 * @type number
 * @min 1
 * @max 5
 * @default 2
 *
 * @param strikeSe
 * @text Sound: pick strike
 * @type file
 * @dir audio/se
 * @default Blow1
 *
 * @param hammerSe
 * @text Sound: hammer strike
 * @type file
 * @dir audio/se
 * @default Blow3
 *
 * @param freeSe
 * @text Sound: find freed
 * @type file
 * @dir audio/se
 * @default Item3
 *
 * @param collapseSe
 * @text Sound: collapse
 * @type file
 * @dir audio/se
 * @default Collapse4
 *
 * @param toolSe
 * @text Sound: change tool
 * @type file
 * @dir audio/se
 * @default Cursor2
 *
 * @command open
 * @text Open Dig
 * @desc Open an excavation. The event waits until the player leaves.
 *
 * @arg grade
 * @text Grade
 * @type number
 * @min 0
 * @max 5
 * @desc 1 (forgiving) to 5 (hard). 0 = the plugin's default grade.
 * @default 0
 *
 * @arg site
 * @text Rock
 * @type select
 * @option auto
 * @option sandstone
 * @option shale
 * @option limestone
 * @option clay
 * @option basalt
 * @default auto
 *
 * @arg items
 * @text Items that can be found
 * @type item[]
 * @desc Each find becomes one of these, in order. Empty = finds are drawn but give no item.
 * @default []
 *
 * @arg title
 * @text Title
 * @desc Shown above the face. Blank = named after the rock.
 * @default
 *
 * @arg switchId
 * @text Switch if every find is freed
 * @type switch
 * @default 0
 *
 * @arg variableId
 * @text Variable: finds freed
 * @type variable
 * @default 0
 *
 * @arg once
 * @text Dig once
 * @type boolean
 * @default true
 *
 * @arg seed
 * @text Seed (optional)
 * @desc Blank = keyed to this map and event.
 * @default
 */

var Strata = Strata || {};

(function (M) {
  'use strict';
  var NAME = 'Strata', SCHEMA = 1;
  var raw = (typeof PluginManager !== 'undefined') ? PluginManager.parameters(NAME) : {};
  function num(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; var n = Number(v); return isFinite(n) ? n : d; }
  function str(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; return String(v).trim(); }
  function bool(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; return String(v) === 'true'; }

  M.params = {
    defaultGrade: Math.max(1, Math.min(5, num(raw.defaultGrade, 2))),
    strikeSe: str(raw.strikeSe, 'Blow1'), hammerSe: str(raw.hammerSe, 'Blow3'), freeSe: str(raw.freeSe, 'Item3'),
    collapseSe: str(raw.collapseSe, 'Collapse4'), toolSe: str(raw.toolSe, 'Cursor2'),
  };

  var _deps = null;
  function deps() {
    if (_deps) return _deps;
    var core = (typeof StrataCore !== 'undefined') ? StrataCore : null;
    var draw = (typeof StrataDraw !== 'undefined') ? StrataDraw : null;
    if (!core || !draw) {
      if (!deps._warned) { deps._warned = true; console.error('Strata: StrataCore.js and StrataDraw.js must both be installed and listed ABOVE Strata.js.'); }
      return null;
    }
    _deps = { core: core, draw: draw };
    return _deps;
  }
  M.deps = deps;

  function fresh() { return { v: SCHEMA, dug: {} }; }
  function store() {
    if (typeof $gameSystem === 'undefined' || !$gameSystem) return fresh();
    var s = $gameSystem._csafStrata;
    if (!s || s.v == null) { s = fresh(); $gameSystem._csafStrata = s; }
    if (!s.dug) s.dug = {};
    return s;
  }
  M.store = store;
  M.keyFor = function (mapId, eventId) { return 'm' + Number(mapId) + 'e' + Number(eventId); };
  M.dugAt = function (key) { var d = store().dug[String(key)]; return d ? { freed: d.freed, total: d.total } : null; };

  var _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () { _Game_System_initialize.call(this); this._csafStrata = fresh(); };

  var HINTS = [[/ammonite|fossil|nautil/i, 'ammonite'], [/trilob/i, 'trilobite'], [/amber|resin/i, 'amber'], [/geode|agate/i, 'geode'],
    [/crystal|gem|quartz|jewel|diamond|ruby|sapphire|emerald/i, 'crystal'], [/ore|gold|silver|copper|iron|mithril|nugget/i, 'ore'],
    [/bone|skeleton|femur/i, 'bone'], [/tooth|fang|claw/i, 'tooth'], [/shell|scallop|clam/i, 'shell'], [/tablet|rune|glyph|stele|inscri/i, 'tablet']];

  /** The family an item is drawn as: its <Strata: x> note, else a name hint, else null (the seed chooses). */
  M.familyFor = function (item) {
    var d = deps(); if (!d || !item) return null;
    var m = /<Strata:\s*([a-z]+)\s*>/i.exec(item.note || '');
    if (m && d.core.FAMILIES[m[1].toLowerCase()]) return m[1].toLowerCase();
    for (var i = 0; i < HINTS.length; i++) if (HINTS[i][0].test(item.name || '')) return HINTS[i][1];
    return null;
  };

  /** Parse an item[] argument: a JSON array of id strings. Blank ids and 0 are absent, never "item 0". */
  function itemIds(v) {
    var out = [];
    try { var a = JSON.parse(v || '[]'); if (Array.isArray(a)) for (var i = 0; i < a.length; i++) { var n = Number(a[i]); if (isFinite(n) && n > 0) out.push(n); } } catch (e) { /* malformed = none */ }
    return out;
  }
  M.itemIds = itemIds;

  M.request = function (args, key, mapId, eventId) {
    var d = deps(); if (!d) return null;
    args = args || {};
    var grade = num(args.grade, 0); if (!(grade >= 1)) grade = M.params.defaultGrade;
    var seedText = str(args.seed, '');
    var seed = seedText === '' ? d.core.hashString(key) : (/^\d+$/.test(seedText) ? (Number(seedText) >>> 0) : d.core.hashString(seedText));
    var ids = itemIds(args.items);
    var items = (typeof $dataItems !== 'undefined' && $dataItems) ? ids.map(function (id) { return $dataItems[id]; }).filter(Boolean) : [];
    var fams = items.map(function (it) { return M.familyFor(it); });
    var site = str(args.site, 'auto');
    var s = d.core.generate({ seed: seed, grade: grade, site: site === 'auto' ? null : site,
      families: fams.filter(function (f) { return !!f; }).length ? fams.map(function (f) { return f || d.core.FAMILY_IDS[seed % d.core.FAMILY_IDS.length]; }) : null });
    var ROCK = { sandstone: 'The Sandstone Cut', shale: 'The Shale Bed', limestone: 'The Limestone Quarry', clay: 'The Clay Bank', basalt: 'The Basalt Seam' };
    return { key: key, site: s, items: items.map(function (it) { return it.id; }), title: str(args.title, ROCK[s.site]),
      switchId: Math.max(0, Math.floor(num(args.switchId, 0))), variableId: Math.max(0, Math.floor(num(args.variableId, 0))),
      once: bool(args.once, true), mapId: mapId, eventId: eventId };
  };

  M.open = function (req) { if (!req) return false; SceneManager.push(Scene_Strata); SceneManager.prepareNextScene(req); return true; };

  /** Settle a dig: award freed finds as items, set the switch and variable, remember the site. */
  M.finish = function (req, freed) {
    var total = req.site.finds.length, gained = [];
    for (var i = 0; i < freed.length; i++) {
      var id = req.items[freed[i]];
      if (id && typeof $gameParty !== 'undefined' && typeof $dataItems !== 'undefined' && $dataItems[id]) { $gameParty.gainItem($dataItems[id], 1); gained.push(id); }
    }
    if (req.variableId > 0 && typeof $gameVariables !== 'undefined') $gameVariables.setValue(req.variableId, freed.length);
    if (req.switchId > 0 && freed.length === total && typeof $gameSwitches !== 'undefined') $gameSwitches.setValue(req.switchId, true);
    store().dug[req.key] = { seed: req.site.seed, freed: freed.length, total: total, items: gained };
    return gained;
  };

  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
    PluginManager.registerCommand(NAME, 'open', function (args) {
      var mapId = this._mapId || ($gameMap ? $gameMap.mapId() : 0), eventId = this.eventId ? this.eventId() : 0;
      var seedText = str(args.seed, '');
      var key = seedText === '' ? M.keyFor(mapId, eventId) : 's' + seedText;
      var req = M.request(args, key, mapId, eventId);
      if (!req) return;
      if (req.once && M.dugAt(key)) req.workedOut = true;
      M.open(req);
    });
  }
  M.VERSION = '1.0.0'; M.SCHEMA = SCHEMA;
}(Strata));

//=============================================================================
// Scene_Strata
//=============================================================================

function Scene_Strata() { this.initialize.apply(this, arguments); }
Scene_Strata.prototype = Object.create(Scene_Base.prototype);
Scene_Strata.prototype.constructor = Scene_Strata;
Scene_Strata.FACE_X = 148;
Scene_Strata.FACE_Y = 104;
Scene_Strata.DUST = 28;

Scene_Strata.prototype.prepare = function (req) { this._req = req; };

Scene_Strata.prototype.create = function () {
  Scene_Base.prototype.create.call(this);
  var d = Strata.deps(); this._d = d;
  var s = this._req.site; this._s = s;
  this._st = d.core.start(s);
  if (this._req.workedOut) { for (var i = 0; i < this._st.depth.length; i++) this._st.depth[i] = 0; this._st.collapsed = true; }
  this._tool = 'pick'; this._cx = Math.floor(s.cols / 2); this._cy = Math.floor(s.rows / 2);
  this._mode = this._req.workedOut ? 'done' : 'dig';
  this._frame = 0; this._shake = 0; this._doneWait = this._req.workedOut ? 120 : 0; this._status = ''; this._tone = '';
  this.createBackdrop(); this.createFace(); this.createDust(); this.createUi();
  this.redrawFace(); this.redrawCrack(); this.redrawTools(); this.redrawFound();
  this.setStatus(this._req.workedOut ? 'This face is worked out. Nothing more to find here.' : 'Free every find before the face gives way.', '');
};

Scene_Strata.prototype.start = function () { Scene_Base.prototype.start.call(this); this.startFadeIn(this.fadeSpeed(), false); };

Scene_Strata.prototype.createBackdrop = function () {
  var d = this._d, W = Graphics.width, H = Graphics.height, s = this._s;
  var bmp = new Bitmap(W, H), ctx = bmp.context;
  d.draw.drawBackdrop(ctx, W, H);
  d.draw.drawFrame(ctx, Scene_Strata.FACE_X, Scene_Strata.FACE_Y, s.cols * d.draw.CELL, s.rows * d.draw.CELL, s.seed);
  bmp._baseTexture.update();
  this.addChild(new Sprite(bmp));
};

Scene_Strata.prototype.createFace = function () {
  var d = this._d, s = this._s, W = s.cols * d.draw.CELL, H = s.rows * d.draw.CELL;
  this._faceLayer = new Sprite(); this._faceLayer.x = Scene_Strata.FACE_X; this._faceLayer.y = Scene_Strata.FACE_Y;
  var under = new Bitmap(W, H), uctx = under.context;
  d.draw.drawUnder(uctx, s.site, W, H, s.seed);
  for (var f = 0; f < s.finds.length; f++) {
    var F = s.finds[f];
    uctx.save(); uctx.translate(F.x * d.draw.CELL, F.y * d.draw.CELL); d.draw.drawFind(uctx, F, F.w, F.h); uctx.restore();
  }
  under._baseTexture.update();
  this._faceLayer.addChild(new Sprite(under));
  this._faceSprite = new Sprite(new Bitmap(W, H));
  this._faceLayer.addChild(this._faceSprite);
  this._markSprite = new Sprite(new Bitmap(3 * d.draw.CELL + 8, 3 * d.draw.CELL + 8));
  this._markSprite.anchor.x = this._markSprite.anchor.y = 0.5;
  this._faceLayer.addChild(this._markSprite);
  this.addChild(this._faceLayer);
};

Scene_Strata.prototype.createDust = function () {
  var bmp = new Bitmap(8, 8), ctx = bmp.context;
  var g = ctx.createRadialGradient(4, 4, 0, 4, 4, 4); g.addColorStop(0, 'rgba(235,215,185,0.95)'); g.addColorStop(1, 'rgba(235,215,185,0)');
  ctx.fillStyle = g; ctx.fillRect(0, 0, 8, 8); bmp._baseTexture.update();
  this._dust = []; this._dustVx = []; this._dustVy = []; this._dustLife = [];
  for (var i = 0; i < Scene_Strata.DUST; i++) {
    var sp = new Sprite(bmp); sp.anchor.x = sp.anchor.y = 0.5; sp.visible = false;
    this._faceLayer.addChild(sp); this._dust.push(sp); this._dustVx.push(0); this._dustVy.push(0); this._dustLife.push(0);
  }
  this._dustNext = 0;
};

Scene_Strata.prototype.createUi = function () {
  var W = Graphics.width;
  this._heading = new Sprite(new Bitmap(W, 60)); this._heading.y = 6;
  this._d.draw.drawHeading(this._heading.bitmap.context, W, this._req.title, 'arrows move  ·  OK strikes  ·  Q / W change tool  ·  Esc packs up');
  this._heading.bitmap._baseTexture.update();
  this._crack = new Sprite(new Bitmap(this._s.cols * this._d.draw.CELL, 28)); this._crack.x = Scene_Strata.FACE_X; this._crack.y = 64;
  this._status = new Sprite(new Bitmap(W, 34)); this._status.y = 526;
  this._tools = new Sprite(new Bitmap(170, 70)); this._tools.x = 150; this._tools.y = 552;
  this._found = new Sprite(new Bitmap(360, 70)); this._found.x = 320; this._found.y = 552;
  this.addChild(this._heading); this.addChild(this._crack); this.addChild(this._status); this.addChild(this._tools); this.addChild(this._found);
  this._statusText = '';
};

Scene_Strata.prototype.setStatus = function (text, tone) {
  if (text === this._statusText && tone === this._tone) return;
  this._statusText = text; this._tone = tone || '';
  this._d.draw.drawStatus(this._status.bitmap.context, Graphics.width, text, tone); this._status.bitmap._baseTexture.update();
};

/** Redraw the face bitmap: ON A STRIKE ONLY, never per frame. */
Scene_Strata.prototype.redrawFace = function () {
  var d = this._d, s = this._s, b = this._faceSprite.bitmap, ctx = b.context;
  ctx.clearRect(0, 0, b.width, b.height);
  d.draw.drawFace(ctx, s.site, s, this._st.depth, s.depth);
  for (var y = 0; y < s.rows; y++) for (var x = 0; x < s.cols; x++) if (s.rock[y * s.cols + x]) d.draw.drawBedrock(ctx, x, y, s.seed);
  b._baseTexture.update();
};

Scene_Strata.prototype.redrawCrack = function () {
  this._d.draw.drawStabilityCrack(this._crack.bitmap.context, this._crack.bitmap.width, this._st.stress / this._s.stability, this._s.seed);
  this._crack.bitmap._baseTexture.update();
};

Scene_Strata.prototype.redrawTools = function () {
  var b = this._tools.bitmap, ctx = b.context, d = this._d;
  ctx.clearRect(0, 0, b.width, b.height);
  ctx.save(); ctx.translate(34, 34); d.draw.drawTool(ctx, 'pick', 26, this._tool === 'pick'); ctx.restore();
  ctx.save(); ctx.translate(104, 34); d.draw.drawTool(ctx, 'hammer', 26, this._tool === 'hammer'); ctx.restore();
  b._baseTexture.update();
};

Scene_Strata.prototype.redrawFound = function () {
  var b = this._found.bitmap, ctx = b.context, d = this._d, s = this._s;
  ctx.clearRect(0, 0, b.width, b.height);
  var freed = d.core.freedList(s, this._st);
  for (var i = 0; i < s.finds.length; i++) {
    var F = s.finds[i], x = 6 + i * 88;
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fillRect(x, 4, 80, 62);
    ctx.strokeStyle = freed.indexOf(i) >= 0 ? '#e8c77e' : 'rgba(200,170,120,0.35)'; ctx.lineWidth = 1.5; ctx.strokeRect(x + 0.5, 4.5, 79, 61);
    if (freed.indexOf(i) >= 0) {
      var sc = Math.min(74 / (F.w * d.draw.CELL), 56 / (F.h * d.draw.CELL));
      ctx.save(); ctx.translate(x + 40 - F.w * d.draw.CELL * sc / 2, 35 - F.h * d.draw.CELL * sc / 2); ctx.scale(sc, sc); d.draw.drawFind(ctx, F, F.w, F.h); ctx.restore();
    } else {
      ctx.fillStyle = 'rgba(220,190,140,0.5)'; ctx.font = 'italic 26px ' + d.draw.FACE; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('?', x + 40, 36);
    }
  }
  b._baseTexture.update();
};

//---------------------------------------------------------------------------- per frame: numbers only

Scene_Strata.prototype.update = function () {
  Scene_Base.prototype.update.call(this);
  this._frame++;
  if (this._mode === 'dig') this.updateInput();
  this.updateMark(); this.updateDust();
  if (this._shake > 0) { this._shake--; this._faceLayer.x = Scene_Strata.FACE_X + ((this._shake & 1) ? 2 : -2) * (this._shake / 8); } else this._faceLayer.x = Scene_Strata.FACE_X;
  if (this._mode === 'done' && --this._doneWait <= 0 && !this.isBusy()) { this._mode = 'leaving'; this.popScene(); }
};

Scene_Strata.prototype.updateMark = function () {
  var m = this._markSprite, C = this._d.draw.CELL;
  m.visible = this._mode === 'dig';
  m.x = this._cx * C + C / 2; m.y = this._cy * C + C / 2;
  m.opacity = 190 + Math.round(60 * Math.sin(this._frame * 0.15));
  if (this._markTool !== this._tool) {
    this._markTool = this._tool;
    var b = m.bitmap, ctx = b.context, s = C, o = 4 + C;
    ctx.clearRect(0, 0, b.width, b.height);
    ctx.strokeStyle = '#ffe7a8'; ctx.lineWidth = 2.5; ctx.strokeRect(o + 1, o + 1, s - 2, s - 2);
    ctx.strokeStyle = 'rgba(255,231,168,0.55)'; ctx.lineWidth = 1.5; ctx.setLineDash([4, 3]);
    if (this._tool === 'hammer') ctx.strokeRect(4, 4, 3 * s, 3 * s);
    else { ctx.beginPath(); ctx.moveTo(o, 4); ctx.lineTo(o + s, 4); ctx.lineTo(o + s, o); ctx.lineTo(o + 2 * s, o); ctx.lineTo(o + 2 * s, o + s); ctx.lineTo(o + s, o + s); ctx.lineTo(o + s, o + 2 * s); ctx.lineTo(o, o + 2 * s); ctx.lineTo(o, o + s); ctx.lineTo(4, o + s); ctx.lineTo(4, o); ctx.lineTo(o, o); ctx.closePath(); ctx.stroke(); }
    ctx.setLineDash([]);
    b._baseTexture.update();
  }
};

Scene_Strata.prototype.updateDust = function () {
  for (var i = 0; i < this._dust.length; i++) {
    if (this._dustLife[i] <= 0) continue;
    var sp = this._dust[i];
    this._dustLife[i]--; sp.x += this._dustVx[i]; sp.y += this._dustVy[i]; this._dustVy[i] += 0.18;
    sp.opacity = Math.min(255, this._dustLife[i] * 12);
    if (this._dustLife[i] <= 0) sp.visible = false;
  }
};

Scene_Strata.prototype.puff = function (cx, cy, n) {
  var C = this._d.draw.CELL, r = this._d.core.rng((this._frame * 2654435761) >>> 0);
  for (var k = 0; k < n; k++) {
    var i = this._dustNext; this._dustNext = (this._dustNext + 1) % this._dust.length;
    var sp = this._dust[i];
    sp.visible = true; sp.x = cx * C + C / 2 + (r() - 0.5) * C; sp.y = cy * C + C / 2 + (r() - 0.5) * C;
    sp.scale.x = sp.scale.y = 0.8 + r() * 1.6;
    this._dustVx[i] = (r() - 0.5) * 3.2; this._dustVy[i] = -1.5 - r() * 2.2; this._dustLife[i] = 18 + Math.floor(r() * 16);
  }
};

//---------------------------------------------------------------------------- input and the blow itself

Scene_Strata.prototype.playSe = function (name) { if (name && typeof AudioManager !== 'undefined') AudioManager.playSe({ name: name, volume: 90, pitch: 100, pan: 0 }); };

Scene_Strata.prototype.updateInput = function () {
  var s = this._s;
  if (TouchInput.isTriggered()) { this.onTouch(TouchInput.x, TouchInput.y); return; }
  if (Input.isRepeated('left')) this._cx = Math.max(0, this._cx - 1);
  else if (Input.isRepeated('right')) this._cx = Math.min(s.cols - 1, this._cx + 1);
  else if (Input.isRepeated('up')) this._cy = Math.max(0, this._cy - 1);
  else if (Input.isRepeated('down')) this._cy = Math.min(s.rows - 1, this._cy + 1);
  else if (Input.isTriggered('pageup') || Input.isTriggered('pagedown') || Input.isTriggered('shift')) this.switchTool();
  else if (Input.isTriggered('ok')) this.strikeAt(this._cx, this._cy);
  else if (Input.isTriggered('cancel') || TouchInput.isCancelled()) this.packUp();
};

Scene_Strata.prototype.switchTool = function () { this._tool = this._tool === 'pick' ? 'hammer' : 'pick'; this.redrawTools(); this.playSe(Strata.params.toolSe); };

Scene_Strata.prototype.onTouch = function (x, y) {
  var C = this._d.draw.CELL, s = this._s;
  if (y >= this._tools.y && y <= this._tools.y + 70 && x >= this._tools.x && x <= this._tools.x + 140) {
    var t = x - this._tools.x < 70 ? 'pick' : 'hammer';
    if (t !== this._tool) this.switchTool();
    return;
  }
  var col = Math.floor((x - Scene_Strata.FACE_X) / C), row = Math.floor((y - Scene_Strata.FACE_Y) / C);
  if (col >= 0 && row >= 0 && col < s.cols && row < s.rows) { this._cx = col; this._cy = row; this.strikeAt(col, row); }
};

Scene_Strata.prototype.strikeAt = function (col, row) {
  var d = this._d, s = this._s;
  var res = d.core.strike(s, this._st, this._tool, col, row);
  this.playSe(this._tool === 'hammer' ? Strata.params.hammerSe : Strata.params.strikeSe);
  this._shake = this._tool === 'hammer' ? 10 : 5;
  this.puff(col, row, this._tool === 'hammer' ? 10 : 5);
  this.redrawFace(); this.redrawCrack();
  this._lastStrike = res;
  if (res.freed.length) { this.playSe(Strata.params.freeSe); this.redrawFound(); }
  var freed = d.core.freedList(s, this._st);
  // a find freed by the blow that also brings the face down still counts (StrataCore: the Underground rule)
  if (freed.length === s.finds.length) {
    if (res.collapsed) { this.playSe(Strata.params.collapseSe); return this.end('Every find is free, just as the face gives way.', 'good'); }
    return this.end('Every find is free. The face holds.', 'good');
  }
  if (res.collapsed) { this.playSe(Strata.params.collapseSe); this.collapse(); return this.end('The face gives way. ' + freed.length + ' of ' + s.finds.length + ' saved.', 'bad'); }
  if (res.freed.length) this.setStatus('Free! ' + freed.length + ' of ' + s.finds.length + ' found.', 'good');
  else if (!res.changed.length) this.setStatus('Nothing gives there.', '');
  else if (this._st.stress / s.stability > 0.8) this.setStatus('The face is groaning. Careful.', 'bad');
  else this.setStatus(this._tool === 'hammer' ? 'The hammer bites wide.' : 'The pick bites deep.', '');
};

/** The collapse: every cell still holding rock falls back to full thickness over what it buried. */
Scene_Strata.prototype.collapse = function () {
  var s = this._s, freed = this._d.core.freedList(s, this._st);
  for (var c = 0; c < this._st.depth.length; c++) {
    var own = this._d.core.findAt(s, c);
    if (own >= 0 && freed.indexOf(own) >= 0) continue;
    this._st.depth[c] = Math.max(this._st.depth[c], 1);
  }
  this._shake = 26; this.puff(Math.floor(s.cols / 2), 1, 20);
  this.redrawFace();
};

Scene_Strata.prototype.end = function (text, tone) {
  var freed = this._d.core.freedList(this._s, this._st);
  this._gained = Strata.finish(this._req, freed);
  this._mode = 'done'; this._doneWait = 110;
  this.setStatus(text, tone); this.redrawFound();
};

Scene_Strata.prototype.packUp = function () {
  var freed = this._d.core.freedList(this._s, this._st);
  this.end('You pack up with ' + freed.length + ' of ' + this._s.finds.length + '.', '');
  this._doneWait = 40;
};
