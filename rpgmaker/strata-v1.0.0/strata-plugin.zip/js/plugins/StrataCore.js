//=============================================================================
// StrataCore.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Strata core - generates excavation dig sites and their
 * fair stability budgets. Place ABOVE StrataDraw and Strata.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The dig generator and rules for Strata. No parameters or commands of its
 * own; Strata.js is the file you configure. Must be installed and listed
 * above Strata.js.
 *
 * Pure logic: nothing here touches the screen and nothing uses Math.random.
 * Every dig comes from a seed, so the same site is the same site on every
 * playthrough and every machine.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var StrataCore = (function () {
  'use strict';

  var COLS = 13, ROWS = 10;

  /**
   * Find families and their footprints, as [col,row] cells relative to an
   * origin. A family may be laid rotated a quarter turn (rot: true).
   */
  var FAMILIES = {
    ammonite: { cells: [[0, 0], [1, 0], [2, 0], [0, 1], [1, 1], [2, 1], [0, 2], [1, 2], [2, 2]], rot: false },
    trilobite: { cells: [[0, 0], [1, 0], [0, 1], [1, 1], [0, 2], [1, 2]], rot: true },
    bone: { cells: [[0, 0], [1, 0], [2, 0], [3, 0]], rot: true },
    tooth: { cells: [[0, 0], [0, 1]], rot: true },
    amber: { cells: [[0, 0], [1, 0], [0, 1], [1, 1]], rot: false },
    geode: { cells: [[0, 0], [1, 0], [0, 1], [1, 1]], rot: false },
    ore: { cells: [[0, 0], [1, 0], [2, 0], [1, 1], [2, 1]], rot: true },
    crystal: { cells: [[1, 0], [0, 1], [1, 1], [1, 2]], rot: true },
    tablet: { cells: [[0, 0], [1, 0], [0, 1], [1, 1], [0, 2], [1, 2]], rot: true },
    shell: { cells: [[0, 0], [1, 0], [0, 1], [1, 1]], rot: false },
  };
  var FAMILY_IDS = Object.keys(FAMILIES);
  var SITES = ['sandstone', 'shale', 'limestone', 'clay', 'basalt'];

  /** Tools: damage at the target and to neighbours, and the stress each blow adds. */
  var TOOLS = {
    pick: { center: 2, ortho: 1, diag: 0, stress: 2 },
    hammer: { center: 2, ortho: 2, diag: 1, stress: 4 },
  };

  /** Grades: finds, bedrock, depth range and the slack over the greedy budget. */
  /**
   * q = the quantile of a SIGHTED digger's stress-to-clear that the budget is set at, so roughly q of
   * attentive players clear the whole face at that grade. slack = the floor over the omniscient greedy plan.
   * (MEASURED 2026-09-23: a budget from the greedy plan alone let a sighted digger free only 16% of finds at
   * grade 1, because the greedy knows where everything is and a player does not.)
   */
  var GRADES = {
    1: { finds: [2, 2], rocks: [1, 2], depth: [2, 4], slack: 1.15, q: 0.9 },
    2: { finds: [2, 3], rocks: [2, 3], depth: [2, 5], slack: 1.15, q: 0.75 },
    3: { finds: [3, 3], rocks: [2, 4], depth: [3, 5], slack: 1.15, q: 0.6 },
    4: { finds: [3, 4], rocks: [3, 4], depth: [3, 6], slack: 1.15, q: 0.45 },
    5: { finds: [4, 4], rocks: [3, 5], depth: [4, 6], slack: 1.15, q: 0.3 },
  };
  var PROSPECT_RUNS = 24;

  //===========================================================================
  // Deterministic randomness
  //===========================================================================

  function hashString(s) {
    var h = 0x811c9dc5; s = String(s);
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; }
    return h >>> 0;
  }
  function rng(seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function pick(r, arr) { return arr[Math.floor(r() * arr.length) % arr.length]; }
  function between(r, lo, hi) { return lo + Math.floor(r() * (hi - lo + 1)); }

  //===========================================================================
  // Generation
  //===========================================================================

  function footprint(fam, rot) {
    var c = FAMILIES[fam].cells;
    if (!rot) return c.map(function (p) { return [p[0], p[1]]; });
    return c.map(function (p) { return [p[1], p[0]]; });
  }

  /**
   * Generate a dig site.
   * @param {Object} opt {seed, grade 1..5, site?, families?: string[] (one per find, from the buyer's items)}
   * @returns {Object} plain data: {cols, rows, depth[], rock[], finds[], stability, site, grade, seed}
   */
  function generate(opt) {
    opt = opt || {};
    var grade = Math.max(1, Math.min(5, Math.round(Number(opt.grade) || 2)));
    var seed = Number(opt.seed) >>> 0;
    var G = GRADES[grade];
    for (var attempt = 0; attempt < 200; attempt++) {
      var r = rng((seed ^ Math.imul(attempt + 1, 0x9E3779B1)) >>> 0);
      var s = tryGenerate(r, G, opt);
      if (s) {
        s.grade = grade; s.seed = seed; s.attempt = attempt;
        var r2 = rng((seed ^ 0x5173) >>> 0);
        s.site = SITES.indexOf(opt.site) >= 0 ? opt.site : pick(r2, SITES);
        return s;
      }
    }
    throw new Error('StrataCore.generate: no layout for seed ' + seed);
  }

  function tryGenerate(r, G, opt) {
    var n = COLS * ROWS;
    var depth = new Array(n), rock = new Array(n), owner = new Array(n);
    // smooth depth field: two coarse value-noise octaves, so the face has hollows and ridges
    var g1 = [], g2 = [];
    for (var i = 0; i < 20; i++) { g1.push(r()); g2.push(r()); }
    for (var y = 0; y < ROWS; y++) for (var x = 0; x < COLS; x++) {
      var v = 0.6 * noise(g1, x / 4.3, y / 3.7) + 0.4 * noise(g2, x / 2.1 + 3, y / 1.9 + 7);
      depth[y * COLS + x] = G.depth[0] + Math.round(v * (G.depth[1] - G.depth[0]));
      rock[y * COLS + x] = 0; owner[y * COLS + x] = -1;
    }
    var nf = between(r, G.finds[0], G.finds[1]);
    var fams = (opt.families && opt.families.length) ? opt.families.slice(0, nf) : [];
    while (fams.length < nf) fams.push(pick(r, FAMILY_IDS));
    var finds = [];
    for (var f = 0; f < nf; f++) {
      var fam = FAMILIES[fams[f]] ? fams[f] : pick(r, FAMILY_IDS);
      var placed = false;
      for (var t = 0; t < 60 && !placed; t++) {
        var rot = FAMILIES[fam].rot && r() < 0.5;
        var fp = footprint(fam, rot);
        var w = 0, h = 0; fp.forEach(function (p) { w = Math.max(w, p[0] + 1); h = Math.max(h, p[1] + 1); });
        var ox = between(r, 0, COLS - w), oy = between(r, 0, ROWS - h);
        var ok = true;
        for (var k = 0; k < fp.length && ok; k++) {
          var cx = ox + fp[k][0], cy = oy + fp[k][1];
          // keep a one-cell moat between finds so no single blow frees two at once
          for (var dy = -1; dy <= 1 && ok; dy++) for (var dx = -1; dx <= 1 && ok; dx++) {
            var qx = cx + dx, qy = cy + dy;
            if (qx < 0 || qy < 0 || qx >= COLS || qy >= ROWS) continue;
            if (owner[qy * COLS + qx] >= 0) ok = false;
          }
        }
        if (!ok) continue;
        var cells = fp.map(function (p) { return (oy + p[1]) * COLS + (ox + p[0]); });
        cells.forEach(function (c) { owner[c] = finds.length; });
        finds.push({ family: fam, rot: rot, x: ox, y: oy, w: w, h: h, cells: cells, variant: Math.floor(r() * 1e9) });
        placed = true;
      }
      if (!placed) return null;
    }
    // bedrock: unbreakable stones, never on a find
    var nr = between(r, G.rocks[0], G.rocks[1]);
    for (var b = 0; b < nr; b++) {
      for (var tb = 0; tb < 40; tb++) {
        var bw = r() < 0.5 ? 1 : 2, bh = r() < 0.6 ? 1 : 2;
        var bx = between(r, 0, COLS - bw), by = between(r, 0, ROWS - bh), clear = true;
        for (var yy = by; yy < by + bh && clear; yy++) for (var xx = bx; xx < bx + bw; xx++) if (owner[yy * COLS + xx] >= 0 || rock[yy * COLS + xx]) clear = false;
        if (!clear) continue;
        for (var y2 = by; y2 < by + bh; y2++) for (var x2 = bx; x2 < bx + bw; x2++) rock[y2 * COLS + x2] = 1;
        break;
      }
    }
    var site = { v: 1, cols: COLS, rows: ROWS, depth: depth, rock: rock, finds: finds };
    var greedy = greedyPlan(site);
    if (!greedy.clearedAll) return null;
    site.greedyStress = greedy.stress;
    site.greedyBlows = greedy.blows;
    // calibrate against a player who cannot see underground: PROSPECT_RUNS seeded sighted digs, no budget
    var need = [];
    for (var pr = 0; pr < PROSPECT_RUNS; pr++) need.push(prospect(site, rng(Math.floor(r() * 4294967296))).stress);
    need.sort(function (a, b) { return a - b; });
    var qi = Math.min(need.length - 1, Math.max(0, Math.round(G.q * (need.length - 1))));
    site.prospectStress = need[qi];
    site.stability = Math.max(Math.ceil(greedy.stress * G.slack) + 2, need[qi] + 1);
    return site;
  }

  /**
   * A SIGHTED digger - a model of an attentive player, not an oracle. It cannot see underground: until part
   * of a find shows, it strikes at random; once part shows, three blows in four go to a still-buried cell of a
   * showing find, with the hammer when there is a lot left to clear. Runs with NO budget and reports the stress
   * it needed to free everything.
   * @returns {{stress:number, blows:number}}
   */
  function prospect(site, r) {
    var st = start(site), guard = 0, n = site.cols * site.rows;
    var probe = { stability: 1e9, cols: site.cols, rows: site.rows, rock: site.rock, finds: site.finds };
    while (freedList(site, st).length < site.finds.length && guard++ < 2000) {
      var showing = [];
      for (var f = 0; f < site.finds.length; f++) {
        var cells = site.finds[f].cells, open = false, shut = false;
        for (var k = 0; k < cells.length; k++) { if (st.depth[cells[k]] === 0) open = true; else shut = true; }
        if (open && shut) for (var k2 = 0; k2 < cells.length; k2++) if (st.depth[cells[k2]] > 0) showing.push(cells[k2]);
      }
      var c = (showing.length && r() < 0.75) ? showing[Math.floor(r() * showing.length)] : Math.floor(r() * n);
      strike(probe, st, showing.length > 3 ? 'hammer' : 'pick', c % site.cols, Math.floor(c / site.cols));
    }
    return { stress: st.stress, blows: st.blows };
  }

  /** Bilinear value noise over a 5x4 lattice of seeds. */
  function noise(g, x, y) {
    var xi = Math.floor(x), yi = Math.floor(y), fx = x - xi, fy = y - yi;
    var at = function (a, b) { return g[(((a % 5) + 5) % 5) + 5 * (((b % 4) + 4) % 4)]; };
    var sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy);
    var top = at(xi, yi) * (1 - sx) + at(xi + 1, yi) * sx;
    var bot = at(xi, yi + 1) * (1 - sx) + at(xi + 1, yi + 1) * sx;
    return top * (1 - sy) + bot * sy;
  }

  //===========================================================================
  // Play: the state is a copy of the depth grid plus the stress spent
  //===========================================================================

  /** @returns {Object} a fresh play state for a site */
  function start(site) { return { depth: site.depth.slice(), stress: 0, blows: 0, collapsed: false }; }

  /**
   * Strike. Bedrock takes nothing and passes nothing on; a cleared cell stays
   * cleared. Stress is spent even on a wasted blow.
   * @returns {{changed:number[], collapsed:boolean, freed:number[]}} cells changed and finds newly freed
   */
  function strike(site, st, tool, col, row) {
    var T = TOOLS[tool] || TOOLS.pick;
    var out = { changed: [], collapsed: false, freed: [] };
    if (st.collapsed) return out;
    if (col < 0 || row < 0 || col >= site.cols || row >= site.rows) return out;
    var before = freedList(site, st);
    for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) {
      var x = col + dx, y = row + dy;
      if (x < 0 || y < 0 || x >= site.cols || y >= site.rows) continue;
      var dmg = (dx === 0 && dy === 0) ? T.center : (dx === 0 || dy === 0) ? T.ortho : T.diag;
      var c = y * site.cols + x;
      if (dmg <= 0 || site.rock[c] || st.depth[c] <= 0) continue;
      st.depth[c] = Math.max(0, st.depth[c] - dmg);
      out.changed.push(c);
    }
    st.stress += T.stress; st.blows++;
    if (st.stress >= site.stability) { st.stress = site.stability; st.collapsed = true; out.collapsed = true; }
    var after = freedList(site, st);
    for (var i = 0; i < after.length; i++) if (before.indexOf(after[i]) < 0) out.freed.push(after[i]);
    return out;
  }

  /** @returns {number[]} indices of finds whose every cell is cleared */
  function freedList(site, st) {
    var out = [];
    for (var f = 0; f < site.finds.length; f++) {
      var all = true, cells = site.finds[f].cells;
      for (var k = 0; k < cells.length; k++) if (st.depth[cells[k]] > 0) { all = false; break; }
      if (all) out.push(f);
    }
    return out;
  }

  /**
   * A greedy digger: each blow picks the tool and cell that removes the most
   * depth still standing over UNFREED find cells, per unit of stress. The
   * site's stability is derived from what this strategy spends, so every
   * generated dig can be cleared completely by play this good.
   */
  function greedyPlan(site) {
    var st = start(site), guard = 0, log = [];
    while (freedList(site, st).length < site.finds.length && guard++ < 400) {
      var best = null, bestScore = 0;
      for (var tool in TOOLS) {
        var T = TOOLS[tool];
        for (var y = 0; y < site.rows; y++) for (var x = 0; x < site.cols; x++) {
          var gain = 0;
          for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) {
            var qx = x + dx, qy = y + dy;
            if (qx < 0 || qy < 0 || qx >= site.cols || qy >= site.rows) continue;
            var c = qy * site.cols + qx;
            var own = findAt(site, c);
            if (own < 0 || site.rock[c] || st.depth[c] <= 0) continue;
            var dmg = (dx === 0 && dy === 0) ? T.center : (dx === 0 || dy === 0) ? T.ortho : T.diag;
            gain += Math.min(dmg, st.depth[c]);
          }
          var score = gain / T.stress;
          if (score > bestScore) { bestScore = score; best = { tool: tool, x: x, y: y }; }
        }
      }
      if (!best) break;
      // the budget is not spent here, so a greedy plan can run past it; stability is set from its total
      var T2 = TOOLS[best.tool];
      for (var ddy = -1; ddy <= 1; ddy++) for (var ddx = -1; ddx <= 1; ddx++) {
        var ax = best.x + ddx, ay = best.y + ddy;
        if (ax < 0 || ay < 0 || ax >= site.cols || ay >= site.rows) continue;
        var cc = ay * site.cols + ax;
        var dm = (ddx === 0 && ddy === 0) ? T2.center : (ddx === 0 || ddy === 0) ? T2.ortho : T2.diag;
        if (dm > 0 && !site.rock[cc]) st.depth[cc] = Math.max(0, st.depth[cc] - dm);
      }
      st.stress += T2.stress; st.blows++;
      log.push(best);
    }
    return { clearedAll: freedList(site, st).length === site.finds.length, stress: st.stress, blows: st.blows, plan: log };
  }

  function findAt(site, c) {
    for (var f = 0; f < site.finds.length; f++) if (site.finds[f].cells.indexOf(c) >= 0) return f;
    return -1;
  }

  /** Play a whole plan through strike(), honouring the budget. @returns {{freed:number, collapsed:boolean, stress:number}} */
  function replay(site, plan) {
    var st = start(site);
    for (var i = 0; i < plan.length && !st.collapsed; i++) strike(site, st, plan[i].tool, plan[i].x, plan[i].y);
    return { freed: freedList(site, st).length, collapsed: st.collapsed, stress: st.stress };
  }

  return {
    VERSION: '1.0.0', COLS: COLS, ROWS: ROWS, FAMILIES: FAMILIES, FAMILY_IDS: FAMILY_IDS, SITES: SITES, TOOLS: TOOLS, GRADES: GRADES,
    hashString: hashString, rng: rng, generate: generate, start: start, strike: strike, freedList: freedList,
    greedyPlan: greedyPlan, replay: replay, findAt: findAt, footprint: footprint, prospect: prospect,
  };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = StrataCore;
