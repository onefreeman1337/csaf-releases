/*:
 * @target MZ
 * @plugindesc [CSAF] Smithereens core: materials and seeded fracture maps. Install with Smithereens.js.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io/smithereens
 * @help SmithereensCore.js
 *
 * The engine-free half of Smithereens: the material table and the fracture
 * generators that decide how a graphic comes apart. It has no parameters and
 * no commands of its own. Install it beside Smithereens.js and
 * SmithereensCut.js; the order of the three files in the Plugin Manager does
 * not matter.
 *
 * Copyright (c) Core Systems Asset Factory. See LICENSE.txt.
 */

/**
 * How a break is decided
 * ----------------------
 * A graphic arrives as an opacity MASK (one byte per pixel, non-zero = opaque)
 * cut from the exact frame the event is showing. fracture() assigns every
 * opaque pixel to exactly one fragment and every transparent pixel to none, so
 * no art is lost or duplicated by construction. Each material builds its
 * fragments a different way (a different STRUCTURE, not a different colour):
 *
 *   ceramic  curved sherds: sectors that spiral out from the impact, cut by a
 *            wavy ring
 *   wood     splinters: thin strips along the grain, each broken with a
 *            slanted tip
 *   stone    angular chunks: a Voronoi partition, more chunks on bigger rocks
 *   crystal  facets: straight wedges from the impact, cut by a ring
 *   ice      slabs: a few wide wedges split by one straight crack
 *   foliage  a rooted stub at the base, many small clippings above it
 *   generic  plain pixel-aligned chunks (the fallback for unknown material)
 *
 * Every fragment is 4-connected; fragments smaller than MIN_FRAGMENT pixels
 * are merged into their largest neighbour. The same mask, material and seed
 * always give the same fragments.
 */
(function (root) {
  'use strict';
  const CSAF = (root.CSAF = root.CSAF || {});
  if (CSAF.SmithereensCore) return;

  const MATERIALS = ['ceramic', 'wood', 'stone', 'crystal', 'ice', 'foliage', 'generic'];
  const MIN_FRAGMENT = 3;
  const TAU = Math.PI * 2;

  /**
   * 32-bit FNV-1a string hash.
   * @param {string} str
   * @returns {number} unsigned 32-bit hash
   */
  function hash(str) {
    let h = 2166136261 >>> 0;
    const s = String(str);
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619) >>> 0;
    }
    return h >>> 0;
  }

  /**
   * Seeded random stream (mulberry32). Never Math.random in a break.
   * @param {number} seed
   * @constructor
   */
  function Rng(seed) {
    this.s = (seed >>> 0) || 1;
  }
  /** @returns {number} a float in [0, 1) */
  Rng.prototype.next = function () {
    let t = (this.s = (this.s + 0x6d2b79f5) >>> 0);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  /** @returns {number} a float in [a, b) */
  Rng.prototype.range = function (a, b) {
    return a + (b - a) * this.next();
  };
  /** @returns {number} an integer in [a, b] inclusive */
  Rng.prototype.int = function (a, b) {
    return a + Math.floor((b - a + 1) * this.next());
  };

  function clamp(v, a, b) {
    return v < a ? a : v > b ? b : v;
  }

  /**
   * Area, bounds and centroid of the opaque pixels of a mask.
   * @param {Uint8Array} mask
   * @param {number} w
   * @param {number} h
   * @returns {{area:number,minX:number,minY:number,maxX:number,maxY:number,cx:number,cy:number}}
   */
  function maskInfo(mask, w, h) {
    let area = 0, minX = w, minY = h, maxX = -1, maxY = -1, sx = 0, sy = 0;
    for (let y = 0; y < h; y++) {
      const row = y * w;
      for (let x = 0; x < w; x++) {
        if (!mask[row + x]) continue;
        area++;
        sx += x + 0.5;
        sy += y + 0.5;
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
    return { area, minX, minY, maxX, maxY, cx: area ? sx / area : w / 2, cy: area ? sy / area : h / 2 };
  }

  /**
   * @param {string} m
   * @returns {string} a known material id; anything else is 'generic'
   */
  function normalizeMaterial(m) {
    const s = String(m || '').trim().toLowerCase();
    return MATERIALS.indexOf(s) >= 0 ? s : 'generic';
  }

  // The impact point, coerced: a NaN or missing coordinate becomes the centroid (a NaN must never reach a
  // threshold - wing §26e).
  function impactOf(info, opts) {
    const imp = opts && opts.impact;
    let x = imp ? Number(imp.x) : NaN;
    let y = imp ? Number(imp.y) : NaN;
    if (!isFinite(x)) x = info.cx;
    if (!isFinite(y)) y = info.cy;
    return { x, y };
  }

  function radiusFrom(mask, w, h, px, py) {
    let r = 0;
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        if (!mask[y * w + x]) continue;
        const dx = x + 0.5 - px, dy = y + 0.5 - py;
        const d = dx * dx + dy * dy;
        if (d > r) r = d;
      }
    }
    return Math.sqrt(r) || 1;
  }

  // Up to n seed points on opaque pixels, spaced so cells come out similar in size.
  function pickSeeds(mask, w, info, n, rng, allow) {
    const pts = [];
    const minD = Math.max(2, Math.sqrt(info.area / Math.max(1, n)) * 0.6);
    const spanX = info.maxX - info.minX + 1, spanY = info.maxY - info.minY + 1;
    let tries = 0;
    while (pts.length < n && tries < n * 80) {
      tries++;
      const x = info.minX + Math.floor(rng.next() * spanX);
      const y = info.minY + Math.floor(rng.next() * spanY);
      if (!mask[y * w + x]) continue;
      if (allow && !allow(x, y)) continue;
      let far = true;
      for (let k = 0; k < pts.length; k++) {
        const dx = pts[k].x - (x + 0.5), dy = pts[k].y - (y + 0.5);
        if (dx * dx + dy * dy < minD * minD) {
          far = false;
          break;
        }
      }
      if (far) pts.push({ x: x + 0.5, y: y + 0.5 });
    }
    if (!pts.length) pts.push({ x: info.cx, y: info.cy });
    return pts;
  }

  function nearest(pts, x, y) {
    let best = 0, bd = Infinity;
    for (let k = 0; k < pts.length; k++) {
      const dx = pts[k].x - x, dy = pts[k].y - y;
      const d = dx * dx + dy * dy;
      if (d < bd) {
        bd = d;
        best = k;
      }
    }
    return best;
  }

  // K sector boundaries around a full turn, widths 0.7-1.3 of the mean (so no sector exceeds 120 deg once K >= 6).
  function sectorCuts(K, rng) {
    const wts = [];
    let sum = 0;
    for (let k = 0; k < K; k++) {
      const v = rng.range(0.7, 1.3);
      wts.push(v);
      sum += v;
    }
    const base = rng.next() * TAU;
    const cuts = [base];
    let acc = base;
    for (let k = 0; k < K - 1; k++) {
      acc += (wts[k] / sum) * TAU;
      cuts.push(acc);
    }
    return cuts;
  }

  function sectorOf(a, cuts) {
    const base = cuts[0];
    let t = a - base;
    t = t - Math.floor(t / TAU) * TAU + base;
    let s = 0;
    for (let k = 1; k < cuts.length; k++) if (t >= cuts[k]) s = k;
    return s;
  }

  // Each generator returns { at(x, y) -> raw label >= 0, ...facts }. x, y are integer pixel coordinates.
  const GEN = {
    generic(c) {
      const cell = clamp(Math.round(Math.sqrt(c.info.area) / 3), 4, 10);
      const ox = Math.floor(c.rng.next() * cell), oy = Math.floor(c.rng.next() * cell);
      const cols = Math.ceil((c.w + cell) / cell) + 1;
      return { at: (x, y) => Math.floor((y + oy) / cell) * cols + Math.floor((x + ox) / cell) };
    },

    stone(c) {
      const n = clamp(Math.round(c.info.area / 55), 3, 16);
      const pts = pickSeeds(c.mask, c.w, c.info, n, c.rng, null);
      return { at: (x, y) => nearest(pts, x + 0.5, y + 0.5) };
    },

    crystal(c) {
      const K = c.rng.int(6, 9);
      const cuts = sectorCuts(K, c.rng);
      const ring = c.rmax * c.rng.range(0.38, 0.55);
      const imp = c.imp;
      return {
        at: (x, y) => {
          const dx = x + 0.5 - imp.x, dy = y + 0.5 - imp.y;
          return sectorOf(Math.atan2(dy, dx), cuts) * 2 + (dx * dx + dy * dy > ring * ring ? 1 : 0);
        },
      };
    },

    ice(c) {
      const K = c.rng.int(3, 5);
      const cuts = sectorCuts(K, c.rng);
      const ang = c.rng.next() * Math.PI;
      const nx = Math.cos(ang), ny = Math.sin(ang);
      const off = c.rng.range(0.25, 0.5) * c.rmax * (c.rng.next() < 0.5 ? -1 : 1);
      const imp = c.imp;
      return {
        at: (x, y) => {
          const dx = x + 0.5 - imp.x, dy = y + 0.5 - imp.y;
          return sectorOf(Math.atan2(dy, dx), cuts) * 2 + (dx * nx + dy * ny > off ? 1 : 0);
        },
      };
    },

    ceramic(c) {
      const K = c.rng.int(5, 8);
      const cuts = sectorCuts(K, c.rng);
      const curl = c.rng.range(0.6, 1.1) * (c.rng.next() < 0.5 ? -1 : 1);
      const phase = c.rng.next() * TAU;
      const rr = c.rng.range(0.4, 0.55);
      // The curl varies smoothly with angle (0.55x to 1.45x) so each sherd edge bends by its own amount - a
      // uniform curl read as a pinwheel on the first contact sheet (2026-09-19). |d(a)/d(theta)| stays > 0 for
      // |curl| <= 1.1, so sectors never cross.
      const wobPh = c.rng.next() * TAU;
      const imp = c.imp, rmax = c.rmax;
      return {
        curl,
        at: (x, y) => {
          const dx = x + 0.5 - imp.x, dy = y + 0.5 - imp.y;
          const r = Math.sqrt(dx * dx + dy * dy);
          const th = Math.atan2(dy, dx);
          const a = th - curl * (1 + 0.45 * Math.sin(2 * th + wobPh)) * (r / rmax);
          const ring = rmax * (rr + 0.12 * Math.sin(3 * a + phase));
          return sectorOf(a, cuts) * 2 + (r > ring ? 1 : 0);
        },
      };
    },

    wood(c) {
      const grain = c.opts && c.opts.grain === 'h' ? 'h' : 'v';
      const info = c.info;
      const lo = grain === 'v' ? info.minX : info.minY;
      const hi = grain === 'v' ? info.maxX : info.maxY;
      const alo = grain === 'v' ? info.minY : info.minX;
      const ahi = grain === 'v' ? info.maxY : info.maxX;
      const len = ahi - alo + 1;
      const edges = [];
      // Strip width scales with the object: 2-4 px strips on a 40 px barrel read as a lattice of sticks, not staves
      // (engine look 2026-09-19, W1). ~1/8 to ~1/5 of the width, never under 3 (wood_width.js: 1/12-1/7 only moved
      // the median from 3 to 4 px on a 40 px crate).
      const span = hi - lo + 1;
      const sLo = Math.max(3, Math.round(span / 8)), sHi = Math.max(sLo + 1, Math.round(span / 5));
      for (let p = lo; p <= hi; p += c.rng.int(sLo, sHi)) edges.push(p);
      const nb = clamp(Math.floor(len / 22), 1, 3);
      const strips = edges.map(() => {
        const cuts = [];
        const step = len / (nb + 1);
        for (let k = 0; k < nb; k++) cuts.push(alo + step * (k + 1) + c.rng.range(-step / 2, step / 2));
        cuts.sort((p, q) => p - q);
        return { cuts, slope: c.rng.next() < 0.5 ? -1 : 1 };
      });
      return {
        grain,
        at: (x, y) => {
          const across = grain === 'v' ? x : y, along = grain === 'v' ? y : x;
          let s = 0;
          while (s + 1 < edges.length && across >= edges[s + 1]) s++;
          const st = strips[s];
          const off = (across - edges[s]) * st.slope;
          let seg = 0;
          for (let k = 0; k < st.cuts.length; k++) if (along + off > st.cuts[k]) seg++;
          return s * 8 + seg;
        },
      };
    },

    foliage(c) {
      const info = c.info;
      const stubH = Math.max(2, Math.round(0.18 * (info.maxY - info.minY + 1)));
      const stubTop = info.maxY - stubH + 1;
      let upper = 0;
      for (let y = info.minY; y < stubTop; y++) for (let x = info.minX; x <= info.maxX; x++) if (c.mask[y * c.w + x]) upper++;
      const n = clamp(Math.round(upper / 18), 5, 36);
      const pts = pickSeeds(c.mask, c.w, info, n, c.rng, (x, y) => y < stubTop);
      return { stubRaw: 0, at: (x, y) => (y >= stubTop ? 0 : 1 + nearest(pts, x + 0.5, y + 0.5)) };
    },
  };

  // Turn raw labels into final fragments: split every raw label into 4-connected components, merge components
  // smaller than MIN_FRAGMENT into the neighbour they share most edge with, number the survivors in row-major
  // order of their first pixel (deterministic).
  function finalize(raw, w, h, stubRaw) {
    const N = w * h;
    const comp = new Int32Array(N).fill(-1);
    const compRaw = [], compArea = [];
    const stack = new Int32Array(N);
    for (let i = 0; i < N; i++) {
      if (raw[i] < 0 || comp[i] >= 0) continue;
      const id = compRaw.length, L = raw[i];
      compRaw.push(L);
      let area = 0, sp = 0;
      stack[sp++] = i;
      comp[i] = id;
      while (sp) {
        const j = stack[--sp];
        area++;
        const x = j % w;
        if (x > 0 && comp[j - 1] < 0 && raw[j - 1] === L) { comp[j - 1] = id; stack[sp++] = j - 1; }
        if (x < w - 1 && comp[j + 1] < 0 && raw[j + 1] === L) { comp[j + 1] = id; stack[sp++] = j + 1; }
        if (j >= w && comp[j - w] < 0 && raw[j - w] === L) { comp[j - w] = id; stack[sp++] = j - w; }
        if (j + w < N && comp[j + w] < 0 && raw[j + w] === L) { comp[j + w] = id; stack[sp++] = j + w; }
      }
      compArea.push(area);
    }
    const C = compRaw.length;
    const parent = new Int32Array(C);
    for (let k = 0; k < C; k++) parent[k] = k;
    const find = (k) => {
      while (parent[k] !== k) {
        parent[k] = parent[parent[k]];
        k = parent[k];
      }
      return k;
    };
    // merge small components, smallest first, until none has a neighbour left to join
    const isolated = new Uint8Array(C);
    let changed = true;
    while (changed) {
      changed = false;
      let target = -1, tArea = Infinity;
      for (let k = 0; k < C; k++) {
        if (find(k) !== k || compArea[k] >= MIN_FRAGMENT || isolated[k]) continue;
        if (compArea[k] < tArea) { tArea = compArea[k]; target = k; }
      }
      if (target < 0) break;
      const shared = new Map();
      for (let i = 0; i < N; i++) {
        if (comp[i] < 0 || find(comp[i]) !== target) continue;
        const x = i % w;
        const nb = [x > 0 ? i - 1 : -1, x < w - 1 ? i + 1 : -1, i >= w ? i - w : -1, i + w < N ? i + w : -1];
        for (let q = 0; q < 4; q++) {
          const j = nb[q];
          if (j < 0 || comp[j] < 0) continue;
          const r = find(comp[j]);
          if (r !== target) shared.set(r, (shared.get(r) || 0) + 1);
        }
      }
      if (!shared.size) {
        isolated[target] = 1; // an isolated speck: it stays its own fragment
        changed = true;
        continue;
      }
      let best = -1, bestN = -1;
      shared.forEach((n, r) => {
        if (n > bestN || (n === bestN && r < best)) { bestN = n; best = r; }
      });
      parent[target] = best;
      compArea[best] += compArea[target];
      changed = true;
    }
    // number the survivors
    const finalOf = new Int32Array(C).fill(-1);
    const labels = new Int16Array(N).fill(-1);
    let count = 0;
    for (let i = 0; i < N; i++) {
      if (comp[i] < 0) continue;
      const r = find(comp[i]);
      if (finalOf[r] < 0) finalOf[r] = count++;
      labels[i] = finalOf[r];
    }
    // the stub (foliage): the largest final fragment built from the stub's raw label
    let stub = -1;
    if (stubRaw !== undefined) {
      let bestA = -1;
      for (let k = 0; k < C; k++) {
        if (find(k) !== k || compRaw[k] !== stubRaw) continue;
        if (compArea[k] > bestA) { bestA = compArea[k]; stub = finalOf[k]; }
      }
    }
    return { labels, count, stub };
  }

  /**
   * Bounds, area and centroid of every fragment.
   * @param {Int16Array} labels
   * @param {number} count
   * @param {number} w
   * @returns {Array<{area:number,minX:number,minY:number,maxX:number,maxY:number,cx:number,cy:number}>}
   */
  function pieces(labels, count, w) {
    const out = [];
    for (let k = 0; k < count; k++) out.push({ area: 0, minX: Infinity, minY: Infinity, maxX: -1, maxY: -1, cx: 0, cy: 0 });
    for (let i = 0; i < labels.length; i++) {
      const L = labels[i];
      if (L < 0) continue;
      const p = out[L], x = i % w, y = (i / w) | 0;
      p.area++;
      p.cx += x + 0.5;
      p.cy += y + 0.5;
      if (x < p.minX) p.minX = x;
      if (x > p.maxX) p.maxX = x;
      if (y < p.minY) p.minY = y;
      if (y > p.maxY) p.maxY = y;
    }
    for (const p of out) {
      p.cx /= p.area;
      p.cy /= p.area;
    }
    return out;
  }

  /**
   * Break a graphic. Every opaque pixel of `mask` lands in exactly one fragment.
   * @param {Uint8Array} mask  one byte per pixel, non-zero = opaque
   * @param {number} w
   * @param {number} h
   * @param {string} material  one of MATERIALS (anything else breaks as 'generic')
   * @param {number} seed      a break seed (graphic key + event id + break index, hashed)
   * @param {{impact?:{x:number,y:number}, grain?:'v'|'h'}} [opts]
   * @returns {{material:string, labels:Int16Array, count:number, pieces:Array, stub:number, impact:{x:number,y:number}, curl?:number, grain?:string}}
   */
  function fracture(mask, w, h, material, seed, opts) {
    const k = Math.floor(Number(opts && opts.scale)) || 1;
    if (k > 1 && w % k === 0 && h % k === 0) return fractureScaled(mask, w, h, material, seed, opts, k);
    const mat = normalizeMaterial(material);
    const info = maskInfo(mask, w, h);
    const imp = impactOf(info, opts || {});
    if (!info.area) {
      return { material: mat, labels: new Int16Array(w * h).fill(-1), count: 0, pieces: [], stub: -1, impact: imp };
    }
    const rng = new Rng(((Number(seed) >>> 0) ^ hash(mat)) >>> 0);
    const ctx = { mask, w, h, info, imp, rng, opts: opts || {}, rmax: radiusFrom(mask, w, h, imp.x, imp.y) };
    const gen = GEN[mat](ctx);
    const raw = new Int32Array(w * h).fill(-1);
    for (let y = info.minY; y <= info.maxY; y++) {
      for (let x = info.minX; x <= info.maxX; x++) {
        const i = y * w + x;
        if (mask[i]) raw[i] = gen.at(x, y);
      }
    }
    const fin = finalize(raw, w, h, gen.stubRaw);
    const out = { material: mat, labels: fin.labels, count: fin.count, pieces: pieces(fin.labels, fin.count, w), stub: fin.stub, impact: imp };
    if (gen.curl !== undefined) out.curl = gen.curl;
    if (gen.grain !== undefined) out.grain = gen.grain;
    return out;
  }

  // Upscaled pixel art (a 16 px tile drawn 3x in a 48 px project) breaks along ITS OWN pixel grid: fracture at the
  // native size, then every label covers a whole k x k art pixel. Cutting through an art pixel leaves 1-2 px slivers
  // that read as mush beside the art they came from.
  function fractureScaled(mask, w, h, material, seed, opts, k) {
    const nw = w / k, nh = h / k;
    const small = new Uint8Array(nw * nh);
    for (let y = 0; y < nh; y++) for (let x = 0; x < nw; x++) small[y * nw + x] = mask[y * k * w + x * k] ? 1 : 0;
    const o = {};
    const src = opts || {};
    for (const key in src) if (key !== 'scale') o[key] = src[key];
    if (src.impact) o.impact = { x: Number(src.impact.x) / k, y: Number(src.impact.y) / k };
    const r = fracture(small, nw, nh, material, seed, o);
    const labels = new Int16Array(w * h).fill(-1);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (mask[y * w + x]) labels[y * w + x] = r.labels[((y / k) | 0) * nw + ((x / k) | 0)];
    // a full-resolution pixel whose block's top-left was transparent has no native label: give it its nearest labelled
    // neighbour in the block so conservation holds (every opaque pixel in exactly one fragment)
    for (let i = 0; i < labels.length; i++) {
      if (!mask[i] || labels[i] >= 0) continue;
      const x = i % w, y = (i / w) | 0, bx = x - (x % k), by = y - (y % k);
      for (let yy = by; yy < by + k && labels[i] < 0; yy++) for (let xx = bx; xx < bx + k; xx++) if (labels[yy * w + xx] >= 0) { labels[i] = labels[yy * w + xx]; break; }
    }
    let count = r.count;
    for (let i = 0; i < labels.length; i++) if (mask[i] && labels[i] < 0) labels[i] = count++ ; // isolated specks stay their own
    const out = { material: r.material, labels, count, pieces: pieces(labels, count, w), stub: r.stub, impact: { x: r.impact.x * k, y: r.impact.y * k }, scale: k };
    if (r.curl !== undefined) out.curl = r.curl;
    if (r.grain !== undefined) out.grain = r.grain;
    return out;
  }

  /**
   * The upscale factor of a picture: k when every k x k block is one colour (k = 4, 3 or 2 tried), else 1.
   * @param {Uint8ClampedArray|Uint8Array} rgba
   * @param {number} w
   * @param {number} h
   * @returns {number}
   */
  function detectScale(rgba, w, h) {
    let opaque = 0;
    for (let i = 3; i < rgba.length; i += 4) if (rgba[i]) { opaque++; break; }
    if (!opaque) return 1;
    for (const k of [4, 3, 2]) {
      if (w % k || h % k) continue;
      let same = true;
      for (let y = 0; y < h && same; y++) {
        const by = y - (y % k);
        for (let x = 0; x < w; x++) {
          const a = (y * w + x) * 4, b = (by * w + (x - (x % k))) * 4;
          if (rgba[a] !== rgba[b] || rgba[a + 1] !== rgba[b + 1] || rgba[a + 2] !== rgba[b + 2] || rgba[a + 3] !== rgba[b + 3]) {
            same = false;
            break;
          }
        }
      }
      if (same) return k;
    }
    return 1;
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Fragment physics
  //
  // A fragment lives on the GROUND PLANE at (x, y) with a height h above it; it is drawn at (x, y - h). A burst
  // starts every piece exactly where it sat in the object (h = distance above the object's base row), so frame 0 of
  // a break looks like the unbroken object. Per-material motion (a behaviour, not a colour):
  //   speed/lift  launch   gravity  pull per frame   term  fastest fall   bounce  vh kept on landing
  //   friction    ground slide kept per frame        drag  air drag (foliage flutters)   spin  quarter turns/frame
  // Rotation is reported in QUARTER TURNS only: pixel art is never rotated by a fraction (Gate 1).
  // ---------------------------------------------------------------------------------------------------------------
  const MOTION = {
    //          speed        lift        grav   term  bounce frict  drag  spin  sway
    ceramic: [1.1, 2.3, 1.2, 2.4, 0.32, 6.0, 0.35, 0.86, 1.0, 0.14, 0.0],
    wood: [1.0, 2.2, 1.4, 2.6, 0.3, 6.0, 0.25, 0.82, 1.0, 0.18, 0.0],
    stone: [1.1, 2.2, 0.8, 1.6, 0.4, 7.0, 0.0, 0.74, 1.0, 0.06, 0.0],
    crystal: [1.3, 2.5, 1.2, 2.2, 0.3, 6.0, 0.3, 0.88, 1.0, 0.16, 0.0],
    ice: [0.8, 1.6, 0.6, 1.2, 0.34, 6.0, 0.15, 0.96, 1.0, 0.03, 0.0],
    foliage: [1.0, 2.1, 1.6, 2.8, 0.08, 0.7, 0.0, 0.9, 0.94, 0.1, 1.6],
    generic: [1.0, 2.0, 1.0, 2.0, 0.32, 6.0, 0.2, 0.84, 1.0, 0.12, 0.0],
  };
  const NM = MATERIALS.length;
  const M_GRAV = new Float32Array(NM), M_TERM = new Float32Array(NM), M_BOUNCE = new Float32Array(NM);
  const M_FRICT = new Float32Array(NM), M_DRAG = new Float32Array(NM), M_SWAY = new Float32Array(NM);
  MATERIALS.forEach((m, i) => {
    const t = MOTION[m];
    M_GRAV[i] = t[4];
    M_TERM[i] = t[5];
    M_BOUNCE[i] = t[6];
    M_FRICT[i] = t[7];
    M_DRAG[i] = t[8];
    M_SWAY[i] = t[10];
  });
  const REST = 0.04; // below this ground speed a fragment settles
  const SCATTER = 0.7; // share of a piece's ground velocity that scatters it around the object
  const DRIVE = 0.65; // share that carries it away from the striker (vx > 0 unless |gx| > 0.93 against the blow)
  const DEPTH = 0.9; // depth runs slightly shorter than across on MZ's square-tile ground
  const BOUNCE_MIN = 0.8; // a landing slower than this does not bounce

  /**
   * A fixed-capacity fragment pool; every field is a typed array so the per-frame step allocates nothing.
   * @param {number} capacity
   * @returns {object} the pool (debrisFrames: 0 = debris stays until clear(); fadeFrames: length of the fade)
   */
  function createPool(capacity) {
    const cap = clamp(Math.floor(Number(capacity)) || 192, 1, 4096);
    return {
      capacity: cap,
      live: 0,
      seq: 1,
      debrisFrames: 1200,
      fadeFrames: 45,
      alive: new Uint8Array(cap),
      settled: new Uint8Array(cap),
      mat: new Uint8Array(cap),
      piece: new Int16Array(cap),
      serial: new Uint32Array(cap),
      x: new Float32Array(cap),
      y: new Float32Array(cap),
      h: new Float32Array(cap),
      vx: new Float32Array(cap),
      vy: new Float32Array(cap),
      vh: new Float32Array(cap),
      rot: new Float32Array(cap),
      spin: new Float32Array(cap),
      phase: new Float32Array(cap),
      age: new Float32Array(cap),
      settleAge: new Float32Array(cap),
      tag: new Int32Array(cap), // the binding's break id, so it can find a fragment's texture
    };
  }

  // A free slot, else the OLDEST SETTLED fragment (recycled), else -1. A fragment in flight is never taken.
  function takeSlot(pool) {
    if (pool.live < pool.capacity) {
      for (let i = 0; i < pool.capacity; i++) {
        if (!pool.alive[i]) {
          pool.live++;
          return i;
        }
      }
    }
    let best = -1, bestSerial = 0xffffffff;
    for (let i = 0; i < pool.capacity; i++) {
      if (pool.alive[i] && pool.settled[i] && pool.serial[i] < bestSerial) {
        bestSerial = pool.serial[i];
        best = i;
      }
    }
    return best;
  }

  /**
   * Launch every piece of a fracture result into the pool.
   * @param {object} pool      from createPool
   * @param {object} res       from fracture
   * @param {string} material
   * @param {number} seed
   * @param {{originX:number, originY:number, dirX?:number, dirY?:number, tag?:number}} opts
   *        origin = where the graphic's top-left sits on screen; dir = the strike direction (away from the striker)
   * @returns {number} fragments spawned (fewer than res.count only when the pool is full of pieces in flight)
   */
  function burst(pool, res, material, seed, opts) {
    const mat = normalizeMaterial(material);
    const mi = MATERIALS.indexOf(mat);
    const M = MOTION[mat];
    const o = opts || {};
    let ox = Number(o.originX), oy = Number(o.originY);
    if (!isFinite(ox)) ox = 0;
    if (!isFinite(oy)) oy = 0;
    let dx = Number(o.dirX), dy = Number(o.dirY);
    if (!isFinite(dx)) dx = 0;
    if (!isFinite(dy)) dy = 0;
    const dl = Math.sqrt(dx * dx + dy * dy);
    if (dl > 0) {
      dx /= dl;
      dy /= dl;
    }
    const tag = Math.floor(Number(o.tag)) || 0;
    // power scales launch speed and lift (a chip knocked off a node flies at ~0.55); NaN/absent is a full break
    const pw = Number(o.power);
    const power = isFinite(pw) && pw > 0 ? clamp(pw, 0.1, 2) : 1;
    const rng = new Rng(((Math.imul(Number(seed) >>> 0, 2654435761) >>> 0) ^ hash('burst:' + mat)) >>> 0);
    let baseY = 0, sumA = 0, sumX = 0, minX = Infinity, maxX = -1;
    for (let k = 0; k < res.count; k++) {
      const p = res.pieces[k];
      if (p.maxY + 1 > baseY) baseY = p.maxY + 1;
      sumA += p.area;
      sumX += p.cx * p.area;
      if (p.minX < minX) minX = p.minX;
      if (p.maxX > maxX) maxX = p.maxX;
    }
    const midX = sumA ? sumX / sumA : 0;
    const halfW = Math.max(1, (maxX - minX + 1) / 2);
    let n = 0;
    for (let k = 0; k < res.count; k++) {
      const p = res.pieces[k];
      const i = takeSlot(pool);
      if (i < 0) break;
      n++;
      pool.alive[i] = 1;
      pool.mat[i] = mi;
      pool.piece[i] = k;
      pool.tag[i] = tag;
      pool.serial[i] = pool.seq++;
      pool.age[i] = 0;
      pool.settleAge[i] = 0;
      pool.rot[i] = 0;
      pool.phase[i] = rng.next() * TAU;
      pool.x[i] = ox + p.cx;
      if (k === res.stub) {
        // the foliage stub stays rooted where it grew
        pool.y[i] = oy + p.cy;
        pool.h[i] = 0;
        pool.vx[i] = pool.vy[i] = pool.vh[i] = pool.spin[i] = 0;
        pool.settled[i] = 1;
        continue;
      }
      pool.y[i] = oy + baseY;
      pool.h[i] = Math.max(0, baseY - p.cy);
      // The scatter direction lives on the GROUND PLANE, not the picture plane. A piece's height in the picture is
      // its height above the ground (h), so it says nothing about depth: across comes from where the piece sat
      // (left pieces go left), depth is seeded per piece. The first engine run used the picture's vertical offset
      // as depth and every heap settled on ONE ground line (S3, depth IQR 0.19-0.45 of lateral, spread_probe.js).
      let gx = (p.cx - midX) / halfW;
      gx = gx < -1 ? -1 : gx > 1 ? 1 : gx;
      let gy = rng.range(-1, 1);
      const gl = Math.sqrt(gx * gx + gy * gy);
      if (gl > 0.05) {
        gx /= gl;
        gy /= gl;
      } else {
        const a = rng.next() * TAU;
        gx = Math.cos(a);
        gy = Math.sin(a);
      }
      // (R3, 2026-09-19: a fresh-install frame LOOKED like a ring of chunks; _probe/ring_probe.js measured the heap as
      // a filled disc - 30-40% inside half the p90 radius - with or without a sqrt(u) speed, so no change was kept)
      const speed = rng.range(M[0], M[1]) * power;
      pool.vx[i] = speed * (SCATTER * gx + DRIVE * dx);
      pool.vy[i] = speed * DEPTH * (SCATTER * gy + DRIVE * dy);
      pool.vh[i] = rng.range(M[2], M[3]) * power;
      pool.spin[i] = M[9] * rng.range(0.5, 1.5) * (rng.next() < 0.5 ? -1 : 1);
      pool.settled[i] = 0;
    }
    return n;
  }

  /**
   * Advance every fragment one frame. Zero allocation: typed arrays and numbers only (pinned by a static scan).
   * @param {object} pool
   */
  function step(pool) {
    const cap = pool.capacity;
    for (let i = 0; i < cap; i++) {
      if (!pool.alive[i]) continue;
      pool.age[i] += 1;
      if (pool.settled[i]) {
        if (pool.debrisFrames > 0 && pool.age[i] - pool.settleAge[i] >= pool.debrisFrames + pool.fadeFrames) {
          pool.alive[i] = 0;
          pool.settled[i] = 0;
          pool.live--;
        }
        continue;
      }
      const mi = pool.mat[i];
      const airborne = pool.h[i] > 0;
      pool.vh[i] -= M_GRAV[mi];
      if (pool.vh[i] < -M_TERM[mi]) pool.vh[i] = -M_TERM[mi];
      if (airborne) {
        pool.vx[i] *= M_DRAG[mi];
        pool.vy[i] *= M_DRAG[mi];
        pool.rot[i] += pool.spin[i];
      }
      pool.h[i] += pool.vh[i];
      pool.x[i] += pool.vx[i];
      pool.y[i] += pool.vy[i];
      if (pool.h[i] <= 0) {
        pool.h[i] = 0;
        if (airborne && pool.vh[i] < -BOUNCE_MIN && M_BOUNCE[mi] > 0) {
          pool.vh[i] = -pool.vh[i] * M_BOUNCE[mi];
        } else {
          pool.vh[i] = 0;
        }
        pool.vx[i] *= M_FRICT[mi];
        pool.vy[i] *= M_FRICT[mi];
        if (pool.vh[i] === 0 && Math.abs(pool.vx[i]) + Math.abs(pool.vy[i]) < REST) {
          pool.vx[i] = 0;
          pool.vy[i] = 0;
          pool.rot[i] = Math.round(pool.rot[i]);
          pool.settled[i] = 1;
          pool.settleAge[i] = pool.age[i];
        }
      }
    }
  }

  /** @returns {number} the fragment's rotation in quarter turns, 0..3 */
  function quarter(pool, i) {
    return ((Math.round(pool.rot[i]) % 4) + 4) % 4;
  }

  /** @returns {number} opacity 0..1 (1 in flight and while debris lies, then the fade) */
  function alpha(pool, i) {
    if (!pool.alive[i]) return 0;
    if (!pool.settled[i] || pool.debrisFrames <= 0) return 1;
    const t = pool.age[i] - pool.settleAge[i] - pool.debrisFrames;
    if (t <= 0) return 1;
    return clamp(1 - t / Math.max(1, pool.fadeFrames), 0, 1);
  }

  /** @returns {number} a draw-only sideways sway in pixels (foliage clippings flutter; 0 once settled) */
  function sway(pool, i) {
    if (pool.settled[i]) return 0;
    const s = M_SWAY[pool.mat[i]];
    return s ? Math.sin(pool.age[i] * 0.15 + pool.phase[i]) * s * Math.min(1, pool.h[i] / 4) : 0;
  }

  /** Remove every fragment. */
  function clear(pool) {
    pool.alive.fill(0);
    pool.settled.fill(0);
    pool.live = 0;
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Gathering nodes: a note tag like <smash: stone hits:3 regrow:180> makes an object take visible damage per strike
  // (a crack network that grows from the struck side, a chip knocked off) and break on the last one; regrow brings it
  // back after that many seconds of play time.
  // ---------------------------------------------------------------------------------------------------------------
  const MAX_HITS = 12;

  function posInt(v, lo, hi, d) {
    if (v === undefined || v === null || String(v).trim() === '') return d; // blank is ABSENT (wing §16)
    const n = Math.floor(Number(v));
    return isFinite(n) && n >= lo ? Math.min(hi, n) : d;
  }

  /**
   * Parse the value of a <smash> note tag.
   * @param {string|boolean|undefined} text  e.g. true (bare <smash>), "ceramic", "stone hits:3 regrow:180"
   * @returns {{material:(string|null), hits:number, regrow:number}} material null = resolve it another way
   */
  function parseSpec(text) {
    const out = { material: null, hits: 1, regrow: 0 };
    if (typeof text !== 'string') return out;
    const toks = text.trim().toLowerCase().split(/\s+/);
    for (let k = 0; k < toks.length; k++) {
      const t = toks[k];
      if (!t) continue;
      const c = t.indexOf(':');
      if (c < 0) {
        if (out.material === null && MATERIALS.indexOf(t) >= 0) out.material = t;
        continue;
      }
      const key = t.slice(0, c), val = t.slice(c + 1);
      if (key === 'hits') out.hits = posInt(val, 1, MAX_HITS, 1);
      else if (key === 'regrow') out.regrow = posInt(val, 1, 86400, 0);
    }
    return out;
  }

  function nearestOpaque(mask, w, h, px, py) {
    let best = -1, bd = Infinity;
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        if (!mask[y * w + x]) continue;
        const dx = x + 0.5 - px, dy = y + 0.5 - py;
        const d = dx * dx + dy * dy;
        if (d < bd) {
          bd = d;
          best = y * w + x;
        }
      }
    }
    return best;
  }

  /**
   * The crack network of a struck object, grown one stage per strike. Stage k's pixels are drawn after the k-th
   * strike; every stage adds crack, never removes it, and cracks only ever lie on opaque pixels.
   * @param {Uint8Array} mask
   * @param {number} w
   * @param {number} h
   * @param {number} seed   per object (map + event), so the same node always cracks the same way
   * @param {{stages:number, impact?:{x:number,y:number}}} opts  stages = strikes before the break
   * @returns {{stageOf:Uint8Array, stages:number}} stageOf[i] = 0 (no crack) or the strike that cracked pixel i
   */
  function crackMap(mask, w, h, seed, opts) {
    const o = opts || {};
    const S = clamp(Math.floor(Number(o.stages)) || 1, 1, MAX_HITS);
    const stageOf = new Uint8Array(w * h);
    const info = maskInfo(mask, w, h);
    if (!info.area) return { stageOf, stages: S };
    const imp = impactOf(info, o);
    const start = nearestOpaque(mask, w, h, imp.x, imp.y);
    const sx = (start % w) + 0.5, sy = Math.floor(start / w) + 0.5;
    const rng = new Rng(((Number(seed) >>> 0) ^ hash('crack')) >>> 0);
    const reach = radiusFrom(mask, w, h, sx, sy);
    const inward = Math.atan2(info.cy - sy, info.cx - sx);
    // Each stage walks every live tip a share of the object's reach, so the last pre-break stage spans ~0.75 of it.
    const len = Math.max(3, (reach * 0.75) / S);
    let tips = [{ x: sx, y: sy, a: inward + rng.range(-0.3, 0.3) }];
    for (let k = 1; k <= S; k++) {
      const next = [];
      if (k > 1) next.push({ x: sx, y: sy, a: inward + rng.range(-1.1, 1.1) }); // a fresh crack from the struck point
      for (let t = 0; t < tips.length; t++) {
        next.push(tips[t]);
        if (rng.next() < 0.55) next.push({ x: tips[t].x, y: tips[t].y, a: tips[t].a + rng.range(0.45, 0.95) * (rng.next() < 0.5 ? -1 : 1) });
      }
      tips = [];
      let added = 0;
      for (let t = 0; t < next.length; t++) {
        const tip = next[t];
        let alive = true;
        const L = len * rng.range(0.8, 1.25);
        for (let s = 0; s < L; s++) {
          tip.a += rng.range(-0.3, 0.3);
          const nx = tip.x + Math.cos(tip.a), ny = tip.y + Math.sin(tip.a);
          const px = Math.floor(nx), py = Math.floor(ny);
          if (px < 0 || py < 0 || px >= w || py >= h || !mask[py * w + px]) {
            alive = false;
            break;
          }
          tip.x = nx;
          tip.y = ny;
          if (!stageOf[py * w + px]) {
            stageOf[py * w + px] = k;
            added++;
          }
        }
        if (alive) tips.push(tip);
      }
      if (k === 1 && !stageOf[start]) {
        stageOf[start] = 1; // the struck point itself always shows the blow
        added++;
      }
      if (!added) {
        // every tip ran off the edge: mark one more pixel along the rim so every strike still shows
        for (let i = 0; i < stageOf.length; i++) {
          if (mask[i] && !stageOf[i]) {
            stageOf[i] = k;
            break;
          }
        }
      }
      if (!tips.length) tips.push({ x: sx, y: sy, a: inward + rng.range(-1.2, 1.2) });
    }
    return { stageOf, stages: S };
  }

  /**
   * The chip a strike knocks off: the opaque pixels within `radius` of the impact.
   * @returns {Uint8Array} a mask the size of the source
   */
  function chipMask(mask, w, h, impact, radius) {
    const out = new Uint8Array(w * h);
    const info = maskInfo(mask, w, h);
    if (!info.area) return out;
    const imp = impactOf(info, { impact });
    const start = nearestOpaque(mask, w, h, imp.x, imp.y);
    const cx = (start % w) + 0.5, cy = Math.floor(start / w) + 0.5;
    const r = clamp(Number(radius) || 4, 2, 12);
    for (let y = Math.max(0, Math.floor(cy - r)); y <= Math.min(h - 1, Math.ceil(cy + r)); y++) {
      for (let x = Math.max(0, Math.floor(cx - r)); x <= Math.min(w - 1, Math.ceil(cx + r)); x++) {
        const i = y * w + x;
        if (mask[i] && Math.hypot(x + 0.5 - cx, y + 0.5 - cy) <= r) out[i] = 1;
      }
    }
    return out;
  }

  const STORE_VERSION = 1;
  /**
   * The saved regrowth store: { v: 1, nodes: { "<mapId>:<eventId>": <play-time second it broke> } }.
   * Anything unreadable, or a version this build does not know, becomes a fresh store; never throws.
   * @param {*} s
   * @returns {{v:number, nodes:Object<string,number>}}
   */
  function normalizeStore(s) {
    const out = { v: STORE_VERSION, nodes: {} };
    if (!s || typeof s !== 'object' || s.v !== STORE_VERSION || !s.nodes || typeof s.nodes !== 'object') return out;
    const keys = Object.keys(s.nodes);
    for (let k = 0; k < keys.length; k++) {
      if (!/^\d+:\d+$/.test(keys[k])) continue;
      const n = Number(s.nodes[keys[k]]);
      if (isFinite(n) && n >= 0) out.nodes[keys[k]] = n;
    }
    return out;
  }

  CSAF.SmithereensCore = {
    VERSION: '1.0.0',
    MATERIALS,
    MIN_FRAGMENT,
    hash,
    Rng,
    maskInfo,
    normalizeMaterial,
    fracture,
    detectScale,
    pieces,
    createPool,
    burst,
    step,
    quarter,
    alpha,
    sway,
    clear,
    MAX_HITS,
    parseSpec,
    crackMap,
    chipMask,
    normalizeStore,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.SmithereensCore;
})(typeof globalThis !== 'undefined' ? globalThis : this);
