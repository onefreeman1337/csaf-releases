/*:
 * @target MZ
 * @plugindesc [CSAF] Timber core: finds the trees in your tileset and plans how each one falls. Install with Timber.js.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io/timber
 * @help TimberCore.js
 *
 * The engine-free half of Timber. It finds the trees painted on a map from
 * the map data and the tileset's own flags, reads a tree's picture once to
 * learn where its trunk stands and what colours its bark and crown are, and
 * plans the chop, the fall, the logs, the stump and the regrowth. It has no
 * parameters and no commands of its own. Install it beside Timber.js,
 * SmithereensCore.js and SmithereensCut.js; the order of the four files in
 * the Plugin Manager does not matter.
 *
 * Copyright (c) Core Systems Asset Factory. See LICENSE.txt.
 */

/**
 * How a tree is found
 * -------------------
 * MZ paints a tree as tiles from the B to E sheets on the two upper map layers
 * (z = 2 and 3): a crown drawn over characters (the star flag) above a trunk
 * that blocks. A tree can be several tiles wide and tall, and a forest puts the
 * same tree beside itself many times. Timber groups tiles into one tree by
 * SHEET ADJACENCY: two map cells side by side belong together when the right
 * one shows the tile one column to the right on the same sheet row, and two
 * cells one above the other when the lower one shows the tile one row down.
 * That is exactly how a multi-tile tree is painted from the palette, and it
 * keeps a forest row of identical trees apart (they repeat one tile id; they
 * are never one column apart on the sheet).
 *
 * A tile is a tree part when it is one of MZ's own stock tree tiles (by the
 * sheet's file name and tile index), when its terrain tag is the one you
 * chose, or when its cell carries the region you chose.
 */
(function (root) {
  'use strict';
  const CSAF = (root.CSAF = root.CSAF || {});
  if (CSAF.TimberCore) return;

  const KINDS = ['broadleaf', 'conifer', 'palm', 'dead', 'mushroom', 'crystal'];
  /** Chops to fell each kind when nothing overrides it. */
  const HITS = { broadleaf: 3, conifer: 4, palm: 2, dead: 2, mushroom: 1, crystal: 3 };
  const MASK_ALPHA = 160; // the falling picture keeps pixels at or above this alpha; the soft rest stays as a fading ground shadow
  const MAX_CELLS = 25;   // a "tree" bigger than 5 x 5 cells is a painted forest mass, not one tree

  /**
   * MZ's own stock tree tiles, by sheet file name and tile index (0-255 on that sheet). DERIVED from the engine's
   * own tile names (img/tilesets/<sheet>.txt) and then LOOKED AT cell by cell on the sheet
   * (Internal_Ops/_probe/stock_flags.js + the grid crops in _probe/out): forest-mass fills that carry the name
   * "Tree" (Outside_B 158, 178/179/186/187, 194/195/202/203, 222; SF_Outside_B 157 "Tree (Loop)") are NOT
   * trees and are left out, as is a palm crown with no trunk (237) and a roadside tree in a planter box that
   * would fall with its planter (SF 142/150). Indices only: no art ships with this plugin.
   */
  const STOCK = {
    Outside_B: {
      157: 'broadleaf', 165: 'broadleaf',
      176: 'broadleaf', 177: 'broadleaf', 184: 'broadleaf', 185: 'broadleaf',
      192: 'conifer', 193: 'conifer', 200: 'conifer', 201: 'conifer',
      221: 'conifer', 229: 'conifer',
      232: 'dead', 240: 'dead', 233: 'dead', 241: 'dead',
      236: 'palm', 244: 'palm',
      234: 'mushroom', 235: 'mushroom',
    },
    SF_Outside_B: { 141: 'conifer', 149: 'conifer' },
  };

  // ── small helpers ────────────────────────────────────────────────────────────────────────────────

  /** 32-bit FNV-1a. @param {string} s @returns {number} */
  function hash(s) {
    let h = 2166136261 >>> 0;
    const t = String(s);
    for (let i = 0; i < t.length; i++) { h ^= t.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    return h >>> 0;
  }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function normalizeKind(k) {
    const s = String(k == null ? '' : k).trim().toLowerCase();
    return KINDS.indexOf(s) >= 0 ? s : null;
  }

  /**
   * Where a B-E tile sits on its sheet: the same arithmetic as Tilemap.prototype._addNormalTile (rmmz_core.js:2483).
   * @param {number} tileId 1..1023
   * @returns {{set:number, index:number, col:number, row:number}} set 0..3 = B..E
   */
  function sheetPos(tileId) {
    const id = tileId | 0;
    return { set: Math.floor(id / 256), index: id % 256, col: (Math.floor(id / 128) % 2) * 8 + (id % 8), row: Math.floor((id % 256) / 8) % 16 };
  }
  /** @returns {boolean} a B-E tile (MZ: 0 is "no tile", 1024..1535 unused, A5 from 1536) */
  function isUpperTile(id) { return id > 0 && id < 1024; }
  function isStar(flag) { return (flag & 0x10) !== 0; }
  function isBlocking(flag) { return (flag & 0x0f) === 0x0f; }

  /**
   * Parse a tileset note: <Timber Tag 5> marks terrain tag 5 as trees (kind read from the picture);
   * <Timber Tag 6: conifer> marks terrain tag 6 as conifers. Several tags may be given.
   * @param {string} note
   * @returns {Object<number,string>} tag -> kind ('' = read from the picture)
   */
  function parseTilesetNote(note) {
    const out = {};
    const re = /<\s*timber\s+tag\s*(\d+)\s*(?::\s*([a-z]+)\s*)?>/gi;
    const s = String(note || '');
    let m;
    while ((m = re.exec(s))) {
      const tag = Number(m[1]);
      if (!(tag >= 1 && tag <= 7)) continue;
      out[tag] = m[2] ? normalizeKind(m[2]) || '' : '';
    }
    return out;
  }

  /**
   * Parse a map note: <Timber Off> disables Timber on the map; <Timber Regrow: 600> sets this map's regrow seconds.
   * @param {string} note
   * @returns {{off:boolean, regrow:number|null}}
   */
  function parseMapNote(note) {
    const s = String(note || '');
    const off = /<\s*timber\s+off\s*>/i.test(s);
    const m = s.match(/<\s*timber\s+regrow\s*:\s*(\d+)\s*>/i);
    return { off, regrow: m ? Number(m[1]) : null };
  }

  // ── finding trees ────────────────────────────────────────────────────────────────────────────────

  /**
   * Find every tree on a map.
   * @param {{width:number,height:number,data:ArrayLike<number>,flags:ArrayLike<number>,sheetNames:string[],
   *          treeTag?:number, tagKinds?:Object<number,string>, treeRegion?:number, stock?:boolean}} m
   *        sheetNames = the tileset's B, C, D, E image names (tilesetNames[5..8])
   * @returns {{trees:Array<object>, cellTree:Int32Array}} cellTree[y*w+x] = tree index + 1 for every cell a tree
   *          occupies (0 = none)
   */
  function findTrees(m) {
    const W = m.width | 0, H = m.height | 0, data = m.data, flags = m.flags || [];
    const names = m.sheetNames || [];
    const useStock = m.stock !== false;
    const treeTag = Number(m.treeTag) || 0;
    const tagKinds = m.tagKinds || {};
    const region = Number(m.treeRegion) || 0;
    const N = W * H;
    // node id = z2 ? cell : N + cell  (two upper layers)
    const part = new Int8Array(2 * N); // 0 no, 1 tree part
    const kindOf = new Array(2 * N);
    const tileAt = (x, y, z) => data[(z * H + y) * W + x] || 0;
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const reg = region > 0 ? tileAt(x, y, 5) : 0;
        for (let L = 0; L < 2; L++) {
          const t = tileAt(x, y, 2 + L);
          if (!isUpperTile(t)) continue;
          const sp = sheetPos(t);
          const sheet = names[sp.set] || '';
          let k = null, isPart = false;
          const st = useStock && STOCK[sheet] ? STOCK[sheet][sp.index] : undefined;
          if (st) { isPart = true; k = st; }
          const tag = ((flags[t] | 0) >> 12) & 0x0f;
          if (!isPart && tag > 0 && (tag === treeTag || Object.prototype.hasOwnProperty.call(tagKinds, tag))) {
            isPart = true;
            k = Object.prototype.hasOwnProperty.call(tagKinds, tag) ? tagKinds[tag] || null : null;
          }
          if (!isPart && region > 0 && reg === region) isPart = true;
          if (!isPart) continue;
          const id = L * N + y * W + x;
          part[id] = 1;
          kindOf[id] = k;
        }
      }
    }
    // union-find over part nodes by sheet adjacency (either layer to either layer)
    const parent = new Int32Array(2 * N);
    for (let i = 0; i < parent.length; i++) parent[i] = i;
    const find = (a) => { while (parent[a] !== a) { parent[a] = parent[parent[a]]; a = parent[a]; } return a; };
    const unite = (a, b) => { const ra = find(a), rb = find(b); if (ra !== rb) parent[Math.max(ra, rb)] = Math.min(ra, rb); };
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        for (let L = 0; L < 2; L++) {
          const id = L * N + y * W + x;
          if (!part[id]) continue;
          const p = sheetPos(tileAt(x, y, 2 + L));
          for (let L2 = 0; L2 < 2; L2++) {
            if (x + 1 < W) {
              const j = L2 * N + y * W + x + 1;
              if (part[j]) { const q = sheetPos(tileAt(x + 1, y, 2 + L2)); if (q.set === p.set && q.row === p.row && q.col === p.col + 1) unite(id, j); }
            }
            if (y + 1 < H) {
              const j = L2 * N + (y + 1) * W + x;
              if (part[j]) { const q = sheetPos(tileAt(x, y + 1, 2 + L2)); if (q.set === p.set && q.col === p.col && q.row === p.row + 1) unite(id, j); }
            }
          }
        }
      }
    }
    const groups = new Map();
    for (let i = 0; i < part.length; i++) {
      if (!part[i]) continue;
      const r = find(i);
      if (!groups.has(r)) groups.set(r, []);
      groups.get(r).push(i);
    }
    const trees = [];
    const cellTree = new Int32Array(N);
    const roots = Array.from(groups.keys()).sort((a, b) => a - b);
    for (const r of roots) {
      const ids = groups.get(r);
      const nodes = [];
      let minX = Infinity, minY = Infinity, maxX = -1, maxY = -1;
      const kinds = {};
      for (const id of ids) {
        const L = id >= N ? 1 : 0, c = id - L * N, x = c % W, y = (c / W) | 0, t = tileAt(x, y, 2 + L);
        nodes.push({ x, y, z: 2 + L, t, star: isStar(flags[t] | 0), block: isBlocking(flags[t] | 0) });
        if (x < minX) minX = x; if (y < minY) minY = y; if (x > maxX) maxX = x; if (y > maxY) maxY = y;
        if (kindOf[id]) kinds[kindOf[id]] = (kinds[kindOf[id]] || 0) + 1;
      }
      const cols = maxX - minX + 1, rows = maxY - minY + 1;
      if (cols * rows > MAX_CELLS) continue;
      // a tree needs a trunk: a non-star tile in its bottom row
      const base = nodes.filter((n) => n.y === maxY && !n.star);
      if (!base.length) continue;
      base.sort((a, b) => a.x - b.x);
      nodes.sort((a, b) => a.y - b.y || a.x - b.x || a.z - b.z);
      let kind = null, best = 0;
      for (const k of KINDS) if ((kinds[k] || 0) > best) { best = kinds[k]; kind = k; }
      const sig = nodes.map((n) => (n.x - minX) + ',' + (n.y - minY) + ',' + n.z + ',' + n.t + (n.star ? '*' : '')).join(';');
      const tree = {
        index: trees.length,
        key: base[0].x + ',' + base[0].y,
        x: minX, y: minY, cols, rows,
        nodes,
        baseCells: base.map((n) => n.x).filter((v, i, a) => a.indexOf(v) === i).map((x) => ({ x, y: maxY })),
        blockCells: nodes.filter((n) => n.block && !n.star).map((n) => ({ x: n.x, y: n.y })),
        kind,
        sig,
      };
      trees.push(tree);
      for (const n of nodes) cellTree[n.y * W + n.x] = tree.index + 1;
    }
    return { trees, cellTree };
  }

  // ── reading a tree's picture (once, while the map settles) ───────────────────────────────────────

  function luma(r, g, b) { return 0.299 * r + 0.587 * g + 0.114 * b; }
  function hsv(r, g, b) {
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
    let h = 0;
    if (d > 0) {
      if (mx === r) h = ((g - b) / d) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4;
      h *= 60; if (h < 0) h += 360;
    }
    return { h, s: mx ? d / mx : 0, v: mx / 255 };
  }
  /** Median colour of a list of pixel offsets. */
  function medianColour(rgba, list) {
    if (!list.length) return [128, 96, 64];
    const ch = [[], [], []];
    for (const o of list) { ch[0].push(rgba[o]); ch[1].push(rgba[o + 1]); ch[2].push(rgba[o + 2]); }
    return ch.map((a) => { a.sort((p, q) => p - q); return a[a.length >> 1]; });
  }
  /** Colours at luma quantiles of a pixel set (the darkest, middle and lightest of the bark, say). */
  function palette(rgba, offs, qs) {
    if (!offs.length) return qs.map(() => [110, 84, 60]);
    const s = offs.slice().sort((a, b) => luma(rgba[a], rgba[a + 1], rgba[a + 2]) - luma(rgba[b], rgba[b + 1], rgba[b + 2]));
    return qs.map((q) => {
      const c = clamp(Math.round(q * (s.length - 1)), 0, s.length - 1);
      const lo = clamp(c - Math.max(1, s.length >> 4), 0, s.length - 1), hi = clamp(c + Math.max(1, s.length >> 4), 0, s.length - 1);
      return medianColour(rgba, s.slice(lo, hi + 1));
    });
  }

  /**
   * Read a composed tree picture.
   * @param {Uint8Array|Uint8ClampedArray} rgba  W x H, the tree's tiles drawn in map order
   * @param {number} W
   * @param {number} H
   * @param {{baseCx:number, tile:number, starRows?:number}} o  baseCx = the base cells' centre in pixels,
   *        tile = tile size, starRows = how many top rows of cells are crown (star) cells
   * @returns {object} the analysis: hinge, trunk span, palettes, masks, ground-backed flag, kind features
   */
  function analyse(rgba, W, H, o) {
    const opts = o || {};
    const T = opts.tile || 48;
    const mask = new Uint8Array(W * H);
    let area = 0, soft = 0, minX = W, minY = H, maxX = -1, maxY = -1;
    for (let i = 0; i < W * H; i++) {
      const a = rgba[i * 4 + 3];
      if (a >= MASK_ALPHA) { mask[i] = 1; area++; const x = i % W, y = (i / W) | 0; if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y; }
      else if (a > 0) soft++;
    }
    const out = { W, H, mask, area, soft, bbox: { minX, minY, maxX, maxY }, ok: area > 0 };
    if (!area) return out;
    out.groundBacked = area / (W * H) > 0.9;
    // the trunk: the opaque run nearest the base centre, measured over a band of rows above the lowest ink
    const baseCx = isFinite(opts.baseCx) ? opts.baseCx : W / 2;
    const runAt = (y, cx) => {
      // the opaque run on row y containing (or nearest to) cx
      let best = null, bestD = Infinity, x = 0;
      while (x < W) {
        if (!mask[y * W + x]) { x++; continue; }
        const s = x; while (x < W && mask[y * W + x]) x++;
        const e = x - 1, d = cx < s ? s - cx : cx > e ? cx - e : 0;
        if (d < bestD) { bestD = d; best = [s, e]; }
      }
      return best;
    };
    /*
     * LOOKED AT, 2026-10-23 (Internal_Ops/_probe/trunk_sheet.png): root tips reach LOWER than the trunk's foot, so
     * "the lowest ink nearest the base" put an oak's hinge on its far-left root and every stock tree's trunk on a
     * 4 px root point. The trunk is the run that CONTAINS the base centre: its foot is the lowest such row, it
     * rises until a row is crown-wide, and its width is read ABOVE the root flare (the upper part of what shows).
     */
    const med = (arr) => { const s = arr.slice().sort((p, q) => p - q); return s[s.length >> 1]; };
    const contains = (y, x) => { const r = runAt(y, x); return r && r[0] <= x + 2 && r[1] >= x - 2 ? r : null; };
    let crownW = 0;
    for (let y = minY; y <= maxY; y++) { let a = W, b = -1; for (let x = 0; x < W; x++) if (mask[y * W + x]) { if (x < a) a = x; b = x; } if (b >= a) crownW = Math.max(crownW, b - a + 1); }
    let baseY = maxY, foot = null;
    for (let y = maxY; y >= minY; y--) { const r = contains(y, baseCx); if (r) { baseY = y; foot = r; break; } }
    if (!foot) foot = runAt(baseY, baseCx) || [Math.floor(baseCx), Math.floor(baseCx)];
    let cx = (foot[0] + foot[1] + 1) / 2;
    const baseRows = [];
    for (let y = baseY; y > baseY - 4 && y >= minY; y--) { const r = contains(y, cx); if (r) baseRows.push(r[1] - r[0] + 1); }
    const limit = Math.max(0.6 * crownW, 1.6 * (baseRows.length ? med(baseRows) : foot[1] - foot[0] + 1));
    let trunkTop = baseY;
    const runs = [];
    for (let y = baseY; y >= minY; y--) {
      const r = contains(y, cx);
      if (!r || r[1] - r[0] + 1 > limit) break;
      trunkTop = y;
      runs.push(r);
    }
    // width above the flare: the upper 60% of the visible trunk (at least one row)
    const upper = runs.slice(Math.floor(runs.length * 0.4));
    const use = upper.length ? upper : runs.length ? runs : [foot];
    let x0 = med(use.map((r) => r[0])), x1 = med(use.map((r) => r[1]));
    // a crown that hangs to the ground hides the trunk: estimate it from the crown when fewer than 4 rows show
    const minW = runs.length < 4 ? Math.max(4, Math.round(crownW * 0.14)) : 3;
    if (x1 - x0 + 1 < minW) { const c = (x0 + x1 + 1) / 2; x0 = Math.round(c - minW / 2); x1 = x0 + minW - 1; }
    const trunkW = Math.max(2, x1 - x0 + 1);
    cx = (x0 + x1 + 1) / 2;
    out.hinge = { x: cx, y: baseY + 1 };
    out.trunk = { x0, x1, w: trunkW, top: trunkTop, bottom: baseY, visible: baseY - trunkTop + 1 };
    // palettes: bark from the visible trunk (or the base band when the crown hides the trunk), crown from the rest
    const bark = [], crown = [];
    const barkTop = Math.min(trunkTop, baseY - Math.max(2, Math.round(trunkW * 0.6)));
    for (let y = minY; y <= maxY; y++) {
      for (let x = minX; x <= maxX; x++) {
        const i = y * W + x;
        if (!mask[i]) continue;
        if (y >= barkTop && x >= x0 && x <= x1) bark.push(i * 4);
        else if (y < trunkTop) crown.push(i * 4);
      }
    }
    out.bark = palette(rgba, bark, [0.12, 0.5, 0.88]);
    out.crown = palette(rgba, crown.length ? crown : bark, [0.08, 0.3, 0.55, 0.8, 0.96]);
    // kind features over the crown (what grows on the tree, not the trunk); a tree that is all trunk (a snag, a
    // crystal spire, a mushroom cluster with no single stem) has no crown, so its colour is read over the whole
    let fol = 0, snow = 0, cool = 0, warm = 0, n = 0;
    let colourSet = crown;
    if (crown.length < area * 0.15) { colourSet = []; for (let i = 0; i < W * H; i++) if (mask[i]) colourSet.push(i * 4); }
    for (const off of colourSet) {
      const r = rgba[off], g = rgba[off + 1], b = rgba[off + 2];
      const c = hsv(r, g, b);
      n++;
      if (c.h >= 50 && c.h <= 170 && c.s >= 0.18 && c.v >= 0.12) fol++;
      if (Math.min(r, g, b) >= 190 && c.s < 0.16) snow++;
      if (c.h > 170 && c.h <= 300 && c.s >= 0.22 && c.v >= 0.4) cool++;
      if ((c.h >= 330 || c.h <= 30) && c.s >= 0.45 && c.v >= 0.4) warm++;
    }
    const share = (v) => (n ? v / n : 0);
    // the crown's taper: width a quarter of the way down the crown against its widest row
    let widest = 0, widestY = minY;
    const rowW = [];
    for (let y = minY; y < trunkTop; y++) {
      let a = W, b = -1;
      for (let x = 0; x < W; x++) if (mask[y * W + x]) { if (x < a) a = x; b = x; }
      const w = b >= a ? b - a + 1 : 0;
      rowW.push(w);
      if (w > widest) { widest = w; widestY = y; }
    }
    const crownH = Math.max(1, trunkTop - minY);
    const q1 = rowW[Math.min(rowW.length - 1, Math.round(crownH * 0.2))] || 0;
    // how much of the crown's own box it fills: fronds and bare branches are sparse, a leafy crown is solid
    let cx0 = W, cx1 = -1;
    for (let y = minY; y < trunkTop; y++) for (let x = 0; x < W; x++) if (mask[y * W + x]) { if (x < cx0) cx0 = x; if (x > cx1) cx1 = x; }
    let crownInk = 0;
    for (let y = minY; y < trunkTop; y++) for (let x = Math.max(0, cx0); x <= cx1; x++) if (mask[y * W + x]) crownInk++;
    const crownFill = cx1 >= cx0 ? crownInk / ((cx1 - cx0 + 1) * crownH) : 0;
    out.features = {
      foliage: share(fol), snow: share(snow), cool: share(cool), warm: share(warm),
      taper: widest ? q1 / widest : 1,
      widestAt: crownH ? (widestY - minY) / crownH : 0,
      trunkShare: (baseY - trunkTop + 1) / Math.max(1, maxY - minY + 1),
      crownToTrunk: widest / trunkW,
      crownFill,
      crownAspect: crownH / Math.max(1, widest),
      crownPixels: n,
    };
    out.tile = T;
    return out;
  }

  /**
   * Which kind a tree is, from its picture, when nothing named it. Returns the kind and whether the call was
   * confident; an unconfident call is broadleaf (the fall every tree can take).
   * Thresholds MEASURED on labelled stock + CSAF trees (Internal_Ops/_probe/kind_features.js).
   * @param {object} f  analysis.features
   * @returns {{kind:string, confident:boolean}}
   */
  function inferKind(f) {
    if (!f) return { kind: 'broadleaf', confident: false };
    if (f.cool >= 0.3 && f.foliage < 0.25) return { kind: 'crystal', confident: true };
    if (f.warm >= 0.2 && f.foliage < 0.3) return { kind: 'mushroom', confident: true };
    if (f.foliage + f.snow < 0.1) return { kind: 'dead', confident: true };
    // MEASURED 2026-10-23 (_probe/kind_features.js, 23 labelled stock + CSAF trees): snowy conifers carry 0.43 snow
    // and broadleaves 0.00; bare conifers taper (top fifth <= 0.47 of the widest row), are widest low (>= 0.74) and
    // tall (aspect >= 1.26) where the nearest broadleaf (the stock Large Tree) reads 0.52 / 0.69 / 0.88
    if (f.snow >= 0.3 || (f.taper <= 0.5 && f.widestAt >= 0.7 && f.crownAspect >= 1.1)) return { kind: 'conifer', confident: true };
    // palms: a sparse crown of fronds (fill 0.59-0.64) on a long visible trunk (0.41-0.69); the densest-crowned
    // long-trunk broadleaf (birch 0.76, mangrove 0.80, kapok 0.91) and the sparsest leafy one (Large Tree 0.73) do
    // not reach it. n = 2 palms: a thin margin, so the Readme recommends naming palms in the tileset note.
    if (f.foliage >= 0.5 && f.crownFill <= 0.68 && f.trunkShare >= 0.38) return { kind: 'palm', confident: true };
    return { kind: 'broadleaf', confident: f.foliage >= 0.35 };
  }

  // ── the fall ─────────────────────────────────────────────────────────────────────────────────────

  /**
   * Per-kind fall: an inverted pendulum about the hinge (a slow start, then gravity), a ground bounce, settle.
   * `accel` is the pull (rad / frame^2 per unit of sin), MEASURED for the impact frame the look wants
   * (core.test pins the impact window per kind). `whip` gives the crown its own lagging angle (palm).
   */
  const FALL = {
    broadleaf: { accel: 0.0125, theta0: 0.025, bounce: 0.24, whip: 0 },
    conifer: { accel: 0.016, theta0: 0.025, bounce: 0.2, whip: 0 },
    palm: { accel: 0.02, theta0: 0.03, bounce: 0.3, whip: 0.11 },
    dead: { accel: 0.03, theta0: 0.06, bounce: 0.12, whip: 0, drop: 6 },
    mushroom: { accel: 0.03, theta0: 0.12, bounce: 0.28, whip: 0 },
    crystal: null, // shatters where it stands
  };

  /**
   * The frame-by-frame angles of a fall, from upright (0) to lying (pi/2).
   * @param {string} kind
   * @returns {{trunk:Float32Array, crown:Float32Array, drop:Float32Array, impact:number, frames:number}|null}
   */
  function fallTable(kind) {
    const F = FALL[normalizeKind(kind) || 'broadleaf'];
    if (!F) return null;
    const HALF = Math.PI / 2;
    const trunk = [], crown = [], drop = [];
    let th = F.theta0, w = 0;
    let ph = 0, pw = 0; // crown angle (whip)
    let impact = -1, f = 0, bounces = 0;
    const dropN = F.drop ? 6 : 0;
    for (let k = 0; k < dropN; k++) { trunk.push(0); crown.push(0); drop.push(F.drop * (k + 1) / dropN); }
    for (f = 0; f < 240; f++) {
      w += F.accel * Math.sin(th);
      th += w;
      if (th >= HALF) {
        th = HALF;
        if (impact < 0) impact = trunk.length;
        if (Math.abs(w) < 0.004 || bounces >= 3) { w = 0; }
        else { w = -w * F.bounce; bounces++; }
      }
      if (F.whip) {
        // the crown is a damped spring toward the trunk's angle: it lags on the way down and overshoots at impact
        const acc = F.whip * (th - ph) - 0.22 * (pw - w);
        pw += acc; ph += pw;
        if (ph > HALF + 0.28) { ph = HALF + 0.28; pw = 0; }
      } else { ph = th; }
      trunk.push(th); crown.push(ph); drop.push(F.drop || 0);
      if (impact >= 0 && w === 0 && Math.abs(ph - th) < 0.004 && trunk.length - impact > 4) break;
    }
    return { trunk: Float32Array.from(trunk), crown: Float32Array.from(crown), drop: Float32Array.from(drop), impact, frames: trunk.length };
  }

  /** 'E' 'W' 'N' 'S' from a direction the player faces (MZ 2/4/6/8): the tree falls the way the player faces. */
  function fallDir(d) { return d === 6 ? 'E' : d === 4 ? 'W' : d === 8 ? 'N' : 'S'; }
  const LIE = 0.45; // a tree lying north or south is seen foreshortened on MZ's oblique ground

  /**
   * The pose of a falling tree at angle theta, as sprite rotation and vertical scale about the hinge.
   * @param {string} dir 'E'|'W'|'N'|'S'
   * @param {number} theta 0..pi/2
   * @returns {{rotation:number, scaleY:number}}
   */
  function pose(dir, theta) {
    if (dir === 'E') return { rotation: theta, scaleY: 1 };
    if (dir === 'W') return { rotation: -theta, scaleY: 1 };
    if (dir === 'N') return { rotation: 0, scaleY: Math.cos(theta) + LIE * Math.sin(theta) };
    return { rotation: 0, scaleY: Math.cos(theta) - LIE * Math.sin(theta) };
  }
  /** Where a picture point (px, py) lands when the tree lies, relative to the hinge (map pixels). */
  function lyingPoint(dir, rx, ry) {
    if (dir === 'E') return { x: -ry, y: rx };
    if (dir === 'W') return { x: ry, y: -rx };
    if (dir === 'N') return { x: rx, y: ry * LIE };
    return { x: rx, y: -ry * LIE };
  }

  /**
   * The lying picture: the crown (or any part) turned the way the tree came to rest, pixel for pixel, so a
   * fracture of it starts exactly where the sprite lay (a quarter turn is exact; N/S is a nearest-neighbour squash).
   * @param {Uint8Array|Uint8ClampedArray} rgba @param {number} W @param {number} H
   * @param {string} dir
   * @param {{x:number,y:number}} hinge
   * @returns {{rgba:Uint8ClampedArray, w:number, h:number, ox:number, oy:number}} ox/oy = the picture's top-left
   *          relative to the hinge
   */
  function lyingImage(rgba, W, H, dir, hinge) {
    if (dir === 'E' || dir === 'W') {
      const w = H, h = W, out = new Uint8ClampedArray(w * h * 4);
      for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
        // E: (x,y) -> (H-1-y, x) ; W: (x,y) -> (y, W-1-x)
        const nx = dir === 'E' ? H - 1 - y : y, ny = dir === 'E' ? x : W - 1 - x;
        const s = (y * W + x) * 4, d = (ny * w + nx) * 4;
        out[d] = rgba[s]; out[d + 1] = rgba[s + 1]; out[d + 2] = rgba[s + 2]; out[d + 3] = rgba[s + 3];
      }
      // the hinge maps through the same turn (pixel corners, not centres)
      const ox = dir === 'E' ? -(H - hinge.y) : -hinge.y;
      const oy = dir === 'E' ? -hinge.x : -(W - hinge.x);
      return { rgba: out, w, h, ox, oy };
    }
    // only the rows above the hinge stand up from it, so only they lie down (the rows below are the trunk's foot)
    const hy = clamp(hinge.y, 1, H);
    const h = Math.max(1, Math.round(hy * LIE)), w = W, out = new Uint8ClampedArray(w * h * 4);
    for (let y = 0; y < h; y++) {
      // N: row y lies at hinge - (h - y); its source row sits that far above the hinge, unsquashed
      // S: row y lies at hinge + y; mirrored, its source row sits y / LIE above the hinge
      const sy = dir === 'N' ? Math.floor((y + 0.5) / LIE) : Math.floor(hy - (y + 0.5) / LIE);
      if (sy < 0 || sy >= H) continue;
      for (let x = 0; x < w; x++) {
        const s = (sy * W + x) * 4, d = (y * w + x) * 4;
        out[d] = rgba[s]; out[d + 1] = rgba[s + 1]; out[d + 2] = rgba[s + 2]; out[d + 3] = rgba[s + 3];
      }
    }
    const ox = -hinge.x;
    const oy = dir === 'N' ? -h : 0;
    return { rgba: out, w, h, ox, oy };
  }

  // ── the notch ────────────────────────────────────────────────────────────────────────────────────

  /**
   * The notch after chop k of n: a wedge bitten into the trunk on the struck side (E/W falls), or, struck from
   * the front or back (N/S), a dark band across the trunk face that widens with every chop.
   * @param {object} A  analysis
   * @param {'L'|'R'|'F'} side  L/R = the bark edge facing the player; F = the face toward the camera
   * @param {number} k  chops so far (1..n)
   * @param {number} n  chops to fell
   * @returns {{cut:Uint8Array, shade:Uint8Array}} cut = pixels removed (transparent), shade = pixels darkened
   */
  function notch(A, side, k, n) {
    const W = A.W, H = A.H, t = A.trunk;
    const cut = new Uint8Array(W * H), shade = new Uint8Array(W * H);
    const nh = clamp(Math.round(t.w * 0.5), 3, 12);
    const cy = Math.round(A.hinge.y - clamp(t.w * 0.55, 4, 14)) - (nh >> 1);
    const frac = clamp(k / Math.max(1, n), 0, 1);
    if (side === 'F') {
      // the band opens from the trunk's middle toward both bark edges
      const half = Math.max(1, Math.round((t.w / 2) * (0.35 + 0.65 * frac)));
      const mid = (t.x0 + t.x1 + 1) / 2;
      const bh = Math.max(2, Math.round(nh * (0.5 + 0.5 * frac)));
      for (let y = cy; y < cy + bh; y++) for (let x = Math.floor(mid - half); x < Math.ceil(mid + half); x++) {
        if (x < 0 || x >= W || y < 0 || y >= H) continue;
        const i = y * W + x;
        if (A.mask[i]) shade[i] = 1;
      }
      return { cut, shade };
    }
    const depth = Math.max(1, Math.round(t.w * 0.62 * frac));
    const mid = Math.round((t.x0 + t.x1) / 2);
    for (let y = cy; y < cy + nh; y++) {
      if (y < 0 || y >= H) continue;
      // the bark edge of THIS row: a curved trunk (a palm) is not where the median says (core.test J1, coconut_palm)
      let e0 = -1, e1 = -1;
      if (mid >= 0 && mid < W && A.mask[y * W + mid]) {
        e0 = mid; while (e0 > 0 && A.mask[y * W + e0 - 1]) e0--;
        e1 = mid; while (e1 < W - 1 && A.mask[y * W + e1 + 1]) e1++;
      } else {
        let best = Infinity;
        for (let x = 0; x < W; x++) if (A.mask[y * W + x] && Math.abs(x - mid) < best) { best = Math.abs(x - mid); e0 = e1 = x; }
        if (e0 < 0) continue;
        while (e0 > 0 && A.mask[y * W + e0 - 1]) e0--;
        while (e1 < W - 1 && A.mask[y * W + e1 + 1]) e1++;
      }
      // a wedge: deepest in its middle row, closing toward its top and bottom rows
      const rel = Math.abs(y - (cy + (nh - 1) / 2)) / Math.max(1, nh / 2);
      const d = Math.min(e1 - e0, Math.max(1, Math.round(depth * (1 - rel * 0.85))));
      for (let s = 0; s < d; s++) {
        const x = side === 'L' ? e0 + s : e1 - s;
        const i = y * W + x;
        if (A.mask[i]) cut[i] = 1;
      }
      // the cut face inside the wedge is the darker wood
      const x = side === 'L' ? e0 + d : e1 - d;
      if (x >= 0 && x < W && A.mask[y * W + x]) shade[y * W + x] = 1;
    }
    return { cut, shade };
  }

  // ── what is left ─────────────────────────────────────────────────────────────────────────────────

  /**
   * Logs per kind and their sizes. The lying trunk runs from the hinge out to `reach` of the tree's height; it is
   * cut into equal logs with small gaps, each as thick as the trunk.
   * @returns {Array<{at:number, len:number, thick:number}>} at = the log's centre distance from the hinge
   */
  function logPlan(kind, A) {
    const k = normalizeKind(kind) || 'broadleaf';
    const count = { broadleaf: 3, conifer: 4, palm: 5, dead: 0, mushroom: 0, crystal: 0 }[k];
    if (!count || !A || !A.trunk) return [];
    const height = A.hinge.y - A.bbox.minY;
    const reach = k === 'palm' ? 0.78 : k === 'conifer' ? 0.74 : 0.62;
    const start = Math.max(2, Math.round(A.trunk.w * 0.4));
    const span = Math.max(count * 8, Math.round(height * reach) - start);
    const gap = Math.max(1, Math.round(span * 0.04));
    const len = Math.max(6, Math.floor((span - gap * (count - 1)) / count));
    const thick = clamp(Math.round(A.trunk.w * (k === 'conifer' ? 0.85 : k === 'palm' ? 0.9 : 1)), 5, 26);
    const out = [];
    for (let i = 0; i < count; i++) out.push({ at: start + i * (len + gap) + len / 2, len, thick });
    return out;
  }

  /** The stump's height above the hinge, per kind. */
  function stumpHeight(kind, A) {
    const k = normalizeKind(kind) || 'broadleaf';
    const w = A && A.trunk ? A.trunk.w : 12;
    if (k === 'palm') return clamp(Math.round(w * 0.55), 5, 10);
    if (k === 'dead') return clamp(Math.round(w * 1.1), 8, 20);
    if (k === 'mushroom') return clamp(Math.round(w * 0.6), 4, 12);
    if (k === 'crystal') return clamp(Math.round(A.tile * 0.35), 8, 24);
    return clamp(Math.round(w * 0.7), 6, 18);
  }

  /** Mix two colours. */
  function mix(a, b, t) { return [Math.round(a[0] + (b[0] - a[0]) * t), Math.round(a[1] + (b[1] - a[1]) * t), Math.round(a[2] + (b[2] - a[2]) * t)]; }
  /**
   * The cut-wood colours of a tree: heartwood and sapwood lightened from the tree's own bark toward pale wood,
   * ring lines from its mid bark. A palm's and a dead tree's cut faces are greyer.
   * @returns {{heart:number[], sap:number[], ring:number[], rim:number[]}}
   */
  function woodColours(kind, A) {
    const k = normalizeKind(kind) || 'broadleaf';
    const dark = A.bark[0], midc = A.bark[1], light = A.bark[2];
    const pale = k === 'dead' ? [196, 186, 168] : k === 'palm' ? [214, 196, 158] : k === 'conifer' ? [232, 206, 150] : [228, 196, 142];
    return { heart: mix(light, pale, 0.62), sap: mix(light, pale, 0.8), ring: mix(midc, pale, 0.25), rim: dark };
  }

  /**
   * The regrowth stage: -1 a bare stump, 0..2 a sapling growing, 3 grown back.
   * @param {number} elapsed seconds since felled
   * @param {number} total   regrow seconds (0 = never)
   */
  function regrowStage(elapsed, total) {
    if (!(total > 0)) return -1;
    const f = elapsed / total;
    if (f >= 1) return 3;
    if (f < 0.4) return -1;
    return Math.min(2, Math.floor((f - 0.4) / 0.2));
  }
  const SAPLING_SCALE = [0.3, 0.45, 0.62];

  // ── the save ─────────────────────────────────────────────────────────────────────────────────────

  const STORE_VERSION = 1;
  /**
   * The saved felled store: { v: 1, maps: { "<mapId>": { "<x>,<y>": <play-time second it fell> } } }.
   * Anything unreadable, or a version this build does not know, becomes an empty store; never throws.
   */
  function normalizeStore(s) {
    const out = { v: STORE_VERSION, maps: {} };
    if (!s || typeof s !== 'object' || s.v !== STORE_VERSION || !s.maps || typeof s.maps !== 'object') return out;
    for (const mid of Object.keys(s.maps)) {
      if (!/^\d+$/.test(mid)) continue;
      const m = s.maps[mid];
      if (!m || typeof m !== 'object') continue;
      const keep = {};
      let any = false;
      for (const key of Object.keys(m)) {
        if (!/^\d+,\d+$/.test(key)) continue;
        const v = Number(m[key]);
        if (isFinite(v) && v >= 0) { keep[key] = v; any = true; }
      }
      if (any) out.maps[mid] = keep;
    }
    return out;
  }

  CSAF.TimberCore = {
    VERSION: '1.0.0',
    KINDS, HITS, STOCK, MASK_ALPHA, MAX_CELLS, FALL, LIE, SAPLING_SCALE,
    hash, sheetPos, isUpperTile, isStar, isBlocking, normalizeKind,
    parseTilesetNote, parseMapNote,
    findTrees, analyse, inferKind,
    fallTable, fallDir, pose, lyingPoint, lyingImage,
    notch, logPlan, stumpHeight, woodColours, mix, regrowStage,
    normalizeStore, STORE_VERSION,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.TimberCore;
})(typeof globalThis !== 'undefined' ? globalThis : this);
