/*:
 * @target MZ
 * @plugindesc [v1.0.0] Timber: every tree in your own tileset can be cut down. It shudders, topples and splits into logs.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io/timber
 *
 * @help Timber.js
 *
 * Trees you can cut down, made from the trees already painted on your maps.
 * No tree sprite sheets, no events on every tree.
 *
 * INSTALL
 *   Put all four files in js/plugins and switch them ON: TimberCore.js,
 *   SmithereensCore.js, SmithereensCut.js and Timber.js. Their order does not
 *   matter. (If you own Smithereens, its two shared files are the same files:
 *   keep one copy of each.)
 *
 * WHICH TREES
 *   MZ's own stock trees work at once: the Outside tileset's trees, large
 *   trees, snowy conifers, dead trees, palms and mushrooms, and the SF
 *   Outside tree. For your own tilesets, pick a terrain tag (1 to 7) and give
 *   it to your tree tiles in the Database, Tilesets tab, Terrain Tag mode
 *   (one click per tile). Then either set "Tree terrain tag" below, or name
 *   the tag in the tileset's Note box:
 *       <Timber Tag 6>            terrain tag 6 tiles are trees
 *       <Timber Tag 5: conifer>   terrain tag 5 tiles are conifers
 *   Kinds: broadleaf, conifer, palm, dead, mushroom, crystal. Without a kind,
 *   Timber reads it from the tree's picture; naming it is always exact.
 *   A tree is the group of tiles painted together from the palette. Its
 *   bottom row needs a tile WITHOUT the star (the trunk). A tile painted
 *   with the ground inside it (no transparent background) falls with its
 *   ground, so Timber leaves it standing.
 *
 * CUTTING ONE DOWN
 *   Face the bottom of a tree and press OK (Enter, Space, Z or the A button).
 *   Each chop shakes the tree, cuts a notch into its own bark and knocks chips
 *   and leaves loose. The last chop fells it: struck from the side, it falls
 *   away from the player; struck from the front or back, it falls to the side
 *   with more open ground (a tree lying toward or away from the camera would
 *   be drawn at under half its height, so trees always fall sideways).
 *   Chops to fell: broadleaf 3, conifer 4, palm 2, dead 2, mushroom 1,
 *   crystal 3 (or one number for all, below).
 *
 * HOW EACH KIND COMES DOWN
 *   broadleaf  topples; the crown bursts into its own leaves; 3 logs, a stump
 *   conifer    topples faster; the crown breaks into wide boughs that slide
 *              apart; snow on a snowy tree falls at every chop; 4 thin logs
 *   palm       whips over (the crown lags, then springs); 5 short segments
 *   dead       snaps at the cut, drops, tips and shatters into splinters
 *   mushroom   flops over and bursts into slow spores; the stem stays
 *   crystal    does not fall: it shatters where it stands
 *   Every leaf, chip, log, splinter, stump and sapling is cut from the tree's
 *   own pixels. Stumps stay and block the cell (a parameter). A sapling grows
 *   back over play time and the tree returns (a parameter; 0 = never).
 *
 * MAP NOTE
 *   <Timber Off>          no trees can be cut on this map
 *   <Timber Regrow: 600>  this map's regrow time in seconds
 *
 * PLUGIN COMMANDS
 *   Chop Tree In Front    one chop at the tree the player faces
 *   Chop Tree At          one chop at a map cell (the tree's bottom row)
 *   Fell Tree At          fell a tree at once, in a direction
 *   Regrow All            every felled tree on this map grows back now
 *   Allow Chopping        turn the OK-button chop on or off
 *
 * SCRIPT (for conditional branches)
 *   Timber.isTree(x, y)    true when a standing tree's bottom row is at x, y
 *   Timber.felledCount()   trees felled on this map that have not grown back
 *
 * WHAT IT DOES NOT DO
 *   Overworld forest autotiles (A1, A2) and trees drawn as events are not
 *   cut. It does not count skill levels; a switch, an item or a weapon can
 *   be required (below), and a common event can run on every tree felled.
 *
 * Copyright (c) Core Systems Asset Factory. See LICENSE.txt.
 *
 * @param chopOnAction
 * @text Chop with the OK button
 * @type boolean
 * @default true
 * @desc Face a tree's bottom and press OK to chop it.
 *
 * @param requireItem
 * @text Needs item
 * @type item
 * @default 0
 * @desc The party must hold this item to chop (0 = none).
 *
 * @param requireWeapon
 * @text Needs weapon
 * @type weapon
 * @default 0
 * @desc The party must hold or wear this weapon to chop, an axe say (0 = none).
 *
 * @param requireSwitch
 * @text Needs switch
 * @type switch
 * @default 0
 * @desc Chopping only while this switch is ON (0 = always).
 *
 * @param deniedCommonEvent
 * @text When not allowed
 * @type common_event
 * @default 0
 * @desc Runs when the player presses OK at a tree without what it needs ("You need an axe."). 0 = nothing.
 *
 * @param treeTerrainTag
 * @text Tree terrain tag
 * @type number
 * @min 0
 * @max 7
 * @default 0
 * @desc Tiles with this terrain tag are trees, in every tileset (0 = none; the tileset note works too).
 *
 * @param treeRegion
 * @text Tree region
 * @type number
 * @min 0
 * @max 255
 * @default 0
 * @desc Upper-layer tiles on cells with this region are trees (0 = none).
 *
 * @param useStock
 * @text Stock MZ trees
 * @type boolean
 * @default true
 * @desc MZ's own stock tree tiles can be cut.
 *
 * @param hits
 * @text Chops to fell
 * @type number
 * @min 0
 * @max 20
 * @default 0
 * @desc One number for every tree (0 = by kind: broadleaf 3, conifer 4, palm 2, dead 2, mushroom 1, crystal 3).
 *
 * @param regrowSeconds
 * @text Regrow time (seconds)
 * @type number
 * @min 0
 * @default 300
 * @desc Seconds of play before a felled tree grows back (0 = never). A map note can override it.
 *
 * @param stumpBlocks
 * @text Stumps block
 * @type boolean
 * @default true
 *
 * @param yieldItem
 * @text Wood item
 * @type item
 * @default 0
 * @desc Given for broadleaf, conifer, palm and dead trees (0 = none).
 *
 * @param yieldAmount
 * @text Wood per tree
 * @type number
 * @min 0
 * @default 3
 *
 * @param mushroomItem
 * @text Mushroom item
 * @type item
 * @default 0
 *
 * @param crystalItem
 * @text Crystal item
 * @type item
 * @default 0
 *
 * @param yieldVariable
 * @text Count variable
 * @type variable
 * @default 0
 * @desc This variable goes up by one for every tree felled (0 = none).
 *
 * @param fellCommonEvent
 * @text Common event on fell
 * @type common_event
 * @default 0
 *
 * @param shake
 * @text Shake on landing
 * @type boolean
 * @default true
 *
 * @param chopSe
 * @text Sound: chop
 * @type file
 * @dir audio/se/
 * @default Blow3
 *
 * @param fallSe
 * @text Sound: fall
 * @type file
 * @dir audio/se/
 * @default Crash
 *
 * @param shatterSe
 * @text Sound: shatter
 * @type file
 * @dir audio/se/
 * @default Break
 *
 * @param maxFragments
 * @text Pieces on screen
 * @type number
 * @min 32
 * @max 512
 * @default 160
 *
 * @param debrisSeconds
 * @text Debris stays (seconds)
 * @type number
 * @min 0
 * @default 12
 * @desc Leaves, chips and splinters stay this long, then fade (0 = until the map changes).
 *
 * @param logSeconds
 * @text Logs stay (seconds)
 * @type number
 * @min 1
 * @default 5
 *
 * @command chopFront
 * @text Chop Tree In Front
 * @desc One chop at the tree the player faces.
 *
 * @command chopAt
 * @text Chop Tree At
 * @desc One chop at the tree whose bottom row is at this cell.
 *
 * @arg x
 * @type number
 * @default 0
 *
 * @arg y
 * @type number
 * @default 0
 *
 * @arg direction
 * @text Fall direction
 * @type select
 * @option player
 * @option east
 * @option west
 * @option north
 * @option south
 * @default player
 *
 * @command fellAt
 * @text Fell Tree At
 * @desc Fell the tree whose bottom row is at this cell, at once.
 *
 * @arg x
 * @type number
 * @default 0
 *
 * @arg y
 * @type number
 * @default 0
 *
 * @arg direction
 * @text Fall direction
 * @type select
 * @option player
 * @option east
 * @option west
 * @option north
 * @option south
 * @default player
 *
 * @command regrowAll
 * @text Regrow All
 * @desc Every felled tree on this map grows back now.
 *
 * @command allow
 * @text Allow Chopping
 * @desc Turn the OK-button chop on or off (saved).
 *
 * @arg on
 * @type boolean
 * @default true
 */
(() => {
  'use strict';
  const NAME = 'Timber';
  const RAW = PluginManager.parameters(NAME);
  // parameters arrive as STRINGS and Number('') is 0 (wing §16): blank is the default, never zero
  const num = (v, d, lo, hi) => { if (v === undefined || v === null || String(v).trim() === '') return d; const n = Number(v); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d; };
  const bool = (v, d) => (String(v) === 'true' ? true : String(v) === 'false' ? false : d);
  const P = {
    chopOnAction: bool(RAW.chopOnAction, true),
    requireItem: num(RAW.requireItem, 0, 0, 9999),
    requireWeapon: num(RAW.requireWeapon, 0, 0, 9999),
    requireSwitch: num(RAW.requireSwitch, 0, 0, 9999),
    deniedCommonEvent: num(RAW.deniedCommonEvent, 0, 0, 9999),
    treeTerrainTag: num(RAW.treeTerrainTag, 0, 0, 7),
    treeRegion: num(RAW.treeRegion, 0, 0, 255),
    useStock: bool(RAW.useStock, true),
    hits: num(RAW.hits, 0, 0, 20),
    regrowSeconds: num(RAW.regrowSeconds, 300, 0, 1e9),
    stumpBlocks: bool(RAW.stumpBlocks, true),
    yieldItem: num(RAW.yieldItem, 0, 0, 9999),
    yieldAmount: num(RAW.yieldAmount, 3, 0, 999),
    mushroomItem: num(RAW.mushroomItem, 0, 0, 9999),
    crystalItem: num(RAW.crystalItem, 0, 0, 9999),
    yieldVariable: num(RAW.yieldVariable, 0, 0, 9999),
    fellCommonEvent: num(RAW.fellCommonEvent, 0, 0, 9999),
    shake: bool(RAW.shake, true),
    chopSe: RAW.chopSe === undefined ? 'Blow3' : String(RAW.chopSe),
    fallSe: RAW.fallSe === undefined ? 'Crash' : String(RAW.fallSe),
    shatterSe: RAW.shatterSe === undefined ? 'Break' : String(RAW.shatterSe),
    maxFragments: num(RAW.maxFragments, 160, 32, 512),
    debrisSeconds: num(RAW.debrisSeconds, 12, 0, 3600),
    logSeconds: num(RAW.logSeconds, 5, 1, 3600),
  };

  // ── the three sibling files, resolved at FIRST USE: load order is the buyer's choice (wing §8 trap 2) ──
  function TC() { return window.CSAF && window.CSAF.TimberCore; }
  function SC() { return window.CSAF && window.CSAF.SmithereensCore; }
  function SX() { return window.CSAF && window.CSAF.SmithereensCut; }
  let _warned = false;
  function ready() {
    if (TC() && SC() && SX()) return true;
    if (!_warned) { _warned = true; console.warn('Timber: switch ON TimberCore.js, SmithereensCore.js and SmithereensCut.js beside Timber.js.'); }
    return false;
  }

  const SWING = 10;      // frames of the player's swing; the blow lands on HIT_AT
  const HIT_AT = 4;
  const PAGE = 1024;     // the shared fragment atlas page
  const STATS = { reads: 0, bakes: 0, chops: 0, fells: 0, regrows: 0, uploads: 0 };

  // ── the saved store (decisions only: which tree fell when) ─────────────────────────────────────
  function store() {
    if (!$gameSystem) return null;
    const s = $gameSystem._csafTimber;
    if (!s || s.v !== TC().STORE_VERSION) $gameSystem._csafTimber = TC().normalizeStore(s);
    return $gameSystem._csafTimber;
  }
  function nowSec() { return $gameSystem ? $gameSystem.playtime() : 0; }
  function allowed() {
    const s = store();
    return !(s && s.off === true);
  }

  // ── the map model: which trees this map has, rebuilt whenever $dataMap is a new object ──────────
  /*
   * A loaded save reloads $dataMap WITHOUT Game_Map.setup (Scene_Map.create -> onMapLoaded), and so does
   * returning from the menu, so the model is keyed on the $dataMap OBJECT and synced from both seams.
   */
  const M = { data: null, mapId: 0, trees: [], cellTree: null, W: 0, H: 0, off: false, regrow: 0, renderData: null, hits: new Map(), hitsMap: 0 };
  function syncMap() {
    if (!ready() || typeof $dataMap === 'undefined' || !$dataMap || !$gameMap) return;
    // a Change Tileset event keeps $dataMap but changes what every tile id IS: that is a new model too
    if (M.data === $dataMap && M.mapId === $gameMap.mapId() && M.tilesetId === $gameMap.tilesetId()) return;
    // the SAME $dataMap (a tileset change) still has its felled trees zeroed: put them back so they are found again,
    // and the store below takes them down again; otherwise their stumps and regrowth would be lost
    if (M.data === $dataMap && M.mapId === $gameMap.mapId()) for (const t of M.trees) if (t.state === 'felled') setTiles(t, $dataMap.data, true);
    M.data = $dataMap; M.mapId = $gameMap.mapId(); M.tilesetId = $gameMap.tilesetId(); M.renderData = null;
    M.W = $dataMap.width; M.H = $dataMap.height;
    if (M.hitsMap !== M.mapId) { M.hits = new Map(); M.hitsMap = M.mapId; }
    const C = TC();
    const note = C.parseMapNote($dataMap.note);
    M.off = note.off;
    M.regrow = note.regrow !== null ? note.regrow : P.regrowSeconds;
    const ts = $gameMap.tileset();
    M.trees = []; M.cellTree = null;
    if (M.off || !ts) return;
    const r = C.findTrees({
      width: M.W, height: M.H, data: $dataMap.data, flags: ts.flags, sheetNames: ts.tilesetNames.slice(5, 9),
      treeTag: P.treeTerrainTag, tagKinds: C.parseTilesetNote(ts.note), treeRegion: P.treeRegion, stock: P.useStock,
    });
    M.trees = r.trees; M.cellTree = r.cellTree;
    const s = store();
    const felled = s && s.maps[M.mapId] ? s.maps[M.mapId] : null;
    const t0 = nowSec();
    for (const t of M.trees) {
      t.state = 'standing';
      t.stumpCell = t.baseCells[Math.floor((t.baseCells.length - 1) / 2)];
      if (felled && felled[t.key] !== undefined) {
        if (C.regrowStage(t0 - felled[t.key], M.regrow) === 3) delete felled[t.key];
        else { setTiles(t, $dataMap.data, false); t.state = 'felled'; t.felledAt = felled[t.key]; }
      }
    }
  }
  /** Write a tree's tiles into a data array (on = its own tiles, off = 0). */
  function setTiles(t, data, on) {
    for (const n of t.nodes) data[(n.z * M.H + n.y) * M.W + n.x] = on ? n.t : 0;
  }
  function treeAtBase(x, y) {
    if (!M.cellTree || x < 0 || y < 0 || x >= M.W || y >= M.H) return null;
    const i = M.cellTree[y * M.W + x];
    if (!i) return null;
    const t = M.trees[i - 1];
    for (const b of t.baseCells) if (b.x === x && b.y === y) return t;
    return null;
  }
  function stumpAt(x, y) {
    if (!M.cellTree || x < 0 || y < 0 || x >= M.W || y >= M.H) return false;
    const i = M.cellTree[y * M.W + x];
    if (!i) return false;
    const t = M.trees[i - 1];
    return t.state === 'felled' && t.stumpCell.x === x && t.stumpCell.y === y;
  }
  function hitsFor(t, kind) { return P.hits > 0 ? P.hits : TC().HITS[kind] || 3; }

  // ── seams on the map ─────────────────────────────────────────────────────────────────────────
  const _Game_Map_setup = Game_Map.prototype.setup;
  Game_Map.prototype.setup = function (mapId) {
    _Game_Map_setup.call(this, mapId);
    syncMap();
  };
  const _Game_Map_isPassable = Game_Map.prototype.isPassable;
  Game_Map.prototype.isPassable = function (x, y, d) {
    // a stump stands where the trunk stood; every other cell answers from its tiles, exactly as before
    if (P.stumpBlocks && M.cellTree && M.data === $dataMap && stumpAt(x, y)) return false;
    return _Game_Map_isPassable.call(this, x, y, d);
  };
  const _Spriteset_Map_createTilemap = Spriteset_Map.prototype.createTilemap;
  Spriteset_Map.prototype.createTilemap = function () {
    syncMap(); // a loaded save or a return from the menu reloaded $dataMap without Game_Map.setup
    _Spriteset_Map_createTilemap.call(this);
  };

  // ── the player's swing and the OK button ────────────────────────────────────────────────────────
  const Swing = { frames: 0, dx: 0, dy: 0, pending: null };
  const _Game_Player_canMove = Game_Player.prototype.canMove;
  Game_Player.prototype.canMove = function () {
    if (Swing.frames > 0) return false;
    return _Game_Player_canMove.call(this);
  };
  const _Game_Player_screenX = Game_Player.prototype.screenX;
  Game_Player.prototype.screenX = function () { return _Game_Player_screenX.call(this) + swingOffset() * Swing.dx; };
  const _Game_Player_screenY = Game_Player.prototype.screenY;
  Game_Player.prototype.screenY = function () { return _Game_Player_screenY.call(this) + swingOffset() * Swing.dy; };
  function swingOffset() {
    if (Swing.frames <= 0) return 0;
    const f = SWING - Swing.frames; // 0..SWING-1
    return f <= HIT_AT ? Math.round(5 * f / HIT_AT) : Math.round(5 * (SWING - f) / (SWING - HIT_AT));
  }
  function partyMay() {
    if (P.requireSwitch > 0 && !$gameSwitches.value(P.requireSwitch)) return false;
    if (P.requireItem > 0 && !$gameParty.hasItem($dataItems[P.requireItem])) return false;
    if (P.requireWeapon > 0 && !$gameParty.hasItem($dataWeapons[P.requireWeapon], true)) return false;
    return true;
  }
  const _Game_Player_triggerButtonAction = Game_Player.prototype.triggerButtonAction;
  Game_Player.prototype.triggerButtonAction = function () {
    if (_Game_Player_triggerButtonAction.call(this)) return true;
    if (!P.chopOnAction || !Input.isTriggered('ok') || !allowed() || this.isInVehicle() || Swing.frames > 0) return false;
    const d = this.direction();
    const x2 = $gameMap.roundXWithDirection(this.x, d), y2 = $gameMap.roundYWithDirection(this.y, d);
    syncMap();
    const t = treeAtBase(x2, y2);
    if (!t || t.state !== 'standing') return false;
    if (!partyMay()) {
      if (P.deniedCommonEvent > 0) { $gameTemp.reserveCommonEvent(P.deniedCommonEvent); return true; }
      return false;
    }
    return requestChop(t, d);
  };
  /** Start the swing; the blow lands HIT_AT frames later. @returns {boolean} */
  function requestChop(t, d) {
    const L = currentLayer();
    if (!L || !L.canChop(t)) return false;
    Swing.frames = SWING;
    Swing.dx = d === 6 ? 1 : d === 4 ? -1 : 0;
    Swing.dy = d === 2 ? 1 : d === 8 ? -1 : 0;
    Swing.pending = { t, d };
    return true;
  }
  function currentLayer() {
    const s = SceneManager._scene;
    return s && s._spriteset && s._spriteset._csafTimber ? s._spriteset._csafTimber : null;
  }

  // ── the layer: everything Timber draws on one map ──────────────────────────────────────────────
  function TimberLayer(spriteset) {
    this._ss = spriteset;
    this._tm = spriteset._tilemap;
    this._sigs = new Map();     // signature -> baked pictures
    this._warm = [];            // signatures waiting to be read
    this._inst = new Map();     // tree index -> live instance (chopped, falling, felled)
    this._list = [];            // the same instances as a plain array: the per-frame loop walks this, never the Map
    this._frameSeen = -1;
    this._jobs = [];            // one heavy job per frame (a crown burst, a log split)
    const C = SC();
    this._pool = C.createPool(P.maxFragments);
    this._pool.debrisFrames = Math.round(P.debrisSeconds * 60);
    this._page = SX().createPage(PAGE, PAGE);
    this._atlas = new Bitmap(PAGE, PAGE);
    this._atlas.smooth = false; // pixel art samples NEAREST (Smithereens, 2026-09-19)
    // the atlas mirror is made with the layer, while the map fades in: made on the first chop it cost that chop 26-31 ms
    // (MEASURED _probe/event_cost.js, 2026-10-23)
    this._pixels = new Uint8ClampedArray(PAGE * PAGE * 4);
    this._sprites = [];
    this._fx = new Float32Array(this._pool.capacity);
    this._fy = new Float32Array(this._pool.capacity);
    for (let i = 0; i < this._pool.capacity; i++) {
      const s = new Sprite(this._atlas);
      s.visible = false; s.z = 3;
      this._sprites.push(s);
      this._tm.addChild(s);
    }
    this._breaks = 0;
    // small particles (dust, spores, snow): a fixed pool, state in typed arrays
    this._pN = 48;
    this._px = new Float32Array(this._pN); this._py = new Float32Array(this._pN); this._ph = new Float32Array(this._pN);
    this._pvx = new Float32Array(this._pN); this._pvy = new Float32Array(this._pN); this._pvh = new Float32Array(this._pN);
    this._page2 = new Float32Array(this._pN); this._plife = new Float32Array(this._pN); this._pkind = new Uint8Array(this._pN);
    this._psprites = [];
    for (let i = 0; i < this._pN; i++) { const s = new Sprite(); s.visible = false; s.z = 4; s.anchor.x = 0.5; s.anchor.y = 0.5; this._psprites.push(s); this._tm.addChild(s); }
    this._pNext = 0;
    this._scratch = null; this._sctx = null;
    this._tsId = $gameMap.tilesetId();
    this.refill();
  }

  /**
   * A Change Tileset event: every picture read so far belongs to the old tileset. Stumps, logs and anything mid-fall
   * are dropped (their art is the old tileset's), the trees are found again in the new one and read again. The engine
   * itself repaints the map from the new sheets (Spriteset_Map.updateTileset).
   */
  TimberLayer.prototype.retileset = function () {
    this._tsId = $gameMap.tilesetId();
    for (let i = this._list.length - 1; i >= 0; i--) this.dropInst(this._list[i]);
    this._jobs.length = 0;
    this._sigs = new Map();
    this._warm = [];
    if (M.renderData) { M.renderData = null; this._tm.setData(M.W, M.H, $dataMap.data); this._tm.refresh(); }
    syncMap();
    this.refill();
  };
  /** Queue every signature on this map that has not been read; build instances for felled trees. */
  TimberLayer.prototype.refill = function () {
    for (const t of M.trees) {
      if (!this._sigs.has(t.sig)) { this._sigs.set(t.sig, { state: 'pending', tree: t }); this._warm.push(t.sig); }
    }
  };

  function tilesetBitmap(tileId) {
    const ts = $gameMap.tileset();
    const name = ts ? ts.tilesetNames[5 + Math.floor(tileId / 256)] : '';
    return name ? ImageManager.loadTileset(name) : null;
  }

  /**
   * Read ONE tree picture per frame while the map settles (a pixel read is a GPU sync point: up to 30 ms if it
   * lands in a busy frame, wing §27a), and bake everything that tree will ever show from it. Nothing reads pixels
   * after this: a chop, a fall and a regrowth only draw from these buffers.
   */
  TimberLayer.prototype.warmNext = function () {
    for (let k = 0; k < this._warm.length; k++) {
      const sig = this._warm[k];
      const e = this._sigs.get(sig);
      if (!e || e.state !== 'pending') { this._warm.splice(k--, 1); continue; }
      let readyAll = true;
      for (const n of e.tree.nodes) { const b = tilesetBitmap(n.t); if (!b || !b.isReady()) { readyAll = false; break; } }
      if (!readyAll) continue;
      this._warm.splice(k, 1);
      this.bake(e);
      return true;
    }
    return false;
  };

  TimberLayer.prototype.scratch = function (w, h) {
    if (!this._scratch) { this._scratch = document.createElement('canvas'); this._scratch.width = 0; this._scratch.height = 0; }
    if (this._scratch.width < w || this._scratch.height < h) { this._scratch.width = Math.max(this._scratch.width, w); this._scratch.height = Math.max(this._scratch.height, h); this._sctx = null; }
    if (!this._sctx) this._sctx = this._scratch.getContext('2d', { willReadFrequently: true });
    return this._sctx;
  };

  /** A Bitmap from an RGBA buffer. */
  function bitmapFrom(rgba, w, h) {
    const b = new Bitmap(Math.max(1, w), Math.max(1, h));
    b.smooth = false;
    if (w > 0 && h > 0) b.context.putImageData(new ImageData(rgba, w, h), 0, 0);
    b._baseTexture.update();
    STATS.uploads++;
    return b;
  }

  TimberLayer.prototype.bake = function (e) {
    const C = TC(), t = e.tree;
    const tw = $gameMap.tileWidth(), th = $gameMap.tileHeight();
    const W = t.cols * tw, H = t.rows * th;
    const ctx = this.scratch(W, H);
    ctx.clearRect(0, 0, W, H);
    const crownCell = new Uint8Array(t.cols * t.rows); // 1 = a star (crown) cell
    for (const n of t.nodes) {
      const b = tilesetBitmap(n.t);
      const sx = ((Math.floor(n.t / 128) % 2) * 8 + (n.t % 8)) * tw, sy = (Math.floor((n.t % 256) / 8) % 16) * th;
      // the tileset's own image, as the engine's Bitmap.blt reads it (rmmz_core.js:1502); never `b.canvas`, which
      // builds a canvas copy of the shared tileset and swaps its texture onto it (wing Probe_Doctrine §39a)
      ctx.drawImage(b._canvas || b._image, sx, sy, tw, th, (n.x - t.x) * tw, (n.y - t.y) * th, tw, th);
      if (n.star) crownCell[(n.y - t.y) * t.cols + (n.x - t.x)] = 1;
    }
    const img = ctx.getImageData(0, 0, W, H);
    STATS.reads++;
    const rgba = new Uint8ClampedArray(img.data);
    const baseXs = t.baseCells.map((b) => b.x - t.x);
    const baseCx = ((Math.min.apply(null, baseXs) + Math.max.apply(null, baseXs) + 1) / 2) * tw;
    const A = C.analyse(rgba, W, H, { baseCx, tile: tw });
    if (!A.ok || A.groundBacked) { e.state = 'skip'; return; }
    const kind = t.kind || C.inferKind(A.features).kind;
    e.kind = kind; e.A = A; e.W = W; e.H = H; e.rgba = rgba; e.tw = tw; e.th = th;
    e.scale = SC().detectScale(rgba, W, H);
    // the two parts as the engine draws them: crown cells over characters, trunk cells under
    const crown = new Uint8ClampedArray(W * H * 4), trunk = new Uint8ClampedArray(W * H * 4);
    const hardCrown = new Uint8ClampedArray(W * H * 4), hardTrunk = new Uint8ClampedArray(W * H * 4), residue = new Uint8ClampedArray(W * H * 4);
    for (let y = 0; y < H; y++) {
      const cr = Math.floor(y / th);
      for (let x = 0; x < W; x++) {
        const i = (y * W + x) * 4, a = rgba[i + 3];
        if (!a) continue;
        const isCrown = crownCell[cr * t.cols + Math.floor(x / tw)] === 1;
        const dst = isCrown ? crown : trunk, hard = isCrown ? hardCrown : hardTrunk;
        dst[i] = rgba[i]; dst[i + 1] = rgba[i + 1]; dst[i + 2] = rgba[i + 2]; dst[i + 3] = a;
        if (a >= C.MASK_ALPHA) { hard[i] = rgba[i]; hard[i + 1] = rgba[i + 1]; hard[i + 2] = rgba[i + 2]; hard[i + 3] = a; }
        else { residue[i] = rgba[i]; residue[i + 1] = rgba[i + 1]; residue[i + 2] = rgba[i + 2]; residue[i + 3] = a; }
      }
    }
    e.crownCell = crownCell;
    e.trunkRGBA = trunk; e.hardCrown = hardCrown; e.hardTrunk = hardTrunk;
    e.bmp = {
      crown: bitmapFrom(crown, W, H), hardCrown: bitmapFrom(hardCrown, W, H), hardTrunk: bitmapFrom(hardTrunk, W, H),
      residue: bitmapFrom(residue, W, H),
    };
    e.wood = C.woodColours(kind, A);
    e.bmp.stump = this.bakeStump(e);
    e.logs = C.logPlan(kind, A);
    e.bmp.logsH = e.logs.map((g, i) => this.bakeLog(e, g, i, false));
    e.bmp.logsV = e.logs.map((g, i) => this.bakeLog(e, g, i, true));
    e.bmp.saplings = C.SAPLING_SCALE.map((s) => this.bakeSapling(e, s));
    e.bmp.dust = this.bakeDust(e);
    e.bmp.spores = this.bakeSpores(e);
    e.state = 'ready';
    STATS.bakes++;
    // a tree felled before this layer existed shows its stump (or sapling) as soon as its picture is read
    for (const tr of M.trees) if (tr.sig === t.sig && tr.state === 'felled') this.showFelled(tr);
    // a tree already chopped (a return from the menu) gets its notch back
    for (const tr of M.trees) if (tr.sig === t.sig && tr.state === 'standing' && M.hits.has(tr.key)) this.relift(tr);
  };

  // ── baked remains: stump, logs, saplings, dust, spores ─────────────────────────────────────────
  TimberLayer.prototype.bakeStump = function (e) {
    const C = TC(), A = e.A, k = e.kind, W = e.W, H = e.H;
    const sh = C.stumpHeight(k, A);
    const t = A.trunk;
    const flare = Math.max(3, Math.round(t.w * 0.4));
    const x0 = Math.max(0, t.x0 - flare), x1 = Math.min(W - 1, t.x1 + flare);
    const y1 = A.hinge.y - 1, y0 = Math.max(0, A.hinge.y - sh);
    const faceH = Math.max(2, Math.round(t.w * 0.38));
    const sw = x1 - x0 + 1, shh = (y1 - y0 + 1) + faceH;
    const out = new Uint8ClampedArray(sw * shh * 4);
    const src = e.rgba;
    const top = faceH; // rows of the cut face above the bark
    // bark: the tree's own lowest rows, inside the trunk (and its roots) only
    for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
      const si = (y * W + x) * 4;
      if (src[si + 3] < C.MASK_ALPHA) continue;
      // above the root flare keep only the trunk's own columns
      const nearBase = y > y1 - Math.max(2, Math.round(sh * 0.35));
      if (!nearBase && (x < t.x0 || x > t.x1)) continue;
      const d = ((y - y0 + top) * sw + (x - x0)) * 4;
      out[d] = src[si]; out[d + 1] = src[si + 1]; out[d + 2] = src[si + 2]; out[d + 3] = 255;
    }
    const cx = (t.x0 + t.x1 + 1) / 2 - x0, rx = t.w / 2, ry = faceH / 2, cy = top;
    const W8 = e.wood;
    if (k === 'dead' || k === 'crystal') {
      // a broken top: jagged, no rings. The tooth pattern is seeded by the tree's own signature
      let h = TC().hash(e.tree.sig);
      for (let x = Math.floor(cx - rx); x <= Math.ceil(cx + rx); x++) {
        h = (Math.imul(h ^ (h >>> 13), 0x5bd1e995) >>> 0);
        const tooth = (h % 5);
        for (let y = top; y < top + tooth; y++) { const d = (y * sw + x) * 4; if (x >= 0 && x < sw && d >= 0) out[d + 3] = 0; }
      }
    } else {
      // the cut face: an ellipse of pale wood, rings in the tree's mid bark, a dark bark rim, lit from the upper left
      for (let y = 0; y < top * 2 + 1 && y < shh; y++) for (let x = 0; x < sw; x++) {
        const nx = (x + 0.5 - cx) / Math.max(1, rx), ny = (y + 0.5 - cy) / Math.max(1, ry);
        const r = Math.sqrt(nx * nx + ny * ny);
        if (r > 1) continue;
        const d = (y * sw + x) * 4;
        let c;
        if (r > 0.82) c = W8.rim;
        else {
          const rings = k === 'palm' ? 2 : 3;
          const ring = Math.abs(Math.sin(r * Math.PI * rings)) < 0.28 && r > 0.15;
          c = ring ? W8.ring : (r < 0.45 ? W8.heart : W8.sap);
          if (nx + ny < -0.6) c = C.mix(c, [255, 248, 230], 0.18); // the lit edge
        }
        out[d] = c[0]; out[d + 1] = c[1]; out[d + 2] = c[2]; out[d + 3] = 255;
      }
    }
    e.stumpOrigin = { x: x0, y: y0 - top };
    return bitmapFrom(out, sw, shh);
  };

  /** A log cut from the tree's own bark: a lying cylinder, bark along it, a cut end of pale wood. */
  TimberLayer.prototype.bakeLog = function (e, g, idx, vertical) {
    const C = TC(), A = e.A, t = A.trunk, W = e.W, src = e.rgba, W8 = e.wood;
    // the bark strip: the trunk's own columns over the rows where its bark shows (at least a few)
    const yTop = Math.min(t.top, A.hinge.y - 6), yBot = A.hinge.y - 1;
    const strip = [];
    for (let y = yTop; y <= yBot; y++) { const row = []; for (let x = t.x0; x <= t.x1; x++) { const i = (y * W + x) * 4; if (src[i + 3] >= C.MASK_ALPHA) row.push([src[i], src[i + 1], src[i + 2]]); } if (row.length) strip.push(row); }
    if (!strip.length) strip.push([A.bark[1]]);
    const L = g.len, T = g.thick;
    const endW = Math.max(2, Math.round(T * 0.42)); // the cut end, seen at an angle
    const w = vertical ? T : L + endW, h = vertical ? Math.round(L * C.LIE) + endW : T;
    const out = new Uint8ClampedArray(w * h * 4);
    const put = (x, y, c, a) => { if (x < 0 || y < 0 || x >= w || y >= h) return; const d = (y * w + x) * 4; out[d] = c[0]; out[d + 1] = c[1]; out[d + 2] = c[2]; out[d + 3] = a || 255; };
    const shade = (c, f) => [Math.round(c[0] * f), Math.round(c[1] * f), Math.round(c[2] * f)];
    const len = vertical ? h - endW : L;
    for (let a = 0; a < len; a++) {
      // along the log: walk the bark strip so its knots and grain run down the log (mirrored, never stretched)
      const per = strip.length * 2 - 1, q = (a + idx * 5) % Math.max(1, per), row = strip[q < strip.length ? q : per - q];
      for (let b = 0; b < T; b++) {
        // across the log: a cylinder lit from above, darker below
        const u = b / Math.max(1, T - 1);
        const f = 1.18 - 0.5 * u;
        const c = shade(row[Math.min(row.length - 1, Math.floor(u * row.length))], f);
        if (vertical) put(b, a, c); else put(a + endW, b, c);
      }
    }
    // the cut end: an ellipse of pale wood with rings and a dark rim
    const ex = vertical ? T / 2 : endW / 2 + 0.5, ey = vertical ? h - endW / 2 - 0.5 : T / 2;
    const rx = vertical ? T / 2 : endW / 2 + 0.5, ry = vertical ? endW / 2 + 0.5 : T / 2;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const nx = (x + 0.5 - ex) / rx, ny = (y + 0.5 - ey) / ry, r = Math.sqrt(nx * nx + ny * ny);
      if (r > 1) continue;
      const ring = Math.abs(Math.sin(r * Math.PI * 2.5)) < 0.3 && r > 0.18;
      put(x, y, r > 0.8 ? W8.rim : ring ? W8.ring : r < 0.45 ? W8.heart : W8.sap);
    }
    return bitmapFrom(out, w, h);
  };

  TimberLayer.prototype.bakeSapling = function (e, s) {
    const W = e.W, H = e.H, w = Math.max(4, Math.round(W * s)), h = Math.max(4, Math.round(H * s));
    const out = new Uint8ClampedArray(w * h * 4), src = e.rgba, C = TC();
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const sx = Math.min(W - 1, Math.floor((x + 0.5) / s)), sy = Math.min(H - 1, Math.floor((y + 0.5) / s));
      const i = (sy * W + sx) * 4;
      if (src[i + 3] < C.MASK_ALPHA) continue;
      const d = (y * w + x) * 4;
      out[d] = src[i]; out[d + 1] = src[i + 1]; out[d + 2] = src[i + 2]; out[d + 3] = 255;
    }
    return { bmp: bitmapFrom(out, w, h), w, h, s };
  };

  TimberLayer.prototype.bakeDust = function (e) {
    const C = TC(), base = C.mix(e.A.bark[2], [206, 194, 172], 0.55), n = 14;
    const out = new Uint8ClampedArray(n * n * 4);
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
      const dx = (x + 0.5 - n / 2) / (n / 2), dy = (y + 0.5 - n / 2) / (n / 2), r = Math.sqrt(dx * dx + dy * dy);
      if (r > 1) continue;
      const d = (y * n + x) * 4;
      out[d] = base[0]; out[d + 1] = base[1]; out[d + 2] = base[2]; out[d + 3] = Math.round(150 * (1 - r) * (1 - r) + 20);
    }
    return bitmapFrom(out, n, n);
  };

  TimberLayer.prototype.bakeSpores = function (e) {
    // five 3 px motes in the crown's own colours (spores, needles, snow), side by side on one strip
    const cols = e.A.crown, n = cols.length, out = new Uint8ClampedArray(n * 3 * 3 * 4);
    for (let k = 0; k < n; k++) for (let y = 0; y < 3; y++) for (let x = 0; x < 3; x++) {
      if ((x === 0 || x === 2) && (y === 0 || y === 2)) continue; // a plus, not a square
      const d = (y * n * 3 + k * 3 + x) * 4, c = cols[k];
      out[d] = c[0]; out[d + 1] = c[1]; out[d + 2] = c[2]; out[d + 3] = 255;
    }
    return bitmapFrom(out, n * 3, 3);
  };

  // ── instances: a tree being chopped, falling, or lying as a stump ──────────────────────────────
  TimberLayer.prototype.canChop = function (t) {
    const e = this._sigs.get(t.sig);
    return !!(e && e.state === 'ready' && t.state === 'standing');
  };
  TimberLayer.prototype.mapOrigin = function (t, e) { return { x: t.x * e.tw, y: t.y * e.th }; };

  /** Take the tree off the RENDER copy of the map (the game still sees it standing) and show it as sprites. */
  TimberLayer.prototype.lift = function (t) {
    const e = this._sigs.get(t.sig);
    let inst = this._inst.get(t.index);
    if (inst) return inst;
    if (!M.renderData) { M.renderData = $dataMap.data.slice(); this._tm.setData(M.W, M.H, M.renderData); }
    setTiles(t, M.renderData, false);
    this._tm.refresh();
    const o = this.mapOrigin(t, e);
    const trunkCopy = new Uint8ClampedArray(e.trunkRGBA);
    inst = {
      t, e, o, phase: 'standing', hits: 0, need: hitsFor(t, e.kind), shake: 0, sway: 0, dir: 'E', frame: 0,
      trunkRGBA: trunkCopy, trunkBmp: bitmapFrom(trunkCopy, e.W, e.H), cut: new Uint8Array(e.W * e.H),
      crown: null, trunk: null, residue: null, stump: null, sapling: null, logs: [], logPhase: 0, stage: -2,
    };
    inst.crown = this.treeSprite(e.bmp.crown, e, o, 4);
    inst.trunk = this.treeSprite(inst.trunkBmp, e, o, 1);
    this._inst.set(t.index, inst);
    this._list.push(inst);
    return inst;
  };
  TimberLayer.prototype.treeSprite = function (bmp, e, o, z) {
    const s = new Sprite(bmp);
    s.anchor.x = e.A.hinge.x / e.W; s.anchor.y = e.A.hinge.y / e.H;
    s.z = z;
    s._mx = o.x + e.A.hinge.x; s._my = o.y + e.A.hinge.y;
    this._tm.addChild(s);
    return s;
  };
  TimberLayer.prototype.relift = function (t) {
    const h = M.hits.get(t.key);
    if (!h || !h.n) return;
    const inst = this.lift(t);
    inst.hits = h.n; inst.dir = h.dir; inst.from = h.from;
    this.drawNotch(inst, h.n, false);
  };

  /** One blow: shake, notch, chips, leaves; the last blow fells. */
  /*
   * A tree falls SIDEWAYS. LOOKED AT 2026-10-23 (Internal_Ops/_probe/motion.js): on MZ's oblique ground a tree lying
   * north or south is drawn foreshortened to under half its height, so a fall toward or away from the camera read as
   * the tree SHRINKING into the ground, and a burst crown hung in the air where it had stood. Struck from the side,
   * it falls away from the player; struck from the front or back, it falls toward the side with more open ground.
   */
  TimberLayer.prototype.fallSide = function (t, d) {
    if (d === 6) return 'E';
    if (d === 4) return 'W';
    const by = t.y + t.rows - 1, reach = Math.max(2, t.rows);
    let east = 0, west = 0;
    const open = (x) => x >= 0 && x < M.W && $gameMap.isValid(x, by) && ($gameMap.isPassable(x, by, 4) || $gameMap.isPassable(x, by, 6)) && !treeAtBase(x, by);
    for (let k = 1; k <= reach; k++) { if (open(t.x + t.cols - 1 + k)) east++; if (open(t.x - k)) west++; }
    if (east !== west) return east > west ? 'E' : 'W';
    return (TC().hash(t.key) & 1) ? 'E' : 'W';
  };
  TimberLayer.prototype.chop = function (t, d) {
    if (!this.canChop(t)) return false;
    const inst = this.lift(t), e = inst.e, C = TC();
    if (!inst.hits) { inst.dir = this.fallSide(t, d); inst.from = d; }
    inst.hits++;
    M.hits.set(t.key, { n: inst.hits, dir: inst.dir, from: inst.from }); // a return from the menu redraws this notch
    STATS.chops++;
    inst.shake = 12;
    inst.sway = e.kind === 'palm' ? 0.06 : 0.025;
    const pitch = 90 + Math.min(30, inst.hits * 8);
    if (P.chopSe) AudioManager.playSe({ name: P.chopSe, volume: 85, pitch, pan: 0 });
    const fresh = this.drawNotch(inst, inst.hits, true);
    const toward = this.playerSideVector(inst);
    this.chips(inst, fresh, toward);
    this.shed(inst);
    if (inst.hits >= inst.need) this.fell(inst);
    return true;
  };
  /** The unit vector from the tree toward the player (chips fly out of the cut toward the axe). */
  TimberLayer.prototype.playerSideVector = function (inst) {
    const d = inst.from || 6;
    return d === 6 ? { x: -1, y: 0 } : d === 4 ? { x: 1, y: 0 } : d === 8 ? { x: 0, y: 1 } : { x: 0, y: -1 };
  };
  /** Redraw the notch after chop k. @returns {Uint8Array} the pixels this chop removed (or shaded) */
  TimberLayer.prototype.drawNotch = function (inst, k, upload) {
    const e = inst.e, C = TC(), A = e.A;
    // the notch is cut on the side the axe strikes: a bark edge from the side, the face from the front or back
    const from = inst.from || (inst.dir === 'W' ? 4 : 6);
    const side = from === 6 ? 'L' : from === 4 ? 'R' : 'F';
    const nn = C.notch(A, side, Math.min(k, inst.need), inst.need);
    const fresh = new Uint8Array(e.W * e.H);
    const px = inst.trunkRGBA, W8 = e.wood;
    // the notch lives in the TRUNK layer's own pixels (a crown cell hanging low is drawn by the crown sprite)
    for (let i = 0; i < nn.cut.length; i++) {
      if (nn.cut[i] && !inst.cut[i] && px[i * 4 + 3] > 0) { fresh[i] = 1; inst.cut[i] = 1; px[i * 4 + 3] = 0; }
    }
    for (let i = 0; i < nn.shade.length; i++) {
      if (!nn.shade[i] || inst.cut[i] || px[i * 4 + 3] === 0) continue;
      // inside a side notch: the fresh wood of its cut face; across a front cut: a band of pale wood. A crystal has
      // no wood: its cut faces catch the light in the crystal's own brightest colour (LOOKED AT: a peach wood band
      // painted across an amethyst, motion.js sheet 2)
      const c = e.kind === 'crystal' ? A.crown[A.crown.length - 1] : side === 'F' ? W8.heart : C.mix(W8.heart, W8.rim, 0.25);
      if (side === 'F') fresh[i] = 1;
      px[i * 4] = c[0]; px[i * 4 + 1] = c[1]; px[i * 4 + 2] = c[2]; px[i * 4 + 3] = 255;
    }
    inst.trunkBmp.context.putImageData(new ImageData(px, e.W, e.H), 0, 0);
    inst.trunkBmp._baseTexture.update();
    if (upload) STATS.uploads++;
    return fresh;
  };

  /*
   * A burst is two halves. PREPARE is the fracture (the costly part: MEASURED _probe/event_cost.js, the crown burst at
   * impact reached 9 ms in one frame); FIRE places the pieces on the atlas and launches them. A fall prepares its
   * impact during its own frames (one job per frame, see queueJob), so the frame it lands in only fires.
   */
  TimberLayer.prototype.prepare = function (mask, src, W, H, material, seed, opts) {
    let any = false;
    for (let i = 0; i < mask.length; i++) if (mask[i]) { any = true; break; }
    if (!any) return null;
    const o = opts || {};
    const res = SC().fracture(mask, W, H, material, seed, { scale: o.scale || 1, grain: o.grain, impact: o.impact });
    return res.count ? { res, src, W, H, material, seed } : null;
  };
  /** Fracture a mask of a picture and launch it from where it sits; pieces land on groundY (map px). */
  TimberLayer.prototype.launch = function (mask, src, W, H, ox, oy, material, seed, dir, power, groundY, opts) {
    return this.fire(this.prepare(mask, src, W, H, material, seed, opts), ox, oy, dir, power, groundY, opts);
  };
  TimberLayer.prototype.fire = function (prep, ox, oy, dir, power, groundY, opts) {
    if (!prep) return 0;
    const C = SC(), X = SX(), res = prep.res, src = prep.src, W = prep.W, material = prep.material, seed = prep.seed;
    const o = opts || {};
    let places = [];
    for (const p of res.pieces) places.push(X.place(this._page, p.maxX - p.minX + 1, p.maxY - p.minY + 1, 1));
    if (places.some((q) => !q)) {
      C.clear(this._pool); X.resetPage(this._page); places = [];
      for (const p of res.pieces) places.push(X.place(this._page, p.maxX - p.minX + 1, p.maxY - p.minY + 1, 1));
      if (places.some((q) => !q)) return 0;
    }
    if (!this._pixels) this._pixels = new Uint8ClampedArray(PAGE * PAGE * 4);
    X.cutInto(src, W, 0, 0, res, W, this._pixels, PAGE, places);
    const ctx = this._atlas.context, whole = new ImageData(this._pixels, PAGE, PAGE);
    for (let k = 0; k < res.count; k++) { const p = res.pieces[k], q = places[k]; ctx.putImageData(whole, 0, 0, q.x, q.y, p.maxX - p.minX + 1, p.maxY - p.minY + 1); }
    this._atlasDirty = true; // one upload per frame however many bursts wrote to the page (update() flushes it)
    const tag = ++this._breaks, pool = this._pool;
    C.burst(pool, res, material, seed, { originX: ox, originY: oy, dirX: dir.x, dirY: dir.y, tag, power });
    let n = 0;
    for (let i = 0; i < pool.capacity; i++) {
      if (!pool.alive[i] || pool.tag[i] !== tag || pool.age[i] !== 0) continue;
      n++;
      const k = pool.piece[i], p = res.pieces[k], q = places[k], s = this._sprites[i];
      const w = p.maxX - p.minX + 1, h = p.maxY - p.minY + 1;
      s.setFrame(q.x, q.y, w, h);
      s.anchor.x = Math.floor(p.cx - p.minX) / w; s.anchor.y = Math.floor(p.cy - p.minY) / h;
      this._fx[i] = p.cx - p.minX - Math.floor(p.cx - p.minX);
      this._fy[i] = p.cy - p.minY - Math.floor(p.cy - p.minY);
      if (isFinite(groundY)) {
        // keep the piece exactly where it is drawn (y - h) and move its ground: it falls to the real ground
        const g = groundY + (o.depth ? ((i * 7) % (o.depth + 1)) : 0);
        const dy = g - pool.y[i];
        if (dy > 0) { pool.y[i] += dy; pool.h[i] += dy; if (pool.settled[i]) { pool.settled[i] = 0; } }
      }
      if (o.lying) {
        // a LYING part is already on the ground everywhere: each piece keeps where it is drawn (y - h) and stands only
        // a pixel or three above its OWN ground. Burst's single ground line (the lying picture's lowest row) put every
        // piece of a felled crown on one row - LOOKED AT 2026-10-23: the crown read as a thin green strip.
        const top = pool.y[i] - pool.h[i], hs = 1 + ((i * 5) % 3);
        pool.y[i] = top + hs; pool.h[i] = hs;
      }
    }
    return n;
  };

  TimberLayer.prototype.chips = function (inst, fresh, toward) {
    const e = inst.e;
    const seed = TC().hash(inst.t.key + ':chip:' + inst.hits);
    const mat = e.kind === 'crystal' ? 'crystal' : 'wood';
    // a front cut's chips are COPIES of the bark that was shaded; a side notch's are the very pixels it removed
    this.launch(fresh, e.rgba, e.W, e.H, inst.o.x, inst.o.y, mat, seed, toward, 0.55, inst.o.y + e.A.hinge.y, { scale: 1, depth: 6 });
  };

  /** Leaves (or needles, snow, spores) shaken loose: copies of small patches of the crown, never holes in it. */
  TimberLayer.prototype.shed = function (inst) {
    const e = inst.e, A = e.A, W = e.W, H = e.H, k = e.kind;
    if (k === 'dead' || k === 'crystal') return;
    if (k === 'mushroom') { this.spores(inst, 6, 0); return; }
    const C = TC();
    let h = C.hash(inst.t.key + ':shed:' + inst.hits);
    const mask = new Uint8Array(W * H);
    const n = k === 'conifer' ? 6 : 4, sz = k === 'conifer' ? 3 : 5;
    let placed = 0;
    for (let tries = 0; tries < 60 && placed < n; tries++) {
      h = (Math.imul(h ^ (h >>> 15), 2246822519) >>> 0);
      const x = A.bbox.minX + (h % Math.max(1, A.bbox.maxX - A.bbox.minX - sz));
      const y = A.bbox.minY + ((h >>> 16) % Math.max(1, A.trunk.top - A.bbox.minY - sz));
      if (!A.mask[(y + (sz >> 1)) * W + x + (sz >> 1)]) continue;
      for (let yy = y; yy < y + sz; yy++) for (let xx = x; xx < x + sz; xx++) if (A.mask[yy * W + xx]) mask[yy * W + xx] = 1;
      placed++;
    }
    const seed = C.hash(inst.t.key + ':leaves:' + inst.hits);
    this.launch(mask, e.rgba, W, H, inst.o.x, inst.o.y, 'foliage', seed, { x: 0, y: 0 }, 0.35, inst.o.y + A.hinge.y, { scale: 1, depth: 10 });
    if (A.features.snow >= 0.2) this.spores(inst, 8, 1);
  };

  /** Rising (spores) or falling (snow) motes in the crown's own colours. */
  TimberLayer.prototype.spores = function (inst, count, falling) {
    const e = inst.e, A = e.A;
    let h = TC().hash(inst.t.key + ':mote:' + inst.hits + ':' + count);
    for (let c = 0; c < count; c++) {
      h = (Math.imul(h ^ (h >>> 15), 2246822519) >>> 0);
      const i = this._pNext; this._pNext = (this._pNext + 1) % this._pN;
      const s = this._psprites[i];
      s.bitmap = e.bmp.spores;
      const col = h % A.crown.length;
      s.setFrame(col * 3, 0, 3, 3);
      this._px[i] = inst.o.x + A.bbox.minX + ((h >>> 8) % Math.max(1, A.bbox.maxX - A.bbox.minX));
      this._py[i] = inst.o.y + A.hinge.y;
      this._ph[i] = (A.hinge.y - A.trunk.top) + ((h >>> 20) % Math.max(1, A.trunk.top - A.bbox.minY));
      this._pvx[i] = ((h & 15) - 7.5) * 0.03;
      this._pvy[i] = 0;
      this._pvh[i] = falling ? -0.5 : 0.35 + ((h >>> 4) & 7) * 0.04;
      this._plife[i] = falling ? 90 : 120;
      this._page2[i] = 0;
      this._pkind[i] = falling ? 2 : 1;
      s.visible = true; s.opacity = 255; s.scale.x = s.scale.y = 1;
    }
  };
  /** A ring of dust where something heavy landed. */
  TimberLayer.prototype.dust = function (inst, mx, my, count, spread) {
    const e = inst.e;
    let h = TC().hash(inst.t.key + ':dust:' + mx + ':' + my);
    for (let c = 0; c < count; c++) {
      h = (Math.imul(h ^ (h >>> 15), 2246822519) >>> 0);
      const i = this._pNext; this._pNext = (this._pNext + 1) % this._pN;
      const s = this._psprites[i];
      s.bitmap = e.bmp.dust; s.setFrame(0, 0, 14, 14);
      const a = (c / count) * Math.PI * 2 + ((h & 255) / 255) * 0.6;
      this._px[i] = mx + Math.cos(a) * spread * 0.3; this._py[i] = my + Math.sin(a) * spread * 0.2;
      this._ph[i] = 2;
      this._pvx[i] = Math.cos(a) * (0.6 + ((h >>> 8) & 7) * 0.08); this._pvy[i] = Math.sin(a) * 0.35;
      this._pvh[i] = 0.25;
      this._plife[i] = 36 + ((h >>> 12) & 15);
      this._page2[i] = 0; this._pkind[i] = 3;
      s.visible = true; s.opacity = 200; s.scale.x = s.scale.y = 0.6;
    }
  };

  // ── felling ────────────────────────────────────────────────────────────────────────────────────
  TimberLayer.prototype.fell = function (inst) {
    const t = inst.t, e = inst.e, C = TC();
    // the game now sees the tree gone: its tiles leave the map data; the stump keeps the trunk cell
    setTiles(t, $dataMap.data, false);
    if (M.renderData) setTiles(t, M.renderData, false);
    t.state = 'felled';
    t.felledAt = nowSec();
    M.hits.delete(t.key);
    const s = store();
    if (s) { if (!s.maps[M.mapId]) s.maps[M.mapId] = {}; s.maps[M.mapId][t.key] = t.felledAt; }
    STATS.fells++;
    this.reward(e.kind);
    inst.phase = e.kind === 'crystal' ? 'shatter' : 'falling';
    inst.frame = 0;
    inst.table = C.fallTable(e.kind);
    // the soft edge and drawn shadow stay on the ground and fade; the tree falls as its hard silhouette
    inst.crown.bitmap = e.bmp.hardCrown;
    inst.trunk.bitmap = this.hardTrunkOf(inst);
    inst.residue = new Sprite(e.bmp.residue);
    inst.residue.anchor.x = inst.crown.anchor.x; inst.residue.anchor.y = inst.crown.anchor.y;
    inst.residue.z = 1; inst.residue._mx = inst.crown._mx; inst.residue._my = inst.crown._my;
    this._tm.addChild(inst.residue);
    this.showStump(inst);
    if (inst.phase === 'shatter') this.shatter(inst);
    else {
      this.queueImpact(inst);
      if (P.fallSe) AudioManager.playSe({ name: P.fallSe, volume: 70, pitch: e.kind === 'mushroom' ? 130 : 70, pan: 0 });
    }
  };
  /** The notched trunk without its soft pixels. */
  TimberLayer.prototype.hardTrunkOf = function (inst) {
    const e = inst.e, src = inst.trunkRGBA, out = new Uint8ClampedArray(src.length), MA = TC().MASK_ALPHA;
    for (let i = 0; i < src.length; i += 4) if (src[i + 3] >= MA) { out[i] = src[i]; out[i + 1] = src[i + 1]; out[i + 2] = src[i + 2]; out[i + 3] = src[i + 3]; }
    inst.hardTrunkRGBA = out;
    return bitmapFrom(out, e.W, e.H);
  };
  TimberLayer.prototype.reward = function (kind) {
    const item = kind === 'mushroom' ? P.mushroomItem : kind === 'crystal' ? P.crystalItem : P.yieldItem;
    if (item > 0 && $dataItems[item]) $gameParty.gainItem($dataItems[item], kind === 'mushroom' || kind === 'crystal' ? 1 : P.yieldAmount);
    if (P.yieldVariable > 0) $gameVariables.setValue(P.yieldVariable, $gameVariables.value(P.yieldVariable) + 1);
    if (P.fellCommonEvent > 0) $gameTemp.reserveCommonEvent(P.fellCommonEvent);
    this._rewardIcon = item > 0 && $dataItems[item] ? $dataItems[item].iconIndex : 0;
  };
  TimberLayer.prototype.showStump = function (inst) {
    const e = inst.e;
    if (inst.stump) return;
    const s = new Sprite(e.bmp.stump);
    s.z = 3;
    s._mx = inst.o.x + e.stumpOrigin.x; s._my = inst.o.y + e.stumpOrigin.y;
    s._sortY = inst.o.y + e.A.hinge.y; // sorts with characters at the trunk's foot
    this._tm.addChild(s);
    inst.stump = s;
  };
  /** A tree felled before this layer was built (a map load): the stump, or the sapling it has grown to. */
  TimberLayer.prototype.showFelled = function (t) {
    const e = this._sigs.get(t.sig);
    if (!e || e.state !== 'ready' || this._inst.has(t.index)) return;
    const inst = { t, e, o: this.mapOrigin(t, e), phase: 'felled', stage: -2, logs: [], crown: null, trunk: null, residue: null, stump: null, sapling: null };
    this._inst.set(t.index, inst);
    this._list.push(inst);
    this.showStump(inst);
    this.regrowCheck(inst);
  };

  /** Crystal: no fall; the whole thing above its stump shatters where it stands. */
  TimberLayer.prototype.shatter = function (inst) {
    const e = inst.e, A = e.A, W = e.W, H = e.H, C = TC();
    const cutY = A.hinge.y - C.stumpHeight(e.kind, A);
    const mask = new Uint8Array(W * H);
    const src = this.compositeHard(inst);
    for (let y = 0; y < cutY; y++) for (let x = 0; x < W; x++) if (src[(y * W + x) * 4 + 3] >= C.MASK_ALPHA) mask[y * W + x] = 1;
    const toward = this.playerSideVector(inst);
    this.launch(mask, src, W, H, inst.o.x, inst.o.y, 'crystal', C.hash(inst.t.key + ':shatter'), { x: -toward.x, y: -toward.y }, 1.1, inst.o.y + A.hinge.y, { scale: e.scale, depth: 10 });
    if (P.shatterSe) AudioManager.playSe({ name: P.shatterSe, volume: 85, pitch: 110, pan: 0 });
    inst.crown.visible = false; inst.trunk.visible = false;
    inst.phase = 'down'; inst.frame = 0;
  };
  /** The hard crown and the notched hard trunk in one picture. */
  TimberLayer.prototype.compositeHard = function (inst) {
    const e = inst.e, a = e.hardCrown, b = inst.hardTrunkRGBA || e.hardTrunk, out = new Uint8ClampedArray(a.length);
    for (let i = 0; i < a.length; i += 4) {
      const s = b[i + 3] ? b : a;
      out[i] = s[i]; out[i + 1] = s[i + 1]; out[i + 2] = s[i + 2]; out[i + 3] = s[i + 3];
    }
    return out;
  };

  /** The moment it lands. */
  TimberLayer.prototype.impact = function (inst) {
    const e = inst.e, A = e.A, C = TC(), k = e.kind;
    if (P.shake && k !== 'mushroom') $gameScreen.startShake(k === 'palm' ? 2 : 3, 9, k === 'conifer' ? 8 : 12);
    const hx = inst.o.x + A.hinge.x, hy = inst.o.y + A.hinge.y;
    const reach = (A.hinge.y - A.bbox.minY) * 0.6;
    const far = C.lyingPoint(inst.dir, 0, -reach);
    this.dust(inst, hx + far.x, hy + far.y, 8, reach);
    if (k === 'dead') {
      // a dead tree does not lie: it shatters into splinters where it lands
      this.fireLying(inst, this.takePrep(inst, 'crown'), 1.0);
      inst.crown.visible = false; inst.trunk.visible = false;
      if (P.shatterSe) AudioManager.playSe({ name: P.shatterSe, volume: 80, pitch: 80, pan: 0 });
      inst.phase = 'down';
      return;
    }
    if (k === 'mushroom') {
      this.fireLying(inst, this.takePrep(inst, 'crown'), 0.4);
      this.fireLying(inst, this.takePrep(inst, 'stem'), 0.3);
      inst.crown.visible = false; inst.trunk.visible = false;
      this.spores(inst, 14, 0);
      inst.phase = 'down';
      return;
    }
    // broadleaf, conifer, palm: the crown bursts; the trunk lies a moment, then splits into logs
    this.fireLying(inst, this.takePrep(inst, 'crown'), k === 'palm' ? 0.75 : k === 'conifer' ? 0.7 : 0.6);
    inst.crown.visible = false;
    inst.logAt = 16;
  };

  /** Queue the costly halves of a fall's impact so they run one per frame DURING the fall (see prepare). */
  TimberLayer.prototype.queueImpact = function (inst) {
    const e = inst.e, k = e.kind, self = this;
    inst.prep = {};
    // a conifer's crown breaks into a few wide boughs that slide apart (Smithereens' ice: wedges, low spin); split
    // along the wood grain, the strips tumbled in quarter turns into a tangle of sticks (LOOKED AT, motion.js 3x)
    const crownMat = k === 'dead' ? 'wood' : k === 'conifer' ? 'ice' : 'foliage';
    this.queueJob(inst, 'crown', () => self.prepLying(inst, k === 'dead' ? self.compositeHard(inst) : e.hardCrown, crownMat, 'crown'));
    if (k === 'mushroom') this.queueJob(inst, 'stem', () => self.prepLying(inst, inst.hardTrunkRGBA || e.hardTrunk, 'foliage', 'stem'));
    if (e.logs.length) this.queueJob(inst, 'split', () => self.prepSplit(inst));
  };
  TimberLayer.prototype.queueJob = function (inst, name, fn) { this._jobs.push({ inst, name, fn }); };
  /** A prepared half, or (if the fall was quicker than the queue) prepared now. */
  TimberLayer.prototype.takePrep = function (inst, name) {
    if (inst.prep && Object.prototype.hasOwnProperty.call(inst.prep, name)) return inst.prep[name];
    for (let i = 0; i < this._jobs.length; i++) {
      const j = this._jobs[i];
      if (j.inst === inst && j.name === name) { this._jobs.splice(i, 1); STATS.lateJobs = (STATS.lateJobs || 0) + 1; return j.fn(); }
    }
    return null;
  };
  /** A part fractured AS IT LIES (frame 0 of its burst is the lying sprite, exactly). */
  TimberLayer.prototype.prepLying = function (inst, rgba, material, tag) {
    const e = inst.e, C = TC(), A = e.A;
    const L = C.lyingImage(rgba, e.W, e.H, inst.dir, A.hinge);
    const mask = new Uint8Array(L.w * L.h);
    for (let i = 0; i < mask.length; i++) if (L.rgba[i * 4 + 3] >= C.MASK_ALPHA) mask[i] = 1;
    const prep = this.prepare(mask, L.rgba, L.w, L.h, material, C.hash(inst.t.key + ':' + material + ':' + tag), { scale: e.scale });
    return prep ? { prep, L } : null;
  };
  TimberLayer.prototype.fireLying = function (inst, pl, power) {
    if (!pl) return 0;
    const A = inst.e.A, hx = inst.o.x + A.hinge.x, hy = inst.o.y + A.hinge.y;
    const dir = inst.dir === 'E' ? { x: 1, y: 0 } : { x: -1, y: 0 };
    // a lying part sits ON the ground: each piece's ground is where it lies, its height a few pixels
    return this.fire(pl.prep, hx + pl.L.ox, hy + pl.L.oy, dir, power, NaN, { lying: true });
  };
  /** Splinters where the lying trunk parts into logs: copies of the trunk pixels at each cut line. */
  TimberLayer.prototype.prepSplit = function (inst) {
    const e = inst.e, A = e.A, C = TC();
    const L = C.lyingImage(inst.hardTrunkRGBA || e.hardTrunk, e.W, e.H, inst.dir, A.hinge);
    const mask = new Uint8Array(L.w * L.h);
    for (const g of e.logs) {
      const p = C.lyingPoint(inst.dir, 0, -(g.at + g.len / 2));
      const cx = Math.round(p.x - L.ox), cy = Math.round(p.y - L.oy);
      for (let y = cy - 2; y <= cy + 2; y++) for (let x = cx - 2; x <= cx + 2; x++) if (x >= 0 && y >= 0 && x < L.w && y < L.h && L.rgba[(y * L.w + x) * 4 + 3]) mask[y * L.w + x] = 1;
    }
    const prep = this.prepare(mask, L.rgba, L.w, L.h, 'wood', C.hash(inst.t.key + ':split'), {});
    return prep ? { prep, L } : null;
  };

  /** The lying trunk becomes logs. */
  TimberLayer.prototype.splitLogs = function (inst) {
    const e = inst.e, A = e.A, C = TC();
    inst.trunk.visible = false;
    const hx = inst.o.x + A.hinge.x, hy = inst.o.y + A.hinge.y;
    const vertical = false; // trees fall sideways (fallSide), so logs lie across the screen
    let h = C.hash(inst.t.key + ':logs');
    e.logs.forEach((g, i) => {
      h = (Math.imul(h ^ (h >>> 15), 2246822519) >>> 0);
      const bmp = vertical ? e.bmp.logsV[i] : e.bmp.logsH[i];
      const s = new Sprite(bmp);
      s.anchor.x = 0.5; s.anchor.y = 0.5; s.z = 1;
      const p = C.lyingPoint(inst.dir, 0, -g.at);
      const roll = ((h & 255) / 255 - 0.5) * 6;
      s._mx = hx + p.x + (vertical ? roll : 0); s._my = hy + p.y + (vertical ? 0 : roll) - (vertical ? 0 : g.thick * 0.2);
      s._rx = (vertical ? 1 : 0) * (((h >>> 8) & 1) ? 1 : -1) * 3; s._ry = (vertical ? 0 : 1) * (((h >>> 9) & 1) ? 1 : -1) * 3;
      s._t = 0;
      if (inst.dir === 'W' || inst.dir === 'N') s.scale.x = inst.dir === 'W' ? -1 : 1;
      this._tm.addChild(s);
      inst.logs.push(s);
      // a puff where the trunk parted
      if (i > 0) this.dust(inst, hx + C.lyingPoint(inst.dir, 0, -(g.at - g.len / 2)).x, hy + C.lyingPoint(inst.dir, 0, -(g.at - g.len / 2)).y, 3, 8);
    });
    // splinters from the cuts (prepared during the fall)
    const pl = this.takePrep(inst, 'split');
    if (pl) this.fire(pl.prep, hx + pl.L.ox, hy + pl.L.oy, { x: 0, y: 0 }, 0.5, NaN, { lying: true });
    inst.logLife = Math.round(P.logSeconds * 60);
  };

  TimberLayer.prototype.popLogs = function (inst) {
    const icon = this._rewardIcon;
    if (icon > 0 && inst.logs.length) {
      const set = ImageManager.loadSystem('IconSet');
      const s = new Sprite(set);
      const pw = ImageManager.iconWidth, ph = ImageManager.iconHeight;
      s.setFrame((icon % 16) * pw, Math.floor(icon / 16) * ph, pw, ph);
      s.anchor.x = 0.5; s.anchor.y = 1; s.z = 5;
      s._mx = inst.logs[0]._mx; s._my = inst.logs[0]._my; s._t = 0;
      this._tm.addChild(s);
      inst.icon = s;
    }
  };

  /** Stump, sapling stages, then the tree itself comes back. */
  TimberLayer.prototype.regrowCheck = function (inst) {
    const t = inst.t, e = inst.e, C = TC();
    if (t.state !== 'felled') return;
    const stage = C.regrowStage(nowSec() - t.felledAt, M.regrow);
    if (stage === inst.stage) return;
    inst.stage = stage;
    if (stage === 3) { this.regrow(inst); return; }
    if (stage >= 0) {
      const sp = e.bmp.saplings[stage];
      if (!inst.sapling) { inst.sapling = new Sprite(sp.bmp); inst.sapling.z = 3; this._tm.addChild(inst.sapling); }
      inst.sapling.bitmap = sp.bmp;
      inst.sapling.anchor.x = (e.A.hinge.x * sp.s) / sp.w; inst.sapling.anchor.y = (e.A.hinge.y * sp.s) / sp.h;
      inst.sapling._mx = inst.o.x + e.A.hinge.x; inst.sapling._my = inst.o.y + e.A.hinge.y - 1;
    }
  };
  TimberLayer.prototype.regrow = function (inst) {
    const t = inst.t;
    setTiles(t, $dataMap.data, true);
    if (M.renderData) setTiles(t, M.renderData, true);
    this._tm.refresh();
    t.state = 'standing';
    const s = store();
    if (s && s.maps[M.mapId]) { delete s.maps[M.mapId][t.key]; if (!Object.keys(s.maps[M.mapId]).length) delete s.maps[M.mapId]; }
    this.dropInst(inst);
    STATS.regrows++;
  };
  TimberLayer.prototype.dropInst = function (inst) {
    for (const s of [inst.crown, inst.trunk, inst.residue, inst.stump, inst.sapling, inst.icon]) if (s && s.parent) s.parent.removeChild(s);
    for (const s of inst.logs) if (s.parent) s.parent.removeChild(s);
    if (inst.trunkBmp) inst.trunkBmp.destroy();
    this._inst.delete(inst.t.index);
    const k = this._list.indexOf(inst);
    if (k >= 0) this._list.splice(k, 1);
  };

  // ── per frame ─────────────────────────────────────────────────────────────────────────────────
  TimberLayer.prototype.update = function () {
    if (this._tsId !== $gameMap.tilesetId()) this.retileset();
    if (this._warm.length) this.warmNext();
    // the swing: the blow lands mid-swing
    if (Swing.frames > 0) {
      Swing.frames--;
      if (Swing.frames === SWING - HIT_AT - 1 && Swing.pending) { const q = Swing.pending; Swing.pending = null; this.chop(q.t, q.d); }
    }
    const tw = $gameMap.tileWidth(), th = $gameMap.tileHeight();
    const dx = $gameMap.displayX() * tw, dy = $gameMap.displayY() * th;
    const tick = Graphics.frameCount % 60 === 0;
    // one prepared half per frame (a falling tree's impact, made ready during its fall)
    if (this._jobs.length) { const j = this._jobs.shift(); if (j.inst.prep) j.inst.prep[j.name] = j.fn(); }
    // an index loop over a plain array: a Map iterator here would allocate every frame (wing §3, zero allocation);
    // backwards, because a tree that grows back leaves the list during its own step
    for (let i = this._list.length - 1; i >= 0; i--) this.stepInst(this._list[i], dx, dy, tick);
    this.stepFragments(dx, dy);
    this.stepMotes(dx, dy);
    if (this._atlasDirty) { this._atlasDirty = false; this._atlas._baseTexture.update(); STATS.uploads++; }
  };
  function place(s, dx, dy) { s.x = Math.round(s._mx - dx); s.y = Math.round(s._my - dy); }
  TimberLayer.prototype.stepInst = function (inst, dx, dy, tick) {
    const C = TC(), e = inst.e;
    if (inst.phase === 'standing') {
      // a struck tree shudders: the whole tree shakes, the crown sways on its trunk
      const sh = inst.shake > 0 ? ((inst.shake & 1) ? 1 : -1) * Math.ceil(inst.shake / 5) : 0;
      if (inst.shake > 0) inst.shake--;
      const sw = inst.sway * Math.sin(inst.shake * 0.9) * (inst.shake / 12);
      place(inst.crown, dx - sh, dy); place(inst.trunk, dx - sh, dy);
      inst.crown.rotation = sw; inst.trunk.rotation = 0;
    } else if (inst.phase === 'falling') {
      const T = inst.table, f = Math.min(inst.frame, T.frames - 1);
      // a sideways fall is a turn about the hinge (TimberCore.pose for E/W, inlined: no object per frame)
      const sgn = inst.dir === 'W' ? -1 : 1;
      const drop = T.drop[f];
      inst.crown.rotation = sgn * T.crown[f];
      inst.trunk.rotation = sgn * T.trunk[f];
      inst.crown.z = 4; inst.trunk.z = 4;
      place(inst.crown, dx, dy - drop); place(inst.trunk, dx, dy - drop);
      if (inst.residue) { place(inst.residue, dx, dy); inst.residue.opacity = Math.max(0, 255 - inst.frame * 10); }
      if (f >= T.impact && !inst.impacted) { inst.impacted = true; inst.crown.z = 1; inst.trunk.z = 1; this.impact(inst); }
      inst.frame++;
      if (inst.logAt !== undefined) { inst.logAt--; if (inst.logAt <= 0 && inst.frame > T.impact) { inst.logAt = undefined; this.splitLogs(inst); inst.phase = 'down'; } }
      else if (inst.frame >= T.frames && inst.phase === 'falling') inst.phase = 'down';
    } else {
      if (inst.residue) { place(inst.residue, dx, dy); inst.residue.opacity -= 10; if (inst.residue.opacity <= 0) { inst.residue.parent.removeChild(inst.residue); inst.residue = null; } }
      if (inst.trunk && inst.trunk.visible) place(inst.trunk, dx, dy);
      if (inst.logAt !== undefined) { inst.logAt--; if (inst.logAt <= 0) { inst.logAt = undefined; this.splitLogs(inst); } }
      for (let i = 0; i < inst.logs.length; i++) {
        const s = inst.logs[i];
        // logs roll apart a few pixels and settle
        if (s._t < 14) { s._t++; const u = s._t / 14, ease = 1 - (1 - u) * (1 - u); s._ox = s._rx * ease; s._oy = s._ry * ease; }
        s.x = Math.round(s._mx + (s._ox || 0) - dx); s.y = Math.round(s._my + (s._oy || 0) - dy);
      }
      if (inst.logLife > 0) {
        inst.logLife--;
        if (inst.logLife === 30) this.popLogs(inst);
        if (inst.logLife < 30) for (let i = 0; i < inst.logs.length; i++) inst.logs[i].opacity = Math.round(255 * inst.logLife / 30);
        if (inst.logLife === 0) { for (let i = 0; i < inst.logs.length; i++) if (inst.logs[i].parent) inst.logs[i].parent.removeChild(inst.logs[i]); inst.logs.length = 0; }
      }
      if (inst.icon) { inst.icon._t++; inst.icon._my -= 0.4; place(inst.icon, dx, dy); inst.icon.opacity = Math.max(0, 255 - Math.max(0, inst.icon._t - 30) * 8); if (inst.icon.opacity <= 0) { inst.icon.parent.removeChild(inst.icon); inst.icon = null; } }
      if (inst.crown && inst.phase === 'felled') inst.crown.visible = false;
      if (tick) this.regrowCheck(inst);
    }
    if (inst.stump) { inst.stump.x = Math.round(inst.stump._mx - dx); inst.stump.y = Math.round(inst.stump._my - dy); }
    if (inst.sapling) place(inst.sapling, dx, dy);
  };
  TimberLayer.prototype.stepFragments = function (dx, dy) {
    const C = SC(), pool = this._pool;
    if (!pool.live) { for (let i = 0; i < this._sprites.length; i++) if (this._sprites[i].visible) this._sprites[i].visible = false; return; }
    C.step(pool);
    for (let i = 0; i < pool.capacity; i++) {
      const s = this._sprites[i];
      if (!pool.alive[i]) { if (s.visible) s.visible = false; continue; }
      s.visible = true;
      s.x = Math.round(pool.x[i] - this._fx[i] - dx + C.sway(pool, i));
      s.y = Math.round(pool.y[i] - pool.h[i] - this._fy[i] - dy);
      s.rotation = C.quarter(pool, i) * (Math.PI / 2);
      s.opacity = Math.round(255 * C.alpha(pool, i));
      s.z = pool.settled[i] ? 1 : 3;
    }
  };
  TimberLayer.prototype.stepMotes = function (dx, dy) {
    for (let i = 0; i < this._pN; i++) {
      const s = this._psprites[i];
      if (!s.visible) continue;
      this._page2[i]++;
      const age = this._page2[i], life = this._plife[i];
      if (age >= life) { s.visible = false; continue; }
      const kind = this._pkind[i];
      this._px[i] += this._pvx[i] + (kind === 1 ? Math.sin(age * 0.12 + i) * 0.25 : 0);
      this._py[i] += this._pvy[i];
      this._ph[i] += this._pvh[i];
      if (kind === 3) { this._pvx[i] *= 0.92; this._pvy[i] *= 0.92; s.scale.x = s.scale.y = 0.6 + 0.9 * (age / life); }
      if (this._ph[i] < 0) { this._ph[i] = 0; this._pvh[i] = 0; }
      s.x = Math.round(this._px[i] - dx); s.y = Math.round(this._py[i] - this._ph[i] - dy);
      s.opacity = Math.round((kind === 3 ? 200 : 255) * (1 - age / life));
    }
  };
  TimberLayer.prototype.clearDebris = function () { SC().clear(this._pool); SX().resetPage(this._page); };

  // ── the layer's seams ─────────────────────────────────────────────────────────────────────────
  const _Spriteset_Map_createLowerLayer = Spriteset_Map.prototype.createLowerLayer;
  Spriteset_Map.prototype.createLowerLayer = function () {
    _Spriteset_Map_createLowerLayer.call(this);
    if (this._csafTimber || !ready() || !this._tilemap) return;
    syncMap();
    this._csafTimber = new TimberLayer(this);
  };
  const _Spriteset_Map_update = Spriteset_Map.prototype.update;
  Spriteset_Map.prototype.update = function () {
    _Spriteset_Map_update.call(this);
    const L = this._csafTimber;
    if (L && L._frameSeen !== Graphics.frameCount) { L._frameSeen = Graphics.frameCount; L.update(); }
  };

  // ── commands and script ─────────────────────────────────────────────────────────────────────────
  const DIRS = { east: 6, west: 4, north: 8, south: 2 };
  function dirArg(a) { const d = DIRS[String(a || '').toLowerCase()]; return d || $gamePlayer.direction(); }
  function chopAt(x, y, d, fellNow) {
    syncMap();
    const t = treeAtBase(Number(x), Number(y));
    const L = currentLayer();
    if (!t || !L || !L.canChop(t)) return false;
    if (fellNow) { const inst = L.lift(t); if (!inst.hits) { inst.dir = L.fallSide(t, d); inst.from = d; } inst.hits = inst.need; L.drawNotch(inst, inst.need, true); L.fell(inst); return true; }
    return L.chop(t, d);
  }
  /** One chop at the tree the player faces, with the player's swing (the same path as the OK button). */
  function chopFront() {
    syncMap();
    const p = $gamePlayer, d = p.direction();
    const t = treeAtBase($gameMap.roundXWithDirection(p.x, d), $gameMap.roundYWithDirection(p.y, d));
    if (!t || t.state !== 'standing' || Swing.frames > 0) return false;
    return requestChop(t, d);
  }
  if (typeof PluginManager.registerCommand === 'function') {
    PluginManager.registerCommand(NAME, 'chopFront', function () { chopFront(); });
    PluginManager.registerCommand(NAME, 'chopAt', function (a) { chopAt(a.x, a.y, dirArg(a.direction), false); });
    PluginManager.registerCommand(NAME, 'fellAt', function (a) { chopAt(a.x, a.y, dirArg(a.direction), true); });
    PluginManager.registerCommand(NAME, 'regrowAll', function () {
      const L = currentLayer();
      for (const t of M.trees) {
        if (t.state !== 'felled') continue;
        if (L && L._inst.has(t.index)) L.regrow(L._inst.get(t.index));
        else { setTiles(t, $dataMap.data, true); t.state = 'standing'; const s = store(); if (s && s.maps[M.mapId]) delete s.maps[M.mapId][t.key]; }
      }
    });
    PluginManager.registerCommand(NAME, 'allow', function (a) { const s = store(); if (s) s.off = String(a.on) === 'false'; });
  }

  window.Timber = {
    version: '1.0.0',
    isTree(x, y) { syncMap(); const t = treeAtBase(Number(x), Number(y)); return !!(t && t.state === 'standing'); },
    felledCount() { syncMap(); let n = 0; for (const t of M.trees) if (t.state === 'felled') n++; return n; },
    trees() { syncMap(); return M.trees.map((t) => ({ key: t.key, kind: t.kind, state: t.state, x: t.x, y: t.y, cols: t.cols, rows: t.rows, base: t.baseCells.slice() })); },
    stats() { const L = currentLayer(); return Object.assign({}, STATS, { live: L ? L._pool.live : 0, pending: L ? L._warm.length : 0, instances: L ? L._inst.size : 0, swing: Swing.frames }); },
    chop(x, y, dir) { return chopAt(x, y, dir || $gamePlayer.direction(), false); },
    chopFront() { return chopFront(); },
    fell(x, y, dir) { return chopAt(x, y, dir || $gamePlayer.direction(), true); },
    kindAt(x, y) { syncMap(); const t = treeAtBase(Number(x), Number(y)); if (!t) return null; const L = currentLayer(); const e = L && L._sigs.get(t.sig); return e && e.kind ? e.kind : t.kind; },
    _layer: currentLayer,
  };
})();
