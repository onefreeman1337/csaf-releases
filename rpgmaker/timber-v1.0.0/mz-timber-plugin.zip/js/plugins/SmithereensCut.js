/*:
 * @target MZ
 * @plugindesc [CSAF] Smithereens cut: fragments cut from your own graphics. Install with Smithereens.js.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io/smithereens
 * @help SmithereensCut.js
 *
 * The pixel half of Smithereens: it reads the exact frame an event is showing,
 * turns it into an opacity mask for SmithereensCore's fracture, and copies
 * every fragment's own pixels onto a shared atlas page so all the pieces of
 * all the breaks on screen draw from one texture. It has no parameters and no
 * commands of its own. Install it beside Smithereens.js and
 * SmithereensCore.js; the order of the three files does not matter.
 *
 * Copyright (c) Core Systems Asset Factory. See LICENSE.txt.
 */
(function (root) {
  'use strict';
  const CSAF = (root.CSAF = root.CSAF || {});
  if (CSAF.SmithereensCut) return;

  /**
   * Opacity mask of one frame inside a bigger sheet (RGBA, row-major).
   * @param {Uint8Array|Uint8ClampedArray} rgba  the whole sheet
   * @param {number} sheetW
   * @param {number} sheetH
   * @param {number} fx    frame left inside the sheet
   * @param {number} fy    frame top inside the sheet
   * @param {number} fw
   * @param {number} fh
   * @param {number} [alphaMin=128]  pixels at or above this alpha are opaque
   * @returns {Uint8Array} fw * fh, 1 = opaque
   */
  function maskFromRGBA(rgba, sheetW, sheetH, fx, fy, fw, fh, alphaMin) {
    const t = Number(alphaMin);
    const th = isFinite(t) ? t : 128;
    const m = new Uint8Array(fw * fh);
    for (let y = 0; y < fh; y++) {
      const sy = fy + y;
      if (sy < 0 || sy >= sheetH) continue;
      for (let x = 0; x < fw; x++) {
        const sx = fx + x;
        if (sx < 0 || sx >= sheetW) continue;
        if (rgba[(sy * sheetW + sx) * 4 + 3] >= th) m[y * fw + x] = 1;
      }
    }
    return m;
  }

  /**
   * A shelf-packed atlas page.
   * @param {number} w
   * @param {number} h
   * @returns {{w:number,h:number,x:number,y:number,rowH:number}}
   */
  function createPage(w, h) {
    return { w: Math.floor(w), h: Math.floor(h), x: 0, y: 0, rowH: 0 };
  }

  /** Empty a page so it can be reused as a ring. */
  function resetPage(page) {
    page.x = 0;
    page.y = 0;
    page.rowH = 0;
  }

  /**
   * Reserve a w x h rect with `pad` clear pixels around it.
   * @returns {{x:number,y:number}|null} null when the page is full or the rect cannot fit at all (never clipped)
   */
  function place(page, w, h, pad) {
    const p = Math.max(0, Math.floor(Number(pad)) || 0);
    w = Math.floor(w);
    h = Math.floor(h);
    if (!(w > 0 && h > 0) || w + 2 * p > page.w || h + 2 * p > page.h) return null;
    let x = page.x + p, y = page.y + p;
    if (x + w + p > page.w) {
      page.y += page.rowH;
      page.x = 0;
      page.rowH = 0;
      x = p;
      y = page.y + p;
    }
    if (y + h + p > page.h) return null;
    page.x = x + w;
    if (h + p > page.rowH) page.rowH = h + p;
    return { x, y };
  }

  /**
   * Copy every fragment's own pixels from the source frame into its placed rect on the page. Each rect is cleared
   * first, so a reused page never shows a previous break; pixels of other fragments are never written into it.
   * @param {Uint8Array|Uint8ClampedArray} src   the whole source sheet, RGBA
   * @param {number} srcW
   * @param {number} fx     frame left in the sheet
   * @param {number} fy     frame top in the sheet
   * @param {object} res    from CSAF.SmithereensCore.fracture (labels over the frame)
   * @param {number} fw     frame width
   * @param {Uint8Array|Uint8ClampedArray} dst   the atlas page, RGBA
   * @param {number} dstW
   * @param {Array<{x:number,y:number}|null>} places  one per fragment (null = skipped)
   * @returns {number} pixels copied
   */
  function cutInto(src, srcW, fx, fy, res, fw, dst, dstW, places) {
    for (let k = 0; k < res.count; k++) {
      const p = res.pieces[k], pl = places[k];
      if (!pl) continue;
      const w = p.maxX - p.minX + 1, h = p.maxY - p.minY + 1;
      for (let y = 0; y < h; y++) {
        const row = ((pl.y + y) * dstW + pl.x) * 4;
        dst.fill(0, row, row + w * 4);
      }
    }
    let n = 0;
    const labels = res.labels;
    for (let i = 0; i < labels.length; i++) {
      const L = labels[i];
      if (L < 0) continue;
      const pl = places[L];
      if (!pl) continue;
      const p = res.pieces[L];
      const x = i % fw, y = (i / fw) | 0;
      const d = ((pl.y + y - p.minY) * dstW + pl.x + x - p.minX) * 4;
      const s = ((fy + y) * srcW + fx + x) * 4;
      dst[d] = src[s];
      dst[d + 1] = src[s + 1];
      dst[d + 2] = src[s + 2];
      dst[d + 3] = src[s + 3];
      n++;
    }
    return n;
  }

  CSAF.SmithereensCut = {
    VERSION: '0.1.0',
    maskFromRGBA,
    createPage,
    resetPage,
    place,
    cutInto,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.SmithereensCut;
})(typeof globalThis !== 'undefined' ? globalThis : this);
