/*:
 * @target MZ
 * @plugindesc [v1.0.0] Fathom - your own maps under the sea: caustic light, light shafts, swaying kelp, sea life and a dive in.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 * @orderAfter FathomCore
 * @orderAfter FathomPaint
 *
 * @param caustics
 * @text Caustic light (%)
 * @type number
 * @min 0
 * @max 300
 * @default 100
 * @desc How bright the crawling network of light on the floor is. A map's own <underwater: caustics N> multiplies this.
 *
 * @param wobble
 * @text Refraction wobble (px)
 * @type number
 * @decimals 1
 * @min 0
 * @max 6
 * @default 1.6
 * @desc How far the whole scene sways, as if seen through moving water. 0 turns it off.
 *
 * @param bubbles
 * @text Bubbles from characters
 * @type boolean
 * @default true
 * @desc The party and every event with a character image breathes out bubble chains.
 *
 * @param life
 * @text Sea life
 * @type boolean
 * @default true
 * @desc Fish schools, rays, jellyfish, eels, crabs and seahorses drawn by the plugin.
 *
 * @param motes
 * @text Drifting motes
 * @type number
 * @min 0
 * @max 150
 * @default 46
 * @desc How many specks of plankton drift through the light.
 *
 * @param slowMovement
 * @text Slower movement
 * @type number
 * @min 0
 * @max 2
 * @default 1
 * @desc Move speed steps lost under water (0 = no change). The party wades through water.
 *
 * @param airSeconds
 * @text Air (seconds)
 * @type number
 * @min 0
 * @max 3600
 * @default 0
 * @desc 0 = no air rule. Otherwise the party can stay under for this long; a column of bubbles shows what is left.
 *
 * @param airEmptyEvent
 * @text When the air runs out
 * @type common_event
 * @default 0
 * @desc Common event run once when the air runs out. None = the party loses 5% of max HP each second instead.
 *
 * @param nightFloor
 * @text Caustics at night (%)
 * @type number
 * @min 0
 * @max 100
 * @default 25
 * @desc On a screen your day/night system has made dark, the caustic light shrinks to this share.
 *
 * @command dive
 * @text Dive (transfer under water)
 * @desc A splash, the screen sinks into blue, and the party arrives on the destination map as the light falls away.
 * @arg mapId
 * @text Map
 * @type number
 * @min 1
 * @default 1
 * @arg x
 * @type number
 * @default 0
 * @arg y
 * @type number
 * @default 0
 * @arg direction
 * @type select
 * @option keep
 * @value 0
 * @option down
 * @value 2
 * @option left
 * @value 4
 * @option right
 * @value 6
 * @option up
 * @value 8
 * @default 0
 *
 * @command surface
 * @text Surface (transfer back up)
 * @desc The light rises, and the party breaks the surface on the destination map with a splash.
 * @arg mapId
 * @text Map
 * @type number
 * @min 1
 * @default 1
 * @arg x
 * @type number
 * @default 0
 * @arg y
 * @type number
 * @default 0
 * @arg direction
 * @type select
 * @option keep
 * @value 0
 * @option down
 * @value 2
 * @option left
 * @value 4
 * @option right
 * @value 6
 * @option up
 * @value 8
 * @default 0
 *
 * @command setUnderwater
 * @text Set this map underwater / dry
 * @desc Overrides this map's notetag until set again (a flooding room, a drained cistern). Kept in the save.
 * @arg mode
 * @type select
 * @option underwater
 * @option dry
 * @option notetag
 * @default underwater
 *
 * @command refillAir
 * @text Refill air
 * @desc Fills the air column (an air pocket, a potion, a shrine).
 *
 * @help Fathom.js  v1.0.0
 *
 * Turns any map into a scene seen from under the water, drawn entirely by the plugin: no images.
 *
 * INSTALL: put FathomCore.js, FathomPaint.js and Fathom.js in js/plugins and turn all three on. Any
 * order works.
 *
 * MAP NOTETAG (Map Properties > Note):
 *   <underwater>
 *   <underwater: depth 3, murk 40>
 *   <underwater: depth 1, murk 10, current 90 1.5, life 150, shafts 5, kelp off, caustics 120>
 *     depth     0-5   how deep: the reds go first, then the greens; the light falls away (default 2)
 *     murk      0-100 how much the water's own colour hangs in the scene (default 30)
 *     current   degrees speed  the way the water flows: kelp leans, motes drift, schools swim with it
 *     life      0-300 percent of the usual sea life (0 = none)
 *     shafts    0-8   light shafts slanting down from the surface (default 4; 0 at depth 5 reads as abyss)
 *     kelp      on/off  your tileset's bush tiles (grass, reeds, shrubs) sway as sea grass
 *     caustics  0-300 percent of the caustic light parameter
 *
 * WHAT IT DRAWS: a depth grade over the whole map (red absorbed first; the map's own rivers and ponds
 * sink into the water's colour), a network of caustic light
 * crawling over floors (less on walls and roofs), light shafts that waver, a refraction wobble, drifting
 * motes, bubble chains from every character on a breathing rhythm, your own bush tiles swaying in the
 * current, and generated sea life from 48 species (fish schools that part around the party, rays,
 * jellyfish, eels, crabs, seahorses). Swimmers sit above the floor in clearer water and cast soft
 * shadows on it; crabs and eels stay on the floor.
 *
 * DIVE AND SURFACE: use the Dive and Surface plugin commands instead of Transfer Player.
 *
 * COMPATIBILITY: Fathom appends ONE filter to the map's base sprite (it never replaces the list) and adds
 * its own layers (the swimming sea life has its own copy of the filter). It reads the live screen tone, so day/night plugins keep working. Patched seams, each
 * calling the original: Spriteset_Map createLowerLayer / update / destroy, Game_System initialize /
 * onAfterLoad, Game_Player realMoveSpeed, Scene_Map update.
 *
 * Copyright (c) 2026 Core Systems Asset Factory. Code written with AI assistance; every effect and
 * creature is drawn by this code at run time. See LICENSE.txt.
 */
'use strict';

(function () {
  const PLUGIN = 'Fathom';
  const RAW = PluginManager.parameters(PLUGIN);
  // ⛔ wing 16: parameters arrive as strings; '' is absent, "0" is a real zero
  const num = (v, d) => { if (v === undefined || v === null || String(v).trim() === '') return d; const n = Number(v); return Number.isFinite(n) ? n : d; };
  const bool = (v, d) => (v === undefined || v === '' ? d : String(v) === 'true');
  const P = {
    caustics: num(RAW.caustics, 100) / 100,
    wobble: num(RAW.wobble, 1.6),
    bubbles: bool(RAW.bubbles, true),
    life: bool(RAW.life, true),
    motes: Math.max(0, Math.round(num(RAW.motes, 46))),
    slowMovement: Math.max(0, num(RAW.slowMovement, 1)),
    airSeconds: Math.max(0, num(RAW.airSeconds, 0)),
    airEmptyEvent: Math.max(0, Math.round(num(RAW.airEmptyEvent, 0))),
    nightFloor: Math.max(0, Math.min(1, num(RAW.nightFloor, 25) / 100)),
  };

  /* Siblings are resolved at FIRST USE, never at load, so the Plugin Manager order is the buyer's
   * choice (wing 8, trap 2). */
  let _core = null, _paint = null;
  function deps() {
    if (!_core) {
      const C = window.CSAF || {};
      if (!C.FathomCore) throw new Error('Fathom needs FathomCore.js: put it in js/plugins and turn it on.');
      if (!C.FathomPaint) throw new Error('Fathom needs FathomPaint.js: put it in js/plugins and turn it on.');
      _core = C.FathomCore; _paint = C.FathomPaint;
    }
    return _core;
  }

  // ------------------------------------------------------------------ saved state (wing 13: runtime is non-enumerable)

  const SAVE_VERSION = 1;
  function defaultState() { return { v: SAVE_VERSION, air: 1, arrival: null, forced: {}, airEmptied: false }; }
  function state() {
    const sys = $gameSystem;
    if (!sys) return defaultState();
    let s = sys._csafFathom;
    if (!s || typeof s !== 'object') { s = defaultState(); sys._csafFathom = s; return s; }
    const d = defaultState();
    for (const k of Object.keys(d)) if (s[k] === undefined) s[k] = d[k];
    if (!s.forced || typeof s.forced !== 'object') s.forced = {};
    if (!(s.air >= 0 && s.air <= 1)) s.air = 1;
    s.v = SAVE_VERSION;
    return s;
  }
  function defineRuntimeSlot(sys) {
    if (!Object.prototype.hasOwnProperty.call(sys, '_csafFathomRuntime')) {
      Object.defineProperty(sys, '_csafFathomRuntime', { value: null, writable: true, enumerable: false, configurable: true });
    }
  }
  const _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () {
    _Game_System_initialize.apply(this, arguments);
    this._csafFathom = defaultState();
    defineRuntimeSlot(this);
  };
  const _Game_System_onAfterLoad = Game_System.prototype.onAfterLoad;
  Game_System.prototype.onAfterLoad = function () {
    if (_Game_System_onAfterLoad) _Game_System_onAfterLoad.apply(this, arguments);
    state();
    defineRuntimeSlot(this);
  };

  /** The underwater spec of the current map: the forced mode first, then the notetag; null when dry. */
  function specOfMap() {
    const C = deps();
    const s = state();
    const id = $gameMap.mapId();
    const forced = s.forced[id];
    const fromNote = C.parseNote($dataMap && $dataMap.note);
    if (forced === 'dry') return null;
    if (forced === 'underwater') return fromNote || C.parseNote('<underwater>');
    return fromNote;
  }
  /* Asked every frame by movement: cached per map id and forced mode, so the notetag is parsed once. */
  let _uwKey = null, _uwVal = false, _uwData = null;
  function isUnderwater() {
    try {
      const id = $gameMap.mapId();
      // a NUMBER, not a string: this runs every frame and must not allocate (wing 3); the map DATA
      // object is compared too, since a new map's data can arrive under the same id
      const f = state().forced[id];
      const key = id * 8 + (f === 'dry' ? 1 : f === 'underwater' ? 2 : 0) + ($dataMap ? 4 : 0);
      if (key !== _uwKey || _uwData !== $dataMap) { _uwKey = key; _uwData = $dataMap; _uwVal = !!specOfMap(); }
      return _uwVal;
    } catch (e) { return false; }
  }

  // ------------------------------------------------------------------ the filter
  // Follows MZ's own ColorFilter pattern (PIXI.Filter.call(this, null, fragment)), and the wing's measured
  // lesson from Cloudshadow (Probe_Doctrine 28a): inputSize and outputFrame are shared with PIXI's default
  // vertex shader, which compiles at highp, so they MUST be declared highp here or the program fails to
  // link with almost no message.

  function FathomFilter() { this.initialize(...arguments); }
  FathomFilter.prototype = Object.create(PIXI.Filter.prototype);
  FathomFilter.prototype.constructor = FathomFilter;
  FathomFilter.prototype.initialize = function () {
    PIXI.Filter.call(this, null, FathomFilter.FRAGMENT);
    const u = this.uniforms;
    u.uCaustic = PIXI.Texture.EMPTY;
    u.uSurface = PIXI.Texture.EMPTY;
    u.uMapOrigin = new Float32Array([0, 0]);
    u.uMapSize = new Float32Array([1, 1]);
    u.uSheetSize = new Float32Array([3, 3]);
    u.uScreenOrigin = new Float32Array([0, 0]);
    u.uTile = new Float32Array([48, 48]);
    u.uZoom = 1;
    u.uTime = 0;
    u.uMul = new Float32Array([1, 1, 1]);
    u.uFog = new Float32Array([0, 0.2, 0.3]);
    u.uFogAmt = 0;
    u.uCaustAmt = 0;
    u.uCurrent = new Float32Array([1, 0]);
    u.uWobble = 0;
    u.uSway = 0;
    u.uWaterFog = 0;
  };
  FathomFilter.FRAGMENT =
    'varying vec2 vTextureCoord;' +
    'uniform sampler2D uSampler;' +
    'uniform highp vec4 inputSize;' +
    'uniform highp vec4 outputFrame;' +
    'uniform sampler2D uCaustic;' +
    'uniform sampler2D uSurface;' +
    'uniform highp vec2 uMapOrigin;' +
    'uniform highp vec2 uMapSize;' +
    'uniform highp vec2 uSheetSize;' +
    'uniform highp vec2 uScreenOrigin;' +
    'uniform highp vec2 uTile;' +
    'uniform highp float uTime;' +
    'uniform float uZoom;' +
    'uniform vec3 uMul;' +
    'uniform vec3 uFog;' +
    'uniform float uFogAmt;' +
    'uniform float uCaustAmt;' +
    'uniform vec2 uCurrent;' +
    'uniform float uWobble;' +
    'uniform float uSway;' +
    'uniform float uWaterFog;' +
    'void main(void) {' +
    // the map tile under this pixel, from the live transform (as Game_Map.canvasToMapX does it)
    '  highp vec2 px = (vTextureCoord * inputSize.xy + outputFrame.xy - uScreenOrigin) / max(uZoom, 0.0001);' +
    '  highp vec2 tile = uMapOrigin + px / uTile;' +
    '  highp vec2 wrapped = mod(mod(tile, uMapSize) + uMapSize, uMapSize);' +
    '  vec4 surf = texture2D(uSurface, (floor(wrapped) + 1.5) / uSheetSize);' +
    // kelp: a bush tile's upper part leans with the current and sways; its foot stays planted
    '  highp vec2 f = fract(wrapped);' +
    '  float lean = surf.r * uSway * pow(1.0 - f.y, 1.6) * (0.55 * uCurrent.x + 0.45 * sin(uTime * 1.7 + tile.x * 0.9 + tile.y * 0.4));' +
    // the refraction wobble over the whole layer, in screen pixels
    '  vec2 wob = vec2(sin(uTime * 1.3 + px.y * 0.045), cos(uTime * 1.05 + px.x * 0.04)) * uWobble;' +
    '  vec2 offPx = (wob + vec2(-lean * uTile.x * 0.22, 0.0)) * uZoom;' +
    '  vec4 base = texture2D(uSampler, vTextureCoord + offPx / inputSize.xy);' +
    // caustics: two networks crawling against each other, eight tiles to a sheet (cells about a tile and
    // a third across). The first render used three tiles to a sheet and read as chicken wire.
    '  highp vec2 cuv = tile / 8.0;' +
    '  float a = texture2D(uCaustic, cuv + uTime * (vec2(0.012, 0.007) + uCurrent * 0.005)).r;' +
    '  float b = texture2D(uCaustic, cuv * 1.13 + uTime * vec2(-0.009, 0.011)).g;' +
    '  float caust = pow(max(a, b), 2.4) * 0.5 + a * b * 1.2;' +
    // broad sunlit patches drifting over the floor: the network brightens and fades by region instead of lying
    // over the whole map at one strength, which read as a net in the first in-engine look (2026-10-08)
    '  float patch = 0.5 + 0.5 * sin(tile.x * 0.37 + uTime * 0.21) * sin(tile.y * 0.29 - uTime * 0.17);' +
    // squared, so the light gathers in bright sunlit pools and thins between them (2026-10-09 independent review: at
    // 0.3 + 0.7 * patch the network still read as "a thin cracked-glass pattern laid evenly over everything")
    '  caust *= 0.12 + 1.1 * patch * patch;' +
    '  float light = caust * uCaustAmt * surf.g;' +
    // premultiplied colour: grade and fog scale with alpha; light is added only where something is drawn
    // water scatters colour out of everything before it absorbs it: a share of each pixel's saturation goes, more
    // in murkier and deeper water (2026-10-08 in-engine look: a saturated green field stayed a lawn at depth 2)
    '  float lum = dot(base.rgb, vec3(0.299, 0.587, 0.114));' +
    '  vec3 src = mix(base.rgb, vec3(lum), clamp(0.12 + uFogAmt * 0.8, 0.0, 0.6));' +
    '  vec3 graded = src * uMul + light * vec3(0.72, 0.96, 1.0) * base.a;' +
    '  graded = mix(graded, uFog * base.a, uFogAmt);' +
    // the map's own rivers and ponds, now under the sea, sink into the water colour (2026-10-09 independent review: a
    // river kept its full saturated blue and "reads as a hole in the effect"); sampled between texel centres so the
    // shoreline ramps; the swimmers' filter passes uWaterFog 0, so a fish over a river is not fogged with it
    '  float wat = texture2D(uSurface, (wrapped + 1.0) / uSheetSize).b * uWaterFog;' +
    '  float wl = dot(graded, vec3(0.299, 0.587, 0.114));' +
    '  graded = mix(graded, mix(vec3(wl), uFog * base.a * 1.15, 0.55), wat * 0.7);' +
    '  gl_FragColor = vec4(clamp(graded, 0.0, 1.0), base.a);' +
    '}';

  // ------------------------------------------------------------------ baked textures

  let _causticBitmap = null;
  /** The caustic sheet, baked once per session from FathomCore.causticSheet (wraps by construction). */
  function causticBitmap() {
    if (_causticBitmap) return _causticBitmap;
    const sheet = deps().causticSheet(128, 'fathom');
    const bmp = new Bitmap(sheet.size, sheet.size);
    const img = bmp.context.createImageData(sheet.size, sheet.size);
    img.data.set(sheet.data);
    bmp.context.putImageData(img, 0, 0);
    bmp.baseTexture.update();
    bmp.baseTexture.wrapMode = PIXI.WRAP_MODES.REPEAT;   // power-of-two: the sampler repeats it
    bmp.smooth = true;
    _causticBitmap = bmp;
    return bmp;
  }

  /**
   * One texel per tile (plus a one-tile bleed ring): R = sways (a bush tile, when kelp is on), G = how
   * much caustic light the surface catches (floors full, walls and roofs less, water tiles some).
   * Read from the engine's own tile flags and tile-id ranges, never guessed from the image.
   */
  function bakeSurface(spec) {
    const w = $gameMap.width(), h = $gameMap.height();
    const bmp = new Bitmap(w + 2, h + 2);
    const ctx = bmp.context;
    const img = ctx.createImageData(w + 2, h + 2);
    let sway = 0;
    for (let y = -1; y <= h; y++) for (let x = -1; x <= w; x++) {
      const mx = (x + w) % w, my = (y + h) % h;
      const bush = spec.kelp && $gameMap.isBush(mx, my);
      let receive = 1, water = false;
      const tiles = $gameMap.layeredTiles(mx, my);
      for (const id of tiles) {
        if (!id) continue;
        if (Tilemap.isRoofTile(id) || Tilemap.isWallSideTile(id) || Tilemap.isWallTopTile(id)) receive = Math.min(receive, 0.35);
        else if (Tilemap.isWaterTile(id)) { receive = Math.min(receive, 0.6); water = true; }
      }
      const k = ((y + 1) * (w + 2) + (x + 1)) * 4;
      img.data[k] = bush ? 255 : 0;
      img.data[k + 1] = Math.round(receive * 255);
      // B = the map's own water (a river or pond now lying under the sea): the shader sinks it into the water colour
      img.data[k + 2] = water ? 255 : 0; img.data[k + 3] = 255;
      if (bush && x >= 0 && y >= 0 && x < w && y < h) sway++;
    }
    ctx.putImageData(img, 0, 0);
    bmp.baseTexture.update();
    // linear, so the water channel ramps across a shoreline instead of stepping at the tile edge; the sway and caustic
    // channels are read at texel CENTRES (floor + 1.5) and so are unaffected by the filtering
    bmp.smooth = true;
    return { bitmap: bmp, w, h, swayTiles: sway };
  }

  // ------------------------------------------------------------------ the runtime (one per map, off the save)

  function Runtime() { this.initialize(...arguments); }
  Runtime.prototype.initialize = function (spec) {
    const C = deps();
    this.spec = spec;
    this.mapId = $gameMap.mapId();
    this.grade = C.grade(spec.depth, spec.murk);
    const deg = spec.currentDeg !== null ? spec.currentDeg : (C.hash('current:' + this.mapId) % 360);
    this.current = [Math.cos(deg * Math.PI / 180) * spec.currentSpeed, Math.sin(deg * Math.PI / 180) * spec.currentSpeed];
    this.time = (C.hash('phase:' + this.mapId) % 1000) / 10;
    this.transition = null;      // { kind, t, dest }
  };

  // ------------------------------------------------------------------ spriteset binding

  const _Spriteset_Map_createLowerLayer = Spriteset_Map.prototype.createLowerLayer;
  Spriteset_Map.prototype.createLowerLayer = function () {
    _Spriteset_Map_createLowerLayer.apply(this, arguments);
    this.createFathom();
  };

  Spriteset_Map.prototype.createFathom = function () {
    this._fathom = null;
    let spec;
    try { spec = specOfMap(); } catch (e) { console.error(e.message); return; }
    const s = state();
    // the transition overlay exists on every map: a surface arrival lands on a DRY map
    this._fathomOverlay = new PIXI.Graphics();
    this.addChild(this._fathomOverlay);
    const arrival = s.arrival;
    s.arrival = null;
    if (!spec) {
      this._fathomDry = { transition: arrival ? { kind: arrival, t: 0 } : null };
      return;
    }
    const rt = new Runtime(spec);
    if (arrival) rt.transition = { kind: arrival, t: 0 };
    /* ⛔ The slot is declared non-enumerable HERE too, not only in Game_System.initialize: a system
     * object made before this plugin loaded would otherwise get a plain property, and JsonEx would write
     * the whole runtime into the save (wing 13; found by the integration suite). */
    defineRuntimeSlot($gameSystem);
    $gameSystem._csafFathomRuntime = rt;
    const F = { rt };
    // the filter, APPENDED to the existing chain (createBaseFilters already put a ColorFilter there)
    F.filter = new FathomFilter();
    if (!Array.isArray(this._baseSprite.filters)) this._baseSprite.filters = [];
    this._baseSprite.filters.push(F.filter);
    F.surface = bakeSurface(spec);
    F.causticTex = new PIXI.Texture(causticBitmap().baseTexture);
    F.surfaceTex = new PIXI.Texture(F.surface.bitmap.baseTexture);
    // light shafts and motes over everything on the map, under the pictures and the screen effects
    F.lightLayer = new Sprite();
    this.addChildAt(F.lightLayer, this.children.indexOf(this._fathomOverlay));
    F.shafts = [];
    const shaftBmp = new Bitmap(160, Graphics.height + 120);
    _paint.shaft(shaftBmp.context, 160, Graphics.height + 120); shaftBmp.baseTexture.update();
    for (let i = 0; i < spec.shafts; i++) {
      const sp = new Sprite(shaftBmp);
      sp.blendMode = PIXI.BLEND_MODES.ADD;
      sp.anchor.x = 0.5; sp.anchor.y = 0;
      sp._seed = deps().hash('shaft:' + rt.mapId + ':' + i);
      F.lightLayer.addChild(sp); F.shafts.push(sp);
    }
    F.motes = [];
    const moteBmp = new Bitmap(6, 6); _paint.mote(moteBmp.context, 3); moteBmp.baseTexture.update();
    const mr = deps().rng(deps().hash('motes:' + rt.mapId));
    for (let i = 0; i < P.motes; i++) {
      const m = new Sprite(moteBmp);
      m.blendMode = PIXI.BLEND_MODES.ADD;
      m._u = mr(); m._v = mr(); m._z = 0.4 + mr() * 0.9;
      m.scale.x = m.scale.y = m._z;
      F.lightLayer.addChild(m); F.motes.push(m);
    }
    // bubbles live in the tilemap, so characters and roofs order with them
    // (second independent review: at r 4 the bubbles were "two stray white specks" at 2x; r 6 reads as a bubble chain)
    F.bubbleBmp = new Bitmap(14, 14); _paint.bubble(F.bubbleBmp.context, 6); F.bubbleBmp.baseTexture.update();
    F.bubbles = [];
    for (let i = 0; i < 72; i++) {
      const b = new Sprite(F.bubbleBmp);
      b.anchor.x = b.anchor.y = 0.5; b.visible = false; b.z = 7; b._life = 0;
      this._tilemap.addChild(b); F.bubbles.push(b);
    }
    F.breaths = new Map();
    // sea life
    F.life = [];
    if (P.life && spec.life > 0) this.createFathomLife(F, rt);
    // the air column
    if (P.airSeconds > 0) {
      F.air = new Sprite(new Bitmap(28, 132));
      F.air.x = 12; F.air.y = Graphics.height - 150;
      F.airDrawn = -1;
      F.lightLayer.addChild(F.air);
    }
    this._fathom = F;
  };

  /* The floor shadow a swimmer casts, per body plan: its size on the floor as a share of the creature's length
   * (x along the body, y across it; a ray seen from above is wider than it is long). */
  // (first in-engine look, 2026-10-09: at 0.9 x 0.36 and 43% a fish's shadow was a 24 x 9 px smudge nobody could find)
  const SHADOW_SHAPE = { fish: [1.05, 0.5], ray: [0.75, 1.05], jelly: [0.9, 0.5], seahorse: [0.55, 0.38] };
  const SHADOW_W = 64, SHADOW_H = 32;
  let _shadowBitmap = null;
  function shadowBitmap() {
    if (_shadowBitmap) return _shadowBitmap;
    const bmp = new Bitmap(SHADOW_W, SHADOW_H);
    _paint.shadow(bmp.context, SHADOW_W, SHADOW_H);
    bmp.baseTexture.update();
    bmp.smooth = true;
    _shadowBitmap = bmp;
    return bmp;
  }

  /**
   * One sheet per species, painted once; one sprite per creature; schools steer in tile space.
   * Creatures that live on the floor (crabs, eels) sit in the tilemap and take the floor's grade. Creatures that swim
   * ABOVE it have less water between them and the viewer, so they sit on their own layer over the map with a lighter
   * grade, and each casts a soft shadow on the floor below it (2026-10-09 in-engine look: graded with the floor at depth
   * 2 the fish took the floor's colour, and a full-screen frame showed specks, not sea life).
   */
  Spriteset_Map.prototype.createFathomLife = function (F, rt) {
    const C = deps();
    const r = C.rng(C.hash('place:' + rt.mapId));
    const w = $gameMap.width(), h = $gameMap.height();
    const groups = C.lifeFor(rt.mapId, rt.spec.depth, rt.spec.life, w * h);
    F.lifeLayer = new Sprite();
    F.lifeFilter = new FathomFilter();
    F.lifeFilter.padding = Math.ceil(P.wobble) + 2;
    F.lifeLayer.filters = [F.lifeFilter];
    F.lifeGrade = C.grade(rt.spec.depth * 0.45, rt.spec.murk * 0.45);
    this.addChildAt(F.lifeLayer, this.children.indexOf(this._baseSprite) + 1);
    const shade = shadowBitmap();
    const swimmers = [];
    for (const g of groups) {
      const sp = g.species;
      const bmp = sheetBitmap(sp);
      const n = g.count;
      const floor = sp.layer === 'floor';
      const grp = { sp, n, cell: _paint.cellSize(sp), pos: new Float32Array(n * 2), vel: new Float32Array(n * 2), sprites: [], shadows: floor ? null : [], lift: sp.layer === 'over' ? 40 : 22, heading: r() * Math.PI * 2, home: [r() * w, r() * h], phase: r() * 10 };
      for (let i = 0; i < n; i++) {
        grp.pos[i * 2] = (grp.home[0] + (r() - 0.5) * 2.5 + w) % w;
        grp.pos[i * 2 + 1] = (grp.home[1] + (r() - 0.5) * 2.5 + h) % h;
        const s = new Sprite(bmp);
        s.anchor.x = 0.5; s.anchor.y = 0.5;
        s.setFrame(0, 0, grp.cell, grp.cell);
        s.z = floor ? 1 : sp.layer === 'over' ? 9 : 5;
        s._frameOff = Math.floor(r() * 4);
        if (floor) this._tilemap.addChild(s); else swimmers.push(s);
        grp.sprites.push(s);
        if (!floor) {
          const shape = SHADOW_SHAPE[sp.plan] || SHADOW_SHAPE.fish;
          const sh = new Sprite(shade);
          sh.anchor.x = 0.5; sh.anchor.y = 0.5; sh.z = 1;
          sh.scale.x = sp.size * shape[0] / SHADOW_W; sh.scale.y = sp.size * shape[1] / SHADOW_H;
          // higher swimmers cast fainter, softer shadows
          // (second independent review: on graded grass "no shadow is distinguishable under any fish": the floor grade
          // takes the contrast out of a half-dark smudge, so the shadow is drawn near-opaque at its core)
          sh.opacity = sp.layer === 'over' ? 205 : 245;
          this._tilemap.addChild(sh);
          grp.shadows.push(sh);
        }
      }
      F.life.push(grp);
    }
    // the swimmers in draw order, once: mid-water first, then what glides over it
    swimmers.sort((a, b) => a.z - b.z);
    for (const s of swimmers) F.lifeLayer.addChild(s);
  };

  const _sheets = new Map();
  function sheetBitmap(sp) {
    let b = _sheets.get(sp.id);
    if (b) return b;
    const out = _paint.sheet(sp, (w, h) => new Bitmap(w, h));
    b = out.target;
    b.baseTexture.update();
    _sheets.set(sp.id, b);
    return b;
  }

  const _Spriteset_Map_update = Spriteset_Map.prototype.update;
  Spriteset_Map.prototype.update = function () {
    _Spriteset_Map_update.apply(this, arguments);
    this.updateFathom();
  };

  /* Per frame: uniforms, shafts, motes, bubbles, life, air, and any transition. ZERO ALLOCATION here
   * (wing 3): every array was made at creation; nothing reads a pixel (Probe_Doctrine 27a). */
  Spriteset_Map.prototype.updateFathom = function () {
    const F = this._fathom;
    const dt = 1 / 60;
    if (!F) { this.updateFathomTransition(this._fathomDry ? this._fathomDry.transition : null, null, dt); return; }
    const rt = F.rt, spec = rt.spec, C = _core;
    rt.time += dt;
    const t = rt.time;
    const u = F.filter.uniforms;
    // the night floor: read the LIVE tone, so any day/night system works
    const tone = $gameScreen.tone();
    const lum = (tone[0] + tone[1] + tone[2]) / 3;
    const daylight = Math.max(0, Math.min(1, 1 + lum / 120));
    const light = P.nightFloor + (1 - P.nightFloor) * daylight;
    // caustics weaken with depth: the surface's focusing is lost in deep water (2026-10-09 in-engine look at depth 1 on a
    // pale seabed: at 0.46 the network read as a white wire mesh over the reef, so the base strength is 0.38)
    // (third review: once the light gathered into squared pools, 0.38 left the network "barely visible" between them; 0.46)
    const caust = Math.max(0, P.caustics * (spec.caustics / 100) * (1 - spec.depth * 0.13) * light * 0.46);
    this.updateFathomUniforms(u, F, rt, rt.grade, caust, spec.kelp ? 1 : 0, t);
    u.uWaterFog = 1;
    // the swimmers' layer: the same filter by the same code path, a lighter grade, no caustics, no sway, no water fog
    if (F.lifeFilter) { this.updateFathomUniforms(F.lifeFilter.uniforms, F, rt, F.lifeGrade, 0, 0, t); F.lifeFilter.uniforms.uWaterFog = 0; }

    // shafts: slanting from the top edge, anchored to the map so they slide past as the camera moves
    const W = Graphics.width, H = Graphics.height;
    const scrollX = $gameMap.displayX() * $gameMap.tileWidth();
    for (let i = 0; i < F.shafts.length; i++) {
      const s = F.shafts[i];
      const seed = s._seed;
      const span = W + 240;
      const base = (seed % 1000) / 1000 * span - scrollX * 0.35;
      s.x = ((base % span) + span) % span - 120;
      s.y = -40;
      s.rotation = 0.22 + Math.sin(t * 0.35 + (seed % 97)) * 0.05;
      s.scale.x = 0.6 + ((seed >>> 10) % 100) / 100 * 0.9;
      // (third review: with the softer painter, 110 +- 45 left "at most one faint shaft" visible at depth 2)
      s.opacity = (165 + Math.sin(t * (0.6 + (seed % 7) * 0.05) + seed) * 55) * light * (1 - spec.depth * 0.12);
    }
    // motes drift with the current, wrapping on the screen with a parallax off the camera
    const scrollY = $gameMap.displayY() * $gameMap.tileHeight();
    for (let i = 0; i < F.motes.length; i++) {
      const m = F.motes[i];
      m._u += (rt.current[0] * 0.0009 + Math.sin(t + i) * 0.0003) * m._z;
      m._v += (rt.current[1] * 0.0009 - 0.0002) * m._z;
      const x = m._u * W - scrollX * 0.5 * m._z, y = m._v * H - scrollY * 0.5 * m._z;
      m.x = ((x % W) + W) % W; m.y = ((y % H) + H) % H;
      m.opacity = 120 + Math.sin(t * 2 + i) * 60;
    }
    if (P.bubbles) this.updateFathomBubbles(F, t, dt);
    for (let k = 0; k < F.life.length; k++) this.updateFathomGroup(F.life[k], rt, t, dt);
    if (F.air) this.updateFathomAir(F, dt);
    this.updateFathomTransition(rt.transition, rt, dt);
  };

  /* Every uniform of one FathomFilter from the live map and camera: the map's filter and the swimmers' filter both
   * go through here, so the two can only differ in the grade, caustic amount and sway they are handed. */
  Spriteset_Map.prototype.updateFathomUniforms = function (u, F, rt, grade, caust, sway, t) {
    u.uCaustic = F.causticTex; u.uSurface = F.surfaceTex;
    u.uMapOrigin[0] = $gameMap.displayX(); u.uMapOrigin[1] = $gameMap.displayY();
    u.uMapSize[0] = F.surface.w; u.uMapSize[1] = F.surface.h;
    u.uSheetSize[0] = F.surface.w + 2; u.uSheetSize[1] = F.surface.h + 2;
    u.uTile[0] = $gameMap.tileWidth(); u.uTile[1] = $gameMap.tileHeight();
    u.uScreenOrigin[0] = this.x; u.uScreenOrigin[1] = this.y;
    u.uZoom = this.scale.x || 1;
    u.uTime = t;
    u.uMul[0] = grade.mul[0]; u.uMul[1] = grade.mul[1]; u.uMul[2] = grade.mul[2];
    u.uFog[0] = grade.fog[0]; u.uFog[1] = grade.fog[1]; u.uFog[2] = grade.fog[2];
    u.uFogAmt = grade.fogAmt;
    u.uCaustAmt = caust;
    u.uCurrent[0] = rt.current[0]; u.uCurrent[1] = rt.current[1];
    u.uWobble = P.wobble;
    u.uSway = sway;
  };

  Spriteset_Map.prototype.updateFathomBubbles = function (F, t, dt) {
    const C = _core;
    const tw = $gameMap.tileWidth();
    // every character with an image breathes (the party, followers, events)
    const chars = this._characterSprites;
    for (let i = 0; i < chars.length; i++) {
      const cs = chars[i], ch = cs._character;
      if (!ch || !cs.visible || !ch.characterName || !ch.characterName() || ch.isTransparent && ch.isTransparent()) continue;
      let br = F.breaths.get(ch);
      if (!br) { br = C.breath(i + ':' + (ch.eventId ? ch.eventId() : 'p')); br.next = br.offset; br.left = 0; F.breaths.set(ch, br); }
      br.next -= dt;
      if (br.next <= 0) { br.left = br.count; br.next = br.period; br.gap = 0; }
      if (br.left > 0) {
        br.gap -= dt;
        if (br.gap <= 0) {
          br.gap = 0.12; br.left--;
          for (let k = 0; k < F.bubbles.length; k++) {
            const b = F.bubbles[k];
            if (b._life > 0) continue;
            // released ABOVE the head and small, growing as they rise (third independent review: released at 0.8 of a
            // tile at full size, the chain sat over the face and read as "a fishbowl helmet or a rendering bug")
            b._life = 1.4; b._x = cs.x + (ch.direction() === 4 ? -8 : ch.direction() === 6 ? 8 : 3); b._y = cs.y - tw * 1.08; b._seed = k;
            b._s = 0.45 + (k % 3) * 0.15;
            b.visible = true; b.scale.x = b.scale.y = b._s;
            break;
          }
        }
      }
    }
    for (let k = 0; k < F.bubbles.length; k++) {
      const b = F.bubbles[k];
      if (b._life <= 0) { if (b.visible) b.visible = false; continue; }
      b._life -= dt;
      b._y -= 38 * dt;
      b.x = b._x + Math.sin(t * 5 + b._seed) * 2.5;
      b.y = b._y;
      b.scale.x = b.scale.y = b._s * (1.6 - b._life * 0.43);   // a bubble swells as it rises (pressure falls)
      b.opacity = Math.min(255, b._life * 300);
    }
  };

  /** One group of creatures: schools steer by FathomCore.stepSchool; jellies bob; rays glide; crabs hop. */
  Spriteset_Map.prototype.updateFathomGroup = function (g, rt, t, dt) {
    const C = _core;
    const w = $gameMap.width(), h = $gameMap.height();
    const tw = $gameMap.tileWidth(), th = $gameMap.tileHeight();
    const sp = g.sp;
    g.phase += dt;
    if (sp.plan === 'jelly') g.heading = Math.atan2(rt.current[1] - 0.4, rt.current[0] || 0.0001);
    else g.heading += Math.sin(g.phase * 0.21 + sp.id) * dt * 0.35;
    const o = _schoolOpts;
    o.heading = g.heading; o.speed = sp.speed * (sp.plan === 'crab' ? 0.4 : 1);
    o.avoidX = $gamePlayer._realX + 0.5; o.avoidY = $gamePlayer._realY + 0.5; o.avoidR = sp.plan === 'fish' ? 2.6 : 1.4;
    o.dt = dt; o.phase = g.phase; o.w = w; o.h = h;
    // the room each creature keeps from its schoolmates: a little more than its own length, in tiles
    o.sep = g.n > 1 ? sp.size * 1.15 / tw : 0;
    C.stepSchool(g.pos, g.vel, g.n, o);
    const frameRate = sp.plan === 'jelly' ? 3 : sp.plan === 'crab' ? 5 : 8;
    for (let i = 0; i < g.n; i++) {
      const s = g.sprites[i];
      const x = g.pos[i * 2], y = g.pos[i * 2 + 1];
      const sx = Math.round($gameMap.adjustX(x) * tw), sy = Math.round($gameMap.adjustY(y) * th);
      const bob = sp.plan === 'jelly' ? Math.sin(t * 1.2 + i) * 6 : sp.plan === 'ray' ? Math.sin(t * 0.7 + i) * 3 : 0;
      s.x = sx; s.y = sy + bob;
      const f = (Math.floor(t * frameRate) + s._frameOff) % 4;
      s.setFrame(f * g.cell, 0, g.cell, g.cell);
      if (sp.plan !== 'jelly' && sp.plan !== 'crab') s.scale.x = g.vel[i * 2] < 0 ? -1 : 1;
      if (sp.plan === 'ray') s.rotation = Math.atan2(g.vel[i * 2 + 1], Math.abs(g.vel[i * 2]) + 0.0001) * 0.6;
      if (g.shadows) {
        // the light comes from above and a little to the left (the shafts lean the same way): the shadow falls below
        // and to the right, further for what swims higher
        const sh = g.shadows[i];
        sh.x = sx + g.lift * 0.4; sh.y = sy + g.lift;
        sh.rotation = s.scale.x < 0 ? -s.rotation : s.rotation;
      }
    }
  };
  const _schoolOpts = { heading: 0, speed: 1, avoidX: 0, avoidY: 0, avoidR: 2, dt: 1 / 60, phase: 0, w: 0, h: 0, sep: 0 };

  Spriteset_Map.prototype.updateFathomAir = function (F, dt) {
    const s = state();
    const ev = _core.stepAir(s, dt, true, P.airSeconds);
    if (ev === 'empty') {
      s.airEmptied = true;
      if (P.airEmptyEvent > 0) $gameTemp.reserveCommonEvent(P.airEmptyEvent);
    }
    if (s.air === 0 && P.airEmptyEvent === 0) {
      // no event chosen: the party loses 5% of max HP each second, never below 1
      F.airTick = (F.airTick || 0) + dt;
      if (F.airTick >= 1) { F.airTick = 0; for (const a of $gameParty.aliveMembers()) a.setHp(Math.max(1, a.hp - Math.ceil(a.mhp * 0.05))); }
    }
    // the column: redrawn only when its shown level changes (30 steps), never every frame
    const level = Math.round(s.air * 30);
    if (level === F.airDrawn) return;
    F.airDrawn = level;
    const b = F.air.bitmap;
    b.clear();
    const ctx = b.context;
    ctx.fillStyle = 'rgba(8,30,44,0.55)'; ctx.fillRect(6, 4, 16, 124);
    ctx.strokeStyle = 'rgba(200,240,255,0.7)'; ctx.lineWidth = 1.5; ctx.strokeRect(6.5, 4.5, 15, 123);
    const n = 10;
    for (let i = 0; i < n; i++) {
      const filled = level / 30 > i / n;
      const y = 120 - i * 12, x = 14 + (i % 2 ? 2 : -2);
      ctx.beginPath(); ctx.arc(x, y, 4.5, 0, Math.PI * 2);
      ctx.fillStyle = filled ? (level <= 7 ? 'rgba(255,170,150,0.85)' : 'rgba(210,245,255,0.85)') : 'rgba(210,245,255,0.12)';
      ctx.fill();
    }
    b.baseTexture.update();
  };

  /* The dive and surface overlays. Drawn into a PIXI.Graphics only while a transition runs. */
  Spriteset_Map.prototype.updateFathomTransition = function (tr, rt, dt) {
    const gfx = this._fathomOverlay;
    if (!gfx) return;
    if (!tr) { if (gfx._drawn) { gfx.clear(); gfx._drawn = false; } return; }
    const C = deps();
    tr.t += dt;
    const fr = C.diveFrame(tr.kind, tr.t);
    gfx.clear(); gfx._drawn = true;
    const W = Graphics.width, H = Graphics.height;
    const blue = rt ? Math.round(rt.grade.fog[2] * 255) : 90;
    if (fr.cover > 0) {
      // (third review: the dark navy 0x0a2a5a at partial cover over green read as "a grey-olive dim", not a sink into blue:
      // the sink and the arrival now use a clear sea blue, deepened by the destination's own water colour when known)
      const col = fr.tint === 'white' ? 0xeaf8ff : (0x14 << 16) | (0x5a << 8) | Math.min(200, Math.max(150, blue + 70));
      gfx.beginFill(col, Math.min(1, fr.cover)); gfx.drawRect(0, 0, W, H); gfx.endFill();
    }
    if (fr.ring > 0 && fr.ring < 1) {
      // a plain loop, not .find(closure): this runs every frame of a transition (wing 3: zero allocation per frame)
      let pl = null;
      for (let i = 0; i < this._characterSprites.length; i++) if (this._characterSprites[i]._character === $gamePlayer) { pl = this._characterSprites[i]; break; }
      const cx = pl ? pl.x : W / 2, cy = pl ? pl.y - 8 : H / 2;
      // the water breaking: a white burst, two rings running out, and a crown of droplets thrown up and falling back
      // (2026-10-09 independent review: one thin ellipse "looks like a selection ring, with no spray or droplets")
      const p = fr.ring, a = 1 - p;
      // in WATER colours (second review: plain white circles "read as popcorn or cotton, not water"): a pale blue-green
      // burst, foam-white rings over a darker water ring, drops with a blue rim and a white highlight
      if (p < 0.4) { gfx.beginFill(0x9fdcec, (0.4 - p) / 0.4 * 0.6); gfx.drawEllipse(cx, cy, 18 + p * 50, 10 + p * 24); gfx.endFill(); }
      gfx.lineStyle(Math.max(1, 9 * a), 0x3f8fb0, a * 0.55);
      gfx.drawEllipse(cx, cy, 24 + p * 70, 10 + p * 26);
      gfx.lineStyle(Math.max(1, 5 * a), 0xeefcff, a);
      gfx.drawEllipse(cx, cy, 22 + p * 70, 9 + p * 26);
      gfx.lineStyle(Math.max(1, 3 * a), 0xd8f4ff, a * 0.8);
      gfx.drawEllipse(cx, cy, 10 + p * 38, 4 + p * 14);
      gfx.lineStyle(0);
      // (first in-engine look: 14 drops of at most 4.4 px read as dust at frame size; 18 larger drops, thrown higher,
      // fading by the square root so they stay readable until they fall)
      const da = Math.sqrt(a);
      for (let i = 0; i < 18; i++) {
        const ang = -Math.PI * (0.05 + 0.9 * i / 17);
        const reach = (14 + 56 * p) * (0.7 + 0.3 * ((i * 7) % 5) / 4);
        const lift = Math.sin(p * Math.PI) * (30 + (i % 4) * 12);
        const dx = cx + Math.cos(ang) * reach, dy = cy + Math.sin(ang) * reach * 0.5 - lift, dr = Math.max(1.6, 6 * da);
        gfx.lineStyle(Math.max(1, dr * 0.35), 0x3f8fb0, da * 0.8);
        gfx.beginFill(0xbfe9f5, da);
        gfx.drawCircle(dx, dy, dr);
        gfx.endFill();
        gfx.lineStyle(0);
        gfx.beginFill(0xffffff, da);
        gfx.drawCircle(dx - dr * 0.3, dy - dr * 0.3, dr * 0.35);
        gfx.endFill();
      }
    }
    if (fr.phase === 'transfer' && tr.dest && !tr.sent) {
      tr.sent = true;
      state().arrival = tr.kind === 'dive' ? 'arriveDive' : 'arriveSurface';
      $gamePlayer.reserveTransfer(tr.dest.mapId, tr.dest.x, tr.dest.y, tr.dest.d, 2);
    }
    // an arrival ends when its cover has cleared (the splash ring of a surfacing finishes well before)
    if (fr.phase === 'arrive' && fr.cover <= 0) {
      if (rt) rt.transition = null; else if (this._fathomDry) this._fathomDry.transition = null;
    }
  };

  const _Spriteset_Map_destroy = Spriteset_Map.prototype.destroy;
  Spriteset_Map.prototype.destroy = function (options) {
    const F = this._fathom;
    if (F) {
      // the textures wrap shared baked bitmaps: destroyed WITHOUT their base; the surface is this map's own
      if (F.causticTex) F.causticTex.destroy(false);
      if (F.surfaceTex) F.surfaceTex.destroy(false);
      if (F.surface && F.surface.bitmap) F.surface.bitmap.destroy();
      if (F.air && F.air.bitmap) F.air.bitmap.destroy();
      this._fathom = null;
    }
    if (_Spriteset_Map_destroy) _Spriteset_Map_destroy.apply(this, arguments);
  };

  // ------------------------------------------------------------------ the rules

  /* Slower movement: the party wades. Followers read $gamePlayer.realMoveSpeed, so they follow. */
  const _Game_Player_realMoveSpeed = Game_Player.prototype.realMoveSpeed;
  Game_Player.prototype.realMoveSpeed = function () {
    const v = _Game_Player_realMoveSpeed.apply(this, arguments);
    return P.slowMovement > 0 && isUnderwater() ? Math.max(1, v - P.slowMovement) : v;
  };

  /* Above water the air refills (the spriteset only runs the meter on an underwater map). */
  const _Scene_Map_update = Scene_Map.prototype.update;
  Scene_Map.prototype.update = function () {
    _Scene_Map_update.apply(this, arguments);
    if (P.airSeconds > 0 && !isUnderwater()) { const s = state(); deps().stepAir(s, 1 / 60, false, P.airSeconds); s.airEmptied = false; }
  };

  // ------------------------------------------------------------------ plugin commands

  function startTransition(kind, args) {
    const sc = SceneManager._scene;
    const sp = sc && sc._spriteset;
    const dest = { mapId: Math.max(1, Math.round(num(args.mapId, 1))), x: Math.round(num(args.x, 0)), y: Math.round(num(args.y, 0)), d: Math.round(num(args.direction, 0)) };
    const tr = { kind, t: 0, dest, sent: false };
    if (sp && sp._fathom) sp._fathom.rt.transition = tr;
    else if (sp) { sp._fathomDry = sp._fathomDry || {}; sp._fathomDry.transition = tr; }
    else { $gamePlayer.reserveTransfer(dest.mapId, dest.x, dest.y, dest.d, 0); return 0; }
    return Math.ceil(deps().DIVE.transferAt * 60) + 2;
  }
  PluginManager.registerCommand(PLUGIN, 'dive', function (args) { this.wait(startTransition('dive', args)); });
  PluginManager.registerCommand(PLUGIN, 'surface', function (args) { this.wait(startTransition('surface', args)); });
  PluginManager.registerCommand(PLUGIN, 'setUnderwater', function (args) {
    const s = state(), id = $gameMap.mapId(), mode = String(args.mode || 'underwater');
    if (mode === 'notetag') delete s.forced[id]; else s.forced[id] = mode === 'dry' ? 'dry' : 'underwater';
    // the scene is rebuilt so the change shows at once (the same as a map refresh after a transfer)
    if (SceneManager._scene instanceof Scene_Map && SceneManager._scene._spriteset) {
      const sc = SceneManager._scene;
      sc.removeChild(sc._spriteset); sc._spriteset.destroy();
      sc.createSpriteset();
      if (sc._windowLayer) { sc.removeChild(sc._windowLayer); sc.addChild(sc._windowLayer); }
    }
  });
  PluginManager.registerCommand(PLUGIN, 'refillAir', function () { const s = state(); s.air = 1; s.airEmptied = false; });

  // exposed for probes and the capture prelude; not part of the buyer-facing surface
  window.CSAF = window.CSAF || {};
  window.CSAF.Fathom = { VERSION: '1.0.0', P, FathomFilter, causticBitmap, bakeSurface, specOfMap, isUnderwater, state, Runtime, deps };
})();
