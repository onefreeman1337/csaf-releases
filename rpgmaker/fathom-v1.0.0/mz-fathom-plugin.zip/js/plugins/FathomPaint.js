/*:
 * @target MZ
 * @plugindesc [v1.0.0] Fathom Paint - draws every sea creature, bubble and light shaft in code. Required by Fathom.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help FathomPaint.js
 *
 * The drawing half of Fathom: no images ship. Each species from FathomCore is drawn from its parts
 * (body plan, body, tail, pattern, palette) into frames of a small sheet, once, when a map first
 * needs it. Works on any 2D canvas context, so the same code paints the in-game sheets and the
 * proof sheets. No parameters and no commands.
 *
 * Copyright (c) 2026 Core Systems Asset Factory. Code written with AI assistance.
 */
'use strict';

(function (root) {
  const FRAMES = 4;

  function core() {
    const c = root.CSAF && root.CSAF.FathomCore;
    if (!c) throw new Error('FathomPaint needs FathomCore.js: put it in js/plugins and turn it on.');
    return c;
  }

  /* The cell a species is painted into: a little larger than its length so fins and arms fit. */
  function cellSize(sp) { return Math.ceil(sp.size * (sp.plan === 'eel' ? 1.25 : sp.plan === 'jelly' ? 1.1 : 1.5)) + 8; }

  function withPath(ctx, fn) { ctx.beginPath(); fn(); ctx.closePath(); }

  /* Fill a closed body path with its pattern: the pattern is clipped to the body so nothing spills. */
  function patterned(ctx, sp, pathFn, L, H) {
    ctx.save();
    pathFn(); ctx.fillStyle = sp.base; ctx.fill();
    ctx.clip();
    ctx.fillStyle = sp.dark;
    switch (sp.pattern) {
      case 'stripes': for (let i = -3; i <= 3; i++) ctx.fillRect(i * L * 0.16 - L * 0.03, -H, L * 0.06, H * 2); break;
      case 'bands': for (let i = -1; i <= 1; i++) ctx.fillRect(i * L * 0.3 - L * 0.07, -H, L * 0.14, H * 2); break;
      case 'spots': for (let i = 0; i < 9; i++) { const a = i * 2.39996, rr = Math.sqrt(i / 9); ctx.beginPath(); ctx.arc(Math.cos(a) * rr * L * 0.38, Math.sin(a) * rr * H * 0.7, Math.max(0.8, H * 0.12), 0, Math.PI * 2); ctx.fill(); } break;
      // a rounded patch: the rectangle of v1 read as a box stuck on the body
      case 'saddle': ctx.beginPath(); ctx.ellipse(-L * 0.02, -H * 0.55, L * 0.2, H * 0.6, 0, 0, Math.PI * 2); ctx.fill(); break;
      case 'gradient': { const g = ctx.createLinearGradient(0, -H, 0, H); g.addColorStop(0, sp.dark); g.addColorStop(1, sp.base); ctx.fillStyle = g; ctx.fillRect(-L, -H, L * 2, H * 2); break; }
      default: break;
    }
    // every body gets a pale belly and a darker back, so it reads lit from above
    const sh = ctx.createLinearGradient(0, -H, 0, H);
    sh.addColorStop(0, 'rgba(0,0,0,0.22)'); sh.addColorStop(0.55, 'rgba(0,0,0,0)'); sh.addColorStop(1, 'rgba(255,255,255,0.28)');
    ctx.fillStyle = sh; ctx.fillRect(-L, -H, L * 2, H * 2);
    ctx.restore();
    ctx.save(); pathFn(); ctx.strokeStyle = 'rgba(10,20,30,0.75)'; ctx.lineWidth = Math.max(1, L * 0.035); ctx.stroke(); ctx.restore();
  }

  function eye(ctx, x, y, r) {
    ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#10151c'; ctx.beginPath(); ctx.arc(x + r * 0.25, y, r * 0.6, 0, Math.PI * 2); ctx.fill();
  }

  // ------------------------------------------------------------------ the plans

  function fish(ctx, sp, f) {
    const L = sp.size, beat = Math.sin(f / FRAMES * Math.PI * 2);
    const H = { torpedo: 0.22, deep: 0.42, round: 0.36, long: 0.15, arrow: 0.24 }[sp.body] * L;
    const nose = sp.body === 'arrow' ? 0.62 : 0.5;
    const body = () => withPath(ctx, () => {
      ctx.moveTo(L * nose, 0);
      ctx.bezierCurveTo(L * 0.3, -H * 1.15, -L * 0.25, -H * 1.05, -L * 0.42, -H * 0.15);
      ctx.lineTo(-L * 0.42, H * 0.15);
      ctx.bezierCurveTo(-L * 0.25, H * 1.05, L * 0.3, H * 1.15, L * nose, 0);
    });
    // the tail, swung by the beat
    ctx.save();
    ctx.translate(-L * 0.4, 0);
    ctx.rotate(beat * 0.35);
    ctx.fillStyle = sp.accent; ctx.strokeStyle = 'rgba(10,20,30,0.7)'; ctx.lineWidth = Math.max(1, L * 0.03);
    const T = L * 0.32, th = Math.max(H * 0.9, L * 0.16);
    ctx.beginPath();
    if (sp.tail === 'fork') { ctx.moveTo(0, 0); ctx.lineTo(-T, -th); ctx.lineTo(-T * 0.55, 0); ctx.lineTo(-T, th); }
    else if (sp.tail === 'fan') { ctx.moveTo(0, 0); ctx.lineTo(-T, -th); ctx.quadraticCurveTo(-T * 1.25, 0, -T, th); }
    else if (sp.tail === 'lunate') { ctx.moveTo(0, 0); ctx.lineTo(-T, -th * 1.2); ctx.quadraticCurveTo(-T * 0.5, 0, -T, th * 1.2); }
    else if (sp.tail === 'round') { ctx.moveTo(0, 0); ctx.arc(-T * 0.55, 0, T * 0.55, -Math.PI * 0.7, Math.PI * 0.7, true); }
    else { ctx.moveTo(0, -th * 0.2); ctx.quadraticCurveTo(-T * 1.2, -th * 0.8, -T * 1.8, beat * th * 0.4); ctx.quadraticCurveTo(-T * 1.2, th * 0.8, 0, th * 0.2); }
    ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.restore();
    if (sp.dorsal) {
      ctx.fillStyle = sp.accent;
      ctx.beginPath(); ctx.moveTo(L * 0.18, -H * 0.85); ctx.quadraticCurveTo(-L * 0.02, -H * 1.9, -L * 0.22, -H * 0.8); ctx.closePath(); ctx.fill();
    }
    patterned(ctx, sp, body, L, H);
    // a pectoral fin, beating against the tail
    ctx.fillStyle = sp.accent; ctx.globalAlpha = 0.85;
    ctx.beginPath(); ctx.moveTo(L * 0.18, H * 0.25); ctx.lineTo(L * 0.02, H * (0.7 + beat * 0.25)); ctx.lineTo(L * 0.1, H * 0.2); ctx.closePath(); ctx.fill();
    ctx.globalAlpha = 1;
    eye(ctx, L * (nose - 0.16), -H * 0.18, Math.max(1.2, L * 0.055));
  }

  function ray(ctx, sp, f) {
    const L = sp.size, flap = Math.sin(f / FRAMES * Math.PI * 2);
    const W = L * 0.5 * (0.82 + flap * 0.18);   // wingspan breathes with the flap (seen from above)
    /* v1 used concave curves and the diamond rays read as four-pointed STARS on the contact sheet, and
     * the round one as an egg. A ray seen from above is a broad CONVEX wing: the leading edge bows
     * forward to the tip, the trailing edge sweeps back to the tail. 'round' is the same with rounder tips. */
    /* v3 (third independent review: the convex trailing edge closed each side into a half-disc, so a ray read as "a D
     * shape on one side of the tail, a fan or a shell, a spotted bean"). A manta from above is a swept wing: the leading
     * edge runs from the head out and BACK to a pointed tip, the trailing edge comes back in CONCAVE to the tail root, and
     * two small head lobes stand forward of the leading edge. 'round' keeps fuller, blunter tips. */
    const tipX = sp.body === 'diamond' ? -L * 0.12 : -L * 0.06;
    const lead = sp.body === 'diamond' ? 0.7 : 0.95;
    const body = () => withPath(ctx, () => {
      ctx.moveTo(L * 0.3, -W * 0.12);
      ctx.quadraticCurveTo(L * 0.22, -W * lead, tipX, -W);
      ctx.quadraticCurveTo(-L * 0.02, -W * 0.32, -L * 0.22, 0);
      ctx.quadraticCurveTo(-L * 0.02, W * 0.32, tipX, W);
      ctx.quadraticCurveTo(L * 0.22, W * lead, L * 0.3, W * 0.12);
      ctx.quadraticCurveTo(L * 0.34, 0, L * 0.3, -W * 0.12);
    });
    // the head lobes (cephalic fins), drawn first so the body's outline sits over their roots
    ctx.fillStyle = sp.dark;
    for (const side of [-1, 1]) { ctx.beginPath(); ctx.ellipse(L * 0.34, side * W * 0.1, L * 0.06, W * 0.045, side * 0.35, 0, Math.PI * 2); ctx.fill(); }
    // the whip tail
    ctx.strokeStyle = sp.dark; ctx.lineWidth = Math.max(1, L * 0.03); ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(-L * 0.25, 0); ctx.quadraticCurveTo(-L * 0.5, flap * L * 0.06, -L * 0.75, -flap * L * 0.04); ctx.stroke();
    patterned(ctx, sp, body, L * 0.6, W);
    eye(ctx, L * 0.18, -W * 0.18, Math.max(1, L * 0.025)); eye(ctx, L * 0.18, W * 0.18, Math.max(1, L * 0.025));
  }

  function jelly(ctx, sp, f) {
    const L = sp.size, pulse = Math.sin(f / FRAMES * Math.PI * 2);
    const bw = L * 0.42 * (1 + pulse * 0.08), bh = L * (sp.body === 'flat' ? 0.22 : sp.body === 'bell' ? 0.42 : 0.32) * (1 - pulse * 0.08);
    // trailing arms first, so the bell sits over them
    ctx.strokeStyle = sp.dark; ctx.globalAlpha = 0.75; ctx.lineWidth = Math.max(1, L * 0.035);
    const arms = sp.body === 'bell' ? 3 : 5;
    for (let i = 0; i < arms; i++) {
      const x0 = -bw * 0.7 + (i / (arms - 1)) * bw * 1.4;
      ctx.beginPath(); ctx.moveTo(x0, 0);
      for (let k = 1; k <= 4; k++) ctx.lineTo(x0 + Math.sin(k * 1.3 + f * 1.6 + i) * L * 0.07, k * L * 0.13 * (1 - pulse * 0.1));
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
    const bell = () => withPath(ctx, () => {
      ctx.moveTo(-bw, 0);
      if (sp.body === 'bell') { ctx.bezierCurveTo(-bw, -bh * 1.6, bw, -bh * 1.6, bw, 0); }
      else ctx.quadraticCurveTo(0, -bh * 2, bw, 0);
      ctx.quadraticCurveTo(0, bh * 0.35, -bw, 0);
    });
    ctx.save(); ctx.globalAlpha = 0.82; patterned(ctx, sp, bell, bw, bh * 1.4); ctx.restore();
    // the glow at its heart
    const g = ctx.createRadialGradient(0, -bh * 0.4, 0, 0, -bh * 0.4, bw);
    g.addColorStop(0, 'rgba(255,255,255,0.55)'); g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, -bh * 0.4, bw, 0, Math.PI * 2); ctx.fill();
  }

  function eel(ctx, sp, f) {
    const L = sp.size, ph = f / FRAMES * Math.PI * 2;
    const thick = sp.body === 'moray' ? L * 0.13 : L * 0.065;
    const pts = [];
    for (let i = 0; i <= 16; i++) { const t = i / 16; pts.push([L * (0.45 - t * 0.9), Math.sin(t * 6.2 - ph) * L * 0.08 * t]); }
    // the fin ribbon along the back
    ctx.strokeStyle = sp.accent; ctx.lineWidth = thick * 1.7; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.globalAlpha = sp.body === 'ribbon' ? 0.7 : 0.45;
    ctx.beginPath(); pts.forEach(([x, y], i) => (i ? ctx.lineTo(x, y - thick * 0.4) : ctx.moveTo(x, y - thick * 0.4))); ctx.stroke();
    ctx.globalAlpha = 1;
    ctx.strokeStyle = 'rgba(10,20,30,0.8)'; ctx.lineWidth = thick + 2;
    ctx.beginPath(); pts.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y))); ctx.stroke();
    ctx.strokeStyle = sp.base; ctx.lineWidth = thick;
    ctx.beginPath(); pts.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y))); ctx.stroke();
    if (sp.pattern !== 'plain') {
      ctx.fillStyle = sp.dark;
      pts.forEach(([x, y], i) => { if (i % (sp.pattern === 'spots' ? 2 : 3) === 1) { ctx.beginPath(); ctx.arc(x, y, thick * (sp.pattern === 'spots' ? 0.25 : 0.42), 0, Math.PI * 2); ctx.fill(); } });
    }
    ctx.fillStyle = sp.base; ctx.beginPath(); ctx.ellipse(L * 0.46, 0, thick * 0.9, thick * 0.7, 0, 0, Math.PI * 2); ctx.fill();
    eye(ctx, L * 0.5, -thick * 0.2, Math.max(1, thick * 0.25));
  }

  function crab(ctx, sp, f) {
    const L = sp.size, step = f % 2 ? 1 : -1;
    const w = sp.body === 'broad' ? L * 0.5 : L * 0.36, h = sp.body === 'tall' ? L * 0.34 : L * 0.26;
    ctx.strokeStyle = sp.dark; ctx.lineWidth = Math.max(1, L * 0.06); ctx.lineCap = 'round';
    for (const side of [-1, 1]) for (let k = 0; k < 3; k++) {
      const x0 = side * w * 0.6, y0 = -h * 0.2 + k * h * 0.35;
      ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x0 + side * L * 0.22, y0 + L * 0.1 + (k % 2 ? step : -step) * L * 0.04); ctx.stroke();
    }
    // claws
    ctx.fillStyle = sp.accent;
    for (const side of [-1, 1]) { ctx.beginPath(); ctx.ellipse(side * w * 0.75, -h * 0.9 + step * side * L * 0.02, L * 0.13, L * 0.09, side * 0.5, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); }
    const shell = () => withPath(ctx, () => {
      if (sp.body === 'spiny') { for (let i = 0; i <= 12; i++) { const a = Math.PI + (i / 12) * Math.PI; const rr = i % 2 ? 1 : 1.18; ctx.lineTo(Math.cos(a) * w * rr, Math.sin(a) * h * rr); } ctx.lineTo(w, h * 0.3); ctx.lineTo(-w, h * 0.3); }
      else ctx.ellipse(0, 0, w, h, 0, 0, Math.PI * 2);
    });
    // eyes on stalks above the shell (sitting on it, they read as ears)
    ctx.strokeStyle = sp.dark; ctx.lineWidth = Math.max(1, L * 0.04);
    for (const side of [-1, 1]) { ctx.beginPath(); ctx.moveTo(side * w * 0.2, -h * 0.6); ctx.lineTo(side * w * 0.28, -h * 1.35); ctx.stroke(); }
    patterned(ctx, sp, shell, w, h);
    for (const side of [-1, 1]) { ctx.fillStyle = '#10151c'; ctx.beginPath(); ctx.arc(side * w * 0.28, -h * 1.4, Math.max(1, L * 0.045), 0, Math.PI * 2); ctx.fill(); }
  }

  function seahorse(ctx, sp, f) {
    const L = sp.size, sway = Math.sin(f / FRAMES * Math.PI * 2) * L * 0.03;
    ctx.save(); ctx.translate(sway, 0);
    ctx.strokeStyle = 'rgba(10,20,30,0.8)'; ctx.lineCap = 'round';
    // curled tail
    ctx.lineWidth = L * 0.12 + 2; ctx.beginPath(); ctx.moveTo(0, L * 0.05); ctx.quadraticCurveTo(-L * 0.12, L * 0.35, L * 0.05, L * 0.42); ctx.arc(L * 0.02, L * 0.36, L * 0.06, 0.8, -2.2, true); ctx.stroke();
    ctx.strokeStyle = sp.base; ctx.lineWidth = L * 0.12; ctx.stroke();
    // body and head
    const body = () => withPath(ctx, () => { ctx.ellipse(0, -L * 0.08, L * 0.13, L * 0.22, 0.15, 0, Math.PI * 2); });
    patterned(ctx, sp, body, L * 0.15, L * 0.25);
    ctx.fillStyle = sp.base; ctx.beginPath(); ctx.ellipse(L * 0.05, -L * 0.33, L * 0.1, L * 0.08, -0.4, 0, Math.PI * 2); ctx.fill();
    ctx.fillRect(L * 0.1, -L * 0.37, L * 0.16, L * 0.05);   // snout
    if (sp.body === 'crested') { ctx.fillStyle = sp.accent; for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.moveTo(-L * 0.02 + i * L * 0.05, -L * 0.4); ctx.lineTo(i * L * 0.05, -L * 0.52); ctx.lineTo(L * 0.03 + i * L * 0.05, -L * 0.4); ctx.fill(); } }
    ctx.fillStyle = sp.accent; ctx.globalAlpha = 0.8; ctx.beginPath(); ctx.ellipse(-L * 0.12, -L * 0.05, L * 0.05, L * 0.1 + sway, 0, 0, Math.PI * 2); ctx.fill(); ctx.globalAlpha = 1;
    eye(ctx, L * 0.07, -L * 0.35, Math.max(1, L * 0.035));
    ctx.restore();
  }

  const PLAN_DRAW = { fish, ray, jelly, eel, crab, seahorse };

  /**
   * Draw one species, one frame, centred at (x, y), facing right, at `scale`.
   * Returns the number of drawing calls made (a probe can assert every species actually drew).
   */
  function drawCreature(ctx, sp, frame, x, y, scale) {
    const fn = PLAN_DRAW[sp.plan];
    if (!fn) throw new Error('FathomPaint: no painter for body plan "' + sp.plan + '"');
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(scale || 1, scale || 1);
    fn(ctx, sp, ((frame % FRAMES) + FRAMES) % FRAMES);
    ctx.restore();
    return 1;
  }

  /**
   * Paint a species' whole sheet: FRAMES cells in a row on a canvas-like target with getContext.
   * `make(w, h)` returns that target (a Bitmap's canvas in MZ, an offscreen canvas in a probe).
   */
  function sheet(sp, make) {
    const c = cellSize(sp);
    const target = make(c * FRAMES, c);
    const ctx = target.getContext ? target.getContext('2d') : target.context;
    for (let f = 0; f < FRAMES; f++) drawCreature(ctx, sp, f, c * f + c / 2, c / 2, 1);
    return { target, cell: c, frames: FRAMES };
  }

  /* A shaft of light: a tall soft wedge, brightest at the top, for an additive sprite. */
  function shaft(ctx, w, h) {
    // Soft-edged light: seven nested wedges, each narrower and each adding a little light, so the edge fades into the
    // water at every height. (2026-10-09 independent review: the single wedge with a horizontal fade read as
    // "hard-edged flat bands of even opacity": the fade was measured across the FULL width, so the narrow top of the
    // wedge sat entirely inside the unfaded middle. The first render's shafts were too faint to find, hence the core.)
    // (second review: seven layers still stepped visibly at the edge; fourteen thinner ones fade smoothly)
    const N = 14;
    for (let k = 0; k < N; k++) {
      const f = k / (N - 1);
      const topHalf = w * 0.2 * (1 - f * 0.8), botHalf = w * 0.5 * (1 - f * 0.75);
      const g = ctx.createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, 'rgba(235,250,255,0.095)'); g.addColorStop(0.5, 'rgba(170,228,255,0.045)'); g.addColorStop(1, 'rgba(120,200,255,0)');
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.moveTo(w / 2 - topHalf, 0); ctx.lineTo(w / 2 + topHalf, 0); ctx.lineTo(w / 2 + botHalf, h); ctx.lineTo(w / 2 - botHalf, h); ctx.closePath(); ctx.fill();
    }
  }

  function bubble(ctx, r) {
    ctx.strokeStyle = 'rgba(230,250,255,0.9)'; ctx.lineWidth = Math.max(1, r * 0.25);
    ctx.fillStyle = 'rgba(200,240,255,0.18)';
    ctx.beginPath(); ctx.arc(r + 1, r + 1, r, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.9)'; ctx.beginPath(); ctx.arc(r * 0.65 + 1, r * 0.6 + 1, Math.max(0.6, r * 0.28), 0, Math.PI * 2); ctx.fill();
  }

  /* The soft shadow a swimming creature casts on the floor below it: a dark ellipse that fades to nothing at its rim.
   * One sheet, shared by every creature on the map and scaled per creature (one texture, so the shadows batch). */
  function shadow(ctx, w, h) {
    ctx.save();
    ctx.translate(w / 2, h / 2); ctx.scale(1, h / w);
    const g = ctx.createRadialGradient(0, 0, 0, 0, 0, w / 2);
    g.addColorStop(0, 'rgba(4,14,22,0.9)'); g.addColorStop(0.45, 'rgba(4,14,22,0.55)'); g.addColorStop(1, 'rgba(4,14,22,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, w / 2, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  function mote(ctx, r) {
    const g = ctx.createRadialGradient(r, r, 0, r, r, r);
    g.addColorStop(0, 'rgba(230,250,240,0.8)'); g.addColorStop(1, 'rgba(230,250,240,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, r * 2, r * 2);
  }

  /* The splash a dive makes, as a ring of droplets at progress p (0..1). */
  function splash(ctx, cx, cy, p, size) {
    ctx.save();
    ctx.strokeStyle = 'rgba(240,252,255,' + (1 - p).toFixed(3) + ')';
    ctx.lineWidth = Math.max(1, size * 0.08 * (1 - p));
    ctx.beginPath(); ctx.ellipse(cx, cy, size * (0.3 + p), size * (0.12 + p * 0.4), 0, 0, Math.PI * 2); ctx.stroke();
    ctx.fillStyle = 'rgba(240,252,255,' + (1 - p).toFixed(3) + ')';
    for (let i = 0; i < 10; i++) {
      const a = -Math.PI * (0.1 + 0.8 * i / 9), d = size * (0.2 + p * 0.9);
      ctx.beginPath(); ctx.arc(cx + Math.cos(a) * d, cy + Math.sin(a) * d * 0.9 - p * (1 - p) * size * 1.6, Math.max(1, size * 0.05 * (1 - p)), 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
  }

  const api = { VERSION: '1.0.0', FRAMES, cellSize, drawCreature, sheet, shaft, shadow, bubble, mote, splash, core, PLAN_DRAW };
  root.CSAF = root.CSAF || {};
  root.CSAF.FathomPaint = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this));
