/*:
 * @target MZ
 * @plugindesc [v1.0.0] Fathom Core - the underwater rules: depth light, caustics, sea life species. Required by Fathom.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help FathomCore.js
 *
 * The part of Fathom that holds no drawing and touches no engine object: notetag reading, the light
 * absorbed at each depth, the caustic light sheet, the sea-life species, how a school steers, the air
 * meter and the dive timeline. Fathom.js and FathomPaint.js use it. It has no parameters and no
 * commands; put all three files in js/plugins and turn all three on, in any order.
 *
 * Copyright (c) 2026 Core Systems Asset Factory. Code written with AI assistance.
 */
'use strict';

(function (root) {

  // ------------------------------------------------------------------ seeded randomness (never Math.random)

  function hash(v) {
    const s = String(v);
    let h = 2166136261 >>> 0;
    for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    h ^= h >>> 15; h = Math.imul(h, 0x2c1b3c6d) >>> 0; h ^= h >>> 12;
    return h >>> 0;
  }
  function rng(seed) {
    let a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  // a parameter arrives as a STRING; '' is absent, never zero (wing 16)
  function num(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; const n = Number(v); return Number.isFinite(n) ? n : d; }

  // ------------------------------------------------------------------ the notetag

  /**
   * Read `<underwater>` or `<underwater: depth 3, murk 40, current 90 1.2, life 30, shafts 4, kelp off>`
   * from a map's note. Returns null when the map is not underwater.
   * Every value is clamped to its range; an unknown word is ignored, never fatal.
   */
  function parseNote(note) {
    const m = /<underwater(?:\s*:\s*([^>]*))?>/i.exec(String(note || ''));
    if (!m) return null;
    const out = { depth: 2, murk: 30, currentDeg: null, currentSpeed: 1, life: 100, shafts: 4, kelp: true, caustics: 100 };
    const body = (m[1] || '').split(',');
    for (const part of body) {
      const w = part.trim().split(/\s+/);
      if (!w[0]) continue;
      const key = w[0].toLowerCase();
      if (key === 'depth') out.depth = clamp(num(w[1], out.depth), 0, 5);
      else if (key === 'murk') out.murk = clamp(num(w[1], out.murk), 0, 100);
      else if (key === 'current') { out.currentDeg = ((num(w[1], 0) % 360) + 360) % 360; out.currentSpeed = clamp(num(w[2], 1), 0, 4); }
      else if (key === 'life') out.life = clamp(num(w[1], out.life), 0, 300);
      else if (key === 'shafts') out.shafts = clamp(Math.round(num(w[1], out.shafts)), 0, 8);
      else if (key === 'kelp') out.kelp = !/^(off|no|false|0)$/i.test(w[1] || '');
      else if (key === 'caustics') out.caustics = clamp(num(w[1], out.caustics), 0, 300);
    }
    return out;
  }

  // ------------------------------------------------------------------ light under water

  /* Water absorbs red first, then green; blue travels furthest. Per metre-ish "depth unit" these are the
   * attenuation constants, shaped to the real ordering (red ~ 8x blue), not to the real magnitudes. */
  const ABSORB = [0.36, 0.11, 0.035];
  const WATER = [0.04, 0.24, 0.36];   // the colour of the water itself, which murk mixes toward

  /**
   * The grade for a depth (0..5) and murk (0..100): a per-channel multiplier and a fog colour + amount.
   * The multiplier is renormalised so that its BRIGHTEST channel is 1 at depth 0 and falls slowly with
   * depth: the hue changes faster than the brightness, which is what reads as water rather than dusk.
   */
  function grade(depth, murk) {
    const d = clamp(depth, 0, 5);
    const mul = ABSORB.map((k) => Math.exp(-k * (d + 0.6)));
    const top = Math.max(mul[0], mul[1], mul[2]);
    const bright = 1 - 0.09 * d;            // the light falls away with depth, slowly
    const m = mul.map((v) => v / top * bright);
    // shallow water still keeps some warmth: a floor on red so a reef at depth 0.5 is not grey
    // (a red roof went near-black in the first render: the floor keeps warm surfaces readable as warm)
    m[0] = Math.max(m[0], 0.44 - 0.05 * d);
    // the water's own colour hangs over everything, more as the water deepens (2026-10-08 in-engine look: at
    // 0.25 + 0.1d a green field at depth 2 stayed garden-green, so the scene read as a tinted lawn, not a seabed)
    // (2026-10-09 independent review: shallow water still read as "a green filter"; the water's own colour now hangs
    // a little heavier at every depth)
    const fogAmt = clamp(murk / 100, 0, 1) * (0.72 + 0.12 * d);
    const fog = WATER.map((v, i) => v * (1.15 - 0.1 * d) + (i === 2 ? 0.05 : 0));
    return { mul: m, fog, fogAmt: clamp(fogAmt, 0, 0.7) };
  }

  // ------------------------------------------------------------------ caustics

  /**
   * The caustic light sheet: two tileable networks of bright thin lines (Worley F2 - F1, the shape the
   * surface's ripples focus onto a floor) in the R and G channels of one RGBA buffer, each from its own
   * seed. The shader scrolls the two layers in different directions and keeps the brighter where they
   * cross, which is what makes the network crawl instead of slide. Baked ONCE; nothing per frame.
   * @returns {{size:number, data:Uint8ClampedArray}}
   */
  function causticSheet(size, seed) {
    size = size || 128;
    const data = new Uint8ClampedArray(size * size * 4);
    const cells = 6;                       // a cell count that divides the sheet: the network wraps
    for (let layer = 0; layer < 2; layer++) {
      const r = rng(hash('caustic:' + seed + ':' + layer));
      const pts = [];
      for (let j = 0; j < cells; j++) for (let i = 0; i < cells; i++) pts.push([(i + 0.1 + r() * 0.8) / cells, (j + 0.1 + r() * 0.8) / cells]);
      for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
        const u = x / size, v = y / size;
        let f1 = 9, f2 = 9;
        for (const p of pts) {
          // toroidal distance: the sheet tiles without a seam by construction
          let dx = Math.abs(u - p[0]); dx = Math.min(dx, 1 - dx);
          let dy = Math.abs(v - p[1]); dy = Math.min(dy, 1 - dy);
          const d = dx * dx + dy * dy;
          if (d < f1) { f2 = f1; f1 = d; } else if (d < f2) f2 = d;
        }
        const edge = Math.sqrt(f2) - Math.sqrt(f1);          // 0 on a cell border
        // (2026-10-09: 2.6 / 3.2 drew hairlines that read as cracked glass; wider and softer reads as focused light)
        const line = Math.pow(clamp(1 - edge * cells * 2.1, 0, 1), 2.6);
        data[(y * size + x) * 4 + layer] = Math.round(line * 255);
      }
    }
    for (let i = 0; i < size * size; i++) { data[i * 4 + 2] = 0; data[i * 4 + 3] = 255; }
    return { size, data };
  }

  // ------------------------------------------------------------------ sea life

  const PLANS = ['fish', 'fish', 'fish', 'fish', 'ray', 'jelly', 'eel', 'crab', 'seahorse'];
  const BODIES = ['torpedo', 'deep', 'round', 'long', 'arrow'];
  const TAILS = ['fork', 'fan', 'lunate', 'round', 'trailing'];
  const PATTERNS = ['plain', 'stripes', 'bands', 'spots', 'saddle', 'gradient'];
  const PLAN_BODIES = { ray: ['diamond', 'round'], jelly: ['dome', 'bell', 'flat'], eel: ['moray', 'ribbon'], crab: ['broad', 'tall', 'spiny'], seahorse: ['plain', 'crested'] };
  const PALETTES = [
    { name: 'silver', base: '#c9d3dc', dark: '#6f7f8f', accent: '#e9f1f6' },
    { name: 'sunset', base: '#f08a3c', dark: '#a8431c', accent: '#ffe08a' },
    { name: 'reef blue', base: '#3c7fe0', dark: '#1d3f86', accent: '#f6d34a' },
    { name: 'coral', base: '#e5576f', dark: '#8f2440', accent: '#ffd1d8' },
    { name: 'lime', base: '#9fd94a', dark: '#4d7a1e', accent: '#1c3d2a' },
    { name: 'violet', base: '#8b5fd6', dark: '#46297e', accent: '#f2c84b' },
    { name: 'bronze', base: '#b08a4a', dark: '#5e4320', accent: '#efe0b0' },
    { name: 'teal', base: '#2fb5a3', dark: '#16655c', accent: '#d8fff8' },
    { name: 'ink', base: '#3a4150', dark: '#151820', accent: '#c7d0dd' },
    { name: 'pearl', base: '#f1ece2', dark: '#a49a87', accent: '#ff9db0' },
  ];
  const JELLY_PALETTES = [
    { name: 'moon', base: '#cfe3ff', dark: '#7aa3d6', accent: '#ffffff' },
    { name: 'rose', base: '#f4b6d2', dark: '#c0628f', accent: '#fff0f7' },
    { name: 'amber', base: '#ffd38a', dark: '#c98a2e', accent: '#fff6dc' },
    { name: 'glow', base: '#a6fff0', dark: '#3ab3a1', accent: '#ffffff' },
  ];

  /**
   * One species, entirely from its index: a body plan, then the parts that plan uses.
   * Plans differ in STRUCTURE (a ray has wings and no tail fin, a jellyfish a bell and trailing arms),
   * not only in colour (wing 21a: a palette is not a composition).
   */
  /* The species' ordinal WITHIN its body plan (the plans repeat every 9 ids; fish take 4 of the 9 slots). */
  function ordinal(i) {
    const lap = Math.floor(i / PLANS.length), slot = i % PLANS.length;
    return PLANS[slot] === 'fish' ? lap * 4 + slot : lap;
  }

  function species(i) {
    const r = rng(hash('species:' + i));
    const plan = PLANS[i % PLANS.length];
    const pal = plan === 'jelly' ? JELLY_PALETTES[Math.floor(r() * JELLY_PALETTES.length)] : PALETTES[Math.floor(r() * PALETTES.length)];
    // Body, tail and pattern are an ENUMERATION by the species' ordinal within its plan, never independent draws, so no
    // two species of one plan share a body AND a pattern (2026-10-09 independent review: the global-index pattern cycle
    // gave the five eels patterns 0,3,0,3,0 and left recolour twins among eels, crabs and fish; wing 21g: a construction
    // that cannot collapse, not a bigger vocabulary). Fish: body n%5, pattern (n + 2*floor(n/5)) % 6, distinct for n < 30.
    const n = ordinal(i);
    const bodies = plan === 'fish' ? BODIES : PLAN_BODIES[plan];
    const smallPatterns = ['plain', 'stripes', 'spots'];
    let body, pattern;
    if (plan === 'fish') { body = BODIES[n % 5]; pattern = PATTERNS[(n + 2 * Math.floor(n / 5)) % PATTERNS.length]; }
    else if (plan === 'eel' || plan === 'ray') { body = bodies[n % bodies.length]; pattern = PATTERNS[n % PATTERNS.length]; }
    else { body = bodies[n % bodies.length]; pattern = smallPatterns[Math.floor(n / bodies.length) % smallPatterns.length]; }
    const sp = {
      id: i, plan, palette: pal.name, base: pal.base, dark: pal.dark, accent: pal.accent,
      // every plan has its own body variants, and FathomPaint draws each one differently
      body,
      tail: plan === 'fish' ? TAILS[(n * 2 + Math.floor(n / 5)) % TAILS.length] : null,
      pattern,
      dorsal: r() < 0.5,
      size: 0, speed: 0, school: 1, layer: 'mid',
    };
    // sizes in screen pixels on a 48 px tile (2026-10-08 in-engine look: at 10-24 px a fish was a speck a quarter of a
    // tile wide and the sea life the plugin sells could not be seen at all in a full-screen frame)
    if (plan === 'fish') { sp.size = 20 + Math.floor(r() * 18); sp.speed = 0.9 + r() * 1.4; sp.school = sp.size < 27 ? 6 + Math.floor(r() * 8) : 2 + Math.floor(r() * 3); sp.layer = 'mid'; }
    else if (plan === 'ray') { sp.size = 60 + Math.floor(r() * 36); sp.speed = 0.6 + r() * 0.5; sp.school = 1; sp.layer = 'over'; }
    else if (plan === 'jelly') { sp.size = 22 + Math.floor(r() * 20); sp.speed = 0.25 + r() * 0.3; sp.school = 2 + Math.floor(r() * 4); sp.layer = 'over'; }
    else if (plan === 'eel') { sp.size = 48 + Math.floor(r() * 30); sp.speed = 0.5 + r() * 0.6; sp.school = 1; sp.layer = 'floor'; }
    else if (plan === 'crab') { sp.size = 18 + Math.floor(r() * 10); sp.speed = 0.35 + r() * 0.3; sp.school = 1 + Math.floor(r() * 2); sp.layer = 'floor'; }
    else { sp.size = 20 + Math.floor(r() * 10); sp.speed = 0.3 + r() * 0.2; sp.school = 1; sp.layer = 'mid'; }
    sp.name = speciesName(sp, r);
    return sp;
  }

  const NAME_A = { fish: ['Glass', 'Flag', 'Lantern', 'Ribbon', 'Ember', 'Pike', 'Coin', 'Thread', 'Moon', 'Saddle'], ray: ['Cloak', 'Kite', 'Shadow', 'Veil'], jelly: ['Lantern', 'Bell', 'Lace', 'Moon'], eel: ['Ribbon', 'Moray', 'Lamp', 'Reed'], crab: ['Shore', 'Rock', 'Hermit', 'Lantern'], seahorse: ['Knight', 'Crown', 'Weed'] };
  const NAME_B = { fish: ['fin', 'tail', 'darter', 'scale', 'bream', 'perch', 'minnow'], ray: ['ray', 'wing'], jelly: ['jelly', 'drifter'], eel: ['eel'], crab: ['crab'], seahorse: ['horse'] };
  function speciesName(sp, r) {
    const a = NAME_A[sp.plan], b = NAME_B[sp.plan];
    return a[Math.floor(r() * a.length)] + ' ' + b[Math.floor(r() * b.length)];
  }

  /* What makes two species look the same on screen: the structural parts and the palette. */
  function signature(sp) { return [sp.plan, sp.body, sp.tail, sp.pattern, sp.palette, sp.dorsal ? 'd' : '', Math.round(sp.size / 6)].join('|'); }

  const CORPUS = 48;
  let _corpus = null;
  function corpus() { if (!_corpus) { _corpus = []; for (let i = 0; i < CORPUS; i++) _corpus.push(species(i)); } return _corpus; }

  /**
   * The life of one map: which species, how many, from the map's id, depth and the `life` percentage.
   * Deep water gets more jellyfish and eels, shallow more fish and crabs. The same map always holds the
   * same life. Returns [{species, count}].
   */
  function lifeFor(mapId, depth, lifePct, area) {
    const r = rng(hash('life:' + mapId));
    const all = corpus();
    // (the first render at depth 2 held five kinds and nine creatures on a 20x14 map: too empty to read; and a
    // bigger map spread the same few kinds thinner, so the count scales with the map's area, capped)
    const spread = clamp((area || 300) / 300, 1, 2.5);
    const want = Math.max(0, Math.round((6 + Math.floor(depth)) * spread * clamp(lifePct, 0, 300) / 100));
    const out = [];
    const used = new Set();
    let guard = 0;
    while (out.length < want && guard++ < 400) {
      const sp = all[Math.floor(r() * all.length)];
      if (used.has(sp.id)) continue;
      const deepish = sp.plan === 'jelly' || sp.plan === 'eel';
      const shallowish = sp.plan === 'crab' || sp.plan === 'seahorse';
      if (deepish && depth < 1.5 && r() < 0.7) continue;
      if (shallowish && depth > 3.5 && r() < 0.7) continue;
      used.add(sp.id);
      out.push({ species: sp, count: sp.school });
    }
    return out;
  }

  // ------------------------------------------------------------------ schools

  /**
   * One step of a school, IN PLACE on typed arrays (zero allocation per frame). Each fish keeps to its
   * school's heading, wanders a little, holds together, and turns away from the party: a school PARTS
   * for the player and closes behind them.
   *   pos: Float32Array [x0,y0,x1,y1,...] in tiles; vel: same, tiles per second
   *   o: { heading, speed, avoidX, avoidY, avoidR, dt, phase, w, h, sep } (sep: the room each fish keeps, in tiles; 0 = none)
   */
  function stepSchool(pos, vel, n, o) {
    let cx = 0, cy = 0;
    for (let i = 0; i < n; i++) { cx += pos[i * 2]; cy += pos[i * 2 + 1]; }
    cx /= Math.max(1, n); cy /= Math.max(1, n);
    const hx = Math.cos(o.heading), hy = Math.sin(o.heading);
    for (let i = 0; i < n; i++) {
      const x = pos[i * 2], y = pos[i * 2 + 1];
      let ax = hx * o.speed - vel[i * 2], ay = hy * o.speed - vel[i * 2 + 1];
      ax += (cx - x) * 0.6; ay += (cy - y) * 0.6;                       // cohesion
      const wob = Math.sin(o.phase * 1.7 + i * 2.3);
      ax += -hy * wob * 0.6; ay += hx * wob * 0.6;                        // wander
      // separation: each fish keeps its own room, so a school reads as fish and not as one heap (2026-10-09 in-engine
      // close-up: with cohesion alone a school of twelve piled into a single overlapping clump)
      const sep = o.sep > 0 ? o.sep : 0;
      if (sep > 0) for (let j = 0; j < n; j++) {
        if (j === i) continue;
        const qx = x - pos[j * 2], qy = y - pos[j * 2 + 1];
        const q = qx * qx + qy * qy;
        if (q < sep * sep && q > 1e-8) { const dd = Math.sqrt(q); const k = (sep - dd) / sep * 4; ax += qx / dd * k; ay += qy / dd * k; }
      }
      const dx = x - o.avoidX, dy = y - o.avoidY;
      const d2 = dx * dx + dy * dy;
      if (d2 < o.avoidR * o.avoidR) {                                     // part for the party
        const d = Math.sqrt(d2) || 0.001;
        const push = (o.avoidR - d) / o.avoidR * 9;
        ax += dx / d * push; ay += dy / d * push;
      }
      vel[i * 2] += ax * o.dt * 2.2; vel[i * 2 + 1] += ay * o.dt * 2.2;
      const sp = Math.sqrt(vel[i * 2] * vel[i * 2] + vel[i * 2 + 1] * vel[i * 2 + 1]);
      const max = o.speed * 2.4;
      if (sp > max) { vel[i * 2] *= max / sp; vel[i * 2 + 1] *= max / sp; }
      pos[i * 2] += vel[i * 2] * o.dt; pos[i * 2 + 1] += vel[i * 2 + 1] * o.dt;
      // the map wraps for life: a school that swims off one edge comes in at the other
      if (o.w > 0) pos[i * 2] = ((pos[i * 2] % o.w) + o.w) % o.w;
      if (o.h > 0) pos[i * 2 + 1] = ((pos[i * 2 + 1] % o.h) + o.h) % o.h;
    }
    return { cx, cy };
  }

  // ------------------------------------------------------------------ bubbles

  /* A character breathes out every `period` seconds, a chain of `count` bubbles; the phase comes from
   * the character so a party does not breathe in unison. */
  function breath(charKey) {
    const r = rng(hash('breath:' + charKey));
    return { period: 2.6 + r() * 1.6, count: 3 + Math.floor(r() * 3), offset: r() * 3 };
  }

  // ------------------------------------------------------------------ the air meter

  /**
   * Advance the air meter. `air` is 0..1. Under water it falls by dt / seconds; above water it refills
   * five times faster. Returns the event the plugin must act on: 'empty' once when it first reaches 0,
   * 'low' once when it first crosses 25%, or null.
   */
  function stepAir(st, dt, under, seconds) {
    if (!(seconds > 0)) { st.air = 1; return null; }
    const before = st.air;
    st.air = under ? Math.max(0, st.air - dt / seconds) : Math.min(1, st.air + dt * 5 / seconds);
    if (under && before > 0 && st.air === 0) return 'empty';
    if (under && before > 0.25 && st.air <= 0.25) return 'low';
    return null;
  }

  // ------------------------------------------------------------------ the dive timeline

  /* A dive: a splash (0..0.35), the sink (0.35..0.9: the screen goes down into blue), transfer at 0.9,
   * then on the new map the light falls away from white to the water's own colour (0..1.2 s).
   * A surface is the reverse. Pure: given the kind and the elapsed time, what to draw. */
  const DIVE = { splash: 0.35, sink: 0.9, transferAt: 0.9, arrive: 1.2 };
  function diveFrame(kind, t) {
    if (kind === 'dive') {
      if (t < DIVE.splash) return { phase: 'splash', ring: t / DIVE.splash, cover: 0, tint: 'white' };
      if (t < DIVE.sink) return { phase: 'sink', ring: 1, cover: (t - DIVE.splash) / (DIVE.sink - DIVE.splash), tint: 'blue' };
      return { phase: 'transfer', ring: 1, cover: 1, tint: 'blue' };
    }
    if (kind === 'surface') {
      if (t < DIVE.sink) return { phase: 'rise', ring: 0, cover: t / DIVE.sink, tint: 'white' };
      return { phase: 'transfer', ring: 0, cover: 1, tint: 'white' };
    }
    // a dive arrives out of the same blue it sank into, clearing to the water's own colour (2026-10-08 in-engine look:
    // a WHITE cover here washed the first second under water out to a pale fog and broke the dive's continuity)
    if (kind === 'arriveDive') return { phase: 'arrive', ring: 0, cover: Math.max(0, 1 - t / DIVE.arrive), tint: 'blue' };
    if (kind === 'arriveSurface') return { phase: 'arrive', ring: clamp(t / DIVE.splash, 0, 1), cover: Math.max(0, 1 - t / DIVE.arrive), tint: 'white' };
    return { phase: 'none', ring: 0, cover: 0, tint: 'none' };
  }

  const api = {
    VERSION: '1.0.0', hash, rng, clamp, num, parseNote, ABSORB, WATER, grade, causticSheet,
    PLANS, BODIES, PLAN_BODIES, TAILS, PATTERNS, PALETTES, JELLY_PALETTES, species, signature, corpus, CORPUS, lifeFor,
    stepSchool, breath, stepAir, DIVE, diveFrame, ordinal,
  };
  root.CSAF = root.CSAF || {};
  root.CSAF.FathomCore = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this));
