//=============================================================================
// JigsawDraw.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Jigsaw renderer: draws each piece from your picture with a bevel, rim light and shadow, and draws the table. Load SECOND.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * Drawing only, onto any canvas 2D context (an MZ/MV Bitmap's context in the
 * game). It reads the cut from JigsawCut.js and the picture you choose; it
 * loads no image of its own. Each piece is traced along the cut's own curves,
 * so its edge stays smooth at any size.
 */

var CSAF = CSAF || {};

(function () {
  'use strict';

  /** Trace one piece's outline (closed) into ctx's current path, in picture coordinates. */
  function tracePiece(ctx, piece) {
    var order = ['top', 'right', 'bottom', 'left'];
    for (var i = 0; i < 4; i++) {
      var e = piece.edges[order[i]], P = e.base.pts;
      var pts = e.reversed ? P.slice().reverse() : P;
      if (i === 0) ctx.moveTo(pts[0][0], pts[0][1]);
      for (var k = 1; k < 10; k += 3) ctx.bezierCurveTo(pts[k][0], pts[k][1], pts[k + 1][0], pts[k + 1][1], pts[k + 2][0], pts[k + 2][1]);
    }
    ctx.closePath();
  }

  /**
   * Draw a piece with its home bounding box at (x, y) on ctx.
   * @param {CanvasRenderingContext2D} ctx target
   * @param {CanvasImageSource} img the picture, drawn at the cut's w x h
   * @param {Object} cut the cut (JigsawCut.cut)
   * @param {Object} piece one of cut.pieces
   * @param {number} x left of the piece's bounding box
   * @param {number} y top of the piece's bounding box
   * @param {{lifted:boolean, bevel:number}} [o] lifted adds a soft drop shadow; bevel in px (default by piece size)
   */
  function drawPiece(ctx, img, cut, piece, x, y, o) {
    o = o || {};
    var bev = o.bevel || bevelOf(piece);
    ctx.save();
    ctx.translate(x - piece.homeX, y - piece.homeY);
    // shadow first, under the piece: deeper when the piece is lifted
    ctx.save();
    ctx.beginPath(); tracePiece(ctx, piece);
    ctx.shadowColor = 'rgba(0,0,0,' + (o.lifted ? 0.55 : 0.38) + ')';
    ctx.shadowBlur = o.lifted ? bev * 7 : bev * 2.2;
    ctx.shadowOffsetX = o.lifted ? bev * 2.6 : bev * 0.7;
    ctx.shadowOffsetY = o.lifted ? bev * 3.4 : bev * 0.9;
    ctx.fillStyle = '#20180f';
    ctx.fill();
    ctx.restore();
    // the picture, clipped to the piece
    ctx.save();
    ctx.beginPath(); tracePiece(ctx, piece); ctx.clip();
    ctx.drawImage(img, 0, 0, cut.w, cut.h);
    // bevel: light from the upper left, a dark lip lower right, each a stroke of the outline offset inside the clip
    ctx.lineJoin = 'round';
    // (first look: width 2 x bevel at 0.42 alpha read as a white halo round the piece; softened after looking)
    ctx.lineWidth = bev * 1.5;
    ctx.save(); ctx.translate(bev * 0.6, bev * 0.6); ctx.beginPath(); tracePiece(ctx, piece);
    ctx.strokeStyle = 'rgba(255,246,226,0.26)'; ctx.stroke(); ctx.restore();
    ctx.save(); ctx.translate(-bev * 0.6, -bev * 0.6); ctx.beginPath(); tracePiece(ctx, piece);
    ctx.strokeStyle = 'rgba(20,12,4,0.40)'; ctx.stroke(); ctx.restore();
    // a faint sheen across the face so a piece reads as card stock, not a cut-out of a screenshot
    var g = ctx.createLinearGradient(piece.homeX, piece.homeY, piece.homeX + piece.bw, piece.homeY + piece.bh);
    g.addColorStop(0, 'rgba(255,255,255,0.10)'); g.addColorStop(0.5, 'rgba(255,255,255,0)'); g.addColorStop(1, 'rgba(0,0,0,0.10)');
    ctx.fillStyle = g; ctx.fillRect(piece.homeX - 4, piece.homeY - 4, piece.bw + 8, piece.bh + 8);
    ctx.restore();
    // the cut line itself: a hairline of the board's grey core
    ctx.beginPath(); tracePiece(ctx, piece);
    ctx.lineWidth = Math.max(0.8, bev * 0.45); ctx.strokeStyle = 'rgba(48,38,26,0.85)'; ctx.stroke();
    ctx.restore();
  }

  /** The bevel drawPiece gives a piece (px): grows with the piece, so a big piece reads as thick card. */
  function bevelOf(piece) { return Math.max(1.5, Math.min(piece.bw, piece.bh) * 0.035); }

  /**
   * How far past its outline box a piece's LIFTED shadow can reach (blur ~1.5 x shadowBlur, plus the offset): the margin
   * a piece's own bitmap needs so no shadow is clipped. One reader of the shadow numbers above, so they cannot drift.
   * @param {Object} piece one of cut.pieces
   * @returns {number} px on every side
   */
  function margin(piece) { var b = bevelOf(piece); return Math.ceil(b * 7 * 1.5 + b * 3.4) + 2; }

  /** A seeded value noise for the table's grain. */
  function noise(R, n) { var a = []; for (var i = 0; i < n; i++) a.push(R()); return a; }

  /**
   * The table: a felt mat inside a wooden rim, lit from above. Drawn once per scene.
   * @param {CanvasRenderingContext2D} ctx target
   * @param {number} w width
   * @param {number} h height
   * @param {{seed:number, felt:string, wood:string}} [o]
   */
  function drawTable(ctx, w, h, o) {
    o = o || {};
    var R = CSAF.JigsawCut.rng(CSAF.JigsawCut.seedOf(o.seed || 7));
    var wood = o.wood || '#5a3a22', felt = o.felt || '#24453a';
    // wood
    ctx.fillStyle = wood; ctx.fillRect(0, 0, w, h);
    var grain = noise(R, 90);
    for (var i = 0; i < grain.length; i++) {
      var y = grain[i] * h;
      ctx.strokeStyle = 'rgba(' + (i % 2 ? '255,220,170' : '30,15,5') + ',' + (0.05 + grain[(i + 7) % 90] * 0.06) + ')';
      ctx.lineWidth = 1 + grain[(i + 3) % 90] * 2.5;
      ctx.beginPath(); ctx.moveTo(0, y);
      ctx.bezierCurveTo(w * 0.3, y + (grain[(i + 11) % 90] - 0.5) * 18, w * 0.7, y + (grain[(i + 23) % 90] - 0.5) * 18, w, y + (grain[(i + 5) % 90] - 0.5) * 10);
      ctx.stroke();
    }
    // felt mat
    var m = feltInset(w, h);
    ctx.fillStyle = felt; ctx.fillRect(m, m, w - m * 2, h - m * 2);
    for (var k = 0; k < 1400; k++) {
      ctx.fillStyle = 'rgba(' + (R() < 0.5 ? '255,255,255' : '0,0,0') + ',' + (0.025 + R() * 0.03) + ')';
      ctx.fillRect(m + R() * (w - m * 2), m + R() * (h - m * 2), 1 + R() * 1.6, 1 + R() * 1.6);
    }
    // the mat's lip and a pool of light from above
    ctx.strokeStyle = 'rgba(0,0,0,0.45)'; ctx.lineWidth = 3; ctx.strokeRect(m + 1.5, m + 1.5, w - m * 2 - 3, h - m * 2 - 3);
    ctx.strokeStyle = 'rgba(255,240,210,0.18)'; ctx.lineWidth = 1; ctx.strokeRect(m - 0.5, m - 0.5, w - m * 2 + 1, h - m * 2 + 1);
    var lg = ctx.createRadialGradient(w * 0.5, h * 0.42, Math.min(w, h) * 0.1, w * 0.5, h * 0.5, Math.max(w, h) * 0.75);
    lg.addColorStop(0, 'rgba(255,240,205,0.10)'); lg.addColorStop(1, 'rgba(0,0,0,0.38)');
    ctx.fillStyle = lg; ctx.fillRect(0, 0, w, h);
  }

  /** The wooden rim's width on a w x h table: the felt starts this far in. The scene lays out inside it. */
  function feltInset(w, h) { return Math.round(Math.min(w, h) * 0.045); }

  CSAF.JigsawDraw = { VERSION: '1.0.0', tracePiece: tracePiece, drawPiece: drawPiece, drawTable: drawTable, feltInset: feltInset, bevelOf: bevelOf, margin: margin };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.JigsawDraw;
