//=============================================================================
// Jigsaw.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Jigsaw: turns any picture in your project into a generated jigsaw the player assembles on a drawn table.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * Recommended order: JigsawCut.js, JigsawDraw.js, Jigsaw.js (this file). Any
 * order works: the files find each other when the first puzzle opens.
 * RPG Maker MV 1.6: also CSAF_MVBridge.js at the TOP of the list. In MV the
 * command is a Plugin Command line:
 *   Jigsaw start picture=Castle pieces=24 seed=7
 *   Jigsaw start picture="Castle at Night" pieces=48
 * Script call (MZ and MV):
 *   CSAF.Jigsaw.start({ picture: 'Castle', pieces: 24, seed: 7 })
 *
 * The picture is any file in img/pictures. Every seed cuts a different puzzle.
 * The player drags pieces with the mouse or a finger, or moves the hand with
 * the arrow keys (Shift = faster) and presses OK to pick up and put down. A
 * piece close to its home snaps in. Hold Q (Page Up) or press the plaque for
 * the box lid. Cancel sets the puzzle aside.
 *
 * Results are written as the puzzle closes, before the event continues:
 * seconds and moves into variables, a switch ON when solved (OFF when set
 * aside), and an optional common event. CSAF.Jigsaw.lastResult() returns
 * { picture, pieces, solved, seconds, moves, peeks, seed }.
 *
 * @param varSeconds
 * @text Seconds -> variable
 * @type variable
 * @default 0
 *
 * @param varMoves
 * @text Moves -> variable
 * @type variable
 * @default 0
 *
 * @param swSolved
 * @text Solved -> switch
 * @type switch
 * @default 0
 *
 * @param commonEvent
 * @text Common event afterwards
 * @type common_event
 * @default 0
 *
 * @param snap
 * @text Snap distance (px)
 * @type number
 * @min 4
 * @max 60
 * @default 16
 *
 * @command start
 * @text Start a jigsaw
 * @desc Cut a picture into a jigsaw and let the player assemble it.
 *
 * @arg picture
 * @text Picture (img/pictures)
 * @type file
 * @dir img/pictures
 * @default
 *
 * @arg pieces
 * @text About how many pieces
 * @type number
 * @min 4
 * @max 256
 * @default 24
 *
 * @arg seed
 * @text Seed
 * @desc Blank = a new cut every time. A number cuts the same puzzle every time.
 * @type string
 * @default
 */

var CSAF = CSAF || {};

(function () {
  'use strict';
  var NAME = 'Jigsaw';
  var RAW = PluginManager.parameters(NAME);
  function num(v, d) { var s = String(v === undefined || v === null ? '' : v).trim(); if (s === '') return d; var n = Number(s); return isFinite(n) ? n : d; }
  var P = { varSeconds: num(RAW.varSeconds, 0), varMoves: num(RAW.varMoves, 0), swSolved: num(RAW.swSolved, 0), commonEvent: num(RAW.commonEvent, 0), snap: Math.max(4, num(RAW.snap, 16)) };
  /** Siblings resolved at first use: the buyer chooses the load order. */
  function deps() {
    var C = CSAF.JigsawCut, D = CSAF.JigsawDraw;
    if (!C || !D) throw new Error('Jigsaw needs JigsawCut.js and JigsawDraw.js installed and ON.');
    return { cut: C, draw: D };
  }
  /** The table's type: a book serif, never the engine's UI font. */
  var FONT = 'Georgia, "Palatino Linotype", "Book Antiqua", Palatino, "Times New Roman", serif';
  var HUD_H = 40, M = 10;
  /** Type and plaque scale with the screen: 1 at MZ's 816x624, up to 3 (a 1080-wide portrait screen reads 1.73). */
  function uiScale() { return Math.max(1, Math.min(3, Math.min(Graphics.width, Graphics.height) / 624)); }
  function rec() { if (!$gameSystem._csafJigsaw) $gameSystem._csafJigsaw = { v: 1, count: 0, last: null }; return $gameSystem._csafJigsaw; }

  var pending = null;
  function start(args) {
    var pic = String(args.picture || '').trim();
    if (!pic) { console.warn('Jigsaw: no picture given. Pick a file in img/pictures.'); return false; }
    var r = rec();
    var seedText = String(args.seed === undefined ? '' : args.seed).trim();
    var seed = seedText !== '' ? seedText : ('j' + r.count + 'm' + ($gameMap ? $gameMap.mapId() : 0) + 'f' + Graphics.frameCount);
    pending = { picture: pic, pieces: Math.max(4, Math.min(256, num(args.pieces, 24))), seed: seed };
    SceneManager.push(Scene_Jigsaw);
    return true;
  }
  // MV has no registerCommand until CSAF_MVBridge.js has loaded: say so instead of throwing at boot
  if (typeof PluginManager.registerCommand === 'function') PluginManager.registerCommand(NAME, 'start', function (args) { start(args); });
  else console.warn('Jigsaw: in RPG Maker MV, put CSAF_MVBridge.js at the TOP of the plugin list, above the Jigsaw files. The script call CSAF.Jigsaw.start({...}) still works.');

  //---------------------------------------------------------------------------
  function Scene_Jigsaw() { this.initialize.apply(this, arguments); }
  Scene_Jigsaw.prototype = Object.create(Scene_Base.prototype);
  Scene_Jigsaw.prototype.constructor = Scene_Jigsaw;

  Scene_Jigsaw.prototype.initialize = function () {
    Scene_Base.prototype.initialize.call(this);
    this._req = pending; pending = null;
    this._picture = this._req ? ImageManager.loadPicture(this._req.picture) : null;
    this._built = false; this._held = -1; this._grabX = 0; this._grabY = 0; this._moves = 0; this._frames = 0; this._done = false; this._doneAge = 0;
  };

  Scene_Jigsaw.prototype.isReady = function () { return Scene_Base.prototype.isReady.call(this) && (!this._picture || this._picture.isReady()); };

  Scene_Jigsaw.prototype.start = function () {
    Scene_Base.prototype.start.call(this);
    if (!this._req || !this._picture || this._picture.width === 0) { console.warn('Jigsaw: the picture could not be loaded.'); this.popScene(); return; }
    this.build();
  };

  /** Lay out the table, the frame and the pieces; cut once. */
  Scene_Jigsaw.prototype.build = function () {
    var d = deps(), W = Graphics.width, H = Graphics.height;
    var tb = new Bitmap(W, H); d.draw.drawTable(tb.context, W, H, { seed: 5 }); tb._baseTexture.update();
    this.addChild(new Sprite(tb));
    // the frame: the largest one whose loose pieces each get a spot of their own (first look: a fixed 60% x 78%
    // frame piled pieces on each other and ran some off the table)
    var L = this.solveLayout(d), fw = L.fw, fh = L.fh;
    this._fx = L.fx; this._fy = L.fy; this._layout = L;
    var fr = new Bitmap(W, H), c = fr.context;
    c.fillStyle = 'rgba(0,0,0,0.30)'; c.fillRect(this._fx - 6, this._fy - 6, fw + 12, fh + 12);
    c.strokeStyle = 'rgba(255,235,200,0.25)'; c.lineWidth = 1; c.strokeRect(this._fx - 6.5, this._fy - 6.5, fw + 13, fh + 13);
    // a ghost of the picture in the frame, so the player has the box art to work from
    c.globalAlpha = 0.16; c.drawImage(this._picture._image || this._picture.canvas, this._fx, this._fy, fw, fh); c.globalAlpha = 1;
    fr._baseTexture.update(); this._frameSp = new Sprite(fr); this.addChild(this._frameSp);
    this._cut = L.cut;
    var src = this._picture._image || this._picture.canvas, R = d.cut.rng(d.cut.seedOf(this._req.seed + ':scatter'));
    this._layer = new Sprite(); this.addChild(this._layer);
    this._pieces = []; this._src = src;
    for (var i = 0; i < this._cut.pieces.length; i++) {
      var p = this._cut.pieces[i];
      // room for the piece's lifted shadow (a fixed 12 px clipped the shadow of a big piece, read from the renderer)
      var pad = d.draw.margin(p);
      var bmp = new Bitmap(Math.ceil(p.bw) + pad * 2, Math.ceil(p.bh) + pad * 2);
      d.draw.drawPiece(bmp.context, src, this._cut, p, pad, pad); bmp._baseTexture.update();
      var sp = new Sprite(bmp);
      sp._piece = p; sp._pad = pad; sp._placed = false;
      sp._homeX = this._fx + p.homeX - pad; sp._homeY = this._fy + p.homeY - pad;
      // its own spot from the packing, with a little seeded play (the gap is wider than the play, so none touch)
      var at = L.pos[i];
      sp.x = Math.round(at[0] - pad + (R() * 2 - 1) * 3); sp.y = Math.round(at[1] - pad + (R() * 2 - 1) * 3);
      sp.x = Math.max(L.t - pad, Math.min(W - L.t - bmp.width + pad, sp.x)); sp.y = Math.max(L.t - pad, Math.min(H - L.t - bmp.height + pad, sp.y));
      this._layer.addChild(sp); this._pieces.push(sp);
    }
    // the hand: keyboard players move it with the arrows
    var hb = new Bitmap(28, 28), hc = hb.context;
    hc.fillStyle = 'rgba(255,240,205,0.9)'; hc.strokeStyle = 'rgba(40,25,10,0.9)'; hc.lineWidth = 2;
    hc.beginPath(); hc.moveTo(4, 2); hc.lineTo(4, 22); hc.lineTo(10, 16); hc.lineTo(16, 26); hc.lineTo(20, 24); hc.lineTo(14, 14); hc.lineTo(22, 14); hc.closePath(); hc.fill(); hc.stroke(); hb._baseTexture.update();
    this._hand = new Sprite(hb); this._hand.x = W / 2; this._hand.y = H / 2; this._hand.visible = false; this.addChild(this._hand);
    // the plaque over the frame: placed / total, time, moves
    this._S = uiScale();
    this._hud = new Sprite(new Bitmap(fw + 12, Math.round(HUD_H * this._S))); this._hud.x = this._fx - 6; this._hud.y = L.t + 8; this.addChild(this._hud);
    this._placedN = 0; this._hudKey = -1;
    // the box lid: the whole picture over the frame while the player holds Q (page up) or presses on the plaque
    var lb = new Bitmap(fw + 8, fh + 8), lc = lb.context;
    lc.fillStyle = 'rgba(16,9,4,0.9)'; lc.fillRect(0, 0, fw + 8, fh + 8);
    lc.drawImage(this._picture._image || this._picture.canvas, 4, 4, fw, fh);
    lc.strokeStyle = 'rgba(244,206,128,0.8)'; lc.lineWidth = 1.5; lc.strokeRect(2.75, 2.75, fw + 2.5, fh + 2.5);
    lb._baseTexture.update();
    this._lid = new Sprite(lb); this._lid.x = this._fx - 4; this._lid.y = this._fy - 4; this._lid.opacity = 0; this.addChild(this._lid);
    this._peeks = 0; this._peeking = false; this._peekTouch = false;
    // the hint, engraved in the gap under the frame
    var hh = Math.round(16 * this._S), hint = new Bitmap(fw + 12, hh); hint.fontFace = FONT; hint.fontSize = Math.round(12 * this._S); hint.outlineWidth = 0; hint.textColor = 'rgba(255,226,170,0.55)';
    hint.drawText('Hold Q or press the plaque for the box lid  ·  Esc sets it aside', 0, 0, fw + 12, hh, 'left');
    var hs = new Sprite(hint); hs.x = this._fx - 4; hs.y = this._fy + fh + 5; this._frameSp.addChild(hs);
    this._fw = fw; this._fh = fh; this._built = true;
    this.drawHud();
  };

  /**
   * The table's layout for this screen: the largest frame (top left, under the plaque) whose loose pieces each get
   * a spot of their own on the free table, so no two pieces start on top of each other. Shrinks the frame 5% a step
   * until the spots cover the pieces; past 40 steps it keeps the smallest and the extra pieces share spots.
   * @returns {{fw:number, fh:number, fx:number, fy:number, cut:object, slots:Array, tries:number}}
   */
  Scene_Jigsaw.prototype.solveLayout = function (d) {
    var W = Graphics.width, H = Graphics.height, pw = this._picture.width, ph = this._picture.height;
    // a portrait screen stacks the frame over the pieces (first look at 1080x1920: a side tray left most of the felt empty)
    var S = uiScale(), portrait = H > W * 1.15;
    var T = d.draw.feltInset(W, H), top = T + 8 + Math.round(HUD_H * S) + 14, fx = T + 14;
    var kMax = portrait ? Math.min((W - fx * 2) / pw, (H - top - T) * 0.5 / ph) : Math.min((W - fx - T) * 0.66 / pw, (H - top - T - 8) / ph), L = null;
    for (var t = 0; t < 40; t++) {
      var k = kMax * Math.pow(0.96, t), fw = Math.max(16, Math.round(pw * k)), fh = Math.max(16, Math.round(ph * k));
      if (portrait) fx = Math.round((W - fw) / 2);
      var g = d.cut.gridFor(fw, fh, this._req.pieces);
      var cut = d.cut.cut({ w: fw, h: fh, cols: g.cols, rows: g.rows, seed: this._req.seed });
      // the same seeded order every try, so the solve is a function of the screen and the seed alone
      var R = d.cut.rng(d.cut.seedOf(this._req.seed + ':order')), order = [];
      for (var i = 0; i < cut.pieces.length; i++) order.push(i);
      for (var q = order.length - 1; q > 0; q--) { var j = Math.floor(R() * (q + 1)), tq = order[q]; order[q] = order[j]; order[j] = tq; }
      // the strip starts below the engraved hint
      var below = top + fh + 10 + Math.round(16 * S);
      var regions = portrait ? [[T + 6, below, W - T - 6, H - T - 6]] : [[fx + fw + 18, T + 6, W - T - 6, H - T - 6], [T + 6, below, fx + fw + 6, H - T - 6]];
      var pos = packLoose(cut, order, regions, 12);
      L = { fw: fw, fh: fh, fx: fx, fy: top, t: T, cut: cut, pos: pos.pos, fits: pos.fits, tries: t + 1 };
      if (pos.fits) break;
    }
    return L;
  };

  /**
   * Shelf-pack the loose pieces by their OWN outline boxes into the free regions, in the given order: left to right,
   * a new row when a piece will not fit, the next region when the rows run out; each row and each region's block is
   * centred. A piece that fits nowhere is stacked at the last region's centre and `fits` is false.
   * @returns {{pos:Array<Array<number>>, fits:boolean}} top-left of each piece's outline box, by piece index
   */
  function packLoose(cut, order, regions, gap) {
    var pos = new Array(cut.pieces.length), k = 0;
    for (var r = 0; r < regions.length && k < order.length; r++) {
      var g = regions[r], x = g[0], y = g[1], rowH = 0, rowStart = k, blockStart = k;
      while (k < order.length) {
        var p = cut.pieces[order[k]];
        if (x > g[0] && x + p.bw > g[2]) { shiftRow(pos, order, rowStart, k, (g[2] - (x - gap)) / 2, 0); x = g[0]; y += rowH + gap; rowH = 0; rowStart = k; }
        if (x + p.bw > g[2] || y + p.bh > g[3]) break;
        pos[order[k]] = [x, y]; x += p.bw + gap; rowH = Math.max(rowH, p.bh); k++;
      }
      if (k > rowStart) shiftRow(pos, order, rowStart, k, (g[2] - (x - gap)) / 2, 0);
      if (k > blockStart) shiftRow(pos, order, blockStart, k, 0, (g[3] - (y + rowH)) / 2);
    }
    var fits = k === order.length, last = regions[regions.length - 1];
    for (; k < order.length; k++) { var q = cut.pieces[order[k]]; pos[order[k]] = [(last[0] + last[2] - q.bw) / 2, (last[1] + last[3] - q.bh) / 2]; }
    return { pos: pos, fits: fits };
  }
  function shiftRow(pos, order, a, b, dx, dy) { for (var i = a; i < b; i++) { pos[order[i]][0] += dx; pos[order[i]][1] += dy; } }

  /** Redraw the plaque when what it says has changed (once a second at most while the clock runs). */
  Scene_Jigsaw.prototype.drawHud = function () {
    var secs = Math.floor(this._frames / 60), key = secs * 1e6 + this._placedN * 1e3 + this._moves;
    if (key === this._hudKey) return;
    this._hudKey = key;
    var b = this._hud.bitmap, w = b.width, h = b.height, c = b.context, n = this._pieces.length, S = this._S;
    b.clear();
    c.save();
    c.fillStyle = 'rgba(24,14,8,0.62)'; roundRect(c, 0.5, 0.5, w - 1, h - 1, 7); c.fill();
    c.strokeStyle = 'rgba(255,226,170,0.38)'; c.lineWidth = 1; roundRect(c, 3.5, 3.5, w - 7, h - 7, 5); c.stroke();
    // the progress rule along the plaque's foot
    var fill = n ? this._placedN / n : 0;
    var ry = h - Math.round(9 * S), rh = Math.max(2, Math.round(2 * S));
    c.fillStyle = 'rgba(255,226,170,0.16)'; c.fillRect(10, ry, w - 20, rh);
    c.fillStyle = 'rgba(244,196,112,0.95)'; c.fillRect(10, ry, Math.round((w - 20) * fill), rh);
    c.restore();
    b.fontFace = FONT; b.outlineWidth = 0; b.fontItalic = false;
    var third = Math.floor((w - 24) / 3), mm = Math.floor(secs / 60), ss = secs % 60, y1 = Math.round(2 * S), y2 = Math.round(15 * S);
    b.fontSize = Math.round(13 * S); b.textColor = 'rgba(255,226,170,0.62)';
    b.drawText('PLACED', 12, y1, third, Math.round(18 * S), 'left'); b.drawText('TIME', 12 + third, y1, third, Math.round(18 * S), 'center'); b.drawText('MOVES', 12 + third * 2, y1, third, Math.round(18 * S), 'right');
    b.fontSize = Math.round(17 * S); b.textColor = '#f6e6c4';
    b.drawText(this._placedN + ' / ' + n, 12, y2, third, Math.round(20 * S), 'left');
    b.drawText(mm + ':' + (ss < 10 ? '0' : '') + ss, 12 + third, y2, third, Math.round(20 * S), 'center');
    b.drawText(String(this._moves), 12 + third * 2, y2, third, Math.round(20 * S), 'right');
  };

  function roundRect(c, x, y, w, h, r) {
    c.beginPath(); c.moveTo(x + r, y); c.lineTo(x + w - r, y); c.quadraticCurveTo(x + w, y, x + w, y + r); c.lineTo(x + w, y + h - r);
    c.quadraticCurveTo(x + w, y + h, x + w - r, y + h); c.lineTo(x + r, y + h); c.quadraticCurveTo(x, y + h, x, y + h - r);
    c.lineTo(x, y + r); c.quadraticCurveTo(x, y, x + r, y); c.closePath();
  }

  /** The topmost unplaced piece under (x, y), by the piece's own outline. No allocation. */
  Scene_Jigsaw.prototype.pieceAt = function (x, y) {
    for (var i = this._layer.children.length - 1; i >= 0; i--) {
      var sp = this._layer.children[i];
      if (sp._placed) continue;
      var p = sp._piece, lx = x - sp.x - sp._pad + p.homeX, ly = y - sp.y - sp._pad + p.homeY, o = p.outline, inside = false;
      for (var a = 0, b = o.length - 1; a < o.length; b = a++) {
        if ((o[a][1] > ly) !== (o[b][1] > ly) && lx < (o[b][0] - o[a][0]) * (ly - o[a][1]) / (o[b][1] - o[a][1]) + o[a][0]) inside = !inside;
      }
      if (inside) return i;
    }
    return -1;
  };

  Scene_Jigsaw.prototype.grab = function (x, y) {
    var i = this.pieceAt(x, y); if (i < 0) return;
    var sp = this._layer.children[i];
    this._layer.removeChild(sp); this._layer.addChild(sp); // to the top
    this._held = this._layer.children.length - 1; this._grabX = x - sp.x; this._grabY = y - sp.y;
    sp.scale.x = sp.scale.y = 1.04; this.redrawPiece(sp, true); SoundManager.playCursor();
  };

  /** Repaint one piece, lifted (a deeper, offset shadow) or at rest. Once per pick-up or put-down, never per frame. */
  Scene_Jigsaw.prototype.redrawPiece = function (sp, lifted) {
    var b = sp.bitmap;
    b.clear(); deps().draw.drawPiece(b.context, this._src, this._cut, sp._piece, sp._pad, sp._pad, { lifted: lifted }); b._baseTexture.update();
  };

  Scene_Jigsaw.prototype.drop = function () {
    var sp = this._layer.children[this._held]; this._held = -1; if (!sp) return;
    sp.scale.x = sp.scale.y = 1; this.redrawPiece(sp, false); this._moves++;
    if (Math.abs(sp.x - sp._homeX) <= P.snap && Math.abs(sp.y - sp._homeY) <= P.snap) {
      sp.x = sp._homeX; sp.y = sp._homeY; sp._placed = true; this._placedN++;
      this._layer.removeChild(sp); this._layer.addChildAt(sp, 0); SoundManager.playOk();
      if (this._placedN === this._pieces.length) this.solve(true);
    }
  };

  Scene_Jigsaw.prototype.placedCount = function () { var n = 0; for (var i = 0; i < this._pieces.length; i++) if (this._pieces[i]._placed) n++; return n; };

  Scene_Jigsaw.prototype.solve = function (solved) {
    if (this._done) return;
    this._done = true; this._solved = !!solved; this._doneAge = 0;
    var secs = Math.floor(this._frames / 60), r = rec();
    r.count++; r.last = { picture: this._req.picture, pieces: this._pieces.length, solved: this._solved, seconds: secs, moves: this._moves, peeks: this._peeks, seed: String(this._req.seed) };
    this._lid.opacity = 0;
    if (P.varSeconds) $gameVariables.setValue(P.varSeconds, secs);
    if (P.varMoves) $gameVariables.setValue(P.varMoves, this._moves);
    if (P.swSolved) $gameSwitches.setValue(P.swSolved, this._solved);
    if (P.commonEvent) $gameTemp.reserveCommonEvent(P.commonEvent);
    if (solved) SoundManager.playOk();
    this.buildFinale(secs);
  };

  /**
   * The ending: on a solve the whole picture comes up over the joined pieces (the cut lines melt away) under a
   * thin gilt line; either way a plaque gives the result. Both fade in from update; built once.
   */
  Scene_Jigsaw.prototype.buildFinale = function (secs) {
    var fw = this._fw, fh = this._fh, n = this._pieces.length, W = Graphics.width, H = Graphics.height, T = this._layout.t, S = this._S, h = Math.round(92 * S);
    // the finished picture rises out of the frame to the middle of the table, drawn at its final size (it shrinks
    // into the frame's place at the start, so it is never magnified)
    var kz = Math.max(1, Math.min((W - T * 2 - 60) / fw, (H - T * 2 - h - 56) / fh)), tw = Math.round(fw * kz), th = Math.round(fh * kz);
    this._fin = { x0: this._fx - 4, y0: this._fy - 4, s0: fw / tw, x1: Math.round((W - tw) / 2) - 4, y1: Math.round((H - th - h - 16) / 2) - 4 };
    if (this._solved) {
      var pb = new Bitmap(tw + 8, th + 8), c = pb.context; pb.smooth = true;
      c.drawImage(this._picture._image || this._picture.canvas, 4, 4, tw, th);
      c.strokeStyle = 'rgba(244,206,128,0.95)'; c.lineWidth = 2; c.strokeRect(3, 3, tw + 2, th + 2);
      c.strokeStyle = 'rgba(40,22,8,0.7)'; c.lineWidth = 1; c.strokeRect(0.5, 0.5, tw + 7, th + 7);
      pb._baseTexture.update();
      this._whole = new Sprite(pb); this._whole.x = this._fin.x0; this._whole.y = this._fin.y0; this._whole.opacity = 0;
      this._whole.scale.x = this._whole.scale.y = this._fin.s0;
      this.addChild(this._whole);
    }
    this.drawHud();
    var w = Math.min(W - 40, Math.max(Math.round(320 * S), Math.round(tw * 0.7)));
    var b = new Bitmap(w, h), x = b.context;
    x.save();
    x.fillStyle = 'rgba(22,12,6,0.86)'; roundRect(x, 0.5, 0.5, w - 1, h - 1, 9 * S); x.fill();
    x.strokeStyle = 'rgba(244,206,128,0.75)'; x.lineWidth = Math.max(1, S * 0.9); roundRect(x, 4.5 * S, 4.5 * S, w - 9 * S, h - 9 * S, 6 * S); x.stroke();
    // a small flourish either side of the title: a rule ending in a diamond (clear of the widest title)
    x.fillStyle = x.strokeStyle = 'rgba(244,206,128,0.85)';
    var gap = (this._solved ? 92 : 128) * S, fy0 = 22 * S;
    for (var s = -1; s <= 1; s += 2) {
      var cx = w / 2 + s * gap;
      x.beginPath(); x.moveTo(cx, fy0); x.lineTo(cx + s * 34 * S, fy0); x.stroke();
      x.beginPath(); x.moveTo(cx + s * 40 * S, fy0); x.lineTo(cx + s * 36 * S, fy0 - 3 * S); x.lineTo(cx + s * 32 * S, fy0); x.lineTo(cx + s * 36 * S, fy0 + 3 * S); x.closePath(); x.fill();
    }
    x.restore();
    b.fontFace = FONT; b.outlineWidth = 0;
    b.fontSize = Math.round(24 * S); b.textColor = '#f6e2b4';
    b.drawText(this._solved ? 'S O L V E D' : 'S E T   A S I D E', 0, Math.round(6 * S), w, Math.round(32 * S), 'center');
    var mm = Math.floor(secs / 60), ss = secs % 60, t = mm + ':' + (ss < 10 ? '0' : '') + ss;
    b.fontSize = Math.round(16 * S); b.textColor = '#ead7b0';
    b.drawText(this._solved ? (n + ' pieces  ·  ' + t + '  ·  ' + this._moves + ' moves') : (this._placedN + ' of ' + n + ' placed  ·  ' + t), 0, Math.round(38 * S), w, Math.round(22 * S), 'center');
    b.fontSize = Math.round(12 * S); b.textColor = 'rgba(234,215,176,0.6)';
    b.drawText('OK to continue', 0, Math.round(62 * S), w, Math.round(18 * S), 'center');
    this._plaque = new Sprite(b);
    this._plaque.x = this._solved ? Math.round((W - w) / 2) : Math.round(this._fx + fw / 2 - w / 2);
    this._plaque.x = Math.max(20, Math.min(W - w - 20, this._plaque.x));
    // set aside: over the middle of the frame (at its foot it covered the engraved hint, first look 1280x720)
    this._plaque.y = this._solved ? this._fin.y1 + th + 8 + 14 : Math.round(this._fy + fh / 2 - h / 2); this._plaque.opacity = 0;
    this.addChild(this._plaque);
  };

  Scene_Jigsaw.prototype.update = function () {
    Scene_Base.prototype.update.call(this);
    if (!this._built) return;
    if (this._done) {
      this._doneAge++;
      if (this._whole) {
        var e = Math.min(1, this._doneAge / 40), f = this._fin; e = e * e * (3 - 2 * e);
        this._whole.opacity = Math.min(255, this._doneAge * 12);
        this._whole.scale.x = this._whole.scale.y = f.s0 + (1 - f.s0) * e;
        this._whole.x = f.x0 + (f.x1 - f.x0) * e; this._whole.y = f.y0 + (f.y1 - f.y0) * e;
        this._layer.opacity = this._frameSp.opacity = this._hud.opacity = Math.round(255 * (1 - e));
      }
      if (this._plaque) this._plaque.opacity = Math.max(0, Math.min(255, (this._doneAge - (this._whole ? 30 : 0)) * 12));
      this._hand.visible = false;
      // the ending finishes (picture at rest by frame 40, plaque in by 52) before OK can leave it
      if (this._doneAge > 52 &&(Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered())) this.popScene();
      return;
    }
    this._frames++;
    // keyboard hand
    var dx = (Input.isPressed('right') ? 1 : 0) - (Input.isPressed('left') ? 1 : 0), dy = (Input.isPressed('down') ? 1 : 0) - (Input.isPressed('up') ? 1 : 0);
    if (dx || dy) { var sp0 = Input.isPressed('shift') ? 9 : 4; this._hand.visible = true; this._hand.x = Math.max(0, Math.min(Graphics.width - 4, this._hand.x + dx * sp0)); this._hand.y = Math.max(0, Math.min(Graphics.height - 4, this._hand.y + dy * sp0)); }
    if (Input.isTriggered('ok')) { this._hand.visible = true; if (this._held < 0) { this.grab(this._hand.x, this._hand.y); this._viaHand = true; } else this.drop(); }
    if (this._held >= 0 && this._viaHand) { var h = this._layer.children[this._held]; h.x = this._hand.x - this._grabX; h.y = this._hand.y - this._grabY; }
    // the box lid (key or a press on the plaque); a peek is counted once per press
    var hx = TouchInput.x - this._hud.x, hy = TouchInput.y - this._hud.y;
    if (TouchInput.isTriggered() && this._held < 0 && hx >= 0 && hy >= 0 && hx < this._hud.bitmap.width && hy < this._hud.bitmap.height) this._peekTouch = true;
    if (this._peekTouch && !TouchInput.isPressed()) this._peekTouch = false;
    var peek = Input.isPressed('pageup') || this._peekTouch;
    if (peek && !this._peeking) this._peeks++;
    this._peeking = peek;
    this._lid.opacity = Math.max(0, Math.min(235, this._lid.opacity + (peek ? 40 : -40)));
    // mouse and touch
    if (TouchInput.isTriggered() && this._held < 0 && !this._peekTouch) { this._hand.visible = false; this._viaHand = false; this.grab(TouchInput.x, TouchInput.y); }
    if (this._held >= 0 && !this._viaHand) {
      var t = this._layer.children[this._held];
      if (TouchInput.isPressed()) { t.x = TouchInput.x - this._grabX; t.y = TouchInput.y - this._grabY; } else this.drop();
    }
    if (Input.isTriggered('cancel') || TouchInput.isCancelled()) this.solve(false);
    this.drawHud();
  };

  CSAF.Jigsaw = { VERSION: '1.0.0', P: P, start: start, Scene_Jigsaw: Scene_Jigsaw, lastResult: function () { return $gameSystem && $gameSystem._csafJigsaw ? $gameSystem._csafJigsaw.last : null; } };
  window.Scene_Jigsaw = Scene_Jigsaw;
})();
