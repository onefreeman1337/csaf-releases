//=============================================================================
// JigsawCut.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Jigsaw cut model: cuts any picture into interlocking knob-and-socket pieces from a seed. Load FIRST.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The cutting model only: no drawing, no scene, no engine code. Jigsaw.js (the
 * scene and commands) and JigsawDraw.js (the renderer) read it.
 *
 * How a cut is made
 *   1. A grid sized to the picture's aspect, its inner corners nudged so no two
 *      pieces are the same rectangle.
 *   2. Every inner edge becomes ONE knob curve (three cubic segments), with the
 *      knob's side, size, lean and neck drawn from the seed.
 *   3. The two pieces that share an edge both use that same curve, one forwards
 *      and one backwards, so a tab always meets its own socket and the pieces
 *      tile the picture exactly. The border stays straight.
 *
 * The same seed always cuts the same puzzle; no Math.random anywhere.
 */

var CSAF = CSAF || {};

(function () {
  'use strict';

  var MIN_SIDE = 2;
  var MAX_SIDE = 16;           // 16 x 16 = 256 pieces, the most a scene is asked to draw
  var CORNER_JITTER = 0.05;    // inner corners move up to 5% of a cell
  var TAB_MIN = 0.085, TAB_SPAN = 0.025, WOBBLE = 0.035;

  /** FNV-1a for string seeds; numbers are used as they are. @returns {number} uint32 */
  function seedOf(s) {
    var n = Number(s);
    if (s !== '' && s !== null && s !== undefined && isFinite(n)) return (Math.floor(Math.abs(n)) >>> 0) || 1;
    var h = 2166136261, str = String(s);
    for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    return h || 1;
  }

  /** mulberry32: a small seeded generator, [0, 1). @param {number} a seed @returns {function(): number} */
  function rng(a) {
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function clampSide(v) { var n = Math.round(Number(v)); return isFinite(n) ? Math.max(MIN_SIDE, Math.min(MAX_SIDE, n)) : 4; }

  /**
   * The grid for about n pieces on a w x h picture, keeping each cell near square.
   * @returns {{cols:number, rows:number}}
   */
  function gridFor(w, h, n) {
    w = Math.max(1, Number(w) || 1); h = Math.max(1, Number(h) || 1); n = Math.max(4, Number(n) || 24);
    var best = null;
    for (var rows = MIN_SIDE; rows <= MAX_SIDE; rows++) {
      for (var cols = MIN_SIDE; cols <= MAX_SIDE; cols++) {
        var aspect = (w / cols) / (h / rows);
        var score = Math.abs(cols * rows - n) / n + Math.abs(Math.log(aspect)) * 0.8;
        if (!best || score < best.score) best = { cols: cols, rows: rows, score: score };
      }
    }
    return { cols: best.cols, rows: best.rows };
  }

  /** A knob curve from A to B (ten control points), bulging toward normal side `sign` (+1/-1; 0 = straight). */
  function knobEdge(A, B, axisNormal, sign, R) {
    var ux = B[0] - A[0], uy = B[1] - A[1];
    var nx = -uy, ny = ux;
    if (nx * axisNormal[0] + ny * axisNormal[1] < 0) { nx = -nx; ny = -ny; }
    var t = TAB_MIN + R() * TAB_SPAN;
    var j = function () { return (R() * 2 - 1) * WOBBLE; };
    var a = j(), b = j(), c = j(), d = j(), e = j();
    var local = sign === 0 ? null : [[0, 0], [0.2, a], [0.5 + b + d, -t + c], [0.5 - t + b, t + c], [0.5 - 2 * t + b - d, 3 * t + c],
      [0.5 + 2 * t + b - d, 3 * t + c], [0.5 + t + b, t + c], [0.5 + b + d, -t + c], [0.8, e], [1, 0]];
    var pts = [];
    for (var i = 0; i < 10; i++) {
      var L = local ? local[i] : [i / 9, 0];
      var s = local ? L[1] * sign : 0;
      pts.push([A[0] + ux * L[0] + nx * s, A[1] + uy * L[0] + ny * s]);
    }
    return { pts: pts, sign: sign, knob: sign === 0 ? 0 : t };
  }

  function cubic(p0, p1, p2, p3, t) {
    var m = 1 - t;
    return [m * m * m * p0[0] + 3 * m * m * t * p1[0] + 3 * m * t * t * p2[0] + t * t * t * p3[0],
      m * m * m * p0[1] + 3 * m * m * t * p1[1] + 3 * m * t * t * p2[1] + t * t * t * p3[1]];
  }

  /**
   * Points along an edge in the PIECE's direction (clockwise round the piece).
   * @param {Object} edge a piece edge {base, reversed, sign}
   * @param {number} [steps] samples per cubic segment (default 8)
   * @returns {Array<Array<number>>} points, first to last inclusive
   */
  function flattenEdge(edge, steps) {
    steps = steps || 8;
    var P = edge.base.pts, out = [P[0]];
    for (var seg = 0; seg < 3; seg++) {
      var k = seg * 3;
      for (var s = 1; s <= steps; s++) out.push(cubic(P[k], P[k + 1], P[k + 2], P[k + 3], s / steps));
    }
    return edge.reversed ? out.slice().reverse() : out;
  }

  /** The closed outline of a piece (corners once), clockwise. @returns {Array<Array<number>>} */
  function flattenOutline(piece, steps) {
    var out = [];
    var order = ['top', 'right', 'bottom', 'left'];
    for (var i = 0; i < 4; i++) { var pts = flattenEdge(piece.edges[order[i]], steps); for (var k = 0; k < pts.length - 1; k++) out.push(pts[k]); }
    return out;
  }

  /**
   * Cut a w x h picture into cols x rows interlocking pieces.
   * @param {{w:number, h:number, cols:number, rows:number, seed:(number|string)}} o
   * @returns {{w:number, h:number, cols:number, rows:number, seed:number, pieces:Array<Object>}}
   */
  function cut(o) {
    o = o || {};
    var w = Math.max(16, Number(o.w) || 0), h = Math.max(16, Number(o.h) || 0);
    var cols = clampSide(o.cols), rows = clampSide(o.rows), seed = seedOf(o.seed === undefined ? 1 : o.seed);
    var R = rng(seed), cw = w / cols, ch = h / rows, r, c;

    var corner = [];
    for (r = 0; r <= rows; r++) {
      corner.push([]);
      for (c = 0; c <= cols; c++) {
        var inner = r > 0 && r < rows && c > 0 && c < cols;
        var jx = inner ? (R() * 2 - 1) * CORNER_JITTER * cw : 0, jy = inner ? (R() * 2 - 1) * CORNER_JITTER * ch : 0;
        corner[r].push([c * cw + jx, r * ch + jy]);
      }
    }
    // horizontal lines (r = 0..rows), segment c: corner[r][c] -> corner[r][c+1]; normal +y
    var H = [], V = [];
    for (r = 0; r <= rows; r++) {
      H.push([]);
      for (c = 0; c < cols; c++) H[r].push(knobEdge(corner[r][c], corner[r][c + 1], [0, 1], (r === 0 || r === rows) ? 0 : (R() < 0.5 ? 1 : -1), R));
    }
    // vertical lines (c = 0..cols), segment r: corner[r][c] -> corner[r+1][c]; normal +x
    for (c = 0; c <= cols; c++) {
      V.push([]);
      for (r = 0; r < rows; r++) V[c].push(knobEdge(corner[r][c], corner[r + 1][c], [1, 0], (c === 0 || c === cols) ? 0 : (R() < 0.5 ? 1 : -1), R));
    }

    var pieces = [];
    for (r = 0; r < rows; r++) {
      for (c = 0; c < cols; c++) {
        // outward sign per side: top faces -y (so -base), right +x (base), bottom +y (base), left -x (-base)
        var top = { base: H[r][c], reversed: false, sign: -H[r][c].sign, knob: H[r][c].knob };
        var right = { base: V[c + 1][r], reversed: false, sign: V[c + 1][r].sign, knob: V[c + 1][r].knob };
        var bottom = { base: H[r + 1][c], reversed: true, sign: H[r + 1][c].sign, knob: H[r + 1][c].knob };
        var left = { base: V[c][r], reversed: true, sign: -V[c][r].sign, knob: V[c][r].knob };
        if (top.sign === 0) top.sign = 0; if (left.sign === 0) left.sign = 0; // -0 -> 0
        var piece = { id: r * cols + c, col: c, row: r, edges: { top: top, right: right, bottom: bottom, left: left } };
        var poly = flattenOutline(piece, 6), minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        for (var i = 0; i < poly.length; i++) {
          if (poly[i][0] < minX) minX = poly[i][0]; if (poly[i][1] < minY) minY = poly[i][1];
          if (poly[i][0] > maxX) maxX = poly[i][0]; if (poly[i][1] > maxY) maxY = poly[i][1];
        }
        piece.homeX = minX; piece.homeY = minY; piece.bw = maxX - minX; piece.bh = maxY - minY;
        piece.outline = poly.map(function (p) { return [Math.round(p[0] * 100) / 100, Math.round(p[1] * 100) / 100]; });
        pieces.push(piece);
      }
    }
    return { w: w, h: h, cols: cols, rows: rows, seed: seed, pieces: pieces };
  }

  CSAF.JigsawCut = {
    VERSION: '1.0.0', MIN_SIDE: MIN_SIDE, MAX_SIDE: MAX_SIDE,
    cut: cut, gridFor: gridFor, flattenEdge: flattenEdge, flattenOutline: flattenOutline, seedOf: seedOf, rng: rng
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.JigsawCut;
