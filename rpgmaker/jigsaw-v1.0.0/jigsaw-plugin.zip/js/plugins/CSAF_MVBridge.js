//=============================================================================
// CSAF_MVBridge.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt in the product you bought.
//=============================================================================
/*:
 * @plugindesc v0.3.0 Lets Core Systems Asset Factory plugins written for RPG Maker MZ run in RPG Maker MV. Place it ABOVE every CSAF plugin.
 * @author Core Systems Asset Factory
 *
 * @help
 * This file does nothing at all in RPG Maker MZ.
 *
 * In RPG Maker MV it supplies the few parts of MZ's scripting surface that
 * CSAF plugins use and MV lacks, so the same plugin file runs in both:
 *
 *  - windows created from a Rectangle (MZ) as well as from x, y, width,
 *    height (MV);
 *  - innerWidth / innerHeight on every window;
 *  - plugin commands: MZ's registered commands become MV "Plugin Command"
 *    event lines, written as
 *
 *        <PluginName> <command> key=value key2="a value with spaces"
 *
 *    for example:   VerdictCore startCase
 *                   VerdictCore giveExhibit exhibitId=knife
 *
 *    Each product's guide lists its commands and their keys.
 *
 * Put CSAF_MVBridge.js at the top of the Plugin Manager list, above every CSAF
 * plugin. It changes nothing for plugins from other authors.
 */

(function () {
  'use strict';
  if (typeof Utils === 'undefined' || Utils.RPGMAKER_NAME !== 'MV') return; // MZ: nothing to do

  //---------------------------------------------------------------------------
  // Windows built from a Rectangle. MV: Window_Base.prototype.initialize(x, y, width, height)
  // (rpg_windows.js). MZ passes one Rectangle. Every MV window subclass calls Window_Base's initialize with its own
  // arguments, so converting here covers Window_Selectable and Window_Command subclasses that forward a rect.
  //---------------------------------------------------------------------------
  // A window built from a Rectangle was written for MZ, and MZ lays it out on MZ's padding: 12 px
  // ($gameSystem.windowPadding(), rmmz_objects.js) where MV pads 18 (Window_Base.prototype.standardPadding,
  // rpg_windows.js). MEASURED 2026-10-03: Verdict Core's 84 px header lost its second line on MV (48 px of contents
  // instead of 60). Only Rectangle-built windows get 12; every MV window of the buyer's own keeps 18.
  var _wbInit = Window_Base.prototype.initialize;
  Window_Base.prototype.initialize = function (x, y, width, height) {
    if (x instanceof Rectangle) { var r = x; this._csafMz = true; return _wbInit.call(this, r.x, r.y, r.width, r.height); }
    return _wbInit.call(this, x, y, width, height);
  };
  var _standardPadding = Window_Base.prototype.standardPadding;
  Window_Base.prototype.standardPadding = function () { return this._csafMz ? 12 : _standardPadding.call(this); };
  // ⛔ MEASURED 2026-10-03 (Verdict Core): MV's Window_Selectable.initialize ends with deactivate() -> reselect() ->
  // select() -> ensureCursorVisible() -> maxItems(), BEFORE the subclass's own initialize has set its data, so an MZ
  // subclass throws reading its list. MZ's Window_Selectable.initialize never reselects; skip it during construction.
  var _wsInit = Window_Selectable.prototype.initialize;
  Window_Selectable.prototype.initialize = function (x, y, width, height) {
    this._csafMvInit = true;
    try {
      // ⛔ bridge.test 2026-10-03: converting here hid the Rectangle from Window_Base's wrapper, so MZ-authored
      // SELECTABLE windows kept MV's padding 18. Mark them here too.
      if (x instanceof Rectangle) { var r = x; this._csafMz = true; return _wsInit.call(this, r.x, r.y, r.width, r.height); }
      return _wsInit.call(this, x, y, width, height);
    } finally { this._csafMvInit = false; }
  };
  var _reselect = Window_Selectable.prototype.reselect;
  Window_Selectable.prototype.reselect = function () { if (this._csafMvInit) return; return _reselect.call(this); };
  // MZ rows are lineHeight() + 8 (Window_Selectable.prototype.itemHeight, rmmz_windows.js); MV rows are lineHeight().
  // MEASURED 2026-10-03: Verdict's deduction shelf drew its "ESTABLISHED" label in the bottom 8 px of an MZ row and MV
  // clipped it. Rectangle-built (MZ-authored) windows get MZ's row; a subclass that sets its own itemHeight keeps it.
  var _itemHeight = Window_Selectable.prototype.itemHeight;
  Window_Selectable.prototype.itemHeight = function () { return this._csafMz ? this.lineHeight() + 8 : _itemHeight.call(this); };
  // ...and MZ insets each row by half its spacing (colSpacing 8, rowSpacing 4: Window_Selectable.prototype.itemRect,
  // rmmz_windows.js), MV does not, so a label drawn at a row's bottom edge sits 4 px lower on MV and falls into the clip.
  var _itemRect = Window_Selectable.prototype.itemRect;
  Window_Selectable.prototype.itemRect = function (index) {
    if (!this._csafMz) return _itemRect.call(this, index);
    var maxCols = this.maxCols(), itemWidth = Math.floor(this.innerWidth / maxCols), itemHeight = this.itemHeight();
    var col = index % maxCols, row = Math.floor(index / maxCols);
    return new Rectangle(col * itemWidth + 4 - (this._scrollX || 0), row * itemHeight + 2 - (this._scrollY || 0), itemWidth - 8, itemHeight - 4);
  };

  // MZ additions MV never had (rmmz_windows.js), defined only where absent: itemPadding 8, itemRectWithPadding,
  // itemLineRect (Sigil Core uses it).
  if (!Window_Base.prototype.itemPadding) Window_Base.prototype.itemPadding = function () { return 8; };
  if (!Window_Selectable.prototype.itemRectWithPadding) {
    Window_Selectable.prototype.itemRectWithPadding = function (index) { var r = this.itemRect(index), p = this.itemPadding(); r.x += p; r.width -= p * 2; return r; };
  }
  if (!Window_Selectable.prototype.itemLineRect) {
    Window_Selectable.prototype.itemLineRect = function (index) { var r = this.itemRectWithPadding(index), p = (r.height - this.lineHeight()) / 2; r.y += p; r.height -= p * 2; return r; };
  }

  // MZ's Bitmap.prototype.destroy (rmmz_core.js) frees the texture and canvas; MV's Bitmap has none, and Sigil Core
  // destroys the bitmaps it replaces (MEASURED 2026-10-03: "this.bitmap.destroy is not a function" on MV). Only where
  // absent, freeing what MV's Bitmap holds. (Sprite.destroy is PIXI's and exists in both.)
  if (!Bitmap.prototype.destroy) {
    // MV keeps them behind lazy getters (_canvas, _context, _baseTexture over __canvas, __context, __baseTexture;
    // rpg_core.js Bitmap), so free the private fields; touching the getters would only create them again.
    Bitmap.prototype.destroy = function () {
      var t = this.__baseTexture;
      if (t && typeof t.destroy === 'function') t.destroy();
      this.__baseTexture = null; this.__canvas = null; this.__context = null;
    };
  }

  // MZ: Window.prototype.innerWidth/innerHeight getters (rmmz_core.js) = size minus padding on both sides
  if (!Object.getOwnPropertyDescriptor(Window.prototype, 'innerWidth')) {
    Object.defineProperty(Window.prototype, 'innerWidth', { get: function () { return Math.max(0, this._width - this._padding * 2); }, configurable: true });
    Object.defineProperty(Window.prototype, 'innerHeight', { get: function () { return Math.max(0, this._height - this._padding * 2); }, configurable: true });
  }

  // Window parts: MZ names them _backSprite/_frameSprite/_cursorSprite/_contentsSprite (rmmz_core.js Window); MV
  // creates the same roles as _windowBackSprite/_windowFrameSprite/_windowCursorSprite/_windowContentsSprite
  // (rpg_core.js Window._createAllParts). A CSAF skin that redraws a part reaches MV's part through these aliases.
  // (_pauseSignSprite added 2026-10-03: Sigil Core's grimoire redraws the pause sign; MV names it _windowPauseSignSprite.
  // MV's _upArrowSprite/_downArrowSprite already share MZ's names.)
  [['_backSprite', '_windowBackSprite'], ['_frameSprite', '_windowFrameSprite'], ['_cursorSprite', '_windowCursorSprite'], ['_contentsSprite', '_windowContentsSprite'], ['_pauseSignSprite', '_windowPauseSignSprite']].forEach(function (p) {
    if (Object.getOwnPropertyDescriptor(Window.prototype, p[0])) return;
    Object.defineProperty(Window.prototype, p[0], { get: function () { return this[p[1]]; }, configurable: true });
  });

  //---------------------------------------------------------------------------
  // Plugin commands. MZ: PluginManager.registerCommand(pluginName, commandName, fn) and the event command calls
  // fn.bind(interpreter)(args) with every value a STRING. MV: one free-text "Plugin Command" line, split on spaces,
  // handed to Game_Interpreter.prototype.pluginCommand(command, args).
  //---------------------------------------------------------------------------
  var commands = Object.create(null);
  var owners = Object.create(null); // plugin name -> its command names (v0.3.0: report a misspelt command)
  if (typeof PluginManager.registerCommand !== 'function') {
    PluginManager.registerCommand = function (pluginName, commandName, fn) {
      commands[pluginName + ':' + commandName] = fn;
      (owners[pluginName] = owners[pluginName] || []).push(commandName);
    };
  }
  /** Parse ["key=value", "key2=\"two", "words\""] (MV splits the line on spaces) back into {key: 'value', key2: 'two words'}. */
  function parseArgs(words) {
    var line = words.join(' '), out = {}, re = /([A-Za-z_][A-Za-z0-9_]*)=("([^"]*)"|\S*)/g, m;
    while ((m = re.exec(line))) out[m[1]] = m[3] !== undefined ? m[3] : m[2];
    return out;
  }
  var _pluginCommand = Game_Interpreter.prototype.pluginCommand;
  Game_Interpreter.prototype.pluginCommand = function (command, args) {
    _pluginCommand.call(this, command, args);
    var fn = commands[command + ':' + (args && args[0])];
    if (fn) { fn.call(this, parseArgs(args.slice(1))); return; }
    if (command.indexOf(':') > 0 && commands[command]) { commands[command].call(this, parseArgs(args || [])); return; } // "Plugin:command k=v"
    // v0.3.0: a line naming a plugin that registered commands, with a command it does not have, is a typo in an
    // event (MV has no dropdown). MZ could not make it; MV used to ignore it in silence. Say so; run nothing.
    if (owners[command]) {
      console.warn('[' + command + '] no plugin command "' + ((args && args[0]) || '') + '". '
        + command + '\'s commands: ' + owners[command].join(', ') + '.');
    }
  };

  window.CSAF_MVBridge = { version: '0.3.0', commands: function () { return Object.keys(commands); }, parseArgs: parseArgs };
})();
