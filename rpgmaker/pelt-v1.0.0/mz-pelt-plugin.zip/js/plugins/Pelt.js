/*:
 * @target MZ
 * @plugindesc [v1.0.0] Pelt 3/3 - team dodgeball: your party against a troop or a rival team on a drawn court, their own battlers throwing and catching.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * Install PeltCore.js, PeltDraw.js and Pelt.js (this file) and turn all three ON. Any order works: this file finds the
 * other two when a match starts.
 *
 * START A MATCH from an event with the Plugin Command "Start Match", or a script call:
 *   Pelt.start({ troop: 1, ai: 'normal', court: 'schoolyard', perTeam: 3, rounds: 1 })
 *   Pelt.start({ rivals: [5, 6, 7, 8], ai: 'hard', court: 'castle' })
 *
 * YOUR TEAM is your party: the leader first, then the other members. A team needs perTeam infielders plus one
 * outfielder, so a small party is filled from the actors in your database. The players are your actors' SIDE-VIEW
 * BATTLER sheets (img/sv_actors), drawn with MZ's own motions: walk to run, guard to catch, swing to throw, evade to
 * dodge, damage when hit, dead when out.
 *
 * THE OTHER TEAM is a TROOP (its enemies, repeated to fill the side, drawn from their own battler images with a hop, a
 * lean and a squash) or a list of RIVAL actors (side-view sheets like yours). A rival who is in your party plays for
 * you instead, and the other team is filled from your database.
 *
 * SPECIAL THROWS come from each player's own skills, up to three a player, thrown in turn: the element decides the look
 * and the way the skill reaches its target decides the throw (a straight shot, a fast rush, a rising spike, a high drop,
 * a skim along the floor, a burst that is hard to step out of, a drain that heals the thrower). A spike, a drop or a skim
 * cannot be caught, only dodged, and a skim can be jumped. Actors use the skills they know and their class will learn;
 * enemies use the skills in their action patterns.
 *
 * THE RULES: hit an opponent and they lose HP (three hits and they are out); CATCH a throw and the thrower is out and
 * one of your own out players comes back. Each side has an OUTFIELDER behind the other team who throws in from behind.
 * The side with players left wins; at the time limit the side with more players (then more HP) wins.
 *
 * CONTROLS (keyboard / gamepad)
 *   Arrows move the player marked with the gold arrow (the one nearest the ball, or the one holding it).
 *   OK (Z, Enter / A): THROW when you hold the ball, CATCH when you do not. A catch stance lasts a moment and must face
 *   the ball; pressing it too early leaves you off balance.
 *   Cancel (X, Esc / B): DODGE, a quick sidestep the ball passes through.
 *   Shift (X button): JUMP.
 *   Page Up / Page Down (Q, W / LB, RB): a SPECIAL throw, when the green meter is at least half full.
 *
 * RESULTS are written before the event continues: the winner into a variable (1 = your team, 2 = the other team,
 * 0 = a draw), a switch ON when your team won, an optional common event. Script call: Pelt.lastResult().
 *
 * @param varWinner
 * @text Winner -> variable
 * @desc 1 = your team won, 2 = the other team won, 0 = a draw.
 * @type variable
 * @default 0
 *
 * @param swWin
 * @text Your team won -> switch
 * @type switch
 * @default 0
 *
 * @param commonEvent
 * @text Common event afterwards
 * @type common_event
 * @default 0
 *
 * @param matchSeconds
 * @text Time limit (seconds)
 * @type number
 * @min 60
 * @max 300
 * @default 120
 *
 * @command start
 * @text Start Match
 * @desc Your party plays dodgeball against a troop or a team of rival actors.
 *
 * @arg troop
 * @text Opponents: troop
 * @desc The troop whose enemies make the other team. Ignored when Rival actors is set.
 * @type troop
 * @default 1
 *
 * @arg rivals
 * @text Opponents: rival actors
 * @desc A team of actors instead of a troop (side-view sheets). Leave empty to use the troop.
 * @type actor[]
 * @default []
 *
 * @arg ai
 * @text Opponent strength
 * @type select
 * @option Beginner
 * @value beginner
 * @option Easy
 * @value easy
 * @option Normal
 * @value normal
 * @option Hard
 * @value hard
 * @default normal
 *
 * @arg court
 * @text Court
 * @type select
 * @option Schoolyard
 * @value schoolyard
 * @option Beach
 * @value beach
 * @option Castle Courtyard
 * @value castle
 * @option Frozen Pond
 * @value pond
 * @option Tavern Cellar
 * @value cellar
 * @default schoolyard
 *
 * @arg perTeam
 * @text Infielders per side
 * @type select
 * @option 2
 * @value 2
 * @option 3
 * @value 3
 * @option 4
 * @value 4
 * @default 3
 *
 * @arg rounds
 * @text Rounds (best of)
 * @type select
 * @option 1
 * @value 1
 * @option 3
 * @value 3
 * @default 1
 *
 * @arg demo
 * @text Demo (both sides play themselves)
 * @type boolean
 * @default false
 */

var Pelt = Pelt || {};

(function () {
  'use strict';
  var NAME = 'Pelt', RAW = PluginManager.parameters(NAME);
  /** Parameters arrive as strings; blank means absent, never zero (wing §16). */
  function num(v, d) { var s = String(v === undefined || v === null ? '' : v).trim(); if (s === '') return d; var n = Number(s); return isFinite(n) ? n : d; }
  var P = { varWinner: num(RAW.varWinner, 0), swWin: num(RAW.swWin, 0), commonEvent: num(RAW.commonEvent, 0), matchSeconds: Math.max(60, Math.min(300, num(RAW.matchSeconds, 120))) };
  /** The two sibling files, resolved at FIRST USE so the buyer's load order never matters (wing §8 trap 2). */
  function deps() {
    var C = window.PeltCore, D = window.PeltDraw;
    if (!C || !D) throw new Error('Pelt needs PeltCore.js and PeltDraw.js installed and ON.');
    return { C: C, D: D };
  }
  function rec() { if (!$gameSystem._csafPelt) $gameSystem._csafPelt = { v: 1, played: 0, won: 0, last: null }; return $gameSystem._csafPelt; }

  /** Up to three distinct specials from a list of skill ids (PeltCore.specialFrom: element x delivery shape x tier). */
  function specialsFromIds(ids) {
    var C = deps().C, out = [], seen = {};
    for (var i = 0; i < ids.length && out.length < 3; i++) {
      var sp = C.specialFrom($dataSkills[ids[i]], $dataSystem.elements);
      if (!sp) continue; var key = sp.shape + '|' + sp.element; if (seen[key]) continue; seen[key] = true; out.push(sp);
    }
    return out;
  }
  /**
   * An actor's specials: the skills it KNOWS, then the ones its CLASS will learn (level order), then its attack skill.
   * The same order as Bout (Bout.js specialsOf); MEASURED there on the stock database: actors 1-4 know no damaging skill at
   * level 1, so known skills alone gave a day-one match no specials at all.
   */
  function actorSpecials(actor) {
    var ids = [], i, known = actor.skills();
    for (i = 0; i < known.length; i++) ids.push(known[i].id);
    var cls = actor.currentClass(), learn = cls && cls.learnings ? cls.learnings.slice().sort(function (a, b) { return a.level - b.level; }) : [];
    for (i = 0; i < learn.length; i++) ids.push(learn[i].skillId);
    ids.push(actor.attackSkillId());
    return specialsFromIds(ids);
  }
  /** An enemy's specials: the skills in its action patterns, in database order. */
  function enemySpecials(enemy) {
    var ids = []; for (var i = 0; i < (enemy.actions || []).length; i++) ids.push(enemy.actions[i].skillId);
    return specialsFromIds(ids);
  }

  /** n + 1 actors for a side: the given actors first, then the database in id order, never a repeat unless the database
   *  is smaller than the side. `exclude` (the party, for the rival side) applies to the given list too: an actor who is
   *  in your party plays on your side and is never drawn on both ends of the court (MEASURED on the stock database: the
   *  party is actors 1, 4, 6 and 7, so rivals 5-8 put Kasey and Eliot on both teams). */
  function fillActors(first, n1, exclude) {
    var out = [], used = {}, i;
    for (i = 0; i < first.length && out.length < n1; i++) { var a = first[i]; if (a && !used[a.actorId()] && !(exclude && exclude[a.actorId()])) { used[a.actorId()] = true; out.push(a); } }
    for (i = 1; i < $dataActors.length && out.length < n1; i++) if ($dataActors[i] && !used[i] && !(exclude && exclude[i])) { used[i] = true; out.push($gameActors.actor(i)); }
    for (i = 0; out.length < n1 && out.length > 0; i++) out.push(out[i % out.length]);
    return out;
  }
  /** a side's roster entries: { kind: 'actor', actor, name } or { kind: 'enemy', enemy, name }, n + 1 of them */
  function rosterOfActors(list) { return list.map(function (a) { return { kind: 'actor', actor: a, name: a.name() }; }); }
  function rosterOfTroop(troopId, n1) {
    var t = $dataTroops[troopId] || $dataTroops[1], ids = [], i;
    for (i = 0; t && i < t.members.length; i++) if ($dataEnemies[t.members[i].enemyId]) ids.push(t.members[i].enemyId);
    if (!ids.length) for (i = 1; i < $dataEnemies.length && !ids.length; i++) if ($dataEnemies[i]) ids.push(i);
    var out = [], count = {};
    for (i = 0; i < n1; i++) { var e = $dataEnemies[ids[i % ids.length]]; count[e.id] = (count[e.id] || 0) + 1; out.push({ kind: 'enemy', enemy: e, name: e.name }); }
    // two of one enemy are lettered like MZ letters them (Goblin A, Goblin B), so the HUD can tell them apart
    var seen = {}; for (i = 0; i < out.length; i++) { var id = out[i].enemy.id; if (count[id] > 1) { seen[id] = (seen[id] || 0) + 1; out[i].name = out[i].enemy.name + ' ' + String.fromCharCode(64 + seen[id]); } }
    return out;
  }
  /** rival ids from the plugin command arrive as a JSON string of strings; a script call may pass numbers */
  function parseIds(v) {
    if (Array.isArray(v)) return v.map(Number).filter(function (n) { return n > 0; });
    var s = String(v === undefined || v === null ? '' : v).trim(); if (!s) return [];
    try { var a = JSON.parse(s); return Array.isArray(a) ? a.map(Number).filter(function (n) { return n > 0; }) : []; } catch (e) { return []; }
  }

  var pending = null;
  /**
   * Start a match. args: troop (id), rivals (actor ids, overrides troop), ai ('beginner' | 'easy' | 'normal' | 'hard'),
   * court (a court key), perTeam (2..4), rounds (1 | 3), demo (both sides play themselves), seed (optional).
   */
  function start(args) {
    args = args || {};
    var D = deps().D, n = Math.max(2, Math.min(4, num(args.perTeam, 3)));
    var party = $gameParty.members(), partyIds = {}, i;
    for (i = 0; i < party.length; i++) partyIds[party[i].actorId()] = true;
    var home = rosterOfActors(fillActors(party, n + 1, null));
    var rivalIds = parseIds(args.rivals), away;
    if (rivalIds.length) { var rv = []; for (i = 0; i < rivalIds.length; i++) if ($dataActors[rivalIds[i]]) rv.push($gameActors.actor(rivalIds[i])); away = rosterOfActors(fillActors(rv, n + 1, partyIds)); }
    else away = rosterOfTroop(num(args.troop, 1), n + 1);
    var ai = /^(beginner|easy|normal|hard)$/.test(String(args.ai)) ? String(args.ai) : 'normal';
    var rounds = num(args.rounds, 1) === 3 ? 3 : 1;
    var court = D.COURTS[String(args.court || '')] ? String(args.court) : 'schoolyard';
    pending = { home: home, away: away, perTeam: n, ai: ai, rounds: rounds, court: court, demo: args.demo === true || String(args.demo) === 'true', seed: num(args.seed, (Graphics.frameCount * 7919 + rec().played * 104729) | 0) };
    SceneManager.push(Scene_Pelt);
    return true;
  }
  PluginManager.registerCommand(NAME, 'start', function (a) { start(a); });

  /** A 9 x 6 sheet of 64 px cells holding a plain player silhouette, for a battler whose image is blank. */
  function standIn(team) {
    var b = new Bitmap(576, 384), g = b.context, col = team ? '#5a1e2a' : '#1e2a46';
    for (var r = 0; r < 6; r++) for (var c = 0; c < 9; c++) {
      var x = c * 64 + 34, y = r * 64 + 62, lean = ((c + r) % 3 - 1) * 2;
      g.fillStyle = col; g.beginPath(); g.ellipse(x + lean, y - 50, 7, 8, 0, 0, Math.PI * 2); g.fill();
      g.fillRect(x - 8 + lean, y - 42, 16, 24); g.fillRect(x - 8, y - 18, 6, 18); g.fillRect(x + 2, y - 18, 6, 18); g.fillRect(x - 20, y - 38, 12, 5);
    }
    b._baseTexture.update();
    return b;
  }

  //---------------------------------------------------------------------------
  // Scene_Pelt
  //---------------------------------------------------------------------------
  function Scene_Pelt() { this.initialize.apply(this, arguments); }
  Scene_Pelt.prototype = Object.create(Scene_Base.prototype);
  Scene_Pelt.prototype.constructor = Scene_Pelt;

  var LOOP_PAT = [0, 1, 2, 1];   // a looping SV motion cycles 0,1,2,1 (rmmz_sprites.js Sprite_Actor motion patterns)
  var MOTION = { walk: 0, wait: 1, chant: 2, guard: 3, damage: 4, evade: 5, thrust: 6, swing: 7, missile: 8, skill: 9, spell: 10, victory: 13, dying: 14, dead: 17 };
  var ACTOR_ZOOM = 1.9, ENEMY_H = 84, ENEMY_W = 120, BALL_CELL = 48, TRAIL = 5, SPARK_FRAMES = 6, INTRO = 100, ROUND_END = 110;
  var LABELS = ['CATCH!', 'OUT!', 'HIT'];

  Scene_Pelt.prototype.initialize = function () {
    Scene_Base.prototype.initialize.call(this);
    this._req = pending; pending = null; this._built = false; this._own = [];
    this._sheets = [];
    if (!this._req) return;
    var sv = $gameSystem.isSideView(), all = this._req.home.concat(this._req.away);
    for (var i = 0; i < all.length; i++) {
      var R = all[i];
      if (R.kind === 'actor') this._sheets.push(ImageManager.loadSvActor(R.actor.battlerName()));
      else this._sheets.push(sv ? ImageManager.loadSvEnemy(R.enemy.battlerName) : ImageManager.loadEnemy(R.enemy.battlerName));
    }
  };
  Scene_Pelt.prototype.isReady = function () { return Scene_Base.prototype.isReady.call(this) && this._sheets.every(function (b) { return b.isReady(); }); };
  Scene_Pelt.prototype.start = function () { Scene_Base.prototype.start.call(this); if (!this._req) { this.popScene(); return; } this.build(); };
  /** a bitmap this scene made and must free (the engine's cached battler images are never freed here) */
  Scene_Pelt.prototype.own = function (b) { this._own.push(b); return b; };
  Scene_Pelt.prototype.terminate = function () {
    Scene_Base.prototype.terminate.call(this);
    for (var i = 0; i < this._own.length; i++) if (this._own[i]) this._own[i].destroy();
    this._own.length = 0;
  };

  /** Everything per-frame is allocated here: the court, the players, the ball, its trail, sparks, labels, the HUD. */
  Scene_Pelt.prototype.build = function () {
    var d = deps(), C = d.C, D = d.D, W = Graphics.width, H = Graphics.height, q = this._req, i, k;
    this._C = C; this._D = D; this._round = 1; this._wins = [0, 0]; this._need = q.rounds === 3 ? 2 : 1; this._sideView = $gameSystem.isSideView();
    this._phase = 'intro'; this._phaseT = 0; this._done = false; this._doneAge = 0; this._t = 0;
    this._roster = q.home.concat(q.away);
    // the stage: everything that shakes on a hit lives in one container
    this._stage = new Sprite(); this.addChild(this._stage);
    var cb = this.own(new Bitmap(W, H)); this._cam = D.drawCourt(cb.context, q.court, C, W, H, q.seed & 0xffff); cb._baseTexture.update();
    this._stage.addChild(new Sprite(cb));
    // ground shadows (one shared ellipse bitmap), then the field: players and the ball, depth-sorted by court z each frame
    var sh = this.own(new Bitmap(64, 20)); sh.context.fillStyle = 'rgba(0,0,0,0.38)'; sh.context.beginPath(); sh.context.ellipse(32, 10, 30, 8, 0, 0, Math.PI * 2); sh.context.fill(); sh._baseTexture.update();
    this._shadowLayer = new Sprite(); this._stage.addChild(this._shadowLayer);
    this._field = new Sprite(); this._field.sortableChildren = true; this._stage.addChild(this._field);
    this._players = []; this._shadows = [];
    for (i = 0; i < this._roster.length; i++) {
      var R = this._roster[i], team = i < q.perTeam + 1 ? 0 : 1, bmp = this._sheets[i], s;
      if (R.kind === 'actor') {
        // an actor with no side-view battler gets a drawn stand-in figure, never an invisible player. A blank name loads
        // ImageManager._emptyBitmap, which is 1 x 1, not 0 wide (Bout.js, measured there): test the NAME and the size
        if (!R.actor.battlerName() || bmp.width < 9 || bmp.height < 6) bmp = this._sheets[i] = this.own(standIn(team));
        bmp.smooth = false; s = new Sprite(bmp); s._cw = bmp.width / 9; s._ch = bmp.height / 6; s._sv = true;
      } else if (!R.enemy.battlerName || bmp.width < 2 || bmp.height < 2) {
        // an enemy with no image plays as the drawn stand-in sheet, animated like an actor's
        bmp = this._sheets[i] = this.own(standIn(team)); s = new Sprite(bmp); s._cw = 64; s._ch = 64; s._sv = true;
      } else {
        // an enemy image fits a height (ENEMY_H at the court's middle depth), and a wide one a width, whichever is smaller
        s = new Sprite(bmp); s._sv = false; s._fit = Math.min(ENEMY_H / bmp.height, ENEMY_W / bmp.width);
      }
      s.anchor.x = 0.5; s.anchor.y = 1; s._key = -1; s._outAge = 0; s._face = 0;
      this._field.addChild(s); this._players.push(s);
      var ss = new Sprite(sh); ss.anchor.x = 0.5; ss.anchor.y = 0.5; this._shadowLayer.addChild(ss); this._shadows.push(ss);
    }
    // the ball: one atlas cell per look (the plain ball, then each special's element), its shadow and a trail of ghosts
    var els = [null]; for (i = 0; i < this._roster.length; i++) { var sp = this.specialsFor(i); for (k = 0; k < sp.length; k++) if (els.indexOf(sp[k].element) < 0) els.push(sp[k].element); }
    this._ballEls = els;
    var ba = this.own(new Bitmap(BALL_CELL * els.length, BALL_CELL)); for (i = 0; i < els.length; i++) D.drawBallCell(ba.context, i * BALL_CELL + BALL_CELL / 2, BALL_CELL / 2, 12, els[i]); ba._baseTexture.update();
    this._ballShadow = new Sprite(sh); this._ballShadow.anchor.x = 0.5; this._ballShadow.anchor.y = 0.5; this._shadowLayer.addChild(this._ballShadow);
    this._trail = []; this._trailX = []; this._trailY = []; this._trailS = []; this._trailN = 0;
    for (i = 0; i < TRAIL; i++) { var gs = new Sprite(ba); gs.anchor.x = 0.5; gs.anchor.y = 0.5; gs.setFrame(0, 0, BALL_CELL, BALL_CELL); gs.visible = false; gs.opacity = 150 - i * 26; this._field.addChild(gs); this._trail.push(gs); this._trailX.push(0); this._trailY.push(0); this._trailS.push(1); }
    this._ball = new Sprite(ba); this._ball.anchor.x = 0.5; this._ball.anchor.y = 0.5; this._ball.setFrame(0, 0, BALL_CELL, BALL_CELL); this._ballCell = 0; this._field.addChild(this._ball);
    // hit sparks: an atlas row per element, SPARK_FRAMES frames
    var sEls = ['Physical']; for (i = 1; i < els.length; i++) if (sEls.indexOf(els[i]) < 0) sEls.push(els[i]);
    this._sparkEls = sEls;
    var kb = this.own(new Bitmap(96 * SPARK_FRAMES, 96 * sEls.length));
    for (i = 0; i < sEls.length; i++) for (k = 0; k < SPARK_FRAMES; k++) D.drawSpark(kb.context, sEls[i], k * 96 + 48, i * 96 + 48, 26, k / SPARK_FRAMES, i + 1);
    kb._baseTexture.update();
    this._sparks = []; this._sparkNext = 0;
    for (i = 0; i < 6; i++) { var sk = new Sprite(kb); sk.anchor.x = 0.5; sk.anchor.y = 0.5; sk.visible = false; sk._age = -1; sk._row = 0; sk.setFrame(0, 0, 96, 96); sk.zIndex = 10000; this._field.addChild(sk); this._sparks.push(sk); }
    // floating labels (CATCH! / OUT! / HIT) from one atlas, and the gold marker over the human's player
    var lb = this.own(new Bitmap(220, 44 * LABELS.length));
    for (i = 0; i < LABELS.length; i++) D.drawText(lb.context, LABELS[i], 110, i * 44 + 6, i === 2 ? 3 : 4, i === 0 ? { top: [200, 255, 220], bottom: [40, 200, 120] } : i === 1 ? { top: [255, 200, 180], bottom: [230, 40, 30] } : null, 'center');
    lb._baseTexture.update();
    this._labels = []; this._labelNext = 0;
    for (i = 0; i < 4; i++) { var ls = new Sprite(lb); ls.anchor.x = 0.5; ls.anchor.y = 1; ls.visible = false; ls._age = -1; ls.setFrame(0, 0, 220, 44); ls.zIndex = 10001; this._field.addChild(ls); this._labels.push(ls); }
    var mb = this.own(new Bitmap(22, 16)); D.drawMarker(mb.context, 22, 16); mb._baseTexture.update();
    this._marker = new Sprite(mb); this._marker.anchor.x = 0.5; this._marker.anchor.y = 1; this._marker.zIndex = 10002; this._field.addChild(this._marker);
    // HUD and banner: repainted only when what they show changes
    this._hud = new Sprite(this.own(new Bitmap(W, 70))); this.addChild(this._hud); this._hudKey = -1;
    this._banner = new Sprite(this.own(new Bitmap(W, 120))); this._banner.y = Math.round(H * 0.3); this.addChild(this._banner); this._bannerKey = -1;
    this._pt = { x: 0, y: 0, s: 0 }; this._shake = 0; this._hp = []; this._outWas = [];
    this.newMatch();
  };
  /** the specials of roster entry i (a player's own skills) */
  Scene_Pelt.prototype.specialsFor = function (i) {
    var R = this._roster[i]; if (!R._specials) R._specials = R.kind === 'actor' ? actorSpecials(R.actor) : enemySpecials(R.enemy);
    return R._specials;
  };
  /** A fresh match for the current round (allocation here is per round, never per frame). */
  Scene_Pelt.prototype.newMatch = function () {
    var C = this._C, q = this._req, i;
    var specials = []; for (i = 0; i < this._roster.length; i++) specials.push(this.specialsFor(i));
    this._g = C.createMatch({ seed: (q.seed + this._round * 7919) | 0, perTeam: q.perTeam, ai: [q.demo ? q.ai : null, q.ai], frames: P.matchSeconds * 60, specials: specials });
    this._hp.length = 0; this._outWas.length = 0;
    for (i = 0; i < this._g.players.length; i++) { this._hp.push(this._g.players[i].hp); this._outWas.push(false); this._players[i]._outAge = 0; this._players[i].opacity = 255; this._players[i].visible = true; }
    this._throwsWas = 0; this._catchesWas = 0; this._trailN = 0;
    this.place(); this.drawHud(); this.drawBanner();
  };

  /** The SV motion for a core player's state (rmmz_sprites.js Sprite_Actor.MOTIONS), mapped onto dodgeball. */
  Scene_Pelt.prototype.motionOf = function (Pl, holding) {
    var S = this._C.S, M = MOTION;
    switch (Pl.state) {
      case S.OUT: return M.dead;
      case S.WIN: return M.victory;
      case S.HIT: return M.damage;
      case S.STAGGER: return M.dying;
      case S.CATCH: return M.guard;
      case S.DODGE: case S.JUMP: return M.evade;
      case S.WINDUP: return Pl.useSpecial ? M.skill : M.swing;
      case S.RECOVER: return M.swing;
      case S.RUN: return M.walk;
    }
    return holding ? M.chant : M.wait;
  };

  /** One frame. Allocates nothing: every object was made in build(). */
  Scene_Pelt.prototype.update = function () {
    Scene_Base.prototype.update.call(this);
    if (!this._g) return;
    var C = this._C, g = this._g, I = C.INPUT, i;
    // the scene's own clock drives every looping motion: the match clock stops in the intro, between rounds and on the result,
    // and with it every player froze mid-pose (looked at 2026-10-17: the result screen was a still)
    this._t++;
    if (this._done) { this._doneAge++; if (this._doneAge > 60 && (Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered())) this.popScene(); this.place(); return; }
    if (this._phase === 'intro') { if (++this._phaseT >= INTRO) { this._phase = 'play'; this._phaseT = 0; } this.place(); this.drawBanner(); return; }
    if (this._phase === 'roundEnd') { if (++this._phaseT >= ROUND_END) { this._round++; this._phase = 'intro'; this._phaseT = 0; this.newMatch(); } this.place(); this.drawBanner(); return; }
    var inp = 0;
    if (!this._req.demo) {
      if (Input.isPressed('left')) inp |= I.LEFT; if (Input.isPressed('right')) inp |= I.RIGHT; if (Input.isPressed('up')) inp |= I.UP; if (Input.isPressed('down')) inp |= I.DOWN;
      // OK is one context button: the core reads THROW only from a holder and CATCH only from a player without the ball
      if (Input.isTriggered('ok')) inp |= I.THROW | I.CATCH;
      if (Input.isTriggered('cancel')) inp |= I.DODGE;
      if (Input.isTriggered('shift')) inp |= I.JUMP;
      if (Input.isTriggered('pageup') || Input.isTriggered('pagedown')) inp |= I.SPECIAL;
    }
    var B = g.ball, el = B.state === C.BALL.FLIGHT && B.spec ? B.spec.element : null;
    C.step(g, inp, 0);
    // events of this frame, read by comparing against what the scene saw last frame (the core keeps counts, not a log)
    for (i = 0; i < g.players.length; i++) {
      var Pl = g.players[i];
      if (Pl.hp < this._hp[i]) { this.spark(i, el); this.label(i, Pl.out ? 1 : 2); this._shake = Pl.out ? 10 : 5; if (!Pl.out) SoundManager.playEnemyAttack(); }
      if (Pl.out && !this._outWas[i] && Pl.hp >= this._hp[i]) this.label(i, 1);   // out by a catch (no HP lost)
      if (Pl.out && !this._outWas[i]) SoundManager.playEnemyCollapse();
      this._hp[i] = Pl.hp; this._outWas[i] = Pl.out;
    }
    if (g.events.catches > this._catchesWas) { this._catchesWas = g.events.catches; if (B.state === C.BALL.HELD) { this.label(B.holder, 0); SoundManager.playRecovery(); } }
    if (g.events.throws > this._throwsWas) { this._throwsWas = g.events.throws; this._trailN = 0; SoundManager.playCursor(); }
    this.place(); this.drawHud();
    if (g.phase === 'over') this.endMatch();
  };

  /** A hit spark at player i, in the element of what hit it. */
  Scene_Pelt.prototype.spark = function (i, el) {
    var sp = this._sparks[this._sparkNext], row = el ? Math.max(0, this._sparkEls.indexOf(el)) : 0, Pl = this._g.players[i], o = this._pt;
    this._sparkNext = (this._sparkNext + 1) % this._sparks.length;
    this._cam.pt(Pl.x, Pl.z, Pl.h + 34, o);
    sp._row = row; sp._age = 0; sp.visible = true; sp.x = o.x; sp.y = o.y; sp.scale.x = sp.scale.y = 1.1 * o.s / 0.65;
  };
  /** A floating label (0 CATCH!, 1 OUT!, 2 HIT) over player i. */
  Scene_Pelt.prototype.label = function (i, which) {
    var ls = this._labels[this._labelNext], Pl = this._g.players[i], o = this._pt;
    this._labelNext = (this._labelNext + 1) % this._labels.length;
    this._cam.pt(Pl.x, Pl.z, Pl.h + 96, o);
    ls.setFrame(0, which * 44, 220, 44); ls._age = 0; ls._y0 = o.y; ls.x = Math.max(110, Math.min(Graphics.width - 110, o.x)); ls.y = o.y; ls.visible = true; ls.scale.x = ls.scale.y = which === 2 ? 0.7 : 0.85;
  };

  /** Players, shadows, the ball and its trail, sparks, labels and the marker to their places for this frame. */
  Scene_Pelt.prototype.place = function () {
    var C = this._C, g = this._g, cam = this._cam, o = this._pt, S = C.S, B = g.ball, i, t = this._t;
    var human = this._req.demo || this._phase !== 'play' ? -1 : C.controlled(g, 0);
    for (i = 0; i < g.players.length; i++) {
      var Pl = g.players[i], sp = this._players[i], shd = this._shadows[i];
      if (Pl.out) { sp._outAge++; if (sp._outAge > 70) { sp.visible = false; shd.visible = false; continue; } } else sp._outAge = 0;
      sp.visible = true; shd.visible = true;
      cam.pt(Pl.x, Pl.z, Pl.h, o);
      var holding = B.state === C.BALL.HELD && B.holder === i;
      sp.zIndex = Pl.z; sp.x = Math.round(o.x); sp.y = Math.round(o.y);
      sp.opacity = Pl.out ? Math.max(0, 255 - sp._outAge * 3.6) : (Pl.state === S.HIT && (t & 2) ? 170 : 255);
      if (sp._sv) {
        var m = this.motionOf(Pl, holding), loop = m === MOTION.walk || m === MOTION.wait || m === MOTION.guard || m === MOTION.victory || m === MOTION.dying || m === MOTION.chant;
        var pat = loop ? LOOP_PAT[(t / 12 | 0) & 3] : Pl.state === S.WINDUP ? (Pl.mf > 4 ? 0 : 1) : (m === MOTION.dead || Pl.state === S.RECOVER ? 2 : 1);
        var key = m * 4 + pat;
        if (key !== sp._key) { sp._key = key; sp.setFrame(((m / 6 | 0) * 3 + pat) * sp._cw, (m % 6) * sp._ch, sp._cw, sp._ch); }
        // SV sheets face LEFT, so a player facing right is mirrored
        var z = ACTOR_ZOOM * o.s; sp.scale.x = Pl.face > 0 ? -z : z; sp.scale.y = z; sp.rotation = 0;
      } else {
        // an enemy image is not a sheet: a hop when it runs, a lean into its throw, a squash in the catch stance, a topple
        var f = sp._fit * o.s / 0.65, sx = f, sy = f, rot = 0, lift = 0;
        if (Pl.state === S.RUN) lift = Math.abs(Math.sin(t * 0.35)) * 7 * o.s;
        else if (Pl.state === S.WIN) { lift = Math.abs(Math.sin(t * 0.16)) * 14 * o.s; sy = f * (1 + Math.max(0, Math.sin(t * 0.16 + 1.6)) * 0.06); }   // a victory hop
        else if (Pl.state === S.WINDUP) rot = -0.12 * Pl.face; else if (Pl.state === S.RECOVER) rot = 0.18 * Pl.face;
        else if (Pl.state === S.CATCH) { sy = f * 0.88; sx = f * 1.08; } else if (Pl.state === S.DODGE) rot = 0.3 * (Pl.z > 120 ? 1 : -1);
        else if (Pl.state === S.STAGGER) rot = Math.sin(t * 0.4) * 0.14; else if (Pl.state === S.HIT) sp.x += (t & 2 ? 3 : -3);
        else if (Pl.out) rot = Math.min(1.3, sp._outAge * 0.06) * (Pl.team ? 1 : -1);
        // side-view enemy images face RIGHT; front-view images face the viewer and are not mirrored
        var mirror = this._sideView && Pl.face < 0 ? -1 : 1;
        sp.scale.x = sx * mirror; sp.scale.y = sy; sp.rotation = rot; sp.y -= Math.round(lift);
      }
      shd.x = sp.x; cam.pt(Pl.x, Pl.z, 0, o); shd.y = Math.round(o.y); shd.scale.x = shd.scale.y = o.s * 1.2 * Math.max(0.55, 1 - Pl.h / 120);
      if (i === human) { this._marker.visible = true; this._marker.x = sp.x; cam.pt(Pl.x, Pl.z, Pl.h + 104, o); this._marker.y = Math.round(o.y - (t & 16 ? 2 : 0)); }
    }
    if (human < 0) this._marker.visible = false;
    // the ball: its cell is the look of the special in flight (or the plain ball), its shadow always on the floor
    var cell = B.state === C.BALL.FLIGHT && B.spec ? Math.max(0, this._ballEls.indexOf(B.spec.element)) : 0;
    if (cell !== this._ballCell) { this._ballCell = cell; this._ball.setFrame(cell * BALL_CELL, 0, BALL_CELL, BALL_CELL); for (i = 0; i < TRAIL; i++) this._trail[i].setFrame(cell * BALL_CELL, 0, BALL_CELL, BALL_CELL); }
    cam.pt(B.x, B.z, 0, o); this._ballShadow.x = Math.round(o.x); this._ballShadow.y = Math.round(o.y); this._ballShadow.scale.x = this._ballShadow.scale.y = o.s * 0.5 * Math.max(0.5, 1 - B.h / 140);
    cam.pt(B.x, B.z, B.h, o); this._ball.x = Math.round(o.x); this._ball.y = Math.round(o.y); this._ball.scale.x = this._ball.scale.y = o.s * 1.15; this._ball.zIndex = B.z + 0.5;
    // the trail: the last TRAIL screen positions while in flight, sampled every second frame, in a ring the scene owns
    if (B.state === C.BALL.FLIGHT) {
      if ((g.frame & 1) === 0) { for (i = TRAIL - 1; i > 0; i--) { this._trailX[i] = this._trailX[i - 1]; this._trailY[i] = this._trailY[i - 1]; this._trailS[i] = this._trailS[i - 1]; } this._trailX[0] = o.x; this._trailY[0] = o.y; this._trailS[0] = o.s; if (this._trailN < TRAIL) this._trailN++; }
      for (i = 0; i < TRAIL; i++) { var gs = this._trail[i]; gs.visible = i < this._trailN; gs.x = this._trailX[i]; gs.y = this._trailY[i]; gs.scale.x = gs.scale.y = this._trailS[i] * (1.05 - i * 0.14); gs.zIndex = B.z + 0.4; }
    } else for (i = 0; i < TRAIL; i++) this._trail[i].visible = false;
    for (i = 0; i < this._sparks.length; i++) { var sk = this._sparks[i]; if (!sk.visible) continue; var fr = sk._age++ >> 1; if (fr >= SPARK_FRAMES) { sk.visible = false; continue; } sk.setFrame(fr * 96, sk._row * 96, 96, 96); }
    for (i = 0; i < this._labels.length; i++) { var lb = this._labels[i]; if (!lb.visible) continue; var a = lb._age++; if (a > 54) { lb.visible = false; continue; } lb.y = lb._y0 - Math.min(26, a * 1.2); lb.opacity = a > 34 ? 255 - (a - 34) * 12 : 255; }
    // the camera shake on a hit, decaying
    if (this._shake > 0) { this._shake--; this._stage.x = (this._shake & 2 ? 1 : -1) * Math.min(4, this._shake * 0.5); this._stage.y = (this._shake & 1 ? 1 : -1) * Math.min(3, this._shake * 0.3); } else { this._stage.x = 0; this._stage.y = 0; }
  };

  /** The HUD: one card per infielder (name, HP, OUT), each side's meter, the clock; repainted only on a change it shows. */
  Scene_Pelt.prototype.drawHud = function () {
    var C = this._C, g = this._g, n = g.perTeam, key = Math.ceil((g.limit - g.frame) / 60) * 7 + this._wins[0] * 3 + this._wins[1] * 5, i, t;
    var human = this._req.demo ? -1 : C.controlled(g, 0);
    for (i = 0; i < g.players.length; i++) { var Pl = g.players[i]; if (Pl.outfield) continue; key = (key * 31 + Math.round(Pl.hp / 2) + (Pl.out ? 977 : 0) + (i === human ? 4099 : 0)) % 1000000007; }
    var m0 = 0, m1 = 0; for (i = 0; i < g.players.length; i++) { if (g.players[i].team === 0) m0 = Math.max(m0, g.players[i].meter); else m1 = Math.max(m1, g.players[i].meter); }
    key = (key * 31 + (m0 / 12.5 | 0) * 9 + (m1 / 12.5 | 0)) % 1000000007;
    if (key === this._hudKey) return; this._hudKey = key;
    var o = this._hudO;
    if (!o) {
      o = this._hudO = { w: Graphics.width, h: 70, teams: [{ players: [], meter: 0 }, { players: [], meter: 0 }], time: 0, wins: this._wins, need: this._need };
      for (t = 0; t < 2; t++) for (i = 0; i < n; i++) o.teams[t].players.push({ name: '', hp: 1, out: false, on: false });
    }
    for (t = 0; t < 2; t++) for (i = 0; i < n; i++) {
      var idx = t * (n + 1) + i, P2 = g.players[idx], c = o.teams[t].players[i];
      c.name = this._roster[idx].name; c.hp = P2.hp / C.MAX_HP; c.out = P2.out; c.on = idx === human;
    }
    o.teams[0].meter = m0 / 100; o.teams[1].meter = m1 / 100; o.time = (g.limit - g.frame) / 60; o.need = this._need;
    var b = this._hud.bitmap; b.clear(); this._D.drawHud(b.context, o); b._baseTexture.update();
  };

  /** ROUND n, PLAY BALL!, TIME!, the round's winner, the result: painted on a change only. */
  Scene_Pelt.prototype.drawBanner = function () {
    var key, txt = '', sub = '';
    if (this._done) key = 900; else if (this._phase === 'intro') key = this._phaseT < 50 && this._req.rounds > 1 ? 100 + this._round : 200; else if (this._phase === 'roundEnd') key = 300 + this._round; else key = 0;
    if (key === this._bannerKey) return; this._bannerKey = key;
    var b = this._banner.bitmap, W = b.width; b.clear();
    var r = rec().last, g = this._g;
    if (key > 100 && key < 200) txt = 'ROUND ' + this._round; else if (key === 200) txt = 'PLAY BALL!';
    // a side is named by its leader as a TEAM, so the verb agrees ("REID WIN" read as a typo, looked at 2026-10-17)
    else if (key > 300 && key < 400) { txt = g.winner < 0 ? 'DRAW' : g.winner === 0 && !this._req.demo ? 'YOU TAKE IT' : 'TEAM ' + this.sideName(g.winner) + ' TAKES IT'; if (g.frame >= g.limit) sub = 'TIME!'; }
    else if (key === 900 && r) { txt = r.winner === 0 ? 'DRAW' : this._req.demo ? 'TEAM ' + (r.winner === 1 ? this.sideName(0) : this.sideName(1)) + ' WINS' : r.winner === 1 ? 'YOU WIN!' : 'YOU LOSE'; sub = this._req.rounds > 1 ? r.wins[0] + ' - ' + r.wins[1] : ''; }
    if (txt) { var u = Math.min(8, Math.floor((W - 40) / (txt.length * 6))); this._D.drawText(b.context, txt, W / 2, sub ? 8 : 30, u, null, 'center'); }
    if (sub) this._D.drawText(b.context, sub, W / 2, 78, 4, { top: [255, 255, 255], bottom: [200, 210, 230] }, 'center');
    b._baseTexture.update();
  };
  /** a short name for a side: the leader's name for the party side, the first player's for the other */
  Scene_Pelt.prototype.sideName = function (t) { var R = this._roster[t * (this._req.perTeam + 1)]; return String(t === 1 && R.kind === 'enemy' ? R.enemy.name : R.name).toUpperCase().slice(0, 10); };

  /** A match ended: a round to the winner, then either the next round or the result into the game. */
  Scene_Pelt.prototype.endMatch = function () {
    var g = this._g;
    if (g.winner >= 0) this._wins[g.winner]++;
    var decided = this._wins[0] >= this._need || this._wins[1] >= this._need || this._round >= (this._req.rounds === 3 ? 5 : 1);
    if (!decided) { this._phase = 'roundEnd'; this._phaseT = 0; this.drawBanner(); return; }
    var r = rec(), q = this._req, winner = this._wins[0] > this._wins[1] ? 1 : this._wins[1] > this._wins[0] ? 2 : 0;
    // played and won count the player's own matches only: a demo is an exhibition, and counting it in one and not the
    // other made the record's win rate wrong
    this._done = true; this._doneAge = 0; if (!q.demo) { r.played++; if (winner === 1) r.won++; }
    r.last = { winner: winner, rounds: this._round, wins: [this._wins[0], this._wins[1]], court: q.court, ai: q.ai, perTeam: q.perTeam, demo: q.demo };
    if (!q.demo) {
      if (P.varWinner > 0) $gameVariables.setValue(P.varWinner, winner);
      if (P.swWin > 0) $gameSwitches.setValue(P.swWin, winner === 1);
      if (P.commonEvent > 0) $gameTemp.reserveCommonEvent(P.commonEvent);
    }
    if (winner === 1) SoundManager.playSave(); else SoundManager.playBuzzer();
    this.drawBanner();
  };

  Pelt.VERSION = '1.0.0'; Pelt.P = P; Pelt.start = start; Pelt.actorSpecials = actorSpecials; Pelt.enemySpecials = enemySpecials; Pelt.Scene_Pelt = Scene_Pelt;
  Pelt.lastResult = function () { return $gameSystem && $gameSystem._csafPelt ? $gameSystem._csafPelt.last : null; };
  window.Pelt = Pelt; window.Scene_Pelt = Scene_Pelt;
})();
