/*:
 * @target MZ
 * @plugindesc [v1.0.0] Pelt 1/3 - the rules: team dodgeball on a court with a depth lane, throw, catch, dodge, outs and returns, specials from skills. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * PeltCore.js holds the rules Pelt uses and touches no part of the engine. Turn it on together with PeltDraw.js and
 * Pelt.js; the order does not matter. See Readme_for_Users.md.
 */
/* PeltCore - pure rules, no engine code, runs in Node for the tests (module.exports) and in MZ (window.PeltCore).
 * A fixed 60 Hz step. The court runs x = 0..COURT_W left to right with the centre line at COURT_W / 2; z = 0..LANE is the
 * depth lane (0 far, LANE near); h is height above the floor. Team 0 plays the left half, team 1 the right half. Each
 * team's OUTFIELD stands beyond the opponent's baseline and throws in from behind. Everything a match needs is allocated
 * by createMatch; step() allocates nothing (wing §3). Copyright (c) 2026 Core Systems Asset Factory. */
var PeltCore = (function () {
  'use strict';
  // ── seeded randomness: COPIED from Bout_MZ BoutCore.js v1.0.0 lines 16-18 (a buyer of Pelt need not own Bout) ──────
  function mix(a, b) { var h = (a ^ Math.imul(b | 0, 0x9E3779B1)) >>> 0; h = Math.imul(h ^ (h >>> 16), 0x85EBCA6B) >>> 0; h = Math.imul(h ^ (h >>> 13), 0xC2B2AE35) >>> 0; return (h ^ (h >>> 16)) >>> 0; }
  function hashString(s) { var h = 2166136261 >>> 0; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; } return h >>> 0; }
  function rand(st) { st.rs = (st.rs + 0x6D2B79F5) | 0; var t = st.rs; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }

  var COURT_W = 960, LANE = 240, MID = COURT_W / 2, OUT_DEPTH = 56, BODY_R = 18, BODY_H = 56, BALL_R = 8;
  // CATCH_WINDOW 7 + WHIFF_STAGGER 20 (v0.2): a catch stance that ends EMPTY leaves the player off balance, unable to move,
  // catch or dodge. MEASURED (balance_probe.js): with a 10-frame window and no whiff cost, holding CATCH covered 38% of every
  // frame for free and a masher beat a timed newcomer
  var RUN = 3.2, JUMP_V = 9, GRAV = 0.5, FRICTION = 0.93, CATCH_WINDOW = 7, CATCH_RECOVERY = 16, WHIFF_STAGGER = 30, DODGE_FRAMES = 12;
  // HOME_SLACK (v0.3): a computer player with nothing to do walks back to its formation spot until it is within this many px
  var HOME_SLACK = 10;
  var THROW_STARTUP = 8, THROW_RECOVERY = 14, THROW_SPEED = 11, THROW_DAMAGE = 34, HOLD_LIMIT = 240, HIT_STUN = 24, MAX_HP = 100, METER_MAX = 100, SPECIAL_COST = 50;
  var INPUT = { LEFT: 1, RIGHT: 2, UP: 4, DOWN: 8, THROW: 16, CATCH: 32, JUMP: 64, SPECIAL: 128, DODGE: 256 };
  var S = { IDLE: 0, RUN: 1, JUMP: 2, WINDUP: 3, RECOVER: 4, CATCH: 5, DODGE: 6, HIT: 7, OUT: 8, WIN: 9, STAGGER: 10 };
  var BALL = { HELD: 0, FLIGHT: 1, LOOSE: 2 };

  /**
   * special shapes from Bout's table (BoutCore.js v1.0.0 lines 47-51), here as THROW PATHS. v1.0 (2026-10-17): each path is a
   * FLIGHT, not a launch velocity. `apex`: px above the release height the ball peaks at, the arc solved per throw so it
   * comes down at body height ON the target (release()); `low`: thrown skimming the floor at that height (jump to clear it);
   * `reach`: px added to the hit box (a burst catches a sidestep); `drain`: a hit heals the thrower half the damage.
   * MEASURED (_scripts/diag_specials.js, normal vs normal, 30 matches a path): the v0.2 table set a launch speed upward with
   * a gravity, so rising hit 0% (50% passed over the target, 49% landed short), ground-wave 3% (96% short), burst 3% (97%
   * short) and rain 1% (67% over); only the three straight paths ever landed
   */
  var PATHS = {
    projectile: { damage: 34, speed: 13, apex: 0, low: 0, reach: 0 }, rush: { damage: 38, speed: 17, apex: 0, low: 0, reach: 0 },
    rising: { damage: 40, speed: 15, apex: 45, low: 0, reach: 0 }, 'ground-wave': { damage: 30, speed: 12, apex: 0, low: 8, reach: 0 },
    burst: { damage: 36, speed: 12, apex: 0, low: 0, reach: 12 }, rain: { damage: 34, speed: 13, apex: 120, low: 0, reach: 0 },
    'drain-tether': { damage: 26, speed: 12, apex: 0, low: 0, reach: 0, drain: true },
  };
  var HIT_H = 28, ARC_G_MAX = 2;                                          // the height an arc arrives at; its steepest gravity
  /**
   * A special throw from one of the player's own skills (an MZ database row), or null when the skill deals no damage to an
   * enemy. The SHAPE rule is COPIED from Bout_MZ BoutCore.js v1.0.0 specialFrom (lines 60-67); the shape names a throw path.
   * @param {object} s an RPG Maker MZ skill row @param {string[]} elements $dataSystem.elements
   */
  function specialFrom(s, elements) {
    if (!s || !s.damage || (s.damage.type !== 1 && s.damage.type !== 5) || !(s.scope >= 1 && s.scope <= 6)) return null;
    var phys = s.hitType === 1, all = s.scope === 2, rnd = s.scope >= 3 && s.scope <= 6, shape;
    if (s.damage.type === 5) shape = 'drain-tether'; else if (rnd) shape = 'rain'; else if (phys) shape = all ? 'ground-wave' : (s.speed > 0 ? 'rising' : 'rush'); else shape = all ? 'burst' : 'projectile';
    var eid = s.damage.elementId, element = eid > 0 ? String((elements && elements[eid]) || 'Element ' + eid) : eid === -1 ? 'Weapon' : 'None';
    var cost = Number(s.mpCost) || 0, tier = cost >= 25 ? 3 : cost >= 10 ? 2 : 1, B = PATHS[shape];
    return { skillId: s.id, name: String(s.name || ''), shape: shape, element: element, tier: tier, damage: B.damage + 8 * (tier - 1), speed: B.speed, apex: B.apex, low: B.low, reach: B.reach, drain: !!B.drain };
  }

  function player(team, slot, outfield) {
    return { team: team, slot: slot, outfield: outfield, x: 0, z: 0, h: 0, vh: 0, face: team === 0 ? 1 : -1, state: S.IDLE, mf: 0,
      hp: MAX_HP, out: false, cooldown: 0, meter: 0, specials: [], specIdx: 0, useSpecial: false, throws: 0, catches: 0, hits: 0, dodges: 0,
      aiWait: -1, aimJitter: 0, aiPlan: 0, aiPlanFor: -1, aiSeen: 0, holdT: 0 };
  }
  /** a player's formation spot. An outfielder stands behind the OPPONENTS, mid-lane. Team 1 is the MIRROR of team 0
   *  (x -> COURT_W - x). MEASURED 2026-10-16 (side_control.js): the first version placed team 1 with a translation instead,
   *  its slots 0 and 2 120 px from the line where team 0's stood 360 px back, and a normal vs normal match read 46-14 for
   *  team 0 with three times the throws */
  function homeX(P, perTeam) {
    if (P.outfield) return P.team === 0 ? COURT_W + OUT_DEPTH / 2 : -OUT_DEPTH / 2;
    var x0 = MID * (0.25 + 0.5 * (P.slot % 2)); return P.team === 0 ? x0 : COURT_W - x0;
  }
  function homeZ(P, perTeam) { return P.outfield ? LANE * 0.5 : LANE * (P.slot + 0.5) / perTeam; }
  /** put a player on its formation spot, facing back across the court (kick-off and a return from OUT) */
  function home(P, perTeam) {
    P.x = homeX(P, perTeam); P.z = homeZ(P, perTeam);
    if (P.outfield) P.face = P.team === 0 ? -1 : 1;
  }
  /** may player P pick up a ball lying at x? Only inside its own zone (v0.2): an outfielder standing on the baseline used to
   *  reach 26 px INTO the opponents' court and re-take the ball its own hit had just dropped there (diag_possession.js) */
  function inZone(P, x) {
    if (P.outfield) return P.team === 0 ? x >= COURT_W : x <= 0;
    return P.team === 0 ? x < MID : x >= MID;
  }
  /** the box a player may stand in: infield = own half; outfield = the strip beyond the opponent's baseline */
  function clampToZone(P) {
    var x0, x1;
    if (P.outfield) { x0 = P.team === 0 ? COURT_W : -OUT_DEPTH; x1 = P.team === 0 ? COURT_W + OUT_DEPTH : 0; }
    else { x0 = P.team === 0 ? BODY_R : MID + BODY_R; x1 = P.team === 0 ? MID - BODY_R : COURT_W - BODY_R; }
    if (P.x < x0) P.x = x0; if (P.x > x1) P.x = x1;
    if (P.z < 0) P.z = 0; if (P.z > LANE) P.z = LANE;
  }

  /**
   * A match. o: {seed, perTeam (infield players per team, 2-4, default 3), ai: [null|'beginner'|'easy'|'normal'|'hard', same],
   * frames (time limit, default 120 s), specials: [[special,...] per player index]}. Players 0..n-1 are team 0's infield,
   * n is team 0's outfielder, then team 1 the same way.
   */
  function createMatch(o) {
    o = o || {};
    var n = Math.max(2, Math.min(4, o.perTeam | 0 || 3)), g = { perTeam: n, players: [], rs: (o.seed | 0) || 1, frame: 0, limit: o.frames || 7200, winner: -1, phase: 'play', ai: o.ai || [null, 'normal'], events: { catches: 0, hits: 0, outs: 0, returns: 0, throws: 0 } };
    for (var t = 0; t < 2; t++) { for (var i = 0; i < n; i++) g.players.push(player(t, i, false)); g.players.push(player(t, n, true)); }
    for (var k = 0; k < g.players.length; k++) { home(g.players[k], n); if (o.specials && o.specials[k]) g.players[k].specials = o.specials[k]; }
    // the outfielders start OUT of play only in the sense that they are not targets; a caught ball can return an OUT infielder
    g.ball = { state: BALL.HELD, holder: 0, x: 0, z: 0, h: 0, vx: 0, vz: 0, vh: 0, g: 0, reach: 0, thrower: -1, damage: 0, spec: null, age: 0 };
    g.ball.holder = (hashString('pelt|' + g.rs) & 1) ? 0 : n + 1;          // the opening ball goes to a seeded side
    g.inp = []; for (k = 0; k < g.players.length; k++) g.inp.push(0);       // scratch, reused every frame (step allocates nothing)
    g.threatX = [NaN, NaN]; g.human = [-1, -1];                              // scratch, rewritten at the start of every step
    return g;
  }
  function teamOf(g, i) { return g.players[i].team; }
  function infieldAlive(g, t) { var c = 0; for (var i = 0; i < g.players.length; i++) { var P = g.players[i]; if (P.team === t && !P.outfield && !P.out) c++; } return c; }

  /** launch the held ball toward a target point; special = a derived path or null */
  function release(g, i, tx, tz, special) {
    var P = g.players[i], B = g.ball, dx = tx - P.x, dz = tz - P.z, d = Math.sqrt(dx * dx + dz * dz) || 1;
    var speed = special ? special.speed : THROW_SPEED;
    P.face = tx >= P.x ? 1 : -1;                                          // the ball leaves from the side it is thrown toward
    B.state = BALL.FLIGHT; B.holder = -1; B.thrower = i; B.x = P.x + P.face * (BODY_R + BALL_R); B.z = P.z; B.h = 30;
    B.vx = speed * dx / d; B.vz = speed * dz / d; B.vh = 0; B.g = 0; B.reach = 0; B.age = 0;
    if (special) {
      if (special.low) B.h = special.low;
      B.reach = special.reach || 0;
      if (special.apex > 0) {
        // the arc is SOLVED for this throw: it peaks `apex` above the release and comes down at HIT_H when it reaches the
        // target's x, whatever the distance. Peak K above h0 and arrival D = HIT_H - h0 after T frames give the gravity
        // sqrt(g) = (sqrt(2K) + sqrt(2(K - D))) / T and the launch speed sqrt(2gK)
        // T is the REAL flight time (MEASURED, trace_lob.js: a 6-frame floor solved a 46 px lob for 78 px, and it came down 32 px
        // past its target every time); the apex shrinks on a short throw so the arc's gravity never exceeds ARC_G_MAX
        // (a parabola peaking K above its ends over T frames has gravity 8K / T^2)
        var T = Math.max(1, Math.abs(tx - B.x) / Math.max(0.01, Math.abs(B.vx))), K = Math.max(2, Math.min(special.apex, ARC_G_MAX * T * T / 8)), D = HIT_H - B.h;
        var u = (Math.sqrt(2 * K) + Math.sqrt(2 * (K - D))) / T;
        B.g = u * u; B.vh = Math.sqrt(2 * B.g * K);
      }
    }
    // 34 (v0.2, was 22): three hits put a player out. MEASURED (diag_throws.js): at 22 a hit almost never finished anyone
    // (0.1 to 0.3 outs a match by HP against 1.8 to 2.2 by catch), so a side that dodged well gained nothing for it
    B.damage = special ? special.damage : THROW_DAMAGE; B.spec = special;
    P.throws++; g.events.throws++;
  }
  /** can a catch stance take this ball? Only a straight throw at body height: never a lob (an arc) nor a skim along the floor */
  function catchable(B) { return !B.g && !(B.spec && B.spec.low); }
  /** the nearest living opposing infielder to a thrower: the default target */
  function nearestTarget(g, i) {
    var P = g.players[i], best = -1, bd = 1e9;
    for (var k = 0; k < g.players.length; k++) { var Q = g.players[k]; if (Q.team === P.team || Q.outfield || Q.out) continue; var d = Math.abs(Q.x - P.x) + Math.abs(Q.z - P.z) * 0.6; if (d < bd) { bd = d; best = k; } }
    return best;
  }
  /** a caught ball puts the THROWER out (if an infielder) and brings back one OUT teammate of the catcher (the classic rule) */
  function onCatch(g, ci) {
    var C = g.players[ci], B = g.ball, T = g.players[B.thrower];
    C.catches++; g.events.catches++; C.meter = Math.min(METER_MAX, C.meter + 25);
    C.state = S.IDLE; C.mf = 0;                                           // a stance that CATCHES ends there
    B.state = BALL.HELD; B.holder = ci; B.vx = B.vz = B.vh = 0;
    if (!T.outfield && !T.out) { T.out = true; T.state = S.OUT; g.events.outs++; }
    for (var k = 0; k < g.players.length; k++) { var Q = g.players[k]; if (Q.team === C.team && !Q.outfield && Q.out) { Q.out = false; Q.hp = MAX_HP; Q.state = S.IDLE; home(Q, g.perTeam); g.events.returns++; break; } }
  }
  function onHit(g, hi) {
    var H = g.players[hi], B = g.ball, T = g.players[B.thrower];
    H.hp -= B.damage; H.state = S.HIT; H.mf = HIT_STUN; T.hits++; g.events.hits++; T.meter = Math.min(METER_MAX, T.meter + 15);
    if (B.spec && B.spec.drain && !T.out) T.hp = Math.min(MAX_HP, T.hp + Math.round(B.damage / 2));   // a drain throw heals its thrower
    if (H.hp <= 0) { H.hp = 0; H.out = true; H.state = S.OUT; g.events.outs++; }
    // the ball pops UP off the player it hit and drops at their feet, so the side that was hit recovers it. MEASURED v0.1
    // (_scripts/diag_possession.js, masher vs beginner): with the rebound `vx *= -0.35` a hit sent the ball back to the side that
    // threw it, and an outfielder behind the opponents re-took it 10.1 times a match - 10 of that side's 14 throws
    B.state = BALL.LOOSE; B.vx = B.vx * -0.06 + (rand(g) - 0.5) * 1.2; B.vz = (rand(g) - 0.5) * 2.4; B.vh = 6; B.thrower = -1;
  }

  /**
   * A free player turns to face the THREAT: a ball an opponent threw, else an opponent holding the ball, else the opposing
   * side. Stances, wind-ups, stuns and staggers keep the direction they started with (the caller returns before this).
   * MEASURED v0.1 (diag_possession.js): facing was set once at kick-off, so every infielder had its back to the opposing
   * outfielder for the whole match and a throw from behind could be neither caught (the stance must face the ball) nor read.
   */
  function faceThreat(g, P) {
    var src = g.threatX[P.team];
    if (src === src) { P.face = src > P.x ? 1 : -1; return; }
    P.face = P.outfield ? (P.team === 0 ? -1 : 1) : (P.team === 0 ? 1 : -1);
  }
  /** the x of the threat to team t at the start of this frame, or NaN for none (an outfielder's x can be negative, so no
   *  sentinel number is safe): a ball the other side threw, else the other side holding the ball */
  function snapThreat(g, t) {
    var B = g.ball;
    g.threatX[t] = B.state === BALL.FLIGHT && B.thrower >= 0 && g.players[B.thrower].team !== t ? B.x
      : B.state === BALL.HELD && g.players[B.holder].team !== t ? g.players[B.holder].x : NaN;
  }
  function updatePlayer(g, i, inp) {
    var P = g.players[i];
    if (P.out) return;
    if (P.cooldown > 0) P.cooldown--;
    if (P.h > 0 || P.vh) { P.h += P.vh; P.vh -= GRAV; if (P.h <= 0) { P.h = 0; P.vh = 0; if (P.state === S.JUMP) P.state = S.IDLE; } }
    if (P.state === S.HIT) { if (--P.mf <= 0) P.state = S.IDLE; return; }
    if (P.state === S.WINDUP) {
      if (--P.mf <= 0) {
        var t = nearestTarget(g, i), Q = t >= 0 ? g.players[t] : null;
        // a player's specials take turns (v1.0): the first special throw uses its first skill, the next one its second.
        // MEASURED 2026-10-17: Pelt.js hands the core up to three specials a player and the core only ever threw [0]
        var sp = P.useSpecial && P.specials.length ? P.specials[P.specIdx % P.specials.length] : null;
        if (sp) { P.meter -= SPECIAL_COST; P.specIdx++; }
        release(g, i, Q ? Q.x : P.x + P.face * 300, (Q ? Q.z : P.z) + P.aimJitter, sp);
        P.useSpecial = false; P.aimJitter = 0; P.state = S.RECOVER; P.mf = THROW_RECOVERY;
      }
      return;
    }
    // the cooldown keeps counting on its own: a catch or dodge that ends does NOT clear it (anti-mash, CATCH_RECOVERY).
    // A catch stance that runs out EMPTY becomes a STAGGER (a successful catch leaves the stance in onCatch, never here)
    if (P.state === S.CATCH) { if (--P.mf <= 0) { P.state = S.STAGGER; P.mf = WHIFF_STAGGER; } return; }
    if (P.state === S.RECOVER || P.state === S.DODGE || P.state === S.STAGGER) { if (--P.mf <= 0) P.state = S.IDLE; else return; }
    var B = g.ball, holding = B.state === BALL.HELD && B.holder === i;
    faceThreat(g, P);
    // a holder who has not thrown within HOLD_LIMIT frames throws anyway (v0.2). MEASURED (side_control.js arm a): a human who
    // held the ball and never threw froze the match to the time limit, 0.0 throws by that side over 120 matches
    if (holding) { if (++P.holdT >= HOLD_LIMIT) inp |= INPUT.THROW; } else P.holdT = 0;
    if (holding && (inp & (INPUT.THROW | INPUT.SPECIAL))) { P.state = S.WINDUP; P.mf = THROW_STARTUP; P.useSpecial = !!(inp & INPUT.SPECIAL) && P.meter >= SPECIAL_COST && P.specials.length > 0; return; }
    if (!holding && (inp & INPUT.CATCH) && P.cooldown === 0) { P.state = S.CATCH; P.mf = CATCH_WINDOW; P.cooldown = CATCH_WINDOW + CATCH_RECOVERY; return; }
    if (!holding && (inp & INPUT.DODGE) && P.cooldown === 0) { P.state = S.DODGE; P.mf = DODGE_FRAMES; P.cooldown = DODGE_FRAMES + CATCH_RECOVERY; P.dodges++; return; }
    if ((inp & INPUT.JUMP) && P.h === 0) { P.vh = JUMP_V; P.h = 0.01; P.state = S.JUMP; }
    var mx = ((inp & INPUT.RIGHT) ? 1 : 0) - ((inp & INPUT.LEFT) ? 1 : 0), mz = ((inp & INPUT.DOWN) ? 1 : 0) - ((inp & INPUT.UP) ? 1 : 0);
    P.x += mx * RUN; P.z += mz * RUN * 0.7;
    if (P.state !== S.JUMP) P.state = mx || mz ? S.RUN : S.IDLE;
    clampToZone(P);
  }

  function updateBall(g) {
    var B = g.ball;
    if (B.state === BALL.HELD) { var H = g.players[B.holder]; B.x = H.x + H.face * BODY_R; B.z = H.z; B.h = H.h + 30; return; }
    var h0 = B.h;                                                         // the height this frame starts at (the swept test)
    B.x += B.vx; B.z += B.vz; B.h += B.vh; B.age++;
    if (B.state === BALL.FLIGHT) {
      if (B.g) B.vh -= B.g;                                               // an arc's own gravity, solved in release()
      var T = g.players[B.thrower];
      for (var k = 0; k < g.players.length; k++) {
        var Q = g.players[k];
        if (Q.team === T.team || Q.outfield || Q.out) continue;
        // the height test is SWEPT over this frame's drop (h0 -> h): MEASURED (_scratch/trace_lob.js) a steep lob thrown from
        // 78 px fell from 164-190 px to below the floor in one frame and passed through the body without a hit, every time
        if (Math.abs(Q.x - B.x) > BODY_R + BALL_R + B.reach || Math.abs(Q.z - B.z) > BODY_R + B.reach || Math.max(h0, B.h) < Q.h || Math.min(h0, B.h) > Q.h + BODY_H) continue;
        if (Q.state === S.DODGE) continue;                                    // a dodge lets it pass
        // a LOB (an arc: rising, rain) comes down from above and a SKIM (ground-wave) runs along the floor: neither can be
        // caught, only dodged (a skim can be jumped). MEASURED (diag_specials.js): a catchable lob was caught 39% and hit
        // 11-22%, and a catchable skim hit 46% for less damage, both worse than a plain throw (47-50%): the special was a penalty
        if (Q.state === S.CATCH && catchable(B) && Math.sign(B.vx) === -Q.face) { onCatch(g, k); return; }
        onHit(g, k); return;
      }
      // the floor is tested AFTER the players: a ball that reaches a body and the floor in the same frame hit the body first
      if (B.h <= 0) { B.h = 0; B.state = BALL.LOOSE; B.vh = 3; B.thrower = -1; return; }
      if (B.x < -OUT_DEPTH || B.x > COURT_W + OUT_DEPTH) { B.state = BALL.LOOSE; B.vx = -B.vx * 0.3; B.thrower = -1; }
      return;
    }
    // LOOSE: rolls and bounces to rest; the first eligible player who reaches it picks it up
    B.vh -= GRAV; if (B.h <= 0) { B.h = 0; B.vh = Math.abs(B.vh) > 1.5 ? -B.vh * 0.45 : 0; }
    B.vx *= FRICTION; B.vz *= FRICTION;
    if (B.z < 0) { B.z = 0; B.vz = -B.vz; } if (B.z > LANE) { B.z = LANE; B.vz = -B.vz; }
    if (B.x < -OUT_DEPTH) { B.x = -OUT_DEPTH; B.vx = -B.vx; } if (B.x > COURT_W + OUT_DEPTH) { B.x = COURT_W + OUT_DEPTH; B.vx = -B.vx; }
    for (var j = 0; j < g.players.length; j++) {
      var R = g.players[j];
      if (R.out || R.state === S.HIT || !inZone(R, B.x)) continue;
      if (Math.abs(R.x - B.x) < BODY_R + BALL_R && Math.abs(R.z - B.z) < BODY_R && B.h < 20) { B.state = BALL.HELD; B.holder = j; B.vx = B.vz = B.vh = 0; return; }
    }
  }

  // The table, not the rules, set the masher result (2026-10-16): a human's throw is auto-aimed with ZERO error and ZERO wait,
  // so a "hard" computer that waited 7-14 frames and missed by up to 6 px was slower and less accurate than mashing.
  // Three rule changes were measured first and reverted (a whiffed-catch penalty, teammate strength, wind-up power).
  // v0.2 adds `read`: how many frames before an incoming ball arrives the computer starts to react (it sidesteps at most
  // read x 2.24 px, so a beginner reading 10 frames ahead barely clears its own body). See the v0.2 table in balance_probe.js
  // beginner picked by _scripts/exp_ai.js (160 seeds): a SLOW but accurate thrower that catches now and then separates a
  // masher (40%) from a newcomer (69%); the inaccurate one (aim 34) never punished a masher's missing defence (58%)
  // v0.3 replaces `read` with `lag`, a REACTION TIME: the computer sees an incoming ball lag .. 1.5 x lag frames after it is
  // thrown, then sidesteps or takes the catch stance. MEASURED (_scratch/compare.js): with the players back in formation every
  // throw crossed 180-360 px, and a computer that starts reacting `read` frames BEFORE impact always had time, so infield
  // throws hit 0% (normal vs normal) and 15 of 40 matches ran to the time limit. A reaction time makes distance matter: a
  // throw from close in beats the reaction, a throw from the back line does not. `runUp`: px short of the centre line a
  // computer holder walks up to while it waits to throw (the competent human's habit, profiles.js). The v0.3 rows were picked
  // by _scripts/exp_v03.js over 100 matches per cell on BOTH seed families (beginner runUp 140 + catchP 0.20 took the masher
  // from 45% to 37-41% against it while a newcomer stayed at 80-85%); the readings are in balance_v03a.txt / balance_v03b.txt
  var AI = { beginner: { react: 40, catchP: 0.2, aim: 20, lag: 16, runUp: 140 }, easy: { react: 18, catchP: 0.3, aim: 22, lag: 11, runUp: 120 }, normal: { react: 10, catchP: 0.5, aim: 12, lag: 10, runUp: 80 }, hard: { react: 5, catchP: 0.78, aim: 4, lag: 6, runUp: 60 } };
  /** the computer's input for player i (allocates nothing) */
  function aiInput(g, i, level) {
    var P = g.players[i], B = g.ball, L = AI[level] || AI.normal, inp = 0;
    if (P.out) return 0;
    // holding: wait a SEEDED number of frames (react .. 2 x react), then throw with a SEEDED aim error of up to +/- aim px in
    // depth. MEASURED 2026-10-16: with a frame-locked wait and the aim setting unused, 8 seeds played only 3 distinct matches.
    if (B.state === BALL.HELD && B.holder === i) {
      if (P.aiWait < 0) P.aiWait = L.react + Math.floor(rand(g) * L.react);
      if (--P.aiWait <= 0) { P.aiWait = -1; P.aimJitter = (rand(g) - 0.5) * 2 * L.aim; inp |= (P.meter >= SPECIAL_COST && P.specials.length ? INPUT.SPECIAL : INPUT.THROW); return inp; }
      // an infielder walks up toward the centre line while it waits (v0.3, runUp)
      if (!P.outfield && (P.team === 0 ? MID - P.x : P.x - MID) > L.runUp) inp |= P.team === 0 ? INPUT.RIGHT : INPUT.LEFT;
      return inp;
    }
    if (B.state === BALL.FLIGHT && B.thrower >= 0 && g.players[B.thrower].team !== P.team && !P.outfield) {
      // decide ONCE per incoming ball (keyed by the throw count): CATCH (hold ground, stance on arrival) with the strength's
      // probability, otherwise EVADE (sidestep out of its line). MEASURED 2026-10-16: deciding at eta < 6 after a sidestep
      // that started at eta < 20 meant the computer was never in the ball's path when it chose to catch: 0 catches in 20 seeds.
      var dx = (B.x - P.x) * -P.face, eta = B.vx ? Math.abs((B.x - P.x) / B.vx) : 99;
      // a lob or a skim cannot be caught, so the computer always sidesteps one (the draw is still taken: same seed sequence)
      if (P.aiPlanFor !== g.events.throws) { P.aiPlanFor = g.events.throws; var pr = rand(g); P.aiPlan = catchable(B) && pr < L.catchP ? 1 : 2; P.aiSeen = g.frame + L.lag + Math.floor(rand(g) * L.lag * 0.5); }
      if (dx < 0 && Math.abs(B.z - P.z) < BODY_R + 6 && g.frame >= P.aiSeen) {
        if (P.aiPlan === 1) { if (eta <= 4 && P.cooldown === 0) inp |= INPUT.CATCH; }
        else inp |= B.z > P.z ? INPUT.UP : INPUT.DOWN;
      }
      return inp;
    }
    // a loose ball is chased by ONE player: the nearest of the team that may pick it up there. Everyone else walks back to
    // the formation spot (v0.3). MEASURED (_probe/overlap.js, 40 seeds, normal, 3 a side): when every free player chased the
    // ball and nobody ever went back, two sprites covered each other on 57% of frames (an infielder in front of the opposing
    // outfielder on 45.7%, two teammates on 28.2%), in runs of up to 2823 frames
    if (B.state === BALL.LOOSE && chaserFor(g, P.team) === i) {
      inp |= B.x > P.x + 2 ? INPUT.RIGHT : B.x < P.x - 2 ? INPUT.LEFT : 0; inp |= B.z > P.z + 2 ? INPUT.DOWN : B.z < P.z - 2 ? INPUT.UP : 0;
      return inp;
    }
    var hx = homeX(P, g.perTeam), hz = homeZ(P, g.perTeam);
    inp |= hx > P.x + HOME_SLACK ? INPUT.RIGHT : hx < P.x - HOME_SLACK ? INPUT.LEFT : 0;
    inp |= hz > P.z + HOME_SLACK ? INPUT.DOWN : hz < P.z - HOME_SLACK ? INPUT.UP : 0;
    return inp;
  }
  /** the one COMPUTER player of team t who goes after a loose ball: the nearest that is in play, allowed to pick it up where
   *  it lies (inZone) and not the human's player, or -1 (allocates nothing). The human's player is skipped so a teammate still
   *  fetches a ball the human leaves alone. MEASURED (balance_probe.js on the first v0.3 cut): with the human's player as the
   *  only chaser, a masher who never moves left the ball loose on its side and 30% of masher-vs-beginner matches ran to the
   *  time limit as draws */
  function chaserFor(g, t) {
    var B = g.ball, best = -1, bd = 1e9, hu = g.human[t];
    for (var k = 0; k < g.players.length; k++) { var Q = g.players[k]; if (Q.team !== t || Q.out || k === hu || !inZone(Q, B.x)) continue; var d = Math.abs(Q.x - B.x) + Math.abs(Q.z - B.z); if (d < bd) { bd = d; best = k; } }
    return best;
  }

  /** one frame. inputs: [team 0 human input bits, team 1 human input bits] for the CONTROLLED player of each team (the
   *  infielder nearest the ball, or the holder); every other player, and a whole team whose ai is set, is the computer. */
  function controlled(g, t) {
    var B = g.ball;
    if (B.state === BALL.HELD && g.players[B.holder].team === t) return B.holder;
    var best = -1, bd = 1e9;
    for (var k = 0; k < g.players.length; k++) { var P = g.players[k]; if (P.team !== t || P.out || P.outfield) continue; var d = Math.abs(P.x - B.x) + Math.abs(P.z - B.z); if (d < bd) { bd = d; best = k; } }
    return best;
  }
  function step(g, in0, in1) {
    if (g.phase !== 'play') return g;
    g.frame++;
    var c0 = controlled(g, 0), c1 = controlled(g, 1), i, P, inp = g.inp;
    // ORDER-INDEPENDENT by construction (v0.2): every player's facing and every computer decision is read from the state at
    // the START of the frame, before anyone acts. MEASURED (_scripts/bisect_mirror.js): reading live state, a ball released by
    // team 0 was seen by team 1 in the same frame and the reverse a frame later; normal vs normal read 35-84, and reversing the
    // update loop flipped it to 85-35
    snapThreat(g, 0); snapThreat(g, 1);
    g.human[0] = g.ai[0] ? -1 : c0; g.human[1] = g.ai[1] ? -1 : c1;
    for (i = 0; i < g.players.length; i++) {
      P = g.players[i]; var lvl = g.ai[P.team];
      var human = i === g.human[P.team];
      // a human's computer teammates play at the OPPONENT's strength (a fair match). MEASURED 2026-10-16: with teammates fixed
      // at 'normal', every human profile faced a beginner team with normal teammates and the probe measured the teammates
      inp[i] = human ? (P.team === 0 ? in0 : in1) : aiInput(g, i, lvl || g.ai[1 - P.team] || 'normal');
    }
    for (i = 0; i < g.players.length; i++) updatePlayer(g, i, inp[i]);
    updateBall(g);
    var a0 = infieldAlive(g, 0), a1 = infieldAlive(g, 1);
    if (a0 === 0 || a1 === 0 || g.frame >= g.limit) {
      g.phase = 'over';
      g.winner = a0 === a1 ? (hpOf(g, 0) === hpOf(g, 1) ? -1 : hpOf(g, 0) > hpOf(g, 1) ? 0 : 1) : a0 > a1 ? 0 : 1;
      // the winning side celebrates (the scene draws S.WIN as MZ's victory motion). MEASURED 2026-10-17: nothing ever set WIN,
      // so the scene's victory branch was dead code and the winners stood frozen in whatever pose the last frame left them
      if (g.winner >= 0) for (i = 0; i < g.players.length; i++) { P = g.players[i]; if (P.team === g.winner && !P.out) { P.state = S.WIN; P.h = 0; P.vh = 0; } }
    }
    return g;
  }
  function hpOf(g, t) { var s = 0; for (var i = 0; i < g.players.length; i++) { var P = g.players[i]; if (P.team === t && !P.outfield && !P.out) s += P.hp; } return s; }

  var api = { VERSION: '1.0.0', COURT_W: COURT_W, LANE: LANE, MID: MID, OUT_DEPTH: OUT_DEPTH, BODY_R: BODY_R, BODY_H: BODY_H, MAX_HP: MAX_HP,
    CATCH_WINDOW: CATCH_WINDOW, CATCH_RECOVERY: CATCH_RECOVERY, WHIFF_STAGGER: WHIFF_STAGGER, HOLD_LIMIT: HOLD_LIMIT, THROW_STARTUP: THROW_STARTUP, SPECIAL_COST: SPECIAL_COST, THROW_DAMAGE: THROW_DAMAGE, THROW_SPEED: THROW_SPEED,
    INPUT: INPUT, S: S, BALL: BALL, PATHS: PATHS, AI: AI,
    mix: mix, hashString: hashString, rand: rand, specialFrom: specialFrom, createMatch: createMatch, step: step, aiInput: aiInput,
    controlled: controlled, infieldAlive: infieldAlive, release: release, nearestTarget: nearestTarget, clampToZone: clampToZone, catchable: catchable, HIT_H: HIT_H, ARC_G_MAX: ARC_G_MAX };
  return api;
})();
if (typeof module !== 'undefined' && module.exports) module.exports = PeltCore;
if (typeof window !== 'undefined') window.PeltCore = PeltCore;
