/*:
 * @target MZ
 * @plugindesc [v1.0.0] Pelt 2/3 - the drawing: five courts, the ball, sparks, the HUD and arcade lettering. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * PeltDraw.js holds the drawing Pelt uses and touches no part of the engine. Turn it on together with PeltCore.js and
 * Pelt.js; the order does not matter. See Readme_for_Users.md.
 */
/* PeltDraw - pure Canvas 2D drawing, no engine code: every function takes a CanvasRenderingContext2D. Runs in MZ
 * (window.PeltDraw) and in a headless page for the store plates. Copyright (c) 2026 Core Systems Asset Factory. */
var PeltDraw = (function () {
  'use strict';
  // ── colour helpers: COPIED from Bout_MZ BoutDraw.js v1.0.0 lines 15-17 (a buyer of Pelt need not own Bout), with ONE
  // change: the final `>>> 0`. MEASURED 2026-10-16 (Internal_Ops/_probe/gap_rate.js): Bout's version returns values in
  // [-0.5, 0.5) because `h ^ (h >>> 16)` is a SIGNED 32-bit int, so a test of `< 0.04` skipped 24-31 of 48 line segments
  function hash(a, b, s) { var h = (Math.imul(a | 0, 374761393) + Math.imul(b | 0, 668265263) + Math.imul(s | 0, 2147483647)) >>> 0; h = Math.imul(h ^ (h >>> 13), 1274126177) >>> 0; return ((h ^ (h >>> 16)) >>> 0) / 4294967296; }
  function rgb(c, a) { return 'rgba(' + Math.round(c[0]) + ',' + Math.round(c[1]) + ',' + Math.round(c[2]) + ',' + (a === undefined ? 1 : a) + ')'; }
  function mix(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }

  /**
   * The camera: court x (-OUT_DEPTH .. COURT_W + OUT_DEPTH) and depth z (0 far .. LANE near) to the screen, a gentle
   * perspective toward the far side. One object per screen size, made once (no allocation per frame); `pt` writes into `out`.
   */
  function camera(core, w, h) {
    var span = core.COURT_W + core.OUT_DEPTH * 2, cx = w / 2, xc = core.COURT_W / 2;
    // the court's far line sits BELOW the backdrop's foot (FLOOR_MARGIN px of asphalt beyond it); the first look had them touch
    var sNear = (w * 0.98) / span, sFar = sNear * 0.74, yFar = h * 0.40, yNear = h * 0.93;
    return {
      w: w, h: h, yFar: yFar, yNear: yNear,
      scale: function (z) { return sFar + (sNear - sFar) * (z / core.LANE); },
      y: function (z) { return yFar + (yNear - yFar) * (z / core.LANE); },
      pt: function (x, z, hgt, out) { var s = this.scale(z); out.x = cx + (x - xc) * s; out.y = this.y(z) - (hgt || 0) * s; out.s = s; return out; },
    };
  }

  var COURTS = {
    schoolyard: { name: 'Schoolyard', sky: [[240, 196, 140], [120, 150, 190]], floor: [72, 74, 80], line: [236, 232, 214], brick: [150, 70, 52] },
    beach: { name: 'Beach', sky: [[250, 236, 206], [96, 170, 226]], floor: [226, 200, 150], line: [150, 118, 78], sea: [[40, 120, 170], [90, 180, 200]], rope: [196, 160, 100] },
    castle: { name: 'Castle Courtyard', sky: [[120, 90, 120], [26, 30, 70]], floor: [112, 106, 104], line: [236, 230, 214], stone: [118, 112, 116], banner: [[168, 34, 40], [34, 64, 140]] },
    pond: { name: 'Frozen Pond', sky: [[226, 234, 242], [150, 178, 206]], floor: [150, 196, 222], red: [176, 30, 40], blue: [30, 70, 170], pines: [[150, 168, 188], [84, 112, 128], [38, 62, 70]] },
    cellar: { name: 'Tavern Cellar', floor: [120, 80, 50], wood: [130, 86, 54], brick: [112, 64, 46], line: [240, 236, 222] },
  };
  /** the beach: a sea horizon with glints and a far headland instead of a wall */
  function backdropBeach(g, C, cam, seed) {
    var w = cam.w, top = cam.yFar - FLOOR_MARGIN, hz = top * 0.52, i;
    var sky = g.createLinearGradient(0, 0, 0, hz); sky.addColorStop(0, rgb(C.sky[1])); sky.addColorStop(1, rgb(C.sky[0])); g.fillStyle = sky; g.fillRect(0, 0, w, hz);
    // a headland on the left horizon, two cloud banks
    g.fillStyle = rgb([92, 120, 110]); g.beginPath(); g.moveTo(0, hz); g.lineTo(0, hz - 34); g.quadraticCurveTo(w * 0.12, hz - 52, w * 0.24, hz - 12); g.lineTo(w * 0.3, hz); g.closePath(); g.fill();
    g.fillStyle = 'rgba(255,255,255,0.75)'; for (i = 0; i < 2; i++) { var cx = w * (0.55 + i * 0.25), cy = hz * (0.35 + i * 0.12); for (var k = 0; k < 5; k++) { g.beginPath(); g.ellipse(cx + (k - 2) * 26, cy + Math.abs(k - 2) * 4, 30, 12, 0, 0, Math.PI * 2); g.fill(); } }
    // the sea: deep at the horizon, lighter toward the shore, glints in rows
    var sea = g.createLinearGradient(0, hz, 0, top); sea.addColorStop(0, rgb(C.sea[0])); sea.addColorStop(1, rgb(C.sea[1])); g.fillStyle = sea; g.fillRect(0, hz, w, top - hz);
    g.fillStyle = 'rgba(255,255,255,0.55)'; for (i = 0; i < 90; i++) { var gx = hash(i, 31, seed) * w, gy = hz + 3 + Math.pow(hash(i, 32, seed), 1.5) * (top - hz - 10), gw = 4 + (gy - hz) / (top - hz) * 14; g.fillRect(gx, gy, gw, 1.5); }
    // surf: a broken white line where the sea meets the sand
    g.fillStyle = 'rgba(255,255,255,0.85)'; for (i = 0; i < w; i += 6) { var sh = 2 + hash(i, 33, seed) * 4; g.fillRect(i, top - 3 - sh * 0.5, 6, sh); }
  }
  /** the sand: warm with ripples and grains; the court is GROOVED into the sand, the centre line is a rope on two posts */
  function floorBeach(g, C, cam, core, seed) {
    var w = cam.w, h = cam.h, P = { x: 0, y: 0, s: 0 }, Q = { x: 0, y: 0, s: 0 }, i;
    var f0 = cam.yFar - FLOOR_MARGIN, fl = g.createLinearGradient(0, f0, 0, h); fl.addColorStop(0, rgb(mix(C.floor, [250, 240, 210], 0.3))); fl.addColorStop(1, rgb(mix(C.floor, [160, 120, 80], 0.35)));
    g.fillStyle = fl; g.fillRect(0, f0, w, h - f0);
    // ripples: gentle wavy darker strokes, wider apart toward the viewer
    // ripples in broken runs of varying length and wavelength (the first look read as ruled paper: full-width, even lines)
    g.strokeStyle = 'rgba(150,110,70,0.16)'; g.lineWidth = 1.1;
    for (i = 0; i < 70; i++) {
      var y = f0 + Math.pow(hash(i, 48, seed), 1.2) * (h - f0), amp = 1.2 + (y - f0) / (h - f0) * 2.6, x0 = hash(i, 49, seed) * w, len = 60 + hash(i, 50, seed) * 220, k = 0.025 + hash(i, 51, seed) * 0.02;
      g.beginPath(); for (var x = x0; x <= x0 + len; x += 6) { var yy = y + Math.sin(x * k + i) * amp; if (x === x0) g.moveTo(x, yy); else g.lineTo(x, yy); } g.stroke();
    }
    for (i = 0; i < 1800; i++) { var gx = hash(i, 41, seed) * w, gy = f0 + hash(i, 42, seed) * (h - f0); g.fillStyle = hash(i, 43, seed) < 0.5 ? 'rgba(255,250,235,0.35)' : 'rgba(120,90,50,0.25)'; g.fillRect(gx, gy, 1.2, 1.2); }
    // shells and pebbles, a few
    for (i = 0; i < 14; i++) { var sx = hash(i, 44, seed) * w, sy = f0 + 30 + hash(i, 45, seed) * (h - f0 - 40); g.fillStyle = hash(i, 46, seed) < 0.5 ? 'rgba(250,236,226,0.95)' : 'rgba(110,100,95,0.9)'; g.beginPath(); g.ellipse(sx, sy, 3 + hash(i, 47, seed) * 3, 2, 0, 0, Math.PI * 2); g.fill(); }
    // grooves drawn in the sand with a stick: a dark trough with a light lip on its near side
    var groove = function (x0, z0, x1, z1, wid) {
      cam.pt(x0, z0, 0, P); cam.pt(x1, z1, 0, Q);
      // the first look could barely find the court: a deeper, wider trough and a brighter lip
      g.lineCap = 'round'; g.strokeStyle = rgb(mix(C.line, [80, 56, 30], 0.35), 0.8); g.lineWidth = wid * 1.6 * (P.s + Q.s) / 2; g.beginPath(); g.moveTo(P.x, P.y); g.lineTo(Q.x, Q.y); g.stroke();
      g.strokeStyle = 'rgba(255,250,230,0.7)'; g.lineWidth = 1.6; g.beginPath(); g.moveTo(P.x, P.y + wid * P.s * 0.9); g.lineTo(Q.x, Q.y + wid * Q.s * 0.9); g.stroke();
    };
    var W = core.COURT_W, L = core.LANE, O = core.OUT_DEPTH;
    groove(0, 0, W, 0, 4); groove(0, L, W, L, 4); groove(0, 0, 0, L, 4); groove(W, 0, W, L, 4);
    groove(-O, 0, 0, 0, 3); groove(-O, L, 0, L, 3); groove(W, 0, W + O, 0, 3); groove(W, L, W + O, L, 3);
    // the rope: two posts and a sagging twisted rope low across the centre (it is the line, not a net)
    var postH = 34, xm = W / 2;
    for (var e = 0; e < 2; e++) { cam.pt(xm, e ? L + 8 : -8, 0, P); g.fillStyle = 'rgba(0,0,0,0.25)'; g.beginPath(); g.ellipse(P.x + 6 * P.s, P.y, 8 * P.s, 3 * P.s, 0, 0, Math.PI * 2); g.fill(); g.fillStyle = rgb([110, 80, 52]); g.fillRect(P.x - 3 * P.s, P.y - postH * P.s, 6 * P.s, postH * P.s); }
    var steps = 40, prev = null;
    for (i = 0; i <= steps; i++) { var z = -8 + (L + 16) * i / steps, sag = Math.sin(Math.PI * i / steps) * 14; cam.pt(xm, z, postH - 4 - sag, P); if (prev) { g.strokeStyle = rgb(C.rope); g.lineWidth = 3.2 * P.s; g.beginPath(); g.moveTo(prev.x, prev.y); g.lineTo(P.x, P.y); g.stroke(); g.strokeStyle = 'rgba(90,60,30,0.6)'; g.lineWidth = 1; g.beginPath(); g.moveTo(prev.x - 1.5 * P.s, prev.y); g.lineTo(P.x + 1.5 * P.s, P.y - 1); g.stroke(); } prev = { x: P.x, y: P.y }; }
    // its shadow on the sand
    g.strokeStyle = 'rgba(0,0,0,0.18)'; g.lineWidth = 3; cam.pt(xm, 0, 0, P); cam.pt(xm, L, 0, Q); g.beginPath(); g.moveTo(P.x + 10 * P.s, P.y); g.lineTo(Q.x + 10 * Q.s, Q.y); g.stroke();
  }
  /** the backdrop behind the far edge of the court: a brick school wall with windows, a chain-link fence in front */
  var FLOOR_MARGIN = 22;
  function backdropSchoolyard(g, C, cam, seed) {
    var w = cam.w, top = cam.yFar - FLOOR_MARGIN, i, j;
    var sky = g.createLinearGradient(0, 0, 0, top); sky.addColorStop(0, rgb(C.sky[1])); sky.addColorStop(1, rgb(C.sky[0])); g.fillStyle = sky; g.fillRect(0, 0, w, top);
    // the wall: bricks in courses, each brick its own tint, mortar showing between
    var wallTop = top * 0.28, bh = 9, bw = 22;
    g.fillStyle = rgb(mix(C.brick, [60, 50, 46], 0.55)); g.fillRect(0, wallTop, w, top - wallTop);
    for (j = 0; wallTop + j * bh < top; j++) for (i = -1; i * bw < w; i++) {
      var off = (j & 1) ? bw / 2 : 0, t = hash(i, j, seed);
      g.fillStyle = rgb(mix(C.brick, [190, 120, 90], t * 0.35)); g.fillRect(i * bw + off + 1, wallTop + j * bh + 1, bw - 2, bh - 2);
    }
    // windows: tall, evenly spaced, warm glass with a cross frame
    for (i = 0; i < 6; i++) {
      var wx = w * (0.08 + i * 0.16), wy = wallTop + (top - wallTop) * 0.18, ww = w * 0.07, wh = (top - wallTop) * 0.5;
      g.fillStyle = rgb([40, 36, 40]); g.fillRect(wx - 3, wy - 3, ww + 6, wh + 6);
      var gl = g.createLinearGradient(wx, wy, wx + ww, wy + wh); gl.addColorStop(0, rgb([250, 214, 150])); gl.addColorStop(1, rgb([150, 120, 110])); g.fillStyle = gl; g.fillRect(wx, wy, ww, wh);
      g.fillStyle = rgb([40, 36, 40]); g.fillRect(wx + ww / 2 - 1.5, wy, 3, wh); g.fillRect(wx, wy + wh * 0.45, ww, 3);
    }
    // the wall's foot in shadow, then a chain-link fence across the whole width at the far edge of the court
    var foot = g.createLinearGradient(0, top - 26, 0, top); foot.addColorStop(0, 'rgba(0,0,0,0)'); foot.addColorStop(1, 'rgba(0,0,0,0.45)'); g.fillStyle = foot; g.fillRect(0, top - 26, w, 26);
    var fTop = top - 70; g.strokeStyle = 'rgba(40,44,48,0.55)'; g.lineWidth = 1;
    for (i = -80; i < w + 80; i += 10) { g.beginPath(); g.moveTo(i, fTop); g.lineTo(i + 70, top); g.stroke(); g.beginPath(); g.moveTo(i + 70, fTop); g.lineTo(i, top); g.stroke(); }
    g.fillStyle = rgb([58, 62, 66]); for (i = 0; i <= 8; i++) g.fillRect(w * i / 8 - 2, fTop - 4, 4, 74);
    g.fillRect(0, fTop - 5, w, 3);
  }
  /** the floor: asphalt with grain and cracks, and the court painted on it in worn lines */
  function floorSchoolyard(g, C, cam, core, seed) {
    var w = cam.w, h = cam.h, P = { x: 0, y: 0, s: 0 }, Q = { x: 0, y: 0, s: 0 }, i;
    var f0 = cam.yFar - FLOOR_MARGIN, fl = g.createLinearGradient(0, f0, 0, h); fl.addColorStop(0, rgb(mix(C.floor, [120, 124, 130], 0.25))); fl.addColorStop(1, rgb(mix(C.floor, [20, 20, 24], 0.35)));
    g.fillStyle = fl; g.fillRect(0, f0, w, h - f0);
    // grain: small light and dark flecks, denser toward the viewer (they are larger there)
    for (i = 0; i < 2600; i++) { var fx = hash(i, 1, seed) * w, fy = cam.yFar + Math.pow(hash(i, 2, seed), 0.8) * (h - cam.yFar), r = 0.5 + (fy - cam.yFar) / (h - cam.yFar) * 1.2; g.fillStyle = hash(i, 3, seed) < 0.5 ? 'rgba(255,255,255,0.07)' : 'rgba(0,0,0,0.16)'; g.fillRect(fx, fy, r, r); }
    // cracks: a few wandering lines
    g.strokeStyle = 'rgba(20,20,22,0.55)'; g.lineWidth = 1;
    // short, kinked cracks (the first look had one run as a long straight scratch)
    for (i = 0; i < 9; i++) { var x = hash(i, 4, seed) * w, y = cam.yFar + 20 + hash(i, 5, seed) * (h - cam.yFar - 40); g.beginPath(); g.moveTo(x, y); for (var k = 0; k < 4; k++) { x += (hash(i, 10 + k, seed) - 0.5) * 22; y += (hash(i, 20 + k, seed) - 0.5) * 9; g.lineTo(x, y); } g.stroke(); }
    // the painted court: boundary, centre line, outfield lines, worn (broken into dashes where the paint has gone)
    var line = function (x0, z0, x1, z1, wid) {
      // worn, not dashed: short segments, few and short gaps (the first look read as road markings at 12% of 24)
      var n = 48; g.strokeStyle = rgb(C.line, 0.85); g.lineCap = 'butt';
      for (var s = 0; s < n; s++) { if (hash(Math.round(x0 + z0 * 7), s, seed + 99) < 0.04) continue; var a = s / n, b = (s + 1) / n; cam.pt(x0 + (x1 - x0) * a, z0 + (z1 - z0) * a, 0, P); cam.pt(x0 + (x1 - x0) * b, z0 + (z1 - z0) * b, 0, Q); g.lineWidth = wid * P.s; g.beginPath(); g.moveTo(P.x, P.y); g.lineTo(Q.x, Q.y); g.stroke(); }
    };
    var W = core.COURT_W, L = core.LANE, O = core.OUT_DEPTH;
    line(0, 0, W, 0, 5); line(0, L, W, L, 5); line(0, 0, 0, L, 5); line(W, 0, W, L, 5); line(W / 2, 0, W / 2, L, 6);
    line(-O, 0, 0, 0, 3); line(-O, L, 0, L, 3); line(W, 0, W + O, 0, 3); line(W, L, W + O, L, 3);
    // a painted centre circle, flattened by the perspective
    // a circle lying on the floor reads WIDE and flat under this camera (the first look drew it tall: wrong radius)
    cam.pt(W / 2, L / 2, 0, P); g.strokeStyle = rgb(C.line, 0.8); g.lineWidth = 4 * P.s; g.beginPath(); g.ellipse(P.x, P.y, 70 * P.s, 70 * P.s * 0.42, 0, 0, Math.PI * 2); g.stroke();
  }
  // ── shared floor helpers ────────────────────────────────────────────────────────────────────────────────────────────
  /** fill the court-space rectangle [x0, x1] x [z0, z1] as its projected trapezoid (the camera keeps straight lines straight) */
  function quad(g, cam, x0, z0, x1, z1, P, Q) {
    g.beginPath(); cam.pt(x0, z0, 0, P); g.moveTo(P.x, P.y); cam.pt(x1, z0, 0, Q); g.lineTo(Q.x, Q.y);
    cam.pt(x1, z1, 0, P); g.lineTo(P.x, P.y); cam.pt(x0, z1, 0, Q); g.lineTo(Q.x, Q.y); g.closePath();
  }
  /** the court-space x range and z range that cover the whole floor area of the screen (for tiling a floor material) */
  function floorSpan(cam, core) {
    var f0 = cam.yFar - FLOOR_MARGIN, zf = (f0 - cam.yFar) / (cam.yNear - cam.yFar) * core.LANE, zn = (cam.h - cam.yFar) / (cam.yNear - cam.yFar) * core.LANE;
    var sF = cam.scale(zf), half = cam.w / 2 / sF + 40;
    return { x0: core.COURT_W / 2 - half, x1: core.COURT_W / 2 + half, z0: zf - 2, z1: zn + 2, f0: f0 };
  }
  /** a chalk line in court space: a rough stroke built from short jittered segments, slightly lighter at its core */
  function chalk(g, cam, x0, z0, x1, z1, wid, col, seed, P, Q) {
    // one segment per ~24 court units: the first look gave a 56-unit outfield line the same 40 jittered segments as the 960-unit
    // baseline, and at 1.4 units a segment the jitter drew a scribble at every corner of the court
    var len = Math.sqrt((x1 - x0) * (x1 - x0) + (z1 - z0) * (z1 - z0)), n = Math.max(3, Math.round(len / 24)), k = Math.round(x0 * 3 + z0 * 7 + x1 + z1 * 5);
    g.lineCap = 'round';
    for (var pass = 0; pass < 2; pass++) {
      g.strokeStyle = pass ? rgb(mix(col, [255, 255, 255], 0.5), 0.55) : rgb(col, 0.78);
      for (var s = 0; s < n; s++) {
        if (hash(k, s, seed + 7) < 0.05) continue;
        var a = s / n, b = (s + 1) / n, j0 = (hash(k, s, seed + 11) - 0.5) * 2.2, j1 = (hash(k, s + 1, seed + 11) - 0.5) * 2.2;
        cam.pt(x0 + (x1 - x0) * a, z0 + (z1 - z0) * a + j0, 0, P); cam.pt(x0 + (x1 - x0) * b, z0 + (z1 - z0) * b + j1, 0, Q);
        g.lineWidth = (pass ? wid * 0.4 : wid) * P.s; g.beginPath(); g.moveTo(P.x, P.y); g.lineTo(Q.x, Q.y); g.stroke();
      }
    }
  }
  /** the standard court markings through any line function: boundary, centre line, the two outfield strips */
  function markings(line, core) {
    var W = core.COURT_W, L = core.LANE, O = core.OUT_DEPTH;
    line(0, 0, W, 0, 5); line(0, L, W, L, 5); line(0, 0, 0, L, 5); line(W, 0, W, L, 5); line(W / 2, 0, W / 2, L, 6);
    line(-O, 0, 0, 0, 3); line(-O, L, 0, L, 3); line(W, 0, W + O, 0, 3); line(W, L, W + O, L, 3);
  }
  /** a warm pool of light on the floor (torch, lantern): an ellipse in screen space under a court point */
  function lightPool(g, cam, x, z, r, col, a, P) {
    cam.pt(x, z, 0, P); var rx = r * P.s, ry = r * P.s * 0.42, gr = g.createRadialGradient(P.x, P.y, 0, P.x, P.y, rx);
    gr.addColorStop(0, rgb(col, a)); gr.addColorStop(1, rgb(col, 0));
    g.save(); g.translate(P.x, P.y); g.scale(1, ry / rx); g.translate(-P.x, -P.y); g.fillStyle = gr; g.beginPath(); g.arc(P.x, P.y, rx, 0, Math.PI * 2); g.fill(); g.restore();
  }

  // ── CASTLE COURTYARD: a crenellated curtain wall with a gatehouse and torches over flagstones, chalked court ─────────
  function backdropCastle(g, C, cam, seed) {
    var w = cam.w, top = cam.yFar - FLOOR_MARGIN, i, j;
    var sky = g.createLinearGradient(0, 0, 0, top); sky.addColorStop(0, rgb(C.sky[1])); sky.addColorStop(0.75, rgb(C.sky[0])); sky.addColorStop(1, rgb([240, 150, 90])); g.fillStyle = sky; g.fillRect(0, 0, w, top);
    for (i = 0; i < 60; i++) { var sx = hash(i, 61, seed) * w, sy = hash(i, 62, seed) * top * 0.5, sr = 0.6 + hash(i, 63, seed) * 1.1; g.fillStyle = 'rgba(255,250,230,' + (0.35 + hash(i, 64, seed) * 0.5) + ')'; g.fillRect(sx, sy, sr, sr); }
    g.fillStyle = 'rgba(255,246,220,0.95)'; g.beginPath(); g.arc(w * 0.82, top * 0.2, 13, 0, Math.PI * 2); g.fill();
    g.fillStyle = rgb(C.sky[1]); g.beginPath(); g.arc(w * 0.82 + 6, top * 0.2 - 3, 11, 0, Math.PI * 2); g.fill();
    // the curtain wall: ashlar courses, each block its own tint, with merlons along its top
    var wallTop = top * 0.36, bh = 12, stone = C.stone;
    g.fillStyle = rgb(mix(stone, [20, 18, 26], 0.6)); g.fillRect(0, wallTop, w, top - wallTop);
    for (j = 0; wallTop + j * bh < top; j++) for (i = -1; i * 34 < w; i++) {
      var off = (j & 1) ? 17 : 0, bw = 34 - (hash(i, j, seed + 3) < 0.3 ? 8 : 0), t = hash(i, j, seed + 4);
      g.fillStyle = rgb(mix(stone, [190, 180, 170], t * 0.3)); g.fillRect(i * 34 + off + 1, wallTop + j * bh + 1, bw - 2, bh - 2);
    }
    for (i = 0; i * 30 < w + 30; i++) { if (i & 1) continue; var mx = i * 30 - 8; g.fillStyle = rgb(mix(stone, [200, 190, 180], 0.12)); g.fillRect(mx, wallTop - 16, 26, 17); g.fillStyle = 'rgba(0,0,0,0.25)'; g.fillRect(mx + 22, wallTop - 16, 4, 17); }
    // the gatehouse: a taller block in the middle with an arched gate, a portcullis and a dark passage beyond
    var gx = w / 2, gw = w * 0.2, gTop = wallTop - 46;
    g.fillStyle = rgb(mix(stone, [30, 26, 34], 0.35)); g.fillRect(gx - gw / 2, gTop, gw, top - gTop);
    for (i = 0; i < 4; i++) { g.fillStyle = rgb(mix(stone, [200, 190, 180], 0.1)); g.fillRect(gx - gw / 2 + i * gw / 3.5, gTop - 14, gw / 7, 15); }
    var aw = gw * 0.5, ab = top - 4, at = gTop + 40;
    g.fillStyle = rgb([16, 12, 18]); g.beginPath(); g.moveTo(gx - aw / 2, ab); g.lineTo(gx - aw / 2, at + aw / 2); g.arc(gx, at + aw / 2, aw / 2, Math.PI, 0); g.lineTo(gx + aw / 2, ab); g.closePath(); g.fill();
    g.save(); g.clip(); g.strokeStyle = 'rgba(70,64,60,0.95)'; g.lineWidth = 2.4;
    for (i = -6; i <= 6; i++) { g.beginPath(); g.moveTo(gx + i * aw / 10, at); g.lineTo(gx + i * aw / 10, ab - 18); g.stroke(); }
    for (j = 0; j < 9; j++) { g.beginPath(); g.moveTo(gx - aw / 2, at + 8 + j * 9); g.lineTo(gx + aw / 2, at + 8 + j * 9); g.stroke(); }
    g.restore();
    g.strokeStyle = rgb(mix(stone, [220, 210, 200], 0.2)); g.lineWidth = 3; g.beginPath(); g.arc(gx, at + aw / 2, aw / 2 + 2, Math.PI, 0); g.stroke();
    // banners either side of the gate (red and blue fields with a white chevron) and two torches with their glow
    for (var b = 0; b < 2; b++) {
      var bx = gx + (b ? 1 : -1) * gw * 0.95, by = wallTop + 6, bwid = 30, bht = (top - wallTop) * 0.62, col = b ? C.banner[1] : C.banner[0];
      g.fillStyle = rgb(col); g.beginPath(); g.moveTo(bx - bwid / 2, by); g.lineTo(bx + bwid / 2, by); g.lineTo(bx + bwid / 2, by + bht); g.lineTo(bx, by + bht - 10); g.lineTo(bx - bwid / 2, by + bht); g.closePath(); g.fill();
      g.strokeStyle = 'rgba(250,240,220,0.9)'; g.lineWidth = 4; g.beginPath(); g.moveTo(bx - bwid / 2 + 3, by + bht * 0.5); g.lineTo(bx, by + bht * 0.3); g.lineTo(bx + bwid / 2 - 3, by + bht * 0.5); g.stroke();
      g.fillStyle = 'rgba(0,0,0,0.25)'; g.fillRect(bx + bwid / 2 - 5, by, 5, bht - 4);
      g.fillStyle = rgb([60, 50, 44]); g.fillRect(bx - bwid / 2 - 3, by - 3, bwid + 6, 4);
      var tx = gx + (b ? 1 : -1) * w * 0.33, ty = wallTop + (top - wallTop) * 0.4;
      var glow = g.createRadialGradient(tx, ty - 8, 0, tx, ty - 8, 60); glow.addColorStop(0, 'rgba(255,190,90,0.55)'); glow.addColorStop(1, 'rgba(255,140,60,0)'); g.fillStyle = glow; g.fillRect(tx - 60, ty - 68, 120, 120);
      g.fillStyle = rgb([40, 34, 30]); g.fillRect(tx - 2, ty - 2, 4, 18); g.fillRect(tx - 7, ty - 4, 14, 4);
      g.fillStyle = 'rgba(255,220,120,0.95)'; g.beginPath(); g.moveTo(tx - 6, ty - 4); g.quadraticCurveTo(tx - 4, ty - 20, tx, ty - 26); g.quadraticCurveTo(tx + 5, ty - 16, tx + 6, ty - 4); g.closePath(); g.fill();
      g.fillStyle = 'rgba(255,140,40,0.9)'; g.beginPath(); g.moveTo(tx - 3, ty - 4); g.quadraticCurveTo(tx, ty - 16, tx + 3, ty - 4); g.closePath(); g.fill();
    }
    var foot = g.createLinearGradient(0, top - 22, 0, top); foot.addColorStop(0, 'rgba(0,0,0,0)'); foot.addColorStop(1, 'rgba(0,0,0,0.5)'); g.fillStyle = foot; g.fillRect(0, top - 22, w, 22);
  }
  function floorCastle(g, C, cam, core, seed) {
    var P = { x: 0, y: 0, s: 0 }, Q = { x: 0, y: 0, s: 0 }, sp = floorSpan(cam, core), i, j;
    g.fillStyle = rgb(mix(C.floor, [20, 18, 24], 0.55)); g.fillRect(0, sp.f0, cam.w, cam.h - sp.f0);
    // flagstones in courses along the depth lane: each course its own row height, stones of varied length, own tint
    var z = sp.z0, row = 0;
    while (z < sp.z1) {
      var rh = 30 + hash(row, 71, seed) * 14, x = sp.x0 - hash(row, 72, seed) * 60, col = 0;
      while (x < sp.x1) {
        var sw = 46 + hash(row, col + 100, seed) * 50, t = hash(row, col, seed + 73);
        quad(g, cam, x + 2.5, z + 2, x + sw - 2.5, z + rh - 2, P, Q);
        g.fillStyle = rgb(mix(C.floor, t < 0.5 ? [150, 140, 130] : [70, 66, 72], Math.abs(t - 0.5) * 0.7)); g.fill();
        if (hash(row, col, seed + 74) < 0.22) { quad(g, cam, x + 6, z + 5, x + sw * 0.6, z + rh * 0.55, P, Q); g.fillStyle = 'rgba(255,255,255,0.05)'; g.fill(); }
        x += sw; col++;
      }
      z += rh; row++;
    }
    // the outfield strips worn darker (they are walked on all match)
    quad(g, cam, -core.OUT_DEPTH, 0, 0, core.LANE, P, Q); g.fillStyle = 'rgba(10,8,14,0.22)'; g.fill();
    quad(g, cam, core.COURT_W, 0, core.COURT_W + core.OUT_DEPTH, core.LANE, P, Q); g.fill();
    // torchlight falling on the far edge of the court, then the chalked court
    lightPool(g, cam, core.COURT_W * 0.17, -6, 230, [255, 170, 80], 0.32, P); lightPool(g, cam, core.COURT_W * 0.83, -6, 230, [255, 170, 80], 0.32, P);
    markings(function (x0, z0, x1, z1, wid) { chalk(g, cam, x0, z0, x1, z1, wid, C.line, seed, P, Q); }, core);
    cam.pt(core.COURT_W / 2, core.LANE / 2, 0, P); g.strokeStyle = rgb(C.line, 0.7); g.lineWidth = 4 * P.s; g.beginPath(); g.ellipse(P.x, P.y, 64 * P.s, 64 * P.s * 0.42, 0, 0, Math.PI * 2); g.stroke();
  }

  // ── FROZEN POND: layered snowy pines on a bank over clear ice, the court painted UNDER the ice ─────────────────────────
  function backdropPond(g, C, cam, seed) {
    var w = cam.w, top = cam.yFar - FLOOR_MARGIN, i, L;
    var sky = g.createLinearGradient(0, 0, 0, top); sky.addColorStop(0, rgb(C.sky[1])); sky.addColorStop(1, rgb(C.sky[0])); g.fillStyle = sky; g.fillRect(0, 0, w, top);
    var sun = g.createRadialGradient(w * 0.24, top * 0.3, 0, w * 0.24, top * 0.3, 70); sun.addColorStop(0, 'rgba(255,250,235,0.95)'); sun.addColorStop(0.25, 'rgba(255,245,220,0.6)'); sun.addColorStop(1, 'rgba(255,240,220,0)'); g.fillStyle = sun; g.fillRect(0, 0, w, top);
    // three layers of pines, each nearer layer darker, larger and lower, each tree with a snow cap on its tiers
    for (L = 0; L < 3; L++) {
      var base = top - 18 + L * 6, hgt = 50 + L * 26, step = 26 + L * 12, col = C.pines[L];
      g.fillStyle = rgb(col); g.fillRect(0, base - 6, w, top - base + 6);
      for (i = -1; i * step < w + step; i++) {
        var tx = i * step + hash(i, 80 + L, seed) * step * 0.6, th = hgt * (0.7 + hash(i, 83 + L, seed) * 0.5), tw = th * 0.42;
        for (var k = 0; k < 3; k++) {
          var ty = base - th + k * th * 0.28, ww = tw * (0.45 + k * 0.28);
          g.fillStyle = rgb(col); g.beginPath(); g.moveTo(tx, ty); g.lineTo(tx + ww, ty + th * 0.42); g.lineTo(tx - ww, ty + th * 0.42); g.closePath(); g.fill();
          g.fillStyle = rgb(mix([250, 252, 255], col, L * 0.12), 0.92); g.beginPath(); g.moveTo(tx, ty); g.lineTo(tx + ww * 0.45, ty + th * 0.17); g.lineTo(tx, ty + th * 0.13); g.lineTo(tx - ww * 0.45, ty + th * 0.17); g.closePath(); g.fill();
        }
      }
    }
    // the snow bank along the pond's far edge: a soft white mound with blue shading underneath
    g.fillStyle = rgb([236, 242, 250]); g.beginPath(); g.moveTo(0, top);
    for (i = 0; i <= w; i += 16) g.lineTo(i, top - 12 - Math.sin(i * 0.013 + seed) * 5 - hash(i, 86, seed) * 3);
    g.lineTo(w, top); g.closePath(); g.fill();
    var bs = g.createLinearGradient(0, top - 8, 0, top); bs.addColorStop(0, 'rgba(160,190,225,0)'); bs.addColorStop(1, 'rgba(140,175,215,0.7)'); g.fillStyle = bs; g.fillRect(0, top - 8, w, 8);
    // falling snow, drawn once (the scene adds nothing per frame for it)
    g.fillStyle = 'rgba(255,255,255,0.8)'; for (i = 0; i < 110; i++) { var fx = hash(i, 87, seed) * w, fy = hash(i, 88, seed) * top, fr = 0.8 + hash(i, 89, seed) * 1.6; g.beginPath(); g.arc(fx, fy, fr, 0, Math.PI * 2); g.fill(); }
  }
  function floorPond(g, C, cam, core, seed) {
    var w = cam.w, h = cam.h, P = { x: 0, y: 0, s: 0 }, Q = { x: 0, y: 0, s: 0 }, sp = floorSpan(cam, core), i, k;
    var ice = g.createLinearGradient(0, sp.f0, 0, h); ice.addColorStop(0, rgb([196, 222, 238])); ice.addColorStop(0.5, rgb(C.floor)); ice.addColorStop(1, rgb(mix(C.floor, [30, 70, 110], 0.45)));
    g.fillStyle = ice; g.fillRect(0, sp.f0, w, h - sp.f0);
    // the court painted UNDER the ice: deep red boundary and outfield lines, a blue double centre line, a red circle
    var under = function (x0, z0, x1, z1, wid, col) { cam.pt(x0, z0, 0, P); cam.pt(x1, z1, 0, Q); g.strokeStyle = rgb(col, 0.62); g.lineWidth = wid * (P.s + Q.s) / 2; g.lineCap = 'butt'; g.beginPath(); g.moveTo(P.x, P.y); g.lineTo(Q.x, Q.y); g.stroke(); };
    var W = core.COURT_W, L = core.LANE, O = core.OUT_DEPTH;
    quad(g, cam, -O, 0, 0, L, P, Q); g.fillStyle = 'rgba(200,40,50,0.08)'; g.fill(); quad(g, cam, W, 0, W + O, L, P, Q); g.fill();
    markings(function (x0, z0, x1, z1, wid) { if (x0 === W / 2 && x1 === W / 2) { under(W / 2 - 7, z0, W / 2 - 7, z1, 3.5, C.blue); under(W / 2 + 7, z0, W / 2 + 7, z1, 3.5, C.blue); } else under(x0, z0, x1, z1, wid, C.red); }, core);
    cam.pt(W / 2, L / 2, 0, P); g.strokeStyle = rgb(C.red, 0.55); g.lineWidth = 3.5 * P.s; g.beginPath(); g.ellipse(P.x, P.y, 62 * P.s, 62 * P.s * 0.42, 0, 0, Math.PI * 2); g.stroke();
    g.fillStyle = rgb(C.red, 0.6); g.beginPath(); g.ellipse(P.x, P.y, 7 * P.s, 7 * P.s * 0.42, 0, 0, Math.PI * 2); g.fill();
    // a frost veil over the paint (it is under the ice), then the reflection band of the sky
    g.fillStyle = 'rgba(235,245,252,0.16)'; g.fillRect(0, sp.f0, w, h - sp.f0);
    var refl = g.createLinearGradient(0, sp.f0, 0, sp.f0 + 70); refl.addColorStop(0, 'rgba(255,255,255,0.35)'); refl.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = refl; g.fillRect(0, sp.f0, w, 70);
    // skate scratches: long thin arcs, white; cracks: short branching lines, darker blue with a white edge
    g.lineWidth = 1;
    for (i = 0; i < 46; i++) {
      var cx = hash(i, 90, seed) * w, cy = sp.f0 + 12 + Math.pow(hash(i, 91, seed), 0.9) * (h - sp.f0 - 12), r = 60 + hash(i, 92, seed) * 160, a0 = hash(i, 93, seed) * Math.PI * 2;
      g.strokeStyle = 'rgba(255,255,255,' + (0.18 + hash(i, 94, seed) * 0.22) + ')'; g.beginPath(); g.ellipse(cx, cy, r, r * 0.3, 0, a0, a0 + 0.6 + hash(i, 95, seed) * 0.9); g.stroke();
    }
    for (i = 0; i < 7; i++) {
      var x = hash(i, 96, seed) * w, y = sp.f0 + 30 + hash(i, 97, seed) * (h - sp.f0 - 50);
      for (var br = 0; br < 3; br++) {
        var px = x, py = y, ang = hash(i, 98 + br, seed) * Math.PI * 2;
        g.beginPath(); g.moveTo(px, py);
        for (k = 0; k < 5; k++) { ang += (hash(i * 7 + br, k, seed + 99) - 0.5) * 1.1; px += Math.cos(ang) * 9; py += Math.sin(ang) * 3.5; g.lineTo(px, py); }
        g.strokeStyle = 'rgba(60,110,150,0.55)'; g.lineWidth = 1.2; g.stroke(); g.strokeStyle = 'rgba(255,255,255,0.45)'; g.lineWidth = 0.6; g.stroke();
      }
    }
    // powder snow drifted onto the edges of the ice and the outfield strips
    for (i = 0; i < 700; i++) {
      var sx = hash(i, 101, seed) * w, sy = sp.f0 + hash(i, 102, seed) * (h - sp.f0), edge = Math.min(sx, w - sx) / w;
      if (hash(i, 103, seed) > 0.35 + (0.5 - edge) * 1.2) continue;
      g.fillStyle = 'rgba(250,252,255,' + (0.25 + hash(i, 104, seed) * 0.45) + ')'; g.beginPath(); g.ellipse(sx, sy, 1.5 + hash(i, 105, seed) * 4, 1 + hash(i, 106, seed) * 1.6, 0, 0, Math.PI * 2); g.fill();
    }
  }

  // ── TAVERN CELLAR: indoors, a vaulted brick wall with barrel racks and lanterns over plank boards, a chalked court ─────
  function backdropCellar(g, C, cam, seed) {
    var w = cam.w, top = cam.yFar - FLOOR_MARGIN, i, j, a;
    g.fillStyle = rgb([24, 16, 14]); g.fillRect(0, 0, w, top);
    // brick wall, warm and dim; three round arches with barrel racks inside
    var bh = 10, bw = 24;
    for (j = 0; j * bh < top; j++) for (i = -1; i * bw < w; i++) { var off = (j & 1) ? bw / 2 : 0, t = hash(i, j, seed + 111); g.fillStyle = rgb(mix(C.brick, [40, 26, 20], 0.35 + t * 0.35)); g.fillRect(i * bw + off + 1, j * bh + 1, bw - 2, bh - 2); }
    for (a = 0; a < 3; a++) {
      var ax = w * (0.2 + a * 0.3), aw = w * 0.21, ab = top - 2, at = top * 0.3;
      g.fillStyle = rgb([14, 9, 8]); g.beginPath(); g.moveTo(ax - aw / 2, ab); g.lineTo(ax - aw / 2, at + aw / 2); g.arc(ax, at + aw / 2, aw / 2, Math.PI, 0); g.lineTo(ax + aw / 2, ab); g.closePath(); g.fill();
      g.save(); g.clip();
      // barrels on their sides in a rack: rows of round ends with hoops, staves and a bung
      var br = aw * 0.13;
      for (j = 0; j < 3; j++) for (i = 0; i < 4 - (j & 1); i++) {
        var bx = ax - aw / 2 + br * 1.25 + i * br * 2.15 + ((j & 1) ? br * 1.07 : 0), by = ab - br - j * br * 1.86;
        var bg = g.createRadialGradient(bx - br * 0.3, by - br * 0.3, br * 0.1, bx, by, br); bg.addColorStop(0, rgb(mix(C.wood, [230, 170, 110], 0.35))); bg.addColorStop(1, rgb(mix(C.wood, [30, 18, 10], 0.5)));
        g.fillStyle = bg; g.beginPath(); g.arc(bx, by, br, 0, Math.PI * 2); g.fill();
        g.strokeStyle = 'rgba(40,24,14,0.6)'; g.lineWidth = 1; for (var st = -2; st <= 2; st++) { g.beginPath(); g.moveTo(bx + st * br * 0.35, by - Math.sqrt(br * br - st * st * br * br * 0.1225)); g.lineTo(bx + st * br * 0.35, by + Math.sqrt(br * br - st * st * br * br * 0.1225)); g.stroke(); }
        g.strokeStyle = rgb([70, 64, 58]); g.lineWidth = 2.4; g.beginPath(); g.arc(bx, by, br - 1.5, 0, Math.PI * 2); g.stroke();
        g.fillStyle = rgb([30, 18, 12]); g.beginPath(); g.arc(bx, by, br * 0.12, 0, Math.PI * 2); g.fill();
      }
      g.restore();
      g.strokeStyle = rgb(mix(C.brick, [210, 170, 140], 0.3)); g.lineWidth = 5; g.beginPath(); g.arc(ax, at + aw / 2, aw / 2 + 3, Math.PI, 0); g.stroke();
      g.fillStyle = rgb(mix(C.brick, [210, 170, 140], 0.25)); g.fillRect(ax - aw / 2 - 6, at + aw / 2, 5, ab - at - aw / 2); g.fillRect(ax + aw / 2 + 1, at + aw / 2, 5, ab - at - aw / 2);
    }
    // a heavy beam across the top and lanterns hanging between the arches, each with its glow
    g.fillStyle = rgb(mix(C.wood, [20, 12, 8], 0.45)); g.fillRect(0, 0, w, top * 0.11); g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(0, top * 0.11, w, 4);
    for (i = 0; i < 2; i++) {
      var lx = w * (0.35 + i * 0.3), ly = top * 0.42;
      var glow = g.createRadialGradient(lx, ly, 0, lx, ly, 120); glow.addColorStop(0, 'rgba(255,200,110,0.55)'); glow.addColorStop(1, 'rgba(255,150,60,0)'); g.fillStyle = glow; g.fillRect(lx - 120, ly - 120, 240, 240);
      g.strokeStyle = rgb([30, 24, 20]); g.lineWidth = 1.5; g.beginPath(); g.moveTo(lx, top * 0.11); g.lineTo(lx, ly - 12); g.stroke();
      g.fillStyle = rgb([40, 32, 26]); g.fillRect(lx - 8, ly - 13, 16, 3); g.fillRect(lx - 7, ly + 10, 14, 3);
      g.fillStyle = 'rgba(255,214,130,0.95)'; g.fillRect(lx - 6, ly - 10, 12, 20); g.fillStyle = rgb([40, 32, 26]); g.fillRect(lx - 1, ly - 10, 2, 20);
    }
    var foot = g.createLinearGradient(0, top - 20, 0, top); foot.addColorStop(0, 'rgba(0,0,0,0)'); foot.addColorStop(1, 'rgba(0,0,0,0.55)'); g.fillStyle = foot; g.fillRect(0, top - 20, w, 20);
  }
  function floorCellar(g, C, cam, core, seed) {
    var w = cam.w, h = cam.h, P = { x: 0, y: 0, s: 0 }, Q = { x: 0, y: 0, s: 0 }, sp = floorSpan(cam, core), i;
    g.fillStyle = rgb(mix(C.wood, [10, 6, 4], 0.6)); g.fillRect(0, sp.f0, w, h - sp.f0);
    // planks running along the court, each its own tint, butt joints staggered, grain streaks and two nails at each joint
    var z = sp.z0, row = 0, BW = 22;
    while (z < sp.z1) {
      var x = sp.x0 - hash(row, 121, seed) * 180, col = 0;
      while (x < sp.x1) {
        var len = 150 + hash(row, col + 200, seed) * 170, t = hash(row, col, seed + 122);
        quad(g, cam, x + 1.5, z + 1.2, x + len - 1.5, z + BW - 1.2, P, Q); g.fillStyle = rgb(mix(C.wood, t < 0.5 ? [200, 140, 90] : [70, 44, 28], Math.abs(t - 0.5) * 0.8)); g.fill();
        for (var gs = 0; gs < 3; gs++) { var gz = z + 4 + hash(row * 3 + gs, col, seed + 123) * (BW - 8); cam.pt(x + 6, gz, 0, P); cam.pt(x + len - 6, gz + (hash(row, col + gs, seed + 124) - 0.5) * 3, 0, Q); g.strokeStyle = 'rgba(40,22,12,0.28)'; g.lineWidth = 0.8; g.beginPath(); g.moveTo(P.x, P.y); g.lineTo(Q.x, Q.y); g.stroke(); }
        for (var nl = 0; nl < 2; nl++) { cam.pt(x + 5, z + BW * (0.3 + nl * 0.4), 0, P); g.fillStyle = 'rgba(20,14,10,0.7)'; g.fillRect(P.x - 1, P.y - 1, 2.2 * P.s, 1.6 * P.s); }
        x += len; col++;
      }
      z += BW; row++;
    }
    // two spilled-ale stains, the worn outfield strips, lantern pools, then the chalk court and a tally scratched by the line
    for (i = 0; i < 2; i++) { cam.pt(core.COURT_W * (0.3 + i * 0.45), core.LANE * (0.25 + i * 0.5), 0, P); g.fillStyle = 'rgba(30,16,6,0.28)'; g.beginPath(); g.ellipse(P.x, P.y, 34 * P.s, 12 * P.s, 0.2, 0, Math.PI * 2); g.fill(); }
    quad(g, cam, -core.OUT_DEPTH, 0, 0, core.LANE, P, Q); g.fillStyle = 'rgba(0,0,0,0.2)'; g.fill(); quad(g, cam, core.COURT_W, 0, core.COURT_W + core.OUT_DEPTH, core.LANE, P, Q); g.fill();
    lightPool(g, cam, core.COURT_W * 0.36, core.LANE * 0.3, 330, [255, 190, 100], 0.3, P); lightPool(g, cam, core.COURT_W * 0.64, core.LANE * 0.3, 330, [255, 190, 100], 0.3, P);
    markings(function (x0, z0, x1, z1, wid) { chalk(g, cam, x0, z0, x1, z1, wid, C.line, seed, P, Q); }, core);
    for (i = 0; i < 8; i++) { var tx = core.COURT_W / 2 + 24 + i * 7 + (i === 4 ? 0 : 0); if (i === 4) { chalk(g, cam, tx - 30, core.LANE + 22, tx - 2, core.LANE + 10, 1.5, C.line, seed, P, Q); continue; } chalk(g, cam, tx - (i > 4 ? 7 : 0), core.LANE + 8, tx - (i > 4 ? 7 : 0), core.LANE + 24, 1.5, C.line, seed, P, Q); }
    // the room's corners fall into shadow
    var vg = g.createRadialGradient(w / 2, h * 0.62, h * 0.2, w / 2, h * 0.62, w * 0.72); vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.55)'); g.fillStyle = vg; g.fillRect(0, sp.f0, w, h - sp.f0);
  }

  /** draw a whole court (backdrop + floor) for screen size w x h. seed varies the grain, never the layout */
  function drawCourt(g, key, core, w, h, seed) {
    var C = COURTS[key] ? COURTS[key] : COURTS.schoolyard, cam = camera(core, w, h), s = seed | 0;
    if (key === 'beach') { backdropBeach(g, C, cam, s); floorBeach(g, C, cam, core, s); }
    else if (key === 'castle') { backdropCastle(g, C, cam, s); floorCastle(g, C, cam, core, s); }
    else if (key === 'pond') { backdropPond(g, C, cam, s); floorPond(g, C, cam, core, s); }
    else if (key === 'cellar') { backdropCellar(g, C, cam, s); floorCellar(g, C, cam, core, s); }
    else { backdropSchoolyard(g, COURTS.schoolyard, cam, s); floorSchoolyard(g, COURTS.schoolyard, cam, core, s); }
    return cam;
  }
  /** the ball's shadow on the floor (always, so its height reads) and the ball itself, lit from the upper left */
  function drawBall(g, cam, x, z, hgt, r, out) {
    cam.pt(x, z, 0, out); var s = out.s;
    g.fillStyle = 'rgba(0,0,0,' + Math.max(0.12, 0.42 - hgt * 0.004) + ')'; g.beginPath(); g.ellipse(out.x, out.y, r * s * 1.1, r * s * 0.45, 0, 0, Math.PI * 2); g.fill();
    cam.pt(x, z, hgt, out);
    var gr = g.createRadialGradient(out.x - r * s * 0.35, out.y - r * s * 0.35, r * s * 0.1, out.x, out.y, r * s);
    gr.addColorStop(0, 'rgb(255,190,160)'); gr.addColorStop(0.6, 'rgb(214,64,48)'); gr.addColorStop(1, 'rgb(110,24,24)');
    g.fillStyle = gr; g.beginPath(); g.arc(out.x, out.y, r * s, 0, Math.PI * 2); g.fill();
  }
  //---------------------------------------------------------------------------
  // ELEMENT LOOKS: COPIED from Bout_MZ BoutDraw.js v1.0.0 lines 25-50 (look, LOOK, KEYS, hsl). A look per element, derived
  // from the buyer's own element names; a name no keyword matches gets a hue hashed from the name itself.
  //---------------------------------------------------------------------------
  var LOOK = {
    fire: { core: [255, 232, 140], hot: [255, 140, 40], dark: [170, 40, 20], form: 'flame' },
    ice: { core: [235, 250, 255], hot: [120, 210, 255], dark: [40, 90, 170], form: 'shard' },
    thunder: { core: [255, 255, 210], hot: [255, 220, 60], dark: [150, 110, 20], form: 'bolt' },
    water: { core: [220, 245, 255], hot: [70, 170, 240], dark: [20, 70, 140], form: 'drop' },
    earth: { core: [240, 210, 160], hot: [170, 120, 70], dark: [90, 60, 35], form: 'rock' },
    wind: { core: [235, 255, 240], hot: [120, 230, 170], dark: [30, 120, 90], form: 'gust' },
    light: { core: [255, 255, 245], hot: [255, 236, 150], dark: [200, 160, 60], form: 'star' },
    dark: { core: [230, 190, 255], hot: [150, 60, 220], dark: [40, 10, 70], form: 'void' },
    physical: { core: [255, 255, 255], hot: [255, 210, 120], dark: [140, 90, 40], form: 'impact' },
  };
  var KEYS = [['fire', /fire|flame|burn|blaze|heat|pyro/], ['ice', /ice|frost|cold|snow|freez|blizz/], ['thunder', /thunder|lightning|bolt|electr|spark|volt|storm/],
    ['water', /water|aqua|tide|wave|rain|sea/], ['earth', /earth|stone|rock|ground|quake|terra|sand/], ['wind', /wind|air|gale|gust|aero|breeze/],
    ['light', /light|holy|sacred|divine|radian|sun/], ['dark', /dark|shadow|void|curse|death|night|evil|abyss/], ['physical', /physical|weapon|none|normal|blade|strike/]];
  var custom = {};
  /** The look for an element NAME (a string from $dataSystem.elements, or 'Weapon' / 'None'). */
  function look(name) {
    var n = String(name || 'none').toLowerCase();
    for (var i = 0; i < KEYS.length; i++) if (KEYS[i][1].test(n)) return LOOK[KEYS[i][0]];
    if (custom[n]) return custom[n];
    var hsh = 0; for (var k = 0; k < n.length; k++) hsh = (Math.imul(hsh, 31) + n.charCodeAt(k)) >>> 0;
    var hue = hsh % 360, c = hsl(hue, 0.85, 0.62), forms = ['flame', 'shard', 'bolt', 'drop', 'rock', 'gust', 'star', 'void'];
    custom[n] = { core: mix(c, [255, 255, 255], 0.65), hot: c, dark: mix(c, [0, 0, 0], 0.6), form: forms[hsh % forms.length], custom: true };
    return custom[n];
  }
  function hsl(h, s, l) { var k = function (n) { return (n + h / 30) % 12; }, a = s * Math.min(l, 1 - l); var f = function (n) { return 255 * (l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)))); }; return [f(0), f(8), f(4)]; }

  /**
   * A hit spark in an element's look at age 0..1. COPIED from Bout_MZ BoutDraw.js v1.0.0 drawSpark (line 236), using
   * Pelt's unsigned hash (so its jitter is the [0, 1) the code was written for).
   */
  function drawSpark(g, elName, x, y, size, age, seed) {
    var L = look(elName), a = 1 - age, r = size * (0.5 + age * 0.7), n, i, ang, s = seed || 1;
    g.save(); g.translate(x, y); g.globalAlpha = Math.max(0, Math.min(1, a * 1.3));
    var glow = g.createRadialGradient(0, 0, 0, 0, 0, r * 1.2); glow.addColorStop(0, rgb(L.hot, 0.55)); glow.addColorStop(1, rgb(L.hot, 0)); g.fillStyle = glow; g.beginPath(); g.arc(0, 0, r * 1.2, 0, Math.PI * 2); g.fill();
    var f = L.form;
    if (f === 'flame') { n = 7; for (i = 0; i < n; i++) { ang = i / n * Math.PI * 2 + hash(i, s, 1); var len = r * (0.8 + hash(i, s, 2) * 0.5); g.fillStyle = rgb(i % 2 ? L.hot : L.core); g.beginPath(); g.moveTo(Math.cos(ang - 0.25) * r * 0.2, Math.sin(ang - 0.25) * r * 0.2); g.quadraticCurveTo(Math.cos(ang + 0.4) * len * 0.6, Math.sin(ang + 0.4) * len * 0.6, Math.cos(ang) * len, Math.sin(ang) * len); g.quadraticCurveTo(Math.cos(ang - 0.4) * len * 0.5, Math.sin(ang - 0.4) * len * 0.5, Math.cos(ang + 0.25) * r * 0.2, Math.sin(ang + 0.25) * r * 0.2); g.fill(); } }
    else if (f === 'shard') { n = 6; for (i = 0; i < n; i++) { ang = i / n * Math.PI * 2 + hash(i, s, 3) * 0.5; var ln = r * (0.7 + hash(i, s, 4) * 0.6); g.fillStyle = rgb(L.core); g.strokeStyle = rgb(L.dark); g.lineWidth = 1.5; g.beginPath(); g.moveTo(Math.cos(ang) * ln, Math.sin(ang) * ln); g.lineTo(Math.cos(ang + 0.18) * ln * 0.3, Math.sin(ang + 0.18) * ln * 0.3); g.lineTo(Math.cos(ang - 0.18) * ln * 0.3, Math.sin(ang - 0.18) * ln * 0.3); g.closePath(); g.fill(); g.stroke(); } }
    else if (f === 'bolt') { n = 4; g.strokeStyle = rgb(L.core); g.lineWidth = 3; g.lineJoin = 'miter'; for (i = 0; i < n; i++) { ang = i / n * Math.PI * 2 + 0.4; g.beginPath(); g.moveTo(0, 0); var px = 0, py = 0; for (var k = 1; k <= 4; k++) { var d = r * k / 4, j = (hash(i, k, s) - 0.5) * r * 0.5; px = Math.cos(ang) * d - Math.sin(ang) * j; py = Math.sin(ang) * d + Math.cos(ang) * j; g.lineTo(px, py); } g.stroke(); } g.strokeStyle = rgb(L.hot); g.lineWidth = 1; g.stroke(); }
    else if (f === 'drop') { n = 9; for (i = 0; i < n; i++) { ang = i / n * Math.PI * 2; var dr = r * 0.85; g.fillStyle = rgb(L.core); g.beginPath(); g.ellipse(Math.cos(ang) * dr, Math.sin(ang) * dr, r * 0.1, r * 0.17, ang + Math.PI / 2, 0, Math.PI * 2); g.fill(); } g.strokeStyle = rgb(L.hot); g.lineWidth = 2; g.beginPath(); g.arc(0, 0, r * 0.5, 0, Math.PI * 2); g.stroke(); }
    else if (f === 'rock') {
      n = 6; for (i = 0; i < n; i++) { ang = i / n * Math.PI * 2 + hash(i, s, 5); var rr = r * (0.55 + hash(i, s, 6) * 0.45), cs = r * (0.22 + hash(i, s, 7) * 0.12), cx2 = Math.cos(ang) * rr, cy2 = Math.sin(ang) * rr;
        g.beginPath(); g.moveTo(cx2 - cs, cy2 - cs * 0.5); g.lineTo(cx2 + cs * 0.7, cy2 - cs); g.lineTo(cx2 + cs, cy2 + cs * 0.6); g.lineTo(cx2 - cs * 0.5, cy2 + cs); g.closePath();
        g.fillStyle = rgb(L.hot); g.fill(); g.lineWidth = 1.5; g.strokeStyle = rgb(L.dark); g.stroke();
        g.beginPath(); g.moveTo(cx2 - cs, cy2 - cs * 0.5); g.lineTo(cx2 + cs * 0.7, cy2 - cs); g.lineTo(cx2 + cs * 0.4, cy2 - cs * 0.35); g.lineTo(cx2 - cs * 0.55, cy2 - cs * 0.1); g.closePath(); g.fillStyle = rgb(L.core); g.fill(); } }
    else if (f === 'gust') { g.strokeStyle = rgb(L.core); g.lineCap = 'round'; for (i = 0; i < 4; i++) { g.lineWidth = 3 - i * 0.5; g.beginPath(); g.arc(0, 0, r * (0.35 + i * 0.2), i * 1.6, i * 1.6 + Math.PI * 1.1); g.stroke(); } }
    else if (f === 'star') { n = 8; g.fillStyle = rgb(L.core); g.beginPath(); for (i = 0; i < n * 2; i++) { ang = i / (n * 2) * Math.PI * 2; var sr = i % 2 ? r * 0.22 : r * (i % 4 ? 0.75 : 1.1); g.lineTo(Math.cos(ang) * sr, Math.sin(ang) * sr); } g.closePath(); g.fill(); }
    else if (f === 'void') { g.fillStyle = rgb(L.dark); g.beginPath(); g.arc(0, 0, r * 0.45, 0, Math.PI * 2); g.fill(); g.strokeStyle = rgb(L.hot); g.lineWidth = 2.5; g.stroke(); for (i = 0; i < 5; i++) { ang = i / 5 * Math.PI * 2 + hash(i, s, 8); g.beginPath(); g.moveTo(Math.cos(ang) * r * 0.45, Math.sin(ang) * r * 0.45); g.quadraticCurveTo(Math.cos(ang + 0.6) * r * 0.8, Math.sin(ang + 0.6) * r * 0.8, Math.cos(ang + 0.2) * r * 1.05, Math.sin(ang + 0.2) * r * 1.05); g.stroke(); } }
    else { n = 10; g.fillStyle = rgb(L.core); g.beginPath(); for (i = 0; i < n * 2; i++) { ang = i / (n * 2) * Math.PI * 2 + 0.2; var ir = i % 2 ? r * 0.3 : r * (0.8 + hash(i, s, 9) * 0.35); g.lineTo(Math.cos(ang) * ir, Math.sin(ang) * ir); } g.closePath(); g.fill(); g.strokeStyle = rgb(L.dark); g.lineWidth = 2; g.stroke(); }
    g.fillStyle = 'rgba(255,255,255,0.9)'; g.beginPath(); g.arc(0, 0, r * 0.16, 0, Math.PI * 2); g.fill();
    g.restore();
  }

  //---------------------------------------------------------------------------
  // ARCADE LETTERING: COPIED from Bout_MZ BoutDraw.js v1.0.0 lines 56-112 (BLOCK, textWidth, glyphPath, drawText). A block
  // alphabet on a 5 x 7 grid, one path per string, gradient face, dark outline and a hard drop shadow. No font file.
  //---------------------------------------------------------------------------
  var BLOCK = {
    A: ['01110', '10001', '10001', '11111', '10001', '10001', '10001'], B: ['11110', '10001', '11110', '10001', '10001', '10001', '11110'],
    C: ['01111', '10000', '10000', '10000', '10000', '10000', '01111'], D: ['11110', '10001', '10001', '10001', '10001', '10001', '11110'],
    E: ['11111', '10000', '11110', '10000', '10000', '10000', '11111'], F: ['11111', '10000', '11110', '10000', '10000', '10000', '10000'],
    G: ['01111', '10000', '10000', '10011', '10001', '10001', '01111'], H: ['10001', '10001', '11111', '10001', '10001', '10001', '10001'],
    I: ['11111', '00100', '00100', '00100', '00100', '00100', '11111'], J: ['00111', '00001', '00001', '00001', '10001', '10001', '01110'],
    K: ['10001', '10010', '11100', '10010', '10001', '10001', '10001'], L: ['10000', '10000', '10000', '10000', '10000', '10000', '11111'],
    M: ['10001', '11011', '10101', '10001', '10001', '10001', '10001'], N: ['10001', '11001', '10101', '10011', '10001', '10001', '10001'],
    O: ['01110', '10001', '10001', '10001', '10001', '10001', '01110'], P: ['11110', '10001', '10001', '11110', '10000', '10000', '10000'],
    Q: ['01110', '10001', '10001', '10001', '10101', '10010', '01101'], R: ['11110', '10001', '10001', '11110', '10010', '10001', '10001'],
    S: ['01111', '10000', '10000', '01110', '00001', '00001', '11110'], T: ['11111', '00100', '00100', '00100', '00100', '00100', '00100'],
    U: ['10001', '10001', '10001', '10001', '10001', '10001', '01110'], V: ['10001', '10001', '10001', '10001', '01010', '01010', '00100'],
    W: ['10001', '10001', '10001', '10101', '10101', '11011', '10001'], X: ['10001', '01010', '00100', '00100', '01010', '10001', '10001'],
    Y: ['10001', '01010', '00100', '00100', '00100', '00100', '00100'], Z: ['11111', '00010', '00100', '01000', '10000', '10000', '11111'],
    0: ['01110', '10011', '10101', '10101', '11001', '10001', '01110'], 1: ['00100', '01100', '00100', '00100', '00100', '00100', '01110'],
    2: ['01110', '10001', '00001', '00110', '01000', '10000', '11111'], 3: ['11110', '00001', '00001', '01110', '00001', '00001', '11110'],
    4: ['00010', '00110', '01010', '10010', '11111', '00010', '00010'], 5: ['11111', '10000', '11110', '00001', '00001', '10001', '01110'],
    6: ['01110', '10000', '11110', '10001', '10001', '10001', '01110'], 7: ['11111', '00001', '00010', '00100', '01000', '01000', '01000'],
    8: ['01110', '10001', '10001', '01110', '10001', '10001', '01110'], 9: ['01110', '10001', '10001', '01111', '00001', '00001', '01110'],
    '!': ['00100', '00100', '00100', '00100', '00100', '00000', '00100'], '.': ['00000', '00000', '00000', '00000', '00000', '00000', '00100'],
    ':': ['00000', '00100', '00100', '00000', '00100', '00100', '00000'], '-': ['00000', '00000', '00000', '01110', '00000', '00000', '00000'],
    ' ': ['00000', '00000', '00000', '00000', '00000', '00000', '00000'],
  };
  function textWidth(str, u) { return String(str).length * 6 * u - u; }
  function glyphPath(g, ch, x, y, u, slant) {
    var rows = BLOCK[ch] || BLOCK[' '];
    for (var r = 0; r < 7; r++) for (var c = 0; c < 5; c++) {
      if (rows[r][c] !== '1') continue;
      var sx = (6 - r) * u * slant, x0 = x + c * u + sx, y0 = y + r * u;
      g.moveTo(x0, y0); g.lineTo(x0 + u + 0.4, y0); g.lineTo(x0 + u + 0.4 - u * slant, y0 + u + 0.4); g.lineTo(x0 - u * slant, y0 + u + 0.4); g.closePath();
    }
  }
  /** Strike a string in the arcade alphabet; style {top, bottom, outline, shadow} colours, align left | center | right. */
  function drawText(g, str, x, y, u, style, align) {
    str = String(str).toUpperCase(); style = style || {};
    var w = textWidth(str, u), x0 = align === 'center' ? x - w / 2 : align === 'right' ? x - w : x, slant = 0.18;
    var top = style.top || [255, 244, 170], bottom = style.bottom || [255, 150, 40], out = style.outline || [30, 14, 8], sh = style.shadow || [0, 0, 0];
    g.save();
    var off = Math.max(2, u * 0.45);
    for (var pass = 0; pass < 3; pass++) {
      g.beginPath();
      for (var i = 0; i < str.length; i++) glyphPath(g, str[i], x0 + i * 6 * u + (pass === 0 ? off : 0), y + (pass === 0 ? off : 0), u, slant);
      if (pass === 0) { g.fillStyle = rgb(sh, 0.55); g.fill(); }
      else if (pass === 1) { g.lineJoin = 'miter'; g.strokeStyle = rgb(out); g.lineWidth = Math.max(2, u * 0.7); g.stroke(); }
      else { var gr = g.createLinearGradient(0, y, 0, y + 7 * u); gr.addColorStop(0, rgb(top)); gr.addColorStop(0.55, rgb(mix(top, bottom, 0.6))); gr.addColorStop(1, rgb(bottom)); g.fillStyle = gr; g.fill(); }
    }
    g.beginPath(); for (var j = 0; j < str.length; j++) { var rows = BLOCK[str[j]] || BLOCK[' ']; for (var c = 0; c < 5; c++) if (rows[0][c] === '1') { var bx = x0 + j * 6 * u + c * u + 6 * u * slant; g.rect(bx, y, u, Math.max(1, u * 0.28)); } }
    g.fillStyle = 'rgba(255,255,255,0.55)'; g.fill();
    g.restore();
    return w;
  }

  //---------------------------------------------------------------------------
  // PELT'S OWN PIECES: the ball atlas (one cell per element look), the team HUD, the controlled-player marker, the labels
  //---------------------------------------------------------------------------
  /** a ball r px in radius at (x, y), its leather panels and seam lines in an element's look (null = the plain red ball) */
  function drawBallCell(g, x, y, r, elName) {
    var L = elName ? look(elName) : null, c0 = L ? L.core : [255, 190, 160], c1 = L ? L.hot : [214, 64, 48], c2 = L ? L.dark : [110, 24, 24];
    if (L) { var gl = g.createRadialGradient(x, y, r * 0.6, x, y, r * 1.9); gl.addColorStop(0, rgb(c1, 0.6)); gl.addColorStop(1, rgb(c1, 0)); g.fillStyle = gl; g.beginPath(); g.arc(x, y, r * 1.9, 0, Math.PI * 2); g.fill(); }
    var gr = g.createRadialGradient(x - r * 0.35, y - r * 0.35, r * 0.1, x, y, r);
    gr.addColorStop(0, rgb(c0)); gr.addColorStop(0.6, rgb(c1)); gr.addColorStop(1, rgb(c2));
    g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fill();
    g.strokeStyle = rgb(c2, 0.75); g.lineWidth = Math.max(1, r * 0.12);
    g.beginPath(); g.ellipse(x, y, r * 0.45, r, 0, -Math.PI / 2, Math.PI / 2); g.stroke();
    g.beginPath(); g.moveTo(x - r, y); g.quadraticCurveTo(x, y + r * 0.35, x + r, y); g.stroke();
    g.fillStyle = 'rgba(255,255,255,0.55)'; g.beginPath(); g.ellipse(x - r * 0.35, y - r * 0.42, r * 0.28, r * 0.16, -0.5, 0, Math.PI * 2); g.fill();
  }
  /**
   * The HUD. o: { w, h, teams: [{ name, players: [{ name, hp (0..1), out (bool), on (the human's player) }], meter (0..1) },
   * same], time (seconds), wins: [a, b], need }. One card per infielder: name, a tapered HP bar, an OUT stamp.
   */
  function drawHud(g, o) {
    var W = o.w, cx = W / 2, top = 10;
    for (var side = 0; side < 2; side++) {
      var T = o.teams[side], n = T.players.length, cw = Math.min(118, (W / 2 - 64) / n), dir = side ? 1 : -1;
      for (var k = 0; k < n; k++) {
        var p = T.players[k], x0 = side ? cx + 52 + k * cw : cx - 52 - (k + 1) * cw, y0 = top;
        g.fillStyle = p.on ? 'rgba(40,30,10,0.86)' : 'rgba(12,10,20,0.78)'; g.beginPath(); g.moveTo(x0 + 6, y0); g.lineTo(x0 + cw - 2, y0); g.lineTo(x0 + cw - 8, y0 + 38); g.lineTo(x0, y0 + 38); g.closePath(); g.fill();
        g.strokeStyle = p.on ? 'rgba(255,214,90,0.95)' : 'rgba(255,220,140,0.55)'; g.lineWidth = p.on ? 2 : 1.2; g.stroke();
        // the name is FITTED to the card (the letter size shrinks down to 1.1) and cut only past that: a hard cut at the
        // 1.5 size printed MICHELLE as MICHELL on a four-a-side card, which reads as a typo (looked at, 2026-10-17)
        var nm = String(p.name).toUpperCase(), nu = Math.min(1.5, (cw - 16) / Math.max(1, nm.length * 6 - 1));
        if (nu < 1.1) { nu = 1.1; nm = nm.slice(0, Math.max(3, Math.floor((cw - 16 + nu) / (6 * nu)))); }
        drawText(g, nm, x0 + 9, y0 + 5 + (1.5 - nu) * 3.5, nu, { top: [255, 255, 255], bottom: [200, 210, 230] }, 'left');
        var bx = x0 + 6, by = y0 + 22, bw = cw - 18, hpc = p.hp > 0.5 ? [250, 214, 60] : p.hp > 0.25 ? [250, 150, 40] : [235, 60, 40];
        g.fillStyle = 'rgba(0,0,0,0.6)'; g.fillRect(bx, by, bw, 9);
        if (!p.out && p.hp > 0) { var hg = g.createLinearGradient(0, by, 0, by + 9); hg.addColorStop(0, rgb(mix(hpc, [255, 255, 255], 0.45))); hg.addColorStop(1, rgb(mix(hpc, [0, 0, 0], 0.3))); g.fillStyle = hg; g.fillRect(bx, by, bw * p.hp, 9); }
        if (p.out) drawText(g, 'OUT', x0 + cw / 2 - 2, y0 + 16, 2, { top: [255, 120, 100], bottom: [190, 30, 30] }, 'center');
      }
      // the special meter of the side, under its cards, in four segments
      var mY = top + 46, segW = 30, mx0 = side ? cx + 52 : cx - 52 - 4 * (segW + 4);
      for (var s = 0; s < 4; s++) { var fN = Math.max(0, Math.min(1, T.meter * 4 - s)), sx = mx0 + s * (segW + 4); g.fillStyle = 'rgba(12,10,20,0.8)'; g.fillRect(sx, mY, segW, 7); if (fN > 0) { g.fillStyle = fN >= 1 ? 'rgb(120,255,200)' : 'rgb(60,160,130)'; g.fillRect(sx, mY, segW * fN, 7); } }
      // rounds won as pips beside the meter
      for (var r = 0; r < (o.need || 1) && o.need > 1; r++) { var px = side ? mx0 + 4 * (segW + 4) + 10 + r * 16 : mx0 - 10 - r * 16; g.beginPath(); g.arc(px, mY + 3.5, 5, 0, Math.PI * 2); g.fillStyle = r < o.wins[side] ? 'rgb(255,214,80)' : 'rgba(12,10,20,0.85)'; g.fill(); g.lineWidth = 1.5; g.strokeStyle = 'rgb(255,230,160)'; g.stroke(); }
    }
    g.beginPath(); for (var a = 0; a < 6; a++) { var ang = Math.PI / 6 + a * Math.PI / 3; g.lineTo(cx + Math.cos(ang) * 32, top + 20 + Math.sin(ang) * 28); } g.closePath();
    g.fillStyle = 'rgba(12,10,20,0.9)'; g.fill(); g.lineWidth = 2; g.strokeStyle = 'rgb(255,220,140)'; g.stroke();
    drawText(g, String(Math.max(0, Math.ceil(o.time))), cx, top + 10, 3, { top: [255, 255, 255], bottom: [255, 210, 120] }, 'center');
  }
  /** the marker over the human's player: a downward chevron in gold with a dark rim, w x h */
  function drawMarker(g, w, h) {
    g.beginPath(); g.moveTo(2, 2); g.lineTo(w - 2, 2); g.lineTo(w / 2, h - 2); g.closePath();
    g.fillStyle = 'rgb(255,214,80)'; g.fill(); g.lineWidth = 2.5; g.strokeStyle = 'rgb(60,30,8)'; g.stroke();
    g.fillStyle = 'rgba(255,255,255,0.6)'; g.fillRect(w * 0.3, 4, w * 0.4, 2);
  }

  return { VERSION: '1.0.0', COURTS: COURTS, camera: camera, drawCourt: drawCourt, drawBall: drawBall, drawBallCell: drawBallCell, drawHud: drawHud, drawMarker: drawMarker,
    drawSpark: drawSpark, drawText: drawText, textWidth: textWidth, look: look, hash: hash, rgb: rgb, mix: mix };
})();
if (typeof module !== 'undefined' && module.exports) module.exports = PeltDraw;
if (typeof window !== 'undefined') window.PeltDraw = PeltDraw;
