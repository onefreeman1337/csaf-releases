//=============================================================================
// Township.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.1.0] Every NPC gets a real day — homes, jobs, overnight shifts and festivals — with idle poses at their destination and door transitions instead of pop-in.
 * @author CSAF — Core Systems Asset Factory
 * @url https://csaf.itch.io/township
 *
 * @param --- Time -------
 * @default
 *
 * @param timeSource
 * @text Clock source
 * @type select
 * @option Township's own clock (internal)
 * @value internal
 * @option Read from game variables (works with most time plugins)
 * @value variables
 * @option Read from a script expression
 * @value script
 * @desc Where the time of day comes from. Use "variables" to drive Township from a day/night plugin you already own.
 * @default internal
 *
 * @param framesPerGameMinute
 * @text Frames per game minute
 * @type number
 * @min 1
 * @max 3600
 * @desc Internal clock speed. 30 frames = one game minute, so a full day takes about 12 real minutes.
 * @default 30
 *
 * @param varHour
 * @text Hour variable
 * @type variable
 * @desc Clock source "variables": the variable holding the hour (0-23). Leave blank if unused.
 * @default 0
 *
 * @param varMinute
 * @text Minute variable
 * @type variable
 * @desc Clock source "variables": the variable holding the minute (0-59). Leave blank if unused.
 * @default 0
 *
 * @param varDay
 * @text Day variable
 * @type variable
 * @desc Clock source "variables": the variable holding the day count. Leave blank if unused.
 * @default 0
 *
 * @param timeScript
 * @text Time script
 * @type note
 * @desc Clock source "script": JavaScript returning {min: 0-1439, day: n}. Evaluated once per frame on the map.
 * @default ""
 *
 * @param weekLength
 * @text Days in a week
 * @type number
 * @min 1
 * @max 31
 * @desc How many days before weekday schedule variants repeat.
 * @default 7
 *
 * @param --- Movement -------
 * @default
 *
 * @param walkSpeed
 * @text NPC walk speed
 * @type number
 * @min 1
 * @max 6
 * @desc Default movement speed for scheduled NPCs. 3 is slow, 4 is normal.
 * @default 3
 *
 * @param pathBudget
 * @text Pathfinding budget
 * @type number
 * @min 50
 * @max 5000
 * @desc Maximum search steps per path. Higher handles bigger maps; lower keeps a crowded town cheap.
 * @default 600
 *
 * @param transitionFrames
 * @text Door fade frames
 * @type number
 * @min 0
 * @max 120
 * @desc How long an NPC takes to fade in or out at a door. 0 disables fading (not recommended).
 * @default 24
 *
 * @param --- Board -------
 * @default
 *
 * @param boardEnabled
 * @text Enable routine board
 * @type boolean
 * @desc Allow the routine board scene to be opened with the OpenBoard command.
 * @default true
 *
 * @param tagColors
 * @text Activity colours
 * @type struct<TagColor>[]
 * @desc Colour of each activity type on the routine board strips.
 * @default ["{\"tag\":\"home\",\"color\":\"#6f8fae\"}","{\"tag\":\"work\",\"color\":\"#c98a3f\"}","{\"tag\":\"errand\",\"color\":\"#8aa85f\"}","{\"tag\":\"social\",\"color\":\"#b06a8f\"}","{\"tag\":\"sleep\",\"color\":\"#3d4a63\"}","{\"tag\":\"travel\",\"color\":\"#7d7568\"}"]
 *
 * @param --- Town data -------
 * @default
 *
 * @param places
 * @text Places (optional)
 * @type struct<Place>[]
 * @desc Named destinations. You can also drop an event on the map and note it <township_place:id> instead.
 * @default []
 *
 * @param doors
 * @text Doors (optional)
 * @type struct<Door>[]
 * @desc Where NPCs enter and leave a map. You can also note an event <township_door:id> instead.
 * @default []
 *
 * @command OpenBoard
 * @text Open routine board
 * @desc Opens the routine board — the day dial, every NPC's day as coloured strips, and a live map inset.
 *
 * @command SetTime
 * @text Set time
 * @desc Sets the town clock. Only affects Township's internal clock.
 * @arg hour
 * @type number
 * @min 0
 * @max 23
 * @default 8
 * @arg minute
 * @type number
 * @min 0
 * @max 59
 * @default 0
 *
 * @command AdvanceMinutes
 * @text Advance minutes
 * @desc Moves the town clock forward. NPCs jump to where they should be.
 * @arg minutes
 * @type number
 * @min 1
 * @max 1440
 * @default 60
 *
 * @command SetDayType
 * @text Set day type
 * @desc Switches the town to a named day type, e.g. "market" or "festival", selecting matching schedule variants.
 * @arg dayType
 * @type string
 * @default normal
 *
 * @command ForceActivity
 * @text Force an NPC somewhere
 * @desc Overrides one NPC's schedule and sends them to a place. Use for story beats.
 * @arg actorId
 * @type string
 * @arg placeId
 * @type string
 * @arg untilHour
 * @type number
 * @min -1
 * @max 23
 * @default -1
 * @desc Hour the override ends. -1 keeps it until you release the NPC.
 *
 * @command ReleaseActor
 * @text Release an NPC
 * @desc Clears any override and returns the NPC to their schedule.
 * @arg actorId
 * @type string
 *
 * @command ActorPlaceToVar
 * @text Where is this NPC?
 * @desc Writes the NPC's current place id into a variable, for conditional eventing.
 * @arg actorId
 * @type string
 * @arg variableId
 * @type variable
 *
 * @command ActorAtPlace
 * @text Is this NPC here?
 * @desc Turns a switch ON if the NPC is currently at the named place, OFF otherwise.
 * @arg actorId
 * @type string
 * @arg placeId
 * @type string
 * @arg switchId
 * @type switch
 *
 * @command SetScheduleVariant
 * @text Force a schedule variant
 * @desc Pins an NPC to a named schedule variant, ignoring conditions. Blank clears the pin.
 * @arg actorId
 * @type string
 * @arg scheduleId
 * @type string
 *
 * @help
 * ============================================================================
 * Township — a living town, not a list of waypoints
 * ============================================================================
 *
 * WHY THE OVERNIGHT CASE WORKS
 *
 * Most routine plugins store a schedule as spans: "work from 08:00 to 17:00".
 * That representation breaks the moment a shift crosses midnight, because
 * `now >= start && now < end` is false for EVERY minute when start is 22:00
 * and end is 07:00 — so no entry is active, the NPC has no destination, and
 * it disappears.
 *
 * Township stores no end times at all. A schedule is a ring of transition
 * points, and the active entry is simply the last one at or before now,
 * wrapping to the end of the day. An overnight shift is not a special case;
 * it is the ordinary case. The broken state cannot be represented.
 *
 * Because of that, where an NPC is depends only on the time — never on
 * accumulated state. So NPCs are always correct after a map transfer, talking
 * to one cannot corrupt its movement, and the routine board can scrub to any
 * time and show you the truth.
 *
 * ----------------------------------------------------------------------------
 * SETTING UP A TOWN
 * ----------------------------------------------------------------------------
 *
 * 1. PLACES. Drop an event where you want an NPC to stand and put this in its
 *    note box:            <township_place:oven>
 *    The event needs no pages and no graphic — it is a marker.
 *
 * 2. DOORS. Mark where NPCs enter and leave a map:
 *                         <township_door:bakery_front>
 *
 * 3. NPCs. Give the event that represents a townsperson:
 *                         <township:baker>
 *    ...and define the "baker" actor and their schedule in a town definition
 *    plugin. TownshipDemo_Millbrook.js is a complete worked example — copy it
 *    and edit it.
 *
 * 4. Open the routine board with the OpenBoard plugin command to see every
 *    NPC's day, scrub time, and jump the world to any hour.
 *
 * ----------------------------------------------------------------------------
 * COMPATIBILITY
 * ----------------------------------------------------------------------------
 *
 * Township uses GRID movement, the same as RPG Maker's own events. It is not
 * compatible with pixel-movement or action-battle plugins that replace event
 * movement wholesale. It is stated here rather than discovered later.
 *
 * Every core method is patched by prototype extension with the original saved
 * and called, so other plugins that patch the same methods keep working.
 *
 * If you already own a day/night plugin, set "Clock source" to "variables" and
 * point Township at the variables it writes. Township will follow your clock
 * instead of running its own.
 *
 * ----------------------------------------------------------------------------
 * TERMS
 * ----------------------------------------------------------------------------
 * RPG MAKER MV (1.6): put CSAF_MVBridge.js at the TOP of the Plugin Manager.
 * Each command is a Plugin Command line, e.g.  Township SetTime hour=20 minute=30
 * The Readme lists all nine.
 *
 * Free for use in commercial and non-commercial RPG Maker MZ and MV projects.
 * Credit "CSAF" appreciated but not required. Do not redistribute or resell
 * the plugin itself. See LICENSE.txt.
 */
/*~struct~Place:
 * @param id
 * @text Place id
 * @type string
 * @desc The name schedules refer to, e.g. "oven".
 * @param mapId
 * @text Map
 * @type number
 * @min 1
 * @param x
 * @type number
 * @min 0
 * @param y
 * @type number
 * @min 0
 * @param facing
 * @text Facing
 * @type select
 * @option Down @value 2
 * @option Left @value 4
 * @option Right @value 6
 * @option Up @value 8
 * @default 2
 */
/*~struct~Door:
 * @param id
 * @text Door id
 * @type string
 * @param mapId
 * @type number
 * @min 1
 * @param x
 * @type number
 * @min 0
 * @param y
 * @type number
 * @min 0
 */
/*~struct~TagColor:
 * @param tag
 * @text Activity
 * @type string
 * @param color
 * @text Colour
 * @type string
 * @default #6f8fae
 */

(function () {
  'use strict';

  var PLUGIN = 'Township';
  var VERSION = '1.0.0';
  var SAVE_V = 1;

  var DAY_MINUTES = 1440;
  var WEEK_DEFAULT = 7;

  /** Activity tags that carry a meaning to the board. Free-form tags are allowed. */
  var KNOWN_TAGS = ['home', 'work', 'errand', 'social', 'sleep', 'travel'];

  /* ======================================================================
   * PURE ENGINE — no RPG Maker globals below this line until the binding.
   * ==================================================================== */

  /**
   * Wrap any minute value into [0, 1440), in both directions.
   * @param {number} m minutes, possibly negative or beyond one day
   * @returns {number} the equivalent minute within a single day
   */
  function normalizeMinute(m) {
    var n = Math.floor(Number(m) || 0) % DAY_MINUTES;
    if (n < 0) n += DAY_MINUTES;
    return n === 0 ? 0 : n;   // `-1440 % 1440` is -0, which escapes `n < 0` and leaks a signed zero
  }

  /**
   * Read a plugin parameter as a number, treating BLANK as absent.
   * `Number('')` is 0, not NaN, so a blank numeric field would otherwise become
   * a real zero — a frames-per-minute of 0 is a clock that never moves and
   * never errors.
   * @param {*} raw the raw parameter value
   * @param {number} dflt value to use when the parameter is absent or unreadable
   * @returns {number}
   */
  function numParam(raw, dflt) {
    if (raw === undefined || raw === null) return dflt;
    var s = String(raw).trim();
    if (s === '') return dflt;
    var n = Number(s);
    return isFinite(n) ? n : dflt;
  }

  /**
   * Parse an MZ `struct<T>[]` parameter, which is DOUBLE-encoded: a JSON string
   * whose elements are themselves JSON strings, with every leaf a string even
   * where the struct declared `@type number`. Never throws.
   * @param {*} raw the raw parameter value
   * @returns {Object[]} parsed entries, or [] for blank or malformed input
   */
  function parseStructList(raw) {
    if (raw === undefined || raw === null || String(raw).trim() === '') return [];
    var outer;
    try { outer = JSON.parse(String(raw)); } catch (e) { return []; }
    if (!Array.isArray(outer)) return [];
    var out = [];
    for (var i = 0; i < outer.length; i++) {
      var el = outer[i];
      if (typeof el === 'string') {
        try { el = JSON.parse(el); } catch (e2) { continue; }
      }
      if (el && typeof el === 'object') out.push(el);
    }
    return out;
  }

  /** Copy own string keys, refusing __proto__ so a hostile save cannot pollute. */
  function safeAssign(target, source) {
    if (!source || typeof source !== 'object') return target;
    var keys = Object.keys(source);
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i];
      if (k === '__proto__' || k === 'constructor' || k === 'prototype') continue;
      target[k] = source[k];
    }
    return target;
  }

  /* --------------------------------------------------------- town build -- */

  function fail(msg) { throw new Error(PLUGIN + ': ' + msg); }

  function assertId(v, what) {
    if (typeof v !== 'string' || !v.trim()) fail('a ' + what + ' is missing its id');
    return v.trim();
  }

  /**
   * Validate and compile a town definition into the runtime shape the resolver
   * uses. Every failure here is a loud throw at load time, because the
   * alternative is an NPC that silently stands still forever.
   * @param {Object} def raw town definition
   * @returns {Object} compiled town { id, places, doors, actors, order }
   */
  function createTown(def) {
    if (!def || typeof def !== 'object') fail('town definition must be an object');

    var town = {
      id: String(def.id || 'town'),
      places: {},
      doors: {},
      actors: {},
      order: []
    };

    /* places */
    var rawPlaces = def.places || [];
    for (var i = 0; i < rawPlaces.length; i++) {
      var p = rawPlaces[i];
      var pid = assertId(p.id, 'place');
      if (town.places[pid]) fail('duplicate place id "' + pid + '"');
      var mapId = Number(p.mapId);
      if (!isFinite(mapId) || mapId < 1) fail('place "' + pid + '" has no valid mapId');
      town.places[pid] = {
        id: pid,
        mapId: mapId,
        x: Math.floor(Number(p.x) || 0),
        y: Math.floor(Number(p.y) || 0),
        facing: Number(p.facing) || 2,
        name: String(p.name || pid)
      };
    }

    /* doors */
    var rawDoors = def.doors || [];
    for (var d = 0; d < rawDoors.length; d++) {
      var dr = rawDoors[d];
      var did = assertId(dr.id, 'door');
      if (town.doors[did]) fail('duplicate door id "' + did + '"');
      town.doors[did] = {
        id: did,
        mapId: Number(dr.mapId) || 0,
        x: Math.floor(Number(dr.x) || 0),
        y: Math.floor(Number(dr.y) || 0),
        side: Number(dr.side) || 2
      };
    }

    /* actors */
    var rawActors = def.actors || [];
    for (var a = 0; a < rawActors.length; a++) {
      var ac = rawActors[a];
      var aid = assertId(ac.id, 'actor');
      if (town.actors[aid]) fail('duplicate actor id "' + aid + '"');

      var schedules = compileSchedules(town, aid, ac.schedules);

      town.actors[aid] = {
        id: aid,
        name: String(ac.name || aid),
        home: ac.home ? String(ac.home) : null,
        sprite: ac.sprite || null,
        speed: ac.speed !== undefined ? Number(ac.speed) : null,
        eventName: ac.eventName ? String(ac.eventName) : null,
        schedules: schedules
      };
      town.order.push(aid);
    }

    if (town.actors.__proto__hack) delete town.actors.__proto__hack;
    return town;
  }

  /** Compile, validate and sort one actor's schedule variants. */
  function compileSchedules(town, actorId, raw) {
    if (!Array.isArray(raw) || raw.length === 0) {
      fail('actor "' + actorId + '" has no schedules');
    }
    var out = [];
    var seenIds = {};
    var hasBase = false;

    for (var s = 0; s < raw.length; s++) {
      var sc = raw[s];
      var sid = assertId(sc.id, 'schedule');
      if (seenIds[sid]) fail('actor "' + actorId + '" has duplicate schedule id "' + sid + '"');
      seenIds[sid] = true;

      if (!Array.isArray(sc.entries) || sc.entries.length === 0) {
        fail('schedule "' + sid + '" of actor "' + actorId + '" has no entries — ' +
             'totality could not be guaranteed');
      }

      var entries = [];
      var seenAt = {};
      for (var e = 0; e < sc.entries.length; e++) {
        var en = sc.entries[e];
        var at = Number(en.at);
        if (!isFinite(at) || at < 0 || at >= DAY_MINUTES || Math.floor(at) !== at) {
          fail('schedule "' + sid + '" of actor "' + actorId + '" has an entry whose ' +
               '"at" minute (' + en.at + ') is out of range 0-1439');
        }
        if (seenAt[at]) {
          fail('schedule "' + sid + '" of actor "' + actorId + '" has two entries at the ' +
               'same minute (' + at + ') — one would silently shadow the other');
        }
        seenAt[at] = true;

        var placeId = assertId(en.place, 'schedule entry place');
        if (!town.places[placeId]) {
          fail('schedule "' + sid + '" of actor "' + actorId + '" refers to unknown place "' +
               placeId + '"');
        }

        entries.push({
          at: at,
          place: placeId,
          tag: en.tag ? String(en.tag) : 'home',
          pose: en.pose || null
        });
      }

      entries.sort(function (x, y) { return x.at - y.at; });

      var hasCondition = !!(sc.dayType || sc.days || sc.when);
      if (!hasCondition) hasBase = true;

      out.push({
        id: sid,
        priority: numParam(sc.priority, 0),
        dayType: sc.dayType ? String(sc.dayType) : null,
        days: Array.isArray(sc.days) ? sc.days.map(Number) : null,
        when: sc.when || null,
        entries: entries
      });
    }

    if (!hasBase) {
      fail('actor "' + actorId + '" has no unconditional base schedule — every actor needs ' +
           'one schedule with no dayType, days or when, so resolution can never fail');
    }
    return out;
  }

  /* ---------------------------------------------------------- selection -- */

  /**
   * Evaluate one declarative schedule condition. Declarative rather than a JS
   * string on purpose: it is testable, serialisable, and cannot execute
   * arbitrary code out of a data file.
   * @param {Object} when condition
   * @param {Object} ctx { switches, variables }
   * @returns {boolean}
   */
  /**
   * Read a switch or variable from the context. Accepts either a plain object
   * keyed by id (what the tests use) or any object exposing `.value(id)` — which
   * is exactly $gameSwitches and $gameVariables, so the binding can pass those
   * straight through instead of building a lookup map on every resolve.
   */
  function readSlot(store, id) {
    if (!store) return 0;
    return typeof store.value === 'function' ? store.value(id) : store[id];
  }

  function evalWhen(when, ctx) {
    if (!when) return true;
    if (when.switch !== undefined) {
      return !!readSlot(ctx.switches, when.switch);
    }
    if (when.variable !== undefined) {
      var v = Number(readSlot(ctx.variables, when.variable)) || 0;
      var target = Number(when.value) || 0;
      switch (String(when.op || '>=')) {
        case '>': return v > target;
        case '>=': return v >= target;
        case '<': return v < target;
        case '<=': return v <= target;
        case '==': return v === target;
        case '!=': return v !== target;
        default: return false;
      }
    }
    return true;
  }

  /** Does this schedule variant's condition set match the current context? */
  function scheduleMatches(sc, ctx, weekLength) {
    if (sc.dayType && String(ctx.dayType || 'normal') !== sc.dayType) return false;
    if (sc.days) {
      var wl = weekLength || WEEK_DEFAULT;
      var idx = ((Math.floor(Number(ctx.dayIndex) || 0) % wl) + wl) % wl;
      if (sc.days.indexOf(idx) === -1) return false;
    }
    if (sc.when && !evalWhen(sc.when, ctx)) return false;
    return true;
  }

  /**
   * Choose which schedule variant applies. Conditional variants beat the base;
   * among matching conditionals the highest priority wins, ties by declaration
   * order. Always returns a schedule — the base is guaranteed to exist.
   * @param {Object} town compiled town
   * @param {string} actorId
   * @param {Object} ctx { dayIndex, dayType, switches, variables, weekLength, pinned }
   * @returns {Object|null} the selected schedule, or null for an unknown actor
   */
  function selectSchedule(town, actorId, ctx) {
    var actor = town.actors[actorId];
    if (!actor) return null;
    ctx = ctx || {};

    /* An explicit pin from SetScheduleVariant overrides every condition. */
    if (ctx.pinned && ctx.pinned[actorId]) {
      for (var p = 0; p < actor.schedules.length; p++) {
        if (actor.schedules[p].id === ctx.pinned[actorId]) return actor.schedules[p];
      }
    }

    var best = null;
    var base = null;
    for (var i = 0; i < actor.schedules.length; i++) {
      var sc = actor.schedules[i];
      var conditional = !!(sc.dayType || sc.days || sc.when);
      if (!conditional) { if (!base) base = sc; continue; }
      if (!scheduleMatches(sc, ctx, ctx.weekLength)) continue;
      if (!best || sc.priority > best.priority) best = sc;
    }
    return best || base;
  }

  /* ---------------------------------------------------------- resolution -- */

  /**
   * The active entry index for a minute: the LAST entry at or before it,
   * wrapping to the final entry of the day when the minute precedes the first.
   *
   * This is the whole product. There are no end times, so an overnight span is
   * not a special case and the "no entry is active" state that makes NPCs
   * disappear in span-based plugins cannot be represented.
   *
   * @param {Object[]} entries sorted ascending by `at`
   * @param {number} minute normalised 0-1439
   * @returns {number} index into entries, always valid when entries is non-empty
   */
  function activeIndex(entries, minute) {
    var n = entries.length;
    if (n === 0) return -1;
    if (minute < entries[0].at) return n - 1;   // before the first change today: yesterday's last
    var i = n - 1;
    while (i > 0 && entries[i].at > minute) i--;
    return i;
  }

  /**
   * Resolve where an actor is and what they are doing at a given time.
   * Pure: depends only on (town, minute, ctx). No accumulated state, so this is
   * correct immediately after a map transfer and safe to call for a time the
   * world is not at (the routine board scrubs with it).
   *
   * @param {Object} town compiled town
   * @param {string} actorId
   * @param {number} minute any minute value; normalised internally
   * @param {Object} ctx { dayIndex, dayType, switches, variables, weekLength, pinned }
   * @returns {Object|null} activity, or null for an unknown actor
   */
  function resolve(town, actorId, minute, ctx) {
    var actor = town.actors[actorId];
    if (!actor) return null;
    var schedule = selectSchedule(town, actorId, ctx);
    if (!schedule) return null;

    var m = normalizeMinute(minute);
    var entries = schedule.entries;
    var idx = activeIndex(entries, m);
    var entry = entries[idx];
    var next = entries[(idx + 1) % entries.length];

    var sinceMin = entry.at;
    var untilMin = next.at;
    var elapsed = normalizeMinute(m - sinceMin);
    var span = entries.length === 1 ? DAY_MINUTES : normalizeMinute(untilMin - sinceMin) || DAY_MINUTES;

    return {
      actorId: actorId,
      schedule: schedule,
      entry: entry,
      entryIndex: idx,
      place: town.places[entry.place],
      pose: entry.pose || null,
      tag: entry.tag,
      sinceMin: sinceMin,
      untilMin: untilMin,
      elapsedMin: elapsed,
      spanMin: span
    };
  }

  /**
   * The actor's whole day as drawable segments in [0, 1440), for the routine
   * board. Segments abut exactly and always total 1440 minutes; a span that
   * crosses midnight is emitted as TWO segments sharing one entryIndex and
   * flagged `wrap`, which is what lets the board draw an overnight shift as a
   * continuous band around the strip edge.
   *
   * @param {Object} town compiled town
   * @param {string} actorId
   * @param {Object} ctx resolution context
   * @returns {Object[]} [{ from, to, tag, place, entryIndex, wrap }]
   */
  function dayStrip(town, actorId, ctx) {
    var schedule = selectSchedule(town, actorId, ctx);
    if (!schedule) return [];
    var entries = schedule.entries;
    var out = [];

    /* One entry covers the whole day as a single band — splitting it at its own
     * start time would draw a seam that means nothing. */
    if (entries.length === 1) {
      out.push({
        from: 0, to: DAY_MINUTES, tag: entries[0].tag,
        place: entries[0].place, entryIndex: 0, wrap: false
      });
      return out;
    }

    for (var i = 0; i < entries.length; i++) {
      var start = entries[i].at;
      var end = entries[(i + 1) % entries.length].at;
      var wraps = end <= start;
      if (!wraps) {
        out.push({
          from: start, to: end, tag: entries[i].tag,
          place: entries[i].place, entryIndex: i, wrap: false
        });
      } else {
        /* crosses midnight: tail of today, then head of tomorrow */
        if (start < DAY_MINUTES) {
          out.push({
            from: start, to: DAY_MINUTES, tag: entries[i].tag,
            place: entries[i].place, entryIndex: i, wrap: true
          });
        }
        if (end > 0) {
          out.push({
            from: 0, to: end, tag: entries[i].tag,
            place: entries[i].place, entryIndex: i, wrap: true
          });
        }
      }
    }
    return out;
  }

  /* --------------------------------------------------------------- save -- */

  /**
   * A fresh persisted state. Deliberately tiny: positions, paths and avatar
   * bindings are all DERIVED from the clock (see resolve), so none of them is
   * stored and none of them can be restored inconsistently.
   * @returns {Object}
   */
  function createState() {
    return {
      v: SAVE_V,
      clock: { min: 8 * 60, day: 0 },
      calendar: { dayType: 'normal', flags: {} },
      overrides: {},
      pinned: {}
    };
  }

  /**
   * Bring a persisted state forward to the current schema. Idempotent, and
   * refuses `__proto__` keys rather than assigning them.
   * @param {Object} raw state read from a save
   * @returns {Object} a state at the current version
   */
  function migrate(raw) {
    var s = createState();
    if (!raw || typeof raw !== 'object') return s;

    if (raw.clock && typeof raw.clock === 'object') {
      s.clock.min = normalizeMinute(numParam(raw.clock.min, s.clock.min));
      s.clock.day = Math.floor(numParam(raw.clock.day, 0));
    }
    if (raw.calendar && typeof raw.calendar === 'object') {
      s.calendar.dayType = String(raw.calendar.dayType || 'normal');
      safeAssign(s.calendar.flags, raw.calendar.flags);
    }
    safeAssign(s.overrides, raw.overrides);
    safeAssign(s.pinned, raw.pinned);
    s.v = SAVE_V;
    return s;
  }

  /* The registered town. Kept in the PURE section deliberately: a town
   * definition is data, so it must be validatable with no engine present.
   * That is what lets the headless suite and the span probe load the real
   * shipped Millbrook file instead of a hand-copied fixture that could drift
   * away from it. */
  var TOWN = null;

  /**
   * Register a town. Content plugins call this at load time. Throws loudly on
   * a bad definition — the alternative is an NPC that stands still forever
   * with no error anywhere.
   * @param {Object} def town definition
   * @returns {Object} the compiled town
   */
  function defineTown(def) {
    TOWN = createTown(def);
    return TOWN;
  }

  /** @returns {Object|null} the registered town. */
  function town() { return TOWN; }

  var Engine = {
    VERSION: VERSION,
    SAVE_V: SAVE_V,
    defineTown: defineTown,
    town: town,
    DAY_MINUTES: DAY_MINUTES,
    KNOWN_TAGS: KNOWN_TAGS,
    normalizeMinute: normalizeMinute,
    numParam: numParam,
    parseStructList: parseStructList,
    createTown: createTown,
    selectSchedule: selectSchedule,
    activeIndex: activeIndex,
    resolve: resolve,
    dayStrip: dayStrip,
    createState: createState,
    migrate: migrate
  };

  /* Headless: export the pure engine and stop before any engine binding. */
  if (typeof PluginManager === 'undefined') {
    if (typeof module !== 'undefined' && module.exports) module.exports = Engine;
    return;
  }

  /* ======================================================================
   * ENGINE BINDING — everything below runs only inside RPG Maker MZ.
   * ==================================================================== */

  var params = PluginManager.parameters(PLUGIN);

  var CFG = {
    timeSource: String(params.timeSource || 'internal'),
    framesPerGameMinute: numParam(params.framesPerGameMinute, 30),
    varHour: numParam(params.varHour, 0),
    varMinute: numParam(params.varMinute, 0),
    varDay: numParam(params.varDay, 0),
    timeScript: String(params.timeScript || ''),
    weekLength: numParam(params.weekLength, WEEK_DEFAULT),
    walkSpeed: numParam(params.walkSpeed, 3),
    pathBudget: numParam(params.pathBudget, 600),
    transitionFrames: numParam(params.transitionFrames, 24),
    boardEnabled: String(params.boardEnabled) !== 'false',
    tagColors: {}
  };

  (function () {
    var list = parseStructList(params.tagColors);
    for (var i = 0; i < list.length; i++) {
      if (list[i].tag) CFG.tagColors[String(list[i].tag)] = String(list[i].color || '#888888');
    }
    for (var k = 0; k < KNOWN_TAGS.length; k++) {
      if (!CFG.tagColors[KNOWN_TAGS[k]]) CFG.tagColors[KNOWN_TAGS[k]] = '#8a8a8a';
    }
  })();

  /**
   * Runtime lives in MODULE scope, never on $gameSystem.
   *
   * Wing CLAUDE.md §13 puts a live wrapper in a NON-ENUMERABLE slot because
   * there the wrapper mirrors the persisted record, and serialising both yields
   * two copies that drift. Township has no such wrapper: positions, paths and
   * avatar bindings are all DERIVED from the clock (see resolve), so there is
   * nothing to persist and nothing to keep in sync. A module-level object cannot
   * be reached by JsonEx at all — including by paths that do not exist yet —
   * which is a stronger guarantee than hiding a property.
   */
  var RT = {
    avatars: {},        // eventId -> avatar record (allocated at bind time only)
    order: [],          // stable iteration without Object.keys per frame
    mapId: 0,
    frameAcc: 0,
    lastMinute: -1,
    pathQueue: [],
    scratch: null,
    warned: {}
  };

  /* Reused buffers — these exist so the per-frame path allocates nothing. */
  var TIME_BUF = { min: 0, day: 0 };
  var CTX = {
    dayIndex: 0, dayType: 'normal', switches: null, variables: null,
    weekLength: WEEK_DEFAULT, pinned: null
  };

  function warnOnce(key, msg) {
    if (RT.warned[key]) return;
    RT.warned[key] = true;
    console.warn(PLUGIN + ': ' + msg);
  }

  /* ------------------------------------------------------------- state -- */

  /** The persisted state, plain JSON on $gameSystem so MZ saves it normally. */
  function st() {
    if (!$gameSystem) return null;
    if (!$gameSystem._csafTownship) $gameSystem._csafTownship = createState();
    return $gameSystem._csafTownship;
  }

  var _DM_makeSave = DataManager.makeSaveContents;
  DataManager.makeSaveContents = function () {
    return _DM_makeSave.call(this);
  };

  var _DM_extractSave = DataManager.extractSaveContents;
  DataManager.extractSaveContents = function (contents) {
    _DM_extractSave.call(this, contents);
    if ($gameSystem) $gameSystem._csafTownship = migrate($gameSystem._csafTownship);
    RT.lastMinute = -1;   // force a re-place on the next update
  };

  /* -------------------------------------------------------------- time -- */

  /**
   * Current town time. Returns a REUSED object — never retain it across frames.
   * @returns {{min:number, day:number}}
   */
  function now() {
    var s = st();
    if (CFG.timeSource === 'variables') {
      var h = CFG.varHour ? $gameVariables.value(CFG.varHour) : 0;
      var m = CFG.varMinute ? $gameVariables.value(CFG.varMinute) : 0;
      TIME_BUF.min = normalizeMinute(Number(h) * 60 + Number(m));
      TIME_BUF.day = CFG.varDay ? Math.floor(Number($gameVariables.value(CFG.varDay)) || 0) : 0;
      return TIME_BUF;
    }
    if (CFG.timeSource === 'script' && CFG.timeScript) {
      try {
        /* SECURITY / TRUST BOUNDARY, stated because you can read this source:
         * this eval runs ONLY the "Time script" plugin parameter, which is typed
         * by the game developer into their own Plugin Manager — the same trust
         * boundary as RPG Maker's own Script event command and its @type note
         * parameters, which the engine evals identically. It never evaluates
         * save data, player input, or anything from the network: schedule
         * conditions are declarative data (see evalWhen) precisely so that a
         * town definition can never execute code. An MZ @type note parameter
         * arrives JSON-quoted, so JSON.parse unwraps it before evaluation.
         * Set "Clock source" to internal or variables and this never runs. */
        var r = eval(JSON.parse(CFG.timeScript));
        if (r && typeof r === 'object') {
          TIME_BUF.min = normalizeMinute(r.min);
          TIME_BUF.day = Math.floor(Number(r.day) || 0);
          return TIME_BUF;
        }
      } catch (e) {
        warnOnce('timescript', 'the time script threw, falling back to the internal clock: ' + e.message);
      }
    }
    TIME_BUF.min = s ? s.clock.min : 0;
    TIME_BUF.day = s ? s.clock.day : 0;
    return TIME_BUF;
  }

  /** Build the reused resolution context. Allocates nothing. */
  function context() {
    var s = st();
    var t = now();
    CTX.dayIndex = t.day;
    CTX.dayType = s ? s.calendar.dayType : 'normal';
    CTX.switches = $gameSwitches;
    CTX.variables = $gameVariables;
    CTX.weekLength = CFG.weekLength;
    CTX.pinned = s ? s.pinned : null;
    return CTX;
  }

  /** Advance the internal clock. Called once per map frame. */
  function tickClock() {
    if (CFG.timeSource !== 'internal') return;
    var s = st();
    if (!s) return;
    RT.frameAcc++;
    if (RT.frameAcc < CFG.framesPerGameMinute) return;
    RT.frameAcc = 0;
    s.clock.min += 1;
    if (s.clock.min >= DAY_MINUTES) { s.clock.min = 0; s.clock.day += 1; }
  }

  /* ------------------------------------------------------- pathfinding -- */

  /**
   * A* over map passability, with every structure allocated ONCE and reused.
   * Called on activity change, never per frame, and at most one solve per frame
   * across the whole town (see RT.pathQueue) so a crowded map cannot spike.
   */
  function ensureScratch(w, h) {
    var n = w * h;
    if (RT.scratch && RT.scratch.n >= n) { RT.scratch.w = w; RT.scratch.h = h; return RT.scratch; }
    RT.scratch = {
      n: n, w: w, h: h,
      g: new Int32Array(n),
      from: new Int32Array(n),
      stamp: new Int32Array(n),
      gen: 0,
      heap: new Int32Array(n + 1),
      heapF: new Int32Array(n + 1),
      heapLen: 0
    };
    return RT.scratch;
  }

  function heapPush(sc, node, f) {
    var i = ++sc.heapLen;
    sc.heap[i] = node; sc.heapF[i] = f;
    while (i > 1) {
      var p = i >> 1;
      if (sc.heapF[p] <= sc.heapF[i]) break;
      var tn = sc.heap[p]; sc.heap[p] = sc.heap[i]; sc.heap[i] = tn;
      var tf = sc.heapF[p]; sc.heapF[p] = sc.heapF[i]; sc.heapF[i] = tf;
      i = p;
    }
  }

  function heapPop(sc) {
    var top = sc.heap[1];
    sc.heap[1] = sc.heap[sc.heapLen];
    sc.heapF[1] = sc.heapF[sc.heapLen];
    sc.heapLen--;
    var i = 1;
    for (;;) {
      var l = i << 1, r = l + 1, best = i;
      if (l <= sc.heapLen && sc.heapF[l] < sc.heapF[best]) best = l;
      if (r <= sc.heapLen && sc.heapF[r] < sc.heapF[best]) best = r;
      if (best === i) break;
      var tn = sc.heap[best]; sc.heap[best] = sc.heap[i]; sc.heap[i] = tn;
      var tf = sc.heapF[best]; sc.heapF[best] = sc.heapF[i]; sc.heapF[i] = tf;
      i = best;
    }
    return top;
  }

  var DIRS = [2, 4, 6, 8];

  function stepX(x, d) { return $gameMap.roundXWithDirection(x, d); }
  function stepY(y, d) { return $gameMap.roundYWithDirection(y, d); }
  function reverseDir(d) { return 10 - d; }

  function canStep(chr, x, y, d) {
    var nx = stepX(x, d), ny = stepY(y, d);
    if (!$gameMap.isValid(nx, ny)) return false;
    if (!$gameMap.isPassable(x, y, d)) return false;
    if (!$gameMap.isPassable(nx, ny, reverseDir(d))) return false;
    if (chr && chr.isCollidedWithCharacters && chr.isCollidedWithCharacters(nx, ny)) return false;
    return true;
  }

  /**
   * Solve a path and write it into the avatar's pre-allocated direction buffer.
   * @returns {boolean} true if a complete path was found
   */
  function solvePath(av, chr, gx, gy) {
    var w = $gameMap.width(), h = $gameMap.height();
    var sc = ensureScratch(w, h);
    sc.gen++;
    sc.heapLen = 0;

    var sx = chr.x, sy = chr.y;
    if (sx === gx && sy === gy) { av.pathLen = 0; av.pathPos = 0; return true; }

    var start = sy * w + sx, goal = gy * w + gx;
    sc.g[start] = 0; sc.stamp[start] = sc.gen; sc.from[start] = -1;
    heapPush(sc, start, Math.abs(sx - gx) + Math.abs(sy - gy));

    var expansions = 0;
    var found = false;
    while (sc.heapLen > 0) {
      if (++expansions > CFG.pathBudget) break;
      var cur = heapPop(sc);
      if (cur === goal) { found = true; break; }
      var cx = cur % w, cy = (cur - cx) / w;
      for (var i = 0; i < 4; i++) {
        var d = DIRS[i];
        if (!canStep(chr, cx, cy, d)) continue;
        var nx = stepX(cx, d), ny = stepY(cy, d);
        var ni = ny * w + nx;
        var ng = sc.g[cur] + 1;
        if (sc.stamp[ni] === sc.gen && sc.g[ni] <= ng) continue;
        sc.stamp[ni] = sc.gen;
        sc.g[ni] = ng;
        sc.from[ni] = cur;
        heapPush(sc, ni, ng + Math.abs(nx - gx) + Math.abs(ny - gy));
      }
    }
    if (!found) return false;

    /* Walk the chain back into the fixed buffer, then reverse in place. */
    var len = 0, node = goal;
    while (node !== start && len < av.path.length) {
      var prev = sc.from[node];
      var px = prev % w, py = (prev - px) / w;
      var nx2 = node % w, ny2 = (node - nx2) / w;
      var dd = 2;
      if (nx2 > px || (nx2 === 0 && px === w - 1)) dd = 6;
      else if (nx2 < px || (nx2 === w - 1 && px === 0)) dd = 4;
      else if (ny2 > py || (ny2 === 0 && py === h - 1)) dd = 2;
      else dd = 8;
      av.path[len++] = dd;
      node = prev;
    }
    if (node !== start) return false;   // buffer overrun: treat as unreachable
    for (var a = 0, b = len - 1; a < b; a++, b--) {
      var t = av.path[a]; av.path[a] = av.path[b]; av.path[b] = t;
    }
    av.pathLen = len;
    av.pathPos = 0;
    return true;
  }

  /* ------------------------------------------------------------ avatars -- */

  function noteMatch(note, tag) {
    var m = /<township([a-z_]*):\s*([^>]+)>/gi;
    var r;
    while ((r = m.exec(note)) !== null) {
      if (String(r[1] || '').toLowerCase() === tag) return String(r[2]).trim();
    }
    return null;
  }

  /**
   * Bind every scheduled NPC that has an event on this map, and read any
   * <township_place:id> / <township_door:id> markers to override coordinates.
   * All allocation for an avatar happens HERE, once, never per frame.
   */
  function onMapSetup(mapId) {
    RT.avatars = {};
    RT.order.length = 0;
    RT.pathQueue.length = 0;
    RT.mapId = mapId;
    RT.lastMinute = -1;
    if (!TOWN || !$dataMap || !$dataMap.events) return;

    var events = $gameMap.events();
    for (var i = 0; i < events.length; i++) {
      var ev = events[i];
      var data = ev.event();
      if (!data || !data.note) continue;

      var placeId = noteMatch(data.note, '_place');
      if (placeId && TOWN.places[placeId]) {
        TOWN.places[placeId].mapId = mapId;
        TOWN.places[placeId].x = ev.x;
        TOWN.places[placeId].y = ev.y;
        continue;
      }

      var doorId = noteMatch(data.note, '_door');
      if (doorId && TOWN.doors[doorId]) {
        TOWN.doors[doorId].mapId = mapId;
        TOWN.doors[doorId].x = ev.x;
        TOWN.doors[doorId].y = ev.y;
        continue;
      }

      var actorId = noteMatch(data.note, '');
      if (!actorId) continue;
      if (!TOWN.actors[actorId]) {
        warnOnce('actor:' + actorId,
          'event ' + ev.eventId() + ' on map ' + mapId + ' is tagged <township:' + actorId +
          '> but no such actor is defined. The event will behave normally.');
        continue;
      }

      var actor = TOWN.actors[actorId];
      RT.avatars[ev.eventId()] = {
        actorId: actorId,
        eventId: ev.eventId(),
        path: new Int8Array(256),
        pathLen: 0,
        pathPos: 0,
        goalX: -1,
        goalY: -1,
        placeId: null,
        posed: false,
        baseSprite: null,
        paused: false,
        fade: 0,
        fadeDir: 0,
        present: true,
        pathPending: false
      };
      RT.order.push(ev.eventId());
      ev.setMoveSpeed(actor.speed || CFG.walkSpeed);
      ev.setThrough(false);
    }
    placeAllInstantly();
  }

  /* ------------------------------------------------------ arrival slots --
   * Two townspeople scheduled to the same place must not fight over one tile.
   * The innkeeper WORKS at the tavern while four others drink there at 19:00,
   * so the exact place tile is routinely occupied — and a plugin that insists
   * on it either fails to path or stacks sprites on top of each other.
   *
   * So a place is a destination, not a parking space: an arriving NPC claims
   * the place tile if it is free, otherwise the nearest free tile around it.
   * People CLUSTER around a spot, which is what a gathering actually looks
   * like, and it is why "everyone meets at the tavern" needs no gathering
   * system at all.
   *
   * Searched in a fixed order so the result is deterministic and reproducible.
   */
  var RING = [
    0, 0, 0, 1, 1, 0, 0, -1, -1, 0,
    1, 1, 1, -1, -1, 1, -1, -1,
    0, 2, 2, 0, 0, -2, -2, 0,
    1, 2, 2, 1, -1, 2, 2, -1, 1, -2, -2, 1, -1, -2, -2, -1
  ];
  var SLOT = { x: 0, y: 0, exact: true };

  /** Can a character stand on this tile at all? */
  function tileStandable(x, y) {
    if (!$gameMap.isValid(x, y)) return false;
    for (var i = 0; i < 4; i++) {
      if ($gameMap.isPassable(x, y, DIRS[i])) return true;
    }
    return false;
  }

  /** Is another normal-priority event, or another avatar's claimed goal, here? */
  function tileTaken(exceptEventId, x, y) {
    var evs = $gameMap.eventsXyNt(x, y);
    for (var i = 0; i < evs.length; i++) {
      if (evs[i].eventId() !== exceptEventId && evs[i].isNormalPriority()) return true;
    }
    if ($gamePlayer && $gamePlayer.x === x && $gamePlayer.y === y) return true;
    for (var k = 0; k < RT.order.length; k++) {
      var id = RT.order[k];
      if (id === exceptEventId) continue;
      var other = RT.avatars[id];
      if (other && other.present && other.goalX === x && other.goalY === y) return true;
    }
    return false;
  }

  /**
   * Choose the tile this NPC will actually stand on for a place. Returns a
   * REUSED object; read it immediately. Falls back to the exact place tile if
   * the whole neighbourhood is busy, which is better than refusing to go.
   */
  function claimTile(eventId, place) {
    for (var i = 0; i < RING.length; i += 2) {
      var x = place.x + RING[i];
      var y = place.y + RING[i + 1];
      if (!tileStandable(x, y)) continue;
      if (tileTaken(eventId, x, y)) continue;
      SLOT.x = x; SLOT.y = y; SLOT.exact = (i === 0);
      return SLOT;
    }
    SLOT.x = place.x; SLOT.y = place.y; SLOT.exact = true;
    return SLOT;
  }

  /** Where should this actor be right now? Returns a place or null (off-map). */
  function currentPlace(actorId) {
    if (!TOWN) return null;
    var act = resolve(TOWN, actorId, now().min, context());
    if (!act) return null;
    var s = st();
    var ov = s && s.overrides[actorId];
    if (ov && ov.placeId && TOWN.places[ov.placeId]) {
      if (ov.untilMin === undefined || ov.untilMin < 0 ||
          normalizeMinute(now().min) !== normalizeMinute(ov.untilMin)) {
        return TOWN.places[ov.placeId];
      }
      delete s.overrides[actorId];
    }
    return act.place;
  }

  /** Apply an entry's pose to a character. */
  function applyPose(ev, av, pose) {
    if (!pose) {
      if (av.posed && av.baseSprite) {
        ev.setImage(av.baseSprite.name, av.baseSprite.index);
        ev.setStepAnime(false);
        av.posed = false;
      }
      return;
    }
    if (!av.baseSprite) av.baseSprite = { name: ev.characterName(), index: ev.characterIndex() };
    if (pose.sprite && pose.sprite.name) {
      ev.setImage(pose.sprite.name, Number(pose.sprite.index) || 0);
    }
    if (pose.dir) ev.setDirection(Number(pose.dir));
    ev.setStepAnime(!!pose.stepAnim);
    if (pose.balloon !== undefined) {
      // MZ queues balloons on $gameTemp; MV keeps one on the character itself
      // (Game_CharacterBase.requestBalloon). 1.1: MV used to skip the balloon
      // in silence, because only the MZ route was tried.
      if ($gameTemp && $gameTemp.requestBalloon) $gameTemp.requestBalloon(ev, Number(pose.balloon));
      else if (ev.requestBalloon) ev.requestBalloon(Number(pose.balloon));
    }
    av.posed = true;
  }

  /** Put every bound NPC exactly where the clock says, with no walking. */
  function placeAllInstantly() {
    for (var i = 0; i < RT.order.length; i++) {
      var id = RT.order[i];
      var av = RT.avatars[id];
      var ev = $gameMap.event(id);
      if (!ev || !av) continue;
      var place = currentPlace(av.actorId);
      av.pathLen = 0; av.pathPos = 0;
      if (!place || place.mapId !== RT.mapId) {
        av.present = false;
        ev.setOpacity(0);
        ev.setThrough(true);
        continue;
      }
      av.present = true;
      av.placeId = place.id;
      ev.setThrough(false);
      ev.setOpacity(255);
      var slot = claimTile(id, place);
      av.goalX = slot.x; av.goalY = slot.y;
      ev.locate(slot.x, slot.y);
      if (place.facing) ev.setDirection(place.facing);
      var act = resolve(TOWN, av.actorId, now().min, context());
      applyPose(ev, av, act ? act.pose : null);
    }
  }

  /** React to a change of minute: re-target anyone whose destination moved. */
  function retarget() {
    for (var i = 0; i < RT.order.length; i++) {
      var id = RT.order[i];
      var av = RT.avatars[id];
      var ev = $gameMap.event(id);
      if (!ev || !av || av.paused) continue;

      var place = currentPlace(av.actorId);
      var onThisMap = !!place && place.mapId === RT.mapId;

      /* Leaving the map: walk to the nearest door, then fade out. */
      if (av.present && !onThisMap) {
        var door = nearestDoor(ev);
        if (door && CFG.transitionFrames > 0) {
          av.placeId = null;
          if (av.goalX !== door.x || av.goalY !== door.y) {
            av.goalX = door.x; av.goalY = door.y;
            queuePath(av, ev, door.x, door.y);
          }
          if (ev.x === door.x && ev.y === door.y) { av.fadeDir = -1; }
        } else {
          av.present = false; ev.setOpacity(0); ev.setThrough(true);
        }
        continue;
      }

      /* Arriving on the map: appear at a door and walk in. */
      if (!av.present && onThisMap) {
        var d2 = nearestDoorToPlace(place);
        av.present = true;
        ev.setThrough(false);
        if (d2 && CFG.transitionFrames > 0) {
          ev.locate(d2.x, d2.y);
          ev.setOpacity(0);
          av.fadeDir = 1;
        } else {
          ev.locate(place.x, place.y);
          ev.setOpacity(255);
        }
      }

      if (!place || !av.present) continue;

      if (av.placeId !== place.id) {
        var slot = claimTile(id, place);
        av.placeId = place.id;
        av.goalX = slot.x;
        av.goalY = slot.y;
        applyPose(ev, av, null);        // drop the old pose while travelling
        queuePath(av, ev, slot.x, slot.y);
      }
    }
  }

  function queuePath(av, ev, gx, gy) {
    if (av.pathPending) return;
    av.pathPending = true;
    RT.pathQueue.push(av.eventId);
  }

  /** At most ONE path solve per frame across the whole town. */
  function servePathQueue() {
    if (RT.pathQueue.length === 0) return;
    var id = RT.pathQueue.shift();
    var av = RT.avatars[id];
    var ev = $gameMap.event(id);
    if (!av || !ev) return;
    av.pathPending = false;
    if (av.goalX < 0) return;
    if (!solvePath(av, ev, av.goalX, av.goalY)) {
      /* STAY PUT. Do NOT teleport home — a character that jumps across the map
       * is precisely the pop-in this product exists to remove, and it would be
       * a self-inflicted version of the incumbent's complaint #2. Standing
       * still is visibly wrong in a way a developer can debug; a teleport looks
       * like a different bug entirely. */
      warnOnce('unreachable:' + av.actorId + ':' + av.placeId,
        'could not path ' + av.actorId + ' to "' + av.placeId + '" — they will wait where they ' +
        'are. Check the route is walkable, or raise the pathfinding budget.');
      av.pathLen = 0;
      av.pathPos = 0;
      av.goalX = ev.x;
      av.goalY = ev.y;
    }
  }

  function nearestDoor(ev) {
    var best = null, bestD = Infinity;
    for (var k in TOWN.doors) {
      var d = TOWN.doors[k];
      if (d.mapId !== RT.mapId) continue;
      var dist = Math.abs(d.x - ev.x) + Math.abs(d.y - ev.y);
      if (dist < bestD) { bestD = dist; best = d; }
    }
    return best;
  }

  function nearestDoorToPlace(place) {
    var best = null, bestD = Infinity;
    for (var k in TOWN.doors) {
      var d = TOWN.doors[k];
      if (d.mapId !== RT.mapId) continue;
      var dist = Math.abs(d.x - place.x) + Math.abs(d.y - place.y);
      if (dist < bestD) { bestD = dist; best = d; }
    }
    return best;
  }

  /* ------------------------------------------------------- per-frame -- */

  /**
   * The per-frame hot path. Allocates nothing: no literals, no closures, no
   * array methods. Enforced statically by Internal_Ops/tests/hot_path.test.js.
   */
  function updateAvatars() {
    for (var i = 0; i < RT.order.length; i++) {
      var id = RT.order[i];
      var av = RT.avatars[id];
      var ev = $gameMap.event(id);
      if (!ev || !av) continue;

      if (av.fadeDir !== 0) {
        var stepAmt = Math.ceil(255 / Math.max(1, CFG.transitionFrames));
        if (av.fadeDir > 0) {
          ev.setOpacity(Math.min(255, ev.opacity() + stepAmt));
          if (ev.opacity() >= 255) av.fadeDir = 0;
        } else {
          ev.setOpacity(Math.max(0, ev.opacity() - stepAmt));
          if (ev.opacity() <= 0) {
            av.fadeDir = 0;
            av.present = false;
            ev.setThrough(true);
          }
        }
      }

      if (av.paused || !av.present) continue;
      if (ev.isMoving()) continue;

      if (av.pathPos < av.pathLen) {
        ev.moveStraight(av.path[av.pathPos]);
        if (ev.isMovementSucceeded()) {
          av.pathPos++;
        } else {
          av.pathLen = 0;
          av.pathPos = 0;
          queuePath(av, ev, av.goalX, av.goalY);   // blocked: re-solve once
        }
        continue;
      }

      /* Arrived. Apply the destination pose exactly once. */
      if (!av.posed && av.placeId && ev.x === av.goalX && ev.y === av.goalY) {
        var place = TOWN.places[av.placeId];
        if (place && place.facing) ev.setDirection(place.facing);
        var act = resolve(TOWN, av.actorId, now().min, context());
        applyPose(ev, av, act ? act.pose : null);
      }
    }
  }

  /* ------------------------------------------------------------ hooks -- */

  var _GM_setup = Game_Map.prototype.setup;
  Game_Map.prototype.setup = function (mapId) {
    _GM_setup.call(this, mapId);
    onMapSetup(mapId);
  };

  var _SM_update = Scene_Map.prototype.update;
  Scene_Map.prototype.update = function () {
    _SM_update.call(this);
    if (!TOWN || !$gameMap) return;
    tickClock();
    var t = now();
    if (t.min !== RT.lastMinute) {
      RT.lastMinute = t.min;
      retarget();
    }
    servePathQueue();
    updateAvatars();
  };

  /* Interaction pause: stop cleanly, and resume by RE-RESOLVING rather than by
   * restoring saved path state. There is nothing to restore, which is why this
   * cannot desynchronise the NPC's movement. */
  var _GE_lock = Game_Event.prototype.lock;
  Game_Event.prototype.lock = function () {
    _GE_lock.call(this);
    var av = RT.avatars[this._eventId];
    if (av) { av.paused = true; }
  };

  var _GE_unlock = Game_Event.prototype.unlock;
  Game_Event.prototype.unlock = function () {
    _GE_unlock.call(this);
    var av = RT.avatars[this._eventId];
    if (av && av.paused) {
      av.paused = false;
      av.pathLen = 0;
      av.pathPos = 0;
      av.placeId = null;   // force a fresh resolve on the next minute tick
      RT.lastMinute = -1;
    }
  };

  /* ------------------------------------------------------- commands -- */

  function cmdActor(args) { return String(args.actorId || '').trim(); }

  PluginManager.registerCommand(PLUGIN, 'OpenBoard', function () {
    if (!CFG.boardEnabled) return;
    if (typeof Scene_TownshipBoard === 'undefined') {
      warnOnce('noboard', 'TownshipBoard.js is not installed, so the routine board cannot open.');
      return;
    }
    SceneManager.push(Scene_TownshipBoard);
  });

  PluginManager.registerCommand(PLUGIN, 'SetTime', function (args) {
    var s = st();
    if (!s) return;
    s.clock.min = normalizeMinute(numParam(args.hour, 8) * 60 + numParam(args.minute, 0));
    RT.frameAcc = 0;
    RT.lastMinute = -1;
    if (RT.mapId) placeAllInstantly();
  });

  PluginManager.registerCommand(PLUGIN, 'AdvanceMinutes', function (args) {
    var s = st();
    if (!s) return;
    var add = numParam(args.minutes, 60);
    var total = s.clock.min + add;
    s.clock.day += Math.floor(total / DAY_MINUTES);
    s.clock.min = normalizeMinute(total);
    RT.lastMinute = -1;
    if (RT.mapId) placeAllInstantly();
  });

  PluginManager.registerCommand(PLUGIN, 'SetDayType', function (args) {
    var s = st();
    if (!s) return;
    s.calendar.dayType = String(args.dayType || 'normal');
    RT.lastMinute = -1;
  });

  PluginManager.registerCommand(PLUGIN, 'ForceActivity', function (args) {
    var s = st();
    if (!s || !TOWN) return;
    var id = cmdActor(args);
    var placeId = String(args.placeId || '').trim();
    if (!TOWN.actors[id] || !TOWN.places[placeId]) {
      warnOnce('force:' + id + placeId, 'ForceActivity: unknown actor or place (' + id + ' -> ' + placeId + ')');
      return;
    }
    var until = numParam(args.untilHour, -1);
    s.overrides[id] = { placeId: placeId, untilMin: until >= 0 ? until * 60 : -1 };
    RT.lastMinute = -1;
  });

  PluginManager.registerCommand(PLUGIN, 'ReleaseActor', function (args) {
    var s = st();
    if (!s) return;
    delete s.overrides[cmdActor(args)];
    RT.lastMinute = -1;
  });

  PluginManager.registerCommand(PLUGIN, 'ActorPlaceToVar', function (args) {
    var varId = numParam(args.variableId, 0);
    if (!varId) return;
    var place = currentPlace(cmdActor(args));
    $gameVariables.setValue(varId, place ? place.id : '');
  });

  PluginManager.registerCommand(PLUGIN, 'ActorAtPlace', function (args) {
    var swId = numParam(args.switchId, 0);
    if (!swId) return;
    var place = currentPlace(cmdActor(args));
    $gameSwitches.setValue(swId, !!place && place.id === String(args.placeId || '').trim());
  });

  PluginManager.registerCommand(PLUGIN, 'SetScheduleVariant', function (args) {
    var s = st();
    if (!s) return;
    var id = cmdActor(args);
    var sched = String(args.scheduleId || '').trim();
    if (sched) s.pinned[id] = sched; else delete s.pinned[id];
    RT.lastMinute = -1;
  });

  /* --------------------------------------------------------- exposure -- */

  Engine.CFG = CFG;
  Engine.RT = RT;
  Engine.state = st;
  Engine.now = now;
  Engine.context = context;
  Engine.currentPlace = currentPlace;
  Engine.placeAllInstantly = placeAllInstantly;


  window.Township = Engine;

})();
