//=============================================================================
// TownshipBoard.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.1.0] The routine board — every townsperson's whole day as coloured strips, a sweeping day dial and a live map. Scrub time, then send the world there.
 * @author CSAF — Core Systems Asset Factory
 * @url https://csaf.itch.io/township
 * @base Township
 * @orderAfter Township
 *
 * @help
 * ============================================================================
 * The routine board
 * ============================================================================
 *
 * Open it with the OpenBoard plugin command from Township.js.
 *
 *   LEFT / RIGHT      scrub time by ten minutes  (hold SHIFT for an hour)
 *   UP / DOWN         choose a townsperson
 *   OK  (Enter/Z)     SET THE WORLD CLOCK to the time you scrubbed to
 *   SHIFT + OK        put the player next to the selected townsperson
 *   PAGE UP/DOWN      cycle the day type (normal / market / festival)
 *   CANCEL (Esc/X)    close
 *
 * It is a director's console, not a report: everything you can see, you can
 * also act on. Scrubbing previews; OK commits.
 *
 * READING A STRIP
 *
 * Each row is one person's whole day, midnight to midnight, coloured by what
 * they are doing. An overnight span — a night watch, a late innkeeper — is
 * drawn as ONE band that runs off the right edge and continues at the left,
 * marked with a chevron at both ends. That band is the thing most schedule
 * plugins cannot represent at all.
 *
 * This scene draws no RPG Maker windows. Every panel, strip and label is drawn
 * by this plugin, so the board does not look like the engine.
 *
 * TERMS: same as Township.js.
 */

(function () {
  'use strict';

  if (typeof Township === 'undefined') {
    console.error('TownshipBoard: Township.js must be installed ABOVE this plugin.');
    return;
  }

  /* ---------------------------------------------------------- look & feel --
   * A deliberately non-RPG-Maker palette: a cold instrument panel at night,
   * with one warm accent for "now". Nothing here is a windowskin. */
  var C = {
    void: '#12151d',
    panel: '#1b2130',
    panelEdge: '#2b3448',
    rail: '#161b26',
    ink: '#ece6d8',
    dim: '#79839a',
    faint: '#39435a',
    accent: '#e8a34e',
    accentSoft: 'rgba(232,163,78,0.22)',
    sel: '#26314a'
  };

  /* MZ's default font is the loudest "this is RPG Maker" signal there is, so
   * the board uses none of it: a humanist sans for names, a monospace for every
   * number, because an instrument reads as an instrument. Stacks, not shipped
   * font files — no licence to redistribute, and these resolve on every
   * platform MZ runs on. */
  var F_LABEL = '"Trebuchet MS", "Avenir Next", "Segoe UI", Verdana, sans-serif';
  var F_NUM = 'Consolas, "SF Mono", Menlo, "DejaVu Sans Mono", monospace';

  var W = 816, HT = 624;
  var STRIP_X = 168, STRIP_W = 356, ROW_H = 44, ROW_TOP = 118;
  var DIAL_CX = 660, DIAL_CY = 214, DIAL_R = 82;
  var MAP_X = 566, MAP_Y = 336, MAP_W = 196, MAP_H = 152;
  var DAY = 1440;

  function hhmm(m) {
    m = ((m % DAY) + DAY) % DAY;
    var h = Math.floor(m / 60), mm = m % 60;
    return (h < 10 ? '0' : '') + h + ':' + (mm < 10 ? '0' : '') + mm;
  }
  function easeOutCubic(t) { var u = 1 - t; return 1 - u * u * u; }

  /**
   * Is there a LOADED map to draw?
   *
   * `$gameMap` existing is not enough: Game_Map.width() reads `$dataMap.width`,
   * so with the object present and no map data loaded it throws — and MZ's
   * SceneManager.update CATCHES that, leaving a half-created scene whose later
   * sprites are undefined. The visible symptom is then a null-property error
   * from whatever touches one first, pointing nowhere near the real cause.
   * @returns {boolean}
   */
  function mapReady() {
    return typeof $gameMap !== 'undefined' && !!$gameMap &&
           typeof $dataMap !== 'undefined' && !!$dataMap &&
           typeof $dataMap.width === 'number';
  }

  /* A vignette + scanline pass. This is the effect stock MZ cannot produce:
   * a real fragment shader over the whole board. If the GL context refuses it
   * for any reason the board simply renders without it — a missing filter must
   * never cost the buyer the scene. */
  function makeInstrumentFilter() {
    try {
      var frag =
        'varying vec2 vTextureCoord;\n' +
        'uniform sampler2D uSampler;\n' +
        'uniform float uWarm;\n' +
        'void main(void){\n' +
        '  vec4 c = texture2D(uSampler, vTextureCoord);\n' +
        '  float d = distance(vTextureCoord, vec2(0.5, 0.46));\n' +
        '  float vig = smoothstep(0.92, 0.22, d);\n' +
        '  float scan = 0.965 + 0.035 * sin(vTextureCoord.y * 640.0);\n' +
        '  c.rgb *= vig * scan;\n' +
        '  c.rgb += vec3(0.05, 0.028, 0.0) * uWarm * (1.0 - d);\n' +
        '  gl_FragColor = c;\n' +
        '}\n';
      var f = new PIXI.Filter(null, frag, { uWarm: 0.0 });
      return f;
    } catch (e) {
      console.warn('TownshipBoard: instrument filter unavailable, rendering plain — ' + e.message);
      return null;
    }
  }

  /* ------------------------------------------------------------ drawing -- */

  /** Rounded rectangle on a Bitmap's 2D context. Clamped: arcTo throws on a
   * negative radius, and MZ asks for sub-2px boxes during layout. */
  function roundRect(bmp, x, y, w, h, r, fill, stroke) {
    if (w <= 0 || h <= 0) return;
    var ctx = bmp.context;
    var rr = Math.max(0, Math.min(r, w / 2, h / 2));
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(x + rr, y);
    ctx.lineTo(x + w - rr, y);
    ctx.arcTo(x + w, y, x + w, y + rr, rr);
    ctx.lineTo(x + w, y + h - rr);
    ctx.arcTo(x + w, y + h, x + w - rr, y + h, rr);
    ctx.lineTo(x + rr, y + h);
    ctx.arcTo(x, y + h, x, y + h - rr, rr);
    ctx.lineTo(x, y + rr);
    ctx.arcTo(x, y, x + rr, y, rr);
    ctx.closePath();
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1; ctx.stroke(); }
    ctx.restore();
    bmp._baseTexture.update();
  }

  function text(bmp, s, x, y, size, color, face, align, maxW) {
    bmp.fontFace = face || F_LABEL;
    bmp.fontSize = size;
    bmp.textColor = color;
    bmp.outlineWidth = 0;
    bmp.drawText(s, x, y, maxW || 300, size + 6, align || 'left');
  }

  /* ============================================================== SCENE == */

  function Scene_TownshipBoard() { this.initialize.apply(this, arguments); }
  Scene_TownshipBoard.prototype = Object.create(Scene_Base.prototype);
  Scene_TownshipBoard.prototype.constructor = Scene_TownshipBoard;

  Scene_TownshipBoard.prototype.initialize = function () {
    Scene_Base.prototype.initialize.call(this);
    this._cursor = 0;
    this._scrub = 0;
    this._intro = 0;
    this._committed = false;
    this._flash = 0;
    this._actors = [];
  };

  Scene_TownshipBoard.prototype.create = function () {
    Scene_Base.prototype.create.call(this);
    var town = Township.town();
    this._actors = town ? town.order.slice(0) : [];
    this._scrub = Township.now().min;
    this.createBackground();
    this.createPanels();
    this.createStrips();
    this.createDial();
    this.createMapInset();
    this.createReadout();
    this.refreshStrips();
    this.refreshReadout();
  };

  Scene_TownshipBoard.prototype.createBackground = function () {
    var b = new Bitmap(W, HT);
    var ctx = b.context;
    var g = ctx.createLinearGradient(0, 0, W * 0.4, HT);
    g.addColorStop(0, '#161b26');
    g.addColorStop(0.55, C.void);
    g.addColorStop(1, '#0d1016');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, HT);
    /* a faint engineering grid — texture without noise */
    ctx.strokeStyle = 'rgba(120,150,200,0.045)';
    ctx.lineWidth = 1;
    for (var x = 0; x < W; x += 24) { ctx.beginPath(); ctx.moveTo(x + 0.5, 0); ctx.lineTo(x + 0.5, HT); ctx.stroke(); }
    for (var y = 0; y < HT; y += 24) { ctx.beginPath(); ctx.moveTo(0, y + 0.5); ctx.lineTo(W, y + 0.5); ctx.stroke(); }
    b._baseTexture.update();

    this._bg = new Sprite(b);
    this._filter = makeInstrumentFilter();
    if (this._filter) this._bg.filters = [this._filter];
    this.addChild(this._bg);
  };

  Scene_TownshipBoard.prototype.createPanels = function () {
    var b = new Bitmap(W, HT);

    /* title */
    var town = Township.town();
    text(b, (town ? town.id : 'town').toUpperCase(), 28, 30, 30, C.ink, F_LABEL, 'left', 400);
    text(b, 'ROUTINE BOARD', 28, 66, 13, C.dim, F_LABEL, 'left', 400);

    /* hairline under the title */
    var ctx = b.context;
    ctx.strokeStyle = C.panelEdge;
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(28, 96.5); ctx.lineTo(W - 28, 96.5); ctx.stroke();

    /* the strip rail behind every row */
    roundRect(b, STRIP_X - 8, ROW_TOP - 10, STRIP_W + 16, this._actors.length * ROW_H + 20, 8, C.rail, C.panelEdge);

    /* hour ticks + labels across the top of the rail */
    for (var h = 0; h <= 24; h += 3) {
      var x = STRIP_X + (h / 24) * STRIP_W;
      ctx.strokeStyle = h % 12 === 0 ? C.dim : C.faint;
      ctx.beginPath();
      ctx.moveTo(x + 0.5, ROW_TOP - 14);
      ctx.lineTo(x + 0.5, ROW_TOP + this._actors.length * ROW_H + 6);
      ctx.stroke();
      if (h < 24) text(b, (h < 10 ? '0' : '') + h, x - 8, ROW_TOP - 34, 11, C.dim, F_NUM, 'left', 30);
    }
    text(b, '24', STRIP_X + STRIP_W - 12, ROW_TOP - 34, 11, C.dim, F_NUM, 'left', 30);

    /* right-hand panels: the dial gets a panel to itself */
    roundRect(b, MAP_X - 12, 112, 236, 196, 10, C.panel, C.panelEdge);
    text(b, 'THE DAY', MAP_X, 120, 11, C.dim, F_LABEL, 'left', 200);
    roundRect(b, MAP_X - 12, MAP_Y - 16, 236, MAP_H + 52, 10, C.panel, C.panelEdge);
    text(b, 'THE TOWN, NOW', MAP_X, MAP_Y - 6, 11, C.dim, F_LABEL, 'left', 200);

    /* a rail behind the selected-actor detail, under the strips */
    roundRect(b, 20, ROW_TOP + this._actors.length * ROW_H + 16, 536, 60, 8, C.rail, C.panelEdge);

    /* footer key */
    var keys = '← →  SCRUB      ↑ ↓  WHO      OK  SET CLOCK      SHIFT+OK  GO TO      ESC  CLOSE';
    text(b, keys, 28, HT - 40, 12, C.dim, F_LABEL, 'left', W - 56);

    b._baseTexture.update();
    this._panels = new Sprite(b);
    this.addChild(this._panels);

    /* legend of activity colours, drawn from the real configured palette */
    var lb = new Bitmap(W, 30);
    var lx = 28;
    for (var i = 0; i < Township.KNOWN_TAGS.length; i++) {
      var tag = Township.KNOWN_TAGS[i];
      var col = Township.CFG.tagColors[tag] || '#888888';
      lb.fillRect(lx, 10, 14, 10, col);
      text(lb, tag.toUpperCase(), lx + 20, 4, 11, C.dim, F_LABEL, 'left', 70);
      lx += 20 + 8 + tag.length * 7 + 14;
    }
    lb._baseTexture.update();
    this._legend = new Sprite(lb);
    this._legend.y = HT - 78;
    this.addChild(this._legend);
  };

  /* ------------------------------------------------------------- strips -- */

  Scene_TownshipBoard.prototype.createStrips = function () {
    /* Selection highlight: one sprite MOVED by y, never redrawn. */
    var sel = new Bitmap(STRIP_W + 150, ROW_H);
    roundRect(sel, 0, 2, STRIP_W + 150, ROW_H - 4, 6, C.sel, null);
    this._selBar = new Sprite(sel);
    this._selBar.x = 20;
    this.addChild(this._selBar);

    this._stripSprite = new Sprite(new Bitmap(W, this._actors.length * ROW_H + 8));
    this._stripSprite.y = ROW_TOP;
    this.addChild(this._stripSprite);

    /* The playhead is a 2px sprite moved by x. Per-frame it costs one property
     * write and nothing else — no bitmap is touched while time moves. */
    var ph = new Bitmap(3, this._actors.length * ROW_H + 26);
    ph.fillRect(0, 0, 3, ph.height, C.accent);
    ph._baseTexture.update();
    this._playhead = new Sprite(ph);
    this._playhead.y = ROW_TOP - 12;
    this.addChild(this._playhead);
  };

  /**
   * Bake every strip once. Called only when the day type, a variant or the
   * roster changes — never per frame.
   */
  Scene_TownshipBoard.prototype.refreshStrips = function () {
    var town = Township.town();
    if (!town) return;
    var bmp = this._stripSprite.bitmap;
    bmp.clear();
    var ctx = bmp.context;
    var ctxLocal = Township.context();

    for (var i = 0; i < this._actors.length; i++) {
      var id = this._actors[i];
      var actor = town.actors[id];
      var y = i * ROW_H;

      text(bmp, actor.name, 28, y + 8, 16, C.ink, F_LABEL, 'left', 120);
      var sch = Township.selectSchedule(town, id, ctxLocal);
      text(bmp, sch && sch.id !== 'base' ? sch.id.toUpperCase() : '', 28, y + 26, 10, C.accent, F_LABEL, 'left', 120);

      var segs = Township.dayStrip(town, id, ctxLocal);
      for (var s = 0; s < segs.length; s++) {
        var sg = segs[s];
        var x0 = STRIP_X + (sg.from / DAY) * STRIP_W;
        var x1 = STRIP_X + (sg.to / DAY) * STRIP_W;
        var col = Township.CFG.tagColors[sg.tag] || '#888888';
        ctx.fillStyle = col;
        ctx.fillRect(x0, y + 12, Math.max(1, x1 - x0), 20);

        /* A wrapping span is ONE activity drawn in two pieces. Chevrons at the
         * cut edges say so — this is the band a span-based plugin cannot even
         * represent, so it is worth pointing at. */
        if (sg.wrap) {
          ctx.fillStyle = 'rgba(255,255,255,0.85)';
          if (sg.to === DAY) {
            ctx.beginPath();
            ctx.moveTo(x1 - 7, y + 16); ctx.lineTo(x1 - 1, y + 22); ctx.lineTo(x1 - 7, y + 28);
            ctx.closePath(); ctx.fill();
          }
          if (sg.from === 0) {
            ctx.beginPath();
            ctx.moveTo(x0 + 7, y + 16); ctx.lineTo(x0 + 1, y + 22); ctx.lineTo(x0 + 7, y + 28);
            ctx.closePath(); ctx.fill();
          }
        }
      }

      /* hairline under each row */
      ctx.strokeStyle = C.faint;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(STRIP_X, y + ROW_H - 3.5);
      ctx.lineTo(STRIP_X + STRIP_W, y + ROW_H - 3.5);
      ctx.stroke();
    }
    bmp._baseTexture.update();
  };

  /* --------------------------------------------------------------- dial -- */

  Scene_TownshipBoard.prototype.createDial = function () {
    var b = new Bitmap(DIAL_R * 2 + 24, DIAL_R * 2 + 24);
    var cx = b.width / 2, cy = b.height / 2;
    var ctx = b.context;

    ctx.strokeStyle = C.panelEdge;
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(cx, cy, DIAL_R, 0, Math.PI * 2); ctx.stroke();
    ctx.strokeStyle = C.faint;
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(cx, cy, DIAL_R - 14, 0, Math.PI * 2); ctx.stroke();

    for (var h = 0; h < 24; h++) {
      var a = (h / 24) * Math.PI * 2 - Math.PI / 2;
      var major = h % 6 === 0;
      var r0 = DIAL_R - (major ? 16 : 8), r1 = DIAL_R - 1;
      ctx.strokeStyle = major ? C.ink : C.faint;
      ctx.lineWidth = major ? 2 : 1;
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0);
      ctx.lineTo(cx + Math.cos(a) * r1, cy + Math.sin(a) * r1);
      ctx.stroke();
    }
    /* Hour labels on their own inner radius. Placed at the rim first, where
     * they collided with the major ticks and rendered as illegible smudges —
     * caught by looking at the render. */
    var LAB_R = DIAL_R - 30;
    var LABELS = [0, 6, 12, 18];
    for (var li = 0; li < LABELS.length; li++) {
      var lh = LABELS[li];
      var la = (lh / 24) * Math.PI * 2 - Math.PI / 2;
      var lx = cx + Math.cos(la) * LAB_R;
      var ly = cy + Math.sin(la) * LAB_R;
      b.fontFace = F_NUM;
      b.fontSize = 12;
      b.textColor = C.dim;
      b.outlineWidth = 0;
      b.drawText((lh < 10 ? '0' : '') + lh, lx - 16, ly - 9, 32, 18, 'center');
    }
    b._baseTexture.update();

    this._dial = new Sprite(b);
    this._dial.x = DIAL_CX - b.width / 2;
    this._dial.y = DIAL_CY - b.height / 2;
    this.addChild(this._dial);

    /* The hand is a sprite ROTATED by property — the bitmap never changes. */
    var hb = new Bitmap(6, DIAL_R);
    hb.fillRect(1, 6, 4, DIAL_R - 6, C.accent);
    hb.fillRect(2, 0, 2, 8, C.ink);
    hb._baseTexture.update();
    this._hand = new Sprite(hb);
    this._hand.anchor.x = 0.5;
    this._hand.anchor.y = 1.0;
    this._hand.x = DIAL_CX;
    this._hand.y = DIAL_CY;
    this.addChild(this._hand);

    var gb = new Bitmap(16, 16);
    gb.context.fillStyle = C.accent;
    gb.context.beginPath(); gb.context.arc(8, 8, 5, 0, Math.PI * 2); gb.context.fill();
    gb._baseTexture.update();
    this._hub = new Sprite(gb);
    this._hub.anchor.x = 0.5; this._hub.anchor.y = 0.5;
    this._hub.x = DIAL_CX; this._hub.y = DIAL_CY;
    this.addChild(this._hub);
  };

  /* ---------------------------------------------------------- map inset -- */

  Scene_TownshipBoard.prototype.createMapInset = function () {
    var ready = mapReady();
    var mw = ready ? $gameMap.width() : 17;
    var mh = ready ? $gameMap.height() : 13;
    this._tile = Math.max(4, Math.min(Math.floor(MAP_W / mw), Math.floor(MAP_H / mh)));
    this._insetW = this._tile * mw;
    this._insetH = this._tile * mh;
    this._insetX = MAP_X + Math.floor((MAP_W - this._insetW) / 2);
    this._insetY = MAP_Y + 12;

    var b = new Bitmap(this._insetW + 2, this._insetH + 2);
    b.fillRect(0, 0, b.width, b.height, '#10141d');
    var ctx = b.context;
    ctx.strokeStyle = 'rgba(120,150,200,0.10)';
    for (var x = 0; x <= mw; x++) {
      ctx.beginPath(); ctx.moveTo(x * this._tile + 0.5, 0); ctx.lineTo(x * this._tile + 0.5, this._insetH); ctx.stroke();
    }
    for (var y = 0; y <= mh; y++) {
      ctx.beginPath(); ctx.moveTo(0, y * this._tile + 0.5); ctx.lineTo(this._insetW, y * this._tile + 0.5); ctx.stroke();
    }

    /* every declared place on this map, as a faint marker */
    var town = Township.town();
    if (town) {
      for (var k in town.places) {
        var p = town.places[k];
        if (ready && p.mapId !== $gameMap.mapId()) continue;
        ctx.strokeStyle = 'rgba(232,163,78,0.35)';
        ctx.strokeRect(p.x * this._tile + 1.5, p.y * this._tile + 1.5, this._tile - 3, this._tile - 3);
      }
    }
    b._baseTexture.update();
    this._inset = new Sprite(b);
    this._inset.x = this._insetX;
    this._inset.y = this._insetY;
    this.addChild(this._inset);

    /* One dot sprite per actor, MOVED by x/y. Allocated here, once. */
    this._dots = [];
    for (var i = 0; i < this._actors.length; i++) {
      var d = new Bitmap(this._tile + 2, this._tile + 2);
      var dc = d.context;
      dc.fillStyle = C.ink;
      dc.beginPath();
      dc.arc((this._tile + 2) / 2, (this._tile + 2) / 2, Math.max(2, this._tile / 2 - 1), 0, Math.PI * 2);
      dc.fill();
      d._baseTexture.update();
      var sp = new Sprite(d);
      sp.anchor.x = 0.5; sp.anchor.y = 0.5;
      this.addChild(sp);
      this._dots.push(sp);
    }
  };

  /* ----------------------------------------------------------- readout -- */

  /* The clock lives in the header and the selected-actor detail sits directly
   * under the strips it describes. They were originally one sprite over the
   * dial, which printed both on top of each other and made the dial
   * unreadable — caught by LOOKING at the render, not by any check. */
  Scene_TownshipBoard.prototype.createReadout = function () {
    this._clock = new Sprite(new Bitmap(280, 80));
    this._clock.x = W - 28 - 280;
    this._clock.y = 14;
    this.addChild(this._clock);

    this._detail = new Sprite(new Bitmap(520, 52));
    this._detail.x = 28;
    this._detail.y = ROW_TOP + this._actors.length * ROW_H + 22;
    this.addChild(this._detail);

    this._lastDrawn = -1;
  };

  /** Redrawn only when the scrubbed minute or selection changes — not per frame. */
  Scene_TownshipBoard.prototype.refreshReadout = function () {
    var s = Township.state();
    var same = Township.now().min === this._scrub;

    var cb = this._clock.bitmap;
    cb.clear();
    cb.fontFace = F_NUM;
    cb.fontSize = 48;
    cb.textColor = C.ink;
    cb.drawText(hhmm(this._scrub), 0, 0, 280, 54, 'right');
    text(cb, (same ? 'LIVE' : 'PREVIEW') + '   DAY ' + (s ? s.clock.day : 0) +
      '   ' + String(s ? s.calendar.dayType : 'normal').toUpperCase(),
      0, 56, 12, same ? C.dim : C.accent, F_LABEL, 'right', 280);
    cb._baseTexture.update();

    var b = this._detail.bitmap;
    b.clear();
    var town = Township.town();
    var id = this._actors[this._cursor];
    if (town && id) {
      var act = Township.resolve(town, id, this._scrub, Township.context());
      if (act) {
        var col = Township.CFG.tagColors[act.tag] || '#888888';
        b.fillRect(0, 6, 5, 40, col);
        text(b, town.actors[id].name.toUpperCase(), 14, 2, 15, C.accent, F_LABEL, 'left', 200);
        text(b, act.tag.toUpperCase() + '  ·  ' + act.place.name, 14, 24, 13, C.ink, F_LABEL, 'left', 300);
        var hrs = Math.floor(act.spanMin / 60), mins = act.spanMin % 60;
        text(b, hhmm(act.sinceMin) + ' → ' + hhmm(act.untilMin) +
          '   (' + hrs + 'h' + (mins ? mins + 'm' : '') + ')' +
          (act.untilMin <= act.sinceMin ? '   OVERNIGHT' : ''),
          250, 24, 13, act.untilMin <= act.sinceMin ? C.accent : C.dim, F_NUM, 'left', 270);
      }
    }
    b._baseTexture.update();
    this._lastDrawn = this._scrub;
  };

  /* ------------------------------------------------------------ update -- */

  Scene_TownshipBoard.prototype.update = function () {
    Scene_Base.prototype.update.call(this);
    this.updateIntro();
    this.updateInput();
    this.updateMotion();
  };

  /** Opening motion: rows ease in. Property writes only, no redraw. */
  Scene_TownshipBoard.prototype.updateIntro = function () {
    if (this._intro >= 1) return;
    this._intro = Math.min(1, this._intro + 0.055);
    var e = easeOutCubic(this._intro);
    this._stripSprite.x = (1 - e) * -40;
    this._stripSprite.opacity = Math.round(255 * e);
    this._playhead.opacity = Math.round(255 * e);
    this._dial.opacity = Math.round(255 * e);
    this._hand.opacity = Math.round(255 * e);
    this._hub.opacity = Math.round(255 * e);
    this._inset.opacity = Math.round(255 * e);
    this._clock.opacity = Math.round(255 * e);
    this._detail.opacity = Math.round(255 * e);
    this._legend.opacity = Math.round(255 * e);
  };

  Scene_TownshipBoard.prototype.updateInput = function () {
    var shift = Input.isPressed('shift');

    if (Input.isRepeated('right')) { this.scrubBy(shift ? 60 : 10); }
    if (Input.isRepeated('left')) { this.scrubBy(shift ? -60 : -10); }

    if (Input.isRepeated('down')) {
      this._cursor = (this._cursor + 1) % Math.max(1, this._actors.length);
      SoundManager.playCursor();
      this.refreshReadout();
    }
    if (Input.isRepeated('up')) {
      this._cursor = (this._cursor + this._actors.length - 1) % Math.max(1, this._actors.length);
      SoundManager.playCursor();
      this.refreshReadout();
    }

    if (Input.isTriggered('pagedown') || Input.isTriggered('pageup')) {
      this.cycleDayType(Input.isTriggered('pagedown') ? 1 : -1);
    }

    if (Input.isTriggered('ok')) {
      if (shift) this.gotoSelected(); else this.commitTime();
    }

    if (Input.isTriggered('cancel') || TouchInput.isCancelled()) {
      SoundManager.playCancel();
      this.popScene();
    }
  };

  Scene_TownshipBoard.prototype.scrubBy = function (delta) {
    this._scrub = Township.normalizeMinute(this._scrub + delta);
    SoundManager.playCursor();
    this.refreshReadout();
  };

  /** ACT: send the world to the previewed time. This is why it is a console. */
  Scene_TownshipBoard.prototype.commitTime = function () {
    var s = Township.state();
    if (!s) return;
    s.clock.min = this._scrub;
    Township.RT.lastMinute = -1;
    Township.RT.frameAcc = 0;
    Township.placeAllInstantly();
    SoundManager.playOk();
    this._flash = 1;
    this.refreshReadout();
  };

  /** ACT: put the player beside the selected townsperson. */
  Scene_TownshipBoard.prototype.gotoSelected = function () {
    var id = this._actors[this._cursor];
    var place = id && Township.currentPlace(id);
    if (!place || !mapReady() || place.mapId !== $gameMap.mapId()) {
      SoundManager.playBuzzer();
      return;
    }
    var tx = place.x, ty = place.y + 1;
    if (!$gameMap.isValid(tx, ty)) ty = place.y;
    $gamePlayer.reserveTransfer($gameMap.mapId(), tx, ty, 8, 0);
    SoundManager.playOk();
    this.popScene();
  };

  Scene_TownshipBoard.prototype.cycleDayType = function (dir) {
    var s = Township.state();
    if (!s) return;
    var types = ['normal', 'market', 'festival'];
    var i = types.indexOf(s.calendar.dayType);
    if (i < 0) i = 0;
    s.calendar.dayType = types[(i + dir + types.length) % types.length];
    Township.RT.lastMinute = -1;
    SoundManager.playCursor();
    this.refreshStrips();
    this.refreshReadout();
  };

  /**
   * The per-frame hot path for this scene. Property writes only: no bitmap is
   * touched, no object or array is created, no closure is made. That is what
   * keeps the board free of texture uploads while the clock sweeps.
   */
  Scene_TownshipBoard.prototype.updateMotion = function () {
    /* playhead + dial follow the scrub */
    this._playhead.x = STRIP_X + (this._scrub / DAY) * STRIP_W - 1;
    this._hand.rotation = (this._scrub / DAY) * Math.PI * 2;

    /* selection bar eases toward its row */
    var targetY = ROW_TOP + this._cursor * ROW_H;
    this._selBar.y += (targetY - this._selBar.y) * 0.28;

    /* live dots on the map inset */
    var town = Township.town();
    if (town) {
      for (var i = 0; i < this._actors.length; i++) {
        var sp = this._dots[i];
        var act = Township.resolve(town, this._actors[i], this._scrub, Township.context());
        if (!act || !mapReady() || act.place.mapId !== $gameMap.mapId()) {
          sp.opacity = 0;
          continue;
        }
        sp.opacity = (i === this._cursor) ? 255 : 130;
        sp.scale.x = (i === this._cursor) ? 1.4 : 1.0;
        sp.scale.y = sp.scale.x;
        sp.x = this._insetX + act.place.x * this._tile + this._tile / 2;
        sp.y = this._insetY + act.place.y * this._tile + this._tile / 2;
      }
    }

    /* commit flash, and the warm pulse in the shader */
    if (this._flash > 0) this._flash = Math.max(0, this._flash - 0.04);
    if (this._filter) this._filter.uniforms.uWarm = this._flash;
    this._hub.scale.x = 1 + this._flash * 0.6;
    this._hub.scale.y = this._hub.scale.x;

    if (this._lastDrawn !== this._scrub) this.refreshReadout();
  };

  window.Scene_TownshipBoard = Scene_TownshipBoard;

})();
