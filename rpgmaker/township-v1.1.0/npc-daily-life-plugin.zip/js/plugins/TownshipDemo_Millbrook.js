//=============================================================================
// TownshipDemo_Millbrook.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.1.0] Millbrook — a complete worked example town for Township. Eight townspeople, a market day, and a night watch. Copy this file and edit it to build your own.
 * @author CSAF — Core Systems Asset Factory
 * @url https://csaf.itch.io/township
 * @base Township
 * @orderAfter Township
 *
 * @help
 * ============================================================================
 * Millbrook — read this file, then copy it
 * ============================================================================
 *
 * This is the town definition for the demo. It is deliberately plain data: a
 * list of places, a list of doors, and a list of townspeople whose schedules
 * are lists of "at this time, be here".
 *
 * THE SHAPE OF A SCHEDULE
 *
 *   { at: 22 * 60, place: 'gate', tag: 'work' }
 *
 * `at` is minutes since midnight. There is NO end time — the entry runs until
 * the next one, wrapping around midnight automatically. That is why Bram the
 * watchman can start at 22:00 and finish at 07:00 without disappearing, which
 * is the single most common failure in schedule plugins.
 *
 * SCHEDULE VARIANTS
 *
 * An actor may have several schedules. The one with no conditions is the base
 * and is always the fallback. Others activate on:
 *   dayType: 'market'          - set with the SetDayType plugin command
 *   days: [0, 3]               - weekdays, counted by the "Days in a week" param
 *   when: { switch: 12 }       - a game switch
 *   when: { variable: 4, op: '>=', value: 10 }
 *   priority: 5                - highest matching priority wins
 *
 * POSES
 *
 * A pose is what an NPC does once they ARRIVE somewhere. This is what makes a
 * town look alive rather than look like people standing on marked tiles.
 *   pose: { dir: 8, stepAnim: true }
 *   pose: { sprite: { name: 'People2', index: 3 }, dir: 2 }
 *
 * TERMS: same as Township.js. Free for commercial and non-commercial use.
 */

(function () {
  'use strict';

  if (typeof Township === 'undefined') {
    console.error('TownshipDemo_Millbrook: Township.js must be installed ABOVE this plugin.');
    return;
  }

  var H = function (h, m) { return h * 60 + (m || 0); };

  Township.defineTown({
    id: 'millbrook',

    /* ------------------------------------------------------------ places --
     * Coordinates here are the fallback. Drop an event on the map with
     * <township_place:oven> in its note box and Township will use the event's
     * position instead, so you can lay a town out visually in the editor.
     */
    places: [
      { id: 'oven', name: 'The bakery oven', mapId: 1, x: 3, y: 3, facing: 8 },
      { id: 'bakery_home', name: 'Odile\'s rooms', mapId: 1, x: 2, y: 5, facing: 2 },
      { id: 'square', name: 'Market square', mapId: 1, x: 8, y: 6, facing: 2 },
      { id: 'well', name: 'The well', mapId: 1, x: 9, y: 8, facing: 4 },
      { id: 'tavern', name: 'The Ferryman', mapId: 1, x: 13, y: 5, facing: 2 },
      { id: 'forge', name: 'The forge', mapId: 1, x: 4, y: 9, facing: 8 },
      { id: 'smith_home', name: 'Doran\'s house', mapId: 1, x: 2, y: 10, facing: 2 },
      { id: 'gate', name: 'The east gate', mapId: 1, x: 15, y: 9, facing: 6 },
      { id: 'watch_hut', name: 'The watch hut', mapId: 1, x: 14, y: 11, facing: 2 },
      { id: 'chapel', name: 'The chapel', mapId: 1, x: 7, y: 2, facing: 8 },
      { id: 'field', name: 'The long field', mapId: 1, x: 11, y: 10, facing: 2 },
      { id: 'mill', name: 'The mill', mapId: 1, x: 12, y: 2, facing: 8 },
      { id: 'dock', name: 'The river dock', mapId: 1, x: 1, y: 7, facing: 4 },
      { id: 'inn_room', name: 'Inn back room', mapId: 1, x: 14, y: 3, facing: 2 }
    ],

    /* Doors are where NPCs fade in and out when they enter or leave the map. */
    doors: [
      { id: 'north_road', mapId: 1, x: 8, y: 1 },
      { id: 'south_road', mapId: 1, x: 8, y: 11 }
    ],

    /* ------------------------------------------------------------ actors -- */
    actors: [
      {
        id: 'baker', name: 'Odile', home: 'bakery_home',
        sprite: { name: 'People1', index: 1 }, speed: 3,
        schedules: [
          {
            id: 'base',
            entries: [
              { at: H(5, 0), place: 'oven', tag: 'work', pose: { dir: 8, stepAnim: true } },
              { at: H(12, 0), place: 'square', tag: 'errand' },
              { at: H(14, 0), place: 'oven', tag: 'work', pose: { dir: 8, stepAnim: true } },
              { at: H(19, 0), place: 'tavern', tag: 'social' },
              { at: H(22, 30), place: 'bakery_home', tag: 'sleep', pose: { dir: 2 } }
            ]
          },
          {
            id: 'market', dayType: 'market',
            entries: [
              { at: H(4, 0), place: 'oven', tag: 'work', pose: { dir: 8, stepAnim: true } },
              { at: H(8, 0), place: 'square', tag: 'work', pose: { dir: 2, stepAnim: true } },
              { at: H(18, 0), place: 'tavern', tag: 'social' },
              { at: H(21, 30), place: 'bakery_home', tag: 'sleep' }
            ]
          }
        ]
      },

      /* The headline case: a shift that starts at 22:00 and ends at 07:00.
       * A span-based plugin resolves NOTHING for the nine hours across
       * midnight, which is why its NPCs vanish. Here it is just two entries. */
      {
        id: 'watchman', name: 'Bram', home: 'watch_hut',
        sprite: { name: 'People2', index: 6 }, speed: 3,
        schedules: [{
          id: 'base',
          entries: [
            { at: H(22, 0), place: 'gate', tag: 'work', pose: { dir: 6, stepAnim: true } },
            { at: H(7, 0), place: 'watch_hut', tag: 'sleep', pose: { dir: 2 } }
          ]
        }]
      },

      {
        id: 'smith', name: 'Doran', home: 'smith_home',
        sprite: { name: 'People1', index: 4 }, speed: 3,
        schedules: [
          {
            id: 'base',
            entries: [
              { at: H(7, 0), place: 'forge', tag: 'work', pose: { dir: 8, stepAnim: true } },
              { at: H(12, 30), place: 'square', tag: 'errand' },
              { at: H(13, 30), place: 'forge', tag: 'work', pose: { dir: 8, stepAnim: true } },
              { at: H(19, 30), place: 'tavern', tag: 'social' },
              { at: H(23, 0), place: 'smith_home', tag: 'sleep', pose: { dir: 2 } }
            ]
          },
          {
            /* An injury switch takes him off the forge entirely. Priority 5 so
             * it beats the market-day variant when both apply. */
            id: 'injured', priority: 5, when: { switch: 21 },
            entries: [{ at: H(9, 0), place: 'smith_home', tag: 'home', pose: { dir: 2 } }]
          },
          {
            id: 'market', priority: 1, dayType: 'market',
            entries: [
              { at: H(7, 0), place: 'forge', tag: 'work', pose: { dir: 8, stepAnim: true } },
              { at: H(10, 0), place: 'square', tag: 'work', pose: { dir: 2 } },
              { at: H(19, 0), place: 'tavern', tag: 'social' },
              { at: H(23, 0), place: 'smith_home', tag: 'sleep' }
            ]
          }
        ]
      },

      {
        id: 'farmer', name: 'Hesta', home: 'smith_home',
        sprite: { name: 'People3', index: 2 }, speed: 3,
        schedules: [
          {
            id: 'base',
            entries: [
              { at: H(6, 0), place: 'field', tag: 'work', pose: { dir: 2, stepAnim: true } },
              { at: H(11, 0), place: 'well', tag: 'errand' },
              { at: H(12, 0), place: 'field', tag: 'work', pose: { dir: 2, stepAnim: true } },
              { at: H(20, 0), place: 'tavern', tag: 'social' },
              { at: H(23, 30), place: 'smith_home', tag: 'sleep' }
            ]
          },
          {
            id: 'market', dayType: 'market',
            entries: [
              { at: H(5, 30), place: 'field', tag: 'work' },
              { at: H(8, 30), place: 'square', tag: 'work', pose: { dir: 4 } },
              { at: H(19, 0), place: 'tavern', tag: 'social' },
              { at: H(23, 0), place: 'smith_home', tag: 'sleep' }
            ]
          }
        ]
      },

      {
        id: 'priest', name: 'Ives', home: 'chapel',
        sprite: { name: 'People4', index: 0 }, speed: 2,
        schedules: [
          {
            id: 'base',
            entries: [
              { at: H(6, 30), place: 'chapel', tag: 'work', pose: { dir: 8 } },
              { at: H(10, 0), place: 'square', tag: 'social' },
              { at: H(11, 30), place: 'chapel', tag: 'work', pose: { dir: 8 } },
              { at: H(21, 0), place: 'chapel', tag: 'sleep', pose: { dir: 2 } }
            ]
          },
          {
            /* Rest day: the whole town gathers, so he is in the square all day. */
            id: 'restday', days: [0],
            entries: [
              { at: H(7, 0), place: 'chapel', tag: 'work', pose: { dir: 8 } },
              { at: H(9, 0), place: 'square', tag: 'social', pose: { dir: 2 } },
              { at: H(20, 0), place: 'chapel', tag: 'sleep' }
            ]
          }
        ]
      },

      {
        id: 'miller', name: 'Cass', home: 'mill',
        sprite: { name: 'People2', index: 2 }, speed: 3,
        schedules: [{
          id: 'base',
          entries: [
            { at: H(5, 30), place: 'mill', tag: 'work', pose: { dir: 8, stepAnim: true } },
            { at: H(9, 0), place: 'dock', tag: 'errand', pose: { dir: 4 } },
            { at: H(10, 30), place: 'mill', tag: 'work', pose: { dir: 8, stepAnim: true } },
            { at: H(19, 0), place: 'tavern', tag: 'social' },
            { at: H(23, 0), place: 'mill', tag: 'sleep' }
          ]
        }]
      },

      /* A second overnight case, deliberately different in shape: the innkeeper
       * closes up at 02:00 and opens at 09:00, so her sleep is the wrapping
       * entry rather than her work. */
      {
        id: 'innkeeper', name: 'Perr', home: 'inn_room',
        sprite: { name: 'People1', index: 6 }, speed: 3,
        schedules: [{
          id: 'base',
          entries: [
            { at: H(9, 0), place: 'tavern', tag: 'work', pose: { dir: 2, stepAnim: true } },
            { at: H(2, 0), place: 'inn_room', tag: 'sleep', pose: { dir: 2 } }
          ]
        }]
      },

      {
        id: 'child', name: 'Wynn', home: 'bakery_home',
        sprite: { name: 'People4', index: 5 }, speed: 4,
        schedules: [{
          id: 'base',
          entries: [
            { at: H(8, 0), place: 'square', tag: 'social', pose: { dir: 2, stepAnim: true } },
            { at: H(10, 0), place: 'well', tag: 'errand' },
            { at: H(11, 0), place: 'square', tag: 'social', pose: { dir: 2, stepAnim: true } },
            { at: H(16, 0), place: 'dock', tag: 'social' },
            { at: H(19, 30), place: 'bakery_home', tag: 'sleep', pose: { dir: 2 } }
          ]
        }]
      }
    ]
  });

})();
