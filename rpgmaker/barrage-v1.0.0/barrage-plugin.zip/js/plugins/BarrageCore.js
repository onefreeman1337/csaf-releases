//=============================================================================
// BarrageCore.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Barrage rules: reads an enemy and its skill, and composes the attack the player must dodge. Load FIRST.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The rules only: no drawing, no scene, no engine code. Barrage.js (the battle
 * phase) and BarrageDraw.js (the drawn projectiles and arena) read it.
 *
 * WHAT IT DECIDES, from data you already have:
 *   form    what flies: the skill's element by NAME (Fire -> embers, Ice ->
 *           shards...), else the enemy's own name (a Crow throws feathers),
 *           else its strongest parameter against your database's median.
 *   family  how it flies: rain, sweep, wall, spiral, ring, bounce or aimed.
 *           The skill's hit type and scope pick three; enemies take those
 *           three in turn by database id, so neighbouring enemies never
 *           attack alike with the same kind of skill.
 *   tier    0..4 density and speed, from the attacker's stats against the
 *           MEDIAN of your own Enemies database.
 *   boss    an enemy with 3x the median max HP (or a notetag) attacks in
 *           phases of different families.
 *
 * Every attack it composes is proved survivable by a solver in its tests: a
 * path that is never hit exists through every family at every tier.
 *
 * Everything is seeded; there is no Math.random anywhere.
 */

var CSAF = CSAF || {};

(function () {
  'use strict';

  var VERSION = '1.0.0';

  /** The arena, in its own pixels. Barrage.js scales it into the battle screen. */
  var ARENA = { w: 384, h: 216 };
  /** The soul: hit radius and top speed in arena pixels per frame. */
  var SOUL = { r: 6, speed: 3 };
  /** Most shots one attack may have scheduled; the runtime pool is this size. */
  var POOL = 192;
  /** No shot moves further than this in one frame (a test holds every family to it). */
  var MAX_STEP = 8;
  /** Frames before the first shot of a phase, so a player can find the soul. */
  var LEAD = 24;
  var PHASE_FRAMES = 210;
  var BOSS_PHASE_FRAMES = 180;
  /** Invulnerable frames after a hit (runtime and bot agree). */
  var IFRAMES = 45;

  var FAMILIES = ['rain', 'sweep', 'wall', 'spiral', 'ring', 'bounce', 'aimed'];

  /** Drawn radius of each form; the hit radius is 80% of it, Undertale-fair. */
  var FORM_R = {
    ember: 5, shard: 5, spark: 4, droplet: 5, pebble: 6, leaf: 5, mote: 4, wisp: 6, blade: 5,
    bone: 6, feather: 5, needle: 4, stone: 7, orb: 6, coin: 5, thorn: 5, fang: 5, note: 5
  };
  var FORMS = Object.keys(FORM_R);
  var MAX_R = 7;

  /** Element NAME keywords -> form. Read against the buyer's own System elements, never ids. */
  var ELEMENT_WORDS = [
    [/fire|flame|burn|heat|blaze|inferno|lava/, 'ember'],
    [/ice|frost|cold|snow|freez|blizzard/, 'shard'],
    [/thunder|lightning|electr|bolt|storm|spark|shock/, 'spark'],
    [/water|aqua|sea|rain|tide|wave|poison|venom|acid/, 'droplet'],
    [/earth|stone|rock|ground|sand|quake/, 'pebble'],
    [/wind|air|gale|sky|tornado/, 'leaf'],
    [/light|holy|sun|radian|divine|star/, 'mote'],
    [/dark|shadow|void|curse|evil|death|abyss/, 'wisp'],
    [/sound|song|music|sonic/, 'note']
  ];

  /** An enemy's NAME, read for what it would throw. Ordered: first match wins. */
  var NAME_WORDS = [
    [/crow|raven|bird|harpy|hawk|owl|griffin|gryphon|eagle|phoenix/, 'feather'],
    [/treant|tree|plant|vine|root|dryad|mandrak|rose|cactus|thorn/, 'thorn'],
    [/skeleton|bone|undead|zombie|ghoul|lich|skull/, 'bone'],
    [/wolf|dog|hound|beast|cat|tiger|lion|bear|snake|serpent|rat|bat|fang/, 'fang'],
    [/slime|jelly|ooze|blob|frog|fish/, 'droplet'],
    [/golem|gnome|rock|stone|gargoyle|statue|dwarf/, 'stone'],
    [/ghost|spirit|phantom|wraith|specter|spectre|shade/, 'wisp'],
    [/bee|wasp|spider|scorpion|insect|hornet|mantis|needle/, 'needle'],
    [/mage|witch|wizard|sorcer|priest|imp|demon|cultist|sage/, 'orb'],
    [/dragon|drake|wyrm|wyvern|salamander/, 'ember'],
    [/mimic|chest|merchant|gold|coin|thief|bandit/, 'coin'],
    [/fairy|pixie|angel|sprite|wisp/, 'mote'],
    [/bard|siren|harp|song/, 'note'],
    [/goblin|orc|knight|soldier|samurai|warrior|guard|mercenar|blade|sword/, 'blade']
  ];

  /** Strongest parameter (index into params) -> form, when nothing else names one. */
  var PARAM_FORM = { 2: 'blade', 3: 'stone', 4: 'orb', 6: 'needle', 7: 'coin' };

  /**
   * How a lexicon row matches a name: a word of FOUR letters or more anywhere (a Werewolf is a wolf, an Archmage a
   * mage), a word of three or fewer only standing alone, plural allowed (a Rat, Bats, a Giant Rat - but not a
   * Pirate, a Combat Drone or an Imperial Guard, which plain substrings turned into fangs and orbs, 2026-10-07).
   */
  function lexRe(re) {
    var parts = re.source.split('|'), long = [], short = [], src = [];
    for (var i = 0; i < parts.length; i++) (parts[i].length <= 3 ? short : long).push(parts[i]);
    if (long.length) src.push('(?:' + long.join('|') + ')');
    if (short.length) src.push('(?:^|[^a-z])(?:' + short.join('|') + ')s?(?:$|[^a-z])');
    return new RegExp(src.join('|'));
  }
  var ELEMENT_RE = ELEMENT_WORDS.map(function (r) { return [lexRe(r[0]), r[1]]; });
  var NAME_RE = NAME_WORDS.map(function (r) { return [lexRe(r[0]), r[1]]; });

  /**
   * Family cells: [hitType][multi target ? 1 : 0] -> three families. Enemies take them IN TURN by database id, so
   * neighbouring enemies never share one for the same kind of skill. A hashed pick per enemy (the first version)
   * gave three of the five stock enemies the same wall for their plain Attack (LOOKED 2026-10-07): a coin toss per
   * enemy is a run waiting to happen (wing §21g); an enumeration cannot collapse.
   */
  var CELLS = {
    0: [['bounce', 'aimed', 'ring'], ['bounce', 'rain', 'wall']],
    1: [['sweep', 'wall', 'aimed'], ['rain', 'wall', 'sweep']],
    2: [['spiral', 'ring', 'bounce'], ['ring', 'rain', 'spiral']]
  };
  /** Boss phases continue in this order from the base family. */
  var BOSS_ORDER = ['sweep', 'ring', 'rain', 'spiral', 'wall', 'bounce'];

  //---------------------------------------------------------------------------
  // Seeds
  //---------------------------------------------------------------------------

  /** FNV-1a for string seeds; numbers are used as they are. @param {*} s @returns {number} uint32 */
  function seedOf(s) {
    var n = Number(s);
    if (s !== '' && s !== null && s !== undefined && isFinite(n)) return (Math.floor(Math.abs(n)) >>> 0) || 1;
    var h = 2166136261, str = String(s);
    for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    return h || 1;
  }

  /** mulberry32: a small seeded generator, [0, 1). @param {number} a seed @returns {function(): number} */
  function rng(a) {
    a = a >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  //---------------------------------------------------------------------------
  // Reading the buyer's data
  //---------------------------------------------------------------------------

  function median(xs) {
    if (!xs.length) return 1;
    var s = xs.slice().sort(function (a, b) { return a - b; });
    var m = s.length >> 1;
    return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
  }

  /**
   * The database context every classification is anchored to: medians of the buyer's own enemies and the
   * element names of their own System. Built once per battle by Barrage.js from $dataEnemies / $dataSystem.
   * @param {Array} enemies $dataEnemies (index 0 is null in MZ)
   * @param {string[]} elementNames $dataSystem.elements
   * @returns {{median:number[], elements:string[]}} context
   */
  function dbContext(enemies, elementNames) {
    var cols = [[], [], [], [], [], [], [], []];
    for (var i = 0; i < (enemies || []).length; i++) {
      var e = enemies[i];
      if (!e || !e.params) continue;
      for (var p = 0; p < 8; p++) cols[p].push(Number(e.params[p]) || 0);
    }
    var med = [];
    for (var q = 0; q < 8; q++) med.push(Math.max(1, median(cols[q])));
    return { median: med, elements: (elementNames || []).map(function (s) { return String(s || ''); }) };
  }

  /**
   * Does this skill open a dodge phase? HP damage (type 1) or HP drain (type 5) aimed at the opposing side
   * (scope 1..6). A heal, a status-only skill or a self-buff does not.
   * @param {object} skill $dataSkills row
   * @returns {boolean} eligible
   */
  function isEligibleSkill(skill) {
    if (!skill || !skill.damage) return false;
    var t = Number(skill.damage.type), sc = Number(skill.scope);
    return (t === 1 || t === 5) && sc >= 1 && sc <= 6;
  }

  /**
   * Barrage notetags from a note field. Values are strings; tier is coerced and range-checked, never tested for
   * truthiness ("0" is a valid tier, wing §16).
   * @param {string} note Note text
   * @returns {{form:?string, family:?string, tier:?number, boss:boolean, off:boolean}} parsed tags
   */
  function parseNotes(note) {
    var out = { form: null, family: null, tier: null, boss: false, off: false };
    var s = String(note || '');
    var m = s.match(/<Barrage\s+Form\s*:\s*([A-Za-z]+)\s*>/i);
    if (m && FORM_R[m[1].toLowerCase()]) out.form = m[1].toLowerCase();
    m = s.match(/<Barrage\s+Pattern\s*:\s*([A-Za-z]+)\s*>/i);
    if (m && FAMILIES.indexOf(m[1].toLowerCase()) >= 0) out.family = m[1].toLowerCase();
    m = s.match(/<Barrage\s+Tier\s*:\s*([0-9]+)\s*>/i);
    if (m) { var t = Number(m[1]); if (isFinite(t) && t >= 0 && t <= 4) out.tier = Math.floor(t); }
    out.boss = /<Barrage\s+Boss\s*>/i.test(s);
    out.off = /<Barrage\s+Off\s*>/i.test(s);
    return out;
  }

  function attackElementOf(enemy) {
    var tr = (enemy && enemy.traits) || [];
    for (var i = 0; i < tr.length; i++) if (Number(tr[i].code) === 31) return Number(tr[i].dataId);
    return 0;
  }

  /**
   * What flies. Element name first (for a real element), then the enemy's own name, then its strongest
   * parameter measured against the database median.
   */
  function formFor(enemy, skill, ctx) {
    var el = Number(skill.damage.elementId);
    if (el < 0) el = attackElementOf(enemy);
    var ename = String((ctx.elements || [])[el] || '').toLowerCase();
    if (ename && !/physical|normal|none/.test(ename)) {
      for (var i = 0; i < ELEMENT_RE.length; i++) if (ELEMENT_RE[i][0].test(ename)) return ELEMENT_RE[i][1];
    }
    var nm = String(enemy.name || '').toLowerCase();
    for (var j = 0; j < NAME_RE.length; j++) if (NAME_RE[j][0].test(nm)) return NAME_RE[j][1];
    var best = 2, bestR = -1, keys = [2, 3, 4, 6, 7];
    for (var k = 0; k < keys.length; k++) {
      var p = keys[k], r = (Number(enemy.params && enemy.params[p]) || 0) / ctx.median[p];
      if (r > bestR + 1e-9) { bestR = r; best = p; }
    }
    return PARAM_FORM[best];
  }

  function tierFor(enemy, skill, ctx) {
    var magical = Number(skill.hitType) === 2;
    var off = Number(enemy.params && enemy.params[magical ? 4 : 2]) || 1;
    var agi = Number(enemy.params && enemy.params[6]) || 1;
    var raw = 2 + 2 * Math.log(off / ctx.median[magical ? 4 : 2]) / Math.LN2 + Math.log(agi / ctx.median[6]) / Math.LN2;
    return Math.max(0, Math.min(4, Math.round(raw)));
  }

  /**
   * Compose the attack an enemy makes with a skill.
   * @param {object} enemy $dataEnemies row
   * @param {object} skill $dataSkills row
   * @param {object} ctx dbContext()
   * @param {{seed:*}} [opts] plugin seed
   * @returns {object} spec {form, family, tier, boss, seed, phases:[{family, tier, frames, seed}], enemy, skill}
   */
  function classify(enemy, skill, ctx, opts) {
    var en = parseNotes(enemy && enemy.note), sn = parseNotes(skill && skill.note);
    var seedStr = String((opts && opts.seed) !== undefined ? opts.seed : 'barrage');
    var seed = seedOf(seedStr + ':' + enemy.id + ':' + enemy.name + ':' + skill.id);
    var form = sn.form || en.form || formFor(enemy, skill, ctx);
    var hit = Number(skill.hitType);
    if (!CELLS[hit]) hit = 1;
    var sc = Number(skill.scope);
    // scope 2 = all opponents, 4..6 = two to four random opponents (3 is ONE random opponent: single)
    var multi = sc === 2 || (sc >= 4 && sc <= 6) || Number(skill.repeats) > 1 ? 1 : 0;
    var cell = CELLS[hit][multi];
    // In turn by database id; the plugin seed rotates where the turn starts, so changing it changes the patterns too.
    var rot = Math.floor(rng(seedOf('cell:' + seedStr + ':' + hit + ':' + multi))() * cell.length);
    var id = Math.abs(Math.floor(Number(enemy.id) || 0));
    var family = sn.family || en.family || cell[(id + rot) % cell.length];
    var tier = sn.tier !== null ? sn.tier : en.tier !== null ? en.tier : tierFor(enemy, skill, ctx);
    var mhp = Number(enemy.params && enemy.params[0]) || 0;
    var boss = en.boss || sn.boss || mhp >= 3 * ctx.median[0];
    var phases = [];
    if (!boss) {
      phases.push({ family: family, tier: tier, frames: PHASE_FRAMES, seed: seed });
    } else {
      var n = mhp >= 6 * ctx.median[0] ? 3 : 2;
      var fams = [family], start = BOSS_ORDER.indexOf(family);
      for (var i = 1; fams.length < n && i <= BOSS_ORDER.length; i++) {
        var f = BOSS_ORDER[(Math.max(0, start) + i) % BOSS_ORDER.length];
        if (fams.indexOf(f) < 0) fams.push(f);
      }
      for (var k = 0; k < fams.length; k++) phases.push({ family: fams[k], tier: tier, frames: BOSS_PHASE_FRAMES, seed: (seed + k * 7919) >>> 0 });
    }
    return { form: form, family: family, tier: tier, boss: boss, seed: seed, phases: phases, enemy: String(enemy.name || ''), skill: String(skill.name || '') };
  }

  /** A single-phase spec for previews and tests. Default form is the LARGEST, so fairness is proved at the worst. */
  function specFor(family, tier, seed, form) {
    var s = seedOf(seed);
    return { form: form || 'stone', family: family, tier: tier, boss: false, seed: s, phases: [{ family: family, tier: tier, frames: PHASE_FRAMES, seed: s }], enemy: '', skill: '' };
  }

  //---------------------------------------------------------------------------
  // Kinematics: a shot's position is a pure function of frames since spawn
  //---------------------------------------------------------------------------

  function fold(v, lo, hi) {
    var span = hi - lo;
    if (span <= 0) return lo;
    var m = (v - lo) % (2 * span);
    if (m < 0) m += 2 * span;
    return lo + (m <= span ? m : 2 * span - m);
  }

  /**
   * Where a shot is at absolute frame f. Writes into `out` (no allocation).
   * Kinds: line · accel (capped) · sine · spin · bounce.
   * @param {object} s shot
   * @param {number} f frame
   * @param {{x:number,y:number}} out written
   * @returns {{x:number,y:number}} out
   */
  function posAt(s, f, out) {
    var t = f - s.t0;
    if (t < 0) t = 0;
    switch (s.kind) {
      case 'accel': {
        var tc = s.ay > 0 ? Math.max(0, (s.vmax - s.vy) / s.ay) : 0;
        out.x = s.x0 + s.vx * t;
        if (t <= tc) out.y = s.y0 + s.vy * t + 0.5 * s.ay * t * t;
        else out.y = s.y0 + s.vy * tc + 0.5 * s.ay * tc * tc + s.vmax * (t - tc);
        break;
      }
      case 'sine': {
        var off = s.amp * Math.sin(s.freq * t + s.ph);
        out.x = s.x0 + s.vx * t - s.vy / s.sp * off;
        out.y = s.y0 + s.vy * t + s.vx / s.sp * off;
        break;
      }
      case 'spin': {
        var r = s.r0 + s.rv * t, a = s.a0 + s.w * t;
        out.x = s.cx + r * Math.cos(a);
        out.y = s.cy + r * Math.sin(a);
        break;
      }
      case 'bounce': {
        out.x = fold(s.x0 + s.vx * t, s.r, ARENA.w - s.r);
        out.y = fold(s.y0 + s.vy * t, s.r, ARENA.h - s.r);
        break;
      }
      default:
        out.x = s.x0 + s.vx * t;
        out.y = s.y0 + s.vy * t;
    }
    return out;
  }

  /** Point an aimed shot at the soul, once, at spawn. Writes into the shot; no allocation. */
  function aimShot(s, sx, sy) {
    var dx = sx - s.x0, dy = sy - s.y0, d = Math.sqrt(dx * dx + dy * dy) || 1;
    var a = Math.atan2(dy, dx) + (s.spread || 0);
    s.vx = Math.cos(a) * s.speed;
    s.vy = Math.sin(a) * s.speed;
    return d;
  }

  /** Frames for a shot to leave the arena (+margin), found by stepping its own pure position. */
  function lifetime(s, cap) {
    var p = { x: 0, y: 0 }, m = 16;
    for (var t = 1; t <= cap; t++) {
      posAt(s, s.t0 + t, p);
      if (p.x < -m || p.x > ARENA.w + m || p.y < -m || p.y > ARENA.h + m) return t;
    }
    return cap;
  }

  /**
   * For a shot born OUTSIDE the arena: frames until it has come in and gone out again (0 if it never comes in, and the
   * caller drops it). A ring born on a 6 px circle just past the wall poked its inner half into the arena as a coiled
   * knot of 53 overlapping shots (LOOKED 2026-10-07); born 60 px out, it is a ring by the time anything is drawn.
   */
  function lifetimeIn(s, cap) {
    var p = { x: 0, y: 0 }, m = 16, seen = false;
    for (var t = 0; t <= cap; t++) {
      posAt(s, s.t0 + t, p);
      var out = p.x < -m || p.x > ARENA.w + m || p.y < -m || p.y > ARENA.h + m;
      if (!out) seen = true; else if (seen) return t;
    }
    return seen ? cap : 0;
  }

  //---------------------------------------------------------------------------
  // The seven families
  //---------------------------------------------------------------------------

  /**
   * A shot. `grace`: frames after spawn during which it is drawn fading in and CANNOT hit. Only shots that appear
   * INSIDE the arena carry one (a bounce at the wall, a spiral's emitter): a shot that enters from outside is seen
   * coming, one that appears on the soul is not (the first spiral spawned its arms ON the soul's start, 2026-10-07).
   */
  function shot(kind, form, t0) {
    return { kind: kind, form: form, r: FORM_R[form] || 5, hitR: (FORM_R[form] || 5) * 0.8, t0: t0, t1: t0 + 1,
      x0: 0, y0: 0, vx: 0, vy: 0, ay: 0, vmax: 0, amp: 0, freq: 0, ph: 0, sp: 1, cx: 0, cy: 0, r0: 0, rv: 0, a0: 0, w: 0,
      aim: false, speed: 0, spread: 0, grace: 0, emit: false };
  }

  /** Can shot s hit at frame f? False while it is fading in (its grace). One rule for the runtime, the solver and the bots. */
  function armed(s, f) { return f - s.t0 >= s.grace; }

  function clamp(v, lo, hi) { return v < lo ? lo : v > hi ? hi : v; }

  /**
   * The next wave's gap centre. It MUST move (at least 70% of the gap's own size, so two waves never share a safe
   * place), and never further than a soul can travel between waves. A plain random walk let the gaps of a low-tier
   * attack overlap and leave a spot the whole attack never touched (balance probe, 2026-10-07).
   */
  function nextGap(g, size, maxShift, span, R) {
    var lo = size / 2 + 8, hi = span - size / 2 - 8;
    var d = Math.min(maxShift, Math.max(size * 0.7, maxShift * (0.6 + 0.4 * R())));
    var sign = R() < 0.5 ? -1 : 1;
    if (g + sign * d < lo || g + sign * d > hi) sign = -sign;
    return clamp(g + sign * d, lo, hi);
  }

  function genRain(out, ph, T, R, form) {
    var tier = ph.tier, sm = 1 + 0.18 * tier, dm = 1 + 0.25 * tier;
    // 18 columns: 21 px apart, so the lane between two drops (21 - 2 x hit radius) is narrower than the soul.
    // 12 columns left 20 px lanes a soul could stand in for the whole attack (balance probe, 2026-10-07).
    // The 3-column safe window MOVES every row, so it cannot be camped either.
    // The column count comes from the FORM's hit radius: neighbouring drops must leave less than a soul's width
    // between them (2 px margin). A fixed 18 columns left 13-15 px lanes for small forms like sparks and needles.
    var hitR = (FORM_R[form] || 5) * 0.8, cwMax = 2 * SOUL.r + 2 * hitR - 2;
    var C = Math.ceil(ARENA.w / cwMax), cw = ARENA.w / C, I = Math.max(12, Math.round(28 / dm));
    var W3 = Math.max(2, Math.ceil(44 / cw));
    var win = Math.floor(R() * (C - W3 + 1)), dir = R() < 0.5 ? -1 : 1;
    for (var t = LEAD; t < ph.frames; t += I) {
      if (win + dir < 0 || win + dir > C - W3) dir = -dir;
      else if (R() < 0.25) dir = -dir;
      win += dir;
      for (var c = 0; c < C; c++) {
        if (c >= win && c < win + W3) continue;
        var s = shot('accel', form, T + t);
        s.x0 = (c + 0.5) * cw + (R() - 0.5) * 1;
        s.y0 = -8;
        s.vy = 1.0 * sm; s.ay = 0.05; s.vmax = Math.min(5.2, 2.6 * sm);
        s.t1 = s.t0 + lifetime(s, 400);
        out.push(s);
      }
    }
  }

  function genWall(out, ph, T, R, form, opts) {
    var tier = ph.tier, sm = 1 + 0.18 * tier, dm = 1 + 0.25 * tier;
    // Shots spread EVENLY over the full width (n slots of W/n, centred), so no edge strip is left uncovered.
    // The first version stepped from sp/2 and left 21 px at the right wall: the solver walked a soul down that
    // strip and called a "gapless" wall fair, which it was (2026-10-07).
    var n = Math.round(ARENA.w / (2 * MAX_R + 8)), sp = ARENA.w / n;
    var gw = Math.max(56, 80 - 6 * tier), I = Math.max(26, Math.round(56 / dm));
    var vy = 1.25 * sm, maxShift = SOUL.speed * I * 0.45, gx = ARENA.w * (0.25 + 0.5 * R());
    for (var t = LEAD; t < ph.frames; t += I) {
      gx = nextGap(gx, gw, maxShift, ARENA.w, R);
      for (var k = 0; k < n; k++) {
        var x = (k + 0.5) * sp;
        if (!(opts && opts.sabotageNoGap) && Math.abs(x - gx) < gw / 2) continue;
        var s;
        if (tier >= 3) {
          s = shot('sine', form, T + t);
          s.amp = 5; s.freq = 0.08; s.ph = x * 0.05;
        } else s = shot('line', form, T + t);
        s.x0 = x; s.y0 = -8; s.vx = 0; s.vy = vy; s.sp = vy;
        s.t1 = s.t0 + lifetime(s, 400);
        out.push(s);
      }
    }
  }

  function genSweep(out, ph, T, R, form) {
    var tier = ph.tier, sm = 1 + 0.18 * tier, dm = 1 + 0.25 * tier;
    var n = Math.round(ARENA.h / (2 * MAX_R + 8)), sp = ARENA.h / n;
    var gh = Math.max(54, 76 - 5 * tier), I = Math.max(24, Math.round(50 / dm));
    // A column must cross the whole arena well inside the phase; at 1.5 px/frame it took 256 frames and the far
    // side of a low-tier sweep was never touched.
    var dir = R() < 0.5 ? 1 : -1, vx = dir * (2.2 + 0.35 * tier), maxShift = SOUL.speed * I * 0.45;
    var gy = ARENA.h * (0.3 + 0.4 * R());
    for (var t = LEAD; t < ph.frames; t += I) {
      gy = nextGap(gy, gh, maxShift, ARENA.h, R);
      for (var k = 0; k < n; k++) {
        var y = (k + 0.5) * sp;
        if (Math.abs(y - gy) < gh / 2) continue;
        var s = shot('line', form, T + t);
        s.x0 = dir > 0 ? -8 : ARENA.w + 8; s.y0 = y; s.vx = vx; s.vy = 0;
        s.t1 = s.t0 + lifetime(s, 500);
        out.push(s);
      }
    }
  }

  function genSpiral(out, ph, T, R, form) {
    var tier = ph.tier, sm = 1 + 0.18 * tier, dm = 1 + 0.25 * tier;
    // Fire often enough that successive rays of one arm sit closer than a soul is wide at mid-arena radius;
    // at 12 frames they were 50 px apart at r = 150 and left whole lanes nothing ever crossed.
    // rv: a ray must reach the arena's corners (r ~ 220) inside the phase, or the far regions are never touched.
    var N = 4 + (tier >> 1), I = Math.max(5, Math.round(9 / dm)), rv = 2.1 + 0.2 * tier;
    var w0 = (R() < 0.5 ? 1 : -1) * (0.028 + 0.004 * tier), base = R() * Math.PI * 2;
    // The EMITTER is a shot of its own: visible (fading in, harmless) from the phase's first frame, then a hazard to
    // touch, so its arms never come out of nowhere. It sits in the upper half, never on the soul's start (the centre):
    // the first spiral spun out of the centre and its arms spawned on a soul that had not moved (LOOKED 2026-10-07).
    var cx = ARENA.w * (0.3 + 0.4 * R()), cy = ARENA.h * 0.28;
    var em = shot('line', form, T);
    em.x0 = cx; em.y0 = cy; em.t1 = T + ph.frames; em.grace = LEAD; em.emit = true;
    out.push(em);
    for (var t = LEAD + 18; t < ph.frames; t += I) {
      for (var a = 0; a < N; a++) {
        var s = shot('spin', form, T + t);
        s.cx = cx; s.cy = cy; s.r0 = 14; s.rv = rv;
        s.a0 = base + w0 * t + a * Math.PI * 2 / N;
        // alternate arms curl, at every tier: straight arms at tiers 0-1 opened gaps far from the emitter that nothing
        // crossed (tier 1: median 1,298 untouched solver cells straight, 742 curled; balance probe 2026-10-07)
        s.w = (a & 1) ? 0.003 * (w0 > 0 ? 1 : -1) : 0;
        s.t1 = s.t0 + lifetime(s, 400);
        out.push(s);
      }
    }
  }

  function genRing(out, ph, T, R, form) {
    var tier = ph.tier, sm = 1 + 0.18 * tier, dm = 1 + 0.25 * tier;
    // Dense rings (shots ~22 px apart at r = 200) that NEED their gap, alternating between two facing edges so
    // the far corners are reached. 14 shots a ring could be slipped through anywhere (probe: 40-90% of the arena
    // never touched).
    // ONE origin per attack: rings from two facing edges CROSS, and a soul cannot sit in both gaps at once
    // (the solver failed 24 of 40 at tier 4 when they alternated). Fast enough that the first ring reaches the far
    // corners inside the phase.
    var M = 52 + 2 * tier, I = Math.max(40, Math.round(80 / dm)), rv = 1.9 * sm;
    // Rings come from above or below: born 60 px out (no knot), they must still cross the arena inside the phase, and
    // across the 384 px long axis the far side of a tier-0 ring was never reached (up to 5,174 untouched cells).
    var O = 60, origins = [[ARENA.w / 2, -O], [ARENA.w / 2, ARENA.h + O]];
    var o = origins[Math.floor(R() * origins.length)];
    var gapN = 7, gap = Math.floor(R() * M);
    for (var t = LEAD; t < ph.frames; t += I) {
      // The gap moves almost its own width each ring, so no cone is safe for the whole attack (a one-slot walk
      // left cones of up to 5,000 solver cells never touched, probe 2026-10-07).
      gap = (gap + M + (R() < 0.5 ? -1 : 1) * (gapN - 1)) % M;
      for (var k = 0; k < M; k++) {
        var d = (k - gap + M) % M;
        if (d < gapN) continue;
        var s = shot('spin', form, T + t);
        s.cx = o[0]; s.cy = o[1]; s.r0 = 6; s.rv = rv;
        s.a0 = k * Math.PI * 2 / M;
        s.w = tier >= 3 ? 0.002 : 0;
        var life = lifetimeIn(s, 600);
        if (!life) continue;   // pointed away from the arena: it would never be seen
        s.t1 = s.t0 + life;
        out.push(s);
      }
    }
  }

  function genBounce(out, ph, T, R, form) {
    var tier = ph.tier, B = 4 + 3 * tier, speed = 1.6 + 0.3 * tier;
    for (var k = 0; k < B; k++) {
      var s = shot('bounce', form, T + LEAD + k * 16);
      var edge = Math.floor(R() * 4), u = 0.15 + 0.7 * R();
      s.x0 = edge === 1 ? ARENA.w - s.r : edge === 3 ? s.r : u * ARENA.w;
      s.y0 = edge === 0 ? s.r : edge === 2 ? ARENA.h - s.r : u * ARENA.h;
      var a = (0.35 + 0.3 * R()) * Math.PI / 2 + Math.floor(R() * 4) * Math.PI / 2;
      s.vx = Math.cos(a) * speed; s.vy = Math.sin(a) * speed;
      s.t1 = T + ph.frames;
      s.grace = 14;   // it appears at the wall, inside the arena: fade in before it can touch
      out.push(s);
    }
  }

  function genAimed(out, ph, T, R, form) {
    var tier = ph.tier, dm = 1 + 0.25 * tier, I = Math.max(10, Math.round(26 / dm));
    var V = 1 + (tier >> 1), speed = 1.8 + 0.22 * tier;
    for (var t = LEAD; t < ph.frames; t += I) {
      var edge = Math.floor(R() * 4), u = 0.1 + 0.8 * R();
      for (var v = 0; v < V; v++) {
        var s = shot('line', form, T + t);
        s.x0 = edge === 1 ? ARENA.w + 8 : edge === 3 ? -8 : u * ARENA.w;
        s.y0 = edge === 0 ? -8 : edge === 2 ? ARENA.h + 8 : u * ARENA.h;
        // The first shot of every volley is aimed dead centre; the rest fan out either side. A symmetric fan of an
        // EVEN count straddled the soul and never touched a still one (measured: 0 hits at tier 2).
        s.aim = true; s.speed = speed; s.spread = v === 0 ? 0 : (v % 2 ? 1 : -1) * Math.ceil(v / 2) * 0.3;
        aimShot(s, ARENA.w / 2, ARENA.h / 2);
        s.t1 = s.t0 + Math.ceil((ARENA.w + ARENA.h) / speed);
        out.push(s);
      }
    }
  }

  var GEN = { rain: genRain, wall: genWall, sweep: genSweep, spiral: genSpiral, ring: genRing, bounce: genBounce, aimed: genAimed };

  /**
   * Every shot of every phase, with absolute spawn frames, sorted by spawn. Built ONCE when a phase starts.
   * @param {object} spec classify() / specFor()
   * @param {{x:number,y:number}} [soul] where the soul starts (aimed shots re-aim at spawn at runtime)
   * @param {object} [opts] {sabotageNoGap} (tests only)
   * @returns {{shots:object[], frames:number}} schedule
   */
  function schedule(spec, soul, opts) {
    var shots = [], T = 0;
    for (var i = 0; i < spec.phases.length; i++) {
      var ph = spec.phases[i];
      GEN[ph.family](shots, ph, T, rng(ph.seed), spec.form, opts);
      T += ph.frames;
    }
    shots.sort(function (a, b) { return a.t0 - b.t0; });
    return { shots: shots, frames: T };
  }

  /** Is the soul at (x, y) touching shot s at frame f? `tmp` is caller-owned scratch. */
  function hits(s, f, x, y, tmp) {
    if (!armed(s, f)) return false;
    posAt(s, f, tmp);
    var dx = tmp.x - x, dy = tmp.y - y, rr = SOUL.r + s.hitR;
    return dx * dx + dy * dy < rr * rr;
  }

  /**
   * The damage multiplier for the hits taken. Zero hits is a dodge (the runtime turns it into the engine's MISS).
   * @param {number} n hits
   * @param {{perHit:number, cap:number}} cfg parameters (defaults 0.5 and 1.5)
   * @returns {number} multiplier
   */
  function scaleFor(n, cfg) {
    var per = cfg && isFinite(Number(cfg.perHit)) && cfg.perHit !== '' && cfg.perHit !== null ? Number(cfg.perHit) : 0.5;
    var cap = cfg && isFinite(Number(cfg.cap)) && cfg.cap !== '' && cfg.cap !== null ? Number(cfg.cap) : 1.5;
    if (!(n > 0)) return 0;
    return Math.min(cap, n * per);
  }

  //---------------------------------------------------------------------------
  // Fairness: a conservative solver proves a never-hit path exists
  //---------------------------------------------------------------------------

  /**
   * Grid solver over 3 px cells, one frame per step, 4-neighbour moves (3 px orthogonal per frame = SOUL.speed,
   * diagonals slower than a real player). A cell is unsafe if any live shot is within soul + hit radius + 1 px of
   * its centre. Fair iff some cell is still reachable when the attack ends. Rows are 128-bit bitsets.
   * @param {object} spec attack spec (aimed shots are judged by botRun instead)
   * @param {object} [opts] {sabotageNoGap}
   * @returns {{fair:boolean, diedAt:number, frames:number}} verdict
   */
  function fairness(spec, opts) {
    var sched = schedule(spec, { x: ARENA.w / 2, y: ARENA.h / 2 }, opts);
    var C = 3, GW = 128, GH = Math.floor(ARENA.h / C), WPR = 4;
    var reach = new Uint32Array(GH * WPR), next = new Uint32Array(GH * WPR), hot = new Uint32Array(GH * WPR), valid = new Uint32Array(GH * WPR), ever = new Uint32Array(GH * WPR);
    var i, x, y, w;
    for (y = 0; y < GH; y++) for (x = 0; x < GW; x++) {
      var px = (x + 0.5) * C, py = (y + 0.5) * C;
      if (px >= SOUL.r && px <= ARENA.w - SOUL.r && py >= SOUL.r && py <= ARENA.h - SOUL.r) valid[y * WPR + (x >> 5)] |= (1 << (x & 31));
    }
    var sx = Math.floor(ARENA.w / 2 / C), sy = Math.floor(ARENA.h / 2 / C);
    reach[sy * WPR + (sx >> 5)] |= (1 << (sx & 31));
    var p = { x: 0, y: 0 }, shots = sched.shots;
    for (var f = 0; f < sched.frames; f++) {
      hot.fill(0);
      for (i = 0; i < shots.length; i++) {
        var s = shots[i];
        if (s.t0 > f) break;
        if (s.t1 <= f || !armed(s, f)) continue;
        posAt(s, f, p);
        var R = SOUL.r + s.hitR + 1;
        var y0 = Math.max(0, Math.ceil((p.y - R) / C - 0.5)), y1 = Math.min(GH - 1, Math.floor((p.y + R) / C - 0.5));
        for (y = y0; y <= y1; y++) {
          var dy = (y + 0.5) * C - p.y, h2 = R * R - dy * dy;
          if (h2 <= 0) continue;
          var half = Math.sqrt(h2);
          var x0 = Math.max(0, Math.ceil((p.x - half) / C - 0.5)), x1 = Math.min(GW - 1, Math.floor((p.x + half) / C - 0.5));
          for (x = x0; x <= x1; x++) hot[y * WPR + (x >> 5)] |= (1 << (x & 31));
        }
      }
      var any = 0;
      for (i = 0; i < hot.length; i++) ever[i] |= hot[i];
      for (y = 0; y < GH; y++) {
        var b = y * WPR;
        for (w = 0; w < WPR; w++) {
          var r0 = reach[b + w];
          var left = ((r0 << 1) | (w > 0 ? reach[b + w - 1] >>> 31 : 0)) >>> 0;
          var right = ((r0 >>> 1) | (w < WPR - 1 ? reach[b + w + 1] << 31 : 0)) >>> 0;
          var up = y > 0 ? reach[b - WPR + w] : 0, down = y < GH - 1 ? reach[b + WPR + w] : 0;
          var nv = ((r0 | left | right | up | down) & valid[b + w] & ~hot[b + w]) >>> 0;
          next[b + w] = nv;
          any |= nv;
        }
      }
      var tmp = reach; reach = next; next = tmp;
      if (!any) return { fair: false, diedAt: f, frames: sched.frames, campCells: -1 };
    }
    // CAMP CELLS: places no shot ever touches. A soul parked there takes nothing for the whole attack, which is
    // the opposite failure to unfairness (too easy), and the first wall had one at the right edge.
    var camp = 0;
    for (i = 0; i < valid.length; i++) { var v = (valid[i] & ~ever[i]) >>> 0; while (v) { v &= v - 1; camp++; } }
    return { fair: true, diedAt: -1, frames: sched.frames, campCells: camp };
  }

  /**
   * A scripted soul plays an attack the way the runtime would (aimed shots re-aim at spawn, i-frames after a hit).
   * @param {object} spec attack spec
   * @param {'still'|'circle'} mode how the soul moves
   * @returns {{hits:number, frames:number}} result
   */
  function botRun(spec, mode) {
    var sched = schedule(spec, { x: ARENA.w / 2, y: ARENA.h / 2 });
    var shots = sched.shots, live = [], next = 0, hitsN = 0, inv = 0, tmp = { x: 0, y: 0 };
    var cx = ARENA.w / 2, cy = ARENA.h / 2, rad = 70, w = SOUL.speed / rad, sx = cx, sy = cy;
    for (var f = 0; f < sched.frames; f++) {
      if (mode === 'circle') { sx = cx + rad * Math.cos(w * f); sy = cy + rad * Math.sin(w * f); }
      while (next < shots.length && shots[next].t0 <= f) {
        var s = shots[next++];
        if (s.aim) aimShot(s, sx, sy);
        live.push(s);
      }
      if (inv > 0) { inv--; continue; }
      for (var i = 0; i < live.length; i++) {
        if (live[i].t1 <= f) continue;
        if (hits(live[i], f, sx, sy, tmp)) { hitsN++; inv = IFRAMES; break; }
      }
    }
    return { hits: hitsN, frames: sched.frames };
  }

  CSAF.BarrageCore = {
    VERSION: VERSION, ARENA: ARENA, SOUL: SOUL, POOL: POOL, MAX_STEP: MAX_STEP, LEAD: LEAD, IFRAMES: IFRAMES,
    FAMILIES: FAMILIES, FORMS: FORMS, FORM_R: FORM_R, CELLS: CELLS, seedOf: seedOf, rng: rng, dbContext: dbContext,
    LEXICON: { elements: ELEMENT_WORDS, names: NAME_WORDS, params: PARAM_FORM },
    isEligibleSkill: isEligibleSkill, parseNotes: parseNotes, classify: classify, specFor: specFor,
    schedule: schedule, posAt: posAt, aimShot: aimShot, hits: hits, armed: armed, scaleFor: scaleFor, fairness: fairness, botRun: botRun
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.BarrageCore;
