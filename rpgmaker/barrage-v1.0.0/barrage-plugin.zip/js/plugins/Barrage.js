//=============================================================================
// Barrage.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Every enemy attack becomes a dodge phase composed from that enemy's own database entry. Load after BarrageCore and BarrageDraw.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 * @base BarrageCore
 * @orderAfter BarrageDraw
 *
 * @param disableSwitch
 * @text Disable switch
 * @type switch
 * @desc While this switch is ON, enemy attacks resolve normally with no dodge phase. 0 = never disabled.
 * @default 0
 *
 * @param perHit
 * @text Damage per hit
 * @type number
 * @decimals 2
 * @min 0
 * @desc Each hit taken adds this share of the skill's damage. 0 hits is a MISS.
 * @default 0.50
 *
 * @param cap
 * @text Damage cap
 * @type number
 * @decimals 2
 * @min 0
 * @desc The most the hits can multiply the skill's damage by.
 * @default 1.50
 *
 * @param seed
 * @text Seed
 * @desc Changes every composed attack in the game. The same seed always composes the same attacks.
 * @default barrage
 *
 * @param soulShape
 * @text Soul shape
 * @type select
 * @option heart
 * @option diamond
 * @option star
 * @default heart
 *
 * @param soulColour
 * @text Soul colour
 * @default #ff3b4e
 *
 * @param labelFont
 * @text Label typeface
 * @desc The attack's title above the arena. A CSS font stack; never the engine's default face.
 * @default "Trebuchet MS", Verdana, sans-serif
 *
 * @help
 * When an enemy uses a skill that deals HP damage (or drains HP) to your
 * party, the battle pauses and a framed arena opens. The player steers the
 * soul through that enemy's attack with the arrow keys, a gamepad, the mouse
 * or a finger (drag; the soul follows). When it ends, every hit taken scales
 * the damage the skill deals: none is a MISS, each hit adds "Damage per hit",
 * up to "Damage cap".
 *
 * NOTHING TO AUTHOR. Each attack is composed from data you already have:
 *   - what flies comes from the skill's element NAME (Fire, Ice, Thunder...),
 *     else from the enemy's own name (a Crow throws feathers), else from its
 *     strongest parameter against the median of your Enemies database;
 *   - how it flies (rain, sweep, wall, spiral, ring, bounce, aimed) comes from
 *     the skill's hit type and scope, which pick three patterns that enemies
 *     take in turn by database id (neighbours never attack alike); the Seed
 *     parameter rotates the turn;
 *   - how dense and fast comes from the attacker's stats against your
 *     database's median;
 *   - an enemy with 3x the median max HP is a boss and attacks in phases.
 *
 * NOTETAGS (enemy or skill note box) override any of it:
 *   <Barrage Form: ember>     ember shard spark droplet pebble leaf mote wisp
 *                             blade bone feather needle stone orb coin thorn
 *                             fang note
 *   <Barrage Pattern: ring>   rain sweep wall spiral ring bounce aimed
 *   <Barrage Tier: 3>         0 (gentle) to 4 (fierce)
 *   <Barrage Boss>            attack in phases
 *   <Barrage Off>             this enemy / this skill never opens a phase
 *
 * Every attack the plugin can compose is proved survivable in its tests: a
 * path that is never hit exists through every pattern at every tier.
 */

(function () {
  'use strict';

  var PLUGIN = 'Barrage';
  var P = PluginManager.parameters(PLUGIN);
  var num = function (v, d) { var n = Number(v); return v === '' || v === undefined || v === null || !isFinite(n) ? d : n; };
  var CFG = {
    disableSwitch: num(P.disableSwitch, 0),
    perHit: num(P.perHit, 0.5),
    cap: num(P.cap, 1.5),
    seed: String(P.seed === undefined || P.seed === '' ? 'barrage' : P.seed),
    soulShape: String(P.soulShape || 'heart'),
    soulColour: String(P.soulColour || '#ff3b4e'),
    labelFont: String(P.labelFont || '"Trebuchet MS", Verdana, sans-serif')
  };

  /**
   * A CSS colour the canvas actually accepts, else the default. A canvas IGNORES an unparseable fillStyle and keeps
   * its previous one (black), so a typo in Soul colour drew a black soul on a near-black arena (wing §21c): set two
   * different sentinels and the value must replace both.
   */
  function cssColour(v, d) {
    var c = document.createElement('canvas').getContext('2d'), s = String(v || '');
    c.fillStyle = '#010203'; c.fillStyle = s; var a = c.fillStyle;
    c.fillStyle = '#030201'; c.fillStyle = s; var b = c.fillStyle;
    return s && a === b ? s : d;
  }

  /** Resolved at FIRST USE, never at load time: plugin order is the buyer's (wing §8 trap 2). */
  function deps() {
    var C = window.CSAF || {};
    if (!C.BarrageCore || !C.BarrageArt) throw new Error('[Barrage] BarrageCore.js and BarrageDraw.js must be installed (any order).');
    return { core: C.BarrageCore, art: C.BarrageArt };
  }

  /** BAND: the frame's dark band, wider than the largest drawn shot radius (7 x 1.5 x 1.3 = 13.65 px at scale 1.5). */
  var INTRO = 14, OUTRO = 22, DRAW_SCALE = 1.3, BAND = 18;

  //===========================================================================
  // The phase: one live attack at a time
  //===========================================================================

  var Barrage = {
    running: false,
    ctx: null,
    spec: null,
    sched: null,
    frame: 0,
    total: 0,
    hits: 0,
    inv: 0,
    soul: { x: 0, y: 0 },
    action: null,
    arena: null,
    next: 0,
    // fixed pools: live slot list and the shot each slot holds (no allocation per frame)
    live: null,
    liveN: 0,
    slotShot: null,
    freeSlots: null,
    freeN: 0
  };
  window.CSAF_Barrage = Barrage;

  /** The database context: medians of THIS project's enemies, its element names. Built once per battle. */
  Barrage.context = function () {
    if (!this.ctx) this.ctx = deps().core.dbContext($dataEnemies, $dataSystem.elements);
    return this.ctx;
  };

  /**
   * Should this action open a dodge phase?
   * @param {Game_Battler} subject acting battler
   * @param {Game_Action} action its action
   * @param {Game_Battler[]} targets the manager's target list
   * @returns {boolean} yes
   */
  Barrage.shouldRun = function (subject, action, targets) {
    if (!subject || !subject.isEnemy || !subject.isEnemy() || !action || !action.isSkill || !action.isSkill()) return false;
    if (CFG.disableSwitch > 0 && $gameSwitches.value(CFG.disableSwitch)) return false;
    if (!this.arena) return false;
    var skill = action.item(), enemy = subject.enemy();
    var core = deps().core;
    if (!core.isEligibleSkill(skill)) return false;
    if (core.parseNotes(enemy.note).off || core.parseNotes(skill.note).off) return false;
    for (var i = 0; i < targets.length; i++) if (targets[i] && targets[i].isActor && targets[i].isActor() && targets[i].isAlive()) return true;
    return false;
  };

  /** Open the arena on this enemy's attack. */
  Barrage.begin = function (subject, action) {
    var core = deps().core;
    this.spec = core.classify(subject.enemy(), action.item(), this.context(), { seed: CFG.seed });
    this.startSpec(this.spec, action, subject.name());
  };

  /** Start a composed spec (also used by previews and captures). */
  Barrage.startSpec = function (spec, action, title) {
    var core = deps().core;
    this.spec = spec;
    this.sched = core.schedule(spec, { x: core.ARENA.w / 2, y: core.ARENA.h / 2 });
    this.frame = -INTRO;
    this.total = this.sched.frames;
    this.hits = 0;
    this.inv = 0;
    this.soul.x = core.ARENA.w / 2;
    this.soul.y = core.ARENA.h / 2;
    this.action = action || null;
    this.next = 0;
    if (!this.live) {
      this.live = new Int16Array(core.POOL);
      this.slotShot = new Array(core.POOL);
      this.freeSlots = new Int16Array(core.POOL);
    }
    this.liveN = 0;
    this.freeN = core.POOL;
    for (var i = 0; i < core.POOL; i++) { this.freeSlots[i] = core.POOL - 1 - i; this.slotShot[i] = null; }
    this.running = true;
    if (this.arena) this.arena.open(spec, title || '');
  };

  /** End: write the damage scale onto the action (non-enumerable, wing §13) and let the battle continue. */
  Barrage.finish = function () {
    var core = deps().core;
    var scale = core.scaleFor(this.hits, CFG);
    if (this.action) {
      Object.defineProperty(this.action, '_csafBarrageScale', { value: scale, writable: true, enumerable: false, configurable: true });
    }
    this.lastResult = { hits: this.hits, scale: scale, form: this.spec.form, family: this.spec.family, phases: this.spec.phases.length };
    this.running = false;
    if (this.arena) this.arena.close();
  };

  /** One frame of the live attack. Called by the arena sprite's update. No allocation. */
  Barrage.step = function (input) {
    var core = deps().core, A = core.ARENA, S = core.SOUL;
    // move the soul (keys / pad / drag), clamped inside the arena
    var mx = input.mx, my = input.my, sp = S.speed;
    if (input.tx !== null) {
      var dx = input.tx - this.soul.x, dy = input.ty - this.soul.y, d = Math.sqrt(dx * dx + dy * dy);
      if (d > 0.5) { var k = Math.min(sp, d) / d; this.soul.x += dx * k; this.soul.y += dy * k; }
    } else if (mx || my) {
      var len = Math.sqrt(mx * mx + my * my);
      this.soul.x += mx / len * sp; this.soul.y += my / len * sp;
    }
    if (this.soul.x < S.r) this.soul.x = S.r; else if (this.soul.x > A.w - S.r) this.soul.x = A.w - S.r;
    if (this.soul.y < S.r) this.soul.y = S.r; else if (this.soul.y > A.h - S.r) this.soul.y = A.h - S.r;
    var f = this.frame;
    if (f >= 0 && f < this.total) {
      var shots = this.sched.shots;
      while (this.next < shots.length && shots[this.next].t0 <= f) {
        var s = shots[this.next++];
        if (this.freeN === 0) continue; // pool exhausted: a peak the tests bound below the pool size
        if (s.aim) core.aimShot(s, this.soul.x, this.soul.y);
        var slot = this.freeSlots[--this.freeN];
        this.slotShot[slot] = s;
        this.live[this.liveN++] = slot;
        if (this.arena) this.arena.bindShot(slot, s);
      }
      if (this.inv > 0) this.inv--;
      var tmp = this.arena ? this.arena.tmp : TMP;
      for (var i = this.liveN - 1; i >= 0; i--) {
        var sl = this.live[i], sh = this.slotShot[sl];
        if (sh.t1 <= f) {
          this.live[i] = this.live[--this.liveN];
          this.slotShot[sl] = null;
          this.freeSlots[this.freeN++] = sl;
          if (this.arena) this.arena.unbindShot(sl);
          continue;
        }
        if (this.inv === 0 && core.hits(sh, f, this.soul.x, this.soul.y, tmp)) {
          this.hits++;
          this.inv = core.IFRAMES;
          if (this.arena) this.arena.onHit();
        }
      }
    }
    this.frame++;
    if (this.frame >= this.total + OUTRO && this.running) this.finish();
  };
  var TMP = { x: 0, y: 0 };

  //===========================================================================
  // The arena: one Sprite tree above the battle windows
  //===========================================================================

  function Sprite_BarrageArena() { this.initialize.apply(this, arguments); }
  Sprite_BarrageArena.prototype = Object.create(Sprite.prototype);
  Sprite_BarrageArena.prototype.constructor = Sprite_BarrageArena;

  Sprite_BarrageArena.prototype.initialize = function () {
    Sprite.prototype.initialize.call(this);
    var core = deps().core;
    this.tmp = { x: 0, y: 0 };
    this.tmp2 = { x: 0, y: 0 };
    this._input = { mx: 0, my: 0, tx: null, ty: null };
    var statusH = 184;
    this._scale = Math.max(1, Math.min(2, Math.min((Graphics.boxWidth - 80) / core.ARENA.w, (Graphics.boxHeight - statusH - 110) / core.ARENA.h)));
    this._w = Math.round(core.ARENA.w * this._scale);
    this._h = Math.round(core.ARENA.h * this._scale);
    this._ox = Math.round((Graphics.width - this._w) / 2);
    this._oy = Math.round(Math.max(64, (Graphics.height - statusH - this._h) / 2 + 20));
    this._dim = new Sprite(new Bitmap(4, 4));
    this._dim.bitmap.fillAll('#05040a');
    this._dim.scale.x = Graphics.width / 4; this._dim.scale.y = Graphics.height / 4;
    this.addChild(this._dim);
    // The frame is TWO sprites: the ground under the shots and the border over them, so a shot entering the arena
    // slides in under the rule, and a hit flash tints the BORDER only (one sprite with both turned the whole ground
    // maroon, LOOKED 2026-10-07).
    this._ground = new Sprite(this.makeGround());
    this._ground.x = this._ox - 10; this._ground.y = this._oy - 10;
    this.addChild(this._ground);
    this._field = new Sprite();
    this._field.x = this._ox; this._field.y = this._oy;
    this.addChild(this._field);
    // NO PIXI MASK. LOOKED 2026-10-07: a Graphics mask on the field clipped EVERY sibling in this container (the dim,
    // the frame's rules and the title vanished), as a child and again when kept out of the display list. Instead a
    // shot is drawn only while its centre is inside the arena, and the border's dark band (wider than the largest
    // drawn radius) covers the half still outside, so nothing pops and nothing is drawn over the frame or title.
    this._frame = new Sprite(this.makeBorder());
    this._frame.x = this._ox - BAND; this._frame.y = this._oy - BAND;
    this.addChild(this._frame);
    this._atlas = null;
    this._frames = null;
    this._pool = [];
    for (var i = 0; i < core.POOL; i++) {
      var sp = new Sprite();
      sp.anchor.x = 0.5; sp.anchor.y = 0.5; sp.visible = false;
      this._field.addChild(sp);
      this._pool.push(sp);
    }
    this._soul = new Sprite(this.makeSoul());
    this._soul.anchor.x = 0.5; this._soul.anchor.y = 0.5;
    this._field.addChild(this._soul);
    this._label = new Sprite(new Bitmap(this._w + 20, 40));
    this._label.x = this._ox - 10; this._label.y = this._oy - BAND - 40;
    this.addChild(this._label);
    this._result = new Sprite(new Bitmap(this._w, 110));
    this._result.x = this._ox; this._result.y = this._oy + this._h / 2 - 55;
    this.addChild(this._result);
    this._shake = 0;
    this._flash = 0;
    this._blend = [255, 60, 80, 0];
    this._blendOff = [0, 0, 0, 0];
    this._blendOn = false;
    this.visible = false;
    this.opacity = 0;
    Barrage.arena = this;
  };

  /** The ground: a deep field with a soft vignette. Drawn, never a windowskin. */
  Sprite_BarrageArena.prototype.makeGround = function () {
    var w = this._w + 20, h = this._h + 20, b = new Bitmap(w, h), c = b.context;
    c.fillStyle = '#0b0a12'; c.fillRect(10, 10, this._w, this._h);
    var g = c.createRadialGradient(w / 2, h / 2, this._h * 0.2, w / 2, h / 2, this._w * 0.7);
    g.addColorStop(0, 'rgba(60,50,90,0.25)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    c.fillStyle = g; c.fillRect(10, 10, this._w, this._h);
    b._baseTexture.update();
    return b;
  };

  /**
   * The border, drawn OVER the shots: a dark band BAND px wide (it hides the outer half of a shot entering or leaving),
   * a bright rule on its inner edge, a fine outer rule and bracketed corners. Transparent inside.
   */
  Sprite_BarrageArena.prototype.makeBorder = function () {
    var M = BAND, w = this._w + 2 * M, h = this._h + 2 * M, b = new Bitmap(w, h), c = b.context;
    c.fillStyle = '#17141f';
    c.beginPath(); c.rect(0, 0, w, h); c.rect(M, M + this._h, this._w, -this._h); c.fill('evenodd');
    var g = c.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, 'rgba(255,255,255,0.06)'); g.addColorStop(1, 'rgba(0,0,0,0.25)');
    c.fillStyle = g; c.beginPath(); c.rect(0, 0, w, h); c.rect(M, M + this._h, this._w, -this._h); c.fill('evenodd');
    c.strokeStyle = '#f4efe2'; c.lineWidth = 4; c.strokeRect(M - 2, M - 2, this._w + 4, this._h + 4);
    c.strokeStyle = 'rgba(244,239,226,0.5)'; c.lineWidth = 1; c.strokeRect(1.5, 1.5, w - 3, h - 3);
    c.fillStyle = '#f4efe2';
    var L = 22, T = 5;
    [[2, 2, 1, 1], [w - 2, 2, -1, 1], [2, h - 2, 1, -1], [w - 2, h - 2, -1, -1]].forEach(function (q) {
      c.fillRect(q[2] > 0 ? q[0] : q[0] - L, q[3] > 0 ? q[1] : q[1] - T, L, T);
      c.fillRect(q[2] > 0 ? q[0] : q[0] - T, q[3] > 0 ? q[1] : q[1] - L, T, L);
    });
    b._baseTexture.update();
    return b;
  };

  /** The soul token, drawn: heart, diamond or star, in the chosen colour with a light rim. */
  Sprite_BarrageArena.prototype.makeSoul = function () {
    var core = deps().core, r = core.SOUL.r * this._scale * 1.25, s = Math.ceil(r * 2.6), b = new Bitmap(s, s), c = b.context;
    c.translate(s / 2, s / 2);
    c.beginPath();
    if (CFG.soulShape === 'diamond') {
      c.moveTo(0, -r); c.lineTo(r * 0.8, 0); c.lineTo(0, r); c.lineTo(-r * 0.8, 0); c.closePath();
    } else if (CFG.soulShape === 'star') {
      for (var i = 0; i < 10; i++) { var a = i / 10 * Math.PI * 2 - Math.PI / 2, rr = i % 2 ? r * 0.45 : r; c.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); }
      c.closePath();
    } else {
      c.moveTo(0, r * 0.95);
      c.bezierCurveTo(-r * 1.35, r * 0.05, -r * 0.75, -r * 1.05, 0, -r * 0.42);
      c.bezierCurveTo(r * 0.75, -r * 1.05, r * 1.35, r * 0.05, 0, r * 0.95);
      c.closePath();
    }
    c.fillStyle = cssColour(CFG.soulColour, '#ff3b4e'); c.fill();
    c.strokeStyle = 'rgba(255,255,255,0.85)'; c.lineWidth = Math.max(1, r * 0.14); c.stroke();
    b._baseTexture.update();
    return b;
  };

  /** Bake every form ONCE into one atlas at the arena's scale: one base texture, so PIXI batches all shots. */
  Sprite_BarrageArena.prototype.ensureAtlas = function () {
    if (this._atlas) return;
    var d = deps(), forms = d.art.FORMS, cells = [], x = 0, y = 0, rowH = 0, W = 1024;
    for (var i = 0; i < forms.length; i++) {
      // Drawn 1.3x the HIT radius's form size: at play size the forms read as crescents and dots otherwise (LOOKED
      // 2026-10-07), and a hitbox inside the drawing is the fair convention of the genre.
      var r = d.core.FORM_R[forms[i]] * this._scale * DRAW_SCALE, cs = d.art.cellFor(r);
      if (x + cs > W) { x = 0; y += rowH; rowH = 0; }
      cells.push({ f: forms[i], x: x, y: y, s: cs, r: r });
      x += cs; rowH = Math.max(rowH, cs);
    }
    var bmp = new Bitmap(W, y + rowH + 2), c = bmp.context;
    this._frames = {};
    for (var j = 0; j < cells.length; j++) {
      var q = cells[j];
      c.save(); c.translate(q.x + q.s / 2, q.y + q.s / 2); d.art.drawForm(c, q.f, q.r); c.restore();
      this._frames[q.f] = q;
    }
    bmp._baseTexture.update();
    this._atlas = bmp;
    for (var k = 0; k < this._pool.length; k++) this._pool[k].bitmap = bmp;
  };

  Sprite_BarrageArena.prototype.open = function (spec, title) {
    this.ensureAtlas();
    // The engine's battle log ("Crow B attacks!") sat on the title's row and competed with it (LOOKED 2026-10-07):
    // hide it for the phase and give it back exactly as it was.
    var log = BattleManager._logWindow;
    if (log && this._logWas === undefined) { this._logWas = log.visible; log.visible = false; }
    this.visible = true;
    this.opacity = 0;
    this._shake = 0; this._flash = 0;
    this._soul.visible = true;
    this._result.bitmap.clear();
    var b = this._label.bitmap;
    b.clear();
    b.fontFace = CFG.labelFont; b.fontSize = 22; b.fontBold = true;
    b.outlineWidth = 4; b.outlineColor = 'rgba(5,4,10,0.9)'; b.textColor = '#f4efe2';
    b.drawText(String(title || spec.enemy || '').toUpperCase() + (spec.skill ? '  ·  ' + spec.skill : ''), 0, 4, b.width, 32, 'center');
    for (var i = 0; i < this._pool.length; i++) this._pool[i].visible = false;
  };

  /**
   * The verdict, over an EMPTY arena: every shot is cleared first. LOOKED 2026-10-07: the shots froze where the outro
   * left them, so "UNTOUCHED" was drawn over a feather sitting on the soul. A second line says what the hits did.
   */
  Sprite_BarrageArena.prototype.close = function () {
    for (var i = 0; i < this._pool.length; i++) this._pool[i].visible = false;
    var b = this._result.bitmap, r = Barrage.lastResult || { hits: Barrage.hits, scale: 0 };
    b.clear();
    b.fontFace = CFG.labelFont; b.fontBold = true;
    b.outlineWidth = 6; b.outlineColor = 'rgba(5,4,10,0.95)';
    b.fontSize = 44;
    b.textColor = r.hits === 0 ? '#ffe68a' : '#ff8a8a';
    b.drawText(r.hits === 0 ? 'UNTOUCHED' : (r.hits + (r.hits === 1 ? ' HIT' : ' HITS')), 0, 6, b.width, 54, 'center');
    b.fontSize = 22; b.outlineWidth = 4;
    b.textColor = '#f4efe2';
    b.drawText(r.hits === 0 ? 'MISS' : '×' + (Math.round(r.scale * 100) / 100) + ' DAMAGE', 0, 62, b.width, 32, 'center');
    this._closing = 18;
  };

  Sprite_BarrageArena.prototype.restoreLog = function () {
    var log = BattleManager._logWindow;
    if (log && this._logWas !== undefined) log.visible = this._logWas;
    this._logWas = undefined;
  };

  Sprite_BarrageArena.prototype.bindShot = function (slot, s) {
    var sp = this._pool[slot], q = this._frames[s.form] || this._frames.orb;
    sp.setFrame(q.x, q.y, q.s, q.s);
    sp.visible = true;
    sp.rotation = 0;
    sp.scale.x = 1;
    sp.scale.y = 1;
    sp.opacity = 255;
  };

  Sprite_BarrageArena.prototype.unbindShot = function (slot) { this._pool[slot].visible = false; };

  Sprite_BarrageArena.prototype.onHit = function () {
    this._shake = 10; this._flash = 12;
    SoundManager.playActorDamage();
  };

  /** Read keys, gamepad, mouse and touch into the shared input record (no allocation). */
  Sprite_BarrageArena.prototype.readInput = function () {
    var I = this._input;
    I.mx = (Input.isPressed('right') ? 1 : 0) - (Input.isPressed('left') ? 1 : 0);
    I.my = (Input.isPressed('down') ? 1 : 0) - (Input.isPressed('up') ? 1 : 0);
    if (TouchInput.isPressed()) {
      I.tx = (TouchInput.x - this._ox) / this._scale;
      I.ty = (TouchInput.y - this._oy) / this._scale;
    } else { I.tx = null; I.ty = null; }
    return I;
  };

  Sprite_BarrageArena.prototype.update = function () {
    Sprite.prototype.update.call(this);
    if (!this.visible) return;
    if (Barrage.running) {
      this.opacity = Math.min(255, this.opacity + 24);
      this._dim.opacity = 150;
      Barrage.step(this.readInput());
      this.place();
    } else if (this._closing > 0) {
      this._closing--;
      if (this._closing < 10) this.opacity = Math.max(0, this.opacity - 26);
      if (this._closing === 0) { this.visible = false; this.restoreLog(); }
    } else {
      this.visible = false;
    }
  };

  /** Write every live shot's position into its sprite. Two position reads per turning shot, no allocation. */
  Sprite_BarrageArena.prototype.place = function () {
    var d = deps(), core = d.core, INFO = d.art.INFO, sc = this._scale, f = Barrage.frame - 1;
    var sx = this._shake > 0 ? ((this._shake & 1) ? 3 : -3) : 0;
    if (this._shake > 0) this._shake--;
    this._field.x = this._ox + sx;
    this._frame.x = this._ox - BAND + sx;
    this._ground.x = this._ox - 10 + sx;
    var aw = core.ARENA.w, ah = core.ARENA.h;
    // Preallocated colour arrays, set only while the flash is changing: an array literal here was one allocation a
    // frame for the whole phase (wing §3, zero allocation in per-frame paths).
    if (this._flash > 0) { this._flash--; this._blend[3] = this._flash * 14; this._frame.setBlendColor(this._blend); this._blendOn = true; }
    else if (this._blendOn) { this._frame.setBlendColor(this._blendOff); this._blendOn = false; }
    for (var i = 0; i < Barrage.liveN; i++) {
      var slot = Barrage.live[i], s = Barrage.slotShot[slot], sp = this._pool[slot];
      core.posAt(s, f, this.tmp);
      sp.x = this.tmp.x * sc; sp.y = this.tmp.y * sc;
      // drawn only while its centre is inside; the band covers the outer half (see BAND)
      sp.visible = this.tmp.x >= 0 && this.tmp.x <= aw && this.tmp.y >= 0 && this.tmp.y <= ah;
      var info = INFO[s.form], age = f - s.t0;
      // a shot that appears INSIDE the arena fades in over its grace, and cannot hit until it is solid (BarrageCore.armed);
      // after the attack's last frame (the outro, where nothing hits) every shot dissolves before the verdict
      sp.opacity = f >= Barrage.total ? Math.max(0, Math.round(255 * (1 - (f - Barrage.total + 1) / OUTRO)))
        : s.grace > 0 && age < s.grace ? Math.round(255 * (age + 1) / (s.grace + 1)) : 255;
      if (s.emit) {
        // a spiral's emitter: the same form, larger, breathing and turning, so the source of the arms is never in doubt
        var k = 1.6 + 0.14 * Math.sin(age * 0.16);
        sp.scale.x = k; sp.scale.y = k;
        sp.rotation = age * 0.045;
      } else if (info && info.turn) {
        core.posAt(s, f - 1, this.tmp2);
        var dx = this.tmp.x - this.tmp2.x, dy = this.tmp.y - this.tmp2.y;
        if (dx * dx + dy * dy > 1e-4) sp.rotation = Math.atan2(dy, dx);
        // a feather or a leaf does not fall nose-first: it rocks about its heading (LOOKED 2026-10-07: rigid
        // feathers read as beans)
        if (info.sway) sp.rotation += 0.55 * Math.sin((f - s.t0) * 0.11 + slot);
      } else if (info && info.spin) {
        sp.rotation = (f - s.t0) * ((slot & 1) ? 0.08 : -0.08);
      } else if (s.form === 'coin') {
        sp.scale.x = Math.max(0.15, Math.abs(Math.cos((f - s.t0) * 0.12)));
      }
    }
    this._soul.x = Barrage.soul.x * sc; this._soul.y = Barrage.soul.y * sc;
    this._soul.visible = Barrage.inv === 0 || ((Barrage.inv >> 2) & 1) === 0;
  };

  window.Sprite_BarrageArena = Sprite_BarrageArena;

  //===========================================================================
  // Engine seams: every patch extends and calls its saved original
  //===========================================================================

  var _BattleManager_setup = BattleManager.setup;
  BattleManager.setup = function (troopId, canEscape, canLose) {
    _BattleManager_setup.call(this, troopId, canEscape, canLose);
    Barrage.ctx = null;       // the database could have changed since the last battle (it is re-read once)
    Barrage.running = false;
  };

  var _BattleManager_updateAction = BattleManager.updateAction;
  BattleManager.updateAction = function () {
    var act = this._action;
    if (act && !act._csafBarrageAsked) {
      Object.defineProperty(act, '_csafBarrageAsked', { value: true, writable: true, enumerable: false, configurable: true });
      if (Barrage.shouldRun(this._subject, act, this._targets)) { Barrage.begin(this._subject, act); return; }
    }
    _BattleManager_updateAction.call(this);
  };

  var _Spriteset_Battle_isBusy = Spriteset_Battle.prototype.isBusy;
  Spriteset_Battle.prototype.isBusy = function () {
    return _Spriteset_Battle_isBusy.call(this) || Barrage.running || !!(Barrage.arena && Barrage.arena.visible);
  };

  var _Scene_Battle_createAllWindows = Scene_Battle.prototype.createAllWindows;
  Scene_Battle.prototype.createAllWindows = function () {
    _Scene_Battle_createAllWindows.call(this);
    this._csafBarrageArena = new Sprite_BarrageArena();
    this.addChild(this._csafBarrageArena);   // above the window layer, so the status window never covers it
  };

  // MZ re-sets the log window's visibility EVERY frame here, so hiding it once in open() lasted one frame (the
  // probe's state print read log: true mid-phase, 2026-10-07). Keep it hidden while the arena is up.
  var _Scene_Battle_updateLogWindowVisibility = Scene_Battle.prototype.updateLogWindowVisibility;
  Scene_Battle.prototype.updateLogWindowVisibility = function () {
    _Scene_Battle_updateLogWindowVisibility.call(this);
    if (this._csafBarrageArena && this._csafBarrageArena.visible) this._logWindow.visible = false;
  };

  var _Scene_Battle_terminate = Scene_Battle.prototype.terminate;
  Scene_Battle.prototype.terminate = function () {
    _Scene_Battle_terminate.call(this);
    if (Barrage.arena === this._csafBarrageArena) Barrage.arena = null;
    Barrage.running = false;
  };

  var _Game_Action_makeDamageValue = Game_Action.prototype.makeDamageValue;
  Game_Action.prototype.makeDamageValue = function (target, critical) {
    var v = _Game_Action_makeDamageValue.call(this, target, critical);
    var s = this._csafBarrageScale;
    if (s !== undefined && s !== null && target && target.isActor && target.isActor()) v = Math.round(v * s);
    return v;
  };

  var _Game_Action_itemHit = Game_Action.prototype.itemHit;
  Game_Action.prototype.itemHit = function (target) {
    if (this._csafBarrageScale === 0 && target && target.isActor && target.isActor()) return 0;  // untouched = MISS
    return _Game_Action_itemHit.call(this, target);
  };
})();
