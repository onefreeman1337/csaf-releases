//=============================================================================
// BarrageDraw.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Barrage's look: every projectile form drawn in code and baked once into one atlas. Load after BarrageCore.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * Nothing here is an image file. Each of the eighteen projectile forms (embers,
 * ice shards, sparks, droplets, pebbles, leaves, motes, wisps, blades, bones,
 * feathers, needles, stones, orbs, coins, thorns, fangs and notes) is drawn with
 * canvas paths and gradients, ONCE, into a single atlas when the first dodge
 * phase opens, so every projectile on screen shares one texture.
 *
 * Forms that have a direction (a flame's trailing tip, a feather's quill) are
 * drawn pointing right and turned to their flight by Barrage.js.
 */

var CSAF = CSAF || {};

(function () {
  'use strict';

  /** Per form: does it turn to its flight, does it spin, its pixel radius at scale 1 (mirrors BarrageCore.FORM_R). */
  var INFO = {
    ember: { turn: true, spin: false }, shard: { turn: true, spin: false }, spark: { turn: true, spin: false },
    droplet: { turn: true, spin: false }, pebble: { turn: false, spin: true }, leaf: { turn: true, spin: false, sway: true },
    mote: { turn: false, spin: true }, wisp: { turn: true, spin: false }, blade: { turn: true, spin: false },
    bone: { turn: false, spin: true }, feather: { turn: true, spin: false, sway: true }, needle: { turn: true, spin: false },
    stone: { turn: false, spin: true }, orb: { turn: false, spin: false }, coin: { turn: false, spin: false },
    thorn: { turn: true, spin: false }, fang: { turn: true, spin: false }, note: { turn: false, spin: false }
  };

  /** Seeded wobble so irregular forms (pebble, stone) are irregular but identical on every load. */
  function wob(i, salt) { var x = Math.sin(i * 12.9898 + salt * 78.233) * 43758.5453; return x - Math.floor(x); }

  function radial(ctx, r, stops) {
    var g = ctx.createRadialGradient(-r * 0.3, -r * 0.35, r * 0.1, 0, 0, r);
    for (var i = 0; i < stops.length; i++) g.addColorStop(stops[i][0], stops[i][1]);
    return g;
  }

  /** A soft halo behind a form, so a dark form still separates from the dark arena ground (Icon_Doctrine §22e). */
  function halo(ctx, r, rgb, a) {
    var g = ctx.createRadialGradient(0, 0, r * 0.2, 0, 0, r * 1.7);
    g.addColorStop(0, 'rgba(' + rgb + ',' + a + ')');
    g.addColorStop(1, 'rgba(' + rgb + ',0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(0, 0, r * 1.7, 0, Math.PI * 2); ctx.fill();
  }

  /** A teardrop: round head at +x, tip trailing at -x by `tail` radii. */
  function teardrop(ctx, r, tail) {
    ctx.beginPath();
    ctx.moveTo(-r * tail, 0);
    ctx.bezierCurveTo(-r * tail * 0.45, -r * 0.55, -r * 0.2, -r, r * 0.2, -r * 0.95);
    ctx.arc(r * 0.2, 0, r * 0.95, -Math.PI / 2, Math.PI / 2);
    ctx.bezierCurveTo(-r * 0.2, r, -r * tail * 0.45, r * 0.55, -r * tail, 0);
    ctx.closePath();
  }

  var DRAW = {
    ember: function (ctx, r) {
      halo(ctx, r, '255,140,40', 0.35);
      // a flame with a forked tail: one lick longer than the other (asymmetry, §22a)
      ctx.beginPath();
      ctx.moveTo(-r * 2.1, -r * 0.15);
      ctx.quadraticCurveTo(-r * 1.0, -r * 0.35, -r * 0.6, -r * 0.85);
      ctx.quadraticCurveTo(r * 0.2, -r * 1.05, r * 0.9, -r * 0.45);
      ctx.arc(r * 0.35, 0, r * 0.7, -Math.PI / 2.4, Math.PI / 2.4);
      ctx.quadraticCurveTo(-r * 0.3, r * 0.95, -r * 1.45, r * 0.5);
      ctx.quadraticCurveTo(-r * 0.9, r * 0.25, -r * 1.2, r * 0.05);
      ctx.closePath();
      ctx.fillStyle = radial(ctx, r * 1.2, [[0, '#fff6c8'], [0.35, '#ffc43a'], [0.75, '#ff6a1a'], [1, '#c2260e']]);
      ctx.fill();
      ctx.fillStyle = 'rgba(255,250,220,0.95)';
      ctx.beginPath(); ctx.ellipse(r * 0.35, -r * 0.05, r * 0.32, r * 0.26, 0, 0, Math.PI * 2); ctx.fill();
    },
    shard: function (ctx, r) {
      halo(ctx, r, '150,220,255', 0.25);
      ctx.beginPath();
      ctx.moveTo(r * 1.7, 0); ctx.lineTo(r * 0.2, -r * 0.75); ctx.lineTo(-r * 0.9, -r * 0.45);
      ctx.lineTo(-r * 1.3, r * 0.1); ctx.lineTo(-r * 0.4, r * 0.7); ctx.lineTo(r * 0.5, r * 0.5);
      ctx.closePath();
      var g = ctx.createLinearGradient(-r, -r, r, r);
      g.addColorStop(0, '#f2fdff'); g.addColorStop(0.5, '#8fd8f4'); g.addColorStop(1, '#2f7fa8');
      ctx.fillStyle = g; ctx.fill();
      ctx.strokeStyle = 'rgba(20,70,100,0.9)'; ctx.lineWidth = Math.max(0.9, r * 0.14); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.lineWidth = Math.max(0.8, r * 0.12);
      ctx.beginPath(); ctx.moveTo(r * 1.4, 0); ctx.lineTo(r * 0.1, -r * 0.45); ctx.stroke();
    },
    spark: function (ctx, r) {
      halo(ctx, r, '255,240,120', 0.45);
      ctx.lineJoin = 'miter';
      ctx.beginPath();
      ctx.moveTo(r * 1.6, -r * 0.2); ctx.lineTo(r * 0.3, r * 0.55); ctx.lineTo(r * 0.35, -r * 0.15);
      ctx.lineTo(-r * 0.9, r * 0.6); ctx.lineTo(-r * 0.6, -r * 0.1); ctx.lineTo(-r * 1.6, r * 0.25);
      ctx.strokeStyle = '#fff36a'; ctx.lineWidth = Math.max(1.6, r * 0.55); ctx.stroke();
      ctx.strokeStyle = '#ffffff'; ctx.lineWidth = Math.max(0.8, r * 0.22); ctx.stroke();
    },
    droplet: function (ctx, r) {
      halo(ctx, r, '90,170,255', 0.25);
      teardrop(ctx, r, 1.9);
      ctx.fillStyle = radial(ctx, r * 1.1, [[0, '#d8f1ff'], [0.4, '#5fb2f0'], [1, '#1d4f9a']]);
      ctx.fill();
      ctx.strokeStyle = 'rgba(12,40,90,0.9)'; ctx.lineWidth = Math.max(0.9, r * 0.12); ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,0.95)';
      ctx.beginPath(); ctx.ellipse(r * 0.45, -r * 0.35, r * 0.22, r * 0.14, -0.5, 0, Math.PI * 2); ctx.fill();
    },
    pebble: function (ctx, r) {
      ctx.beginPath();
      for (var i = 0; i < 9; i++) {
        var a = i / 9 * Math.PI * 2, rr = r * (0.82 + 0.22 * wob(i, 3));
        if (i === 0) ctx.moveTo(Math.cos(a) * rr, Math.sin(a) * rr * 0.85); else ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr * 0.85);
      }
      ctx.closePath();
      ctx.fillStyle = radial(ctx, r, [[0, '#e6d2b0'], [0.55, '#a88a62'], [1, '#5e4630']]); ctx.fill();
      ctx.strokeStyle = 'rgba(40,28,18,0.95)'; ctx.lineWidth = Math.max(0.9, r * 0.14); ctx.stroke();
    },
    leaf: function (ctx, r) {
      halo(ctx, r, '140,220,110', 0.2);
      ctx.beginPath();
      ctx.moveTo(r * 1.6, 0);
      ctx.bezierCurveTo(r * 0.8, -r * 1.05, -r * 0.7, -r * 0.9, -r * 1.3, 0);
      ctx.bezierCurveTo(-r * 0.6, r * 0.6, r * 0.7, r * 0.75, r * 1.6, 0);
      ctx.closePath();
      ctx.fillStyle = radial(ctx, r * 1.2, [[0, '#c8f28c'], [0.6, '#5fae3a'], [1, '#2c6a1f']]); ctx.fill();
      ctx.strokeStyle = 'rgba(20,55,15,0.95)'; ctx.lineWidth = Math.max(0.9, r * 0.12); ctx.stroke();
      ctx.strokeStyle = 'rgba(235,255,200,0.9)'; ctx.lineWidth = Math.max(0.7, r * 0.1);
      ctx.beginPath(); ctx.moveTo(-r * 1.7, r * 0.15); ctx.quadraticCurveTo(0, -r * 0.1, r * 1.4, 0); ctx.stroke();
    },
    mote: function (ctx, r) {
      halo(ctx, r, '255,245,200', 0.55);
      ctx.beginPath();
      for (var i = 0; i < 8; i++) {
        var a = i / 8 * Math.PI * 2 - Math.PI / 2, rr = i % 2 ? r * 0.32 : (i % 4 === 0 ? r * 1.35 : r * 1.0);
        ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr);
      }
      ctx.closePath();
      ctx.fillStyle = '#fffbe8'; ctx.fill();
      ctx.strokeStyle = 'rgba(230,180,60,0.9)'; ctx.lineWidth = Math.max(0.7, r * 0.12); ctx.stroke();
    },
    wisp: function (ctx, r) {
      halo(ctx, r, '170,110,255', 0.35);
      ctx.beginPath();
      ctx.moveTo(-r * 2.0, r * 0.35);
      ctx.bezierCurveTo(-r * 1.3, -r * 0.2, -r * 1.0, r * 0.6, -r * 0.5, -r * 0.6);
      ctx.arc(r * 0.2, 0, r * 0.85, -Math.PI * 0.75, Math.PI * 0.6);
      ctx.bezierCurveTo(-r * 0.4, r * 0.95, -r * 1.2, r * 0.9, -r * 2.0, r * 0.35);
      ctx.closePath();
      ctx.fillStyle = radial(ctx, r * 1.2, [[0, '#f1e0ff'], [0.45, '#9d64e8'], [1, '#3d1a73']]); ctx.fill();
      ctx.fillStyle = '#1a0b30';
      ctx.beginPath(); ctx.arc(r * 0.45, -r * 0.18, r * 0.16, 0, Math.PI * 2); ctx.arc(r * 0.05, -r * 0.22, r * 0.13, 0, Math.PI * 2); ctx.fill();
    },
    blade: function (ctx, r) {
      halo(ctx, r, '210,225,240', 0.2);
      ctx.beginPath();
      ctx.moveTo(r * 1.9, 0); ctx.lineTo(r * 0.2, -r * 0.42); ctx.lineTo(-r * 0.35, -r * 0.3);
      ctx.lineTo(-r * 0.35, r * 0.3); ctx.lineTo(r * 0.2, r * 0.42); ctx.closePath();
      var g = ctx.createLinearGradient(0, -r * 0.42, 0, r * 0.42);
      g.addColorStop(0, '#ffffff'); g.addColorStop(0.5, '#b9c8d8'); g.addColorStop(1, '#5d6e82');
      ctx.fillStyle = g; ctx.fill();
      ctx.strokeStyle = 'rgba(25,35,50,0.95)'; ctx.lineWidth = Math.max(0.9, r * 0.12); ctx.stroke();
      // the guard and the grip: a tool is read from its JOINT (§22c)
      ctx.fillStyle = '#c99a3a'; ctx.fillRect(-r * 0.55, -r * 0.62, r * 0.22, r * 1.24);
      ctx.fillStyle = '#5a3418'; ctx.fillRect(-r * 1.35, -r * 0.18, r * 0.8, r * 0.36);
    },
    bone: function (ctx, r) {
      ctx.fillStyle = '#f4ecd8'; ctx.strokeStyle = 'rgba(70,60,45,0.95)'; ctx.lineWidth = Math.max(0.9, r * 0.13);
      ctx.beginPath();
      ctx.arc(-r * 1.2, -r * 0.32, r * 0.42, 0, Math.PI * 2); ctx.arc(-r * 1.2, r * 0.32, r * 0.42, 0, Math.PI * 2);
      ctx.arc(r * 1.2, -r * 0.32, r * 0.42, 0, Math.PI * 2); ctx.arc(r * 1.2, r * 0.32, r * 0.42, 0, Math.PI * 2);
      ctx.fill(); ctx.stroke();
      ctx.fillRect(-r * 1.2, -r * 0.3, r * 2.4, r * 0.6);
      ctx.beginPath(); ctx.moveTo(-r * 1.0, -r * 0.3); ctx.lineTo(r * 1.0, -r * 0.3); ctx.moveTo(-r * 1.0, r * 0.3); ctx.lineTo(r * 1.0, r * 0.3); ctx.stroke();
    },
    feather: function (ctx, r) {
      // LOOKED 2026-10-07: a symmetric lens with notches on both sides read as a closed EYE with lashes (§22a).
      // Now: a long, CURVED, one-sided vane on a bare quill that sticks out behind it, light with a dark tip,
      // notched on the trailing edge only.
      halo(ctx, r, '200,210,230', 0.3);
      ctx.save();
      ctx.rotate(-0.12);
      ctx.beginPath();
      ctx.moveTo(r * 2.0, -r * 0.05);
      ctx.bezierCurveTo(r * 1.2, -r * 0.95, -r * 0.4, -r * 0.95, -r * 1.2, -r * 0.2);
      ctx.lineTo(-r * 0.9, r * 0.05); ctx.lineTo(-r * 0.5, -r * 0.05); ctx.lineTo(-r * 0.15, r * 0.25);
      ctx.lineTo(r * 0.25, r * 0.05); ctx.lineTo(r * 0.7, r * 0.3);
      ctx.quadraticCurveTo(r * 1.4, r * 0.25, r * 2.0, -r * 0.05);
      ctx.closePath();
      var g = ctx.createLinearGradient(-r * 1.2, 0, r * 2.0, 0);
      g.addColorStop(0, '#e9edf5'); g.addColorStop(0.6, '#9aa4b8'); g.addColorStop(1, '#2a3040');
      ctx.fillStyle = g; ctx.fill();
      ctx.strokeStyle = 'rgba(25,30,45,0.95)'; ctx.lineWidth = Math.max(0.8, r * 0.11); ctx.stroke();
      ctx.strokeStyle = '#3a3226'; ctx.lineWidth = Math.max(1, r * 0.16);
      ctx.beginPath(); ctx.moveTo(-r * 2.1, r * 0.3); ctx.quadraticCurveTo(-r * 0.2, r * 0.05, r * 1.9, -r * 0.05); ctx.stroke();
      ctx.restore();
    },
    needle: function (ctx, r) {
      halo(ctx, r, '220,230,255', 0.3);
      ctx.beginPath();
      ctx.moveTo(r * 2.4, 0); ctx.lineTo(-r * 1.6, -r * 0.32); ctx.lineTo(-r * 2.0, 0); ctx.lineTo(-r * 1.6, r * 0.32); ctx.closePath();
      ctx.fillStyle = '#dfe6f2'; ctx.fill();
      ctx.strokeStyle = 'rgba(40,50,70,0.95)'; ctx.lineWidth = Math.max(0.8, r * 0.14); ctx.stroke();
      ctx.fillStyle = '#20263a';
      ctx.beginPath(); ctx.ellipse(-r * 1.45, 0, r * 0.28, r * 0.11, 0, 0, Math.PI * 2); ctx.fill();
    },
    stone: function (ctx, r) {
      ctx.beginPath();
      var pts = 6;
      for (var i = 0; i < pts; i++) {
        var a = i / pts * Math.PI * 2 + 0.3, rr = r * (0.85 + 0.25 * wob(i, 7));
        if (i === 0) ctx.moveTo(Math.cos(a) * rr, Math.sin(a) * rr); else ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr);
      }
      ctx.closePath();
      ctx.fillStyle = radial(ctx, r * 1.1, [[0, '#d8dbe0'], [0.5, '#8b9098'], [1, '#43474f']]); ctx.fill();
      ctx.strokeStyle = 'rgba(20,22,28,0.95)'; ctx.lineWidth = Math.max(1, r * 0.13); ctx.stroke();
      ctx.strokeStyle = 'rgba(30,32,38,0.85)'; ctx.lineWidth = Math.max(0.8, r * 0.09);
      ctx.beginPath(); ctx.moveTo(-r * 0.2, -r * 0.7); ctx.lineTo(r * 0.05, -r * 0.1); ctx.lineTo(-r * 0.25, r * 0.35); ctx.stroke();
    },
    orb: function (ctx, r) {
      halo(ctx, r, '255,90,200', 0.5);
      ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2);
      ctx.fillStyle = radial(ctx, r, [[0, '#ffe0f6'], [0.35, '#ff6ad0'], [1, '#7a1062']]); ctx.fill();
      ctx.strokeStyle = 'rgba(255,200,240,0.9)'; ctx.lineWidth = Math.max(0.8, r * 0.1); ctx.stroke();
      ctx.fillStyle = '#ffffff';
      ctx.beginPath(); ctx.arc(-r * 0.35, -r * 0.4, r * 0.2, 0, Math.PI * 2); ctx.fill();
    },
    coin: function (ctx, r) {
      halo(ctx, r, '255,210,80', 0.3);
      ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2);
      ctx.fillStyle = radial(ctx, r, [[0, '#fff4b8'], [0.5, '#f0c03a'], [1, '#9a6a10']]); ctx.fill();
      ctx.strokeStyle = 'rgba(90,55,5,0.95)'; ctx.lineWidth = Math.max(0.9, r * 0.14); ctx.stroke();
      ctx.strokeStyle = 'rgba(120,80,10,0.85)'; ctx.lineWidth = Math.max(0.8, r * 0.1);
      ctx.beginPath(); ctx.arc(0, 0, r * 0.68, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = '#8a5a0a';
      ctx.beginPath(); ctx.moveTo(0, -r * 0.42); ctx.lineTo(r * 0.12, -r * 0.1); ctx.lineTo(r * 0.42, 0); ctx.lineTo(r * 0.12, r * 0.1);
      ctx.lineTo(0, r * 0.42); ctx.lineTo(-r * 0.12, r * 0.1); ctx.lineTo(-r * 0.42, 0); ctx.lineTo(-r * 0.12, -r * 0.1); ctx.closePath(); ctx.fill();
    },
    thorn: function (ctx, r) {
      // LOOKED twice, 2026-10-07: a straight wedge read as a CHIP; then a red-brown hook on a green stem read as a
      // CHILLI PEPPER in battle (colour + stem = a vegetable). A thorn is WOOD: a dark bark spike, broad at the
      // base, curving to a pale hard point, with a light rim so it separates from the dark ground. No stem.
      halo(ctx, r, '230,215,180', 0.22);
      ctx.beginPath();
      ctx.moveTo(-r * 1.3, -r * 0.85);
      ctx.quadraticCurveTo(-r * 0.2, -r * 0.55, r * 1.9, -r * 0.2);
      ctx.quadraticCurveTo(r * 0.3, r * 0.15, -r * 1.3, r * 0.85);
      ctx.quadraticCurveTo(-r * 0.95, 0, -r * 1.3, -r * 0.85);
      ctx.closePath();
      var g = ctx.createLinearGradient(-r * 1.3, 0, r * 1.9, 0);
      g.addColorStop(0, '#3a2414'); g.addColorStop(0.6, '#6b4a2c'); g.addColorStop(1, '#e8dcc0');
      ctx.fillStyle = g; ctx.fill();
      ctx.strokeStyle = 'rgba(235,222,190,0.85)'; ctx.lineWidth = Math.max(0.8, r * 0.11); ctx.stroke();
    },
    fang: function (ctx, r) {
      // LOOKED 2026-10-07: a white wedge with a red bar at its base read as a PENNANT. A canine is CURVED along
      // its whole length and its root is darker ivory, not a coloured band.
      halo(ctx, r, '255,250,235', 0.22);
      ctx.beginPath();
      ctx.moveTo(-r * 1.3, -r * 0.7);
      ctx.bezierCurveTo(-r * 0.2, -r * 0.95, r * 1.2, -r * 0.6, r * 1.9, r * 0.55);
      ctx.bezierCurveTo(r * 0.9, -r * 0.05, -r * 0.1, r * 0.2, -r * 1.3, r * 0.45);
      ctx.quadraticCurveTo(-r * 1.6, -r * 0.1, -r * 1.3, -r * 0.7);
      ctx.closePath();
      var g = ctx.createLinearGradient(-r * 1.4, 0, r * 1.9, 0);
      g.addColorStop(0, '#b8a684'); g.addColorStop(0.35, '#f3ead2'); g.addColorStop(1, '#ffffff');
      ctx.fillStyle = g; ctx.fill();
      ctx.strokeStyle = 'rgba(70,58,40,0.95)'; ctx.lineWidth = Math.max(0.9, r * 0.13); ctx.stroke();
    },
    note: function (ctx, r) {
      halo(ctx, r, '255,255,255', 0.45);
      ctx.lineWidth = Math.max(1, r * 0.2); ctx.strokeStyle = '#ffffff';
      ctx.fillStyle = '#141018';
      ctx.beginPath(); ctx.ellipse(-r * 0.35, r * 0.75, r * 0.62, r * 0.45, -0.45, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(r * 0.22, r * 0.65); ctx.lineTo(r * 0.22, -r * 1.35);
      ctx.quadraticCurveTo(r * 0.9, -r * 0.95, r * 1.05, -r * 0.35);
      ctx.strokeStyle = '#ffffff'; ctx.lineWidth = Math.max(1.6, r * 0.42); ctx.stroke();
      ctx.strokeStyle = '#141018'; ctx.lineWidth = Math.max(0.8, r * 0.2); ctx.stroke();
    }
  };

  /**
   * Draw one form centred at (0,0), pointing +x, in a 2D canvas context at pixel radius r.
   * @param {CanvasRenderingContext2D} ctx context (transform already at the cell centre)
   * @param {string} form form id
   * @param {number} r drawn radius in pixels
   * @returns {boolean} drawn
   */
  function drawForm(ctx, form, r) {
    var fn = DRAW[form];
    if (!fn) return false;
    ctx.save();
    fn(ctx, r);
    ctx.restore();
    return true;
  }

  /** The cell a form needs in the atlas: its widest reach (tails, halos) is about 2.4 r each side. */
  function cellFor(r) { return Math.ceil(r * 5.2) + 2; }

  CSAF.BarrageArt = { INFO: INFO, FORMS: Object.keys(DRAW), drawForm: drawForm, cellFor: cellFor };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.BarrageArt;
