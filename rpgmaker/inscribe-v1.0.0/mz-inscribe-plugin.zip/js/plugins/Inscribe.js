/*:
 * @target MZ
 * @plugindesc [v1.0.0] Inscribe 3/3 - name entry and riddle answers written onto an object: a register, a carved stone, stamped papers, a typed form, a sigil, a grave marker.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 * @base InscribeCore
 * @base InscribeDraw
 * @orderAfter InscribeDraw
 *
 * @param replaceNameInput
 * @text Replace Name Input Processing
 * @desc On: every Name Input Processing event opens Inscribe. Off: the stock screen stays, and only "Inscribe Next Name" or "Inscribe Name" open Inscribe.
 * @type boolean
 * @on Replace
 * @off Keep stock
 * @default true
 *
 * @param defaultRite
 * @text Default rite
 * @desc The object a name is written on when the event and the actor do not choose one. Actor notetag: <Inscribe Rite: stone>
 * @type select
 * @option register
 * @option stone
 * @option papers
 * @option typewriter
 * @option sigil
 * @option grave
 * @default register
 *
 * @param suggestions
 * @text Name suggestions
 * @desc On: the Suggest key offers new names made from the names in your own database.
 * @type boolean
 * @on On
 * @off Off
 * @default true
 *
 * @param keyboard
 * @text Type on the keyboard
 * @desc On: letters typed on a keyboard go straight onto the object; Enter finishes, Backspace erases. The drawn keys still work for pad, mouse and touch.
 * @type boolean
 * @on On
 * @off Off
 * @default true
 *
 * @param portrait
 * @text Portrait on the papers
 * @desc On: the papers rite shows the actor's face in the portrait inset. Off: a drawn silhouette.
 * @type boolean
 * @on On
 * @off Off
 * @default true
 *
 * @param letterSe
 * @text Sound: a letter
 * @desc An SE from audio/se. (None) = silent.
 * @type file
 * @dir audio/se
 * @default Cursor2
 *
 * @param backSe
 * @text Sound: erase
 * @desc An SE from audio/se. (None) = silent.
 * @type file
 * @dir audio/se
 * @default Cancel1
 *
 * @param rightSe
 * @text Sound: name sealed or answer accepted
 * @desc An SE from audio/se. (None) = silent.
 * @type file
 * @dir audio/se
 * @default Chime2
 *
 * @param wrongSe
 * @text Sound: answer refused
 * @desc An SE from audio/se. (None) = silent.
 * @type file
 * @dir audio/se
 * @default Buzzer1
 *
 * @command nextName
 * @text Inscribe Next Name
 * @desc The NEXT Name Input Processing opens Inscribe on this rite, with this heading and prompt (even when "Replace Name Input Processing" is off).
 *
 * @arg rite
 * @text Rite
 * @type select
 * @option (default)
 * @option register
 * @option stone
 * @option papers
 * @option typewriter
 * @option sigil
 * @option grave
 * @default (default)
 *
 * @arg title
 * @text Heading
 * @desc Blank = the rite's own heading.
 * @default
 *
 * @arg prompt
 * @text Prompt
 * @desc Blank = the rite's own prompt.
 * @default
 *
 * @command name
 * @text Inscribe Name
 * @desc Open Inscribe for one actor now. The event waits until the name is written.
 *
 * @arg actorId
 * @text Actor
 * @type actor
 * @default 1
 *
 * @arg maxLength
 * @text Max letters
 * @type number
 * @min 1
 * @max 24
 * @default 8
 *
 * @arg rite
 * @text Rite
 * @type select
 * @option (default)
 * @option register
 * @option stone
 * @option papers
 * @option typewriter
 * @option sigil
 * @option grave
 * @default (default)
 *
 * @arg title
 * @text Heading
 * @default
 *
 * @arg prompt
 * @text Prompt
 * @default
 *
 * @command answer
 * @text Inscribe Answer
 * @desc Ask for a written answer (a riddle, a password, a name to remember). The event waits; the result goes to a switch.
 *
 * @arg rite
 * @text Rite
 * @type select
 * @option (default)
 * @option register
 * @option stone
 * @option papers
 * @option typewriter
 * @option sigil
 * @option grave
 * @default (default)
 *
 * @arg title
 * @text Heading
 * @default
 *
 * @arg prompt
 * @text Question
 * @desc Shown on the object. Two lines fit on every rite.
 * @default
 *
 * @arg answers
 * @text Accepted answers
 * @desc One per line. Case never matters; the options below decide how forgiving the check is.
 * @type multiline_string
 * @default
 *
 * @arg typo
 * @text Typos forgiven
 * @desc Letters that may be wrong, missing, extra or swapped (never more than a third of the answer).
 * @type number
 * @min 0
 * @max 3
 * @default 1
 *
 * @arg accents
 * @text Ignore accents
 * @type boolean
 * @on Ignore
 * @off Exact
 * @default true
 *
 * @arg punctuation
 * @text Ignore punctuation
 * @type boolean
 * @on Ignore
 * @off Exact
 * @default true
 *
 * @arg attempts
 * @text Attempts
 * @desc 0 = as many as the player wants.
 * @type number
 * @min 0
 * @default 3
 *
 * @arg maxLength
 * @text Max letters
 * @type number
 * @min 1
 * @max 24
 * @default 16
 *
 * @arg reveal
 * @text Show the answer when they run out
 * @type boolean
 * @on Show
 * @off Hide
 * @default true
 *
 * @arg leave
 * @text Player may give up
 * @desc On: cancel on an empty answer leaves, unsolved.
 * @type boolean
 * @on Allowed
 * @off Not allowed
 * @default true
 *
 * @arg solvedSwitch
 * @text Switch: solved
 * @type switch
 * @default 0
 *
 * @arg attemptsVariable
 * @text Variable: attempts used
 * @type variable
 * @default 0
 *
 * @arg inputVariable
 * @text Variable: last answer typed
 * @desc Stores the text itself. Show it in a message with \V[n].
 * @type variable
 * @default 0
 *
 * @help
 * ============================================================================
 * INSCRIBE v1.0.0 - names and answers, written onto an object
 * ============================================================================
 * The stock name screen is a grid of letters in a window. Inscribe draws the
 * moment as an object being written on, in one of six rites:
 *   register    a guest register, the name signed in ink on the line
 *   stone       a slab, the name carved in V-cut letters
 *   papers      travel papers, the portrait inset, stamped by the office
 *   typewriter  a typed form, struck letters off the line
 *   sigil       the letters traced into a circle as a sigil (every name makes
 *               its own mark)
 *   grave       a headstone at night, the name carved and mossed
 * Each rite has its own drawn keys (brass plates, stone tiles, rubber stamps,
 * typewriter keys, wax seals, bone) for pad, mouse and touch, and a keyboard
 * types straight onto the object.
 *
 * INSTALLING: copy InscribeCore.js, InscribeDraw.js and Inscribe.js into
 * js/plugins and enable all three. Any order works.
 *
 * NAME ENTRY: with "Replace Name Input Processing" on (the default), the stock
 * event command opens Inscribe. Choose the rite per actor with the notetag
 * <Inscribe Rite: stone>, per event with "Inscribe Next Name", or with the
 * "Default rite" parameter. The Suggest key offers names made from the names
 * in your own database (actors, and the class, enemy and map words you wrote).
 *
 * ANSWERS: "Inscribe Answer" asks a question and checks what the player
 * writes against one or more accepted answers, forgiving case, spacing, and
 * (when you allow it) accents, punctuation and a typo or two. Right or wrong
 * is shown on the object (stamped, gilded, struck out, cracked). The result
 * goes to a switch, the attempts and the typed text to variables.
 *
 * CONTROLS: keyboard: type; Enter finishes; Backspace erases. Pad or arrows:
 * move over the keys, OK presses, Cancel erases (or gives up on an empty
 * answer, when allowed), PageUp switches to accents and digits, PageDown
 * switches case. Mouse and touch: press a key; a right click erases.
 *
 * SCRIPT CALLS:
 *   Inscribe.name({ actorId: 1, maxLength: 10, rite: 'stone' });
 *   Inscribe.answer({ prompt: 'What has keys but opens no lock?',
 *                     answers: ['piano', 'a piano'], solvedSwitch: 5 });
 *
 * COMPATIBILITY: Inscribe adds its own scene. It extends three engine methods,
 * each by saving the original and calling it: Game_Interpreter.command303
 * (the stock screen still opens when replacing is off, in battle, or in a
 * project whose language is Japanese), Game_Interpreter.updateWaitMode and
 * Game_System.initialize (its save record).
 *
 * TERMS OF USE: commercial and non-commercial use permitted in RPG Maker
 * projects, credit appreciated but not required. Do not redistribute the
 * source as an asset pack. Every line of this plugin was written with AI
 * assistance.
 */

var Inscribe = Inscribe || {};

(function (M) {
  'use strict';
  var NAME = 'Inscribe', SCHEMA = 1;
  var raw = (typeof PluginManager !== 'undefined') ? PluginManager.parameters(NAME) : {};
  function num(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; var n = Number(v); return isFinite(n) ? n : d; }
  function str(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; return String(v).trim(); }
  function bool(v, d) { if (v === true || v === false) return v; var s = str(v, ''); return s === '' ? d : s !== 'false'; }
  /** a sound parameter: (None) in the Plugin Manager is '' and means SILENT; only a key absent from plugins.js takes the
   *  default (Leadlight docs_probe B1, 2026-10-11: blank read as absent played a sound the buyer had turned off) */
  function se(v, d) { return (v === undefined || v === null) ? d : String(v).trim(); }
  var RITE_IDS = ['register', 'stone', 'papers', 'typewriter', 'sigil', 'grave'];
  function riteOf(v, d) { var s = str(v, ''); return RITE_IDS.indexOf(s) >= 0 ? s : d; }
  M.params = {
    replaceNameInput: bool(raw.replaceNameInput, true), defaultRite: riteOf(raw.defaultRite, 'register'), suggestions: bool(raw.suggestions, true),
    keyboard: bool(raw.keyboard, true), portrait: bool(raw.portrait, true),
    letterSe: se(raw.letterSe, 'Cursor2'), backSe: se(raw.backSe, 'Cancel1'), rightSe: se(raw.rightSe, 'Chime2'), wrongSe: se(raw.wrongSe, 'Buzzer1'),
  };
  /** the heading and prompt each rite shows when asking a question, when the command leaves them blank */
  M.ANSWER_TEXT = {
    register: ['The Ledger Asks', 'Write the answer upon the line'], stone: ['Speak the Word', 'Carve the answer'],
    papers: ['State Your Business', 'Enter the word you were given'], typewriter: ['Form 12: Declaration', 'Type the answer in the space provided'],
    sigil: ['The Circle Asks', 'Bind the answer into the circle'], grave: ['The Stone Asks', 'Carve the answer upon the stone'],
  };
  var _deps = null;
  /** ⛔ siblings resolved at FIRST USE, never at load time: the buyer chooses the load order (wing §8 trap 2) */
  function deps() {
    if (_deps) return _deps;
    var core = (typeof InscribeCore !== 'undefined') ? InscribeCore : null, draw = (typeof InscribeDraw !== 'undefined') ? InscribeDraw : null;
    if (!core || !draw) { if (!deps._w) { deps._w = true; console.error('Inscribe: enable InscribeCore.js and InscribeDraw.js in the Plugin Manager too.'); } return null; }
    _deps = { core: core, draw: draw }; return _deps;
  }
  M.deps = deps;
  function fresh() { return { v: SCHEMA, named: 0, asked: 0, solved: 0, next: null }; }
  M.record = function () {
    if (typeof $gameSystem === 'undefined' || !$gameSystem) return fresh();
    var s = $gameSystem._csafInscribe; if (!s || s.v == null) { s = fresh(); $gameSystem._csafInscribe = s; } return s;
  };
  var _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () { _Game_System_initialize.call(this); this._csafInscribe = fresh(); };

  /** the rite an actor's name is written on: the one-shot from "Inscribe Next Name", the actor's notetag, the parameter */
  M.riteFor = function (actorId, chosen) {
    var r = riteOf(chosen, ''); if (r) return r;
    var a = (typeof $dataActors !== 'undefined' && $dataActors) ? $dataActors[actorId] : null, m = a && a.note ? /<Inscribe Rite:\s*(\w+)\s*>/i.exec(a.note) : null;
    return riteOf(m && m[1].toLowerCase(), M.params.defaultRite);
  };
  /** answers from the editor's multiline text (one per line) or a script call's array */
  function answersOf(v) { var a = Array.isArray(v) ? v : String(v == null ? '' : v).split(/\r?\n/); return a.map(function (s) { return String(s).trim(); }).filter(function (s) { return s.length > 0; }); }
  M._open = false;
  /** a name request (strings from the editor, or plain values from a script call) */
  M.nameRequest = function (o) {
    o = o || {}; var id = Math.max(1, Math.floor(num(o.actorId, 1)));
    return { mode: 'name', actorId: id, max: Math.max(1, Math.min(24, Math.floor(num(o.maxLength != null ? o.maxLength : o.max, 8)))), rite: M.riteFor(id, o.rite), title: str(o.title, ''), prompt: str(o.prompt, ''), isRequest: true };
  };
  M.answerRequest = function (o) {
    o = o || {}; var rite = riteOf(o.rite, M.params.defaultRite);
    return { mode: 'answer', rite: rite, title: str(o.title, ''), prompt: str(o.prompt, ''), answers: answersOf(o.answers),
      typo: Math.max(0, Math.min(3, Math.floor(num(o.typo, 1)))), accents: bool(o.accents, true), punctuation: bool(o.punctuation, true),
      attempts: Math.max(0, Math.floor(num(o.attempts, 3))), max: Math.max(1, Math.min(24, Math.floor(num(o.maxLength != null ? o.maxLength : o.max, 16)))),
      reveal: bool(o.reveal, true), leave: bool(o.leave, true), solvedSwitch: Math.max(0, Math.floor(num(o.solvedSwitch, 0))),
      attemptsVariable: Math.max(0, Math.floor(num(o.attemptsVariable, 0))), inputVariable: Math.max(0, Math.floor(num(o.inputVariable, 0))), isRequest: true };
  };
  function open(req) {
    if (!req || M._open || !deps()) return false;
    if (typeof $gameParty !== 'undefined' && $gameParty && $gameParty.inBattle()) { if (!M._warnedBattle) { M._warnedBattle = true; console.warn('Inscribe: not opened during battle.'); } return false; }
    if (req.mode === 'name' && !(typeof $dataActors !== 'undefined' && $dataActors && $dataActors[req.actorId])) return false;
    // a scene that has not started yet (a map still loading its data) has no windows to stop: pushing over it throws
    // inside Scene_Map.stop (breakit X4, 2026-10-11), so refuse until it is running
    if (SceneManager._scene && SceneManager._scene.isStarted && !SceneManager._scene.isStarted()) return false;
    if (req.mode === 'answer' && !req.answers.length) { if (!M._warnedAns) { M._warnedAns = true; console.warn('Inscribe: "Inscribe Answer" has no accepted answers. Nothing opened.'); } return false; }
    M._open = true; SceneManager.push(Scene_Inscribe); SceneManager.prepareNextScene(req); return true;
  }
  M.name = function (o) { return open(o && o.isRequest ? o : M.nameRequest(o)); };
  M.answer = function (o) { return open(o && o.isRequest ? o : M.answerRequest(o)); };
  /** the next Name Input Processing opens Inscribe on this rite (kept in the save, so a save between the two holds it) */
  M.nextName = function (o) { o = o || {}; M.record().next = { rite: riteOf(o.rite, ''), title: str(o.title, ''), prompt: str(o.prompt, '') }; return true; };
  M.isOpen = function () { return M._open; };
  /** a Japanese-language project keeps the stock kana tables (Inscribe's keys are Latin) */
  // !! because Game_System.isJapanese returns the MATCH (an array or null), not a boolean (rmmz_objects.js)
  M.stockLanguage = function () { return !!(typeof $gameSystem !== 'undefined' && $gameSystem && $gameSystem.isJapanese && $gameSystem.isJapanese()); };

  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
    PluginManager.registerCommand(NAME, 'nextName', function (args) { M.nextName(args); });
    PluginManager.registerCommand(NAME, 'name', function (args) { if (M.name(M.nameRequest(args))) this.setWaitMode('inscribe'); });
    PluginManager.registerCommand(NAME, 'answer', function (args) { if (M.answer(M.answerRequest(args))) this.setWaitMode('inscribe'); });
  }
  // EXTENDS Name Input Processing: Inscribe when replacing (or a one-shot is set), the saved original otherwise
  var _command303 = Game_Interpreter.prototype.command303;
  Game_Interpreter.prototype.command303 = function (params) {
    var rec = M.record(), next = rec.next;
    if ((M.params.replaceNameInput || next) && !M.stockLanguage() && deps() && !$gameParty.inBattle() && $dataActors[params[0]]) {
      var req = M.nameRequest({ actorId: params[0], maxLength: params[1], rite: next && next.rite, title: next && next.title, prompt: next && next.prompt });
      if (open(req)) { rec.next = null; this.setWaitMode('inscribe'); return true; }
    }
    return _command303.call(this, params);
  };
  var _updateWaitMode = Game_Interpreter.prototype.updateWaitMode;
  Game_Interpreter.prototype.updateWaitMode = function () {
    if (this._waitMode === 'inscribe') { if (SceneManager._scene instanceof Scene_Inscribe || SceneManager._nextScene instanceof Scene_Inscribe) return true; this._waitMode = ''; return false; }
    return _updateWaitMode.call(this);
  };
  M.VERSION = '1.0.0';
}(Inscribe));

//=============================================================================
// Scene_Inscribe
//=============================================================================

function Scene_Inscribe() { this.initialize.apply(this, arguments); }
Scene_Inscribe.prototype = Object.create(Scene_Base.prototype);
Scene_Inscribe.prototype.constructor = Scene_Inscribe;
/** the logical stage every number here is written for; scaled to fit and centred on any screen (as Leadlight) */
Scene_Inscribe.W = 816; Scene_Inscribe.H = 624;
Scene_Inscribe.prototype.prepare = function (req) { this._req = req; };
Scene_Inscribe.prototype.create = function () {
  Scene_Base.prototype.create.call(this);
  var req = this._req, d = this._d = Inscribe.deps(), W = Scene_Inscribe.W, H = Scene_Inscribe.H, s = Math.min(Graphics.width / W, Graphics.height / H);
  this._k = s; this._ox = Math.round((Graphics.width - W * s) / 2); this._oy = Math.round((Graphics.height - H * s) / 2);
  var bg = new Sprite(new Bitmap(Graphics.width, Graphics.height)); bg.bitmap.fillAll('#0b0a0d'); this.addChild(bg);
  this._root = new Sprite(); this._root.scale.x = this._root.scale.y = s; this._root.x = this._ox; this._root.y = this._oy; this.addChild(this._root);
  this._actor = req.mode === 'name' ? $gameActors.actor(req.actorId) : null;
  this._initial = this._actor ? this._actor.name() : '';
  this._entry = d.core.entry(req.max, req.mode === 'name' ? this._initial : '');
  this._session = req.mode === 'answer' ? d.core.session({ answers: req.answers, attempts: req.attempts, typo: req.typo, accents: req.accents, punctuation: req.punctuation }) : null;
  this._seed = d.core.mix(d.core.hashString('inscribe:' + req.rite + ':' + (req.actorId || 0)), Inscribe.record().named + Inscribe.record().asked * 31);
  this._page = 'letters'; this._lower = req.mode === 'name' && this._entry.length() > 0; this._caseTouched = false; this._cur = 0; this._curX = 0; this._curY = 0; this._pressT = 0; this._t = 0;
  this._typed = []; this._mode = 'loading'; this._suggestAt = 0;
  this._face = null;
  if (req.rite === 'papers' && this._actor && Inscribe.params.portrait && this._actor.faceName()) this._faceBmp = ImageManager.loadFace(this._actor.faceName());
};
Scene_Inscribe.prototype.start = function () {
  Scene_Base.prototype.start.call(this); this.startFadeIn(this.fadeSpeed(), false);
  if (Inscribe.params.keyboard && typeof window !== 'undefined') { var self = this; this._onKey = function (e) { self.onKey(e); }; window.addEventListener('keydown', this._onKey, true); }
};
/** keyboard typing: printable keys go onto the object and never reach the engine's Input (so "z" is a letter, not OK) */
Scene_Inscribe.prototype.onKey = function (e) {
  if (this._mode !== 'input' || e.ctrlKey || e.metaKey || e.altKey || e.isComposing) return;
  var k = e.key;
  if (k === 'Enter') this._typed.push('\n');
  else if (k === 'Backspace') this._typed.push('\b');
  else if (typeof k === 'string' && Array.from(k).length === 1) this._typed.push(k);
  else return;
  e.preventDefault(); e.stopImmediatePropagation();
};
/** everything the rite draws from the buyer's own project: other actors, the class, the map, the face */
Scene_Inscribe.prototype.riteState = function () {
  var req = this._req, rec = Inscribe.record(), a = this._actor, st = { seed: this._seed, max: req.max, mode: req.mode, title: req.title || undefined, prompt: req.prompt || undefined };
  if (req.mode === 'answer') { var t = Inscribe.ANSWER_TEXT[req.rite]; st.title = req.title || t[0]; st.prompt = req.prompt || t[1]; st.prior = []; st.fields = ['Your answer', 'Remarks', 'Witness', 'Signature']; st.epitaph = ' '; return st; }
  var prior = [];
  for (var i = 1; i < $dataActors.length && prior.length < 3; i++) { if (!$dataActors[i] || i === req.actorId) continue; var nm = $gameActors._data[i] ? $gameActors._data[i].name() : $dataActors[i].name; if (nm) prior.push(nm); }
  st.prior = prior.length ? prior : null; st.entry = 11 + (rec.named % 80);
  st.occupation = a && a.currentClass() ? a.currentClass().name : '';
  st.origin = ($gameMap && $gameMap.displayName && $gameMap.displayName()) || '';
  st.face = this._face;
  return st;
};
Scene_Inscribe.prototype.build = function () {
  var D = this._d.draw, C = this._d.core, req = this._req, L = D.L, root = this._root;
  if (this._faceBmp && this._faceBmp.width > 0) {
    // crop the actor's face cell once (MZ faces are 144 x 144 cells, 4 per row)
    var fw = ImageManager.faceWidth, fh = ImageManager.faceHeight, fi = this._actor.faceIndex(), c = document.createElement('canvas'); c.width = fw; c.height = fh;
    c.getContext('2d').drawImage(this._faceBmp.canvas, (fi % 4) * fw, Math.floor(fi / 4) * fh, fw, fh, 0, 0, fw, fh); this._face = c;
  }
  this._st = this.riteState();
  this._base = new Sprite(new Bitmap(L.W, L.RH)); D.base(this._base.bitmap.context, req.rite, this._st); this._base.bitmap._baseTexture.update(); root.addChild(this._base);
  this._text = new Sprite(new Bitmap(L.W, L.RH)); root.addChild(this._text);
  this._verdict = new Sprite(new Bitmap(L.W, L.RH)); this._verdict.anchor.x = this._verdict.anchor.y = 0.5; this._verdict.x = L.W / 2; this._verdict.y = L.RH / 2; this._verdict.visible = false; root.addChild(this._verdict);
  this._tray = new Sprite(new Bitmap(L.W, L.TH)); this._tray.y = L.RH; root.addChild(this._tray);
  var k0 = D.KEYS[0], kf = D.KEYS[30], self = this;
  this._curBmp = [k0, kf].map(function (k) { var b = new Bitmap(k.w + 12, k.h + 12); D.cursor(b.context, req.rite, k.w, k.h); b._baseTexture.update(); return b; });
  // the pressed key: the tray's own pixels for that key, sunk 3 px and darkened by TINT (LOOKED AT 2026-10-11: a colour
  // tone filter on a sub-frame sprite drew a dark sliver beside the key instead of darkening it)
  this._press = new Sprite(this._tray.bitmap); this._press.visible = false; this._press.tint = 0x8c8c8c; root.addChild(this._press);
  this._cursor = new Sprite(this._curBmp[0]); root.addChild(this._cursor);
  this._suggest = (req.mode === 'name' && Inscribe.params.suggestions) ? C.namer(C.databaseNames({ actors: $dataActors, classes: $dataClasses, enemies: $dataEnemies, mapInfos: $dataMapInfos }), req.rite).suggest(12, this._seed, { max: Math.min(8, req.max), min: Math.min(4, req.max) }) : [];
  this.redrawText(); this.redrawTray(); this.placeCursor(true);
  this._mode = 'input'; self._t = 0;
};
Scene_Inscribe.prototype.redrawText = function () {
  var b = this._text.bitmap; b.clear(); var st = this._st; st.text = this._entry.text(); st.caret = this._mode !== 'verdict' || this._verdictKind !== 'reveal'; st.gilt = this._gilt === true;
  this._ext = this._d.draw.text(b.context, this._req.rite, st); b._baseTexture.update();
};
Scene_Inscribe.prototype.redrawTray = function () {
  var b = this._tray.bitmap; b.clear(); var st = this._st; st.page = this._page; st.lower = this._lower;
  this._labels = this._d.core.page(this._page, this._lower); this._d.draw.tray(b.context, this._req.rite, this._labels, st); b._baseTexture.update();
};
/** the cursor glides to its key (a few frames of easing); `snap` puts it there at once */
Scene_Inscribe.prototype.placeCursor = function (snap) {
  var k = this._d.draw.KEYS[this._cur], L = this._d.draw.L; this._cursor.bitmap = this._curBmp[k.kind === 'fn' ? 1 : 0];
  this._curTX = k.x - 6; this._curTY = L.RH + k.y - 6; if (snap) { this._curX = this._curTX; this._curY = this._curTY; }
};
Scene_Inscribe.prototype.update = function () {
  Scene_Base.prototype.update.call(this);
  if (this._mode === 'loading') { if (!this._faceBmp || this._faceBmp.isReady()) this.build(); return; }
  this._t++;
  if (this._mode === 'input') this.updateInput();
  else if (this._mode === 'verdict') this.updateVerdict();
  // the cursor eases toward its key and breathes; the pressed key sinks for six frames. No allocation.
  this._curX += (this._curTX - this._curX) * 0.35; this._curY += (this._curTY - this._curY) * 0.35;
  this._cursor.x = Math.round(this._curX); this._cursor.y = Math.round(this._curY); this._cursor.opacity = this._mode === 'input' ? 190 + Math.round(Math.sin(this._t * 0.08) * 60) : 0;
  if (this._pressT > 0) { this._pressT--; if (this._pressT === 0) this._press.visible = false; }
};
Scene_Inscribe.prototype.updateInput = function () {
  var D = this._d.draw;
  while (this._typed.length) { var c = this._typed.shift(); if (c === '\n') { this.finish(); return; } if (c === '\b') this.back(); else this.typeChar(c, -1); if (this._mode !== 'input') return; }
  // pointer: hover moves the cursor, a press presses the key under it, a right click erases
  var sx = (TouchInput.x - this._ox) / this._k, sy = (TouchInput.y - this._oy) / this._k - D.L.RH, hit = sy >= 0 ? D.keyAt(sx, sy) : -1;
  if (TouchInput.isTriggered()) { if (hit >= 0) { this._cur = hit; this.placeCursor(false); this.pressKey(hit); } return; }
  if (TouchInput.isCancelled()) { this.cancel(); return; }
  if (hit >= 0 && hit !== this._cur && (TouchInput.isMoved() || (TouchInput.isHovered && TouchInput.isHovered()))) { this._cur = hit; this.placeCursor(false); }
  // pad and arrows
  if (Input.isRepeated('right')) this.moveCursor(1, 0); else if (Input.isRepeated('left')) this.moveCursor(-1, 0);
  else if (Input.isRepeated('down')) this.moveCursor(0, 1); else if (Input.isRepeated('up')) this.moveCursor(0, -1);
  if (Input.isTriggered('ok')) this.pressKey(this._cur);
  else if (Input.isRepeated('cancel')) this.cancel();
  else if (Input.isTriggered('pageup')) this.pressKey(31);
  // not 'shift': a typist holds Shift for every capital, and the drawn case would flip under them
  else if (Input.isTriggered('pagedown')) this.pressKey(30);
};
/** the grid: three rows of ten, then five function keys under them (two character columns to each) */
Scene_Inscribe.prototype.moveCursor = function (dx, dy) {
  var k = this._d.draw.KEYS[this._cur], row = k.row, col = k.col;
  if (dx) { var n = row === 3 ? 5 : 10; col = (col + dx + n) % n; }
  if (dy) { var nr = (row + dy + 4) % 4; col = nr === 3 ? Math.floor(col / 2) : (row === 3 ? col * 2 : col); row = nr; }
  this._cur = row === 3 ? 30 + col : row * 10 + col; this.placeCursor(false); SoundManager.playCursor();
};
Scene_Inscribe.prototype.sink = function (i) { var k = this._d.draw.KEYS[i]; this._press.setFrame(k.x - 2, k.y - 2, k.w + 4, k.h + 6); this._press.x = k.x - 2; this._press.y = this._d.draw.L.RH + k.y + 1; this._press.visible = true; this._pressT = 6; };
Scene_Inscribe.prototype.pressKey = function (i) {
  var k = this._d.draw.KEYS[i]; this.sink(i);
  if (k.kind === 'char') { this.typeChar(this._labels[k.i], i); return; }
  if (k.fn === 'case') { this._lower = !this._lower; this._caseTouched = true; this.redrawTray(); this.playSe(Inscribe.params.letterSe, 60); }
  else if (k.fn === 'page') { this._page = this._page === 'letters' ? 'marks' : 'letters'; this.redrawTray(); this.playSe(Inscribe.params.letterSe, 60); }
  else if (k.fn === 'extra') this.extra();
  else if (k.fn === 'back') this.back();
  else if (k.fn === 'done') this.finish();
};
Scene_Inscribe.prototype.playSe = function (name, vol) { if (name) AudioManager.playSe({ name: name, volume: vol, pitch: 100, pan: 0 }); };
Scene_Inscribe.prototype.typeChar = function (ch, keyIndex) {
  if (!this._entry.insert(ch)) { SoundManager.playBuzzer(); return; }
  this.playSe(Inscribe.params.letterSe, 70);
  // the first capital, then lower case, as a name is written (unless the player chose a case themselves)
  if (this._req.mode === 'name' && this._page === 'letters' && !this._lower && !this._caseTouched && this._entry.length() === 1) { this._lower = true; this.redrawTray(); }
  this.redrawText();
};
Scene_Inscribe.prototype.back = function () {
  if (!this._entry.back()) { SoundManager.playBuzzer(); return; }
  this.playSe(Inscribe.params.backSe, 60);
  if (this._req.mode === 'name' && this._entry.length() === 0 && !this._caseTouched && this._lower) { this._lower = false; this.redrawTray(); }
  this.redrawText();
};
Scene_Inscribe.prototype.cancel = function () {
  if (this._entry.length()) { this.back(); return; }
  if (this._req.mode === 'answer' && this._req.leave) { this.playSe(Inscribe.params.backSe, 60); this.results(false); return; }
  SoundManager.playBuzzer();
};
/** Suggest (name): the next generated name; Clear (answer): an empty line */
Scene_Inscribe.prototype.extra = function () {
  if (this._req.mode === 'answer') { this._entry.clear(); this.redrawText(); this.playSe(Inscribe.params.backSe, 60); return; }
  if (!this._suggest.length) { SoundManager.playBuzzer(); return; }
  var s = this._suggest[this._suggestAt % this._suggest.length]; this._suggestAt++;
  this._entry.clear(); Array.from(s).forEach(function (c) { this._entry.insert(c); }, this);
  this._lower = true; this.redrawTray(); this.redrawText(); this.playSe(Inscribe.params.letterSe, 80);
};
Scene_Inscribe.prototype.showVerdict = function (kind, frames) {
  var b = this._verdict.bitmap; this._verdictKind = kind; this._gilt = kind === 'right'; this._mode = 'verdict'; this._vt = 0; this._vlen = frames;
  this.redrawText(); b.clear(); this._st.verdict = kind; this._d.draw.verdict(b.context, this._req.rite, this._st, this._ext); this._st.verdict = undefined; b._baseTexture.update();
  this._verdict.visible = true; this._verdict.opacity = 0; this._verdict.scale.x = this._verdict.scale.y = 1.06;
};
Scene_Inscribe.prototype.updateVerdict = function () {
  this._vt++; var v = this._verdict, p = Math.min(1, this._vt / 10); v.opacity = Math.round(255 * p); v.scale.x = v.scale.y = 1 + 0.06 * (1 - p);
  if (this._vt >= this._vlen) this.afterVerdict();
};
Scene_Inscribe.prototype.finish = function () {
  var req = this._req, text = this._entry.text();
  if (req.mode === 'name') {
    if (!text.trim()) { if (this._initial) { this._entry.clear(); Array.from(this._initial).forEach(function (c) { this._entry.insert(c); }, this); } else { SoundManager.playBuzzer(); return; } }
    this.playSe(Inscribe.params.rightSe, 80); this.showVerdict('right', 54); return;
  }
  if (!text.trim()) { SoundManager.playBuzzer(); return; }
  var r = this._session.submit(text);
  if (r.ok) { this.playSe(Inscribe.params.rightSe, 85); this.showVerdict('right', 60); }
  else { this.playSe(Inscribe.params.wrongSe, 85); this.showVerdict('wrong', 50); }
};
Scene_Inscribe.prototype.afterVerdict = function () {
  var req = this._req, kind = this._verdictKind;
  if (req.mode === 'name') { this._actor.setName(this._entry.text()); Inscribe.record().named++; this.leave(); return; }
  if (kind === 'right') { this.results(true); return; }
  if (kind === 'reveal') { this.results(false); return; }
  if (this._session.over) {
    // the revealed answer is written whole, even when it is longer than the player's letter limit
    if (req.reveal) { this._entry = this._d.core.entry(Math.max(req.max, Array.from(req.answers[0]).length), req.answers[0]); this._verdict.visible = false; this._gilt = false; this.showVerdict('reveal', 80); return; }
    this.results(false); return;
  }
  // attempts remain: the struck line is cleared for another try
  this._verdict.visible = false; this._gilt = false; this._entry.clear(); this._mode = 'input'; this.redrawText();
};
Scene_Inscribe.prototype.results = function (solved) {
  var req = this._req, rec = Inscribe.record(), s = this._session;
  if (req.solvedSwitch > 0) $gameSwitches.setValue(req.solvedSwitch, solved);
  if (req.attemptsVariable > 0) $gameVariables.setValue(req.attemptsVariable, s.used);
  if (req.inputVariable > 0) $gameVariables.setValue(req.inputVariable, s.last == null ? '' : s.last);
  rec.asked++; if (solved) rec.solved++;
  this._solved = solved; this.leave();
};
Scene_Inscribe.prototype.leave = function () { if (this._mode === 'leaving') return; this._mode = 'leaving'; this.popScene(); };
Scene_Inscribe.prototype.stop = function () { Scene_Base.prototype.stop.call(this); this.startFadeOut(this.fadeSpeed(), false); };
Scene_Inscribe.prototype.terminate = function () {
  Scene_Base.prototype.terminate.call(this); Inscribe._open = false;
  if (this._onKey) { window.removeEventListener('keydown', this._onKey, true); this._onKey = null; }
};
