/*:
 * @target MZ
 * @plugindesc [v1.0.0] Inscribe 2/3 - the look: each rite drawn as an object (a register signed in ink, a name carved in stone, ...). No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * InscribeDraw.js draws the rites Inscribe shows and touches no part of the engine. Turn it on together with
 * InscribeCore.js and Inscribe.js; the order does not matter. See Readme_for_Users.md.
 */
/* InscribeDraw - canvas drawing only (2D context), no engine code; runs in a plain page for the contact sheets and in MZ.
 * Every layer is drawn when its state changes, never per frame. Copyright (c) 2026 Core Systems Asset Factory.
 *
 * The stage is 816 x 624: the RITE (the object being written on) fills the top 816 x 424, the TRAY (the drawn keys, in
 * the rite's own material) fills the bottom 816 x 200. Four layers, each its own canvas:
 *   base(ctx, rite, st)            the object and its ground, drawn once per scene
 *   text(ctx, rite, st) -> ext     the name or answer and the tool that writes it (transparent; redrawn on each letter)
 *   verdict(ctx, rite, st, ext)    accepted / refused / revealed marks (transparent)
 *   tray(ctx, rite, labels, st)    the keys
 */
var InscribeDraw = (function () {
  'use strict';
  /** typeface stacks per hand: system faces only (no font ships, no stock MZ face, wing §15a) */
  var FACES = {
    ink: '"Segoe Script", "Lucida Handwriting", "Brush Script MT", cursive',
    chisel: '"Palatino Linotype", "Book Antiqua", Palatino, Georgia, serif',
    label: '"Palatino Linotype", "Book Antiqua", Palatino, Georgia, serif',
    type: '"Courier New", Courier, "Lucida Console", monospace',
  };
  var L = { W: 816, H: 624, RH: 424, TH: 200 };
  function rng(seed) { var s = seed >>> 0 || 1; return function () { s = (s + 0x6D2B79F5) | 0; var t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function chars(s) { return Array.from(String(s || '')); }
  /** fit a run of text to a width by shrinking the size down to a floor; `spacing` is the letter spacing the caller draws
   *  with (LOOKED AT 2026-10-11: a 20-letter name carved with 8 px spacing ran off the slab because the fit measured the bare word) */
  function fitSize(ctx, text, face, weight, size, minSize, maxW, spacing) { var s = size, n = chars(text).length, sp = spacing || 0; ctx.font = weight + ' ' + s + 'px ' + face; while (s > minSize && ctx.measureText(text).width + sp * n > maxW) { s -= 1; ctx.font = weight + ' ' + s + 'px ' + face; } return s; }
  /** break a prompt into at most `max` lines that fit `maxW` with the current font; the last line is ellipsised if the
   *  rest does not fit (a riddle's question lives in the prompt, so it must never run off the object) */
  // `spacing` is the letter spacing the caller draws with (LOOKED AT 2026-10-11: a carved two-line riddle measured
  // without its 4 px spacing ran past both edges of the slab, the fitSize defect again)
  function wrap(ctx, text, maxW, max, spacing) {
    var sp = spacing || 0, wd = function (t) { return ctx.measureText(t).width + sp * chars(t).length; };
    var words = String(text || '').split(/\s+/).filter(Boolean), lines = [], line = '';
    for (var i = 0; i < words.length; i++) { var t = line ? line + ' ' + words[i] : words[i]; if (wd(t) > maxW && line) { lines.push(line); line = words[i]; } else line = t; }
    if (line) lines.push(line);
    if (lines.length > max) { var last = lines.slice(max - 1).join(' '); while (last.length > 1 && wd(last + '…') > maxW) last = last.slice(0, -1); lines = lines.slice(0, max - 1).concat([last + '…']); }
    return lines;
  }
  function wrapped(ctx, text, x, y, maxW, max, lh) { var ls = wrap(ctx, text, maxW, max); for (var i = 0; i < ls.length; i++) ctx.fillText(ls[i], x, y + i * lh); return ls.length; }
  function rr(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r); ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h); ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r); ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.closePath(); }
  /** a word stamped in a ring or a box, worn, on its own canvas (LOOKED AT: wearing with destination-out on the page punched
   *  holes through the paper to the background) */
  function stampBox(word, colour, r, angle, seed) {
    var c = document.createElement('canvas'), x = c.getContext('2d'), rnd = rng(seed || 5);
    x.font = 'bold 30px ' + FACES.label; var w = Math.ceil(x.measureText(word).width) + 44; c.width = w + 40; c.height = 110;
    x.translate(c.width / 2, c.height / 2); x.rotate(angle);
    x.strokeStyle = colour; x.lineWidth = 4; rr(x, -w / 2, -26, w, 52, 6); x.stroke(); x.lineWidth = 1.5; rr(x, -w / 2 + 6, -20, w - 12, 40, 4); x.stroke();
    x.fillStyle = colour; x.textAlign = 'center'; x.textBaseline = 'middle'; x.font = 'bold 30px ' + FACES.label; x.fillText(word, 0, 2);
    x.setTransform(1, 0, 0, 1, 0, 0); x.globalCompositeOperation = 'destination-out';
    for (var k = 0; k < 90; k++) { x.fillStyle = 'rgba(0,0,0,' + (0.25 + rnd() * 0.55) + ')'; x.beginPath(); x.arc(rnd() * c.width, rnd() * c.height, 0.8 + rnd() * 2.6, 0, Math.PI * 2); x.fill(); }
    return c;
  }

  // ============================================================================================================== REGISTER
  var register = {
    geo: function (W, H) { var x0 = 96, y0 = 20, pw = 624, ph = 384, lx0 = x0 + 46, lx1 = x0 + pw - 46; return { x0: x0, y0: y0, pw: pw, ph: ph, lx0: lx0, lx1: lx1, nx: lx0 + 96, line: function (i) { return y0 + 112 + i * 46; }, nameRow: 3 }; },
    base: function (ctx, W, H, st) {
      var g = this.geo(W, H), r = rng(st.seed || 7);
      var dg = ctx.createLinearGradient(0, 0, 0, H); dg.addColorStop(0, '#3a2618'); dg.addColorStop(1, '#22150d'); ctx.fillStyle = dg; ctx.fillRect(0, 0, W, H);
      for (var q = 0; q < 70; q++) { ctx.strokeStyle = 'rgba(0,0,0,' + (0.06 + r() * 0.08) + ')'; ctx.lineWidth = 1 + r() * 2; ctx.beginPath(); var gy = r() * H; ctx.moveTo(0, gy); ctx.bezierCurveTo(W * 0.3, gy + (r() - 0.5) * 20, W * 0.7, gy + (r() - 0.5) * 20, W, gy + (r() - 0.5) * 12); ctx.stroke(); }
      ctx.save(); ctx.shadowColor = 'rgba(0,0,0,0.55)'; ctx.shadowBlur = 24; ctx.shadowOffsetY = 8; ctx.fillStyle = '#e9dcbc'; ctx.fillRect(g.x0, g.y0, g.pw, g.ph); ctx.restore();
      var pg = ctx.createRadialGradient(g.x0 + g.pw * 0.5, g.y0 + g.ph * 0.45, g.pw * 0.1, g.x0 + g.pw * 0.5, g.y0 + g.ph * 0.5, g.pw * 0.75); pg.addColorStop(0, '#f1e6c8'); pg.addColorStop(1, '#cdb88c'); ctx.fillStyle = pg; ctx.fillRect(g.x0, g.y0, g.pw, g.ph);
      for (var f = 0; f < 900; f++) { var fx = g.x0 + r() * g.pw, fy = g.y0 + r() * g.ph, a = r() * Math.PI; ctx.strokeStyle = r() < 0.5 ? 'rgba(120,90,50,0.10)' : 'rgba(255,250,235,0.18)'; ctx.lineWidth = 0.7; ctx.beginPath(); ctx.moveTo(fx, fy); ctx.lineTo(fx + Math.cos(a) * (3 + r() * 6), fy + Math.sin(a) * (3 + r() * 6)); ctx.stroke(); }
      // the gutter shadow of the open book along the left edge
      var gs = ctx.createLinearGradient(g.x0, 0, g.x0 + 40, 0); gs.addColorStop(0, 'rgba(90,60,30,0.35)'); gs.addColorStop(1, 'rgba(90,60,30,0)'); ctx.fillStyle = gs; ctx.fillRect(g.x0, g.y0, 40, g.ph);
      ctx.fillStyle = '#5a3a1e'; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
      ctx.font = 'bold 28px ' + FACES.label; ctx.fillText(st.title || 'Register of Arrivals', W / 2, g.y0 + 46);
      ctx.font = 'italic 17px ' + FACES.label; ctx.fillStyle = '#7a5a36'; wrapped(ctx, st.prompt || 'Sign your name upon the line', W / 2, g.y0 + 72, 540, st.prior && !st.prior.length ? 2 : 1, 21);
      for (var i = 0; i < 6; i++) { var ly = g.line(i); ctx.strokeStyle = i === g.nameRow ? 'rgba(120,40,30,0.75)' : 'rgba(70,90,140,0.35)'; ctx.lineWidth = i === g.nameRow ? 1.6 : 1; ctx.beginPath(); ctx.moveTo(g.lx0, ly); ctx.lineTo(g.lx1, ly); ctx.stroke(); }
      ctx.strokeStyle = 'rgba(160,50,40,0.45)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(g.nx - 14, g.y0 + 84); ctx.lineTo(g.nx - 14, g.y0 + g.ph - 34); ctx.stroke();
      // earlier entries in faded ink: the buyer's other actors (the register is a used book); an EMPTY list (answer mode)
      // leaves the lines blank so a two-line question has room
      var prior = st.prior ? st.prior : ['Aldous Wray', 'M. Corvanne', 'Tobias Venn'];
      ctx.textAlign = 'left';
      for (var p = 0; p < g.nameRow && prior.length; p++) { var py = g.line(p) - 7; ctx.font = '22px ' + FACES.ink; ctx.fillStyle = 'rgba(60,45,40,' + (0.38 + 0.1 * p) + ')'; ctx.fillText(prior[p % prior.length], g.nx, py, g.lx1 - g.nx - 10); ctx.font = '14px ' + FACES.label; ctx.fillStyle = 'rgba(80,60,40,0.55)'; ctx.fillText(String((st.entry || 11) + p), g.lx0 + 4, py); }
      ctx.font = '14px ' + FACES.label; ctx.fillStyle = 'rgba(80,60,40,0.75)'; ctx.fillText(String((st.entry || 11) + g.nameRow), g.lx0 + 4, g.line(g.nameRow) - 7);
    },
    text: function (ctx, W, H, st) {
      var g = this.geo(W, H), r = rng((st.seed || 7) ^ 0x51ED), text = st.text || '', ny = g.line(g.nameRow) - 8, nx = g.nx;
      var size = fitSize(ctx, text || 'M', FACES.ink, '', 38, 20, g.lx1 - nx - 60);
      ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic'; ctx.font = size + 'px ' + FACES.ink; ctx.fillStyle = '#1d1a2e'; ctx.fillText(text, nx, ny);
      ctx.save(); ctx.globalAlpha = 0.35; ctx.fillText(text, nx + 0.6, ny + 0.4); ctx.restore();
      // ink pooled where a stroke starts
      var cx = nx, cs = chars(text); for (var c = 0; c < cs.length; c++) { var cw = ctx.measureText(cs[c]).width; if (/[A-Za-z]/.test(cs[c]) && r() < 0.5) { ctx.fillStyle = 'rgba(20,18,40,0.55)'; ctx.beginPath(); ctx.arc(cx + cw * 0.2, ny - size * (0.3 + r() * 0.3), 1.2 + r() * 1.6, 0, Math.PI * 2); ctx.fill(); } cx += cw; }
      var end = nx + ctx.measureText(text).width;
      // the quill: its nib just past the last stroke, leaning AWAY from the writing (LOOKED AT: at +6 px, or rotated -0.85,
      // the feather lay across the last letter). On an EMPTY line it rests along the line instead of standing up through
      // the entry above (LOOKED AT 2026-10-11, the open defect of the first session)
      if (st.caret !== false) {
        var Lq = 82, lean = text ? 1.1 : 1.32, qx = text ? end + 10 : nx + 8;
        ctx.save(); ctx.translate(qx, ny - 2); ctx.rotate(lean);
        var qg = ctx.createLinearGradient(0, 0, 0, -Lq); qg.addColorStop(0, '#f6f1e4'); qg.addColorStop(1, '#bfb49b'); ctx.fillStyle = qg;
        ctx.beginPath(); ctx.moveTo(0, 0); ctx.quadraticCurveTo(15, -Lq * 0.5, 5, -Lq); ctx.quadraticCurveTo(-8, -Lq * 0.5, 0, 0); ctx.fill();
        ctx.strokeStyle = 'rgba(90,80,60,0.6)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(4, -Lq * 0.97); ctx.stroke();
        ctx.fillStyle = '#1d1a2e'; ctx.beginPath(); ctx.moveTo(-1.5, 0); ctx.lineTo(1.5, 0); ctx.lineTo(0, 5); ctx.fill(); ctx.restore();
      }
      ctx.textAlign = 'right'; ctx.font = 'italic 15px ' + FACES.label; ctx.fillStyle = '#7a5a36';
      var left = st.max - cs.length; ctx.fillText(left === 1 ? '1 letter remains' : left + ' letters remain', g.lx1, g.y0 + g.ph - 14);
      return { x0: nx, x1: end, y: ny, size: size };
    },
    verdict: function (ctx, W, H, st, e) {
      var g = this.geo(W, H), r = rng((st.seed || 7) ^ 0xBEEF);
      if (st.verdict === 'right') {
        // a flourish under the name, two strokes in the same ink, and a tick in the margin
        ctx.strokeStyle = 'rgba(29,26,46,0.85)'; ctx.lineWidth = 2.2; ctx.lineCap = 'round';
        for (var k = 0; k < 2; k++) { var yy = e.y + 8 + k * 6; ctx.beginPath(); ctx.moveTo(e.x0 - 4, yy + 2); ctx.bezierCurveTo(e.x0 + (e.x1 - e.x0) * 0.3, yy - 5, e.x0 + (e.x1 - e.x0) * 0.7, yy + 7, e.x1 + 24, yy - 6 + k * 4); ctx.stroke(); ctx.lineWidth = 1.4; }
        ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(40,90,50,0.85)'; ctx.beginPath(); ctx.moveTo(g.lx0 + 30, e.y - 12); ctx.lineTo(g.lx0 + 38, e.y - 4); ctx.lineTo(g.lx0 + 54, e.y - 24); ctx.stroke();
      } else if (st.verdict === 'wrong') {
        ctx.strokeStyle = 'rgba(150,30,30,0.85)'; ctx.lineWidth = 2.6; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(e.x0 - 6, e.y - e.size * 0.3 + 2); ctx.lineTo(Math.max(e.x1, e.x0 + 40) + 6, e.y - e.size * 0.36 - 1); ctx.stroke();
        ctx.lineWidth = 2.2; var mx = g.lx0 + 40, my = e.y - 14; ctx.beginPath(); ctx.moveTo(mx - 8, my - 8); ctx.lineTo(mx + 8, my + 8); ctx.moveTo(mx + 8, my - 8); ctx.lineTo(mx - 8, my + 8); ctx.stroke();
        for (var b = 0; b < 3; b++) { ctx.fillStyle = 'rgba(150,30,30,' + (0.3 + r() * 0.3) + ')'; ctx.beginPath(); ctx.arc(e.x1 + 12 + r() * 10, e.y - 8 + r() * 8, 1 + r() * 2, 0, Math.PI * 2); ctx.fill(); }
      } else if (st.verdict === 'reveal') {
        ctx.textAlign = 'right'; ctx.font = 'italic 15px ' + FACES.label; ctx.fillStyle = 'rgba(120,40,30,0.85)'; ctx.fillText('the answer, in the clerk\'s hand', g.lx1, e.y + 30);
      }
    },
  };

  // ================================================================================================================= STONE
  function carve(ctx, text, x, y, size, spacing, tone) {
    ctx.font = 'bold ' + size + 'px ' + FACES.chisel; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
    var hasLS = ctx.letterSpacing !== undefined; if (hasLS) ctx.letterSpacing = spacing + 'px';
    ctx.fillStyle = tone && tone.lit || 'rgba(245,240,225,0.40)'; ctx.fillText(text, x + 1.4, y + 1.6);   // the lit lower-right wall of the cut
    ctx.fillStyle = tone && tone.shade || 'rgba(28,26,24,0.85)'; ctx.fillText(text, x - 0.8, y - 0.8);    // the shadowed floor
    ctx.fillStyle = tone && tone.floor || 'rgba(70,66,60,0.9)'; ctx.fillText(text, x, y);
    if (hasLS) ctx.letterSpacing = '0px';
  }
  function carvedWidth(ctx, text, size, spacing) { ctx.font = 'bold ' + size + 'px ' + FACES.chisel; return ctx.measureText(text).width + spacing * chars(text).length; }
  var stone = {
    geo: function () { return { sx: 114, sy: 34, sw: 588, sh: 340, nameY: 34 + 196 }; },
    base: function (ctx, W, H, st) {
      var g = this.geo(), r = rng(st.seed || 11);
      var bg = ctx.createRadialGradient(W / 2, H * 0.45, 40, W / 2, H / 2, W * 0.8); bg.addColorStop(0, '#2b2f36'); bg.addColorStop(1, '#0e1013'); ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
      ctx.save(); ctx.shadowColor = 'rgba(0,0,0,0.7)'; ctx.shadowBlur = 30; ctx.shadowOffsetY = 12; ctx.fillStyle = '#7d7a72'; ctx.fillRect(g.sx, g.sy, g.sw, g.sh); ctx.restore();
      var sg = ctx.createLinearGradient(g.sx, g.sy, g.sx + g.sw, g.sy + g.sh); sg.addColorStop(0, '#9b978c'); sg.addColorStop(1, '#5f5c55'); ctx.fillStyle = sg; ctx.fillRect(g.sx, g.sy, g.sw, g.sh);
      for (var m = 0; m < 1600; m++) { var mx = g.sx + r() * g.sw, my = g.sy + r() * g.sh, mr = 0.5 + r() * 2.2; ctx.fillStyle = r() < 0.5 ? 'rgba(40,38,34,' + (0.08 + r() * 0.12) + ')' : 'rgba(235,230,215,' + (0.06 + r() * 0.1) + ')'; ctx.beginPath(); ctx.arc(mx, my, mr, 0, Math.PI * 2); ctx.fill(); }
      var bev = 10; ctx.fillStyle = 'rgba(255,250,235,0.22)'; ctx.fillRect(g.sx, g.sy, g.sw, bev); ctx.fillRect(g.sx, g.sy, bev, g.sh); ctx.fillStyle = 'rgba(0,0,0,0.32)'; ctx.fillRect(g.sx, g.sy + g.sh - bev, g.sw, bev); ctx.fillRect(g.sx + g.sw - bev, g.sy, bev, g.sh);
      var cut = function (x, y, w, h) { ctx.strokeStyle = 'rgba(25,24,22,0.75)'; ctx.lineWidth = 3; ctx.strokeRect(x + 1, y + 1, w, h); ctx.strokeStyle = 'rgba(245,240,225,0.35)'; ctx.lineWidth = 1.5; ctx.strokeRect(x - 0.5, y - 0.5, w, h); };
      cut(g.sx + 26, g.sy + 24, g.sw - 52, g.sh - 48);
      carve(ctx, (st.title || 'Here Stands').toUpperCase(), W / 2, g.sy + 86, 24, 6);
      ctx.font = 'bold 17px ' + FACES.chisel; var pl = wrap(ctx, (st.prompt || 'Carve your name').toUpperCase(), 480, 2, 4);
      for (var pi = 0; pi < pl.length; pi++) carve(ctx, pl[pi], W / 2, g.sy + g.sh - 66 + pi * 24 - (pl.length - 1) * 8, 17, 4);
    },
    text: function (ctx, W, H, st) {
      var g = this.geo(), r = rng((st.seed || 11) ^ 0x51ED), text = (st.text || '').toUpperCase();
      var size = fitSize(ctx, text || 'M', FACES.chisel, 'bold', 58, 26, g.sw - 120, 8);
      carve(ctx, text, W / 2, g.nameY, size, 8, st.gilt ? { lit: 'rgba(255,240,190,0.55)', shade: 'rgba(60,40,10,0.9)', floor: 'rgba(196,150,60,0.95)' } : null);
      var half = carvedWidth(ctx, text, size, 8) / 2, x0 = W / 2 - half, ex = Math.min(g.sx + g.sw - 34, W / 2 + half + 4), ey = g.nameY;
      // chips and dust spilling from the end of the cut, kept on the slab (LOOKED AT: they floated a chisel's length away;
      // after a 20-letter name the chisel hung past the slab's edge)
      if (st.caret !== false) {
        for (var k = 0; k < 14; k++) { ctx.fillStyle = 'rgba(200,195,180,' + (0.4 + r() * 0.4) + ')'; var kx = ex + (r() - 0.5) * 22, ky = ey + 2 + r() * 18; ctx.beginPath(); ctx.moveTo(kx, ky); ctx.lineTo(kx + 2 + r() * 4, ky + 1 + r() * 3); ctx.lineTo(kx + r() * 2, ky + 3 + r() * 4); ctx.fill(); }
        // the chisel, leaning well over to the right and short (LOOKED AT: upright, on an empty name it crossed the heading)
        var Lc = Math.min(size, 40); ctx.save(); ctx.translate(ex, ey - size * 0.35); ctx.rotate(0.95); ctx.fillStyle = '#c9ccd2'; ctx.fillRect(-3, -Lc * 1.4, 6, Lc * 1.2); ctx.fillStyle = '#6b4a2b'; ctx.fillRect(-6, -Lc * 2.6, 12, Lc * 1.25); ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.fillRect(-3, -Lc * 1.4, 2, Lc * 1.2); ctx.restore();
      }
      return { x0: x0, x1: W / 2 + half, y: ey, size: size };
    },
    verdict: function (ctx, W, H, st, e) {
      var g = this.geo(), r = rng((st.seed || 11) ^ 0xBEEF);
      if (st.verdict === 'right') {
        // gilt: the letters filled with gold leaf (text() redraws them gilt) and glints catching on their tops
        // (LOOKED AT 2026-10-11: a gradient band behind the word read as a highlighter box)
        for (var k = 0; k < 6; k++) { var gx = e.x0 + 10 + r() * (e.x1 - e.x0 - 20), gy = e.y - e.size * (0.55 + r() * 0.4), gs = 5 + r() * 6; ctx.save(); ctx.shadowColor = 'rgba(255,230,160,0.9)'; ctx.shadowBlur = 8; ctx.fillStyle = 'rgba(255,248,220,0.95)'; ctx.beginPath(); ctx.moveTo(gx, gy - gs); ctx.lineTo(gx + gs * 0.22, gy - gs * 0.22); ctx.lineTo(gx + gs, gy); ctx.lineTo(gx + gs * 0.22, gy + gs * 0.22); ctx.lineTo(gx, gy + gs); ctx.lineTo(gx - gs * 0.22, gy + gs * 0.22); ctx.lineTo(gx - gs, gy); ctx.lineTo(gx - gs * 0.22, gy - gs * 0.22); ctx.closePath(); ctx.fill(); ctx.restore(); }
      } else if (st.verdict === 'wrong') {
        // a crack through the cut, branching, with spalled chips
        ctx.strokeStyle = 'rgba(20,18,16,0.9)'; ctx.lineWidth = 2.2; ctx.beginPath(); var x = g.sx + 40, y = e.y - e.size * 0.9; ctx.moveTo(x, y);
        var pts = []; while (x < g.sx + g.sw - 40) { x += 18 + r() * 26; y += (r() - 0.45) * 22; y = Math.max(g.sy + 40, Math.min(g.sy + g.sh - 40, y)); ctx.lineTo(x, y); pts.push([x, y]); } ctx.stroke();
        ctx.strokeStyle = 'rgba(235,230,215,0.35)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(g.sx + 40, e.y - e.size * 0.9 + 2); for (var p = 0; p < pts.length; p++) ctx.lineTo(pts[p][0], pts[p][1] + 2); ctx.stroke();
        ctx.strokeStyle = 'rgba(20,18,16,0.8)'; ctx.lineWidth = 1.4; for (var b = 2; b < pts.length; b += 3) { ctx.beginPath(); ctx.moveTo(pts[b][0], pts[b][1]); ctx.lineTo(pts[b][0] + (r() - 0.5) * 30, pts[b][1] + 14 + r() * 20); ctx.stroke(); }
      } else if (st.verdict === 'reveal') {
        carve(ctx, 'IT WAS WRITTEN', W / 2, e.y + 44, 15, 5);
      }
    },
  };

  // ================================================================================================================ PAPERS
  var papers = {
    geo: function () { var px = 82, py = 32, pw = 652, ph = 352, fw = 150, fh = 204; return { px: px, py: py, pw: pw, ph: ph, fx: px + 22, fy: py + 70, fw: fw, fh: fh, lx: px + 22 + fw + 28, lw: px + pw - 24 - (px + 22 + fw + 28), rowY: [py + 88, py + 178, py + 268] }; },
    base: function (ctx, W, H, st) {
      var g = this.geo(), r = rng(st.seed || 13);
      var bg = ctx.createLinearGradient(0, 0, W, H); bg.addColorStop(0, '#2c3a33'); bg.addColorStop(1, '#141c18'); ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
      ctx.save(); ctx.shadowColor = 'rgba(0,0,0,0.6)'; ctx.shadowBlur = 22; ctx.shadowOffsetY = 8; ctx.fillStyle = '#e6eadb'; ctx.fillRect(g.px, g.py, g.pw, g.ph); ctx.restore();
      var pg = ctx.createLinearGradient(g.px, g.py, g.px + g.pw, g.py + g.ph); pg.addColorStop(0, '#eef0e2'); pg.addColorStop(1, '#d8dfcb'); ctx.fillStyle = pg; ctx.fillRect(g.px, g.py, g.pw, g.ph);
      // guilloche: interleaved sine rosettes in two inks, the security ground of a real document
      ctx.save(); ctx.beginPath(); ctx.rect(g.px, g.py, g.pw, g.ph); ctx.clip();
      for (var q = 0; q < 26; q++) { ctx.strokeStyle = q % 2 ? 'rgba(90,140,120,0.22)' : 'rgba(150,110,160,0.18)'; ctx.lineWidth = 0.8; ctx.beginPath(); for (var t = 0; t <= 400; t++) { var u = t / 400, x = g.px + u * g.pw, y = g.py + g.ph * 0.55 + Math.sin(u * Math.PI * 9 + q * 0.42) * g.ph * 0.3 * Math.cos(u * Math.PI * 2 + q * 0.11); if (t) ctx.lineTo(x, y); else ctx.moveTo(x, y); } ctx.stroke(); }
      ctx.restore();
      ctx.fillStyle = 'rgba(40,70,60,0.88)'; ctx.fillRect(g.px, g.py, g.pw, 46);
      ctx.fillStyle = '#eef0e2'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.font = 'bold 21px ' + FACES.label; ctx.fillText((st.title || 'Papers of Passage').toUpperCase(), g.px + 20, g.py + 23);
      ctx.textAlign = 'right'; ctx.font = '15px ' + FACES.label; ctx.fillText('No. ' + (100000 + Math.floor(r() * 899999)), g.px + g.pw - 20, g.py + 23);
      ctx.fillStyle = '#c9cfbf'; ctx.fillRect(g.fx, g.fy, g.fw, g.fh); ctx.strokeStyle = 'rgba(40,60,50,0.7)'; ctx.lineWidth = 2; ctx.strokeRect(g.fx, g.fy, g.fw, g.fh);
      if (st.face) {
        // the face cover-fitted into the inset (MZ faces are square; the inset is portrait)
        var fwI = st.face.width, fhI = st.face.height, k = Math.max((g.fw - 6) / fwI, (g.fh - 6) / fhI), sw = (g.fw - 6) / k, sh = (g.fh - 6) / k;
        ctx.drawImage(st.face, (fwI - sw) / 2, (fhI - sh) / 2, sw, sh, g.fx + 3, g.fy + 3, g.fw - 6, g.fh - 6);
      } else { ctx.fillStyle = 'rgba(60,75,68,0.55)'; ctx.beginPath(); ctx.arc(g.fx + g.fw / 2, g.fy + g.fh * 0.4, g.fw * 0.22, 0, Math.PI * 2); ctx.fill(); ctx.beginPath(); ctx.ellipse(g.fx + g.fw / 2, g.fy + g.fh * 0.95, g.fw * 0.42, g.fh * 0.32, 0, Math.PI, 0); ctx.fill(); }
      var labels = ['Name of bearer', 'Place of origin', 'Seal of the office'];
      for (var i = 0; i < 3; i++) { var y0 = g.rowY[i]; ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic'; ctx.fillStyle = 'rgba(40,70,60,0.9)'; ctx.font = '13px ' + FACES.label; ctx.fillText(labels[i].toUpperCase(), g.lx, y0); ctx.strokeStyle = 'rgba(40,70,60,0.35)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(g.lx, y0 + 40); ctx.lineTo(g.lx + g.lw, y0 + 40); ctx.stroke(); }
      ctx.fillStyle = 'rgba(70,70,80,0.75)'; ctx.font = '19px ' + FACES.type; ctx.fillText(st.origin || 'Not recorded', g.lx, g.rowY[1] + 32, g.lw);
      // the office seal, struck at an angle, ink uneven
      var sr = 50, sc = document.createElement('canvas'); sc.width = sc.height = Math.ceil(sr * 2.6); var x = sc.getContext('2d'); x.translate(sc.width / 2, sc.height / 2); x.rotate(-0.22);
      x.strokeStyle = 'rgba(165,35,40,0.75)'; x.lineWidth = 3; x.beginPath(); x.arc(0, 0, sr, 0, Math.PI * 2); x.stroke(); x.lineWidth = 1.5; x.beginPath(); x.arc(0, 0, sr * 0.72, 0, Math.PI * 2); x.stroke();
      var word = (st.stamp || 'Approved by the office').toUpperCase(); x.font = 'bold ' + Math.round(sr * 0.2) + 'px ' + FACES.label; x.fillStyle = 'rgba(165,35,40,0.8)'; x.textAlign = 'center'; x.textBaseline = 'middle';
      for (var j = 0; j < word.length; j++) { var a = -Math.PI / 2 + (j - word.length / 2) * (Math.PI * 1.7 / word.length); x.save(); x.rotate(a + Math.PI / 2); x.fillText(word[j], 0, -sr * 0.86); x.restore(); }
      x.font = 'bold ' + Math.round(sr * 0.5) + 'px ' + FACES.label; x.fillText('✦', 0, 2);
      x.setTransform(1, 0, 0, 1, 0, 0); x.globalCompositeOperation = 'destination-out'; for (var k2 = 0; k2 < 60; k2++) { x.fillStyle = 'rgba(0,0,0,' + (0.2 + r() * 0.5) + ')'; x.beginPath(); x.arc(r() * sc.width, r() * sc.height, 1 + r() * 3, 0, Math.PI * 2); x.fill(); }
      ctx.drawImage(sc, g.px + g.pw - 120 - sc.width / 2, g.rowY[2] + 26 - sc.height / 2);
      // the instruction (or the question) printed small under the portrait
      ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic'; ctx.font = 'italic 14px ' + FACES.label; ctx.fillStyle = 'rgba(40,70,60,0.9)';
      wrapped(ctx, st.prompt || 'Enter the name of the bearer', g.fx, g.fy + g.fh + 26, g.pw - 220, 2, 18);
    },
    text: function (ctx, W, H, st) {
      var g = this.geo(), text = (st.text || '').toUpperCase(), size = fitSize(ctx, text || 'M', FACES.type, 'bold', 34, 18, g.lw - 24);
      ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic'; ctx.font = 'bold ' + size + 'px ' + FACES.type; ctx.fillStyle = '#1f2430'; var y = g.rowY[0] + 34; ctx.fillText(text, g.lx, y);
      var tend = g.lx + ctx.measureText(text).width;
      if (st.caret !== false) { ctx.fillStyle = 'rgba(31,36,48,0.75)'; ctx.fillRect(tend + 3, y + 4, size * 0.55, 3); }
      return { x0: g.lx, x1: tend, y: y, size: size };
    },
    verdict: function (ctx, W, H, st, e) {
      var g = this.geo();
      if (st.verdict === 'right' || st.verdict === 'wrong') {
        var sb = stampBox(st.verdict === 'right' ? (st.rightWord || 'APPROVED') : (st.wrongWord || 'REFUSED'), st.verdict === 'right' ? 'rgba(40,120,70,0.85)' : 'rgba(170,30,35,0.88)', 0, st.verdict === 'right' ? -0.14 : 0.12, st.seed);
        ctx.drawImage(sb, g.lx + g.lw * 0.42 - sb.width / 2, g.rowY[1] + 4 - sb.height / 2);
      } else if (st.verdict === 'reveal') { ctx.textAlign = 'left'; ctx.font = 'italic 14px ' + FACES.label; ctx.fillStyle = 'rgba(170,30,35,0.85)'; ctx.fillText('ENTERED BY THE CLERK', g.lx, e.y + 22); }
    },
  };

  // ============================================================================================================ TYPEWRITER
  var typewriter = {
    geo: function () { var px = 130, pw = 556, top = 12, platenY = 362; return { px: px, pw: pw, top: top, platenY: platenY, fy0: top + 116, fstep: 60 }; },
    base: function (ctx, W, H, st) {
      var g = this.geo(), r = rng(st.seed || 17);
      ctx.fillStyle = '#1b1a1d'; ctx.fillRect(0, 0, W, H);
      var paper = ctx.createLinearGradient(0, g.top, 0, g.platenY); paper.addColorStop(0, '#f4f1e8'); paper.addColorStop(1, '#ddd8c9'); ctx.fillStyle = paper; ctx.fillRect(g.px, g.top, g.pw, g.platenY - g.top);
      for (var f = 0; f < 500; f++) { ctx.fillStyle = 'rgba(120,110,90,' + (0.03 + r() * 0.05) + ')'; ctx.fillRect(g.px + r() * g.pw, g.top + r() * (g.platenY - g.top), 1, 1); }
      var pl = ctx.createLinearGradient(0, g.platenY, 0, H); pl.addColorStop(0, '#3a3a3e'); pl.addColorStop(0.35, '#111114'); pl.addColorStop(1, '#2a2a2e'); ctx.fillStyle = pl; ctx.fillRect(g.px - 40, g.platenY, g.pw + 80, H - g.platenY);
      ctx.fillStyle = 'rgba(255,255,255,0.12)'; ctx.fillRect(g.px - 40, g.platenY + 3, g.pw + 80, 2);
      // the platen knobs at both ends
      for (var s = -1; s <= 1; s += 2) { var kx = W / 2 + s * (g.pw / 2 + 58), kg = ctx.createRadialGradient(kx - 4, g.platenY + 22, 2, kx, g.platenY + 28, 26); kg.addColorStop(0, '#6a6a70'); kg.addColorStop(1, '#141416'); ctx.fillStyle = kg; ctx.beginPath(); ctx.arc(kx, g.platenY + 28, 22, 0, Math.PI * 2); ctx.fill(); }
      ctx.fillStyle = '#2d3a5a'; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic'; ctx.font = 'bold 24px ' + FACES.label; ctx.fillText((st.title || 'Form 7: Particulars').toUpperCase(), W / 2, g.top + 40);
      ctx.font = 'italic 15px ' + FACES.label; wrapped(ctx, st.prompt || 'Type your name in the space provided', W / 2, g.top + 62, 500, 2, 17);
      var fields = st.fields || ['Name in full', 'Occupation', 'Address', 'Signature'];
      ctx.textAlign = 'left';
      for (var i = 0; i < 4; i++) { var y = g.fy0 + i * g.fstep; ctx.fillStyle = '#2d3a5a'; ctx.font = '14px ' + FACES.label; ctx.fillText((i + 1) + '. ' + (fields[i] || ''), g.px + 30, y - 27); ctx.strokeStyle = 'rgba(45,58,90,0.55)'; ctx.setLineDash([2, 3]); ctx.beginPath(); ctx.moveTo(g.px + 30, y + 8); ctx.lineTo(g.px + g.pw - 30, y + 8); ctx.stroke(); ctx.setLineDash([]); }
      // the occupation already typed, a little faded (the buyer's own class name)
      if (st.occupation) { ctx.font = 'bold 20px ' + FACES.type; ctx.fillStyle = 'rgba(20,22,40,0.55)'; ctx.fillText(st.occupation, g.px + 34, g.fy0 + g.fstep, g.pw - 80); }
    },
    text: function (ctx, W, H, st) {
      var g = this.geo(), r = rng((st.seed || 17) ^ 0x51ED), cs = chars(st.text), size = 30, x = g.px + 34, y0 = g.fy0;
      // each letter advances by its OWN width, at least the face's "M" (LOOKED AT: full-width letters on one "M" advance
      // overlapped); bold with uneven ribbon ink (LOOKED AT: regular Courier read as a thin screen font)
      var face = 'bold ' + size + 'px ' + FACES.type; ctx.font = face; var m = ctx.measureText('M').width, total = 0; for (var q = 0; q < cs.length; q++) total += Math.max(m, ctx.measureText(cs[q]).width);
      if (total > g.pw - 80) { size = Math.max(16, Math.floor(size * (g.pw - 80) / total)); face = 'bold ' + size + 'px ' + FACES.type; ctx.font = face; }
      ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
      var mW = ctx.measureText('M').width, cx = x;
      for (var c = 0; c < cs.length; c++) { var dy = (r() - 0.5) * 2.2, dk = 0.6 + r() * 0.35; ctx.fillStyle = (st.ribbon === 'red' ? 'rgba(140,24,24,' : 'rgba(20,22,40,') + dk + ')'; ctx.fillText(cs[c], cx, y0 + dy); if (r() < 0.4) { ctx.fillStyle = 'rgba(20,22,40,0.22)'; ctx.fillText(cs[c], cx + 0.7, y0 + dy + 0.5); } cx += Math.max(mW, ctx.measureText(cs[c]).width); }
      // the carriage guide: a small red arrow at the paper's edge under the next letter (no line through the form: LOOKED AT)
      if (st.caret !== false) { var gx = cx + mW * 0.5, gy = g.platenY - 4; ctx.fillStyle = '#b8322c'; ctx.beginPath(); ctx.moveTo(gx, gy - 12); ctx.lineTo(gx - 7, gy); ctx.lineTo(gx + 7, gy); ctx.fill(); ctx.fillStyle = 'rgba(31,36,48,0.7)'; ctx.fillRect(cx + 1, y0 + 4, mW * 0.8, 2); }
      return { x0: x, x1: cx, y: y0, size: size, advance: mW };
    },
    verdict: function (ctx, W, H, st, e) {
      var g = this.geo();
      if (st.verdict === 'wrong') {
        // struck over: an X typed on every letter, the way a typist voids a line
        ctx.font = 'bold ' + e.size + 'px ' + FACES.type; ctx.textAlign = 'left'; ctx.fillStyle = 'rgba(20,22,40,0.8)';
        for (var x = e.x0; x < Math.max(e.x1, e.x0 + e.advance * 4) - 1; x += e.advance) ctx.fillText('X', x, e.y);
        var sb = stampBox(st.wrongWord || 'VOID', 'rgba(170,30,35,0.85)', 0, 0.1, st.seed); ctx.drawImage(sb, g.px + g.pw - 40 - sb.width, g.fy0 + g.fstep * 2 - sb.height / 2);
      } else if (st.verdict === 'right') {
        var sa = stampBox(st.rightWord || 'ACCEPTED', 'rgba(170,30,35,0.85)', 0, -0.12, st.seed); ctx.drawImage(sa, g.px + g.pw - 40 - sa.width, g.fy0 + g.fstep * 2 - sa.height / 2);
      } else if (st.verdict === 'reveal') { ctx.font = 'italic 14px ' + FACES.label; ctx.fillStyle = 'rgba(140,24,24,0.85)'; ctx.textAlign = 'left'; ctx.fillText('(entered by the office)', e.x0, e.y + 26); }
    },
  };

  // ================================================================================================================= SIGIL
  /** where a letter sits on the wheel: A at the top, clockwise; accents fold to their base letter, other marks have no place */
  function wheelIndex(ch) { var b = String(ch).normalize('NFD').replace(/[̀-ͯ]/g, '').toUpperCase(); if (b === 'Æ') b = 'A'; if (b === 'Ø') b = 'O'; if (b === 'ß') b = 'S'; var c = b.charCodeAt(0) - 65; return (b.length === 1 && c >= 0 && c < 26) ? c : -1; }
  var sigil = {
    // the circle sits high and the name plate goes UNDER it (LOOKED AT 2026-10-11: a plate across the lower circle ran into
    // the wheel's R and J on a long name)
    geo: function () { return { cx: 408, cy: 190, R: 172 }; },
    pt: function (i, rad) { var g = this.geo(), a = -Math.PI / 2 + i / 26 * Math.PI * 2; return [g.cx + Math.cos(a) * rad, g.cy + Math.sin(a) * rad]; },
    base: function (ctx, W, H, st) {
      var g = this.geo(), r = rng(st.seed || 19);
      var bg = ctx.createRadialGradient(g.cx, g.cy, 20, g.cx, g.cy, W * 0.7); bg.addColorStop(0, '#2a1838'); bg.addColorStop(0.6, '#140b1e'); bg.addColorStop(1, '#07040b'); ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
      for (var d = 0; d < 260; d++) { ctx.fillStyle = 'rgba(200,170,255,' + (0.03 + r() * 0.12) + ')'; ctx.fillRect(r() * W, r() * H, 1, 1); }
      // the circle: chalked double ring, tick marks between, an inner ring the trace runs inside
      ctx.save(); ctx.shadowColor = 'rgba(190,150,255,0.6)'; ctx.shadowBlur = 10;
      ctx.strokeStyle = 'rgba(214,196,255,0.85)'; ctx.lineWidth = 2.2; ctx.beginPath(); ctx.arc(g.cx, g.cy, g.R, 0, Math.PI * 2); ctx.stroke();
      ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(g.cx, g.cy, g.R - 12, 0, Math.PI * 2); ctx.stroke(); ctx.beginPath(); ctx.arc(g.cx, g.cy, g.R - 52, 0, Math.PI * 2); ctx.stroke();
      ctx.restore();
      for (var t = 0; t < 104; t++) { var a = t / 104 * Math.PI * 2, i0 = t % 4 === 0 ? g.R - 12 : g.R - 8; ctx.strokeStyle = 'rgba(214,196,255,0.45)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(g.cx + Math.cos(a) * i0, g.cy + Math.sin(a) * i0); ctx.lineTo(g.cx + Math.cos(a) * (g.R - 2), g.cy + Math.sin(a) * (g.R - 2)); ctx.stroke(); }
      // the alphabet wheel, dim: the trace is drawn letter to letter around it
      ctx.font = '16px ' + FACES.label; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      for (var k = 0; k < 26; k++) { var p = this.pt(k, g.R - 32); ctx.fillStyle = 'rgba(214,196,255,0.55)'; ctx.fillText(String.fromCharCode(65 + k), p[0], p[1]); var q = this.pt(k, g.R - 62); ctx.fillStyle = 'rgba(214,196,255,0.28)'; ctx.beginPath(); ctx.arc(q[0], q[1], 1.6, 0, Math.PI * 2); ctx.fill(); }
      // title and prompt on the left, the count on the right (the circle owns the middle)
      ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic'; ctx.fillStyle = 'rgba(232,220,255,0.9)'; ctx.font = 'bold 24px ' + FACES.label;
      var tl = String(st.title || 'The Sigil').split(' '); for (var w = 0; w < tl.length && w < 3; w++) ctx.fillText(tl[w], 36, 70 + w * 30);
      ctx.font = 'italic 15px ' + FACES.label; ctx.fillStyle = 'rgba(214,196,255,0.7)';
      var pr = String(st.prompt || 'Bind your name into the circle').split(' '), line = '', ly = 70 + Math.min(3, tl.length) * 30 + 10;
      for (var z = 0; z < pr.length; z++) { var tst = line ? line + ' ' + pr[z] : pr[z]; if (ctx.measureText(tst).width > 170 && line) { ctx.fillText(line, 36, ly); ly += 20; line = pr[z]; } else line = tst; } if (line) ctx.fillText(line, 36, ly);
    },
    text: function (ctx, W, H, st) {
      var g = this.geo(), cs = chars(st.text), self = this, pts = [];
      for (var i = 0; i < cs.length; i++) { var ix = wheelIndex(cs[i]); if (ix >= 0) pts.push(ix); }
      // the trace: letter to letter on the inner points, a ring where it starts, a bar where it ends, a loop on a repeat
      var gold = st.gilt;
      ctx.save(); ctx.shadowColor = gold ? 'rgba(255,210,120,0.9)' : 'rgba(200,120,255,0.9)'; ctx.shadowBlur = 12; ctx.strokeStyle = gold ? 'rgba(255,226,150,0.98)' : 'rgba(236,200,255,0.95)'; ctx.lineWidth = 2.6; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      if (pts.length) {
        var P = function (k) { return self.pt(pts[k], g.R - 62); };
        var s0 = P(0); ctx.beginPath(); ctx.arc(s0[0], s0[1], 6, 0, Math.PI * 2); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(s0[0], s0[1]);
        for (var k = 1; k < pts.length; k++) { var p = P(k); if (pts[k] === pts[k - 1]) { ctx.stroke(); ctx.beginPath(); var a = Math.atan2(p[1] - g.cy, p[0] - g.cx); ctx.arc(p[0] - Math.cos(a) * 8, p[1] - Math.sin(a) * 8, 8, 0, Math.PI * 2); ctx.stroke(); ctx.beginPath(); ctx.moveTo(p[0], p[1]); } else ctx.lineTo(p[0], p[1]); }
        ctx.stroke();
        var e1 = P(pts.length - 1), e0 = pts.length > 1 ? P(pts.length - 2) : [g.cx, g.cy], ang = Math.atan2(e1[1] - e0[1], e1[0] - e0[0]) + Math.PI / 2;
        ctx.beginPath(); ctx.moveTo(e1[0] - Math.cos(ang) * 9, e1[1] - Math.sin(ang) * 9); ctx.lineTo(e1[0] + Math.cos(ang) * 9, e1[1] + Math.sin(ang) * 9); ctx.stroke();
      }
      ctx.restore();
      // the wheel letters the name uses, lit
      ctx.font = 'bold 16px ' + FACES.label; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      var lit = {}; for (var j = 0; j < pts.length; j++) lit[pts[j]] = 1;
      for (var n in lit) { var q = this.pt(Number(n), g.R - 32); ctx.save(); ctx.shadowColor = 'rgba(220,170,255,0.9)'; ctx.shadowBlur = 8; ctx.fillStyle = gold ? '#ffe2a0' : '#f1e4ff'; ctx.fillText(String.fromCharCode(65 + Number(n)), q[0], q[1]); ctx.restore(); }
      // the name on a plate across the lower circle
      var text = st.text || '', size = fitSize(ctx, text || 'M', FACES.label, 'bold', 28, 16, 460, 3), py = g.cy + g.R + 30;
      var gr = ctx.createLinearGradient(g.cx - 270, 0, g.cx + 270, 0); gr.addColorStop(0, 'rgba(10,5,16,0)'); gr.addColorStop(0.2, 'rgba(10,5,16,0.85)'); gr.addColorStop(0.8, 'rgba(10,5,16,0.85)'); gr.addColorStop(1, 'rgba(10,5,16,0)'); ctx.fillStyle = gr; ctx.fillRect(g.cx - 280, py - 26, 560, 38);
      ctx.strokeStyle = 'rgba(214,196,255,0.35)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(g.cx - 220, py + 12); ctx.lineTo(g.cx + 220, py + 12); ctx.stroke();
      ctx.font = 'bold ' + size + 'px ' + FACES.label; var hasLS = ctx.letterSpacing !== undefined; if (hasLS) ctx.letterSpacing = '3px';
      ctx.textBaseline = 'alphabetic'; ctx.fillStyle = gold ? '#ffd98a' : '#efe2ff'; ctx.fillText(text, g.cx, py + 4);
      var tw = ctx.measureText(text).width + 3 * cs.length; if (hasLS) ctx.letterSpacing = '0px';
      if (st.caret !== false) { ctx.fillStyle = 'rgba(239,226,255,0.8)'; ctx.fillRect(g.cx + tw / 2 + 4, py + 6, 12, 2); }
      ctx.textAlign = 'right'; ctx.font = 'italic 15px ' + FACES.label; ctx.fillStyle = 'rgba(214,196,255,0.7)';
      ctx.fillText(pts.length + (pts.length === 1 ? ' mark' : ' marks') + ' bound', W - 36, 70); ctx.fillText((st.max - cs.length) + ' left', W - 36, 92);
      return { x0: g.cx - tw / 2, x1: g.cx + tw / 2, y: py + 4, size: size, marks: pts.length };
    },
    verdict: function (ctx, W, H, st, e) {
      var g = this.geo(), r = rng((st.seed || 19) ^ 0xBEEF);
      if (st.verdict === 'right') {
        var gl = ctx.createRadialGradient(g.cx, g.cy, g.R * 0.2, g.cx, g.cy, g.R * 1.25); gl.addColorStop(0, 'rgba(255,214,140,0.22)'); gl.addColorStop(0.75, 'rgba(255,200,120,0.10)'); gl.addColorStop(1, 'rgba(255,200,120,0)'); ctx.fillStyle = gl; ctx.fillRect(0, 0, W, H);
        ctx.save(); ctx.shadowColor = 'rgba(255,210,120,0.9)'; ctx.shadowBlur = 16; ctx.strokeStyle = 'rgba(255,226,150,0.9)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(g.cx, g.cy, g.R + 6, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
      } else if (st.verdict === 'wrong') {
        // the circle broken: three gaps cut out of the rings and ash drifting from them
        ctx.save(); ctx.globalCompositeOperation = 'source-over';
        // gaps in the ground's own colour, small (LOOKED AT 2026-10-11: 14 px near-black discs read as holes punched in the frame)
        for (var k = 0; k < 3; k++) { var a = r() * Math.PI * 2, x = g.cx + Math.cos(a) * (g.R - 6), y = g.cy + Math.sin(a) * (g.R - 6); ctx.fillStyle = '#1a0f26'; ctx.beginPath(); ctx.arc(x, y, 9, 0, Math.PI * 2); ctx.fill(); for (var s = 0; s < 10; s++) { ctx.fillStyle = 'rgba(150,140,160,' + (0.2 + r() * 0.4) + ')'; ctx.fillRect(x + (r() - 0.5) * 24, y + r() * 22, 2, 2); } }
        ctx.strokeStyle = 'rgba(170,40,60,0.85)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(g.cx - 70, g.cy - 70); ctx.lineTo(g.cx + 70, g.cy + 70); ctx.stroke(); ctx.restore();
      } else if (st.verdict === 'reveal') { ctx.textAlign = 'right'; ctx.font = 'italic 15px ' + FACES.label; ctx.fillStyle = 'rgba(214,196,255,0.8)'; ctx.fillText('the circle shows', W - 36, 124); ctx.fillText('what was asked', W - 36, 144); }
    },
  };

  // ================================================================================================================= GRAVE
  var grave = {
    geo: function () { var x = 258, w = 300, top = 26, bot = 372; return { x: x, w: w, top: top, bot: bot, cx: x + w / 2, archY: top + w / 2, nameY: 226 }; },
    shape: function (ctx, g, inset) { var x = g.x + inset, w = g.w - inset * 2, r = w / 2; ctx.beginPath(); ctx.moveTo(x, g.bot); ctx.lineTo(x, g.archY); ctx.arc(g.cx, g.archY, r, Math.PI, 0); ctx.lineTo(x + w, g.bot); ctx.closePath(); },
    base: function (ctx, W, H, st) {
      var g = this.geo(), r = rng(st.seed || 23);
      var sky = ctx.createLinearGradient(0, 0, 0, H); sky.addColorStop(0, '#0d1420'); sky.addColorStop(0.7, '#1d2733'); sky.addColorStop(1, '#141a20'); ctx.fillStyle = sky; ctx.fillRect(0, 0, W, H);
      // the moon behind cloud, top right
      var mg = ctx.createRadialGradient(676, 72, 6, 676, 72, 150); mg.addColorStop(0, 'rgba(230,236,220,0.55)'); mg.addColorStop(0.2, 'rgba(200,210,200,0.18)'); mg.addColorStop(1, 'rgba(200,210,200,0)'); ctx.fillStyle = mg; ctx.fillRect(500, 0, 316, 260);
      ctx.fillStyle = '#e6ead8'; ctx.beginPath(); ctx.arc(676, 72, 26, 0, Math.PI * 2); ctx.fill();
      // a cloud bank BELOW the disc, soft puffs (LOOKED AT 2026-10-11: thin ellipses across the disc read as a ringed planet)
      for (var c = 0; c < 14; c++) { var cxp = 560 + r() * 230, cyp = 118 + r() * 22, crp = 14 + r() * 22, cg = ctx.createRadialGradient(cxp, cyp, 1, cxp, cyp, crp); cg.addColorStop(0, 'rgba(28,36,48,0.55)'); cg.addColorStop(1, 'rgba(28,36,48,0)'); ctx.fillStyle = cg; ctx.fillRect(cxp - crp, cyp - crp, crp * 2, crp * 2); }
      // far hill, iron fence and a dead tree, all silhouette
      ctx.fillStyle = '#0b1016'; ctx.beginPath(); ctx.moveTo(0, 300); for (var x = 0; x <= W; x += 24) ctx.lineTo(x, 292 - Math.sin(x * 0.011) * 18 - r() * 6); ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.fill();
      ctx.strokeStyle = '#0a0e13'; ctx.lineWidth = 3; for (var f = 20; f < 230; f += 18) { ctx.beginPath(); ctx.moveTo(f, 340); ctx.lineTo(f, 268); ctx.stroke(); ctx.fillStyle = '#0a0e13'; ctx.beginPath(); ctx.moveTo(f - 4, 270); ctx.lineTo(f, 260); ctx.lineTo(f + 4, 270); ctx.fill(); } ctx.fillRect(16, 282, 214, 3);
      ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(712, 340); ctx.lineTo(704, 220); ctx.stroke(); ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(706, 250); ctx.lineTo(668, 214); ctx.moveTo(705, 236); ctx.lineTo(748, 196); ctx.moveTo(686, 232); ctx.lineTo(676, 200); ctx.moveTo(730, 216); ctx.lineTo(742, 182); ctx.stroke();
      // the headstone: granite with an arched top, its own shadow, weathered
      ctx.save(); ctx.shadowColor = 'rgba(0,0,0,0.7)'; ctx.shadowBlur = 26; ctx.shadowOffsetX = -10; ctx.fillStyle = '#6c706f'; this.shape(ctx, g, 0); ctx.fill(); ctx.restore();
      var sg = ctx.createLinearGradient(g.x, g.top, g.x + g.w, g.bot); sg.addColorStop(0, '#9aa09c'); sg.addColorStop(0.55, '#737975'); sg.addColorStop(1, '#4b504e'); ctx.fillStyle = sg; this.shape(ctx, g, 0); ctx.fill();
      ctx.save(); this.shape(ctx, g, 0); ctx.clip();
      for (var m = 0; m < 1300; m++) { ctx.fillStyle = r() < 0.55 ? 'rgba(30,34,32,' + (0.08 + r() * 0.12) + ')' : 'rgba(225,230,220,' + (0.05 + r() * 0.09) + ')'; ctx.beginPath(); ctx.arc(g.x + r() * g.w, g.top + r() * (g.bot - g.top), 0.5 + r() * 2, 0, Math.PI * 2); ctx.fill(); }
      // lichen and moss creeping up from the ground and down the left shoulder
      for (var l = 0; l < 160; l++) { var ly = g.bot - Math.pow(r(), 2.2) * 150, lx = g.x + r() * g.w; ctx.fillStyle = 'rgba(' + (70 + Math.floor(r() * 40)) + ',' + (100 + Math.floor(r() * 40)) + ',60,' + (0.25 + r() * 0.35) + ')'; ctx.beginPath(); ctx.arc(lx, ly, 1 + r() * 4, 0, Math.PI * 2); ctx.fill(); }
      for (var l2 = 0; l2 < 50; l2++) { var a2 = Math.PI + r() * 0.9; ctx.fillStyle = 'rgba(120,140,80,' + (0.2 + r() * 0.3) + ')'; ctx.beginPath(); ctx.arc(g.cx + Math.cos(a2) * (g.w / 2 - 6 - r() * 18), g.archY + Math.sin(a2) * (g.w / 2 - 6 - r() * 18), 1 + r() * 3, 0, Math.PI * 2); ctx.fill(); }
      ctx.restore();
      ctx.strokeStyle = 'rgba(245,245,235,0.28)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(g.cx, g.archY, g.w / 2 - 1, Math.PI, Math.PI * 1.5); ctx.stroke();
      // a carved border inside the arch and a small carved cross at the crown
      ctx.strokeStyle = 'rgba(28,30,30,0.6)'; ctx.lineWidth = 2.5; this.shape(ctx, g, 18); ctx.stroke(); ctx.strokeStyle = 'rgba(235,240,230,0.25)'; ctx.lineWidth = 1; ctx.save(); ctx.translate(1, 1); this.shape(ctx, g, 18); ctx.stroke(); ctx.restore();
      carve(ctx, '✝', g.cx, g.top + 80, 30, 0, { lit: 'rgba(230,235,225,0.35)', shade: 'rgba(20,22,22,0.8)', floor: 'rgba(60,64,62,0.9)' });
      carve(ctx, (st.title || 'Here Lies').toUpperCase(), g.cx, g.top + 128, 19, 5, { lit: 'rgba(230,235,225,0.35)', shade: 'rgba(20,22,22,0.8)', floor: 'rgba(60,64,62,0.9)' });
      ctx.font = 'italic 16px ' + FACES.label; ctx.textAlign = 'center'; ctx.fillStyle = 'rgba(32,36,34,0.85)'; ctx.fillText(st.epitaph || 'Rest well, traveller', g.cx, g.nameY + 52); ctx.fillStyle = 'rgba(230,235,225,0.25)'; ctx.fillText(st.epitaph || 'Rest well, traveller', g.cx + 1, g.nameY + 53);
      // ground: turned earth and grass blades in front of the stone
      ctx.fillStyle = '#10140f'; ctx.fillRect(0, 368, W, H - 368);
      for (var b = 0; b < 520; b++) { var bx = r() * W, by = 366 + r() * (H - 366), bh = 6 + r() * 16; ctx.strokeStyle = 'rgba(' + (40 + Math.floor(r() * 30)) + ',' + (60 + Math.floor(r() * 40)) + ',40,' + (0.5 + r() * 0.5) + ')'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(bx + (r() - 0.5) * 6, by - bh); ctx.stroke(); }
      // ground mist
      var fg = ctx.createLinearGradient(0, 330, 0, H); fg.addColorStop(0, 'rgba(170,185,190,0)'); fg.addColorStop(0.6, 'rgba(170,185,190,0.14)'); fg.addColorStop(1, 'rgba(170,185,190,0.05)'); ctx.fillStyle = fg; ctx.fillRect(0, 330, W, H - 330);
      ctx.textAlign = 'left'; ctx.font = 'italic 15px ' + FACES.label; ctx.fillStyle = 'rgba(200,210,205,0.78)'; wrapped(ctx, st.prompt || 'Carve a name upon the stone', 30, 40, 210, 5, 19);
    },
    text: function (ctx, W, H, st) {
      var g = this.geo(), r = rng((st.seed || 23) ^ 0x51ED), text = (st.text || '').toUpperCase(), maxW = g.w - 56;
      var tone = st.gilt ? { lit: 'rgba(255,240,190,0.5)', shade: 'rgba(50,34,10,0.9)', floor: 'rgba(190,150,70,0.95)' } : { lit: 'rgba(230,235,225,0.4)', shade: 'rgba(18,20,20,0.85)', floor: 'rgba(52,56,54,0.92)' };
      // a name too long for the stone at a readable size is cut on TWO lines at the space nearest its middle (LOOKED AT
      // 2026-10-11: "BARTHOLOMEW ASHGROVE" at the 18 px floor still ran past both edges of the stone)
      var lines = [text], size = fitSize(ctx, text || 'M', FACES.chisel, 'bold', 44, 22, maxW, 4);
      if (carvedWidth(ctx, text, size, 4) > maxW && text.indexOf(' ') > 0) {
        var best = -1; for (var s = 0; s < text.length; s++) if (text[s] === ' ' && (best < 0 || Math.abs(s - text.length / 2) < Math.abs(best - text.length / 2))) best = s;
        lines = [text.slice(0, best), text.slice(best + 1)]; size = Math.min(fitSize(ctx, lines[0], FACES.chisel, 'bold', 36, 14, maxW, 4), fitSize(ctx, lines[1], FACES.chisel, 'bold', 36, 14, maxW, 4));
      } else if (carvedWidth(ctx, text, size, 4) > maxW) size = fitSize(ctx, text, FACES.chisel, 'bold', size, 12, maxW, 4);
      var lh = size * 1.15, y0 = g.nameY - (lines.length - 1) * lh / 2, half = 0, cs, x;
      for (var li = 0; li < lines.length; li++) {
        var ly = y0 + li * lh; carve(ctx, lines[li], g.cx, ly, size, 4, tone); var hw = carvedWidth(ctx, lines[li], size, 4) / 2; half = Math.max(half, hw);
        // moss already in the oldest grooves: a few letters hold a fleck of green
        cs = chars(lines[li]); ctx.font = 'bold ' + size + 'px ' + FACES.chisel; x = g.cx - hw;
        for (var i = 0; i < cs.length; i++) { var w = ctx.measureText(cs[i]).width + 4; if (r() < 0.35) { ctx.fillStyle = 'rgba(110,140,70,0.75)'; ctx.beginPath(); ctx.arc(x + w * (0.3 + r() * 0.4), ly - 2 - r() * 4, 1.4 + r() * 1.6, 0, Math.PI * 2); ctx.fill(); } x += w; }
      }
      var lastY = y0 + (lines.length - 1) * lh, lastHalf = carvedWidth(ctx, lines[lines.length - 1], size, 4) / 2;
      if (st.caret !== false) { var ex = Math.min(g.x + g.w - 26, g.cx + lastHalf + 6); ctx.fillStyle = 'rgba(225,230,220,0.55)'; for (var k = 0; k < 9; k++) ctx.fillRect(ex + (r() - 0.5) * 14, lastY + 4 + r() * 10, 2, 2); ctx.fillStyle = 'rgba(225,230,220,0.6)'; ctx.fillRect(ex - 2, lastY + 6, 14, 2); }
      return { x0: g.cx - half, x1: g.cx + half, y: lastY, size: size, lines: lines.length };
    },
    verdict: function (ctx, W, H, st, e) {
      var g = this.geo(), r = rng((st.seed || 23) ^ 0xBEEF);
      if (st.verdict === 'right') {
        // two candles lit at the foot of the stone
        for (var s = -1; s <= 1; s += 2) { var cx = g.cx + s * (g.w / 2 + 34), cy = 360; ctx.fillStyle = '#e8e0c8'; ctx.fillRect(cx - 6, cy - 36, 12, 36); var fl = ctx.createRadialGradient(cx, cy - 46, 1, cx, cy - 46, 60); fl.addColorStop(0, 'rgba(255,220,140,0.95)'); fl.addColorStop(0.15, 'rgba(255,190,90,0.5)'); fl.addColorStop(1, 'rgba(255,190,90,0)'); ctx.fillStyle = fl; ctx.fillRect(cx - 60, cy - 106, 120, 120); ctx.fillStyle = '#fff3c8'; ctx.beginPath(); ctx.ellipse(cx, cy - 46, 4, 9, 0, 0, Math.PI * 2); ctx.fill(); }
      } else if (st.verdict === 'wrong') {
        ctx.save(); this.shape(ctx, g, 0); ctx.clip(); ctx.strokeStyle = 'rgba(15,16,16,0.9)'; ctx.lineWidth = 2.4; ctx.beginPath(); var x = g.cx + 40, y = g.top + 10; ctx.moveTo(x, y); while (y < g.bot) { y += 14 + r() * 22; x += (r() - 0.5) * 36; ctx.lineTo(x, y); } ctx.stroke(); ctx.restore();
      } else if (st.verdict === 'reveal') { ctx.textAlign = 'center'; ctx.font = 'italic 14px ' + FACES.label; ctx.fillStyle = 'rgba(30,34,32,0.9)'; ctx.fillText('so the stone remembers', g.cx, e.y + 78); }
    },
  };

  var RITES = { register: register, stone: stone, papers: papers, typewriter: typewriter, sigil: sigil, grave: grave };
  function pick(id) { return RITES[id] || RITES.register; }

  // ================================================================================================================== TRAY
  /** the key rects, tray-local: three rows of ten characters and a row of five function keys */
  var KEYS = (function () {
    var out = [], mx = 40, pitch = (L.W - mx * 2) / 10, kw = pitch - 8, kh = 38;
    for (var row = 0; row < 3; row++) for (var col = 0; col < 10; col++) out.push({ i: row * 10 + col, row: row, col: col, x: Math.round(mx + col * pitch + 4), y: 14 + row * 44, w: Math.round(kw), h: kh, kind: 'char' });
    var fp = (L.W - mx * 2) / 5, fns = ['case', 'page', 'extra', 'back', 'done'];
    for (var f = 0; f < 5; f++) out.push({ i: 30 + f, row: 3, col: f, x: Math.round(mx + f * fp + 4), y: 14 + 3 * 44 + 4, w: Math.round(fp - 8), h: kh, kind: 'fn', fn: fns[f] });
    return out;
  }());
  /** the look of each rite's keys: ground, face, edge, ink, the cursor's glow */
  var MATERIAL = {
    register: { ground: ['#2e1d10', '#1a0f07'], face: ['#e6c879', '#9c7a35'], edge: '#5a4318', ink: '#3b2a10', lip: 'rgba(255,240,200,0.55)', glow: 'rgba(255,214,120,0.95)', shape: 'plate', font: FACES.label },
    stone: { ground: ['#24282d', '#121418'], face: ['#a39f95', '#6a675f'], edge: '#3a3934', ink: '#2c2a26', lip: 'rgba(245,240,225,0.45)', glow: 'rgba(235,235,225,0.95)', shape: 'tile', font: FACES.chisel },
    // LOOKED AT 2026-10-11: red letters on a red rubber face could not be read; a stamp's rubber is near-black, its ink red
    papers: { ground: ['#2f4a3c', '#1b2c23'], face: ['#7a5236', '#4a2e1b'], edge: '#20140b', ink: '#e04848', lip: 'rgba(0,0,0,0.6)', glow: 'rgba(255,120,110,0.95)', shape: 'stamp', font: FACES.label },
    typewriter: { ground: ['#232326', '#0f0f11'], face: ['#2a2a2e', '#0c0c0e'], edge: '#b9bcc4', ink: '#f2efe6', lip: 'rgba(255,255,255,0.2)', glow: 'rgba(255,255,255,0.9)', shape: 'round', font: FACES.type },
    sigil: { ground: ['#1c1026', '#0a050f'], face: ['#9a1f3a', '#4e0c1c'], edge: '#300612', ink: '#2a0410', lip: 'rgba(255,170,190,0.4)', glow: 'rgba(214,160,255,0.95)', shape: 'wax', font: FACES.label },
    grave: { ground: ['#1b1712', '#0d0b08'], face: ['#e8dcc0', '#a8956c'], edge: '#5a4c33', ink: '#3b2e22', lip: 'rgba(255,250,235,0.5)', glow: 'rgba(170,230,190,0.95)', shape: 'bone', font: FACES.chisel },
  };
  var FN_LABEL = { case: { upper: 'abc', lower: 'ABC' }, page: { letters: 'ÀÉ 123', marks: 'A to Z' } };
  function fnLabel(k, st) {
    if (k.fn === 'case') return st.lower ? FN_LABEL.case.lower : FN_LABEL.case.upper;
    if (k.fn === 'page') return st.page === 'marks' ? FN_LABEL.page.marks : FN_LABEL.page.letters;
    if (k.fn === 'extra') return st.mode === 'answer' ? 'Clear' : 'Suggest';
    if (k.fn === 'back') return 'Back';
    return st.mode === 'answer' ? 'Answer' : 'Done';
  }
  function keyFace(ctx, m, k, r) {
    var x = k.x, y = k.y, w = k.w, h = k.h;
    if (m.shape === 'round' && k.kind === 'char') {
      var cx = x + w / 2, cy = y + h / 2, R = h / 2 + 1;
      ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.beginPath(); ctx.arc(cx + 1, cy + 3, R + 2, 0, Math.PI * 2); ctx.fill();
      var rim = ctx.createLinearGradient(0, cy - R, 0, cy + R); rim.addColorStop(0, '#eef0f4'); rim.addColorStop(0.5, '#8e929b'); rim.addColorStop(1, '#d6d9e0'); ctx.fillStyle = rim; ctx.beginPath(); ctx.arc(cx, cy, R + 2, 0, Math.PI * 2); ctx.fill();
      var gl = ctx.createRadialGradient(cx - 5, cy - 7, 2, cx, cy, R); gl.addColorStop(0, '#4a4a52'); gl.addColorStop(1, '#09090b'); ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(cx, cy, R - 1, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.18)'; ctx.beginPath(); ctx.ellipse(cx - 4, cy - 9, R * 0.55, R * 0.25, -0.3, 0, Math.PI * 2); ctx.fill();
      return;
    }
    if (m.shape === 'wax') {
      // a wax seal: an uneven disc (or an uneven bar for a function key), a pressed inner ring
      var cxw = x + w / 2, cyw = y + h / 2, rx = w / 2 + 2, ry = h / 2 + 3;
      ctx.fillStyle = 'rgba(0,0,0,0.55)'; ctx.beginPath(); ctx.ellipse(cxw + 2, cyw + 3, rx, ry, 0, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); for (var t = 0; t <= 24; t++) { var a = t / 24 * Math.PI * 2, j = 1 + (r() - 0.5) * 0.14; var px = cxw + Math.cos(a) * rx * j, py = cyw + Math.sin(a) * ry * j; if (t) ctx.lineTo(px, py); else ctx.moveTo(px, py); } ctx.closePath();
      var wg = ctx.createRadialGradient(cxw - rx * 0.3, cyw - ry * 0.4, 2, cxw, cyw, Math.max(rx, ry)); wg.addColorStop(0, m.face[0]); wg.addColorStop(1, m.face[1]); ctx.fillStyle = wg; ctx.fill();
      ctx.strokeStyle = 'rgba(30,4,12,0.6)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.ellipse(cxw, cyw, rx * 0.72, ry * 0.68, 0, 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,180,200,0.25)'; ctx.beginPath(); ctx.ellipse(cxw + 0.8, cyw + 1, rx * 0.72, ry * 0.68, 0, 0, Math.PI * 2); ctx.stroke();
      return;
    }
    // plates, tiles, stamps, bone and the wide typewriter bars
    var jit = m.shape === 'tile' ? 3 : 0;
    ctx.fillStyle = 'rgba(0,0,0,0.55)'; rr(ctx, x + 1, y + 3, w, h, m.shape === 'plate' ? 4 : 6); ctx.fill();
    if (m.shape === 'tile') { ctx.beginPath(); ctx.moveTo(x + r() * jit, y + r() * jit); ctx.lineTo(x + w - r() * jit, y + r() * jit); ctx.lineTo(x + w - r() * jit, y + h - r() * jit); ctx.lineTo(x + r() * jit, y + h - r() * jit); ctx.closePath(); }
    else rr(ctx, x, y, w, h, m.shape === 'plate' ? 4 : (m.shape === 'round' ? h / 2 : 7));
    var fg = ctx.createLinearGradient(x, y, x, y + h); fg.addColorStop(0, m.face[0]); fg.addColorStop(1, m.face[1]); ctx.fillStyle = fg; ctx.fill();
    ctx.strokeStyle = m.edge; ctx.lineWidth = m.shape === 'round' ? 2.5 : 1.5; ctx.stroke();
    if (m.shape === 'stamp') { ctx.fillStyle = 'rgba(32,22,20,0.97)'; rr(ctx, x + 5, y + 5, w - 10, h - 10, 4); ctx.fill(); ctx.strokeStyle = 'rgba(120,30,30,0.7)'; ctx.lineWidth = 1; ctx.stroke(); for (var g2 = 0; g2 < 6; g2++) { ctx.fillStyle = 'rgba(200,40,40,' + (0.15 + r() * 0.25) + ')'; ctx.beginPath(); ctx.arc(x + 7 + r() * (w - 14), y + 7 + r() * (h - 14), 0.8 + r() * 1.6, 0, Math.PI * 2); ctx.fill(); } }
    if (m.shape === 'plate') { ctx.fillStyle = 'rgba(255,248,220,0.35)'; ctx.fillRect(x + 3, y + 2, w - 6, 2); ctx.fillStyle = '#5a4318'; [[x + 5, y + h / 2], [x + w - 5, y + h / 2]].forEach(function (s) { ctx.beginPath(); ctx.arc(s[0], s[1], 1.6, 0, Math.PI * 2); ctx.fill(); }); }
    if (m.shape === 'tile') { for (var q = 0; q < 30; q++) { ctx.fillStyle = r() < 0.5 ? 'rgba(40,38,34,0.18)' : 'rgba(235,230,215,0.12)'; ctx.fillRect(x + r() * w, y + r() * h, 1.5, 1.5); } ctx.fillStyle = 'rgba(255,250,235,0.2)'; ctx.fillRect(x + 2, y + 1, w - 4, 2); }
    if (m.shape === 'bone') { ctx.strokeStyle = 'rgba(120,96,60,0.35)'; ctx.lineWidth = 0.8; for (var c = 0; c < 2; c++) { var sx = x + 6 + r() * (w - 12); ctx.beginPath(); ctx.moveTo(sx, y + 3); ctx.lineTo(sx + (r() - 0.5) * 8, y + h * (0.3 + r() * 0.5)); ctx.stroke(); } var yl = ctx.createLinearGradient(x, y, x + w, y + h); yl.addColorStop(0, 'rgba(160,120,60,0)'); yl.addColorStop(1, 'rgba(160,120,60,0.3)'); ctx.fillStyle = yl; rr(ctx, x, y, w, h, 7); ctx.fill(); }
    if (m.shape === 'round') { ctx.fillStyle = 'rgba(255,255,255,0.12)'; rr(ctx, x + 4, y + 3, w - 8, h * 0.35, h * 0.17); ctx.fill(); }
  }
  function keyLabel(ctx, m, k, label) {
    var x = k.x + k.w / 2, y = k.y + k.h / 2 + 1, isFn = k.kind === 'fn', size = isFn ? 17 : (label.length > 1 ? 13 : 21);
    if (label === ' ') { label = isFn ? label : 'space'; size = 13; }
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.font = (m.shape === 'round' ? 'bold ' : 'bold ') + size + 'px ' + m.font;
    // wax: the letter stands in relief, lit on top (LOOKED AT 2026-10-11: a dark pressed letter on dark wax could not be read)
    if (m.shape === 'wax') { ctx.fillStyle = 'rgba(30,2,10,0.85)'; ctx.fillText(label, x + 1, y + 1.5); ctx.fillStyle = 'rgba(255,210,220,0.92)'; ctx.fillText(label, x, y); return; }
    if (m.shape === 'plate' || m.shape === 'tile' || m.shape === 'bone' || m.shape === 'stamp') { ctx.fillStyle = m.lip; ctx.fillText(label, x + 0.8, y + 1.1); }
    ctx.fillStyle = m.ink; ctx.fillText(label, x, y);
  }
  /**
   * The tray: the rite's keys for one page. `labels` is 30 characters (the page), `st` carries mode/page/lower.
   * @param {CanvasRenderingContext2D} ctx 816 x 200 @param {string} riteId @param {string[]} labels @param {object} st
   */
  function tray(ctx, riteId, labels, st) {
    var m = MATERIAL[riteId] || MATERIAL.register, r = rng((st.seed || 3) ^ 0x7A11), W = L.W, H = L.TH;
    var gg = ctx.createLinearGradient(0, 0, 0, H); gg.addColorStop(0, m.ground[0]); gg.addColorStop(1, m.ground[1]); ctx.fillStyle = gg; ctx.fillRect(0, 0, W, H);
    for (var n = 0; n < 700; n++) { ctx.fillStyle = r() < 0.5 ? 'rgba(0,0,0,0.12)' : 'rgba(255,255,255,0.03)'; ctx.fillRect(r() * W, r() * H, 1 + r() * (riteId === 'register' ? 30 : 2), 1); }
    // the tray's top edge: a lit lip so the keys sit in a case, not on a band of colour
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(0, 0, W, 6); ctx.fillStyle = 'rgba(255,255,255,0.10)'; ctx.fillRect(0, 6, W, 1.5);
    for (var i = 0; i < KEYS.length; i++) {
      var k = KEYS[i], label = k.kind === 'char' ? (labels[k.i] == null ? '' : labels[k.i]) : fnLabel(k, st);
      if (k.kind === 'char' && label === '') continue;
      keyFace(ctx, m, k, r); keyLabel(ctx, m, k, label);
    }
  }
  /** the cursor: a glow around a key's outline, in the rite's own light */
  function cursor(ctx, riteId, w, h) {
    var m = MATERIAL[riteId] || MATERIAL.register, pad = 6;
    ctx.save(); ctx.shadowColor = m.glow; ctx.shadowBlur = 10; ctx.strokeStyle = m.glow; ctx.lineWidth = 2.5;
    if ((riteId === 'typewriter' && w < 100) || (riteId === 'sigil' && w < 100)) { ctx.beginPath(); ctx.ellipse(w / 2 + pad, h / 2 + pad, w / 2 + 3, h / 2 + 3, 0, 0, Math.PI * 2); ctx.stroke(); }
    else { rr(ctx, pad - 2, pad - 2, w + 4, h + 4, 8); ctx.stroke(); }
    ctx.restore();
  }

  /**
   * Draw a whole rite in one call (the contact sheets): base, text and verdict onto one context, ground included.
   * @returns {object} the text extents
   */
  function drawRite(ctx, riteId, st) { var f = pick(riteId); f.base(ctx, L.W, L.RH, st); var e = f.text(ctx, L.W, L.RH, st); if (st.verdict) f.verdict(ctx, L.W, L.RH, st, e); return e; }
  return {
    VERSION: '1.0.0', FACES: FACES, L: L, KEYS: KEYS, MATERIAL: MATERIAL, RITE_IDS: Object.keys(RITES), wheelIndex: wheelIndex,
    base: function (ctx, id, st) { pick(id).base(ctx, L.W, L.RH, st); },
    text: function (ctx, id, st) { return pick(id).text(ctx, L.W, L.RH, st); },
    verdict: function (ctx, id, st, e) { pick(id).verdict(ctx, L.W, L.RH, st, e); },
    tray: tray, cursor: cursor, drawRite: drawRite, fnLabel: fnLabel,
    /** the key under a tray-local point, or -1 */
    keyAt: function (x, y) { for (var i = 0; i < KEYS.length; i++) { var k = KEYS[i]; if (x >= k.x - 3 && x < k.x + k.w + 3 && y >= k.y - 3 && y < k.y + k.h + 3) return i; } return -1; },
  };
}());
if (typeof module !== 'undefined' && module.exports) module.exports = InscribeDraw;
