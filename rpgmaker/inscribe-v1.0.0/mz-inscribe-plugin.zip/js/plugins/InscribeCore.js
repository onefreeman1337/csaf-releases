/*:
 * @target MZ
 * @plugindesc [v1.0.0] Inscribe 1/3 - the rules: rites, the entry buffer, forgiving answer checks and name suggestions from your database. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * InscribeCore.js holds the rules Inscribe uses and touches no part of the engine. Turn it on together with
 * InscribeDraw.js and Inscribe.js; the order does not matter. See Readme_for_Users.md.
 */
/* InscribeCore - pure rules, no engine code, runs in Node for the tests (module.exports) and in MZ (window.InscribeCore).
 * Copyright (c) 2026 Core Systems Asset Factory. */
var InscribeCore = (function () {
  'use strict';

  /** seeded RNG seam: a 32-bit mix and a mulberry32-style draw. Never Math.random in game logic (wing §3). */
  function mix(a, b) { var h = (a ^ Math.imul(b | 0, 0x9E3779B1)) >>> 0; h = Math.imul(h ^ (h >>> 16), 0x85EBCA6B) >>> 0; h = Math.imul(h ^ (h >>> 13), 0xC2B2AE35) >>> 0; return (h ^ (h >>> 16)) >>> 0; }
  /** @param {string} s @returns {number} a stable 32-bit hash */
  function hashString(s) { var h = 2166136261 >>> 0; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; } return h >>> 0; }
  /** @param {{rs:number}} st @returns {number} 0..1 */
  function rand(st) { st.rs = (st.rs + 0x6D2B79F5) | 0; var t = st.rs; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }

  /** the six rites: how the name is made, the hand it is written in, the material of the drawn keys */
  var RITES = [
    { id: 'register', name: 'The Register', maxLen: 12, hand: 'ink', keys: 'brass' },
    { id: 'stone', name: 'The Stone', maxLen: 10, hand: 'chisel', keys: 'stone' },
    { id: 'papers', name: 'The Papers', maxLen: 14, hand: 'stamp', keys: 'rubber' },
    { id: 'typewriter', name: 'The Form', maxLen: 16, hand: 'type', keys: 'typebar' },
    { id: 'sigil', name: 'The Sigil', maxLen: 8, hand: 'rune', keys: 'wax' },
    { id: 'grave', name: 'The Marker', maxLen: 10, hand: 'chisel', keys: 'bone' },
  ];
  /** @param {string} id @returns {object} the rite, the register when unknown */
  function rite(id) { for (var i = 0; i < RITES.length; i++) if (RITES[i].id === id) return RITES[i]; return RITES[0]; }

  /**
   * The key pages: thirty characters each, laid three rows of ten. "letters" then "marks" (digits and the accented
   * letters names use); `lower` folds a page to lower case (ß has no single capital and stays itself).
   * @param {string} page 'letters' | 'marks' @param {boolean} lower @returns {string[]} 30 characters
   */
  var PAGE_SRC = { letters: "ABCDEFGHIJKLMNOPQRSTUVWXYZ'-. ", marks: '1234567890ÀÁÂÄÇÈÉÊËÍÏÑÓÔÖØÚÜßÆ' };
  function page(id, lower) { var a = Array.from(PAGE_SRC[id] || PAGE_SRC.letters); return lower ? a.map(function (c) { return c === 'ß' ? c : c.toLowerCase(); }) : a; }
  var PAGES = ['letters', 'marks'];

  var CONTROL = /[\u0000-\u001f\u007f-\u009f]/;
  /**
   * The entry buffer: characters are CODE POINTS (a surrogate pair is one character, kana are one each).
   * @param {number} maxLen @param {string} initial @returns {{insert:function,back:function,clear:function,text:function,length:function}}
   */
  function entry(maxLen, initial) {
    var chars = Array.from(String(initial || '')).slice(0, maxLen);
    return {
      insert: function (ch) { var a = Array.from(String(ch || '')); if (a.length !== 1 || CONTROL.test(a[0]) || chars.length >= maxLen) return false; chars.push(a[0]); return true; },
      back: function () { if (!chars.length) return false; chars.pop(); return true; },
      clear: function () { chars.length = 0; },
      text: function () { return chars.join(''); },
      length: function () { return chars.length; },
      max: maxLen,
    };
  }

  /**
   * Normalise an answer: case folded, trimmed, runs of space collapsed; accents and punctuation fold only when asked.
   * @param {string} s @param {{accents?:boolean,punctuation?:boolean}} [o] @returns {string}
   */
  function normalise(s, o) {
    o = o || {}; var t = String(s == null ? '' : s).toLowerCase();
    if (o.accents) t = t.normalize('NFD').replace(/[̀-ͯ]/g, '');
    if (o.punctuation) t = t.replace(/[^\p{L}\p{N}\s]/gu, ' ');
    return t.replace(/\s+/g, ' ').trim();
  }
  /**
   * Bounded optimal-string-alignment distance (insert, delete, substitute, adjacent transposition), stopping once
   * every cell of a row exceeds `bound` (returns bound + 1 then).
   * @param {string} a @param {string} b @param {number} bound @returns {number}
   */
  function distance(a, b, bound) {
    var A = Array.from(a), B = Array.from(b), n = A.length, m = B.length;
    if (Math.abs(n - m) > bound) return bound + 1;
    var prev2 = null, prev = [], cur;
    for (var j = 0; j <= m; j++) prev.push(j);
    for (var i = 1; i <= n; i++) {
      cur = [i]; var rowMin = i;
      for (var k = 1; k <= m; k++) {
        var cost = A[i - 1] === B[k - 1] ? 0 : 1, v = Math.min(prev[k] + 1, cur[k - 1] + 1, prev[k - 1] + cost);
        if (prev2 && i > 1 && k > 1 && A[i - 1] === B[k - 2] && A[i - 2] === B[k - 1]) v = Math.min(v, prev2[k - 2] + 1);
        cur.push(v); if (v < rowMin) rowMin = v;
      }
      if (rowMin > bound) return bound + 1;
      prev2 = prev; prev = cur;
    }
    return prev[m];
  }
  /**
   * Check a typed answer against accepted variants. The typo budget never exceeds a third of the variant's length.
   * @param {string} input @param {string[]} answers @param {{typo?:number,accents?:boolean,punctuation?:boolean}} [o]
   * @returns {{ok:boolean, matched:(string|null), distance:number}}
   */
  function check(input, answers, o) {
    o = o || {}; var x = normalise(input, o), best = { ok: false, matched: null, distance: Infinity };
    if (!x) return best;
    for (var i = 0; i < (answers || []).length; i++) {
      var want = normalise(answers[i], o); if (!want) continue;
      var budget = Math.max(0, Math.min(Math.floor(Number(o.typo) || 0), Math.floor(Array.from(want).length / 3)));
      var d = distance(x, want, budget);
      if (d <= budget && d < best.distance) best = { ok: true, matched: want, distance: d };
    }
    return best;
  }
  /**
   * An answer session: accepted variants, attempts (0 = unlimited), forgiveness options.
   * @param {{answers:string[],attempts?:number,typo?:number,accents?:boolean,punctuation?:boolean}} o
   */
  function session(o) {
    var max = Math.max(0, Math.floor(Number(o.attempts) || 0));
    var s = { used: 0, solved: false, over: false, last: null };
    s.submit = function (text) {
      if (s.solved || s.over) return { ok: false, left: 0, matched: null };
      s.used++; var r = check(text, o.answers, o); s.last = String(text == null ? '' : text);
      if (r.ok) s.solved = true; else if (max && s.used >= max) s.over = true;
      return { ok: r.ok, left: max ? Math.max(0, max - s.used) : Infinity, matched: r.matched, distance: r.distance };
    };
    return s;
  }

  // ---- name suggestions -------------------------------------------------------------------------------------------
  /** fallback corpora per rite, used when the buyer's database holds fewer than 20 usable names */
  var FALLBACK = {
    register: 'Adela Bertil Cora Dorian Edda Faramund Greta Hollis Ingrid Jory Kestrel Linnea Merrick Nolwenn Oswin Perrine Quillon Rosalind Sabine Tobias Ulla Viviane Wendel Ysabeau Zelda Anselm Brielle',
    stone: 'Aldwyn Bran Corrach Dunmore Eadric Fergus Gorm Halvard Ingold Jarnvid Kolbein Leofric Magnar Njal Orm Ragnor Sigurd Thorgar Ulfar Vandred Wulfstan Yngvar Brannoc Eirik Haldor Torsten',
    papers: 'Anton Beatrix Clement Dagny Emil Frida Gustav Helena Ivo Jolanda Konrad Lotte Matthias Nadja Otto Petra Ruben Saskia Theo Ursula Viktor Wilma Xaver Yvonne Zeno Albin Carla',
    typewriter: 'Agnes Bernard Clara Desmond Edith Floyd Gertrude Harold Irene Jasper Lillian Mabel Norman Opal Percival Ruth Stanley Thelma Virgil Walter Winifred Eugene Hazel Leopold Marion Cecil',
    sigil: 'Azrael Belith Caelum Dravos Elyon Faeryn Galeth Hesper Ithuriel Jorvath Kaelix Lucan Morvane Nyxa Orpheon Phaedra Quorith Raziel Sethis Thalor Umbriel Vesper Xandor Ysmir Zephyrin Aurelis',
    grave: 'Ambrose Bathilda Cornelius Dorothea Ebenezer Florence Gideon Hortense Ichabod Jemima Lavinia Mortimer Nathaniel Obadiah Prudence Silas Tabitha Ulysses Wilhelmina Zachariah Ezekiel Mercy Temperance Josiah Philippa Lucretia',
  };
  // a blocklist of offensive stems, ROT13-encoded so the shipped source does not print them; decoded once at load
  var BLOCK_ROT13 = 'fuvg shpx phag pbpx qvpx cvff fyhg jubre avtt snt encr anmv gjng ovgpu jnax cbea xvxr fcvp puvax ergneq cevpx';   // cevpx added 2026-10-11: names_probe v2 drew it from the register model
  function rot13(s) { return s.replace(/[a-z]/g, function (c) { return String.fromCharCode((c.charCodeAt(0) - 97 + 13) % 26 + 97); }); }
  var BLOCK = BLOCK_ROT13.split(' ').filter(function (w) { return /^[a-z]+$/.test(w); }).map(rot13);
  /** @param {string} name @returns {boolean} true when the name contains a blocklisted stem */
  function blocked(name) { var t = String(name).toLowerCase(); for (var i = 0; i < BLOCK.length; i++) if (t.indexOf(BLOCK[i]) >= 0) return true; return false; }

  /**
   * The names a project already uses: actors, classes, enemies and map names (split into words); blanks and MZ's
   * default "MAP001" ids dropped.
   * @param {{actors?:Array,classes?:Array,enemies?:Array,mapInfos?:Array}} db @returns {string[]}
   */
  function databaseNames(db) {
    // actors always (they are people); class, enemy and map words only when the BUYER wrote them: MZ's stock vocabulary
    // (STOCK, read out of the engine's own data, wing §24a) taught the model "Sworragnoc" and "Bragnome" (names_probe v1)
    var out = [], add = function (s, own) { s = String(s || '').trim(); if (s && !/^map\d+$/i.test(s) && /^[\p{L}'-]+$/u.test(s) && (own || STOCK.indexOf(s.toLowerCase()) < 0)) out.push(s); };
    (db.actors || []).forEach(function (r) { if (r && r.name) add(r.name, true); });
    ['classes', 'enemies'].forEach(function (k) { (db[k] || []).forEach(function (r) { if (r && r.name) String(r.name).split(/\s+/).forEach(function (w) { add(w, false); }); }); });
    (db.mapInfos || []).forEach(function (r) { if (r && r.name) String(r.name).split(/\s+/).forEach(function (w) { add(w, false); }); });
    return out;
  }
  /** the class, enemy and map words MZ's stock database ships (BlankProject/data; core.test re-derives this list) */
  var STOCK = ['artist', 'bandit', 'crow', 'gnome', 'goblin', 'hi_monster', 'hunter', 'knight', 'magic', 'map001', 'martial', 'priest', 'sorcerer', 'swordsman', 'treant'];
  /**
   * A name's SHAPE: no run of three consonants outside the clusters names actually use, no four, no three vowels except
   * "eau". names_probe v2: the long draws read as two names glued at a consonant pile ("Wulfarnvid", "Cedrandric").
   * @param {string} w lower-case letters @returns {boolean}
   */
  var CLUSTERS = ['str', 'thr', 'chr', 'sch', 'ght', 'tch', 'nch', 'rth', 'ndr', 'ldr', 'ngr', 'nst', 'rst', 'lfr', 'ldw'];
  function shapely(w) {
    var runs = w.match(/[^aeiouy]{3,}/g) || [];
    for (var i = 0; i < runs.length; i++) if (runs[i].length > 3 || CLUSTERS.indexOf(runs[i]) < 0) return false;
    var vs = w.match(/[aeiouy]{3,}/g) || [];
    for (var j = 0; j < vs.length; j++) if (vs[j] !== 'eau') return false;
    return true;
  }
  /** letters only, accents folded, lower case: the alphabet the model speaks */
  function clean(s) { return String(s).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z]/g, ''); }
  /**
   * An order-2 character model over the buyer's names (or the rite's fallback corpus when fewer than 20 are usable).
   * @param {string[]} names @param {string} [riteId] @returns {{suggest:function, fallback:boolean, size:number}}
   */
  function namer(names, riteId) {
    var seen = {}, own = [], corpus = [];
    (names || []).forEach(function (n) { var c = clean(n); if (c.length >= 3 && !seen[c]) { seen[c] = 1; own.push(c); } });
    var fallback = own.length < 20;
    // the rite's corpus is ALWAYS blended in (names_probe v1: with 40 database names all six rites suggested the SAME
    // names, a rite only flavoured the fallback, wing §21a); the buyer's own names weigh double when there are enough
    FALLBACK[rite(riteId).id].split(' ').forEach(function (n) { var c = clean(n); if (!seen[c]) { seen[c] = 1; corpus.push(c); } });
    var T = {}, learn = function (w) { var s = '^^' + w + '$'; for (var i = 2; i < s.length; i++) { var k = s.slice(i - 2, i); (T[k] = T[k] || []).push(s[i]); } };
    own.forEach(function (w) { learn(w); if (!fallback) learn(w); }); corpus.forEach(learn);
    corpus = own.concat(corpus);
    /** a near-copy: within one edit of a word the model learned from (names_probe v1: "Pric", "Knigh", 22%) */
    function near(w) { for (var i = 0; i < corpus.length; i++) if (distance(w, corpus[i], 1) <= 1) return true; return false; }
    function one(st, min, max) {
      var w = '', k = '^^';
      for (var g = 0; g < max + 1; g++) { var opts = T[k]; if (!opts) break; var c = opts[Math.floor(rand(st) * opts.length)]; if (c === '$') break; w += c; k = k[1] + c; }
      return w;
    }
    return {
      fallback: fallback, size: corpus.length,
      /** @param {number} n @param {number} seed @param {{min?:number,max?:number}} [o] @returns {string[]} n new names */
      suggest: function (n, seed, o) {
        // default minimum 4: LOOKED AT 2026-10-11, three-letter draws ("Mic", "Ale") read as cut-off words, not names
        // default maximum 8: names_probe v2 measured a third of draws at 8-10 letters, most of them glued pairs
        o = o || {}; var min = o.min || 4, max = o.max || 8, st = { rs: mix(hashString('inscribe'), seed >>> 0) | 0 }, out = [], have = {};
        for (var tries = 0; out.length < n && tries < n * 400; tries++) {
          var w = one(st, min, max);
          if (w.length < min || w.length > max || seen[w] || have[w] || !shapely(w) || blocked(w) || near(w)) continue;
          have[w] = 1; out.push(w[0].toUpperCase() + w.slice(1));
        }
        return out;
      },
    };
  }

  var api = { VERSION: '1.0.0', mix: mix, hashString: hashString, rand: rand, RITES: RITES, rite: rite, page: page, PAGES: PAGES, entry: entry, normalise: normalise, distance: distance,
    check: check, session: session, databaseNames: databaseNames, namer: namer, blocked: blocked, FALLBACK: FALLBACK, STOCK: STOCK, shapely: shapely,
    _blockSample: function () { return BLOCK[0]; } };
  return api;
}());
if (typeof module !== 'undefined' && module.exports) module.exports = InscribeCore;
