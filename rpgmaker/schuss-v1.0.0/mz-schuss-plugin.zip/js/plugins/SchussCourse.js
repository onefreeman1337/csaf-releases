//=============================================================================
// SchussCourse.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Schuss course engine: lays out every downhill course from a seed and runs the rider's physics. Needed by Schuss.js.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * Part of Schuss. Install SchussCourse.js, SchussDraw.js and Schuss.js and
 * turn all three ON. This file has no parameters and no commands: Schuss.js
 * holds them. It draws nothing; it decides where every tree, rock, gate,
 * ramp, rail and rapid goes, and how the rider moves.
 *
 * THE GUARANTEE. Every course is laid out around a hidden SAFE LINE first:
 * a route from the top to the bottom that a rider can actually steer at full
 * speed, through every gate, with no obstacle on it. Obstacles, pickups and
 * hazards are then placed around that line. So every course this file makes
 * can be finished cleanly, at every difficulty and every seed; harder
 * courses only make the safe line narrower and the rest of the slope
 * busier. The same seed always gives the same course.
 */

(function (root) {
  'use strict';

  //---------------------------------------------------------------------------
  // seeded randomness: a string or number seed -> a repeatable stream. Never Math.random.
  //---------------------------------------------------------------------------
  /** FNV-1a hash of a string to a 32-bit seed. @param {string|number} s @returns {number} */
  function seedOf(s) {
    var t = String(s), h = 2166136261;
    for (var i = 0; i < t.length; i++) { h ^= t.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    return h >>> 0;
  }
  /** mulberry32 stream in [0,1). @param {number} a seed @returns {function():number} */
  function rng(a) {
    a = a >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  //---------------------------------------------------------------------------
  // the five run modes. Speeds are px per frame at 60 fps; the course is COURSE_W px wide.
  //---------------------------------------------------------------------------
  var COURSE_W = 720;
  var RIDER_R = 10;
  /**
   * Per-mode physics and the obstacle corpus each mode lays out. `kinds` name the shapes SchussDraw.js draws;
   * `hard` ones crash the rider, `soft` ones are scenery the rider rides through, `ramp` launches.
   */
  var MODES = {
    ski:   { label: 'Ski',       biome: 'snow',  vMin: 2.2, vMax: 7.4, accel: 0.075, steer: 0.30, latMax: 5.0, turnCost: 0.010, lanes: 0 },
    board: { label: 'Snowboard', biome: 'snow',  vMin: 2.0, vMax: 7.0, accel: 0.070, steer: 0.34, latMax: 5.6, turnCost: 0.012, lanes: 0 },
    sled:  { label: 'Sled',      biome: 'snow',  vMin: 2.4, vMax: 6.6, accel: 0.080, steer: 0.22, latMax: 3.8, turnCost: 0.006, lanes: 0 },
    cart:  { label: 'Mine cart', biome: 'mine',  vMin: 3.0, vMax: 7.0, accel: 0.060, steer: 0,    latMax: 0,   turnCost: 0,     lanes: 3 },
    raft:  { label: 'Raft',      biome: 'river', vMin: 2.0, vMax: 5.6, accel: 0.050, steer: 0.20, latMax: 3.4, turnCost: 0.004, lanes: 0 },
  };
  /** Obstacle corpora by biome: [kind, radius, weight, role]. role: hard | soft | ramp | ice | mogul | eddy | gap | fall. */
  var CORPUS = {
    snow: [
      ['pine', 15, 9, 'hard'], ['pineTall', 17, 6, 'hard'], ['pineSnowed', 15, 5, 'hard'], ['birch', 11, 4, 'hard'],
      ['deadTree', 11, 3, 'hard'], ['stump', 9, 3, 'hard'], ['rock', 13, 5, 'hard'], ['rockPair', 16, 3, 'hard'],
      ['boulder', 18, 2, 'hard'], ['cabin', 30, 1, 'hard'], ['snowman', 11, 1, 'hard'], ['fence', 22, 2, 'hard'],
      ['signpost', 8, 1, 'hard'], ['liftPylon', 12, 1, 'hard'], ['mogul', 14, 6, 'mogul'], ['icePatch', 26, 3, 'ice'],
      ['ramp', 16, 2, 'ramp'], ['shrub', 9, 4, 'soft'], ['tuft', 7, 4, 'soft'], ['flagMarker', 6, 2, 'soft'],
    ],
    mine: [
      ['crate', 13, 6, 'hard'], ['barrel', 11, 4, 'hard'], ['rockfall', 15, 3, 'hard'], ['oreCart', 14, 2, 'hard'],
      ['buffer', 12, 1, 'hard'], ['gap', 16, 3, 'gap'], ['lantern', 7, 4, 'soft'], ['beam', 8, 4, 'soft'],
      ['crystal', 8, 3, 'soft'], ['pickaxe', 7, 2, 'soft'], ['sleeperPile', 9, 2, 'soft'],
    ],
    river: [
      ['rockWet', 14, 8, 'hard'], ['rockFlat', 12, 4, 'hard'], ['log', 20, 4, 'hard'], ['snag', 10, 3, 'hard'],
      ['buoy', 8, 1, 'hard'], ['eddy', 20, 4, 'eddy'], ['falls', 30, 1, 'fall'], ['reeds', 10, 4, 'soft'],
      ['lily', 7, 3, 'soft'], ['foam', 9, 4, 'soft'],
    ],
  };
  /** Shapes drawn along the course edges, never collided with. */
  var EDGE = { snow: ['pine', 'pineTall', 'pineSnowed', 'birch', 'rock'], mine: ['beam', 'lantern', 'crystal', 'rockfall'], river: ['reeds', 'bankStone', 'snag'] };   // banks: a dry stone, never the wet rock's foam halo (review: halos read as snow on grass)
  var GOALS = { slalom: 1, collect: 1, chase: 1 };

  /** Difficulty 1..5 -> the knobs it turns. */
  function knobs(d) {
    d = Math.max(1, Math.min(5, Math.round(+d || 3)));
    return {
      d: d,
      density: [0, 0.18, 0.26, 0.34, 0.42, 0.52][d],     // obstacles per 24 px row
      corridor: [0, 44, 38, 32, 28, 24][d],                // free half-width around the safe line, px beyond the rider
      gateW: [0, 150, 130, 112, 96, 84][d],                 // slalom gate width, px
      slope: [0, 0.42, 0.50, 0.58, 0.64, 0.70][d],          // share of the rider's steering the safe line demands
      chase: [0, 0.74, 0.80, 0.85, 0.89, 0.92][d],          // pursuer speed / the mode's top speed
      lead: [0, 520, 460, 400, 360, 320][d],                // pursuer start distance, px
    };
  }

  //---------------------------------------------------------------------------
  // the generator
  //---------------------------------------------------------------------------
  /**
   * Lay out a course.
   * @param {{mode?:string, goal?:string, seed?:string|number, difficulty?:number, seconds?:number, pickups?:number}} o
   * @returns {object} course: { mode, goal, seed, length, safe(y)->x via sample table, obstacles[], gates[], pickups[], edges[], river?, lanes? }
   */
  function generate(o) {
    o = o || {};
    var mode = MODES[o.mode] ? o.mode : 'ski', M = MODES[mode], biome = M.biome;
    var goal = GOALS[o.goal] ? o.goal : 'slalom';
    var K = knobs(o.difficulty), seedText = String(o.seed === undefined ? 1 : o.seed);
    var R = rng(seedOf(mode + '|' + goal + '|' + K.d + '|' + seedText));
    var seconds = Math.max(15, Math.min(240, +o.seconds || 60));
    var vRun = (M.vMin + M.vMax) * 0.5 + (M.vMax - M.vMin) * 0.25;
    var length = Math.round(seconds * 60 * vRun / 24) * 24;
    var START = 360, END = START + length;
    var STEP = 8, nS = Math.ceil((END + 600) / STEP) + 1;
    var safe = new Float32Array(nS);                  // the safe line, x at y = i * STEP
    var lane = mode === 'cart' ? new Int8Array(nS) : null;
    var junction = mode === 'cart' ? new Uint8Array(nS) : null;
    var river = biome === 'river' ? { cx: new Float32Array(nS), half: new Float32Array(nS) } : null;
    var margin = 70, flats = [];
    var laneX = null;
    if (mode === 'cart') {
      laneX = [COURSE_W / 2 - 150, COURSE_W / 2, COURSE_W / 2 + 150];
      // a lane sequence: changes happen only inside junction zones, each long enough to make the move
      var cur = 1, y = 0, jLen = 160;
      for (var i = 0; i < nS; i++) lane[i] = 1;
      while (y < END + 600) {
        var run = 280 + Math.floor(R() * 360);
        for (var yy = y; yy < Math.min(END + 600, y + run); yy += STEP) lane[Math.floor(yy / STEP)] = cur;
        y += run;
        if (y < START + 120 || y > END - 200) continue;
        // a junction: the zone joins two neighbouring lanes (or all three)
        for (var jy = y; jy < y + jLen && jy < END + 600; jy += STEP) junction[Math.floor(jy / STEP)] = 1;
        var next = cur + (R() < 0.5 ? -1 : 1);
        if (next < 0) next = 1; if (next > 2) next = 1;
        for (var jy2 = y; jy2 < y + jLen && jy2 < END + 600; jy2 += STEP) lane[Math.floor(jy2 / STEP)] = jy2 < y + jLen / 2 ? cur : next;
        cur = next; y += jLen;
      }
      for (var k = 0; k < nS; k++) safe[k] = laneX[lane[k]];
    } else {
      // control points every 180..340 px; the line between them is a smoothstep whose steepest slope is 1.5x the mean,
      // so the mean slope is bounded by K.slope * (latMax / vMax) / 1.5: the rider can always hold it at top speed
      var maxSlope = K.slope * (M.latMax / M.vMax) / 1.5;
      var lo = margin + 30, hi = COURSE_W - margin - 30;
      var pts = [[0, COURSE_W / 2]], py = 0, px = COURSE_W / 2, nextFlat = START + 500 + Math.floor(R() * 400);
      while (py < END + 600) {
        if (py >= nextFlat && py < END - 700) {
          // a FLAT RUN: the line holds its x for 560 px, so a ramp or a fall can sit on it (set pieces, below)
          flats.push(py + 80); py += 560; pts.push([py, px]); nextFlat = py + 900 + Math.floor(R() * 600); continue;
        }
        var dy = 180 + Math.floor(R() * 160);
        var want = lo + R() * (hi - lo), dx = Math.max(-maxSlope * dy, Math.min(maxSlope * dy, want - px));
        py += dy; px = Math.max(lo, Math.min(hi, px + dx));
        if (py < START) px = COURSE_W / 2;               // the run-in is straight down the middle
        pts.push([py, px]);
      }
      var p = 0;
      for (var s = 0; s < nS; s++) {
        var ys = s * STEP;
        while (p + 1 < pts.length && pts[p + 1][0] < ys) p++;
        var a = pts[p], b = pts[Math.min(p + 1, pts.length - 1)];
        var t = b[0] > a[0] ? (ys - a[0]) / (b[0] - a[0]) : 0; t = Math.max(0, Math.min(1, t));
        safe[s] = a[1] + (b[1] - a[1]) * t * t * (3 - 2 * t);
      }
      if (river) {
        // the river meanders around the safe line, never so narrow the line leaves it
        for (var r = 0; r < nS; r++) {
          var wob = Math.sin(r * STEP / 230 + 1.3) * 26 + Math.sin(r * STEP / 97) * 9;
          river.cx[r] = Math.max(170, Math.min(COURSE_W - 170, safe[r] + wob));
          river.half[r] = 150 + Math.sin(r * STEP / 410 + 0.4) * 40;
          var off = Math.abs(safe[r] - river.cx[r]); if (river.half[r] < off + 70) river.half[r] = off + 70;
        }
      }
    }
    function inJunction(yq) { if (!junction) return false; for (var jj = Math.max(0, Math.floor((yq - 360) / STEP)); jj <= Math.min(nS - 1, Math.floor((yq + 40) / STEP)); jj++) if (junction[jj]) return true; return false; }
    function safeAt(yq) { var i2 = Math.max(0, Math.min(nS - 1, Math.round(yq / STEP))); return safe[i2]; }

    var course = { mode: mode, goal: goal, seed: seedText, difficulty: K.d, knobs: K, start: START, end: END, length: length, width: COURSE_W,
      step: STEP, safe: safe, lane: lane, junction: junction, laneX: laneX, river: river, obstacles: [], gates: [], pickups: [], edges: [], safeAt: safeAt };

    // goal furniture first, on the safe line
    if (goal === 'slalom') {
      var gap = 300 + Math.floor(R() * 60), side = R() < 0.5 ? -1 : 1;
      for (var gy = START + 260; gy < END - 120; gy += gap + Math.floor(R() * 90)) {
        if (mode === 'cart') { var jzG = false; for (var jg = Math.max(0, Math.floor((gy - 360) / STEP)); jg <= Math.min(nS - 1, Math.floor((gy + 40) / STEP)); jg++) if (junction[jg]) { jzG = true; break; } if (jzG) continue; }
        var sx = safeAt(gy), off2 = mode === 'cart' ? 0 : side * Math.min(K.gateW * 0.22, 18), gw = mode === 'cart' ? 100 : K.gateW;
        course.gates.push({ x: Math.round(sx + off2), y: gy, w: gw, side: side, passed: false, missed: false });
        side = -side;
      }
    }
    var nPick = Math.max(0, Math.round(o.pickups === undefined ? (goal === 'collect' ? 24 : 0) : +o.pickups));
    if (nPick > 0) {
      var span = (END - START - 300) / nPick;
      for (var pi = 0; pi < nPick; pi++) {
        var pyk = Math.round(START + 200 + span * (pi + 0.25 + R() * 0.5));
        // every second pickup sits on the line; the rest a short steer off it (still inside the clear corridor)
        var ox = mode === 'cart' ? 0 : (pi % 2 === 0 ? 0 : (R() < 0.5 ? -1 : 1) * K.corridor * 0.6);
        // cart: a coin never sits in a lane change (junction plus the 360 px it takes to settle); slide it down the rail
        if (mode === 'cart') { for (var tryJ = 0; tryJ < 6 && inJunction(pyk); tryJ++) pyk += 120; if (inJunction(pyk) || pyk > END - 100) continue; }
        course.pickups.push({ x: Math.round(safeAt(pyk) + ox), y: pyk, taken: false, onLine: pi % 2 === 0 || mode === 'cart' });
      }
    }

    course.pickups.sort(function (a1, b1) { return a1.y - b1.y; });
    // obstacles: rows every 24 px, weighted kinds, rejected inside the safe corridor or on another obstacle
    var corpus = CORPUS[biome], wsum = 0;
    for (var c = 0; c < corpus.length; c++) wsum += corpus[c][2];
    function pickKind() { var u = R() * wsum; for (var c2 = 0; c2 < corpus.length; c2++) { u -= corpus[c2][2]; if (u <= 0) return corpus[c2]; } return corpus[0]; }
    var obs = course.obstacles, near = [];
    function clearOf(x, y, rad) {
      for (var n = near.length - 1; n >= 0; n--) { var q = near[n]; if (q.y < y - 80) break; var dx2 = q.x - x, dy2 = q.y - y, rr = q.r + rad + 6; if (dx2 * dx2 + dy2 * dy2 < rr * rr) return false; }
      for (var g = 0; g < course.gates.length; g++) { var G = course.gates[g]; if (Math.abs(G.y - y) < rad + 26 && Math.abs(x - G.x) < G.w / 2 + rad + 20) return false; }
      for (var pk = 0; pk < course.pickups.length; pk++) { var Q = course.pickups[pk]; if (Math.abs(Q.y - y) < rad + 18 && Math.abs(Q.x - x) < rad + 18) return false; }
      return true;
    }
    /** A launcher (ramp, fall, cart gap) never sends the rider over a pickup or into another launcher's landing. */
    function landingClear(x, y, role) {
      for (var pk2 = 0; pk2 < course.pickups.length; pk2++) { var Q2 = course.pickups[pk2]; if (Q2.y > y - 100 && Q2.y < y + 420 && Math.abs(Q2.x - x) < 60) return false; }
      for (var n2 = near.length - 1; n2 >= 0; n2--) { var q2 = near[n2]; if (q2.y < y - 460) break; if ((q2.role === 'gap' || q2.role === 'ramp' || q2.role === 'fall') && Math.abs(q2.x - x) < 60) return false; }
      return true;
    }
    function inBounds(x, y, rad) {
      if (river) { var ri = Math.max(0, Math.min(nS - 1, Math.round(y / STEP))); return Math.abs(x - river.cx[ri]) < river.half[ri] - rad - 4; }
      return x > margin - 30 + rad && x < COURSE_W - margin + 30 - rad;
    }
    for (var row = START + 120; row < END - 40; row += 24) {
      var tries = K.density + (R() < (K.density % 1) ? 1 : 0);
      tries = Math.floor(K.density * 2 + R() * 1.2);
      for (var tI = 0; tI < tries; tI++) {
        var kind = pickKind(), rad = kind[1], role = kind[3];
        var x;
        if (mode === 'cart') {
          // cart hazards sit ON a rail; scenery sits between and beside the rails
          if (role === 'soft') x = [COURSE_W / 2 - 75, COURSE_W / 2 + 75, COURSE_W / 2 - 225, COURSE_W / 2 + 225][Math.floor(R() * 4)];
          else x = laneX[Math.floor(R() * 3)];
        } else x = margin - 30 + rad + R() * (COURSE_W - 2 * (margin - 30 + rad));
        var y2 = row + Math.floor(R() * 24);
        if (!inBounds(x, y2, rad)) continue;
        var dl = Math.abs(x - safeAt(y2));
        var blocks = role === 'hard' || role === 'eddy' || (role === 'gap' && false);
        if (mode === 'cart') {
          // the safe lane may carry a gap (the rider hops it) but never a hard hazard, before, in or after a junction
          if (role !== 'soft') {
            // a lane change takes ~300 px to settle, so no hazard sits within 360 px after (or 80 px before) any junction
            var ln = laneX.indexOf(x), lo2 = Math.floor((y2 - 360) / STEP), hi2 = Math.floor((y2 + 80) / STEP), bad = false;
            for (var li = Math.max(0, lo2); li <= Math.min(nS - 1, hi2); li++) if (junction[li] || (lane[li] === ln && role !== 'gap')) { bad = true; break; }
            if (bad) continue;
          }
        } else if (blocks || role === 'ice' || role === 'fall' || role === 'mogul') {
          // hard things and eddies never touch the corridor; ice, moguls and falls may sit ON it (they slow, they do not stop)
          if (blocks && dl < K.corridor + rad + RIDER_R) continue;
          if (role === 'fall' && dl > 60) continue;
        }
        if (role === 'ramp' && mode !== 'cart' && dl > K.corridor * 0.8) continue;   // ramps are worth taking: on the line
        // a rider cannot steer in the air or on ice: a ramp, a fall or an ice patch near the line only where the line
        // runs straight for the whole flight or slide after it (measured: on a bend the autopilot landed 174 px off it)
        if ((role === 'ramp' || role === 'fall' || role === 'ice') && mode !== 'cart' && dl < K.corridor + rad + 40) {
          var run2 = role === 'ice' ? 300 : 420, s0 = safeAt(y2), straightRun = true;
          for (var sy = y2 - 60; sy <= y2 + run2; sy += 40) if (Math.abs(safeAt(sy) - s0) > 10) { straightRun = false; break; }
          if (!straightRun) continue;
        }
        if (!clearOf(x, y2, rad)) continue;
        if ((role === 'gap' || role === 'ramp' || role === 'fall') && !landingClear(x, y2, role)) continue;
        var ob = { kind: kind[0], role: role, r: rad, x: Math.round(x), y: y2, v: Math.floor(R() * 4) };
        obs.push(ob); near.push(ob);
      }
    }
    // SET PIECES on the line: a ramp (snow) or a fall (river) every 900-1500 px where the line runs straight for
    // the whole flight. Random placement alone almost never found a straight enough spot (MEASURED: no ramp on a
    // difficulty-2 ski course in 40 seeds), and a slope with no air is not the product.
    if (biome !== 'mine') {
      var feature = biome === 'river' ? CORPUS.river.filter(function (k) { return k[3] === 'fall'; })[0] : CORPUS.snow.filter(function (k) { return k[3] === 'ramp'; })[0];
      for (var fi = 0; fi < flats.length; fi++) {
        var fy = flats[fi], f0 = safeAt(fy), flat = true;
        for (var fy2 = fy - 60; fy2 <= fy + 420; fy2 += 40) if (Math.abs(safeAt(fy2) - f0) > 12) { flat = false; break; }
        if (!flat) continue;
        if (!clearOf(Math.round(f0), fy, feature[1]) || !landingClear(Math.round(f0), fy, feature[3])) continue;
        var fo = { kind: feature[0], role: feature[3], r: feature[1], x: Math.round(f0), y: fy, v: 0 };
        obs.push(fo); near.push(fo); near.sort(function (a4, b4) { return a4.y - b4.y; });
      }
    }
    obs.sort(function (a2, b2) { return a2.y - b2.y || a2.x - b2.x; });
    // edge scenery (outside the playfield), for the look only
    var edge = EDGE[biome];
    for (var ey = 0; ey < END + 600; ey += 34) {
      for (var sideE = 0; sideE < 2; sideE++) {
        var ex = sideE === 0 ? 8 + R() * (margin - 30) : COURSE_W - 8 - R() * (margin - 30);
        if (river) { var ri2 = Math.max(0, Math.min(nS - 1, Math.round(ey / STEP))); var bank = river.cx[ri2] + (sideE === 0 ? -1 : 1) * (river.half[ri2] + 26 + R() * 40); ex = bank; }
        course.edges.push({ kind: edge[Math.floor(R() * edge.length)], x: Math.round(ex), y: ey + Math.floor(R() * 20), v: Math.floor(R() * 4) });
      }
    }
    course.edges.sort(function (a3, b3) { return a3.y - b3.y; });
    course.certified = certify(course);
    return course;
  }

  /**
   * THE GUARANTEE, made constructive: ride the course once with the autopilot before anyone sees it. An obstacle the
   * ride hits is removed; a gate or an on-line pickup the ride misses is moved onto the line the ride actually took.
   * Repeat until one ride is clean (no crash, every gate, every on-line pickup, not caught). The placement rules above
   * make this rare (MEASURED by the balance probe: 7 repairs needed in 7,500 courses before this pass existed).
   * @returns {{rides:number, removed:number, moved:number, clean:boolean}}
   */
  function certify(c) {
    var removed = 0, moved = 0, rides = 0, trace = new Float32Array(c.safe.length);
    for (; rides < 24; ) {
      rides++;
      resetRun(c);
      var s = newRider(c), P = newPursuer(c), io = { steer: 0, tuck: false, brake: false, jump: false }, hitAt = -1, caught = false;
      for (var f = 0; f < 60 * 900 && !s.done; f++) {
        autopilot(c, s, io); step(c, s, io.steer, io.tuck, io.brake, io.jump);
        var ti = Math.max(0, Math.min(trace.length - 1, Math.round(s.y / c.step))); trace[ti] = s.x;
        if (s.crashes > 0) { hitAt = s.lastHitIndex; break; }
        if (stepPursuer(c, s, P)) { caught = true; break; }
      }
      if (hitAt >= 0) { c.obstacles.splice(hitAt, 1); removed++; continue; }
      if (caught) { c.knobs.lead += 120; removed++; continue; }
      var fixed = 0;
      for (var g = 0; g < c.gates.length; g++) if (c.gates[g].missed) { c.gates[g].x = Math.round(trace[Math.max(0, Math.min(trace.length - 1, Math.round(c.gates[g].y / c.step)))]); fixed++; }
      for (var q = 0; q < c.pickups.length; q++) if (c.pickups[q].onLine && !c.pickups[q].taken) { c.pickups[q].x = Math.round(trace[Math.max(0, Math.min(trace.length - 1, Math.round(c.pickups[q].y / c.step)))]); fixed++; }
      moved += fixed;
      if (!fixed) { resetRun(c); return { rides: rides, removed: removed, moved: moved, clean: true }; }
    }
    resetRun(c);
    return { rides: rides, removed: removed, moved: moved, clean: false };
  }

  //---------------------------------------------------------------------------
  // the rider: one fixed step per frame, no allocation
  //---------------------------------------------------------------------------
  /** A fresh rider at the top of the course. */
  function newRider(course) {
    var M = MODES[course.mode];
    return { x: course.safeAt(0), y: 0, vx: 0, vy: M.vMin, air: 0, airMax: 0, crash: 0, crashes: 0, lane: 1, laneT: 1, ice: 0, frames: 0,
      gatesPassed: 0, gatesMissed: 0, picked: 0, done: false, caught: false, nextGate: 0, nextPick: 0, obIndex: 0, lean: 0, jumpCool: 0, airs: 0, hits: 0, lastHit: '', lastHitIndex: -1 };
  }
  /** The pursuer for a chase run. */
  function newPursuer(course) { var K = course.knobs, M = MODES[course.mode]; return { y: -K.lead, v: M.vMax * K.chase, active: course.goal === 'chase', gap: K.lead }; }

  /**
   * Advance the rider one frame.
   * @param {object} c course @param {object} s rider state (mutated)
   * @param {number} steer -1 left, 0, 1 right @param {boolean} tuck @param {boolean} brake @param {boolean} jump (cart)
   */
  function step(c, s, steer, tuck, brake, jump) {
    if (s.done) return;
    var M = MODES[c.mode];
    s.frames++;
    if (s.jumpCool > 0) s.jumpCool--;
    // downhill speed
    var target = M.vMax * (tuck ? 1.08 : 1) * (brake ? 0.45 : 1);
    if (s.crash > 0) { s.crash--; s.vy = Math.max(M.vMin * 0.3, s.vy * 0.9); }
    else s.vy += (target - s.vy) * M.accel * 0.35 + (s.vy < target ? M.accel * 0.4 : -M.accel * 0.6);
    s.vy = Math.max(M.vMin * (s.crash > 0 ? 0.3 : 1), Math.min(M.vMax * 1.1, s.vy));
    if (c.mode === 'cart') {
      // rails: a lane change is only possible inside a junction zone
      var ji = Math.max(0, Math.min(c.junction.length - 1, Math.round(s.y / c.step)));
      if (steer !== 0 && s.laneT === s.lane && c.junction[ji] && s.air === 0) { var nl = s.lane + steer; if (nl >= 0 && nl <= 2) s.laneT = nl; }
      var tx = c.laneX[s.laneT];
      s.vx = Math.max(-4, Math.min(4, (tx - s.x) * 0.18));
      s.x += s.vx;
      if (Math.abs(tx - s.x) < 0.5) { s.x = tx; s.lane = s.laneT; }
      if (jump && s.air === 0 && s.jumpCool === 0 && s.crash === 0) { s.air = s.airMax = 26; s.airs++; s.jumpCool = 40; }
    } else {
      var grip = s.ice > 0 ? 0.30 : 1;
      if (s.ice > 0) s.ice--;
      if (s.air === 0 && s.crash === 0) s.vx += steer * M.steer * grip;
      if (steer === 0 || s.air > 0) s.vx *= s.ice > 0 ? 0.985 : 0.90;
      s.vx = Math.max(-M.latMax, Math.min(M.latMax, s.vx));
      s.vy -= Math.abs(s.vx) * M.turnCost * (s.air > 0 ? 0 : 1);
      if (c.river) {
        var ri = Math.max(0, Math.min(c.river.cx.length - 1, Math.round(s.y / c.step)));
        var cx = c.river.cx[ri], half = c.river.half[ri];
        s.vx += (cx - s.x) * 0.0016;                         // the current runs down the middle
        if (Math.abs(s.x - cx) > half - RIDER_R) { s.x = cx + Math.sign(s.x - cx) * (half - RIDER_R); s.vx = -s.vx * 0.4; s.vy *= 0.94; }
      }
      s.x += s.vx;
      var lo = 40 + RIDER_R, hi = c.width - 40 - RIDER_R;
      if (s.x < lo) { s.x = lo; s.vx = 0; } if (s.x > hi) { s.x = hi; s.vx = 0; }
    }
    s.lean += ((c.mode === 'cart' ? s.vx / 4 : s.vx / (M.latMax || 1)) - s.lean) * 0.25;
    s.y += s.vy;
    if (s.air > 0) s.air--;

    // gates and pickups (indexes advance; nothing allocated)
    while (s.nextGate < c.gates.length && c.gates[s.nextGate].y <= s.y) {
      var G = c.gates[s.nextGate];
      if (Math.abs(s.x - G.x) <= G.w / 2) { G.passed = true; s.gatesPassed++; } else { G.missed = true; s.gatesMissed++; }
      s.nextGate++;
    }
    for (var p = s.nextPick; p < c.pickups.length; p++) {
      var Q = c.pickups[p];
      if (Q.y > s.y + 20) break;
      if (!Q.taken && Q.y >= s.y - 20 && Math.abs(Q.x - s.x) < 22 && s.air === 0) { Q.taken = true; s.picked++; }
      if (Q.y < s.y - 30 && p === s.nextPick) s.nextPick++;
    }
    // obstacles in reach
    var obs = c.obstacles;
    while (s.obIndex < obs.length && obs[s.obIndex].y < s.y - 60) s.obIndex++;
    for (var i = s.obIndex; i < obs.length; i++) {
      var o = obs[i];
      if (o.y > s.y + 40) break;
      var dx = o.x - s.x, dy = o.y - s.y, rr = o.r + RIDER_R;
      if (dx * dx + dy * dy > rr * rr) continue;
      var role = o.role;
      if (role === 'soft') continue;
      if (role === 'ramp') { if (s.air === 0) { s.air = s.airMax = Math.round(14 + s.vy * 4); s.airs++; } continue; }
      if (role === 'fall') { if (s.air === 0) { s.air = s.airMax = 22; s.airs++; s.vy = Math.min(M.vMax * 1.1, s.vy + 0.8); } continue; }
      if (s.air > 0) continue;                                  // airborne: over everything
      if (role === 'ice') { s.ice = 40; continue; }
      if (role === 'mogul') { s.vy *= 0.985; continue; }
      if (role === 'eddy') { s.vx += (dx > 0 ? -1 : 1) * 0.35; s.vy *= 0.97; continue; }
      if (role === 'gap') { if (s.crash === 0) { hit(s, o, M); s.lastHitIndex = i; } continue; }
      if (s.crash === 0) { hit(s, o, M); s.lastHitIndex = i; }
    }
    if (s.y >= c.end) s.done = true;
  }
  function hit(s, o, M) {
    s.crash = 40; s.crashes++; s.hits++; s.lastHit = o.kind; s.vy = M.vMin * 0.3;
    var dx = s.x - o.x; s.vx = (dx >= 0 ? 1 : -1) * 2.5;
  }
  /** Advance the pursuer one frame; returns true when it has caught the rider. */
  function stepPursuer(c, s, P) {
    if (!P.active || s.done) return false;
    P.y += P.v;
    P.gap = s.y - P.y;
    if (P.gap <= 14) { s.caught = true; s.done = true; return true; }
    return false;
  }

  //---------------------------------------------------------------------------
  // the autopilot: rides the safe line. The guarantee's proof, and the probe's player.
  //---------------------------------------------------------------------------
  /** Inputs that follow the safe line from the rider's state (no allocation: writes into out). */
  function autopilot(c, s, out) {
    var M = MODES[c.mode], look = c.mode === 'cart' ? 40 : Math.max(24, s.vy * 9);
    out.tuck = c.goal === 'chase'; out.brake = false; out.jump = false; out.steer = 0;
    if (c.mode === 'cart') {
      var i = Math.max(0, Math.min(c.lane.length - 1, Math.round((s.y + look) / c.step)));
      var want = c.lane[i];
      if (want !== s.laneT) out.steer = want > s.laneT ? 1 : -1;
      for (var k = s.obIndex; k < c.obstacles.length; k++) { var o = c.obstacles[k]; if (o.y > s.y + 60) break; if (o.role === 'gap' && o.y > s.y + 16 && Math.abs(o.x - c.laneX[s.laneT]) < 4) out.jump = true; }
      return out;
    }
    var tx = c.safeAt(s.y + look);
    // aim at the gate or pickup coming up when it is close
    if (c.goal === 'slalom' && s.nextGate < c.gates.length && c.gates[s.nextGate].y - s.y < 160) tx = c.gates[s.nextGate].x * 0.5 + tx * 0.5;
    var predicted = s.x + s.vx * 6;
    var e = tx - predicted;
    out.steer = e > 3 ? 1 : e < -3 ? -1 : 0;
    return out;
  }
  /**
   * Run a whole course with an input source (default: the autopilot). For tests and the balance probe.
   * @returns {object} result { finished, caught, frames, seconds, crashes, gatesPassed, gatesMissed, picked, airs, minGap }
   */
  function simulate(c, input, maxFrames) {
    var s = newRider(c), P = newPursuer(c), io = { steer: 0, tuck: false, brake: false, jump: false }, minGap = Infinity;
    maxFrames = maxFrames || 60 * 600;
    for (var f = 0; f < maxFrames && !s.done; f++) {
      (input || autopilot)(c, s, io);
      step(c, s, io.steer, io.tuck, io.brake, io.jump);
      if (stepPursuer(c, s, P)) break;
      if (P.active && P.gap < minGap) minGap = P.gap;
    }
    return { finished: s.done && !s.caught, caught: s.caught, frames: s.frames, seconds: +(s.frames / 60).toFixed(2), crashes: s.crashes, lastHit: s.lastHit,
      gatesPassed: s.gatesPassed, gatesMissed: s.gatesMissed, gates: c.gates.length, picked: s.picked, pickups: c.pickups.length, airs: s.airs, minGap: P.active ? Math.round(minGap) : null };
  }
  /** Reset a course's per-run marks (gates, pickups) so the same course object can be run again. */
  function resetRun(c) { for (var i = 0; i < c.gates.length; i++) { c.gates[i].passed = c.gates[i].missed = false; } for (var j = 0; j < c.pickups.length; j++) c.pickups[j].taken = false; }

  /** Every shape name this file can lay out, by biome (SchussDraw.js must draw every one). */
  function kinds() {
    var out = {};
    for (var b in CORPUS) { out[b] = []; for (var i = 0; i < CORPUS[b].length; i++) out[b].push(CORPUS[b][i][0]); for (var j = 0; j < EDGE[b].length; j++) if (out[b].indexOf(EDGE[b][j]) < 0) out[b].push(EDGE[b][j]); }
    return out;
  }

  var API = { VERSION: '1.0.0', COURSE_W: COURSE_W, RIDER_R: RIDER_R, MODES: MODES, CORPUS: CORPUS, EDGE: EDGE, GOALS: GOALS,
    seedOf: seedOf, rng: rng, knobs: knobs, generate: generate, newRider: newRider, newPursuer: newPursuer, step: step, stepPursuer: stepPursuer,
    autopilot: autopilot, simulate: simulate, resetRun: resetRun, kinds: kinds };
  root.CSAF = root.CSAF || {};
  root.CSAF.SchussCourse = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof window !== 'undefined' ? window : this);
