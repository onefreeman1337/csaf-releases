//=============================================================================
// Schuss.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Schuss: downhill run minigames (ski, snowboard, sled, mine cart, raft) on a course the plugin lays out and draws, with your own character riding.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * Install SchussCourse.js, SchussDraw.js and Schuss.js (this file) and turn
 * all three ON. Any order works: the files find each other when a run starts.
 *
 * START A RUN from an event with the Plugin Command "Start a run", or with a
 * script call:
 *   CSAF.Schuss.start({ mode: 'ski', goal: 'slalom', seed: 7, difficulty: 3 })
 *
 * MODES   ski · board (snowboard) · sled · cart (mine cart) · raft
 * GOALS   slalom  - race the clock through the gates; a missed gate adds
 *                   seconds to your time
 *         collect - pick up coins down the course (each can give an item)
 *         chase   - something follows you down; reach the bottom first
 *
 * CONTROLS  Left / Right steer (mine cart: change rails at a switch).
 *           Down tucks (faster), Up brakes. OK hops (mine cart, over gaps).
 *           Mouse / touch: hold the left or right half of the screen.
 *           Cancel gives up the run.
 *
 * THE COURSE. Every course is laid out from the seed, so the same seed is the
 * same course every time (a best time per course is kept). Before you see a
 * course it has been ridden once by the plugin's own autopilot along a hidden
 * safe line: every course can be finished with no crash, every gate and
 * every coin on that line, at every difficulty. Blank seed = a new course
 * every run.
 *
 * THE RIDER is your party leader's walking character (or an actor you
 * choose), standing on a board, skis, sled or raft, or sitting in the cart.
 * Nothing else comes from your project: the slopes, the mine, the river,
 * every obstacle and the lettering are drawn by the plugin.
 *
 * RESULTS are written before the event continues: the time in hundredths of
 * a second, gates passed, coins picked up and crashes into variables, a
 * switch ON for a clean finish (finished, not caught), an optional common
 * event, and the item you choose given once per coin. Script calls:
 *   CSAF.Schuss.lastResult()   -> { mode, goal, seed, difficulty, finished,
 *                                   caught, time, gates, gatesMissed, coins,
 *                                   crashes, best, newBest }
 *   CSAF.Schuss.best(mode, goal, seed, difficulty) -> best time or null
 *
 * DEMO. demo: true (or the command's Demo option) lets the autopilot ride:
 * an attract screen for a title, or a preview before the player tries.
 *
 * @param varTime
 * @text Time (1/100 s) -> variable
 * @type variable
 * @default 0
 *
 * @param varGates
 * @text Gates passed -> variable
 * @type variable
 * @default 0
 *
 * @param varCoins
 * @text Coins -> variable
 * @type variable
 * @default 0
 *
 * @param varCrashes
 * @text Crashes -> variable
 * @type variable
 * @default 0
 *
 * @param swClean
 * @text Clean finish -> switch
 * @desc ON when the run reached the bottom (not caught, not given up).
 * @type switch
 * @default 0
 *
 * @param commonEvent
 * @text Common event afterwards
 * @type common_event
 * @default 0
 *
 * @param coinItem
 * @text Item per coin
 * @desc Given once for every coin picked up. None = coins only count.
 * @type item
 * @default 0
 *
 * @param missPenalty
 * @text Seconds added per missed gate
 * @type number
 * @decimals 1
 * @min 0
 * @max 30
 * @default 3.0
 *
 * @command start
 * @text Start a run
 * @desc Lay out a course and let the player ride it.
 *
 * @arg mode
 * @text Mode
 * @type select
 * @option Ski
 * @value ski
 * @option Snowboard
 * @value board
 * @option Sled
 * @value sled
 * @option Mine cart
 * @value cart
 * @option Raft
 * @value raft
 * @default ski
 *
 * @arg goal
 * @text Goal
 * @type select
 * @option Slalom (gates, against the clock)
 * @value slalom
 * @option Collect (coins)
 * @value collect
 * @option Chase (escape a pursuer)
 * @value chase
 * @default slalom
 *
 * @arg difficulty
 * @text Difficulty (1-5)
 * @type number
 * @min 1
 * @max 5
 * @default 3
 *
 * @arg seconds
 * @text Course length (seconds)
 * @desc About how long a clean run takes.
 * @type number
 * @min 15
 * @max 240
 * @default 60
 *
 * @arg seed
 * @text Seed
 * @desc Blank = a new course every run. Any text or number = the same course every time.
 * @type string
 * @default
 *
 * @arg pursuer
 * @text Pursuer (chase)
 * @type select
 * @option Yeti
 * @value yeti
 * @option Boulder
 * @value boulder
 * @option Flood wave
 * @value flood
 * @option Enemy image (below)
 * @value enemy
 * @default yeti
 *
 * @arg enemyImage
 * @text Pursuer enemy image
 * @desc Only used when Pursuer is "Enemy image".
 * @type file
 * @dir img/enemies
 * @default
 *
 * @arg actor
 * @text Rider
 * @desc None = the party leader.
 * @type actor
 * @default 0
 *
 * @arg demo
 * @text Demo (rides itself)
 * @type boolean
 * @default false
 */

var CSAF = CSAF || {};

(function () {
  'use strict';
  var NAME = 'Schuss';
  var RAW = PluginManager.parameters(NAME);
  /** Parameters arrive as strings; blank means absent, never zero (wing §16). */
  function num(v, d) { var s = String(v === undefined || v === null ? '' : v).trim(); if (s === '') return d; var n = Number(s); return isFinite(n) ? n : d; }
  var P = { varTime: num(RAW.varTime, 0), varGates: num(RAW.varGates, 0), varCoins: num(RAW.varCoins, 0), varCrashes: num(RAW.varCrashes, 0),
    swClean: num(RAW.swClean, 0), commonEvent: num(RAW.commonEvent, 0), coinItem: num(RAW.coinItem, 0), missPenalty: Math.max(0, num(RAW.missPenalty, 3)) };
  function deps() {
    var C = CSAF.SchussCourse, D = CSAF.SchussDraw;
    if (!C || !D) throw new Error('Schuss needs SchussCourse.js and SchussDraw.js installed and ON.');
    return { C: C, D: D };
  }
  function rec() { if (!$gameSystem._csafSchuss) $gameSystem._csafSchuss = { v: 1, runs: 0, best: {}, last: null }; return $gameSystem._csafSchuss; }
  function keyOf(mode, goal, seed, difficulty) { return mode + '|' + goal + '|' + seed + '|' + difficulty; }

  var pending = null;
  /**
   * Start a run. Unknown modes fall back to ski, unknown goals to slalom.
   * @param {object} args mode, goal, difficulty, seconds, seed, pursuer, enemyImage, actor, demo
   * @returns {boolean} true when the scene was pushed
   */
  function start(args) {
    args = args || {};
    var C = deps().C, r = rec();
    var mode = C.MODES[String(args.mode || '').trim()] ? String(args.mode).trim() : 'ski';
    var goal = C.GOALS[String(args.goal || '').trim()] ? String(args.goal).trim() : 'slalom';
    var seedText = String(args.seed === undefined || args.seed === null ? '' : args.seed).trim();
    var seed = seedText !== '' ? seedText : ('s' + r.runs + 'm' + ($gameMap ? $gameMap.mapId() : 0) + 'f' + Graphics.frameCount);
    var actorId = num(args.actor, 0);
    var demo = args.demo === true || String(args.demo) === 'true';
    pending = { mode: mode, goal: goal, seed: seed, fixedSeed: seedText !== '', difficulty: Math.max(1, Math.min(5, Math.round(num(args.difficulty, 3)))),
      seconds: Math.max(15, Math.min(240, num(args.seconds, 60))), pursuer: String(args.pursuer || 'yeti'), enemyImage: String(args.enemyImage || ''), actorId: actorId, demo: demo };
    SceneManager.push(Scene_Schuss);
    return true;
  }
  PluginManager.registerCommand(NAME, 'start', function (args) { start(args); });

  //---------------------------------------------------------------------------
  function Scene_Schuss() { this.initialize.apply(this, arguments); }
  Scene_Schuss.prototype = Object.create(Scene_Base.prototype);
  Scene_Schuss.prototype.constructor = Scene_Schuss;

  var STRIP_H = 128, COUNTDOWN = 150;   // a strip's upload is a hitch; 128 px halves each one (same total per distance)
  var RIDER_MAX_H = 64, RIDER_MAX_W = 72; // the largest character cell drawn at full size on the vehicle
  // The carved tracks are a pool of line sprites laid end to end in course coordinates, and every number on the HUD is
  // sprites cut from a glyph atlas painted once. Neither re-uploads a texture while the run plays: a canvas track layer
  // and a repainted clock cost 1.11 texture uploads and 1.54 bitmap dirties per frame and failed the engine gate (0.5).
  var TRACK_POOL = 360, SEG_MIN = 6;      // segments in the ring; a new segment once the rider has moved 6 px
  var GLYPHS = '0123456789:./M', HUD_SIZE = 17, ADV = HUD_SIZE * 0.86, CELL = 26, PAD = 4;
  var G_COLON = 10, G_DOT = 11, G_SLASH = 12, G_M = 13, OUTLINE = 'rgba(10,14,30,0.85)';

  Scene_Schuss.prototype.initialize = function () {
    Scene_Base.prototype.initialize.call(this);
    this._req = pending; pending = null;
    var a = null;
    if (this._req) a = this._req.actorId > 0 ? $gameActors.actor(this._req.actorId) : $gameParty.leader();
    this._actor = a;
    this._charBmp = a && a.characterName() ? ImageManager.loadCharacter(a.characterName()) : null;
    this._enemyBmp = this._req && this._req.pursuer === 'enemy' && this._req.enemyImage ? ImageManager.loadEnemy(this._req.enemyImage) : null;
    this._built = false; this._done = false; this._doneAge = 0; this._t = 0;
    this._io = { steer: 0, tuck: false, brake: false, jump: false };
  };

  Scene_Schuss.prototype.isReady = function () {
    return Scene_Base.prototype.isReady.call(this) && (!this._charBmp || this._charBmp.isReady()) && (!this._enemyBmp || this._enemyBmp.isReady());
  };

  Scene_Schuss.prototype.start = function () {
    Scene_Base.prototype.start.call(this);
    if (!this._req) { this.popScene(); return; }
    this.build();
  };

  /** Lay out the course, the strip ring, the rider, the pools and the HUD. Everything per-frame is allocated here. */
  Scene_Schuss.prototype.build = function () {
    var d = deps(), C = d.C, D = d.D, W = Graphics.width, H = Graphics.height, q = this._req;
    this._C = C; this._D = D;
    this._course = C.generate({ mode: q.mode, goal: q.goal, seed: q.seed, difficulty: q.difficulty, seconds: q.seconds });
    this._rider = C.newRider(this._course);
    this._pursuer = C.newPursuer(this._course);
    this._ox = Math.round((W - this._course.width) / 2);
    this._biome = q.mode === 'cart' ? 'mine' : q.mode === 'raft' ? 'river' : 'snow';
    // the rider sits high on the screen to see the slope coming, lower in a chase so the pursuer is in view behind
    // (first look: at 30% a pursuer 240 px back, the closest a clean run lets it get, was always off the top)
    this._riderScreenY = Math.round(H * (q.goal === 'chase' ? 0.58 : 0.30));
    this._camY = this._rider.y - this._riderScreenY;
    // the strip ring: enough strips to cover the screen plus one ahead
    this._world = new Sprite(); this.addChild(this._world);
    this._strips = [];
    var n = Math.ceil(H / STRIP_H) + 2;
    for (var i = 0; i < n; i++) {
      var sp = new Sprite(new Bitmap(W, STRIP_H)); sp._wy = Math.floor(this._camY / STRIP_H) * STRIP_H + i * STRIP_H;
      this.paintStrip(sp); this._world.addChild(sp); this._strips.push(sp);
    }
    // the carved tracks: line sprites over the ground, under everything else. The texture is a 4 px bar of the biome's
    // track colour with a clear column each side, so a bar drawn at 2.5 px keeps a soft edge when it turns.
    var tex = new Bitmap(6, 4); tex.context.fillStyle = D.PAL[this._biome].track; tex.context.fillRect(1, 0, 4, 4); tex._baseTexture.update();
    this._trackLayer = new Sprite(); this._world.addChild(this._trackLayer);
    this._trk = [];
    for (var t2 = 0; t2 < TRACK_POOL; t2++) { var ts = new Sprite(tex); ts.anchor.x = 0.5; ts.anchor.y = 0; ts.visible = false; this._trackLayer.addChild(ts); this._trk.push(ts); }
    this._trkNext = 0; this._trkX = NaN; this._trkY = NaN; this._trkSegs = 0;
    // coins
    this._coinBmp = new Bitmap(28, 32); D.drawCoin(this._coinBmp.context, 14, 13, 10, 0); this._coinBmp._baseTexture.update();
    this._coins = [];
    for (var c = 0; c < this._course.pickups.length; c++) { var cs = new Sprite(this._coinBmp); cs.anchor.x = 0.5; cs.anchor.y = 0.5; cs._q = this._course.pickups[c]; this._world.addChild(cs); this._coins.push(cs); }
    // the rider: shadow, then the composed figure (vehicle + the buyer's character)
    var sh = new Bitmap(48, 18); sh.context.fillStyle = 'rgba(30,40,70,0.32)'; sh.context.beginPath(); sh.context.ellipse(24, 9, 20, 6, 0, 0, Math.PI * 2); sh.context.fill(); sh._baseTexture.update();
    this._shadow = new Sprite(sh); this._shadow.anchor.x = 0.5; this._shadow.anchor.y = 0.5; this._world.addChild(this._shadow);
    this._riderSp = new Sprite(this.composeRider()); this._riderSp.anchor.x = 0.5; this._riderSp.anchor.y = 0.8; this._world.addChild(this._riderSp);
    // spray pool
    // spray: a powder puff with a blue-grey rim, so it reads on white snow (review: plain white dots vanished)
    var dot = new Bitmap(12, 12), dc = dot.context;
    dc.fillStyle = this._biome === 'mine' ? 'rgba(120,80,40,0.7)' : this._biome === 'river' ? 'rgba(20,70,90,0.45)' : 'rgba(110,140,190,0.55)'; dc.beginPath(); dc.arc(6, 6, 5.5, 0, Math.PI * 2); dc.fill();
    dc.fillStyle = this._biome === 'mine' ? 'rgba(255,200,120,0.95)' : 'rgba(255,255,255,0.98)'; dc.beginPath(); dc.arc(5.5, 5.5, 4, 0, Math.PI * 2); dc.fill(); dot._baseTexture.update();
    this._spray = [];
    this._fx = new Sprite(); this._world.addChildAt(this._fx, this._world.children.indexOf(this._shadow));
    for (var s = 0; s < 48; s++) { var p = new Sprite(dot); p.anchor.x = p.anchor.y = 0.5; p.visible = false; p._vx = 0; p._vy = 0; p._life = 0; this._fx.addChild(p); this._spray.push(p); }
    this._sprayNext = 0;
    // the pursuer
    this._pursuerSp = null;
    if (this._course.goal === 'chase') {
      if (this._enemyBmp && this._enemyBmp.width) { this._pursuerSp = new Sprite(this._enemyBmp); this._pursuerFrames = 0; }
      else {
        // four frames stacked in ONE bitmap, shown with setFrame (swapping bitmaps binds a new load listener every swap)
        var kind = q.pursuer === 'boulder' || q.pursuer === 'flood' ? q.pursuer : 'yeti', wide = kind === 'flood', pw = wide ? 780 : 96;
        var pb = new Bitmap(pw, 96 * 4), pg = pb.context;
        for (var f = 0; f < 4; f++) { pg.save(); pg.beginPath(); pg.rect(0, f * 96, pw, 96); pg.clip(); pg.translate(0, f * 96); D.drawPursuer(pg, kind, wide ? 390 : 48, 44, f * 4); pg.restore(); }
        pb._baseTexture.update();
        this._pursuerSp = new Sprite(pb); this._pursuerSp.setFrame(0, 0, pw, 96); this._pursuerFrames = 4; this._pursuerFrame = 0;
      }
      this._pursuerSp.anchor.x = 0.5; this._pursuerSp.anchor.y = 0.5; this.addChild(this._pursuerSp);
    }
    // the HUD
    this._hud = new Sprite(new Bitmap(W, 64)); this.addChild(this._hud); this._hudKey = -1;
    this._hudGlyphs = new Sprite(); this.addChild(this._hudGlyphs);
    this._atlas = this.glyphAtlas(); this._codes = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    this._bestKey = keyOf(this._course.mode, this._course.goal, this._course.seed, this._course.difficulty);
    this._timeField = this.field(30 + 5 * ADV, 20, 8);                                                  // after 'TIME '
    this._countField = this.field(254 + 18 + (this._course.goal === 'chase' ? 5 : 6) * ADV, 20, 9);   // after 'GATES ' / 'COINS ' / 'LEAD '
    this._banner = new Sprite(new Bitmap(W, 140)); this._banner.y = Math.round(H * 0.42) - 70; this.addChild(this._banner); this._bannerKey = -1;
    this._penalty = 0; this._built = true;
    this.drawHud(); this.drawBanner();
  };

  /** Bake one strip: ground, props, gates (SchussDraw.drawStrip), for world rows [sp._wy, sp._wy + STRIP_H). */
  Scene_Schuss.prototype.paintStrip = function (sp) {
    var b = sp.bitmap; this._D.drawStrip(b.context, this._course, sp._wy, b.width, STRIP_H, this._ox); b._baseTexture.update();
  };

  /**
   * The rider bitmap: the vehicle drawn in code with the buyer's own walking frame (facing down, middle step) on top.
   * Board, skis, sled and raft show the whole figure standing (a raft is poled standing, on the logs); the cart shows
   * head and shoulders above its rim.
   */
  Scene_Schuss.prototype.composeRider = function () {
    var mode = this._req.mode, bmp = new Bitmap(80, 96), g = bmp.context, cx = 40, base = 76;
    var seated = mode === 'cart', rim = base - 12 - 8;   // the cart is drawn at base - 12; its top edge is 8 px above that
    if (!seated) this._D.drawVehicle(g, mode, cx, mode === 'raft' ? base - 8 : base, 0, this._actor ? this._actor.actorId() % 4 : 0);
    var src = this._charBmp, ok = src && src.width > 0;
    if (ok) {
      var name = this._actor.characterName(), idx = this._actor.characterIndex(), big = ImageManager.isBigCharacter(name);
      var pw = src.width / (big ? 3 : 12), ph = src.height / (big ? 4 : 8);
      var sx = ((big ? 0 : (idx % 4) * 3) + 1) * pw, sy = (big ? 0 : Math.floor(idx / 4) * 4) * ph;   // direction 2 (down) = row 0
      var cut = seated ? Math.round(ph * 0.66) : ph;
      // a character cell larger than the standard 48 px (big `$` sheets: 64, 96, 128 px) is drawn down to fit the
      // 80 x 96 rider picture, never cropped (a 128 px cell at full size lost its head off the top)
      var k = Math.min(1, RIDER_MAX_H / ph, RIDER_MAX_W / pw), dw = Math.round(pw * k), dh = Math.round(cut * k), fh = Math.round(ph * k);
      var img = src._canvas || src._image;
      // seated: the cell's chest row sits at the rim, so head and shoulders show and the waist is inside the cart, which is
      // drawn over it (first review: the rider lay across the top; second look, on the stock RTP leader: only hair showed)
      g.drawImage(img, sx, sy, pw, cut, cx - dw / 2, seated ? rim - Math.round(fh * 0.55) : base - fh + 4, dw, dh);
    } else {
      // no character: a drawn rider in the party colours (never an engine default)
      g.fillStyle = '#2a3a6a'; g.fillRect(cx - 7, base - 34, 14, 22); g.fillStyle = '#f2d2b6'; g.beginPath(); g.arc(cx, base - 40, 7, 0, Math.PI * 2); g.fill(); g.fillStyle = '#d03a2a'; g.fillRect(cx - 8, base - 47, 16, 5);
    }
    if (seated) this._D.drawVehicle(g, mode, cx, base - 12, 0, 0);
    bmp._baseTexture.update();
    return bmp;
  };

  /** Lay one track segment (course coordinates) from the ring: a bar of width w from (x0, y0) to (x1, y1). Never allocates. */
  Scene_Schuss.prototype.segment = function (x0, y0, x1, y1, w) {
    var dx = x1 - x0, dy = y1 - y0, len = Math.sqrt(dx * dx + dy * dy); if (len < 0.5) return;
    var s = this._trk[this._trkNext]; this._trkNext = (this._trkNext + 1) % this._trk.length;
    s.visible = true; s.x = x0; s.y = y0; s.rotation = Math.atan2(-dx, dy); s.scale.x = w / 4; s.scale.y = len / 4; this._trkSegs++;
  };

  /** The rider's track behind (x, y): two ski lines, one board line, two sled runners, or the raft's wake. Never allocates. */
  Scene_Schuss.prototype.carve = function (x1, y1) {
    var mode = this._req.mode; if (mode === 'cart') return;
    if (mode === 'raft') {
      // a WAKE, not tracks: two short strokes spreading out behind the raft every few frames (review: parallel lines read as ski tracks)
      if ((this._t & 3) === 0) { this.segment(x1 - 10, y1 - 6, x1 - 22, y1 - 24, 2); this.segment(x1 + 10, y1 - 6, x1 + 22, y1 - 24, 2); }
      return;
    }
    if (this._trkX !== this._trkX) { this._trkX = x1; this._trkY = y1; return; }   // NaN: the first point after a start, a jump or a crash
    var dx = x1 - this._trkX, dy = y1 - this._trkY; if (dx * dx + dy * dy < SEG_MIN * SEG_MIN) return;
    if (mode === 'board') this.segment(this._trkX, this._trkY, x1, y1, 7);
    else { var sep = mode === 'sled' ? 9 : 5; this.segment(this._trkX - sep, this._trkY, x1 - sep, y1, 2.5); this.segment(this._trkX + sep, this._trkY, x1 + sep, y1, 2.5); }
    this._trkX = x1; this._trkY = y1;
  };

  /** Throw one spray particle (named puff: PIXI objects already own an emit() for their events, and shadowing it broke addChild). */
  Scene_Schuss.prototype.puff = function (x, y, vx, vy) {
    var p = this._spray[this._sprayNext]; this._sprayNext = (this._sprayNext + 1) % this._spray.length;
    p.visible = true; p.x = x; p.y = y; p._vx = vx; p._vy = vy; p._life = 22; p.scale.x = p.scale.y = 1; p.opacity = 255;
  };

  /** One frame of play. The only per-frame allocations are none: every object here was made in build(). */
  Scene_Schuss.prototype.update = function () {
    Scene_Base.prototype.update.call(this);
    if (!this._built) return;
    this._t++;
    var C = this._C, c = this._course, s = this._rider, io = this._io;
    if (this._done) { this._doneAge++; this.drawBanner(); if (this._doneAge > 40 && (Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered())) this.popScene(); this.place(); return; }
    if (this._t <= COUNTDOWN) {
      // Cancel gives up at any time, the countdown included (breakit A8: it was read only once the run had started)
      if (!this._req.demo && (Input.isTriggered('cancel') || TouchInput.isCancelled())) { this.finish(true); return; }
      this.drawBanner(); this.place(); this.drawHud(); return;
    }
    if (this._req.demo) C.autopilot(c, s, io);
    else {
      var tl = TouchInput.isPressed() && TouchInput.x < Graphics.width / 2, tr = TouchInput.isPressed() && TouchInput.x >= Graphics.width / 2;
      io.steer = (Input.isPressed('right') || tr ? 1 : 0) - (Input.isPressed('left') || tl ? 1 : 0);
      io.tuck = Input.isPressed('down'); io.brake = Input.isPressed('up'); io.jump = Input.isTriggered('ok') || Input.isPressed('ok');
      if (Input.isTriggered('cancel') || TouchInput.isCancelled()) { this.finish(true); return; }
    }
    var crashes = s.crashes, wasAir = s.air;
    C.step(c, s, io.steer, io.tuck, io.brake, io.jump);
    C.stepPursuer(c, s, this._pursuer);
    if (s.air === 0 && s.crash === 0) this.carve(s.x, s.y); else this._trkX = NaN;
    // spray: on a hard carve, on a landing, on a crash
    if (s.air === 0 && Math.abs(s.vx) > 1.6 && this._req.mode !== 'cart') { this.puff(s.x - Math.sign(s.vx) * 8, s.y + 4, -s.vx * 0.5, -s.vy * 0.25 - 0.8); if ((this._t & 1) === 0) this.puff(s.x - Math.sign(s.vx) * 12, s.y + 8, -s.vx * 0.8, -s.vy * 0.15 - 1.2); }
    if (wasAir > 0 && s.air === 0) for (var k = 0; k < 8; k++) this.puff(s.x + (k - 4) * 3, s.y + 4, (k - 4) * 0.5, -1.2 - (k % 3) * 0.4);
    if (s.crashes > crashes) { for (var k2 = 0; k2 < 12; k2++) this.puff(s.x, s.y, Math.cos(k2) * 2.5, Math.sin(k2) * 2.5 - 1); SoundManager.playBuzzer(); }
    if (s.done) this.finish(false);
    this.place();
    this.drawHud();
    this.drawBanner();
  };

  /** Position everything for the camera; recycle strips that scrolled off the top. */
  Scene_Schuss.prototype.place = function () {
    var s = this._rider, W = Graphics.width, H = Graphics.height;
    this._camY = s.y - this._riderScreenY;
    var n = this._strips.length;
    for (var i = 0; i < n; i++) {
      var sp = this._strips[i];
      if (sp._wy + STRIP_H < this._camY - 8) { sp._wy += n * STRIP_H; this.paintStrip(sp); }
      sp.y = Math.round(sp._wy - this._camY);
    }
    // tracks, like spray, live in course coordinates in a layer that follows the camera
    this._trackLayer.x = this._ox; this._trackLayer.y = -Math.round(this._camY);
    var airH = s.air > 0 && s.airMax > 0 ? Math.sin(Math.PI * (1 - s.air / s.airMax)) * 34 : 0;
    this._shadow.x = this._ox + s.x + airH * 0.4; this._shadow.y = s.y - this._camY + 4; this._shadow.scale.x = this._shadow.scale.y = 1 - airH / 90;
    this._riderSp.x = this._ox + s.x; this._riderSp.y = s.y - this._camY - airH;
    this._riderSp.rotation = s.crash > 0 ? Math.sin(s.crash * 0.6) * 0.5 : s.lean * (this._req.mode === 'board' ? 0.35 : 0.22);
    this._riderSp.opacity = s.crash > 0 && (s.crash >> 2) % 2 === 0 ? 150 : 255;
    for (var c = 0; c < this._coins.length; c++) {
      var cs = this._coins[c], q = cs._q, yy = q.y - this._camY;
      cs.visible = !q.taken && yy > -30 && yy < H + 30;
      if (cs.visible) { cs.x = this._ox + q.x; cs.y = yy - 10; cs.scale.x = Math.max(0.2, Math.abs(Math.cos((this._t + c * 7) * 0.08))); }
    }
    for (var p = 0; p < this._spray.length; p++) {
      var sp2 = this._spray[p]; if (!sp2.visible) continue;
      sp2._life--; if (sp2._life <= 0) { sp2.visible = false; continue; }
      sp2.x += sp2._vx; sp2.y += sp2._vy; sp2._vy += 0.12; sp2.opacity = sp2._life * 11; sp2.scale.x = sp2.scale.y = 0.5 + sp2._life / 22;
    }
    // spray lives in course coordinates, in its own layer that follows the camera
    this._fx.x = this._ox; this._fx.y = -this._camY;
    if (this._pursuerSp) {
      var P = this._pursuer, py = P.y - this._camY;
      this._pursuerSp.x = this._ox + (this._req.pursuer === 'flood' ? this._course.width / 2 : this._rider.x * 0.6 + this._course.width * 0.2);
      this._pursuerSp.y = Math.max(-40, py);
      if (this._pursuerFrames) { var pf = (this._t >> 3) & 3; if (pf !== this._pursuerFrame) { this._pursuerFrame = pf; this._pursuerSp.setFrame(0, pf * 96, this._pursuerSp.bitmap.width, 96); } }
    }
  };

  function hund(frames) { return Math.round(frames * 100 / 60); }
  function clock(h) { var m = Math.floor(h / 6000), s = Math.floor(h / 100) % 60, c = h % 100; return m + ':' + (s < 10 ? '0' : '') + s + '.' + (c < 10 ? '0' : '') + c; }

  /** The HUD digits: each glyph of GLYPHS painted ONCE in the display alphabet, row 0 its outline pass, row 1 its fill. */
  Scene_Schuss.prototype.glyphAtlas = function () {
    var b = new Bitmap(GLYPHS.length * CELL, CELL * 2), g = b.context, D = this._D;
    for (var i = 0; i < GLYPHS.length; i++) {
      D.drawText(g, GLYPHS[i], i * CELL + PAD, PAD, HUD_SIZE, OUTLINE, 'left');
      D.drawText(g, GLYPHS[i], i * CELL + PAD, CELL + PAD, HUD_SIZE, '#ffffff', 'left', false);
    }
    b._baseTexture.update();
    return b;
  };

  /** A HUD number field at (x, y), up to `max` glyphs: every outline sprite under every fill sprite, as drawText strokes. */
  Scene_Schuss.prototype.field = function (x, y, max) {
    var f = { out: [], fill: [], last: [] };
    for (var r = 0; r < 2; r++) for (var i = 0; i < max; i++) {
      var sp = new Sprite(this._atlas); sp.setFrame(0, r * CELL, CELL, CELL); sp.x = Math.round(x + i * ADV) - PAD; sp.y = y - PAD; sp.visible = false;
      this._hudGlyphs.addChild(sp); (r === 0 ? f.out : f.fill).push(sp);
    }
    for (var k = 0; k < max; k++) f.last.push(-1);
    return f;
  };

  /** Show the first n glyph codes of this._codes in field f. Only a glyph that changed moves its frame. Never allocates. */
  Scene_Schuss.prototype.setField = function (f, n) {
    for (var i = 0; i < f.out.length; i++) {
      var c = i < n ? this._codes[i] : -1;
      if (c === f.last[i]) continue;
      f.last[i] = c;
      var o = f.out[i], fl = f.fill[i];
      if (c < 0) { o.visible = false; fl.visible = false; continue; }
      o.visible = true; fl.visible = true; o.setFrame(c * CELL, 0, CELL, CELL); fl.setFrame(c * CELL, CELL, CELL, CELL);
    }
  };

  /** Write the digits of a whole number (0-999) into this._codes from index `at`; returns the next index. */
  Scene_Schuss.prototype.putNum = function (v, at) {
    var q = this._codes; v = Math.max(0, Math.min(999, Math.floor(v)));
    if (v >= 100) q[at++] = Math.floor(v / 100) % 10;
    if (v >= 10) q[at++] = Math.floor(v / 10) % 10;
    q[at++] = v % 10;
    return at;
  };

  /** M:SS.CC (MM:SS.CC past ten minutes) into this._codes; returns the glyph count. */
  Scene_Schuss.prototype.codesClock = function (h) {
    var q = this._codes, m = Math.min(99, Math.floor(h / 6000)), s = Math.floor(h / 100) % 60, c = h % 100, n = 0;
    if (m >= 10) q[n++] = Math.floor(m / 10);
    q[n++] = m % 10; q[n++] = G_COLON; q[n++] = Math.floor(s / 10); q[n++] = s % 10; q[n++] = G_DOT; q[n++] = Math.floor(c / 10); q[n++] = c % 10;
    return n;
  };

  /**
   * The HUD. The plates and their words are a bitmap repainted only when a plate changes (the chase plate turning red,
   * a best time appearing); the numbers are atlas sprites, so a running clock uploads nothing.
   */
  Scene_Schuss.prototype.drawHud = function () {
    var s = this._rider, c = this._course, D = this._D, goal = c.goal;
    var t = hund(Math.max(0, s.frames)) + Math.round(s.gatesMissed * P.missPenalty * 100);
    var gap = goal === 'chase' ? Math.max(0, Math.round(this._pursuer.gap / 10)) : 0;
    var best = rec().best[this._bestKey], key = (goal === 'chase' && gap < 12 ? 1 : 0) + (best !== undefined && this._req.fixedSeed ? 2 : 0);
    if (key !== this._hudKey) {
      this._hudKey = key;
      var b = this._hud.bitmap, g = b.context, x = 254; b.clear();
      D.plate(g, 12, 10, 230, 40, '#e8432e'); D.drawText(g, 'TIME', 30, 20, HUD_SIZE, '#ffffff', 'left');
      if (goal === 'slalom') { D.plate(g, x, 10, 200, 40, '#2a6ad0'); D.drawText(g, 'GATES', x + 18, 20, HUD_SIZE, '#ffffff', 'left'); }
      if (goal === 'collect') { D.plate(g, x, 10, 200, 40, '#f2c230'); D.drawText(g, 'COINS', x + 18, 20, HUD_SIZE, '#ffffff', 'left'); }
      if (goal === 'chase') { D.plate(g, x, 10, 200, 40, key & 1 ? '#e8432e' : '#40a070'); D.drawText(g, 'LEAD', x + 18, 20, HUD_SIZE, '#ffffff', 'left'); }
      if (key & 2) { D.plate(g, b.width - 214, 10, 200, 40, '#8a5ad0'); D.drawText(g, 'BEST ' + clock(best), b.width - 196, 20, HUD_SIZE, '#ffffff', 'left'); }
      b._baseTexture.update();
    }
    this.setField(this._timeField, this.codesClock(t));
    var n;
    if (goal === 'slalom') { n = this.putNum(s.gatesPassed, 0); this._codes[n++] = G_SLASH; n = this.putNum(c.gates.length, n); }
    else if (goal === 'collect') { n = this.putNum(s.picked, 0); this._codes[n++] = G_SLASH; n = this.putNum(c.pickups.length, n); }
    else { n = this.putNum(gap, 0); this._codes[n++] = G_M; }
    this.setField(this._countField, n);
  };

  /** The big centre lettering: the countdown, then the result plate, painted once and faded in by opacity. */
  Scene_Schuss.prototype.drawBanner = function () {
    var D = this._D, c = this._course, key;
    if (this._done) key = 200;
    else if (this._t <= COUNTDOWN) key = 100 + Math.ceil((COUNTDOWN - this._t) / 50);
    else key = this._t < COUNTDOWN + 40 ? 1 : 0;
    this._banner.opacity = this._done ? Math.min(255, Math.round(this._doneAge * 255 / 30)) : 255;
    if (key === this._bannerKey) return; this._bannerKey = key;
    var b = this._banner.bitmap, g = b.context, W = b.width; b.clear();
    if (!this._done && this._t <= COUNTDOWN) {
      var n = Math.ceil((COUNTDOWN - this._t) / 50);
      D.drawText(g, n > 0 ? String(n) : 'GO!', W / 2, 20, 64, '#ffffff', 'center');
      D.drawText(g, (c.goal === 'slalom' ? 'SLALOM' : c.goal === 'collect' ? 'COLLECT' : 'ESCAPE') + ' - ' + deps().C.MODES[c.mode].label, W / 2, 104, 16, '#ffe9a8', 'center');
    } else if (!this._done && this._t < COUNTDOWN + 40) {
      D.drawText(g, 'GO!', W / 2, 20, 64, '#ffffff', 'center');
    } else if (this._done) {
      var r = rec().last;
      D.plate(g, W / 2 - 260, 6, 520, 128, r.finished ? '#40a070' : '#e8432e');
      D.drawText(g, r.caught ? 'CAUGHT!' : r.gaveUp ? 'GAVE UP' : 'FINISH!', W / 2, 18, 40, '#ffffff', 'center');
      var line2 = 'TIME ' + clock(r.time) + (c.goal === 'slalom' ? '  GATES ' + r.gates + '/' + c.gates.length : c.goal === 'collect' ? '  COINS ' + r.coins + '/' + c.pickups.length : '') + '  CRASHES ' + r.crashes;
      D.drawText(g, line2, W / 2, 74, 15, '#ffe9a8', 'center');
      if (r.newBest) D.drawText(g, 'NEW BEST!', W / 2, 102, 15, '#8affc8', 'center');
      else D.drawText(g, 'OK TO CONTINUE', W / 2, 102, 12, 'rgba(255,255,255,0.7)', 'center');
    }
    b._baseTexture.update();
  };

  /** Close the run: results into the game, best time kept, the result plate shown. */
  Scene_Schuss.prototype.finish = function (gaveUp) {
    if (this._done) return;
    var s = this._rider, c = this._course, r = rec(), q = this._req;
    this._done = true; this._doneAge = 0; s.done = true;
    var finished = !gaveUp && !s.caught && s.y >= c.end;
    var time = hund(s.frames) + Math.round(s.gatesMissed * P.missPenalty * 100);
    var k = keyOf(c.mode, c.goal, c.seed, c.difficulty), newBest = false;
    // a demo is the autopilot riding: never a best time the player then has to beat (breakit A7)
    if (finished && q.fixedSeed && !q.demo && (r.best[k] === undefined || time < r.best[k])) { r.best[k] = time; newBest = true; }
    r.runs++;
    r.last = { mode: c.mode, goal: c.goal, seed: String(c.seed), difficulty: c.difficulty, finished: finished, caught: !!s.caught, gaveUp: !!gaveUp, time: time,
      gates: s.gatesPassed, gatesMissed: s.gatesMissed, coins: s.picked, crashes: s.crashes, best: r.best[k] === undefined ? null : r.best[k], newBest: newBest, demo: !!q.demo };
    if (!q.demo) {
      if (P.varTime > 0) $gameVariables.setValue(P.varTime, time);
      if (P.varGates > 0) $gameVariables.setValue(P.varGates, s.gatesPassed);
      if (P.varCoins > 0) $gameVariables.setValue(P.varCoins, s.picked);
      if (P.varCrashes > 0) $gameVariables.setValue(P.varCrashes, s.crashes);
      if (P.swClean > 0) $gameSwitches.setValue(P.swClean, finished);
      if (P.coinItem > 0 && s.picked > 0 && $dataItems[P.coinItem]) $gameParty.gainItem($dataItems[P.coinItem], s.picked);
      if (P.commonEvent > 0) $gameTemp.reserveCommonEvent(P.commonEvent);
    }
    if (finished) SoundManager.playOk();
    this._hudKey = -1; this.drawHud(); this.drawBanner();
  };

  CSAF.Schuss = { VERSION: '1.0.0', P: P, start: start, Scene_Schuss: Scene_Schuss,
    lastResult: function () { return $gameSystem && $gameSystem._csafSchuss ? $gameSystem._csafSchuss.last : null; },
    best: function (mode, goal, seed, difficulty) { var r = $gameSystem && $gameSystem._csafSchuss; var v = r ? r.best[keyOf(mode, goal, String(seed), Math.max(1, Math.min(5, Math.round(+difficulty || 3))))] : undefined; return v === undefined ? null : v; } };
  window.Scene_Schuss = Scene_Schuss;
})();
