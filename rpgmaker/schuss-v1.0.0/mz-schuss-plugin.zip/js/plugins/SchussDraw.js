//=============================================================================
// SchussDraw.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Schuss painter: draws every slope, mine and river, every obstacle, the rider's board, sled, cart or raft, and the HUD lettering. Needed by Schuss.js.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * Part of Schuss. Install SchussCourse.js, SchussDraw.js and Schuss.js and
 * turn all three ON. This file has no parameters and no commands. Everything
 * it draws is drawn in code onto a canvas: no image files are needed and none
 * ship. The only picture Schuss takes from your project is your own walking
 * character (and, if you choose, an enemy image for the pursuer).
 */

(function (root) {
  'use strict';

  //---------------------------------------------------------------------------
  // small helpers (drawing time only: never called per frame)
  //---------------------------------------------------------------------------
  function hash(x, y, s) { var h = (Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263) + Math.imul(s | 0, 2147483647)) >>> 0; h = Math.imul(h ^ (h >>> 13), 1274126177) >>> 0; return (h ^ (h >>> 16)) / 4294967296; }
  function mix(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }
  function rgb(c, a) { return 'rgba(' + Math.round(c[0]) + ',' + Math.round(c[1]) + ',' + Math.round(c[2]) + ',' + (a === undefined ? 1 : a) + ')'; }
  function ell(g, x, y, rx, ry, fill) { g.fillStyle = fill; g.beginPath(); g.ellipse(x, y, Math.max(0.1, rx), Math.max(0.1, ry), 0, 0, Math.PI * 2); g.fill(); }
  function poly(g, pts, fill, stroke, lw) { g.beginPath(); g.moveTo(pts[0], pts[1]); for (var i = 2; i < pts.length; i += 2) g.lineTo(pts[i], pts[i + 1]); g.closePath(); if (fill) { g.fillStyle = fill; g.fill(); } if (stroke) { g.strokeStyle = stroke; g.lineWidth = lw || 1; g.stroke(); } }
  function line(g, x0, y0, x1, y1, col, w) { g.strokeStyle = col; g.lineWidth = w; g.beginPath(); g.moveTo(x0, y0); g.lineTo(x1, y1); g.stroke(); }

  /** Biome palettes. Snow is cool white with blue shadow; mine is warm umber with lamplight; river is teal on sand. */
  var PAL = {
    snow: { base: [236, 242, 250], shade: [196, 212, 232], deep: [160, 182, 214], spark: [255, 255, 255], track: 'rgba(150,172,206,0.55)', shadow: 'rgba(70,96,140,0.28)' },
    mine: { base: [74, 56, 44], shade: [52, 39, 31], deep: [34, 26, 21], spark: [255, 196, 120], track: 'rgba(0,0,0,0)', shadow: 'rgba(10,6,4,0.45)' },
    river: { base: [44, 128, 146], shade: [30, 100, 122], deep: [20, 72, 96], spark: [220, 248, 250], track: 'rgba(225,250,252,0.40)', shadow: 'rgba(8,40,52,0.35)', bank: [204, 186, 140], grass: [112, 140, 72] },
  };

  //---------------------------------------------------------------------------
  // GROUND: one horizontal strip of the course, world rows [y0, y0+h), into a canvas of width W
  //---------------------------------------------------------------------------
  /**
   * Paint the ground of one strip, then every edge prop and obstacle whose drawing reaches into it.
   * @param {CanvasRenderingContext2D} g @param {object} c course @param {number} y0 world y of the strip top
   * @param {number} W canvas width @param {number} h strip height @param {number} ox screen x of course x = 0
   */
  function drawStrip(g, c, y0, W, h, ox) {
    var biome = c.mode === 'cart' ? 'mine' : c.mode === 'raft' ? 'river' : 'snow', P = PAL[biome];
    g.clearRect(0, 0, W, h);
    if (biome === 'snow') snowGround(g, c, y0, W, h, ox, P);
    else if (biome === 'mine') mineGround(g, c, y0, W, h, ox, P);
    else riverGround(g, c, y0, W, h, ox, P);
    // finish line
    if (c.end >= y0 - 40 && c.end <= y0 + h + 40) finishLine(g, ox, c.end - y0, c.width, biome);
    if (c.start >= y0 - 40 && c.start <= y0 + h + 40) startLine(g, ox, c.start - y0, c.width, biome);
    // props: edges then obstacles, in y order, each with its own shadow first
    var list = [c.edges, c.obstacles];
    for (var L = 0; L < 2; L++) {
      var arr = list[L];
      for (var i = 0; i < arr.length; i++) {
        var o = arr[i];
        if (o.y < y0 - 90) continue; if (o.y > y0 + h + 60) break;
        drawKind(g, o.kind, ox + o.x, o.y - y0, o.v || 0, biome);
      }
    }
    // gates
    for (var gI = 0; gI < c.gates.length; gI++) {
      var G = c.gates[gI];
      if (G.y < y0 - 60 || G.y > y0 + h + 40) continue;
      gate(g, ox + G.x, G.y - y0, G.w, gI % 2 === 0 ? [214, 46, 52] : [40, 92, 196], biome);
    }
  }

  function snowGround(g, c, y0, W, h, ox, P) {
    // the slope's light: bands of shadow across the fall line, gentle and seeded by world y so strips join
    for (var y = 0; y < h; y += 4) {
      var wy = y0 + y, t = 0.5 + 0.5 * Math.sin(wy / 190) * Math.sin(wy / 73 + 1.7);
      g.fillStyle = rgb(mix(P.base, P.shade, t * 0.55)); g.fillRect(0, y, W, 4);
    }
    // groomed corduroy, faint
    g.strokeStyle = 'rgba(176,196,226,0.18)'; g.lineWidth = 1;
    for (var x = ox; x < ox + c.width; x += 6) { g.beginPath(); g.moveTo(x + 0.5, 0); g.lineTo(x + 0.5, h); g.stroke(); }
    // wind ridges and blue hollows
    for (var k = 0; k < 18; k++) {
      var hy = Math.floor(y0 / 64) * 64, yy = hy + k * 64 - y0 + hash(k, hy, 3) * 40, xx = ox - 40 + hash(hy, k, 5) * (c.width + 80);
      if (yy < -60 || yy > h + 60) continue;
      var gr = g.createRadialGradient(xx, yy, 2, xx, yy, 60); gr.addColorStop(0, 'rgba(150,176,214,0.20)'); gr.addColorStop(1, 'rgba(150,176,214,0)');
      g.fillStyle = gr; g.fillRect(xx - 60, yy - 30, 120, 60);
      g.strokeStyle = 'rgba(255,255,255,0.65)'; g.lineWidth = 1.2; g.beginPath(); g.moveTo(xx - 46, yy - 6); g.quadraticCurveTo(xx, yy - 16, xx + 46, yy - 4); g.stroke();
    }
    // sparkle
    for (var s = 0; s < h * 0.9; s++) { var sy = Math.floor(hash(s, y0, 11) * h), sx = Math.floor(hash(y0, s, 13) * W); g.fillStyle = 'rgba(255,255,255,' + (0.4 + hash(s, s, 17) * 0.6) + ')'; g.fillRect(sx, sy, 1, 1); }
    // the piste's edges: deeper powder beyond the groomed width
    var gEdge = g.createLinearGradient(0, 0, ox + 40, 0); gEdge.addColorStop(0, 'rgba(176,196,226,0.55)'); gEdge.addColorStop(1, 'rgba(176,196,226,0)');
    g.fillStyle = gEdge; g.fillRect(0, 0, ox + 40, h);
    var gEdge2 = g.createLinearGradient(ox + c.width - 40, 0, W, 0); gEdge2.addColorStop(0, 'rgba(176,196,226,0)'); gEdge2.addColorStop(1, 'rgba(176,196,226,0.55)');
    g.fillStyle = gEdge2; g.fillRect(ox + c.width - 40, 0, W - ox - c.width + 40, h);
  }

  /** A reusable full-resolution pixel buffer for the mine floor, rebuilt only when its size changes. */
  var FLOOR = { img: null, px: null, w: 0, h: 0 };
  var LITTLE = new Uint8Array(new Uint32Array([1]).buffer)[0] === 1;
  function floorBuffer(w, h) {
    if (FLOOR.w !== w || FLOOR.h !== h) { FLOOR.img = new ImageData(w, h); FLOOR.px = new Uint32Array(FLOOR.img.data.buffer); FLOOR.w = w; FLOOR.h = h; }
    return FLOOR;
  }

  function mineGround(g, c, y0, W, h, ox, P) {
    g.fillStyle = rgb(P.deep); g.fillRect(0, 0, W, h);
    // the floor: packed earth between the walls, mottled in 6 px cells, written straight into the strip with ONE
    // putImageData (opaque, over the deep fill, exactly where the cells go). ~2,300 fillRects per strip made the cart's strip
    // repaint the engine gate's p99 stutter frame; a cell-canvas drawn up 6x fixed the cost but made Chrome render the
    // later layers on another backend, 1 strip in 135 off by a few levels (_probe/strip_equiv.js), so no second canvas.
    var fx = ox - 20, cols = Math.ceil((c.width + 40) / 6), rows = Math.ceil(h / 6), bw = cols * 6, bh = Math.min(h, rows * 6);
    var F = floorBuffer(bw, bh), px = F.px;
    for (var j = 0; j < rows; j++) for (var i = 0; i < cols; i++) {
      var n = hash((fx + i * 6) >> 3, (y0 + j * 6) >> 3, 7) * 0.8;
      var r = Math.round(P.base[0] + (P.shade[0] - P.base[0]) * n), gg = Math.round(P.base[1] + (P.shade[1] - P.base[1]) * n), b = Math.round(P.base[2] + (P.shade[2] - P.base[2]) * n);
      var v = LITTLE ? ((255 << 24) | (b << 16) | (gg << 8) | r) >>> 0 : ((r << 24) | (gg << 16) | (b << 8) | 255) >>> 0;
      for (var yy = j * 6, ye = Math.min(bh, yy + 6); yy < ye; yy++) for (var xx = i * 6, row = yy * bw; xx < i * 6 + 6; xx++) px[row + xx] = v;
    }
    g.putImageData(F.img, fx, 0);
    // the walls: rough rock faces with lamplit edges
    for (var side = 0; side < 2; side++) {
      for (var wy = Math.floor(y0 / 20) * 20 - 20; wy < y0 + h + 20; wy += 20) {
        var inset = 20 + hash(wy, side, 9) * 26, x0 = side === 0 ? 0 : ox + c.width - inset + 6, x1 = side === 0 ? ox + inset - 6 : W;
        g.fillStyle = rgb(mix([44, 34, 28], [28, 21, 17], hash(wy, side, 4))); g.fillRect(x0, wy - y0, x1 - x0, 22);
        g.fillStyle = 'rgba(255,190,110,0.10)'; g.fillRect(side === 0 ? x1 - 3 : x0, wy - y0, 3, 22);
      }
    }
    // rails: sleepers then two rails per lane; junction zones get the crossover
    for (var l = 0; l < c.laneX.length; l++) {
      var lx = ox + c.laneX[l];
      for (var sy = Math.floor((y0 - 20) / 26) * 26; sy < y0 + h + 26; sy += 26) {
        var syy = sy - y0; g.fillStyle = '#5a3c24'; g.fillRect(lx - 20, syy, 40, 8); g.fillStyle = 'rgba(255,210,150,0.10)'; g.fillRect(lx - 20, syy, 40, 2); g.fillStyle = 'rgba(0,0,0,0.30)'; g.fillRect(lx - 20, syy + 7, 40, 2);
      }
      for (var r = -1; r <= 1; r += 2) { g.fillStyle = '#2a2c30'; g.fillRect(lx + r * 12 - 2, 0, 4, h); g.fillStyle = 'rgba(220,226,236,0.75)'; g.fillRect(lx + r * 12 - 1, 0, 1.5, h); }
    }
    // junction zones: a switch, drawn as a second pair of rails curving across to each neighbouring lane, plus the
    // lamp-lit switch stand at the zone's head (first look: dotted diagonals in a bright box read as a crate lid)
    for (var jy = -40; jy < h + 40; jy += 2) {
      var wj = y0 + jy, ji = Math.max(0, Math.min(c.junction.length - 1, Math.round(wj / c.step)));
      if (!c.junction[ji]) continue;
      var head = !c.junction[Math.max(0, ji - 1)];
      var z0 = ji; while (z0 > 0 && c.junction[z0 - 1]) z0--;
      var tz = Math.min(1, (wj - z0 * c.step) / 160), e = tz * tz * (3 - 2 * tz);
      for (var a = 0; a < 2; a++) {
        var xa = ox + c.laneX[a], xb = ox + c.laneX[a + 1];
        var xm = xa + (xb - xa) * e, xm2 = xb - (xb - xa) * e;
        for (var rr = -1; rr <= 1; rr += 2) { g.fillStyle = '#2a2c30'; g.fillRect(xm + rr * 12 - 2, jy, 4, 2); g.fillRect(xm2 + rr * 12 - 2, jy, 4, 2); g.fillStyle = 'rgba(220,226,236,0.75)'; g.fillRect(xm + rr * 12 - 1, jy, 1.5, 2); g.fillRect(xm2 + rr * 12 - 1, jy, 1.5, 2); }
      }
      if (head) for (var a2 = 0; a2 < 3; a2++) {
        var sx = ox + c.laneX[a2] + 26;
        line(g, sx, jy, sx, jy - 22, '#2a2a2e', 2.5); poly(g, [sx - 6, jy - 30, sx + 6, jy - 30, sx + 6, jy - 22, sx - 6, jy - 22], '#f2c230', '#1a1a1a', 1);
        line(g, sx - 4, jy - 26, sx + 4, jy - 26, '#1a1a1a', 2); poly(g, [sx + 4, jy - 29, sx + 7, jy - 26, sx + 4, jy - 23], '#1a1a1a');
      }
    }
  }

  function riverGround(g, c, y0, W, h, ox, P) {
    // banks
    g.fillStyle = rgb(P.grass); g.fillRect(0, 0, W, h);
    for (var y = 0; y < h; y += 3) {
      var ri = Math.max(0, Math.min(c.river.cx.length - 1, Math.round((y0 + y) / c.step)));
      var cx = ox + c.river.cx[ri], half = c.river.half[ri];
      // sand margin, then water with depth: darker down the middle
      g.fillStyle = rgb(P.bank); g.fillRect(cx - half - 18, y, (half + 18) * 2, 3);
      var gw = g.createLinearGradient(cx - half, 0, cx + half, 0);
      gw.addColorStop(0, rgb(P.base)); gw.addColorStop(0.5, rgb(P.deep)); gw.addColorStop(1, rgb(P.base));
      g.fillStyle = gw; g.fillRect(cx - half, y, half * 2, 3);
      g.fillStyle = 'rgba(255,255,255,0.35)'; g.fillRect(cx - half, y, 2, 3); g.fillRect(cx + half - 2, y, 2, 3);
    }
    // grass texture on the banks
    for (var s = 0; s < h * 1.5; s++) { var sy = hash(s, y0, 21) * h, sx = hash(y0, s, 23) * W; g.fillStyle = hash(s, 1, y0) < 0.5 ? 'rgba(80,110,50,0.6)' : 'rgba(150,176,96,0.5)'; g.fillRect(sx, sy, 2, 3); }
    // current streaks: long pale dashes running downstream
    for (var k = 0; k < 40; k++) {
      var base = Math.floor(y0 / 40) * 40, wy = base + k * 22, yy = wy - y0 + hash(k, base, 3) * 10;
      if (yy < -30 || yy > h + 30) continue;
      var ri2 = Math.max(0, Math.min(c.river.cx.length - 1, Math.round(wy / c.step)));
      var xx = ox + c.river.cx[ri2] + (hash(base, k, 7) * 2 - 1) * c.river.half[ri2] * 0.8;
      line(g, xx, yy, xx + 1, yy + 18 + hash(k, k, base) * 16, 'rgba(220,248,250,0.35)', 1.5);
    }
  }

  function finishLine(g, ox, y, w, biome) {
    var sq = 12;
    for (var x = 0; x < w; x += sq) for (var r = 0; r < 2; r++) { g.fillStyle = ((x / sq) + r) % 2 ? '#14161c' : '#f4f4f0'; g.fillRect(ox + x, y + r * sq - sq, sq, sq); }
    for (var s = 0; s < 2; s++) { var px = ox + (s ? w - 6 : 6); line(g, px, y - 70, px, y, '#3a3a44', 4); poly(g, [px, y - 70, px + (s ? -34 : 34), y - 60, px, y - 50], '#e43a3a'); }
  }
  /** The start: a rope of red and white pennants between two posts (first look: a bare blue line read as a stray). */
  function startLine(g, ox, y, w, biome) {
    var x0 = ox + 40, x1 = ox + w - 40;
    for (var s = 0; s < 2; s++) { var px = s ? x1 : x0; ell(g, px + 4, y + 2, 7, 3, 'rgba(0,0,0,0.25)'); line(g, px, y, px, y - 26, '#3a3a44', 3); }
    g.strokeStyle = 'rgba(40,40,50,0.7)'; g.lineWidth = 1; g.beginPath(); g.moveTo(x0, y - 24); g.quadraticCurveTo((x0 + x1) / 2, y - 12, x1, y - 24); g.stroke();
    for (var k = 1; k < 40; k++) { var t = k / 40, px2 = x0 + (x1 - x0) * t, py = y - 24 + 12 * 4 * t * (1 - t); poly(g, [px2 - 4, py, px2 + 4, py, px2, py + 8], k % 2 ? '#e8432e' : '#f4f4f0'); }
  }

  /** A slalom gate: two poles with pennants, a dotted line between them on the snow. */
  function gate(g, x, y, w, col, biome) {
    var h = w / 2;
    g.setLineDash([4, 6]); line(g, x - h, y, x + h, y, rgb(col, 0.35), 2); g.setLineDash([]);
    for (var s = -1; s <= 1; s += 2) {
      var px = x + s * h;
      ell(g, px + 6, y + 3, 9, 3, 'rgba(40,60,100,0.25)');
      line(g, px, y, px, y - 40, '#24262e', 3);
      poly(g, [px, y - 40, px + s * -22, y - 34, px, y - 26], rgb(col), 'rgba(0,0,0,0.35)', 1);
      line(g, px, y - 40, px, y - 26, 'rgba(255,255,255,0.6)', 1);
    }
  }

  //---------------------------------------------------------------------------
  // THE OBSTACLE CORPUS: every kind SchussCourse.js can lay out, each drawn at (x, y) = its base on the ground
  //---------------------------------------------------------------------------
  var KIND = {};
  function shadow(g, x, y, rx, ry) { ell(g, x + rx * 0.35, y + ry * 0.2, rx, ry, 'rgba(40,60,100,0.25)'); }
  function shadowDark(g, x, y, rx, ry) { ell(g, x + rx * 0.3, y + ry * 0.2, rx, ry, 'rgba(0,0,0,0.38)'); }
  function conifer(g, x, y, s, tiers, col, snow) {
    shadow(g, x + 4, y + 2, 15 * s, 6 * s);
    g.fillStyle = '#5a3a22'; g.fillRect(x - 2.5 * s, y - 6 * s, 5 * s, 8 * s);
    for (var t = 0; t < tiers; t++) {
      var w = (16 - t * 3.6) * s, top = y - (14 + t * 10) * s - 8 * s, base = y - (4 + t * 10) * s;
      poly(g, [x, top, x + w, base, x - w, base], rgb(mix(col, [10, 30, 20], t * 0.08)));
      poly(g, [x, top, x + w, base, x + w * 0.2, base], 'rgba(0,0,0,0.18)');
      if (snow) { g.fillStyle = 'rgba(250,252,255,0.92)'; g.beginPath(); g.moveTo(x - w * 0.86, base - 1); g.quadraticCurveTo(x - w * 0.3, base - 6 * s, x, top + 3 * s); g.quadraticCurveTo(x - w * 0.1, base - 2 * s, x - w * 0.86, base - 1); g.fill(); }
    }
  }
  KIND.pine = function (g, x, y, v) { conifer(g, x, y, 1, 3, [34, 92, 62], false); };
  KIND.pineTall = function (g, x, y, v) { conifer(g, x, y, 1.15, 4, [28, 80, 58], false); };
  KIND.pineSnowed = function (g, x, y, v) { conifer(g, x, y, 1, 3, [40, 96, 70], true); };
  KIND.birch = function (g, x, y, v) {
    shadow(g, x + 3, y + 2, 10, 4);
    g.fillStyle = '#f0ede4'; g.fillRect(x - 2.5, y - 34, 5, 34);
    for (var i = 0; i < 6; i++) { g.fillStyle = '#2a2622'; g.fillRect(x - 2.5 + (i % 2) * 2, y - 30 + i * 5, 3, 1.5); }
    var leaf = v % 2 ? [214, 170, 60] : [198, 146, 52];
    for (var k = 0; k < 7; k++) ell(g, x + Math.cos(k * 0.9) * 9, y - 40 + Math.sin(k * 1.7) * 7, 7, 6, rgb(mix(leaf, [120, 80, 30], k * 0.06)));
  };
  KIND.deadTree = function (g, x, y, v) {
    shadow(g, x + 3, y + 2, 10, 4);
    line(g, x, y, x + 1, y - 34, '#4a3a30', 4);
    line(g, x, y - 18, x - 10, y - 30, '#4a3a30', 2.5); line(g, x + 1, y - 24, x + 11, y - 36, '#4a3a30', 2.5); line(g, x - 6, y - 25, x - 12, y - 24, '#4a3a30', 1.5);
    g.fillStyle = 'rgba(255,255,255,0.85)'; g.fillRect(x - 10, y - 31, 6, 2); g.fillRect(x + 6, y - 37, 6, 2);
  };
  KIND.stump = function (g, x, y, v) { shadow(g, x, y + 2, 10, 4); g.fillStyle = '#6a4a30'; g.fillRect(x - 7, y - 9, 14, 9); ell(g, x, y - 9, 7, 3, '#c8a070'); g.strokeStyle = '#8a6440'; g.lineWidth = 1; g.beginPath(); g.ellipse(x, y - 9, 4, 1.6, 0, 0, 6.3); g.stroke(); ell(g, x, y - 11, 7, 2.5, 'rgba(255,255,255,0.9)'); };
  function rockShape(g, x, y, s, base, snowCap, wet) {
    var pts = [x - 13 * s, y, x - 11 * s, y - 9 * s, x - 4 * s, y - 15 * s, x + 6 * s, y - 13 * s, x + 13 * s, y - 5 * s, x + 12 * s, y];
    poly(g, pts, rgb(base));
    poly(g, [x - 4 * s, y - 15 * s, x + 6 * s, y - 13 * s, x + 13 * s, y - 5 * s, x + 2 * s, y - 6 * s], rgb(mix(base, [255, 255, 255], 0.22)));
    poly(g, [x - 13 * s, y, x - 11 * s, y - 9 * s, x - 2 * s, y - 4 * s, x + 12 * s, y], rgb(mix(base, [0, 0, 0], 0.25)));
    if (snowCap) { g.fillStyle = 'rgba(250,252,255,0.95)'; g.beginPath(); g.moveTo(x - 9 * s, y - 10 * s); g.quadraticCurveTo(x, y - 18 * s, x + 9 * s, y - 11 * s); g.quadraticCurveTo(x, y - 12 * s, x - 9 * s, y - 10 * s); g.fill(); }
    if (wet) { line(g, x - 6 * s, y - 11 * s, x + 3 * s, y - 12 * s, 'rgba(255,255,255,0.7)', 1.5); }
  }
  KIND.rock = function (g, x, y, v) { shadow(g, x, y + 1, 15, 5); rockShape(g, x, y, 1, [112, 118, 132], true, false); };
  KIND.rockPair = function (g, x, y, v) { shadow(g, x, y + 1, 20, 6); rockShape(g, x - 7, y, 0.8, [104, 110, 126], true, false); rockShape(g, x + 9, y + 2, 0.65, [124, 128, 140], false, false); };
  KIND.boulder = function (g, x, y, v) { shadow(g, x + 2, y + 2, 20, 7); ell(g, x, y - 13, 18, 15, '#7c8292'); ell(g, x - 5, y - 18, 10, 7, 'rgba(255,255,255,0.20)'); ell(g, x + 6, y - 7, 11, 7, 'rgba(0,0,0,0.18)'); g.fillStyle = 'rgba(250,252,255,0.95)'; g.beginPath(); g.ellipse(x - 2, y - 25, 12, 4, -0.1, 0, 6.3); g.fill(); };
  KIND.cabin = function (g, x, y, v) {
    shadow(g, x + 8, y + 3, 34, 9);
    g.fillStyle = '#7a4a2a'; g.fillRect(x - 26, y - 26, 52, 26);
    for (var i = 0; i < 5; i++) { g.fillStyle = i % 2 ? '#6a3e22' : '#84502e'; g.fillRect(x - 26, y - 26 + i * 5.2, 52, 5.2); }
    poly(g, [x - 32, y - 24, x, y - 46, x + 32, y - 24], '#f6f8fc', 'rgba(120,140,170,0.6)', 1);
    poly(g, [x, y - 46, x + 32, y - 24, x + 10, y - 24], 'rgba(150,170,200,0.45)');
    g.fillStyle = '#ffd27a'; g.fillRect(x - 16, y - 18, 10, 9); g.fillStyle = '#3a2416'; g.fillRect(x + 6, y - 16, 10, 16);
    g.fillStyle = '#4a3a34'; g.fillRect(x + 14, y - 50, 6, 12); ell(g, x + 17, y - 56, 5, 3, 'rgba(230,232,240,0.7)');
  };
  KIND.snowman = function (g, x, y, v) { shadow(g, x, y + 1, 12, 4); ell(g, x, y - 8, 11, 9, '#f8fafe'); ell(g, x, y - 22, 8, 7, '#f8fafe'); ell(g, x + 3, y - 7, 6, 6, 'rgba(150,170,200,0.35)'); g.fillStyle = '#e8762a'; poly(g, [x, y - 22, x + 8, y - 21, x, y - 20], '#e8762a'); g.fillStyle = '#222'; g.fillRect(x - 3, y - 25, 2, 2); g.fillRect(x + 1, y - 25, 2, 2); g.fillStyle = '#c03030'; g.fillRect(x - 7, y - 16, 14, 3); };
  KIND.fence = function (g, x, y, v) { shadow(g, x, y + 2, 24, 4); for (var i = -2; i <= 2; i++) { g.fillStyle = '#7a5434'; g.fillRect(x + i * 10 - 1.5, y - 16, 3, 16); } g.fillStyle = '#8a6040'; g.fillRect(x - 22, y - 13, 44, 3); g.fillRect(x - 22, y - 7, 44, 3); g.fillStyle = '#e83a2a'; g.fillRect(x - 22, y - 13, 44, 1.2); g.fillStyle = 'rgba(255,255,255,0.9)'; g.fillRect(x - 22, y - 16, 44, 1.5); };
  KIND.signpost = function (g, x, y, v) { shadow(g, x, y + 1, 7, 3); line(g, x, y, x, y - 24, '#4a3a2a', 2.5); poly(g, [x - 10, y - 30, x + 10, y - 30, x + 14, y - 25, x + 10, y - 20, x - 10, y - 20], v % 2 ? '#2a6ad0' : '#1a1a1a', 'rgba(255,255,255,0.7)', 1); g.fillStyle = '#fff'; if (v % 2) { ell(g, x - 1, y - 25, 3, 3, '#fff'); } else { poly(g, [x - 4, y - 25, x, y - 29, x + 4, y - 25, x, y - 21], '#fff'); } };
  KIND.liftPylon = function (g, x, y, v) { shadow(g, x + 6, y + 2, 12, 4); g.fillStyle = '#9aa2b0'; poly(g, [x - 6, y, x - 3, y - 44, x + 3, y - 44, x + 6, y], '#9aa2b0', '#5a626e', 1); g.fillStyle = '#5a626e'; g.fillRect(x - 16, y - 46, 32, 4); line(g, x - 30, y - 47, x + 30, y - 45, 'rgba(30,30,40,0.7)', 1.2); };
  KIND.mogul = function (g, x, y, v) { ell(g, x + 5, y + 5, 16, 7, 'rgba(110,140,190,0.45)'); var gr = g.createRadialGradient(x - 5, y - 5, 2, x, y, 17); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.55, 'rgba(232,240,250,0.95)'); gr.addColorStop(1, 'rgba(176,198,230,0.9)'); g.fillStyle = gr; g.beginPath(); g.ellipse(x, y, 16, 10, 0, 0, 6.3); g.fill(); g.strokeStyle = 'rgba(130,156,200,0.55)'; g.lineWidth = 1; g.beginPath(); g.ellipse(x, y, 16, 10, 0, 0.2, 2.9); g.stroke(); };
  KIND.icePatch = function (g, x, y, v) { var gr = g.createLinearGradient(x - 26, y - 10, x + 26, y + 10); gr.addColorStop(0, 'rgba(170,220,250,0.55)'); gr.addColorStop(0.5, 'rgba(220,244,255,0.85)'); gr.addColorStop(1, 'rgba(150,206,240,0.55)'); g.fillStyle = gr; g.beginPath(); g.ellipse(x, y, 28, 12, -0.15, 0, 6.3); g.fill(); line(g, x - 16, y - 2, x + 6, y - 6, 'rgba(255,255,255,0.9)', 1.5); line(g, x - 4, y + 4, x + 14, y + 1, 'rgba(255,255,255,0.7)', 1); };
  KIND.ramp = function (g, x, y, v) { shadow(g, x, y + 4, 20, 6); poly(g, [x - 18, y + 6, x + 18, y + 6, x + 14, y - 14, x - 14, y - 14], '#e8eef8', '#9fb2d0', 1); poly(g, [x - 14, y - 14, x + 14, y - 14, x + 16, y - 18, x - 16, y - 18], '#ffffff'); for (var i = 0; i < 4; i++) line(g, x - 12, y + 2 - i * 4, x + 12, y + 2 - i * 4, 'rgba(160,180,212,0.5)', 1); poly(g, [x - 18, y + 6, x - 14, y - 14, x - 18, y - 12], '#e8432e'); poly(g, [x + 18, y + 6, x + 14, y - 14, x + 18, y - 12], '#e8432e'); };
  KIND.shrub = function (g, x, y, v) { for (var k = 0; k < 5; k++) ell(g, x + (k - 2) * 4, y - 4 - (k % 2) * 3, 5, 4, k % 2 ? '#4a6a3a' : '#3a5a30'); ell(g, x, y - 8, 7, 2.5, 'rgba(255,255,255,0.85)'); };
  KIND.tuft = function (g, x, y, v) { for (var k = -2; k <= 2; k++) line(g, x, y, x + k * 3, y - 8 + Math.abs(k), '#8a8a5a', 1.2); };
  KIND.flagMarker = function (g, x, y, v) { line(g, x, y, x, y - 18, '#ffb02a', 2); poly(g, [x, y - 18, x + 8, y - 15, x, y - 12], '#ff7a1a'); };
  // mine
  KIND.crate = function (g, x, y, v) { shadowDark(g, x, y + 2, 14, 5); g.fillStyle = '#9a6a3a'; g.fillRect(x - 12, y - 20, 24, 20); g.strokeStyle = '#5a3a1a'; g.lineWidth = 2; g.strokeRect(x - 11, y - 19, 22, 18); line(g, x - 11, y - 19, x + 11, y - 1, '#5a3a1a', 2); g.fillStyle = 'rgba(255,220,160,0.25)'; g.fillRect(x - 12, y - 20, 24, 3); };
  KIND.barrel = function (g, x, y, v) { shadowDark(g, x, y + 2, 11, 4); g.fillStyle = '#7a4a2a'; g.fillRect(x - 9, y - 20, 18, 20); ell(g, x, y - 20, 9, 3.5, '#8a5a34'); g.fillStyle = '#3a3a40'; g.fillRect(x - 9, y - 16, 18, 2); g.fillRect(x - 9, y - 6, 18, 2); g.fillStyle = 'rgba(255,220,160,0.25)'; g.fillRect(x - 9, y - 20, 4, 20); };
  KIND.rockfall = function (g, x, y, v) { shadowDark(g, x, y + 2, 16, 5); rockShape(g, x - 6, y, 0.7, [96, 84, 74], false, false); rockShape(g, x + 7, y + 1, 0.55, [110, 96, 82], false, false); rockShape(g, x, y - 6, 0.45, [86, 74, 66], false, false); };
  KIND.oreCart = function (g, x, y, v) { shadowDark(g, x, y + 2, 15, 5); g.fillStyle = '#4a4c54'; poly(g, [x - 14, y - 18, x + 14, y - 18, x + 11, y - 2, x - 11, y - 2], '#4a4c54', '#2a2c32', 1.5); ell(g, x, y - 18, 13, 4, '#6a5a4a'); for (var k = 0; k < 4; k++) ell(g, x - 7 + k * 5, y - 20, 3, 2.5, k % 2 ? '#c89a3a' : '#9a7a5a'); ell(g, x - 9, y - 1, 3, 3, '#1a1a1e'); ell(g, x + 9, y - 1, 3, 3, '#1a1a1e'); };
  KIND.buffer = function (g, x, y, v) { shadowDark(g, x, y + 2, 14, 4); g.fillStyle = '#6a2a1a'; g.fillRect(x - 14, y - 14, 28, 10); for (var i = 0; i < 4; i++) { g.fillStyle = i % 2 ? '#f2c230' : '#1a1a1a'; g.fillRect(x - 14 + i * 7, y - 14, 7, 4); } g.fillStyle = '#3a3a40'; g.fillRect(x - 12, y - 4, 4, 4); g.fillRect(x + 8, y - 4, 4, 4); };
  KIND.gap = function (g, x, y, v) { poly(g, [x - 26, y - 14, x - 18, y - 19, x + 20, y - 18, x + 27, y - 12, x + 25, y + 15, x + 16, y + 19, x - 20, y + 18, x - 27, y + 12], '#3a2c22'); var gr = g.createLinearGradient(0, y - 15, 0, y + 15); gr.addColorStop(0, '#000000'); gr.addColorStop(0.5, '#0c0806'); gr.addColorStop(1, '#241a12'); poly(g, [x - 22, y - 13, x + 22, y - 13, x + 22, y + 13, x - 22, y + 13], gr); for (var i = -1; i <= 1; i += 2) { line(g, x + i * 12, y - 22, x + i * 12 + i * 4, y - 12, '#9aa2b0', 2.5); line(g, x + i * 12, y + 22, x + i * 12 - i * 3, y + 13, '#9aa2b0', 2.5); } g.fillStyle = '#5a3c24'; g.save(); g.translate(x - 4, y + 2); g.rotate(0.5); g.fillRect(-14, -3, 28, 6); g.restore(); line(g, x - 22, y - 13, x + 22, y - 13, 'rgba(255,190,110,0.35)', 1.5); };
  KIND.lantern = function (g, x, y, v) { var gr = g.createRadialGradient(x, y - 18, 1, x, y - 18, 34); gr.addColorStop(0, 'rgba(255,200,110,0.40)'); gr.addColorStop(1, 'rgba(255,200,110,0)'); g.fillStyle = gr; g.fillRect(x - 34, y - 52, 68, 68); line(g, x, y, x, y - 14, '#3a2a1a', 2); g.fillStyle = '#2a2a2e'; g.fillRect(x - 4, y - 24, 8, 10); g.fillStyle = '#ffd47a'; g.fillRect(x - 2.5, y - 22.5, 5, 7); };
  KIND.beam = function (g, x, y, v) { g.fillStyle = '#5a3a20'; g.fillRect(x - 5, y - 30, 10, 30); g.fillStyle = 'rgba(255,210,150,0.18)'; g.fillRect(x - 5, y - 30, 2, 30); g.fillStyle = '#4a2e18'; g.fillRect(x - 9, y - 34, 18, 6); };
  KIND.crystal = function (g, x, y, v) { var col = v % 2 ? [120, 210, 240] : [200, 120, 240]; poly(g, [x, y - 18, x + 5, y - 6, x, y, x - 5, y - 6], rgb(col)); poly(g, [x - 6, y - 10, x - 2, y - 4, x - 6, y, x - 10, y - 4], rgb(mix(col, [255, 255, 255], 0.3))); line(g, x - 1, y - 15, x + 1, y - 6, 'rgba(255,255,255,0.8)', 1); };
  KIND.pickaxe = function (g, x, y, v) { line(g, x - 8, y, x + 6, y - 14, '#7a5434', 2.5); g.strokeStyle = '#9aa2b0'; g.lineWidth = 3; g.beginPath(); g.arc(x + 6, y - 14, 8, Math.PI * 1.1, Math.PI * 1.9); g.stroke(); };
  KIND.sleeperPile = function (g, x, y, v) { shadowDark(g, x, y + 1, 12, 3); for (var i = 0; i < 3; i++) { g.fillStyle = i % 2 ? '#5a3c24' : '#6a4a2c'; g.fillRect(x - 12 + i * 2, y - 4 - i * 4, 22, 4); } };
  // river
  KIND.rockWet = function (g, x, y, v) { ell(g, x, y - 2, 18, 8, 'rgba(255,255,255,0.45)'); rockShape(g, x, y, 0.95, [88, 92, 98], false, true); };
  KIND.bankStone = function (g, x, y, v) { ell(g, x + 3, y + 2, 12, 4, 'rgba(40,60,20,0.35)'); rockShape(g, x, y, 0.7, [120, 118, 108], false, false); };
  KIND.rockFlat = function (g, x, y, v) { ell(g, x, y, 16, 7, 'rgba(255,255,255,0.40)'); ell(g, x, y - 2, 13, 6, '#7a7a74'); ell(g, x - 3, y - 4, 7, 3, 'rgba(255,255,255,0.25)'); };
  KIND.log = function (g, x, y, v) { ell(g, x, y + 2, 24, 6, 'rgba(255,255,255,0.35)'); g.fillStyle = '#6a4a2c'; g.fillRect(x - 20, y - 6, 40, 10); ell(g, x - 20, y - 1, 3, 5, '#c8a070'); ell(g, x + 20, y - 1, 3, 5, '#a88050'); line(g, x - 16, y - 3, x + 14, y - 3, 'rgba(255,220,160,0.25)', 1.5); line(g, x + 4, y - 6, x + 8, y - 12, '#5a3a20', 2); };
  KIND.snag = function (g, x, y, v) { ell(g, x, y, 10, 4, 'rgba(255,255,255,0.4)'); line(g, x, y, x + 6, y - 14, '#4a3420', 3); line(g, x + 3, y - 7, x - 5, y - 12, '#4a3420', 2); };
  KIND.buoy = function (g, x, y, v) { ell(g, x, y + 1, 9, 3, 'rgba(255,255,255,0.5)'); ell(g, x, y - 5, 7, 7, '#e8432e'); g.fillStyle = '#fff'; g.fillRect(x - 7, y - 6, 14, 2.5); ell(g, x - 2, y - 8, 2, 2, 'rgba(255,255,255,0.6)'); };
  KIND.eddy = function (g, x, y, v) { g.strokeStyle = 'rgba(220,248,250,0.55)'; g.lineWidth = 1.5; for (var r = 4; r < 20; r += 5) { g.beginPath(); g.arc(x, y, r, v * 0.7, v * 0.7 + Math.PI * 1.4); g.stroke(); } ell(g, x, y, 3, 3, 'rgba(10,50,70,0.5)'); };
  KIND.falls = function (g, x, y, v) { var gr = g.createLinearGradient(0, y - 14, 0, y + 16); gr.addColorStop(0, 'rgba(255,255,255,0.15)'); gr.addColorStop(0.45, 'rgba(255,255,255,0.95)'); gr.addColorStop(1, 'rgba(200,236,240,0.25)'); g.fillStyle = gr; g.fillRect(x - 34, y - 14, 68, 30); for (var i = 0; i < 8; i++) line(g, x - 30 + i * 8.5, y - 4, x - 32 + i * 8.5, y + 14, 'rgba(255,255,255,0.7)', 1.5); rockShape(g, x - 40, y + 2, 0.5, [80, 84, 90], false, true); rockShape(g, x + 40, y + 2, 0.5, [80, 84, 90], false, true); };
  KIND.reeds = function (g, x, y, v) { for (var k = -3; k <= 3; k++) { line(g, x + k * 2, y, x + k * 3, y - 16 - (k & 1) * 4, '#5a7a3a', 1.5); } ell(g, x + 3, y - 18, 1.6, 4, '#6a4a2a'); ell(g, x - 4, y - 16, 1.6, 4, '#6a4a2a'); };
  KIND.lily = function (g, x, y, v) { g.fillStyle = '#4a8a4a'; g.beginPath(); g.moveTo(x, y); g.arc(x, y, 7, 0.4, Math.PI * 2 - 0.1); g.closePath(); g.fill(); if (v % 2) { ell(g, x + 2, y - 2, 2.6, 2.6, '#f0c0d8'); } };
  KIND.foam = function (g, x, y, v) { for (var k = 0; k < 5; k++) ell(g, x + (k - 2) * 4, y + (k % 2) * 2, 3, 2, 'rgba(255,255,255,0.75)'); };
  /** Draw one shape by name. Unknown names draw a magenta X so a missing drawing can never pass unseen. */
  function drawKind(g, kind, x, y, v, biome) { var f = KIND[kind]; if (!f) { line(g, x - 8, y - 8, x + 8, y + 8, '#ff00ff', 3); line(g, x - 8, y + 8, x + 8, y - 8, '#ff00ff', 3); return false; } f(g, x, y, v); return true; }

  //---------------------------------------------------------------------------
  // VEHICLES: drawn under the buyer's character; origin = the rider's contact point
  //---------------------------------------------------------------------------
  /** @param {string} mode @param {number} lean -1..1 @param {number} colourIndex 0..3 */
  function drawVehicle(g, mode, x, y, lean, col) {
    var C = [[214, 46, 52], [40, 92, 196], [240, 176, 40], [40, 160, 110]][col || 0], dark = mix(C, [0, 0, 0], 0.45);
    g.save(); g.translate(x, y);
    if (mode === 'ski') {
      g.rotate(lean * 0.35);
      for (var s = -1; s <= 1; s += 2) { g.fillStyle = rgb(C); roundRect(g, s * 6 - 2.5, -20, 5, 34, 2.5); g.fill(); g.fillStyle = 'rgba(255,255,255,0.5)'; g.fillRect(s * 6 - 1, -18, 1.5, 28); }
      line(g, -14, -2, -10, 10, '#30323a', 1.5); line(g, 14, -2, 10, 10, '#30323a', 1.5);
    } else if (mode === 'board') {
      g.rotate(Math.PI / 2 * 0.15 + lean * 0.5);
      g.fillStyle = rgb(C); roundRect(g, -20, -6, 40, 12, 6); g.fill();
      g.fillStyle = rgb(dark); g.fillRect(-10, -4, 4, 8); g.fillRect(6, -4, 4, 8);
      g.fillStyle = 'rgba(255,255,255,0.35)'; g.fillRect(-16, -4, 32, 2);
    } else if (mode === 'sled') {
      g.rotate(lean * 0.25);
      line(g, -10, -12, -10, 12, '#5a5c66', 2); line(g, 10, -12, 10, 12, '#5a5c66', 2);
      g.strokeStyle = '#5a5c66'; g.lineWidth = 2; g.beginPath(); g.arc(-10, -14, 3, Math.PI * 0.5, Math.PI * 1.5, true); g.stroke(); g.beginPath(); g.arc(10, -14, 3, Math.PI * 0.5, Math.PI * 1.5, true); g.stroke();
      g.fillStyle = '#9a6a3a'; roundRect(g, -13, -9, 26, 18, 3); g.fill();
      for (var k = 0; k < 4; k++) { g.fillStyle = k % 2 ? '#8a5a30' : '#a67444'; g.fillRect(-13, -9 + k * 4.5, 26, 4); }
    } else if (mode === 'cart') {
      g.fillStyle = '#3a3c44'; g.fillRect(-16, -8, 32, 20);
      g.fillStyle = '#5a5c66'; g.fillRect(-16, -8, 32, 4); g.fillStyle = 'rgba(255,220,150,0.25)'; g.fillRect(-16, -8, 3, 20);
      g.fillStyle = '#c8a040'; g.fillRect(-16, 2, 32, 2.5);
      for (var w = -1; w <= 1; w += 2) { ell(g, w * 13, 12, 3.5, 3, '#121214'); }
    } else if (mode === 'raft') {
      g.rotate(lean * 0.3);
      ell(g, 0, 4, 26, 10, 'rgba(255,255,255,0.40)');
      for (var lg = -2; lg <= 2; lg++) { g.fillStyle = lg % 2 ? '#8a6038' : '#a0743e'; roundRect(g, lg * 8 - 4, -16, 8, 32, 4); g.fill(); }
      line(g, -18, -8, 18, -8, '#c8b080', 2); line(g, -18, 8, 18, 8, '#c8b080', 2);
      line(g, 14, 2, 26, -14, '#6a4a2a', 2.5); ell(g, 27, -16, 3, 5, '#6a4a2a');
    }
    g.restore();
  }
  function roundRect(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.lineTo(x + w - r, y); c.quadraticCurveTo(x + w, y, x + w, y + r); c.lineTo(x + w, y + h - r); c.quadraticCurveTo(x + w, y + h, x + w - r, y + h); c.lineTo(x + r, y + h); c.quadraticCurveTo(x, y + h, x, y + h - r); c.lineTo(x, y + r); c.quadraticCurveTo(x, y, x + r, y); c.closePath(); }

  //---------------------------------------------------------------------------
  // PURSUERS: drawn in code (the buyer may pick an enemy image instead in Schuss.js)
  //---------------------------------------------------------------------------
  function drawPursuer(g, kind, x, y, frame) {
    var bob = Math.sin(frame * 0.35) * 2;
    if (kind === 'boulder') {
      shadow(g, x + 4, y + 26, 30, 9);
      ell(g, x, y, 30, 28, '#7c7a78'); ell(g, x - 8, y - 9, 14, 9, 'rgba(255,255,255,0.18)'); ell(g, x + 10, y + 10, 16, 10, 'rgba(0,0,0,0.18)');
      for (var k = 0; k < 6; k++) { var a = frame * 0.2 + k; line(g, x + Math.cos(a) * 12, y + Math.sin(a) * 12, x + Math.cos(a) * 24, y + Math.sin(a) * 22, 'rgba(40,40,40,0.35)', 2); }
      g.fillStyle = 'rgba(255,255,255,0.85)'; for (var s = 0; s < 6; s++) ell(g, x - 26 + s * 10, y + 26 + (s % 2) * 3, 6, 3, 'rgba(255,255,255,0.8)');
      return;
    }
    if (kind === 'flood') {
      var gr = g.createLinearGradient(0, y - 40, 0, y + 20); gr.addColorStop(0, 'rgba(255,255,255,0.0)'); gr.addColorStop(0.6, 'rgba(255,255,255,0.9)'); gr.addColorStop(1, 'rgba(120,200,220,0.9)');
      g.fillStyle = gr; g.fillRect(x - 380, y - 40, 760, 60);
      for (var f = 0; f < 24; f++) ell(g, x - 380 + f * 33 + (frame * 3 % 33), y + 4 + Math.sin(f + frame * 0.2) * 4, 14, 8, 'rgba(255,255,255,0.85)');
      return;
    }
    // the yeti (default)
    shadow(g, x + 4, y + 30, 22, 7);
    ell(g, x, y + 4 + bob, 25, 29, '#3a4a66'); ell(g, x, y - 22 + bob, 17, 16, '#3a4a66');
    ell(g, x, y + 4 + bob, 22, 26, '#eef2f8'); ell(g, x, y - 22 + bob, 14, 13, '#eef2f8');
    for (var fz = 0; fz < 9; fz++) line(g, x - 18 + fz * 4.5, y + 26 + bob, x - 20 + fz * 4.5, y + 31 + bob, '#3a4a66', 1.5);
    ell(g, x + 6, y + 8 + bob, 12, 18, 'rgba(160,180,210,0.35)');
    var arm = Math.sin(frame * 0.35) * 8;
    ell(g, x - 24, y - 2 + arm + bob, 9, 17, '#3a4a66'); ell(g, x + 24, y - 2 - arm + bob, 9, 17, '#3a4a66');
    ell(g, x - 24, y - 2 + arm + bob, 7, 15, '#e6ecf4'); ell(g, x + 24, y - 2 - arm + bob, 7, 15, '#e6ecf4');
    ell(g, x, y - 20 + bob, 9, 7, '#7a8aa4'); g.fillStyle = '#c03030'; ell(g, x - 4, y - 22 + bob, 2, 2, '#ff4040'); ell(g, x + 4, y - 22 + bob, 2, 2, '#ff4040');
    poly(g, [x - 5, y - 15 + bob, x + 5, y - 15 + bob, x, y - 11 + bob], '#2a2a34');
    ell(g, x - 9, y + 30 + bob * 0.3, 7, 4, '#d8e0ec'); ell(g, x + 9, y + 30 - bob * 0.3, 7, 4, '#d8e0ec');
  }

  /** A pickup (coin) drawn at radius r; `spin` 0..1 squeezes it as it turns. */
  function drawCoin(g, x, y, r, spin) {
    var sx = Math.max(0.15, Math.abs(Math.cos(spin * Math.PI)));
    ell(g, x + 2, y + r + 2, r * 0.8, r * 0.3, 'rgba(0,0,0,0.25)');
    g.save(); g.translate(x, y); g.scale(sx, 1);
    ell(g, 0, 0, r, r, '#b8861e'); ell(g, 0, 0, r * 0.82, r * 0.82, '#f2c64a'); ell(g, -r * 0.25, -r * 0.3, r * 0.3, r * 0.22, 'rgba(255,255,255,0.7)');
    g.strokeStyle = '#b8861e'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(0, -r * 0.45); g.lineTo(0, r * 0.45); g.stroke();
    g.restore();
  }

  //---------------------------------------------------------------------------
  // THE DISPLAY ALPHABET: stroke glyphs on a 4 x 6 grid, slanted, so the HUD never uses a font
  //---------------------------------------------------------------------------
  var GLYPH = {
    '0': ['0,0 4,0 4,6 0,6 0,0', '0,5 4,1'], '1': ['1,1 2,0 2,6', '1,6 3,6'], '2': ['0,1 1,0 3,0 4,1 4,2 0,6 4,6'], '3': ['0,0 4,0 2,2 4,3 4,5 3,6 0,6'],
    '4': ['3,6 3,0 0,4 4,4'], '5': ['4,0 0,0 0,3 4,3 4,6 0,6'], '6': ['4,0 1,0 0,1 0,6 4,6 4,3 0,3'], '7': ['0,0 4,0 1,6'],
    '8': ['1,0 3,0 4,1 4,2 3,3 1,3 0,2 0,1 1,0', '1,3 3,3 4,4 4,5 3,6 1,6 0,5 0,4 1,3'], '9': ['4,3 0,3 0,0 4,0 4,5 3,6 0,6'],
    'A': ['0,6 0,2 2,0 4,2 4,6', '0,3 4,3'], 'B': ['0,6 0,0 3,0 4,1 4,2 3,3 0,3', '3,3 4,4 4,5 3,6 0,6'], 'C': ['4,0 0,0 0,6 4,6'], 'D': ['0,0 2,0 4,2 4,4 2,6 0,6 0,0'],
    'E': ['4,0 0,0 0,6 4,6', '0,3 3,3'], 'F': ['4,0 0,0 0,6', '0,3 3,3'], 'G': ['4,0 0,0 0,6 4,6 4,3 2,3'], 'H': ['0,0 0,6', '4,0 4,6', '0,3 4,3'],
    'I': ['1,0 3,0', '2,0 2,6', '1,6 3,6'], 'J': ['4,0 4,5 3,6 1,6 0,5'], 'K': ['0,0 0,6', '4,0 0,3 4,6'], 'L': ['0,0 0,6 4,6'],
    'M': ['0,6 0,0 2,3 4,0 4,6'], 'N': ['0,6 0,0 4,6 4,0'], 'O': ['1,0 3,0 4,1 4,5 3,6 1,6 0,5 0,1 1,0'], 'P': ['0,6 0,0 4,0 4,3 0,3'],
    'Q': ['0,0 4,0 4,6 0,6 0,0', '2,4 4,6'], 'R': ['0,6 0,0 4,0 4,3 0,3 4,6'], 'S': ['4,1 3,0 1,0 0,1 0,2 1,3 3,3 4,4 4,5 3,6 1,6 0,5'], 'T': ['0,0 4,0', '2,0 2,6'],
    'U': ['0,0 0,6 4,6 4,0'], 'V': ['0,0 2,6 4,0'], 'W': ['0,0 1,6 2,3 3,6 4,0'], 'X': ['0,0 4,6', '4,0 0,6'], 'Y': ['0,0 2,3 4,0', '2,3 2,6'], 'Z': ['0,0 4,0 0,6 4,6'],
    ':': ['2,1.5 2,2', '2,4 2,4.5'], '.': ['2,5.6 2,6'], '/': ['4,0 0,6'], '-': ['1,3 3,3'], '+': ['2,1.5 2,4.5', '0.5,3 3.5,3'], '!': ['2,0 2,4', '2,5.6 2,6'], '\'': ['2,0 2,1.5'],
    ' ': [],
  };
  var GLYPH_P = {};
  for (var key in GLYPH) GLYPH_P[key] = GLYPH[key].map(function (s) { return s.split(' ').map(function (p) { var q = p.split(','); return [+q[0], +q[1]]; }); });
  /** Width in px of a string at cap height `size`. */
  function textWidth(str, size) { return String(str).length * size * 0.86 - size * 0.2; }
  /**
   * Stroke a string in the display alphabet. align: 'left' | 'center' | 'right'. Draws an outline under the fill.
   * @returns {number} the width drawn
   */
  function drawText(g, str, x, y, size, col, align, outline) {
    str = String(str).toUpperCase();
    var u = size / 6, adv = size * 0.86, w = textWidth(str, size);
    var x0 = align === 'center' ? x - w / 2 : align === 'right' ? x - w : x;
    g.save(); g.lineCap = 'round'; g.lineJoin = 'round';
    for (var pass = 0; pass < 2; pass++) {
      if (pass === 0 && outline === false) continue;
      g.strokeStyle = pass === 0 ? (outline || 'rgba(10,14,30,0.85)') : col; g.lineWidth = pass === 0 ? size * 0.34 : size * 0.17;
      for (var i = 0; i < str.length; i++) {
        var gl = GLYPH_P[str[i]] || GLYPH_P[' '], gx = x0 + i * adv;
        for (var s = 0; s < gl.length; s++) {
          var pts = gl[s]; g.beginPath();
          for (var p = 0; p < pts.length; p++) { var px = gx + pts[p][0] * u + (6 - pts[p][1]) * u * 0.22, py = y + pts[p][1] * u; if (p === 0) g.moveTo(px, py); else g.lineTo(px, py); }
          if (pts.length === 1) g.lineTo(gx + pts[0][0] * u + 0.01, y + pts[0][1] * u);
          g.stroke();
        }
      }
    }
    g.restore();
    return w;
  }

  /** The HUD plate: a slanted dark tab with a coloured edge, sized w x h. */
  function plate(g, x, y, w, h, accent) {
    g.save();
    poly(g, [x + h * 0.35, y, x + w, y, x + w - h * 0.35, y + h, x, y + h], 'rgba(14,20,40,0.82)');
    poly(g, [x + h * 0.35, y, x + h * 0.35 + 5, y, x + 5, y + h, x, y + h], accent || '#e8432e');
    line(g, x + h * 0.35 + 6, y + 1.5, x + w - 2, y + 1.5, 'rgba(255,255,255,0.25)', 1);
    g.restore();
  }

  var API = { VERSION: '1.0.0', PAL: PAL, KIND: KIND, GLYPH: GLYPH, drawStrip: drawStrip, drawKind: drawKind, drawVehicle: drawVehicle, drawPursuer: drawPursuer,
    drawCoin: drawCoin, drawText: drawText, textWidth: textWidth, plate: plate, gate: gate, roundRect: roundRect };
  root.CSAF = root.CSAF || {};
  root.CSAF.SchussDraw = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof window !== 'undefined' ? window : this);
