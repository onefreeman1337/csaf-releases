//=============================================================================
// Taproom.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Taproom - sit down with an NPC and play Nine Men's
 * Morris, Fox and Geese, Oware or Fanorona for a stake, on boards the plugin
 * draws. Place BELOW TaproomCore and TaproomDraw.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * Taproom
 * ============================================================================
 *
 * Four old tavern board games your player can sit down and play against the
 * people of your world, for gold:
 *
 *   Nine Men's Morris   rows of three take men; fly when you are down to three
 *   Fox and Geese       one fox against thirteen geese; pick your side
 *   Oware               sow seeds round twelve pits, take twos and threes
 *   Fanorona            take whole lines by approach or withdrawal
 *
 * EVERY BOARD IS DRAWN. Slate, marble, a board knifed into the tabletop,
 * black lacquer with gilt lines, a linen mat, tooled leather, walnut with
 * brass, carved soapstone; borders worked at a steady pitch and the wear of
 * use. The men are drawn too: river stones, bone and horn, glass, silver and
 * copper coins, fired clay, boxwood and ebony. Which board and men an
 * opponent sets out is chosen from their name, so the old man in the corner
 * always plays on the same scratched slate. You can name a board and a set
 * instead.
 *
 * THE OPPONENT THINKS. Five strengths: Novice, Regular, Sharp, Hustler,
 * Master. It searches ahead a little at a time across frames, so the game
 * never stalls, and the same position with the same seed gets the same move.
 *
 * ----------------------------------------------------------------------------
 * INSTALLING
 * ----------------------------------------------------------------------------
 * Plugin Manager order, top to bottom:
 *
 *     TaproomCore.js     (the rules and the opponent)
 *     TaproomDraw.js     (the drawing)
 *     Taproom.js         (this file: parameters, the command, the scene)
 *
 * ----------------------------------------------------------------------------
 * USING IT
 * ----------------------------------------------------------------------------
 * Add the plugin command "Play a Game" to an event: choose the game, the
 * opponent's name and strength, which side the player takes, the stake, and
 * the variables and switch to set. The event waits while they play.
 *
 *   Result variable   1 = won, 0 = lost (or conceded), 2 = drawn
 *   Margin variable   by how much, in the game's own count: men ahead
 *                     (Morris, Fanorona), seeds ahead (Oware), geese taken
 *                     (as the fox) or geese left (as the geese). Negative
 *                     when the player lost.
 *   Win switch        on only for a win
 *   Stake             won or lost in gold. If the party has less, the stake
 *                     is what they have. A draw returns it.
 *
 * Script calls:
 *   Taproom.record("Old Brannoc", "morris")  -> {w, l, d} against them
 *   Taproom.lastResult                        -> the last game's result
 *
 * ----------------------------------------------------------------------------
 * CONTROLS
 * ----------------------------------------------------------------------------
 * Mouse and touch: click a man, then where it goes. Rings show every point
 * you may click next; a red cross marks a man you may take.
 * Keyboard and gamepad: the arrows move between the ringed points, OK
 * chooses, Cancel puts a picked-up man back. Shift shows the rules of the
 * game. W (page down) stops a chain of captures early. The Concede plaque
 * gives the game up (click it twice).
 *
 * ----------------------------------------------------------------------------
 * COMPATIBILITY
 * ----------------------------------------------------------------------------
 * Taproom adds its own scene and replaces nothing. It extends one engine
 * method (Game_System.initialize) to create its save record, calling the
 * original first.
 *
 * ============================================================================
 * TERMS OF USE
 * ============================================================================
 * Commercial and non-commercial use permitted in RPG Maker projects, credit
 * appreciated but not required. Do not redistribute the source as an asset
 * pack. Every line of this plugin was written with AI assistance.
 *
 * ============================================================================
 *
 * @param moveSe
 * @text Sound: a man set down
 * @type file
 * @dir audio/se
 * @default Knock
 *
 * @param takeSe
 * @text Sound: a man taken
 * @type file
 * @dir audio/se
 * @default Coin
 *
 * @param sowSe
 * @text Sound: a seed sown
 * @type file
 * @dir audio/se
 * @default Cursor2
 *
 * @param pickSe
 * @text Sound: a man picked up
 * @type file
 * @dir audio/se
 * @default Cursor1
 *
 * @param refuseSe
 * @text Sound: not allowed
 * @type file
 * @dir audio/se
 * @default Buzzer1
 *
 * @param winSe
 * @text Sound: the player wins
 * @type file
 * @dir audio/se
 * @default Applause1
 *
 * @param loseSe
 * @text Sound: the player loses
 * @type file
 * @dir audio/se
 * @default Cancel1
 *
 * @param thinkMs
 * @text Opponent search per frame (ms)
 * @desc How much of each frame the opponent may spend searching. Its move is the same whatever this is.
 * @type number
 * @decimals 1
 * @min 0.2
 * @max 8
 * @default 1.0
 *
 * @command play
 * @text Play a Game
 * @desc Sit the player down at a board. The event waits until the game ends.
 *
 * @arg game
 * @text Game
 * @type select
 * @option morris
 * @option foxgeese
 * @option oware
 * @option fanorona
 * @default morris
 *
 * @arg opponent
 * @text Opponent's name
 * @desc Shown on the card, and it chooses their board and men. Blank = "The Stranger".
 * @default
 *
 * @arg grade
 * @text Opponent's strength
 * @type select
 * @option 1: Novice
 * @value 1
 * @option 2: Regular
 * @value 2
 * @option 3: Sharp
 * @value 3
 * @option 4: Hustler
 * @value 4
 * @option 5: Master
 * @value 5
 * @default 3
 *
 * @arg side
 * @text The player's side
 * @desc first / second / random. In Fox and Geese: fox or geese (the geese move first).
 * @type select
 * @option first
 * @option second
 * @option random
 * @option fox
 * @option geese
 * @default first
 *
 * @arg stake
 * @text Stake (gold)
 * @type number
 * @min 0
 * @default 0
 *
 * @arg resultVariableId
 * @text Variable: result (1 won, 0 lost, 2 drawn)
 * @type variable
 * @default 0
 *
 * @arg marginVariableId
 * @text Variable: margin
 * @type variable
 * @default 0
 *
 * @arg winSwitchId
 * @text Switch: on for a win
 * @type switch
 * @default 0
 *
 * @arg board
 * @text Board (blank = the opponent's own)
 * @type select
 * @option
 * @option slate
 * @option marble
 * @option knifed
 * @option lacquer
 * @option linen
 * @option leather
 * @option walnut
 * @option soapstone
 * @default
 *
 * @arg set
 * @text Men (blank = the opponent's own)
 * @type select
 * @option
 * @option stones
 * @option bone
 * @option glass
 * @option coins
 * @option clay
 * @option boxwood
 * @default
 *
 * @arg seed
 * @text Seed (optional)
 * @desc Blank = keyed to this map, event and how many games have been played there.
 * @default
 */

var Taproom = Taproom || {};

(function (M) {
  'use strict';
  var NAME = 'Taproom', SCHEMA = 1;
  var raw = (typeof PluginManager !== 'undefined') ? PluginManager.parameters(NAME) : {};
  function num(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; var n = Number(v); return isFinite(n) ? n : d; }
  function str(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; return String(v).trim(); }
  M.params = { moveSe: str(raw.moveSe, 'Knock'), takeSe: str(raw.takeSe, 'Coin'), sowSe: str(raw.sowSe, 'Cursor2'), pickSe: str(raw.pickSe, 'Cursor1'), refuseSe: str(raw.refuseSe, 'Buzzer1'),
    winSe: str(raw.winSe, 'Applause1'), loseSe: str(raw.loseSe, 'Cancel1'), thinkMs: Math.max(0.2, Math.min(8, num(raw.thinkMs, 1.0))) };

  var _deps = null;
  function deps() {
    if (_deps) return _deps;
    var core = (typeof TaproomCore !== 'undefined') ? TaproomCore : null, draw = (typeof TaproomDraw !== 'undefined') ? TaproomDraw : null;
    if (!core || !draw) { if (!deps._w) { deps._w = true; console.error('Taproom: TaproomCore.js and TaproomDraw.js must both be installed and listed ABOVE Taproom.js.'); } return null; }
    _deps = { core: core, draw: draw }; return _deps;
  }
  M.deps = deps;

  function fresh() { return { v: SCHEMA, rec: {}, played: {} }; }
  function store() {
    if (typeof $gameSystem === 'undefined' || !$gameSystem) return fresh();
    var s = $gameSystem._csafTaproom; if (!s || s.v == null) { s = fresh(); $gameSystem._csafTaproom = s; }
    if (!s.rec) s.rec = {}; if (!s.played) s.played = {}; return s;
  }
  M.store = store;
  /** @returns {{w:number, l:number, d:number}} the player's record against `name` at `game` */
  M.record = function (name, game) { var r = store().rec, k = String(name) + '|' + String(game); if (!r[k]) r[k] = { w: 0, l: 0, d: 0 }; return r[k]; };
  M.lastResult = null;

  var _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () { _Game_System_initialize.call(this); this._csafTaproom = fresh(); };

  var SIDES = { first: 0, second: 1 };
  /** Build a request from command arguments. Returns null if the sibling plugins are missing. */
  M.request = function (args, key, mapId, eventId) {
    var d = deps(); if (!d) return null; args = args || {};
    var game = str(args.game, 'morris'); if (!d.core.GAMES[game]) game = 'morris';
    var played = store().played[key] || 0, seedText = str(args.seed, '');
    var seed = seedText === '' ? d.core.hashString(key + '|' + played) : (/^\d+$/.test(seedText) ? (Number(seedText) >>> 0) : d.core.hashString(seedText));
    var sideArg = str(args.side, 'first'), human;
    if (game === 'foxgeese') human = sideArg === 'fox' || sideArg === 'second' ? 0 : sideArg === 'random' ? (seed & 1) : 1;   // geese move first
    else human = sideArg === 'second' || sideArg === 'geese' ? 1 : sideArg === 'random' ? (seed & 1) : 0;
    var grade = Math.max(1, Math.min(5, Math.floor(num(args.grade, 3))));
    var name = str(args.opponent, 'The Stranger'), board = str(args.board, ''), set = str(args.set, '');
    return { key: key, seed: seed, game: game, human: human, grade: grade, opponent: name, stake: Math.max(0, Math.floor(num(args.stake, 0))),
      resultVariableId: Math.max(0, Math.floor(num(args.resultVariableId, 0))), marginVariableId: Math.max(0, Math.floor(num(args.marginVariableId, 0))),
      winSwitchId: Math.max(0, Math.floor(num(args.winSwitchId, 0))), style: d.draw.styleFor(name, game, board, set), mapId: mapId, eventId: eventId };
  };
  M.open = function (req) { if (!req) return false; SceneManager.push(Scene_Taproom); SceneManager.prepareNextScene(req); return true; };

  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
    PluginManager.registerCommand(NAME, 'play', function (args) {
      var mapId = this._mapId || ($gameMap ? $gameMap.mapId() : 0), eventId = this.eventId ? this.eventId() : 0;
      var seedText = str(args.seed, ''), key = seedText === '' ? 'm' + mapId + 'e' + eventId : 's' + seedText;
      M.open(M.request(args, key, mapId, eventId));
    });
  }
  M.RULES = {
    morris: ['Take turns placing your nine men on the points.', 'Three in a row along a line is a mill: take one of their men', '(not one standing in a mill, unless all of them are).', 'Then move a man along a line to an empty neighbour.', 'Down to three men, you may fly to any empty point.', 'Leave them two men, or no move, and you win.'],
    foxgeese: ['The geese move first, one step forward or sideways.', 'The fox steps any way along the lines,', 'or jumps a goose to an empty point beyond to take it,', 'and may keep jumping.', 'Trap the fox and the geese win.', 'Take enough geese that they cannot, and the fox wins.'],
    oware: ['Take every seed from a pit on your row and sow them', 'one by one round the board, anticlockwise.', 'If your last seed makes two or three in their pit,', 'take them, and any twos and threes just behind it.', 'Never leave their row empty if you can feed it.', 'More than twenty-four seeds wins.'],
    fanorona: ['Move a man along a line to the next empty point.', 'Moving TOWARD their line takes it (approach);', 'moving AWAY from an adjacent one takes it (withdrawal).', 'After a capture the same man may go on taking,', 'never twice in one direction or back to a point it left.', 'Taking is compulsory. Take every man to win.'],
  };
  M.VERSION = '1.0.0'; M.SCHEMA = SCHEMA;
}(Taproom));

//=============================================================================
// Scene_Taproom
//=============================================================================

function Scene_Taproom() { this.initialize.apply(this, arguments); }
Scene_Taproom.prototype = Object.create(Scene_Base.prototype);
Scene_Taproom.prototype.constructor = Scene_Taproom;
Scene_Taproom.LABELS = ['Rules', 'Stop', 'Concede'];
Scene_Taproom.MIN_THINK = 34;   // frames: the opponent always takes a moment

Scene_Taproom.prototype.prepare = function (req) { this._req = req; };

Scene_Taproom.prototype.create = function () {
  Scene_Base.prototype.create.call(this);
  var d = Taproom.deps(), req = this._req, C = d.core; this._d = d; this._C = C; this._D = d.draw;
  this._G = C.GAMES[req.game]; this._m = C.newMatch(req.game, { human: req.human }); this._human = req.human;
  this._L = d.draw.layout(req.game, Graphics.width, Graphics.height, C); this._style = req.style;
  this._stake = req.stake; if (typeof $gameParty !== 'undefined' && $gameParty && this._stake > $gameParty.gold()) this._stake = $gameParty.gold();
  this._prefix = []; this._opts = null; this._targets = []; this._cur = 0; this._q = []; this._mode = 'start'; this._anim = 0; this._concede = 0;
  this._markKey = ''; this._statusText = ''; this._plaqueKey = ''; this._hover = -1; this._rules = false; this._thinker = null; this._thinkFrames = 0; this._last = null;
  this.layoutPanel(); this.createBoard(); this.createMen(); this.addChild(this._marks); this.addChild(this._top); this.createUi();   // rings and crosses sit ABOVE the men (a take-cross under its man was invisible)
  this.refreshPanel(); this.refreshPlaques();
};
Scene_Taproom.prototype.start = function () { Scene_Base.prototype.start.call(this); this.startFadeIn(this.fadeSpeed(), false); this.nextTurn(); };

/** Panel rectangles for the two layouts (board left + panel right, or board on top + panel below). */
Scene_Taproom.prototype.layoutPanel = function () {
  var L = this._L, P = L.panel, R = {};
  if (L.side === 'right') {
    R.card = { x: P.x, y: P.y, w: P.w, h: 172 }; R.theirs = { x: P.x, y: P.y + 180, w: P.w, h: 124 }; R.mine = { x: P.x, y: P.y + 312, w: P.w, h: 124 };
    R.status = { x: P.x, y: P.y + 444, w: P.w, h: 60 }; R.plaques = { x: P.x, y: P.y + 514, w: P.w, h: 36, cols: 3, gap: 4 };
  } else {
    R.card = { x: P.x, y: P.y, w: 224, h: P.h }; var bx = P.x + 234, bw = P.w - 234 - 184;
    R.theirs = { x: bx, y: P.y, w: bw, h: Math.floor((P.h - 56) / 2) }; R.mine = { x: bx, y: P.y + Math.floor((P.h - 56) / 2) + 6, w: bw, h: Math.floor((P.h - 56) / 2) };
    R.status = { x: bx, y: P.y + P.h - 44, w: P.w - 234, h: 44 }; R.plaques = { x: P.x + P.w - 174, y: P.y, w: 174, h: 38, cols: 1, gap: 8 };
  }
  this._R = R;
};

Scene_Taproom.prototype.createBoard = function () {
  var D = this._D, W = Graphics.width, H = Graphics.height, bmp = new Bitmap(W, H), ctx = bmp.context;
  D.drawTable(ctx, W, H, this._style.seed ^ 0x7ab1e);
  this._boardInfo = D.drawBoard(ctx, this._L, this._style, this._C);
  this.drawBoxes(ctx);
  bmp._baseTexture.update(); this._bg = new Sprite(bmp); this.addChild(this._bg);
  this._marks = new Sprite(new Bitmap(W, H)); this.addChild(this._marks);
};
/** The two trays at the side of the board: felt-lined boxes, one for each player's men in hand and the men they took. */
Scene_Taproom.prototype.drawBoxes = function (ctx) {
  var D = this._D, self = this;
  ['theirs', 'mine'].forEach(function (k) {
    var b = self._R[k]; ctx.save(); ctx.shadowColor = 'rgba(0,0,0,0.5)'; ctx.shadowBlur = 10; ctx.shadowOffsetX = 4; ctx.shadowOffsetY = 6; ctx.fillStyle = '#4a2c16'; D.rrect(ctx, b.x, b.y, b.w, b.h, 8); ctx.fill(); ctx.restore();
    var g = ctx.createLinearGradient(b.x, b.y, b.x, b.y + b.h); g.addColorStop(0, '#2a3a26'); g.addColorStop(1, '#1a2618'); ctx.fillStyle = g; D.rrect(ctx, b.x + 6, b.y + 6, b.w - 12, b.h - 12, 5); ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,0.6)'; ctx.lineWidth = 2; D.rrect(ctx, b.x + 6, b.y + 6, b.w - 12, b.h - 12, 5); ctx.stroke();
    ctx.strokeStyle = 'rgba(214,170,96,0.55)'; ctx.lineWidth = 1; D.rrect(ctx, b.x + 1.5, b.y + 1.5, b.w - 3, b.h - 3, 7); ctx.stroke();
  });
};

//---------------------------------------------------------------------------- the men
Scene_Taproom.prototype.manSprite = function (side, seed) {
  var r = this._L.r, fox = this._G.id === 'foxgeese' && side === 0, rr = fox ? r * 1.22 : r, pad = Math.ceil(rr * 0.7) + 6, sz = Math.ceil(rr * 2 + pad * 2);
  var sp = new Sprite(new Bitmap(sz, sz)); sp.anchor.x = 0.5; sp.anchor.y = 0.5;
  this._D.drawMan(sp.bitmap.context, sz / 2 - 3, sz / 2 - 3, rr, this._style.set, fox ? 'fox' : side, seed, 0); sp.bitmap._baseTexture.update();
  sp._side = side; sp._fox = fox; return sp;
};
Scene_Taproom.prototype.createMen = function () {
  var s = this._m.state, L = this._L, i; this._layer = new Sprite(); this.addChild(this._layer); this._occ = []; this._hand = [[], []]; this._tray = [[], []]; this._pits = null;
  if (this._G.id === 'oware') { this.createPits(); return; }
  for (i = 0; i < L.pts.length; i++) this._occ.push(null);
  for (i = 0; i < s.cells.length; i++) if (s.cells[i] >= 0) { var sp = this.manSprite(s.cells[i], this._style.seed + i * 31); sp.x = L.pts[i].x; sp.y = L.pts[i].y; this._layer.addChild(sp); this._occ[i] = sp; }
  if (this._G.id === 'morris') for (var side = 0; side < 2; side++) for (i = 0; i < 9; i++) { var h = this.manSprite(side, this._style.seed + 900 + side * 50 + i * 7); this._layer.addChild(h); this._hand[side].push(h); }
  this.placeBoxes(true);
  this._top = new Sprite(); this.addChild(this._top);
};
/** The box a side's men go to: the player's own box at the bottom (or below), the opponent's above. */
Scene_Taproom.prototype.boxOf = function (side) { return side === this._human ? this._R.mine : this._R.theirs; };
/** Where slot `i` of a box row sits. Row 0: men in hand (Morris); after it, the men that side has TAKEN. */
// rows a box needs: Morris 9 in hand (2 rows of 7) + up to 7 taken; the fox takes up to 13; Fanorona up to 22
Scene_Taproom.BOX = { morris: { rows: 3, per: 7, hand: 2 }, foxgeese: { rows: 2, per: 7, hand: 0 }, fanorona: { rows: 2, per: 11, hand: 0 }, oware: { rows: 1, per: 1, hand: 0 } };
Scene_Taproom.prototype.slot = function (side, kind, i) {
  var b = this.boxOf(side), r = this._L.r, K = Scene_Taproom.BOX[this._G.id];
  // ⛔ found by looking (2026-09-28): the width term divided the 4 px gap by the scale too, so the seventh man overhung
  // the box. A row of `per` men at pitch 2rs + 4 must fit the box's inner width.
  var s = Math.min(0.62, (b.h - 30) / (K.rows * 2 * r + (K.rows - 1) * 3), ((b.w - 26) / K.per - 4) / (2 * r)), step = r * 2 * s + 4;
  var row = kind === 'hand' ? Math.floor(i / K.per) : K.hand + Math.floor(i / K.per), col = i % K.per;
  return { x: b.x + 12 + step / 2 + col * step, y: b.y + 28 + r * s + row * (r * 2 * s + 3), s: s };
};
Scene_Taproom.prototype.placeBoxes = function () {
  for (var side = 0; side < 2; side++) {
    var k, sl;
    for (k = 0; k < this._hand[side].length; k++) { sl = this.slot(side, 'hand', k); this.put(this._hand[side][k], sl.x, sl.y, sl.s); }
    for (k = 0; k < this._tray[side].length; k++) { sl = this.slot(side, 'tray', k); this.put(this._tray[side][k], sl.x, sl.y, sl.s); }
  }
};
Scene_Taproom.prototype.put = function (sp, x, y, s) { sp.x = x; sp.y = y; sp.scale.x = sp.scale.y = s; };

//---------------------------------------------------------------------------- oware pits
Scene_Taproom.prototype.createPits = function () {
  var L = this._L, i; this._vis = this._m.state.pits.slice(); this._visStore = [0, 0]; this._pits = []; this._stores = [];
  // each pit sprite spans the pit and its count on either side: the count sits L.countGap beyond the rim (above for the
  // far row, below for the near row)
  var padY = L.countGap + 14;
  for (i = 0; i < 12; i++) { var w = Math.ceil(L.pitR * 2 + 12), h = Math.ceil((L.pitR + padY) * 2), sp = new Sprite(new Bitmap(w, h)); sp.x = L.pts[i].x - w / 2; sp.y = L.pts[i].y - L.pitR - padY; sp._i = i; this._layer.addChild(sp); this._pits.push(sp); this.paintPit(i); }
  for (i = 0; i < 2; i++) { var st = L.stores[i], ss = new Sprite(new Bitmap(st.w + 20, st.h + 40)); ss.x = st.x - st.w / 2 - 10; ss.y = st.y - st.h / 2 - 20; this._layer.addChild(ss); this._stores.push(ss); this.paintStore(i); }
  this._hand1 = new Sprite(new Bitmap(60, 60)); this._hand1.anchor.x = this._hand1.anchor.y = 0.5; this._hand1.visible = false; this._top = new Sprite(); this.addChild(this._top); this._top.addChild(this._hand1);
};
Scene_Taproom.prototype.paintPit = function (i) {
  var sp = this._pits[i], b = sp.bitmap, ctx = b.context, L = this._L, n = this._vis[i], cx = b.width / 2, cy = b.height / 2, B = this._D.BOARDS[this._style.board];
  ctx.clearRect(0, 0, b.width, b.height); this._D.drawSeeds(ctx, cx, cy, L.pitR, n, this._style.set, this._style.seed + i * 13 + n);
  this._D.drawCount(ctx, cx, i >= 6 ? cy - L.pitR - L.countGap : cy + L.pitR + L.countGap, n, B, 19); b._baseTexture.update();
};
Scene_Taproom.prototype.paintStore = function (k) {
  var sp = this._stores[k], b = sp.bitmap, ctx = b.context, st = this._L.stores[k], n = this._visStore[k], B = this._D.BOARDS[this._style.board], r = rng2(this._style.seed + k);
  ctx.clearRect(0, 0, b.width, b.height);
  // ⛔ found by looking (2026-09-28): seeds laid in columns read as a stack of coins, and a count set outside the store
  // sat on the border band. The seeds heap in a tall spiral round the store's middle; the count is cut INSIDE its far end.
  var shown = Math.min(n, 48), sr = this._L.pitR * 0.19, cx = b.width / 2, cy = b.height / 2 + (k === 0 ? -14 : 14);
  for (var j = 0; j < shown; j++) { var a = j * 2.39996 + r() * 0.3, d = Math.sqrt(j + 0.5) * sr * 1.15, x = cx + Math.cos(a) * Math.min(d, st.w * 0.3), y = cy + Math.sin(a) * Math.min(d * 2.3, st.h * 0.3); this._D.drawSeeds(ctx, x, y, sr * 5.2, 1, this._style.set, j + 7); }
  this._D.drawCount(ctx, cx, k === 0 ? b.height - 20 - 30 : 20 + 30, n, B, 22); b._baseTexture.update();
};
function rng2(seed) { var a = seed >>> 0; return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

//---------------------------------------------------------------------------- panel + ui
Scene_Taproom.prototype.createUi = function () {
  var R = this._R, W = Graphics.width, H = Graphics.height;
  this._card = new Sprite(new Bitmap(W, H)); this.drawCard(this._card.bitmap.context); this._card.bitmap._baseTexture.update(); this.addChild(this._card);
  this._panel = new Sprite(new Bitmap(W, H)); this.addChild(this._panel);
  this._status = new Sprite(new Bitmap(R.status.w, R.status.h)); this._status.x = R.status.x; this._status.y = R.status.y; this.addChild(this._status);
  var P = R.plaques, pw = P.cols === 3 ? Math.floor((P.w - P.gap * 2) / 3) : P.w, ph = P.h;
  this._plaques = new Sprite(new Bitmap(P.w + 8, P.cols === 3 ? ph + 8 : 3 * (ph + P.gap) + 8)); this._plaques.x = P.x - 4; this._plaques.y = P.y - 4; this._pw = pw; this.addChild(this._plaques);
  this._pr = []; for (var k = 0; k < 3; k++) this._pr.push(P.cols === 3 ? { x: P.x + k * (pw + P.gap), y: P.y, w: pw, h: P.h } : { x: P.x, y: P.y + k * (P.h + P.gap), w: P.w, h: P.h });   // built once: hit-tested every frame
  this._rulesCard = new Sprite(new Bitmap(W, H)); this._rulesCard.visible = false; this.addChild(this._rulesCard);
  this._verdict = new Sprite(new Bitmap(W, H)); this._verdict.visible = false; this.addChild(this._verdict);
};
Scene_Taproom.prototype.names = function (side) { return side === this._human ? 'You' : this._req.opponent; };
Scene_Taproom.prototype.sideName = function (side) { return this._G.sides[side]; };
/**
 * The opponent's card, drawn ONCE when the game opens (nothing on it changes during a game).
 * ⛔ mz_gate 2026-09-28: redrawn with the labels on every capture, its per-pixel paper put 10-20 ms spikes in the update half.
 */
Scene_Taproom.prototype.drawCard = function (ctx) {
  var D = this._D, R = this._R, req = this._req, g = this._G.id, me = this._human;
  var you = g === 'foxgeese' ? (me === 0 ? 'You play the fox' : 'You play the geese') : (me === 0 ? 'You move first (' + this.sideName(0) + ')' : 'You move second (' + this.sideName(1) + ')');
  var lines = [this._stake > 0 ? 'Stake: ' + this._stake + ' gold' : 'A friendly game', you];
  var rec = Taproom.record(req.opponent, g); if (rec.w + rec.l + rec.d > 0) lines.push('Before tonight: ' + rec.w + ' won, ' + rec.l + ' lost' + (rec.d ? ', ' + rec.d + ' drawn' : ''));
  D.drawPlacard(ctx, R.card.x, R.card.y, R.card.w, R.card.h, { game: this._G.name, name: req.opponent, grade: 'a ' + this._C.GRADES.names[req.grade] + ' (' + req.grade + ' of 5)', lines: lines });
};
/** The box labels; redrawn (only their strips) when a count changes. */
Scene_Taproom.prototype.refreshPanel = function () {
  var s = this._m.state, key = JSON.stringify([s.store, s.hand, this._tray[0].length, this._tray[1].length, s.taken]); if (key === this._panelKey) return; this._panelKey = key;
  var D = this._D, R = this._R, b = this._panel.bitmap, ctx = b.context, me = this._human, them = 1 - me;
  var self = this;
  [['theirs', them], ['mine', me]].forEach(function (e) {
    var bx = R[e[0]], side = e[1], label = self.boxLabel(side);
    ctx.clearRect(bx.x, bx.y, bx.w, 30);
    ctx.font = 'italic 14px ' + D.FACE; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#e8d3a2'; ctx.fillText(label, bx.x + 14, bx.y + 17, bx.w - 24);
  });
  // ⛔ found by looking (2026-09-28): without this upload the labels froze at their first drawing ("9 in hand" beside
  // four men already in the tray) while every count in the rules was right
  b._baseTexture.update();
};
Scene_Taproom.prototype.boxLabel = function (side) {
  var s = this._m.state, g = this._G.id, who = side === this._human ? 'Yours' : this._req.opponent + '’s';
  if (g === 'oware') return who + ': ' + s.store[side] + ' seeds in store';
  if (g === 'morris') return who + ': ' + s.hand[side] + ' in hand, ' + this._tray[side].length + ' taken';
  if (g === 'foxgeese') return side === 0 ? who + ' (fox): ' + s.taken + ' geese taken' : who + ' (geese): ' + this._G.geese(s) + ' left, ' + this._G.FLOCK_MIN + ' needed';
  return who + ': ' + this._tray[side].length + ' taken';
};
Scene_Taproom.prototype.plaqueStates = function () {
  var human = this._mode === 'human', canStop = human && this._opts && this._opts.complete && this._opts.next.length > 0 && this._prefix.length > 1;
  return [this._mode === 'over' || this._mode === 'reveal' || this._mode === 'done' ? 'off' : (this._rules ? 'on' : 'idle'), canStop ? 'idle' : 'off', human || this._mode === 'think' ? (this._concede ? 'on' : 'idle') : 'off'];
};
Scene_Taproom.prototype.plaqueRect = function (k) { return this._pr[k]; };
Scene_Taproom.prototype.refreshPlaques = function () {
  var st = this.plaqueStates(), key = st.join('|') + '|' + this._hover; if (key === this._plaqueKey) return; this._plaqueKey = key;
  var b = this._plaques.bitmap, ctx = b.context; ctx.clearRect(0, 0, b.width, b.height);
  for (var k = 0; k < 3; k++) { var r = this.plaqueRect(k); this._D.drawPlaque(ctx, r.x - this._plaques.x, r.y - this._plaques.y, r.w, r.h, Scene_Taproom.LABELS[k], st[k] === 'idle' && this._hover === k ? 'on' : st[k]); }
  b._baseTexture.update();
};
Scene_Taproom.prototype.setStatus = function (t) { if (t === this._statusText) return; this._statusText = t; var S = this._R.status; this._D.drawStatus(this._status.bitmap.context, S.w, S.h, t); this._status.bitmap._baseTexture.update(); };
Scene_Taproom.prototype.playSe = function (n) { if (n && typeof AudioManager !== 'undefined') AudioManager.playSe({ name: n, volume: 80, pitch: 100, pan: 0 }); };
Scene_Taproom.prototype.toggleRules = function () {
  this._rules = !this._rules; this._rulesCard.visible = this._rules;
  if (this._rules) { var b = this._rulesCard.bitmap; this.drawRulesText(b.context, b.width, b.height); b._baseTexture.update(); }
  this.refreshPlaques();
};
Scene_Taproom.prototype.drawRulesText = function (ctx, W, H) {
  var lines = Taproom.RULES[this._G.id], bd = this._L.board, w = Math.min(520, bd.w - 20), h = 250, x = bd.x + (bd.w - w) / 2, y = Math.max(8, bd.y + (bd.h - h) / 2);
  ctx.clearRect(0, 0, W, H); ctx.fillStyle = 'rgba(6,3,1,0.55)'; ctx.fillRect(0, 0, W, H);
  this._D.drawPlacard(ctx, x, y, w, h, { game: 'How to play', name: this._G.name, grade: 'press Shift or Rules to close', lines: lines });
};

//---------------------------------------------------------------------------- turns
/** The legal moves of the position on the board, generated once per position (a Fanorona midgame's chains are not free). */
Scene_Taproom.prototype.legal = function () {
  var s = this._m.state; if (this._legalFor !== s) { this._legalFor = s; this._legal = this._G.moves(s); }
  return this._legal;
};
Scene_Taproom.prototype.nextTurn = function () {
  var m = this._m; this._prefix = []; this._concede = 0;
  if (m.over) { this.finish(); return; }
  if (m.state.turn === this._human) {
    this._mode = 'human'; this._opts = this._C.options(this._G.id, this.legal(), this._prefix); this.buildTargets(); this.refreshPlaques();
    this.setStatus(this.promptText());
  } else {
    this._mode = 'think'; this._thinkFrames = 0; this._dots = 0; this._thinker = new this._C.Thinker(this._G.id, m.state, this._req.grade, this._req.seed ^ (m.state.ply * 2654435761)); this._targets = []; this.refreshMarks(); this.refreshPlaques();
    this.setStatus(this._req.opponent + ' studies the board');
  }
};
Scene_Taproom.prototype.promptText = function () {
  var g = this._G.id, p = this._prefix, s = this._m.state, o = this._opts;
  if (o && o.next.length && o.next[0][0] === 't') return 'A mill! Take one of their men.';
  if (o && o.next.length && o.next[0][0] === 'x') return 'Take which line? Click the first man of it.';
  if (o && o.complete && o.next.length) return 'You may take again, or Stop.';
  if (g === 'oware') return 'Choose a pit on your row to sow.';
  if (g === 'morris' && !p.length && s.hand[this._human] > 0) return 'Place a man on an empty point (' + s.hand[this._human] + ' in hand).';
  if (!p.length) return g === 'fanorona' && o && this.legal()[0].steps[0].kind !== 'p' ? 'Your move. Taking is compulsory: pick a man that can take.' : 'Your move: pick up a man.';
  return 'Now choose where it goes (Cancel puts it back).';
};

/** Rings for every click the player may make next; the keyboard cursor walks these. */
Scene_Taproom.prototype.buildTargets = function () {
  var o = this._opts, L = this._L, t = [], i;
  for (i = 0; i < o.next.length; i++) { var tk = o.next[i], p = Number(tk.slice(1)), pt = L.pts[p]; t.push({ tk: tk, x: pt.x, y: pt.y, kind: tk[0] === 'p' ? 'target' : 'take' }); }
  t.sort(function (a, b) { return a.y - b.y || a.x - b.x; });
  this._targets = t; if (this._cur >= t.length) this._cur = 0; this.refreshMarks();
};
Scene_Taproom.prototype.refreshMarks = function () {
  var L = this._L, list = [], rr = this._G.id === 'oware' ? L.pitR + 4 : L.r + 6, self = this;
  if (this._mode === 'human') {
    this._targets.forEach(function (t, i) { list.push({ x: t.x, y: t.y, r: rr, kind: i === self._cur ? (t.kind === 'take' ? 'take' : 'sel') : t.kind }); });
    var sel = this.selPoint(); if (sel >= 0) list.push({ x: L.pts[sel].x, y: L.pts[sel].y, r: rr + 3, kind: 'sel' });
  }
  if (this._last) this._last.forEach(function (p) { list.push({ x: L.pts[p].x, y: L.pts[p].y, r: rr - 2, kind: 'last', faint: true }); });
  this.drawMarks(list);
};
Scene_Taproom.prototype.drawMarks = function (list) {
  var key = JSON.stringify(list); if (key === this._markKey) return; this._markKey = key;
  var b = this._marks.bitmap, ctx = b.context; ctx.clearRect(0, 0, b.width, b.height);
  for (var i = 0; i < list.length; i++) { ctx.globalAlpha = list[i].faint ? 0.55 : 1; this._D.drawMarker(ctx, list[i].x, list[i].y, list[i].r, list[i].kind); }
  ctx.globalAlpha = 1; b._baseTexture.update();
};
/** The point of the man currently picked up (a chain's current square), or -1. */
Scene_Taproom.prototype.selPoint = function () {
  var p = this._prefix; if (!p.length || this._G.id === 'oware') return -1;
  for (var i = p.length - 1; i >= 0; i--) if (p[i][0] === 'p') { if (this._G.id === 'morris' && p.length === 1 && this._m.state.hand[this._m.state.turn] > 0) return -1; return Number(p[i].slice(1)); }
  return -1;
};

//---------------------------------------------------------------------------- a click, for either player: the motion it makes
/**
 * Enter one token of the current move and queue its animation. A token that only picks a man up moves nothing.
 * Returns false if the token is not on offer.
 */
Scene_Taproom.prototype.enter = function (tk) {
  var legal = this.legal(), o = this._C.options(this._G.id, legal, this._prefix);
  if (o.next.indexOf(tk) < 0) return false;
  var before = this._prefix.slice(); this._prefix.push(tk); this.queueOps(before, tk, legal);
  return true;
};
Scene_Taproom.prototype.queueOps = function (before, tk, legal) {
  var g = this._G.id, s = this._m.state, side = s.turn, L = this._L, p = Number(tk.slice(1)), self = this, sp, cur;
  var ref = null, pre = this._prefix; for (var i = 0; i < legal.length && !ref; i++) { var t = this._C.tokens(g, legal[i]); if (pre.every(function (x, k) { return t[k] === x; })) ref = legal[i]; }
  if (g === 'oware') { this.queueSow(p, side); return; }
  var isPick = !before.length && !(g === 'morris' && s.hand[side] > 0);
  if (isPick) { this.playSe(Taproom.params.pickSe); this.q({ wait: 4 }); return; }
  if (tk[0] === 'p') {
    if (g === 'morris' && !before.length) { sp = this._hand[side].pop(); this.slide(sp, L.pts[p].x, L.pts[p].y, 1, 16); this._occ[p] = sp; return; }
    cur = this.chainPoint(before); sp = this._occ[cur]; this._occ[cur] = null; this._occ[p] = sp; this.slide(sp, L.pts[p].x, L.pts[p].y, 1, 12);
    if (g === 'foxgeese') { var a = this._G.xy[cur], b = this._G.xy[p]; if (Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]) === 2) this.take(this._G.at((a[0] + b[0]) / 2, (a[1] + b[1]) / 2), side); }
    return;
  }
  if (tk[0] === 't') { this.take(p, side); return; }
  // 'x': the Fanorona step just made takes the line starting at p
  var step = ref.steps[this.stepIndex(pre)]; for (var k = 0; k < step.take.length; k++) this.take(step.take[k], side, k * 3);
  void self;
};
/** Index of the Fanorona step an 'x' token belongs to: the number of 'p' tokens after the first, minus one. */
Scene_Taproom.prototype.stepIndex = function (pre) { var n = 0; for (var i = 1; i < pre.length; i++) if (pre[i][0] === 'p') n++; return n - 1; };
Scene_Taproom.prototype.chainPoint = function (before) { for (var i = before.length - 1; i >= 0; i--) if (before[i][0] === 'p') return Number(before[i].slice(1)); return -1; };
/** A man taken: lifted off the board and laid in the taker's box. */
Scene_Taproom.prototype.take = function (p, taker, delay) {
  var sp = this._occ[p]; if (!sp) return; this._occ[p] = null; this._tray[taker].push(sp);
  var sl = this.slot(taker, 'tray', this._tray[taker].length - 1); if (delay) this.q({ wait: delay });
  this.q({ sprite: sp, x: sl.x, y: sl.y, s: sl.s, frames: 16, lift: 1, se: Taproom.params.takeSe });
};
Scene_Taproom.prototype.slide = function (sp, x, y, s, frames) { this.q({ sprite: sp, x: x, y: y, s: s, frames: frames, lift: 1, se: Taproom.params.moveSe, seAtEnd: true }); };
Scene_Taproom.prototype.q = function (op) { this._q.push(op); };
/** Oware: lift the pit's seeds and sow them round, one pit at a time; then the captures fly to the store. */
Scene_Taproom.prototype.queueSow = function (pit, side) {
  var r = this._G.sow(this._m.state.pits, side, pit), self = this, L = this._L, st = L.stores[side];
  this.q({ call: function () { self._vis[pit] = 0; self.paintPit(pit); self.showHandful(true, L.pts[pit].x, L.pts[pit].y - 8); } });
  r.path.forEach(function (to) { self.q({ handTo: to, frames: 6, call: function () { self._vis[to]++; self.paintPit(to); self.playSe(Taproom.params.sowSe); } }); });
  this.q({ call: function () { self.showHandful(false); } });
  r.caps.forEach(function (c) { self.q({ wait: 6, call: function () { var n = self._vis[c]; self._vis[c] = 0; self.paintPit(c); self.showHandful(true, L.pts[c].x, L.pts[c].y - 8); self._pendingStore = n; } });
    self.q({ handXY: [st.x, st.y], frames: 14, call: function () { self._visStore[side] += self._pendingStore; self.paintStore(side); self.showHandful(false); self.playSe(Taproom.params.takeSe); } }); });
};
Scene_Taproom.prototype.showHandful = function (on, x, y) {
  var h = this._hand1; h.visible = on; if (!on) return; h.x = x; h.y = y;
  var b = h.bitmap; b.context.clearRect(0, 0, 60, 60); this._D.drawSeeds(b.context, 30, 30, 26, 5, this._style.set, 3); b._baseTexture.update();
};

//---------------------------------------------------------------------------- per frame
Scene_Taproom.prototype.update = function () {
  Scene_Base.prototype.update.call(this);
  if (this._q.length) { this.updateQueue(); return; }
  var m = this._mode;
  if (m === 'anim') this.afterToken();
  else if (m === 'human') this.updateHuman();
  else if (m === 'think') this.updateThink();
  else if (m === 'ai') this.aiNext();
  else if (m === 'reveal') { this._anim++; this._verdict.opacity = Math.min(255, this._anim * 11); if (this._anim >= 24) this._mode = 'done'; }
  else if (m === 'done') { if (Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered() || TouchInput.isCancelled()) this.leave(); }
  else if (m === 'leaving' && !this.isBusy()) { this._mode = 'gone'; this.popScene(); }
};
Scene_Taproom.prototype.updateQueue = function () {
  var op = this._q[0];
  if (op.t === undefined) { op.t = 0; if (op.sprite) { op.x0 = op.sprite.x; op.y0 = op.sprite.y; op.s0 = op.sprite.scale.x; this._top.addChild(op.sprite); } if (op.handTo !== undefined) { op.x0 = this._hand1.x; op.y0 = this._hand1.y; } if (op.handXY) { op.x0 = this._hand1.x; op.y0 = this._hand1.y; } if (op.se && !op.seAtEnd) this.playSe(op.se); }
  op.t++; var f = op.frames || op.wait || 0, k = f ? Math.min(1, op.t / f) : 1, e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
  if (op.sprite) { var sp = op.sprite, lift = Math.sin(Math.PI * k) * 10 * (op.lift || 0); sp.x = op.x0 + (op.x - op.x0) * e; sp.y = op.y0 + (op.y - op.y0) * e - lift; var sc = op.s0 + (op.s - op.s0) * e; sp.scale.x = sp.scale.y = sc * (1 + 0.08 * Math.sin(Math.PI * k) * (op.lift || 0)); }
  if (op.handTo !== undefined) { var pt = this._L.pts[op.handTo]; this._hand1.x = op.x0 + (pt.x - op.x0) * e; this._hand1.y = op.y0 + (pt.y - 8 - op.y0) * e - Math.sin(Math.PI * k) * 10; }
  if (op.handXY) { this._hand1.x = op.x0 + (op.handXY[0] - op.x0) * e; this._hand1.y = op.y0 + (op.handXY[1] - op.y0) * e - Math.sin(Math.PI * k) * 16; }
  if (k >= 1) {
    this._q.shift();
    if (op.sprite) { this._layer.addChild(op.sprite); if (op.se && op.seAtEnd) this.playSe(op.se); }
    if (op.call) op.call();
    if (!this._q.length) this.refreshPanel();
  }
};

/** After a token's motion: finish the move, wait for the next click, or take a forced line automatically. */
Scene_Taproom.prototype.afterToken = function () {
  var legal = this.legal(), o = this._C.options(this._G.id, legal, this._prefix);
  if (o.complete && !o.next.length) { this.commit(o.complete); return; }
  if (this._aiMove) { this._mode = 'ai'; return; }   // the opponent enters its own clicks, forced ones included
  if (!o.complete && o.next.length === 1 && o.next[0][0] === 'x') { this.enter(o.next[0]); this._mode = 'anim'; return; }
  this._mode = 'human'; this._opts = o; this._cur = 0; this.buildTargets(); this.refreshPlaques(); this.setStatus(this.promptText());
};
Scene_Taproom.prototype.commit = function (move) {
  var ok = this._C.play(this._m, move); this._aiMove = null;
  if (!ok) { console.error('Taproom: a move the rules refused reached commit', move); }
  var tk = this._C.tokens(this._G.id, move); this._last = []; for (var i = 0; i < tk.length; i++) if (tk[i][0] === 'p') this._last.push(Number(tk[i].slice(1)));
  if (this._G.id === 'oware') { this._last = [move.pit]; this._vis = this._m.state.pits.slice(); this._visStore = this._m.state.store.slice(); for (var k = 0; k < 12; k++) this.paintPit(k); this.paintStore(0); this.paintStore(1); }
  if (this._G.id === 'morris') this.placeBoxes();
  this.refreshPanel(); this.nextTurn();
};

Scene_Taproom.prototype.updateThink = function () {
  var t = this._thinker, t0 = performance.now(), budget = Taproom.params.thinkMs;
  this._thinkFrames++;
  // one node at a time against the clock (mz_gate 2026-09-28: 24 nodes between clock reads overran the frame by 10+ ms
  // on a Fanorona midgame). The node sequence, and so the move, does not depend on this.
  while (!t.done && performance.now() - t0 < budget) t.step(1);
  var dots = Math.floor(this._thinkFrames / 20) % 4; if (dots !== this._dots) { this._dots = dots; this.setStatus(this._req.opponent + ' studies the board' + '....'.slice(0, dots)); }   // a new string only when the dots change
  this.updateCommonInput();
  if (t.done && this._thinkFrames >= Scene_Taproom.MIN_THINK) { this._aiMove = t.move; this._aiTokens = this._C.tokens(this._G.id, t.move); this._aiI = 0; this._mode = 'ai'; }
};
/** Play the opponent's chosen move one click at a time, through the same motions a player's clicks make. */
Scene_Taproom.prototype.aiNext = function () {
  if (this._aiI >= this._aiTokens.length) { var o = this._C.options(this._G.id, this.legal(), this._prefix); if (o.complete) this.commit(this._aiMove); return; }
  var tk = this._aiTokens[this._aiI++];
  if (!this._prefix.length && this._G.id !== 'oware' && !(this._G.id === 'morris' && this._m.state.hand[this._m.state.turn] > 0)) { var p = Number(tk.slice(1)); this.drawMarks([{ x: this._L.pts[p].x, y: this._L.pts[p].y, r: this._L.r + 9, kind: 'sel' }]); this._markKey = ''; this.q({ wait: 14 }); }
  this.enter(tk); this._mode = 'anim';
};

Scene_Taproom.prototype.updateHuman = function () {
  var t = this._targets, n = t.length;
  if (this.updateCommonInput()) return;
  if (this._rules) return;
  if (n) {
    var dir = Input.isRepeated('left') ? [-1, 0] : Input.isRepeated('right') ? [1, 0] : Input.isRepeated('up') ? [0, -1] : Input.isRepeated('down') ? [0, 1] : null;
    if (dir) { this._cur = this.nearest(this._cur, dir); this.refreshMarks(); this.playSe(Taproom.params.pickSe); }
    if (Input.isTriggered('ok')) { this.choose(t[this._cur].tk); return; }
  }
  if (Input.isTriggered('pagedown')) { this.pressPlaque(1); return; }
  if (Input.isTriggered('cancel') || TouchInput.isCancelled()) { this.back(); return; }
  if (TouchInput.isTriggered()) {
    var x = TouchInput.x, y = TouchInput.y, k, rr = this._G.id === 'oware' ? this._L.pitR + 6 : this._L.r + 8;
    for (k = 0; k < n; k++) if (Math.hypot(t[k].x - x, t[k].y - y) <= rr) { this._cur = k; this.choose(t[k].tk); return; }
    var sel = this.selPoint(); if (sel >= 0 && this._prefix.length === 1 && Math.hypot(this._L.pts[sel].x - x, this._L.pts[sel].y - y) <= rr) { this.back(); return; }
  }
};
/** Rules, Stop, Concede: plaques by mouse, Shift for the rules. Returns true if it used the frame. */
Scene_Taproom.prototype.updateCommonInput = function () {
  var x = TouchInput.x, y = TouchInput.y, hover = -1;
  for (var k = 0; k < 3; k++) { var r = this.plaqueRect(k); if (x >= r.x && x < r.x + r.w && y >= r.y && y < r.y + r.h) hover = k; }
  if (hover !== this._hover) { this._hover = hover; this.refreshPlaques(); }
  if (Input.isTriggered('shift')) { this.toggleRules(); return true; }
  if (this._rules && (Input.isTriggered('ok') || Input.isTriggered('cancel') || (TouchInput.isTriggered() && hover !== 0))) { this.toggleRules(); return true; }
  if (TouchInput.isTriggered() && hover >= 0) { this.pressPlaque(hover); return true; }
  return false;
};
Scene_Taproom.prototype.pressPlaque = function (k) {
  var st = this.plaqueStates(); if (st[k] === 'off') { this.playSe(Taproom.params.refuseSe); return; }
  if (k === 0) this.toggleRules();
  else if (k === 1) { var o = this._opts; if (o && o.complete) this.commit(o.complete); }
  else { if (this._concede) { this.concede(); return; } this._concede = 1; this.setStatus('Click Concede again to give up the game' + (this._stake ? ' and the stake.' : '.')); this.refreshPlaques(); }
};
/** Arrow keys: the nearest ringed point in that direction (by angle-weighted distance). */
Scene_Taproom.prototype.nearest = function (from, dir) {
  var t = this._targets, a = t[from], best = from, bd = Infinity;
  for (var i = 0; i < t.length; i++) { if (i === from) continue; var dx = t[i].x - a.x, dy = t[i].y - a.y, along = dx * dir[0] + dy * dir[1]; if (along <= 2) continue; var across = Math.abs(dx * dir[1] - dy * dir[0]), d = along + across * 2.2; if (d < bd) { bd = d; best = i; } }
  return best;
};
Scene_Taproom.prototype.choose = function (tk) {
  if (!this.enter(tk)) { this.playSe(Taproom.params.refuseSe); return; }
  this._concede = 0; this._mode = 'anim'; this._targets = []; this.refreshMarks(); this.refreshPlaques();
};
/** Cancel: put a picked-up man back (before it has moved). Once a man has moved, the move must be finished. */
Scene_Taproom.prototype.back = function () {
  if (this._prefix.length === 1 && this.selPoint() >= 0) { this._prefix = []; this._opts = this._C.options(this._G.id, this.legal(), []); this.buildTargets(); this.refreshPlaques(); this.setStatus(this.promptText()); this.playSe(Taproom.params.pickSe); return; }
  if (this._opts && this._opts.complete && this._opts.next.length) { this.commit(this._opts.complete); return; }
  this.playSe(Taproom.params.refuseSe);
};

//---------------------------------------------------------------------------- the end
Scene_Taproom.prototype.concede = function () { this._m.over = { winner: 1 - this._human, reason: 'you conceded' }; this._q = []; this.finish(); };
Scene_Taproom.prototype.finish = function () {
  var m = this._m, req = this._req, me = this._human, w = m.over.winner, out = w === -1 ? 2 : (w === me ? 1 : 0), margin = this._C.margin(m, me);
  if (this._G.id === 'foxgeese' && out === 0) margin = -Math.abs(me === 0 ? this._G.geese(m.state) : m.state.taken);
  if (out === 0 && margin > 0) margin = -margin;
  var rec = Taproom.record(req.opponent, req.game); if (out === 1) rec.w++; else if (out === 0) rec.l++; else rec.d++;
  var st = Taproom.store(); st.played[req.key] = (st.played[req.key] || 0) + 1;
  if (typeof $gameParty !== 'undefined' && $gameParty && this._stake > 0) { if (out === 1) $gameParty.gainGold(this._stake); else if (out === 0) $gameParty.loseGold(this._stake); }
  if (req.resultVariableId > 0 && typeof $gameVariables !== 'undefined') $gameVariables.setValue(req.resultVariableId, out);
  if (req.marginVariableId > 0 && typeof $gameVariables !== 'undefined') $gameVariables.setValue(req.marginVariableId, margin);
  if (req.winSwitchId > 0 && typeof $gameSwitches !== 'undefined') $gameSwitches.setValue(req.winSwitchId, out === 1);
  Taproom.lastResult = { game: req.game, opponent: req.opponent, grade: req.grade, result: out, margin: margin, reason: m.over.reason, plies: m.state.ply, stake: this._stake };
  var title = out === 1 ? 'You win' : out === 0 ? req.opponent + ' wins' : 'A draw';
  var unit = { morris: 'men', fanorona: 'men', oware: 'seeds', foxgeese: 'geese' }[req.game];
  var lines = [out === 2 ? 'Honours even.' : (this._G.id === 'foxgeese' ? (me === 0 ? m.state.taken + ' geese taken' : this._G.geese(m.state) + ' geese left') : 'By ' + Math.abs(margin) + ' ' + unit + '.'),
    this._stake ? (out === 1 ? 'You take ' + this._stake + ' gold.' : out === 0 ? 'You pay ' + this._stake + ' gold.' : 'The stake goes back.') : 'No stake.', 'Press OK to leave the table.'];
  var b = this._verdict.bitmap, bd = this._L.board; this._D.drawVerdict(b.context, b.width, b.height, { game: this._G.name, title: title, sub: m.over.reason.charAt(0).toUpperCase() + m.over.reason.slice(1), lines: lines }, bd.x + bd.w / 2, bd.y + bd.h / 2); b._baseTexture.update();
  this._verdictInfo = { title: title, sub: m.over.reason, lines: lines, out: out, margin: margin };
  this._verdict.opacity = 0; this._verdict.visible = true; this._anim = 0; this._mode = 'reveal'; this._targets = []; this.refreshMarks(); this.refreshPlaques(); this.setStatus('');
  this.playSe(out === 1 ? Taproom.params.winSe : out === 0 ? Taproom.params.loseSe : Taproom.params.moveSe);
};
Scene_Taproom.prototype.leave = function () {
  if (this._mode === 'leaving' || this._mode === 'gone') return;
  this._mode = 'leaving'; this.startFadeOut(this.fadeSpeed(), false);
};
