//=============================================================================
// TaproomDraw.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Taproom drawing - the tavern table, the boards and the
 * men, all drawn in code. Place BELOW TaproomCore and ABOVE Taproom.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The drawing for Taproom. No parameters or commands of its own; Taproom.js
 * is the file you configure.
 *
 * Nothing here is an image file. Every board is drawn when a game opens:
 * its surface (slate, marble, a board knifed into the tabletop, black
 * lacquer, a linen mat, tooled leather, walnut with brass, carved soapstone),
 * the lines or pits of the game, a border worked at a steady pitch, and the
 * wear of use: mug rings, scratches, chipped edges. Every man is drawn too:
 * river stones, bone and horn, glass, coins, fired clay or turned boxwood
 * and ebony, lit from the lamp at the upper left.
 *
 * Which board and which men an opponent plays with is chosen from the
 * opponent's name, so the same person always sets out the same board.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var TaproomDraw = (function () {
  'use strict';
  var FACE = '"Palatino Linotype", "Book Antiqua", Palatino, "Georgia", serif';
  var TAU = Math.PI * 2;

  //---------------------------------------------------------------------------- noise and colour
  function hash2(x, y, s) { var h = Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263) ^ Math.imul(s | 0, 1274126177); h = Math.imul(h ^ (h >>> 13), 1103515245); h ^= h >>> 16; return (h >>> 0) / 4294967296; }
  function vnoise(x, y, s) {
    var xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi, u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
    var a = hash2(xi, yi, s), b = hash2(xi + 1, yi, s), c = hash2(xi, yi + 1, s), d = hash2(xi + 1, yi + 1, s);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
  }
  function fbm(x, y, s, oct) { var t = 0, amp = 0.5, f = 1, n = 0; for (var i = 0; i < (oct || 4); i++) { t += amp * vnoise(x * f, y * f, s + i * 17); n += amp; amp *= 0.5; f *= 2.03; } return t / n; }
  function rgb(c, a) { return a === undefined ? 'rgb(' + (c[0] | 0) + ',' + (c[1] | 0) + ',' + (c[2] | 0) + ')' : 'rgba(' + (c[0] | 0) + ',' + (c[1] | 0) + ',' + (c[2] | 0) + ',' + a + ')'; }
  function mix(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }
  function lum(c) { function ch(v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); } return 0.2126 * ch(c[0]) + 0.7152 * ch(c[1]) + 0.0722 * ch(c[2]); }
  function contrast(a, b) { var la = lum(a), lb = lum(b); return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05); }
  /** The first candidate ink that clears `want` against `bg`, else the one that contrasts most (Icon_Doctrine §22e). */
  function pickInk(bg, cands, want) { var best = cands[0], bc = 0; for (var i = 0; i < cands.length; i++) { var c = contrast(bg, cands[i]); if (c >= want) return cands[i]; if (c > bc) { bc = c; best = cands[i]; } } return best; }
  function canvas(w, h) { var c = document.createElement('canvas'); c.width = Math.max(1, Math.ceil(w)); c.height = Math.max(1, Math.ceil(h)); return c; }
  function rng(seed) { var a = seed >>> 0; return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function hashString(s) { var h = 0x811c9dc5; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h >>> 0; }

  //---------------------------------------------------------------------------- materials
  // Each board material: a per-pixel surface function, the line treatment its lines are worked in, and a border motif.
  // `lit` is the colour a line's lit edge takes; `ink` the line itself. Contrast is solved, not hard-coded (§22e).
  var BOARDS = {
    slate:    { name: 'Slate', base: [60, 66, 76], line: 'scribe', ink: [214, 218, 212], motif: 'chevron', edge: [38, 42, 50] },
    marble:   { name: 'Marble', base: [222, 216, 204], line: 'inlay', ink: [58, 66, 62], motif: 'key', edge: [176, 168, 154] },
    knifed:   { name: 'Knifed tabletop', base: [132, 90, 52], line: 'groove', ink: [52, 30, 16], motif: 'notch', edge: [96, 62, 34] },
    lacquer:  { name: 'Black lacquer', base: [26, 20, 22], line: 'gilt', ink: [214, 172, 84], motif: 'lozenge', edge: [120, 24, 22] },
    linen:    { name: 'Linen mat', base: [212, 196, 162], line: 'stitch', ink: [120, 40, 34], motif: 'stitch', edge: [170, 150, 112] },
    leather:  { name: 'Tooled leather', base: [118, 66, 38], line: 'burn', ink: [44, 22, 12], motif: 'rope', edge: [80, 42, 22] },
    walnut:   { name: 'Walnut and brass', base: [96, 60, 38], line: 'brass', ink: [206, 166, 92], motif: 'bead', edge: [62, 38, 22] },
    soapstone:{ name: 'Carved soapstone', base: [150, 160, 142], line: 'groove', ink: [70, 78, 66], motif: 'notch', edge: [110, 120, 104] },
  };
  var BOARD_IDS = Object.keys(BOARDS);

  function surfaceAt(id, x, y, s) {
    var B = BOARDS[id], b = B.base, n = fbm(x / 60, y / 60, s, 4), f = vnoise(x / 3.2, y / 3.2, s + 99), t, k;
    switch (id) {
      case 'slate': t = (n - 0.5) * 22 + (f - 0.5) * 8 + Math.sin((y + n * 26) * 0.22) * 3; return [b[0] + t, b[1] + t, b[2] + t * 1.1];
      case 'marble': { var v = Math.abs(Math.sin(x * 0.012 + y * 0.018 + fbm(x / 90, y / 90, s + 5, 5) * 9)); var vein = Math.pow(1 - v, 14); var v2 = Math.pow(1 - Math.abs(Math.sin(x * 0.03 - y * 0.011 + n * 7)), 30);
        t = (n - 0.5) * 12; var c = [b[0] + t, b[1] + t, b[2] + t]; c = mix(c, [120, 134, 124], vein * 0.7); return mix(c, [150, 156, 150], v2 * 0.45); }
      case 'knifed': case 'walnut': { var g = fbm(x / 400, y / 16, s + 3, 3), gr = Math.sin((y + g * 40 + fbm(x / 120, y / 120, s, 2) * 30) * (id === 'walnut' ? 0.6 : 0.42));
        k = gr * 0.5 + 0.5; t = (n - 0.5) * 18 - Math.pow(k, 6) * 26 + (f - 0.5) * 6; return [b[0] + t, b[1] + t * 0.8, b[2] + t * 0.6]; }
      case 'lacquer': t = (n - 0.5) * 8 + (f - 0.5) * 3; var sheen = Math.max(0, 1 - Math.hypot(x - 120, y - 90) / 420) * 22; return [b[0] + t + sheen, b[1] + t + sheen * 0.9, b[2] + t + sheen * 0.9];
      case 'linen': { var w = (Math.sin(x * 2.1) * Math.sin(y * 2.1)) * 7, slub = Math.pow(vnoise(x / 2, y / 40, s + 7), 8) * 26 + Math.pow(vnoise(x / 40, y / 2, s + 8), 8) * 20; t = w - slub + (n - 0.5) * 14; return [b[0] + t, b[1] + t, b[2] + t * 0.9]; }
      case 'leather': { var peb = Math.pow(vnoise(x / 2.4, y / 2.4, s + 11), 3) * 16; t = (n - 0.5) * 26 - peb + (f - 0.5) * 4; return [b[0] + t, b[1] + t * 0.8, b[2] + t * 0.7]; }
      case 'soapstone': { var sp = hash2(x | 0, y | 0, s + 13) > 0.985 ? -30 : 0; t = (n - 0.5) * 20 + (f - 0.5) * 6 + sp; return [b[0] + t, b[1] + t, b[2] + t]; }
    }
    return b;
  }
  /** Paint a material into a rectangle of `ctx`, then shade it with the lamp (lit upper left, falling off to the lower right). */
  function fillSurface(ctx, id, x, y, w, h, seed) {
    var c = canvas(w, h), cx = c.getContext('2d'), img = cx.createImageData(c.width, c.height), d = img.data, i = 0;
    for (var py = 0; py < c.height; py++) for (var px = 0; px < c.width; px++, i += 4) {
      var v = surfaceAt(id, px + x, py + y, seed), lamp = 1.08 - 0.26 * ((px / c.width) * 0.55 + (py / c.height) * 0.45);
      d[i] = Math.max(0, Math.min(255, v[0] * lamp)); d[i + 1] = Math.max(0, Math.min(255, v[1] * lamp)); d[i + 2] = Math.max(0, Math.min(255, v[2] * lamp)); d[i + 3] = 255;
    }
    cx.putImageData(img, 0, 0); ctx.drawImage(c, x, y);
  }

  //---------------------------------------------------------------------------- the tavern table
  /** Oak planks under a hanging lamp: warm pool of light upper left, falling into shadow; seams, grain, knots, old rings. */
  function drawTable(ctx, W, H, seed) {
    var c = canvas(W, H), cx = c.getContext('2d'), img = cx.createImageData(W, H), d = img.data, i = 0, plank = 104;
    for (var y = 0; y < H; y++) for (var x = 0; x < W; x++, i += 4) {
      var row = Math.floor((y + 30) / plank), py = (y + 30) - row * plank, off = hash2(row, 1, seed) * 900;
      var g = fbm((x + off) / 500, py / 14, seed + row, 3), gr = Math.sin((py + g * 36) * 0.5) * 0.5 + 0.5, knot = 0;
      var kx = hash2(row, 2, seed) * W, ky = row * plank + plank * 0.5 - 30, kd = Math.hypot((x - kx) / 2.2, y - ky); if (kd < 26) knot = Math.pow(1 - kd / 26, 2) * 38 * (0.6 + 0.4 * Math.sin(kd * 1.3));
      var t = (fbm(x / 70, y / 70, seed + 5, 3) - 0.5) * 22 - Math.pow(gr, 5) * 22 - knot;
      var base = [98 + t, 62 + t * 0.8, 36 + t * 0.6];
      if (py < 3 || py > plank - 2) base = mix(base, [22, 12, 6], py < 3 ? 0.75 - py * 0.2 : 0.55);
      var lamp = Math.max(0.22, 1.12 - Math.hypot(x - W * 0.32, y - H * 0.28) / (W * 0.78));
      d[i] = base[0] * lamp; d[i + 1] = base[1] * lamp; d[i + 2] = base[2] * lamp; d[i + 3] = 255;
    }
    cx.putImageData(img, 0, 0); ctx.drawImage(c, 0, 0);
    // old mug rings and a scatter of scratches on the table itself
    var r = rng(seed ^ 0xA11E);
    for (var k = 0; k < 4; k++) { var rx = W * (0.55 + r() * 0.42), ry = H * (0.08 + r() * 0.84), rr = 26 + r() * 12; ctx.strokeStyle = 'rgba(28,14,6,' + (0.18 + r() * 0.12) + ')'; ctx.lineWidth = 2.2; ctx.beginPath(); ctx.arc(rx, ry, rr, r() * TAU, r() * TAU + 4.4); ctx.stroke(); }
  }

  //---------------------------------------------------------------------------- geometry
  /**
   * Where the board and the panels go for each game on an 816 x 624 screen. Square boards sit left with the panel at
   * the right; wide boards (fanorona, oware) sit across the top with the panel below.
   */
  function layout(gameId, W, H, C) {
    var G = C.GAMES[gameId], L = { game: gameId, pts: [] }, i;
    if (gameId === 'morris' || gameId === 'foxgeese') {
      L.board = { x: 14, y: 14, w: 560, h: 560 }; L.side = 'right';
      L.panel = { x: 588, y: 14, w: W - 602, h: H - 28 };
      var inner = 560 - 2 * 58, cell = inner / 6; L.cell = cell;
      for (i = 0; i < G.xy.length; i++) L.pts.push({ x: L.board.x + 58 + G.xy[i][0] * cell, y: L.board.y + 58 + G.xy[i][1] * cell });
      L.r = cell * (gameId === 'morris' ? 0.33 : 0.34);
    } else if (gameId === 'fanorona') {
      L.board = { x: 14, y: 14, w: W - 28, h: 404 }; L.side = 'below';
      var cw = (L.board.w - 2 * 52) / 8, ch = (L.board.h - 2 * 52) / 4, c2 = Math.min(cw, ch); L.cell = c2;
      var ox = L.board.x + (L.board.w - 8 * c2) / 2, oy = L.board.y + (L.board.h - 4 * c2) / 2;
      for (i = 0; i < 45; i++) L.pts.push({ x: ox + G.xy[i][0] * c2, y: oy + G.xy[i][1] * c2 });
      L.r = c2 * 0.3; L.panel = { x: 14, y: 432, w: W - 28, h: H - 446 };
    } else {   // oware: two rows of six pits and a store at each end
      // ⛔ found by looking (2026-09-28): counts set at a fixed offset sat ON the border band. The rows are placed so a
      // count clears the band's inner edge (12 + 22 from the slab) and still clears its own pit.
      L.board = { x: 20, y: 30, w: W - 40, h: 318 }; L.side = 'below';
      var pitW = (L.board.w - 2 * 108) / 6; L.cell = pitW; L.pitR = pitW * 0.42; L.countGap = 13;
      var inset = 34 + 12 + L.countGap + L.pitR;   // band inner edge (34) + half a 19 px figure's height, + gap + the pit
      for (i = 0; i < 12; i++) { var col = i < 6 ? i : 11 - i, row = i < 6 ? 1 : 0; L.pts.push({ x: L.board.x + 108 + (col + 0.5) * pitW, y: row ? L.board.y + L.board.h - inset : L.board.y + inset }); }
      L.stores = [{ x: L.board.x + L.board.w - 56, y: L.board.y + L.board.h / 2, w: 72, h: 232 }, { x: L.board.x + 56, y: L.board.y + L.board.h / 2, w: 72, h: 232 }];
      L.r = L.pitR * 0.19; L.panel = { x: 14, y: 362, w: W - 28, h: H - 376 };
    }
    return L;
  }

  //---------------------------------------------------------------------------- lines and borders
  /** One line in the material's own treatment. A groove is a dark cut with a lit lower lip; a scribe is chalk; etc. */
  function strokeLine(ctx, B, x1, y1, x2, y2, wgt) {
    var ink = B.ink, w = wgt || 1;
    ctx.lineCap = 'round';
    switch (B.line) {
      case 'groove': ctx.strokeStyle = rgb(mix(B.base, [255, 236, 200], 0.35), 0.55); ctx.lineWidth = 3.2 * w; seg(ctx, x1 + 1.2, y1 + 1.4, x2 + 1.2, y2 + 1.4);
        ctx.strokeStyle = rgb(ink, 0.9); ctx.lineWidth = 3.4 * w; seg(ctx, x1, y1, x2, y2); ctx.strokeStyle = rgb([16, 8, 4], 0.55); ctx.lineWidth = 1.2 * w; seg(ctx, x1 - 0.6, y1 - 0.6, x2 - 0.6, y2 - 0.6); break;
      case 'scribe': ctx.strokeStyle = rgb(ink, 0.18); ctx.lineWidth = 4.2 * w; seg(ctx, x1, y1, x2, y2); ctx.strokeStyle = rgb(ink, 0.78); ctx.lineWidth = 1.8 * w; seg(ctx, x1, y1, x2, y2); break;
      case 'inlay': case 'brass': case 'gilt': ctx.strokeStyle = rgb([10, 8, 6], 0.45); ctx.lineWidth = 4.4 * w; seg(ctx, x1 + 0.8, y1 + 1, x2 + 0.8, y2 + 1);
        ctx.strokeStyle = rgb(ink); ctx.lineWidth = 3 * w; seg(ctx, x1, y1, x2, y2); ctx.strokeStyle = rgb(mix(ink, [255, 250, 230], 0.55), 0.8); ctx.lineWidth = 1 * w; seg(ctx, x1 - 0.7, y1 - 0.7, x2 - 0.7, y2 - 0.7); break;
      case 'stitch': ctx.strokeStyle = rgb(ink); ctx.lineWidth = 2.6 * w; ctx.setLineDash([6, 4]); seg(ctx, x1, y1, x2, y2); ctx.setLineDash([]); break;
      case 'burn': ctx.strokeStyle = rgb(ink, 0.35); ctx.lineWidth = 6 * w; seg(ctx, x1, y1, x2, y2); ctx.strokeStyle = rgb(ink, 0.9); ctx.lineWidth = 2.4 * w; seg(ctx, x1, y1, x2, y2); break;
    }
  }
  function seg(ctx, a, b, c, d) { ctx.beginPath(); ctx.moveTo(a, b); ctx.lineTo(c, d); ctx.stroke(); }

  /** A border band worked at a steady PITCH (never a typed count: Icon_Doctrine §22b-1a); returns how many marks it made. */
  function drawBorder(ctx, B, x, y, w, h, band) {
    var marks = 0, pitch = band * 1.05, ink = B.line === 'stitch' || B.line === 'burn' || B.line === 'groove' ? B.ink : B.ink;
    function run(x1, y1, x2, y2, nx, ny) {
      var len = Math.hypot(x2 - x1, y2 - y1), n = Math.max(1, Math.floor(len / pitch)), step = len / n, ux = (x2 - x1) / len, uy = (y2 - y1) / len;
      for (var k = 0; k < n; k++) {
        var cx = x1 + ux * (k + 0.5) * step, cy = y1 + uy * (k + 0.5) * step, a = band * 0.34;
        ctx.save(); ctx.translate(cx, cy);
        switch (B.motif) {
          case 'chevron': ctx.strokeStyle = rgb(ink, 0.7); ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(-ux * a - nx * a, -uy * a - ny * a); ctx.lineTo(nx * a * 0.2, ny * a * 0.2); ctx.lineTo(ux * a - nx * a, uy * a - ny * a); ctx.stroke(); break;
          case 'key': ctx.strokeStyle = rgb(ink, 0.8); ctx.lineWidth = 1.8; ctx.beginPath(); ctx.moveTo(-ux * a - nx * a, -uy * a - ny * a); ctx.lineTo(-ux * a + nx * a, -uy * a + ny * a); ctx.lineTo(ux * a + nx * a, uy * a + ny * a); ctx.lineTo(ux * a - nx * a * 0.2, uy * a - ny * a * 0.2); ctx.lineTo(-ux * a * 0.2 - nx * a * 0.2, -uy * a * 0.2 - ny * a * 0.2); ctx.stroke(); break;
          case 'notch': ctx.fillStyle = rgb(B.ink, 0.75); ctx.beginPath(); ctx.moveTo(-ux * a, -uy * a); ctx.lineTo(ux * a, uy * a); ctx.lineTo(nx * a * 0.9, ny * a * 0.9); ctx.closePath(); ctx.fill();
            ctx.strokeStyle = rgb(mix(B.base, [255, 240, 210], 0.4), 0.5); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(ux * a, uy * a); ctx.lineTo(nx * a * 0.9, ny * a * 0.9); ctx.stroke(); break;
          case 'lozenge': ctx.fillStyle = rgb(ink); ctx.beginPath(); ctx.moveTo(-ux * a, -uy * a); ctx.lineTo(nx * a * 0.55, ny * a * 0.55); ctx.lineTo(ux * a, uy * a); ctx.lineTo(-nx * a * 0.55, -ny * a * 0.55); ctx.closePath(); ctx.fill(); break;
          case 'stitch': ctx.strokeStyle = rgb(ink); ctx.lineWidth = 2.2; ctx.beginPath(); ctx.moveTo(-ux * a - nx * a * 0.6, -uy * a - ny * a * 0.6); ctx.lineTo(ux * a + nx * a * 0.6, uy * a + ny * a * 0.6); ctx.stroke(); break;
          // ⛔ found by looking (2026-09-28): outlined ovals at the pitch read as a row of zeros. A rope is filled strands,
          // each LONGER than the pitch so it overlaps the next, slanted, lit on its upper edge.
          case 'rope': { var ang = Math.atan2(uy, ux) + 0.75; ctx.fillStyle = rgb(ink, 0.9); ctx.beginPath(); ctx.ellipse(0, 0, a * 1.75, a * 0.62, ang, 0, TAU); ctx.fill();
            ctx.strokeStyle = rgb(mix(B.base, [255, 236, 200], 0.45), 0.7); ctx.lineWidth = 1.2; ctx.beginPath(); ctx.ellipse(0, 0, a * 1.75, a * 0.62, ang, Math.PI * 1.1, Math.PI * 1.8); ctx.stroke(); break; }
          case 'bead': ctx.fillStyle = rgb(ink); ctx.beginPath(); ctx.arc(0, 0, a * 0.42, 0, TAU); ctx.fill(); ctx.fillStyle = rgb([255, 244, 210], 0.7); ctx.beginPath(); ctx.arc(-a * 0.13, -a * 0.13, a * 0.14, 0, TAU); ctx.fill(); break;
        }
        ctx.restore(); marks++;
      }
    }
    var o = band / 2;
    run(x + o, y + o, x + w - o, y + o, 0, 1); run(x + w - o, y + o, x + w - o, y + h - o, -1, 0);
    run(x + w - o, y + h - o, x + o, y + h - o, 0, -1); run(x + o, y + h - o, x + o, y + o, 1, 0);
    return marks;
  }

  /** The board's slab: drop shadow on the table, a bevelled edge lit upper-left, the surface, the border band. */
  function drawSlab(ctx, B, id, x, y, w, h, seed) {
    ctx.save(); ctx.shadowColor = 'rgba(0,0,0,0.6)'; ctx.shadowBlur = 22; ctx.shadowOffsetX = 9; ctx.shadowOffsetY = 12; ctx.fillStyle = rgb(B.edge); rrect(ctx, x, y, w, h, 10); ctx.fill(); ctx.restore();
    var eg = ctx.createLinearGradient(x, y, x + w, y + h); eg.addColorStop(0, rgb(mix(B.edge, [255, 240, 210], 0.28))); eg.addColorStop(1, rgb(mix(B.edge, [0, 0, 0], 0.35))); ctx.fillStyle = eg; rrect(ctx, x, y, w, h, 10); ctx.fill();
    ctx.save(); rrect(ctx, x + 7, y + 7, w - 14, h - 14, 6); ctx.clip(); fillSurface(ctx, id, x + 7, y + 7, w - 14, h - 14, seed); ctx.restore();
    ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 1.5; rrect(ctx, x + 7, y + 7, w - 14, h - 14, 6); ctx.stroke();
  }
  function rrect(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r); ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h); ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r); ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.closePath(); }

  /**
   * Wear of use: scratches and chipped edges; returns counts so a test can see the layer is drawn.
   * ⛔ found by looking (2026-09-28): mug rings on the PLAYING surface sat round points and between pits and read as a
   * selection ring or a pit. Rings belong to the tabletop (drawTable), never to a board.
   */
  function drawWear(ctx, B, x, y, w, h, seed, amount) {
    var r = rng(seed ^ 0x3EA5), n = { scratches: 0, chips: 0 }, a = amount === undefined ? 1 : amount, k;
    var dark = lum(B.base) > 0.2;
    for (k = 0; k < Math.round(14 * a); k++) { var sx = x + 12 + r() * (w - 24), sy = y + 12 + r() * (h - 24), an = r() * TAU, l = 6 + r() * 26; ctx.strokeStyle = rgb(dark ? [255, 244, 224] : [60, 50, 40], 0.16 + r() * 0.14); ctx.lineWidth = 0.8 + r() * 0.6; seg(ctx, sx, sy, sx + Math.cos(an) * l, sy + Math.sin(an) * l); n.scratches++; }
    for (k = 0; k < Math.round(5 * a); k++) { var side = Math.floor(r() * 4), t = 0.08 + r() * 0.84, cxp = side % 2 === 0 ? x + t * w : (side === 1 ? x + w - 3 : x + 3), cyp = side % 2 === 1 ? y + t * h : (side === 0 ? y + 3 : y + h - 3);
      ctx.fillStyle = rgb(mix(B.edge, [0, 0, 0], 0.45), 0.85); ctx.beginPath(); ctx.arc(cxp, cyp, 2 + r() * 3.5, 0, TAU); ctx.fill(); n.chips++; }
    return n;
  }

  /** The whole board for a game, drawn once when it opens. Returns {lines, points, border, wear} counts. */
  function drawBoard(ctx, L, style, C) {
    var B = BOARDS[style.board], b = L.board, G = C.GAMES[L.game], out = { lines: 0, points: 0, border: 0, wear: null, pits: 0 }, i, band = 22;
    drawSlab(ctx, B, style.board, b.x, b.y, b.w, b.h, style.seed);
    out.border = drawBorder(ctx, B, b.x + 12, b.y + 12, b.w - 24, b.h - 24, band);
    ctx.strokeStyle = rgb(B.ink, 0.55); ctx.lineWidth = 1.4; ctx.strokeRect(b.x + 12 + band + 3, b.y + 12 + band + 3, b.w - 24 - 2 * band - 6, b.h - 24 - 2 * band - 6);
    if (L.game === 'oware') {
      for (i = 0; i < 12; i++) { drawPit(ctx, B, L.pts[i].x, L.pts[i].y, L.pitR, L.pitR * 0.86); out.pits++; }
      for (i = 0; i < 2; i++) { var s = L.stores[i]; drawPit(ctx, B, s.x, s.y, s.w / 2, s.h / 2); out.pits++; }
    } else {
      G.edges.forEach(function (e) { var p = L.pts[e[0]], q = L.pts[e[1]]; strokeLine(ctx, B, p.x, p.y, q.x, q.y, L.game === 'fanorona' ? 0.85 : 1); out.lines++; });
      for (i = 0; i < L.pts.length; i++) { var pt = L.pts[i]; drawPoint(ctx, B, pt.x, pt.y, L.game === 'fanorona' ? 3.2 : 5); out.points++; }
    }
    out.wear = drawWear(ctx, B, b.x + 10, b.y + 10, b.w - 20, b.h - 20, style.seed, style.wear);
    return out;
  }
  function drawPoint(ctx, B, x, y, r) {
    if (B.line === 'groove' || B.line === 'burn') { ctx.fillStyle = rgb(B.ink); ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); ctx.strokeStyle = rgb(mix(B.base, [255, 236, 200], 0.4), 0.6); ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(x, y, r, 0.2, 1.9); ctx.stroke(); }
    else { ctx.fillStyle = rgb(B.ink); ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); ctx.fillStyle = rgb([255, 250, 236], 0.45); ctx.beginPath(); ctx.arc(x - r * 0.3, y - r * 0.3, r * 0.4, 0, TAU); ctx.fill(); }
  }
  /** A carved cup: shadowed on the side nearer the lamp (the rim hides it), lit on the far side. */
  function drawPit(ctx, B, x, y, rx, ry) {
    var g = ctx.createRadialGradient(x + rx * 0.28, y + ry * 0.3, rx * 0.1, x, y, Math.max(rx, ry));
    g.addColorStop(0, rgb(mix(B.base, [255, 240, 214], 0.18))); g.addColorStop(0.62, rgb(mix(B.base, [0, 0, 0], 0.28))); g.addColorStop(1, rgb(mix(B.base, [0, 0, 0], 0.62)));
    ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(x, y, rx, ry, 0, 0, TAU); ctx.fill();
    ctx.strokeStyle = rgb(mix(B.base, [255, 240, 214], 0.45), 0.75); ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(x, y, rx, ry, 0, 0.1, Math.PI - 0.1); ctx.stroke();
    ctx.strokeStyle = rgb([0, 0, 0], 0.5); ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(x, y, rx, ry, 0, Math.PI + 0.1, TAU - 0.1); ctx.stroke();
  }

  //---------------------------------------------------------------------------- the men
  // Each set: a light and a dark man, and the seed Oware is played with. `fox` is Fox and Geese's fox, whatever the set.
  var SETS = {
    stones: { name: 'River stones', light: [214, 206, 188], dark: [58, 60, 66], kind: 'stone', seed: 'pebble' },
    bone:   { name: 'Bone and horn', light: [232, 220, 188], dark: [92, 56, 34], kind: 'turned', seed: 'cowrie' },
    glass:  { name: 'Glass', light: [214, 232, 236], dark: [34, 62, 150], kind: 'glass', seed: 'bead' },
    coins:  { name: 'Silver and copper', light: [196, 200, 204], dark: [172, 98, 58], kind: 'coin', seed: 'coin' },
    clay:   { name: 'Fired clay', light: [196, 104, 62], dark: [36, 30, 30], kind: 'clay', seed: 'clay' },
    boxwood:{ name: 'Boxwood and ebony', light: [222, 184, 112], dark: [40, 28, 24], kind: 'turned', seed: 'bean' },
  };
  var SET_IDS = Object.keys(SETS);
  var FOX = [204, 92, 40];

  /**
   * One man centred at (x, y), radius r, lit from the upper left. side 0 = light, 1 = dark, 'fox' = the fox.
   * `lift` 0..1 raises it off the board (a longer, softer shadow). `seed` varies stones and grain.
   */
  function drawMan(ctx, x, y, r, setId, side, seed, lift) {
    var S = SETS[setId], col = side === 'fox' ? FOX : (side ? S.dark : S.light), kind = side === 'fox' ? 'fox' : S.kind, rr = rng(seed || 1), L = lift || 0;
    var sx = 3 + L * 9, sy = 4 + L * 12;
    ctx.save(); ctx.fillStyle = 'rgba(0,0,0,' + (0.42 - L * 0.12) + ')'; ctx.filter = 'blur(' + (2 + L * 4) + 'px)'; ctx.beginPath(); ctx.ellipse(x + sx, y + sy, r * 1.02, r * 0.94, 0, 0, TAU); ctx.fill(); ctx.restore();
    var hi = mix(col, [255, 252, 244], 0.55), lo = mix(col, [0, 0, 0], 0.45), g;
    if (kind === 'stone' || kind === 'fox') {
      ctx.beginPath(); var n = 28, ph = rr() * 10; for (var k = 0; k <= n; k++) { var a = k / n * TAU, rad = r * (1 + 0.07 * Math.sin(a * 2 + ph) + 0.04 * Math.sin(a * 3 + ph * 2)); var px = x + Math.cos(a) * rad * (kind === 'fox' ? 1 : 1.06), py = y + Math.sin(a) * rad * 0.94; if (k) ctx.lineTo(px, py); else ctx.moveTo(px, py); } ctx.closePath();
      g = ctx.createRadialGradient(x - r * 0.35, y - r * 0.4, r * 0.1, x, y, r * 1.1); g.addColorStop(0, rgb(hi)); g.addColorStop(0.55, rgb(col)); g.addColorStop(1, rgb(lo)); ctx.fillStyle = g; ctx.fill();
      ctx.save(); ctx.clip(); for (k = 0; k < 40; k++) { ctx.fillStyle = rgb(rr() < 0.5 ? mix(col, [0, 0, 0], 0.4) : mix(col, [255, 255, 255], 0.35), 0.35); ctx.fillRect(x - r + rr() * 2 * r, y - r + rr() * 2 * r, 1.2, 1.2); }
      if (kind === 'fox') { ctx.strokeStyle = rgb([232, 196, 104]); ctx.lineWidth = Math.max(2, r * 0.12); ctx.beginPath(); ctx.arc(x, y, r * 0.8, 0, TAU); ctx.stroke(); ctx.fillStyle = rgb([250, 232, 200], 0.9); ctx.beginPath(); ctx.arc(x, y, r * 0.22, 0, TAU); ctx.fill(); }
      ctx.restore();
    } else if (kind === 'turned') {
      g = ctx.createRadialGradient(x - r * 0.3, y - r * 0.35, r * 0.1, x, y, r); g.addColorStop(0, rgb(hi)); g.addColorStop(0.6, rgb(col)); g.addColorStop(1, rgb(lo));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
      for (var q = 1; q <= 3; q++) { ctx.strokeStyle = rgb(mix(col, [0, 0, 0], 0.4), 0.55); ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(x, y, r * (0.25 * q + 0.08), 0, TAU); ctx.stroke(); ctx.strokeStyle = rgb(hi, 0.45); ctx.lineWidth = 0.8; ctx.beginPath(); ctx.arc(x, y, r * (0.25 * q + 0.08) + 1, Math.PI * 1.05, Math.PI * 1.7); ctx.stroke(); }
    } else if (kind === 'glass') {
      g = ctx.createRadialGradient(x + r * 0.2, y + r * 0.25, r * 0.1, x, y, r); g.addColorStop(0, rgb(mix(col, [255, 255, 255], 0.35), 0.95)); g.addColorStop(0.7, rgb(col, 0.9)); g.addColorStop(1, rgb(lo, 0.95));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.85)'; ctx.beginPath(); ctx.ellipse(x - r * 0.38, y - r * 0.42, r * 0.26, r * 0.15, -0.7, 0, TAU); ctx.fill();
      ctx.strokeStyle = rgb(mix(col, [255, 255, 255], 0.6), 0.55); ctx.lineWidth = 1.6; ctx.beginPath(); ctx.arc(x, y, r * 0.8, 0.3, 1.6); ctx.stroke();
    } else if (kind === 'coin') {
      g = ctx.createLinearGradient(x - r, y - r, x + r, y + r); g.addColorStop(0, rgb(hi)); g.addColorStop(0.5, rgb(col)); g.addColorStop(1, rgb(lo));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
      ctx.strokeStyle = rgb(lo); ctx.lineWidth = Math.max(1.5, r * 0.1); ctx.beginPath(); ctx.arc(x, y, r * 0.82, 0, TAU); ctx.stroke();
      ctx.fillStyle = rgb(lo, 0.8); for (var p = 0; p < 7; p++) { var an = p / 7 * TAU - Math.PI / 2; ctx.beginPath(); ctx.ellipse(x + Math.cos(an) * r * 0.38, y + Math.sin(an) * r * 0.38, r * 0.16, r * 0.07, an, 0, TAU); ctx.fill(); }
      ctx.beginPath(); ctx.arc(x, y, r * 0.13, 0, TAU); ctx.fill();
    } else if (kind === 'clay') {
      g = ctx.createRadialGradient(x - r * 0.3, y - r * 0.35, r * 0.1, x, y, r); g.addColorStop(0, rgb(hi)); g.addColorStop(0.65, rgb(col)); g.addColorStop(1, rgb(lo));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
      ctx.fillStyle = rgb(lo, 0.55); ctx.beginPath(); ctx.ellipse(x + r * 0.1, y + r * 0.05, r * 0.3, r * 0.24, 0.4, 0, TAU); ctx.fill();
      ctx.strokeStyle = rgb(hi, 0.4); ctx.lineWidth = 1; ctx.beginPath(); ctx.ellipse(x + r * 0.1, y + r * 0.05, r * 0.3, r * 0.24, 0.4, 2.2, 4.6); ctx.stroke();
    }
    ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(x, y, r, 0.2, 2.9); ctx.stroke();
  }

  /** The count of a pit or store, cut into the board beside it: dark figures with a lit lower lip, or light on dark. */
  function drawCount(ctx, x, y, n, B, size) {
    var s = size || 20, ink = pickInk(B.base, [B.ink, [32, 20, 12], [244, 234, 210]], 4.5);
    ctx.font = 'bold ' + s + 'px ' + FACE; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = rgb(lum(ink) < lum(B.base) ? mix(B.base, [255, 244, 220], 0.5) : [0, 0, 0], 0.55); ctx.fillText(String(n), x + 1, y + 1.5);
    ctx.fillStyle = rgb(ink); ctx.fillText(String(n), x, y);
  }
  /** Oware: `n` seeds of the set's kind heaped in a pit (a packed spiral). Returns how many were drawn (capped at 30). */
  function drawSeeds(ctx, x, y, pitR, n, setId, seed) {
    var S = SETS[setId], r = rng(seed || 3), sr = pitR * 0.19, placed = Math.min(n, 30);
    for (var k = 0; k < placed; k++) {
      var a = k * 2.39996 + r() * 0.4, d = Math.sqrt(k + 0.5) * sr * 1.05 * (placed > 18 ? 0.86 : 1), px = x + Math.cos(a) * Math.min(d, pitR * 0.72), py = y + Math.sin(a) * Math.min(d, pitR * 0.62);
      var col = mix(S.light, S.dark, (k * 37 % 11) / 22), rot = r() * TAU;
      ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.ellipse(px + 1.5, py + 2, sr, sr * 0.8, rot, 0, TAU); ctx.fill();
      var g = ctx.createRadialGradient(px - sr * 0.4, py - sr * 0.4, 0.5, px, py, sr * 1.2); g.addColorStop(0, rgb(mix(col, [255, 255, 255], 0.5))); g.addColorStop(1, rgb(mix(col, [0, 0, 0], 0.35)));
      ctx.fillStyle = g; ctx.beginPath();
      if (S.seed === 'cowrie' || S.seed === 'bean') ctx.ellipse(px, py, sr * 1.1, sr * 0.72, rot, 0, TAU); else ctx.arc(px, py, sr * (S.seed === 'pebble' ? 0.95 + r() * 0.2 : 0.9), 0, TAU);
      ctx.fill();
      if (S.seed === 'cowrie') { ctx.strokeStyle = rgb([90, 60, 30], 0.8); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(px - Math.cos(rot) * sr * 0.7, py - Math.sin(rot) * sr * 0.7); ctx.lineTo(px + Math.cos(rot) * sr * 0.7, py + Math.sin(rot) * sr * 0.7); ctx.stroke(); }
      if (S.seed === 'bean') { ctx.strokeStyle = rgb([255, 240, 220], 0.5); ctx.lineWidth = 1; ctx.beginPath(); ctx.ellipse(px, py, sr * 0.6, sr * 0.3, rot, 3.6, 5.8); ctx.stroke(); }
      if (S.seed === 'coin') { ctx.strokeStyle = rgb(mix(col, [0, 0, 0], 0.5), 0.8); ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(px, py, sr * 0.6, 0, TAU); ctx.stroke(); }
    }
    return placed;
  }

  //---------------------------------------------------------------------------- style: chosen from the opponent's name
  /** The board and set an opponent plays with, from their name unless the buyer named one. */
  function styleFor(name, gameId, board, set) {
    var h = hashString(String(name || 'stranger') + '|' + gameId), bIds = gameId === 'oware' ? ['walnut', 'soapstone', 'knifed', 'lacquer', 'marble', 'leather'] : BOARD_IDS;
    return { board: BOARDS[board] ? board : bIds[h % bIds.length], set: SETS[set] ? set : SET_IDS[(h >>> 8) % SET_IDS.length], seed: h, wear: 0.5 + ((h >>> 16) % 100) / 100 };
  }

  //---------------------------------------------------------------------------- panels
  /** A worked-brass plaque; `state` idle | on | off. */
  function drawPlaque(ctx, x, y, w, h, label, state) {
    var base = state === 'off' ? [96, 84, 66] : state === 'on' ? [232, 196, 116] : [196, 156, 84];
    var g = ctx.createLinearGradient(x, y, x, y + h); g.addColorStop(0, rgb(mix(base, [255, 250, 230], 0.35))); g.addColorStop(1, rgb(mix(base, [0, 0, 0], 0.3)));
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; rrect(ctx, x + 2, y + 3, w, h, 6); ctx.fill(); ctx.fillStyle = g; rrect(ctx, x, y, w, h, 6); ctx.fill();
    ctx.strokeStyle = rgb(mix(base, [0, 0, 0], 0.55)); ctx.lineWidth = 1.5; rrect(ctx, x + 3, y + 3, w - 6, h - 6, 4); ctx.stroke();
    // ⛔ found by looking (2026-09-28): "Concede" ran past a 68 px plaque. The label is fitted: the size steps down
    // until the measured width clears the plaque's inner rule.
    var fs = Math.round(h * 0.46); ctx.font = 'bold ' + fs + 'px ' + FACE; while (fs > 10 && ctx.measureText(label).width > w - 14) { fs--; ctx.font = 'bold ' + fs + 'px ' + FACE; }
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = rgb(pickInk(base, [[44, 26, 10], [250, 240, 214]], 4.5)); ctx.fillText(label, x + w / 2, y + h / 2 + 1);
    return fs;
  }
  /** The opponent's card: a parchment slip pinned to the table. */
  function drawPlacard(ctx, x, y, w, h, info) {
    var paper = [230, 214, 178];
    ctx.save(); ctx.shadowColor = 'rgba(0,0,0,0.55)'; ctx.shadowBlur = 12; ctx.shadowOffsetX = 5; ctx.shadowOffsetY = 7; ctx.fillStyle = rgb(paper); ctx.fillRect(x, y, w, h); ctx.restore();
    ctx.save(); ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip(); fillSurface(ctx, 'linen', x, y, w, h, 77); ctx.fillStyle = 'rgba(236,222,186,0.72)'; ctx.fillRect(x, y, w, h); ctx.restore();
    ctx.strokeStyle = 'rgba(90,60,30,0.6)'; ctx.lineWidth = 1; ctx.strokeRect(x + 5.5, y + 5.5, w - 11, h - 11);
    var ink = [52, 30, 16];
    ctx.fillStyle = rgb(ink); ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
    ctx.font = 'italic ' + 15 + 'px ' + FACE; ctx.fillText(info.game, x + w / 2, y + 28);
    ctx.font = 'bold ' + fitSize(ctx, info.name, w - 24, 26, 14) + 'px ' + FACE; ctx.fillText(info.name, x + w / 2, y + 60);
    ctx.font = 'italic 14px ' + FACE; ctx.fillStyle = rgb([110, 60, 30]); ctx.fillText(info.grade, x + w / 2, y + 80);
    ctx.fillStyle = rgb(ink); ctx.font = '14px ' + FACE;
    for (var i = 0; i < info.lines.length; i++) ctx.fillText(info.lines[i], x + w / 2, y + 108 + i * 20);
  }
  function fitSize(ctx, text, w, max, min) { for (var s = max; s > min; s--) { ctx.font = 'bold ' + s + 'px ' + FACE; if (ctx.measureText(text).width <= w) return s; } return min; }
  /** A one-line status strip in lamp-lit letters on a dark band. */
  function drawStatus(ctx, w, h, text) {
    ctx.clearRect(0, 0, w, h); var g = ctx.createLinearGradient(0, 0, 0, h); g.addColorStop(0, 'rgba(20,12,6,0.78)'); g.addColorStop(1, 'rgba(12,6,2,0.86)');
    ctx.fillStyle = g; rrect(ctx, 0, 0, w, h, 8); ctx.fill(); ctx.strokeStyle = 'rgba(200,160,90,0.5)'; ctx.lineWidth = 1; rrect(ctx, 1.5, 1.5, w - 3, h - 3, 7); ctx.stroke();
    ctx.fillStyle = '#f1dfb4'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    var s = 18; ctx.font = s + 'px ' + FACE; while (s > 14 && ctx.measureText(text).width > w - 20) { s--; ctx.font = s + 'px ' + FACE; }
    if (ctx.measureText(text).width <= w - 20) { ctx.fillText(text, w / 2, h / 2 + 1); return 1; }
    // ⛔ found by looking (2026-09-28): a long line on the narrow panel shrank to 11 px and was STILL clipped at both
    // ends. Two lines, broken at the word nearest the middle, each fitted.
    var words = String(text).split(' '), best = 1, bd = Infinity;
    for (var i = 1; i < words.length; i++) { var a = words.slice(0, i).join(' '), b = words.slice(i).join(' '), d = Math.abs(ctx.measureText(a).width - ctx.measureText(b).width); if (d < bd) { bd = d; best = i; } }
    var l1 = words.slice(0, best).join(' '), l2 = words.slice(best).join(' ');
    s = Math.min(16, Math.floor((h - 8) / 2.3)); ctx.font = s + 'px ' + FACE; while (s > 10 && Math.max(ctx.measureText(l1).width, ctx.measureText(l2).width) > w - 16) { s--; ctx.font = s + 'px ' + FACE; }
    ctx.fillText(l1, w / 2, h / 2 - s * 0.6); ctx.fillText(l2, w / 2, h / 2 + s * 0.65);
    return 2;
  }
  /** A ring round a point: 'target' (a legal next click), 'sel' (the man picked up), 'take' (a man that can be taken), 'last'. */
  function drawMarker(ctx, x, y, r, kind) {
    var col = kind === 'take' ? [236, 84, 60] : kind === 'sel' ? [255, 226, 130] : kind === 'last' ? [140, 200, 255] : [250, 214, 120];
    ctx.strokeStyle = rgb([0, 0, 0], 0.5); ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.stroke();
    ctx.strokeStyle = rgb(col, kind === 'target' ? 0.8 : 1); ctx.lineWidth = kind === 'target' ? 2.4 : 3.2; ctx.setLineDash(kind === 'target' ? [5, 4] : []); ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.stroke(); ctx.setLineDash([]);
    if (kind === 'take') { ctx.lineWidth = 3; seg(ctx, x - r * 0.45, y - r * 0.45, x + r * 0.45, y + r * 0.45); seg(ctx, x + r * 0.45, y - r * 0.45, x - r * 0.45, y + r * 0.45); }
  }
  /** The end of the game: a slip with the verdict over a dimmed table, centred on the BOARD (cx, cy), never the panel. */
  function drawVerdict(ctx, W, H, info, cx, cy) {
    ctx.clearRect(0, 0, W, H); ctx.fillStyle = 'rgba(6,3,1,0.55)'; ctx.fillRect(0, 0, W, H);
    var w = 440, h = 190, x = (cx === undefined ? W / 2 : cx) - w / 2, y = (cy === undefined ? H / 2 : cy) - h / 2;
    drawPlacard(ctx, x, y, w, h, { game: info.game, name: info.title, grade: info.sub, lines: info.lines });
  }

  return {
    VERSION: '1.0.0', FACE: FACE, BOARDS: BOARDS, BOARD_IDS: BOARD_IDS, SETS: SETS, SET_IDS: SET_IDS, FOX: FOX,
    rgb: rgb, mix: mix, lum: lum, contrast: contrast, pickInk: pickInk, hashString: hashString, rng: rng, fbm: fbm, surfaceAt: surfaceAt,
    drawTable: drawTable, layout: layout, drawBoard: drawBoard, drawSlab: drawSlab, drawBorder: drawBorder, drawWear: drawWear, strokeLine: strokeLine,
    drawPit: drawPit, drawMan: drawMan, drawSeeds: drawSeeds, drawCount: drawCount, rrect: rrect, styleFor: styleFor, drawPlaque: drawPlaque, drawPlacard: drawPlacard, drawStatus: drawStatus,
    drawMarker: drawMarker, drawVerdict: drawVerdict, fillSurface: fillSurface,
  };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = TaproomDraw;
