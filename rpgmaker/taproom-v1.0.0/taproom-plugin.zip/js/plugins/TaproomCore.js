//=============================================================================
// TaproomCore.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Taproom core - the rules of four historic tavern board
 * games and the opponent who plays them. Place ABOVE TaproomDraw and Taproom.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The rules and the computer opponent for Taproom. No parameters or commands
 * of its own; Taproom.js is the file you configure. Must be installed and
 * listed above Taproom.js.
 *
 * Pure logic: nothing here touches the screen and nothing uses Math.random.
 *
 * THE GAMES
 *   morris    Nine Men's Morris: place nine men each, make a row of three
 *             (a mill) to take one of the other side's men, then move along
 *             the lines; down to three men, you may fly anywhere. Win by
 *             leaving the other side two men or no move.
 *   foxgeese  Fox and Geese: one fox against thirteen geese on the cross
 *             board. Geese step forward or sideways and win by trapping the
 *             fox; the fox steps any way and jumps geese to take them, and
 *             wins by taking enough that the flock cannot trap it.
 *   oware     Oware (abapa): twelve pits, forty-eight seeds. Sow a pit
 *             around the board; a last seed that makes two or three in an
 *             enemy pit takes them, and the pits behind it. First to 25.
 *   fanorona  Fanorona: 22 men each on a 5 x 9 board of lines. Move toward
 *             an enemy line to take it (approach) or away from one
 *             (withdrawal), and keep taking with the same man. Taking is
 *             compulsory. Take every enemy man to win.
 *
 * THE OPPONENT searches ahead with alpha-beta. Its strength (1 to 5) sets how
 * far it looks and how often it misjudges. The search runs in small slices
 * spread over frames, and gives the same move however it is sliced.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var TaproomCore = (function () {
  'use strict';

  function hashString(s) { var h = 0x811c9dc5; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h >>> 0; }
  function rng(seed) { var a = seed >>> 0; return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  var WIN = 100000;

  //============================================================================ Nine Men's Morris
  // Points 0..23 on three nested squares; XY on a 7 x 7 lattice.
  var MXY = [[0, 0], [3, 0], [6, 0], [1, 1], [3, 1], [5, 1], [2, 2], [3, 2], [4, 2], [0, 3], [1, 3], [2, 3], [4, 3], [5, 3], [6, 3], [2, 4], [3, 4], [4, 4], [1, 5], [3, 5], [5, 5], [0, 6], [3, 6], [6, 6]];
  var MEDGES = [[0, 1], [1, 2], [0, 9], [9, 21], [21, 22], [22, 23], [2, 14], [14, 23], [3, 4], [4, 5], [3, 10], [10, 18], [18, 19], [19, 20], [5, 13], [13, 20], [6, 7], [7, 8], [6, 11], [11, 15], [15, 16], [16, 17], [8, 12], [12, 17], [1, 4], [4, 7], [9, 10], [10, 11], [12, 13], [13, 14], [16, 19], [19, 22]];
  var MMILLS = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9, 10, 11], [12, 13, 14], [15, 16, 17], [18, 19, 20], [21, 22, 23], [0, 9, 21], [3, 10, 18], [6, 11, 15], [1, 4, 7], [16, 19, 22], [8, 12, 17], [5, 13, 20], [2, 14, 23]];
  var MADJ = [], MMILLOF = [];
  (function () { var i; for (i = 0; i < 24; i++) { MADJ.push([]); MMILLOF.push([]); } MEDGES.forEach(function (e) { MADJ[e[0]].push(e[1]); MADJ[e[1]].push(e[0]); }); MMILLS.forEach(function (m, k) { m.forEach(function (p) { MMILLOF[p].push(k); }); }); }());

  var morris = {
    id: 'morris', name: "Nine Men's Morris", sides: ['light', 'dark'], points: 24, xy: MXY, edges: MEDGES, mills: MMILLS,
    init: function (opts) { var c = []; for (var i = 0; i < 24; i++) c.push(-1); return { g: 'morris', cells: c, hand: [9, 9], turn: 0, ply: 0, quiet: 0, flying: !(opts && opts.flying === false) }; },
    clone: function (s) { return { g: 'morris', cells: s.cells.slice(), hand: s.hand.slice(), turn: s.turn, ply: s.ply, quiet: s.quiet, flying: s.flying }; },
    count: function (s, side) { var n = 0; for (var i = 0; i < 24; i++) if (s.cells[i] === side) n++; return n; },
    inMill: function (cells, p) { var ms = MMILLOF[p], v = cells[p]; if (v < 0) return false; for (var k = 0; k < ms.length; k++) { var m = MMILLS[ms[k]]; if (cells[m[0]] === v && cells[m[1]] === v && cells[m[2]] === v) return true; } return false; },
    /** Men of `side` the mover may take: any not in a mill, or any at all if every one is in a mill. */
    removable: function (cells, side) { var free = [], all = []; for (var i = 0; i < 24; i++) if (cells[i] === side) { all.push(i); if (!morris.inMill(cells, i)) free.push(i); } return free.length ? free : all; },
    phase: function (s, side) { if (s.hand[side] > 0) return 'place'; return (s.flying && morris.count(s, side) === 3) ? 'fly' : 'move'; },
    moves: function (s) {
      var side = s.turn, opp = 1 - side, out = [], ph = morris.phase(s, side), c = s.cells, i, j, t;
      function add(from, to) {
        c[to] = side; if (from >= 0) c[from] = -1;
        if (morris.inMill(c, to)) { var rm = morris.removable(c, opp); for (var k = 0; k < rm.length; k++) out.push({ from: from, to: to, take: rm[k] }); if (!rm.length) out.push({ from: from, to: to, take: -1 }); }
        else out.push({ from: from, to: to, take: -1 });
        c[to] = -1; if (from >= 0) c[from] = side;
      }
      if (ph === 'place') { for (i = 0; i < 24; i++) if (c[i] < 0) add(-1, i); }
      else for (i = 0; i < 24; i++) {
        if (c[i] !== side) continue;
        if (ph === 'fly') { for (j = 0; j < 24; j++) if (c[j] < 0) add(i, j); }
        else for (t = 0; t < MADJ[i].length; t++) { j = MADJ[i][t]; if (c[j] < 0) add(i, j); }
      }
      return out;
    },
    apply: function (s, m) {
      var n = morris.clone(s), side = s.turn;
      if (m.from < 0) n.hand[side]--; else n.cells[m.from] = -1;
      n.cells[m.to] = side; if (m.take >= 0) { n.cells[m.take] = -1; n.quiet = 0; } else n.quiet++;
      n.turn = 1 - side; n.ply++; return n;
    },
    /** null while the game runs; {winner: 0|1|-1, reason} when it is over (checked for the side to move). */
    result: function (s) {
      var side = s.turn, opp = 1 - side;
      if (s.hand[side] === 0 && morris.count(s, side) < 3) return { winner: opp, reason: 'two men left' };
      if (s.hand[opp] === 0 && morris.count(s, opp) < 3) return { winner: side, reason: 'two men left' };
      if (morris.moves(s).length === 0) return { winner: opp, reason: 'no move' };
      if (s.quiet >= 60 && s.hand[0] === 0 && s.hand[1] === 0) return { winner: -1, reason: 'thirty moves without a mill' };
      if (s.ply >= 300) return { winner: -1, reason: 'the candle burned down' };
      return null;
    },
    evaluate: function (s, side) {
      var opp = 1 - side, c = s.cells, v = 0, k, m, a, b;
      v += 120 * ((morris.count(s, side) + s.hand[side]) - (morris.count(s, opp) + s.hand[opp]));
      for (k = 0; k < MMILLS.length; k++) { m = MMILLS[k]; a = 0; b = 0; var e = 0; for (var q = 0; q < 3; q++) { if (c[m[q]] === side) a++; else if (c[m[q]] === opp) b++; else e++; } if (a === 2 && e === 1) v += 14; if (b === 2 && e === 1) v -= 16; if (a === 3) v += 6; if (b === 3) v -= 6; }
      var mob = [0, 0]; for (var i = 0; i < 24; i++) { if (c[i] < 0) continue; for (var t = 0; t < MADJ[i].length; t++) if (c[MADJ[i][t]] < 0) mob[c[i]]++; }
      if (s.hand[side] === 0) v += 3 * mob[side]; if (s.hand[opp] === 0) v -= 3 * mob[opp];
      if (s.hand[opp] === 0 && mob[opp] === 0 && morris.count(s, opp) > 3) v += 400;
      return v;
    },
    orderKey: function (m) { return m.take >= 0 ? 0 : 1; },
    same: function (a, b) { return a.from === b.from && a.to === b.to && a.take === b.take; },
  };

  //============================================================================ Fox and Geese
  // 33 points of the cross board on a 7 x 7 lattice; lines are orthogonal. Side 0 = the fox, side 1 = the geese.
  var FXY = [], FIDX = {};
  (function () { for (var y = 0; y < 7; y++) for (var x = 0; x < 7; x++) { if ((x < 2 || x > 4) && (y < 2 || y > 4)) continue; FIDX[x + ',' + y] = FXY.length; FXY.push([x, y]); } }());
  function fAt(x, y) { var k = FIDX[x + ',' + y]; return k === undefined ? -1 : k; }
  var FDIRS = [[1, 0], [-1, 0], [0, 1], [0, -1]];
  var FEDGES = []; (function () { for (var i = 0; i < FXY.length; i++) { var a = FXY[i], r = fAt(a[0] + 1, a[1]), d = fAt(a[0], a[1] + 1); if (r >= 0) FEDGES.push([i, r]); if (d >= 0) FEDGES.push([i, d]); } }());
  var GEESE_START = []; (function () { for (var i = 0; i < FXY.length; i++) if (FXY[i][1] <= 2) GEESE_START.push(i); }());   // rows 0-2: 6 + 7 = 13
  var FOX_START = fAt(3, 5);

  var foxgeese = {
    id: 'foxgeese', name: 'Fox and Geese', sides: ['fox', 'geese'], points: FXY.length, xy: FXY, edges: FEDGES, at: fAt,
    /** geese needed to trap the fox: below this many, the fox has won. Set from Internal_Ops/_probe/balance_probe.js. */
    FLOCK_MIN: 9,
    init: function () { var c = []; for (var i = 0; i < FXY.length; i++) c.push(-1); GEESE_START.forEach(function (p) { c[p] = 1; }); c[FOX_START] = 0; return { g: 'foxgeese', cells: c, turn: 1, ply: 0, taken: 0 }; },
    clone: function (s) { return { g: 'foxgeese', cells: s.cells.slice(), turn: s.turn, ply: s.ply, taken: s.taken }; },
    fox: function (s) { for (var i = 0; i < s.cells.length; i++) if (s.cells[i] === 0) return i; return -1; },
    geese: function (s) { var n = 0; for (var i = 0; i < s.cells.length; i++) if (s.cells[i] === 1) n++; return n; },
    /** The fox's jump chains from `p` (each a full path + the geese taken), depth-first; a chain may stop after any jump. */
    jumps: function (c, p, path, caps, out) {
      var a = FXY[p];
      for (var d = 0; d < 4; d++) {
        var mid = fAt(a[0] + FDIRS[d][0], a[1] + FDIRS[d][1]), to = fAt(a[0] + 2 * FDIRS[d][0], a[1] + 2 * FDIRS[d][1]);
        if (mid < 0 || to < 0 || c[mid] !== 1 || c[to] >= 0) continue;
        c[mid] = -1; c[p] = -1; c[to] = 0;
        var np = path.concat([to]), nc = caps.concat([mid]);
        out.push({ path: np, take: nc });
        foxgeese.jumps(c, to, np, nc, out);
        c[to] = -1; c[p] = 0; c[mid] = 1;
      }
    },
    moves: function (s) {
      var c = s.cells, out = [], i, d, a, t;
      if (s.turn === 0) {
        var f = foxgeese.fox(s); a = FXY[f];
        foxgeese.jumps(c, f, [f], [], out);
        for (d = 0; d < 4; d++) { t = fAt(a[0] + FDIRS[d][0], a[1] + FDIRS[d][1]); if (t >= 0 && c[t] < 0) out.push({ path: [f, t], take: [] }); }
      } else {
        for (i = 0; i < c.length; i++) {
          if (c[i] !== 1) continue; a = FXY[i];
          for (d = 0; d < 4; d++) { if (FDIRS[d][1] < 0) continue;   // geese never step back toward their own side
            t = fAt(a[0] + FDIRS[d][0], a[1] + FDIRS[d][1]); if (t >= 0 && c[t] < 0) out.push({ path: [i, t], take: [] }); }
        }
      }
      return out;
    },
    apply: function (s, m) {
      var n = foxgeese.clone(s), from = m.path[0], to = m.path[m.path.length - 1], who = n.cells[from];
      n.cells[from] = -1; n.cells[to] = who; for (var k = 0; k < m.take.length; k++) n.cells[m.take[k]] = -1;
      n.taken += m.take.length; n.turn = 1 - s.turn; n.ply++; return n;
    },
    result: function (s) {
      if (foxgeese.geese(s) < foxgeese.FLOCK_MIN) return { winner: 0, reason: 'too few geese to trap the fox' };
      if (foxgeese.moves(s).length === 0) return s.turn === 0 ? { winner: 1, reason: 'the fox is trapped' } : { winner: 0, reason: 'the geese cannot move' };
      // The geese must CLOSE the trap: sideways steps could shuffle forever, so after 80 moves each the fox has won.
      // (balance_probe 2026-09-28: as a draw this cap swallowed 11 of 12 Regular games and 7 of 12 Hustler games)
      if (s.ply >= 160) return { winner: 0, reason: 'the geese never closed the trap' };
      return null;
    },
    evaluate: function (s, side) {
      var c = s.cells, f = foxgeese.fox(s), a = FXY[f], g = foxgeese.geese(s), mob = 0, jumpy = 0, d, t, adv = 0;
      for (d = 0; d < 4; d++) { t = fAt(a[0] + FDIRS[d][0], a[1] + FDIRS[d][1]); if (t >= 0 && c[t] < 0) mob++;
        var t2 = fAt(a[0] + 2 * FDIRS[d][0], a[1] + 2 * FDIRS[d][1]); if (t >= 0 && t2 >= 0 && c[t] === 1 && c[t2] < 0) jumpy++; }
      // geese want to be many, low on the board (advanced) and packed (no holes behind them); the fox wants room and jumps
      for (var i = 0; i < c.length; i++) if (c[i] === 1) { adv += FXY[i][1]; var bx = FXY[i][0], by = FXY[i][1] - 1, back = fAt(bx, by); if (back >= 0 && c[back] === 1) adv += 1; }
      // the room the fox has: points it can reach over empty ground. Geese win by squeezing this, not by marching
      // (balance_probe 2026-09-28: with advancement alone a shallow flock lost to any fox, so strength did not show).
      var seen = foxgeese._seen || (foxgeese._seen = []), stack = foxgeese._stack || (foxgeese._stack = []), room = 0, q, k;
      for (k = 0; k < c.length; k++) seen[k] = 0; stack.length = 0; stack.push(f); seen[f] = 1;
      while (stack.length) { q = stack.pop(); room++; var qa = FXY[q]; for (d = 0; d < 4; d++) { t = fAt(qa[0] + FDIRS[d][0], qa[1] + FDIRS[d][1]); if (t >= 0 && !seen[t] && c[t] < 0) { seen[t] = 1; stack.push(t); } } }
      var foxScore = 260 * (13 - g) + 22 * mob + 70 * jumpy - 5 * adv + 8 * a[1] + 9 * room;
      return side === 0 ? foxScore : -foxScore;
    },
    orderKey: function (m) { return -m.take.length; },
    same: function (a, b) { return a.path.join(',') === b.path.join(','); },
  };

  //============================================================================ Oware (abapa)
  // Pits 0..5 belong to side 0 (sown left to right along the near row), 6..11 to side 1; sowing runs 0 -> 11 -> 0.
  var oware = {
    id: 'oware', name: 'Oware', sides: ['south', 'north'], pits: 12,
    init: function () { var p = []; for (var i = 0; i < 12; i++) p.push(4); return { g: 'oware', pits: p, store: [0, 0], turn: 0, ply: 0, quiet: 0 }; },
    clone: function (s) { return { g: 'oware', pits: s.pits.slice(), store: s.store.slice(), turn: s.turn, ply: s.ply, quiet: s.quiet }; },
    own: function (side, i) { return side === 0 ? (i < 6) : (i >= 6); },
    seedsOn: function (pits, side) { var n = 0, b = side * 6; for (var i = b; i < b + 6; i++) n += pits[i]; return n; },
    /** Sow pit `from` for `side` into a copy: {pits, taken, last, path}. Skips the emptied pit on laps of 12+. Grand slam takes nothing. */
    sow: function (pits, side, from) {
      var p = pits.slice(), n = p[from], i = from, path = [];
      p[from] = 0;
      while (n > 0) { i = (i + 1) % 12; if (i === from) continue; p[i]++; n--; path.push(i); }
      var take = 0, j = i, before = p.slice(), caps = [];
      while (!oware.own(side, j) && (p[j] === 2 || p[j] === 3)) { take += p[j]; caps.push(j); p[j] = 0; j = (j + 11) % 12; }
      if (take > 0 && oware.seedsOn(p, 1 - side) === 0) { p = before; take = 0; caps = []; }   // grand slam: legal, takes nothing
      return { pits: p, taken: take, last: i, path: path, caps: caps };
    },
    moves: function (s) {
      var side = s.turn, b = side * 6, out = [], starve = oware.seedsOn(s.pits, 1 - side) === 0;
      for (var i = b; i < b + 6; i++) {
        if (!s.pits[i]) continue;
        if (starve) { var r = oware.sow(s.pits, side, i); if (oware.seedsOn(r.pits, 1 - side) === 0) continue; }   // must feed a starving opponent
        out.push({ pit: i });
      }
      return out;
    },
    apply: function (s, m) {
      var n = oware.clone(s), r = oware.sow(s.pits, s.turn, m.pit);
      n.pits = r.pits; n.store[s.turn] += r.taken; n.quiet = r.taken ? 0 : n.quiet + 1; n.turn = 1 - s.turn; n.ply++;
      return n;
    },
    /** When the game cannot go on, each side keeps the seeds on its own row (the usual ending). */
    finalStores: function (s) { return [s.store[0] + oware.seedsOn(s.pits, 0), s.store[1] + oware.seedsOn(s.pits, 1)]; },
    result: function (s) {
      if (s.store[0] > 24) return { winner: 0, reason: 'more than half the seeds' };
      if (s.store[1] > 24) return { winner: 1, reason: 'more than half the seeds' };
      if (s.store[0] === 24 && s.store[1] === 24) return { winner: -1, reason: 'twenty-four each' };
      var ended = oware.moves(s).length === 0 ? 'no move can feed the other row' : (s.quiet >= 80 ? 'the seeds went round and round' : null);
      if (!ended) return null;
      var f = oware.finalStores(s); return { winner: f[0] > f[1] ? 0 : f[1] > f[0] ? 1 : -1, reason: ended, stores: f };
    },
    evaluate: function (s, side) {
      var opp = 1 - side, v = 100 * (s.store[side] - s.store[opp]), p = s.pits, b = side * 6, o = opp * 6, i;
      for (i = o; i < o + 6; i++) if (p[i] === 1 || p[i] === 2) v += 12;     // enemy pits we could take next
      for (i = b; i < b + 6; i++) if (p[i] === 1 || p[i] === 2) v -= 14;     // ours they could take
      for (i = b; i < b + 6; i++) if (p[i] >= 12) v += 18;                    // a kroo (a lap-sowing store) in hand
      v += 2 * (oware.seedsOn(p, side) - oware.seedsOn(p, opp));
      return v;
    },
    orderKey: function (m) { return 0; },
    same: function (a, b) { return a.pit === b.pit; },
  };

  //============================================================================ Fanorona
  // 5 rows x 9 columns; every point joins its orthogonal neighbours, and the "strong" points (x+y even) their diagonals.
  // Side 0 (white) starts on rows 3-4, side 1 (black) on rows 0-1; the middle row alternates with its centre empty.
  var ZXY = [];
  (function () { for (var y = 0; y < 5; y++) for (var x = 0; x < 9; x++) ZXY.push([x, y]); }());
  function zAt(x, y) { return (x < 0 || y < 0 || x > 8 || y > 4) ? -1 : y * 9 + x; }
  var ZDIRS = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1], [1, -1], [-1, 1]];
  function zDirOk(p, d) { return d < 4 || ((ZXY[p][0] + ZXY[p][1]) % 2 === 0); }
  var ZEDGES = []; (function () { for (var p = 0; p < 45; p++) for (var d = 0; d < 8; d += 2) { if (!zDirOk(p, d)) continue; var q = zAt(ZXY[p][0] + ZDIRS[d][0], ZXY[p][1] + ZDIRS[d][1]); if (q >= 0) ZEDGES.push([p, q]); } }());
  var ZMID = [1, 0, 1, 0, -1, 1, 0, 1, 0];

  var fanorona = {
    id: 'fanorona', name: 'Fanorona', sides: ['white', 'black'], points: 45, xy: ZXY, edges: ZEDGES, at: zAt,
    init: function () { var c = []; for (var p = 0; p < 45; p++) { var y = ZXY[p][1]; c.push(y < 2 ? 1 : y > 2 ? 0 : ZMID[ZXY[p][0]]); } return { g: 'fanorona', cells: c, turn: 0, ply: 0, quiet: 0 }; },
    clone: function (s) { return { g: 'fanorona', cells: s.cells.slice(), turn: s.turn, ply: s.ply, quiet: s.quiet }; },
    count: function (s, side) { var n = 0; for (var i = 0; i < 45; i++) if (s.cells[i] === side) n++; return n; },
    /** The enemy line taken by a step p -> q in direction d, by approach ('a') or withdrawal ('w'). */
    line: function (c, p, q, d, kind, side) {
      var dx = ZDIRS[d][0], dy = ZDIRS[d][1], x, y, out = [], opp = 1 - side;
      if (kind === 'a') { x = ZXY[q][0] + dx; y = ZXY[q][1] + dy; } else { x = ZXY[p][0] - dx; y = ZXY[p][1] - dy; dx = -dx; dy = -dy; }
      for (var k = zAt(x, y); k >= 0 && c[k] === opp; k = zAt(x, y)) { out.push(k); x += dx; y += dy; }
      return out;
    },
    /** Capturing steps from p (single steps, one entry per approach/withdrawal choice), honouring a chain's constraints. */
    captureSteps: function (c, p, side, lastDir, visited) {
      var out = [];
      for (var d = 0; d < 8; d++) {
        if (!zDirOk(p, d) || d === lastDir) continue;
        var q = zAt(ZXY[p][0] + ZDIRS[d][0], ZXY[p][1] + ZDIRS[d][1]); if (q < 0 || c[q] >= 0 || (visited && visited.indexOf(q) >= 0)) continue;
        var ap = fanorona.line(c, p, q, d, 'a', side), wd = fanorona.line(c, p, q, d, 'w', side);
        if (ap.length) out.push({ to: q, dir: d, kind: 'a', take: ap });
        if (wd.length) out.push({ to: q, dir: d, kind: 'w', take: wd });
      }
      return out;
    },
    chains: function (c, p, side, lastDir, visited, steps, out, first) {
      var st = fanorona.captureSteps(c, p, side, lastDir, visited);
      for (var k = 0; k < st.length; k++) {
        var s = st[k];
        c[p] = -1; c[s.to] = side; for (var t = 0; t < s.take.length; t++) c[s.take[t]] = -1;
        var ns = steps.concat([s]); out.push({ from: steps.length ? steps[0].from : p, steps: ns });
        ns[ns.length - 1].from = p;
        if (!first) fanorona.chains(c, s.to, side, s.dir, visited.concat([p]), ns, out, false);
        for (t = 0; t < s.take.length; t++) c[s.take[t]] = 1 - side; c[s.to] = -1; c[p] = side;
      }
    },
    moves: function (s) {
      var c = s.cells, side = s.turn, out = [], p, d;
      for (p = 0; p < 45; p++) if (c[p] === side) fanorona.chains(c, p, side, -1, [], [], out, s.ply === 0);   // the opening move takes once
      if (out.length) return out;   // taking is compulsory
      for (p = 0; p < 45; p++) {
        if (c[p] !== side) continue;
        for (d = 0; d < 8; d++) { if (!zDirOk(p, d)) continue; var q = zAt(ZXY[p][0] + ZDIRS[d][0], ZXY[p][1] + ZDIRS[d][1]); if (q >= 0 && c[q] < 0) out.push({ from: p, steps: [{ from: p, to: q, dir: d, kind: 'p', take: [] }] }); }
      }
      return out;
    },
    apply: function (s, m) {
      var n = fanorona.clone(s), c = n.cells, side = s.turn, took = 0;
      for (var k = 0; k < m.steps.length; k++) { var st = m.steps[k]; c[st.from] = -1; c[st.to] = side; for (var t = 0; t < st.take.length; t++) { c[st.take[t]] = -1; took++; } }
      n.quiet = took ? 0 : n.quiet + 1; n.turn = 1 - side; n.ply++; return n;
    },
    taken: function (m) { var n = 0; for (var k = 0; k < m.steps.length; k++) n += m.steps[k].take.length; return n; },
    /** Whether the side to move has any move: a man with an empty point along one of its lines (a capture needs one too). */
    hasMove: function (s) {
      var c = s.cells, side = s.turn;
      for (var p = 0; p < 45; p++) { if (c[p] !== side) continue; for (var d = 0; d < 8; d++) { if (!zDirOk(p, d)) continue; var q = zAt(ZXY[p][0] + ZDIRS[d][0], ZXY[p][1] + ZDIRS[d][1]); if (q >= 0 && c[q] < 0) return true; } }
      return false;
    },
    result: function (s) {
      var side = s.turn, opp = 1 - side;
      if (fanorona.count(s, side) === 0) return { winner: opp, reason: 'every man taken' };
      if (fanorona.count(s, opp) === 0) return { winner: side, reason: 'every man taken' };
      // (mz_gate 2026-09-28: generating every capture chain just to ask "is there a move?" cost whole milliseconds a node)
      if (!fanorona.hasMove(s)) return { winner: opp, reason: 'no move' };
      if (s.quiet >= 50) return { winner: -1, reason: 'twenty-five moves without a capture' };
      if (s.ply >= 240) return { winner: -1, reason: 'the candle burned down' };
      return null;
    },
    evaluate: function (s, side) {
      var opp = 1 - side, c = s.cells, v = 100 * (fanorona.count(s, side) - fanorona.count(s, opp)), p, k, st, best = [0, 0];
      for (p = 0; p < 45; p++) if (c[p] >= 0 && (ZXY[p][0] + ZXY[p][1]) % 2 === 0) v += c[p] === side ? 3 : -3;   // strong points
      // the next capture: almost every Fanorona position has one, so a plain material count sits on a cliff (the horizon).
      // The side to move takes first, so its best single step counts more than the answer it leaves.
      for (p = 0; p < 45; p++) { if (c[p] < 0) continue; st = fanorona.captureSteps(c, p, c[p], -1, null); for (k = 0; k < st.length; k++) if (st[k].take.length > best[c[p]]) best[c[p]] = st[k].take.length; }
      if (s.turn === side) v += 70 * best[side] - 35 * best[opp]; else v += 35 * best[side] - 70 * best[opp];
      return v;
    },
    orderKey: function (m) { return -fanorona.taken(m); },
    same: function (a, b) { if (a.steps.length !== b.steps.length) return false; for (var k = 0; k < a.steps.length; k++) { var x = a.steps[k], y = b.steps[k]; if (x.from !== y.from || x.to !== y.to || x.kind !== y.kind) return false; } return true; },
  };

  var GAMES = { morris: morris, foxgeese: foxgeese, oware: oware, fanorona: fanorona };
  var GAME_IDS = ['morris', 'foxgeese', 'oware', 'fanorona'];

  //============================================================================ the opponent
  // grade 1..5: how far it looks (plies, per game) and how much it misjudges (centipawn-style noise on the root moves).
  // Set from Internal_Ops/_probe/balance_probe.js (each grade must beat the one below it), never guessed.
  var GRADES = {
    names: ['', 'Novice', 'Regular', 'Sharp', 'Hustler', 'Master'],
    // Fox and Geese: 5 and 6 plies cost 200-450 ms a move once the flock's room is scored; 4 and 5 separate every grade
    // (measured 2026-09-28: 13-11, 17-7, 20-4, 17-7 in 24 games, g vs g-1)
    depth: { morris: [0, 1, 2, 3, 4, 5], foxgeese: [0, 1, 2, 3, 4, 5], oware: [0, 1, 2, 4, 6, 8], fanorona: [0, 1, 2, 2, 3, 3] },
    noise: [0, 260, 120, 40, 12, 0],
    // Fanorona: a 4-ply Master LOST to a 3-ply Hustler (7 wins, 15 losses in 24; an odd/even horizon), so there the two
    // look equally far and the Hustler misjudges more. Measured 2026-09-28: 23-0, 15-1, 12-2, 11-3 (grade g vs g-1).
    noiseFor: { fanorona: [0, 260, 120, 40, 40, 0] },
  };

  function ordered(G, list) {
    // stable sort on a key computed from the move alone (no RNG in the comparator: wing CLAUDE.md §3)
    var keyed = list.map(function (m, i) { return { m: m, k: G.orderKey(m), i: i }; });
    keyed.sort(function (a, b) { return a.k - b.k || a.i - b.i; });
    return keyed.map(function (e) { return e.m; });
  }

  /**
   * A search that can be run a slice at a time. `step(nodes)` expands at most that many nodes and returns true when the
   * move is chosen (`.move`, `.score`, `.nodes`). The node sequence does not depend on how it is sliced, so the move is
   * the same whether it runs in one call or a thousand.
   */
  function Thinker(gameId, state, grade, seed) {
    var G = GAMES[gameId]; this.G = G; this.root = state; this.side = state.turn;
    grade = Math.max(1, Math.min(5, Math.floor(Number(grade) || 3))); this.grade = grade;
    this.depth = GRADES.depth[gameId][grade]; this.nodes = 0; this.done = false; this.move = null; this.score = 0;
    var r = rng((seed >>> 0) ^ Math.imul(state.ply + 1, 0x9E3779B1)), rootMoves = ordered(G, G.moves(state));
    var nz = (GRADES.noiseFor && GRADES.noiseFor[gameId]) ? GRADES.noiseFor[gameId][grade] : GRADES.noise[grade];
    this.noise = []; for (var i = 0; i < rootMoves.length; i++) this.noise.push(Math.round((r() * 2 - 1) * nz));
    this.rootMoves = rootMoves; this.ri = 0; this.best = -Infinity; this.bestI = 0; this.stack = null;
    if (rootMoves.length <= 1) { this.done = true; this.move = rootMoves[0] || null; }
  }
  Thinker.prototype.leaf = function (st, ply) {
    var res = this.G.result(st);
    if (res) return res.winner < 0 ? 0 : (res.winner === st.turn ? WIN - ply : -(WIN - ply));
    return this.G.evaluate(st, st.turn);
  };
  Thinker.prototype.push = function (st, depth, alpha, beta, ply) {
    if (depth <= 0 || this.G.result(st)) return { leaf: this.leaf(st, ply) };
    this.stack.push({ st: st, ms: ordered(this.G, this.G.moves(st)), i: 0, depth: depth, alpha: alpha, beta: beta, best: -Infinity, ply: ply });
    return null;
  };
  Thinker.prototype.step = function (budget) {
    if (this.done) return true;
    var n = 0;
    while (n < budget) {
      if (!this.stack) {
        if (this.ri >= this.rootMoves.length) { this.move = this.rootMoves[this.bestI]; this.score = this.best; this.done = true; return true; }
        this.stack = []; this.nodes++; n++;
        var child = this.G.apply(this.root, this.rootMoves[this.ri]);
        // alpha-beta at the root: a window from the best found so far (minus the largest noise, so noise can still reorder)
        var lead = this.push(child, this.depth - 1, -Infinity, Infinity, 1);
        if (lead) { this.finishRoot(-lead.leaf); }
        continue;
      }
      var top = this.stack[this.stack.length - 1];
      if (top.i >= top.ms.length || top.alpha >= top.beta) {
        var v = top.best === -Infinity ? top.alpha : top.best; this.stack.pop();
        if (!this.stack.length) { this.finishRoot(-v); continue; }
        this.absorb(this.stack[this.stack.length - 1], -v); continue;
      }
      var m = top.ms[top.i++], ch = this.G.apply(top.st, m); this.nodes++; n++;
      var r = this.push(ch, top.depth - 1, -top.beta, -top.alpha, top.ply + 1);
      if (r) this.absorb(top, -r.leaf);
    }
    return false;
  };
  Thinker.prototype.absorb = function (f, v) { if (v > f.best) f.best = v; if (v > f.alpha) f.alpha = v; };
  Thinker.prototype.finishRoot = function (v) {
    var sc = v + this.noise[this.ri];
    if (sc > this.best) { this.best = sc; this.bestI = this.ri; }
    this.ri++; this.stack = null;
  };
  /** Run a search to the end in one call. */
  function bestMove(gameId, state, grade, seed) { var t = new Thinker(gameId, state, grade, seed); t.step(Infinity); return t; }

  /**
   * A move as the clicks that make it: 'p<point>' a point (or pit), 't<point>' the man taken after a mill, 'x<point>'
   * the first man of the line a Fanorona step takes (approach and withdrawal take different lines).
   */
  function tokens(gameId, m) {
    var t = [], k;
    if (gameId === 'morris') { if (m.from >= 0) t.push('p' + m.from); t.push('p' + m.to); if (m.take >= 0) t.push('t' + m.take); return t; }
    if (gameId === 'foxgeese') { for (k = 0; k < m.path.length; k++) t.push('p' + m.path[k]); return t; }
    if (gameId === 'oware') return ['p' + m.pit];
    t.push('p' + m.from); for (k = 0; k < m.steps.length; k++) { t.push('p' + m.steps[k].to); if (m.steps[k].kind !== 'p') t.push('x' + m.steps[k].take[0]); }
    return t;
  }
  /**
   * What the player may click next, given the clicks so far: {next: [distinct tokens], complete: the legal move those
   * clicks already make (or null), matches: how many legal moves are still possible}.
   */
  function options(gameId, legal, prefix) {
    var next = [], complete = null, matches = 0;
    for (var i = 0; i < legal.length; i++) {
      var tk = tokens(gameId, legal[i]), ok = tk.length >= prefix.length;
      for (var k = 0; ok && k < prefix.length; k++) if (tk[k] !== prefix[k]) ok = false;
      if (!ok) continue; matches++;
      if (tk.length === prefix.length) complete = legal[i]; else if (next.indexOf(tk[prefix.length]) < 0) next.push(tk[prefix.length]);
    }
    return { next: next, complete: complete, matches: matches };
  }

  /** A match: the game, whose turn, the history. `human` is the side the player plays. */
  function newMatch(gameId, opts) {
    var G = GAMES[gameId]; opts = opts || {};
    return { game: gameId, state: G.init(opts), human: opts.human === 1 ? 1 : 0, history: [], over: null };
  }
  function play(match, move) {
    // a malformed move is REFUSED, never thrown on (docs_break 2026-09-28: `same()` read fields a garbage move lacks)
    if (!move || typeof move !== 'object' || match.over) return false;
    var G = GAMES[match.game], legal = G.moves(match.state), ok = null, want;
    try { want = tokens(match.game, move).join(' '); } catch (e) { return false; }
    for (var i = 0; i < legal.length; i++) if (tokens(match.game, legal[i]).join(' ') === want) { ok = legal[i]; break; }
    if (!ok) return false;
    match.history.push(ok); match.state = G.apply(match.state, ok); match.over = G.result(match.state); return true;
  }
  /** Margin in the game's own unit (men, geese, seeds) from `side`'s point of view. */
  function margin(match, side) {
    var s = match.state, G = GAMES[match.game];
    if (match.game === 'morris') return (G.count(s, side) + s.hand[side]) - (G.count(s, 1 - side) + s.hand[1 - side]);
    if (match.game === 'fanorona') return G.count(s, side) - G.count(s, 1 - side);
    if (match.game === 'oware') { var f = (match.over && match.over.stores) || s.store; return f[side] - f[1 - side]; }
    return side === 0 ? s.taken : G.geese(s);   // fox: geese taken; geese: geese left
  }

  return {
    VERSION: '1.0.0', GAMES: GAMES, GAME_IDS: GAME_IDS, GRADES: GRADES, WIN: WIN, hashString: hashString, rng: rng,
    Thinker: Thinker, bestMove: bestMove, newMatch: newMatch, play: play, margin: margin, tokens: tokens, options: options,
  };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = TaproomCore;
