//=============================================================================
// Rebuttal.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Class-trial debates: statements fly as kinetic type; shoot the weak point with the right evidence. Load after RebuttalCore and RebuttalDraw.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 * @base RebuttalCore
 * @orderAfter RebuttalDraw
 *
 * @param wonSwitch
 * @text Won -> switch
 * @type switch
 * @desc ON when the player breaks the right weak point, OFF when the debate is lost. 0 = none.
 * @default 0
 *
 * @param shotsVariable
 * @text Shots -> variable
 * @type variable
 * @desc How many shots the player fired. 0 = none.
 * @default 0
 *
 * @param seed
 * @text Seed
 * @desc Changes how every statement moves. The same seed always moves them the same way.
 * @default rebuttal
 *
 * @command start
 * @text Start a Debate
 * @desc Runs the debate written in a common event's Comment lines. The event waits until it ends.
 *
 * @arg commonEvent
 * @text Debate (common event)
 * @type common_event
 * @desc The common event whose Comment lines hold the statements (Rebuttal: Speaker | text with {weak point} | bullet).
 * @default 1
 *
 * @arg influence
 * @text Influence
 * @type number
 * @min 1
 * @max 9
 * @desc Wrong shots allowed before the debate is lost.
 * @default 3
 *
 * @arg seconds
 * @text Time limit (seconds)
 * @type number
 * @min 10
 * @max 600
 * @default 90
 *
 * @help
 * Write a debate as Comment lines in a common event, one statement per line:
 *
 *   Rebuttal: Kasey | The door was {locked from the inside} all night. | receipt
 *   Rebuttal: Eliot | Nobody reached the {east stair} unseen! | stair-map
 *   Rebuttal: Kasey | It was suicide, plain and simple.
 *
 * Curly brackets mark the weak point; the last field names the bullet that
 * breaks it. Bullets are the items your party holds that carry the notetag
 * <Rebuttal Bullet: receipt>. With none held, the debate's own answers are
 * offered, so a debate can be tested before its items exist.
 *
 * In the debate: aim with the mouse, a finger or the arrow keys; Page Up and
 * Page Down (or the wheel) choose the bullet; OK or a click fires. A wrong
 * bullet on a weak point costs influence. The result goes to the Won switch.
 */

(function () {
  'use strict';

  var PLUGIN = 'Rebuttal';
  var P = PluginManager.parameters(PLUGIN);
  var num = function (v, d) { var n = Number(v); return v === '' || v === undefined || v === null || !isFinite(n) ? d : n; };
  var CFG = { wonSwitch: num(P.wonSwitch, 0), shotsVariable: num(P.shotsVariable, 0), seed: String(P.seed === undefined || P.seed === '' ? 'rebuttal' : P.seed) };
  var PX = 28, MAX_GLYPHS = 180;

  /** Resolved at FIRST USE, never at load time: plugin order is the buyer's (wing §8 trap 2). */
  function deps() {
    var C = window.CSAF || {};
    if (!C.RebuttalCore || !C.RebuttalArt) throw new Error('[Rebuttal] RebuttalCore.js and RebuttalDraw.js must be installed (any order).');
    return { core: C.RebuttalCore, art: C.RebuttalArt };
  }

  /** The Comment lines (codes 108 and 408) of a common event, in order. */
  function commentLines(id) {
    var ce = $dataCommonEvents[Number(id)], out = [];
    if (!ce || !ce.list) return out;
    for (var i = 0; i < ce.list.length; i++) { var c = ce.list[i]; if ((c.code === 108 || c.code === 408) && c.parameters) out.push(String(c.parameters[0])); }
    return out;
  }

  /** Bullets: held items tagged <Rebuttal Bullet: key>, else the debate's own answers. */
  function bulletsFor(debate) {
    var held = [], items = $gameParty ? $gameParty.items() : [];
    for (var i = 0; i < items.length; i++) { var m = /<Rebuttal\s+Bullet\s*:\s*([^>]+)>/i.exec(items[i].note || ''); if (m) held.push({ key: m[1].trim(), name: items[i].name }); }
    if (held.length) return held;
    var seen = {};
    for (var k = 0; k < debate.statements.length; k++) { var a = debate.statements[k].answer; if (a && !seen[a]) { seen[a] = 1; held.push({ key: a, name: a }); } }
    return held;
  }

  window.CSAF_Rebuttal = { lastResult: null, start: function (args) { SceneManager.push(Scene_Rebuttal); Scene_Rebuttal._args = args; } };

  PluginManager.registerCommand(PLUGIN, 'start', function (args) {
    window.CSAF_Rebuttal.start({ commonEvent: num(args.commonEvent, 1), influence: num(args.influence, 3), seconds: num(args.seconds, 90) });
    this.setWaitMode('rebuttal');
  });

  var _Game_Interpreter_updateWaitMode = Game_Interpreter.prototype.updateWaitMode;
  Game_Interpreter.prototype.updateWaitMode = function () {
    if (this._waitMode === 'rebuttal') {
      if (SceneManager._scene instanceof Scene_Rebuttal || SceneManager._nextScene instanceof Scene_Rebuttal) return true;
      this._waitMode = '';
      return false;
    }
    return _Game_Interpreter_updateWaitMode.call(this);
  };

  //===========================================================================
  // Scene_Rebuttal
  //===========================================================================

  function Scene_Rebuttal() { this.initialize.apply(this, arguments); }
  Scene_Rebuttal.prototype = Object.create(Scene_Base.prototype);
  Scene_Rebuttal.prototype.constructor = Scene_Rebuttal;

  Scene_Rebuttal.prototype.create = function () {
    Scene_Base.prototype.create.call(this);
    var d = deps(), C = d.core, args = Scene_Rebuttal._args || { commonEvent: 1, influence: 3, seconds: 90 };
    this._debate = C.parseDebate(commentLines(args.commonEvent));
    // A rejected line must never vanish silently (the first in-engine run dropped one and showed three statements of
    // four with no word why): name every one, with its comment line number, in the console.
    for (var e = 0; e < this._debate.errors.length; e++) {
      var er = this._debate.errors[e];
      console.warn('[Rebuttal] common event ' + args.commonEvent + ', comment line ' + er.line + ' skipped: ' + er.why);
    }
    window.CSAF_Rebuttal.lastErrors = this._debate.errors;
    var m = document.createElement('canvas').getContext('2d');
    m.font = 'italic 900 ' + PX + 'px ' + d.art.FACE;
    var cache = {};
    this._widths = function (ch) { return cache[ch] === undefined ? (cache[ch] = m.measureText(ch).width) : cache[ch]; };
    this._state = this._debate.statements.length ? C.newDebate(this._debate, { seed: CFG.seed, influence: args.influence, timeLimit: Math.round(args.seconds * 60), widths: this._widths }) : null;
    this._bullets = bulletsFor(this._debate);
    this._bullet = 0;
    this._maxInf = Math.max(1, Math.floor(args.influence) || 3);
    this._sx = Graphics.width / C.STAGE.w; this._sy = (Graphics.height - 120) / C.STAGE.h;
    this._sc = Math.min(this._sx, this._sy);
    this._ox = (Graphics.width - C.STAGE.w * this._sc) / 2; this._oy = 0;
    // the ground fills the whole screen first, so no letterbox band shows around the stage (LOOKED 2026-10-07)
    var gb = new Bitmap(Graphics.width, Graphics.height); d.art.drawGround(gb.context, gb.width, gb.height); gb._baseTexture.update();
    this.addChild(new Sprite(gb));
    this._stage = new Sprite(new Bitmap(C.STAGE.w, C.STAGE.h)); this._stage.x = this._ox; this._stage.y = this._oy; this._stage.scale.x = this._stage.scale.y = this._sc;
    this.addChild(this._stage);
    this._layer = new Sprite(); this._layer.x = this._ox; this._layer.y = this._oy; this._layer.scale.x = this._layer.scale.y = this._sc;
    this.addChild(this._layer);
    this._glyphs = [];
    for (var i = 0; i < MAX_GLYPHS; i++) { var sp = new Sprite(); sp.anchor.x = 0.5; sp.anchor.y = 0.5; sp.visible = false; this._layer.addChild(sp); this._glyphs.push(sp); }
    var ch = new Bitmap(64, 64); d.art.drawCrosshair(ch.context, 32, 32, 18); ch._baseTexture.update();
    this._cross = new Sprite(ch); this._cross.anchor.x = this._cross.anchor.y = 0.5; this.addChild(this._cross);
    this._cx = Graphics.width / 2; this._cy = Graphics.height * 0.4;
    var hudTop = Math.round(this._oy + C.STAGE.h * this._sc);
    this._hud = new Sprite(new Bitmap(Graphics.width, Math.max(96, Graphics.height - hudTop))); this._hud.y = Graphics.height - this._hud.bitmap.height; this.addChild(this._hud);
    this._shown = -1; this._end = 0; this._flash = 0; this._P = { x: 0, y: 0, scale: 1, alpha: 1, rot: 0 };
    // the cast around the ring: every speaker of the debate gets a named seat, in order of first line
    this._cast = [];
    for (var q = 0; q < this._debate.statements.length; q++) if (this._cast.indexOf(this._debate.statements[q].speaker) < 0) this._cast.push(this._debate.statements[q].speaker);
    this._seats = Math.max(6, this._cast.length);
    this._names = []; for (var n = 0; n < this._seats; n++) this._names.push(this._cast[n] || '');
    // the refute burst: per-glyph velocities, allocated ONCE here (wing §3: nothing allocated per frame)
    this._vx = new Float32Array(MAX_GLYPHS); this._vy = new Float32Array(MAX_GLYPHS); this._vr = new Float32Array(MAX_GLYPHS);
    this._stamp = new Sprite(new Bitmap(520, 150)); this._stamp.anchor.x = this._stamp.anchor.y = 0.5;
    this._stamp.x = Graphics.width / 2; this._stamp.y = this._oy + C.STAGE.h * this._sc * 0.5; this._stamp.visible = false;
    this.addChild(this._stamp);
    // the wrong-shot tag: drawn ONCE here, shown at the crosshair and faded per frame (feedback a wrong bullet lacked)
    this._wrong = new Sprite(new Bitmap(240, 48)); this._wrong.anchor.x = 0.5; this._wrong.anchor.y = 1; this._wrong.visible = false;
    var wb = this._wrong.bitmap.context;
    wb.font = 'italic 900 26px ' + d.art.FACE; wb.textAlign = 'center'; wb.textBaseline = 'middle'; wb.lineJoin = 'round';
    wb.strokeStyle = '#3a0006'; wb.lineWidth = 6; wb.strokeText('WRONG BULLET', 120, 24); wb.fillStyle = '#ff6a6a'; wb.fillText('WRONG BULLET', 120, 24);
    this._wrong.bitmap._baseTexture.update(); this._wrongT = 0;
    this.addChild(this._wrong);
    this.drawHud();
  };

  /** The moment a debate ends: the weak point's letters burst apart (on a win) and the verdict stamp slams in. */
  Scene_Rebuttal.prototype.onOutcome = function () {
    var d = deps(), s = this._state, c = s.list[s.cur], won = s.outcome === 'won';
    if (won) {
      var box = { x: 0, y: 0, w: 0, h: 0 }; d.core.currentWeakBox(s, box);
      var mx = box.x + box.w / 2, my = box.y + box.h / 2;
      for (var i = 0; i < c.text.length && i < MAX_GLYPHS; i++) {
        var sp = this._glyphs[i], k = d.core.hash('burst:' + i) / 4294967296, dx = sp.x - mx, dy = sp.y - my, len = Math.sqrt(dx * dx + dy * dy) || 1;
        var weak = c.weakIdx.indexOf(i) >= 0, speed = weak ? 7 + 6 * k : 0;
        this._vx[i] = dx / len * speed; this._vy[i] = dy / len * speed - (weak ? 4 : 0); this._vr[i] = weak ? (k - 0.5) * 0.5 : 0;
      }
    }
    d.art.drawStamp(this._stamp.bitmap.context, 520, 150, won ? 'REFUTED!' : s.outcome === 'timeout' ? 'TIME UP' : 'SILENCED', won);
    this._stamp.bitmap._baseTexture.update();
    this._stamp.visible = true; this._stamp.scale.x = this._stamp.scale.y = 2.2; this._stamp.opacity = 0;
    this._cross.visible = false;   // the aim is over: the crosshair sat on the verdict (LOOKED 2026-10-07)
  };

  /** One frame of the ending: letters fly, the rest dims, the stamp settles. No allocation. */
  Scene_Rebuttal.prototype.animateEnd = function () {
    var s = this._state, c = s.list[s.cur], won = s.outcome === 'won';
    for (var i = 0; i < c.text.length && i < this._glyphs.length; i++) {
      var sp = this._glyphs[i];
      if (won && this._vx[i] !== 0) { sp.x += this._vx[i]; sp.y += this._vy[i]; this._vy[i] += 0.35; sp.rotation += this._vr[i]; sp.opacity = Math.max(0, sp.opacity - 5); }
      else sp.opacity = Math.max(90, sp.opacity - 6);
    }
    var st = this._stamp;
    if (st.scale.x > 1) { st.scale.x = st.scale.y = Math.max(1, st.scale.x - 0.12); }
    st.opacity = Math.min(255, st.opacity + 40);
  };

  /** A per-statement glyph atlas: each character drawn once in its palette (weak ones gold), cells in one bitmap. */
  Scene_Rebuttal.prototype.buildStatement = function () {
    var d = deps(), c = this._state.list[this._state.cur], cell = Math.ceil(PX * 1.9), cols = 24;
    var rows = Math.ceil(c.text.length / cols) || 1, bmp = new Bitmap(cols * cell, rows * cell), ctx = bmp.context;
    var still = { x: 0, y: 0, scale: 1, alpha: 1, rot: 0 };
    for (var i = 0; i < c.text.length; i++) {
      still.x = (i % cols) * cell + cell / 2; still.y = Math.floor(i / cols) * cell + cell / 2;
      d.art.drawGlyph(ctx, c.text[i], still, PX, c.palette, c.weakIdx.indexOf(i) >= 0, 0.6);
    }
    bmp._baseTexture.update();
    if (this._atlas) this._atlas.destroy();
    this._atlas = bmp;
    for (var g = 0; g < this._glyphs.length; g++) {
      var sp = this._glyphs[g];
      if (g < c.text.length) { sp.bitmap = bmp; sp.setFrame((g % cols) * cell, Math.floor(g / cols) * cell, cell, cell); sp.visible = true; }
      else sp.visible = false;
    }
    var sb = this._stage.bitmap; sb.clear();
    d.art.drawStage(sb.context, sb.width, sb.height, { seats: this._seats, speaker: this._cast.indexOf(c.speaker), palette: c.palette, names: this._names });
    sb._baseTexture.update();
    this._shown = this._state.cur;
  };

  /** The HUD is drawn by RebuttalDraw (a cylinder, pips, a time bar); redrawn only when something on it changes. */
  Scene_Rebuttal.prototype.drawHud = function () {
    var b = this._hud.bitmap, s = this._state, names = [];
    for (var i = 0; i < this._bullets.length; i++) names.push(this._bullets[i].name);
    deps().art.drawHud(b.context, b.width, b.height, { bullets: names, current: this._bullet, influence: s ? s.influence : 0, maxInfluence: this._maxInf, timeFrac: s ? 1 - s.time / s.timeLimit : 0 });
    b._baseTexture.update();
  };

  Scene_Rebuttal.prototype.update = function () {
    Scene_Base.prototype.update.call(this);
    var C = deps().core, s = this._state;
    if (!s) { this.finish(false); return; }
    if (this._end > 0) { this.animateEnd(); if (--this._end === 0) this.finish(s.outcome === 'won'); return; }
    // aim: pointer if pressed or moved, else keys
    if (TouchInput.isPressed() || TouchInput.isMoved()) { this._cx = TouchInput.x; this._cy = TouchInput.y; }
    var v = 7;
    if (Input.isPressed('left')) this._cx -= v; if (Input.isPressed('right')) this._cx += v;
    if (Input.isPressed('up')) this._cy -= v; if (Input.isPressed('down')) this._cy += v;
    this._cx = Math.max(0, Math.min(Graphics.width, this._cx)); this._cy = Math.max(0, Math.min(Graphics.height, this._cy));
    this._cross.x = this._cx; this._cross.y = this._cy;
    if (this._bullets.length && (Input.isTriggered('pagedown') || TouchInput.wheelY > 0)) { this._bullet = (this._bullet + 1) % this._bullets.length; this.drawHud(); SoundManager.playCursor(); }
    if (this._bullets.length && (Input.isTriggered('pageup') || TouchInput.wheelY < 0)) { this._bullet = (this._bullet + this._bullets.length - 1) % this._bullets.length; this.drawHud(); SoundManager.playCursor(); }
    if ((Input.isTriggered('ok') || TouchInput.isTriggered()) && this._bullets.length) this.fire();
    C.step(s);
    if (s.cur !== this._shown) this.buildStatement();
    this.place();
    if (s.time % 60 === 0) this.drawHud();
    if (s.outcome) { this._end = 90; this.onOutcome(); this.drawHud(); }
  };

  /** Fire the chosen bullet at the crosshair (stage coordinates). */
  Scene_Rebuttal.prototype.fire = function () {
    var C = deps().core, s = this._state;
    var x = (this._cx - this._ox) / this._sc, y = (this._cy - this._oy) / this._sc;
    var r = C.fire(s, this._bullets[this._bullet].key, x, y);
    if (r.result === 'refuted') SoundManager.playOk();
    // the tag rises from the influence pips, where the cost lands (LOOKED 2026-10-07: at the crosshair it covered the
    // statement being read)
    else if (r.result === 'wrong') { SoundManager.playBuzzer(); this._flash = 12; this._wrongT = 40; this._wrong.x = Graphics.width - 150; this._wrong.y = this._hud.y - 2; this._wrong.visible = true; }
    else SoundManager.playCursor();
    this.drawHud();
    return r;
  };

  /** Every glyph of the current statement at its choreographed place. No allocation. */
  Scene_Rebuttal.prototype.place = function () {
    var C = deps().core, s = this._state, c = s.list[s.cur], p = this._P, cell = Math.ceil(PX * 1.9);
    for (var i = 0; i < c.text.length && i < this._glyphs.length; i++) {
      var sp = this._glyphs[i];
      C.glyphAt(c, i, s.t, p);
      sp.x = p.x; sp.y = p.y; sp.rotation = p.rot; sp.scale.x = sp.scale.y = p.scale; sp.opacity = Math.round(255 * Math.max(0, Math.min(1, p.alpha)));
    }
    if (this._flash > 0) { this._flash--; this._layer.x = this._ox + ((this._flash & 1) ? 4 : -4); } else this._layer.x = this._ox;
    if (this._wrongT > 0) { this._wrongT--; this._wrong.y -= 0.6; this._wrong.opacity = Math.min(255, this._wrongT * 10); if (this._wrongT === 0) this._wrong.visible = false; }
  };

  Scene_Rebuttal.prototype.finish = function (won) {
    var s = this._state;
    window.CSAF_Rebuttal.lastResult = { won: !!won, outcome: s ? s.outcome : 'empty', shots: s ? s.shots : 0, influence: s ? s.influence : 0 };
    if (CFG.wonSwitch > 0) $gameSwitches.setValue(CFG.wonSwitch, !!won);
    if (CFG.shotsVariable > 0) $gameVariables.setValue(CFG.shotsVariable, s ? s.shots : 0);
    SceneManager.pop();
  };

  window.Scene_Rebuttal = Scene_Rebuttal;
})();
