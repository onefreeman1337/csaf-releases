//=============================================================================
// RebuttalDraw.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Rebuttal's look: the trial ring, kinetic type and the weak-point glow, drawn in code. Load after RebuttalCore.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * Nothing here is an image file. The trial ring, every statement's letters,
 * the glow on a weak point and the crosshair are drawn with canvas paths when
 * a debate opens. The type is a bold display face from the player's system,
 * never the engine's default font.
 */

var CSAF = CSAF || {};

(function () {
  'use strict';

  /** Display stack for statements: heavy, condensed-reading faces present on desktop systems. Never rmmz-mainfont. */
  var FACE = '"Arial Black", "Segoe UI Black", "Helvetica Neue", Impact, sans-serif';
  /** Per-speaker palettes: letter fill, letter edge, and the speaker's accent (the ring seat, the name plate). */
  var PALETTES = [
    { fill: '#f6efe0', edge: '#1b1424', accent: '#e05a7a' },
    { fill: '#e8f3ff', edge: '#101a2a', accent: '#4fa3ff' },
    { fill: '#f3ffe9', edge: '#122214', accent: '#6fd36a' },
    { fill: '#fff4dc', edge: '#2a1a08', accent: '#f0a030' },
    { fill: '#f6e9ff', edge: '#1d1029', accent: '#b07cff' },
    { fill: '#e9fffb', edge: '#0d2421', accent: '#3fd6c0' }
  ];
  /** The weak point: hot gold with a glow, the one colour no palette uses for its letters. */
  var WEAK = { fill: '#ffcf3a', edge: '#5a1a00', glow: 'rgba(255,150,40,0.95)' };

  /**
   * The trial ring: a dark floor, a lit ring of seats around it, the speaker's seat lit in their accent.
   * @param {CanvasRenderingContext2D} c context @param {number} w width @param {number} h height
   * @param {{seats:number, speaker:number, palette:number}} o seats in the ring, the speaking seat, its palette
   */
  function drawStage(c, w, h, o) {
    var seats = Math.max(3, o.seats || 8), cx = w / 2, cy = h * 0.62;
    var g = c.createRadialGradient(cx, cy, h * 0.05, cx, cy, w * 0.75);
    g.addColorStop(0, '#2a1d3a'); g.addColorStop(0.55, '#130c1d'); g.addColorStop(1, '#06040a');
    c.fillStyle = g; c.fillRect(0, 0, w, h);
    // concentric floor rings, foreshortened
    for (var r = 0; r < 5; r++) {
      c.strokeStyle = 'rgba(255,220,255,' + (0.05 + 0.03 * r) + ')'; c.lineWidth = 1 + r * 0.4;
      c.beginPath(); c.ellipse(cx, cy, w * (0.16 + 0.07 * r), h * (0.07 + 0.03 * r), 0, 0, Math.PI * 2); c.stroke();
    }
    // the seats: podiums on a wide ellipse, nearer ones larger and lower (asymmetric: the speaker's seat is raised)
    for (var i = 0; i < seats; i++) {
      var a = -Math.PI / 2 + (i / seats) * Math.PI * 2, px = cx + Math.cos(a) * w * 0.42, py = cy + Math.sin(a) * h * 0.24;
      var near = (Math.sin(a) + 1) / 2, sw = 26 + 22 * near, sh = 14 + 10 * near, lit = i === o.speaker;
      var pal = PALETTES[(o.palette || 0) % PALETTES.length];
      c.fillStyle = lit ? pal.accent : 'rgba(70,52,92,' + (0.55 + 0.35 * near) + ')';
      c.beginPath(); c.moveTo(px - sw / 2, py); c.lineTo(px + sw / 2, py); c.lineTo(px + sw * 0.38, py + sh); c.lineTo(px - sw * 0.38, py + sh); c.closePath(); c.fill();
      c.fillStyle = lit ? '#ffffff' : 'rgba(255,230,255,0.25)'; c.fillRect(px - sw / 2, py - 2, sw, 2);
      // a nameplate for every seat the debate's cast sits in (LOOKED: unnamed seats read as plain flower pots)
      if (o.names && o.names[i]) {
        c.save(); c.font = '700 ' + Math.round(10 + 3 * near) + 'px ' + FACE; c.textAlign = 'center'; c.textBaseline = 'top';
        c.fillStyle = lit ? pal.accent : 'rgba(230,214,240,' + (0.35 + 0.35 * near) + ')';
        c.fillText(String(o.names[i]).toUpperCase(), px, py + sh + 4); c.restore();
      }
      // the spotlight is filled as its own disc: filling a rect smaller than the gradient left hard box edges (LOOKED)
      if (lit) { var sp = c.createRadialGradient(px, py - 40, 4, px, py - 40, 100); sp.addColorStop(0, 'rgba(255,240,220,0.30)'); sp.addColorStop(1, 'rgba(255,240,220,0)'); c.fillStyle = sp; c.beginPath(); c.arc(px, py - 40, 100, 0, Math.PI * 2); c.fill(); }
    }
  }

  /**
   * One glyph of a statement, at its choreographed place. Weak glyphs glow gold; others wear the speaker's palette.
   * @param {CanvasRenderingContext2D} c context @param {string} ch character
   * @param {{x:number,y:number,scale:number,alpha:number,rot:number}} p place (RebuttalCore.glyphAt)
   * @param {number} px base pixel size @param {number} palette speaker palette @param {boolean} weak weak point glyph
   * @param {number} pulse 0..1 glow pulse for the weak point
   */
  function drawGlyph(c, ch, p, px, palette, weak, pulse) {
    if (ch === ' ' || p.alpha <= 0.01) return;
    var pal = PALETTES[palette % PALETTES.length];
    c.save();
    c.globalAlpha = Math.min(1, p.alpha);
    c.translate(p.x, p.y); c.rotate(p.rot); c.scale(p.scale, p.scale);
    c.font = 'italic 900 ' + px + 'px ' + FACE; c.textAlign = 'center'; c.textBaseline = 'middle';
    c.lineJoin = 'round';
    if (weak) { c.shadowColor = WEAK.glow; c.shadowBlur = 10 + 10 * pulse; }
    c.strokeStyle = weak ? WEAK.edge : pal.edge; c.lineWidth = Math.max(2, px * 0.16); c.strokeText(ch, 0, 0);
    c.shadowBlur = 0;
    c.fillStyle = weak ? WEAK.fill : pal.fill; c.fillText(ch, 0, 0);
    c.restore();
  }

  /**
   * The crosshair: an open ring with four ticks, cyan-white over a dark keyline so it reads ON the gold weak point
   * (LOOKED 2026-10-07: a gold crosshair vanished on gold letters, exactly where the player aims).
   */
  function drawCrosshair(c, x, y, r) {
    c.save();
    var pass = function (col, lw) {
      c.strokeStyle = col; c.lineWidth = lw;
      c.beginPath(); c.arc(x, y, r, 0.2, Math.PI * 2 - 0.2); c.stroke();
      for (var k = 0; k < 4; k++) { var a = k * Math.PI / 2; c.beginPath(); c.moveTo(x + Math.cos(a) * r * 0.55, y + Math.sin(a) * r * 0.55); c.lineTo(x + Math.cos(a) * r * 1.35, y + Math.sin(a) * r * 1.35); c.stroke(); }
    };
    pass('rgba(6,4,14,0.9)', 5.5);
    pass('#9ff6ff', 2.5);
    c.fillStyle = '#ffffff'; c.beginPath(); c.arc(x, y, 2, 0, Math.PI * 2); c.fill();
    c.restore();
  }

  /** The ground behind everything, so the scene has no letterbox bands (LOOKED 2026-10-07: black bars above and below). */
  function drawGround(c, w, h) {
    var g = c.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, '#0d0816'); g.addColorStop(0.7, '#130c1d'); g.addColorStop(1, '#07050b');
    c.fillStyle = g; c.fillRect(0, 0, w, h);
  }

  /**
   * The HUD plate: a revolver cylinder with one brass cartridge per held bullet (the chosen one turned to the top and
   * lit), the chosen bullet's name, influence as pips and the time as a draining bar. Drawn, never a window.
   * @param {CanvasRenderingContext2D} c context @param {number} w width @param {number} h height
   * @param {{bullets:string[], current:number, influence:number, maxInfluence:number, timeFrac:number}} o state
   */
  function drawHud(c, w, h, o) {
    c.clearRect(0, 0, w, h);
    var pg = c.createLinearGradient(0, 0, 0, h); pg.addColorStop(0, '#1c1428'); pg.addColorStop(1, '#0a0710');
    c.fillStyle = pg; c.fillRect(0, 0, w, h);
    c.fillStyle = '#c9932e'; c.fillRect(0, 0, w, 3); c.fillStyle = 'rgba(255,220,140,0.35)'; c.fillRect(0, 3, w, 1);
    // the cylinder
    // six chambers at least, empties drawn dark: two loaded chambers alone read as a sparse disc (LOOKED 2026-10-07)
    var held = o.bullets.length, n = Math.max(6, held), cx = 70, cy = h / 2 + 2, R = Math.min(h * 0.40, 46), cr = Math.min(R * 0.30, 12);
    var cg = c.createRadialGradient(cx - R * 0.3, cy - R * 0.3, 4, cx, cy, R * 1.1); cg.addColorStop(0, '#6f6a78'); cg.addColorStop(1, '#25222c');
    c.fillStyle = cg; c.beginPath(); c.arc(cx, cy, R, 0, Math.PI * 2); c.fill();
    c.strokeStyle = 'rgba(0,0,0,0.8)'; c.lineWidth = 2; c.stroke();
    for (var i = 0; i < n; i++) {
      var a = -Math.PI / 2 + ((i - o.current) / n) * Math.PI * 2, x = cx + Math.cos(a) * R * 0.6, y = cy + Math.sin(a) * R * 0.6, lit = i === o.current;
      c.fillStyle = '#0a080e'; c.beginPath(); c.arc(x, y, cr + 2, 0, Math.PI * 2); c.fill();
      if (i >= held) continue;   // an empty chamber stays a dark bore
      var bg = c.createRadialGradient(x - cr * 0.35, y - cr * 0.35, 1, x, y, cr); bg.addColorStop(0, lit ? '#fff1b8' : '#e6c27a'); bg.addColorStop(1, lit ? '#d08a1a' : '#8a6420');
      c.fillStyle = bg; c.beginPath(); c.arc(x, y, cr, 0, Math.PI * 2); c.fill();
      c.fillStyle = lit ? '#7a3c0c' : '#5a4220'; c.beginPath(); c.arc(x, y, cr * 0.34, 0, Math.PI * 2); c.fill();
      if (lit) { c.save(); c.shadowColor = WEAK.glow; c.shadowBlur = 12; c.strokeStyle = WEAK.fill; c.lineWidth = 2; c.beginPath(); c.arc(x, y, cr + 3, 0, Math.PI * 2); c.stroke(); c.restore(); }
    }
    // the chosen bullet's name
    c.save(); c.textBaseline = 'middle';
    c.font = '700 13px ' + FACE; c.fillStyle = 'rgba(246,239,224,0.6)'; c.fillText('TRUTH BULLET', 140, h * 0.30);
    c.font = 'italic 900 26px ' + FACE; c.lineJoin = 'round'; c.strokeStyle = WEAK.edge; c.lineWidth = 5;
    var name = String(o.bullets[o.current] || 'NONE').toUpperCase();
    c.strokeText(name, 140, h * 0.58); c.fillStyle = WEAK.fill; c.fillText(name, 140, h * 0.58);
    // influence pips
    var px0 = w - 40 - o.maxInfluence * 30;
    c.font = '700 13px ' + FACE; c.fillStyle = 'rgba(246,239,224,0.6)'; c.fillText('INFLUENCE', px0, h * 0.30);
    for (var k = 0; k < o.maxInfluence; k++) {
      var pxk = px0 + k * 30 + 10, py = h * 0.58, on = k < o.influence;
      c.fillStyle = on ? '#e05a7a' : 'rgba(224,90,122,0.18)';
      c.beginPath(); c.moveTo(pxk, py - 10); c.lineTo(pxk + 9, py); c.lineTo(pxk, py + 10); c.lineTo(pxk - 9, py); c.closePath(); c.fill();
      if (on) { c.strokeStyle = '#ffd0dc'; c.lineWidth = 1.5; c.stroke(); }
    }
    // time: a draining bar along the bottom
    var tf = Math.max(0, Math.min(1, o.timeFrac));
    c.fillStyle = 'rgba(255,255,255,0.08)'; c.fillRect(140, h - 16, w - 180, 6);
    c.fillStyle = tf > 0.25 ? '#9ff6ff' : '#ff6a6a'; c.fillRect(140, h - 16, (w - 180) * tf, 6);
    c.restore();
  }

  /** The verdict stamp: a tilted plate with heavy italic letters (REFUTED in gold, or the loss word in red). */
  function drawStamp(c, w, h, word, won) {
    c.clearRect(0, 0, w, h);
    c.save(); c.translate(w / 2, h / 2); c.rotate(-0.08);
    var pw = w * 0.86, ph = h * 0.62;
    c.fillStyle = won ? 'rgba(40,20,4,0.88)' : 'rgba(40,6,10,0.88)'; c.fillRect(-pw / 2, -ph / 2, pw, ph);
    c.strokeStyle = won ? WEAK.fill : '#ff6a6a'; c.lineWidth = 4; c.strokeRect(-pw / 2 + 6, -ph / 2 + 6, pw - 12, ph - 12);
    c.font = 'italic 900 ' + Math.round(ph * 0.55) + 'px ' + FACE; c.textAlign = 'center'; c.textBaseline = 'middle'; c.lineJoin = 'round';
    c.shadowColor = won ? WEAK.glow : 'rgba(255,60,60,0.9)'; c.shadowBlur = 16;
    c.strokeStyle = won ? WEAK.edge : '#3a0006'; c.lineWidth = 8; c.strokeText(word, 0, 4);
    c.shadowBlur = 0; c.fillStyle = won ? WEAK.fill : '#ff8a8a'; c.fillText(word, 0, 4);
    c.restore();
  }

  CSAF.RebuttalArt = { FACE: FACE, PALETTES: PALETTES, WEAK: WEAK, drawStage: drawStage, drawGlyph: drawGlyph, drawCrosshair: drawCrosshair, drawGround: drawGround, drawHud: drawHud, drawStamp: drawStamp };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.RebuttalArt;
