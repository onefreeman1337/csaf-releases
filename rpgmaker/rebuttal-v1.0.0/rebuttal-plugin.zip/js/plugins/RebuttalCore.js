//=============================================================================
// RebuttalCore.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Rebuttal rules: reads a debate written in comments and composes how every statement moves. Load FIRST.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The rules only: no drawing, no scene, no engine code. Rebuttal.js (the
 * debate scene) and RebuttalDraw.js (the look) read it.
 *
 * Every statement's motion is composed from its own words and its speaker:
 * each speaker moves in their own way, each line enters differently from the
 * one before it, punctuation sets the emphasis, and long lines move slower so
 * they stay readable. Everything is seeded; there is no Math.random anywhere.
 */

var CSAF = CSAF || {};

(function () {
  'use strict';

  var VERSION = '1.0.0';
  /** The stage statements move on, in its own pixels (the scene scales it). */
  var STAGE = { w: 816, h: 460 };
  /** Base type size: line height and glyph height at scale 1. */
  var FONT_H = 30, LINE_H = 36;
  /** Widest a statement may set before it wraps (keeps it on stage while it drifts). */
  var MAX_LINE_W = 520;
  /** Reading floor: a statement stays readable at least this many frames per character (15 characters a second). */
  var FRAMES_PER_CHAR = 4;
  /** A weak point is wholly on stage and shootable at least this long, every pass. */
  var MIN_SHOT_WINDOW = 45;
  var ENTER = 24, EXIT = 16;
  /** Longest statement (characters, after the brackets are removed). The scene pools 180 glyph sprites; a longer line
   *  would lose its tail without a word, so the parser refuses it with a reason instead (found 2026-10-07). */
  var MAX_CHARS = 160;

  var ENTRANCES = ['slide', 'zoom', 'drop', 'rise', 'spin', 'type', 'split', 'sweep'];
  var PATHS = ['drift', 'arc', 'wave', 'orbit', 'zig', 'hold', 'tilt'];

  //---------------------------------------------------------------------------
  // Seeds
  //---------------------------------------------------------------------------

  /** FNV-1a. @param {*} s @returns {number} uint32 */
  function hash(s) {
    var h = 2166136261, str = String(s);
    for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    return h >>> 0;
  }
  /** A stable fraction in [0,1) from a key. */
  function frac(key) { return hash(key) / 4294967296; }

  //---------------------------------------------------------------------------
  // Parsing the comment lines
  //---------------------------------------------------------------------------

  var LINE_RE = /^\s*Rebuttal( noise)?\s*:\s*(.*)$/i;

  /**
   * Parse one comment line. Lines that do not start with "Rebuttal" are not ours and return null.
   * @param {string} line comment text
   * @param {number} n 1-based line number (for errors)
   * @returns {{statement:?object, error:?object}|null} result
   */
  function parseLine(line, n) {
    var m = LINE_RE.exec(String(line || ''));
    if (!m) return null;
    var noise = !!m[1], parts = m[2].split('|').map(function (s) { return s.trim(); });
    var err = function (why) { return { statement: null, error: { line: n, why: why } }; };
    var speaker = parts[0] || '', raw = parts[1] || '', answer = parts[2] || '';
    if (!speaker) return err('no speaker before the first |');
    if (!raw) return err('no statement text after the speaker');
    var opens = raw.split('{').length - 1, closes = raw.split('}').length - 1;
    if (opens !== closes) return err('a weak point is not closed: every { needs a }');
    if (opens > 1) return err('two weak points in one statement: give each its own line');
    var weak = null, text = raw;
    if (opens === 1) {
      var a = raw.indexOf('{'), b = raw.indexOf('}');
      if (b < a) return err('a } comes before its {');
      var inner = raw.slice(a + 1, b);
      if (!inner.trim()) return err('an empty weak point {}');
      text = raw.slice(0, a) + inner + raw.slice(b + 1);
      weak = { text: inner, start: a, end: a + inner.length };
      if (!answer && !noise) return err('a weak point needs the bullet that breaks it after a second |');
    } else if (answer) {
      return err('a bullet is named but the statement has no {weak point}');
    }
    if (noise && weak) return err('a noise line cannot have a weak point');
    if (text.length > MAX_CHARS) return err('too long (' + text.length + ' characters, the most is ' + MAX_CHARS + '): split it into two statements');
    return { statement: { kind: noise ? 'noise' : 'statement', speaker: speaker, text: text, weak: weak, answer: weak ? answer : null }, error: null };
  }

  /**
   * Parse a debate from comment lines (blank and foreign lines are skipped).
   * @param {string[]} lines comment lines in order
   * @returns {{statements:object[], errors:object[]}} parsed
   */
  function parseDebate(lines) {
    var out = { statements: [], errors: [] };
    for (var i = 0; i < (lines || []).length; i++) {
      var r = parseLine(lines[i], i + 1);
      if (!r) continue;
      if (r.error) out.errors.push(r.error); else out.statements.push(r.statement);
    }
    return out;
  }

  //---------------------------------------------------------------------------
  // Composing a statement's choreography
  //---------------------------------------------------------------------------

  /**
   * Break text into lines no wider than MAX_LINE_W; returns per-glyph local positions (centre origin). The weak point
   * is ONE unbreakable token: LOOKED 2026-10-07, "locked from the / inside" wrapped and its box spanned two lines, so
   * a shot at the non-weak word between them counted as a hit. Glyph i is always text[i] (spaces stay inside tokens).
   */
  function layout(text, widths, weak) {
    var raw = text.split(' '), words = [], at = 0;
    for (var r = 0; r < raw.length; r++) {
      var s0 = at, s1 = at + raw[r].length; at = s1 + 1;
      var inWeak = weak && s1 > weak.start && s0 < weak.end;
      if (inWeak && words.length && words[words.length - 1].weak) words[words.length - 1].t += ' ' + raw[r];
      else words.push({ t: raw[r], weak: !!inWeak });
    }
    words = words.map(function (w) { return w.t; });
    var space = widths(' '), ww = words.map(function (t) { var s = 0; for (var k = 0; k < t.length; k++) s += widths(t[k]); return s; });
    var wrap = function (maxW) {
      var L = [[]], W = [0];
      for (var i = 0; i < words.length; i++) {
        var cur = L.length - 1, add = (L[cur].length ? space : 0) + ww[i];
        if (L[cur].length && W[cur] + add > maxW) { L.push([]); W.push(0); cur++; add = ww[i]; }
        L[cur].push(words[i]); W[cur] += add;
      }
      return { lines: L, lw: W };
    };
    // BALANCED: keep the greedy line count but even the lengths, so no line is a lone last word (LOOKED 2026-10-07:
    // "The door was / locked from the inside the whole / night.")
    var best = wrap(MAX_LINE_W);
    if (best.lines.length > 1) {
      var total = 0; for (var q0 = 0; q0 < best.lw.length; q0++) total += best.lw[q0];
      for (var target = total / best.lines.length; target < MAX_LINE_W; target += 8) {
        var tryW = wrap(target);
        if (tryW.lines.length === best.lines.length) { best = tryW; break; }
      }
    }
    var lines = best.lines, lw = best.lw;
    var gx = [], gy = [], gw = [], idx = 0, H = lines.length * LINE_H;
    for (var L = 0; L < lines.length; L++) {
      var x = -lw[L] / 2, y = -H / 2 + L * LINE_H + LINE_H / 2, s = lines[L].join(' ');
      for (var c = 0; c < s.length; c++) {
        var cw = widths(s[c]);
        gx[idx] = x + cw / 2; gy[idx] = y; gw[idx] = cw; x += cw; idx++;
      }
      if (L < lines.length - 1) { gx[idx] = x; gy[idx] = y; gw[idx] = 0; idx++; } // the space the break consumed
    }
    var maxW = 0; for (var q = 0; q < lw.length; q++) if (lw[q] > maxW) maxW = lw[q];
    return { gx: gx, gy: gy, gw: gw, width: maxW, height: H, lines: lines.length };
  }

  function emphasisOf(text) {
    var t = text.trim();
    if (/\.\.\.|…/.test(t)) return 'drift';
    if (/!$/.test(t)) return 'punch';
    if (/\?$/.test(t)) return 'wobble';
    return 'plain';
  }

  /**
   * Compose one statement's motion. Deterministic: same statement, same options, same result.
   * @param {object} st parsed statement
   * @param {{seed:*, index:number, widths:function(string):number}} opts index = its place in the debate
   * @returns {object} choreography
   */
  function compose(st, opts) {
    var seed = String(opts && opts.seed !== undefined ? opts.seed : 'rebuttal');
    var index = Math.max(0, Math.floor(Number(opts && opts.index) || 0));
    var widths = (opts && opts.widths) || function () { return 14; };
    var lay = layout(st.text, widths, st.weak);
    // Each speaker moves within their own family of three paths and the statement's words pick which; entrances are
    // taken IN TURN through the debate, so neighbours never enter alike. (First version: path by speaker alone, so
    // path and entrance cycled together and sixty statements made 26 distinct choreographies - the volume test.)
    var path = PATHS[(hash('path:' + seed + ':' + st.speaker) + hash('pv:' + st.text) % 3) % PATHS.length];
    var entrance = ENTRANCES[(index + hash('enter:' + seed)) % ENTRANCES.length];
    var emphasis = emphasisOf(st.text);
    var dir = (hash('dir:' + seed + ':' + st.speaker + ':' + st.text) & 1) ? 1 : -1;
    var lane = index % 3;
    var cx0 = STAGE.w / 2, cy0 = STAGE.h * (0.27 + 0.23 * lane);
    var margin = (STAGE.w - lay.width * 1.08) / 2 - 12;
    var amp = Math.max(0, Math.min(150, margin));
    var dwell = Math.max(Math.ceil(st.text.length * FRAMES_PER_CHAR), MIN_SHOT_WINDOW + 20) + 10;
    var weakIdx = [];
    if (st.weak) for (var i = st.weak.start; i < st.weak.end; i++) if (st.text[i] !== ' ') weakIdx.push(i);
    var scat = [];
    for (var g = 0; g < lay.gx.length; g++) scat.push([(frac('sx:' + seed + index + ':' + g) - 0.5) * 240, (frac('sy:' + seed + index + ':' + g) - 0.5) * 160]);
    return {
      kind: st.kind, speaker: st.speaker, text: st.text, answer: st.answer, weak: st.weak, weakIdx: weakIdx,
      entrance: entrance, path: path, emphasis: emphasis, dir: dir, lane: lane, cx0: cx0, cy0: cy0, amp: amp,
      enter: ENTER, dwell: dwell, exit: EXIT, frames: ENTER + dwell + EXIT,
      gx: lay.gx, gy: lay.gy, gw: lay.gw, width: lay.width, height: lay.height, lines: lay.lines, scat: scat,
      palette: hash('pal:' + st.speaker) % 6
    };
  }

  /** What makes two choreographies LOOK different: entrance, path, emphasis, direction, number of lines. */
  function signature(c) { return [c.entrance, c.path, c.emphasis, c.dir, c.lines].join('|'); }

  function easeOut(u) { u = u < 0 ? 0 : u > 1 ? 1 : u; return 1 - (1 - u) * (1 - u) * (1 - u); }

  // statement-level transform at frame t, into a reusable record (no allocation per call)
  var T = { cx: 0, cy: 0, s: 1, r: 0, a: 1, e: 1 };
  function frameOf(c, t) {
    var u, e;
    T.cx = c.cx0; T.cy = c.cy0; T.s = 1; T.r = 0; T.a = 1; T.e = 1;
    if (t < c.enter) {
      u = t / c.enter; e = easeOut(u); T.e = e;
      switch (c.entrance) {
        case 'slide': T.cx = c.cx0 - c.dir * (1 - e) * (STAGE.w * 0.75); break;
        case 'zoom': T.s = 2.4 - 1.4 * e; T.a = e; break;
        case 'drop': T.cy = c.cy0 - (1 - e) * (c.cy0 + 80); break;
        case 'rise': T.cy = c.cy0 + (1 - e) * (STAGE.h - c.cy0 + 80); break;
        case 'spin': T.r = c.dir * (1 - e) * 1.2; T.s = 0.4 + 0.6 * e; T.a = e; break;
        case 'type': break;
        case 'split': T.a = 0.3 + 0.7 * e; break;
        case 'sweep': T.cx = c.cx0 - c.dir * (1 - e) * 420; T.cy = c.cy0 - Math.sin(e * Math.PI / 2 + Math.PI / 2) * 0 - (1 - e) * 120; break;
      }
      return T;
    }
    var d = t - c.enter;
    var v = d >= c.dwell ? 1 : d / c.dwell;
    switch (c.path) {
      case 'drift': T.cx = c.cx0 + c.dir * c.amp * v; break;
      case 'arc': T.cx = c.cx0 + c.dir * c.amp * v; T.cy = c.cy0 - Math.sin(Math.PI * v) * 22; break;
      case 'wave': T.cx = c.cx0 + c.dir * c.amp * 0.6 * v; T.cy = c.cy0 + Math.sin(Math.PI * 4 * v) * 12; break;
      case 'orbit': T.cx = c.cx0 + c.dir * (Math.cos(Math.PI * 2 * v) - 1) * 16; T.cy = c.cy0 + Math.sin(Math.PI * 2 * v) * 12; break;
      case 'zig': { var z = (v * 3) % 1; T.cx = c.cx0 + c.dir * c.amp * v; T.cy = c.cy0 + (z < 0.5 ? z * 2 : 2 - z * 2) * 16 - 8 * (v > 0 ? 1 : 0) + 8 * (v > 0 ? 0 : 0); break; }
      case 'hold': T.s = 1 + 0.04 * Math.sin(Math.PI * 4 * v); break;
      case 'tilt': T.cx = c.cx0 + c.dir * c.amp * 0.4 * v; T.r = 0.06 * Math.sin(Math.PI * 3 * v); break;
    }
    if (c.emphasis === 'punch') T.s *= 1 + 0.22 * Math.exp(-d / 10);
    else if (c.emphasis === 'wobble') T.r += 0.05 * Math.sin(d * 0.3) * Math.exp(-d / 60);
    else if (c.emphasis === 'drift') T.a = 0.94 + 0.06 * Math.cos(d * 0.08);
    if (d >= c.dwell) { var x = (d - c.dwell) / c.exit; T.a *= Math.max(0, 1 - x); }
    return T;
  }

  /**
   * Where glyph i is at frame t. Writes {x, y, scale, alpha, rot} into out; pure, no allocation.
   * @param {object} c choreography @param {number} i glyph index @param {number} t frame @param {object} out written
   * @returns {object} out
   */
  function glyphAt(c, i, t, out) {
    var f = frameOf(c, t), lx = c.gx[i], ly = c.gy[i], a = f.a;
    if (t < c.enter) {
      if (c.entrance === 'split') { var k = (1 - f.e) * (1 - f.e); lx += c.scat[i][0] * k; ly += c.scat[i][1] * k; }
      else if (c.entrance === 'type') a *= (i < (t / c.enter) * c.gx.length) ? 1 : 0;
    }
    var cs = Math.cos(f.r), sn = Math.sin(f.r);
    out.x = f.cx + (lx * cs - ly * sn) * f.s;
    out.y = f.cy + (lx * sn + ly * cs) * f.s;
    out.scale = f.s; out.alpha = a; out.rot = f.r;
    return out;
  }

  var G = { x: 0, y: 0, scale: 1, alpha: 1, rot: 0 };

  /** The weak point's box at frame t (axis aligned around its glyphs). Writes into out; w = 0 when there is none. */
  function weakBox(c, t, out) {
    out.x = 0; out.y = 0; out.w = 0; out.h = 0;
    if (!c.weakIdx.length) return out;
    var x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    for (var k = 0; k < c.weakIdx.length; k++) {
      var i = c.weakIdx[k];
      glyphAt(c, i, t, G);
      var hw = c.gw[i] * G.scale / 2, hh = FONT_H * G.scale / 2;
      if (G.x - hw < x0) x0 = G.x - hw; if (G.x + hw > x1) x1 = G.x + hw;
      if (G.y - hh < y0) y0 = G.y - hh; if (G.y + hh > y1) y1 = G.y + hh;
    }
    out.x = x0; out.y = y0; out.w = x1 - x0; out.h = y1 - y0;
    return out;
  }

  /** Is every glyph of the weak point visible (alpha >= 0.5)? A weak point still typing in cannot be shot. */
  function weakVisible(c, t) {
    if (!c.weakIdx.length) return false;
    for (var k = 0; k < c.weakIdx.length; k++) { glyphAt(c, c.weakIdx[k], t, G); if (G.alpha < 0.5) return false; }
    return true;
  }

  var BX = { x: 0, y: 0, w: 0, h: 0 };
  /** Does a shot at (x, y) on frame t strike the weak point? Only while it is wholly visible (weakVisible). */
  function hits(c, t, x, y) {
    weakBox(c, t, BX);
    if (BX.w <= 0) return false;
    if (!weakVisible(c, t)) return false;
    // only while WHOLLY on stage (the Readme's promise; found unenforced by reading the Readme against the code)
    if (BX.x < 0 || BX.y < 0 || BX.x + BX.w > STAGE.w || BX.y + BX.h > STAGE.h) return false;
    var p = 3;
    return x >= BX.x - p && x <= BX.x + BX.w + p && y >= BX.y - p && y <= BX.y + BX.h + p;
  }

  /** Frames during which every glyph is on stage and solid enough to read (alpha >= 0.85). */
  function readableFrames(c) {
    var n = 0;
    for (var t = 0; t < c.frames; t++) {
      var ok = true;
      for (var i = 0; i < c.gx.length && ok; i++) {
        glyphAt(c, i, t, G);
        if (G.alpha < 0.85 || G.x < 0 || G.x > STAGE.w || G.y < 0 || G.y > STAGE.h) ok = false;
      }
      if (ok) n++;
    }
    return n;
  }

  //---------------------------------------------------------------------------
  // The debate
  //---------------------------------------------------------------------------

  /**
   * A running debate: statements loop until the right bullet breaks a weak point, influence runs out, or time.
   * @param {{statements:object[]}} debate parseDebate() result
   * @param {{seed:*, influence:number, timeLimit:number, widths:function}} opts options
   * @returns {object} state
   */
  function newDebate(debate, opts) {
    var list = [];
    for (var i = 0; i < debate.statements.length; i++) list.push(compose(debate.statements[i], { seed: opts.seed, index: i, widths: opts.widths }));
    return { list: list, cur: 0, t: 0, time: 0, loops: 0, influence: Math.max(1, Math.floor(Number(opts.influence) || 3)), timeLimit: Math.max(60, Math.floor(Number(opts.timeLimit) || 5400)), outcome: null, shots: 0 };
  }

  function step(s) {
    if (s.outcome) return s;
    s.t++; s.time++;
    if (s.t >= s.list[s.cur].frames) { s.t = 0; s.cur++; if (s.cur >= s.list.length) { s.cur = 0; s.loops++; } }
    if (s.time >= s.timeLimit) s.outcome = 'timeout';
    return s;
  }

  /** Jump to statement i, at its entrance ('start') or the middle of its dwell ('middle'). For previews and tests. */
  function advanceTo(s, i, where) {
    s.cur = Math.max(0, Math.min(s.list.length - 1, i));
    var c = s.list[s.cur];
    s.t = where === 'middle' ? c.enter + Math.floor(c.dwell / 2) : 0;
    return s;
  }

  function currentWeakBox(s, out) { return weakBox(s.list[s.cur], s.t, out); }

  /**
   * Fire a bullet at (x, y) on the current frame.
   * @returns {{result:'refuted'|'wrong'|'miss'|'over'}} what happened
   */
  function fire(s, bullet, x, y) {
    if (s.outcome) return { result: 'over' };
    s.shots++;
    var c = s.list[s.cur];
    if (c.kind === 'statement' && c.weakIdx.length && hits(c, s.t, x, y)) {
      if (String(bullet) === String(c.answer)) { s.outcome = 'won'; return { result: 'refuted', statement: s.cur }; }
      s.influence--;
      if (s.influence <= 0) s.outcome = 'lost';
      return { result: 'wrong', statement: s.cur };
    }
    return { result: 'miss' };
  }

  CSAF.RebuttalCore = {
    VERSION: VERSION, STAGE: STAGE, FONT_H: FONT_H, LINE_H: LINE_H, FRAMES_PER_CHAR: FRAMES_PER_CHAR, MIN_SHOT_WINDOW: MIN_SHOT_WINDOW, MAX_CHARS: MAX_CHARS,
    ENTRANCES: ENTRANCES, PATHS: PATHS, hash: hash, parseLine: parseLine, parseDebate: parseDebate, compose: compose,
    signature: signature, glyphAt: glyphAt, weakBox: weakBox, weakVisible: weakVisible, hits: hits, readableFrames: readableFrames,
    newDebate: newDebate, step: step, advanceTo: advanceTo, currentWeakBox: currentWeakBox, fire: fire
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.RebuttalCore;
