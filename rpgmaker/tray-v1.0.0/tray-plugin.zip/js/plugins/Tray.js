//=============================================================================
// Tray.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Tray - generated packing puzzles in inlaid wood: fit
 * every piece back into its shaped tray. Place BELOW TrayCore and TrayDraw.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * Tray
 * ============================================================================
 *
 * A packing puzzle for your game. A shaped tray sits on the table and its
 * pieces wait in a box beside it, turned every which way. The player picks
 * them up, turns and flips them, and fits every one back into the tray.
 *
 * EVERY PUZZLE IS GENERATED, AND EVERY ONE CAN BE SOLVED. The tray (a
 * rectangle, a cross, a diamond, a round, a notched or an arch) is cut into
 * pieces of three to six squares, all different even turned over, so the
 * pieces always go back. A built-in solver grades each puzzle by how many
 * different ways the tray can be filled, and the generator keeps the
 * tightest of several carvings for the difficulty you ask for.
 *
 * EVERY PIECE IS MARQUETRY. Each piece is cut from its own wood (walnut,
 * maple, cherry, oak, ebony, ash, rosewood, yew, olive, holly) and carries
 * an inlaid motif in brass, mother-of-pearl, holly or ebony, with a line of
 * stringing run inside its edge. Nothing is an image file: it is all drawn
 * when the puzzle opens, and a finished tray is a panel of inlaid wood.
 *
 * ----------------------------------------------------------------------------
 * INSTALLING
 * ----------------------------------------------------------------------------
 * Plugin Manager order, top to bottom:
 *
 *     TrayCore.js     (the generator, the solver, the rules)
 *     TrayDraw.js     (the drawing)
 *     Tray.js         (this file: parameters, the command, the scene)
 *
 * ----------------------------------------------------------------------------
 * USING IT
 * ----------------------------------------------------------------------------
 * Add the plugin command "Open Tray" to an event. Choose the difficulty
 * (easy: 4 or 5 pieces, normal: 6 or 7, hard: 8 to 10), the shape, how many
 * hints the player may ask for, and the variables and switch to set. The
 * event waits while the player works.
 *
 *   Moves variable     pieces put down by the player (0 if they left)
 *   Hints variable     hints used
 *   Switch             on when the tray is filled, off if they left
 *   A new puzzle each time it is solved
 *                      off: the same event always gives the same puzzle
 *                      on:  each solve at that event deals a fresh one
 *
 * ----------------------------------------------------------------------------
 * CONTROLS
 * ----------------------------------------------------------------------------
 * Keyboard and gamepad: left and right choose a piece, OK picks it up, the
 * arrows move it over the tray, Q and W turn it, Shift flips it, OK puts it
 * down, Cancel puts it back. Tab asks for a hint. Escape leaves.
 * Mouse and touch: drag a piece onto the tray; while holding it, the right
 * button or the wheel turns it. Click the plaques to turn, flip, ask for a
 * hint or leave. Right-click on the table leaves.
 *
 * ----------------------------------------------------------------------------
 * COMPATIBILITY
 * ----------------------------------------------------------------------------
 * Tray adds its own scene and replaces nothing. It extends one engine method
 * (Game_System.initialize) to create its save record, calling the original
 * first.
 *
 * ============================================================================
 * TERMS OF USE
 * ============================================================================
 * Commercial and non-commercial use permitted in RPG Maker projects, credit
 * appreciated but not required. Do not redistribute the source as an asset
 * pack. Every line of this plugin was written with AI assistance.
 *
 * ============================================================================
 *
 * @param pickSe
 * @text Sound: a piece picked up
 * @type file
 * @dir audio/se
 * @default Cursor2
 *
 * @param dropSe
 * @text Sound: a piece put down
 * @type file
 * @dir audio/se
 * @default Knock
 *
 * @param turnSe
 * @text Sound: a piece turned or flipped
 * @type file
 * @dir audio/se
 * @default Cursor1
 *
 * @param refuseSe
 * @text Sound: it does not fit
 * @type file
 * @dir audio/se
 * @default Buzzer1
 *
 * @param hintSe
 * @text Sound: a hint
 * @type file
 * @dir audio/se
 * @default Book1
 *
 * @param solveSe
 * @text Sound: the tray filled
 * @type file
 * @dir audio/se
 * @default Item3
 *
 * @command open
 * @text Open Tray
 * @desc Open a packing puzzle. The event waits until the tray is filled or the player leaves.
 *
 * @arg difficulty
 * @text Difficulty
 * @type select
 * @option easy
 * @option normal
 * @option hard
 * @default normal
 *
 * @arg shape
 * @text Tray shape
 * @type select
 * @option auto
 * @option rect
 * @option cross
 * @option diamond
 * @option round
 * @option notched
 * @option arch
 * @default auto
 *
 * @arg hints
 * @text Hints allowed
 * @type number
 * @min 0
 * @max 99
 * @default 3
 *
 * @arg variableId
 * @text Variable: moves
 * @type variable
 * @default 0
 *
 * @arg hintVariableId
 * @text Variable: hints used
 * @type variable
 * @default 0
 *
 * @arg switchId
 * @text Switch: on when solved
 * @type switch
 * @default 0
 *
 * @arg fresh
 * @text A new puzzle each time it is solved
 * @type boolean
 * @default false
 *
 * @arg title
 * @text Title
 * @desc Shown on the brass plate. Blank = "The Cabinetmaker's Tray".
 * @default
 *
 * @arg seed
 * @text Seed (optional)
 * @desc Blank = keyed to this map and event.
 * @default
 */

var Tray = Tray || {};

(function (M) {
  'use strict';
  var NAME = 'Tray', SCHEMA = 1;
  var raw = (typeof PluginManager !== 'undefined') ? PluginManager.parameters(NAME) : {};
  function num(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; var n = Number(v); return isFinite(n) ? n : d; }
  function str(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; return String(v).trim(); }
  M.params = { pickSe: str(raw.pickSe, 'Cursor2'), dropSe: str(raw.dropSe, 'Knock'), turnSe: str(raw.turnSe, 'Cursor1'), refuseSe: str(raw.refuseSe, 'Buzzer1'), hintSe: str(raw.hintSe, 'Book1'), solveSe: str(raw.solveSe, 'Item3') };

  var _deps = null;
  function deps() {
    if (_deps) return _deps;
    var core = (typeof TrayCore !== 'undefined') ? TrayCore : null, draw = (typeof TrayDraw !== 'undefined') ? TrayDraw : null;
    if (!core || !draw) { if (!deps._w) { deps._w = true; console.error('Tray: TrayCore.js and TrayDraw.js must both be installed and listed ABOVE Tray.js.'); } return null; }
    _deps = { core: core, draw: draw }; return _deps;
  }
  M.deps = deps;

  function fresh() { return { v: SCHEMA, solved: {} }; }
  function store() {
    if (typeof $gameSystem === 'undefined' || !$gameSystem) return fresh();
    var s = $gameSystem._csafTray; if (!s || s.v == null) { s = fresh(); $gameSystem._csafTray = s; }
    if (!s.solved) s.solved = {}; return s;
  }
  M.store = store;
  M.keyFor = function (mapId, eventId) { return 'm' + Number(mapId) + 'e' + Number(eventId); };
  /** @returns {{times:number, bestMoves:number, hints:number}} what has been solved at this key */
  M.record = function (key) { var r = store().solved[String(key)]; if (!r) { r = { times: 0, bestMoves: 0, hints: 0 }; store().solved[String(key)] = r; } return r; };
  /** How many trays the player has filled, anywhere. */
  M.solvedCount = function () { var c = store().solved, k = 0; for (var id in c) if (c[id]) k += c[id].times || 0; return k; };
  /** The last tray filled: {moves, hints, difficulty, shape, pieces, ways} or null. */
  M.lastResult = null;

  var _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () { _Game_System_initialize.call(this); this._csafTray = fresh(); };

  /** Build a request from command arguments. Returns null if the sibling plugins are missing. */
  M.request = function (args, key, mapId, eventId) {
    var d = deps(); if (!d) return null; args = args || {};
    var fr = String(args.fresh) === 'true', seedText = str(args.seed, '');
    var seed = seedText === '' ? d.core.hashString(key + '|' + (fr ? M.record(key).times : 0)) : (/^\d+$/.test(seedText) ? (Number(seedText) >>> 0) : d.core.hashString(seedText));
    var diff = str(args.difficulty, 'normal'); if (!d.core.DIFFS[diff]) diff = 'normal';
    var shape = str(args.shape, 'auto'); if (d.core.SHAPES.indexOf(shape) < 0) shape = 'auto';
    return { key: key, seed: seed, difficulty: diff, shape: shape, hints: Math.max(0, Math.min(99, Math.floor(num(args.hints, 3)))), fresh: fr,
      variableId: Math.max(0, Math.floor(num(args.variableId, 0))), hintVariableId: Math.max(0, Math.floor(num(args.hintVariableId, 0))), switchId: Math.max(0, Math.floor(num(args.switchId, 0))),
      title: str(args.title, 'The Cabinetmaker\'s Tray'), mapId: mapId, eventId: eventId };
  };

  M.open = function (req) { if (!req) return false; SceneManager.push(Scene_Tray); SceneManager.prepareNextScene(req); return true; };

  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
    PluginManager.registerCommand(NAME, 'open', function (args) {
      var mapId = this._mapId || ($gameMap ? $gameMap.mapId() : 0), eventId = this.eventId ? this.eventId() : 0;
      var seedText = str(args.seed, ''), key = seedText === '' ? M.keyFor(mapId, eventId) : 's' + seedText;
      M.open(M.request(args, key, mapId, eventId));
    });
  }
  M.VERSION = '1.0.0'; M.SCHEMA = SCHEMA;
}(Tray));

//=============================================================================
// Scene_Tray
//=============================================================================

function Scene_Tray() { this.initialize.apply(this, arguments); }
Scene_Tray.prototype = Object.create(Scene_Base.prototype);
Scene_Tray.prototype.constructor = Scene_Tray;
Scene_Tray.CASE = { x: 12, y: 64, w: 504, h: 444 };
Scene_Tray.PARTS = { x: 528, y: 64, w: 276, h: 444 };
Scene_Tray.TITLE = { x: 208, y: 8, w: 400, h: 48 };
Scene_Tray.CARD = { x: 12, y: 516, w: 188, h: 96 };
Scene_Tray.STATUS = { x: 210, y: 514, w: 596, h: 38 };
Scene_Tray.PLAQUES = { x: 222, y: 562, w: 136, h: 36, gap: 146 };
Scene_Tray.LABELS = ['Turn', 'Flip', 'Hint', 'Leave'];

Scene_Tray.prototype.prepare = function (req) { this._req = req; };

Scene_Tray.prototype.create = function () {
  Scene_Base.prototype.create.call(this);
  var d = Tray.deps(), req = this._req, C = d.core; this._d = d;
  var p = C.generate({ seed: req.seed, difficulty: req.difficulty, shape: req.shape === 'auto' ? null : req.shape }) || C.generate({ seed: req.seed, difficulty: 'easy', shape: 'rect' });
  this._p = p; this._g = C.newGame(p); this._mode = 'pick'; this._anim = 0; this._sel = 0; this._hover = -1; this._statusText = ''; this._plaqueKey = ''; this._cardKey = ''; this._ghostKey = '';
  this._hintsLeft = req.hints; this._carry = -1; this._from = null; this._cx = 0; this._cy = 0; this._gx = 0; this._gy = 0; this._snap = { x: 0, y: 0, on: false, fits: false };
  var CA = Scene_Tray.CASE; this._s = Math.min(Math.floor(CA.w / (p.w + 1.3)), Math.floor(CA.h / (p.h + 1.3)), 58);
  // the pieces start in the box turned every which way (seeded, so the same puzzle deals the same way)
  var r = C.rng(p.seed ^ 0x51ED); this._pose = []; this._T = [];
  for (var i = 0; i < p.pieces.length; i++) { this._pose.push({ rot: Math.floor(r() * 4) & 3, flip: r() < 0.5 }); this._T.push(d.draw.turn(p.pieces[i].cells, this._pose[i].rot, this._pose[i].flip)); }
  this.createBoard(); this.layoutParts(); this.createPieces(); this.createUi();
  for (i = 0; i < p.pieces.length; i++) this.placeSprite(i);
  this.refreshCard(); this.refreshPlaques(); this.placePointer();
  this.setStatus('Fit every piece into the tray. OK picks one up; drag it with the mouse.');
};
Scene_Tray.prototype.start = function () { Scene_Base.prototype.start.call(this); this.startFadeIn(this.fadeSpeed(), false); };

Scene_Tray.prototype.createBoard = function () {
  var D = this._d.draw, p = this._p, req = this._req, W = Graphics.width, H = Graphics.height, CA = Scene_Tray.CASE, PA = Scene_Tray.PARTS, TI = Scene_Tray.TITLE;
  var bmp = new Bitmap(W, H), ctx = bmp.context;
  D.drawTable(ctx, W, H);
  this._geo = D.drawCase(ctx, CA.x + CA.w / 2, CA.y + CA.h / 2, p, this._s);
  D.drawPartsBox(ctx, PA.x, PA.y, PA.w, PA.h);
  var words = ['', '', '', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten'];
  D.drawTitle(ctx, TI.x, TI.y, TI.w, TI.h, req.title, req.difficulty + ' · ' + (words[p.pieces.length] || p.pieces.length) + ' pieces · ' + (/^[aeiou]/.test(p.shape) ? 'an ' : 'a ') + p.shape + ' tray');
  bmp._baseTexture.update(); this._bg = new Sprite(bmp); this.addChild(this._bg);
  var g = this._geo; this._ghost = new Sprite(new Bitmap(p.w * this._s + 4, p.h * this._s + 4)); this._ghost.x = g.x - 2; this._ghost.y = g.y - 2; this.addChild(this._ghost);
};

/**
 * The box: every piece gets a slot the size of the way it was dealt, packed in rows at the largest shared scale that
 * fits. A piece turned in the box keeps its slot and shrinks only if its new turn does not fit it.
 * ⛔ found by looking (2026-09-28): square slots sized for ANY turn left the box two thirds empty with the pieces at 0.4.
 */
Scene_Tray.prototype.layoutParts = function () {
  var PA = Scene_Tray.PARTS, p = this._p, s = this._s, pad = 16, n = p.pieces.length, i, ls, rows, innerW = PA.w - 28, innerH = PA.h - 28;
  for (ls = 1; ls >= 0.3; ls -= 0.02) {
    rows = []; var row = [], rw = 0, rh = 0, total = 0;
    for (i = 0; i < n; i++) { var sw = this._T[i].w * s * ls + pad, sh = this._T[i].h * s * ls + pad; if (rw + sw > innerW && row.length) { rows.push({ items: row, h: rh, w: rw }); total += rh; row = []; rw = 0; rh = 0; } row.push({ i: i, sw: sw, sh: sh }); rw += sw; rh = Math.max(rh, sh); }
    if (row.length) { rows.push({ items: row, h: rh, w: rw }); total += rh; }
    if (total <= innerH && rows.every(function (r2) { return r2.w <= innerW; })) break;
  }
  this._ls = ls; this._slots = []; var used = rows.reduce(function (a, r2) { return a + r2.h; }, 0), gapY = Math.max(0, (innerH - used) / (rows.length + 1)), y = PA.y + 14 + gapY;
  for (var k = 0; k < rows.length; k++) {
    var gapX = Math.max(0, (innerW - rows[k].w) / (rows[k].items.length + 1)), x = PA.x + 14 + gapX;
    for (var j = 0; j < rows[k].items.length; j++) { var it = rows[k].items[j]; this._slots[it.i] = { cx: x + it.sw / 2, cy: y + rows[k].h / 2, sw: it.sw, sh: it.sh }; x += it.sw + gapX; }
    y += rows[k].h + gapY;
  }
};

Scene_Tray.prototype.createPieces = function () {
  var p = this._p, s = this._s; this._pad = Math.ceil(s * 0.55);
  this._layer = new Sprite(); this.addChild(this._layer);
  this._sprites = [];
  for (var i = 0; i < p.pieces.length; i++) {
    var bw = 0, bh = 0; p.pieces[i].cells.forEach(function (c) { bw = Math.max(bw, c[0] + 1); bh = Math.max(bh, c[1] + 1); });
    var side = Math.ceil(Math.max(bw, bh) * s + this._pad * 2);
    var sp = new Sprite(new Bitmap(side, side)); sp._lift = -1; this._layer.addChild(sp); this._sprites.push(sp);
    this.paintPiece(i, 0.25);
  }
  this._top = new Sprite(); this.addChild(this._top);
};

Scene_Tray.prototype.createUi = function () {
  var D = this._d.draw, CD = Scene_Tray.CARD, S = Scene_Tray.STATUS, P = Scene_Tray.PLAQUES;
  var pb = new Bitmap(26, 30); D.drawPointer(pb.context, 26, 30); pb._baseTexture.update(); this._pointer = new Sprite(pb); this._pointer.anchor.x = 0.5; this._pointer.anchor.y = 1; this.addChild(this._pointer);
  this._card = new Sprite(new Bitmap(CD.w, CD.h)); this._card.x = CD.x; this._card.y = CD.y; this.addChild(this._card);
  this._status = new Sprite(new Bitmap(S.w, S.h)); this._status.x = S.x; this._status.y = S.y; this.addChild(this._status);
  this._plaques = new Sprite(new Bitmap(P.gap * 3 + P.w + 12, P.h + 12)); this._plaques.x = P.x - 6; this._plaques.y = P.y - 6; this.addChild(this._plaques);
  var bd = this._geo.board, sb = new Bitmap(140, bd.h); D.drawSheen(sb.context, 140, bd.h); sb._baseTexture.update();
  this._sheen = new Sprite(sb); this._sheen.blendMode = 1; this._sheen.visible = false; this._sheen.y = bd.y; this.addChild(this._sheen);   // PIXI.BLEND_MODES.ADD
  this._verdict = new Sprite(new Bitmap(Graphics.width, Graphics.height)); this._verdict.visible = false; this.addChild(this._verdict);
};

Scene_Tray.prototype.playSe = function (n) { if (n && typeof AudioManager !== 'undefined') AudioManager.playSe({ name: n, volume: 80, pitch: 100, pan: 0 }); };
Scene_Tray.prototype.woodName = function (i) { var W = this._d.draw.WOOD[this._p.pieces[i].wood]; return W ? W.name.toLowerCase() : 'wooden'; };

//---------------------------------------------------------------------------- redraws (only on change)

/** Repaint one piece in its current turn; lift is how far off the table it is (the shadow). */
Scene_Tray.prototype.paintPiece = function (i, lift) {
  var sp = this._sprites[i], b = sp.bitmap, pose = this._pose[i];
  b.context.clearRect(0, 0, b.width, b.height);
  this._d.draw.drawPiece(b.context, this._p.pieces[i], this._pad, this._pad, this._s, { rot: pose.rot, flip: pose.flip, shadow: lift });
  b._baseTexture.update(); sp._lift = lift;
};
/** Put a resting piece where it belongs: in the tray at full size, or in its slot in the box at the box's scale. */
Scene_Tray.prototype.placeSprite = function (i) {
  if (i === this._carry) return;
  var sp = this._sprites[i], pl = this._g.placed[i], s = this._s, T = this._T[i], pad = this._pad;
  if (pl) { sp.scale.x = sp.scale.y = 1; sp.x = this._geo.x + pl.x * s - pad; sp.y = this._geo.y + pl.y * s - pad; }
  else { var sl = this._slots[i], sc = Math.min(this._ls, (sl.sw - 8) / (T.w * s), (sl.sh - 8) / (T.h * s)); sp.scale.x = sp.scale.y = sc; sp.x = sl.cx - (T.w * s / 2 + pad) * sc; sp.y = sl.cy - (T.h * s / 2 + pad) * sc; }
};
/** Screen box of a resting piece's turned squares: {x, y, sc}. */
Scene_Tray.prototype.pieceBox = function (i) { var sp = this._sprites[i]; return { x: sp.x + this._pad * sp.scale.x, y: sp.y + this._pad * sp.scale.y, sc: sp.scale.x }; };
Scene_Tray.prototype.placePointer = function () {
  var show = this._mode === 'pick' && this._sel >= 0; this._pointer.visible = show; if (!show) return;
  var b = this.pieceBox(this._sel), T = this._T[this._sel]; this._pointer.x = b.x + T.w * this._s * b.sc / 2; this._pointer._baseY = b.y - 4; this._pointer.y = this._pointer._baseY;
};
Scene_Tray.prototype.refreshCard = function () {
  var g = this._g, placed = 0; for (var i = 0; i < g.placed.length; i++) if (g.placed[i]) placed++;
  var key = placed + '|' + g.moves + '|' + g.hints + '|' + this._hintsLeft; if (key === this._cardKey) return; this._cardKey = key;
  var CD = Scene_Tray.CARD; this._d.draw.drawCard(this._card.bitmap.context, CD.w, CD.h, { placed: placed, total: this._p.pieces.length, moves: g.moves, hints: g.hints, hintsLeft: this._hintsLeft }); this._card.bitmap._baseTexture.update();
};
Scene_Tray.prototype.plaqueStates = function () {
  var m = this._mode, holding = m === 'carry' || m === 'drag', loose = m === 'pick' && this._sel >= 0 && !this._g.placed[this._sel], live = m === 'pick' || holding;
  return [holding || loose ? 'idle' : 'off', holding || loose ? 'idle' : 'off', m === 'pick' && this._hintsLeft > 0 ? 'idle' : 'off', live ? 'idle' : 'off'];
};
Scene_Tray.prototype.refreshPlaques = function () {
  var st = this.plaqueStates(), key = st.join('|') + '|' + this._hover; if (key === this._plaqueKey) return; this._plaqueKey = key;
  var P = Scene_Tray.PLAQUES, b = this._plaques.bitmap, ctx = b.context; ctx.clearRect(0, 0, b.width, b.height);
  for (var k = 0; k < 4; k++) this._d.draw.drawPlaque(ctx, 6 + k * P.gap, 6, P.w, P.h, Scene_Tray.LABELS[k], st[k] === 'idle' && this._hover === k ? 'on' : st[k]);
  b._baseTexture.update();
};
Scene_Tray.prototype.setStatus = function (t) { if (t === this._statusText) return; this._statusText = t; var S = Scene_Tray.STATUS; this._d.draw.drawStatus(this._status.bitmap.context, S.w, S.h, t); this._status.bitmap._baseTexture.update(); };
/** Show where the held piece would land (only when the square it snaps to, its turn or the verdict changes). */
Scene_Tray.prototype.refreshGhost = function () {
  var sn = this._snap, i = this._carry, pose = i >= 0 ? this._pose[i] : null, key = sn.on && i >= 0 ? i + ',' + sn.x + ',' + sn.y + ',' + pose.rot + ',' + pose.flip + ',' + sn.fits : '';
  if (key === this._ghostKey) return; this._ghostKey = key;
  var b = this._ghost.bitmap; b.context.clearRect(0, 0, b.width, b.height);
  if (key) this._d.draw.drawGhost(b.context, this._T[i].cells, 2 + sn.x * this._s, 2 + sn.y * this._s, this._s, sn.fits);
  b._baseTexture.update();
};
Scene_Tray.prototype.setSnap = function (x, y) {
  // over the tray = at least half the piece's squares over the box (one row grazing the rim is still the table)
  var T = this._T[this._carry], p = this._p, cs = T.cells, inside = 0;
  for (var k = 0; k < cs.length; k++) { var cx = x + cs[k][0], cy = y + cs[k][1]; if (cx >= 0 && cy >= 0 && cx < p.w && cy < p.h) inside++; }
  var on = inside * 2 >= cs.length;
  this._snap.x = x; this._snap.y = y; this._snap.on = on; this._snap.fits = on && this._d.core.fits(p, this._g, this._carry, T.cells, x, y);
  this.refreshGhost();
};

//---------------------------------------------------------------------------- turning

/** Turn (dir +1 clockwise, -1 back) or flip a piece; `held` pieces keep their place over the tray. */
Scene_Tray.prototype.turnPiece = function (i, dir, flip) {
  var pose = this._pose[i]; if (flip) pose.flip = !pose.flip; else pose.rot = (pose.rot + dir + 4) & 3;
  this._T[i] = this._d.draw.turn(this._p.pieces[i].cells, pose.rot, pose.flip);
  this.paintPiece(i, i === this._carry ? 0.9 : 0.25); this.playSe(Tray.params.turnSe);
  if (i === this._carry) {
    var T = this._T[i];
    if (this._mode === 'carry') { this._cx = Math.max(0, Math.min(this._p.w - T.w, this._cx)); this._cy = Math.max(0, Math.min(this._p.h - T.h, this._cy)); this.carryMoved(); }
    else { this._gx = T.w * this._s / 2; this._gy = T.h * this._s / 2; this.dragMoved(true); }
  } else { this.placeSprite(i); this.placePointer(); }
};

//---------------------------------------------------------------------------- per frame

Scene_Tray.prototype.update = function () {
  Scene_Base.prototype.update.call(this);
  var m = this._mode;
  if (m === 'pick') this.updatePick();
  else if (m === 'carry') this.updateCarry();
  else if (m === 'drag') this.updateDrag();
  else if (m === 'polish') this.updatePolish();
  else if (m === 'reveal') { this._anim++; this._verdict.opacity = Math.min(255, this._anim * 11); if (this._anim >= 24) this._mode = 'done'; }
  else if (m === 'done') { if (Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered() || TouchInput.isCancelled()) this.leave(); }
  else if (m === 'leaving' && !this.isBusy()) { this._mode = 'gone'; this.popScene(); }
  if (this._pointer.visible) this._pointer.y = this._pointer._baseY + Math.sin(Graphics.frameCount * 0.12) * 3;
};

Scene_Tray.prototype.plaqueAt = function (x, y) {
  var P = Scene_Tray.PLAQUES; if (y < P.y || y >= P.y + P.h) return -1;
  for (var k = 0; k < 4; k++) if (x >= P.x + k * P.gap && x < P.x + k * P.gap + P.w) return k;
  return -1;
};
/** The resting piece under a screen point (the topmost), or -1. Tests the piece's own squares, not its box. */
Scene_Tray.prototype.pieceAt = function (x, y) {
  var s = this._s;
  for (var i = this._p.pieces.length - 1; i >= 0; i--) {
    if (i === this._carry) continue;
    var b = this.pieceBox(i), cs = this._T[i].cells, lx = Math.floor((x - b.x) / (s * b.sc)), ly = Math.floor((y - b.y) / (s * b.sc));
    for (var k = 0; k < cs.length; k++) if (cs[k][0] === lx && cs[k][1] === ly) return i;
  }
  return -1;
};

Scene_Tray.prototype.updatePick = function () {
  var n = this._p.pieces.length;
  if (Input.isRepeated('left') || Input.isRepeated('up')) { this._sel = (this._sel + n - 1) % n; this.placePointer(); this.refreshPlaques(); this.playSe(Tray.params.turnSe); }
  else if (Input.isRepeated('right') || Input.isRepeated('down')) { this._sel = (this._sel + 1) % n; this.placePointer(); this.refreshPlaques(); this.playSe(Tray.params.turnSe); }
  if (Input.isTriggered('ok')) { this.beginCarry(this._sel); return; }
  if (Input.isTriggered('pageup') || Input.isTriggered('pagedown') || Input.isTriggered('shift')) {
    if (this._g.placed[this._sel]) { this.setStatus('Pick it up first (OK), then turn it.'); return; }
    this.turnPiece(this._sel, Input.isTriggered('pageup') ? -1 : 1, Input.isTriggered('shift')); return;
  }
  if (Input.isTriggered('tab')) { this.hint(); return; }
  if (Input.isTriggered('cancel') || TouchInput.isCancelled()) { this.leave(); return; }
  var tx = TouchInput.x, ty = TouchInput.y, hover = this.plaqueAt(tx, ty);
  if (hover !== this._hover) { this._hover = hover; this.refreshPlaques(); }
  if (TouchInput.isTriggered()) {
    if (hover >= 0) { this.pressPlaque(hover); return; }
    var i = this.pieceAt(tx, ty); if (i >= 0) this.beginDrag(i, tx, ty);
  }
};
Scene_Tray.prototype.pressPlaque = function (k) {
  var st = this.plaqueStates(); if (st[k] === 'off') { this.playSe(Tray.params.refuseSe); return; }
  var i = this._carry >= 0 ? this._carry : this._sel;
  if (k === 0) this.turnPiece(i, 1, false); else if (k === 1) this.turnPiece(i, 0, true); else if (k === 2) this.hint(); else this.leave();
};

/** Keyboard: lift a piece and hold it over the tray. */
Scene_Tray.prototype.beginCarry = function (i) {
  var pl = this._g.placed[i], T = this._T[i], p = this._p;
  this._from = pl ? { x: pl.x, y: pl.y } : null;
  if (pl) this._d.core.lift(p, this._g, i);
  this._carry = i; this._mode = 'carry';
  this._cx = pl ? pl.x : Math.max(0, Math.floor((p.w - T.w) / 2)); this._cy = pl ? pl.y : Math.max(0, Math.floor((p.h - T.h) / 2));
  this._top.addChild(this._sprites[i]); this.paintPiece(i, 0.9); this.playSe(Tray.params.pickSe);
  this.carryMoved(); this.placePointer(); this.refreshPlaques(); this.refreshCard();
  this.setStatus('Arrows move it, Q and W turn it, Shift flips it. OK puts it down.');
};
Scene_Tray.prototype.carryMoved = function () {
  var sp = this._sprites[this._carry]; sp.scale.x = sp.scale.y = 1;
  sp.x = this._geo.x + this._cx * this._s - this._pad; sp.y = this._geo.y + this._cy * this._s - this._pad - 6;
  this.setSnap(this._cx, this._cy);
};
Scene_Tray.prototype.updateCarry = function () {
  var T = this._T[this._carry], p = this._p, moved = false;
  if (Input.isRepeated('left') && this._cx > 0) { this._cx--; moved = true; }
  else if (Input.isRepeated('right') && this._cx < p.w - T.w) { this._cx++; moved = true; }
  if (Input.isRepeated('up') && this._cy > 0) { this._cy--; moved = true; }
  else if (Input.isRepeated('down') && this._cy < p.h - T.h) { this._cy++; moved = true; }
  if (moved) this.carryMoved();
  if (Input.isTriggered('pageup')) { this.turnPiece(this._carry, -1, false); return; }
  if (Input.isTriggered('pagedown')) { this.turnPiece(this._carry, 1, false); return; }
  if (Input.isTriggered('shift')) { this.turnPiece(this._carry, 0, true); return; }
  if (Input.isTriggered('ok')) { this.drop(this._cx, this._cy); return; }
  if (Input.isTriggered('cancel') || TouchInput.isCancelled()) { this.putBack(); return; }
  var tx = TouchInput.x, ty = TouchInput.y, hover = this.plaqueAt(tx, ty);
  if (hover !== this._hover) { this._hover = hover; this.refreshPlaques(); }
  if (TouchInput.isTriggered() && hover >= 0) this.pressPlaque(hover);
};

/** Mouse and touch: pick a piece up where it was grabbed and let it follow the pointer. */
Scene_Tray.prototype.beginDrag = function (i, x, y) {
  var b = this.pieceBox(i), pl = this._g.placed[i];
  this._gx = (x - b.x) / b.sc; this._gy = (y - b.y) / b.sc;
  this._from = pl ? { x: pl.x, y: pl.y } : null;
  if (pl) this._d.core.lift(this._p, this._g, i);
  this._carry = i; this._sel = i; this._mode = 'drag';
  this._top.addChild(this._sprites[i]); this.paintPiece(i, 0.9); this.playSe(Tray.params.pickSe);
  this.dragMoved(true); this.placePointer(); this.refreshPlaques(); this.refreshCard();
  this.setStatus('Drop it on the tray. Right button or wheel turns it.');
};
Scene_Tray.prototype.dragMoved = function (force) {
  var sp = this._sprites[this._carry], tx = TouchInput.x, ty = TouchInput.y, s = this._s;
  if (!force && tx === this._lastTx && ty === this._lastTy) return; this._lastTx = tx; this._lastTy = ty;
  sp.scale.x = sp.scale.y = 1; sp.x = tx - this._gx - this._pad; sp.y = ty - this._gy - this._pad;
  this.setSnap(Math.round((tx - this._gx - this._geo.x) / s), Math.round((ty - this._gy - this._geo.y) / s));
};
Scene_Tray.prototype.updateDrag = function () {
  if (TouchInput.isCancelled() || Input.isTriggered('pagedown')) { this.turnPiece(this._carry, 1, false); return; }
  if (Input.isTriggered('pageup')) { this.turnPiece(this._carry, -1, false); return; }
  if (Input.isTriggered('shift')) { this.turnPiece(this._carry, 0, true); return; }
  if (TouchInput.wheelY) { this.turnPiece(this._carry, TouchInput.wheelY > 0 ? 1 : -1, false); return; }
  if (TouchInput.isPressed()) { this.dragMoved(false); return; }
  // released
  if (this._snap.on && this._snap.fits) this.drop(this._snap.x, this._snap.y);
  else this.toBox(this._snap.on ? 'It does not fit there: back in the box.' : 'Back in the box.');
};

/** Put the held piece down at (x, y) if it fits; otherwise say so and keep holding it (keyboard) or box it (mouse). */
Scene_Tray.prototype.drop = function (x, y) {
  var i = this._carry, p = this._p, T = this._T[i];
  if (!this._d.core.place(p, this._g, i, T.cells, x, y)) {
    this.playSe(Tray.params.refuseSe); this.setStatus('It does not fit there.');
    if (this._mode === 'drag') this.toBox('It does not fit there: back in the box.');
    return false;
  }
  this.settle(i); this.playSe(Tray.params.dropSe);
  if (this._g.done) { this.beginPolish(); return true; }
  this.setStatus('Fit every piece into the tray.');
  return true;
};
/** The held piece goes back where it came from (keyboard cancel). */
Scene_Tray.prototype.putBack = function () {
  var i = this._carry, f = this._from;
  if (f) { this._d.core.place(this._p, this._g, i, this._T[i].cells, f.x, f.y); this._g.moves--; }
  this.settle(i); this.setStatus(f ? 'Put back where it was.' : 'Back in the box.');
};
Scene_Tray.prototype.toBox = function (msg) { var i = this._carry; this.settle(i); this.playSe(Tray.params.dropSe); this.setStatus(msg); };
/** End a hold: the piece rests (in the tray or its slot), the ghost clears, back to choosing. */
Scene_Tray.prototype.settle = function (i) {
  this._carry = -1; this._from = null; this._snap.on = false; this._mode = 'pick'; this._sel = i;
  this._layer.addChild(this._sprites[i]); this.paintPiece(i, this._g.placed[i] ? 0 : 0.25); this.placeSprite(i);
  this.refreshGhost(); this.placePointer(); this.refreshPlaques(); this.refreshCard();
};

/** A hint: a piece of a solution that keeps what the player has placed, or the placed piece that has to come out. */
Scene_Tray.prototype.hint = function () {
  if (this._mode !== 'pick') return;
  if (this._hintsLeft <= 0) { this.playSe(Tray.params.refuseSe); this.setStatus('No hints left.'); return; }
  var C = this._d.core, D = this._d.draw, p = this._p, g = this._g, h = C.hint(p, g);
  if (h.place) {
    var i = h.place.piece, pose = D.poseOf(p.pieces[i].cells, h.place.cells);
    this._pose[i] = pose; this._T[i] = D.turn(p.pieces[i].cells, pose.rot, pose.flip);
    C.place(p, g, i, this._T[i].cells, h.place.x, h.place.y); g.moves--;
    this.settle(i); this.setStatus('Hint: the ' + this.woodName(i) + ' piece goes here.');
  } else if (h.lift >= 0) {
    var j = h.lift; C.lift(p, g, j); this.settle(j); this.setStatus('The ' + this.woodName(j) + ' piece cannot stay where it was: it is back in the box.');
  } else { this.setStatus('No hint found.'); return; }
  g.hints++; this._hintsLeft--; this.playSe(Tray.params.hintSe); this.refreshCard(); this.refreshPlaques();
  if (g.done) this.beginPolish();
};

//---------------------------------------------------------------------------- the finished panel

Scene_Tray.prototype.beginPolish = function () {
  this._mode = 'polish'; this._anim = 0; this._pointer.visible = false; this.playSe(Tray.params.solveSe); this.refreshPlaques();
  this.setStatus('The tray is full.'); this._sheen.visible = true; this._sheen.x = this._geo.board.x - 140; this._sheen.alpha = 1;
};
Scene_Tray.prototype.updatePolish = function () {
  var a = ++this._anim, bd = this._geo.board;
  this._sheen.x = bd.x - 140 + (bd.w + 140) * Math.min(1, a / 40);
  if (a >= 40) { this._sheen.visible = false; this.finish(); }
};
Scene_Tray.prototype.finish = function () {
  var req = this._req, g = this._g, p = this._p, rec = Tray.record(req.key);
  rec.times = (rec.times || 0) + 1; if (!rec.bestMoves || g.moves < rec.bestMoves) rec.bestMoves = g.moves; rec.hints = g.hints;
  var D = this._d.core.DIFFS[p.difficulty], exact = p.graded && p.ways >= 1 && p.ways <= D.ways;
  Tray.lastResult = { moves: g.moves, hints: g.hints, difficulty: p.difficulty, shape: p.shape, pieces: p.pieces.length, ways: exact ? p.ways : -1 };
  if (req.variableId > 0 && typeof $gameVariables !== 'undefined') $gameVariables.setValue(req.variableId, g.moves);
  if (req.hintVariableId > 0 && typeof $gameVariables !== 'undefined') $gameVariables.setValue(req.hintVariableId, g.hints);
  if (req.switchId > 0 && typeof $gameSwitches !== 'undefined') $gameSwitches.setValue(req.switchId, true);
  var ways = exact ? (p.ways === 1 ? 'This tray fills only one way.' : 'This tray fills ' + p.ways + ' different ways.') : 'This tray fills more than ' + D.ways + ' different ways.';
  var info = { title: 'Solved in ' + g.moves + (g.moves === 1 ? ' move' : ' moves') + (g.hints ? ', ' + g.hints + (g.hints === 1 ? ' hint' : ' hints') : ', no hints'), sub: ways, foot: 'Press OK to leave the table.' };
  var b = this._verdict.bitmap; this._d.draw.drawVerdict(b.context, b.width, b.height, p, g.placed, info); b._baseTexture.update();
  this._verdictInfo = info; this._verdict.opacity = 0; this._verdict.visible = true; this._anim = 0; this._mode = 'reveal'; this.setStatus('');
};

Scene_Tray.prototype.leave = function () {
  if (this._mode === 'leaving' || this._mode === 'gone') return;
  var req = this._req;
  if (!this._g.done) {
    if (req.variableId > 0 && typeof $gameVariables !== 'undefined') $gameVariables.setValue(req.variableId, 0);
    if (req.switchId > 0 && typeof $gameSwitches !== 'undefined') $gameSwitches.setValue(req.switchId, false);
  }
  this._mode = 'leaving'; this._pointer.visible = false; this.startFadeOut(this.fadeSpeed(), false);
};
