//=============================================================================
// TrayDraw.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Tray drawing - the marquetry: ten woods with their own
 * grain, inlaid motifs, stringing, the shaped tray and the finished panel.
 * Place BELOW TrayCore and ABOVE Tray.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * Everything Tray shows is drawn here at runtime with the canvas: no image
 * files are loaded. No parameters or commands of its own; Tray.js is the file
 * you configure. Must be installed between TrayCore.js and Tray.js.
 *
 * Every piece is cut from one of ten woods (walnut, maple, cherry, oak,
 * ebony, ash, rosewood, yew, olive, holly), each with its own colour and
 * figure, and carries an inlaid motif in brass, mother-of-pearl, holly or
 * ebony, with a line of stringing run just inside its edge. The grain and
 * the inlay turn and flip with the piece, as they would on a real one.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var TrayDraw = (function () {
  'use strict';

  var FACE = '"Palatino Linotype", "Book Antiqua", Palatino, "Georgia", serif';
  function rng(seed) { var a = seed >>> 0; return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function rr(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
  function fitText(ctx, text, maxW, size, style) { ctx.font = (style || 'bold') + ' ' + size + 'px ' + FACE; while (size > 9 && ctx.measureText(text).width > maxW) { size--; ctx.font = (style || 'bold') + ' ' + size + 'px ' + FACE; } return size; }
  function hex(c) { var n = parseInt(c.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  function rgba(c, a) { var h = hex(c); return 'rgba(' + h[0] + ',' + h[1] + ',' + h[2] + ',' + a + ')'; }
  function mix(a, b, t) { var x = hex(a), y = hex(b); return 'rgb(' + Math.round(x[0] + (y[0] - x[0]) * t) + ',' + Math.round(x[1] + (y[1] - x[1]) * t) + ',' + Math.round(x[2] + (y[2] - x[2]) * t) + ')'; }

  /**
   * The ten woods. base/light/dark are the board's colours, streak the grain lines, figure the pattern the species is
   * known for, lum how light it reads (picks the inlay material that shows against it).
   */
  var WOOD = {
    walnut: { name: 'Walnut', base: '#5a3a22', light: '#7a5334', dark: '#35200f', streak: '#24140a', figure: 'cathedral', pores: 0.8, lum: 0.28 },
    maple: { name: 'Maple', base: '#e3cc9c', light: '#f2e2bb', dark: '#c9ad78', streak: '#b8955c', figure: 'curl', pores: 0.1, lum: 0.82 },
    cherry: { name: 'Cherry', base: '#a8583a', light: '#c4724d', dark: '#7e3c24', streak: '#5e2a16', figure: 'cathedral', pores: 0.25, lum: 0.45 },
    oak: { name: 'Oak', base: '#b58c58', light: '#cda676', dark: '#8e6a3c', streak: '#6a4a24', figure: 'ray', pores: 1, lum: 0.6 },
    ebony: { name: 'Ebony', base: '#241c18', light: '#3a2e26', dark: '#120c0a', streak: '#4a3c30', figure: 'fine', pores: 0.05, lum: 0.1 },
    ash: { name: 'Ash', base: '#d6c09a', light: '#e8d6b2', dark: '#b39a70', streak: '#8a7048', figure: 'cathedral', pores: 0.9, lum: 0.75 },
    rosewood: { name: 'Rosewood', base: '#5c2a26', light: '#7a3c34', dark: '#361412', streak: '#1c0806', figure: 'streak', pores: 0.5, lum: 0.22 },
    yew: { name: 'Yew', base: '#c47a44', light: '#dc9a62', dark: '#9a5428', streak: '#7a3c18', figure: 'wild', pores: 0.1, lum: 0.55 },
    olive: { name: 'Olive', base: '#b8a068', light: '#d2bc84', dark: '#8a7440', streak: '#3e3014', figure: 'wild', pores: 0.2, lum: 0.62 },
    holly: { name: 'Holly', base: '#ede4d0', light: '#f8f2e4', dark: '#d6ccb4', streak: '#bfb298', figure: 'fine', pores: 0.05, lum: 0.92 },
  };
  var MATERIAL = {
    brass: { name: 'brass', stops: ['#fbe7a4', '#d9aa4a', '#9a6a1c'], edge: '#5a3a08', lum: 0.7 },
    pearl: { name: 'mother-of-pearl', stops: ['#fbfaf6', '#dfeaf2', '#f3dfe9', '#e8e2cc'], edge: '#7a7468', lum: 0.92 },
    holly: { name: 'holly', stops: ['#fbf6ea', '#ece2c8'], edge: '#8a7a5a', lum: 0.9 },
    ebony: { name: 'ebony', stops: ['#3a302a', '#120c0a'], edge: '#000000', lum: 0.08 },
  };
  /** The inlay that shows best against a wood: pale materials on dark woods, ebony on pale ones, brass in the middle. */
  function materialFor(wood, id) {
    var L = (WOOD[wood] || WOOD.oak).lum;
    if (L < 0.35) return ['brass', 'pearl', 'holly'][id % 3];
    if (L > 0.72) return ['ebony', 'brass'][id % 2];
    return ['brass', 'ebony', 'holly'][id % 3];
  }

  //------------------------------------------------------------------------ geometry

  /** Turn (quarter turns clockwise) and flip (mirror left-right, first) a piece. Returns its cells and the matrix that
   *  carries the piece's own frame (cell units) into the turned one: [a, b, c, d, e, f] as canvas transform() takes. */
  function turn(cells, rot, flip) {
    var bw = 0, bh = 0, k;
    for (k = 0; k < cells.length; k++) { if (cells[k][0] + 1 > bw) bw = cells[k][0] + 1; if (cells[k][1] + 1 > bh) bh = cells[k][1] + 1; }
    var a = 1, b = 0, c = 0, d = 1;
    if (flip) a = -1;
    for (k = 0; k < (rot & 3); k++) { var na = -b, nb = a, nc = -d, nd = c; a = na; b = nb; c = nc; d = nd; }   // (x, y) -> (-y, x) on screen
    var xs = [0, bw * a, bh * c, bw * a + bh * c], ys = [0, bw * b, bh * d, bw * b + bh * d];
    var e = -Math.min.apply(null, xs), f = -Math.min.apply(null, ys);
    var out = [];
    for (k = 0; k < cells.length; k++) { var cx = cells[k][0] + 0.5, cy = cells[k][1] + 0.5; out.push([Math.floor(a * cx + c * cy + e), Math.floor(b * cx + d * cy + f)]); }
    out.sort(function (p, q) { return p[1] - q[1] || p[0] - q[0]; });
    return { cells: out, m: [a, b, c, d, e, f], w: (rot & 1) ? bh : bw, h: (rot & 1) ? bw : bh };
  }
  /** The (rot, flip) that turns `cells` into `target` (both as cell lists), or null. */
  function poseOf(cells, target) {
    var key = function (cs) { return cs.slice().sort(function (p, q) { return p[1] - q[1] || p[0] - q[0]; }).map(function (p) { return p[0] + ',' + p[1]; }).join(';'); };
    var want = key(target);
    for (var f = 0; f < 2; f++) for (var r = 0; r < 4; r++) if (key(turn(cells, r, !!f).cells) === want) return { rot: r, flip: !!f };
    return null;
  }

  /** The outline of a set of cells: closed loops of corner points (cell units), clockwise on screen. */
  function outline(cells) {
    var edges = {}, k;
    function add(x1, y1, x2, y2) { var f = x1 + ',' + y1 + '>' + x2 + ',' + y2, r = x2 + ',' + y2 + '>' + x1 + ',' + y1; if (edges[r]) delete edges[r]; else edges[f] = [x1, y1, x2, y2]; }
    for (k = 0; k < cells.length; k++) { var x = cells[k][0], y = cells[k][1]; add(x, y, x + 1, y); add(x + 1, y, x + 1, y + 1); add(x + 1, y + 1, x, y + 1); add(x, y + 1, x, y); }
    var from = {}, id, loops = [];
    for (id in edges) { var e = edges[id], s = e[0] + ',' + e[1]; (from[s] = from[s] || []).push(e); }
    var left = Object.keys(edges).length;
    while (left > 0) {
      var start = null; for (var s0 in from) if (from[s0].length) { start = from[s0][0]; break; }
      if (!start) break;
      var loop = [], cur = start, guard = 0;
      while (cur && guard++ < 4000) {
        var list = from[cur[0] + ',' + cur[1]], at = list.indexOf(cur); list.splice(at, 1); left--;
        loop.push([cur[0], cur[1]]);
        var nx = from[cur[2] + ',' + cur[3]];
        if (!nx || !nx.length) break;
        // at a pinch, take the right-most turn so each loop stays simple
        var dx = cur[2] - cur[0], dy = cur[3] - cur[1], pickE = nx[0];
        if (nx.length > 1) for (var q = 0; q < nx.length; q++) { var ex = nx[q][2] - nx[q][0], ey = nx[q][3] - nx[q][1]; if (dx * ey - dy * ex > 0) pickE = nx[q]; }
        cur = pickE;
        if (cur === start) break;
      }
      // drop the points in the middle of a straight run
      var clean = [];
      for (k = 0; k < loop.length; k++) { var p = loop[(k + loop.length - 1) % loop.length], c = loop[k], n = loop[(k + 1) % loop.length]; if ((c[0] - p[0]) * (n[1] - c[1]) - (c[1] - p[1]) * (n[0] - c[0]) !== 0) clean.push(c); }
      if (clean.length >= 4) loops.push(clean);
    }
    return loops;
  }
  /** Move every edge of a clockwise right-angled loop inward by d (exact for right angles, convex and reflex). */
  function inset(loop, d) {
    var out = [], n = loop.length;
    for (var i = 0; i < n; i++) {
      var p = loop[(i + n - 1) % n], c = loop[i], q = loop[(i + 1) % n];
      var d1x = Math.sign(c[0] - p[0]), d1y = Math.sign(c[1] - p[1]), d2x = Math.sign(q[0] - c[0]), d2y = Math.sign(q[1] - c[1]);
      out.push([c[0] + d * (-d1y + -d2y), c[1] + d * (d1x + d2x)]);
    }
    return out;
  }
  function loopPath(ctx, loop, s, ox, oy, r) {
    var n = loop.length;
    if (!r) { ctx.moveTo(ox + loop[0][0] * s, oy + loop[0][1] * s); for (var i = 1; i < n; i++) ctx.lineTo(ox + loop[i][0] * s, oy + loop[i][1] * s); ctx.closePath(); return; }
    var m0 = [(loop[n - 1][0] + loop[0][0]) / 2, (loop[n - 1][1] + loop[0][1]) / 2];
    ctx.moveTo(ox + m0[0] * s, oy + m0[1] * s);
    for (var j = 0; j < n; j++) { var c = loop[j], nx = loop[(j + 1) % n], mx = (c[0] + nx[0]) / 2, my = (c[1] + nx[1]) / 2; ctx.arcTo(ox + c[0] * s, oy + c[1] * s, ox + mx * s, oy + my * s, r); }
    ctx.closePath();
  }
  /** The cell nearest the piece's centre of mass: where its inlay sits. */
  function heartCell(cells) {
    var sx = 0, sy = 0, k, best = 0, bd = Infinity;
    for (k = 0; k < cells.length; k++) { sx += cells[k][0] + 0.5; sy += cells[k][1] + 0.5; }
    sx /= cells.length; sy /= cells.length;
    for (k = 0; k < cells.length; k++) { var d = Math.pow(cells[k][0] + 0.5 - sx, 2) + Math.pow(cells[k][1] + 0.5 - sy, 2); if (d < bd - 1e-9) { bd = d; best = k; } }
    return cells[best];
  }

  //------------------------------------------------------------------------ the wood

  /**
   * Grain over a W x H board in the board's own frame, running along x. Species figure: cathedral arches (flat-sawn),
   * curl (maple's fiddleback bands), ray (oak's flecks), streak (rosewood's dark lines), wild (olive and yew), fine.
   */
  function drawGrain(ctx, wood, seed, W, H) {
    var WD = WOOD[wood] || WOOD.oak, r = rng(seed), i, x, y;
    var g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, WD.light); g.addColorStop(0.45 + r() * 0.2, WD.base); g.addColorStop(1, WD.dark);
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    // broad colour drifts across the board
    for (i = 0; i < 4; i++) { var by = r() * H, bh = H * (0.15 + r() * 0.3); ctx.fillStyle = rgba(r() < 0.5 ? WD.light : WD.dark, 0.18 + r() * 0.18); ctx.fillRect(0, by - bh / 2, W, bh); }
    // ⛔ found by looking (2026-09-28), twice: first amp 0.09 H at 5 waves drew olive and yew as a crackle net; then, in
    // the engine, EVERY wood showed lines crossing each other, because each line took its own phase. Grain lines in a
    // board run side by side: they share ONE warp (phase varying slowly with height) and differ only by a small jitter.
    var lines = Math.max(10, Math.round(H / 3.2)), wild = WD.figure === 'wild', amp = wild ? H * 0.12 : H * 0.035, freq = (wild ? 1.1 : 1.6) / W;
    var P1 = r() * 6.28, P2 = r() * 6.28, k1 = (r() - 0.5) * 0.05, k2 = (r() - 0.5) * 0.08;
    ctx.lineCap = 'round';
    for (i = 0; i < lines; i++) {
      var y0 = (i + r() * 0.8) * H / lines, phj = r() * 6.28, aj = amp * 0.1, lw = 0.5 + r() * (WD.figure === 'streak' ? 2.6 : 1.4);
      ctx.strokeStyle = rgba(WD.streak, WD.figure === 'fine' ? 0.12 + r() * 0.12 : 0.14 + r() * 0.3); ctx.lineWidth = lw;
      ctx.beginPath();
      for (x = -6; x <= W + 6; x += 6) { y = y0 + amp * Math.sin(x * freq * 6.28 + P1 + y0 * k1) + amp * 0.35 * Math.sin(x * freq * 14 + P2 + y0 * k2) + aj * Math.sin(x * freq * 31 + phj); if (x === -6) ctx.moveTo(x, y); else ctx.lineTo(x, y); }
      ctx.stroke();
    }
    if (WD.figure === 'cathedral') {
      // nested arches: the flat-sawn heart of the board
      var cx = W * (0.25 + r() * 0.5), cy = H * (0.3 + r() * 0.4), rings = 5 + Math.floor(r() * 4);
      for (i = 0; i < rings; i++) {
        var rw = W * (0.1 + i * 0.09), rh = H * (0.06 + i * 0.05);
        ctx.strokeStyle = rgba(i % 2 ? WD.dark : WD.streak, 0.28); ctx.lineWidth = 1 + (i % 2);
        ctx.beginPath(); ctx.moveTo(-10, cy - rh); ctx.bezierCurveTo(cx - rw, cy - rh, cx - rw * 0.6, cy + rh * 0.2, cx, cy + rh * 0.25); ctx.bezierCurveTo(cx + rw * 0.6, cy + rh * 0.2, cx + rw, cy - rh, W + 10, cy - rh); ctx.stroke();
      }
    } else if (WD.figure === 'curl') {
      // fiddleback: bands across the grain that catch the light
      for (x = r() * 10; x < W; x += 5 + r() * 7) { var gb = ctx.createLinearGradient(x, 0, x + 5, 0); gb.addColorStop(0, rgba(WD.light, 0)); gb.addColorStop(0.5, rgba(r() < 0.5 ? WD.light : WD.dark, 0.35)); gb.addColorStop(1, rgba(WD.light, 0)); ctx.fillStyle = gb; ctx.fillRect(x, 0, 5, H); }
    } else if (WD.figure === 'ray') {
      // oak's silver flecks, long with the grain
      for (i = 0; i < W * H / 260; i++) { var fx = r() * W, fy = r() * H, fl = 3 + r() * 9; ctx.fillStyle = rgba('#f4dcb0', 0.22 + r() * 0.25); ctx.beginPath(); ctx.ellipse(fx, fy, fl, 0.8 + r() * 1.2, (r() - 0.5) * 0.2, 0, 6.2832); ctx.fill(); }
    } else if (WD.figure === 'wild') {
      // knots and swirls
      var knots = 1 + Math.floor(r() * 2);
      for (i = 0; i < knots; i++) { var kx = r() * W, ky = r() * H; for (var j = 0; j < 6; j++) { ctx.strokeStyle = rgba(WD.streak, 0.35 - j * 0.04); ctx.lineWidth = 1.2; ctx.beginPath(); ctx.ellipse(kx, ky, 2 + j * 3.2, 1 + j * 1.6, 0, 0, 6.2832); ctx.stroke(); } ctx.fillStyle = rgba(WD.streak, 0.6); ctx.beginPath(); ctx.ellipse(kx, ky, 2, 1.2, 0, 0, 6.2832); ctx.fill(); }
    }
    // pores: short dark ticks along the grain
    var pores = Math.round(W * H / 30 * WD.pores);
    ctx.fillStyle = rgba(WD.streak, 0.35);
    for (i = 0; i < pores; i++) ctx.fillRect(r() * W, r() * H, 1 + r() * 2.5, 0.8);
  }

  //------------------------------------------------------------------------ inlay motifs

  var MOTIFS = ['star', 'lozenge', 'rosette', 'bars', 'chevron', 'dot', 'ring', 'cross', 'leaf', 'wave'];
  /** One inlaid motif of size s centred on (0, 0), filled in a material. */
  function drawMotif(ctx, motif, s, matName) {
    var M = MATERIAL[matName] || MATERIAL.brass, i, a;
    var g = ctx.createLinearGradient(-s / 2, -s / 2, s / 2, s / 2);
    for (i = 0; i < M.stops.length; i++) g.addColorStop(i / (M.stops.length - 1), M.stops[i]);
    ctx.beginPath();
    var h = s / 2;
    if (motif === 'star') { for (i = 0; i < 16; i++) { a = i * Math.PI / 8 - Math.PI / 2; var rad = i % 2 ? h * (i % 4 === 1 ? 0.3 : 0.42) : (i % 4 === 0 ? h : h * 0.62); ctx.lineTo(Math.cos(a) * rad, Math.sin(a) * rad); } ctx.closePath(); }
    else if (motif === 'lozenge') { ctx.moveTo(0, -h); ctx.lineTo(h * 0.62, 0); ctx.lineTo(0, h); ctx.lineTo(-h * 0.62, 0); ctx.closePath(); ctx.moveTo(0, -h * 0.45); ctx.lineTo(-h * 0.26, 0); ctx.lineTo(0, h * 0.45); ctx.lineTo(h * 0.26, 0); ctx.closePath(); }
    else if (motif === 'rosette') { for (i = 0; i < 6; i++) { a = i * Math.PI / 3; ctx.moveTo(0, 0); ctx.ellipse(Math.cos(a) * h * 0.52, Math.sin(a) * h * 0.52, h * 0.46, h * 0.2, a, 0, 6.2832); } ctx.moveTo(h * 0.2, 0); ctx.arc(0, 0, h * 0.2, 0, 6.2832); }
    else if (motif === 'bars') { for (i = -1; i <= 1; i++) { ctx.rect(-h * 0.8, i * h * 0.5 - h * 0.13, h * 1.6, h * 0.26); } }
    else if (motif === 'chevron') { for (i = 0; i < 2; i++) { var y0 = -h * 0.55 + i * h * 0.7; ctx.moveTo(-h * 0.85, y0); ctx.lineTo(0, y0 + h * 0.5); ctx.lineTo(h * 0.85, y0); ctx.lineTo(h * 0.85, y0 + h * 0.3); ctx.lineTo(0, y0 + h * 0.8); ctx.lineTo(-h * 0.85, y0 + h * 0.3); ctx.closePath(); } }
    else if (motif === 'dot') { ctx.arc(0, 0, h * 0.34, 0, 6.2832); for (i = 0; i < 8; i++) { a = i * Math.PI / 4; ctx.moveTo(Math.cos(a) * h * 0.78 + h * 0.1, Math.sin(a) * h * 0.78); ctx.arc(Math.cos(a) * h * 0.78, Math.sin(a) * h * 0.78, h * 0.1, 0, 6.2832); } }
    else if (motif === 'ring') { ctx.arc(0, 0, h * 0.86, 0, 6.2832); ctx.moveTo(h * 0.58, 0); ctx.arc(0, 0, h * 0.58, 0, 6.2832, true); ctx.moveTo(h * 0.22, 0); ctx.arc(0, 0, h * 0.22, 0, 6.2832); }
    else if (motif === 'cross') { for (i = 0; i < 4; i++) { a = i * Math.PI / 2; var c = Math.cos(a), sn = Math.sin(a); ctx.moveTo(c * h * 0.15, sn * h * 0.15); ctx.lineTo(c * h * 0.9 - sn * h * 0.42, sn * h * 0.9 + c * h * 0.42); ctx.lineTo(c * h * 0.72, sn * h * 0.72); ctx.lineTo(c * h * 0.9 + sn * h * 0.42, sn * h * 0.9 - c * h * 0.42); ctx.closePath(); } }
    else if (motif === 'leaf') { ctx.moveTo(0, -h * 0.95); ctx.bezierCurveTo(h * 0.75, -h * 0.4, h * 0.6, h * 0.5, 0, h * 0.8); ctx.bezierCurveTo(-h * 0.6, h * 0.5, -h * 0.75, -h * 0.4, 0, -h * 0.95); ctx.closePath(); }
    else { ctx.moveTo(-h * 0.9, -h * 0.1); for (i = 0; i <= 12; i++) { var xx = -h * 0.9 + i * h * 0.15; ctx.lineTo(xx, -h * 0.1 + Math.sin(i * 0.9) * h * 0.3 - h * 0.12); } for (i = 12; i >= 0; i--) { var x2 = -h * 0.9 + i * h * 0.15; ctx.lineTo(x2, -h * 0.1 + Math.sin(i * 0.9) * h * 0.3 + h * 0.2); } ctx.closePath(); }
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.save(); ctx.translate(0.8, 1); ctx.fill('evenodd'); ctx.restore();   // the cut the inlay sits in
    ctx.fillStyle = g; ctx.fill('evenodd');
    ctx.strokeStyle = rgba(M.edge, 0.85); ctx.lineWidth = Math.max(0.7, s / 44); ctx.stroke();
    if (motif === 'leaf') { ctx.beginPath(); ctx.moveTo(0, -h * 0.8); ctx.lineTo(0, h * 0.75); for (i = 0; i < 3; i++) { var vy = -h * 0.35 + i * h * 0.35; ctx.moveTo(0, vy + h * 0.15); ctx.lineTo(h * 0.32, vy - h * 0.05); ctx.moveTo(0, vy + h * 0.15); ctx.lineTo(-h * 0.32, vy - h * 0.05); } ctx.stroke(); }
    if (matName === 'pearl') { var gl = ctx.createRadialGradient(-h * 0.3, -h * 0.3, 0, 0, 0, h); gl.addColorStop(0, 'rgba(255,255,255,0.5)'); gl.addColorStop(0.5, 'rgba(180,220,255,0.12)'); gl.addColorStop(1, 'rgba(255,190,230,0.1)'); ctx.fillStyle = gl; ctx.fill('evenodd'); }
  }

  //------------------------------------------------------------------------ a piece

  /**
   * One marquetry piece: its wood with the grain running along its own length, a line of stringing inset from its
   * edge, its inlay on its heart cell, bevelled edges lit from the top left, a varnish sheen. Grain and inlay turn and
   * flip with the piece; the light does not. Draws with the turned piece's top-left at (ox, oy), squares of size s.
   * @param {object} opt {rot, flip, shadow: 0..1 (how far off the table), glow: highlight colour or null, scale-free}
   */
  function drawPiece(ctx, piece, ox, oy, s, opt) {
    opt = opt || {};
    var T = turn(piece.cells, opt.rot || 0, !!opt.flip), loops = outline(T.cells), loop = loops[0], rad = Math.max(1.5, s * 0.1);
    var mat = materialFor(piece.wood, piece.id), seed = (piece.id + 1) * 7919 + (piece.seed || 0);
    ctx.save();
    // shadow on the table: soft, further when lifted
    var lift = opt.shadow == null ? 0.25 : opt.shadow;
    if (lift > 0) { ctx.save(); ctx.shadowColor = 'rgba(0,0,0,' + (0.45 + lift * 0.2) + ')'; ctx.shadowBlur = 4 + lift * 16; ctx.shadowOffsetX = 2 + lift * 8; ctx.shadowOffsetY = 3 + lift * 11; ctx.fillStyle = '#000'; ctx.beginPath(); loopPath(ctx, loop, s, ox, oy, rad); ctx.fill(); ctx.restore(); }
    ctx.save(); ctx.beginPath(); loopPath(ctx, loop, s, ox, oy, rad); ctx.clip();
    // the grain in the piece's own frame: long axis of the ORIGINAL piece
    var bw = 0, bh = 0, k; for (k = 0; k < piece.cells.length; k++) { bw = Math.max(bw, piece.cells[k][0] + 1); bh = Math.max(bh, piece.cells[k][1] + 1); }
    var m = T.m;
    ctx.save(); ctx.translate(ox, oy); ctx.transform(m[0], m[1], m[2], m[3], m[4] * s, m[5] * s);
    if (bh > bw) { ctx.translate(bw * s, 0); ctx.rotate(Math.PI / 2); drawGrain(ctx, piece.wood, seed, bh * s, bw * s); ctx.rotate(-Math.PI / 2); ctx.translate(-bw * s, 0); }
    else drawGrain(ctx, piece.wood, seed, bw * s, bh * s);
    ctx.restore();
    // stringing: a fine line of contrasting wood run inside the edge
    var WD = WOOD[piece.wood] || WOOD.oak, inner = inset(loop, 0.14), line = WD.lum < 0.5 ? '#efe2c2' : '#2a1a10';
    ctx.beginPath(); loopPath(ctx, inner, s, ox, oy, rad * 0.6); ctx.strokeStyle = rgba(line, 0.75); ctx.lineWidth = Math.max(1, s * 0.035); ctx.stroke();
    ctx.beginPath(); loopPath(ctx, inset(loop, 0.14 + 0.05), s, ox, oy, rad * 0.5); ctx.strokeStyle = rgba(WD.lum < 0.5 ? '#000000' : '#ffffff', 0.18); ctx.lineWidth = 1; ctx.stroke();
    // the inlay, on the heart cell, turned with the piece
    var hc = heartCell(piece.cells);
    ctx.save(); ctx.translate(ox, oy); ctx.transform(m[0], m[1], m[2], m[3], m[4] * s, m[5] * s); ctx.translate((hc[0] + 0.5) * s, (hc[1] + 0.5) * s);
    drawMotif(ctx, piece.inlay, s * 0.72, mat); ctx.restore();
    // varnish: a broad soft sheen
    var sh = ctx.createLinearGradient(ox, oy, ox + T.w * s, oy + T.h * s); sh.addColorStop(0, 'rgba(255,248,230,0.16)'); sh.addColorStop(0.4, 'rgba(255,248,230,0)'); sh.addColorStop(0.75, 'rgba(255,248,230,0.05)'); sh.addColorStop(1, 'rgba(0,0,0,0.12)');
    ctx.fillStyle = sh; ctx.fillRect(ox, oy, T.w * s, T.h * s);
    // bevels: the edges that face the light (top, left) catch it, the others fall into shade
    var n = loop.length, bwid = Math.max(1.2, s * 0.07);
    ctx.lineWidth = bwid * 2; ctx.lineCap = 'butt';
    for (k = 0; k < n; k++) {
      var p0 = loop[k], p1 = loop[(k + 1) % n], dx = Math.sign(p1[0] - p0[0]), dy = Math.sign(p1[1] - p0[1]);
      var lit = dx > 0 || dy < 0;   // top edges run right, left edges run up (clockwise)
      ctx.strokeStyle = lit ? 'rgba(255,244,220,0.42)' : 'rgba(10,5,0,0.42)';
      ctx.beginPath(); ctx.moveTo(ox + p0[0] * s, oy + p0[1] * s); ctx.lineTo(ox + p1[0] * s, oy + p1[1] * s); ctx.stroke();
    }
    ctx.restore();
    // the kerf: a dark hairline round the cut
    ctx.beginPath(); loopPath(ctx, loop, s, ox, oy, rad); ctx.strokeStyle = 'rgba(18,8,2,0.85)'; ctx.lineWidth = Math.max(1, s * 0.03); ctx.stroke();
    if (opt.glow) { ctx.beginPath(); loopPath(ctx, loop, s, ox, oy, rad); ctx.strokeStyle = opt.glow; ctx.lineWidth = Math.max(2, s * 0.06); ctx.stroke(); }
    ctx.restore();
    return { w: T.w, h: T.h, cells: T.cells };
  }

  //------------------------------------------------------------------------ the room

  /** The workbench: dark planks with their own grain, lit from above. */
  function drawTable(ctx, W, H) {
    var planks = 5, ph = H / planks, i;
    for (i = 0; i < planks; i++) {
      ctx.save(); ctx.translate(0, i * ph); ctx.beginPath(); ctx.rect(0, 0, W, ph); ctx.clip();
      drawGrain(ctx, 'walnut', 4021 + i * 97, W, ph);
      ctx.fillStyle = 'rgba(12,6,2,' + (0.42 + (i % 2) * 0.08) + ')'; ctx.fillRect(0, 0, W, ph);
      ctx.fillStyle = 'rgba(0,0,0,0.55)'; ctx.fillRect(0, 0, W, 2); ctx.fillStyle = 'rgba(255,220,170,0.08)'; ctx.fillRect(0, 2, W, 1);
      ctx.restore();
    }
    var v = ctx.createRadialGradient(W * 0.45, H * 0.42, H * 0.2, W * 0.5, H * 0.5, W * 0.75); v.addColorStop(0, 'rgba(255,214,150,0.10)'); v.addColorStop(1, 'rgba(0,0,0,0.6)');
    ctx.fillStyle = v; ctx.fillRect(0, 0, W, H);
  }

  /** Stringing and corner fans on a board: the cabinetmaker's border. */
  function drawBanding(ctx, x, y, w, h, inset0) {
    ctx.strokeStyle = 'rgba(240,226,190,0.7)'; ctx.lineWidth = 1.4; ctx.strokeRect(x + inset0, y + inset0, w - inset0 * 2, h - inset0 * 2);
    ctx.strokeStyle = 'rgba(20,10,4,0.6)'; ctx.lineWidth = 1; ctx.strokeRect(x + inset0 + 3, y + inset0 + 3, w - inset0 * 2 - 6, h - inset0 * 2 - 6);
    // quarter-fan paterae in the corners
    var cs = [[x + inset0, y + inset0, 0], [x + w - inset0, y + inset0, 1], [x + w - inset0, y + h - inset0, 2], [x + inset0, y + h - inset0, 3]];
    for (var i = 0; i < 4; i++) {
      var cx = cs[i][0], cy = cs[i][1], a0 = cs[i][2] * Math.PI / 2, R = inset0 * 1.6;
      for (var k = 0; k < 5; k++) { var a1 = a0 + k * Math.PI / 10, a2 = a0 + (k + 1) * Math.PI / 10; ctx.fillStyle = k % 2 ? 'rgba(230,208,160,0.85)' : 'rgba(120,70,30,0.85)'; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.arc(cx, cy, R, a1, a2); ctx.closePath(); ctx.fill(); }
      ctx.strokeStyle = 'rgba(20,10,4,0.7)'; ctx.lineWidth = 0.8; ctx.beginPath(); ctx.arc(cx, cy, R, a0, a0 + Math.PI / 2); ctx.stroke();
    }
  }

  /** Baize: the green cloth a recess is lined with. */
  function drawBaize(ctx, x, y, w, h, seed) {
    var g = ctx.createLinearGradient(x, y, x, y + h); g.addColorStop(0, '#1d4a36'); g.addColorStop(1, '#123424'); ctx.fillStyle = g; ctx.fillRect(x, y, w, h);
    var r = rng(seed); for (var i = 0; i < w * h / 14; i++) { ctx.fillStyle = r() < 0.5 ? 'rgba(80,140,100,0.16)' : 'rgba(0,20,10,0.2)'; ctx.fillRect(x + r() * w, y + r() * h, 1, 1); }
  }

  /**
   * The case: a mahogany board with the tray's shape sunk into it and lined with baize, scored in squares. The recess
   * walls throw a shadow onto the cloth from the top left. Returns where the squares are: {x, y, s} (top-left of the box).
   */
  function drawCase(ctx, cx, cy, p, s) {
    var rim = Math.round(s * 0.62), bw = p.w * s + rim * 2, bh = p.h * s + rim * 2, x = Math.round(cx - bw / 2), y = Math.round(cy - bh / 2), ox = x + rim, oy = y + rim;
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.55)'; rr(ctx, x + 6, y + 9, bw, bh, 10); ctx.fill();
    // ⛔ found by looking (2026-09-28): a rosewood board swallowed the rosewood and cherry pieces lying against its rim.
    // The case is ebonised (black lacquer over a faint grain) so all ten woods stand off it, with a brass fillet round
    // the recess.
    ctx.save(); rr(ctx, x, y, bw, bh, 10); ctx.clip();
    ctx.translate(x, y); drawGrain(ctx, 'ebony', 777 + p.w * 31 + p.h, bw, bh); ctx.translate(-x, -y);
    // japanned: a blue-black lacquer, so the (warm) ebony piece still stands off the (cool) case
    ctx.fillStyle = 'rgba(14,20,38,0.62)'; ctx.fillRect(x, y, bw, bh);
    var gl = ctx.createLinearGradient(x, y, x + bw, y + bh); gl.addColorStop(0, 'rgba(255,230,200,0.14)'); gl.addColorStop(0.5, 'rgba(255,230,200,0.02)'); gl.addColorStop(1, 'rgba(0,0,0,0.3)'); ctx.fillStyle = gl; ctx.fillRect(x, y, bw, bh);
    ctx.restore();
    ctx.strokeStyle = 'rgba(255,230,190,0.35)'; ctx.lineWidth = 2; rr(ctx, x + 1, y + 1, bw - 2, bh - 2, 9); ctx.stroke();
    ctx.strokeStyle = 'rgba(0,0,0,0.6)'; ctx.lineWidth = 1; rr(ctx, x + 0.5, y + 0.5, bw - 1, bh - 1, 10); ctx.stroke();
    drawBanding(ctx, x, y, bw, bh, Math.max(6, rim * 0.34));
    // the recess
    var cells = []; for (var i = 0; i < p.mask.length; i++) if (p.mask[i]) cells.push([i % p.w, Math.floor(i / p.w)]);
    var loops = outline(cells);
    ctx.save(); ctx.beginPath(); for (var L = 0; L < loops.length; L++) loopPath(ctx, loops[L], s, ox, oy, s * 0.08); ctx.clip();
    drawBaize(ctx, ox, oy, p.w * s, p.h * s, 91 + p.cells);
    // scoring: faint lines where the squares meet
    ctx.strokeStyle = 'rgba(0,0,0,0.22)'; ctx.lineWidth = 1; ctx.setLineDash([2, 3]);
    for (var gx = 1; gx < p.w; gx++) { ctx.beginPath(); ctx.moveTo(ox + gx * s, oy); ctx.lineTo(ox + gx * s, oy + p.h * s); ctx.stroke(); }
    for (var gy = 1; gy < p.h; gy++) { ctx.beginPath(); ctx.moveTo(ox, oy + gy * s); ctx.lineTo(ox + p.w * s, oy + gy * s); ctx.stroke(); }
    ctx.setLineDash([]);
    // the wall's shadow, cast down and right onto the cloth
    for (L = 0; L < loops.length; L++) { ctx.save(); ctx.shadowColor = 'rgba(0,0,0,0.75)'; ctx.shadowBlur = s * 0.28; ctx.shadowOffsetX = s * 0.08; ctx.shadowOffsetY = s * 0.12; ctx.beginPath(); ctx.rect(ox - s * 3, oy - s * 3, p.w * s + s * 6, p.h * s + s * 6); loopPath(ctx, loops[L], s, ox, oy, s * 0.08); ctx.fillStyle = '#000'; ctx.fill('evenodd'); ctx.restore(); }
    ctx.restore();
    // the brass fillet round the recess, then the lip: lit on the far (bottom/right) walls, dark on the near ones
    ctx.save(); ctx.beginPath(); for (L = 0; L < loops.length; L++) loopPath(ctx, inset(loops[L], -0.07), s, ox, oy, s * 0.12);
    ctx.strokeStyle = '#c99a42'; ctx.lineWidth = Math.max(2, s * 0.06); ctx.stroke(); ctx.strokeStyle = 'rgba(255,240,190,0.5)'; ctx.lineWidth = 1; ctx.stroke(); ctx.restore();
    for (L = 0; L < loops.length; L++) {
      var lp = loops[L], n = lp.length;
      ctx.lineWidth = 2;
      for (var k = 0; k < n; k++) { var a = lp[k], b = lp[(k + 1) % n], dx = Math.sign(b[0] - a[0]), dy = Math.sign(b[1] - a[1]); ctx.strokeStyle = (dx < 0 || dy > 0) ? 'rgba(255,226,180,0.45)' : 'rgba(0,0,0,0.7)'; ctx.beginPath(); ctx.moveTo(ox + a[0] * s, oy + a[1] * s); ctx.lineTo(ox + b[0] * s, oy + b[1] * s); ctx.stroke(); }
    }
    ctx.restore();
    return { x: ox, y: oy, s: s, board: { x: x, y: y, w: bw, h: bh } };
  }

  /** The parts box: a shallow open box of pale wood lined with baize, where the loose pieces wait. */
  function drawPartsBox(ctx, x, y, w, h) {
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; rr(ctx, x + 5, y + 8, w, h, 8); ctx.fill();
    ctx.save(); rr(ctx, x, y, w, h, 8); ctx.clip(); ctx.translate(x, y); drawGrain(ctx, 'oak', 1203, w, h); ctx.translate(-x, -y); ctx.fillStyle = 'rgba(40,20,5,0.25)'; ctx.fillRect(x, y, w, h); ctx.restore();
    var b = 12; drawBaize(ctx, x + b, y + b, w - b * 2, h - b * 2, 57);
    // the box wall's shadow on the cloth (clip to the cloth, fill everything outside it, keep only the shadow)
    ctx.save(); ctx.beginPath(); ctx.rect(x + b, y + b, w - b * 2, h - b * 2); ctx.clip();
    ctx.shadowColor = 'rgba(0,0,0,0.7)'; ctx.shadowBlur = 10; ctx.shadowOffsetX = 3; ctx.shadowOffsetY = 5; ctx.beginPath(); ctx.rect(x - 60, y - 60, w + 120, h + 120); ctx.rect(x + b, y + b, w - b * 2, h - b * 2); ctx.fillStyle = '#000'; ctx.fill('evenodd'); ctx.restore();
    ctx.strokeStyle = 'rgba(0,0,0,0.65)'; ctx.lineWidth = 2; ctx.strokeRect(x + b, y + b, w - b * 2, h - b * 2);
    ctx.strokeStyle = 'rgba(255,236,200,0.35)'; ctx.lineWidth = 1.5; rr(ctx, x + 1, y + 1, w - 2, h - 2, 7); ctx.stroke();
    ctx.restore();
  }

  /** The brass title plate. */
  function drawTitle(ctx, x, y, w, h, title, sub) {
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; rr(ctx, x + 3, y + 4, w, h, 6); ctx.fill();
    var g = ctx.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, '#f6dc94'); g.addColorStop(0.45, '#c99a42'); g.addColorStop(1, '#8a6120'); ctx.fillStyle = g; rr(ctx, x, y, w, h, 6); ctx.fill();
    ctx.strokeStyle = 'rgba(60,40,10,0.7)'; ctx.lineWidth = 1; rr(ctx, x + 4, y + 4, w - 8, h - 8, 4); ctx.stroke();
    ctx.fillStyle = '#6a4816'; for (var i = 0; i < 2; i++) { var sx = i ? x + w - 12 : x + 12; ctx.beginPath(); ctx.arc(sx, y + h / 2, 3.2, 0, 6.2832); ctx.fill(); ctx.strokeStyle = 'rgba(255,240,200,0.6)'; ctx.beginPath(); ctx.moveTo(sx - 2.2, y + h / 2); ctx.lineTo(sx + 2.2, y + h / 2); ctx.stroke(); }
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    fitText(ctx, title, w - 44, sub ? 19 : 22); ctx.fillStyle = 'rgba(255,245,210,0.6)'; ctx.fillText(title, x + w / 2 + 0.8, y + (sub ? h * 0.38 : h / 2) + 1.6); ctx.fillStyle = '#3a2408'; ctx.fillText(title, x + w / 2, y + (sub ? h * 0.38 : h / 2) + 0.8);
    if (sub) { fitText(ctx, sub, w - 44, 12, 'italic'); ctx.fillStyle = '#4a3010'; ctx.fillText(sub, x + w / 2, y + h * 0.74); }
    ctx.restore();
  }

  /** The tally card: moves, hints and pieces placed, on a small ivory card. */
  function drawCard(ctx, w, h, info) {
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; rr(ctx, 4, 5, w - 6, h - 7, 5); ctx.fill();
    var g = ctx.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#f4ead2'); g.addColorStop(1, '#e0d0aa'); ctx.fillStyle = g; rr(ctx, 1, 1, w - 6, h - 7, 5); ctx.fill();
    ctx.strokeStyle = 'rgba(120,80,30,0.6)'; ctx.lineWidth = 1; rr(ctx, 5, 5, w - 14, h - 15, 3); ctx.stroke();
    var rows = [['Pieces in', info.placed + ' of ' + info.total], ['Moves', String(info.moves)], ['Hints', info.hintsLeft < 0 ? String(info.hints) : info.hints + ' (' + info.hintsLeft + ' left)']];
    ctx.textBaseline = 'middle';
    for (var i = 0; i < rows.length; i++) { var y = 22 + i * 22; ctx.textAlign = 'left'; ctx.font = 'italic 13px ' + FACE; ctx.fillStyle = '#6a4a28'; ctx.fillText(rows[i][0], 14, y); ctx.textAlign = 'right'; ctx.font = 'bold 14px ' + FACE; ctx.fillStyle = '#2a1a08'; ctx.fillText(rows[i][1], w - 18, y); ctx.fillStyle = 'rgba(120,80,30,0.25)'; ctx.fillRect(12, y + 10, w - 30, 1); }
  }

  /** A brass plaque button. state: 'on', 'idle', 'off'. */
  function drawPlaque(ctx, x, y, w, h, text, state) {
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; rr(ctx, x + 3, y + 4, w, h, 6); ctx.fill();
    var g = ctx.createLinearGradient(0, y, 0, y + h);
    if (state === 'off') { g.addColorStop(0, '#6a5a44'); g.addColorStop(1, '#3a2e20'); } else if (state === 'on') { g.addColorStop(0, '#fff0b0'); g.addColorStop(0.5, '#e8b850'); g.addColorStop(1, '#9a6a1e'); } else { g.addColorStop(0, '#f2d890'); g.addColorStop(0.5, '#c99a42'); g.addColorStop(1, '#8a6120'); }
    ctx.fillStyle = g; rr(ctx, x, y, w, h, 6); ctx.fill(); ctx.strokeStyle = 'rgba(60,40,10,0.75)'; ctx.lineWidth = 1; rr(ctx, x + 3, y + 3, w - 6, h - 6, 4); ctx.stroke();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; fitText(ctx, text, w - 20, 15);
    ctx.fillStyle = state === 'off' ? 'rgba(200,180,150,0.45)' : 'rgba(255,245,210,0.6)'; ctx.fillText(text, x + w / 2 + 0.8, y + h / 2 + 1.8); ctx.fillStyle = state === 'off' ? 'rgba(30,20,10,0.8)' : '#3a2408'; ctx.fillText(text, x + w / 2, y + h / 2 + 1);
    ctx.restore();
  }
  function drawStatus(ctx, W, H, text) {
    ctx.clearRect(0, 0, W, H); if (!text) return; fitText(ctx, text, W - 10, 16, 'italic');
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = 'rgba(0,0,0,0.75)'; ctx.fillText(text, W / 2 + 1, H / 2 + 1); ctx.fillStyle = '#f1dfb4'; ctx.fillText(text, W / 2, H / 2);
  }
  /** Where a carried piece would land: its squares outlined on the cloth, green-gold if it fits, red if not. */
  function drawGhost(ctx, cells, ox, oy, s, fits) {
    var loops = outline(cells);
    ctx.save(); ctx.beginPath(); for (var L = 0; L < loops.length; L++) loopPath(ctx, loops[L], s, ox, oy, s * 0.1);
    ctx.fillStyle = fits ? 'rgba(236,210,120,0.22)' : 'rgba(200,40,30,0.25)'; ctx.fill();
    ctx.setLineDash([5, 4]); ctx.strokeStyle = fits ? 'rgba(255,232,150,0.9)' : 'rgba(255,110,90,0.9)'; ctx.lineWidth = 2; ctx.stroke(); ctx.restore();
  }
  /** A small brass pointer (a hand-cut arrow) that marks the chosen piece. */
  function drawPointer(ctx, w, h) {
    ctx.clearRect(0, 0, w, h);
    ctx.save(); ctx.translate(w / 2, h - 2);
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(-w * 0.4, -h * 0.5); ctx.lineTo(-w * 0.16, -h * 0.5); ctx.lineTo(-w * 0.16, -h + 3); ctx.lineTo(w * 0.16, -h + 3); ctx.lineTo(w * 0.16, -h * 0.5); ctx.lineTo(w * 0.4, -h * 0.5); ctx.closePath();
    ctx.shadowColor = 'rgba(0,0,0,0.6)'; ctx.shadowBlur = 4; ctx.shadowOffsetY = 2;
    var g = ctx.createLinearGradient(-w / 2, 0, w / 2, 0); g.addColorStop(0, '#fbe7a4'); g.addColorStop(0.5, '#d9aa4a'); g.addColorStop(1, '#8a5a14'); ctx.fillStyle = g; ctx.fill();
    ctx.shadowColor = 'transparent'; ctx.strokeStyle = '#4a2e06'; ctx.lineWidth = 1; ctx.stroke(); ctx.restore();
  }
  /** A soft band of light, for the polish that runs across a finished panel. */
  function drawSheen(ctx, w, h) {
    var g = ctx.createLinearGradient(0, 0, w, 0); g.addColorStop(0, 'rgba(255,250,235,0)'); g.addColorStop(0.5, 'rgba(255,250,235,0.55)'); g.addColorStop(1, 'rgba(255,250,235,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
  }

  /** The finished panel, framed: every piece home, a plaque with the result, the woods listed underneath. */
  function drawVerdict(ctx, W, H, p, placed, info) {
    // ⛔ found by looking: at 0.78 the tally card showed through beside the plate; the finished panel stands alone
    ctx.clearRect(0, 0, W, H); ctx.fillStyle = 'rgba(8,4,2,0.96)'; ctx.fillRect(0, 0, W, H);
    var lamp = ctx.createRadialGradient(W / 2, 250, 40, W / 2, 250, W * 0.6); lamp.addColorStop(0, 'rgba(255,214,150,0.12)'); lamp.addColorStop(1, 'rgba(255,214,150,0)'); ctx.fillStyle = lamp; ctx.fillRect(0, 0, W, H);
    var s = Math.min(Math.floor(520 / p.w), Math.floor(300 / p.h), 60), geo = drawCase(ctx, W / 2, 238, p, s);
    for (var i = 0; i < p.pieces.length; i++) { var pl = placed[i]; if (!pl) continue; var pose = poseOf(p.pieces[i].cells, pl.cells) || { rot: 0, flip: false }; drawPiece(ctx, p.pieces[i], geo.x + pl.x * s, geo.y + pl.y * s, s, { rot: pose.rot, flip: pose.flip, shadow: 0 }); }
    var hg = ctx.createLinearGradient(geo.board.x, geo.board.y, geo.board.x + geo.board.w, geo.board.y + geo.board.h); hg.addColorStop(0, 'rgba(255,245,220,0.14)'); hg.addColorStop(0.5, 'rgba(255,245,220,0)'); hg.addColorStop(1, 'rgba(0,0,0,0.1)'); ctx.fillStyle = hg; ctx.fillRect(geo.board.x, geo.board.y, geo.board.w, geo.board.h);
    var x = W / 2 - 230, y = Math.min(H - 120, geo.board.y + geo.board.h + 22), w = 460, h = 60;
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; rr(ctx, x + 3, y + 4, w, h, 6); ctx.fill();
    var g = ctx.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, '#f6dc94'); g.addColorStop(0.5, '#c99a42'); g.addColorStop(1, '#8a6120');
    ctx.fillStyle = g; rr(ctx, x, y, w, h, 6); ctx.fill(); ctx.strokeStyle = 'rgba(60,40,10,0.7)'; ctx.lineWidth = 1; rr(ctx, x + 3, y + 3, w - 6, h - 6, 4); ctx.stroke();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; fitText(ctx, info.title, w - 24, 20); ctx.fillStyle = 'rgba(255,245,210,0.6)'; ctx.fillText(info.title, W / 2, y + 21); ctx.fillStyle = '#3a2408'; ctx.fillText(info.title, W / 2, y + 20);
    fitText(ctx, info.sub, w - 24, 13, 'italic'); ctx.fillStyle = '#4a3010'; ctx.fillText(info.sub, W / 2, y + 43);
    var woods = p.pieces.map(function (q) { return (WOOD[q.wood] || WOOD.oak).name; }).join(' · ');
    fitText(ctx, woods, W - 80, 13, 'italic'); ctx.fillStyle = '#d8c49a'; ctx.fillText(woods, W / 2, y + h + 22);
    ctx.font = 'italic 14px ' + FACE; ctx.fillStyle = '#e8d4a8'; ctx.fillText(info.foot, W / 2, Math.min(H - 16, y + h + 48));
  }

  return {
    VERSION: '1.0.0', FACE: FACE, WOOD: WOOD, MATERIAL: MATERIAL, MOTIFS: MOTIFS, rng: rng, rr: rr, fitText: fitText, mix: mix,
    materialFor: materialFor, turn: turn, poseOf: poseOf, outline: outline, inset: inset, loopPath: loopPath, heartCell: heartCell,
    drawGrain: drawGrain, drawMotif: drawMotif, drawPiece: drawPiece, drawTable: drawTable, drawBanding: drawBanding, drawBaize: drawBaize,
    drawCase: drawCase, drawPartsBox: drawPartsBox, drawTitle: drawTitle, drawCard: drawCard, drawPlaque: drawPlaque, drawStatus: drawStatus,
    drawGhost: drawGhost, drawPointer: drawPointer, drawSheen: drawSheen, drawVerdict: drawVerdict,
  };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = TrayDraw;
