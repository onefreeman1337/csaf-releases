//=============================================================================
// TrayCore.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Tray core - generated packing puzzles: a shaped tray cut
 * into distinct polyomino pieces, so every puzzle is solvable by construction.
 * Place ABOVE TrayDraw and Tray.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The generator, the solver and the play rules for Tray. No parameters or
 * commands of its own; Tray.js is the file you configure. Must be installed
 * and listed above Tray.js.
 *
 * Pure logic: nothing here touches the screen and nothing uses Math.random.
 *
 * THE PUZZLE. A tray of a generated shape (rectangle, cross, diamond, round,
 * notched, arch) is carved into pieces of three to six squares, every piece
 * a different shape even allowing for turning and flipping. The pieces are
 * handed to the player loose; putting them back fills the tray. Because the
 * pieces were cut from the tray, every puzzle can be solved. A solver counts
 * how many ways there are, which grades the puzzle.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var TrayCore = (function () {
  'use strict';

  function hashString(s) { var h = 0x811c9dc5; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h >>> 0; }
  function rng(seed) { var a = seed >>> 0; return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function pick(r, a) { return a[Math.floor(r() * a.length) % a.length]; }

  var SHAPES = ['rect', 'cross', 'diamond', 'round', 'notched', 'arch'];
  // ways = the most DIFFERENT solutions (turns and flips of the tray counted once) a puzzle of that difficulty may have;
  // tries = how many carvings generate-and-test looks at. Set from Internal_Ops/_probe/grade_probe.js, never guessed.
  // area = squares per piece: bigger pieces (pentominoes, hexominoes) pack TIGHTER, so hard leans on them
  var DIFFS = { easy: { pieces: [4, 5], area: [3.9, 5.6], ways: 4, tries: 4 }, normal: { pieces: [6, 7], area: [4.2, 5.3], ways: 12, tries: 5 }, hard: { pieces: [8, 10], area: [4.5, 5.5], ways: 40, tries: 6 } };
  var GRADE_NODES = 150000;   // the solver's budget per carving while grading
  var BOX = { w: [4, 10], h: [3, 7] };   // the largest box the scene lays out (Tray.js sizes its squares from this)
  var WOODS = ['walnut', 'maple', 'cherry', 'oak', 'ebony', 'ash', 'rosewood', 'yew', 'olive', 'holly'];
  var INLAYS = ['star', 'lozenge', 'rosette', 'bars', 'chevron', 'dot', 'ring', 'cross', 'leaf', 'wave'];

  /** The tray's cells as a mask (1 = part of the tray), row-major w x h, for a shape family. */
  function mask(shape, w, h) {
    var m = [], x, y, cx = (w - 1) / 2, cy = (h - 1) / 2;
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) {
      var dx = Math.abs(x - cx) / (w / 2), dy = Math.abs(y - cy) / (h / 2), v = 1;
      if (shape === 'cross') v = (dx < 0.45 || dy < 0.45) ? 1 : 0;
      else if (shape === 'diamond') v = dx + dy <= 1.05 ? 1 : 0;
      else if (shape === 'round') v = dx * dx + dy * dy <= 1.05 ? 1 : 0;
      else if (shape === 'notched') v = ((x === 0 || x === w - 1) && (y === 0 || y === h - 1)) ? 0 : 1;
      else if (shape === 'arch') v = (y < h / 2 && dx * dx + (cy - y) * (cy - y) / (h * h / 4) > 1.0) ? 0 : 1;
      m.push(v);
    }
    return m;
  }
  function count(m) { var n = 0; for (var i = 0; i < m.length; i++) n += m[i]; return n; }

  /** The 8 turns and flips of a polyomino, each normalised to its top-left, as [[x,y]...] sorted; de-duplicated. */
  function orientations(cells) {
    var out = [], seen = {}, t, k;
    for (t = 0; t < 8; t++) {
      var pts = [];
      for (k = 0; k < cells.length; k++) {
        var x = cells[k][0], y = cells[k][1], nx, ny;
        switch (t & 3) { case 0: nx = x; ny = y; break; case 1: nx = -y; ny = x; break; case 2: nx = -x; ny = -y; break; default: nx = y; ny = -x; }
        if (t & 4) nx = -nx;
        pts.push([nx, ny]);
      }
      var mx = Infinity, my = Infinity; for (k = 0; k < pts.length; k++) { if (pts[k][0] < mx) mx = pts[k][0]; if (pts[k][1] < my) my = pts[k][1]; }
      for (k = 0; k < pts.length; k++) { pts[k][0] -= mx; pts[k][1] -= my; }
      pts.sort(function (a, b) { return a[1] - b[1] || a[0] - b[0]; });
      var key = pts.map(function (p) { return p[0] + ',' + p[1]; }).join(';');
      if (!seen[key]) { seen[key] = 1; out.push(pts); }
    }
    return out;
  }
  /** A shape's canonical key: the smallest of its orientation keys (same key = same piece, turned or flipped). */
  function canon(cells) { var o = orientations(cells), best = null; for (var i = 0; i < o.length; i++) { var k = o[i].map(function (p) { return p[0] + ',' + p[1]; }).join(';'); if (best === null || k < best) best = k; } return best; }

  /**
   * Carve the mask into k connected pieces of 3..6 cells, all of different shapes. Grows regions from spread seeds,
   * always extending the smallest region that can grow. Returns an array of cell-index lists, or null on failure.
   */
  function carve(m, w, h, k, r) {
    var n = m.length, owner = [], i, cells = [];
    for (i = 0; i < n; i++) { owner.push(m[i] ? -1 : -2); if (m[i]) cells.push(i); }
    var total = cells.length; if (total < k * 3 || total > k * 6) return null;
    // spread seeds: pick the free cell farthest from all seeds (with a random tie-break)
    var seeds = [pick(r, cells)];
    while (seeds.length < k) {
      var bestI = -1, bestD = -1;
      for (i = 0; i < cells.length; i++) { var c = cells[i], dmin = Infinity; for (var s = 0; s < seeds.length; s++) { var d = Math.abs(c % w - seeds[s] % w) + Math.abs(Math.floor(c / w) - Math.floor(seeds[s] / w)); if (d < dmin) dmin = d; } dmin += r() * 0.5; if (dmin > bestD) { bestD = dmin; bestI = c; } }
      seeds.push(bestI);
    }
    var regions = seeds.map(function (s, j) { owner[s] = j; return [s]; }), left = total - k, guard = 0;
    while (left > 0 && guard++ < 10000) {
      // the smallest region with a free neighbour grows by one random free neighbour
      // ⛔ (2026-09-28) the tie-break used to call r() INSIDE the sort comparator, so how many draws a carving took
      // depended on the engine's sort algorithm: the same seed could carve differently on another JS engine. One draw per
      // region, taken before sorting, makes the seed mean the same puzzle everywhere.
      var tie = []; for (var tj = 0; tj < regions.length; tj++) tie.push(r());
      var order = regions.map(function (reg, j) { return j; }).sort(function (a, b) { return regions[a].length - regions[b].length || tie[a] - tie[b]; }), grew = false;
      for (var oi = 0; oi < order.length && !grew; oi++) {
        var j = order[oi]; if (regions[j].length >= 6) continue;
        var front = [];
        for (var q = 0; q < regions[j].length; q++) { var cc = regions[j][q], x = cc % w, y = Math.floor(cc / w); [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(function (dd) { var nx = x + dd[0], ny = y + dd[1]; if (nx >= 0 && ny >= 0 && nx < w && ny < h && owner[ny * w + nx] === -1 && front.indexOf(ny * w + nx) < 0) front.push(ny * w + nx); }); }
        if (front.length) { var pc = pick(r, front); owner[pc] = j; regions[j].push(pc); left--; grew = true; }
      }
      if (!grew) return null;
    }
    if (left > 0) return null;
    var keys = {};
    for (i = 0; i < regions.length; i++) {
      if (regions[i].length < 3 || regions[i].length > 6) return null;
      var key = canon(regions[i].map(function (c2) { return [c2 % w, Math.floor(c2 / w)]; }));
      if (keys[key]) return null; keys[key] = 1;
    }
    return regions;
  }

  /**
   * The tray's symmetries: every turn or flip of the w x h box that maps the tray's mask onto itself, each as a cell
   * permutation (perm[i] = where cell i goes). Always contains the identity. A square box can have up to 8, any other
   * rectangle up to 4 (no quarter turns).
   */
  function symmetries(m, w, h) {
    var out = [], t, i;
    for (t = 0; t < 8; t++) {
      if ((t === 1 || t === 3 || t === 5 || t === 7) && w !== h) continue;   // quarter turns (and their mirrors) need a square box
      var perm = [], ok = true;
      for (i = 0; i < m.length && ok; i++) {
        var x = i % w, y = Math.floor(i / w), nx, ny;
        switch (t & 3) { case 0: nx = x; ny = y; break; case 1: nx = w - 1 - y; ny = x; break; case 2: nx = w - 1 - x; ny = h - 1 - y; break; default: nx = y; ny = h - 1 - x; }
        if (t & 4) nx = w - 1 - nx;
        var j = ny * w + nx; if (m[j] !== m[i]) ok = false; perm.push(j);
      }
      if (ok) out.push(perm);
    }
    return out;
  }

  /**
   * Exact cover by backtracking on the first empty cell. Counts DIFFERENT solutions: two fillings that are the same
   * picture turned or flipped (a symmetry of the tray) count once, so a symmetric tray does not look easier than it is.
   * @param {object} [o] {cap: stop after this many different solutions, nodeCap: search budget,
   *   fixed: a grid (-1 empty, -2 outside, >=0 a placed piece) whose placed pieces are kept, keep: collect the placements of
   *   the first solution found}
   * @returns {{solutions:number, raw:number, complete:boolean, nodes:number, first:Array|null}}
   */
  function solve(m, w, h, pieces, o) {
    o = o || {};
    var cap = o.cap || 50, nodeCap = o.nodeCap || 400000, n = m.length, i;
    var grid = [], used = [], who = [];
    for (i = 0; i < n; i++) {
      var f0 = o.fixed ? o.fixed[i] : (m[i] ? -1 : -2);
      grid.push(f0 === -1 ? 0 : 1); who.push(f0);
    }
    for (i = 0; i < pieces.length; i++) used.push(false);
    if (o.fixed) for (i = 0; i < n; i++) if (o.fixed[i] >= 0) used[o.fixed[i]] = true;
    var syms = symmetries(m, w, h), seen = {}, sols = 0, raw = 0, nodes = 0, stop = false, stack = [], first = null;
    var orients = pieces.map(function (p) { return orientations(p.cells); });
    function firstEmpty() { for (var q = 0; q < n; q++) if (!grid[q]) return q; return -1; }
    function key() {   // the smallest spelling of the filled grid over the tray's symmetries
      var best = null;
      for (var s = 0; s < syms.length; s++) { var arr = []; for (var q = 0; q < n; q++) arr[syms[s][q]] = who[q]; var k = arr.join(','); if (best === null || k < best) best = k; }
      return best;
    }
    function rec() {
      if (stop) return; if (++nodes > nodeCap) { stop = true; return; }
      var f = firstEmpty();
      if (f < 0) {
        raw++; var k = key(); if (!seen[k]) { seen[k] = 1; sols++; if (o.keep && !first) first = stack.map(function (s2) { return { piece: s2.piece, x: s2.x, y: s2.y, cells: s2.cells.map(function (c) { return c.slice(); }) }; }); if (sols >= cap) stop = true; }
        return;
      }
      var fx = f % w, fy = Math.floor(f / w);
      for (var pi = 0; pi < pieces.length; pi++) {
        if (used[pi]) continue;
        var os = orients[pi];
        for (var oi = 0; oi < os.length; oi++) {
          var or = os[oi], ax = fx - or[0][0], ay = fy - or[0][1], ok = true, c;   // the piece's first cell goes on the first empty cell
          for (c = 0; c < or.length && ok; c++) { var x = ax + or[c][0], y = ay + or[c][1]; if (x < 0 || y < 0 || x >= w || y >= h || grid[y * w + x]) ok = false; }
          if (!ok) continue;
          for (c = 0; c < or.length; c++) { grid[(ay + or[c][1]) * w + ax + or[c][0]] = 1; who[(ay + or[c][1]) * w + ax + or[c][0]] = pi; }
          used[pi] = true; stack.push({ piece: pi, x: ax, y: ay, cells: or }); rec(); stack.pop(); used[pi] = false;
          for (c = 0; c < or.length; c++) { grid[(ay + or[c][1]) * w + ax + or[c][0]] = 0; who[(ay + or[c][1]) * w + ax + or[c][0]] = -1; }
          if (stop) return;
        }
      }
    }
    rec();
    return { solutions: sols, raw: raw, complete: !stop || sols >= cap, nodes: nodes, first: first, symmetries: syms.length };
  }

  /**
   * A packing puzzle. @param {{seed:number, difficulty?:string, shape?:string}} opt
   * @returns the tray (w, h, mask), the pieces (normalised cells, wood, inlay) and the carving it came from (a solution).
   */
  /** One carved tray for a difficulty and shape, ungraded, or null if 400 carvings all failed. */
  var _sizes = {};
  /** Box sizes (w >= h, within BOX) whose tray of this shape holds between lo and hi cells. Cached per shape. */
  function sizesFor(shape, lo, hi) {
    var t = _sizes[shape], out = [], i;
    // w >= h (the scene is landscape) but no wider than 1.8 h: a 10 x 3 strip is a shelf, not a tray (found by looking)
    if (!t) { t = []; for (var w = BOX.w[0]; w <= BOX.w[1]; w++) for (var h = BOX.h[0]; h <= Math.min(w, BOX.h[1]); h++) if (w <= h * 1.8) t.push([w, h, count(mask(shape, w, h))]); _sizes[shape] = t; }
    for (i = 0; i < t.length; i++) if (t[i][2] >= lo && t[i][2] <= hi) out.push(t[i]);
    return out;
  }
  function candidate(r, seed, diff, shape) {
    var D = DIFFS[diff], attempt = 0;
    while (attempt++ < 400) {
      // the piece count is the difficulty; the box is sized so THIS shape holds about 4.5 squares a piece (the six shapes
      // hold very different areas in the same box, so a fixed box would make a diamond easy and a rectangle hard)
      var k = D.pieces[0] + Math.floor(r() * (D.pieces[1] - D.pieces[0] + 1)), fit = sizesFor(shape, Math.ceil(k * D.area[0]), Math.floor(k * D.area[1]));
      if (!fit.length) continue;
      var sz = pick(r, fit), w = sz[0], h = sz[1], m = mask(shape, w, h);
      var regions = carve(m, w, h, k, r); if (!regions) continue;
      var woods = WOODS.slice(), inlays = INLAYS.slice(), pieces = [], solution = [];
      for (var i = 0; i < regions.length; i++) {
        var pts = regions[i].map(function (c) { return [c % w, Math.floor(c / w)]; }), mx = Infinity, my = Infinity;
        pts.forEach(function (p) { if (p[0] < mx) mx = p[0]; if (p[1] < my) my = p[1]; });
        var norm = pts.map(function (p) { return [p[0] - mx, p[1] - my]; }).sort(function (a, b) { return a[1] - b[1] || a[0] - b[0]; });
        var wi = Math.floor(r() * woods.length) % woods.length, ii = Math.floor(r() * inlays.length) % inlays.length;
        pieces.push({ id: i, cells: norm, wood: woods.splice(wi, 1)[0] || WOODS[i % WOODS.length], inlay: inlays.splice(ii, 1)[0] || INLAYS[i % INLAYS.length] });
        solution.push({ piece: i, x: mx, y: my, cells: norm });
      }
      return { v: 1, seed: seed, difficulty: diff, shape: shape, w: w, h: h, mask: m, cells: count(m), pieces: pieces, solution: solution, ways: -1, graded: false };
    }
    return null;
  }

  /**
   * A packing puzzle, graded by generate-and-test: carve up to DIFFS[d].tries trays and keep the first whose number of
   * different solutions is at most DIFFS[d].ways (or, if none is, the one with the fewest). `ways` on the result is that
   * count; `graded` is false only if the solver ran out of budget.
   * @param {{seed:number, difficulty?:string, shape?:string, raw?:boolean}} opt  raw = the first carving, ungraded
   */
  function generate(opt) {
    opt = opt || {};
    var seed = Number(opt.seed) >>> 0, r = rng(seed ^ 0x7A4), diff = DIFFS[opt.difficulty] ? opt.difficulty : pick(r, Object.keys(DIFFS)), D = DIFFS[diff];
    var shape = SHAPES.indexOf(opt.shape) >= 0 ? opt.shape : pick(r, SHAPES), best = null;
    for (var t = 0; t < (opt.raw ? 1 : D.tries); t++) {
      var p = candidate(r, seed, diff, shape); if (!p) continue;
      if (opt.raw) return p;
      var g = solve(p.mask, p.w, p.h, p.pieces, { cap: D.ways + 1, nodeCap: GRADE_NODES });
      p.ways = g.solutions; p.graded = g.complete; p.tries = t + 1;
      if (g.complete && g.solutions <= D.ways) return p;
      if (!best || (p.graded && (!best.graded || p.ways < best.ways))) best = p;
    }
    if (best) best.tries = D.tries;   // all spent; the tightest proven one wins (ways = D.ways + 1 reads "more than D.ways")
    return best;
  }

  /**
   * A hint: one piece of a solution that keeps every piece the player has already placed, or, if no solution keeps
   * them, the placed piece that has to come out. @returns {{place?:object, lift?:number, none?:boolean}}
   */
  function hint(p, game) {
    var g = solve(p.mask, p.w, p.h, p.pieces, { cap: 1, nodeCap: 300000, fixed: game.grid, keep: true });
    if (g.first && g.first.length) { var s = g.first[0]; return { place: { piece: s.piece, x: s.x, y: s.y, cells: s.cells } }; }
    if (!g.complete) return { none: true };
    // no completion keeps the current placement: the last piece put down is the one to lift
    var last = -1, at = -1; for (var i = 0; i < game.placed.length; i++) if (game.placed[i] && game.placed[i].at > at) { at = game.placed[i].at; last = i; }
    return last >= 0 ? { lift: last } : { none: true };
  }

  /** A fresh play state: every piece in the box. */
  function newGame(p) { var g = []; for (var i = 0; i < p.mask.length; i++) g.push(p.mask[i] ? -1 : -2); return { grid: g, placed: p.pieces.map(function () { return null; }), moves: 0, seq: 0, hints: 0, done: false }; }
  /** Can piece `pi`, in orientation `cells`, go with its top-left at (x, y)? */
  function fits(p, game, pi, cells, x, y) { for (var k = 0; k < cells.length; k++) { var cx = x + cells[k][0], cy = y + cells[k][1]; if (cx < 0 || cy < 0 || cx >= p.w || cy >= p.h) return false; var v = game.grid[cy * p.w + cx]; if (v !== -1 && v !== pi) return false; } return true; }
  /** Place (or move) a piece. Returns false (and changes nothing) if it does not fit. */
  function place(p, game, pi, cells, x, y) {
    if (game.done || pi < 0 || pi >= p.pieces.length || !fits(p, game, pi, cells, x, y)) return false;
    lift(p, game, pi);
    for (var k = 0; k < cells.length; k++) game.grid[(y + cells[k][1]) * p.w + x + cells[k][0]] = pi;
    game.placed[pi] = { x: x, y: y, cells: cells.map(function (c) { return c.slice(); }), at: ++game.seq }; game.moves++;
    game.done = solved(p, game); return true;
  }
  /** Take a piece back out of the tray. */
  function lift(p, game, pi) { if (!game.placed[pi]) return false; for (var i = 0; i < game.grid.length; i++) if (game.grid[i] === pi) game.grid[i] = -1; game.placed[pi] = null; return true; }
  /** Every tray cell covered. */
  function solved(p, game) { for (var i = 0; i < game.grid.length; i++) if (game.grid[i] === -1) return false; return true; }

  return {
    VERSION: '1.0.0', SHAPES: SHAPES, DIFFS: DIFFS, BOX: BOX, sizesFor: sizesFor, WOODS: WOODS, INLAYS: INLAYS, hashString: hashString, rng: rng, mask: mask, count: count,
    orientations: orientations, canon: canon, carve: carve, symmetries: symmetries, solve: solve, candidate: candidate, generate: generate, hint: hint,
    newGame: newGame, fits: fits, place: place, lift: lift, solved: solved,
  };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = TrayCore;
