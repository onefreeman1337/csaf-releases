//=============================================================================
// PostureCore.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Posture core - derives sitting, kneeling, lying,
 * sleeping, collapsed, waving and cheering frames from a walking sheet.
 * Place ABOVE Posture.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The pixel rules of Posture. No parameters or commands of its own;
 * Posture.js is the file you configure. Must be installed and listed above
 * Posture.js.
 *
 * Pure logic on RGBA pixel arrays: nothing here touches the screen.
 *
 * HOW A POSE IS MADE. Every pose starts from the character's own STANDING
 * frames (the middle frame of each facing). Posture measures the figure once
 * on the down-facing frame: its top and bottom, its neck (the narrowest row
 * between the head and the shoulders) and its hip (where the two legs part;
 * a long skirt or robe that never parts counts its bottom fifth as legs).
 * A pose then moves, drops, mirrors or turns WHOLE PIXELS of that frame: no
 * pixel is resampled or blended, so nothing blurs and the outline stays the
 * outline. The arms of a wave or cheer are found from the character's own
 * walk (the pixels that swing) and turned up about the shoulder. A sleeper
 * lies in bed seen from above, head on a pillow with the eyes closed, under
 * a quilt in the colour of the character's clothes. The pixels that are not
 * the character's own are the soft contact shadow under a seated, kneeling or
 * lying figure, the book, and the pillow, sheet and quilt, painted in the
 * character's own colours and lighter and darker tints of them.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var PostureCore = (function () {
  'use strict';

  var ALPHA = 16;            // a pixel with alpha above this is part of the figure
  var HEADROOM = 16;         // extra rows above a wave or cheer frame, so raised arms are never cut off by the cell (12 clipped a stock armoured knight's raised arm, Actor2#1)
  var ARMROOM = 8;           // extra columns either side of a wave or cheer frame: an arm raised beside a chibi's wide head leans out past the 48 px cell
  var DIRS = [2, 4, 6, 8];   // sheet rows: down, left, right, up (MZ: characterPatternY = (direction - 2) / 2)
  /**
   * Every pose, and how it is laid out: `facings` = 'four' (one frame per facing), 'lying' (head left on the down and
   * left rows, head right on the right and up rows), 'bed' (in bed seen from above, two tiles tall; the head turns on the
   * pillow with the facing) or 'camera' (the figure turns to the camera on every row);
   * `animated` = the three columns differ (Posture.js cycles them); `seat` = it takes the seat lift.
   */
  var POSES = {
    sit:       { facings: 'four', animated: false, seat: true, shadow: true },
    sitfloor:  { facings: 'four', animated: false, seat: false, shadow: true },
    kneel:     { facings: 'four', animated: false, seat: false, shadow: true },
    read:      { facings: 'four', animated: false, seat: true, shadow: true },
    lie:       { facings: 'lying', animated: false, seat: false, shadow: true },
    sleep:     { facings: 'bed', animated: true, seat: false, shadow: false },
    collapsed: { facings: 'lying', animated: false, seat: false, shadow: true },
    wave:      { facings: 'camera', animated: true, seat: false, shadow: false },
    cheer:     { facings: 'camera', animated: true, seat: false, shadow: false },
  };
  var NAMES = Object.keys(POSES);
  /** how far a front 'sitfloor' spreads the feet either side (legs crossed toward the camera); one reader, exported for the suite */
  function SPREAD(M) { return Math.max(3, Math.round(M.width * 0.12) + 1); }

  // ---- sheet layout, exactly as MZ reads it ---------------------------------------------------------------------
  /** MZ's ImageManager.isBigCharacter: a '$' among the leading '!'/'$' marks makes a one-character sheet. */
  function isBig(name) { var m = /^[!$]+/.exec(String(name || '')); return !!(m && m[0].indexOf('$') >= 0); }
  /** cell size and the character's block origin, as Sprite_Character.patternWidth/characterBlockX compute them */
  function layout(w, h, name, index) {
    var big = isBig(name), cw = Math.floor(big ? w / 3 : w / 12), ch = Math.floor(big ? h / 4 : h / 8), i = big ? 0 : (Number(index) || 0) & 7;
    return { big: big, cw: cw, ch: ch, bx: big ? 0 : (i % 4) * 3, by: big ? 0 : Math.floor(i / 4) * 4 };
  }

  // ---- a cell: a small RGBA grid ---------------------------------------------------------------------------------
  function Cell(w, h) { this.w = w; this.h = h; this.d = new Uint8ClampedArray(w * h * 4); }
  Cell.prototype.a = function (x, y) { return x < 0 || y < 0 || x >= this.w || y >= this.h ? 0 : this.d[(y * this.w + x) * 4 + 3]; };
  Cell.prototype.on = function (x, y) { return this.a(x, y) > ALPHA; };
  /** copy one pixel from another cell (whole pixel, every channel) */
  Cell.prototype.put = function (x, y, src, sx, sy) {
    if (x < 0 || y < 0 || x >= this.w || y >= this.h || !src.on(sx, sy)) return;
    var o = (y * this.w + x) * 4, i = (sy * src.w + sx) * 4;
    this.d[o] = src.d[i]; this.d[o + 1] = src.d[i + 1]; this.d[o + 2] = src.d[i + 2]; this.d[o + 3] = src.d[i + 3];
  };
  Cell.prototype.paint = function (x, y, c) {
    if (x < 0 || y < 0 || x >= this.w || y >= this.h) return;
    var o = (y * this.w + x) * 4; this.d[o] = c[0]; this.d[o + 1] = c[1]; this.d[o + 2] = c[2]; this.d[o + 3] = c[3];
  };
  Cell.prototype.erase = function (x, y) { if (x >= 0 && y >= 0 && x < this.w && y < this.h) this.d[(y * this.w + x) * 4 + 3] = 0; };
  /** copy source rows [r0, r1] to this cell, shifted by (dx, dy) */
  Cell.prototype.rows = function (src, r0, r1, dx, dy) { for (var y = r0; y <= r1; y++) for (var x = 0; x < src.w; x++) this.put(x + dx, y + dy, src, x, y); };
  /** a mirrored copy (facing the other way) */
  Cell.prototype.mirror = function () { var c = new Cell(this.w, this.h); for (var y = 0; y < this.h; y++) for (var x = 0; x < this.w; x++) c.put(this.w - 1 - x, y, this, x, y); return c; };

  /** one frame of a sheet as a Cell (dir 2/4/6/8, pattern 0..2) */
  function frameOf(img, L, dir, pattern) {
    var c = new Cell(L.cw, L.ch), row = L.by + DIRS.indexOf(dir), col = L.bx + pattern;
    for (var y = 0; y < L.ch; y++) for (var x = 0; x < L.cw; x++) {
      var i = (((row * L.ch) + y) * img.width + col * L.cw + x) * 4, o = (y * L.cw + x) * 4;
      c.d[o] = img.data[i]; c.d[o + 1] = img.data[i + 1]; c.d[o + 2] = img.data[i + 2]; c.d[o + 3] = img.data[i + 3];
    }
    return c;
  }

  // ---- measuring the figure ---------------------------------------------------------------------------------------
  /** opaque runs in a row: [[x0, x1], ...] */
  function runs(c, y) { var out = [], x0 = -1; for (var x = 0; x <= c.w; x++) { var on = x < c.w && c.on(x, y); if (on && x0 < 0) x0 = x; if (!on && x0 >= 0) { out.push([x0, x - 1]); x0 = -1; } } return out; }
  function bbox(c) {
    var t = -1, b = -1, l = c.w, r = -1;
    for (var y = 0; y < c.h; y++) for (var x = 0; x < c.w; x++) if (c.on(x, y)) { if (t < 0) t = y; b = y; if (x < l) l = x; if (x > r) r = x; }
    return t < 0 ? null : { top: t, bottom: b, left: l, right: r, height: b - t + 1, width: r - l + 1 };
  }
  /**
   * The body, measured on the standing down-facing frame: bbox, neck (the narrowest row in 30%..62% of the height, ties
   * to the lower row, as in Stature), the hip (the top of the run of rows, rising from just above the feet, in which the
   * figure is two separate runs: the legs), the leg length, and whether the legs are hidden by a skirt (no parting
   * found: the bottom fifth of the figure is used). Returns null for an empty frame.
   */
  function measure(down) {
    var bb = bbox(down); if (!bb) return null;
    /* The neck: follow the head down from its widest row to the narrowest row before the shoulders widen again (3 px or
     * more). ⛔ Stature's "narrowest row in 30%..62% of the height" found the WAIST on a 4-head tall figure (neck 42 of
     * 57 rows, measured 2026-10-08) - a band in fractions of the height is an assumption about proportions, and Posture
     * is sold on characters of any proportion. The old band is kept only as the fallback when no shoulder step exists. */
    var H = bb.height, y, wAt = function (yy) { var rr = runs(down, yy); return rr.length ? rr[rr.length - 1][1] - rr[0][0] + 1 : 0; };
    /* ⛔ Walking down from the head's widest row stops at the first jag in a spiky or layered hairline: on the STOCK RTP
     * cast that put the neck on the FOREHEAD for 23 of 96 characters (Actor1#2 at row 3 of 48; measured 2026-10-09 by
     * Internal_Ops/_probe/neck_compare.js), and a forehead neck lays the sleeping blanket over the face and raises hair
     * as arms. The neck is first sought as the deepest PINCH: a row narrower than the widest row above it (the head) AND
     * than the next rows below it (the shoulders), depth = the smaller of the two steps, ties to the lower row. Only a
     * pinch at least 3 px deep is trusted; a shallower one (long hair hanging past the shoulders hides the neck) falls back
     * to the walk below, which every fixture of the first build was measured with. */
    var pinchY = -1, pinchD = -1, reach = Math.max(3, Math.round(H * 0.25)), maxAbove = 0;
    for (y = bb.top; y < bb.top + Math.floor(H * 0.15); y++) maxAbove = Math.max(maxAbove, wAt(y));
    for (y = bb.top + Math.floor(H * 0.15); y <= bb.top + Math.floor(H * 0.72); y++) {
      var wy = wAt(y), below = 0;
      for (var k2 = y + 1; k2 <= Math.min(bb.bottom, y + reach); k2++) below = Math.max(below, wAt(k2));
      var dep = Math.min(maxAbove - wy, below - wy);
      if (dep >= pinchD) { pinchD = dep; pinchY = y; }
      maxAbove = Math.max(maxAbove, wy);
    }
    var peak = bb.top, pw = 0, lim = bb.top + Math.floor(H * 0.7);
    for (y = bb.top; y <= bb.top + Math.floor(H * 0.5); y++) if (wAt(y) >= pw) { pw = wAt(y); peak = y; } else break;
    var neck = pinchD >= 3 ? pinchY : -1, mn = Infinity, mnY = peak;
    if (neck < 0) for (y = peak; y <= lim; y++) { var wv = wAt(y); if (wv < mn) { mn = wv; mnY = y; } else if (wv >= mn + 3) { neck = mnY; break; } }
    if (neck < 0) {
      var lo = bb.top + Math.floor(H * 0.30), hi = bb.top + Math.ceil(H * 0.62), best = Infinity; neck = lo;
      for (y = lo; y <= hi; y++) { var w = wAt(y); if (w > 0 && w <= best) { best = w; neck = y; } }
    }
    /* The hip is where the figure gets NARROW above the feet: the arms hang beside the torso, so the torso band is wider
     * than the legs. ⛔ Finding it by the gap BETWEEN the legs failed on every fixture (2026-10-08): the outline pass of
     * a pixel-art sheet closes a 1-2 px gap, so "two runs" never appears. Rising from the feet, the legs are the rows no
     * wider than the feet band (+2); the first wider row is the hip line. A skirt or robe that widens toward the floor
     * never shows that step, so it falls back to the bottom fifth of the figure. */
    var spanW = function (yy) { var rr = runs(down, yy); return rr.length ? rr[rr.length - 1][1] - rr[0][0] + 1 : 0; };
    var feetW = Math.max(spanW(bb.bottom - 1), spanW(bb.bottom - 2), spanW(bb.bottom - 3)), hip = bb.bottom;
    for (y = bb.bottom - 1; y > neck + 2; y--) { if (spanW(y) <= feetW + 2) hip = y; else break; }
    var legLen = bb.bottom - hip + 1, skirted = legLen < 3 || legLen > H * 0.45 || spanW(hip - 1) < feetW + 4;
    if (skirted) { legLen = Math.max(3, Math.round(H * 0.2)); hip = bb.bottom - legLen + 1; }
    return { top: bb.top, bottom: bb.bottom, left: bb.left, right: bb.right, height: H, width: bb.width, neck: neck, hip: hip, legLen: legLen, skirted: skirted };
  }

  // ---- the pose builders: each returns one Cell of size (W, ch), feet on the source floor ----------------------------
  /**
   * The columns the legs occupy in a side frame (one block). Measured on the SHINS only - the lower part of the leg band
   * above the feet - because a hanging hand reaches into the top of the band and a foot points forward at the bottom:
   * measuring the whole band made the "thigh" as wide as the torso (first contact sheet, 2026-10-08). The span is the
   * widest single run found there; null if the band is empty.
   */
  function legSpan(c, hip, bottom) {
    var len = bottom - hip + 1, y0 = hip + Math.ceil(len * 0.4), y1 = Math.max(y0, bottom - 2), l = c.w, r = -1;
    for (var y = y0; y <= y1; y++) { var rr = runs(c, y); for (var k = 0; k < rr.length; k++) { if (rr[k][0] < l) l = rr[k][0]; if (rr[k][1] > r) r = rr[k][1]; } }
    return r < 0 ? null : [l, r];
  }

  /**
   * Front or back: drop `drop` rows out of the legs (keeping the hip row and the `keep` feet rows), so the upper body
   * comes down by `drop`, then raise the whole figure by `lift`. `spread` widens the feet (crossed legs on the floor).
   */
  function compressLegs(src, M, W, drop, lift, spread) {
    var out = new Cell(W, src.h), ox = Math.floor((W - src.w) / 2), bb = bbox(src); if (!bb) return out;
    var hip = bb.bottom - M.legLen + 1, keep = Math.max(1, M.legLen - 1 - drop);
    lift = Math.min(lift, Math.max(0, bb.top + drop));   // ⛔ never lift a tall figure out of the top of its cell (TableService server, 2026-10-08)
    out.rows(src, bb.top, hip, ox, drop - lift);                                   // the upper body and the hip row, lowered
    if (spread) { out.rows(src, bb.bottom - keep + 1, bb.bottom, ox - spread, -lift); out.rows(src, bb.bottom - keep + 1, bb.bottom, ox + spread, -lift); }
    out.rows(src, bb.bottom - keep + 1, bb.bottom, ox, -lift);                     // the feet, on the floor (or the seat's edge)
    return out;
  }

  /**
   * Side view, seated. ⛔ The first version turned the thigh a quarter turn; on a chibi sheet the thigh is SHORTER than
   * it is thick (4 rows long, 9 px across on the first fixture), so the turned thigh stood taller than the leg it
   * replaced and pushed the body UP out of the cell (contact sheet, 2026-10-08). Every side pose is now made by sliding
   * whole BLOCKS of rows: the upper body drops onto the lap, the lap slides half a leg forward under it, and the lower
   * legs slide a whole leg forward. `facing` -1 = left, +1 = right. `tuck` = on the floor, legs out in front.
   * ⛔ A skirt or robe is never slid: the independent review (2026-10-08, items 4-5) read a slid hem as a 1 px "fin"
   * sticking out of the figure, so a skirted figure sits by dropping rows, as from the front.
   */
  function sideSit(src, M, W, lift, facing, tuck) {
    if (M.skirted) return compressLegs(src, M, W, tuck ? M.legLen - 2 : M.legLen - Math.max(1, Math.round(M.legLen * 0.35)) - 1, lift, 0);
    var out = new Cell(W, src.h), ox = Math.floor((W - src.w) / 2), bb = bbox(src); if (!bb) return out;
    var hip = bb.bottom - M.legLen + 1, span = legSpan(src, hip, bb.bottom), wL = span ? span[1] - span[0] + 1 : 4;
    var fwd = Math.max(2, Math.round(wL * 0.5)), lapRows = Math.min(2, M.legLen - 1);
    if (tuck) {
      // ⛔ legs out along the floor were a 1 px line with holes (review item 1): the lap rows are the belt and outline.
      // Now the LOWER LEG block (shin and shoe, up to 4 rows: as thick as a standing leg) is laid end to end forward,
      // each copy overlapping the last, and the body sits on top of it.
      var thick = Math.min(4, M.legLen), step = Math.max(2, wL - 1), n = 1;   // two leg blocks end to end (near leg, far leg): more copies repeated the shoe into a smear (core.test, tall)
      for (var k = n; k >= 0; k--) out.rows(src, bb.bottom - thick + 1, bb.bottom, ox + facing * k * step, 0);
      out.rows(src, bb.top, hip - 1, ox, M.legLen - thick);
      return out;
    }
    var keep = Math.max(3, Math.ceil(M.legLen * 0.5)), drop = M.legLen - keep;
    out.rows(src, bb.top, hip - 1, ox, drop - lift);                                         // the upper body, lowered
    out.rows(src, hip, hip + lapRows - 1, ox + facing * Math.ceil(fwd / 2), drop - lift);     // the lap, under it
    out.rows(src, bb.bottom - keep + 1, bb.bottom, ox + facing * fwd, -lift);                // lower legs, forward
    return out;
  }

  /**
   * Front or back, kneeling on ONE knee. ⛔ Dropping both legs evenly made a front kneel the same picture as a front sit
   * (contact sheet, 2026-10-08): from the front, only asymmetry says "kneel". The body drops by half a leg; the right
   * half keeps its full lower leg (the foot planted, knee up); the left half keeps its THIGH, ending on the floor (the
   * knee down, the foot hidden behind). ⛔ The first version kept only the left foot's last 2 rows, which on a tall
   * figure floated a shoe 7 rows below the cut thigh (review item 3).
   */
  function frontKneel(src, M, W) {
    var out = new Cell(W, src.h), ox = Math.floor((W - src.w) / 2), bb = bbox(src); if (!bb) return out;
    var hip = bb.bottom - M.legLen + 1, drop = Math.max(Math.floor(M.legLen / 2), M.legLen - 2), mid = Math.round((bb.left + bb.right) / 2), keepUp = Math.max(2, M.legLen - drop - 1);   // (lower than a chair sit on short chibi legs: review D10)
    out.rows(src, bb.top, hip, ox, drop);
    for (var y = bb.bottom - keepUp + 1; y <= bb.bottom; y++) for (var x = mid; x < src.w; x++) out.put(x + ox, y, src, x, y);   // planted foot
    for (y = hip + 1; y <= hip + Math.max(1, M.legLen - drop - 1); y++) for (x = 0; x < mid; x++) out.put(x + ox, y + drop, src, x, y);   // thigh to the knee, ending ON the floor row
    return out;
  }

  /**
   * The kneeler BOWS: the head (its own rows, top to neck) moves down a row over the neck, and in a side view a column
   * forward too. ⛔ Dropping the legs alone made a front kneel the same picture as a front sit on the stock RTP cast,
   * whose legs are 5 rows long (looked at 2026-10-09): there is nothing left in the legs to say "kneel". A bowed head
   * is the cue a player reads from every facing, including from behind.
   */
  function bow(c, M, side) {
    var cb = bbox(c); if (!cb) return;
    var h = M.neck - M.top + 1, tmp = new Cell(c.w, c.h), x, y;
    for (y = cb.top; y < cb.top + h; y++) for (x = 0; x < c.w; x++) { tmp.put(x, y, c, x, y); c.erase(x, y); }
    // ⛔ a 1-row bow from the front was invisible at 1x (looked at, Actor1#2), and 2 rows still read as "no bow" to the
    // independent review (D11): the head sinks 3 rows into the shoulders from the front and back (a chin on the chest),
    // or drops 2 and leans a column forward in profile
    var down = side ? 2 : 3;
    for (y = cb.top; y < cb.top + h; y++) for (x = 0; x < c.w; x++) c.put(x + (side || 0), y + down, tmp, x, y);
  }

  /** side view, kneeling: the body drops by half a leg, the thigh stays under it, the shins slide BACK along the floor */
  function sideKneel(src, M, W, facing) {
    if (M.skirted) return compressLegs(src, M, W, Math.floor(M.legLen / 2), 0, 0);   // never slide a hem (review items 4-5)
    var out = new Cell(W, src.h), ox = Math.floor((W - src.w) / 2), bb = bbox(src); if (!bb) return out;
    var hip = bb.bottom - M.legLen + 1, span = legSpan(src, hip, bb.bottom), wL = span ? span[1] - span[0] + 1 : 4;
    var drop = Math.floor(M.legLen / 2), back = Math.max(2, Math.round(wL * 0.6)), keep = Math.max(2, M.legLen - drop - 1);
    out.rows(src, bb.bottom - keep + 1, bb.bottom, ox - facing * back, 0);                    // the shins, behind
    out.rows(src, bb.top, hip + 1, ox, drop);                                                 // body and thigh, lowered
    return out;
  }

  /** lying: the figure turned a quarter (head toward -1 = left, +1 = right), resting on the floor row */
  function lying(src, W, ch, head) {
    var bb = bbox(src), out = new Cell(W, ch); if (!bb) return out;
    var floor = bb.bottom, x0 = Math.floor((W - bb.height) / 2), y0 = floor - bb.width + 1;
    for (var y = bb.top; y <= bb.bottom; y++) for (var x = bb.left; x <= bb.right; x++) {
      // head left: source row -> x (top first), source column -> y (right side up); head right: the mirror
      var dx = head < 0 ? y - bb.top : bb.bottom - y, dy = head < 0 ? bb.right - x : x - bb.left;
      out.put(x0 + dx, y0 + dy, src, x, y);
    }
    return out;
  }

  /** the character's palette: every opaque colour of the standing frames with its count, plus a few named picks */
  function palette(cells, M, down) {
    var count = {}, list = [];
    for (var k = 0; k < cells.length; k++) for (var i = 0; i < cells[k].d.length; i += 4) {
      if (cells[k].d[i + 3] <= ALPHA) continue;
      var key = cells[k].d[i] + ',' + cells[k].d[i + 1] + ',' + cells[k].d[i + 2] + ',' + cells[k].d[i + 3];
      if (!count[key]) { count[key] = 0; list.push(key); } count[key]++;
    }
    var col = function (key) { return key.split(',').map(Number); };
    var luma = function (c) { return 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]; };
    var opaque = list.map(col).filter(function (c) { return c[3] === 255; });
    var dark = opaque.reduce(function (a, c) { return !a || luma(c) < luma(a) ? c : a; }, null);
    var light = opaque.reduce(function (a, c) { return !a || luma(c) > luma(a) ? c : a; }, null);
    // colours of the head (rows top..neck of the down frame): skin and hair, which a pillow must not be (review item 14)
    var headCols = {};
    if (M) for (var hy = M.top; hy <= M.neck; hy++) for (var hx = 0; hx < down.w; hx++) { var ho = (hy * down.w + hx) * 4; if (down.d[ho + 3] > ALPHA) headCols[down.d[ho] + ',' + down.d[ho + 1] + ',' + down.d[ho + 2] + ',' + down.d[ho + 3]] = 1; }
    // the clothing colour: the most frequent opaque colour in the torso band of the down frame (neck..hip), not a head colour
    /* ⛔ An exact-colour exclusion let the NECK's skin (a shade the face does not use) win the torso band, and the quilt
     * came out skin-coloured on the stock RTP cast (Actor1#2, looked at 2026-10-09). Skin is excluded by HUE (warm and
     * light), and so is anything within a near shade of a head colour, and the outline darks. */
    var tc = {}, best = null, warmLight = function (r, g, b) { return r >= g && g >= b && r - b >= 28 && r - b <= 160 && r >= 150; };
    var headList = Object.keys(headCols).map(col);
    // ⛔ and only the torso's CENTRE columns: the whole band let the arms' gilt shoulder plates win over the shirt (Actor1#2's
    // quilt came out gold; looked at 2026-10-09)
    var cx0 = M ? M.left + Math.round(M.width * 0.3) : 0, cx1 = M ? M.right - Math.round(M.width * 0.3) : -1;
    if (M) for (var y = M.neck + 1; y < M.hip; y++) for (var x = cx0; x <= cx1; x++) {
      var o = (y * down.w + x) * 4; if (down.d[o + 3] !== 255) continue;
      var kk = down.d[o] + ',' + down.d[o + 1] + ',' + down.d[o + 2] + ',255'; if (headCols[kk]) continue;
      if (tc[kk] === undefined) {
        var cc = col(kk), bad = warmLight(cc[0], cc[1], cc[2]) || luma(cc) < 40;
        for (var hi = 0; hi < headList.length && !bad; hi++) if (dist(cc, headList[hi]) < 24) bad = true;
        tc[kk] = bad ? -1 : 0;
      }
      if (tc[kk] < 0) continue;
      tc[kk]++;
      if (!best || tc[kk] > tc[best]) best = kk;
    }
    var cloth = best ? col(best) : light;
    var fold = opaque.filter(function (c) { return luma(c) < luma(cloth) && luma(c) > luma(dark); }).sort(function (a, b) { return dist(a, cloth) - dist(b, cloth); })[0] || dark;
    // linen (pillow, pages, the turned-down sheet): the lightest colour that is not on the head and not the cloth itself
    var linen = opaque.filter(function (c) { var kk2 = c.join(','); return !headCols[kk2] && dist(c, cloth) > 40; }).reduce(function (a, c) { return !a || luma(c) > luma(a) ? c : a; }, null) || light;
    return { colours: list, dark: dark, light: light, cloth: cloth, fold: fold, linen: linen };
  }
  function dist(a, b) { return Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]) + Math.abs(a[2] - b[2]); }

  /** a colour `t` of the way from `c` toward `to` (whole channels; a tint of the character's own colour) */
  function mix(c, to, t) { return [Math.round(c[0] + (to[0] - c[0]) * t), Math.round(c[1] + (to[1] - c[1]) * t), Math.round(c[2] + (to[2] - c[2]) * t), 255]; }
  function luma3(c) { return 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]; }

  /**
   * SLEEP, IN BED, seen from above: the stock MZ beds stand UPRIGHT on the map (pillow at the top tile, the foot on the
   * tile below), so a sleeper lies head-up, not on its side. ⛔ v1 laid the figure on its side with a striped blanket
   * beside the head: on the stock RTP cast it read as "a head beside a door", in skin colour more than once (looked at
   * 2026-10-09). The cell is TWO tiles tall (MZ anchors a character at its feet, so the event stands on the bed's FOOT
   * tile and the picture rises over the pillow tile): a pillow, the character's own head on it with the eyes closed
   * (closeEyes), the turned-down sheet across the chin, and a quilt over the body to the foot of the bed, in the
   * character's clothing colour with its own light and shade, a ridge where the body lies under it and the feet at the
   * end. `breath` 1 raises the sheet and the chest a pixel: the breath in.
   */
  function inBed(down, M, pal, W, ch, breath, headSrc, profile) {
    var out = new Cell(W, ch), head = closeEyes(headSrc || down, M, pal, !!profile), x, y;
    var hb = { l: down.w, r: -1 };
    for (y = M.top; y <= M.neck; y++) { var rr = runs(down, y); if (rr.length) { hb.l = Math.min(hb.l, rr[0][0]); hb.r = Math.max(hb.r, rr[rr.length - 1][1]); } }
    var ox = Math.floor((W - down.w) / 2), hl = hb.l + ox, hr = hb.r + ox, hcx = (hl + hr) / 2, hw = hr - hl + 1;
    // ⛔ MZ draws a character 6 px above its tile's foot (Game_CharacterBase.shiftY), so a pillow at the cell's top stood
    // 4 px proud of a two-tile bed's head (looked at in the engine, 2026-10-09): the pillow starts 8 px down, which puts it
    // 2 px inside the bed, and the head 13 px down
    var PT = 8, dy = PT + 5 - M.top, chinRow = Math.max(M.neck, head.faceBottom > 0 ? head.faceBottom : M.neck), chin = chinRow + dy;   // the sheet folds at the face's bottom (closeEyes), never above the measured neck
    // the torso's width, for the quilt
    var tl = down.w, tr = -1; for (y = M.neck + 1; y < M.hip; y++) { var r2 = runs(down, y); if (r2.length) { tl = Math.min(tl, r2[0][0]); tr = Math.max(tr, r2[r2.length - 1][1]); } }
    var bodyW = tr >= tl ? tr - tl + 1 : hw;
    // colours: linen (pillow, sheet) is the character's lightest non-head colour, lifted toward white if it is dark;
    // the quilt is the clothing colour, a lighter and a darker tint of it for light and shade; the outline is the darkest
    var ink = pal.dark, cloth = pal.cloth, lit = mix(cloth, [255, 250, 235], 0.28), shade = mix(cloth, ink, 0.35), deep = mix(cloth, ink, 0.6);
    // ⛔ a linen taken as-is came out YELLOW or PINK on half the cast (the lightest colour of a blonde or a pink dress):
    // the pillow and sheet are always near-white, only tinted by the character's linen
    var linen = mix(pal.linen, [246, 243, 234], 0.92), linenShade = mix(linen, cloth, 0.22);   // (0.8 left pink pillows that merged with the face: review D6)
    var qt0 = chin;   // the sheet folds over at the neck row: the chin stays above it
    // 1) the pillow: a rounded slab behind the head, wider than it, down to the quilt (⛔ a pillow shorter than the head
    //    left the background showing beside a narrow neck, between the pillow and the quilt: looked at, Actor1#5)
    var pw = Math.min(W - 2, hw + 8), pl = Math.round(hcx - pw / 2), pr = pl + pw - 1, pt = PT, pbm = qt0 + 1;
    for (y = pt; y <= pbm; y++) for (x = pl; x <= pr; x++) {
      var cy = Math.min(y - pt, pbm - y), cxd = Math.min(x - pl, pr - x); if (cy + cxd < 2 && !(cy >= 1 && cxd >= 1)) continue;   // rounded corners
      var edge = y === pt || y === pbm || x === pl || x === pr || (cy + cxd === 2 && (cy === 0 || cxd === 0));
      out.paint(x, y, edge ? ink : (y >= pbm - 2 || x >= pr - 1) ? linenShade : linen);
    }
    // 2) the head on it
    for (y = M.top; y <= chinRow + 1; y++) for (x = 0; x < down.w; x++) out.put(x + ox, y + dy, head, x, y);
    // 3) the quilt, from the chin to the foot of the bed
    var qw = Math.min(W - 2, Math.max(hw - 2, bodyW + 10)), ql = Math.round(hcx - qw / 2), qr = ql + qw - 1, qt = qt0 - (breath ? 1 : 0), qb = ch - 2;
    /* ⛔ v1 of this quilt drew the body's ridge with a lit and a shaded 2 px COLUMN either side: two hard vertical lines
     * down a rectangle read as a WARDROBE DOOR (looked at 2026-10-09). The body is now a soft lift only: the quilt over
     * it is a half-tint lighter, with no line at its edge, and the stitch runs across it. */
    var ridgeL = Math.round(hcx - bodyW * 0.3), ridgeR = Math.round(hcx + bodyW * 0.3), soft = mix(cloth, lit, 0.45), softStitch = mix(shade, soft, 0.4);
    for (y = qt; y <= qb; y++) for (x = ql; x <= qr; x++) {
      var cyb = qb - y, cxq = Math.min(x - ql, qr - x); if (cyb < 2 && cxq < 2 && cyb + cxq < 2) continue;   // rounded foot corners
      var c, onBody = x >= ridgeL && x <= ridgeR && y < qb - 4, stitch = (((x - ql) + (y - qt)) % 8 === 0 || ((x - ql) - (y - qt) + 800) % 8 === 0) && y > qt + 5;
      if (y === qt || x === ql || x === qr || y === qb || (cyb + cxq === 2 && (cyb === 0 || cxq === 0))) c = ink;
      else if (y <= qt + 3) c = y === qt + 3 ? linenShade : linen;                       // the turned-down sheet
      else if (y === qt + 4) c = deep;                                                   // its shadow on the quilt
      else if (x >= qr - 1 || y >= qb - 1) c = shade;                                    // the quilt's far side and foot fall away
      else if (x === ql + 1) c = lit;                                                    // the near edge catches the light
      else if (stitch) c = onBody ? softStitch : shade;                                  // a quilted diamond stitch
      else c = onBody ? soft : cloth;                                                    // the body lifts the quilt: a half-tint, no edge line
      out.paint(x, y, c);
    }
    // the chest rises with the breath: the lift brightens a row under the sheet's shadow
    if (breath) for (x = ridgeL + 1; x < ridgeR; x++) out.paint(x, qt + 5, lit);
    out.eyes = head.eyes || 'no face';
    out.tints = [ink, cloth, lit, shade, deep, linen, linenShade, soft, softStitch].map(function (q) { return q[0] + ',' + q[1] + ',' + q[2] + ',' + (q[3] === undefined ? 255 : q[3]); });
    return out;
  }

  /**
   * Close the eyes of a down-facing frame (for sleep). The face is the run of SKIN between the hair and the chin; the
   * eyes are the two clusters of non-skin pixels enclosed by skin in the upper face, one either side of its centre,
   * of eye size. Each is painted over in the skin colour of the row and given a lid: a dark curve along its lower third.
   * Returns a new Cell; when no face or no pair of eyes is found the frame is returned unchanged (a helmet, a mask, a
   * back-facing sheet) - the pose still reads as asleep from the pillow and the quilt.
   */
  function closeEyes(src, M, pal, single) {
    var c = new Cell(src.w, src.h); c.d.set(src.d);
    // skin: warm and light, and neither SATURATED red nor yellow (⛔ a red or a yellow dress passed "warm and light" and the
    // sleeper's sheet folded at the waist, Townsfolk#1 and Bighead#4; looked at 2026-10-09): green at least 0.6 of red,
    // blue at least 0.42 of red
    var isSkin = function (r, g, b) { return r >= g && g >= b && r - b >= 28 && r - b <= 160 && r >= 150 && g >= 0.6 * r && b >= 0.42 * r; };
    var count = {}, skinKey = null, x, y, i;
    for (y = M.top; y <= M.neck; y++) for (x = 0; x < src.w; x++) {
      i = (y * src.w + x) * 4; if (src.d[i + 3] < 200 || !isSkin(src.d[i], src.d[i + 1], src.d[i + 2])) continue;
      var k = src.d[i] + ',' + src.d[i + 1] + ',' + src.d[i + 2]; count[k] = (count[k] || 0) + 1; if (!skinKey || count[k] > count[skinKey]) skinKey = k;
    }
    if (!skinKey || count[skinKey] < 12) { c.eyes = 'no skin'; return c; }
    /* ⛔ "near the commonest skin colour" left the cheek SHADING out of the face, which joined each eye to the jaw line
     * and made it too wide to be an eye (Actor1#2, face_map.js 2026-10-09): skin is judged by HUE (warm, light), so
     * every shade of the face counts as face. */
    var skin = skinKey.split(',').map(Number).concat(255), near = function (j) { return src.d[j + 3] >= 200 && isSkin(src.d[j], src.d[j + 1], src.d[j + 2]); };
    // the face rows: rows with at least 3 skin-ish pixels; the face's centre column from them
    var f0 = -1, f1 = -1, sx = 0, sn = 0;
    for (y = M.top; y <= M.neck; y++) { var n = 0; for (x = 0; x < src.w; x++) if (near((y * src.w + x) * 4)) { n++; sx += x; sn++; } if (n >= 3) { if (f0 < 0) f0 = y; f1 = y; } }
    if (f0 < 0 || f1 - f0 < 5) { c.eyes = 'no face'; return c; }
    /* the FACE'S BOTTOM, for the sleeper's sheet line: the last row, down to 60% of the head's height past the measured
     * neck, with skin in the head's central columns. ⛔ A crown or hood narrower than the head below it is a "pinch", so
     * the measured neck can sit at the hat's brim and the sheet then covered the whole face (People3#0: a crown on a
     * quilt; independent review 2026-10-09, D3). The hands are skin too, so only the central columns count. */
    { var hh = Math.max(1, M.neck - M.top), cxa = Math.round(sx / sn - hh * 0.25), cxb = Math.round(sx / sn + hh * 0.25), fb = -1;
      for (y = M.top; y <= Math.min(src.h - 1, M.neck + Math.round(hh * 0.6)); y++) { var ns = 0; for (x = Math.max(0, cxa); x <= Math.min(src.w - 1, cxb); x++) if (near((y * src.w + x) * 4)) ns++; if (ns >= 2) fb = y; else if (fb >= 0 && y > M.neck) break; }
      // a head is never more than 62% of a sprite's height (the stock chibis run 55-60%): the witch's cream bodice passed
      // the skin test down to her hem (faceBottom 47 of 48) until this cap
      c.faceBottom = Math.min(fb, M.top + Math.round(M.height * 0.62)); }
    var fcx = sx / sn, cand = new Uint8Array(src.w * src.h);
    for (y = f0; y <= f1; y++) {
      var a = -1, b = -1; for (x = 0; x < src.w; x++) if (near((y * src.w + x) * 4)) { if (a < 0) a = x; b = x; }
      for (x = a + 1; x < b; x++) { i = (y * src.w + x) * 4; if (src.d[i + 3] > ALPHA && !near(i)) cand[y * src.w + x] = 1; }
    }
    // clusters of candidates, 4-connected; an eye is 2..8 wide, 2..9 tall, enclosed (its top row is skin or bangs, its bottom row skin)
    var seen = new Uint8Array(src.w * src.h), eyes = [];
    for (y = f0; y <= f1; y++) for (x = 0; x < src.w; x++) {
      var s0 = y * src.w + x; if (!cand[s0] || seen[s0]) continue;
      var st = [s0], px = [], l = x, r = x, t = y, bt = y; seen[s0] = 1;
      while (st.length) { var p = st.pop(), qx = p % src.w, qy = (p - qx) / src.w; px.push(p); if (qx < l) l = qx; if (qx > r) r = qx; if (qy < t) t = qy; if (qy > bt) bt = qy;
        var nb = [qx > 0 ? p - 1 : -1, qx < src.w - 1 ? p + 1 : -1, p - src.w, p + src.w];
        for (var q = 0; q < 4; q++) { var z = nb[q]; if (z >= 0 && z < cand.length && cand[z] && !seen[z]) { seen[z] = 1; st.push(z); } } }
      var w = r - l + 1, h = bt - t + 1;
      if (w <= 9 && h <= 10 && t > f0 && bt < f1 - 1) eyes.push({ l: l, r: r, t: t, b: bt, n: px.length, px: px, cx: (l + r) / 2 });
    }
    /* ⛔ "the biggest cluster on each side" took a gap in the HAIRLINE for an eye on 56 of 116 characters (face_map.js
     * --all, 2026-10-09) while the real pair sat lower. The eyes are the best PAIR: one each side of the face's centre,
     * level with each other (tops and bottoms within 2 rows), alike in size, mirrored about the centre (within 3 px);
     * among pairs that qualify, the largest. A centred mouth has no partner, so it can never be chosen. */
    /* ⛔ A level, mirrored pair is not yet a pair of EYES: on the stock cast the first pairing closed side-locks, a hair
     * parting and a collar (Actor1#1 rows 9-12, Actor1#6 columns 8-15, Actor1#5 rows 32-33; face_map.js -v,
     * 2026-10-09). Eyes sit in a band of the HEAD: their centre 42%..90% of the way from its top to the neck, no further
     * from the face's centre than a third of the head's width, and on a head 22+ rows tall at least 3 rows tall. */
    var hTop = M.top, hH = Math.max(1, M.neck - M.top), hb0 = src.w, hb1 = -1;
    for (y = M.top; y <= M.neck; y++) { var rh = runs(src, y); if (rh.length) { hb0 = Math.min(hb0, rh[0][0]); hb1 = Math.max(hb1, rh[rh.length - 1][1]); } }
    var hW = hb1 - hb0 + 1, minH = hH >= 22 ? 2 : 1;   // (3 on a big head dropped CSAF_Bighead's 1 x 2 dot eyes: a big head is not a big eye)
    /* ⛔ and an eye is not made of HAIR: a pigtailed girl's fringe strands passed every test above and got the lids while
     * her green eyes stayed open below them (People1#1, looked at 2026-10-09). A cluster most of whose pixels are colours
     * of the crown (the head's top 30%) is hair. */
    var crown = {}; for (y = M.top; y < M.top + Math.round(hH * 0.3); y++) for (x = 0; x < src.w; x++) { i = (y * src.w + x) * 4; if (src.d[i + 3] > ALPHA) crown[src.d[i] + ',' + src.d[i + 1] + ',' + src.d[i + 2]] = 1; }
    // (the near-black outline colour is shared by hair and eyes alike, so it votes neither way: a dot eye drawn in the
    // outline colour is still an eye - CSAF_Townsfolk lost all eight closed eyes until this, 2026-10-09)
    var hairy = function (e) { if (!e.px) return false; var n = 0, m = 0; for (var q = 0; q < e.px.length; q++) { var o = e.px[q] * 4; if (luma3([src.d[o], src.d[o + 1], src.d[o + 2]]) < 60) continue; m++; if (crown[src.d[o] + ',' + src.d[o + 1] + ',' + src.d[o + 2]]) n++; } return m > 0 && n > m * 0.5; };
    var eyeOk = function (e) { var v = ((e.t + e.b) / 2 - hTop) / hH, d = Math.abs(e.cx - fcx); return v >= 0.42 && v <= 0.9 && (single ? d <= hW / 2 : d >= 2 && d <= hW / 3) && e.b - e.t + 1 >= minH && !hairy(e); };
    eyes = eyes.filter(eyeOk);
    if (single) {
      // a face in PROFILE (the sleeper's head turned on the pillow) shows one eye: the largest eye-sized cluster
      var only = null;
      for (i = 0; i < eyes.length; i++) { var sw = eyes[i].r - eyes[i].l + 1, shh = eyes[i].b - eyes[i].t + 1; if (sw <= 7 && shh <= 8 && (!only || eyes[i].n > only.n)) only = eyes[i]; }
      if (!only) { c.eyes = 'no eye (profile, ' + eyes.length + ' clusters)'; return c; }
      shut(c, only, skin, pal.dark); c.eyes = 'closed'; c.eyeBoxes = only.l + '-' + only.r + 'x' + only.t + '-' + only.b; c.face = [f0, f1];
      return c;
    }
    var L = null, R = null, bestS = -1;
    for (i = 0; i < eyes.length; i++) for (var j2 = 0; j2 < eyes.length; j2++) {
      var a2 = eyes[i], b3 = eyes[j2]; if (a2.cx >= fcx || b3.cx <= fcx) continue;
      if (Math.abs(a2.t - b3.t) > 2 || Math.abs(a2.b - b3.b) > 2 || Math.min(a2.n, b3.n) < Math.max(a2.n, b3.n) * 0.5) continue;
      if (Math.abs((a2.cx + b3.cx) / 2 - fcx) > 3 || b3.cx - a2.cx < 4) continue;
      var sc = a2.n + b3.n; if (sc > bestS) { bestS = sc; L = a2; R = b3; }
    }
    if (!L || !R) {
      /* ⛔ On a stock RTP face the BANGS hang into the eyes, and brown or blond hair is warm enough to pass the skin test,
       * so the eye joins the hair and no cluster is eye-shaped (Actor1#0, face_map.js 2026-10-09). The fallback finds the
       * IRIS instead: the one cool or saturated colour that sits on both sides of the face, level and eye-sized. */
      var pair = irisPair(src, f0, f1, fcx, isSkin, function (q) { return eyeOk({ t: q.t, b: q.b, cx: (q.l + q.r) / 2 }); });
      if (pair) { L = pair[0]; R = pair[1]; }
    }
    if (!L || !R) {
      /* One eye found clean and its partner lost in the bangs (Actor2#4: 27-31 x 21-25 found, the left eye joined to a
       * side lock): a front-facing face is drawn mirrored, so the partner is the MIRROR of the found box about the face's
       * centre, and its eye pixels are the non-skin pixels inside that box - if there are at least half as many. */
      var one = null;
      // only an EYE-SIZED cluster is mirrored (⛔ the witch's eye joined to her fringe, 9 x 8 px, was mirrored into a pair
      // of skin-coloured goggles: looked at, Actor1#5)
      for (i = 0; i < eyes.length; i++) { var ew = eyes[i].r - eyes[i].l + 1, eh = eyes[i].b - eyes[i].t + 1; if (ew >= 3 && ew <= 7 && eh <= 7 && eyes[i].n <= ew * eh && (!one || eyes[i].n > one.n)) one = eyes[i]; }
      if (one) {
        var m = { l: Math.round(2 * fcx - one.r), r: Math.round(2 * fcx - one.l), t: one.t, b: one.b, px: [] };
        for (y = m.t; y <= m.b; y++) for (x = Math.max(0, m.l); x <= Math.min(src.w - 1, m.r); x++) { i = (y * src.w + x) * 4; if (src.d[i + 3] > ALPHA && !near(i)) m.px.push(y * src.w + x); }
        m.n = m.px.length; m.cx = (m.l + m.r) / 2;
        if (m.n >= one.n * 0.5 && m.l >= 0 && m.r < src.w && !hairy(m)) { if (one.cx < fcx) { L = one; R = m; } else { L = m; R = one; } }
      }
    }
    if (!L || !R) {   // not a pair: leave the face alone
      c.eyes = 'no pair (' + eyes.length + ' clusters: ' + eyes.map(function (e) { return e.l + '-' + e.r + 'x' + e.t + '-' + e.b + ':' + e.n; }).join(' ') + '; face rows ' + f0 + '-' + f1 + ', centre ' + fcx.toFixed(1) + ')';
      return c;
    }
    /* ⛔ On a stock face the upper half of an eye can join the fringe, leaving only its lower rows as the "cluster": the
     * witch (Actor1#5) was closed over rows 23-24 of eyes that run 21-25, and read as goggles (looked at 2026-10-09). On
     * a big head a found eye is GROWN to the stock eye's height (5 rows, upward from its bottom) within its own columns,
     * taking every non-skin pixel that is not a crown (hair) colour - the lashes and the iris, never the fringe. */
    if (hH >= 22) [L, R].forEach(function (e) {
      if (e.r - e.l < 2 || e.b - e.t >= 4) return;
      var have = {}, t0 = e.t, top = e.t; for (var q = 0; q < e.px.length; q++) have[e.px[q]] = 1;
      for (var yy = Math.max(f0, e.b - 4); yy < t0; yy++) for (var xx = e.l; xx <= e.r; xx++) {
        var j = yy * src.w + xx, o = j * 4; if (have[j] || src.d[o + 3] <= ALPHA || near(o)) continue;
        if (luma3([src.d[o], src.d[o + 1], src.d[o + 2]]) >= 60 && crown[src.d[o] + ',' + src.d[o + 1] + ',' + src.d[o + 2]]) continue;
        e.px.push(j); have[j] = 1; if (yy < top) top = yy;
      }
      e.t = top;
      // and down, while a row below still holds iris (non-skin, non-hair) pixels in the eye's columns: the iris's foot
      // was left showing under the lid on Actor1#1 and Actor1#3 (looked at)
      for (var dn = 1; dn <= 2 && e.b + 1 <= f1; dn++) {
        var row = [];
        for (xx = e.l; xx <= e.r; xx++) { j = (e.b + 1) * src.w + xx; o = j * 4; if (src.d[o + 3] > ALPHA && !near(o) && !(luma3([src.d[o], src.d[o + 1], src.d[o + 2]]) >= 60 && crown[src.d[o] + ',' + src.d[o + 1] + ',' + src.d[o + 2]])) row.push(j); }
        if (!row.length) break;
        for (q = 0; q < row.length; q++) e.px.push(row[q]); e.b++;
      }
    });
    shut(c, L, skin, pal.dark); shut(c, R, skin, pal.dark);
    c.eyes = 'closed';
    c.eyeBoxes = [L, R].map(function (e) { return e.l + '-' + e.r + 'x' + e.t + '-' + e.b; }).join(' ');
    c.face = [f0, f1];
    return c;
  }

  /** paint one found eye shut: its pixels in the skin colour, then a lid along its lower third, ends lifted (a dot eye
   *  closes to a dash wider than the dot) */
  function shut(c, e, skin, lid) {
    for (var j = 0; j < e.px.length; j++) { var pp = e.px[j]; c.d[pp * 4] = skin[0]; c.d[pp * 4 + 1] = skin[1]; c.d[pp * 4 + 2] = skin[2]; c.d[pp * 4 + 3] = 255; }
    var ly = e.b - Math.floor((e.b - e.t + 1) / 3), small = e.r - e.l < 2, l0 = small ? e.l - 1 : e.l, r0 = small ? e.r + 1 : e.r;
    for (var xx = l0; xx <= r0; xx++) c.paint(xx, (xx === l0 || xx === r0) && r0 - l0 >= 3 ? ly - 1 : ly, lid);
  }

  /**
   * The eyes found by their IRIS colour (closeEyes' fallback): among the face rows, every colour that is not skin, not
   * near-grey and not near-black is counted on each side of the face's centre; the iris is the colour present on BOTH
   * sides (2+ px each) in eye-sized boxes (<= 7 wide, <= 8 tall) whose tops are level within 2 rows, the most plentiful
   * such colour winning. Each eye is that box widened 1 px and raised 2 rows (the lashes); inside it, every pixel that is
   * not skin-hued is the eye's (iris, white, lash) and is painted over. Returns [left, right] or null.
   */
  function irisPair(src, f0, f1, fcx, isSkin, ok) {
    var W = src.w, cnt = {}, x, y, i;
    for (y = f0; y <= f1; y++) for (x = 0; x < W; x++) {
      i = (y * W + x) * 4; if (src.d[i + 3] < 200) continue;
      var r = src.d[i], g = src.d[i + 1], b = src.d[i + 2], mx = Math.max(r, g, b), mn = Math.min(r, g, b);
      if (isSkin(r, g, b) || mx - mn < 45 || mx < 70) continue;
      var k = r + ',' + g + ',' + b, s = x < fcx ? 0 : 1, e = cnt[k] || (cnt[k] = [{ n: 0, l: W, r: -1, t: 99, b: -1 }, { n: 0, l: W, r: -1, t: 99, b: -1 }]), q = e[s];
      q.n++; if (x < q.l) q.l = x; if (x > q.r) q.r = x; if (y < q.t) q.t = y; if (y > q.b) q.b = y;
    }
    var best = null, bn = 0;
    Object.keys(cnt).forEach(function (k) {
      var a = cnt[k][0], b2 = cnt[k][1]; if (a.n < 2 || b2.n < 2) return;
      if (a.r - a.l > 6 || b2.r - b2.l > 6 || a.b - a.t > 7 || b2.b - b2.t > 7 || Math.abs(a.t - b2.t) > 2) return;
      if (Math.abs((a.l + a.r) / 2 + (b2.l + b2.r) / 2 - 2 * fcx) > 6) return;   // mirrored about the face's centre
      if (ok && !(ok(a) && ok(b2))) return;                                       // where eyes sit on a head (closeEyes' band)
      if (a.n + b2.n > bn) { bn = a.n + b2.n; best = [a, b2]; }
    });
    if (!best) return null;
    return best.map(function (q) {
      var e = { l: Math.max(0, q.l - 1), r: Math.min(W - 1, q.r + 1), t: Math.max(0, q.t - 2), b: q.b, px: [] };
      for (var yy = e.t; yy <= e.b; yy++) for (var xx = e.l; xx <= e.r; xx++) {
        var j = (yy * W + xx) * 4; if (src.d[j + 3] > ALPHA && !isSkin(src.d[j], src.d[j + 1], src.d[j + 2])) e.px.push(yy * W + xx);
      }
      e.n = e.px.length; e.t = q.t; return e;
    });
  }

  /**
   * A book held in both hands in front of the body. ⛔ The first book was 3 x 2 px of white at the thighs or the toe and
   * read as white shoes (review item 9). Now: open pages (two light pages, a dark spine, a dark rim) 10 x 6 seen from the
   * front, a closed book 4 x 7 held up at the front edge of the body from the side, both at the hands (the lower torso).
   */
  function book(cell, cx, cy, facing, pal) {
    // ⛔ the side book was a 4 x 7 closed block at the hip: "a box, a phone or a purse" (independent review 2026-10-09,
    // D15). From the side the book is now held OPEN at the chest, 7 x 5, pages towards the reader's face: two light
    // pages either side of a dark spine, lines of text on the pages
    var w = facing === 0 ? 10 : 7, h = facing === 0 ? 6 : 5, x0 = facing === 0 ? cx - 5 : facing < 0 ? cx - w + 1 : cx, x, y;
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) {
      var edge = y === 0 || y === h - 1 || x === 0 || x === w - 1, spine = facing === 0 ? (x === 4 || x === 5) : x === 3;
      cell.paint(x0 + x, cy + y, edge ? pal.dark : spine ? pal.fold : (y % 2 === 1 && x > 0 && x < w - 1 ? pal.fold : pal.linen));
    }
  }

  /**
   * The arm on one side of a front-facing frame: its columns, and its rows from the shoulder to the bottom of the HAND.
   * ⛔ v1 stopped at a third of the figure, which left the walking frame's hand behind at the hip (review item 20); the
   * block now runs to two rows below the hip (the hand) - or, on a robe whose "hip" is the hem, to 40% of the figure.
   */
  function armBlock(src, M, side) {
    var bb = bbox(src); if (!bb) return null;
    var walked = M.arms && M.arms[side < 0 ? 0 : 1]; if (walked) return walked;
    var aw = Math.max(2, Math.round(bb.width * 0.2)), x0 = side < 0 ? bb.left : bb.right - aw + 1;
    var y1 = M.skirted ? M.neck + Math.round(M.height * 0.4) : M.hip + 2;
    return { x0: x0, x1: x0 + aw - 1, y0: M.neck + 1, y1: Math.min(bb.bottom, y1) };
  }
  /**
   * The ARMS, found from the character's own walk: the pixels that differ between walk frames 0 and 2 of the down row,
   * above the hip, on each side of the body's centre line, ARE the swinging arms. ⛔ A fixed block (20% of the figure's
   * width from the neck down) grabbed HAIR on the stock RTP cast and raised it as arms (MEASURED 2026-10-09 on Actor1;
   * Internal_Ops/_probe/arm_diff.js showed two clean blocks either side of a static torso column, e.g. Actor1#0 columns
   * 9-16 and 30-38, rows 28-40). Returns [left, right] blocks (or null for a side whose walk does not swing an arm, which
   * then falls back to the fixed block). Run once per character, at derive time.
   */
  function armsFromWalk(down, w0, w2, M) {
    var bb = bbox(down); if (!bb || !w0 || !w2) return null;
    /* ⛔ The stock RTP walk BOBS the whole body a pixel between the standing frame and frames 0 and 2 (MEASURED
     * 2026-10-09, Internal_Ops/_probe/arm_map.js: unaligned, every torso pixel "moved"; aligned at dy=1, the torso is
     * static and only the arms and legs move). A bounding box of the unaligned difference took the TORSO as the arms,
     * and raising both arms for a cheer erased the body down to a dotted pole. So: align each walk frame first, mark the
     * standing pixels that differ from BOTH alignments' counterparts, and keep the connected groups that reach the
     * figure's outer edge on each side (an arm hangs at the silhouette; a fold or buckle inside the torso does not). */
    var W = down.w, d0 = bobOf(down, w0, M), d2 = bobOf(down, w2, M), yLo = M.neck + 1, yHi = Math.min(down.h - 1, M.bottom - 3, M.hip + 4);   // hands hang past a chibi's measured hip (CSAF_Bighead#0: hip 38, hands 40-42); the feet's rows never count
    var moving = new Uint8Array(W * down.h), x, y;
    for (y = yLo; y <= yHi; y++) for (x = 0; x < W; x++) if (down.on(x, y) && (differs(down, w0, x, y, d0) || differs(down, w2, x, y, d2))) moving[y * W + x] = 1;
    /* ⛔ A connected group of moving pixels is not an arm: on People1#2 the shirt's HEM swings too and joins the two
     * hands across the body, so one "arm" spanned columns 15..37 and was raised as a long rod (looked at 2026-10-09).
     * An arm is the OUTER run of each row: from the row's outermost inked pixel, if it moves, inward while the pixels
     * keep moving; the first still pixel (the torso's outline) ends it. The arm is the rows' runs, and only the largest
     * group of them that touch row to row (a stray moving pixel lower down is not part of it). */
    var cx = (bb.left + bb.right) / 2, masks = [null, null], k;
    for (var sd = 0; sd < 2; sd++) {
      var rowsHit = [];
      for (y = yLo; y <= yHi; y++) {
        var e = -1;
        if (sd === 0) { for (x = 0; x < cx; x++) if (down.on(x, y)) { e = x; break; } }
        else { for (x = W - 1; x > cx; x--) if (down.on(x, y)) { e = x; break; } }
        if (e < 0 || !moving[y * W + e]) { rowsHit.push(null); continue; }
        // ⛔ a CAPE or skirt that swings with the walk made the whole lower body "move" (Actor1#1: arms 8-22 and 23-38, the
        // cheer erased the torso; looked at 2026-10-09): an arm is never wider than 28% of the figure, nor below 45% of
        // its height past the neck on a skirted figure
        var a = e, b2 = e, step = sd === 0 ? 1 : -1, maxW = Math.max(4, Math.round(bb.width * 0.28));
        if (M.skirted && y > M.neck + Math.round(M.height * 0.45)) { rowsHit.push(null); continue; }
        while (moving[y * W + b2 + step] && (sd === 0 ? b2 + step < cx : b2 + step > cx) && Math.abs(b2 + step - e) < maxW) b2 += step;
        rowsHit.push(sd === 0 ? [a, b2] : [b2, a]);
      }
      // the longest stretch of consecutive rows whose runs overlap row to row
      var best = null, cur = null;
      for (var ri = 0; ri < rowsHit.length; ri++) {
        var run = rowsHit[ri], prev = ri > 0 ? rowsHit[ri - 1] : null;
        if (run && cur && prev && run[0] <= prev[1] + 1 && run[1] >= prev[0] - 1) cur.end = ri;
        else cur = run ? { start: ri, end: ri } : null;
        if (cur && (!best || cur.end - cur.start > best.end - best.start)) best = { start: cur.start, end: cur.end };
      }
      if (!best) continue;
      masks[sd] = [];
      for (ri = best.start; ri <= best.end; ri++) for (x = rowsHit[ri][0]; x <= rowsHit[ri][1]; x++) masks[sd].push((yLo + ri) * W + x);
    }
    /* ⛔ Where only the HAND swings (the TableService server: a dark static sleeve) the moving pixels are the hand alone,
     * and the raised "arm" was a hand on a 1 px stalk; where nothing swings (CSAF_Bighead#0) there was no arm at all and
     * the old fixed-block fallback raised 3 px (core.test, 2026-10-09). So the arm GROWS UP from what moved to the
     * shoulder: in the columns the moving pixels span, every row from the neck down to their lowest row takes the outer
     * run of the silhouette (edge inward, clipped to those columns). With nothing moving on a side, the columns are the
     * outer fifth of the figure and the rows run to the hip - the same shape, found without the walk. */
    var aw = Math.max(2, Math.round(bb.width * 0.2));
    for (var sg = 0; sg < 2; sg++) {
      var cur2 = masks[sg], c0, c1, r1, moved = !!(cur2 && cur2.length >= 6);
      if (moved) { c0 = W; c1 = -1; r1 = -1; for (k = 0; k < cur2.length; k++) { var mx = cur2[k] % W, my = (cur2[k] - mx) / W; if (mx < c0) c0 = mx; if (mx > c1) c1 = mx; if (my > r1) r1 = my; } }
      else { c0 = sg === 0 ? bb.left : bb.right - aw + 1; c1 = sg === 0 ? bb.left + aw - 1 : bb.right; r1 = Math.min(M.skirted ? M.neck + Math.round(M.height * 0.4) : M.hip + 2, M.bottom - 3); cur2 = masks[sg] = []; }
      // the grown arm is never wider than the moving one may be (28% of the figure, kept on the OUTER side): a pigtail
      // hanging beside the arm widened it to 12 px and the cheer erased the torso to a pole (People1#1, looked at)
      var capW = Math.max(4, Math.round(bb.width * 0.28)); if (c1 - c0 + 1 > capW) { if (sg === 0) c1 = c0 + capW - 1; else c0 = c1 - capW + 1; }
      var have = {}; for (k = 0; k < cur2.length; k++) have[cur2[k]] = 1;
      // with nothing moving, hair hanging past the shoulders is not an arm (the tall abbess raised a grey lock: looked
      // at): a row whose edge pixel is a CROWN colour (the head's top 30%) is hair and is skipped
      var crownC = {};
      if (!moved) for (y = M.top; y <= M.top + Math.max(1, Math.round((M.neck - M.top) * 0.3)); y++) for (x = 0; x < W; x++) if (down.on(x, y)) { var ci = (y * W + x) * 4; crownC[down.d[ci] + ',' + down.d[ci + 1] + ',' + down.d[ci + 2]] = 1; }
      for (y = yLo; y <= r1; y++) {
        var ex = -1;
        if (sg === 0) { for (x = c0; x <= c1; x++) if (down.on(x, y)) { ex = x; break; } }
        else { for (x = c1; x >= c0; x--) if (down.on(x, y)) { ex = x; break; } }
        if (ex < 0 || down.on(ex + (sg === 0 ? -1 : 1), y)) continue;   // the silhouette's edge must lie inside the arm's columns
        if (!moved) { var ei = (y * W + ex) * 4, ec = down.d[ei] + ',' + down.d[ei + 1] + ',' + down.d[ei + 2], ei2 = (y * W + ex + (sg === 0 ? 1 : -1)) * 4; if (crownC[ec] || crownC[down.d[ei2] + ',' + down.d[ei2 + 1] + ',' + down.d[ei2 + 2]]) continue; }
        for (x = ex; x >= c0 && x <= c1 && down.on(x, y); x += sg === 0 ? 1 : -1) if (!have[y * W + x]) { have[y * W + x] = 1; cur2.push(y * W + x); }
      }
      if (!moved) cur2.walkless = true;
    }
    var out = [null, null];
    for (var s = 0; s < 2; s++) {
      var list = masks[s]; if (!list || list.length < 8) continue;
      var mk = new Uint8Array(W * down.h), l = W, r = -1, t = down.h, b = -1;
      for (k = 0; k < list.length; k++) { var pp = list[k], ax = pp % W, ay = (pp - ax) / W; mk[pp] = 1; if (ax < l) l = ax; if (ax > r) r = ax; if (ay < t) t = ay; if (ay > b) b = ay; }
      /* an arm is a block at least 2 px wide and 4 rows long with real movement in it; anything less is a cloak's flutter */
      if (r - l >= 1 && b - t >= 3) {
        out[s] = { x0: l, x1: r, y0: t, y1: b, walked: !list.walkless, n: list.length };
        Object.defineProperty(out[s], 'mask', { value: mk, enumerable: false });   // a per-pixel working array, never part of a printed or saved spec
      }
    }
    return out;
  }
  /** the vertical shift (-3..3) that best lines walk frame `f` up with the standing frame over the torso rows */
  function bobOf(stand, f, M) {
    var best = 0, bestN = -1;
    for (var dy = -3; dy <= 3; dy++) {
      var n = 0;
      for (var y = M.neck + 1; y < M.hip; y++) for (var x = 0; x < stand.w; x++) if (stand.on(x, y) && !differs(stand, f, x, y, dy)) n++;
      if (n > bestN || (n === bestN && Math.abs(dy) < Math.abs(best))) { bestN = n; best = dy; }
    }
    return best;
  }
  /** does pixel (x, y) of `a` differ from pixel (x, y + dy) of `b` (every channel; off-cell reads as empty) */
  function differs(a, b, x, y, dy) {
    var yy = y + dy; if (yy < 0 || yy >= b.h) return a.on(x, y);
    var i = (y * a.w + x) * 4, j = (yy * b.w + x) * 4;
    return a.d[i] !== b.d[j] || a.d[i + 1] !== b.d[j + 1] || a.d[i + 2] !== b.d[j + 2] || a.d[i + 3] !== b.d[j + 3];
  }
  /**
   * Raise an arm found from the walk (it carries a pixel MASK, not just a box). (1) The hanging arm's own pixels are
   * erased, and only those: the torso beside it stays. (2) A torso pixel left open by the erase takes the outline colour,
   * so the side of the body is closed again. (3) The arm is flipped end over end about its shoulder row - the hand on
   * top, the shoulder where it was, so it stays attached - and leans OUT by `k` pixels per row, k chosen so the hand
   * clears the head's widest column (a chibi's head is wider than its shoulders), clamped to 0.25..1 (steep to 45°).
   * `sway` moves the hand a further `sway` px out (the shoulder never moves): the wave. Whole pixels throughout.
   */
  function raiseMasked(out, src, ab, ox, dy, side, sway, hs, ink, M) {
    var W = src.w, x, y, len = ab.y1 - ab.y0 + 1, mk = ab.mask, span = Math.max(1, len - 1);
    for (y = ab.y0; y <= ab.y1; y++) for (x = ab.x0; x <= ab.x1; x++) if (mk[y * W + x]) out.erase(x + ox, y + dy);
    for (y = ab.y0 - 1; y <= ab.y1 + 1; y++) for (x = ab.x0 - 1; x <= ab.x1 + 1; x++) {
      if (x < 0 || y < 0 || x >= W || y >= src.h || mk[y * W + x] || !out.on(x + ox, y + dy)) continue;
      var open = false;
      for (var k = 0; k < 2 && !open; k++) {   // ⛔ sides only: closing the TOP too painted a dark bar across the shoulders (Actor1#5 cheer, a 23 px run)
        var nx = x + (k === 0 ? -1 : k === 1 ? 1 : 0), ny = y + (k === 2 ? -1 : k === 3 ? 1 : 0);
        if (nx >= 0 && ny >= 0 && nx < W && ny < src.h && mk[ny * W + nx] && !out.on(nx + ox, ny + dy)) open = true;
      }
      if (open) out.paint(x + ox, y + dy, ink);
    }
    /* ⛔ v2 sheared the flipped arm (k px out per row): a shear LENGTHENS the arm by up to 1.4x and thins it, and on the
     * RTP cast the raised arm read as a staff held up (looked at 2026-10-09). The arm is now ROTATED about its shoulder,
     * which keeps its length and thickness: every destination pixel samples the nearest source pixel of the arm's mask
     * (whole pixels, no blending, no holes). The angle from straight up is chosen so the HAND clears the head's widest
     * column by at most 2 px of overlap, 15°..60°; `sway` (degrees) tips it further out per frame: the wave. */
    var top = ab.y0, l = W, r = -1;
    for (x = ab.x0; x <= ab.x1; x++) if (mk[top * W + x]) { if (x < l) l = x; if (x > r) r = x; }
    var pX = (l + r) / 2, pY = top + 1, reach = len - 1, hand = side > 0 ? ab.x1 - pX : pX - ab.x0;
    // the hand's centre must sit past the head's widest column by half the arm's width, less 1 px of overlap
    var need = !hs ? reach * 0.5 : (side > 0 ? hs[1] - pX : pX - hs[0]) + (ab.x1 - ab.x0 + 1) / 2 - 1;
    var alpha = Math.asin(Math.max(0.26, Math.min(0.87, need / Math.max(1, reach)))) + (sway || 0) * Math.PI / 180;
    var R = Math.ceil(len + hand + 2);
    /* ⛔ a raised arm drawn OVER the head covered the cheek and an eye on caped and big-haired stock figures (Actor1#0's
     * wave: the shoulder plate and cape on the face; looked at 2026-10-09). The arm passes BEHIND the head: no pixel of
     * it lands on a pixel of the head (the standing frame's rows top..neck), so it shows beside the head, never on it.
     * Behind a wide head an arm can vanish (the tall abbess, SF_Actor1#1: 5-7 px left): the angle then opens 8° at a time,
     * to 80°, until at least 60% of the arm shows. */
    var headTop = M ? M.top : -1, headBot = M ? M.neck : -1, total = 0, k2;
    for (k2 = 0; k2 < mk.length; k2++) if (mk[k2]) total++;
    var place = function (a, draw) {
      var th = -side * (Math.PI - a), c = Math.cos(th), sn = Math.sin(th), shown = 0;
      for (var qy = Math.floor(pY - R); qy <= Math.ceil(pY + R); qy++) for (var qx = Math.floor(pX - R); qx <= Math.ceil(pX + R); qx++) {
        var rx = qx - pX, ry = qy - pY, sx = Math.round(pX + c * rx + sn * ry), sy = Math.round(pY - sn * rx + c * ry);
        if (sx < ab.x0 || sx > ab.x1 || sy < ab.y0 || sy > ab.y1 || !mk[sy * W + sx]) continue;
        if (qy >= headTop && qy <= headBot && src.on(qx, qy)) continue;   // behind the head
        shown++; if (draw) out.put(qx + ox, qy + dy, src, sx, sy);
      }
      return shown;
    };
    while (alpha < 80 * Math.PI / 180 && place(alpha, false) < total * 0.6) alpha += 8 * Math.PI / 180;
    place(alpha, true);
    return alpha * 180 / Math.PI;
  }
  /** the head's columns at its widest row (the big-head test for a raised arm) */
  function headSpan(src, M) { var best = null; for (var y = M.top; y <= M.neck; y++) { var rr = runs(src, y); if (rr.length) { var w = rr[rr.length - 1][1] - rr[0][0]; if (!best || w > best[1] - best[0]) best = [rr[0][0], rr[rr.length - 1][1]]; } } return best; }
  /**
   * Raise one arm. Upright (the block flipped end over end, hand up, shoulder at the shoulder) when it clears the head;
   * ⛔ on a big-head chibi an upright arm stayed beside the cheek and read as headphones (review item 21), so when the
   * head reaches past the arm the arm is turned a quarter instead and held OUT to the side at the shoulder, hand at the
   * tip (whole pixels, the same quarter turn as the lying poses). `sway` moves the arm per frame.
   */
  function raiseArm(out, src, ab, ox, side, sway, swayOut, dy, hs) {
    var x, y, len = ab.y1 - ab.y0 + 1, aw = ab.x1 - ab.x0 + 1;
    for (y = ab.y0; y <= ab.y1; y++) for (x = ab.x0; x <= ab.x1; x++) out.erase(x + ox, y + dy);
    var blocked = hs && (side > 0 ? hs[1] >= ab.x0 + 1 : hs[0] <= ab.x1 - 1);
    if (blocked && ab.walked) {
      /* ⛔ the quarter-turn below read as a blob at the cheek on the stock RTP cast (looked at 2026-10-09): an arm found
       * from the walk is raised BESIDE the head instead, flipped end over end (hand up) and pushed out past the head's
       * edge, clamped inside the cell: the chibi cheer. `sway` lifts it per frame. */
      var shift = side > 0 ? Math.max(0, hs[1] + 1 - ab.x0) : Math.min(0, hs[0] - 1 - ab.x1);
      shift = side > 0 ? Math.min(shift, out.w - 1 - ox - ab.x1) : Math.max(shift, -(ab.x0 + ox));
      for (y = 0; y < len; y++) for (x = ab.x0; x <= ab.x1; x++) out.put(x + ox + shift, ab.y0 + 1 - len + y + dy - swayOut, src, x, ab.y1 - y);
      return 'beside';
    }
    if (!blocked) {
      for (y = 0; y < len; y++) for (x = ab.x0; x <= ab.x1; x++) out.put(x + ox + side * sway, ab.y0 + 1 - len + y + dy, src, x, ab.y1 - y);
      return 'up';
    }
    for (y = 0; y < len; y++) for (x = 0; x < aw; x++) {
      var sx = side > 0 ? ab.x0 + x : ab.x1 - x, tx = side > 0 ? ab.x0 + y : ab.x1 - y, ty = ab.y0 + (aw - 1 - x) - swayOut - (y >> 1);   // angled up and out (a 2:1 stair of whole pixels)
      out.put(tx + ox, ty + dy, src, sx, ab.y0 + y);
    }
    return 'out';
  }

  /** a soft oval shadow on the floor under a figure, drawn only where nothing else is (the one non-character pixel) */
  function shadow(cell, cx, floor, half) {
    for (var y = floor - 1; y <= floor + 1; y++) for (var x = Math.round(cx - half); x <= Math.round(cx + half); x++) {
      var t = (x - cx) / half, v = (y - floor); if (t * t + v * v * 0.6 > 1 || cell.on(x, y)) continue;
      cell.paint(x, y, [0, 0, 0, y === floor ? 72 : 40]);
    }
  }

  /**
   * One pose for one character of a sheet. Returns {width, height, data, cw, ch, pose, spec} - a big-character layout
   * (3 columns x 4 rows, rows = down, left, right, up) that Posture.js hands to Sprite_Character as a '$' sheet.
   * `opt.lift` = seat height in pixels for 'sit' and 'read' (default 6). Returns null when the character's standing
   * frame is empty (nothing to pose).
   */
  function derive(img, name, index, pose, opt) {
    opt = opt || {};
    var P = POSES[pose]; if (!P) throw new Error('PostureCore: unknown pose "' + pose + '" (known: ' + NAMES.join(', ') + ')');
    var L = layout(img.width, img.height, name, index);
    var stand = {}; for (var k = 0; k < 4; k++) stand[DIRS[k]] = frameOf(img, L, DIRS[k], 1);
    var M = measure(stand[2]); if (!M) return null;
    M.arms = armsFromWalk(stand[2], frameOf(img, L, 2, 0), frameOf(img, L, 2, 2), M);
    var lift = P.seat ? Math.max(0, Math.min(Math.floor(M.legLen * 0.9), M.top, Number(opt.lift === undefined ? 6 : opt.lift) || 0)) : 0;
    var W = P.facings === 'lying' ? Math.max(L.cw, M.height + 4) : P.facings === 'camera' ? L.cw + 2 * ARMROOM : L.cw, ch = P.facings === 'bed' ? 2 * L.ch : L.ch + (P.facings === 'camera' ? HEADROOM : 0);   // raised arms get headroom above the cell (MZ anchors a character sprite at its feet, so a taller frame grows upward)
    var pal = palette([stand[2], stand[4], stand[6], stand[8]], M, stand[2]);
    var frames = [];   // frames[row][col]
    for (var r = 0; r < 4; r++) {
      var dir = DIRS[r], src = stand[dir], row = [];
      for (var col = 0; col < 3; col++) row.push(build(pose, src, dir, col));
      frames.push(row);
    }
    function build(pose, src, dir, col) {
      var side = dir === 4 ? -1 : dir === 6 ? 1 : 0, c, bb = bbox(src);
      if (!bb) return new Cell(W, ch);
      var ox = Math.floor((W - src.w) / 2), mid = ox + (bb.left + bb.right) / 2;
      if (pose === 'sit' || pose === 'read') {
        c = side ? sideSit(src, M, W, lift, side, false) : compressLegs(src, M, W, M.legLen - Math.max(1, Math.round(M.legLen * 0.35)) - 1, lift, 0);
        if (pose === 'read' && dir !== 8 && bbox(c)) {   // (a pose with nothing left to hold a book gets none: breakit, a 1 px sheet)
          // the book sits at the hands: the bottom of the torso, i.e. the seated figure's top + the head-to-hip height, less the book
          var cb = bbox(c), handY = side ? Math.min(cb.top + (M.neck - M.top) + 1, cb.bottom - 6) : Math.max(cb.top + (M.neck - M.top), Math.min(cb.top + (M.hip - M.top) - 6, cb.bottom - 6));   // side: at the chest, just under the chin
          var bx = Math.round(mid);
          if (side) { var rr = runs(c, handY + 2); if (rr.length) bx = side < 0 ? rr[0][0] + 2 : rr[rr.length - 1][1] - 2; }   // held out in front of the chest: 2 px over the body, 4 px beyond it
          book(c, bx, handY, side, pal);
        }
        shadow(c, mid, bb.bottom, M.width * 0.55);
      } else if (pose === 'sitfloor') {
        // ⛔ v1 dropped a stock chibi's 5-row legs by 2 here, by 2 for sit and by 2 for kneel: the independent review
        // (2026-10-09, D10) could swap the three front views and not notice. On the floor the body now sits LOWEST (all
        // but one row of the legs) on the widest base (the feet spread one more pixel): the low, wide one of the three.
        c = side ? sideSit(src, M, W, 0, side, true) : compressLegs(src, M, W, Math.max(0, M.legLen - 2), 0, SPREAD(M));
        shadow(c, mid, bb.bottom, M.width * 0.65);
      } else if (pose === 'kneel') {
        c = side ? sideKneel(src, M, W, side) : frontKneel(src, M, W);
        bow(c, M, side);
        shadow(c, mid, bb.bottom, M.width * 0.55);
      } else if (pose === 'sleep') {
        // facing left or right turns the sleeper's head on the pillow (its own side-facing head, eye closed); down or up
        // sleeps face up. The middle column breathes in.
        c = inBed(stand[2], M, pal, W, ch, col === 1 ? 1 : 0, side ? stand[dir] : stand[2], !!side);
      } else if (pose === 'lie' || pose === 'collapsed') {
        var head = (dir === 2 || dir === 4) ? -1 : 1;
        c = lying(pose === 'collapsed' ? stand[8] : stand[2], W, ch, head);
        var lb = bbox(c); if (lb) shadow(c, (lb.left + lb.right) / 2, lb.bottom, lb.width * 0.55);
      } else if (pose === 'wave' || pose === 'cheer') {
        var front = stand[2], fb = bbox(front), fo = Math.floor((W - front.w) / 2), jump = (pose === 'cheer' && col === 1 ? 2 : 0) - HEADROOM;
        c = new Cell(W, ch); c.rows(front, fb.top, fb.bottom, fo, -jump);
        // ⛔ v1's wave had two distinct frames (0 and 2 identical) and moved the arm 1 px: a twitch (review item 23). The three
        // columns now sway the arm 0, 2 and 4 px (upright) or 0, 1 and 2 rows (held out); the clock plays 0-1-2-1.
        var hs = headSpan(front, M), wave = pose === 'wave', aL = M.arms && M.arms[0], aR = M.arms && M.arms[1];
        if (aR && aR.mask && (wave || (aL && aL.mask))) {
          // both arms (or the waving one) were found from the walk: raise them by their own pixels (raiseMasked)
          raiseMasked(c, front, aR, fo, -jump, 1, wave ? col * 22 - 12 : col === 1 ? -6 : 0, hs, pal.dark, M);   // degrees: the wave tips the hand -12°, +10°, +32° (±7° "barely moved", review D18); the cheer's hop lifts both arms 6° higher
          if (!wave) raiseMasked(c, front, aL, fo, -jump, -1, col === 1 ? -6 : 0, hs, pal.dark, M);
        } else {
          raiseArm(c, front, armBlock(front, M, 1), fo, 1, wave ? col * 2 : 1, wave ? col : 0, -jump, hs);
          if (!wave) raiseArm(c, front, armBlock(front, M, -1), fo, -1, 1, 0, -jump, hs);
        }
      }
      return c;
    }
    // assemble the pose sheet
    var out = { width: W * 3, height: ch * 4, data: new Uint8ClampedArray(W * 3 * ch * 4 * 4), cw: W, ch: ch, pose: pose, spec: M, lift: lift, palette: pal.colours.length, tints: [], eyes: [] };
    for (var rr = 0; rr < 4; rr++) for (var cc = 0; cc < 3; cc++) {
      var f = frames[rr][cc];
      // the colours a pose PAINTS (sleep's pillow and quilt: tints of the character's own colours) and what closeEyes did
      if (f.tints) for (var t = 0; t < f.tints.length; t++) if (out.tints.indexOf(f.tints[t]) < 0) out.tints.push(f.tints[t]);
      if (f.eyes && cc === 0) out.eyes.push(f.eyes);
      for (var y = 0; y < ch; y++) for (var x = 0; x < W; x++) {
        var i = (y * W + x) * 4, o = (((rr * ch) + y) * out.width + cc * W + x) * 4;
        out.data[o] = f.d[i]; out.data[o + 1] = f.d[i + 1]; out.data[o + 2] = f.d[i + 2]; out.data[o + 3] = f.d[i + 3];
      }
    }
    return out;
  }

  return { VERSION: '1.0.0', ALPHA: ALPHA, HEADROOM: HEADROOM, ARMROOM: ARMROOM, SPREAD: SPREAD, DIRS: DIRS, POSES: POSES, NAMES: NAMES, isBig: isBig, layout: layout, frameOf: frameOf, measure: measure, bbox: bbox, runs: runs, palette: palette, derive: derive, Cell: Cell, closeEyes: closeEyes, armsFromWalk: armsFromWalk };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = PostureCore;
