//=============================================================================
// Posture.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Posture - your characters sit, kneel, lie, sleep and
 * wave, every pose made from the walking sheet they already have.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 * @base PostureCore
 * @orderAfter PostureCore
 *
 * @param seatLift
 * @text Seat height
 * @type number
 * @min 0
 * @max 24
 * @desc Pixels a character sitting on a chair (sit, read) is raised, so the body rests on the seat. 0 = on the floor.
 * @default 6
 *
 * @param standOnMove
 * @text Stand up on move
 * @type boolean
 * @on Stand up
 * @off Keep the pose
 * @desc When a posed character takes a step, the pose ends and they walk normally.
 * @default true
 *
 * @param chairRegions
 * @text Chair regions
 * @type string
 * @desc Region ids (comma separated) that count as chairs. A character with the pose "auto" on one of them sits.
 * @default 10
 *
 * @param bedRegions
 * @text Bed regions
 * @type string
 * @desc Region ids (comma separated) that count as beds. A character with the pose "auto" on one of them sleeps. Paint it on each bed's foot tile.
 * @default 11
 *
 * @param breathFrames
 * @text Breath length
 * @type number
 * @min 8
 * @max 240
 * @desc Frames per breath of a sleeping character (60 = one second).
 * @default 48
 *
 * @param waveFrames
 * @text Wave speed
 * @type number
 * @min 4
 * @max 60
 * @desc Frames per step of a waving or cheering character.
 * @default 10
 *
 * @command SetPose
 * @text Set pose
 * @desc Puts the player or an event into a pose.
 *
 * @arg target
 * @text Who
 * @type select
 * @option player
 * @option this event
 * @option event id
 * @default this event
 *
 * @arg eventId
 * @text Event id
 * @type number
 * @min 0
 * @desc Used when "Who" is "event id".
 * @default 0
 *
 * @arg pose
 * @text Pose
 * @type select
 * @option sit
 * @option sitfloor
 * @option kneel
 * @option read
 * @option lie
 * @option sleep
 * @option collapsed
 * @option wave
 * @option cheer
 * @option auto
 * @option stand
 * @desc "auto" sits on a chair region and sleeps on a bed region. "stand" ends the pose.
 * @default sit
 *
 * @command ClearPose
 * @text Stand up
 * @desc Ends the pose of the player or an event.
 *
 * @arg target
 * @text Who
 * @type select
 * @option player
 * @option this event
 * @option event id
 * @default this event
 *
 * @arg eventId
 * @text Event id
 * @type number
 * @min 0
 * @default 0
 *
 * @help
 * POSTURE - sitting, kneeling, lying, sleeping, collapsed, waving and
 * cheering poses for every character in your project, made at load time from
 * the walking sheet each character already has. No new art.
 *
 * INSTALL: PostureCore.js above Posture.js in the Plugin Manager.
 *
 * THE POSES
 *   sit        on a chair or bench (raised by "Seat height")   4 facings
 *   sitfloor   on the floor, legs out                           4 facings
 *   kneel      on one knee                                      4 facings
 *   read       seated, holding a book                           4 facings
 *   lie        lying down (head left or right)                  2 ways
 *   sleep      in bed: pillow, eyes closed, quilt, breathing    3 ways
 *   collapsed  face down on the ground                          2 ways
 *   wave       one arm raised, waving (turns to the camera)     animated
 *   cheer      both arms up, a little jump (turns to camera)    animated
 * The character's facing picks the frame: for lie and collapsed, facing
 * down or left lays the head to the left, right or up to the right. A
 * sleeper faces up, or turns its head on the pillow when facing left or
 * right. A sleeper is TWO tiles tall: put it (or the Bed region) on the
 * bed's FOOT tile and its head lies on the pillow tile above.
 *
 * EVENT NOTETAG (in the event's Note box)
 *   <pose: sit>      the event starts in this pose
 * PAGE COMMENT (a Comment command on an event page)
 *   <pose: sleep>    while this page is active the event holds this pose;
 *                    a page without one uses the notetag (or stands)
 *   <pose: auto>     sit on a chair region, sleep on a bed region
 *
 * PLUGIN COMMANDS
 *   Set pose   (Who: player / this event / event id, Pose)
 *   Stand up   (Who)
 *
 * SCRIPT
 *   Posture.set($gamePlayer, 'kneel');   Posture.set(5, 'wave');
 *   Posture.clear(5);                    Posture.get($gameMap.event(5))
 *
 * Poses are saved with the game. Tile-image events and characters without
 * a sheet are left alone. Your image files are never changed: each pose is
 * built once, in memory, the first time it is needed.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var Posture = (function () {
  'use strict';

  var NAME = 'Posture';
  var RAW = PluginManager.parameters(NAME);
  var CORE = null;
  /** ⛔ The sibling is resolved at FIRST USE, never at load time: the buyer chooses the load order (wing §8 trap 2). */
  function deps() { if (!CORE) CORE = window.PostureCore; if (!CORE) throw new Error('Posture needs PostureCore.js installed and ON in the Plugin Manager.'); return CORE; }

  /** ⛔ parameters arrive as strings; "" is ABSENT, never zero (wing §16) */
  function num(v, def, lo, hi) { if (v === undefined || v === null || String(v).trim() === '') return def; var n = Number(v); return isFinite(n) ? Math.max(lo, Math.min(hi, Math.round(n))) : def; }
  function ids(v) { return String(v === undefined ? '' : v).split(',').map(function (s) { return Number(s.trim()); }).filter(function (n) { return isFinite(n) && n > 0 && n < 256; }); }
  var P = {
    lift: num(RAW.seatLift, 6, 0, 24),
    standOnMove: String(RAW.standOnMove === undefined ? 'true' : RAW.standOnMove) !== 'false',
    chairs: ids(RAW.chairRegions === undefined ? '10' : RAW.chairRegions),
    beds: ids(RAW.bedRegions === undefined ? '11' : RAW.bedRegions),
    breath: num(RAW.breathFrames, 48, 8, 240),
    wave: num(RAW.waveFrames, 10, 4, 60),
  };
  var POSE_NAMES = ['sit', 'sitfloor', 'kneel', 'read', 'lie', 'sleep', 'collapsed', 'wave', 'cheer'];

  /** a pose name from user text: lower case, trimmed; 'auto' and 'stand' are commands, anything unknown is '' (stand) */
  function normal(pose) { var p = String(pose === undefined || pose === null ? '' : pose).trim().toLowerCase(); return p === 'auto' || POSE_NAMES.indexOf(p) >= 0 ? p : ''; }

  /** 'auto' resolved against the region under the character: a chair sits, a bed sleeps, anywhere else stands */
  function resolve(ch, pose) {
    if (pose !== 'auto') return pose;
    var r = $gameMap.regionId(ch.x, ch.y);
    return P.chairs.indexOf(r) >= 0 ? 'sit' : P.beds.indexOf(r) >= 0 ? 'sleep' : '';
  }

  // ---- the character side: one saved field ---------------------------------------------------------------------
  /** the pose a character holds ('' = standing). Stored on the character, so it is saved with the map and the player. */
  Game_CharacterBase.prototype.csafPose = function () { return this._csafPose ? resolve(this, this._csafPose) : ''; };
  Game_CharacterBase.prototype.csafSetPose = function (pose) { this._csafPose = normal(pose); };

  var _increaseSteps = Game_CharacterBase.prototype.increaseSteps;
  /** a step ends the pose when "Stand up on move" is on */
  Game_CharacterBase.prototype.increaseSteps = function () {
    _increaseSteps.apply(this, arguments);
    if (P.standOnMove && this._csafPose) this._csafPose = '';
  };

  /** the <pose: x> of the active page's comments, else the event note's, else null (no instruction) */
  function poseFromEvent(ev) {
    var page = ev.page(), list = page && page.list, i, m;
    if (list) for (i = 0; i < list.length; i++) {
      var c = list[i]; if (c.code !== 108 && c.code !== 408) continue;
      m = /<pose:\s*([a-z]+)\s*>/i.exec(String(c.parameters[0] || '')); if (m) return m[1];
    }
    var meta = ev.event() && ev.event().meta;
    return meta && meta.pose !== undefined && meta.pose !== true ? String(meta.pose) : null;
  }
  var _setupPageSettings = Game_Event.prototype.setupPageSettings;
  /** a page change applies that page's pose (or the note's); a page with neither leaves a pose set by a command alone */
  Game_Event.prototype.setupPageSettings = function () {
    _setupPageSettings.apply(this, arguments);
    var p = poseFromEvent(this);
    if (p !== null) this.csafSetPose(p);
  };

  // ---- the sprite side: one derived sheet per (file, character, pose, seat height) --------------------------------
  var CACHE = {};
  var SOURCE = {};   // the pixels of each loaded sheet, read once (wing §27a: never read pixels during play)
  /** the pose sheet for a loaded source bitmap, or null while it is still loading / when there is nothing to pose */
  function sheetFor(name, index, pose) {
    var C = deps(), key = name + '|' + index + '|' + pose + '|' + P.lift;
    if (CACHE[key] !== undefined) return CACHE[key];
    var src = ImageManager.loadCharacter(name);
    if (!src || !src.isReady() || !src.width) return null;
    if (!SOURCE[name]) SOURCE[name] = { width: src.width, height: src.height, data: src.context.getImageData(0, 0, src.width, src.height).data };
    var out = C.derive(SOURCE[name], name, index, pose, { lift: P.lift });
    var bmp = null;
    if (out) {
      bmp = new Bitmap(out.width, out.height);
      bmp.context.putImageData(new ImageData(out.data, out.width, out.height), 0, 0);
      bmp._baseTexture.update();
      bmp._csafPose = { pose: pose, cw: out.cw, ch: out.ch, animated: C.POSES[pose].animated };
    }
    CACHE[key] = bmp;
    return bmp;
  }

  var _updateBitmap = Sprite_Character.prototype.updateBitmap;
  /** after the engine picks the sheet, swap in the pose sheet while the character holds a pose (no allocation per frame) */
  Sprite_Character.prototype.updateBitmap = function () {
    _updateBitmap.apply(this, arguments);
    var ch = this._character, pose = ch && !this._tileId && this._characterName ? ch.csafPose() : '';
    if (!pose) {
      if (this._csafPoseBmp) { this.bitmap = ImageManager.loadCharacter(this._characterName); this._csafPoseBmp = null; this._csafPoseKey = ''; }
      return;
    }
    if (this._csafPoseBmp && this._csafPoseKey === pose && this._csafPoseName === this._characterName && this._csafPoseIndex === this._characterIndex) return;
    var bmp = sheetFor(this._characterName, this._characterIndex, pose);
    if (!bmp) return;
    this.bitmap = bmp; this._csafPoseBmp = bmp; this._csafPoseKey = pose; this._csafPoseName = this._characterName; this._csafPoseIndex = this._characterIndex;
  };

  // the engine's own frame math, saved one per statement and CALLED for every character that holds no pose
  var _blockX = Sprite_Character.prototype.characterBlockX;
  var _blockY = Sprite_Character.prototype.characterBlockY;
  var _patX = Sprite_Character.prototype.characterPatternX;
  var _pw = Sprite_Character.prototype.patternWidth;
  var _ph = Sprite_Character.prototype.patternHeight;
  /** a pose sheet holds ONE character, laid out like a '$' sheet: no block offset */
  Sprite_Character.prototype.characterBlockX = function () { return this._csafPoseBmp ? 0 : _blockX.apply(this, arguments); };
  Sprite_Character.prototype.characterBlockY = function () { return this._csafPoseBmp ? 0 : _blockY.apply(this, arguments); };
  Sprite_Character.prototype.patternWidth = function () { return this._csafPoseBmp ? this._csafPoseBmp._csafPose.cw : _pw.apply(this, arguments); };
  Sprite_Character.prototype.patternHeight = function () { return this._csafPoseBmp ? this._csafPoseBmp._csafPose.ch : _ph.apply(this, arguments); };
  /** a held pose shows its middle frame; sleep breathes (0 -> 1 -> 0) and wave/cheer step 0 -> 1 -> 2 -> 1 on a clock */
  Sprite_Character.prototype.characterPatternX = function () {
    var b = this._csafPoseBmp; if (!b) return _patX.apply(this, arguments);
    var info = b._csafPose; if (!info.animated) return 1;
    if (info.pose === 'sleep') return Math.floor(Graphics.frameCount / P.breath) % 2;   // column 0 resting, column 1 the breath in
    var s = Math.floor(Graphics.frameCount / P.wave) % 4; return s === 3 ? 1 : s;
  };

  // ---- commands and the script API -------------------------------------------------------------------------------
  function targetOf(args, interp) {
    var who = String(args.target || 'this event');
    if (who === 'player') return $gamePlayer;
    var id = who === 'event id' ? Number(args.eventId) : (interp && interp.eventId ? interp.eventId() : 0);
    return id > 0 ? $gameMap.event(id) || null : null;
  }
  function charOf(t) { return typeof t === 'number' ? (t === 0 ? $gamePlayer : $gameMap.event(t) || null) : t || null; }
  PluginManager.registerCommand(NAME, 'SetPose', function (args) { var c = targetOf(args, this); if (c) c.csafSetPose(args.pose === 'stand' ? '' : args.pose); });
  PluginManager.registerCommand(NAME, 'ClearPose', function (args) { var c = targetOf(args, this); if (c) c.csafSetPose(''); });

  return {
    VERSION: '1.0.0', P: P, POSE_NAMES: POSE_NAMES, CACHE: CACHE, SOURCE: SOURCE, deps: deps, normal: normal, resolve: resolve, poseFromEvent: poseFromEvent, sheetFor: sheetFor,
    /** Posture.set(characterOrEventId, pose) - 0 or $gamePlayer = the player */
    set: function (t, pose) { var c = charOf(t); if (c) c.csafSetPose(pose); return !!c; },
    clear: function (t) { var c = charOf(t); if (c) c.csafSetPose(''); return !!c; },
    get: function (t) { var c = charOf(t); return c ? c.csafPose() : ''; },
  };
}());
