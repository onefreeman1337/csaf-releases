/*:
 * @target MZ
 * @plugindesc [v1.0.0] Threshold core: derives door opening frames from your own tile pixels. Load BEFORE Threshold.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io/
 *
 * @help ThresholdCore.js
 *
 * The pure rules half of Threshold. It has no engine code in it: it reads an array of RGBA pixels (your door
 * tile) and returns the pixels of that door at any point of its opening, for eight kinds of opening. Threshold.js
 * feeds it your tileset and shows the result. This file has no parameters and no commands; see Threshold.js.
 *
 * Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.
 */

/*
 * HOW A FRAME IS MADE, and the rule every kind obeys:
 *
 *   Every pixel of the moving part is a COPY of one of your door's own pixels, picked by whole pixel
 *   nearest-neighbour sampling. Nothing is blended, smoothed or resampled with filtering, so a 48 px door
 *   stays crisp at every step of its swing (the failure this product exists to avoid is a smeared sprite).
 *   The only colours that are not your pixels are a small, named palette DERIVED from your pixels: the
 *   leaf's own darkest colour (its thickness edge), the dark of the doorway behind it, and the shadow a
 *   lifted hatch casts. Tests assert that rule on every frame of every kind.
 *
 *   The interior behind an opening is unknown, so it is drawn as darkness in bands, never as a guessed room.
 *   The warm light that spills out at night is NOT baked in: each frame also returns an interior mask, and the
 *   plugin lays the spill over that mask at a strength read from the map's tint, so one set of frames serves
 *   day and night.
 */
(function (root) {
  'use strict';

  var KINDS = ['door', 'double', 'portcullis', 'hatch', 'sliding', 'curtain', 'vault', 'cave'];
  var OPENING_KINDS = KINDS.filter(function (k) { return k !== 'cave'; });
  // The stock MZ door event animates by TURNING the event: down, left, right, up. Threshold reads the same
  // four directions as the four stages of its own opening, so an existing door event drives it unchanged.
  var STAGE_OF_DIRECTION = { 2: 0, 4: 1 / 3, 6: 2 / 3, 8: 1 };
  var MAX_SWING_DEG = 78;

  function clamp(x, a, b) { return x < a ? a : x > b ? b : x; }
  function lum(r, g, b) { return 0.2126 * r + 0.7152 * g + 0.0722 * b; }

  /**
   * Read a `<threshold: kind [option...]>` note value (MZ hands it over as the text after the colon).
   * Options: `right` (hinge on the right), `dust` (old doors shed dust as they move), `nogroup`.
   * @param {string|boolean} value  the meta value; `true` when the tag had no value
   * @returns {{kind:string, hinge:string, dust:boolean, group:boolean}|null}  null when the kind is unknown
   */
  function parseNote(value) {
    var words = (value === true || value == null ? 'door' : String(value)).toLowerCase().split(/[\s,]+/).filter(Boolean);
    var kind = words[0] || 'door';
    var alias = { gate: 'portcullis', bars: 'portcullis', trapdoor: 'hatch', shoji: 'sliding', slide: 'sliding', flap: 'curtain', hide: 'curtain', vaultdoor: 'vault', mouth: 'cave', entrance: 'cave', doubledoor: 'double' };
    if (alias[kind]) kind = alias[kind];
    if (KINDS.indexOf(kind) < 0) return null;
    return { kind: kind, hinge: words.indexOf('right') >= 0 ? 'right' : 'left', dust: words.indexOf('dust') >= 0, group: words.indexOf('nogroup') < 0 };
  }

  /** @returns {number} the opening stage (0..1) a stock door event's direction stands for */
  function stageOfDirection(d) { return STAGE_OF_DIRECTION[d] != null ? STAGE_OF_DIRECTION[d] : 0; }

  /**
   * The derived palette of one door image: its darkest opaque colour (the leaf's thickness edge) and the
   * bands of darkness behind it, all computed from the door's own pixels.
   * @param {Uint8ClampedArray|number[]} d RGBA @param {number} w @param {number} h
   */
  function analyse(d, w, h) {
    var dark = null, darkL = 1e9, n = 0, sr = 0, sg = 0, sb = 0, colours = {};
    var bbox = { x0: w, y0: h, x1: 0, y1: 0 };
    for (var i = 0; i < w * h; i++) {
      var a = d[i * 4 + 3];
      if (a >= 128) { var px = i % w, py = Math.floor(i / w); if (px < bbox.x0) bbox.x0 = px; if (py < bbox.y0) bbox.y0 = py; if (px + 1 > bbox.x1) bbox.x1 = px + 1; if (py + 1 > bbox.y1) bbox.y1 = py + 1; }
      if (a < 128) continue;
      var r = d[i * 4], g = d[i * 4 + 1], b = d[i * 4 + 2], L = lum(r, g, b);
      n++; sr += r; sg += g; sb += b;
      colours[(r << 16) | (g << 8) | b] = 1;
      if (L < darkL) { darkL = L; dark = [r, g, b]; }
    }
    if (!n) return { empty: true, opaque: 0, dark: [0, 0, 0], interior: [[8, 7, 10, 255]], shade: [0, 0, 0], palette: [], mean: [0, 0, 0] };
    var mean = [sr / n, sg / n, sb / n];
    // the doorway: the leaf's own darkest colour pulled most of the way to black, in four bands (deepest at the top)
    var interior = [];
    for (var k = 0; k < 4; k++) {
      var f = 0.16 + k * 0.07;
      interior.push([Math.round(dark[0] * f + 4), Math.round(dark[1] * f + 3), Math.round(dark[2] * f + 6), 255]);
    }
    var palette = Object.keys(colours).map(function (c) { c = +c; return [(c >> 16) & 255, (c >> 8) & 255, c & 255]; });
    return { empty: false, opaque: n, bbox: bbox, dark: dark, interior: interior, shade: [Math.round(dark[0] * 0.45), Math.round(dark[1] * 0.45), Math.round(dark[2] * 0.45)], palette: palette, mean: mean };
  }

  /** The colour of `palette` nearest to (r,g,b): how a fold or a cave's depth darkens WITHOUT inventing a colour. */
  function nearest(palette, r, g, b) {
    var best = palette[0], bd = 1e12;
    for (var i = 0; i < palette.length; i++) {
      var p = palette[i], dr = p[0] - r, dg = p[1] - g, db = p[2] - b, dd = dr * dr * 2 + dg * dg * 4 + db * db * 3;
      if (dd < bd) { bd = dd; best = p; }
    }
    return best;
  }

  /**
   * How see-through a door is: the share of each row's span, between its first and last SOLID pixel, that is
   * transparent. Bars and grilles drawn over nothing are full of such holes; leaves, arches and panels are not.
   * @returns {number} 0..1
   */
  function holeFraction(d, w, h) {
    var holes = 0, span = 0;
    for (var y = 0; y < h; y++) {
      var a = -1, b = -1;
      for (var x = 0; x < w; x++) if (d[(y * w + x) * 4 + 3] >= 128) { if (a < 0) a = x; b = x; }
      if (a < 0) continue;
      span += b - a + 1;
      for (var x2 = a; x2 <= b; x2++) if (d[(y * w + x2) * 4 + 3] < 128) holes++;
    }
    return span ? holes / span : 0;
  }
  // MEASURED (Internal_Ops/_probe/hole_census.js, 2026-10-12): 30 solid doors on the RTP and three generated styles
  // read 0 to 0.02; the RTP's see-through cell bars and iron gate read 0.229 and 0.251. The bar sits between them.
  var SEE_THROUGH = 0.1;

  function newFrame(w, h) { return { data: new Uint8ClampedArray(w * h * 4), mask: new Uint8Array(w * h), w: w, h: h }; }
  function put(f, x, y, r, g, b, a) { if (x < 0 || y < 0 || x >= f.w || y >= f.h) return; var i = (y * f.w + x) * 4; f.data[i] = r; f.data[i + 1] = g; f.data[i + 2] = b; f.data[i + 3] = a; }
  function copyPx(f, x, y, s, sx, sy, sw) { if (x < 0 || y < 0 || x >= f.w || y >= f.h) return; var i = (y * f.w + x) * 4, j = (sy * sw + sx) * 4; if (s[j + 3] === 0) return; f.data[i] = s[j]; f.data[i + 1] = s[j + 1]; f.data[i + 2] = s[j + 2]; f.data[i + 3] = s[j + 3]; }

  /** Fill the opening (columns x0..x1, all rows) with the interior bands and mark it in the mask. */
  function fillInterior(f, A, x0, x1, y0, y1) {
    var H = y1 - y0;
    for (var y = y0; y < y1; y++) {
      var band = A.interior[Math.min(3, Math.floor(4 * (y - y0) / Math.max(1, H)))];
      for (var x = x0; x < x1; x++) { put(f, x, y, band[0], band[1], band[2], 255); f.mask[y * f.w + x] = 1; }
    }
  }

  // ── the kinds ─────────────────────────────────────────────────────────────────────────────────────

  /**
   * A hinged leaf swinging INTO the doorway: it foreshortens to cos(angle) of its width (nearest columns),
   * its free edge shrinks toward the middle as it moves away from the viewer, and its thickness appears as a
   * strip in the leaf's own darkest colour. `x0..x0+w` is the leaf's span; `mirror` hinges it on the right.
   */
  function swingLeaf(f, src, sw, sh, sx0, w, x0, t, A, mirror) {
    var ang = t * MAX_SWING_DEG * Math.PI / 180;
    var leafW = Math.max(1, Math.round(w * Math.cos(ang)));
    if (t >= 1) leafW = Math.max(1, Math.round(w * 0.12));
    var edge = Math.round(3 * Math.sin(ang) * (sw / 48 > 0.5 ? sw / 48 : 0.5));
    var shrink = 0.16 * Math.sin(ang);
    var cy = (sh - 1) / 2;
    for (var c = 0; c < leafW + edge; c++) {
      var u = c / Math.max(1, leafW);                       // 0 at the hinge, 1 at the free edge
      var s = 1 - shrink * Math.min(1, u);                  // the far edge is further away: shorter
      var dx = mirror ? x0 + w - 1 - c : x0 + c;
      for (var y = 0; y < sh; y++) {
        var yy = Math.round(cy + (y - cy) / s);
        if (yy < 0 || yy >= sh) continue;
        if (c < leafW) {
          var scol = Math.min(w - 1, Math.floor(c * w / leafW));
          var sx = mirror ? sx0 + w - 1 - scol : sx0 + scol;
          copyPx(f, dx, y, src, sx, yy, sw);
          f.mask[y * f.w + dx] = 0;
        } else {
          put(f, dx, y, A.dark[0], A.dark[1], A.dark[2], 255);  // the leaf's edge, in its own darkest colour
          f.mask[y * f.w + dx] = 0;
        }
      }
    }
  }

  function kindDoor(f, src, sw, sh, t, A, opt) {
    fillInterior(f, A, 0, sw, 0, sh);
    swingLeaf(f, src, sw, sh, 0, sw, 0, t, A, opt.hinge === 'right');
  }

  function kindDouble(f, src, sw, sh, t, A) {
    fillInterior(f, A, 0, sw, 0, sh);
    var half = Math.floor(sw / 2);
    swingLeaf(f, src, sw, sh, 0, half, 0, t, A, false);
    swingLeaf(f, src, sw, sh, half, sw - half, half, t, A, true);
  }

  /** A portcullis or bar gate rises in whole steps, its chain links ticking past at the sides. */
  function kindPortcullis(f, src, sw, sh, t, A) {
    var step = Math.max(2, Math.round(sh / 12));
    var lift = Math.min(sh, Math.round((t * sh * 0.94) / step) * step);
    fillInterior(f, A, 0, sw, 0, sh);
    for (var y = 0; y < sh - lift; y++) for (var x = 0; x < sw; x++) {
      var sy = y + lift;
      var j = (sy * sw + x) * 4;
      if (src[j + 3] === 0) continue;
      copyPx(f, x, y, src, x, sy, sw); f.mask[y * sw + x] = 0;
    }
    // the chains, at both sides of the opening, links offset by the lift so they visibly run
    var link = Math.max(2, Math.round(sh / 16));
    for (var side = 0; side < 2; side++) {
      var cx = side ? sw - 2 - Math.round(sw / 16) : Math.round(sw / 16);
      for (var y2 = sh - lift; y2 < sh; y2++) {
        var on = Math.floor((y2 + lift) / link) % 2 === 0;
        var col = on ? A.dark : A.palette.length ? nearest(A.palette, A.mean[0], A.mean[1], A.mean[2]) : A.dark;
        put(f, cx, y2, col[0], col[1], col[2], 255); f.mask[y2 * sw + cx] = 0;
        if (on) { put(f, cx + 1, y2, col[0], col[1], col[2], 255); f.mask[y2 * sw + cx + 1] = 0; }
      }
    }
  }

  /** A floor hatch seen from above lifts on its top hinge: it foreshortens upward and casts its own shadow into the hole. */
  function kindHatch(f, src, sw, sh, t, A) {
    var ang = t * 84 * Math.PI / 180;
    var leafH = Math.max(1, Math.round(sh * Math.cos(ang)));
    fillInterior(f, A, 0, sw, 0, sh);
    var shadow = Math.round(Math.sin(ang) * sh * 0.18);
    for (var y = leafH; y < Math.min(sh, leafH + shadow); y++) for (var x = 1; x < sw; x++) { put(f, x, y, A.shade[0], A.shade[1], A.shade[2], 255); }
    for (var y2 = 0; y2 < leafH; y2++) {
      var sy = Math.min(sh - 1, Math.floor(y2 * sh / leafH));
      for (var x2 = 0; x2 < sw; x2++) { copyPx(f, x2, y2, src, x2, sy, sw); f.mask[y2 * sw + x2] = 0; }
    }
  }

  /** A shoji or sliding door slides into the wall to the left (or right), leaving a hard shadow line at its edge. */
  function kindSliding(f, src, sw, sh, t, A, opt) {
    var d = Math.round(t * sw * 0.96);
    var right = opt.hinge === 'right';
    fillInterior(f, A, 0, sw, 0, sh);
    for (var y = 0; y < sh; y++) for (var x = 0; x < sw - d; x++) {
      var dx = right ? x + d : x, sx = right ? x : x + d;
      copyPx(f, dx, y, src, sx, y, sw); f.mask[y * sw + dx] = 0;
    }
    if (d > 0 && d < sw) {
      var ex = right ? d : sw - d - 1;
      for (var y2 = 0; y2 < sh; y2++) { put(f, ex, y2, A.dark[0], A.dark[1], A.dark[2], 255); f.mask[y2 * sw + ex] = 0; }
    }
  }

  /** A curtain or hide flap parts from the middle and bunches at the sides, its folds darkened with its own colours. */
  function kindCurtain(f, src, sw, sh, t, A) {
    var half = Math.floor(sw / 2);
    var keep = Math.max(2, Math.round(half * (1 - t * 0.84)));
    fillInterior(f, A, 0, sw, 0, sh);
    for (var side = 0; side < 2; side++) {
      for (var c = 0; c < keep; c++) {
        var scol = Math.min(half - 1, Math.floor(c * half / keep));
        var fold = t > 0.15 && (Math.floor(c * 3 / Math.max(1, keep / 2)) % 2 === 1);
        // a hanging cloth drawn up: its hem rises toward the middle as it parts
        var hem = Math.round(t * sh * 0.18 * (c / Math.max(1, keep)));
        for (var y = 0; y < sh - hem; y++) {
          var sx = side ? sw - 1 - scol : scol, dx = side ? sw - 1 - c : c;
          var j = (y * sw + sx) * 4;
          if (src[j + 3] === 0) continue;
          var r = src[j], g = src[j + 1], b = src[j + 2];
          if (fold) { var p = nearest(A.palette, r * 0.72, g * 0.72, b * 0.72); r = p[0]; g = p[1]; b = p[2]; }
          put(f, dx, y, r, g, b, src[j + 3]); f.mask[y * sw + dx] = 0;
        }
      }
    }
  }

  /**
   * A round vault door rolls aside into the wall. The LEAF is the largest circle centred in the door; everything
   * outside it is the frame and never moves. Inside the circle the leaf translates and turns (whole-pixel inverse
   * rotation, nearest sampling) and is clipped to the circle, so it rolls into the wall rather than off the tile.
   */
  function kindVault(f, src, sw, sh, t, A) {
    var cx = (sw - 1) / 2, cy = (sh - 1) / 2, R = Math.min(sw, sh) / 2 - 0.5;
    var inCircle = function (x, y) { return (x - cx) * (x - cx) + (y - cy) * (y - cy) <= R * R; };
    for (var y0 = 0; y0 < sh; y0++) for (var x0 = 0; x0 < sw; x0++) {
      if (inCircle(x0, y0)) { var b = A.interior[Math.min(3, Math.floor(4 * y0 / sh))]; put(f, x0, y0, b[0], b[1], b[2], 255); f.mask[y0 * sw + x0] = 1; }
      else copyPx(f, x0, y0, src, x0, y0, sw);
    }
    var d = Math.round(t * 2 * R * 0.96);
    var ang = d / Math.max(1, R);
    var ca = Math.cos(-ang), sa = Math.sin(-ang);
    for (var y = 0; y < sh; y++) for (var x = 0; x < sw; x++) {
      if (!inCircle(x, y)) continue;
      var lx = x - d - cx, ly = y - cy;                       // into the leaf's own frame, then un-turn it
      var sx = Math.round(cx + lx * ca - ly * sa), sy = Math.round(cy + lx * sa + ly * ca);
      if (sx < 0 || sy < 0 || sx >= sw || sy >= sh || !inCircle(sx, sy)) continue;
      var j = (sy * sw + sx) * 4;
      if (src[j + 3] === 0) continue;
      copyPx(f, x, y, src, sx, sy, sw); f.mask[y * sw + x] = 0;
    }
  }

  /**
   * A cave mouth or mountain entrance does not open: it reads as a way IN. Its dark pixels (the mouth) get
   * deeper toward their centre in bands of the tile's own darks, and a breath of cold air drifts out of it.
   * `t` here is the phase of the breath (0..1, it loops).
   */
  function kindCave(f, src, sw, sh, t, A, opt) {
    for (var i = 0; i < sw * sh; i++) { var j = i * 4; f.data[j] = src[j]; f.data[j + 1] = src[j + 1]; f.data[j + 2] = src[j + 2]; f.data[j + 3] = src[j + 3]; }
    var mouth = mouthMask(src, sw, sh);
    if (!mouth.count) return;
    var mx = mouth.cx, my = mouth.cy, R = mouth.r;
    f.derived = mouth.bands.slice();
    for (var y = 0; y < sh; y++) for (var x = 0; x < sw; x++) {
      if (!mouth.mask[y * sw + x]) continue;
      var dd = Math.sqrt((x - mx) * (x - mx) + (y - my) * (y - my)) / R;
      var band = dd < 0.4 ? 0 : dd < 0.65 ? 1 : dd < 0.85 ? 2 : 3;
      var c = mouth.bands[band];
      put(f, x, y, c[0], c[1], c[2], 255); f.mask[y * sw + x] = 1;
    }
    // the breath: a few cold motes rising out of the mouth, positions from a seeded table, drifting with the phase
    var seed = (opt.seed || 1) >>> 0;
    var rnd = function () { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; };
    // (a single pixel mote read as a dead pixel at game size, looked at 2026-10-12: a mote is a small cluster, sized to
    // the tile, and there are enough of them to read as a drift of air rather than noise)
    var motes = Math.max(5, Math.round(R / 1.6)), size = Math.max(1, Math.round(sw / 24));
    for (var m = 0; m < motes; m++) {
      var ox = mx + (rnd() - 0.5) * R * 1.3, oy = my + rnd() * R * 0.5, ph = (t + rnd()) % 1;
      var px = Math.round(ox + Math.sin((ph + m) * 6.283) * 2), py = Math.round(oy - ph * R * 1.3);
      if (ph > 0.85) continue;
      var big = ph < 0.5 ? size : Math.max(1, size - 1);         // a mote thins as it drifts away
      for (var by = 0; by < big; by++) for (var bx = 0; bx < big; bx++) {
        var qx = px + bx, qy = py + by;
        if (qx < 0 || qy < 0 || qx >= sw || qy >= sh) continue;
        put(f, qx, qy, 198, 220, 236, 255); f.mask[qy * sw + qx] = 0;
      }
    }
  }

  /** The cave mouth: the connected dark region around the darkest pixel of the lower two thirds of the tile. */
  function mouthMask(src, sw, sh) {
    var lumAt = function (i) { return src[i * 4 + 3] < 128 ? 999 : lum(src[i * 4], src[i * 4 + 1], src[i * 4 + 2]); };
    var seed = -1, best = 1e9, sum = 0, n = 0;
    for (var i = 0; i < sw * sh; i++) { var L = lumAt(i); if (L < 999) { sum += L; n++; } if (Math.floor(i / sw) > sh / 3 && L < best) { best = L; seed = i; } }
    var mask = new Uint8Array(sw * sh);
    if (seed < 0 || !n) return { mask: mask, count: 0 };
    var cut = Math.min(sum / n * 0.62, best + 48);
    var stack = [seed], count = 0, sx = 0, sy = 0;
    mask[seed] = 1;
    while (stack.length) {
      var p = stack.pop(); count++; sx += p % sw; sy += Math.floor(p / sw);
      var x = p % sw, y = Math.floor(p / sw);
      var nb = [x > 0 ? p - 1 : -1, x < sw - 1 ? p + 1 : -1, y > 0 ? p - sw : -1, y < sh - 1 ? p + sw : -1];
      for (var k = 0; k < 4; k++) { var q = nb[k]; if (q >= 0 && !mask[q] && lumAt(q) <= cut) { mask[q] = 1; stack.push(q); } }
    }
    var cx = sx / count, cy = sy / count, r = 1;
    for (var q2 = 0; q2 < sw * sh; q2++) if (mask[q2]) r = Math.max(r, Math.sqrt(Math.pow(q2 % sw - cx, 2) + Math.pow(Math.floor(q2 / sw) - cy, 2)));
    // depth: the rim takes the light of the rock AROUND the mouth (its mean, well dimmed), the heart goes to black,
    // so a near black mouth still reads as a hole with depth rather than a flat patch
    var rr = 0, rg = 0, rb = 0, rn = 0;
    for (var q3 = 0; q3 < sw * sh; q3++) if (!mask[q3] && src[q3 * 4 + 3] >= 128) { rr += src[q3 * 4]; rg += src[q3 * 4 + 1]; rb += src[q3 * 4 + 2]; rn++; }
    var rock = rn ? [rr / rn, rg / rn, rb / rn] : [60, 56, 52];
    var bands = [0.05, 0.12, 0.2, 0.3].map(function (k) { return [Math.round(rock[0] * k), Math.round(rock[1] * k), Math.round(rock[2] * k + 2)]; });
    return { mask: mask, count: count, cx: cx, cy: cy, r: r, bands: bands };
  }

  var DRAW = { door: kindDoor, double: kindDouble, portcullis: kindPortcullis, hatch: kindHatch, sliding: kindSliding, curtain: kindCurtain, vault: kindVault, cave: kindCave };

  /**
   * Dust shed by an old door while it moves: a few motes in the OPEN DOORWAY near the floor, in the door's own
   * lightest tone, so they read against the dark behind it. (The first version scattered them in the door's
   * MAIN colour anywhere across the tile: most landed on the leaf itself and were invisible; the suite caught it.)
   */
  function addDust(f, A, t, seed) {
    if (t <= 0.05 || t >= 0.95) return;
    var s = (seed >>> 0) || 7;
    var rnd = function () { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; };
    var light = A.palette.reduce(function (b, p) { return lum(p[0], p[1], p[2]) > lum(b[0], b[1], b[2]) ? p : b; }, A.dark);
    var spots = [];
    for (var y = Math.floor(f.h * 0.55); y < f.h - 1; y++) for (var x = 0; x < f.w; x++) if (f.mask[y * f.w + x]) spots.push(y * f.w + x);
    if (!spots.length) return;
    var n = Math.max(2, Math.round(f.w / 10));
    for (var i = 0; i < n; i++) {
      var p = spots[Math.floor(rnd() * spots.length)];
      put(f, p % f.w, Math.floor(p / f.w), light[0], light[1], light[2], 255); f.mask[p] = 0;
    }
  }

  /**
   * THE ENTRY POINT. The pixels of a door image at one point of its opening.
   * @param {{data:Uint8ClampedArray|number[], w:number, h:number}} src  the door (one tile, or a grouped block)
   * @param {string} kind  one of KINDS
   * @param {number} t     0 closed .. 1 fully open (for a cave: the phase of its breath)
   * @param {{hinge?:string, dust?:boolean, seed?:number, analysis?:object}} [opt]
   * @returns {{data:Uint8ClampedArray, mask:Uint8Array, w:number, h:number}}  mask = 1 where the doorway shows
   */
  function frame(src, kind, t, opt) {
    opt = opt || {};
    if (!DRAW[kind]) throw new Error('ThresholdCore.frame: unknown kind ' + JSON.stringify(kind));
    var w = src.w, h = src.h;
    if (!(w > 0 && h > 0) || src.data.length !== w * h * 4) throw new Error('ThresholdCore.frame: ' + w + 'x' + h + ' does not match ' + src.data.length + ' bytes');
    t = clamp(Number(t) || 0, 0, 1);
    var A = opt.analysis || analyse(src.data, w, h);
    var f = newFrame(w, h);
    if (A.empty) return f;
    if (kind !== 'cave' && t === 0) {                        // closed is EXACTLY your tile, byte for byte
      for (var i = 0; i < src.data.length; i++) f.data[i] = src.data[i];
      return f;
    }
    // Every kind works on the DOOR, not the cell: the opaque bounding box of the tile, and the doorway behind
    // the leaf is only ever drawn inside the closed door's own silhouette. (The first contact sheet drew the
    // doorway across the whole 48 px cell, a black box wider than the door it was behind.)
    var bb = A.bbox, bw = bb.x1 - bb.x0, bh = bb.y1 - bb.y0;
    var sub = new Uint8ClampedArray(bw * bh * 4);
    for (var yy = 0; yy < bh; yy++) for (var xx = 0; xx < bw; xx++) for (var c = 0; c < 4; c++) sub[(yy * bw + xx) * 4 + c] = src.data[((yy + bb.y0) * w + xx + bb.x0) * 4 + c];
    var sf = newFrame(bw, bh);
    var SA = analyse(sub, bw, bh);
    DRAW[kind](sf, sub, bw, bh, t, SA, opt);
    // the CLOSED list of colours this frame may use that are not the door's own pixels (tests read it, and refuse
    // a list longer than 12: a derived palette that grows is a frame inventing colours under a different name)
    f.derived = [SA.dark, SA.shade].concat(SA.interior.map(function (c) { return c.slice(0, 3); }), [[198, 220, 236]], sf.derived || []);
    if (opt.dust && kind !== 'cave') addDust(sf, SA, t, (opt.seed || 1) + Math.round(t * 97));
    // a SEE-THROUGH door (bars or a grille drawn over nothing) already shows what is behind it, so where it moves away
    // it leaves exactly that: transparency, never a dark ghost of its own bars (measured on the RTP cell bars)
    var see = kind !== 'cave' && holeFraction(sub, bw, bh) >= SEE_THROUGH;
    f.seeThrough = see;
    for (var y2 = 0; y2 < bh; y2++) for (var x2 = 0; x2 < bw; x2++) {
      var si = y2 * bw + x2, di = (y2 + bb.y0) * w + x2 + bb.x0;
      if (sf.mask[si] && (see || sub[si * 4 + 3] < 128)) continue;   // no doorway outside the door's own SOLID outline (a soft painted fringe is not the door)
      if (sf.data[si * 4 + 3] === 0) continue;
      for (var c2 = 0; c2 < 4; c2++) f.data[di * 4 + c2] = sf.data[si * 4 + c2];
      f.mask[di] = sf.mask[si];
    }
    return f;
  }

  /**
   * Group adjacent door events of the same kind into one door (a 2 wide double door, a 2 tall gate).
   * @param {{id:number, x:number, y:number, kind:string, group?:boolean}[]} doors
   * @returns {{key:string, kind:string, x:number, y:number, cols:number, rows:number, ids:number[]}[]}
   */
  function groupDoors(doors) {
    var byPos = {}, seen = {}, out = [];
    doors.forEach(function (d) { byPos[d.x + ',' + d.y] = d; });
    doors.slice().sort(function (a, b) { return a.y - b.y || a.x - b.x; }).forEach(function (d) {
      if (seen[d.id]) return;
      var members = [d]; seen[d.id] = 1;
      if (d.group !== false && d.kind !== 'cave') {
        for (var i = 0; i < members.length; i++) {
          var m = members[i];
          [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(function (o) {
            var n = byPos[(m.x + o[0]) + ',' + (m.y + o[1])];
            if (n && !seen[n.id] && n.kind === d.kind && n.group !== false) { seen[n.id] = 1; members.push(n); }
          });
        }
      }
      var xs = members.map(function (m) { return m.x; }), ys = members.map(function (m) { return m.y; });
      var x0 = Math.min.apply(null, xs), y0 = Math.min.apply(null, ys);
      var cols = Math.max.apply(null, xs) - x0 + 1, rows = Math.max.apply(null, ys) - y0 + 1;
      // a group is only a group when it is a full rectangle; an L-shape opens as separate doors
      if (members.length !== cols * rows) {
        members.slice(1).forEach(function (m) { delete seen[m.id]; });
        members = [d]; x0 = d.x; y0 = d.y; cols = 1; rows = 1;
      }
      out.push({ key: d.kind + '@' + x0 + ',' + y0, kind: d.kind, x: x0, y: y0, cols: cols, rows: rows, ids: members.map(function (m) { return m.id; }).sort(function (a, b) { return a - b; }) });
    });
    return out;
  }

  /** How dark the map's tint is, 0 (day) .. 1 (deep night), from an MZ screen tone [r, g, b, gray]. */
  function nightOf(tone) {
    if (!tone) return 0;
    var avg = (Number(tone[0]) + Number(tone[1]) + Number(tone[2])) / 3;
    return clamp(-avg / 85, 0, 1);
  }

  var API = { KINDS: KINDS, OPENING_KINDS: OPENING_KINDS, STAGE_OF_DIRECTION: STAGE_OF_DIRECTION, parseNote: parseNote, stageOfDirection: stageOfDirection,
    analyse: analyse, frame: frame, groupDoors: groupDoors, nightOf: nightOf, mouthMask: mouthMask, nearest: nearest,
    holeFraction: holeFraction, SEE_THROUGH: SEE_THROUGH, VERSION: '1.0.0' };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  root.ThresholdCore = API;
})(typeof window !== 'undefined' ? window : globalThis);
