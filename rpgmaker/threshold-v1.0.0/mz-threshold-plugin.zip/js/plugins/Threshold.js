/*:
 * @target MZ
 * @plugindesc [v1.0.0] Threshold: every door, gate, hatch and cave mouth in your own tileset opens the way it was drawn.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io/
 * @base ThresholdCore
 * @orderAfter ThresholdCore
 *
 * @help Threshold.js
 *
 * Doors that open, drawn from YOUR tileset. No door sprite sheets.
 *
 * HOW TO MARK A DOOR
 *   1. Make an event and give it a TILE as its graphic (the door tile from your own tileset, in the B to E tabs).
 *   2. Put this in the event's Note box:   <threshold: door>
 *   That is all. Threshold reads that tile's pixels when the map loads and works out how it opens.
 *
 * KINDS (the word after the colon)
 *   door        a hinged door that swings inward          (also: <threshold: door right> to hinge on the right)
 *   double      double doors that part from the middle    (mark BOTH halves; side by side they open as one)
 *   portcullis  a portcullis or bar gate that rises       (also: gate, bars; stack two for a 2 tall gate)
 *   hatch       a floor hatch or trapdoor that lifts      (also: trapdoor)
 *   sliding     a shoji or sliding door                   (also: shoji, slide; "right" slides it the other way)
 *   curtain     a curtain or hide flap that parts         (also: flap, hide)
 *   vault       a round vault door that rolls aside
 *   cave        a cave mouth or mountain entrance         (also: entrance) it does not open: it gets depth
 *                                                          and a breath of cold air, so it reads as a way in
 *   Add "dust" to any opening kind for an old door that sheds dust as it moves:  <threshold: door dust>
 *   Add "nogroup" to keep a door from opening together with a same kind door next to it.
 *
 * OPENING IT: YOUR EXISTING DOOR EVENTS ALREADY WORK
 *   The stock MZ door event opens by turning the event: Turn Left, Turn Right, Turn Up with a short wait
 *   between (the Quick Event "Door" makes exactly this). Threshold reads those four directions as the four
 *   stages of its own opening (down = closed, left = 1/3, right = 2/3, up = open), so a door event you
 *   already have opens your tile instead of a !Door sheet, with no change. A page whose graphic faces up
 *   shows the door already open.
 *
 * PLUGIN COMMANDS (for doors that open on a switch, a lever or a cutscene)
 *   Open Door     Event ID (0 = this event), Wait for completion
 *   Close Door    the same, played backwards
 *   Toggle Door   opens a closed door, closes an open one
 *   A command plays the door's sound from the parameters below, if you set one for its kind.
 *
 * NIGHT
 *   When the screen is tinted dark, a warm light fills every open doorway, stronger the darker the tint, and
 *   the tint does not recolour it. The interior behind a door is never guessed: it is darkness, and at night,
 *   light. (The light stays in the doorway; it is not thrown onto the ground outside.)
 *
 * WHAT IT DOES NOT DO
 *   It does not detect doors on its own: a door is the event you mark. Doors drawn into a wall autotile
 *   (A3/A4) need an event with the door tile on it, as in stock MZ. Chests are not doors.
 *   Passability is yours, exactly as with any door event (Through, Same as characters).
 *
 * Load ThresholdCore.js ABOVE this file. Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.
 *
 * @param openFrames
 * @text Command open time
 * @type number
 * @min 4
 * @max 120
 * @default 18
 * @desc Frames an Open / Close Door command takes (60 = one second).
 *
 * @param stageFrames
 * @text Stage glide
 * @type number
 * @min 1
 * @max 30
 * @default 3
 * @desc Frames to glide from one direction stage to the next when a door event turns (the stock door waits 3).
 *
 * @param nightSpill
 * @text Light spill at night
 * @type boolean
 * @default true
 *
 * @param spillColor
 * @text Spill colour
 * @type string
 * @default #ffbe78
 *
 * @param spillStrength
 * @text Spill strength
 * @type number
 * @min 0
 * @max 100
 * @default 70
 * @desc 0 to 100. The spill at full night; it fades with the tint.
 *
 * @param caveAir
 * @text Cave breath
 * @type boolean
 * @default true
 * @desc Cold air drifting out of cave mouths.
 *
 * @param caveCycle
 * @text Cave breath length
 * @type number
 * @min 30
 * @max 600
 * @default 120
 * @desc Frames for one breath of a cave mouth.
 *
 * @param seDoor
 * @text Sound: door
 * @type file
 * @dir audio/se/
 * @default
 *
 * @param seDouble
 * @text Sound: double
 * @type file
 * @dir audio/se/
 * @default
 *
 * @param sePortcullis
 * @text Sound: portcullis
 * @type file
 * @dir audio/se/
 * @default
 *
 * @param seHatch
 * @text Sound: hatch
 * @type file
 * @dir audio/se/
 * @default
 *
 * @param seSliding
 * @text Sound: sliding
 * @type file
 * @dir audio/se/
 * @default
 *
 * @param seCurtain
 * @text Sound: curtain
 * @type file
 * @dir audio/se/
 * @default
 *
 * @param seVault
 * @text Sound: vault
 * @type file
 * @dir audio/se/
 * @default
 *
 * @command open
 * @text Open Door
 * @desc Open a Threshold door (and every door grouped with it).
 *
 * @arg eventId
 * @text Event ID
 * @type number
 * @min 0
 * @default 0
 * @desc 0 = this event.
 *
 * @arg wait
 * @text Wait for completion
 * @type boolean
 * @default false
 *
 * @command close
 * @text Close Door
 * @desc Close a Threshold door (and every door grouped with it).
 *
 * @arg eventId
 * @text Event ID
 * @type number
 * @min 0
 * @default 0
 *
 * @arg wait
 * @text Wait for completion
 * @type boolean
 * @default false
 *
 * @command toggle
 * @text Toggle Door
 * @desc Open a closed door, close an open one.
 *
 * @arg eventId
 * @text Event ID
 * @type number
 * @min 0
 * @default 0
 *
 * @arg wait
 * @text Wait for completion
 * @type boolean
 * @default false
 */
(() => {
  'use strict';
  const NAME = 'Threshold';
  const RAW = PluginManager.parameters(NAME);
  // parameters arrive as STRINGS and Number('') is 0: a blank is the default, never zero
  const num = (v, d, lo, hi) => { if (v === undefined || v === null || String(v).trim() === '') return d; const n = Number(v); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d; };
  // a boolean is 'true' or 'false'; anything else (blank, a typo) is the default, never a silent off
  const bool = (v, d) => (String(v) === 'true' ? true : String(v) === 'false' ? false : d);
  const P = {
    openFrames: num(RAW.openFrames, 18, 4, 120),
    stageFrames: num(RAW.stageFrames, 3, 1, 30),
    nightSpill: bool(RAW.nightSpill, true),
    spillColor: /^#[0-9a-fA-F]{6}$/.test(String(RAW.spillColor || '')) ? RAW.spillColor : '#ffbe78',
    spillStrength: num(RAW.spillStrength, 70, 0, 100),
    caveAir: bool(RAW.caveAir, true),
    caveCycle: num(RAW.caveCycle, 120, 30, 600),
    se: { door: RAW.seDoor || '', double: RAW.seDouble || '', portcullis: RAW.sePortcullis || '', hatch: RAW.seHatch || '', sliding: RAW.seSliding || '', curtain: RAW.seCurtain || '', vault: RAW.seVault || '' },
  };
  const OPEN_STEPS = 12;     // an opening door has 13 frames: 0/12 .. 12/12, so the four stock stages land exactly on 0, 4, 8, 12
  const CAVE_STEPS = 16;

  // the core is resolved at FIRST USE, never at load: load order is the buyer's choice
  let _core = null;
  function Core() {
    if (!_core) {
      _core = window.ThresholdCore;
      if (!_core) throw new Error('Threshold: ThresholdCore.js is not loaded. Put it ABOVE Threshold.js in the Plugin Manager.');
    }
    return _core;
  }

  // ── which events are doors ─────────────────────────────────────────────────────────────────────
  /** @returns {{kind,hinge,dust,group}|null} the door spec of an event's CURRENT page, or null */
  Game_Event.prototype.thresholdSpec = function () {
    if (!Object.prototype.hasOwnProperty.call(this, '_thrSpecCache')) hideRuntimeSlots(this);
    if (this._thrSpecPage === this._pageIndex && this._thrSpecTile === this.tileId()) return this._thrSpecCache || null;
    this._thrSpecPage = this._pageIndex;
    this._thrSpecTile = this.tileId();
    const data = this.event();
    const tag = data && data.meta ? data.meta.threshold : undefined;
    this._thrSpecCache = (tag !== undefined && this.tileId() > 0 && this._pageIndex >= 0) ? Core().parseNote(tag) : null;
    return this._thrSpecCache;
  };
  /**
   * The spec cache is runtime only and must never be written into a save: declared on the INSTANCE
   * as non-enumerable, because JsonEx walks Object.keys. (Declaring it on the prototype does not work: the first
   * assignment creates an own, enumerable property.)
   */
  function hideRuntimeSlots(ev) {
    for (const k of ['_thrSpecCache', '_thrSpecPage', '_thrSpecTile', '_thrPrevP', '_thrStepAt']) {
      Object.defineProperty(ev, k, { value: undefined, writable: true, enumerable: false, configurable: true });
    }
  }

  /** @returns {number} 0 closed .. 1 open (saved with the event) */
  Game_Event.prototype.thresholdProgress = function () { return Number(this._thrP) || 0; };

  const _setupPageSettings = Game_Event.prototype.setupPageSettings;
  Game_Event.prototype.setupPageSettings = function () {
    _setupPageSettings.call(this);
    const spec = this.thresholdSpec();
    if (spec && spec.kind !== 'cave') {
      // a page shows its door at the stage its graphic's direction says, at once (a page that faces up is open)
      this._thrP = this._thrTarget = Core().stageOfDirection(this.direction());
      this._thrRate = 0;
      this._thrDir = this.direction();
    }
  };

  const _update = Game_Event.prototype.update;
  Game_Event.prototype.update = function () {
    _update.call(this);
    const spec = this.thresholdSpec();
    if (!spec || spec.kind === 'cave') return;
    const d = this.direction();
    if (d !== this._thrDir) {
      // the stock door protocol: a turn is a stage; glide to it over stageFrames
      this._thrDir = d;
      setGroupTarget(this, Core().stageOfDirection(d), (1 / 3) / P.stageFrames);
    }
    this._thrPrevP = this.thresholdProgress();
    this._thrStepAt = Graphics.frameCount;
    stepProgress(this);
  };
  /** One frame of glide toward the target. */
  function stepProgress(ev) {
    const p = ev.thresholdProgress(), t = Number(ev._thrTarget) || 0, r = Number(ev._thrRate) || 0;
    if (p !== t) ev._thrP = r > 0 ? (p < t ? Math.min(t, p + r) : Math.max(t, p - r)) : t;
  }

  // ── groups (adjacent same kind doors open as one) ──────────────────────────────────────────────
  // runtime only, rebuilt per map, never saved: an id -> group table
  const Groups = { mapId: -1, sig: 0, byEvent: new Map(), list: [], frame: -1 };
  /**
   * The groups of the current map. Asked by every door sprite every frame, so the per frame check is an integer
   * signature over the marked events (map, tileset, id, position, tile, kind) and allocates nothing; the groups and
   * their frame keys are rebuilt only when that signature changes.
   */
  function groupsNow() {
    if (!$gameMap) return Groups;
    if (Groups.frame === Graphics.frameCount && Groups.mapId === $gameMap.mapId()) return Groups;
    Groups.frame = Graphics.frameCount;
    const C = Core(), evs = $gameMap._events;
    let sig = (Math.imul($gameMap.mapId(), 2654435761) ^ $gameMap.tilesetId()) | 0;
    for (let i = 0; i < evs.length; i++) {
      const ev = evs[i];
      if (!ev) continue;
      const sp = ev.thresholdSpec();
      if (!sp) continue;
      sig = (Math.imul(sig, 1000003) ^ (ev.eventId() * 7919 + ev.x * 131 + ev.y * 17 + ev.tileId() * 3 + C.KINDS.indexOf(sp.kind) + (sp.group ? 0 : 977))) | 0;
    }
    if (sig === Groups.sig && Groups.mapId === $gameMap.mapId()) return Groups;
    Groups.sig = sig; Groups.mapId = $gameMap.mapId();
    const doors = [];
    for (const ev of $gameMap.events()) {
      const sp = ev.thresholdSpec();
      if (sp) doors.push({ id: ev.eventId(), x: ev.x, y: ev.y, kind: sp.kind, group: sp.group });
    }
    Groups.list = C.groupDoors(doors);
    Groups.byEvent = new Map();
    for (const g of Groups.list) {
      // the key names everything the frames are drawn from: map, tileset (Change Tileset mid map must rebuild, not
      // show the old tileset's door), group and every member's tile
      g.frameKey = $gameMap.mapId() + '@' + $gameMap.tilesetId() + ':' + g.key + ':' + g.ids.map((id) => $gameMap.event(id).tileId()).join(',');
      for (const id of g.ids) Groups.byEvent.set(id, g);
    }
    return Groups;
  }
  function groupOf(ev) { return groupsNow().byEvent.get(ev.eventId()) || null; }
  function setGroupTarget(ev, target, rate) {
    const g = groupOf(ev);
    const ids = g ? g.ids : [ev.eventId()];
    for (const id of ids) {
      const m = $gameMap.event(id);
      if (!m) continue;
      m._thrTarget = target; m._thrRate = rate;
      // a member that already took this frame's step did so toward the OLD target (events update in id order, and a
      // stock door turns inside its own update): redo its step from where it began, so every part of one door shows
      // the same frame (measured on the RTP plank door: the upper half ran one frame behind the lower)
      if (m !== ev && m._thrStepAt === Graphics.frameCount) { m._thrP = m._thrPrevP; stepProgress(m); }
    }
  }

  // ── plugin commands ────────────────────────────────────────────────────────────────────────────
  function commandEvent(interp, args) {
    const id = Number(args.eventId);
    // compare against zero: "0" is truthy as a string
    const ev = $gameMap.event(id > 0 ? id : interp.eventId());
    return ev && ev.thresholdSpec() && ev.thresholdSpec().kind !== 'cave' ? ev : null;
  }
  function drive(interp, args, to) {
    const ev = commandEvent(interp, args);
    if (!ev) return;
    const target = to === 'toggle' ? (ev.thresholdProgress() >= 0.5 ? 0 : 1) : to;
    if (Math.abs(ev.thresholdProgress() - target) < 1e-9) return;
    setGroupTarget(ev, target, 1 / P.openFrames);
    const se = P.se[ev.thresholdSpec().kind];
    if (se) AudioManager.playSe({ name: se, volume: 90, pitch: target > 0 ? 100 : 85, pan: 0 });
    if (String(args.wait) === 'true') interp.wait(Math.ceil(P.openFrames * Math.abs(ev.thresholdProgress() - target)) + 1);
  }
  PluginManager.registerCommand(NAME, 'open', function (args) { drive(this, args, 1); });
  PluginManager.registerCommand(NAME, 'close', function (args) { drive(this, args, 0); });
  PluginManager.registerCommand(NAME, 'toggle', function (args) { drive(this, args, 'toggle'); });

  // ── the frames: built once per door per map, one door per frame, never during play ─────────────
  /*
   * A pixel read is a GPU sync point (measured in an earlier plugin: reading straight from a tileset
   * bitmap cost up to 19-31 ms). So each door is read ONCE, through a small scratch canvas, by a warm pass that
   * handles one door per frame while the map settles, and every frame of its opening is computed then. Opening
   * a door afterwards only moves a frame rectangle: no reads, no allocation.
   */
  const Frames = {
    mapId: -1, byKey: new Map(), pending: [], scratch: null, sctx: null,
    reset(mapId) {
      for (const e of this.byKey.values()) { if (e.bitmap) e.bitmap.destroy(); if (e.spill) e.spill.destroy(); }
      this.byKey = new Map(); this.pending = []; this.mapId = mapId;
    },
    keyOf(g) { return g.frameKey; },
    want(g) {
      const k = this.keyOf(g);
      if (!this.byKey.has(k)) { this.byKey.set(k, { state: 'pending', group: g }); this.pending.push(k); }
      return this.byKey.get(k);
    },
    /** Build at most ONE pending door this frame. */
    step() {
      for (let i = 0; i < this.pending.length; i++) {
        const k = this.pending[i];
        const e = this.byKey.get(k);
        if (!e || e.state !== 'pending') { this.pending.splice(i--, 1); continue; }
        if (!this.sourcesReady(e.group)) continue;
        this.pending.splice(i, 1);
        this.build(e);
        return true;
      }
      return false;
    },
    sourcesReady(g) {
      for (const id of g.ids) { const ev = $gameMap.event(id); if (!ev) return false; const b = tilesetBitmapOf(ev.tileId()); if (!b || !b.isReady()) return false; }
      return true;
    },
    build(e) {
      const g = e.group, tw = $gameMap.tileWidth(), th = $gameMap.tileHeight();
      const W = g.cols * tw, H = g.rows * th;
      if (!this.scratch) { this.scratch = document.createElement('canvas'); this.scratch.width = 0; this.scratch.height = 0; }
      if (this.scratch.width < W || this.scratch.height < H) { this.scratch.width = Math.max(this.scratch.width, W); this.scratch.height = Math.max(this.scratch.height, H); this.sctx = null; }
      if (!this.sctx) this.sctx = this.scratch.getContext('2d', { willReadFrequently: true });
      const ctx = this.sctx;
      ctx.clearRect(0, 0, W, H);
      let lead = null;
      for (const id of g.ids) {
        const ev = $gameMap.event(id);
        if (!lead) lead = ev;
        const tid = ev.tileId(), b = tilesetBitmapOf(tid);
        const sx = ((Math.floor(tid / 128) % 2) * 8 + (tid % 8)) * tw, sy = (Math.floor((tid % 256) / 8) % 16) * th;
        // read the tileset's own image, exactly as the engine's Bitmap.blt does (rmmz_core.js:1502). Never `b.canvas`:
        // that getter builds a canvas COPY of the shared tileset and swaps its texture onto it (rmmz_core.js:1750).
        ctx.drawImage(b._canvas || b._image, sx, sy, tw, th, (ev.x - g.x) * tw, (ev.y - g.y) * th, tw, th);
      }
      const img = ctx.getImageData(0, 0, W, H);
      const src = { data: img.data, w: W, h: H };
      const spec = lead.thresholdSpec();
      const C = Core(), A = C.analyse(src.data, W, H);
      const cave = g.kind === 'cave';
      const N = (cave ? CAVE_STEPS : OPEN_STEPS + 1);
      const bmp = new Bitmap(W * N, H), spill = cave ? null : new Bitmap(W * N, H);
      const seed = hash(g.key);
      const rgb = hexRgb(P.spillColor);
      for (let n = 0; n < N; n++) {
        const t = cave ? n / CAVE_STEPS : n / OPEN_STEPS;
        const f = cave && !P.caveAir ? C.frame(src, 'cave', 0.95, { seed, analysis: A }) : C.frame(src, g.kind, t, { hinge: spec.hinge, dust: spec.dust, seed, analysis: A });
        bmp.context.putImageData(new ImageData(f.data, W, H), n * W, 0);
        if (spill) {
          // the spill lives on the doorway's own mask, pooled at the floor and falling off upward, its core whitening
          // toward the floor, so it reads as light coming OUT of a lit room (a flat fill read as a tan panel: looked at,
          // 2026-10-12, the night plate)
          const s = new Uint8ClampedArray(W * H * 4);
          for (let y = 0; y < H; y++) {
            const v = y / Math.max(1, H - 1), k = v * v;
            const a = Math.round(255 * (0.18 + 0.82 * Math.pow(v, 1.4)));
            const r = Math.round(rgb[0] + (255 - rgb[0]) * 0.55 * k), gg = Math.round(rgb[1] + (244 - rgb[1]) * 0.55 * k), bb = Math.round(rgb[2] + (220 - rgb[2]) * 0.55 * k);
            for (let x = 0; x < W; x++) {
              const i = y * W + x;
              if (!f.mask[i]) continue;
              s[i * 4] = r; s[i * 4 + 1] = gg; s[i * 4 + 2] = bb; s[i * 4 + 3] = a;
            }
          }
          spill.context.putImageData(new ImageData(s, W, H), n * W, 0);
        }
      }
      bmp.baseTexture.update();
      if (spill) spill.baseTexture.update();
      e.bitmap = bmp; e.spill = spill; e.N = N; e.W = W; e.H = H; e.tw = tw; e.th = th; e.state = 'ready';
      Frames.built = (Frames.built || 0) + 1;
    },
  };
  function tilesetBitmapOf(tileId) {
    const ts = $gameMap.tileset();
    const name = ts ? ts.tilesetNames[5 + Math.floor(tileId / 256)] : '';
    return name ? ImageManager.loadTileset(name) : null;
  }
  function hash(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0) || 1; }
  function hexRgb(h) { return [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)]; }

  /*
   * THE LIGHT LAYER. MZ tints the map with a colour filter on the spriteset's base sprite, which recolours anything
   * inside it: a warm spill drawn there came out MAGENTA under a blue night tone (looked at, 2026-10-11). Light is
   * not tinted by the dark it falls through, so the spills live in their own layer just above the base sprite (where
   * MZ keeps its own untoned layers, below pictures) and are drawn additively.
   */
  const _createLowerLayer = Spriteset_Map.prototype.createLowerLayer;
  Spriteset_Map.prototype.createLowerLayer = function () {
    _createLowerLayer.call(this);
    this._thrLightLayer = new Sprite();
    this.addChild(this._thrLightLayer);
  };

  const _spritesetCreate = Spriteset_Map.prototype.createCharacters;
  Spriteset_Map.prototype.createCharacters = function () {
    Frames.reset($gameMap.mapId());
    _spritesetCreate.call(this);
  };
  const _spritesetUpdate = Spriteset_Map.prototype.update;
  Spriteset_Map.prototype.update = function () {
    // build BEFORE the sprites update, so a door built this frame is shown this frame (measured: built after, the
    // last door of a map showed its stock tile for one extra frame)
    Frames.step();
    _spritesetUpdate.call(this);
  };

  // ── the sprite ─────────────────────────────────────────────────────────────────────────────────
  function doorEntry(ch) {
    if (!(ch instanceof Game_Event)) return null;
    const spec = ch.thresholdSpec();
    if (!spec) return null;
    const g = groupOf(ch);
    if (!g) return null;
    return Frames.want(g);
  }

  const _updateBitmap = Sprite_Character.prototype.updateBitmap;
  Sprite_Character.prototype.updateBitmap = function () {
    const e = doorEntry(this._character);
    if (e && e.state === 'ready') {
      if (this.bitmap !== e.bitmap) {
        this.bitmap = e.bitmap;
        this._thrEntry = e;
        // the stock tracking fields, so the stock path does not swap the tile back next frame
        this._tilesetId = $gameMap.tilesetId(); this._tileId = this._character.tileId();
        this._characterName = this._character.characterName(); this._characterIndex = this._character.characterIndex();
      }
      return;
    }
    if (this._thrEntry) { this._thrEntry = null; this._tileId = -1; }   // left Threshold: let the stock path redraw
    _updateBitmap.call(this);
  };

  const _updateFrame = Sprite_Character.prototype.updateFrame;
  Sprite_Character.prototype.updateFrame = function () {
    const e = this._thrEntry;
    if (!e || e.state !== 'ready' || this.bitmap !== e.bitmap) { this.thrHideSpill(); return _updateFrame.call(this); }
    const ch = this._character, g = e.group;
    let n;
    if (g.kind === 'cave') n = Math.floor((Graphics.frameCount % P.caveCycle) / P.caveCycle * CAVE_STEPS) % CAVE_STEPS;
    else n = Math.round(ch.thresholdProgress() * OPEN_STEPS);
    const ox = (ch.x - g.x) * e.tw, oy = (ch.y - g.y) * e.th;
    this.setFrame(n * e.W + ox, oy, e.tw, e.th);
    this.thrUpdateSpill(e, n, ox, oy);
  };

  Sprite_Character.prototype.thrUpdateSpill = function (e, n, ox, oy) {
    const night = P.nightSpill && e.spill && n > 0 ? Core().nightOf($gameScreen.tone()) : 0;
    const op = Math.round(255 * night * P.spillStrength / 100);
    if (op <= 0) { this.thrHideSpill(); return; }
    const ss = SceneManager._scene && SceneManager._scene._spriteset;
    const layer = ss && ss._thrLightLayer;
    if (!layer) { this.thrHideSpill(); return; }
    if (!this._thrSpill || this._thrSpill.parent !== layer) {
      this._thrSpill = new Sprite();
      this._thrSpill.anchor.x = 0.5; this._thrSpill.anchor.y = 1;
      this._thrSpill.blendMode = 1;                              // PIXI ADD: light adds to what it falls on
      layer.addChild(this._thrSpill);
    }
    const s = this._thrSpill;
    if (s.bitmap !== e.spill) s.bitmap = e.spill;
    s.setFrame(n * e.W + ox, oy, e.tw, e.th);
    s.x = this.x; s.y = this.y;
    s.opacity = op; s.visible = true;
  };
  Sprite_Character.prototype.thrHideSpill = function () { if (this._thrSpill) this._thrSpill.visible = false; };

  // a test and support seam: how many doors are built and waiting, read only
  window.Threshold = {
    version: '1.0.0',
    stats: () => ({ built: Frames.built || 0, pending: Frames.pending.length, groups: groupsNow().list.length }),
    groups: () => groupsNow().list.map((g) => Object.assign({}, g, { ids: g.ids.slice() })),
  };
})();
