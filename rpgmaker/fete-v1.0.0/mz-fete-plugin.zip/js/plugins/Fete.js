/*:
 * @target MZ
 * @plugindesc [v1.0.0] Fete 3/3 - dress your own towns for their festivals. Switchable, saved, played in with a transition.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @param transition
 * @text Default transition
 * @type select
 * @option unspool
 * @option fade
 * @option none
 * @default unspool
 * @desc How a dressing arrives and leaves when nothing else is asked for. unspool: strings run out post to post, things rise.
 *
 * @param duration
 * @text Default duration (frames)
 * @type number
 * @min 1
 * @max 600
 * @default 90
 * @desc Length of a transition in frames (60 = one second).
 *
 * @param lights
 * @text Lamps
 * @type select
 * @option auto
 * @option always
 * @option never
 * @option switch
 * @default auto
 * @desc auto: lamps shine as the screen is tinted darker (Tint Screen). switch: shine while the Lamp switch is ON.
 *
 * @param lightSwitch
 * @text Lamp switch
 * @type switch
 * @default 0
 * @desc Used when Lamps is "switch": the lamps shine while this switch is ON.
 *
 * @param air
 * @text Air particles
 * @type number
 * @min 0
 * @max 120
 * @default 36
 * @desc How many leaves, petals, sky lanterns, motes or wisps drift over a dressed map. 0 = none.
 *
 * @param solid
 * @text Solid decorations
 * @type boolean
 * @on Block movement
 * @off Walk through
 * @default true
 * @desc Posts, stalls and the centrepiece block their cell, but only where every path round them stays open.
 *
 * @param sway
 * @text Wind sway
 * @type boolean
 * @default true
 * @desc Strings and banners move gently in the wind.
 *
 * @param pixel
 * @text Pixel size
 * @type number
 * @min 1
 * @max 4
 * @default 1
 * @desc 1 draws the decorations smooth (for 48 px art such as the RTP). 2 or 3 draws them in chunky pixels to sit with pixel-art tiles drawn at 2x or 3x.
 *
 * @param bindings
 * @text Switch bindings
 * @type struct<Binding>[]
 * @default []
 * @desc A map (or a region of it) is dressed while a switch is ON. Map ID 0 = every map whose note says <Fete town>.
 *
 * @command set
 * @text Set Dressing
 * @desc Dress the whole map, one region of it, or a rectangle, in one of the five dressings.
 *
 * @arg dressing
 * @text Dressing
 * @type select
 * @option harvest
 * @option lantern
 * @option blossom
 * @option midwinter
 * @option hallows
 * @default harvest
 *
 * @arg target
 * @text Target
 * @type select
 * @option map
 * @option region
 * @option rect
 * @default map
 *
 * @arg regionId
 * @text Region ID
 * @type number
 * @min 1
 * @max 255
 * @default 1
 * @desc Used when Target is region.
 *
 * @arg x
 * @text Rect X
 * @type number
 * @default 0
 * @arg y
 * @text Rect Y
 * @type number
 * @default 0
 * @arg width
 * @text Rect width
 * @type number
 * @min 1
 * @default 10
 * @arg height
 * @text Rect height
 * @type number
 * @min 1
 * @default 10
 *
 * @arg mapId
 * @text Map ID
 * @type number
 * @default 0
 * @desc 0 = the current map. Another map is dressed when the player next arrives there.
 *
 * @arg transition
 * @text Transition
 * @type select
 * @option default
 * @option unspool
 * @option fade
 * @option none
 * @default default
 *
 * @arg duration
 * @text Duration (frames)
 * @type number
 * @default 0
 * @desc 0 = the plugin's default duration.
 *
 * @arg wait
 * @text Wait for completion
 * @type boolean
 * @default false
 *
 * @command clear
 * @text Clear Dressing
 * @desc Take a dressing down. The map stays bare until you set a dressing again or release it back to its notes.
 *
 * @arg target
 * @text Target
 * @type select
 * @option map
 * @option region
 * @option rect
 * @option all
 * @default all
 *
 * @arg regionId
 * @text Region ID
 * @type number
 * @default 1
 * @arg x
 * @text Rect X
 * @type number
 * @default 0
 * @arg y
 * @text Rect Y
 * @type number
 * @default 0
 * @arg width
 * @text Rect width
 * @type number
 * @default 10
 * @arg height
 * @text Rect height
 * @type number
 * @default 10
 * @arg mapId
 * @text Map ID
 * @type number
 * @default 0
 * @arg transition
 * @text Transition
 * @type select
 * @option default
 * @option unspool
 * @option fade
 * @option none
 * @default default
 * @arg duration
 * @text Duration (frames)
 * @type number
 * @default 0
 * @arg wait
 * @text Wait for completion
 * @type boolean
 * @default false
 *
 * @command release
 * @text Release to Notes
 * @desc Forget every Set / Clear on a map, so its notetags and switch bindings decide again.
 *
 * @arg mapId
 * @text Map ID
 * @type number
 * @default 0
 * @arg transition
 * @text Transition
 * @type select
 * @option default
 * @option unspool
 * @option fade
 * @option none
 * @default default
 *
 * @command lamps
 * @text Lamps On / Off / Auto
 * @desc Override the Lamps setting for the rest of the game (saved).
 *
 * @arg mode
 * @text Lamps
 * @type select
 * @option on
 * @option off
 * @option auto
 * @default auto
 *
 * @help
 * Fete - your own towns, dressed for their festivals.
 *
 * Fete reads the map you already built - where the houses are, their eaves and
 * front walls, the gaps between them, your lanes and your square - and dresses
 * it: bunting strung eave to eave and zigzagged across the lanes, lamp posts
 * along the house fronts and the roads with festoons between them, banners and
 * wreaths on free wall, market stalls round the square and a centrepiece in it,
 * and leaves, petals, sky lanterns, motes or wisps drifting over it all.
 *
 * Five dressings: harvest (Harvest Fair), lantern (Lantern Night), blossom
 * (Spring Blossom), midwinter (Midwinter) and hallows (All Hallows).
 *
 * Every decoration is drawn by the plugin. There are no image files to import
 * and nothing is written into your map: switch the dressing off and the town is
 * exactly as you made it.
 *
 * Requires FeteCore.js and FeteDraw.js (any order in the Plugin Manager).
 *
 * MAP NOTETAGS (Map Properties > Note)
 *   <Fete: harvest>               the map is dressed whenever nothing else says
 *   <Fete region 5: lantern>      region 5 takes its own dressing
 *   <Fete switch 12: hallows>     dressed while switch 12 is ON
 *   <Fete switch 12 region 5: lantern>   region 5 only, while switch 12 is ON
 *   <Fete square region 9>        region 9 is the square (the centrepiece and
 *                                 the stalls go there)
 *   <Fete mask region 3>          never decorate region 3
 *   <Fete solid: off>             decorations on this map never block movement
 *   <Fete air: 0>                 no particles on this map (or a number)
 *   <Fete town>                   this map takes the plugin's bindings whose
 *                                 Map ID is 0
 *
 * WHAT DECIDES A MAP'S DRESSING (first match wins, per target)
 *   1. Set Dressing / Clear Dressing commands (saved with the game)
 *   2. Switch bindings that are ON (notetag ones, then the plugin's)
 *   3. The plain notetag (<Fete: ...>, <Fete region n: ...>)
 *   A rect set by command wins over a region, a region over the whole map.
 *
 * PLUGIN COMMANDS
 *   Set Dressing    map, region or rect; transition unspool, fade or none
 *   Clear Dressing  take it down (stays down until set or released)
 *   Release to Notes  forget the commands for a map
 *   Lamps On / Off / Auto
 *
 * SCRIPT CALLS
 *   Fete.set('map', 'harvest')
 *   Fete.set('region', 'lantern', { regionId: 5, transition: 'fade' })
 *   Fete.set('rect', 'blossom', { x: 3, y: 4, width: 8, height: 6 })
 *   Fete.clear('all')     Fete.release()     Fete.isBusy()
 *   Fete.stateAt(x, y)    -> 'harvest' ... or null
 *
 * NIGHT
 *   With Lamps = auto (the default) the lamps, lantern strings, the tree and
 *   the bonfire shine brighter the darker you tint the screen. Tint Screen to
 *   (-68, -68, 0, 68) for a festival night.
 *
 * Saved games: the record lives in $gameSystem._fete (versioned). Old saves
 * load without it and simply follow the notes.
 *
 * Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.
 */
/*~struct~Binding:
 * @param switchId
 * @text Switch
 * @type switch
 * @default 0
 *
 * @param mapId
 * @text Map ID
 * @type number
 * @default 0
 * @desc 0 = every map whose note says <Fete town>.
 *
 * @param dressing
 * @text Dressing
 * @type select
 * @option harvest
 * @option lantern
 * @option blossom
 * @option midwinter
 * @option hallows
 * @default harvest
 *
 * @param regionId
 * @text Region ID
 * @type number
 * @default 0
 * @desc 0 = the whole map.
 */
/* Fete - engine glue. The only Fete file that touches MZ: Spriteset_Map layers, notetags, switch bindings, plugin
 * commands, the transition, the save record. Prototype extension only; every patched original is saved and called.
 * Copyright (c) 2026 Core Systems Asset Factory. */
var Fete = (function () {
  'use strict';
  var NAME = 'Fete', DRESS = ['harvest', 'lantern', 'blossom', 'midwinter', 'hallows'], SAVE_V = 1;
  var raw = (typeof PluginManager !== 'undefined' && PluginManager.parameters(NAME)) || {};
  // parameters arrive as STRINGS; a blank is absent, never zero (wing section 16)
  function num(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; var n = Number(v); return isFinite(n) ? n : d; }
  function bool(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; return String(v).trim() === 'true'; }
  function pick(v, list, d) { v = String(v === undefined ? '' : v).trim(); return list.indexOf(v) >= 0 ? v : d; }
  var P = {
    transition: pick(raw.transition, ['unspool', 'fade', 'none'], 'unspool'),
    duration: Math.max(1, Math.min(600, num(raw.duration, 90))),
    lights: pick(raw.lights, ['auto', 'always', 'never', 'switch'], 'auto'),
    lightSwitch: num(raw.lightSwitch, 0),
    air: Math.max(0, Math.min(120, num(raw.air, 36))),
    solid: bool(raw.solid, true),
    sway: bool(raw.sway, true),
    pixel: Math.max(1, Math.min(4, Math.round(num(raw.pixel, 1)))),
    bindings: []
  };
  try {
    var list = JSON.parse(raw.bindings || '[]');
    for (var bi = 0; bi < list.length; bi++) {
      var b = typeof list[bi] === 'string' ? JSON.parse(list[bi]) : list[bi], sw = num(b.switchId, 0), dr = pick(b.dressing, DRESS, '');
      if (sw > 0 && dr) P.bindings.push({ sw: sw, mapId: num(b.mapId, 0), region: num(b.regionId, 0), d: dr });
    }
  } catch (e) { console.warn('Fete: the Switch bindings parameter could not be read (' + e.message + '); none are used.'); }

  /** FeteCore and FeteDraw, resolved at FIRST USE so the Plugin Manager order is the buyer's choice */
  function deps() {
    var C = typeof FeteCore !== 'undefined' ? FeteCore : null, D = typeof FeteDraw !== 'undefined' ? FeteDraw : null;
    if (!C || !D) throw new Error('Fete: turn on FeteCore.js and FeteDraw.js in the Plugin Manager (missing: ' + (!C ? 'FeteCore ' : '') + (!D ? 'FeteDraw' : '') + ')');
    return { C: C, D: D };
  }

  // ── notes ───────────────────────────────────────────────────────────────────────────────────────────────────────────
  /** read a map's note into { base, regions{}, switches[], square, mask[], solid, air, town } */
  function readNotes(note) {
    var n = { base: null, regions: {}, switches: [], square: 0, mask: [], solid: null, air: null, town: false }, m, re;
    note = String(note || '');
    m = /<Fete:\s*(\w+)\s*>/i.exec(note); if (m && DRESS.indexOf(m[1].toLowerCase()) >= 0) n.base = m[1].toLowerCase();
    re = /<Fete region (\d+):\s*(\w+)\s*>/gi; while ((m = re.exec(note))) if (DRESS.indexOf(m[2].toLowerCase()) >= 0) n.regions[Number(m[1])] = m[2].toLowerCase();
    re = /<Fete switch (\d+)(?: region (\d+))?:\s*(\w+)\s*>/gi; while ((m = re.exec(note))) if (DRESS.indexOf(m[3].toLowerCase()) >= 0 && Number(m[1]) > 0) n.switches.push({ sw: Number(m[1]), region: m[2] ? Number(m[2]) : 0, d: m[3].toLowerCase() });
    m = /<Fete square region (\d+)>/i.exec(note); if (m) n.square = Number(m[1]);
    re = /<Fete mask region (\d+)>/gi; while ((m = re.exec(note))) n.mask.push(Number(m[1]));
    m = /<Fete solid:\s*(on|off|true|false)\s*>/i.exec(note); if (m) n.solid = /on|true/i.test(m[1]);
    m = /<Fete air:\s*(\d+)\s*>/i.exec(note); if (m) n.air = Math.min(120, Number(m[1]));
    n.town = /<Fete town>/i.test(note);
    return n;
  }

  // ── the save record ─────────────────────────────────────────────────────────────────────────────────────────────────
  /** $gameSystem._fete = { v, maps: { id: { all, regions{}, rects[] } }, lamps } - plain data, lossless through JsonEx */
  function store() {
    var s = $gameSystem._fete;
    if (!s || typeof s !== 'object') s = $gameSystem._fete = { v: SAVE_V, maps: {}, lamps: null };
    if (!s.maps) s.maps = {};
    if (s.v !== SAVE_V) s.v = SAVE_V;   // v1 is the first schema; a later one migrates here
    return s;
  }
  function mapRec(mapId, make) { var s = store(), r = s.maps[mapId]; if (!r && make) r = s.maps[mapId] = { all: undefined, regions: {}, rects: [] }; return r || null; }
  var rev = 0;   // bumped by every command: the live layer re-resolves when it moves

  /** what dresses map mapId right now: { all, regions{}, rects[] } (null = bare), following the precedence in @help */
  function resolve(mapId, notes) {
    var r = mapRec(mapId, false), out = { all: null, regions: {}, rects: [] }, k, i;
    // 3. the plain notes
    out.all = notes.base; for (k in notes.regions) out.regions[k] = notes.regions[k];
    // 2. switch bindings that are ON (the notes' first, then the plugin's), applied over the notes
    var binds = notes.switches.slice();
    for (i = 0; i < P.bindings.length; i++) { var pb = P.bindings[i]; if (pb.mapId === mapId || (pb.mapId === 0 && notes.town)) binds.push(pb); }
    var seen = {};
    for (i = 0; i < binds.length; i++) { var bd = binds[i], key = 'r' + bd.region; if (seen[key] || !$gameSwitches.value(bd.sw)) continue; seen[key] = 1; if (bd.region > 0) out.regions[bd.region] = bd.d; else out.all = bd.d; }
    // 1. commands
    if (r) {
      if (r.all !== undefined) out.all = r.all === 'none' ? null : r.all;
      for (k in r.regions) { if (r.regions[k] === 'none') delete out.regions[k]; else out.regions[k] = r.regions[k]; }
      for (i = 0; i < r.rects.length; i++) out.rects.push(r.rects[i]);
    }
    return out;
  }
  /** the switch ids a map's resolution reads */
  function watchedSwitches(mapId, notes) {
    var ids = [], i; for (i = 0; i < notes.switches.length; i++) ids.push(notes.switches[i].sw);
    for (i = 0; i < P.bindings.length; i++) if (P.bindings[i].mapId === mapId || (P.bindings[i].mapId === 0 && notes.town)) ids.push(P.bindings[i].sw);
    if (P.lights === 'switch' && P.lightSwitch > 0) ids.push(P.lightSwitch);
    return ids;
  }

  // ── commands ────────────────────────────────────────────────────────────────────────────────────────────────────────
  function targetMap(opts) { var id = num(opts && opts.mapId, 0); return id > 0 ? id : $gameMap.mapId(); }
  function noteTransition(opts) { var t = opts && opts.transition; return t && t !== 'default' ? pick(t, ['unspool', 'fade', 'none'], P.transition) : P.transition; }
  function noteDuration(opts) { var d = num(opts && opts.duration, 0); return d > 0 ? Math.min(600, d) : P.duration; }
  var pendingTransition = null;
  /**
   * Dress a target. target 'map' | 'region' | 'rect'; dressing one of the five or 'none'; opts { regionId, x, y, width,
   * height, mapId, transition, duration }.
   */
  function set(target, dressing, opts) {
    opts = opts || {}; var d = dressing === 'none' ? 'none' : pick(dressing, DRESS, null);
    if (!d) { console.warn('Fete: unknown dressing "' + dressing + '" (use ' + DRESS.join(', ') + ')'); return false; }
    var r = mapRec(targetMap(opts), true);
    if (target === 'region') { var rid = num(opts.regionId, 0); if (rid < 1) return false; r.regions[rid] = d; }
    else if (target === 'rect') {
      var rc = { x: num(opts.x, 0), y: num(opts.y, 0), w: Math.max(1, num(opts.width, 1)), h: Math.max(1, num(opts.height, 1)), d: d };
      for (var i = r.rects.length - 1; i >= 0; i--) if (r.rects[i].x === rc.x && r.rects[i].y === rc.y && r.rects[i].w === rc.w && r.rects[i].h === rc.h) r.rects.splice(i, 1);
      r.rects.push(rc);
    } else r.all = d;
    pendingTransition = { mode: noteTransition(opts), dur: noteDuration(opts) }; rev++;
    return true;
  }
  /** take a dressing down: target 'map' | 'region' | 'rect' | 'all' (the whole map, its regions and rects) */
  function clear(target, opts) {
    opts = opts || {}; var r = mapRec(targetMap(opts), true);
    if (target === 'region') { var rid = num(opts.regionId, 0); if (rid > 0) r.regions[rid] = 'none'; }
    else if (target === 'rect') { var x = num(opts.x, 0), y = num(opts.y, 0), w = num(opts.width, 1), h = num(opts.height, 1); r.rects = r.rects.filter(function (q) { return !(q.x === x && q.y === y && q.w === w && q.h === h); }); r.rects.push({ x: x, y: y, w: Math.max(1, w), h: Math.max(1, h), d: 'none' }); }
    else if (target === 'map') r.all = 'none';
    else { r.all = 'none'; var reg = {}, notes = $dataMap && targetMap(opts) === $gameMap.mapId() ? readNotes($dataMap.note) : { regions: {} }; for (var k in notes.regions) reg[k] = 'none'; for (k in r.regions) reg[k] = 'none'; r.regions = reg; r.rects = []; }
    pendingTransition = { mode: noteTransition(opts), dur: noteDuration(opts) }; rev++;
    return true;
  }
  /** forget every command on a map so its notes and bindings decide again */
  function release(opts) { opts = opts || {}; var s = store(); delete s.maps[targetMap(opts)]; pendingTransition = { mode: noteTransition(opts), dur: noteDuration(opts) }; rev++; return true; }
  function lamps(mode) { store().lamps = mode === 'on' ? true : mode === 'off' ? false : null; rev++; }

  // ── the layer ───────────────────────────────────────────────────────────────────────────────────────────────────────
  var live = null;
  /** pixel size 2+: a body pixel with less alpha than this is dropped, the rest made opaque (60: a one-pixel string at half
   *  size survives; LOOKED AT 2026-10-18, a cut at 110 dropped the festoon strings and left their bulbs floating) */
  var ALPHA_CUT = 60;
  function easeOutBack(t) { var c = 1.4; t = t - 1; return 1 + (c + 1) * t * t * t + c * t * t; }
  function clamp01(v) { return v < 0 ? 0 : v > 1 ? 1 : v; }
  function posMod(a, m) { return ((a % m) + m) % m; }

  /** Fete's sprites for one Spriteset_Map: objects in the tilemap (sorted with characters), lights above the screen tint,
   *  air particles. Built from the resolution; every allocation happens in build(), none per frame. */
  function FeteLayer(spriteset) {
    if (live && live !== this) live.dispose();
    live = this;
    this.ss = spriteset; this.tm = spriteset._tilemap; this.mapId = $gameMap.mapId(); this.notes = readNotes($dataMap.note);
    this.W = $gameMap.width(); this.H = $gameMap.height();
    this.entries = []; this.bitmaps = []; this.solid = null; this.cellD = null; this.sig = ''; this.res = null;
    this.phase = 'idle'; this.t = 0; this.dur = 1; this.mode = 'none'; this.next = null; this.frame = 0; this.airKind = null; this.progress = 1;
    this.watch = watchedSwitches(this.mapId, this.notes); this.watchV = new Uint8Array(this.watch.length); this.rev = -1;
    this.lightBox = new Sprite(); this.lightBox.z = 0; spriteset.addChild(this.lightBox);           // beside the weather: never toned
    this.airLow = new Sprite(); spriteset._baseSprite.addChild(this.airLow);                        // over the tilemap, toned with it
    this.airHigh = new Sprite(); spriteset.addChild(this.airHigh);                                   // glowing particles, never toned
    this.air = null; this.reads = 0; this.builds = 0;
    this.check(true);
  }
  /** re-resolve when a command ran or a watched switch moved; start a transition when the picture would change */
  FeteLayer.prototype.check = function (first) {
    var moved = this.rev !== rev, i;
    for (i = 0; i < this.watch.length; i++) { var v = $gameSwitches.value(this.watch[i]) ? 1 : 0; if (v !== this.watchV[i]) { this.watchV[i] = v; moved = true; } }
    if (!moved && !first) return;
    this.rev = rev;
    var res = resolve(this.mapId, this.notes), sig = JSON.stringify(res);
    if (sig === this.sig && !first) { pendingTransition = null; return; }
    var tr = pendingTransition || { mode: P.transition, dur: P.duration }; pendingTransition = null;
    if (first || tr.mode === 'none' || !this.entries.length) {
      this.build(res, sig);
      if (first || tr.mode === 'none') { this.phase = 'idle'; this.progress = 1; this.apply(1, 'none'); }
      else { this.phase = 'in'; this.mode = tr.mode; this.dur = tr.dur; this.t = 0; this.apply(0, tr.mode); }
      return;
    }
    // something is up: take it down, then (if anything is wanted) put the new one up
    this.next = { res: res, sig: sig, mode: tr.mode, dur: tr.dur };
    this.phase = 'out'; this.mode = tr.mode; this.dur = Math.max(1, Math.round(tr.dur / 2)); this.t = 0;
  };
  /** the dressing index (1-5, 0 bare) of every cell under resolution res */
  FeteLayer.prototype.cells = function (res) {
    var W = this.W, H = this.H, N = W * H, out = new Uint8Array(N), map = $dataMap.data, mask = this.notes.mask, i, x, y, k;
    var di = function (d) { return d ? DRESS.indexOf(d) + 1 : 0; }, all = di(res.all);
    for (i = 0; i < N; i++) {
      var reg = map[5 * N + i] || 0; if (mask.indexOf(reg) >= 0) { out[i] = 0; continue; }
      out[i] = res.regions[reg] !== undefined ? di(res.regions[reg]) : all;
    }
    for (k = 0; k < res.rects.length; k++) { var rc = res.rects[k], v = rc.d === 'none' ? 0 : di(rc.d); for (y = rc.y; y < rc.y + rc.h && y < H; y++) for (x = rc.x; x < rc.x + rc.w && x < W; x++) if (x >= 0 && y >= 0 && mask.indexOf(map[5 * N + y * W + x] || 0) < 0) out[y * W + x] = v; }
    return out;
  };
  /** plan, draw and sprite resolution res (the only place Fete allocates) */
  FeteLayer.prototype.build = function (res, sig) {
    var dp = deps(), C = dp.C, D = dp.D, W = this.W, H = this.H, T = $gameMap.tileWidth(), PX = P.pixel, TB = T / PX, i, k;
    this.px = PX;
    this.clearSprites();
    this.res = res; this.sig = sig; this.builds++;
    var cellD = this.cells(res); this.cellD = cellD;
    var events = [], evs = $gameMap.events(); for (i = 0; i < evs.length; i++) if (evs[i]) events.push({ x: evs[i].x, y: evs[i].y });
    var de = $dataMap.events || []; for (i = 0; i < de.length; i++) if (de[i]) events.push({ x: de[i].x, y: de[i].y });
    var A = C.analyse({ width: W, height: H, data: $dataMap.data }, $gameMap.tilesetFlags(), events);
    var solidOn = this.notes.solid !== null ? this.notes.solid : P.solid, its = [], counts = [0, 0, 0, 0, 0, 0];
    this.solid = new Uint8Array(W * H);
    for (k = 1; k <= DRESS.length; k++) {
      var any = false; for (i = 0; i < cellD.length; i++) if (cellD[i] === k) { any = true; break; }
      if (!any) continue;
      // (the open-ground fallback centrepiece belongs to the map's own dressing only, never to a region's or a rectangle's)
      var kk = k, pl = C.plan(A, { seed: this.mapId * 7919 + k, inside: function (x, y) { return cellD[y * W + x] === kk; }, squareRegion: this.notes.square, solid: solidOn, fallbackSquare: DRESS[k - 1] === res.all });
      if (solidOn) for (i = 0; i < pl.solid.length; i++) this.solid[pl.solid[i]] = 1;
      // every item twice: at the map's tile size (where it stands) and at the drawing size, tile / pixel (how it is drawn)
      var list = D.items(pl, DRESS[k - 1], T), listB = PX > 1 ? D.items(pl, DRESS[k - 1], TB) : list;
      for (i = 0; i < list.length; i++) { list[i].d = DRESS[k - 1]; list[i].bit = listB[i]; its.push(list[i]); counts[k]++; }
    }
    this.counts = counts;
    // pack every body and every light into shelf atlases (2048 wide; a new atlas when one fills)
    var bodies = this.pack(its, function (it) { return D.box(it.bit, TB); }), lights = this.pack(its, function (it) { return D.lightBox(it, it.d, T); });
    for (i = 0; i < its.length; i++) {
      var it = its[i], bb = bodies.at[i], e = { it: it, sprite: null, light: null, box: bb, lbox: lights.at[i], offX: it.x - it.cx * T, offY: it.y - it.cy * T, delay: 0, phase: D.hash(i, this.mapId, 5) * 6.283 };
      D.drawItem(bodies.bmp[bb.a].context, it.bit, it.d, TB, bb.x + bb.b.ax, bb.y + bb.b.ay, { lit: true, halo: PX === 1 });
      var sp = new Sprite(bodies.bmp[bb.a]); sp.setFrame(bb.x, bb.y, bb.b.w, bb.b.h); sp.anchor.x = bb.b.ax / bb.b.w; sp.anchor.y = bb.b.ay / bb.b.h; sp.scale.x = sp.scale.y = PX;
      sp.z = it.layer === 'low' ? 1 : it.layer === 'stand' ? 3 : 5; this.tm.addChild(sp); e.sprite = sp;
      if (e.lbox) {
        var lb = e.lbox; D.drawLight(lights.bmp[lb.a].context, it, it.d, T, lb.x + lb.b.ax, lb.y + lb.b.ay);
        var ls = new Sprite(lights.bmp[lb.a]); ls.setFrame(lb.x, lb.y, lb.b.w, lb.b.h); ls.anchor.x = lb.b.ax / lb.b.w; ls.anchor.y = lb.b.ay / lb.b.h; ls.blendMode = 1; this.lightBox.addChild(ls); e.light = ls;
      }
      this.entries.push(e);
    }
    // pixel size 2+: every body pixel is either drawn or not (alpha cut at ALPHA_CUT), read and written once here at build,
    // never during play (wing Probe 27a), and the atlas is sampled nearest-neighbour so a pixel stays a square
    if (PX > 1) for (i = 0; i < bodies.bmp.length; i++) { var bctx = bodies.bmp[i].context, bw = bodies.bmp[i].width, bh = bodies.bmp[i].height, img = bctx.getImageData(0, 0, bw, bh), pd = img.data; for (var q = 3; q < pd.length; q += 4) pd[q] = pd[q] < ALPHA_CUT ? 0 : 255; bctx.putImageData(img, 0, 0); bodies.bmp[i].smooth = false; }
    for (i = 0; i < bodies.bmp.length; i++) bodies.bmp[i].baseTexture.update();
    for (i = 0; i < lights.bmp.length; i++) lights.bmp[i].baseTexture.update();
    // the order things arrive in: nearest the player first
    var px = $gamePlayer.x, py = $gamePlayer.y, far = 1;
    for (i = 0; i < this.entries.length; i++) { var en = this.entries[i], dd = Math.hypot(en.it.cx - px, en.it.cy - py); en.delay = dd; if (dd > far) far = dd; }
    for (i = 0; i < this.entries.length; i++) this.entries[i].delay /= far;
    this.buildAir(counts, T);
  };
  /** shelf-pack boxes; returns { bmp: [Bitmap], at: [{ a, x, y, b } | null] } */
  FeteLayer.prototype.pack = function (its, boxOf) {
    var MAXW = 2048, MAXH = 2048, at = [], bins = [], cur = null, i;
    for (i = 0; i < its.length; i++) {
      var b = boxOf(its[i]); if (!b || b.w < 1 || b.h < 1) { at.push(null); continue; }
      var w = Math.min(MAXW, b.w + 2), h = Math.min(MAXH, b.h + 2);
      if (!cur || (cur.x + w > MAXW && cur.y + cur.row + h > MAXH) || (cur.x + w <= MAXW && cur.y + h > MAXH)) { cur = { x: 0, y: 0, row: 0, w: 0, h: 0, list: [] }; bins.push(cur); }
      if (cur.x + w > MAXW) { cur.x = 0; cur.y += cur.row; cur.row = 0; }
      at.push({ a: bins.length - 1, x: cur.x + 1, y: cur.y + 1, b: b });
      cur.x += w; if (h > cur.row) cur.row = h; if (cur.x > cur.w) cur.w = cur.x; if (cur.y + cur.row > cur.h) cur.h = cur.y + cur.row;
    }
    var bmp = []; for (i = 0; i < bins.length; i++) { var bm = new Bitmap(Math.max(1, bins[i].w), Math.max(1, bins[i].h)); bmp.push(bm); this.bitmaps.push(bm); }
    return { bmp: bmp, at: at };
  };
  /** the air: one dressing's particle (the dressing with the most decorations), N sprites, positions in typed arrays */
  FeteLayer.prototype.buildAir = function (counts, T) {
    var D = deps().D, best = 0, k, n = this.notes.air !== null ? this.notes.air : P.air;
    for (k = 1; k < counts.length; k++) if (counts[k] > counts[best]) best = k;
    if (!best || n <= 0) { this.air = null; return; }
    var dr = D.DRESSINGS[DRESS[best - 1]], cell = 24, bmp = new Bitmap(cell * 4, cell * dr.airColours.length), g = bmp.context, i;
    for (var c = 0; c < dr.airColours.length; c++) for (var f = 0; f < 4; f++) { g.save(); g.translate(f * cell + cell / 2, c * cell + cell / 2); g.scale(T / 48, T / 48); D.drawParticle(g, dr, f, c); g.restore(); }
    bmp.baseTexture.update(); this.bitmaps.push(bmp);
    var host = dr.airGlow ? this.airHigh : this.airLow, a = { kind: dr.air, n: n, sprites: [], x: new Float32Array(n), y: new Float32Array(n), vx: new Float32Array(n), vy: new Float32Array(n), ph: new Float32Array(n), col: new Uint8Array(n), cell: cell };
    var st = { rs: deps().C.mix(this.mapId, 0x41495220) | 0 }, rnd = function () { return deps().C.rand(st); };
    var Wp = Graphics.width + 64, Hp = Graphics.height + 64;
    for (i = 0; i < n; i++) {
      a.x[i] = rnd() * Wp; a.y[i] = rnd() * Hp; a.ph[i] = rnd() * 6.283; a.col[i] = (rnd() * dr.airColours.length) | 0;
      var sp = 0.5 + rnd() * 0.5;
      if (a.kind === 'leaf') { a.vx[i] = 0.25 + 0.35 * sp; a.vy[i] = 0.45 + 0.45 * sp; }
      else if (a.kind === 'petal') { a.vx[i] = 0.35 + 0.3 * sp; a.vy[i] = 0.3 + 0.3 * sp; }
      else if (a.kind === 'skylantern') { a.vx[i] = 0.05 * (rnd() - 0.5); a.vy[i] = -(0.18 + 0.25 * sp); }
      else if (a.kind === 'mote') { a.vx[i] = 0.12 * (rnd() - 0.5); a.vy[i] = -(0.04 + 0.1 * sp); }
      else { a.vx[i] = 0.2 * (rnd() - 0.5); a.vy[i] = 0.2 * (rnd() - 0.5); }
      var s = new Sprite(bmp); s.setFrame(0, a.col[i] * cell, cell, cell); s.anchor.x = 0.5; s.anchor.y = 0.5; if (dr.airGlow) s.blendMode = 1; host.addChild(s); a.sprites.push(s);
    }
    this.air = a;
  };
  FeteLayer.prototype.clearSprites = function () {
    var i;
    for (i = 0; i < this.entries.length; i++) { var e = this.entries[i]; if (e.sprite && e.sprite.parent) e.sprite.parent.removeChild(e.sprite); if (e.light && e.light.parent) e.light.parent.removeChild(e.light); }
    if (this.air) for (i = 0; i < this.air.sprites.length; i++) { var s = this.air.sprites[i]; if (s.parent) s.parent.removeChild(s); }
    for (i = 0; i < this.bitmaps.length; i++) this.bitmaps[i].destroy();
    this.entries = []; this.bitmaps = []; this.air = null; this.solid = null; this.cellD = null;
  };
  FeteLayer.prototype.dispose = function () { this.clearSprites(); if (live === this) live = null; };
  /** how bright the lamps are: 0..1 */
  FeteLayer.prototype.lampStrength = function () {
    var s = store(); if (s.lamps === true) return 1; if (s.lamps === false) return 0;
    if (P.lights === 'always') return 1; if (P.lights === 'never') return 0;
    if (P.lights === 'switch') return P.lightSwitch > 0 && $gameSwitches.value(P.lightSwitch) ? 1 : 0;
    var t = $gameScreen.tone(); return clamp01(-(t[0] + t[1] + t[2]) / 150 + t[3] / 600);
  };
  /** place every sprite for transition progress p (0 = absent, 1 = fully up) in mode m: zero allocation */
  FeteLayer.prototype.apply = function (p, m) {
    var tw = $gameMap.tileWidth(), th = $gameMap.tileHeight(), lamp = this.lampStrength(), f = this.frame, sway = P.sway, gw = Graphics.width, gh = Graphics.height, i;
    this.progress = p;
    for (i = 0; i < this.entries.length; i++) {
      var e = this.entries[i], it = e.it, s = e.sprite, b = e.box.b;
      var sx = Math.round($gameMap.adjustX(it.cx) * tw + e.offX), sy = Math.round($gameMap.adjustY(it.cy) * th + e.offY);
      s.x = sx; s.y = sy;
      var pxs = this.px || 1, on = sx + b.w * pxs > -64 && sx - b.w * pxs < gw + 64 && sy + b.h * pxs > -64 && sy - b.h * pxs < gh + 64;
      var q = m === 'unspool' ? clamp01((p - 0.65 * e.delay) / 0.35) : p;
      s.visible = on && q > 0;
      if (m === 'unspool' && q < 1) {
        // a partial frame keeps the item's anchor where it was: PIXI's anchor is a FRACTION of the frame, so it is re-derived
        if (it.k === 'span') { var fw = Math.max(1, Math.round(b.w * q)); s.setFrame(e.box.x, e.box.y, fw, b.h); s.anchor.x = b.ax / fw; s.scale.y = pxs; s.alpha = 1; }
        else if (it.k === 'banner') { var fh = Math.max(1, Math.round(b.h * q)); s.setFrame(e.box.x, e.box.y, b.w, fh); s.anchor.y = b.ay / fh; s.alpha = 1; }
        else { var eb = easeOutBack(q); s.scale.y = eb * pxs; s.scale.x = (0.7 + 0.3 * q) * pxs; s.alpha = clamp01(q * 3); }
      } else if (e.wasPartial || s.alpha !== 1 || s.scale.y !== pxs) {
        s.setFrame(e.box.x, e.box.y, b.w, b.h); s.anchor.x = b.ax / b.w; s.anchor.y = b.ay / b.h; s.scale.x = pxs; s.scale.y = pxs; s.alpha = m === 'fade' ? q : 1;
      }
      e.wasPartial = m === 'unspool' && q < 1;
      if (m === 'fade') s.alpha = q;
      if (sway && (it.k === 'span' || it.k === 'banner')) s.skew.x = (it.k === 'span' ? 0.03 : 0.02) * Math.sin(f * 0.025 + e.phase);
      if (e.light) {
        var L = e.light; L.x = sx; L.y = sy;
        var fl = it.k === 'centre' && it.d === 'hallows' ? 0.72 + 0.28 * Math.sin(f * 0.21 + e.phase) * Math.sin(f * 0.13) : 0.86 + 0.14 * Math.sin(f * 0.09 + e.phase);
        L.alpha = lamp * q * fl; L.visible = on && L.alpha > 0.01;
      }
    }
    if (this.air) this.updateAir(p, gw, gh);
  };
  FeteLayer.prototype.updateAir = function (p, gw, gh) {
    var a = this.air, tw = $gameMap.tileWidth(), th = $gameMap.tileHeight(), ox = $gameMap.displayX() * tw, oy = $gameMap.displayY() * th, f = this.frame, Wp = gw + 64, Hp = gh + 64, i;
    for (i = 0; i < a.n; i++) {
      var ph = a.ph[i];
      a.x[i] += a.vx[i] + (a.kind === 'leaf' || a.kind === 'petal' ? 0.35 * Math.sin(f * 0.03 + ph) : a.kind === 'wisp' ? 0.25 * Math.sin(f * 0.02 + ph) : 0);
      a.y[i] += a.vy[i] + (a.kind === 'wisp' ? 0.2 * Math.cos(f * 0.017 + ph) : 0);
      var s = a.sprites[i];
      s.x = posMod(a.x[i] - ox, Wp) - 32; s.y = posMod(a.y[i] - oy, Hp) - 32;
      var fr = ((f / (a.kind === 'leaf' || a.kind === 'petal' ? 8 : 14) + ph) | 0) & 3;
      if (fr !== s._feteFr) { s._feteFr = fr; s.setFrame(fr * a.cell, a.col[i] * a.cell, a.cell, a.cell); }
      s.alpha = p * (a.kind === 'mote' || a.kind === 'wisp' ? 0.55 + 0.45 * Math.sin(f * 0.05 + ph) : 1);
    }
  };
  FeteLayer.prototype.update = function () {
    this.frame++;
    this.check(false);
    if (this.phase === 'idle') { this.apply(1, 'none'); return; }
    this.t++;
    var p = clamp01(this.t / this.dur);
    if (this.phase === 'in') { this.apply(p, this.mode); if (p >= 1) { this.phase = 'idle'; this.apply(1, 'none'); } return; }
    // out
    this.apply(1 - p, this.mode);
    if (p >= 1) {
      var nx = this.next; this.next = null;
      this.build(nx.res, nx.sig);
      if (!this.entries.length && !this.air) { this.phase = 'idle'; return; }
      this.phase = 'in'; this.mode = nx.mode; this.dur = Math.max(1, Math.round(nx.dur / 2)); this.t = 0; this.apply(0, this.mode);
    }
  };
  FeteLayer.prototype.solidAt = function (x, y) { return !!(this.solid && x >= 0 && y >= 0 && x < this.W && y < this.H && this.solid[y * this.W + x]); };
  FeteLayer.prototype.stateAt = function (x, y) { if (!this.cellD || x < 0 || y < 0 || x >= this.W || y >= this.H) return null; var v = this.cellD[y * this.W + x]; return v ? DRESS[v - 1] : null; };

  // ── engine hooks (prototype extension, originals saved and called) ─────────────────────────────────────────────────
  var _Spriteset_Map_createLowerLayer = Spriteset_Map.prototype.createLowerLayer;
  Spriteset_Map.prototype.createLowerLayer = function () {
    _Spriteset_Map_createLowerLayer.call(this);
    this._feteLayer = new FeteLayer(this);
  };
  var _Spriteset_Map_update = Spriteset_Map.prototype.update;
  Spriteset_Map.prototype.update = function () {
    _Spriteset_Map_update.call(this);
    if (this._feteLayer) this._feteLayer.update();
  };
  var _Game_CharacterBase_isMapPassable = Game_CharacterBase.prototype.isMapPassable;
  Game_CharacterBase.prototype.isMapPassable = function (x, y, d) {
    if (!_Game_CharacterBase_isMapPassable.call(this, x, y, d)) return false;
    if (!live || live.mapId !== $gameMap.mapId()) return true;
    return !live.solidAt($gameMap.roundXWithDirection(x, d), $gameMap.roundYWithDirection(y, d));
  };
  var _Game_Interpreter_updateWaitMode = Game_Interpreter.prototype.updateWaitMode;
  Game_Interpreter.prototype.updateWaitMode = function () {
    if (this._waitMode === 'fete') { if (live && live.phase !== 'idle') return true; this._waitMode = ''; return false; }
    return _Game_Interpreter_updateWaitMode.call(this);
  };

  function cmdOpts(a) { return { regionId: a.regionId, x: a.x, y: a.y, width: a.width, height: a.height, mapId: a.mapId, transition: a.transition, duration: a.duration }; }
  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
    PluginManager.registerCommand(NAME, 'set', function (a) { var o = cmdOpts(a); set(pick(a.target, ['map', 'region', 'rect'], 'map'), a.dressing, o); if (bool(a.wait, false) && targetMap(o) === $gameMap.mapId()) this.setWaitMode('fete'); });
    PluginManager.registerCommand(NAME, 'clear', function (a) { var o = cmdOpts(a); clear(pick(a.target, ['map', 'region', 'rect', 'all'], 'all'), o); if (bool(a.wait, false) && targetMap(o) === $gameMap.mapId()) this.setWaitMode('fete'); });
    PluginManager.registerCommand(NAME, 'release', function (a) { release({ mapId: a.mapId, transition: a.transition }); });
    PluginManager.registerCommand(NAME, 'lamps', function (a) { lamps(pick(a.mode, ['on', 'off', 'auto'], 'auto')); });
  }

  return {
    VERSION: '1.0.0', DRESSINGS: DRESS, params: P,
    set: set, clear: clear, release: release, lamps: lamps, readNotes: readNotes, resolve: function (mapId) { return resolve(mapId || $gameMap.mapId(), live && live.mapId === (mapId || $gameMap.mapId()) ? live.notes : readNotes($dataMap.note)); },
    isBusy: function () { return !!(live && live.phase !== 'idle'); },
    stateAt: function (x, y) { return live ? live.stateAt(x, y) : null; },
    solidAt: function (x, y) { return live ? live.solidAt(x, y) : false; },
    get _layer() { return live; }
  };
})();
