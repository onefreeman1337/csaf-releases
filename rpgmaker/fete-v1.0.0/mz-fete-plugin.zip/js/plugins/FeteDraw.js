/*:
 * @target MZ
 * @plugindesc [v1.0.0] Fete 2/3 - the look: five festival dressings drawn in code (strings, lamps, banners, stalls, centrepieces, air). No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * FeteDraw.js draws every decoration Fete places, into a canvas: no image file and no font. Five dressings: Harvest Fair,
 * Lantern Night, Spring Blossom, Midwinter and All Hallows. Turn it on together with FeteCore.js and Fete.js; the order
 * does not matter. See Readme_for_Users.md.
 */
/* FeteDraw - canvas drawing only; runs in a browser page (the engine, or a headless preview). Every drawing is authored at
 * a 48 px tile and scaled to the map's tile size. Copyright (c) 2026 Core Systems Asset Factory. */
var FeteDraw = (function () {
  'use strict';
  function rgb(c, a) { return a === undefined ? 'rgb(' + (c[0] | 0) + ',' + (c[1] | 0) + ',' + (c[2] | 0) + ')' : 'rgba(' + (c[0] | 0) + ',' + (c[1] | 0) + ',' + (c[2] | 0) + ',' + a + ')'; }
  function mix(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }
  function hash(a, b, c) { var h = (Math.imul(a | 0, 374761393) + Math.imul(b | 0, 668265263) + Math.imul(c | 0, 2246822519)) >>> 0; h = Math.imul(h ^ (h >>> 13), 1274126177) >>> 0; return ((h ^ (h >>> 16)) >>> 0) / 4294967296; }
  /** inline halos in the body drawings: off for a pixel-snapped body, whose glow comes from the light layer alone */
  var HALO = true;
  var BLACK = [0, 0, 0], WHITE = [255, 255, 255], WOOD = [58, 40, 28], WOOD_LIT = [92, 66, 44], CREAM = [240, 228, 196];

  /**
   * The five dressings. pennants: string colours in order; cut: the pennant shape; eave / cross / post: the string style
   * on house fronts, across lanes, and between posts; lamp: what hangs from a post; banner + emblem: what hangs on a free
   * wall; centre: the square's centrepiece; goods: what the stalls sell; air: the particle that drifts over the town
   * (glow = drawn above the screen tint, so it still shines at night).
   */
  var DRESSINGS = {
    harvest: { id: 'harvest', name: 'Harvest Fair', pennants: [[214, 120, 40], [168, 40, 34], [236, 212, 140], [120, 132, 52]], string: [92, 64, 38], cut: 'triangle', eave: 'pennant', cross: 'pennant', post: 'festoon', lamp: 'paper', glow: [255, 176, 90], cloth: [[168, 40, 34], [214, 120, 40]], banner: 'pennon', emblem: 'sheaf', centre: 'maypole', goods: ['pumpkins', 'apples', 'loaves'], air: 'leaf', airColours: [[214, 120, 40], [184, 64, 30], [228, 178, 64], [150, 104, 40]], airGlow: false },
    lantern: { id: 'lantern', name: 'Lantern Night', pennants: [[204, 38, 36], [236, 172, 54], [204, 38, 36], [232, 122, 52]], string: [40, 30, 30], cut: 'round', eave: 'lanterns', cross: 'lanterns', post: 'lanterns', lamp: 'tall', glow: [255, 132, 70], cloth: [[172, 28, 32], [234, 178, 66]], banner: 'scroll', emblem: 'moon', centre: 'gate', goods: ['lanterns', 'sweets', 'fans'], air: 'skylantern', airColours: [[255, 170, 90], [255, 128, 70], [255, 200, 120]], airGlow: true },
    blossom: { id: 'blossom', name: 'Spring Blossom', pennants: [[240, 160, 184], [250, 238, 206], [164, 206, 146], [196, 168, 228]], string: [116, 92, 66], cut: 'swallow', eave: 'flowers', cross: 'pennant', post: 'flowers', lamp: 'basket', glow: [255, 214, 170], cloth: [[222, 112, 146], [250, 238, 206]], banner: 'ring', emblem: 'blossom', centre: 'arch', goods: ['flowers', 'pots', 'honey'], air: 'petal', airColours: [[248, 186, 204], [255, 228, 234], [236, 150, 180]], airGlow: false },
    midwinter: { id: 'midwinter', name: 'Midwinter', pennants: [[156, 30, 38], [36, 96, 62], [222, 182, 92], [156, 30, 38]], string: [46, 38, 30], cut: 'triangle', eave: 'evergreen', cross: 'festoon', post: 'evergreen', lamp: 'star', glow: [255, 208, 124], cloth: [[134, 24, 32], [30, 86, 54]], banner: 'wreath', emblem: 'holly', centre: 'tree', goods: ['gifts', 'candles', 'bread'], air: 'mote', airColours: [[255, 222, 150], [255, 196, 120], [255, 240, 200]], airGlow: true },
    // (v1.0: the near-black pennant and the dark purple cloth vanished on a night wall, independent review 2026-10-18; the
    // palette is now orange, violet and lime, the cloth a lighter violet)
    hallows: { id: 'hallows', name: 'All Hallows', pennants: [[232, 112, 30], [132, 70, 170], [150, 196, 60], [232, 112, 30]], string: [30, 24, 30], cut: 'tatter', eave: 'pennant', cross: 'pennant', post: 'lanterns', lamp: 'jack', glow: [255, 150, 42], cloth: [[104, 58, 132], [232, 112, 30]], banner: 'tatter', emblem: 'bat', centre: 'bonfire', goods: ['pumpkins', 'candy', 'apples'], air: 'wisp', airColours: [[170, 255, 170], [200, 160, 255], [255, 190, 110]], airGlow: true }
  };
  var ORDER = ['harvest', 'lantern', 'blossom', 'midwinter', 'hallows'];

  /** a point on a hanging string from (x0, y0) to (x1, y1) with a sag (a fraction of the span), t in 0..1: a parabola,
   *  which reads as a catenary at these spans */
  function stringPoint(x0, y0, x1, y1, sag, t, out) { var span = Math.abs(x1 - x0) + Math.abs(y1 - y0); out.x = x0 + (x1 - x0) * t; out.y = y0 + (y1 - y0) * t + 4 * sag * span * t * (1 - t); return out; }
  function strokeString(g, col, w, x0, y0, x1, y1, sag) { var p = { x: 0, y: 0 }; g.lineWidth = w; g.strokeStyle = rgb(col); g.beginPath(); for (var i = 0; i <= 24; i++) { stringPoint(x0, y0, x1, y1, sag, i / 24, p); if (i) g.lineTo(p.x, p.y); else g.moveTo(p.x, p.y); } g.stroke(); }

  /** a five-petal bloom of radius r at (x, y) */
  function bloom(g, x, y, r, col, eye) {
    g.fillStyle = rgb(col); for (var k = 0; k < 5; k++) { var a = k / 5 * Math.PI * 2 - Math.PI / 2; g.beginPath(); g.ellipse(x + Math.cos(a) * r * 0.55, y + Math.sin(a) * r * 0.55, r * 0.52, r * 0.38, a, 0, Math.PI * 2); g.fill(); }
    g.fillStyle = rgb(eye || [250, 210, 90]); g.beginPath(); g.arc(x, y, r * 0.28, 0, Math.PI * 2); g.fill();
  }
  function leaf(g, x, y, rx, ry, a, col) { g.fillStyle = rgb(col); g.beginPath(); g.ellipse(x, y, rx, ry, a, 0, Math.PI * 2); g.fill(); }

  // ── strings ─────────────────────────────────────────────────────────────────────────────────────────────────────────
  /** bunting: the string, then pennants hung at a pitch along it, colours cycling, each nudged by a seeded sway */
  function drawBunting(g, D, x0, y0, x1, y1, sag, seed, sway) {
    var p = { x: 0, y: 0 }, q = { x: 0, y: 0 }, span = Math.hypot(x1 - x0, y1 - y0), n = Math.max(3, Math.round(span / 17)), i;
    g.save(); strokeString(g, D.string, 1.6, x0, y0, x1, y1, sag);
    for (i = 1; i < n; i++) {
      var t = i / n; stringPoint(x0, y0, x1, y1, sag, t, p); stringPoint(x0, y0, x1, y1, sag, t + 0.5 / n, q);
      var col = D.pennants[(i + seed) % D.pennants.length], ang = Math.atan2(q.y - p.y, q.x - p.x), w = 11, h = 16, sw = (sway || 0) * Math.sin(i * 1.7 + seed);
      if (Math.abs(ang) > 1.0) ang = ang > 0 ? 1.0 : -1.0;   // a steep string still hangs its flags downward
      g.save(); g.translate(p.x, p.y); g.rotate(ang); g.transform(1, 0, sw * 0.15, 1, 0, 0);
      g.beginPath();
      if (D.cut === 'round') { g.moveTo(-w / 2, 0); g.lineTo(w / 2, 0); g.lineTo(w / 2, h * 0.55); g.arc(0, h * 0.55, w / 2, 0, Math.PI); g.closePath(); }
      else if (D.cut === 'swallow') { g.moveTo(-w / 2, 0); g.lineTo(w / 2, 0); g.lineTo(w / 2, h); g.lineTo(0, h * 0.62); g.lineTo(-w / 2, h); g.closePath(); }
      else if (D.cut === 'tatter') { var r1 = hash(i, seed, 1), r2 = hash(i, seed, 2); g.moveTo(-w / 2, 0); g.lineTo(w / 2, 0); g.lineTo(w / 2 - 1, h * (0.75 + r1 * 0.2)); g.lineTo(w * 0.15, h * (0.55 + r2 * 0.2)); g.lineTo(-w * 0.1, h * (0.92 + r2 * 0.08)); g.lineTo(-w * 0.3, h * (0.6 + r1 * 0.15)); g.lineTo(-w / 2, h * 0.8); g.closePath(); }
      else { g.moveTo(-w / 2, 0); g.lineTo(w / 2, 0); g.lineTo(0, h); g.closePath(); }
      g.fillStyle = rgb(col); g.fill(); g.lineWidth = 1; g.strokeStyle = rgb(mix(col, BLACK, 0.45)); g.stroke();
      g.fillStyle = rgb(mix(col, WHITE, 0.35), 0.8); g.fillRect(-w / 2 + 1, 0.5, w - 2, 1.4);   // a lit top edge
      g.restore();
    }
    g.restore();
  }

  /** a festoon of small bulbs on a string between two post tops */
  function drawFestoon(g, D, x0, y0, x1, y1, sag, lit) {
    var p = { x: 0, y: 0 }, span = Math.hypot(x1 - x0, y1 - y0), n = Math.max(3, Math.round(span / 13)), i;
    g.save(); strokeString(g, [40, 30, 24], 1.2, x0, y0, x1, y1, sag);
    for (i = 1; i < n; i++) { stringPoint(x0, y0, x1, y1, sag, i / n, p); var col = D.pennants[i % D.pennants.length];
      if (lit && HALO) { g.fillStyle = rgb(mix(col, [255, 240, 200], 0.4), 0.35); g.beginPath(); g.arc(p.x, p.y + 4, 6, 0, Math.PI * 2); g.fill(); }
      g.fillStyle = rgb(mix(col, [255, 255, 230], lit ? 0.45 : 0.1)); g.beginPath(); g.ellipse(p.x, p.y + 4, 2.6, 3.4, 0, 0, Math.PI * 2); g.fill(); g.fillStyle = rgb([40, 30, 24]); g.fillRect(p.x - 1, p.y, 2, 1.6); }
    g.restore();
  }

  /** a string of small paper lanterns (Lantern Night) or small jack-o'-lanterns (All Hallows) */
  function drawLanternString(g, D, x0, y0, x1, y1, sag, lit) {
    var p = { x: 0, y: 0 }, span = Math.hypot(x1 - x0, y1 - y0), n = Math.max(2, Math.round(span / 22)), i;
    g.save(); strokeString(g, D.string, 1.3, x0, y0, x1, y1, sag);
    for (i = 1; i < n; i++) {
      stringPoint(x0, y0, x1, y1, sag, i / n, p); var cx = p.x, cy = p.y + 9;
      g.strokeStyle = rgb(D.string); g.lineWidth = 0.9; g.beginPath(); g.moveTo(p.x, p.y); g.lineTo(cx, cy - 6); g.stroke();
      if (lit && HALO) { g.fillStyle = rgb(D.glow, 0.28); g.beginPath(); g.arc(cx, cy, 10, 0, Math.PI * 2); g.fill(); }
      if (D.lamp === 'jack') {
        g.fillStyle = rgb([226, 112, 30]); g.beginPath(); g.ellipse(cx, cy, 6.2, 5, 0, 0, Math.PI * 2); g.fill();
        g.strokeStyle = rgb([150, 64, 20]); g.lineWidth = 0.8; g.beginPath(); g.ellipse(cx, cy, 2.4, 5, 0, 0, Math.PI * 2); g.stroke();
        g.fillStyle = rgb(lit ? [255, 236, 120] : [70, 30, 10]); g.beginPath(); g.moveTo(cx - 3.6, cy - 1.4); g.lineTo(cx - 1.4, cy - 1.4); g.lineTo(cx - 2.5, cy - 3.2); g.closePath(); g.fill(); g.beginPath(); g.moveTo(cx + 3.6, cy - 1.4); g.lineTo(cx + 1.4, cy - 1.4); g.lineTo(cx + 2.5, cy - 3.2); g.closePath(); g.fill();
        g.fillRect(cx - 3, cy + 1.2, 6, 1.3); g.fillStyle = rgb([70, 90, 30]); g.fillRect(cx - 0.7, cy - 7, 1.4, 2.2);
      } else {
        var col = D.pennants[i % D.pennants.length], body = g.createLinearGradient(cx - 6, 0, cx + 6, 0);
        body.addColorStop(0, rgb(mix(col, BLACK, 0.35))); body.addColorStop(0.5, rgb(mix(col, [255, 236, 190], lit ? 0.5 : 0.08))); body.addColorStop(1, rgb(mix(col, BLACK, 0.35)));
        g.fillStyle = body; g.beginPath(); g.ellipse(cx, cy, 5.6, 6.8, 0, 0, Math.PI * 2); g.fill();
        g.strokeStyle = rgb(mix(col, BLACK, 0.5), 0.7); g.lineWidth = 0.7; g.beginPath(); g.ellipse(cx, cy, 2.6, 6.8, 0, 0, Math.PI * 2); g.stroke();
        g.fillStyle = rgb([40, 26, 20]); g.fillRect(cx - 3, cy - 7.5, 6, 1.8); g.fillRect(cx - 3, cy + 6, 6, 1.6); g.fillStyle = rgb([236, 178, 66]); g.fillRect(cx - 0.5, cy + 7.6, 1, 3.4);
      }
    }
    g.restore();
  }

  /** a rope of greenery: evergreen (Midwinter: dark needles, red bows, gold bulbs) or flowers (Spring: leaves and blooms) */
  function drawGarland(g, D, x0, y0, x1, y1, sag, seed, lit) {
    var p = { x: 0, y: 0 }, span = Math.hypot(x1 - x0, y1 - y0), steps = Math.max(8, Math.round(span / 3)), i, ever = D.eave === 'evergreen' || D.post === 'evergreen' && D.eave !== 'flowers';
    g.save();
    // the rope: three leaves a step, dark under-leaves first so the rope has a lit top (v0.2b: LOOKED AT 2026-10-18, one
    // leaf a step read as a thread at 48 px)
    for (var pass = 0; pass < 2; pass++) for (i = 0; i <= steps; i++) {
      stringPoint(x0, y0, x1, y1, sag, i / steps, p); var r = hash(i, seed, 7 + pass), a = r * Math.PI * 2;
      if (ever) { var dk = pass ? [44, 106, 64] : [18, 54, 34]; leaf(g, p.x + Math.cos(a) * 2.6, p.y + Math.sin(a) * 2 + (pass ? -0.8 : 1.2), 5, 2, a, dk); leaf(g, p.x - Math.cos(a) * 2.6, p.y + (pass ? -0.4 : 1.6), 4.4, 1.8, -a, pass ? [60, 124, 76] : [26, 70, 44]); }
      else { var lc = pass ? [104, 162, 74] : [58, 108, 48]; leaf(g, p.x + Math.cos(a) * 2.6, p.y + Math.sin(a) * 2 + (pass ? -0.8 : 1.2), 4.4, 2, a, lc); leaf(g, p.x - Math.cos(a) * 2.4, p.y + (pass ? -0.4 : 1.4), 3.8, 1.8, -a, lc); }
    }
    var n = Math.max(2, Math.round(span / (ever ? 14 : 9)));
    for (i = 1; i < n; i++) {
      stringPoint(x0, y0, x1, y1, sag, i / n, p);
      if (ever) {
        var bc = i % 2 ? [236, 188, 80] : [196, 40, 44];
        if (lit && HALO) { g.fillStyle = rgb(D.glow, 0.32); g.beginPath(); g.arc(p.x, p.y + 2, 6, 0, Math.PI * 2); g.fill(); }
        g.fillStyle = rgb(mix(bc, WHITE, lit ? 0.3 : 0)); g.beginPath(); g.arc(p.x, p.y + 2, 2.8, 0, Math.PI * 2); g.fill(); g.fillStyle = rgb(WHITE, 0.55); g.fillRect(p.x - 1.4, p.y + 0.6, 1.1, 1.1);
      } else {
        bloom(g, p.x, p.y + 0.5, 5.6, D.pennants[i % D.pennants.length], i % 3 ? null : [240, 150, 60]);
        // a hanging drop of blooms every third flower
        if (i % 3 === 1) { g.strokeStyle = rgb([70, 124, 56]); g.lineWidth = 1; g.beginPath(); g.moveTo(p.x, p.y + 3); g.lineTo(p.x, p.y + 11); g.stroke(); bloom(g, p.x, p.y + 12, 3.8, D.pennants[(i + 1) % D.pennants.length]); leaf(g, p.x - 3, p.y + 8, 2.6, 1.2, -0.6, [104, 162, 74]); }
      }
    }
    if (ever) for (var e = 0; e < 2; e++) { var bx = e ? x1 : x0, by = e ? y1 : y0; g.fillStyle = rgb([176, 30, 38]); g.beginPath(); g.ellipse(bx - 4, by, 4, 2.6, -0.4, 0, Math.PI * 2); g.fill(); g.beginPath(); g.ellipse(bx + 4, by, 4, 2.6, 0.4, 0, Math.PI * 2); g.fill(); g.fillRect(bx - 1.5, by - 1.5, 3, 3); g.fillRect(bx - 3, by + 1, 2, 7); g.fillRect(bx + 1, by + 1, 2, 6); }
    g.restore();
  }

  function drawString(g, D, style, x0, y0, x1, y1, sag, seed, opts) {
    var lit = !opts || opts.lit !== false;
    if (style === 'pennant') drawBunting(g, D, x0, y0, x1, y1, sag, seed, opts && opts.sway);
    else if (style === 'festoon') drawFestoon(g, D, x0, y0, x1, y1, sag, lit);
    else if (style === 'lanterns') drawLanternString(g, D, x0, y0, x1, y1, sag, lit);
    else drawGarland(g, D, x0, y0, x1, y1, sag, seed, lit);
  }

  // ── posts and lamps ─────────────────────────────────────────────────────────────────────────────────────────────────
  /** the height of a lamp post's crossbar above its foot: post and cross strings hang from it */
  var POST_H = 54;
  /** where the lamp's light sits relative to the post's foot (the glow sprite's place) */
  var LAMP_AT = { x: 9, y: -POST_H + 15 };
  /** a lamp post whose foot is (0, 0): a dark post with a crossbar and the dressing's lamp hanging from it */
  function drawPost(g, D, lit) {
    var top = -POST_H, lx = LAMP_AT.x, ly = LAMP_AT.y;
    g.fillStyle = rgb([28, 20, 14], 0.35); g.beginPath(); g.ellipse(0, -1, 8, 2.5, 0, 0, Math.PI * 2); g.fill();
    g.fillStyle = rgb(WOOD); g.fillRect(-2, top, 4, POST_H); g.fillRect(-6, -4, 12, 4); g.fillRect(-2, top, 14, 3);
    g.fillStyle = rgb(WOOD_LIT); g.fillRect(-1, top + 1, 1.5, POST_H - 6);
    if (D.post === 'evergreen' || D.post === 'flowers') { for (var s = 0; s < 6; s++) leaf(g, (s % 2 ? 2.5 : -2.5), top + 8 + s * 6, 3.4, 1.5, s % 2 ? 0.6 : -0.6, D.post === 'evergreen' ? [34, 86, 52] : [92, 146, 66]); if (D.post === 'evergreen') { g.fillStyle = rgb([180, 30, 40]); g.fillRect(-3, top + 30, 6, 3); } else bloom(g, 0, top + 22, 3.6, D.pennants[0]); }
    g.strokeStyle = rgb([40, 28, 20]); g.lineWidth = 1; g.beginPath(); g.moveTo(lx, top + 3); g.lineTo(lx, ly - 9); g.stroke();
    drawLamp(g, D, lx, ly, lit);
  }
  /** the dressing's lamp centred at (x, y) */
  function drawLamp(g, D, x, y, lit) {
    var gc = D.glow;
    if (lit && HALO) { var gl = g.createRadialGradient(x, y, 2, x, y, 22); gl.addColorStop(0, rgb(gc, 0.45)); gl.addColorStop(1, rgb(gc, 0)); g.fillStyle = gl; g.beginPath(); g.arc(x, y, 22, 0, Math.PI * 2); g.fill(); }
    var bright = lit ? 0.55 : 0.1;
    if (D.lamp === 'tall') {
      var body = g.createLinearGradient(x - 6, 0, x + 6, 0); body.addColorStop(0, rgb([120, 16, 20])); body.addColorStop(0.5, rgb(mix([210, 40, 36], [255, 220, 170], bright))); body.addColorStop(1, rgb([120, 16, 20]));
      g.fillStyle = body; g.beginPath(); g.moveTo(x - 5, y - 9); g.quadraticCurveTo(x - 8, y, x - 5, y + 9); g.lineTo(x + 5, y + 9); g.quadraticCurveTo(x + 8, y, x + 5, y - 9); g.closePath(); g.fill();
      g.strokeStyle = rgb([90, 14, 16], 0.7); g.lineWidth = 0.8; for (var k = -1; k <= 1; k++) { g.beginPath(); g.moveTo(x - 6.6, y + k * 4.5); g.lineTo(x + 6.6, y + k * 4.5); g.stroke(); }
      g.fillStyle = rgb([228, 172, 60]); g.fillRect(x - 5, y - 11, 10, 2.5); g.fillRect(x - 5, y + 8.5, 10, 2.2); g.fillRect(x - 1, y + 10.5, 2, 5); g.fillRect(x - 2, y + 15, 4, 1.5);
    } else if (D.lamp === 'basket') {
      g.save(); g.translate(x, y); g.scale(1.35, 1.35); g.translate(-x, -y);   // v0.2b: the first basket read as a speck
      g.strokeStyle = rgb([90, 66, 40]); g.lineWidth = 0.9; g.beginPath(); g.moveTo(x, y - 9); g.lineTo(x - 7, y - 1); g.moveTo(x, y - 9); g.lineTo(x + 7, y - 1); g.stroke();
      g.fillStyle = rgb([142, 104, 62]); g.beginPath(); g.moveTo(x - 8, y - 1); g.lineTo(x + 8, y - 1); g.quadraticCurveTo(x + 7, y + 7, x, y + 7); g.quadraticCurveTo(x - 7, y + 7, x - 8, y - 1); g.fill();
      g.strokeStyle = rgb([104, 74, 42]); g.lineWidth = 0.7; for (var w = -6; w <= 6; w += 3) { g.beginPath(); g.moveTo(x + w, y - 1); g.lineTo(x + w * 0.8, y + 6); g.stroke(); }
      for (var f = 0; f < 5; f++) bloom(g, x - 7 + f * 3.5, y - 2 - (f % 2) * 2.5, 2.6, D.pennants[f % D.pennants.length]);
      leaf(g, x - 7, y + 5, 1.4, 4, 0.3, [92, 146, 66]); leaf(g, x + 6, y + 6, 1.4, 4.5, -0.3, [92, 146, 66]);
      if (lit) { g.fillStyle = rgb([255, 240, 200], 0.9); g.beginPath(); g.arc(x, y + 1, 1.6, 0, Math.PI * 2); g.fill(); }
      g.restore();
    } else if (D.lamp === 'star') {
      g.save(); g.translate(x, y);
      for (var r = 0; r < 2; r++) { g.save(); g.rotate(r * Math.PI / 4); g.fillStyle = rgb(mix([196, 150, 64], [255, 236, 170], bright)); g.fillRect(-6, -6, 12, 12); g.strokeStyle = rgb([120, 84, 30]); g.lineWidth = 0.8; g.strokeRect(-6, -6, 12, 12); g.restore(); }
      g.fillStyle = rgb(lit ? [255, 250, 220] : [150, 110, 50]); for (var h = 0; h < 8; h++) { var ha = h / 8 * Math.PI * 2; g.fillRect(Math.cos(ha) * 4.2 - 0.7, Math.sin(ha) * 4.2 - 0.7, 1.4, 1.4); }
      g.beginPath(); g.arc(0, 0, 1.8, 0, Math.PI * 2); g.fill(); g.restore();
    } else if (D.lamp === 'jack') {
      g.fillStyle = rgb([224, 110, 30]); g.beginPath(); g.ellipse(x, y + 1, 8.5, 7, 0, 0, Math.PI * 2); g.fill();
      g.strokeStyle = rgb([150, 62, 20]); g.lineWidth = 0.9; g.beginPath(); g.ellipse(x, y + 1, 3.4, 7, 0, 0, Math.PI * 2); g.stroke(); g.beginPath(); g.ellipse(x, y + 1, 6.4, 7, 0, 0, Math.PI * 2); g.stroke();
      g.fillStyle = rgb([80, 96, 34]); g.fillRect(x - 1, y - 8, 2, 3);
      g.fillStyle = rgb(lit ? [255, 236, 110] : [70, 30, 10]);
      g.beginPath(); g.moveTo(x - 5.5, y - 0.5); g.lineTo(x - 1.5, y - 0.5); g.lineTo(x - 3.5, y - 3.8); g.closePath(); g.fill();
      g.beginPath(); g.moveTo(x + 5.5, y - 0.5); g.lineTo(x + 1.5, y - 0.5); g.lineTo(x + 3.5, y - 3.8); g.closePath(); g.fill();
      g.beginPath(); g.moveTo(x - 5, y + 2.5); g.lineTo(x + 5, y + 2.5); g.lineTo(x + 3.5, y + 5); g.lineTo(x + 1.5, y + 3.6); g.lineTo(x, y + 5.2); g.lineTo(x - 1.5, y + 3.6); g.lineTo(x - 3.5, y + 5); g.closePath(); g.fill();
    } else {
      var lb = g.createLinearGradient(x - 8, 0, x + 8, 0); lb.addColorStop(0, rgb(mix(gc, [120, 40, 20], 0.5))); lb.addColorStop(0.5, rgb(mix(gc, [255, 240, 200], bright))); lb.addColorStop(1, rgb(mix(gc, [120, 40, 20], 0.5)));
      g.fillStyle = lb; g.beginPath(); g.ellipse(x, y, 7.5, 10, 0, 0, Math.PI * 2); g.fill();
      g.strokeStyle = rgb([90, 40, 24], 0.7); g.lineWidth = 0.9; for (var m = -1; m <= 1; m++) { g.beginPath(); g.ellipse(x, y + m * 4.5, 7.5 * Math.sqrt(1 - (m * 4.5 / 10) * (m * 4.5 / 10)), 1.2, 0, 0, Math.PI * 2); g.stroke(); }
      g.fillStyle = rgb(WOOD); g.fillRect(x - 4, y - 11, 8, 2.5); g.fillRect(x - 4, y + 9, 8, 2); g.fillRect(x - 0.5, y + 11, 1, 4);
    }
  }

  // ── banners on walls ────────────────────────────────────────────────────────────────────────────────────────────────
  /** the dressing's emblem centred at (x, y), drawn in colour c */
  function drawEmblem(g, D, x, y, c, ground) {
    g.fillStyle = rgb(c); g.strokeStyle = rgb(c); g.lineWidth = 1.4;
    if (D.emblem === 'sheaf') { for (var k = -2; k <= 2; k++) { g.beginPath(); g.moveTo(x, y + 7); g.lineTo(x + k * 2.4, y - 5); g.stroke(); g.beginPath(); g.ellipse(x + k * 2.6, y - 6, 1.3, 2.6, k * 0.25, 0, Math.PI * 2); g.fill(); } g.fillRect(x - 3, y + 1, 6, 1.6); }
    else if (D.emblem === 'moon') { g.beginPath(); g.arc(x, y, 6, 0, Math.PI * 2); g.fill(); g.fillStyle = rgb(ground); g.beginPath(); g.arc(x + 2.5, y - 1.5, 5, 0, Math.PI * 2); g.fill(); }
    else if (D.emblem === 'blossom') bloom(g, x, y, 6.5, c, [250, 210, 90]);
    else if (D.emblem === 'holly') { leaf(g, x - 3.5, y + 1, 5, 2.2, -0.5, [40, 110, 64]); leaf(g, x + 3.5, y + 1, 5, 2.2, 0.5, [40, 110, 64]); g.fillStyle = rgb([210, 36, 40]); for (var b = 0; b < 3; b++) { g.beginPath(); g.arc(x - 1.6 + b * 1.6, y - 1 + (b % 2) * 1.6, 1.5, 0, Math.PI * 2); g.fill(); } }
    else if (D.emblem === 'bat') { g.beginPath(); g.moveTo(x, y - 2); g.quadraticCurveTo(x - 3, y - 4, x - 8, y - 3); g.lineTo(x - 6.5, y - 1); g.lineTo(x - 5, y + 1); g.lineTo(x - 3, y); g.lineTo(x - 1.5, y + 2.5); g.lineTo(x, y + 1.5); g.lineTo(x + 1.5, y + 2.5); g.lineTo(x + 3, y); g.lineTo(x + 5, y + 1); g.lineTo(x + 6.5, y - 1); g.lineTo(x + 8, y - 3); g.quadraticCurveTo(x + 3, y - 4, x, y - 2); g.fill(); g.fillRect(x - 1.5, y - 4, 1, 2); g.fillRect(x + 0.5, y - 4, 1, 2); }
  }
  /** a wall decoration hung on the face cell whose top-left is (0, 0) */
  function drawBanner(g, D, seed) {
    var c0 = D.cloth[seed % D.cloth.length], c1 = D.cloth[(seed + 1) % D.cloth.length];
    if (D.banner === 'ring' || D.banner === 'wreath') {
      var cx = 24, cy = 19, R = 13, ever = D.banner === 'wreath';
      g.fillStyle = rgb([28, 20, 14], 0.25); g.beginPath(); g.arc(cx + 1, cy + 2, R + 2, 0, Math.PI * 2); g.fill();
      g.strokeStyle = rgb([70, 48, 30]); g.lineWidth = 1; g.beginPath(); g.moveTo(cx, 1); g.lineTo(cx, cy - R); g.stroke();
      for (var i = 0; i < 44; i++) { var a = i / 44 * Math.PI * 2, r = hash(i, seed, 3), rr0 = R + (i % 2 ? 2 : -2); leaf(g, cx + Math.cos(a) * rr0, cy + Math.sin(a) * rr0, ever ? 5 : 4.6, ever ? 2.1 : 2.2, a + Math.PI / 2 + (r - 0.5), ever ? (r > 0.5 ? [36, 92, 56] : [18, 56, 34]) : (r > 0.5 ? [100, 158, 72] : [60, 110, 50])); }
      if (ever) { g.fillStyle = rgb([210, 36, 40]); for (var b = 0; b < 7; b++) { var ba = b / 7 * Math.PI * 2 + 0.4; g.beginPath(); g.arc(cx + Math.cos(ba) * R, cy + Math.sin(ba) * R, 1.6, 0, Math.PI * 2); g.fill(); }
        g.fillStyle = rgb([176, 28, 36]); g.beginPath(); g.ellipse(cx - 5, cy + R, 5, 3, -0.4, 0, Math.PI * 2); g.fill(); g.beginPath(); g.ellipse(cx + 5, cy + R, 5, 3, 0.4, 0, Math.PI * 2); g.fill(); g.fillRect(cx - 2, cy + R - 2, 4, 4); g.fillRect(cx - 4, cy + R + 1, 2.5, 9); g.fillRect(cx + 1.5, cy + R + 1, 2.5, 8); }
      else { for (var f = 0; f < 11; f++) { var fa = f / 11 * Math.PI * 2; bloom(g, cx + Math.cos(fa) * R, cy + Math.sin(fa) * R, 4.4, D.pennants[f % D.pennants.length], f % 3 ? null : [240, 150, 60]); }
        g.fillStyle = rgb(D.cloth[0]); g.beginPath(); g.ellipse(cx - 4, cy + R + 1, 4, 2.4, -0.4, 0, Math.PI * 2); g.fill(); g.beginPath(); g.ellipse(cx + 4, cy + R + 1, 4, 2.4, 0.4, 0, Math.PI * 2); g.fill(); g.fillRect(cx - 3, cy + R + 2, 2, 8); g.fillRect(cx + 1, cy + R + 2, 2, 7); }
      return;
    }
    var bx = 14, bw = 20, bh = 34, by = 4;
    g.fillStyle = rgb([70, 48, 30]); g.fillRect(bx - 3, by - 2, bw + 6, 3);
    g.beginPath();
    if (D.banner === 'scroll') { g.rect(bx, by, bw, bh - 4); }
    else if (D.banner === 'tatter') { g.moveTo(bx, by); g.lineTo(bx + bw, by); g.lineTo(bx + bw, by + bh - 6); g.lineTo(bx + bw - 3, by + bh); g.lineTo(bx + bw - 7, by + bh - 7); g.lineTo(bx + bw / 2, by + bh - 1); g.lineTo(bx + 6, by + bh - 8); g.lineTo(bx + 3, by + bh - 2); g.lineTo(bx, by + bh - 5); g.closePath(); }
    else { g.moveTo(bx, by); g.lineTo(bx + bw, by); g.lineTo(bx + bw, by + bh); g.lineTo(bx + bw / 2, by + bh - 7); g.lineTo(bx, by + bh); g.closePath(); }
    var gr = g.createLinearGradient(bx, 0, bx + bw, 0); gr.addColorStop(0, rgb(mix(c0, BLACK, 0.25))); gr.addColorStop(0.5, rgb(c0)); gr.addColorStop(1, rgb(mix(c0, BLACK, 0.3)));
    g.fillStyle = gr; g.fill(); g.lineWidth = 1; g.strokeStyle = rgb(mix(c0, BLACK, 0.55)); g.stroke();
    if (D.banner === 'scroll') { g.fillStyle = rgb([40, 26, 20]); g.fillRect(bx - 2, by + bh - 5, bw + 4, 3); g.fillStyle = rgb(c1); g.fillRect(bx + 3, by + bh - 2, 1.5, 6); g.fillRect(bx + bw - 4.5, by + bh - 2, 1.5, 6); g.fillRect(bx + 2, by + 2, bw - 4, 1.2); g.fillRect(bx + 2, by + bh - 8, bw - 4, 1.2); }
    else { g.fillStyle = rgb(c1); g.fillRect(bx + 2, by + 3, bw - 4, 2); g.fillRect(bx + 2, by + bh - 12, bw - 4, 1.5); }
    drawEmblem(g, D, bx + bw / 2, by + 15, c1, c0);
  }

  // ── the centrepiece, standing on (0, 0) ─────────────────────────────────────────────────────────────────────────────
  function drawCentre(g, D, lit) {
    var x = 0, y = 0;
    g.fillStyle = rgb([28, 20, 14], 0.3);
    if (D.centre === 'maypole') {
      var top = y - 128, n = 10;
      g.beginPath(); g.ellipse(x, y - 2, 46, 15, 0, 0, Math.PI * 2); g.fill();   // (v1.0: footprint 58 -> 46 px, it crowded the plaza well)
      var ribbon = function (front) { for (var i2 = 0; i2 < n; i2++) { var a2 = (i2 / n) * Math.PI * 2 + 0.3; if ((Math.sin(a2) >= 0) !== front) continue; var ex2 = x + Math.cos(a2) * 44, ey2 = y - 4 + Math.sin(a2) * 15, col2 = D.pennants[i2 % D.pennants.length];
        g.strokeStyle = rgb(mix(col2, BLACK, front ? 0 : 0.25)); g.lineWidth = 2.6; g.beginPath(); g.moveTo(x, top + 6); g.quadraticCurveTo((x + ex2) / 2, (top + ey2) / 2 + 16, ex2, ey2); g.stroke();
        g.fillStyle = rgb([70, 50, 32]); g.fillRect(ex2 - 1.5, ey2 - 2, 3, 5); } };
      ribbon(false);
      var pole = g.createLinearGradient(x - 4, 0, x + 4, 0); pole.addColorStop(0, rgb([110, 78, 48])); pole.addColorStop(0.5, rgb([206, 170, 120])); pole.addColorStop(1, rgb([96, 66, 40]));
      g.fillStyle = pole; g.fillRect(x - 3.5, top, 7, y - top); for (var s = 0; s < 9; s++) { g.fillStyle = rgb(D.pennants[s % D.pennants.length]); g.save(); g.translate(x, top + 16 + s * 12); g.rotate(-0.5); g.fillRect(-4.6, -2, 9.2, 4); g.restore(); }
      ribbon(true);
      g.fillStyle = rgb([236, 212, 140]); g.beginPath(); g.arc(x, top, 7, 0, Math.PI * 2); g.fill(); g.strokeStyle = rgb([120, 90, 40]); g.lineWidth = 1.2; g.stroke();
      for (var l = 0; l < 14; l++) { var la = l / 14 * Math.PI * 2; leaf(g, x + Math.cos(la) * 11, top + 10 + Math.sin(la) * 4, 4.2, 2, la, l % 2 ? [120, 132, 52] : [168, 150, 52]); }
    } else if (D.centre === 'gate') {
      // the lantern gate: two lacquered pillars, a sweeping lintel, five tall lanterns under it
      g.beginPath(); g.ellipse(x, y - 2, 64, 14, 0, 0, Math.PI * 2); g.fill();
      for (var pc = -1; pc <= 1; pc += 2) { var px = x + pc * 46, pg = g.createLinearGradient(px - 4, 0, px + 4, 0); pg.addColorStop(0, rgb([110, 16, 18])); pg.addColorStop(0.5, rgb([206, 44, 38])); pg.addColorStop(1, rgb([100, 14, 16])); g.fillStyle = pg; g.fillRect(px - 4.5, y - 104, 9, 104); g.fillStyle = rgb([40, 26, 22]); g.fillRect(px - 6.5, y - 8, 13, 8); }
      g.fillStyle = rgb([180, 34, 32]); g.fillRect(x - 54, y - 92, 108, 7);
      g.fillStyle = rgb([36, 24, 22]); g.beginPath(); g.moveTo(x - 66, y - 104); g.quadraticCurveTo(x, y - 112, x + 66, y - 104); g.lineTo(x + 70, y - 112); g.quadraticCurveTo(x, y - 122, x - 70, y - 112); g.closePath(); g.fill();
      g.fillStyle = rgb([200, 40, 36]); g.fillRect(x - 58, y - 106, 116, 5);
      for (var j = 0; j < 5; j++) { var lx = x - 32 + j * 16; g.strokeStyle = rgb([40, 26, 22]); g.lineWidth = 1; g.beginPath(); g.moveTo(lx, y - 85); g.lineTo(lx, y - 76); g.stroke(); drawLamp(g, { lamp: 'tall', glow: D.glow }, lx, y - 64, lit); }
    } else if (D.centre === 'arch') {
      // the flower arch: two posts wound with leaves and an arch covered in blooms
      // v0.2b: posts wound thick with leaves, the arch a deep band of blooms with drops (LOOKED AT 2026-10-18: the first
      // arch was two stalks and a thin hoop)
      g.beginPath(); g.ellipse(x, y - 2, 60, 15, 0, 0, Math.PI * 2); g.fill();
      for (var ac = -1; ac <= 1; ac += 2) { var ax = x + ac * 42; g.fillStyle = rgb([200, 184, 150]); g.fillRect(ax - 4, y - 80, 8, 80); g.fillStyle = rgb([150, 130, 100]); g.fillRect(ax + 1.5, y - 80, 2.5, 80);
        for (var v = 0; v < 16; v++) { var vr = hash(v, ac + 3, 2); leaf(g, ax + (v % 2 ? 4 : -4), y - 6 - v * 4.8, 5, 2.3, (v % 2 ? 0.7 : -0.7) + vr * 0.4, vr > 0.5 ? [96, 154, 70] : [62, 114, 52]); }
        for (var vb = 0; vb < 5; vb++) bloom(g, ax + (vb % 2 ? 3 : -3), y - 14 - vb * 14, 4.2, D.pennants[(vb + (ac > 0 ? 1 : 0)) % D.pennants.length]); }
      for (var band = 0; band < 3; band++) for (var k2 = 0; k2 <= 46; k2++) { var aa = Math.PI + k2 / 46 * Math.PI, rr = hash(k2, 9 + band, 4), rad = 42 + (band - 1) * 6; leaf(g, x + Math.cos(aa) * rad, y - 80 + Math.sin(aa) * (rad - 4), 5.4, 2.4, aa + rr, rr > 0.5 ? [96, 154, 70] : [58, 108, 48]); }
      for (var k3 = 0; k3 <= 34; k3++) { var ab = Math.PI + k3 / 34 * Math.PI, ro = hash(k3, 5, 6), rad2 = 42 + (ro - 0.5) * 12; bloom(g, x + Math.cos(ab) * rad2, y - 80 + Math.sin(ab) * (rad2 - 4), 5.2 + ro * 2.4, D.pennants[k3 % D.pennants.length], k3 % 4 ? null : [240, 150, 60]); }
      for (var dr = 1; dr < 6; dr++) { var ad = Math.PI + dr / 6 * Math.PI, dxp = x + Math.cos(ad) * 38, dyp = y - 80 + Math.sin(ad) * 34; g.strokeStyle = rgb([70, 124, 56]); g.lineWidth = 1; g.beginPath(); g.moveTo(dxp, dyp); g.lineTo(dxp, dyp + 14); g.stroke(); bloom(g, dxp, dyp + 15, 4, D.pennants[(dr + 2) % D.pennants.length]); }
      // flower clumps at the two feet only (v1.0: a row of blooms along the ground closed the arch into a frame, independent
      // review 2026-10-18)
      for (var fc2 = -1; fc2 <= 1; fc2 += 2) for (var k4 = 0; k4 < 4; k4++) bloom(g, x + fc2 * 42 + (k4 - 1.5) * 5, y - 3 - (k4 % 2) * 4, 4.4, D.pennants[(k4 + (fc2 > 0 ? 2 : 0)) % D.pennants.length]);
    } else if (D.centre === 'tree') {
      // the midwinter tree: an evergreen in a tub, a garland spiral, baubles and a star
      g.beginPath(); g.ellipse(x, y - 2, 40, 12, 0, 0, Math.PI * 2); g.fill();
      g.fillStyle = rgb([120, 74, 40]); g.beginPath(); g.moveTo(x - 14, y - 18); g.lineTo(x + 14, y - 18); g.lineTo(x + 11, y); g.lineTo(x - 11, y); g.closePath(); g.fill(); g.fillStyle = rgb([156, 30, 38]); g.fillRect(x - 14, y - 12, 28, 3);
      var tiers = [[0, 36], [1, 30], [2, 24], [3, 17]];
      for (var t = 0; t < tiers.length; t++) { var ty = y - 18 - t * 26, tw = tiers[t][1]; var tg = g.createLinearGradient(x - tw, 0, x + tw, 0); tg.addColorStop(0, rgb([16, 52, 32])); tg.addColorStop(0.5, rgb([40, 100, 60])); tg.addColorStop(1, rgb([14, 46, 30])); g.fillStyle = tg; g.beginPath(); g.moveTo(x - tw, ty); g.lineTo(x + tw, ty); g.lineTo(x, ty - 40); g.closePath(); g.fill(); g.fillStyle = rgb([10, 36, 22], 0.6); for (var nd = -tw + 4; nd < tw; nd += 6) g.fillRect(x + nd, ty - 2, 3, 2); }
      g.strokeStyle = rgb([236, 196, 96]); g.lineWidth = 1.6; g.beginPath(); for (var sp = 0; sp <= 60; sp++) { var u = sp / 60, sy = y - 24 - u * 96, sw = 34 * (1 - u * 0.85); var sx = x + Math.sin(u * Math.PI * 7) * sw; if (sp) g.lineTo(sx, sy); else g.moveTo(sx, sy); } g.stroke();
      for (var bb = 0; bb < 16; bb++) { var bu = hash(bb, 3, 9), bh = y - 24 - bu * 92, bwid = 32 * (1 - bu * 0.85), bxx = x + (hash(bb, 4, 1) * 2 - 1) * bwid * 0.85, bcol = [[196, 36, 44], [236, 188, 80], [80, 120, 200], [240, 240, 230]][bb % 4];
        if (lit && HALO) { g.fillStyle = rgb(D.glow, 0.25); g.beginPath(); g.arc(bxx, bh, 5, 0, Math.PI * 2); g.fill(); } g.fillStyle = rgb(bcol); g.beginPath(); g.arc(bxx, bh, 2.6, 0, Math.PI * 2); g.fill(); g.fillStyle = rgb(WHITE, 0.6); g.fillRect(bxx - 1.2, bh - 1.6, 1, 1); }
      g.save(); g.translate(x, y - 142); g.fillStyle = rgb(mix([226, 180, 70], [255, 240, 180], lit ? 0.6 : 0)); g.beginPath(); for (var sk = 0; sk < 10; sk++) { var sa = sk / 10 * Math.PI * 2 - Math.PI / 2, srr = sk % 2 ? 4 : 9.5; if (sk) g.lineTo(Math.cos(sa) * srr, Math.sin(sa) * srr); else g.moveTo(Math.cos(sa) * srr, Math.sin(sa) * srr); } g.closePath(); g.fill(); g.strokeStyle = rgb([150, 110, 30]); g.lineWidth = 0.8; g.stroke(); g.restore();
    } else {
      // the bonfire: a ring of stones, stacked logs, the flame, three jack-o'-lanterns keeping it
      g.beginPath(); g.ellipse(x, y - 2, 50, 14, 0, 0, Math.PI * 2); g.fill();
      for (var st2 = 0; st2 < 12; st2++) { var sa2 = st2 / 12 * Math.PI * 2; if (Math.sin(sa2) > 0.2) continue; g.fillStyle = rgb(st2 % 2 ? [110, 104, 100] : [86, 80, 78]); g.beginPath(); g.ellipse(x + Math.cos(sa2) * 22, y - 6 + Math.sin(sa2) * 8, 6, 4, 0, 0, Math.PI * 2); g.fill(); }
      g.fillStyle = rgb([84, 56, 34]); for (var lg = 0; lg < 5; lg++) { g.save(); g.translate(x, y - 12); g.rotate(-0.9 + lg * 0.45); g.fillRect(-3, -26, 6, 30); g.fillStyle = rgb([120, 84, 52]); g.fillRect(-1, -26, 2, 30); g.fillStyle = rgb([84, 56, 34]); g.restore(); }
      // the flame: four layers, each a row of tongues of different heights (v0.2b: LOOKED AT 2026-10-18, one tongue a layer
      // read as a single orange drop)
      var fl = [[1, [196, 56, 18]], [0.78, [238, 116, 28]], [0.56, [255, 184, 56]], [0.32, [255, 238, 160]]];
      for (var fi = 0; fi < fl.length; fi++) { var sc = fl[fi][0]; g.fillStyle = rgb(fl[fi][1], lit === false ? 0.4 : 1);
        for (var tg2 = -2; tg2 <= 2; tg2++) { var tx = x + tg2 * 7 * sc, th = (46 + (2 - Math.abs(tg2)) * 14 + hash(tg2 + 5, fi, 3) * 10) * sc, tw2 = 9 * sc + 2;
          g.beginPath(); g.moveTo(tx - tw2, y - 14); g.quadraticCurveTo(tx - tw2 * 1.1, y - 14 - th * 0.55, tx + tg2 * 1.5, y - 14 - th); g.quadraticCurveTo(tx + tw2 * 1.1, y - 14 - th * 0.5, tx + tw2, y - 14); g.closePath(); g.fill(); } }
      for (var st3 = 0; st3 < 12; st3++) { var sa3 = st3 / 12 * Math.PI * 2; if (Math.sin(sa3) <= 0.2) continue; g.fillStyle = rgb(st3 % 2 ? [110, 104, 100] : [86, 80, 78]); g.beginPath(); g.ellipse(x + Math.cos(sa3) * 22, y - 6 + Math.sin(sa3) * 8, 6, 4, 0, 0, Math.PI * 2); g.fill(); }
      for (var jk = 0; jk < 3; jk++) drawLamp(g, D, x - 40 + jk * 40 + (jk === 1 ? 0 : 0), y - 7 + (jk === 1 ? 6 : 0), lit);
    }
  }

  // ── stalls ──────────────────────────────────────────────────────────────────────────────────────────────────────────
  /** a market stall whose foot (bottom centre of its cell) is (0, 0): counter, posts, an awning in the dressing's cloth,
   *  goods (variant 0-2 of the dressing's three) */
  function drawStall(g, D, goods) {
    // the awning takes one of three colours by the stall's goods (v1.0: six identical awnings read as copies, independent
    // review 2026-10-18); its stripe is cream, or a pale tint of the cloth where the awning itself is pale
    var AWN = [D.cloth[0], D.cloth[1], D.pennants[2 % D.pennants.length]], c0 = AWN[goods % 3], lum = 0.3 * c0[0] + 0.59 * c0[1] + 0.11 * c0[2];
    var x = -24, y = -48, c1 = lum > 170 ? mix(D.cloth[0], WHITE, 0.25) : CREAM, ax = x + 3, aw = 42, ay = y + 4, kind = D.goods[goods % 3];
    g.fillStyle = rgb([28, 20, 14], 0.3); g.fillRect(x + 4, y + 42, 40, 5);
    g.fillStyle = rgb([84, 58, 36]); g.fillRect(x + 6, y + 10, 3, 34); g.fillRect(x + 39, y + 10, 3, 34);
    g.fillStyle = rgb([128, 92, 58]); g.fillRect(x + 4, y + 28, 40, 12); g.fillStyle = rgb([156, 116, 74]); g.fillRect(x + 4, y + 28, 40, 3); g.fillStyle = rgb([70, 48, 30]); g.fillRect(x + 4, y + 39, 40, 2);
    for (var k = 0; k < 4; k++) { var gx = x + 10 + k * 9, gy = y + 26; drawGoods(g, D, kind, gx, gy, k); }
    for (var s = 0; s < 6; s++) { g.fillStyle = rgb(s % 2 ? c1 : c0); g.beginPath(); g.moveTo(ax + s * 7, ay); g.lineTo(ax + (s + 1) * 7, ay); g.lineTo(ax + (s + 1) * 7 + 1, ay + 12); g.lineTo(ax + s * 7 + 1, ay + 12); g.closePath(); g.fill(); }
    for (var h = 0; h < 6; h++) { g.fillStyle = rgb(h % 2 ? c1 : c0); g.beginPath(); g.arc(ax + h * 7 + 4.5, ay + 12, 3.5, 0, Math.PI); g.fill(); }
    g.strokeStyle = rgb(mix(c0, BLACK, 0.5)); g.lineWidth = 1; g.strokeRect(ax, ay, aw, 12);
  }
  function drawGoods(g, D, kind, gx, gy, k) {
    if (kind === 'pumpkins') { g.fillStyle = rgb([220, 120, 40]); g.beginPath(); g.ellipse(gx, gy, 4.5, 3.6, 0, 0, Math.PI * 2); g.fill(); g.fillStyle = rgb([90, 110, 40]); g.fillRect(gx - 0.6, gy - 5, 1.4, 2); }
    else if (kind === 'apples') { g.fillStyle = rgb(k % 2 ? [190, 40, 34] : [140, 170, 50]); g.beginPath(); g.arc(gx, gy + 0.5, 3.4, 0, Math.PI * 2); g.fill(); }
    else if (kind === 'loaves' || kind === 'bread') { g.fillStyle = rgb([196, 140, 70]); g.beginPath(); g.ellipse(gx, gy, 4.6, 3, 0, 0, Math.PI * 2); g.fill(); g.strokeStyle = rgb([150, 98, 46]); g.lineWidth = 0.8; g.beginPath(); g.moveTo(gx - 2, gy - 1); g.lineTo(gx + 2, gy - 1); g.stroke(); }
    else if (kind === 'lanterns') { g.fillStyle = rgb(D.pennants[k % D.pennants.length]); g.beginPath(); g.ellipse(gx, gy - 1, 3.4, 4.2, 0, 0, Math.PI * 2); g.fill(); g.fillStyle = rgb([40, 26, 20]); g.fillRect(gx - 2, gy - 5.5, 4, 1.2); }
    else if (kind === 'sweets') { g.fillStyle = rgb([[240, 160, 180], [250, 230, 160], [180, 220, 160], [240, 240, 230]][k % 4]); g.beginPath(); g.arc(gx, gy, 2.6, 0, Math.PI * 2); g.fill(); g.fillStyle = rgb(WHITE, 0.6); g.fillRect(gx - 1, gy - 1.5, 1, 1); }
    else if (kind === 'fans') { g.fillStyle = rgb(D.pennants[(k + 1) % D.pennants.length]); g.beginPath(); g.moveTo(gx, gy + 2); g.arc(gx, gy + 2, 5, Math.PI * 1.15, Math.PI * 1.85); g.closePath(); g.fill(); }
    else if (kind === 'flowers') { g.fillStyle = rgb([92, 146, 66]); g.fillRect(gx - 0.5, gy - 2, 1, 4); bloom(g, gx, gy - 2.5, 3, D.pennants[k % D.pennants.length]); }
    else if (kind === 'pots') { g.fillStyle = rgb([176, 96, 60]); g.beginPath(); g.moveTo(gx - 3, gy - 1); g.lineTo(gx + 3, gy - 1); g.lineTo(gx + 2.2, gy + 3); g.lineTo(gx - 2.2, gy + 3); g.closePath(); g.fill(); leaf(g, gx - 1.2, gy - 3, 2.2, 1, -0.6, [92, 146, 66]); leaf(g, gx + 1.2, gy - 3, 2.2, 1, 0.6, [92, 146, 66]); }
    else if (kind === 'honey') { g.fillStyle = rgb([226, 160, 40]); g.fillRect(gx - 2.6, gy - 3, 5.2, 5.5); g.fillStyle = rgb(CREAM); g.fillRect(gx - 3, gy - 4, 6, 1.6); }
    else if (kind === 'gifts') { g.fillStyle = rgb([[156, 30, 38], [36, 96, 62], [222, 182, 92], [80, 110, 180]][k % 4]); g.fillRect(gx - 3, gy - 3, 6, 5.5); g.fillStyle = rgb([240, 220, 150]); g.fillRect(gx - 0.6, gy - 3, 1.2, 5.5); g.fillRect(gx - 3, gy - 0.8, 6, 1.2); }
    else if (kind === 'candles') { g.fillStyle = rgb(CREAM); g.fillRect(gx - 1.2, gy - 4, 2.4, 6); g.fillStyle = rgb([255, 210, 100]); g.beginPath(); g.ellipse(gx, gy - 5.5, 1, 1.8, 0, 0, Math.PI * 2); g.fill(); }
    else if (kind === 'candy') { g.fillStyle = rgb([[232, 112, 30], [122, 62, 152], [240, 240, 230], [170, 220, 90]][k % 4]); g.beginPath(); g.ellipse(gx, gy, 2.6, 1.8, 0, 0, Math.PI * 2); g.fill(); g.beginPath(); g.moveTo(gx - 2.4, gy); g.lineTo(gx - 4.2, gy - 1.4); g.lineTo(gx - 4.2, gy + 1.4); g.closePath(); g.fill(); g.beginPath(); g.moveTo(gx + 2.4, gy); g.lineTo(gx + 4.2, gy - 1.4); g.lineTo(gx + 4.2, gy + 1.4); g.closePath(); g.fill(); }
  }

  // ── air: one particle frame centred at (0, 0) ───────────────────────────────────────────────────────────────────────
  /** the dressing's particle, frame f of 4 (a turn of a leaf or petal, a flicker of a light) */
  function drawParticle(g, D, f, c) {
    var col = D.airColours[c % D.airColours.length];
    if (D.air === 'leaf') { g.save(); g.rotate(f * Math.PI / 4); g.scale(1, f % 2 ? 0.55 : 1); g.fillStyle = rgb(col); g.beginPath(); g.moveTo(0, -5); g.quadraticCurveTo(4, -2, 0, 5); g.quadraticCurveTo(-4, -2, 0, -5); g.fill(); g.strokeStyle = rgb(mix(col, BLACK, 0.4)); g.lineWidth = 0.6; g.beginPath(); g.moveTo(0, -4); g.lineTo(0, 5); g.stroke(); g.restore(); }
    else if (D.air === 'petal') { g.save(); g.rotate(f * Math.PI / 3); g.scale(1, f % 2 ? 0.5 : 1); g.fillStyle = rgb(col); g.beginPath(); g.ellipse(0, 0, 2.6, 3.8, 0, 0, Math.PI * 2); g.fill(); g.fillStyle = rgb(WHITE, 0.4); g.beginPath(); g.ellipse(-0.6, -1, 0.9, 1.6, 0, 0, Math.PI * 2); g.fill(); g.restore(); }
    else if (D.air === 'skylantern') {
      // v1.0: a warm paper lantern lit from below, not a white card (independent review 2026-10-18)
      var a = 0.8 + 0.2 * (f % 2), gl = g.createRadialGradient(0, 1, 1, 0, 1, 11); gl.addColorStop(0, rgb([255, 190, 110], 0.55 * a)); gl.addColorStop(1, rgb(col, 0)); g.fillStyle = gl; g.beginPath(); g.arc(0, 1, 11, 0, Math.PI * 2); g.fill();
      var pb = g.createLinearGradient(0, -5, 0, 5); pb.addColorStop(0, rgb(mix(col, [150, 50, 30], 0.45))); pb.addColorStop(1, rgb(mix(col, [255, 236, 170], 0.55)));
      g.fillStyle = pb; g.beginPath(); g.moveTo(-3.2, -5); g.quadraticCurveTo(0, -6.2, 3.2, -5); g.lineTo(2.4, 4); g.lineTo(-2.4, 4); g.closePath(); g.fill();
      g.strokeStyle = rgb(mix(col, [120, 40, 20], 0.5), 0.6); g.lineWidth = 0.6; g.beginPath(); g.moveTo(0, -5.6); g.lineTo(0, 4); g.stroke();
      g.fillStyle = rgb([255, 250, 200], a); g.beginPath(); g.ellipse(0, 3.4, 1.4, 1, 0, 0, Math.PI * 2); g.fill();
    }
    else { var r = f % 2 ? 7 : 5.5; var gm = g.createRadialGradient(0, 0, 0.5, 0, 0, r); gm.addColorStop(0, rgb(mix(col, WHITE, 0.6), 0.95)); gm.addColorStop(0.35, rgb(col, 0.6)); gm.addColorStop(1, rgb(col, 0)); g.fillStyle = gm; g.beginPath(); g.arc(0, 0, r, 0, Math.PI * 2); g.fill(); }
  }

  /** a soft round light of the dressing's glow colour, radius r, centred at (0, 0): the glow sprite's texture */
  // (v1.0: a core of 0.85 alpha mixed 30% to white blew lamps out to white diamonds under ADD, independent review 2026-10-18)
  function drawGlow(g, D, r) { var gl = g.createRadialGradient(0, 0, 1, 0, 0, r); gl.addColorStop(0, rgb(mix(D.glow, WHITE, 0.12), 0.58)); gl.addColorStop(0.3, rgb(D.glow, 0.32)); gl.addColorStop(1, rgb(D.glow, 0)); g.fillStyle = gl; g.beginPath(); g.arc(0, 0, r, 0, Math.PI * 2); g.fill(); }

  // ── items: the plan as drawable things with boxes ───────────────────────────────────────────────────────────────────
  /** the string style a span of this type takes in dressing D */
  function styleFor(D, type) { return type === 'cross' ? D.cross : type === 'post' ? D.post : D.eave; }
  /**
   * The plan (FeteCore.plan output) as drawable items in map pixels for tile size T. Each item: { k (post, stall, centre,
   * banner, span), layer (low: on walls, under everyone; stand: sorted with characters by its foot; high: overhead),
   * x, y (its anchor in map pixels: a foot, a cell's top-left for a banner, a string's first end), cx, cy (its cell), ... }
   */
  function items(P, dressing, T) {
    var D = DRESSINGS[dressing] || DRESSINGS.harvest, s = T / 48, out = [], i;
    for (i = 0; i < P.banners.length; i++) out.push({ k: 'banner', layer: 'low', x: P.banners[i].x * T, y: P.banners[i].y * T, cx: P.banners[i].x, cy: P.banners[i].y, seed: i });
    for (i = 0; i < P.lanterns.length; i++) out.push({ k: 'post', layer: 'stand', x: P.lanterns[i].x * T + T / 2, y: (P.lanterns[i].y + 1) * T - 4 * s, cx: P.lanterns[i].x, cy: P.lanterns[i].y });
    for (i = 0; i < (P.stalls || []).length; i++) out.push({ k: 'stall', layer: 'stand', x: P.stalls[i].x * T + T / 2, y: (P.stalls[i].y + 1) * T, cx: P.stalls[i].x, cy: P.stalls[i].y, goods: P.stalls[i].goods });
    if (P.square) out.push({ k: 'centre', layer: 'stand', x: P.square.x * T + T / 2, y: (P.square.y + 1) * T - 6 * s, cx: P.square.x, cy: P.square.y });
    for (i = 0; i < P.spans.length; i++) {
      var sp = P.spans[i], top = sp.type === 'post' || sp.type === 'cross', x0, y0, x1, y1;
      if (top) { x0 = sp.ax * T + T / 2; y0 = (sp.ay + 1) * T - (4 + POST_H - 2) * s; x1 = sp.bx * T + T / 2; y1 = (sp.by + 1) * T - (4 + POST_H - 2) * s; }
      else { x0 = sp.ax * T; y0 = sp.ay * T + 4 * s; x1 = sp.bx * T; y1 = sp.by * T + 4 * s; }
      out.push({ k: 'span', layer: sp.type === 'eave' ? 'low' : 'high', type: sp.type, style: styleFor(D, sp.type), x: x0, y: y0, dx: x1 - x0, dy: y1 - y0, sag: sp.sag, seed: i, cx: sp.ax, cy: sp.ay });
    }
    return out;
  }

  /**
   * The lights an item gives off, relative to its anchor in 48 px units: [[dx, dy, radius], ...]. Strings place theirs
   * with the same arithmetic their drawing uses (a lantern, a bulb), so the light lands on the lamp. The engine draws these
   * into a light layer above the screen tint, so a town tinted for night still glows.
   */
  function emitters(it, dressing) {
    var D = DRESSINGS[dressing] || DRESSINGS.harvest, out = [], p = { x: 0, y: 0 }, i, n;
    if (it.k === 'post') out.push([LAMP_AT.x, LAMP_AT.y, D.lamp === 'basket' ? 22 : 34]);
    else if (it.k === 'centre') {
      if (D.centre === 'gate') { for (i = 0; i < 5; i++) out.push([-32 + i * 16, -64, 22]); out.push([0, -66, 70]); }
      else if (D.centre === 'tree') { out.push([0, -142, 34]); for (i = 0; i < 16; i++) { var bu = hash(i, 3, 9); out.push([(hash(i, 4, 1) * 2 - 1) * 32 * (1 - bu * 0.85) * 0.85, -24 - bu * 92, 9]); } }
      else if (D.centre === 'bonfire') { out.push([0, -44, 84]); out.push([0, -30, 40]); for (i = 0; i < 3; i++) out.push([-40 + i * 40, -7 + (i === 1 ? 6 : 0), 20]); }
    } else if (it.k === 'span') {
      var dx = it.dx, dy = it.dy, span;
      if (it.style === 'lanterns') { span = Math.hypot(dx, dy); n = Math.max(2, Math.round(span / 22)); for (i = 1; i < n; i++) { stringPoint(0, 0, dx, dy, it.sag, i / n, p); out.push([p.x, p.y + 9, 15]); } }
      else if (it.style === 'festoon') { span = Math.hypot(dx, dy); n = Math.max(3, Math.round(span / 13)); for (i = 1; i < n; i++) { stringPoint(0, 0, dx, dy, it.sag, i / n, p); out.push([p.x, p.y + 4, 10]); } }
      else if (it.style === 'evergreen') { span = Math.hypot(dx, dy); n = Math.max(2, Math.round(span / 14)); for (i = 1; i < n; i++) { stringPoint(0, 0, dx, dy, it.sag, i / n, p); out.push([p.x, p.y + 2, 10]); } }
    }
    return out;
  }
  /** draw an item's lights (its emitters) with its anchor at (x, y): soft discs of the dressing's glow colour */
  function drawLight(g, it, dressing, T, x, y) {
    var D = DRESSINGS[dressing] || DRESSINGS.harvest, s = T / 48, em = emitters(spanIn48(it, s), dressing);
    g.save(); g.translate(x, y); g.scale(s, s);
    for (var i = 0; i < em.length; i++) { g.save(); g.translate(em[i][0], em[i][1]); drawGlow(g, D, em[i][2]); g.restore(); }
    g.restore();
    return em.length;
  }
  /** a span item's geometry is in map pixels; its emitters are computed in 48 px units */
  function spanIn48(it, s) { if (it.k !== 'span' || s === 1) return it; return { k: it.k, style: it.style, dx: it.dx / s, dy: it.dy / s, sag: it.sag }; }
  /** the box an item's LIGHT needs (a glow reaches past the body), at tile size T */
  function lightBox(it, dressing, T) {
    var s = T / 48, em = emitters(spanIn48(it, s), dressing); if (!em.length) return null;
    var x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    for (var i = 0; i < em.length; i++) { x0 = Math.min(x0, em[i][0] - em[i][2]); y0 = Math.min(y0, em[i][1] - em[i][2]); x1 = Math.max(x1, em[i][0] + em[i][2]); y1 = Math.max(y1, em[i][1] + em[i][2]); }
    return { w: Math.ceil((x1 - x0) * s), h: Math.ceil((y1 - y0) * s), ax: -x0 * s, ay: -y0 * s };
  }

  /** an item's box at tile size T: { w, h, ax, ay } (the anchor inside the box) */
  function box(it, T) {
    var s = T / 48, b;
    if (it.k === 'banner') b = { w: 48, h: 48, ax: 0, ay: 0 };
    else if (it.k === 'post') b = { w: 60, h: 84, ax: 22, ay: 80 };
    else if (it.k === 'stall') b = { w: 52, h: 54, ax: 26, ay: 52 };
    else if (it.k === 'centre') b = { w: 150, h: 170, ax: 75, ay: 160 };
    else {
      var dx = it.dx / s, dy = it.dy / s, len = Math.abs(dx) + Math.abs(dy), x0 = Math.min(0, dx) - 12, x1 = Math.max(0, dx) + 12, y0 = Math.min(0, dy) - 10, y1 = Math.max(0, dy) + 4 * it.sag * len * 0.25 + 30;
      b = { w: Math.ceil(x1 - x0), h: Math.ceil(y1 - y0), ax: -x0, ay: -y0 };
    }
    return { w: Math.ceil(b.w * s), h: Math.ceil(b.h * s), ax: b.ax * s, ay: b.ay * s };
  }

  /** draw one item with its anchor at (x, y) on context g, tile size T */
  function drawItem(g, it, dressing, T, x, y, opts) {
    var D = DRESSINGS[dressing] || DRESSINGS.harvest, s = T / 48, lit = !opts || opts.lit !== false;
    HALO = !(opts && opts.halo === false);
    g.save(); g.translate(x, y); g.scale(s, s);
    if (it.k === 'banner') drawBanner(g, D, it.seed);
    else if (it.k === 'post') drawPost(g, D, lit);
    else if (it.k === 'stall') drawStall(g, D, it.goods | 0);
    else if (it.k === 'centre') drawCentre(g, D, lit);
    else drawString(g, D, it.style, 0, 0, it.dx / s, it.dy / s, it.sag, it.seed, opts);
    g.restore();
  }

  /**
   * Draw a whole plan onto a canvas context in map pixels (a preview helper; the engine splits these into sprites): low
   * items, standing items in foot order, high items. opts.night darkens what is drawn so far and adds the glows above it,
   * as the engine's screen tint does with Fete's light layer.
   */
  function drawPlan(g, P, dressing, T, opts) {
    opts = opts || {}; var its = items(P, dressing, T), D = DRESSINGS[dressing] || DRESSINGS.harvest, i;
    var order = its.filter(function (a) { return a.layer === 'low'; }).concat(its.filter(function (a) { return a.layer === 'stand'; }).sort(function (a, b) { return a.y - b.y; }), its.filter(function (a) { return a.layer === 'high'; }));
    for (i = 0; i < order.length; i++) drawItem(g, order[i], dressing, T, order[i].x, order[i].y, opts);
    if (opts.air) { for (i = 0; i < opts.air; i++) { var ax = hash(i, 11, 1) * g.canvas.width, ay = hash(i, 12, 2) * g.canvas.height; if (!D.airGlow) { g.save(); g.translate(ax, ay); drawParticle(g, D, i % 4, i); g.restore(); } } }
    if (opts.night) {
      g.save(); g.globalCompositeOperation = 'multiply'; g.fillStyle = 'rgb(70,78,128)'; g.fillRect(0, 0, g.canvas.width, g.canvas.height); g.restore();
      g.save(); g.globalCompositeOperation = 'lighter';
      for (i = 0; i < its.length; i++) drawLight(g, its[i], dressing, T, its[i].x, its[i].y);
      g.restore();
    }
    if (opts.air && D.airGlow) { g.save(); g.globalCompositeOperation = 'lighter'; for (i = 0; i < opts.air; i++) { g.save(); g.translate(hash(i, 11, 1) * g.canvas.width, hash(i, 12, 2) * g.canvas.height * 0.8); drawParticle(g, D, i % 4, i); g.restore(); } g.restore(); }
  }

  return { VERSION: '1.0.0', DRESSINGS: DRESSINGS, ORDER: ORDER, POST_H: POST_H, LAMP_AT: LAMP_AT, items: items, box: box, lightBox: lightBox, emitters: emitters, drawItem: drawItem, drawLight: drawLight, drawPlan: drawPlan, drawParticle: drawParticle, drawGlow: drawGlow,
    drawBunting: drawBunting, drawFestoon: drawFestoon, drawLanternString: drawLanternString, drawGarland: drawGarland, drawPost: drawPost, drawLamp: drawLamp, drawBanner: drawBanner, drawCentre: drawCentre, drawStall: drawStall, styleFor: styleFor, stringPoint: stringPoint, rgb: rgb, mix: mix, hash: hash };
})();
if (typeof module !== 'undefined' && module.exports) module.exports = FeteDraw;
if (typeof window !== 'undefined') window.FeteDraw = FeteDraw;
