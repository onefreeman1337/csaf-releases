/*:
 * @target MZ
 * @plugindesc [v1.0.0] Fete 1/3 - the plan: reads your map and decides where the festival goes. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * FeteCore.js reads a map's tiles and returns where every decoration goes: bunting between neighbouring eaves, banners on
 * wall runs, lanterns along the edges of your lanes, a centrepiece in your square. It touches no part of the engine. Turn
 * it on together with FeteDraw.js and Fete.js; the order does not matter. See Readme_for_Users.md.
 */
/* FeteCore - pure analysis, no engine code; runs in Node for the tests (module.exports) and in MZ (window.FeteCore).
 * Copyright (c) 2026 Core Systems Asset Factory. */
var FeteCore = (function () {
  'use strict';
  // ── seeded randomness: COPIED from Bout_MZ BoutCore.js v1.0.0 lines 16-18 (via PeltCore.js v1.0.0) ─────────────────
  function mix(a, b) { var h = (a ^ Math.imul(b | 0, 0x9E3779B1)) >>> 0; h = Math.imul(h ^ (h >>> 16), 0x85EBCA6B) >>> 0; h = Math.imul(h ^ (h >>> 13), 0xC2B2AE35) >>> 0; return (h ^ (h >>> 16)) >>> 0; }
  function rand(st) { st.rs = (st.rs + 0x6D2B79F5) | 0; var t = st.rs; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }

  // ── tile arithmetic: COPIED from rmmz_core.js (BlankProject) lines 2667-2783, Tilemap.TILE_ID_* and the is*Tile tests.
  // Never paraphrased (wing §3a): core.test.js checks every function against the engine file's own bodies.
  var TILE_ID_A5 = 1536, TILE_ID_A1 = 2048, TILE_ID_A2 = 2816, TILE_ID_A3 = 4352, TILE_ID_A4 = 5888, TILE_ID_MAX = 8192;
  function getAutotileKind(tileId) { return Math.floor((tileId - TILE_ID_A1) / 48); }
  function isTileA1(tileId) { return tileId >= TILE_ID_A1 && tileId < TILE_ID_A2; }
  function isTileA2(tileId) { return tileId >= TILE_ID_A2 && tileId < TILE_ID_A3; }
  function isTileA3(tileId) { return tileId >= TILE_ID_A3 && tileId < TILE_ID_A4; }
  function isTileA4(tileId) { return tileId >= TILE_ID_A4 && tileId < TILE_ID_MAX; }
  function isTileA5(tileId) { return tileId >= TILE_ID_A5 && tileId < TILE_ID_A1; }
  function isWaterTile(tileId) { if (isTileA1(tileId)) { return !(tileId >= TILE_ID_A1 + 96 && tileId < TILE_ID_A1 + 192); } else { return false; } }
  function isGroundTile(tileId) { return isTileA1(tileId) || isTileA2(tileId) || isTileA5(tileId); }
  function isRoofTile(tileId) { return isTileA3(tileId) && getAutotileKind(tileId) % 16 < 8; }
  function isWallTopTile(tileId) { return isTileA4(tileId) && getAutotileKind(tileId) % 16 < 8; }
  function isWallSideTile(tileId) { return (isTileA3(tileId) || isTileA4(tileId)) && getAutotileKind(tileId) % 16 >= 8; }

  /** cell roles */
  var R = { NONE: 0, GROUND: 1, WATER: 2, ROOF: 3, WALL: 4, TOP: 5 };

  /**
   * Read a map into roles and blocked cells. map: { width, height, data } (MZ's six layers, z-major as $dataMap.data);
   * flags: the tileset's flags array (may be empty: then only the roles block); events: [{x, y}] cells that must stay
   * clear; regions come from layer 5. Roles come from the TILE IDS of layers 0 and 1 (never from passability: a fixture
   * tileset can leave every flag 0), and an object on layers 2-3 whose flag is impassable in all four directions (0x0f,
   * not a star 0x10) blocks its cell. COPIED rule: Game_Map.prototype.checkPassage, rmmz_objects.js 6592-6611.
   */
  function analyse(map, flags, events) {
    var W = map.width, H = map.height, N = W * H, d = map.data, i, x, y;
    var role = new Uint8Array(N), blocked = new Uint8Array(N), occupied = new Uint8Array(N), anyObj = new Uint8Array(N), region = new Uint8Array(N), event = new Uint8Array(N), kind = new Int32Array(N);
    for (i = 0; i < N; i++) {
      // the ground KIND of layer 0: an A2 autotile kind, or 1000 + an A5 tile's own id; -1 for anything else
      var t0 = d[i] || 0; kind[i] = isTileA2(t0) ? getAutotileKind(t0) : isTileA5(t0) ? 1000 + t0 - TILE_ID_A5 : -1;
      var r = R.NONE;
      for (var z = 1; z >= 0; z--) {
        var t = d[z * N + i] || 0; if (!t) continue;
        if (isRoofTile(t)) { r = R.ROOF; break; }
        if (isWallSideTile(t)) { r = R.WALL; break; }
        if (isWallTopTile(t)) { r = R.TOP; break; }
        if (isWaterTile(t)) { r = R.WATER; break; }
        if (isGroundTile(t)) { r = R.GROUND; break; }
      }
      role[i] = r;
      // an object (layers 2-3) that is not a star tile OCCUPIES its cell for placement whatever its passability (a well, a
      // barrel or a lamp is no place for a lantern; LOOKED AT 2026-10-17 on Wrack's town, whose fixture flags are all 0, so a
      // passability-only rule would have stood the centrepiece on the plaza's well); impassable (0x0f, not star) also BLOCKS
      for (var z2 = 2; z2 <= 3; z2++) { var o = d[z2 * N + i] || 0; if (!o) continue; anyObj[i] = 1; var f = flags ? flags[o] | 0 : 0; if ((f & 0x10) === 0) occupied[i] = 1; if ((f & 0x10) === 0 && (f & 0x0f) === 0x0f) blocked[i] = 1; }
      region[i] = d[5 * N + i] || 0;
    }
    for (var e = 0; e < (events || []).length; e++) { var ev = events[e]; if (ev && ev.x >= 0 && ev.y >= 0 && ev.x < W && ev.y < H) event[ev.y * W + ev.x] = 1; }
    // buildings: 4-connected components of roof + wall + top cells; each keeps its EAVE (roof cells with a wall below)
    var comp = new Int32Array(N).fill(-1), buildings = [], stack = [];
    for (i = 0; i < N; i++) {
      if (comp[i] >= 0 || !(role[i] === R.ROOF || role[i] === R.WALL || role[i] === R.TOP)) continue;
      var b = { id: buildings.length, x0: W, y0: H, x1: -1, y1: -1, cells: 0, eave: [], face: [] };
      stack.length = 0; stack.push(i); comp[i] = b.id;
      while (stack.length) {
        var c = stack.pop(); x = c % W; y = (c / W) | 0; b.cells++;
        if (x < b.x0) b.x0 = x; if (y < b.y0) b.y0 = y; if (x > b.x1) b.x1 = x; if (y > b.y1) b.y1 = y;
        var nb = [c - W, c + W, c - 1, c + 1];
        for (var k = 0; k < 4; k++) { var q = nb[k]; if (q < 0 || q >= N) continue; if (k >= 2 && ((q / W) | 0) !== y) continue; if (comp[q] < 0 && (role[q] === R.ROOF || role[q] === R.WALL || role[q] === R.TOP)) { comp[q] = b.id; stack.push(q); } }
        if (role[c] === R.ROOF && y + 1 < H && role[c + W] === R.WALL) b.eave.push(c);
        if (role[c] === R.WALL && (y + 1 >= H || !(role[c + W] === R.WALL || role[c + W] === R.ROOF))) b.face.push(c);
      }
      b.eave.sort(function (a, c2) { return a - c2; }); b.face.sort(function (a, c2) { return a - c2; });
      buildings.push(b);
    }
    // the map's dominant ground kind (a town's grass): never the square, never a road
    var count = {}, dominant = -1, most = -1;
    for (i = 0; i < N; i++) { var kd = kind[i]; if (kd < 0) continue; count[kd] = (count[kd] || 0) + 1; if (count[kd] > most) { most = count[kd]; dominant = kd; } }
    return { W: W, H: H, role: role, blocked: blocked, occupied: occupied, anyObj: anyObj, region: region, event: event, kind: kind, comp: comp, buildings: buildings, dominant: dominant };
  }

  /**
   * Roads (v0.2): thin bands of a ground kind that is neither the map's dominant ground nor the square's paving. Walking
   * each column, a horizontal road is a run of 1-3 road cells with ground on both sides; neighbouring columns with the same
   * run join into one segment (4+ long). Rows likewise for vertical roads. Returns [{ o: 'h'|'v', a0, a1 (the extent along
   * the road), b0, b1 (the band across it) }]. A junction (a run longer than 3) ends a segment, so no string crosses one.
   */
  function roads(A, sq) {
    var W = A.W, H = A.H, N = W * H, i, x, y;
    var road = new Uint8Array(N), plaza = new Uint8Array(N);
    if (sq && sq.block) {
      // the square's own paving, flood-filled from its block: a plaza wider than its solid block is still the plaza
      var st = [], k0 = sq.kind; for (y = sq.block[1]; y < sq.block[1] + sq.block[2]; y++) for (x = sq.block[0]; x < sq.block[0] + sq.block[2]; x++) { plaza[y * W + x] = 1; st.push(y * W + x); }
      while (st.length) { var c = st.pop(), cx = c % W, cy = (c / W) | 0, nb = [cx > 0 ? c - 1 : -1, cx < W - 1 ? c + 1 : -1, cy > 0 ? c - W : -1, cy < H - 1 ? c + W : -1];
        for (var q = 0; q < 4; q++) { var n = nb[q]; if (n >= 0 && !plaza[n] && A.kind[n] === k0 && A.role[n] === R.GROUND) { plaza[n] = 1; st.push(n); } } }
    }
    for (i = 0; i < N; i++) if (A.role[i] === R.GROUND && A.kind[i] >= 0 && A.kind[i] !== A.dominant && !plaza[i]) road[i] = 1;
    var segs = [];
    for (var o = 0; o < 2; o++) {
      var L1 = o === 0 ? W : H, L2 = o === 0 ? H : W, live = {};
      for (var a = 0; a < L1; a++) {
        var b = 0;
        while (b < L2) {
          var at0 = o === 0 ? b * W + a : a * W + b;
          if (!road[at0]) { b++; continue; }
          // a run is ONE ground kind: a flower patch beside a lane is not part of the lane (LOOKED AT 2026-10-18: a 3-cell
          // patch of tall grass joined the town's north-south lane into a 4-wide run and the lane lost its strings)
          var b0 = b, rk = A.kind[at0]; while (b < L2 && road[o === 0 ? b * W + a : a * W + b] && A.kind[o === 0 ? b * W + a : a * W + b] === rk) b++;
          var b1 = b - 1, key = rk + ':' + b0 + ',' + b1;
          if (b1 - b0 + 1 > 3 || b0 === 0 || b1 === L2 - 1) continue;
          if (live[key] && live[key].a1 === a - 1) live[key].a1 = a;
          else { live[key] = { o: o === 0 ? 'h' : 'v', a0: a, a1: a, b0: b0, b1: b1 }; segs.push(live[key]); }
        }
      }
    }
    return segs.filter(function (s) { return s.a1 - s.a0 + 1 >= 4; });
  }

  /** a cell the planner may stand a post on: open ground, nothing on it, and no other post within one cell (posts[] holds
   *  {x, y}) */
  function postFree(A, x, y, posts) {
    if (!open(A, x, y) || !standClear(A, x, y)) return false;
    for (var k = 0; k < posts.length; k++) if (Math.abs(posts[k].x - x) < 2 && Math.abs(posts[k].y - y) < 2) return false;
    return true;
  }

  /**
   * Blocking cell (x, y) keeps every passable neighbour reachable from every other through the 3 x 3 window around it
   * (digital topology's simple-point test, 4-connectivity): walk the eight-cell ring, count the runs of passable cells that
   * touch an EDGE neighbour; one run (or none) is safe. pass(i) says whether cell i is passable. Conservative: a cell that
   * would only be safe through a long way round is refused.
   */
  function safeToBlock(A, x, y, pass) {
    var W = A.W, H = A.H, RX = [0, 1, 1, 1, 0, -1, -1, -1], RY = [-1, -1, 0, 1, 1, 1, 0, -1], f = [0, 0, 0, 0, 0, 0, 0, 0], k;
    for (k = 0; k < 8; k++) { var nx = x + RX[k], ny = y + RY[k]; f[k] = nx >= 0 && ny >= 0 && nx < W && ny < H && pass(ny * W + nx) ? 1 : 0; }
    var runs = 0;
    for (k = 0; k < 8; k++) {
      if (!f[k] || f[(k + 7) % 8]) continue;        // the start of a run
      var edge = false, j = k; do { if (j % 2 === 0) edge = true; j = (j + 1) % 8; } while (f[j] && j !== k);
      if (edge) runs++;
    }
    if (runs === 0 && f.every(function (v) { return v; })) runs = 1; // all eight passable: one ring, safe
    return runs <= 1;
  }

  /**
   * The square as a solid block: for each open ground cell, the side of the largest square of open cells of ITS OWN ground
   * kind ending there (the classic maximal-square recurrence), over every kind but the map's most common. A region id, when
   * given, wins: its open cells are the square. Returns { size, x, y, k, kind, block } with x, y the block's centre cell.
   */
  function squareBlock(A, inside, regionId) {
    var W = A.W, H = A.H, N = W * H, i, x, y;
    if (regionId > 0) {
      var cells = [], sx = 0, sy = 0; for (i = 0; i < N; i++) { x = i % W; y = (i / W) | 0; if (A.region[i] === regionId && open(A, x, y)) { cells.push(i); sx += x; sy += y; } }
      if (!cells.length) return null;
      var cx = sx / cells.length, cy = sy / cells.length, bc = cells[0], bd = 1e9;
      for (var c = 0; c < cells.length; c++) { var dx = cells[c] % W - cx, dy = ((cells[c] / W) | 0) - cy; if (dx * dx + dy * dy < bd) { bd = dx * dx + dy * dy; bc = cells[c]; } }
      return { size: cells.length, x: bc % W, y: (bc / W) | 0, k: 0, kind: -1, region: regionId };
    }
    var dominant = A.dominant;
    var dp = new Int32Array(N), best = null;
    for (y = 0; y < H; y++) for (x = 0; x < W; x++) {
      i = y * W + x; var k0 = A.kind[i];
      // the block is found on the PAVING alone (ground role, one kind): a plaza with a well and two lamps in it is still the
      // plaza (MEASURED on Wrack's town: requiring free cells left no 3 x 3 and the square fell back to all open ground)
      if (k0 < 0 || k0 === dominant || A.role[i] !== R.GROUND || A.event[i] || !inside(x, y)) { dp[i] = 0; continue; }
      var up = y > 0 && A.kind[i - W] === k0 ? dp[i - W] : 0, left = x > 0 && A.kind[i - 1] === k0 ? dp[i - 1] : 0, ul = x > 0 && y > 0 && A.kind[i - W - 1] === k0 ? dp[i - W - 1] : 0;
      dp[i] = 1 + Math.min(up, left, ul);
      if (!best || dp[i] > best.k) best = { k: dp[i], x1: x, y1: y, kind: k0 };
    }
    if (!best || best.k < 3) return null;
    // of every block of that size and kind, take the one nearest the middle of its own paving (v0.2: LOOKED AT 2026-10-18,
    // an 8 x 4 field put its 4 x 4 block, and the tree, at the field's left edge because that block was found first)
    var seenK = new Uint8Array(N), stk = [best.y1 * W + best.x1], sx = 0, sy = 0, sn = 0; seenK[stk[0]] = 1;
    while (stk.length) { var c0 = stk.pop(), x0 = c0 % W, y0 = (c0 / W) | 0; sx += x0; sy += y0; sn++;
      var nb4 = [x0 > 0 ? c0 - 1 : -1, x0 < W - 1 ? c0 + 1 : -1, y0 > 0 ? c0 - W : -1, y0 < H - 1 ? c0 + W : -1];
      for (var q = 0; q < 4; q++) { var n4 = nb4[q]; if (n4 >= 0 && !seenK[n4] && A.kind[n4] === best.kind && A.role[n4] === R.GROUND) { seenK[n4] = 1; stk.push(n4); } } }
    var gx = sx / sn, gy = sy / sn, bestD = 1e9;
    for (i = 0; i < N; i++) if (dp[i] === best.k && seenK[i]) { var bxc = i % W - (best.k - 1) / 2, byc = ((i / W) | 0) - (best.k - 1) / 2, dd0 = (bxc - gx) * (bxc - gx) + (byc - gy) * (byc - gy); if (dd0 < bestD - 1e-9) { bestD = dd0; best = { k: best.k, x1: i % W, y1: (i / W) | 0, kind: best.kind }; } }
    // the centrepiece: the free cell of the block nearest its centre WITH NO OBJECT WITHIN ONE CELL (its ribbons and stalls
    // reach a tile each way; LOOKED AT 2026-10-17: the maypole stood beside the plaza well and its ribbons crossed it), else
    // the nearest free cell
    var bx0 = best.x1 - best.k + 1, by0 = best.y1 - best.k + 1, ccx = bx0 + (best.k - 1) / 2, ccy = by0 + (best.k - 1) / 2, pick = -1, pd = 1e9;
    // four passes, in order of preference: clear of every object AND under open sky; under open sky, clear of SOLID objects
    // (a well's roof or a lamp head beside it is allowed: covering the buyer's house front is the worse picture); clear of
    // every object; any free cell
    for (var pass = 0; pass < 4 && pick < 0; pass++) for (y = by0; y <= best.y1; y++) for (x = bx0; x <= best.x1; x++) {
      if (!open(A, x, y)) continue;
      if (pass === 0 && !(clearOf(A, x, y, 1) && headroom(A, x, y, 2))) continue;
      if (pass === 1 && !(clearOf(A, x, y, 1, true) && headroom(A, x, y, 2))) continue;
      if (pass === 2 && !clearOf(A, x, y, 1)) continue;
      var dd = (x - ccx) * (x - ccx) + (y - ccy) * (y - ccy); if (dd < pd) { pd = dd; pick = y * W + x; }
    }
    if (pick < 0) return null;
    return { size: best.k * best.k, x: pick % W, y: (pick / W) | 0, k: best.k, kind: best.kind, block: [bx0, by0, best.k] };
  }

  /** no object (a star object too: a well's roof, a crown), block or event in the (2r+1) square round (x, y). v1.0: star
   *  objects count (independent review 2026-10-18: the maypole's ribbons lay over the plaza well's roof, a star tile) */
  function clearOf(A, x, y, r, solidOnly) { for (var dy = -r; dy <= r; dy++) for (var dx = -r; dx <= r; dx++) { var nx = x + dx, ny = y + dy; if (nx < 0 || ny < 0 || nx >= A.W || ny >= A.H) continue; var n = ny * A.W + nx; if (A.occupied[n] || (!solidOnly && A.anyObj[n]) || A.blocked[n] || A.event[n]) return false; } return true; }

  /** no roof, wall or wall top in the n rows above (x, y): a centrepiece stands two to three tiles tall and must not reach up
   *  over a house front (LOOKED AT 2026-10-18: the flower arch, moved off the well, stood on the plaza's north rim and its top
   *  tangled with the house garland) */
  function headroom(A, x, y, n) { for (var k = 1; k <= n; k++) { var yy = y - k; if (yy < 0) break; var r = A.role[yy * A.W + x]; if (r === R.ROOF || r === R.WALL || r === R.TOP) return false; } return true; }

  /** a cell a post may stand on: no object on it at all and no star object (an overhanging crown) directly above it, where
   *  the post's top and lamp reach. v1.0 (independent review 2026-10-18: lamp posts ran up into tree crowns) */
  function standClear(A, x, y) { var i = y * A.W + x; if (A.anyObj[i]) return false; if (y > 0 && A.anyObj[i - A.W] && !A.occupied[i - A.W]) return false; return true; }

  /** a stall's cell: nothing on it, no object left or right of it (the counter is cell-wide), no star object (a crown that
   *  overhangs) above it */
  function stallClear(A, x, y) {
    var W = A.W, i = y * W + x;
    if (A.anyObj[i]) return false;
    if (x > 0 && (A.occupied[i - 1] || A.event[i - 1])) return false;
    if (x + 1 < W && (A.occupied[i + 1] || A.event[i + 1])) return false;
    if (y > 0 && A.anyObj[i - W] && !A.occupied[i - W]) return false;
    return true;
  }

  /** is cell (x, y) open ground a decoration may stand over: ground role, not blocked, not an event */
  function open(A, x, y) { if (x < 0 || y < 0 || x >= A.W || y >= A.H) return false; var i = y * A.W + x; return A.role[i] === R.GROUND && !A.blocked[i] && !A.occupied[i] && !A.event[i]; }

  /**
   * The plan for one dressing. opts: { seed, maxSpan (cells, default 6), pitch (cells between lanterns, default 3),
   * inside(x, y) -> bool (the target: whole map, a region or a rect; default all) }. Returns pixel-free cell geometry:
   *   spans:    bunting from building a's eave end to building b's eave end across open ground (a left of b), with the gap
   *   banners:  on each front wall run, between doors, one per run of 2+ free face cells
   *   lanterns: on open ground cells along building fronts and the square's rim, at a pitch
   *   square:   the largest 8-connected open ground region (cells, centroid) and its centrepiece cell
   */
  function plan(A, opts) {
    opts = opts || {};
    var st = { rs: mix(0x46455445, opts.seed | 0) | 0 }, maxSpan = opts.maxSpan || 6, pitch = opts.pitch || 3;
    var inside = opts.inside || function () { return true; }, W = A.W, H = A.H, i, x, y;
    var out = { spans: [], banners: [], lanterns: [], square: null };
    // spans: for every pair of buildings side by side, eave ends facing each other across open ground
    var ends = A.buildings.filter(function (b) { return b.eave.length; }).map(function (b) {
      var ex0 = W, ex1 = -1, ey = -1; for (var k = 0; k < b.eave.length; k++) { var c = b.eave[k], cx = c % W, cy = (c / W) | 0; if (cx < ex0) ex0 = cx; if (cx > ex1) ex1 = cx; if (cy > ey) ey = cy; }
      return { b: b.id, x0: ex0, x1: ex1, y: ey };
    });
    for (var a = 0; a < ends.length; a++) for (var c2 = 0; c2 < ends.length; c2++) {
      var L = ends[a], Rr = ends[c2]; if (L.b === Rr.b) continue;
      var gap = Rr.x0 - L.x1 - 1; if (gap < 1 || gap > maxSpan || Math.abs(L.y - Rr.y) > 1) continue;
      // the string runs one row below the lower eave (in front of the walls): every cell under it must be open ground
      var sy = Math.max(L.y, Rr.y) + 1, clear = true;
      for (x = L.x1 + 1; x < Rr.x0 && clear; x++) { var ok = false; for (y = sy; y < Math.min(H, sy + 3); y++) if (A.role[y * W + x] === R.GROUND && !A.event[y * W + x]) { ok = true; break; } if (!ok || A.role[(sy - 1) * W + x] === R.ROOF) clear = false;
        // v1.0: never across a tree crown standing in the gap (a star object in the string's band; independent review
        // 2026-10-18: the pennants were drawn over the canopy)
        for (var yb = sy - 1; yb <= sy && clear; yb++) { var cb = yb * W + x; if (A.anyObj[cb] && !A.occupied[cb]) clear = false; } }
      if (!clear || !inside(L.x1, L.y) || !inside(Rr.x0, Rr.y)) continue;
      out.spans.push({ a: L.b, b: Rr.b, ax: L.x1 + 1, ay: L.y + 1, bx: Rr.x0, by: Rr.y + 1, gap: gap, sag: 0.18 + 0.12 * rand(st), type: 'gap' });
    }
    // eave strings (v0.1b): a pennant string along every eave of 3+ cells, corner to corner, just under the roof's edge.
    // LOOKED AT 2026-10-17 (preview_town_verdant_harvest.png): with gap spans alone two short strings were the whole
    // festival; a string along each house front is what reads as "dressed"
    for (var ei = 0; ei < ends.length; ei++) { var E = ends[ei]; if (E.x1 - E.x0 + 1 >= 3 && inside(E.x0, E.y) && inside(E.x1, E.y)) out.spans.push({ a: E.b, b: E.b, ax: E.x0, ay: E.y + 1, bx: E.x1 + 1, by: E.y + 1, gap: 0, sag: 0.05 + 0.03 * rand(st), type: 'eave' }); }
    // banners on the front wall's FREE cells (not a door, not under an event, no object: a window is an object), at least
    // one cell apart. LOOKED AT 2026-10-17: the first rule hung banners over windows
    for (var bi = 0; bi < A.buildings.length; bi++) {
      var B = A.buildings[bi], last = -9;
      for (var f = 0; f < B.face.length; f++) {
        var cell = B.face[f], fx = cell % W, fy = (cell / W) | 0, door = A.event[cell] || (fy + 1 < H && A.event[cell + W]);
        // (anyObj, not just occupied: a crown overhanging the wall hid half a banner, independent review 2026-10-18)
        if (door || A.anyObj[cell] || !inside(fx, fy) || fx - last < 2) continue;
        out.banners.push({ b: B.id, x: fx, y: fy }); last = fx;
      }
    }
    // the square, first choice: the largest SOLID BLOCK (k x k open cells of one ground kind) of a kind that is NOT the
    // map's dominant ground (a town's grass), k >= 3, or the buyer's region (opts.squareRegion). LOOKED AT 2026-10-17
    // (_probe/plan_ascii.js): "the largest open region" was the whole town's ground (285 of 384 cells), so the
    // centrepiece landed at the edge of the plaza by accident. A road is a thin block, so it loses to a plaza
    var sq = squareBlock(A, inside, opts.squareRegion | 0);
    if (sq) out.square = sq;
    // stalls (v0.1c) on the square block's RIM: free cells, two apart, never within one cell of the centrepiece
    out.stalls = [];
    if (sq && sq.block) {
      var r0x = sq.block[0], r0y = sq.block[1], rk = sq.block[2], lastS = null;
      for (y = r0y; y < r0y + rk; y++) for (x = r0x; x < r0x + rk; x++) {
        if (!(x === r0x || y === r0y || x === r0x + rk - 1 || y === r0y + rk - 1)) continue;
        // the two collisions LOOKED AT 2026-10-17, and only those: a stall leaned on the plaza well (an object beside it) and
        // one stood under a tree crown (a STAR object above it, which overhangs). A barrel above a stall read fine, so the
        // first, wider rule (3 x 3 clear) is not the rule: it left one stall on the plaza
        if (!open(A, x, y) || !inside(x, y) || (Math.abs(x - sq.x) <= 1 && Math.abs(y - sq.y) <= 1) || !stallClear(A, x, y)) continue;
        if (out.stalls.some(function (o) { return Math.abs(o.x - x) < 2 && Math.abs(o.y - y) < 2; })) continue;
        out.stalls.push({ x: x, y: y, goods: (rand(st) * 3) | 0 }); lastS = x;
      }
    }
    // fallback: the largest 8-connected open region; its centrepiece is the open cell nearest its centroid
    var seen = new Uint8Array(W * H), best = null, q2 = [];
    for (i = 0; i < W * H; i++) {
      x = i % W; y = (i / W) | 0; if (seen[i] || !open(A, x, y) || !inside(x, y)) continue;
      var cells = [], sx = 0, sy2 = 0; q2.length = 0; q2.push(i); seen[i] = 1;
      while (q2.length) { var c3 = q2.pop(), cx = c3 % W, cy = (c3 / W) | 0; cells.push(c3); sx += cx; sy2 += cy;
        for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) { var nx = cx + dx, ny = cy + dy, n = ny * W + nx; if ((dx || dy) && nx >= 0 && ny >= 0 && nx < W && ny < H && !seen[n] && open(A, nx, ny) && inside(nx, ny)) { seen[n] = 1; q2.push(n); } } }
      if (!best || cells.length > best.cells.length) best = { cells: cells, cx: sx / cells.length, cy: sy2 / cells.length };
    }
    // (only a map with houses: a town with no paved square holds its fair on its green, but a forest or a dungeon with no
    // building must not grow a maypole in its biggest clearing; v0.2, 2026-10-18)
    // (and only when the caller allows it: a region or a rectangle with no paved block of its own gets no centrepiece,
    // LOOKED AT 2026-10-18: a rectangle over one house put a flower arch over that house's front)
    if (best && !out.square && A.buildings.length && opts.fallbackSquare !== false) {
      // nearest the open region's centroid, preferring open sky above and no solid object beside (the block rules, relaxed)
      var bc = null, bd = 1e9;
      for (var fp = 0; fp < 2 && bc === null; fp++) for (var j = 0; j < best.cells.length; j++) { var cc = best.cells[j], ccx2 = cc % W, ccy2 = (cc / W) | 0;
        if (fp === 0 && !(headroom(A, ccx2, ccy2, 2) && clearOf(A, ccx2, ccy2, 1, true))) continue;
        var ddx = ccx2 - best.cx, ddy = ccy2 - best.cy, dd = ddx * ddx + ddy * ddy; if (dd < bd) { bd = dd; bc = cc; } }
      out.square = { size: best.cells.length, cx: best.cx, cy: best.cy, x: bc % W, y: (bc / W) | 0 };
    }
    // lanterns: open cells directly in front of a building face, every `pitch` cells along each face run, skipping doors
    for (var b2 = 0; b2 < A.buildings.length; b2++) {
      var F = A.buildings[b2].face, n2 = 0;
      var prev = null;
      for (var k2 = 0; k2 < F.length; k2++) { var fc = F[k2], lx = fc % W, ly = ((fc / W) | 0) + 1; if (A.event[fc] || !open(A, lx, ly) || !standClear(A, lx, ly) || !inside(lx, ly)) continue; if (n2++ % pitch === 0) {
        out.lanterns.push({ x: lx, y: ly, b: b2 });
        // post strings (v0.1b): a string swagged between two neighbouring posts of one front, at the posts' tops
        if (prev && lx - prev.x >= 2 && lx - prev.x <= maxSpan) out.spans.push({ a: b2, b: b2, ax: prev.x, ay: ly, bx: lx, by: ly, gap: lx - prev.x, sag: 0.12, type: 'post' });
        prev = { x: lx, y: ly };
      } }
    }
    // road posts and strings ACROSS the road (v0.2). LOOKED AT 2026-10-17: with strings only along house fronts the lanes
    // between them were bare. A horizontal road gets posts zigzagging edge to edge, a string from each to the next; a
    // vertical road gets a pair of posts per stop and a string straight across. A face lantern within a cell of a wanted
    // post IS that post (it is reused, never doubled)
    out.roads = roads(A, sq);
    var crossPitch = opts.crossPitch || 3, avoid = out.stalls.slice();
    if (out.square) avoid.push({ x: out.square.x, y: out.square.y });
    for (var ri = 0; ri < out.roads.length; ri++) {
      var Rd = out.roads[ri], chain = [], side = 0;
      for (var at = Rd.a0 + 1; at <= Rd.a1 - 1; at += crossPitch, side ^= 1) {
        if (Rd.o === 'h') { chain.push(roadPost(A, Rd, at, side, out.lanterns, avoid, inside)); continue; }
        var pair = roadPair(A, Rd, at, out.lanterns, avoid, inside);
        if (pair) out.spans.push({ a: -1, b: -1, ax: pair[0].x, ay: pair[0].y, bx: pair[1].x, by: pair[1].y, gap: pair[1].x - pair[0].x, sag: 0.10 + 0.06 * rand(st), type: 'cross' });
      }
      // a zigzag string runs 2 to crossMax cells along the road (LOOKED AT 2026-10-18: a 6-cell diagonal swept across a
      // house front, and a 1-cell one hung nearly straight down)
      for (var ci = 1; ci < chain.length; ci++) { var p0 = chain[ci - 1], p1 = chain[ci], dxc = p1 && p0 ? p1.x - p0.x : 0;
        if (p0 && p1 && dxc >= 2 && dxc <= (opts.crossMax || 4) && p0.y !== p1.y) out.spans.push({ a: -1, b: -1, ax: p0.x, ay: p0.y, bx: p1.x, by: p1.y, gap: dxc, sag: 0.08 + 0.06 * rand(st), type: 'cross' }); }
    }
    // solid decorations (v0.2): posts, stalls and the centrepiece block their cell unless opts.solid === false, but only
    // where blocking keeps every neighbour reachable (safeToBlock); a refused cell stays walkable and is NAMED in refused[]
    out.solid = []; out.refused = [];
    if (opts.solid !== false) {
      var solidMap = new Uint8Array(W * H), pass = function (c) { return A.role[c] === R.GROUND && !A.blocked[c] && !solidMap[c]; };
      var items = out.lanterns.concat(out.stalls); if (out.square) items.push({ x: out.square.x, y: out.square.y });
      for (var si = 0; si < items.length; si++) { var it = items[si], ci2 = it.y * W + it.x; if (solidMap[ci2]) continue;
        if (safeToBlock(A, it.x, it.y, pass)) { solidMap[ci2] = 1; out.solid.push(ci2); } else out.refused.push(ci2); }
    }
    return out;
  }

  /**
   * One post beside road Rd at position `at` along it, on side 0 (north / west) or 1 (south / east). Tries the cell just
   * off the road, one either way along it, then (a road 2+ wide) the road's own edge cell, which still leaves a lane. A
   * lantern already within a cell is reused; a new post needs postFree, the target, and no stall or centrepiece within a
   * cell (avoid[]). Returns the post ({x, y}) or null.
   */
  function roadPost(A, Rd, at, side, lanterns, avoid, inside) {
    var along = [0, 1, -1];
    for (var k = 0; k < along.length; k++) { var c = sideCell(A, Rd, at + along[k], side, lanterns, avoid, inside); if (c) return commitPost(c, lanterns); }
    return null;
  }
  /** a PAIR of posts facing each other across vertical road Rd at one row (at, at + 1 or at - 1), or null */
  function roadPair(A, Rd, at, lanterns, avoid, inside) {
    var along = [0, 1, -1];
    for (var k = 0; k < along.length; k++) {
      var w = sideCell(A, Rd, at + along[k], 0, lanterns, avoid, inside); if (!w) continue;
      var e = sideCell(A, Rd, at + along[k], 1, lanterns, avoid, inside); if (!e || e.y !== w.y) continue;
      return [commitPost(w, lanterns), commitPost(e, lanterns)];
    }
    return null;
  }
  /** the cell a post would take beside road Rd at exactly position `at` along it on `side`, WITHOUT placing it: the cell
   *  just off the road, then (a road 2+ wide) the road's own edge cell. { x, y, reuse } where reuse is a lantern already
   *  within a cell on that side */
  function sideCell(A, Rd, at, side, lanterns, avoid, inside) {
    var thick = Rd.b1 - Rd.b0 + 1, across = [side ? Rd.b1 + 1 : Rd.b0 - 1], j, d, near = thick >= 2 ? 1 : 0;
    if (thick >= 2) across.push(side ? Rd.b1 : Rd.b0);
    for (j = 0; j < across.length; j++) {
      var x = Rd.o === 'h' ? at : across[j], y = Rd.o === 'h' ? across[j] : at;
      for (d = 0; d < lanterns.length; d++) { var L = lanterns[d], u = Rd.o === 'h' ? L.y : L.x;
        if (Math.abs(L.x - x) <= 1 && Math.abs(L.y - y) <= 1 && (side ? u > Rd.b1 - near : u < Rd.b0 + near) && (Rd.o === 'h' ? L.x === x : L.y === y)) return { x: L.x, y: L.y, reuse: L }; }
      if (inside(x, y) && postFree(A, x, y, lanterns.concat(avoid))) return { x: x, y: y, reuse: null };
    }
    return null;
  }
  function commitPost(c, lanterns) { if (c.reuse) return c.reuse; var p = { x: c.x, y: c.y, b: -1, road: true }; lanterns.push(p); return p; }

  var api = { VERSION: '1.0.0', R: R, mix: mix, rand: rand, analyse: analyse, plan: plan, open: open, roads: roads, safeToBlock: safeToBlock,
    isRoofTile: isRoofTile, isWallSideTile: isWallSideTile, isWallTopTile: isWallTopTile, isWaterTile: isWaterTile, isGroundTile: isGroundTile, getAutotileKind: getAutotileKind,
    TILE: { A1: TILE_ID_A1, A2: TILE_ID_A2, A3: TILE_ID_A3, A4: TILE_ID_A4, A5: TILE_ID_A5, MAX: TILE_ID_MAX } };
  return api;
})();
if (typeof module !== 'undefined' && module.exports) module.exports = FeteCore;
if (typeof window !== 'undefined') window.FeteCore = FeteCore;
