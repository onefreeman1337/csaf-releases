/*:
 * @target MZ
 * @plugindesc Rebus 3/3 - picture word puzzles from your own database: four pictures, silhouette, close-up and mosaic rounds.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @param material
 * @text Tile material
 * @type select
 * @option wood
 * @option brass
 * @option ivory
 * @option slate
 * @default brass
 *
 * @param pixelArt
 * @text Pixel art pictures
 * @type boolean
 * @on Sharp pixels
 * @off Smooth
 * @desc ON: your icons, faces and battlers keep sharp pixels at every size. OFF: smoothed when the scale is not a whole number.
 * @default false
 *
 * @param roundLabel
 * @text Round label
 * @desc %1 is the round, %2 the number of rounds.
 * @default ROUND %1 OF %2
 *
 * @param hintLetterLabel
 * @text Hint label: reveal a letter
 * @default Letter
 *
 * @param hintClearLabel
 * @text Hint label: clear decoys
 * @default Clear
 *
 * @param solvedWord
 * @text Solved stamp word
 * @default SOLVED
 *
 * @command start
 * @text Start a Rebus game
 * @desc Opens the puzzle scene. Rounds are built from your database; results go to the variables and switch below.
 *
 * @arg mode
 * @text Mode
 * @type select
 * @option mixed
 * @option four
 * @option silhouette
 * @option closeup
 * @option mosaic
 * @default mixed
 *
 * @arg rounds
 * @text Rounds
 * @type number
 * @min 1
 * @max 30
 * @default 5
 *
 * @arg seconds
 * @text Reveal time (close-up, mosaic)
 * @desc Seconds a close-up takes to widen to the whole picture, or a mosaic to sharpen. Also the par time for scoring.
 * @type number
 * @min 5
 * @max 120
 * @default 20
 *
 * @arg goldPerHint
 * @text Gold per hint
 * @desc 0 = hints are free (they still cost points).
 * @type number
 * @min 0
 * @default 0
 *
 * @arg scoreVariable
 * @text Score variable
 * @type variable
 * @default 0
 *
 * @arg solvedVariable
 * @text Solved count variable
 * @type variable
 * @default 0
 *
 * @arg allSolvedSwitch
 * @text All-solved switch
 * @type switch
 * @default 0
 *
 * @help
 * Rebus.js - part of Rebus v1.0.0. Enable it with RebusCore.js and RebusDraw.js (any order).
 *
 * Plugin command "Start a Rebus game" opens a puzzle scene whose rounds come from YOUR database:
 *   four        two to four DIFFERENT icons pinned to a board that share one name: the weapons of one weapon type, the
 *               armours of one armour type or slot, the skills of one element or skill type, or your own group (below)
 *   silhouette  an enemy battler, blacked out on a spotlit stage
 *   closeup     an actor face, a battler or an icon seen through a lens that widens over time
 *   mosaic      an icon, a face or a battler as blocks that sharpen over time
 *   mixed       a round of each in turn
 * A name whose records all share ONE icon is asked as a single-picture round instead.
 * The player spells the answer from a tray of tiles: click a tile, or type its letter; click a filled slot or press
 * Backspace to take a tile back; Escape leaves. Two hints: reveal a letter, clear the decoys.
 *
 * Notetags:
 *   <Rebus: skip>         on any weapon, armour, skill, item, enemy or actor: never use this record
 *   <Rebus: word>         on an enemy or actor: spell this word instead of its name
 *   <Rebus Group: word>   on any item, weapon, armour or skill: put it in a picture round whose answer is that word
 * Answers are Latin letters A-Z (3 to 12 letters; spaces, hyphens and apostrophes are shown, never spelled). A name
 * with any other character is skipped, never mangled.
 *
 * The tile face is "Palatino Linotype" (Windows), then Book Antiqua, Palatino (macOS), Georgia, then the system serif.
 *
 * Every line of this plugin was written with AI assistance.
 */
/*
 * The scene owns three layers, each a Bitmap baked by RebusDraw only when something changes (a tile moves, a reveal step
 * passes): BACK (table, board or stage), PIC (the pictures), PLAY (rail, tray, strip). update() reads input and timers and
 * allocates nothing. No pixel is ever read back from the GPU in play (Probe_Doctrine §27a): pictures are fitted by their
 * cell, never by an opaque-box scan.
 */
(function () {
  'use strict';
  var NAME = 'Rebus';
  var P = PluginManager.parameters(NAME);
  var MATERIAL = String(P.material || 'brass');
  // pixel art keeps sharp pixels at every scale (a 4x close-up of a pixel-art face, smoothed, was a blur; LOOKED AT
  // 2026-10-10). Read as the string "true": parameters arrive as strings (wing §16)
  var PIXEL_ART = String(P.pixelArt) === 'true';
  var ROUND_LABEL = String(P.roundLabel || 'ROUND %1 OF %2');
  var HINT_LETTER = String(P.hintLetterLabel || 'Letter');
  var HINT_CLEAR = String(P.hintClearLabel || 'Clear');
  var SOLVED_WORD = String(P.solvedWord || 'SOLVED');
  var MODES = ['four', 'silhouette', 'closeup', 'mosaic'];

  /** siblings resolved at FIRST USE, never at load (wing §8 trap 2: load order is the buyer's) */
  // resolved once and kept: deps() runs every frame (stepKey, readKeys), and returning a fresh object each call was a
  // per-frame allocation (found 2026-10-10 by Internal_Ops/_scripts/alloc.test.js)
  var DEPS = null;
  function deps() {
    if (DEPS) return DEPS;
    if (typeof RebusCore === 'undefined' || typeof RebusDraw === 'undefined') throw new Error('Rebus needs RebusCore.js and RebusDraw.js enabled');
    DEPS = { core: RebusCore, draw: RebusDraw };
    return DEPS;
  }
  /** a plugin-command id: parameters arrive as strings and "0" is truthy (wing §16) */
  function idOf(v) { var n = Number(v); return n > 0 ? Math.floor(n) : 0; }

  /** Build the game's rounds from the live database. */
  function buildGame(args) {
    var C = deps().core;
    var seed = C.mix(($gameSystem.playtime() | 0) + 1, (Graphics.frameCount | 0) + ($gameParty.gold() | 0));
    var all = C.harvest({ system: $dataSystem, weapons: $dataWeapons, armors: $dataArmors, skills: $dataSkills, items: $dataItems, enemies: $dataEnemies, actors: $dataActors }, { seed: seed });
    var run = { rs: C.mix(seed, 0x7eb05) };
    var fours = C.shuffle(run, all.filter(function (r) { return r.mode === 'four'; }));
    var singles = C.shuffle(run, all.filter(function (r) { return r.mode === 'silhouette'; }));
    // a SILHOUETTE needs a subject with clear space around it: an enemy battler. MZ's icons sit on an opaque framed tile
    // and blacked out they are a black square (LOOKED AT in engine 2026-10-10); icons and faces are close-up and mosaic
    // rounds instead. Decided by kind, never by reading pixels in play (Probe_Doctrine §27a).
    // and a CLOSE-UP needs large art: a 32 px icon at 6x is a few squares of its frame (LOOKED AT in engine 2026-10-10),
    // so close-ups take faces and battlers first and mosaics take icons first
    var battlers = singles.filter(function (r) { return r.pictures[0].kind === 'battler'; });
    var faces = singles.filter(function (r) { return r.pictures[0].kind === 'face'; });
    var icons = singles.filter(function (r) { return r.pictures[0].kind === 'icon'; });
    var used = {};
    var take = function (lists) {
      for (var a = 0; a < lists.length; a++) for (var b = 0; b < lists[a].length; b++) if (!used[lists[a][b].id]) { used[lists[a][b].id] = true; return lists[a][b]; }
      return null;
    };
    var mode = MODES.indexOf(String(args.mode)) >= 0 ? String(args.mode) : 'mixed';
    var want = Math.max(1, Math.min(30, Number(args.rounds) || 5)), list = [];
    for (var i = 0; i < want; i++) {
      var m = mode === 'mixed' ? MODES[i % MODES.length] : mode, src = null;
      if (m === 'four') src = take([fours]);
      else if (m === 'silhouette') src = take([battlers]);
      else if (m === 'closeup') src = take([faces, battlers, icons]);
      else src = take([icons, faces, battlers]);
      // a mode the database has run out of falls back to another, so the game still has its rounds
      if (!src) { src = take([fours]); if (src) m = 'four'; }
      if (!src) { src = take([icons, faces, battlers]); if (src) m = 'mosaic'; }
      if (!src) break;
      list.push({ id: src.id, show: m, answer: src.answer, pictures: src.pictures });
    }
    return {
      run: run, rounds: list, index: 0, total: 0, solved: 0,
      seconds: Math.max(5, Math.min(120, Number(args.seconds) || 20)), gold: Math.max(0, Number(args.goldPerHint) || 0),
      scoreVar: idOf(args.scoreVariable), solvedVar: idOf(args.solvedVariable), allSwitch: idOf(args.allSolvedSwitch),
    };
  }

  PluginManager.registerCommand(NAME, 'start', function (args) {
    var game = buildGame(args);
    if (!game.rounds.length) return;
    Scene_Rebus.pending = game;
    SceneManager.push(Scene_Rebus);
  });

  /* ======================================================================= the scene */
  function Scene_Rebus() { this.initialize.apply(this, arguments); }
  Scene_Rebus.prototype = Object.create(Scene_Base.prototype);
  Scene_Rebus.prototype.constructor = Scene_Rebus;
  Scene_Rebus.pending = null;

  Scene_Rebus.prototype.initialize = function () {
    Scene_Base.prototype.initialize.call(this);
    this._game = Scene_Rebus.pending; Scene_Rebus.pending = null;
    this._keys = []; this._keyHead = 0;
    this._onKey = this.onKey.bind(this);
    this._trayRects = []; this._slotRects = []; this._hintRects = [{ x: 0, y: 0, w: 0, h: 0 }, { x: 0, y: 0, w: 0, h: 0 }];
    this._images = {}; this._st = null; this._frames = 0; this._solvedAt = -1; this._stepKey = -1;
    this._dirtyPlay = true; this._dirtyPic = true; this._dirtyBack = true;
  };
  Scene_Rebus.prototype.create = function () {
    Scene_Base.prototype.create.call(this);
    var W = Graphics.width, H = Graphics.height;
    this._back = new Sprite(new Bitmap(W, H)); this._pic = new Sprite(new Bitmap(W, H)); this._play = new Sprite(new Bitmap(W, H));
    this.addChild(this._back); this.addChild(this._pic); this.addChild(this._play);
    this._layout = this.layout(W, H);
    this.startRound();
  };
  /** the frame's regions, derived from the screen size, never typed per resolution */
  Scene_Rebus.prototype.layout = function (W, H) {
    var picH = Math.round(H * 0.53), railY = picH + 24;
    return { W: W, H: H, pic: { x: Math.round(W * 0.12), y: 14, w: Math.round(W * 0.76), h: picH - 14 }, railY: railY, trayY: railY + 84, stripY: H - 50 };
  };
  Scene_Rebus.prototype.start = function () {
    Scene_Base.prototype.start.call(this);
    document.addEventListener('keydown', this._onKey);
    this.startFadeIn(this.fadeSpeed(), false);
  };
  Scene_Rebus.prototype.terminate = function () {
    document.removeEventListener('keydown', this._onKey);
    Scene_Base.prototype.terminate.call(this);
  };
  /** letters and Backspace/Escape go into a queue the update reads; MZ's Input maps X and Z, so it is never read here */
  Scene_Rebus.prototype.onKey = function (e) {
    var k = e.keyCode;
    if ((k >= 65 && k <= 90) || k === 8 || k === 27) { this._keys.push(k); e.preventDefault(); }
  };

  /* ----------------------------------------------------------------------- rounds */
  Scene_Rebus.prototype.round = function () { return this._game.rounds[this._game.index]; };
  Scene_Rebus.prototype.startRound = function () {
    var C = deps().core, r = this.round();
    var size = Math.min(18, Math.max(12, r.answer.letters + 6));
    this._st = C.newRound(this._game.run, { id: r.id, answer: r.answer }, { traySize: size });
    this._frames = 0; this._solvedAt = -1; this._stepKey = -1;
    this._images = {};
    for (var i = 0; i < r.pictures.length; i++) {
      var p = r.pictures[i];
      if (p.kind === 'icon') this._images.icon = ImageManager.loadSystem('IconSet');
      else if (p.kind === 'battler') this._images['b' + i] = $gameSystem.isSideView() ? ImageManager.loadSvEnemy(p.image) : ImageManager.loadEnemy(p.image);
      else if (p.kind === 'face') this._images['f' + i] = ImageManager.loadFace(p.image);
    }
    this._dirtyBack = this._dirtyPic = this._dirtyPlay = true;
  };
  Scene_Rebus.prototype.imagesReady = function () {
    for (var k in this._images) {
      var b = this._images[k];
      // a file that does not exist: RPG Maker's own "Failed to load" screen names it, exactly as a battle or a scene
      // would (ImageManager.isReady, rmmz_managers.js:992), instead of a round that waits forever
      if (b.isError()) ImageManager.throwLoadError(b);
      if (!b.isReady()) return false;
    }
    return true;
  };
  /**
   * The drawable behind a loaded Bitmap, read the way MZ's own Bitmap.blt reads it (`source._canvas || source._image`,
   * rmmz_core.js:1502). Never `bitmap.canvas`: that getter (rmmz_core.js:1750) builds a canvas COPY of the image and
   * swaps the bitmap's texture onto it, so it would mutate the engine's cached IconSet, faces and battlers that the
   * buyer's menus and battles share; and on a bitmap still loading it builds a 0 x 0 canvas and keeps it for good.
   */
  function drawable(bitmap) { return bitmap._canvas || bitmap._image; }
  /** the source rect of picture i: an icon cell, a face cell, or the whole battler */
  Scene_Rebus.prototype.sourceOf = function (i) {
    var p = this.round().pictures[i];
    if (p.kind === 'icon') { var iw = ImageManager.iconWidth, ih = ImageManager.iconHeight; return { img: drawable(this._images.icon), x: (p.iconIndex % 16) * iw, y: Math.floor(p.iconIndex / 16) * ih, w: iw, h: ih }; }
    if (p.kind === 'face') { var fw = ImageManager.faceWidth, fh = ImageManager.faceHeight, b = this._images['f' + i]; return { img: drawable(b), x: (p.index % 4) * fw, y: Math.floor(p.index / 4) * fh, w: fw, h: fh }; }
    var bb = this._images['b' + i]; return { img: drawable(bb), x: 0, y: 0, w: bb.width, h: bb.height };
  };

  /* ----------------------------------------------------------------------- update: input and time, no allocation */
  Scene_Rebus.prototype.update = function () {
    Scene_Base.prototype.update.call(this);
    if (!this._st || !this.imagesReady()) return;
    this._frames++;
    if (this._solvedAt >= 0) {
      // the next round's pictures are still LOADING when nextRound returns, so nothing may bake in this frame: the
      // imagesReady() guard above holds the next one (found 2026-10-10 by _probe/upload_census.js: baking here read a
      // loading battler and MZ caught the throw, so round 2 of a mixed game drew no picture at all)
      if (this._frames - this._solvedAt > 100 || TouchInput.isTriggered()) { this.nextRound(); return; }
      this.refresh();
      return;
    }
    this.readKeys();
    // Escape (or the last round's end) inside readKeys has already finished the game and cleared the round: nothing more
    // may run this frame (found 2026-10-10 by _probe/breakit.js: refresh() read the cleared round and MZ caught the throw)
    if (!this._st) return;
    if (TouchInput.isTriggered()) this.onClick(TouchInput.x, TouchInput.y);
    if (!this._st) return;
    this.refresh();
  };
  Scene_Rebus.prototype.readKeys = function () {
    var C = deps().core;
    while (this._keyHead < this._keys.length) {
      var k = this._keys[this._keyHead++];
      if (k === 27) { this.finish(); return; }
      if (k === 8) { for (var s = this._st.slots.length - 1; s >= 0; s--) if (C.remove(this._st, s)) { this._dirtyPlay = true; break; } continue; }
      var ch = String.fromCharCode(k);
      for (var i = 0; i < this._st.tray.length; i++) { var t = this._st.tray[i]; if (!t.used && !t.removed && t.ch === ch) { this.placeTile(i); break; } }
    }
    this._keys.length = 0; this._keyHead = 0;
  };
  Scene_Rebus.prototype.onClick = function (x, y) {
    var C = deps().core, i;
    for (i = 0; i < this._trayRects.length; i++) { var a = this._trayRects[i]; if (a && x >= a.x && x < a.x + a.w && y >= a.y && y < a.y + a.h) { this.placeTile(i); return; } }
    for (i = 0; i < this._slotRects.length; i++) { var b = this._slotRects[i]; if (x >= b.x && x < b.x + b.w && y >= b.y && y < b.y + b.h) { if (C.remove(this._st, i)) this._dirtyPlay = true; return; } }
    for (i = 0; i < 2; i++) { var h = this._hintRects[i]; if (x >= h.x && x < h.x + h.w && y >= h.y && y < h.y + h.h) { this.useHint(i); return; } }
  };
  Scene_Rebus.prototype.placeTile = function (i) {
    var C = deps().core;
    if (C.place(this._st, i) < 0) return;
    this._dirtyPlay = true;
    if (C.isSolved(this._st)) this.onSolved();
  };
  Scene_Rebus.prototype.useHint = function (which) {
    var C = deps().core, g = this._game;
    if (g.gold > 0 && $gameParty.gold() < g.gold) { SoundManager.playBuzzer(); return; }
    var done = which === 0 ? C.revealLetter(this._st) : C.clearDecoys(this._st);
    if (!done) { SoundManager.playBuzzer(); return; }
    if (g.gold > 0) $gameParty.loseGold(g.gold);
    this._dirtyPlay = true;
    if (C.isSolved(this._st)) this.onSolved();
  };
  Scene_Rebus.prototype.onSolved = function () {
    var C = deps().core, r = this.round(), g = this._game;
    var pts = C.score({ letters: r.answer.letters, hints: this._st.hints, seconds: this._frames / 60, par: g.seconds });
    g.total += pts; g.solved++;
    this._solvedAt = this._frames; this._dirtyPic = this._dirtyPlay = true;
    SoundManager.playOk();
  };
  Scene_Rebus.prototype.nextRound = function () {
    var g = this._game;
    if (g.index + 1 >= g.rounds.length) { this.finish(); return; }
    g.index++; this.startRound();
  };
  /** results to the buyer's variables and switch, then back to the map */
  Scene_Rebus.prototype.finish = function () {
    var g = this._game;
    if (g.scoreVar > 0) $gameVariables.setValue(g.scoreVar, g.total);
    if (g.solvedVar > 0) $gameVariables.setValue(g.solvedVar, g.solved);
    if (g.allSwitch > 0) $gameSwitches.setValue(g.allSwitch, g.solved === g.rounds.length);
    this._st = null;
    this.popScene();
  };

  /* ----------------------------------------------------------------------- baking */
  /** the reveal step for timed modes: re-bake the picture layer only when the step changes */
  Scene_Rebus.prototype.stepKey = function () {
    var C = deps().core, r = this.round(), t = this._solvedAt >= 0 ? this._game.seconds : this._frames / 60;
    if (r.show === 'closeup') return Math.round(C.closeupZoom(t, this._game.seconds) * 20);
    if (r.show === 'mosaic') return C.mosaicBlock(t, this._game.seconds);
    return this._solvedAt >= 0 ? 1 : 0;
  };
  Scene_Rebus.prototype.refresh = function () {
    var key = this.stepKey();
    if (key !== this._stepKey) { this._stepKey = key; this._dirtyPic = true; }
    if (this._dirtyBack) { this.bakeBack(); this._dirtyBack = false; }
    // a picture still loading would bake blank and never repaint, so the flag waits for the images (second guard behind
    // update()'s own imagesReady() check)
    if (this._dirtyPic && this.imagesReady()) { this.bakePic(); this._dirtyPic = false; }
    if (this._dirtyPlay) { this.bakePlay(); this._dirtyPlay = false; }
  };
  Scene_Rebus.prototype.bakeBack = function () {
    var D = deps().draw, L = this._layout, b = this._back.bitmap, ctx = b.context, r = this.round();
    b.clear();
    if (r.show === 'four') this._inner = D.drawBoard(ctx, L.W, L.H, L.pic, 3);
    else { D.drawTable(ctx, L.W, L.H, 3); if (r.show === 'silhouette') this._stand = D.drawStage(ctx, L.pic, 5); }
    b._baseTexture.update();
  };
  Scene_Rebus.prototype.bakePic = function () {
    var C = deps().core, D = deps().draw, L = this._layout, b = this._pic.bitmap, ctx = b.context, r = this.round(), self = this;
    var solved = this._solvedAt >= 0, back = ['#5d7a8c', '#22323d'];
    b.clear();
    if (r.show === 'four') {
      var mats = D.layoutMats(this._inner, r.pictures.length, 4 / 3, 14);
      mats.forEach(function (M, k) {
        var s = self.sourceOf(k);
        D.drawMat(ctx, M.cx, M.cy, M.w, M.h, k + 1, function (c2, x, y, w, h) {
          var bg = c2.createLinearGradient(x, y, x, y + h); bg.addColorStop(0, '#6f8f58'); bg.addColorStop(1, '#4b6a3c'); c2.fillStyle = bg; c2.fillRect(x, y, w, h);
          // an icon fills its cell, so the cell may fill the photo (0.98): 3x on a 2 x 2 board, not 2x
          var f = D.subjectScale(s, w, h, 0.98), dw = Math.round(s.w * f.z), dh = Math.round(s.h * f.z);
          c2.imageSmoothingEnabled = f.smooth && !PIXEL_ART; c2.drawImage(s.img, s.x, s.y, s.w, s.h, Math.round(x + (w - dw) / 2), Math.round(y + (h - dh) / 2), dw, dh);
        });
      });
    } else {
      var s0 = this.sourceOf(0), t = solved ? this._game.seconds : this._frames / 60;
      if (r.show === 'silhouette') {
        var st = this._stand, fit = D.subjectScale(s0, st.maxW, st.maxH, 1), dw = Math.round(s0.w * fit.z), dh = Math.round(s0.h * fit.z);
        D.drawSilhouette(ctx, s0.img, s0.x, s0.y, s0.w, s0.h, st.cx - dw / 2, st.floorY - dh, dw, dh, solved ? 1 : 0, fit.smooth && !PIXEL_ART);
      } else if (r.show === 'closeup') {
        var rad = Math.round(L.pic.h * 0.46);
        D.drawLens(ctx, L.W / 2, L.pic.y + L.pic.h / 2, rad, s0.img, s0.x, s0.y, s0.w, s0.h, C.closeupZoom(t, this._game.seconds), 0.62, 0.32, back, s0.w > 96 && !PIXEL_ART, r.pictures[0].kind !== 'battler');
      } else {
        var mw = Math.round(L.pic.h * 0.92), mx = Math.round(L.W / 2 - mw / 2), my = Math.round(L.pic.y + (L.pic.h - mw) / 2);
        D.drawMat(ctx, L.W / 2, my + mw / 2, mw + 28, mw + 28, 2, function (c2, x, y, w, h) { D.drawMosaic(c2, x, y, w, h, s0.img, s0.x, s0.y, s0.w, s0.h, C.mosaicBlock(t, self._game.seconds), back, PIXEL_ART); });
      }
    }
    if (solved) D.drawStamp(ctx, L.pic.x + L.pic.w * 0.8, L.pic.y + L.pic.h * 0.62, Math.round(L.pic.h * 0.2), SOLVED_WORD, this._game.index + 7);
    b._baseTexture.update();
  };
  Scene_Rebus.prototype.bakePlay = function () {
    var C = deps().core, D = deps().draw, L = this._layout, b = this._play.bitmap, ctx = b.context, st = this._st, r = this.round(), g = this._game;
    b.clear();
    // the rail: cell size from the answer's length and the frame width
    var cells = r.answer.cells, n = cells.length, s = Math.min(54, Math.floor((L.W - 80) / (n * 1.19))), gap = Math.round(s * 0.19);
    var rw = n * s + (n - 1) * gap, rx = Math.round((L.W - rw) / 2), ry = L.railY;
    var rail = ctx.createLinearGradient(0, ry - 14, 0, ry + s + 14); rail.addColorStop(0, '#7a5232'); rail.addColorStop(1, '#3e2716');
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.fillRect(rx - 26, ry - 10, rw + 52, s + 28); ctx.fillStyle = rail; ctx.fillRect(rx - 30, ry - 14, rw + 60, s + 28);
    this._slotRects.length = 0;
    var li = 0;
    for (var i = 0; i < n; i++) {
      var x = rx + i * (s + gap), cell = cells[i];
      if (cell.kind === 'gap') continue;
      if (cell.kind === 'fixed') { D.drawFixed(ctx, x, ry, s, cell.ch, [92, 60, 34]); continue; }
      var slot = st.slots[li];
      if (slot === null) D.drawSlot(ctx, x, ry, s, { next: this._solvedAt < 0 && li === this.firstEmpty() });
      else D.drawTile(ctx, x, ry, s, st.tray[slot].ch, MATERIAL, { seed: li });
      this._slotRects.push({ x: x, y: ry, w: s, h: s });
      li++;
    }
    // the tray: two rows, centred
    var per = Math.ceil(st.tray.length / 2), ts = Math.min(50, Math.floor((L.W - 120) / (per * 1.24))), tg = Math.round(ts * 0.24);
    var tw = per * ts + (per - 1) * tg, tx = Math.round((L.W - tw) / 2);
    this._trayRects.length = 0;
    for (var k = 0; k < st.tray.length; k++) {
      // an odd tray leaves the second row one tile short: it is centred under the first (LOOKED AT 2026-10-10: left
      // aligned it read as a missing tile at the right end)
      var row = Math.floor(k / per), inRow = row === 0 ? per : st.tray.length - per, off = Math.round(((per - inRow) * (ts + tg)) / 2);
      var t = st.tray[k], x2 = tx + off + (k % per) * (ts + tg), y2 = L.trayY + row * (ts + tg);
      if (t.used || t.removed) { D.drawSlot(ctx, x2, y2, ts, {}); this._trayRects.push(null); }
      else { D.drawTile(ctx, x2, y2, ts, t.ch, MATERIAL, { seed: k }); this._trayRects.push({ x: x2, y: y2, w: ts, h: ts }); }
    }
    // the strip: the round plaque left, the two hints right
    var sy = L.stripY;
    D.drawPlaque(ctx, 18, sy - 10, 200, 52, ROUND_LABEL.replace('%1', g.index + 1).replace('%2', g.rounds.length), String(g.total));
    var hw = 160, hh = 38, hx = L.W - 18 - hw * 2 - 10;
    var spentClear = !this.anyDecoyLeft();
    this._hintRects[0].x = hx; this._hintRects[0].y = sy - 4; this._hintRects[0].w = hw; this._hintRects[0].h = hh;
    this._hintRects[1].x = hx + hw + 10; this._hintRects[1].y = sy - 4; this._hintRects[1].w = hw; this._hintRects[1].h = hh;
    // the cost shown is the GOLD it takes, with a coin; when hints are free in gold, the 40 points it costs, without one
    var cost = g.gold > 0 ? String(g.gold) : '-40', coinOn = g.gold > 0;
    D.drawHintButton(ctx, hx, sy - 4, hw, hh, HINT_LETTER, cost, this._solvedAt >= 0 ? 'spent' : 'idle', coinOn);
    D.drawHintButton(ctx, hx + hw + 10, sy - 4, hw, hh, HINT_CLEAR, cost, spentClear || this._solvedAt >= 0 ? 'spent' : 'idle', coinOn);
    b._baseTexture.update();
  };
  Scene_Rebus.prototype.firstEmpty = function () { for (var s = 0; s < this._st.slots.length; s++) if (this._st.slots[s] === null) return s; return -1; };
  Scene_Rebus.prototype.anyDecoyLeft = function () { for (var i = 0; i < this._st.tray.length; i++) { var t = this._st.tray[i]; if (t.decoy && !t.used && !t.removed) return true; } return false; };

  window.Scene_Rebus = Scene_Rebus;
})();
