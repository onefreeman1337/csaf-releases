/*:
 * @target MZ
 * @plugindesc Rebus 1/3 - the rules: rounds harvested from your database, the letter tray, hints and scoring. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * RebusCore.js - part of Rebus v1.0.0. Enable it with RebusDraw.js and Rebus.js (any order). It has no commands or
 * parameters of its own; Rebus.js reads it.
 *
 * Every line of this plugin was written with AI assistance.
 */
/*
 * The rules of a picture word puzzle, pure JavaScript with no engine calls, so they run headless in Node exactly as they
 * run in MZ. A round's state is plain JSON (no functions; the RNG state is a number on the run), so a game saved in the
 * middle of a round resumes exactly. Never Math.random: a seeded generator whose state lives on the run.
 */
var RebusCore = (function () {
  'use strict';

  /* ------------------------------------------------------------ seeded randomness */
  /** Mix two 32-bit values into a new seed. */
  function mix(a, b) { var h = Math.imul((a >>> 0) ^ 0x9e3779b9, 0x85ebca6b) ^ (b >>> 0); h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35); return (h ^ (h >>> 16)) >>> 0; }
  /**
   * mulberry32 with its state ON THE RUN (run.rs), so saving the run saves the generator.
   * @param {{rs:number}} run
   * @returns {number} in [0, 1)
   */
  function rand(run) {
    var t = run.rs = (run.rs + 0x6D2B79F5) | 0;
    t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  /**
   * Fisher-Yates on a copy. The RNG is never drawn inside a sort comparator (the draw count would be the engine's sort,
   * wing §3), so the same seed gives the same order in Node and in MZ.
   * @param {{rs:number}} run
   * @param {Array} list
   * @returns {Array}
   */
  function shuffle(run, list) {
    var a = list.slice();
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rand(run) * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }

  /* ------------------------------------------------------------ answers */
  var MIN_LETTERS = 3, MAX_LETTERS = 12;
  /**
   * A name as the player will spell it. Upper-case A-Z letters become tile cells; a space or underscore becomes one fixed
   * GAP cell; an apostrophe or hyphen becomes a fixed cell that is shown, never a tile. Anything else (an accent, kana, a
   * digit) returns null: v1 spells Latin letters only, and a name it cannot spell is skipped, never mangled.
   * @param {string} text
   * @returns {{display:string, cells:Array<{kind:string, ch:string}>, letters:number}|null}
   */
  function normalAnswer(text) {
    if (typeof text !== 'string') return null;
    var t = text.replace(/_/g, ' ').replace(/\s+/g, ' ').trim().toUpperCase();
    if (!t || !/^[A-Z' -]+$/.test(t)) return null;
    var cells = [], n = 0;
    for (var i = 0; i < t.length; i++) {
      var ch = t.charAt(i);
      if (ch === ' ') cells.push({ kind: 'gap', ch: ' ' });
      else if (ch === "'" || ch === '-') cells.push({ kind: 'fixed', ch: ch });
      else { cells.push({ kind: 'letter', ch: ch }); n++; }
    }
    if (n < MIN_LETTERS || n > MAX_LETTERS) return null;
    return { display: t, cells: cells, letters: n };
  }
  /** the letters of an answer, in order, as a string */
  function lettersOf(answer) { var s = ''; for (var i = 0; i < answer.cells.length; i++) if (answer.cells[i].kind === 'letter') s += answer.cells[i].ch; return s; }

  /* ------------------------------------------------------------ the harvest */
  var NOTE = /<Rebus:\s*([^>]+)>/i;
  /** a record's notetag: 'skip', an override word, or null */
  function noteOf(r) { var m = NOTE.exec((r && r.note) || ''); return m ? m[1].trim() : null; }
  var GROUP_NOTE = /<Rebus Group:\s*([^>]+)>/i;
  /** a record's own group word (<Rebus Group: Mushroom>), or null */
  function groupNoteOf(r) { var m = GROUP_NOTE.exec((r && r.note) || ''); return m ? m[1].trim() : null; }
  var ITEM_KINDS = ['', 'Item', 'Key Item', '', ''];   // hidden items (3, 4) have no name a player knows: never asked

  /**
   * Every round the database offers.
   * FOUR PICTURES: groups the database itself names - weapons by weapon type, armours by armour type and by equip slot,
   * skills by element and by skill type, items by kind. A group is asked when at least four of its records have art (an
   * icon) and the group's name is spellable; four members are picked by the seed; a word two groups share is asked once.
   * SILHOUETTE: every enemy with a battler and every actor with a face, its name (or a <Rebus: word> notetag) the answer.
   * <Rebus: skip> on any record leaves it out.
   * @param {{system:Object, weapons:Array, armors:Array, skills:Array, items:Array, enemies:Array, actors:Array}} db
   * @param {{seed?:number}} [opts]
   * @returns {Array<{id:string, mode:string, answer:Object, pictures:Array}>}
   */
  function harvest(db, opts) {
    var run = { rs: mix((opts && opts.seed) | 0, 0x5eb05) };
    var sys = db.system || {};
    var out = [], seen = {};
    var groupBy = function (source, rows, keyOf, wordOf) {
      var groups = {}, order = [];
      for (var i = 0; i < (rows || []).length; i++) {
        var r = rows[i];
        if (!r || !r.name || !(r.iconIndex > 0) || noteOf(r) === 'skip') continue;
        var k = keyOf(r);
        if (typeof k === 'string' ? !k : !(k > 0)) continue;
        if (!groups[k]) { groups[k] = []; order.push(k); }
        groups[k].push({ kind: 'icon', source: source, id: r.id, iconIndex: r.iconIndex, name: r.name });
      }
      for (var j = 0; j < order.length; j++) {
        var key = order[j], members = groups[key];
        var answer = normalAnswer(wordOf(key) || '');
        if (!answer || seen[answer.display]) continue;
        seen[answer.display] = true;
        // one picture per DIFFERENT icon (2026-10-10, found in engine: the stock FIRE skills share one icon and a round of
        // four records showed one picture four times). Two to four different icons make a picture round; a group whose
        // records all share one icon is a single-picture round (silhouette, close-up, mosaic)
        var mixed = shuffle(run, members), pics = [], icons = {};
        for (var q = 0; q < mixed.length && pics.length < 4; q++) if (!icons[mixed[q].iconIndex]) { icons[mixed[q].iconIndex] = true; pics.push(mixed[q]); }
        if (pics.length >= 2) out.push({ id: 'four:' + source + ':' + key, mode: 'four', answer: answer, pictures: pics });
        else out.push({ id: 'icon:' + source + ':' + key, mode: 'silhouette', answer: answer, pictures: pics });
      }
    };
    // the buyer's OWN groups first: <Rebus Group: Mushroom> on any item, weapon, armour or skill puts it in a round whose
    // answer is that word, so icons the database never typed together can still share a round (and a word the buyer chose
    // outranks the same word arriving from a database type)
    var tagged = [];
    [db.items, db.weapons, db.armors, db.skills].forEach(function (rows) {
      for (var i = 0; i < (rows || []).length; i++) if (rows[i] && groupNoteOf(rows[i])) tagged.push(rows[i]);
    });
    if (tagged.length) {
      var words = {};
      groupBy('tagged', tagged, function (r) {
        var w = groupNoteOf(r), key = w.toUpperCase(); words[key] = w; return key;
      }, function (k) { return words[k]; });
    }
    groupBy('weapons', db.weapons, function (r) { return r.wtypeId; }, function (k) { return (sys.weaponTypes || [])[k]; });
    groupBy('armors', db.armors, function (r) { return r.atypeId; }, function (k) { return (sys.armorTypes || [])[k]; });
    groupBy('armors', db.armors, function (r) { return r.etypeId; }, function (k) { return (sys.equipTypes || [])[k]; });
    groupBy('skills', db.skills, function (r) { return r.damage ? r.damage.elementId : 0; }, function (k) { return (sys.elements || [])[k]; });
    groupBy('skills', db.skills, function (r) { return r.stypeId; }, function (k) { return (sys.skillTypes || [])[k]; });
    groupBy('items', db.items, function (r) { return r.itypeId; }, function (k) { return ITEM_KINDS[k]; });
    var single = function (source, rows, kind, imageOf) {
      for (var i = 0; i < (rows || []).length; i++) {
        var r = rows[i];
        if (!r || !r.name) continue;
        var note = noteOf(r);
        if (note === 'skip') continue;
        var pic = imageOf(r);
        if (!pic) continue;
        var answer = normalAnswer(note || r.name);
        if (!answer || seen[answer.display]) continue;
        seen[answer.display] = true;
        pic.kind = kind; pic.source = source; pic.id = r.id; pic.name = r.name;
        out.push({ id: 'silhouette:' + source + ':' + r.id, mode: 'silhouette', answer: answer, pictures: [pic] });
      }
    };
    single('enemies', db.enemies, 'battler', function (r) { return r.battlerName ? { image: r.battlerName, hue: r.battlerHue | 0 } : null; });
    single('actors', db.actors, 'face', function (r) { return r.faceName ? { image: r.faceName, index: r.faceIndex | 0 } : null; });
    return out;
  }

  /* ------------------------------------------------------------ the tray */
  // English letter frequencies (per 1,000 letters), so decoys look like plausible letters, not noise
  var FREQ = 'EEEEEEEEEEEETTTTTTTTTAAAAAAAAOOOOOOOOIIIIIIINNNNNNNSSSSSSHHHHHHRRRRRRDDDDLLLLCCCUUUMMMWWFFGGYYPPBBVKJXQZ';
  var ALPHA = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  /**
   * The tiles for an answer: every answer letter once per time the answer uses it, plus decoys up to the tray size,
   * shuffled. Each tile: { ch, decoy, used, removed }. A decoy is drawn by English letter frequency, but a letter may
   * hold only ONE decoy: one copy of a letter the answer lacks, one spare copy of a letter it uses (LOOKED AT 2026-10-10:
   * drawn with replacement, a STAG tray held four S and the sweep in core.test found six E). A rejected draw is redrawn;
   * after 64 rejections the first free letter in the alphabet is taken, so the loop always ends. There are 26 letters, so
   * at most 26 decoys.
   * @param {{rs:number}} run
   * @param {{cells:Array}} answer
   * @param {number} size
   * @returns {Array<{ch:string, decoy:boolean, used:boolean, removed:boolean}>}
   */
  function makeTray(run, answer, size) {
    var letters = lettersOf(answer), tiles = [], taken = {};
    for (var i = 0; i < letters.length; i++) tiles.push({ ch: letters.charAt(i), decoy: false, used: false, removed: false });
    var n = Math.min(26, Math.max(0, (size | 0) - letters.length));
    for (var d = 0; d < n; d++) {
      var ch = '', tries = 0;
      do { ch = FREQ.charAt(Math.floor(rand(run) * FREQ.length)); tries++; } while (taken[ch] && tries < 64);
      if (taken[ch]) for (var a = 0; a < ALPHA.length; a++) if (!taken[ALPHA.charAt(a)]) { ch = ALPHA.charAt(a); break; }
      taken[ch] = true;
      tiles.push({ ch: ch, decoy: true, used: false, removed: false });
    }
    return shuffle(run, tiles);
  }

  /* ------------------------------------------------------------ playing a round */
  /**
   * A round in play: one slot per answer letter (gaps and fixed cells are drawn, never filled), the tray, hints spent.
   * @param {{rs:number}} run
   * @param {{answer:Object}} round
   * @param {{traySize?:number}} [opts]
   */
  function newRound(run, round, opts) {
    var n = round.answer.letters, slots = [], locked = [];
    for (var i = 0; i < n; i++) { slots.push(null); locked.push(false); }
    return { id: round.id, letters: lettersOf(round.answer), slots: slots, locked: locked, tray: makeTray(run, round.answer, (opts && opts.traySize) || 12), hints: 0 };
  }
  /** Put tray tile i into the first empty slot. Returns the slot, or -1. */
  function place(st, i) {
    var t = st.tray[i];
    if (!t || t.used || t.removed) return -1;
    for (var s = 0; s < st.slots.length; s++) if (st.slots[s] === null) { st.slots[s] = i; t.used = true; return s; }
    return -1;
  }
  /** Take the tile out of slot s (a locked hint letter stays). */
  function remove(st, s) {
    if (st.locked[s] || st.slots[s] === null || st.slots[s] === undefined) return false;
    st.tray[st.slots[s]].used = false; st.slots[s] = null; return true;
  }
  function filled(st) { var n = 0; for (var s = 0; s < st.slots.length; s++) if (st.slots[s] !== null) n++; return n; }
  function wrongCells(st) { var w = []; for (var s = 0; s < st.slots.length; s++) if (st.slots[s] !== null && st.tray[st.slots[s]].ch !== st.letters.charAt(s)) w.push(s); return w; }
  function isSolved(st) { return filled(st) === st.slots.length && wrongCells(st).length === 0; }
  /**
   * Hint: lock the correct letter into the first cell that is empty or wrong (a tile wrongly in it goes back to the tray;
   * if the right tile sits wrongly in another cell, it moves). Returns { slot } or null when nothing is left to reveal.
   */
  function revealLetter(st) {
    for (var s = 0; s < st.slots.length; s++) {
      if (st.locked[s]) continue;
      var want = st.letters.charAt(s);
      if (st.slots[s] !== null && st.tray[st.slots[s]].ch === want) continue;
      if (st.slots[s] !== null) remove(st, s);
      var pick = -1;
      for (var pass = 0; pass < 2 && pick < 0; pass++) {
        for (var i = 0; i < st.tray.length; i++) {
          var t = st.tray[i];
          if (t.used || t.removed || t.ch !== want || (pass === 0 && t.decoy)) continue;
          pick = i; break;
        }
      }
      if (pick < 0) {
        for (var o = 0; o < st.slots.length && pick < 0; o++) {
          if (o === s || st.locked[o] || st.slots[o] === null) continue;
          if (st.tray[st.slots[o]].ch === want) { pick = st.slots[o]; remove(st, o); }
        }
      }
      if (pick < 0) return null;
      st.slots[s] = pick; st.tray[pick].used = true; st.locked[s] = true; st.hints++;
      return { slot: s };
    }
    return null;
  }
  /** Hint: take every decoy still in the tray away. Returns { removed } or null (nothing to clear costs nothing). */
  function clearDecoys(st) {
    var n = 0;
    for (var i = 0; i < st.tray.length; i++) { var t = st.tray[i]; if (t.decoy && !t.used && !t.removed) { t.removed = true; n++; } }
    if (!n) return null;
    st.hints++;
    return { removed: n };
  }
  /**
   * Points for a solved round: 100 plus 10 a letter, minus 40 a hint, minus 2 a second over par; never below zero.
   * @param {{letters:number, hints:number, seconds:number, par:number}} r
   */
  function score(r) { return Math.max(0, Math.round(100 + 10 * r.letters - 40 * r.hints - 2 * Math.max(0, r.seconds - r.par))); }

  /* ------------------------------------------------------------ the clue schedules (pure functions of time) */
  /**
   * Close-up: the zoom on the picture's subject, 4x at the start easing out to 1x at T seconds. 4x, not 6x: at 6x the
   * lens showed about a fifth of a face's span and read as a blur (LOOKED AT in engine 2026-10-10).
   */
  var CLOSEUP_START = 4;
  function closeupZoom(t, T) { var p = Math.max(0, Math.min(1, T > 0 ? t / T : 1)); var e = 1 - (1 - p) * (1 - p); return CLOSEUP_START - (CLOSEUP_START - 1) * e; }
  var MOSAIC = [32, 24, 16, 12, 8, 6, 4, 2, 1];
  /** Mosaic: the block size in pixels, stepping from 32 down to 1 over T seconds. */
  function mosaicBlock(t, T) { var p = Math.max(0, Math.min(1, T > 0 ? t / T : 1)); return MOSAIC[Math.min(MOSAIC.length - 1, Math.floor(p * (MOSAIC.length - 1) + 1e-9))]; }
  /** Silhouette: a pixel is part of the figure at this alpha or above (to be confirmed on a contact sheet, wing §21b). */
  var SILHOUETTE_ALPHA = 96;

  return {
    VERSION: '1.0.0', rand: rand, mix: mix, shuffle: shuffle, normalAnswer: normalAnswer, lettersOf: lettersOf,
    harvest: harvest, makeTray: makeTray, newRound: newRound, place: place, remove: remove, filled: filled,
    wrongCells: wrongCells, isSolved: isSolved, revealLetter: revealLetter, clearDecoys: clearDecoys, score: score,
    closeupZoom: closeupZoom, mosaicBlock: mosaicBlock, SILHOUETTE_ALPHA: SILHOUETTE_ALPHA,
  };
})();
if (typeof module === 'object' && module.exports) module.exports = RebusCore;
