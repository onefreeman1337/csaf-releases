/*:
 * @target MZ
 * @plugindesc Rebus 2/3 - the drawing: letter tiles in four materials, slots, the board and the stage. Canvas only.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * RebusDraw.js - part of Rebus v1.0.0. Enable it with RebusCore.js and Rebus.js (any order). It has no commands or
 * parameters of its own; Rebus.js reads it.
 *
 * Every line of this plugin was written with AI assistance.
 */
/*
 * Every object in the scene is drawn here on a 2D canvas context (an MZ Bitmap's context in the game, an HTML canvas in
 * the preview page), baked once per scene and never redrawn per frame. Nothing reads the engine. Textures come from a
 * seeded hash, never Math.random, so a tile looks the same every time it is drawn.
 */
var RebusDraw = (function () {
  'use strict';

  /* ------------------------------------------------------------ colour helpers */
  function hex(c) { return '#' + c.map(function (v) { var s = Math.max(0, Math.min(255, Math.round(v))).toString(16); return s.length < 2 ? '0' + s : s; }).join(''); }
  function luma(c) { return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; }
  /** move a colour toward white (d > 0) or black (d < 0) by an ABSOLUTE amount of luma, clamped (Icon_Doctrine §22e-1) */
  function relief(c, d) {
    if (d >= 0) { var head = 255 - Math.max(c[0], c[1], c[2]); var k = Math.min(d, head); return [c[0] + k, c[1] + k, c[2] + k]; }
    var floor = Math.min(c[0], c[1], c[2]); var k2 = Math.min(-d, floor); return [c[0] - k2, c[1] - k2, c[2] - k2];
  }
  function hash(x, y, s) { var h = Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263) ^ Math.imul(s | 0, 2147483647); h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; }

  /* ------------------------------------------------------------ the four materials */
  // base = the face colour; grain = what the surface texture draws; the INK (the carved letter) is not chosen here: it is
  // solved per material against the face by luminance (Icon_Doctrine §22e), see inkFor()
  var MATERIALS = {
    wood:  { base: [166, 112, 64], grain: 'wood' },
    brass: { base: [196, 160, 78], grain: 'metal' },
    ivory: { base: [232, 222, 196], grain: 'ivory' },
    slate: { base: [70, 78, 88], grain: 'stone' },
  };
  /** the carved letter's colour: a deep-brown cut or a gilded cut, whichever stands FURTHER from the face in luminance
   *  (Icon_Doctrine §22e: picked by measurement against what it sits on, never hard-coded per material). The first rule
   *  (darken the face by a fixed 110) left brass with a gold-on-gold cut at 44 luma, LOOKED AT 2026-10-10. */
  var CUT_DARK = [40, 26, 16], CUT_GILT = [244, 216, 132];
  function inkFor(base) {
    var l = luma(base);
    return Math.abs(l - luma(CUT_DARK)) >= Math.abs(l - luma(CUT_GILT)) ? CUT_DARK : CUT_GILT;
  }

  /** a rounded-rectangle path */
  function rr(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }

  /** the surface texture inside the face, clipped by the caller */
  function texture(ctx, m, x, y, s, seed) {
    var b = m.base;
    if (m.grain === 'wood') {
      // long grain lines running the tile's width, each its own tone, gently waved
      for (var i = 0; i < 9; i++) {
        var gy = y + s * (0.08 + i * 0.105) + (hash(i, 1, seed) - 0.5) * s * 0.04;
        ctx.strokeStyle = hex(relief(b, hash(i, 2, seed) < 0.5 ? -22 : 14));
        ctx.lineWidth = Math.max(1, s * (0.012 + hash(i, 3, seed) * 0.012));
        ctx.beginPath();
        for (var k = 0; k <= 12; k++) { var px = x + (s * k) / 12, py = gy + Math.sin(k * 0.9 + seed + i) * s * 0.012; if (k) ctx.lineTo(px, py); else ctx.moveTo(px, py); }
        ctx.stroke();
      }
    } else if (m.grain === 'metal') {
      var g = ctx.createLinearGradient(x, y, x + s, y + s);
      g.addColorStop(0, hex(relief(b, 40))); g.addColorStop(0.45, hex(b)); g.addColorStop(1, hex(relief(b, -46)));
      ctx.fillStyle = g; ctx.fillRect(x, y, s, s);
      ctx.strokeStyle = 'rgba(255,255,255,0.10)'; ctx.lineWidth = 1;
      for (var j = 0; j < 14; j++) { var yy = y + (s * (j + 0.5)) / 14; ctx.beginPath(); ctx.moveTo(x, yy); ctx.lineTo(x + s, yy); ctx.stroke(); }
    } else if (m.grain === 'ivory') {
      var gi = ctx.createRadialGradient(x + s * 0.35, y + s * 0.3, s * 0.05, x + s * 0.5, y + s * 0.5, s * 0.75);
      gi.addColorStop(0, hex(relief(b, 16))); gi.addColorStop(1, hex(relief(b, -26)));
      ctx.fillStyle = gi; ctx.fillRect(x, y, s, s);
    } else {
      for (var n = 0; n < 60; n++) { ctx.fillStyle = hex(relief(b, hash(n, 4, seed) < 0.5 ? -16 : 18)); var sx = x + hash(n, 5, seed) * s, sy = y + hash(n, 6, seed) * s, ss = Math.max(1, s * 0.03); ctx.fillRect(Math.round(sx), Math.round(sy), ss, ss); }
    }
  }

  var SCRATCH = null;
  /** a scratch canvas reused for every carve (tiles are baked once per scene, never per frame) */
  function scratch(w, h) {
    if (!SCRATCH) SCRATCH = document.createElement('canvas');
    if (SCRATCH.width < w || SCRATCH.height < h) { SCRATCH.width = Math.max(w, SCRATCH.width); SCRATCH.height = Math.max(h, SCRATCH.height); }
    var g = SCRATCH.getContext('2d'); g.setTransform(1, 0, 0, 1, 0, 0); g.globalCompositeOperation = 'source-over'; g.clearRect(0, 0, SCRATCH.width, SCRATCH.height);
    return g;
  }
  /** draw one wall: the letter in `col`, minus the letter shifted by (dx, dy) - leaving a band only on the edges facing (-dx, -dy) */
  function wall(ctx, ch, cx, cy, s, font, col, dx, dy) {
    var w = Math.ceil(s), g = scratch(w, w);
    g.font = font; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillStyle = col; g.fillText(ch, w / 2, w / 2);
    g.globalCompositeOperation = 'destination-out'; g.fillText(ch, w / 2 + dx, w / 2 + dy);
    ctx.drawImage(SCRATCH, 0, 0, w, w, cx - w / 2, cy - w / 2, w, w);
  }
  function mixc(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }
  /**
   * An engraved letter: the floor in the ink, a shadowed upper-left wall, a lit lower-right wall. The walls are ~2.5% of
   * the tile and the lit wall on a dark cut is a MID-TONE between cut and face (LOOKED AT 2026-10-10: at 4% with a near-
   * face colour the lit wall split every stroke on brass and ivory and the letters read as stencils).
   */
  function carve(ctx, ch, cx, cy, s, font, ink, face) {
    var d = Math.max(1, Math.round(s * 0.025));
    ctx.save();
    ctx.font = font; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = hex(ink); ctx.fillText(ch, cx, cy);
    var dark = luma(ink) < luma(face);
    wall(ctx, ch, cx, cy, s, font, hex(dark ? relief(ink, -20) : relief(face, -70)), d, d);        // shadow on the upper-left inner edge
    wall(ctx, ch, cx, cy, s, font, hex(dark ? mixc(ink, face, 0.42) : relief(ink, 28)), -d, -d);   // light on the lower-right inner edge
    ctx.restore();
  }

  /**
   * One letter tile: a bevelled block of the material (lit upper-left, shadowed lower-right, a contact shadow under it),
   * a face with its texture, and the letter CARVED into it (a dark cut with a lit lower-right lip on a light material;
   * a gilded cut on slate).
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x @param {number} y @param {number} s tile size in px
   * @param {string} ch one letter A-Z
   * @param {string} matName wood | brass | ivory | slate
   * @param {{seed?:number, font?:string, state?:string}} [opt] state: 'idle' | 'used' | 'removed'
   */
  function drawTile(ctx, x, y, s, ch, matName, opt) {
    var m = MATERIALS[matName] || MATERIALS.wood;
    var seed = (opt && opt.seed) | 0;
    var r = Math.max(2, s * 0.14), bev = Math.max(2, Math.round(s * 0.07));
    ctx.save();
    // contact shadow
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; rr(ctx, x + s * 0.05, y + s * 0.08, s, s, r); ctx.fill();
    // the block: the bevel ring, light from the upper left
    var g = ctx.createLinearGradient(x, y, x + s, y + s);
    g.addColorStop(0, hex(relief(m.base, 48))); g.addColorStop(0.5, hex(m.base)); g.addColorStop(1, hex(relief(m.base, -60)));
    ctx.fillStyle = g; rr(ctx, x, y, s, s, r); ctx.fill();
    // the face
    var fx = x + bev, fy = y + bev, fs = s - 2 * bev;
    ctx.save(); rr(ctx, fx, fy, fs, fs, r * 0.6); ctx.clip();
    ctx.fillStyle = hex(m.base); ctx.fillRect(fx, fy, fs, fs);
    texture(ctx, m, fx, fy, fs, seed);
    ctx.restore();
    // the carved letter (third look, 2026-10-10: a flat fill with an offset lip read as INLAY at 2x): the cut floor in
    // the ink, then its two inner walls - the upper-left wall in shadow, the lower-right wall catching the light -
    // each the letter minus itself shifted by the wall depth, so a wall exists only along the edges that face it
    var font = (opt && opt.font) || '700 ' + Math.round(s * 0.62) + 'px "Palatino Linotype", "Book Antiqua", Palatino, Georgia, serif';
    var ink = inkFor(m.base);
    carve(ctx, ch, x + s / 2, y + s / 2 + s * 0.03, s, font, ink, m.base);
    if (opt && opt.state === 'used') { ctx.fillStyle = 'rgba(20,14,10,0.55)'; rr(ctx, x, y, s, s, r); ctx.fill(); }
    ctx.restore();
  }

  /**
   * An empty letter slot: a recess cut into the board rail, darker than the rail, lit on its lower-right inner edge, with a
   * cursor glow when it is the next slot to fill. A gap cell is not a slot (the caller leaves the space).
   */
  function drawSlot(ctx, x, y, s, opt) {
    var r = Math.max(2, s * 0.12);
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.55)'; rr(ctx, x, y, s, s, r); ctx.fill();
    var g = ctx.createLinearGradient(x, y, x + s, y + s); g.addColorStop(0, 'rgba(0,0,0,0.5)'); g.addColorStop(1, 'rgba(255,230,190,0.14)');
    ctx.strokeStyle = g; ctx.lineWidth = Math.max(1, s * 0.05); rr(ctx, x + 1, y + 1, s - 2, s - 2, r); ctx.stroke();
    if (opt && opt.next) { ctx.strokeStyle = 'rgba(255,214,140,0.85)'; ctx.lineWidth = Math.max(1.5, s * 0.05); rr(ctx, x - 2, y - 2, s + 4, s + 4, r + 2); ctx.stroke(); }
    ctx.restore();
  }
  /** a fixed cell of the answer (an apostrophe or hyphen): drawn carved into the rail, never a tile */
  function drawFixed(ctx, x, y, s, ch, rail) { carve(ctx, ch, x + s / 2, y + s / 2, s, '700 ' + Math.round(s * 0.62) + 'px "Palatino Linotype", "Book Antiqua", Palatino, Georgia, serif', inkFor(rail), rail); }
  /**
   * The table and the pin board: a dark table, a cork board in a wooden frame (lit top-left, shadowed bottom-right), cork
   * speckle from the seeded hash. Returns the board's inner rect.
   */
  /** the dark table every mode sits on: a vertical wash and long, gently waved grain */
  function drawTable(ctx, W, H, seed) {
    var t = ctx.createLinearGradient(0, 0, 0, H); t.addColorStop(0, '#3a2a1f'); t.addColorStop(1, '#1d1510'); ctx.fillStyle = t; ctx.fillRect(0, 0, W, H);
    for (var i = 0; i < 14; i++) { ctx.strokeStyle = 'rgba(0,0,0,' + (0.08 + hash(i, 9, seed) * 0.08) + ')'; ctx.lineWidth = 2; ctx.beginPath(); var yy = (H * (i + 0.5)) / 14; ctx.moveTo(0, yy); ctx.bezierCurveTo(W * 0.3, yy + 6, W * 0.6, yy - 6, W, yy + 2); ctx.stroke(); }
  }
  function drawBoard(ctx, W, H, rect, seed) {
    drawTable(ctx, W, H, seed);
    var x = rect.x, y = rect.y, w = rect.w, h = rect.h, f = Math.round(Math.min(w, h) * 0.045);
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.fillRect(x + 8, y + 10, w, h);
    var fr = ctx.createLinearGradient(x, y, x + w, y + h); fr.addColorStop(0, '#9a6a3e'); fr.addColorStop(1, '#4e321c'); ctx.fillStyle = fr; ctx.fillRect(x, y, w, h);
    var ix = x + f, iy = y + f, iw = w - 2 * f, ih = h - 2 * f;
    // the frame's bevel (first look 2026-10-10: a flat gradient): outer edge lit top-left, dark bottom-right; the inner
    // edge reversed, because the cork sits BELOW the frame
    var e = Math.max(1, Math.round(f * 0.18));
    ctx.fillStyle = 'rgba(255,226,180,0.30)'; ctx.fillRect(x, y, w, e); ctx.fillRect(x, y, e, h);
    ctx.fillStyle = 'rgba(0,0,0,0.40)'; ctx.fillRect(x, y + h - e, w, e); ctx.fillRect(x + w - e, y, e, h);
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.fillRect(ix - e, iy - e, iw + 2 * e, e); ctx.fillRect(ix - e, iy - e, e, ih + 2 * e);
    ctx.fillStyle = 'rgba(255,226,180,0.22)'; ctx.fillRect(ix - e, iy + ih, iw + 2 * e, e); ctx.fillRect(ix + iw, iy - e, e, ih + 2 * e);
    ctx.fillStyle = '#b48a5a'; ctx.fillRect(ix, iy, iw, ih);
    for (var n = 0; n < Math.round(iw * ih / 90); n++) { ctx.fillStyle = hash(n, 1, seed) < 0.5 ? 'rgba(90,58,30,0.35)' : 'rgba(230,196,150,0.30)'; ctx.fillRect(ix + Math.floor(hash(n, 2, seed) * iw), iy + Math.floor(hash(n, 3, seed) * ih), 2, 2); }
    var sh = ctx.createLinearGradient(ix, iy, ix, iy + 18); sh.addColorStop(0, 'rgba(0,0,0,0.35)'); sh.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = sh; ctx.fillRect(ix, iy, iw, 18);
    return { x: ix, y: iy, w: iw, h: ih };
  }
  /**
   * A picture pinned to the board: a cream mat with a drop shadow, slightly turned (angle from the seed), the picture
   * drawn by the caller's callback inside the mat's window, and a brass pin at the top.
   * @param {Function} paint (ctx, x, y, w, h) draws the picture into the window
   */
  function drawMat(ctx, cx, cy, w, h, seed, paint) {
    var a = (hash(seed, 7, 3) - 0.5) * 0.09;
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(a);
    ctx.fillStyle = 'rgba(0,0,0,0.38)'; ctx.fillRect(-w / 2 + 6, -h / 2 + 8, w, h);
    var m = ctx.createLinearGradient(-w / 2, -h / 2, w / 2, h / 2); m.addColorStop(0, '#f3ead6'); m.addColorStop(1, '#d9ccaf'); ctx.fillStyle = m; ctx.fillRect(-w / 2, -h / 2, w, h);
    // the photo's white border: 7.5% of the short side (at 10% a 32 px icon fitted its 2 x 2 mat at 2x and read small,
    // LOOKED AT in engine 2026-10-10; the slimmer border lets it draw at a whole 3x)
    var b = Math.round(Math.min(w, h) * 0.075);
    ctx.fillStyle = '#2a2420'; ctx.fillRect(-w / 2 + b - 1, -h / 2 + b - 1, w - 2 * b + 2, h - 2 * b + 2);
    ctx.save(); ctx.beginPath(); ctx.rect(-w / 2 + b, -h / 2 + b, w - 2 * b, h - 2 * b); ctx.clip();
    paint(ctx, -w / 2 + b, -h / 2 + b, w - 2 * b, h - 2 * b);
    ctx.restore();
    var pg = ctx.createRadialGradient(-2, -h / 2 + 2, 1, 0, -h / 2 + 4, 9); pg.addColorStop(0, '#fff2c0'); pg.addColorStop(0.4, '#c99a3c'); pg.addColorStop(1, '#5a3c12');
    ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.beginPath(); ctx.arc(3, -h / 2 + 8, 7, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = pg; ctx.beginPath(); ctx.arc(0, -h / 2 + 4, 7, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  /** one velvet curtain: vertical folds (each band shaded across its width), the inner edge drawn back by a tieback */
  function curtain(ctx, x, y, w, h, seed, right) {
    var inner = right ? x : x + w, outer = right ? x + w : x, tieY = y + h * 0.62, pull = w * 0.62;
    ctx.save();
    ctx.beginPath(); ctx.moveTo(outer, y); ctx.lineTo(inner, y);
    ctx.quadraticCurveTo(inner + (right ? pull : -pull), tieY, inner + (right ? pull * 0.55 : -pull * 0.55), tieY);
    ctx.quadraticCurveTo(inner + (right ? pull * 0.2 : -pull * 0.2), y + h * 0.85, inner, y + h);
    ctx.lineTo(outer, y + h); ctx.closePath(); ctx.clip();
    var n = 6, bw = w / n;
    for (var i = 0; i < n; i++) {
      var bx = x + i * bw, gg = ctx.createLinearGradient(bx, 0, bx + bw, 0), lit = 0.7 + hash(i, 3, seed) * 0.3;
      gg.addColorStop(0, '#2a0508'); gg.addColorStop(0.45, 'rgb(' + Math.round(150 * lit) + ',' + Math.round(22 * lit) + ',' + Math.round(34 * lit) + ')'); gg.addColorStop(1, '#3a070c');
      ctx.fillStyle = gg; ctx.fillRect(bx, y, bw + 1, h);
    }
    var sh = ctx.createLinearGradient(right ? x : x + w, 0, right ? x + w : x, 0); sh.addColorStop(0, 'rgba(0,0,0,0)'); sh.addColorStop(1, 'rgba(0,0,0,0.55)');
    ctx.fillStyle = sh; ctx.fillRect(x, y, w, h);
    ctx.restore();
    // the tieback cord, gold
    var tx = inner + (right ? pull * 0.55 : -pull * 0.55);
    ctx.fillStyle = '#c9a24a'; ctx.fillRect(Math.min(tx, outer), tieY - 3, Math.abs(outer - tx), 6);
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fillRect(Math.min(tx, outer), tieY + 2, Math.abs(outer - tx), 2);
  }
  /**
   * The SILHOUETTE stage: a dark back wall, a plank floor in perspective, a spotlight cone and its pool, velvet curtains
   * drawn back each side and a scalloped valance. Returns where the subject stands (its feet on `floorY`, centred on `cx`)
   * and the box it may fill.
   * @returns {{cx:number, floorY:number, maxW:number, maxH:number}}
   */
  function drawStage(ctx, rect, seed) {
    var x = rect.x, y = rect.y, w = rect.w, h = rect.h, cx = x + w / 2, fy = y + h * 0.7, foot = fy + h * 0.07;
    ctx.save();
    ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
    var bw = ctx.createLinearGradient(0, y, 0, fy); bw.addColorStop(0, '#0e0a10'); bw.addColorStop(1, '#2a1b20'); ctx.fillStyle = bw; ctx.fillRect(x, y, w, fy - y);
    var fl = ctx.createLinearGradient(0, fy, 0, y + h); fl.addColorStop(0, '#3a2516'); fl.addColorStop(1, '#5e3d24'); ctx.fillStyle = fl; ctx.fillRect(x, fy, w, y + h - fy);
    ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 1;
    for (var i = -9; i <= 9; i++) { ctx.beginPath(); ctx.moveTo(cx + i * w * 0.045, fy); ctx.lineTo(cx + i * w * 0.13, y + h); ctx.stroke(); }
    for (var k = 1; k < 5; k++) { var yy = fy + ((y + h - fy) * k * k) / 25; ctx.beginPath(); ctx.moveTo(x, yy); ctx.lineTo(x + w, yy); ctx.stroke(); }
    ctx.fillStyle = '#160e0a'; ctx.fillRect(x, fy - 2, w, 3);
    ctx.globalCompositeOperation = 'lighter';
    // the cone stops at the back edge of the floor and the POOL lights the floor (first look 2026-10-10: a cone carried
    // down to the feet ended in a hard horizontal edge and read as a lit rectangle lying on the planks)
    var cone = ctx.createLinearGradient(0, y, 0, fy); cone.addColorStop(0, 'rgba(255,236,190,0.03)'); cone.addColorStop(1, 'rgba(255,236,190,0.15)');
    var fw = 0.05 + (0.22 - 0.05) * ((fy - y) / (foot - y));
    ctx.fillStyle = cone; ctx.beginPath(); ctx.moveTo(cx - w * 0.05, y); ctx.lineTo(cx + w * 0.05, y); ctx.lineTo(cx + w * fw, fy); ctx.lineTo(cx - w * fw, fy); ctx.closePath(); ctx.fill();
    var pr = w * 0.26, pool = ctx.createRadialGradient(cx, foot, 1, cx, foot, pr); pool.addColorStop(0, 'rgba(255,228,176,0.60)'); pool.addColorStop(1, 'rgba(255,228,176,0)');
    ctx.save(); ctx.translate(cx, foot); ctx.scale(1, 0.26); ctx.fillStyle = pool; ctx.beginPath(); ctx.arc(0, 0, pr, 0, Math.PI * 2); ctx.fill(); ctx.restore();
    ctx.globalCompositeOperation = 'source-over';
    curtain(ctx, x, y, w * 0.18, h, seed, false);
    curtain(ctx, x + w - w * 0.18, y, w * 0.18, h, seed + 1, true);
    // the valance: velvet with a scalloped hem and a gold fringe line, pitch derived from the width (wing §24d)
    var vh = h * 0.1, sc = Math.max(3, Math.round(w / 70)), sw = w / sc;
    ctx.fillStyle = '#7a0f18'; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + w, y); ctx.lineTo(x + w, y + vh);
    for (var s = sc - 1; s >= 0; s--) ctx.quadraticCurveTo(x + (s + 0.5) * sw, y + vh * 1.55, x + s * sw, y + vh);
    ctx.closePath(); ctx.fill();
    ctx.strokeStyle = '#c9a24a'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x + w, y + vh);
    for (var t = sc - 1; t >= 0; t--) ctx.quadraticCurveTo(x + (t + 0.5) * sw, y + vh * 1.55, x + t * sw, y + vh);
    ctx.stroke();
    ctx.restore();
    return { cx: cx, floorY: foot, maxW: w * 0.4, maxH: foot - (y + vh * 1.6) - h * 0.04 };
  }
  /**
   * A subject on the stage: its own pixels filled near-black (k = 0) with a warm rim of spotlight along its top edge, or
   * in full colour (k = 1); between the two, the black lifts. A contact shadow sits under its feet. Pixel art is never
   * smoothed.
   */
  function drawSilhouette(ctx, src, sx, sy, sw, sh, dx, dy, dw, dh, k, smooth) {
    var W = Math.ceil(dw), Hh = Math.ceil(dh), g = scratch(W, Hh);
    g.imageSmoothingEnabled = !!smooth; g.drawImage(src, sx, sy, sw, sh, 0, 0, W, Hh);
    ctx.save(); ctx.imageSmoothingEnabled = false;
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.beginPath(); ctx.ellipse(dx + dw / 2, dy + dh - 1, dw * 0.34, Math.max(3, dh * 0.045), 0, 0, Math.PI * 2); ctx.fill();
    if (k < 1) {
      g.globalCompositeOperation = 'source-atop';
      g.fillStyle = 'rgba(255,214,150,' + (0.85 * (1 - k)) + ')'; g.fillRect(0, 0, W, Hh);
      var rim = Math.max(1, Math.round(dh * 0.012));
      ctx.drawImage(SCRATCH, 0, 0, W, Hh, Math.round(dx), Math.round(dy) - rim, W, Hh);
      g.globalCompositeOperation = 'source-over'; g.clearRect(0, 0, W, Hh); g.drawImage(src, sx, sy, sw, sh, 0, 0, W, Hh);
      g.globalCompositeOperation = 'source-atop'; g.fillStyle = 'rgba(14,10,16,' + (1 - k) + ')'; g.fillRect(0, 0, W, Hh);
    }
    ctx.drawImage(SCRATCH, 0, 0, W, Hh, Math.round(dx), Math.round(dy), W, Hh);
    ctx.restore();
  }
  /**
   * The SOLVED stamp: a red rubber-stamp roundel (outer ring, inner ring, a band across the middle with the word knocked
   * out of it), turned by the seed, the ink broken by seeded gaps the way a real stamp never inks evenly.
   */
  function drawStamp(ctx, cx, cy, r, word, seed, font) {
    var S = Math.ceil(r * 2.3), c = S / 2, g = scratch(S, S);
    g.strokeStyle = '#b3262a'; g.fillStyle = '#b3262a';
    g.lineWidth = Math.max(2, r * 0.09); g.beginPath(); g.arc(c, c, r - g.lineWidth / 2, 0, Math.PI * 2); g.stroke();
    g.lineWidth = Math.max(1, r * 0.035); g.beginPath(); g.arc(c, c, r * 0.78, 0, Math.PI * 2); g.stroke();
    g.fillRect(c - r * 1.08, c - r * 0.22, r * 2.16, r * 0.44);
    for (var d = -1; d <= 1; d++) for (var v = -1; v <= 1; v += 2) {
      var px = c + d * r * 0.24, py = c + v * r * 0.5, q = r * 0.06;
      g.beginPath(); g.moveTo(px, py - q); g.lineTo(px + q, py); g.lineTo(px, py + q); g.lineTo(px - q, py); g.closePath(); g.fill();
    }
    g.globalCompositeOperation = 'destination-out';
    var wf = font || '700 ' + Math.round(r * 0.3) + 'px "Palatino Linotype", "Book Antiqua", Palatino, Georgia, serif';
    g.font = wf;
    g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(word, c, c + r * 0.02);
    for (var n = 0; n < Math.round(r * 2.2); n++) {
      var a = hash(n, 1, seed) * Math.PI * 2, rr2 = Math.sqrt(hash(n, 2, seed)) * r * 1.1;
      g.fillStyle = 'rgba(0,0,0,' + (0.4 + hash(n, 3, seed) * 0.6) + ')';
      g.beginPath(); g.arc(c + Math.cos(a) * rr2, c + Math.sin(a) * rr2, Math.max(0.6, r * (0.008 + hash(n, 4, seed) * 0.02)), 0, Math.PI * 2); g.fill();
    }
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(-0.22 + (hash(seed, 11, 5) - 0.5) * 0.16); ctx.globalAlpha = 0.9;
    // the word is knocked out of the band, so whatever lies under the stamp shows through it: over the brass rim of the
    // close-up lens the S vanished into gold (LOOKED AT 2026-10-10). A paper ground under the letters keeps the word
    // pale-on-red on any background, the way a stamp reads on a sheet.
    ctx.font = wf; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#efe4cc';
    ctx.lineJoin = 'round'; ctx.strokeStyle = '#efe4cc'; ctx.lineWidth = Math.max(1, r * 0.03);
    ctx.strokeText(word, 0, r * 0.02); ctx.fillText(word, 0, r * 0.02);
    ctx.drawImage(SCRATCH, 0, 0, S, S, -c, -c, S, S); ctx.restore();
  }

  /* ------------------------------------------------------------ the two guessing modes that reveal over time */
  var PING = [null, null];
  /** the two ping-pong canvases the mosaic halves through (reused; a mosaic step is baked once, never per frame) */
  function ping(k, w, h) {
    if (!PING[k]) PING[k] = document.createElement('canvas');
    var c = PING[k];
    if (c.width < w || c.height < h) { c.width = Math.max(w, c.width); c.height = Math.max(h, c.height); }
    var g = c.getContext('2d'); g.setTransform(1, 0, 0, 1, 0, 0); g.globalCompositeOperation = 'source-over'; g.clearRect(0, 0, c.width, c.height);
    return g;
  }
  /** a backdrop for a subject: a two-stop radial wash */
  function backdrop(g, x, y, w, h, back) {
    var bg = g.createRadialGradient(x + w / 2, y + h * 0.35, Math.min(w, h) * 0.05, x + w / 2, y + h / 2, Math.max(w, h) * 0.7);
    bg.addColorStop(0, back[0]); bg.addColorStop(1, back[1]); g.fillStyle = bg; g.fillRect(x, y, w, h);
  }
  /**
   * The CLOSE-UP lens: a brass-rimmed round window onto the subject at `zoom` times its fitted size. At 1x the whole
   * subject is centred; as the zoom rises the view slides toward the focus point (fx, fy, 0..1 of the subject's box), so
   * at 6x the player sees one detail. RebusCore.closeupZoom supplies the schedule.
   * `cover` is for OPAQUE art (a face, an icon on its framed tile): at 1x the picture COVERS the round window instead of
   * fitting inside it, so the lens never shows a square photo floating in a circle (LOOKED AT 2026-10-10 in engine). A
   * battler, drawn on transparency, keeps the whole-subject fit.
   */
  function drawLens(ctx, cx, cy, r, src, sx, sy, sw, sh, zoom, fx, fy, back, smooth, cover) {
    var base = cover ? Math.max((r * 2) / sw, (r * 2) / sh) * 1.04 : Math.min((r * 1.6) / sw, (r * 1.6) / sh);
    var z = base * zoom, t = Math.min(1, (1 - 1 / zoom) * 1.25);
    var px = (0.5 + (fx - 0.5) * t) * sw, py = (0.5 + (fy - 0.5) * t) * sh;
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.beginPath(); ctx.arc(cx + 5, cy + 8, r * 1.14, 0, Math.PI * 2); ctx.fill();
    ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.clip();
    backdrop(ctx, cx - r, cy - r, 2 * r, 2 * r, back);
    ctx.imageSmoothingEnabled = !!smooth;
    ctx.drawImage(src, sx, sy, sw, sh, Math.round(cx - px * z), Math.round(cy - py * z), Math.round(sw * z), Math.round(sh * z));
    var vg = ctx.createRadialGradient(cx, cy, r * 0.55, cx, cy, r); vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.5)');
    ctx.fillStyle = vg; ctx.fillRect(cx - r, cy - r, 2 * r, 2 * r);
    ctx.strokeStyle = 'rgba(255,255,255,0.20)'; ctx.lineWidth = Math.max(2, r * 0.05); ctx.beginPath(); ctx.arc(cx, cy, r * 0.82, Math.PI * 1.08, Math.PI * 1.42); ctx.stroke();
    ctx.restore();
    var rw = Math.max(4, r * 0.14), rg = ctx.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
    rg.addColorStop(0, '#f2d892'); rg.addColorStop(0.5, '#b0823a'); rg.addColorStop(1, '#5a3c12');
    ctx.strokeStyle = rg; ctx.lineWidth = rw; ctx.beginPath(); ctx.arc(cx, cy, r + rw / 2, 0, Math.PI * 2); ctx.stroke();
    ctx.strokeStyle = 'rgba(0,0,0,0.55)'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke(); ctx.beginPath(); ctx.arc(cx, cy, r + rw, 0, Math.PI * 2); ctx.stroke();
    for (var k = 0; k < 4; k++) {
      var a = Math.PI / 4 + (k * Math.PI) / 2, sxp = cx + Math.cos(a) * (r + rw / 2), syp = cy + Math.sin(a) * (r + rw / 2), sr = Math.max(1.5, rw * 0.22);
      ctx.fillStyle = '#3a2608'; ctx.beginPath(); ctx.arc(sxp, syp, sr, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = 'rgba(255,236,180,0.6)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(sxp - sr * 0.7, syp + sr * 0.7); ctx.lineTo(sxp + sr * 0.7, syp - sr * 0.7); ctx.stroke();
    }
    ctx.restore();
  }
  /**
   * The MOSAIC: the subject fitted into a w x h window over its backdrop, then averaged into square blocks of `block` px
   * (RebusCore.mosaicBlock supplies the schedule). The average is made by HALVING the picture on canvases until it is one
   * texel per block, so nothing reads pixels back from the GPU (Probe_Doctrine §27a), then drawn back up unsmoothed.
   */
  function drawMosaic(ctx, x, y, w, h, src, sx, sy, sw, sh, block, back, crisp) {
    var W = Math.ceil(w), Hh = Math.ceil(h), g = scratch(W, Hh);
    backdrop(g, 0, 0, W, Hh, back);
    var fit = subjectScale({ w: sw, h: sh }, W, Hh, 0.82), dw = Math.round(sw * fit.z), dh = Math.round(sh * fit.z);
    // `crisp` (pixel art): the picture is fitted with sharp pixels; the block averaging below stays smoothed either way
    g.imageSmoothingEnabled = fit.smooth && !crisp; g.drawImage(src, sx, sy, sw, sh, Math.round((W - dw) / 2), Math.round((Hh - dh) / 2), dw, dh);
    ctx.save(); ctx.beginPath(); ctx.rect(x, y, W, Hh); ctx.clip();
    if (block <= 1) { ctx.drawImage(SCRATCH, 0, 0, W, Hh, x, y, W, Hh); ctx.restore(); return; }
    var bw = Math.max(1, Math.ceil(W / block)), bh = Math.max(1, Math.ceil(Hh / block));
    var cur = SCRATCH, cw = W, ch = Hh, k = 0;
    while (cw / 2 >= bw && ch / 2 >= bh) {
      var nw = Math.ceil(cw / 2), nh = Math.ceil(ch / 2), d = ping(k, nw, nh);
      d.imageSmoothingEnabled = true; d.drawImage(cur, 0, 0, cw, ch, 0, 0, nw, nh);
      cur = PING[k]; cw = nw; ch = nh; k = 1 - k;
    }
    var last = ping(k, bw, bh); last.imageSmoothingEnabled = true; last.drawImage(cur, 0, 0, cw, ch, 0, 0, bw, bh);
    ctx.imageSmoothingEnabled = false; ctx.drawImage(PING[k], 0, 0, bw, bh, x, y, bw * block, bh * block);
    // seams only where a block is big enough to read as a tile (LOOKED AT 2026-10-10: at 8 px the seams were graph paper
    // laid over the picture)
    if (block >= 16) {
      ctx.strokeStyle = 'rgba(0,0,0,0.16)'; ctx.lineWidth = 1; ctx.beginPath();
      for (var gx = 1; gx < bw; gx++) { ctx.moveTo(x + gx * block + 0.5, y); ctx.lineTo(x + gx * block + 0.5, y + Hh); }
      for (var gy = 1; gy < bh; gy++) { ctx.moveTo(x, y + gy * block + 0.5); ctx.lineTo(x + W, y + gy * block + 0.5); }
      ctx.stroke();
    }
    ctx.restore();
  }

  /* ------------------------------------------------------------ the strip: round, score, hints */
  var LABEL_FONT = '"Palatino Linotype", "Book Antiqua", Palatino, Georgia, serif';
  /** engraved text on metal: a dark cut with a one-pixel lit edge below it */
  function engrave(ctx, text, x, y, px, align, cut, lit) {
    ctx.save(); ctx.font = '700 ' + px + 'px ' + LABEL_FONT; ctx.textAlign = align || 'left'; ctx.textBaseline = 'middle';
    ctx.fillStyle = lit; ctx.fillText(text, x, y + 1); ctx.fillStyle = cut; ctx.fillText(text, x, y); ctx.restore();
  }
  function screw(ctx, x, y, r) {
    var g = ctx.createRadialGradient(x - r * 0.3, y - r * 0.3, r * 0.1, x, y, r); g.addColorStop(0, '#f6e2a8'); g.addColorStop(1, '#6a4a18');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = 'rgba(40,24,6,0.8)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x - r * 0.7, y + r * 0.2); ctx.lineTo(x + r * 0.7, y - r * 0.2); ctx.stroke();
  }
  /** a brass plate: bevelled, brushed, a screw in each corner */
  function plate(ctx, x, y, w, h, pressed) {
    var r = Math.max(3, h * 0.12);
    ctx.fillStyle = 'rgba(0,0,0,0.4)'; rr(ctx, x + 3, y + (pressed ? 2 : 5), w, h, r); ctx.fill();
    var g = ctx.createLinearGradient(x, y, x, y + h);
    g.addColorStop(0, pressed ? '#a8813e' : '#e8c87a'); g.addColorStop(0.5, pressed ? '#8a6830' : '#c49a4a'); g.addColorStop(1, pressed ? '#6a4c20' : '#8a6328');
    ctx.fillStyle = g; rr(ctx, x, y, w, h, r); ctx.fill();
    ctx.save(); rr(ctx, x, y, w, h, r); ctx.clip();
    ctx.strokeStyle = 'rgba(255,255,255,0.08)'; ctx.lineWidth = 1;
    for (var i = 2; i < h; i += 3) { ctx.beginPath(); ctx.moveTo(x, y + i + 0.5); ctx.lineTo(x + w, y + i + 0.5); ctx.stroke(); }
    ctx.restore();
    ctx.strokeStyle = 'rgba(255,240,200,0.45)'; ctx.lineWidth = 1; rr(ctx, x + 1.5, y + 1.5, w - 3, h - 3, r); ctx.stroke();
    ctx.strokeStyle = 'rgba(50,30,8,0.7)'; rr(ctx, x + 0.5, y + 0.5, w - 1, h - 1, r); ctx.stroke();
  }
  /** a gold coin, for a hint's cost */
  function coin(ctx, cx, cy, r) {
    var g = ctx.createRadialGradient(cx - r * 0.35, cy - r * 0.35, r * 0.1, cx, cy, r); g.addColorStop(0, '#fff0b0'); g.addColorStop(0.6, '#e0b040'); g.addColorStop(1, '#8a6010');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = 'rgba(90,60,10,0.8)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(cx, cy, r * 0.72, 0, Math.PI * 2); ctx.stroke();
  }
  /**
   * The round plaque: a brass plate engraved with the round (e.g. "ROUND 3 OF 10") over the score, the score larger.
   * Labels are the caller's (the plugin parameters carry them, so a buyer can translate them).
   */
  function drawPlaque(ctx, x, y, w, h, top, big) {
    plate(ctx, x, y, w, h, false);
    var sr = Math.max(2, h * 0.045);
    screw(ctx, x + sr * 2.6, y + sr * 2.6, sr); screw(ctx, x + w - sr * 2.6, y + sr * 2.6, sr); screw(ctx, x + sr * 2.6, y + h - sr * 2.6, sr); screw(ctx, x + w - sr * 2.6, y + h - sr * 2.6, sr);
    // sizes LOOKED AT in engine 2026-10-10: at 0.17 of a 52 px plate the round label was 9 px and unreadable
    engrave(ctx, top, x + w / 2, y + h * 0.3, Math.max(12, Math.round(h * 0.25)), 'center', '#3a2408', 'rgba(255,240,200,0.55)');
    engrave(ctx, big, x + w / 2, y + h * 0.7, Math.max(14, Math.round(h * 0.36)), 'center', '#3a2408', 'rgba(255,240,200,0.55)');
  }
  /**
   * A hint button: a brass push-plate with its label and its cost in coins; `state` 'idle' | 'pressed' | 'spent' (a spent
   * hint is dulled and its cost struck through, so the player sees it is gone).
   */
  function drawHintButton(ctx, x, y, w, h, label, cost, state, coinOn) {
    var pressed = state === 'pressed', dy = pressed ? 2 : 0, withCoin = coinOn !== false;
    plate(ctx, x, y + dy, w, h, pressed);
    var px = Math.round(h * 0.34), cr = Math.max(4, h * 0.2), cx = x + w - cr * 1.6 - 4;
    engrave(ctx, label, x + h * 0.3, y + dy + h / 2, px, 'left', '#3a2408', 'rgba(255,240,200,0.55)');
    // a coin only when the cost IS gold; a points cost is written without one
    if (withCoin) coin(ctx, cx, y + dy + h / 2, cr);
    engrave(ctx, String(cost), withCoin ? cx - cr - 4 : x + w - h * 0.3, y + dy + h / 2, px, 'right', '#3a2408', 'rgba(255,240,200,0.55)');
    if (state === 'spent') {
      ctx.fillStyle = 'rgba(30,20,12,0.55)'; rr(ctx, x, y, w, h, Math.max(3, h * 0.12)); ctx.fill();
      ctx.strokeStyle = 'rgba(179,38,42,0.9)'; ctx.lineWidth = Math.max(2, h * 0.06);
      ctx.beginPath(); ctx.moveTo(x + w * 0.08, y + h * 0.5); ctx.lineTo(x + w * 0.92, y + h * 0.5); ctx.stroke();
    }
  }

  /**
   * Where the mats go on the board, DERIVED from the board's inner rect (wing §18b: never a typed size). One picture is
   * centred; two sit side by side; four are a 2 x 2 grid. Every mat keeps the given aspect, the largest that fits with a
   * gap of at least `gap` between mats and from the cork edge, so a rotated mat never touches its neighbour.
   * @returns {Array<{cx:number, cy:number, w:number, h:number}>}
   */
  function layoutMats(inner, n, aspect, gap) {
    // three pictures: two above, one CENTRED below at the 2 x 2 cell size (LOOKED AT in engine 2026-10-10: a row of three
    // left 40% of the cork empty, and a 2 x 2 grid with a hole at one corner reads as a missing picture); four: 2 x 2
    var cols = n >= 2 ? 2 : 1, rows = n >= 3 ? 2 : 1, out = [];
    // solved with a pixel of slack and floored, so rounding the centres can never eat into the promised gap (MEASURED in
    // engine 2026-10-10: an exact solve rounded to a 13 px gap)
    var g1 = gap + 1, cw = (inner.w - g1 * (cols + 1)) / cols, ch = (inner.h - g1 * (rows + 1)) / rows;
    var h = Math.floor(Math.min(ch, cw / aspect)), w = Math.floor(h * aspect);
    var gx = (inner.w - cols * w) / (cols + 1), gy = (inner.h - rows * h) / (rows + 1);
    for (var i = 0; i < n; i++) {
      var c = i % cols, r = Math.floor(i / cols);
      var cx = n === 3 && i === 2 ? inner.x + inner.w / 2 : inner.x + gx + c * (w + gx) + w / 2;
      out.push({ cx: Math.round(cx), cy: Math.round(inner.y + gy + r * (h + gy) + h / 2), w: Math.round(w), h: Math.round(h) });
    }
    return out;
  }

  /**
   * The opaque bounds of a picture's pixels (alpha > 16) inside a cell of RGBA data: an icon or a battler sits in padding,
   * and a picture scaled by its CELL comes out half the size of its window. Null when the cell is empty.
   */
  function opaqueBox(data, stride, x0, y0, w, h) {
    var minX = w, minY = h, maxX = -1, maxY = -1;
    for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) {
      if (data[((y0 + y) * stride + x0 + x) * 4 + 3] > 16) { if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y; }
    }
    return maxX < 0 ? null : { x: minX, y: minY, w: maxX - minX + 1, h: maxY - minY + 1 };
  }
  /**
   * The scale that fits a subject's opaque box to `fill` of a space. A whole number when at least 2x fits (pixel art
   * stays crisp); below that the exact fit, because flooring 1.83 to 1 left a 112 px stag alone on a 205 px stage
   * (LOOKED AT 2026-10-10). A fractional scale is drawn smoothed (`smooth` in the result); a whole one never is.
   * @returns {{z:number, smooth:boolean}}
   */
  function subjectScale(box, w, h, fill) {
    var fit = Math.min((w * fill) / box.w, (h * fill) / box.h);
    return fit >= 2 ? { z: Math.floor(fit), smooth: false } : { z: Math.max(0.25, fit), smooth: true };
  }

  return { VERSION: '1.0.0', MATERIALS: MATERIALS, drawTile: drawTile, drawSlot: drawSlot, drawFixed: drawFixed, drawTable: drawTable, drawBoard: drawBoard, drawMat: drawMat, drawStage: drawStage, drawSilhouette: drawSilhouette, drawStamp: drawStamp, drawLens: drawLens, drawMosaic: drawMosaic, drawPlaque: drawPlaque, drawHintButton: drawHintButton, layoutMats: layoutMats, opaqueBox: opaqueBox, subjectScale: subjectScale, inkFor: inkFor, relief: relief, luma: luma, hex: hex };
})();
if (typeof module === 'object' && module.exports) module.exports = RebusDraw;
