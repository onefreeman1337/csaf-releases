//=============================================================================
// TemperamentCore.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Temperament 1/3 - the rules: twelve temperaments, the question bank, the sort and the tie rule. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The rules for Temperament. No parameters or commands of its own, and no
 * engine code: it reads the plain database arrays it is handed and returns
 * plain data, so it can be tested outside the engine.
 *
 * What it does:
 * - names twelve temperaments, each with an epithet and a stat leaning;
 * - reads a temperament profile out of a class's own parameter curves
 *   (compared with YOUR other classes, never with a fixed table), its skill
 *   types and its skills, unless a notetag says otherwise;
 * - holds a bank of situational questions where every answer leans toward
 *   one or two temperaments and no answer is right;
 * - draws a seeded, balanced quiz from the bank so every outcome can be
 *   reached;
 * - sorts the player into the outcome whose profile best matches the
 *   answers, and when two or more outcomes tie, sets a face-off question
 *   between the tied outcomes only, so a tie is never decided silently.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var TemperamentCore = (function () {
  'use strict';

  /* ── THE TWELVE TEMPERAMENTS ──────────────────────────────────────────────────────────────────────────────
   * `lean` is the stat direction over MZ's eight parameters [MHP, MMP, ATK, DEF, MAT, MDF, AGI, LUK]: a class whose
   * curves stand out in that direction among the buyer's classes reads as that temperament. Two temperaments never
   * share a lean (asserted in the tests), so the derivation can tell them apart. */
  var T = [
    { id: 'steadfast', name: 'Steadfast', epithet: 'the Steadfast', lean: [1, 0, 0, 2, 0, 0, 0, 0], colour: '#6f8fae' },
    { id: 'bold', name: 'Bold', epithet: 'the Bold', lean: [0, 0, 2, 0, 0, 0, 0, 0], colour: '#d2553b' },
    { id: 'fierce', name: 'Fierce', epithet: 'the Fierce', lean: [0, 0, 1, 0, 0, 0, 1, 0], colour: '#b8352f' },
    { id: 'proud', name: 'Proud', epithet: 'the Proud', lean: [1, 0, 1, 1, 0, 0, 0, 0], colour: '#c99a2e' },
    { id: 'loyal', name: 'Loyal', epithet: 'the Loyal', lean: [0, 0, 0, 1, 0, 1, 0, 0], colour: '#4f7c5a' },
    { id: 'gentle', name: 'Gentle', epithet: 'the Gentle', lean: [0, 1, 0, 0, 0, 2, 0, 0], colour: '#7fb59a' },
    { id: 'calm', name: 'Calm', epithet: 'the Calm', lean: [0, 1, 0, 0, 0, 1, -1, 0], colour: '#5c8db8' },
    { id: 'wise', name: 'Wise', epithet: 'the Wise', lean: [0, 1, 0, 0, 2, 0, 0, 0], colour: '#6a5cae' },
    { id: 'curious', name: 'Curious', epithet: 'the Curious', lean: [0, 0, 0, 0, 1, 0, 0, 1], colour: '#3fa3b5' },
    { id: 'cunning', name: 'Cunning', epithet: 'the Cunning', lean: [0, 0, 0, 0, 1, 0, 1, 0], colour: '#8a4f9e' },
    { id: 'daring', name: 'Daring', epithet: 'the Daring', lean: [0, 0, 0, 0, 0, 0, 2, 0], colour: '#e0823a' },
    { id: 'lucky', name: 'Lucky', epithet: 'the Lucky', lean: [0, 0, 0, 0, 0, 0, 0, 2], colour: '#d8b84a' },
  ];
  var IDS = T.map(function (t) { return t.id; });
  var BY = {}; T.forEach(function (t, i) { BY[t.id] = i; });

  /* ── THE QUESTION BANK ────────────────────────────────────────────────────────────────────────────────────
   * Situational questions for a fantasy setting. No answer is right; each answer leans toward one or two
   * temperaments (2 = strongly, 1 = a little). The tests assert every temperament is leaned toward by many answers. */
  function q(id, text, answers) { return { id: id, text: text, answers: answers.map(function (a) { return { text: a[0], w: a[1] }; }) }; }
  var BANK = [
    q('bridge', 'A rope bridge sways over a gorge. The far side is where you need to be.', [['Cross it at a run.', { daring: 2 }], ['Test every plank first.', { steadfast: 1, calm: 1 }], ['Look for another way round.', { cunning: 1, wise: 1 }], ['Wonder who built it, and why here.', { curious: 2 }]]),
    q('stranger', 'A stranger at the inn asks to share your table.', [['Of course. Sit, eat.', { gentle: 2 }], ['Only if they pay for the round.', { cunning: 2 }], ['Ask where they are headed.', { curious: 1, wise: 1 }], ['Keep a hand near your blade.', { steadfast: 1, fierce: 1 }]]),
    q('dragon', 'The village elder says a dragon sleeps under the hill.', [['Then I will wake it.', { bold: 2 }], ['Then we let it sleep.', { calm: 2 }], ['How big is its hoard?', { lucky: 1, cunning: 1 }], ['Who will guard the village if it wakes?', { loyal: 2 }]]),
    q('coin', 'You find a purse of coins on an empty road.', [['Finders keepers.', { lucky: 2 }], ['Find its owner.', { loyal: 1, gentle: 1 }], ['Count it, then decide.', { wise: 1, calm: 1 }], ['It is bait. Look around.', { cunning: 2 }]]),
    q('rival', 'A rival sneers that you will never be good enough.', [['Prove them wrong, today.', { proud: 2 }], ['Let it pass.', { calm: 2 }], ['Challenge them to a duel.', { fierce: 1, bold: 1 }], ['Ask them what they mean.', { curious: 1, gentle: 1 }]]),
    q('map', 'You are handed an old map with one corner torn away.', [['Follow it at once.', { daring: 2 }], ['Study it by candlelight.', { wise: 2 }], ['The missing corner is the interesting part.', { curious: 2 }], ['Sell it to someone who wants it more.', { cunning: 1, lucky: 1 }]]),
    q('storm', 'A storm traps your party in a cave for the night.', [['Keep watch so the others can sleep.', { loyal: 2 }], ['Explore deeper into the cave.', { curious: 1, daring: 1 }], ['Light a fire and tell stories.', { gentle: 1, calm: 1 }], ['Plan tomorrow\'s route.', { wise: 1, steadfast: 1 }]]),
    q('feast', 'A king throws a feast in your honour.', [['Sit at the head of the table.', { proud: 2 }], ['Thank the cooks.', { gentle: 2 }], ['Listen to the gossip.', { cunning: 1, curious: 1 }], ['Leave early. There is work to do.', { steadfast: 2 }]]),
    q('wolf', 'A wounded wolf blocks the forest path.', [['Bind its wound.', { gentle: 2 }], ['Step around it slowly.', { calm: 2 }], ['Stand your ground.', { steadfast: 1, bold: 1 }], ['Drive it off.', { fierce: 2 }]]),
    q('door', 'A door in the dungeon is marked DO NOT OPEN.', [['Open it.', { daring: 1, curious: 1 }], ['Leave it shut.', { calm: 1, wise: 1 }], ['Listen at it first.', { cunning: 2 }], ['Let someone braver go first.', { lucky: 2 }]]),
    q('oath', 'A friend asks you to swear an oath you might not keep.', [['Swear it and keep it, whatever it costs.', { loyal: 2 }], ['Refuse, gently.', { gentle: 1, wise: 1 }], ['Swear it with my fingers crossed.', { cunning: 2 }], ['Ask what happens if I fail.', { curious: 1, calm: 1 }]]),
    q('tourney', 'A tourney is announced. The prize is a golden sword.', [['Enter, to win.', { proud: 1, bold: 1 }], ['Enter, for the fun of it.', { daring: 1, lucky: 1 }], ['Watch and learn the fighters\' tricks.', { cunning: 1, wise: 1 }], ['Guard the gate while others play.', { steadfast: 2 }]]),
    q('witch', 'A witch offers to tell your fortune for a price.', [['Pay. I want to know.', { curious: 2 }], ['My fortune is mine to make.', { proud: 1, bold: 1 }], ['Haggle the price down.', { cunning: 2 }], ['Ask her fortune instead.', { lucky: 1, gentle: 1 }]]),
    q('child', 'A crying child is lost in the market.', [['Stay with them until a parent comes.', { gentle: 2 }], ['Lift them on my shoulders and shout.', { bold: 1, daring: 1 }], ['Ask the stall keepers, one by one.', { steadfast: 1, wise: 1 }], ['Find the guard. That is their job.', { calm: 2 }]]),
    q('ruin', 'You reach a ruined tower at dusk.', [['Climb to the top.', { daring: 2 }], ['Search the cellar for books.', { wise: 1, curious: 1 }], ['Make camp outside its walls.', { calm: 1, steadfast: 1 }], ['Carve my name on the gate.', { proud: 2 }]]),
    q('betray', 'You learn a companion lied to you.', [['Confront them now.', { fierce: 2 }], ['Hear their reasons first.', { gentle: 1, wise: 1 }], ['Say nothing and watch them.', { cunning: 2 }], ['Forgive them. They are still mine.', { loyal: 2 }]]),
    q('river', 'The river is high and the ferryman is asleep.', [['Swim it.', { bold: 1, daring: 1 }], ['Wake him politely.', { gentle: 1, calm: 1 }], ['Borrow his boat.', { cunning: 1, lucky: 1 }], ['Wait for morning.', { steadfast: 2 }]]),
    q('spell', 'An old spellbook falls open at your feet.', [['Read it aloud.', { curious: 1, daring: 1 }], ['Close it and take it to a scholar.', { wise: 2 }], ['Keep it. It chose me.', { proud: 1, lucky: 1 }], ['Burn it. Some things should stay shut.', { fierce: 1, steadfast: 1 }]]),
    q('march', 'Your army must march at dawn.', [['Lead from the front.', { bold: 2 }], ['March with the rearguard.', { loyal: 1, steadfast: 1 }], ['Scout ahead alone.', { daring: 1, cunning: 1 }], ['Sleep well. Dawn comes either way.', { calm: 2 }]]),
    q('crown', 'A crown lies unclaimed on an empty throne.', [['Put it on.', { proud: 2 }], ['Give it to whoever earns it.', { loyal: 1, wise: 1 }], ['Sell the jewels.', { cunning: 1, lucky: 1 }], ['Ask why the throne is empty.', { curious: 2 }]]),
    q('dice', 'A sailor bets you a gold piece on one roll of the dice.', [['Roll.', { lucky: 2 }], ['Only with my own dice.', { cunning: 2 }], ['I do not gamble.', { steadfast: 1, calm: 1 }], ['Double it.', { bold: 1, daring: 1 }]]),
    q('monster', 'A monster attacks your camp at night.', [['Leap up and fight.', { fierce: 2 }], ['Shield the sleeping.', { loyal: 1, steadfast: 1 }], ['Study how it moves.', { wise: 1, cunning: 1 }], ['Hide and hope it passes.', { lucky: 1, calm: 1 }]]),
    q('garden', 'You are given a small garden of your own.', [['Grow herbs to heal with.', { gentle: 2 }], ['Grow the strangest seeds I can find.', { curious: 2 }], ['Grow food for the village.', { loyal: 1, steadfast: 1 }], ['Let it grow wild.', { calm: 1, lucky: 1 }]]),
    q('duel', 'You are challenged to a duel at sunrise.', [['I will be there early.', { proud: 1, steadfast: 1 }], ['I will strike first.', { fierce: 2 }], ['I will learn their style tonight.', { cunning: 1, wise: 1 }], ['I will talk them out of it.', { gentle: 1, calm: 1 }]]),
    q('cave', 'A cave mouth breathes warm air in winter.', [['Go in.', { daring: 2 }], ['Something lives there. Leave it be.', { calm: 1, gentle: 1 }], ['Warm air means hot springs. Or gold.', { lucky: 1, curious: 1 }], ['Mark it on the map and move on.', { wise: 1, steadfast: 1 }]]),
    q('mentor', 'An old master offers to teach you one thing.', [['Teach me to fight.', { fierce: 1, bold: 1 }], ['Teach me to read the stars.', { wise: 1, curious: 1 }], ['Teach me patience.', { calm: 2 }], ['Teach me your best trick.', { cunning: 2 }]]),
    q('fire', 'The village granary is on fire.', [['Run in for the grain.', { bold: 2 }], ['Form a bucket line.', { loyal: 1, steadfast: 1 }], ['Find out who started it.', { cunning: 1, curious: 1 }], ['Quiet the crowd.', { calm: 1, gentle: 1 }]]),
    q('song', 'A bard asks what song to sing about you.', [['A song of my victories.', { proud: 2 }], ['A song about my friends.', { loyal: 2 }], ['A funny one.', { lucky: 1, daring: 1 }], ['No song. I would rather listen.', { gentle: 1, wise: 1 }]]),
    q('trap', 'Your companion has stepped into a hunter\'s snare.', [['Cut them free, whatever it takes.', { loyal: 1, fierce: 1 }], ['Work out how it springs, then free them.', { wise: 1, cunning: 1 }], ['Keep your voice low and talk them through it.', { calm: 1, gentle: 1 }], ['Laugh first. Then help.', { lucky: 1, daring: 1 }]]),
    q('wish', 'A fallen star grants you one wish.', [['Strength.', { bold: 1, fierce: 1 }], ['Knowledge.', { wise: 2 }], ['Wealth.', { lucky: 2 }], ['That my friends are safe.', { loyal: 1, gentle: 1 }]]),
    q('enemy', 'Your enemy kneels and begs for mercy.', [['Spare them.', { gentle: 2 }], ['Spare them, but take their sword.', { steadfast: 1, wise: 1 }], ['Ask what they would have done.', { cunning: 1, curious: 1 }], ['They made their choice.', { fierce: 1, proud: 1 }]]),
    q('shortcut', 'A shortcut through the marsh would save a day.', [['Take it.', { daring: 1, lucky: 1 }], ['Keep to the road.', { steadfast: 2 }], ['Ask the marsh folk.', { curious: 1, gentle: 1 }], ['Send a scout first.', { cunning: 1, wise: 1 }]]),
    q('banner', 'You may choose the beast on your banner.', [['A lion.', { proud: 1, bold: 1 }], ['A wolf.', { loyal: 1, fierce: 1 }], ['An owl.', { wise: 1, calm: 1 }], ['A fox.', { cunning: 1, lucky: 1 }]]),
    q('silence', 'Your party falls silent around the fire.', [['Break it with a joke.', { lucky: 1, daring: 1 }], ['Enjoy it.', { calm: 2 }], ['Ask someone about their past.', { curious: 1, gentle: 1 }], ['Sharpen my blade.', { fierce: 1, steadfast: 1 }]]),
    q('treasure', 'The treasure chest is guarded by a riddle.', [['Solve it.', { wise: 2 }], ['Smash the chest.', { bold: 1, fierce: 1 }], ['Guess. Fortune has been kind so far.', { lucky: 2 }], ['Pick the lock and skip the riddle.', { cunning: 2 }]]),
    q('apprentice', 'A clumsy apprentice breaks your favourite cup.', [['It is only a cup.', { calm: 1, gentle: 1 }], ['Show them how to hold one.', { wise: 1, loyal: 1 }], ['They will pay for it.', { proud: 2 }], ['I never liked that cup.', { lucky: 1, daring: 1 }]]),
    q('tower', 'From the tower top you can see the whole kingdom.', [['I want to walk every road of it.', { daring: 1, curious: 1 }], ['I will keep it safe.', { steadfast: 1, loyal: 1 }], ['One day it will be mine.', { proud: 2 }], ['It looks peaceful from here.', { calm: 2 }]]),
    q('feud', 'Two villages ask you to settle their feud.', [['Hear both sides.', { wise: 1, calm: 1 }], ['Side with the weaker.', { gentle: 1, loyal: 1 }], ['Make them both pay me.', { cunning: 2 }], ['Bang their heads together.', { fierce: 1, bold: 1 }]]),
    q('ghost', 'A ghost asks you to finish its last task.', [['Of course.', { gentle: 1, loyal: 1 }], ['What is in it for me?', { cunning: 1, lucky: 1 }], ['Ask how it died.', { curious: 2 }], ['Run.', { daring: 1, calm: 1 }]]),
    q('blade', 'The smith offers you a blade or a shield, not both.', [['The blade.', { bold: 1, fierce: 1 }], ['The shield.', { steadfast: 2 }], ['Whichever is worth more.', { cunning: 1, lucky: 1 }], ['The one my friend needs.', { loyal: 2 }]]),
    q('sea', 'You stand at the edge of an unknown sea.', [['Build a boat.', { daring: 1, bold: 1 }], ['Wonder what lives beneath.', { curious: 2 }], ['Listen to the waves.', { calm: 2 }], ['Ask the fishers for their tales.', { wise: 1, gentle: 1 }]]),
    q('victory', 'Your side wins the battle. What first?', [['Tend the wounded.', { gentle: 2 }], ['Raise the banner high.', { proud: 2 }], ['Count who is missing.', { loyal: 1, steadfast: 1 }], ['Search the field for spoils.', { lucky: 1, cunning: 1 }]]),
    q('lantern', 'Your lantern goes out deep in the mine.', [['Keep walking. My feet know the way.', { daring: 1, bold: 1 }], ['Wait for my eyes to adjust.', { calm: 1, wise: 1 }], ['Strike a spark and see what is near.', { curious: 1, cunning: 1 }], ['Call to the others and stay together.', { loyal: 1, steadfast: 1 }]]),
    q('morning', 'It is the first morning of your journey.', [['Up before the sun.', { steadfast: 1, proud: 1 }], ['Sleep in. The road will wait.', { calm: 1, lucky: 1 }], ['Pack the map first.', { wise: 1, cunning: 1 }], ['Out the door already.', { daring: 1, fierce: 1 }]]),
  ];

  /* ── SEEDED RANDOMNESS (wing §6: never Math.random in game logic) ──────────────────────────────────────── */
  function hashString(s) { var h = 2166136261 >>> 0; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; } return h >>> 0; }
  function mix(a, b) { var h = (a ^ Math.imul(b >>> 0, 2654435761)) >>> 0; h ^= h >>> 15; h = Math.imul(h, 2246822507) >>> 0; h ^= h >>> 13; return h >>> 0; }
  function rng(seed) { var s = (seed >>> 0) || 1; return function () { s = (s + 0x6D2B79F5) >>> 0; var t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  /** Fisher-Yates with the seeded stream: the draw count is the array's own length, never a sort's (wing §3). */
  function shuffle(list, r) { var a = list.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(r() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }

  /* ── VECTORS ──────────────────────────────────────────────────────────────────────────────────────────── */
  function zero() { var v = []; for (var i = 0; i < 12; i++) v.push(0); return v; }
  function fromWeights(w) { var v = zero(); for (var k in w) if (Object.prototype.hasOwnProperty.call(w, k) && k in BY) v[BY[k]] += Number(w[k]) || 0; return v; }
  function norm(v) { var s = 0; for (var i = 0; i < v.length; i++) s += v[i] * v[i]; return Math.sqrt(s); }
  function cosine(a, b) { var na = norm(a), nb = norm(b); if (!na || !nb) return 0; var s = 0; for (var i = 0; i < a.length; i++) s += a[i] * b[i]; return s / (na * nb); }

  /* ── READING A TEMPERAMENT OUT OF THE DATABASE ────────────────────────────────────────────────────────── */
  /** `<Temperament: Gentle>` or `<Temperament: Gentle 2, Wise 1>` in a note. Returns a 12-vector or null. */
  function noteProfile(note) {
    var m = /<\s*temperament\s*:\s*([^>]+)>/i.exec(String(note || ''));
    if (!m) return null;
    var v = zero(), any = false;
    m[1].split(/[,;]/).forEach(function (part) {
      var mm = /^\s*([a-z]+)\s*(-?\d+(?:\.\d+)?)?\s*$/i.exec(part); if (!mm) return;
      var id = mm[1].toLowerCase(); if (!(id in BY)) return;
      v[BY[id]] += mm[2] != null ? Number(mm[2]) : 1; any = true;
    });
    return any ? v : null;
  }
  /** A class's stat SHAPE: each parameter at level 50 (or the last level it has), as a share of that class's own total. */
  function statShape(cls) {
    var p = cls && cls.params; if (!p || !p.length) return null;
    var out = [];
    for (var i = 0; i < 8; i++) { var row = p[i] || []; var lv = Math.min(50, row.length - 1); out.push(Number(row[lv]) || 0); }
    // HP and MP live on a scale ten times the others in MZ's curves: bring them to the same scale before shares
    out[0] /= 10; out[1] /= 10;
    var tot = out.reduce(function (s, x) { return s + Math.max(0, x); }, 0) || 1;
    return out.map(function (x) { return x / tot; });
  }
  /**
   * Profiles for a set of classes, read RELATIVE TO EACH OTHER: a stat shape is compared with the mean shape of the
   * buyer's own classes, so what matters is what makes a class different from its siblings (wing §24a: score what the
   * buyer CHANGED, never a fixed table). A <Temperament> notetag replaces the reading for that class.
   * `skills` is $dataSkills (optional): healing skills lean Gentle, magic attacks Wise, physical attacks Bold.
   */
  function classProfiles(classes, ids, skills) {
    return distinct(rawClassProfiles(classes, ids, skills));
  }
  /**
   * Give each curve-read class its OWN leading temperament where twelve allow it (core.test, 2026-10-20: a balanced
   * Hero and a Warrior both led Bold, so the two outcomes were near-twins and the Hero was reachable on 87 of 200
   * deliberate quizzes). Greedy over (class, temperament) claims, strongest first; a notetag's lead is reserved before
   * any curve-read class claims. The won temperament is raised to lead its profile by half its peak again, and a
   * temperament another class won is halved, so siblings pull apart (balance probe run 3, fixture classes: Hero
   * reachable 87 -> 188 of 200, uniform shares max/min 1.42 -> 1.29; Warrior 171 -> 116, the price, still reachable).
   */
  function distinct(list) {
    var taken = {}, claims = [], lead = {};
    list.forEach(function (c) { if (c.source === 'notetag') { var b = 0; for (var t = 1; t < 12; t++) if (c.profile[t] > c.profile[b]) b = t; taken[b] = true; } });
    list.forEach(function (c, k) { if (c.source !== 'curves') return; for (var t = 0; t < 12; t++) claims.push({ k: k, t: t, s: c.profile[t] }); });
    claims.sort(function (a, b) { return b.s - a.s || a.k - b.k || a.t - b.t; });
    claims.forEach(function (cl) { if (cl.s <= 0 || lead[cl.k] != null || taken[cl.t]) return; lead[cl.k] = cl.t; taken[cl.t] = true; });
    return list.map(function (c, k) {
      if (lead[k] == null) return c;
      var p = c.profile.slice(), peak = Math.max.apply(null, p) || 1; p[lead[k]] = peak * 1.5; for (var o in lead) if (Number(o) !== k && lead[o] !== lead[k]) p[lead[o]] *= 0.5;
      return { id: c.id, name: c.name, profile: p, source: c.source, lead: IDS[lead[k]] };
    });
  }
  function rawClassProfiles(classes, ids, skills) {
    var shapes = ids.map(function (id) { return statShape(classes[id]); });
    var have = shapes.filter(Boolean), mean = [0, 0, 0, 0, 0, 0, 0, 0];
    have.forEach(function (s) { for (var i = 0; i < 8; i++) mean[i] += s[i] / have.length; });
    return ids.map(function (id, k) {
      var c = classes[id] || {}, note = noteProfile(c.note);
      if (note) return { id: id, name: c.name || ('Class ' + id), profile: note, source: 'notetag' };
      var v = zero(), sh = shapes[k];
      if (sh) {
        var d = sh.map(function (x, i) { return (x - mean[i]) / (mean[i] || 1); });
        for (var t = 0; t < 12; t++) { var s = 0; for (var i = 0; i < 8; i++) s += d[i] * T[t].lean[i]; v[t] = s; }
      }
      // skills it learns: what it DOES, beside what it IS
      var heal = 0, magic = 0, phys = 0;
      (c.learnings || []).forEach(function (l) {
        var sk = skills && skills[l.skillId]; if (!sk || !sk.damage) return;
        if (sk.damage.type === 3) heal++; else if (sk.damage.type === 1 && sk.hitType === 2) magic++; else if (sk.damage.type === 1 && sk.hitType === 1) phys++;
      });
      var n = heal + magic + phys;
      if (n) { v[BY.gentle] += 0.35 * heal / n; v[BY.wise] += 0.35 * magic / n; v[BY.bold] += 0.35 * phys / n; }
      // keep only what stands out: the profile is the positive part (a class is not "anti-lucky")
      var pos = v.map(function (x) { return Math.max(0, x); });
      if (!norm(pos)) pos[BY.steadfast] = 1; // a class identical to the mean of its siblings reads as Steadfast, said in the Readme
      return { id: id, name: c.name || ('Class ' + id), profile: pos, source: 'curves' };
    });
  }
  /** Actors read through their class, unless the actor's own note carries a <Temperament> tag. */
  function actorProfiles(actors, ids, classes, skills) {
    var cls = classProfiles(classes, ids.map(function (id) { return (actors[id] || {}).classId || 0; }).filter(function (x, i, a) { return x && a.indexOf(x) === i; }), skills);
    var byClass = {}; cls.forEach(function (c) { byClass[c.id] = c; });
    return ids.map(function (id) {
      var a = actors[id] || {}, note = noteProfile(a.note);
      if (note) return { id: id, name: a.name || ('Actor ' + id), profile: note, source: 'notetag', face: a.faceName, faceIndex: a.faceIndex, battler: a.battlerName };
      var c = byClass[a.classId];
      return { id: id, name: a.name || ('Actor ' + id), profile: c ? c.profile.slice() : fromWeights({ steadfast: 1 }), source: c ? 'class:' + c.name : 'default', face: a.faceName, faceIndex: a.faceIndex, battler: a.battlerName };
    });
  }
  /** Houses: named outcomes the buyer writes, each with one or more temperaments ("Gentle 2, Wise 1"). */
  function houseProfiles(houses) {
    return houses.map(function (h, i) {
      var v = noteProfile('<Temperament: ' + (h.temperaments || '') + '>') || fromWeights({ steadfast: 1 });
      return { id: i + 1, name: h.name || ('House ' + (i + 1)), profile: v, source: 'house', colour: h.colour || null, face: h.face || '', faceIndex: Number(h.faceIndex) || 0 };
    });
  }

  /* ── THE QUIZ ─────────────────────────────────────────────────────────────────────────────────────────── */
  /** The temperaments that matter for these outcomes: those any outcome leans toward. */
  function relevant(outcomes) { var r = []; for (var t = 0; t < 12; t++) if (outcomes.some(function (o) { return o.profile[t] > 0; })) r.push(t); return r; }
  /**
   * A balanced draw of `count` questions: seeded, and chosen so that every relevant temperament is leaned toward by
   * as many answers as possible (greedy on the minimum coverage, then on total), so every outcome stays reachable.
   */
  /*
   * 2026-10-21 (variety_probe.js): the greedy pick with the shuffle only breaking EXACT ties opened the default houses' quiz
   * with one of TWO questions over 500 seeds, and only 21 of the 44 ever appeared. Two changes, neither touching the
   * coverage minimum the balance rests on: (1) a seeded jitter of at most DRAW_JITTER on the TOTAL term only (the minimum
   * is weighted 100 per level, so a jitter below 100 can never trade a lower minimum for a higher total); (2) the drawn
   * questions are ASKED in a seeded order (the sort sums answers and what was offered over the whole quiz, so the order
   * of asking cannot change a result).
   * MEASURED (500 seeds, 8 questions): default houses 2 -> 25 openings, 21 -> 35 of 44 questions seen; stock classes
   * 4 -> 29 openings, 24 -> 39 seen. Balance probe run 4 vs run 3 (20,000 players x 2 seeds): houses-12 max/min 2.01 -> 1.66,
   * houses-6 1.46 -> 1.45, fixture classes 1.29 -> 1.22 (Warrior deliberately reachable 116 -> 154 of 200), houses-3 1.23 -> 1.22;
   * face-off share 22.5% -> 21.3% (houses-12), every other outcome still reachable 190-200 of 200.
   */
  var DRAW_JITTER = 4;
  function draw(bank, outcomes, count, seed) {
    var r = rng(seed), pool = shuffle(bank, r), rel = relevant(outcomes), cover = zero(), picked = [];
    count = Math.max(1, Math.min(count, pool.length));
    while (picked.length < count) {
      var best = -1, bestScore = -Infinity;
      for (var i = 0; i < pool.length; i++) {
        if (!pool[i]) continue;
        var c = cover.slice();
        pool[i].answers.forEach(function (a) { var v = fromWeights(a.w); for (var t = 0; t < 12; t++) if (v[t] > 0) c[t] += 1; });
        var min = Infinity, tot = 0; rel.forEach(function (t) { min = Math.min(min, c[t]); tot += c[t]; });
        var score = min * 100 + tot + r() * DRAW_JITTER;
        if (score > bestScore) { bestScore = score; best = i; }
      }
      var qq = pool[best]; pool[best] = null; picked.push(qq);
      qq.answers.forEach(function (a) { var v = fromWeights(a.w); for (var t = 0; t < 12; t++) if (v[t] > 0) cover[t] += 1; });
    }
    return shuffle(picked, r);
  }
  /** The bank the buyer gets: the built-in questions plus their own, each validated; a bad one is dropped with a reason. */
  function bank(custom, useBuiltIn) {
    var out = useBuiltIn === false ? [] : BANK.slice(), rejected = [];
    (custom || []).forEach(function (cq, i) {
      var answers = (cq.answers || []).filter(function (a) { return a && String(a.text || '').trim() !== '' && norm(fromWeights(a.w || {})) > 0; });
      if (!String(cq.text || '').trim()) rejected.push({ index: i, why: 'no question text' });
      else if (answers.length < 2) rejected.push({ index: i, why: 'fewer than two answers that lean toward a temperament' });
      else out.push({ id: 'custom' + (i + 1), text: String(cq.text).trim(), answers: answers.map(function (a) { return { text: String(a.text).trim(), w: a.w }; }), custom: true });
    });
    return { questions: out, rejected: rejected };
  }
  /**
   * What the drawn questions OFFER each temperament: the mean lean of a question's answers, summed over the quiz.
   * The sort reads each spoke against this, so a temperament the bank happens to offer more often cannot win by
   * frequency alone (balance probe, 2026-10-20: before it, Calm and Cunning took 15-16% of random players over twelve
   * houses and Loyal 4.9%, and a gentle house took 66% of a three-house quiz).
   */
  function offered(questions) {
    var e = zero();
    questions.forEach(function (qq) { qq.answers.forEach(function (a) { var v = fromWeights(a.w); for (var t = 0; t < 12; t++) e[t] += Math.max(0, v[t]) / qq.answers.length; }); });
    return e;
  }
  function createQuiz(questions, outcomes, seed) {
    if (!outcomes || outcomes.length < 2) throw new Error('Temperament: a quiz needs at least two outcomes to sort into');
    return { questions: questions, outcomes: outcomes, seed: seed >>> 0, index: 0, scores: zero(), offered: offered(questions), answers: [], faceoff: null, faceoffs: 0, result: null };
  }
  /** The player's spokes, each read against what the quiz offered it (a spoke never offered stays at zero). */
  function spokes(qz) { return qz.scores.map(function (x, t) { return qz.offered[t] > 0 ? x / qz.offered[t] : 0; }); }
  function current(qz) { return qz.faceoff ? qz.faceoff.question : qz.questions[qz.index]; }
  /** How well each outcome matches the player's answers so far. */
  function standings(qz) { var sp = spokes(qz); return qz.outcomes.map(function (o, i) { return { i: i, id: o.id, name: o.name, match: cosine(sp, o.profile) }; }).sort(function (a, b) { return b.match - a.match || a.i - b.i; }); }
  var TIE = 1e-9;
  /**
   * The face-off between tied outcomes: of the questions NOT yet asked, the one whose answers best separate them,
   * each answer assigned to the tied outcome it leans toward most. The player's choice decides; nothing is silent.
   */
  function faceoff(qz, tied, bankAll) {
    var asked = {}; qz.answers.forEach(function (a) { asked[a.q] = true; });
    var outs = tied.map(function (s) { return qz.outcomes[s.i]; }), best = null;
    (bankAll || BANK).forEach(function (cand) {
      if (asked[cand.id]) return;
      var used = {}, choice = [];
      outs.forEach(function (o, k) {
        var top = -1, topScore = -Infinity;
        cand.answers.forEach(function (a, j) { if (used[j]) return; var v = fromWeights(a.w), mine = cosine(v, o.profile), other = 0; outs.forEach(function (o2, k2) { if (k2 !== k) other = Math.max(other, cosine(v, o2.profile)); }); var s = mine - other; if (s > topScore) { topScore = s; top = j; } });
        if (top >= 0) { used[top] = true; choice.push({ answer: top, outcome: tied[k].i, margin: topScore }); }
      });
      if (choice.length !== outs.length) return;
      var minMargin = Math.min.apply(null, choice.map(function (c) { return c.margin; }));
      if (!best || minMargin > best.minMargin) best = { q: cand, choice: choice, minMargin: minMargin };
    });
    if (!best) { // the bank has nothing left that separates them: ask the plainest question there is
      return { question: { id: 'faceoff', text: 'One last choice. Which road is yours?', answers: outs.map(function (o) { return { text: o.name + '.', w: {} }; }), faceoff: true }, map: tied.map(function (s) { return s.i; }), tied: tied.map(function (s) { return s.i; }) };
    }
    var question = { id: best.q.id, text: best.q.text, answers: best.choice.map(function (c) { return best.q.answers[c.answer]; }), faceoff: true };
    return { question: question, map: best.choice.map(function (c) { return c.outcome; }), tied: tied.map(function (s) { return s.i; }) };
  }
  /** Answer the current question with answer index `k`. Returns 'next' | 'faceoff' | 'done'. */
  function answer(qz, k, bankAll) {
    if (qz.result) return 'done';
    if (qz.faceoff) {
      var winner = qz.faceoff.map[k];
      if (winner == null) throw new Error('Temperament: face-off answer ' + k + ' does not exist');
      var picked = qz.faceoff.question.answers[k];
      var v0 = fromWeights(picked.w || {}); for (var t0 = 0; t0 < 12; t0++) qz.scores[t0] += v0[t0];
      qz.answers.push({ q: qz.faceoff.question.id, k: k, faceoff: true });
      qz.result = { outcome: winner, tied: qz.faceoff.tied, byFaceoff: true };
      qz.faceoff = null; return 'done';
    }
    var qq = qz.questions[qz.index], a = qq.answers[k];
    if (!a) throw new Error('Temperament: answer ' + k + ' does not exist on question ' + qq.id);
    var v = fromWeights(a.w); for (var t = 0; t < 12; t++) qz.scores[t] += v[t];
    qz.answers.push({ q: qq.id, k: k });
    qz.index++;
    if (qz.index < qz.questions.length) return 'next';
    var st = standings(qz), tied = st.filter(function (s) { return st[0].match - s.match <= TIE; });
    if (tied.length > 1) { qz.faceoff = faceoff(qz, tied, bankAll); qz.faceoffs++; return 'faceoff'; }
    qz.result = { outcome: st[0].i, tied: null, byFaceoff: false };
    return 'done';
  }
  /** The player's own temperament: the strongest spoke, ties broken toward the winning outcome's leaning. */
  function temperamentOf(qz) {
    var o = qz.result ? qz.outcomes[qz.result.outcome] : null, best = 0, sp = spokes(qz);
    for (var t = 1; t < 12; t++) { var a = sp[t], b = sp[best]; if (a > b || (a === b && o && o.profile[t] > o.profile[best])) best = t; }
    return T[best];
  }
  /** The result as the plugin hands it out (variables, switches, the script call). */
  function result(qz) {
    if (!qz.result) return null;
    var o = qz.outcomes[qz.result.outcome], tp = temperamentOf(qz), sp = spokes(qz), max = Math.max.apply(null, sp) || 1;
    return { outcome: o, outcomeIndex: qz.result.outcome, temperament: tp, temperamentIndex: BY[tp.id] + 1, epithet: tp.epithet, wheel: sp.map(function (x) { return Math.max(0, x) / max; }),
      byFaceoff: qz.result.byFaceoff, tied: qz.result.tied ? qz.result.tied.map(function (i) { return qz.outcomes[i].name; }) : [], answers: qz.answers.slice() };
  }

  return { VERSION: '1.0.0', TEMPERAMENTS: T, IDS: IDS, BY: BY, BANK: BANK, hashString: hashString, mix: mix, rng: rng, shuffle: shuffle,
    zero: zero, fromWeights: fromWeights, cosine: cosine, noteProfile: noteProfile, statShape: statShape, classProfiles: classProfiles,
    actorProfiles: actorProfiles, houseProfiles: houseProfiles, relevant: relevant, draw: draw, bank: bank, createQuiz: createQuiz,
    current: current, offered: offered, spokes: spokes, standings: standings, faceoff: faceoff, answer: answer, temperamentOf: temperamentOf, result: result, TIE: TIE };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = TemperamentCore;
