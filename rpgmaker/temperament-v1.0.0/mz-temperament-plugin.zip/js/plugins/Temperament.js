//=============================================================================
// Temperament.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Temperament 3/3 - personality quizzes that sort the player into one of YOUR classes, actors or houses.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * Temperament
 * ============================================================================
 *
 * A personality quiz for your game. The player answers situational questions
 * ("A rope bridge sways over a gorge...") where no answer is right, and is
 * sorted into one of YOUR outcomes:
 *
 *   classes  - the classes you list; each class's temperament is read from
 *              its own parameter curves (compared with the other classes you
 *              list) and from the skills it learns.
 *   actors   - the actors you list, read through their class.
 *   houses   - named houses you write in the parameters, each with one or
 *              more temperaments ("Gentle 2, Wise 1").
 *
 * A notetag overrides the reading on a class or an actor:
 *   <Temperament: Gentle>            or   <Temperament: Bold 2, Daring 1>
 * The twelve temperaments: Steadfast, Bold, Fierce, Proud, Loyal, Gentle,
 * Calm, Wise, Curious, Cunning, Daring, Lucky.
 *
 * A bank of 44 questions is built in, and you can add your own. Each quiz
 * draws a seeded, balanced set from the bank so every outcome stays
 * reachable. When two or more outcomes tie, one more question is asked
 * between the tied outcomes only: a tie is never decided silently.
 *
 * The reveal: a twelve-spoke wheel fills from the player's answers, the
 * strongest spoke flares, and a card turns over showing the outcome's face
 * (an actor's face, or a house's face if you set one), its name and the
 * player's epithet ("the Calm"). Six stages are drawn by the plugin: the
 * Dreaming Void, the Fortune-Teller's Tent, the Shrine of Charms, the Guild
 * Hall at Night, Under the Starfield and the Sorting Hall.
 *
 * ----------------------------------------------------------------------------
 * INSTALLING
 * ----------------------------------------------------------------------------
 * Copy TemperamentCore.js, TemperamentDraw.js and Temperament.js into
 * js/plugins and enable all three. Any order works.
 *
 * ----------------------------------------------------------------------------
 * USING IT
 * ----------------------------------------------------------------------------
 * Add the plugin command "Start Temperament Quiz" to an event. The event
 * waits while the quiz runs. When it is over:
 *   - the outcome's id goes to the variable you choose (the class id, the
 *     actor id, or the house's number in the list, from 1);
 *   - the player's temperament goes to another variable, 1 to 12 in the
 *     order above;
 *   - the switch you choose is turned ON (the quiz was completed), and a
 *     second switch tells you whether a tie question decided it;
 *   - classes: optionally the party leader changes to the sorted class;
 *   - actors: optionally the sorted actor joins the party, or replaces the
 *     party leader (for a "who are you?" opening before the first map).
 *
 * SCRIPT CALLS
 *   Temperament.lastResult()  ->  { source, outcomeId, outcomeName,
 *       temperament, temperamentIndex, epithet, byFaceoff } or null.
 *       It is kept in the save file.
 *   Temperament.start({ source: 'houses', questions: 8 })  starts a quiz
 *       from a script, with the same argument names as the command.
 *
 * CONTROLS: arrow keys choose an answer, OK picks it; or click / tap an
 * answer. On the reveal, OK or a click leaves.
 *
 * ----------------------------------------------------------------------------
 * COMPATIBILITY
 * ----------------------------------------------------------------------------
 * Temperament adds its own scene and replaces nothing. It extends two engine
 * methods, each by saving the original and calling it: Game_System.initialize
 * (its save record) and Game_Interpreter.updateWaitMode (so the event waits
 * while the quiz runs).
 *
 * ============================================================================
 * TERMS OF USE
 * ============================================================================
 * Commercial and non-commercial use permitted in RPG Maker projects, credit
 * appreciated but not required. Do not redistribute the source as an asset
 * pack. The code and the question text were written with AI assistance.
 * ============================================================================
 *
 * @param pickSe
 * @text Sound: moving between answers
 * @type file
 * @dir audio/se
 * @default Cursor1
 *
 * @param answerSe
 * @text Sound: an answer chosen
 * @type file
 * @dir audio/se
 * @default Decision1
 *
 * @param revealSe
 * @text Sound: the reveal
 * @type file
 * @dir audio/se
 * @default Chime2
 *
 * @param houses
 * @text Houses
 * @desc The outcomes for source "houses". Each has a name and its temperaments, e.g. "Gentle 2, Wise 1".
 * @type struct<House>[]
 * @default ["{\"name\":\"Hearth\",\"temperaments\":\"Gentle 2, Loyal 1\",\"face\":\"\",\"faceIndex\":\"0\"}","{\"name\":\"Ember\",\"temperaments\":\"Bold 2, Fierce 1\",\"face\":\"\",\"faceIndex\":\"0\"}","{\"name\":\"Tide\",\"temperaments\":\"Calm 2, Wise 1\",\"face\":\"\",\"faceIndex\":\"0\"}","{\"name\":\"Gale\",\"temperaments\":\"Daring 2, Cunning 1\",\"face\":\"\",\"faceIndex\":\"0\"}"]
 *
 * @param questions
 * @text Your own questions
 * @desc Added to the built-in bank. Each answer has a text and a lean, e.g. "Bold 2" or "Calm 1, Wise 1".
 * @type struct<Question>[]
 * @default []
 *
 * @param builtIn
 * @text Use the built-in questions
 * @type boolean
 * @default true
 *
 * @command start
 * @text Start Temperament Quiz
 * @desc Ask the questions and sort the player into an outcome. The event waits until it is over.
 *
 * @arg source
 * @text Sort into
 * @type select
 * @option houses
 * @option classes
 * @option actors
 * @default houses
 *
 * @arg classIds
 * @text Classes (source: classes)
 * @desc Blank = every named class in the database.
 * @type class[]
 * @default []
 *
 * @arg actorIds
 * @text Actors (source: actors)
 * @desc Blank = every named actor in the database.
 * @type actor[]
 * @default []
 *
 * @arg questions
 * @text Questions
 * @type number
 * @min 4
 * @max 20
 * @default 8
 *
 * @arg stage
 * @text Stage
 * @type select
 * @option auto
 * @option dream
 * @option tent
 * @option shrine
 * @option guild
 * @option stars
 * @option hall
 * @default auto
 *
 * @arg resultVariable
 * @text Variable: outcome id
 * @type variable
 * @default 0
 *
 * @arg temperamentVariable
 * @text Variable: temperament (1-12)
 * @type variable
 * @default 0
 *
 * @arg doneSwitch
 * @text Switch: quiz completed
 * @type switch
 * @default 0
 *
 * @arg faceoffSwitch
 * @text Switch: decided by a tie question
 * @type switch
 * @default 0
 *
 * @arg changeClass
 * @text Classes: change the leader's class
 * @type boolean
 * @default false
 *
 * @arg keepExp
 * @text Classes: keep EXP on class change
 * @type boolean
 * @default true
 *
 * @arg partyEffect
 * @text Actors: party change
 * @type select
 * @option none
 * @option join
 * @option replaceLeader
 * @default none
 *
 * @arg seed
 * @text Seed (optional)
 * @desc Blank = different questions every time. A number or word = the same quiz every time.
 * @default
 */
/*~struct~House:
 * @param name
 * @text Name
 * @default House
 *
 * @param temperaments
 * @text Temperaments
 * @desc One or more of the twelve, with an optional weight: "Gentle 2, Wise 1".
 * @default Steadfast
 *
 * @param face
 * @text Face image (optional)
 * @type file
 * @dir img/faces
 * @default
 *
 * @param faceIndex
 * @text Face index
 * @type number
 * @min 0
 * @max 7
 * @default 0
 */
/*~struct~Question:
 * @param text
 * @text Question
 * @default
 *
 * @param answerA
 * @text Answer A
 * @default
 *
 * @param leanA
 * @text Answer A leans toward
 * @default
 *
 * @param answerB
 * @text Answer B
 * @default
 *
 * @param leanB
 * @text Answer B leans toward
 * @default
 *
 * @param answerC
 * @text Answer C (optional)
 * @default
 *
 * @param leanC
 * @text Answer C leans toward
 * @default
 *
 * @param answerD
 * @text Answer D (optional)
 * @default
 *
 * @param leanD
 * @text Answer D leans toward
 * @default
 */

var Temperament = Temperament || {};

(function (M) {
  'use strict';
  var NAME = 'Temperament', SCHEMA = 1;
  var raw = (typeof PluginManager !== 'undefined') ? PluginManager.parameters(NAME) : {};
  function num(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; var n = Number(v); return isFinite(n) ? n : d; }
  function str(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; return String(v).trim(); }
  function bool(v, d) { if (v === true || v === false) return v; var s = str(v, ''); return s === '' ? d : s === 'true'; }
  /** An id list as the editor stores it ("[\"1\",\"3\"]"), or a plain array. Ids are compared against zero, never tested for truth (wing §16). */
  function ids(v) { var a = v; if (!Array.isArray(a)) { try { a = JSON.parse(v || '[]'); } catch (e) { a = []; } } return Array.isArray(a) ? a.map(Number).filter(function (n) { return isFinite(n) && n > 0; }) : []; }
  /** A struct<T>[] parameter is a JSON string of JSON strings (wing §16). */
  function structs(v) { var a; try { a = JSON.parse(v || '[]'); } catch (e) { return []; } if (!Array.isArray(a)) return []; return a.map(function (s) { if (s && typeof s === 'object') return s; try { return JSON.parse(s); } catch (e) { return null; } }).filter(Boolean); }
  /** A sound the buyer CLEARED is silence; only a parameter the editor never wrote takes the default. */
  function sound(v, d) { return v === undefined || v === null ? d : String(v).trim(); }
  M.params = { pickSe: sound(raw.pickSe, 'Cursor1'), answerSe: sound(raw.answerSe, 'Decision1'), revealSe: sound(raw.revealSe, 'Chime2'), houses: structs(raw.houses), questions: structs(raw.questions), builtIn: bool(raw.builtIn, true) };
  M.structs = structs;
  var _deps = null;
  function deps() {
    if (_deps) return _deps;
    var core = (typeof TemperamentCore !== 'undefined') ? TemperamentCore : null, draw = (typeof TemperamentDraw !== 'undefined') ? TemperamentDraw : null;
    if (!core || !draw) { if (!deps._w) { deps._w = true; console.error('Temperament: enable TemperamentCore.js and TemperamentDraw.js in the Plugin Manager too.'); } return null; }
    _deps = { core: core, draw: draw }; return _deps;
  }
  M.deps = deps;
  function se(name) { if (name) AudioManager.playSe({ name: name, volume: 85, pitch: 100, pan: 0 }); }
  M.se = se;
  function fresh() { return { v: SCHEMA, played: 0, last: null }; }
  /** The save record: plain data only, so it survives JsonEx. */
  M.record = function () {
    if (typeof $gameSystem === 'undefined' || !$gameSystem) return fresh();
    var s = $gameSystem._csafTemperament; if (!s || s.v == null) { s = fresh(); $gameSystem._csafTemperament = s; } return s;
  };
  var _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () { _Game_System_initialize.call(this); this._csafTemperament = fresh(); };
  /** The last quiz's result, from the save file, or null. */
  M.lastResult = function () { var l = M.record().last; return l ? JSON.parse(JSON.stringify(l)) : null; };

  /** "Bold 2, Daring 1" as answer weights { bold: 2, daring: 1 }; unknown names are dropped. */
  M.lean = function (text) {
    var d = deps(), w = {}; if (!d) return w;
    String(text || '').split(/[,;]/).forEach(function (part) {
      var m = /^\s*([a-z]+)\s*(-?\d+(?:\.\d+)?)?\s*$/i.exec(part); if (!m) return;
      var id = m[1].toLowerCase(); if (d.core.IDS.indexOf(id) < 0) return;
      w[id] = (w[id] || 0) + (m[2] != null ? Number(m[2]) : 1);
    });
    return w;
  };
  /** The buyer's questions, from the parameter structs, in the core's shape. */
  M.customQuestions = function (list) {
    return (list || M.params.questions).map(function (s) {
      var answers = [];
      ['A', 'B', 'C', 'D'].forEach(function (k) { var t = str(s['answer' + k], ''); if (t !== '') answers.push({ text: t, w: M.lean(s['lean' + k]) }); });
      return { text: str(s.text, ''), answers: answers };
    });
  };
  /** The questions this game can ask: the built-in bank and the buyer's own. Rejected questions are reported once. */
  M.questionBank = function () {
    var d = deps(); if (!d) return [];
    var b = d.core.bank(M.customQuestions(), M.params.builtIn);
    if (b.rejected.length && !M._warnedQ) { M._warnedQ = true; b.rejected.forEach(function (r) { console.warn('Temperament: your question ' + (r.index + 1) + ' was skipped: ' + r.why + '.'); }); }
    return b.questions;
  };
  function named(list) { var out = []; for (var i = 1; i < (list || []).length; i++) if (list[i] && String(list[i].name || '').trim() !== '') out.push(i); return out; }
  /** The outcomes for a request, read from the database or the houses parameter. */
  M.outcomes = function (req) {
    var d = deps(); if (!d) return [];
    if (req.source === 'classes') return d.core.classProfiles($dataClasses, req.classIds.length ? req.classIds : named($dataClasses), $dataSkills);
    if (req.source === 'actors') return d.core.actorProfiles($dataActors, req.actorIds.length ? req.actorIds : named($dataActors), $dataClasses, $dataSkills);
    return d.core.houseProfiles(M.params.houses);
  };
  M.request = function (args) {
    var d = deps(); if (!d) return null; args = args || {};
    var seedText = str(args.seed, ''), source = str(args.source, 'houses'), stage = str(args.stage, 'auto'), effect = str(args.partyEffect, 'none');
    var seed = seedText === '' ? d.core.mix(d.core.hashString('temperament') ^ (M.record().played * 7919), (typeof $gameSystem !== 'undefined' && $gameSystem ? $gameSystem.playtime() : 0) >>> 0)
      : (/^\d+$/.test(seedText) ? (Number(seedText) >>> 0) : d.core.hashString(seedText));
    return { seed: seed, source: ['houses', 'classes', 'actors'].indexOf(source) >= 0 ? source : 'houses', classIds: ids(args.classIds), actorIds: ids(args.actorIds),
      count: Math.max(4, Math.min(20, Math.floor(num(args.questions, 8)))), stage: d.draw.STAGES.indexOf(stage) >= 0 ? stage : null,
      resultVariable: Math.max(0, Math.floor(num(args.resultVariable, 0))), temperamentVariable: Math.max(0, Math.floor(num(args.temperamentVariable, 0))),
      doneSwitch: Math.max(0, Math.floor(num(args.doneSwitch, 0))), faceoffSwitch: Math.max(0, Math.floor(num(args.faceoffSwitch, 0))),
      changeClass: bool(args.changeClass, false), keepExp: bool(args.keepExp, true), partyEffect: ['none', 'join', 'replaceLeader'].indexOf(effect) >= 0 ? effect : 'none' };
  };
  M.start = function (opts) {
    var req = opts && opts.seed != null && opts.classIds ? opts : M.request(opts || {});
    if (!req) return false;
    var outs = M.outcomes(req);
    // fewer than two outcomes cannot be a sort: start nothing (and say so once) rather than a quiz with one answer
    if (outs.length < 2) { if (!M._warnedFew) { M._warnedFew = true; console.warn('Temperament: source "' + req.source + '" gave ' + outs.length + ' outcome(s); a quiz needs at least two. No quiz started.'); } return false; }
    SceneManager.push(Scene_Temperament); SceneManager.prepareNextScene(req, outs); return true;
  };
  /**
   * Hand out a finished quiz: variables, switches, the class change or party change, and the save record.
   * Save-safe: every change goes through the engine's own Game_* methods, which the save file already carries.
   */
  M.apply = function (req, res) {
    var o = res.outcome, rec = M.record();
    if (req.resultVariable > 0) $gameVariables.setValue(req.resultVariable, o.id);
    if (req.temperamentVariable > 0) $gameVariables.setValue(req.temperamentVariable, res.temperamentIndex);
    if (req.doneSwitch > 0) $gameSwitches.setValue(req.doneSwitch, true);
    if (req.faceoffSwitch > 0) $gameSwitches.setValue(req.faceoffSwitch, !!res.byFaceoff);
    if (req.source === 'classes' && req.changeClass) { var lead = $gameParty.leader(); if (lead && lead.currentClass().id !== o.id) lead.changeClass(o.id, req.keepExp); }
    if (req.source === 'actors' && req.partyEffect !== 'none') {
      var before = $gameParty.leader(), has = $gameParty.members().some(function (a) { return a.actorId() === o.id; });
      if (!has) $gameParty.addActor(o.id);
      if (req.partyEffect === 'replaceLeader' && before && before.actorId() !== o.id) {
        // the new actor goes to the front first, THEN the old leader leaves, so the party is never empty
        var at = $gameParty._actors.indexOf(o.id); if (at > 0) $gameParty.swapOrder(0, at);
        $gameParty.removeActor(before.actorId());
      }
    }
    rec.played++;
    rec.last = { source: req.source, outcomeId: o.id, outcomeName: o.name, temperament: res.temperament.id, temperamentIndex: res.temperamentIndex, epithet: res.epithet, byFaceoff: !!res.byFaceoff };
  };
  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) PluginManager.registerCommand(NAME, 'start', function (args) { if (M.start(M.request(args))) this.setWaitMode('temperament'); });
  var _updateWaitMode = Game_Interpreter.prototype.updateWaitMode;
  Game_Interpreter.prototype.updateWaitMode = function () {
    if (this._waitMode === 'temperament') { if (SceneManager._scene instanceof Scene_Temperament || SceneManager._nextScene instanceof Scene_Temperament) return true; this._waitMode = ''; return false; }
    return _updateWaitMode.call(this);
  };
  M.VERSION = '1.0.0';
}(Temperament));

//=============================================================================
// Scene_Temperament
//=============================================================================

function Scene_Temperament() { this.initialize.apply(this, arguments); }
Scene_Temperament.prototype = Object.create(Scene_Message.prototype);
Scene_Temperament.prototype.constructor = Scene_Temperament;
Scene_Temperament.LABELS = 'ABCDEFGHIJKL';
Scene_Temperament.PAUSE = 16;       // frames a picked answer stays lit before the next question
Scene_Temperament.FILL = 84;        // frames the wheel takes to fill
Scene_Temperament.FILL_STEPS = 24;  // the wheel is redrawn this many times while it fills, never every frame
Scene_Temperament.FLIP = 30;        // frames the card takes to turn over
// the question card; the tiles fill the frame below it (review 2026-10-20: the bottom 28% of the frame stood empty)
Scene_Temperament.CARD = { x: 58, y: 64, w: 700, h: 210 };
Scene_Temperament.prototype.prepare = function (req, outcomes) { this._req = req; this._outs = outcomes; };

Scene_Temperament.prototype.create = function () {
  Scene_Message.prototype.create.call(this);
  var d = Temperament.deps(), C = d.core, req = this._req;
  this._d = d;
  this._bank = Temperament.questionBank();
  this._quiz = C.createQuiz(C.draw(this._bank, this._outs, req.count, C.mix(req.seed, 0x51)), this._outs, req.seed);
  this._stage = req.stage || d.draw.STAGES[req.seed % d.draw.STAGES.length];
  // every face the reveal can show is loaded before the scene starts (Scene_Base.isReady waits on ImageManager)
  this._faces = this._outs.map(function (o) { return Scene_Temperament.faceOf(o, req.source); });
  this._faces.forEach(function (f) { if (f) ImageManager.loadFace(f.name); });
  this._layer = new Sprite(); this.addChild(this._layer);
  this.createWindowLayer(); this.createAllWindows();
  this._mode = 'loading'; this._t = 0; this._sel = 0; this._picked = -1; this._shown = -1;
};
/** The face an outcome shows on the reveal: an actor's own, a house's if set, or for a class the first actor who starts in it. */
Scene_Temperament.faceOf = function (o, source) {
  if (o.face) return { name: o.face, index: o.faceIndex || 0 };
  if (source === 'classes') for (var i = 1; i < $dataActors.length; i++) { var a = $dataActors[i]; if (a && a.classId === o.id && a.faceName) return { name: a.faceName, index: a.faceIndex || 0 }; }
  return null;
};
Scene_Temperament.prototype.start = function () {
  Scene_Message.prototype.start.call(this);
  var D = this._d.draw, W = Graphics.width, H = Graphics.height, bmp = new Bitmap(W, H);
  D.backdrop(bmp.context, W, H, this._stage, this._req.seed); bmp._baseTexture.update();
  this._layer.addChild(new Sprite(bmp));
  // the motes are drawn ONCE onto a layer twice the screen's height that drifts upward; a frame moves a sprite, never redraws one
  var mb = new Bitmap(W, H * 2); D.motes(mb.context, W, H, this._stage, 2.5, this._req.seed); mb.context.drawImage(mb._canvas, 0, 0, W, H, 0, H, W, H); mb._baseTexture.update();
  this._motes = new Sprite(mb); this._layer.addChild(this._motes);
  this._card = new Sprite(new Bitmap(W, 310)); this._layer.addChild(this._card);
  this._banner = new Sprite(new Bitmap(W, 80)); this._banner.y = Scene_Temperament.CARD.y + Scene_Temperament.CARD.h + 12; this._banner.visible = false; this._layer.addChild(this._banner);
  this._tiles = [];
  for (var i = 0; i < 12; i++) { var s = new Sprite(); s.visible = false; this._layer.addChild(s); this._tiles.push(s); }
  this._wheel = new Sprite(new Bitmap(440, 440)); this._wheel.x = Math.round(W * 0.31) - 220; this._wheel.y = Math.round(H / 2) - 220; this._wheel.visible = false; this._layer.addChild(this._wheel);
  this._result = new Sprite(); this._result.anchor.x = 0.5; this._result.anchor.y = 0.5; this._result.x = Math.round(W * 0.74); this._result.y = Math.round(H / 2) - 6; this._result.visible = false; this._layer.addChild(this._result);
  this._pips = new Sprite(new Bitmap(W, 40)); this._pips.y = H - 58; this._layer.addChild(this._pips);
  this._hint = new Sprite(new Bitmap(W, 40)); this._hint.y = H - 44; this._hint.visible = false; this._layer.addChild(this._hint);
  this.ask(); this.startFadeIn(this.fadeSpeed(), false);
};

/** The tile rectangles for `n` answers: two columns, rows sized to fit (a face-off between many outcomes has more than four). */
Scene_Temperament.prototype.layout = function (n, faceoff) {
  var W = Graphics.width, H = Graphics.height, C = Scene_Temperament.CARD, top = C.y + C.h + (faceoff ? 98 : 26), rows = Math.ceil(n / 2), w = (W - 116 - 12) / 2;
  var h = Math.min(84, Math.floor((H - 70 - top) / rows) - 14), out = [];
  for (var i = 0; i < n; i++) out.push({ x: 58 + (i % 2) * (w + 12), y: top + Math.floor(i / 2) * (h + 14), w: w, h: h });
  return out;
};
Scene_Temperament.prototype.ask = function () {
  var D = this._d.draw, C = this._d.core, qz = this._quiz, q = C.current(qz), W = Graphics.width, b = this._card.bitmap;
  b.clear();
  var number = qz.faceoff ? 0 : qz.index + 1;
  var CR = Scene_Temperament.CARD; this._cardInfo = D.card(b.context, CR.x, CR.y, CR.w, CR.h, q.text, this._stage, number, qz.questions.length); b._baseTexture.update();
  var pb = this._pips.bitmap; pb.clear(); D.pips(pb.context, W / 2, 20, qz.questions.length, qz.faceoff ? qz.questions.length : qz.index, this._stage); pb._baseTexture.update();
  this._banner.visible = !!qz.faceoff;
  if (qz.faceoff) {
    var outs = this._outs, names = qz.faceoff.map.map(function (i) { return outs[i].name; }), temps = qz.faceoff.map.map(function (i) { return C.TEMPERAMENTS[Scene_Temperament.topTemperament(outs[i].profile)]; });
    var bb = this._banner.bitmap; bb.clear(); D.faceoffBanner(bb.context, 58, 4, W - 116, names, temps, this._stage, Scene_Temperament.LABELS.slice(0, names.length).split('')); bb._baseTexture.update();
  }
  this._rects = this.layout(q.answers.length, !!qz.faceoff);
  for (var i = 0; i < 12; i++) {
    var s = this._tiles[i], r = this._rects[i];
    s.visible = !!r; if (!r) continue;
    if (!s.bitmap || s.bitmap.width !== Math.ceil(r.w) + 4 || s.bitmap.height !== r.h + 4) s.bitmap = new Bitmap(Math.ceil(r.w) + 4, r.h + 4);
    s.x = r.x - 2; s.y = r.y - 2;
  }
  this._sel = 0; this._picked = -1; this.drawTiles();
  this._mode = 'ask'; this._t = 0;
};
Scene_Temperament.topTemperament = function (profile) { var best = 0; for (var t = 1; t < 12; t++) if (profile[t] > profile[best]) best = t; return best; };
Scene_Temperament.prototype.drawTiles = function () {
  var D = this._d.draw, q = this._d.core.current(this._quiz), L = Scene_Temperament.LABELS;
  for (var i = 0; i < this._rects.length; i++) {
    var b = this._tiles[i].bitmap, r = this._rects[i], st = this._picked >= 0 ? (i === this._picked ? 'picked' : 'dim') : (i === this._sel ? 'chosen' : 'idle');
    b.clear(); D.tile(b.context, 2, 2, r.w, r.h, L[i], q.answers[i].text, st, this._stage); b._baseTexture.update();
  }
};

Scene_Temperament.prototype.update = function () {
  Scene_Message.prototype.update.call(this);
  if (this._motes) { this._motes.y -= 0.25; if (this._motes.y <= -Graphics.height) this._motes.y += Graphics.height; }
  if (this._mode === 'loading' || this.isBusy()) return;
  this._t++;
  if (this._mode === 'ask') this.updateAsk();
  else if (this._mode === 'picked' && this._t >= Scene_Temperament.PAUSE) this.advance();
  else if (this._mode === 'fill') this.updateFill();
  else if (this._mode === 'flip') this.updateFlip();
  else if (this._mode === 'done' && this._t > 20 && (Input.isTriggered('ok') || TouchInput.isTriggered())) this.leave();
};
Scene_Temperament.prototype.updateAsk = function () {
  var n = this._rects.length, moved = -1;
  if (Input.isTriggered('right') || Input.isTriggered('left')) { moved = this._sel ^ 1; if (moved >= n) moved = -1; }
  if (Input.isTriggered('down')) { var dn = this._sel + 2; if (dn >= n) dn = this._sel % 2; moved = dn; }
  if (Input.isTriggered('up')) { var up = this._sel - 2; if (up < 0) { up = (Math.ceil(n / 2) - 1) * 2 + (this._sel % 2); if (up >= n) up -= 2; } moved = up; }
  if (moved >= 0 && moved !== this._sel) { this._sel = moved; this.drawTiles(); Temperament.se(Temperament.params.pickSe); }
  var pick = -1;
  if (TouchInput.isTriggered()) for (var i = 0; i < n; i++) { var r = this._rects[i]; if (TouchInput.x >= r.x && TouchInput.x < r.x + r.w && TouchInput.y >= r.y && TouchInput.y < r.y + r.h) pick = i; }
  if (Input.isTriggered('ok')) pick = this._sel;
  if (pick < 0) return;
  this._picked = pick; this.drawTiles(); Temperament.se(Temperament.params.answerSe);
  this._mode = 'picked'; this._t = 0;
};
Scene_Temperament.prototype.advance = function () {
  var st = this._d.core.answer(this._quiz, this._picked, this._bank);
  if (st === 'done') this.reveal(); else this.ask();
};
/** The reveal: the question layer goes, the wheel fills spoke by spoke, the strongest spoke flares, the card turns over. */
Scene_Temperament.prototype.reveal = function () {
  var C = this._d.core, D = this._d.draw;
  this._res = C.result(this._quiz);
  this._card.visible = false; this._banner.visible = false; this._pips.visible = false; for (var i = 0; i < 12; i++) this._tiles[i].visible = false;
  this._wheel.visible = true; this._shown = -1; this.drawWheel(0, null);
  var face = this._faces[this._res.outcomeIndex], picture = null;
  if (face) {
    var f = ImageManager.loadFace(face.name), fw = ImageManager.faceWidth, fh = ImageManager.faceHeight, fi = face.index;
    picture = function (g, x, y, size) { g.drawImage(f._canvas || f._image, (fi % 4) * fw, Math.floor(fi / 4) * fh, fw, fh, x, y, size, size); };
  }
  var cw = 300, chh = 470;
  this._front = new Bitmap(cw + 40, chh + 40); this._frontInfo = D.resultFront(this._front.context, 20, 20, cw, chh, this._res.outcome.name, this._res.epithet, this._res.temperament, this._stage, picture, C.TEMPERAMENTS[Scene_Temperament.topTemperament(this._res.outcome.profile)]); this._front._baseTexture.update();
  this._back = new Bitmap(cw + 40, chh + 40); D.resultBack(this._back.context, 20, 20, cw, chh, this._stage); this._back._baseTexture.update();
  this._result.bitmap = this._back; this._result.scale.x = 1; this._result.visible = true; this._shadeTone = [0, 0, 0, 0];
  this._mode = 'fill'; this._t = 0;
};
Scene_Temperament.prototype.drawWheel = function (progress, flare) {
  var step = Math.round(progress * Scene_Temperament.FILL_STEPS) + (flare == null ? 0 : 1000);
  if (step === this._shown) return;                  // a redraw (and a texture upload) only when the wheel visibly moves
  this._shown = step;
  var b = this._wheel.bitmap; b.clear(); this._d.draw.wheel(b.context, 220, 220, 150, this._res.wheel, this._d.core.TEMPERAMENTS, step % 1000 / Scene_Temperament.FILL_STEPS, flare); b._baseTexture.update();
};
Scene_Temperament.prototype.updateFill = function () {
  var p = Math.min(1, this._t / Scene_Temperament.FILL);
  this.drawWheel(p, null);
  if (p >= 1) { this.drawWheel(1, this._res.temperamentIndex - 1); Temperament.se(Temperament.params.revealSe); this._mode = 'flip'; this._t = 0; }
};
Scene_Temperament.prototype.updateFlip = function () {
  var half = Scene_Temperament.FLIP / 2, t = this._t;
  if (t < half) this._result.scale.x = 1 - t / half;
  else { if (this._result.bitmap !== this._front) this._result.bitmap = this._front; this._result.scale.x = Math.min(1, (t - half) / half); }
  // edge-on is darker: the card is lit from the front (review 2026-10-20: a flat squash read as a cheap turn)
  this._shadeTone[3] = Math.round(150 * (1 - this._result.scale.x)); this._result.setBlendColor(this._shadeTone);
  if (t >= Scene_Temperament.FLIP) {
    this._result.scale.x = 1; this._shadeTone[3] = 0; this._result.setBlendColor(this._shadeTone);
    var hb = this._hint.bitmap, D = this._d.draw; hb.clear(); D.hint(hb.context, 'OK to continue', Graphics.width / 2, 20, this._stage); hb._baseTexture.update(); this._hint.visible = true;
    this._mode = 'done'; this._t = 0;
  }
};
Scene_Temperament.prototype.leave = function () { Temperament.apply(this._req, this._res); this._mode = 'left'; this.popScene(); };
Scene_Temperament.prototype.stop = function () { Scene_Message.prototype.stop.call(this); this.startFadeOut(this.fadeSpeed(), false); };
