//=============================================================================
// TemperamentDraw.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Temperament 2/3 - the drawing kit: six stages, question cards, answer tiles, twelve crests, the temperament wheel, the result card. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The drawing kit for Temperament. No parameters or commands of its own. It
 * knows nothing about RPG Maker: it draws on a canvas 2D context. The only
 * pictures it does not draw are the ones your database already names (an
 * actor's face, a battler), which the scene hands it.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var TemperamentDraw = (function () {
  'use strict';
  var TAU = Math.PI * 2;
  var FONT = '"Palatino Linotype", "Book Antiqua", Palatino, Georgia, serif';

  function hex(c) { var n = parseInt(String(c).slice(1), 16); if (!/^#[0-9a-f]{6}$/i.test(String(c))) return null; return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  function toHex(rgb) { return '#' + rgb.map(function (v) { var s = Math.max(0, Math.min(255, Math.round(v))).toString(16); return s.length < 2 ? '0' + s : s; }).join(''); }
  function shade(c, k) { var h = hex(c) || [128, 128, 128]; return toHex(h.map(function (v) { return k >= 0 ? v + (255 - v) * k : v * (1 + k); })); }
  function rgba(c, a) { var h = hex(c) || [128, 128, 128]; return 'rgba(' + h[0] + ',' + h[1] + ',' + h[2] + ',' + a + ')'; }
  function roundRect(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
  function text(g, s, x, y, size, color, align, weight, font) { g.font = (weight || '700') + ' ' + size + 'px ' + (font || FONT); g.fillStyle = color; g.textAlign = align || 'left'; g.textBaseline = 'middle'; g.fillText(s, x, y); }
  /** Wrap `s` into lines no wider than w; shrinks the size until it fits `maxLines` and SAYS when it could not. */
  function wrap(g, s, w, size, maxLines, weight) {
    for (var sz = size; sz >= 12; sz--) {
      g.font = (weight || '700') + ' ' + sz + 'px ' + FONT;
      var words = String(s).split(/\s+/), lines = [], cur = '';
      for (var i = 0; i < words.length; i++) { var t = cur ? cur + ' ' + words[i] : words[i]; if (g.measureText(t).width > w && cur) { lines.push(cur); cur = words[i]; } else cur = t; }
      if (cur) lines.push(cur);
      if (lines.length <= maxLines && lines.every(function (l) { return g.measureText(l).width <= w; })) return { lines: lines, size: sz, squeezed: sz < size };
    }
    return { lines: [String(s)], size: 12, squeezed: true, overflow: true };
  }
  function rand(seed) { var s = (seed >>> 0) || 1; return function () { s = (s + 0x6D2B79F5) >>> 0; var t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  /**
   * Pre-drawn pieces, keyed by everything that changes their pixels, so a piece is drawn once and copied after that.
   * 2026-10-21, counted in the engine (_probe/frame_counts.js): every crest made a NEW canvas, twelve per wheel redraw,
   * 300 canvases during one reveal's wheel fill; with this cache, 0. The copy reproduces the pixels byte for byte
   * (_probe/cache_identity.js renders every piece with the old and new kit). Without a document (Node tests) nothing is cached.
   */
  var _cache = {}, _cacheSize = 0;
  function cached(key, w, h, paint) {
    var c = _cache[key];
    if (c) return c;
    if (typeof document === 'undefined') return null;
    if (_cacheSize >= 160) { _cache = {}; _cacheSize = 0; }   // bounded: sizes and stages are few, but a buyer may draw anything
    c = document.createElement('canvas'); c.width = w; c.height = h; paint(c.getContext('2d'));
    _cache[key] = c; _cacheSize++;
    return c;
  }

  /* ── THE TWELVE CRESTS ────────────────────────────────────────────────────────────────────────────────────
   * Each a single, ASYMMETRIC charge (Icon_Doctrine §22a: vertical symmetry is the hazard) on a round seal, drawn in
   * a unit box [-1, 1] and fitted by the caller. Charges are distinct OBJECTS, never one shape in twelve colours. */
  var CHARGE = {
    steadfast: function (g) { g.beginPath(); g.moveTo(-0.55, -0.62); g.lineTo(0.55, -0.62); g.lineTo(0.55, 0.05); g.quadraticCurveTo(0.5, 0.55, 0, 0.78); g.quadraticCurveTo(-0.5, 0.55, -0.55, 0.05); g.closePath(); g.fill(); g.globalCompositeOperation = 'destination-out'; g.fillRect(-0.55, -0.18, 1.1, 0.16); g.fillRect(-0.06, -0.62, 0.16, 0.9); g.globalCompositeOperation = 'source-over'; },
    bold: function (g) { g.beginPath(); g.moveTo(-0.1, 0.78); g.bezierCurveTo(-0.7, 0.6, -0.62, 0.0, -0.3, -0.25); g.bezierCurveTo(-0.32, 0.05, -0.18, 0.12, -0.1, 0.12); g.bezierCurveTo(-0.25, -0.3, 0.0, -0.6, 0.12, -0.85); g.bezierCurveTo(0.2, -0.45, 0.62, -0.25, 0.55, 0.2); g.bezierCurveTo(0.52, 0.5, 0.35, 0.72, -0.1, 0.78); g.fill(); },
    fierce: function (g) { for (var i = 0; i < 3; i++) { var o = (i - 1) * 0.36, L = 0.8 - Math.abs(i - 1) * 0.16; g.save(); g.translate(o * 0.72 + 0.04, -o * 0.72); g.rotate(-0.72); g.beginPath(); g.moveTo(0.02, -L); g.quadraticCurveTo(0.36, -0.1, 0.0, L); g.quadraticCurveTo(-0.04, 0, 0.02, -L); g.fill(); g.restore(); } },
    proud: function (g) { g.save(); g.rotate(-0.18); g.beginPath(); g.moveTo(-0.7, 0.45); g.lineTo(-0.72, -0.35); g.lineTo(-0.35, 0.02); g.lineTo(-0.02, -0.62); g.lineTo(0.3, 0.02); g.lineTo(0.7, -0.38); g.lineTo(0.68, 0.45); g.closePath(); g.fill(); g.fillRect(-0.72, 0.52, 1.42, 0.16); g.beginPath(); g.arc(-0.02, -0.72, 0.1, 0, TAU); g.fill(); g.restore(); },
    loyal: function (g) { g.beginPath(); g.ellipse(0.05, 0.35, 0.4, 0.32, 0.15, 0, TAU); g.fill(); [[-0.52, -0.08, 0.15], [-0.25, -0.42, 0.16], [0.15, -0.5, 0.16], [0.5, -0.22, 0.15]].forEach(function (p) { g.beginPath(); g.ellipse(p[0], p[1], p[2], p[2] * 1.3, p[0] * 0.6, 0, TAU); g.fill(); }); },
    gentle: function (g) { g.beginPath(); g.moveTo(-0.6, 0.7); g.bezierCurveTo(-0.7, 0.0, -0.1, -0.75, 0.62, -0.72); g.bezierCurveTo(0.6, 0.0, 0.0, 0.6, -0.6, 0.7); g.fill(); g.globalCompositeOperation = 'destination-out'; g.lineWidth = 0.07; g.beginPath(); g.moveTo(-0.5, 0.6); g.quadraticCurveTo(0.0, -0.05, 0.5, -0.6); g.stroke(); g.globalCompositeOperation = 'source-over'; g.lineWidth = 0.1; g.lineCap = 'round'; g.beginPath(); g.moveTo(-0.6, 0.7); g.lineTo(-0.78, 0.86); g.stroke(); },
    calm: function (g) { g.beginPath(); g.arc(-0.05, -0.2, 0.55, 0.9, 5.2); g.arc(0.18, -0.32, 0.42, 4.6, 1.35, true); g.closePath(); g.fill(); g.lineWidth = 0.12; g.lineCap = 'round'; g.beginPath(); g.moveTo(-0.75, 0.62); g.bezierCurveTo(-0.45, 0.45, -0.25, 0.8, 0.0, 0.62); g.bezierCurveTo(0.25, 0.45, 0.45, 0.8, 0.75, 0.6); g.stroke(); },
    wise: function (g) { g.beginPath(); g.moveTo(0, -0.35); g.quadraticCurveTo(-0.4, -0.55, -0.8, -0.38); g.lineTo(-0.8, 0.5); g.quadraticCurveTo(-0.4, 0.34, 0, 0.55); g.quadraticCurveTo(0.4, 0.34, 0.8, 0.5); g.lineTo(0.8, -0.38); g.quadraticCurveTo(0.4, -0.55, 0, -0.35); g.fill(); g.globalCompositeOperation = 'destination-out'; g.lineWidth = 0.06; g.beginPath(); g.moveTo(0, -0.33); g.lineTo(0, 0.52); g.stroke(); for (var i = 0; i < 3; i++) { g.beginPath(); g.moveTo(-0.62, -0.18 + i * 0.2); g.quadraticCurveTo(-0.35, -0.28 + i * 0.2, -0.12, -0.18 + i * 0.2); g.stroke(); } g.globalCompositeOperation = 'source-over'; g.beginPath(); g.moveTo(0.45, -0.45); g.lineTo(0.62, -0.85); g.lineTo(0.7, -0.4); g.fill(); },
    curious: function (g) { g.lineWidth = 0.13; g.lineCap = 'round'; g.beginPath(); for (var a = 0; a < 3.2 * Math.PI; a += 0.08) { var r = 0.06 + a * 0.075, x = Math.cos(a) * r - 0.05, y = Math.sin(a) * r - 0.05; if (a === 0) g.moveTo(x, y); else g.lineTo(x, y); } g.stroke(); g.beginPath(); g.arc(0.48, 0.62, 0.1, 0, TAU); g.fill(); },
    cunning: function (g) { g.beginPath(); g.moveTo(-0.68, -0.72); g.lineTo(-0.3, -0.25); g.lineTo(0.22, -0.28); g.lineTo(0.62, -0.75); g.lineTo(0.6, -0.08); g.quadraticCurveTo(0.5, 0.35, 0.05, 0.72); g.quadraticCurveTo(-0.5, 0.3, -0.66, -0.05); g.closePath(); g.fill(); g.globalCompositeOperation = 'destination-out'; g.beginPath(); g.moveTo(-0.38, -0.02); g.lineTo(-0.12, 0.05); g.lineTo(-0.36, 0.12); g.closePath(); g.fill(); g.beginPath(); g.moveTo(0.36, -0.06); g.lineTo(0.12, 0.04); g.lineTo(0.34, 0.1); g.closePath(); g.fill(); g.globalCompositeOperation = 'source-over'; },
    daring: function (g) { g.lineWidth = 0.11; g.lineCap = 'round'; g.beginPath(); g.moveTo(-0.62, 0.62); g.lineTo(0.5, -0.5); g.stroke(); g.beginPath(); g.moveTo(0.72, -0.72); g.lineTo(0.28, -0.6); g.lineTo(0.6, -0.28); g.closePath(); g.fill(); for (var i = 0; i < 3; i++) { var x = -0.62 + i * 0.12, y = 0.62 - i * 0.12; g.beginPath(); g.moveTo(x, y); g.lineTo(x - 0.22, y - 0.05); g.lineTo(x - 0.1, y - 0.14); g.closePath(); g.fill(); g.beginPath(); g.moveTo(x, y); g.lineTo(x + 0.05, y + 0.22); g.lineTo(x + 0.14, y + 0.1); g.closePath(); g.fill(); } },
    lucky: function (g) { var cx = -0.1, cy = -0.02, r = 0.44; g.lineWidth = 0.27; g.lineCap = 'butt'; g.beginPath(); g.moveTo(cx - r, -0.56); g.lineTo(cx - r, cy); g.arc(cx, cy, r, Math.PI, 0, true); g.lineTo(cx + r, -0.56); g.stroke(); g.lineWidth = 0.27; g.lineCap = 'round'; g.beginPath(); g.moveTo(cx - r, -0.56); g.lineTo(cx - r - 0.1, -0.66); g.moveTo(cx + r, -0.56); g.lineTo(cx + r + 0.1, -0.66); g.stroke(); g.globalCompositeOperation = 'destination-out'; [[cx - r, -0.36], [cx + r, -0.36]].concat([0.82, 0.62, 0.38, 0.18].map(function (k) { return [cx + Math.cos(Math.PI * k) * r, cy + Math.sin(Math.PI * k) * r]; })).forEach(function (pt) { g.beginPath(); g.arc(pt[0], pt[1], 0.065, 0, TAU); g.fill(); }); g.globalCompositeOperation = 'source-over'; var sx = 0.68, sy = -0.12, k = 0.26; g.beginPath(); g.moveTo(sx, sy - k); g.lineTo(sx + k * 0.28, sy - k * 0.28); g.lineTo(sx + k, sy); g.lineTo(sx + k * 0.28, sy + k * 0.28); g.lineTo(sx, sy + k); g.lineTo(sx - k * 0.28, sy + k * 0.28); g.lineTo(sx - k, sy); g.lineTo(sx - k * 0.28, sy - k * 0.28); g.closePath(); g.fill(); },
  };
  /** A crest: the temperament's charge on a round seal. `ink` defaults to a cream that clears AA on every seal colour. */
  function crest(g, id, cx, cy, size, colour, opts) {
    opts = opts || {};
    var col = colour || '#777777', r = size / 2;
    g.save();
    if (!opts.bare) {
      var grad = g.createRadialGradient(cx - r * 0.3, cy - r * 0.35, r * 0.1, cx, cy, r);
      grad.addColorStop(0, shade(col, 0.25)); grad.addColorStop(1, shade(col, -0.35));
      g.fillStyle = grad; g.beginPath(); g.arc(cx, cy, r, 0, TAU); g.fill();
      g.lineWidth = Math.max(1.5, r * 0.07); g.strokeStyle = shade(col, -0.55); g.stroke();
      g.lineWidth = Math.max(1, r * 0.03); g.strokeStyle = rgba('#fff4dc', 0.55); g.beginPath(); g.arc(cx, cy, r * 0.86, 0, TAU); g.stroke();
    }
    // the charge on its own layer, so destination-out cuts only the charge, never the seal; drawn once per (charge, size, ink)
    var k = r * (opts.bare ? 0.95 : 0.6), side = Math.ceil(k * 2 + 4), ink = opts.ink || '#fff4dc', cid = CHARGE[id] ? id : 'steadfast';
    var layer = cached('crest|' + cid + '|' + k + '|' + ink, side, side, function (lg) {
      lg.translate(side / 2, side / 2); lg.scale(k, k); lg.fillStyle = lg.strokeStyle = ink;
      CHARGE[cid](lg);
    });
    if (layer) g.drawImage(layer, cx - side / 2, cy - side / 2);
    g.restore();
  }

  /* ── THE WHEEL ────────────────────────────────────────────────────────────────────────────────────────────
   * Twelve spokes, each a wedge filled from the centre by that temperament's share of the answers. `progress` (0..1)
   * fills them in order, spoke by spoke; `flare` (index) lights the winner. */
  function wheel(g, cx, cy, R, values, temps, progress, flare, labels) {
    var n = temps.length, p = progress == null ? 1 : progress;
    g.save();
    g.fillStyle = 'rgba(14,10,22,0.78)'; g.beginPath(); g.arc(cx, cy, R + 8, 0, TAU); g.fill();
    for (var i = 0; i < n; i++) {
      var a0 = -Math.PI / 2 + (i - 0.5) * TAU / n + 0.02, a1 = a0 + TAU / n - 0.04;
      g.fillStyle = rgba(temps[i].colour, 0.16); g.beginPath(); g.moveTo(cx, cy); g.arc(cx, cy, R, a0, a1); g.closePath(); g.fill();
      var local = Math.max(0, Math.min(1, p * n - i)), v = Math.max(0, Math.min(1, values[i] || 0)) * local;
      if (v > 0) {
        var rr = R * (0.12 + 0.88 * v);
        if (flare === i) { g.shadowColor = temps[i].colour; g.shadowBlur = R * 0.25; }
        g.fillStyle = flare === i ? shade(temps[i].colour, 0.25) : temps[i].colour; g.beginPath(); g.moveTo(cx, cy); g.arc(cx, cy, rr, a0, a1); g.closePath(); g.fill();
        g.shadowBlur = 0;
        if (flare === i) { g.strokeStyle = '#fff4dc'; g.lineWidth = 3; g.stroke(); }
      }
      g.strokeStyle = 'rgba(255,244,220,0.25)'; g.lineWidth = 1; g.beginPath(); g.moveTo(cx, cy); g.lineTo(cx + Math.cos(a0) * R, cy + Math.sin(a0) * R); g.stroke();
      if (labels !== false) {
        var am = (a0 + a1) / 2, lx = cx + Math.cos(am) * (R + 26), ly = cy + Math.sin(am) * (R + 26);
        crest(g, temps[i].id, lx, ly, R * 0.2, temps[i].colour);
      }
    }
    g.strokeStyle = 'rgba(255,244,220,0.55)'; g.lineWidth = 2; g.beginPath(); g.arc(cx, cy, R, 0, TAU); g.stroke();
    g.fillStyle = '#1a1424'; g.beginPath(); g.arc(cx, cy, R * 0.12, 0, TAU); g.fill();
    g.restore();
  }

  /* ── STAGES ───────────────────────────────────────────────────────────────────────────────────────────────
   * Six places, each built differently (wing §21a: a palette is not a composition). */
  var STAGE = {
    dream: { name: 'The Dreaming Void', back: '#0b0a1f', back2: '#251a4a', card: '#f4ecda', ink: '#22182e', accent: '#9ec9ff', tile: '#2c2350', tileInk: '#f4ecda' },
    tent: { name: 'The Fortune-Teller\'s Tent', back: '#2a0f12', back2: '#6b2a1c', card: '#f6e7c9', ink: '#3a1d12', accent: '#f2b04a', tile: '#4a1f18', tileInk: '#fbe8c6' },
    shrine: { name: 'The Shrine of Charms', back: '#1d2a26', back2: '#3d5a4c', card: '#f2efe2', ink: '#1f2a24', accent: '#d94f3d', tile: '#2a3d34', tileInk: '#f2efe2' },
    guild: { name: 'The Guild Hall at Night', back: '#1a130d', back2: '#3a2a1a', card: '#efe2c4', ink: '#2a1e12', accent: '#e0a24a', tile: '#33261a', tileInk: '#f3e6c8' },
    stars: { name: 'Under the Starfield', back: '#03050f', back2: '#0e1a3a', card: '#e8eefc', ink: '#121a33', accent: '#ffd76a', tile: '#141e3e', tileInk: '#e8eefc' },
    hall: { name: 'The Sorting Hall', back: '#20161f', back2: '#4a2e3e', card: '#f5ecdc', ink: '#2a1b22', accent: '#c9a24a', tile: '#3a2532', tileInk: '#f5ecdc' },
  };
  var STAGES = Object.keys(STAGE);
  function backdrop(g, W, H, stage, seed) {
    var S = STAGE[stage] || STAGE.dream, r = rand(seed || 7), i;
    var grad = g.createLinearGradient(0, 0, 0, H); grad.addColorStop(0, S.back); grad.addColorStop(1, S.back2); g.fillStyle = grad; g.fillRect(0, 0, W, H);
    if (stage === 'dream') {
      for (i = 0; i < 5; i++) { var cx = r() * W, cy = r() * H, rr = 120 + r() * 220, gg = g.createRadialGradient(cx, cy, 0, cx, cy, rr); gg.addColorStop(0, 'rgba(120,110,220,0.18)'); gg.addColorStop(1, 'rgba(120,110,220,0)'); g.fillStyle = gg; g.fillRect(0, 0, W, H); }
    } else if (stage === 'tent') {
      for (i = 0; i < 9; i++) { var x0 = (i + 0.5) * W / 9; g.fillStyle = i % 2 ? 'rgba(160,40,30,0.35)' : 'rgba(230,170,80,0.12)'; g.beginPath(); g.moveTo(W / 2, -40); g.lineTo(x0 - W / 18, H); g.lineTo(x0 + W / 18, H); g.closePath(); g.fill(); }
      // the lamp hangs ABOVE the question card (card top at y 64): lower, the card hid it and its cord read as a stray line (review 2026-10-21)
      var ly = Math.round(H * 0.055);
      var lamp = g.createRadialGradient(W * 0.8, ly, 4, W * 0.8, ly, 220); lamp.addColorStop(0, 'rgba(255,214,140,0.85)'); lamp.addColorStop(0.15, 'rgba(255,190,100,0.35)'); lamp.addColorStop(1, 'rgba(255,190,100,0)'); g.fillStyle = lamp; g.fillRect(0, 0, W, H);
      g.strokeStyle = 'rgba(40,20,10,0.9)'; g.lineWidth = 2; g.beginPath(); g.moveTo(W * 0.8, 0); g.lineTo(W * 0.8, ly - 12); g.stroke(); g.fillStyle = '#7a4a1e'; g.fillRect(W * 0.8 - 7, ly - 14, 14, 4); g.fillStyle = '#f7c46a'; g.beginPath(); g.ellipse(W * 0.8, ly, 9, 12, 0, 0, TAU); g.fill();
    } else if (stage === 'shrine') {
      g.fillStyle = 'rgba(160,40,30,0.85)'; g.fillRect(0, H * 0.08, W, 18); g.fillRect(W * 0.12, H * 0.08, 22, H); g.fillRect(W * 0.86, H * 0.08, 22, H);
      for (i = 0; i < 14; i++) { var hx = W * 0.18 + i * W * 0.048, len = 30 + r() * 70; g.strokeStyle = 'rgba(240,230,210,0.5)'; g.lineWidth = 1; g.beginPath(); g.moveTo(hx, H * 0.08 + 18); g.lineTo(hx, H * 0.08 + 18 + len); g.stroke(); g.fillStyle = i % 3 ? '#efe6cc' : '#d94f3d'; g.fillRect(hx - 6, H * 0.08 + 18 + len, 12, 26); }
    } else if (stage === 'guild') {
      for (i = 0; i < 6; i++) { g.fillStyle = 'rgba(90,60,30,0.6)'; g.fillRect(0, i * H / 6 + 20, W, 10); }
      for (i = 0; i < 4; i++) { var wx = W * (0.15 + i * 0.24); g.fillStyle = 'rgba(30,40,80,0.9)'; g.fillRect(wx, 30, 70, 110); g.fillStyle = 'rgba(240,240,255,0.7)'; g.beginPath(); g.arc(wx + 50, 60, 9, 0, TAU); g.fill(); g.strokeStyle = 'rgba(60,40,20,1)'; g.lineWidth = 6; g.strokeRect(wx, 30, 70, 110); g.beginPath(); g.moveTo(wx + 35, 30); g.lineTo(wx + 35, 140); g.stroke(); }
    } else if (stage === 'stars') {
      for (i = 0; i < 260; i++) { var sx = r() * W, sy = r() * H, sr = r() < 0.08 ? 1.8 : 0.9; g.fillStyle = 'rgba(255,255,255,' + (0.3 + r() * 0.7) + ')'; g.beginPath(); g.arc(sx, sy, sr, 0, TAU); g.fill(); }
      g.strokeStyle = 'rgba(160,190,255,0.35)'; g.lineWidth = 1; g.beginPath(); g.moveTo(W * 0.1, H * 0.2); g.lineTo(W * 0.18, H * 0.14); g.lineTo(W * 0.25, H * 0.22); g.lineTo(W * 0.31, H * 0.12); g.stroke(); [[0.1, 0.2], [0.18, 0.14], [0.25, 0.22], [0.31, 0.12]].forEach(function (p) { g.fillStyle = 'rgba(230,238,255,0.95)'; g.beginPath(); g.arc(W * p[0], H * p[1], 2.6, 0, TAU); g.fill(); g.fillStyle = 'rgba(160,190,255,0.25)'; g.beginPath(); g.arc(W * p[0], H * p[1], 6, 0, TAU); g.fill(); });
    } else if (stage === 'hall') {
      var cols = ['#7a2b2b', '#2b4a7a', '#2f6a3a', '#7a6a2b', '#5a2b7a', '#2b6a6a'];
      for (i = 0; i < 6; i++) { var bx = W * (0.06 + i * 0.16), bw = 70; g.fillStyle = cols[i]; g.beginPath(); g.moveTo(bx, 0); g.lineTo(bx + bw, 0); g.lineTo(bx + bw, 200); g.lineTo(bx + bw / 2, 170); g.lineTo(bx, 200); g.closePath(); g.fill(); g.strokeStyle = 'rgba(201,162,74,0.9)'; g.lineWidth = 3; g.stroke(); }
      g.fillStyle = 'rgba(0,0,0,0.25)'; g.fillRect(0, H * 0.82, W, H * 0.18);
    }
    var v = g.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.3, W / 2, H / 2, Math.max(W, H) * 0.75); v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(0,0,0,0.55)'); g.fillStyle = v; g.fillRect(0, 0, W, H);
  }
  /** Slow motes over a stage (drawn each few frames by the scene onto its own layer). `t` in seconds. */
  function motes(g, W, H, stage, t, seed) {
    var S = STAGE[stage] || STAGE.dream, r = rand(seed || 3);
    for (var i = 0; i < 26; i++) {
      var x = (r() * W + Math.sin(t * 0.3 + i) * 30) % W, y = (H - ((r() * H + t * (8 + r() * 14)) % H)), a = 0.25 + 0.35 * Math.abs(Math.sin(t * 0.7 + i));
      g.fillStyle = rgba(S.accent, a); g.beginPath(); g.arc(x, y, 1.5 + (i % 3), 0, TAU); g.fill();
    }
  }
  /** The question card. Returns { lines, squeezed, overflow } so the scene can refuse a question that cannot fit. */
  function card(g, x, y, w, h, question, stage, number, total) {
    var S = STAGE[stage] || STAGE.dream;
    g.save(); g.shadowColor = 'rgba(0,0,0,0.5)'; g.shadowBlur = 18; g.shadowOffsetY = 6;
    g.fillStyle = S.card; roundRect(g, x, y, w, h, 16); g.fill(); g.restore();
    g.strokeStyle = S.accent; g.lineWidth = 3; roundRect(g, x + 6, y + 6, w - 12, h - 12, 12); g.stroke();
    if (number) text(g, number + ' / ' + total, x + w - 26, y + 30, 19, shade(S.ink, 0.12), 'right', '700');
    var wr = wrap(g, question, w - 80, 28, 3, '700');
    var lh = wr.size * 1.3, y0 = y + h / 2 - (wr.lines.length - 1) * lh / 2 + 6;
    wr.lines.forEach(function (l, i) { text(g, l, x + w / 2, y0 + i * lh, wr.size, S.ink, 'center', '700'); });
    return wr;
  }
  /** WCAG contrast of two #rrggbb colours (gamma-expanded, wing §25h). */
  function lum(c) { var h = hex(c) || [128, 128, 128]; var v = h.map(function (x) { x /= 255; return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4); }); return 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2]; }
  function contrast(a, b) { var x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); }
  /** The ink for text on `ground`: the first candidate that clears 4.5:1, else the best of them (review 2026-10-20: dark
   * ink on the shrine's red read at 3:1). */
  function inkOn(ground, candidates) { var best = candidates[0], bc = 0; for (var i = 0; i < candidates.length; i++) { var c = contrast(ground, candidates[i]); if (c >= 4.5) return candidates[i]; if (c > bc) { bc = c; best = candidates[i]; } } return best; }
  /**
   * An answer tile. state: idle | chosen | picked | dim. `picked` is the answer just given (brighter, a heavier rim and
   * a tick); `dim` is every other answer while it stays lit (review 2026-10-20: picking looked like moving the cursor).
   */
  function tile(g, x, y, w, h, label, answerText, state, stage) {
    var S = STAGE[stage] || STAGE.dream, lit = state === 'chosen' || state === 'picked', ground = state === 'picked' ? shade(S.accent, 0.18) : (lit ? S.accent : S.tile);
    var ink = lit ? inkOn(ground, [S.tile, '#14100c', '#ffffff']) : S.tileInk;
    g.save(); if (state === 'dim') g.globalAlpha = 0.4;
    g.fillStyle = ground; roundRect(g, x, y, w, h, 12); g.fill();
    g.strokeStyle = lit ? '#ffffff' : rgba(S.accent, 0.6); g.lineWidth = state === 'picked' ? 5 : (lit ? 3 : 2); roundRect(g, x + 1, y + 1, w - 2, h - 2, 11); g.stroke();
    g.fillStyle = lit ? ink : S.accent; g.beginPath(); g.arc(x + 28, y + h / 2, 15, 0, TAU); g.fill();
    if (state === 'picked') { g.strokeStyle = ground; g.lineWidth = 3.5; g.lineCap = 'round'; g.lineJoin = 'round'; g.beginPath(); g.moveTo(x + 21, y + h / 2); g.lineTo(x + 26, y + h / 2 + 6); g.lineTo(x + 36, y + h / 2 - 6); g.stroke(); }
    else text(g, label, x + 28, y + h / 2 + 1, 16, lit ? ground : S.tile, 'center', '700');
    var wr = wrap(g, answerText, w - 70, 20, 2, '600'), lh = wr.size * 1.2, y0 = y + h / 2 - (wr.lines.length - 1) * lh / 2;
    wr.lines.forEach(function (l, i) { text(g, l, x + 54, y0 + i * lh, wr.size, ink, 'left', '600'); });
    g.restore();
    return wr;
  }
  /**
   * The result card's FACE: the outcome's picture (a callback) or, without one, the OUTCOME's own crest; its name; the
   * player's epithet; and the PLAYER's crest in the medallion below. `outcomeTemp` is the outcome's leading temperament
   * (review 2026-10-20: the big crest showed the player's temperament, so a Steadfast house revealed with a flame and
   * the card said the same thing twice).
   */
  function resultFront(g, x, y, w, h, outcomeName, epithet, temperament, stage, picture, outcomeTemp) {
    var S = STAGE[stage] || STAGE.dream, col = temperament.colour, ot = outcomeTemp || temperament;
    g.save(); g.shadowColor = rgba(col, 0.8); g.shadowBlur = 26;
    g.fillStyle = S.card; roundRect(g, x, y, w, h, 18); g.fill(); g.restore();
    g.strokeStyle = col; g.lineWidth = 5; roundRect(g, x + 7, y + 7, w - 14, h - 14, 13); g.stroke();
    var ps = Math.min(w - 80, h * 0.42);
    g.fillStyle = rgba(ot.colour, 0.18); roundRect(g, x + (w - ps) / 2 - 6, y + 34, ps + 12, ps + 12, 10); g.fill();
    if (picture) picture(g, x + (w - ps) / 2, y + 40, ps); else crest(g, ot.id, x + w / 2, y + 40 + ps / 2, ps * 0.8, ot.colour);
    var ny = y + 40 + ps + 44;
    var wr = wrap(g, outcomeName, w - 50, 32, 1, '700'); text(g, wr.lines[0], x + w / 2, ny, wr.size, S.ink, 'center', '700');
    text(g, epithet, x + w / 2, ny + 38, 22, shade(col, -0.25), 'center', '600');
    var my = Math.min(y + h - 56, ny + 38 + 70);
    // the rule flanks the medallion (review 2026-10-21: drawn 44 px above it, its gap framed nothing)
    g.strokeStyle = rgba(col, 0.45); g.lineWidth = 2; g.beginPath(); g.moveTo(x + 40, my); g.lineTo(x + w / 2 - 44, my); g.moveTo(x + w / 2 + 44, my); g.lineTo(x + w - 40, my); g.stroke();
    crest(g, temperament.id, x + w / 2, my, 64, col);
    return { nameSize: wr.size, overflow: !!wr.overflow };
  }
  /** A small pill: the "OK to continue" prompt. */
  function hint(g, label, cx, cy, stage) {
    var S = STAGE[stage] || STAGE.dream; g.font = '700 16px ' + FONT; var w = g.measureText(label).width + 36;
    g.fillStyle = 'rgba(10,8,16,0.7)'; roundRect(g, cx - w / 2, cy - 15, w, 30, 15); g.fill(); g.strokeStyle = S.accent; g.lineWidth = 2; roundRect(g, cx - w / 2 + 1, cy - 14, w - 2, 28, 14); g.stroke();
    text(g, label, cx, cy + 1, 16, '#fff4dc', 'center', '700');
  }
  /** The quiz's progress: one pip per question, the answered ones filled. */
  function pips(g, cx, cy, total, done, stage) {
    var S = STAGE[stage] || STAGE.dream, pitch = 26;
    for (var i = 0; i < total; i++) { var px = cx + (i - (total - 1) / 2) * pitch; g.beginPath(); g.arc(px, cy, i === done ? 7 : 5.5, 0, TAU); if (i < done) { g.fillStyle = S.accent; g.fill(); } else { g.strokeStyle = i === done ? S.accent : rgba(S.accent, 0.45); g.lineWidth = i === done ? 3 : 2; g.stroke(); } }
  }
  /** The result card's BACK, seen while it turns. */
  /**
   * The result card's BACK, seen while it turns: a shaded panel under a diamond lattice, a double rim with corner studs,
   * and a sun medallion (24 rays, twelve beads on its ring, one per temperament, an eight-point star). Drawn ONCE per
   * reveal. (Review 2026-10-21: the plain back with a thin sunburst read as unfinished beside the drawn front.)
   */
  function resultBack(g, x, y, w, h, stage) {
    var S = STAGE[stage] || STAGE.dream, cx = x + w / 2, cy = y + h / 2, i, a;
    var grad = g.createLinearGradient(x, y, x, y + h); grad.addColorStop(0, shade(S.tile, 0.1)); grad.addColorStop(1, shade(S.tile, -0.3));
    g.fillStyle = grad; roundRect(g, x, y, w, h, 18); g.fill();
    g.save(); roundRect(g, x + 18, y + 18, w - 36, h - 36, 8); g.clip();
    g.strokeStyle = rgba(S.accent, 0.16); g.lineWidth = 1.5; g.beginPath();
    for (i = -h; i < w + h; i += 26) { g.moveTo(x + i, y); g.lineTo(x + i + h, y + h); g.moveTo(x + i, y + h); g.lineTo(x + i + h, y); }
    g.stroke(); g.restore();
    g.strokeStyle = S.accent; g.lineWidth = 4; roundRect(g, x + 10, y + 10, w - 20, h - 20, 12); g.stroke();
    g.strokeStyle = rgba(S.accent, 0.6); g.lineWidth = 1.5; roundRect(g, x + 18, y + 18, w - 36, h - 36, 8); g.stroke();
    g.fillStyle = S.accent;
    for (i = 0; i < 4; i++) { var px = i % 2 ? x + w - 32 : x + 32, py = i < 2 ? y + 32 : y + h - 32; g.beginPath(); g.moveTo(px, py - 8); g.lineTo(px + 8, py); g.lineTo(px, py + 8); g.lineTo(px - 8, py); g.closePath(); g.fill(); }
    var R = w * 0.3;
    g.fillStyle = shade(S.tile, -0.4); g.beginPath(); g.arc(cx, cy, R + 12, 0, TAU); g.fill();
    g.strokeStyle = S.accent; g.lineWidth = 3; g.stroke();
    g.strokeStyle = rgba(S.accent, 0.5); g.lineWidth = 1.5; g.beginPath(); g.arc(cx, cy, R - 4, 0, TAU); g.stroke();
    for (i = 0; i < 24; i++) {
      a = i * TAU / 24 - Math.PI / 2; var L = i % 2 ? R * 0.55 : R * 0.86;
      g.strokeStyle = rgba(S.accent, i % 2 ? 0.45 : 0.85); g.lineWidth = i % 2 ? 1.5 : 2.5;
      g.beginPath(); g.moveTo(cx + Math.cos(a) * R * 0.28, cy + Math.sin(a) * R * 0.28); g.lineTo(cx + Math.cos(a) * L, cy + Math.sin(a) * L); g.stroke();
    }
    g.fillStyle = S.accent;
    for (i = 0; i < 12; i++) { a = i * TAU / 12 - Math.PI / 2; g.beginPath(); g.arc(cx + Math.cos(a) * (R + 12), cy + Math.sin(a) * (R + 12), 4.5, 0, TAU); g.fill(); }
    g.beginPath(); for (i = 0; i < 16; i++) { a = i * TAU / 16 - Math.PI / 2; var r2 = i % 2 ? R * 0.1 : R * 0.26; if (i) g.lineTo(cx + Math.cos(a) * r2, cy + Math.sin(a) * r2); else g.moveTo(cx + Math.cos(a) * r2, cy + Math.sin(a) * r2); } g.closePath(); g.fill();
    g.fillStyle = shade(S.tile, -0.4); g.beginPath(); g.arc(cx, cy, R * 0.07, 0, TAU); g.fill();
  }
  /** The face-off banner: the tied outcomes, each with its crest and the LETTER of the answer that chooses it. */
  function faceoffBanner(g, x, y, w, names, temps, stage, labels) {
    var S = STAGE[stage] || STAGE.dream, n = names.length;
    g.fillStyle = 'rgba(10,8,16,0.72)'; roundRect(g, x, y, w, 70, 14); g.fill();
    text(g, 'A TIE. ONE QUESTION DECIDES.', x + w / 2, y + 18, 16, S.accent, 'center', '700');
    for (var i = 0; i < n; i++) {
      var cx = x + w * (i + 0.5) / n, lab = labels ? labels[i] + '  ' : '', size = n > 4 ? 15 : 18;
      g.font = '700 ' + size + 'px ' + FONT; var tw = g.measureText(lab + names[i]).width, gw = 34 + 8 + tw, x0 = cx - gw / 2;
      crest(g, temps[i].id, x0 + 17, y + 46, 34, temps[i].colour); text(g, lab + names[i], x0 + 42, y + 47, size, '#fff4dc', 'left', '700');
    }
  }

  return { VERSION: '1.0.0', FONT: FONT, STAGE: STAGE, STAGES: STAGES, CHARGES: Object.keys(CHARGE), hex: hex, shade: shade, rgba: rgba, roundRect: roundRect, text: text, wrap: wrap,
    crest: crest, wheel: wheel, backdrop: backdrop, motes: motes, card: card, tile: tile, resultFront: resultFront, resultBack: resultBack, faceoffBanner: faceoffBanner, hint: hint, pips: pips, contrast: contrast, inkOn: inkOn };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = TemperamentDraw;
