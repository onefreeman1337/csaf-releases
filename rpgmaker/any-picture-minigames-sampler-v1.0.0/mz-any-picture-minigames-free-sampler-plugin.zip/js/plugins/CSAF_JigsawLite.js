//=============================================================================
// CSAF_JigsawLite.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Jigsaw Lite (free): cuts any picture in your project into a 9-piece jigsaw the player assembles on a drawn table.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io/
 *
 * @help
 * Jigsaw Lite is the free sample of Jigsaw (https://csaf.itch.io/jigsaw).
 * It does ONE size: every puzzle is a 3 x 3 cut, nine interlocking pieces,
 * and every cut is new. The full Jigsaw cuts 4 to 256 pieces, takes a seed so
 * the same puzzle comes back, has the box lid peek, writes the time and the
 * moves into variables, runs a common event afterwards and works in MV too.
 *
 * Use: add the plugin command "Start a jigsaw" (CSAF_JigsawLite) to an event
 * and pick any file in img/pictures. Script call:
 *   CSAF.JigsawLite.start({ picture: 'Castle' })
 *
 * The player drags pieces with the mouse or a finger, or moves the hand with
 * the arrow keys (Shift = faster) and presses OK to pick up and put down. A
 * piece close to its home snaps in. Cancel sets the puzzle aside.
 * The "Solved -> switch" parameter is turned ON when the puzzle is solved and
 * OFF when it is set aside, before the event continues.
 *
 * Upgrading: install the full Jigsaw and this command hands every puzzle to it
 * (at nine pieces); you can then switch your events to Jigsaw's own command.
 * Jigsaw Lite patches no engine method; it adds one scene and one command.
 *
 * @param swSolved
 * @text Solved -> switch
 * @type switch
 * @default 0
 *
 * @command start
 * @text Start a jigsaw
 * @desc Cut a picture into a 9-piece jigsaw and let the player assemble it.
 *
 * @arg picture
 * @text Picture (img/pictures)
 * @type file
 * @dir img/pictures
 * @default
 */

var CSAF = CSAF || {};

(function () {
  'use strict';
  var NAME = 'CSAF_JigsawLite';
  var RAW = (typeof PluginManager !== 'undefined' && PluginManager.parameters) ? PluginManager.parameters(NAME) : {};
  /** A plugin parameter as a number: blank = the default (an id of "0" is 0, never truthy). */
  function num(v, d) { var s = String(v === undefined || v === null ? '' : v).trim(); if (s === '') return d; var n = Number(s); return isFinite(n) ? n : d; }
  var P = { swSolved: Math.max(0, Math.floor(num(RAW.swSolved, 0))) };
  /** The one size this plugin cuts. */
  var COLS = 3, ROWS = 3;
  /** How close (px) a dropped piece must be to its home to snap in. */
  var SNAP = 16;
  /** What the plugin has done, for tests and the curious: puzzles opened here, handed to the full Jigsaw, solved. */
  var STATS = { opened: 0, handedOff: 0, solved: 0, setAside: 0 };

  //===========================================================================
  // The cut: a 3 x 3 grid of interlocking knob-and-socket pieces from a seed
  //===========================================================================
  var CORNER_JITTER = 0.05;    // inner corners move up to 5% of a cell
  var TAB_MIN = 0.085, TAB_SPAN = 0.025, WOBBLE = 0.035;

  /** FNV-1a for string seeds; numbers are used as they are. @returns {number} uint32 */
  function seedOf(s) {
    var n = Number(s);
    if (s !== '' && s !== null && s !== undefined && isFinite(n)) return (Math.floor(Math.abs(n)) >>> 0) || 1;
    var h = 2166136261, str = String(s);
    for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    return h || 1;
  }

  /** mulberry32: a small seeded generator, [0, 1). @param {number} a seed @returns {function(): number} */
  function rng(a) {
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /** A knob curve from A to B (ten control points), bulging toward normal side `sign` (+1/-1; 0 = straight). */
  function knobEdge(A, B, axisNormal, sign, R) {
    var ux = B[0] - A[0], uy = B[1] - A[1];
    var nx = -uy, ny = ux;
    if (nx * axisNormal[0] + ny * axisNormal[1] < 0) { nx = -nx; ny = -ny; }
    var t = TAB_MIN + R() * TAB_SPAN;
    var j = function () { return (R() * 2 - 1) * WOBBLE; };
    var a = j(), b = j(), c = j(), d = j(), e = j();
    var local = sign === 0 ? null : [[0, 0], [0.2, a], [0.5 + b + d, -t + c], [0.5 - t + b, t + c], [0.5 - 2 * t + b - d, 3 * t + c],
      [0.5 + 2 * t + b - d, 3 * t + c], [0.5 + t + b, t + c], [0.5 + b + d, -t + c], [0.8, e], [1, 0]];
    var pts = [];
    for (var i = 0; i < 10; i++) {
      var L = local ? local[i] : [i / 9, 0];
      var s = local ? L[1] * sign : 0;
      pts.push([A[0] + ux * L[0] + nx * s, A[1] + uy * L[0] + ny * s]);
    }
    return { pts: pts, sign: sign, knob: sign === 0 ? 0 : t };
  }

  function cubic(p0, p1, p2, p3, t) {
    var m = 1 - t;
    return [m * m * m * p0[0] + 3 * m * m * t * p1[0] + 3 * m * t * t * p2[0] + t * t * t * p3[0],
      m * m * m * p0[1] + 3 * m * m * t * p1[1] + 3 * m * t * t * p2[1] + t * t * t * p3[1]];
  }

  /** Points along an edge in the PIECE's direction (clockwise round the piece), first to last inclusive. */
  function flattenEdge(edge, steps) {
    steps = steps || 8;
    var P = edge.base.pts, out = [P[0]];
    for (var seg = 0; seg < 3; seg++) {
      var k = seg * 3;
      for (var s = 1; s <= steps; s++) out.push(cubic(P[k], P[k + 1], P[k + 2], P[k + 3], s / steps));
    }
    return edge.reversed ? out.slice().reverse() : out;
  }

  /** The closed outline of a piece (corners once), clockwise. @returns {Array<Array<number>>} */
  function flattenOutline(piece, steps) {
    var out = [];
    var order = ['top', 'right', 'bottom', 'left'];
    for (var i = 0; i < 4; i++) { var pts = flattenEdge(piece.edges[order[i]], steps); for (var k = 0; k < pts.length - 1; k++) out.push(pts[k]); }
    return out;
  }

  /**
   * Cut a w x h picture into 3 x 3 interlocking pieces. The same seed always cuts the same puzzle.
   * @param {{w:number, h:number, seed:(number|string)}} o
   * @returns {{w:number, h:number, cols:number, rows:number, seed:number, pieces:Array<Object>}}
   */
  function cut(o) {
    o = o || {};
    var w = Math.max(16, Number(o.w) || 0), h = Math.max(16, Number(o.h) || 0);
    var cols = COLS, rows = ROWS, seed = seedOf(o.seed === undefined ? 1 : o.seed);
    var R = rng(seed), cw = w / cols, ch = h / rows, r, c;

    var corner = [];
    for (r = 0; r <= rows; r++) {
      corner.push([]);
      for (c = 0; c <= cols; c++) {
        var inner = r > 0 && r < rows && c > 0 && c < cols;
        var jx = inner ? (R() * 2 - 1) * CORNER_JITTER * cw : 0, jy = inner ? (R() * 2 - 1) * CORNER_JITTER * ch : 0;
        corner[r].push([c * cw + jx, r * ch + jy]);
      }
    }
    // horizontal lines (r = 0..rows), segment c: corner[r][c] -> corner[r][c+1]; normal +y
    var H = [], V = [];
    for (r = 0; r <= rows; r++) {
      H.push([]);
      for (c = 0; c < cols; c++) H[r].push(knobEdge(corner[r][c], corner[r][c + 1], [0, 1], (r === 0 || r === rows) ? 0 : (R() < 0.5 ? 1 : -1), R));
    }
    // vertical lines (c = 0..cols), segment r: corner[r][c] -> corner[r+1][c]; normal +x
    for (c = 0; c <= cols; c++) {
      V.push([]);
      for (r = 0; r < rows; r++) V[c].push(knobEdge(corner[r][c], corner[r + 1][c], [1, 0], (c === 0 || c === cols) ? 0 : (R() < 0.5 ? 1 : -1), R));
    }

    var pieces = [];
    for (r = 0; r < rows; r++) {
      for (c = 0; c < cols; c++) {
        // outward sign per side: top faces -y (so -base), right +x (base), bottom +y (base), left -x (-base)
        var top = { base: H[r][c], reversed: false, sign: -H[r][c].sign, knob: H[r][c].knob };
        var right = { base: V[c + 1][r], reversed: false, sign: V[c + 1][r].sign, knob: V[c + 1][r].knob };
        var bottom = { base: H[r + 1][c], reversed: true, sign: H[r + 1][c].sign, knob: H[r + 1][c].knob };
        var left = { base: V[c][r], reversed: true, sign: -V[c][r].sign, knob: V[c][r].knob };
        if (top.sign === 0) top.sign = 0; if (left.sign === 0) left.sign = 0; // -0 -> 0
        var piece = { id: r * cols + c, col: c, row: r, edges: { top: top, right: right, bottom: bottom, left: left } };
        var poly = flattenOutline(piece, 6), minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        for (var i = 0; i < poly.length; i++) {
          if (poly[i][0] < minX) minX = poly[i][0]; if (poly[i][1] < minY) minY = poly[i][1];
          if (poly[i][0] > maxX) maxX = poly[i][0]; if (poly[i][1] > maxY) maxY = poly[i][1];
        }
        piece.homeX = minX; piece.homeY = minY; piece.bw = maxX - minX; piece.bh = maxY - minY;
        piece.outline = poly.map(function (p) { return [Math.round(p[0] * 100) / 100, Math.round(p[1] * 100) / 100]; });
        pieces.push(piece);
      }
    }
    return { w: w, h: h, cols: cols, rows: rows, seed: seed, pieces: pieces };
  }

  //===========================================================================
  // Drawing: a piece with bevel, rim light and shadow; the felt table
  //===========================================================================
  /** Trace one piece's outline (closed) into ctx's current path, in picture coordinates. */
  function tracePiece(ctx, piece) {
    var order = ['top', 'right', 'bottom', 'left'];
    for (var i = 0; i < 4; i++) {
      var e = piece.edges[order[i]], P = e.base.pts;
      var pts = e.reversed ? P.slice().reverse() : P;
      if (i === 0) ctx.moveTo(pts[0][0], pts[0][1]);
      for (var k = 1; k < 10; k += 3) ctx.bezierCurveTo(pts[k][0], pts[k][1], pts[k + 1][0], pts[k + 1][1], pts[k + 2][0], pts[k + 2][1]);
    }
    ctx.closePath();
  }

  /**
   * Draw a piece with its home bounding box at (x, y) on ctx.
   * @param {CanvasRenderingContext2D} ctx target
   * @param {CanvasImageSource} img the picture, drawn at the cut's w x h
   * @param {Object} cutRes the cut
   * @param {Object} piece one of cutRes.pieces
   * @param {number} x left of the piece's bounding box
   * @param {number} y top of the piece's bounding box
   * @param {{lifted:boolean}} [o] lifted adds a deeper, offset drop shadow
   */
  function drawPiece(ctx, img, cutRes, piece, x, y, o) {
    o = o || {};
    var bev = bevelOf(piece);
    ctx.save();
    ctx.translate(x - piece.homeX, y - piece.homeY);
    // shadow first, under the piece: deeper when the piece is lifted
    ctx.save();
    ctx.beginPath(); tracePiece(ctx, piece);
    ctx.shadowColor = 'rgba(0,0,0,' + (o.lifted ? 0.55 : 0.38) + ')';
    ctx.shadowBlur = o.lifted ? bev * 7 : bev * 2.2;
    ctx.shadowOffsetX = o.lifted ? bev * 2.6 : bev * 0.7;
    ctx.shadowOffsetY = o.lifted ? bev * 3.4 : bev * 0.9;
    ctx.fillStyle = '#20180f';
    ctx.fill();
    ctx.restore();
    // the picture, clipped to the piece
    ctx.save();
    ctx.beginPath(); tracePiece(ctx, piece); ctx.clip();
    ctx.drawImage(img, 0, 0, cutRes.w, cutRes.h);
    // bevel: light from the upper left, a dark lip lower right, each a stroke of the outline offset inside the clip
    ctx.lineJoin = 'round';
    ctx.lineWidth = bev * 1.5;
    ctx.save(); ctx.translate(bev * 0.6, bev * 0.6); ctx.beginPath(); tracePiece(ctx, piece);
    ctx.strokeStyle = 'rgba(255,246,226,0.26)'; ctx.stroke(); ctx.restore();
    ctx.save(); ctx.translate(-bev * 0.6, -bev * 0.6); ctx.beginPath(); tracePiece(ctx, piece);
    ctx.strokeStyle = 'rgba(20,12,4,0.40)'; ctx.stroke(); ctx.restore();
    // a faint sheen across the face so a piece reads as card stock, not a cut-out of a screenshot
    var g = ctx.createLinearGradient(piece.homeX, piece.homeY, piece.homeX + piece.bw, piece.homeY + piece.bh);
    g.addColorStop(0, 'rgba(255,255,255,0.10)'); g.addColorStop(0.5, 'rgba(255,255,255,0)'); g.addColorStop(1, 'rgba(0,0,0,0.10)');
    ctx.fillStyle = g; ctx.fillRect(piece.homeX - 4, piece.homeY - 4, piece.bw + 8, piece.bh + 8);
    ctx.restore();
    // the cut line itself: a hairline of the board's grey core
    ctx.beginPath(); tracePiece(ctx, piece);
    ctx.lineWidth = Math.max(0.8, bev * 0.45); ctx.strokeStyle = 'rgba(48,38,26,0.85)'; ctx.stroke();
    ctx.restore();
  }

  /** The bevel drawPiece gives a piece (px): grows with the piece, so a big piece reads as thick card. */
  function bevelOf(piece) { return Math.max(1.5, Math.min(piece.bw, piece.bh) * 0.035); }

  /** How far past its outline box a piece's LIFTED shadow can reach: the margin a piece's own bitmap needs. */
  function margin(piece) { var b = bevelOf(piece); return Math.ceil(b * 7 * 1.5 + b * 3.4) + 2; }

  /** A seeded value noise for the table's grain. */
  function noise(R, n) { var a = []; for (var i = 0; i < n; i++) a.push(R()); return a; }

  /**
   * The table: a felt mat inside a wooden rim, lit from above. Drawn once per scene.
   * @param {CanvasRenderingContext2D} ctx target
   * @param {number} w width
   * @param {number} h height
   * @param {{seed:number}} [o]
   */
  function drawTable(ctx, w, h, o) {
    o = o || {};
    var R = rng(seedOf(o.seed || 7));
    var wood = '#5a3a22', felt = '#24453a';
    ctx.fillStyle = wood; ctx.fillRect(0, 0, w, h);
    var grain = noise(R, 90);
    for (var i = 0; i < grain.length; i++) {
      var y = grain[i] * h;
      ctx.strokeStyle = 'rgba(' + (i % 2 ? '255,220,170' : '30,15,5') + ',' + (0.05 + grain[(i + 7) % 90] * 0.06) + ')';
      ctx.lineWidth = 1 + grain[(i + 3) % 90] * 2.5;
      ctx.beginPath(); ctx.moveTo(0, y);
      ctx.bezierCurveTo(w * 0.3, y + (grain[(i + 11) % 90] - 0.5) * 18, w * 0.7, y + (grain[(i + 23) % 90] - 0.5) * 18, w, y + (grain[(i + 5) % 90] - 0.5) * 10);
      ctx.stroke();
    }
    var m = feltInset(w, h);
    ctx.fillStyle = felt; ctx.fillRect(m, m, w - m * 2, h - m * 2);
    for (var k = 0; k < 1400; k++) {
      ctx.fillStyle = 'rgba(' + (R() < 0.5 ? '255,255,255' : '0,0,0') + ',' + (0.025 + R() * 0.03) + ')';
      ctx.fillRect(m + R() * (w - m * 2), m + R() * (h - m * 2), 1 + R() * 1.6, 1 + R() * 1.6);
    }
    ctx.strokeStyle = 'rgba(0,0,0,0.45)'; ctx.lineWidth = 3; ctx.strokeRect(m + 1.5, m + 1.5, w - m * 2 - 3, h - m * 2 - 3);
    ctx.strokeStyle = 'rgba(255,240,210,0.18)'; ctx.lineWidth = 1; ctx.strokeRect(m - 0.5, m - 0.5, w - m * 2 + 1, h - m * 2 + 1);
    var lg = ctx.createRadialGradient(w * 0.5, h * 0.42, Math.min(w, h) * 0.1, w * 0.5, h * 0.5, Math.max(w, h) * 0.75);
    lg.addColorStop(0, 'rgba(255,240,205,0.10)'); lg.addColorStop(1, 'rgba(0,0,0,0.38)');
    ctx.fillStyle = lg; ctx.fillRect(0, 0, w, h);
  }

  /** The wooden rim's width on a w x h table: the felt starts this far in. */
  function feltInset(w, h) { return Math.round(Math.min(w, h) * 0.045); }

  //===========================================================================
  // The command
  //===========================================================================
  /** The table's type: a book serif, never the engine's UI font. */
  var FONT = 'Georgia, "Palatino Linotype", "Book Antiqua", Palatino, "Times New Roman", serif';
  var HUD_H = 40;
  /** Type and plaque scale with the screen: 1 at MZ's 816x624, up to 3. */
  function uiScale() { return Math.max(1, Math.min(3, Math.min(Graphics.width, Graphics.height) / 624)); }
  function rec() { if (!$gameSystem._csafJigsawLite) $gameSystem._csafJigsawLite = { v: 1, count: 0 }; return $gameSystem._csafJigsawLite; }

  var pending = null;
  /**
   * Start a 9-piece jigsaw of a picture in img/pictures. With the full Jigsaw installed, the puzzle is handed to it.
   * @param {{picture:string}} args
   * @returns {boolean} whether a puzzle was opened
   */
  function start(args) {
    var pic = String((args && args.picture) || '').trim();
    if (!pic) { console.warn('Jigsaw Lite: no picture given. Pick a file in img/pictures.'); return false; }
    if (CSAF.Jigsaw && typeof CSAF.Jigsaw.start === 'function') { STATS.handedOff++; return CSAF.Jigsaw.start({ picture: pic, pieces: COLS * ROWS }); }
    var r = rec();
    pending = { picture: pic, seed: 'jl' + r.count + 'm' + ($gameMap ? $gameMap.mapId() : 0) + 'f' + Graphics.frameCount };
    STATS.opened++;
    SceneManager.push(Scene_JigsawLite);
    return true;
  }
  if (typeof PluginManager !== 'undefined' && typeof PluginManager.registerCommand === 'function') PluginManager.registerCommand(NAME, 'start', function (args) { start(args); });

  //===========================================================================
  // The scene
  //===========================================================================
  function Scene_JigsawLite() { this.initialize.apply(this, arguments); }
  if (typeof Scene_Base !== 'undefined') {
    Scene_JigsawLite.prototype = Object.create(Scene_Base.prototype);
    Scene_JigsawLite.prototype.constructor = Scene_JigsawLite;

    Scene_JigsawLite.prototype.initialize = function () {
      Scene_Base.prototype.initialize.call(this);
      this._req = pending; pending = null;
      this._picture = this._req ? ImageManager.loadPicture(this._req.picture) : null;
      this._built = false; this._held = -1; this._grabX = 0; this._grabY = 0; this._moves = 0; this._frames = 0; this._done = false; this._doneAge = 0;
    };

    Scene_JigsawLite.prototype.isReady = function () { return Scene_Base.prototype.isReady.call(this) && (!this._picture || this._picture.isReady()); };

    Scene_JigsawLite.prototype.start = function () {
      Scene_Base.prototype.start.call(this);
      // no usable picture: say so, write the switch OFF (an event's branch must not read a stale value) and close
      if (!this._req || !this._picture || this._picture.width === 0) { console.warn('Jigsaw Lite: the picture could not be loaded.'); if (P.swSolved > 0) $gameSwitches.setValue(P.swSolved, false); this.popScene(); return; }
      this.build();
    };

    /** Lay out the table, the frame and the pieces; cut once. */
    Scene_JigsawLite.prototype.build = function () {
      var W = Graphics.width, H = Graphics.height;
      var tb = new Bitmap(W, H); drawTable(tb.context, W, H, { seed: 5 }); tb._baseTexture.update();
      this.addChild(new Sprite(tb));
      var L = this.solveLayout(), fw = L.fw, fh = L.fh;
      this._fx = L.fx; this._fy = L.fy; this._layout = L;
      var fr = new Bitmap(W, H), c = fr.context;
      c.fillStyle = 'rgba(0,0,0,0.30)'; c.fillRect(this._fx - 6, this._fy - 6, fw + 12, fh + 12);
      c.strokeStyle = 'rgba(255,235,200,0.25)'; c.lineWidth = 1; c.strokeRect(this._fx - 6.5, this._fy - 6.5, fw + 13, fh + 13);
      // a ghost of the picture in the frame, so the player has the box art to work from
      c.globalAlpha = 0.16; c.drawImage(this._picture._image || this._picture.canvas, this._fx, this._fy, fw, fh); c.globalAlpha = 1;
      fr._baseTexture.update(); this._frameSp = new Sprite(fr); this.addChild(this._frameSp);
      this._cut = L.cut;
      var src = this._picture._image || this._picture.canvas, R = rng(seedOf(this._req.seed + ':scatter'));
      this._layer = new Sprite(); this.addChild(this._layer);
      this._pieces = []; this._src = src;
      for (var i = 0; i < this._cut.pieces.length; i++) {
        var p = this._cut.pieces[i];
        var pad = margin(p);
        var bmp = new Bitmap(Math.ceil(p.bw) + pad * 2, Math.ceil(p.bh) + pad * 2);
        drawPiece(bmp.context, src, this._cut, p, pad, pad); bmp._baseTexture.update();
        var sp = new Sprite(bmp);
        sp._piece = p; sp._pad = pad; sp._placed = false;
        sp._homeX = this._fx + p.homeX - pad; sp._homeY = this._fy + p.homeY - pad;
        var at = L.pos[i];
        sp.x = Math.round(at[0] - pad + (R() * 2 - 1) * 3); sp.y = Math.round(at[1] - pad + (R() * 2 - 1) * 3);
        sp.x = Math.max(L.t - pad, Math.min(W - L.t - bmp.width + pad, sp.x)); sp.y = Math.max(L.t - pad, Math.min(H - L.t - bmp.height + pad, sp.y));
        this._layer.addChild(sp); this._pieces.push(sp);
      }
      // the hand: keyboard players move it with the arrows
      var hb = new Bitmap(28, 28), hc = hb.context;
      hc.fillStyle = 'rgba(255,240,205,0.9)'; hc.strokeStyle = 'rgba(40,25,10,0.9)'; hc.lineWidth = 2;
      hc.beginPath(); hc.moveTo(4, 2); hc.lineTo(4, 22); hc.lineTo(10, 16); hc.lineTo(16, 26); hc.lineTo(20, 24); hc.lineTo(14, 14); hc.lineTo(22, 14); hc.closePath(); hc.fill(); hc.stroke(); hb._baseTexture.update();
      this._hand = new Sprite(hb); this._hand.x = W / 2; this._hand.y = H / 2; this._hand.visible = false; this.addChild(this._hand);
      // the plaque over the frame: placed / total, time, moves
      this._S = uiScale();
      this._hud = new Sprite(new Bitmap(fw + 12, Math.round(HUD_H * this._S))); this._hud.x = this._fx - 6; this._hud.y = L.t + 8; this.addChild(this._hud);
      this._placedN = 0; this._hudKey = -1;
      // the hint, engraved in the gap under the frame
      var hh = Math.round(16 * this._S), hint = new Bitmap(fw + 12, hh); hint.fontFace = FONT; hint.fontSize = Math.round(12 * this._S); hint.outlineWidth = 0; hint.textColor = 'rgba(255,226,170,0.55)';
      hint.drawText('Drag a piece home  ·  Esc sets it aside', 0, 0, fw + 12, hh, 'left');
      var hs = new Sprite(hint); hs.x = this._fx - 4; hs.y = this._fy + fh + 5; this._frameSp.addChild(hs);
      this._fw = fw; this._fh = fh; this._built = true;
      this.drawHud();
    };

    /**
     * The table's layout for this screen: the largest frame (top left, under the plaque) whose loose pieces each get a
     * spot of their own on the free table. Shrinks the frame 4% a step until the spots cover the pieces.
     * @returns {{fw:number, fh:number, fx:number, fy:number, t:number, cut:object, pos:Array, fits:boolean, tries:number}}
     */
    Scene_JigsawLite.prototype.solveLayout = function () {
      var W = Graphics.width, H = Graphics.height, pw = this._picture.width, ph = this._picture.height;
      var S = uiScale(), portrait = H > W * 1.15;
      var T = feltInset(W, H), top = T + 8 + Math.round(HUD_H * S) + 14, fx = T + 14;
      var kMax = portrait ? Math.min((W - fx * 2) / pw, (H - top - T) * 0.5 / ph) : Math.min((W - fx - T) * 0.66 / pw, (H - top - T - 8) / ph), L = null;
      for (var t = 0; t < 40; t++) {
        var k = kMax * Math.pow(0.96, t), fw = Math.max(16, Math.round(pw * k)), fh = Math.max(16, Math.round(ph * k));
        if (portrait) fx = Math.round((W - fw) / 2);
        var cutRes = cut({ w: fw, h: fh, seed: this._req.seed });
        var R = rng(seedOf(this._req.seed + ':order')), order = [];
        for (var i = 0; i < cutRes.pieces.length; i++) order.push(i);
        for (var q = order.length - 1; q > 0; q--) { var j = Math.floor(R() * (q + 1)), tq = order[q]; order[q] = order[j]; order[j] = tq; }
        var below = top + fh + 10 + Math.round(16 * S);
        var regions = portrait ? [[T + 6, below, W - T - 6, H - T - 6]] : [[fx + fw + 18, T + 6, W - T - 6, H - T - 6], [T + 6, below, fx + fw + 6, H - T - 6]];
        var pos = packLoose(cutRes, order, regions, 12);
        L = { fw: fw, fh: fh, fx: fx, fy: top, t: T, cut: cutRes, pos: pos.pos, fits: pos.fits, tries: t + 1 };
        if (pos.fits) break;
      }
      return L;
    };

    /** Redraw the plaque when what it says has changed (once a second at most while the clock runs). */
    Scene_JigsawLite.prototype.drawHud = function () {
      var secs = Math.floor(this._frames / 60), key = secs * 1e6 + this._placedN * 1e3 + this._moves;
      if (key === this._hudKey) return;
      this._hudKey = key;
      var b = this._hud.bitmap, w = b.width, h = b.height, c = b.context, n = this._pieces.length, S = this._S;
      // MZ's Bitmap.drawText and clearRect each end in _baseTexture.update() (rmmz_core.js:1549, :1684): hold those dirty
      // marks while the plaque is drawn, then mark once - the same calls, the same pixels. The hold is an own property on
      // this one texture and is DELETED afterwards, never left shadowing BaseTexture.prototype.update.
      var bt = b._baseTexture;
      bt.update = noUpload;
      try { this.paintHud(b, w, h, c, n, S, secs); } finally { delete bt.update; }
      bt.update();
    };

    /** The plaque's drawing (called by drawHud with the texture upload held). */
    Scene_JigsawLite.prototype.paintHud = function (b, w, h, c, n, S, secs) {
      b.clear();
      c.save();
      c.fillStyle = 'rgba(24,14,8,0.62)'; roundRect(c, 0.5, 0.5, w - 1, h - 1, 7); c.fill();
      c.strokeStyle = 'rgba(255,226,170,0.38)'; c.lineWidth = 1; roundRect(c, 3.5, 3.5, w - 7, h - 7, 5); c.stroke();
      var fill = n ? this._placedN / n : 0;
      var ry = h - Math.round(9 * S), rh = Math.max(2, Math.round(2 * S));
      c.fillStyle = 'rgba(255,226,170,0.16)'; c.fillRect(10, ry, w - 20, rh);
      c.fillStyle = 'rgba(244,196,112,0.95)'; c.fillRect(10, ry, Math.round((w - 20) * fill), rh);
      c.restore();
      b.fontFace = FONT; b.outlineWidth = 0; b.fontItalic = false;
      var third = Math.floor((w - 24) / 3), mm = Math.floor(secs / 60), ss = secs % 60, y1 = Math.round(2 * S), y2 = Math.round(15 * S);
      b.fontSize = Math.round(13 * S); b.textColor = 'rgba(255,226,170,0.62)';
      b.drawText('PLACED', 12, y1, third, Math.round(18 * S), 'left'); b.drawText('TIME', 12 + third, y1, third, Math.round(18 * S), 'center'); b.drawText('MOVES', 12 + third * 2, y1, third, Math.round(18 * S), 'right');
      b.fontSize = Math.round(17 * S); b.textColor = '#f6e6c4';
      b.drawText(this._placedN + ' / ' + n, 12, y2, third, Math.round(20 * S), 'left');
      b.drawText(mm + ':' + (ss < 10 ? '0' : '') + ss, 12 + third, y2, third, Math.round(20 * S), 'center');
      b.drawText(String(this._moves), 12 + third * 2, y2, third, Math.round(20 * S), 'right');
    };

    /** The topmost unplaced piece under (x, y), by the piece's own outline. No allocation. */
    Scene_JigsawLite.prototype.pieceAt = function (x, y) {
      for (var i = this._layer.children.length - 1; i >= 0; i--) {
        var sp = this._layer.children[i];
        if (sp._placed) continue;
        var p = sp._piece, lx = x - sp.x - sp._pad + p.homeX, ly = y - sp.y - sp._pad + p.homeY, o = p.outline, inside = false;
        for (var a = 0, b = o.length - 1; a < o.length; b = a++) {
          if ((o[a][1] > ly) !== (o[b][1] > ly) && lx < (o[b][0] - o[a][0]) * (ly - o[a][1]) / (o[b][1] - o[a][1]) + o[a][0]) inside = !inside;
        }
        if (inside) return i;
      }
      return -1;
    };

    Scene_JigsawLite.prototype.grab = function (x, y) {
      var i = this.pieceAt(x, y); if (i < 0) return;
      var sp = this._layer.children[i];
      this._layer.removeChild(sp); this._layer.addChild(sp); // to the top
      this._held = this._layer.children.length - 1; this._grabX = x - sp.x; this._grabY = y - sp.y;
      sp.scale.x = sp.scale.y = 1.04; this.redrawPiece(sp, true); SoundManager.playCursor();
    };

    /** Repaint one piece, lifted or at rest. Once per pick-up or put-down, never per frame. */
    Scene_JigsawLite.prototype.redrawPiece = function (sp, lifted) {
      var b = sp.bitmap;
      b.clear(); drawPiece(b.context, this._src, this._cut, sp._piece, sp._pad, sp._pad, { lifted: lifted }); b._baseTexture.update();
    };

    Scene_JigsawLite.prototype.drop = function () {
      var sp = this._layer.children[this._held]; this._held = -1; if (!sp) return;
      sp.scale.x = sp.scale.y = 1; this.redrawPiece(sp, false); this._moves++;
      if (Math.abs(sp.x - sp._homeX) <= SNAP && Math.abs(sp.y - sp._homeY) <= SNAP) {
        sp.x = sp._homeX; sp.y = sp._homeY; sp._placed = true; this._placedN++;
        this._layer.removeChild(sp); this._layer.addChildAt(sp, 0); SoundManager.playOk();
        if (this._placedN === this._pieces.length) this.solve(true);
      }
    };

    /** The puzzle closes: the switch is written, then the ending plays. */
    Scene_JigsawLite.prototype.solve = function (solved) {
      if (this._done) return;
      this._done = true; this._solved = !!solved; this._doneAge = 0;
      var secs = Math.floor(this._frames / 60);
      rec().count++;
      if (this._solved) STATS.solved++; else STATS.setAside++;
      if (P.swSolved > 0) $gameSwitches.setValue(P.swSolved, this._solved);
      if (solved) SoundManager.playOk();
      this.buildFinale(secs);
    };

    /** The ending: on a solve the whole picture rises over the joined pieces; either way a plaque gives the result. */
    Scene_JigsawLite.prototype.buildFinale = function (secs) {
      var fw = this._fw, fh = this._fh, n = this._pieces.length, W = Graphics.width, H = Graphics.height, T = this._layout.t, S = this._S, h = Math.round(92 * S);
      var kz = Math.max(1, Math.min((W - T * 2 - 60) / fw, (H - T * 2 - h - 56) / fh)), tw = Math.round(fw * kz), th = Math.round(fh * kz);
      this._fin = { x0: this._fx - 4, y0: this._fy - 4, s0: fw / tw, x1: Math.round((W - tw) / 2) - 4, y1: Math.round((H - th - h - 16) / 2) - 4 };
      if (this._solved) {
        var pb = new Bitmap(tw + 8, th + 8), c = pb.context; pb.smooth = true;
        c.drawImage(this._picture._image || this._picture.canvas, 4, 4, tw, th);
        c.strokeStyle = 'rgba(244,206,128,0.95)'; c.lineWidth = 2; c.strokeRect(3, 3, tw + 2, th + 2);
        c.strokeStyle = 'rgba(40,22,8,0.7)'; c.lineWidth = 1; c.strokeRect(0.5, 0.5, tw + 7, th + 7);
        pb._baseTexture.update();
        this._whole = new Sprite(pb); this._whole.x = this._fin.x0; this._whole.y = this._fin.y0; this._whole.opacity = 0;
        this._whole.scale.x = this._whole.scale.y = this._fin.s0;
        this.addChild(this._whole);
      }
      this.drawHud();
      var w = Math.min(W - 40, Math.max(Math.round(320 * S), Math.round(tw * 0.7)));
      var b = new Bitmap(w, h), x = b.context;
      x.save();
      x.fillStyle = 'rgba(22,12,6,0.86)'; roundRect(x, 0.5, 0.5, w - 1, h - 1, 9 * S); x.fill();
      x.strokeStyle = 'rgba(244,206,128,0.75)'; x.lineWidth = Math.max(1, S * 0.9); roundRect(x, 4.5 * S, 4.5 * S, w - 9 * S, h - 9 * S, 6 * S); x.stroke();
      x.fillStyle = x.strokeStyle = 'rgba(244,206,128,0.85)';
      var gap = (this._solved ? 92 : 128) * S, fy0 = 22 * S;
      for (var s = -1; s <= 1; s += 2) {
        var cx = w / 2 + s * gap;
        x.beginPath(); x.moveTo(cx, fy0); x.lineTo(cx + s * 34 * S, fy0); x.stroke();
        x.beginPath(); x.moveTo(cx + s * 40 * S, fy0); x.lineTo(cx + s * 36 * S, fy0 - 3 * S); x.lineTo(cx + s * 32 * S, fy0); x.lineTo(cx + s * 36 * S, fy0 + 3 * S); x.closePath(); x.fill();
      }
      x.restore();
      b.fontFace = FONT; b.outlineWidth = 0;
      b.fontSize = Math.round(24 * S); b.textColor = '#f6e2b4';
      b.drawText(this._solved ? 'S O L V E D' : 'S E T   A S I D E', 0, Math.round(6 * S), w, Math.round(32 * S), 'center');
      var mm = Math.floor(secs / 60), ss = secs % 60, t = mm + ':' + (ss < 10 ? '0' : '') + ss;
      b.fontSize = Math.round(16 * S); b.textColor = '#ead7b0';
      b.drawText(this._solved ? (n + ' pieces  ·  ' + t + '  ·  ' + this._moves + ' moves') : (this._placedN + ' of ' + n + ' placed  ·  ' + t), 0, Math.round(38 * S), w, Math.round(22 * S), 'center');
      b.fontSize = Math.round(12 * S); b.textColor = 'rgba(234,215,176,0.6)';
      b.drawText('OK to continue', 0, Math.round(62 * S), w, Math.round(18 * S), 'center');
      this._plaque = new Sprite(b);
      this._plaque.x = this._solved ? Math.round((W - w) / 2) : Math.round(this._fx + fw / 2 - w / 2);
      this._plaque.x = Math.max(20, Math.min(W - w - 20, this._plaque.x));
      this._plaque.y = this._solved ? this._fin.y1 + th + 8 + 14 : Math.round(this._fy + fh / 2 - h / 2); this._plaque.opacity = 0;
      this.addChild(this._plaque);
    };

    Scene_JigsawLite.prototype.update = function () {
      Scene_Base.prototype.update.call(this);
      if (!this._built) return;
      if (this._done) {
        this._doneAge++;
        if (this._whole) {
          var e = Math.min(1, this._doneAge / 40), f = this._fin; e = e * e * (3 - 2 * e);
          this._whole.opacity = Math.min(255, this._doneAge * 12);
          this._whole.scale.x = this._whole.scale.y = f.s0 + (1 - f.s0) * e;
          this._whole.x = f.x0 + (f.x1 - f.x0) * e; this._whole.y = f.y0 + (f.y1 - f.y0) * e;
          this._layer.opacity = this._frameSp.opacity = this._hud.opacity = Math.round(255 * (1 - e));
        }
        if (this._plaque) this._plaque.opacity = Math.max(0, Math.min(255, (this._doneAge - (this._whole ? 30 : 0)) * 12));
        this._hand.visible = false;
        if (this._doneAge > 52 && (Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered())) this.popScene();
        return;
      }
      this._frames++;
      var dx = (Input.isPressed('right') ? 1 : 0) - (Input.isPressed('left') ? 1 : 0), dy = (Input.isPressed('down') ? 1 : 0) - (Input.isPressed('up') ? 1 : 0);
      if (dx || dy) { var sp0 = Input.isPressed('shift') ? 9 : 4; this._hand.visible = true; this._hand.x = Math.max(0, Math.min(Graphics.width - 4, this._hand.x + dx * sp0)); this._hand.y = Math.max(0, Math.min(Graphics.height - 4, this._hand.y + dy * sp0)); }
      if (Input.isTriggered('ok')) { this._hand.visible = true; if (this._held < 0) { this.grab(this._hand.x, this._hand.y); this._viaHand = true; } else this.drop(); }
      if (this._held >= 0 && this._viaHand) { var h = this._layer.children[this._held]; h.x = this._hand.x - this._grabX; h.y = this._hand.y - this._grabY; }
      if (TouchInput.isTriggered() && this._held < 0) { this._hand.visible = false; this._viaHand = false; this.grab(TouchInput.x, TouchInput.y); }
      if (this._held >= 0 && !this._viaHand) {
        var t = this._layer.children[this._held];
        if (TouchInput.isPressed()) { t.x = TouchInput.x - this._grabX; t.y = TouchInput.y - this._grabY; } else this.drop();
      }
      if (Input.isTriggered('cancel') || TouchInput.isCancelled()) this.solve(false);
      this.drawHud();
    };
  }

  /**
   * Shelf-pack the loose pieces by their OWN outline boxes into the free regions, in the given order; each row and each
   * region's block is centred. A piece that fits nowhere is stacked at the last region's centre and `fits` is false.
   * @returns {{pos:Array<Array<number>>, fits:boolean}} top-left of each piece's outline box, by piece index
   */
  function packLoose(cutRes, order, regions, gap) {
    var pos = new Array(cutRes.pieces.length), k = 0;
    for (var r = 0; r < regions.length && k < order.length; r++) {
      var g = regions[r], x = g[0], y = g[1], rowH = 0, rowStart = k, blockStart = k;
      while (k < order.length) {
        var p = cutRes.pieces[order[k]];
        if (x > g[0] && x + p.bw > g[2]) { shiftRow(pos, order, rowStart, k, (g[2] - (x - gap)) / 2, 0); x = g[0]; y += rowH + gap; rowH = 0; rowStart = k; }
        if (x + p.bw > g[2] || y + p.bh > g[3]) break;
        pos[order[k]] = [x, y]; x += p.bw + gap; rowH = Math.max(rowH, p.bh); k++;
      }
      if (k > rowStart) shiftRow(pos, order, rowStart, k, (g[2] - (x - gap)) / 2, 0);
      if (k > blockStart) shiftRow(pos, order, blockStart, k, 0, (g[3] - (y + rowH)) / 2);
    }
    var fits = k === order.length, last = regions[regions.length - 1];
    for (; k < order.length; k++) { var q = cutRes.pieces[order[k]]; pos[order[k]] = [(last[0] + last[2] - q.bw) / 2, (last[1] + last[3] - q.bh) / 2]; }
    return { pos: pos, fits: fits };
  }
  /** Stands in for a BaseTexture's update() while a plaque is drawn (see drawHud). */
  function noUpload() {}
  function shiftRow(pos, order, a, b, dx, dy) { for (var i = a; i < b; i++) { pos[order[i]][0] += dx; pos[order[i]][1] += dy; } }
  function roundRect(c, x, y, w, h, r) {
    c.beginPath(); c.moveTo(x + r, y); c.lineTo(x + w - r, y); c.quadraticCurveTo(x + w, y, x + w, y + r); c.lineTo(x + w, y + h - r);
    c.quadraticCurveTo(x + w, y + h, x + w - r, y + h); c.lineTo(x + r, y + h); c.quadraticCurveTo(x, y + h, x, y + h - r);
    c.lineTo(x, y + r); c.quadraticCurveTo(x, y, x + r, y); c.closePath();
  }

  CSAF.JigsawLite = {
    VERSION: '1.0.0', COLS: COLS, ROWS: ROWS, SNAP: SNAP, P: P, start: start, Scene: Scene_JigsawLite,
    cut: cut, seedOf: seedOf, rng: rng, flattenOutline: flattenOutline, drawPiece: drawPiece, drawTable: drawTable, feltInset: feltInset, bevelOf: bevelOf, margin: margin, packLoose: packLoose,
    /** @returns {{opened:number, handedOff:number, solved:number, setAside:number}} a copy of the counters */
    stats: function () { return { opened: STATS.opened, handedOff: STATS.handedOff, solved: STATS.solved, setAside: STATS.setAside }; }
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.JigsawLite;
