//=============================================================================
// CSAF_PendantLite.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Pendant Lite (free): any picture in your project, hung twice in a gallery, with 3 generated differences to find.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io/
 *
 * @help
 * Pendant Lite is the free sample of Pendant (https://csaf.itch.io/pendant).
 * It does ONE round: three differences of two kinds, something painted out
 * and a detail mirrored, on a picture hung twice on a green gallery wall.
 * Every change is measured to be visible before it is kept. The full Pendant
 * makes 1 to 12 differences of four kinds (it also recolours objects and adds
 * small drawn objects that belong where they land), has hints, a time limit,
 * four wall colours, a seed so the same puzzle comes back, writes finds,
 * misses and time into variables, runs a common event and works in MV too.
 *
 * Use: add the plugin command "Start a spot-the-difference" (CSAF_PendantLite)
 * to an event and pick any file in img/pictures. Script call:
 *   CSAF.PendantLite.start({ picture: 'Castle' })
 *
 * The player clicks or taps either painting where they differ, or moves the
 * hand with the arrow keys (Shift = faster) and presses OK. A find is ringed
 * in ink on both paintings; a click on nothing is a miss. Cancel gives up and
 * shows what was left. The "All found -> switch" parameter is turned ON when
 * all three were found and OFF otherwise, before the event continues.
 *
 * Upgrading: install the full Pendant and this command hands every round to it
 * (at three differences); you can then switch your events to Pendant's own
 * command. Pendant Lite patches no engine method; it adds one scene and one
 * command.
 *
 * @param swAllFound
 * @text All found -> switch
 * @type switch
 * @default 0
 *
 * @command start
 * @text Start a spot-the-difference
 * @desc Hang a picture twice with 3 generated differences for the player to find.
 *
 * @arg picture
 * @text Picture (img/pictures)
 * @type file
 * @dir img/pictures
 * @default
 */

var CSAF = CSAF || {};

(function () {
  'use strict';
  var NAME = 'CSAF_PendantLite';
  var RAW = (typeof PluginManager !== 'undefined' && PluginManager.parameters) ? PluginManager.parameters(NAME) : {};
  /** A plugin parameter as a number: blank = the default (an id of "0" is 0, never truthy). */
  function num(v, d) { var s = String(v === undefined || v === null ? '' : v).trim(); if (s === '') return d; var n = Number(s); return isFinite(n) ? n : d; }
  var P = { swAllFound: Math.max(0, Math.floor(num(RAW.swAllFound, 0))) };
  /** The one round this plugin makes: three differences. */
  var COUNT = 3;
  /** What the plugin has done, for tests and the curious: rounds opened here, handed to the full Pendant, all found. */
  var STATS = { opened: 0, handedOff: 0, allFound: 0, ended: 0 };

  //===========================================================================
  // The difference maker: paint-out and mirror, each measured to be findable
  //===========================================================================
  /** A change must move at least this many pixels by at least this much (sum of channel deltas). */
  var FLOOR = { px: 120, meanDelta: 60 };
  var CHANGED = 40;   // a pixel counts as changed when its channel deltas sum above this
  /** The full Pendant shuffles its twelve drawn objects here; the Lite draws none but takes the same 11 numbers from the
   *  generator, so the seed sequence (and so every change) stays exactly the full Pendant's for the same kinds. */
  var OBJECT_SHUFFLE_DRAWS = 11;

  function seedOf(s) {
    var n = Number(s);
    if (s !== '' && s !== null && s !== undefined && isFinite(n)) return (Math.floor(Math.abs(n)) >>> 0) || 1;
    var h = 2166136261, str = String(s);
    for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    return h || 1;
  }
  function rng(a) {
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /** How visibly b differs from a in the square of half-size r around (cx, cy). @returns {{px:number, meanDelta:number}} */
  function visibility(a, b, cx, cy, r) {
    var W = a.width, H = a.height, n = 0, sum = 0;
    var x0 = Math.max(0, Math.round(cx - r)), x1 = Math.min(W, Math.round(cx + r)), y0 = Math.max(0, Math.round(cy - r)), y1 = Math.min(H, Math.round(cy + r));
    for (var y = y0; y < y1; y++) for (var x = x0; x < x1; x++) {
      var i = (y * W + x) * 4, d = Math.abs(a.data[i] - b.data[i]) + Math.abs(a.data[i + 1] - b.data[i + 1]) + Math.abs(a.data[i + 2] - b.data[i + 2]);
      if (d > CHANGED) { n++; sum += d; }
    }
    return { px: n, meanDelta: n ? Math.round(sum / n) : 0 };
  }

  /** A fixed phase from a centre, so the same place always gets the same outline. */
  function phaseOf(cx, cy) { return (((cx * 73856093) ^ (cy * 19349663)) >>> 0) % 6283 / 1000; }

  /**
   * How much of a change shows at offset (x, y) from its centre: 1 in the core, easing to 0 across a feathered rim whose
   * reach wobbles with the angle, so the edit has no hard circular seam. Never above 0 at or beyond r. @returns {number} 0..1
   */
  function edgeWeight(x, y, r, ph) {
    var dist = Math.sqrt(x * x + y * y);
    if (dist >= r) return 0;
    var th = Math.atan2(y, x), reach = r * (0.86 + 0.08 * Math.sin(3 * th + ph) + 0.06 * Math.sin(2 * th + ph * 1.7));
    var t = (reach - dist) / Math.max(3, r * 0.2);
    if (t <= 0) return 0;
    if (t >= 1) return 1;
    return t * t * (3 - 2 * t);
  }

  /** Blend pixel j of `src` into pixel i of `d` by weight w. */
  function blend(d, i, src, j, w) {
    d[i] = d[i] + (src[j] - d[i]) * w; d[i + 1] = d[i + 1] + (src[j + 1] - d[i + 1]) * w; d[i + 2] = d[i + 2] + (src[j + 2] - d[i + 2]) * w;
  }

  /** Mirror the round patch at (cx, cy) left-to-right, only if it is uneven enough to show. @returns {{x,y,r,asym}|null} */
  function mirror(img, cx, cy, r, o) {
    o = o || {};
    var W = img.width, H = img.height, d = img.data, minAsym = o.minAsym === undefined ? 0.08 : o.minAsym;
    cx = Math.round(cx); cy = Math.round(cy);
    if (cx - r < 0 || cy - r < 0 || cx + r >= W || cy + r >= H) return null;
    var diff = 0, n = 0, x, y, i, j;
    for (y = -r; y <= r; y++) for (x = -r; x <= r; x++) {
      if (x * x + y * y > r * r) continue;
      i = ((cy + y) * W + cx + x) * 4; j = ((cy + y) * W + cx - x) * 4;
      diff += Math.abs(d[i] - d[j]) + Math.abs(d[i + 1] - d[j + 1]) + Math.abs(d[i + 2] - d[j + 2]); n++;
    }
    var asym = n ? diff / n / 765 : 0;
    if (asym < minAsym) return null;
    var snap = new Uint8ClampedArray(d), ph = phaseOf(cx, cy), w;
    for (y = -r; y <= r; y++) for (x = -r; x <= r; x++) {
      if ((w = edgeWeight(x, y, r, ph)) <= 0) continue;
      i = ((cy + y) * W + cx + x) * 4; j = ((cy + y) * W + cx - x) * 4;
      blend(d, i, snap, j, w);
    }
    return { x: cx, y: cy, r: r, asym: Math.round(asym * 1000) / 1000 };
  }

  /** Replace the round patch at (cx, cy) with the one dx across. @returns {{x,y,r,dx}|null} */
  function paintOut(img, cx, cy, r, dx) {
    var W = img.width, H = img.height, d = img.data;
    cx = Math.round(cx); cy = Math.round(cy); dx = Math.round(dx);
    if (cx - r < 0 || cy - r < 0 || cx + r >= W || cy + r >= H || cx + dx - r < 0 || cx + dx + r >= W) return null;
    var snap = new Uint8ClampedArray(d), ph = phaseOf(cx, cy), w;
    for (var y = -r; y <= r; y++) for (var x = -r; x <= r; x++) {
      if ((w = edgeWeight(x, y, r, ph)) <= 0) continue;
      blend(d, ((cy + y) * W + cx + x) * 4, snap, ((cy + y) * W + cx + dx + x) * 4, w);
    }
    return { x: cx, y: cy, r: r, dx: dx };
  }

  function restore(dst, src, cx, cy, r) {
    var W = src.width, H = src.height;
    for (var y = Math.max(0, cy - r); y < Math.min(H, cy + r + 1); y++) for (var x = Math.max(0, cx - r); x < Math.min(W, cx + r + 1); x++) {
      var i = (y * W + x) * 4; dst.data[i] = src.data[i]; dst.data[i + 1] = src.data[i + 1]; dst.data[i + 2] = src.data[i + 2]; dst.data[i + 3] = src.data[i + 3];
    }
  }

  /**
   * The second picture: three changes (a mirror, a paint-out, a mirror, falling back to the other kind where a place
   * refuses), each spaced from the others and each clearing the visibility floor; a change that does not clear it is
   * undone and the next place is tried. The original is never touched.
   * @param {{width:number, height:number, data:Uint8ClampedArray}} img
   * @param {{seed:(number|string)}} [o]
   * @returns {{image:{width,height,data}, changes:Array<{kind,x,y,r}>}}
   */
  function makeDifferences(img, o) {
    o = o || {};
    var W = img.width | 0, H = img.height | 0, out = { width: W, height: H, data: new Uint8ClampedArray(img.data) };
    if (W < 32 || H < 32) return { image: out, changes: [] };
    var want = COUNT;
    var R = rng(seedOf(o.seed === undefined ? 'pendant' : o.seed)), G = 16, cand = [], x, y, k;
    for (y = G * 2; y < H - G * 2; y += G) for (x = G * 2; x < W - G * 2; x += G) cand.push([x + G / 2, y + G / 2]);
    for (k = cand.length - 1; k > 0; k--) { var j = Math.floor(R() * (k + 1)), t = cand[k]; cand[k] = cand[j]; cand[j] = t; }
    // Each slot WANTS a kind (alternating, a mirror first) and keeps it across places; only after HOLD real refusals in a
    // row does it take whichever kind a place allows. Paint-out never refuses, so it is always the LAST fallback.
    var kinds = ['paintout', 'mirror'], ROTATION = [1, 0], ORDER = [[0, 1], [1, 0]], changes = [], refused = 0, HOLD = 24;
    for (k = 0; k < OBJECT_SHUFFLE_DRAWS; k++) R();
    var scarce = [false, false];
    for (var c = 0; c < cand.length && changes.length < want; c++) {
      var kind0 = ROTATION[changes.length % ROTATION.length];
      if (refused >= HOLD) scarce[kind0] = true;
      var cx = cand[c][0], cy = cand[c][1], tries = refused < HOLD && !scarce[kind0] ? 1 : ORDER[kind0].length, made = false, spaced = true;
      for (var a = 0; a < tries; a++) {
        var kind = kinds[ORDER[kind0][a]], r = 18 + Math.floor(R() * 7), res = null;
        for (k = 0; k < changes.length; k++) if (Math.hypot(changes[k].x - cx, changes[k].y - cy) < changes[k].r + r + 8) { spaced = false; break; }
        if (!spaced) break;
        if (kind === 'paintout') res = paintOut(out, cx, cy, r, (R() < 0.5 ? -1 : 1) * r * 2.2);
        else res = mirror(out, cx, cy, r, { minAsym: 0.08 });
        if (!res) continue;
        var v = visibility(img, out, cx, cy, r + 6);
        if (v.px >= FLOOR.px && v.meanDelta >= FLOOR.meanDelta) { changes.push({ kind: kind, x: res.x, y: res.y, r: res.r }); made = true; break; }
        restore(out, img, Math.round(cx), Math.round(cy), r + 1);
      }
      if (made) refused = 0; else if (spaced) refused++;
    }
    return { image: out, changes: changes };
  }

  /** Which change (index) a click at (x, y) lands on, or -1. */
  function hit(changes, x, y) {
    for (var i = 0; i < changes.length; i++) { var c = changes[i]; if (Math.hypot(c.x - x, c.y - y) <= c.r + 6) return i; }
    return -1;
  }

  //===========================================================================
  // The command
  //===========================================================================
  /** The gallery's type: a book serif, never the engine's UI font. */
  var FONT = 'Georgia, "Palatino Linotype", "Book Antiqua", Palatino, "Times New Roman", serif';
  /** The wall: [base, damask, wainscot] (the full Pendant's green). */
  var WALL = [[30, 50, 42], [40, 64, 54], [44, 30, 22]];
  /** The longest side of the picture the differences are made on: the visibility floors were measured at 640. */
  var WORK = 640, SHORT = 160, LONG = 2400;
  function uiScale() { return Math.max(1, Math.min(3, Math.min(Graphics.width, Graphics.height) / 624)); }
  function rec() { if (!$gameSystem._csafPendantLite) $gameSystem._csafPendantLite = { v: 1, count: 0 }; return $gameSystem._csafPendantLite; }

  var pending = null;
  /**
   * Start a 3-difference round on a picture in img/pictures. With the full Pendant installed, the round is handed to it.
   * @param {{picture:string}} args
   * @returns {boolean} whether a round was opened
   */
  function start(args) {
    var pic = String((args && args.picture) || '').trim();
    if (!pic) { console.warn('Pendant Lite: no picture given. Pick a file in img/pictures.'); return false; }
    if (CSAF.Pendant && typeof CSAF.Pendant.start === 'function') { STATS.handedOff++; return CSAF.Pendant.start({ picture: pic, count: COUNT }); }
    var r = rec();
    pending = { picture: pic, seed: 'pl' + r.count + 'm' + ($gameMap ? $gameMap.mapId() : 0) + 'f' + Graphics.frameCount };
    STATS.opened++;
    SceneManager.push(Scene_PendantLite);
    return true;
  }
  if (typeof PluginManager !== 'undefined' && typeof PluginManager.registerCommand === 'function') PluginManager.registerCommand(NAME, 'start', function (args) { start(args); });

  //===========================================================================
  // The scene
  //===========================================================================
  function Scene_PendantLite() { this.initialize.apply(this, arguments); }
  var PT = { side: 0, u: 0, v: 0 };
  if (typeof Scene_Base !== 'undefined') {
    Scene_PendantLite.prototype = Object.create(Scene_Base.prototype);
    Scene_PendantLite.prototype.constructor = Scene_PendantLite;

    Scene_PendantLite.prototype.initialize = function () {
      Scene_Base.prototype.initialize.call(this);
      this._req = pending; pending = null;
      this._picture = this._req ? ImageManager.loadPicture(this._req.picture) : null;
      this._built = false; this._frames = 0; this._done = false; this._doneAge = 0; this._misses = 0; this._foundN = 0; this._hudKey = -1;
    };

    Scene_PendantLite.prototype.isReady = function () { return Scene_Base.prototype.isReady.call(this) && (!this._picture || this._picture.isReady()); };

    Scene_PendantLite.prototype.start = function () {
      Scene_Base.prototype.start.call(this);
      // no usable picture: say so, write the switch OFF (an event's branch must not read a stale value) and close
      if (!this._req || !this._picture || this._picture.width === 0) { console.warn('Pendant Lite: the picture could not be loaded.'); if (P.swAllFound > 0) $gameSwitches.setValue(P.swAllFound, false); this.popScene(); return; }
      this.build();
    };

    /**
     * The layout: side by side, or one above the other, whichever hangs the larger paintings, inside a margin that leaves
     * the picture rail above and the plaque below. @returns {{w,h,f,ax,ay,bx,by,stacked}}
     */
    Scene_PendantLite.prototype.solveLayout = function (pw, ph) {
      var W = Graphics.width, H = Graphics.height, S = uiScale(), top = Math.round(46 * S), foot = Math.round(78 * S), side = Math.round(22 * S), gap = Math.round(26 * S);
      var best = null;
      for (var stacked = 0; stacked < 2; stacked++) {
        var f = Math.round(14 * S), w, h;
        for (var it = 0; it < 3; it++) {
          var aw = stacked ? W - side * 2 - f * 2 : (W - side * 2 - gap - f * 4) / 2, ah = stacked ? (H - top - foot - gap - f * 4) / 2 : H - top - foot - f * 2;
          var k = Math.min(aw / pw, ah / ph); w = Math.max(16, Math.floor(pw * k)); h = Math.max(16, Math.floor(ph * k));
          f = Math.round(Math.max(9 * S, Math.min(30 * S, Math.min(w, h) * 0.075)));
        }
        var L;
        if (stacked) { var x0 = Math.round((W - w) / 2), used = h * 2 + f * 4 + gap, y0 = top + Math.round((H - top - foot - used) / 2) + f; L = { w: w, h: h, f: f, ax: x0, ay: y0, bx: x0, by: y0 + h + f * 2 + gap, stacked: true }; }
        else { var usedW = w * 2 + f * 4 + gap, xa = Math.round((W - usedW) / 2) + f, ya = top + Math.round((H - top - foot - h - f * 2) / 2) + f; L = { w: w, h: h, f: f, ax: xa, ay: ya, bx: xa + w + f * 2 + gap, by: ya, stacked: false }; }
        if (!best || L.w * L.h > best.w * best.h) best = L;
      }
      return best;
    };

    /** Make the differences on a WORK-sized copy of the picture (pixels read ONCE, here), then hang both copies. */
    Scene_PendantLite.prototype.build = function () {
      var W = Graphics.width, H = Graphics.height, S = uiScale(), src = this._picture._image || this._picture.canvas;
      var pw = this._picture.width, ph = this._picture.height, k = Math.min(Math.max(WORK / Math.max(pw, ph), SHORT / Math.min(pw, ph)), LONG / Math.max(pw, ph));
      var ww = Math.max(32, Math.round(pw * k)), wh = Math.max(32, Math.round(ph * k));
      var wc = document.createElement('canvas'); wc.width = ww; wc.height = wh;
      var wx = wc.getContext('2d'); wx.drawImage(src, 0, 0, ww, wh);
      var id = wx.getImageData(0, 0, ww, wh), orig = { width: ww, height: wh, data: id.data };
      var res = makeDifferences(orig, { seed: this._req.seed });
      if (!res.changes.length) { console.warn('Pendant Lite: no visible difference could be made on "' + this._req.picture + '" (a picture with more detail works; the full Pendant has two more kinds of change).'); if (P.swAllFound > 0) $gameSwitches.setValue(P.swAllFound, false); this.popScene(); return; }
      this._changes = res.changes; this._found = []; for (var i = 0; i < res.changes.length; i++) this._found.push(false);
      var cc = document.createElement('canvas'); cc.width = ww; cc.height = wh;
      cc.getContext('2d').putImageData(new ImageData(res.image.data, ww, wh), 0, 0);
      this._work = { w: ww, h: wh, original: wc, changed: cc };
      var L = this.solveLayout(ww, wh); this._L = L; this._S = S;
      // the gallery: wall, rail, cords, lights, frames and both paintings in ONE bitmap, drawn once
      var g = new Bitmap(W, H), c = g.context;
      drawWall(c, W, H, S, WALL);
      drawHanging(c, L, S);
      drawFrame(c, L.ax, L.ay, L.w, L.h, L.f, S); drawFrame(c, L.bx, L.by, L.w, L.h, L.f, S);
      c.imageSmoothingEnabled = true;
      c.drawImage(wc, L.ax, L.ay, L.w, L.h); c.drawImage(cc, L.bx, L.by, L.w, L.h);
      drawLight(c, L, S);
      g._baseTexture.update();
      this.addChild(new Sprite(g));
      // rings: one pre-drawn ink ring per change and painting, hidden until found (no bitmap work during play)
      this._rings = new Sprite(); this.addChild(this._rings); this._ringSp = [];
      var sc = L.w / ww;
      for (i = 0; i < this._changes.length; i++) {
        var ch = this._changes[i], rr = Math.max(9 * S, (ch.r + 4) * sc), pad = Math.ceil(rr * 0.35 + 4), bmp = new Bitmap(Math.ceil(rr * 2 + pad * 2), Math.ceil(rr * 2 + pad * 2));
        drawRing(bmp.context, bmp.width / 2, bmp.height / 2, rr, i * 1.7 + 0.4, Math.max(1.6, 2.2 * S), false); bmp._baseTexture.update();
        var gb = new Bitmap(bmp.width, bmp.height); drawRing(gb.context, gb.width / 2, gb.height / 2, rr, i * 1.7 + 0.4, Math.max(1.6, 2.2 * S), true); gb._baseTexture.update();
        var pair = [];
        for (var side = 0; side < 2; side++) {
          var sp = new Sprite(bmp); sp.anchor.x = sp.anchor.y = 0.5;
          sp.x = (side ? L.bx : L.ax) + ch.x * sc; sp.y = (side ? L.by : L.ay) + ch.y * sc; sp.visible = false; sp._age = 0; sp._ghost = gb; sp._ink = bmp;
          this._rings.addChild(sp); pair.push(sp);
        }
        this._ringSp.push(pair);
      }
      // misses: a small pool of pre-drawn ticks that fade where the player clicked on nothing
      var mb = new Bitmap(Math.round(26 * S), Math.round(26 * S)); drawMiss(mb.context, mb.width, S); mb._baseTexture.update();
      this._missSp = []; this._missNext = 0;
      for (i = 0; i < 4; i++) { var ms = new Sprite(mb); ms.anchor.x = ms.anchor.y = 0.5; ms.opacity = 0; this.addChild(ms); this._missSp.push(ms); }
      // the hand: keyboard players move it with the arrows
      var hand = new Bitmap(28, 28), hc = hand.context;
      hc.fillStyle = 'rgba(255,240,205,0.92)'; hc.strokeStyle = 'rgba(40,25,10,0.9)'; hc.lineWidth = 2;
      hc.beginPath(); hc.moveTo(4, 2); hc.lineTo(4, 22); hc.lineTo(10, 16); hc.lineTo(16, 26); hc.lineTo(20, 24); hc.lineTo(14, 14); hc.lineTo(22, 14); hc.closePath(); hc.fill(); hc.stroke(); hand._baseTexture.update();
      this._hand = new Sprite(hand); this._hand.x = Math.round(L.bx + L.w / 2); this._hand.y = Math.round(L.by + L.h / 2); this._hand.visible = false; this.addChild(this._hand);
      // the plaque: found, time, misses
      var pwid = Math.min(W - 40, Math.round(380 * S)), phgt = Math.round(52 * S);
      this._hud = new Sprite(new Bitmap(pwid, phgt)); this._hud.x = Math.round((W - pwid) / 2); this._hud.y = H - Math.round(78 * S) + Math.round(13 * S); this.addChild(this._hud);
      this._built = true;
      this.drawHud();
    };

    /** The brass plaque: FOUND, TIME, MISSES. Redrawn only when what it says changes. */
    Scene_PendantLite.prototype.drawHud = function () {
      var secs = Math.floor(this._frames / 60);
      var key = secs * 1e6 + this._foundN * 1e4 + Math.min(99, this._misses) * 1e2;
      if (key === this._hudKey) return;
      this._hudKey = key;
      var b = this._hud.bitmap, w = b.width, h = b.height, c = b.context, S = this._S, n = this._changes.length;
      // MZ's Bitmap.drawText and clearRect each end in _baseTexture.update() (rmmz_core.js:1549, :1684), so this plaque's
      // twelve labels marked the texture dirty twelve times per redraw (mz_gate 2026-10-26: 0.867 bitmap dirties a frame
      // under clicks; PIXI still re-uploads a dirty texture once per rendered frame). Hold the marks while the plaque is
      // drawn, then mark once: the same calls, the same pixels. The hold is an own property on this one texture and is
      // DELETED afterwards, so nothing is left shadowing BaseTexture.prototype.update (a first version re-assigned the
      // saved function and left a stale own copy that bypassed the gate's own counter).
      var bt = b._baseTexture;
      bt.update = noUpload;
      try { this.paintHud(b, w, h, c, S, n, secs); } finally { delete bt.update; }
      bt.update();
    };

    /** The plaque's drawing (called by drawHud with the texture upload held). */
    Scene_PendantLite.prototype.paintHud = function (b, w, h, c, S, n, secs) {
      b.clear();
      c.save();
      var gr = c.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, '#d9b670'); gr.addColorStop(0.18, '#b48a44'); gr.addColorStop(0.55, '#8e6a2e'); gr.addColorStop(1, '#5e4318');
      c.fillStyle = 'rgba(0,0,0,0.45)'; roundRect(c, 3, 4, w - 3, h - 3, 6 * S); c.fill();
      c.fillStyle = gr; roundRect(c, 0.5, 0.5, w - 4, h - 4, 6 * S); c.fill();
      c.strokeStyle = 'rgba(60,40,12,0.8)'; c.lineWidth = 1; roundRect(c, 4.5 * S, 4.5 * S, w - 4 - 9 * S, h - 4 - 9 * S, 4 * S); c.stroke();
      c.strokeStyle = 'rgba(255,240,200,0.5)'; roundRect(c, 5.5 * S, 5.5 * S, w - 4 - 11 * S, h - 4 - 11 * S, 3.5 * S); c.stroke();
      var sx = [9 * S, w - 13 * S], sy = [9 * S, h - 13 * S];
      for (var i = 0; i < 2; i++) for (var j = 0; j < 2; j++) { c.fillStyle = '#5a3e14'; c.beginPath(); c.arc(sx[i], sy[j], 2.2 * S, 0, Math.PI * 2); c.fill(); c.strokeStyle = 'rgba(255,236,190,0.7)'; c.beginPath(); c.moveTo(sx[i] - 1.5 * S, sy[j] + 1.5 * S); c.lineTo(sx[i] + 1.5 * S, sy[j] - 1.5 * S); c.stroke(); }
      c.restore();
      b.fontFace = FONT; b.outlineWidth = 0; b.fontItalic = false;
      var cols = 3, cw = Math.floor((w - 4 - 40 * S) / cols), x0 = Math.round(20 * S), y1 = Math.round(5 * S), y2 = Math.round(20 * S), mm = Math.floor(secs / 60), ss = secs % 60;
      var labels = ['FOUND', 'TIME', 'MISSES'], vals = [this._foundN + ' / ' + n, mm + ':' + (ss < 10 ? '0' : '') + ss, String(this._misses)];
      for (i = 0; i < cols; i++) {
        b.fontSize = Math.round(10 * S); b.textColor = 'rgba(255,240,200,0.55)'; b.drawText(labels[i], x0 + cw * i, y1 + 1, cw, Math.round(16 * S), 'center');
        b.textColor = 'rgba(44,28,8,0.85)'; b.drawText(labels[i], x0 + cw * i, y1, cw, Math.round(16 * S), 'center');
        b.fontSize = Math.round(18 * S); b.textColor = 'rgba(255,240,200,0.5)'; b.drawText(vals[i], x0 + cw * i, y2 + 1, cw, Math.round(22 * S), 'center');
        b.textColor = '#2a1a06'; b.drawText(vals[i], x0 + cw * i, y2, cw, Math.round(22 * S), 'center');
      }
    };

    /** Which painting (0, 1) and which work-image point a screen point falls on; writes into `out`, no allocation. */
    Scene_PendantLite.prototype.toWork = function (x, y, out) {
      var L = this._L, k = this._work.w / L.w;
      if (x >= L.ax && y >= L.ay && x < L.ax + L.w && y < L.ay + L.h) { out.side = 0; out.u = (x - L.ax) * k; out.v = (y - L.ay) * k; return true; }
      if (x >= L.bx && y >= L.by && x < L.bx + L.w && y < L.by + L.h) { out.side = 1; out.u = (x - L.bx) * k; out.v = (y - L.by) * k; return true; }
      return false;
    };

    /** A mark at a screen point: a find, a repeat of a find (nothing), a miss, or a press on the wall (nothing). */
    Scene_PendantLite.prototype.markAt = function (x, y) {
      if (this._done || !this.toWork(x, y, PT)) return;
      var i = hit(this._changes, PT.u, PT.v);
      if (i >= 0 && this._found[i]) return;
      if (i >= 0) {
        this._found[i] = true; this._foundN++;
        for (var s = 0; s < 2; s++) { var sp = this._ringSp[i][s]; sp.visible = true; sp._age = 1; sp.scale.x = sp.scale.y = 1.5; sp.opacity = 0; }
        SoundManager.playOk();
        if (this._foundN === this._changes.length) this.finish(true);
        return;
      }
      this._misses++;
      var m = this._missSp[this._missNext]; this._missNext = (this._missNext + 1) % this._missSp.length;
      m.x = x; m.y = y; m.opacity = 255; m.scale.x = m.scale.y = 1.3;
      SoundManager.playBuzzer();
    };

    /** The ending, once: the switch written, unfound differences revealed, a plaque. */
    Scene_PendantLite.prototype.finish = function (all) {
      if (this._done) return;
      this._done = true; this._doneAge = 0; this._allFound = !!all;
      var secs = Math.floor(this._frames / 60);
      rec().count++;
      STATS.ended++; if (this._allFound) STATS.allFound++;
      if (P.swAllFound > 0) $gameSwitches.setValue(P.swAllFound, this._allFound);
      for (var i = 0; i < this._found.length; i++) if (!this._found[i]) for (var s = 0; s < 2; s++) { var sp = this._ringSp[i][s]; sp.bitmap = sp._ghost; sp.visible = true; sp._age = 1; sp.opacity = 0; sp.scale.x = sp.scale.y = 1.2; }
      this.drawHud();
      this.buildPlaque(secs);
    };

    Scene_PendantLite.prototype.buildPlaque = function (secs) {
      var W = Graphics.width, H = Graphics.height, S = this._S, L = this._L, w = Math.min(W - 40, Math.round(380 * S)), h = Math.round(92 * S), n = this._changes.length;
      var b = new Bitmap(w, h), x = b.context;
      x.save();
      x.fillStyle = 'rgba(20,12,6,0.9)'; roundRect(x, 0.5, 0.5, w - 1, h - 1, 9 * S); x.fill();
      x.strokeStyle = 'rgba(232,196,120,0.8)'; x.lineWidth = Math.max(1, S * 0.9); roundRect(x, 4.5 * S, 4.5 * S, w - 9 * S, h - 9 * S, 6 * S); x.stroke();
      x.fillStyle = x.strokeStyle = 'rgba(232,196,120,0.85)';
      var gap = (this._allFound ? 104 : 118) * S, fy0 = 22 * S;
      for (var s = -1; s <= 1; s += 2) {
        var cx = w / 2 + s * gap;
        x.beginPath(); x.moveTo(cx, fy0); x.lineTo(cx + s * 30 * S, fy0); x.stroke();
        x.beginPath(); x.moveTo(cx + s * 36 * S, fy0); x.lineTo(cx + s * 32 * S, fy0 - 3 * S); x.lineTo(cx + s * 28 * S, fy0); x.lineTo(cx + s * 32 * S, fy0 + 3 * S); x.closePath(); x.fill();
      }
      x.restore();
      b.fontFace = FONT; b.outlineWidth = 0;
      b.fontSize = Math.round(23 * S); b.textColor = '#f4e0b0';
      b.drawText(this._allFound ? 'A L L   F O U N D' : 'S E T   A S I D E', 0, Math.round(6 * S), w, Math.round(32 * S), 'center');
      var mm = Math.floor(secs / 60), ss = secs % 60, t = mm + ':' + (ss < 10 ? '0' : '') + ss;
      b.fontSize = Math.round(16 * S); b.textColor = '#e8d4aa';
      b.drawText(this._allFound ? (n + ' differences  ·  ' + t + '  ·  ' + this._misses + (this._misses === 1 ? ' miss' : ' misses')) : (this._foundN + ' of ' + n + ' found  ·  ' + t), 0, Math.round(38 * S), w, Math.round(22 * S), 'center');
      b.fontSize = Math.round(12 * S); b.textColor = 'rgba(232,212,170,0.62)';
      b.drawText(this._allFound ? 'OK to continue' : 'the rest are marked  ·  OK to continue', 0, Math.round(62 * S), w, Math.round(18 * S), 'center');
      this._plaque = new Sprite(b); this._plaque.x = Math.round((W - w) / 2);
      // on the wall under the frames when it fits there, else at the foot of the screen in the counter plaque's place
      var below = Math.max(L.ay, L.by) + L.h + L.f + Math.round(6 * S), room = this._hud.y - Math.round(6 * S) - below;
      if (room >= h) this._plaque.y = below + Math.round((room - h) / 2);
      else { this._plaque.y = Math.max(below, H - h - Math.round(6 * S)); this._hud.visible = false; }
      this._plaque.opacity = 0; this.addChild(this._plaque);
    };

    Scene_PendantLite.prototype.update = function () {
      Scene_Base.prototype.update.call(this);
      if (!this._built) return;
      // found rings settle in: a quick pop from 1.5 to 1 as they fade up
      for (var i = 0; i < this._ringSp.length; i++) for (var s = 0; s < 2; s++) {
        var sp = this._ringSp[i][s];
        if (sp._age > 0 && sp._age <= 14) { var e = sp._age / 14; e = e * e * (3 - 2 * e); sp.opacity = Math.round(255 * Math.min(1, e * 1.4)); sp.scale.x = sp.scale.y = 1.5 - 0.5 * e; sp._age++; }
      }
      for (i = 0; i < this._missSp.length; i++) { var m = this._missSp[i]; if (m.opacity > 0) { m.opacity = Math.max(0, m.opacity - 9); m.scale.x = m.scale.y = Math.max(1, m.scale.x - 0.02); } }
      if (this._done) {
        this._doneAge++;
        if (this._plaque) this._plaque.opacity = Math.max(0, Math.min(255, (this._doneAge - 16) * 12));
        this._hand.visible = false;
        if (this._doneAge > 40 && (Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered())) this.popScene();
        return;
      }
      this._frames++;
      var dx = (Input.isPressed('right') ? 1 : 0) - (Input.isPressed('left') ? 1 : 0), dy = (Input.isPressed('down') ? 1 : 0) - (Input.isPressed('up') ? 1 : 0);
      if (dx || dy) { var sp0 = Input.isPressed('shift') ? 9 : 4; this._hand.visible = true; this._hand.x = Math.max(0, Math.min(Graphics.width - 4, this._hand.x + dx * sp0)); this._hand.y = Math.max(0, Math.min(Graphics.height - 4, this._hand.y + dy * sp0)); }
      if (Input.isTriggered('ok')) { this._hand.visible = true; this.markAt(this._hand.x, this._hand.y); }
      if (TouchInput.isTriggered()) { this._hand.visible = false; this.markAt(TouchInput.x, TouchInput.y); }
      if (!this._done && (Input.isTriggered('cancel') || TouchInput.isCancelled())) this.finish(false);
      this.drawHud();
    };
  }

  //===========================================================================
  // Drawing (once, at build)
  //===========================================================================
  /** The gallery wall: a damask in the wall's own colour, a dado rail and a wainscot, lit from above. */
  function drawWall(c, W, H, S, col) {
    var b = col[0], d = col[1], wn = col[2], dado = Math.round(H * 0.86);
    c.fillStyle = rgb(b); c.fillRect(0, 0, W, H);
    var p = Math.round(34 * S);
    c.fillStyle = rgb(d);
    for (var y = -p, row = 0; y < dado + p; y += p * 0.86, row++) for (var x = (row % 2) * p / 2 - p; x < W + p; x += p) {
      c.beginPath();
      for (var q = 0; q < 4; q++) { var a = q * Math.PI / 2; c.moveTo(x, y); c.quadraticCurveTo(x + Math.cos(a + 0.5) * p * 0.26, y + Math.sin(a + 0.5) * p * 0.26, x + Math.cos(a) * p * 0.22, y + Math.sin(a) * p * 0.22); c.quadraticCurveTo(x + Math.cos(a - 0.5) * p * 0.26, y + Math.sin(a - 0.5) * p * 0.26, x, y); }
      c.fill();
      c.fillRect(x + p / 2 - 1, y + p * 0.43 - 1, 2, 2);
    }
    c.fillStyle = rgb(wn); c.fillRect(0, dado, W, H - dado);
    var pn = Math.round(120 * S);
    for (var px = Math.round(((W % pn) / 2)); px < W; px += pn) {
      c.strokeStyle = 'rgba(0,0,0,0.35)'; c.lineWidth = 2; c.strokeRect(px + 8, dado + 10 * S, pn - 16, H - dado - 18 * S);
      c.strokeStyle = 'rgba(255,220,170,0.08)'; c.lineWidth = 1; c.strokeRect(px + 9.5, dado + 11.5 * S, pn - 19, H - dado - 21 * S);
    }
    var rg = c.createLinearGradient(0, dado - 6 * S, 0, dado + 6 * S);
    rg.addColorStop(0, '#6b4a2c'); rg.addColorStop(0.45, '#9a7044'); rg.addColorStop(1, '#3a2615');
    c.fillStyle = rg; c.fillRect(0, dado - 5 * S, W, 10 * S);
    var v = c.createRadialGradient(W / 2, H * 0.42, Math.min(W, H) * 0.25, W / 2, H * 0.42, Math.max(W, H) * 0.75);
    v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(0,0,0,0.55)');
    c.fillStyle = v; c.fillRect(0, 0, W, H);
  }

  /** The picture rail across the top and two cords per painting, meeting at a brass hook: a pendant pair. */
  function drawHanging(c, L, S) {
    var W = Graphics.width, ry = Math.round(14 * S);
    var rg = c.createLinearGradient(0, ry - 5 * S, 0, ry + 5 * S);
    rg.addColorStop(0, '#2a1a0e'); rg.addColorStop(0.4, '#8a6236'); rg.addColorStop(1, '#24160b');
    c.fillStyle = rg; c.fillRect(0, ry - 5 * S, W, 10 * S);
    var boxes = [[L.ax, L.ay], [L.bx, L.by]];
    for (var i = 0; i < 2; i++) {
      var fx = boxes[i][0] - L.f, fy = boxes[i][1] - L.f, fw = L.w + L.f * 2, hx = fx + fw / 2;
      var hy = (L.stacked && i === 1) ? L.ay + L.h + L.f : ry;
      for (var s = -1; s <= 1; s += 2) {
        var ex = hx + s * fw * 0.32, ey = fy + L.f * 0.3;
        c.strokeStyle = 'rgba(0,0,0,0.35)'; c.lineWidth = 2.6 * S; c.beginPath(); c.moveTo(hx + 2, hy + 3); c.lineTo(ex + 2, ey + 3); c.stroke();
        c.strokeStyle = '#b89254'; c.lineWidth = 1.6 * S; c.beginPath(); c.moveTo(hx, hy); c.lineTo(ex, ey); c.stroke();
        c.strokeStyle = 'rgba(255,240,200,0.45)'; c.lineWidth = 0.7 * S; c.beginPath(); c.moveTo(hx - 0.6, hy); c.lineTo(ex - 0.6, ey); c.stroke();
      }
      var hk = c.createRadialGradient(hx - 1.5 * S, hy - 1.5 * S, 0, hx, hy, 5 * S);
      hk.addColorStop(0, '#fff2c8'); hk.addColorStop(0.5, '#c9a052'); hk.addColorStop(1, '#5a3c14');
      c.fillStyle = hk; c.beginPath(); c.arc(hx, hy, 4.5 * S, 0, Math.PI * 2); c.fill();
    }
  }

  /** A gilt frame around the picture area (x, y, w, h), f wide: mitred, lit from the upper left, with a beaded band. */
  function drawFrame(c, x, y, w, h, f, S) {
    var X0 = x - f, Y0 = y - f, X1 = x + w + f, Y1 = y + h + f;
    c.fillStyle = 'rgba(0,0,0,0.45)'; c.fillRect(X0 + 4 * S, Y0 + 6 * S, X1 - X0, Y1 - Y0);
    var sides = [[X0, Y0, X1, Y0, X1 - f, Y0 + f, X0 + f, Y0 + f, 1.18], [X1, Y0, X1, Y1, X1 - f, Y1 - f, X1 - f, Y0 + f, 0.78], [X1, Y1, X0, Y1, X0 + f, Y1 - f, X1 - f, Y1 - f, 0.66], [X0, Y1, X0, Y0, X0 + f, Y0 + f, X0 + f, Y1 - f, 1.04]];
    for (var s = 0; s < 4; s++) {
      var q = sides[s], k = q[8];
      c.save(); c.beginPath(); c.moveTo(q[0], q[1]); c.lineTo(q[2], q[3]); c.lineTo(q[4], q[5]); c.lineTo(q[6], q[7]); c.closePath(); c.clip();
      var horiz = s % 2 === 0, a0 = horiz ? (s === 0 ? Y0 : Y1) : (s === 3 ? X0 : X1), dir = (s === 0 || s === 3) ? 1 : -1;
      var gr = horiz ? c.createLinearGradient(0, a0, 0, a0 + dir * f) : c.createLinearGradient(a0, 0, a0 + dir * f, 0);
      gr.addColorStop(0, shade([60, 40, 16], k)); gr.addColorStop(0.1, shade([150, 108, 44], k)); gr.addColorStop(0.28, shade([238, 200, 120], k));
      gr.addColorStop(0.45, shade([176, 128, 52], k)); gr.addColorStop(0.62, shade([96, 66, 26], k)); gr.addColorStop(0.78, shade([214, 172, 92], k)); gr.addColorStop(0.9, shade([120, 84, 34], k)); gr.addColorStop(1, shade([40, 26, 10], k));
      c.fillStyle = gr; c.fillRect(X0, Y0, X1 - X0, Y1 - Y0);
      c.restore();
    }
    var bd = Math.max(2.2 * S, f * 0.13), off = f * 0.62, pitch = bd * 1.9;
    var runs = [[X0 + off, Y0 + off, X1 - off, Y0 + off], [X1 - off, Y0 + off, X1 - off, Y1 - off], [X1 - off, Y1 - off, X0 + off, Y1 - off], [X0 + off, Y1 - off, X0 + off, Y0 + off]];
    for (var r = 0; r < 4; r++) {
      var R = runs[r], len = Math.hypot(R[2] - R[0], R[3] - R[1]), n = Math.max(2, Math.floor(len / pitch)), step = len / n, ux = (R[2] - R[0]) / len, uy = (R[3] - R[1]) / len;
      for (var b = 0; b < n; b++) {
        var bx = R[0] + ux * (b + 0.5) * step, by = R[1] + uy * (b + 0.5) * step, bg = c.createRadialGradient(bx - bd * 0.25, by - bd * 0.25, 0, bx, by, bd * 0.5);
        bg.addColorStop(0, '#fff0c0'); bg.addColorStop(0.55, '#c49446'); bg.addColorStop(1, '#4a3010');
        c.fillStyle = bg; c.beginPath(); c.arc(bx, by, bd * 0.5, 0, Math.PI * 2); c.fill();
      }
    }
    var corners = [[X0 + off, Y0 + off], [X1 - off, Y0 + off], [X1 - off, Y1 - off], [X0 + off, Y1 - off]];
    for (var cn = 0; cn < 4; cn++) {
      var cx = corners[cn][0], cy = corners[cn][1], rr = f * 0.3;
      for (var pt = 0; pt < 4; pt++) { var a = pt * Math.PI / 2 + Math.PI / 4; c.fillStyle = '#d8b066'; c.beginPath(); c.ellipse(cx + Math.cos(a) * rr * 0.45, cy + Math.sin(a) * rr * 0.45, rr * 0.42, rr * 0.22, a, 0, Math.PI * 2); c.fill(); }
      var rg = c.createRadialGradient(cx - rr * 0.15, cy - rr * 0.15, 0, cx, cy, rr * 0.4);
      rg.addColorStop(0, '#fff4cc'); rg.addColorStop(1, '#8a5e20'); c.fillStyle = rg; c.beginPath(); c.arc(cx, cy, rr * 0.36, 0, Math.PI * 2); c.fill();
    }
    c.fillStyle = '#1a1006'; c.fillRect(x - 3, y - 3, w + 6, h + 6);
    c.strokeStyle = '#e2c27c'; c.lineWidth = 1; c.strokeRect(x - 1.5, y - 1.5, w + 3, h + 3);
  }

  /** A picture light's warm wash over each painting's upper half, and the lamp itself. */
  function drawLight(c, L, S) {
    var boxes = [[L.ax, L.ay], [L.bx, L.by]];
    for (var i = 0; i < 2; i++) {
      var x = boxes[i][0], y = boxes[i][1], g = c.createRadialGradient(x + L.w / 2, y - L.f, 0, x + L.w / 2, y - L.f, Math.max(L.w, L.h) * 0.9);
      g.addColorStop(0, 'rgba(255,226,160,0.16)'); g.addColorStop(0.5, 'rgba(255,226,160,0.05)'); g.addColorStop(1, 'rgba(255,226,160,0)');
      c.fillStyle = g; c.fillRect(x - L.f, y - L.f, L.w + L.f * 2, L.h + L.f * 2);
      var lx = x + L.w / 2, ly = y - L.f - 9 * S, hw = Math.min(L.w * 0.22, 46 * S);
      c.fillStyle = 'rgba(0,0,0,0.4)'; c.fillRect(lx - hw + 2, ly - 4 * S + 3, hw * 2, 8 * S);
      var lg = c.createLinearGradient(0, ly - 4 * S, 0, ly + 4 * S); lg.addColorStop(0, '#f2d496'); lg.addColorStop(0.5, '#a87a36'); lg.addColorStop(1, '#4a3010');
      c.fillStyle = lg; c.beginPath(); c.moveTo(lx - hw, ly + 4 * S); c.lineTo(lx - hw * 0.8, ly - 4 * S); c.lineTo(lx + hw * 0.8, ly - 4 * S); c.lineTo(lx + hw, ly + 4 * S); c.closePath(); c.fill();
      c.fillStyle = 'rgba(255,240,190,0.9)'; c.fillRect(lx - hw * 0.92, ly + 3 * S, hw * 1.84, 1.4 * S);
    }
  }

  /** An ink ring drawn by hand; `ghost` draws the reveal ring (a dashed ochre pencil line) for a difference left unfound. */
  function drawRing(c, cx, cy, r, ph, lw, ghost) {
    c.save(); c.lineCap = 'round'; c.lineJoin = 'round';
    for (var pass = 0; pass < (ghost ? 1 : 2); pass++) {
      c.beginPath();
      var a0 = ph + pass * 0.9, span = Math.PI * 2 + (ghost ? 0 : 0.35);
      for (var t = 0; t <= 64; t++) {
        var a = a0 + span * t / 64, rr = r * (1 + 0.06 * Math.sin(a * 2 + ph) + 0.03 * Math.sin(a * 5 + ph * 2) + pass * 0.05);
        var px = cx + Math.cos(a) * rr * 1.06, py = cy + Math.sin(a) * rr * 0.96;
        if (t === 0) c.moveTo(px, py); else c.lineTo(px, py);
      }
      if (ghost) { c.setLineDash([lw * 2.4, lw * 2]); c.strokeStyle = 'rgba(30,18,6,0.6)'; c.lineWidth = lw * 2.2; c.stroke(); c.strokeStyle = '#f0c058'; c.lineWidth = lw * 1.1; c.stroke(); }
      else { c.strokeStyle = 'rgba(255,246,226,0.75)'; c.lineWidth = lw * (pass ? 1.6 : 2.4); c.stroke(); c.strokeStyle = pass ? 'rgba(150,20,16,0.85)' : '#b3201a'; c.lineWidth = lw * (pass ? 0.8 : 1.15); c.stroke(); }
    }
    c.restore();
  }

  /** A miss: a short pencil tick-cross, dark with a light edge so it reads on any picture. */
  function drawMiss(c, s, S) {
    c.save(); c.lineCap = 'round';
    var m = s * 0.28;
    for (var pass = 0; pass < 2; pass++) {
      c.strokeStyle = pass ? 'rgba(60,40,30,0.95)' : 'rgba(255,244,224,0.85)'; c.lineWidth = (pass ? 2 : 4) * S;
      c.beginPath(); c.moveTo(m, m); c.lineTo(s - m, s - m); c.moveTo(s - m, m); c.lineTo(m, s - m); c.stroke();
    }
    c.restore();
  }

  /** Stands in for a BaseTexture's update() while a plaque is drawn (see drawHud). */
  function noUpload() {}
  function rgb(a) { return 'rgb(' + Math.round(a[0]) + ',' + Math.round(a[1]) + ',' + Math.round(a[2]) + ')'; }
  function shade(a, k) { return 'rgb(' + Math.min(255, Math.round(a[0] * k)) + ',' + Math.min(255, Math.round(a[1] * k)) + ',' + Math.min(255, Math.round(a[2] * k)) + ')'; }
  function roundRect(c, x, y, w, h, r) {
    c.beginPath(); c.moveTo(x + r, y); c.lineTo(x + w - r, y); c.quadraticCurveTo(x + w, y, x + w, y + r); c.lineTo(x + w, y + h - r);
    c.quadraticCurveTo(x + w, y + h, x + w - r, y + h); c.lineTo(x + r, y + h); c.quadraticCurveTo(x, y + h, x, y + h - r);
    c.lineTo(x, y + r); c.quadraticCurveTo(x, y, x + r, y); c.closePath();
  }

  CSAF.PendantLite = {
    VERSION: '1.0.0', COUNT: COUNT, FLOOR: FLOOR, P: P, start: start, Scene: Scene_PendantLite,
    seedOf: seedOf, rng: rng, visibility: visibility, mirror: mirror, paintOut: paintOut, makeDifferences: makeDifferences, hit: hit,
    /** @returns {{opened:number, handedOff:number, allFound:number, ended:number}} a copy of the counters */
    stats: function () { return { opened: STATS.opened, handedOff: STATS.handedOff, allFound: STATS.allFound, ended: STATS.ended }; }
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.PendantLite;
