//=============================================================================
// CSAF_UnveilLite.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Unveil Lite (free): a Qix-style minigame, claim the silk veil to reveal any picture in your project.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io/
 *
 * @help
 * Unveil Lite is the free sample of Unveil (https://csaf.itch.io/unveil).
 * It does ONE board: your picture under a silk veil, reveal 75% to win, three
 * lives, one creature in the veil and two sparks on the edge. The full Unveil
 * has three veils (silk, frost, lacquer), lets you set the target, lives,
 * creatures and sparks per game, takes a seed so the same game comes back,
 * writes the percent revealed into a variable and lets you choose the sounds.
 *
 * Use: add the plugin command "Start Unveil" (CSAF_UnveilLite) to an event and
 * pick any file in img/pictures. Script call:
 *   CSAF.UnveilLite.start({ picture: 'Castle' })
 *
 * The player walks the edge of the revealed land with the arrow keys; holding
 * OK (or Shift) cuts into the veil. Close the cut on revealed land again and
 * every part of the veil with no creature in it falls away. The creature
 * touching your cut, or a spark touching you, costs a life. Touch: press and
 * drag toward where you want to go; while pressed you cut. On the results, OK
 * or a click leaves. The "Won -> switch" parameter is set ON on a win and OFF
 * on a loss, before the event continues.
 *
 * Upgrading: install the full Unveil and this command hands every game to it
 * (at its defaults); you can then switch your events to Unveil's own command.
 * Unveil Lite patches no engine method; it adds one scene and one command.
 *
 * @param wonSwitch
 * @text Won -> switch
 * @type switch
 * @default 0
 *
 * @command unveil
 * @text Start Unveil
 * @desc Run the reveal minigame over one of your pictures. The event waits until it is over.
 *
 * @arg picture
 * @text Picture (img/pictures)
 * @type file
 * @dir img/pictures
 * @default
 */

var CSAF = CSAF || {};

(function () {
  'use strict';
  var NAME = 'CSAF_UnveilLite';
  var RAW = (typeof PluginManager !== 'undefined' && PluginManager.parameters) ? PluginManager.parameters(NAME) : {};
  /** A plugin parameter as a number: blank = the default (an id of "0" is 0, never truthy). */
  function num(v, d) { var s = String(v === undefined || v === null ? '' : v).trim(); if (s === '') return d; var n = Number(s); return isFinite(n) ? n : d; }
  var P = { wonSwitch: Math.max(0, Math.floor(num(RAW.wonSwitch, 0))) };
  /** The one board this plugin plays: the full Unveil's defaults. */
  var BOARD = { cols: 96, rows: 64, target: 75, lives: 3, creatures: 1, sparks: 2, creatureSpeed: 0.35, sparkEvery: 3 };
  var SE = { cut: 'Cursor1', claim: 'Chime1', hit: 'Damage1' };
  /** What the plugin has done, for tests and the curious: games opened here, handed to the full Unveil, won, lost. */
  var STATS = { opened: 0, handedOff: 0, won: 0, lost: 0 };

  //===========================================================================
  // The rules: a territory-capture game over a grid of cells. Pure JavaScript, no engine calls.
  // CLAIMED (the picture shows through), OPEN (still veiled), TRAIL (the line the player is drawing).
  //===========================================================================
  var OPEN = 0, CLAIMED = 1, TRAIL = 2;
  var SPARK_CLEARANCE = 12;   // a spark moved off enclosed land lands at least this many steps from the player

  function hashString(s) { var h = 0x811c9dc5; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193); } return h >>> 0; }
  function mix(a, b) { var h = Math.imul((a >>> 0) ^ 0x9e3779b9, 0x85ebca6b) ^ (b >>> 0); h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35); return (h ^ (h >>> 16)) >>> 0; }
  function rand(g) { var t = g.rs = (g.rs + 0x6D2B79F5) | 0; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }

  /**
   * A new game on the one board: 96 x 64 cells, target 75%, 3 lives, 1 creature, 2 sparks.
   * @param {number} seed
   * @returns {Object} the game state (typed arrays, no allocation during play)
   */
  function createGame(seed) {
    var cols = BOARD.cols, rows = BOARD.rows;
    var g = { v: 1, seed: seed >>> 0, rs: mix(seed >>> 0, 0x0A11) | 0, cols: cols, rows: rows, cells: new Uint8Array(cols * rows),
      target: BOARD.target, lives: BOARD.lives, creatureSpeed: BOARD.creatureSpeed, sparkEvery: BOARD.sparkEvery,
      px: Math.floor(cols / 2), py: rows - 1, drawing: false, trail: new Int32Array(cols * rows), trailLen: 0, sx: 0, sy: 0,
      creatures: [], sparks: [], claimed: 0, interior: (cols - 2) * (rows - 2), frame: 0, phase: 'play', hits: 0, cuts: 0,
      stack: new Int32Array(cols * rows), mark: new Int32Array(cols * rows), markGen: 0 };
    g.livesMax = g.lives;
    for (var x = 0; x < cols; x++) { g.cells[x] = CLAIMED; g.cells[(rows - 1) * cols + x] = CLAIMED; }
    for (var y = 0; y < rows; y++) { g.cells[y * cols] = CLAIMED; g.cells[y * cols + cols - 1] = CLAIMED; }
    for (var c = 0; c < BOARD.creatures; c++) { var a = rand(g) * Math.PI * 2; g.creatures.push({ x: cols / 2 + (rand(g) - 0.5) * cols * 0.3, y: rows / 2 + (rand(g) - 0.5) * rows * 0.3, vx: Math.cos(a) * g.creatureSpeed, vy: Math.sin(a) * g.creatureSpeed }); }
    for (var s = 0; s < BOARD.sparks; s++) g.sparks.push({ x: s % 2 ? cols - 1 : 0, y: 0, px: -1, py: -1 });
    return g;
  }

  function at(g, x, y) { return (x < 0 || y < 0 || x >= g.cols || y >= g.rows) ? CLAIMED : g.cells[y * g.cols + x]; }
  /** A claimed cell touching the veil (8 neighbours): where the player and the sparks may walk. */
  function isEdge(g, x, y) {
    if (at(g, x, y) !== CLAIMED || x < 0 || y < 0 || x >= g.cols || y >= g.rows) return false;
    for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) { if ((dx || dy) && at(g, x + dx, y + dy) === OPEN) return true; }
    return false;
  }
  /** Percent of the interior claimed (0..100, one decimal). */
  function percent(g) { return Math.round(1000 * g.claimed / g.interior) / 10; }

  /** The nearest edge cell to (x, y), preferring one at least minDist steps from (ax, ay); -1 when none. No allocation. */
  function nearestEdge(g, x, y, ax, ay, minDist) {
    var cols = g.cols, rows = g.rows, head = 0, tail = 0, first = -1, start = y * cols + x;
    g.markGen++; g.stack[tail++] = start; g.mark[start] = g.markGen;
    while (head < tail) {
      var k = g.stack[head++], kx = k % cols, ky = (k - kx) / cols;
      if (isEdge(g, kx, ky)) { if (first < 0) first = k; if (Math.abs(kx - ax) + Math.abs(ky - ay) >= minDist) return k; }
      if (kx > 0 && g.mark[k - 1] !== g.markGen) { g.mark[k - 1] = g.markGen; g.stack[tail++] = k - 1; }
      if (kx < cols - 1 && g.mark[k + 1] !== g.markGen) { g.mark[k + 1] = g.markGen; g.stack[tail++] = k + 1; }
      if (ky > 0 && g.mark[k - cols] !== g.markGen) { g.mark[k - cols] = g.markGen; g.stack[tail++] = k - cols; }
      if (ky < rows - 1 && g.mark[k + cols] !== g.markGen) { g.mark[k + cols] = g.markGen; g.stack[tail++] = k + cols; }
    }
    return first;
  }

  /** Close the trail: the trail becomes claimed land; every open region with no creature in it is claimed too. */
  function claim(g) {
    var cols = g.cols, n = g.cells.length, before = g.claimed, i;
    for (i = 0; i < g.trailLen; i++) { g.cells[g.trail[i]] = CLAIMED; g.claimed++; }
    g.trailLen = 0; g.drawing = false; g.cuts++;
    g.markGen++;
    for (var c = 0; c < g.creatures.length; c++) {
      var cx = Math.floor(g.creatures[c].x), cy = Math.floor(g.creatures[c].y), start = cy * cols + cx;
      if (g.cells[start] !== OPEN || g.mark[start] === g.markGen) continue;
      var sp = 0; g.stack[sp++] = start; g.mark[start] = g.markGen;
      while (sp) {
        var k = g.stack[--sp], kx = k % cols, ky = (k - kx) / cols;
        if (kx > 0 && g.cells[k - 1] === OPEN && g.mark[k - 1] !== g.markGen) { g.mark[k - 1] = g.markGen; g.stack[sp++] = k - 1; }
        if (kx < cols - 1 && g.cells[k + 1] === OPEN && g.mark[k + 1] !== g.markGen) { g.mark[k + 1] = g.markGen; g.stack[sp++] = k + 1; }
        if (ky > 0 && g.cells[k - cols] === OPEN && g.mark[k - cols] !== g.markGen) { g.mark[k - cols] = g.markGen; g.stack[sp++] = k - cols; }
        if (ky < g.rows - 1 && g.cells[k + cols] === OPEN && g.mark[k + cols] !== g.markGen) { g.mark[k + cols] = g.markGen; g.stack[sp++] = k + cols; }
      }
    }
    for (i = 0; i < n; i++) if (g.cells[i] === OPEN && g.mark[i] !== g.markGen) { g.cells[i] = CLAIMED; g.claimed++; }
    if (percent(g) >= g.target) g.phase = 'won';
    else settle(g);
    return g.claimed - before;
  }

  /** After a claim: whoever now stands on land that touches no veil steps to the nearest edge (sparks: not onto the player). */
  function settle(g) {
    var k;
    if (!isEdge(g, g.px, g.py)) { k = nearestEdge(g, g.px, g.py, g.px, g.py, 0); if (k >= 0) { g.px = k % g.cols; g.py = (k - g.px) / g.cols; } }
    for (var s = 0; s < g.sparks.length; s++) {
      var sp = g.sparks[s];
      if (isEdge(g, sp.x, sp.y)) continue;
      k = nearestEdge(g, sp.x, sp.y, g.px, g.py, SPARK_CLEARANCE);
      if (k >= 0) { sp.x = k % g.cols; sp.y = (k - sp.x) / g.cols; sp.px = -1; sp.py = -1; }
    }
  }

  /** The trail is broken (a creature or a spark): a life lost, the trail erased, the player back where it began. */
  function hit(g) {
    for (var i = 0; i < g.trailLen; i++) g.cells[g.trail[i]] = OPEN;
    if (g.drawing) { g.px = g.sx; g.py = g.sy; }
    g.trailLen = 0; g.drawing = false; g.lives--; g.hits++;
    if (g.lives <= 0) { g.lives = 0; g.phase = 'lost'; }
  }

  /**
   * Move the player one cell (dx, dy one of -1/0/1, not both). Without "draw" the player keeps to the edge of the claimed
   * land; with it, it cuts into the veil. Crossing its own trail is refused.
   * @returns {string} 'moved' | 'cut' | 'closed' | 'blocked'
   */
  function move(g, dx, dy, draw) {
    if (g.phase !== 'play' || (dx && dy) || (!dx && !dy)) return 'blocked';
    var nx = g.px + dx, ny = g.py + dy;
    if (nx < 0 || ny < 0 || nx >= g.cols || ny >= g.rows) return 'blocked';
    var c = g.cells[ny * g.cols + nx];
    if (!g.drawing) {
      if (c === CLAIMED) { if (!isEdge(g, nx, ny)) return 'blocked'; g.px = nx; g.py = ny; return 'moved'; }
      if (c === OPEN && draw) { g.drawing = true; g.sx = g.px; g.sy = g.py; g.cells[ny * g.cols + nx] = TRAIL; g.trail[g.trailLen++] = ny * g.cols + nx; g.px = nx; g.py = ny; return 'cut'; }
      return 'blocked';
    }
    if (c === TRAIL) return 'blocked';
    g.px = nx; g.py = ny;
    if (c === OPEN) { g.cells[ny * g.cols + nx] = TRAIL; g.trail[g.trailLen++] = ny * g.cols + nx; return 'cut'; }
    claim(g); return 'closed';
  }

  /** One frame of the world: the creature drifts and bounces, the sparks run the edge. Allocates nothing. */
  function step(g) {
    if (g.phase !== 'play') return g;
    g.frame++;
    for (var c = 0; c < g.creatures.length; c++) {
      var q = g.creatures[c], nx = q.x + q.vx, ny = q.y + q.vy;
      var hx = at(g, Math.floor(nx), Math.floor(q.y)), hy = at(g, Math.floor(q.x), Math.floor(ny));
      if (hx === TRAIL || hy === TRAIL) { hit(g); if (g.phase !== 'play') return g; continue; }
      if (hx === CLAIMED) { q.vx = -q.vx; nx = q.x; }
      if (hy === CLAIMED) { q.vy = -q.vy; ny = q.y; }
      if (at(g, Math.floor(nx), Math.floor(ny)) === OPEN) { q.x = nx; q.y = ny; }
      else { q.vx = -q.vx; q.vy = -q.vy; }
    }
    if (g.frame % g.sparkEvery === 0) for (var s = 0; s < g.sparks.length; s++) {
      var sp = g.sparks[s];
      if (!isEdge(g, sp.x, sp.y)) { var e = nearestEdge(g, sp.x, sp.y, g.px, g.py, SPARK_CLEARANCE); if (e < 0) continue; sp.x = e % g.cols; sp.y = (e - sp.x) / g.cols; sp.px = -1; sp.py = -1; }
      var bx = -1, by = -1, seen = 0;
      for (var d = 0; d < 4; d++) {
        var ex = sp.x + (d === 0 ? 1 : d === 1 ? -1 : 0), ey = sp.y + (d === 2 ? 1 : d === 3 ? -1 : 0);
        if ((ex === sp.px && ey === sp.py) || !isEdge(g, ex, ey)) continue;
        seen++; if (bx < 0 || rand(g) < 1 / seen) { bx = ex; by = ey; }
      }
      if (bx < 0) { bx = sp.px; by = sp.py; if (bx < 0) continue; }
      sp.px = sp.x; sp.py = sp.y; sp.x = bx; sp.y = by;
      if (sp.x === g.px && sp.y === g.py) { hit(g); if (g.phase !== 'play') return g; }
    }
    return g;
  }

  /** The game's outcome. */
  function results(g) { return { won: g.phase === 'won', lost: g.phase === 'lost', percent: percent(g), target: g.target, lives: g.lives, cuts: g.cuts, hits: g.hits, frames: g.frame }; }

  //===========================================================================
  // Drawing: the silk veil, the reveal rim, the trail, the creature, sparks, the marker, the band, the results
  //===========================================================================
  var TAU = Math.PI * 2;
  var FONT = '"Palatino Linotype", "Book Antiqua", Palatino, Georgia, serif';
  var SILK = { name: 'Silk', a: '#5a0f2a', b: '#8e1d45', fold: '#c94a72', rim: '#f3c86b', trail: '#ffe39a', ink: '#fff2dc', glow: '#ffcf6e' };
  function rgba(hex, a) { var n = parseInt(hex.slice(1), 16); return 'rgba(' + (n >> 16 & 255) + ',' + (n >> 8 & 255) + ',' + (n & 255) + ',' + a + ')'; }
  function text(g, s, x, y, size, color, align, weight) { g.font = (weight || '700') + ' ' + size + 'px ' + FONT; g.fillStyle = color; g.textAlign = align || 'left'; g.textBaseline = 'middle'; g.fillText(s, x, y); }
  function roundRect(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.lineTo(x + w - r, y); g.quadraticCurveTo(x + w, y, x + w, y + r); g.lineTo(x + w, y + h - r); g.quadraticCurveTo(x + w, y + h, x + w - r, y + h); g.lineTo(x + r, y + h); g.quadraticCurveTo(x, y + h, x, y + h - r); g.lineTo(x, y + r); g.quadraticCurveTo(x, y, x + r, y); g.closePath(); }
  function scatter(seed) { var s = seed | 0; return function () { s = (s + 0x6D2B79F5) | 0; var t = Math.imul(s ^ (s >>> 15), s | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

  /** The silk veil, filling W x H: draped folds and a woven damask diamond. */
  function veil(g, W, H, seed) {
    var T = SILK, rnd = scatter(seed || 7), i;
    var base = g.createLinearGradient(0, 0, W, H); base.addColorStop(0, T.a); base.addColorStop(1, T.b); g.fillStyle = base; g.fillRect(0, 0, W, H);
    for (i = 0; i < 18; i++) {
      var fx = (i + rnd() * 0.6) * W / 18, fw = 18 + rnd() * 40, fg = g.createLinearGradient(fx - fw, 0, fx + fw, 0);
      fg.addColorStop(0, rgba(T.fold, 0)); fg.addColorStop(0.5, rgba(T.fold, 0.28 + rnd() * 0.18)); fg.addColorStop(1, rgba(T.fold, 0));
      g.fillStyle = fg; g.beginPath(); g.moveTo(fx - fw, 0); g.bezierCurveTo(fx - fw + 20, H * 0.3, fx - fw - 20, H * 0.7, fx - fw + 10, H); g.lineTo(fx + fw + 10, H); g.bezierCurveTo(fx + fw - 20, H * 0.7, fx + fw + 20, H * 0.3, fx + fw, 0); g.closePath(); g.fill();
    }
    g.strokeStyle = rgba(T.rim, 0.25); g.lineWidth = 1;
    for (var dx = -H; dx < W; dx += 28) { g.beginPath(); g.moveTo(dx, 0); g.lineTo(dx + H, H); g.stroke(); g.beginPath(); g.moveTo(dx + H, 0); g.lineTo(dx, H); g.stroke(); }
    var vig = g.createRadialGradient(W / 2, H / 2, H * 0.2, W / 2, H / 2, W * 0.7); vig.addColorStop(0, 'rgba(0,0,0,0)'); vig.addColorStop(1, 'rgba(0,0,0,0.35)'); g.fillStyle = vig; g.fillRect(0, 0, W, H);
  }

  /** Cut the claimed land out of the veil already drawn into g, then strike the rim along every claimed/veil edge. */
  function cutVeil(g, game, cw, ch) {
    var T = SILK, cols = game.cols, rows = game.rows, c = game.cells, x, y, rim = 0;
    g.save(); g.globalCompositeOperation = 'destination-out'; g.fillStyle = '#000';
    for (y = 1; y < rows - 1; y++) for (x = 1; x < cols - 1; x++) if (c[y * cols + x] === 1) g.fillRect(x * cw - 0.5, y * ch - 0.5, cw + 1, ch + 1);
    g.restore();
    g.save(); g.strokeStyle = T.rim; g.lineWidth = 2.2; g.shadowColor = T.glow; g.shadowBlur = 6; g.beginPath();
    for (y = 1; y < rows - 1; y++) for (x = 1; x < cols - 1; x++) {
      if (c[y * cols + x] !== 0) continue;
      if (c[y * cols + x - 1] === 1) { g.moveTo(x * cw, y * ch); g.lineTo(x * cw, (y + 1) * ch); rim++; }
      if (c[y * cols + x + 1] === 1) { g.moveTo((x + 1) * cw, y * ch); g.lineTo((x + 1) * cw, (y + 1) * ch); rim++; }
      if (c[(y - 1) * cols + x] === 1) { g.moveTo(x * cw, y * ch); g.lineTo((x + 1) * cw, y * ch); rim++; }
      if (c[(y + 1) * cols + x] === 1) { g.moveTo(x * cw, (y + 1) * ch); g.lineTo((x + 1) * cw, (y + 1) * ch); rim++; }
    }
    g.stroke(); g.restore();
    return rim;
  }

  /** The trail as a glowing thread through its cells, in order. Redrawn when it grows. */
  function drawTrail(g, game, cw, ch) {
    var T = SILK;
    if (!game.trailLen) return 0;
    g.save(); g.lineCap = 'round'; g.lineJoin = 'round';
    for (var pass = 0; pass < 2; pass++) {
      g.strokeStyle = pass ? '#ffffff' : T.trail; g.lineWidth = pass ? 1.4 : 4; g.shadowColor = T.glow; g.shadowBlur = pass ? 0 : 10;
      g.beginPath(); g.moveTo((game.sx + 0.5) * cw, (game.sy + 0.5) * ch);
      for (var i = 0; i < game.trailLen; i++) { var k = game.trail[i], x = k % game.cols, y = (k - x) / game.cols; g.lineTo((x + 0.5) * cw, (y + 0.5) * ch); }
      g.stroke();
    }
    g.restore();
    return game.trailLen;
  }

  /** The creature: a many-armed wisp in the veil's glow colour, drawn once; the scene spins it. */
  function drawCreature(g, size) {
    var T = SILK, c = size / 2;
    g.save(); g.translate(c, c);
    var halo = g.createRadialGradient(0, 0, 0, 0, 0, c); halo.addColorStop(0, rgba(T.glow, 0.55)); halo.addColorStop(1, rgba(T.glow, 0)); g.fillStyle = halo; g.fillRect(-c, -c, size, size);
    for (var a = 0; a < 7; a++) { var ang = a * TAU / 7; g.strokeStyle = rgba(T.trail, 0.85); g.lineWidth = 2.4; g.beginPath(); g.moveTo(0, 0);
      g.bezierCurveTo(Math.cos(ang) * c * 0.4, Math.sin(ang) * c * 0.4, Math.cos(ang + 0.6) * c * 0.7, Math.sin(ang + 0.6) * c * 0.7, Math.cos(ang + 0.3) * c * 0.92, Math.sin(ang + 0.3) * c * 0.92); g.stroke();
      g.fillStyle = '#ffffff'; g.beginPath(); g.arc(Math.cos(ang + 0.3) * c * 0.92, Math.sin(ang + 0.3) * c * 0.92, 2, 0, TAU); g.fill(); }
    g.fillStyle = T.trail; g.beginPath(); g.arc(0, 0, c * 0.22, 0, TAU); g.fill(); g.fillStyle = '#1a0b12'; g.beginPath(); g.arc(c * 0.06, -c * 0.04, c * 0.08, 0, TAU); g.fill();
    g.restore();
  }
  /** A spark: an ember with rays. */
  function drawSpark(g, size) {
    var T = SILK, c = size / 2; g.save(); g.translate(c, c);
    var gl = g.createRadialGradient(0, 0, 0, 0, 0, c); gl.addColorStop(0, '#ffffff'); gl.addColorStop(0.3, T.glow); gl.addColorStop(1, rgba(T.glow, 0)); g.fillStyle = gl; g.fillRect(-c, -c, size, size);
    g.strokeStyle = '#ffffff'; g.lineWidth = 1.5; for (var r = 0; r < 4; r++) { var a = r * Math.PI / 4; g.beginPath(); g.moveTo(Math.cos(a) * c * 0.9, Math.sin(a) * c * 0.9); g.lineTo(-Math.cos(a) * c * 0.9, -Math.sin(a) * c * 0.9); g.stroke(); }
    g.restore();
  }
  /** The player's marker: a cut-diamond needle. */
  function drawMarker(g, size) {
    var T = SILK, c = size / 2; g.save(); g.translate(c, c);
    g.fillStyle = rgba('#000000', 0.4); g.beginPath(); g.moveTo(1, -c + 3); g.lineTo(c - 1, 1); g.lineTo(1, c - 1); g.lineTo(-c + 3, 1); g.closePath(); g.fill();
    g.fillStyle = T.ink; g.beginPath(); g.moveTo(0, -c + 2); g.lineTo(c - 2, 0); g.lineTo(0, c - 2); g.lineTo(-c + 2, 0); g.closePath(); g.fill();
    g.strokeStyle = T.rim; g.lineWidth = 2; g.stroke(); g.fillStyle = T.rim; g.beginPath(); g.arc(0, 0, c * 0.18, 0, TAU); g.fill();
    g.restore();
  }
  /** The top band: the claimed share against the target, the lives. Drawn when one of them changes. */
  function drawHud(g, W, st) {
    var T = SILK;
    g.save(); g.fillStyle = 'rgba(8,6,10,0.85)'; g.fillRect(0, 0, W, 56);
    var bx = 190, bw = W - 380, by = 18, bh = 18;
    g.fillStyle = 'rgba(255,255,255,0.12)'; roundRect(g, bx, by, bw, bh, 9); g.fill();
    var fw = Math.max(18, bw * Math.min(1, st.percent / 100));
    g.fillStyle = T.rim; roundRect(g, bx, by, fw, bh, 9); g.fill();
    var tx = bx + bw * st.target / 100; g.strokeStyle = '#ffffff'; g.lineWidth = 2; g.beginPath(); g.moveTo(tx, by - 6); g.lineTo(tx, by + bh + 6); g.stroke();
    var label = st.percent.toFixed(1) + '%', lx = bx + bw / 2, ly = by + bh / 2 + 1;
    g.save(); g.beginPath(); g.rect(bx, by - 2, fw, bh + 4); g.clip(); text(g, label, lx, ly, 14, '#120c10', 'center', '700'); g.restore();
    g.save(); g.beginPath(); g.rect(bx + fw, by - 2, bw - fw + 2, bh + 4); g.clip(); g.shadowColor = 'rgba(0,0,0,0.9)'; g.shadowBlur = 4; text(g, label, lx, ly, 14, '#ffffff', 'center', '700'); g.restore();
    text(g, 'target ' + st.target + '%', tx, 49, 12, T.ink, 'center', '600');
    text(g, T.name, 24, 28, 22, T.ink, 'left', '700');
    for (var i = 0; i < st.livesMax; i++) { g.fillStyle = i < st.lives ? T.rim : 'rgba(255,255,255,0.18)'; g.beginPath(); g.moveTo(W - 30 - i * 26, 16); g.lineTo(W - 22 - i * 26, 28); g.lineTo(W - 30 - i * 26, 40); g.lineTo(W - 38 - i * 26, 28); g.closePath(); g.fill(); }
    g.restore();
  }
  /** The results panel. */
  function drawResults(g, W, H, res) {
    var T = SILK, pw = 440, ph = 230, px = (W - pw) / 2, py = H - ph - 30;
    g.save(); g.fillStyle = 'rgba(8,6,10,0.85)'; roundRect(g, px, py, pw, ph, 14); g.fill(); g.strokeStyle = T.rim; g.lineWidth = 3; roundRect(g, px + 3, py + 3, pw - 6, ph - 6, 12); g.stroke();
    text(g, res.won ? 'UNVEILED' : 'THE VEIL HOLDS', W / 2, py + 44, 28, res.won ? T.rim : '#e0786c', 'center', '700');
    text(g, res.percent.toFixed(1) + '% revealed  ·  target ' + res.target + '%', W / 2, py + 98, 20, T.ink, 'center', '600');
    text(g, res.cuts + (res.cuts === 1 ? ' cut' : ' cuts') + '  ·  ' + res.hits + (res.hits === 1 ? ' life lost' : ' lives lost'), W / 2, py + 136, 18, rgba(T.ink, 0.8), 'center', '600');
    text(g, 'OK to leave', W / 2, py + ph - 26, 15, rgba(T.ink, 0.7), 'center', '600');
    g.restore();
  }

  //===========================================================================
  // The command
  //===========================================================================
  var played = 0;
  /**
   * Start a game over a picture in img/pictures. With the full Unveil installed, the game is handed to it.
   * @param {{picture:string}} args
   * @returns {boolean} whether a game was opened
   */
  function start(args) {
    var pic = String((args && args.picture) || '').trim();
    if (!pic) { console.warn('Unveil Lite: name a picture from img/pictures in the command. No game started.'); return false; }
    var full = typeof window !== 'undefined' ? window.Unveil : null;
    if (full && typeof full.start === 'function') { STATS.handedOff++; return full.start({ picture: pic }); }
    var seed = mix(hashString('unveil-lite') ^ (played * 7919), ((typeof $gameSystem !== 'undefined' && $gameSystem ? $gameSystem.playtime() : 0) + Graphics.frameCount) >>> 0);
    played++; STATS.opened++;
    SceneManager.push(Scene_UnveilLite); SceneManager.prepareNextScene({ picture: pic, seed: seed });
    return true;
  }
  if (typeof PluginManager !== 'undefined' && typeof PluginManager.registerCommand === 'function') PluginManager.registerCommand(NAME, 'unveil', function (args) { start(args); });

  //===========================================================================
  // The scene
  //===========================================================================
  var TOP = 56, MOVE_EVERY = 3, MAGNET = 2;
  function Scene_UnveilLite() { this.initialize.apply(this, arguments); }
  if (typeof Scene_Base !== 'undefined') {
    Scene_UnveilLite.prototype = Object.create(Scene_Base.prototype);
    Scene_UnveilLite.prototype.constructor = Scene_UnveilLite;
    Scene_UnveilLite.prototype.prepare = function (req) { this._req = req; };
    Scene_UnveilLite.prototype.create = function () {
      Scene_Base.prototype.create.call(this);
      var req = this._req || { picture: '', seed: 1 };
      this._game = createGame(req.seed);
      this._pic = ImageManager.loadPicture(req.picture);
      this._mode = 'loading'; this._t = 0; this._moveT = 0; this._lastDir = 0;
    };
    Scene_UnveilLite.prototype.isReady = function () { return Scene_Base.prototype.isReady.call(this) && this._pic.isReady(); };
    Scene_UnveilLite.prototype.start = function () {
      Scene_Base.prototype.start.call(this);
      // no usable picture: say so, write the switch OFF (an event's branch must not read a stale value) and close
      if (!this._pic || this._pic.width === 0) { console.warn('Unveil Lite: the picture could not be loaded.'); if (P.wonSwitch > 0) $gameSwitches.setValue(P.wonSwitch, false); this.popScene(); return; }
      var W = Graphics.width, H = Graphics.height - TOP, g = this._game;
      this._cw = W / g.cols; this._ch = H / g.rows;
      var back = new Sprite(new Bitmap(Graphics.width, Graphics.height)); back.bitmap.fillAll('#08060a'); this.addChild(back);
      var pic = new Sprite(this._pic), k = Math.max(W / Math.max(1, this._pic.width), H / Math.max(1, this._pic.height));
      pic.scale.x = k; pic.scale.y = k; pic.x = (W - this._pic.width * k) / 2; pic.y = TOP + (H - this._pic.height * k) / 2;
      var mask = new Sprite(new Bitmap(W, H)); mask.y = TOP; mask.bitmap.fillAll('#ffffff'); pic.mask = mask; this.addChild(mask); this.addChild(pic);
      this._pristine = new Bitmap(W, H); veil(this._pristine.context, W, H, this._req.seed); this._pristine._baseTexture.update();
      this._veil = new Sprite(new Bitmap(W, H)); this._veil.y = TOP; this.addChild(this._veil); this.redrawVeil();
      this._trail = new Sprite(new Bitmap(W, H)); this._trail.y = TOP; this.addChild(this._trail); this._trailShown = -1;
      var cb = new Bitmap(64, 64); drawCreature(cb.context, 64); cb._baseTexture.update();
      this._creatures = [];
      for (var i = 0; i < g.creatures.length; i++) { var s = new Sprite(cb); s.anchor.x = 0.5; s.anchor.y = 0.5; this._creatures.push(s); this.addChild(s); }
      var sb = new Bitmap(24, 24); drawSpark(sb.context, 24); sb._baseTexture.update();
      this._sparks = [];
      for (var j = 0; j < g.sparks.length; j++) { var p = new Sprite(sb); p.anchor.x = 0.5; p.anchor.y = 0.5; this._sparks.push(p); this.addChild(p); }
      var mb = new Bitmap(22, 22); drawMarker(mb.context, 22); mb._baseTexture.update();
      this._marker = new Sprite(mb); this._marker.anchor.x = 0.5; this._marker.anchor.y = 0.5; this.addChild(this._marker);
      this._hud = new Sprite(new Bitmap(Graphics.width, TOP)); this.addChild(this._hud); this._hudKey = -1; this.drawHud();
      this._results = new Sprite(); this._results.visible = false; this.addChild(this._results);
      this.syncSprites();
      this._mode = 'play'; this.startFadeIn(this.fadeSpeed(), false);
    };
    /** The veil minus the revealed land, with its rim: redrawn only when land is claimed. */
    Scene_UnveilLite.prototype.redrawVeil = function () {
      var b = this._veil.bitmap; b.context.clearRect(0, 0, b.width, b.height); b.context.drawImage(this._pristine._canvas, 0, 0);
      cutVeil(b.context, this._game, this._cw, this._ch); b._baseTexture.update(); this._claimedShown = this._game.claimed;
    };
    Scene_UnveilLite.prototype.drawHud = function () {
      var g = this._game, key = g.claimed * 16 + g.lives; if (key === this._hudKey) return; this._hudKey = key;
      var b = this._hud.bitmap; b.context.clearRect(0, 0, b.width, b.height);
      drawHud(b.context, Graphics.width, { percent: percent(g), target: g.target, lives: g.lives, livesMax: g.livesMax }); b._baseTexture.update();
    };
    Scene_UnveilLite.prototype.update = function () {
      Scene_Base.prototype.update.call(this);
      if (this._mode === 'loading' || this.isBusy()) return;
      this._t++;
      if (this._mode === 'play') this.updatePlay();
      else if (this._mode === 'results' && this._t > 30 && (Input.isTriggered('ok') || TouchInput.isTriggered())) this.leave();
    };
    /** Which way the player is steering this frame: arrows, or toward a pressed touch point along its longer axis. */
    Scene_UnveilLite.prototype.steer = function () {
      var g = this._game;
      if (TouchInput.isPressed()) {
        var tx = Math.floor(TouchInput.x / this._cw), ty = Math.floor((TouchInput.y - TOP) / this._ch), dx = tx - g.px, dy = ty - g.py;
        if (!dx && !dy) return this.magnet();
        return Math.abs(dx) >= Math.abs(dy) ? (dx > 0 ? 6 : 4) : (dy > 0 ? 2 : 8);
      }
      return Input.isPressed('left') ? 4 : Input.isPressed('right') ? 6 : Input.isPressed('up') ? 8 : Input.isPressed('down') ? 2 : 0;
    };
    /** A finger that stops a cell or two short of revealed land while cutting still closes the cut onto it. */
    Scene_UnveilLite.prototype.magnet = function () {
      var g = this._game, d = this._lastDir;
      if (!g.drawing || !d) return 0;
      var ux = d === 4 ? -1 : d === 6 ? 1 : 0, uy = d === 8 ? -1 : d === 2 ? 1 : 0;
      for (var k = 1; k <= MAGNET; k++) { var c = at(g, g.px + ux * k, g.py + uy * k); if (c === CLAIMED) return d; if (c !== OPEN) return 0; }
      return 0;
    };
    Scene_UnveilLite.prototype.updatePlay = function () {
      var g = this._game, lives = g.lives;
      if (++this._moveT >= MOVE_EVERY) {
        var dir = this.steer();
        if (dir) {
          this._moveT = 0; this._lastDir = dir;
          var draw = Input.isPressed('ok') || Input.isPressed('shift') || TouchInput.isPressed();
          var r = move(g, dir === 4 ? -1 : dir === 6 ? 1 : 0, dir === 8 ? -1 : dir === 2 ? 1 : 0, draw);
          if (r === 'cut' && g.trailLen === 1) AudioManager.playSe(SE_CUT);
          if (r === 'closed') AudioManager.playSe(SE_CLAIM);
        }
      }
      step(g);
      if (g.lives !== lives) AudioManager.playSe(SE_HIT);
      if (g.claimed !== this._claimedShown) this.redrawVeil();
      if (g.trailLen !== this._trailShown) { var tb = this._trail.bitmap; tb.context.clearRect(0, 0, tb.width, tb.height); drawTrail(tb.context, g, this._cw, this._ch); tb._baseTexture.update(); this._trailShown = g.trailLen; }
      this.syncSprites(); this.drawHud();
      if (g.phase !== 'play') this.showResults();
    };
    /** The creature spins, sparks flicker, the marker follows the player. No allocation. */
    Scene_UnveilLite.prototype.syncSprites = function () {
      var g = this._game, cw = this._cw, ch = this._ch;
      for (var i = 0; i < this._creatures.length; i++) { var s = this._creatures[i], q = g.creatures[i]; s.x = q.x * cw; s.y = TOP + q.y * ch; s.rotation += 0.06; }
      for (var j = 0; j < this._sparks.length; j++) { var p = this._sparks[j], k = g.sparks[j]; p.x = (k.x + 0.5) * cw; p.y = TOP + (k.y + 0.5) * ch; p.scale.x = p.scale.y = (g.frame + j) % 6 < 3 ? 1 : 0.8; }
      this._marker.x = (g.px + 0.5) * cw; this._marker.y = TOP + (g.py + 0.5) * ch;
    };
    Scene_UnveilLite.prototype.showResults = function () {
      var res = results(this._game), bmp = new Bitmap(Graphics.width, Graphics.height);
      drawResults(bmp.context, Graphics.width, Graphics.height, res); bmp._baseTexture.update();
      // won: the whole picture, nothing over it
      if (res.won) { this._veil.visible = false; this._trail.visible = false; this._marker.visible = false; for (var i = 0; i < this._creatures.length; i++) this._creatures[i].visible = false; for (var j = 0; j < this._sparks.length; j++) this._sparks[j].visible = false; }
      this._results.bitmap = bmp; this._results.visible = true; this._res = res; this._mode = 'results'; this._t = 0;
      if (res.won) STATS.won++; else STATS.lost++;
    };
    /** Leave: the switch written, then back to the map (the event continues). */
    Scene_UnveilLite.prototype.leave = function () {
      if (P.wonSwitch > 0) $gameSwitches.setValue(P.wonSwitch, !!this._res.won);
      this.popScene();
    };
    Scene_UnveilLite.prototype.stop = function () { Scene_Base.prototype.stop.call(this); this.startFadeOut(this.fadeSpeed(), false); };
  }
  var SE_CUT = { name: SE.cut, volume: 60, pitch: 100, pan: 0 }, SE_CLAIM = { name: SE.claim, volume: 85, pitch: 100, pan: 0 }, SE_HIT = { name: SE.hit, volume: 85, pitch: 100, pan: 0 };

  CSAF.UnveilLite = {
    VERSION: '1.0.0', BOARD: BOARD, P: P, OPEN: OPEN, CLAIMED: CLAIMED, TRAIL: TRAIL, start: start, Scene: Scene_UnveilLite,
    hashString: hashString, mix: mix, createGame: createGame, at: at, isEdge: isEdge, percent: percent, nearestEdge: nearestEdge,
    claim: claim, move: move, step: step, results: results, veil: veil, cutVeil: cutVeil, drawTrail: drawTrail,
    /** @returns {{opened:number, handedOff:number, won:number, lost:number}} a copy of the counters */
    stats: function () { return { opened: STATS.opened, handedOff: STATS.handedOff, won: STATS.won, lost: STATS.lost }; }
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.UnveilLite;
