//=============================================================================
// AloftPaint.js — Aloft [2/3]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Aloft [2/3] — the painter: every underside, hanger, cloud, wisp and mote is drawn here. No settings here; see Aloft.js. v1.0.0
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help AloftPaint.js
 *
 * Part 2 of 3. Load all three: AloftCore.js, AloftPaint.js and Aloft.js.
 * Any order works. No image files are loaded: everything Aloft shows is
 * drawn with the canvas when a map loads, then only moved.
 *
 * Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.
 */

'use strict';

if (typeof globalThis.CSAF === 'undefined') globalThis.CSAF = {};

(function () {
  var TAU = Math.PI * 2;
  var TILE = 48;   /* set to the map's tile size by Aloft.js before a bake (setTile) */
  function setTile(n) { TILE = n > 0 ? n : 48; return TILE; }
  function core() { return globalThis.CSAF.AloftCore; }
  function C(a, alpha) { return core().css(a, alpha); }
  function mix(a, b, t) { return core().mix(a, b, t); }
  function shade(a, k) { return core().shade(a, k); }
  var WHITE = [255, 255, 255], BLACK = [0, 0, 0];

  /* --------------------------------------------------------- primitives --*/
  /** a tapering stroke along points [[x,y]...] from width w0 to w1 */
  function taperLine(ctx, pts, w0, w1, color) {
    ctx.strokeStyle = color; ctx.lineCap = 'round';
    for (var i = 1; i < pts.length; i++) {
      var t = (i - 1) / Math.max(1, pts.length - 2);
      ctx.lineWidth = w0 + (w1 - w0) * t;
      ctx.beginPath(); ctx.moveTo(pts[i - 1][0], pts[i - 1][1]); ctx.lineTo(pts[i][0], pts[i][1]); ctx.stroke();
    }
  }
  /** a wandering strand hanging from (x,y): n points, length len, sway amplitude a */
  function strand(rng, x, y, len, a, n) {
    var pts = [[x, y]], ph = rng.range(0, TAU), f = rng.range(0.8, 1.6), dx = 0;
    for (var i = 1; i <= n; i++) {
      var t = i / n;
      dx += rng.range(-a, a) * 0.35;
      pts.push([x + Math.sin(ph + t * f * Math.PI) * a * t + dx, y + len * t]);
    }
    return pts;
  }
  function blob(ctx, x, y, r, color) { ctx.fillStyle = color; ctx.beginPath(); ctx.arc(x, y, Math.max(0.5, r), 0, TAU); ctx.fill(); }
  function poly(ctx, pts, fill, stroke, lw) {
    ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]);
    for (var i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
    ctx.closePath();
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lw || 1; ctx.stroke(); }
  }
  /** a lit hexagonal prism pointing DOWN from (x,y), length len, width wd, tilt rad */
  function prism(ctx, x, y, len, wd, tilt, base, glow) {
    var cs = Math.cos(tilt), sn = Math.sin(tilt);
    function P(u, v) { return [x + u * cs - v * sn, y + u * sn + v * cs]; }
    var L = P(-wd / 2, 0), R = P(wd / 2, 0), ML = P(-wd / 2, len * 0.72), MR = P(wd / 2, len * 0.72), M = P(0, len * 0.08), MM = P(0, len * 0.8), T = P(0, len);
    poly(ctx, [L, M, MM, ML], C(mix(base, WHITE, 0.25)));
    poly(ctx, [M, R, MR, MM], C(shade(base, 0.62)));
    poly(ctx, [ML, MM, T], C(mix(base, WHITE, 0.08)));
    poly(ctx, [MM, MR, T], C(shade(base, 0.45)));
    ctx.strokeStyle = C(mix(base, WHITE, 0.75), 0.85); ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(M[0], M[1]); ctx.lineTo(MM[0], MM[1]); ctx.lineTo(T[0], T[1]); ctx.stroke();
    if (glow) { ctx.globalCompositeOperation = 'lighter'; blob(ctx, T[0], T[1], wd * 0.6, C(glow, 0.35)); ctx.globalCompositeOperation = 'source-over'; }
  }

  /* --------------------------------------------------------- undersides --*/
  /**
   * The underside of one island, drawn into a bitmap whose origin is map pixel (ox, oy).
   * @param {CanvasRenderingContext2D} ctx
   * @param {object} prof  AloftCore.profile() result
   * @param {object} pal   AloftCore.derivePalette() result
   * @param {string} dressing
   * @param {Rng} rng
   * @param {number} ox @param {number} oy
   * @param {HTMLCanvasElement|null} lipSrc  a 48 x (k*48) strip of the buyer's edge tiles, one per column in order, or null
   */
  function drawUnderside(ctx, prof, pal, dressing, rng, ox, oy, lipSrc) {
    if (!prof.cols.length) return 0;
    var D = core().DRESSINGS[dressing] || core().DRESSINGS.garden, cols = prof.cols, ops = 0;
    /* ---- the outline: top along the columns, bottom along the keel, ends tucked under ---- */
    var top = [], bot = [];
    for (var i = 0; i < cols.length; i++) {
      var c = cols[i], x0 = c.x * TILE - ox, x1 = x0 + TILE;
      top.push([x0, c.top - oy], [x1, c.top - oy]);
      bot.push([x0 + TILE * 0.5, c.bottom - oy]);
    }
    var first = cols[0], last = cols[cols.length - 1];
    var inset = Math.min(TILE * 0.6, (last.x - first.x + 1) * TILE * 0.18);
    var keel = [];
    keel.push([last.x * TILE + TILE - ox, last.top - oy + TILE * 0.2]);
    keel.push([last.x * TILE + TILE - inset - ox, (last.top + last.bottom) / 2 - oy]);
    var style = D.bottom;
    for (var k = bot.length - 1; k >= 0; k--) {
      var p = bot[k], nx = bot[k - 1];
      if (style === 'stepped') { keel.push([p[0] + TILE * 0.5, p[1]], [p[0] - TILE * 0.5, p[1]]); }
      else if (style === 'spikes' || style === 'points') {
        keel.push([p[0] + TILE * 0.3, p[1] - TILE * 0.18]);
        keel.push([p[0] + rng.range(-6, 6), p[1] + TILE * rng.range(0.25, style === 'spikes' ? 0.9 : 0.55)]);
        keel.push([p[0] - TILE * 0.3, p[1] - TILE * 0.18]);
      } else if (style === 'flat') { keel.push([p[0], p[1] - 4]); }
      else {
        keel.push(p);
        if (nx) keel.push([(p[0] + nx[0]) / 2, (p[1] + nx[1]) / 2 + rng.range(-3, 5)]);
      }
    }
    keel.push([first.x * TILE + inset - ox, (first.top + first.bottom) / 2 - oy]);
    keel.push([first.x * TILE - ox, first.top - oy + TILE * 0.2]);
    var outline = top.concat(keel);
    var minY = 1e9, maxY = -1e9;
    for (var o = 0; o < outline.length; o++) { if (outline[o][1] < minY) minY = outline[o][1]; if (outline[o][1] > maxY) maxY = outline[o][1]; }
    function trace() {
      ctx.beginPath(); ctx.moveTo(outline[0][0], outline[0][1]);
      if (style === 'round' || style === 'flat') {
        for (var q = 1; q < top.length; q++) ctx.lineTo(outline[q][0], outline[q][1]);
        for (var r = top.length; r < outline.length; r++) {
          var a = outline[r], b = outline[r + 1] || outline[0];
          ctx.quadraticCurveTo(a[0], a[1], (a[0] + b[0]) / 2, (a[1] + b[1]) / 2);
        }
      } else for (var s = 1; s < outline.length; s++) ctx.lineTo(outline[s][0], outline[s][1]);
      ctx.closePath();
    }
    /* ---- body fill: the strata as a vertical gradient ---- */
    var g = ctx.createLinearGradient(0, minY, 0, maxY);
    for (var st = 0; st < pal.strata.length; st++) g.addColorStop(st / (pal.strata.length - 1), C(pal.strata[st]));
    trace(); ctx.fillStyle = g; ctx.fill(); ops++;
    ctx.save(); trace(); ctx.clip();
    var W = (last.x - first.x + 1) * TILE, X0 = first.x * TILE - ox;
    if (D.body === 'earth') ops += earthBody(ctx, rng, pal, cols, ox, oy, X0, W, minY, maxY);
    else if (D.body === 'masonry') ops += masonryBody(ctx, rng, pal, cols, ox, oy, X0, W, minY, maxY);
    else if (D.body === 'geode') ops += geodeBody(ctx, rng, pal, X0, W, minY, maxY);
    else if (D.body === 'plated') ops += platedBody(ctx, rng, pal, cols, ox, oy, X0, W, minY, maxY);
    else ops += jaggedBody(ctx, rng, pal, X0, W, minY, maxY);
    /* light from the upper left, shade to the lower right, and the dark under the lip */
    var lg = ctx.createLinearGradient(X0, 0, X0 + W, 0);
    lg.addColorStop(0, C(pal.highlight, 0.28)); lg.addColorStop(0.35, C(pal.highlight, 0)); lg.addColorStop(0.7, 'rgba(0,0,0,0)'); lg.addColorStop(1, 'rgba(0,0,0,0.32)');
    ctx.fillStyle = lg; ctx.fillRect(X0 - 4, minY - 4, W + 8, maxY - minY + 8);
    /* lighter than the first cut: at 0.38 / 0.45 the earth read as a VOID and four tilesets' rock all read dark brown
     * (fresh review, 2026-10-27) */
    var vg = ctx.createLinearGradient(0, minY, 0, maxY);
    vg.addColorStop(0, 'rgba(0,0,0,0.24)'); vg.addColorStop(0.16, 'rgba(0,0,0,0.02)'); vg.addColorStop(0.75, 'rgba(0,0,0,0.05)'); vg.addColorStop(1, 'rgba(0,0,0,0.28)');
    ctx.fillStyle = vg; ctx.fillRect(X0 - 4, minY - 4, W + 8, maxY - minY + 8);
    ctx.restore();
    /* a rim light along the keel so the mass reads against the cloud sea */
    trace(); ctx.strokeStyle = C(pal.keel, 0.9); ctx.lineWidth = 2; ctx.stroke(); ops++;
    /* ---- the lip: the buyer's own edge tiles, mirrored, darkened, finished per dressing ---- */
    ops += drawLip(ctx, cols, pal, D.lip, rng, ox, oy, lipSrc);
    ops += drawBottomDetail(ctx, cols, pal, style, rng, ox, oy);
    return ops;
  }

  function earthBody(ctx, rng, pal, cols, ox, oy, X0, W, minY, maxY) {
    var ops = 0, bands = 5 + Math.floor((maxY - minY) / 40);
    for (var b = 1; b < bands; b++) {
      var col = pal.strata[Math.min(pal.strata.length - 1, Math.floor(b * pal.strata.length / bands))];
      ctx.beginPath();
      for (var i = 0; i <= W; i += 8) {
        var c = cols[Math.min(cols.length - 1, Math.floor(i / TILE))];
        var y = c.top - oy + (b / bands) * (maxY - (c.top - oy)) * 1.05 + Math.sin(i * 0.05 + b) * 3 + rng.range(-1.2, 1.2);
        if (i === 0) ctx.moveTo(X0 + i, y); else ctx.lineTo(X0 + i, y);
      }
      ctx.strokeStyle = C(shade(col, 0.7), 0.85); ctx.lineWidth = rng.range(1.5, 3); ctx.stroke();
      ctx.strokeStyle = C(mix(col, WHITE, 0.18), 0.35); ctx.lineWidth = 1; ctx.translate(0, -2); ctx.stroke(); ctx.translate(0, 2);
      ops += 2;
    }
    /* buried stones: fewer, flattened and lying in the beds (round evenly spread dots read as POLKA DOTS, fresh review) */
    var n = Math.floor(W * (maxY - minY) / 2200);
    for (var k = 0; k < n; k++) {
      var px = X0 + rng.range(0, W), py = rng.range(minY + 14, maxY - 6), rx = rng.range(2, 6), ry = rx * rng.range(0.45, 0.7);
      ctx.fillStyle = C(pal.crack, 0.55); ctx.beginPath(); ctx.ellipse(px + 1, py + 1.2, rx, ry, rng.range(-0.3, 0.3), 0, TAU); ctx.fill();
      ctx.fillStyle = C(mix(pal.strata[2], WHITE, rng.range(0.1, 0.32)), 0.85); ctx.beginPath(); ctx.ellipse(px, py, rx, ry, rng.range(-0.3, 0.3), 0, TAU); ctx.fill(); ops += 2;
    }
    return ops;
  }
  function masonryBody(ctx, rng, pal, cols, ox, oy, X0, W, minY, maxY) {
    var ops = 0, course = 16;
    for (var y = minY + 8, row = 0; y < maxY; y += course, row++) {
      var off = (row % 2) * 14;
      for (var x = X0 - 30 + off; x < X0 + W + 30; x += rng.range(22, 34)) {
        var bw = rng.range(20, 32), tone = pal.strata[Math.min(pal.strata.length - 1, Math.floor((y - minY) / (maxY - minY + 1) * pal.strata.length))];
        ctx.fillStyle = C(mix(tone, WHITE, rng.range(-0.05, 0.16) < 0 ? 0 : rng.range(0, 0.16)));
        ctx.fillRect(x + 1, y + 1, bw - 2, course - 2);
        ctx.fillStyle = C(shade(tone, 0.55), 0.8); ctx.fillRect(x + 1, y + course - 3, bw - 2, 2);
        ctx.fillStyle = C(mix(tone, WHITE, 0.3), 0.6); ctx.fillRect(x + 1, y + 1, bw - 2, 1);
        if (rng.next() < 0.12) { ctx.strokeStyle = C(pal.crack, 0.8); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x + bw * 0.3, y + 2); ctx.lineTo(x + bw * 0.5, y + course * 0.6); ctx.lineTo(x + bw * 0.42, y + course - 2); ctx.stroke(); }
        ops += 3;
      }
    }
    return ops;
  }
  function geodeBody(ctx, rng, pal, X0, W, minY, maxY) {
    var ops = 0, n = Math.max(6, Math.floor(W * (maxY - minY) / 700));
    for (var k = 0; k < n; k++) {
      var cx = X0 + rng.range(0, W), cy = rng.range(minY, maxY), r = rng.range(10, 26), sides = rng.int(4, 6), ph = rng.range(0, TAU), pts = [];
      for (var s = 0; s < sides; s++) { var a = ph + s * TAU / sides; pts.push([cx + Math.cos(a) * r * rng.range(0.7, 1.1), cy + Math.sin(a) * r * rng.range(0.7, 1.1)]); }
      var base = pal.strata[rng.int(0, pal.strata.length - 1)];
      poly(ctx, pts, C(mix(base, rng.next() < 0.5 ? WHITE : BLACK, rng.range(0.05, 0.22))), C(shade(base, 0.6), 0.7), 1); ops++;
    }
    /* veins of the accent colour */
    for (var v = 0; v < Math.max(2, W / 90); v++) {
      var vx = X0 + rng.range(0, W), vy = minY + rng.range(5, 30), pts2 = [[vx, vy]];
      for (var j = 0; j < 6; j++) { vx += rng.range(-14, 14); vy += rng.range(8, 20); pts2.push([vx, vy]); }
      taperLine(ctx, pts2, 2.2, 0.6, C(pal.accent, 0.55)); ops++;
    }
    return ops;
  }
  function platedBody(ctx, rng, pal, cols, ox, oy, X0, W, minY, maxY) {
    var ops = earthBody(ctx, rng, pal, cols, ox, oy, X0, W, minY, maxY);
    /* riveted brass bands wrapped round the rock */
    var brass = pal.accent;
    for (var b = 0; b < 2; b++) {
      var y = minY + (maxY - minY) * (0.32 + b * 0.3);
      ctx.fillStyle = C(shade(brass, 0.55)); ctx.fillRect(X0 - 4, y + 2, W + 8, 9);
      ctx.fillStyle = C(brass); ctx.fillRect(X0 - 4, y, W + 8, 8);
      ctx.fillStyle = C(mix(brass, WHITE, 0.45)); ctx.fillRect(X0 - 4, y, W + 8, 2);
      for (var x = X0 + 6; x < X0 + W; x += 14) { blob(ctx, x, y + 4, 1.8, C(shade(brass, 0.4))); blob(ctx, x - 0.5, y + 3.5, 0.9, C(mix(brass, WHITE, 0.6))); ops += 2; }
      ops += 3;
    }
    return ops;
  }
  function jaggedBody(ctx, rng, pal, X0, W, minY, maxY) {
    var ops = 0, n = Math.max(8, Math.floor(W / 14));
    for (var k = 0; k < n; k++) {
      var x = X0 + rng.range(-10, W + 10), y = rng.range(minY - 10, maxY), w = rng.range(10, 30), h = rng.range(20, 60);
      var base = pal.strata[rng.int(1, pal.strata.length - 1)];
      poly(ctx, [[x, y], [x + w, y + h * 0.3], [x + w * 0.7, y + h], [x - w * 0.2, y + h * 0.6]], C(mix(base, WHITE, rng.range(0, 0.14))), null); ops++;
      ctx.strokeStyle = C(mix(base, WHITE, 0.4), 0.5); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + w, y + h * 0.3); ctx.stroke(); ops++;
    }
    for (var f = 0; f < W / 40; f++) {
      var fx = X0 + rng.range(0, W), fy = minY + rng.range(0, 20), pts = [[fx, fy]];
      for (var j = 0; j < 5; j++) { fx += rng.range(-10, 10); fy += rng.range(10, 24); pts.push([fx, fy]); }
      taperLine(ctx, pts, 1.6, 0.5, C(pal.crack, 0.9)); ops++;
    }
    return ops;
  }

  /** the lip under the ground edge: the edge tile's own bottom rows, mirrored and darkened, then finished */
  function drawLip(ctx, cols, pal, lip, rng, ox, oy, lipSrc) {
    /* the band hangs BELOW the tile's edge, where it can be seen (the first cut drew it behind the tile's own bottom
     * half, so the caption described a band nobody could find: fresh review, 2026-10-27) */
    var ops = 0, H = Math.round(TILE * 0.36);
    for (var i = 0; i < cols.length; i++) {
      var c = cols[i], x = c.x * TILE - ox, y = c.top - oy + TILE * 0.5 + H;
      if (lipSrc) {
        ctx.save(); ctx.translate(x, y); ctx.scale(1, -1);
        ctx.drawImage(lipSrc, i * TILE, TILE - H, TILE, H, 0, 0, TILE, H);
        ctx.restore();
        var lg2 = ctx.createLinearGradient(0, y - H, 0, y);
        lg2.addColorStop(0, 'rgba(0,0,0,0.12)'); lg2.addColorStop(1, 'rgba(0,0,0,0.42)');
        ctx.fillStyle = lg2; ctx.fillRect(x, y - H, TILE, H); ops += 2;
      } else { ctx.fillStyle = C(pal.lip); ctx.fillRect(x, y - H, TILE, H); ops++; }
      /* the ragged under-edge of the lip */
      for (var px = 0; px < TILE; px += 3) {
        var len = lip === 'turf' ? rng.range(2, 9) : (lip === 'crystal' ? rng.range(1, 6) : rng.range(1, 4));
        if (lip === 'turf') { ctx.strokeStyle = C(mix(pal.lip, BLACK, rng.range(0.1, 0.4))); ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(x + px, y - 1); ctx.lineTo(x + px + rng.range(-1.5, 1.5), y + len); ctx.stroke(); }
        else if (lip === 'stone') { ctx.fillStyle = C(shade(pal.strata[0], rng.range(0.7, 1))); ctx.fillRect(x + px, y - 1, 3, len); }
        else if (lip === 'crystal') { if (rng.next() < 0.35) prism(ctx, x + px, y - 2, len * 2.2, 3, rng.range(-0.3, 0.3), pal.accent, null); }
        else if (lip === 'brass') { ctx.fillStyle = C(shade(pal.accent, 0.8)); ctx.fillRect(x + px, y - 2, 3, 3); }
        else { ctx.fillStyle = C(shade(pal.strata[1], rng.range(0.5, 0.8))); ctx.beginPath(); ctx.moveTo(x + px, y - 1); ctx.lineTo(x + px + 3, y - 1); ctx.lineTo(x + px + 1.5, y + len * 1.6); ctx.fill(); }
        ops++;
      }
      if (lip === 'brass') { ctx.fillStyle = C(pal.accent); ctx.fillRect(x, y - 3, TILE, 3); ctx.fillStyle = C(mix(pal.accent, WHITE, 0.5)); ctx.fillRect(x, y - 3, TILE, 1); ops += 2; }
    }
    return ops;
  }

  /** what hangs off the keel itself: drips, block corbels, crystal tips, a brass keel band, spikes */
  function drawBottomDetail(ctx, cols, pal, style, rng, ox, oy) {
    var ops = 0;
    for (var i = 0; i < cols.length; i++) {
      var c = cols[i], x = c.x * TILE - ox + TILE * 0.5, y = c.bottom - oy;
      if (style === 'round') { for (var d = 0; d < 2; d++) { var dx = x + rng.range(-18, 18), len = rng.range(5, 14); poly(ctx, [[dx - 3, y - 6], [dx + 3, y - 6], [dx, y + len]], C(pal.strata[3]), null); ops++; } }
      else if (style === 'stepped') { ctx.fillStyle = C(shade(pal.strata[2], 0.85)); ctx.fillRect(x - 10, y - 2, 20, 8); ctx.fillStyle = C(mix(pal.strata[2], WHITE, 0.25)); ctx.fillRect(x - 10, y - 2, 20, 2); ops += 2; }
      else if (style === 'points') { prism(ctx, x + rng.range(-10, 10), y - 6, rng.range(18, 34), rng.range(6, 10), rng.range(-0.25, 0.25), pal.accent, pal.glow); ops++; }
      else if (style === 'flat') {
        /* a riveted brass keel plate under each column, following the smoothed keel (never a step) */
        var nb = cols[i + 1] ? cols[i + 1].bottom - oy : y, pb = cols[i - 1] ? cols[i - 1].bottom - oy : y, yl = (pb + y) / 2 - 6, yr = (y + nb) / 2 - 6;
        poly(ctx, [[x - TILE / 2, yl - 3], [x + TILE / 2, yr - 3], [x + TILE / 2, yr + 3], [x - TILE / 2, yl + 3]], C(shade(pal.accent, 0.62)), null);
        poly(ctx, [[x - TILE / 2, yl - 3], [x + TILE / 2, yr - 3], [x + TILE / 2, yr - 1.5], [x - TILE / 2, yl - 1.5]], C(mix(pal.accent, WHITE, 0.35)), null);
        blob(ctx, x, (yl + yr) / 2, 1.6, C(mix(pal.accent, WHITE, 0.5))); ops += 3;
      }
      else { poly(ctx, [[x - 6, y - 10], [x + 6, y - 10], [x + rng.range(-3, 3), y + rng.range(14, 30)]], C(pal.strata[2]), C(mix(pal.strata[2], WHITE, 0.3), 0.6), 1); ops++; }
    }
    return ops;
  }

  /* ------------------------------------------------------------ hangers --*/
  /**
   * One hanger at (x, y), hanging len px. Static kinds are drawn here; the animated part of a waterfall, propeller or a
   * glow is a separate texture (drawWaterColumn / drawPropeller / drawGlow) that Aloft.js moves.
   * @returns {number} draw operations (a kind that draws nothing returns 0: the contact sheet refuses it)
   */
  function drawHanger(ctx, kind, x, y, len, pal, rng) {
    var ops = 0, i, pts;
    var rootC = shade(mix(pal.strata[1], [90, 64, 40], 0.5), 0.8), leafC = mix(pal.accent || [120, 180, 110], [70, 130, 60], 0.55);
    switch (kind) {
      case 'root-tangle':
        for (i = 0; i < 4; i++) { pts = strand(rng, x + rng.range(-8, 8), y, len * rng.range(0.55, 1), 6, 7); taperLine(ctx, pts, 3.2, 0.6, C(shade(rootC, rng.range(0.8, 1.1)))); ops++; }
        for (i = 0; i < 5; i++) { pts = strand(rng, x + rng.range(-10, 10), y + rng.range(4, len * 0.5), rng.range(6, 14), 4, 3); taperLine(ctx, pts, 1.2, 0.4, C(rootC, 0.8)); ops++; }
        break;
      case 'root-tap':
        pts = strand(rng, x, y, len * 1.1, 3, 8); taperLine(ctx, pts, 6, 0.8, C(rootC)); taperLine(ctx, pts, 2, 0.4, C(mix(rootC, WHITE, 0.25), 0.7)); ops += 2;
        for (i = 0; i < 2; i++) { var a = pts[2 + i * 2]; taperLine(ctx, strand(rng, a[0], a[1], len * 0.35, 5, 4), 1.8, 0.4, C(rootC)); ops++; }
        break;
      case 'vine-ivy':
      case 'vine-flower':
        pts = strand(rng, x, y, len * 1.2, 5, 10); taperLine(ctx, pts, 1.8, 0.8, C(shade(leafC, 0.6))); ops++;
        for (i = 1; i < pts.length; i++) {
          var side = i % 2 ? 1 : -1, lx = pts[i][0] + side * 4, ly = pts[i][1];
          ctx.fillStyle = C(mix(leafC, i % 3 ? WHITE : BLACK, 0.15));
          ctx.beginPath(); ctx.ellipse(lx, ly, 4.5, 3, side * 0.6, 0, TAU); ctx.fill(); ops++;
          if (kind === 'vine-flower' && i % 3 === 1) { for (var pe = 0; pe < 5; pe++) { var pa = pe * TAU / 5; blob(ctx, lx + Math.cos(pa) * 2.4, ly + Math.sin(pa) * 2.4, 1.7, 'rgb(246,190,214)'); } blob(ctx, lx, ly, 1.3, 'rgb(255,230,120)'); ops += 6; }
        }
        break;
      case 'moss-beard':
        for (i = 0; i < 16; i++) { var mx = x + rng.range(-12, 12), ml = len * 0.6 * (1 - Math.abs(mx - x) / 14) * rng.range(0.5, 1); taperLine(ctx, strand(rng, mx, y, ml, 2, 4), 1.6, 0.5, C(mix([120, 140, 100], leafC, 0.4), rng.range(0.6, 0.95))); ops++; }
        break;
      case 'waterfall':
        /* the white foam where the water leaves the lip; the column itself is an animated sprite */
        for (i = 0; i < 9; i++) { blob(ctx, x + rng.range(-9, 9), y + rng.range(-3, 5), rng.range(2, 5), 'rgba(240,250,255,0.85)'); ops++; }
        break;
      case 'dripline':
        for (i = 0; i < 5; i++) { var dx = x + rng.range(-14, 14), dl = rng.range(len * 0.3, len * 0.8); ctx.strokeStyle = 'rgba(170,215,240,0.55)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(dx, y); ctx.lineTo(dx, y + dl); ctx.stroke(); blob(ctx, dx, y + dl + 3, 1.6, 'rgba(200,235,255,0.85)'); ops += 2; }
        break;
      case 'chain':
        var links = Math.max(3, Math.floor(len / 9));
        for (i = 0; i < links; i++) {
          var cy = y + i * 9;
          ctx.lineWidth = 2.2; ctx.strokeStyle = 'rgb(60,58,62)';
          if (i % 2 === 0) { ctx.beginPath(); ctx.ellipse(x, cy + 4, 3.2, 5.5, 0, 0, TAU); ctx.stroke(); ctx.strokeStyle = 'rgba(190,190,200,0.7)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.ellipse(x - 0.8, cy + 3.2, 2.2, 4.4, 0, Math.PI, TAU * 0.95); ctx.stroke(); }
          else { ctx.fillStyle = 'rgb(84,82,88)'; ctx.fillRect(x - 1.2, cy, 2.4, 10); }
          ops++;
        }
        ctx.strokeStyle = 'rgb(70,68,72)'; ctx.lineWidth = 2.4; ctx.beginPath(); ctx.arc(x + 3, y + links * 9 + 3, 4, Math.PI * 0.9, Math.PI * 2.4); ctx.stroke(); ops++;
        break;
      case 'broken-arch':
        for (i = 0; i < 6; i++) {
          var t0 = Math.PI * (0.05 + i * 0.12), t1 = t0 + Math.PI * 0.11, R0 = 30, R1 = 42;
          var A = [x + Math.cos(t0) * R0, y + Math.sin(t0) * R0], B = [x + Math.cos(t0) * R1, y + Math.sin(t0) * R1], Cc = [x + Math.cos(t1) * R1, y + Math.sin(t1) * R1], Dd = [x + Math.cos(t1) * R0, y + Math.sin(t1) * R0];
          poly(ctx, [A, B, Cc, Dd], C(mix(pal.strata[0], WHITE, 0.1 + (i % 2) * 0.08)), C(shade(pal.strata[2], 0.7)), 1); ops++;
        }
        break;
      case 'hanging-block':
        ctx.strokeStyle = 'rgb(66,64,68)'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(x - 8, y); ctx.lineTo(x - 10, y + 14); ctx.moveTo(x + 8, y); ctx.lineTo(x + 10, y + 14); ctx.stroke();
        poly(ctx, [[x - 14, y + 14], [x + 14, y + 14], [x + 14, y + 34], [x + 4, y + 38], [x - 14, y + 34]], C(mix(pal.strata[0], WHITE, 0.12)), C(shade(pal.strata[2], 0.6)), 1.2);
        ctx.fillStyle = C(mix(pal.strata[0], WHITE, 0.35)); ctx.fillRect(x - 14, y + 14, 28, 2);
        ctx.strokeStyle = C(pal.crack); ctx.beginPath(); ctx.moveTo(x + 6, y + 15); ctx.lineTo(x + 2, y + 25); ctx.lineTo(x + 7, y + 33); ctx.stroke(); ops += 4;
        break;
      case 'banner-rag':
        ctx.fillStyle = 'rgb(80,60,40)'; ctx.fillRect(x - 13, y + 2, 26, 3);
        pts = [[x - 11, y + 5], [x + 11, y + 5], [x + 11, y + len * 0.8], [x + 6, y + len * 0.7], [x + 2, y + len * 0.9], [x - 4, y + len * 0.72], [x - 11, y + len * 0.86]];
        poly(ctx, pts, 'rgb(142,52,46)', 'rgb(92,30,28)', 1);
        ctx.fillStyle = 'rgb(214,176,92)'; ctx.fillRect(x - 11, y + 9, 22, 3); ctx.beginPath(); ctx.moveTo(x, y + 16); ctx.lineTo(x + 5, y + 24); ctx.lineTo(x, y + 32); ctx.lineTo(x - 5, y + 24); ctx.fill(); ops += 5;
        break;
      case 'pillar-stub':
        var ph = Math.max(26, len * 0.8);
        ctx.fillStyle = C(mix(pal.strata[0], WHITE, 0.2)); ctx.fillRect(x - 10, y, 20, ph);
        for (i = -7; i <= 7; i += 4.6) { ctx.fillStyle = C(shade(pal.strata[0], 0.75)); ctx.fillRect(x + i, y + 4, 1.6, ph - 8); }
        ctx.fillStyle = C(mix(pal.strata[0], WHITE, 0.35)); ctx.fillRect(x - 13, y, 26, 5);
        poly(ctx, [[x - 10, y + ph], [x - 4, y + ph + 7], [x + 1, y + ph + 2], [x + 6, y + ph + 9], [x + 10, y + ph]], C(mix(pal.strata[0], WHITE, 0.2)), null); ops += 5;
        break;
      case 'crystal-cluster':
        for (i = 0; i < 5; i++) { prism(ctx, x + rng.range(-12, 12), y - 2, len * rng.range(0.4, 0.9), rng.range(5, 9), rng.range(-0.5, 0.5), mix(pal.accent, [150, 120, 255], rng.range(0, 0.6)), pal.glow); ops++; }
        break;
      case 'crystal-spike':
        prism(ctx, x, y - 2, len * 1.4, 11, rng.range(-0.12, 0.12), pal.accent, pal.glow); ops++;
        break;
      case 'glow-vein':
      case 'static-vein':
        pts = [[x, y]]; var vx = x, vy = y;
        for (i = 0; i < 7; i++) { vx += rng.range(-9, 9); vy += kind === 'static-vein' ? rng.range(3, 9) : rng.range(-4, 6); pts.push([vx + (kind === 'static-vein' ? (i % 2 ? 6 : -6) : 0), vy]); }
        var vc = pal.glow || pal.accent;
        ctx.globalCompositeOperation = 'lighter';
        taperLine(ctx, pts, 5, 2, C(vc, 0.18)); taperLine(ctx, pts, 2, 1, C(vc, 0.9));
        ctx.globalCompositeOperation = 'source-over'; ops += 2;
        break;
      case 'geode-shard':
        ctx.fillStyle = C(shade(pal.strata[2], 0.9)); ctx.beginPath(); ctx.ellipse(x, y + 12, 16, 12, 0, 0, Math.PI); ctx.fill();
        ctx.fillStyle = C(shade(pal.strata[4], 0.9)); ctx.beginPath(); ctx.ellipse(x, y + 12, 12, 8, 0, 0, Math.PI); ctx.fill();
        for (i = -9; i <= 9; i += 3) { prism(ctx, x + i, y + 10, rng.range(5, 9), 3, 0, pal.accent, null); }
        ops += 9;
        break;
      case 'brass-strut':
        ctx.save(); ctx.translate(x, y); ctx.rotate(rng.range(-0.7, -0.35));
        ctx.fillStyle = C(shade(pal.accent, 0.55)); ctx.fillRect(-2, -3, len, 8);
        ctx.fillStyle = C(pal.accent); ctx.fillRect(-2, -4, len, 6);
        ctx.fillStyle = C(mix(pal.accent, WHITE, 0.5)); ctx.fillRect(-2, -4, len, 1.5);
        for (i = 4; i < len; i += 10) { blob(ctx, i, -1, 1.4, C(shade(pal.accent, 0.35))); }
        ctx.restore(); ops += 4;
        break;
      case 'pipe-run':
        var pc = mix(pal.accent, [120, 80, 50], 0.35), pl = len * 1.3;
        ctx.fillStyle = C(shade(pc, 0.6)); ctx.fillRect(x - pl / 2, y + 1, pl, 9);
        ctx.fillStyle = C(pc); ctx.fillRect(x - pl / 2, y, pl, 7); ctx.fillStyle = C(mix(pc, WHITE, 0.45)); ctx.fillRect(x - pl / 2, y + 1, pl, 2);
        ctx.fillStyle = C(pc); ctx.fillRect(x + pl / 2 - 7, y, 7, 26); ctx.fillStyle = C(mix(pc, WHITE, 0.4)); ctx.fillRect(x + pl / 2 - 6, y, 2, 26);
        for (i = -1; i <= 1; i += 2) { ctx.fillStyle = C(shade(pc, 0.45)); ctx.fillRect(x + i * pl * 0.25 - 2, y - 2, 4, 11); }
        ctx.strokeStyle = 'rgb(150,40,30)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y - 6, 5, 0, TAU); ctx.moveTo(x - 5, y - 6); ctx.lineTo(x + 5, y - 6); ctx.moveTo(x, y - 11); ctx.lineTo(x, y - 1); ctx.stroke(); ops += 9;
        break;
      case 'propeller':
        ctx.fillStyle = C(shade(pal.accent, 0.5)); ctx.fillRect(x - 2, y, 4, 16); ops++;
        ops += drawPropellerBlades(ctx, x, y + 18, 20, pal.accent, 0);
        break;
      case 'gear-wheel':
        var teeth = 10, R = 13;
        ctx.fillStyle = C(shade(pal.accent, 0.7)); ctx.beginPath();
        for (i = 0; i < teeth * 2; i++) { var ga = i * Math.PI / teeth, rr = i % 2 ? R : R + 4; ctx.lineTo(x + Math.cos(ga) * rr, y + Math.sin(ga) * rr); }
        ctx.closePath(); ctx.fill();
        blob(ctx, x, y, R - 3, C(pal.accent)); blob(ctx, x, y, 4, C(shade(pal.accent, 0.4)));
        for (i = 0; i < 4; i++) { var sa = i * Math.PI / 2 + 0.4; blob(ctx, x + Math.cos(sa) * 7, y + Math.sin(sa) * 7, 2, C(shade(pal.accent, 0.5))); }
        ops += 7;
        break;
      case 'steam-vent':
        ctx.fillStyle = 'rgb(70,64,60)'; ctx.fillRect(x - 5, y, 10, 14); ctx.fillStyle = C(pal.accent); ctx.fillRect(x - 7, y + 12, 14, 4);
        for (i = 0; i < 5; i++) { blob(ctx, x + rng.range(-6, 6) + i * 2, y + 20 + i * 7, 4 + i * 1.6, 'rgba(235,235,240,' + (0.55 - i * 0.09) + ')'); }
        ops += 7;
        break;
      case 'lantern':
        ctx.strokeStyle = 'rgb(60,56,52)'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + len * 0.5); ctx.stroke();
        var ly2 = y + len * 0.5;
        ctx.globalCompositeOperation = 'lighter'; blob(ctx, x, ly2 + 9, 14, 'rgba(255,190,90,0.25)'); ctx.globalCompositeOperation = 'source-over';
        ctx.fillStyle = 'rgb(60,50,40)'; ctx.fillRect(x - 6, ly2, 12, 3); ctx.fillRect(x - 6, ly2 + 15, 12, 3);
        ctx.fillStyle = 'rgb(255,214,130)'; ctx.fillRect(x - 5, ly2 + 3, 10, 12);
        ctx.fillStyle = 'rgb(60,50,40)'; ctx.fillRect(x - 1, ly2 + 3, 2, 12); ops += 6;
        break;
      case 'rock-spike':
        poly(ctx, [[x - 9, y - 4], [x + 9, y - 4], [x + rng.range(-2, 2), y + len * 1.3]], C(pal.strata[2]), null);
        poly(ctx, [[x - 9, y - 4], [x - 1, y - 4], [x + rng.range(-2, 2), y + len * 1.3]], C(mix(pal.strata[2], WHITE, 0.18)), null); ops += 2;
        break;
      case 'storm-rod':
        ctx.fillStyle = 'rgb(70,74,82)'; ctx.fillRect(x - 1.5, y, 3, len);
        for (i = 0; i < 5; i++) { ctx.strokeStyle = 'rgb(176,120,70)'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.ellipse(x, y + 6 + i * 4, 4, 1.6, 0, 0, TAU); ctx.stroke(); }
        ctx.globalCompositeOperation = 'lighter'; blob(ctx, x, y + len, 6, C(pal.glow || [200, 230, 255], 0.5)); blob(ctx, x, y + len, 2.4, 'rgb(240,250,255)'); ctx.globalCompositeOperation = 'source-over';
        ops += 8;
        break;
      case 'hanging-shard':
        ctx.strokeStyle = C(pal.strata[3]); ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 2, y + 8); ctx.stroke();
        poly(ctx, [[x - 10, y + 8], [x + 14, y + 6], [x + 9, y + len * 0.9], [x - 4, y + len * 1.1]], C(pal.strata[1]), C(mix(pal.strata[1], WHITE, 0.35), 0.7), 1); ops += 2;
        break;
      default:
        return 0;
    }
    return ops;
  }

  /** a falling-water texture w x h, tileable vertically (Aloft.js scrolls it) */
  function drawWaterColumn(ctx, w, h, rng) {
    var g = ctx.createLinearGradient(0, 0, w, 0);
    g.addColorStop(0, 'rgba(160,210,240,0)'); g.addColorStop(0.2, 'rgba(180,225,250,0.55)'); g.addColorStop(0.5, 'rgba(225,245,255,0.78)'); g.addColorStop(0.8, 'rgba(180,225,250,0.55)'); g.addColorStop(1, 'rgba(160,210,240,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    for (var i = 0; i < w * h / 70; i++) {
      var x = rng.range(2, w - 2), y = rng.range(0, h), l = rng.range(8, 26);
      ctx.strokeStyle = 'rgba(255,255,255,' + rng.range(0.25, 0.7).toFixed(2) + ')'; ctx.lineWidth = rng.range(0.8, 1.8);
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + l); ctx.stroke();
      if (y + l > h) { ctx.beginPath(); ctx.moveTo(x, y - h); ctx.lineTo(x, y + l - h); ctx.stroke(); }
    }
    return 1;
  }
  /** propeller blades at angle a (Aloft.js rotates a sprite of this) */
  function drawPropellerBlades(ctx, x, y, r, col, a) {
    for (var i = 0; i < 3; i++) {
      var t = a + i * TAU / 3;
      ctx.save(); ctx.translate(x, y); ctx.rotate(t);
      ctx.fillStyle = C(mix(col, [120, 90, 60], 0.3)); ctx.beginPath(); ctx.ellipse(r * 0.5, 0, r * 0.5, r * 0.16, 0.18, 0, TAU); ctx.fill();
      ctx.fillStyle = C(mix(col, WHITE, 0.35)); ctx.beginPath(); ctx.ellipse(r * 0.5, -1, r * 0.42, r * 0.06, 0.18, 0, TAU); ctx.fill();
      ctx.restore();
    }
    blob(ctx, x, y, 4, C(shade(col, 0.45))); blob(ctx, x - 1, y - 1, 1.6, C(mix(col, WHITE, 0.6)));
    return 5;
  }
  /** a soft round glow (crystal, lantern, rod): Aloft.js pulses its alpha */
  function drawGlow(ctx, w, h, col) {
    var g = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w / 2);
    g.addColorStop(0, C(col, 0.8)); g.addColorStop(0.35, C(col, 0.3)); g.addColorStop(1, C(col, 0));
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    return 1;
  }

  /* -------------------------------------------------------------- clouds --*/
  /**
   * A TILEABLE field of cloud tops (w x h), seen from above: each cloud is a cluster of puffs lit from the upper left.
   * @param {string} kind 'cumulus'|'stratus'|'puff'|'anvil'
   * @param {number} cover 0..100
   * @param {number[]} lit  colour of the lit tops @param {number[]} shadowC  colour of the shaded sides
   */
  function drawCloudField(ctx, kind, w, h, rng, cover, lit, shadowC) {
    /* at least one cluster whenever there is any cover (MEASURED 2026-10-27: a 122 x 118 cell rounded to ZERO clusters and
     * the field drew nothing; the plate builder caught it) */
    var ops = 0, clusters = cover > 0 ? Math.max(1, Math.round((kind === 'puff' ? 26 : (kind === 'stratus' ? 9 : 12)) * (0.25 + cover / 100) * (w * h) / (768 * 512))) : 0;
    function wrapPuff(x, y, r, sx, sy, col) {
      for (var ox = -w; ox <= w; ox += w) for (var oy = -h; oy <= h; oy += h) {
        var cx = x + ox, cy = y + oy;
        if (cx + r * sx < 0 || cx - r * sx > w || cy + r * sy < 0 || cy - r * sy > h) continue;
        ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(cx, cy, r * sx, r * sy, 0, 0, TAU); ctx.fill(); ops++;
      }
    }
    for (var c = 0; c < clusters; c++) {
      var cx = rng.range(0, w), cy = rng.range(0, h);
      var n = kind === 'puff' ? rng.int(3, 6) : (kind === 'stratus' ? rng.int(6, 10) : rng.int(7, 13));
      var spread = kind === 'stratus' ? 90 : (kind === 'puff' ? 22 : 46), sx = kind === 'stratus' ? 2.6 : 1, sy = kind === 'stratus' ? 0.55 : 0.85;
      var puffs = [];
      for (var p = 0; p < n; p++) puffs.push([cx + rng.range(-spread, spread) * sx * 0.6, cy + rng.range(-spread, spread) * 0.45, rng.range(kind === 'puff' ? 9 : 18, kind === 'puff' ? 18 : 38)]);
      /* shaded underside first, offset down-right */
      for (p = 0; p < n; p++) wrapPuff(puffs[p][0] + 5, puffs[p][1] + 7, puffs[p][2], sx, sy, C(shadowC, kind === 'anvil' ? 0.95 : 0.8));
      for (p = 0; p < n; p++) wrapPuff(puffs[p][0], puffs[p][1], puffs[p][2] * 0.96, sx, sy, C(mix(shadowC, lit, 0.72)));
      for (p = 0; p < n; p++) wrapPuff(puffs[p][0] - 4, puffs[p][1] - 5, puffs[p][2] * 0.72, sx, sy, C(lit, kind === 'anvil' ? 0.55 : 0.95));
      if (kind === 'anvil') for (p = 0; p < n; p++) wrapPuff(puffs[p][0] - 6, puffs[p][1] - 8, puffs[p][2] * 0.3, sx, sy, 'rgba(220,235,255,0.35)');
    }
    return ops;
  }

  /** a wisp of cloud passing between the islands, w x h, soft-edged */
  function drawWisp(ctx, kind, w, h, rng) {
    var ops = 0, n = kind === 'scrap' ? 6 : (kind === 'long' ? 22 : 14);
    for (var i = 0; i < n; i++) {
      var t = i / (n - 1), x, y, r;
      if (kind === 'ribbon') { x = w * (0.08 + 0.84 * t); y = h * (0.5 + Math.sin(t * Math.PI * 2) * 0.22); r = h * 0.18 * (0.5 + Math.sin(t * Math.PI) * 0.6); }
      else if (kind === 'curl') { var a = t * Math.PI * 1.6; x = w * 0.5 + Math.cos(a) * w * 0.32 * (1 - t * 0.5); y = h * 0.5 + Math.sin(a) * h * 0.3 * (1 - t * 0.5); r = h * 0.14 * (1 - t * 0.5); }
      else if (kind === 'scrap') { x = w * rng.range(0.3, 0.7); y = h * rng.range(0.35, 0.65); r = h * rng.range(0.12, 0.24); }
      else { x = w * (0.04 + 0.92 * t); y = h * 0.5 + rng.range(-2, 2); r = h * 0.1 * (0.4 + Math.sin(t * Math.PI)); }
      var g = ctx.createRadialGradient(x, y, 0, x, y, r * 2);
      g.addColorStop(0, 'rgba(255,255,255,0.42)'); g.addColorStop(0.5, 'rgba(250,252,255,0.18)'); g.addColorStop(1, 'rgba(250,252,255,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(x, y, r * 2 * (kind === 'long' ? 2.2 : 1.3), r * 2, 0, 0, TAU); ctx.fill(); ops++;
    }
    return ops;
  }

  /** a distant island, w x h, in haze colour col */
  function drawDistant(ctx, kind, w, h, rng, col) {
    var ops = 0, cx = w / 2, gy = h * 0.42, rw = w * 0.36;
    var dark = shade(col, 0.82), lite = mix(col, WHITE, 0.2);
    /* the underside cone */
    poly(ctx, [[cx - rw, gy], [cx + rw, gy], [cx + rw * 0.35, gy + h * 0.28], [cx + rng.range(-6, 6), gy + h * (kind === 'distant-isle-spire' ? 0.56 : 0.46)], [cx - rw * 0.4, gy + h * 0.3]], C(dark), null); ops++;
    /* the top */
    ctx.fillStyle = C(lite); ctx.beginPath(); ctx.ellipse(cx, gy, rw, h * 0.07, 0, 0, TAU); ctx.fill(); ops++;
    if (kind === 'distant-isle-round') { for (var i = 0; i < 5; i++) { blob(ctx, cx + rng.range(-rw * 0.7, rw * 0.7), gy - rng.range(4, 12), rng.range(5, 9), C(mix(col, [90, 130, 100], 0.25))); ops++; } }
    else if (kind === 'distant-isle-spire') { poly(ctx, [[cx - 8, gy], [cx + 8, gy], [cx + 2, gy - h * 0.34], [cx - 1, gy - h * 0.4]], C(lite), null); ops++; }
    else { ctx.fillStyle = C(lite); ctx.fillRect(cx - 14, gy - h * 0.26, 10, h * 0.26); ctx.fillRect(cx + 4, gy - h * 0.18, 9, h * 0.18); ctx.fillRect(cx - 14, gy - h * 0.29, 27, 3); ctx.fillStyle = C(dark); ctx.fillRect(cx - 11, gy - h * 0.2, 3, 5); ops += 4; }
    return ops;
  }

  /** a mote (w x h cell, drawn centred) */
  function drawMote(ctx, kind, w, h, rng) {
    var cx = w / 2, cy = h / 2;
    switch (kind) {
      case 'petal': ctx.fillStyle = 'rgb(250,196,214)'; ctx.beginPath(); ctx.ellipse(cx, cy, w * 0.32, h * 0.2, 0.5, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgb(255,226,236)'; ctx.beginPath(); ctx.ellipse(cx - 1, cy - 1, w * 0.16, h * 0.08, 0.5, 0, TAU); ctx.fill(); return 2;
      case 'leaf': ctx.fillStyle = 'rgb(122,170,84)'; ctx.beginPath(); ctx.ellipse(cx, cy, w * 0.36, h * 0.17, -0.6, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgb(82,120,56)'; ctx.lineWidth = 0.8; ctx.beginPath(); ctx.moveTo(cx - w * 0.28, cy + h * 0.17); ctx.lineTo(cx + w * 0.28, cy - h * 0.17); ctx.stroke(); return 2;
      case 'dust': blob(ctx, cx, cy, w * 0.22, 'rgba(226,214,190,0.55)'); blob(ctx, cx, cy, w * 0.1, 'rgba(246,238,220,0.8)'); return 2;
      case 'sparkle': ctx.fillStyle = 'rgba(200,250,255,0.95)'; ctx.beginPath(); ctx.moveTo(cx, cy - h * 0.45); ctx.lineTo(cx + w * 0.08, cy); ctx.lineTo(cx, cy + h * 0.45); ctx.lineTo(cx - w * 0.08, cy); ctx.fill(); ctx.beginPath(); ctx.moveTo(cx - w * 0.45, cy); ctx.lineTo(cx, cy - h * 0.08); ctx.lineTo(cx + w * 0.45, cy); ctx.lineTo(cx, cy + h * 0.08); ctx.fill(); return 2;
      case 'soot': for (var i = 0; i < 4; i++) blob(ctx, cx + (rng ? rng.range(-2, 2) : i - 2), cy + (rng ? rng.range(-2, 2) : 0), w * 0.16, 'rgba(70,64,62,0.55)'); return 4;
      case 'rain': ctx.strokeStyle = 'rgba(200,220,245,0.7)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(cx + w * 0.2, cy - h * 0.45); ctx.lineTo(cx - w * 0.2, cy + h * 0.45); ctx.stroke(); return 1;
      default: return 0;
    }
  }
  /** a wind streak: a thin tapered line, w x h */
  function drawStreak(ctx, w, h) {
    var g = ctx.createLinearGradient(0, 0, w, 0);
    g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(0.6, 'rgba(255,255,255,0.55)'); g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(w / 2, h / 2, w / 2, h * 0.22, 0, 0, TAU); ctx.fill();
    return 1;
  }

  /* ----------------------------------------------------------------- sky --*/
  /** the sky gradient (top, mid, low), w x h */
  function drawSky(ctx, w, h, sky) {
    var g = ctx.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, C(sky.top)); g.addColorStop(0.55, C(sky.mid)); g.addColorStop(1, C(sky.low));
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    return 1;
  }
  /** stars on transparent, w x h */
  function drawStars(ctx, w, h, rng) {
    var n = Math.floor(w * h / 1400);
    for (var i = 0; i < n; i++) { var r = rng.next() < 0.08 ? 1.6 : 0.8; blob(ctx, rng.range(0, w), rng.range(0, h), r, 'rgba(255,255,240,' + rng.range(0.4, 1).toFixed(2) + ')'); }
    return n;
  }
  /**
   * An island's shadow on the cloud sea: its ground cells and underside as one soft dark mass.
   * @param {Array<[number,number]>} cells  ground cells (tile coords) @param {object} prof  the profile
   */
  function drawShadow(ctx, cells, prof, ox, oy, blurPx) {
    var hasFilter = typeof ctx.filter === 'string';
    if (hasFilter) ctx.filter = 'blur(' + blurPx + 'px)';
    ctx.fillStyle = 'rgba(20,28,52,1)';
    for (var i = 0; i < cells.length; i++) ctx.fillRect(cells[i][0] * TILE - ox, cells[i][1] * TILE - oy, TILE, TILE);
    for (var c = 0; c < prof.cols.length; c++) { var col = prof.cols[c]; ctx.fillRect(col.x * TILE - ox + 6, col.top - oy, TILE - 12, col.bottom - col.top); }
    if (hasFilter) ctx.filter = 'none';
    return cells.length + prof.cols.length;
  }

  /* ------------------------------------------------------- contact sheet --*/
  /**
   * Draw ANY registry id standalone into a w x h cell (the contact sheet and the store plates use this). The underside
   * kinds draw a sample island underside with that dressing's body / lip / keel; everything else calls its own branch.
   * @returns {number} draw operations (0 = the id drew nothing: a defect)
   */
  function drawEntity(ctx, id, w, h, seed, sample) {
    var K = core(), rng = new K.Rng(seed || 1), ops = 0;
    var byBody = { earth: 'garden', masonry: 'ruins', geode: 'crystal', plated: 'steam', jagged: 'storm' };
    var byLip = { turf: 'garden', stone: 'ruins', crystal: 'crystal', brass: 'steam', slate: 'storm' };
    var byBottom = { round: 'garden', stepped: 'ruins', points: 'crystal', flat: 'steam', spikes: 'storm' };
    var m = /^(body|lip|bottom)-(\w+)$/.exec(id);
    if (m) {
      var dress = (m[1] === 'body' ? byBody : (m[1] === 'lip' ? byLip : byBottom))[m[2]];
      if (!dress) return 0;
      var pal = K.derivePalette(dress, sample || null);
      /* a body is shown as a WIDE island at half scale: a two-column sample read as a pot or a barrel (fresh review) */
      var s = m[1] === 'body' ? 0.5 : 1, w2 = w / s, h2 = h / s;
      var cols = Math.max(2, Math.floor(w2 / TILE) - 1), isl = { x0: 0, x1: cols - 1, y0: 0, y1: 1, cols: {} };
      for (var x = 0; x < cols; x++) isl.cols[x] = { bottom: 1, edges: [1], gap: 99 };
      var prof = K.profile(isl, { depth: 3, bottom: K.DRESSINGS[dress].bottom, tile: TILE }, rng);
      var ox = -(w2 - cols * TILE) / 2, oy = m[1] === 'lip' ? TILE * 1.2 : TILE * 0.9;
      ctx.save();
      if (s !== 1) { ctx.scale(s, s); ctx.fillStyle = C(mix(pal.lip, BLACK, 0.1)); ctx.fillRect(-ox, TILE * 0.9 - TILE * 0.9 + 0, cols * TILE, TILE * 0.62); }
      if (m[1] === 'lip') { ctx.translate(w / 2, h / 2); ctx.scale(2.2, 2.2); ctx.translate(-w / 2, -h / 2 + 10); }
      /* a keel is shown as a close-up OF THE KEEL: drawn whole it was the same picture as its body, shifted (looked at on the
       * 59-kinds plate, 2026-10-27: a hash called them distinct, an eye did not) */
      if (m[1] === 'bottom') { ctx.translate(w / 2, h * 0.58); ctx.scale(1.9, 1.9); ctx.translate(-w / 2, -(prof.maxBottom - oy) + TILE * 0.15); }
      ops = drawUnderside(ctx, prof, pal, dress, rng, ox, oy, null);
      ctx.restore();
      return ops;
    }
    var e = null;
    for (var i = 0; i < K.ENTITIES.length; i++) if (K.ENTITIES[i].id === id) e = K.ENTITIES[i];
    if (!e) return 0;
    var palH = K.derivePalette(hangerDressing(id), sample || null);
    if (e.kind === 'hanger') {
      ctx.fillStyle = C(palH.strata[1]); ctx.fillRect(w * 0.15, 0, w * 0.7, h * 0.16);
      if (id === 'waterfall') { ctx.save(); ctx.translate(w / 2 - 12, h * 0.16); drawWaterColumn(ctx, 24, h * 0.84, rng); ctx.restore(); ops++; }
      if (id === 'propeller') return drawHanger(ctx, id, w / 2, h * 0.16, h * 0.6, palH, rng) + drawPropellerBlades(ctx, w / 2, h * 0.16 + 18, 26, palH.accent, 0.6);
      return ops + drawHanger(ctx, id, w / 2, h * 0.16, h * 0.55, palH, rng);
    }
    if (e.kind === 'cloud') { var kind = id.slice(6); ctx.fillStyle = 'rgb(118,150,196)'; ctx.fillRect(0, 0, w, h); return drawCloudField(ctx, kind, w, h, rng, 80, kind === 'anvil' ? [150, 162, 186] : [252, 252, 255], kind === 'anvil' ? [52, 58, 78] : [168, 186, 214]); }
    if (e.kind === 'wisp') { ctx.fillStyle = 'rgb(96,132,184)'; ctx.fillRect(0, 0, w, h); return drawWisp(ctx, id.slice(5), w, h, rng); }
    if (e.kind === 'distant') { ctx.fillStyle = 'rgb(150,182,220)'; ctx.fillRect(0, 0, w, h); return drawDistant(ctx, id, w, h, rng, [118, 140, 178]); }
    if (e.kind === 'mote') {
      /* three of them, enlarged: one dot in an empty square read as an inflated count (fresh review) */
      ctx.fillStyle = 'rgb(80,110,150)'; ctx.fillRect(0, 0, w, h); var o = 0;
      for (var q = 0; q < 3; q++) { ctx.save(); ctx.translate(w * (0.28 + q * 0.22), h * (0.35 + (q % 2) * 0.3)); ctx.rotate(q * 0.9); ctx.scale(2.2, 2.2); ctx.translate(-16, -16); o += drawMote(ctx, id.slice(5), 32, 32, rng); ctx.restore(); }
      return o;
    }
    if (e.kind === 'streak') { ctx.fillStyle = 'rgb(80,110,150)'; ctx.fillRect(0, 0, w, h); ctx.save(); ctx.translate(w * 0.1, h / 2 - 4); var s = drawStreak(ctx, w * 0.8, 8); ctx.restore(); return s; }
    return 0;
  }
  function hangerDressing(id) {
    var D = core().DRESSINGS;
    for (var k in D) if (D[k].hangers[id]) return k;
    return 'garden';
  }

  globalThis.CSAF.AloftPaint = {
    VERSION: '1.0.0', setTile: setTile,
    drawUnderside: drawUnderside, drawHanger: drawHanger, drawWaterColumn: drawWaterColumn, drawPropellerBlades: drawPropellerBlades,
    drawGlow: drawGlow, drawCloudField: drawCloudField, drawWisp: drawWisp, drawDistant: drawDistant, drawMote: drawMote,
    drawStreak: drawStreak, drawSky: drawSky, drawStars: drawStars, drawShadow: drawShadow, drawEntity: drawEntity, hangerDressing: hangerDressing
  };
})();
