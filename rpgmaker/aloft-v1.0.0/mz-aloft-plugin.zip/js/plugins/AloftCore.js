//=============================================================================
// AloftCore.js — Aloft [1/3]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Aloft [1/3] — the rules: void and ground, islands, undersides, palettes. No settings here; see Aloft.js. v1.0.0
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help AloftCore.js
 *
 * Part 1 of 3. Load all three: AloftCore.js, AloftPaint.js and Aloft.js.
 * Any order works. This file touches nothing in RPG Maker; every setting
 * lives on Aloft.js.
 *
 * Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.
 */

'use strict';

if (typeof globalThis.CSAF === 'undefined') globalThis.CSAF = {};

(function () {
  var TILE = 48;

  /* ---------------------------------------------------------------- RNG --*/
  /** FNV-1a 32 bit over a string: the seed of a map is hash('aloft:' + mapId). */
  function hash(s) {
    var h = 0x811c9dc5;
    s = String(s);
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; }
    return h >>> 0;
  }

  /**
   * Seeded generator (mulberry32). Never Math.random (wing §6.2).
   * @param {number} seed
   */
  function Rng(seed) { this.s = (seed >>> 0) || 1; }
  Rng.prototype.next = function () {
    var t = (this.s = (this.s + 0x6d2b79f5) >>> 0);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  /** @returns {number} a float in [a, b) */
  Rng.prototype.range = function (a, b) { return a + (b - a) * this.next(); };
  /** @returns {number} an integer in [a, b] */
  Rng.prototype.int = function (a, b) { return a + Math.floor((b - a + 1) * this.next()); };
  /** @returns {*} one element of arr */
  Rng.prototype.pick = function (arr) { return arr[Math.floor(this.next() * arr.length) % arr.length]; };

  /* ------------------------------------------------------------- colour --*/
  /** '#rrggbb' -> [r,g,b], or null for anything malformed (wing §21c: never NaN channels). */
  function hex(c) {
    var m = /^#([0-9a-f]{6})$/i.exec(String(c));
    if (!m) return null;
    var n = parseInt(m[1], 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function clamp255(v) { return v < 0 ? 0 : (v > 255 ? 255 : Math.round(v)); }
  /** mix two [r,g,b] by t (0 = a, 1 = b) */
  function mix(a, b, t) { return [clamp255(a[0] + (b[0] - a[0]) * t), clamp255(a[1] + (b[1] - a[1]) * t), clamp255(a[2] + (b[2] - a[2]) * t)]; }
  /** scale brightness (k < 1 darker) */
  function shade(a, k) { return [clamp255(a[0] * k), clamp255(a[1] * k), clamp255(a[2] * k)]; }
  /** relative luminance 0..1 (sRGB, gamma-expanded: wing §25h) */
  function lum(a) {
    function ch(v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }
    return 0.2126 * ch(a[0]) + 0.7152 * ch(a[1]) + 0.0722 * ch(a[2]);
  }
  /** [r,g,b] (+ alpha) -> css */
  function css(a, alpha) {
    if (alpha === undefined || alpha >= 1) return 'rgb(' + a[0] + ',' + a[1] + ',' + a[2] + ')';
    return 'rgba(' + a[0] + ',' + a[1] + ',' + a[2] + ',' + (Math.round(alpha * 1000) / 1000) + ')';
  }
  /** rgb -> [h 0..360, s 0..1, l 0..1] */
  function hsl(a) {
    var r = a[0] / 255, g = a[1] / 255, b = a[2] / 255;
    var mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, h = 0, s = 0, d = mx - mn;
    if (d > 1e-6) {
      s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
      if (mx === r) h = ((g - b) / d + (g < b ? 6 : 0)); else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4;
      h *= 60;
    }
    return [h, s, l];
  }

  /* ----------------------------------------------------------- dressings --*/
  /**
   * The five dressings. A dressing decides the BODY of the underside (how rock is built and how it ends), the
   * HANGERS that dangle from it, the CLOUD FIELD below, the MOTE that drifts on the wind and the base palette that the
   * buyer's own edge tiles then tint. `tint` = how far the strata move toward the sampled ground colour.
   */
  var DRESSINGS = {
    garden: {
      name: 'Spirit Garden', body: 'earth', lip: 'turf', bottom: 'round', cloud: 'cumulus', mote: 'petal', mote2: 'leaf',
      rock: ['#6b4f3a', '#5a4231', '#4a372a', '#3b2d24', '#2c231d'], accent: '#9fd8a8', glow: null, tint: 0.28,
      hangers: { 'root-tangle': 4, 'root-tap': 3, 'vine-ivy': 4, 'vine-flower': 3, 'moss-beard': 3, 'waterfall': 1, 'dripline': 2 },
      sky: ['#5f9fd9', '#9cc8ec', '#d6ebf7'], deep: '#7fa9cf', distant: 'distant-isle-round'
    },
    ruins: {
      name: 'Sky Ruins', body: 'masonry', lip: 'stone', bottom: 'stepped', cloud: 'stratus', mote: 'dust', mote2: 'leaf',
      rock: ['#8a8173', '#766e62', '#625b52', '#4f4943', '#3c3834'], accent: '#c9b98f', glow: null, tint: 0.18,
      hangers: { 'chain': 4, 'broken-arch': 2, 'hanging-block': 3, 'banner-rag': 2, 'pillar-stub': 3, 'root-tap': 2 },
      sky: ['#6e8fb8', '#a8bdd6', '#e3dccb'], deep: '#8c9db3', distant: 'distant-isle-ruin'
    },
    crystal: {
      name: 'Crystal Spire', body: 'geode', lip: 'crystal', bottom: 'points', cloud: 'puff', mote: 'sparkle', mote2: 'sparkle',
      rock: ['#5b5578', '#4b4566', '#3d3855', '#302c45', '#242136'], accent: '#9ef0ff', glow: '#7fe6ff', tint: 0.16,
      hangers: { 'crystal-cluster': 4, 'crystal-spike': 4, 'glow-vein': 3, 'geode-shard': 3, 'moss-beard': 1 },
      sky: ['#4f63b0', '#8e9fe0', '#d9d6f5'], deep: '#7381c4', distant: 'distant-isle-spire'
    },
    steam: {
      name: 'Steam Isle', body: 'plated', lip: 'brass', bottom: 'flat', cloud: 'cumulus', mote: 'soot', mote2: 'dust',
      rock: ['#6f5a49', '#5d4b3d', '#4c3e33', '#3c3129', '#2d251f'], accent: '#d9a441', glow: '#ffcf73', tint: 0.22,
      hangers: { 'brass-strut': 4, 'pipe-run': 4, 'propeller': 1, 'gear-wheel': 2, 'steam-vent': 2, 'lantern': 2, 'chain': 1 },
      sky: ['#7d8fa6', '#b9c2c9', '#ead9bd'], deep: '#9aa3ab', distant: 'distant-isle-round'
    },
    storm: {
      name: 'Storm Reach', body: 'jagged', lip: 'slate', bottom: 'spikes', cloud: 'anvil', mote: 'rain', mote2: 'rain',
      rock: ['#4d5059', '#40434b', '#34363d', '#292b31', '#1f2025'], accent: '#b7d7ff', glow: '#cfe6ff', tint: 0.14,
      hangers: { 'rock-spike': 4, 'storm-rod': 2, 'static-vein': 3, 'hanging-shard': 3, 'chain': 1 },
      sky: ['#2e3a52', '#56637d', '#8d96a8'], deep: '#3f4a60', distant: 'distant-isle-spire'
    }
  };
  var DRESSING_ORDER = ['garden', 'ruins', 'crystal', 'steam', 'storm'];

  /**
   * THE ENTITY REGISTRY: every distinct thing Aloft draws, by id. Each id is drawn by its own branch in AloftPaint
   * (the contact-sheet probe draws every id and requires a distinct, non-empty picture for each: wing §25a).
   */
  var ENTITIES = [
    /* underside bodies, one per dressing */
    { id: 'body-earth', kind: 'body' }, { id: 'body-masonry', kind: 'body' }, { id: 'body-geode', kind: 'body' },
    { id: 'body-plated', kind: 'body' }, { id: 'body-jagged', kind: 'body' },
    /* the lip under the ground edge: cut from the buyer's own edge tile, finished per dressing */
    { id: 'lip-turf', kind: 'lip' }, { id: 'lip-stone', kind: 'lip' }, { id: 'lip-crystal', kind: 'lip' },
    { id: 'lip-brass', kind: 'lip' }, { id: 'lip-slate', kind: 'lip' },
    /* how the underside ends */
    { id: 'bottom-round', kind: 'bottom' }, { id: 'bottom-stepped', kind: 'bottom' }, { id: 'bottom-points', kind: 'bottom' },
    { id: 'bottom-flat', kind: 'bottom' }, { id: 'bottom-spikes', kind: 'bottom' },
    /* hangers */
    { id: 'root-tangle', kind: 'hanger' }, { id: 'root-tap', kind: 'hanger' }, { id: 'vine-ivy', kind: 'hanger' },
    { id: 'vine-flower', kind: 'hanger' }, { id: 'moss-beard', kind: 'hanger' }, { id: 'waterfall', kind: 'hanger' },
    { id: 'dripline', kind: 'hanger' }, { id: 'chain', kind: 'hanger' }, { id: 'broken-arch', kind: 'hanger' },
    { id: 'hanging-block', kind: 'hanger' }, { id: 'banner-rag', kind: 'hanger' }, { id: 'pillar-stub', kind: 'hanger' },
    { id: 'crystal-cluster', kind: 'hanger' }, { id: 'crystal-spike', kind: 'hanger' }, { id: 'glow-vein', kind: 'hanger' },
    { id: 'geode-shard', kind: 'hanger' }, { id: 'brass-strut', kind: 'hanger' }, { id: 'pipe-run', kind: 'hanger' },
    { id: 'propeller', kind: 'hanger' }, { id: 'gear-wheel', kind: 'hanger' }, { id: 'steam-vent', kind: 'hanger' },
    { id: 'lantern', kind: 'hanger' }, { id: 'rock-spike', kind: 'hanger' }, { id: 'storm-rod', kind: 'hanger' },
    { id: 'static-vein', kind: 'hanger' }, { id: 'hanging-shard', kind: 'hanger' },
    /* the cloud sea */
    { id: 'cloud-cumulus', kind: 'cloud' }, { id: 'cloud-stratus', kind: 'cloud' }, { id: 'cloud-puff', kind: 'cloud' },
    { id: 'cloud-anvil', kind: 'cloud' },
    /* wisps between the islands */
    { id: 'wisp-ribbon', kind: 'wisp' }, { id: 'wisp-curl', kind: 'wisp' }, { id: 'wisp-scrap', kind: 'wisp' },
    { id: 'wisp-long', kind: 'wisp' },
    /* distant islands */
    { id: 'distant-isle-round', kind: 'distant' }, { id: 'distant-isle-spire', kind: 'distant' }, { id: 'distant-isle-ruin', kind: 'distant' },
    /* on the wind */
    { id: 'mote-petal', kind: 'mote' }, { id: 'mote-leaf', kind: 'mote' }, { id: 'mote-dust', kind: 'mote' },
    { id: 'mote-sparkle', kind: 'mote' }, { id: 'mote-soot', kind: 'mote' }, { id: 'mote-rain', kind: 'mote' },
    { id: 'wind-streak', kind: 'streak' }
  ];
  var ENTITY_IDS = ENTITIES.map(function (e) { return e.id; });
  /* the HEADLINE set: lips and keels are finishes OF the five bodies, so they are not counted as kinds of their own (a
   * fresh review, 2026-10-27, read "five materials shown three ways" as padding, and it was) */
  var HEADLINE_IDS = ENTITIES.filter(function (e) { return e.kind !== 'lip' && e.kind !== 'bottom'; }).map(function (e) { return e.id; });

  /* ------------------------------------------------------------ notetag --*/
  /**
   * Parse a map note. Returns null when the map is not an Aloft map.
   *   <aloft>                                   the default dressing
   *   <aloft: ruins>                            a dressing by id
   *   <aloft: storm, depth 4, wind 220, clouds 80, shadow off, isles 0, motes 40, sky region 7>
   * Every number is bounded; an unknown word is ignored (never fatal), and `bad` lists what was ignored.
   * @param {string} note
   * @param {object} [defaults] {dressing, depth, wind, clouds, motes, isles, skyRegion}
   */
  function parseNote(note, defaults) {
    var d = defaults || {};
    var m = /<aloft(?:\s*:\s*([^>]*))?>/i.exec(String(note || ''));
    if (!m) return null;
    var out = {
      dressing: DRESSINGS[d.dressing] ? d.dressing : 'garden',
      depth: num(d.depth, 3, 1, 6), wind: num(d.wind, 20, 0, 359), windSpeed: num(d.windSpeed, 1, 0, 4),
      clouds: num(d.clouds, 70, 0, 100), motes: num(d.motes, 50, 0, 100), isles: num(d.isles, 2, 0, 4),
      shadow: d.shadow === undefined ? true : !!d.shadow, skyRegion: num(d.skyRegion, 1, 0, 255), bad: []
    };
    var body = (m[1] || '').trim();
    if (!body) return out;
    var parts = body.split(',');
    for (var i = 0; i < parts.length; i++) {
      var p = parts[i].trim().toLowerCase();
      if (!p) continue;
      if (DRESSINGS[p]) { out.dressing = p; continue; }
      var kv = /^(depth|wind|speed|clouds|motes|isles|shadow|sky region)\s+(.+)$/.exec(p);
      if (!kv) { out.bad.push(p); continue; }
      var k = kv[1], v = kv[2].trim();
      if (k === 'shadow') { if (v === 'on' || v === 'off') out.shadow = v === 'on'; else out.bad.push(p); continue; }
      var n = Number(v);
      if (v === '' || !isFinite(n)) { out.bad.push(p); continue; }   /* wing §16: blank is absent, never zero */
      if (k === 'depth') out.depth = num(n, out.depth, 1, 6);
      else if (k === 'wind') out.wind = ((Math.round(n) % 360) + 360) % 360;
      else if (k === 'speed') out.windSpeed = num(n, out.windSpeed, 0, 4);
      else if (k === 'clouds') out.clouds = num(n, out.clouds, 0, 100);
      else if (k === 'motes') out.motes = num(n, out.motes, 0, 100);
      else if (k === 'isles') out.isles = Math.round(num(n, out.isles, 0, 4));
      else if (k === 'sky region') out.skyRegion = Math.round(num(n, out.skyRegion, 0, 255));
    }
    return out;
  }
  function num(v, dflt, lo, hi) {
    if (v === '' || v === null || v === undefined) return dflt;
    var n = Number(v);
    if (!isFinite(n)) return dflt;
    return n < lo ? lo : (n > hi ? hi : n);
  }

  /* --------------------------------------------------------- void/ground --*/
  /**
   * Classify every cell. VOID when all four tile layers are 0, or the region equals skyRegion (> 0).
   * @param {number} w @param {number} h
   * @param {Array<number>} data  MZ map data (w*h*6: layers 0-3 tiles, 4 shadow, 5 region)
   * @param {number} skyRegion  0 = the region route is off
   * @returns {Uint8Array} 1 = void, 0 = ground
   */
  function classify(w, h, data, skyRegion) {
    var n = w * h, mask = new Uint8Array(n);
    for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) {
      var i = y * w + x;
      var region = data[5 * n + i] || 0;
      if (skyRegion > 0 && region === skyRegion) { mask[i] = 1; continue; }
      var empty = true;
      for (var z = 0; z < 4; z++) if ((data[z * n + i] || 0) !== 0) { empty = false; break; }
      mask[i] = empty ? 1 : 0;
    }
    return mask;
  }

  /**
   * Label the ground into islands (4-connected) and describe each one's edges.
   * An island: {id, x0, x1, y0, y1, cells, cols: {x: {bottom, edges:[y...]}}, south: [[x,y]...], east, west, north}
   *   south = ground cells with void directly below (inside the map); bottom = the lowest of them per column.
   * @returns {{labels: Int32Array, islands: Array}}
   */
  function islands(mask, w, h) {
    var labels = new Int32Array(w * h).fill(-1), list = [], stack = [];
    for (var s = 0; s < w * h; s++) {
      if (mask[s] || labels[s] >= 0) continue;
      var id = list.length, isl = { id: id, x0: w, x1: -1, y0: h, y1: -1, cells: 0, cols: {}, south: [], east: [], west: [], north: [] };
      labels[s] = id; stack.length = 0; stack.push(s);
      while (stack.length) {
        var c = stack.pop(), x = c % w, y = (c - x) / w;
        isl.cells++;
        if (x < isl.x0) isl.x0 = x; if (x > isl.x1) isl.x1 = x; if (y < isl.y0) isl.y0 = y; if (y > isl.y1) isl.y1 = y;
        var nb = [[x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]];
        for (var k = 0; k < 4; k++) {
          var nx = nb[k][0], ny = nb[k][1];
          if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
          var j = ny * w + nx;
          if (!mask[j] && labels[j] < 0) { labels[j] = id; stack.push(j); }
        }
        if (y + 1 < h && mask[c + w]) {
          isl.south.push([x, y]);
          var col = isl.cols[x] || (isl.cols[x] = { bottom: -1, edges: [] });
          col.edges.push(y); if (y > col.bottom) col.bottom = y;
        }
        if (x + 1 < w && mask[c + 1]) isl.east.push([x, y]);
        if (x - 1 >= 0 && mask[c - 1]) isl.west.push([x, y]);
        if (y - 1 >= 0 && mask[c - w]) isl.north.push([x, y]);
      }
      /* the free sky under each column's lowest edge: a keel may not hang into the island below it (looked at
       * 2026-10-27: an isle's rock ran straight into the grass of the islet under it). Reaching the map's foot = open. */
      for (var cx in isl.cols) {
        var cc = isl.cols[cx], gy = cc.bottom + 1, gap = 0;
        while (gy < h && mask[gy * w + Number(cx)]) { gap++; gy++; }
        cc.gap = gy >= h ? 99 : gap;
      }
      list.push(isl);
    }
    return { labels: labels, islands: list };
  }

  /* ---------------------------------------------------------- undersides --*/
  /**
   * The hanging profile of one island, in PIXELS relative to the map origin.
   * For every column x that has a southern edge: top = the middle of the lowest edge tile (the ground tile covers the
   * upper half, so no seam can show), depth = the taper across the island's own width x the note's depth, shaped by the
   * dressing's bottom style. Upper notches (an edge above the lowest one) get a short lip only.
   * @param {object} isl  one entry of islands().islands
   * @param {object} opt  {depth (tiles), bottom ('round'|'stepped'|'points'|'flat'|'spikes')}
   * @param {Rng} rng
   * @returns {{cols: Array<{x, top, bottom}>, notches: Array<{x, top, bottom}>, x0, x1, maxBottom, hangW}}
   */
  function profile(isl, opt, rng) {
    var TILE = opt.tile || 48;   /* the map's own tile size (MZ lets a project change it) */
    var xs = Object.keys(isl.cols).map(Number).sort(function (a, b) { return a - b; });
    var out = { cols: [], notches: [], x0: 0, x1: 0, maxBottom: 0, hangW: 0, tile: TILE };
    if (!xs.length) return out;
    var w = isl.x1 - isl.x0 + 1, hgt = isl.y1 - isl.y0 + 1;
    /* a narrow or flat island cannot hang a deep keel: depth grows with size, capped by the note */
    var cap = Math.max(1, Math.min(opt.depth, 0.6 + Math.sqrt(w * Math.max(1, hgt)) * 0.55));
    var steps = opt.bottom === 'stepped';
    var raw = [];
    for (var i = 0; i < xs.length; i++) {
      var x = xs[i], col = isl.cols[x];
      var t = (x - isl.x0 + 0.5) / w;
      var taper = Math.pow(Math.sin(Math.PI * t), 0.65);
      var d = cap * (0.22 + 0.78 * taper) * (0.88 + 0.24 * rng.next());
      if (steps) d = Math.max(0.5, Math.round(d * 2) / 2);
      raw.push({ x: x, top: (col.bottom + 0.5) * TILE, d: d * TILE });
      for (var e = 0; e < col.edges.length; e++) {
        var ey = col.edges[e];
        if (ey !== col.bottom) out.notches.push({ x: x, top: (ey + 0.5) * TILE, bottom: (ey + 1) * TILE + TILE * 0.32 });
      }
    }
    /* smooth the bottom contour (not for stepped masonry), never shallower than a third of a tile */
    for (var j = 0; j < raw.length; j++) {
      var b;
      if (steps) b = raw[j].top + raw[j].d;
      else {
        var acc = 0, wsum = 0;
        for (var k = -1; k <= 1; k++) {
          var q = raw[j + k];
          if (!q || Math.abs(q.x - raw[j].x) > 1) continue;
          var wt = k === 0 ? 2 : 1;
          acc += (q.top + q.d) * wt; wsum += wt;
        }
        b = acc / wsum;
      }
      b = Math.max(b, raw[j].top + TILE * 0.85);
      var cg = isl.cols[raw[j].x].gap;
      if (cg !== undefined && cg < 99) b = Math.min(b, (isl.cols[raw[j].x].bottom + 1 + cg - 0.3) * TILE);
      out.cols.push({ x: raw[j].x, top: raw[j].top, bottom: b });
      if (b > out.maxBottom) out.maxBottom = b;
    }
    out.x0 = xs[0]; out.x1 = xs[xs.length - 1]; out.hangW = (out.x1 - out.x0 + 1) * TILE;
    return out;
  }

  /**
   * Where the hangers go on one island: walk the hanging columns, one hanger per ~0.9 tile of edge, kinds drawn from the
   * dressing's weighted table. A waterfall or a propeller is placed at most once per island, near the deepest column.
   * Deterministic for (map seed, island id).
   * @returns {Array<{kind, x, y, len, seed}>}  x, y in map pixels (y = where it hangs from), len in pixels
   */
  function placeHangers(prof, dressing, rng) {
    var TILE = prof.tile || 48;
    var D = DRESSINGS[dressing] || DRESSINGS.garden, table = [], total = 0, key;
    for (key in D.hangers) { table.push([key, D.hangers[key]]); total += D.hangers[key]; }
    var out = [], once = { waterfall: 0, propeller: 0, 'broken-arch': 0, 'steam-vent': 0 };
    if (!prof.cols.length) return out;
    var deepest = prof.cols[0];
    for (var i = 1; i < prof.cols.length; i++) if (prof.cols[i].bottom - prof.cols[i].top > deepest.bottom - deepest.top) deepest = prof.cols[i];
    for (var c = 0; c < prof.cols.length; c++) {
      var col = prof.cols[c];
      var count = rng.next() < 0.88 ? 1 : 2;
      for (var n = 0; n < count; n++) {
        var r = rng.next() * total, kind = table[0][0];
        for (var t = 0; t < table.length; t++) { r -= table[t][1]; if (r <= 0) { kind = table[t][0]; break; } }
        if (once[kind] !== undefined) {
          if (once[kind] >= 1 || Math.abs(col.x - deepest.x) > 2) { kind = table[0][0]; } else once[kind]++;
        }
        var fx = (col.x + rng.range(0.15, 0.85)) * TILE;
        var depth = col.bottom - col.top;
        /* most hangers hang from the BOTTOM contour; veins, struts and lanterns sit ON the face */
        var onFace = kind === 'glow-vein' || kind === 'static-vein' || kind === 'pipe-run' || kind === 'gear-wheel' || kind === 'brass-strut';
        var y = onFace ? col.top + depth * rng.range(0.3, 0.7) : col.bottom - rng.range(4, 10);
        var len = kind === 'waterfall' ? 420 : TILE * rng.range(0.5, 1.6);
        out.push({ kind: kind, x: fx, y: y, len: len, seed: (rng.next() * 4294967296) >>> 0 });
      }
    }
    /* a waterfall falls from the LIP, not from the keel */
    for (var h = 0; h < out.length; h++) if (out[h].kind === 'waterfall') out[h].y = (Math.floor(out[h].x / TILE) === deepest.x ? deepest.top : out[h].y) + TILE * 0.5;
    return out;
  }

  /* ------------------------------------------------------------- palette --*/
  /**
   * The underside palette from the dressing and the buyer's sampled edge colours.
   * @param {string} dressing
   * @param {{mean:number[], dark:number[], light:number[]}|null} sample  null = the dressing's own palette, untinted
   * @returns {{lip, lipDark, strata:number[][], crack, highlight, keel, accent, glow}}
   */
  function derivePalette(dressing, sample) {
    var D = DRESSINGS[dressing] || DRESSINGS.garden, rock = D.rock.map(hex), t = D.tint;
    var mean = sample && sample.mean ? sample.mean : rock[0], dark = sample && sample.dark ? sample.dark : shade(rock[0], 0.6);
    var light = sample && sample.light ? sample.light : mix(rock[0], [255, 255, 255], 0.3);
    /* the upper strata lean HARD toward the ground's own colour (darkened a step per band), the deep ones keep more of the
     * dressing's rock: MEASURED 2026-10-27 on the g4 plate, a flat 0.28 tint left grass, sandstone, snow and basalt islands
     * with four near-identical brown undersides (the claim was true and invisible: wing §21b) */
    var strata = [];
    for (var i = 0; i < rock.length; i++) {
      var ground = shade(i < 2 ? mean : mix(mean, dark, 0.5), 0.92 - i * 0.13);
      strata.push(mix(rock[i], ground, sample ? Math.min(0.85, t * (2.4 - i * 0.38)) : 0));
    }
    return {
      lip: mix(mean, dark, 0.15), lipDark: shade(dark, 0.7), strata: strata,
      crack: shade(strata[strata.length - 1], 0.55), highlight: mix(strata[0], light, 0.35), keel: shade(strata[strata.length - 1], 0.75),
      accent: hex(D.accent), glow: D.glow ? hex(D.glow) : null
    };
  }

  /**
   * Summarise a tile's pixels (RGBA bytes) into mean / dark / light colours over its OPAQUE pixels.
   * dark = mean of the darkest quarter, light = mean of the brightest quarter. Null when the tile is empty.
   * @param {Uint8ClampedArray|Array<number>} px
   */
  function summarise(px) {
    var lums = [], cols = [];
    for (var i = 0; i + 3 < px.length; i += 4) {
      if (px[i + 3] < 128) continue;
      var c = [px[i], px[i + 1], px[i + 2]];
      cols.push(c); lums.push(0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]);
    }
    if (cols.length < 8) return null;
    var idx = lums.map(function (v, k) { return k; }).sort(function (a, b) { return lums[a] - lums[b] || a - b; });
    function meanOf(from, to) {
      var r = 0, g = 0, b = 0, n = 0;
      for (var k = from; k < to; k++) { var c = cols[idx[k]]; r += c[0]; g += c[1]; b += c[2]; n++; }
      return [Math.round(r / n), Math.round(g / n), Math.round(b / n)];
    }
    var q = Math.max(1, Math.floor(cols.length / 4));
    return { mean: meanOf(0, cols.length), dark: meanOf(0, q), light: meanOf(cols.length - q, cols.length), opaque: cols.length };
  }

  /* ------------------------------------------------------------------ sky --*/
  /**
   * The sky's three stops for the current screen tone. MZ's tone [r, g, b, gray] is applied on top by the engine's own
   * ColorFilter; here the PALETTE moves too (a dusk tone warms the horizon, a night tone deepens the zenith and brings the
   * stars), so a night sky is a night sky and not a darkened noon.
   * @param {string} dressing @param {number[]} tone [r,g,b,gray]
   * @returns {{top:number[], mid:number[], low:number[], stars:number}}  stars 0..1
   */
  function skyFor(dressing, tone) {
    var D = DRESSINGS[dressing] || DRESSINGS.garden, s = D.sky.map(hex);
    var r = tone ? tone[0] : 0, g = tone ? tone[1] : 0, b = tone ? tone[2] : 0;
    /* darkness reads red and green only: MZ's own Night preset is (-68,-68,0,68), blue held at 0, and must read as 1;
     * its Sunset preset (68,-34,-34,0) must read as 0 (MEASURED 2026-10-27: the mean of all three read Night as 0.67) */
    var dark = Math.max(0, Math.min(1, -(r + g) / 2 / 68));
    var warm = Math.max(0, Math.min(1, (r - b) / 68));                    /* a dusk/sunset tone (+r, -b) */
    var top = mix(s[0], [16, 22, 52], dark * 0.85), mid = mix(s[1], [34, 44, 86], dark * 0.8), low = mix(s[2], [70, 72, 110], dark * 0.7);
    if (warm > 0) { mid = mix(mid, [236, 150, 120], warm * 0.55); low = mix(low, [255, 196, 140], warm * 0.65); }
    return { top: top, mid: mid, low: low, stars: dark > 0.35 ? Math.min(1, (dark - 0.35) / 0.5) : 0 };
  }

  /**
   * Parallax: where a layer of depth factor p puts a world x (or y), given the camera and the screen centre.
   * p = 1 moves with the map, p = 0 never moves; a layer is directly under the island when the island is centred.
   */
  function parallax(world, cam, centre, p) { return (world - cam - centre) * p + centre; }

  globalThis.CSAF.AloftCore = {
    VERSION: '1.0.0', TILE: TILE,
    DRESSINGS: DRESSINGS, DRESSING_ORDER: DRESSING_ORDER, ENTITIES: ENTITIES, ENTITY_IDS: ENTITY_IDS, HEADLINE_IDS: HEADLINE_IDS,
    hash: hash, Rng: Rng, hex: hex, mix: mix, shade: shade, lum: lum, css: css, hsl: hsl,
    parseNote: parseNote, classify: classify, islands: islands, profile: profile, placeHangers: placeHangers,
    derivePalette: derivePalette, summarise: summarise, skyFor: skyFor, parallax: parallax
  };
})();
