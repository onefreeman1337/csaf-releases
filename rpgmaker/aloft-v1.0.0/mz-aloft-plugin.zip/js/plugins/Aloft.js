//=============================================================================
// Aloft.js — Aloft [3/3]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Aloft [3/3] — your own maps as islands in the sky: rock undersides from your own edge tiles, a sea of clouds below. v1.0.0
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help Aloft.js
 *
 * Load all three: AloftCore.js, AloftPaint.js and Aloft.js. Any order works.
 *
 * ---------------------------------------------------------------------------
 * HOW TO USE
 * ---------------------------------------------------------------------------
 * 1. Put <aloft> in a map's Note box.
 * 2. Leave the sky EMPTY, or paint it with the Sky Region (region 1 by
 *    default). Everything else is ground.
 * 3. Playtest. Under every southern edge of your ground the plugin hangs a
 *    rock underside, cut from your own edge tiles' pixels and tinted by
 *    them. The sky becomes open air over a sea of clouds drifting far below,
 *    with wisps between the islands, your islands' shadows on the clouds,
 *    distant islands, and petals or dust on the wind.
 *
 * Nothing in the map file changes. Sky cells cannot be walked on.
 *
 * ---------------------------------------------------------------------------
 * MAP NOTE
 * ---------------------------------------------------------------------------
 *   <aloft>                      the Default Dressing
 *   <aloft: ruins>               a dressing: garden, ruins, crystal, steam, storm
 *   <aloft: storm, depth 4, wind 200, speed 2, clouds 90, motes 30,
 *           isles 3, shadow off, sky region 7>
 *
 *   depth   how far the rock hangs, in tiles (1-6)
 *   wind    the direction the clouds and motes travel, degrees
 *           (0 = east, 90 = south, 180 = west, 270 = north)
 *   speed   wind speed (0-4)
 *   clouds  how much of the cloud sea is covered (0-100)
 *   motes   how many petals, leaves, dust or rain drops ride the wind (0-100)
 *   isles   distant islands in the far sky (0-4)
 *   shadow  your islands' shadows on the cloud sea (on/off)
 *   sky region   the region that marks sky on this map (0 = only empty cells)
 *
 * ---------------------------------------------------------------------------
 * DRESSINGS
 * ---------------------------------------------------------------------------
 *   garden   Spirit Garden: earth and roots, ivy, flowering vines, moss,
 *            a waterfall off the edge, petals on the wind
 *   ruins    Sky Ruins: cut-stone courses, chains, broken arches, hanging
 *            blocks, banners, pillar stubs, dust
 *   crystal  Crystal Spire: geode rock, glowing crystal clusters and veins,
 *            sparkles
 *   steam    Steam Isle: riveted brass bands, struts, pipes, gears, lanterns,
 *            a turning propeller, steam vents, soot
 *   storm    Storm Reach: jagged slate, spikes, lightning rods, static veins,
 *            dark anvil clouds lit by lightning, rain
 *
 * The sky follows your own screen tone: a Night tint gives a night sky with
 * stars, a warm tint gives a sunset horizon.
 *
 * ---------------------------------------------------------------------------
 * PLUGIN COMMANDS
 * ---------------------------------------------------------------------------
 *   Aloft On/Off           turn Aloft on or off for the whole game
 *   Set Map Dressing       change this map's dressing (saved)
 *   Set Wind               change wind direction and speed (saved)
 *   Set Cloud Cover        change the cloud cover (saved)
 *   Fall Off the Edge      the player or an event steps off the edge and
 *                          falls through the clouds; then a transfer
 *                          (player) or a temporary erase (event)
 *
 * ---------------------------------------------------------------------------
 * COMPATIBILITY
 * ---------------------------------------------------------------------------
 * Extends (calls the original): Game_System initialize / onAfterLoad,
 * Game_Map setup / isPassable, Game_CharacterBase update / screenY,
 * Game_Interpreter updateWaitMode, Sprite_Character updateOther,
 * Spriteset_Map createLowerLayer / update / destroy, Scene_Map start.
 * Replaces nothing. Looping maps: sky and clouds work; undersides are not
 * drawn across the loop seam.
 *
 * Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.
 *
 * @param defaultDressing
 * @text Default Dressing
 * @type select
 * @option garden
 * @option ruins
 * @option crystal
 * @option steam
 * @option storm
 * @default garden
 * @desc The dressing for a map whose note is just <aloft>.
 *
 * @param skyRegion
 * @text Sky Region
 * @type number
 * @min 0
 * @max 255
 * @default 1
 * @desc Cells painted with this region are sky. 0 = only cells with no tile on any layer are sky.
 *
 * @param depth
 * @text Underside Depth
 * @type number
 * @min 1
 * @max 6
 * @default 3
 * @desc How far the rock hangs below a large island, in tiles. Small islands hang less.
 *
 * @param wind
 * @text Wind Direction
 * @type number
 * @min 0
 * @max 359
 * @default 15
 * @desc Degrees. 0 = east, 90 = south, 180 = west, 270 = north.
 *
 * @param windSpeed
 * @text Wind Speed
 * @type number
 * @decimals 1
 * @min 0
 * @max 4
 * @default 1
 *
 * @param clouds
 * @text Cloud Cover
 * @type number
 * @min 0
 * @max 100
 * @default 70
 *
 * @param motes
 * @text Motes
 * @type number
 * @min 0
 * @max 100
 * @default 50
 * @desc How many petals, leaves, dust or rain drops ride the wind.
 *
 * @param isles
 * @text Distant Isles
 * @type number
 * @min 0
 * @max 4
 * @default 2
 *
 * @param shadow
 * @text Island Shadows
 * @type boolean
 * @on Shown
 * @off Hidden
 * @default true
 *
 * @command setEnabled
 * @text Aloft On/Off
 * @desc Turn Aloft on or off for the whole game (saved).
 *
 * @arg on
 * @text On
 * @type boolean
 * @default true
 *
 * @command setDressing
 * @text Set Map Dressing
 * @desc Change the current map's dressing (saved). Takes effect at once.
 *
 * @arg dressing
 * @text Dressing
 * @type select
 * @option garden
 * @option ruins
 * @option crystal
 * @option steam
 * @option storm
 * @default garden
 *
 * @command setWind
 * @text Set Wind
 * @desc Change the wind on every Aloft map (saved).
 *
 * @arg direction
 * @text Direction
 * @type number
 * @min 0
 * @max 359
 * @default 15
 *
 * @arg speed
 * @text Speed
 * @type number
 * @decimals 1
 * @min 0
 * @max 4
 * @default 1
 *
 * @command setClouds
 * @text Set Cloud Cover
 * @desc Change the cloud cover on every Aloft map (saved).
 *
 * @arg cover
 * @text Cover
 * @type number
 * @min 0
 * @max 100
 * @default 70
 *
 * @command fall
 * @text Fall Off the Edge
 * @desc The character steps one tile forward off the edge and falls through the clouds.
 *
 * @arg character
 * @text Character
 * @type number
 * @min -1
 * @default -1
 * @desc -1 = the player, 0 = this event, N = event N.
 *
 * @arg wait
 * @text Wait for Completion
 * @type boolean
 * @default true
 *
 * @arg mapId
 * @text Then Transfer To Map
 * @type number
 * @min 0
 * @default 0
 * @desc Player only. 0 = no transfer (the player stays hidden until you show them).
 *
 * @arg x
 * @text Transfer X
 * @type number
 * @min 0
 * @default 0
 *
 * @arg y
 * @text Transfer Y
 * @type number
 * @min 0
 * @default 0
 */

'use strict';

if (typeof globalThis.CSAF === 'undefined') globalThis.CSAF = {};

(function () {
  var PLUGIN = 'Aloft';
  var P = PluginManager.parameters(PLUGIN);
  function pnum(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; var n = Number(v); return isFinite(n) ? n : d; }
  var DEFAULTS = {
    dressing: String(P.defaultDressing || 'garden'),
    skyRegion: pnum(P.skyRegion, 1), depth: pnum(P.depth, 3), wind: pnum(P.wind, 15), windSpeed: pnum(P.windSpeed, 1),
    clouds: pnum(P.clouds, 70), motes: pnum(P.motes, 50), isles: pnum(P.isles, 2), shadow: String(P.shadow) !== 'false'
  };
  /* siblings resolved at FIRST USE (wing §8 trap 2: the load order is the buyer's) */
  function deps() {
    var C = globalThis.CSAF;
    if (!C.AloftCore || !C.AloftPaint) throw new Error('Aloft: AloftCore.js and AloftPaint.js must be installed and ON in the Plugin Manager.');
    return C;
  }
  var testSeed = null;
  var FALL_FRAMES = 64;
  var DEPTH = { stars: 0.04, isles: 0.12, far: 0.28, shadow: 0.42, near: 0.45, wisp: 0.72 };

  /* ------------------------------------------------------------ the save --*/
  function slot() {
    var s = $gameSystem._csafAloft;
    if (!s || s.v !== 1) s = $gameSystem._csafAloft = { v: 1, enabled: true, dressing: {}, wind: null, speed: null, clouds: null };
    return s;
  }
  var _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () { _Game_System_initialize.apply(this, arguments); this._csafAloft = { v: 1, enabled: true, dressing: {}, wind: null, speed: null, clouds: null }; };
  var _Game_System_onAfterLoad = Game_System.prototype.onAfterLoad;
  Game_System.prototype.onAfterLoad = function () { _Game_System_onAfterLoad.apply(this, arguments); if (!this._csafAloft || this._csafAloft.v !== 1) this._csafAloft = { v: 1, enabled: true, dressing: {}, wind: null, speed: null, clouds: null }; };

  /* -------------------------------------------------- the map's runtime --*/
  /**
   * The current map's Aloft runtime, or null. Kept on $gameMap NON-ENUMERABLY (wing §13): $gameMap is saved, and
   * the mask is rebuilt from the map data whenever it is missing (after a load) or stale (after a transfer).
   */
  function runtime() {
    if (!$gameMap || !$dataMap || !$gameMap.mapId()) return null;
    if (!$gameSystem || !slot().enabled) return null;
    var rt = $gameMap._csafAloftRt;
    if (rt && rt.mapId === $gameMap.mapId() && rt.dataRef === $dataMap.data) return rt.spec ? rt : null;
    rt = buildRuntime();
    Object.defineProperty($gameMap, '_csafAloftRt', { value: rt, writable: true, enumerable: false, configurable: true });
    return rt.spec ? rt : null;
  }
  function buildRuntime() {
    var K = deps().AloftCore, s = slot(), mapId = $gameMap.mapId();
    var spec = K.parseNote($dataMap.note, DEFAULTS);
    var rt = { mapId: mapId, dataRef: $dataMap.data, spec: spec, mask: null, isl: null };
    if (!spec) return rt;
    if (s.dressing[mapId] && K.DRESSINGS[s.dressing[mapId]]) spec.dressing = s.dressing[mapId];
    if (s.wind !== null) spec.wind = s.wind;
    if (s.speed !== null) spec.windSpeed = s.speed;
    if (s.clouds !== null) spec.clouds = s.clouds;
    var w = $dataMap.width, h = $dataMap.height;
    rt.mask = K.classify(w, h, $dataMap.data, spec.skyRegion);
    rt.isl = K.islands(rt.mask, w, h);
    rt.seed = testSeed !== null ? testSeed : K.hash('aloft:' + mapId);
    return rt;
  }
  function isVoid(rt, x, y) {
    var w = $dataMap.width;
    if (x < 0 || y < 0 || x >= w || y >= $dataMap.height) return false;
    return rt.mask[y * w + x] === 1;
  }

  var _Game_Map_setup = Game_Map.prototype.setup;
  Game_Map.prototype.setup = function (mapId) {
    _Game_Map_setup.apply(this, arguments);
    if (this._csafAloftRt) this._csafAloftRt = null;
  };
  /* sky cannot be walked on: from either side (Game_CharacterBase.isMapPassable asks both cells) */
  var _Game_Map_isPassable = Game_Map.prototype.isPassable;
  Game_Map.prototype.isPassable = function (x, y, d) {
    var rt = runtime();
    if (rt && isVoid(rt, this.roundX(x), this.roundY(y))) return false;
    return _Game_Map_isPassable.apply(this, arguments);
  };

  /* ------------------------------------------------- sampling the tiles --*/
  /**
   * Draw one tile id into ctx at (dx, dy) the way the ENGINE draws it (rmmz_core.js Tilemap.prototype._addNormalTile and
   * _addAutotile, animation frame 0), from the tileset bitmaps. Read once at map load (wing §27a), never during play.
   */
  function drawTileInto(ctx, bitmaps, flags, tileId, dx, dy, tw, th) {
    if (!tileId || tileId >= Tilemap.TILE_ID_MAX) return 0;
    var setNumber, sx, sy, src;
    if (!Tilemap.isAutotile(tileId)) {
      setNumber = Tilemap.isTileA5(tileId) ? 4 : 5 + Math.floor(tileId / 256);
      sx = ((Math.floor(tileId / 128) % 2) * 8 + (tileId % 8)) * tw;
      sy = (Math.floor((tileId % 256) / 8) % 16) * th;
      src = source(bitmaps[setNumber]);
      if (!src) return 0;
      ctx.drawImage(src, sx, sy, tw, th, dx, dy, tw, th);
      return 1;
    }
    var kind = Tilemap.getAutotileKind(tileId), shape = Tilemap.getAutotileShape(tileId), tx = kind % 8, ty = Math.floor(kind / 8);
    var bx = 0, by = 0, table = Tilemap.FLOOR_AUTOTILE_TABLE, isTable = false;
    setNumber = 0;
    if (Tilemap.isTileA1(tileId)) {
      if (kind === 0) { bx = 0; by = 0; } else if (kind === 1) { bx = 0; by = 3; } else if (kind === 2) { bx = 6; by = 0; } else if (kind === 3) { bx = 6; by = 3; }
      else { bx = Math.floor(tx / 4) * 8; by = ty * 6 + (Math.floor(tx / 2) % 2) * 3; if (kind % 2 !== 0) { bx += 6; table = Tilemap.WATERFALL_AUTOTILE_TABLE; } }
    } else if (Tilemap.isTileA2(tileId)) { setNumber = 1; bx = tx * 2; by = (ty - 2) * 3; isTable = !!(flags[tileId] & 0x80); }
    else if (Tilemap.isTileA3(tileId)) { setNumber = 2; bx = tx * 2; by = (ty - 6) * 2; table = Tilemap.WALL_AUTOTILE_TABLE; }
    else if (Tilemap.isTileA4(tileId)) { setNumber = 3; bx = tx * 2; by = Math.floor((ty - 10) * 2.5 + (ty % 2 === 1 ? 0.5 : 0)); if (ty % 2 === 1) table = Tilemap.WALL_AUTOTILE_TABLE; }
    src = source(bitmaps[setNumber]);
    if (!src) return 0;
    var t = table[shape], w1 = tw / 2, h1 = th / 2;
    for (var i = 0; i < 4; i++) {
      var qsx = t[i][0], qsy = t[i][1], sx1 = (bx * 2 + qsx) * w1, sy1 = (by * 2 + qsy) * h1, dx1 = dx + (i % 2) * w1, dy1 = dy + Math.floor(i / 2) * h1;
      if (isTable && (qsy === 1 || qsy === 5)) {
        var qsx2 = qsy === 1 ? (4 - qsx) % 4 : qsx;
        ctx.drawImage(src, (bx * 2 + qsx2) * w1, (by * 2 + 3) * h1, w1, h1, dx1, dy1, w1, h1);
        ctx.drawImage(src, sx1, sy1, w1, h1 / 2, dx1, dy1 + h1 / 2, w1, h1 / 2);
      } else ctx.drawImage(src, sx1, sy1, w1, h1, dx1, dy1, w1, h1);
    }
    return 1;
  }
  function source(bmp) {
    if (!bmp || !bmp.isReady || !bmp.isReady() || !bmp.width) return null;
    return bmp._canvas || bmp._image || null;
  }
  /** one tile cell's GROUND (tile layers 0 and 1) drawn into ctx at (dx, dy). Layers 2-3 hold props (a rock, a flower, a
   *  trunk); mirrored into the lip they hung half a rock under the edge (looked at 2026-10-27), so the lip takes ground only. */
  function drawCell(ctx, bitmaps, flags, x, y, dx, dy, tw, th) {
    var n = 0;
    for (var z = 0; z < 2; z++) n += drawTileInto(ctx, bitmaps, flags, $gameMap.tileId(x, y, z), dx, dy, tw, th);
    return n;
  }

  /* --------------------------------------------------------- the layers --*/
  function newCanvas(w, h) { var c = document.createElement('canvas'); c.width = Math.max(1, Math.ceil(w)); c.height = Math.max(1, Math.ceil(h)); return c; }
  function bitmapFrom(w, h, draw) {
    var b = new Bitmap(Math.max(1, Math.ceil(w)), Math.max(1, Math.ceil(h)));
    draw(b.context, b.width, b.height);
    b.baseTexture.update();
    return b;
  }

  /**
   * The Aloft layer of one Spriteset_Map. Built in two steps: the containers at createLowerLayer (no pixels exist yet),
   * the bake at Scene_Map.start (every tileset bitmap is loaded by then: Scene_Base.isReady waited for it).
   */
  function AloftLayer(spriteset, rt) {
    this.ss = spriteset; this.rt = rt; this.baked = false; this.t = 0; this.drift = 0; this.toneKey = '';
    this.back = new Sprite(); this.front = new Sprite();
    this.back.name = 'AloftBack'; this.front.name = 'AloftFront';
    this.anim = []; this.glows = []; this.motes = []; this.streaks = []; this.wisps = []; this.shadows = []; this.isles = []; this.parts = [];
    this.stats = { islands: 0, undersideBitmaps: 0, hangers: 0, hangerOps: 0, bodyOps: 0, sampledTiles: 0, bakeMs: 0, sample: [] };
    var base = spriteset._baseSprite, tm = spriteset._tilemap;
    base.addChildAt(this.back, base.children.indexOf(tm));
    base.addChildAt(this.front, base.children.indexOf(tm) + 1);
    this.blankTilemap();
  }
  /** the TILEMAP's own copy of the data with sky cells blanked (region-painted sky shows sky); $dataMap is untouched */
  AloftLayer.prototype.blankTilemap = function () {
    var rt = this.rt, w = $dataMap.width, h = $dataMap.height, n = w * h, any = false;
    for (var i = 0; i < n; i++) if (rt.mask[i]) { for (var z = 0; z < 4; z++) if ($dataMap.data[z * n + i]) { any = true; break; } if (any) break; }
    if (!any) return;
    var copy = $dataMap.data.slice();
    for (var j = 0; j < n; j++) if (rt.mask[j]) { copy[j] = 0; copy[n + j] = 0; copy[2 * n + j] = 0; copy[3 * n + j] = 0; copy[4 * n + j] = 0; }
    this.ss._tilemap.setData(w, h, copy);
    this.blanked = true;
  };

  AloftLayer.prototype.bake = function () {
    if (this.baked) return;
    var t0 = (typeof performance !== 'undefined') ? performance.now() : 0;
    var C = deps(), K = C.AloftCore, PA = C.AloftPaint, rt = this.rt, spec = rt.spec, D = K.DRESSINGS[spec.dressing];
    var tw = $gameMap.tileWidth(), th = $gameMap.tileHeight(), W = Graphics.width, H = Graphics.height;
    PA.setTile(tw);
    var rng = new K.Rng(rt.seed);
    var bitmaps = this.ss._tilemap._bitmaps || [], flags = $gameMap.tilesetFlags();
    /* ---- the sky: gradient + stars ---- */
    this.sky = new Sprite(new Bitmap(4, 256)); this.sky.scale.x = W / 4; this.sky.scale.y = H / 256;
    this.back.addChild(this.sky);
    var starRng = new K.Rng(rt.seed ^ 0x5157);
    this.stars = new TilingSprite(bitmapFrom(512, 512, function (ctx) { PA.drawStars(ctx, 512, 512, starRng); }));
    this.stars.move(0, 0, W, H); this.stars.alpha = 0; this.back.addChild(this.stars);
    this.updateSky(true);
    /* ---- distant isles ---- */
    var hazeC = K.mix(K.hex(D.deep), [255, 255, 255], 0.12), mapW = $dataMap.width * tw, mapH = $dataMap.height * th;
    for (var i = 0; i < spec.isles; i++) {
      var kindI = i === 0 ? D.distant : K.DRESSINGS[K.DRESSING_ORDER[(K.DRESSING_ORDER.indexOf(spec.dressing) + i) % 5]].distant;
      var ir = new K.Rng(rt.seed + 101 * (i + 1)), iw = ir.range(90, 150);
      var sp = new Sprite(bitmapFrom(iw, iw * 0.8, function (ctx, w2, h2) { PA.drawDistant(ctx, kindI, w2, h2, ir, hazeC); }));
      sp.anchor.x = 0.5; sp.anchor.y = 0.5; sp.alpha = 0.55 + 0.15 * ir.next();
      sp._aloftWX = mapW * (i + 0.5) / Math.max(1, spec.isles) + ir.range(-60, 60); sp._aloftWY = mapH * ir.range(0.15, 0.85);
      this.isles.push(sp); this.back.addChild(sp);
    }
    /* ---- the far cloud field ---- */
    var dk = K.hex(D.deep), cloudRng = new K.Rng(rt.seed ^ 0xc10d);
    var lit = D.cloud === 'anvil' ? [98, 106, 128] : [242, 246, 252], shd = D.cloud === 'anvil' ? [28, 32, 46] : K.mix(dk, [255, 255, 255], 0.35);
    var cover = spec.clouds;
    this.far = new TilingSprite(bitmapFrom(768, 512, function (ctx, w2, h2) { PA.drawCloudField(ctx, D.cloud, w2, h2, cloudRng, cover * 0.8, K.mix(lit, dk, 0.35), K.mix(shd, dk, 0.4)); }));
    this.far.move(0, 0, W, H); this.far.alpha = 0.85; this.back.addChild(this.far);
    /* ---- island shadows (on the near cloud tops) ---- */
    var isl = rt.isl.islands, profiles = [];
    for (var s = 0; s < isl.length; s++) {
      var prng = new K.Rng(rt.seed + 7919 * (s + 1));
      profiles.push(K.profile(isl[s], { depth: spec.depth, bottom: D.bottom, tile: tw }, prng));
    }
    this.nearShadow = new Sprite(); this.back.addChild(this.nearShadow);
    /* ---- the near cloud field ---- */
    var cloudRng2 = new K.Rng(rt.seed ^ 0xbeef);
    this.near = new TilingSprite(bitmapFrom(768, 512, function (ctx, w2, h2) { PA.drawCloudField(ctx, D.cloud, w2, h2, cloudRng2, cover, lit, shd); }));
    this.near.move(0, 0, W, H); this.near.alpha = cover > 0 ? 1 : 0; this.back.addChild(this.near);
    if (spec.shadow) this.makeShadows(isl, profiles, tw, th);
    this.back.removeChild(this.nearShadow); this.back.addChild(this.nearShadow);
    /* ---- storm flash ---- */
    if (D.cloud === 'anvil') {
      this.flash = new Sprite(bitmapFrom(4, 4, function (ctx) { ctx.fillStyle = '#dfeaff'; ctx.fillRect(0, 0, 4, 4); }));
      this.flash.scale.x = W / 4; this.flash.scale.y = H / 4; this.flash.alpha = 0; this.flash.blendMode = PIXI.BLEND_MODES.ADD;
      this.back.addChild(this.flash); this.flashT = 0; this.flashRng = new K.Rng(rt.seed ^ 0xf1a5);
    }
    /* ---- wisps ---- */
    var wispKinds = ['ribbon', 'curl', 'scrap', 'long'], wr = new K.Rng(rt.seed ^ 0x3157);
    for (var wi = 0; wi < 5; wi++) {
      var wk = wispKinds[wi % 4], ww = wr.range(150, 260);
      var wsp = new Sprite(bitmapFrom(ww, ww * 0.45, function (ctx, w2, h2) { PA.drawWisp(ctx, wk, w2, h2, wr); }));
      wsp.anchor.x = 0.5; wsp.anchor.y = 0.5; wsp.alpha = 0.7; wsp._aloftX = wr.range(0, W + 300); wsp._aloftY = wr.range(0, H);
      this.wisps.push(wsp); this.back.addChild(wsp);
    }
    /* ---- undersides and hangers ---- */
    this.stats.islands = isl.length;
    for (var u = 0; u < isl.length; u++) this.makeUnderside(isl[u], profiles[u], u, bitmaps, flags, tw, th);
    /* ---- the front: wind streaks and motes ---- */
    this.makeWind(D, spec);
    this.baked = true;
    this.stats.bakeMs = (typeof performance !== 'undefined') ? performance.now() - t0 : 0;
    this.update();
  };

  AloftLayer.prototype.makeShadows = function (isl, profiles, tw, th) {
    var PA = deps().AloftPaint;
    for (var i = 0; i < isl.length; i++) {
      var I = isl[i], prof = profiles[i];
      if (!I.cells) continue;
      var cells = [];
      for (var y = I.y0; y <= I.y1; y++) for (var x = I.x0; x <= I.x1; x++) if (!this.rt.mask[y * $dataMap.width + x] && this.rt.isl.labels[y * $dataMap.width + x] === I.id) cells.push([x, y]);
      /* the pad is three blur radii: at 24 px the 22 px blur was CLIPPED by the bitmap's own edge and drew a hard
       * vertical seam across the cloud sea (fresh review, 2026-10-27) */
      var pad = 72, ox = I.x0 * tw - pad, oy = I.y0 * th - pad, w = (I.x1 - I.x0 + 1) * tw + pad * 2, h = Math.max((I.y1 + 1) * th, prof.maxBottom) - I.y0 * th + pad * 2;
      if (w * h > 4096 * 4096) continue;
      /* a shadow far below is wide, soft and faint (MEASURED by looking 2026-10-27: alpha 0.32 at blur 10 read as SMOKE) */
      var sp = new Sprite(bitmapFrom(w, h, function (ctx) { PA.drawShadow(ctx, cells, prof, ox, oy, 22); }));
      sp.alpha = 0.16; sp._aloftWX = ox; sp._aloftWY = oy;
      this.shadows.push(sp); this.nearShadow.addChild(sp);
    }
  };

  AloftLayer.prototype.makeUnderside = function (I, prof, idx, bitmaps, flags, tw, th) {
    if (!prof.cols.length) return;
    var C = deps(), K = C.AloftCore, PA = C.AloftPaint, rt = this.rt, spec = rt.spec;
    /* the buyer's edge tiles, one per hanging column, drawn as the engine draws them */
    var lip = newCanvas(prof.cols.length * tw, th), lctx = lip.getContext('2d'), drawn = 0;
    for (var c = 0; c < prof.cols.length; c++) drawn += drawCell(lctx, bitmaps, flags, prof.cols[c].x, Math.round(prof.cols[c].top / th - 0.5), c * tw, 0, tw, th) ? 1 : 0;
    var sample = null;
    if (drawn) { try { sample = K.summarise(lctx.getImageData(0, 0, lip.width, lip.height).data); } catch (e) { sample = null; } }
    this.stats.sampledTiles += drawn;
    if (this.stats.sample.length < 8) this.stats.sample.push(sample ? { mean: sample.mean, dark: sample.dark, light: sample.light } : null);
    var pal = K.derivePalette(spec.dressing, sample);
    var seed = rt.seed + 104729 * (idx + 1);
    var hangers = K.placeHangers(prof, spec.dressing, new K.Rng(seed ^ 0x6a09));
    /* bounds: the whole hanging mass and everything that hangs from it */
    var x0 = prof.x0 * tw - tw, x1 = (prof.x1 + 1) * tw + tw, y0 = Infinity, y1 = prof.maxBottom + th * 2;
    for (var q = 0; q < prof.cols.length; q++) if (prof.cols[q].top < y0) y0 = prof.cols[q].top;
    y0 -= th * 0.6;
    for (var hh = 0; hh < hangers.length; hh++) if (hangers[hh].kind !== 'waterfall' && hangers[hh].y + hangers[hh].len * 1.5 > y1) y1 = hangers[hh].y + hangers[hh].len * 1.5;
    var CH = 2048, self = this;
    for (var cx = x0; cx < x1; cx += CH) {
      var cw = Math.min(CH, x1 - cx), ch = Math.min(4096, y1 - y0);
      var bmp = bitmapFrom(cw, ch, function (ctx) {
        self.stats.bodyOps += PA.drawUnderside(ctx, prof, pal, spec.dressing, new K.Rng(seed), cx, y0, drawn ? lip : null);
        var hr = new K.Rng(seed ^ 0x2545);
        for (var k = 0; k < hangers.length; k++) {
          var hg = hangers[k];
          ctx.save(); ctx.translate(-cx, -y0);
          self.stats.hangerOps += PA.drawHanger(ctx, hg.kind, hg.x, hg.y, hg.len, pal, hr);
          ctx.restore();
        }
      });
      var sp = new Sprite(bmp); sp._aloftWX = cx; sp._aloftWY = y0;
      this.parts.push(sp); this.back.addChild(sp);
      this.stats.undersideBitmaps++;
    }
    this.stats.hangers += hangers.length;
    /* the animated parts: waterfalls, propellers, glows */
    for (var a = 0; a < hangers.length; a++) {
      var g = hangers[a];
      if (g.kind === 'waterfall') {
        var wr = new K.Rng(g.seed), water = new TilingSprite(bitmapFrom(24, 192, function (ctx, w2, h2) { PA.drawWaterColumn(ctx, w2, h2, wr); }));
        water.move(0, 0, 24, g.len); water._aloftWX = g.x - 12; water._aloftWY = g.y; water._aloftKind = 'water'; water.alpha = 0.9;
        var mist = new Sprite(bitmapFrom(96, 64, function (ctx, w2, h2) { var gr = ctx.createRadialGradient(w2 / 2, h2 / 2, 0, w2 / 2, h2 / 2, w2 / 2); gr.addColorStop(0, 'rgba(255,255,255,0.75)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = gr; ctx.fillRect(0, 0, w2, h2); }));
        mist._aloftWX = g.x - 48; mist._aloftWY = g.y + g.len - 40;
        this.anim.push(water); this.parts.push(water, mist); this.back.addChild(water); this.back.addChild(mist);
      } else if (g.kind === 'propeller') {
        var pc = pal.accent, prop = new Sprite(bitmapFrom(56, 56, function (ctx) { PA.drawPropellerBlades(ctx, 28, 28, 26, pc, 0); }));
        prop.anchor.x = 0.5; prop.anchor.y = 0.5; prop._aloftWX = g.x; prop._aloftWY = g.y + 18; prop._aloftKind = 'prop';
        this.anim.push(prop); this.parts.push(prop); this.back.addChild(prop);
      } else if (/crystal|vein|lantern|storm-rod/.test(g.kind) && (pal.glow || g.kind === 'lantern')) {
        var gc = g.kind === 'lantern' ? [255, 196, 110] : pal.glow, glow = new Sprite(bitmapFrom(64, 64, function (ctx, w2, h2) { PA.drawGlow(ctx, w2, h2, gc); }));
        glow.anchor.x = 0.5; glow.anchor.y = 0.5; glow.blendMode = PIXI.BLEND_MODES.ADD;
        glow._aloftWX = g.x; glow._aloftWY = g.y + (g.kind === 'lantern' ? g.len * 0.5 + 10 : g.len * 0.45); glow._aloftPh = (g.seed % 628) / 100;
        this.glows.push(glow); this.parts.push(glow); this.back.addChild(glow);
      }
    }
  };

  AloftLayer.prototype.makeWind = function (D, spec) {
    var K = deps().AloftCore, PA = deps().AloftPaint, W = Graphics.width, H = Graphics.height, rng = new K.Rng(this.rt.seed ^ 0x77);
    var streakBmp = bitmapFrom(180, 8, function (ctx, w, h) { PA.drawStreak(ctx, w, h); });
    for (var i = 0; i < 6; i++) {
      var s = new Sprite(streakBmp); s.anchor.x = 0.5; s.anchor.y = 0.5; s.alpha = 0;
      s._aloftX = rng.range(0, W); s._aloftY = rng.range(0, H); s._aloftLife = rng.range(0, 1);
      this.streaks.push(s); this.front.addChild(s);
    }
    var kinds = [D.mote, D.mote2], moteBmp = bitmapFrom(64, 32, function (ctx) { for (var k = 0; k < 2; k++) { ctx.save(); ctx.translate(k * 32, 0); PA.drawMote(ctx, kinds[k], 32, 32, rng); ctx.restore(); } });
    var n = Math.round(28 * spec.motes / 100);
    for (var m = 0; m < n; m++) {
      var sp = new Sprite(moteBmp); sp.setFrame((m % 2) * 32, 0, 32, 32); sp.anchor.x = 0.5; sp.anchor.y = 0.5;
      var sc = rng.range(0.45, 0.9); sp.scale.x = sc; sp.scale.y = sc;
      sp._aloftX = rng.range(0, W); sp._aloftY = rng.range(0, H); sp._aloftPh = rng.range(0, 6.28); sp._aloftSp = rng.range(0.6, 1.4);
      this.motes.push(sp); this.front.addChild(sp);
    }
  };

  /** redraw the sky gradient only when the screen tone has moved (never every frame) */
  AloftLayer.prototype.updateSky = function (force) {
    var tone = $gameScreen.tone(), a = tone[0] >> 2, b = tone[1] >> 2, c = tone[2] >> 2, d = tone[3] >> 2;
    if (!force && a === this.tk0 && b === this.tk1 && c === this.tk2 && d === this.tk3) return;
    this.tk0 = a; this.tk1 = b; this.tk2 = c; this.tk3 = d; this.skyRedraws = (this.skyRedraws || 0) + 1;
    var K = deps().AloftCore, PA = deps().AloftPaint, sky = K.skyFor(this.rt.spec.dressing, tone), bmp = this.sky.bitmap;
    bmp.context.clearRect(0, 0, 4, 256); PA.drawSky(bmp.context, 4, 256, sky); bmp.baseTexture.update();
    this.stars.alpha = sky.stars;
  };

  /** every frame: numbers in, numbers out. No allocation (wing §3). */
  AloftLayer.prototype.update = function () {
    if (!this.baked) return;
    var spec = this.rt.spec, tm = this.ss._tilemap, camX = Math.ceil(tm.origin.x), camY = Math.ceil(tm.origin.y);
    var W = Graphics.width, H = Graphics.height, cx = W / 2, cy = H / 2, i, s;
    this.t++;
    var rad = spec.wind * Math.PI / 180, wx = Math.cos(rad), wy = Math.sin(rad), sp = spec.windSpeed;
    this.drift += sp * 0.25;
    this.updateSky(false);
    this.stars.origin.x = camX * DEPTH.stars; this.stars.origin.y = camY * DEPTH.stars;
    for (i = 0; i < this.isles.length; i++) { s = this.isles[i]; s.x = (s._aloftWX - camX - cx) * DEPTH.isles + cx; s.y = (s._aloftWY - camY - cy) * DEPTH.isles + cy; }
    this.far.origin.x = camX * DEPTH.far - wx * this.drift * 0.5; this.far.origin.y = camY * DEPTH.far - wy * this.drift * 0.5;
    this.near.origin.x = camX * DEPTH.near - wx * this.drift; this.near.origin.y = camY * DEPTH.near - wy * this.drift;
    for (i = 0; i < this.shadows.length; i++) {
      s = this.shadows[i];
      s.scale.x = s.scale.y = 0.92;
      s.x = (s._aloftWX - camX - cx) * DEPTH.shadow + cx + 70; s.y = (s._aloftWY - camY - cy) * DEPTH.shadow + cy + 90;
    }
    if (this.flash) {
      if (this.flashT > 0) { this.flashT--; this.flash.alpha = (this.flashT % 7 < 3) ? this.flashT / 70 : this.flashT / 160; }
      else { this.flash.alpha = 0; if (this.flashRng.next() < 0.004) this.flashT = 22; }
    }
    for (i = 0; i < this.wisps.length; i++) {
      s = this.wisps[i];
      s._aloftX += wx * sp * 0.55; s._aloftY += wy * sp * 0.55;
      var px = (s._aloftX - camX * DEPTH.wisp) % (W + 320), py = (s._aloftY - camY * DEPTH.wisp) % (H + 200);
      s.x = (px < 0 ? px + W + 320 : px) - 160; s.y = (py < 0 ? py + H + 200 : py) - 100;
    }
    for (i = 0; i < this.parts.length; i++) { s = this.parts[i]; s.x = s._aloftWX - camX; s.y = s._aloftWY - camY; }
    for (i = 0; i < this.anim.length; i++) {
      s = this.anim[i];
      if (s._aloftKind === 'water') s.origin.y -= 3.2;
      else if (s._aloftKind === 'prop') s.rotation += 0.06 * (0.5 + sp * 0.5);
    }
    for (i = 0; i < this.glows.length; i++) { s = this.glows[i]; s.alpha = 0.45 + 0.35 * Math.sin(this.t * 0.05 + s._aloftPh); }
    for (i = 0; i < this.streaks.length; i++) {
      s = this.streaks[i];
      s._aloftLife += 0.006 + sp * 0.002;
      if (s._aloftLife >= 1) { s._aloftLife -= 1; s._aloftX = (s._aloftX * 7.13 + 97) % W; s._aloftY = (s._aloftY * 3.71 + 211) % H; }
      s.rotation = rad; s.x = s._aloftX + wx * s._aloftLife * 220; s.y = s._aloftY + wy * s._aloftLife * 220;
      s.alpha = sp > 0 ? Math.sin(s._aloftLife * Math.PI) * 0.45 : 0;
    }
    for (i = 0; i < this.motes.length; i++) {
      s = this.motes[i];
      s._aloftX += wx * sp * 1.4 * s._aloftSp + Math.sin(this.t * 0.03 + s._aloftPh) * 0.4;
      s._aloftY += wy * sp * 1.4 * s._aloftSp + Math.cos(this.t * 0.025 + s._aloftPh) * 0.35 + (spec.dressing === 'storm' ? 3.5 : 0.15);
      if (s._aloftX < -20) s._aloftX += W + 40; else if (s._aloftX > W + 20) s._aloftX -= W + 40;
      if (s._aloftY < -20) s._aloftY += H + 40; else if (s._aloftY > H + 20) s._aloftY -= H + 40;
      s.x = s._aloftX; s.y = s._aloftY; s.rotation = spec.dressing === 'storm' ? 0 : this.t * 0.02 + s._aloftPh;
    }
  };

  AloftLayer.prototype.destroy = function () {
    this.baked = false;
    if (this.back.parent) this.back.parent.removeChild(this.back);
    if (this.front.parent) this.front.parent.removeChild(this.front);
  };

  /* ------------------------------------------------------ Spriteset_Map --*/
  var _Spriteset_Map_createLowerLayer = Spriteset_Map.prototype.createLowerLayer;
  Spriteset_Map.prototype.createLowerLayer = function () {
    _Spriteset_Map_createLowerLayer.apply(this, arguments);
    var rt = runtime();
    this._csafAloft = rt ? new AloftLayer(this, rt) : null;
  };
  var _Spriteset_Map_update = Spriteset_Map.prototype.update;
  Spriteset_Map.prototype.update = function () {
    _Spriteset_Map_update.apply(this, arguments);
    if (this._csafAloft) this._csafAloft.update();
  };
  var _Spriteset_Map_destroy = Spriteset_Map.prototype.destroy;
  Spriteset_Map.prototype.destroy = function () {
    if (this._csafAloft) { this._csafAloft.destroy(); this._csafAloft = null; }
    _Spriteset_Map_destroy.apply(this, arguments);
  };
  var _Scene_Map_start = Scene_Map.prototype.start;
  Scene_Map.prototype.start = function () {
    _Scene_Map_start.apply(this, arguments);
    if (this._spriteset && this._spriteset._csafAloft) this._spriteset._csafAloft.bake();
  };
  /** rebuild the layer in place (a command changed the dressing, the wind or the cover) */
  function rebuild() {
    var sc = SceneManager._scene;
    if ($gameMap && $gameMap._csafAloftRt) $gameMap._csafAloftRt = null;
    if (!sc || !(sc instanceof Scene_Map) || !sc._spriteset) return;
    var ss = sc._spriteset;
    if (ss._csafAloft) { ss._csafAloft.destroy(); ss._csafAloft = null; }
    ss._tilemap.setData($gameMap.width(), $gameMap.height(), $gameMap.data());
    var rt = runtime();
    if (rt) { ss._csafAloft = new AloftLayer(ss, rt); ss._csafAloft.bake(); }
  }

  /* ----------------------------------------------------------- the fall --*/
  function fallState(ch) { return ch && ch._csafAloftFall ? ch._csafAloftFall : null; }
  function startFall(ch, transfer) {
    var d = ch.direction(), dx = d === 6 ? 1 : (d === 4 ? -1 : 0), dy = d === 2 ? 1 : (d === 8 ? -1 : 0);
    Object.defineProperty(ch, '_csafAloftFall', { value: { phase: 0, t: 0, transfer: transfer }, writable: true, enumerable: false, configurable: true });
    ch.jump(dx, dy);
  }
  var _Game_CharacterBase_update = Game_CharacterBase.prototype.update;
  Game_CharacterBase.prototype.update = function () {
    _Game_CharacterBase_update.apply(this, arguments);
    var f = fallState(this);
    if (!f) return;
    if (f.phase === 0) { if (!this.isJumping()) f.phase = 1; return; }
    if (f.phase === 1) {
      f.t++;
      if (f.t >= FALL_FRAMES) {
        f.phase = 2;
        if (this === $gamePlayer) {
          if (f.transfer && f.transfer.mapId > 0) { $gamePlayer.reserveTransfer(f.transfer.mapId, f.transfer.x, f.transfer.y, 2, 0); }
          else this.setTransparent(true);
        } else if (this.erase) this.erase();
        this._csafAloftFall = null;
      }
    }
  };
  var _Game_CharacterBase_screenY = Game_CharacterBase.prototype.screenY;
  Game_CharacterBase.prototype.screenY = function () {
    var y = _Game_CharacterBase_screenY.apply(this, arguments), f = fallState(this);
    /* seen from above, a fall RECEDES: a short drop on screen while the figure shrinks into the clouds (MEASURED by
     * looking 2026-10-27: a 0.11*t^2 drop slid the figure off the bottom of the screen in ten frames) */
    /* ...and it must still drop PAST the keel into the clouds: 70 px left the figure fading on the rock face (fresh
     * review, 2026-10-27); 230 px carries it below a three-tile keel */
    if (f && f.phase === 1) y += 230 * Math.pow(f.t / FALL_FRAMES, 1.35);
    return y;
  };
  var _Sprite_Character_updateOther = Sprite_Character.prototype.updateOther;
  Sprite_Character.prototype.updateOther = function () {
    _Sprite_Character_updateOther.apply(this, arguments);
    var f = this._character ? fallState(this._character) : null;
    if (f && f.phase === 1) {
      var k = f.t / FALL_FRAMES;
      this.scale.x = this.scale.y = 1 - 0.72 * Math.pow(k, 0.9);
      this.opacity = Math.round(this.opacity * (k < 0.7 ? 1 : 1 - (k - 0.7) / 0.3));
      this._csafAloftScaled = true;
    } else if (this._csafAloftScaled) { this.scale.x = this.scale.y = 1; this._csafAloftScaled = false; }
  };
  var _Game_Interpreter_updateWaitMode = Game_Interpreter.prototype.updateWaitMode;
  Game_Interpreter.prototype.updateWaitMode = function () {
    if (this._waitMode === 'csafAloftFall') {
      if (this._csafAloftChar && fallState(this._csafAloftChar)) return true;
      this._waitMode = ''; this._csafAloftChar = null;
      return false;
    }
    return _Game_Interpreter_updateWaitMode.apply(this, arguments);
  };

  /* ------------------------------------------------------------ commands --*/
  PluginManager.registerCommand(PLUGIN, 'setEnabled', function (args) {
    slot().enabled = String(args.on) !== 'false';
    rebuild();
  });
  PluginManager.registerCommand(PLUGIN, 'setDressing', function (args) {
    var K = deps().AloftCore, d = String(args.dressing || '').trim();
    if (!K.DRESSINGS[d]) return;
    slot().dressing[$gameMap.mapId()] = d;
    rebuild();
  });
  PluginManager.registerCommand(PLUGIN, 'setWind', function (args) {
    var s = slot();
    s.wind = ((Math.round(pnum(args.direction, 15)) % 360) + 360) % 360;
    s.speed = Math.max(0, Math.min(4, pnum(args.speed, 1)));
    var rt = runtime(); if (rt) { rt.spec.wind = s.wind; rt.spec.windSpeed = s.speed; }
  });
  PluginManager.registerCommand(PLUGIN, 'setClouds', function (args) {
    slot().clouds = Math.max(0, Math.min(100, pnum(args.cover, 70)));
    rebuild();
  });
  PluginManager.registerCommand(PLUGIN, 'fall', function (args) {
    var id = Math.round(pnum(args.character, -1));
    var ch = id < 0 ? $gamePlayer : (id === 0 ? $gameMap.event(this._eventId) : $gameMap.event(id));
    if (!ch) return;
    var mapId = Math.round(pnum(args.mapId, 0));
    startFall(ch, ch === $gamePlayer && mapId > 0 ? { mapId: mapId, x: Math.round(pnum(args.x, 0)), y: Math.round(pnum(args.y, 0)) } : null);
    if (String(args.wait) !== 'false') { this._csafAloftChar = ch; this.setWaitMode('csafAloftFall'); }
  });
  /* --------------------------------------------------------------- API --*/
  globalThis.CSAF.Aloft = {
    VERSION: '1.0.0', DEFAULTS: DEFAULTS,
    runtime: runtime, layer: function () { var sc = SceneManager._scene; return sc && sc._spriteset ? sc._spriteset._csafAloft || null : null; },
    isVoid: function (x, y) { var rt = runtime(); return !!rt && isVoid(rt, x, y); },
    setEnabled: function (on) { slot().enabled = !!on; rebuild(); },
    setDressing: function (d) { if (!deps().AloftCore.DRESSINGS[d]) return false; slot().dressing[$gameMap.mapId()] = d; rebuild(); return true; },
    setWind: function (deg, speed) { var s = slot(); s.wind = ((Math.round(deg) % 360) + 360) % 360; s.speed = Math.max(0, Math.min(4, speed)); var rt = runtime(); if (rt) { rt.spec.wind = s.wind; rt.spec.windSpeed = s.speed; } },
    setClouds: function (c) { slot().clouds = Math.max(0, Math.min(100, c)); rebuild(); },
    fall: function (ch, transfer) { startFall(ch, transfer || null); },
    isFalling: function (ch) { return !!fallState(ch); },
    rebuild: rebuild, drawTileInto: drawTileInto,
    _setSeedForTest: function (s) { testSeed = s === null ? null : (s >>> 0); if ($gameMap && $gameMap._csafAloftRt) $gameMap._csafAloftRt = null; }
  };
})();
