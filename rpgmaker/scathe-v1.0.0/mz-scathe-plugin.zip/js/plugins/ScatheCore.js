/*:
 * @target MZ
 * @plugindesc Scathe 1/2 - the damage: generated from each enemy's own battler pixels, by element, HP band and material. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ScatheCore.js - part of Scathe v1.0.0. Enable it with Scathe.js (any order). It has no commands or parameters of its
 * own; Scathe.js reads it.
 *
 * Every line of this plugin was written with AI assistance.
 */
/*
 * The whole picture as PURE pixel operations on an RGBA buffer, so it runs in Node on real battler PNGs exactly as it
 * runs in MZ. Never Math.random: a seeded generator whose state is a number. Every mark is clipped to the battler's own
 * alpha mask, and every ink is derived from the pixels it lands on (never a hard-coded ink).
 */
var ScatheCore = (function () {
  'use strict';

  /* ------------------------------------------------------------ seeded randomness */
  function mix(a, b) { var h = Math.imul((a >>> 0) ^ 0x9e3779b9, 0x85ebca6b) ^ (b >>> 0); h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35); return (h ^ (h >>> 16)) >>> 0; }
  /** mulberry32 with its state on the object, so a saved state reproduces the same marks */
  function rand(r) { var t = r.s = (r.s + 0x6D2B79F5) | 0; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }
  function hash2(x, y, s) { var h = Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263) ^ Math.imul(s | 0, 2246822519); h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; }
  /** smooth value noise in [0,1] at scale `sc` px */
  function noise(x, y, sc, s) {
    var fx = x / sc, fy = y / sc, ix = Math.floor(fx), iy = Math.floor(fy), tx = fx - ix, ty = fy - iy;
    tx = tx * tx * (3 - 2 * tx); ty = ty * ty * (3 - 2 * ty);
    var a = hash2(ix, iy, s), b = hash2(ix + 1, iy, s), c = hash2(ix, iy + 1, s), d = hash2(ix + 1, iy + 1, s);
    return a + (b - a) * tx + (c - a) * ty + (a - b - c + d) * tx * ty;
  }

  /* ------------------------------------------------------------ analysis (once per battler, at battle start) */
  var ALPHA_IN = 32, SHADOW_ALPHA = 230, SHADOW_LUM = 20;
  /**
   * @param {Uint8Array|Uint8ClampedArray|Buffer} px RGBA
   * @returns {{w:number,h:number,mask:Uint8Array,dist:Float32Array,lum:Float32Array,bbox:Object,area:number,px:number}}
   */
  function analyse(px, w, h) {
    var n = w * h, mask = new Uint8Array(n), lum = new Float32Array(n), dist = new Float32Array(n), area = 0;
    var x0 = w, y0 = h, x1 = -1, y1 = -1, i, x, y;
    for (i = 0; i < n; i++) {
      var o = i * 4;
      lum[i] = 0.2126 * px[o] + 0.7152 * px[o + 1] + 0.0722 * px[o + 2];
      // a battler's painted ground SHADOW is semi-transparent and near-black (MEASURED on six stock enemies,
      // _probe/shadow_probe.js: alpha < 230 with luminance < 20 sits in the bottom 15% of the bbox, Goblin 791 vs 36 in the
      // body, Dragon 6,731 vs 428): it is not the creature, so damage never lands on it
      if (px[o + 3] > ALPHA_IN && !(px[o + 3] < SHADOW_ALPHA && lum[i] < SHADOW_LUM)) { mask[i] = 1; area++; x = i % w; y = (i / w) | 0; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    }
    // chamfer distance (1, 1.414) to the nearest outside pixel, inside the mask only
    var BIG = 1e6;
    for (i = 0; i < n; i++) dist[i] = mask[i] ? BIG : 0;
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) {
      i = y * w + x; if (!mask[i]) continue;
      var d = dist[i];
      d = Math.min(d, x > 0 ? dist[i - 1] + 1 : 1, y > 0 ? dist[i - w] + 1 : 1, x > 0 && y > 0 ? dist[i - w - 1] + 1.414 : 1.414, x < w - 1 && y > 0 ? dist[i - w + 1] + 1.414 : 1.414);
      dist[i] = d;
    }
    for (y = h - 1; y >= 0; y--) for (x = w - 1; x >= 0; x--) {
      i = y * w + x; if (!mask[i]) continue;
      var e = dist[i];
      e = Math.min(e, x < w - 1 ? dist[i + 1] + 1 : 1, y < h - 1 ? dist[i + w] + 1 : 1, x < w - 1 && y < h - 1 ? dist[i + w + 1] + 1.414 : 1.414, x > 0 && y < h - 1 ? dist[i + w - 1] + 1.414 : 1.414);
      dist[i] = e;
    }
    return { w: w, h: h, mask: mask, dist: dist, lum: lum, bbox: { x: x0, y: y0, w: x1 - x0 + 1, h: y1 - y0 + 1 }, area: area, px: pixelScale(px, w, h, mask) };
  }
  /**
   * The native pixel size of the art: pixel art upscaled 2x or 3x repeats each colour in runs of 2 or 3, painted art
   * does not. The modal horizontal run length among opaque runs, 1..6 (wing §17c-1: damage drawn at the art's scale).
   */
  function pixelScale(px, w, h, mask) {
    var hist = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], y, x, r;
    for (y = 0; y < h; y += 2) {
      var run = 0, prev = -1;
      for (x = 0; x < w; x++) {
        var i = y * w + x, o = i * 4, key = mask[i] ? (px[o] << 16 | px[o + 1] << 8 | px[o + 2]) : -2;
        if (key === prev && key !== -2) run++; else { if (prev !== -2 && prev !== -1 && run > 0 && run <= 12) hist[run]++; run = 1; prev = key; }
      }
    }
    // a true 2x/3x/4x upscale has (almost) no runs of 1, and every run is a multiple of the scale. MEASURED 2026-10-11
    // (docs.test.js): the first version kept the SMALLEST scale on a tie and counted runs only up to 6, so 4x art (runs of
    // 4 and 8, all also multiples of 2) read as 2x. The largest scale that divides nearly every run wins
    var total = 0;
    for (r = 1; r <= 12; r++) total += hist[r];
    if (total < 20) return 1;
    if (hist[1] / total > 0.25) return 1;
    for (var s = 4; s >= 2; s--) { var sc = 0; for (r = 1; r <= 12; r++) if (r % s === 0) sc += hist[r]; if (sc / total > 0.85) return s; }
    return 1;
  }

  /* ------------------------------------------------------------ pixel helpers (all clipped to the mask) */
  /**
   * The DIRTY RECTANGLE of the hits being applied: every write below widens it, so the bake copies (and the plugin
   * uploads) only what changed. MEASURED 2026-10-11 (_probe/bake_split.js, gate_trio_autohit): copying the whole image on
   * every hit cost 0.6-2 ms in Node on the demo battlers and the trio's gate read update p99 4.9-7.7 ms, NOT CLEAN.
   * core.test compares the incremental picture with a full bake over the WHOLE image, so a write the rectangle missed
   * fails it.
   */
  var DX0 = 0, DY0 = 0, DX1 = -1, DY1 = -1;
  function dirtyReset() { DX0 = 1e9; DY0 = 1e9; DX1 = -1; DY1 = -1; }
  function touch(x0, y0, x1, y1) { if (x0 < DX0) DX0 = x0; if (y0 < DY0) DY0 = y0; if (x1 > DX1) DX1 = x1; if (y1 > DY1) DY1 = y1; }
  function put(out, A, x, y, r, g, b, a) {
    x |= 0; y |= 0;
    if (x < 0 || y < 0 || x >= A.w || y >= A.h || a <= 0) return;
    var i = y * A.w + x; if (!A.mask[i]) return;
    var o = i * 4, k = a > 1 ? 1 : a;
    if (x < DX0) DX0 = x; if (y < DY0) DY0 = y; if (x > DX1) DX1 = x; if (y > DY1) DY1 = y;
    out[o] = out[o] + (r - out[o]) * k; out[o + 1] = out[o + 1] + (g - out[o + 1]) * k; out[o + 2] = out[o + 2] + (b - out[o + 2]) * k;
  }
  /** a disc of radius rr (anti-aliased edge) in native pixel blocks */
  function dab(out, A, cx, cy, rr, colFn, alpha) {
    var s = A.px, r = Math.max(0.5, rr), x0 = Math.floor(cx - r - 1), x1 = Math.ceil(cx + r + 1), y0 = Math.floor(cy - r - 1), y1 = Math.ceil(cy + r + 1);
    if (s === 1) {
      // painted art (native scale 1): the same disc, the same arithmetic in the same order as the block path below (so the
      // same bytes), without the per-pixel block loops, bounds re-checks and sqrt outside the disc
      var W = A.w, Hh = A.h, mask = A.mask, rr2 = (r + 0.5) * (r + 0.5);
      if (x0 < 0) x0 = 0; if (y0 < 0) y0 = 0; if (x1 > W - 1) x1 = W - 1; if (y1 > Hh - 1) y1 = Hh - 1;
      if (x1 < x0 || y1 < y0) return;
      touch(x0, y0, x1, y1);
      for (var fy = y0; fy <= y1; fy++) {
        var fdy = fy + 0.5 - cy, fdy2 = fdy * fdy, row = fy * W;
        for (var fx = x0; fx <= x1; fx++) {
          var fdx = fx + 0.5 - cx, d2 = fdx * fdx + fdy2;
          if (d2 >= rr2) continue;
          var fi = row + fx; if (!mask[fi]) continue;
          var fcov = r + 0.5 - Math.sqrt(d2); if (fcov > 1) fcov = 1;
          var fk = alpha * fcov; if (fk <= 0) continue; if (fk > 1) fk = 1;
          var fc = colFn(fx, fy), fo = fi * 4;
          out[fo] = out[fo] + (fc[0] - out[fo]) * fk; out[fo + 1] = out[fo + 1] + (fc[1] - out[fo + 1]) * fk; out[fo + 2] = out[fo + 2] + (fc[2] - out[fo + 2]) * fk;
        }
      }
      return;
    }
    for (var y = y0; y <= y1; y += s) for (var x = x0; x <= x1; x += s) {
      var bx = Math.floor(x / s) * s, by = Math.floor(y / s) * s, dx = bx + s / 2 - cx, dy = by + s / 2 - cy, d = Math.sqrt(dx * dx + dy * dy);
      var cov = Math.max(0, Math.min(1, r + 0.5 - d));
      if (cov <= 0) continue;
      for (var yy = 0; yy < s; yy++) for (var xx = 0; xx < s; xx++) {
        var X = bx + xx, Y = by + yy; if (X < 0 || Y < 0 || X >= A.w || Y >= A.h) continue;
        var c = colFn(X, Y); put(out, A, X, Y, c[0], c[1], c[2], alpha * cov);
      }
    }
  }
  function lumAt(A, x, y) { x = Math.max(0, Math.min(A.w - 1, x | 0)); y = Math.max(0, Math.min(A.h - 1, y | 0)); return A.lum[y * A.w + x]; }
  function inside(A, x, y) { x |= 0; y |= 0; return x >= 0 && y >= 0 && x < A.w && y < A.h && A.mask[y * A.w + x] === 1; }
  /** the nearest inside point to (x,y), walking toward the bbox centre */
  function snapInside(A, x, y) {
    var cx = A.bbox.x + A.bbox.w / 2, cy = A.bbox.y + A.bbox.h / 2;
    for (var t = 0; t <= 1.0001; t += 0.02) { var px = x + (cx - x) * t, py = y + (cy - y) * t; if (inside(A, px, py)) return { x: px, y: py }; }
    return { x: cx, y: cy };
  }
  /** derived inks: a dark core and a lit lip relative to the pixels underneath (Icon_Doctrine §22e) */
  /** the one triple every ink writes into (an ink is read once by put() before the next call) */
  var INK = [0, 0, 0];
  function ink(r, g, b) { INK[0] = r; INK[1] = g; INK[2] = b; return INK; }
  function darkInk(A, tint) { return function (x, y) { var l = lumAt(A, x, y), k = 0.18 + l / 255 * 0.12; return ink(tint[0] * k, tint[1] * k, tint[2] * k); }; }
  function litInk(A, tint) { return function (x, y) { var l = lumAt(A, x, y), v = Math.min(255, l * 1.35 + 55); return ink(v * tint[0] / 255, v * tint[1] / 255, v * tint[2] / 255); }; }

  /* ------------------------------------------------------------ the families */
  /** an angle-persistent branching walk from (x,y): returns segments [{x0,y0,x1,y1,w}] that stay inside the mask */
  function walk(A, r, x, y, opts) {
    var segs = [], stack = [], s = A.px, size = Math.min(A.bbox.w, A.bbox.h);
    var arms = opts.arms, maxLen = opts.reach * size;
    for (var a = 0; a < arms; a++) stack.push({ x: x, y: y, ang: (a / arms) * Math.PI * 2 + rand(r) * 1.2, w: opts.w0, len: 0, depth: 0 });
    var guard = 0;
    while (stack.length && guard++ < 4000) {
      var b = stack.pop(), step = Math.max(1.5, s * 1.5);
      while (b.len < maxLen * (1 - b.depth * 0.3)) {
        b.ang += (rand(r) - 0.5) * opts.jitter;
        var nx = b.x + Math.cos(b.ang) * step, ny = b.y + Math.sin(b.ang) * step;
        if (!inside(A, nx, ny) || A.dist[(ny | 0) * A.w + (nx | 0)] < 1.2) break;
        segs.push({ x0: b.x, y0: b.y, x1: nx, y1: ny, w: Math.max(0.5, b.w * (1 - b.len / maxLen)), d: b.depth });
        b.x = nx; b.y = ny; b.len += step;
        if (b.depth < opts.depth && rand(r) < opts.fork) stack.push({ x: nx, y: ny, ang: b.ang + (rand(r) < 0.5 ? -1 : 1) * (0.5 + rand(r) * 0.6), w: b.w * 0.65, len: b.len, depth: b.depth + 1 });
      }
    }
    return segs;
  }
  function strokeSegs(out, A, segs, colFn, alpha, widen, ox, oy) {
    for (var k = 0; k < segs.length; k++) {
      // stamps spaced by the brush's own radius (MEASURED 2026-10-10: a fixed 0.6 px spacing overdrew a 3.6 px halo
      // dozens of times and a blight hit cost ~4 ms on a goblin, which the frame gate's p99 caught)
      var g = segs[k], dx = g.x1 - g.x0, dy = g.y1 - g.y0, L = Math.sqrt(dx * dx + dy * dy), rad = g.w * (widen || 1) * 0.5 * A.px;
      var n = Math.max(1, Math.ceil(L / Math.max(0.6, rad * 0.6, A.px * 0.5)));
      for (var j = 0; j <= n; j++) dab(out, A, g.x0 + dx * j / n + (ox || 0), g.y0 + dy * j / n + (oy || 0), rad, colFn, alpha);
    }
  }
  var FAM = {};
  /** crack: a branching network from the impact, a dark core with a lit lip, chips at the impact on hard materials */
  // LOOKED AT 2026-10-10 (contact sheet): 3-4 arms with jitter 0.9 read as ink scribbles, and a lip offset of 0.7 px sat
  // under the core. Fewer, straighter arms; the lit lip a full pixel up-left and wider than the core so it shows
  FAM.crack = function (out, A, hit, r, mat, orig) {
    var segs = walk(A, r, hit.x, hit.y, { arms: 2 + (rand(r) * 2 | 0), reach: 0.16 + hit.power * 0.24, jitter: 0.55, fork: 0.11, depth: 2, w0: 1.2 + hit.power * 1.1 });
    for (var k = 0; k < segs.length; k++) if (segs[k].d) segs[k].w *= Math.pow(0.65, segs[k].d);
    // LOOKED AT 2026-10-11 on the painted cast: a lit lip at alpha 0.7, 1.5x wide, read as a white SHEATH round a black
    // wire, and without it a near-black core read as a wire laid ON the body. A crack is the material's OWN colour in
    // shadow: a soft darkened band of the local colour, a deep core of the same hue, and a faint lip on the far edge
    var at = function (x, y) { return ((y | 0) * A.w + (x | 0)) * 4; };
    strokeSegs(out, A, segs, function (x, y) { var i = at(x, y); return ink(orig[i] * 0.62, orig[i + 1] * 0.6, orig[i + 2] * 0.6); }, 0.4, 2.2, A.px * 0.4, A.px * 0.5);
    strokeSegs(out, A, segs, function (x, y) { var l = lumAt(A, x, y), v = Math.min(255, l * 1.12 + 30); return ink(v, v * 0.97, v * 0.92); }, 0.4, 0.95, -A.px * 0.8, -A.px * 0.8);
    // LOOKED AT 2026-10-11 on black plate armour and a dark beetle shell: a dark core on a near-black surface has no
    // contrast and the crack vanished (wing §21b). Where the surface is dark the crack EXPOSES the material's bare
    // interior instead (bright steel, pale chitin, raw stone), so the mark reads on any surface
    var bare = mat.bare;
    strokeSegs(out, A, segs, function (x, y) {
      var i = at(x, y), v = Math.max(orig[i], orig[i + 1], orig[i + 2]), t = bare ? Math.max(0, Math.min(1, (DARK - v) / 30)) : 0;
      var dr = orig[i] * 0.22 + mat.core[0] * 0.1, dg = orig[i + 1] * 0.2 + mat.core[1] * 0.1, db = orig[i + 2] * 0.2 + mat.core[2] * 0.1;
      // blended, never switched, so a crack crossing from a lit plate onto a black one does not flip colour mid-line
      if (t > 0) { var k = 0.7 + 0.3 * v / DARK; dr += (bare[0] * k - dr) * t; dg += (bare[1] * k - dg) * t; db += (bare[2] * k - db) * t; }
      return ink(dr, dg, db); }, 0.92, 0.85, 0, 0);
    if (mat.chips) {
      // a chipped crater at the impact: a dark pit with a lit rim on the far side
      dab(out, A, hit.x - A.px, hit.y - A.px, (1.6 + hit.power * 1.6) * A.px, litInk(A, [255, 240, 220]), 0.6);
      dab(out, A, hit.x, hit.y, (1.3 + hit.power * 1.4) * A.px, darkInk(A, mat.core), 0.9);
    }
  };
  /** cut: a gash across the silhouette through the impact: lifted lit lip above, a dark wound core, a soft shadow below */
  FAM.cut = function (out, A, hit, r, mat) {
    var ang = -0.5 + rand(r) * 1.0 + (rand(r) < 0.5 ? 0 : Math.PI), len = (0.22 + hit.power * 0.28) * Math.min(A.bbox.w, A.bbox.h);
    var segs = [], n = 14, x = hit.x - Math.cos(ang) * len / 2, y = hit.y - Math.sin(ang) * len / 2;
    // LOOKED AT 2026-10-10: a straight gash of one smooth width read as ruled. A blade drags: the line bows a little to
    // one side (perpendicular offset, peak mid-gash), and the width is torn, a seeded factor per segment smoothed with
    // its neighbour so it reads ragged rather than dotted
    var nx = -Math.sin(ang), ny = Math.cos(ang), bow = (rand(r) - 0.5) * 0.24 * len, tear = 1;
    var px0 = x, py0 = y, lip = [], drips = [];
    for (var i = 0; i < n; i++) {
      // LOOKED AT 2026-10-10: at 1.4-3.0 px the gash was a thin dark line; a gash is wide in the middle and tapers
      // LOOKED AT 2026-10-11 on the painted cast: four full-length parallel strokes (shadow, lip, wound, seam) of one
      // smooth width read as a striped ribbon laid ON the body. A wound is a LENS (sharp ends, open middle), its lip catches
      // light only in broken stretches, and on flesh it runs
      var t0 = i / n, t1 = (i + 1) / n;
      tear = tear * 0.45 + (0.55 + rand(r) * 0.9) * 0.55;
      var wv = 0.4 + Math.pow(Math.sin(Math.PI * (t0 + t1) / 2), 1.6) * (2.4 + hit.power * 2.8) * tear;
      var b1 = bow * 4 * t1 * (1 - t1), px1 = x + Math.cos(ang) * len * t1 + nx * b1, py1 = y + Math.sin(ang) * len * t1 + ny * b1;
      var sg = { x0: px0, y0: py0, x1: px1, y1: py1, w: wv };
      segs.push(sg);
      if (rand(r) < 0.6) lip.push(sg);
      if (mat.drips && i > 2 && i < n - 3 && rand(r) < 0.22 && drips.length < 3) drips.push({ x: (px0 + px1) / 2, y: (py0 + py1) / 2, w: wv });
      px0 = px1; py0 = py1;
    }
    var wound = mat.wound, core = mat.core;
    // a soft bruise round the whole wound, the open wound (dark at its deepest), a wet glint inside, a broken lit lip
    strokeSegs(out, A, segs, function (X, Y) { var l = lumAt(A, X, Y), k = 0.55 + l / 255 * 0.15; return ink(l * k * 0.9, l * k * 0.62, l * k * 0.62); }, 0.32, 2.4, 0, A.px * 0.6);
    strokeSegs(out, A, segs, function (X, Y) { var l = lumAt(A, X, Y), k = 0.45 + l / 255 * 0.25; return ink(wound[0] * k, wound[1] * k, wound[2] * k); }, 1.0, 0.95, 0, 0);
    strokeSegs(out, A, segs, function () { return ink(core[0] * 0.6, core[1] * 0.6, core[2] * 0.6); }, 0.85, 0.45, 0, -A.px * 0.3);
    strokeSegs(out, A, segs, function () { return ink(Math.min(255, wound[0] * 1.5 + 40), wound[1] * 1.3 + 30, wound[2] * 1.3 + 30); }, 0.5, 0.18, A.px * 0.4, A.px * 0.7);
    // the lip is the edge facing the light (up the image), whichever way the blade travelled
    var up = ny > 0 ? -1 : 1;
    // (2026-10-11: on a pale belly a lip at l * 1.12 + 28 went pure white and read as a white line drawn beside the cut)
    strokeSegs(out, A, lip, function (X, Y) { var l = lumAt(A, X, Y), v = Math.min(240, l * 1.06 + 18); return ink(v, v * 0.94, v * 0.9); }, 0.38, 0.5, up * nx * A.px * 1.1, up * ny * A.px * 1.1 - A.px * 0.4);
    // flesh bleeds: short runs straight DOWN the image from the lower edge, tapering, each its own length
    for (var dk = 0; dk < drips.length; dk++) {
      var dp = drips[dk], dl = (4 + rand(r) * 10) * (0.6 + hit.power) * A.px, dseg = [], steps = 6;
      for (var s2 = 0; s2 < steps; s2++) dseg.push({ x0: dp.x + Math.sin(s2 * 1.7 + dk) * 0.3, y0: dp.y + dp.w * 0.4 + dl * s2 / steps, x1: dp.x + Math.sin((s2 + 1) * 1.7 + dk) * 0.3, y1: dp.y + dp.w * 0.4 + dl * (s2 + 1) / steps, w: Math.max(0.6, 1.5 * (1 - s2 / steps) + 0.5) });
      strokeSegs(out, A, dseg, function (X, Y) { var l = lumAt(A, X, Y), k = 0.5 + l / 255 * 0.25; return ink(wound[0] * k, wound[1] * k, wound[2] * k); }, 0.9, 1.0, 0, 0);
    }
  };
  /** scorch: char inward from the impact and from the nearest outline, with ember glints in the char */
  // LOOKED AT 2026-10-10 (contact sheet): a wide speckled field with an ember on 5% of its pixels read as glitter on
  // dirt, and at band 3 it covered half a dragon. A tighter, smoothly ragged burn: black-brown char in the middle, a
  // warm smouldering rim where the char thins out, embers only along that rim and rare
  FAM.scorch = function (out, A, hit, r, mat) {
    // LOOKED AT in engine 2026-10-10: at 0.11 + 0.14p a goblin's torso went one flat black; smaller, and the char keeps a
    // quarter of the texture under it
    var R = (0.07 + hit.power * 0.1) * Math.min(A.bbox.w, A.bbox.h), s = A.px, seed = hit.seed | 0;
    var x0 = Math.max(0, Math.floor(hit.x - R * 1.6)), x1 = Math.min(A.w - 1, Math.ceil(hit.x + R * 1.6)), y0 = Math.max(0, Math.floor(hit.y - R * 1.6)), y1 = Math.min(A.h - 1, Math.ceil(hit.y + R * 1.6));
    touch(x0, y0, x1, y1);
    for (var y = y0; y <= y1; y++) for (var x = x0; x <= x1; x++) {
      var i = y * A.w + x; if (!A.mask[i]) continue;
      var bx = Math.floor(x / s), by = Math.floor(y / s), dx = x - hit.x, dy = y - hit.y, d = Math.sqrt(dx * dx + dy * dy);
      var nz = noise(bx * s, by * s, Math.max(4, R * 0.6), seed) * 0.7 + noise(bx * s, by * s, Math.max(2, R * 0.2), seed + 3) * 0.3;
      var c = 1 - d / (R * (0.7 + nz * 0.7));
      if (c <= -0.25) continue;
      var o = i * 4, l = A.lum[i];
      if (c > 0) {
        var k = Math.min(0.85, c * 2.2);
        var cr = 20 + out[o] * 0.22, cg = 13 + out[o + 1] * 0.16, cb = 10 + out[o + 2] * 0.12;
        out[o] += (cr - out[o]) * k; out[o + 1] += (cg - out[o + 1]) * k; out[o + 2] += (cb - out[o + 2]) * k;
      }
      // the smouldering rim: a warm orange where the char thins (c near 0), strongest just outside the char
      // LOOKED AT 2026-10-11 on a thin dark wing: a continuous rim with embers on 3% of it read as a dotted orange RING.
      // The smoulder is broken by its own noise (it glows in patches), and the few embers sit just inside the char edge
      var rim = Math.max(0, 1 - Math.abs(c) / 0.25) * Math.max(0, Math.min(1, noise(bx * s, by * s, Math.max(3, R * 0.3), seed + 17) * 1.8 - 0.35));
      if (rim > 0) { var q = rim * 0.55; out[o] += (230 - out[o]) * q; out[o + 1] += (110 - out[o + 1]) * q * 0.9; out[o + 2] += (30 - out[o + 2]) * q; }
      if (c > 0.02 && c < 0.3 && hash2(bx, by, seed + 7) < 0.005) { out[o] = 255; out[o + 1] = 200 + hash2(bx, by, seed) * 45; out[o + 2] = 80; }
    }
  };
  /** rime: needles of frost grown inward from the outline near the impact, a cool pale tint under them */
  FAM.rime = function (out, A, hit, r, mat) {
    var R = (0.2 + hit.power * 0.25) * Math.min(A.bbox.w, A.bbox.h), seeds = 8 + (hit.power * 10 | 0), tries = 0, done = 0, s = A.px;
    var x0 = Math.max(0, Math.floor(hit.x - R)), x1 = Math.min(A.w - 1, Math.ceil(hit.x + R)), y0 = Math.max(0, Math.floor(hit.y - R)), y1 = Math.min(A.h - 1, Math.ceil(hit.y + R));
    touch(x0, y0, x1, y1);
    for (var y = y0; y <= y1; y++) for (var x = x0; x <= x1; x++) {
      var i = y * A.w + x; if (!A.mask[i]) continue;
      // LOOKED AT 2026-10-10: a smooth tint covered up to 54% of a body for two hits and needles alone read as scratches.
      // Frost is a COAT: patchy (noise-thresholded), pale and cool, with sparse sparkles, inside a tighter radius
      var dx = x - hit.x, dy = y - hit.y, fall = 1 - Math.sqrt(dx * dx + dy * dy) / (R * 0.75);
      if (fall <= 0) continue;
      var bxr = Math.floor(x / s), byr = Math.floor(y / s), nzr = noise(bxr * s, byr * s, Math.max(3, R * 0.25), hit.seed | 0);
      // LOOKED AT 2026-10-11 on the painted cast: blending toward one flat pale colour erased the shading and read as a
      // splash of white paint. Frost keeps the form under it: the target is the pixel's OWN luminance pushed cool and
      // pale, so muscles and plates stay readable through the coat; a second, finer noise frosts the high spots whiter
      var f = Math.max(0, Math.min(1, (fall * 1.4 + nzr - 1.0) * 2.2)) * 0.78;
      if (f <= 0) continue;
      var o = i * 4, lo = 0.2126 * out[o] + 0.7152 * out[o + 1] + 0.0722 * out[o + 2];
      var hf = noise(bxr * s, byr * s, Math.max(2, R * 0.08), (hit.seed | 0) + 5), wh = hf > 0.62 ? (hf - 0.62) * 1.6 : 0;
      var tr = Math.min(255, lo * 0.72 + 52 + wh * 90), tg = Math.min(255, lo * 0.86 + 62 + wh * 80), tb = Math.min(255, lo * 0.92 + 88 + wh * 60);
      out[o] += (tr - out[o]) * f; out[o + 1] += (tg - out[o + 1]) * f; out[o + 2] += (tb - out[o + 2]) * f;
      if (f > 0.5 && hash2(bxr, byr, (hit.seed | 0) + 13) < 0.006) { out[o] = 255; out[o + 1] = 255; out[o + 2] = 255; }
    }
    // LOOKED AT in engine 2026-10-10: a needle with a symmetric branch pair read as a stamped snowflake glyph, and a fan
    // of needles from one point read as an arrowhead. Frost is MANY short needles from scattered points along the
    // outline, each its own length and angle around the inward direction
    // LOOKED AT 2026-10-11: 14-30 white ticks on the outline read as scratch marks; fewer, finer, blue-white
    seeds = 3 + (hit.power * 5 | 0);
    while (done < seeds && tries++ < 1500) {
      // the crystal fringe: only points ON the outline (within two native pixels of it), inside the coat's radius
      // (2026-10-11: needles out at 0.85 R landed past the coat and read as loose white dashes; they grow only where it is thick)
      var a = rand(r) * Math.PI * 2, rr = Math.sqrt(rand(r)) * R * 0.5, px0 = hit.x + Math.cos(a) * rr, py0 = hit.y + Math.sin(a) * rr;
      if (!inside(A, px0, py0) || A.dist[(py0 | 0) * A.w + (px0 | 0)] > 2 * s + 0.5) continue;
      var cxi = px0 | 0, cyi = py0 | 0;
      var gx = A.dist[cyi * A.w + Math.min(A.w - 1, cxi + 1)] - A.dist[cyi * A.w + Math.max(0, cxi - 1)];
      var gy = A.dist[Math.min(A.h - 1, cyi + 1) * A.w + cxi] - A.dist[Math.max(0, cyi - 1) * A.w + cxi];
      var inward = Math.atan2(gy, gx), len = (0.05 + hit.power * 0.07) * Math.min(A.bbox.w, A.bbox.h), segs = [], fan = rand(r) < 0.35 ? 2 : 1;
      for (var k = 0; k < fan; k++) {
        var ang = inward + (rand(r) - 0.5) * 1.0, L = len * (0.2 + rand(r) * 0.35), n = 4;
        for (var j = 0; j < n; j++) {
          var xa = px0 + Math.cos(ang) * L * j / n, ya = py0 + Math.sin(ang) * L * j / n, xb = px0 + Math.cos(ang) * L * (j + 1) / n, yb = py0 + Math.sin(ang) * L * (j + 1) / n;
          if (!inside(A, xb, yb)) break;
          segs.push({ x0: xa, y0: ya, x1: xb, y1: yb, w: 0.75 * (1 - j / n) + 0.2 });
        }
      }
      strokeSegs(out, A, segs, function () { return ink(110, 160, 205); }, 0.22, 1.1, A.px * 0.6, A.px * 0.6);
      strokeSegs(out, A, segs, function () { return ink(225, 242, 255); }, 0.6, 1.0, 0, 0);
      done++;
    }
  };
  /** fork: a forked lightning burn: zigzag with sharp turns, a dark burnt core and a pale ionised edge */
  // LOOKED AT in engine 2026-10-10: a zigzag with a white outline read as a doodle drawn on the face. A lightning burn
  // is a Lichtenberg figure: a fern of fine branches spreading from the strike, burnt dark red-brown, under a faint cool
  // glow, never outlined
  FAM.fork = function (out, A, hit, r, mat) {
    // LOOKED AT 2026-10-11 on a 540 px boss at power 1: fork 0.3 to depth 3 grew a dense tangle across the whole chest
    // that read as roots. Fewer, shallower fronds and a shorter reach, so the strike and its channel lead
    var segs = walk(A, r, hit.x, hit.y, { arms: 1 + (rand(r) * 2 | 0), reach: 0.2 + hit.power * 0.17, jitter: 0.85, fork: 0.16, depth: 2, w0: 1.2 + hit.power * 0.8 });
    // LOOKED AT 2026-10-11 on the painted cast: a uniform red-brown fern read as the SAME vein network as blight. A
    // lightning burn has a burnt ENTRY at the strike, channels that thin fast with each fork, and a hot pale line left in
    // the main channel; the fine fronds stay faint
    for (var k = 0; k < segs.length; k++) segs[k].w *= segs[k].d ? Math.pow(0.6, segs[k].d) : 1.25;
    var ER = (0.025 + hit.power * 0.025) * Math.min(A.bbox.w, A.bbox.h);
    // LOOKED AT 2026-10-11: a cream dot at the entry read as a bead stuck on, and a 0.7 white trunk as a line drawn on. The
    // entry is a charred pit with a hot orange ring; the trunk keeps only a faint cool glint
    // (2026-10-11, second look: three stacked discs read as a ring target) one soft radial burn: char in the middle that
    // keeps a fifth of the texture, an orange heat that fades out past it, both modulated by noise so the edge is ragged
    var ex0 = Math.max(0, Math.floor(hit.x - ER * 2.4)), ex1 = Math.min(A.w - 1, Math.ceil(hit.x + ER * 2.4)), ey0 = Math.max(0, Math.floor(hit.y - ER * 2.4)), ey1 = Math.min(A.h - 1, Math.ceil(hit.y + ER * 2.4));
    touch(ex0, ey0, ex1, ey1);
    for (var ey = ey0; ey <= ey1; ey++) for (var ex = ex0; ex <= ex1; ex++) {
      var ei = ey * A.w + ex; if (!A.mask[ei]) continue;
      var edx = ex - hit.x, edy = ey - hit.y, ed = Math.sqrt(edx * edx + edy * edy) / (ER * (0.8 + noise(ex, ey, Math.max(2, ER * 0.5), (hit.seed | 0) + 9) * 0.5));
      if (ed >= 2.2) continue;
      var eo = ei * 4, ch = ed < 1 ? Math.min(0.85, (1 - ed) * 2.2) : 0, ht = ed < 2.2 ? Math.max(0, 1 - Math.abs(ed - 1.05) / 1.1) * 0.5 : 0;
      if (ht > 0) { out[eo] += (240 - out[eo]) * ht; out[eo + 1] += (128 - out[eo + 1]) * ht * 0.9; out[eo + 2] += (44 - out[eo + 2]) * ht; }
      if (ch > 0) { out[eo] += (22 + out[eo] * 0.2 - out[eo]) * ch; out[eo + 1] += (15 + out[eo + 1] * 0.16 - out[eo + 1]) * ch; out[eo + 2] += (12 + out[eo + 2] * 0.12 - out[eo + 2]) * ch; }
    }
    strokeSegs(out, A, segs, function () { return ink(205, 225, 255); }, 0.2, 3.2, 0, 0);
    strokeSegs(out, A, segs, function (x, y) { var l = lumAt(A, x, y); return ink(38 + l * 0.16, 24 + l * 0.08, 22 + l * 0.08); }, 0.85, 0.9, 0, 0);
    var trunk = [];
    for (var t2 = 0; t2 < segs.length; t2++) if (!segs[t2].d) trunk.push(segs[t2]);
    strokeSegs(out, A, trunk, function () { return ink(214, 232, 255); }, 0.42, 0.25, 0, 0);
  };
  /** blight: sickly veins creeping from the impact, a soft discolour around them */
  // LOOKED AT in engine 2026-10-10: a fixed saturated purple vein read as paint on a wooden shield. The vein now
  // DARKENS the colour it runs through and shifts it slightly toward violet, under a faint sickly halo
  FAM.blight = function (out, A, hit, r, mat, orig) {
    // LOOKED AT 2026-10-11 on the painted cast: four thin arms with 20% forks read as the same fern as lightning. Blight
    // is an INFECTION: a mottled bruise spreading from the wound, a few thick veins with a sick halo, the bite at the centre
    var segs = walk(A, r, hit.x, hit.y, { arms: 3, reach: 0.2 + hit.power * 0.22, jitter: 0.6, fork: 0.1, depth: 1, w0: 2.2 + hit.power * 1.4 });
    // read the ORIGINAL pixels, never the buffer being written: overlapping dabs that re-read their own output converge
    // on one fixed colour whatever the battler is
    var at = function (x, y) { return ((y | 0) * A.w + (x | 0)) * 4; };
    var R = (0.1 + hit.power * 0.09) * Math.min(A.bbox.w, A.bbox.h), s = A.px, sd = hit.seed | 0;
    var x0 = Math.max(0, Math.floor(hit.x - R * 1.5)), x1 = Math.min(A.w - 1, Math.ceil(hit.x + R * 1.5)), y0 = Math.max(0, Math.floor(hit.y - R * 1.5)), y1 = Math.min(A.h - 1, Math.ceil(hit.y + R * 1.5));
    touch(x0, y0, x1, y1);
    for (var y = y0; y <= y1; y++) for (var x = x0; x <= x1; x++) {
      var i = y * A.w + x; if (!A.mask[i]) continue;
      var dx = x - hit.x, dy = y - hit.y, bx = Math.floor(x / s) * s, by = Math.floor(y / s) * s;
      var nz = noise(bx, by, Math.max(3, R * 0.35), sd + 21), fall = 1 - Math.sqrt(dx * dx + dy * dy) / (R * (0.75 + nz * 0.6));
      if (fall <= 0) continue;
      var q = Math.min(1, fall * 1.6) * 0.55, o = i * 4, lo = A.lum[i];
      // a bruise: the pixel's own value, sunk toward a sick violet-olive mottle
      var mot = noise(bx, by, Math.max(2, R * 0.12), sd + 22);
      out[o] += (lo * 0.55 + 30 + mot * 14 - out[o]) * q; out[o + 1] += (lo * 0.5 + 22 + (1 - mot) * 18 - out[o + 1]) * q; out[o + 2] += (lo * 0.62 + 42 - out[o + 2]) * q;
    }
    strokeSegs(out, A, segs, function (x, y) { var i = at(x, y); return ink(orig[i] * 0.55 + 46, orig[i + 1] * 0.7 + 52, orig[i + 2] * 0.4 + 12); }, 0.25, 2.6, 0, 0);
    strokeSegs(out, A, segs, function (x, y) { var i = at(x, y); return ink(orig[i] * 0.3 + 22, orig[i + 1] * 0.2 + 8, orig[i + 2] * 0.36 + 28); }, 0.92, 0.85, 0, 0);
    dab(out, A, hit.x, hit.y, (1.4 + hit.power * 1.6) * A.px, function () { return ink(36, 14, 40); }, 0.85);
    dab(out, A, hit.x - A.px * 0.6, hit.y - A.px * 0.6, (0.6 + hit.power * 0.6) * A.px, function () { return ink(170, 190, 90); }, 0.6);
  };
  var FAMILIES = ['cut', 'crack', 'scorch', 'rime', 'fork', 'blight'];
  /** below this VALUE (max channel) a crack exposes the bare material instead of darkening, fully by DARK - 30. Value,
   *  not luminance: a dark mark reads on saturated red (luminance ~40, value ~200) and cannot on black. MEASURED
   *  2026-10-11 by _probe/lum_probe.js over the CSAF demo cast's bodies: black armour value p50 38 (71% under 70),
   *  dark beetle p50 50 (64%), red wyvern p50 109 (26%, its shading lines), sandstone golem p50 179 (14%) */
  var DARK = 70;

  /* ------------------------------------------------------------ materials, elements, bands */
  var MATERIALS = {
    flesh: { wound: [150, 20, 24], core: [70, 20, 24], chips: false, drips: true, bare: [196, 120, 112] },
    shell: { wound: [60, 50, 40], core: [40, 34, 28], chips: true, bare: [200, 186, 150] },
    stone: { wound: [50, 46, 44], core: [36, 32, 30], chips: true, bare: [178, 168, 154] },
    metal: { wound: [40, 40, 46], core: [30, 30, 36], chips: false, bare: [214, 218, 226] },
    slime: { wound: [30, 60, 30], core: [24, 40, 24], chips: false, bare: [150, 210, 150] },
    spirit: { wound: [40, 30, 70], core: [30, 24, 60], chips: false, bare: [190, 170, 230] },
  };
  /** the family an element NAME asks for (unknown names fall to cut, never to nothing); hard materials crack */
  function familyOf(elementName, material) {
    var n = String(elementName || '').toLowerCase();
    if (/fire|flame|burn|heat|lava|inferno/.test(n)) return 'scorch';
    if (/ice|frost|cold|water|snow|freez/.test(n)) return 'rime';
    if (/thunder|lightning|electric|spark|storm|bolt/.test(n)) return 'fork';
    if (/poison|venom|dark|shadow|blight|toxic|curse|death/.test(n)) return 'blight';
    if (/earth|stone|rock|blunt|crush|impact/.test(n)) return 'crack';
    return material === 'stone' || material === 'metal' || material === 'shell' ? 'crack' : 'cut';
  }
  /** HP band 0 (fresh) .. 3 (barely standing) from the thresholds, highest first, e.g. [75, 50, 25] */
  function bandOf(hp, mhp, cuts) {
    var p = mhp > 0 ? (hp / mhp) * 100 : 100, b = 0;
    for (var i = 0; i < cuts.length; i++) if (p <= cuts[i]) b = i + 1;
    return b;
  }
  /** the band's global wear: outline-near darkening and a desaturation that deepen with the band; band 3 chips the edge */
  function wear(out, A, band, seed) {
    if (band <= 0) return;
    // LOOKED AT 2026-10-11 in a full battle frame: a rim of (1 + band) px and chips one pixel wide were invisible on a
    // 300 px painted battler. Everything here scales with the battler's own size (sc), and from band 2 a mottled grime
    // sinks into the body in patches, so a beaten enemy reads as beaten across the room, not only at the edge
    var sc = Math.max(1, Math.min(A.bbox.w, A.bbox.h) / 140), n = A.w * A.h, rim = (1 + band) * A.px * sc, sat = 0.1 * band;
    var gs = Math.max(4, Math.min(A.bbox.w, A.bbox.h) * 0.09), chip = Math.max(1, Math.round(A.px * sc));
    for (var i = 0; i < n; i++) {
      if (!A.mask[i]) continue;
      var o = i * 4, l = 0.2126 * out[o] + 0.7152 * out[o + 1] + 0.0722 * out[o + 2], x = i % A.w, y = (i / A.w) | 0;
      out[o] += (l - out[o]) * sat; out[o + 1] += (l - out[o + 1]) * sat; out[o + 2] += (l - out[o + 2]) * sat;
      var d = A.dist[i];
      if (d < rim) { var k = (1 - d / rim) * 0.13 * band; out[o] *= 1 - k; out[o + 1] *= 1 - k; out[o + 2] *= 1 - k; }
      if (band >= 2) {
        var g = noise(x, y, gs, seed + 31) - 0.52;
        if (g > 0) { var gk = Math.min(1, g * 4) * 0.13 * (band - 1); out[o] *= 1 - gk; out[o + 1] *= 1 - gk * 1.08; out[o + 2] *= 1 - gk * 1.12; }
      }
      // LOOKED AT 2026-10-11 at 3x: one-cell chips at 20% read as a speckle of square holes (compression noise, not
      // damage). The last band takes BITES out of the outline: where a coarse noise peaks, the edge is eaten to a depth
      // that grows with the peak, so the notches are few, irregular and contiguous
      if (band >= 3 && d < 12 * chip) { var nb = noise(x, y, gs * 0.7, seed + 41); if (nb > 0.6 && d < (nb - 0.6) * 11 * chip) out[o + 3] = 0; }
    }
  }

  /**
   * Bake one enemy's damaged picture: a NEW RGBA buffer from the original, the band's wear, then every recorded hit's
   * family mark at its point, in order. Pure; the same state always gives the same pixels.
   * @param {Object} A analyse() result   @param {Uint8Array} src original RGBA
   * @param {{band:number, hits:Array<{family:string,x:number,y:number,power:number,seed:number}>, seed:number}} st
   * @param {string} material
   */
  function bake(A, src, st, material) { return bakeStep(A, src, st, material, null).rgba; }
  /** one hit applied to the working buffer: its own RNG, seeded by the hit alone, so order is the only coupling */
  function applyHit(out, A, h, mat, src) {
    var fam = FAM[h.family] || FAM.cut, p = inside(A, h.x, h.y) ? { x: h.x, y: h.y } : snapInside(A, h.x, h.y);
    fam(out, A, { x: p.x, y: p.y, power: Math.max(0, Math.min(1, h.power)), seed: h.seed | 0 }, { s: mix(h.seed | 0, 0x5ca7) }, mat, src);
  }
  /**
   * The same picture as a full bake, reusing the previous result when only NEW hits were added at the same band: the
   * full bake is wear(band) then every hit in order, so applying hits n.. onto the buffer that already holds wear and hits
   * 0..n-1 is that same sequence (core.test asserts byte equality). A band change or a different material rebuilds.
   * Measured 2026-10-10: a full re-bake of blight on the 440 x 376 Dragon took 43 ms, on every hit.
   * @param {{buf:Float32Array, band:number, n:number, material:string}|null} prev the `work` of the last call
   * @returns {{rgba:Uint8ClampedArray, work:Object}}
   */
  function bakeStep(A, src, st, material, prev) {
    var hits = st.hits || [], band = st.band | 0, mat = MATERIALS[material] || MATERIALS.flesh, out, from, res, full;
    if (prev && prev.band === band && prev.material === material && prev.n <= hits.length && prev.buf.length === src.length) {
      out = prev.buf; from = prev.n; res = prev.res; full = false;
    } else {
      out = prev && prev.buf.length === src.length ? prev.buf : new Float32Array(src.length);
      for (var i = 0; i < src.length; i++) out[i] = src[i];
      wear(out, A, band, st.seed | 0);
      from = 0; full = true;
      res = prev && prev.res && prev.res.length === src.length ? prev.res : new Uint8ClampedArray(src.length);
    }
    dirtyReset();
    for (var k = from; k < hits.length; k++) applyHit(out, A, hits[k], mat, src);
    // the result buffer persists in `work` (no allocation per hit): all of it after a rebuild, else only the rows and
    // columns the new hits wrote. `dirty` tells the caller which rectangle to upload
    var x0 = 0, y0 = 0, x1 = A.w - 1, y1 = A.h - 1;
    if (!full) { x0 = Math.max(0, DX0); y0 = Math.max(0, DY0); x1 = Math.min(A.w - 1, DX1); y1 = Math.min(A.h - 1, DY1); }
    for (var yy = y0; yy <= y1; yy++) { var a = (yy * A.w + x0) * 4, b = (yy * A.w + x1) * 4 + 4; for (var j = a; j < b; j++) res[j] = out[j]; }
    var dirty = x1 >= x0 && y1 >= y0 ? { x: x0, y: y0, w: x1 - x0 + 1, h: y1 - y0 + 1 } : { x: 0, y: 0, w: 0, h: 0 };
    return { rgba: res, dirty: dirty, work: { buf: out, res: res, band: band, n: hits.length, material: material } };
  }
  /** a hit's landing point when the engine gives none: a seeded point inside the silhouette, biased to its middle */
  /**
   * ...and away from the marks already on it: of up to 12 seeded candidates inside the body, the one farthest from every
   * earlier hit (LOOKED AT in engine 2026-10-10: three hits on one goblin landed on one patch and merged into a blob)
   * @param {Array<{x:number,y:number}>} [placed] earlier hits on this enemy
   */
  function hitPoint(A, seed, placed) {
    var r = { s: mix(seed | 0, 0xb17) }, best = null, bestD = -1, found = 0, prev = placed || [];
    // LOOKED AT 2026-10-11 on a spindly beetle: blows landed on a leg and a horn, where a crack has nowhere to run (the
    // walk stops at the outline) and the mark was a few pixels. A blow lands where the body has THICKNESS: a point at
    // least 6% of the short side from the outline, relaxing to the old two-pixel floor only for a battler without one
    var thick = Math.max(2 * A.px, 0.06 * Math.min(A.bbox.w, A.bbox.h)), r0 = r.s;
    for (var pass = 0; pass < 2; pass++) {
      // pass 0 needs thickness; pass 1 (the same seeded candidates) only the two-pixel floor, when pass 0 found under 3
      var floor = pass === 0 ? thick : 2 * A.px;
      r.s = r0; found = 0; best = null; bestD = -1;
      for (var t = 0; t < 240 && found < 12; t++) {
        var x = A.bbox.x + A.bbox.w * (0.15 + rand(r) * 0.7), y = A.bbox.y + A.bbox.h * (0.15 + rand(r) * 0.7);
        if (!inside(A, x, y) || A.dist[(y | 0) * A.w + (x | 0)] <= floor) continue;
        found++;
        var dmin = 1e9;
        for (var k = 0; k < prev.length; k++) if (prev[k] && prev[k].x !== null) { var dx = prev[k].x - x, dy = prev[k].y - y, d = dx * dx + dy * dy; if (d < dmin) dmin = d; }
        if (!prev.length) return { x: x, y: y };
        if (dmin > bestD) { bestD = dmin; best = { x: x, y: y }; }
      }
      if (found >= 3) break;
    }
    return best || snapInside(A, A.bbox.x + A.bbox.w / 2, A.bbox.y + A.bbox.h / 2);
  }

  return { VERSION: '1.0.0', mix: mix, rand: rand, analyse: analyse, pixelScale: pixelScale, bake: bake, bakeStep: bakeStep, familyOf: familyOf, bandOf: bandOf, hitPoint: hitPoint, FAMILIES: FAMILIES, MATERIALS: MATERIALS, ALPHA_IN: ALPHA_IN };
})();
if (typeof module === 'object' && module.exports) module.exports = ScatheCore;
