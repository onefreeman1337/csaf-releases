/*:
 * @target MZ
 * @plugindesc Scathe 2/2 - enemies show the damage you deal, generated from their own battler art by element and HP.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io/scathe
 *
 * @param bands
 * @text HP bands (percent)
 * @desc Below each of these HP percentages the enemy looks one step more worn. Highest first, comma separated.
 * @default 75,50,25
 *
 * @param material
 * @text Default material
 * @desc How damage reads on an enemy with no <Scathe Material> notetag.
 * @type select
 * @option flesh
 * @option shell
 * @option stone
 * @option metal
 * @option slime
 * @option spirit
 * @default flesh
 *
 * @param maxHits
 * @text Marks per enemy
 * @desc The most hit marks one enemy keeps (older marks stay; new ones stop adding once this is reached).
 * @type number
 * @min 1
 * @max 40
 * @default 16
 *
 * @command mark
 * @text Mark an enemy
 * @desc Draw a hit mark onto a troop member from an event: a scripted blow, a trap, a cutscene.
 *
 * @arg index
 * @text Troop member
 * @desc 1 = the first enemy in the troop, 2 = the second... 0 = every enemy.
 * @type number
 * @min 0
 * @default 1
 *
 * @arg family
 * @text Kind of mark
 * @type select
 * @option cut
 * @option crack
 * @option scorch
 * @option rime
 * @option fork
 * @option blight
 * @default cut
 *
 * @arg power
 * @text Power
 * @desc 0 to 1. How big the mark is (a hit for a third of max HP or more reads as 1).
 * @type number
 * @decimals 2
 * @min 0
 * @max 1
 * @default 0.6
 *
 * @command mend
 * @text Mend an enemy
 * @desc Clear every hit mark on a troop member (its HP-band wear still follows its HP).
 *
 * @arg index
 * @text Troop member
 * @desc 1 = the first enemy in the troop, 2 = the second... 0 = every enemy.
 * @type number
 * @min 0
 * @default 0
 *
 * @help
 * Scathe.js - part of Scathe v1.0.0. Enable it with ScatheCore.js (any order).
 *
 * Every enemy shows the damage it takes, drawn into its own battler image: physical hits cut, earth cracks, fire
 * chars, ice frosts, thunder burns a forked line, poison and darkness spread a bruise with veins. As its HP falls
 * past each band the enemy looks more worn, and at the last band its outline chips. Nothing to draw: the damage is
 * generated from the battler's own pixels, and never drawn outside its outline or on its painted ground shadow.
 *
 * Enemy notetags:
 *   <Scathe Material: stone>   flesh, shell, stone, metal, slime or spirit
 *   <Scathe: off>              this enemy never shows damage
 *
 * The kind of mark comes from the NAME of the element that hit (Fire, Ice, Thunder, Water, Earth, Poison,
 * Darkness...; a name it does not know is a cut, or a crack on stone, metal and shell). An enemy that transforms
 * starts clean. Collapse stays with whatever collapse effect your game uses.
 *
 * Plugin commands: Mark an enemy (draw a mark from an event), Mend an enemy (clear its marks).
 *
 * Every line of this plugin was written with AI assistance.
 */
(function () {
  'use strict';
  var NAME = 'Scathe';
  var P = PluginManager.parameters(NAME);
  var BANDS = String(P.bands || '75,50,25').split(',').map(function (s) { return Number(s); }).filter(function (n) { return n > 0 && n < 100; }).sort(function (a, b) { return b - a; });
  var MATERIAL = String(P.material || 'flesh');
  var MAX_HITS = Math.max(1, Math.min(40, Number(P.maxHits) || 16));
  var DEPS = null;
  /** images one enemy sprite may be read from in a battle (a transform is one; an animation plugin swapping frames is many) */
  var MAX_READS = 4;
  /** ScatheCore resolved once at first use (wing §8 trap 2: load order is the buyer's) */
  function core() {
    if (DEPS) return DEPS;
    if (typeof ScatheCore === 'undefined') throw new Error('Scathe needs ScatheCore.js enabled');
    DEPS = ScatheCore;
    return DEPS;
  }
  var NOTE_MAT = /<Scathe Material:\s*(\w+)\s*>/i, NOTE_OFF = /<Scathe:\s*off\s*>/i;
  function materialOf(enemy) { var m = NOTE_MAT.exec((enemy && enemy.note) || ''); var v = m ? m[1].toLowerCase() : MATERIAL; return core().MATERIALS[v] ? v : MATERIAL; }
  function isOff(enemy) { return NOTE_OFF.test((enemy && enemy.note) || ''); }

  /* ----------------------------------------------------------------------- the record of hits, on the enemy */
  /** per-enemy damage record; plain JSON, not saved (battles are not saved mid-fight). gen counts mends: a sprite never
   *  reuses a bake from an older generation, however many hits arrive in one frame */
  Game_Enemy.prototype.scatheRecord = function () {
    if (!this._scathe) this._scathe = { hits: [], ver: 0, gen: 0, seed: core().mix(this.enemyId() | 0, (this.index() | 0) + 1) };
    return this._scathe;
  };
  /** add one mark of a family at a power 0..1 (the sprite places it on the body); false when the enemy is full or off */
  Game_Enemy.prototype.scatheAddHit = function (family, power) {
    if (isOff(this.enemy())) return false;
    var C = core(), rec = this.scatheRecord();
    if (rec.hits.length >= MAX_HITS) return false;
    rec.hits.push({ family: C.FAMILIES.indexOf(family) >= 0 ? family : 'cut', x: null, y: null, power: Math.max(0, Math.min(1, Number(power) || 0)), seed: C.mix(rec.seed, rec.hits.length + 1 + rec.gen * 4096) });
    rec.ver++;
    return true;
  };
  /** clear every mark (the band wear stays with HP) */
  Game_Enemy.prototype.scatheMend = function () { var rec = this.scatheRecord(); rec.hits = []; rec.gen++; rec.ver++; };
  var _transform = Game_Enemy.prototype.transform;
  Game_Enemy.prototype.transform = function () {
    _transform.apply(this, arguments);
    // a transformed enemy is another creature with another image: it starts clean
    if (this._scathe) this.scatheMend();
  };
  /** the element name of an action against a target: the skill's own element, or the attacker's first attack element */
  function elementNameOf(action) {
    var item = action.item(), id = item && item.damage ? item.damage.elementId : 0;
    if (id < 0) { var els = action.subject().attackElements(); id = els.length ? els[0] : 1; }
    return ($dataSystem.elements[id] || '');
  }
  var _executeHpDamage = Game_Action.prototype.executeHpDamage;
  Game_Action.prototype.executeHpDamage = function (target, value) {
    _executeHpDamage.apply(this, arguments);
    if (!(value > 0) || !target || !target.isEnemy() || isOff(target.enemy())) return;
    target.scatheAddHit(core().familyOf(elementNameOf(this), materialOf(target.enemy())), (value / Math.max(1, target.mhp)) * 3);
  };

  /* ----------------------------------------------------------------------- plugin commands */
  /** troop members a command names: 1-based index, 0 = all; an index past the troop is nobody */
  function membersOf(args) {
    var n = Math.floor(Number(args.index)), all = $gameTroop.members();
    if (!(n > 0)) return n === 0 ? all : [];
    return all[n - 1] ? [all[n - 1]] : [];
  }
  PluginManager.registerCommand(NAME, 'mark', function (args) {
    var fam = String(args.family || 'cut'), pw = args.power === '' || args.power == null ? 0.6 : Number(args.power);
    membersOf(args).forEach(function (en) { en.scatheAddHit(fam, pw); });
  });
  PluginManager.registerCommand(NAME, 'mend', function (args) {
    membersOf(args).forEach(function (en) { en.scatheMend(); });
  });

  /* ----------------------------------------------------------------------- the sprite */
  var _initMembers = Sprite_Enemy.prototype.initMembers;
  Sprite_Enemy.prototype.initMembers = function () {
    _initMembers.apply(this, arguments);
    this._scatheSrc = null; this._scatheA = null; this._scathePx = null; this._scatheOut = null; this._scatheWork = null; this._scatheImg = null;
    this._scatheBand = -1; this._scatheVer = -1; this._scatheGen = -1; this._scatheReads = 0; this._scatheGaveUp = false;
  };
  var _update = Sprite_Enemy.prototype.update;
  Sprite_Enemy.prototype.update = function () {
    _update.apply(this, arguments);
    if (this._enemy) this.updateScathe();
  };
  /**
   * Once per battler image: read it from a canvas WE own (never bitmap.canvas, Probe_Doctrine §37b), analyse it. Then,
   * only when a hit lands or the HP band changes, re-bake the damaged copy and show it. Nothing allocates per frame.
   */
  Sprite_Enemy.prototype.updateScathe = function () {
    var b = this.bitmap, en = this._enemy;
    if (!b || this._scatheGaveUp || isOff(en.enemy())) return;
    if (b !== this._scatheOut && b !== this._scatheSrc) {
      if (!b.isReady()) return;
      // an image too small to hold a mark (RPG Maker's 1 x 1 empty bitmap, for an enemy with no battler) is taken as
      // this sprite's image and never read. MEASURED 2026-10-11 (breakit.js attack 2): without this the 1 x 1 empty
      // bitmap was read and baked like a battler (a pointless pixel read and a 1 x 1 texture of our own)
      if (b.width < 4 || b.height < 4) { this._scatheSrc = b; this._scatheA = null; this._scatheWork = null; this._scathePx = null; return; }
      // a battler whose image keeps being replaced (an animated-battler plugin) would cost a pixel read per swap, a GPU
      // stall in the middle of play (Probe_Doctrine §27a): after MAX_READS images on one sprite, Scathe leaves it alone
      if (++this._scatheReads > MAX_READS) { this._scatheGaveUp = true; this._scatheWork = null; this._scathePx = null; this._scatheA = null; return; }
      this.scatheAnalyse(b);
    }
    if (!this._scatheA) return;
    var C = core(), band = C.bandOf(en.hp, en.mhp, BANDS), rec = en.scatheRecord();
    if (band === this._scatheBand && rec.ver === this._scatheVer) return;
    this._scatheBand = band; this._scatheVer = rec.ver;
    this.scatheBake(band, rec);
  };
  Sprite_Enemy.prototype.scatheAnalyse = function (b) {
    var C = core(), w = b.width, h = b.height, cv = document.createElement('canvas');
    cv.width = w; cv.height = h;
    var g = cv.getContext('2d', { willReadFrequently: true });
    g.drawImage(b._canvas || b._image, 0, 0);
    var data = g.getImageData(0, 0, w, h).data;
    this._scatheSrc = b; this._scathePx = data; this._scatheA = C.analyse(data, w, h); this._scatheWork = null;
    if (!this._scatheOut || this._scatheOut.width !== w || this._scatheOut.height !== h) { if (this._scatheOut) this._scatheOut.destroy(); this._scatheOut = new Bitmap(w, h); }
    this._scatheBand = -1; this._scatheVer = -1;
  };
  Sprite_Enemy.prototype.scatheBake = function (band, rec) {
    var C = core(), A = this._scatheA;
    // a mend (or a transform) starts a new generation: the last bake is never reused across it
    if (rec.gen !== this._scatheGen) { this._scatheWork = null; this._scatheGen = rec.gen; }
    if (band === 0 && rec.hits.length === 0) { this._scatheWork = null; if (this.bitmap !== this._scatheSrc) this.bitmap = this._scatheSrc; return; }
    // each new hit lands away from the marks already on this enemy (hits before it in the record)
    for (var i = 0; i < rec.hits.length; i++) if (rec.hits[i].x === null) { var p = C.hitPoint(A, rec.hits[i].seed, rec.hits.slice(0, i)); rec.hits[i].x = p.x; rec.hits[i].y = p.y; }
    // incremental: a new hit at the same band is applied onto the last result, never a re-bake of every hit
    var step = C.bakeStep(A, this._scathePx, { band: band, seed: rec.seed, hits: rec.hits }, materialOf(this._enemy.enemy()), this._scatheWork);
    this._scatheWork = step.work;
    // the result buffer persists across hits, so one ImageData wraps it for good; only the rectangle the hit changed is
    // written into the canvas (MEASURED 2026-10-11: a whole-image copy and put on every hit put the update half's p99
    // over budget on 300 px battlers, gate_trio_autohit)
    var out = step.rgba, bmp = this._scatheOut, ctx = bmp.context, d = step.dirty;
    if (!this._scatheImg || this._scatheImg.data !== out) this._scatheImg = new ImageData(out, A.w, A.h);
    if (d.w > 0 && d.h > 0) ctx.putImageData(this._scatheImg, 0, 0, d.x, d.y, d.w, d.h);
    bmp._baseTexture.update();
    if (this.bitmap !== bmp) this.bitmap = bmp;
  };
  /** the baked copy is ours: free its canvas and GPU texture with the sprite (a battle's sprites die with its scene) */
  var _destroy = Sprite_Enemy.prototype.destroy;
  Sprite_Enemy.prototype.destroy = function () {
    var own = this._scatheOut;
    this._scatheOut = null; this._scatheSrc = null; this._scathePx = null; this._scatheA = null; this._scatheWork = null; this._scatheImg = null;
    _destroy.apply(this, arguments);
    if (own) own.destroy();
  };
})();
