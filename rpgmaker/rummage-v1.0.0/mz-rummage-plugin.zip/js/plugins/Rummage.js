//=============================================================================
// Rummage.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Rummage: I Spy and seek-and-find scenes composed from your own items and characters.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * Install RummageCore.js, RummageDraw.js and Rummage.js (this file). Any
 * order works: the files find each other when the first scene opens.
 *
 * I SPY (plugin command "I Spy", or a script call)
 *   CSAF.Rummage.spy({ surface: 'hoard', count: 6, source: 'items' })
 * The scene is composed from your database: every item, weapon or armour
 * with an icon and a name can be hidden, on one of eight drawn surfaces
 * (hoard, velvet, tavern, forest, beach, bench, wreck, library). The list on
 * the parchment is your own names. No two records that share an icon or a
 * name are ever in the same scene, and every listed thing keeps most of its
 * outline in plain view, so it can always be found.
 * Notetags on items, weapons and armours:
 *   <Rummage: fish>          a tag a command can ask for (several: fish, river)
 *   <Rummage: skip>          never used
 *
 * CROWD (plugin command "Crowd", or a script call)
 *   CSAF.Rummage.crowd({ target: 3, walkers: 56 })
 * Your characters walk a drawn market square, fair meadow or quay, in front
 * of its stalls, tents or moored boats; the player finds one of them by face
 * and costume among the others and among recoloured lookalikes. target is an
 * actor id, or "file:index" for any sheet in img/characters.
 *
 * Playing: click or tap what you find. The lens follows the mouse; with the
 * keyboard or a pad, move it with the arrows and press OK to look there. Hint
 * (W / Page Down, or the seal on the parchment) makes one thing glint. Cancel
 * gives up if the command allows it.
 *
 * Results are written as the scene closes, before the event continues:
 * seconds, found and misses into variables, a switch ON when everything was
 * found, and an optional common event. CSAF.Rummage.lastResult() returns
 * { mode, place, found, total, seconds, misses, hints, success, seed }.
 *
 * @param varSeconds
 * @text Seconds -> variable
 * @type variable
 * @default 0
 *
 * @param varFound
 * @text Found -> variable
 * @type variable
 * @default 0
 *
 * @param varMisses
 * @text Misses -> variable
 * @type variable
 * @default 0
 *
 * @param swSuccess
 * @text All found -> switch
 * @type switch
 * @default 0
 *
 * @param commonEvent
 * @text Common event afterwards
 * @type common_event
 * @default 0
 *
 * @param lens
 * @text Magnifying lens
 * @type boolean
 * @on Show
 * @off Hide
 * @default true
 *
 * @param missPenalty
 * @text Seconds added per miss
 * @desc On a timed scene, each wrong click costs this many seconds. 0 = none.
 * @type number
 * @min 0
 * @max 30
 * @default 0
 *
 * @param allowCancel
 * @text Cancel gives up
 * @type boolean
 * @default true
 *
 * @command spy
 * @text I Spy
 * @desc Compose a seek-and-find scene from your database and let the player hunt the listed things.
 *
 * @arg surface
 * @text Surface
 * @type select
 * @option Seeded (auto)
 * @value auto
 * @option Dragon Hoard
 * @value hoard
 * @option Merchant's Cloth
 * @value velvet
 * @option Tavern Table
 * @value tavern
 * @option Forest Floor
 * @value forest
 * @option Low Tide
 * @value beach
 * @option Alchemist's Bench
 * @value bench
 * @option Sunken Wreck
 * @value wreck
 * @option Library Desk
 * @value library
 * @default auto
 *
 * @arg count
 * @text Things to find
 * @type number
 * @min 1
 * @max 12
 * @default 6
 *
 * @arg difficulty
 * @text Difficulty
 * @type select
 * @option easy
 * @option normal
 * @option hard
 * @default normal
 *
 * @arg source
 * @text Hide from
 * @type select
 * @option items
 * @option weapons
 * @option armors
 * @option all
 * @default all
 *
 * @arg tag
 * @text Only this <Rummage> tag
 * @desc Blank = any record. A tag such as fish uses only records with <Rummage: fish>.
 * @type string
 * @default
 *
 * @arg seconds
 * @text Time limit (seconds)
 * @desc 0 = no limit.
 * @type number
 * @min 0
 * @max 999
 * @default 0
 *
 * @arg hints
 * @text Hints
 * @type number
 * @min 0
 * @max 9
 * @default 2
 *
 * @arg seed
 * @text Seed
 * @desc Blank = a new scene every time. A number composes the same scene every time.
 * @type string
 * @default
 *
 * @command crowd
 * @text Crowd
 * @desc Your characters walk a drawn square, meadow or quay; the player finds one of them.
 *
 * @arg target
 * @text Who to find
 * @desc An actor id, or file:index for a sheet in img/characters (e.g. People1:2). Blank = a random actor.
 * @type string
 * @default
 *
 * @arg name
 * @text Name on the card
 * @desc Blank = the actor's name, or the file name.
 * @type string
 * @default
 *
 * @arg ground
 * @text Ground
 * @type select
 * @option Seeded (auto)
 * @value auto
 * @option The Market Square
 * @value plaza
 * @option The Fair Meadow
 * @value meadow
 * @option The Quay
 * @value quay
 * @default auto
 *
 * @arg walkers
 * @text Walkers
 * @type number
 * @min 6
 * @max 80
 * @default 56
 *
 * @arg lookalikes
 * @text Recoloured lookalikes
 * @type number
 * @min 0
 * @max 8
 * @default 4
 *
 * @arg extra
 * @text Extra cast (file:index, ...)
 * @desc More sheets to walk in the crowd besides your actors, e.g. People1:0, People1:3, Actor2:5
 * @type string
 * @default
 *
 * @arg seconds
 * @text Time limit (seconds)
 * @type number
 * @min 0
 * @max 999
 * @default 0
 *
 * @arg seed
 * @text Seed
 * @type string
 * @default
 */

var CSAF = CSAF || {};

(function () {
  'use strict';
  var NAME = 'Rummage';
  var RAW = PluginManager.parameters(NAME);
  /** Parameters arrive as strings; blank is absent, never zero (wing §16). */
  function num(v, d) { var s = String(v === undefined || v === null ? '' : v).trim(); if (s === '') return d; var n = Number(s); return isFinite(n) ? n : d; }
  function bool(v, d) { var s = String(v === undefined || v === null ? '' : v).trim(); if (s === '') return d; return s === 'true'; }
  var P = {
    varSeconds: num(RAW.varSeconds, 0), varFound: num(RAW.varFound, 0), varMisses: num(RAW.varMisses, 0), swSuccess: num(RAW.swSuccess, 0),
    commonEvent: num(RAW.commonEvent, 0), lens: bool(RAW.lens, true), missPenalty: Math.max(0, num(RAW.missPenalty, 0)), allowCancel: bool(RAW.allowCancel, true)
  };
  /** Siblings resolved at first use: the buyer chooses the load order (Retrofit_Doctrine trap 2). */
  function deps() {
    var C = CSAF.RummageCore, D = CSAF.RummageDraw;
    if (!C || !D) throw new Error('Rummage needs RummageCore.js and RummageDraw.js installed and ON.');
    return { C: C, D: D };
  }
  /** A book serif for the parchment, never the engine's UI font (wing §15a). Palatino first: its figures are LINING, while
   *  Georgia's old-style zero reads as a letter o ("o misses", "o:oo", review 2026-10-20). */
  var FONT = '"Palatino Linotype", "Book Antiqua", Palatino, Georgia, "Times New Roman", serif';
  var INK = '#3a1d0e', INK_SOFT = 'rgba(58,29,14,0.62)';
  var GROUND_NAMES = { plaza: 'The Market Square', meadow: 'The Fair Meadow', quay: 'The Quay' };
  var GROUND_WHERE = { plaza: 'in the square', meadow: 'on the meadow', quay: 'on the quay' };
  function uiScale() { return Math.max(1, Math.min(3, Math.min(Graphics.width, Graphics.height) / 624)); }
  /**
   * Text straight onto a bitmap's context, laid out exactly as Bitmap.drawText lays it out (rmmz_core.js), but WITHOUT its
   * per-call texture upload: MZ's drawText marks the texture dirty every call, so a parchment of 18 lines cost 18 dirties
   * a repaint (the gate read 0.3 a frame from the clock alone, Probe §34a). The caller uploads once when done.
   */
  function txt(b, text, x, y, maxWidth, lineHeight, align) {
    var c = b.context, ty = Math.round(y + lineHeight / 2 + b.fontSize * 0.35), tx = align === 'center' ? x + maxWidth / 2 : align === 'right' ? x + maxWidth : x;
    c.save(); c.font = b._makeFontNameText(); c.textAlign = align || 'left'; c.textBaseline = 'alphabetic'; c.globalAlpha = b.paintOpacity / 255;
    c.fillStyle = b.textColor; c.fillText(String(text), tx, ty, maxWidth); c.restore();
  }
  function rec() { if (!$gameSystem._csafRummage) $gameSystem._csafRummage = { v: 1, count: 0, last: null, seen: {} }; return $gameSystem._csafRummage; }
  function autoSeed(tag) { var r = rec(); return tag + r.count + 'm' + ($gameMap ? $gameMap.mapId() : 0) + 'f' + Graphics.frameCount; }

  /** Every item, weapon and armour as a plain record for the pool. */
  function databaseRecords(source) {
    var out = [], sets = [['item', $dataItems], ['weapon', $dataWeapons], ['armor', $dataArmors]];
    var want = source === 'items' ? 'item' : source === 'weapons' ? 'weapon' : source === 'armors' ? 'armor' : null;
    for (var s = 0; s < sets.length; s++) {
      if (want && sets[s][0] !== want) continue;
      var list = sets[s][1] || [];
      for (var i = 1; i < list.length; i++) { var d = list[i]; if (d) out.push({ kind: sets[s][0], id: d.id, name: d.name, iconIndex: d.iconIndex, meta: d.meta || {} }); }
    }
    return out;
  }

  var pending = null;
  /**
   * Open an I Spy scene. @param {object} args {surface, count, difficulty, source, tag, seconds, hints, seed}
   * @returns {boolean} false when nothing in the database can be hidden
   */
  function spy(args) {
    args = args || {};
    var d = deps(), seedText = String(args.seed === undefined ? '' : args.seed).trim(), seed = seedText !== '' ? seedText : autoSeed('s');
    var pool = d.C.buildPool(databaseRecords(String(args.source || 'all')), { tag: args.tag });
    if (!pool.length) { console.warn('Rummage: no item, weapon or armour has both an icon and a name' + (args.tag ? ' and the tag ' + args.tag : '') + '.'); return false; }
    var diff = d.C.DIFFICULTY[args.difficulty] ? String(args.difficulty) : 'normal', count = Math.max(1, Math.min(12, num(args.count, 6)));
    pending = { mode: 'spy', seed: seed, surface: d.C.surfaceFor(String(args.surface || 'auto'), seed), count: count, difficulty: diff, pool: pool,
      seconds: Math.max(0, num(args.seconds, 0)), hints: Math.max(0, num(args.hints, 2)) };
    SceneManager.push(Scene_Rummage);
    return true;
  }

  /** "Actor 3", "3", "People1:2" -> a cast entry {file, index, name, face, faceIndex}. */
  function castEntry(spec, nameOverride) {
    var s = String(spec === undefined ? '' : spec).trim();
    if (!s) return null;
    if (/^\d+$/.test(s)) { var a = $dataActors[Number(s)]; if (!a || !a.characterName) return null; return { key: 'a' + a.id, file: a.characterName, index: a.characterIndex, name: nameOverride || a.name, face: a.faceName, faceIndex: a.faceIndex }; }
    var m = s.match(/^(.+?)\s*:\s*(\d+)$/), file = m ? m[1].trim() : s, idx = m ? Number(m[2]) : 0;
    return { key: 'c' + file + ':' + idx, file: file, index: idx, name: nameOverride || file.replace(/^[!$]+/, ''), face: '', faceIndex: 0 };
  }

  /**
   * Open a crowd scene. @param {object} args {target, name, ground, walkers, lookalikes, extra, seconds, seed}
   */
  function crowd(args) {
    args = args || {};
    var d = deps(), seedText = String(args.seed === undefined ? '' : args.seed).trim(), seed = seedText !== '' ? seedText : autoSeed('c');
    var cast = [], seen = {};
    function add(e) { if (e && !seen[e.key]) { seen[e.key] = 1; cast.push(e); } }
    for (var i = 1; i < $dataActors.length; i++) if ($dataActors[i] && $dataActors[i].characterName) add(castEntry(String(i)));
    String(args.extra || '').split(',').forEach(function (t) { add(castEntry(t)); });
    var tgt = castEntry(args.target, String(args.name || '').trim());
    if (!tgt && cast.length) tgt = cast[Math.floor(d.C.rng(d.C.seedOf(seed + ':who'))() * cast.length)];
    if (!tgt) { console.warn('Rummage: no actor has a character image, and no target was given.'); return false; }
    if (args.name) tgt.name = String(args.name).trim();
    add(tgt);
    var ti = -1; for (var k = 0; k < cast.length; k++) if (cast[k].key === tgt.key) { ti = k; cast[k].name = tgt.name; }
    var grounds = ['plaza', 'meadow', 'quay'], g = String(args.ground || 'auto');
    if (grounds.indexOf(g) < 0) g = grounds[Math.floor(d.C.rng(d.C.seedOf(seed + ':ground'))() * grounds.length)];
    pending = { mode: 'crowd', seed: seed, ground: g, cast: cast, target: ti, walkers: Math.max(6, Math.min(80, num(args.walkers, 56))),
      lookalikes: Math.max(0, Math.min(8, num(args.lookalikes, 4))), seconds: Math.max(0, num(args.seconds, 0)), hints: 1 };
    SceneManager.push(Scene_Rummage);
    return true;
  }

  PluginManager.registerCommand(NAME, 'spy', function (args) { spy(args); });
  PluginManager.registerCommand(NAME, 'crowd', function (args) { crowd(args); });

  //---------------------------------------------------------------------------
  function Scene_Rummage() { this.initialize.apply(this, arguments); }
  Scene_Rummage.prototype = Object.create(Scene_Base.prototype);
  Scene_Rummage.prototype.constructor = Scene_Rummage;

  Scene_Rummage.prototype.initialize = function () {
    Scene_Base.prototype.initialize.call(this);
    this._req = pending; pending = null;
    this._built = false; this._done = false; this._doneAge = 0; this._frames = 0; this._misses = 0; this._hintsUsed = 0; this._penalty = 0;
    this._icons = this._req && this._req.mode === 'spy' ? ImageManager.loadSystem('IconSet') : null;
    this._sheets = [];
    // crowd sheets load OUTSIDE ImageManager's cache: ImageManager.isReady() THROWS on any errored bitmap in its cache
    // (rmmz_managers.js:988-1000) and the engine's Retry screen loops forever on a mistyped sheet name. Uncached, a missing
    // sheet just reads isError() here, and buildCrowd leaves that cast member out (2026-10-20, found by breakit).
    if (this._req && this._req.mode === 'crowd') for (var i = 0; i < this._req.cast.length; i++) this._sheets.push(Bitmap.load('img/characters/' + Utils.encodeURI(this._req.cast[i].file) + '.png'));
  };

  Scene_Rummage.prototype.isReady = function () {
    if (!Scene_Base.prototype.isReady.call(this)) return false;
    if (this._icons && !this._icons.isReady()) return false;
    for (var i = 0; i < this._sheets.length; i++) if (!this._sheets[i].isReady() && !this._sheets[i].isError()) return false;
    return true;
  };

  Scene_Rummage.prototype.start = function () {
    Scene_Base.prototype.start.call(this);
    if (!this._req) { this.popScene(); return; }
    this.buildLayout();
    if (this._req.mode === 'spy') this.buildSpy(); else this.buildCrowd();
    // a build that gave up (the character to find did not load) has already popped the scene: build nothing more
    if (this._aborted) return;
    this._built = true;
    this.drawPanel();
  };

  /** Where the scene and the parchment go on this screen (portrait screens stack them). */
  Scene_Rummage.prototype.buildLayout = function () {
    var W = Graphics.width, H = Graphics.height, S = uiScale(), M = Math.round(16 * S), portrait = H > W * 1.15;
    var PW = portrait ? W - 2 * M : Math.round(212 * S), PH = portrait ? Math.round(250 * S) : H - 2 * M;
    var L = { S: S, M: M, portrait: portrait };
    if (portrait) { L.sx = M; L.sy = M; L.sw = W - 2 * M; L.sh = H - 3 * M - PH; L.px = M; L.py = H - M - PH; }
    else { L.sx = M; L.sy = M; L.sw = W - 3 * M - PW; L.sh = H - 2 * M; L.px = W - M - PW; L.py = M; }
    L.pw = PW; L.ph = PH;
    this._L = L;
    var d = deps(), desk = new Bitmap(W, H);
    d.D.drawDesk(desk.context, W, H, this._req.seed, S);
    d.D.drawFrame(desk.context, L.sx, L.sy, L.sw, L.sh, S);
    d.D.drawParchment(desk.context, L.px, L.py, PW, PH, this._req.seed, S);
    desk._baseTexture.update();
    this.addChild(new Sprite(desk));
  };

  //---------------------------------------------------------------------------
  // I SPY
  //---------------------------------------------------------------------------
  Scene_Rummage.prototype.buildSpy = function () {
    var d = deps(), L = this._L, q = this._req, iw = ImageManager.iconWidth || 32, ih = ImageManager.iconHeight || 32;
    var k = Math.max(1, Math.round(Math.min(L.sw, L.sh) / 600)), itemPx = iw * k;
    var f = d.C.pickFinds(q.pool, q.count, q.count * d.C.DIFFICULTY[q.difficulty].decoyMul, q.seed);
    this._sc = d.C.compose({ w: L.sw, h: L.sh, surface: q.surface, seed: q.seed, targets: f.targets, decoys: f.decoys, itemPx: itemPx, fillScale: k, difficulty: q.difficulty });
    this._found = new Uint8Array(this._sc.targets.length);
    this._iconSrc = this._icons._canvas || this._icons._image; // Probe §37b: never the .canvas getter on an engine bitmap
    this._iw = iw; this._ih = ih; this._scratch = document.createElement('canvas'); this._k = k;
    // the scene bitmap: the surface now, the objects settle in over the first frames (the intro), then it never changes
    this._sceneBmp = new Bitmap(L.sw, L.sh);
    d.D.drawSurface(this._sceneBmp.context, this._sc.surface, L.sw, L.sh, this._sc.seed, k);
    this._sceneBmp._baseTexture.update();
    // the lens gets its OWN copy of the scene and the ink at twice the resolution, drawn under a 2x transform from the
    // same seed and the same objects, so what it magnifies is sharp detail, not the 1x bitmap blown up
    this._lensBmp = P.lens ? new Bitmap(L.sw * 2, L.sh * 2) : null;
    this._lensInk = P.lens ? new Bitmap(L.sw * 2, L.sh * 2) : null;
    if (this._lensBmp) { var lc = this._lensBmp.context; lc.save(); lc.scale(2, 2); d.D.drawSurface(lc, this._sc.surface, L.sw, L.sh, this._sc.seed, k); lc.restore(); this._lensBmp._baseTexture.update(); }
    this._bakeAt = 0; this._bakePer = Math.max(1, Math.ceil(this._sc.objects.length / 36));
    this._sceneSp = new Sprite(this._sceneBmp); this._sceneSp.x = L.sx; this._sceneSp.y = L.sy; this.addChild(this._sceneSp);
    this._inkBmp = new Bitmap(L.sw, L.sh); this._inkSp = new Sprite(this._inkBmp); this._inkSp.x = L.sx; this._inkSp.y = L.sy; this.addChild(this._inkSp);
    this.buildLens();
    this.buildGlint();
    this._cursorX = L.sw / 2; this._cursorY = L.sh / 2; this._kbd = false;
  };

  /** Bake the next batch of objects into the scene (the intro). Returns true while there is more to bake. */
  Scene_Rummage.prototype.bakeStep = function () {
    var d = deps(), sc = this._sc, c = this._sceneBmp.context, end = Math.min(sc.objects.length, this._bakeAt + this._bakePer);
    for (var i = this._bakeAt; i < end; i++) d.D.drawObject(c, sc.objects[i], this._k, this._iconSrc, this._scratch, this._iw, this._ih);
    if (this._lensBmp) {
      var lc = this._lensBmp.context; lc.save(); lc.scale(2, 2);
      for (var j = this._bakeAt; j < end; j++) d.D.drawObject(lc, sc.objects[j], this._k, this._iconSrc, this._scratch, this._iw, this._ih);
      lc.restore(); this._lensBmp._baseTexture.update();
    }
    this._bakeAt = end;
    this._sceneBmp._baseTexture.update();
    return this._bakeAt < sc.objects.length;
  };

  /** Ink on the scene AND on the lens's 2x copy: fn(context) draws in scene coordinates. Called on an event, never per frame. */
  Scene_Rummage.prototype.ink = function (fn) {
    fn(this._inkBmp.context); this._inkBmp._baseTexture.update();
    if (this._lensInk) { var c = this._lensInk.context; c.save(); c.scale(2, 2); fn(c); c.restore(); this._lensInk._baseTexture.update(); }
  };

  /** The lens: the scene and its ink again at 2x under a round mask, and the brass rim on top. Moving it sets x/y only. */
  Scene_Rummage.prototype.buildLens = function () {
    var L = this._L, S = L.S, R = Math.round(58 * S);
    this._lensR = R;
    this._lens = new Sprite(); this._lens.visible = false;
    // the lens shows the 2x bake at 1:1 (sharp); without one it falls back to the scene at scale 2
    this._lensIn = new Sprite(); var hi = !!this._lensBmp;
    if (!hi) this._lensIn.scale.x = this._lensIn.scale.y = 2;
    var a = new Sprite(hi ? this._lensBmp : this._sceneBmp), b = new Sprite(hi ? this._lensInk : (this._inkBmp || this._sceneBmp));
    this._lensIn.addChild(a); if (hi || this._inkBmp) this._lensIn.addChild(b);
    this._lens.addChild(this._lensIn);
    var mask = new PIXI.Graphics(); mask.beginFill(0xffffff); mask.drawCircle(0, 0, R); mask.endFill();
    this._lensMask = mask; this._lens.addChild(mask); this._lensIn.mask = mask;
    var rb = new Bitmap(R * 2 + Math.round(70 * S), R * 2 + Math.round(70 * S));
    deps().D.drawLens(rb.context, R + 4 * S, R + 4 * S, R, S); rb._baseTexture.update();
    this._rim = new Sprite(rb); this._rimOff = R + 4 * S; this._lens.addChild(this._rim);
    if (P.lens) this.addChild(this._lens);
  };

  /** Point the lens at scene-local (x, y). No allocation. */
  Scene_Rummage.prototype.placeLens = function (x, y) {
    var L = this._L;
    this._lens.x = L.sx + x; this._lens.y = L.sy + y;
    this._lensIn.x = -2 * x; this._lensIn.y = -2 * y;
    this._lensMask.x = 0; this._lensMask.y = 0;
    this._rim.x = -this._rimOff; this._rim.y = -this._rimOff;
  };

  Scene_Rummage.prototype.buildGlint = function () {
    // big enough that its clear centre (0.42 r) holds a whole listed icon
    var S = this._L.S, r = Math.round(Math.max(26 * S, this._sc ? this._sc.itemPx * 1.25 : 0)), gb = new Bitmap(r * 2, r * 2);
    deps().D.drawGlint(gb.context, r, r, r); gb._baseTexture.update();
    this._glint = new Sprite(gb); this._glint.anchor.x = this._glint.anchor.y = 0.5; this._glint.visible = false; this._glintAge = 0;
    this.addChild(this._glint);
  };

  /** A click or OK at scene-local (x, y). */
  Scene_Rummage.prototype.searchSpy = function (x, y) {
    var d = deps(), sc = this._sc, tol = Math.max(5, sc.itemPx * 0.16), hit = d.C.hitSpy(sc, x, y, tol, this._found);
    if (hit >= 0) {
      this._found[hit] = 1;
      var o = sc.objects[sc.targets[hit]], S = this._L.S;
      this.ink(function (c) { d.D.drawRing(c, o.x, o.y, o.a * 1.45, S, sc.seed + ':ring' + hit); });
      rec().seen[o.icon] = 1;
      SoundManager.playOk();
      if (this._glint.visible && this._glintTarget === hit) this._glint.visible = false;
      this.drawPanel();
      if (this.foundCount() === sc.targets.length) this.finish(true);
    } else {
      this._misses++; this._penalty += P.missPenalty;
      var S2 = this._L.S, mseed = sc.seed + ':miss' + this._misses;
      this.ink(function (c) { d.D.drawMiss(c, x, y, S2, mseed); });
      SoundManager.playBuzzer();
      this.drawPanel();
    }
  };

  Scene_Rummage.prototype.foundCount = function () { var n = 0; for (var i = 0; i < this._found.length; i++) n += this._found[i]; return n; };

  /** Make one unfound thing glint, at the middle of its visible part. */
  Scene_Rummage.prototype.useHint = function () {
    if (this._done || this._hintsUsed >= this._req.hints) return;
    var L = this._L;
    if (this._req.mode === 'spy') {
      // the first unfound thing counting on from a different place each hint, so two hints point at two things
      var sc = this._sc, n0 = sc.targets.length, pick = -1;
      for (var i = 0; i < n0 && pick < 0; i++) { var j = (i + this._hintsUsed * 3) % n0; if (!this._found[j]) pick = j; }
      if (pick < 0) return;
      var s = sc.visStart[pick], n = sc.visCount[pick], mx = 0, my = 0;
      for (var k = s; k < s + n; k++) { mx += sc.vis[k * 2]; my += sc.vis[k * 2 + 1]; }
      this._glint.x = L.sx + mx / Math.max(1, n); this._glint.y = L.sy + my / Math.max(1, n); this._glintTarget = pick;
    } else {
      this._glintTarget = 0; this._glintFollow = true;
    }
    this._hintsUsed++; this._glint.visible = true; this._glintAge = 0;
    SoundManager.playCursor();
    this.drawPanel();
  };

  //---------------------------------------------------------------------------
  // CROWD
  //---------------------------------------------------------------------------
  /** One character's 3 x 4 block cut from its sheet into a bitmap of its own; hue > 0 recolours it. */
  Scene_Rummage.prototype.characterBlock = function (ci, hue, filter) {
    var e = this._req.cast[ci], sheet = this._sheets[ci];
    if (!sheet || !sheet.isReady() || sheet.width === 0) return null;
    var big = ImageManager.isBigCharacter(e.file), pw = sheet.width / (big ? 3 : 12), ph = sheet.height / (big ? 4 : 8);
    var bx = big ? 0 : (e.index % 4) * pw * 3, by = big ? 0 : Math.floor(e.index / 4) * ph * 4;
    var b = new Bitmap(Math.round(pw * 3), Math.round(ph * 4)), c = b.context, src = sheet._canvas || sheet._image;
    c.save(); if (hue) c.filter = filter || ('hue-rotate(' + hue + 'deg) saturate(1.25)');
    c.drawImage(src, bx, by, pw * 3, ph * 4, 0, 0, pw * 3, ph * 4); c.restore();
    // a recolour changes the CLOTHES: rotating the whole sheet turned faces and hands blue, teal and green (review
    // 2026-10-20), so every pixel the plain sheet draws in a skin tone is put back as drawn. The grey ghost stays grey.
    if (hue && !(filter && filter.indexOf('grayscale') >= 0)) keepSkin(b, src, bx, by, pw * 3, ph * 4);
    b._baseTexture.update();
    return { bmp: b, pw: pw, ph: ph };
  };

  /**
   * Is this a skin tone? Warm (red over green, green not under blue), neither grey nor vivid, pale to deep brown. A brown
   * belt or blond hair passes too and keeps its colour, which is how a dyed costume looks; a red or orange garment is
   * too saturated to pass and is recoloured.
   */
  function isSkin(r, g, bl) {
    var mx = r > g ? (r > bl ? r : bl) : (g > bl ? g : bl), mn = r < g ? (r < bl ? r : bl) : (g < bl ? g : bl), sat = mx ? (mx - mn) / mx : 0;
    return r > 60 && g > 30 && bl > 15 && r > g && r > bl && g >= bl * 0.85 && r - g > 12 && sat >= 0.12 && sat <= 0.68;
  }
  /** Copy the plain sheet's skin-tone pixels back over a recoloured block. Runs once per block while the scene is built (Probe §27a). */
  function keepSkin(b, src, sx, sy, sw, sh) {
    var w = b.width, h = b.height, tmp = document.createElement('canvas'); tmp.width = w; tmp.height = h;
    var tc = tmp.getContext('2d'); tc.drawImage(src, sx, sy, sw, sh, 0, 0, w, h);
    var od = tc.getImageData(0, 0, w, h).data, img = b.context.getImageData(0, 0, w, h), dd = img.data, n = 0;
    for (var i = 0; i < od.length; i += 4) if (od[i + 3] > 0 && isSkin(od[i], od[i + 1], od[i + 2])) { dd[i] = od[i]; dd[i + 1] = od[i + 1]; dd[i + 2] = od[i + 2]; dd[i + 3] = od[i + 3]; n++; }
    if (n) b.context.putImageData(img, 0, 0);
    b._csafSkin = n;
    return n;
  }

  /**
   * How different two blocks look: the mean channel difference over pixels opaque in either (read ONCE while the
   * scene is built, never in play: Probe §27a). A recolour of a grey or black costume can come out the same picture.
   */
  function blockDiff(a, b) {
    var w = a.bmp.width, h = a.bmp.height, da = a.bmp.context.getImageData(0, 0, w, h).data, db = b.bmp.context.getImageData(0, 0, w, h).data, sum = 0, n = 0;
    for (var i = 0; i < da.length; i += 4) { if (da[i + 3] < 64 && db[i + 3] < 64) continue; n++; sum += (Math.abs(da[i] - db[i]) + Math.abs(da[i + 1] - db[i + 1]) + Math.abs(da[i + 2] - db[i + 2])) / 3; }
    return n ? sum / n : 0;
  }
  var LOOKALIKE_MIN = 22;
  var FALLBACK_FILTERS = ['sepia(0.55) hue-rotate({h}deg) saturate(1.7) brightness(0.92)', 'invert(0.18) hue-rotate({h}deg) saturate(1.4)', 'brightness(0.62) saturate(1.5) hue-rotate({h}deg)'];

  Scene_Rummage.prototype.buildCrowd = function () {
    var d = deps(), L = this._L, q = this._req, S = L.S;
    // leave out every cast member whose sheet did not load, and say so; the target's index moves with them
    var okCast = [], okSheets = [], newTarget = -1, missing = [];
    for (var m = 0; m < q.cast.length; m++) {
      var sh = this._sheets[m];
      if (sh && sh.isReady() && !sh.isError() && sh.width > 0) { if (m === q.target) newTarget = okCast.length; okCast.push(q.cast[m]); okSheets.push(sh); }
      else missing.push(q.cast[m].file);
    }
    if (missing.length) console.warn('Rummage: character sheet(s) not found in img/characters, left out of the crowd: ' + missing.join(', '));
    this._castMissing = missing.length;
    if (newTarget < 0) { console.warn('Rummage: the character to find (' + q.cast[q.target].file + ') did not load; the crowd scene closes.'); this._aborted = true; this.popScene(); return; }
    q.cast = okCast; this._sheets = okSheets; q.target = newTarget;
    var tb = this.characterBlock(q.target, 0);
    if (!tb) { console.warn('Rummage: the target\'s character sheet did not load.'); this._aborted = true; this.popScene(); return; }
    this._fw = tb.pw; this._fh = tb.ph;
    // the back row is sized to the cast's own figure height, and nobody's feet go above its front line
    var top = d.C.backrowLine(q.ground, L.sh, tb.ph);
    this._top = top;
    var gb = new Bitmap(L.sw, L.sh); d.D.drawGround(gb.context, q.ground, L.sw, L.sh, q.seed, S, top, tb.ph); gb._baseTexture.update();
    this._groundSp = new Sprite(gb); this._groundSp.x = L.sx; this._groundSp.y = L.sy; this.addChild(this._groundSp);
    var st = d.C.crowdSetup({ w: L.sw, h: L.sh, seed: q.seed, n: q.walkers, cast: q.cast.length, target: q.target, lookalikes: q.lookalikes, fw: tb.pw, fh: tb.ph, top: top });
    this._st = st;
    // bake every (cast, colour) pair once; a lookalike that does not look different enough tries another recolour,
    // then becomes another cast member, so no walker but the target can be mistaken for it
    var cache = {}, self = this, dropped = 0, plain = { 0: tb };
    cache[q.target + ':0'] = tb;
    for (var i = 0; i < st.n; i++) {
      var ci = st.look[i], hue = st.hue[i], key = ci + ':' + hue;
      if (!cache[key]) {
        var blk = this.characterBlock(ci, hue);
        if (blk && ci === q.target && hue) {
          var tries = 0;
          while (blk && blockDiff(blk, tb) < LOOKALIKE_MIN && tries < FALLBACK_FILTERS.length) { blk = this.characterBlock(ci, hue, FALLBACK_FILTERS[tries].replace('{h}', String(hue))); tries++; }
          if (blk && blockDiff(blk, tb) < LOOKALIKE_MIN) blk = null;
        }
        cache[key] = blk;
      }
      if (!cache[key] && i !== 0) {
        // fall back to another cast member, plain
        var alt = (q.target + 1 + i) % q.cast.length;
        if (alt === q.target) alt = (alt + 1) % q.cast.length;
        if (alt !== q.target && q.cast.length > 1) { st.look[i] = alt; st.hue[i] = 0; key = alt + ':0'; if (!cache[key]) cache[key] = this.characterBlock(alt, 0); dropped++; }
      }
      if (!cache[key] && i !== 0) {
        // the target is the only cast member and no recolour reads as different: a grey shadow or a pale ghost of the
        // costume, whichever differs more. A walker is NEVER the target drawn plain (that would be a second answer).
        if (!cache['ghost']) {
          var g1 = this.characterBlock(q.target, 1, 'grayscale(1) brightness(0.35)'), g2 = this.characterBlock(q.target, 1, 'grayscale(1) brightness(1.8) contrast(0.6)');
          cache['ghost'] = g1 && g2 ? (blockDiff(g1, tb) >= blockDiff(g2, tb) ? g1 : g2) : (g1 || g2);
        }
        cache[key] = cache['ghost']; dropped++;
      }
    }
    this._lookDropped = dropped;
    // a contact shadow under every walker (one shared texture, one layer beneath them all, so it batches): without it
    // the crowd floats over the ground like stickers (review 2026-10-20)
    var shw = Math.round(tb.pw * 0.5), shh = Math.max(4, Math.round(tb.pw * 0.17)), shb = new Bitmap(shw * 2, shh * 2), shc = shb.context;
    var sg = shc.createRadialGradient(shw, shh, 0, shw, shh, shw); sg.addColorStop(0, 'rgba(14,8,4,0.5)'); sg.addColorStop(0.6, 'rgba(14,8,4,0.32)'); sg.addColorStop(1, 'rgba(14,8,4,0)');
    shc.save(); shc.translate(shw, shh); shc.scale(1, shh / shw); shc.translate(-shw, -shh); shc.fillStyle = sg; shc.beginPath(); shc.arc(shw, shh, shw, 0, Math.PI * 2); shc.fill(); shc.restore();
    shb._baseTexture.update();
    this._shadowLayer = new Sprite(); this._shadowLayer.x = L.sx; this._shadowLayer.y = L.sy; this.addChild(this._shadowLayer);
    this._shadows = [];
    for (var si = 0; si < st.n; si++) { var ss = new Sprite(shb); ss.anchor.x = 0.5; ss.anchor.y = 0.5; this._shadows.push(ss); this._shadowLayer.addChild(ss); }
    this._shadowLift = Math.round(tb.ph * 0.06);
    this._walkLayer = new Sprite(); this._walkLayer.x = L.sx; this._walkLayer.y = L.sy; this.addChild(this._walkLayer);
    this._walkers = [];
    for (var j = 0; j < st.n; j++) {
      var b = (j === 0 ? tb : cache[st.look[j] + ':' + st.hue[j]]) || cache['ghost'] || tb, sp = new Sprite(b.bmp);
      sp.anchor.x = 0.5; sp.anchor.y = 1; sp._pat = -1; sp._dir = -1; sp._pw = b.pw; sp._ph = b.ph; sp._idx = j;
      this._walkers.push(sp); this._walkLayer.addChild(sp);
    }
    this._inkBmp = new Bitmap(L.sw, L.sh); this._inkSp = new Sprite(this._inkBmp); this._inkSp.x = L.sx; this._inkSp.y = L.sy; this.addChild(this._inkSp);
    this.buildGlint();
    this._cursorX = L.sw / 2; this._cursorY = L.sh / 2; this._kbd = false;
    // a hand cursor for keyboard and pad players
    var hb = new Bitmap(28, 28), hc = hb.context;
    hc.fillStyle = 'rgba(255,240,205,0.95)'; hc.strokeStyle = 'rgba(40,25,10,0.95)'; hc.lineWidth = 2;
    hc.beginPath(); hc.moveTo(4, 2); hc.lineTo(4, 22); hc.lineTo(10, 16); hc.lineTo(16, 26); hc.lineTo(20, 24); hc.lineTo(14, 14); hc.lineTo(22, 14); hc.closePath(); hc.fill(); hc.stroke(); hb._baseTexture.update();
    this._hand = new Sprite(hb); this._hand.visible = false; this.addChild(this._hand);
    this._ringSp = null;
    this.updateWalkers();
  };

  /** Frames and depth order for the walkers. setFrame only when a pattern or facing changed; no allocation. */
  Scene_Rummage.prototype.updateWalkers = function () {
    var C = deps().C, st = this._st, ws = this._walkers, kids = this._walkLayer.children;
    for (var i = 0; i < st.n; i++) {
      var sp = ws[i], pat = C.patternOf(st, i), dir = st.dir[i];
      sp.x = Math.round(st.x[i]); sp.y = Math.round(st.y[i]);
      if (this._shadows) { var sh = this._shadows[i]; sh.x = sp.x; sh.y = sp.y - this._shadowLift; }
      if (pat !== sp._pat || dir !== sp._dir) { sp._pat = pat; sp._dir = dir; sp.setFrame(pat * sp._pw, (dir / 2 - 1) * sp._ph, sp._pw, sp._ph); }
    }
    for (var k = 0; k < st.n; k++) kids[k] = ws[st.order[k]];
  };

  Scene_Rummage.prototype.searchCrowd = function (x, y) {
    var d = deps(), st = this._st, hit = d.C.hitCrowd(st, x, y);
    if (hit === st.target) {
      this._foundCrowd = true;
      var rb = new Bitmap(Math.round(this._fw * 1.6), Math.round(this._fh * 1.4));
      d.D.drawRing(rb.context, rb.width / 2, rb.height / 2, Math.min(rb.width, rb.height) * 0.42, this._L.S, st.seed + ':found');
      rb._baseTexture.update();
      this._ringSp = new Sprite(rb); this._ringSp.anchor.x = 0.5; this._ringSp.anchor.y = 0.5; this._walkLayer.addChild(this._ringSp);
      SoundManager.playOk();
      this.drawPanel();
      this.finish(true);
    } else {
      this._misses++; this._penalty += P.missPenalty;
      d.D.drawMiss(this._inkBmp.context, x, y, this._L.S, st.seed + ':miss' + this._misses);
      this._inkBmp._baseTexture.update();
      SoundManager.playBuzzer();
      this.drawPanel();
    }
  };

  //---------------------------------------------------------------------------
  // The parchment
  //---------------------------------------------------------------------------
  Scene_Rummage.prototype.timeLeft = function () { var q = this._req; return q.seconds ? Math.max(0, q.seconds - Math.floor(this._frames / 60) - this._penalty) : -1; };

  /** Redraw the parchment's words (only when what it says changes: a find, a miss, a hint, the clock's second). */
  Scene_Rummage.prototype.drawPanel = function () {
    var L = this._L, S = L.S, q = this._req, secs = Math.floor(this._frames / 60), key = secs * 1e6 + this._misses * 1e3 + this._hintsUsed * 10 + (q.mode === 'spy' ? this.foundCount() : (this._foundCrowd ? 1 : 0)) + (this._done ? 0.5 : 0);
    if (key === this._panelKey) return;
    this._panelKey = key;
    if (!this._panel) { this._panel = new Sprite(new Bitmap(L.pw, L.ph)); this._panel.x = L.px; this._panel.y = L.py; this.addChild(this._panel); }
    var b = this._panel.bitmap, c = b.context, w = L.pw, h = L.ph, d = deps();
    // a portrait parchment is a wide strip under the scene: the words take the left part (cw), the clock, tally and seal
    // a column on the right (fx0..w). Landscape: cw = w and the foot runs across the bottom, as before.
    var tall = !!L.portrait, cw = tall ? Math.round(w * 0.64) : w, fx0 = tall ? cw : 0, fw0 = tall ? w - cw : w;
    c.clearRect(0, 0, w, h);
    b.fontFace = FONT; b.outlineWidth = 0; b.fontItalic = false; b.fontBold = false;
    var title = q.mode === 'spy' ? d.C.SURFACES[q.surface].name : GROUND_NAMES[q.ground];
    b.fontSize = Math.round(21 * S); b.textColor = INK; b.fontItalic = true;
    var top = Math.round(14 * S);
    txt(b, title, 0, top, cw, Math.round(28 * S), 'center');
    b.fontItalic = false;
    // an engraved rule with a lozenge
    c.strokeStyle = INK_SOFT; c.lineWidth = Math.max(1, S); var ry = top + Math.round(36 * S);
    c.beginPath(); c.moveTo(cw * 0.14, ry); c.lineTo(cw * 0.43, ry); c.moveTo(cw * 0.57, ry); c.lineTo(cw * 0.86, ry); c.stroke();
    c.fillStyle = INK_SOFT; c.beginPath(); c.moveTo(cw / 2, ry - 4 * S); c.lineTo(cw / 2 + 6 * S, ry); c.lineTo(cw / 2, ry + 4 * S); c.lineTo(cw / 2 - 6 * S, ry); c.closePath(); c.fill();
    var y = ry + Math.round(14 * S);
    this._panelRows = null;
    if (q.mode === 'spy' && tall) {
      b.fontSize = Math.round(12 * S); b.textColor = INK_SOFT;
      txt(b, 'F I N D   T H E S E', 0, y, cw, Math.round(18 * S), 'center');
      y += Math.round(24 * S);
      // the names in as many columns (up to 3) as it takes to give every row at least 20 px
      var scP = this._sc, nP = scP.targets.length, avail = h - y - Math.round(12 * S), cols = 1;
      while (cols < 3 && Math.ceil(nP / cols) * 20 * S > avail) cols++;
      var rowsN = Math.ceil(nP / cols), rowP = Math.round(Math.min(28 * S, avail / rowsN)), colW = (cw - 24 * S) / cols;
      b.fontSize = Math.round(Math.min(19 * S, rowP * 0.72));
      this._panelRows = { cols: cols, rows: rowsN, rowH: rowP, y0: y, colW: colW, header: y };
      for (var iP = 0; iP < nP; iP++) {
        var oP = scP.objects[scP.targets[iP]], fP = this._found[iP], colI = Math.floor(iP / rowsN), rowY = y + (iP % rowsN) * rowP, cx0 = 12 * S + colI * colW;
        b.textColor = fP ? 'rgba(58,29,14,0.42)' : INK;
        var twP = Math.min(colW - 8 * S, b.measureTextWidth(oP.name)), xs = Math.round(cx0 + (colW - twP) / 2);
        txt(b, oP.name, cx0 + 4 * S, rowY, colW - 8 * S, rowP, 'center');
        if (fP) d.D.drawStrike(c, xs, rowY + rowP * 0.55, xs + twP, S, scP.seed + ':strike' + iP);
      }
    } else if (q.mode === 'spy') {
      b.fontSize = Math.round(12 * S); b.textColor = INK_SOFT;
      txt(b, 'F I N D   T H E S E', 0, y, w, Math.round(18 * S), 'center');
      y += Math.round(26 * S);
      // the list sits in the middle of the free height and spreads into it: rows up to 50 px, so six names fill the
      // sheet instead of floating in a third of it (review 2026-10-20: ~80 px bare above, ~110 below)
      var sc = this._sc, free = h - y - 118 * S, rowH = Math.round(Math.min(50 * S, free / Math.max(1, sc.targets.length)));
      y += Math.max(0, Math.round((free - rowH * sc.targets.length) * 0.42));
      b.fontSize = Math.round(Math.min(23 * S, rowH * 0.64));
      for (var i = 0; i < sc.targets.length; i++) {
        var o = sc.objects[sc.targets[i]], found = this._found[i], name = o.name;
        b.textColor = found ? 'rgba(58,29,14,0.42)' : INK;
        var tw = Math.min(w - 36 * S, b.measureTextWidth(name)), x0 = Math.round((w - tw) / 2);
        txt(b, name, 18 * S, y, w - 36 * S, rowH, 'center');
        if (found) d.D.drawStrike(c, x0, y + rowH * 0.55, x0 + tw, S, sc.seed + ':strike' + i);
        y += rowH;
      }
    } else if (tall) {
      // portrait crowd card: the figure on the left, the name and what the player is up against beside it
      b.fontSize = Math.round(12 * S); b.textColor = INK_SOFT;
      txt(b, 'F I N D   T H I S   O N E', 0, y, cw, Math.round(18 * S), 'center');
      y += Math.round(22 * S);
      var tbP = this._walkers ? this._walkers[0] : null, room = h - y - Math.round(10 * S), tx0 = Math.round(16 * S);
      if (tbP) {
        var srcP = tbP.bitmap._canvas || tbP.bitmap._image, pwP = tbP._pw, phP = tbP._ph, zP = Math.max(1, Math.floor(Math.min((cw * 0.42) / pwP, room / phP))), fwP = pwP * zP, fhP = phP * zP, fyP = y + Math.round((room - fhP) / 2);
        // a round medallion (as in landscape), clear of the sheet's torn edge
        var rrP = Math.min(Math.max(fwP, fhP) * 0.56, room / 2 + 4 * S), fxP = Math.round(Math.max(20 * S, rrP + 14 * S - fwP / 2));
        c.save(); c.beginPath(); c.arc(fxP + fwP / 2, fyP + fhP / 2, rrP, 0, Math.PI * 2); c.fillStyle = 'rgba(120,84,40,0.16)'; c.fill();
        c.lineWidth = 2 * S; c.strokeStyle = INK_SOFT; c.stroke(); c.imageSmoothingEnabled = false;
        c.drawImage(srcP, pwP, 0, pwP, phP, fxP, fyP, fwP, fhP); c.restore();
        tx0 = fxP + fwP + Math.round(18 * S);
      }
      var tw0 = cw - tx0 - Math.round(8 * S), ty0 = y + Math.round(room / 2) - Math.round(40 * S);
      b.fontSize = Math.round(19 * S); b.textColor = INK;
      txt(b, q.cast[q.target].name, tx0, ty0, tw0, Math.round(26 * S), 'center');
      if (this._foundCrowd) { var nwP = Math.min(tw0, b.measureTextWidth(q.cast[q.target].name)); d.D.drawStrike(c, tx0 + (tw0 - nwP) / 2, ty0 + 14 * S, tx0 + (tw0 + nwP) / 2, S, q.seed + ':crowdstrike'); }
      var lookP = 0; for (var lp = 1; lp < this._st.n; lp++) if (this._st.look[lp] === q.target) lookP++;
      b.fontSize = Math.round(13 * S); b.textColor = INK_SOFT; b.fontItalic = true;
      txt(b, this._st.n + ' people ' + (GROUND_WHERE[q.ground] || GROUND_WHERE.plaza), tx0, ty0 + Math.round(34 * S), tw0, Math.round(20 * S), 'center');
      if (lookP) txt(b, lookP + (lookP === 1 ? ' wears' : ' wear') + ' the same clothes', tx0, ty0 + Math.round(54 * S), tw0, Math.round(20 * S), 'center');
      if (lookP) txt(b, 'in other colours', tx0, ty0 + Math.round(72 * S), tw0, Math.round(20 * S), 'center');
      b.fontItalic = false;
    } else {
      b.fontSize = Math.round(12 * S); b.textColor = INK_SOFT;
      txt(b, 'F I N D   T H I S   O N E', 0, y, w, Math.round(18 * S), 'center');
      y += Math.round(24 * S);
      // the portrait: the target's own front-facing frame at 2x in an oval frame. The card (portrait, name, two lines)
      // sits in the middle of the room above the clock, not at the top with a bare third below it (review 2026-10-20)
      var tb = this._walkers ? this._walkers[0] : null;
      if (tb) {
        var src = tb.bitmap._canvas || tb.bitmap._image, pw = tb._pw, ph = tb._ph, zoom = Math.max(1, Math.floor(Math.min((w * 0.62) / pw, (h * 0.36) / ph))), fw = pw * zoom, fh = ph * zoom, fx = Math.round((w - fw) / 2);
        var lookC = 0; for (var lc0 = 1; lc0 < this._st.n; lc0++) if (this._st.look[lc0] === q.target) lookC++;
        var cardH = fh + Math.round(48 * S) + Math.round((lookC ? 58 : 20) * S), roomC = h - Math.round(112 * S) - y;
        y += Math.max(0, Math.round((roomC - cardH) * 0.42));
        var fy = y;
        c.save(); c.beginPath(); c.ellipse(w / 2, fy + fh / 2, fw * 0.62, fh * 0.56, 0, 0, Math.PI * 2); c.fillStyle = 'rgba(120,84,40,0.16)'; c.fill();
        c.lineWidth = 2 * S; c.strokeStyle = INK_SOFT; c.stroke(); c.imageSmoothingEnabled = false;
        c.drawImage(src, pw, 0, pw, ph, fx, fy, fw, fh); c.restore();
        y = fy + fh + Math.round(10 * S);
      }
      b.fontSize = Math.round(19 * S); b.textColor = INK;
      txt(b, q.cast[q.target].name, 0, y, w, Math.round(26 * S), 'center');
      if (this._foundCrowd) { var nw = Math.min(w - 20 * S, b.measureTextWidth(q.cast[q.target].name)); d.D.drawStrike(c, (w - nw) / 2, y + 14 * S, (w + nw) / 2, S, q.seed + ':crowdstrike'); }
      y += Math.round(38 * S);
      // what the player is up against, in two short lines
      var look = 0; for (var li = 1; li < this._st.n; li++) if (this._st.look[li] === q.target) look++;
      b.fontSize = Math.round(13 * S); b.textColor = INK_SOFT; b.fontItalic = true;
      txt(b, this._st.n + ' people ' + (GROUND_WHERE[q.ground] || GROUND_WHERE.plaza), 0, y, w, Math.round(20 * S), 'center');
      if (look) txt(b, look + (look === 1 ? ' wears' : ' wear') + ' the same clothes', 0, y + Math.round(20 * S), w, Math.round(20 * S), 'center');
      if (look) txt(b, 'in other colours', 0, y + Math.round(38 * S), w, Math.round(20 * S), 'center');
      b.fontItalic = false;
    }
    // the foot: the clock, the tally, the hint seal
    var fy2 = tall ? Math.round(h / 2 - 46 * S) : h - Math.round(96 * S), left = this.timeLeft(), tsecs = left >= 0 ? left : secs + this._penalty, mm = Math.floor(tsecs / 60), ss = tsecs % 60;
    c.strokeStyle = INK_SOFT; c.lineWidth = Math.max(1, S); c.beginPath();
    if (tall) { c.moveTo(cw, Math.round(18 * S)); c.lineTo(cw, h - Math.round(18 * S)); } else { c.moveTo(w * 0.14, fy2 - 8 * S); c.lineTo(w * 0.86, fy2 - 8 * S); }
    c.stroke();
    b.fontSize = Math.round(26 * S); b.textColor = left >= 0 && left <= 10 ? '#8a1a10' : INK;
    txt(b, mm + ':' + (ss < 10 ? '0' : '') + ss, fx0, fy2, fw0, Math.round(32 * S), 'center');
    b.fontSize = Math.round(13 * S); b.textColor = INK_SOFT;
    var tally = q.mode === 'spy' ? (this.foundCount() + ' of ' + this._sc.targets.length + ' found') : (this._foundCrowd ? '1 of 1 found' : 'still looking');
    if (tall) {
      txt(b, tally, fx0, fy2 + Math.round(32 * S), fw0, Math.round(18 * S), 'center');
      txt(b, this._misses + (this._misses === 1 ? ' miss' : ' misses'), fx0, fy2 + Math.round(48 * S), fw0, Math.round(18 * S), 'center');
    } else txt(b, tally + '   ·   ' + this._misses + (this._misses === 1 ? ' miss' : ' misses'), 0, fy2 + Math.round(32 * S), w, Math.round(18 * S), 'center');
    var hl = q.hints - this._hintsUsed;
    this._hintRect = null;
    if (q.hints > 0) {
      var r = Math.round(13 * S), hx = fx0 + fw0 / 2 - Math.round(34 * S), hy = fy2 + Math.round((tall ? 80 : 66) * S);
      c.beginPath(); c.arc(hx, hy, r, 0, Math.PI * 2); c.fillStyle = hl > 0 ? 'rgb(150,26,30)' : 'rgba(120,90,70,0.4)'; c.fill();
      c.strokeStyle = 'rgba(60,10,10,0.6)'; c.lineWidth = Math.max(1, S); c.beginPath(); c.arc(hx, hy, r * 0.66, 0, Math.PI * 2); c.stroke();
      b.fontSize = Math.round(13 * S); b.textColor = hl > 0 ? '#f4e2c0' : 'rgba(240,220,190,0.7)';
      txt(b, String(hl), hx - r, hy - r + 1, r * 2, r * 2, 'center');
      // one word for every device: a phone, a pad or a mouse player has no W key to be told about (review 2026-10-20);
      // the seal itself is the button, and W / Page Down are in the help
      b.textColor = INK_SOFT; txt(b, 'hint', hx + r + 6 * S, hy - 10 * S, w, Math.round(20 * S), 'left');
      this._hintRect = { x: L.px + hx - r - 4 * S, y: L.py + hy - r - 4 * S, w: Math.round(120 * S), h: r * 2 + 8 * S };
    }
    b._baseTexture.update();
  };

  //---------------------------------------------------------------------------
  // The ending
  //---------------------------------------------------------------------------
  Scene_Rummage.prototype.finish = function (success) {
    if (this._done) return;
    this._done = true; this._success = !!success; this._doneAge = 0;
    var q = this._req, secs = Math.floor(this._frames / 60) + this._penalty, r = rec();
    var found = q.mode === 'spy' ? this.foundCount() : (this._foundCrowd ? 1 : 0), total = q.mode === 'spy' ? this._sc.targets.length : 1;
    r.count++;
    r.last = { mode: q.mode, place: q.mode === 'spy' ? q.surface : q.ground, found: found, total: total, seconds: secs, misses: this._misses, hints: this._hintsUsed, success: this._success, seed: String(q.seed) };
    if (P.varSeconds) $gameVariables.setValue(P.varSeconds, secs);
    if (P.varFound) $gameVariables.setValue(P.varFound, found);
    if (P.varMisses) $gameVariables.setValue(P.varMisses, this._misses);
    if (P.swSuccess) $gameSwitches.setValue(P.swSuccess, this._success);
    if (P.commonEvent) $gameTemp.reserveCommonEvent(P.commonEvent);
    if (this._lens) this._lens.visible = false;
    if (this._glint) this._glint.visible = false;
    // what was missed is ringed in a paler ink, so the player sees where it was
    if (q.mode === 'spy' && !this._success) {
      // ⛔ never name this `found`: a `var` here is the SAME variable as the count above (2026-10-20, the plaque read
      // "0,1,0,0,1,0 of 6"); the per-target flags are `hit`
      var d = deps(), sc = this._sc, hit = this._found, S = this._L.S;
      this.ink(function (c) {
        // pale cream ink with a dark edge: where each missed thing was, at a glance (red at 0.55 vanished on a busy
        // surface: review 2026-10-20), and never mistakable for one more find
        for (var i = 0; i < sc.targets.length; i++) if (!hit[i]) { var o = sc.objects[sc.targets[i]]; d.D.drawRing(c, o.x, o.y, o.a * 1.45, S, q.seed + ':missed' + i, true); }
      });
    }
    this.drawPanel();
    this.buildPlaque(found, total, secs);
  };

  Scene_Rummage.prototype.buildPlaque = function (found, total, secs) {
    var L = this._L, S = L.S, w = Math.round(Math.min(L.sw - 40 * S, 330 * S)), h = Math.round(118 * S), d = deps();
    var b = new Bitmap(w + Math.round(20 * S), h + Math.round(20 * S));
    d.D.drawParchment(b.context, Math.round(6 * S), Math.round(6 * S), w, h, this._req.seed + ':plaque', S);
    b.fontFace = FONT; b.outlineWidth = 0;
    b.fontSize = Math.round(26 * S); b.textColor = INK; b.fontItalic = true;
    var head = this._success ? (this._req.mode === 'spy' ? 'Found them all' : 'There they are') : (this.timeLeft() === 0 ? 'Out of time' : 'Set aside');
    txt(b, head, 0, Math.round(16 * S), b.width, Math.round(34 * S), 'center');
    // the sub-lines at 20 and 16 px (17 and 14 could not be read once a plate showed the board smaller: review 2026-10-20)
    b.fontItalic = false; b.fontSize = Math.round(20 * S); b.textColor = INK;
    var mm = Math.floor(secs / 60), ss = secs % 60;
    txt(b, found + ' of ' + total + '  ·  ' + mm + ':' + (ss < 10 ? '0' : '') + ss + '  ·  ' + this._misses + (this._misses === 1 ? ' miss' : ' misses'), 0, Math.round(56 * S), b.width, Math.round(24 * S), 'center');
    b.fontSize = Math.round(16 * S); b.textColor = INK_SOFT; txt(b, 'OK to continue', 0, Math.round(88 * S), b.width, Math.round(18 * S), 'center');
    b._baseTexture.update();
    this._plaqueText = { head: head, found: found, total: total, secs: secs };
    this._plaque = new Sprite(b); this._plaque.x = Math.round(L.sx + (L.sw - b.width) / 2); this._plaque.y = Math.round(L.sy + (L.sh - b.height) / 2); this._plaque.opacity = 0;
    this.addChild(this._plaque);
  };

  //---------------------------------------------------------------------------
  // The frame
  //---------------------------------------------------------------------------
  Scene_Rummage.prototype.update = function () {
    Scene_Base.prototype.update.call(this);
    if (!this._built) return;
    var q = this._req, L = this._L;
    if (q.mode === 'spy' && this._bakeAt < this._sc.objects.length) {
      // the intro: the objects settle onto the surface; OK or a click finishes it at once
      if (Input.isTriggered('ok') || TouchInput.isTriggered()) { this._bakePer = this._sc.objects.length; }
      this.bakeStep();
      return;
    }
    if (q.mode === 'crowd' && !this._done) { deps().C.stepCrowd(this._st); }
    if (q.mode === 'crowd') { this.updateWalkers(); if (this._ringSp) { var t = this._st.target; this._ringSp.x = this._st.x[t]; this._ringSp.y = this._st.y[t] - this._fh * 0.45; } }
    this.updateGlint();
    if (this._done) {
      this._doneAge++;
      if (this._plaque) this._plaque.opacity = Math.min(255, this._doneAge * 14);
      if (this._doneAge > 24 && (Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered())) this.popScene();
      return;
    }
    this._frames++;
    // pointer: the mouse moves the lens; the arrows move it for keyboard and pad players
    var dx = (Input.isPressed('right') ? 1 : 0) - (Input.isPressed('left') ? 1 : 0), dy = (Input.isPressed('down') ? 1 : 0) - (Input.isPressed('up') ? 1 : 0);
    if (dx || dy) { var sp = Input.isPressed('shift') ? 9 : 4; this._kbd = true; this._cursorX = Math.max(0, Math.min(L.sw, this._cursorX + dx * sp)); this._cursorY = Math.max(0, Math.min(L.sh, this._cursorY + dy * sp)); }
    var tx = TouchInput.x - L.sx, ty = TouchInput.y - L.sy, inside = tx >= 0 && ty >= 0 && tx < L.sw && ty < L.sh;
    if (TouchInput.isHovered() || TouchInput.isMoved() || TouchInput.isTriggered()) { if (inside) { this._cursorX = tx; this._cursorY = ty; this._kbd = false; } }
    var showLens = q.mode === 'spy' && (this._kbd || inside);
    if (this._lens) { this._lens.visible = showLens; if (showLens) this.placeLens(this._cursorX, this._cursorY); }
    if (this._hand) { this._hand.visible = this._kbd; this._hand.x = L.sx + this._cursorX - 4; this._hand.y = L.sy + this._cursorY - 2; }
    // a click or OK
    var hr = this._hintRect;
    if (TouchInput.isTriggered() && hr && TouchInput.x >= hr.x && TouchInput.y >= hr.y && TouchInput.x < hr.x + hr.w && TouchInput.y < hr.y + hr.h) this.useHint();
    else if (TouchInput.isTriggered() && inside) { if (q.mode === 'spy') this.searchSpy(tx, ty); else this.searchCrowd(tx, ty); }
    else if (Input.isTriggered('ok')) { if (q.mode === 'spy') this.searchSpy(this._cursorX, this._cursorY); else this.searchCrowd(this._cursorX, this._cursorY); }
    if (Input.isTriggered('pagedown')) this.useHint();
    if (P.allowCancel && (Input.isTriggered('cancel') || TouchInput.isCancelled())) { this.finish(false); return; }
    if (q.seconds && this.timeLeft() <= 0) { this.finish(false); return; }
    this.drawPanel();
  };

  Scene_Rummage.prototype.updateGlint = function () {
    var g = this._glint;
    if (!g || !g.visible) return;
    this._glintAge++;
    if (this._glintFollow && this._st) { g.x = this._L.sx + this._st.x[0]; g.y = this._L.sy + this._st.y[0] - this._fh * 0.55; }
    var t = this._glintAge, pulse = 0.65 + 0.35 * Math.sin(t * 0.25);
    g.scale.x = g.scale.y = pulse; g.rotation = t * 0.03; g.opacity = t > 150 ? Math.max(0, 255 - (t - 150) * 10) : 255;
    if (t > 176) g.visible = false;
  };

  CSAF.Rummage = {
    VERSION: '1.0.0', P: P, spy: spy, crowd: crowd, Scene_Rummage: Scene_Rummage, isSkin: isSkin,
    lastResult: function () { return $gameSystem && $gameSystem._csafRummage ? $gameSystem._csafRummage.last : null; },
    seenCount: function () { return $gameSystem && $gameSystem._csafRummage ? Object.keys($gameSystem._csafRummage.seen || {}).length : 0; }
  };
  window.Scene_Rummage = Scene_Rummage;
})();
