//=============================================================================
// RummageCore.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Rummage model: composes seek-and-find scenes from your database and proves every target can be found.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The model only: no drawing, no scene. Rummage.js (the scene and commands)
 * and RummageDraw.js (the renderer) read it. Any load order works.
 *
 * What it decides
 *   1. The find pool: your items, weapons and armours with an icon and a
 *      name, one record per icon and one per name, so a listed name can never
 *      be answered by a second record that shares its picture.
 *   2. The scene: the surface's own filler laid in layers, the decoys, the
 *      targets spread across the scene, a little filler over the top.
 *   3. The proof: every target keeps at least a set share of its outline in
 *      plain view. The parts that stay visible are what a click is tested
 *      against, so a hidden part can never be "found".
 *   4. The crowd: walkers that keep apart, and step aside when they would
 *      stand in front of the one the player is looking for.
 *
 * The same seed always composes the same scene; no Math.random anywhere.
 */

var CSAF = CSAF || {};

(function () {
  'use strict';

  /** FNV-1a for string seeds; numbers are used as they are. @returns {number} uint32 */
  function seedOf(s) {
    var n = Number(s);
    if (s !== '' && s !== null && s !== undefined && isFinite(n)) return (Math.floor(Math.abs(n)) >>> 0) || 1;
    var h = 2166136261, str = String(s);
    for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    return h || 1;
  }

  /** mulberry32: a small seeded generator, [0, 1). @param {number} a seed @returns {function(): number} */
  function rng(a) {
    a = a >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  //---------------------------------------------------------------------------
  // The filler corpus. One table, read by the composer (footprints) and the renderer (what to draw inside them).
  // len = long axis in px at scale 1 (min, max); asp = short axis / long axis. The renderer must keep every
  // mark INSIDE the ellipse (len x len*asp), because the visibility proof trusts it.
  //---------------------------------------------------------------------------
  var FILLERS = {
    coin:        { len: [17, 23], asp: 1.00, name: 'coin' },
    gemChip:     { len: [10, 15], asp: 0.80, name: 'gem chip' },
    chain:       { len: [34, 52], asp: 0.30, cap: 1, name: 'chain' },
    scale:       { len: [16, 22], asp: 0.82, name: 'dragon scale' },
    bone:        { len: [28, 40], asp: 0.34, cap: 1, name: 'bone' },
    bead:        { len: [30, 46], asp: 0.36, cap: 1, name: 'bead string' },
    ring:        { len: [15, 19], asp: 1.00, name: 'ring' },
    ribbon:      { len: [34, 50], asp: 0.42, cap: 1, name: 'ribbon' },
    button:      { len: [12, 16], asp: 1.00, name: 'button' },
    die:         { len: [15, 19], asp: 1.00, name: 'die' },
    card:        { len: [30, 36], asp: 0.70, name: 'playing card' },
    cork:        { len: [16, 21], asp: 0.62, cap: 1, name: 'cork' },
    candle:      { len: [26, 34], asp: 0.44, cap: 1, name: 'candle stub' },
    nutshell:    { len: [14, 18], asp: 0.80, name: 'nutshell' },
    leafOak:     { len: [28, 38], asp: 0.62, name: 'oak leaf' },
    leafMaple:   { len: [28, 36], asp: 0.94, name: 'maple leaf' },
    leafBirch:   { len: [20, 27], asp: 0.62, name: 'birch leaf' },
    acorn:       { len: [15, 19], asp: 0.72, name: 'acorn' },
    pinecone:    { len: [24, 31], asp: 0.62, name: 'pine cone' },
    twig:        { len: [36, 56], asp: 0.26, name: 'twig' },
    mushroom:    { len: [20, 27], asp: 0.92, name: 'mushroom' },
    snail:       { len: [16, 21], asp: 0.82, name: 'snail shell' },
    feather:     { len: [34, 48], asp: 0.30, name: 'feather' },
    berry:       { len: [14, 18], asp: 0.92, name: 'berry sprig' },
    scallop:     { len: [20, 27], asp: 0.94, name: 'scallop shell' },
    conch:       { len: [22, 29], asp: 0.56, name: 'cone shell' },
    starfish:    { len: [24, 32], asp: 1.00, name: 'starfish' },
    pebble:      { len: [12, 22], asp: 0.74, name: 'pebble' },
    seaGlass:    { len: [12, 17], asp: 0.72, name: 'sea glass' },
    kelp:        { len: [38, 58], asp: 0.30, name: 'kelp' },
    herb:        { len: [30, 42], asp: 0.42, name: 'herb sprig' },
    crystal:     { len: [16, 24], asp: 0.60, name: 'crystal' },
    vial:        { len: [30, 40], asp: 0.50, cap: 1, name: 'vial' },
    petal:       { len: [11, 15], asp: 0.66, name: 'petal' },
    quill:       { len: [40, 54], asp: 0.24, name: 'quill' },
    waxDrip:     { len: [12, 18], asp: 0.86, name: 'wax drip' },
    rope:        { len: [26, 34], asp: 1.00, name: 'rope coil' },
    rivet:       { len: [9, 12],  asp: 1.00, name: 'rivet' },
    coral:       { len: [22, 30], asp: 0.84, name: 'coral' },
    sherd:       { len: [16, 24], asp: 0.70, name: 'pot sherd' },
    paper:       { len: [34, 46], asp: 0.72, name: 'paper scrap' },
    inkBlot:     { len: [14, 22], asp: 0.84, name: 'ink blot' },
    waxSeal:     { len: [16, 20], asp: 1.00, name: 'wax seal' },
    flower:      { len: [18, 24], asp: 1.00, name: 'pressed flower' }
  };
  var FILLER_IDS = Object.keys(FILLERS);

  /**
   * The eight surfaces. fill = [kind, weight] pairs for the dense base layer; top = kinds allowed over the items
   * (the long, thin ones read as "lying on top"); cover = base coverage (sum of footprint areas / scene area).
   */
  var SURFACES = {
    hoard:   { name: 'Dragon Hoard',      fill: [['coin', 9], ['gemChip', 2], ['chain', 1], ['scale', 2], ['bone', 1], ['ring', 1]], top: ['coin', 'chain', 'bone', 'scale'], cover: 1.15 },
    velvet:  { name: 'Merchant\'s Cloth', fill: [['coin', 2], ['bead', 2], ['ring', 2], ['ribbon', 1], ['button', 3], ['gemChip', 1], ['waxSeal', 1]], top: ['ribbon', 'bead', 'coin'], cover: 0.80 },
    tavern:  { name: 'Tavern Table',      fill: [['die', 2], ['card', 2], ['cork', 2], ['candle', 1], ['nutshell', 3], ['coin', 2]], top: ['card', 'candle', 'cork'], cover: 0.80 },
    forest:  { name: 'Forest Floor',      fill: [['leafOak', 4], ['leafMaple', 3], ['leafBirch', 4], ['acorn', 2], ['pinecone', 1], ['twig', 2], ['mushroom', 1], ['snail', 1], ['feather', 1], ['berry', 1]], top: ['leafOak', 'leafMaple', 'leafBirch', 'twig', 'feather'], cover: 1.20 },
    beach:   { name: 'Low Tide',          fill: [['scallop', 2], ['conch', 2], ['starfish', 1], ['pebble', 5], ['seaGlass', 2], ['kelp', 2], ['snail', 1]], top: ['kelp', 'pebble', 'scallop'], cover: 0.85 },
    // vials, candle stubs and herbs make it a bench; petals at 4 and a bone read as candy and a dog's dinner (review 2026-10-20)
    bench:   { name: 'Alchemist\'s Bench', fill: [['vial', 2], ['herb', 2], ['crystal', 2], ['candle', 1], ['petal', 1], ['quill', 1], ['waxDrip', 1], ['berry', 1], ['inkBlot', 1]], top: ['herb', 'quill', 'vial'], cover: 0.80 },
    wreck:   { name: 'Sunken Wreck',      fill: [['kelp', 2], ['rope', 1], ['rivet', 3], ['coral', 2], ['sherd', 2], ['scallop', 1], ['pebble', 2], ['coin', 1], ['chain', 1]], top: ['kelp', 'chain', 'rope'], cover: 0.90 },
    library: { name: 'Library Desk',      fill: [['paper', 3], ['quill', 2], ['inkBlot', 2], ['waxSeal', 2], ['ribbon', 1], ['candle', 1], ['flower', 2], ['button', 1]], top: ['paper', 'quill', 'ribbon'], cover: 0.85 }
  };
  var SURFACE_IDS = Object.keys(SURFACES);

  var DIFFICULTY = {
    easy:   { minVisible: 0.80, topCover: 0.05, decoyMul: 2, baseMul: 0.75 },
    normal: { minVisible: 0.66, topCover: 0.11, decoyMul: 3, baseMul: 1.00 },
    hard:   { minVisible: 0.52, topCover: 0.18, decoyMul: 4, baseMul: 1.20 }
  };

  /** The default surface for a set of records (a kind or tag a surface suits), else seeded. */
  function surfaceFor(id, seed) {
    if (SURFACES[id]) return id;
    return SURFACE_IDS[Math.floor(rng(seedOf(String(seed) + ':surface'))() * SURFACE_IDS.length)];
  }

  //---------------------------------------------------------------------------
  // The find pool
  //---------------------------------------------------------------------------
  /**
   * Notetag reading. MZ keeps the space after the colon (Probe_Doctrine §35b), so every value is trimmed.
   * @returns {{skip:boolean, tags:Array<string>}}
   */
  function readTags(meta) {
    var out = { skip: false, tags: [] };
    if (!meta) return out;
    var v = meta.Rummage !== undefined ? meta.Rummage : meta.rummage;
    if (v === undefined || v === true) return out;
    String(v).split(',').forEach(function (t) {
      t = t.trim().toLowerCase();
      if (t === 'skip') out.skip = true; else if (t) out.tags.push(t);
    });
    return out;
  }

  /**
   * Build the find pool: one record per icon index and one per name (case-insensitive), first by kind order then id.
   * @param {Array<{key:string, kind:string, id:number, name:string, iconIndex:number, meta:object}>} records
   * @param {{kinds?:Array<string>, tag?:string, ids?:Array<string>}} opt  ids as "item:3", "weapon:7"
   * @returns {Array<{key:string, kind:string, id:number, name:string, iconIndex:number}>}
   */
  function buildPool(records, opt) {
    opt = opt || {};
    var kinds = opt.kinds && opt.kinds.length ? opt.kinds : null, tag = String(opt.tag || '').trim().toLowerCase();
    var ids = opt.ids && opt.ids.length ? opt.ids : null;
    var seenIcon = {}, seenName = {}, out = [];
    for (var i = 0; i < records.length; i++) {
      var r = records[i];
      if (!r) continue;
      var name = String(r.name || '').trim(), icon = Number(r.iconIndex);
      if (!name || !isFinite(icon) || icon <= 0) continue;
      var t = readTags(r.meta);
      if (t.skip) continue;
      if (kinds && kinds.indexOf(r.kind) < 0) continue;
      if (ids && ids.indexOf(r.kind + ':' + r.id) < 0) continue;
      if (tag && t.tags.indexOf(tag) < 0) continue;
      var nk = name.toLowerCase();
      if (seenIcon[icon] || seenName[nk]) continue;
      seenIcon[icon] = 1; seenName[nk] = 1;
      out.push({ key: r.kind + ':' + r.id, kind: r.kind, id: r.id, name: name, iconIndex: icon });
    }
    return out;
  }

  /** Seeded Fisher-Yates over a copy. */
  function shuffled(arr, R) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(R() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }

  /**
   * Targets first from the seeded order, decoys after. The pool is already icon- and name-unique, so no decoy can
   * share a target's picture or name.
   * @returns {{targets:Array, decoys:Array}}
   */
  function pickFinds(pool, count, decoys, seed) {
    var order = shuffled(pool, rng(seedOf(String(seed) + ':finds')));
    var n = Math.max(0, Math.min(count, order.length));
    return { targets: order.slice(0, n), decoys: order.slice(n, n + Math.max(0, decoys)) };
  }

  //---------------------------------------------------------------------------
  // Composition
  //---------------------------------------------------------------------------
  var T_FILLER = 0, T_DECOY = 1, T_TARGET = 2;
  var K = 9;              // the visibility sample grid per target (9 x 9 over its box, those inside the circle kept)
  var ICON_R = 0.42;      // an icon's footprint radius as a share of its drawn size (MZ icons fill the middle of the cell)

  /**
   * Is (px, py) inside object o's footprint? Circles for icons and round fillers, a capsule (a bar with round ends,
   * radius b, overall length 2a) for the long thin kinds marked cap, oriented ellipses otherwise.
   */
  function covers(o, px, py) {
    var dx = px - o.x, dy = py - o.y;
    if (o.a === o.b) return dx * dx + dy * dy <= o.a * o.a;
    var c = o.cos, s = o.sin, u = dx * c + dy * s, v = -dx * s + dy * c;
    if (o.cap) { var e = o.a - o.b, du = u > e ? u - e : u < -e ? u + e : 0; return du * du + v * v <= o.b * o.b; }
    return (u * u) / (o.a * o.a) + (v * v) / (o.b * o.b) <= 1;
  }

  function weighted(pairs, R) {
    var tot = 0, i;
    for (i = 0; i < pairs.length; i++) tot += pairs[i][1];
    var x = R() * tot;
    for (i = 0; i < pairs.length; i++) { x -= pairs[i][1]; if (x <= 0) return pairs[i][0]; }
    return pairs[pairs.length - 1][0];
  }

  function makeFiller(kind, x, y, R, scale) {
    var f = FILLERS[kind], len = (f.len[0] + (f.len[1] - f.len[0]) * R()) * scale, ang = R() * Math.PI * 2;
    var a = len / 2, b = f.asp >= 0.999 ? a : a * f.asp;
    return { t: T_FILLER, kind: kind, x: x, y: y, a: a, b: b, cap: f.cap ? 1 : 0, ang: ang, cos: Math.cos(ang), sin: Math.sin(ang), v: R(), w: R() };
  }

  /**
   * Compose one scene.
   * @param {object} o
   * @param {number} o.w scene width  @param {number} o.h scene height
   * @param {string} o.surface  one of SURFACE_IDS
   * @param {*} o.seed
   * @param {Array} o.targets  pool records  @param {Array} o.decoys pool records
   * @param {number} [o.itemPx=32] drawn icon size  @param {number} [o.fillScale=1]
   * @param {string} [o.difficulty='normal']
   * @returns {{w:number,h:number,surface:string,seed:string,objects:Array,targets:Array<number>,vis:Float32Array,
   *            visStart:Int32Array,visCount:Int32Array,visTotal:Int32Array,proof:Array<number>,dropped:number}}
   */
  function compose(o) {
    var w = o.w, h = o.h, sid = SURFACES[o.surface] ? o.surface : 'hoard', S = SURFACES[sid];
    var D = DIFFICULTY[o.difficulty] || DIFFICULTY.normal;
    var px = Math.max(8, o.itemPx || 32), fs = o.fillScale || 1, R = rng(seedOf(String(o.seed) + ':' + sid + ':' + w + 'x' + h));
    var ir = px * ICON_R, objs = [], i, j;
    // 1. the base layer: stratified cells sized from the surface's mean footprint, so the cover is even
    var meanA = 0, wt = 0;
    for (i = 0; i < S.fill.length; i++) { var F = FILLERS[S.fill[i][0]], L = (F.len[0] + F.len[1]) / 2 * fs; meanA += Math.PI * (L / 2) * (L / 2 * F.asp) * S.fill[i][1]; wt += S.fill[i][1]; }
    meanA /= wt;
    var nBase = Math.round(w * h * S.cover * D.baseMul / meanA), cell = Math.sqrt(w * h / Math.max(1, nBase));
    var cols = Math.max(1, Math.round(w / cell)), rows = Math.max(1, Math.round(h / cell)), cw = w / cols, ch = h / rows;
    var cells = [];
    for (i = 0; i < cols * rows; i++) cells.push(i);
    cells = shuffled(cells, R);
    for (i = 0; i < cells.length; i++) {
      var cx = (cells[i] % cols + R()) * cw, cy = (Math.floor(cells[i] / cols) + R()) * ch;
      objs.push(makeFiller(weighted(S.fill, R), cx, cy, R, fs));
    }
    // 2. decoys and targets on stratified cells inside a margin, targets spaced apart
    var nItems = o.targets.length + o.decoys.length, m = ir + 4;
    var icols = Math.max(1, Math.round(Math.sqrt(nItems * (w - 2 * m) / Math.max(1, h - 2 * m)))), irows = Math.max(1, Math.ceil(nItems / icols));
    while (icols * irows < nItems * 1.6) { if ((w - 2 * m) / icols > (h - 2 * m) / irows) icols++; else irows++; }
    var icw = (w - 2 * m) / icols, ich = (h - 2 * m) / irows, slots = [];
    for (i = 0; i < icols * irows; i++) slots.push(i);
    slots = shuffled(slots, R);
    var placed = [], si = 0;
    function slotPoint(k) { return [m + (k % icols + 0.18 + R() * 0.64) * icw, m + (Math.floor(k / icols) + 0.18 + R() * 0.64) * ich]; }
    // decoys first (lower in z), then targets, each target at least 1.7 icons from every other item centre
    for (i = 0; i < o.decoys.length && si < slots.length; i++) {
      var dp = slotPoint(slots[si++]);
      objs.push({ t: T_DECOY, icon: o.decoys[i].iconIndex, key: o.decoys[i].key, name: o.decoys[i].name, x: dp[0], y: dp[1], a: ir, b: ir, ang: 0, cos: 1, sin: 0, q: Math.floor(R() * 4), flip: R() < 0.5 ? 1 : 0, v: R(), w: R() });
      placed.push(dp);
    }
    var targetIdx = [];
    for (i = 0; i < o.targets.length; i++) {
      var tp = null;
      for (var tries = 0; tries < 400 && !tp; tries++) {
        var cand = tries < slots.length - si ? slotPoint(slots[si + tries]) : [m + R() * (w - 2 * m), m + R() * (h - 2 * m)];
        var ok = true;
        for (j = 0; j < targetIdx.length && ok; j++) { var q = objs[targetIdx[j]], ddx = q.x - cand[0], ddy = q.y - cand[1]; if (ddx * ddx + ddy * ddy < (px * 1.7) * (px * 1.7)) ok = false; }
        if (ok) tp = cand;
      }
      if (!tp) tp = [m + R() * (w - 2 * m), m + R() * (h - 2 * m)];
      si++;
      targetIdx.push(objs.length);
      objs.push({ t: T_TARGET, icon: o.targets[i].iconIndex, key: o.targets[i].key, name: o.targets[i].name, x: tp[0], y: tp[1], a: ir, b: ir, ang: 0, cos: 1, sin: 0, q: Math.floor(R() * 4), flip: R() < 0.5 ? 1 : 0, v: R(), w: R() });
    }
    // a decoy that would sit over a target is impossible (decoys are lower in z); one that sits UNDER a target is fine.
    // 3. the visibility samples of every target, then the top layer, refusing any piece that would break the proof
    var nT = targetIdx.length, per = [], total = new Int32Array(nT);
    for (i = 0; i < nT; i++) {
      var to = objs[targetIdx[i]], pts = [];
      for (var gy = 0; gy < K; gy++) for (var gx = 0; gx < K; gx++) {
        var sx = to.x - to.a + (gx + 0.5) * (2 * to.a / K), sy = to.y - to.a + (gy + 0.5) * (2 * to.a / K);
        if ((sx - to.x) * (sx - to.x) + (sy - to.y) * (sy - to.y) <= to.a * to.a) pts.push(sx, sy, 1);
      }
      // later targets in z can cover earlier ones only at the spacing floor; mark those samples hidden now
      for (j = i + 1; j < nT; j++) { var tj = objs[targetIdx[j]]; for (var k = 0; k < pts.length; k += 3) if (pts[k + 2] && covers(tj, pts[k], pts[k + 1])) pts[k + 2] = 0; }
      per.push(pts); total[i] = pts.length / 3;
    }
    function visibleShare(ti) { var pts = per[ti], n = 0; for (var k = 0; k < pts.length; k += 3) n += pts[k + 2]; return n / (pts.length / 3); }
    var topArea = w * h * D.topCover, area = 0, dropped = 0, guard = 0;
    while (area < topArea && guard++ < 2000) {
      var kind = S.top[Math.floor(R() * S.top.length)];
      var f = makeFiller(kind, R() * w, R() * h, R, fs * 1.08);
      // would it break any target's proof?
      var breaks = false;
      for (i = 0; i < nT && !breaks; i++) {
        var to2 = objs[targetIdx[i]], reach = to2.a + f.a;
        if (Math.abs(f.x - to2.x) > reach || Math.abs(f.y - to2.y) > reach) continue;
        var pts2 = per[i], vis = 0, n2 = pts2.length / 3;
        for (var k2 = 0; k2 < pts2.length; k2 += 3) if (pts2[k2 + 2] && !covers(f, pts2[k2], pts2[k2 + 1])) vis++;
        if (vis / n2 < D.minVisible) breaks = true;
      }
      if (breaks) { dropped++; continue; }
      for (i = 0; i < nT; i++) { var pts3 = per[i]; for (var k3 = 0; k3 < pts3.length; k3 += 3) if (pts3[k3 + 2] && covers(f, pts3[k3], pts3[k3 + 1])) pts3[k3 + 2] = 0; }
      f.top = 1;
      objs.push(f);
      area += Math.PI * f.a * f.b;
    }
    // 4. the proof and the visible samples, packed for an allocation-free hit test
    var vStart = new Int32Array(nT), vCount = new Int32Array(nT), nv = 0, proof = [];
    for (i = 0; i < nT; i++) { var c0 = 0; for (var k4 = 0; k4 < per[i].length; k4 += 3) c0 += per[i][k4 + 2]; nv += c0; }
    var vis2 = new Float32Array(nv * 2), at = 0;
    for (i = 0; i < nT; i++) {
      vStart[i] = at; var pp = per[i];
      for (var k5 = 0; k5 < pp.length; k5 += 3) if (pp[k5 + 2]) { vis2[at * 2] = pp[k5]; vis2[at * 2 + 1] = pp[k5 + 1]; at++; }
      vCount[i] = at - vStart[i];
      proof.push(Math.round(visibleShare(i) * 1000) / 1000);
    }
    return { w: w, h: h, surface: sid, seed: String(o.seed), difficulty: o.difficulty || 'normal', minVisible: D.minVisible, itemPx: px,
      objects: objs, targets: targetIdx, vis: vis2, visStart: vStart, visCount: vCount, visTotal: total, proof: proof, dropped: dropped };
  }

  /**
   * Which target (index into scene.targets) a click at (x, y) finds: the first not-yet-found target with a VISIBLE
   * sample within tol px. -1 for none. No allocation.
   * @param {object} sc compose() result  @param {Uint8Array|Array} found  1 = already found
   */
  function hitSpy(sc, x, y, tol, found) {
    var t2 = tol * tol, best = -1, bestD = t2;
    for (var i = 0; i < sc.targets.length; i++) {
      if (found && found[i]) continue;
      var s = sc.visStart[i], e = s + sc.visCount[i], v = sc.vis;
      for (var k = s; k < e; k++) { var dx = v[k * 2] - x, dy = v[k * 2 + 1] - y, d = dx * dx + dy * dy; if (d <= bestD) { bestD = d; best = i; } }
    }
    return best;
  }

  /** The object index drawn topmost at (x, y), or -1 (for "what did the player click instead"). No allocation. */
  function topAt(sc, x, y) {
    for (var i = sc.objects.length - 1; i >= 0; i--) if (covers(sc.objects[i], x, y)) return i;
    return -1;
  }

  //---------------------------------------------------------------------------
  // The crowd
  //---------------------------------------------------------------------------
  /**
   * A crowd: walker 0 is the target; `lookalikes` walkers wear the target's own sheet in another colour; the rest are
   * the other cast members, each drawn plain once and then recoloured. No walker other than 0 is the target as drawn.
   * @param {object} o {w, h, seed, n, cast (number of cast entries), target (cast index), lookalikes, fw, fh, hues}
   * @returns {object} typed-array state for stepCrowd
   */
  function crowdSetup(o) {
    var n = Math.max(2, Math.min(80, o.n | 0)), R = rng(seedOf(String(o.seed) + ':crowd')), fw = o.fw, fh = o.fh;
    var hues = o.hues && o.hues.length ? o.hues : [55, 110, 165, 215, 270, 320];
    // the feet line: no walker's feet go above it, so everyone stands IN FRONT of the ground's back row (stalls, tents,
    // the quay edge), which is baked into the ground and can therefore never be drawn over a person by mistake
    var top = Math.max(fh * 0.95, Number(o.top) > 0 ? Number(o.top) : 0);
    var st = { n: n, w: o.w, h: o.h, fw: fw, fh: fh, top: top, s: seedOf(String(o.seed) + ':walk') >>> 0,
      x: new Float32Array(n), y: new Float32Array(n), vx: new Float32Array(n), vy: new Float32Array(n), hd: new Float32Array(n),
      turn: new Float32Array(n), dist: new Float32Array(n), dir: new Uint8Array(n), look: new Int16Array(n), hue: new Int16Array(n),
      speed: new Float32Array(n), order: new Int16Array(n), pause: new Float32Array(n), target: 0 };
    var cast = Math.max(1, o.cast | 0), tgt = Math.max(0, Math.min(cast - 1, o.target | 0)), look = Math.max(0, Math.min(n - 1, o.lookalikes | 0));
    var others = [];
    for (var c = 0; c < cast; c++) if (c !== tgt) others.push(c);
    var uses = {};
    for (var i = 0; i < n; i++) {
      var L, H = 0;
      if (i === 0) L = tgt;
      else if (i <= look || !others.length) { L = tgt; H = hues[(i - 1) % hues.length]; }
      else { L = others[(i - look - 1) % others.length]; var u = uses[L] || 0; uses[L] = u + 1; H = u === 0 ? 0 : hues[(u - 1 + L) % hues.length]; }
      st.look[i] = L; st.hue[i] = H;
    }
    // spread on a jittered grid, the target somewhere in the middle band so it starts reachable
    var span = o.h - top, gc = Math.max(1, Math.round(Math.sqrt(n * o.w / Math.max(1, span)))), gr = Math.max(1, Math.ceil(n / gc)), mx = fw * 0.5, my = top + fh * 0.12;
    var spots = [];
    for (i = 0; i < gc * gr; i++) spots.push(i);
    spots = shuffled(spots, R);
    for (i = 0; i < n; i++) {
      var sp = spots[i % spots.length];
      st.x[i] = mx + ((sp % gc) + 0.2 + R() * 0.6) * ((o.w - 2 * mx) / gc);
      st.y[i] = my + (Math.floor(sp / gc) + 0.2 + R() * 0.6) * ((o.h - my - fh * 0.15) / gr);
      st.hd[i] = R() * Math.PI * 2; st.turn[i] = 30 + R() * 120; st.speed[i] = 0.55 + R() * 0.5; st.order[i] = i;
      st.pause[i] = R() < 0.25 ? R() * 90 : 0;
      st.dir[i] = 2;
    }
    depthOrder(st);
    return st;
  }

  /**
   * Where a ground's back row (market stalls, fair tents, the quay edge and its cargo) meets the walking ground, in
   * scene pixels: a share of the height, never less than two figures tall so a stall stands taller than a person.
   * @param {string} ground plaza | meadow | quay
   * @param {number} h scene height
   * @param {number} fh one character frame's height
   */
  var BACKROW = { plaza: 0.25, meadow: 0.23, quay: 0.27 };
  function backrowLine(ground, h, fh) {
    var share = BACKROW[ground] !== undefined ? BACKROW[ground] : BACKROW.plaza;
    return Math.round(Math.min(h * 0.45, Math.max(fh * 1.9, h * share)));
  }

  /** The walk RNG lives in the state (st.s), so stepping allocates nothing. */
  function nextRand(st) {
    var a = st.s = (st.s + 0x6D2B79F5) >>> 0;
    var t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  /**
   * One frame of walking: wander, keep apart, step aside from in front of the target, stay inside. No allocation.
   * @param {object} st crowdSetup() state
   */
  function stepCrowd(st) {
    // personal space: wide enough that two walkers never fuse into one double figure (0.46 x 0.22 let them: review 2026-10-20)
    var n = st.n, fw = st.fw, fh = st.fh, sepX = fw * 0.58, sepY = fh * 0.27, i, j;
    var tx = st.x[st.target], ty = st.y[st.target];
    for (i = 0; i < n; i++) {
      if (st.pause[i] > 0) { st.pause[i]--; st.vx[i] *= 0.8; st.vy[i] *= 0.8; continue; }
      if (--st.turn[i] <= 0) { st.hd[i] += (nextRand(st) - 0.5) * 2.4; st.turn[i] = 40 + nextRand(st) * 140; if (nextRand(st) < 0.18) st.pause[i] = 30 + nextRand(st) * 70; }
      var ax = Math.cos(st.hd[i]) * st.speed[i], ay = Math.sin(st.hd[i]) * st.speed[i] * 0.7;
      // separation
      for (j = 0; j < n; j++) {
        if (j === i) continue;
        var dx = st.x[i] - st.x[j], dy = st.y[i] - st.y[j], ex = dx / sepX, ey = dy / sepY, d2 = ex * ex + ey * ey;
        if (d2 < 1 && d2 > 1e-6) { var push = (1 - d2) * 1.6; var dl = Math.sqrt(d2); ax += (ex / dl) * push; ay += (ey / dl) * push * 0.6; }
      }
      // in front of the target (lower on screen, overlapping its body): step aside
      if (i !== st.target && st.y[i] > ty - fh * 0.1 && st.y[i] - ty < fh * 1.0 && Math.abs(st.x[i] - tx) < fw * 0.8) ax += (st.x[i] >= tx ? 1 : -1) * 2.6;
      // ...and in a dense crowd the target also steps out from behind whoever covers it: sideways and a little forward
      if (i === st.target) {
        for (j = 0; j < n; j++) {
          if (j === i || st.y[j] <= ty || st.y[j] - ty > fh * 0.86 || Math.abs(st.x[j] - tx) > fw * 0.6) continue;
          ax += (tx >= st.x[j] ? 1 : -1) * 1.7; ay += 0.8;
        }
      }
      // walls
      var m = fw * 0.45;
      if (st.x[i] < m) ax += (m - st.x[i]) * 0.08; if (st.x[i] > st.w - m) ax -= (st.x[i] - (st.w - m)) * 0.08;
      if (st.y[i] < st.top + fh * 0.12) ay += (st.top + fh * 0.12 - st.y[i]) * 0.08; if (st.y[i] > st.h - fh * 0.08) ay -= (st.y[i] - (st.h - fh * 0.08)) * 0.08;
      st.vx[i] = st.vx[i] * 0.82 + ax * 0.18; st.vy[i] = st.vy[i] * 0.82 + ay * 0.18;
      var sp = Math.sqrt(st.vx[i] * st.vx[i] + st.vy[i] * st.vy[i]), cap = st.speed[i] * 1.6;
      if (sp > cap) { st.vx[i] *= cap / sp; st.vy[i] *= cap / sp; sp = cap; }
      st.x[i] += st.vx[i]; st.y[i] += st.vy[i]; st.dist[i] += sp;
      if (sp > 0.12) st.dir[i] = Math.abs(st.vx[i]) > Math.abs(st.vy[i]) * 1.1 ? (st.vx[i] > 0 ? 6 : 4) : (st.vy[i] > 0 ? 2 : 8);
      // a wall reached turns the heading back inside
      if (st.x[i] < 2 || st.x[i] > st.w - 2 || st.y[i] < st.top || st.y[i] > st.h) { st.hd[i] += Math.PI; st.x[i] = Math.max(2, Math.min(st.w - 2, st.x[i])); st.y[i] = Math.max(st.top, Math.min(st.h, st.y[i])); }
    }
    depthOrder(st);
  }

  /** The walking pattern (0, 1, 2, 1) from distance walked; 1 when standing. */
  function patternOf(st, i) {
    var sp = Math.abs(st.vx[i]) + Math.abs(st.vy[i]);
    if (sp < 0.12) return 1;
    var p = Math.floor(st.dist[i] / 7) % 4;
    return p === 3 ? 1 : p;
  }

  /** Insertion sort of st.order by feet y (back to front). In place, no allocation; the order is nearly sorted each frame. */
  function depthOrder(st) {
    var o = st.order, y = st.y;
    for (var i = 1; i < o.length; i++) { var v = o[i], yv = y[v], j = i - 1; while (j >= 0 && y[o[j]] > yv) { o[j + 1] = o[j]; j--; } o[j + 1] = v; }
  }

  /** The body box a click is tested against, as a share of the frame (feet at y, centred on x). */
  var BODY = { x0: -0.30, x1: 0.30, y0: -0.86, y1: -0.04 };

  /** The walker drawn in front at (x, y) whose body box holds the point, or -1. No allocation. */
  function hitCrowd(st, x, y) {
    for (var k = st.n - 1; k >= 0; k--) {
      var i = st.order[k];
      if (x >= st.x[i] + BODY.x0 * st.fw && x <= st.x[i] + BODY.x1 * st.fw && y >= st.y[i] + BODY.y0 * st.fh && y <= st.y[i] + BODY.y1 * st.fh) return i;
    }
    return -1;
  }

  /** Share of the target's body box that no walker in front of it covers (sampled 8 x 8). For probes and the gate. */
  function targetVisibleShare(st) {
    var t = st.target, n = 0, vis = 0;
    for (var gy = 0; gy < 8; gy++) for (var gx = 0; gx < 8; gx++) {
      var px = st.x[t] + (BODY.x0 + (BODY.x1 - BODY.x0) * (gx + 0.5) / 8) * st.fw, py = st.y[t] + (BODY.y0 + (BODY.y1 - BODY.y0) * (gy + 0.5) / 8) * st.fh;
      n++;
      var hidden = false;
      for (var j = 0; j < st.n && !hidden; j++) {
        if (j === t || st.y[j] <= st.y[t]) continue;
        if (px >= st.x[j] + BODY.x0 * st.fw && px <= st.x[j] + BODY.x1 * st.fw && py >= st.y[j] + BODY.y0 * st.fh && py <= st.y[j] + BODY.y1 * st.fh) hidden = true;
      }
      if (!hidden) vis++;
    }
    return vis / n;
  }

  CSAF.RummageCore = {
    VERSION: '1.0.0', FILLERS: FILLERS, FILLER_IDS: FILLER_IDS, SURFACES: SURFACES, SURFACE_IDS: SURFACE_IDS, DIFFICULTY: DIFFICULTY,
    T_FILLER: T_FILLER, T_DECOY: T_DECOY, T_TARGET: T_TARGET, ICON_R: ICON_R, BODY: BODY,
    seedOf: seedOf, rng: rng, readTags: readTags, buildPool: buildPool, pickFinds: pickFinds, surfaceFor: surfaceFor,
    compose: compose, covers: covers, hitSpy: hitSpy, topAt: topAt,
    BACKROW: BACKROW, backrowLine: backrowLine, crowdSetup: crowdSetup, stepCrowd: stepCrowd, patternOf: patternOf, depthOrder: depthOrder, hitCrowd: hitCrowd, targetVisibleShare: targetVisibleShare
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.RummageCore;
