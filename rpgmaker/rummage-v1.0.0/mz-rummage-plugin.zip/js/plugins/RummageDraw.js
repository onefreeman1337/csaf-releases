//=============================================================================
// RummageDraw.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Rummage renderer: draws the surfaces, the filler, your icons, the ink and the lens. No image files.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The renderer only: canvas drawing, no scene, no engine state. Rummage.js
 * calls it while a scene is being built, never in the middle of play.
 *
 * Everything here is drawn as vector paths from a seed: eight surfaces, more
 * than forty kinds of clutter, the parchment list, the ink that rings a find
 * and strikes its name, the brass lens and three crowd grounds. Your icons are
 * drawn at whole-number scale with a fine outline and a contact shadow so they
 * read on a busy ground. Every piece of clutter stays inside the outline the
 * model gave it, which is what lets the model promise each listed item can be
 * seen.
 */

var CSAF = CSAF || {};

(function () {
  'use strict';

  function core() {
    var C = CSAF.RummageCore;
    if (!C) throw new Error('Rummage needs RummageCore.js installed and ON.');
    return C;
  }

  //---------------------------------------------------------------------------
  // colour helpers (all colours are [r, g, b] arrays; css() writes them)
  //---------------------------------------------------------------------------
  function clamp8(v) { return v < 0 ? 0 : v > 255 ? 255 : Math.round(v); }
  function css(c, a) { return a === undefined || a >= 1 ? 'rgb(' + clamp8(c[0]) + ',' + clamp8(c[1]) + ',' + clamp8(c[2]) + ')' : 'rgba(' + clamp8(c[0]) + ',' + clamp8(c[1]) + ',' + clamp8(c[2]) + ',' + a + ')'; }
  /** Lighten (k > 0) toward white or darken (k < 0) toward black, by a share. */
  function tone(c, k) { return k >= 0 ? [c[0] + (255 - c[0]) * k, c[1] + (255 - c[1]) * k, c[2] + (255 - c[2]) * k] : [c[0] * (1 + k), c[1] * (1 + k), c[2] * (1 + k)]; }
  function mix(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }
  function pick(list, v) { return list[Math.min(list.length - 1, Math.floor(v * list.length))]; }

  /** A tiny seeded generator for texture (never game logic). */
  function rnd(seed) { var C = core(); return C.rng(C.seedOf(seed)); }

  var SHADOW = 'rgba(18,10,4,0.42)';
  /** Fill the current path with a contact shadow toward the lower right (screen space), then clear the shadow. */
  function bodyFill(c, style, s) {
    c.save();
    c.shadowColor = SHADOW; c.shadowBlur = 1.6 * s; c.shadowOffsetX = 1.4 * s; c.shadowOffsetY = 2.0 * s;
    if (!DRAW.shadows) { c.shadowColor = 'rgba(0,0,0,0)'; c.shadowBlur = 0; c.shadowOffsetX = 0; c.shadowOffsetY = 0; }
    c.fillStyle = style; c.fill();
    c.restore();
  }
  /** A radial gradient whose bright side faces the light (L is the light direction in the object's own frame). */
  function litGrad(c, r, base, L, hi, lo) {
    var g = c.createRadialGradient(L.x * r * 0.45, L.y * r * 0.45, r * 0.05, 0, 0, r * 1.05);
    g.addColorStop(0, css(tone(base, hi === undefined ? 0.38 : hi)));
    g.addColorStop(0.55, css(base));
    g.addColorStop(1, css(tone(base, lo === undefined ? -0.38 : lo)));
    return g;
  }
  function ellipse(c, x, y, rx, ry, rot) { c.beginPath(); c.ellipse(x, y, Math.max(0.1, rx), Math.max(0.1, ry), rot || 0, 0, Math.PI * 2); }
  function circle(c, x, y, r) { c.beginPath(); c.arc(x, y, Math.max(0.1, r), 0, Math.PI * 2); }

  var GOLD = [214, 168, 58], SILVER = [190, 196, 204], COPPER = [186, 108, 62], IVORY = [232, 222, 196], IRON = [104, 98, 92];

  //---------------------------------------------------------------------------
  // The filler corpus. Each function draws in the object's own frame: the long axis along x, from -a to a, the short
  // one along y, from -b to b; s = pixel scale. ⛔ Every mark stays inside the ellipse (a, b): the model's proof
  // trusts it, and _probe/footprint_check.js counts any ink outside.
  //---------------------------------------------------------------------------
  var KIND = {};

  KIND.coin = function (c, a, b, v, w, L, s) {
    var metal = v < 0.68 ? GOLD : v < 0.88 ? SILVER : COPPER, r = a * 0.98;
    circle(c, 0, 0, r); bodyFill(c, litGrad(c, r, metal, L, 0.45, -0.42), s);
    // the raised rim and the struck face
    c.lineWidth = Math.max(0.8, r * 0.13); c.strokeStyle = css(tone(metal, -0.30)); circle(c, 0, 0, r * 0.80); c.stroke();
    c.lineWidth = Math.max(0.6, r * 0.07); c.strokeStyle = css(tone(metal, 0.45), 0.8);
    c.beginPath(); c.arc(0, 0, r * 0.80, Math.atan2(L.y, L.x) - 1.2, Math.atan2(L.y, L.x) + 1.2); c.stroke();
    // a beaded ring inside the rim, the mark of a struck coin (a plain cross here read as a screw head: review 2026-10-20)
    var beads = Math.max(8, Math.min(16, Math.round(r * 1.2))), br = Math.max(0.45, r * 0.055);
    c.fillStyle = css(tone(metal, -0.28), 0.9);
    for (var bi = 0; bi < beads; bi++) { var ba = bi / beads * Math.PI * 2; circle(c, Math.cos(ba) * r * 0.64, Math.sin(ba) * r * 0.64, br); c.fill(); }
    // the device: a crown of three points, or a raised boss lit from the light, by w
    if (w < 0.5) {
      c.fillStyle = css(tone(metal, -0.34)); c.beginPath();
      c.moveTo(-r * 0.36, r * 0.18); c.lineTo(-r * 0.36, -r * 0.16); c.lineTo(-r * 0.18, r * 0.02); c.lineTo(0, -r * 0.30); c.lineTo(r * 0.18, r * 0.02); c.lineTo(r * 0.36, -r * 0.16); c.lineTo(r * 0.36, r * 0.18); c.closePath();
      c.fill();
    } else {
      circle(c, 0, 0, r * 0.34); c.fillStyle = litGrad(c, r * 0.34, tone(metal, 0.05), L, 0.5, -0.5); c.fill();
      c.lineWidth = Math.max(0.5, r * 0.05); c.strokeStyle = css(tone(metal, -0.38), 0.85); c.stroke();
    }
  };
  KIND.gemChip = function (c, a, b, v, w, L, s) {
    var base = pick([[200, 36, 52], [40, 92, 210], [36, 170, 92], [146, 60, 200], [232, 168, 36], [40, 190, 200]], v);
    var n = 6, pts = [];
    for (var i = 0; i < n; i++) { var t = i / n * Math.PI * 2 + w; pts.push([Math.cos(t) * a * (0.82 + 0.16 * ((i * 7 + 3) % 3) / 2), Math.sin(t) * b * (0.82 + 0.16 * ((i * 5 + 1) % 3) / 2)]); }
    c.beginPath(); pts.forEach(function (p, i) { if (i) c.lineTo(p[0], p[1]); else c.moveTo(p[0], p[1]); }); c.closePath();
    bodyFill(c, css(base), s);
    // facets: each wedge lit by how it faces the light
    for (var j = 0; j < n; j++) {
      var p0 = pts[j], p1 = pts[(j + 1) % n], mx = (p0[0] + p1[0]) / 2, my = (p0[1] + p1[1]) / 2, ml = Math.sqrt(mx * mx + my * my) || 1;
      var lit = (mx / ml) * L.x + (my / ml) * L.y;
      c.beginPath(); c.moveTo(0, 0); c.lineTo(p0[0], p0[1]); c.lineTo(p1[0], p1[1]); c.closePath();
      c.fillStyle = css(tone(base, lit * 0.45)); c.fill();
    }
    c.beginPath(); c.moveTo(L.x * a * 0.5, L.y * b * 0.5); c.lineTo(L.x * a * 0.1 + b * 0.2, L.y * b * 0.1); c.lineTo(L.x * a * 0.1, L.y * b * 0.1 + b * 0.2); c.closePath();
    c.fillStyle = 'rgba(255,255,255,0.85)'; c.fill();
  };
  /** The half-height a capsule footprint (length 2a, radius b) allows at x along its axis. */
  function capHH(a, b, x) { var e = a - b, d = Math.abs(x) - e; return d <= 0 ? b : Math.sqrt(Math.max(0, b * b - d * d)); }
  /** A capsule path (a bar with round ends) of half-length hl and radius r, centred. */
  function capsule(c, hl, r, x0) { var e = Math.max(0, hl - r); x0 = x0 || 0; c.beginPath(); c.arc(x0 - e, 0, r, Math.PI / 2, Math.PI * 1.5); c.arc(x0 + e, 0, r, -Math.PI / 2, Math.PI / 2); c.closePath(); }
  KIND.chain = function (c, a, b, v, w, L, s) {
    var metal = v < 0.6 ? IRON : GOLD, pitch = b * 1.55, reach = pitch * 0.62 + b * 0.17, n = Math.max(2, Math.floor((2 * (a - b * 0.6) - 2 * reach) / pitch) + 1), x0 = -(n - 1) * pitch / 2;
    for (var i = 0; i < n; i++) {
      var x = x0 + i * pitch;
      if (i % 2 === 0) { ellipse(c, x, 0, pitch * 0.62, b * 0.72); c.lineWidth = b * 0.34; c.strokeStyle = css(tone(metal, -0.25)); c.save(); c.shadowColor = DRAW.shadows ? SHADOW : 'rgba(0,0,0,0)'; c.shadowBlur = s; c.shadowOffsetX = s; c.shadowOffsetY = 1.4 * s; c.stroke(); c.restore(); c.lineWidth = b * 0.14; c.strokeStyle = css(tone(metal, 0.35)); ellipse(c, x - b * 0.06, -b * 0.06, pitch * 0.62, b * 0.72); c.stroke(); }
      else { c.beginPath(); c.moveTo(x - pitch * 0.62, 0); c.lineTo(x + pitch * 0.62, 0); c.lineWidth = b * 0.42; c.lineCap = 'round'; c.strokeStyle = css(tone(metal, -0.1)); c.stroke(); c.lineWidth = b * 0.14; c.strokeStyle = css(tone(metal, 0.4)); c.beginPath(); c.moveTo(x - pitch * 0.5, -b * 0.08); c.lineTo(x + pitch * 0.5, -b * 0.08); c.stroke(); }
    }
  };
  KIND.scale = function (c, a, b, v, w, L, s) {
    var base = pick([[52, 120, 84], [150, 40, 36], [150, 112, 50], [60, 70, 120]], v);
    c.beginPath(); c.moveTo(a * 0.96, 0); c.quadraticCurveTo(a * 0.2, -b * 1.0, -a * 0.62, -b * 0.72); c.quadraticCurveTo(-a * 1.02, 0, -a * 0.62, b * 0.72); c.quadraticCurveTo(a * 0.2, b * 1.0, a * 0.96, 0); c.closePath();
    bodyFill(c, litGrad(c, a, base, L, 0.42, -0.45), s);
    c.strokeStyle = css(tone(base, -0.42)); c.lineWidth = Math.max(0.7, b * 0.10); c.beginPath(); c.moveTo(-a * 0.70, 0); c.lineTo(a * 0.80, 0); c.stroke();
    c.strokeStyle = css(tone(base, 0.4), 0.7); c.lineWidth = Math.max(0.6, b * 0.07); c.beginPath(); c.moveTo(-a * 0.55, -b * 0.42); c.quadraticCurveTo(a * 0.1, -b * 0.62, a * 0.7, -b * 0.08); c.stroke();
  };
  KIND.bone = function (c, a, b, v, w, L, s) {
    // two knuckles at each end (centred where the capsule's round ends begin), a waisted shaft between: one union path
    var col = mix(IVORY, [200, 186, 150], v), kr = b * 0.5, e = a - b;
    c.beginPath();
    [[-e, -0.48], [-e, 0.48], [e, -0.48], [e, 0.48]].forEach(function (p) { c.moveTo(p[0] + kr, p[1] * b); c.arc(p[0], p[1] * b, kr, 0, Math.PI * 2); });
    c.moveTo(-e, -b * 0.30); c.quadraticCurveTo(0, -b * 0.18, e, -b * 0.30); c.lineTo(e, b * 0.30); c.quadraticCurveTo(0, b * 0.18, -e, b * 0.30); c.closePath();
    bodyFill(c, css(col), s);
    c.strokeStyle = css(tone(col, -0.30), 0.8); c.lineWidth = Math.max(0.7, b * 0.12); c.beginPath(); c.moveTo(-a * 0.55, b * 0.22); c.lineTo(a * 0.55, b * 0.22); c.stroke();
    c.strokeStyle = 'rgba(255,255,255,0.55)'; c.beginPath(); c.moveTo(-a * 0.55, -b * 0.16); c.lineTo(a * 0.55, -b * 0.16); c.stroke();
  };
  KIND.bead = function (c, a, b, v, w, L, s) {
    var pearl = v < 0.45, col = pearl ? [236, 230, 222] : pick([[180, 40, 60], [40, 110, 180], [40, 150, 110], [210, 150, 40]], (v - 0.45) / 0.55);
    var r = b * 0.82, pitch = r * 1.9, n = Math.max(2, Math.floor((2 * a - 2 * b) / pitch) + 1), x0 = -(n - 1) * pitch / 2;
    c.strokeStyle = 'rgba(60,40,24,0.6)'; c.lineWidth = Math.max(0.5, s * 0.6); c.beginPath(); c.moveTo(x0, 0); c.lineTo(-x0, 0); c.stroke();
    for (var i = 0; i < n; i++) { var x = x0 + i * pitch, yy = Math.sin(i * 1.3 + w * 6) * b * 0.1; circle(c, x, yy, r); c.save(); c.translate(x, yy); bodyFill(c, litGrad(c, r, col, L, pearl ? 0.7 : 0.5, -0.35), s); c.restore(); circle(c, x + L.x * r * 0.42, yy + L.y * r * 0.42, r * 0.22); c.fillStyle = 'rgba(255,255,255,0.85)'; c.fill(); }
  };
  KIND.ring = function (c, a, b, v, w, L, s) {
    var metal = v < 0.7 ? GOLD : SILVER, R = a * 0.70, band = a * 0.28;
    c.beginPath(); c.arc(0, 0, R + band / 2, 0, Math.PI * 2); c.arc(0, 0, R - band / 2, 0, Math.PI * 2, true);
    bodyFill(c, litGrad(c, R + band / 2, metal, L, 0.5, -0.45), s);
    c.strokeStyle = css(tone(metal, 0.55), 0.85); c.lineWidth = band * 0.30; c.beginPath(); c.arc(0, 0, R, Math.atan2(L.y, L.x) - 1.1, Math.atan2(L.y, L.x) + 0.9); c.stroke();
    if (w < 0.6) { var g = pick([[200, 30, 50], [40, 90, 210], [40, 170, 100]], w / 0.6); circle(c, -Math.cos(Math.atan2(L.y, L.x)) * 0 + 0, -(R + band * 0.05), band * 0.95); c.save(); c.translate(0, -(R + band * 0.05)); bodyFill(c, litGrad(c, band, g, L, 0.6, -0.3), s); c.restore(); }
  };
  KIND.ribbon = function (c, a, b, v, w, L, s) {
    var col = pick([[170, 30, 48], [40, 70, 150], [190, 150, 50], [70, 120, 70], [120, 50, 120]], v), wd = b * 0.46, amp = b * 0.42;
    var n = 18, top = [], bot = [];
    for (var i = 0; i <= n; i++) {
      var t = i / n, x = -a * 0.96 + t * a * 1.92, y = Math.sin(t * Math.PI * 2.2 + w * 6) * amp, tw = Math.cos(t * Math.PI * 2.2 + w * 6), hw = wd * (0.35 + 0.65 * Math.abs(tw));
      var lim = capHH(a, b, x) * 0.94, y0 = Math.max(-lim, y - hw), y1 = Math.min(lim, y + hw);
      if (y1 - y0 < 0.6) { var mid = Math.max(-lim, Math.min(lim, y)); y0 = mid - 0.3; y1 = mid + 0.3; }
      top.push([x, y0]); bot.push([x, y1]);
    }
    c.beginPath(); top.forEach(function (p, i) { if (i) c.lineTo(p[0], p[1]); else c.moveTo(p[0], p[1]); }); for (var k = bot.length - 1; k >= 0; k--) c.lineTo(bot[k][0], bot[k][1]); c.closePath();
    bodyFill(c, css(col), s);
    // the twist: darker where the ribbon turns away
    for (var j = 0; j < n; j++) { var tt = (j + 0.5) / n, sh = Math.cos(tt * Math.PI * 2.2 + w * 6); c.beginPath(); c.moveTo(top[j][0], top[j][1]); c.lineTo(top[j + 1][0], top[j + 1][1]); c.lineTo(bot[j + 1][0], bot[j + 1][1]); c.lineTo(bot[j][0], bot[j][1]); c.closePath(); c.fillStyle = css(tone(col, sh > 0 ? sh * 0.28 : sh * 0.42), 0.9); c.fill(); }
  };
  KIND.button = function (c, a, b, v, w, L, s) {
    var col = pick([[120, 76, 44], [30, 30, 36], [200, 190, 170], [150, 40, 40], [50, 70, 110], [200, 160, 60]], v), r = a * 0.96;
    circle(c, 0, 0, r); bodyFill(c, litGrad(c, r, col, L, 0.35, -0.35), s);
    c.strokeStyle = css(tone(col, -0.35)); c.lineWidth = Math.max(0.6, r * 0.12); circle(c, 0, 0, r * 0.72); c.stroke();
    var holes = w < 0.5 ? 2 : 4, hr = Math.max(0.6, r * 0.13);
    for (var i = 0; i < holes; i++) { var t = i / holes * Math.PI * 2 + 0.6, d = r * 0.30; circle(c, Math.cos(t) * d, Math.sin(t) * d, hr); c.fillStyle = css(tone(col, -0.6)); c.fill(); }
  };
  KIND.die = function (c, a, b, v, w, L, s) {
    var h = a * 0.66, r = h * 0.28;
    c.beginPath(); c.moveTo(-h + r, -h); c.lineTo(h - r, -h); c.quadraticCurveTo(h, -h, h, -h + r); c.lineTo(h, h - r); c.quadraticCurveTo(h, h, h - r, h); c.lineTo(-h + r, h); c.quadraticCurveTo(-h, h, -h, h - r); c.lineTo(-h, -h + r); c.quadraticCurveTo(-h, -h, -h + r, -h); c.closePath();
    var col = w < 0.75 ? [238, 230, 210] : [170, 36, 40];
    bodyFill(c, litGrad(c, h * 1.3, col, L, 0.3, -0.25), s);
    var face = 1 + Math.floor(v * 6), pip = w < 0.75 ? [40, 30, 26] : [245, 240, 230], P = h * 0.5, pr = Math.max(0.7, h * 0.16);
    var spots = { 1: [[0, 0]], 2: [[-1, -1], [1, 1]], 3: [[-1, -1], [0, 0], [1, 1]], 4: [[-1, -1], [1, -1], [-1, 1], [1, 1]], 5: [[-1, -1], [1, -1], [0, 0], [-1, 1], [1, 1]], 6: [[-1, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [1, 1]] }[face];
    c.fillStyle = css(pip); spots.forEach(function (p) { circle(c, p[0] * P, p[1] * P, pr); c.fill(); });
  };
  KIND.card = function (c, a, b, v, w, L, s) {
    var hw = a * 0.83, hh = b * 0.53, r = hh * 0.16;
    c.beginPath(); c.moveTo(-hw + r, -hh); c.lineTo(hw - r, -hh); c.quadraticCurveTo(hw, -hh, hw, -hh + r); c.lineTo(hw, hh - r); c.quadraticCurveTo(hw, hh, hw - r, hh); c.lineTo(-hw + r, hh); c.quadraticCurveTo(-hw, hh, -hw, hh - r); c.lineTo(-hw, -hh + r); c.quadraticCurveTo(-hw, -hh, -hw + r, -hh); c.closePath();
    bodyFill(c, css([244, 238, 222]), s);
    if (w < 0.45) {
      // the back: a lattice in one ink
      var ink = v < 0.5 ? [150, 34, 40] : [36, 60, 130];
      c.save(); c.clip(); c.fillStyle = css(ink); c.fillRect(-hw + hh * 0.18, -hh + hh * 0.18, (hw - hh * 0.18) * 2, (hh - hh * 0.18) * 2);
      c.strokeStyle = css(tone(ink, 0.45)); c.lineWidth = Math.max(0.5, hh * 0.08);
      for (var x = -hw * 2; x < hw * 2; x += hh * 0.5) { c.beginPath(); c.moveTo(x, -hh); c.lineTo(x + hh * 2, hh); c.stroke(); c.beginPath(); c.moveTo(x, hh); c.lineTo(x + hh * 2, -hh); c.stroke(); }
      c.restore();
    } else {
      // a face: one pip of the suit in the middle (hearts and diamonds red), corner marks
      var red = v < 0.5, ink2 = red ? [180, 30, 36] : [26, 24, 30], k = hh * 0.42;
      c.fillStyle = css(ink2); c.beginPath();
      if (v < 0.25) { c.moveTo(0, k); c.bezierCurveTo(-k * 1.4, -k * 0.2, -k * 0.6, -k * 1.1, 0, -k * 0.4); c.bezierCurveTo(k * 0.6, -k * 1.1, k * 1.4, -k * 0.2, 0, k); }
      else if (v < 0.5) { c.moveTo(0, -k); c.lineTo(k * 0.7, 0); c.lineTo(0, k); c.lineTo(-k * 0.7, 0); c.closePath(); }
      else if (v < 0.75) { c.arc(0, -k * 0.35, k * 0.42, 0, Math.PI * 2); c.moveTo(-k * 0.4, k * 0.15); c.arc(-k * 0.42, k * 0.1, k * 0.42, 0, Math.PI * 2); c.moveTo(k * 0.84, k * 0.1); c.arc(k * 0.42, k * 0.1, k * 0.42, 0, Math.PI * 2); c.rect(-k * 0.1, 0, k * 0.2, k); }
      else { c.moveTo(0, -k); c.bezierCurveTo(k * 1.3, -k * 0.1, k * 0.6, k * 0.8, 0, k * 0.35); c.bezierCurveTo(-k * 0.6, k * 0.8, -k * 1.3, -k * 0.1, 0, -k); c.rect(-k * 0.1, k * 0.2, k * 0.2, k * 0.8); }
      c.fill();
      c.fillRect(-hw + hh * 0.18, -hh + hh * 0.2, hh * 0.16, hh * 0.38); c.fillRect(hw - hh * 0.34, hh - hh * 0.58, hh * 0.16, hh * 0.38);
    }
  };
  KIND.cork = function (c, a, b, v, w, L, s) {
    var col = [184, 140, 92], hh = b * 0.9, hw = a * 0.97 - hh * 0.45;
    capsule(c, a * 0.97, hh);
    var g = c.createLinearGradient(0, -hh, 0, hh); g.addColorStop(0, css(tone(col, L.y < 0 ? 0.3 : -0.2))); g.addColorStop(0.5, css(col)); g.addColorStop(1, css(tone(col, L.y < 0 ? -0.3 : 0.2)));
    bodyFill(c, g, s);
    var R = rnd('cork' + v); c.fillStyle = css(tone(col, -0.4), 0.7);
    for (var i = 0; i < 14; i++) { circle(c, (R() * 1.4 - 0.7) * hw, (R() * 1.4 - 0.7) * hh, Math.max(0.4, s * 0.5)); c.fill(); }
    ellipse(c, hw, 0, hh * 0.40, hh * 0.86); c.fillStyle = css(tone(col, 0.18)); c.fill(); c.strokeStyle = css(tone(col, -0.3)); c.lineWidth = Math.max(0.5, s * 0.5); c.stroke();
    if (w < 0.5) { ellipse(c, hw, 0, hh * 0.28, hh * 0.6); c.fillStyle = 'rgba(110,20,40,0.55)'; c.fill(); }
  };
  KIND.candle = function (c, a, b, v, w, L, s) {
    var col = v < 0.6 ? [236, 226, 196] : v < 0.85 ? [196, 40, 44] : [60, 90, 70], hh = b * 0.78, e = a - b, x0 = -e, x1 = e * 0.45;
    c.beginPath(); c.moveTo(x0, -hh); c.lineTo(x1, -hh); c.ellipse(x1, 0, hh * 0.38, hh, 0, -Math.PI / 2, Math.PI / 2); c.lineTo(x0, hh); c.ellipse(x0, 0, hh * 0.38, hh, 0, Math.PI / 2, Math.PI * 1.5); c.closePath();
    var g = c.createLinearGradient(0, -hh, 0, hh); g.addColorStop(0, css(tone(col, 0.35))); g.addColorStop(0.55, css(col)); g.addColorStop(1, css(tone(col, -0.3)));
    bodyFill(c, g, s);
    // the burnt end, its wick, and a drip down the side
    ellipse(c, x1, 0, hh * 0.34, hh * 0.86); c.fillStyle = css(tone(col, 0.12)); c.fill(); c.strokeStyle = css(tone(col, -0.25)); c.lineWidth = Math.max(0.5, s * 0.6); c.stroke();
    c.strokeStyle = 'rgb(30,22,18)'; c.lineWidth = Math.max(0.8, hh * 0.18); c.lineCap = 'round'; c.beginPath(); c.moveTo(x1, 0); c.lineTo(Math.min(e + b * 0.5, x1 + hh * 0.75), -hh * 0.18); c.stroke();
    c.fillStyle = css(tone(col, 0.2)); c.beginPath(); c.moveTo(x1 - hh * 0.6, -hh); c.quadraticCurveTo(x1 - hh * 0.9, -hh * 0.2, x1 - hh * 1.1, hh * 0.15); c.quadraticCurveTo(x1 - hh * 1.35, -hh * 0.4, x1 - hh * 1.4, -hh); c.closePath(); c.fill();
  };
  KIND.nutshell = function (c, a, b, v, w, L, s) {
    var col = [150, 104, 60];
    ellipse(c, 0, 0, a * 0.96, b * 0.96); bodyFill(c, litGrad(c, a, col, L, 0.3, -0.45), s);
    c.strokeStyle = css(tone(col, -0.5), 0.8); c.lineWidth = Math.max(0.6, b * 0.11); c.lineCap = 'round';
    c.beginPath(); c.moveTo(-a * 0.9, 0); c.lineTo(a * 0.9, 0); c.stroke();
    var R = rnd('nut' + v);
    for (var i = 0; i < 6; i++) { var x = (R() * 1.4 - 0.7) * a, y = (i % 2 ? 1 : -1) * (0.3 + R() * 0.35) * b; c.beginPath(); c.moveTo(x - a * 0.18, y); c.quadraticCurveTo(x, y + (R() - 0.5) * b * 0.4, x + a * 0.18, y); c.stroke(); }
  };
  function leafPath(c, a, b, lobes, depth, tooth) {
    // a leaf along x: tip at +a, stem end at -a; the half-width follows a sine envelope with lobes or teeth on top
    var n = 64, i, t, env, edge;
    c.beginPath();
    for (i = 0; i <= n; i++) { t = i / n; env = Math.sin(Math.PI * Math.pow(t, 0.85)); edge = 1 - depth * (0.5 - 0.5 * Math.cos(t * Math.PI * 2 * lobes)) - tooth * ((i % 2) ? 0.12 : 0); var x = -a + t * 2 * a, y = -b * env * edge; if (i) c.lineTo(x, y); else c.moveTo(x, y); }
    for (i = n; i >= 0; i--) { t = i / n; env = Math.sin(Math.PI * Math.pow(t, 0.85)); edge = 1 - depth * (0.5 - 0.5 * Math.cos(t * Math.PI * 2 * lobes + 0.4)) - tooth * ((i % 2) ? 0.12 : 0); c.lineTo(-a + t * 2 * a, b * env * edge); }
    c.closePath();
  }
  var AUTUMN = [[176, 92, 36], [196, 140, 44], [150, 60, 34], [120, 110, 52], [92, 120, 58], [168, 120, 70]];
  function veins(c, a, b, col, n, s) {
    c.strokeStyle = css(tone(col, -0.38), 0.85); c.lineWidth = Math.max(0.6, b * 0.07); c.lineCap = 'round';
    c.beginPath(); c.moveTo(-a * 0.98, 0); c.lineTo(a * 0.86, 0); c.stroke();
    c.lineWidth = Math.max(0.45, b * 0.04);
    for (var i = 1; i <= n; i++) { var x = -a * 0.7 + i * (a * 1.4 / (n + 1)), dy = b * 0.62 * Math.sin(Math.PI * (i / (n + 1))); c.beginPath(); c.moveTo(x - a * 0.12, 0); c.lineTo(x + a * 0.06, -dy); c.moveTo(x - a * 0.12, 0); c.lineTo(x + a * 0.06, dy); c.stroke(); }
  }
  KIND.leafOak = function (c, a, b, v, w, L, s) {
    var col = pick(AUTUMN, v);
    leafPath(c, a * 0.98, b * 0.96, 3.5, 0.42, 0); bodyFill(c, litGrad(c, a, col, L, 0.22, -0.3), s); veins(c, a * 0.9, b * 0.9, col, 4, s);
  };
  KIND.leafMaple = function (c, a, b, v, w, L, s) {
    var col = pick([[196, 54, 36], [214, 110, 32], [226, 168, 44], [170, 40, 44]], v), R0 = a * 0.96, pts = [];
    // five pointed lobes on a palm, the stem toward -x
    var lob = [0, 0.95, -0.95, 1.85, -1.85];
    c.beginPath();
    for (var i = 0; i <= 50; i++) {
      var t = -Math.PI + i / 50 * Math.PI * 2, best = 0.34;
      for (var k = 0; k < lob.length; k++) { var d = Math.abs(((t - lob[k] + Math.PI * 3) % (Math.PI * 2)) - Math.PI); best = Math.max(best, (1 - d / 0.55) * (k === 0 ? 1 : k < 3 ? 0.9 : 0.66)); }
      var r = R0 * Math.max(0.3, best) * (i % 2 ? 0.97 : 1), x = Math.cos(t) * r, y = Math.sin(t) * r * (b / a);
      if (i) c.lineTo(x, y); else c.moveTo(x, y);
    }
    c.closePath(); bodyFill(c, litGrad(c, a, col, L, 0.2, -0.3), s);
    c.strokeStyle = css(tone(col, -0.4), 0.85); c.lineWidth = Math.max(0.5, a * 0.05);
    lob.forEach(function (t, k) { c.beginPath(); c.moveTo(0, 0); c.lineTo(Math.cos(t) * R0 * (k === 0 ? 0.85 : k < 3 ? 0.75 : 0.55), Math.sin(t) * R0 * (k === 0 ? 0.85 : k < 3 ? 0.75 : 0.55) * (b / a)); c.stroke(); });
    c.lineWidth = Math.max(0.7, a * 0.07); c.beginPath(); c.moveTo(0, 0); c.lineTo(-a * 0.95, 0); c.stroke();
  };
  KIND.leafBirch = function (c, a, b, v, w, L, s) {
    var col = pick([[214, 178, 52], [190, 150, 40], [140, 150, 60], [200, 130, 40]], v);
    leafPath(c, a * 0.98, b * 0.96, 0, 0, 1); bodyFill(c, litGrad(c, a, col, L, 0.25, -0.3), s); veins(c, a * 0.9, b * 0.9, col, 5, s);
  };
  KIND.acorn = function (c, a, b, v, w, L, s) {
    var nut = [168, 112, 52], cap = [112, 82, 50];
    ellipse(c, a * 0.12, 0, a * 0.82, b * 0.86); bodyFill(c, litGrad(c, a, nut, L, 0.4, -0.35), s);
    c.beginPath(); c.ellipse(-a * 0.40, 0, a * 0.42, b * 0.98, 0, -Math.PI / 2, Math.PI / 2, true); c.closePath(); c.fillStyle = css(cap); c.fill();
    c.fillStyle = css(tone(cap, -0.35));
    for (var i = 0; i < 9; i++) { var yy = (i / 8 - 0.5) * b * 1.5; circle(c, -a * 0.58 + (i % 2) * a * 0.12, yy, Math.max(0.5, b * 0.08)); c.fill(); }
    c.strokeStyle = css(tone(cap, -0.3)); c.lineWidth = Math.max(0.7, b * 0.16); c.lineCap = 'round'; c.beginPath(); c.moveTo(-a * 0.80, 0); c.lineTo(-a * 0.96, -b * 0.1); c.stroke();
    circle(c, a * 0.50, -b * 0.28, b * 0.16); c.fillStyle = 'rgba(255,240,210,0.6)'; c.fill();
  };
  KIND.pinecone = function (c, a, b, v, w, L, s) {
    var col = [126, 84, 46];
    ellipse(c, 0, 0, a * 0.96, b * 0.92); bodyFill(c, css(tone(col, -0.2)), s);
    // rows of scales from the base (-x) to the tip, each a small lit arc
    var rows = 6;
    for (var r = 0; r < rows; r++) {
      var x = -a * 0.72 + r * (a * 1.5 / (rows - 1)), half = b * 0.88 * Math.sin(Math.PI * (0.12 + 0.76 * (r + 0.5) / rows)), n = Math.max(2, Math.round(half / (b * 0.28)));
      for (var k = 0; k < n; k++) { var y = -half + (k + 0.5) * (2 * half / n); c.beginPath(); c.ellipse(x, y, a * 0.15, half / n * 0.95, 0, 0, Math.PI * 2); c.fillStyle = css(tone(col, 0.05 + ((k + r) % 2) * 0.1)); c.fill(); c.strokeStyle = css(tone(col, -0.45)); c.lineWidth = Math.max(0.4, s * 0.5); c.stroke(); }
    }
  };
  KIND.twig = function (c, a, b, v, w, L, s) {
    var col = pick([[96, 70, 46], [120, 92, 62], [78, 62, 50]], v);
    c.lineCap = 'round'; c.strokeStyle = css(col);
    c.save(); c.shadowColor = DRAW.shadows ? SHADOW : 'rgba(0,0,0,0)'; c.shadowBlur = s; c.shadowOffsetX = s; c.shadowOffsetY = 1.4 * s;
    c.lineWidth = b * 0.36; c.beginPath(); c.moveTo(-a * 0.94, b * 0.1); c.quadraticCurveTo(0, -b * 0.25, a * 0.92, 0); c.stroke();
    c.lineWidth = b * 0.22; c.beginPath(); c.moveTo(-a * 0.2, -b * 0.08); c.lineTo(a * 0.25, -b * 0.84 * (w < 0.5 ? 1 : -1)); c.stroke();
    if (w > 0.3) { c.lineWidth = b * 0.16; c.beginPath(); c.moveTo(a * 0.35, -b * 0.06); c.lineTo(a * 0.66, b * 0.72 * (w < 0.5 ? 1 : -1)); c.stroke(); }
    c.restore();
    c.strokeStyle = css(tone(col, 0.35), 0.8); c.lineWidth = Math.max(0.5, b * 0.08); c.beginPath(); c.moveTo(-a * 0.9, -b * 0.02); c.quadraticCurveTo(0, -b * 0.36, a * 0.9, -b * 0.1); c.stroke();
  };
  KIND.mushroom = function (c, a, b, v, w, L, s) {
    var agaric = v < 0.5, cap = agaric ? [196, 44, 36] : [156, 110, 66], r = Math.min(a, b) * 0.96;
    // seen from above: the cap, offset, with the stem's foot showing beside it
    ellipse(c, -r * 0.55, 0, r * 0.38, r * 0.30); bodyFill(c, css([226, 214, 186]), s);
    circle(c, r * 0.12, 0, r * 0.84); bodyFill(c, litGrad(c, r * 0.84, cap, L, 0.32, -0.4), s);
    if (agaric) { c.fillStyle = 'rgba(250,244,230,0.95)'; var R = rnd('agaric' + v); for (var i = 0; i < 7; i++) { var t = R() * 6.28, d = R() * r * 0.6; circle(c, r * 0.12 + Math.cos(t) * d, Math.sin(t) * d, r * (0.07 + R() * 0.06)); c.fill(); } }
    else { c.strokeStyle = css(tone(cap, -0.35), 0.8); c.lineWidth = Math.max(0.5, r * 0.06); circle(c, r * 0.12, 0, r * 0.55); c.stroke(); }
  };
  KIND.snail = function (c, a, b, v, w, L, s) {
    var col = pick([[176, 132, 82], [150, 100, 70], [196, 170, 120]], v), r = Math.min(a, b) * 0.97;
    circle(c, 0, 0, r); bodyFill(c, litGrad(c, r, col, L, 0.35, -0.4), s);
    c.strokeStyle = css(tone(col, -0.55)); c.lineWidth = Math.max(0.6, r * 0.10); c.lineCap = 'round'; c.beginPath();
    for (var i = 0; i <= 60; i++) { var t = i / 60 * Math.PI * 5.2, rr = r * 0.92 * Math.exp(-0.21 * t); var x = Math.cos(t + w * 6) * rr, y = Math.sin(t + w * 6) * rr; if (i) c.lineTo(x, y); else c.moveTo(x, y); }
    c.stroke();
  };
  KIND.feather = function (c, a, b, v, w, L, s) {
    var col = pick([[236, 232, 222], [150, 120, 90], [70, 110, 170], [60, 56, 54]], v);
    c.beginPath(); c.moveTo(-a * 0.55, 0); c.quadraticCurveTo(-a * 0.2, -b * 0.98, a * 0.94, -b * 0.08); c.quadraticCurveTo(a * 0.1, b * 0.98, -a * 0.55, 0); c.closePath();
    bodyFill(c, css(col), s);
    // barbs: tapered to nothing at both ends (Icon_Doctrine §22a-2), only where they resolve
    var n = Math.floor(a * 1.4 / Math.max(2.6, s * 2.6)); c.strokeStyle = css(tone(col, -0.28), 0.7); c.lineWidth = Math.max(0.4, s * 0.45);
    for (var i = 1; i < n; i++) { var t = i / n, x = -a * 0.5 + t * a * 1.4, env = Math.pow(Math.sin(Math.PI * t), 2) * b * 0.82; if (env < s) continue; c.beginPath(); c.moveTo(x, 0); c.lineTo(x + a * 0.08, -env); c.moveTo(x, 0); c.lineTo(x + a * 0.08, env); c.stroke(); }
    if (v >= 0.25 && v < 0.5) { c.fillStyle = css(tone(col, -0.35), 0.6); for (var k = 0; k < 3; k++) { c.fillRect(-a * 0.2 + k * a * 0.3, -b * 0.4, a * 0.08, b * 0.8); } }
    c.strokeStyle = css(tone(col, -0.45)); c.lineWidth = Math.max(0.6, b * 0.10); c.lineCap = 'round'; c.beginPath(); c.moveTo(-a * 0.96, b * 0.05); c.lineTo(a * 0.9, -b * 0.06); c.stroke();
  };
  KIND.berry = function (c, a, b, v, w, L, s) {
    var col = pick([[176, 24, 40], [60, 50, 120], [30, 30, 50]], v), r = Math.min(a, b) * 0.36;
    var at = [[-r * 0.9, -r * 0.5], [r * 0.6, -r * 0.8], [r * 0.9, r * 0.6], [-r * 0.5, r * 0.85], [r * 0.05, r * 0.05]];
    c.strokeStyle = 'rgb(80,70,40)'; c.lineWidth = Math.max(0.5, s * 0.6); at.forEach(function (p) { c.beginPath(); c.moveTo(-a * 0.82, -b * 0.1); c.lineTo(p[0], p[1]); c.stroke(); });
    at.forEach(function (p) { circle(c, p[0], p[1], r); c.save(); c.translate(p[0], p[1]); bodyFill(c, litGrad(c, r, col, L, 0.5, -0.35), s); c.restore(); circle(c, p[0] + L.x * r * 0.4, p[1] + L.y * r * 0.4, r * 0.25); c.fillStyle = 'rgba(255,255,255,0.7)'; c.fill(); });
  };
  KIND.scallop = function (c, a, b, v, w, L, s) {
    var col = pick([[226, 150, 112], [236, 200, 150], [200, 110, 90], [220, 180, 196]], v), R0 = Math.min(a, b) * 0.96;
    // a fan from the hinge at -x: a scalloped rim, radial ribs, the two ears at the hinge
    c.beginPath(); c.moveTo(-R0 * 0.62, -R0 * 0.38); c.lineTo(-R0 * 0.92, -R0 * 0.36); c.lineTo(-R0 * 0.92, R0 * 0.36); c.lineTo(-R0 * 0.62, R0 * 0.38);
    var ribs = 9;
    for (var i = 0; i <= ribs * 2; i++) { var t = -1.05 + i / (ribs * 2) * 2.1, rr = R0 * (i % 2 ? 0.98 : 0.90); c.lineTo(-R0 * 0.62 + Math.cos(t) * rr * 1.5, Math.sin(t) * rr * 0.95); }
    c.closePath();
    var g = c.createRadialGradient(-R0 * 0.62, 0, R0 * 0.1, -R0 * 0.62, 0, R0 * 1.5); g.addColorStop(0, css(tone(col, 0.3))); g.addColorStop(1, css(tone(col, -0.2)));
    bodyFill(c, g, s);
    c.strokeStyle = css(tone(col, -0.35), 0.8); c.lineWidth = Math.max(0.5, R0 * 0.05);
    for (var k = 0; k <= ribs; k++) { var tt = -0.95 + k / ribs * 1.9; c.beginPath(); c.moveTo(-R0 * 0.62, 0); c.lineTo(-R0 * 0.62 + Math.cos(tt) * R0 * 1.3, Math.sin(tt) * R0 * 0.83); c.stroke(); }
  };
  KIND.conch = function (c, a, b, v, w, L, s) {
    // a whelk: a fat body whorl toward -x with its open mouth, the spire stepping down to a point at +x as a stack of
    // smaller whorls, each its own lit lump with a suture line (a turned shape, not a flat wedge: §22 pie-slice read)
    var col = pick([[226, 196, 150], [200, 160, 110], [236, 220, 196]], v), band = tone(col, -0.38);
    ellipse(c, -a * 0.30, 0, a * 0.62, b * 0.92); bodyFill(c, litGrad(c, a * 0.62, col, L, 0.35, -0.38), s);
    var steps = 4;
    for (var i = 0; i < steps; i++) {
      var t = i / steps, cx = a * (0.22 + t * 0.62), rx = a * (0.24 - t * 0.045), ry = b * (0.66 - t * 0.14);
      ellipse(c, cx, 0, rx, ry); c.save(); c.translate(cx, 0); bodyFill(c, litGrad(c, rx, tone(col, -0.04 * i), L, 0.4, -0.35), s * 0.6); c.restore();
      c.strokeStyle = css(band, 0.85); c.lineWidth = Math.max(0.5, b * 0.07); c.beginPath(); c.ellipse(cx - rx * 0.9, 0, rx * 0.25, ry * 0.95, 0, -Math.PI / 2, Math.PI / 2); c.stroke();
    }
    // the mouth: a dark crescent on the body whorl's underside, and a spiral band across the body
    c.beginPath(); c.ellipse(-a * 0.42, b * 0.18, a * 0.30, b * 0.42, -0.2, 0, Math.PI * 2); c.fillStyle = css(tone(col, -0.55), 0.85); c.fill();
    c.beginPath(); c.ellipse(-a * 0.40, b * 0.14, a * 0.20, b * 0.28, -0.2, 0, Math.PI * 2); c.fillStyle = css(tone(col, 0.35)); c.fill();
    c.strokeStyle = css(band, 0.7); c.lineWidth = Math.max(0.6, b * 0.12); c.beginPath(); c.ellipse(-a * 0.30, 0, a * 0.52, b * 0.70, 0, Math.PI * 1.05, Math.PI * 1.75); c.stroke();
  };
  KIND.starfish = function (c, a, b, v, w, L, s) {
    var col = pick([[226, 112, 52], [200, 70, 64], [220, 160, 70], [150, 70, 120]], v), R0 = a * 0.96, r0 = R0 * 0.36;
    c.beginPath();
    for (var i = 0; i < 10; i++) { var t = i / 10 * Math.PI * 2 + w, rr = i % 2 ? r0 : R0; var x = Math.cos(t) * rr, y = Math.sin(t) * rr; if (i) c.lineTo(x, y); else c.moveTo(x, y); }
    c.closePath(); c.lineJoin = 'round';
    bodyFill(c, litGrad(c, R0, col, L, 0.3, -0.35), s);
    c.fillStyle = css(tone(col, 0.4), 0.8);
    for (var k = 0; k < 5; k++) { var tt = k / 5 * Math.PI * 2 + w; for (var d = 1; d <= 3; d++) { circle(c, Math.cos(tt) * R0 * d * 0.2, Math.sin(tt) * R0 * d * 0.2, Math.max(0.5, R0 * 0.05)); c.fill(); } }
  };
  KIND.pebble = function (c, a, b, v, w, L, s) {
    var col = pick([[150, 146, 138], [120, 110, 100], [170, 150, 120], [96, 98, 104], [180, 120, 90]], v);
    c.beginPath();
    for (var i = 0; i <= 16; i++) { var t = i / 16 * Math.PI * 2, k = 0.88 + 0.1 * Math.sin(t * 3 + w * 9) ; var x = Math.cos(t) * a * k, y = Math.sin(t) * b * k; if (i) c.lineTo(x, y); else c.moveTo(x, y); }
    c.closePath(); bodyFill(c, litGrad(c, a, col, L, 0.35, -0.35), s);
    var R = rnd('peb' + v); c.fillStyle = css(tone(col, -0.3), 0.6); for (var j = 0; j < 4; j++) { circle(c, (R() - 0.5) * a, (R() - 0.5) * b, Math.max(0.4, s * 0.6)); c.fill(); }
  };
  KIND.seaGlass = function (c, a, b, v, w, L, s) {
    var col = pick([[120, 190, 150], [110, 170, 190], [220, 230, 226], [70, 120, 90], [130, 90, 60]], v);
    c.beginPath();
    for (var i = 0; i < 6; i++) { var t = i / 6 * Math.PI * 2 + w * 2, k = 0.8 + 0.18 * ((i * 3) % 4) / 3; var x = Math.cos(t) * a * k, y = Math.sin(t) * b * k; if (i) c.lineTo(x, y); else c.moveTo(x, y); }
    c.closePath(); c.lineJoin = 'round';
    bodyFill(c, css(col, 0.78), s);
    c.fillStyle = 'rgba(255,255,255,0.35)'; ellipse(c, L.x * a * 0.3, L.y * b * 0.3, a * 0.35, b * 0.25); c.fill();
  };
  KIND.kelp = function (c, a, b, v, w, L, s) {
    var col = pick([[92, 96, 40], [120, 110, 46], [70, 84, 44]], v), n = 24, top = [], bot = [];
    for (var i = 0; i <= n; i++) { var t = i / n, x = -a * 0.96 + t * a * 1.92, y = Math.sin(t * Math.PI * 3 + w * 6) * b * 0.32, hw = b * (0.14 + 0.46 * Math.sin(Math.PI * Math.min(1, t * 1.15))); top.push([x, y - hw]); bot.push([x, y + hw]); }
    c.beginPath(); top.forEach(function (p, i) { if (i) c.lineTo(p[0], p[1]); else c.moveTo(p[0], p[1]); }); for (var k = n; k >= 0; k--) c.lineTo(bot[k][0], bot[k][1]); c.closePath();
    bodyFill(c, css(col, 0.92), s);
    c.strokeStyle = css(tone(col, 0.3), 0.6); c.lineWidth = Math.max(0.5, s * 0.6); c.beginPath(); for (var j = 0; j <= n; j++) { var mx = (top[j][0] + bot[j][0]) / 2, my = (top[j][1] + bot[j][1]) / 2; if (j) c.lineTo(mx, my); else c.moveTo(mx, my); } c.stroke();
    circle(c, -a * 0.72, Math.sin(0.12 * Math.PI * 3 + w * 6) * b * 0.32, b * 0.24); c.fillStyle = css(tone(col, 0.15)); c.fill();
  };
  KIND.herb = function (c, a, b, v, w, L, s) {
    var lav = v > 0.66, col = lav ? [112, 130, 96] : pick([[70, 124, 60], [110, 140, 90]], v * 1.5), pitch = Math.max(b * 0.62, s * 3.4), n = Math.max(2, Math.floor(a * 1.5 / pitch));
    c.strokeStyle = css(tone(col, -0.3)); c.lineWidth = Math.max(0.6, b * 0.10); c.lineCap = 'round'; c.beginPath(); c.moveTo(-a * 0.95, 0); c.lineTo(a * 0.75, 0); c.stroke();
    for (var i = 0; i < n; i++) { var x = -a * 0.65 + i * pitch, sz = b * 0.62 * (1 - i / (n + 2)); for (var sgn = -1; sgn <= 1; sgn += 2) { ellipse(c, x + sz * 0.4, sgn * sz * 0.62, sz * 0.62, sz * 0.32, sgn * 0.7); c.save(); bodyFill(c, css(tone(col, sgn < 0 ? 0.12 : -0.05)), s * 0.7); c.restore(); } }
    if (lav) { c.fillStyle = 'rgb(150,110,190)'; for (var k = 0; k < 5; k++) { circle(c, a * 0.62 + k * b * 0.14, (k % 2 ? 1 : -1) * b * 0.16, Math.max(0.7, b * 0.17)); c.fill(); } }
  };
  KIND.crystal = function (c, a, b, v, w, L, s) {
    var col = pick([[170, 110, 220], [150, 210, 236], [236, 236, 244], [220, 120, 150], [120, 220, 170]], v);
    var p = [[a * 0.96, 0], [a * 0.46, -b * 0.84], [-a * 0.52, -b * 0.82], [-a * 0.94, 0], [-a * 0.52, b * 0.82], [a * 0.46, b * 0.84]];
    c.beginPath(); p.forEach(function (q, i) { if (i) c.lineTo(q[0], q[1]); else c.moveTo(q[0], q[1]); }); c.closePath();
    bodyFill(c, css(col, 0.85), s);
    c.beginPath(); c.moveTo(p[1][0], p[1][1]); c.lineTo(p[0][0], p[0][1]); c.lineTo(p[2][0], 0); c.lineTo(p[2][0], p[2][1]); c.closePath(); c.fillStyle = css(tone(col, L.y < 0 ? 0.45 : -0.2), 0.8); c.fill();
    c.strokeStyle = css(tone(col, -0.3), 0.7); c.lineWidth = Math.max(0.4, s * 0.5); c.beginPath(); c.moveTo(-a * 0.82, 0); c.lineTo(a * 0.5, 0); c.lineTo(a * 0.96, 0); c.stroke();
  };
  KIND.vial = function (c, a, b, v, w, L, s) {
    // a round-bottomed potion flask lying on the bench: a glass bulb at -x with a coloured draught pooled on its lower side,
    // a long clear neck and a cork at +x. (A straight phial half full read as a two-tone PILL at product size, 2026-10-20.)
    // Every part sits inside the capsule (a, b) the model gave it: the bulb is centred on the capsule's own round end.
    var liq = pick([[176, 34, 52], [46, 146, 76], [58, 94, 200], [214, 146, 36], [138, 60, 176]], v);
    var r = b * 0.95, x0 = -(a - b), nh = b * 0.30, nx1 = a * 0.64, tn = Math.asin(Math.min(0.99, nh / r));
    function glass() { c.beginPath(); c.moveTo(nx1, -nh); c.lineTo(x0 + r * Math.cos(tn), -nh); c.arc(x0, 0, r, -tn, tn, true); c.lineTo(nx1, nh); c.closePath(); }
    glass(); bodyFill(c, 'rgba(206,226,234,0.30)', s);
    // the draught pools on the side away from the light (screen-down), filling w's share of the bulb
    var dl = Math.sqrt(L.x * L.x + L.y * L.y) || 1, dx = -L.x / dl, dy = -L.y / dl;
    c.save(); circle(c, x0, 0, r * 0.97); c.clip(); c.translate(x0, 0); c.rotate(Math.atan2(dy, dx));
    var g = c.createLinearGradient(-r, 0, r, 0); g.addColorStop(0, css(tone(liq, 0.35))); g.addColorStop(0.6, css(liq)); g.addColorStop(1, css(tone(liq, -0.42)));
    var lv = -r * (0.15 + 0.55 * w);
    c.fillStyle = g; c.fillRect(lv, -r * 1.2, r * 2.4, r * 2.4);
    c.strokeStyle = css(tone(liq, 0.6), 0.9); c.lineWidth = Math.max(0.6, r * 0.12); c.beginPath(); c.moveTo(lv, -r); c.lineTo(lv, r); c.stroke();
    c.restore();
    // a dark glass edge so the flask reads against the bench, and the bright window on the lit side of the bulb
    glass(); c.lineWidth = Math.max(0.6, b * 0.10); c.strokeStyle = 'rgba(22,32,38,0.62)'; c.stroke();
    ellipse(c, x0 + L.x * r * 0.42, L.y * r * 0.42, r * 0.26, r * 0.16, Math.atan2(L.y, L.x) + Math.PI / 2); c.fillStyle = 'rgba(255,255,255,0.88)'; c.fill();
    c.strokeStyle = 'rgba(255,255,255,0.55)'; c.lineWidth = Math.max(0.5, nh * 0.35); c.beginPath(); c.moveTo(x0 + r * 0.9, (L.y < 0 ? -1 : 1) * nh * 0.45); c.lineTo(nx1 - a * 0.05, (L.y < 0 ? -1 : 1) * nh * 0.45); c.stroke();
    // the cork, pushed into the neck, with its cut end facing out
    var cx0 = a * 0.58, cx1 = a * 0.92, chh = b * 0.40, col = [150, 98, 54];
    c.beginPath(); c.moveTo(cx0, -chh); c.lineTo(cx1 - chh * 0.3, -chh); c.quadraticCurveTo(cx1, -chh, cx1, -chh * 0.6); c.lineTo(cx1, chh * 0.6); c.quadraticCurveTo(cx1, chh, cx1 - chh * 0.3, chh); c.lineTo(cx0, chh); c.closePath();
    var cg = c.createLinearGradient(0, -chh, 0, chh); cg.addColorStop(0, css(tone(col, L.y < 0 ? 0.30 : -0.25))); cg.addColorStop(1, css(tone(col, L.y < 0 ? -0.30 : 0.25)));
    c.fillStyle = cg; c.fill(); c.strokeStyle = css(tone(col, -0.45), 0.8); c.lineWidth = Math.max(0.5, s * 0.5); c.stroke();
    c.beginPath(); c.moveTo(cx0 + (cx1 - cx0) * 0.35, -chh); c.lineTo(cx0 + (cx1 - cx0) * 0.35, chh); c.stroke();
  };
  KIND.petal = function (c, a, b, v, w, L, s) {
    var col = pick([[236, 170, 190], [244, 232, 230], [236, 200, 90], [200, 90, 120]], v);
    c.beginPath(); c.moveTo(-a * 0.96, 0); c.bezierCurveTo(-a * 0.3, -b * 1.25, a * 0.75, -b * 0.95, a * 0.94, 0); c.bezierCurveTo(a * 0.75, b * 0.95, -a * 0.3, b * 1.25, -a * 0.96, 0); c.closePath();
    bodyFill(c, litGrad(c, a, col, L, 0.3, -0.18), s * 0.7);
    c.strokeStyle = css(tone(col, -0.2), 0.6); c.lineWidth = Math.max(0.4, s * 0.5); c.beginPath(); c.moveTo(-a * 0.85, 0); c.lineTo(a * 0.5, 0); c.stroke();
  };
  KIND.quill = function (c, a, b, v, w, L, s) {
    var col = pick([[240, 236, 228], [200, 196, 190], [60, 60, 66]], v);
    c.beginPath(); c.moveTo(-a * 0.35, 0); c.quadraticCurveTo(0, -b * 0.98, a * 0.95, -b * 0.15); c.quadraticCurveTo(a * 0.2, b * 0.98, -a * 0.35, 0); c.closePath();
    bodyFill(c, css(col), s);
    c.strokeStyle = css(tone(col, -0.2), 0.7); c.lineWidth = Math.max(0.4, s * 0.45); var n = Math.floor(a * 1.2 / Math.max(2.6, s * 2.6));
    for (var i = 1; i < n; i++) { var t = i / n, x = -a * 0.3 + t * a * 1.2, env = Math.pow(Math.sin(Math.PI * t), 2) * b * 0.8; if (env < s) continue; c.beginPath(); c.moveTo(x, 0); c.lineTo(x + a * 0.06, -env); c.moveTo(x, 0); c.lineTo(x + a * 0.06, env); c.stroke(); }
    // the shaft runs out to the cut nib at -x, dipped in ink
    c.strokeStyle = 'rgb(220,206,170)'; c.lineWidth = Math.max(0.7, b * 0.14); c.lineCap = 'round'; c.beginPath(); c.moveTo(-a * 0.95, 0); c.lineTo(a * 0.9, -b * 0.08); c.stroke();
    c.strokeStyle = 'rgb(28,24,30)'; c.beginPath(); c.moveTo(-a * 0.96, 0); c.lineTo(-a * 0.82, 0); c.stroke();
  };
  KIND.waxDrip = function (c, a, b, v, w, L, s) {
    var col = pick([[236, 226, 196], [180, 30, 40], [220, 180, 90]], v);
    // a puddle of set wax: soft round lobes (no points: §22, the first cut read as a star), a run off one side and a
    // separate droplet, glossy where the light catches the dome
    c.beginPath();
    for (var i = 0; i <= 36; i++) { var t = i / 36 * Math.PI * 2, k = 0.70 + 0.10 * Math.sin(t * 2 + w * 7) + 0.07 * Math.sin(t * 3 + 1.3 + w * 5); var x = Math.cos(t) * a * k * 0.92 - a * 0.06, y = Math.sin(t) * b * k * 0.92; if (i) c.lineTo(x, y); else c.moveTo(x, y); }
    c.closePath(); bodyFill(c, litGrad(c, a, col, L, 0.45, -0.25), s * 0.6);
    circle(c, a * 0.78, b * 0.12, Math.min(a, b) * 0.13); c.save(); c.translate(a * 0.78, b * 0.12); bodyFill(c, litGrad(c, Math.min(a, b) * 0.13, col, L, 0.5, -0.2), s * 0.4); c.restore();
    ellipse(c, L.x * a * 0.28 - a * 0.06, L.y * b * 0.28, a * 0.22, b * 0.12, -0.5); c.fillStyle = 'rgba(255,255,255,0.55)'; c.fill();
    c.strokeStyle = css(tone(col, -0.22), 0.6); c.lineWidth = Math.max(0.5, s * 0.6); ellipse(c, -a * 0.06, 0, a * 0.42, b * 0.40); c.stroke();
  };
  KIND.rope = function (c, a, b, v, w, L, s) {
    var col = [176, 146, 96], R0 = a * 0.94, turns = 2.6, thick = R0 / (turns * 2 + 0.6);
    c.lineCap = 'round'; c.lineWidth = thick * 1.7;
    c.save(); c.shadowColor = DRAW.shadows ? SHADOW : 'rgba(0,0,0,0)'; c.shadowBlur = s; c.shadowOffsetX = s; c.shadowOffsetY = 1.4 * s;
    c.strokeStyle = css(col); c.beginPath();
    for (var i = 0; i <= 120; i++) { var t = i / 120 * Math.PI * 2 * turns, rr = R0 - thick * 0.85 - (t / (Math.PI * 2)) * thick * 1.85; var x = Math.cos(t + w * 6) * rr, y = Math.sin(t + w * 6) * rr; if (i) c.lineTo(x, y); else c.moveTo(x, y); }
    c.stroke(); c.restore();
    // the lay of the strands: short diagonal ticks along the coil
    c.strokeStyle = css(tone(col, -0.42)); c.lineWidth = Math.max(0.5, thick * 0.32);
    for (var k = 0; k <= 60; k++) { var tt = k / 60 * Math.PI * 2 * turns, r2 = R0 - thick * 0.85 - (tt / (Math.PI * 2)) * thick * 1.85, nx = Math.cos(tt + w * 6), ny = Math.sin(tt + w * 6); c.beginPath(); c.moveTo(nx * (r2 - thick * 0.6) - ny * thick * 0.3, ny * (r2 - thick * 0.6) + nx * thick * 0.3); c.lineTo(nx * (r2 + thick * 0.6) + ny * thick * 0.3, ny * (r2 + thick * 0.6) - nx * thick * 0.3); c.stroke(); }
  };
  KIND.rivet = function (c, a, b, v, w, L, s) {
    var col = v < 0.5 ? [140, 80, 50] : [110, 104, 96];
    circle(c, 0, 0, a * 0.96); bodyFill(c, litGrad(c, a, col, L, 0.5, -0.45), s);
    circle(c, L.x * a * 0.35, L.y * a * 0.35, a * 0.22); c.fillStyle = 'rgba(255,240,220,0.55)'; c.fill();
  };
  KIND.coral = function (c, a, b, v, w, L, s) {
    var col = pick([[236, 120, 110], [240, 170, 100], [220, 90, 140], [236, 220, 200]], v);
    c.lineCap = 'round'; c.strokeStyle = css(col);
    c.save(); c.shadowColor = DRAW.shadows ? SHADOW : 'rgba(0,0,0,0)'; c.shadowBlur = s; c.shadowOffsetX = s; c.shadowOffsetY = 1.4 * s;
    var br = [[-0.9, 0.1, -0.1, 0], [-0.1, 0, 0.5, -0.6], [-0.1, 0, 0.6, 0.55], [0.5, -0.6, 0.85, -0.75], [0.25, -0.3, 0.2, -0.8], [0.3, 0.27, 0.15, 0.78], [0.6, 0.55, 0.85, 0.4]].map(function (q) { return [q[0] * 0.72, q[1] * 0.72, q[2] * 0.72, q[3] * 0.72]; });
    br.forEach(function (q, i) { c.lineWidth = Math.min(a, b) * (i < 3 ? 0.30 : 0.22); c.beginPath(); c.moveTo(q[0] * a, q[1] * b); c.lineTo(q[2] * a, q[3] * b); c.stroke(); });
    c.restore();
    c.fillStyle = css(tone(col, 0.35)); br.forEach(function (q) { circle(c, q[2] * a, q[3] * b, Math.min(a, b) * 0.12); c.fill(); });
  };
  KIND.sherd = function (c, a, b, v, w, L, s) {
    var col = pick([[186, 100, 60], [170, 120, 80], [200, 150, 110]], v);
    c.beginPath(); c.moveTo(-a * 0.9, -b * 0.3); c.quadraticCurveTo(0, -b * 1.05, a * 0.88, -b * 0.42); c.lineTo(a * 0.62, b * 0.52); c.lineTo(a * 0.05, b * 0.62); c.lineTo(-a * 0.55, b * 0.7); c.closePath();
    bodyFill(c, litGrad(c, a, col, L, 0.25, -0.3), s);
    c.save(); c.clip(); c.strokeStyle = 'rgba(30,20,16,0.85)'; c.lineWidth = b * 0.18; c.beginPath(); c.moveTo(-a, -b * 0.15); c.quadraticCurveTo(0, -b * 0.75, a, -b * 0.2); c.stroke(); c.lineWidth = b * 0.07; c.beginPath(); c.moveTo(-a, b * 0.15); c.quadraticCurveTo(0, -b * 0.45, a, b * 0.1); c.stroke(); c.restore();
    c.strokeStyle = css(tone(col, 0.4)); c.lineWidth = Math.max(0.5, s * 0.6); c.beginPath(); c.moveTo(a * 0.62, b * 0.52); c.lineTo(a * 0.05, b * 0.62); c.lineTo(-a * 0.55, b * 0.7); c.stroke();
  };
  KIND.paper = function (c, a, b, v, w, L, s) {
    var col = pick([[238, 228, 204], [226, 214, 186], [244, 238, 226]], v), R = rnd('paper' + w), hw = a * 0.80, hh = b * 0.58;
    c.beginPath(); c.moveTo(-hw, -hh);
    var steps = 7, i;
    for (i = 1; i <= steps; i++) c.lineTo(-hw + i * 2 * hw / steps, -hh + (R() - 0.5) * hh * 0.18);
    c.lineTo(hw - R() * hw * 0.1, hh * 0.2); c.lineTo(hw, hh);
    for (i = steps; i >= 0; i--) c.lineTo(-hw + i * 2 * hw / steps, hh + (i % 2 ? -1 : 0) * hh * 0.16 * R());
    c.closePath(); bodyFill(c, css(col), s);
    // lines of writing in iron-gall ink, broken into words
    c.strokeStyle = 'rgba(70,46,30,0.75)'; c.lineWidth = Math.max(0.5, s * 0.55);
    var lines = Math.max(2, Math.floor(hh * 1.5 / Math.max(3, s * 3.2)));
    for (var l = 0; l < lines; l++) { var y = -hh * 0.65 + l * (hh * 1.3 / Math.max(1, lines - 1)), x = -hw * 0.82; while (x < hw * 0.7) { var wl = hw * (0.1 + R() * 0.22); c.beginPath(); c.moveTo(x, y); c.lineTo(Math.min(hw * 0.8, x + wl), y + (R() - 0.5) * 0.6); c.stroke(); x += wl + hw * 0.08; } }
    c.strokeStyle = 'rgba(120,96,60,0.35)'; c.beginPath(); c.moveTo(-hw * 0.1, -hh); c.lineTo(hw * 0.05, hh); c.stroke();
  };
  KIND.inkBlot = function (c, a, b, v, w, L, s) {
    var col = v < 0.6 ? [22, 20, 30] : [24, 30, 70], R = rnd('blot' + v);
    c.beginPath();
    for (var i = 0; i <= 24; i++) { var t = i / 24 * Math.PI * 2, k = 0.48 + 0.32 * Math.abs(Math.sin(t * 3.5 + w * 8)) * (0.6 + 0.4 * Math.sin(t * 7)); var x = Math.cos(t) * a * k, y = Math.sin(t) * b * k; if (i) c.lineTo(x, y); else c.moveTo(x, y); }
    c.closePath(); c.fillStyle = css(col, 0.92); c.fill();
    for (var j = 0; j < 5; j++) { var tt = R() * 6.28, d = 0.68 + R() * 0.2; circle(c, Math.cos(tt) * a * d, Math.sin(tt) * b * d, Math.max(0.5, a * (0.04 + R() * 0.06))); c.fill(); }
    ellipse(c, L.x * a * 0.2, L.y * b * 0.2, a * 0.16, b * 0.08, 0.4); c.fillStyle = 'rgba(255,255,255,0.22)'; c.fill();
  };
  KIND.waxSeal = function (c, a, b, v, w, L, s) {
    var col = pick([[170, 26, 36], [40, 60, 110], [30, 90, 60], [140, 100, 40]], v), R0 = a * 0.96;
    c.beginPath(); for (var i = 0; i <= 24; i++) { var t = i / 24 * Math.PI * 2, k = 0.86 + 0.12 * Math.abs(Math.sin(t * 4.5 + w * 6)); if (i) c.lineTo(Math.cos(t) * R0 * k, Math.sin(t) * R0 * k); else c.moveTo(Math.cos(t) * R0 * k, Math.sin(t) * R0 * k); }
    c.closePath(); bodyFill(c, litGrad(c, R0, col, L, 0.3, -0.35), s);
    c.strokeStyle = css(tone(col, -0.35)); c.lineWidth = Math.max(0.6, R0 * 0.08); circle(c, 0, 0, R0 * 0.62); c.stroke();
    // the struck sigil: a star of four or a fleur-like tri-leaf, raised
    c.fillStyle = css(tone(col, 0.25)); c.beginPath();
    if (w < 0.5) { for (var k2 = 0; k2 < 8; k2++) { var t2 = k2 / 8 * Math.PI * 2, r2 = k2 % 2 ? R0 * 0.16 : R0 * 0.48; if (k2) c.lineTo(Math.cos(t2) * r2, Math.sin(t2) * r2); else c.moveTo(Math.cos(t2) * r2, Math.sin(t2) * r2); } c.closePath(); }
    else { c.ellipse(0, -R0 * 0.2, R0 * 0.12, R0 * 0.28, 0, 0, Math.PI * 2); c.moveTo(R0 * 0.38, R0 * 0.1); c.ellipse(R0 * 0.24, R0 * 0.1, R0 * 0.14, R0 * 0.2, 0.9, 0, Math.PI * 2); c.moveTo(-R0 * 0.1, R0 * 0.1); c.ellipse(-R0 * 0.24, R0 * 0.1, R0 * 0.14, R0 * 0.2, -0.9, 0, Math.PI * 2); }
    c.fill();
  };
  KIND.flower = function (c, a, b, v, w, L, s) {
    var col = pick([[200, 120, 160], [226, 196, 96], [150, 140, 200], [236, 226, 220], [200, 90, 80]], v), R0 = a * 0.94, n = w < 0.5 ? 5 : 6;
    for (var i = 0; i < n; i++) { var t = i / n * Math.PI * 2 + w * 3; c.save(); c.rotate(t); ellipse(c, R0 * 0.5, 0, R0 * 0.46, R0 * 0.26); bodyFill(c, css(mix(col, [226, 214, 190], 0.25), 0.92), s * 0.5); c.strokeStyle = css(tone(col, -0.25), 0.5); c.lineWidth = Math.max(0.4, s * 0.4); c.beginPath(); c.moveTo(R0 * 0.1, 0); c.lineTo(R0 * 0.8, 0); c.stroke(); c.restore(); }
    circle(c, 0, 0, R0 * 0.22); c.fillStyle = 'rgb(186,140,50)'; c.fill();
  };

  //---------------------------------------------------------------------------
  // The eight surfaces
  //---------------------------------------------------------------------------
  function noise(c, w, h, n, col, alpha, size, R) {
    c.fillStyle = css(col, alpha);
    for (var i = 0; i < n; i++) c.fillRect(R() * w, R() * h, size, size);
  }
  function vignette(c, w, h, k) {
    var g = c.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.3, w / 2, h / 2, Math.max(w, h) * 0.75);
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,' + k + ')'); c.fillStyle = g; c.fillRect(0, 0, w, h);
  }
  var SURF = {};
  SURF.hoard = function (c, w, h, R, s) {
    c.fillStyle = 'rgb(122,80,24)'; c.fillRect(0, 0, w, h);
    // a heap of gold below the loose coins: thousands of small lit discs, warmer toward the middle
    for (var i = 0; i < w * h / (60 * s * s); i++) {
      var x = R() * w, y = R() * h, r = (4 + R() * 6) * s, k = 1 - Math.min(1, Math.hypot(x - w / 2, y - h / 2) / Math.max(w, h));
      ellipse(c, x, y, r, r * (0.55 + R() * 0.45), R() * 3); c.fillStyle = css(tone(mix([150, 104, 30], GOLD, k), (R() - 0.5) * 0.5)); c.fill();
      if (R() < 0.3) { circle(c, x - r * 0.3, y - r * 0.3, r * 0.25); c.fillStyle = 'rgba(255,240,180,0.5)'; c.fill(); }
    }
    vignette(c, w, h, 0.55);
  };
  SURF.velvet = function (c, w, h, R, s) {
    var base = [112, 18, 34]; c.fillStyle = css(base); c.fillRect(0, 0, w, h);
    // folds: broad soft bands across the cloth
    for (var i = 0; i < 9; i++) {
      var x = R() * w, wd = (60 + R() * 120) * s, ang = -0.5 + R() * 0.3, g = c.createLinearGradient(x - wd, 0, x + wd, 0);
      g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(0.45, css(tone(base, 0.22), 0.45)); g.addColorStop(0.55, css(tone(base, -0.45), 0.4)); g.addColorStop(1, 'rgba(0,0,0,0)');
      c.save(); c.translate(w / 2, h / 2); c.rotate(ang); c.translate(-w / 2, -h / 2); c.fillStyle = g; c.fillRect(-w, -h, w * 3, h * 3); c.restore();
    }
    noise(c, w, h, w * h / (6 * s), [255, 160, 170], 0.05, s, R); noise(c, w, h, w * h / (6 * s), [0, 0, 0], 0.08, s, R);
    // a gilt braid along the edge
    c.strokeStyle = css(GOLD, 0.8); c.lineWidth = 3 * s; c.strokeRect(9 * s, 9 * s, w - 18 * s, h - 18 * s);
    c.strokeStyle = css(tone(GOLD, -0.4), 0.8); c.lineWidth = s; c.setLineDash([3 * s, 3 * s]); c.strokeRect(9 * s, 9 * s, w - 18 * s, h - 18 * s); c.setLineDash([]);
    vignette(c, w, h, 0.5);
  };
  SURF.tavern = function (c, w, h, R, s) {
    var plank = 58 * s, base = [128, 84, 50];
    for (var y = -plank * R(); y < h; y += plank) {
      var col = tone(base, (R() - 0.5) * 0.3); c.fillStyle = css(col); c.fillRect(0, y, w, plank);
      c.strokeStyle = css(tone(col, -0.3), 0.55); c.lineWidth = Math.max(0.6, s * 0.8);
      for (var g = 0; g < 9; g++) { var gy = y + (g + 0.5) * plank / 9, ph = R() * 6; c.beginPath(); for (var x = 0; x <= w; x += 8 * s) { var yy = gy + Math.sin(x / (70 * s) + ph) * 2.2 * s; if (x) c.lineTo(x, yy); else c.moveTo(x, yy); } c.stroke(); }
      for (var k = 0; k < 2; k++) { var kx = R() * w, ky = y + plank * (0.3 + R() * 0.4); for (var r = 1; r <= 3; r++) { ellipse(c, kx, ky, r * 6 * s, r * 2.6 * s); c.stroke(); } }
      c.fillStyle = 'rgba(20,10,4,0.75)'; c.fillRect(0, y + plank - 2 * s, w, 2 * s);
      c.fillStyle = 'rgba(255,220,170,0.10)'; c.fillRect(0, y, w, 1.5 * s);
      if (R() < 0.6) { circle(c, R() * w, y + plank / 2, 2.4 * s); c.fillStyle = 'rgb(40,36,34)'; c.fill(); }
    }
    for (var m = 0; m < 3; m++) { c.strokeStyle = 'rgba(60,30,14,0.28)'; c.lineWidth = 4 * s; circle(c, R() * w, R() * h, (22 + R() * 10) * s); c.stroke(); }
    vignette(c, w, h, 0.5);
  };
  SURF.forest = function (c, w, h, R, s) {
    c.fillStyle = 'rgb(58,42,28)'; c.fillRect(0, 0, w, h);
    for (var i = 0; i < 26; i++) { var g = c.createRadialGradient(0, 0, 0, 0, 0, (40 + R() * 80) * s); g.addColorStop(0, 'rgba(70,96,40,0.55)'); g.addColorStop(1, 'rgba(70,96,40,0)'); c.save(); c.translate(R() * w, R() * h); c.fillStyle = g; c.fillRect(-120 * s, -120 * s, 240 * s, 240 * s); c.restore(); }
    noise(c, w, h, w * h / (8 * s), [20, 14, 8], 0.5, 1.5 * s, R); noise(c, w, h, w * h / (16 * s), [150, 120, 80], 0.35, s, R);
    vignette(c, w, h, 0.55);
  };
  SURF.beach = function (c, w, h, R, s) {
    var g = c.createLinearGradient(0, 0, w, h); g.addColorStop(0, 'rgb(214,190,146)'); g.addColorStop(1, 'rgb(170,146,108)'); c.fillStyle = g; c.fillRect(0, 0, w, h);
    // ripples left by the tide: long wavy ridges, lit on one side
    for (var y = 0; y < h; y += 11 * s) { var ph = R() * 6; for (var pass = 0; pass < 2; pass++) { c.strokeStyle = pass ? 'rgba(255,245,220,0.30)' : 'rgba(90,70,40,0.25)'; c.lineWidth = 1.6 * s; c.beginPath(); for (var x = 0; x <= w; x += 6 * s) { var yy = y + Math.sin(x / (34 * s) + ph) * 3 * s + (pass ? -1.4 * s : 0); if (x) c.lineTo(x, yy); else c.moveTo(x, yy); } c.stroke(); } }
    // the wet edge and its foam in one corner
    var wg = c.createLinearGradient(0, 0, w * 0.4, h * 0.3); wg.addColorStop(0, 'rgba(90,110,110,0.55)'); wg.addColorStop(1, 'rgba(90,110,110,0)'); c.fillStyle = wg; c.fillRect(0, 0, w, h);
    noise(c, w, h, w * h / (10 * s), [255, 250, 230], 0.4, s, R); noise(c, w, h, w * h / (14 * s), [80, 60, 40], 0.35, s, R);
    vignette(c, w, h, 0.4);
  };
  SURF.bench = function (c, w, h, R, s) {
    c.fillStyle = 'rgb(92,74,58)'; c.fillRect(0, 0, w, h);
    noise(c, w, h, w * h / (5 * s), [40, 30, 22], 0.35, 1.5 * s, R); noise(c, w, h, w * h / (10 * s), [180, 160, 130], 0.18, s, R);
    // scorch marks and stains
    for (var i = 0; i < 7; i++) { var g = c.createRadialGradient(0, 0, 0, 0, 0, (20 + R() * 50) * s); g.addColorStop(0, 'rgba(14,8,4,0.55)'); g.addColorStop(1, 'rgba(14,8,4,0)'); c.save(); c.translate(R() * w, R() * h); c.fillStyle = g; c.fillRect(-80 * s, -80 * s, 160 * s, 160 * s); c.restore(); }
    for (var j = 0; j < 4; j++) { c.strokeStyle = css(pick([[90, 140, 60], [120, 60, 140], [60, 120, 150]], R()), 0.25); c.lineWidth = 3 * s; circle(c, R() * w, R() * h, (14 + R() * 18) * s); c.stroke(); }
    // a chalked circle of working, half rubbed away
    var cx = w * (0.3 + R() * 0.4), cy = h * (0.3 + R() * 0.4), r = Math.min(w, h) * 0.34;
    c.strokeStyle = 'rgba(236,230,214,0.32)'; c.lineWidth = 2 * s; circle(c, cx, cy, r); c.stroke(); circle(c, cx, cy, r * 0.86); c.stroke();
    c.beginPath(); for (var k = 0; k <= 5; k++) { var t = -Math.PI / 2 + k * 4 * Math.PI / 5; if (k) c.lineTo(cx + Math.cos(t) * r * 0.86, cy + Math.sin(t) * r * 0.86); else c.moveTo(cx + Math.cos(t) * r * 0.86, cy + Math.sin(t) * r * 0.86); } c.stroke();
    vignette(c, w, h, 0.55);
  };
  SURF.wreck = function (c, w, h, R, s) {
    var g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, 'rgb(36,78,92)'); g.addColorStop(1, 'rgb(70,104,96)'); c.fillStyle = g; c.fillRect(0, 0, w, h);
    noise(c, w, h, w * h / (8 * s), [190, 200, 170], 0.18, s, R);
    // broken planks of the hull lying across the floor
    for (var i = 0; i < 4; i++) {
      c.save(); c.translate(R() * w, R() * h); c.rotate(-0.6 + R() * 1.2);
      var len = (160 + R() * 200) * s, wd = 30 * s; c.fillStyle = 'rgb(70,62,48)'; c.fillRect(-len / 2, -wd / 2, len, wd);
      c.strokeStyle = 'rgba(30,26,20,0.6)'; c.lineWidth = s; for (var k = 1; k < 5; k++) { c.beginPath(); c.moveTo(-len / 2, -wd / 2 + k * wd / 5); c.lineTo(len / 2, -wd / 2 + k * wd / 5 + (R() - 0.5) * 3 * s); c.stroke(); }
      c.fillStyle = 'rgb(46,40,32)'; c.beginPath(); c.moveTo(len / 2, -wd / 2); c.lineTo(len / 2 - 14 * s, 0); c.lineTo(len / 2, wd / 2); c.fill();
      c.restore();
    }
    // caustics: a net of light rippling across everything
    c.strokeStyle = 'rgba(200,240,230,0.13)'; c.lineWidth = 2.2 * s;
    for (var j = 0; j < 40; j++) { var x = R() * w, y = R() * h; c.beginPath(); c.moveTo(x, y); c.bezierCurveTo(x + 30 * s, y - 20 * s, x + 50 * s, y + 25 * s, x + 80 * s, y + 5 * s); c.stroke(); }
    vignette(c, w, h, 0.6);
  };
  SURF.library = function (c, w, h, R, s) {
    c.fillStyle = 'rgb(84,58,36)'; c.fillRect(0, 0, w, h);
    // the green leather blotter with a gilt tooled border
    var m = 16 * s; c.fillStyle = 'rgb(42,74,52)'; c.fillRect(m, m, w - 2 * m, h - 2 * m);
    noise(c, w, h, w * h / (6 * s), [10, 30, 18], 0.35, 1.5 * s, R); noise(c, w, h, w * h / (12 * s), [140, 180, 140], 0.1, s, R);
    c.strokeStyle = css(GOLD, 0.7); c.lineWidth = 1.5 * s; c.strokeRect(m + 6 * s, m + 6 * s, w - 2 * m - 12 * s, h - 2 * m - 12 * s);
    c.setLineDash([2 * s, 4 * s]); c.strokeRect(m + 10 * s, m + 10 * s, w - 2 * m - 20 * s, h - 2 * m - 20 * s); c.setLineDash([]);
    // two loose sheets under everything
    for (var i = 0; i < 2; i++) { c.save(); c.translate(R() * w, R() * h); c.rotate(-0.4 + R() * 0.8); c.fillStyle = 'rgba(232,222,196,0.85)'; c.fillRect(-90 * s, -120 * s, 180 * s, 240 * s); c.strokeStyle = 'rgba(80,60,40,0.35)'; c.lineWidth = s; for (var l = 0; l < 18; l++) { c.beginPath(); c.moveTo(-76 * s, -100 * s + l * 12 * s); c.lineTo(76 * s, -100 * s + l * 12 * s); c.stroke(); } c.restore(); }
    vignette(c, w, h, 0.5);
  };

  //---------------------------------------------------------------------------
  // The crowd grounds
  //---------------------------------------------------------------------------
  var GROUND = {};
  GROUND.plaza = function (c, w, h, R, s) {
    c.fillStyle = 'rgb(126,116,104)'; c.fillRect(0, 0, w, h);
    var cs = 22 * s;
    for (var y = 0; y < h + cs; y += cs * 0.8) { var off = (Math.floor(y / (cs * 0.8)) % 2) * cs * 0.5; for (var x = -cs; x < w + cs; x += cs) { var col = tone([150, 140, 126], (R() - 0.5) * 0.25); ellipse(c, x + off + (R() - 0.5) * 3 * s, y + (R() - 0.5) * 2 * s, cs * 0.46, cs * 0.34); c.fillStyle = css(col); c.fill(); c.strokeStyle = 'rgba(40,34,30,0.45)'; c.lineWidth = s; c.stroke(); ellipse(c, x + off - cs * 0.12, y - cs * 0.1, cs * 0.2, cs * 0.1); c.fillStyle = 'rgba(255,250,240,0.15)'; c.fill(); } }
    vignette(c, w, h, 0.45);
  };
  GROUND.meadow = function (c, w, h, R, s) {
    c.fillStyle = 'rgb(92,132,62)'; c.fillRect(0, 0, w, h);
    for (var i = 0; i < w * h / (20 * s * s); i++) { var x = R() * w, y = R() * h; c.strokeStyle = css(tone([92, 132, 62], (R() - 0.4) * 0.5), 0.8); c.lineWidth = s; c.beginPath(); c.moveTo(x, y); c.lineTo(x + (R() - 0.5) * 3 * s, y - (3 + R() * 4) * s); c.stroke(); }
    // a worn path across the fair ground
    c.strokeStyle = 'rgba(170,140,96,0.55)'; c.lineWidth = 70 * s; c.lineCap = 'round'; c.beginPath(); c.moveTo(-20 * s, h * 0.7); c.bezierCurveTo(w * 0.3, h * 0.4, w * 0.6, h * 0.9, w + 20 * s, h * 0.45); c.stroke();
    for (var f = 0; f < 60; f++) { circle(c, R() * w, R() * h, 1.6 * s); c.fillStyle = pick(['rgb(240,230,120)', 'rgb(236,236,236)', 'rgb(200,120,190)'], R()); c.fill(); }
    vignette(c, w, h, 0.4);
  };
  GROUND.quay = function (c, w, h, R, s) {
    var plank = 26 * s;
    for (var x = 0; x < w; x += plank) { var col = tone([130, 98, 66], (R() - 0.5) * 0.3); c.fillStyle = css(col); c.fillRect(x, 0, plank, h); c.fillStyle = 'rgba(20,12,6,0.7)'; c.fillRect(x + plank - 1.5 * s, 0, 1.5 * s, h); for (var y = R() * 160 * s; y < h; y += 160 * s) { c.fillRect(x, y, plank, 1.2 * s); circle(c, x + plank * 0.3, y + 5 * s, 1.4 * s); c.fill(); circle(c, x + plank * 0.7, y + 5 * s, 1.4 * s); c.fill(); } }
    vignette(c, w, h, 0.45);
  };

  //---------------------------------------------------------------------------
  // What lies on the walking ground (flat: a walker may stand on it) and the BACK ROW (stalls, tents, the quay edge).
  // The back row is drawn above the feet line `top` only: the model keeps every walker's feet below it, so a person
  // always stands in front of a stall and is never drawn behind one (RummageCore.backrowLine). f = one figure's height.
  //---------------------------------------------------------------------------
  var LITTER = {}, BACK = {};
  function puddle(c, x, y, r, s, R) {
    ellipse(c, x, y, r, r * 0.42, (R() - 0.5) * 0.4); c.fillStyle = 'rgba(70,86,96,0.42)'; c.fill();
    ellipse(c, x - r * 0.25, y - r * 0.1, r * 0.45, r * 0.12, -0.1); c.fillStyle = 'rgba(220,235,240,0.28)'; c.fill();
  }
  function straw(c, x, y, s, R) {
    c.strokeStyle = css(tone([214, 182, 102], (R() - 0.5) * 0.3), 0.9); c.lineWidth = 1.1 * s;
    for (var k = 0; k < 5; k++) { var a = R() * Math.PI, l = (5 + R() * 7) * s; c.beginPath(); c.moveTo(x, y); c.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l * 0.5); c.stroke(); }
  }
  LITTER.plaza = function (c, w, h, top, R, s, f) {
    for (var i = 0; i < 4; i++) puddle(c, R() * w, top + f * 0.4 + R() * (h - top - f * 0.4), (14 + R() * 16) * s, s, R);
    for (var j = 0; j < 26; j++) straw(c, R() * w, top + R() * (h - top), s, R);
    // cabbage leaves and dropped fruit near the stalls
    for (var k = 0; k < 14; k++) { var x = R() * w, y = top + 6 * s + R() * f * 0.9; ellipse(c, x, y, 4.5 * s, 2.6 * s, R() * 3); c.fillStyle = css(tone([110, 160, 70], (R() - 0.5) * 0.4)); c.fill(); }
    for (var a = 0; a < 6; a++) { var ax = R() * w, ay = top + 8 * s + R() * f * 1.4; circle(c, ax, ay, 2.8 * s); c.fillStyle = pick(['rgb(190,40,30)', 'rgb(220,150,40)', 'rgb(150,170,60)'], R()); c.fill(); }
  };
  LITTER.meadow = function (c, w, h, top, R, s, f) {
    for (var j = 0; j < 20; j++) straw(c, R() * w, top + R() * (h - top), s, R);
    // a picnic cloth in checks, laid flat
    var px = w * (0.12 + R() * 0.6), py = top + f * 1.2 + R() * (h - top - f * 2.2), pw = 54 * s, ph = 34 * s;
    c.save(); c.translate(px, py); c.rotate((R() - 0.5) * 0.5);
    c.fillStyle = 'rgb(236,228,212)'; c.fillRect(-pw / 2, -ph / 2, pw, ph);
    c.fillStyle = 'rgba(176,40,36,0.75)'; for (var q = 0; q < 6; q++) { c.fillRect(-pw / 2 + q * pw / 6, -ph / 2, pw / 12, ph); }
    for (var r2 = 0; r2 < 4; r2++) c.fillRect(-pw / 2, -ph / 2 + r2 * ph / 4, pw, ph / 8);
    c.fillStyle = 'rgb(150,100,52)'; circle(c, pw * 0.18, 0, 5 * s); c.fill(); c.fillStyle = 'rgb(200,60,40)'; circle(c, -pw * 0.2, -ph * 0.1, 2.6 * s); c.fill(); circle(c, -pw * 0.12, ph * 0.12, 2.6 * s); c.fill();
    c.restore();
  };
  LITTER.quay = function (c, w, h, top, R, s, f) {
    for (var i = 0; i < 3; i++) puddle(c, R() * w, top + f * 0.5 + R() * (h - top - f * 0.5), (12 + R() * 12) * s, s, R);
    // coils of rope, laid flat on the planks
    for (var k = 0; k < 4; k++) {
      var x = 30 * s + R() * (w - 60 * s), y = top + f * 0.6 + R() * (h - top - f * 1.2);
      c.strokeStyle = 'rgb(176,140,84)'; c.lineWidth = 2.4 * s; c.beginPath();
      for (var t = 0; t < 26; t++) { var a = t * 0.62, r = 2 * s + t * 0.42 * s; if (t) c.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r * 0.6); else c.moveTo(x, y); }
      c.stroke(); c.strokeStyle = 'rgba(70,50,24,0.5)'; c.lineWidth = 0.8 * s; c.stroke();
    }
    // a fishing net spread to dry
    var nx = w * (0.15 + R() * 0.55), ny = top + f * 1.3 + R() * (h - top - f * 2.4), nr = 34 * s;
    c.save(); c.translate(nx, ny); c.rotate(R() * 3); c.beginPath(); c.ellipse(0, 0, nr, nr * 0.55, 0, 0, Math.PI * 2); c.clip();
    c.strokeStyle = 'rgba(52,64,58,0.7)'; c.lineWidth = 0.9 * s;
    for (var g = -nr; g < nr; g += 5 * s) { c.beginPath(); c.moveTo(g, -nr); c.lineTo(g + nr, nr); c.stroke(); c.beginPath(); c.moveTo(g, nr); c.lineTo(g + nr, -nr); c.stroke(); }
    c.restore();
  };

  /** A barrel standing with its foot at (x, y), d across. */
  function barrel(c, x, y, d, s, R) {
    var hgt = d * 1.25, base = tone([132, 84, 44], (R() - 0.5) * 0.25);
    ellipse(c, x + d * 0.1, y, d * 0.6, d * 0.16); c.fillStyle = 'rgba(20,12,6,0.4)'; c.fill();
    var g = c.createLinearGradient(x - d / 2, 0, x + d / 2, 0); g.addColorStop(0, css(tone(base, -0.35))); g.addColorStop(0.4, css(tone(base, 0.18))); g.addColorStop(1, css(tone(base, -0.45)));
    c.beginPath(); c.moveTo(x - d * 0.44, y); c.quadraticCurveTo(x - d * 0.56, y - hgt / 2, x - d * 0.44, y - hgt); c.lineTo(x + d * 0.44, y - hgt); c.quadraticCurveTo(x + d * 0.56, y - hgt / 2, x + d * 0.44, y); c.closePath();
    c.fillStyle = g; c.fill(); c.strokeStyle = 'rgba(30,16,8,0.7)'; c.lineWidth = s; c.stroke();
    c.strokeStyle = 'rgb(70,64,60)'; c.lineWidth = 2 * s;
    for (var k = 0; k < 2; k++) { var hy = y - hgt * (0.22 + k * 0.56); c.beginPath(); c.moveTo(x - d * 0.5, hy); c.quadraticCurveTo(x, hy + d * 0.08, x + d * 0.5, hy); c.stroke(); }
    ellipse(c, x, y - hgt, d * 0.44, d * 0.13); c.fillStyle = css(tone(base, 0.05)); c.fill(); c.strokeStyle = 'rgba(30,16,8,0.6)'; c.lineWidth = s; c.stroke();
  }
  /** A crate standing with its foot at (x, y). */
  function crate(c, x, y, d, s, R) {
    var base = tone([168, 128, 78], (R() - 0.5) * 0.25), hgt = d * 0.86, dep = d * 0.28;
    c.fillStyle = 'rgba(20,12,6,0.35)'; c.fillRect(x - d / 2 + 3 * s, y - 2 * s, d, 4 * s);
    c.fillStyle = css(tone(base, 0.2)); c.beginPath(); c.moveTo(x - d / 2, y - hgt); c.lineTo(x - d / 2 + dep, y - hgt - dep * 0.7); c.lineTo(x + d / 2 + dep, y - hgt - dep * 0.7); c.lineTo(x + d / 2, y - hgt); c.closePath(); c.fill();
    c.fillStyle = css(tone(base, -0.28)); c.beginPath(); c.moveTo(x + d / 2, y); c.lineTo(x + d / 2 + dep, y - dep * 0.7); c.lineTo(x + d / 2 + dep, y - hgt - dep * 0.7); c.lineTo(x + d / 2, y - hgt); c.closePath(); c.fill();
    c.fillStyle = css(base); c.fillRect(x - d / 2, y - hgt, d, hgt);
    c.strokeStyle = 'rgba(60,36,16,0.75)'; c.lineWidth = s; c.strokeRect(x - d / 2, y - hgt, d, hgt);
    for (var k = 1; k < 3; k++) { c.beginPath(); c.moveTo(x - d / 2, y - hgt * k / 3); c.lineTo(x + d / 2, y - hgt * k / 3); c.stroke(); }
    c.lineWidth = 2 * s; c.beginPath(); c.moveTo(x - d / 2 + 2 * s, y - 2 * s); c.lineTo(x + d / 2 - 2 * s, y - hgt + 2 * s); c.stroke();
  }
  /** A sack slumped with its foot at (x, y). */
  function sack(c, x, y, d, s, R) {
    var base = tone([196, 170, 124], (R() - 0.5) * 0.2);
    c.beginPath(); c.moveTo(x - d * 0.45, y); c.quadraticCurveTo(x - d * 0.55, y - d * 0.7, x - d * 0.12, y - d * 0.95); c.lineTo(x + d * 0.12, y - d * 0.95); c.quadraticCurveTo(x + d * 0.55, y - d * 0.7, x + d * 0.45, y); c.closePath();
    var g = c.createLinearGradient(x - d / 2, 0, x + d / 2, 0); g.addColorStop(0, css(tone(base, -0.25))); g.addColorStop(0.45, css(tone(base, 0.15))); g.addColorStop(1, css(tone(base, -0.35)));
    c.fillStyle = g; c.fill(); c.strokeStyle = 'rgba(80,60,30,0.7)'; c.lineWidth = s; c.stroke();
    c.strokeStyle = 'rgb(120,84,40)'; c.lineWidth = 1.6 * s; c.beginPath(); c.moveTo(x - d * 0.14, y - d * 0.86); c.lineTo(x + d * 0.14, y - d * 0.86); c.stroke();
  }
  var AWNINGS = [[176, 38, 34], [40, 108, 64], [42, 70, 140], [196, 132, 30], [118, 52, 120]];
  /** Wares on a counter, from x0 to x1 at height y: fruit, bread, pots, cloth or cheese. */
  function wares(c, kind, x0, x1, y, f, s, R) {
    var n = Math.max(3, Math.round((x1 - x0) / (f * 0.16)));
    for (var i = 0; i < n; i++) {
      var x = x0 + (i + 0.5) * (x1 - x0) / n, j = (R() - 0.5) * 2 * s;
      if (kind === 0) { var col = pick([[200, 40, 30], [230, 150, 40], [150, 180, 60]], (i % 3) / 3 + 0.01); for (var k = 0; k < 3; k++) { circle(c, x + (k - 1) * 3.4 * s, y - 3 * s - (k === 1 ? 3 * s : 0) + j, 3 * s); c.fillStyle = css(col); c.fill(); circle(c, x + (k - 1) * 3.4 * s - s, y - 4 * s - (k === 1 ? 3 * s : 0) + j, s); c.fillStyle = 'rgba(255,255,255,0.4)'; c.fill(); } }
      else if (kind === 1) { ellipse(c, x, y - 3.5 * s, f * 0.07, 3.5 * s); c.fillStyle = css(tone([186, 124, 56], (R() - 0.5) * 0.2)); c.fill(); c.strokeStyle = 'rgba(250,220,170,0.7)'; c.lineWidth = s; for (var q = -1; q <= 1; q++) { c.beginPath(); c.moveTo(x + q * 3 * s - 2 * s, y - 5 * s); c.lineTo(x + q * 3 * s + 2 * s, y - 2 * s); c.stroke(); } }
      else if (kind === 2) { var pc = tone([150, 84, 50], (R() - 0.5) * 0.4); c.beginPath(); c.moveTo(x - 3 * s, y); c.quadraticCurveTo(x - 6 * s, y - 6 * s, x - 2 * s, y - 9 * s); c.lineTo(x + 2 * s, y - 9 * s); c.quadraticCurveTo(x + 6 * s, y - 6 * s, x + 3 * s, y); c.closePath(); c.fillStyle = css(pc); c.fill(); c.strokeStyle = 'rgba(40,20,10,0.6)'; c.lineWidth = 0.8 * s; c.stroke(); c.fillStyle = 'rgba(255,230,200,0.35)'; c.fillRect(x - 3 * s, y - 7 * s, 1.2 * s, 4 * s); }
      else if (kind === 3) { var bc = pick([[120, 40, 90], [40, 90, 130], [200, 170, 70], [60, 120, 70]], (i % 4) / 4 + 0.01); c.fillStyle = css(bc); c.fillRect(x - f * 0.06, y - 7 * s, f * 0.12, 7 * s); c.fillStyle = css(tone(bc, 0.3)); c.fillRect(x - f * 0.06, y - 7 * s, f * 0.12, 1.6 * s); c.strokeStyle = 'rgba(20,10,10,0.5)'; c.lineWidth = 0.8 * s; c.strokeRect(x - f * 0.06, y - 7 * s, f * 0.12, 7 * s); }
      else { ellipse(c, x, y - 4 * s, f * 0.075, 4 * s); c.fillStyle = 'rgb(230,190,70)'; c.fill(); c.strokeStyle = 'rgba(120,80,20,0.7)'; c.lineWidth = 0.8 * s; c.stroke(); c.fillStyle = 'rgb(246,214,110)'; c.beginPath(); c.ellipse(x, y - 5.5 * s, f * 0.06, 2 * s, 0, 0, Math.PI * 2); c.fill(); }
    }
  }
  /** One market stall: counter, posts, a striped awning with a scalloped edge, wares; its front foot at y = top. */
  function stall(c, x, wd, top, f, s, R, k) {
    var counterTop = top - f * 0.5, roof = top - f * 1.5, col = AWNINGS[k % AWNINGS.length], wood = tone([120, 78, 42], (R() - 0.5) * 0.2);
    // the shadow it throws forward onto the ground
    var sg = c.createLinearGradient(0, top - 2 * s, 0, top + f * 0.22); sg.addColorStop(0, 'rgba(20,12,6,0.45)'); sg.addColorStop(1, 'rgba(20,12,6,0)'); c.fillStyle = sg; c.fillRect(x - 4 * s, top - 2 * s, wd + 8 * s, f * 0.22);
    // the back cloth, posts
    c.fillStyle = css(tone(col, -0.55)); c.fillRect(x + 3 * s, roof, wd - 6 * s, counterTop - roof);
    c.fillStyle = css(tone(wood, -0.2)); c.fillRect(x, roof, 4 * s, top - roof); c.fillRect(x + wd - 4 * s, roof, 4 * s, top - roof);
    // the counter: a front board and a top
    c.fillStyle = css(wood); c.fillRect(x - 2 * s, counterTop, wd + 4 * s, top - counterTop);
    c.strokeStyle = 'rgba(40,22,10,0.7)'; c.lineWidth = s; c.strokeRect(x - 2 * s, counterTop, wd + 4 * s, top - counterTop);
    for (var p = 1; p < 3; p++) { c.beginPath(); c.moveTo(x - 2 * s, counterTop + (top - counterTop) * p / 3); c.lineTo(x + wd + 2 * s, counterTop + (top - counterTop) * p / 3); c.stroke(); }
    c.fillStyle = css(tone(wood, 0.25)); c.fillRect(x - 4 * s, counterTop - 3 * s, wd + 8 * s, 4 * s);
    wares(c, k % 5, x + 4 * s, x + wd - 4 * s, counterTop - 3 * s, f, s, R);
    // the awning: stripes on a slope, then the scalloped valance
    var aw = wd + 16 * s, ax = x - 8 * s, ay0 = roof - f * 0.28, ay1 = roof + f * 0.06, stripes = Math.max(4, Math.round(aw / (9 * s)));
    for (var i = 0; i < stripes; i++) {
      var sx0 = ax + aw * i / stripes, sx1 = ax + aw * (i + 1) / stripes;
      c.beginPath(); c.moveTo(sx0 + 4 * s, ay0); c.lineTo(sx1 + 4 * s, ay0); c.lineTo(sx1, ay1); c.lineTo(sx0, ay1); c.closePath();
      c.fillStyle = i % 2 ? 'rgb(238,228,206)' : css(col); c.fill();
    }
    var sc = c.createLinearGradient(0, ay0, 0, ay1); sc.addColorStop(0, 'rgba(255,250,240,0.18)'); sc.addColorStop(1, 'rgba(0,0,0,0.18)'); c.fillStyle = sc; c.fillRect(ax, ay0, aw + 4 * s, ay1 - ay0);
    var sw = aw / stripes;
    for (var v = 0; v < stripes; v++) { c.beginPath(); c.moveTo(ax + v * sw, ay1); c.arc(ax + v * sw + sw / 2, ay1, sw / 2, Math.PI, 0, true); c.closePath(); c.fillStyle = v % 2 ? 'rgb(226,214,190)' : css(tone(col, -0.12)); c.fill(); }
    c.strokeStyle = 'rgba(30,14,8,0.55)'; c.lineWidth = s; c.beginPath(); c.moveTo(ax + 4 * s, ay0); c.lineTo(ax + aw + 4 * s, ay0); c.stroke();
  }
  /** A run of timber-framed house fronts across the top of the square, down to y = base. */
  function facades(c, w, base, s, R) {
    var x = -R() * 40 * s;
    while (x < w) {
      var hw = (90 + R() * 60) * s, plaster = tone([226, 210, 176], (R() - 0.5) * 0.18), beam = 'rgb(62,40,24)';
      c.fillStyle = css(plaster); c.fillRect(x, 0, hw, base);
      c.fillStyle = beam; c.fillRect(x, 0, 5 * s, base); c.fillRect(x, base * 0.5, hw, 4 * s); c.fillRect(x, base - 5 * s, hw, 5 * s);
      c.strokeStyle = beam; c.lineWidth = 4 * s; c.beginPath(); c.moveTo(x + 5 * s, base * 0.5); c.lineTo(x + hw * 0.3, base - 5 * s); c.moveTo(x + hw, base * 0.5); c.lineTo(x + hw * 0.7, base - 5 * s); c.stroke();
      for (var wi = 0; wi < 2; wi++) {
        var wx = x + hw * (0.22 + wi * 0.42), wy = base * 0.12, ww = hw * 0.2, wh = base * 0.28;
        c.fillStyle = 'rgb(40,46,52)'; c.fillRect(wx, wy, ww, wh); c.strokeStyle = 'rgba(200,190,150,0.55)'; c.lineWidth = s;
        c.beginPath(); c.moveTo(wx + ww / 2, wy); c.lineTo(wx + ww / 2, wy + wh); c.moveTo(wx, wy + wh / 2); c.lineTo(wx + ww, wy + wh / 2); c.stroke();
        c.fillStyle = 'rgba(255,240,200,0.18)'; c.fillRect(wx + 2 * s, wy + 2 * s, ww * 0.3, wh * 0.3);
        c.fillStyle = 'rgb(70,96,64)'; c.fillRect(wx - ww * 0.3, wy, ww * 0.26, wh); c.fillRect(wx + ww * 1.04, wy, ww * 0.26, wh);
        c.fillStyle = 'rgb(120,64,40)'; c.fillRect(wx - 2 * s, wy + wh, ww + 4 * s, 3 * s);
      }
      c.fillStyle = 'rgba(30,18,10,0.5)'; c.fillRect(x + hw - 2 * s, 0, 2 * s, base);
      x += hw;
    }
    var g = c.createLinearGradient(0, 0, 0, 14 * s); g.addColorStop(0, 'rgba(0,0,0,0.55)'); g.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = g; c.fillRect(0, 0, w, 14 * s);
  }
  BACK.plaza = function (c, w, h, top, R, s, f) {
    facades(c, w, Math.round(top - f * 1.25), s, R);
    var n = Math.max(2, Math.round(w / (f * 2.3))), slot = w / n, k0 = Math.floor(R() * 5);
    for (var i = 0; i < n; i++) {
      var wd = slot * (0.62 + R() * 0.1), x = i * slot + (slot - wd) / 2;
      stall(c, x, wd, top, f, s, R, k0 + i);
      // between two stalls: a barrel, a crate or a sack, standing at the feet line
      var gx = (i + 1) * slot;
      if (i < n - 1) { var pick3 = R(); if (pick3 < 0.4) barrel(c, gx, top, f * 0.34, s, R); else if (pick3 < 0.75) crate(c, gx - f * 0.05, top, f * 0.36, s, R); else sack(c, gx, top, f * 0.3, s, R); }
    }
  };
  /** A striped round pavilion, its door facing the meadow, its foot at y = top. */
  function tent(c, cx, r, top, f, s, R, k) {
    var col = AWNINGS[k % AWNINGS.length], wallTop = top - f * 0.72, apex = top - f * 1.55, n = 8;
    ellipse(c, cx + 4 * s, top + 2 * s, r * 1.05, r * 0.2); c.fillStyle = 'rgba(20,30,10,0.35)'; c.fill();
    for (var i = 0; i < n; i++) { var x0 = cx - r + 2 * r * i / n, x1 = cx - r + 2 * r * (i + 1) / n; c.fillStyle = i % 2 ? 'rgb(238,230,210)' : css(col); c.fillRect(x0, wallTop, x1 - x0 + 0.5, top - wallTop); }
    var sh = c.createLinearGradient(cx - r, 0, cx + r, 0); sh.addColorStop(0, 'rgba(0,0,0,0.28)'); sh.addColorStop(0.4, 'rgba(255,255,255,0.08)'); sh.addColorStop(1, 'rgba(0,0,0,0.35)'); c.fillStyle = sh; c.fillRect(cx - r, wallTop, 2 * r, top - wallTop);
    // the open door
    c.fillStyle = 'rgb(36,22,16)'; c.beginPath(); c.moveTo(cx - r * 0.22, top); c.lineTo(cx, wallTop + f * 0.06); c.lineTo(cx + r * 0.22, top); c.closePath(); c.fill();
    c.fillStyle = css(tone(col, -0.2)); c.beginPath(); c.moveTo(cx - r * 0.22, top); c.lineTo(cx, wallTop + f * 0.06); c.lineTo(cx - r * 0.34, top); c.closePath(); c.fill();
    // the conical roof in wedges, then the scalloped skirt
    for (var j = 0; j < n; j++) {
      var bx0 = cx - r * 1.1 + 2.2 * r * j / n, bx1 = cx - r * 1.1 + 2.2 * r * (j + 1) / n;
      c.beginPath(); c.moveTo(cx, apex); c.lineTo(bx1, wallTop + 2 * s); c.lineTo(bx0, wallTop + 2 * s); c.closePath(); c.fillStyle = j % 2 ? 'rgb(236,226,204)' : css(tone(col, 0.05)); c.fill();
    }
    var rg = c.createLinearGradient(cx - r, 0, cx + r, 0); rg.addColorStop(0, 'rgba(0,0,0,0.25)'); rg.addColorStop(0.35, 'rgba(255,255,255,0.12)'); rg.addColorStop(1, 'rgba(0,0,0,0.3)');
    c.beginPath(); c.moveTo(cx, apex); c.lineTo(cx + r * 1.1, wallTop + 2 * s); c.lineTo(cx - r * 1.1, wallTop + 2 * s); c.closePath(); c.fillStyle = rg; c.fill();
    var sk = 2.2 * r / n; for (var v = 0; v < n; v++) { c.beginPath(); c.arc(cx - r * 1.1 + v * sk + sk / 2, wallTop + 2 * s, sk / 2, 0, Math.PI); c.closePath(); c.fillStyle = v % 2 ? 'rgb(226,214,190)' : css(tone(col, -0.15)); c.fill(); }
    // the pole and pennant
    c.strokeStyle = 'rgb(80,54,30)'; c.lineWidth = 2 * s; c.beginPath(); c.moveTo(cx, apex); c.lineTo(cx, apex - f * 0.3); c.stroke();
    c.fillStyle = css(tone(col, 0.1)); c.beginPath(); c.moveTo(cx, apex - f * 0.3); c.lineTo(cx + f * 0.26, apex - f * 0.24); c.lineTo(cx, apex - f * 0.17); c.closePath(); c.fill();
    return apex - f * 0.3;
  }
  function bunting(c, x0, y0, x1, y1, s, R) {
    var sag = 14 * s, n = Math.max(4, Math.round(Math.abs(x1 - x0) / (10 * s)));
    c.strokeStyle = 'rgba(60,40,24,0.8)'; c.lineWidth = 0.9 * s; c.beginPath(); c.moveTo(x0, y0); c.quadraticCurveTo((x0 + x1) / 2, (y0 + y1) / 2 + sag * 2, x1, y1); c.stroke();
    for (var i = 1; i < n; i++) {
      var t = i / n, u = 1 - t, x = u * u * x0 + 2 * u * t * (x0 + x1) / 2 + t * t * x1, y = u * u * y0 + 2 * u * t * ((y0 + y1) / 2 + sag * 2) + t * t * y1;
      c.beginPath(); c.moveTo(x - 3 * s, y); c.lineTo(x + 3 * s, y); c.lineTo(x, y + 7 * s); c.closePath(); c.fillStyle = css(AWNINGS[i % AWNINGS.length]); c.fill();
    }
  }
  function hayBale(c, x, y, d, s, R) {
    ellipse(c, x + 3 * s, y, d * 0.6, d * 0.15); c.fillStyle = 'rgba(20,30,10,0.35)'; c.fill();
    var g = c.createLinearGradient(0, y - d * 0.6, 0, y); g.addColorStop(0, 'rgb(236,206,116)'); g.addColorStop(1, 'rgb(176,140,62)');
    c.beginPath(); c.moveTo(x - d / 2, y); c.lineTo(x - d / 2, y - d * 0.5); c.quadraticCurveTo(x - d / 2, y - d * 0.62, x - d * 0.38, y - d * 0.62); c.lineTo(x + d * 0.38, y - d * 0.62); c.quadraticCurveTo(x + d / 2, y - d * 0.62, x + d / 2, y - d * 0.5); c.lineTo(x + d / 2, y); c.closePath();
    c.fillStyle = g; c.fill(); c.strokeStyle = 'rgba(120,90,30,0.8)'; c.lineWidth = s; c.stroke();
    c.strokeStyle = 'rgba(120,84,30,0.55)'; for (var k = 0; k < 6; k++) { var hx = x - d * 0.42 + R() * d * 0.84; c.beginPath(); c.moveTo(hx, y - d * 0.55); c.lineTo(hx + (R() - 0.5) * 4 * s, y - 2 * s); c.stroke(); }
    c.strokeStyle = 'rgb(140,60,40)'; c.lineWidth = 1.3 * s; c.beginPath(); c.moveTo(x - d * 0.2, y - d * 0.62); c.lineTo(x - d * 0.2, y); c.moveTo(x + d * 0.2, y - d * 0.62); c.lineTo(x + d * 0.2, y); c.stroke();
  }
  BACK.meadow = function (c, w, h, top, R, s, f) {
    // the hedge and trees at the meadow's far edge
    var hedgeBase = top - f * 1.2;
    c.fillStyle = 'rgb(40,66,34)'; c.fillRect(0, 0, w, hedgeBase);
    for (var i = 0; i < w / (8 * s); i++) { var x = i * 8 * s + (R() - 0.5) * 6 * s, r = (14 + R() * 18) * s, y = hedgeBase - r * 0.4 + (R() - 0.5) * 6 * s; circle(c, x, y, r); c.fillStyle = css(tone([52, 92, 44], (R() - 0.5) * 0.35)); c.fill(); circle(c, x - r * 0.3, y - r * 0.35, r * 0.45); c.fillStyle = 'rgba(160,200,110,0.18)'; c.fill(); }
    for (var t = 0; t < w / (60 * s); t++) { var tx = R() * w, tr = (24 + R() * 20) * s; circle(c, tx, tr * 0.4, tr); c.fillStyle = css(tone([36, 72, 36], (R() - 0.5) * 0.3)); c.fill(); circle(c, tx - tr * 0.3, tr * 0.1, tr * 0.5); c.fillStyle = 'rgba(170,210,120,0.14)'; c.fill(); }
    var g = c.createLinearGradient(0, hedgeBase - 6 * s, 0, hedgeBase + 20 * s); g.addColorStop(0, 'rgba(10,20,6,0.5)'); g.addColorStop(1, 'rgba(10,20,6,0)'); c.fillStyle = g; c.fillRect(0, hedgeBase - 6 * s, w, 26 * s);
    // the tents, with bunting from pennant to pennant
    var n = Math.max(2, Math.round(w / (f * 2.6))), slot = w / n, tops = [], k0 = Math.floor(R() * 5);
    for (var j = 0; j < n; j++) { var cx = (j + 0.5) * slot + (R() - 0.5) * slot * 0.12, r = Math.min(slot * 0.34, f * 0.72); tops.push([cx, tent(c, cx, r, top - (R() * f * 0.08), f, s, R, k0 + j)]); }
    for (var b = 0; b < tops.length - 1; b++) bunting(c, tops[b][0], tops[b][1], tops[b + 1][0], tops[b + 1][1], s, R);
    for (var q = 0; q < n - 1; q++) { var hx = (q + 1) * slot + (R() - 0.5) * 6 * s; if (R() < 0.6) hayBale(c, hx, top, f * 0.42, s, R); else barrel(c, hx, top, f * 0.32, s, R); }
  };
  function boat(c, cx, cy, len, s, R, k) {
    var hull = tone(pick([[110, 60, 34], [60, 80, 96], [140, 46, 36], [80, 90, 60]], (k % 4) / 4 + 0.01), (R() - 0.5) * 0.15), hh = len * 0.22;
    ellipse(c, cx, cy + hh * 0.6, len * 0.55, hh * 0.35); c.fillStyle = 'rgba(10,30,40,0.45)'; c.fill();
    c.beginPath(); c.moveTo(cx - len / 2, cy - hh * 0.3); c.quadraticCurveTo(cx - len * 0.36, cy + hh, cx, cy + hh); c.quadraticCurveTo(cx + len * 0.4, cy + hh, cx + len / 2, cy - hh * 0.45); c.lineTo(cx - len / 2, cy - hh * 0.3); c.closePath();
    c.fillStyle = css(hull); c.fill(); c.strokeStyle = 'rgba(20,10,6,0.8)'; c.lineWidth = 1.2 * s; c.stroke();
    c.strokeStyle = css(tone(hull, 0.3)); c.lineWidth = 1 * s; for (var p = 1; p < 3; p++) { c.beginPath(); c.moveTo(cx - len * 0.46, cy - hh * 0.3 + hh * 0.33 * p); c.quadraticCurveTo(cx, cy + hh * (0.2 + p * 0.25), cx + len * 0.46, cy - hh * 0.4 + hh * 0.3 * p); c.stroke(); }
    c.fillStyle = 'rgb(150,112,70)'; c.beginPath(); c.moveTo(cx - len / 2 + 4 * s, cy - hh * 0.3); c.lineTo(cx + len / 2 - 4 * s, cy - hh * 0.45); c.lineTo(cx + len / 2 - 6 * s, cy - hh * 0.2); c.lineTo(cx - len / 2 + 6 * s, cy - hh * 0.08); c.closePath(); c.fill();
    c.strokeStyle = 'rgb(70,46,24)'; c.lineWidth = 2.4 * s; c.beginPath(); c.moveTo(cx - len * 0.05, cy - hh * 0.2); c.lineTo(cx - len * 0.05, cy - len * 0.55); c.stroke();
    c.fillStyle = 'rgb(226,214,186)'; c.beginPath(); c.moveTo(cx - len * 0.05, cy - len * 0.52); c.lineTo(cx + len * 0.24, cy - len * 0.48); c.lineTo(cx + len * 0.2, cy - len * 0.42); c.lineTo(cx - len * 0.05, cy - len * 0.44); c.closePath(); c.fill();
  }
  function bollard(c, x, y, d, s) {
    ellipse(c, x + 2 * s, y, d * 0.6, d * 0.2); c.fillStyle = 'rgba(10,6,4,0.4)'; c.fill();
    c.fillStyle = 'rgb(46,44,46)'; c.fillRect(x - d * 0.32, y - d * 0.9, d * 0.64, d * 0.9);
    ellipse(c, x, y - d * 0.9, d * 0.44, d * 0.16); c.fillStyle = 'rgb(70,68,72)'; c.fill();
    c.strokeStyle = 'rgb(176,140,84)'; c.lineWidth = 2.2 * s; c.beginPath(); c.moveTo(x - d * 0.34, y - d * 0.55); c.quadraticCurveTo(x, y - d * 0.4, x + d * 0.34, y - d * 0.55); c.stroke();
  }
  BACK.quay = function (c, w, h, top, R, s, f) {
    var edge = Math.round(top - f * 0.95), stone = Math.round(f * 0.24);
    // the harbour water
    var wg = c.createLinearGradient(0, 0, 0, edge); wg.addColorStop(0, 'rgb(26,58,76)'); wg.addColorStop(1, 'rgb(44,92,108)'); c.fillStyle = wg; c.fillRect(0, 0, w, edge);
    c.strokeStyle = 'rgba(180,220,230,0.22)'; c.lineWidth = 1.2 * s;
    for (var i = 0; i < w * edge / (900 * s * s); i++) { var x = R() * w, y = R() * edge, l = (8 + R() * 16) * s; c.beginPath(); c.moveTo(x, y); c.quadraticCurveTo(x + l / 2, y - 2 * s, x + l, y); c.stroke(); }
    // boats moored along the edge
    var nb = Math.max(2, Math.round(w / (f * 3))), slot = w / nb;
    for (var b = 0; b < nb; b++) boat(c, (b + 0.5) * slot + (R() - 0.5) * slot * 0.2, edge - f * 0.32, Math.min(slot * 0.82, f * 2.1), s, R, b);
    // the stone coping
    for (var x2 = -R() * 30 * s; x2 < w; x2 += 34 * s) { c.fillStyle = css(tone([132, 126, 116], (R() - 0.5) * 0.2)); c.fillRect(x2, edge, 33 * s, stone); c.fillStyle = 'rgba(255,250,240,0.16)'; c.fillRect(x2, edge, 33 * s, 2 * s); }
    c.fillStyle = 'rgba(20,16,12,0.55)'; c.fillRect(0, edge + stone, w, 2 * s);
    // cargo standing along the edge, its feet at the feet line
    var n = Math.max(4, Math.round(w / (f * 0.95))), step = w / n;
    for (var k = 0; k < n; k++) {
      var cx = (k + 0.5) * step + (R() - 0.5) * step * 0.25, r = R(), fy = top - R() * f * 0.06;
      if (r < 0.3) crate(c, cx, fy, f * 0.4, s, R); else if (r < 0.55) barrel(c, cx, fy, f * 0.34, s, R); else if (r < 0.75) bollard(c, cx, fy, f * 0.3, s); else sack(c, cx, fy, f * 0.32, s, R);
      if (r < 0.3 && R() < 0.5) crate(c, cx + f * 0.04, fy - f * 0.36, f * 0.32, s, R);
    }
  };

  //---------------------------------------------------------------------------
  // Icons, ink, parchment, lens
  //---------------------------------------------------------------------------
  /**
   * Draw one icon of the buyer's IconSet at whole-number scale, a quarter-turn and an optional mirror, with a dark
   * outline one scaled pixel wide and a soft contact shadow. src is the IconSet image or canvas (Probe §37b: never
   * the engine bitmap's .canvas getter); scratch is a canvas this module may resize and draw on.
   */
  function drawIcon(c, src, index, x, y, px, q, flip, scratch, iw, ih) {
    iw = iw || 32; ih = ih || 32;
    var cols = Math.max(1, Math.floor((src.width || 512) / iw)), sx = (index % cols) * iw, sy = Math.floor(index / cols) * ih;
    var k = Math.max(1, Math.round(px / iw)), dw = iw * k, pad = k * 2;
    scratch.width = dw + pad * 2; scratch.height = dw + pad * 2;
    var sc = scratch.getContext('2d');
    sc.imageSmoothingEnabled = false;
    sc.clearRect(0, 0, scratch.width, scratch.height);
    // the outline: the icon's own silhouette, struck dark around it
    sc.save(); sc.translate(scratch.width / 2, scratch.height / 2); sc.rotate(q * Math.PI / 2); if (flip) sc.scale(-1, 1);
    for (var ox = -1; ox <= 1; ox++) for (var oy = -1; oy <= 1; oy++) if (ox || oy) sc.drawImage(src, sx, sy, iw, ih, -dw / 2 + ox * k, -dw / 2 + oy * k, dw, dw);
    sc.restore();
    sc.globalCompositeOperation = 'source-in'; sc.fillStyle = 'rgba(28,18,10,0.92)'; sc.fillRect(0, 0, scratch.width, scratch.height);
    sc.globalCompositeOperation = 'source-over';
    sc.save(); sc.translate(scratch.width / 2, scratch.height / 2); sc.rotate(q * Math.PI / 2); if (flip) sc.scale(-1, 1);
    sc.drawImage(src, sx, sy, iw, ih, -dw / 2, -dw / 2, dw, dw);
    sc.restore();
    c.save();
    c.imageSmoothingEnabled = false;
    if (DRAW.shadows) { c.shadowColor = 'rgba(18,10,4,0.5)'; c.shadowBlur = 2.5 * k; c.shadowOffsetX = 1.5 * k; c.shadowOffsetY = 2.2 * k; }
    c.drawImage(scratch, Math.round(x - scratch.width / 2), Math.round(y - scratch.height / 2));
    c.restore();
  }

  /** Draw one composed object (filler, decoy or target) at its place. Light comes from the upper left of the screen. */
  function drawObject(c, o, s, iconSrc, scratch, iw, ih) {
    var C = core();
    if (o.t !== C.T_FILLER) { drawIcon(c, iconSrc, o.icon, o.x, o.y, o.a / C.ICON_R, o.q, o.flip, scratch, iw, ih); return; }
    var f = KIND[o.kind]; if (!f) return;
    var lx = -0.6, ly = -0.8, L = { x: lx * o.cos + ly * o.sin, y: -lx * o.sin + ly * o.cos };
    c.save(); c.translate(o.x, o.y); c.rotate(o.ang); f(c, o.a, o.b, o.v, o.w, L, s); c.restore();
  }

  /** Bake a whole I Spy scene: the surface, then every object in z order. Returns the number of objects drawn. */
  function bakeScene(c, sc, iconSrc, scratch, s, iw, ih) {
    var R = rnd(sc.seed + ':surface:' + sc.surface);
    c.save(); (SURF[sc.surface] || SURF.hoard)(c, sc.w, sc.h, R, s || 1); c.restore();
    for (var i = 0; i < sc.objects.length; i++) drawObject(c, sc.objects[i], s || 1, iconSrc, scratch, iw, ih);
    return sc.objects.length;
  }

  function drawSurface(c, id, w, h, seed, s) { (SURF[id] || SURF.hoard)(c, w, h, rnd(seed + ':surface:' + id), s || 1); }
  /**
   * A crowd ground: the floor, the flat litter below the feet line `top`, then the back row above it. top and f (one
   * figure's height) come from the model (RummageCore.backrowLine); without them only the floor is drawn.
   */
  function drawGround(c, id, w, h, seed, s, top, f) {
    var key = GROUND[id] ? id : 'plaza', R = rnd(seed + ':ground:' + key);
    s = s || 1;
    c.save(); GROUND[key](c, w, h, R, s); c.restore();
    if (!(top > 0 && f > 0)) return;
    c.save(); LITTER[key](c, w, h, top, R, s, f); c.restore();
    c.save(); BACK[key](c, w, h, top, R, s, f); c.restore();
    vignette(c, w, h, 0.25);
  }

  /** Parchment: a deckled sheet with fibres, foxing and darker edges. */
  function drawParchment(c, x, y, w, h, seed, s) {
    var R = rnd(seed + ':parch'); s = s || 1;
    c.save();
    c.beginPath(); var step = 9 * s, px, py;
    c.moveTo(x, y + (R() * 3) * s);
    for (px = x; px <= x + w; px += step) c.lineTo(px, y + R() * 3 * s);
    for (py = y; py <= y + h; py += step) c.lineTo(x + w - R() * 3 * s, py);
    for (px = x + w; px >= x; px -= step) c.lineTo(px, y + h - R() * 3 * s);
    for (py = y + h; py >= y; py -= step) c.lineTo(x + R() * 3 * s, py);
    c.closePath();
    c.shadowColor = 'rgba(0,0,0,0.55)'; c.shadowBlur = 10 * s; c.shadowOffsetX = 3 * s; c.shadowOffsetY = 5 * s;
    var g = c.createLinearGradient(x, y, x + w, y + h); g.addColorStop(0, 'rgb(240,226,190)'); g.addColorStop(1, 'rgb(222,200,154)');
    c.fillStyle = g; c.fill(); c.shadowColor = 'rgba(0,0,0,0)';
    c.clip();
    var e = c.createRadialGradient(x + w / 2, y + h / 2, Math.min(w, h) * 0.3, x + w / 2, y + h / 2, Math.max(w, h) * 0.75);
    e.addColorStop(0, 'rgba(120,80,30,0)'); e.addColorStop(1, 'rgba(120,80,30,0.38)'); c.fillStyle = e; c.fillRect(x, y, w, h);
    c.strokeStyle = 'rgba(150,120,80,0.16)'; c.lineWidth = s;
    for (var i = 0; i < w * h / (220 * s * s); i++) { var fx = x + R() * w, fy = y + R() * h; c.beginPath(); c.moveTo(fx, fy); c.lineTo(fx + (R() - 0.5) * 18 * s, fy + (R() - 0.5) * 4 * s); c.stroke(); }
    for (var j = 0; j < 6; j++) { circle(c, x + R() * w, y + R() * h, (2 + R() * 5) * s); c.fillStyle = 'rgba(150,100,50,0.10)'; c.fill(); }
    c.restore();
  }

  var INK = 'rgba(52,26,14,0.92)';
  /** A hand-inked stroke from (x0, y0) to (x1, y1): tapered at both ends, slightly wavering. */
  function inkLine(c, x0, y0, x1, y1, wd, seed) {
    var R = rnd(seed), n = 14, dx = x1 - x0, dy = y1 - y0, len = Math.sqrt(dx * dx + dy * dy) || 1, nx = -dy / len, ny = dx / len, top = [], bot = [];
    var wob = (R() - 0.5) * 2;
    for (var i = 0; i <= n; i++) { var t = i / n, off = Math.sin(t * Math.PI * 1.5 + wob) * wd * 0.6, hw = wd * 0.5 * Math.pow(Math.sin(Math.PI * Math.min(1, 0.08 + t * 0.92)), 0.6); var cx = x0 + dx * t + nx * off, cy = y0 + dy * t + ny * off; top.push([cx + nx * hw, cy + ny * hw]); bot.push([cx - nx * hw, cy - ny * hw]); }
    c.beginPath(); top.forEach(function (p, i) { if (i) c.lineTo(p[0], p[1]); else c.moveTo(p[0], p[1]); }); for (var k = n; k >= 0; k--) c.lineTo(bot[k][0], bot[k][1]); c.closePath();
    c.fillStyle = INK; c.fill();
  }
  /** Strike a name through: one stroke, rising slightly, overshooting both ends. */
  function drawStrike(c, x0, y, x1, s, seed) { inkLine(c, x0 - 3 * s, y + 1.5 * s, x1 + 3 * s, y - 1.5 * s, 2.6 * s, seed); }
  /** Ring a find on the scene: an inked loop that does not quite close, its ends overlapping. pale = a thing that was
   *  NOT found, shown where it was: cream ink with a dark edge, so it never reads as one more find. */
  function drawRing(c, x, y, r, s, seed, pale) {
    var R = rnd(seed), a0 = R() * 6.28, n = 40, wd = 2.8 * s, top = [], bot = [];
    for (var i = 0; i <= n; i++) {
      var t = i / n, ang = a0 + t * Math.PI * 2.18, rr = r * (1 + 0.06 * Math.sin(t * 9 + a0)) + t * r * 0.08, hw = wd * 0.5 * Math.pow(Math.sin(Math.PI * Math.min(1, 0.04 + t * 0.96)), 0.5);
      var cx = x + Math.cos(ang) * rr, cy = y + Math.sin(ang) * rr * 0.88; top.push([cx + Math.cos(ang) * hw, cy + Math.sin(ang) * hw]); bot.push([cx - Math.cos(ang) * hw, cy - Math.sin(ang) * hw]);
    }
    c.save(); c.shadowColor = pale ? 'rgba(20,10,4,0.9)' : 'rgba(255,240,200,0.65)'; c.shadowBlur = (pale ? 2.2 : 3) * s;
    c.beginPath(); top.forEach(function (p, i) { if (i) c.lineTo(p[0], p[1]); else c.moveTo(p[0], p[1]); }); for (var k = n; k >= 0; k--) c.lineTo(bot[k][0], bot[k][1]); c.closePath();
    c.fillStyle = pale ? 'rgba(248,234,200,0.97)' : 'rgba(150,20,16,0.95)'; c.fill(); c.restore();
  }
  /** A small inked cross where a click found nothing. */
  function drawMiss(c, x, y, s, seed) { var r = 7 * s; inkLine(c, x - r, y - r, x + r, y + r, 2.2 * s, seed + 'a'); inkLine(c, x + r, y - r, x - r, y + r, 2.2 * s, seed + 'b'); }

  /** The brass lens rim and handle, drawn around (cx, cy) on a canvas of size 2R + handle room. */
  function drawLens(c, cx, cy, R, s) {
    // handle first, so the rim sits over its end
    c.save(); c.translate(cx, cy); c.rotate(Math.PI * 0.25);
    c.fillStyle = 'rgb(70,40,22)'; c.beginPath(); c.moveTo(R + 4 * s, -5 * s); c.lineTo(R + 46 * s, -7 * s); c.quadraticCurveTo(R + 52 * s, 0, R + 46 * s, 7 * s); c.lineTo(R + 4 * s, 5 * s); c.closePath(); c.fill();
    c.fillStyle = 'rgba(255,220,170,0.25)'; c.fillRect(R + 8 * s, -4 * s, 36 * s, 2 * s);
    c.fillStyle = css(GOLD); c.fillRect(R - 2 * s, -7 * s, 9 * s, 14 * s);
    c.restore();
    c.lineWidth = 7 * s; var g = c.createLinearGradient(cx - R, cy - R, cx + R, cy + R); g.addColorStop(0, css(tone(GOLD, 0.5))); g.addColorStop(0.5, css(GOLD)); g.addColorStop(1, css(tone(GOLD, -0.5)));
    c.strokeStyle = g; circle(c, cx, cy, R); c.stroke();
    c.lineWidth = 1.2 * s; c.strokeStyle = 'rgba(40,20,6,0.8)'; circle(c, cx, cy, R - 3.5 * s); c.stroke(); circle(c, cx, cy, R + 3.5 * s); c.stroke();
    // the glass catches the light at the upper left
    c.strokeStyle = 'rgba(255,255,255,0.35)'; c.lineWidth = 4 * s; c.beginPath(); c.arc(cx, cy, R * 0.78, Math.PI * 1.05, Math.PI * 1.45); c.stroke();
  }

  /** A four-pointed glint, size r, for the hint. */
  function drawGlint(c, x, y, r) {
    // a CLEAR centre: the rays frame the thing they point at instead of covering it (review 2026-10-20: the old bright
    // core hid the very item the hint was for)
    var g = c.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, 'rgba(255,255,240,0)'); g.addColorStop(0.2, 'rgba(255,250,225,0.12)'); g.addColorStop(0.42, 'rgba(255,240,180,0.95)'); g.addColorStop(1, 'rgba(255,220,120,0)');
    c.fillStyle = g; c.beginPath();
    for (var i = 0; i < 8; i++) { var t = i / 8 * Math.PI * 2 - Math.PI / 2, rr = i % 2 ? r * 0.18 : r; if (i) c.lineTo(x + Math.cos(t) * rr, y + Math.sin(t) * rr); else c.moveTo(x + Math.cos(t) * rr, y + Math.sin(t) * rr); }
    c.closePath(); c.fill();
    // a thin halo round the clear centre, so the eye lands on what is inside it
    c.strokeStyle = 'rgba(255,246,214,0.9)'; c.lineWidth = Math.max(1, r * 0.06); c.beginPath(); c.arc(x, y, r * 0.42, 0, Math.PI * 2); c.stroke();
  }

  /** A carved frame around the scene: a dark inset with a gilt line. */
  function drawFrame(c, x, y, w, h, s) {
    c.save();
    c.lineWidth = 10 * s; c.strokeStyle = 'rgb(38,22,12)'; c.strokeRect(x - 5 * s, y - 5 * s, w + 10 * s, h + 10 * s);
    c.lineWidth = 1.5 * s; c.strokeStyle = css(GOLD, 0.85); c.strokeRect(x - 1 * s, y - 1 * s, w + 2 * s, h + 2 * s);
    c.strokeStyle = 'rgba(255,230,180,0.25)'; c.strokeRect(x - 9 * s, y - 9 * s, w + 18 * s, h + 18 * s);
    var g = c.createLinearGradient(x, y, x, y + 16 * s); g.addColorStop(0, 'rgba(0,0,0,0.45)'); g.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = g; c.fillRect(x, y, w, 16 * s);
    c.restore();
  }

  /** A desk the panel lies on: dark walnut with grain. */
  function drawDesk(c, w, h, seed, s) {
    var R = rnd(seed + ':desk'); c.fillStyle = 'rgb(46,28,16)'; c.fillRect(0, 0, w, h);
    c.strokeStyle = 'rgba(90,56,30,0.35)'; c.lineWidth = s;
    for (var y = 0; y < h; y += 5 * s) { var ph = R() * 6; c.beginPath(); for (var x = 0; x <= w; x += 10 * s) { var yy = y + Math.sin(x / (90 * s) + ph) * 2 * s; if (x) c.lineTo(x, yy); else c.moveTo(x, yy); } c.stroke(); }
    vignette(c, w, h, 0.6);
  }

  var DRAW = {
    VERSION: '1.0.0', shadows: true, KIND: KIND, SURF: SURF, GROUND: GROUND, LITTER: LITTER, BACK: BACK, GOLD: GOLD,
    css: css, tone: tone, mix: mix, rnd: rnd,
    drawIcon: drawIcon, drawObject: drawObject, bakeScene: bakeScene, drawSurface: drawSurface, drawGround: drawGround,
    drawParchment: drawParchment, drawStrike: drawStrike, drawRing: drawRing, drawMiss: drawMiss, inkLine: inkLine,
    drawLens: drawLens, drawGlint: drawGlint, drawFrame: drawFrame, drawDesk: drawDesk
  };
  CSAF.RummageDraw = DRAW;
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.RummageDraw;
