//=============================================================================
// WrackCore.js — part of Wrack for RPG Maker MZ
// Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [Wrack] Core: derives burned, ruined, overgrown and abandoned tiles from your own tileset pixels.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * WrackCore holds the pixel rules only. It has no parameters and no commands:
 * install it ABOVE Wrack.js in the Plugin Manager. Everything you configure is in
 * Wrack.js.
 *
 * How it reads a tileset (it never guesses at a sheet's purpose; MZ declares it):
 *   A1           water            the surface darkens, scums or fills with ash
 *   A2           ground           grass, earth, paving, each by its own colours
 *   A3 rows 1,3  building roofs   opened, fallen in, mossed or faded
 *   A3 rows 2,4  building walls   sooted, broken down, vined or dusty
 *   A4           wall tops/faces  as roofs and walls
 *   A5           floor tiles      as ground
 *   B to E       objects          each 48x48 cell classified by its own pixels:
 *                                 foliage, glass, wood, stone, or other
 *
 * Autotile seams: every mark Wrack draws on an A1 to A4 sheet stays inside one
 * quarter (24x24) of the sheet with a margin, and every recolour is per pixel,
 * so whatever quarters MZ composes into a tile still meet as they did.
 */
(function(root, factory) {
    'use strict';
    const api = factory();
    if (typeof module === 'object' && module.exports) module.exports = api;
    else root.WrackCore = api;
})(typeof window !== 'undefined' ? window : this, function() {
    'use strict';

    const VERSION = '1.0.0';
    const STATES = ['burned', 'ruined', 'overgrown', 'abandoned'];

    //-------------------------------------------------------------------------
    // Seeded, order-free noise: every value is a pure function of position and
    // seed, so a sheet derives to the same bytes in Node and in the engine.
    //-------------------------------------------------------------------------
    function hash(x, y, s) {
        let h = (Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263) + Math.imul(s | 0, 1442695041)) | 0;
        h = Math.imul(h ^ (h >>> 13), 1274126177);
        h ^= h >>> 16;
        return (h >>> 0) / 4294967296;
    }
    const clamp8 = v => (v < 0 ? 0 : v > 255 ? 255 : Math.round(v));
    const luma = (r, g, b) => 0.299 * r + 0.587 * g + 0.114 * b;
    const lerp = (a, b, t) => a + (b - a) * t;

    //-------------------------------------------------------------------------
    // Image access. An image is { width, height, data } with RGBA bytes, the
    // shape of an ImageData.
    //-------------------------------------------------------------------------
    function cloneImage(img) {
        return { width: img.width, height: img.height, data: new Uint8ClampedArray(img.data) };
    }
    function px(img, x, y) {
        return (y * img.width + x) * 4;
    }
    function put(img, x, y, r, g, b, a) {
        if (x < 0 || y < 0 || x >= img.width || y >= img.height) return;
        const o = px(img, x, y);
        img.data[o] = clamp8(r);
        img.data[o + 1] = clamp8(g);
        img.data[o + 2] = clamp8(b);
        img.data[o + 3] = a === undefined ? 255 : clamp8(a);
    }
    /** Blend colour c over pixel (x,y) with strength t in [0,1]; keeps alpha unless the pixel was empty and keepEmpty is false. */
    function tint(img, x, y, c, t) {
        const o = px(img, x, y);
        const d = img.data;
        d[o] = clamp8(lerp(d[o], c[0], t));
        d[o + 1] = clamp8(lerp(d[o + 1], c[1], t));
        d[o + 2] = clamp8(lerp(d[o + 2], c[2], t));
    }
    /** Paint over a pixel, compositing onto whatever is there (also onto transparency). */
    function paint(img, x, y, c, a) {
        if (x < 0 || y < 0 || x >= img.width || y >= img.height) return;
        const o = px(img, x, y);
        const d = img.data;
        const sa = a / 255;
        const da = d[o + 3] / 255;
        const oa = sa + da * (1 - sa);
        if (oa <= 0) return;
        d[o] = clamp8((c[0] * sa + d[o] * da * (1 - sa)) / oa);
        d[o + 1] = clamp8((c[1] * sa + d[o + 1] * da * (1 - sa)) / oa);
        d[o + 2] = clamp8((c[2] * sa + d[o + 2] * da * (1 - sa)) / oa);
        d[o + 3] = clamp8(oa * 255);
    }

    //-------------------------------------------------------------------------
    // Colour reading
    //-------------------------------------------------------------------------
    function hsv(r, g, b) {
        const mx = Math.max(r, g, b);
        const mn = Math.min(r, g, b);
        const d = mx - mn;
        let h = 0;
        if (d > 0) {
            if (mx === r) h = ((g - b) / d) % 6;
            else if (mx === g) h = (b - r) / d + 2;
            else h = (r - g) / d + 4;
            h *= 60;
            if (h < 0) h += 360;
        }
        return [h, mx === 0 ? 0 : d / mx, mx / 255];
    }
    /** One pixel's family: 'leaf' | 'glass' | 'wood' | 'stone' | 'warm' | 'dark' | 'light'. */
    function family(r, g, b) {
        const [h, s, v] = hsv(r, g, b);
        if (v < 0.16) return 'dark';
        if (s < 0.16) return v > 0.82 ? 'light' : 'stone';
        if (h >= 65 && h < 170 && s > 0.2) return 'leaf';
        if (h >= 180 && h < 250 && s > 0.2 && v > 0.45) return 'glass';
        if (h >= 15 && h < 50 && v < 0.75) return 'wood';
        return 'warm';
    }

    /**
     * Census of a rectangle: share of each family among opaque pixels, mean
     * luma, and opaque share. The classifier reads this and nothing else.
     */
    function census(img, x0, y0, w, h) {
        const c = { leaf: 0, glass: 0, wood: 0, stone: 0, warm: 0, dark: 0, light: 0, opaque: 0, luma: 0, n: w * h };
        for (let y = y0; y < y0 + h; y++) {
            for (let x = x0; x < x0 + w; x++) {
                const o = px(img, x, y);
                if (img.data[o + 3] < 128) continue;
                c.opaque++;
                c[family(img.data[o], img.data[o + 1], img.data[o + 2])]++;
                c.luma += luma(img.data[o], img.data[o + 1], img.data[o + 2]);
            }
        }
        if (c.opaque) {
            c.luma /= c.opaque;
            for (const k of ['leaf', 'glass', 'wood', 'stone', 'warm', 'dark', 'light']) c[k] /= c.opaque;
        }
        c.cover = c.opaque / c.n;
        return c;
    }

    /** Ground class of an opaque surface: 'veg' | 'paved' | 'bare' | 'water'. */
    function groundClass(c) {
        if (c.cover < 0.05) return 'empty';
        if (c.leaf > 0.45) return 'veg';
        if (c.glass > 0.45) return 'water';
        if (c.stone + c.light + c.dark > 0.5) return 'paved';
        return 'bare';
    }

    /** Object class of a B-E cell: 'empty' | 'small' | 'foliage' | 'glass' | 'wood' | 'stone' | 'other'. */
    function objectClass(c) {
        if (c.opaque < 12) return 'empty';
        if (c.cover < 0.12) return 'small'; // a clump of flowers, a stone: too little to break, only to wither
        if (c.leaf > 0.4) return 'foliage';
        if (c.glass > 0.18) return 'glass';
        if (c.wood + c.warm > 0.45) return 'wood';
        if (c.stone + c.light > 0.45) return 'stone';
        return 'other';
    }

    //-------------------------------------------------------------------------
    // Palette harvest: the greens, stones and woods the buyer's art already
    // uses, so a vine is painted in THEIR green and rubble in THEIR stone.
    //-------------------------------------------------------------------------
    function harvest(sheets) {
        const buckets = { leaf: [], stone: [], wood: [] };
        for (const img of sheets) {
            if (!img || !img.width) continue;
            const step = Math.max(1, Math.floor((img.width * img.height) / 20000));
            for (let i = 0; i < img.width * img.height; i += step) {
                const o = i * 4;
                if (img.data[o + 3] < 200) continue;
                const f = family(img.data[o], img.data[o + 1], img.data[o + 2]);
                if (buckets[f]) buckets[f].push([img.data[o], img.data[o + 1], img.data[o + 2]]);
            }
        }
        const ramp = (list, fallback) => {
            if (list.length < 24) return fallback;
            list.sort((a, b) => luma(a[0], a[1], a[2]) - luma(b[0], b[1], b[2]));
            const at = q => list[Math.min(list.length - 1, Math.floor(q * list.length))];
            return [at(0.1), at(0.35), at(0.65), at(0.92)];
        };
        return {
            leaf: ramp(buckets.leaf, [[40, 78, 40], [62, 112, 52], [96, 150, 70], [150, 196, 104]]),
            stone: ramp(buckets.stone, [[70, 68, 66], [110, 106, 100], [146, 140, 132], [186, 180, 170]]),
            wood: ramp(buckets.wood, [[70, 46, 30], [104, 70, 44], [140, 100, 64], [178, 136, 90]]),
            counts: { leaf: buckets.leaf.length, stone: buckets.stone.length, wood: buckets.wood.length }
        };
    }

    // Fire's own colours are physics, not style: char, ash and ember.
    const CHAR = [[22, 18, 18], [40, 33, 30], [62, 52, 46], [92, 80, 70]];
    const ASH = [[118, 112, 106], [150, 144, 136], [182, 176, 168]];
    const EMBER = [[120, 30, 14], [214, 74, 22], [255, 156, 48], [255, 220, 120]];
    const DUST = [176, 164, 140];

    /** luma-preserving char: a pixel keeps its light and loses its colour to soot */
    function charOf(r, g, b, depth) {
        const l = luma(r, g, b) / 255;
        const k = Math.min(3, Math.floor(l * (1 - depth * 0.6) * 4));
        return CHAR[Math.max(0, k)];
    }

    //-------------------------------------------------------------------------
    // Quarter-safe marks. A "quarter" is a (tile/2)-square cell of an
    // autotile sheet; marks are clipped to its interior minus a margin so any
    // composition of quarters still meets cleanly.
    //-------------------------------------------------------------------------
    function inQuarter(x, y, qx, qy, Q, m) {
        return x >= qx + m && y >= qy + m && x < qx + Q - m && y < qy + Q - m;
    }
    function blob(img, cx, cy, r, colourAt, clip) {
        const r2 = r * r;
        for (let y = Math.floor(cy - r); y <= Math.ceil(cy + r); y++) {
            for (let x = Math.floor(cx - r); x <= Math.ceil(cx + r); x++) {
                const dx = x + 0.5 - cx;
                const dy = y + 0.5 - cy;
                if (dx * dx + dy * dy > r2) continue;
                if (clip && !clip(x, y)) continue;
                const c = colourAt(dx / r, dy / r, x, y);
                if (c) paint(img, x, y, c, c[3] === undefined ? 255 : c[3]);
            }
        }
    }
    /** A lit stone: top-left light, bottom-right dark, from a 4-tone ramp. */
    function stoneAt(ramp) {
        return function(nx, ny) {
            const s = -nx * 0.6 - ny * 0.8;
            return s > 0.45 ? ramp[3] : s > 0 ? ramp[2] : s > -0.5 ? ramp[1] : ramp[0];
        };
    }

    //-------------------------------------------------------------------------
    // Treatments. Each takes (img, rect, ctx) and edits img in place. rect is
    // {x, y, w, h} in sheet pixels; ctx carries tile size, seed, palette.
    //-------------------------------------------------------------------------
    function forPixels(img, r, fn) {
        for (let y = r.y; y < r.y + r.h; y++) {
            for (let x = r.x; x < r.x + r.w; x++) {
                const o = px(img, x, y);
                if (img.data[o + 3] === 0) continue;
                fn(x, y, o);
            }
        }
    }
    function forQuarters(r, Q, fn) {
        for (let qy = r.y; qy < r.y + r.h; qy += Q) {
            for (let qx = r.x; qx < r.x + r.w; qx += Q) fn(qx, qy);
        }
    }

    // ---- ground (A1, A2, A4 tops, A5) -------------------------------------
    // Pointwise recolours read ctx.seed (the same for every variant, so a seam
    // between two cells of different variants is never a recolour seam);
    // marks read M(), which moves with the variant.
    function marker(ctx) {
        return function(a, b, s) {
            return hash(a + ctx.m * 131, b - ctx.m * 71, s + ctx.m);
        };
    }
    /** low-frequency field in [0,1]: bilinear over a lattice of the given pitch, so patches have soft edges */
    function field(x, y, pitch, s) {
        const gx = x / pitch;
        const gy = y / pitch;
        const x0 = Math.floor(gx);
        const y0 = Math.floor(gy);
        const fx = gx - x0;
        const fy = gy - y0;
        const a = hash(x0, y0, s);
        const b = hash(x0 + 1, y0, s);
        const c = hash(x0, y0 + 1, s);
        const d = hash(x0 + 1, y0 + 1, s);
        const u = fx * fx * (3 - 2 * fx);
        const v = fy * fy * (3 - 2 * fy);
        return lerp(lerp(a, b, u), lerp(c, d, u), v);
    }
    /**
     * A soft patch inside the pixel's own quarter, chosen by the variant: 0 at
     * the quarter's margin (so it never makes a seam) and up to 1 at its
     * centre. This replaces any low-frequency pattern in sheet coordinates,
     * which would repeat every tile into a grid on the map.
     */
    function qpatch(ctx, r, x, y, salt, prob) {
        const Q = ctx.tile / 2;
        const qx = r.x + Math.floor((x - r.x) / Q) * Q;
        const qy = r.y + Math.floor((y - r.y) / Q) * Q;
        const M = marker(ctx);
        if (M(qx, qy, salt) > prob) return 0;
        const cx = qx + Q * (0.32 + M(qx, qy, salt + 1) * 0.36);
        const cy = qy + Q * (0.32 + M(qy, qx, salt + 2) * 0.36);
        const rad = Q * (0.24 + M(qx, qy, salt + 3) * 0.16);
        const edge = Math.min(x - qx, y - qy, qx + Q - 1 - x, qy + Q - 1 - y);
        if (edge < 2) return 0;
        const ragged = (hash(x, y, salt + 4) - 0.5) * 0.35;
        const v = 1 - Math.hypot(x + 0.5 - cx, y + 0.5 - cy) / rad + ragged;
        return v <= 0 ? 0 : Math.min(1, v * 1.8);
    }
    function groundBurned(img, r, ctx, cls) {
        const d = img.data;
        const M = marker(ctx);
        forPixels(img, r, (x, y, o) => {
            const n = hash(x, y, ctx.seed + 11);
            const l = luma(d[o], d[o + 1], d[o + 2]);
            // a path or paving autotile carries its own grass fringe; judged by the block it stays green on a burned map
            // and outlines every path (2026-10-08, stock Outside). Green pixels burn wherever they are.
            if (cls === 'veg' || (cls !== 'water' && family(d[o], d[o + 1], d[o + 2]) === 'leaf')) {
                // grass burns to black stubble and grey ash; a few dry stalks survive. The char follows the grass's own
                // light continuously (2026-10-08 look: four quantised levels read as salt-and-pepper noise at 1x)
                const t = Math.min(1, l / 200);
                let c = [lerp(CHAR[0][0], CHAR[2][0], t), lerp(CHAR[0][1], CHAR[2][1], t), lerp(CHAR[0][2], CHAR[2][2], t)];
                if (n > 0.99) c = ASH[n > 0.997 ? 1 : 0];
                else if (n < 0.015) c = [88, 64, 42];
                put(img, x, y, c[0], c[1], c[2], d[o + 3]);
            } else if (cls === 'water') {
                tint(img, x, y, [40, 42, 46], 0.5);
                if (n > 0.985) tint(img, x, y, ASH[1], 0.8);
            } else {
                // uniform: the soot and ash PATCHES are drawn in map space by Wrack.js's decor layer (2026-10-10, step 2 -
                // a quarter-confined patch repeated at the tile pitch, R5/R29)
                const soot = 0.62;
                tint(img, x, y, charOf(d[o], d[o + 1], d[o + 2], 0.1), cls === 'paved' ? soot : soot + 0.1);
            }
        });
        if (cls === 'water') return;
        // ash drifts are map-space now (Wrack.js decor); a few embers stay in the burnt grass, varying with the cell
        const Q = ctx.tile / 2;
        forQuarters(r, Q, (qx, qy) => {
            if (cls === 'veg' && M(qx, qy, 14) > 0.86) {
                const ex = Math.floor(qx + 4 + M(qx, qy, 15) * (Q - 8));
                const ey = Math.floor(qy + 4 + M(qy, qx, 16) * (Q - 8));
                put(img, ex, ey, ...EMBER[2]);
                put(img, ex + 1, ey, ...EMBER[1]);
                put(img, ex, ey + 1, ...EMBER[0]);
            }
        });
    }
    function groundRuined(img, r, ctx, cls) {
        const d = img.data;
        const Q = ctx.tile / 2;
        const M = marker(ctx);
        forPixels(img, r, (x, y, o) => {
            const l = luma(d[o], d[o + 1], d[o + 2]);
            if (cls === 'veg') {
                // drought: the grass dries a little everywhere; the straw PATCHES are map-space (Wrack.js decor)
                tint(img, x, y, [l * 1.1 + 22, l * 1.0 + 10, l * 0.6], 0.14);
            } else if (cls === 'water') {
                tint(img, x, y, [70, 78, 60], 0.35);
            } else {
                tint(img, x, y, [l * 0.9, l * 0.88, l * 0.84], 0.3);
            }
        });
        if (cls === 'water') return;
        forQuarters(r, Q, (qx, qy) => {
            const clip = (x, y) => inQuarter(x, y, qx, qy, Q, 2);
            // every ground cell reuses the same few quarters, so a mark here repeats across a whole field: keep them rare
            if (cls === 'paved' && M(qx, qy, 21) < 0.25) {
                // a crack, lit on its far lip
                let x = qx + 4 + Math.floor(M(qx, qy, 22) * (Q - 8));
                for (let y = qy + 2; y < qy + Q - 2; y++) {
                    if (clip(x, y)) put(img, x, y, ...ctx.pal.stone[0]);
                    if (clip(x + 1, y)) tint(img, x + 1, y, ctx.pal.stone[3], 0.5);
                    x += M(x, y, 23) < 0.3 ? -1 : M(x, y, 23) > 0.7 ? 1 : 0;
                }
            }
            if (cls !== 'veg' && M(qx, qy, 24) < 0.14) {
                // a cluster of fallen stones, not a scatter
                const cx = qx + 6 + M(qx, qy, 25) * (Q - 12);
                const cy = qy + 6 + M(qy, qx, 26) * (Q - 12);
                const n = 2 + Math.floor(M(qx, qy, 27) * 3);
                for (let i = 0; i < n; i++) {
                    blob(img, cx + (M(i, qx, 28) - 0.5) * 8, cy + (M(qy, i, 29) - 0.5) * 6, 1.6 + M(i, qy, 30) * 2.2, stoneAt(ctx.pal.stone), clip);
                }
            }
        });
    }
    function groundOvergrown(img, r, ctx, cls) {
        const d = img.data;
        const Q = ctx.tile / 2;
        const L = ctx.pal.leaf;
        const M = marker(ctx);
        forPixels(img, r, (x, y, o) => {
            const l = luma(d[o], d[o + 1], d[o + 2]);
            if (cls === 'veg') {
                // lusher and darker: grass gone long, everywhere; the long-grass PATCHES are map-space (Wrack.js decor)
                tint(img, x, y, L[1], 0.24);
            } else if (cls === 'water') {
                tint(img, x, y, [52, 90, 58], 0.45);
            } else {
                // green fills the joints; the grass creeping over paths and plazas is map-space (Wrack.js decor, R35:
                // a patch confined to a quarter cannot creep, it can only repeat)
                if (cls === 'paved' && l < ctx.groundLuma * 0.8) tint(img, x, y, L[1], 0.85);
            }
        });
        if (cls === 'water') {
            // lily pads in the tileset's own green
            forQuarters(r, Q, (qx, qy) => {
                if (M(qx, qy, 32) > 0.3) return;
                const clip = (x, y) => inQuarter(x, y, qx, qy, Q, 2);
                blob(img, qx + 5 + M(qx, qy, 33) * (Q - 10), qy + 5 + M(qy, qx, 34) * (Q - 10), 2.5 + M(qx, qy, 35) * 2, (nx, ny) => (Math.abs(nx) < 0.15 && ny < 0 ? null : ny < -0.3 ? L[3] : L[2]), clip);
            });
            return;
        }
        forQuarters(r, Q, (qx, qy) => {
            const clip = (x, y) => inQuarter(x, y, qx, qy, Q, 1);
            if (M(qx, qy, 36) > (cls === 'veg' ? 0.3 : 0.55)) return;
            // a clump: three to five tufts close together, dark roots, lit tips
            const cx = qx + 5 + M(qx, qy, 37) * (Q - 10);
            const cy = qy + Q * 0.45 + M(qy, qx, 38) * Q * 0.35;
            const tufts = 3 + Math.floor(M(qx, qy, 39) * 3);
            for (let t = 0; t < tufts; t++) {
                const bx = Math.round(cx + (M(t, qx, 40) - 0.5) * 9);
                const by = Math.round(cy + (M(qy, t, 41) - 0.5) * 4);
                for (let b = -1; b <= 1; b++) {
                    const hgt = 3 + Math.floor(M(bx + b, by, 42) * (Q / 4));
                    for (let k = 0; k < hgt; k++) {
                        const x = bx + b + (k > hgt / 2 ? b : 0);
                        const y = by - k;
                        if (clip(x, y)) put(img, x, y, ...(k >= hgt - 1 ? L[3] : k > hgt / 2 ? L[2] : L[0]));
                    }
                }
            }
        });
    }
    function groundAbandoned(img, r, ctx, cls) {
        const d = img.data;
        const Q = ctx.tile / 2;
        const L = ctx.pal.leaf;
        const M = marker(ctx);
        forPixels(img, r, (x, y, o) => {
            const l = luma(d[o], d[o + 1], d[o + 2]);
            if (cls === 'veg') {
                tint(img, x, y, [l, l, l], 0.3);
                // dried, uneven grass in streaks that wander across the quarter (independent review 2026-10-08, D11/D23:
                // one round straw patch per quarter read as polka dots at tile pitch and as a tint at map scale)
                const lx = (x - r.x) % Q, ly = (y - r.y) % Q;
                const fall = Math.min(1, Math.min(lx, ly, Q - 1 - lx, Q - 1 - ly) / 4);
                const f = field(x * 0.7 + ctx.m * 13.1, y * 1.25 + ctx.m * 7.7, 6, ctx.seed + 40);
                const g = Math.max(0, f - 0.48) * 2.4 * fall;
                if (g > 0) tint(img, x, y, [l * 1.1 + 24, l * 1.02 + 12, l * 0.62], Math.min(0.65, g));
            } else if (cls === 'water') {
                tint(img, x, y, [92, 98, 70], 0.4);
            } else {
                tint(img, x, y, [l, l, l], 0.3);
                tint(img, x, y, DUST, 0.2);
            }
        });
        if (cls === 'water') return;
        if (cls === 'veg') {
            // the grass has gone to seed: tall clumps, green at the root and straw at the head, on some quarters
            const DRY = [[150, 136, 84], [196, 178, 112]];
            forQuarters(r, Q, (qx, qy) => {
                if (M(qx, qy, 46) > 0.4) return;
                const clip = (x, y) => inQuarter(x, y, qx, qy, Q, 1);
                const cx = qx + 5 + M(qx, qy, 47) * (Q - 10);
                const cy = qy + Q * 0.55 + M(qy, qx, 48) * Q * 0.3;
                const blades = 5 + Math.floor(M(qx, qy, 49) * 4);
                for (let b = 0; b < blades; b++) {
                    const lean = (b - (blades - 1) / 2) * 0.5 + (M(b, qx, 50) - 0.5);
                    const bx = Math.round(cx + (M(b, qy, 51) - 0.5) * 6);
                    const hgt = 6 + Math.floor(M(b, qx + qy, 52) * 7);
                    for (let k = 0; k < hgt; k++) {
                        const x = bx + Math.round(lean * (k / hgt) * 2), y = Math.round(cy) - k;
                        if (!clip(x, y)) continue;
                        const head = k >= hgt - 2;
                        put(img, x, y, ...(head ? DRY[b % 2] : k < 2 ? L[0] : k < hgt * 0.6 ? L[1] : DRY[0]));
                    }
                }
            });
            return;
        }
        forQuarters(r, Q, (qx, qy) => {
            if (M(qx, qy, 42) > 0.5) return;
            const clip = (x, y) => inQuarter(x, y, qx, qy, Q, 2);
            const bx = Math.floor(qx + 4 + M(qx, qy, 43) * (Q - 8));
            const by = Math.floor(qy + Q * 0.5 + M(qy, qx, 44) * Q * 0.35);
            // a weed: a stalk and two leaves
            const hgt = 4 + Math.floor(M(qx, qy, 45) * (Q / 4));
            for (let k = 0; k < hgt; k++) if (clip(bx, by - k)) put(img, bx, by - k, ...L[k === hgt - 1 ? 3 : 1]);
            for (const s of [-1, 1]) {
                const ky = by - Math.floor(hgt * (s < 0 ? 0.4 : 0.65));
                if (clip(bx + s, ky)) put(img, bx + s, ky, ...L[2]);
                if (clip(bx + 2 * s, ky - 1)) put(img, bx + 2 * s, ky - 1, ...L[2]);
            }
        });
    }

    // ---- roofs ------------------------------------------------------------
    function roofBurned(img, r, ctx, rubbleSrc, src) {
        // ⛔ THE BURNED ROOF KEEPS ITS OWN MATERIAL, CHARRED (third independent review 2026-10-10, R3-5 + R3-12 MAJOR).
        // History: one opening per quarter read as a lattice of punched rectangles (first review, D16); the roof was then
        // drawn as a burnt shell of char boards under evenly spaced rafters, which read as a CAGE (R14) and, once RUINED
        // was redesigned on the same structure, made the two states the same drawing on every house - differing only by
        // the grass - with tile, thatch and slate all lost to one grille. Now the whole roof is the original tiles, thatch
        // or slate blackened by the fire, its courses still readable and each house still its own material, with a
        // pointwise scorch field (identical in every variant, so it meets across any composition MZ makes). The
        // burnt-through HOLES, the beams showing through them, the ash drifts and the embers are drawn in MAP space by
        // Wrack.js's decor layer: ragged, crossing tile borders, never repeating at the tile or quarter pitch (every
        // interior quarter of an A3 roof is drawn from the same few source quarters, so any per-quarter mark is a lattice).
        void rubbleSrc;
        const S = ctx.seed;
        const d = img.data;
        forPixels(img, r, (x, y, o) => {
            const so = px(src, x, y);
            const k = 0.3 + field(x, y, 6, S + 148) * 0.16;
            put(img, x, y, src.data[so] * k * 0.92 + 7, src.data[so + 1] * k * 0.8 + 5, src.data[so + 2] * k * 0.74 + 5, d[o + 3]);
        });
    }
    /**
     * Ruined: the roof has fallen in and what a player sees from above is the house's STRUCTURE, never a fill
     * (independent review 2026-10-08, D7 BLOCKER: "a featureless dark slab with a leftover roof-colour rim"):
     *   floorboards in the tileset's own wood, dimmed and weathered, darker under the standing back wall;
     *   rafters still standing ridge to eave in grey weathered wood, some snapped; beams fallen across the boards;
     *   a deep, torn remnant of the roof along the eave and a thin one at the ridge, DARKENED (no bright rim);
     *   rubble from the building's own wall stone heaped against the eave wall on some quarters, never all.
     * Every mark stays inside its quarter with the 1 px border ring untouched (the seam suite).
     */
    function roofRuined(img, r, ctx, rubbleSrc, src) {
        // (independent review 2026-10-08, R16 BLOCKER: the ruined roof was a field of short planks edge to edge and read
        // as an INTACT brown brick or shingle roof, every house the same brown.) Redesigned 2026-10-10 on the burned
        // shell's structure, in daylight: the roof has fallen in, so a player sees a dark VOID down into the house,
        // weathered GREY rafters still standing ridge to eave at one pitch, the house's OWN roof kept in torn bands at
        // the eave, ridge and sides (each house stays its colour), grey timbers fallen into the void, and wall-stone
        // rubble against the eave wall. Pointwise parts read ctx.seed (identical in every variant); per-variant marks
        // stay inside their quarter with the 1 px border ring untouched (the seam suite).
        const Q = ctx.tile / 2;
        const S = ctx.pal.stone;
        const Sd = ctx.seed;
        const M = marker(ctx);
        const d = img.data;
        const ro = 5 + Math.floor(hash(4, 7, Sd + 170) * (Q - 12)); // the rafter's left edge inside each quarter column
        function remnant(x, y) {
            const qc = Math.floor((x - r.x) / Q), qr = Math.floor((y - r.y) / Q);
            const lx = (x - r.x) % Q, ly = (y - r.y) % Q;
            let best = 99, edge = false;
            const test = (dist, keep) => { if (dist < keep) best = Math.min(best, dist); else if (dist === keep) edge = true; };
            // deep and ragged: the house keeps its roof colour as a frame (2026-10-10 look: 9-19 px read as a thin rim
            // round a dark slab, the first review's D7 again)
            if (qr === 3) test(Q - 1 - ly, 13 + Math.floor(hash(x >> 1, qc, Sd + 171) * 10));
            if (qr === 0) test(ly, 6 + Math.floor(hash(x >> 1, qc, Sd + 172) * 9));
            if (qc === 0) test(lx, 3 + Math.floor(hash(y >> 1, qr, Sd + 173) * 4));
            if (qc === 3) test(Q - 1 - lx, 3 + Math.floor(hash(y >> 1, qr, Sd + 174) * 4));
            return best < 99 ? 1 : edge ? 2 : 0;
        }
        // the void: the house's dim interior seen through the fallen roof, darkest under the standing ridge, a faint
        // trace of floor in long boards (never short ones: a short board with a dark joint reads as brickwork)
        function voidAt(x, y) {
            const qr = Math.floor((y - r.y) / Q), ly = (y - r.y) % Q;
            const under = qr === 0 ? Math.min(1, Math.max(0, (ly - 5) / 8)) : 1;
            const row = Math.floor(y / 6);
            const off = Math.floor(hash(row, 2, Sd + 175) * 53);
            const t = hash(row, Math.floor((x + off) / 53), Sd + 176);
            const base = t > 0.66 ? [46, 41, 38] : t > 0.33 ? [38, 34, 32] : [31, 28, 27];
            const seam = y % 6 === 5 ? 0.8 : 1;
            const mott = 0.9 + field(x, y, 7, Sd + 177) * 0.2;
            const k = (0.55 + 0.45 * under) * seam * mott;
            return [base[0] * k, base[1] * k, base[2] * k];
        }
        // a rafter: 4 px of weathered grey wood, a lit left face, a dark right face, a shadow on the void beside it
        function rafterAt(lx) {
            if (lx === ro) return 1;
            if (lx === ro + 1 || lx === ro + 2) return 2;
            if (lx === ro + 3) return 3;
            if (lx === ro + 4) return 4;
            return 0;
        }
        forPixels(img, r, (x, y, o) => {
            const rem = remnant(x, y);
            if (rem === 1) {
                // the roof that is left keeps its own colour (house identity), weathered a little
                const so = px(src, x, y);
                const w = 0.8 + field(x, y, 5, Sd + 178) * 0.12;
                put(img, x, y, src.data[so] * w, src.data[so + 1] * w, src.data[so + 2] * w, d[o + 3]);
                return;
            }
            if (rem === 2) { put(img, x, y, 24, 21, 19, d[o + 3]); return; }   // the torn edge
            const lx = (x - r.x) % Q;
            const rf = rafterAt(lx);
            const qr = Math.floor((y - r.y) / Q), ly = (y - r.y) % Q;
            const k = qr === 0 ? 0.78 + 0.22 * Math.min(1, ly / 10) : 1;
            if (rf === 1) { put(img, x, y, 158 * k, 150 * k, 136 * k, d[o + 3]); return; }
            if (rf === 2) { const g = lx === ro + 1 ? [118, 110, 98] : [96, 89, 80]; put(img, x, y, g[0] * k, g[1] * k, g[2] * k, d[o + 3]); return; }
            if (rf === 3) { put(img, x, y, 62 * k, 57 * k, 52 * k, d[o + 3]); return; }
            const c = voidAt(x, y);
            const sh = rf === 4 ? 0.6 : 1;
            put(img, x, y, c[0] * sh, c[1] * sh, c[2] * sh, d[o + 3]);
        });
        forQuarters(r, Q, (qx, qy) => {
            const clip = (x, y) => inQuarter(x, y, qx, qy, Q, 1) && remnant(x, y) === 0;
            const row = Math.floor((qy - r.y) / Q);
            // ⛔ NO HANGING SHEETS (third pass 2026-10-10, LOOKED AT 3x): every interior quarter of an A3 roof is drawn
            // from the SAME few source quarters, so a sheet of roof placed per quarter repeats at the quarter pitch
            // whatever its probability or position (rarer, lower and sagging sheets still stood in a grid of red tabs).
            // The house keeps its colour in the torn frame (remnant); a mark that must vary across a roof belongs to the
            // map-space layer, never to a derived tile.
            // a rafter snapped: a gap in its run, the void showing through, splintered ends
            if (row >= 1 && M(qx, qy, 179) < 0.16) {   // rare: like every per-quarter mark it repeats with its source quarter
                const y0 = qy + 4 + Math.floor(M(qx, qy, 180) * (Q - 12));
                const len = 4 + Math.floor(M(qy, qx, 181) * 6);
                for (let y = y0; y < y0 + len; y++) for (let lx = ro; lx <= ro + 4; lx++) { const x = qx + lx; if (clip(x, y)) put(img, x, y, ...voidAt(x, y)); }
                for (let lx = ro; lx <= ro + 3; lx++) {
                    const x = qx + lx;
                    if ((lx + y0) % 2 && clip(x, y0)) put(img, x, y0, 150, 142, 128);
                    if ((lx + y0) % 2 === 0 && clip(x, y0 + len - 1)) put(img, x, y0 + len - 1, 150, 142, 128);
                }
            }
            // a timber fallen into the void: grey, lit on top, a shadow under it (rarer: at 32% they read as staples)
            if (row >= 1 && M(qx, qy, 73) < 0.16) {
                const y0 = qy + 5 + Math.floor(M(qx, qy, 74) * (Q - 13));
                const slope = (M(qy, qx, 75) - 0.5) * 0.9;
                const x0 = qx + 2, x1 = qx + Q - 3;
                for (let x = x0; x < x1; x++) {
                    const y = Math.round(y0 + (x - x0) * slope);
                    if (clip(x, y)) put(img, x, y, 150, 142, 128);
                    if (clip(x, y + 1)) put(img, x, y + 1, 112, 104, 93);
                    if (clip(x, y + 2)) put(img, x, y + 2, 78, 72, 64);
                    if (clip(x, y + 3)) tint(img, x, y + 3, [10, 9, 9], 0.6);
                }
            }
            // a rubble heap against the eave wall on some quarters, in the wall's own stone
            if (row === 3 && M(qx, qy, 62) < 0.45) {
                const cx = qx + 6 + M(qx, qy, 63) * (Q - 12);
                const cy = qy + Q * 0.35 + M(qy, qx, 64) * Q * 0.15;
                const n = 3 + Math.floor(M(qx, qy, 65) * 5);
                for (let i = 0; i < n; i++) {
                    const up = i / n;
                    const bx = cx + (M(i, qx, 66) - 0.5) * (10 - up * 6);
                    const by = cy - up * 6 + (M(qy, i, 67) - 0.5) * 2;
                    const rad = (Q / 8) * (1.2 - up * 0.55) + M(i, qy, 68) * 1.4;
                    const sx = rubbleSrc ? rubbleSrc.x + Math.floor(M(i, qx, 69) * (rubbleSrc.w - 8)) : 0;
                    const sy = rubbleSrc ? rubbleSrc.y + Math.floor(M(i, qy, 70) * (rubbleSrc.h - 8)) : 0;
                    blob(img, bx, by, rad, (nx, ny, x, y) => {
                        let c = S[2];
                        if (rubbleSrc) {
                            const o = px(src, Math.min(src.width - 1, sx + ((x - Math.floor(bx)) & 7)), Math.min(src.height - 1, sy + ((y - Math.floor(by)) & 7)));
                            if (src.data[o + 3] >= 128) c = [src.data[o], src.data[o + 1], src.data[o + 2]];
                        }
                        const lit = -nx * 0.6 - ny * 0.8;
                        const k = (lit > 0.5 ? 1.08 : lit < -0.45 ? 0.55 : 0.86) * 0.8;
                        return [c[0] * k, c[1] * k, c[2] * k];
                    }, (x, y) => inQuarter(x, y, qx, qy, Q, 1));   // rubble may lie on the eave remnant too
                }
            }
        });
    }
    function roofOvergrown(img, r, ctx) {
        const d = img.data;
        const Q = ctx.tile / 2;
        const L = ctx.pal.leaf;
        const M = marker(ctx);
        let mean = 0;
        let n = 0;
        forPixels(img, r, (x, y, o) => { mean += luma(d[o], d[o + 1], d[o + 2]); n++; });
        mean /= Math.max(1, n);
        // moss hugs the courses and gathers toward the eaves (independent review 2026-10-08, D10: one soft disc per quarter
        // read as polka dots). Patches are stretched along the courses, weighted by the quarter row (ridge light, eave
        // heavy), vary with the variant, and fade to nothing at each quarter's border so every variant meets cleanly.
        const EAVE = [0.35, 0.6, 0.85, 1.1];
        forPixels(img, r, (x, y, o) => {
            const l = luma(d[o], d[o + 1], d[o + 2]);
            const lx = (x - r.x) % Q, ly = (y - r.y) % Q, row = Math.floor((y - r.y) / Q);
            const edge = Math.min(lx, ly, Q - 1 - lx, Q - 1 - ly);
            const fall = edge < 1 ? 0 : Math.min(1, edge / 3);
            const fm = field(x * 0.55 + ctx.m * 17.3, y * 1.9 + ctx.m * 9.1, 7, ctx.seed + 72);
            const amt = Math.max(0, fm * EAVE[Math.min(3, row)] - 0.42) * 2.4 * fall;
            // flat pixel art, not an alpha ramp (independent review 2026-10-08, R18: "airbrushed blur in crisp pixel
            // art"): three fixed tones and a checker dither at the patch edge
            if (l < mean * 0.86) { if (amt > 0.08) tint(img, x, y, L[amt > 0.3 ? 1 : 0], 0.7); }   // grooves first
            else if (amt > 0.55) tint(img, x, y, L[2], 0.85);
            else if (amt > 0.25) tint(img, x, y, L[1], 0.75);
            else if (amt > 0.12 && (x + y) % 2 === 0) tint(img, x, y, L[1], 0.6);
        });
        forQuarters(r, Q, (qx, qy) => {
            const clip = (x, y) => inQuarter(x, y, qx, qy, Q, 1);
            const row = Math.floor((qy - r.y) / Q);
            if (row < 2 || M(qx, qy, 74) > 0.22) return;
            // a tuft of grass rooted in a course near the eave: four to six blades, dark at the root, lit at the tips
            const bx = Math.floor(qx + 4 + M(qx, qy, 75) * (Q - 9));
            const by = Math.floor(qy + Q * 0.55 + M(qy, qx, 76) * Q * 0.3);
            const blades = 4 + Math.floor(M(qx, qy, 77) * 3);
            for (let b = 0; b < blades; b++) {
                const lean = b - (blades - 1) / 2;
                const hgt = 3 + Math.floor(M(b, qx + qy, 78) * 4);
                for (let k = 0; k < hgt; k++) {
                    const x = bx + Math.round(lean * (k / hgt) * 1.4), y = by - k;
                    if (clip(x, y)) put(img, x, y, ...(k >= hgt - 1 ? L[3] : k > hgt / 2 ? L[2] : L[0]));
                }
            }
        });
    }
    function roofAbandoned(img, r, ctx) {
        const d = img.data;
        const Q = ctx.tile / 2;
        const M = marker(ctx);
        forPixels(img, r, (x, y, o) => {
            const l = luma(d[o], d[o + 1], d[o + 2]);
            tint(img, x, y, [l, l, l], 0.5);
            tint(img, x, y, DUST, 0.18);
        });
        // a few slipped or missing tiles: the gap shows the roof's underlay and a batten across it in the tileset's own
        // wood, with the shadow of the course above (independent review 2026-10-08, D20: pure-black dashes read as
        // dead pixels)
        const Wd = ctx.pal.wood;
        forQuarters(r, Q, (qx, qy) => {
            // more and larger gaps than before (independent review 2026-10-08, D11: abandoned read as a tint at map scale)
            if (M(qx, qy, 80) > 0.5) return;
            const w = 5 + Math.floor(M(qx, qy, 81) * 8);
            const h = 3 + Math.floor(M(qy, qx, 82) * 3);
            const x0 = qx + 3 + Math.floor(M(qx, qy, 83) * (Q - 6 - w));
            const y0 = qy + 3 + Math.floor(M(qy, qx, 84) * (Q - 6 - h));
            const bat = y0 + 1 + Math.floor(h / 2);
            for (let y = y0; y < y0 + h; y++) for (let x = x0; x < x0 + w; x++) {
                const c = y === y0 ? [Wd[0][0] * 0.45, Wd[0][1] * 0.45, Wd[0][2] * 0.45] : y === bat ? Wd[2] : y === bat + 1 ? Wd[0] : [Wd[0][0] * 0.75, Wd[0][1] * 0.75, Wd[0][2] * 0.75];
                put(img, x, y, ...c);
            }
            for (let x = x0; x < x0 + w; x++) {
                const o = px(img, x, y0 + h);
                tint(img, x, y0 + h, [d[o] * 1.3, d[o + 1] * 1.3, d[o + 2] * 1.3], 0.6);
            }
        });
    }

    // ---- walls ------------------------------------------------------------
    // A wall block's quarter columns pair up: a cell's left half always comes
    // from block column 0 or 2, its right half from 1 or 3 (WALL_AUTOTILE_TABLE).
    // A vertical mark at the SAME offset in each pair runs unbroken down any
    // wall face MZ composes, however tall.
    function stemOffsets(ctx, pair) {
        const Q = ctx.tile / 2;
        const a = 3 + Math.floor(hash(pair, 1, ctx.seed + 90) * (Q / 2 - 4));
        return [a, a + Math.floor(Q / 2)];
    }
    function wallBurned(img, r, ctx) {
        const d = img.data;
        forPixels(img, r, (x, y, o) => {
            // soot climbs: heaviest under the eaves, in streaks that ran up from below
            const t = 1 - (y - r.y) / r.h;
            const streak = hash((x - r.x) % (ctx.tile / 2) >> 1, 0, ctx.seed + 91);
            const amt = Math.min(0.95, 0.55 + t * 0.3 + streak * 0.25);
            tint(img, x, y, charOf(d[o], d[o + 1], d[o + 2], 0.5), amt);
        });
    }
    function wallRuined(img, r, ctx) {
        const Q = ctx.tile / 2;
        const d = img.data;
        const M = marker(ctx);
        // broken down: the top quarter row loses its upper courses to a jagged line
        for (let qx = r.x; qx < r.x + r.w; qx += Q) {
            const qy = r.y;
            let edge = Math.floor(Q * (0.3 + M(qx, qy, 101) * 0.35));
            for (let x = qx; x < qx + Q; x++) {
                const inner = x > qx + 1 && x < qx + Q - 2;
                if (inner) edge += M(x, qy, 102) < 0.3 ? -1 : M(x, qy, 102) > 0.7 ? 1 : 0;
                edge = Math.max(4, Math.min(Q - 4, edge));
                if (!inner) continue;
                for (let y = qy; y < qy + Q; y++) {
                    if (y < qy + edge - 1) put(img, x, y, 30, 27, 26);
                    else if (y < qy + edge + 1) {
                        const o = px(img, x, y);
                        tint(img, x, y, [d[o] * 1.3 + 20, d[o + 1] * 1.3 + 20, d[o + 2] * 1.3 + 16], 0.7);
                    }
                }
            }
        }
        forQuarters({ x: r.x, y: r.y + Q, w: r.w, h: r.h - Q }, Q, (qx, qy) => {
            const clip = (x, y) => inQuarter(x, y, qx, qy, Q, 2);
            if (M(qx, qy, 103) < 0.55) {
                let x = qx + 4 + Math.floor(M(qx, qy, 104) * (Q - 8));
                for (let y = qy + 2; y < qy + Q - 2; y++) {
                    if (clip(x, y)) put(img, x, y, ...ctx.pal.stone[0]);
                    if (clip(x + 1, y)) tint(img, x + 1, y, ctx.pal.stone[3], 0.35);
                    x += M(x, y, 105) < 0.35 ? -1 : M(x, y, 105) > 0.65 ? 1 : 0;
                }
            }
            if (qy + Q >= r.y + r.h && M(qx, qy, 106) < 0.7) {
                for (let i = 0; i < 3; i++) blob(img, qx + 5 + M(qx + i, qy, 107) * (Q - 10), qy + Q - 4 - (i === 2 ? 3 : 0), 2 + M(i, qx, 108) * 2.2, stoneAt(ctx.pal.stone), clip);
            }
        });
    }
    function wallOvergrown(img, r, ctx) {
        const d = img.data;
        const L = ctx.pal.leaf;
        const Q = ctx.tile / 2;
        const M = marker(ctx);
        // ivy: unbroken stems at fixed offsets per column pair, climbing from the foot to a height that varies by stem
        for (let col = 0; col * Q < r.w; col++) {
            const offs = stemOffsets(ctx, col % 2);
            for (let s = 0; s < offs.length; s++) {
                const sx = r.x + col * Q + offs[s];
                const reach = 0.35 + hash(col % 2, s, ctx.seed + 110) * 0.65; // shared by the pair, so stems agree across quarters
                for (let y = r.y + r.h - 1; y >= r.y; y--) {
                    const up = (r.y + r.h - 1 - y) / r.h;
                    if (up > reach) break;
                    const wob = Math.round(Math.sin(y * 0.55 + s * 2) * 0.6);
                    put(img, sx + wob, y, ...L[0]);
                }
            }
        }
        // leaves along the stems and in the mortar lines, denser near the ground; these move with the variant
        let mean = 0;
        let n = 0;
        forPixels(img, r, (x, y, o) => { mean += luma(d[o], d[o + 1], d[o + 2]); n++; });
        mean /= Math.max(1, n);
        forQuarters(r, Q, (qx, qy) => {
            const clip = (x, y) => inQuarter(x, y, qx, qy, Q, 1);
            const col = Math.floor((qx - r.x) / Q);
            const low = (qy - r.y + Q) / r.h;
            const offs = stemOffsets(ctx, col % 2);
            const leaves = Math.floor(3 + low * 7 * (0.5 + M(qx, qy, 112) * 0.5));
            for (let i = 0; i < leaves; i++) {
                const s = i % 2;
                const sx = qx + offs[s] + (M(i, qx, 113) > 0.5 ? 2 : -2);
                const sy = qy + 2 + M(qx, qy + i, 114) * (Q - 4);
                const reach = 0.35 + hash(col % 2, s, ctx.seed + 110) * 0.65;
                if ((r.y + r.h - sy) / r.h > reach + 0.05) continue;
                blob(img, sx, sy, 1.7 + M(i, qy, 115) * 1.3, (nx, ny) => (ny < -0.25 && nx < 0.3 ? L[3] : ny < 0.35 ? L[2] : L[1]), clip);
            }
            // moss in the mortar of the lowest course
            if (qy + Q >= r.y + r.h) {
                forPixels(img, { x: qx, y: qy + Q / 2, w: Q, h: Q / 2 }, (x, y, o) => {
                    if (luma(d[o], d[o + 1], d[o + 2]) < mean * 0.8) put(img, x, y, ...L[1]);
                });
            }
        });
    }
    function wallAbandoned(img, r, ctx) {
        const d = img.data;
        const Q = ctx.tile / 2;
        forPixels(img, r, (x, y, o) => {
            const l = luma(d[o], d[o + 1], d[o + 2]);
            tint(img, x, y, [l, l * 0.98, l * 0.94], 0.45);
            tint(img, x, y, DUST, 0.16);
            // damp stains running down from the top, at fixed column-pair offsets so they run unbroken
            const col = Math.floor((x - r.x) / Q) % 2;
            const lx = (x - r.x) % Q;
            const sx = 4 + Math.floor(hash(col, 9, ctx.seed + 121) * (Q - 10));
            const run = hash(col, 10, ctx.seed + 122);
            if (lx >= sx && lx < sx + 3 && (y - r.y) / r.h < 0.25 + run * 0.6) tint(img, x, y, [l * 0.62, l * 0.6, l * 0.54], 0.4);
        });
        // ⛔ NO COBWEBS ON WALLS (third pass 2026-10-10, LOOKED AT 4x on a Verdant stone wall): a web placed per top quarter
        // repeats with the quarter (wall interiors share source quarters), so the webs stood in facing PAIRS at the tile
        // pitch along every eave and read as tiny "TM" glyphs (second review R20) however rare they were made.
    }

    // ---- objects (B to E) -------------------------------------------------
    function opaqueBounds(img, r) {
        let x0 = r.x + r.w;
        let y0 = r.y + r.h;
        let x1 = -1;
        let y1 = -1;
        forPixels(img, r, (x, y, o) => {
            if (img.data[o + 3] < 128) return;
            if (x < x0) x0 = x;
            if (y < y0) y0 = y;
            if (x > x1) x1 = x;
            if (y > y1) y1 = y;
        });
        return x1 < 0 ? null : { x: x0, y: y0, w: x1 - x0 + 1, h: y1 - y0 + 1 };
    }
    /**
     * The frame of the tree a foliage cell belongs to, read from the ORIGINAL sheet so every cell of a tall tree
     * finds the same one: the trunk's top and centre (the first run of 4+ rows holding 'wood' pixels in the cell's
     * centre band, scanning down through this cell and up to two below while the crown continues), the crown's top
     * (scanning up while rows stay opaque, up to two cells above) and its half-width. null when no trunk is found.
     */
    function treeFrame(src, r, T) {
        const W = src.width, H = src.height, d = src.data;
        // A tree two cells WIDE (third pass 2026-10-10, a Verdant tree: its trunk stands on the boundary between its two
        // columns, so each column's centre band missed it and the tree burned as TWO skinny bushes): the object spans
        // the neighbouring column when the boundary between them is opaque on both sides for 30% of this cell's rows.
        // Every cell of the tree then measures the same span, so all four draw ONE skeleton.
        const across = (bx) => { let n = 0; for (let y = r.y; y < r.y + T && y < H; y++) if (d[(y * W + bx - 1) * 4 + 3] >= 128 && d[(y * W + bx) * 4 + 3] >= 128) n++; return n; };
        let ox0 = r.x, ox1 = r.x + T;
        if (r.x - T >= 0 && across(r.x) >= T * 0.3) ox0 = r.x - T;
        if (r.x + 2 * T <= W && across(r.x + T) >= T * 0.3) ox1 = r.x + 2 * T;
        const span = ox1 - ox0;
        const x0 = ox0 + Math.floor(span * 0.25), x1 = ox0 + Math.ceil(span * 0.75);
        const woodRow = (y) => { let n = 0, sx = 0; for (let x = x0; x < x1; x++) { const o = (y * W + x) * 4; if (d[o + 3] >= 128 && family(d[o], d[o + 1], d[o + 2]) === 'wood') { n++; sx += x; } } return n >= 2 ? sx / n : -1; };
        const opaqueRow = (y) => { for (let x = ox0; x < ox1; x++) if (d[(y * W + x) * 4 + 3] >= 128) return true; return false; };
        let top = -1, cx = 0, half = 0;
        const yEnd = Math.min(H, r.y + 3 * T);
        let seen = false;
        for (let y = r.y; y < yEnd; y++) {
            // empty rows above the crown are skipped; a gap AFTER the crown means whatever is below is another object
            if (!opaqueRow(y)) { if (seen) break; continue; }
            seen = true;
            const c = woodRow(y);
            if (c < 0) continue;
            let run = 1;
            while (run < 4 && y + run < H && woodRow(y + run) >= 0) run++;
            if (run >= 4) {
                top = y; cx = c;
                // the trunk's half-width a few rows down
                let n = 0; const yy = Math.min(H - 1, y + 3);
                for (let x = x0; x < x1; x++) { const o = (yy * W + x) * 4; if (d[o + 3] >= 128 && family(d[o], d[o + 1], d[o + 2]) === 'wood') n++; }
                half = Math.max(1.2, n / 2);
                break;
            }
        }
        if (top < 0) return null;
        let crown = top;
        const yMin = Math.max(0, r.y - 2 * T);
        while (crown - 1 >= yMin && opaqueRow(crown - 1)) crown--;
        let reach = 0;
        for (let y = crown; y < top; y++) for (let x = ox0; x < ox1; x++) { const o = (y * W + x) * 4; if (d[o + 3] >= 128) reach = Math.max(reach, Math.abs(x + 0.5 - cx)); }
        return { cx: cx + 0.5, top: top, crown: crown, reach: Math.max(4, reach), trunkHalf: half };
    }
    /** A bare, forking crown for a burned tree, in sheet coordinates: [x1, y1, x2, y2, halfThickness] segments. */
    function treeSkeleton(f, key) {
        const H = Math.max(8, f.top - f.crown);
        const segs = [];
        const tips = [];
        const grow = (x, y, ang, len, th, depth, salt) => {
            ang = Math.max(-Math.PI + 0.35, Math.min(-0.35, ang));   // a burned branch still reaches up
            let x2 = x + Math.cos(ang) * len;
            const y2 = y + Math.sin(ang) * len;
            x2 = Math.max(f.cx - f.reach, Math.min(f.cx + f.reach, x2));
            segs.push([x, y, x2, y2, th]);
            if (depth === 0) { tips.push([x2, y2]); return; }
            const spread = 0.34 + hash(key, salt, 401) * 0.2;
            const lean = (hash(key, salt, 402) - 0.5) * 0.3;
            grow(x2, y2, ang - spread + lean, len * 0.74, Math.max(0.6, th * 0.62), depth - 1, salt * 2 + 1);
            grow(x2, y2, ang + spread + lean, len * 0.74, Math.max(0.6, th * 0.62), depth - 1, salt * 2 + 2);
        };
        grow(f.cx, f.top + 1, -Math.PI / 2 + (hash(key, 0, 403) - 0.5) * 0.16, H * 0.36, Math.max(1.1, f.trunkHalf * 0.85), 3, 0);
        return { segs: segs, tips: tips };
    }
    function objBurned(img, r, ctx, cls) {
        const d = img.data;
        const b = opaqueBounds(img, r);
        if (!b) return;
        const M = marker(ctx);
        // (independent review 2026-10-08, R15: burned trees read as "dandelion clocks": the crown's outline survived as a
        // ring, embers were scattered through it, and each 48 px cell radiated its own branches from its own bottom edge.
        // Now a tree's frame is read once from the original sheet and every cell of it draws one shared skeleton.)
        // a bush (foliage with no trunk found) burns to a low tangle from its own foot, with the same skeleton - the old
        // path left its outline as a ring full of embers (2026-10-10 look at map scale: the last "dandelion" on the map)
        const frame = cls === 'foliage' && ctx.src
            ? (treeFrame(ctx.src, r, ctx.tile) || { cx: b.x + b.w / 2, top: b.y + b.h - 2, crown: b.y + Math.floor(b.h * 0.25), reach: Math.max(4, b.w / 2), trunkHalf: 1.0 })
            : null;
        if (frame) {
            const sk = treeSkeleton(frame, (Math.round(frame.cx) * 7 + frame.top * 13 + ctx.seed) | 0);
            const s = ctx.src.data;
            forPixels(img, r, (x, y, o) => {
                const so = (y * ctx.src.width + x) * 4;
                const wasOpaque = s[so + 3] >= 128;
                // the trunk below the crown keeps its shape, charred
                if (wasOpaque && y >= frame.top && Math.abs(x + 0.5 - frame.cx) <= frame.trunkHalf + 1.5 && family(s[so], s[so + 1], s[so + 2]) !== 'leaf') {
                    // in the skeleton's own colours, so the drawn trunk above runs on without a tone step: the tile's dark
                    // outline stays char, the body is the branch core, its upper-left edge catches the light
                    const l = luma(s[so], s[so + 1], s[so + 2]);
                    const leftEdge = x + 0.5 - frame.cx < -frame.trunkHalf + 1.2;
                    const c = l < 45 ? CHAR[0] : leftEdge ? ASH[0] : CHAR[2];
                    put(img, x, y, c[0], c[1], c[2], 255);
                    return;
                }
                // everything else that was the crown goes; the skeleton is drawn over the emptied cell
                let best = 99, side = 0;
                for (const g of sk.segs) {
                    const vx = g[2] - g[0], vy = g[3] - g[1];
                    const l2 = vx * vx + vy * vy || 1;
                    let t = ((x + 0.5 - g[0]) * vx + (y + 0.5 - g[1]) * vy) / l2;
                    t = t < 0 ? 0 : t > 1 ? 1 : t;
                    const px_ = g[0] + vx * t, py_ = g[1] + vy * t;
                    const dist = Math.hypot(x + 0.5 - px_, y + 0.5 - py_) - g[4];
                    if (dist < best) { best = dist; side = (x + 0.5 - px_) * -vy + (y + 0.5 - py_) * vx; }
                }
                if (best <= 0) {
                    // lit from the upper left like the tileset: a pale ash edge on one side, char on the other
                    const c = best > -0.7 ? (side < 0 ? ASH[0] : CHAR[0]) : CHAR[2];
                    put(img, x, y, c[0], c[1], c[2], 255);
                } else if (best <= 0.8 && wasOpaque) put(img, x, y, CHAR[0][0], CHAR[0][1], CHAR[0][2], 255);   // a dark rim where the crown stood
                else d[o + 3] = 0;
            });
            // a few twig ends still glowing (at most three a tree, never scattered through the crown)
            let lit = 0;
            for (let i = 0; i < sk.tips.length && lit < 3; i++) {
                if (hash(i, frame.top, ctx.seed + 404) > 0.3) continue;
                const tx = Math.floor(sk.tips[i][0]), ty = Math.floor(sk.tips[i][1]);
                if (tx < r.x || ty < r.y || tx >= r.x + r.w || ty >= r.y + r.h) continue;
                put(img, tx, ty, ...EMBER[2]);
                lit++;
            }
            return;
        }
        if (cls === 'foliage') {
            // the canopy burns away to a charred crown of branches; the leaves go
            const cx = b.x + b.w / 2;
            const base = b.y + b.h + b.h * 0.15;
            const arms = 6;
            const angs = [];
            for (let a = 0; a < arms; a++) angs.push(-Math.PI / 2 + (a - (arms - 1) / 2) * 0.42 + (M(a, r.x, 131) - 0.5) * 0.35);
            forPixels(img, r, (x, y, o) => {
                if (d[o + 3] < 128) return;
                const f = family(d[o], d[o + 1], d[o + 2]);
                if (f !== 'leaf') {
                    tint(img, x, y, charOf(d[o], d[o + 1], d[o + 2], 0.3), 0.92);
                    return;
                }
                let near = 99;
                for (let a = 0; a < arms; a++) {
                    const vx = Math.cos(angs[a]);
                    const vy = Math.sin(angs[a]);
                    const ox = x + 0.5 - cx;
                    const oy = y + 0.5 - base;
                    const along = ox * vx + oy * vy;
                    if (along < 0) continue;
                    // a forked twig off each arm
                    const dist = Math.abs(ox * vy - oy * vx);
                    const thick = Math.max(0.7, 2.4 - along / (b.h * 0.5));
                    near = Math.min(near, dist - thick);
                    const fx = cx + vx * along * 0.6;
                    const fy = base + vy * along * 0.6;
                    const tw = angs[a] + (a % 2 ? 0.7 : -0.7);
                    const ax = x + 0.5 - fx;
                    const ay = y + 0.5 - fy;
                    const al = ax * Math.cos(tw) + ay * Math.sin(tw);
                    if (al > 0 && al < b.h * 0.3) near = Math.min(near, Math.abs(ax * Math.sin(tw) - ay * Math.cos(tw)) - 0.8);
                }
                if (near <= 0) put(img, x, y, ...(near > -0.6 && (x + y) % 3 === 0 ? CHAR[3] : near < -1.2 ? CHAR[0] : CHAR[1]));
                else if (hash(x, y, ctx.seed + 133) > 0.975) put(img, x, y, ...EMBER[2]);
                else d[o + 3] = 0;
            });
            return;
        }
        if (cls === 'glass') {
            forPixels(img, r, (x, y, o) => {
                const f = family(d[o], d[o + 1], d[o + 2]);
                if (f === 'glass' || f === 'light') {
                    const low = (y - b.y) / Math.max(1, b.h);
                    // fire still inside: a glow rising from the sill, smooth, no speckle
                    const g = Math.max(0, (low - 0.55) / 0.45);
                    put(img, x, y, 16 + g * 150, 12 + g * 44, 12 + g * 10);
                } else tint(img, x, y, charOf(d[o], d[o + 1], d[o + 2], 0.2), 0.82);
            });
            sootPlume(img, r, b, ctx);
            return;
        }
        if (cls === 'wood') {
            // charred, and a third of the pieces lose their top to a burn line with an ember lip
            // (independent review 2026-10-08, D24: a continuous orange line on every cut piece read as an outline stamp;
            // now fewer pieces are cut and the burnt edge is char with embers only in short runs along it)
            const cut = M(r.x, r.y, 150) < 0.3;
            const burnTo = cut ? b.y + Math.floor(b.h * (0.15 + M(r.x, r.y, 151) * 0.25)) : -1;
            for (let x = b.x; x < b.x + b.w; x++) {
                const line = burnTo + Math.floor((hash(x, r.y, 152) - 0.5) * 5);
                const glowing = hash(x >> 2, r.y, 153) < 0.35;
                for (let y = b.y; y < b.y + b.h; y++) {
                    const o = px(img, x, y);
                    if (d[o + 3] === 0) continue;
                    if (cut && y < line) d[o + 3] = 0;
                    else if (cut && y < line + 1) put(img, x, y, ...(glowing ? EMBER[2] : CHAR[0]));
                    else if (cut && y < line + 2) put(img, x, y, ...(glowing ? EMBER[0] : CHAR[1]));
                    else tint(img, x, y, charOf(d[o], d[o + 1], d[o + 2], 0.25), 0.88);
                }
            }
            if (!cut) sootPlume(img, r, b, ctx);
            return;
        }
        forPixels(img, r, (x, y, o) => {
            if (d[o + 3] < 128) return;
            const f = family(d[o], d[o + 1], d[o + 2]);
            // a scatter (flowers, weeds) burns to char stalks and a fleck of ash: nothing keeps its colour (2026-10-10
            // look: a flower clump at 75% char still read pink on the burned map)
            if (cls === 'small') {
                const h = hash(x, y, ctx.seed + 193);
                const c = h > 0.88 ? ASH[0] : h > 0.45 ? CHAR[1] : CHAR[0];
                put(img, x, y, c[0], c[1], c[2], d[o + 3]);
                return;
            }
            // a lamp's light goes out; stone and iron only blacken
            if (f === 'warm' && luma(d[o], d[o + 1], d[o + 2]) > 150) put(img, x, y, 36, 30, 26);
            else tint(img, x, y, charOf(d[o], d[o + 1], d[o + 2], 0), cls === 'stone' ? 0.6 : 0.75);
        });
        if (cls === 'small') return;   // a scatter is too small to smoke
        sootPlume(img, r, b, ctx);
    }
    /** soot climbing out of an object, painted into the cell's empty pixels above it so it falls on whatever is beneath */
    function sootPlume(img, r, b, ctx) {
        const cx = b.x + b.w / 2;
        for (let y = r.y; y < b.y + 2; y++) {
            const rise = (b.y - y) / Math.max(1, b.y - r.y + 1);
            const half = b.w * (0.4 + rise * 0.3);
            for (let x = Math.floor(cx - half); x <= Math.ceil(cx + half); x++) {
                if (x < r.x || x >= r.x + r.w) continue;
                const o = px(img, x, y);
                if (img.data[o + 3] > 0) continue;
                const edge = 1 - Math.abs(x + 0.5 - cx) / half;
                const a = Math.max(0, edge * (1 - rise * 0.8) * 220 * (0.7 + field(x, y, 3, ctx.seed + 161) * 0.3));
                if (a > 10) paint(img, x, y, CHAR[0], a);
            }
        }
    }
    function objRuined(img, r, ctx, cls) {
        const d = img.data;
        const b = opaqueBounds(img, r);
        if (!b) return;
        const M = marker(ctx);
        if (cls === 'foliage') return; // a ruined town's trees live on
        if (cls === 'small') {
            forPixels(img, r, (x, y, o) => { const l = luma(d[o], d[o + 1], d[o + 2]); tint(img, x, y, [l * 1.05 + 10, l * 0.95 + 4, l * 0.7], 0.55); });
            return;
        }
        if (cls === 'glass') {
            // SMASHED, not starred (third pass 2026-10-10, LOOKED AT 2x: white specks scattered over black read as a night
            // sky in the window): the pane is gone, so the middle is the dark room, and jagged shards still stand in the
            // frame - a glass pixel within 1-3 px (hashed per 2 px, so the edge is ragged) of the frame stays glass.
            const s = ctx.src || img;
            const isGlass = (x, y) => {
                if (x < r.x || y < r.y || x >= r.x + r.w || y >= r.y + r.h) return false;
                const o2 = (y * s.width + x) * 4;
                if (s.data[o2 + 3] < 128) return false;
                const f2 = family(s.data[o2], s.data[o2 + 1], s.data[o2 + 2]);
                return f2 === 'glass' || f2 === 'light';
            };
            // the distance is to the edge of the GLAZED AREA (its bounding box), not to the nearest non-glass pixel: a
            // leaded window's bars are non-glass too, and every pane would have stayed a "shard"
            let gx0 = 1e9, gy0 = 1e9, gx1 = -1, gy1 = -1;
            forPixels(img, r, (x, y) => { if (isGlass(x, y)) { if (x < gx0) gx0 = x; if (x > gx1) gx1 = x; if (y < gy0) gy0 = y; if (y > gy1) gy1 = y; } });
            // a lamp's small pane just goes dark (R3-7: a shard ring on a 12 px lantern read as a white square with a black
            // centre); a lamp = glazed width under a third of a tile (see objAbandoned)
            const lamp = gx1 >= 0 && gx1 - gx0 + 1 < ctx.tile * 0.34;
            forPixels(img, r, (x, y) => {
                if (!isGlass(x, y)) return;
                if (lamp) { put(img, x, y, 30, 28, 32); return; }
                const dist = 1 + Math.min(x - gx0, gx1 - x, y - gy0, gy1 - y);
                const jag = 1 + Math.floor(hash(x >> 1, y >> 1, ctx.seed + 171) * 2.6);
                if (dist <= jag) put(img, x, y, ...(hash(x, y, ctx.seed + 172) > 0.6 ? [204, 216, 226] : [142, 160, 176]));
                else put(img, x, y, 22, 20, 22);
            });
            return;
        }
        if (cls === 'wood') {
            // (independent review 2026-10-08, R32: two or three vertical gaps on EVERY wooden object read as one "||"
            // decal, pause-button icons on hay bales.) One of three kinds of damage per object and variant:
            const mode = Math.floor(M(r.x, r.y, 185) * 3);
            if (mode === 0) {
                // a corner broken off: a ragged triangle gone from a top corner, its splintered edge lit
                const left = M(r.y, r.x, 186) < 0.5;
                const size = Math.max(4, Math.floor(Math.min(b.w, b.h) * (0.3 + M(r.x, r.y, 187) * 0.2)));
                for (let y = b.y; y < b.y + size; y++) {
                    for (let i = 0; i < size; i++) {
                        const x = left ? b.x + i : b.x + b.w - 1 - i;
                        const edge = size - (y - b.y) - i + Math.floor((hash(x, y, 188) - 0.5) * 3);
                        const o = px(img, x, y);
                        if (d[o + 3] < 128) continue;
                        if (edge > 1) d[o + 3] = 0;
                        else if (edge > -1) put(img, x, y, ...(edge > 0 ? [d[o] * 1.35, d[o + 1] * 1.3, d[o + 2] * 1.2] : [34, 28, 24]));
                    }
                }
            } else if (mode === 1) {
                // a split: one diagonal crack from an edge, dark with a lit lip
                const x0 = b.x + 2 + Math.floor(M(r.x, r.y, 189) * Math.max(1, b.w - 5));
                const len = Math.floor(b.h * (0.35 + M(r.y, r.x, 190) * 0.35));
                const dir = M(r.x, r.y, 191) < 0.5 ? -1 : 1;
                for (let k = 0; k < len; k++) {
                    const x = x0 + Math.round(dir * k * 0.45 + (hash(k, r.x, 192) - 0.5));
                    const y = b.y + 1 + k;
                    const o = px(img, x, y);
                    if (d[o + 3] < 128) continue;
                    put(img, x, y, 18, 14, 12);
                    const o2 = px(img, x + 1, y);
                    if (d[o2 + 3] >= 128) tint(img, x + 1, y, [d[o2] * 1.4, d[o2 + 1] * 1.4, d[o2 + 2] * 1.4], 0.6);
                }
            }
            const gaps = mode === 2 ? 1 : 0;   // a single board stove in
            for (let g = 0; g < gaps; g++) {
                const gx = b.x + 2 + Math.floor(M(g, r.x, 181) * Math.max(1, b.w - 5));
                const gy0 = b.y + Math.floor(M(r.y, g, 182) * b.h * 0.4);
                const gy1 = gy0 + Math.floor(b.h * (0.3 + M(g, r.y, 183) * 0.4));
                const gEnd = Math.min(b.y + b.h, gy1);
                for (let y = gy0; y < gEnd; y++) {
                    // wide in the middle, splintered to a point at both ends (a uniform 2 px slot read as a "|" decal)
                    const taper = Math.min(y - gy0, gEnd - 1 - y);
                    const w = taper < 1 ? 1 : taper < 2 ? 2 : 3 + (hash(gx, y, 184) > 0.6 ? 1 : 0);
                    for (let x = gx; x < gx + w; x++) {
                        const o = px(img, x, y);
                        if (d[o + 3] < 128) continue;
                        put(img, x, y, ...(x === gx ? [18, 14, 12] : [34, 28, 24]));
                    }
                    const o2 = px(img, gx + w, y);
                    if (d[o2 + 3] >= 128) tint(img, gx + w, y, [d[o2] * 1.4, d[o2 + 1] * 1.4, d[o2 + 2] * 1.4], 0.7);
                }
            }
            forPixels(img, r, (x, y, o) => { if (d[o + 3] >= 128) tint(img, x, y, [luma(d[o], d[o + 1], d[o + 2]) * 0.9, luma(d[o], d[o + 1], d[o + 2]) * 0.85, luma(d[o], d[o + 1], d[o + 2]) * 0.8], 0.3); });
            return;
        }
        // stone and iron: cracked, a chip out of the rim, the light gone
        forPixels(img, r, (x, y, o) => {
            if (d[o + 3] < 128) return;
            const f = family(d[o], d[o + 1], d[o + 2]);
            if (f === 'warm' && luma(d[o], d[o + 1], d[o + 2]) > 150) put(img, x, y, 44, 38, 34);
        });
        let x = b.x + Math.floor(b.w * (0.3 + M(r.x, r.y, 185) * 0.4));
        for (let y = b.y; y < b.y + b.h * 0.7; y++) {
            const o = px(img, x, y);
            if (d[o + 3] >= 128) put(img, x, y, 22, 20, 20);
            x += M(x, y, 186) < 0.3 ? -1 : M(x, y, 186) > 0.7 ? 1 : 0;
        }
        const chip = { x: b.x + Math.floor(M(r.y, r.x, 187) * b.w * 0.6), y: b.y };
        for (let y = chip.y; y < chip.y + 3; y++) for (let x2 = chip.x; x2 < chip.x + Math.max(3, b.w * 0.2); x2++) { const o = px(img, x2, y); if (x2 < r.x + r.w) d[o + 3] = 0; }
    }
    function objOvergrown(img, r, ctx, cls) {
        const d = img.data;
        const L = ctx.pal.leaf;
        const b = opaqueBounds(img, r);
        if (!b) return;
        const M = marker(ctx);
        if (cls === 'foliage') {
            forPixels(img, r, (x, y, o) => {
                if (d[o + 3] < 128) return;
                const l = luma(d[o], d[o + 1], d[o + 2]);
                tint(img, x, y, l < 90 ? L[0] : l < 150 ? L[1] : L[2], 0.35);
            });
            return;
        }
        // moss on the upper surfaces, ivy wound round the body, leaves breaking the silhouette
        const turns = 1.5 + M(r.x, r.y, 190);
        forPixels(img, r, (x, y, o) => {
            if (d[o + 3] < 128) return;
            const above = y > r.y ? d[px(img, x, y - 1) + 3] : 0;
            if (above < 128) put(img, x, y, ...L[hash(x, y, 192) > 0.5 ? 2 : 1]);
            else if (y > r.y + 1 && d[px(img, x, y - 2) + 3] < 128 && hash(x, y, 191) > 0.4) put(img, x, y, ...L[1]);
            const t = (y - b.y) / Math.max(2, b.h);
            const wind = Math.sin(t * Math.PI * 2 * turns + ((x - b.x) / Math.max(2, b.w)) * Math.PI * 2);
            if (Math.abs(wind) < 0.16) put(img, x, y, ...L[0]);
        });
        for (let i = 0; i < 4; i++) {
            const lx = b.x + M(i, r.x, 194) * b.w;
            const ly = b.y + b.h * 0.3 + M(r.y, i, 195) * b.h * 0.7;
            blob(img, lx, ly, 1.6 + M(i, r.y, 196), (nx, ny) => (ny < 0 ? L[3] : L[2]), (x, y) => x >= r.x && y >= r.y && x < r.x + r.w && y < r.y + r.h);
        }
    }
    function objAbandoned(img, r, ctx, cls) {
        const d = img.data;
        const W = ctx.pal.wood;
        const b = opaqueBounds(img, r);
        if (!b) return;
        const M = marker(ctx);
        if (cls === 'glass') {
            // boarded up: two planks across the opening in the tileset's own wood
            const gl = { x0: 1e9, y0: 1e9, x1: -1, y1: -1 };
            forPixels(img, r, (x, y, o) => {
                const f = family(d[o], d[o + 1], d[o + 2]);
                if (f === 'glass' || f === 'light') {
                    put(img, x, y, 28, 26, 30);
                    gl.x0 = Math.min(gl.x0, x); gl.y0 = Math.min(gl.y0, y); gl.x1 = Math.max(gl.x1, x); gl.y1 = Math.max(gl.y1, y);
                }
            });
            // a LAMP is not boarded up, it just goes cold (third review R3-7: planks across a street lamp's head read as the
            // plugin misreading the tileset): glazed width under a third of a tile is a lamp, MEASURED by
            // Internal_Ops/_probe/glass_widths.js - windows 20-33 px, the lantern 12 px on our four tilesets
            if (gl.x1 >= 0 && gl.x1 - gl.x0 + 1 >= ctx.tile * 0.34) {
                const ph = Math.max(3, Math.floor((gl.y1 - gl.y0) / 4));
                const tilt = M(r.x, r.y, 197) > 0.5 ? 1 : -1;
                for (const [fy, sl] of [[0.22, 0.16 * tilt], [0.62, -0.12 * tilt]]) {
                    for (let x = b.x - 1; x <= b.x + b.w; x++) {
                        const yc = Math.round(gl.y0 + (gl.y1 - gl.y0) * fy + (x - b.x) * sl);
                        for (let k = 0; k < ph; k++) {
                            const y = yc + k;
                            if (x < r.x || x >= r.x + r.w || y < r.y || y >= r.y + r.h) continue;
                            put(img, x, y, ...(k === 0 ? W[3] : k === ph - 1 ? W[0] : (x + k) % 9 === 0 ? W[1] : W[2]));
                        }
                    }
                }
            }
            return;
        }
        forPixels(img, r, (x, y, o) => {
            if (d[o + 3] < 128) return;
            const l = luma(d[o], d[o + 1], d[o + 2]);
            const f = family(d[o], d[o + 1], d[o + 2]);
            if (f === 'warm' && l > 150 && cls !== 'foliage' && cls !== 'small') { put(img, x, y, 70, 62, 52); return; } // the lamp is cold
            tint(img, x, y, [l, l, l], cls === 'foliage' ? 0.28 : 0.45);
            tint(img, x, y, DUST, 0.2);
        });
        if (cls !== 'foliage' && cls !== 'small') {
            // weeds at the foot, painted into empty pixels so they stand on the ground beneath
            const L = ctx.pal.leaf;
            const footY = Math.min(r.y + r.h - 1, b.y + b.h);
            for (let i = 0; i < 5; i++) {
                const wx = Math.floor(b.x - 2 + M(i, r.x, 201) * (b.w + 4));
                const hgt = 3 + Math.floor(M(r.y, i, 202) * 5);
                for (let k = 0; k < hgt; k++) {
                    const y = footY - k;
                    const x = wx + (k > hgt * 0.6 ? (i % 2 ? 1 : -1) : 0);
                    if (y < r.y || y >= r.y + r.h || x < r.x || x >= r.x + r.w) continue;
                    put(img, x, y, ...(k === hgt - 1 ? L[3] : k > hgt / 2 ? L[2] : L[1]));
                }
            }
        }
    }

    const GROUND = { burned: groundBurned, ruined: groundRuined, overgrown: groundOvergrown, abandoned: groundAbandoned };
    const ROOF = { burned: roofBurned, ruined: roofRuined, overgrown: roofOvergrown, abandoned: roofAbandoned };
    const WALL = { burned: wallBurned, ruined: wallRuined, overgrown: wallOvergrown, abandoned: wallAbandoned };
    const OBJ = { burned: objBurned, ruined: objRuined, overgrown: objOvergrown, abandoned: objAbandoned };

    //-------------------------------------------------------------------------
    // Sheet layouts, in TILES, exactly as Tilemap reads them (rmmz_core.js
    // Tilemap.prototype._addAutotile): A2 blocks are 2x3, A3 blocks 2x2 (roof
    // rows even, wall rows odd), A4 alternates a 2x3 top row and a 2x2 face row.
    //-------------------------------------------------------------------------
    function regionsOf(kind, img, T) {
        const out = [];
        const cols = Math.floor(img.width / T);
        const rows = Math.floor(img.height / T);
        if (kind === 'A1' || kind === 'A2') {
            for (let by = 0; by + 3 <= rows; by += 3) {
                for (let bx = 0; bx + 2 <= cols; bx += 2) out.push({ x: bx * T, y: by * T, w: 2 * T, h: 3 * T, role: 'ground' });
            }
        } else if (kind === 'A3') {
            for (let by = 0; by + 2 <= rows; by += 2) {
                for (let bx = 0; bx + 2 <= cols; bx += 2) out.push({ x: bx * T, y: by * T, w: 2 * T, h: 2 * T, role: (by / 2) % 2 === 0 ? 'roof' : 'wall' });
            }
        } else if (kind === 'A4') {
            let y = 0;
            let top = true;
            while (y + (top ? 3 : 2) <= rows) {
                for (let bx = 0; bx + 2 <= cols; bx += 2) out.push({ x: bx * T, y: y * T, w: 2 * T, h: (top ? 3 : 2) * T, role: top ? 'walltop' : 'wall' });
                y += top ? 3 : 2;
                top = !top;
            }
        } else {
            for (let ty = 0; ty < rows; ty++) {
                for (let tx = 0; tx < cols; tx++) out.push({ x: tx * T, y: ty * T, w: T, h: T, role: kind === 'A5' ? 'floor' : 'object' });
            }
        }
        return out;
    }

    /** Count separate opaque pieces (4-connected, at least 4 pixels) in a rectangle. */
    function pieces(img, r) {
        const seen = new Uint8Array(r.w * r.h);
        const stack = [];
        let n = 0;
        for (let y = 0; y < r.h; y++) {
            for (let x = 0; x < r.w; x++) {
                const i = y * r.w + x;
                if (seen[i] || img.data[px(img, r.x + x, r.y + y) + 3] < 128) continue;
                let size = 0;
                stack.push(i);
                seen[i] = 1;
                while (stack.length) {
                    const j = stack.pop();
                    size++;
                    const jx = j % r.w;
                    const jy = (j - jx) / r.w;
                    const nb = [jx > 0 ? j - 1 : -1, jx < r.w - 1 ? j + 1 : -1, jy > 0 ? j - r.w : -1, jy < r.h - 1 ? j + r.w : -1];
                    for (const k of nb) {
                        if (k < 0 || seen[k]) continue;
                        const kx = k % r.w;
                        if (img.data[px(img, r.x + kx, r.y + (k - kx) / r.w) + 3] < 128) continue;
                        seen[k] = 1;
                        stack.push(k);
                    }
                }
                if (size >= 4) n++;
            }
        }
        return n;
    }

    /**
     * Classify every region of a sheet (a pure read). Returns the list the
     * deriver will act on, so a test can assert the classifier separately.
     */
    function classify(kind, img, T) {
        T = T || 48;
        return regionsOf(kind, img, T).map(r => {
            const c = census(img, r.x, r.y, r.w, r.h);
            let cls = 'empty';
            if (c.opaque > 0) {
                if (r.role === 'ground' || r.role === 'floor') cls = kind === 'A1' ? 'water' : groundClass(c);
                else if (r.role === 'walltop') cls = 'paved';
                else if (r.role === 'object') {
                    cls = objectClass(c);
                    // a scatter (a flower clump, pebbles, weeds) is three or more separate pieces: small, however
                    // wide it spreads and whatever colour its outlines are
                    if (cls !== 'empty' && cls !== 'foliage' && pieces(img, r) >= 3) cls = 'small';
                }
                else cls = r.role;
            }
            return { x: r.x, y: r.y, w: r.w, h: r.h, role: r.role, cls: cls, luma: c.luma, leaf: c.leaf, glass: c.glass };
        });
    }

    /**
     * Derive one sheet into one state. Pure: returns a new image; the input is
     * untouched. opts: { state, tile=48, seed=0, variant=0, palette (from harvest),
     * rubbleFor(region) -> {x,y,w,h} on the same sheet for A3 roofs }.
     */
    function deriveSheet(kind, img, opts) {
        const state = opts.state;
        if (STATES.indexOf(state) < 0) throw new Error('WrackCore: unknown state "' + state + '"');
        const T = opts.tile || 48;
        if (T % 2) throw new Error('WrackCore: tile size must be even (MZ composes autotiles from half tiles)');
        const out = cloneImage(img);
        const pal = opts.palette || harvest([img]);
        const seed = ((opts.seed || 0) * 7919 + STATES.indexOf(state) * 104729 + kind.charCodeAt(0) * 31 + kind.charCodeAt(1 % kind.length)) | 0;
        const regions = classify(kind, img, T);
        let ground = 0;
        let gn = 0;
        for (const r of regions) if (r.role === 'ground' || r.role === 'floor') { ground += r.luma; gn++; }
        // src: the ORIGINAL sheet, for geometry that spans cells (a two-tile tree reads its whole crown and trunk from
        // here, so both of its cells draw ONE skeleton; out is already changed for cells processed earlier)
        const ctx = { tile: T, seed: seed, m: (opts.variant | 0) + 1, pal: pal, groundLuma: gn ? ground / gn : 110, src: img };
        let acted = 0;
        for (const r of regions) {
            if (r.cls === 'empty') continue;
            acted++;
            if (r.role === 'ground' || r.role === 'floor' || r.role === 'walltop') GROUND[state](out, r, ctx, r.cls);
            else if (r.role === 'roof') {
                const src = state === 'ruined' ? (opts.rubbleFor ? opts.rubbleFor(r) : null) : null;
                ROOF[state](out, r, ctx, src, img);
            } else if (r.role === 'wall') WALL[state](out, r, ctx);
            else OBJ[state](out, r, ctx, r.cls);
        }
        out.acted = acted;
        return out;
    }

    /** For an A3 roof region, the wall block in the row below it (the same building's stone), if it has pixels. */
    function a3RubbleSource(img, T) {
        return function(r) {
            const y = r.y + 2 * T;
            if (y + 2 * T > img.height) return null;
            const c = census(img, r.x, y, 2 * T, 2 * T);
            return c.cover > 0.5 ? { x: r.x, y: y, w: 2 * T, h: 2 * T } : null;
        };
    }

    /**
     * Derive a whole tileset (the nine MZ sheets, any may be null) into one
     * state. Sheets are { A1, A2, A3, A4, A5, B, C, D, E }.
     */
    function deriveTileset(sheets, state, opts) {
        opts = opts || {};
        const T = opts.tile || 48;
        const order = ['A1', 'A2', 'A3', 'A4', 'A5', 'B', 'C', 'D', 'E'];
        const pal = opts.palette || harvest(order.map(k => sheets[k]).filter(Boolean));
        const out = {};
        for (const k of order) {
            const img = sheets[k];
            if (!img || !img.width) {
                out[k] = null;
                continue;
            }
            out[k] = deriveSheet(k, img, { state: state, tile: T, seed: opts.seed || 0, variant: opts.variant || 0, palette: pal, rubbleFor: k === 'A3' ? a3RubbleSource(img, T) : null });
        }
        return out;
    }

    /**
     * Which variant a map cell uses. One rule, read by the engine glue and by
     * every test, so a picture in a test is the picture in the game (wing §11).
     */
    function variantAt(x, y, count, seed) {
        if (count <= 1) return 0;
        return Math.min(count - 1, Math.floor(hash(x, y, (seed | 0) + 977) * count));
    }

    /**
     * The dissolve mask of the "years" and "fade" transitions: a tileable fractal value noise, size x size
     * (a power of two), RANK-EQUALISED so its values are spread evenly over 0..255 and a transition's progress
     * maps linearly onto the share of the map that has changed. Three octaves (8, 16 and 32 lattice cells across),
     * smoothstep-interpolated, every lattice coordinate wrapped, so the sheet repeats with no seam. Pure: the same
     * seed gives the same bytes in Node and in the engine. Octaves: 4, 8 and 16 lattice cells across the sheet.
     * (Independent review 2026-10-08, R23: the years transition swapped whole 48 px tiles and read as a tilemap
     * failing to load; the change now creeps through organic blobs that cross tile borders.)
     * @param {number} size - sheet width and height in texels, a power of two (256 in the engine)
     * @param {number} seed
     * @returns {Uint8Array} size*size values, 0..255, each value used size*size/256 times (+-1)
     */
    function veilNoise(size, seed) {
        const n = size * size;
        const raw = new Float32Array(n);
        // a blob about four tiles across (lattice 4 on a 16-tile sheet), with two finer octaves for a ragged edge;
        // MEASURED 2026-10-10 (_probe/veil_noise_check.js): lattice 8/16/32 at 0.55/0.3/0.15 flipped right neighbours
        // together only 19.3% of the time against 12.0% for a per-cell hash - speckle, not creeping blobs
        const octaves = [[4, 0.62], [8, 0.26], [16, 0.12]];
        const sm = t => t * t * (3 - 2 * t);
        for (const [g, wgt] of octaves) {
            const cell = size / g;
            for (let y = 0; y < size; y++) {
                const gy = y / cell;
                const y0 = Math.floor(gy);
                const fy = sm(gy - y0);
                for (let x = 0; x < size; x++) {
                    const gx = x / cell;
                    const x0 = Math.floor(gx);
                    const fx = sm(gx - x0);
                    const s = (seed | 0) + g * 131;
                    const a = hash(x0 % g, y0 % g, s), b = hash((x0 + 1) % g, y0 % g, s);
                    const c = hash(x0 % g, (y0 + 1) % g, s), d = hash((x0 + 1) % g, (y0 + 1) % g, s);
                    raw[y * size + x] += wgt * lerp(lerp(a, b, fx), lerp(c, d, fx), fy);
                }
            }
        }
        // rank-equalise: the k-th smallest value becomes floor(k * 256 / n)
        const order = new Uint32Array(n);
        for (let i = 0; i < n; i++) order[i] = i;
        order.sort((i, j) => raw[i] - raw[j] || i - j);
        const out = new Uint8Array(n);
        for (let k = 0; k < n; k++) out[order[k]] = Math.floor((k * 256) / n);
        return out;
    }

    /**
     * Sample the veil noise at sheet coordinates (u, v) in texels, wrapping, bilinear: the same
     * interpolation the GPU's LINEAR sampler does, so a cell's state read matches the picture over it.
     * @returns {number} 0..1
     */
    function veilSample(noise, size, u, v) {
        const x = u - 0.5, y = v - 0.5;
        const x0 = Math.floor(x), y0 = Math.floor(y);
        const fx = x - x0, fy = y - y0;
        const m = size - 1;
        const at = (xx, yy) => noise[(yy & m) * size + (xx & m)] / 255;
        return lerp(lerp(at(x0, y0), at(x0 + 1, y0), fx), lerp(at(x0, y0 + 1), at(x0 + 1, y0 + 1), fx), fy);
    }

    return {
        VERSION: VERSION,
        variantAt: variantAt,
        veilNoise: veilNoise,
        veilSample: veilSample,
        STATES: STATES,
        hash: hash,
        family: family,
        census: census,
        classify: classify,
        harvest: harvest,
        deriveSheet: deriveSheet,
        deriveTileset: deriveTileset,
        regionsOf: regionsOf,
        PALETTE: { CHAR: CHAR, ASH: ASH, EMBER: EMBER }
    };
});
