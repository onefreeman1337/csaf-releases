//=============================================================================
// Wrack.js — burned, ruined, overgrown and abandoned towns from your own tileset
// Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [Wrack] Your own town burned, ruined, overgrown or abandoned, re-struck from your own tileset at load time.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 * @base WrackCore
 * @orderAfter WrackCore
 *
 * @param variants
 * @text Variants per state
 * @type number
 * @min 1
 * @max 4
 * @default 3
 * @desc How many differently-marked copies of each derived tile to make. Each map cell uses one, so marks do not repeat every tile.
 *
 * @param seed
 * @text Seed
 * @type number
 * @default 0
 * @desc Change it to get a different (still deterministic) set of holes, cracks and vines.
 *
 * @param smoke
 * @text Smoke over burned roofs
 * @type boolean
 * @default true
 *
 * @param embers
 * @text Drifting embers
 * @type boolean
 * @default true
 *
 * @param smokeDensity
 * @text Smoke density
 * @type number
 * @decimals 2
 * @min 0
 * @max 1
 * @default 0.18
 * @desc Share of burned roof cells that send up a smoke column (0 to 1).
 *
 * @param bindings
 * @text Switch bindings
 * @type struct<Binding>[]
 * @default []
 * @desc While the switch is ON, the target is in the state. Commands you run later win over these.
 *
 * @command set
 * @text Set State
 * @desc Put the whole map, a region or a rectangle into a state, optionally with a transition played on screen.
 *
 * @arg target
 * @text Target
 * @type select
 * @option map
 * @option region
 * @option rect
 * @default map
 *
 * @arg regionId
 * @text Region id (target: region)
 * @type number
 * @min 1
 * @max 255
 * @default 1
 *
 * @arg x
 * @text X (target: rect)
 * @type number
 * @default 0
 *
 * @arg y
 * @text Y (target: rect)
 * @type number
 * @default 0
 *
 * @arg width
 * @text Width (target: rect)
 * @type number
 * @min 1
 * @default 1
 *
 * @arg height
 * @text Height (target: rect)
 * @type number
 * @min 1
 * @default 1
 *
 * @arg state
 * @text State
 * @type select
 * @option none
 * @option burned
 * @option ruined
 * @option overgrown
 * @option abandoned
 * @default burned
 *
 * @arg transition
 * @text Transition
 * @type select
 * @option none
 * @option fire
 * @option years
 * @option fade
 * @default none
 * @desc fire: a burning line sweeps left to right (water never burns). years: the change creeps in through ragged patches. fade: a cross-fade.
 *
 * @arg duration
 * @text Duration (frames)
 * @type number
 * @min 1
 * @default 120
 *
 * @arg wait
 * @text Wait for completion
 * @type boolean
 * @default true
 *
 * @command clear
 * @text Restore the map
 * @desc Remove every state Wrack set on this map (switch bindings still apply while their switch is ON).
 *
 * @command preload
 * @text Preload States
 * @desc Derive states now (during a fade or a quiet moment) so a later Set State is instant.
 *
 * @arg states
 * @text States
 * @type string
 * @default burned
 * @desc Comma-separated: burned, ruined, overgrown, abandoned.
 *
 * @help
 * ============================================================================
 * Wrack
 * ============================================================================
 * Every RPG with a war, a dragon or a time skip needs the same town twice. Wrack
 * makes the after from the before: when a map loads, it reads YOUR tileset's
 * pixels and derives four states from them:
 *
 *   burned     each roof's own tiles, thatch or slate blackened, ragged holes
 *              burnt through it with glowing rims and charred beams inside,
 *              ash in drifts over roofs and ground with embers glowing in it;
 *              soot on the walls, panes gone dark with the fire still inside,
 *              the ground burned black, trees to bare forked branches, smoke
 *              columns and drifting embers
 *   ruined     roofs fallen in: a dark void, grey rafters where they still stand,
 *              heaps of fallen roof inside, the house's own roof colour left in a
 *              torn frame, rubble in the wall's own stone against the wall; walls
 *              broken down to jagged courses, cracks, boards stove in, windows
 *              smashed to shards, the grass dried in straw-coloured patches
 *   overgrown  ivy climbing every wall face, moss in the roof grooves and saplings
 *              rooted in it, grass creeping over paths and paving, lily pads
 *   abandoned  colour faded under dust, slipped roof tiles, windows boarded,
 *              damp down the walls, weeds at every door, grit on the paths,
 *              lawns browned in patches, lamps cold
 *
 * Your map file is never touched: events, cutscenes and passability are exactly
 * as you made them. No image files ship; nothing is drawn by hand.
 *
 * ----------------------------------------------------------------------------
 * Install
 * ----------------------------------------------------------------------------
 *   WrackCore.js   first
 *   Wrack.js       below it
 *
 * ----------------------------------------------------------------------------
 * Map notetags (Map Properties > Note)
 * ----------------------------------------------------------------------------
 *   <Wrack: burned>               the whole map starts in that state
 *   <Wrack region 5: ruined>      cells with region 5 start in that state
 *   <Wrack preload: overgrown>    derive this state at load too, for a later
 *                                 instant switch (comma-separate several)
 *
 * ----------------------------------------------------------------------------
 * Plugin commands
 * ----------------------------------------------------------------------------
 *   Set State      target map / region / rect, a state (or none), a transition
 *                  (none, fire, years, fade), its duration and Wait.
 *   Restore the map
 *   Preload States
 *
 * What you set is saved with the game, per map.
 *
 * Priority, lowest first: map notetags, switch bindings that are ON, then what
 * Set State commands wrote. Within each, a rectangle wins over a region, and a
 * region over the whole map.
 *
 * ----------------------------------------------------------------------------
 * Script calls
 * ----------------------------------------------------------------------------
 *   Wrack.set('map', 'burned')
 *   Wrack.set('region', 'ruined', { regionId: 5, transition: 'years' })
 *   Wrack.set('rect', 'burned', { x: 4, y: 3, width: 5, height: 4 })
 *   Wrack.clear()
 *   Wrack.stateAt(x, y)            -> 'burned' | 'ruined' | ... | null
 *   Wrack.isBusy()                 -> true while deriving or mid-transition
 *
 * ----------------------------------------------------------------------------
 * Good to know
 * ----------------------------------------------------------------------------
 * - Deriving takes a moment each time a map that uses a state loads (nothing is
 *   kept between maps). A map that starts in a state waits for it behind the
 *   fade-in. A state first used mid-scene costs a
 *   short stall unless you preload it (notetag or command).
 * - The derived tiles are packed into the three spare texture slots MZ's tile
 *   renderer already has. If one map uses more distinct tiles in states than
 *   fit, Wrack drops to fewer variants, and then leaves the overflow intact and
 *   says so in the console. It never draws a wrong tile.
 * - Water and waterfalls keep animating in every state.
 * - Winter and snow are not a state.
 * - Wrack reads tile art through the image the engine loaded; a tileset served
 *   from another origin without CORS cannot be read and stays intact (console).
 */
/*~struct~Binding:
 * @param switchId
 * @text Switch
 * @type switch
 * @default 0
 *
 * @param mapId
 * @text Map
 * @type number
 * @min 0
 * @default 0
 * @desc 0 = every map.
 *
 * @param target
 * @text Target
 * @type select
 * @option map
 * @option region
 * @default map
 *
 * @param regionId
 * @text Region id (target: region)
 * @type number
 * @min 1
 * @max 255
 * @default 1
 *
 * @param state
 * @text State
 * @type select
 * @option burned
 * @option ruined
 * @option overgrown
 * @option abandoned
 * @default burned
 */

var Wrack = Wrack || {};

(() => {
    'use strict';

    const PLUGIN = 'Wrack';
    const SCHEMA = 1;
    const STATES = ['burned', 'ruined', 'overgrown', 'abandoned'];
    const STATE_INDEX = { burned: 1, ruined: 2, overgrown: 3, abandoned: 4 };
    const STRIDE = 64; // quarter cells per sheet row in the remap table (supports sheets up to 64 quarters wide)
    const ATLAS = 1024; // MZ's tile renderer places each sheet in a 1024 x 1024 slot (rmmz_core.js Tilemap.Renderer.updateTextures)
    const SLOTS = 3; // slots 9, 10, 11 are unused by the engine's nine sheets

    //-------------------------------------------------------------------------
    // Parameters. Strings arrive from the Plugin Manager; blank is "absent",
    // never zero (wing §16).
    //-------------------------------------------------------------------------
    const raw = PluginManager.parameters(PLUGIN);
    const num = (v, d) => (v === undefined || v === '' ? d : Number(v));
    const P = {
        variants: Math.max(1, Math.min(4, Math.floor(num(raw.variants, 3)) || 1)),
        seed: Math.floor(num(raw.seed, 0)) || 0,
        smoke: raw.smoke !== 'false',
        embers: raw.embers !== 'false',
        smokeDensity: Math.max(0, Math.min(1, num(raw.smokeDensity, 0.18))),
        bindings: parseBindings(raw.bindings)
    };
    function parseBindings(text) {
        const out = [];
        let list = [];
        try {
            list = JSON.parse(text || '[]');
        } catch (e) {
            console.warn('[Wrack] bindings parameter is not readable JSON; ignored');
        }
        for (const item of list) {
            let b = item;
            try {
                if (typeof b === 'string') b = JSON.parse(b);
            } catch (e) {
                continue;
            }
            const switchId = Number(b.switchId);
            const state = String(b.state || '');
            if (!(switchId > 0) || !STATE_INDEX[state]) continue;
            out.push({ switchId: switchId, mapId: Number(b.mapId) || 0, target: b.target === 'region' ? 'region' : 'map', regionId: Number(b.regionId) || 0, state: state });
        }
        return out;
    }

    let CORE = null;
    function core() {
        // resolved at first use: load order is the buyer's choice (wing §8 trap 2)
        if (!CORE) {
            CORE = window.WrackCore;
            if (!CORE) throw new Error('Wrack needs WrackCore.js installed and ON above it in the Plugin Manager.');
        }
        return CORE;
    }

    //-------------------------------------------------------------------------
    // Saved record: $gameSystem._wrack = { v, maps: { id: { all, regions, rects } } }
    //-------------------------------------------------------------------------
    function store() {
        const sys = $gameSystem;
        if (!sys._wrack || sys._wrack.v !== SCHEMA) sys._wrack = { v: SCHEMA, maps: {} };
        return sys._wrack;
    }
    function mapRecord(mapId, create) {
        const s = store();
        let r = s.maps[mapId];
        if (!r && create) r = s.maps[mapId] = { all: null, regions: {}, rects: [] };
        return r || null;
    }

    //-------------------------------------------------------------------------
    // Notetags
    //-------------------------------------------------------------------------
    function readNotes() {
        const note = ($dataMap && $dataMap.note) || '';
        const out = { all: null, regions: {}, preload: [] };
        const all = /<Wrack:\s*(\w+)\s*>/i.exec(note);
        if (all && STATE_INDEX[all[1].toLowerCase()]) out.all = all[1].toLowerCase();
        const re = /<Wrack\s+region\s+(\d+)\s*:\s*(\w+)\s*>/gi;
        let m;
        while ((m = re.exec(note))) if (STATE_INDEX[m[2].toLowerCase()]) out.regions[Number(m[1])] = m[2].toLowerCase();
        const pre = /<Wrack\s+preload\s*:\s*([^>]+)>/i.exec(note);
        if (pre) for (const s of pre[1].split(',')) if (STATE_INDEX[s.trim().toLowerCase()]) out.preload.push(s.trim().toLowerCase());
        return out;
    }

    //-------------------------------------------------------------------------
    // The layout: one byte per cell, 0 = intact, 1..4 = STATES. Recomputed
    // only when something that decides it changes.
    //-------------------------------------------------------------------------
    function computeLayout(w, h) {
        const cells = new Uint8Array(w * h);
        const notes = readNotes();
        const regionOf = (x, y) => $gameMap.regionId(x, y);
        const applyAll = st => { if (st) cells.fill(STATE_INDEX[st] || 0); else if (st === 'none') cells.fill(0); };
        const applyRegion = (rid, st) => {
            const v = st === 'none' ? 0 : STATE_INDEX[st];
            if (v === undefined) return;
            for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (regionOf(x, y) === rid) cells[y * w + x] = v;
        };
        const applyRect = (rx, ry, rw, rh, st) => {
            const v = st === 'none' ? 0 : STATE_INDEX[st];
            if (v === undefined) return;
            for (let y = Math.max(0, ry); y < Math.min(h, ry + rh); y++) for (let x = Math.max(0, rx); x < Math.min(w, rx + rw); x++) cells[y * w + x] = v;
        };
        // notetags
        if (notes.all) applyAll(notes.all);
        for (const rid in notes.regions) applyRegion(Number(rid), notes.regions[rid]);
        // switch bindings that are ON
        const mapId = $gameMap.mapId();
        for (const b of P.bindings) {
            if (b.mapId && b.mapId !== mapId) continue;
            if (!$gameSwitches.value(b.switchId)) continue;
            if (b.target === 'region') applyRegion(b.regionId, b.state);
            else applyAll(b.state);
        }
        // what commands wrote
        const rec = mapRecord(mapId, false);
        if (rec) {
            if (rec.all === 'none') cells.fill(0);
            else if (rec.all) applyAll(rec.all);
            for (const rid in rec.regions) applyRegion(Number(rid), rec.regions[rid]);
            for (const r of rec.rects) applyRect(r[0], r[1], r[2], r[3], r[4]);
        }
        return { cells: cells, preload: notes.preload };
    }

    //-------------------------------------------------------------------------
    // Engine seams. _addSpot draws one map cell (rmmz_core.js 2436); every
    // rect it draws goes through CombinedLayer.addRect (2926). While a cell in
    // a state is drawn, addRect moves its source rect into the atlas slot.
    //-------------------------------------------------------------------------
    // The object split (2026-10-10, step 2 of the second review): MZ paints ground (layers 0-1) AND lower objects
    // (layers 2-3, non-star) into one _lowerLayer. On a map Wrack runs on, the 3rd and 4th lower tiles of each spot go
    // to a layer of their own just above it (z 0.6), so marks can lie BETWEEN the ground and the objects. MEASURED
    // (Internal_Ops/_probe/split_probe.js): 0 of 884,736 pixels differ with the split on and off, intact and burned.
    const _Tilemap_addAllSpots = Tilemap.prototype._addAllSpots;
    Tilemap.prototype._addAllSpots = function(startX, startY) {
        if (this._wrackObjLayer) this._wrackObjLayer.clear();
        return _Tilemap_addAllSpots.call(this, startX, startY);
    };
    // Routed by TILE SET, not by layer index: a lower B-E tile (ids below TILE_ID_A5) is an object wherever it sits, and
    // an A tile on layer 3 is ground. (The lower layer draws grouped by texture set, so this keeps MZ's own order.
    // In-engine on our fixtures and on MZ's stock Outside, Inside and Dungeon: byte-identical with the split on and off.)
    const _Tilemap_addSpotTile = Tilemap.prototype._addSpotTile;
    Tilemap.prototype._addSpotTile = function(tileId, dx, dy) {
        if (this._wrackObjLayer && tileId < Tilemap.TILE_ID_A5 && Tilemap.isVisibleTile(tileId) && !this._isHigherTile(tileId)) {
            this._addTile(this._wrackObjLayer, tileId, dx, dy);
            return;
        }
        _Tilemap_addSpotTile.call(this, tileId, dx, dy);
    };
    const _Tilemap_updateTransform = Tilemap.prototype.updateTransform;
    Tilemap.prototype.updateTransform = function() {
        _Tilemap_updateTransform.call(this);
        const ol = this._wrackObjLayer;
        if (ol) {
            ol.x = this._lowerLayer.x;
            ol.y = this._lowerLayer.y;
            ol.updateTransform();
        }
    };

    let REMAP = null;
    const _Tilemap_addSpot = Tilemap.prototype._addSpot;
    Tilemap.prototype._addSpot = function(startX, startY, x, y) {
        const L = this._wrackLayer;
        if (L && L.live) {
            const t = L.tableAt(startX + x, startY + y);
            if (t) {
                REMAP = t;
                try {
                    _Tilemap_addSpot.call(this, startX, startY, x, y);
                } finally {
                    REMAP = null;
                }
                return;
            }
        }
        _Tilemap_addSpot.call(this, startX, startY, x, y);
    };
    const _CombinedLayer_addRect = Tilemap.CombinedLayer.prototype.addRect;
    Tilemap.CombinedLayer.prototype.addRect = function(setNumber, sx, sy, dx, dy, w, h) {
        if (REMAP !== null && setNumber >= 0 && setNumber < 9) {
            const q = REMAP.q;
            const qx = Math.floor(sx / q);
            const qy = Math.floor(sy / q);
            const v = REMAP.cells[setNumber * STRIDE * STRIDE + qy * STRIDE + qx];
            if (v >= 0) {
                const slot = v >>> 20;
                const ax = (v >>> 10) & 1023;
                const ay = v & 1023;
                _CombinedLayer_addRect.call(this, 9 + slot, ax * q + (sx - qx * q), ay * q + (sy - qy * q), dx, dy, w, h);
                return;
            }
        }
        _CombinedLayer_addRect.call(this, setNumber, sx, sy, dx, dy, w, h);
    };

    //-------------------------------------------------------------------------
    // Which source quarters a tile id can ever draw from. Mirrors the base
    // arithmetic of Tilemap.prototype._addAutotile / _addNormalTile
    // (rmmz_core.js 2483-2577), over every animation frame.
    //-------------------------------------------------------------------------
    function sourceCellsOf(tileId, T, add) {
        if (!Tilemap.isVisibleTile(tileId)) return;
        const q = T / 2;
        if (Tilemap.isAutotile(tileId)) {
            const kind = Tilemap.getAutotileKind(tileId);
            const tx = kind % 8;
            const ty = Math.floor(kind / 8);
            const blocks = [];
            if (Tilemap.isTileA1(tileId)) {
                const surfaces = [0, 1, 2];
                if (kind === 0) for (const s of surfaces) blocks.push([0, s * 2, 0, 3]);
                else if (kind === 1) for (const s of surfaces) blocks.push([0, s * 2, 3, 3]);
                else if (kind === 2) blocks.push([0, 6, 0, 3]);
                else if (kind === 3) blocks.push([0, 6, 3, 3]);
                else {
                    const bx = Math.floor(tx / 4) * 8;
                    const by = ty * 6 + (Math.floor(tx / 2) % 2) * 3;
                    if (kind % 2 === 0) for (const s of surfaces) blocks.push([0, bx + s * 2, by, 3]);
                    else for (let f = 0; f < 3; f++) blocks.push([0, bx + 6, by + f, 1]);
                }
            } else if (Tilemap.isTileA2(tileId)) blocks.push([1, tx * 2, (ty - 2) * 3, 3]);
            else if (Tilemap.isTileA3(tileId)) blocks.push([2, tx * 2, (ty - 6) * 2, 2]);
            else if (Tilemap.isTileA4(tileId)) blocks.push([3, tx * 2, Math.floor((ty - 10) * 2.5 + (ty % 2 === 1 ? 0.5 : 0)), ty % 2 === 1 ? 2 : 3]);
            for (const [set, bx, by, rows] of blocks) {
                for (let qy = by * 2; qy < (by + rows) * 2; qy++) for (let qx = bx * 2; qx < bx * 2 + 4; qx++) add(set, qx, qy, 1);
            }
            return;
        }
        const set = Tilemap.isTileA5(tileId) ? 4 : 5 + Math.floor(tileId / 256);
        const qx = ((Math.floor(tileId / 128) % 2) * 8 + (tileId % 8)) * 2;
        const qy = (Math.floor((tileId % 256) / 8) % 16) * 2;
        add(set, qx, qy, 2);
        void q;
    }

    //-------------------------------------------------------------------------
    // The veil: how "years" and "fade" change a map (independent review 2026-10-08, R23). The tiles under the
    // change switch to the new state at once, and a picture of the OLD tiles, taken once when the change begins,
    // lies over them and dissolves through an organic map-space noise (WrackCore.veilNoise), so the change creeps
    // in blobs that cross tile borders instead of swapping whole 48 px squares. Per frame: one uniform. The
    // filter follows MZ's ColorFilter pattern; inputSize / outputFrame are shared with PIXI's default vertex
    // shader and MUST be highp (Probe_Doctrine §28a).
    //-------------------------------------------------------------------------
    const VEIL_SIZE = 256;        // noise sheet, texels (power of two: the sampler repeats it)
    const VEIL_TILES = 16;        // map tiles per noise sheet: 16 texels a tile, blobs about two tiles across
    const VEIL_SOFT = 0.035;      // the dissolve edge, in noise units
    const VEIL_KINDS = { years: true, fade: true, fire: true };
    // the fire front (third pass, 2026-10-10; second review R3/R4: "a vertical wipe locked to the tile grid ... one
    // sticker sprite stamped once per 48 px row"): the burn line is the veil's own noise added to a left-to-right
    // sweep, so it wanders across tile borders; in tiles, so it scales with the map's grid
    const FIRE_WOB = 2.6;      // how far the burn line wanders either way of the sweep, peak to peak, in tiles
    const FIRE_RIM = 0.19;     // the glowing edge behind the line, in tiles (9 px at 48)
    const FIRE_SCORCH = 0.7;   // the browned stretch ahead of the line, in tiles
    // an ADDITION (our own class), never an engine seam: declared as a class so no engine prototype is assigned
    class VeilFilter extends PIXI.Filter {
        constructor() {
            super(null, VEIL_FRAGMENT);
            const u = this.uniforms;
            u.uNoise = PIXI.Texture.EMPTY;
            u.uChanged = PIXI.Texture.EMPTY;
            u.uScreenOrigin = new Float32Array([0, 0]);
            u.uOrigin = new Float32Array([0, 0]);
            u.uMapSize = new Float32Array([1, 1]);
            u.uTile = 48;
            u.uZoom = 1;
            u.uPeriod = 768;
            u.uCut = -1;
            u.uSoft = VEIL_SOFT;
            u.uMode = 0;   // 0 = years: the noise veil; 1 = fade: the whole change cross-fades; 2 = fire: a burning line
            u.uFront = -1e6;  // fire: where the sweep stands, in map pixels
            u.uWob = 120;     // fire: FIRE_WOB in pixels
            u.uRim = 9;       // fire: FIRE_RIM in pixels
            u.uScorch = 34;   // fire: FIRE_SCORCH in pixels
            u.uRimOn = 1;     // fire: the glowing edge is drawn by the LOWER veil only (the upper one would put it over characters)
            u.uTime = 0;      // fire: frames, for the edge's flicker
        }
    }
    const VEIL_FRAGMENT =
        'varying vec2 vTextureCoord;' +
        'uniform sampler2D uSampler;' +
        'uniform sampler2D uNoise;' +
        'uniform sampler2D uChanged;' +
        'uniform highp vec4 inputSize;' +
        'uniform highp vec4 outputFrame;' +
        'uniform highp vec2 uScreenOrigin;' +
        'uniform highp vec2 uOrigin;' +
        'uniform highp vec2 uMapSize;' +
        'uniform highp float uTile;' +
        'uniform highp float uZoom;' +
        'uniform highp float uPeriod;' +
        'uniform float uCut;' +
        'uniform float uSoft;' +
        'uniform float uMode;' +
        'uniform highp float uFront;' +
        'uniform highp float uWob;' +
        'uniform highp float uRim;' +
        'uniform highp float uScorch;' +
        'uniform float uRimOn;' +
        'uniform highp float uTime;' +
        // a 4 x 4 ordered dither (Bayer), from the block index
        'float bayer2(vec2 a) { a = floor(a); return fract(a.x * 0.5 + a.y * a.y * 0.75); }' +
        'float bayer4(vec2 a) { return bayer2(0.5 * a) * 0.25 + bayer2(a); }' +
        'void main(void) {' +
        '  vec4 c = texture2D(uSampler, vTextureCoord);' +
        // the map pixel under this screen pixel, from the live transform
        '  highp vec2 px = (vTextureCoord * inputSize.xy + outputFrame.xy - uScreenOrigin) / max(uZoom, 0.0001) + uOrigin;' +
        // the edge is drawn in 3 px blocks with a dithered band, like the pixel art it cuts through (a smooth
        // vector edge read as airbrush over crisp tiles, the same complaint as R18; 2026-10-10 look)
        '  highp vec2 blk = floor(px / 3.0);' +
        '  float n = texture2D(uNoise, (blk * 3.0 + 1.5) / uPeriod).r;' +
        // only cells that change are veiled: an unchanged cell shows the live map (its water keeps moving)
        // ⛔ the wrap is floor((c + 0.5) / size), never mod(mod(c, size) + size, size): MEASURED 2026-10-10, this GPU's
        // mod(24.0, 24.0) returns 24.0, so column 0 read the CLAMPED last column (a pond) and kept the old picture
        '  highp vec2 cell = floor(px / uTile);' +
        '  cell = cell - uMapSize * floor((cell + 0.5) / uMapSize);' +
        '  vec4 cc = texture2D(uChanged, (cell + 0.5) / uMapSize);' +
        '  float changed = cc.a;' +
        // FIRE: the old town stands ahead of a burning line that wanders with the noise; just ahead of it the old
        // picture browns in the heat, on it a hot edge glows and cools to embers, behind it the burned state shows
        '  if (uMode > 1.5) {' +
        '    float dth = bayer4(blk);' +
        '    if (cc.b > 0.5) {' +
        // water does not burn (R24): a pond keeps its old picture until the line has passed all of it, then
        // dissolves over two tiles of the sweep, with no glowing edge
        '      float pe = cc.g * uMapSize.x * uTile;' +
        '      float k = 1.0 - clamp((uFront - pe) / (uTile * 2.0), 0.0, 1.0);' +
        '      gl_FragColor = c * step(dth + 0.03, k) * changed; return;' +
        '    }' +
        '    float fl = texture2D(uNoise, (blk * 3.0 + 1.5) / (uPeriod * 0.5) + vec2(uTime * 0.0021, uTime * -0.0047)).r;' +
        '    float d = uFront - (blk.x * 3.0 + 1.5 + (n - 0.5) * uWob) + (fl - 0.5) * uRim * 0.9;' +
        // d runs along x; across the line it is d / |grad|, so a stretch where the line runs sideways keeps the same
        // rim width instead of swelling into a blob (2026-10-10 look: a 90 x 60 px orange lump where the line turned)
        '    float nx = texture2D(uNoise, ((blk + vec2(1.0, 0.0)) * 3.0 + 1.5) / uPeriod).r;' +
        '    float ny = texture2D(uNoise, ((blk + vec2(0.0, 1.0)) * 3.0 + 1.5) / uPeriod).r;' +
        '    d = d / max(length(vec2(1.0 + (nx - n) * uWob / 3.0, (ny - n) * uWob / 3.0)), 0.35);' +
        '    if (d < 0.0) {' +
        '      float s = clamp(1.0 + d / uScorch, 0.0, 1.0);' +
        '      float br = step(dth, s * s * 0.95) * (0.28 + 0.34 * s);' +
        '      gl_FragColor = vec4(mix(c.rgb, vec3(0.20, 0.10, 0.05) * c.a, br), c.a) * changed; return;' +
        '    }' +
        '    if (d < uRim && uRimOn > 0.5) {' +
        '      float r = d / uRim;' +
        '      vec3 hot = r < 0.34 ? vec3(1.0, 0.88, 0.47) : (r < 0.67 ? vec3(1.0, 0.50, 0.13) : vec3(0.60, 0.13, 0.05));' +
        '      float a = r < 0.67 ? 1.0 : step(dth, (1.0 - r) * 3.0) * 0.9;' +
        '      gl_FragColor = vec4(hot * a, a) * changed; return;' +
        '    }' +
        '    gl_FragColor = vec4(0.0); return;' +
        '  }' +
        '  float ramp = smoothstep(uCut - uSoft, uCut + uSoft, n);' +
        '  float veil = step(bayer4(blk) + 0.03, ramp);' +
        // fade: the old picture's opacity falls evenly from 1 to 0 over the changed cells
        '  float cross = 1.0 - clamp(uCut, 0.0, 1.0);' +
        '  float keep = mix(veil, cross, step(0.5, uMode)) * changed;' +
        '  gl_FragColor = c * keep;' +
        '}';
    //-------------------------------------------------------------------------
    // The decor: field marks drawn in MAP space (step 2 of the second review: every patch baked into a derived tile
    // repeated at tile pitch - R5, R19, R29, R31). One sprite between the ground (z 0) and the split object layer
    // (z 0.6), one filter: a per-cell state map (1 texel a cell, NEAREST) gates the shared veil noise into ash drifts
    // (burned), straw patches (ruined), grass creeping over paths and plazas (overgrown) and dust (abandoned), in 2 px
    // blocks with a dithered edge. Patches cross tile borders; nothing repeats at the tile pitch. Per frame: uniforms.
    //-------------------------------------------------------------------------
    class DecorFilter extends PIXI.Filter {
        constructor() {
            super(null, DECOR_FRAGMENT);
            const u = this.uniforms;
            u.uNoise = PIXI.Texture.EMPTY;
            u.uCells = PIXI.Texture.EMPTY;
            u.uScreenOrigin = new Float32Array([0, 0]);
            u.uOrigin = new Float32Array([0, 0]);
            u.uMapSize = new Float32Array([1, 1]);
            u.uTile = 48;
            u.uZoom = 1;
            u.uAsh = new Float32Array([118 / 255, 112 / 255, 106 / 255]);
            u.uStraw = new Float32Array([178 / 255, 158 / 255, 98 / 255]);
            u.uLeaf = new Float32Array([96 / 255, 150 / 255, 64 / 255]);
            u.uLeafDark = new Float32Array([58 / 255, 104 / 255, 46 / 255]);
            u.uDust = new Float32Array([176 / 255, 164 / 255, 140 / 255]);
        }
    }
    const DECOR_FRAGMENT =
        'varying vec2 vTextureCoord;' +
        'uniform sampler2D uSampler;' +
        'uniform sampler2D uNoise;' +
        'uniform sampler2D uCells;' +
        'uniform highp vec4 inputSize;' +
        'uniform highp vec4 outputFrame;' +
        'uniform highp vec2 uScreenOrigin;' +
        'uniform highp vec2 uOrigin;' +
        'uniform highp vec2 uMapSize;' +
        'uniform highp float uTile;' +
        'uniform highp float uZoom;' +
        'uniform vec3 uAsh;' +
        'uniform vec3 uStraw;' +
        'uniform vec3 uLeaf;' +
        'uniform vec3 uLeafDark;' +
        'uniform vec3 uDust;' +
        'float bayer2(vec2 a) { a = floor(a); return fract(a.x * 0.5 + a.y * a.y * 0.75); }' +
        'float bayer4(vec2 a) { return bayer2(0.5 * a) * 0.25 + bayer2(a); }' +
        'void main(void) {' +
        '  highp vec2 px = (vTextureCoord * inputSize.xy + outputFrame.xy - uScreenOrigin) / max(uZoom, 0.0001) + uOrigin;' +
        '  highp vec2 cell = floor(px / uTile);' +
        '  cell = cell - uMapSize * floor((cell + 0.5) / uMapSize);' +   // never a double mod (see VEIL_FRAGMENT)
        '  vec4 cs = texture2D(uCells, (cell + 0.5) / uMapSize);' +
        '  float st = floor(cs.r * 4.0 + 0.5);' +
        '  if (cs.g < 0.1 || st < 0.5) { gl_FragColor = vec4(0.0); return; }' +   // G 0 = nothing; 50/100/150/200 = its kind
        '  highp vec2 blk = floor(px / 2.0);' +
        '  highp vec2 q = blk * 2.0 + 1.0;' +
        '  float n1 = texture2D(uNoise, q / (uTile * 7.0)).r;' +
        '  float n2 = texture2D(uNoise, q / (uTile * 2.3) + vec2(0.37, 0.61)).r;' +
        '  float dth = bayer4(blk);' +
        // per-block hashes: a mark is GRAINS, never a film (third pass 2026-10-10: translucent flat patches read as
        // fog over the town and as yellow cellophane over cobbles)
        '  highp float hs = fract(sin(dot(blk, vec2(12.9898, 78.233))) * 43758.5453);' +
        '  highp float h2 = fract(sin(dot(blk, vec2(39.3468, 11.135))) * 24634.6345);' +
        // the ground under the cell, read from its own tile's colour (MapLayer.classifyGround): 1 grass, 2 earth, 3 paving;
        // 4 = a roof (only a BURNED roof takes a mark: ash and embers on the burnt shell, in map space, R14)
        '  float cls = floor(cs.g * 255.0 / 50.0 + 0.5);' +
        '  if (cls > 3.5 && st > 2.5) { gl_FragColor = vec4(0.0); return; }' +
        '  vec3 col = vec3(0.0); float a = 0.0;' +
        // ROOFS (third independent review 2026-10-10, R3-5/R3-12 MAJOR: burned and ruined roofs were one grille of evenly
        // spaced rafters). BURNED: the derived roof is the house's own roof charred; here, holes burnt through it in
        // ragged map-space blobs, a rim still glowing, the dark room inside with the beams that still stand (some gone),
        // and ash with embers on what is left. RUINED: the derived roof is the open void and rafters; here, heaps of the
        // fallen roof and gaps where rafters went down with it, so no two stretches of a roof are alike.
        '  if (cls > 3.5) {' +
        '    float h = texture2D(uNoise, q / (uTile * 3.1) + vec2(0.11, 0.73)).r;' +
        '    highp float bc = floor(px.x / (uTile * 0.5));' +
        '    highp float bx = px.x - bc * uTile * 0.5;' +
        '    highp float keep = fract(sin(bc * 91.17 + 3.1) * 43758.5453);' +
        '    if (st < 1.5) {' +
        '      if (h > 0.66) { bool beam = keep > 0.3 && bx >= uTile * 0.2 && bx < uTile * 0.2 + 3.0;' +
        '        col = beam ? (bx < uTile * 0.2 + 1.0 ? vec3(0.36, 0.28, 0.22) : vec3(0.15, 0.11, 0.09)) : vec3(0.05, 0.04, 0.04) * (0.8 + 0.4 * hs); a = 1.0; }' +
        '      else if (h > 0.635) { col = hs < 0.4 ? vec3(1.0, 0.47, 0.13) : (hs < 0.7 ? vec3(0.55, 0.16, 0.06) : vec3(0.08, 0.06, 0.05)); a = 1.0; }' +
        '      else { float m = n1 * 0.7 + n2 * 0.3; float cover = smoothstep(0.66, 0.84, m);' +
        '        if (hs < cover * 0.9) { col = h2 < 0.18 ? uAsh * 0.42 : (h2 < 0.6 ? uAsh : uAsh * 1.16); a = 0.8; if (h2 > 0.993) { col = vec3(1.0, 0.55, 0.16); a = 1.0; } } }' +
        '    } else {' +
        '      float g = texture2D(uNoise, q / (uTile * 2.7) + vec2(0.52, 0.19)).r;' +
        // rubble as STONES, not grit: 4 px blocks, each its own tone, lit on its top-left edge and shaded on its
        // bottom-right (third pass look: 2 px speckle in three greys read as ash)
        '      if (g > 0.74 || (g > 0.70 && dth < 0.5)) { float lit = clamp((g - 0.70) * 7.0, 0.0, 1.0);' +
        '        highp vec2 sb = floor(px / 4.0); highp vec2 sl = px - sb * 4.0;' +
        '        highp float hk = fract(sin(dot(sb, vec2(27.619, 57.583))) * 43758.5453);' +
        '        vec3 stone = hk < 0.33 ? vec3(0.62, 0.58, 0.52) : (hk < 0.75 ? vec3(0.47, 0.44, 0.40) : vec3(0.36, 0.33, 0.30));' +
        '        float bev = (sl.x < 1.0 || sl.y < 1.0) ? 1.18 : ((sl.x >= 3.0 || sl.y >= 3.0) ? 0.55 : 1.0);' +
        '        col = stone * bev * (0.78 + 0.3 * lit); a = 1.0; }' +
        '      else if (g < 0.2 || (g < 0.24 && dth < 0.5)) { col = vec3(0.13, 0.12, 0.11) * (0.85 + 0.3 * hs); a = 1.0; }' +
        '    }' +
        '    gl_FragColor = vec4(col * a, a); return;' +
        '  }' +
        // burned: ash in drifts, dense at a drift's heart and thinning to its edge, with char flecks
        '  if (st < 1.5) { float m = n1 * 0.7 + n2 * 0.3; float cover = smoothstep(0.70, 0.84, m);' +
        '    if (hs < cover * 0.9) { col = h2 < 0.18 ? uAsh * 0.42 : (h2 < 0.6 ? uAsh : uAsh * 1.16); a = 0.8; } }' +
        // ruined: drought. On grass, straw blades (2 px wide, 4 px tall); on earth and paving, a little grit only
        '  else if (st < 2.5) { float m = n1 * 0.8 + n2 * 0.2;' +
        '    if (cls < 1.5) { float cover = smoothstep(0.64, 0.78, m); highp float hb = fract(sin(dot(vec2(blk.x, floor(blk.y / 2.0)), vec2(12.9898, 78.233))) * 43758.5453);' +
        '      if (hb < cover * 0.95) { col = h2 < 0.5 ? uStraw : (h2 < 0.8 ? uStraw * 0.8 : uStraw * 1.12); a = 0.9; } }' +
        '    else { float cover = smoothstep(0.72, 0.86, m); if (hs < cover * 0.3) { col = h2 < 0.5 ? vec3(0.40, 0.36, 0.31) : vec3(0.56, 0.51, 0.45); a = 0.85; } } }' +
        // overgrown: grass creeping over everything, two greens
        '  else if (st < 3.5) { float m = n1 * 0.6 + n2 * 0.4; if (m > 0.66) { col = n2 > 0.55 ? uLeaf : uLeafDark; a = 0.82; } else if (m > 0.62 && dth < 0.5) { col = uLeafDark; a = 0.65; } }' +
        // abandoned: on grass the lawn browning in grainy patches; on earth and paving, settled grit and dust
        '  else { float m = n1;' +
        '    if (cls < 1.5) { float cover = smoothstep(0.68, 0.82, m); if (hs < cover * 0.6) { col = h2 < 0.5 ? vec3(0.60, 0.58, 0.33) : vec3(0.50, 0.50, 0.29); a = 0.72; } }' +
        '    else { float cover = smoothstep(0.66, 0.80, m); if (hs < cover * 0.7) { col = h2 < 0.55 ? uDust : uDust * 0.86; a = 0.6; } } }' +
        '  if (st > 2.5 && st < 3.5) col = hs > 0.62 ? uLeaf : (hs < 0.18 ? uLeafDark * 0.8 : uLeafDark);' +
        '  gl_FragColor = vec4(col * a, a);' +
        '}';

    let VEIL_NOISE = null;   // { values: Uint8Array, bitmap: Bitmap, texture }
    function veilNoise() {
        if (VEIL_NOISE) return VEIL_NOISE;
        const values = core().veilNoise(VEIL_SIZE, P.seed);
        const bmp = new Bitmap(VEIL_SIZE, VEIL_SIZE);
        const img = bmp.context.createImageData(VEIL_SIZE, VEIL_SIZE);
        for (let i = 0; i < values.length; i++) {
            const o = i * 4;
            img.data[o] = img.data[o + 1] = img.data[o + 2] = values[i];
            img.data[o + 3] = 255;
        }
        bmp.context.putImageData(img, 0, 0);
        bmp.baseTexture.update();
        bmp.baseTexture.wrapMode = PIXI.WRAP_MODES.REPEAT;
        bmp.smooth = true;
        VEIL_NOISE = { values: values, bitmap: bmp, texture: new PIXI.Texture(bmp.baseTexture) };
        return VEIL_NOISE;
    }
    /**
     * The noise value under a map PIXEL, 0..1, exactly as the veil shader reads it there (its 3 px block centre,
     * LINEAR, repeating). Per frame for the fire's flames, so it allocates nothing.
     */
    function noiseAtPx(px, py, T) {
        const vals = veilNoise().values;
        const k = VEIL_SIZE / (T * VEIL_TILES);
        const m = VEIL_SIZE - 1;
        const u = (Math.floor(px / 3) * 3 + 1.5) * k - 0.5;
        const v = (Math.floor(py / 3) * 3 + 1.5) * k - 0.5;
        const x0 = Math.floor(u);
        const y0 = Math.floor(v);
        const fx = u - x0;
        const fy = v - y0;
        const r0 = (y0 & m) * VEIL_SIZE;
        const r1 = ((y0 + 1) & m) * VEIL_SIZE;
        const a = vals[r0 + (x0 & m)];
        const b = vals[r0 + ((x0 + 1) & m)];
        const c = vals[r1 + (x0 & m)];
        const d = vals[r1 + ((x0 + 1) & m)];
        const top = a + (b - a) * fx;
        return (top + (c + (d - c) * fx - top) * fy) / 255;
    }
    /** the noise value at a map cell's centre, 0..1, as the shader's LINEAR sampler reads it there */
    function veilAt(x, y) {
        const k = VEIL_SIZE / VEIL_TILES;
        return core().veilSample(veilNoise().values, VEIL_SIZE, (x + 0.5) * k, (y + 0.5) * k);
    }
    /** where the dissolve edge stands at progress p (0..1), in noise units: wholly old at 0, wholly new at 1 */
    function veilCut(p) {
        return -VEIL_SOFT + p * (1 + 2 * VEIL_SOFT);
    }
    function canVeil() {
        return !!(Graphics._app && Graphics._app.renderer && PIXI.RenderTexture && PIXI.Filter);
    }

    //-------------------------------------------------------------------------
    // The map layer: owns derivation, the atlas, the layout and transitions.
    //-------------------------------------------------------------------------
    class MapLayer {
        constructor(spriteset) {
            this.spriteset = spriteset;
            this.tilemap = spriteset._tilemap;
            this.tilemap._wrackLayer = this;
            this.T = this.tilemap.tileWidth;
            this.q = this.T / 2;
            this.mapId = $gameMap.mapId();
            this.w = $gameMap.width();
            this.h = $gameMap.height();
            this.originals = this.tilemap._bitmaps.slice();
            this.names = $gameMap.tileset() ? $gameMap.tileset().tilesetNames.slice() : [];
            this.source = null; // pixels of the nine sheets
            this.palette = null;
            this.derived = {}; // key `${state}|${variant}` -> [9 canvases or null]
            this.jobs = [];
            this.cells = new Uint8Array(this.w * this.h);
            this.prev = new Uint8Array(this.w * this.h);
            this.threshold = null; // Uint8Array during a transition
            this.progress = 256;
            this.transition = null;
            this.tables = {}; // stateIndex -> [variant tables]
            this.atlases = [];
            this.live = false;
            this.wanted = [];
            this.dirty = true;
            this.failed = false;
            this.particles = new Particles(this);
            this.tilemap.addChild(this.particles.container);
            // the veil (years / fade): made at the first such transition, reused after
            this.veil = null;        // { lower, upper, rts: [lower, upper], filter, changedBmp, ox, oy }
            this.veilMode = false;   // a veiled transition is running: the tiles show the NEW state everywhere
            this.veilPending = false; // true only while the old state is painted for the snapshot
            this.fire = null;         // the fire's sweep while a veiled fire runs (fireLayout)
            // the object split: lower objects (layers 2-3) on their own layer just above the ground
            this.objLayer = new Tilemap.CombinedLayer();
            this.objLayer.z = 0.6;
            this.tilemap.addChild(this.objLayer);
            this.tilemap._wrackObjLayer = this.objLayer;
            this.tilemap.refresh();
            // the decor (map-space field marks), between the ground and the objects; ground = an A2 or A5 tile on the
            // map's first layer (z 0 in tileId terms)
            this.ground = new Uint8Array(this.w * this.h);
            this.roof = new Uint8Array(this.w * this.h);   // an A3 roof on the first layer: the decor lays ash on a burned one
            for (let y = 0; y < this.h; y++) for (let x = 0; x < this.w; x++) {
                const id = $gameMap.tileId(x, y, 0);
                if (Tilemap.isTileA2(id) || Tilemap.isTileA5(id)) this.ground[y * this.w + x] = 1;
                else if (Tilemap.isRoofTile(id)) this.roof[y * this.w + x] = 1;
            }
            this.decor = null;   // { sprite, filter, bmp, tex } made when a state first needs it
            this.groundClass = null;   // per cell: 1 grass, 2 earth, 3 paving (classifyGround), once the sheets are read
        }
        /** Write the per-cell state map the decor reads: 'painted' (what the tiles show now), 'prev' or 'cells'. */
        writeDecor(which) {
            let any = false;
            for (let i = 0; i < this.cells.length; i++) if (this.cells[i] || this.prev[i]) { any = true; break; }
            if (!any && !this.decor) return;
            if (!this.decor) {
                const bmp = new Bitmap(this.w, this.h);
                bmp.smooth = false;
                const filter = new DecorFilter();
                const sprite = new PIXI.Sprite(PIXI.Texture.WHITE);
                sprite.z = 0.3;   // over the ground (z 0), under the split object layer (0.6) and every character
                sprite.filters = [filter];
                this.tilemap.addChild(sprite);
                this.decor = { bmp: bmp, tex: new PIXI.Texture(bmp.baseTexture), filter: filter, sprite: sprite, img: bmp.context.createImageData(this.w, this.h) };
                const u = filter.uniforms;
                u.uNoise = veilNoise().texture;
                u.uCells = this.decor.tex;
                u.uMapSize[0] = this.w;
                u.uMapSize[1] = this.h;
                u.uTile = this.T;
            }
            const data = this.decor.img.data;
            const cls = this.classifyGround();
            for (let i = 0; i < this.cells.length; i++) {
                let s = which === 'prev' ? this.prev[i] : this.cells[i];
                if (which === 'painted' && !this.veilMode && this.threshold && this.threshold[i] >= this.shownProgress) s = this.prev[i];
                data[i * 4] = s * 63;
                // G = the cell's kind x 50: 50 grass, 100 earth, 150 paving (classifyGround), 200 roof, 0 none of these
                data[i * 4 + 1] = this.ground[i] ? (cls ? cls[i] : 2) * 50 : this.roof[i] ? 200 : 0;
                data[i * 4 + 3] = 255;
            }
            this.decor.bmp.context.putImageData(this.decor.img, 0, 0);
            this.decor.bmp.baseTexture.update();
            this.placeDecor();
        }
        /**
         * What each ground cell IS, read once per map from its own tile's pixels (the interior T x T of its A2 block, or
         * its A5 tile), so the decor puts straw on grass and grit on paving, never straw on cobbles: 1 grass (green
         * leads), 3 paving (grey: channels within 26 of each other), 2 earth (the rest: dirt, sand, wood). Uint8Array,
         * or null while the sheets are unread. Pure arithmetic on pixels already read for derivation (Probe §27a).
         */
        classifyGround() {
            if (this.groundClass) return this.groundClass;
            if (!this.source) return null;
            const W = this.w;
            const H = this.h;
            const T = this.T;
            const out = new Uint8Array(W * H);
            const memo = new Map();
            for (let y = 0; y < H; y++) {
                for (let x = 0; x < W; x++) {
                    const i = y * W + x;
                    if (!this.ground[i]) continue;
                    const id = $gameMap.tileId(x, y, 0);
                    const key = Tilemap.isAutotile(id) ? 'k' + Tilemap.getAutotileKind(id) : 'a' + id;
                    if (!memo.has(key)) {
                        let set, sx, sy;
                        if (Tilemap.isTileA2(id)) {
                            // the block's INTERIOR (the quarters FLOOR_AUTOTILE_TABLE shape 0 draws: block quarters x 1-2,
                            // y 3-4), never its top-left tile, which is the island preview and mostly the BORDER's colour
                            // (MEASURED 2026-10-10 on a Verdant dirt road: the preview read as grass, 45 earth cells -> 0)
                            const kind = Tilemap.getAutotileKind(id);
                            set = 1;
                            sx = (kind % 8) * 2 * T + T / 2;
                            sy = (Math.floor(kind / 8) - 2) * 3 * T + T * 1.5;
                        } else {
                            set = 4;
                            sx = ((Math.floor(id / 128) % 2) * 8 + (id % 8)) * T;
                            sy = (Math.floor((id % 256) / 8) % 16) * T;
                        }
                        const src = this.source[set];
                        let r = 0, g = 0, b = 0, n = 0;
                        if (src) {
                            for (let yy = sy; yy < sy + T && yy < src.height; yy += 2) {
                                for (let xx = sx; xx < sx + T && xx < src.width; xx += 2) {
                                    const o = (yy * src.width + xx) * 4;
                                    if (src.data[o + 3] < 128) continue;
                                    r += src.data[o];
                                    g += src.data[o + 1];
                                    b += src.data[o + 2];
                                    n++;
                                }
                            }
                        }
                        let c = 2;
                        if (n) {
                            r /= n; g /= n; b /= n;
                            if (g > r + 12 && g > b + 8) c = 1;
                            else if (Math.max(r, g, b) - Math.min(r, g, b) < 26) c = 3;
                        }
                        memo.set(key, c);
                    }
                    out[i] = memo.get(key);
                }
            }
            this.groundClass = out;
            return out;
        }
        /** Per frame, no allocation: the sprite covers the screen; the filter reads the live transform. */
        placeDecor() {
            const D = this.decor;
            if (!D) return;
            const tm = this.tilemap;
            D.sprite.width = Graphics.width;
            D.sprite.height = Graphics.height;
            const u = D.filter.uniforms;
            const wt = tm.worldTransform;
            u.uScreenOrigin[0] = wt.tx;
            u.uScreenOrigin[1] = wt.ty;
            u.uZoom = wt.a;
            u.uOrigin[0] = Math.ceil(tm.origin.x);
            u.uOrigin[1] = Math.ceil(tm.origin.y);
        }
        destroy() {
            this.tilemap._wrackLayer = null;
            if (this.tilemap._wrackObjLayer === this.objLayer) this.tilemap._wrackObjLayer = null;
            this.tilemap.removeChild(this.objLayer);
            this.objLayer.destroy({ children: true });
            this.tilemap.refresh();
            if (this.decor) {
                this.tilemap.removeChild(this.decor.sprite);
                this.decor.sprite.destroy();
                this.decor.tex.destroy(false);
                this.decor.bmp.destroy();
                this.decor = null;
            }
            if (this.veil) {
                this.veil.lower.destroy();
                this.veil.upper.destroy();
                for (const rt of this.veil.rts) rt.destroy(true);
                if (this.veil.changedTex) this.veil.changedTex.destroy(false);
                if (this.veil.changedBmp) this.veil.changedBmp.destroy();
                this.veil = null;
            }
            this.particles.destroy();
            for (const a of this.atlases) a.destroy();
            this.atlases.length = 0;
        }
        // ---- derivation -------------------------------------------------
        ready() {
            return this.tilemap.isReady();
        }
        readSources() {
            if (this.source) return true;
            if (!this.ready()) return false;
            const out = [];
            for (let i = 0; i < 9; i++) {
                const bmp = this.originals[i];
                const img = bmp && (bmp.image || bmp._canvas);
                if (!img || !img.width) {
                    out.push(null);
                    continue;
                }
                try {
                    const c = document.createElement('canvas');
                    c.width = img.width;
                    c.height = img.height;
                    const ctx = c.getContext('2d');
                    ctx.drawImage(img, 0, 0);
                    const d = ctx.getImageData(0, 0, c.width, c.height);
                    out.push({ width: c.width, height: c.height, data: d.data });
                } catch (e) {
                    console.warn('[Wrack] cannot read tileset "' + this.names[i] + '" (' + e.message + '); it stays intact');
                    out.push(null);
                }
            }
            this.source = out;
            this.palette = core().harvest(out.filter(Boolean));
            Wrack._reads += 1;
            return true;
        }
        want(stateIndex) {
            for (let v = 0; v < P.variants; v++) {
                const key = stateIndex + '|' + v;
                if (this.derived[key] || this.jobs.some(j => j.key === key)) continue;
                this.derived[key] = null;
                for (let i = 0; i < 9; i++) this.jobs.push({ key: key, state: STATES[stateIndex - 1], variant: v, sheet: i });
            }
        }
        pump(budgetMs) {
            if (!this.readSources()) return false;
            const t0 = performance.now();
            const kinds = ['A1', 'A2', 'A3', 'A4', 'A5', 'B', 'C', 'D', 'E'];
            while (this.jobs.length && performance.now() - t0 < budgetMs) {
                const j = this.jobs.shift();
                const src = this.source[j.sheet];
                let list = this.derived[j.key];
                if (!list) list = this.derived[j.key] = new Array(9).fill(null);
                if (src) {
                    const out = core().deriveSheet(kinds[j.sheet], src, {
                        state: j.state,
                        tile: this.T,
                        seed: P.seed,
                        variant: j.variant,
                        palette: this.palette,
                        rubbleFor: j.sheet === 2 ? rubbleFor(src, this.T) : null
                    });
                    const c = document.createElement('canvas');
                    c.width = out.width;
                    c.height = out.height;
                    c.getContext('2d').putImageData(new ImageData(out.data, out.width, out.height), 0, 0);
                    list[j.sheet] = c;
                    Wrack._derivedSheets += 1;
                }
                list.done = (list.done || 0) + 1;
            }
            return this.jobs.length === 0;
        }
        isDerived(stateIndex) {
            for (let v = 0; v < P.variants; v++) {
                const l = this.derived[stateIndex + '|' + v];
                if (!l || l.done !== 9) return false;
            }
            return true;
        }
        // ---- layout -----------------------------------------------------
        markDirty() {
            this.dirty = true;
        }
        refreshLayout() {
            const lay = computeLayout(this.w, this.h);
            const used = new Set();
            for (let i = 0; i < lay.cells.length; i++) if (lay.cells[i]) used.add(lay.cells[i]);
            for (const s of lay.preload) used.add(STATE_INDEX[s]);
            for (const s of used) this.want(s);
            const changed = !this.live || !sameBytes(lay.cells, this.cells);
            this.target = lay.cells;
            this.needStates = used.size > 0;
            this.dirty = false;
            return changed;
        }
        /** Called every frame (and while the map is still loading, from Scene_Map.isReady). */
        update(budgetMs) {
            if (this.failed) return;
            try {
                if (this.dirty) {
                    if (this.refreshLayout()) this.pendingApply = true;
                }
                if (this.jobs.length) this.pump(budgetMs);
                // a map with nothing in a state never reads a pixel; otherwise the sources must be read first
                if (this.pendingApply && !this.jobs.length && (!this.needStates || this.readSources())) {
                    this.apply();
                    this.pendingApply = false;
                }
                if (this.transition) this.stepTransition();
                this.placeDecor();
                this.particles.update();
            } catch (e) {
                this.failed = true;
                this.live = false;
                console.error('[Wrack] stopped on this map:', e);
            }
        }
        busy() {
            return !!(this.dirty || this.pendingApply || this.jobs.length || this.transition);
        }
        apply() {
            const next = this.target;
            const tr = Wrack._nextTransition;
            Wrack._nextTransition = null;
            if (tr && tr.kind !== 'none' && this.live) {
                this.prev.set(this.cells);
                this.cells.set(next);
                this.beginTransition(tr);
            } else {
                this.cells.set(next);
                this.prev.set(next);
                this.threshold = null;
                this.progress = 256;
                if (this.transition) {
                    // an instant change ends a running transition; its veil must not keep dissolving a stale picture
                    this.endVeil();
                    this.transition = null;
                    this.particles.endFront();
                }
            }
            if (this.needStates || this.atlases.length) this.pack();
            this.writeDecor('painted');
            this.live = true;
            this.particles.rebuild();
            this.tilemap.refresh();
        }
        // ---- the atlas --------------------------------------------------
        pack() {
            const T = this.T;
            const q = this.q;
            const grid = Math.floor(ATLAS / q);
            const states = new Set();
            for (let i = 0; i < this.cells.length; i++) {
                if (this.cells[i]) states.add(this.cells[i]);
                if (this.prev[i]) states.add(this.prev[i]);
            }
            // which source cells the stated cells can draw from
            const need = new Map();
            const add = (set, qx, qy, size) => {
                const k = set * STRIDE * STRIDE + qy * STRIDE + qx;
                if (!need.has(k)) need.set(k, size);
            };
            const data = $gameMap.data();
            const W = this.w;
            const H = this.h;
            for (let y = 0; y < H; y++) {
                for (let x = 0; x < W; x++) {
                    if (!this.cells[y * W + x] && !this.prev[y * W + x]) continue;
                    for (let z = 0; z < 4; z++) sourceCellsOf(data[(z * H + y) * W + x] || 0, T, add);
                    if (y > 0) sourceCellsOf(data[(1 * H + y - 1) * W + x] || 0, T, add); // a table edge drawn from the tile above
                }
            }
            const singles = [];
            const doubles = [];
            for (const [k, size] of need) (size === 2 ? doubles : singles).push(k);
            const perCopy = doubles.length * 4 + singles.length;
            const capacity = SLOTS * grid * grid;
            let variants = P.variants;
            while (variants > 1 && perCopy * variants * states.size > capacity) variants--;
            if (perCopy * variants * states.size > capacity) console.warn('[Wrack] this map uses more tiles in states than fit; some stay intact');
            this.variants = variants;
            Wrack._lastPack = { states: states.size, variants: variants, cellsPerCopy: perCopy, capacity: capacity, need: need.size };
            // atlas canvases
            while (this.atlases.length < SLOTS) this.atlases.push(new Bitmap(ATLAS, ATLAS));
            for (const a of this.atlases) a.clear();
            this.tables = {};
            // an occupancy grid per slot: a 2x2 tile cell and a 1x1 quarter can never overlap
            const used = new Uint8Array(SLOTS * grid * grid);
            let slot = 0;
            let cx = 0;
            let cy = 0;
            let scan1 = 0;
            let scan2 = 0;
            const takeAt = (i, size) => {
                slot = Math.floor(i / (grid * grid));
                const r = i % (grid * grid);
                cy = Math.floor(r / grid);
                cx = r % grid;
                for (let dy = 0; dy < size; dy++) for (let dx = 0; dx < size; dx++) used[slot * grid * grid + (cy + dy) * grid + cx + dx] = 1;
                return true;
            };
            const free2 = () => {
                for (; scan2 < used.length; scan2++) {
                    const r = scan2 % (grid * grid);
                    const y = Math.floor(r / grid);
                    const x = r % grid;
                    if (x % 2 || y % 2 || x + 2 > grid || y + 2 > grid) continue;
                    const base = scan2 - r;
                    if (used[base + y * grid + x] || used[base + y * grid + x + 1] || used[base + (y + 1) * grid + x] || used[base + (y + 1) * grid + x + 1]) continue;
                    return takeAt(scan2, 2);
                }
                return false;
            };
            const free1 = () => {
                for (; scan1 < used.length; scan1++) if (!used[scan1]) return takeAt(scan1, 1);
                return false;
            };
            for (const s of states) {
                this.tables[s] = [];
                for (let v = 0; v < variants; v++) {
                    const table = { q: q, cells: new Int32Array(9 * STRIDE * STRIDE).fill(-1) };
                    this.tables[s].push(table);
                    const sheets = this.derived[s + '|' + v];
                    if (!sheets) continue;
                    const place = (k, size) => {
                        const set = Math.floor(k / (STRIDE * STRIDE));
                        const rest = k % (STRIDE * STRIDE);
                        const sqy = Math.floor(rest / STRIDE);
                        const sqx = rest % STRIDE;
                        const src = sheets[set];
                        if (!src || (sqx + size) * q > src.width || (sqy + size) * q > src.height) return true;
                        if (!(size === 2 ? free2() : free1())) return false;
                        this.atlases[slot].context.drawImage(src, sqx * q, sqy * q, size * q, size * q, cx * q, cy * q, size * q, size * q);
                        Wrack._packed += size * size;
                        for (let dy = 0; dy < size; dy++) {
                            for (let dx = 0; dx < size; dx++) {
                                table.cells[set * STRIDE * STRIDE + (sqy + dy) * STRIDE + sqx + dx] = (slot << 20) | ((cx + dx) << 10) | (cy + dy);
                            }
                        }
                        return true;
                    };
                    for (const k of doubles) if (!place(k, 2)) break;
                    for (const k of singles) if (!place(k, 1)) break;
                }
            }
            for (const a of this.atlases) a.baseTexture.update();
            this.tilemap.setBitmaps(this.originals.concat(this.atlases));
        }
        tableAt(mx, my) {
            const W = this.w;
            const H = this.h;
            if (this.tilemap.horizontalWrap) mx = ((mx % W) + W) % W;
            if (this.tilemap.verticalWrap) my = ((my % H) + H) % H;
            if (mx < 0 || my < 0 || mx >= W || my >= H) return null;
            const i = my * W + mx;
            let s = this.cells[i];
            if (this.veilMode) {
                // a veiled change paints the old state once (for the snapshot), then the new state everywhere
                if (this.veilPending) s = this.prev[i];
            }
            // the PAINTED state follows shownProgress (set when the repaint is requested), not progress: the tilemap
            // paints lazily, a frame or more later, and the flames stand on shownProgress's line (review D4)
            else if (this.threshold && this.threshold[i] >= this.shownProgress) s = this.prev[i];
            if (!s) return null;
            const list = this.tables[s];
            if (!list || !list.length) return null;
            return list[list.length > 1 ? core().variantAt(mx, my, list.length, P.seed) : 0];
        }
        stateAt(x, y) {
            if (x < 0 || y < 0 || x >= this.w || y >= this.h) return null;
            const i = y * this.w + x;
            const s = this.threshold && this.threshold[i] >= this.progress ? this.prev[i] : this.cells[i];
            return s ? STATES[s - 1] : null;
        }
        // ---- transitions --------------------------------------------------
        beginTransition(tr) {
            const W = this.w;
            const H = this.h;
            this.endVeil();   // a change that interrupts a veiled one starts from the tiles, never from an old picture
            const th = new Uint8Array(W * H);
            const H_ = core().hash;
            if (VEIL_KINDS[tr.kind] && canVeil()) {
                // R23: the veil. A cell's state (stateAt, smoke, the API) flips when the dissolve edge passes the
                // noise at its centre, so what the game reads matches the picture over the cell.
                // (fade cross-fades the whole change, so every cell flips half-way; fire flips a cell when the burning
                // line passes its centre, and a pond when the line has passed all of it)
                this.fire = null;
                this.water = null;
                if (tr.kind === 'fade') th.fill(128);
                else if (tr.kind === 'fire') this.fire = this.fireLayout(th);
                else for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) th[y * W + x] = Math.min(255, Math.floor(veilAt(x, y) * 255));
                if (this.fire) this.water = this.fire.water;
                this.threshold = th;
                this.progress = tr.kind === 'fade' || this.fire ? 0 : Math.round(veilCut(0) * 255);
                this.shownProgress = 256;
                this.veilMode = true;
                this.veilPending = true;   // the snapshot is taken on the first step, after pack() (apply)
                this.transition = { kind: tr.kind, frames: Math.max(1, tr.duration | 0), frame: 0, lastStep: -1, veil: true };
                this.particles.beginFront(tr.kind);
                return;
            }
            for (let y = 0; y < H; y++) {
                for (let x = 0; x < W; x++) {
                    let t;
                    if (tr.kind === 'fire') t = (x + 0.5) / W + (H_(x, y, 51) - 0.5) * 0.08 + Math.sin(y * 0.7) * 0.02;
                    else if (tr.kind === 'years') {
                        // the change creeps: soft clusters, early ones first
                        const gx = Math.floor(x / 3);
                        const gy = Math.floor(y / 3);
                        t = H_(gx, gy, 52) * 0.7 + H_(x, y, 53) * 0.3;
                    } else t = H_(x, y, 54);
                    th[y * W + x] = Math.max(0, Math.min(255, Math.floor(t * 255)));
                }
            }
            // ⛔ WATER DOES NOT BURN (independent review 2026-10-08, R24: flames stood on the pond and the pond darkened in
            // hard tile squares as the front crossed it). Every water cell (MZ's A1 water, Tilemap.isWaterTile on layer 0)
            // is marked once here, so the front's flames skip it, and each connected body of water takes ONE threshold,
            // its latest cell's: a pond changes in a single step after the fire has passed all of it, never square by square.
            const water = new Uint8Array(W * H);
            for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (Tilemap.isWaterTile($gameMap.tileId(x, y, 0))) water[y * W + x] = 1;
            if (tr.kind === 'fire') {
                const seen = new Uint8Array(W * H), stack = [], body = [];
                for (let i0 = 0; i0 < W * H; i0++) {
                    if (!water[i0] || seen[i0]) continue;
                    body.length = 0; stack.length = 0; stack.push(i0); seen[i0] = 1; let mx = 0;
                    while (stack.length) {
                        const i = stack.pop(), x = i % W, y = (i - x) / W; body.push(i); if (th[i] > mx) mx = th[i];
                        if (x > 0 && water[i - 1] && !seen[i - 1]) { seen[i - 1] = 1; stack.push(i - 1); }
                        if (x < W - 1 && water[i + 1] && !seen[i + 1]) { seen[i + 1] = 1; stack.push(i + 1); }
                        if (y > 0 && water[i - W] && !seen[i - W]) { seen[i - W] = 1; stack.push(i - W); }
                        if (y < H - 1 && water[i + W] && !seen[i + W]) { seen[i + W] = 1; stack.push(i + W); }
                    }
                    for (const i of body) th[i] = mx;
                }
            }
            this.water = water;
            this.threshold = th;
            this.progress = 0;
            this.shownProgress = 0;
            this.transition = { kind: tr.kind, frames: Math.max(1, tr.duration | 0), frame: 0, lastStep: -1 };
            this.particles.beginFront(tr.kind);
        }
        /**
         * The fire's sweep, in map pixels: the burning line stands at x0 + p * span, wandering FIRE_WOB tiles with the
         * veil noise, so a cell burns when the line passes its centre. Water does not burn (R24): every connected body
         * of water takes ONE threshold, the moment the line has passed its far edge. Fills th; returns the sweep.
         */
        fireLayout(th) {
            const W = this.w;
            const H = this.h;
            const T = this.T;
            const wob = FIRE_WOB * T;
            const rim = Math.max(3, Math.round(FIRE_RIM * T));
            const x0 = -(wob * 0.5 + rim + 3);
            const span = W * T + wob + rim * 2 + 6 + T * 2;
            const water = new Uint8Array(W * H);
            const pondEnd = new Uint8Array(W * H);   // per water cell: the pond's far edge, in cells (its last x + 1)
            for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (Tilemap.isWaterTile($gameMap.tileId(x, y, 0))) water[y * W + x] = 1;
            const seen = new Uint8Array(W * H), stack = [], body = [];
            for (let i0 = 0; i0 < W * H; i0++) {
                if (!water[i0] || seen[i0]) continue;
                body.length = 0; stack.length = 0; stack.push(i0); seen[i0] = 1; let mx = 0;
                while (stack.length) {
                    const i = stack.pop(), x = i % W, y = (i - x) / W; body.push(i); if (x + 1 > mx) mx = x + 1;
                    if (x > 0 && water[i - 1] && !seen[i - 1]) { seen[i - 1] = 1; stack.push(i - 1); }
                    if (x < W - 1 && water[i + 1] && !seen[i + 1]) { seen[i + 1] = 1; stack.push(i + 1); }
                    if (y > 0 && water[i - W] && !seen[i - W]) { seen[i - W] = 1; stack.push(i - W); }
                    if (y < H - 1 && water[i + W] && !seen[i + W]) { seen[i + W] = 1; stack.push(i + W); }
                }
                for (const i of body) pondEnd[i] = Math.min(255, mx);
            }
            for (let y = 0; y < H; y++) {
                for (let x = 0; x < W; x++) {
                    const i = y * W + x;
                    // the line's own test (Particles.front and the shader): block centre + the noise's wander
                    const at = water[i]
                        ? pondEnd[i] * T + T
                        : Math.floor((x * T + T / 2) / 3) * 3 + 1.5 + (noiseAtPx(x * T + T / 2, y * T + T / 2, T) - 0.5) * wob;
                    th[i] = Math.max(0, Math.min(255, Math.round(((at - x0) / span) * 255)));
                }
            }
            return { x0: x0, span: span, wob: wob, rim: rim, scorch: Math.round(FIRE_SCORCH * T), water: water, pondEnd: pondEnd };
        }
        /** Paint the OLD state once and photograph the two tile layers into the veil (screen-sized textures). */
        takeVeil() {
            const tm = this.tilemap;
            const renderer = Graphics._app.renderer;
            const w = Graphics.width;
            const h = Graphics.height;
            let v = this.veil;
            if (!v || v.rts[0].width !== w || v.rts[0].height !== h) {
                if (v) {
                    v.lower.destroy();
                    v.upper.destroy();
                    for (const rt of v.rts) rt.destroy(true);
                }
                const rts = [PIXI.RenderTexture.create({ width: w, height: h }), PIXI.RenderTexture.create({ width: w, height: h })];
                const filter = (v && v.filter) || new VeilFilter();
                const filter2 = (v && v.filter2) || new VeilFilter();   // the upper veil's: identical, but draws no glowing edge
                const lower = new PIXI.Sprite(rts[0]);
                const upper = new PIXI.Sprite(rts[1]);
                lower.z = 0.7;   // above the ground AND the split object layer (0.6), under every character (rmmz_core.js 2394)
                upper.z = 4.5;   // just above the upper tiles, under "above characters" (z 5)
                lower.filters = [filter];
                upper.filters = [filter2];
                tm.addChild(lower);
                tm.addChild(upper);
                v = this.veil = { lower: lower, upper: upper, rts: rts, filter: filter, filter2: filter2, changedBmp: (v && v.changedBmp) || null, changedTex: (v && v.changedTex) || null, ox: 0, oy: 0 };
            }
            // which cells change: only those are veiled (an unchanged cell keeps its live water and animation)
            if (!v.changedBmp || v.changedBmp.width !== this.w || v.changedBmp.height !== this.h) {
                if (v.changedTex) v.changedTex.destroy(false);
                if (v.changedBmp) v.changedBmp.destroy();
                v.changedBmp = new Bitmap(this.w, this.h);
                v.changedBmp.smooth = false;   // one texel a cell, read NEAREST: a cell is veiled or it is not
                v.changedTex = new PIXI.Texture(v.changedBmp.baseTexture);
            }
            const ctx = v.changedBmp.context;
            const img = ctx.createImageData(this.w, this.h);
            let changed = 0;
            const F = this.fire;
            for (let i = 0; i < this.cells.length; i++) {
                if (this.cells[i] === this.prev[i]) continue;
                img.data[i * 4 + 3] = 255;
                changed++;
                // fire: water cells carry their pond's far edge (G, as a share of the map width) and a flag (B)
                if (F && F.water[i]) {
                    img.data[i * 4 + 1] = Math.min(255, Math.round((F.pondEnd[i] / this.w) * 255));
                    img.data[i * 4 + 2] = 255;
                }
            }
            ctx.putImageData(img, 0, 0);
            v.changedBmp.baseTexture.update();
            // the old state, painted now, photographed, then the tiles repaint as the new state
            this.veilPending = true;
            tm._needsRepaint = true;
            tm.updateTransform();
            renderer.render(tm._lowerLayer, v.rts[0], true);
            if (this.decor) {
                // the OLD state's field marks between the old ground and the old objects, then back to the new
                this.writeDecor('prev');
                renderer.render(this.decor.sprite, v.rts[0], false);
            }
            if (this.objLayer) renderer.render(this.objLayer, v.rts[0], false);   // the old objects over the old ground
            if (this.decor) this.writeDecor('cells');
            renderer.render(tm._upperLayer, v.rts[1], true);
            this.veilPending = false;
            tm.refresh();
            v.ox = Math.ceil(tm.origin.x);
            v.oy = Math.ceil(tm.origin.y);
            const kind = this.transition && this.transition.kind;
            for (let k = 0; k < 2; k++) {
                const u = (k ? v.filter2 : v.filter).uniforms;
                u.uNoise = veilNoise().texture;
                u.uChanged = v.changedTex;
                u.uMapSize[0] = this.w;
                u.uMapSize[1] = this.h;
                u.uTile = this.T;
                u.uPeriod = this.T * VEIL_TILES;
                u.uMode = kind === 'fire' && F ? 2 : kind === 'fade' ? 1 : 0;
                if (F) {
                    u.uWob = F.wob;
                    u.uRim = F.rim;
                    u.uScorch = F.scorch;
                }
                u.uRimOn = k ? 0 : 1;
            }
            v.lower.visible = true;
            v.upper.visible = true;
            Wrack._lastVeil = { changed: changed, w: w, h: h };
            this.placeVeil(0);
        }
        /** Per frame, no allocation: follow the scroll and move the dissolve edge. */
        placeVeil(p) {
            const v = this.veil;
            const tm = this.tilemap;
            const ox = Math.ceil(tm.origin.x);
            const oy = Math.ceil(tm.origin.y);
            v.lower.x = v.upper.x = v.ox - ox;
            v.lower.y = v.upper.y = v.oy - oy;
            const wt = tm.worldTransform;
            const F = this.fire;
            for (let k = 0; k < 2; k++) {
                const u = (k ? v.filter2 : v.filter).uniforms;
                u.uScreenOrigin[0] = wt.tx;
                u.uScreenOrigin[1] = wt.ty;
                u.uZoom = wt.a;
                u.uOrigin[0] = ox;
                u.uOrigin[1] = oy;
                u.uCut = u.uMode > 0.5 ? p : veilCut(p);
                if (F) {
                    u.uFront = F.x0 + p * F.span;
                    u.uTime = this.particles.tick;
                }
            }
        }
        endVeil() {
            this.veilMode = false;
            this.veilPending = false;
            this.fire = null;
            if (this.veil) {
                this.veil.lower.visible = false;
                this.veil.upper.visible = false;
            }
        }
        stepTransition() {
            const tr = this.transition;
            if (tr.veil) {
                if (tr.frame === 0) this.takeVeil();
                tr.frame++;
                const p = Math.min(1, tr.frame / tr.frames);
                this.progress = tr.kind === 'fade' ? Math.round(p * 256) : this.fire ? Math.round(p * 255) : Math.round(veilCut(p) * 255);
                this.placeVeil(p);
                if (this.fire) this.particles.front('fire', p);
                if (tr.frame >= tr.frames) {
                    this.endVeil();
                    this.fire = null;
                    this.threshold = null;
                    this.progress = 256;
                    this.prev.set(this.cells);
                    this.transition = null;
                    this.particles.endFront();
                    this.particles.rebuild();
                    this.tilemap.refresh();
                }
                return;
            }
            tr.frame++;
            const p = Math.min(256, Math.floor((tr.frame / tr.frames) * 272));
            const step = p >> 3; // repaint when the front crosses an eighth of a band, not every frame
            this.progress = p;
            if (step !== tr.lastStep) {
                tr.lastStep = step;
                this.shownProgress = p; // what the repainted tiles show; the flames ride THIS line (review D4)
                this.tilemap.refresh();
                this.writeDecor('painted');   // the field marks follow the same line as the tiles
            }
            this.particles.front(tr.kind, p / 256);
            if (tr.frame >= tr.frames) {
                this.threshold = null;
                this.progress = 256;
                this.prev.set(this.cells);
                this.transition = null;
                this.particles.endFront();
                this.particles.rebuild();
                this.tilemap.refresh();
                this.writeDecor('painted');
            }
        }
    }

    function sameBytes(a, b) {
        if (a.length !== b.length) return false;
        for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
        return true;
    }
    function rubbleFor(img, T) {
        return function(r) {
            const y = r.y + 2 * T;
            if (y + 2 * T > img.height) return null;
            let solid = 0;
            for (let yy = y; yy < y + 2 * T; yy += 4) for (let xx = r.x; xx < r.x + 2 * T; xx += 4) if (img.data[(yy * img.width + xx) * 4 + 3] > 128) solid++;
            return solid > ((T / 2) * (T / 2)) * 0.5 ? { x: r.x, y: y, w: 2 * T, h: 2 * T } : null;
        };
    }

    //-------------------------------------------------------------------------
    // Smoke, embers and the burning front. Every sprite is made once; the
    // per-frame update allocates nothing (wing §3).
    //-------------------------------------------------------------------------
    const PUFFS = 64;
    const SPARKS = 48;
    const FLAMES = 64;   // two a row (one on the burning line, one trailing), 32 rows down the screen
    const FLAME_W = 11;  // one flame frame, in art pixels; shown at 3x NEAREST
    const FLAME_H = 16;
    function makePuffBitmap() {
        const b = new Bitmap(48, 48);
        const ctx = b.context;
        const g = ctx.createRadialGradient(24, 24, 2, 24, 24, 23);
        g.addColorStop(0, 'rgba(70,64,62,0.55)');
        g.addColorStop(0.55, 'rgba(58,54,54,0.32)');
        g.addColorStop(1, 'rgba(50,48,48,0)');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(24, 24, 23, 0, Math.PI * 2);
        ctx.fill();
        b.baseTexture.update();
        return b;
    }
    function makeSparkBitmap() {
        const b = new Bitmap(3, 3);
        b.fillRect(1, 0, 1, 3, '#ff9c30');
        b.fillRect(0, 1, 3, 1, '#ff9c30');
        b.fillRect(1, 1, 1, 1, '#ffe08a');
        return b;
    }
    /**
     * Three PIXEL-ART flames side by side (FLAME_W x FLAME_H each): tall, forked, leaning. Drawn at the art's own
     * scale and shown at 3x NEAREST, so the fire has the chunky pixels of the tiles and of the burning edge (second
     * review R4: smooth vector tongues, one per row, read as stickers). Each pixel's colour comes from its "heat":
     * how near it is to a tongue's axis, hotter low and in the middle.
     */
    function makeFlameBitmap() {
        const b = new Bitmap(FLAME_W * 3, FLAME_H);
        b.smooth = false;
        const C = ['#8f220d', '#cf3f17', '#f6801f', '#ffc14f', '#fff0b8'];
        const SHAPES = [
            [[5.5, 4.7, 16, 0], [3.2, 1.7, 9, -1.2], [8.0, 1.5, 7, 1]],          // tall, with two licks
            [[3.8, 3.3, 15, -1.6], [7.3, 3.0, 12, 1.7], [5.5, 4.5, 8, 0]],        // forked
            [[5.0, 4.5, 14, 2.6], [7.8, 1.6, 7, 1.2], [2.6, 1.4, 6, -0.6]]        // leaning
        ];
        for (let f = 0; f < 3; f++) {
            for (let y = 0; y < FLAME_H; y++) {
                for (let x = 0; x < FLAME_W; x++) {
                    let heat = 0;
                    let core = 0;
                    for (const [cx, hw, h, lean] of SHAPES[f]) {
                        const t = (FLAME_H - (y + 0.5)) / h;   // 0 at the base, 1 at this tongue's tip
                        if (t < 0 || t > 1) continue;
                        const axis = cx + lean * t * t;
                        const half = hw * Math.pow(1 - t, 0.75) + 0.35;
                        const r = Math.abs(x + 0.5 - axis) / half;
                        if (r >= 1) continue;
                        const v = 1 - r;
                        if (v > heat) heat = v;
                        const k = v * (1 - t * 0.9);
                        if (k > core) core = k;
                    }
                    if (heat <= 0) continue;
                    const c = core > 0.62 ? 4 : core > 0.42 ? 3 : heat > 0.42 ? 2 : heat > 0.16 ? 1 : 0;
                    b.fillRect(f * FLAME_W + x, y, 1, 1, C[c]);
                }
            }
        }
        return b;
    }
    /** A soft orange light, 96 px across, drawn once; added (blend ADD) under the fire front to light the tiles beside it. */
    function makeGlowBitmap() {
        const b = new Bitmap(96, 96);
        const ctx = b.context;
        const g = ctx.createRadialGradient(48, 48, 0, 48, 48, 48);
        g.addColorStop(0, 'rgba(255,140,40,0.55)');
        g.addColorStop(0.45, 'rgba(240,90,20,0.25)');
        g.addColorStop(1, 'rgba(200,60,10,0)');
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, 96, 96);
        b.baseTexture.update();
        return b;
    }
    class Particles {
        constructor(layer) {
            this.layer = layer;
            this.container = new Sprite();
            this.container.z = 5.5; // above upper tiles and characters that walk over them (Tilemap z list, rmmz_core.js 2392)
            this.puffBmp = makePuffBitmap();
            this.sparkBmp = makeSparkBitmap();
            this.flameBmp = makeFlameBitmap();
            this.glowBmp = makeGlowBitmap();
            this.puffs = [];
            this.sparks = [];
            this.flames = [];
            // the light the fire throws on the tiles around it, under everything else (review 2026-10-08, D3: a column
            // of flame icons with no light on the street beside it read as a stamped border, not a fire)
            this.glows = [];
            for (let i = 0; i < (FLAMES >> 1); i++) { const g = this.sprite(this.glowBmp, 0.5, 0.5); g.blendMode = 1; this.glows.push(g); }
            for (let i = 0; i < PUFFS; i++) this.puffs.push(this.sprite(this.puffBmp, 0.5, 0.5));
            for (let i = 0; i < SPARKS; i++) this.sparks.push(this.sprite(this.sparkBmp, 0.5, 0.5));
            for (let i = 0; i < FLAMES; i++) this.flames.push(this.sprite(this.flameBmp, 0.5, 1));
            this.pv = new Float32Array(PUFFS * 5); // x, y, age, life, drift (map pixels)
            this.sv = new Float32Array(SPARKS * 5);
            this.sources = new Int32Array(0);
            this.tick = 0;
            this.frontKind = null;
        }
        sprite(bmp, ax, ay) {
            const s = new Sprite(bmp);
            s.anchor.x = ax;
            s.anchor.y = ay;
            s.visible = false;
            this.container.addChild(s);
            return s;
        }
        destroy() {
            this.container.destroy({ children: true });
        }
        rebuild() {
            const L = this.layer;
            const data = $gameMap.data();
            const list = [];
            for (let y = 0; y < L.h; y++) {
                for (let x = 0; x < L.w; x++) {
                    if (L.cells[y * L.w + x] !== STATE_INDEX.burned) continue;
                    const id = data[y * L.w + x] || 0;
                    if (Tilemap.isRoofTile(id) && core().hash(x, y, 71 + P.seed) < P.smokeDensity) list.push(x, y);
                }
            }
            this.sources = Int32Array.from(list);
            if (!list.length && !this.frontKind) {
                // nothing burning here any more: the smoke and sparks already in the air go with it
                this.pv.fill(0);
                this.sv.fill(0);
                for (const p of this.puffs) p.visible = false;
                for (const p of this.sparks) p.visible = false;
            }
            this.burnedAny = false;
            for (let i = 0; i < L.cells.length; i++) if (L.cells[i] === STATE_INDEX.burned) { this.burnedAny = true; break; }
        }
        spawnPuff(mx, my) {
            for (let i = 0; i < PUFFS; i++) {
                const o = i * 5;
                if (this.pv[o + 3] > 0) continue;
                const T = this.layer.T;
                this.pv[o] = (mx + 0.3 + core().hash(mx, this.tick, 81) * 0.4) * T;
                this.pv[o + 1] = (my + 0.4) * T;
                this.pv[o + 2] = 0;
                this.pv[o + 3] = 150 + core().hash(my, this.tick, 82) * 90;
                this.pv[o + 4] = 0.15 + core().hash(this.tick, mx, 83) * 0.2;
                return;
            }
        }
        spawnSpark(px, py) {
            for (let i = 0; i < SPARKS; i++) {
                const o = i * 5;
                if (this.sv[o + 3] > 0) continue;
                this.sv[o] = px;
                this.sv[o + 1] = py;
                this.sv[o + 2] = 0;
                this.sv[o + 3] = 60 + core().hash(i, this.tick, 84) * 80;
                this.sv[o + 4] = (core().hash(this.tick, i, 85) - 0.3) * 0.6;
                return;
            }
        }
        update() {
            this.tick++;
            const L = this.layer;
            const T = L.T;
            const ox = L.tilemap.origin.x;
            const oy = L.tilemap.origin.y;
            const sw = Graphics.width;
            const sh = Graphics.height;
            // spawn: each visible source sends up a puff every ~14 frames, and a spark now and then
            if ((P.smoke || P.embers) && this.sources.length && L.live) {
                for (let i = 0; i < this.sources.length; i += 2) {
                    const mx = this.sources[i];
                    const my = this.sources[i + 1];
                    const sx = mx * T - ox;
                    const sy = my * T - oy;
                    if (sx < -T * 2 || sy < -T * 4 || sx > sw + T || sy > sh + T * 2) continue;
                    if (L.stateAt(mx, my) !== 'burned') continue;
                    if (P.smoke && (this.tick + i * 7) % 14 === 0) this.spawnPuff(mx, my);
                    if (P.embers && (this.tick + i * 13) % 23 === 0) this.spawnSpark((mx + 0.5) * T, (my + 0.4) * T);
                }
            }
            for (let i = 0; i < PUFFS; i++) {
                const o = i * 5;
                const s = this.puffs[i];
                if (this.pv[o + 3] <= 0) {
                    s.visible = false;
                    continue;
                }
                const a = ++this.pv[o + 2];
                const life = this.pv[o + 3];
                if (a >= life) {
                    this.pv[o + 3] = 0;
                    s.visible = false;
                    continue;
                }
                const t = a / life;
                s.visible = true;
                s.x = this.pv[o] + a * this.pv[o + 4] + Math.sin(a * 0.05 + i) * 3 - ox;
                s.y = this.pv[o + 1] - a * 0.42 - oy;
                const k = 0.45 + t * 1.6;
                s.scale.x = k;
                s.scale.y = k;
                s.opacity = 255 * Math.min(1, t * 6) * (1 - t);
            }
            for (let i = 0; i < SPARKS; i++) {
                const o = i * 5;
                const s = this.sparks[i];
                if (this.sv[o + 3] <= 0) {
                    s.visible = false;
                    continue;
                }
                const a = ++this.sv[o + 2];
                const life = this.sv[o + 3];
                if (a >= life) {
                    this.sv[o + 3] = 0;
                    s.visible = false;
                    continue;
                }
                s.visible = true;
                s.x = this.sv[o] + a * this.sv[o + 4] + Math.sin(a * 0.15 + i) * 4 - ox;
                s.y = this.sv[o + 1] - a * 0.9 - oy;
                s.opacity = 255 * (1 - a / life) * (0.6 + 0.4 * ((a >> 2) & 1));
            }
        }
        beginFront(kind) {
            this.frontKind = kind;
        }
        endFront() {
            this.frontKind = null;
            for (const f of this.flames) f.visible = false;
            for (const g of this.glows) g.visible = false;
        }
        /** hide one row's flames and its light */
        hideRow(r) {
            this.flames[r * 2].visible = false;
            this.flames[r * 2 + 1].visible = false;
            this.glows[r].visible = false;
        }
        /** a flame of this size (1 = 48 px tall) at map pixel (mx, my), base at my, frame cycling */
        placeFlame(f, mx, my, size, seed, ox, oy) {
            const t = this.tick;
            f.visible = true;
            f.setFrame((((t >> 2) + seed * 5) % 3) * FLAME_W, 0, FLAME_W, FLAME_H);
            f.x = Math.round(mx - ox + Math.sin(t * 0.31 + seed * 1.7) * 2);
            f.y = my - Math.round(oy);
            f.scale.x = 3 * size * (0.92 + Math.sin(t * 0.37 + seed * 2.1) * 0.1);
            f.scale.y = 3 * size * (1 + Math.sin(t * 0.53 + seed) * 0.2);
            f.opacity = 235;
        }
        /** the burning front: flames ride the burning line (veiled fire) or the column the change has reached */
        front(kind, p) {
            if (kind !== 'fire') return;
            const L = this.layer;
            const T = L.T;
            const ox = L.tilemap.origin.x;
            const oy = L.tilemap.origin.y;
            const F = L.fire;
            if (F && L.veilMode) {
                // THE BURNING LINE (2026-10-10, second review R3/R4): one row every 1/32 of the screen, each at its own
                // fixed jitter so the flames never stand in a rank; on each row the flame stands where the shader's
                // line crosses it (the same block, noise and wander as VEIL_FRAGMENT), sized per row, with a smaller
                // one trailing into the embers. No flame on water (R24) or on a cell the change does not touch.
                const rows = FLAMES >> 1;
                const gap = Graphics.height / rows;
                const X = F.x0 + p * F.span;
                const reach = F.wob * 0.5 + 6;
                for (let r = 0; r < rows; r++) {
                    const h1 = core().hash(r, 3, 97 + P.seed);
                    const my = oy + (r + 0.12 + h1 * 0.76) * gap;
                    let bx = -1e9;
                    for (let x = Math.floor((X - reach) / 3) * 3; x <= X + reach; x += 3) {
                        if (x + 1.5 + (noiseAtPx(x, my, T) - 0.5) * F.wob >= X) { bx = x + 1.5; break; }
                    }
                    // every test is made on the cell under the flame's BASE (its anchor), the pixel it stands on
                    const by = Math.round(my + T * 0.18);
                    const cx = Math.floor(bx / T);
                    const cy = Math.floor((by - 1) / T);   // the flame's lowest drawn row is by - 1
                    const i = cy * L.w + cx;
                    const size = 0.5 + core().hash(r, 5, 98 + P.seed) * 0.75;
                    const mid = Math.floor((by - T * size * 0.5) / T) * L.w + cx;   // the cell its body stands in
                    // and the cells under the two ends of its base (a flame centred on a shore must not lick the pond)
                    const half = FLAME_W * 1.5 * size * 0.7 + 3;
                    const wl = cy * L.w + Math.max(0, Math.floor((bx - half) / T));
                    const wr = cy * L.w + Math.min(L.w - 1, Math.floor((bx + half) / T));
                    if (p >= 1 || cx < 0 || cy < 0 || cx >= L.w || cy >= L.h || F.water[i] || F.water[wl] || F.water[wr] || (mid >= 0 && F.water[mid]) || L.cells[i] === L.prev[i] || bx - ox < -T || bx - ox > Graphics.width + T) {
                        this.hideRow(r);
                        continue;
                    }
                    this.placeFlame(this.flames[r * 2], bx, by, size, r, ox, oy);
                    // the trailing flame stands on the burned side, smaller, where its own cell is not water
                    const tx = bx - (0.3 + core().hash(r, 6, 99 + P.seed) * 0.7) * T;
                    const ty = Math.round(my + T * 0.1);
                    const tcy = Math.floor((ty - 1) / T);
                    const ti = tcy * L.w + Math.floor(tx / T);
                    const g = this.flames[r * 2 + 1];
                    const tr = tcy * L.w + Math.min(L.w - 1, Math.floor((tx + half * 0.62) / T));
                    if (tx > 0 && tcy < L.h && !F.water[ti] && !F.water[tr] && L.cells[ti] !== L.prev[ti]) this.placeFlame(g, tx, ty, size * 0.62, r + 17, ox, oy);
                    else g.visible = false;
                    const glow = this.glows[r];
                    glow.visible = true;
                    glow.x = bx - ox;
                    glow.y = my - oy;
                    glow.scale.x = glow.scale.y = 0.75 + size * 0.5 + Math.sin(this.tick * 0.21 + r * 1.3) * 0.08;
                    glow.opacity = 170 + Math.floor(Math.sin(this.tick * 0.37 + r) * 40);
                    if ((this.tick + r * 3) % 7 === 0) this.spawnSpark(bx + (core().hash(this.tick, r, 92) - 0.5) * T * 0.6, my);
                    if ((this.tick + r * 5) % 13 === 0) this.spawnPuff(Math.floor((bx - T * 0.4) / T), cy);
                }
                return;
            }
            const fx = p * L.w * T;
            const rows = Math.ceil(Graphics.height / T) + 1;
            const y0 = Math.floor(oy / T);
            // two flames a row (a big one on the front, a smaller one trailing into the burned side), each with its own
            // shape frame, cycled every few ticks
            for (let i = 0; i < FLAMES; i++) {
                const f = this.flames[i];
                const row = i >> 1;
                const back = (i & 1) === 1;
                const glow = back ? null : this.glows[row];
                if (row >= rows || p >= 1) {
                    f.visible = false;
                    if (glow) glow.visible = false;
                    continue;
                }
                const my = y0 + row;
                // the flames stand on THIS row's burn line as the tiles show it: the first cell not yet changed at the
                // last repaint (review 2026-10-08, D4: flames on a smooth line while the tiles burned on a jittered one
                // left unburned cells behind the fire and burned cells ahead of it). A row that has fully burned has none.
                let bx = fx / T;
                if (L.threshold && my >= 0 && my < L.h) {
                    bx = -1;
                    const base = my * L.w, sp = L.shownProgress;
                    // (water cells are skipped: a pond is not the fire's edge, R24)
                    for (let x = 0; x < L.w; x++) if (L.threshold[base + x] >= sp && !(L.water && L.water[base + x])) { bx = x; break; }
                    if (bx < 0) { f.visible = false; if (glow) glow.visible = false; continue; }
                }
                if (glow) {
                    glow.visible = true;
                    glow.x = bx * T - ox;
                    glow.y = (my + 0.5) * T - oy;
                    glow.scale.x = glow.scale.y = 1.25 + Math.sin(this.tick * 0.21 + row * 1.3) * 0.12;
                    glow.opacity = 200 + Math.floor(Math.sin(this.tick * 0.37 + row) * 40);
                }
                f.visible = true;
                f.setFrame(((((this.tick >> 3) + i * 7 + my) % 3) + 3) % 3 * FLAME_W, 0, FLAME_W, FLAME_H);
                f.x = bx * T - ox + Math.sin(this.tick * 0.3 + i * 1.7) * 4 - (back ? T * 0.45 : 0);
                f.y = (my + 1) * T - oy - (back ? T * 0.2 : 0);
                f.scale.y = 3 * ((back ? 0.75 : 1.1) + Math.sin(this.tick * 0.5 + i) * 0.25);
                f.scale.x = 3 * ((back ? 0.9 : 1.2) + Math.sin(this.tick * 0.37 + i * 2) * 0.15);
                f.opacity = back ? 190 : 230;
                // sparks and smoke rise from the flame's own cell (bx), never from the smooth line fx, which can lie on water (R24)
                if (!back && (this.tick + row) % 5 === 0) this.spawnSpark(bx * T + (core().hash(this.tick, row, 92) - 0.5) * T, (my + 0.5) * T);
                if (!back && (this.tick + row * 3) % 9 === 0) this.spawnPuff(Math.floor(bx), my);
            }
        }
    }

    //-------------------------------------------------------------------------
    // Hooks into the scene
    //-------------------------------------------------------------------------
    const _Spriteset_Map_loadTileset = Spriteset_Map.prototype.loadTileset;
    Spriteset_Map.prototype.loadTileset = function() {
        _Spriteset_Map_loadTileset.call(this);
        if (this._wrackLayer) this._wrackLayer.destroy();
        this._wrackLayer = this._tileset ? new MapLayer(this) : null;
        Wrack._layer = this._wrackLayer;
    };
    const _Spriteset_Map_update = Spriteset_Map.prototype.update;
    Spriteset_Map.prototype.update = function() {
        _Spriteset_Map_update.call(this);
        if (this._wrackLayer) this._wrackLayer.update(8);
    };
    const _Spriteset_Map_destroy = Spriteset_Map.prototype.destroy;
    Spriteset_Map.prototype.destroy = function(options) {
        if (this._wrackLayer) this._wrackLayer.destroy();
        this._wrackLayer = null;
        if (Wrack._layer && Wrack._layer.spriteset === this) Wrack._layer = null;
        _Spriteset_Map_destroy.call(this, options);
    };
    // A map that starts in a state waits for it behind the fade-in instead of flashing the intact town.
    const _Scene_Map_isReady = Scene_Map.prototype.isReady;
    Scene_Map.prototype.isReady = function() {
        const ok = _Scene_Map_isReady.call(this);
        if (!ok) return false;
        const L = this._spriteset && this._spriteset._wrackLayer;
        if (!L || L.failed) return true;
        L.update(24);
        return !(L.dirty || L.pendingApply || L.jobs.length);
    };
    const _Game_Switches_onChange = Game_Switches.prototype.onChange;
    Game_Switches.prototype.onChange = function() {
        _Game_Switches_onChange.call(this);
        if (P.bindings.length && Wrack._layer) Wrack._layer.markDirty();
    };
    const _Game_Interpreter_updateWaitMode = Game_Interpreter.prototype.updateWaitMode;
    Game_Interpreter.prototype.updateWaitMode = function() {
        if (this._waitMode === 'wrack') {
            if (Wrack.isBusy()) return true;
            this._waitMode = '';
            return false;
        }
        return _Game_Interpreter_updateWaitMode.call(this);
    };

    //-------------------------------------------------------------------------
    // Commands and the script API
    //-------------------------------------------------------------------------
    Wrack.VERSION = '1.0.0';
    Wrack._reads = 0;
    Wrack._derivedSheets = 0;
    Wrack._layer = null;
    Wrack._nextTransition = null;
    Wrack._lastPack = null;
    Wrack._packed = 0;

    /**
     * Put a target into a state. target: 'map' | 'region' | 'rect'; state: one
     * of the four or 'none'. opts: { regionId, x, y, width, height, transition,
     * duration }.
     */
    Wrack.set = function(target, state, opts) {
        opts = opts || {};
        state = String(state || 'none').toLowerCase();
        if (state !== 'none' && !STATE_INDEX[state]) throw new Error('Wrack.set: unknown state "' + state + '"');
        const rec = mapRecord($gameMap.mapId(), true);
        if (target === 'region') {
            const rid = Number(opts.regionId);
            if (!(rid > 0)) throw new Error('Wrack.set: region needs regionId 1 to 255');
            rec.regions[rid] = state;
        } else if (target === 'rect') {
            const x = Number(opts.x) || 0;
            const y = Number(opts.y) || 0;
            const w = Math.max(1, Number(opts.width) || 1);
            const h = Math.max(1, Number(opts.height) || 1);
            rec.rects.push([x, y, w, h, state]);
        } else {
            rec.all = state;
            rec.regions = {};
            rec.rects = [];
        }
        const kind = String(opts.transition || 'none');
        Wrack._nextTransition = kind === 'none' ? null : { kind: kind, duration: Number(opts.duration) || 120 };
        if (Wrack._layer) Wrack._layer.markDirty();
    };
    Wrack.clear = function() {
        const s = store();
        delete s.maps[$gameMap.mapId()];
        if (Wrack._layer) Wrack._layer.markDirty();
    };
    Wrack.preload = function(states) {
        if (!Wrack._layer) return;
        for (const s of states) if (STATE_INDEX[s]) Wrack._layer.want(STATE_INDEX[s]);
    };
    Wrack.stateAt = function(x, y) {
        return Wrack._layer ? Wrack._layer.stateAt(x, y) : null;
    };
    Wrack.isBusy = function() {
        return !!(Wrack._layer && !Wrack._layer.failed && Wrack._layer.busy());
    };

    PluginManager.registerCommand(PLUGIN, 'set', function(args) {
        Wrack.set(args.target || 'map', args.state || 'burned', {
            regionId: Number(args.regionId),
            x: Number(args.x),
            y: Number(args.y),
            width: Number(args.width),
            height: Number(args.height),
            transition: args.transition || 'none',
            duration: Number(args.duration) || 120
        });
        if (args.wait !== 'false') this.setWaitMode('wrack');
    });
    PluginManager.registerCommand(PLUGIN, 'clear', function() {
        Wrack.clear();
    });
    PluginManager.registerCommand(PLUGIN, 'preload', function(args) {
        Wrack.preload(String(args.states || '').split(',').map(s => s.trim().toLowerCase()));
    });
})();
