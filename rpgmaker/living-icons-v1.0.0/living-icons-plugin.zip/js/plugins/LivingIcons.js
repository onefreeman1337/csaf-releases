/*:
 * @target MZ
 * @plugindesc [Living Icons 1.0] Every icon in your menus moves by what it is: blades glint, gems twinkle, potions bubble, fire flickers. No frames to draw, no notetags needed.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 * @base LivingIconsCore
 * @orderAfter LivingIconsCore
 *
 * @param speed
 * @text Speed
 * @type number
 * @min 1
 * @max 8
 * @default 3
 * @desc Engine frames per animation frame. 3 is calm; 2 is livelier; 5 is slow.
 *
 * @param intensity
 * @text Intensity
 * @type select
 * @option Subtle
 * @value 1
 * @option Standard
 * @value 2
 * @option Bold
 * @value 3
 * @default 2
 * @desc How strong the light is. The most expensive quarter of your database is always one step stronger.
 *
 * @param skip
 * @text Leave out
 * @type string
 * @default
 * @desc Effects to switch off, comma separated: glint, twinkle, bubble, flicker, pulse.
 *
 * @help LivingIcons.js  (requires LivingIconsCore.js directly above it)
 * ============================================================================
 * Living Icons animates the icons RPG Maker draws in every window (items,
 * skills, equipment, shops, status) by reading what each icon IS:
 *
 *   weapons ............ a glint of light sweeps across the blade
 *   armour (metal) ..... a glint
 *   accessories ........ the icon's own brightest points twinkle
 *   recovery items ..... bubbles rise through the liquid
 *   key items .......... a slow pulse at the rim
 *   skills ............. by element: fire flickers with embers, thunder
 *                        sparks, ice glints, water bubbles, light and dark pulse
 *
 * The effect is chosen from your DATABASE (weapon, armour slot, element,
 * recovery effect), so a red sword is a blade that glints, never a fire.
 * Each icon plays briefly and then rests, and identical icons in one list are
 * out of step, so a full inventory shimmers instead of strobing. Disabled
 * (greyed) entries stay greyed.
 *
 * Notetags (items, weapons, armours, skills):
 *   <Living Icon: glint>     force an effect (glint, twinkle, bubble,
 *                            flicker, pulse)
 *   <Living Icon: none>      keep this icon still
 *
 * Frames are made once per icon the first time it is drawn and played from
 * one shared texture, so a full menu costs very little per frame.
 *
 * An icon another plugin has drawn its own picture over (for example a
 * generated item picture) is left alone: Living Icons checks the pixels it
 * expects before it animates anything.
 *
 * Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.
 */
(function () {
  'use strict';

  const NAME = 'LivingIcons';
  const P = PluginManager.parameters(NAME);
  const toNum = (v, d) => { const s = String(v == null ? '' : v).trim(); if (s === '') return d; const n = Number(s); return Number.isFinite(n) ? n : d; };
  const PARAMS = {
    speed: Math.max(1, Math.min(8, Math.round(toNum(P.speed, 3)))),
    intensity: Math.max(1, Math.min(3, Math.round(toNum(P.intensity, 2)))),
    skip: String(P.skip || '').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean),
  };

  function core() {
    const C = window.LivingIconsCore;
    if (!C) throw new Error('Living Icons: LivingIconsCore.js is missing. Install it directly above LivingIcons.js and turn it ON.');
    return C;
  }

  // ------------------------------------------------------------------ what each icon is

  let table = null;            // iconIndex -> every database entry that uses it
  let prices = null;

  function recovers(item) {
    return (item.effects || []).some((e) => e.code === 11 || e.code === 12) || (item.damage && item.damage.type >= 3 && item.damage.type <= 4);
  }

  function attackElementOf(weapon) {
    const t = (weapon.traits || []).find((tr) => tr.code === 31);
    return t ? t.dataId : 0;
  }

  function buildTable() {
    table = new Map();
    const names = ($dataSystem && $dataSystem.elements) || [];
    // Every entry is kept: icons are shared (a status skill and an accessory can use the same picture), and the
    // FIRST entry is not necessarily the one that says what the picture is. slotFor() decides.
    const put = (iconIndex, entry) => {
      if (!(iconIndex > 0)) return;
      if (!table.has(iconIndex)) table.set(iconIndex, []);
      table.get(iconIndex).push(entry);
    };
    for (const s of $dataSkills || []) if (s) put(s.iconIndex, { kind: 'skill', elementName: names[s.damage ? s.damage.elementId : 0] || '', note: s.note || '', price: 0 });
    for (const w of $dataWeapons || []) if (w) put(w.iconIndex, { kind: 'weapon', elementName: names[attackElementOf(w)] || '', note: w.note || '', price: w.price || 0 });
    for (const a of $dataArmors || []) if (a) put(a.iconIndex, { kind: 'armor', etypeId: a.etypeId, note: a.note || '', price: a.price || 0 });
    for (const it of $dataItems || []) if (it) put(it.iconIndex, { kind: 'item', itypeId: it.itypeId, recovers: recovers(it), note: it.note || '', price: it.price || 0 });
    prices = [];
    for (const list of [$dataWeapons, $dataArmors, $dataItems]) for (const e of list || []) if (e && e.price > 0) prices.push(e.price);
    prices.sort((a, b) => a - b);
  }

  // ------------------------------------------------------------------ the shared atlas

  const SIZE = () => ImageManager.iconWidth;
  const ROWS_PER_PAGE = 32;
  const pages = [];
  const slots = new Map();      // iconIndex -> { page, row, effect } | { effect:'none' }
  let iconData = null;

  function iconSetData() {
    if (iconData) return iconData;
    const bmp = ImageManager.loadSystem('IconSet');
    if (!bmp.isReady() || !bmp.width) return null;
    iconData = bmp.context.getImageData(0, 0, bmp.width, bmp.height);   // once per session, never per frame
    return iconData;
  }

  function cutIcon(index) {
    const d = iconSetData(), s = SIZE();
    const out = new Uint8ClampedArray(s * s * 4);
    const sx = (index % 16) * s, sy = Math.floor(index / 16) * s;
    for (let y = 0; y < s; y++) for (let x = 0; x < s; x++) {
      const si = ((sy + y) * d.width + sx + x) * 4, di = (y * s + x) * 4;
      out[di] = d.data[si]; out[di + 1] = d.data[si + 1]; out[di + 2] = d.data[si + 2]; out[di + 3] = d.data[si + 3];
    }
    return out;
  }

  /** The slot for an icon, baking it on first use. Returns null while the IconSet is still loading. */
  function slotFor(index) {
    if (slots.has(index)) return slots.get(index);
    if (!iconSetData()) return null;
    if (!table) buildTable();
    const C = core(), s = SIZE();
    const entries = table.get(index) || [];
    const px = cutIcon(index);
    const read = C.readIcon(px, s);
    // A notetag on ANY entry using the icon wins; otherwise the first entry that maps to a real effect.
    const tagged = entries.find((e) => /<\s*living\s+icon\s*:/i.test(e.note));
    let entry = tagged || null, effect = tagged ? C.chooseEffect(tagged, read) : 'none';
    if (!tagged) for (const e of entries) { const fx = C.chooseEffect(e, read); if (fx !== 'none') { entry = e; effect = fx; break; } }
    if (!entry) entry = entries[0] || null;
    if (PARAMS.skip.indexOf(effect) >= 0) effect = 'none';
    if (effect === 'none') { const none = { effect: 'none' }; slots.set(index, none); return none; }
    // Skills have no price, so they sit at the middle tier; priced things rank against the database's own spread.
    const base = !entry || entry.kind === 'skill' ? 2 : C.tierOf(entry.price, prices);
    const tier = Math.max(1, Math.min(3, base + PARAMS.intensity - 2));
    const frames = C.bake(px, read, effect, tier, index);
    let page = pages[pages.length - 1];
    if (!page || page.used >= ROWS_PER_PAGE) { page = { bitmap: new Bitmap(C.FRAMES * s, ROWS_PER_PAGE * s), used: 0 }; pages.push(page); }
    const row = page.used++;
    const ctx = page.bitmap.context;
    for (let f = 0; f < frames.length; f++) ctx.putImageData(new ImageData(frames[f], s, s), f * s, row * s);
    page.bitmap.baseTexture.update();
    const slot = { page, row, effect, px };
    slots.set(index, slot);
    return slot;
  }

  // ------------------------------------------------------------------ windows

  /** Did the plain IconSet icon land at (x, y)? If another plugin drew its own picture there, leave it alone. */
  function landedAsIcon(win, slot, x, y) {
    const s = SIZE();
    const d = win.contents.context.getImageData(x, y, s, s).data;   // a refresh-time read on a 2D canvas, never per frame
    const probe = [[s >> 1, s >> 1], [s >> 2, s >> 2], [(3 * s) >> 2, (3 * s) >> 2], [s >> 2, (3 * s) >> 2]];
    let match = 0;
    for (const [px, py] of probe) {
      const i = (py * s + px) * 4;
      if (slot.px[i + 3] < 40) { match++; continue; }
      if (Math.abs(d[i] - slot.px[i]) + Math.abs(d[i + 1] - slot.px[i + 1]) + Math.abs(d[i + 2] - slot.px[i + 2]) < 60) match++;
    }
    return match >= 3;
  }

  const _drawIcon = Window_Base.prototype.drawIcon;
  Window_Base.prototype.drawIcon = function (iconIndex, x, y) {
    _drawIcon.call(this, iconIndex, x, y);
    try {
      const slot = slotFor(iconIndex);
      if (!slot || slot.effect === 'none' || !this.contents) return;
      const fx = Math.floor(x), fy = Math.floor(y);
      if (!landedAsIcon(this, slot, fx, fy)) return;
      this.livingIconAdd(iconIndex, slot, fx, fy);
    } catch (e) {
      if (Utils.isOptionValid('test')) console.warn('[Living Icons] ' + (e && e.message));
    }
  };

  Window_Base.prototype.livingIconAdd = function (iconIndex, slot, x, y) {
    if (!this._livingIcons) { this._livingIcons = []; this._livingSlot = 0; }
    let spr = null;
    for (const s of this._livingIcons) if (!s.visible) { spr = s; break; }
    if (!spr) { spr = new Sprite(); spr._lf = -1; this._livingIcons.push(spr); this._contentsSprite.addChild(spr); }
    const s = SIZE();
    spr.bitmap = slot.page.bitmap;
    spr._row = slot.row; spr._lf = -1;
    spr._phase = core().phaseOf(iconIndex, this._livingSlot++);
    spr.x = x; spr.y = y;
    spr.opacity = this.contents.paintOpacity;     // a greyed (disabled) entry stays greyed
    spr.visible = true;
    spr.setFrame(0, slot.row * s, s, s);
    spr._iconIndex = iconIndex;
  };

  Window_Base.prototype.livingIconClear = function (x, y, w, h) {
    if (!this._livingIcons) return;
    const s = SIZE();
    for (const spr of this._livingIcons) {
      if (!spr.visible) continue;
      if (x == null || (spr.x < x + w && spr.x + s > x && spr.y < y + h && spr.y + s > y)) spr.visible = false;
    }
  };

  // Clearing the contents (whole or part) retires the overlays drawn there. Per-instance wrappers on the bitmap,
  // so Bitmap.prototype is never touched.
  const _createContents = Window_Base.prototype.createContents;
  Window_Base.prototype.createContents = function () {
    _createContents.call(this);
    this.livingIconClear();
    const win = this, c = this.contents;
    const clear = c.clear, clearRect = c.clearRect;
    c.clear = function () { clear.call(this); win.livingIconClear(); };
    c.clearRect = function (x, y, w, h) { clearRect.call(this, x, y, w, h); win.livingIconClear(x, y, w, h); };
  };

  const _update = Window_Base.prototype.update;
  Window_Base.prototype.update = function () {
    _update.call(this);
    const list = this._livingIcons;
    if (!list) return;
    const F = core().FRAMES, s = SIZE(), fc = Graphics.frameCount, sp = PARAMS.speed;
    for (let i = 0; i < list.length; i++) {
      const spr = list[i];
      if (!spr.visible) continue;
      const f = (Math.floor(fc / sp) + spr._phase) % F;
      if (f !== spr._lf) { spr._lf = f; spr.setFrame(f * s, spr._row * s, s, s); }
    }
  };

  /** Public surface for scripts and the verification harness. */
  window.LivingIcons = {
    params: PARAMS,
    effectOf(iconIndex) { const sl = slotFor(iconIndex); return sl ? sl.effect : null; },
    rebuild() { table = null; slots.clear(); pages.length = 0; iconData = null; },
    stats() { let rows = 0; for (const p of pages) rows += p.used; return { pages: pages.length, baked: rows, known: slots.size }; },
  };
})();
