/*:
 * @target MZ
 * @plugindesc [Living Icons 1.0 core] Reads each icon and bakes its animation. Install DIRECTLY ABOVE LivingIcons.js.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help LivingIconsCore.js
 * ============================================================================
 * The pure half of Living Icons. No commands, no parameters. It reads an
 * icon's pixels and the database entry that uses it, chooses one restrained
 * effect (a glint, a twinkle, bubbles, a flicker with embers, a pulse), and
 * bakes the effect's frames once. LivingIcons.js plays them. No Math.random:
 * every frame is a pure function of (icon pixels, effect, seed).
 *
 * Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.
 */
(function (root) {
  'use strict';

  const VERSION = 1;
  const EFFECTS = ['glint', 'twinkle', 'bubble', 'flicker', 'pulse', 'none'];
  /** Frames per loop. A loop is long on purpose: the effect plays briefly, then the icon rests. */
  const FRAMES = 48;

  // ------------------------------------------------------------------ seeded numbers

  function hashString(s) {
    let h = 0x811c9dc5;
    const str = String(s);
    for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 0x01000193); }
    return h >>> 0;
  }
  function hash2(a, b) {
    let h = (Math.imul(a | 0, 0x27d4eb2d) ^ Math.imul(b | 0, 0x165667b1)) >>> 0;
    h = Math.imul(h ^ (h >>> 15), 0x85ebca6b);
    h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35);
    return (h ^ (h >>> 16)) >>> 0;
  }

  // ------------------------------------------------------------------ reading an icon

  function hsv(r, g, b) {
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b);
    const v = mx / 255, s = mx === 0 ? 0 : (mx - mn) / mx;
    let h = 0;
    if (mx !== mn) {
      if (mx === r) h = 60 * (((g - b) / (mx - mn)) % 6);
      else if (mx === g) h = 60 * ((b - r) / (mx - mn) + 2);
      else h = 60 * ((r - g) / (mx - mn) + 4);
      if (h < 0) h += 360;
    }
    return [h, s, v];
  }

  /**
   * Measures one icon: its opaque mask, its rim, its brightest points, and how much of it is warm, cool or liquid-coloured.
   * @param {Uint8Array|Uint8ClampedArray} px RGBA of a size x size icon (already cut out of the IconSet)
   * @param {number} size icon size in pixels (32 in MZ)
   */
  function readIcon(px, size) {
    const n = size * size;
    const mask = new Uint8Array(n), rim = new Uint8Array(n);
    let opaque = 0, warm = 0, cool = 0, satSum = 0, lumSum = 0;
    const lum = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      const o = i * 4;
      if (px[o + 3] < 40) continue;
      mask[i] = 1; opaque++;
      const [h, s, v] = hsv(px[o], px[o + 1], px[o + 2]);
      lum[i] = 0.299 * px[o] + 0.587 * px[o + 1] + 0.114 * px[o + 2];
      lumSum += lum[i]; satSum += s;
      if (s > 0.35 && v > 0.35 && (h < 50 || h > 340)) warm++;
      if (s > 0.3 && v > 0.3 && h > 170 && h < 300) cool++;
    }
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
      const i = y * size + x;
      if (!mask[i]) continue;
      if (x === 0 || y === 0 || x === size - 1 || y === size - 1 || !mask[i - 1] || !mask[i + 1] || !mask[i - size] || !mask[i + size]) rim[i] = 1;
    }
    // Inside distance: how far each opaque pixel is from the outside (4-neighbour BFS).
    const inside = new Uint8Array(n);
    {
      const q = new Int32Array(n); let head = 0, tail = 0;
      for (let i = 0; i < n; i++) if (rim[i]) { inside[i] = 1; q[tail++] = i; }
      while (head < tail) {
        const i = q[head++], x = i % size, y = (i / size) | 0, d1 = inside[i] + 1;
        for (const j of [x > 0 ? i - 1 : -1, x < size - 1 ? i + 1 : -1, y > 0 ? i - size : -1, y < size - 1 ? i + size : -1]) {
          if (j >= 0 && mask[j] && !inside[j]) { inside[j] = d1; q[tail++] = j; }
        }
      }
    }
    // A BADGE icon fills its square (RPG Maker's stock style: a white glyph on a coloured tile).
    const badge = opaque / n >= 0.85;
    // The GLYPH: on a badge, the pixels that stand out from the tile (bright and pale); on a sprite, everything inside.
    const glyph = new Uint8Array(n);
    let glyphCount = 0;
    for (let i = 0; i < n; i++) {
      if (!mask[i]) continue;
      const o = i * 4, [, s] = hsv(px[o], px[o + 1], px[o + 2]);
      const g = badge ? (lum[i] > 190 && s < 0.35 && inside[i] >= 3) : inside[i] >= 1;
      if (g) { glyph[i] = 1; glyphCount++; }
    }
    // Sparkle anchors: local brightness peaks DEEP inside (never the tile's own border highlight), kept apart.
    const order = [];
    for (let i = 0; i < n; i++) if (mask[i] && inside[i] >= (badge ? 4 : 2)) order.push(i);
    order.sort((a, b) => lum[b] - lum[a] || a - b);
    const points = [];
    for (const i of order) {
      const x = i % size, y = (i / size) | 0;
      if (points.every((p) => Math.abs(p[0] - x) + Math.abs(p[1] - y) >= size / 4)) points.push([x, y]);
      if (points.length >= 3) break;
    }
    let tr = 0, tg = 0, tb = 0, tn = 0;
    for (let i = 0; i < n; i++) if (mask[i] && !glyph[i]) { tr += px[i * 4]; tg += px[i * 4 + 1]; tb += px[i * 4 + 2]; tn++; }
    const d = Math.max(1, opaque);
    return { size, mask, rim, inside, glyph, glyphCount, badge, lum, opaque, coverage: opaque / n, warm: warm / d, cool: cool / d, sat: satSum / d, lumMean: lumSum / d, points,
      tint: tn ? [tr / tn, tg / tn, tb / tn] : [120, 160, 220] };
  }

  // ------------------------------------------------------------------ choosing the effect

  const ELEMENT_WORDS = [
    [/fire|flame|burn|blaze|heat|inferno|ember|炎|火/i, 'flicker'],
    [/thunder|lightning|spark|electric|storm|bolt|雷/i, 'twinkle'],
    [/ice|frost|cold|snow|freez|氷/i, 'glint'],
    [/water|aqua|sea|wave|水/i, 'bubble'],
    [/light|holy|sacred|sun|radian|光/i, 'pulse'],
    [/dark|shadow|curse|void|death|闇/i, 'pulse'],
  ];

  /**
   * One effect per icon, decided by the DATABASE first (what the thing is) and the pixels second.
   * A <Living Icon: effect> note always wins; <Living Icon: none> switches an icon off.
   * @param {object} e { kind:'weapon'|'armor'|'item'|'skill', etypeId, itypeId, elementName, recovers, note, price }
   * @param {object} read readIcon() of the icon
   * @returns {string} one of EFFECTS
   */
  function chooseEffect(e, read) {
    const m = String((e && e.note) || '').match(/<\s*living\s+icon\s*:\s*([a-z]+)\s*>/i);
    if (m && EFFECTS.indexOf(m[1].toLowerCase()) >= 0) return m[1].toLowerCase();
    if (!e || !read || read.opaque < 12) return 'none';
    const byElement = () => { for (const [re, fx] of ELEMENT_WORDS) if (re.test(String(e.elementName || ''))) return fx; return null; };
    switch (e.kind) {
      case 'skill': return byElement() || 'none';
      case 'weapon': return byElement() === 'flicker' ? 'flicker' : 'glint';
      case 'armor':
        if (e.etypeId === 5) return 'twinkle';            // accessories: rings, amulets
        return read.sat < 0.45 ? 'glint' : 'none';         // metal reads desaturated; cloth does not glint
      case 'item':
        if (e.recovers) return 'bubble';
        if (e.itypeId === 2) return 'pulse';                // key items
        return 'none';
      default: return 'none';
    }
  }

  /** 0..3 from price against the database's own spread (the top quarter shines hardest). */
  function tierOf(price, sortedPrices) {
    if (!sortedPrices || !sortedPrices.length || !(price > 0)) return 1;
    let below = 0;
    for (const p of sortedPrices) if (p < price) below++;
    const q = below / sortedPrices.length;
    return q >= 0.75 ? 3 : q >= 0.4 ? 2 : 1;
  }

  // ------------------------------------------------------------------ baking frames

  const clamp255 = (v) => (v < 0 ? 0 : v > 255 ? 255 : v | 0);
  function lighten(out, o, k) { out[o] = clamp255(out[o] + (255 - out[o]) * k); out[o + 1] = clamp255(out[o + 1] + (255 - out[o + 1]) * k); out[o + 2] = clamp255(out[o + 2] + (255 - out[o + 2]) * k); }
  function setPx(out, size, x, y, r, g, b, a) {
    if (x < 0 || y < 0 || x >= size || y >= size) return;
    const o = (y * size + x) * 4;
    const t = a / 255, ia = out[o + 3] / 255;
    const oa = t + ia * (1 - t);
    if (oa <= 0) return;
    out[o] = clamp255((r * t + out[o] * ia * (1 - t)) / oa);
    out[o + 1] = clamp255((g * t + out[o + 1] * ia * (1 - t)) / oa);
    out[o + 2] = clamp255((b * t + out[o + 2] * ia * (1 - t)) / oa);
    out[o + 3] = clamp255(oa * 255);
  }

  /** Where in its loop an effect is: 0..1 while playing, -1 while resting. */
  function activeT(f, start, len) {
    const d = (f - start + FRAMES) % FRAMES;
    return d < len ? d / (len - 1 || 1) : -1;
  }

  /**
   * Bakes FRAMES frames of one icon with its effect.
   * @returns {Uint8ClampedArray[]} FRAMES RGBA buffers, size x size each. Resting frames equal the icon exactly.
   */
  function bake(px, read, effect, tier, seed) {
    const size = read.size, n = size * size;
    const frames = [];
    const k = [0, 0.4, 0.55, 0.75][tier == null ? 1 : tier] || 0.55;
    for (let f = 0; f < FRAMES; f++) {
      const out = new Uint8ClampedArray(px);
      if (effect === 'glint') {
        // A narrow diagonal band of light sweeps across the opaque pixels, brighter where the icon is already bright.
        // The band has a 1 px white core so it reads even on a pale stone or a white glyph, where lightening alone shows nothing.
        const t = activeT(f, 0, 16);
        if (t >= 0) {
          const pos = -6 + t * (2 * size + 12), w = 3.5;
          for (let i = 0; i < n; i++) {
            if (!read.mask[i]) continue;
            const x = i % size, y = (i / size) | 0;
            const d = Math.abs((x + y) - pos);
            if (d < 0.75 && !read.rim[i]) setPx(out, size, x, y, 255, 255, 255, 255 * Math.min(1, 0.55 + k * 0.6));
            else if (d < w) lighten(out, i * 4, k * (1 - d / w) * (0.6 + 0.4 * read.lum[i] / 255));
          }
        }
      } else if (effect === 'twinkle') {
        // Four-point stars open and close on the icon's own brightest points, one after another.
        read.points.forEach((p, s) => {
          const t = activeT(f, (s * 9 + (seed % 7)) % FRAMES, 10);
          if (t < 0) return;
          const r = Math.round((t < 0.5 ? t * 2 : (1 - t) * 2) * (1 + tier));
          const a = 255 * Math.min(1, 0.35 + k);
          setPx(out, size, p[0], p[1], 255, 255, 255, a);
          for (let q = 1; q <= r; q++) {
            const fade = a * (1 - q / (r + 1));
            setPx(out, size, p[0] + q, p[1], 255, 250, 230, fade); setPx(out, size, p[0] - q, p[1], 255, 250, 230, fade);
            setPx(out, size, p[0], p[1] + q, 255, 250, 230, fade); setPx(out, size, p[0], p[1] - q, 255, 250, 230, fade);
          }
        });
      } else if (effect === 'bubble') {
        // Bubbles rise through the coloured (non-white) body of the icon and vanish at its top.
        // The liquid: on a sprite icon, its saturated body; on a badge, the pale glyph, where a bubble is a tinted dot.
        const inLiquid = (i) => {
          if (!read.mask[i] || read.rim[i]) return false;
          if (read.badge) return read.glyph[i] === 1;
          const o = i * 4, [, s, v] = hsv(px[o], px[o + 1], px[o + 2]);
          return s >= 0.3 && v >= 0.25 && read.inside[i] >= 2;
        };
        let minY = size, maxY = -1, minX = size, maxX = -1;
        for (let i = 0; i < n; i++) {
          if (!inLiquid(i)) continue;
          const x = i % size, y = (i / size) | 0;
          if (y < minY) minY = y; if (y > maxY) maxY = y; if (x < minX) minX = x; if (x > maxX) maxX = x;
        }
        const tint = read.tint;
        const mark = (i, strength) => {
          if (read.badge) setPx(out, size, i % size, (i / size) | 0, tint[0] * 0.75 + 40, tint[1] * 0.75 + 40, tint[2] * 0.75 + 40, 255 * strength);
          else lighten(out, i * 4, 0.7 * strength);
        };
        if (maxY > minY + 3) {
          for (let b = 0; b < 3; b++) {
            const h = hash2(seed + b, 77);
            const period = 20 + (h % 9), start = (h >>> 8) % FRAMES;
            const t = ((f - start + FRAMES * 4) % period) / period;
            if (t > 0.85) continue;
            const x = minX + 1 + ((h >>> 4) % Math.max(1, maxX - minX - 1));
            const y = Math.round(maxY - t * (maxY - minY));
            const i = y * size + x;
            if (!inLiquid(i)) continue;
            mark(i, 1);
            if (b === 0 && t > 0.3 && inLiquid(i - 1)) mark(i - 1, 0.5);
          }
        }
      } else if (effect === 'flicker') {
        // Warm pixels breathe in brightness on a slow hashed curve; two embers rise from the hottest top edge.
        // Warm pixels breathe toward a hotter yellow (not just lighter), on a slow curve.
        const wobble = (Math.sin((f / FRAMES) * Math.PI * 6) * 0.5 + 0.5) * 0.3 * (0.5 + k);
        for (let i = 0; i < n; i++) {
          if (!read.mask[i]) continue;
          const o = i * 4, [hh, s, v] = hsv(px[o], px[o + 1], px[o + 2]);
          if (s > 0.3 && v > 0.3 && (hh < 50 || hh > 330)) {
            out[o] = clamp255(out[o] + (255 - out[o]) * wobble);
            out[o + 1] = clamp255(out[o + 1] + (210 - out[o + 1]) * wobble * 0.9);
            out[o + 2] = clamp255(out[o + 2] + (90 - out[o + 2]) * wobble * 0.5);
          }
        }
        // Embers leave from the top of the WARM region (the flame), never from the tile's border.
        let topY = size, topX = size >> 1;
        for (let i = 0; i < n; i++) {
          if (!read.mask[i] || read.inside[i] < 2) continue;
          const o = i * 4, [hh, s, v] = hsv(px[o], px[o + 1], px[o + 2]);
          if (!(s > 0.35 && v > 0.35 && (hh < 50 || hh > 340))) continue;
          const y = (i / size) | 0; if (y < topY) { topY = y; topX = i % size; }
        }
        if (topY === size) topY = size >> 1;
        for (let e = 0; e < 3; e++) {
          const t = activeT(f, (e * 16 + seed) % FRAMES, 18);
          if (t < 0) continue;
          const x = topX + (e - 1) * 3 + Math.round(Math.sin(t * 6 + e) * 1.2);
          const y = Math.round(topY + 3 - t * 11);
          const a = 255 * (1 - t * 0.85);
          setPx(out, size, x, y, 255, 220 - t * 100, 90, a);
          if (t < 0.5) setPx(out, size, x, y + 1, 255, 150, 60, a * 0.6);
        }
      } else if (effect === 'pulse') {
        // The rim brightens and fades once per loop, in the icon's own colour lifted toward white.
        // A 1 px halo just OUTSIDE the icon rises and fades in a warm gold, so it shows on pale art as well as dark;
        // the rim itself lifts with it. On a badge (which fills its square) only the rim can move.
        const t = activeT(f, seed % FRAMES, 22);
        if (t >= 0) {
          const a = Math.sin(t * Math.PI);
          for (let i = 0; i < n; i++) if (read.rim[i]) lighten(out, i * 4, a * k * 0.8);
          if (!read.badge) {
            for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
              const i = y * size + x;
              if (read.mask[i]) continue;
              if ((x > 0 && read.mask[i - 1]) || (x < size - 1 && read.mask[i + 1]) || (y > 0 && read.mask[i - size]) || (y < size - 1 && read.mask[i + size])) setPx(out, size, x, y, 255, 214, 120, 255 * a * (0.35 + k * 0.5));
            }
          }
        }
      }
      frames.push(out);
    }
    return frames;
  }

  /** Phase offset in frames so a list of identical icons never moves in step. */
  function phaseOf(iconIndex, slot) { return hash2(iconIndex, slot | 0) % FRAMES; }

  /** How many of the baked frames differ from the still icon (the loop's "playing" share). */
  function activeFrames(px, frames) {
    let c = 0;
    for (const fr of frames) { for (let i = 0; i < fr.length; i++) if (fr[i] !== px[i]) { c++; break; } }
    return c;
  }

  const LivingIconsCore = { VERSION, EFFECTS, FRAMES, hashString, hash2, hsv, readIcon, chooseEffect, tierOf, bake, phaseOf, activeFrames };
  if (typeof module !== 'undefined' && module.exports) module.exports = LivingIconsCore;
  root.LivingIconsCore = LivingIconsCore;
})(typeof window !== 'undefined' ? window : globalThis);
