//=============================================================================
// Quizmaster.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Quizmaster 3/3 - quiz shows and exams for MZ, the questions written from your own database.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * Quizmaster
 * ============================================================================
 *
 * A quiz for your game, WRITTEN FROM YOUR OWN DATABASE: what an item costs,
 * which element a skill is, which class learns it, which state it inflicts,
 * which enemy is toughest, what an enemy drops. A question is only asked when
 * exactly one answer is right in your data; blanks, dividers, shared names
 * and ties are never asked. Every question card pictures its subject with
 * your own art: the item's icon, the enemy's image, the actor's face.
 *
 * Two modes: a QUIZ SHOW against up to three rivals on podiums, and an EXAM
 * the player sits alone, marked against a pass mark. Six stages are drawn by
 * the plugin: game show, classroom, tavern, arcane, royal court and carnival.
 *
 * ----------------------------------------------------------------------------
 * INSTALLING
 * ----------------------------------------------------------------------------
 * Copy QuizmasterCore.js, QuizmasterDraw.js and Quizmaster.js into js/plugins
 * and enable all three. Any order works.
 *
 * ----------------------------------------------------------------------------
 * USING IT
 * ----------------------------------------------------------------------------
 * Add the plugin command "Start Quiz" to an event. The event waits while the
 * quiz runs. Results go to the variables and switch you choose.
 *
 * CONTROLS: arrow keys choose an answer, OK locks it in; or click / tap an
 * answer. On the results, OK or a click leaves.
 *
 * ----------------------------------------------------------------------------
 * COMPATIBILITY
 * ----------------------------------------------------------------------------
 * Quizmaster adds its own scene and replaces nothing. It extends two engine
 * methods, each by saving the original and calling it: Game_System.initialize
 * (its save record) and Game_Interpreter.updateWaitMode (so the event waits
 * while the quiz runs).
 *
 * ============================================================================
 * TERMS OF USE
 * ============================================================================
 * Commercial and non-commercial use permitted in RPG Maker projects, credit
 * appreciated but not required. Do not redistribute the source as an asset
 * pack. Every line of this plugin was written with AI assistance.
 * ============================================================================
 *
 * @param rightSe
 * @text Sound: a right answer
 * @type file
 * @dir audio/se
 * @default Chime2
 *
 * @param wrongSe
 * @text Sound: a wrong answer
 * @type file
 * @dir audio/se
 * @default Buzzer1
 *
 * @param pickSe
 * @text Sound: choosing
 * @type file
 * @dir audio/se
 * @default Cursor1
 *
 * @command quiz
 * @text Start Quiz
 * @desc Run a quiz written from your database. The event waits until it is over.
 *
 * @arg mode
 * @text Mode
 * @type select
 * @option show
 * @option exam
 * @default show
 *
 * @arg questions
 * @text Questions
 * @type number
 * @min 3
 * @max 20
 * @default 6
 *
 * @arg seconds
 * @text Seconds per question
 * @type number
 * @min 5
 * @max 30
 * @default 12
 *
 * @arg theme
 * @text Stage
 * @type select
 * @option auto
 * @option gameshow
 * @option classroom
 * @option tavern
 * @option arcane
 * @option court
 * @option carnival
 * @default auto
 *
 * @arg rivals
 * @text Rivals (quiz show)
 * @type number
 * @min 0
 * @max 3
 * @default 3
 *
 * @arg rivalLevel
 * @text Rival level
 * @type select
 * @option mixed
 * @option novice
 * @option sharp
 * @option master
 * @default mixed
 *
 * @arg rivalActors
 * @text Rival actors (faces and names)
 * @type actor[]
 * @default []
 *
 * @arg passPercent
 * @text Exam pass mark (%)
 * @type number
 * @min 1
 * @max 100
 * @default 60
 *
 * @arg scoreVariable
 * @text Variable: score
 * @type variable
 * @default 0
 *
 * @arg rightVariable
 * @text Variable: right answers
 * @type variable
 * @default 0
 *
 * @arg placeVariable
 * @text Variable: place (quiz show)
 * @type variable
 * @default 0
 *
 * @arg wonSwitch
 * @text Switch: won or passed
 * @type switch
 * @default 0
 *
 * @arg goldPerPoint
 * @text Gold per point
 * @type number
 * @min 0
 * @default 0
 *
 * @arg seed
 * @text Seed (optional)
 * @desc Blank = new questions every time. A number or word = the same quiz every time.
 * @default
 */

var Quizmaster = Quizmaster || {};

(function (M) {
  'use strict';
  var NAME = 'Quizmaster', SCHEMA = 1;
  var raw = (typeof PluginManager !== 'undefined') ? PluginManager.parameters(NAME) : {};
  function num(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; var n = Number(v); return isFinite(n) ? n : d; }
  function str(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; return String(v).trim(); }
  function list(v) { try { var a = JSON.parse(v || '[]'); return Array.isArray(a) ? a.map(Number).filter(function (n) { return n > 0; }) : []; } catch (e) { return []; } }
  M.params = { rightSe: str(raw.rightSe, 'Chime2'), wrongSe: str(raw.wrongSe, 'Buzzer1'), pickSe: str(raw.pickSe, 'Cursor1') };
  var _deps = null;
  function deps() {
    if (_deps) return _deps;
    var core = (typeof QuizmasterCore !== 'undefined') ? QuizmasterCore : null, draw = (typeof QuizmasterDraw !== 'undefined') ? QuizmasterDraw : null;
    if (!core || !draw) { if (!deps._w) { deps._w = true; console.error('Quizmaster: enable QuizmasterCore.js and QuizmasterDraw.js in the Plugin Manager too.'); } return null; }
    _deps = { core: core, draw: draw }; return _deps;
  }
  M.deps = deps;
  function fresh() { return { v: SCHEMA, played: 0, won: 0, best: 0 }; }
  M.record = function () {
    if (typeof $gameSystem === 'undefined' || !$gameSystem) return fresh();
    var s = $gameSystem._csafQuizmaster; if (!s || s.v == null) { s = fresh(); $gameSystem._csafQuizmaster = s; } return s;
  };
  var _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () { _Game_System_initialize.call(this); this._csafQuizmaster = fresh(); };
  /** The database, as the core reads it. */
  M.database = function () { return { items: $dataItems, weapons: $dataWeapons, armors: $dataArmors, skills: $dataSkills, enemies: $dataEnemies, actors: $dataActors, classes: $dataClasses, states: $dataStates, system: $dataSystem }; };
  M.request = function (args) {
    var d = deps(); if (!d) return null; args = args || {};
    var seedText = str(args.seed, ''), seed = seedText === '' ? d.core.mix(d.core.hashString('quiz') ^ (M.record().played * 7919), (typeof $gameSystem !== 'undefined' && $gameSystem ? $gameSystem.playtime() : 0) >>> 0)
      : (/^\d+$/.test(seedText) ? (Number(seedText) >>> 0) : d.core.hashString(seedText));
    var mode = str(args.mode, 'show') === 'exam' ? 'exam' : 'show', theme = str(args.theme, 'auto'), level = str(args.rivalLevel, 'mixed');
    return { seed: seed, mode: mode, count: Math.max(3, Math.min(20, Math.floor(num(args.questions, 6)))), seconds: Math.max(5, Math.min(30, Math.floor(num(args.seconds, 12)))),
      theme: d.draw.THEMES.indexOf(theme) >= 0 ? theme : null, rivals: mode === 'exam' ? 0 : Math.max(0, Math.min(3, Math.floor(num(args.rivals, 3)))),
      levels: level === 'mixed' ? ['novice', 'sharp', 'master'] : [level, level, level], rivalActors: Array.isArray(args.rivalActors) ? args.rivalActors : list(args.rivalActors),
      pass: Math.max(1, Math.min(100, Math.floor(num(args.passPercent, 60)))), scoreVariable: Math.max(0, Math.floor(num(args.scoreVariable, 0))), rightVariable: Math.max(0, Math.floor(num(args.rightVariable, 0))),
      placeVariable: Math.max(0, Math.floor(num(args.placeVariable, 0))), wonSwitch: Math.max(0, Math.floor(num(args.wonSwitch, 0))), goldPerPoint: Math.max(0, Math.floor(num(args.goldPerPoint, 0))) };
  };
  M.start = function (opts) {
    var req = opts && opts.seed != null && opts.levels ? opts : M.request(opts || {});
    if (!req) return false;
    // a database too sparse to write one sound question starts nothing (and says so once) rather than an empty quiz
    if (!deps().core.bank(M.database(), req.seed).length) { if (!M._warnedEmpty) { M._warnedEmpty = true; console.warn('Quizmaster: your database has no facts a question can be written from (named items with prices, skills, enemies...). No quiz started.'); } return false; }
    SceneManager.push(Scene_Quizmaster); SceneManager.prepareNextScene(req); return true;
  };
  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) PluginManager.registerCommand(NAME, 'quiz', function (args) { if (M.start(M.request(args))) this.setWaitMode('quizmaster'); });
  var _updateWaitMode = Game_Interpreter.prototype.updateWaitMode;
  Game_Interpreter.prototype.updateWaitMode = function () {
    if (this._waitMode === 'quizmaster') { if (SceneManager._scene instanceof Scene_Quizmaster || SceneManager._nextScene instanceof Scene_Quizmaster) return true; this._waitMode = ''; return false; }
    return _updateWaitMode.call(this);
  };
  M.VERSION = '1.0.0';
}(Quizmaster));

//=============================================================================
// Scene_Quizmaster
//=============================================================================

function Scene_Quizmaster() { this.initialize.apply(this, arguments); }
Scene_Quizmaster.prototype = Object.create(Scene_Message.prototype);
Scene_Quizmaster.prototype.constructor = Scene_Quizmaster;
Scene_Quizmaster.REVEAL = 80;     // frames the answer is shown
Scene_Quizmaster.CARD = { x: 28, y: 40, w: 690, h: 190 };
Scene_Quizmaster.TIMER = { x: 768, y: 70, r: 34 };   // clear of the card's corner (contact sheet 2026-10-08)
Scene_Quizmaster.prototype.prepare = function (req) { this._req = req; };

Scene_Quizmaster.prototype.create = function () {
  Scene_Message.prototype.create.call(this);
  var d = Quizmaster.deps(), req = this._req, C = d.core;
  this._d = d;
  var bank = C.balanced(C.bank(Quizmaster.database(), req.seed), req.seed);
  var leader = $gameParty.leader(), people = [{ name: leader ? leader.name() : 'You', ai: 'player', actor: leader }];
  for (var i = 0; i < req.rivals; i++) { var a = req.rivalActors[i] ? $gameActors.actor(req.rivalActors[i]) : null; people.push({ name: a ? a.name() : ['Ada', 'Bertram', 'Cosima'][i], ai: req.levels[i], actor: a }); }
  this._actors = people.map(function (p) { return p.actor || null; });
  this._quiz = C.createQuiz(bank, people, C.mix(req.seed, 0x9A), { count: req.count, seconds: req.seconds });
  this._theme = req.theme || d.draw.THEMES[req.seed % d.draw.THEMES.length];
  // everything a card can picture is loaded before the scene starts (Scene_Base.isReady waits on ImageManager)
  ImageManager.loadSystem('IconSet');
  this._quiz.questions.forEach(function (q) { if (q.subject.battler) ImageManager.loadEnemy(q.subject.battler); if (q.subject.face) ImageManager.loadFace(q.subject.face); });
  this._actors.forEach(function (a) { if (a && a.faceName()) ImageManager.loadFace(a.faceName()); });
  this._layer = new Sprite(); this.addChild(this._layer);
  this.createWindowLayer(); this.createAllWindows();
  this._mode = 'loading'; this._t = 0; this._sel = 0; this._shownTimer = -1; this._history = [];
};
Scene_Quizmaster.prototype.start = function () {
  Scene_Message.prototype.start.call(this);
  var D = this._d.draw, W = Graphics.width, H = Graphics.height, bmp = new Bitmap(W, H);
  D.backdrop(bmp.context, W, H, this._theme); bmp._baseTexture.update();
  this._layer.addChild(new Sprite(bmp));
  this._card = new Sprite(new Bitmap(W, 260)); this._layer.addChild(this._card);
  this._tiles = [];
  for (var i = 0; i < 4; i++) { var s = new Sprite(new Bitmap(370, 60)); s.x = 28 + (i % 2) * 384; s.y = 262 + Math.floor(i / 2) * 70; this._layer.addChild(s); this._tiles.push(s); }
  this._timer = new Sprite(new Bitmap(80, 80)); this._timer.x = Scene_Quizmaster.TIMER.x - 40; this._timer.y = Scene_Quizmaster.TIMER.y - 40; this._layer.addChild(this._timer);
  this._podiums = new Sprite(new Bitmap(W, 170)); this._podiums.y = H - 170; this._layer.addChild(this._podiums);
  this._results = new Sprite(); this._results.visible = false; this._layer.addChild(this._results);
  this.ask(); this.startFadeIn(this.fadeSpeed(), false);
};

/** The card's picture: the subject drawn from the buyer's own art, or the answer's element mark for an element question. */
Scene_Quizmaster.prototype.picture = function (q) {
  var D = this._d.draw, s = q.subject;
  return function (g, x, y, size) {
    if (q.template === 'skillElement' || q.template === 'weakness') {
      if (s.battler) { var eb = ImageManager.loadEnemy(s.battler), k = Math.min(size / eb.width, size / eb.height); g.drawImage(eb._canvas || eb._image, x + (size - eb.width * k) / 2, y + (size - eb.height * k) / 2, eb.width * k, eb.height * k); return; }
    }
    if (s.icon != null && s.icon > 0) {
      var ic = ImageManager.loadSystem('IconSet'), pw = ImageManager.iconWidth, ph = ImageManager.iconHeight;
      g.imageSmoothingEnabled = false; g.drawImage(ic._canvas || ic._image, (s.icon % 16) * pw, Math.floor(s.icon / 16) * ph, pw, ph, x + size * 0.15, y + size * 0.15, size * 0.7, size * 0.7); g.imageSmoothingEnabled = true; return;
    }
    if (s.battler) { var b = ImageManager.loadEnemy(s.battler), k2 = Math.min(size / b.width, size / b.height); g.drawImage(b._canvas || b._image, x + (size - b.width * k2) / 2, y + (size - b.height * k2) / 2, b.width * k2, b.height * k2); return; }
    if (s.face) { var f = ImageManager.loadFace(s.face), fw = ImageManager.faceWidth, fh = ImageManager.faceHeight, fi = s.faceIndex || 0; g.drawImage(f._canvas || f._image, (fi % 4) * fw, Math.floor(fi / 4) * fh, fw, fh, x, y, size, size); return; }
    D.elementMark(g, x + size / 2, y + size / 2, size * 0.42, q.answer);
  };
};
Scene_Quizmaster.prototype.isElement = function (q) { return q.template === 'skillElement' || q.template === 'weakness'; };
Scene_Quizmaster.prototype.ask = function () {
  var D = this._d.draw, q = this._d.core.current(this._quiz), b = this._card.bitmap, C = Scene_Quizmaster.CARD;
  b.clear(); this._cardInfo = D.card(b.context, C.x, C.y, C.w, C.h, q, this._theme, this.picture(q)); b._baseTexture.update();
  this._sel = 0; this._picked = -1; this.drawTiles(null); this.drawPodiums(null);
  this._mode = 'ask'; this._t = 0; this._shownTimer = -1;
};
Scene_Quizmaster.prototype.drawTiles = function (reveal) {
  var D = this._d.draw, q = this._d.core.current(this._quiz), L = ['A', 'B', 'C', 'D'];
  for (var i = 0; i < 4; i++) {
    var b = this._tiles[i].bitmap, st = 'idle';
    if (reveal) st = q.choices[i] === q.answer ? 'right' : (i === this._picked ? 'wrong' : 'idle');
    else if (i === this._sel) st = 'chosen';
    b.clear(); D.tile(b.context, 2, 2, 362, 52, L[i], q.choices[i], st, this._theme, this.isElement(q)); b._baseTexture.update();
  }
};
Scene_Quizmaster.prototype.drawPodiums = function (results) {
  var D = this._d.draw, b = this._podiums.bitmap, g = b.context, ps = this._quiz.people, n = ps.length, W = Graphics.width, self = this;
  b.clear();
  if (this._req.mode === 'exam') {
    // the exam's progress strip: one pip per question (right, wrong, the current one, still to come) on a dark plate, so
    // the ink reads on all six stages (2026-10-08: the exam left this band empty but for one line of text)
    var qn = this._quiz.questions.length, pitch = Math.min(46, (W - 160) / qn), pw = pitch * qn + 60, x0 = W / 2 - pitch * (qn - 1) / 2, cur = this._quiz.index, acc = D.STAGE[this._theme].accent;
    g.fillStyle = 'rgba(12,8,10,0.62)'; D.roundRect(g, W / 2 - pw / 2, 18, pw, 128, 14); g.fill();
    for (var k = 0; k < qn; k++) {
      var h = this._history[k]; g.beginPath(); g.arc(x0 + k * pitch, 60, Math.min(14, pitch * 0.32), 0, Math.PI * 2);
      if (h === true || h === false) { g.fillStyle = h ? '#3f9e5a' : '#b8392f'; g.fill(); g.lineWidth = 2.5; g.strokeStyle = '#fff6e0'; g.stroke(); }
      else { g.lineWidth = k === cur ? 4 : 2.5; g.strokeStyle = k === cur ? acc : 'rgba(255,246,224,0.35)'; g.stroke(); }
    }
    D.text(g, 'EXAM  ' + Math.min(qn, cur + 1) + ' / ' + qn + '    right so far: ' + ps[0].right, W / 2, 114, 22, '#fff6e0', 'center', '700');
  } else ps.forEach(function (p, i) {
    var a = self._actors[i], faceFn = null;
    if (a && a.faceName()) { var f = ImageManager.loadFace(a.faceName()), fi = a.faceIndex(), fw = ImageManager.faceWidth, fh = ImageManager.faceHeight; faceFn = function (gg, x, y, r) { gg.drawImage(f._canvas || f._image, (fi % 4) * fw, Math.floor(fi / 4) * fh, fw, fh, x - r, y - r, r * 2, r * 2); }; }
    var lit = !!(results && results[i] && results[i].right);
    D.podium(g, W * (i + 0.5) / n, 64, 110, self._theme, p.name, p.score, lit, faceFn);
  });
  b._baseTexture.update();
};
Scene_Quizmaster.prototype.drawTimer = function (left) {
  var k = Math.round(left * 40);
  if (k === this._shownTimer) return;                 // a redraw (and a texture upload) only when the ring visibly moves
  this._shownTimer = k;
  var b = this._timer.bitmap; b.clear(); this._d.draw.timer(b.context, 40, 40, Scene_Quizmaster.TIMER.r, k / 40, this._theme); b._baseTexture.update();
};

Scene_Quizmaster.prototype.update = function () {
  Scene_Message.prototype.update.call(this);
  if (this._mode === 'loading' || this.isBusy()) return;
  this._t++;
  if (this._mode === 'ask') this.updateAsk();
  else if (this._mode === 'reveal' && this._t >= Scene_Quizmaster.REVEAL) { if (this._d.core.next(this._quiz) === 'done') this.showResults(); else this.ask(); }
  else if (this._mode === 'results' && this._t > 30 && (Input.isTriggered('ok') || TouchInput.isTriggered())) this.leave();
};
Scene_Quizmaster.prototype.updateAsk = function () {
  var total = this._quiz.time * 60, left = Math.max(0, 1 - this._t / total);
  this.drawTimer(left);
  var moved = -1;
  if (Input.isTriggered('right') || Input.isTriggered('left')) moved = this._sel ^ 1;
  if (Input.isTriggered('down') || Input.isTriggered('up')) moved = this._sel ^ 2;
  if (moved >= 0) { this._sel = moved; this.drawTiles(null); AudioManager.playSe({ name: Quizmaster.params.pickSe, volume: 80, pitch: 100, pan: 0 }); }
  var pick = -1;
  if (TouchInput.isTriggered()) for (var i = 0; i < 4; i++) { var s = this._tiles[i]; if (TouchInput.x >= s.x && TouchInput.x < s.x + 366 && TouchInput.y >= s.y && TouchInput.y < s.y + 56) pick = i; }
  if (Input.isTriggered('ok')) pick = this._sel;
  if (pick < 0 && left > 0) return;
  this.settle(pick, left);
};
Scene_Quizmaster.prototype.settle = function (pick, left) {
  var q = this._d.core.current(this._quiz);
  this._picked = pick; var res = this._d.core.answer(this._quiz, pick >= 0 ? q.choices[pick] : null, left);
  this._history.push(!!res[0].right);
  this.drawTiles(true); this.drawPodiums(res);
  AudioManager.playSe({ name: res[0].right ? Quizmaster.params.rightSe : Quizmaster.params.wrongSe, volume: 85, pitch: 100, pan: 0 });
  this._mode = 'reveal'; this._t = 0;
};
Scene_Quizmaster.prototype.showResults = function () {
  var D = this._d.draw, C = this._d.core, res = C.results(this._quiz), W = Graphics.width, H = Graphics.height, req = this._req;
  var me = res.filter(function (r) { return r.who === 0; })[0], n = this._quiz.questions.length;
  this._mine = { score: me.score, right: me.right, place: me.place, won: req.mode === 'exam' ? (100 * me.right / n >= req.pass) : me.place === 1 };
  var bmp = new Bitmap(W, H), g = bmp.context, pw = 460, ph = req.mode === 'exam' ? 260 : 130 + res.length * 56, px = (W - pw) / 2, py = (H - ph) / 2 - 20;
  g.fillStyle = 'rgba(10,8,6,0.55)'; g.fillRect(0, 0, W, H);
  g.fillStyle = '#f6efdf'; D.roundRect(g, px, py, pw, ph, 14); g.fill(); g.strokeStyle = D.STAGE[this._theme].trim; g.lineWidth = 4; D.roundRect(g, px + 2, py + 2, pw - 4, ph - 4, 12); g.stroke();
  D.text(g, D.STAGE[this._theme].name, W / 2, py + 40, 28, '#2a1d14', 'center', '700');
  if (req.mode === 'exam') {
    D.text(g, me.right + ' / ' + n, W / 2, py + 120, 56, '#2a1d14', 'center', '700');
    D.text(g, this._mine.won ? 'PASSED' : 'NOT YET', W / 2, py + 190, 30, this._mine.won ? '#2f7a43' : '#a3352d', 'center', '700');
  } else res.forEach(function (r, i) { var y = py + 96 + i * 56; D.text(g, ['1st', '2nd', '3rd', '4th'][i], px + 40, y, 24, i === 0 ? '#9a6a12' : '#4a321b', 'left', '700'); D.text(g, r.name, px + 130, y, 22, '#2a1d14', 'left', '700'); D.text(g, r.score + ' pts', px + pw - 40, y, 20, '#2a1d14', 'right', '700'); });
  D.text(g, 'OK to leave', W / 2, py + ph - 24, 15, '#6a4e2e', 'center', '600');
  bmp._baseTexture.update(); this._results.bitmap = bmp; this._results.visible = true;
  this._mode = 'results'; this._t = 0;
};
Scene_Quizmaster.prototype.leave = function () {
  var req = this._req, m = this._mine, rec = Quizmaster.record();
  if (req.scoreVariable > 0) $gameVariables.setValue(req.scoreVariable, m.score);
  if (req.rightVariable > 0) $gameVariables.setValue(req.rightVariable, m.right);
  if (req.placeVariable > 0 && req.mode === 'show') $gameVariables.setValue(req.placeVariable, m.place);
  if (req.wonSwitch > 0) $gameSwitches.setValue(req.wonSwitch, m.won);
  if (req.goldPerPoint > 0) $gameParty.gainGold(m.score * req.goldPerPoint);
  rec.played++; if (m.won) rec.won++; rec.best = Math.max(rec.best, m.score);
  this.popScene();
};
Scene_Quizmaster.prototype.stop = function () { Scene_Message.prototype.stop.call(this); this.startFadeOut(this.fadeSpeed(), false); };
