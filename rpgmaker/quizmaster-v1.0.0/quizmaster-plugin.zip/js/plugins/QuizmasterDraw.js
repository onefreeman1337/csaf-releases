//=============================================================================
// QuizmasterDraw.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Quizmaster 2/3 - the drawing kit: stages, question cards, answer tiles, timer, marks. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The drawing kit for Quizmaster. No parameters or commands of its own. It
 * knows nothing about RPG Maker: it draws on a canvas 2D context. The only
 * pictures it does not draw are the ones your database already names (an
 * icon, an enemy's image, an actor's face), which the scene hands it.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var QuizmasterDraw = (function () {
  'use strict';
  var TAU = Math.PI * 2;
  var FONT = '"Palatino Linotype", "Book Antiqua", Palatino, Georgia, serif';

  function hex(c) { var n = parseInt(c.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  function toHex(rgb) { return '#' + rgb.map(function (v) { var s = Math.max(0, Math.min(255, Math.round(v))).toString(16); return s.length < 2 ? '0' + s : s; }).join(''); }
  function shade(c, k) { return toHex(hex(c).map(function (v) { return k >= 0 ? v + (255 - v) * k : v * (1 + k); })); }
  function rgba(c, a) { var h = hex(c); return 'rgba(' + h[0] + ',' + h[1] + ',' + h[2] + ',' + a + ')'; }
  function lum(c) { var h = hex(c).map(function (v) { v /= 255; return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * h[0] + 0.7152 * h[1] + 0.0722 * h[2]; }
  function contrast(a, b) { var x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); }
  function pickInk(bg, inks) { var best = inks[0], bc = 0; inks.forEach(function (c) { var k = contrast(bg, c); if (k > bc) { bc = k; best = c; } }); return best; }
  function roundRect(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
  function text(g, s, x, y, size, color, align, weight) { g.font = (weight || '700') + ' ' + size + 'px ' + FONT; g.fillStyle = color; g.textAlign = align || 'left'; g.textBaseline = 'middle'; g.fillText(s, x, y); }
  /** Wrap `s` into lines no wider than w at `size`; shrinks the size until it fits `maxLines` (Icon_Doctrine §22f: a fitter that cannot fit must say so). */
  function wrap(g, s, w, size, maxLines, weight) {
    for (var sz = size; sz >= 12; sz--) {
      g.font = (weight || '700') + ' ' + sz + 'px ' + FONT;
      var words = String(s).split(/\s+/), lines = [], cur = '';
      for (var i = 0; i < words.length; i++) { var t = cur ? cur + ' ' + words[i] : words[i]; if (g.measureText(t).width > w && cur) { lines.push(cur); cur = words[i]; } else cur = t; }
      if (cur) lines.push(cur);
      if (lines.length <= maxLines && lines.every(function (l) { return g.measureText(l).width <= w; })) return { lines: lines, size: sz, squeezed: sz < size };
    }
    return { lines: [String(s)], size: 12, squeezed: true, overflow: true };
  }

  /* ---------------------------------------------------------------- stages */

  var STAGE = {
    gameshow: { name: 'Game Show', back: '#3a1030', back2: '#6e1d4f', accent: '#f6c440', board: '#14223f', ink: '#fff6e0', trim: '#f6c440' },
    classroom: { name: 'Classroom', back: '#36543f', back2: '#2a4232', accent: '#e8e2cf', board: '#2f4a39', ink: '#f4f1e6', trim: '#9a6b3c' },
    tavern: { name: 'Tavern Trivia', back: '#3b2617', back2: '#5a3a22', accent: '#e9a23b', board: '#262019', ink: '#f6e9cf', trim: '#b07a3e' },
    arcane: { name: 'Arcane Exam', back: '#151a3a', back2: '#2a2f66', accent: '#8fd6ff', board: '#0f1230', ink: '#e8f3ff', trim: '#8f7dff' },
    court: { name: 'Royal Court', back: '#e6dfd2', back2: '#c9bda7', accent: '#a5232f', board: '#f6f1e6', ink: '#2a1d14', trim: '#b8913f' },
    carnival: { name: 'Carnival', back: '#f3e3c3', back2: '#d84a3a', accent: '#2a77c9', board: '#fff8e8', ink: '#2a1d14', trim: '#d84a3a' },
  };
  var THEMES = Object.keys(STAGE);

  /** The backdrop of a theme, filling W x H: each a different place, never a recolour (wing §21a). Returns the board rect. */
  function backdrop(g, W, H, theme) {
    var T = STAGE[theme] || STAGE.gameshow, i;
    var bg = g.createLinearGradient(0, 0, 0, H); bg.addColorStop(0, T.back2); bg.addColorStop(1, T.back); g.fillStyle = bg; g.fillRect(0, 0, W, H);
    if (theme === 'gameshow') {                              // velvet folds and a marquee of bulbs
      for (i = 0; i < W; i += 46) { var fg = g.createLinearGradient(i, 0, i + 46, 0); fg.addColorStop(0, rgba('#000000', 0.25)); fg.addColorStop(0.5, rgba('#ffffff', 0.06)); fg.addColorStop(1, rgba('#000000', 0.25)); g.fillStyle = fg; g.fillRect(i, 0, 46, H * 0.7); }
      for (i = 22; i < W; i += 34) { g.fillStyle = (i / 34) % 2 < 1 ? '#fff3b0' : '#f6c440'; g.beginPath(); g.arc(i, 18, 6, 0, TAU); g.fill(); g.fillStyle = rgba('#fff3b0', 0.25); g.beginPath(); g.arc(i, 18, 12, 0, TAU); g.fill(); }
    } else if (theme === 'classroom') {                       // a wall, a wooden rail, chalk dust
      g.fillStyle = '#c9b48a'; g.fillRect(0, 0, W, H * 0.12); g.fillStyle = T.trim; g.fillRect(0, H * 0.12, W, 10);
      g.fillStyle = rgba('#ffffff', 0.05); for (i = 0; i < 300; i++) g.fillRect((i * 7919) % W, H * 0.15 + (i * 104729) % (H * 0.5), 2, 1);
    } else if (theme === 'tavern') {                          // timber beams and candlelight
      for (i = 0; i < W; i += 160) { g.fillStyle = shade(T.back2, -0.2); g.fillRect(i, 0, 18, H * 0.75); }
      g.fillStyle = shade(T.back2, -0.3); g.fillRect(0, 26, W, 16);
      var cg = g.createRadialGradient(W * 0.15, H * 0.3, 4, W * 0.15, H * 0.3, 160); cg.addColorStop(0, rgba('#ffc96b', 0.45)); cg.addColorStop(1, rgba('#ffc96b', 0)); g.fillStyle = cg; g.fillRect(0, 0, W, H);
    } else if (theme === 'arcane') {                          // a starfield and a rune circle
      for (i = 0; i < 160; i++) { g.fillStyle = rgba('#ffffff', 0.3 + (i % 5) * 0.12); g.fillRect((i * 7919) % W, (i * 104729) % (H * 0.7), 1 + (i % 3 === 0), 1 + (i % 3 === 0)); }
      g.strokeStyle = rgba(T.accent, 0.35); g.lineWidth = 2; g.beginPath(); g.arc(W / 2, H * 0.42, Math.min(W, H) * 0.42, 0, TAU); g.stroke();
      for (i = 0; i < 24; i++) { var a = i / 24 * TAU; g.beginPath(); g.moveTo(W / 2 + Math.cos(a) * Math.min(W, H) * 0.39, H * 0.42 + Math.sin(a) * Math.min(W, H) * 0.39); g.lineTo(W / 2 + Math.cos(a) * Math.min(W, H) * 0.42, H * 0.42 + Math.sin(a) * Math.min(W, H) * 0.42); g.stroke(); }
    } else if (theme === 'court') {                           // marble columns and banners
      for (i = 40; i < W; i += Math.max(140, W / 6)) { g.fillStyle = '#f4efe6'; g.fillRect(i, 0, 34, H * 0.72); g.fillStyle = rgba('#000000', 0.08); g.fillRect(i + 24, 0, 10, H * 0.72); }
      for (i = 110; i < W - 60; i += Math.max(280, W / 3)) { g.fillStyle = T.accent; g.beginPath(); g.moveTo(i, 0); g.lineTo(i + 46, 0); g.lineTo(i + 46, 110); g.lineTo(i + 23, 92); g.lineTo(i, 110); g.closePath(); g.fill(); g.fillStyle = T.trim; g.fillRect(i, 0, 46, 8); }
    } else if (theme === 'carnival') {                        // a striped tent and bunting
      for (i = 0; i < W; i += 60) { g.fillStyle = (i / 60) % 2 ? '#f3e3c3' : T.back2; g.beginPath(); g.moveTo(i, 0); g.lineTo(i + 60, 0); g.lineTo(i + 50, H * 0.7); g.lineTo(i + 10, H * 0.7); g.closePath(); g.fill(); }
      var flags = ['#d84a3a', '#2a77c9', '#f2c23a', '#3f9e5a'];
      for (i = 0; i < W; i += 36) { g.fillStyle = flags[(i / 36) % 4]; g.beginPath(); g.moveTo(i, 30); g.lineTo(i + 30, 30); g.lineTo(i + 15, 54); g.closePath(); g.fill(); }
    }
    // the floor
    var fy = H * 0.72, fl = g.createLinearGradient(0, fy, 0, H); fl.addColorStop(0, shade(T.back, -0.25)); fl.addColorStop(1, shade(T.back, -0.5)); g.fillStyle = fl; g.fillRect(0, fy, W, H - fy);
    return { x: W * 0.08, y: H * 0.1, w: W * 0.84, h: H * 0.5 };
  }

  /** A contestant's podium with a name plate and a score display (drawn per score change, never per frame). */
  function podium(g, x, y, w, theme, name, score, lit, faceFn) {
    var T = STAGE[theme] || STAGE.gameshow, h = w * 0.7;
    g.save(); g.translate(x, y);
    g.fillStyle = rgba('#000000', 0.3); g.beginPath(); g.ellipse(0, h + 4, w * 0.6, 8, 0, 0, TAU); g.fill();
    var body = g.createLinearGradient(-w / 2, 0, w / 2, 0); body.addColorStop(0, shade(T.trim, -0.3)); body.addColorStop(0.5, T.trim); body.addColorStop(1, shade(T.trim, -0.45));
    g.fillStyle = body; g.beginPath(); g.moveTo(-w * 0.42, 0); g.lineTo(w * 0.42, 0); g.lineTo(w / 2, h); g.lineTo(-w / 2, h); g.closePath(); g.fill();
    g.fillStyle = lit ? T.accent : shade(T.trim, -0.55); roundRect(g, -w * 0.36, h * 0.18, w * 0.72, h * 0.3, 6); g.fill();
    text(g, String(score), 0, h * 0.33, Math.round(w * 0.16), lit ? pickInk(T.accent, ['#1a1208', '#ffffff']) : '#f6e9cf', 'center', '700');
    g.fillStyle = '#f6eedc'; roundRect(g, -w * 0.4, h * 0.58, w * 0.8, h * 0.26, 5); g.fill();
    var nf = wrap(g, name, w * 0.74, Math.round(w * 0.12), 1, '700'); text(g, nf.lines[0], 0, h * 0.71, nf.size, '#2a1d14', 'center', '700');
    if (faceFn) { g.save(); g.beginPath(); g.arc(0, -w * 0.32, w * 0.26, 0, TAU); g.clip(); faceFn(g, 0, -w * 0.32, w * 0.26); g.restore(); g.strokeStyle = T.trim; g.lineWidth = 3; g.beginPath(); g.arc(0, -w * 0.32, w * 0.26 + 1.5, 0, TAU); g.stroke(); }
    g.restore();
  }

  /* ---------------------------------------------------------------- element marks (one hand, asymmetric, Icon_Doctrine §22) */

  var MARK = {
    Fire: function (g, r) { g.beginPath(); g.moveTo(0, r); g.bezierCurveTo(-r * 0.9, r * 0.6, -r * 0.6, -r * 0.2, -r * 0.1, -r); g.bezierCurveTo(0, -r * 0.4, r * 0.5, -r * 0.5, r * 0.35, -r * 0.05); g.bezierCurveTo(r * 0.7, -r * 0.2, r * 0.8, r * 0.6, 0, r); g.fill(); },
    Ice: function (g, r) { g.lineWidth = r * 0.16; g.lineCap = 'round'; for (var i = 0; i < 3; i++) { var a = i * Math.PI / 3; g.beginPath(); g.moveTo(Math.cos(a) * r, Math.sin(a) * r); g.lineTo(-Math.cos(a) * r, -Math.sin(a) * r); g.stroke(); } for (var k = 0; k < 6; k++) { var b = k * Math.PI / 3; g.beginPath(); g.moveTo(Math.cos(b) * r * 0.6, Math.sin(b) * r * 0.6); g.lineTo(Math.cos(b + 0.4) * r * 0.85, Math.sin(b + 0.4) * r * 0.85); g.stroke(); } },
    Thunder: function (g, r) { g.beginPath(); g.moveTo(r * 0.2, -r); g.lineTo(-r * 0.55, r * 0.1); g.lineTo(-r * 0.05, r * 0.1); g.lineTo(-r * 0.3, r); g.lineTo(r * 0.6, -r * 0.15); g.lineTo(r * 0.08, -r * 0.15); g.closePath(); g.fill(); },
    Water: function (g, r) { g.beginPath(); g.moveTo(0, -r); g.bezierCurveTo(r * 0.25, -r * 0.4, r * 0.75, 0, r * 0.7, r * 0.35); g.arc(0, r * 0.35, r * 0.7, 0, Math.PI); g.bezierCurveTo(-r * 0.75, 0, -r * 0.25, -r * 0.4, 0, -r); g.fill(); },
    Earth: function (g, r) { g.beginPath(); g.moveTo(-r, r * 0.7); g.lineTo(-r * 0.45, -r * 0.4); g.lineTo(-r * 0.1, r * 0.05); g.lineTo(r * 0.3, -r * 0.8); g.lineTo(r, r * 0.7); g.closePath(); g.fill(); },
    Wind: function (g, r) { g.lineWidth = r * 0.16; g.lineCap = 'round'; [[-0.45, 1.2], [0, 1.6], [0.45, 1.0]].forEach(function (w) { var y = w[0] * r; g.beginPath(); g.moveTo(-r, y); g.lineTo(-r + w[1] * r * 0.9, y); g.arc(-r + w[1] * r * 0.9, y - r * 0.22, r * 0.22, Math.PI / 2, -Math.PI * 0.6, true); g.stroke(); }); },
    Light: function (g, r) { g.beginPath(); g.arc(0, 0, r * 0.42, 0, TAU); g.fill(); g.lineWidth = r * 0.13; g.lineCap = 'round'; for (var i = 0; i < 8; i++) { var a = i * TAU / 8 + 0.2; g.beginPath(); g.moveTo(Math.cos(a) * r * 0.6, Math.sin(a) * r * 0.6); g.lineTo(Math.cos(a) * r * (i % 2 ? 0.85 : 1), Math.sin(a) * r * (i % 2 ? 0.85 : 1)); g.stroke(); } },
    Darkness: function (g, r) { g.beginPath(); g.arc(0, 0, r * 0.85, Math.PI * 0.25, Math.PI * 1.75); g.arc(r * 0.35, -r * 0.05, r * 0.7, Math.PI * 1.6, Math.PI * 0.4, true); g.closePath(); g.fill(); },
    Physical: function (g, r) { g.save(); g.rotate(-0.7); g.fillRect(-r * 0.09, -r, r * 0.18, r * 1.35); g.fillRect(-r * 0.4, r * 0.3, r * 0.8, r * 0.14); g.fillRect(-r * 0.07, r * 0.42, r * 0.14, r * 0.42); g.beginPath(); g.arc(0, r * 0.9, r * 0.11, 0, TAU); g.fill(); g.restore(); },
  };
  var MARK_FACE = { Fire: '#e5582d', Ice: '#7cc6ea', Thunder: '#f2c23a', Water: '#3f86d6', Earth: '#9a7a4a', Wind: '#7fcf9a', Light: '#f6e27a', Darkness: '#5b3f8c', Physical: '#a8a29a' };
  /** An element's mark on a disc in its own colour; an element the kit does not know gets its initial, never nothing. */
  function elementMark(g, x, y, r, name) {
    var face = MARK_FACE[name] || '#8a8a8a', ink = pickInk(face, ['#2a1d14', '#fff8ea']);
    g.save(); g.translate(x, y);
    g.fillStyle = rgba('#000000', 0.3); g.beginPath(); g.arc(2, 3, r, 0, TAU); g.fill();
    var fg = g.createRadialGradient(-r * 0.3, -r * 0.35, r * 0.1, 0, 0, r); fg.addColorStop(0, shade(face, 0.3)); fg.addColorStop(1, shade(face, -0.2)); g.fillStyle = fg; g.beginPath(); g.arc(0, 0, r, 0, TAU); g.fill();
    g.strokeStyle = shade(face, -0.5); g.lineWidth = Math.max(1.5, r * 0.06); g.stroke();
    g.fillStyle = ink; g.strokeStyle = ink;
    if (MARK[name]) MARK[name](g, r * 0.58); else text(g, String(name || '?').charAt(0), 0, 1, Math.round(r), ink, 'center', '700');
    g.restore();
    return { known: !!MARK[name], ink: ink };
  }

  /* ---------------------------------------------------------------- the question card */

  var SECTION = { price: 'MARKET', priciest: 'MARKET', oddOne: 'ARMOURY', mpCost: 'SPELLBOOK', skillElement: 'SPELLBOOK', inflicts: 'SPELLBOOK', learnedBy: 'SCHOOLS', actorClass: 'ROLL CALL', weakness: 'BESTIARY', toughest: 'BESTIARY', gold: 'BESTIARY' };

  /**
   * The card for a question: a section header, the subject pictured (by `picture(g, x, y, size)` the scene supplies from
   * the database: the icon, the enemy's image or the face; an element question also shows the element marks of its
   * choices), the question in display type, and difficulty pips. Returns what it drew, for tests.
   */
  function card(g, x, y, w, h, q, theme, picture) {
    var T = STAGE[theme] || STAGE.gameshow, paper = T.board, ink = pickInk(paper, ['#2a1d14', '#fff6e0']);
    g.save();
    g.fillStyle = rgba('#000000', 0.35); roundRect(g, x + 5, y + 7, w, h, 16); g.fill();
    g.fillStyle = paper; roundRect(g, x, y, w, h, 16); g.fill();
    g.strokeStyle = T.trim; g.lineWidth = 4; roundRect(g, x + 2, y + 2, w - 4, h - 4, 14); g.stroke();
    g.strokeStyle = rgba(T.trim, 0.5); g.lineWidth = 1.5; roundRect(g, x + 10, y + 10, w - 20, h - 20, 10); g.stroke();
    var sec = SECTION[q.template] || 'QUESTION';
    g.fillStyle = T.trim; roundRect(g, x + w / 2 - 90, y - 16, 180, 34, 8); g.fill();
    text(g, sec, x + w / 2, y + 1, 17, pickInk(T.trim, ['#2a1d14', '#fff6e0']), 'center', '700');
    var ps = Math.min(h - 70, w * 0.3), px = x + 30, py = y + (h - ps) / 2 + 8, drew = 'none';
    g.fillStyle = rgba(T.accent, 0.12); roundRect(g, px - 8, py - 8, ps + 16, ps + 16, 12); g.fill();
    if (picture) { picture(g, px, py, ps); drew = 'subject'; }
    var tx = px + ps + 28, tw = x + w - tx - 30, fit = wrap(g, q.text, tw, 30, 3, '700'), lh = fit.size * 1.25, ty = y + h / 2 - (fit.lines.length - 1) * lh / 2 - 8;
    fit.lines.forEach(function (l, i) { text(g, l, tx, ty + i * lh, fit.size, ink, 'left', '700'); });
    for (var p = 0; p < 3; p++) { g.fillStyle = p < (q.difficulty || 1) ? T.accent : rgba(ink, 0.25); g.beginPath(); g.arc(x + w - 40 - p * 18, y + h - 28, 6, 0, TAU); g.fill(); }
    g.restore();
    return { drew: drew, section: sec, squeezed: fit.squeezed, overflow: !!fit.overflow, lines: fit.lines.length };
  }

  /** An answer tile: a letter badge and the choice; state idle | chosen | right | wrong. */
  function tile(g, x, y, w, h, letter, choice, state, theme, mark) {
    // chosen is ONE gold in every theme: the Royal Court's crimson accent read the same as "wrong" (2026-10-08 sheet)
    var T = STAGE[theme] || STAGE.gameshow, face = state === 'right' ? '#3f9e5a' : state === 'wrong' ? '#b8392f' : state === 'chosen' ? '#f2c94c' : shade(T.board, lum(T.board) > 0.4 ? -0.06 : 0.12);
    var ink = pickInk(face, ['#2a1d14', '#fff6e0']);
    g.save();
    g.fillStyle = rgba('#000000', 0.3); roundRect(g, x + 3, y + 5, w, h, 12); g.fill();
    g.fillStyle = face; roundRect(g, x, y, w, h, 12); g.fill();
    g.strokeStyle = state === 'idle' ? rgba(T.trim, 0.8) : '#ffffff'; g.lineWidth = state === 'idle' ? 2 : 3; roundRect(g, x + 1.5, y + 1.5, w - 3, h - 3, 11); g.stroke();
    g.fillStyle = T.trim; g.beginPath(); g.arc(x + h / 2 + 4, y + h / 2, h * 0.32, 0, TAU); g.fill();
    text(g, letter, x + h / 2 + 4, y + h / 2 + 1, Math.round(h * 0.36), pickInk(T.trim, ['#2a1d14', '#fff6e0']), 'center', '700');
    var off = h + 12;
    if (mark) { elementMark(g, x + off + h * 0.3, y + h / 2, h * 0.3, choice); off += h * 0.78; }   // clear of the mark's shadow
    var fit = wrap(g, choice, w - off - 14, Math.round(h * 0.36), 1, '700');
    text(g, fit.lines[0], x + off, y + h / 2 + 1, fit.size, ink, 'left', '700');
    g.restore();
    return { ink: ink, squeezed: fit.squeezed };
  }

  /** The timer: a ring that drains clockwise, turning red in its last quarter. */
  function timer(g, x, y, r, left, theme) {
    var T = STAGE[theme] || STAGE.gameshow, f = Math.max(0, Math.min(1, left));
    g.save(); g.translate(x, y);
    g.fillStyle = rgba('#000000', 0.45); g.beginPath(); g.arc(0, 0, r, 0, TAU); g.fill();
    g.strokeStyle = rgba('#ffffff', 0.15); g.lineWidth = r * 0.22; g.beginPath(); g.arc(0, 0, r * 0.78, 0, TAU); g.stroke();
    g.strokeStyle = f < 0.25 ? '#e5482d' : T.accent; g.lineCap = 'round'; g.beginPath(); g.arc(0, 0, r * 0.78, -Math.PI / 2, -Math.PI / 2 + TAU * f); g.stroke();
    g.restore();
  }

  return { VERSION: '1.0.0', FONT: FONT, STAGE: STAGE, THEMES: THEMES, MARK: MARK, MARK_FACE: MARK_FACE, SECTION: SECTION,
    shade: shade, lum: lum, contrast: contrast, pickInk: pickInk, roundRect: roundRect, text: text, wrap: wrap,
    backdrop: backdrop, podium: podium, elementMark: elementMark, card: card, tile: tile, timer: timer };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = QuizmasterDraw;
