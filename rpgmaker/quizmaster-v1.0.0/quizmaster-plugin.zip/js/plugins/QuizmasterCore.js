//=============================================================================
// QuizmasterCore.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Quizmaster 1/3 - the rules: questions written from your database, the quiz, the rivals. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The rules for Quizmaster. No parameters or commands of its own.
 *
 * Pure logic: nothing here touches the screen and nothing uses Math.random.
 * It reads your database (items, weapons, armors, skills, enemies, actors,
 * classes, states, elements) and writes multiple-choice questions whose
 * answers are facts in that database. A fact that is missing, blank, tied or
 * ambiguous is never asked: a question is only written when exactly one
 * answer is right.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var QuizmasterCore = (function () {
  'use strict';

  /* ---------------------------------------------------------------- seeds */
  function hashString(str) { var h = 2166136261, s = String(str); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function mix(a, b) { var h = Math.imul((a >>> 0) ^ 0x9E3779B9, 0x85EBCA6B) ^ Math.imul((b >>> 0) + 0x632BE5AB, 0xC2B2AE35); h ^= h >>> 15; h = Math.imul(h, 0x2C1B3C6D); h ^= h >>> 12; return h >>> 0; }
  function rng(seed) { var a = (seed >>> 0) || 1; return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function draw(state) { state.r = (state.r + 0x6D2B79F5) >>> 0; var t = state.r; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }
  function shuffle(r, a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(r() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }

  /* ---------------------------------------------------------------- reading the database */

  /** A usable record: has a name that is not blank and not a divider ("-----Reserved"), and the name is not shared. */
  function usable(list) {
    var out = [], count = {};
    (list || []).forEach(function (x) { if (x && typeof x.name === 'string') { var n = x.name.trim(); if (n) count[n] = (count[n] || 0) + 1; } });
    (list || []).forEach(function (x) {
      if (!x || typeof x.name !== 'string') return;
      var n = x.name.trim();
      if (!n || /^[-=*_~]{2,}/.test(n) || count[n] > 1) return;   // blank, a divider, or ambiguous by name
      out.push(x);
    });
    return out;
  }
  function elementName(db, id) { var e = db.system && db.system.elements; return e && id > 0 && e[id] && String(e[id]).trim() ? String(e[id]).trim() : null; }

  /**
   * The facts the templates ask about, read once from a database {items, weapons, armors, skills, enemies, actors,
   * classes, states, system}. Each list is filtered by usable().
   */
  function facts(db) {
    return { items: usable(db.items), weapons: usable(db.weapons), armors: usable(db.armors), skills: usable(db.skills), enemies: usable(db.enemies),
      actors: usable(db.actors), classes: usable(db.classes), states: usable(db.states), db: db };
  }

  /* ---------------------------------------------------------------- templates */
  // Each template returns null when it cannot write a question with exactly one right answer from the record it was
  // handed. A question: {template, text, answer, choices[4], subject:{kind, id, icon, battler}, difficulty 1..3}

  function pickOthers(r, pool, exclude, n, key) {
    var seen = {}, out = [], c = shuffle(r, pool.slice());
    seen[exclude] = true;
    for (var i = 0; i < c.length && out.length < n; i++) { var v = key(c[i]); if (v == null || seen[v]) continue; seen[v] = true; out.push(v); }
    return out.length === n ? out : null;
  }
  function numericChoices(r, answer, step) {
    var opts = [answer], tries = 0;
    while (opts.length < 4 && tries++ < 40) {
      var k = (1 + Math.floor(r() * 3)) * (r() < 0.5 ? -1 : 1), v = answer + k * step;
      if (v >= 0 && opts.indexOf(v) < 0) opts.push(v);
    }
    return opts.length === 4 ? opts : null;
  }
  /** True when the answer is printed in the question ("Which state can Sleep inflict?" -> Sleep): never asked. */
  function gives(text, answer) { var a = String(answer).trim().toLowerCase(); return a.length > 2 && !/^\d+$/.test(a) && String(text).toLowerCase().indexOf(a) >= 0; }
  function build(r, template, text, answer, others, subject, difficulty) {
    if (!others || gives(text, answer)) return null;   // (2026-10-08: the stock "Sleep" skill asked which state it inflicts)
    var choices = shuffle(r, [answer].concat(others).map(String));
    return { template: template, text: text, answer: String(answer), choices: choices, subject: subject, difficulty: difficulty };
  }

  var TEMPLATES = {
    /** Which of these four costs the most? (items, weapons or armors with distinct non-zero prices) */
    priciest: function (F, r) {
      var pool = [].concat(F.items, F.weapons, F.armors).filter(function (x) { return x.price > 0; });
      if (pool.length < 4) return null;
      var four = shuffle(r, pool.slice()).slice(0, 4), max = Math.max.apply(null, four.map(function (x) { return x.price; }));
      if (four.filter(function (x) { return x.price === max; }).length !== 1) return null;
      var top = four.filter(function (x) { return x.price === max; })[0];
      return { template: 'priciest', text: 'Which of these costs the most?', answer: top.name, choices: shuffle(r, four.map(function (x) { return x.name; })), subject: { kind: 'item', id: top.id, icon: top.iconIndex }, difficulty: 2 };
    },
    /** How much does X cost? */
    price: function (F, r, x) {
      if (!x || !(x.price > 0)) return null;
      var step = x.price >= 1000 ? 100 : x.price >= 100 ? 50 : 10, c = numericChoices(r, x.price, step);
      return c && build(r, 'price', 'How much does ' + x.name + ' cost?', x.price, c.slice(1), { kind: 'item', id: x.id, icon: x.iconIndex }, 1);
    },
    /** Which element is X weakest to? (an enemy with exactly one highest element rate above 100%) */
    weakness: function (F, r, e) {
      if (!e) return null;
      var rates = {}; (e.traits || []).forEach(function (t) { if (t.code === 11 && elementName(F.db, t.dataId)) rates[t.dataId] = (rates[t.dataId] == null ? 1 : rates[t.dataId]) * t.value; });
      var ids = Object.keys(rates).filter(function (k) { return rates[k] > 1; });
      if (!ids.length) return null;
      var max = Math.max.apply(null, ids.map(function (k) { return rates[k]; }));
      var top = ids.filter(function (k) { return rates[k] === max; });
      if (top.length !== 1) return null;
      var all = (F.db.system.elements || []).map(function (n, i) { return i > 0 && elementName(F.db, i) ? i : null; }).filter(function (i) { return i != null && rates[i] == null || i != null && rates[i] <= 1; });
      var others = pickOthers(r, all, elementName(F.db, Number(top[0])), 3, function (i) { return elementName(F.db, i); });
      return build(r, 'weakness', 'Which element is ' + e.name + ' weakest to?', elementName(F.db, Number(top[0])), others, { kind: 'enemy', id: e.id, battler: e.battlerName }, 3);
    },
    /** How much MP does skill X cost? */
    mpCost: function (F, r, s) {
      if (!s || !(s.mpCost > 0)) return null;
      var c = numericChoices(r, s.mpCost, s.mpCost >= 20 ? 5 : 2);
      return c && build(r, 'mpCost', 'How much MP does ' + s.name + ' cost?', s.mpCost, c.slice(1), { kind: 'skill', id: s.id, icon: s.iconIndex }, 2);
    },
    /** Which element is skill X? (a damaging skill with a real element id) */
    skillElement: function (F, r, s) {
      if (!s || !s.damage || !(s.damage.type > 0) || !elementName(F.db, s.damage.elementId)) return null;
      var all = []; for (var i = 1; i < (F.db.system.elements || []).length; i++) if (elementName(F.db, i)) all.push(i);
      var ans = elementName(F.db, s.damage.elementId), others = pickOthers(r, all, ans, 3, function (k) { return elementName(F.db, k); });
      return build(r, 'skillElement', 'What element is ' + s.name + '?', ans, others, { kind: 'skill', id: s.id, icon: s.iconIndex }, 2);
    },
    /** Which state does skill X inflict? (exactly one Add State effect naming a usable state) */
    inflicts: function (F, r, s) {
      if (!s) return null;
      var adds = (s.effects || []).filter(function (e) { return e.code === 21 && e.dataId > 0; }), byId = {};
      F.states.forEach(function (st) { byId[st.id] = st; });
      if (adds.length !== 1 || !byId[adds[0].dataId]) return null;
      var ans = byId[adds[0].dataId].name, others = pickOthers(r, F.states, ans, 3, function (st) { return st.name; });
      return build(r, 'inflicts', 'Which state can ' + s.name + ' inflict?', ans, others, { kind: 'skill', id: s.id, icon: s.iconIndex }, 3);
    },
    /** Which class is X? (an actor) */
    actorClass: function (F, r, a) {
      if (!a) return null;
      var byId = {}; F.classes.forEach(function (c) { byId[c.id] = c; });
      if (!byId[a.classId]) return null;
      var ans = byId[a.classId].name, others = pickOthers(r, F.classes, ans, 3, function (c) { return c.name; });
      return build(r, 'actorClass', 'What class is ' + a.name + '?', ans, others, { kind: 'actor', id: a.id, face: a.faceName, faceIndex: a.faceIndex }, 1);
    },
    /** Which class learns skill X? (exactly one class learns it) */
    learnedBy: function (F, r, s) {
      if (!s) return null;
      var who = F.classes.filter(function (c) { return (c.learnings || []).some(function (l) { return l.skillId === s.id; }); });
      if (who.length !== 1) return null;
      var others = pickOthers(r, F.classes, who[0].name, 3, function (c) { return c.name; });
      return build(r, 'learnedBy', 'Which class learns ' + s.name + '?', who[0].name, others, { kind: 'skill', id: s.id, icon: s.iconIndex }, 3);
    },
    /** Which of these is a weapon? (one weapon among three armors) */
    oddOne: function (F, r) {
      if (!F.weapons.length || F.armors.length < 3) return null;
      var w = F.weapons[Math.floor(r() * F.weapons.length)], others = pickOthers(r, F.armors, w.name, 3, function (a) { return a.name; });
      return build(r, 'oddOne', 'Which of these is a weapon?', w.name, others, { kind: 'weapon', id: w.id, icon: w.iconIndex }, 1);
    },
    /** Which of these enemies has the most HP? */
    toughest: function (F, r) {
      if (F.enemies.length < 4) return null;
      var four = shuffle(r, F.enemies.slice()).slice(0, 4), max = Math.max.apply(null, four.map(function (e) { return e.params[0]; }));
      var top = four.filter(function (e) { return e.params[0] === max; });
      if (top.length !== 1) return null;
      return { template: 'toughest', text: 'Which of these has the most HP?', answer: top[0].name, choices: shuffle(r, four.map(function (e) { return e.name; })), subject: { kind: 'enemy', id: top[0].id, battler: top[0].battlerName }, difficulty: 2 };
    },
    /** How much gold does enemy X drop? */
    gold: function (F, r, e) {
      if (!e || !(e.gold > 0)) return null;
      var c = numericChoices(r, e.gold, e.gold >= 100 ? 25 : 5);
      return c && build(r, 'gold', 'How much gold does ' + e.name + ' drop?', e.gold, c.slice(1), { kind: 'enemy', id: e.id, battler: e.battlerName }, 2);
    },
  };
  // which list each per-record template walks
  var SOURCE = { price: ['items', 'weapons', 'armors'], weakness: ['enemies'], mpCost: ['skills'], skillElement: ['skills'], inflicts: ['skills'], actorClass: ['actors'], learnedBy: ['skills'], gold: ['enemies'] };
  var POOL = ['priciest', 'oddOne', 'toughest'];   // templates that pick their own records

  /**
   * Every question the database can answer, deduplicated by text, in a seeded order.
   * @param {Object} db the database lists
   * @param {number} seed
   * @param {{templates?:string[]}} [opts]
   */
  function bank(db, seed, opts) {
    var F = facts(db), r = rng(mix(seed >>> 0, 0x0B1A)), out = [], seen = {}, use = (opts && opts.templates) || Object.keys(TEMPLATES);
    // a question is the same question only if its text AND its choices match: the pool templates ("Which of these is a
    // weapon?") share one text across many different sets (2026-10-08: keyed on text alone, each wrote ONE question)
    function add(q) { if (!q) return; var key = q.text + '|' + q.choices.slice().sort().join('|'); if (seen[key]) return; seen[key] = true; out.push(q); }
    use.forEach(function (name) {
      if (!TEMPLATES[name]) return;
      if (SOURCE[name]) SOURCE[name].forEach(function (src) { F[src].forEach(function (rec) { add(TEMPLATES[name](F, r, rec)); }); });
      else for (var k = 0; k < 24; k++) add(TEMPLATES[name](F, r));
    });
    return shuffle(r, out);
  }
  /**
   * The bank interleaved by template (seeded), so a short quiz is not ten price questions: the stock database writes 141
   * price questions of 375 (MEASURED 2026-10-08, _probe/bank_print.js), and a straight slice reflects that.
   */
  function balanced(questions, seed) {
    var r = rng(mix(seed >>> 0, 0xBA1A)), groups = {}, order = [], out = [];
    questions.forEach(function (q) { if (!groups[q.template]) { groups[q.template] = []; order.push(q.template); } groups[q.template].push(q); });
    shuffle(r, order);
    for (var round = 0; out.length < questions.length; round++) order.forEach(function (t) { if (groups[t][round]) out.push(groups[t][round]); });
    return out;
  }

  /** A question is sound when it has four distinct choices, exactly one of them the answer. */
  function sound(q) {
    if (!q || !Array.isArray(q.choices) || q.choices.length !== 4) return false;
    var set = {}; for (var i = 0; i < 4; i++) { if (set[q.choices[i]]) return false; set[q.choices[i]] = true; }
    return q.choices.filter(function (c) { return c === q.answer; }).length === 1 && typeof q.text === 'string' && q.text.length > 0;
  }

  /* ---------------------------------------------------------------- the quiz */

  var RIVAL_SKILL = { novice: 0.45, sharp: 0.65, master: 0.85 };
  /**
   * A quiz: `count` questions from the bank, the player and up to three rivals. Plain JSON: save it as it is.
   * Scoring: a right answer earns 10 points plus up to 10 for speed (the fraction of the timer left).
   */
  function createQuiz(questions, contestants, seed, opts) {
    opts = opts || {};
    if (!questions || !questions.length) return null;      // nothing the database can answer: no quiz, never an empty one
    var n = Math.max(1, Math.min(questions.length, Math.floor(opts.count || 5)));
    return { v: 1, r: mix(seed >>> 0, 0x5C0E) >>> 0, questions: questions.slice(0, n), index: 0, phase: 'ask', time: Math.max(3, Math.floor(opts.seconds || 12)),
      people: contestants.map(function (c, i) { return { name: String(c.name || 'Contestant ' + (i + 1)), ai: c.ai === 'player' ? 'player' : (RIVAL_SKILL[c.ai] ? c.ai : 'sharp'), score: 0, right: 0, last: null }; }) };
  }
  function current(state) { return state.questions[state.index]; }
  /** A rival's answer to the current question, and how fast (fraction of the timer left). Seeded, saved state. */
  function rivalAnswer(state, i) {
    var p = state.people[i], q = current(state), skill = RIVAL_SKILL[p.ai] - (q.difficulty - 2) * 0.1;
    var right = draw(state) < skill, wrong = q.choices.filter(function (c) { return c !== q.answer; });
    return { choice: right ? q.answer : wrong[Math.floor(draw(state) * wrong.length)], speed: 0.2 + draw(state) * 0.7 };
  }
  /**
   * Settle the current question: the player's choice (or null when time ran out) and the time left (0..1); every rival
   * answers for itself. Returns each contestant's result.
   */
  function answer(state, playerChoice, timeLeft) {
    if (state.phase !== 'ask') throw new Error('Quizmaster: answer() in phase ' + state.phase);
    var q = current(state), out = [];
    for (var i = 0; i < state.people.length; i++) {
      var p = state.people[i], a = p.ai === 'player' ? { choice: playerChoice, speed: Math.max(0, Math.min(1, Number(timeLeft) || 0)) } : rivalAnswer(state, i);
      var ok = a.choice === q.answer, pts = ok ? 10 + Math.round(10 * a.speed) : 0;
      p.score += pts; if (ok) p.right++; p.last = { choice: a.choice, right: ok, points: pts };
      out.push({ who: i, choice: a.choice, right: ok, points: pts });
    }
    state.phase = 'reveal';
    return out;
  }
  /** Move on: the next question, or 'done'. */
  function next(state) {
    if (state.phase !== 'reveal') throw new Error('Quizmaster: next() in phase ' + state.phase);
    state.index++;
    state.phase = state.index >= state.questions.length ? 'done' : 'ask';
    return state.phase;
  }
  /** Places by score, then right answers, then seat. */
  function results(state) {
    return state.people.map(function (p, i) { return { who: i, name: p.name, score: p.score, right: p.right }; })
      .sort(function (a, b) { return b.score - a.score || b.right - a.right || a.who - b.who; })
      .map(function (x, k) { x.place = k + 1; return x; });
  }

  return { VERSION: '1.0.0', TEMPLATES: TEMPLATES, RIVAL_SKILL: RIVAL_SKILL, hashString: hashString, mix: mix, rng: rng, usable: usable, facts: facts, bank: bank, balanced: balanced, gives: gives, sound: sound,
    createQuiz: createQuiz, current: current, answer: answer, next: next, results: results };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = QuizmasterCore;
