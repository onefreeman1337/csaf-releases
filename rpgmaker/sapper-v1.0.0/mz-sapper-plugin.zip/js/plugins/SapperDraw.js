/*:
 * @target MZ
 * @plugindesc [v1.0.0] Sapper 2/3 - the look: the minefield drawn as turf, sand, snow or slate in your picture's colours, the marks, the frame. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * SapperDraw.js draws everything Sapper shows and touches no part of the engine. Turn it on together with
 * SapperCore.js and Sapper.js; the order does not matter. See Readme_for_Users.md.
 */
/* SapperDraw - canvas drawing only (2D context), no engine code; runs in a plain page for the contact sheets and in MZ.
 * A cell is drawn when it changes, never per frame. Copyright (c) 2026 Core Systems Asset Factory. */
var SapperDraw = (function () {
  'use strict';
  var FACE = '"Palatino Linotype", "Book Antiqua", Palatino, Georgia, serif';
  var STYLES = ['turf', 'sand', 'snow', 'slate'];
  function rng(seed) { var s = seed >>> 0 || 1; return function () { s = (s + 0x6D2B79F5) | 0; var t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function rr(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r); ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h); ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r); ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.closePath(); }
  function hex(c) { return 'rgb(' + (c[0] | 0) + ',' + (c[1] | 0) + ',' + (c[2] | 0) + ')'; }
  function mixc(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }
  function shade(c, k) { return k >= 0 ? mixc(c, [255, 255, 255], k) : mixc(c, [0, 0, 0], -k); }

  /** each material: its own base colour, how much of the picture tints it, its marks, its number tokens and inks.
   *  Inks are earth, dye and mineral colours, never the stock minesweeper palette. */
  var MAT = {
    turf: { base: [86, 126, 62], tint: 0.38, token: [236, 226, 196], tokenEdge: [92, 70, 44], inks: ['#2a4f7a', '#3c6b2e', '#a33a26', '#5a3c78', '#7a2a3a', '#2a6a68', '#3a2a22', '#6a6052'] },
    sand: { base: [196, 166, 112], tint: 0.34, token: [250, 240, 214], tokenEdge: [150, 112, 66], inks: ['#245a86', '#4b6a24', '#b2401f', '#663c7e', '#8a2f2f', '#1f6b62', '#3b2a1c', '#6b5a44'] },
    snow: { base: [214, 228, 240], tint: 0.26, token: [252, 252, 255], tokenEdge: [120, 146, 176], inks: ['#1f4f9a', '#2f6e4c', '#b0302f', '#5a3a96', '#8a2a4a', '#1f6f86', '#2a2f3c', '#5d6676'] },
    slate: { base: [96, 108, 122], tint: 0.32, token: [226, 222, 210], tokenEdge: [52, 58, 66], inks: ['#2b5a8f', '#3a6f3a', '#a8402c', '#5c3e86', '#83303f', '#2a6c6e', '#2a2a2e', '#665f56'] },
  };

  /**
   * The average colour of the picture under each cell, read ONCE when the game is built (never during play, Probe_Doctrine
   * §27a). `px` is RGBA of the picture at (pw, ph); the board covers it cover-fitted, as the scene draws it.
   * @returns {Uint8Array} 3 bytes per cell
   */
  function cellColours(px, pw, ph, cols, rows, bw, bh) {
    var out = new Uint8Array(cols * rows * 3), k = Math.max(bw / pw, bh / ph), ox = (pw * k - bw) / 2, oy = (ph * k - bh) / 2, cw = bw / cols, ch = bh / rows;
    for (var cy = 0; cy < rows; cy++) for (var cx = 0; cx < cols; cx++) {
      var r = 0, g = 0, b = 0, n = 0;
      for (var sy = 0; sy < 4; sy++) for (var sx = 0; sx < 4; sx++) {
        var X = Math.min(pw - 1, Math.max(0, Math.floor(((cx + (sx + 0.5) / 4) * cw + ox) / k))), Y = Math.min(ph - 1, Math.max(0, Math.floor(((cy + (sy + 0.5) / 4) * ch + oy) / k))), i = (Y * pw + X) * 4;
        if (px[i + 3] < 8) continue; r += px[i]; g += px[i + 1]; b += px[i + 2]; n++;
      }
      var o = (cy * cols + cx) * 3; if (n) { out[o] = r / n; out[o + 1] = g / n; out[o + 2] = b / n; } else { out[o] = 128; out[o + 1] = 128; out[o + 2] = 128; }
    }
    return out;
  }
  /** a covered cell in its material, tinted by the picture beneath it; `flag` plants a pennant */
  function drawCell(ctx, x, y, s, style, pic, seed, flag) {
    var m = MAT[style] || MAT.turf, r = rng(seed), base = mixc(m.base, pic, m.tint), g;
    ctx.clearRect(x, y, s, s);
    // the body with a bevel: lit from the upper left, the cell edges sunk so the grid reads as cut ground
    ctx.fillStyle = hex(shade(base, -0.35)); ctx.fillRect(x, y, s, s);
    g = ctx.createLinearGradient(x, y, x + s, y + s); g.addColorStop(0, hex(shade(base, 0.12))); g.addColorStop(1, hex(shade(base, -0.12)));
    ctx.fillStyle = g; rr(ctx, x + 1, y + 1, s - 2, s - 2, Math.max(2, s * 0.12)); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.18)'; ctx.fillRect(x + 2, y + 2, s - 4, Math.max(1, s * 0.05)); ctx.fillStyle = 'rgba(0,0,0,0.22)'; ctx.fillRect(x + 2, y + s - 2 - Math.max(1, s * 0.05), s - 4, Math.max(1, s * 0.05));
    ctx.save(); ctx.beginPath(); ctx.rect(x + 2, y + 2, s - 4, s - 4); ctx.clip();
    var q, k;
    if (style === 'turf') {
      // grass: TUFTS of short blades fanning up from a darker root, in three greens (LOOKED AT 2026-10-11: single long
      // blades all leaning one way read as rain streaks)
      for (k = 0; k < 7; k++) {
        var tx = x + s * (0.12 + r() * 0.76), ty = y + s * (0.3 + r() * 0.62), th = s * (0.1 + r() * 0.12);
        ctx.fillStyle = hex(shade(base, -0.3)); ctx.beginPath(); ctx.ellipse(tx, ty, s * 0.06, s * 0.025, 0, 0, Math.PI * 2); ctx.fill();
        for (var bl = -2; bl <= 2; bl++) { ctx.strokeStyle = hex(shade(base, bl % 2 ? 0.3 : (bl ? -0.15 : 0.15))); ctx.lineWidth = Math.max(1, s * 0.022); ctx.beginPath(); ctx.moveTo(tx + bl * s * 0.012, ty); ctx.quadraticCurveTo(tx + bl * s * 0.03, ty - th * 0.6, tx + bl * s * 0.05 + (r() - 0.5) * s * 0.02, ty - th * (bl ? 0.85 : 1.1)); ctx.stroke(); }
      }
      for (k = 0; k < 2; k++) if (r() < 0.4) { ctx.fillStyle = 'rgba(240,230,170,0.7)'; ctx.beginPath(); ctx.arc(x + s * (0.2 + r() * 0.6), y + s * (0.2 + r() * 0.5), Math.max(1, s * 0.03), 0, Math.PI * 2); ctx.fill(); }
    } else if (style === 'sand') {
      // wind ripples and grains
      for (k = 0; k < 4; k++) { var ry = y + s * (0.2 + k * 0.2) + (r() - 0.5) * s * 0.06; ctx.strokeStyle = hex(shade(base, -0.18)); ctx.lineWidth = Math.max(1, s * 0.03); ctx.beginPath(); ctx.moveTo(x, ry); ctx.bezierCurveTo(x + s * 0.3, ry - s * 0.08, x + s * 0.6, ry + s * 0.08, x + s, ry - s * 0.02); ctx.stroke(); ctx.strokeStyle = hex(shade(base, 0.22)); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x, ry - 1.5); ctx.bezierCurveTo(x + s * 0.3, ry - s * 0.08 - 1.5, x + s * 0.6, ry + s * 0.08 - 1.5, x + s, ry - s * 0.02 - 1.5); ctx.stroke(); }
      for (k = 0; k < s * 0.6; k++) { ctx.fillStyle = r() < 0.5 ? 'rgba(90,60,30,0.25)' : 'rgba(255,250,230,0.35)'; ctx.fillRect(x + r() * s, y + r() * s, 1, 1); }
    } else if (style === 'snow') {
      // drifts: soft rounded mounds with blue shadows, a few glints
      for (k = 0; k < 3; k++) { var dx = x + s * (0.15 + r() * 0.7), dy = y + s * (0.35 + r() * 0.5), dr = s * (0.25 + r() * 0.2); var dg = ctx.createRadialGradient(dx - dr * 0.3, dy - dr * 0.4, 1, dx, dy, dr); dg.addColorStop(0, 'rgba(255,255,255,0.75)'); dg.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = dg; ctx.beginPath(); ctx.arc(dx, dy, dr, 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = 'rgba(110,140,190,0.35)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(dx, dy + dr * 0.15, dr * 0.85, 0.2, Math.PI - 0.2); ctx.stroke(); }
      for (k = 0; k < 3; k++) { var gx = x + r() * s, gy = y + r() * s, gl = Math.max(1.5, s * 0.05); ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.beginPath(); ctx.moveTo(gx - gl, gy); ctx.lineTo(gx + gl, gy); ctx.moveTo(gx, gy - gl); ctx.lineTo(gx, gy + gl); ctx.stroke(); }
    } else {
      // slate: layered cleavage lines and chisel marks
      for (k = 0; k < 3; k++) { var ly = y + s * (0.25 + k * 0.25) + (r() - 0.5) * s * 0.1; ctx.strokeStyle = hex(shade(base, -0.3)); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x, ly); ctx.lineTo(x + s, ly + (r() - 0.5) * s * 0.12); ctx.stroke(); ctx.strokeStyle = hex(shade(base, 0.2)); ctx.beginPath(); ctx.moveTo(x, ly + 1.2); ctx.lineTo(x + s, ly + 1.2 + (r() - 0.5) * s * 0.12); ctx.stroke(); }
      for (k = 0; k < 4; k++) { var cxp = x + s * (0.15 + r() * 0.7), cyp = y + s * (0.15 + r() * 0.7), cl = s * (0.06 + r() * 0.06); ctx.strokeStyle = hex(shade(base, -0.4)); ctx.lineWidth = Math.max(1, s * 0.03); ctx.beginPath(); ctx.moveTo(cxp, cyp); ctx.lineTo(cxp + cl, cyp + cl * 0.6); ctx.stroke(); }
    }
    ctx.restore();
    if (flag) pennant(ctx, x, y, s, m);
  }
  /** a pennant on a pole, planted in the cell */
  function pennant(ctx, x, y, s, m) {
    var px = x + s * 0.42, top = y + s * 0.18, foot = y + s * 0.82;
    ctx.fillStyle = 'rgba(0,0,0,0.28)'; ctx.beginPath(); ctx.ellipse(px + s * 0.04, foot, s * 0.16, s * 0.05, 0, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#3a2a1c'; ctx.lineWidth = Math.max(1.5, s * 0.05); ctx.beginPath(); ctx.moveTo(px, foot); ctx.lineTo(px, top); ctx.stroke();
    ctx.fillStyle = '#c0392b'; ctx.beginPath(); ctx.moveTo(px + 1, top); ctx.quadraticCurveTo(px + s * 0.26, top + s * 0.08, px + s * 0.42, top + s * 0.16); ctx.quadraticCurveTo(px + s * 0.24, top + s * 0.2, px + 1, top + s * 0.32); ctx.closePath(); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.25)'; ctx.beginPath(); ctx.moveTo(px + 1, top); ctx.quadraticCurveTo(px + s * 0.2, top + s * 0.06, px + s * 0.34, top + s * 0.13); ctx.lineTo(px + 1, top + s * 0.12); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#d9b44a'; ctx.beginPath(); ctx.arc(px, top, Math.max(1.5, s * 0.04), 0, Math.PI * 2); ctx.fill();
  }
  /** the number on an opened cell: a token in the material's own make so it reads over any picture */
  function drawNumber(ctx, x, y, s, style, n) {
    var m = MAT[style] || MAT.turf, cx = x + s / 2, cy = y + s / 2, R = s * 0.3;
    ctx.save(); ctx.shadowColor = 'rgba(0,0,0,0.45)'; ctx.shadowBlur = 4; ctx.shadowOffsetY = 1.5;
    ctx.fillStyle = hex(m.token);
    if (style === 'slate') { rr(ctx, cx - R, cy - R, R * 2, R * 2, R * 0.3); ctx.fill(); }
    else if (style === 'sand') { ctx.beginPath(); ctx.ellipse(cx, cy, R * 1.08, R * 0.95, 0, 0, Math.PI * 2); ctx.fill(); }
    else { ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.fill(); }
    ctx.restore();
    ctx.strokeStyle = hex(m.tokenEdge); ctx.lineWidth = Math.max(1, s * 0.035);
    if (style === 'slate') { rr(ctx, cx - R, cy - R, R * 2, R * 2, R * 0.3); ctx.stroke(); } else if (style === 'sand') { ctx.beginPath(); ctx.ellipse(cx, cy, R * 1.08, R * 0.95, 0, 0, Math.PI * 2); ctx.stroke(); } else { ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.stroke(); }
    if (style === 'snow') { ctx.strokeStyle = 'rgba(160,190,230,0.6)'; ctx.beginPath(); ctx.arc(cx, cy, R * 0.8, Math.PI * 1.1, Math.PI * 1.7); ctx.stroke(); }
    ctx.fillStyle = m.inks[(n - 1) % 8]; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.font = 'bold ' + Math.round(s * 0.42) + 'px ' + FACE; ctx.fillText(String(n), cx, cy + s * 0.02);
  }
  /** an iron mine: a dark sphere with studs and a glint; `burst` draws the one that went off */
  function drawMine(ctx, x, y, s, burst) {
    var cx = x + s / 2, cy = y + s / 2, R = s * 0.24;
    if (burst) { var bg = ctx.createRadialGradient(cx, cy, 1, cx, cy, s * 0.62); bg.addColorStop(0, 'rgba(255,230,140,0.95)'); bg.addColorStop(0.35, 'rgba(230,90,30,0.85)'); bg.addColorStop(1, 'rgba(120,20,10,0)'); ctx.fillStyle = bg; ctx.fillRect(x - s * 0.1, y - s * 0.1, s * 1.2, s * 1.2); }
    // a pale halo so an iron mine reads on a dark picture (LOOKED AT 2026-10-11: black on a night scene)
    else { var hg = ctx.createRadialGradient(cx, cy, R * 0.6, cx, cy, s * 0.48); hg.addColorStop(0, 'rgba(255,244,220,0.55)'); hg.addColorStop(1, 'rgba(255,244,220,0)'); ctx.fillStyle = hg; ctx.beginPath(); ctx.arc(cx, cy, s * 0.48, 0, Math.PI * 2); ctx.fill(); }
    ctx.strokeStyle = '#1c1c20'; ctx.lineWidth = Math.max(1.5, s * 0.06);
    for (var k = 0; k < 8; k++) { var a = k * Math.PI / 4; ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * R * 0.9, cy + Math.sin(a) * R * 0.9); ctx.lineTo(cx + Math.cos(a) * R * 1.45, cy + Math.sin(a) * R * 1.45); ctx.stroke(); ctx.fillStyle = '#2a2a30'; ctx.beginPath(); ctx.arc(cx + Math.cos(a) * R * 1.45, cy + Math.sin(a) * R * 1.45, Math.max(1, s * 0.035), 0, Math.PI * 2); ctx.fill(); }
    var g = ctx.createRadialGradient(cx - R * 0.35, cy - R * 0.4, 1, cx, cy, R); g.addColorStop(0, '#6a6a74'); g.addColorStop(1, '#16161a'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.55)'; ctx.beginPath(); ctx.arc(cx - R * 0.35, cy - R * 0.4, R * 0.2, 0, Math.PI * 2); ctx.fill();
  }
  /** a troop's enemy pressed into a wax seal: the battler image (any drawable) cover-fitted into a disc */
  function drawSeal(ctx, x, y, s, img, burst) {
    var cx = x + s / 2, cy = y + s / 2, R = s * 0.36;
    if (burst) drawMine(ctx, x, y, s, true);
    ctx.save(); ctx.shadowColor = 'rgba(0,0,0,0.5)'; ctx.shadowBlur = 4; ctx.fillStyle = '#8a1e2e'; ctx.beginPath(); for (var t = 0; t <= 20; t++) { var a = t / 20 * Math.PI * 2, j = 1 + Math.sin(t * 2.7) * 0.05; var px = cx + Math.cos(a) * R * 1.12 * j, py = cy + Math.sin(a) * R * 1.12 * j; if (t) ctx.lineTo(px, py); else ctx.moveTo(px, py); } ctx.closePath(); ctx.fill(); ctx.restore();
    if (img && img.width) { ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, R * 0.9, 0, Math.PI * 2); ctx.clip(); var w = img.width, h = img.height, k = Math.max(R * 1.8 / w, R * 1.8 / h); ctx.drawImage(img, cx - w * k / 2, cy - h * k / 2, w * k, h * k); ctx.restore(); }
    ctx.strokeStyle = 'rgba(255,190,190,0.45)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(cx, cy, R * 0.92, 0, Math.PI * 2); ctx.stroke();
  }
  /** a cross over a flag that was wrong, drawn when the field holds */
  function drawWrongFlag(ctx, x, y, s) { ctx.strokeStyle = 'rgba(150,20,20,0.9)'; ctx.lineWidth = Math.max(2, s * 0.08); ctx.beginPath(); ctx.moveTo(x + s * 0.22, y + s * 0.22); ctx.lineTo(x + s * 0.78, y + s * 0.78); ctx.moveTo(x + s * 0.78, y + s * 0.22); ctx.lineTo(x + s * 0.22, y + s * 0.78); ctx.stroke(); }
  /** the frame around the board and the band above it: an iron-bound wooden frame on a dark ground */
  function drawFrame(ctx, W, H, bx, by, bw, bh, hudH, style) {
    var g = ctx.createRadialGradient(W / 2, H * 0.55, 60, W / 2, H / 2, W * 0.8); g.addColorStop(0, '#2a2420'); g.addColorStop(1, '#0d0b0a'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    var r = rng(41); for (var k = 0; k < 220; k++) { ctx.fillStyle = 'rgba(255,240,220,' + (0.02 + r() * 0.04) + ')'; ctx.fillRect(r() * W, r() * H, 1, 1); }
    var f = 16, fx = bx - f, fy = by - f, fw = bw + f * 2, fh = bh + f * 2;
    ctx.save(); ctx.shadowColor = 'rgba(0,0,0,0.7)'; ctx.shadowBlur = 24; ctx.shadowOffsetY = 8; ctx.fillStyle = '#4a3220'; ctx.fillRect(fx, fy, fw, fh); ctx.restore();
    var wg = ctx.createLinearGradient(fx, fy, fx, fy + fh); wg.addColorStop(0, '#7a5434'); wg.addColorStop(0.5, '#5a3c24'); wg.addColorStop(1, '#3e2a18'); ctx.fillStyle = wg; ctx.fillRect(fx, fy, fw, fh);
    for (k = 0; k < 60; k++) { ctx.strokeStyle = 'rgba(30,18,8,' + (0.15 + r() * 0.2) + ')'; ctx.lineWidth = 1; ctx.beginPath(); var gy = fy + r() * fh; ctx.moveTo(fx, gy); ctx.lineTo(fx + fw, gy + (r() - 0.5) * 6); ctx.stroke(); }
    ctx.fillStyle = '#0d0b0a'; ctx.fillRect(bx - 2, by - 2, bw + 4, bh + 4);
    ctx.strokeStyle = 'rgba(255,220,170,0.25)'; ctx.lineWidth = 1; ctx.strokeRect(fx + 0.5, fy + 0.5, fw - 1, fh - 1);
    // iron corner straps with rivets
    [[fx, fy, 1, 1], [fx + fw, fy, -1, 1], [fx, fy + fh, 1, -1], [fx + fw, fy + fh, -1, -1]].forEach(function (c) { ctx.fillStyle = '#2a2a2e'; ctx.beginPath(); ctx.moveTo(c[0], c[1]); ctx.lineTo(c[0] + c[2] * 46, c[1]); ctx.lineTo(c[0] + c[2] * 46, c[1] + c[3] * 10); ctx.lineTo(c[0] + c[2] * 10, c[1] + c[3] * 10); ctx.lineTo(c[0] + c[2] * 10, c[1] + c[3] * 46); ctx.lineTo(c[0], c[1] + c[3] * 46); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#8a8a90'; [[18, 5], [38, 5], [5, 18], [5, 38]].forEach(function (p) { ctx.beginPath(); ctx.arc(c[0] + c[2] * p[0], c[1] + c[3] * p[1], 2, 0, Math.PI * 2); ctx.fill(); }); });
    // the band above: a brass plate for the title and the counts
    var hg = ctx.createLinearGradient(0, 6, 0, hudH); hg.addColorStop(0, '#5a4630'); hg.addColorStop(1, '#3a2c1c'); ctx.fillStyle = hg; rr(ctx, 24, 6, W - 48, hudH - 10, 8); ctx.fill(); ctx.strokeStyle = 'rgba(230,200,140,0.45)'; ctx.lineWidth = 1.2; rr(ctx, 24.5, 6.5, W - 49, hudH - 11, 8); ctx.stroke();
  }
  /** the counts on the band: title, mines left (a small mine), lives (pennants), time */
  function drawHud(ctx, W, h, st) {
    ctx.clearRect(0, 0, W, h);
    ctx.fillStyle = '#f0dfb8'; ctx.textBaseline = 'middle'; ctx.textAlign = 'left'; ctx.font = 'bold 20px ' + FACE; var title = st.title || 'Sapper'; ctx.fillText(title.toUpperCase().split('').join(String.fromCharCode(8202)), 44, h / 2);
    drawMine(ctx, W / 2 - 74, h / 2 - 14, 28, false); ctx.font = 'bold 20px ' + FACE; ctx.fillStyle = '#f0dfb8'; ctx.fillText(String(st.minesLeft), W / 2 - 40, h / 2);
    for (var i = 0; i < st.livesMax; i++) { ctx.globalAlpha = i < st.lives ? 1 : 0.25; pennant(ctx, W / 2 + 18 + i * 22, h / 2 - 15, 30, MAT.turf); }
    ctx.globalAlpha = 1; ctx.textAlign = 'right'; ctx.font = '18px ' + FACE; var m = Math.floor(st.seconds / 60), s = st.seconds % 60; ctx.fillText(m + ':' + (s < 10 ? '0' : '') + s, W - 44, h / 2);
  }
  /** the end: a brass plaque under the uncovered picture */
  function drawResults(ctx, W, H, res) {
    ctx.clearRect(0, 0, W, H);
    var pw = 420, ph = 132, px = (W - pw) / 2, py = H - ph - 18;
    ctx.save(); ctx.shadowColor = 'rgba(0,0,0,0.6)'; ctx.shadowBlur = 18; var g = ctx.createLinearGradient(0, py, 0, py + ph); g.addColorStop(0, '#d8b46a'); g.addColorStop(1, '#8a6a30'); ctx.fillStyle = g; rr(ctx, px, py, pw, ph, 10); ctx.fill(); ctx.restore();
    ctx.strokeStyle = '#5a4018'; ctx.lineWidth = 2; rr(ctx, px + 6, py + 6, pw - 12, ph - 12, 7); ctx.stroke();
    ctx.fillStyle = '#3a2810'; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic'; ctx.font = 'bold 28px ' + FACE; ctx.fillText(res.won ? 'The field is clear' : 'The field holds', W / 2, py + 44);
    ctx.font = '17px ' + FACE; var m = Math.floor(res.seconds / 60), s = res.seconds % 60;
    ctx.fillText((res.won ? '' : res.percent + '% cleared  ·  ') + m + ':' + (s < 10 ? '0' : '') + s + '  ·  ' + res.mistakes + (res.mistakes === 1 ? ' mine set off' : ' mines set off') + '  ·  ' + res.flags + (res.flags === 1 ? ' flag' : ' flags'), W / 2, py + 78);
    ctx.font = 'italic 15px ' + FACE; ctx.fillText('OK to leave', W / 2, py + 108);
  }
  /** a chip of the cover, for the crumble when a cell opens (one small bitmap, tinted per cell by the scene) */
  function drawChips(ctx, s) { for (var k = 0; k < 4; k++) { ctx.fillStyle = '#ffffff'; ctx.beginPath(); var x = k * s; ctx.moveTo(x + s * 0.2, s * 0.25); ctx.lineTo(x + s * 0.8, s * 0.15 + k * 0.05 * s); ctx.lineTo(x + s * 0.7, s * 0.8); ctx.lineTo(x + s * 0.3, s * 0.7); ctx.closePath(); ctx.fill(); } }
  /** the cursor for keyboard and pad: a gold frame */
  function drawCursor(ctx, s) { ctx.strokeStyle = 'rgba(255,214,120,0.95)'; ctx.lineWidth = 3; ctx.shadowColor = 'rgba(255,200,90,0.9)'; ctx.shadowBlur = 8; rr(ctx, 3, 3, s - 6, s - 6, 5); ctx.stroke(); }
  /** the board's place on the 816 x 624 stage: square cells as large as the area allows, centred under the band */
  function layout(cols, rows) { var W = 816, areaW = 744, areaH = 520, top = 66, s = Math.floor(Math.min(areaW / cols, areaH / rows)), bw = s * cols, bh = s * rows; return { W: W, H: 624, hudH: 52, s: s, bw: bw, bh: bh, bx: Math.round((W - bw) / 2), by: top + Math.round((areaH - bh) / 2) }; }
  return { VERSION: '1.0.0', FACE: FACE, STYLES: STYLES, MAT: MAT, layout: layout, cellColours: cellColours, drawCell: drawCell, drawNumber: drawNumber, drawMine: drawMine, drawSeal: drawSeal, drawWrongFlag: drawWrongFlag, drawFrame: drawFrame, drawHud: drawHud, drawResults: drawResults, drawChips: drawChips, drawCursor: drawCursor, pennant: pennant };
}());
if (typeof module !== 'undefined' && module.exports) module.exports = SapperDraw;
