/*:
 * @target MZ
 * @plugindesc [v1.0.0] Sapper 1/3 - the rules: a minefield laid over your picture, every board solvable without a guess. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * SapperCore.js holds the rules Sapper uses and touches no part of the engine. Turn it on together with
 * SapperDraw.js and Sapper.js; the order does not matter. See Readme_for_Users.md.
 */
/* SapperCore - pure rules, no engine code, runs in Node for the tests (module.exports) and in MZ (window.SapperCore).
 * Copyright (c) 2026 Core Systems Asset Factory. */
var SapperCore = (function () {
  'use strict';
  /** seeded RNG seam: a 32-bit mix and a mulberry32-style draw. Never Math.random in game logic (wing §3). */
  function mix(a, b) { var h = (a ^ Math.imul(b | 0, 0x9E3779B1)) >>> 0; h = Math.imul(h ^ (h >>> 16), 0x85EBCA6B) >>> 0; h = Math.imul(h ^ (h >>> 13), 0xC2B2AE35) >>> 0; return (h ^ (h >>> 16)) >>> 0; }
  /** @param {string} s @returns {number} a stable 32-bit hash */
  function hashString(s) { var h = 2166136261 >>> 0; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; } return h >>> 0; }
  /** @param {{rs:number}} st @returns {number} 0..1 */
  function rand(st) { st.rs = (st.rs + 0x6D2B79F5) | 0; var t = st.rs; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }

  /** three boards: densities 14-17% (the classic beginner board is 12%, intermediate 16%) */
  var SIZES = { small: { cols: 9, rows: 7, mines: 9 }, medium: { cols: 12, rows: 9, mines: 17 }, large: { cols: 16, rows: 12, mines: 32 } };
  /** @param {string} id @returns {{cols:number,rows:number,mines:number}} */
  function size(id) { return SIZES[id] || SIZES.medium; }
  var COVERED = 0, OPEN = 1, FLAGGED = 2, BOOM = 3, MAX_FIRST_OPEN = 0.6;
  var EV = { OPEN: 1, FLAG: 2, UNFLAG: 3, BOOM: 4, WON: 5, LOST: 6 }, RING = 1024;

  /** the eight neighbours of every cell, built once per board: nbr[i*8 .. i*8+nbn[i]) */
  function neighbours(cols, rows) {
    var n = cols * rows, nbr = new Int32Array(n * 8), nbn = new Uint8Array(n);
    for (var i = 0; i < n; i++) { var x = i % cols, y = (i / cols) | 0, k = 0; for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) { if (!dx && !dy) continue; var xx = x + dx, yy = y + dy; if (xx >= 0 && yy >= 0 && xx < cols && yy < rows) nbr[i * 8 + k++] = yy * cols + xx; } nbn[i] = k; }
    return { nbr: nbr, nbn: nbn };
  }
  function countAdj(mine, N, n, adj) { for (var i = 0; i < n; i++) { var c = 0; for (var k = 0; k < N.nbn[i]; k++) c += mine[N.nbr[i * 8 + k]]; adj[i] = c; } }

  /**
   * The logic solver a player would be: open from `first`, then repeat, until stuck, (a) a number whose remaining mines
   * equal its unknown neighbours flags them all and one whose remaining mines are zero opens them all, (b) the SUBSET rule
   * between two numbers that share neighbours, (c) the global count. Never guesses.
   * @param {Uint8Array} mine @param {number} cols @param {number} rows @param {number} first
   * @returns {{solved:boolean, steps:number, left:number}}
   */
  function solve(mine, cols, rows, first) {
    var n = cols * rows, N = neighbours(cols, rows), adj = new Uint8Array(n), k = new Uint8Array(n), total = 0;   // k: 0 unknown, 1 open, 2 known mine
    countAdj(mine, N, n, adj); for (var t = 0; t < n; t++) total += mine[t];
    if (mine[first]) return { solved: false, steps: 0, left: n };
    var stack = new Int32Array(n), sp = 0, steps = 0, opened = 0, safeTotal = n - total, known = 0, subsets = 0, globals = 0;
    function openAt(i) { if (k[i]) return; k[i] = 1; opened++; stack[sp++] = i; while (sp) { var c = stack[--sp]; if (adj[c] !== 0) continue; for (var q = 0; q < N.nbn[c]; q++) { var j = N.nbr[c * 8 + q]; if (!k[j]) { k[j] = 1; opened++; stack[sp++] = j; } } } }
    openAt(first); var firstOpen = opened;
    var progress = true, U = [], V = [];
    while (progress && opened < safeTotal) {
      progress = false; steps++;
      for (var c = 0; c < n; c++) {
        if (k[c] !== 1 || adj[c] === 0) continue;
        var unk = 0, km = 0; for (var q = 0; q < N.nbn[c]; q++) { var j = N.nbr[c * 8 + q]; if (k[j] === 0) unk++; else if (k[j] === 2) km++; }
        if (!unk) continue;
        var r = adj[c] - km;
        if (r === 0) { for (q = 0; q < N.nbn[c]; q++) { j = N.nbr[c * 8 + q]; if (k[j] === 0) { if (mine[j]) return { solved: false, steps: steps, left: safeTotal - opened, error: 'solver opened a mine' }; openAt(j); } } progress = true; }
        else if (r === unk) { for (q = 0; q < N.nbn[c]; q++) { j = N.nbr[c * 8 + q]; if (k[j] === 0) { k[j] = 2; known++; } } progress = true; }
      }
      if (progress) continue;
      // (b) subset: for numbers a, b with unknown sets Ua inside Ub, Ub - Ua holds exactly rb - ra mines
      for (var a = 0; a < n && !progress; a++) {
        if (k[a] !== 1 || adj[a] === 0) continue;
        U.length = 0; var ka = 0; for (q = 0; q < N.nbn[a]; q++) { j = N.nbr[a * 8 + q]; if (k[j] === 0) U.push(j); else if (k[j] === 2) ka++; }
        if (!U.length) continue; var ra = adj[a] - ka;
        var ax = a % cols, ay = (a / cols) | 0;
        for (var dy = -2; dy <= 2 && !progress; dy++) for (var dx = -2; dx <= 2 && !progress; dx++) {
          var bx = ax + dx, by = ay + dy; if ((!dx && !dy) || bx < 0 || by < 0 || bx >= cols || by >= rows) continue;
          var b = by * cols + bx; if (k[b] !== 1 || adj[b] === 0) continue;
          V.length = 0; var kb = 0; for (q = 0; q < N.nbn[b]; q++) { j = N.nbr[b * 8 + q]; if (k[j] === 0) V.push(j); else if (k[j] === 2) kb++; }
          if (V.length <= U.length) continue; var sub = true; for (var u = 0; u < U.length; u++) if (V.indexOf(U[u]) < 0) { sub = false; break; } if (!sub) continue;
          var rb = adj[b] - kb, extra = V.length - U.length, d = rb - ra; if (d === 0 || d === extra) subsets++;
          if (d === 0) { for (u = 0; u < V.length; u++) if (U.indexOf(V[u]) < 0 && k[V[u]] === 0) { if (mine[V[u]]) return { solved: false, steps: steps, left: safeTotal - opened, error: 'subset opened a mine' }; openAt(V[u]); } progress = true; }
          else if (d === extra) { for (u = 0; u < V.length; u++) if (U.indexOf(V[u]) < 0 && k[V[u]] === 0) { k[V[u]] = 2; known++; } progress = true; }
        }
      }
      if (progress) continue;
      // (c) the global count: every mine known -> the rest is safe; as many unknowns as mines left -> all mines
      var unknown = 0; for (c = 0; c < n; c++) if (k[c] === 0) unknown++;
      if ((known === total && unknown) || (unknown && unknown === total - known)) globals++;
      if (known === total && unknown) { for (c = 0; c < n; c++) if (k[c] === 0) openAt(c); progress = true; }
      else if (unknown && unknown === total - known) { for (c = 0; c < n; c++) if (k[c] === 0) { k[c] = 2; known++; } progress = true; }
    }
    return { solved: opened === safeTotal, steps: steps, left: safeTotal - opened, subsets: subsets, globals: globals, firstOpen: firstOpen };
  }

  /**
   * A new game. The mines are laid at the FIRST open, away from it, and re-laid until the solver finishes the board.
   * @param {number} seed @param {{cols:number,rows:number,mines:number,lives?:number}} o
   */
  function createGame(seed, o) {
    var cols = Math.max(4, o.cols | 0), rows = Math.max(3, o.rows | 0), n = cols * rows;
    var mines = Math.max(1, Math.min(n - 9, o.mines | 0)), N = neighbours(cols, rows), lives = Math.max(1, Math.min(9, (o.lives | 0) || 1));
    return { seed: seed >>> 0, cols: cols, rows: rows, n: n, mines: mines, N: N, mine: new Uint8Array(n), adj: new Uint8Array(n), state: new Uint8Array(n),
      laid: false, attempts: 0, phase: 'ready', lives: lives, livesMax: lives, mistakes: 0, flags: 0, opened: 0, safeTotal: n - mines, frame: 0, endFrame: 0,
      stack: new Int32Array(n), ring: new Int32Array(RING * 2), evN: 0 };
  }
  function emit(g, code, i) { var s = (g.evN % RING) * 2; g.ring[s] = code; g.ring[s + 1] = i; g.evN++; }
  /** read event k into out [code, cell]; false if it has left the ring */
  function event(g, k, out) { if (k < g.evN - RING || k >= g.evN) return false; var s = (k % RING) * 2; out[0] = g.ring[s]; out[1] = g.ring[s + 1]; return true; }
  /** lay the mines for a first open at `first`: never in its 3 x 3, re-laid until the solver finishes from it */
  function lay(g, first) {
    var st = { rs: mix(g.seed, first + 1) | 0 }, n = g.n, fx = first % g.cols, fy = (first / g.cols) | 0, pool = [], i;
    for (i = 0; i < n; i++) { var x = i % g.cols, y = (i / g.cols) | 0; if (Math.abs(x - fx) > 1 || Math.abs(y - fy) > 1) pool.push(i); }
    var mines = Math.min(g.mines, pool.length);
    for (var tries = 1; tries <= 4000; tries++) {
      g.mine.fill(0);
      for (i = 0; i < mines; i++) { var j = i + Math.floor(rand(st) * (pool.length - i)), t = pool[i]; pool[i] = pool[j]; pool[j] = t; g.mine[pool[i]] = 1; }
      g.attempts = tries;
      // solvable from the first click AND that click must not open most of the field (balance_probe v1: on the small field a
      // first click opened a median 52% and up to 100% of the safe ground, which is no game); relaxed after 1,500 layouts
      var r = solve(g.mine, g.cols, g.rows, first);
      if (r.solved && (r.firstOpen <= MAX_FIRST_OPEN * (n - mines) || tries > 1500)) break;
      // after 1,500 failed layouts one mine fewer (a guard that has never fired in the suite's sweeps: core.test prints the worst)
      if (tries % 1500 === 0 && mines > 1) mines--;
    }
    g.mines = mines; g.safeTotal = n - mines; countAdj(g.mine, g.N, n, g.adj); g.laid = true; g.phase = 'play';
  }
  function openOne(g, i) { if (g.state[i] !== COVERED) return; g.state[i] = OPEN; g.opened++; emit(g, EV.OPEN, i); }
  /** open a cell (the first open lays the board); a zero floods; a mine costs a life */
  function open(g, i) {
    if (g.phase === 'won' || g.phase === 'lost' || i < 0 || i >= g.n) return false;
    if (!g.laid) lay(g, i);
    if (g.state[i] !== COVERED) return false;
    if (g.mine[i]) { g.state[i] = BOOM; g.lives--; g.mistakes++; emit(g, EV.BOOM, i); if (g.lives <= 0) { g.phase = 'lost'; g.endFrame = g.frame; emit(g, EV.LOST, i); } return true; }
    openOne(g, i);
    if (g.adj[i] === 0) { var sp = 0, s = g.stack, N = g.N; s[sp++] = i; while (sp) { var c = s[--sp]; for (var q = 0; q < N.nbn[c]; q++) { var j = N.nbr[c * 8 + q]; if (g.state[j] === COVERED && !g.mine[j]) { openOne(g, j); if (g.adj[j] === 0) s[sp++] = j; } } } }
    if (g.opened >= g.safeTotal) { g.phase = 'won'; g.endFrame = g.frame; emit(g, EV.WON, i); }
    return true;
  }
  /** plant or lift a flag on a covered cell */
  function flag(g, i) {
    if (g.phase === 'won' || g.phase === 'lost' || i < 0 || i >= g.n) return false;
    if (g.state[i] === COVERED) { g.state[i] = FLAGGED; g.flags++; emit(g, EV.FLAG, i); return true; }
    if (g.state[i] === FLAGGED) { g.state[i] = COVERED; g.flags--; emit(g, EV.UNFLAG, i); return true; }
    return false;
  }
  /** on an open number with as many flags around it as its number: open every other covered neighbour */
  function chord(g, i) {
    if (g.state[i] !== OPEN || g.adj[i] === 0) return false;
    var N = g.N, f = 0, q; for (q = 0; q < N.nbn[i]; q++) { var j = N.nbr[i * 8 + q]; if (g.state[j] === FLAGGED || g.state[j] === BOOM) f++; }
    if (f !== g.adj[i]) return false;
    for (q = 0; q < N.nbn[i]; q++) { j = N.nbr[i * 8 + q]; if (g.state[j] === COVERED) open(g, j); }
    return true;
  }
  /** per frame: the clock. Allocates nothing. */
  function step(g) {
    if (g.phase === 'play') g.frame++;
  }
  /** the next safe move the solver would make, or -1 (used by autoplay and the in-engine tests, never by players) */
  function hint(g) {
    for (var c = 0; c < g.n; c++) if (g.state[c] === COVERED && !g.mine[c]) { var N = g.N; for (var q = 0; q < N.nbn[c]; q++) if (g.state[N.nbr[c * 8 + q]] === OPEN) return c; }
    for (c = 0; c < g.n; c++) if (g.state[c] === COVERED && !g.mine[c]) return c;
    return -1;
  }
  /** play the board out with the safe moves (tests and captures only) */
  function autoplay(g) { var guard = g.n * 2; while (g.phase === 'play' && guard-- > 0) { var c = hint(g); if (c < 0) break; open(g, c); } }
  function results(g) { var sec = Math.floor((g.phase === 'play' ? g.frame : g.endFrame) / 60); return { won: g.phase === 'won', lost: g.phase === 'lost', seconds: sec, mistakes: g.mistakes, flags: g.flags, percent: g.safeTotal ? Math.round(100 * Math.min(g.opened, g.safeTotal) / g.safeTotal) : 0, mines: g.mines }; }

  return { VERSION: '1.0.0', mix: mix, hashString: hashString, rand: rand, SIZES: SIZES, size: size, COVERED: COVERED, OPEN: OPEN, FLAGGED: FLAGGED, BOOM: BOOM, EV: EV, RING: RING,
    createGame: createGame, solve: solve, lay: lay, open: open, flag: flag, chord: chord, step: step, hint: hint, autoplay: autoplay, results: results, event: event };
}());
if (typeof module !== 'undefined' && module.exports) module.exports = SapperCore;
