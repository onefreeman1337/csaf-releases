/*:
 * @target MZ
 * @plugindesc [v1.0.0] Sapper 3/3 - Minesweeper over one of your pictures: clear the field to uncover it. Every board solvable without a guess.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 * @base SapperCore
 * @base SapperDraw
 * @orderAfter SapperDraw
 *
 * @param openSe
 * @text Sound: ground cleared
 * @desc An SE from audio/se. (None) = silent.
 * @type file
 * @dir audio/se
 * @default Sand
 *
 * @param flagSe
 * @text Sound: a flag planted
 * @desc An SE from audio/se. (None) = silent.
 * @type file
 * @dir audio/se
 * @default Equip1
 *
 * @param boomSe
 * @text Sound: a mine goes off
 * @desc An SE from audio/se. (None) = silent.
 * @type file
 * @dir audio/se
 * @default Explosion1
 *
 * @param winSe
 * @text Sound: the field is clear
 * @desc An SE from audio/se. (None) = silent.
 * @type file
 * @dir audio/se
 * @default Chime2
 *
 * @param loseSe
 * @text Sound: the field holds
 * @desc An SE from audio/se. (None) = silent.
 * @type file
 * @dir audio/se
 * @default Collapse1
 *
 * @command sapper
 * @text Start Sapper
 * @desc Clear a minefield laid over one of your pictures. The event waits until it is over.
 *
 * @arg picture
 * @text Picture
 * @type file
 * @dir img/pictures
 * @default
 *
 * @arg size
 * @text Field
 * @type select
 * @option small
 * @option medium
 * @option large
 * @desc small 9 x 7 (9 mines), medium 12 x 9 (17), large 16 x 12 (32).
 * @default medium
 *
 * @arg mines
 * @text Mines
 * @type number
 * @min 0
 * @desc 0 = the field's own count. More is harder; the board is always still solvable without a guess.
 * @default 0
 *
 * @arg cover
 * @text Ground
 * @type select
 * @option auto
 * @option turf
 * @option sand
 * @option snow
 * @option slate
 * @desc What the field is made of, tinted from your picture. Auto picks one from the seed.
 * @default auto
 *
 * @arg mineStyle
 * @text Mines drawn as
 * @type select
 * @option iron
 * @option troop
 * @desc iron = drawn mines. troop = the enemies of the troop below, pressed into wax seals.
 * @default iron
 *
 * @arg troop
 * @text Troop (for troop mines)
 * @type troop
 * @default 0
 *
 * @arg lives
 * @text Lives
 * @type number
 * @min 1
 * @max 9
 * @desc How many mines the player may set off. The last one ends the game.
 * @default 1
 *
 * @arg secondsVariable
 * @text Variable: seconds taken
 * @type variable
 * @default 0
 *
 * @arg mistakesVariable
 * @text Variable: mines set off
 * @type variable
 * @default 0
 *
 * @arg flagsVariable
 * @text Variable: flags planted
 * @type variable
 * @default 0
 *
 * @arg percentVariable
 * @text Variable: percent cleared
 * @type variable
 * @default 0
 *
 * @arg clearedSwitch
 * @text Switch: cleared
 * @type switch
 * @default 0
 *
 * @arg seed
 * @text Seed (optional)
 * @desc Blank = a new field every time. A number or word = the same field for the same first click, every time.
 * @default
 *
 * @help
 * ============================================================================
 * SAPPER v1.0.0 - clear the field, uncover the picture
 * ============================================================================
 * One of your pictures lies under a minefield the plugin lays over it: turf,
 * sand, snow or slate, each cell tinted from the picture beneath it. Every
 * cell the player clears uncovers that patch of the picture; a number says how
 * many mines touch it. Clear every safe cell and the picture is yours.
 *
 * NO GUESSING: every field is generated after the first click, away from it,
 * and laid again until a logic solver can finish it from there, so a careful
 * player never has to guess.
 *
 * INSTALLING: copy SapperCore.js, SapperDraw.js and Sapper.js into js/plugins
 * and enable all three. Any order works.
 *
 * USING IT: the plugin command "Start Sapper" with a picture from
 * img/pictures. The event waits while the game runs. Script call:
 *   Sapper.start({ picture: 'Castle', size: 'large', cover: 'snow' });
 *
 * CONTROLS: mouse: left click clears, right click plants or lifts a flag,
 * a click on a number whose flags are all placed clears around it. Touch: tap
 * clears, a long press flags. Keyboard and pad: move with the arrows, OK
 * clears, Shift or Cancel flags. On the results, OK or a click leaves.
 *
 * COMPATIBILITY: Sapper adds its own scene and replaces nothing. It extends
 * two engine methods, each by saving the original and calling it:
 * Game_System.initialize (its save record) and Game_Interpreter.updateWaitMode
 * (so the event waits while the game runs).
 *
 * TERMS OF USE: commercial and non-commercial use permitted in RPG Maker
 * projects, credit appreciated but not required. Do not redistribute the
 * source as an asset pack. Every line of this plugin was written with AI
 * assistance.
 */

var Sapper = Sapper || {};

(function (M) {
  'use strict';
  var NAME = 'Sapper', SCHEMA = 1;
  var raw = (typeof PluginManager !== 'undefined') ? PluginManager.parameters(NAME) : {};
  function num(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; var n = Number(v); return isFinite(n) ? n : d; }
  function str(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; return String(v).trim(); }
  /** a sound parameter: (None) in the Plugin Manager is '' and means SILENT; only a key absent from plugins.js takes the
   *  default (Leadlight docs_probe B1, 2026-10-11) */
  function se(v, d) { return (v === undefined || v === null) ? d : String(v).trim(); }
  M.params = { openSe: se(raw.openSe, 'Sand'), flagSe: se(raw.flagSe, 'Equip1'), boomSe: se(raw.boomSe, 'Explosion1'), winSe: se(raw.winSe, 'Chime2'), loseSe: se(raw.loseSe, 'Collapse1') };
  var _deps = null;
  /** ⛔ siblings resolved at FIRST USE, never at load time: the buyer chooses the load order (wing §8 trap 2) */
  function deps() {
    if (_deps) return _deps;
    var core = (typeof SapperCore !== 'undefined') ? SapperCore : null, draw = (typeof SapperDraw !== 'undefined') ? SapperDraw : null;
    if (!core || !draw) { if (!deps._w) { deps._w = true; console.error('Sapper: enable SapperCore.js and SapperDraw.js in the Plugin Manager too.'); } return null; }
    _deps = { core: core, draw: draw }; return _deps;
  }
  M.deps = deps;
  function fresh() { return { v: SCHEMA, played: 0, cleared: 0, best: 0 }; }
  M.record = function () {
    if (typeof $gameSystem === 'undefined' || !$gameSystem) return fresh();
    var s = $gameSystem._csafSapper; if (!s || s.v == null) { s = fresh(); $gameSystem._csafSapper = s; } return s;
  };
  var _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () { _Game_System_initialize.call(this); this._csafSapper = fresh(); };
  /** a request from command arguments (strings from the editor, or plain values from a script call) */
  M.request = function (args) {
    var d = deps(); if (!d) return null; args = args || {};
    var seedText = str(args.seed, ''), seed = seedText === '' ? d.core.mix(d.core.hashString('sapper') ^ (M.record().played * 7919), (typeof $gameSystem !== 'undefined' && $gameSystem ? $gameSystem.playtime() : 0) >>> 0)
      : (/^\d+$/.test(seedText) ? (Number(seedText) >>> 0) : d.core.hashString(seedText));
    var sizeId = ['small', 'medium', 'large'].indexOf(str(args.size, 'medium')) >= 0 ? str(args.size, 'medium') : 'medium', sz = d.core.size(sizeId);
    var cover = str(args.cover, 'auto'), mines = Math.floor(num(args.mines, 0));
    return { seed: seed, picture: str(args.picture, ''), size: sizeId, cols: sz.cols, rows: sz.rows,
      mines: mines > 0 ? Math.min(mines, Math.floor(sz.cols * sz.rows * 0.3)) : sz.mines,
      cover: d.draw.STYLES.indexOf(cover) >= 0 ? cover : d.draw.STYLES[seed % d.draw.STYLES.length],
      mineStyle: str(args.mineStyle, 'iron') === 'troop' ? 'troop' : 'iron', troop: Math.max(0, Math.floor(num(args.troop, 0))), lives: Math.max(1, Math.min(9, Math.floor(num(args.lives, 1)))),
      secondsVariable: Math.max(0, Math.floor(num(args.secondsVariable, 0))), mistakesVariable: Math.max(0, Math.floor(num(args.mistakesVariable, 0))), flagsVariable: Math.max(0, Math.floor(num(args.flagsVariable, 0))),
      percentVariable: Math.max(0, Math.floor(num(args.percentVariable, 0))), clearedSwitch: Math.max(0, Math.floor(num(args.clearedSwitch, 0))), isRequest: true };
  };
  M._open = false;
  /** start a game (script call: the command's options). Without a picture it starts nothing and says so once; refused while one is open */
  M.start = function (opts) {
    var req = opts && opts.isRequest ? opts : M.request(opts || {});
    if (!req || M._open) return false;
    if (!req.picture) { if (!M._warnedPic) { M._warnedPic = true; console.warn('Sapper: name a picture from img/pictures in the command. No game started.'); } return false; }
    if (SceneManager._scene && SceneManager._scene.isStarted && !SceneManager._scene.isStarted()) return false;   // a map still loading (Inscribe breakit X4)
    M._open = true; SceneManager.push(Scene_Sapper); SceneManager.prepareNextScene(req); return true;
  };
  M.isOpen = function () { return M._open; };
  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) PluginManager.registerCommand(NAME, 'sapper', function (args) { if (M.start(M.request(args))) this.setWaitMode('sapper'); });
  var _updateWaitMode = Game_Interpreter.prototype.updateWaitMode;
  Game_Interpreter.prototype.updateWaitMode = function () {
    if (this._waitMode === 'sapper') { if (SceneManager._scene instanceof Scene_Sapper || SceneManager._nextScene instanceof Scene_Sapper) return true; this._waitMode = ''; return false; }
    return _updateWaitMode.call(this);
  };
  M.VERSION = '1.0.0';
}(Sapper));

//=============================================================================
// Scene_Sapper
//=============================================================================

function Scene_Sapper() { this.initialize.apply(this, arguments); }
Scene_Sapper.prototype = Object.create(Scene_Base.prototype);
Scene_Sapper.prototype.constructor = Scene_Sapper;
Scene_Sapper.W = 816; Scene_Sapper.H = 624; Scene_Sapper.CHIPS = 32;
Scene_Sapper.prototype.prepare = function (req) { this._req = req; };
Scene_Sapper.prototype.create = function () {
  Scene_Base.prototype.create.call(this);
  var req = this._req; this._d = Sapper.deps(); this._pic = ImageManager.loadPicture(req.picture);
  this._mode = 'loading'; this._t = 0; this._read = 0; this._ev = [0, 0]; this._cur = 0; this._press = -1; this._pressFlagged = false;
  var W = Scene_Sapper.W, H = Scene_Sapper.H, s = Math.min(Graphics.width / W, Graphics.height / H);
  this._k = s; this._ox = Math.round((Graphics.width - W * s) / 2); this._oy = Math.round((Graphics.height - H * s) / 2);
  var bg = new Sprite(new Bitmap(Graphics.width, Graphics.height)); bg.bitmap.fillAll('#0d0b0a'); this.addChild(bg);
  this._root = new Sprite(); this._root.scale.x = this._root.scale.y = s; this._root.x = this._ox; this._root.y = this._oy; this.addChild(this._root);
  // troop mines: the troop's enemies, front or side view as the project battles
  this._seals = [];
  if (req.mineStyle === 'troop' && $dataTroops[req.troop]) {
    var side = $gameSystem.isSideView(), seen = {};
    $dataTroops[req.troop].members.forEach(function (m) { var e = $dataEnemies[m.enemyId]; if (e && e.battlerName && !seen[e.battlerName]) { seen[e.battlerName] = 1; this._seals.push(side ? ImageManager.loadSvEnemy(e.battlerName) : ImageManager.loadEnemy(e.battlerName)); } }, this);
  }
};
Scene_Sapper.prototype.start = function () { Scene_Base.prototype.start.call(this); this.startFadeIn(this.fadeSpeed(), false); };
Scene_Sapper.prototype.ready = function () { if (!this._pic.isReady()) return false; for (var i = 0; i < this._seals.length; i++) if (!this._seals[i].isReady()) return false; return true; };
/** built once the picture has loaded: read its pixels ONCE (never during play, Probe_Doctrine §27a) */
Scene_Sapper.prototype.build = function () {
  var C = this._d.core, D = this._d.draw, req = this._req, L = this._L = D.layout(req.cols, req.rows), root = this._root, pic = this._pic, pw = Math.max(1, pic.width), ph = Math.max(1, pic.height);
  var px = pic.canvas.getContext('2d').getImageData(0, 0, pw, ph).data;
  this._cols = D.cellColours(px, pw, ph, req.cols, req.rows, L.bw, L.bh);
  this._game = C.createGame(req.seed, { cols: req.cols, rows: req.rows, mines: req.mines, lives: req.lives });
  this._frame = new Sprite(new Bitmap(L.W, L.H)); D.drawFrame(this._frame.bitmap.context, L.W, L.H, L.bx, L.by, L.bw, L.bh, L.hudH, req.cover); this._frame.bitmap._baseTexture.update(); root.addChild(this._frame);
  var k = Math.max(L.bw / pw, L.bh / ph), ps = new Sprite(pic); ps.scale.x = ps.scale.y = k; ps.x = L.bx + (L.bw - pw * k) / 2; ps.y = L.by + (L.bh - ph * k) / 2;
  var mask = new PIXI.Graphics(); mask.beginFill(0xffffff); mask.drawRect(L.bx, L.by, L.bw, L.bh); mask.endFill(); root.addChild(mask); ps.mask = mask; root.addChild(ps); this._picSprite = ps;
  this._cover = new Sprite(new Bitmap(L.bw, L.bh)); this._cover.x = L.bx; this._cover.y = L.by; root.addChild(this._cover);
  for (var i = 0; i < this._game.n; i++) this.drawCell(i);
  this._cover.bitmap._baseTexture.update();
  var cs = Math.max(6, Math.round(L.s * 0.22)), cb = new Bitmap(cs * 4, cs); D.drawChips(cb.context, cs); cb._baseTexture.update();
  this._chips = []; for (var c = 0; c < Scene_Sapper.CHIPS; c++) { var sp = new Sprite(cb); sp.setFrame((c % 4) * cs, 0, cs, cs); sp.anchor.x = sp.anchor.y = 0.5; sp.visible = false; sp._life = 0; sp._vx = 0; sp._vy = 0; sp._vr = 0; this._chips.push(sp); root.addChild(sp); }
  this._chipNext = 0;
  var cur = new Bitmap(L.s, L.s); D.drawCursor(cur.context, L.s); cur._baseTexture.update(); this._cursor = new Sprite(cur); root.addChild(this._cursor);
  this._cur = Math.floor(this._game.rows / 2) * this._game.cols + Math.floor(this._game.cols / 2); this.placeCursor();
  this._hud = new Sprite(new Bitmap(L.W, L.hudH)); this._hud.y = 4; root.addChild(this._hud); this._hudKey = -1; this.drawHud();
  this._results = new Sprite(new Bitmap(L.W, L.H)); this._results.visible = false; root.addChild(this._results);
  this._mode = 'play';
};
/** one cell of the cover, by its state: covered (material, tinted) or flagged, or opened (cleared to the picture, its number) */
Scene_Sapper.prototype.drawCell = function (i) {
  var C = this._d.core, D = this._d.draw, g = this._game, L = this._L, ctx = this._cover.bitmap.context, x = (i % g.cols) * L.s, y = Math.floor(i / g.cols) * L.s, st = g.state[i], c = this._cols, o = i * 3;
  if (st === C.OPEN) { ctx.clearRect(x, y, L.s, L.s); if (g.adj[i]) D.drawNumber(ctx, x, y, L.s, this._req.cover, g.adj[i]); return; }
  if (st === C.BOOM) { ctx.clearRect(x, y, L.s, L.s); this.drawMine(ctx, i, x, y, true); return; }
  D.drawCell(ctx, x, y, L.s, this._req.cover, [c[o], c[o + 1], c[o + 2]], this._req.seed ^ (i * 2654435761), st === C.FLAGGED);
};
Scene_Sapper.prototype.drawMine = function (ctx, i, x, y, burst) {
  var D = this._d.draw, L = this._L;
  if (this._seals.length) D.drawSeal(ctx, x, y, L.s, this._seals[(i * 7 + this._req.seed) % this._seals.length].canvas, burst); else D.drawMine(ctx, x, y, L.s, burst);
};
Scene_Sapper.prototype.drawHud = function () {
  var g = this._game, sec = Math.floor(g.frame / 60), key = ((g.mines - g.flags) * 16 + g.lives) * 100000 + sec; if (key === this._hudKey) return; this._hudKey = key;
  this._d.draw.drawHud(this._hud.bitmap.context, Scene_Sapper.W, this._L.hudH, { title: 'Sapper', minesLeft: g.mines - g.flags, lives: g.lives, livesMax: g.livesMax, seconds: sec }); this._hud.bitmap._baseTexture.update();
};
Scene_Sapper.prototype.placeCursor = function () { var g = this._game, L = this._L; this._cursor.x = L.bx + (this._cur % g.cols) * L.s; this._cursor.y = L.by + Math.floor(this._cur / g.cols) * L.s; };
Scene_Sapper.prototype.update = function () {
  Scene_Base.prototype.update.call(this);
  if (this._mode === 'loading') { if (this.ready()) this.build(); return; }
  this._t++;
  if (this._mode === 'play') this.updatePlay();
  else if (this._mode === 'clearing') this.updateClearing();
  else if (this._mode === 'holding') { if (++this._holdT >= 50) this.showResults(); }
  else if (this._mode === 'results' && this._t > 30 && (Input.isTriggered('ok') || TouchInput.isTriggered())) this.leave();
  this.updateChips();
  if (this._cursor) this._cursor.opacity = this._mode === 'play' ? 170 + Math.round(Math.sin(this._t * 0.1) * 70) : 0;
};
/** the cell under the pointer, or -1 */
Scene_Sapper.prototype.cellAt = function (sx, sy) {
  var L = this._L, g = this._game, x = (sx - this._ox) / this._k - L.bx, y = (sy - this._oy) / this._k - L.by;
  if (x < 0 || y < 0 || x >= L.bw || y >= L.bh) return -1; return Math.floor(y / L.s) * g.cols + Math.floor(x / L.s);
};
Scene_Sapper.prototype.updatePlay = function () {
  var C = this._d.core, g = this._game;
  // pointer: open on RELEASE (so a touch long-press can flag without opening), right click flags, a hover moves the cursor
  var hit = this.cellAt(TouchInput.x, TouchInput.y);
  if (TouchInput.isTriggered()) { this._press = hit; this._pressFlagged = false; }
  if (this._press >= 0 && !this._pressFlagged && TouchInput.isLongPressed()) { this.act('flag', this._press); this._pressFlagged = true; }
  if (TouchInput.isReleased()) { if (this._press >= 0 && !this._pressFlagged && hit === this._press) this.act('open', hit); this._press = -1; }
  if (TouchInput.isCancelled() && hit >= 0) this.act('flag', hit);
  if (hit >= 0 && hit !== this._cur && (TouchInput.isMoved() || (TouchInput.isHovered && TouchInput.isHovered()))) { this._cur = hit; this.placeCursor(); }
  // keyboard and pad
  var x = this._cur % g.cols, y = Math.floor(this._cur / g.cols), moved = false;
  if (Input.isRepeated('right')) { x = (x + 1) % g.cols; moved = true; } else if (Input.isRepeated('left')) { x = (x + g.cols - 1) % g.cols; moved = true; }
  if (Input.isRepeated('down')) { y = (y + 1) % g.rows; moved = true; } else if (Input.isRepeated('up')) { y = (y + g.rows - 1) % g.rows; moved = true; }
  if (moved) { this._cur = y * g.cols + x; this.placeCursor(); SoundManager.playCursor(); }
  if (Input.isTriggered('ok')) this.act('open', this._cur);
  else if (Input.isTriggered('shift') || Input.isTriggered('cancel')) this.act('flag', this._cur);
  C.step(g); this.readEvents(); this.drawHud();
  if (g.phase === 'won') { this._mode = 'clearing'; this._clearT = 0; this.playSe(Sapper.params.winSe, 90); }
  else if (g.phase === 'lost') { this._mode = 'holding'; this._holdT = 0; this.revealMines(); this.playSe(Sapper.params.loseSe, 90); }
};
/** open (a click on an open number chords) or flag */
Scene_Sapper.prototype.act = function (what, i) {
  var C = this._d.core, g = this._game; if (i < 0 || i >= g.n) return;
  if (what === 'flag') { if (C.flag(g, i)) this.playSe(Sapper.params.flagSe, 70); return; }
  if (g.state[i] === C.OPEN) { C.chord(g, i); return; }
  C.open(g, i);
};
/** the core's events since the last frame: redraw what changed, throw chips, play sounds. No allocation. */
Scene_Sapper.prototype.readEvents = function () {
  var C = this._d.core, g = this._game, E = C.EV, ev = this._ev, dirty = false, opened = 0, P = Sapper.params;
  if (g.evN - this._read > C.RING) this._read = g.evN - C.RING;
  for (; this._read < g.evN; this._read++) {
    if (!C.event(g, this._read, ev)) continue;
    var code = ev[0], i = ev[1];
    if (code === E.OPEN || code === E.FLAG || code === E.UNFLAG || code === E.BOOM) { this.drawCell(i); dirty = true; }
    if (code === E.OPEN) { if (opened++ < 8) this.throwChips(i); }
    else if (code === E.BOOM) this.playSe(P.boomSe, 85);
  }
  if (opened) this.playSe(P.openSe, 55);
  if (dirty) this._cover.bitmap._baseTexture.update();
};
Scene_Sapper.prototype.playSe = function (name, vol) { if (name) AudioManager.playSe({ name: name, volume: vol, pitch: 100, pan: 0 }); };
/** an opened cell crumbles: four chips of its own colour fall away */
Scene_Sapper.prototype.throwChips = function (i) {
  var g = this._game, L = this._L, c = this._cols, o = i * 3, m = this._d.draw.MAT[this._req.cover], f = function (a, b) { return Math.round(a * 0.62 + b * 0.38); };
  var tint = (f(m.base[0], c[o]) << 16) | (f(m.base[1], c[o + 1]) << 8) | f(m.base[2], c[o + 2]), x = L.bx + (i % g.cols) * L.s, y = L.by + Math.floor(i / g.cols) * L.s;
  for (var k = 0; k < 4; k++) { var s = this._chips[this._chipNext]; this._chipNext = (this._chipNext + 1) % this._chips.length; s.x = x + L.s * (0.25 + 0.17 * k); s.y = y + L.s * (0.35 + 0.12 * (k % 2)); s._vx = (k - 1.5) * 0.7; s._vy = -1.2 - (k % 2) * 0.6; s._vr = k % 2 ? 0.14 : -0.12; s._life = 40; s.tint = tint; s.opacity = 255; s.rotation = k; s.visible = true; }
};
Scene_Sapper.prototype.updateChips = function () {
  if (!this._chips) return;
  for (var i = 0; i < this._chips.length; i++) { var s = this._chips[i]; if (s._life <= 0) continue; s._life--; s._vy += 0.22; s.x += s._vx; s.y += s._vy; s.rotation += s._vr; s.opacity = s._life < 16 ? s._life * 16 : 255; if (s._life <= 0) s.visible = false; }
};
/** the field holds: every mine shown where it lay, every wrong flag crossed */
Scene_Sapper.prototype.revealMines = function () {
  var C = this._d.core, D = this._d.draw, g = this._game, L = this._L, ctx = this._cover.bitmap.context;
  for (var i = 0; i < g.n; i++) { var x = (i % g.cols) * L.s, y = Math.floor(i / g.cols) * L.s;
    if (g.mine[i] && g.state[i] === C.COVERED) { ctx.clearRect(x, y, L.s, L.s); this.drawMine(ctx, i, x, y, false); }
    else if (!g.mine[i] && g.state[i] === C.FLAGGED) D.drawWrongFlag(ctx, x, y, L.s); }
  this._cover.bitmap._baseTexture.update();
};
/** the field is clear: what cover is left lifts away over 40 frames, then the picture is shown whole with the results */
Scene_Sapper.prototype.updateClearing = function () {
  this._clearT++; this._cover.opacity = Math.max(0, 255 - this._clearT * 7); this._cover.y = this._L.by - this._clearT * 0.4;
  if (this._clearT >= 40) { this._cover.visible = false; this.showResults(); }
};
Scene_Sapper.prototype.showResults = function () {
  var res = this._d.core.results(this._game), b = this._results.bitmap;
  this._d.draw.drawResults(b.context, Scene_Sapper.W, Scene_Sapper.H, res); b._baseTexture.update();
  this._results.visible = true; this._res = res; this._mode = 'results'; this._t = 0;
};
Scene_Sapper.prototype.leave = function () {
  if (this._mode === 'leaving') return;
  var req = this._req, m = this._res, rec = Sapper.record();
  if (req.secondsVariable > 0) $gameVariables.setValue(req.secondsVariable, m.seconds);
  if (req.mistakesVariable > 0) $gameVariables.setValue(req.mistakesVariable, m.mistakes);
  if (req.flagsVariable > 0) $gameVariables.setValue(req.flagsVariable, m.flags);
  if (req.percentVariable > 0) $gameVariables.setValue(req.percentVariable, m.percent);
  if (req.clearedSwitch > 0) $gameSwitches.setValue(req.clearedSwitch, m.won);
  rec.played++; if (m.won) rec.cleared++; rec.best = Math.max(rec.best, m.percent);
  this._mode = 'leaving'; this.popScene();
};
Scene_Sapper.prototype.stop = function () { Scene_Base.prototype.stop.call(this); this.startFadeOut(this.fadeSpeed(), false); };
Scene_Sapper.prototype.terminate = function () { Scene_Base.prototype.terminate.call(this); Sapper._open = false; };
