/*:
 * @target MZ
 * @plugindesc [v1.0.0] Ajar: the drawers, barrels, jars, sacks and shelves in your own tileset open when searched, cut from their own pixels.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io/
 * @base AjarCore
 * @orderAfter AjarCore
 * @orderAfter Threshold
 * @orderAfter Smithereens
 *
 * @help Ajar.js
 *
 * Search the furniture. Drawers slide out, lids lift off, sacks slump open and books tip out of line, all cut from
 * YOUR furniture tiles. No opening sprite sheets to draw.
 *
 * HOW TO MARK A PIECE
 *   1. Make an event and give it a TILE as its graphic (the dresser, barrel, jar... from your own tileset, B to E).
 *   2. Put this in the event's Note box:   <ajar: drawer>
 *   That is all. Ajar reads that tile's pixels once when the map loads and works out how it opens.
 *   The event's commands stay yours: Show Text, Change Items, a loot plugin, anything.
 *
 * KINDS (the word after the colon)
 *   drawer   a drawer slides out toward the camera: dressers, desks, nightstands, cabinets, chests of drawers
 *            (also: dresser, desk, cabinet, nightstand). It finds the drawer fronts in the picture and opens the
 *            top one of the big fronts. <ajar: drawer 2> opens the 2nd front from the top; <ajar: drawer all>
 *            opens every front, one after the other.
 *   lid      a lid lifts, tips and comes to rest askew: barrels, crates, jars, pots, urns, baskets, boxes
 *            (also: barrel, crate, jar, pot, urn, basket, box). It finds the rim by the colour break.
 *            <ajar: lid rim 12> says the lid is the top 12 pixels; <ajar: lid left> sets it down to the left.
 *   sack     the tie loosens, the gathered top sinks into a collar round a dark mouth, the body slumps (also: bag, pouch)
 *   shelf    books tip out of line, one pulled toward the camera (also: bookshelf, bookcase)
 *   A piece two or more tiles big (a wide desk, a tall bookcase): mark EVERY tile of it with the same note and
 *   they open as one. Tiles join only when they sit side by side on your TILESET the same way they sit on the map,
 *   so a dresser placed beside a desk stays its own piece. "nogroup" keeps a piece from joining anything.
 *
 * THE SEARCH
 *   When the player searches a marked event (Action Button, Player Touch or Event Touch), it opens, then the event's
 *   own commands run. If that page gives something (Change Items, Change Weapons, Change Armors, Change Gold, an
 *   increase by a constant), the item's own icon rises out of the dark inside. A page that gives nothing shakes a
 *   little dust out instead (turn it off with "nodust" in the note or the parameter). Then the piece settles and
 *   RESTS AJAR: a drawer stays half out, a lid stays askew, so the player can see what they have already searched.
 *   That searched state is saved with the game and survives leaving the map.
 *   Opt in to a faint glint on pieces nobody has searched yet: the Glint parameter, or "glint" in one note.
 *   "manual" in the note: the event never opens by itself; use the plugin commands.
 *
 * PLUGIN COMMANDS
 *   Search Piece   open it the way a search does (rise or dust, then rest ajar). Event ID 0 = this event.
 *   Open Piece / Close Piece   open fully, or close, with no search (for cutscenes)
 *   Forget Search  close it and mark it unsearched again (a respawning stash)
 *   Show Found Icon  rise any icon out of an open piece (for loot plugins that do not use Change Items)
 *
 * WHAT IT DOES NOT DO
 *   It decides nothing about loot: what is found is your event's business. The inside of a drawer or jar is never
 *   guessed; it is darkness, and the found item rises out of it. Hinged cupboard and wardrobe doors are Threshold's
 *   (<threshold: door>); breaking a barrel is Smithereens' (<smash>). An event that carries <threshold> or <smash>
 *   is theirs and Ajar leaves it alone. Treasure chests are not in scope.
 *
 * Load AjarCore.js above this file (the other way round also works: this file finds it at first use).
 * Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.
 *
 * @param openFrames
 * @text Open time
 * @type number
 * @min 4
 * @max 120
 * @default 16
 * @desc Frames a piece takes to open (60 = one second).
 *
 * @param holdFrames
 * @text Hold open
 * @type number
 * @min 0
 * @max 600
 * @default 40
 * @desc Frames a searched piece stays fully open before it settles (it also waits for the event to finish).
 *
 * @param restPose
 * @text Searched pieces rest
 * @type select
 * @option ajar
 * @option open
 * @option closed
 * @default ajar
 * @desc ajar: a drawer half out, a lid askew. open: fully open. closed: shut again.
 *
 * @param itemRise
 * @text Found item rises
 * @type boolean
 * @default true
 *
 * @param riseFrames
 * @text Rise time
 * @type number
 * @min 10
 * @max 240
 * @default 54
 *
 * @param goldIcon
 * @text Gold icon
 * @type number
 * @min 0
 * @default 314
 * @desc The IconSet index shown when a search gives gold.
 *
 * @param dust
 * @text Dust on an empty search
 * @type boolean
 * @default true
 *
 * @param glint
 * @text Glint on unsearched pieces
 * @type boolean
 * @default false
 *
 * @param glintCycle
 * @text Glint interval
 * @type number
 * @min 60
 * @max 3600
 * @default 300
 * @desc Frames between two glints on one piece.
 *
 * @param seDrawer
 * @text Sound: drawer
 * @type file
 * @dir audio/se/
 * @default
 *
 * @param seLid
 * @text Sound: lid
 * @type file
 * @dir audio/se/
 * @default
 *
 * @param seSack
 * @text Sound: sack
 * @type file
 * @dir audio/se/
 * @default
 *
 * @param seShelf
 * @text Sound: shelf
 * @type file
 * @dir audio/se/
 * @default
 *
 * @command search
 * @text Search Piece
 * @desc Open a piece the way a search does: the found icon rises (or dust), then it rests ajar.
 *
 * @arg eventId
 * @text Event ID
 * @type number
 * @min 0
 * @default 0
 * @desc 0 = this event.
 *
 * @command open
 * @text Open Piece
 * @desc Open a piece fully, with no search.
 *
 * @arg eventId
 * @text Event ID
 * @type number
 * @min 0
 * @default 0
 *
 * @arg wait
 * @text Wait for completion
 * @type boolean
 * @default false
 *
 * @command close
 * @text Close Piece
 * @desc Close a piece.
 *
 * @arg eventId
 * @text Event ID
 * @type number
 * @min 0
 * @default 0
 *
 * @arg wait
 * @text Wait for completion
 * @type boolean
 * @default false
 *
 * @command forget
 * @text Forget Search
 * @desc Close a piece and mark it unsearched again.
 *
 * @arg eventId
 * @text Event ID
 * @type number
 * @min 0
 * @default 0
 *
 * @command rise
 * @text Show Found Icon
 * @desc Rise an icon out of an open piece (for loot that is not given by Change Items).
 *
 * @arg eventId
 * @text Event ID
 * @type number
 * @min 0
 * @default 0
 *
 * @arg iconIndex
 * @text Icon
 * @type icon
 * @default 176
 */
(() => {
  'use strict';
  const NAME = 'Ajar';
  const RAW = PluginManager.parameters(NAME);
  // parameters arrive as STRINGS and Number('') is 0: a blank is the default, never zero (wing §16)
  const num = (v, d, lo, hi) => { if (v === undefined || v === null || String(v).trim() === '') return d; const n = Number(v); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d; };
  // a boolean is 'true' or 'false'; anything else (blank, a typo) is the default, never a silent off
  const bool = (v, d) => (String(v) === 'true' ? true : String(v) === 'false' ? false : d);
  const P = {
    openFrames: num(RAW.openFrames, 16, 4, 120),
    holdFrames: num(RAW.holdFrames, 40, 0, 600),
    restPose: ['ajar', 'open', 'closed'].indexOf(String(RAW.restPose)) >= 0 ? String(RAW.restPose) : 'ajar',
    itemRise: bool(RAW.itemRise, true),
    riseFrames: num(RAW.riseFrames, 54, 10, 240),
    goldIcon: num(RAW.goldIcon, 314, 0, 100000),
    dust: bool(RAW.dust, true),
    glint: bool(RAW.glint, false),
    glintCycle: num(RAW.glintCycle, 300, 60, 3600),
    se: { drawer: RAW.seDrawer || '', lid: RAW.seLid || '', sack: RAW.seSack || '', shelf: RAW.seShelf || '' },
  };
  // how far open a searched piece rests, by kind: a drawer half out; a lid already rests askew at the end of its
  // opening, a sack slumped open, a shelf with its books out of line
  const REST_AJAR = { drawer: 0.5, lid: 1, sack: 1, shelf: 1 };
  const RISE_STAGGER = 14;        // frames between two found icons
  const DUST_TICK = 3;            // frames per dust step
  const GLINT_TICK = 4;           // frames per glint step
  const RISE_POOL = 4;            // icons one piece can show at once

  // the core is resolved at FIRST USE, never at load: load order is the buyer's choice (wing §8 trap 2)
  let _core = null;
  function Core() {
    if (!_core) {
      _core = window.AjarCore;
      if (!_core) throw new Error('Ajar: AjarCore.js is not loaded. Put it ABOVE Ajar.js in the Plugin Manager.');
    }
    return _core;
  }

  // ── the saved record: which pieces have been searched ─────────────────────────────────────────────────────
  /** { v: 1, searched: { "<mapId>:<eventId>": 1 } } on $gameSystem: a set of decisions, nothing else */
  function store() {
    const s = $gameSystem;
    if (!s._csafAjar || typeof s._csafAjar !== 'object') s._csafAjar = { v: 1, searched: {} };
    if (!s._csafAjar.searched || typeof s._csafAjar.searched !== 'object') s._csafAjar.searched = {};
    return s._csafAjar;
  }
  function keyOf(ev) { return $gameMap.mapId() + ':' + ev.eventId(); }
  function isSearched(ev) { return !!store().searched[keyOf(ev)]; }
  function setSearched(ev, on) { const st = store(); if (on) st.searched[keyOf(ev)] = 1; else delete st.searched[keyOf(ev)]; ev._ajarKnown = !!on; }
  function restOf(kind) { return P.restPose === 'open' ? 1 : P.restPose === 'closed' ? 0 : REST_AJAR[kind]; }

  // ── which events are pieces ─────────────────────────────────────────────────────────────────────────────
  /** @returns {object|null} the AjarCore spec of an event, or null (no note, no tile, or Threshold/Smithereens own it) */
  Game_Event.prototype.ajarSpec = function () {
    if (!Object.prototype.hasOwnProperty.call(this, '_ajarSpecCache')) hideRuntimeSlots(this);
    if (this._ajarSpecPage === this._pageIndex && this._ajarSpecTile === this.tileId()) return this._ajarSpecCache || null;
    return resolveSpec(this);
  };
  /** The cold half of ajarSpec: read the note again (a new page or a new tile), and cache the answer. */
  function resolveSpec(ev) {
    ev._ajarSpecPage = ev._pageIndex;
    ev._ajarSpecTile = ev.tileId();
    const data = ev.event();
    const meta = data && data.meta ? data.meta : null;
    const tag = meta ? meta.ajar : undefined;
    // one event, one owner: a door is Threshold's and a breakable is Smithereens' (named in the compatibility block)
    const theirs = meta && (meta.threshold !== undefined || meta.smash !== undefined);
    let spec = null;
    if (tag !== undefined && !theirs && ev.tileId() > 0 && ev._pageIndex >= 0) {
      spec = Core().parseNote(tag);
      if (spec) spec.manual = /(^|[\s,])manual([\s,]|$)/i.test(String(tag));
    }
    ev._ajarSpecCache = spec;
    return spec;
  }
  /**
   * Runtime slots are declared on the INSTANCE as non-enumerable, because JsonEx walks Object.keys (wing §13); the
   * progress fields (_ajarP, _ajarT, _ajarR) are ordinary numbers and DO save, so a save made mid-opening resumes.
   */
  function hideRuntimeSlots(ev) {
    for (const k of ['_ajarSpecCache', '_ajarSpecPage', '_ajarSpecTile', '_ajarPhase', '_ajarClock', '_ajarLoot', '_ajarDust', '_ajarRiseAt', '_ajarKnown']) {
      Object.defineProperty(ev, k, { value: undefined, writable: true, enumerable: false, configurable: true });
    }
  }
  /** @returns {number} 0 closed .. 1 open */
  Game_Event.prototype.ajarProgress = function () { return Number(this._ajarP) || 0; };

  const _setupPageSettings = Game_Event.prototype.setupPageSettings;
  Game_Event.prototype.setupPageSettings = function () {
    _setupPageSettings.call(this);
    const spec = this.ajarSpec();
    // first sight of this event on this map (a new map or a reloaded one): searched pieces rest, the rest are shut.
    // A page change while it is open keeps its progress (the stock "self switch A, then It's empty" pattern)
    if (spec && this._ajarP === undefined) {
      this._ajarP = this._ajarT = isSearched(this) ? restOf(spec.kind) : 0;
      this._ajarR = 0;
    }
  };

  const _start = Game_Event.prototype.start;
  Game_Event.prototype.start = function () {
    _start.call(this);
    const spec = this.ajarSpec();
    // the player's own triggers only (Action Button, Player Touch, Event Touch); never autorun or parallel
    if (spec && !spec.manual && this._starting && this.isTriggerIn([0, 1, 2])) beginSearch(leadOf(this), this.list());
  };

  /** What a page gives: the icons of every Change Items / Weapons / Armors / Gold that INCREASES by a constant. */
  function lookAhead(list) {
    const out = [];
    if (!list) return out;
    for (const c of list) {
      const p = c.parameters;
      if (!p) continue;
      if (c.code === 125 && p[0] === 0 && p[1] === 0 && Number(p[2]) > 0) out.push(P.goldIcon);
      else if ((c.code === 126 || c.code === 127 || c.code === 128) && p[1] === 0 && p[2] === 0 && Number(p[3]) > 0) {
        const db = c.code === 126 ? $dataItems : c.code === 127 ? $dataWeapons : $dataArmors;
        const it = db && db[p[0]];
        if (it && it.iconIndex > 0) out.push(it.iconIndex);
      }
    }
    return out;
  }

  /** Open a piece the way a search does. `list` = the page it searches with (null: give nothing, so dust). */
  function beginSearch(ev, list) {
    const spec = ev.ajarSpec();
    if (!spec) return;
    const gives = lookAhead(list);
    ev._ajarLoot = P.itemRise ? gives : [];
    ev._ajarRiseAt = undefined;
    // dust only when the page gives NOTHING (a page that gives with the rise switched off is not empty)
    ev._ajarDust = !gives.length && P.dust && spec.dust !== false;
    ev._ajarPhase = 'opening';
    ev._ajarClock = 0;
    ev._ajarT = 1; ev._ajarR = 1 / P.openFrames;
    setSearched(ev, true);
    const se = P.se[spec.kind];
    if (se) AudioManager.playSe({ name: se, volume: 90, pitch: 100, pan: 0 });
    Stats.searches++;
  }

  const _update = Game_Event.prototype.update;
  Game_Event.prototype.update = function () {
    _update.call(this);
    const spec = this.ajarSpec();
    if (!spec) return;
    // glide toward the target (no allocation: numbers only)
    const p = this.ajarProgress(), t = Number(this._ajarT) || 0, r = Number(this._ajarR) || 0;
    if (p !== t) this._ajarP = r > 0 ? (p < t ? Math.min(t, p + r) : Math.max(t, p - r)) : t;
    const ph = this._ajarPhase;
    if (ph === 'opening' && this._ajarP >= 1) { this._ajarPhase = 'reveal'; this._ajarClock = 0; }
    else if (ph === 'reveal') {
      this._ajarClock++;
      // settle once it has been shown long enough AND the event that searched it has finished
      if (this._ajarClock >= revealFrames(this) && !this.isStarting() && !runningHere(this)) settle(this, spec);
    }
  };
  /** How long a reveal lasts: the hold, every found icon's rise, or the dust, whichever is longest. */
  function revealFrames(ev) {
    const loot = ev._ajarLoot ? ev._ajarLoot.length : 0;
    let last = 0;
    for (let i = 0; i < loot; i++) last = Math.max(last, riseStart(ev, i) + P.riseFrames);
    return Math.max(P.holdFrames, last, ev._ajarDust ? (Core().DUST_STEPS + 1) * DUST_TICK : 0);
  }
  /** The reveal frame icon `i` starts rising at: staggered, or when a Show Found Icon command added it. */
  function riseStart(ev, i) { return ev._ajarRiseAt && ev._ajarRiseAt[i] !== undefined ? ev._ajarRiseAt[i] : i * RISE_STAGGER; }
  function runningHere(ev) {
    const it = $gameMap._interpreter;
    if (!it || !it.isRunning()) return false;
    const g = groupOf(ev);
    const id = it.eventId();
    return g ? g.ids.indexOf(id) >= 0 : id === ev.eventId();
  }
  function settle(ev, spec) {
    ev._ajarPhase = 'idle';
    ev._ajarT = restOf(spec.kind); ev._ajarR = 1 / P.openFrames;
  }

  // ── groups (adjacent same kind pieces open as one; the bottom-left member draws and keeps the state) ────────
  // runtime only, rebuilt per map, never saved
  const Groups = { mapId: -1, sig: 0, byEvent: new Map(), list: [], frame: -1 };
  /**
   * The groups of the current map. Asked by every piece sprite every frame, so the per frame check is an integer
   * signature over the marked events and allocates nothing; the groups are rebuilt only when it changes.
   */
  function groupsNow() {
    if (!$gameMap) return Groups;
    if (Groups.frame === Graphics.frameCount && Groups.mapId === $gameMap.mapId()) return Groups;
    Groups.frame = Graphics.frameCount;
    const C = Core(), evs = $gameMap._events;
    let sig = (Math.imul($gameMap.mapId(), 2654435761) ^ $gameMap.tilesetId()) | 0;
    for (let i = 0; i < evs.length; i++) {
      const ev = evs[i];
      if (!ev) continue;
      const sp = ev.ajarSpec();
      if (!sp) continue;
      sig = (Math.imul(sig, 1000003) ^ (ev.eventId() * 7919 + ev.x * 131 + ev.y * 17 + ev.tileId() * 3 + C.KINDS.indexOf(sp.kind) + (sp.group ? 0 : 977))) | 0;
    }
    if (sig === Groups.sig && Groups.mapId === $gameMap.mapId()) return Groups;
    return rebuildGroups(sig);
  }
  /** The cold half of groupsNow: only when a marked event appeared, moved, changed tile or note. */
  function rebuildGroups(sig) {
    const C = Core();
    Groups.sig = sig; Groups.mapId = $gameMap.mapId();
    const pieces = [];
    for (const ev of $gameMap.events()) {
      const sp = ev.ajarSpec();
      if (sp) pieces.push({ id: ev.eventId(), x: ev.x, y: ev.y, kind: sp.kind, group: sp.group, tile: ev.tileId() });
    }
    Groups.list = C.groupPieces(pieces);
    Groups.byEvent = new Map();
    for (const g of Groups.list) {
      // the key names everything the frames are drawn from: map, tileset (Change Tileset rebuilds), group, tiles, note
      const lead = $gameMap.event(g.lead);
      g.frameKey = $gameMap.mapId() + '@' + $gameMap.tilesetId() + ':' + g.key + ':' + g.ids.map((id) => $gameMap.event(id).tileId()).join(',') + ':' + JSON.stringify(lead.ajarSpec());
      for (const id of g.ids) Groups.byEvent.set(id, g);
    }
    return Groups;
  }
  function groupOf(ev) { return groupsNow().byEvent.get(ev.eventId()) || null; }
  /** The member that keeps a group's state (any member can be searched; the whole piece opens). */
  function leadOf(ev) { const g = groupOf(ev); return g ? $gameMap.event(g.lead) || ev : ev; }

  // ── plugin commands ─────────────────────────────────────────────────────────────────────────────────────
  function commandEvent(interp, args) {
    const id = Number(args.eventId);
    // compare against zero: "0" is truthy as a string (wing §16)
    const ev = $gameMap.event(id > 0 ? id : interp.eventId());
    return ev && ev.ajarSpec() ? leadOf(ev) : null;
  }
  function driveTo(interp, args, to) {
    const ev = commandEvent(interp, args);
    if (!ev) return;
    ev._ajarPhase = 'idle';
    ev._ajarT = to; ev._ajarR = 1 / P.openFrames;
    if (String(args.wait) === 'true') interp.wait(Math.ceil(P.openFrames * Math.abs(ev.ajarProgress() - to)) + 1);
  }
  PluginManager.registerCommand(NAME, 'search', function (args) {
    const ev = commandEvent(this, args);
    // a command search gives what THIS page gives (the event running the command)
    if (ev) beginSearch(ev, this._list);
  });
  PluginManager.registerCommand(NAME, 'open', function (args) { driveTo(this, args, 1); });
  PluginManager.registerCommand(NAME, 'close', function (args) { driveTo(this, args, 0); });
  PluginManager.registerCommand(NAME, 'forget', function (args) {
    const ev = commandEvent(this, args);
    if (!ev) return;
    setSearched(ev, false);
    ev._ajarPhase = 'idle'; ev._ajarT = 0; ev._ajarR = 1 / P.openFrames;
  });
  PluginManager.registerCommand(NAME, 'rise', function (args) {
    const ev = commandEvent(this, args);
    const icon = Number(args.iconIndex);
    if (!ev || !(icon > 0)) return;
    if (!ev._ajarLoot) ev._ajarLoot = [];
    // a late icon joins the current reveal, or starts one on a piece that is already open
    if (ev._ajarPhase !== 'reveal') { ev._ajarPhase = 'reveal'; ev._ajarClock = 0; ev._ajarLoot = []; ev._ajarDust = false; ev._ajarRiseAt = undefined; }
    if (ev._ajarLoot.length >= RISE_POOL) return;
    ev._ajarDust = false;
    if (!ev._ajarRiseAt) { ev._ajarRiseAt = []; for (let i = 0; i < ev._ajarLoot.length; i++) ev._ajarRiseAt.push(i * RISE_STAGGER); }
    ev._ajarLoot.push(icon);
    ev._ajarRiseAt.push(ev._ajarClock);
  });

  // ── the frames: built once per piece per map, one piece per frame, never during play ──────────────────────
  /*
   * A pixel read is a GPU sync point (wing §27a: up to 19-31 ms). So each piece is read ONCE, through a small scratch
   * canvas, by a warm pass that handles one piece per frame while the map settles, and every frame of its opening,
   * its glint and its dust is computed then. Opening it afterwards only moves a frame rectangle.
   * One bitmap per piece: row 0 = the opening (OPEN_STEPS + 1 frames), row 1 = the glint, row 2 = the dust.
   */
  const Frames = {
    mapId: -1, byKey: new Map(), pending: [], scratch: null, sctx: null,
    reset(mapId) {
      for (const e of this.byKey.values()) if (e.bitmap) e.bitmap.destroy();
      this.byKey = new Map(); this.pending = []; this.mapId = mapId;
    },
    want(g) {
      const e = this.byKey.get(g.frameKey);
      return e || this.add(g);
    },
    /** First sight of a piece on this map: queue it for the warm pass. */
    add(g) {
      const e = { state: 'pending', group: g };
      this.byKey.set(g.frameKey, e); this.pending.push(g.frameKey);
      return e;
    },
    /** Build at most ONE pending piece this frame. */
    step() {
      for (let i = 0; i < this.pending.length; i++) {
        const k = this.pending[i];
        const e = this.byKey.get(k);
        if (!e || e.state !== 'pending') { this.pending.splice(i--, 1); continue; }
        const ready = this.sourcesReady(e.group);
        // a tile on a page the tileset has no sheet for can never be read (MEASURED by breakit.js: it waited forever,
        // and the warm pass never finished). It is dropped, and the stock path draws whatever MZ draws there
        if (ready === null) { e.state = 'none'; this.pending.splice(i--, 1); Stats.skipped++; continue; }
        if (!ready) continue;
        this.pending.splice(i, 1);
        this.build(e);
        return true;
      }
      return false;
    },
    /** true = every member's sheet is loaded; false = still loading; null = a member's page has no sheet at all. */
    sourcesReady(g) {
      for (const id of g.ids) { const ev = $gameMap.event(id); if (!ev) return false; const b = tilesetBitmapOf(ev.tileId()); if (!b) return null; if (!b.isReady()) return false; }
      return true;
    },
    build(e) {
      const g = e.group, tw = $gameMap.tileWidth(), th = $gameMap.tileHeight();
      const W = g.cols * tw, H = g.rows * th;
      if (!this.scratch) { this.scratch = document.createElement('canvas'); this.scratch.width = 0; this.scratch.height = 0; }
      if (this.scratch.width < W || this.scratch.height < H) { this.scratch.width = Math.max(this.scratch.width, W); this.scratch.height = Math.max(this.scratch.height, H); this.sctx = null; }
      if (!this.sctx) this.sctx = this.scratch.getContext('2d', { willReadFrequently: true });
      const ctx = this.sctx;
      ctx.clearRect(0, 0, W, H);
      for (const id of g.ids) {
        const ev = $gameMap.event(id);
        const tid = ev.tileId(), b = tilesetBitmapOf(tid);
        const sx = ((Math.floor(tid / 128) % 2) * 8 + (tid % 8)) * tw, sy = (Math.floor((tid % 256) / 8) % 16) * th;
        // the tileset's own image, as Bitmap.blt reads it (rmmz_core.js:1502). Never `b.canvas`: that getter builds a
        // canvas COPY of the shared tileset and swaps its texture onto it (rmmz_core.js:1750)
        ctx.drawImage(b._canvas || b._image, sx, sy, tw, th, (ev.x - g.x) * tw, (ev.y - g.y) * th, tw, th);
      }
      const img = ctx.getImageData(0, 0, W, H);
      Stats.reads++;
      const src = { data: img.data, w: W, h: H };
      const C = Core(), lead = $gameMap.event(g.lead), spec = Object.assign({}, lead.ajarSpec(), { seed: hash(g.key) });
      const plan = C.plan(src, spec);
      const pad = plan.pad, FW = W + pad.l + pad.r, FH = H + pad.t + pad.b;
      const N = C.OPEN_STEPS + 1, cols = Math.max(N, C.GLINT_STEPS, C.DUST_STEPS);
      const bmp = new Bitmap(FW * cols, FH * 3);
      let mouth = null;
      for (let n = 0; n < N; n++) {
        const f = C.frame(src, spec, n / C.OPEN_STEPS, { plan });
        bmp.context.putImageData(new ImageData(f.data, FW, FH), n * FW, 0);
        if (n === N - 1) mouth = f.mouth;
      }
      for (let k = 0; k < C.GLINT_STEPS; k++) {
        const f = C.frame(src, spec, 0, { plan, glint: (k + 0.5) / C.GLINT_STEPS });
        bmp.context.putImageData(new ImageData(f.data, FW, FH), k * FW, FH);
      }
      for (let k = 0; k < C.DUST_STEPS; k++) {
        const f = C.frame(src, spec, 1, { plan, dust: (k + 1) / (C.DUST_STEPS + 1), seed: hash(g.key) });
        bmp.context.putImageData(new ImageData(f.data, FW, FH), k * FW, FH * 2);
      }
      bmp.baseTexture.update();
      Object.assign(e, { bitmap: bmp, FW, FH, W, H, tw, th, pad, mouth, N, detected: !!plan.detected, state: 'ready' });
      Stats.built++;
    },
  };
  const Stats = { built: 0, reads: 0, searches: 0, skipped: 0 };
  function tilesetBitmapOf(tileId) {
    const ts = $gameMap.tileset();
    const name = ts ? ts.tilesetNames[5 + Math.floor(tileId / 256)] : '';
    return name ? ImageManager.loadTileset(name) : null;
  }
  function hash(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0) || 1; }

  const _createCharacters = Spriteset_Map.prototype.createCharacters;
  Spriteset_Map.prototype.createCharacters = function () {
    Frames.reset($gameMap.mapId());
    _createCharacters.call(this);
  };
  const _spritesetUpdate = Spriteset_Map.prototype.update;
  Spriteset_Map.prototype.update = function () {
    // build BEFORE the sprites update, so a piece built this frame is shown this frame
    Frames.step();
    _spritesetUpdate.call(this);
  };

  // ── the sprite ──────────────────────────────────────────────────────────────────────────────────────────
  function pieceEntry(ch) {
    if (!(ch instanceof Game_Event)) return null;
    if (!ch.ajarSpec()) return null;
    const g = groupOf(ch);
    return g ? Frames.want(g) : null;
  }

  const _updateBitmap = Sprite_Character.prototype.updateBitmap;
  Sprite_Character.prototype.updateBitmap = function () {
    const e = pieceEntry(this._character);
    if (e && e.state === 'ready') {
      if (this.bitmap !== e.bitmap) {
        this.bitmap = e.bitmap;
        this._ajarEntry = e;
        // the stock tracking fields, so the stock path does not swap the tile back next frame
        this._tilesetId = $gameMap.tilesetId(); this._tileId = this._character.tileId();
        this._characterName = this._character.characterName(); this._characterIndex = this._character.characterIndex();
      }
      return;
    }
    if (this._ajarEntry) { this._ajarEntry = null; this._tileId = -1; this.anchor.x = 0.5; this.anchor.y = 1; this.ajarHideRises(); }
    _updateBitmap.call(this);
  };

  const _updateFrame = Sprite_Character.prototype.updateFrame;
  Sprite_Character.prototype.updateFrame = function () {
    const e = this._ajarEntry;
    if (!e || e.state !== 'ready' || this.bitmap !== e.bitmap) return _updateFrame.call(this);
    const g = e.group, ch = this._character;
    // a grouped piece is drawn whole by its lead; every other member shows nothing (the engine's own way to empty a
    // character frame, rmmz_sprites.js:331)
    if (ch.eventId() !== g.lead) { this.setFrame(0, 0, 0, e.th); this.ajarHideRises(); return; }
    const C = Core(), p = ch.ajarProgress();
    let col = Math.round(p * C.OPEN_STEPS), row = 0;
    if (ch._ajarPhase === 'reveal' && ch._ajarDust && p >= 1) {
      const k = Math.floor((ch._ajarClock || 0) / DUST_TICK);
      if (k < C.DUST_STEPS) { col = k; row = 2; }
    } else if (p <= 0 && glintOn(ch)) {
      const c = (Graphics.frameCount + (ch.eventId() * 97)) % P.glintCycle, k = Math.floor(c / GLINT_TICK);
      if (k < C.GLINT_STEPS) { col = k; row = 1; }
    }
    this.setFrame(col * e.FW, row * e.FH, e.FW, e.FH);
    // the piece's tiles sit at (pad.l, pad.t) inside its frame; the sprite's anchor is the lead tile's bottom middle
    this.anchor.x = (e.pad.l + (ch.x - g.x) * e.tw + e.tw / 2) / e.FW;
    this.anchor.y = (e.pad.t + (ch.y - g.y + 1) * e.th) / e.FH;
    this.ajarUpdateRises(e, ch);
  };
  function glintOn(ch) {
    const spec = ch.ajarSpec();
    if (!spec || spec.glint === false) return false;
    if (!(P.glint || spec.glint === true)) return false;
    // the record answers once and the event keeps the answer (a key string built every frame would allocate)
    if (ch._ajarKnown === undefined) ch._ajarKnown = isSearched(ch);
    return !ch._ajarKnown;
  }

  /** The found icons, rising out of the opening. A fixed pool of child sprites per piece: nothing allocated in play. */
  Sprite_Character.prototype.ajarUpdateRises = function (e, ch) {
    const loot = ch._ajarLoot;
    const active = ch._ajarPhase === 'reveal' && loot && loot.length && e.mouth;
    if (!active) { this.ajarHideRises(); return; }
    if (!this._ajarRises) this.ajarMakeRises();
    const iw = ImageManager.iconWidth, ih = ImageManager.iconHeight;
    const mx = e.mouth.x - this.anchor.x * e.FW, my = e.mouth.y - this.anchor.y * e.FH;
    for (let i = 0; i < RISE_POOL; i++) {
      const s = this._ajarRises[i];
      const t = (ch._ajarClock || 0) - riseStart(ch, i);
      if (i >= loot.length || t < 0 || t >= P.riseFrames) { s.visible = false; continue; }
      const u = t / P.riseFrames;
      // out of the dark: it grows from 40% while it clears the opening, rises a little over half a tile above the
      // mouth, then fades (0.9 of a tile carried a drawer's loot up past the hero's head - the second fresh review)
      const lift = 1 - (1 - Math.min(1, u / 0.55)) * (1 - Math.min(1, u / 0.55));
      const icon = loot[i];
      s.setFrame((icon % 16) * iw, Math.floor(icon / 16) * ih, iw, ih);
      s.x = mx; s.y = my - lift * e.th * 0.6;
      const sc = 0.4 + 0.6 * Math.min(1, u / 0.3);
      s.scale.x = sc; s.scale.y = sc;
      s.opacity = u < 0.75 ? 255 : Math.round(255 * (1 - u) / 0.25);
      s.visible = true;
    }
  };
  /** The icon pool, made once per piece sprite the first time it reveals something. */
  Sprite_Character.prototype.ajarMakeRises = function () {
    this._ajarRises = [];
    const icons = ImageManager.loadSystem('IconSet');
    for (let i = 0; i < RISE_POOL; i++) {
      const s = new Sprite(icons);
      s.anchor.x = 0.5; s.anchor.y = 0.5; s.visible = false;
      this._ajarRises.push(s); this.addChild(s);
    }
  };
  Sprite_Character.prototype.ajarHideRises = function () {
    if (!this._ajarRises) return;
    for (let i = 0; i < this._ajarRises.length; i++) this._ajarRises[i].visible = false;
  };

  // a test and support seam, read only
  window.Ajar = {
    version: '1.0.0',
    stats: () => ({ built: Stats.built, reads: Stats.reads, searches: Stats.searches, skipped: Stats.skipped, pending: Frames.pending.length, groups: groupsNow().list.length }),
    groups: () => groupsNow().list.map((g) => Object.assign({}, g, { ids: g.ids.slice() })),
    entry: (eventId) => { const ev = $gameMap.event(eventId); const g = ev && groupOf(ev); const e = g && Frames.byKey.get(g.frameKey); return e ? { state: e.state, FW: e.FW, FH: e.FH, detected: e.detected, mouth: e.mouth, lead: g.lead, ids: g.ids.slice() } : null; },
    searched: () => Object.keys(store().searched),
  };
})();
