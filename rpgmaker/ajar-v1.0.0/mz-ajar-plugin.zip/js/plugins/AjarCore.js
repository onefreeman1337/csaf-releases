/*:
 * @target MZ
 * @plugindesc [v1.0.0] Ajar core: derives how your own furniture tiles open (drawers, lids, sacks, shelves). Put it above Ajar.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io/
 *
 * @help AjarCore.js
 *
 * The pure rules half of Ajar. It has no engine code in it: it reads an array of RGBA pixels (your furniture
 * tile, or a block of tiles) and returns the pixels of that piece at any point of its opening, for four kinds of
 * opening. Ajar.js feeds it your tileset and shows the result. This file has no parameters and no commands; see
 * Ajar.js.
 *
 * Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.
 */

/*
 * HOW A FRAME IS MADE, and the rule every kind obeys:
 *
 *   Every pixel that moves is a COPY of one of your tile's own pixels, picked by whole pixel nearest neighbour
 *   sampling. Nothing is blended, smoothed or resampled with filtering, so a 48 px drawer stays crisp at every step
 *   (the failure this product exists to avoid is a smeared sprite). The only colours that are not your pixels are a
 *   short, named list DERIVED from your pixels: the darkness inside an opening (four bands pulled from the piece's
 *   own darkest colour), the soft shadow a pulled drawer drops on the floor, and the two tones of a glint. Tests
 *   assert that rule on every frame of every kind (frame().derived is the closed list).
 *
 *   A frame is LARGER than the tile: a lid lifts above it and a drawer slides out below it, so every frame carries
 *   a margin (pad) around the tile, and the tile sits at (pad.l, pad.t) inside the frame. Closed (t = 0) is your
 *   tile byte for byte inside that margin.
 *
 *   The interior of a drawer, jar or sack is unknown, so it is drawn as darkness in bands, never as guessed contents.
 *   What the event gives the player rises out of that darkness (Ajar.js draws the item's own icon).
 */
(function (root) {
  'use strict';

  var KINDS = ['drawer', 'lid', 'sack', 'shelf'];
  var ALIAS = {
    drawers: 'drawer', dresser: 'drawer', desk: 'drawer', cabinet: 'drawer', nightstand: 'drawer', chest_of_drawers: 'drawer',
    barrel: 'lid', crate: 'lid', jar: 'lid', pot: 'lid', urn: 'lid', basket: 'lid', box: 'lid', cask: 'lid', bin: 'lid',
    bag: 'sack', pouch: 'sack', bundle: 'sack',
    bookshelf: 'shelf', bookcase: 'shelf', books: 'shelf', shelves: 'shelf',
  };
  var OPEN_STEPS = 12;        // an opening has 13 frames, t = 0/12 .. 12/12
  var GLINT_STEPS = 8;
  var DUST_STEPS = 8;

  function clamp(x, a, b) { return x < a ? a : x > b ? b : x; }
  function lum(r, g, b) { return 0.2126 * r + 0.7152 * g + 0.0722 * b; }

  /**
   * Read an `<ajar: kind [option...]>` note value (MZ hands over the text after the colon).
   * Options: a NUMBER picks which drawer (1 = the first, reading top to bottom), `all` opens every drawer it finds,
   * `rim N` says the lid is the top N pixels, `left`/`right` says which way a lid slides off, `glint`/`noglint`,
   * `nodust`, `nogroup`.
   * @param {string|boolean} value  the meta value; `true` when the tag had no value
   * @returns {{kind:string, band:number, all:boolean, rim:number, side:number, glint:(boolean|null), dust:boolean, group:boolean}|null}
   *          null when the kind is unknown
   */
  function parseNote(value) {
    var words = (value === true || value == null ? 'drawer' : String(value)).toLowerCase().split(/[\s,]+/).filter(Boolean);
    var kind = words[0] || 'drawer';
    if (ALIAS[kind]) kind = ALIAS[kind];
    if (KINDS.indexOf(kind) < 0) return null;
    var out = { kind: kind, band: 0, all: false, rim: 0, side: 1, glint: null, dust: true, group: true };
    for (var i = 1; i < words.length; i++) {
      var w = words[i];
      if (/^\d+$/.test(w)) { out.band = Number(w); continue; }
      if (w === 'rim' && /^\d+$/.test(words[i + 1] || '')) { out.rim = Number(words[++i]); continue; }
      if (w === 'all') out.all = true;
      else if (w === 'left') out.side = -1;
      else if (w === 'right') out.side = 1;
      else if (w === 'glint') out.glint = true;
      else if (w === 'noglint') out.glint = false;
      else if (w === 'nodust') out.dust = false;
      else if (w === 'nogroup') out.group = false;
    }
    return out;
  }

  /**
   * The derived palette of one piece: its bounding box, darkest and lightest opaque colours, every colour it uses,
   * the median brightness, and the four bands of darkness inside an opening. All from the piece's own pixels.
   * @param {Uint8ClampedArray|number[]} d RGBA @param {number} w @param {number} h
   */
  function analyse(d, w, h) {
    var dark = null, darkL = 1e9, light = null, lightL = -1, n = 0, sr = 0, sg = 0, sb = 0, colours = {}, lums = [];
    var bbox = { x0: w, y0: h, x1: 0, y1: 0 };
    for (var i = 0; i < w * h; i++) {
      if (d[i * 4 + 3] < 128) continue;
      var px = i % w, py = (i - px) / w;
      if (px < bbox.x0) bbox.x0 = px; if (py < bbox.y0) bbox.y0 = py; if (px + 1 > bbox.x1) bbox.x1 = px + 1; if (py + 1 > bbox.y1) bbox.y1 = py + 1;
      var r = d[i * 4], g = d[i * 4 + 1], b = d[i * 4 + 2], L = lum(r, g, b);
      n++; sr += r; sg += g; sb += b; lums.push(L);
      colours[(r << 16) | (g << 8) | b] = 1;
      if (L < darkL) { darkL = L; dark = [r, g, b]; }
      if (L > lightL) { lightL = L; light = [r, g, b]; }
    }
    if (!n) return { empty: true, opaque: 0, bbox: { x0: 0, y0: 0, x1: 0, y1: 0 }, dark: [0, 0, 0], light: [0, 0, 0], interior: [[8, 7, 10]], palette: [], mean: [0, 0, 0], median: 0, lums: [0] };
    lums.sort(function (a, b) { return a - b; });
    var palette = Object.keys(colours).map(function (c) { c = +c; return [(c >> 16) & 255, (c >> 8) & 255, c & 255]; });
    return { empty: false, opaque: n, bbox: bbox, dark: dark, light: light, interior: interiorOf(dark), palette: palette, mean: [sr / n, sg / n, sb / n], median: lums[lums.length >> 1], lums: lums };
  }

  /** The darkness inside an opening: a colour pulled most of the way to black, in four bands, band 0 the deepest. */
  function interiorOf(c) {
    var out = [];
    for (var k = 0; k < 4; k++) {
      var f = 0.14 + k * 0.08;
      out.push([Math.round(c[0] * f + 4), Math.round(c[1] * f + 3), Math.round(c[2] * f + 6)]);
    }
    return out;
  }

  /** The colour of `palette` nearest to (r,g,b): how a wall, rim or shade darkens WITHOUT inventing a colour. */
  function nearest(palette, r, g, b) {
    var best = palette[0], bd = 1e12;
    for (var i = 0; i < palette.length; i++) {
      var p = palette[i], dr = p[0] - r, dg = p[1] - g, db = p[2] - b, dd = dr * dr * 2 + dg * dg * 4 + db * db * 3;
      if (dd < bd) { bd = dd; best = p; }
    }
    return best;
  }

  /** The margin a frame carries around the tile, so a lid can lift above it and a drawer slide out below it. */
  function padOf(w, h) { return { l: Math.round(w / 4), r: Math.round(w / 4), t: Math.round(h / 2), b: Math.round(h / 4) }; }

  // ── plans: where the moving part is, found ONCE per piece from its own pixels ─────────────────────────────────

  /**
   * DRAWER FRONTS. A drawer front is a light, nearly rectangular panel bounded by the darker seams around it
   * (the gap between drawers, the carcass edge). Find the connected light regions, keep the ones shaped like a
   * front (wider than tall, not the top surface, mostly filling their own box), and grow each by its outline.
   * @returns {{fronts:{x0:number,y0:number,x1:number,y1:number}[], detected:boolean}}
   */
  function drawerFronts(d, w, h, A) {
    var bb = A.bbox, BW = bb.x1 - bb.x0, BH = bb.y1 - bb.y0;
    // WHERE a seam stops and a front starts is the tile's own business: a pixel set drawn on black has a median in
    // the seams, a painted set has soft brown seams well above any fixed fraction of its median (MEASURED on the
    // contact sheets: one fixed cut found fronts in 4 of 13 drawer pieces). So the cut is SWEPT over the piece's own
    // brightness quantiles and the cut that frames the most front area wins (ties: the darker cut, fewer guesses).
    var best = null, bestArea = 0;
    var cuts = [A.median * DARK_CUT], levels = [], last = -1;
    // every step between two of the piece's own brightness levels up to its 90th percentile (a pixel set has a
    // handful; a painted set has hundreds, so those are thinned evenly to CUT_MAX)
    var top = A.lums[Math.floor(0.9 * (A.lums.length - 1))];
    for (var li = 0; li < A.lums.length; li++) { var v = Math.round(A.lums[li]); if (v > last && v <= top) { levels.push(v); last = v; } }
    var stride = Math.max(1, Math.ceil(levels.length / CUT_MAX));
    for (var q = 1; q < levels.length; q += stride) cuts.push((levels[q - 1] + levels[q]) / 2 + 0.25);
    var floorL = RECESS_K * lum(A.mean[0], A.mean[1], A.mean[2]);
    var topY = carcassTop(d, w, bb, BW);
    for (var c = 0; c < cuts.length; c++) {
      var got = frontsAt(d, w, h, bb, BW, BH, cuts[c], floorL, topY);
      if (got.area > bestArea) { bestArea = got.area; best = got.fronts; }
    }
    if (best && best.length) return { fronts: best, detected: true };
    // nothing shaped like a front at any cut: one front across the middle of the piece, so the plugin still does
    // something on an unusual tile (a number in the note picks a band; this is the fallback, and it says so)
    var fy0 = bb.y0 + Math.round(0.45 * BH);
    return { fronts: [{ x0: bb.x0 + Math.round(0.1 * BW), y0: fy0, x1: bb.x1 - Math.round(0.1 * BW), y1: Math.min(bb.y1, fy0 + Math.max(4, Math.round(0.22 * BH))) }], detected: false };
  }
  // how many seam cuts are tried at most (plus the old fixed cut, DARK_CUT x median); a plan is made once per piece
  // at map load, never during play
  var CUT_MAX = 32;
  /**
   * The top of the CARCASS: the first row whose opaque pixels span CARCASS_SPAN of the piece's width. Whatever stands ON
   * the piece (books on a desk, a vase on a dresser) raises the bounding box but is not the piece, and measuring "the top
   * surface is not a drawer" from it let a desk's top board pass as its drawer (MEASURED 2026-10-24, the Verdant 07 desk:
   * two books lifted the box 5 px and the whole top board opened instead of the pedestal drawer).
   */
  function carcassTop(d, w, bb, BW) {
    for (var y = bb.y0; y < bb.y1; y++) {
      var n = 0;
      for (var x = bb.x0; x < bb.x1; x++) if (d[(y * w + x) * 4 + 3] >= 128) n++;
      if (n >= CARCASS_SPAN * BW) return y;
    }
    return bb.y0;
  }
  var CARCASS_SPAN = 0.6;
  /** The fronts found at one brightness cut, and the opaque front pixels they frame. */
  function frontsAt(d, w, h, bb, BW, BH, cut, floorL, topY) {
    if (topY === undefined) topY = bb.y0;
    var lit = new Uint8Array(w * h);
    for (var i = 0; i < w * h; i++) if (d[i * 4 + 3] >= 128 && lum(d[i * 4], d[i * 4 + 1], d[i * 4 + 2]) >= cut) lit[i] = 1;
    var seen = new Int32Array(w * h), fronts = [], stack = [], area = 0;   // seen = the component's id (its seed + 1)
    for (var s = 0; s < w * h; s++) {
      if (!lit[s] || seen[s]) continue;
      var x0 = w, y0 = h, x1 = 0, y1 = 0, n = 0, id = s + 1;
      stack.length = 0; stack.push(s); seen[s] = id;
      while (stack.length) {
        var p = stack.pop(), px = p % w, py = (p - px) / w; n++;
        if (px < x0) x0 = px; if (py < y0) y0 = py; if (px + 1 > x1) x1 = px + 1; if (py + 1 > y1) y1 = py + 1;
        if (px > 0 && lit[p - 1] && !seen[p - 1]) { seen[p - 1] = id; stack.push(p - 1); }
        if (px < w - 1 && lit[p + 1] && !seen[p + 1]) { seen[p + 1] = id; stack.push(p + 1); }
        if (py > 0 && lit[p - w] && !seen[p - w]) { seen[p - w] = id; stack.push(p - w); }
        if (py < h - 1 && lit[p + w] && !seen[p + w]) { seen[p + w] = id; stack.push(p + w); }
      }
      if (isFront(x0, y0, x1, y1, n, bb, BW, BH, topY) && !isRecess(d, w, seen, id, x0, y0, x1, y1, floorL)) { area += n; fronts.push(grow(x0, y0, x1, y1, bb)); continue; }
      // A component that is not front-shaped can still HOLD fronts: in pixel art a front often touches a side stile
      // of its own colour, which joins every drawer and the top into one region (MEASURED, the 16 px test dresser).
      // Split it at its dark ROWS, judged across the middle of the component so the stiles do not count.
      if (x1 - x0 < Math.max(6, Math.round(0.22 * BW)) || y1 - y0 < 6) continue;
      var mx0 = x0 + Math.round(0.15 * (x1 - x0)), mx1 = x1 - Math.round(0.15 * (x1 - x0)), b0 = -1;
      for (var yy = y0; yy <= y1; yy++) {
        var on = false;
        if (yy < y1) { var k = 0; for (var xx = mx0; xx < mx1; xx++) if (seen[yy * w + xx] === id) k++; on = k >= SPLIT_ROW * (mx1 - mx0); }
        if (on && b0 < 0) b0 = yy;
        if (!on && b0 >= 0) {
          // the band's extent: the run of this component's columns through its middle row, across the piece's middle
          var ym = (b0 + yy) >> 1, c = (mx0 + mx1) >> 1, ax = c, bx = c;
          if (seen[ym * w + c] === id) {
            while (ax > x0 && seen[ym * w + ax - 1] === id) ax--;
            while (bx < x1 - 1 && seen[ym * w + bx + 1] === id) bx++;
            var nb = 0;
            for (var y2 = b0; y2 < yy; y2++) for (var x2 = ax; x2 <= bx; x2++) if (seen[y2 * w + x2] === id) nb++;
            if (isFront(ax, b0, bx + 1, yy, nb, bb, BW, BH, topY) && !isRecess(d, w, seen, id, ax, b0, bx + 1, yy, floorL)) { area += nb; fronts.push(grow(ax, b0, bx + 1, yy, bb)); }
          }
          b0 = -1;
        }
      }
    }
    fronts.sort(function (a, b) { return a.y0 - b.y0 || a.x0 - b.x0; });
    return { fronts: fronts, area: area };
  }
  /** Is a lit box shaped like a drawer front: filled, wider than tall, not tiny, not most of the piece, not the top. */
  function isFront(x0, y0, x1, y1, n, bb, BW, BH, topY) {
    var cw = x1 - x0, ch = y1 - y0;
    if (n / (cw * ch) < FRONT_FILL) return false;
    if (cw < Math.max(6, Math.round(0.22 * BW)) || ch < Math.max(3, Math.round(0.07 * BH)) || ch > 0.42 * BH || cw < 1.25 * ch) return false;
    return y0 >= (topY === undefined ? bb.y0 : topY) + Math.round(0.12 * BH);   // the carcass's top surface is not a drawer
  }
  /**
   * A front is a PANEL standing out of the carcass; an open compartment (a nightstand's shelf, a desk's knee hole) is
   * a RECESS, darker than the piece it is cut into, and opening it as a drawer pulls the shelf out (MEASURED, the 16 px
   * test nightstand). A box whose own pixels average darker than RECESS_K of the piece's mean is a recess.
   */
  function isRecess(d, w, seen, id, x0, y0, x1, y1, floorL) {
    var s = 0, n = 0;
    for (var y = y0; y < y1; y++) for (var x = x0; x < x1; x++) { var p = y * w + x; if (seen[p] !== id) continue; s += lum(d[p * 4], d[p * 4 + 1], d[p * 4 + 2]); n++; }
    return n > 0 && s / n < floorL;
  }
  var RECESS_K = 0.85;
  function grow(x0, y0, x1, y1, bb) { return { x0: Math.max(bb.x0, x0 - 1), y0: Math.max(bb.y0, y0 - 1), x1: Math.min(bb.x1, x1 + 1), y1: Math.min(bb.y1, y1 + 1) }; }
  // a row belongs to a front band when this share of the component's middle is lit
  var SPLIT_ROW = 0.75;
  // MEASURED on the contact sheets (Internal_Ops/_probe/contact.js): a seam is a pixel under 0.62 of the piece's median
  // brightness; a front fills at least 0.7 of its own box (a handle or grain makes holes, a seam makes a split)
  var DARK_CUT = 0.62;
  var FRONT_FILL = 0.7;

  /**
   * Which fronts a note opens: a number picks one; `all` opens every one; else the TOP front that carries a HANDLE
   * among the large ones, else the top large one. A rail or a shelf lip is front-shaped too, and has no handle
   * (MEASURED: the tavern sideboard opened its plate rail instead of its drawers).
   */
  function chooseFronts(fronts, spec, d, w) {
    if (spec.all) return fronts.map(function (_, i) { return i; });
    if (spec.band > 0 && spec.band <= fronts.length) return [spec.band - 1];
    var max = 0;
    for (var i = 0; i < fronts.length; i++) max = Math.max(max, (fronts[i].x1 - fronts[i].x0) * (fronts[i].y1 - fronts[i].y0));
    var big = [];
    for (var j = 0; j < fronts.length; j++) if ((fronts[j].x1 - fronts[j].x0) * (fronts[j].y1 - fronts[j].y0) >= HANDLE_BIG * max) big.push(j);
    if (d) for (var k = 0; k < big.length; k++) if (hasHandle(d, w, fronts[big[k]])) return [big[k]];
    for (var m = 0; m < big.length; m++) if ((fronts[big[m]].x1 - fronts[big[m]].x0) * (fronts[big[m]].y1 - fronts[big[m]].y0) >= 0.6 * max) return [big[m]];
    return [0];
  }
  /** A handle: a few pixels inside the front (off its border) far from the front's own median brightness. */
  function hasHandle(d, w, F) {
    var ls = [], y, x, j;
    for (y = F.y0 + 1; y < F.y1 - 1; y++) for (x = F.x0 + 1; x < F.x1 - 1; x++) { j = (y * w + x) * 4; if (d[j + 3] >= 128) ls.push(lum(d[j], d[j + 1], d[j + 2])); }
    if (ls.length < 6) return false;
    var sorted = ls.slice().sort(function (a, b) { return a - b; }), med = sorted[sorted.length >> 1], n = 0;
    for (var i = 0; i < ls.length; i++) if (Math.abs(ls[i] - med) > HANDLE_DL) n++;
    return n >= 2 && n <= HANDLE_SHARE * ls.length;
  }
  var HANDLE_BIG = 0.35, HANDLE_DL = 45, HANDLE_SHARE = 0.2;

  /**
   * LID. The lid of a barrel, crate, jar or pot is the top of the piece down to the rim: the row where the colour
   * breaks hardest (with a bonus for a dark rim line), searched between a tenth and a half of the piece's height.
   * `rim N` in the note overrides it.
   * @returns {{rimY:number, lx0:number, lx1:number, detected:boolean, foot:Uint8Array, mouthPx:Uint8Array}}
   */
  function lidPlan(d, w, h, A, spec) {
    var bb = A.bbox, BH = bb.y1 - bb.y0;
    var rowMean = [], rowN = [];
    for (var y = 0; y < h; y++) {
      var r = 0, g = 0, b = 0, n = 0;
      for (var x = 0; x < w; x++) { var i = (y * w + x) * 4; if (d[i + 3] < 128) continue; r += d[i]; g += d[i + 1]; b += d[i + 2]; n++; }
      rowN.push(n); rowMean.push(n ? [r / n, g / n, b / n] : null);
    }
    var rimY = -1, detected = false;
    if (spec && spec.rim > 0) { rimY = clamp(bb.y0 + spec.rim, bb.y0 + 1, bb.y1 - 2); detected = true; }
    else {
      var best = -1, lo = bb.y0 + Math.max(2, Math.round(0.1 * BH)), hi = bb.y0 + Math.round(0.5 * BH), widest = 0, score = {};
      for (var yw = 0; yw < h; yw++) widest = Math.max(widest, rowN[yw]);
      for (var yy = lo; yy <= hi; yy++) {
        var a0 = avgRows(rowMean, rowN, yy - 2, yy), a1 = avgRows(rowMean, rowN, yy, yy + 2);
        if (!a0 || !a1) continue;
        var dist = Math.sqrt((a0[0] - a1[0]) * (a0[0] - a1[0]) + (a0[1] - a1[1]) * (a0[1] - a1[1]) + (a0[2] - a1[2]) * (a0[2] - a1[2]));
        var line = rowMean[yy] ? lum(rowMean[yy][0], rowMean[yy][1], rowMean[yy][2]) : 255;
        var bonus = (line < lum(a0[0], a0[1], a0[2]) - 6 && line < lum(a1[0], a1[1], a1[2]) - 6) ? 18 : 0;
        // a lid's edge runs the width of the piece; the break between a narrow knob and the dome under it does not
        // (MEASURED: the painted pot lifted only its knob), so a break counts by the square root of its row's width
        var span = Math.sqrt(Math.min(rowN[yy - 1] || 0, rowN[yy] || 0) / Math.max(1, widest));
        score[yy] = (dist + bonus) * span;
        if (score[yy] > best) best = score[yy];
      }
      // the rim is the LOWEST break nearly as strong as the strongest: a barrel's lid carries its own rings and a
      // pot's dome its own highlight, and the strongest of those cut the lid in half (MEASURED, the stock barrel lifted
      // the top half of its own lid)
      for (var yr = hi; yr >= lo; yr--) if (score[yr] >= LID_LOWEST * best) { rimY = yr; break; }
      detected = best >= LID_BREAK;
      if (!detected) rimY = bb.y0 + Math.round(0.3 * BH);
    }
    // the lid's footprint (its opaque pixels above the rim) and the mouth it leaves: the footprint pulled in by a rim
    // ...trimmed to the lid's OWN width: a pot's handles or a crock's lugs sit at rim height and would lift with the
    // lid (MEASURED, the clean test pot); the lid is as wide as most of its rows, the 70th percentile of their widths
    var wl = [], cxl = 0, nl = 0;
    for (var yl = bb.y0; yl < rimY; yl++) {
      var a = -1, b = -1;
      for (var xl = 0; xl < w; xl++) if (d[(yl * w + xl) * 4 + 3] >= 128) { if (a < 0) a = xl; b = xl; }
      if (a >= 0) { wl.push(b - a + 1); cxl += (a + b) / 2; nl++; }
    }
    wl.sort(function (p, q) { return p - q; });
    var half = nl ? (wl[Math.floor(LID_WIDTH_Q * (nl - 1))] + 2) / 2 : w, cmid = nl ? cxl / nl : w / 2;
    var foot = new Uint8Array(w * h), lx0 = w, lx1 = 0;
    for (var y2 = bb.y0; y2 < rimY; y2++) for (var x2 = 0; x2 < w; x2++) {
      if (d[(y2 * w + x2) * 4 + 3] < 128 || Math.abs(x2 - cmid) > half) continue;
      foot[y2 * w + x2] = 1; if (x2 < lx0) lx0 = x2; if (x2 + 1 > lx1) lx1 = x2 + 1;
    }
    var r0 = Math.max(1, Math.round((lx1 - lx0) / 24));
    // ROUND or BOX: a barrel, pot, jar or basket lid is round, and the hole it leaves is an ELLIPSE in this view, not the
    // lid's outline (LOOKED AT 2026-10-24, the fresh review: a pot's opening spilled past its own body where the dome
    // had overhung it, and read as a hole cut in the air). A lid that fills its own box (a crate's boards) is a box
    var footN = 0; for (var fq = 0; fq < w * h; fq++) footN += foot[fq];
    var round = footN > 0 && footN / Math.max(1, (lx1 - lx0) * (rimY - bb.y0)) < ROUND_FILL && lx1 - lx0 >= 8;
    if (round) {
      // the mouth is no wider than the BODY just under the rim (a jar's stopper sat on a narrow neck and the mouth spilled
      // two pixels past it, MEASURED by core.test D4)
      var nb0 = w, nb1 = -1;
      for (var yn = rimY; yn < Math.min(h, rimY + 3); yn++) for (var xn = 0; xn < w; xn++) if (d[(yn * w + xn) * 4 + 3] >= 128) { if (xn < nb0) nb0 = xn; if (xn > nb1) nb1 = xn; }
      var mx0 = Math.max(lx0, nb1 >= 0 ? nb0 : lx0), mx1 = Math.min(lx1, nb1 >= 0 ? nb1 + 1 : lx1);
      var ecx = (mx0 + mx1 - 1) / 2, erx = (mx1 - mx0) / 2 - Math.max(1, r0);
      var ery = clamp(Math.round(erx * ELLIPSE_RATIO), 2, Math.max(2, rimY - bb.y0));
      var ecy = rimY - ery;
      var mouthR = new Uint8Array(w * h), ring = new Uint8Array(w * h), mr = 0;
      for (var ye = Math.floor(ecy - ery - 1); ye <= Math.ceil(ecy + ery + 1); ye++) for (var xe = Math.floor(ecx - erx - 1); xe <= Math.ceil(ecx + erx + 1); xe++) {
        if (xe < 0 || ye < 0 || xe >= w || ye >= h || d[(ye * w + xe) * 4 + 3] < 128) continue;
        var ex = (xe - ecx) / erx, ey = (ye - ecy) / ery, ex1 = (xe - ecx) / (erx + 1), ey1 = (ye - ecy) / (ery + 1);
        if (ex * ex + ey * ey <= 1) { mouthR[ye * w + xe] = 1; mr++; } else if (ex1 * ex1 + ey1 * ey1 <= 1) ring[ye * w + xe] = 1;
      }
      if (mr >= 6) return { rimY: rimY, lx0: lx0, lx1: lx1, detected: detected, foot: foot, mouthPx: mouthR, ring: ring, round: true, ell: { cx: ecx, cy: ecy, rx: erx, ry: ery }, rimW: r0, mouthBottom: Math.ceil(ecy + ery + 2) };
    }
    var mouthPx = new Uint8Array(w * h);
    for (var y3 = bb.y0; y3 < rimY; y3++) for (var x3 = lx0; x3 < lx1; x3++) {
      if (!foot[y3 * w + x3]) continue;
      var inside = true;
      for (var k = 1; k <= r0 && inside; k++) {
        if (x3 - k < 0 || x3 + k >= w || !foot[y3 * w + x3 - k] || !foot[y3 * w + x3 + k]) inside = false;
        else if (y3 - k < bb.y0 || !foot[(y3 - k) * w + x3]) inside = false;
      }
      // the near side of the mouth is the rim's own front edge: keep a band of the body below it unopened
      if (inside && y3 >= rimY - r0) inside = false;
      if (inside) mouthPx[y3 * w + x3] = 1;
    }
    // a THIN lid (a crate's top plank seen nearly front on) leaves no room for a mouth inside its own footprint
    // (MEASURED: the Verdant 07 slat crate opened onto nothing). Then the opening is the top of the box itself: the
    // lid's rows plus a few rows of the body below the rim, each row pulled in by a pixel at both ends
    var mn = 0; for (var q = 0; q < w * h; q++) mn += mouthPx[q];
    var mouthBottom = rimY;
    if (mn < THIN_MOUTH * Math.max(1, lx1 - lx0)) {
      var extra = clamp(THIN_ROWS - (rimY - bb.y0), 1, THIN_ROWS);
      mouthBottom = Math.min(bb.y1 - 2, rimY + extra);
      for (var y4 = bb.y0 + 1; y4 < mouthBottom; y4++) {
        var a4 = -1, b4 = -1;
        for (var x4 = lx0; x4 < lx1; x4++) if (d[(y4 * w + x4) * 4 + 3] >= 128) { if (a4 < 0) a4 = x4; b4 = x4; }
        for (var x5 = a4 + 1; a4 >= 0 && x5 < b4; x5++) if (d[(y4 * w + x5) * 4 + 3] >= 128) mouthPx[y4 * w + x5] = 1;
      }
    }
    return { rimY: rimY, lx0: lx0, lx1: lx1, detected: detected, foot: foot, mouthPx: mouthPx, rimW: r0, mouthBottom: mouthBottom };
  }
  function avgRows(rowMean, rowN, a, b) {
    var r = 0, g = 0, bl = 0, n = 0;
    for (var y = a; y < b; y++) { if (y < 0 || y >= rowMean.length || !rowMean[y]) continue; r += rowMean[y][0] * rowN[y]; g += rowMean[y][1] * rowN[y]; bl += rowMean[y][2] * rowN[y]; n += rowN[y]; }
    return n ? [r / n, g / n, bl / n] : null;
  }
  // MEASURED (Internal_Ops/_probe/contact.js): a real lid edge moves the row colour by 20+ on every test piece; under
  // that the piece has no lid line and the fallback (the top 30%) is used and reported
  var LID_BREAK = 20;
  var LID_LOWEST = 0.75;
  var LID_WIDTH_Q = 0.7;
  var THIN_MOUTH = 2;      // a mouth smaller than 2 rows of the lid's width is no mouth
  var THIN_ROWS = 6;       // ...and the thin-lid opening is this deep, counted from the top of the lid
  var ROUND_FILL = 0.88;   // a lid filling less of its own box than this is round (a crate's boards fill ~0.95)
  var ELLIPSE_RATIO = 0.42; // the height of a round opening seen from MZ's tilted view, as a share of its width
  var LID_SLIDE = 0.3;     // how far across a lid is set down, as a share of its width
  var LID_TILT = 16;       // degrees of tip at the top of a lid's lift (the drawn rotation is under half of it)
  var RING_SAMPLE = 2;     // rows under the rim a round mouth's lit lip takes its tone from (the rim row is the outline)
  var RING_LIFT = 1.3;     // how far that tone is lifted toward the light (then snapped to the piece's own palette)
  var SACK_MOUTH = 0.3;    // half-width of an open sack's mouth, as a share of the body's widest row

  /**
   * SACK. The neck is the narrowest row between an eighth and three fifths of the way down (the tie); above it is
   * the gathered top, below it the body. No waist found: the neck is put at 30% and that is reported.
   */
  function sackPlan(d, w, h, A) {
    var bb = A.bbox, BH = bb.y1 - bb.y0;
    var width = [];
    for (var y = 0; y < h; y++) { var a = -1, b = -1; for (var x = 0; x < w; x++) if (d[(y * w + x) * 4 + 3] >= 128) { if (a < 0) a = x; b = x; } width.push(a < 0 ? 0 : b - a + 1); }
    var lo = bb.y0 + Math.max(2, Math.round(0.12 * BH)), hi = bb.y0 + Math.round(0.6 * BH);
    var neck = -1, nw = 1e9;
    for (var y2 = lo; y2 <= hi; y2++) if (width[y2] > 0 && width[y2] < nw) { nw = width[y2]; neck = y2; }
    var above = 0, below = 0;
    for (var y3 = bb.y0; y3 < neck; y3++) above = Math.max(above, width[y3]);
    for (var y4 = neck + 1; y4 < bb.y1; y4++) below = Math.max(below, width[y4]);
    var detected = neck > 0 && nw < 0.85 * below && nw <= above;
    if (!detected) neck = bb.y0 + Math.round(0.3 * BH);
    return { neck: neck, detected: detected, neckW: width[neck] || 0, bodyW: below };
  }

  /**
   * SHELF. Rows of books are the rows where the colour changes most often across the piece (spines side by side);
   * the shelf boards between them are calm. In each row of books, a spine is a run of columns of one colour.
   */
  function shelfPlan(d, w, h, A, seed) {
    var bb = A.bbox;
    var busy = [], changes = [];
    for (var y = 0; y < h; y++) {
      var ch = 0, n = 0;
      for (var x = bb.x0 + 1; x < bb.x1; x++) {
        var i = (y * w + x) * 4, j = i - 4;
        if (d[i + 3] < 128 || d[j + 3] < 128) continue;
        n++;
        if (Math.abs(d[i] - d[j]) + Math.abs(d[i + 1] - d[j + 1]) + Math.abs(d[i + 2] - d[j + 2]) > 60) ch++;
      }
      busy.push(n ? ch / n : 0); changes.push(ch);
    }
    var rows = [], start = -1;
    for (var y2 = bb.y0; y2 <= bb.y1; y2++) {
      // a book row changes colour often: as a SHARE of the row for thin spines, as a COUNT for wide ones (a 16 px-art
      // shelf has 6 px spines, 0.13 of its columns, MEASURED; a shelf board crosses only its two side edges)
      var on = y2 < bb.y1 && (busy[y2] >= BOOK_BUSY || changes[y2] >= BOOK_CHANGES);
      if (on && start < 0) start = y2;
      if (!on && start >= 0) { if (y2 - start >= 4) rows.push({ y0: start, y1: y2 }); start = -1; }
    }
    // the carcass's own colours: everything opaque in the rows that hold no books (boards, top, plinth, the gaps)
    var inBook = new Uint8Array(h), carcass = [], cseen = {};
    rows.forEach(function (r) { for (var yb = r.y0; yb < r.y1; yb++) inBook[yb] = 1; });
    for (var yc = bb.y0; yc < bb.y1; yc++) {
      if (inBook[yc]) continue;
      for (var xc = bb.x0; xc < bb.x1; xc++) {
        var ic = (yc * w + xc) * 4; if (d[ic + 3] < 128) continue;
        var kc = (d[ic] << 16) | (d[ic + 1] << 8) | d[ic + 2];
        if (!cseen[kc]) { cseen[kc] = 1; carcass.push([d[ic], d[ic + 1], d[ic + 2]]); }
      }
    }
    var isCarcass = function (c) {
      for (var q = 0; q < carcass.length; q++) if (Math.abs(carcass[q][0] - c[0]) + Math.abs(carcass[q][1] - c[1]) + Math.abs(carcass[q][2] - c[2]) < CARCASS_NEAR) return true;
      return false;
    };
    var spines = [];
    rows.forEach(function (r, ri) {
      var mid0 = r.y0 + Math.floor((r.y1 - r.y0) * 0.3), mid1 = r.y0 + Math.ceil((r.y1 - r.y0) * 0.7);
      var col = [];
      for (var x = bb.x0; x < bb.x1; x++) {
        var sr = 0, sg = 0, sb = 0, n = 0;
        for (var y = mid0; y < mid1; y++) { var i = (y * w + x) * 4; if (d[i + 3] < 128) continue; sr += d[i]; sg += d[i + 1]; sb += d[i + 2]; n++; }
        col.push(n ? [sr / n, sg / n, sb / n] : null);
      }
      var s0 = 0, runs = [];
      for (var k = 1; k <= col.length; k++) {
        var brk = k === col.length || !col[k] || !col[k - 1] || Math.abs(col[k][0] - col[k - 1][0]) + Math.abs(col[k][1] - col[k - 1][1]) + Math.abs(col[k][2] - col[k - 1][2]) > 50;
        if (!brk) continue;
        runs.push([s0, k]);
        s0 = k;
      }
      // a spine is a coloured run 2+ wide, narrower than a fifth of the shelf, not the dark back of the shelf, and
      // never the first or last run of the row: those are the carcass's own side stiles (MEASURED: a stile picked as a
      // spine leaned the side of the bookcase on the 16 px and stock sheets)
      for (var ri2 = 1; ri2 < runs.length - 1; ri2++) {
        var a0 = runs[ri2][0], a1 = runs[ri2][1], x0 = bb.x0 + a0, x1 = bb.x0 + a1;
        if (x1 - x0 < 2 || x1 - x0 > 0.2 * (bb.x1 - bb.x0) || !col[a0]) continue;
        // ...and not a colour the carcass is made of: the back of the shelf or a stile showing between books
        // (judged per PIXEL: a column mean of a stile drawn in two shades is a colour the carcass never uses, MEASURED)
        var wood = 0, mn = 0;
        for (var xa = x0; xa < x1; xa++) for (var ya = mid0; ya < mid1; ya++) {
          var ia = (ya * w + xa) * 4; if (d[ia + 3] < 128) continue;
          mn++; if (isCarcass([d[ia], d[ia + 1], d[ia + 2]])) wood++;
        }
        if (!mn || wood >= 0.5 * mn) continue;
        if (lum(col[a0][0], col[a0][1], col[a0][2]) > A.median * 0.55) spines.push({ row: ri, x0: x0, x1: x1, y0: r.y0, y1: r.y1 });
      }
    });
    // three spines move: the first one PULLED (it slides toward the camera), two more LEAN; picked by the seed
    var picks = [];
    if (spines.length) {
      var st = (seed >>> 0) || 1;
      var rnd = function () { st = (Math.imul(st, 1664525) + 1013904223) >>> 0; return st / 4294967296; };
      var order = spines.map(function (_, i) { return i; });
      for (var q = order.length - 1; q > 0; q--) { var z = Math.floor(rnd() * (q + 1)); var t0 = order[q]; order[q] = order[z]; order[z] = t0; }
      var used = {};
      for (var o = 0; o < order.length && picks.length < 3; o++) {
        var sp = spines[order[o]], key = sp.row + ':' + sp.x0;
        // never two moving spines side by side: the second would lean into the first's gap
        var clash = picks.some(function (p) { return p.row === sp.row && (Math.abs(p.x0 - sp.x1) <= 1 || Math.abs(sp.x0 - p.x1) <= 1); });
        if (used[key] || clash) continue;
        used[key] = 1; picks.push(sp);
      }
    }
    var detected = rows.length > 0 && spines.length >= 3;
    // the back of the shelf: the darkest carcass colour that is not the outline (a near-black gap reads as a hole)
    var backTone = null, backL = 1e9;
    for (var cq = 0; cq < carcass.length; cq++) { var cl = lum(carcass[cq][0], carcass[cq][1], carcass[cq][2]); if (cl >= BACK_MIN_L && cl < backL) { backL = cl; backTone = carcass[cq]; } }
    if (!backTone) backTone = nearest(A.palette, A.dark[0] + 30, A.dark[1] + 22, A.dark[2] + 16);
    if (!picks.length) {
      // no spines found: one book-sized block at the middle of the piece is pulled, so the shelf still answers the
      // search (a guess, reported as one; `<ajar: shelf>` on such a tile is better served by a hand-set note)
      var u = Math.max(2, Math.round((bb.x1 - bb.x0) / 12)), cx = (bb.x0 + bb.x1) >> 1, BHs = bb.y1 - bb.y0;
      picks.push({ row: 0, x0: cx - u, x1: cx + u, y0: bb.y0 + Math.round(0.4 * BHs), y1: bb.y0 + Math.round(0.68 * BHs) });
    }
    return { rows: rows, spines: spines, picks: picks, detected: detected, backTone: backTone };
  }
  // MEASURED (Internal_Ops/_probe/contact.js): book rows change colour on 30%+ of their columns, boards and carcass under 15%
  var BOOK_BUSY = 0.22;
  var BOOK_CHANGES = 5;
  var CARCASS_NEAR = 36;   // a run within this RGB distance of a carcass colour is wood, not a book
  var SHELF_PULL = 3;      // units (a 24th of the piece's width) the pulled book tips toward you
  var BACK_MIN_L = 18;     // the shelf's back is the darkest carcass colour at least this bright (darker is the outline)

  /**
   * The plan of one piece: everything the frames need that is found from its pixels, found once.
   * @param {{data:Uint8ClampedArray|number[], w:number, h:number}} src
   * @param {object} spec  parseNote() output (or {kind})
   */
  function plan(src, spec) {
    var w = src.w, h = src.h, d = src.data;
    var A = analyse(d, w, h);
    var P = { kind: spec.kind, A: A, pad: padOf(w, h), w: w, h: h };
    if (A.empty) { P.detected = false; return P; }
    if (spec.kind === 'drawer') { var df = drawerFronts(d, w, h, A); P.fronts = df.fronts; P.detected = df.detected; P.open = chooseFronts(df.fronts, spec, d, w); }
    else if (spec.kind === 'lid') { P.lid = lidPlan(d, w, h, A, spec); P.detected = P.lid.detected; }
    else if (spec.kind === 'sack') { P.sack = sackPlan(d, w, h, A); P.detected = P.sack.detected; }
    else if (spec.kind === 'shelf') { P.shelf = shelfPlan(d, w, h, A, spec.seed || 7); P.detected = P.shelf.detected; }
    return P;
  }

  // ── frames ────────────────────────────────────────────────────────────────────────────────────────────────

  function newFrame(w, h) { return { data: new Uint8ClampedArray(w * h * 4), mask: new Uint8Array(w * h), w: w, h: h }; }
  function put(f, x, y, c, a) { if (x < 0 || y < 0 || x >= f.w || y >= f.h) return; var i = (y * f.w + x) * 4; f.data[i] = c[0]; f.data[i + 1] = c[1]; f.data[i + 2] = c[2]; f.data[i + 3] = a == null ? 255 : a; }
  function getA(f, x, y) { if (x < 0 || y < 0 || x >= f.w || y >= f.h) return 0; return f.data[(y * f.w + x) * 4 + 3]; }
  function getC(f, x, y) { var i = (y * f.w + x) * 4; return [f.data[i], f.data[i + 1], f.data[i + 2]]; }
  /** copy source pixel (sx,sy) to frame (x,y) when it is opaque; returns true when it drew */
  function copyPx(f, x, y, d, sw, sh, sx, sy) {
    if (sx < 0 || sy < 0 || sx >= sw || sy >= sh || x < 0 || y < 0 || x >= f.w || y >= f.h) return false;
    var j = (sy * sw + sx) * 4; if (d[j + 3] === 0) return false;
    var i = (y * f.w + x) * 4; f.data[i] = d[j]; f.data[i + 1] = d[j + 1]; f.data[i + 2] = d[j + 2]; f.data[i + 3] = d[j + 3];
    return true;
  }
  /** a shade of what is already at (x,y): the nearest of the piece's own colours to it at `k` brightness */
  function shadeAt(f, P, x, y, k) {
    if (getA(f, x, y) < 128) { put(f, x, y, P.floorShade, FLOOR_SHADE_A); return; }
    var c = getC(f, x, y), s = nearest(P.A.palette, c[0] * k, c[1] * k, c[2] * k);
    if (s[0] === c[0] && s[1] === c[1] && s[2] === c[2]) s = P.A.dark;   // nothing darker of that hue: the darkest colour
    put(f, x, y, s);
  }
  var FLOOR_SHADE_A = 96;

  /** A drawer pulled out toward the camera by `t` (0..1). */
  function drawDrawer(f, d, w, h, P, t) {
    var ox = P.pad.l, oy = P.pad.t, BH = P.A.bbox.y1 - P.A.bbox.y0;
    var open = P.open.slice().sort(function (a, b) { return P.fronts[b].y0 - P.fronts[a].y0; });   // lower fronts first
    var n = P.open.length, stag = n > 1 ? 0.15 : 0;
    for (var q = 0; q < open.length; q++) {
      var idx = open[q], F = P.fronts[idx], order = P.open.indexOf(idx);
      var tt = n > 1 ? clamp((t - order * stag) / (1 - (n - 1) * stag), 0, 1) : t;
      var fw = F.x1 - F.x0, fh = F.y1 - F.y0;
      // travel: about the front's own height, but never under a sixth of the piece (a 16 px-art front is 3 px tall and
      // a 3 px pull reads as a line, MEASURED on the contact sheet), never over a third
      var T = clamp(Math.round(Math.max(fh * 0.85, BH * 0.16)), 3, Math.max(3, Math.round(BH * 0.32)));
      var s = Math.round(tt * T);
      if (s <= 0) continue;
      // a pixel wider each side once it is well out (it is nearer the camera) - but never past the carcass: a front that
      // reaches its stile would poke out of the piece (LOOKED AT 2026-10-24, the fresh review: a gold edge past the side)
      var roomL = F.x0 - 1 >= P.A.bbox.x0 + 1, roomR = F.x1 + 1 <= P.A.bbox.x1 - 1;
      var e = s >= Math.max(3, Math.round(T * 0.6)) && roomL && roomR ? 1 : 0;
      var Fd = null, FdL = 1e9, Fl = null, FlL = -1;
      for (var yy = F.y0; yy < F.y1; yy++) for (var xx = F.x0; xx < F.x1; xx++) {
        var j = (yy * w + xx) * 4; if (d[j + 3] < 128) continue;
        var L = lum(d[j], d[j + 1], d[j + 2]);
        if (L < FdL) { FdL = L; Fd = [d[j], d[j + 1], d[j + 2]]; }
        if (L > FlL) { FlL = L; Fl = [d[j], d[j + 1], d[j + 2]]; }
      }
      if (!Fd) continue;
      var inside = interiorOf(Fd);
      P.derivedSeen.push.apply(P.derivedSeen, inside);
      // the drawer's own box, seen from above: side walls and back edge in the front's darkest colour, the inside in
      // bands of darkness, the lit top edge of the front panel along its leading edge
      for (var y = 0; y < s; y++) for (var x = F.x0; x < F.x1; x++) {
        var X = ox + x, Y = oy + F.y0 + y;
        if (x === F.x0 || x === F.x1 - 1 || y === 0) put(f, X, Y, Fd);
        else if (y === s - 1 && s >= 3) put(f, X, Y, Fl);
        else { put(f, X, Y, inside[Math.min(3, Math.floor(4 * (s - 1 - y) / Math.max(1, s)))]); f.mask[Y * f.w + X] = 1; }
      }
      // the front itself, moved down by s, a pixel wider each side once it is well out (it is nearer the camera)
      var dw = fw + 2 * e;
      for (var y2 = 0; y2 < fh; y2++) for (var x2 = 0; x2 < dw; x2++) {
        var sx = F.x0 + Math.min(fw - 1, Math.floor(x2 * fw / dw));
        var X2 = ox + F.x0 - e + x2, Y2 = oy + F.y0 + s + y2;
        if (copyPx(f, X2, Y2, d, w, h, sx, F.y0 + y2)) f.mask[Y2 * f.w + X2] = 0;
      }
      // its shadow on what is below it (the carcass, or the floor past the bottom of the piece)
      var sh = s >= 4 ? 2 : 1;
      for (var k = 0; k < sh; k++) for (var x3 = -e; x3 < fw + e; x3++) shadeAt(f, P, ox + F.x0 + x3, oy + F.y1 + s + k, 0.55);
      if (q === open.length - 1 || !P.mouth) P.mouth = { x: ox + F.x0 + fw / 2, y: oy + F.y0 + s / 2 };
    }
  }

  /** A lid lifted, tipped and set down askew on its rim by `t` (0..1); its shadow falls into the mouth. */
  function drawLid(f, d, w, h, P, t, spec) {
    var ox = P.pad.l, oy = P.pad.t, L0 = P.lid, A = P.A, bb = A.bbox;
    var side = spec && spec.side ? spec.side : 1;
    var lidH = L0.rimY - bb.y0, lidW = L0.lx1 - L0.lx0;
    var wallTone = nearest(A.palette, A.mean[0] * 0.5, A.mean[1] * 0.5, A.mean[2] * 0.5);
    var inside = A.interior;
    // 1. the mouth and the rim, where the lid was
    var my0 = 1e9, my1 = -1, mb = Math.max(L0.rimY, L0.mouthBottom || 0);
    for (var y = bb.y0; y < mb; y++) for (var x = L0.lx0; x < L0.lx1; x++) if (L0.mouthPx[y * w + x]) { if (y < my0) my0 = y; if (y > my1) my1 = y; }
    for (var y1 = bb.y0; y1 < mb; y1++) for (var x1 = L0.lx0; x1 < L0.lx1; x1++) {
      var i = y1 * w + x1;
      // below the rim only a thin lid's (or a round mouth's) pixels are painted; the body there is otherwise untouched
      if (!L0.foot[i] && !(y1 >= L0.rimY && (L0.mouthPx[i] || (L0.ring && L0.ring[i])))) continue;
      var X = ox + x1, Y = oy + y1;
      if (L0.round && !L0.mouthPx[i]) {
        // a round lid: the ellipse's rim ring catches the light; whatever else the lid covered is now EMPTY (the dome
        // stood in front of the wall, nothing of the body is there)
        // the lip's tone comes from the body two rows UNDER the rim, never the rim row itself: that row is the piece's dark
        // outline, and on a dark iron pot a lip lifted from it stayed near black, so the open mouth read as a black blade
        // with no rim round it (the third fresh review, 2026-10-24, on the cover, g3 and g4)
        if (L0.ring[i]) { var jb = (Math.min(bb.y1 - 1, L0.rimY + RING_SAMPLE) * w + x1) * 4; var bb0 = d[jb + 3] >= 128 ? [d[jb], d[jb + 1], d[jb + 2]] : A.mean; put(f, X, Y, nearest(A.palette, bb0[0] * RING_LIFT + 16, bb0[1] * RING_LIFT + 16, bb0[2] * RING_LIFT + 16)); }
        else put(f, X, Y, [0, 0, 0], 0);
        continue;
      }
      if (L0.mouthPx[i]) {
        var depth = (y1 - my0) / Math.max(1, my1 - my0);
        if (depth < 0.34) put(f, X, Y, wallTone);           // the far inside wall, in the piece's own shaded colour
        else put(f, X, Y, inside[Math.min(3, Math.floor((1 - depth) * 4 / 0.66))]);
        f.mask[Y * f.w + X] = depth >= 0.34 ? 1 : 0;
      } else {
        // the rim: the top edge of the body's own wall in that column, a shade lighter
        var by = Math.min(bb.y1 - 1, L0.rimY), j = (by * w + x1) * 4;
        var base = d[j + 3] >= 128 ? [d[j], d[j + 1], d[j + 2]] : A.mean;
        put(f, X, Y, nearest(A.palette, base[0] * 1.15 + 8, base[1] * 1.15 + 8, base[2] * 1.15 + 8));
      }
    }
    // 2. where the lid is: up, tipped, then across and down onto the rim (askew)
    var Lmax = Math.round(lidH * 0.8 + 3), restLift = Math.max(1, Math.round(lidH * 0.3));
    var lift, dx, tilt;
    // a gentler tilt (peak LID_TILT, resting a third of it): a whole-pixel copy of a rotated lid stair-steps, and at 24
    // degrees the steps read as a broken lid (the second fresh review, 2026-10-24)
    if (t <= 0.55) { var u = t / 0.55; lift = Math.round(u * Lmax); dx = 0; tilt = u * LID_TILT; }
    // it is set down askew a third of its width across (0.42 slid a thin plank out like a stick, the fresh review), and
    // never further than the frame's own margin can hold
    else { var v = (t - 0.55) / 0.45; lift = Math.round((1 - v) * Lmax + v * restLift); dx = Math.round(v * side * Math.min(LID_SLIDE * lidW, (side > 0 ? P.pad.r + (w - L0.lx1) : P.pad.l + L0.lx0) - 2)); tilt = LID_TILT * (1 - v * 0.66); }
    var rot = side * tilt * 0.45 * Math.PI / 180, sq = 1 - 0.32 * Math.sin(tilt * Math.PI / 180);
    var cx = (L0.lx0 + L0.lx1 - 1) / 2, cy = (bb.y0 + L0.rimY - 1) / 2;
    var ca = Math.cos(-rot), sa = Math.sin(-rot);
    var R = Math.ceil(Math.max(lidW, lidH) * 0.75) + 2;
    var drawn = newFrame(f.w, f.h);   // which frame pixels the lid covers (for the shadow and the underside)
    var Ld = null, LdL = 1e9;
    for (var y2 = bb.y0; y2 < L0.rimY; y2++) for (var x2 = L0.lx0; x2 < L0.lx1; x2++) { var jj = (y2 * w + x2) * 4; if (L0.foot[y2 * w + x2]) { var LL = lum(d[jj], d[jj + 1], d[jj + 2]); if (LL < LdL) { LdL = LL; Ld = [d[jj], d[jj + 1], d[jj + 2]]; } } }
    var px0 = Math.round(cx + dx), py0 = Math.round(cy - lift);
    // its shadow first: the lid's silhouette cast down and away from the light, on whatever is under it
    for (var Y3 = py0 - R; Y3 <= py0 + R; Y3++) for (var X3 = px0 - R; X3 <= px0 + R; X3++) {
      if (lidSrc(X3 - 1, Y3 - 2)) shadeAt(f, P, ox + X3, oy + Y3, 0.6);
    }
    for (var Y4 = py0 - R; Y4 <= py0 + R; Y4++) for (var X4 = px0 - R; X4 <= px0 + R; X4++) {
      var sp = lidSrc(X4, Y4);
      if (!sp) continue;
      if (copyPx(f, ox + X4, oy + Y4, d, w, h, sp[0], sp[1])) { drawn.mask[(oy + Y4) * f.w + ox + X4] = 1; f.mask[(oy + Y4) * f.w + ox + X4] = 0; }
    }
    // the lid's underside, seen because it is tipped: a strip of its own darkest colour under its lowest pixels
    var u2 = Math.round(Math.sin(tilt * Math.PI / 180) * lidH * 0.35);
    if (u2 > 0 && Ld) for (var X5 = 0; X5 < f.w; X5++) {
      var low = -1;
      for (var Y5 = f.h - 1; Y5 >= 0; Y5--) if (drawn.mask[Y5 * f.w + X5]) { low = Y5; break; }
      if (low < 0) continue;
      for (var k = 1; k <= u2; k++) { if (!drawn.mask[(low + k) * f.w + X5]) { put(f, X5, low + k, Ld); f.mask[(low + k) * f.w + X5] = 0; } }
    }
    // the item rises from the part of the mouth the lid leaves open
    var mx = 0, myy = 0, mn = 0;
    for (var q = 0; q < f.w * f.h; q++) if (f.mask[q]) { mx += q % f.w; myy += Math.floor(q / f.w); mn++; }
    P.mouth = mn ? { x: mx / mn, y: myy / mn } : { x: ox + cx, y: oy + cy };

    function lidSrc(X, Y) {   // frame-relative (tile coords) -> the lid pixel drawn there, or null
      var rx = X - px0, ry = Y - py0;
      var ux = rx * ca - ry * sa, uy = (rx * sa + ry * ca) / sq;
      var sx = Math.round(cx + ux), sy = Math.round(cy + uy);
      if (sx < L0.lx0 || sx >= L0.lx1 || sy < bb.y0 || sy >= L0.rimY || !L0.foot[sy * w + sx]) return null;
      return [sx, sy];
    }
  }

  /** A sack's tie loosened by `t`: the gathered top rolls down into a collar round a dark mouth, the body slumps. */
  function drawSack(f, d, w, h, P, t) {
    var ox = P.pad.l, oy = P.pad.t, A = P.A, bb = A.bbox, S = P.sack;
    var neck = S.neck, bodyH = bb.y1 - neck, topH = neck - bb.y0;
    var slump = Math.round(t * 0.12 * bodyH), widen = 1 + t * 0.08;
    var cx = (bb.x0 + bb.x1 - 1) / 2;
    // clear the piece and redraw it: body squashed into [neck+slump, y1) and widened about the centre
    for (var y = bb.y0; y < bb.y1; y++) for (var x = bb.x0; x < bb.x1; x++) put(f, ox + x, oy + y, [0, 0, 0], 0);
    var bodyTop = neck + slump, rows = bb.y1 - bodyTop, ext = Math.ceil((bb.x1 - bb.x0) * (widen - 1) / 2) + 1;
    for (var y2 = 0; y2 < rows; y2++) {
      var sy = neck + Math.min(bodyH - 1, Math.floor(y2 * bodyH / rows));
      for (var x2 = bb.x0 - ext; x2 < bb.x1 + ext; x2++) {
        var sx = Math.round(cx + (x2 - cx) / widen);
        copyPx(f, ox + x2, oy + bodyTop + y2, d, w, h, sx, sy);
      }
    }
    // the gathered top SINKS into the body as the tie lets go (gone by two thirds open): its cloth becomes the collar.
    // (Squashed and spread sideways it read as a bow tie, LOOKED AT 2026-10-24)
    var sink = clamp(t / 0.66, 0, 1), th = Math.round(topH * (1 - sink));
    var cr = 0, cg = 0, cb = 0, cn = 0;
    for (var y3 = 0; y3 < topH; y3++) for (var x3 = bb.x0; x3 < bb.x1; x3++) { var j3 = ((bb.y0 + y3) * w + x3) * 4; if (d[j3 + 3] < 128) continue; cr += d[j3]; cg += d[j3 + 1]; cb += d[j3 + 2]; cn++; }
    for (var y4 = 0; y4 < th; y4++) {
      var sy4 = bb.y0 + topH - th + y4;
      for (var x4 = bb.x0; x4 < bb.x1; x4++) copyPx(f, ox + x4, oy + bodyTop - th + y4 + 1, d, w, h, x4, sy4);
    }
    // THE COLLAR AND THE MOUTH: an ellipse on the top of the slumped body, as wide as the body's own top; a rolled ring
    // of the sack's own cloth colour, lit on its far edge, round darkness. Seated ON the body (drawn at the neck it floated
    // above the body as a black oval in the air, the fresh review, 2026-10-24)
    var ta = -1, tb = -1;
    for (var xt = 0; xt < f.w; xt++) if (getA(f, xt, oy + bodyTop + 2) >= 128) { if (ta < 0) ta = xt; tb = xt; }
    // sized from the body's WIDEST row: an untied sack's top flares out onto its shoulders (sized from the narrow shoulder
    // the mouth was a pinhole, LOOKED AT 2026-10-24)
    var bodyW = S.bodyW || (ta >= 0 ? tb - ta + 1 : bb.x1 - bb.x0);
    var a = Math.round(t * Math.max(bodyW * SACK_MOUTH, 3.5)), b = Math.max(2, Math.round(a * ELLIPSE_RATIO));
    // under four pixels across an ellipse reads as a "+" (LOOKED AT: the 1/4 and 3/4 stages), so it appears once it can read
    if (a >= 4) {
      var cloth = cn ? nearest(A.palette, cr / cn, cg / cn, cb / cn) : A.light;
      var litC = nearest(A.palette, cloth[0] * 1.18 + 10, cloth[1] * 1.18 + 10, cloth[2] * 1.18 + 10);
      var shadeC = nearest(A.palette, cloth[0] * 0.72, cloth[1] * 0.72, cloth[2] * 0.72);
      var mcx = ta >= 0 ? (ta + tb) / 2 - ox : cx, my = bodyTop + 1 + b;
      for (var Y = -b - 2; Y <= b + 2; Y++) for (var X = -a - 2; X <= a + 2; X++) {
        var q = (X * X) / (a * a) + (Y * Y) / (b * b);
        var qo = (X * X) / ((a + 2) * (a + 2)) + (Y * Y) / ((b + 1.5) * (b + 1.5));
        var px = Math.round(mcx + X) + ox, py = my + Y + oy;
        if (q <= 1) {
          var band = Math.min(3, Math.floor((Y + b) / Math.max(1, 2 * b) * 4));   // the far side deepest, the near side less so
          put(f, px, py, A.interior[band]); f.mask[py * f.w + px] = 1;
        } else if (qo <= 1) put(f, px, py, Y < 0 ? litC : Y > b ? shadeC : cloth);
      }
      P.mouth = { x: ox + mcx, y: oy + my };
    } else P.mouth = { x: ox + cx, y: oy + neck };
  }

  /** Books tipped out of line by `t`: one pulled toward the camera, two leaning, dark gaps behind them. */
  function drawShelf(f, d, w, h, P, t) {
    var ox = P.pad.l, oy = P.pad.t, A = P.A, S = P.shelf;
    var unit = Math.max(1, Math.round((A.bbox.x1 - A.bbox.x0) / 24));
    var pageTone = A.light;
    S.picks.forEach(function (sp, i) {
      var sw = sp.x1 - sp.x0, sh = sp.y1 - sp.y0;
      // the gap a book leaves shows the BACK OF THE SHELF in its own colour (near-black slivers read as holes, the second
      // fresh review, 2026-10-24); the pulled book's own top covers most of its gap
      for (var y = sp.y0; y < sp.y1; y++) for (var x = sp.x0; x < sp.x1; x++) { put(f, ox + x, oy + y, S.backTone); f.mask[(oy + y) * f.w + ox + x] = i === 0 ? 1 : 0; }
      if (i === 0) {
        // PULLED: it TIPS toward you about its foot, which stays on the board: the spine shortens from the top and the
        // book's own top (its page edges, in the piece's lightest colour, edged in its own spine colour) appears above it.
        // (Slid down whole it fell through the shelf board below, the second fresh review)
        var dy = Math.min(Math.round(sh * 0.45), Math.round(t * SHELF_PULL * unit)), e = t > 0.6 && sp.x0 - 1 > A.bbox.x0 && sp.x1 + 1 < A.bbox.x1 ? 1 : 0;
        var spineH = sh - dy;
        for (var y2 = 0; y2 < spineH; y2++) for (var x2 = 0; x2 < sw + 2 * e; x2++) {
          var sx = sp.x0 + Math.min(sw - 1, Math.floor(x2 * sw / (sw + 2 * e))), sy = sp.y0 + Math.min(sh - 1, Math.floor(y2 * sh / Math.max(1, spineH)));
          var X = ox + sp.x0 - e + x2, Y = oy + sp.y0 + dy + y2;
          if (copyPx(f, X, Y, d, w, h, sx, sy)) f.mask[Y * f.w + X] = 0;
        }
        var spineC = [d[((sp.y0 + (sh >> 1)) * w + sp.x0 + (sw >> 1)) * 4], d[((sp.y0 + (sh >> 1)) * w + sp.x0 + (sw >> 1)) * 4 + 1], d[((sp.y0 + (sh >> 1)) * w + sp.x0 + (sw >> 1)) * 4 + 2]];
        for (var y3 = Math.max(0, dy - Math.max(2, Math.round(dy * 0.8))); y3 < dy; y3++) for (var x3 = -e; x3 < sw + e; x3++) {
          var edge = x3 === -e || x3 === sw + e - 1;
          put(f, ox + sp.x0 + x3, oy + sp.y0 + y3, edge ? spineC : pageTone); f.mask[(oy + sp.y0 + y3) * f.w + ox + sp.x0 + x3] = 0;
        }
        P.mouth = { x: ox + (sp.x0 + sp.x1) / 2, y: oy + sp.y0 + 1 };
      } else {
        // LEANING: the foot stays, the top tips toward the neighbour by up to two units
        // ...and a leaning top never crosses the carcass's side (a book near the stile leaned out of the case, the review)
        var dir = i === 1 ? 1 : -1, room = dir > 0 ? A.bbox.x1 - 2 - sp.x1 : sp.x0 - (A.bbox.x0 + 1);
        var lean = Math.max(0, Math.min(Math.round(t * 2 * unit), room));
        for (var y4 = 0; y4 < sh; y4++) {
          var off = Math.round(dir * lean * (1 - y4 / Math.max(1, sh - 1)));
          for (var x4 = 0; x4 < sw; x4++) {
            var X4 = ox + sp.x0 + x4 + off, Y4 = oy + sp.y0 + y4;
            if (copyPx(f, X4, Y4, d, w, h, sp.x0 + x4, sp.y0 + y4)) f.mask[Y4 * f.w + X4] = 0;
          }
        }
      }
    });
    if (!P.mouth) P.mouth = { x: ox + (A.bbox.x0 + A.bbox.x1) / 2, y: oy + (A.bbox.y0 + A.bbox.y1) / 2 };
  }

  /** A glint (opt-in) on a closed piece: a small four point star on its brightest edge, `phase` 0..1. */
  function addGlint(f, P, phase) {
    var A = P.A, bb = A.bbox;
    var x = P.pad.l + Math.round(bb.x0 + (bb.x1 - bb.x0) * 0.72), y = P.pad.t + Math.round(bb.y0 + (bb.y1 - bb.y0) * 0.28);
    var size = Math.round(Math.sin(phase * Math.PI) * Math.max(2, (bb.x1 - bb.x0) / 12));
    if (size <= 0) return;
    put(f, x, y, GLINT_CORE);
    for (var k = 1; k <= size; k++) {
      var c = k === 1 ? A.light : GLINT_EDGE;
      put(f, x + k, y, c); put(f, x - k, y, c); put(f, x, y + k, c); put(f, x, y - k, c);
    }
  }
  var GLINT_CORE = [255, 255, 255];
  var GLINT_EDGE = [255, 246, 214];

  /** Dust shaken out of an empty search: motes rising out of the opening in the piece's lightest colour. */
  function addDust(f, P, phase, seed) {
    var s = (seed >>> 0) || 7;
    var rnd = function () { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; };
    var m = P.mouth || { x: f.w / 2, y: f.h / 2 }, light = P.A.light;
    var n = Math.max(4, Math.round(P.w / 8)), size = Math.max(1, Math.round(P.w / 32));
    for (var i = 0; i < n; i++) {
      var ph = phase * 1.2 - rnd() * 0.2, ang = (rnd() - 0.5) * 2.2, sp = 0.4 + rnd() * 0.8;
      if (ph <= 0 || ph >= 1) continue;
      var px = Math.round(m.x + Math.sin(ang) * ph * P.w * 0.32 * sp), py = Math.round(m.y - ph * P.h * 0.4 * sp);
      var big = ph < 0.6 ? size : Math.max(1, size - 1);
      for (var by = 0; by < big; by++) for (var bx = 0; bx < big; bx++) put(f, px + bx, py + by, light);
    }
  }

  /**
   * THE ENTRY POINT. The pixels of a piece at one point of its opening, inside its padded frame.
   * @param {{data:Uint8ClampedArray|number[], w:number, h:number}} src  the piece (one tile, or a grouped block)
   * @param {object} spec  parseNote() output: {kind, band, all, rim, side, ...}
   * @param {number} t     0 closed .. 1 open
   * @param {{plan?:object, glint?:number, dust?:number, seed?:number}} [opt]  glint/dust: a phase 0..1 to overlay
   * @returns {{data:Uint8ClampedArray, mask:Uint8Array, w:number, h:number, pad:object, mouth:{x:number,y:number}, derived:number[][], detected:boolean}}
   *          mask = 1 where the dark inside of the opening shows; mouth = where the found item rises from
   */
  function frame(src, spec, t, opt) {
    opt = opt || {};
    if (!spec || KINDS.indexOf(spec.kind) < 0) throw new Error('AjarCore.frame: unknown kind ' + JSON.stringify(spec && spec.kind));
    var w = src.w, h = src.h, d = src.data;
    if (!(w > 0 && h > 0) || d.length !== w * h * 4) throw new Error('AjarCore.frame: ' + w + 'x' + h + ' does not match ' + d.length + ' bytes');
    t = clamp(Number(t) || 0, 0, 1);
    var base = opt.plan || plan(src, spec);
    var P = Object.create(base);
    P.derivedSeen = []; P.mouth = null;
    P.floorShade = [Math.round(base.A.dark[0] * 0.3), Math.round(base.A.dark[1] * 0.3), Math.round(base.A.dark[2] * 0.3)];
    var pad = base.pad, f = newFrame(w + pad.l + pad.r, h + pad.t + pad.b);
    for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) copyPx(f, pad.l + x, pad.t + y, d, w, h, x, y);   // closed: your tile, byte for byte
    if (!base.A.empty && t > 0) {
      if (spec.kind === 'drawer') drawDrawer(f, d, w, h, P, t);
      else if (spec.kind === 'lid') drawLid(f, d, w, h, P, t, spec);
      else if (spec.kind === 'sack') drawSack(f, d, w, h, P, t);
      else if (spec.kind === 'shelf') drawShelf(f, d, w, h, P, t);
    }
    if (!P.mouth) P.mouth = mouthAtRest(base);
    if (opt.glint != null && !base.A.empty) addGlint(f, P, opt.glint);
    if (opt.dust != null && !base.A.empty) addDust(f, P, opt.dust, opt.seed || 1);
    f.pad = pad; f.mouth = P.mouth; f.detected = !!base.detected;
    // the CLOSED list of colours a frame may use that are not the piece's own pixels (tests read it and refuse a list
    // longer than 14: a derived palette that grows is a frame inventing colours under a different name)
    f.derived = [P.floorShade, GLINT_CORE, GLINT_EDGE].concat(base.A.interior, uniq(P.derivedSeen));
    return f;
  }
  function uniq(list) { var seen = {}, out = []; list.forEach(function (c) { var k = c.join(','); if (!seen[k]) { seen[k] = 1; out.push(c); } }); return out; }
  /** Where the item would rise from a piece that has not moved yet (the plugin asks this for the open frame). */
  function mouthAtRest(P) { var bb = P.A.bbox; return { x: P.pad.l + (bb.x0 + bb.x1) / 2, y: P.pad.t + bb.y0 + (bb.y1 - bb.y0) * 0.35 }; }

  /** Where a B-E tile sits on its sheet: page, column, row (the engine's own arithmetic, rmmz_sprites.js:316). */
  function sheetPos(tileId) { return { page: Math.floor(tileId / 256), col: (Math.floor(tileId / 128) % 2) * 8 + (tileId % 8), row: Math.floor((tileId % 256) / 8) % 16 }; }
  /**
   * Two map neighbours are parts of ONE drawn object only when their tiles sit the same way round on the tileset
   * sheet: the tile to the right on the map is the tile to the right on the sheet, the tile below is the tile below.
   * A dresser placed beside a desk comes from somewhere else on the sheet and stays its own piece. (Without the tile
   * ids, adjacency alone decides, as before.)
   */
  function sameObject(m, n) {
    if (m.tile == null || n.tile == null) return true;
    var a = sheetPos(m.tile), b = sheetPos(n.tile);
    return a.page === b.page && b.col - a.col === n.x - m.x && b.row - a.row === n.y - m.y;
  }
  /**
   * Group adjacent pieces of the same kind into one piece (a two tile desk, a two tall bookcase).
   * @param {{id:number, x:number, y:number, kind:string, group?:boolean, tile?:number}[]} pieces
   * @returns {{key:string, kind:string, x:number, y:number, cols:number, rows:number, ids:number[], lead:number}[]}
   *          lead = the member that draws the whole piece (the bottom row, leftmost: it sorts in front correctly)
   */
  function groupPieces(pieces) {
    var byPos = {}, seen = {}, out = [];
    pieces.forEach(function (p) { byPos[p.x + ',' + p.y] = p; });
    pieces.slice().sort(function (a, b) { return a.y - b.y || a.x - b.x; }).forEach(function (p) {
      if (seen[p.id]) return;
      var members = [p]; seen[p.id] = 1;
      if (p.group !== false) {
        for (var i = 0; i < members.length; i++) {
          var m = members[i];
          [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(function (o) {
            var n = byPos[(m.x + o[0]) + ',' + (m.y + o[1])];
            if (n && !seen[n.id] && n.kind === p.kind && n.group !== false && sameObject(m, n)) { seen[n.id] = 1; members.push(n); }
          });
        }
      }
      var xs = members.map(function (m) { return m.x; }), ys = members.map(function (m) { return m.y; });
      var x0 = Math.min.apply(null, xs), y0 = Math.min.apply(null, ys);
      var cols = Math.max.apply(null, xs) - x0 + 1, rows = Math.max.apply(null, ys) - y0 + 1;
      // a group is a full rectangle. A connected block that is not one keeps the largest rectangle that starts at its
      // top-left member (its run along that row, then every full row below it) and the rest are looked at again
      if (members.length !== cols * rows) {
        var has = {};
        members.forEach(function (m) { has[m.x + ',' + m.y] = m; });
        var w0 = 1; while (has[(p.x + w0) + ',' + p.y]) w0++;
        var h0 = 1, full = true;
        while (full) { for (var dx = 0; dx < w0; dx++) if (!has[(p.x + dx) + ',' + (p.y + h0)]) { full = false; break; } if (full) h0++; }
        var keep = [];
        members.forEach(function (m) { if (m.x >= p.x && m.x < p.x + w0 && m.y >= p.y && m.y < p.y + h0) keep.push(m); else delete seen[m.id]; });
        members = keep; x0 = p.x; y0 = p.y; cols = w0; rows = h0;
      }
      var lead = members.slice().sort(function (a, b) { return b.y - a.y || a.x - b.x; })[0];
      out.push({ key: p.kind + '@' + x0 + ',' + y0, kind: p.kind, x: x0, y: y0, cols: cols, rows: rows, ids: members.map(function (m) { return m.id; }).sort(function (a, b) { return a - b; }), lead: lead.id });
    });
    return out;
  }

  var API = {
    KINDS: KINDS, ALIAS: ALIAS, OPEN_STEPS: OPEN_STEPS, GLINT_STEPS: GLINT_STEPS, DUST_STEPS: DUST_STEPS,
    parseNote: parseNote, analyse: analyse, plan: plan, frame: frame, padOf: padOf, groupPieces: groupPieces, sheetPos: sheetPos,
    drawerFronts: drawerFronts, frontsAt: frontsAt, chooseFronts: chooseFronts, lidPlan: lidPlan, sackPlan: sackPlan, shelfPlan: shelfPlan,
    nearest: nearest, interiorOf: interiorOf, DARK_CUT: DARK_CUT, FRONT_FILL: FRONT_FILL, LID_BREAK: LID_BREAK, BOOK_BUSY: BOOK_BUSY,
    VERSION: '1.0.0',
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  root.AjarCore = API;
})(typeof window !== 'undefined' ? window : globalThis);
