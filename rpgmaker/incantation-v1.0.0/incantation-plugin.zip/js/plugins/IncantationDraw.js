/*:
 * @target MZ
 * @plugindesc Incantation 2/3 - the drawing kit: three stages, word plates, ignited letters, candles. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * IncantationDraw.js - part of Incantation v1.0.0. Enable it with
 * IncantationCore.js and Incantation.js (any order). It has no commands or
 * parameters of its own; Incantation.js reads it.
 *
 * Every line of this plugin was written with AI assistance.
 */
/*
 * Everything the player sees, drawn with the canvas 2D API into whatever context it is handed: the stage (a corridor in
 * perspective, each stage a different place, never a recolour, wing §21a), the word plates with each typed letter
 * igniting, the candles that count lives, the score band and the results panel. Pure drawing, no engine calls, so a
 * contact sheet can render it outside MZ. The scene draws each piece ONCE per change into its own bitmap; nothing here
 * runs per frame.
 */
var IncantationDraw = (function () {
  'use strict';
  var TAU = Math.PI * 2;
  var FONT = '"Palatino Linotype", "Book Antiqua", Palatino, Georgia, serif';
  var STAGE = {
    crypt: { name: 'The Crypt', sky: '#120d0b', wall: '#3a302a', wall2: '#241d19', floor: '#2b2420', line: '#5a4a3e', glow: '#ffb24a', plate: '#1a1310', plateInk: '#cdbfa8', ignite: '#ffd27a', trim: '#b4884a', hud: '#f3e3c4' },
    grove: { name: 'The Night Grove', sky: '#0b1426', wall: '#0f1d18', wall2: '#08120e', floor: '#2a2a1c', line: '#4d4a30', glow: '#b8f07a', plate: '#0c1712', plateInk: '#c8d6c0', ignite: '#d9ff9e', trim: '#6f9a55', hud: '#e6f2dc' },
    void: { name: 'The Void Library', sky: '#0d0820', wall: '#1d1340', wall2: '#120b2c', floor: '#140c2e', line: '#6a4fd6', glow: '#9fd2ff', plate: '#100a24', plateInk: '#cbc3ee', ignite: '#a8e4ff', trim: '#8a6cff', hud: '#ece6ff' }
  };
  var THEMES = Object.keys(STAGE);

  function text(g, s, x, y, size, color, align, weight) { g.font = (weight || '700') + ' ' + size + 'px ' + FONT; g.fillStyle = color; g.textAlign = align || 'left'; g.textBaseline = 'middle'; g.fillText(s, x, y); }
  function roundRect(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.lineTo(x + w - r, y); g.quadraticCurveTo(x + w, y, x + w, y + r); g.lineTo(x + w, y + h - r); g.quadraticCurveTo(x + w, y + h, x + w - r, y + h); g.lineTo(x + r, y + h); g.quadraticCurveTo(x, y + h, x, y + h - r); g.lineTo(x, y + r); g.quadraticCurveTo(x, y, x + r, y); g.closePath(); }
  function rgba(hex, a) { var n = parseInt(hex.slice(1), 16); return 'rgba(' + (n >> 16 & 255) + ',' + (n >> 8 & 255) + ',' + (n & 255) + ',' + a + ')'; }
  /** A tiny seeded stream for scenery (stars, stones), so a stage draws the same every time. */
  function scatter(seed) { var s = seed | 0; return function () { s = (s + 0x6D2B79F5) | 0; var t = Math.imul(s ^ (s >>> 15), s | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

  /* ---------------------------------------------------------------- perspective */
  var HORIZON = 0.34, GROUND = 0.84;
  /**
   * Where a foe stands: lane of lanes at progress t (0 far, 1 at the party). Depth eases in (t^1.6) so a foe seems to
   * speed up as it nears. Returns screen x, the foot y and a scale for the foe's picture.
   */
  function lanePoint(W, H, lane, lanes, t) {
    var e = Math.pow(Math.max(0, Math.min(1, t)), 1.6), y0 = H * HORIZON, y1 = H * GROUND;
    var off = lanes > 1 ? (lane / (lanes - 1)) * 2 - 1 : 0;
    return { x: W / 2 + off * (W * 0.15 + e * W * 0.27), y: y0 + (y1 - y0) * e, s: 0.22 + 0.78 * e, e: e };
  }

  /* ---------------------------------------------------------------- the stages */
  function corridorWalls(g, W, H, T) {
    var vx = W / 2, vy = H * HORIZON;
    g.fillStyle = T.wall; g.beginPath(); g.moveTo(0, 0); g.lineTo(vx - W * 0.09, vy - H * 0.1); g.lineTo(vx - W * 0.09, vy + H * 0.02); g.lineTo(0, H); g.closePath(); g.fill();
    g.fillStyle = T.wall2; g.beginPath(); g.moveTo(W, 0); g.lineTo(vx + W * 0.09, vy - H * 0.1); g.lineTo(vx + W * 0.09, vy + H * 0.02); g.lineTo(W, H); g.closePath(); g.fill();
    g.fillStyle = T.floor; g.beginPath(); g.moveTo(0, H); g.lineTo(vx - W * 0.09, vy + H * 0.02); g.lineTo(vx + W * 0.09, vy + H * 0.02); g.lineTo(W, H); g.closePath(); g.fill();
  }
  function crypt(g, W, H, T) {
    g.fillStyle = T.sky; g.fillRect(0, 0, W, H);
    corridorWalls(g, W, H, T);
    var vx = W / 2, vy = H * HORIZON, rnd = scatter(11);
    // flagstones: converging seams and courses spaced in perspective
    g.strokeStyle = rgba(T.line, 0.55); g.lineWidth = 1.2;
    for (var i = -6; i <= 6; i++) { g.beginPath(); g.moveTo(vx + i * W * 0.012, vy + H * 0.02); g.lineTo(vx + i * W * 0.16, H); g.stroke(); }
    for (var k = 1; k < 12; k++) { var e = Math.pow(k / 12, 1.7), y = vy + H * 0.02 + (H - vy) * e, hw = W * 0.09 + (W * 0.41) * e; g.beginPath(); g.moveTo(vx - hw, y); g.lineTo(vx + hw, y); g.stroke(); }
    // receding arches, far to near, each standing ON the floor at its own depth with its crown inside the frame
    // (2026-10-08 contact sheet: the first version put every crown off-screen and the arches read as bars)
    for (var a = 0; a < 6; a++) {
      var e = 0.04 + 0.86 * Math.pow(a / 5, 1.7), hw = W * 0.09 + W * 0.41 * e, base = vy + H * 0.02 + (H - vy) * e;
      var crown = (vy - H * 0.1) * (1 - e) + H * 0.035 * e, r = Math.min(hw, (base - crown) * 0.6), spring = crown + r, lw = 3 + 14 * e;
      g.strokeStyle = rgba(T.trim, 0.3 + 0.5 * e); g.lineWidth = lw;
      g.beginPath(); g.moveTo(vx - hw, base); g.lineTo(vx - hw, spring); g.ellipse(vx, spring, hw, r, 0, Math.PI, 0); g.lineTo(vx + hw, base); g.stroke();
      g.strokeStyle = rgba('#000000', 0.4); g.lineWidth = Math.max(1, lw * 0.15);
      for (var v = 1; v < 11; v++) { var ang = Math.PI + v * Math.PI / 11, c0 = Math.cos(ang), s0 = Math.sin(ang); g.beginPath(); g.moveTo(vx + c0 * (hw - lw / 2), spring + s0 * (r - lw / 2)); g.lineTo(vx + c0 * (hw + lw / 2), spring + s0 * (r + lw / 2)); g.stroke(); }
    }
    // wall stones
    g.fillStyle = rgba('#000000', 0.18);
    for (var s = 0; s < 70; s++) { var sx = rnd() < 0.5 ? rnd() * W * 0.3 : W - rnd() * W * 0.3, sy = rnd() * H * 0.9; g.fillRect(sx, sy, 18 + rnd() * 26, 8 + rnd() * 8); }
    // torches with their light
    [[W * 0.12, H * 0.36], [W * 0.88, H * 0.36], [W * 0.33, H * 0.3], [W * 0.67, H * 0.3]].forEach(function (p, i) {
      var r = i < 2 ? 150 : 70, glow = g.createRadialGradient(p[0], p[1], 2, p[0], p[1], r); glow.addColorStop(0, rgba(T.glow, 0.55)); glow.addColorStop(1, rgba(T.glow, 0));
      g.fillStyle = glow; g.fillRect(p[0] - r, p[1] - r, r * 2, r * 2);
      g.fillStyle = '#4a3624'; g.fillRect(p[0] - 3, p[1], 6, i < 2 ? 34 : 16);
      g.fillStyle = T.glow; g.beginPath(); g.ellipse(p[0], p[1] - 4, i < 2 ? 7 : 4, i < 2 ? 14 : 8, 0, 0, TAU); g.fill();
      g.fillStyle = '#fff3d6'; g.beginPath(); g.ellipse(p[0], p[1], i < 2 ? 3 : 2, i < 2 ? 6 : 4, 0, 0, TAU); g.fill();
    });
  }
  function grove(g, W, H, T) {
    var sky = g.createLinearGradient(0, 0, 0, H * 0.6); sky.addColorStop(0, '#050a18'); sky.addColorStop(1, T.sky); g.fillStyle = sky; g.fillRect(0, 0, W, H);
    var rnd = scatter(23), vx = W / 2, vy = H * HORIZON;
    for (var i = 0; i < 140; i++) { g.fillStyle = rgba('#ffffff', 0.3 + rnd() * 0.6); g.fillRect(rnd() * W, rnd() * H * 0.34, rnd() < 0.1 ? 2 : 1, rnd() < 0.1 ? 2 : 1); }
    g.fillStyle = '#f2ecd0'; g.beginPath(); g.arc(W * 0.78, H * 0.12, 26, 0, TAU); g.fill(); g.fillStyle = T.sky; g.beginPath(); g.arc(W * 0.78 + 10, H * 0.12 - 6, 24, 0, TAU); g.fill();
    g.fillStyle = T.wall2; g.fillRect(0, vy - 2, W, H);
    // the path
    g.fillStyle = T.floor; g.beginPath(); g.moveTo(vx - W * 0.03, vy); g.lineTo(vx + W * 0.03, vy); g.lineTo(W * 0.92, H); g.lineTo(W * 0.08, H); g.closePath(); g.fill();
    g.strokeStyle = rgba(T.line, 0.7); g.lineWidth = 2; g.beginPath(); g.moveTo(vx - W * 0.03, vy); g.lineTo(W * 0.08, H); g.moveTo(vx + W * 0.03, vy); g.lineTo(W * 0.92, H); g.stroke();
    // pebbles in perspective
    for (var p = 0; p < 90; p++) { var e = Math.pow(rnd(), 1.6), y = vy + (H - vy) * e, hw = W * 0.03 + W * 0.42 * e; g.fillStyle = rgba(T.line, 0.5); g.beginPath(); g.ellipse(vx + (rnd() * 2 - 1) * hw, y, 1 + 4 * e, 0.6 + 2 * e, 0, 0, TAU); g.fill(); }
    // trees receding on both sides: trunk + layered crowns, darker with distance
    for (var t = 7; t >= 0; t--) {
      var d = t / 7, ee = Math.pow(1 - d, 1.6), base = vy + (H - vy) * ee * 0.95, hgt = 40 + 420 * ee;
      [-1, 1].forEach(function (side) {
        var x = vx + side * (W * 0.07 + W * 0.43 * ee + 30 * ee);
        g.fillStyle = rgba('#000000', 0.55 + 0.35 * d); g.fillRect(x - 3 - 9 * ee, base - hgt * 0.4, 6 + 18 * ee, hgt * 0.4);
        for (var c = 0; c < 3; c++) { g.fillStyle = c % 2 ? T.wall : T.wall2; g.beginPath(); g.moveTo(x, base - hgt * (1 - c * 0.2)); g.lineTo(x - hgt * (0.22 + c * 0.06), base - hgt * (0.45 - c * 0.12)); g.lineTo(x + hgt * (0.22 + c * 0.06), base - hgt * (0.45 - c * 0.12)); g.closePath(); g.fill(); }
      });
    }
    // fireflies
    for (var f = 0; f < 26; f++) { var fx = rnd() * W, fy = vy + rnd() * (H - vy) * 0.8, gl = g.createRadialGradient(fx, fy, 0, fx, fy, 9); gl.addColorStop(0, rgba(T.glow, 0.9)); gl.addColorStop(1, rgba(T.glow, 0)); g.fillStyle = gl; g.fillRect(fx - 9, fy - 9, 18, 18); }
  }
  function voidLibrary(g, W, H, T) {
    var sky = g.createRadialGradient(W / 2, H * HORIZON, 10, W / 2, H * HORIZON, W * 0.8); sky.addColorStop(0, '#2a1b5c'); sky.addColorStop(1, T.sky); g.fillStyle = sky; g.fillRect(0, 0, W, H);
    var rnd = scatter(37), vx = W / 2, vy = H * HORIZON;
    for (var i = 0; i < 160; i++) { g.fillStyle = rgba(i % 3 ? '#ffffff' : T.glow, 0.25 + rnd() * 0.6); g.fillRect(rnd() * W, rnd() * H, 1, 1); }
    // floating shelves of books receding on both sides
    for (var s = 6; s >= 0; s--) {
      var d = s / 6, e = Math.pow(1 - d, 1.6), y = vy - 30 + (H - vy) * e * 0.7, h = 20 + 120 * e, w = 40 + 170 * e;
      [-1, 1].forEach(function (side) {
        var x = vx + side * (W * 0.08 + W * 0.36 * e) - (side < 0 ? w : 0);
        g.fillStyle = rgba(T.wall, 0.95); g.fillRect(x, y - h, w, h);
        var bx = x + 3; while (bx < x + w - 4) { var bw = 3 + rnd() * 7 * (0.4 + e); g.fillStyle = ['#7a3b5c', '#3b5c7a', '#7a6a3b', '#4a7a3b', '#5c3b7a'][Math.floor(rnd() * 5)]; g.fillRect(bx, y - h + 4 + rnd() * 6 * e, bw, h - 8 - rnd() * 6 * e); bx += bw + 1; }
        g.fillStyle = T.trim; g.fillRect(x - 2, y, w + 4, 2 + 3 * e);
      });
    }
    // a glowing perspective grid floor
    g.strokeStyle = rgba(T.line, 0.55); g.lineWidth = 1;
    for (var l = -10; l <= 10; l++) { g.beginPath(); g.moveTo(vx + l * W * 0.01, vy + H * 0.04); g.lineTo(vx + l * W * 0.1, H); g.stroke(); }
    for (var k = 1; k < 13; k++) { var ek = Math.pow(k / 13, 1.8), yk = vy + H * 0.04 + (H - vy) * ek; g.beginPath(); g.moveTo(0, yk); g.lineTo(W, yk); g.stroke(); }
    // rune rings hanging in the distance
    [[vx, vy - 40, 70], [vx - W * 0.28, vy - 120, 34], [vx + W * 0.3, vy - 110, 40]].forEach(function (r, n) {
      g.strokeStyle = rgba(T.glow, 0.7); g.lineWidth = 2; g.beginPath(); g.arc(r[0], r[1], r[2], 0, TAU); g.stroke();
      g.strokeStyle = rgba(T.trim, 0.8); g.beginPath(); g.arc(r[0], r[1], r[2] * 0.78, 0, TAU); g.stroke();
      for (var m = 0; m < 12; m++) { var a = m * TAU / 12 + n; g.beginPath(); g.moveTo(r[0] + Math.cos(a) * r[2] * 0.8, r[1] + Math.sin(a) * r[2] * 0.8); g.lineTo(r[0] + Math.cos(a) * r[2] * 0.96, r[1] + Math.sin(a) * r[2] * 0.96); g.stroke(); }
    });
  }
  /** The stage, filling W x H. */
  function backdrop(g, W, H, theme) {
    var T = STAGE[theme] || STAGE.crypt;
    g.save(); if (theme === 'grove') grove(g, W, H, T); else if (theme === 'void') voidLibrary(g, W, H, T); else crypt(g, W, H, T);
    var vig = g.createRadialGradient(W / 2, H * 0.55, H * 0.3, W / 2, H * 0.55, W * 0.75); vig.addColorStop(0, 'rgba(0,0,0,0)'); vig.addColorStop(1, 'rgba(0,0,0,0.55)');
    g.fillStyle = vig; g.fillRect(0, 0, W, H); g.restore();
  }

  /* ---------------------------------------------------------------- the word plate */
  var TRACK = 0.12;
  /** Width and height a plate needs for this word at this letter size. */
  function plateSize(g, word, size) {
    g.font = '700 ' + size + 'px ' + FONT;
    var w = 0, s = word.toUpperCase();
    for (var i = 0; i < s.length; i++) w += (s[i] === ' ' ? size * 0.45 : g.measureText(s[i]).width) + size * TRACK;
    return { w: Math.ceil(w + size * 1.4), h: Math.ceil(size * 1.9) };
  }
  /**
   * A word on its plate: typed letters IGNITE (the stage's ignite colour, a glow, a spark dot under each), letters still
   * to type in the plate ink; a locked plate is lifted with a bright trim and a pointer; a missed key reddens the trim.
   * Draws into a context already sized by plateSize (with 12 px of margin for the glow). Returns what it drew.
   */
  function plate(g, word, typed, theme, size, state) {
    var T = STAGE[theme] || STAGE.crypt, ps = plateSize(g, word, size), x = 12, y = 12, w = ps.w, h = ps.h, s = word.toUpperCase();
    g.save();
    g.fillStyle = 'rgba(0,0,0,0.45)'; roundRect(g, x + 2, y + 4, w, h, h * 0.3); g.fill();
    g.fillStyle = rgba(T.plate, state === 'locked' ? 0.92 : 0.8); roundRect(g, x, y, w, h, h * 0.3); g.fill();
    g.lineWidth = state === 'locked' ? 3 : 1.5; g.strokeStyle = state === 'miss' ? '#e0483a' : state === 'locked' ? T.ignite : rgba(T.trim, 0.85);
    if (state === 'locked') { g.shadowColor = T.ignite; g.shadowBlur = 10; }
    roundRect(g, x + 1, y + 1, w - 2, h - 2, h * 0.3 - 1); g.stroke(); g.shadowBlur = 0;
    var cx = x + size * 0.7, cy = y + h / 2 + 1, lit = 0;
    g.font = '700 ' + size + 'px ' + FONT; g.textBaseline = 'middle'; g.textAlign = 'left';
    for (var i = 0; i < s.length; i++) {
      var ch = s[i], cw = ch === ' ' ? size * 0.45 : g.measureText(ch).width;
      if (ch === ' ') { g.fillStyle = rgba(i < typed ? T.ignite : T.plateInk, 0.6); g.beginPath(); g.arc(cx + cw / 2, cy, size * 0.06, 0, TAU); g.fill(); }
      else if (i < typed) {
        // IGNITED: a halo behind, the letter in the stage's flame colour, a white-hot core, a spark under it
        // (2026-10-08 contact sheet: typed and untyped letters read alike; the untyped ink is now ash-dim)
        g.shadowColor = T.ignite; g.shadowBlur = size * 0.8; g.fillStyle = T.ignite; g.fillText(ch, cx, cy); g.fillText(ch, cx, cy); g.shadowBlur = 0;
        g.fillStyle = '#ffffff'; g.globalAlpha = 0.7; g.fillText(ch, cx + 0.5, cy - 0.5); g.globalAlpha = 1;
        g.fillStyle = T.ignite; g.beginPath(); g.arc(cx + cw / 2, cy + size * 0.62, size * 0.07, 0, TAU); g.fill(); lit++;
      } else { g.fillStyle = rgba(T.plateInk, 0.62); g.fillText(ch, cx, cy); }
      if (i === typed && state === 'locked') { g.fillStyle = T.ignite; g.fillRect(cx, cy + size * 0.55, Math.max(4, cw), 2); }
      cx += cw + size * TRACK;
    }
    if (state === 'locked') { g.fillStyle = T.ignite; g.beginPath(); g.moveTo(x + w / 2 - 7, y + h); g.lineTo(x + w / 2 + 7, y + h); g.lineTo(x + w / 2, y + h + 9); g.closePath(); g.fill(); }
    g.restore();
    return { w: w + 24, h: h + 30, lit: lit };
  }

  /* ---------------------------------------------------------------- lives, score, results */
  /** One life: a candle, lit or snuffed (a curl of smoke). */
  function candle(g, x, y, h, lit, theme) {
    var T = STAGE[theme] || STAGE.crypt;
    g.save();
    g.fillStyle = '#e9dcc0'; roundRect(g, x - 7, y - h, 14, h, 3); g.fill();
    g.fillStyle = 'rgba(0,0,0,0.18)'; g.fillRect(x + 2, y - h, 5, h);
    g.fillStyle = '#e9dcc0'; g.beginPath(); g.ellipse(x - 3, y - h + 6, 3, 6, 0, 0, TAU); g.fill();
    g.strokeStyle = '#3a2a1e'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(x, y - h); g.lineTo(x, y - h - 6); g.stroke();
    if (lit) {
      var gl = g.createRadialGradient(x, y - h - 12, 1, x, y - h - 12, 26); gl.addColorStop(0, rgba(T.glow, 0.7)); gl.addColorStop(1, rgba(T.glow, 0)); g.fillStyle = gl; g.fillRect(x - 26, y - h - 38, 52, 52);
      g.fillStyle = T.glow; g.beginPath(); g.moveTo(x, y - h - 24); g.quadraticCurveTo(x + 7, y - h - 10, x, y - h - 5); g.quadraticCurveTo(x - 7, y - h - 10, x, y - h - 24); g.fill();
      g.fillStyle = '#fffbe8'; g.beginPath(); g.ellipse(x, y - h - 10, 2, 4, 0, 0, TAU); g.fill();
    } else {
      g.strokeStyle = 'rgba(200,200,210,0.5)'; g.lineWidth = 2; g.beginPath(); g.moveTo(x, y - h - 6); g.bezierCurveTo(x + 8, y - h - 14, x - 8, y - h - 22, x + 3, y - h - 32); g.stroke();
    }
    g.restore();
  }
  /** The top band: candles for lives, the score, the combo and the words left. Drawn when one of them changes. */
  function hud(g, W, theme, st) {
    var T = STAGE[theme] || STAGE.crypt;
    g.save();
    var band = g.createLinearGradient(0, 0, 0, 74); band.addColorStop(0, 'rgba(0,0,0,0.65)'); band.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = band; g.fillRect(0, 0, W, 74);
    for (var i = 0; i < st.livesMax; i++) candle(g, 30 + i * 26, 58, 22 + (i % 2) * 4, i < st.lives, theme);
    text(g, String(st.score), W - 24, 26, 30, T.hud, 'right', '700');
    text(g, st.combo >= 2 ? 'combo x' + st.combo : '', W - 24, 54, 16, T.ignite, 'right', '700');
    text(g, T.name, W / 2, 24, 20, T.hud, 'center', '700');
    text(g, st.cleared + ' / ' + st.count + ' words', W / 2, 48, 15, rgba(T.hud, 0.75), 'center', '600');
    g.restore();
  }
  /** The results panel over the stage. */
  function resultsPanel(g, W, H, theme, res, count) {
    var T = STAGE[theme] || STAGE.crypt, pw = 470, ph = 300, px = (W - pw) / 2, py = (H - ph) / 2 - 10;
    g.save();
    g.fillStyle = 'rgba(5,4,8,0.6)'; g.fillRect(0, 0, W, H);
    g.fillStyle = rgba(T.plate, 0.96); roundRect(g, px, py, pw, ph, 16); g.fill();
    g.strokeStyle = T.trim; g.lineWidth = 3; roundRect(g, px + 3, py + 3, pw - 6, ph - 6, 13); g.stroke();
    text(g, res.won ? 'THE WORDS HELD' : 'THE CANDLES ARE OUT', W / 2, py + 46, 26, res.won ? T.ignite : '#e0786c', 'center', '700');
    var rows = [['Words cleared', res.cleared + ' / ' + count], ['Accuracy', res.accuracy + '%'], ['Best combo', 'x' + res.bestCombo], ['Score', String(res.score)]];
    rows.forEach(function (r, i) { var y = py + 104 + i * 42; text(g, r[0], px + 50, y, 20, T.plateInk, 'left', '600'); text(g, r[1], px + pw - 50, y, 22, T.hud, 'right', '700'); });
    text(g, 'OK to leave', W / 2, py + ph - 24, 15, rgba(T.plateInk, 0.8), 'center', '600');
    g.restore();
  }

  return { VERSION: '1.0.0', FONT: FONT, STAGE: STAGE, THEMES: THEMES, HORIZON: HORIZON, GROUND: GROUND, text: text, roundRect: roundRect, rgba: rgba,
    lanePoint: lanePoint, backdrop: backdrop, plateSize: plateSize, plate: plate, candle: candle, hud: hud, resultsPanel: resultsPanel };
}());
if (typeof module !== 'undefined' && module.exports) module.exports = IncantationDraw;
