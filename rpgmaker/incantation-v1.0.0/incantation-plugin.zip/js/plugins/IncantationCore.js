/*:
 * @target MZ
 * @plugindesc Incantation 1/3 - the rules: words harvested from your database, the typing battle. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * IncantationCore.js - part of Incantation v1.0.0. Enable it with
 * IncantationDraw.js and Incantation.js (any order). It has no commands or
 * parameters of its own; Incantation.js reads it.
 *
 * Every line of this plugin was written with AI assistance.
 */
/*
 * The rules of a typing battle, pure JavaScript with no engine calls, so they run headless in Node exactly as they run
 * in MZ. State is plain JSON (no functions, the RNG state is a number on the run), so a run saved mid-battle resumes
 * exactly. Never Math.random: a seeded generator, the seed on the run.
 */
var IncantationCore = (function () {
  'use strict';

  /* ------------------------------------------------------------ seeded randomness */
  /** FNV-1a over a string, for word seeds. */
  function hashString(s) { var h = 0x811c9dc5; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193); } return h >>> 0; }
  /** Mix two 32-bit values into a new seed. */
  function mix(a, b) { var h = Math.imul((a >>> 0) ^ 0x9e3779b9, 0x85ebca6b) ^ (b >>> 0); h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35); return (h ^ (h >>> 16)) >>> 0; }
  /** mulberry32 with its state ON THE RUN (run.rs), so saving the run saves the generator. */
  function rand(run) {
    var t = run.rs = (run.rs + 0x6D2B79F5) | 0;
    t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  /* ------------------------------------------------------------ the words */
  var SHORT = 5, MEDIUM = 9, MIN_LEN = 3, MAX_LEN = 24;
  var NOTE = /<Incantation:\s*([^>]+)>/i;
  var SOURCES = { skills: 'skill', enemies: 'enemy', items: 'item' };

  /**
   * A database name as the player will type it: lower case, underscores as spaces, spaces collapsed. A name holding any
   * character outside [a-z0-9' -] is null (an accented or CJK name needs an IME, which cannot be typed in real time):
   * skipped, never mangled. So is anything shorter than 3 or longer than 24 characters, or with no letter at all.
   * @param {string} name
   * @returns {string|null}
   */
  function normal(name) {
    if (typeof name !== 'string') return null;
    var t = name.trim();
    if (/^-{3,}/.test(t)) return null;
    t = t.toLowerCase().replace(/_/g, ' ').replace(/\s+/g, ' ').trim();
    if (!/^[a-z0-9' -]+$/.test(t) || !/[a-z]/.test(t)) return null;
    if (t.length < MIN_LEN || t.length > MAX_LEN) return null;
    return t;
  }
  /** short <= 5 characters, medium 6..9, long 10+. */
  function tierOf(t) { return t.length <= SHORT ? 'short' : t.length <= MEDIUM ? 'medium' : 'long'; }

  /**
   * Every word the database offers: names of skills, enemies and items (opts.sources picks which), a
   * <Incantation: text> notetag replacing a name. Blank names, dividers, untypeable names and names two records share
   * are skipped AND COUNTED by reason.
   * @param {{skills?:Array, enemies?:Array, items?:Array}} db
   * @param {{sources?:string[]}} [opts]
   * @returns {{words:Array<{text:string,kind:string,id:number,tier:string}>, skipped:{blank:number,divider:number,shared:number,untypeable:number}}}
   */
  function words(db, opts) {
    var use = (opts && opts.sources) || ['skills', 'enemies', 'items'], skipped = { blank: 0, divider: 0, shared: 0, untypeable: 0 }, cand = [], count = {};
    use.forEach(function (src) {
      if (!SOURCES[src]) return;
      ((db && db[src]) || []).forEach(function (rec) {
        if (!rec) return;
        var raw = rec.name == null ? '' : String(rec.name), m = NOTE.exec(rec.note || '');
        if (m) raw = m[1];
        if (!raw.trim()) { skipped.blank++; return; }
        if (/^\s*-{3,}/.test(raw)) { skipped.divider++; return; }
        var t = normal(raw);
        if (!t) { skipped.untypeable++; return; }
        cand.push({ text: t, kind: SOURCES[src], id: Number(rec.id) || 0, tier: tierOf(t) });
        count[t] = (count[t] || 0) + 1;
      });
    });
    var out = [];
    cand.forEach(function (c) { if (count[c.text] > 1) skipped.shared++; else out.push(c); });
    return { words: out, skipped: skipped };
  }

  /* ------------------------------------------------------------ the run */
  var TIERS = ['short', 'medium', 'long'];
  /**
   * The three difficulties. MEASURED 2026-10-08 by Internal_Ops/_probe/balance_probe.js on the stock database's 159
   * words, 200 seeds x 2 seed sets, a typist at 93% accuracy (wins at keys per second):
   *   easy   - 1.5 keys/s 65-70%, 2 keys/s 100%
   *   normal - 2 keys/s 0%, 3 keys/s 50-55%, 4 keys/s 100%
   *   hard   - 5 keys/s 10-12%, 6 keys/s 89-92%, 8 keys/s 100%
   * (3 keys a second is roughly 35 words a minute.)
   */
  var DIFFICULTY = {
    easy: { count: 12, lives: 5, speed: 10, maxLive: 2 },
    normal: { count: 12, lives: 3, speed: 8, maxLive: 3 },
    hard: { count: 16, lives: 3, speed: 6, maxLive: 4 }
  };

  function shuffleInto(run, list) { for (var i = list.length - 1; i > 0; i--) { var j = Math.floor(rand(run) * (i + 1)), t = list[i]; list[i] = list[j]; list[j] = t; } return list; }
  function refill(run) {
    run.deck = { short: [], medium: [], long: [] };
    run.pool.forEach(function (w) { run.deck[w.tier].push(w); });
    TIERS.forEach(function (t) { shuffleInto(run, run.deck[t]); });
  }

  /**
   * A new typing battle over a pool of words.
   * @param {Array} pool words() output's .words
   * @param {number} seed
   * @param {{count?:number, lives?:number, speed?:number, maxLive?:number, gap?:number, lanes?:number}} [opts]
   *   count words to deal (12), lives (3), speed = seconds a 6-letter word takes to reach the party (8), maxLive foes at
   *   once (3), gap = frames between arrivals (45), lanes (5)
   * @returns {Object|null} null for an empty pool (never an empty battle)
   */
  function createRun(pool, seed, opts) {
    if (!pool || !pool.length) return null;
    opts = opts || {};
    var run = {
      v: 1, seed: seed >>> 0, rs: mix(seed >>> 0, 0x1C4) | 0,
      count: Math.max(1, Math.floor(opts.count || 12)), lives: Math.max(1, Math.floor(opts.lives || 3)),
      speed: Math.max(1, Number(opts.speed) || 8), maxLive: Math.max(1, Math.min(5, Math.floor(opts.maxLive || 3))),
      gap: Math.max(1, Math.floor(opts.gap || 45)), lanes: Math.max(1, Math.min(7, Math.floor(opts.lanes || 5))),
      pool: pool.map(function (w) { return { text: w.text, kind: w.kind, id: w.id, tier: w.tier }; }),
      deck: null, foes: [], nextId: 1, lock: -1, combo: 0, bestCombo: 0, score: 0, hits: 0, misses: 0,
      cleared: 0, escaped: 0, dealt: 0, frame: 0, lastSpawn: -100000, phase: 'play', log: []
    };
    run.livesMax = run.lives;
    refill(run);
    return run;
  }

  /** How many foes are on the field. A loop, no allocation (step() calls it every frame). */
  function live(run) { var n = 0; for (var i = 0; i < run.foes.length; i++) if (run.foes[i].alive) n++; return n; }
  /** The foe with this id, or null. */
  function foeById(run, id) { for (var i = 0; i < run.foes.length; i++) if (run.foes[i].id === id) return run.foes[i]; return null; }

  /**
   * Deal one word: from the tier the battle has reached (short first, long last), falling back to the nearest tier with
   * a word left, and never a word whose FIRST LETTER a live foe already shows (so the first key locks exactly one).
   * Called by step() at most once per frame and only when a foe actually arrives, so its allocation is per arrival.
   */
  function spawn(run) {
    var firsts = '', used = {};
    for (var i = 0; i < run.foes.length; i++) { var f = run.foes[i]; if (f.alive) { firsts += f.word.charAt(0); used[f.lane] = true; } }
    var remaining = run.deck.short.length + run.deck.medium.length + run.deck.long.length;
    if (!remaining) refill(run);
    var want = Math.min(2, Math.floor(3 * run.dealt / run.count)), order = [want, want - 1, want + 1, want - 2, want + 2];
    for (var k = 0; k < order.length; k++) {
      var tier = TIERS[order[k]]; if (!tier) continue;
      var list = run.deck[tier];
      for (var j = 0; j < list.length; j++) {
        if (firsts.indexOf(list[j].text.charAt(0)) >= 0) continue;
        // the lane FARTHEST from every occupied lane (ties broken by the seed), so two plates never stack at the horizon
        // (2026-10-08 in-engine photograph: two far foes in adjacent lanes, one word printed over the other)
        var w = list.splice(j, 1)[0], free = [], bestGap = -1;
        for (var l = 0; l < run.lanes; l++) {
          if (used[l]) continue;
          var gap = run.lanes; for (var u in used) gap = Math.min(gap, Math.abs(l - Number(u)));
          if (gap > bestGap) { bestGap = gap; free = [l]; } else if (gap === bestGap) free.push(l);
        }
        var lane = free.length ? free[Math.floor(rand(run) * free.length)] : Math.floor(rand(run) * run.lanes);
        var len = w.text.length, frames = run.speed * 60 * (0.7 + 0.05 * len);
        run.foes.push({ id: run.nextId++, word: w.text, kind: w.kind, recId: w.id, tier: w.tier, typed: 0, lane: lane, t: 0, v: 1 / frames, alive: true, killed: false, escaped: false });
        run.dealt++; run.lastSpawn = run.frame;
        run.log.push({ word: w.text, tier: w.tier, at: run.frame });
        return true;
      }
    }
    return false;                                             // every word left clashes with a live first letter: wait
  }

  /**
   * Advance the battle by whole frames: foes walk in, one that reaches the party costs a life and breaks the combo, new
   * foes arrive. Allocates nothing itself (wing §3); spawn() allocates once per arrival.
   * @param {Object} run
   * @param {number} frames
   * @returns {Object} the run
   */
  function step(run, frames) {
    var n = Math.floor(frames) || 0;
    for (var k = 0; k < n && run.phase === 'play'; k++) {
      run.frame++;
      for (var i = 0; i < run.foes.length; i++) {
        var f = run.foes[i];
        if (!f.alive) continue;
        f.t += f.v;
        if (f.t >= 1) { f.t = 1; f.alive = false; f.escaped = true; run.lives--; run.escaped++; run.combo = 0; if (run.lock === f.id) run.lock = -1; }
      }
      if (run.lives <= 0) { run.lives = 0; run.phase = 'lost'; break; }
      if (run.dealt < run.count && live(run) < run.maxLive && run.frame - run.lastSpawn >= run.gap) spawn(run);
      if (run.dealt >= run.count && live(run) === 0) run.phase = 'won';
    }
    return run;
  }

  /** A word finished: the foe falls, the lock frees, the score grows with the combo. */
  function kill(run, f) {
    f.alive = false; f.killed = true; run.lock = -1; run.cleared++;
    var letters = f.word.replace(/ /g, '').length, pts = letters * 10 * (1 + Math.floor(run.combo / 5));
    run.score += pts; run.combo++; if (run.combo > run.bestCombo) run.bestCombo = run.combo;
    if (run.dealt >= run.count && live(run) === 0) run.phase = 'won';
    return { kind: 'kill', id: f.id, points: pts };
  }

  /**
   * One key from the player. Unlocked: the key locks the NEAREST live foe whose word starts with it. Locked: the next
   * letter of that word must match; a wrong key is a miss, the combo resets and the lock HOLDS.
   * @param {Object} run
   * @param {string} ch one character (upper case is read as lower case)
   * @returns {{kind:string, id?:number, typed?:number, points?:number}} lock | hit | kill | miss | ignored
   */
  function key(run, ch) {
    if (run.phase !== 'play' || typeof ch !== 'string' || ch.length !== 1) return { kind: 'ignored' };
    var c = ch.toLowerCase(), f;
    if (run.lock !== -1) {
      f = foeById(run, run.lock);
      if (!f || !f.alive) run.lock = -1;
    }
    if (run.lock === -1) {
      var best = null;
      for (var i = 0; i < run.foes.length; i++) { var g = run.foes[i]; if (g.alive && g.word.charAt(0) === c && (!best || g.t > best.t)) best = g; }
      if (!best) { run.misses++; run.combo = 0; return { kind: 'miss', id: -1 }; }
      run.lock = best.id; best.typed = 1; run.hits++;
      if (best.typed >= best.word.length) return kill(run, best);
      return { kind: 'lock', id: best.id, typed: 1 };
    }
    if (f.word.charAt(f.typed) === c) {
      f.typed++; run.hits++;
      if (f.typed >= f.word.length) return kill(run, f);
      return { kind: 'hit', id: f.id, typed: f.typed };
    }
    run.misses++; run.combo = 0;
    return { kind: 'miss', id: f.id };
  }

  /**
   * The battle's outcome.
   * @returns {{won:boolean, lost:boolean, cleared:number, escaped:number, dealt:number, score:number, hits:number, misses:number, accuracy:number, bestCombo:number, lives:number, frames:number}}
   */
  function results(run) {
    var keys = run.hits + run.misses;
    return { won: run.phase === 'won', lost: run.phase === 'lost', cleared: run.cleared, escaped: run.escaped, dealt: run.dealt, score: run.score,
      hits: run.hits, misses: run.misses, accuracy: keys ? Math.round(100 * run.hits / keys) : 100, bestCombo: run.bestCombo, lives: run.lives, frames: run.frame };
  }

  return { VERSION: '1.0.0', SHORT: SHORT, MEDIUM: MEDIUM, TIERS: TIERS, DIFFICULTY: DIFFICULTY, hashString: hashString, mix: mix, normal: normal, tierOf: tierOf,
    words: words, createRun: createRun, live: live, foeById: foeById, step: step, key: key, results: results };
}());
if (typeof module !== 'undefined' && module.exports) module.exports = IncantationCore;
