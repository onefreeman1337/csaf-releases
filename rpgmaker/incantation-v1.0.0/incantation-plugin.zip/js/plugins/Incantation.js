/*:
 * @target MZ
 * @plugindesc Incantation 3/3 - typing battles for MZ: foes carry words from your own database; type a word to strike.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * INCANTATION v1.0.0 - typing battles, the words written from your database
 * ============================================================================
 * Foes walk toward the party down a drawn corridor, each carrying a word over
 * its head. Type the word to strike it down. The words are YOUR OWN: the names
 * of your skills (the incantation you must say to cast it), your enemies and
 * your items, or any text you put in an <Incantation: words> notetag.
 *
 * ----------------------------------------------------------------------------
 * INSTALLING
 * ----------------------------------------------------------------------------
 * Copy IncantationCore.js, IncantationDraw.js and Incantation.js into
 * js/plugins and enable all three. Any order works.
 *
 * ----------------------------------------------------------------------------
 * USING IT
 * ----------------------------------------------------------------------------
 * Add the plugin command "Start Typing Battle" to an event. The event waits
 * while the battle runs. Results go to the variables and switch you choose.
 *
 * CONTROLS: a keyboard. The first letter you type locks the nearest foe whose
 * word starts with it; type the rest to strike it. A wrong key is a miss and
 * breaks your combo. On the results, OK or a click leaves.
 * Names with characters a keyboard cannot type directly (accents, kana) are
 * skipped; give those records an <Incantation: words> notetag.
 *
 * ----------------------------------------------------------------------------
 * COMPATIBILITY
 * ----------------------------------------------------------------------------
 * Incantation adds its own scene and replaces nothing. It extends two engine
 * methods, each by saving the original and calling it: Game_System.initialize
 * (its save record) and Game_Interpreter.updateWaitMode (so the event waits
 * while the battle runs). It reads your database and never writes to it.
 *
 * ============================================================================
 * TERMS OF USE
 * ============================================================================
 * Commercial and non-commercial use permitted in RPG Maker projects, credit
 * appreciated but not required. Do not redistribute the source as an asset
 * pack. Every line of this plugin was written with AI assistance.
 * ============================================================================
 *
 * @param letterSe
 * @text Sound: a right letter
 * @type file
 * @dir audio/se
 * @default Cursor2
 *
 * @param strikeSe
 * @text Sound: a word finished
 * @type file
 * @dir audio/se
 * @default Magic3
 *
 * @param missSe
 * @text Sound: a wrong key
 * @type file
 * @dir audio/se
 * @default Buzzer1
 *
 * @param hurtSe
 * @text Sound: a foe reaches the party
 * @type file
 * @dir audio/se
 * @default Damage1
 *
 * @command battle
 * @text Start Typing Battle
 * @desc Run a typing battle with words from your database. The event waits until it is over.
 *
 * @arg difficulty
 * @text Difficulty
 * @type select
 * @option easy
 * @option normal
 * @option hard
 * @default normal
 *
 * @arg words
 * @text Words to clear
 * @desc 0 = the difficulty's own count (12, 12, 16).
 * @type number
 * @min 0
 * @max 40
 * @default 0
 *
 * @arg sources
 * @text Words from
 * @type select
 * @option all
 * @option skills
 * @option enemies
 * @option items
 * @default all
 *
 * @arg troop
 * @text Troop (foe pictures)
 * @desc The foes wear this troop's enemy pictures. 0 = any enemy in your database.
 * @type troop
 * @default 0
 *
 * @arg stage
 * @text Stage
 * @type select
 * @option auto
 * @option crypt
 * @option grove
 * @option void
 * @default auto
 *
 * @arg scoreVariable
 * @text Variable: score
 * @type variable
 * @default 0
 *
 * @arg clearedVariable
 * @text Variable: words cleared
 * @type variable
 * @default 0
 *
 * @arg wonSwitch
 * @text Switch: won
 * @type switch
 * @default 0
 *
 * @arg goldPerPoint
 * @text Gold per 10 points
 * @type number
 * @min 0
 * @default 0
 *
 * @arg seed
 * @text Seed (optional)
 * @desc Blank = new words every time. A number or word = the same battle every time.
 * @default
 */

var Incantation = Incantation || {};

(function (M) {
  'use strict';
  var NAME = 'Incantation', SCHEMA = 1;
  var raw = (typeof PluginManager !== 'undefined') ? PluginManager.parameters(NAME) : {};
  function num(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; var n = Number(v); return isFinite(n) ? n : d; }
  function str(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; return String(v).trim(); }
  M.params = { letterSe: str(raw.letterSe, 'Cursor2'), strikeSe: str(raw.strikeSe, 'Magic3'), missSe: str(raw.missSe, 'Buzzer1'), hurtSe: str(raw.hurtSe, 'Damage1') };
  var _deps = null;
  /** The two sibling files, found the first time a battle starts (any load order works, wing §8 trap 2). */
  function deps() {
    if (_deps) return _deps;
    var core = (typeof IncantationCore !== 'undefined') ? IncantationCore : null, draw = (typeof IncantationDraw !== 'undefined') ? IncantationDraw : null;
    if (!core || !draw) { if (!deps._w) { deps._w = true; console.error('Incantation: enable IncantationCore.js and IncantationDraw.js in the Plugin Manager too.'); } return null; }
    _deps = { core: core, draw: draw }; return _deps;
  }
  M.deps = deps;
  function fresh() { return { v: SCHEMA, played: 0, won: 0, best: 0 }; }
  /** The save record: battles played, won, the best score. */
  M.record = function () {
    if (typeof $gameSystem === 'undefined' || !$gameSystem) return fresh();
    var s = $gameSystem._csafIncantation; if (!s || s.v == null) { s = fresh(); $gameSystem._csafIncantation = s; } return s;
  };
  var _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () { _Game_System_initialize.call(this); this._csafIncantation = fresh(); };
  /** The database lists the core reads. */
  M.database = function () { return { skills: $dataSkills, enemies: $dataEnemies, items: $dataItems }; };
  var SOURCES = { all: ['skills', 'enemies', 'items'], skills: ['skills'], enemies: ['enemies'], items: ['items'] };
  /** Plugin-command arguments (strings) to a clamped request. */
  M.request = function (args) {
    var d = deps(); if (!d) return null; args = args || {};
    var seedText = str(args.seed, ''), seed = seedText === '' ? d.core.mix(d.core.hashString('incantation') ^ (M.record().played * 7919), (typeof $gameSystem !== 'undefined' && $gameSystem ? $gameSystem.playtime() : 0) >>> 0)
      : (/^\d+$/.test(seedText) ? (Number(seedText) >>> 0) : d.core.hashString(seedText));
    var diff = str(args.difficulty, 'normal'); if (!d.core.DIFFICULTY[diff]) diff = 'normal';
    var src = str(args.sources, 'all'); if (!SOURCES[src]) src = 'all';
    var stage = str(args.stage, 'auto');
    var opts = {}, P = d.core.DIFFICULTY[diff]; for (var k in P) opts[k] = P[k];
    var words = Math.floor(num(args.words, 0)); if (words > 0) opts.count = Math.min(40, words);
    return { seed: seed, difficulty: diff, sources: SOURCES[src], opts: opts, troop: Math.max(0, Math.floor(num(args.troop, 0))),
      stage: d.draw.THEMES.indexOf(stage) >= 0 ? stage : null, scoreVariable: Math.max(0, Math.floor(num(args.scoreVariable, 0))),
      clearedVariable: Math.max(0, Math.floor(num(args.clearedVariable, 0))), wonSwitch: Math.max(0, Math.floor(num(args.wonSwitch, 0))),
      goldPerPoint: Math.max(0, Math.floor(num(args.goldPerPoint, 0))), isRequest: true };
  };
  /**
   * Start a battle (script call: the same options as the command). Returns false, says so once, and starts nothing
   * when the database offers no typeable word.
   */
  M.start = function (opts) {
    var req = opts && opts.isRequest ? opts : M.request(opts || {});
    if (!req) return false;
    if (!deps().core.words(M.database(), { sources: req.sources }).words.length) {
      if (!M._warnedEmpty) { M._warnedEmpty = true; console.warn('Incantation: your database has no names a keyboard can type (skills, enemies or items, 3 to 24 letters). No battle started.'); }
      return false;
    }
    SceneManager.push(Scene_Incantation); SceneManager.prepareNextScene(req); return true;
  };
  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) PluginManager.registerCommand(NAME, 'battle', function (args) { if (M.start(M.request(args))) this.setWaitMode('incantation'); });
  var _updateWaitMode = Game_Interpreter.prototype.updateWaitMode;
  Game_Interpreter.prototype.updateWaitMode = function () {
    if (this._waitMode === 'incantation') { if (SceneManager._scene instanceof Scene_Incantation || SceneManager._nextScene instanceof Scene_Incantation) return true; this._waitMode = ''; return false; }
    return _updateWaitMode.call(this);
  };
  M.VERSION = '1.0.0';
}(Incantation));

//=============================================================================
// Scene_Incantation
//=============================================================================

function Scene_Incantation() { this.initialize.apply(this, arguments); }
Scene_Incantation.prototype = Object.create(Scene_Message.prototype);
Scene_Incantation.prototype.constructor = Scene_Incantation;
Scene_Incantation.PLATE_SIZE = 26;      // letter size a plate is drawn at; depth scales the SPRITE, never redraws it
Scene_Incantation.BODY_H = 250;         // a foe's picture height at the front of the corridor
Scene_Incantation.prototype.prepare = function (req) { this._req = req; };

Scene_Incantation.prototype.create = function () {
  Scene_Message.prototype.create.call(this);
  var d = Incantation.deps(), req = this._req, C = d.core;
  this._d = d;
  this._run = C.createRun(C.words(Incantation.database(), { sources: req.sources }).words, req.seed, req.opts);
  this._theme = req.stage || d.draw.THEMES[req.seed % d.draw.THEMES.length];
  // the foe pictures: the troop's enemies, or every enemy with a picture; an enemy's OWN word wears its own picture
  var side = $gameSystem.isSideView(), list = [];
  if (req.troop > 0 && $dataTroops[req.troop]) $dataTroops[req.troop].members.forEach(function (m) { var e = $dataEnemies[m.enemyId]; if (e && e.battlerName) list.push(e); });
  if (!list.length) $dataEnemies.forEach(function (e) { if (e && e.battlerName && e.name) list.push(e); });
  this._looks = list; this._side = side;
  list.forEach(function (e) { if (side) ImageManager.loadSvEnemy(e.battlerName); else ImageManager.loadEnemy(e.battlerName); });
  this._field = new Sprite(); this.addChild(this._field);
  this._foeLayer = new Sprite(); this._plateLayer = new Sprite();
  this._sprites = {}; this._keys = []; this._shake = 0;
  this._onKey = this.onKey.bind(this);
  this.createWindowLayer(); this.createAllWindows();
  this._mode = 'loading'; this._t = 0;
};
Scene_Incantation.prototype.start = function () {
  Scene_Message.prototype.start.call(this);
  var D = this._d.draw, W = Graphics.width, H = Graphics.height, bmp = new Bitmap(W, H);
  D.backdrop(bmp.context, W, H, this._theme); bmp._baseTexture.update();
  this._field.addChild(new Sprite(bmp)); this._field.addChild(this._foeLayer); this._field.addChild(this._plateLayer);
  this._hud = new Sprite(new Bitmap(W, 84)); this.addChild(this._hud); this.drawHud();
  this._results = new Sprite(); this._results.visible = false; this.addChild(this._results);
  document.addEventListener('keydown', this._onKey);
  this._mode = 'play'; this.startFadeIn(this.fadeSpeed(), false);
};
Scene_Incantation.prototype.terminate = function () {
  Scene_Message.prototype.terminate.call(this);
  document.removeEventListener('keydown', this._onKey);          // every listener has a teardown (wing §3)
};
/** A key from the keyboard, queued for the next update (one character only; held-key repeats and IME text ignored). */
Scene_Incantation.prototype.onKey = function (ev) {
  if (this._mode !== 'play' || ev.repeat || ev.isComposing || ev.ctrlKey || ev.altKey || ev.metaKey || !ev.key || ev.key.length !== 1) return;
  this._keys.push(ev.key);
};

Scene_Incantation.prototype.lookFor = function (foe) {
  if (foe.kind === 'enemy' && $dataEnemies[foe.recId] && $dataEnemies[foe.recId].battlerName) return $dataEnemies[foe.recId];
  return this._looks.length ? this._looks[foe.id % this._looks.length] : null;
};
/** The sprites of one foe, made once when it arrives. */
Scene_Incantation.prototype.spritesFor = function (foe) {
  var s = this._sprites[foe.id];
  if (s) return s;
  var e = this.lookFor(foe), body = new Sprite(e ? (this._side ? ImageManager.loadSvEnemy(e.battlerName) : ImageManager.loadEnemy(e.battlerName)) : new Bitmap(1, 1));
  body.anchor.x = 0.5; body.anchor.y = 1; if (e && e.battlerHue) body.setHue(e.battlerHue);
  var D = this._d.draw, sz = Scene_Incantation.PLATE_SIZE, ps = D.plateSize(new Bitmap(1, 1).context, foe.word, sz);
  var plate = new Sprite(new Bitmap(ps.w + 24, ps.h + 30)); plate.anchor.x = 0.5; plate.anchor.y = 1;
  s = { body: body, plate: plate, state: '', typed: -1, missT: 0, dieT: 0 };
  this._sprites[foe.id] = s; this._foeLayer.addChild(body); this._plateLayer.addChild(plate);
  this.drawPlate(foe, s, 'idle');
  return s;
};
Scene_Incantation.prototype.drawPlate = function (foe, s, state) {
  if (s.state === state && s.typed === foe.typed) return;              // a redraw (and an upload) only on a change
  s.state = state; s.typed = foe.typed;
  // cleared through the context and uploaded ONCE (Bitmap.clear() marks the texture dirty a second time; mz_gate
  // 2026-10-08 counted 0.667 dirties a frame against a 0.5 ceiling with the auto-typist at 8.6 keys a second)
  var b = s.plate.bitmap; b.context.clearRect(0, 0, b.width, b.height); this._d.draw.plate(b.context, foe.word, foe.typed, this._theme, Scene_Incantation.PLATE_SIZE, state); b._baseTexture.update();
};
/** The score band, redrawn only when a number it SHOWS changes (a right letter changes none of them). */
Scene_Incantation.prototype.drawHud = function () {
  var r = this._run, key = r.lives * 1e9 + r.cleared * 1e6 + r.combo * 1e4 + r.score;
  if (key === this._hudKey) return;
  this._hudKey = key;
  var b = this._hud.bitmap; b.context.clearRect(0, 0, b.width, b.height);
  this._d.draw.hud(b.context, Graphics.width, this._theme, { lives: r.lives, livesMax: r.livesMax, score: r.score, combo: r.combo, cleared: r.cleared, count: r.count });
  b._baseTexture.update();
};

Scene_Incantation.prototype.update = function () {
  Scene_Message.prototype.update.call(this);
  if (this._mode === 'loading' || this.isBusy()) return;
  this._t++;
  if (this._mode === 'play') this.updatePlay();
  else if (this._mode === 'results' && this._t > 30 && (Input.isTriggered('ok') || TouchInput.isTriggered())) this.leave();
  this.updateEffects();
};
Scene_Incantation.prototype.updatePlay = function () {
  var C = this._d.core, r = this._run, hudDirty = false;
  while (this._keys.length) {
    var ev = C.key(r, this._keys.shift());
    if (ev.kind === 'ignored') continue;
    hudDirty = true;
    if (ev.kind === 'miss') { AudioManager.playSe({ name: Incantation.params.missSe, volume: 70, pitch: 110, pan: 0 }); var mf = C.foeById(r, ev.id); if (mf) { var ms = this.spritesFor(mf); ms.missT = 10; this.drawPlate(mf, ms, 'miss'); } }
    else if (ev.kind === 'kill') { AudioManager.playSe({ name: Incantation.params.strikeSe, volume: 80, pitch: 100, pan: 0 }); var kf = C.foeById(r, ev.id), ks = this.spritesFor(kf); this.drawPlate(kf, ks, 'locked'); ks.dieT = 24; ks.body.setBlendColor([255, 255, 255, 200]); }
    else { AudioManager.playSe({ name: Incantation.params.letterSe, volume: 45, pitch: 120, pan: 0 }); var hf = C.foeById(r, ev.id); this.drawPlate(hf, this.spritesFor(hf), 'locked'); }
  }
  var lives = r.lives, cleared = r.cleared;
  C.step(r, 1);
  if (r.lives !== lives) { hudDirty = true; this._shake = 14; AudioManager.playSe({ name: Incantation.params.hurtSe, volume: 80, pitch: 100, pan: 0 }); }
  if (r.cleared !== cleared) hudDirty = true;
  this.syncFoes();
  if (hudDirty) this.drawHud();
  if (r.phase !== 'play') this.showResults();
};
/** Place every foe for this frame: depth, lane, scale. No allocation (wing §3). */
Scene_Incantation.prototype.syncFoes = function () {
  var r = this._run, D = this._d.draw, W = Graphics.width, H = Graphics.height, foes = r.foes;
  for (var i = 0; i < foes.length; i++) {
    var f = foes[i], s = this._sprites[f.id];
    if (!f.alive && !s) continue;
    if (!s) s = this.spritesFor(f);
    var p = D.lanePoint(W, H, f.lane, r.lanes, f.t), bh = s.body.bitmap.height || 1, k = Scene_Incantation.BODY_H / Math.max(bh, 120) * p.s;
    s.body.x = p.x; s.body.y = p.y; s.body.scale.x = k; s.body.scale.y = k;
    s.plate.x = p.x + (s.missT > 0 ? ((s.missT % 4) - 1.5) * 3 : 0); s.plate.y = p.y - bh * k - 4;
    var ps = 0.45 + 0.55 * p.e; s.plate.scale.x = ps; s.plate.scale.y = ps;
    if (f.escaped && s.dieT === 0) s.dieT = 16;
    if (f.alive && f.id !== r.lock && s.state === 'locked') this.drawPlate(f, s, 'idle');
  }
  this._foeLayer.children.sort(Scene_Incantation.byDepth); this._plateLayer.children.sort(Scene_Incantation.byDepth);
  this.unstackPlates();
};
/**
 * No word is ever printed over another: walking from the nearest plate to the farthest, a farther plate that overlaps
 * a nearer one is lifted above it (2026-10-08 GIF frame: two long words in neighbouring lanes collided at the horizon).
 * At most a handful of plates, loops only, no allocation.
 */
Scene_Incantation.prototype.unstackPlates = function () {
  var ch = this._plateLayer.children;
  for (var a = ch.length - 1; a >= 0; a--) {
    var A = ch[a]; if (!A.visible || !A.opacity) continue;
    for (var b = ch.length - 1; b >= 0; b--) {
      var B = ch[b]; if (b === a || !B.visible || !B.opacity || B.y < A.y || (B.y === A.y && b < a)) continue;   // only plates nearer than A
      var aw = A.bitmap.width * A.scale.x / 2, bw = B.bitmap.width * B.scale.x / 2, ah = A.bitmap.height * A.scale.y, bh = B.bitmap.height * B.scale.y;
      if (Math.abs(A.x - B.x) < aw + bw - 6 && A.y > B.y - bh + 4 && A.y - ah < B.y - 4) A.y = B.y - bh + 4;
    }
  }
};
Scene_Incantation.byDepth = function (a, b) { return a.y - b.y; };
/** Misses shake a plate, a strike flashes and lifts the word away, a foe that got through shakes the stage. */
Scene_Incantation.prototype.updateEffects = function () {
  var r = this._run, foes = r.foes;
  for (var i = 0; i < foes.length; i++) {
    var f = foes[i], s = this._sprites[f.id];
    if (!s) continue;
    if (s.missT > 0 && --s.missT === 0 && f.alive) this.drawPlate(f, s, f.id === r.lock ? 'locked' : 'idle');
    if (s.dieT > 0) {
      s.dieT--; var a = s.dieT / 24;
      s.body.opacity = Math.round(255 * a); s.plate.opacity = Math.round(255 * a);
      if (f.killed) { s.plate.scale.x *= 1.02; s.plate.scale.y *= 1.02; s.plate.y -= 2; }
      if (s.dieT === 0) { this._foeLayer.removeChild(s.body); this._plateLayer.removeChild(s.plate); s.body.visible = false; s.plate.visible = false; }
    }
  }
  if (this._shake > 0) { this._shake--; this._field.x = this._shake ? ((this._shake % 4) - 1.5) * 4 : 0; }
};

Scene_Incantation.prototype.showResults = function () {
  var D = this._d.draw, res = this._d.core.results(this._run), W = Graphics.width, H = Graphics.height, bmp = new Bitmap(W, H);
  D.resultsPanel(bmp.context, W, H, this._theme, res, this._run.count); bmp._baseTexture.update();
  this._results.bitmap = bmp; this._results.visible = true; this._res = res;
  this._mode = 'results'; this._t = 0; this._keys.length = 0;
};
Scene_Incantation.prototype.leave = function () {
  var req = this._req, m = this._res, rec = Incantation.record();
  if (req.scoreVariable > 0) $gameVariables.setValue(req.scoreVariable, m.score);
  if (req.clearedVariable > 0) $gameVariables.setValue(req.clearedVariable, m.cleared);
  if (req.wonSwitch > 0) $gameSwitches.setValue(req.wonSwitch, m.won);
  if (req.goldPerPoint > 0) $gameParty.gainGold(Math.floor(m.score / 10) * req.goldPerPoint);
  rec.played++; if (m.won) rec.won++; rec.best = Math.max(rec.best, m.score);
  this.popScene();
};
Scene_Incantation.prototype.stop = function () { Scene_Message.prototype.stop.call(this); this.startFadeOut(this.fadeSpeed(), false); };
