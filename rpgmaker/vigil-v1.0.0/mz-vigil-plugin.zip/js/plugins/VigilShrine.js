//=============================================================================
// VigilShrine.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Vigil [1/3] — the shrine painter. Composes and draws every rest shrine from a seed: form, fuel, relic and weathering. No image files. v1.0.0
 * @author CSAF — Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * VigilShrine — part 1 of 3. Install all three; any Plugin Manager order works.
 * ============================================================================
 *
 * This file has no parameters and no commands. It is the drawing half of Vigil:
 * every shrine the player rests at is composed here from four independent
 * choices and painted in code onto a canvas, then cut into animation frames
 * once, when the map loads. Nothing is drawn per frame.
 *
 *   FORM        brazier · cairn · ward-lamp · standing stone · root-bound idol
 *   FUEL        pine · peat · bone · oil · coal      (the colour of the fire)
 *   RELIC       none · planted blade · skull · bell · banner · iron ring
 *   WEATHERING  fresh · worn · cracked · overgrown
 *
 * A shrine's choices come from its own notetag if you give them, otherwise
 * from the map, the event and the region it stands on, so the same project
 * always draws the same shrine in the same place.
 *
 * Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.
 */

(function () {
  'use strict';

  var root = (typeof window !== 'undefined') ? window : globalThis;
  var CSAF = root.CSAF = root.CSAF || {};

  /* ---------------------------------------------------------------- RNG --- */
  /**
   * mulberry32 — the seeded RNG seam. Never Math.random() (wing §6 rule 2).
   * @param {number} seed
   * @returns {function(): number} uniform [0, 1)
   */
  function rng(seed) {
    var a = (seed >>> 0) || 0x9e3779b9;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  /** a stable 32-bit hash of small integers (map, event, region) */
  function hashInts() {
    var h = 2166136261 >>> 0;
    for (var i = 0; i < arguments.length; i++) {
      h ^= (arguments[i] | 0) & 0xffff; h = Math.imul(h, 16777619) >>> 0;
      h ^= ((arguments[i] | 0) >>> 16) & 0xffff; h = Math.imul(h, 16777619) >>> 0;
    }
    return h >>> 0;
  }

  /* ------------------------------------------------------------ the axes --- */
  var FORMS = ['brazier', 'cairn', 'wardlamp', 'stone', 'idol'];
  var FUELS = ['pine', 'peat', 'bone', 'oil', 'coal'];
  var RELICS = ['none', 'blade', 'skull', 'bell', 'banner', 'ring'];
  var WEATHER = ['fresh', 'worn', 'cracked', 'overgrown'];

  /*
   * The fire's colour per fuel: [deep, body, core, ember]. A fire reads as fire by a HOT CORE inside a darker body inside
   * a deep rim, never by one orange (wing §21b: the contrast is against what it is drawn on, and the night map is dark).
   */
  var FIRE = {
    pine: ['#7a1e0a', '#e2581a', '#ffd36a', '#ff9a3c'],
    /* ⛔ peat was a second orange (#b8461a beside pine's #e2581a) and the five fuels read as four on the board (independent
     * review 2026-10-09). Peat is a marsh fire now: pale green-gold, the one hue no other fuel is near. */
    peat: ['#1e3a14', '#6aa83a', '#e8f8a8', '#a8d860'],
    bone: ['#2c4a5c', '#6fb0c8', '#e8f6ff', '#a8e0f0'],
    oil:  ['#6a3a06', '#e89a1c', '#fff2b0', '#ffc850'],
    coal: ['#4a0a14', '#c42a3a', '#ff9a7a', '#ff5a4a']
  };
  /* stone ramps [shadow, body, lit, top-edge highlight] — the LIT TOP EDGE is what makes a built object read as built */
  var STONE = [
    ['#2a2a30', '#4a4a54', '#6c6c78', '#9a9aa6'],
    ['#2e2a24', '#4e463a', '#706452', '#9c8e74'],
    ['#262c2a', '#3e4a46', '#5e6c66', '#8a9a92'],
    ['#30261e', '#523e30', '#765a44', '#a48266']
  ];
  var IRON = ['#16161c', '#2a2a34', '#4a4a58', '#7a7a8c'];
  var WOOD = ['#2a1a10', '#4a2e1a', '#6e4626', '#94683a'];
  var MOSS = ['#1e3020', '#2e4a2c', '#4a6c3a'];

  /**
   * Resolve a shrine's composition. Explicit notetag choices win; anything left open is drawn from a seed made of the
   * map, the event and the region, so the result is stable for a given project and varies across it.
   * @param {{mapId:number, eventId:number, regionId:number, seed?:number, form?:string, fuel?:string, relic?:string, weather?:string}} o
   * @returns {{form:string, fuel:string, relic:string, weather:string, stone:number, seed:number, key:string}}
   */
  function resolve(o) {
    var seed = (o.seed != null && isFinite(Number(o.seed)) && String(o.seed) !== '') ? (Number(o.seed) >>> 0) : hashInts(o.mapId || 0, o.eventId || 0, o.regionId || 0, 7919);
    var r = rng(seed);
    /* ⛔ TRIM. MZ's note parser (DataManager.extractMetadata) keeps everything after the colon, so the documented
     * <vigil-form: cairn> arrives as " cairn" and an untrimmed lookup IGNORED every chosen form, fuel, relic and weathering
     * in the real engine while the headless suites, fed "cairn", stayed green (found 2026-10-09 by looking at the demo). */
    var pick = function (list, want) { var i = list.indexOf(String(want || '').trim().toLowerCase()); return i >= 0 ? list[i] : list[Math.floor(r() * list.length)]; };
    var spec = { form: pick(FORMS, o.form), fuel: pick(FUELS, o.fuel), relic: pick(RELICS, o.relic), weather: pick(WEATHER, o.weather) };
    spec.stone = (o.regionId | 0) > 0 ? ((o.regionId | 0) % STONE.length) : Math.floor(r() * STONE.length);
    spec.seed = seed;
    spec.key = [spec.form, spec.fuel, spec.relic, spec.weather, spec.stone, seed].join('/');
    return spec;
  }

  /* ------------------------------------------------------- canvas helpers --- */
  function px(ctx, x, y, w, h, c) { ctx.fillStyle = c; ctx.fillRect(Math.round(x), Math.round(y), Math.max(1, Math.round(w)), Math.max(1, Math.round(h))); }
  /** a block with a lit left face, a shaded right face and a highlighted top edge — the built-object grammar */
  function block(ctx, x, y, w, h, R) {
    px(ctx, x, y, w, h, R[1]);
    px(ctx, x, y, Math.max(2, w * 0.28), h, R[2]);
    px(ctx, x + w - Math.max(2, w * 0.24), y, Math.max(2, w * 0.24), h, R[0]);
    px(ctx, x, y, w, 2, R[3]);
    px(ctx, x, y + h - 1, w, 1, R[0]);
  }
  /** a rounded boulder: a stack of rows, each lit on its left end */
  function boulder(ctx, cx, cy, rx, ry, R) {
    for (var dy = -ry; dy <= ry; dy++) {
      var hw = Math.round(rx * Math.sqrt(Math.max(0, 1 - (dy * dy) / (ry * ry))));
      if (hw <= 0) continue;
      var y = cy + dy;
      px(ctx, cx - hw, y, hw * 2, 1, R[1]);
      px(ctx, cx - hw, y, Math.max(1, Math.round(hw * 0.6)), 1, dy < 0 ? R[3] : R[2]);
      px(ctx, cx + hw - Math.max(1, Math.round(hw * 0.5)), y, Math.max(1, Math.round(hw * 0.5)), 1, R[0]);
    }
  }

  /**
   * Draw the shrine BODY (everything that does not move) into ctx, standing on (cx, baseY).
   * Returns the point the fire sits on, {fx, fy, fw} (fw = the bowl's half width).
   */
  function paintBody(ctx, spec, cx, baseY, r) {
    var S = STONE[spec.stone];
    var fire;
    switch (spec.form) {
      case 'brazier': {
        /* three iron legs, a wide bowl with a lit rim, coals heaped above the rim */
        for (var l = -1; l <= 1; l++) { px(ctx, cx + l * 9 - 1, baseY - 16, 3, 16, IRON[1]); px(ctx, cx + l * 9 - 1, baseY - 16, 1, 16, IRON[3]); }
        px(ctx, cx - 9, baseY - 9, 19, 2, IRON[0]);
        for (var b = 0; b < 7; b++) { var hw = 15 - b; px(ctx, cx - hw, baseY - 24 + b, hw * 2, 1, b < 2 ? IRON[3] : IRON[2]); px(ctx, cx + hw - 4, baseY - 24 + b, 4, 1, IRON[0]); }
        px(ctx, cx - 16, baseY - 25, 32, 2, IRON[3]);
        fire = { fx: cx, fy: baseY - 25, fw: 13 };
        break;
      }
      case 'cairn': {
        /* stacked boulders, a hearth hollow in the top stone */
        boulder(ctx, cx - 8, baseY - 6, 10, 6, S); boulder(ctx, cx + 9, baseY - 6, 9, 6, S);
        boulder(ctx, cx, baseY - 15, 13, 6, S); boulder(ctx, cx - 3, baseY - 24, 10, 5, S);
        px(ctx, cx - 8, baseY - 29, 16, 3, S[0]);
        fire = { fx: cx - 1, fy: baseY - 28, fw: 8 };
        break;
      }
      case 'wardlamp': {
        /* a dressed pillar with a stepped plinth and a pierced lamp-house on top */
        block(ctx, cx - 13, baseY - 7, 26, 7, S); block(ctx, cx - 9, baseY - 30, 18, 23, S);
        block(ctx, cx - 14, baseY - 34, 28, 4, S);
        px(ctx, cx - 12, baseY - 52, 3, 18, S[1]); px(ctx, cx + 9, baseY - 52, 3, 18, S[0]);
        block(ctx, cx - 15, baseY - 56, 30, 4, S);
        px(ctx, cx - 6, baseY - 60, 12, 4, S[2]); px(ctx, cx - 6, baseY - 60, 12, 1, S[3]);
        fire = { fx: cx, fy: baseY - 35, fw: 8 };
        break;
      }
      case 'stone': {
        /* a tall standing stone, leaning, a fire bowl cut into a flat stone at its foot */
        var lean = (r() < 0.5 ? -1 : 1);
        for (var y = 0; y < 50; y++) {
          var w = 13 - Math.floor(y / 9); var x = cx - 14 + lean * Math.floor(y / 12) - (lean < 0 ? 0 : 4);
          px(ctx, x, baseY - 8 - y, w, 1, S[1]); px(ctx, x, baseY - 8 - y, 3, 1, S[2]); px(ctx, x + w - 3, baseY - 8 - y, 3, 1, S[0]);
        }
        px(ctx, cx - 13 + lean * 4 - (lean < 0 ? 0 : 4), baseY - 58, 8, 2, S[3]);
        block(ctx, cx - 2, baseY - 8, 20, 8, S);
        px(ctx, cx + 1, baseY - 9, 14, 2, S[0]);
        fire = { fx: cx + 8, fy: baseY - 9, fw: 7 };
        break;
      }
      default: { /* idol: a squat carved figure bound in roots, holding the fire in its lap */
        block(ctx, cx - 12, baseY - 10, 24, 10, S);
        boulder(ctx, cx, baseY - 26, 11, 14, S);
        px(ctx, cx - 5, baseY - 34, 3, 2, S[0]); px(ctx, cx + 3, baseY - 34, 3, 2, S[0]);   /* eyes */
        px(ctx, cx - 3, baseY - 29, 6, 1, S[0]);                                          /* mouth */
        /* ⛔ v1 bound it in HORIZONTAL bands and the idol read as a BARREL (contact_48.png, looked at). Roots are grown, not
         *    nailed: three strands climb from the ground on a DIAGONAL wave, tapering, crossing the figure once each. */
        for (var k = 0; k < 3; k++) {
          var sx = cx - 12 + k * 11; var dir = k === 1 ? -1 : 1;
          for (var s = 0; s < 26; s++) {
            var w = s < 10 ? 2 : 1;
            var rx = sx + Math.round(dir * s * 0.45 + Math.sin(s * 0.5 + k) * 2); var ry = baseY - 1 - s;
            px(ctx, rx, ry, w, 1, WOOD[1]); px(ctx, rx, ry, 1, 1, WOOD[3]);
          }
        }
        px(ctx, cx - 5, baseY - 34, 3, 2, '#e8c070'); px(ctx, cx + 3, baseY - 34, 3, 2, '#e8c070');   /* the eyes catch the fire */
        fire = { fx: cx, fy: baseY - 11, fw: 6 };   /* ⛔ v2 at baseY-19 hid the face and read as an EGG on fire (looked at): the fire sits in the LAP */
      }
    }
    paintRelic(ctx, spec, cx, baseY, fire);
    paintWeather(ctx, spec, cx, baseY, r);
    return fire;
  }

  function paintRelic(ctx, spec, cx, baseY, fire) {
    /* ⛔ v1 stood relics at cx+15 and the banner ran to x 51 of a 48 px cell — into the NEXT animation frame, where it showed
     *    as a stray red bar on the far edge (contact_48.png, looked at). Every relic now fits x <= cx+22. */
    var x = cx + 13; var y = baseY;
    switch (spec.relic) {
      case 'blade':
        px(ctx, x, y - 30, 3, 26, IRON[3]); px(ctx, x + 2, y - 30, 1, 26, IRON[1]);
        px(ctx, x - 3, y - 32, 9, 2, '#a07b2c'); px(ctx, x, y - 38, 3, 6, WOOD[2]); px(ctx, x, y - 40, 3, 2, '#d4ab4a');
        break;
      case 'skull':
        px(ctx, x - 1, y - 8, 8, 6, '#d8d0bc'); px(ctx, x - 1, y - 8, 8, 1, '#f2ecdc');
        px(ctx, x, y - 6, 2, 2, '#1a1410'); px(ctx, x + 3, y - 6, 2, 2, '#1a1410'); px(ctx, x + 1, y - 3, 4, 1, '#8a8070');
        break;
      case 'bell':
        px(ctx, x + 1, y - 34, 2, 24, WOOD[1]); px(ctx, x - 4, y - 34, 10, 2, WOOD[2]);
        px(ctx, x - 3, y - 31, 6, 7, '#a07b2c'); px(ctx, x - 3, y - 31, 2, 7, '#d4ab4a'); px(ctx, x - 4, y - 24, 8, 1, '#6b4f1c');
        break;
      case 'banner':
        px(ctx, x + 1, y - 46, 2, 46, WOOD[1]); px(ctx, x + 1, y - 46, 1, 46, WOOD[3]);
        for (var i = 0; i < 16; i++) px(ctx, x + 3, y - 44 + i, 7 - (i > 12 ? (i - 12) * 2 : 0), 1, i % 5 === 0 ? '#b04a52' : '#7a2f3a');
        break;
      case 'ring':
        for (var a = 0; a < 16; a++) { var t = a / 16 * Math.PI * 2; px(ctx, x + 2 + Math.round(Math.cos(t) * 5), y - 9 + Math.round(Math.sin(t) * 5), 2, 2, a < 8 ? IRON[3] : IRON[1]); }
        break;
      default: break;
    }
    void fire;
  }

  function paintWeather(ctx, spec, cx, baseY, r) {
    var S = STONE[spec.stone];
    if (spec.weather === 'fresh') return;
    var n = spec.weather === 'worn' ? 5 : 9;
    for (var i = 0; i < n; i++) {                                     /* chips: a dark notch with a lit lower lip */
      var x = cx - 14 + Math.floor(r() * 28); var y = baseY - 4 - Math.floor(r() * 30);
      px(ctx, x, y, 2, 1, S[0]); px(ctx, x, y + 1, 2, 1, S[3]);
    }
    if (spec.weather === 'cracked' || spec.weather === 'overgrown') { /* a crack: a broken dark line, never a ruled one */
      var x0 = cx - 6 + Math.floor(r() * 12); var y0 = baseY - 30 - Math.floor(r() * 6);
      for (var s = 0; s < 14; s++) { if (s % 5 === 3) continue; px(ctx, x0 + Math.round(Math.sin(s * 1.7) * 2), y0 + s, 1, 1, '#121216'); }
    }
    if (spec.weather === 'overgrown') {                               /* moss on the upward faces, ivy down one side */
      for (var m = 0; m < 22; m++) { var mx = cx - 15 + Math.floor(r() * 30); var my = baseY - 2 - Math.floor(r() * 12); px(ctx, mx, my, 2, 1, MOSS[m % 3]); }
      for (var v = 0; v < 18; v++) px(ctx, cx - 15 + (v % 3), baseY - 40 + v * 2, 2, 2, MOSS[(v + 1) % 3]);
    }
  }

  /**
   * Draw ONE frame of the fire. Layered tongues (deep rim, body, hot core), each tongue's height a function of the frame
   * phase, plus rising embers. `lit` false draws the banked coals only (an unkindled shrine).
   */
  function paintFire(ctx, spec, fire, phase, lit) {
    var F = FIRE[spec.fuel];
    var fx = fire.fx; var fy = fire.fy; var fw = fire.fw;
    for (var c = -fw + 1; c < fw; c += 2) px(ctx, fx + c, fy - 1, 2, 2, (c + Math.round(phase * 8)) % 4 === 0 ? F[2] : F[0]);   /* coals */
    if (!lit) return;
    var tongues = Math.max(3, Math.round(fw / 2.5));
    for (var t = 0; t < tongues; t++) {
      var u = tongues === 1 ? 0.5 : t / (tongues - 1);
      var x = fx - fw + 2 + Math.round(u * (fw * 2 - 4));
      var center = 1 - Math.abs(u - 0.5) * 2;                          /* tall in the middle */
      var flick = Math.sin((phase + t * 0.37) * Math.PI * 2) * 0.5 + 0.5;
      var h = Math.round(6 + center * 14 + flick * 6);
      for (var y = 0; y < h; y++) {
        var k = y / h; var w = Math.max(1, Math.round((1 - k) * 3.2));
        var sway = Math.round(Math.sin((phase * 2 + y * 0.18 + t) * Math.PI) * k * 2);
        px(ctx, x - w + sway, fy - 2 - y, w * 2, 1, k > 0.75 ? F[0] : F[1]);
        if (k < 0.55 && w > 1) px(ctx, x - Math.max(1, w - 2) + sway, fy - 2 - y, Math.max(1, w - 2) * 2, 1, F[2]);
      }
    }
    for (var e = 0; e < 5; e++) {                                      /* embers rising and drifting */
      var p = (phase + e / 5) % 1;
      var ex = fx + Math.round(Math.sin((e * 2.1 + p * 3) * Math.PI) * (fw * 0.6));
      var ey = fy - 22 - Math.round(p * 26);
      if (p < 0.85) px(ctx, ex, ey, 1, 1, F[3]);
    }
  }

  var CELL_W = 48; var CELL_H = 96; var FRAMES = 6;
  /**
   * Paint a shrine's whole animation strip: FRAMES cells side by side, CELL_W x CELL_H each. The body is drawn into
   * every cell from the same seed, so only the fire differs between frames.
   * @param {CanvasRenderingContext2D} ctx  a context at least FRAMES*CELL_W x CELL_H
   * @param {object} spec  from resolve()
   * @param {boolean} lit  kindled (true) or banked (false)
   * @returns {{fire:{fx:number,fy:number,fw:number}, frames:number, cellW:number, cellH:number}}
   */
  function paintStrip(ctx, spec, lit) {
    var fire = null;
    for (var f = 0; f < FRAMES; f++) {
      var r = rng(spec.seed ^ 0x5bd1e995);                           /* the SAME draws every frame: the body cannot shimmer */
      ctx.save(); ctx.translate(f * CELL_W, 0);
      ctx.beginPath(); ctx.rect(0, 0, CELL_W, CELL_H); ctx.clip();  /* a frame can never paint into its neighbour */
      fire = paintBody(ctx, spec, CELL_W / 2, CELL_H - 4, r);
      paintFire(ctx, spec, fire, f / FRAMES, lit);
      ctx.restore();
    }
    return { fire: fire, frames: FRAMES, cellW: CELL_W, cellH: CELL_H };
  }

  /**
   * Paint the warm light pool that sits UNDER a shrine on the ground (drawn once; the sprite's alpha flickers, so no
   * bitmap is redrawn per frame).
   */
  function paintLightPool(ctx, spec, w, h) {
    var F = FIRE[spec.fuel];
    /* ⛔ v1 (alpha 0.55, the fire's body colour to 45%) read as a COLOURED RUG under every shrine (contact_48.png, looked at):
     *    light on ground is a falloff, not a disc. Ember colour only, a steep falloff, a third of the strength. */
    var g = ctx.createRadialGradient(w / 2, h / 2, 1, w / 2, h / 2, w / 2);
    g.addColorStop(0, F[3]); g.addColorStop(0.25, F[1]); g.addColorStop(0.6, 'rgba(0,0,0,0.0)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.globalAlpha = 0.22; ctx.fillStyle = g; ctx.fillRect(0, 0, w, h); ctx.globalAlpha = 1;
  }

  CSAF.VigilShrine = {
    version: '1.0.0',
    FORMS: FORMS, FUELS: FUELS, RELICS: RELICS, WEATHER: WEATHER, FIRE: FIRE, STONE: STONE,
    CELL_W: CELL_W, CELL_H: CELL_H, FRAMES: FRAMES,
    rng: rng, hashInts: hashInts, resolve: resolve,
    paintBody: paintBody, paintFire: paintFire, paintStrip: paintStrip, paintLightPool: paintLightPool
  };
})();
