//=============================================================================
// Vigil.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Vigil [3/3] — the Souls loop for MZ. Rest at drawn shrines to heal and raise the fallen enemies, spend what you carry at the altar, and when you fall, walk back to your echo to take it back. v1.0.0
 * @author CSAF — Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @param currencyMode
 * @text Currency carried
 * @desc What the party carries, drops when it falls, and spends at the altar.
 * @type select
 * @option Gold
 * @value gold
 * @option A variable
 * @value variable
 * @option Embers (battle EXP is held, not applied)
 * @value embers
 * @default gold
 *
 * @param currencyVariable
 * @text Currency variable
 * @desc Used when the currency is "A variable".
 * @type variable
 * @default 0
 *
 * @param embersVariable
 * @text Mirror embers to variable
 * @desc Embers mode only. Copies the held embers into this variable so your own events and HUD can read it. 0 = none.
 * @type variable
 * @default 0
 *
 * @param currencyName
 * @text Currency name
 * @desc Shown on the altar under the count. Blank = automatic: your database's currency unit (gold), the variable's name (variable), EMBERS (embers).
 * @type string
 * @default
 *
 * @param dropPercent
 * @text Dropped on death (%)
 * @desc The share of what is carried that stays in the echo where the party fell.
 * @type number
 * @min 0
 * @max 100
 * @default 100
 *
 * @param saveOnRest
 * @text Autosave on rest
 * @desc Resting writes the autosave slot (only if your project has autosave on).
 * @type boolean
 * @default true
 *
 * @param altarOnRest
 * @text Open the altar on rest
 * @desc Resting opens the level-up altar. Off = rest heals and respawns only; open the altar with the plugin command.
 * @type boolean
 * @default true
 *
 * @param respawnDefault
 * @text Untagged enemies
 * @desc What resting does to an event with NO <vigil: ...> tag.
 * @type select
 * @option Leave it defeated
 * @value never
 * @option Raise it again
 * @value always
 * @default never
 *
 * @param strongerStep
 * @text Stronger step (per rest)
 * @desc An event tagged <vigil: respawn stronger> returns this much stronger each time it is raised (0.25 = +25% to every parameter).
 * @type number
 * @decimals 2
 * @min 0
 * @default 0.25
 *
 * @param strongerCap
 * @text Stronger cap (tiers)
 * @desc How many times an enemy can come back stronger.
 * @type number
 * @min 0
 * @default 4
 *
 * @param levelCost
 * @text Level cost (gold / variable)
 * @desc A formula in "level" (the actor's current level). Embers mode always charges MZ's own EXP-to-next-level instead.
 * @type string
 * @default Math.round(25 * level * level + 75)
 *
 * @param paramCost
 * @text Attribute cost
 * @desc A formula in "bought" (attributes this actor has already bought at the altar).
 * @type string
 * @default Math.round(40 + 20 * bought)
 *
 * @param paramSteps
 * @text Attribute steps
 * @desc How much one purchase adds: MaxHP, MaxMP, ATK, DEF, MAT, MDF, AGI, LUK.
 * @type string
 * @default 30,10,2,2,2,2,2,2
 *
 * @param interceptEventGameOver
 * @text Catch event "Game Over"
 * @desc Off (default) lets your own "Game Over" event command end the game as written. On sends it to the shrine too.
 * @type boolean
 * @default false
 *
 * @param shrinesStartLit
 * @text Shrines start lit
 * @desc Off: a shrine shows banked coals until the party first rests there (it is then kindled for good).
 * @type boolean
 * @default false
 *
 * @param echoRange
 * @text Echo wakes within (tiles)
 * @desc The echo begins to replay the fall when the leader comes this close.
 * @type number
 * @min 1
 * @default 3
 *
 * @param echoSteps
 * @text Steps the echo replays
 * @type number
 * @min 2
 * @max 64
 * @default 12
 *
 * @param deathTitle
 * @text Death plate title
 * @type string
 * @default FALLEN
 *
 * @param deathLine
 * @text Death plate line
 * @type string
 * @default What you carried waits where you fell.
 *
 * @param displayFont
 * @text Display face
 * @desc A CSS font stack for the death plate and the altar. Never the engine's own font.
 * @type string
 * @default "Cinzel", "Trajan Pro", Georgia, "Times New Roman", serif
 *
 * @command rest
 * @text Rest here
 * @desc Rest at the event that runs this command, as if it were a shrine.
 *
 * @command openAltar
 * @text Open the altar
 *
 * @command giveCurrency
 * @text Give currency
 * @arg amount
 * @type number
 * @min -999999
 * @default 100
 *
 * @command clearEcho
 * @text Clear the echo
 * @desc Removes an uncollected echo (and what it holds).
 *
 * @help
 * ============================================================================
 * Vigil — part 3 of 3. Install VigilShrine.js, VigilEcho.js and Vigil.js.
 * ============================================================================
 * Any Plugin Manager order works: each file finds the others at first use.
 *
 * SHRINES — put this in an event's Note box:
 *     <vigil: shrine>
 *   and give the event no image. Vigil draws the shrine on that tile and the
 *   party rests when it activates it. Optional, to choose instead of letting
 *   the map decide:
 *     <vigil-form: cairn>      brazier, cairn, wardlamp, stone, idol
 *     <vigil-fuel: bone>       pine, peat, bone, oil, coal
 *     <vigil-relic: blade>     none, blade, skull, bell, banner, ring
 *     <vigil-weather: worn>    fresh, worn, cracked, overgrown
 *     <vigil-seed: 42>
 *
 * REST heals the party, makes the shrine the return point, raises the fallen
 * enemies (below), autosaves if your project allows it, and opens the altar.
 *
 * ENEMIES — on an encounter event's Note box:
 *     <vigil: respawn>            raised again at every rest
 *     <vigil: respawn stronger>   raised again, stronger each time
 *     <vigil: never>              stays defeated
 *   "Defeated" means the event turned one of its self switches ON (the usual
 *   way an encounter removes itself). Resting turns those self switches OFF
 *   again, on every map, not only the one you rest on.
 *
 * DEATH — instead of Game Over the party wakes at the last shrine, healed.
 * What it carried stays where it fell, inside an ECHO: a ghost of the party
 * leader that replays the last steps when you come near. Walk onto it to take
 * it all back. Fall again first and the old echo is gone.
 * If the party has not rested anywhere yet, Game Over happens as normal.
 *
 * COMPATIBILITY — see the compatibility block on the store page.
 *
 * Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.
 */

(function () {
  'use strict';

  var PLUGIN = 'Vigil';
  var root = (typeof window !== 'undefined') ? window : globalThis;
  var CSAF = root.CSAF = root.CSAF || {};
  var SCHEMA = 1;

  /* ---------------------------------------------------------- parameters --- */
  var P = PluginManager.parameters(PLUGIN) || {};
  /* ⛔ wing §16: parameters are STRINGS, '' is absent (never 0) and "0" is truthy — coerce, then compare */
  function str(k, d) { var v = P[k]; return (v === undefined || v === null || v === '') ? d : String(v); }
  function num(k, d) { var v = P[k]; if (v === undefined || v === null || v === '') return d; var n = Number(v); return isFinite(n) ? n : d; }
  function bool(k, d) { var v = P[k]; if (v === undefined || v === null || v === '') return d; return String(v) === 'true'; }
  var CFG = {
    currencyMode: str('currencyMode', 'gold'),
    currencyVariable: num('currencyVariable', 0),
    embersVariable: num('embersVariable', 0),
    currencyName: str('currencyName', ''),
    dropPercent: Math.max(0, Math.min(100, num('dropPercent', 100))),
    saveOnRest: bool('saveOnRest', true),
    altarOnRest: bool('altarOnRest', true),
    respawnDefault: str('respawnDefault', 'never'),
    strongerStep: Math.max(0, num('strongerStep', 0.25)),
    strongerCap: Math.max(0, num('strongerCap', 4)),
    levelCost: str('levelCost', 'Math.round(25 * level * level + 75)'),
    paramCost: str('paramCost', 'Math.round(40 + 20 * bought)'),
    paramSteps: str('paramSteps', '30,10,2,2,2,2,2,2').split(',').map(function (s) { var n = Number(s); return isFinite(n) ? n : 0; }),
    interceptEventGameOver: bool('interceptEventGameOver', false),
    shrinesStartLit: bool('shrinesStartLit', false),
    echoRange: Math.max(1, num('echoRange', 3)),
    echoSteps: Math.max(2, Math.min(64, num('echoSteps', 12))),
    deathTitle: str('deathTitle', 'FALLEN'),
    deathLine: str('deathLine', 'What you carried waits where you fell.'),
    displayFont: str('displayFont', '"Cinzel", "Trajan Pro", Georgia, "Times New Roman", serif')
  };
  while (CFG.paramSteps.length < 8) CFG.paramSteps.push(0);

  /* ------------------------------------------- siblings, at first use only --- */
  function shrineLib() { var s = CSAF.VigilShrine; if (!s) throw new Error('Vigil: VigilShrine.js is not installed'); return s; }
  function echoLib() { var e = CSAF.VigilEcho; if (!e) throw new Error('Vigil: VigilEcho.js is not installed'); return e; }

  /* --------------------------------------------------------------- state --- */
  /**
   * The save slot. PLAIN DATA ONLY (numbers, strings, arrays, objects of those) so JsonEx round-trips it byte for byte
   * (wing §13 needs no trick when the data is genuinely data). Repaired, never thrown on, if old or corrupt.
   */
  function fresh() { return { schema: SCHEMA, shrine: null, echo: null, fallen: [], tiers: {}, kindled: {}, bought: {}, embers: 0, deaths: 0, rests: 0, reclaimed: 0, lost: 0 }; }
  function state() {
    var s = $gameSystem._csafVigil;
    if (!s || typeof s !== 'object' || Array.isArray(s)) s = $gameSystem._csafVigil = fresh();
    var f = fresh();
    for (var k in f) if (!(k in s)) s[k] = f[k];
    if (!Array.isArray(s.fallen)) s.fallen = [];
    for (var o = ['tiers', 'kindled', 'bought'], i = 0; i < o.length; i++) if (!s[o[i]] || typeof s[o[i]] !== 'object' || Array.isArray(s[o[i]])) s[o[i]] = {};
    if (typeof s.embers !== 'number' || !isFinite(s.embers)) s.embers = 0;
    if (s.schema !== SCHEMA) s.schema = SCHEMA;                     /* forward migrations go here, one per version */
    return s;
  }

  var _GS_init = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () { _GS_init.apply(this, arguments); this._csafVigil = fresh(); };

  /* ------------------------------------------------------------ currency --- */
  function carried() {
    if (CFG.currencyMode === 'variable') return Number(CFG.currencyVariable) > 0 ? ($gameVariables.value(CFG.currencyVariable) | 0) : 0;
    if (CFG.currencyMode === 'embers') return state().embers;
    return $gameParty.gold();
  }
  function setCarried(n) {
    n = Math.max(0, Math.floor(n));
    if (CFG.currencyMode === 'variable') { if (Number(CFG.currencyVariable) > 0) $gameVariables.setValue(CFG.currencyVariable, n); return; }
    if (CFG.currencyMode === 'embers') { state().embers = n; if (Number(CFG.embersVariable) > 0) $gameVariables.setValue(CFG.embersVariable, n); return; }
    var g = $gameParty.gold(); if (n > g) $gameParty.gainGold(n - g); else if (n < g) $gameParty.loseGold(g - n);
  }

  /* Embers mode: battle EXP is held as embers, not applied — the altar spends it on levels at MZ's own curve. */
  var _BM_gainExp = BattleManager.gainExp;
  BattleManager.gainExp = function () {
    if (CFG.currencyMode !== 'embers') return _BM_gainExp.apply(this, arguments);
    var exp = (this._rewards && this._rewards.exp) | 0;
    setCarried(carried() + exp);
  };

  /* ------------------------------------------------------------- notetags --- */
  function metaOf(ev) { var d = ev && ev.event && ev.event(); return (d && d.meta) ? d.meta : {}; }
  /** 'shrine' | 'respawn' | 'stronger' | 'never' | '' — what an event's <vigil: ...> tag says */
  function tagOf(ev) {
    var v = metaOf(ev).vigil; if (v === undefined || v === true) return '';
    v = String(v).trim().toLowerCase();
    if (v === 'shrine') return 'shrine';
    if (v === 'respawn stronger' || v === 'stronger') return 'stronger';
    if (v === 'respawn' || v === 'always') return 'respawn';
    if (v === 'never') return 'never';
    return '';
  }
  function respawnRule(ev) { var t = tagOf(ev); if (t === 'respawn' || t === 'stronger' || t === 'never') return t; return t === 'shrine' ? 'never' : (CFG.respawnDefault === 'always' ? 'respawn' : 'never'); }

  /* -------------------------------------------------- defeat bookkeeping --- */
  /*
   * An encounter "removes itself" by turning a self switch ON. We record that key when it happens (on the map where the
   * event is loaded, so its tag can be read), and resting turns every recorded key OFF again — on every map.
   */
  var _SS_setValue = Game_SelfSwitches.prototype.setValue;
  Game_SelfSwitches.prototype.setValue = function (key, value) {
    _SS_setValue.apply(this, arguments);
    try {
      if (!value || !key || !$gameMap || key[0] !== $gameMap.mapId()) return;
      var ev = $gameMap.event(key[1]); if (!ev) return;
      var rule = respawnRule(ev); if (rule === 'never') return;
      var s = state(); var k = key[0] + ',' + key[1] + ',' + key[2]; var ek = key[0] + ',' + key[1];
      if (s.fallen.indexOf(k) < 0) s.fallen.push(k);
      /* a "stronger" event is remembered by the PRESENCE of its tier key: its map may not be loaded when the party rests */
      if (rule === 'stronger' && !Object.prototype.hasOwnProperty.call(s.tiers, ek)) s.tiers[ek] = 0;
    } catch (e) { /* bookkeeping must never break the event that set the switch */ }
  };

  /** raise every fallen encounter; a "stronger" one comes back one tier up (to the cap). Returns how many were raised. */
  function raiseFallen() {
    var s = state(); var n = 0; var seenEv = {};
    for (var i = 0; i < s.fallen.length; i++) {
      var parts = String(s.fallen[i]).split(','); var mapId = Number(parts[0]); var evId = Number(parts[1]);
      if (!(mapId > 0 && evId > 0) || !parts[2]) continue;
      _SS_setValue.call($gameSelfSwitches, [mapId, evId, parts[2]], false); n++;
      var ek = mapId + ',' + evId;
      if (!seenEv[ek]) { seenEv[ek] = true; if (Object.prototype.hasOwnProperty.call(s.tiers, ek)) s.tiers[ek] = Math.min(CFG.strongerCap, (s.tiers[ek] | 0) + 1); }
    }
    s.fallen.length = 0;
    if ($gameMap && typeof $gameMap.requestRefresh === 'function') $gameMap.requestRefresh();
    return n;
  }

  /* the tier reaches the troop: the battle command remembers which event started it */
  var _GI_301 = Game_Interpreter.prototype.command301;
  Game_Interpreter.prototype.command301 = function (params) {
    var t = state().tiers[this._mapId + ',' + this._eventId] | 0;
    $gameTemp._csafVigilTier = t;
    return _GI_301.call(this, params);
  };
  var _GT_setup = Game_Troop.prototype.setup;
  Game_Troop.prototype.setup = function (troopId) {
    _GT_setup.apply(this, arguments);
    this._csafVigilTier = ($gameTemp && $gameTemp._csafVigilTier) | 0;
    if ($gameTemp) $gameTemp._csafVigilTier = 0;
  };
  var _GE_paramBase = Game_Enemy.prototype.paramBase;
  Game_Enemy.prototype.paramBase = function (paramId) {
    var base = _GE_paramBase.call(this, paramId);
    var tier = ($gameTroop && $gameTroop._csafVigilTier) | 0;
    return tier > 0 ? Math.round(base * (1 + CFG.strongerStep * tier)) : base;
  };

  /* ---------------------------------------------------------------- rest --- */
  /**
   * Rest at `ev` (a Game_Event). Heals, records the return point, kindles the shrine, raises the fallen, autosaves if the
   * project allows it, then opens the altar. Returns a plain summary (the Node suite reads it).
   */
  function rest(ev) {
    var s = state();
    var mapId = $gameMap.mapId();
    var members = $gameParty.members();
    for (var i = 0; i < members.length; i++) members[i].recoverAll();
    s.shrine = { mapId: mapId, x: ev.x, y: ev.y, eventId: ev.eventId ? ev.eventId() : 0 };
    var kk = mapId + ',' + s.shrine.eventId; var newlyLit = !s.kindled[kk]; s.kindled[kk] = 1;
    var raised = raiseFallen();
    s.rests++;
    if (CFG.saveOnRest && SceneManager._scene && typeof SceneManager._scene.requestAutosave === 'function') SceneManager._scene.requestAutosave();
    if (CFG.altarOnRest && typeof SceneManager.push === 'function' && CSAF.Vigil.Scene_Altar()) SceneManager.push(CSAF.Vigil.Scene_Altar());
    if (newlyLit && CSAF.Vigil._onKindle) CSAF.Vigil._onKindle(ev);
    return { healed: members.length, raised: raised, kindled: newlyLit };
  }

  var _GE_start = Game_Event.prototype.start;
  Game_Event.prototype.start = function () {
    if (tagOf(this) === 'shrine' && !$gameParty.inBattle()) rest(this);
    _GE_start.apply(this, arguments);
  };

  /* ---------------------------------------------------------- the steps --- */
  var ring = null;
  function stepRing() { if (!ring) ring = new (echoLib().StepRing)(64); return ring; }
  var _GP_increaseSteps = Game_Player.prototype.increaseSteps;
  Game_Player.prototype.increaseSteps = function () {
    _GP_increaseSteps.apply(this, arguments);
    stepRing().push($gameMap.mapId(), this.x, this.y, this.direction());
  };

  /* --------------------------------------------------------------- death --- */
  /**
   * What happens when the party falls with a shrine to return to: the carried share is taken and left in a NEW echo at
   * the place of the fall (an older uncollected echo is lost), the party is restored and sent to the shrine. Returns a
   * plain summary. With no shrine yet, returns null and the caller lets Game Over stand.
   */
  function fall() {
    var s = state(); if (!s.shrine) return null;
    var mapId = $gameMap.mapId(); var have = carried();
    var amount = Math.floor(have * CFG.dropPercent / 100);
    if (s.echo) s.lost += s.echo.amount | 0;
    var leader = $gameParty.leader();
    var steps = stepRing().tail(mapId, CFG.echoSteps);
    var last = steps.length ? steps[steps.length - 1] : null;
    if (!last || last[0] !== $gamePlayer.x || last[1] !== $gamePlayer.y) steps.push([$gamePlayer.x, $gamePlayer.y, $gamePlayer.direction()]);
    s.echo = { mapId: mapId, x: $gamePlayer.x, y: $gamePlayer.y, d: $gamePlayer.direction(), amount: amount,
      charName: leader ? leader.characterName() : '', charIndex: leader ? leader.characterIndex() : 0, steps: steps };
    setCarried(have - amount);
    s.deaths++;
    var all = $gameParty.members(); for (var i = 0; i < all.length; i++) all[i].recoverAll();
    if ($gameMap._interpreter && typeof $gameMap._interpreter.clear === 'function') $gameMap._interpreter.clear();
    $gamePlayer.reserveTransfer(s.shrine.mapId, s.shrine.x, s.shrine.y + 1, 2, 0);
    return { amount: amount, echo: s.echo, to: s.shrine };
  }

  /** the party walked onto its echo: give back what it holds */
  function reclaim() {
    var s = state(); var e = s.echo; if (!e) return 0;
    setCarried(carried() + (e.amount | 0)); s.reclaimed += e.amount | 0; s.echo = null;
    return e.amount | 0;
  }

  /* ⛔ Game Over is caught at the one door every path uses (battle, map, slip damage): SceneManager.goto(Scene_Gameover). */
  var scriptedGameOver = false;
  var _GI_353 = Game_Interpreter.prototype.command353;
  Game_Interpreter.prototype.command353 = function () {
    scriptedGameOver = !CFG.interceptEventGameOver;
    try { return _GI_353.apply(this, arguments); } finally { scriptedGameOver = false; }
  };
  var _SM_goto = SceneManager.goto;
  SceneManager.goto = function (sceneClass) {
    if (sceneClass === root.Scene_Gameover && !scriptedGameOver && state().shrine) return _SM_goto.call(this, CSAF.Vigil.Scene_Death());
    return _SM_goto.apply(this, arguments);
  };

  /* ------------------------------------------------------------- the altar --- */
  var PARAM_NAMES = ['MAX HP', 'MAX MP', 'ATTACK', 'DEFENCE', 'M.ATTACK', 'M.DEFENCE', 'AGILITY', 'LUCK'];
  function evalCost(formula, vars) {
    try { var f = new Function('level', 'bought', 'Math', 'return (' + formula + ');'); var n = Number(f(vars.level | 0, vars.bought | 0, Math)); return isFinite(n) ? Math.max(0, Math.round(n)) : Infinity; }
    catch (e) { return Infinity; }
  }
  /** what a level costs this actor now: MZ's own EXP-to-next-level in embers mode, the formula otherwise */
  function levelCost(actor) {
    if (actor.isMaxLevel && actor.isMaxLevel()) return Infinity;
    if (CFG.currencyMode === 'embers') return Math.max(0, actor.nextLevelExp() - actor.currentExp());
    return evalCost(CFG.levelCost, { level: actor.level });
  }
  function boughtOf(actor) { return state().bought[actor.actorId()] | 0; }
  function paramCost(actor) { return evalCost(CFG.paramCost, { bought: boughtOf(actor) }); }
  /** spend at the altar. kind 'level' or a param id 0..7. Returns true if bought. */
  function buy(actor, kind) {
    var cost = kind === 'level' ? levelCost(actor) : paramCost(actor);
    if (!isFinite(cost) || cost > carried()) return false;
    setCarried(carried() - cost);
    if (kind === 'level') actor.changeExp(actor.nextLevelExp(), false);
    else { actor.addParam(kind | 0, CFG.paramSteps[kind | 0] | 0); var s = state(); s.bought[actor.actorId()] = boughtOf(actor) + 1; }
    return true;
  }

  /* ------------------------------------------------- scenes, built lazily --- */
  var SceneDeath = null; var SceneAltar = null;
  function font(px) { return 'bold ' + px + 'px ' + CFG.displayFont; }

  function buildDeath() {
    if (SceneDeath) return SceneDeath;
    SceneDeath = function () { this.initialize.apply(this, arguments); };
    SceneDeath.prototype = Object.create(Scene_Base.prototype);
    SceneDeath.prototype.constructor = SceneDeath;
    SceneDeath.prototype.create = function () {
      Scene_Base.prototype.create.call(this);
      var W = Graphics.width; var H = Graphics.height;
      this._bg = new Sprite(new Bitmap(W, H)); var c = this._bg.bitmap.context;
      var g = c.createRadialGradient(W / 2, H * 0.46, 20, W / 2, H * 0.46, W * 0.7);
      g.addColorStop(0, '#2a1a14'); g.addColorStop(0.55, '#120c0a'); g.addColorStop(1, '#050304');
      c.fillStyle = g; c.fillRect(0, 0, W, H); this._bg.bitmap._baseTexture.update();
      this.addChild(this._bg);
      this._ash = [];
      var ab = new Bitmap(3, 3); ab.fillRect(0, 0, 3, 3, '#8a7a6a');
      for (var i = 0; i < 60; i++) { var s = new Sprite(ab); s.x = (i * 137) % W; s.y = (i * 89) % H; s.alpha = 0.15 + (i % 5) * 0.08; this._ash.push(s); this.addChild(s); }
      /* what is about to be left behind, read with the same rule fall() applies (⛔ the first plate said only "what you
       * carried waits" and never showed how much, review 2026-10-09) */
      this._lost = state().shrine ? Math.floor(carried() * CFG.dropPercent / 100) : 0;
      this._title = new Sprite(new Bitmap(W, 220)); this._title.y = H * 0.36;
      var t = this._title.bitmap.context; t.textAlign = 'center'; t.textBaseline = 'middle';
      t.font = font(84); t.fillStyle = '#3a0e08'; t.fillText(CFG.deathTitle, W / 2 + 3, 63);
      t.fillStyle = '#c8462a'; t.fillText(CFG.deathTitle, W / 2, 60);
      t.fillStyle = 'rgba(255,190,140,0.55)'; t.fillRect(W * 0.3, 108, W * 0.4, 1);
      t.font = 'italic 22px ' + CFG.displayFont; t.fillStyle = '#b8a490'; t.fillText(CFG.deathLine, W / 2, 132);
      if (this._lost > 0) {
        /* the amount and its label only: a coal glyph after the label read as a stray full stop (looked at 2026-10-09) */
        var lostTxt = this._lost + '  ' + currencyLabel(); t.font = font(30);
        t.fillStyle = '#2a0e08'; t.fillText(lostTxt, W / 2 + 2, 182); t.fillStyle = '#e8a060'; t.fillText(lostTxt, W / 2, 180);
      }
      this._title.bitmap._baseTexture.update(); this._title.opacity = 0; this.addChild(this._title);
      this._t = 0; this._done = false;
    };
    /* the project's own Game Over ME, as Scene_Gameover.playGameoverMusic plays it (rmmz_scenes.js:3669); the map's BGM
     * returns with the wake, because the transfer to the shrine autoplays the map (Scene_Map.onTransferEnd) */
    SceneDeath.prototype.start = function () {
      Scene_Base.prototype.start.call(this);
      AudioManager.stopBgm(); AudioManager.stopBgs();
      if ($dataSystem && $dataSystem.gameoverMe && $dataSystem.gameoverMe.name) AudioManager.playMe($dataSystem.gameoverMe);
    };
    SceneDeath.prototype.update = function () {
      Scene_Base.prototype.update.call(this);
      this._t++;
      var H = Graphics.height;
      for (var i = 0; i < this._ash.length; i++) { var s = this._ash[i]; s.y += 0.4 + (i % 3) * 0.3; s.x += Math.sin((this._t + i * 20) * 0.02) * 0.4; if (s.y > H) s.y -= H; }
      this._title.opacity = Math.min(255, this._t * 4);
      if (!this._done && (this._t > 240 || (this._t > 60 && (Input.isTriggered('ok') || TouchInput.isTriggered())))) {
        this._done = true;
        var r = fall();
        if (r) SceneManager.goto(Scene_Map); else _SM_goto.call(SceneManager, root.Scene_Gameover);
      }
    };
    return SceneDeath;
  }

  /** the carried currency's label: the parameter, or (blank, the default) the project's own word for it */
  function currencyLabel() {
    if (CFG.currencyName) return CFG.currencyName;
    if (CFG.currencyMode === 'gold') return String((typeof TextManager !== 'undefined' && TextManager.currencyUnit) || 'G').toUpperCase();
    if (CFG.currencyMode === 'variable' && Number(CFG.currencyVariable) > 0 && $dataSystem && $dataSystem.variables && $dataSystem.variables[CFG.currencyVariable]) return String($dataSystem.variables[CFG.currencyVariable]).toUpperCase();
    return 'EMBERS';
  }
  /** the project's own word for an altar row: 0 = level, 1..8 = the eight parameters (TextManager reads the database) */
  function termOf(j) {
    var t = typeof TextManager !== 'undefined' ? (j === 0 ? TextManager.level : TextManager.param(j - 1)) : '';
    return String(t || (j === 0 ? 'Level' : PARAM_NAMES[j - 1])).toUpperCase();
  }
  /** the actor's class value of each parameter at the actor's maximum level (the database's own curve), for the bars */
  function classTop(act) {
    var out = [], cls = act.currentClass && act.currentClass(), lv = act.maxLevel ? act.maxLevel() : 99;
    for (var p = 0; p < 8; p++) { var row = cls && cls.params && cls.params[p], v = row ? Number(row[Math.min(lv, row.length - 1)]) : 0; out.push(Math.max(1, v || act.param(p) * 2)); }
    return out;
  }
  /** one small lit coal: the altar's single currency mark, beside every price and the carried count */
  function coalGlyph(c, x, y, lit) {
    c.fillStyle = '#26100a'; c.fillRect(Math.round(x) - 1, Math.round(y) - 2, 7, 6);
    c.fillStyle = lit ? '#e2581a' : '#5a3a2a'; c.fillRect(Math.round(x), Math.round(y) - 1, 5, 4);
    c.fillStyle = lit ? '#ffd38a' : '#7a5a4a'; c.fillRect(Math.round(x) + 1, Math.round(y) - 1, 2, 1);
  }
  function hexRgb(h) { return [parseInt(h.substr(1, 2), 16) | 0, parseInt(h.substr(3, 2), 16) | 0, parseInt(h.substr(5, 2), 16) | 0].join(','); }
  /** a shrine event's spec, resolved ONE way for the map sprite and the altar alike (wing §11: agree by construction) */
  function shrineSpec(ev, mapId, eventId) {
    var m = metaOf(ev);
    return shrineLib().resolve({ mapId: mapId, eventId: eventId, regionId: ev && $gameMap ? $gameMap.regionId(ev.x, ev.y) : 0,
      seed: m['vigil-seed'], form: m['vigil-form'], fuel: m['vigil-fuel'], relic: m['vigil-relic'], weather: m['vigil-weather'] });
  }

  function buildAltar() {
    if (SceneAltar) return SceneAltar;
    SceneAltar = function () { this.initialize.apply(this, arguments); };
    SceneAltar.prototype = Object.create(Scene_MenuBase.prototype);
    SceneAltar.prototype.constructor = SceneAltar;
    /*
     * ⛔ v1 was a 4 x 9 grid of numbers and read as a SPREADSHEET. ⛔ v2 put the fire at the foot with the leader's BACK to
     * us, and in the real engine (Internal_Ops/Capture/engine/altar.png and engine_stock/stock_altar.png, looked at
     * 2026-10-09) the leader stood ON the fire and hid it at MZ's stock 816x624, the footer ran through the leader, the heap
     * read as static, one bar scale made MaxHP dwarf every other parameter, and gold was labelled EMBERS.
     * v3 derives the whole layout from the screen (layout()): the offerings at the top; under them a band holding the
     * SHRINE YOU RESTED AT (its own painter, at the largest whole-pixel scale the band allows), the leader standing BESIDE
     * it facing the fire at the same pixel scale, and the heap of what you carry at its foot with the count above it.
     */
    SceneAltar.prototype.layout = function () {
      var W = Graphics.width, H = Graphics.height, n = Math.max(1, $gameParty.members().length);
      var top = 100, rowH = Math.max(24, Math.min(30, Math.floor((H - top - 230) / 9)));
      var listEnd = top + 9 * rowH, span = listEnd - top + 10;
      var pitch = Math.max(30, Math.min(58, Math.floor(span / n))), visible = Math.max(1, Math.min(n, Math.floor(span / pitch)));
      var x0 = Math.max(300, Math.round(W * 0.30)), bandTop = listEnd + 14, bandBot = H - 36;
      var Z = Math.max(1, Math.min(3, Math.floor((bandBot - bandTop) / shrineLib().CELL_H)));
      return { W: W, H: H, top: top, rowH: rowH, listEnd: listEnd, pitch: pitch, visible: visible, plateX: 36, plateW: x0 - 80, x0: x0, x1: W - 40, bandTop: bandTop, bandBot: bandBot, Z: Z };
    };
    /** the shrine the party rested at, as its map sprite draws it (its notetags and region when it is on this map) */
    SceneAltar.prototype.restSpec = function () {
      var sh = state().shrine; var here = sh && $gameMap && $gameMap.mapId() === sh.mapId;
      return shrineSpec(here ? $gameMap.event(sh.eventId) : null, sh ? sh.mapId : 1, sh ? sh.eventId : 1);
    };
    SceneAltar.prototype.create = function () {
      Scene_MenuBase.prototype.create.call(this);
      var L = shrineLib(), Lo = this._lay = this.layout(), W = Lo.W, H = Lo.H, Z = Lo.Z, spec = this._spec = this.restSpec();
      this._shade = new Sprite(new Bitmap(W, H)); var c = this._shade.bitmap.context;
      var g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, 'rgba(6,4,4,0.84)'); g.addColorStop(1, 'rgba(16,8,4,0.95)');
      c.fillStyle = g; c.fillRect(0, 0, W, H);
      /* the shrine: painted ONCE into its six-frame strip at 1x and scaled by whole pixels (nearest), cycled by setFrame */
      var strip = new Bitmap(L.CELL_W * L.FRAMES, L.CELL_H); strip.smooth = false;
      var info = L.paintStrip(strip.context, spec, true); strip._baseTexture.update();
      var sw = L.CELL_W * Z, shh = L.CELL_H * Z, sx = Math.round(W / 2 - sw / 2), sy = Lo.bandBot - shh;
      var fx = sx + info.fire.fx * Z, fy = sy + info.fire.fy * Z, rgb = hexRgb(L.FIRE[spec.fuel][1]);
      /* ⛔ v2 lit the room ORANGE round a BLUE bone fire: the glow is the fire's own body colour, centred ON the fire */
      var glow = c.createRadialGradient(fx, fy - 8 * Z, 6, fx, fy - 8 * Z, Math.max(200, 110 * Z));
      glow.addColorStop(0, 'rgba(' + rgb + ',0.40)'); glow.addColorStop(0.45, 'rgba(' + rgb + ',0.10)'); glow.addColorStop(1, 'rgba(0,0,0,0)');
      c.fillStyle = glow; c.fillRect(0, 0, W, H);
      c.save(); c.translate(fx - 60 * Z, Lo.bandBot - 12 * Z); L.paintLightPool(c, spec, 120 * Z, 26 * Z); c.restore();   /* the shrine's own light pool, on the band's floor */
      this._shade.bitmap._baseTexture.update(); this.addChild(this._shade);
      this._fire = new Sprite(strip); this._fire.scale.x = Z; this._fire.scale.y = Z; this._fire.x = sx; this._fire.y = sy;
      this._fire.setFrame(0, 0, L.CELL_W, L.CELL_H); this._fireBox = [sx, sy, sw, shh]; this.addChild(this._fire);
      /* the leader, standing BESIDE the shrine and facing it (row "right" of their own walking sheet), at the shrine's scale */
      var leader = $gameParty.leader();
      if (leader && leader.characterName()) {
        this._leader = new Sprite(ImageManager.loadCharacter(leader.characterName())); this._leader.scale.x = Z; this._leader.scale.y = Z;
        this._leaderIdx = leader.characterIndex(); this._leaderName = leader.characterName(); this._leader.visible = false; this.addChild(this._leader);
      }
      this._plate = new Sprite(new Bitmap(W, H)); this.addChild(this._plate);
      this._row = 0; this._col = 0; this._first = 0;
      this.redraw();
    };
    var COAL = [['#7a2a0c', '#a8380e'], ['#e2581a', '#ff9a3c'], ['#ffb860', '#ffd38a']];
    /**
     * The heap: one coal per (log-scaled) unit carried, stacked as a MOUND (each row one coal shorter than the one under
     * it, brick-staggered, cooler at the foot and brighter at the crown). ⛔ v2 scattered the same count as random dots and
     * it read as static noise at 816x624 (looked at). The count IS the picture; returns it.
     */
    SceneAltar.prototype.drawHeap = function (c, cx, by, amount) {
      var n = Math.min(160, Math.round(Math.log(1 + Math.max(0, amount)) * 18)), R = 0;
      while (R * (R + 1) / 2 < n) R++;
      var r = shrineLib().rng(0x51ab1e), k = 0;
      if (n > 0) { c.fillStyle = 'rgba(0,0,0,0.45)'; c.beginPath(); c.ellipse(cx, by + 1, R * 3 + 6, 4, 0, 0, Math.PI * 2); c.fill(); }
      for (var row = 0; row < R && k < n; row++) {
        var count = R - row, y = by - 3 - row * 3, band = COAL[Math.min(2, Math.floor(row / Math.max(1, R) * 3))];
        for (var i = 0; i < count && k < n; i++, k++) {
          var x = Math.round(cx - (count - 1) * 2.5 + i * 5 + (r() - 0.5) * 1.4);
          c.fillStyle = '#26100a'; c.fillRect(x, y + 1, 4, 3);
          c.fillStyle = band[r() < 0.5 ? 0 : 1]; c.fillRect(x, y, 4, 2);
          if (r() < 0.35) { c.fillStyle = '#fff0c0'; c.fillRect(x + 1, y, 1, 1); }
        }
      }
      this._heapTop = by - 3 - Math.max(0, R - 1) * 3;
      return n;
    };
    SceneAltar.prototype.redraw = function () {
      var Lo = this._lay, b = this._plate.bitmap, c = b.context, W = Lo.W, H = Lo.H;
      c.clearRect(0, 0, W, H); c.textBaseline = 'middle';
      c.textAlign = 'center'; c.font = font(40); c.fillStyle = '#e8b070'; c.fillText('THE ALTAR', W / 2, 44);
      c.fillStyle = 'rgba(232,176,112,0.40)'; c.fillRect(W / 2 - 150, 74, 300, 1);
      var actors = $gameParty.members(), n = actors.length;
      /* left: the party's name plates, scrolled so the chosen one is always on screen */
      if (this._row < this._first) this._first = this._row;
      if (this._row >= this._first + Lo.visible) this._first = this._row - Lo.visible + 1;
      var ph = Lo.pitch - 10, two = ph >= 40;
      for (var i = 0; i < Lo.visible && this._first + i < n; i++) {
        var rr = this._first + i, a = actors[rr], y = Lo.top + i * Lo.pitch, sel = rr === this._row;
        c.fillStyle = sel ? 'rgba(232,150,80,0.22)' : 'rgba(255,255,255,0.05)'; c.fillRect(Lo.plateX, y, Lo.plateW, ph);
        c.fillStyle = sel ? '#e8a060' : '#4a3a2e'; c.fillRect(Lo.plateX, y, 3, ph);
        c.textAlign = 'left';
        if (two) {
          c.font = font(20); c.fillStyle = sel ? '#fff0dc' : '#bca88e'; c.fillText(a.name(), Lo.plateX + 14, y + 18);
          c.font = font(13); c.fillStyle = sel ? '#e8b888' : '#7a6a58'; c.fillText('LEVEL ' + a.level, Lo.plateX + 14, y + 37);
        } else {
          c.font = font(16); c.fillStyle = sel ? '#fff0dc' : '#bca88e'; c.fillText(a.name(), Lo.plateX + 14, y + ph / 2);
          c.textAlign = 'right'; c.font = font(12); c.fillStyle = sel ? '#e8b888' : '#7a6a58'; c.fillText('LV ' + a.level, Lo.plateX + Lo.plateW - 10, y + ph / 2);
        }
      }
      if (n > Lo.visible) {   /* more plates than fit: a lit tick above / below says so */
        c.fillStyle = this._first > 0 ? '#e8a060' : '#3a2e26'; c.fillRect(Lo.plateX + Lo.plateW / 2 - 8, Lo.top - 8, 16, 2);
        c.fillStyle = this._first + Lo.visible < n ? '#e8a060' : '#3a2e26'; c.fillRect(Lo.plateX + Lo.plateW / 2 - 8, Lo.top + Lo.visible * Lo.pitch - 6, 16, 2);
      }
      /* right: the chosen actor's nine offerings. ⛔ v3 labelled them in hard-coded English ("DEFENCE" where the stock
       * database says "Defense", and a Japanese project would read English): the labels are the project's OWN terms
       * (TextManager.level / TextManager.param). ⛔ v3 measured each bar against the party's best x 1.15, so the best
       * stat of every row drew the same 87% and nothing ever filled (independent review 2026-10-09): each bar now runs
       * toward THIS actor's class value at its maximum level (the database's own curve), a scale the footnote states. */
      var act = actors[this._row];
      if (act) {
        var x0 = Lo.x0, x1 = Lo.x1, bx = x0 + 120, bw = Math.max(110, x1 - bx - 130), rowH = Lo.rowH, top99 = classTop(act);
        for (var j = 0; j < 9; j++) {
          var yy = Lo.top + j * rowH, on = j === this._col, mid = yy + rowH / 2 - 4;
          var label = termOf(j), val = j === 0 ? act.level : act.param(j - 1), cap = j === 0 ? Math.max(1, act.maxLevel()) : top99[j - 1];
          var frac = Math.min(1, val / Math.max(1, cap));
          var cost = j === 0 ? levelCost(act) : paramCost(act), can = isFinite(cost) && cost <= carried();
          if (on) { c.fillStyle = 'rgba(232,150,80,0.18)'; c.fillRect(x0 - 8, yy - 4, x1 - x0 + 16, rowH - 2); }
          c.textAlign = 'left'; c.font = font(14); c.fillStyle = on ? '#ffe2b8' : '#a8927a'; c.fillText(label, x0, mid);
          c.fillStyle = '#2a1e18'; c.fillRect(bx, mid - 5, bw, 10);
          c.fillStyle = on ? '#f0a050' : '#9a5a2a'; c.fillRect(bx, mid - 5, Math.max(2, Math.round(bw * frac)), 10);
          c.fillStyle = 'rgba(255,230,190,0.5)'; c.fillRect(bx, mid - 5, Math.max(2, Math.round(bw * frac)), 1);
          c.font = font(15); c.fillStyle = on ? '#ffffff' : '#d8c4a8'; c.fillText(String(val), bx + bw + 12, mid);
          c.textAlign = 'right'; c.font = font(13); c.fillStyle = can ? '#ffb060' : '#5a4a3e';
          if (isFinite(cost)) { c.fillText(String(cost), x1 - 10, mid); coalGlyph(c, x1 - 6, mid - 2, can); } else c.fillText('—', x1, mid);
        }
        c.textAlign = 'right'; c.font = 'italic 12px ' + CFG.displayFont; c.fillStyle = '#6a5a4a';
        c.fillText('bars run to this class at level ' + act.maxLevel(), x1, Lo.listEnd + 6);
        this.drawOffer(c, act);
      }
      /* the heap of what is carried, at the shrine's foot on the right, the count above it (with the same coal glyph) */
      var fb = this._fireBox, hx = Math.min(W - 70, fb[0] + fb[2] + 70);
      this._heapCount = this.drawHeap(c, hx, Lo.bandBot - 2, carried());
      c.textAlign = 'center'; c.font = font(22); c.fillStyle = '#ffd8a8'; c.fillText(String(carried()), hx - 6, this._heapTop - 30);
      coalGlyph(c, hx - 6 + c.measureText(String(carried())).width / 2 + 6, this._heapTop - 32, true);
      c.font = font(12); c.fillStyle = '#9a8670'; c.fillText(currencyLabel(), hx, this._heapTop - 12);
      c.textAlign = 'center'; c.font = 'italic 15px ' + CFG.displayFont; c.fillStyle = '#8a7a68';
      c.fillText('Arrows choose · OK offers · Cancel, or touch the fire, to rise', W / 2, H - 16);
      b._baseTexture.update();
    };
    /**
     * The offer card, under the name plates: what OK would buy now, from what to what, for how much, and what is carried.
     * ⛔ v3 left the left third under the plates empty (about 40% of the frame was background, review 2026-10-09).
     */
    SceneAltar.prototype.drawOffer = function (c, act) {
      var Lo = this._lay, n = $gameParty.members().length, y0 = Lo.top + Math.min(n, Lo.visible) * Lo.pitch + 12, x = Lo.plateX, w = Lo.plateW, h = 112;
      if (y0 + h > Lo.bandBot - 8) return;   /* a tall party on a short screen: the plates need the room */
      var j = this._col, cost = j === 0 ? levelCost(act) : paramCost(act), have = carried();
      var now = j === 0 ? act.level : act.param(j - 1), next = j === 0 ? now + 1 : now + (CFG.paramSteps[j - 1] | 0);
      this._offer = { col: j, now: now, next: next, cost: cost, have: have };   /* what the card states, for a probe to check against a real purchase */
      c.fillStyle = 'rgba(20,12,8,0.55)'; c.fillRect(x, y0, w, h); c.fillStyle = 'rgba(232,176,112,0.35)'; c.fillRect(x, y0, w, 1); c.fillRect(x, y0 + h - 1, w, 1);
      c.textAlign = 'left'; c.font = font(12); c.fillStyle = '#9a8670'; c.fillText('OFFER', x + 12, y0 + 16);
      c.font = font(16); c.fillStyle = '#e8c098'; c.fillText(termOf(j), x + 12, y0 + 38);
      c.font = font(24); c.fillStyle = '#fff0dc'; var s = now + '  →  ' + (isFinite(cost) ? next : now); c.fillText(s, x + 12, y0 + 66);
      c.font = font(14);
      if (!isFinite(cost)) { c.fillStyle = '#7a6a58'; c.fillText(j === 0 && act.isMaxLevel && act.isMaxLevel() ? 'already at the top' : 'not offered', x + 12, y0 + 94); }
      else if (cost <= have) { c.fillStyle = '#ffb060'; c.fillText('for ' + cost, x + 12, y0 + 94); coalGlyph(c, x + 18 + c.measureText('for ' + cost).width, y0 + 92, true); }
      else { c.fillStyle = '#a06a4a'; c.fillText((cost - have) + ' more needed', x + 12, y0 + 94); coalGlyph(c, x + 18 + c.measureText((cost - have) + ' more needed').width, y0 + 92, false); }
    };
    /*
     * ⛔ Scene_MenuBase.createButtons adds MZ's stock touch Cancel button whenever touch UI is on (rmmz_scenes.js:1275),
     * which is MZ's default: a stock Sprite_Button on a scene sold as having no engine chrome (wing §15). The altar makes
     * no stock buttons; touch is read by hit-testing the scene's own drawn layout instead (hitTest).
     */
    SceneAltar.prototype.createButtons = function () {};
    /** what a touch at (x, y) lands on: {row} a name plate, {col} an offering, {rise} the shrine or the footer, or null */
    SceneAltar.prototype.hitTest = function (x, y) {
      var Lo = this._lay, n = $gameParty.members().length;
      for (var i = 0; i < Lo.visible && this._first + i < n; i++) { var py = Lo.top + i * Lo.pitch; if (x >= Lo.plateX && x < Lo.plateX + Lo.plateW && y >= py && y < py + Lo.pitch - 10) return { row: this._first + i }; }
      for (var j = 0; j < 9; j++) { var yy = Lo.top + j * Lo.rowH; if (x >= Lo.x0 - 8 && x < Lo.x1 + 8 && y >= yy - 4 && y < yy + Lo.rowH - 6) return { col: j }; }
      if (y >= Lo.H - 32) return { rise: true };
      var fb = this._fireBox; if (fb && x >= fb[0] && x < fb[0] + fb[2] && y >= fb[1] && y < fb[1] + fb[3]) return { rise: true };
      return null;
    };
    SceneAltar.prototype.update = function () {
      Scene_MenuBase.prototype.update.call(this);
      var Lb = shrineLib(); var f = Math.floor(Graphics.frameCount / 6) % Lb.FRAMES;
      this._fire.setFrame(f * Lb.CELL_W, 0, Lb.CELL_W, Lb.CELL_H);
      if (this._leader && this._leader.bitmap && this._leader.bitmap.isReady() && !this._leader.visible) {
        var kb = this._leader.bitmap, big = ImageManager.isBigCharacter(this._leaderName), pw = kb.width / (big ? 3 : 12), ph = kb.height / (big ? 4 : 8);
        var idx = big ? 0 : this._leaderIdx, Z = this._lay.Z;
        this._leader.setFrame(((idx % 4) * 3 + 1) * pw, (Math.floor(idx / 4) * 4 + 2) * ph, pw, ph);   /* row 2 = facing right, toward the shrine */
        this._leader.x = this._fireBox[0] - 6 - pw * Z; this._leader.y = this._lay.bandBot - ph * Z; this._leader.visible = true;
      }
      var n = $gameParty.members().length; var moved = false;
      if (Input.isRepeated('down')) { this._col = (this._col + 1) % 9; moved = true; }
      if (Input.isRepeated('up')) { this._col = (this._col + 8) % 9; moved = true; }
      if (Input.isRepeated('right') || Input.isTriggered('pagedown')) { this._row = (this._row + 1) % n; moved = true; }
      if (Input.isRepeated('left') || Input.isTriggered('pageup')) { this._row = (this._row + n - 1) % n; moved = true; }
      var offer = Input.isTriggered('ok'); var rise = Input.isTriggered('cancel') || TouchInput.isCancelled();
      if (TouchInput.isTriggered()) {
        /* a touch selects a plate or an offering; touching the offering already chosen offers it (a second tap) */
        var hit = this.hitTest(TouchInput.x, TouchInput.y);
        if (hit && hit.row !== undefined && hit.row !== this._row) { this._row = hit.row; moved = true; }
        else if (hit && hit.col !== undefined) { if (hit.col === this._col) offer = true; else { this._col = hit.col; moved = true; } }
        else if (hit && hit.rise) rise = true;
      }
      if (moved) { SoundManager.playCursor(); this.redraw(); }
      if (offer) {
        var a = $gameParty.members()[this._row];
        if (a && buy(a, this._col === 0 ? 'level' : this._col - 1)) { SoundManager.playUseItem(); this.redraw(); } else SoundManager.playBuzzer();
      }
      if (rise) { SoundManager.playCancel(); this.popScene(); }
    };
    return SceneAltar;
  }

  /* ------------------------------------------------- map sprites (lazily) --- */
  /*
   * ⛔ THE LIGHT IS NOT IN THE TILEMAP. MZ tints the map through a colour filter on Spriteset_Base._baseSprite
   * (rmmz_sprites.js:3204, updateBaseFilters), so a fire drawn inside the tilemap goes DARK with the town at dusk: the
   * first dusk capture (Internal_Ops/Capture/frames/hero, looked at 2026-10-09) showed a dim brazier that lit nothing.
   * Light is drawn in its own layer, a sibling placed right after _baseSprite: it escapes the tone, yet still fades out and
   * flashes with the screen, because brightness and flash live on the spriteset's OVERALL filter (rmmz_sprites.js:3209),
   * and it still shakes and zooms with the map (updatePosition moves the whole spriteset). In daylight (tone 0) the layer
   * paints the same pixels as before. The shrine BODY stays in the tilemap, sorted with the characters.
   */
  var ShrineSprite = null;
  function shrineClass() {
    if (ShrineSprite) return ShrineSprite;
    ShrineSprite = function () { this.initialize.apply(this, arguments); };
    ShrineSprite.prototype = Object.create(Sprite.prototype);
    ShrineSprite.prototype.constructor = ShrineSprite;
    ShrineSprite.prototype.initialize = function (ev) {
      Sprite.prototype.initialize.call(this);
      var L = shrineLib();
      this._ev = ev; this.anchor.x = 0.5; this.anchor.y = 1; this.z = 3;
      this._spec = shrineSpec(ev, $gameMap.mapId(), ev.eventId());
      this._body = new Sprite(); this._body.anchor.x = 0.5; this._body.anchor.y = 1; this.addChild(this._body);
      /* the light: pool on the ground, a glow round the fire, and the flames drawn again above the dusk (see above) */
      this._light = new Sprite();
      /* sizes: the pool lights about two tiles of ground either side, the glow about three tiles round the flame (a bonfire
       * lights a clearing, not a candle's worth: the first light layer at 96 px read as a lamp, looked at 2026-10-09) */
      this._pool = new Sprite(new Bitmap(192, 72)); this._pool.anchor.x = 0.5; this._pool.anchor.y = 0.5; this._pool.blendMode = 1; this._pool.y = -6;
      L.paintLightPool(this._pool.bitmap.context, this._spec, 192, 72); this._pool.bitmap._baseTexture.update();
      /* ⛔ the bitmap holds the WHOLE gradient circle (radius 132 in 272 x 272): a bitmap smaller than the circle cuts the
       * glow into a hard-edged box, the defect the review found on the shrine board's own copy of this glow */
      this._glow = new Sprite(new Bitmap(272, 272)); this._glow.anchor.x = 0.5; this._glow.anchor.y = 0.5; this._glow.blendMode = 1;
      var gc = this._glow.bitmap.context, rgb = hexRgb(L.FIRE[this._spec.fuel][1]), gg = gc.createRadialGradient(136, 136, 2, 136, 136, 132);
      gg.addColorStop(0, 'rgba(' + rgb + ',0.50)'); gg.addColorStop(0.18, 'rgba(' + rgb + ',0.22)'); gg.addColorStop(0.55, 'rgba(' + rgb + ',0.06)'); gg.addColorStop(1, 'rgba(' + rgb + ',0)');
      gc.fillStyle = gg; gc.fillRect(0, 0, 272, 272); this._glow.bitmap._baseTexture.update();
      this._flame = new Sprite(); this._flame.anchor.x = 0.5; this._flame.anchor.y = 1;
      this._light.addChild(this._pool); this._light.addChild(this._glow); this._light.addChild(this._flame);
      this.repaint();
    };
    ShrineSprite.prototype.isLit = function () { return CFG.shrinesStartLit || !!state().kindled[$gameMap.mapId() + ',' + this._ev.eventId()]; };
    /** paint the 6-frame strips ONCE (and again only when the shrine is kindled) - nothing is redrawn per frame */
    ShrineSprite.prototype.repaint = function () {
      var L = shrineLib(); this._lit = this.isLit();
      var b = new Bitmap(L.CELL_W * L.FRAMES, L.CELL_H); var info = L.paintStrip(b.context, this._spec, this._lit); b._baseTexture.update();
      var fl = new Bitmap(L.CELL_W * L.FRAMES, L.CELL_H), c = fl.context;   /* the flames alone (banked: the coals alone), same cells */
      for (var f = 0; f < L.FRAMES; f++) { c.save(); c.translate(f * L.CELL_W, 0); c.beginPath(); c.rect(0, 0, L.CELL_W, L.CELL_H); c.clip(); L.paintFire(c, this._spec, info.fire, f / L.FRAMES, this._lit); c.restore(); }
      fl._baseTexture.update();
      this._body.bitmap = b; this._flame.bitmap = fl; this._pool.visible = this._lit; this._glow.visible = this._lit;
      this._glow.x = info.fire.fx - L.CELL_W / 2; this._glow.y = info.fire.fy - L.CELL_H - 8;
    };
    ShrineSprite.prototype.update = function () {
      Sprite.prototype.update.call(this);
      var L = shrineLib(); var f = Math.floor(Graphics.frameCount / 6) % L.FRAMES; var t = Graphics.frameCount;
      if (this._lit !== this.isLit()) this.repaint();
      this._body.setFrame(f * L.CELL_W, 0, L.CELL_W, L.CELL_H); this._flame.setFrame(f * L.CELL_W, 0, L.CELL_W, L.CELL_H);
      /* a fire does not outshine daylight: the glow and the pool scale with how DARK the screen tone is (no tint = a soft
       * warmth; a night tint = the full light). ⛔ v1 drew the night strength by day and bloomed a pale blob on bright
       * cobbles (plate_light.png, looked at 2026-10-09). tone() returns the screen's own array: nothing is allocated. */
      var tn = $gameScreen.tone(), dark = Math.min(1, Math.max(0, -(tn[0] + tn[1] + tn[2]) / 300));
      this._pool.alpha = (0.75 + Math.sin(t * 0.21) * 0.12 + Math.sin(t * 0.057) * 0.08) * (0.45 + 0.55 * dark);
      this._glow.alpha = (0.80 + Math.sin(t * 0.17 + 1.3) * 0.10 + Math.sin(t * 0.043) * 0.07) * (0.25 + 0.75 * dark);
      this.x = this._ev.screenX(); this.y = this._ev.screenY() + 4;
      this._light.x = this.x; this._light.y = this.y; this._light.visible = this.visible;
    };
    return ShrineSprite;
  }

  /** the untoned light layer (above), made once per spriteset, right after the toned base sprite */
  function lightsOf(ss) {
    if (!ss._csafVigilLights) { ss._csafVigilLights = new Sprite(); ss.addChildAt(ss._csafVigilLights, Math.max(0, ss.children.indexOf(ss._baseSprite)) + 1); }
    return ss._csafVigilLights;
  }
  /** take the echo (and its halo in the light layer) off the map */
  function dropEcho(ss) {
    if (!ss._csafVigilEcho) return;
    ss._tilemap.removeChild(ss._csafVigilEcho);
    if (ss._csafVigilEcho._halo && ss._csafVigilLights) ss._csafVigilLights.removeChild(ss._csafVigilEcho._halo);
    ss._csafVigilEcho = null;
  }
  var _SM_createCharacters = Spriteset_Map.prototype.createCharacters;
  Spriteset_Map.prototype.createCharacters = function () {
    _SM_createCharacters.apply(this, arguments);
    var lights = lightsOf(this);
    this._csafVigilShrines = [];
    var evs = $gameMap.events();
    for (var i = 0; i < evs.length; i++) if (tagOf(evs[i]) === 'shrine') { var s = new (shrineClass())(evs[i]); this._csafVigilShrines.push(s); this._tilemap.addChild(s); lights.addChild(s._light); }
    this._csafVigilEcho = null; this.refreshVigilEcho();
  };
  Spriteset_Map.prototype.refreshVigilEcho = function () {
    var e = state().echo;
    if (this._csafVigilEcho && (!e || e.mapId !== $gameMap.mapId())) dropEcho(this);
    if (e && e.mapId === $gameMap.mapId() && !this._csafVigilEcho) {
      var E = echoLib().echoClass(); this._csafVigilEcho = new E(e); this._csafVigilEcho._range = CFG.echoRange; this._tilemap.addChild(this._csafVigilEcho);
      if (this._csafVigilEcho._halo) lightsOf(this).addChild(this._csafVigilEcho._halo);
    }
  };
  /**
   * The reclaim, made visible: embers burst from the place of the fall and the amount rises over it in the display face,
   * in the light layer so it reads at night. ⛔ v1 only removed the ghost, so the payoff of the whole loop was invisible
   * (independent review 2026-10-09: "no pickup flash, no amount"). Built once, at the reclaim (an event, not a frame);
   * Spriteset_Map.update moves it and removes it after 72 frames.
   */
  Spriteset_Map.prototype.csafVigilBurst = function (x, y, amount) {
    var lights = lightsOf(this), fx = new Sprite(), r = shrineLib().rng(((x * 73856093) ^ (y * 19349663) ^ (amount | 0)) >>> 0);
    fx._mx = x; fx._my = y; fx._t = 0; fx._parts = []; fx._amount = amount | 0;
    var eb = new Bitmap(3, 3); eb.fillRect(0, 0, 3, 3, '#ffb860'); eb.fillRect(1, 1, 1, 1, '#fff6d8');
    for (var i = 0; i < 18; i++) { var s = new Sprite(eb); s.blendMode = 1; s.anchor.x = 0.5; s.anchor.y = 0.5; s._vx = (r() - 0.5) * 2.6; s._vy = -1.0 - r() * 2.4; fx._parts.push(s); fx.addChild(s); }
    var tb = new Bitmap(240, 44), tc = tb.context, txt = '+' + (amount | 0) + '  ' + currencyLabel();
    tc.textAlign = 'center'; tc.textBaseline = 'middle'; tc.font = font(24);
    tc.fillStyle = 'rgba(24,10,4,0.92)'; tc.fillText(txt, 121, 24); tc.fillStyle = '#ffd8a8'; tc.fillText(txt, 120, 22); tb._baseTexture.update();
    fx._label = new Sprite(tb); fx._label.anchor.x = 0.5; fx._label.anchor.y = 1; fx._label.alpha = 0; fx.addChild(fx._label);
    lights.addChild(fx); (this._csafVigilFx = this._csafVigilFx || []).push(fx);
    return fx;
  };
  var _SMap_update = Spriteset_Map.prototype.update;
  Spriteset_Map.prototype.update = function () {
    _SMap_update.apply(this, arguments);
    var e = state().echo; var here = !!(e && e.mapId === $gameMap.mapId());
    if (here && $gamePlayer.x === e.x && $gamePlayer.y === e.y && !$gamePlayer.isMoving()) { var ex = e.x, ey = e.y, got = reclaim(); this.csafVigilBurst(ex, ey, got); e = null; here = false; }
    if (this._csafVigilEcho && (!here || this._csafVigilEcho._echo !== e)) dropEcho(this);
    if (here && !this._csafVigilEcho) this.refreshVigilEcho();
    var fxs = this._csafVigilFx;
    if (fxs && fxs.length) {
      var tw = $gameMap.tileWidth(), th = $gameMap.tileHeight();
      for (var k = fxs.length - 1; k >= 0; k--) {
        var f = fxs[k], t = ++f._t;
        f.x = Math.round($gameMap.adjustX(f._mx) * tw + tw / 2); f.y = Math.round($gameMap.adjustY(f._my) * th + th - 20);
        for (var q = 0; q < f._parts.length; q++) { var s = f._parts[q]; s.x = s._vx * t; s.y = s._vy * t + 0.035 * t * t; s.alpha = Math.max(0, 1 - t / 48); }
        f._label.y = -14 - t * 0.55; f._label.alpha = t < 46 ? Math.min(1, t / 6) : Math.max(0, 1 - (t - 46) / 26);
        if (t >= 72) { if (f.parent) f.parent.removeChild(f); fxs.splice(k, 1); }
      }
    }
  };

  /* ------------------------------------------------------------ commands --- */
  PluginManager.registerCommand(PLUGIN, 'rest', function () { var ev = $gameMap.event(this._eventId); if (ev) rest(ev); });
  PluginManager.registerCommand(PLUGIN, 'openAltar', function () { SceneManager.push(buildAltar()); });
  PluginManager.registerCommand(PLUGIN, 'giveCurrency', function (a) { var n = Number(a.amount); if (isFinite(n)) setCarried(carried() + n); });
  PluginManager.registerCommand(PLUGIN, 'clearEcho', function () { var s = state(); if (s.echo) { s.lost += s.echo.amount | 0; s.echo = null; } });

  CSAF.Vigil = {
    version: '1.0.0', SCHEMA: SCHEMA, CFG: CFG,
    state: state, carried: carried, setCarried: setCarried, tagOf: tagOf, respawnRule: respawnRule,
    rest: rest, raiseFallen: raiseFallen, fall: fall, reclaim: reclaim, stepRing: stepRing,
    levelCost: levelCost, paramCost: paramCost, buy: buy, currencyLabel: currencyLabel, shrineSpec: shrineSpec, termOf: termOf, classTop: classTop,
    Scene_Death: buildDeath, Scene_Altar: buildAltar, ShrineSprite: shrineClass
  };
})();
