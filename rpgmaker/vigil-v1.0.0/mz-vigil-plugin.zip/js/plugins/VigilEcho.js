//=============================================================================
// VigilEcho.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Vigil [2/3] — the echo. Remembers the party leader's last steps and, where they fell, raises a ghost of that leader that replays the fall. v1.0.0
 * @author CSAF — Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * VigilEcho — part 2 of 3. Install all three; any Plugin Manager order works.
 * ============================================================================
 *
 * No parameters or commands here; Vigil.js owns them. This file holds:
 *
 *   - the STEP RING: the leader's last steps, kept in fixed typed arrays so
 *     walking allocates nothing;
 *   - the ECHO SPRITE: a ghost of YOUR leader, struck from your own walking
 *     sheet (desaturated, cooled, translucent, with a rim of light and a
 *     trail of embers), that walks the recorded steps up to the place it fell.
 *
 * Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.
 */

(function () {
  'use strict';

  var root = (typeof window !== 'undefined') ? window : globalThis;
  var CSAF = root.CSAF = root.CSAF || {};

  /* ----------------------------------------------------------- step ring --- */
  /**
   * A fixed-capacity ring of steps (map id, x, y, direction). push() allocates nothing (wing §3: zero allocation in hot
   * paths); tail() copies the newest run on ONE map into plain arrays, which is the only allocating call and happens once,
   * at death.
   * @param {number} capacity
   */
  function StepRing(capacity) {
    this.cap = Math.max(2, capacity | 0);
    this.map = new Int16Array(this.cap); this.x = new Int16Array(this.cap); this.y = new Int16Array(this.cap); this.d = new Int8Array(this.cap);
    this.head = 0; this.count = 0;
  }
  /** record one step */
  StepRing.prototype.push = function (mapId, x, y, d) {
    this.map[this.head] = mapId; this.x[this.head] = x; this.y[this.head] = y; this.d[this.head] = d;
    this.head = (this.head + 1) % this.cap; if (this.count < this.cap) this.count++;
  };
  StepRing.prototype.clear = function () { this.head = 0; this.count = 0; };
  /**
   * The newest consecutive steps taken on `mapId`, oldest first, at most `n`; plain [[x,y,d], ...] for the save file.
   * A step on another map ends the run (an echo never walks through a map transfer).
   */
  StepRing.prototype.tail = function (mapId, n) {
    var out = [];
    for (var k = 0; k < Math.min(n, this.count); k++) {
      var i = (this.head - 1 - k + this.cap * 2) % this.cap;
      if (this.map[i] !== mapId) break;
      out.push([this.x[i], this.y[i], this.d[i]]);
    }
    return out.reverse();
  };

  /* ------------------------------------------------------ the replay path --- */
  /**
   * Where the ghost stands at replay frame `f`: it walks the recorded steps (16 frames a tile, MZ's speed 4), arrives at
   * the death tile, holds there for `hold` frames, then the cycle restarts. Pure function of (steps, f) so the in-engine
   * sprite and the Node suite compute the same thing (wing §11: two paths that must agree, agree by construction).
   * @param {Array<Array<number>>} steps  [[x,y,d], ...] oldest first, the last entry being the death tile
   * @param {number} f  frame counter since the replay began
   * @param {number} [hold]
   * @returns {{x:number, y:number, d:number, walking:boolean}} x/y in TILES (fractional while walking)
   */
  function replayAt(steps, f, hold, out) {
    /* `out` is reused by the sprite every frame (wing §3: no allocation per frame); the Node suite may omit it */
    out = out || { x: 0, y: 0, d: 2, walking: false };
    hold = hold == null ? 60 : hold;
    if (!steps || !steps.length) { out.x = 0; out.y = 0; out.d = 2; out.walking = false; return out; }
    var walkFrames = (steps.length - 1) * 16;
    var cycle = walkFrames + hold;
    var t = ((f % cycle) + cycle) % cycle;
    if (t >= walkFrames) { var last = steps[steps.length - 1]; out.x = last[0]; out.y = last[1]; out.d = last[2] || 2; out.walking = false; return out; }
    var i = Math.floor(t / 16); var u = (t % 16) / 16;
    var a = steps[i]; var b = steps[i + 1];
    out.x = a[0] + (b[0] - a[0]) * u; out.y = a[1] + (b[1] - a[1]) * u; out.d = b[2] || a[2] || 2; out.walking = true;
    return out;
  }
  var WALK = [0, 1, 2, 1];

  /* ------------------------------------------------------------ the ghost --- */
  /**
   * The colour matrix that turns a walking sheet into its echo: luminance only, then pushed toward a cold blue-grey and
   * lifted, so a dark costume still reads at night. A matrix, not a tint: a tint multiplies, and a black cloak times blue
   * is still black.
   */
  var GHOST_MATRIX = [
    0.20, 0.55, 0.10, 0, 0.06,
    0.22, 0.60, 0.12, 0, 0.10,
    0.26, 0.66, 0.16, 0, 0.20,
    0, 0, 0, 1, 0
  ];

  var EchoSprite = null;
  /** build the sprite class at first use, after the engine exists (wing §8 trap 2: load order is the buyer's choice) */
  function echoClass() {
    if (EchoSprite) return EchoSprite;
    EchoSprite = function () { this.initialize.apply(this, arguments); };
    EchoSprite.prototype = Object.create(Sprite.prototype);
    EchoSprite.prototype.constructor = EchoSprite;
    /**
     * @param {{mapId:number,x:number,y:number,d:number,steps:Array,charName:string,charIndex:number}} echo
     */
    EchoSprite.prototype.initialize = function (echo) {
      Sprite.prototype.initialize.call(this);
      this._echo = echo; this._f = 0; this._replaying = false; this._at = { x: 0, y: 0, d: 2, walking: false }; this._rect = [0, 0, 0, 0];
      this.anchor.x = 0.5; this.anchor.y = 1; this.z = 3;
      this._body = new Sprite(); this._body.anchor.x = 0.5; this._body.anchor.y = 1;
      this._rim = new Sprite(); this._rim.anchor.x = 0.5; this._rim.anchor.y = 1;
      this._body.bitmap = ImageManager.loadCharacter(echo.charName || '');
      this._rim.bitmap = this._body.bitmap;
      if (typeof PIXI !== 'undefined' && PIXI.filters && PIXI.filters.ColorMatrixFilter) {
        var cm = new PIXI.filters.ColorMatrixFilter(); cm.matrix = GHOST_MATRIX.slice(); this._body.filters = [cm];
        var rim = new PIXI.filters.ColorMatrixFilter(); rim.matrix = [0, 0, 0, 0, 0.55, 0, 0, 0, 0, 0.75, 0, 0, 0, 0, 0.95, 0, 0, 0, 1, 0]; this._rim.filters = [rim];
      }
      this._rim.blendMode = 1; this._rim.alpha = 0.28; this._rim.scale.x = 1.08; this._rim.scale.y = 1.04;   /* an additive halo one size up */
      this._body.alpha = 0.62;
      this.addChild(this._rim); this.addChild(this._body);
      /* ⛔ the HALO and the embers are light, so Vigil.js puts `_halo` in the map's untoned light layer (a body in the
       * tilemap goes dark with a dusk tint and the ghost stopped reading at night, looked at 2026-10-09). The body and rim
       * stay here, depth-sorted with the characters. A sprite that is never added anywhere (a plugin that only uses
       * this file) simply shows no halo. */
      this._halo = new Sprite();
      var hb = new Bitmap(72, 96), hc = hb.context, hg = hc.createRadialGradient(36, 58, 2, 36, 58, 40);
      hg.addColorStop(0, 'rgba(150,190,255,0.42)'); hg.addColorStop(0.5, 'rgba(110,150,230,0.14)'); hg.addColorStop(1, 'rgba(90,120,210,0)');
      hc.fillStyle = hg; hc.fillRect(0, 0, 72, 96); hb._baseTexture.update();
      this._haloGlow = new Sprite(hb); this._haloGlow.anchor.x = 0.5; this._haloGlow.anchor.y = 1; this._haloGlow.blendMode = 1; this._halo.addChild(this._haloGlow);
      this._embers = [];
      var eb = new Bitmap(2, 2); eb.fillRect(0, 0, 2, 2, '#ffb060');
      for (var i = 0; i < 10; i++) { var s = new Sprite(eb); s.blendMode = 1; s.anchor.x = 0.5; s.anchor.y = 0.5; this._embers.push(s); this._halo.addChild(s); }
    };
    EchoSprite.prototype.frameRect = function (d, pattern) {
      var b = this._body.bitmap; if (!b || !b.isReady()) return null;
      var big = ImageManager.isBigCharacter(this._echo.charName || '');
      var pw = b.width / (big ? 3 : 12); var ph = b.height / (big ? 4 : 8);
      var idx = big ? 0 : (this._echo.charIndex | 0);
      var bx = (idx % 4) * 3; var by = Math.floor(idx / 4) * 4;
      var row = (d - 2) / 2; var r = this._rect;
      r[0] = (bx + pattern) * pw; r[1] = (by + row) * ph; r[2] = pw; r[3] = ph;
      return r;
    };
    EchoSprite.prototype.update = function () {
      Sprite.prototype.update.call(this);
      var e = this._echo; this._f++;
      var near = $gamePlayer && Math.abs($gamePlayer.x - e.x) + Math.abs($gamePlayer.y - e.y) <= (this._range || 3);
      if (near && !this._replaying) { this._replaying = true; this._rf = 0; }
      var at = this._at;
      if (this._replaying) replayAt(e.steps, this._rf++, 50, at); else { at.x = e.x; at.y = e.y; at.d = e.d || 2; at.walking = false; }
      var pattern = at.walking ? WALK[Math.floor(this._f / 12) % 4] : 1;
      var r = this.frameRect(at.d, pattern);
      if (r) { this._body.setFrame(r[0], r[1], r[2], r[3]); this._rim.setFrame(r[0], r[1], r[2], r[3]); }
      var tw = $gameMap.tileWidth(); var th = $gameMap.tileHeight();
      this.x = Math.round($gameMap.adjustX(at.x) * tw + tw / 2);
      this.y = Math.round($gameMap.adjustY(at.y) * th + th);
      var breathe = 0.56 + Math.sin(this._f * 0.05) * 0.08; this._body.alpha = breathe;
      this._halo.x = this.x; this._halo.y = this.y; this._halo.visible = this.visible; this._haloGlow.alpha = 0.7 + Math.sin(this._f * 0.05) * 0.2;
      for (var i = 0; i < this._embers.length; i++) {           /* embers shed upward, phase-offset, from the ghost's body */
        var p = ((this._f + i * 13) % 90) / 90; var s = this._embers[i];
        s.x = Math.sin((i * 1.7 + p * 4)) * 8; s.y = -10 - p * 40; s.alpha = (1 - p) * 0.9;
      }
    };
    return EchoSprite;
  }

  CSAF.VigilEcho = { version: '1.0.0', StepRing: StepRing, replayAt: replayAt, GHOST_MATRIX: GHOST_MATRIX, echoClass: echoClass };
})();
