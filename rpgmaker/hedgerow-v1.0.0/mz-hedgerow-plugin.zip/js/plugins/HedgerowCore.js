//=============================================================================
// HedgerowCore.js — Hedgerow [1/3]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Hedgerow [1/3] — the animals, the habitat reader and the behaviour. No settings here; see Hedgerow.js. v1.0.0
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help HedgerowCore.js
 *
 * Part 1 of 3. Load all three: HedgerowCore.js, HedgerowPaint.js and
 * Hedgerow.js. Any order works. This file touches nothing in RPG Maker;
 * every setting lives on Hedgerow.js.
 */

'use strict';

if (typeof globalThis.CSAF === 'undefined') globalThis.CSAF = {};

(function () {
  /* ------------------------------------------------------------ families --*/
  /**
   * The thirteen families. A family decides the BODY PLAN, the HABITAT, the GAIT and the FLIGHT; a look decides
   * coat colour and pattern. `view` is how the painter draws it: 'quad' = four facings like a stock character,
   * 'dorsal' = seen from above and rotated to its heading, 'front' = always front-on (a crab), 'side2' = left
   * and right only (a snail), 'hang' = on a thread from the wall above (a spider).
   * `per` = one animal per that many habitat tiles in view; `cap` = the most at once; `walk`/`run` in px/frame.
   */
  var FAMILIES = {
    rabbit: { view: 'quad', habitat: 'ground', phases: ['day', 'dusk'], per: 34, cap: 4, walk: 0.55, run: 3.4, flee: 'bolt' },
    hare: { view: 'quad', habitat: 'ground', phases: ['day', 'dusk'], per: 80, cap: 2, walk: 0.6, run: 4.6, flee: 'dash' },
    squirrel: { view: 'quad', habitat: 'treefoot', phases: ['day'], per: 3, cap: 3, walk: 0.8, run: 3.4, flee: 'climb' },
    hedgehog: { view: 'quad', habitat: 'ground', phases: ['dusk', 'night'], per: 60, cap: 2, walk: 0.3, run: 0, flee: 'curl' },
    mouse: { view: 'quad', habitat: 'wallfoot', phases: ['day', 'dusk', 'night'], per: 5, cap: 4, walk: 0.7, run: 3.6, flee: 'hole' },
    rat: { view: 'quad', habitat: 'wallfoot', phases: ['dusk', 'night'], per: 7, cap: 3, walk: 0.7, run: 3.2, flee: 'hole' },
    lizard: { view: 'dorsal', habitat: 'rock', phases: ['day'], per: 3, cap: 3, walk: 0.5, run: 4.4, flee: 'dart' },
    crab: { view: 'front', habitat: 'sand', phases: ['day', 'dusk'], per: 4, cap: 5, walk: 0.35, run: 1.4, flee: 'dig' },
    snail: { view: 'side2', habitat: 'ground', phases: ['dusk', 'night'], per: 40, cap: 3, walk: 0.05, run: 0, flee: 'shell', rain: true },
    cat: { view: 'quad', habitat: 'ground', phases: ['day', 'dusk', 'night'], per: 110, cap: 2, walk: 0.45, run: 1.1, flee: 'stalk' },
    fox: { view: 'quad', habitat: 'ground', phases: ['dusk', 'night'], per: 150, cap: 1, walk: 0.75, run: 3.0, flee: 'trot' },
    badger: { view: 'quad', habitat: 'ground', phases: ['night'], per: 150, cap: 1, walk: 0.5, run: 2.2, flee: 'trot' },
    spider: { view: 'hang', habitat: 'wallfoot', phases: ['day', 'dusk', 'night'], per: 10, cap: 2, walk: 0, run: 1.6, flee: 'reel' }
  };
  var FAMILY_ORDER = ['rabbit', 'hare', 'squirrel', 'hedgehog', 'mouse', 'rat', 'lizard', 'crab', 'snail', 'cat', 'fox', 'badger', 'spider'];

  /** Which families a biome carries. A family also needs ITS habitat in the map to appear at all. */
  var BIOMES = {
    meadow: ['rabbit', 'hare', 'squirrel', 'hedgehog', 'mouse', 'lizard', 'crab', 'snail', 'fox', 'badger'],
    forest: ['rabbit', 'squirrel', 'hedgehog', 'mouse', 'lizard', 'snail', 'fox', 'badger'],
    town: ['cat', 'mouse', 'rat', 'hedgehog', 'squirrel', 'snail', 'lizard', 'crab'],
    coast: ['crab', 'lizard', 'rabbit', 'cat'],
    desert: ['lizard', 'hare'],
    snow: ['hare', 'rabbit', 'fox', 'squirrel'],
    house: ['mouse', 'cat', 'spider'],
    cellar: ['rat', 'mouse', 'spider'],
    none: []
  };

  /* --------------------------------------------------------------- looks --*/
  /**
   * The built-in looks (coats). Colours are `#rrggbb` strings (checked by the suite). `c1` = coat, `c2` = second
   * colour (belly, mask, bands, shell), `c3` = accent (ear tips, tail tip, eyes of a white coat, claws).
   * `pattern` is read by HedgerowPaint; every value is drawn (suite: axis reads). `size` scales the family plan.
   * `biomes` narrows a look inside its family (empty = every biome the family is in).
   */
  var LOOKS = [
    /* rabbits — long upright ears, round body, the white scut */
    { id: 'wild-rabbit', name: 'Wild Rabbit', family: 'rabbit', size: 1, pattern: 'agouti', c1: '#8b6a4a', c2: '#e6dccb', c3: '#3a2a1e', biomes: [] },
    { id: 'grey-rabbit', name: 'Grey Rabbit', family: 'rabbit', size: 1, pattern: 'agouti', c1: '#8e8a84', c2: '#e8e6e0', c3: '#3c3a38', biomes: [] },
    { id: 'sandy-rabbit', name: 'Sandy Rabbit', family: 'rabbit', size: 0.95, pattern: 'plain', c1: '#c49a64', c2: '#f0e4cc', c3: '#6a4a2a', biomes: ['meadow', 'coast', 'town'] },
    { id: 'black-rabbit', name: 'Black Rabbit', family: 'rabbit', size: 1, pattern: 'plain', c1: '#2f2a28', c2: '#4a4442', c3: '#1a1614', biomes: [] },
    { id: 'snow-rabbit', name: 'Snow Rabbit', family: 'rabbit', size: 1, pattern: 'plain', c1: '#efebe3', c2: '#ffffff', c3: '#b0384a', biomes: ['snow', 'town'] },

    /* hares — longer legs, black-tipped ears */
    { id: 'brown-hare', name: 'Brown Hare', family: 'hare', size: 1, pattern: 'agouti', c1: '#9c7448', c2: '#e8dcc4', c3: '#16120e', biomes: ['meadow'] },
    { id: 'mountain-hare', name: 'Mountain Hare', family: 'hare', size: 1, pattern: 'plain', c1: '#eef0f2', c2: '#ffffff', c3: '#16120e', biomes: ['snow'] },
    { id: 'desert-hare', name: 'Desert Hare', family: 'hare', size: 0.92, pattern: 'agouti', c1: '#bc9a6c', c2: '#efe4cc', c3: '#2a1e14', biomes: ['desert', 'meadow'] },

    /* squirrels — the S-curve tail */
    { id: 'red-squirrel', name: 'Red Squirrel', family: 'squirrel', size: 1, pattern: 'plain', c1: '#b5532a', c2: '#f0e2cc', c3: '#7a3418', biomes: [] },
    { id: 'grey-squirrel', name: 'Grey Squirrel', family: 'squirrel', size: 1.05, pattern: 'agouti', c1: '#8c8782', c2: '#f2eee8', c3: '#a9764e', biomes: [] },
    { id: 'black-squirrel', name: 'Black Squirrel', family: 'squirrel', size: 1.05, pattern: 'plain', c1: '#2c2826', c2: '#3e3836', c3: '#5a4a3e', biomes: [] },

    /* hedgehogs — the spine fringe */
    { id: 'hedgehog', name: 'Hedgehog', family: 'hedgehog', size: 1, pattern: 'spines', c1: '#6e5640', c2: '#d9c6a4', c3: '#2a1e16', biomes: [] },
    { id: 'blond-hedgehog', name: 'Blond Hedgehog', family: 'hedgehog', size: 0.95, pattern: 'spines', c1: '#c9b490', c2: '#f2e8d8', c3: '#5a4632', biomes: [] },

    /* mice — a dot with a tail at speed */
    { id: 'wood-mouse', name: 'Wood Mouse', family: 'mouse', size: 1, pattern: 'belly', c1: '#8a6440', c2: '#ece2d0', c3: '#d89a8a', biomes: [] },
    { id: 'house-mouse', name: 'House Mouse', family: 'mouse', size: 0.95, pattern: 'plain', c1: '#8a8478', c2: '#a8a294', c3: '#d89a8a', biomes: [] },
    { id: 'harvest-mouse', name: 'Harvest Mouse', family: 'mouse', size: 0.85, pattern: 'belly', c1: '#c47a3a', c2: '#f4ead6', c3: '#d89a8a', biomes: ['meadow', 'forest'] },
    { id: 'white-mouse', name: 'White Mouse', family: 'mouse', size: 0.95, pattern: 'plain', c1: '#efebe4', c2: '#ffffff', c3: '#e08a96', biomes: ['house', 'town', 'cellar'] },

    /* rats — bigger, the long naked tail */
    { id: 'brown-rat', name: 'Brown Rat', family: 'rat', size: 1, pattern: 'belly', c1: '#6a5440', c2: '#b8a890', c3: '#c88c84', biomes: [] },
    { id: 'black-rat', name: 'Black Rat', family: 'rat', size: 0.95, pattern: 'plain', c1: '#2e2a2a', c2: '#46403e', c3: '#b47c78', biomes: [] },

    /* lizards — seen from above, the side-to-side run */
    { id: 'green-lizard', name: 'Green Lizard', family: 'lizard', size: 1, pattern: 'speckle', c1: '#5a8a3a', c2: '#2e4a1e', c3: '#c8d86a', biomes: ['meadow', 'forest', 'town'] },
    { id: 'wall-lizard', name: 'Wall Lizard', family: 'lizard', size: 0.9, pattern: 'net', c1: '#7a6a52', c2: '#3a3026', c3: '#c8b894', biomes: ['town', 'coast', 'meadow'] },
    { id: 'sand-gecko', name: 'Sand Gecko', family: 'lizard', size: 0.85, pattern: 'spots', c1: '#c8a874', c2: '#8a6a44', c3: '#f2e4c4', biomes: ['desert', 'coast'] },
    { id: 'blue-tailed-skink', name: 'Blue-tailed Skink', family: 'lizard', size: 0.9, pattern: 'stripes', c1: '#3a3228', c2: '#d8c89a', c3: '#3a8ae0', biomes: [] },

    /* crabs — front-on, claws */
    { id: 'shore-crab', name: 'Shore Crab', family: 'crab', size: 1, pattern: 'plain', c1: '#b8462a', c2: '#e8a070', c3: '#2a1a14', biomes: [] },
    { id: 'blue-crab', name: 'Blue Crab', family: 'crab', size: 1.05, pattern: 'plain', c1: '#3a6a9a', c2: '#d86a4a', c3: '#1a2230', biomes: [] },
    { id: 'ghost-crab', name: 'Ghost Crab', family: 'crab', size: 0.9, pattern: 'pale', c1: '#d8c8a0', c2: '#f4ecd8', c3: '#2a2218', biomes: [] },
    { id: 'hermit-crab', name: 'Hermit Crab', family: 'crab', size: 0.9, pattern: 'shell', c1: '#d0603a', c2: '#e8d4b0', c3: '#8a5a3a', biomes: ['coast', 'town'] },

    /* snails — side-on, the shell */
    { id: 'garden-snail', name: 'Garden Snail', family: 'snail', size: 1, pattern: 'spiral', c1: '#8a5a2a', c2: '#c8a070', c3: '#8a8070', biomes: [] },
    { id: 'banded-snail', name: 'Banded Snail', family: 'snail', size: 0.9, pattern: 'bands', c1: '#e0c84a', c2: '#4a2e1a', c3: '#a09884', biomes: [] },
    { id: 'pink-snail', name: 'White-lipped Snail', family: 'snail', size: 0.9, pattern: 'bands', c1: '#e09a86', c2: '#7a3a2a', c3: '#9a8a7c', biomes: [] },

    /* cats — ears, the long tail, the doze */
    { id: 'ginger-cat', name: 'Ginger Cat', family: 'cat', size: 1, pattern: 'tabby', c1: '#d27a2c', c2: '#a8521a', c3: '#f4e6d0', biomes: [] },
    { id: 'grey-tabby', name: 'Grey Tabby', family: 'cat', size: 1, pattern: 'tabby', c1: '#8e8a84', c2: '#4a4644', c3: '#ece8e0', biomes: [] },
    { id: 'black-cat', name: 'Black Cat', family: 'cat', size: 1, pattern: 'plain', c1: '#24201f', c2: '#3a3432', c3: '#d8c040', biomes: [] },
    { id: 'calico-cat', name: 'Calico Cat', family: 'cat', size: 0.95, pattern: 'calico', c1: '#f2ece2', c2: '#d27a2c', c3: '#2a2422', biomes: [] },
    { id: 'white-cat', name: 'White Cat', family: 'cat', size: 0.95, pattern: 'plain', c1: '#f0ece4', c2: '#ffffff', c3: '#6aa8d8', biomes: [] },
    { id: 'tuxedo-cat', name: 'Tuxedo Cat', family: 'cat', size: 1, pattern: 'tuxedo', c1: '#22201f', c2: '#f4f0e8', c3: '#c8d050', biomes: [] },
    { id: 'tortoiseshell', name: 'Tortoiseshell', family: 'cat', size: 0.95, pattern: 'tortie', c1: '#3a2a22', c2: '#c0682a', c3: '#e8b040', biomes: [] },

    /* foxes — the brush with its tip */
    { id: 'red-fox', name: 'Red Fox', family: 'fox', size: 1, pattern: 'fox', c1: '#c45a24', c2: '#f4ece0', c3: '#24180f', biomes: ['meadow', 'forest', 'snow'] },
    { id: 'grey-fox', name: 'Grey Fox', family: 'fox', size: 0.95, pattern: 'fox', c1: '#8a8078', c2: '#efe8de', c3: '#2a2220', biomes: ['meadow', 'forest'] },
    { id: 'arctic-fox', name: 'Arctic Fox', family: 'fox', size: 0.9, pattern: 'plain', c1: '#f2f2f0', c2: '#ffffff', c3: '#2a2626', biomes: ['snow'] },

    /* badgers — the striped face */
    { id: 'badger', name: 'Badger', family: 'badger', size: 1, pattern: 'badger', c1: '#7e7a76', c2: '#f2f0ea', c3: '#1a1818', biomes: [] },
    { id: 'american-badger', name: 'American Badger', family: 'badger', size: 0.95, pattern: 'badger', c1: '#8a7458', c2: '#f0e8d8', c3: '#24201a', biomes: ['meadow', 'desert'] },

    /* spiders — a body on a thread */
    { id: 'house-spider', name: 'House Spider', family: 'spider', size: 1, pattern: 'plain', c1: '#4a3a2a', c2: '#6a5640', c3: '#1a140e', biomes: [] },
    { id: 'garden-spider', name: 'Garden Spider', family: 'spider', size: 1.1, pattern: 'cross', c1: '#8a5a2a', c2: '#f2e8d0', c3: '#2a1a10', biomes: [] }
  ];

  /* --------------------------------------------------------- stock tiles --*/
  /**
   * MZ's own stock tiles that ARE a habitat, by sheet file name and tile index (0-255 on that sheet; A2 entries
   * are autotile KINDS, as Tilemap.getAutotileKind returns them). DERIVED from the engine's own tile names
   * (img/tilesets/<sheet>.txt, one name per line, line N = index N-1): every "Tree", "Large Tree", "Conifer",
   * "Dead Tree" and "Palm Tree" cell; every "Boulder", "Rocks" and "Tall Rock" cell; the "Sand", "Grass (Sand)"
   * and "Road (Sand)" ground kinds; every "Fireplace". Indices only: no art ships with this plugin. Any other
   * sheet is marked by the buyer with a terrain tag (parameters, or `<Hedgerow tags: ...>` in the tileset note).
   */
  var STOCK = {
    tree: {
      Outside_B: [157, 158, 165, 176, 177, 178, 179, 184, 185, 186, 187, 192, 193, 194, 195, 200, 201, 202, 203, 221, 222, 229, 232, 233, 236, 237, 240, 241, 244],
      SF_Outside_B: [141, 149]
    },
    rock: {
      Outside_B: [159, 167, 171, 223, 227, 231],
      Dungeon_B: [40, 41, 42, 44, 47, 48, 49, 50, 52, 55, 56, 57, 58, 60, 63]
    },
    sandKind: { Outside_A2: [32, 33, 34] },
    hearth: { Inside_B: [186, 187, 188, 189, 190, 191, 194, 195, 196, 197, 198, 199] }
  };

  /* ------------------------------------------------------------------ rng --*/
  /**
   * FNV-1a string hash, 32-bit. Used to seed each map.
   * @param {string} s @returns {number} unsigned 32-bit
   */
  function hash(s) {
    var h = 2166136261;
    s = String(s);
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
  }

  /**
   * A seeded generator (mulberry32). Every random choice Hedgerow makes goes through one of these — never
   * Math.random() (wing §3) — so a map's animals are the same every time the same seed is used.
   * @param {number} seed
   */
  function Rng(seed) { this.state = (seed >>> 0) || 1; }
  Rng.prototype.next = function () {
    var t = (this.state = (this.state + 0x6D2B79F5) >>> 0);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  Rng.prototype.range = function (a, b) { return a + (b - a) * this.next(); };
  Rng.prototype.int = function (n) { return Math.floor(this.next() * n); };

  /* -------------------------------------------------------------- notes --*/
  /**
   * Read `<Hedgerow: meadow town>`, `<Hedgerow: none>` and `<Hedgerow density: 1.5>` out of a note.
   * @param {string} note
   * @returns {{biomes:(string[]|null), density:(number|null), unknown:string[]}}
   */
  function parseNote(note) {
    var out = { biomes: null, density: null, unknown: [] };
    var s = String(note || '');
    var re = /<\s*hedgerow\s*(density)?\s*:\s*([^>]*)>/gi, m;
    while ((m = re.exec(s))) {
      if (m[1]) {
        var d = Number(String(m[2]).trim());
        if (String(m[2]).trim() !== '' && isFinite(d) && d >= 0) out.density = Math.min(4, d);
        continue;
      }
      var words = String(m[2]).toLowerCase().split(/[\s,]+/), list = [];
      for (var i = 0; i < words.length; i++) {
        var w = words[i].trim();
        if (!w) continue;
        if (BIOMES[w]) { if (list.indexOf(w) < 0) list.push(w); } else out.unknown.push(w);
      }
      if (list.length) out.biomes = list.indexOf('none') >= 0 ? ['none'] : list;
    }
    return out;
  }

  /**
   * Read `<Hedgerow tags: tree 7, rock 6, sand 5, hearth 4, water 1>` out of a tileset note: which terrain tag
   * marks each habitat on THAT tileset (a custom sheet MZ's stock tables cannot know). Unknown words and tags
   * outside 1-7 are ignored, never guessed.
   * @param {string} note @returns {{tree:number, rock:number, sand:number, hearth:number, water:number}}
   */
  function parseTags(note) {
    var out = { tree: 0, rock: 0, sand: 0, hearth: 0, water: 0 };
    var m = /<\s*hedgerow\s+tags\s*:\s*([^>]*)>/i.exec(String(note || ''));
    if (!m) return out;
    var re = /([a-z]+)\s*[= ]\s*(\d+)/gi, p;
    while ((p = re.exec(m[1]))) {
      var k = p[1].toLowerCase(), v = Number(p[2]);
      if (out.hasOwnProperty(k) && v >= 1 && v <= 7) out[k] = v;
    }
    return out;
  }

  /**
   * The tileset-name rule list: `Outside=meadow; Inside=house` — first rule whose word appears in the tileset
   * name (case-insensitive) wins.
   * @param {string} raw @returns {{word:string, biomes:string[]}[]}
   */
  function parseRules(raw) {
    var out = [];
    var parts = String(raw || '').split(/[;\n]+/);
    for (var i = 0; i < parts.length; i++) {
      var eq = parts[i].indexOf('=');
      if (eq < 0) continue;
      var word = parts[i].slice(0, eq).trim().toLowerCase();
      var bs = parts[i].slice(eq + 1).toLowerCase().split(/[\s,]+/).filter(function (b) { return !!BIOMES[b]; });
      if (word && bs.length) out.push({ word: word, biomes: bs });
    }
    return out;
  }

  /**
   * Decide a map's biomes. Order: a command override, the map note, the tileset note, the tileset name rules.
   * Nothing matched means no animals. A rule-derived outdoor biome becomes a TOWN as well when the map's
   * building tiles (A3 roofs and walls) cover at least `townShare` of it: the stock Outside sheet serves
   * villages and fields alike, and only the map can say which it is.
   * @returns {string[]}
   */
  function biomesFor(opts) {
    if (opts.override && opts.override.length) return opts.override.slice();
    var n = parseNote(opts.mapNote);
    if (n.biomes) return n.biomes;
    var t = parseNote(opts.tilesetNote);
    if (t.biomes) return t.biomes;
    var name = String(opts.tilesetName || '').toLowerCase();
    var rules = opts.rules || [];
    for (var i = 0; i < rules.length; i++) {
      if (name.indexOf(rules[i].word) < 0) continue;
      var bs = rules[i].biomes.slice();
      var share = Number(opts.buildingShare), want = Number(opts.townShare);
      if (bs.indexOf('town') < 0 && bs.indexOf('none') < 0 && (bs.indexOf('meadow') >= 0 || bs.indexOf('forest') >= 0)
        && isFinite(share) && isFinite(want) && want > 0 && share >= want) bs.push('town');
      return bs;
    }
    return ['none'];
  }

  /* ------------------------------------------------------------ habitat --*/
  /** Habitat bits per tile. GROUND is any walkable land; the others are where a family makes its home. */
  var H_GROUND = 1, H_WALLFOOT = 2, H_TREEFOOT = 4, H_ROCK = 8, H_SAND = 16, H_HEARTH = 32, H_WATER = 64;
  var KIND_BIT = { ground: H_GROUND, wallfoot: H_WALLFOOT, treefoot: H_TREEFOOT, rock: H_ROCK, sand: H_SAND, hearth: H_HEARTH, water: H_WATER };

  /**
   * Build the habitat grid once per map from accessor functions (so the suite can feed it a synthetic map and
   * the engine feeds it the real one — one function, two callers, wing §11).
   *   WALLFOOT = walkable with an impassable, non-water, non-tree tile directly ABOVE (the base of a wall face,
   *              a fence, a cliff, a counter): what a mouse runs along.
   *   TREEFOOT = walkable with a tree tile directly above: where a squirrel lives.
   *   ROCK     = walkable and a rock itself or beside one (4 sides): where a lizard basks.
   *   SAND     = walkable sand within two tiles of water: where a crab lives.
   *   HEARTH   = walkable beside a fireplace (4 sides): where a cat sleeps.
   * @param {{width:number,height:number,isWater:function,isPassable:function,isBlocked:function,
   *          isTree:function,isRock:function,isSand:function,isHearth:function,isBuilding:function}} q
   * @returns {{w:number,h:number,grid:Uint8Array,counts:object,buildingShare:number}}
   */
  function buildHabitat(q) {
    var w = q.width | 0, h = q.height | 0, n = w * h;
    var grid = new Uint8Array(n), solid = new Uint8Array(n);
    var x, y, i, buildings = 0;
    var no = function () { return false; };
    var isTree = q.isTree || no, isRock = q.isRock || no, isSand = q.isSand || no, isHearth = q.isHearth || no, isBuilding = q.isBuilding || no;
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) {
      i = y * w + x;
      if (isBuilding(x, y)) buildings++;
      if (q.isBlocked && q.isBlocked(x, y)) { solid[i] = 2; continue; }
      if (q.isWater(x, y)) { grid[i] = H_WATER; continue; }
      if (q.isPassable(x, y)) grid[i] = H_GROUND; else solid[i] = 1;
    }
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) {
      i = y * w + x;
      if (!(grid[i] & H_GROUND)) continue;
      /* a rock's base is ROCK habitat, not a wall foot (a mouse hole drawn into a boulder, smoke_day 2026-10-24) */
      if (y > 0 && solid[i - w] === 1) { if (isTree(x, y - 1)) grid[i] |= H_TREEFOOT; else if (!isRock(x, y - 1)) grid[i] |= H_WALLFOOT; }
      if (isRock(x, y) || (x > 0 && isRock(x - 1, y)) || (x < w - 1 && isRock(x + 1, y)) || (y > 0 && isRock(x, y - 1)) || (y < h - 1 && isRock(x, y + 1))) grid[i] |= H_ROCK;
      if ((x > 0 && isHearth(x - 1, y)) || (x < w - 1 && isHearth(x + 1, y)) || (y > 0 && isHearth(x, y - 1)) || (y < h - 1 && isHearth(x, y + 1))) grid[i] |= H_HEARTH;
      if (isSand(x, y)) {
        var near = false;
        for (var oy = -2; oy <= 2 && !near; oy++) for (var ox = -2; ox <= 2; ox++) {
          var xx = x + ox, yy = y + oy;
          if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
          if (grid[yy * w + xx] === H_WATER) { near = true; break; }
        }
        if (near) grid[i] |= H_SAND;
      }
    }
    /* WHERE on its home tile the thing it lives by stands. A tree drawn two tiles wide has its trunk on the line
     * BETWEEN its two tiles, so a squirrel at the middle of its foot tile climbed thin air beside the trunk (review
     * 2026-10-24, the store GIF). `trunk` = the trunk's offset from the tile's middle in HALF tiles, from the run of
     * tree tiles above: a run of 1 or 4+ is a tree per tile, 2 is one tree on its middle line, 3 is one tree on its
     * middle tile. `rock` = the side a rock lies on (1 left, 2 right, 3 up, 4 down), so a lizard basks ON it. */
    var trunk = new Int8Array(n), rock = new Int8Array(n);
    var treeAt = function (xx, yy) { return xx >= 0 && xx < w && yy >= 0 && yy < h && solid[yy * w + xx] === 1 && isTree(xx, yy); };
    for (y = 1; y < h; y++) for (x = 0; x < w; x++) {
      i = y * w + x;
      if (grid[i] & H_TREEFOOT) {
        var a = x, b = x;
        while (a > 0 && x - a < 4 && treeAt(a - 1, y - 1)) a--;
        while (b < w - 1 && b - x < 4 && treeAt(b + 1, y - 1)) b++;
        var run = b - a + 1;
        if (run === 2) trunk[i] = x === a ? 1 : -1;
        else if (run === 3) trunk[i] = (a + 1 - x) * 2;
      }
    }
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) {
      i = y * w + x;
      if (!(grid[i] & H_ROCK) || isRock(x, y)) continue;
      rock[i] = (x > 0 && isRock(x - 1, y)) ? 1 : (x < w - 1 && isRock(x + 1, y)) ? 2 : (y > 0 && isRock(x, y - 1)) ? 3 : (y < h - 1 && isRock(x, y + 1)) ? 4 : 0;
    }
    var counts = { ground: 0, wallfoot: 0, treefoot: 0, rock: 0, sand: 0, hearth: 0, water: 0 };
    for (i = 0; i < n; i++) {
      var g = grid[i];
      if (g & H_GROUND) counts.ground++;
      if (g & H_WALLFOOT) counts.wallfoot++;
      if (g & H_TREEFOOT) counts.treefoot++;
      if (g & H_ROCK) counts.rock++;
      if (g & H_SAND) counts.sand++;
      if (g & H_HEARTH) counts.hearth++;
      if (g & H_WATER) counts.water++;
    }
    return { w: w, h: h, grid: grid, trunk: trunk, rock: rock, counts: counts, buildingShare: n > 0 ? buildings / n : 0 };
  }

  /** @returns {boolean} whether tile (tx, ty) carries the habitat `kind` */
  function isHabitat(hab, kind, tx, ty) {
    if (tx < 0 || ty < 0 || tx >= hab.w || ty >= hab.h) return false;
    var bit = KIND_BIT[kind] || H_GROUND;
    return (hab.grid[ty * hab.w + tx] & bit) !== 0;
  }

  /* ----------------------------------------------------------- day phase --*/
  /**
   * Day, dusk or night — Vivarium's own reader, so the two plugins agree on one map. Order: a forced phase, an
   * hour variable (0-23), a night switch, the screen tone. MZ's "Night" tint (-68,-68,0,68) reads night,
   * "Sunset" (68,-34,-34,0) reads dusk, a heavily grey look (Sepia) is not a time of day.
   * @returns {'day'|'dusk'|'night'}
   */
  function phaseOf(o) {
    if (o.forced === 'day' || o.forced === 'dusk' || o.forced === 'night') return o.forced;
    if (o.hour !== null && o.hour !== undefined && String(o.hour).trim() !== '' && isFinite(Number(o.hour))) {
      var hr = ((Math.floor(Number(o.hour)) % 24) + 24) % 24;
      if (hr >= 21 || hr < 5) return 'night';
      if (hr >= 18 || hr < 7) return 'dusk';
      return 'day';
    }
    if (o.nightSwitch === true) return 'night';
    var t = o.tone;
    if (t && t.length >= 3) {
      var lum = (Number(t[0]) + Number(t[1]) + Number(t[2])) / 3;
      if (!isFinite(lum)) return 'day';
      if (lum <= -40) return 'night';
      if ((Number(t[3]) || 0) >= 120) return 'day';
      if (lum <= -12 || Number(t[0]) - Number(t[2]) >= 60) return 'dusk';
    }
    return 'day';
  }

  /* ------------------------------------------------------------- roster --*/
  /**
   * Which looks may appear on this map in this phase, family by family.
   * Indoors (house, cellar) has no sun: every indoor family is out at any hour. Rain brings snails out by day.
   * @returns {object} family -> array of look indices (empty families omitted)
   */
  function eligible(biomes, phase, hab, lookList, familiesOn, raining) {
    var out = {}, fams = {};
    var indoor = biomes.indexOf('house') >= 0 || biomes.indexOf('cellar') >= 0;
    for (var b = 0; b < biomes.length; b++) {
      var list = BIOMES[biomes[b]] || [];
      for (var f = 0; f < list.length; f++) fams[list[f]] = true;
    }
    for (var fi = 0; fi < FAMILY_ORDER.length; fi++) {
      var fam = FAMILY_ORDER[fi];
      if (!fams[fam]) continue;
      if (familiesOn && familiesOn[fam] === false) continue;
      var F = FAMILIES[fam];
      var inPhase = indoor || F.phases.indexOf(phase) >= 0 || (F.rain && raining);
      if (!inPhase) continue;
      if (!hab.counts[F.habitat]) continue;
      var ids = [];
      for (var s = 0; s < lookList.length; s++) {
        var lk = lookList[s];
        if (lk.family !== fam) continue;
        if (lk.biomes && lk.biomes.length) {
          var hit = false;
          for (var k = 0; k < biomes.length; k++) if (lk.biomes.indexOf(biomes[k]) >= 0) { hit = true; break; }
          if (!hit) continue;
        }
        ids.push(s);
      }
      if (ids.length) out[fam] = ids;
    }
    return out;
  }

  /**
   * How many of a family to keep alive for a given number of habitat tiles in view. Never zero when the
   * habitat is in view at all and the density is on: one rabbit in a small field beats none.
   * @returns {number}
   */
  function targetCount(fam, tilesInView, density) {
    var F = FAMILIES[fam];
    if (!F || tilesInView <= 0 || !(density > 0)) return 0;
    var n = Math.round(tilesInView / F.per * density);
    if (n < 1 && tilesInView * density >= F.per * 0.34) n = 1;
    return Math.max(0, Math.min(Math.round(F.cap * Math.max(1, density)), n));
  }

  /* ---------------------------------------------------------- behaviour --*/
  /** States. CALM = the calm loop (pose A/B), MOVE = walking to a target, ALERT = frozen and looking, FLEE =
   *  the family's flight, HIDE = gone (burrow, hole, canopy, sand, thread), BALL = curled or in its shell,
   *  OUT = coming back (peeking, unrolling, surfacing, letting down). */
  var S_CALM = 0, S_MOVE = 1, S_ALERT = 2, S_FLEE = 3, S_HIDE = 4, S_BALL = 5, S_OUT = 6;
  /** Pose slots (side view, left and right): see HedgerowPaint.POSES. */
  var P_CALM_A = 0, P_CALM_B = 1, P_ALERT = 2, P_F1 = 3, P_F2 = 4, P_F3 = 5;
  /** Facing index for the walk cells: down, left, right, up (MZ's own character order). */
  var D_DOWN = 0, D_LEFT = 1, D_RIGHT = 2, D_UP = 3;
  var CELLS_PER_LOOK = 24;
  var WALK_SEQ = [1, 0, 1, 2];

  /**
   * An animal record. Made ONCE per pool slot (zero per-frame allocation, wing §3); `spawn` reuses it.
   */
  function Animal() {
    this.active = false; this.look = -1; this.fam = ''; this.x = 0; this.y = 0; this.lift = 0;
    this.vx = 0; this.vy = 0; this.tx = 0; this.ty = 0; this.hx = 0; this.hy = 0;
    this.state = 0; this.t = 0; this.timer = 0; this.frame = 0; this.dir = D_DOWN; this.side = 0; this.angle = 0;
    this.alpha = 0; this.fade = 0; this.phaseT = 0; this.flee = 0; this.speed = 1; this.zig = 0; this.drop = 0;
    this.walkT = 0; this.looked = 0;
  }

  /**
   * Put an animal at a spawn point (its home) and give it a first calm spell.
   * @param {Animal} c @param {number} lookIndex @param {object} lk @param {number} px @param {number} py @param {Rng} rng
   */
  function spawn(c, lookIndex, lk, px, py, rng) {
    c.active = true; c.look = lookIndex; c.fam = lk.family; c.x = px; c.y = py; c.hx = px; c.hy = py; c.lift = 0;
    c.vx = 0; c.vy = 0; c.tx = px; c.ty = py; c.state = S_CALM; c.t = rng.int(1000); c.timer = rng.range(40, 160);
    c.frame = 0; c.dir = rng.next() < 0.5 ? D_LEFT : D_RIGHT; c.side = c.dir === D_LEFT ? 0 : 1; c.angle = rng.range(0, Math.PI * 2);
    c.alpha = 0; c.fade = 1; c.phaseT = rng.next(); c.flee = 0; c.speed = rng.range(0.85, 1.15); c.zig = rng.next() < 0.5 ? -1 : 1;
    c.drop = 0; c.walkT = 0; c.looked = 0;
    /* a spider appears already hanging: its thread is out from the first frame (a fresh spider at lift 0 had
     * nothing to reel in, so its flight ended the frame it began, core.test spider-reels-up 2026-10-24) */
    if (lk.family === 'spider') { c.drop = rng.range(10, 26); c.lift = c.drop; c.state = S_CALM; }
  }

  /** The walk cell for a facing at a walk time. */
  function walkCell(dir, walkT, stride) { return dir * 3 + WALK_SEQ[Math.floor(walkT / stride) % 4]; }
  /** The pose cell for a pose slot on the animal's current side. */
  function poseCell(c, pose) { return 12 + pose * 2 + c.side; }
  /** A squirrel's two climb frames (seen from behind) live in pose slot F3's two cells. */
  function climbCell(t) { return 12 + P_F3 * 2 + (Math.floor(t / 3) % 2); }

  /** Face the direction of travel. Prefers the horizontal facing unless the move is clearly vertical. */
  function faceTo(c, dx, dy) {
    var ax = dx < 0 ? -dx : dx, ay = dy < 0 ? -dy : dy;
    if (ax < 0.01 && ay < 0.01) return;
    if (FAMILIES[c.fam].view !== 'quad') {
      /* a snail, crab, lizard or spider has no front and back views: only the side it last moved toward */
      if (ax >= 0.01) c.side = dx < 0 ? 0 : 1;
      c.dir = c.side ? D_RIGHT : D_LEFT;
      return;
    }
    if (ay > ax * 1.35) c.dir = dy > 0 ? D_DOWN : D_UP;
    else { c.dir = dx < 0 ? D_LEFT : D_RIGHT; c.side = dx < 0 ? 0 : 1; }
  }

  /**
   * Choose a new target near home inside the family's habitat when it can find one. Wall-foot families keep to
   * their ROW (a mouse runs along the wall, never across the room).
   * @returns {boolean} whether a habitat target was found
   */
  function pickTarget(c, env, radius, kind) {
    var tw = env.tw, th = env.th, hab = env.hab;
    for (var tries = 0; tries < 8; tries++) {
      var tx, ty;
      if (kind === 'wallfoot') {
        tx = c.hx + env.rng.range(-radius, radius); ty = c.hy;
        if (!runClear(hab, Math.floor(c.x / tw), Math.floor(tx / tw), Math.floor(ty / th))) continue;
      } else {
        var a = env.rng.range(0, Math.PI * 2), r = env.rng.range(radius * 0.25, radius);
        tx = c.hx + Math.cos(a) * r; ty = c.hy + Math.sin(a) * r * 0.75;
      }
      if (isHabitat(hab, kind || 'ground', Math.floor(tx / tw), Math.floor(ty / th)) && isHabitat(hab, 'ground', Math.floor(tx / tw), Math.floor(ty / th))) { c.tx = tx; c.ty = ty; return true; }
    }
    c.tx = c.hx; c.ty = c.hy;
    return false;
  }

  /** Every tile on the row between two columns is wall foot (a mouse never runs through a gap in the wall). */
  function runClear(hab, x0, x1, row) {
    var a = x0 < x1 ? x0 : x1, b = x0 < x1 ? x1 : x0;
    for (var x = a; x <= b; x++) if (!isHabitat(hab, 'wallfoot', x, row)) return false;
    return true;
  }

  /** Move toward the target at up to `max` px/frame; returns the remaining distance. Walkable ground only. */
  function moveTo(c, env, max, kind) {
    var dx = c.tx - c.x, dy = c.ty - c.y;
    var d = Math.sqrt(dx * dx + dy * dy);
    if (d < 0.001) { c.vx = 0; c.vy = 0; return 0; }
    var s = d < max ? d : max;
    var nx = c.x + dx / d * s, ny = c.y + dy / d * s;
    var tx = Math.floor(nx / env.tw), ty = Math.floor(ny / env.th);
    /* an animal standing OFF the ground (a lizard basking on top of its rock) may always step: that is how it
     * leaves the rock; everything else keeps to walkable ground */
    var here = isHabitat(env.hab, 'ground', Math.floor(c.x / env.tw), Math.floor(c.y / env.th));
    if (!here || isHabitat(env.hab, 'ground', tx, ty) && (!kind || kind === 'ground' || isHabitat(env.hab, kind, tx, ty) || kind === 'near')) {
      c.vx = nx - c.x; c.vy = ny - c.y; c.x = nx; c.y = ny;
    } else { c.vx = 0; c.vy = 0; c.tx = c.x; c.ty = c.y; return 0; }
    faceTo(c, dx, dy);
    return d - s;
  }

  /** Is the straight run from the animal to (tx, ty) walkable ground all the way (sampled every half tile)? */
  function clearRun(c, env, tx, ty) {
    var dx = tx - c.x, dy = ty - c.y, d = Math.sqrt(dx * dx + dy * dy), n = Math.max(1, Math.ceil(d / (env.tw * 0.5)));
    var sx = Math.floor(c.x / env.tw), sy = Math.floor(c.y / env.th);
    for (var i = 1; i <= n; i++) {
      var x = c.x + dx * i / n, y = c.y + dy * i / n, gx = Math.floor(x / env.tw), gy = Math.floor(y / env.th);
      if (gx === sx && gy === sy) continue;   /* the tile it stands on (a lizard's rock top) is not in its way */
      if (!isHabitat(env.hab, 'ground', gx, gy)) return false;
    }
    return true;
  }

  /**
   * A flight target `tiles` away from the player along a CLEAR run of walkable ground: straight away first, then
   * fanning out to either side up to 90 degrees. (Checking only the end tile sent a lizard into its own rock, where
   * the first step stopped it dead; core.test lizard-darts, 2026-10-24.)
   */
  function awayTarget(c, env, tiles) {
    var pdx = c.x - env.playerX, pdy = c.y - env.playerY, pd = Math.sqrt(pdx * pdx + pdy * pdy) || 1;
    var ux = pdx / pd, uy = pdy / pd;
    for (var k = 0; k < 9; k++) {
      var spread = (k === 0 ? 0 : ((k & 1) ? 1 : -1) * Math.ceil(k / 2) * 0.4);
      var rx = ux * Math.cos(spread) - uy * Math.sin(spread), ry = ux * Math.sin(spread) + uy * Math.cos(spread);
      var tx = c.x + rx * env.tw * tiles, ty = c.y + ry * env.th * tiles;
      if (clearRun(c, env, tx, ty)) { c.tx = tx; c.ty = ty; return true; }
    }
    c.tx = c.x + ux * env.tw * tiles; c.ty = c.y + uy * env.th * tiles;
    return false;
  }

  /** Begin the family's flight. */
  function startFlee(c, env, F) {
    var fam = c.fam;
    c.flee = 0; c.looked = 0;
    switch (F.flee) {
      case 'bolt': c.state = S_ALERT; c.timer = 10; break;           /* sit up, then the thump, then the bolt */
      case 'dash': c.state = S_ALERT; c.timer = 6; break;
      case 'climb': c.state = S_FLEE; c.tx = c.hx; c.ty = c.hy; c.timer = 0; break;   /* run home to the tree */
      case 'curl': c.state = S_BALL; c.timer = 0; break;
      case 'hole': c.state = S_FLEE; c.tx = c.hx; c.ty = c.hy; break;                 /* run along the wall to the hole */
      case 'dart': c.state = S_FLEE; c.flee = 2 + env.rng.int(2); c.timer = 0; awayTarget(c, env, 1.4); break;
      case 'dig': c.state = S_ALERT; c.timer = 24; break;           /* claws up, then sidle back, then dig in */
      case 'shell': c.state = S_BALL; c.timer = 0; break;
      case 'stalk': c.state = S_ALERT; c.timer = 46; break;         /* sit up and watch first */
      case 'trot': c.state = S_ALERT; c.timer = 18; break;
      case 'reel': c.state = S_FLEE; break;
    }
    if (fam === 'lizard') faceAngle(c);
  }

  function faceAngle(c) {
    var dx = c.tx - c.x, dy = c.ty - c.y;
    if (dx * dx + dy * dy > 0.25) c.angle = Math.atan2(dy, dx) + Math.PI / 2;
  }

  /**
   * One frame of one animal. Mutates `c` only; allocates nothing.
   * @param {Animal} c
   * @param {{rng:Rng, hab:object, tw:number, th:number, playerX:number, playerY:number, fleeR:number,
   *          looks:object[], spook:number}} env
   */
  function step(c, env) {
    if (!c.active) return;
    var F = FAMILIES[c.fam], fam = c.fam;
    c.t++;
    if (c.fade > 0) { c.alpha = Math.min(1, c.alpha + 0.05); if (c.alpha >= 1) c.fade = 0; }
    else if (c.fade < 0) { c.alpha = Math.max(0, c.alpha - 0.05); if (c.alpha <= 0) { c.active = false; return; } }

    var pdx = c.x - env.playerX, pdy = c.y - env.playerY;
    var pd = Math.sqrt(pdx * pdx + pdy * pdy) || 1;
    var fleeR = env.fleeR * (fam === 'cat' ? 0.8 : (fam === 'snail' || fam === 'hedgehog' ? 0.7 : 1));
    var near = pd < fleeR;
    if (near && (c.state === S_CALM || c.state === S_MOVE) && F.flee) startFlee(c, env, F);

    switch (F.flee) {
      case 'bolt': case 'dash': stepRunner(c, env, F, near); break;
      case 'climb': stepSquirrel(c, env, F, near); break;
      case 'curl': case 'shell': stepCurler(c, env, F, pd, fleeR); break;
      case 'hole': stepWallRunner(c, env, F, near); break;
      case 'dart': stepLizard(c, env, F, near); break;
      case 'dig': stepCrab(c, env, F, near, pdx); break;
      case 'stalk': case 'trot': stepWalker(c, env, F, near); break;
      case 'reel': stepSpider(c, env, F, near); break;
    }
  }

  /** The calm loop shared by every ground walker: pose A, pose B, an occasional short walk. */
  function calm(c, env, F, kind, radius, poseA, poseB, stride) {
    if (c.state === S_MOVE) {
      var left = moveTo(c, env, F.walk * c.speed, kind);
      c.walkT++;
      c.frame = walkCell(c.dir, c.walkT, stride);
      if (left < 1 || --c.timer <= 0) { c.state = S_CALM; c.timer = env.rng.range(60, 240); if (c.dir === D_DOWN || c.dir === D_UP) c.dir = c.side ? D_RIGHT : D_LEFT; }
      return;
    }
    /* calm: alternate the two poses on a slow beat */
    var beat = Math.floor((c.t + c.phaseT * 400) / 70) % 3;
    c.frame = poseCell(c, beat === 2 ? poseB : poseA);
    if (--c.timer <= 0) {
      if (pickTarget(c, env, radius, kind)) { c.state = S_MOVE; c.timer = 240; }
      else c.timer = env.rng.range(60, 200);
    }
  }

  /** Rabbit and hare: alert, (thump), then the bolt — a zig-zag for a rabbit, a long straight dash for a hare. */
  function stepRunner(c, env, F, near) {
    var tw = env.tw;
    if (c.state === S_CALM || c.state === S_MOVE) { calm(c, env, F, 'ground', tw * 2.2, P_CALM_A, P_CALM_B, 5); return; }
    if (c.state === S_ALERT) {
      c.frame = poseCell(c, c.flee === 0 && F.flee === 'bolt' && c.timer < 6 ? P_F3 : P_ALERT);
      if (--c.timer <= 0) {
        if (F.flee === 'bolt' && c.flee === 0) { c.flee = 1; c.timer = 8; return; }   /* the thump */
        c.state = S_FLEE; c.flee = F.flee === 'bolt' ? 5 : 7; awayTarget(c, env, c.flee); c.zig = c.zig || 1; c.timer = 0;
        c.hx = c.tx; c.hy = c.ty;   /* the goal of the flight; a rabbit's aim swings either side of it */
      }
      return;
    }
    if (c.state === S_FLEE) {
      /* a rabbit jinks: every 12 frames its aim swings to the other side of the line to its goal, a tile and a half
       * ahead and one tile across, so the run is a zig-zag of +-34 degrees (a swing of a FAR target bent the line by
       * under 15 degrees and read as straight, core.test rabbit-jinks 2026-10-24) */
      if (F.flee === 'bolt') {
        if ((c.timer % 12) === 0) c.zig = -c.zig;
        var gx = c.hx - c.x, gy = c.hy - c.y, gd = Math.sqrt(gx * gx + gy * gy) || 1;
        var ax = c.x + gx / gd * tw * 1.5 - gy / gd * tw * c.zig, ay = c.y + gy / gd * tw * 1.5 + gx / gd * tw * c.zig;
        if (gd > tw * 1.5 && isHabitat(env.hab, 'ground', Math.floor(ax / tw), Math.floor(ay / tw))) { c.tx = ax; c.ty = ay; }
        else { c.tx = c.hx; c.ty = c.hy; }
        if (gd < tw * 1.2) { c.tx = c.x; c.ty = c.y; }
      }
      var left = moveTo(c, env, F.run * c.speed, 'ground');
      if (F.flee === 'bolt') left = Math.sqrt((c.hx - c.x) * (c.hx - c.x) + (c.hy - c.y) * (c.hy - c.y)) - tw * 1.2;
      c.timer++;
      c.frame = (c.dir === D_LEFT || c.dir === D_RIGHT) ? poseCell(c, (Math.floor(c.timer / 4) % 2) ? P_F1 : P_F2) : walkCell(c.dir, c.timer, 2);
      if (left < 2 || c.timer > 120) { c.state = S_CALM; c.hx = c.x; c.hy = c.y; c.timer = env.rng.range(90, 200); if (c.dir === D_DOWN || c.dir === D_UP) c.dir = c.side ? D_RIGHT : D_LEFT; }
    }
  }

  /** Squirrel: forage round its tree; flee home, climb into the canopy, come back down when the party has gone. */
  function stepSquirrel(c, env, F, near) {
    var th = env.th;
    if (c.state === S_CALM || c.state === S_MOVE) { calm(c, env, F, 'near', env.tw * 1.6, P_CALM_A, P_CALM_B, 4); return; }
    if (c.state === S_FLEE) {
      if (c.lift === 0) {
        c.tx = c.hx; c.ty = c.hy;
        moveTo(c, env, F.run * c.speed, 'near');
        /* blocked on the straight line home (a corner of the trunk row): go round it one axis at a time. It used
         * to be put home in one frame, a jump the store GIF showed (review 2026-10-24); now it RUNS there. */
        if (c.vx === 0 && c.vy === 0) {
          c.tx = c.hx; c.ty = c.y; moveTo(c, env, F.run * c.speed, 'near');
          if (c.vx === 0 && c.vy === 0) { c.tx = c.x; c.ty = c.hy; moveTo(c, env, F.run * c.speed, 'near'); }
          c.tx = c.hx; c.ty = c.hy;
        }
        var hx = c.hx - c.x, hy = c.hy - c.y, home = Math.sqrt(hx * hx + hy * hy);
        c.timer++;
        c.frame = (c.dir === D_LEFT || c.dir === D_RIGHT) ? poseCell(c, (Math.floor(c.timer / 3) % 2) ? P_F1 : P_F2) : walkCell(c.dir, c.timer, 2);
        /* at the trunk (within a few px it is drawn there): climb. Stuck far from it: it slips away, never jumps */
        if (home < 4) { c.x = c.hx; c.y = c.hy; c.lift = 0.01; c.dir = D_UP; c.timer = 0; }
        else if (c.timer > 90 && c.vx === 0 && c.vy === 0) c.fade = -1;
        return;
      }
      /* the climb: up the trunk, behind the canopy (the upper layer covers it), then gone. Seen from behind, so
       * pose slot F3 holds the two climb frames in its two cells (left reach, right reach). */
      c.lift += 1.6; c.timer++;
      c.frame = climbCell(c.timer);
      if (c.lift > th * 1.6) { c.state = S_HIDE; c.timer = env.rng.range(360, 620); }
      return;
    }
    if (c.state === S_HIDE) {
      if (--c.timer <= 0 && !near) { c.state = S_OUT; c.timer = 0; }
      return;
    }
    if (c.state === S_OUT) {
      c.lift -= 1.2; c.timer++;
      c.frame = climbCell(c.timer + 1);
      if (near) { c.state = S_FLEE; return; }
      if (c.lift <= 0) { c.lift = 0; c.state = S_CALM; c.timer = env.rng.range(60, 160); c.dir = c.side ? D_RIGHT : D_LEFT; }
      return;
    }
    if (c.state === S_ALERT) { c.state = S_FLEE; }
  }

  /** Hedgehog and snail: roll up (or withdraw) where they stand, wait for the party to go, then come out. */
  function stepCurler(c, env, F, pd, fleeR) {
    if (c.state === S_CALM || c.state === S_MOVE) { calm(c, env, F, 'ground', env.tw * (c.fam === 'snail' ? 0.8 : 2), P_CALM_A, P_CALM_B, c.fam === 'snail' ? 18 : 7); return; }
    if (c.state === S_BALL) {
      c.frame = poseCell(c, P_F1);
      if (pd > fleeR * 1.35) { if (++c.timer > (c.fam === 'snail' ? 200 : 90)) { c.state = S_OUT; c.timer = 0; } }
      else c.timer = 0;
      return;
    }
    if (c.state === S_OUT) {
      c.timer++;
      c.frame = poseCell(c, P_F2);
      if (pd < fleeR) { c.state = S_BALL; c.timer = 0; return; }
      if (c.timer > 24) { c.state = S_CALM; c.timer = env.rng.range(60, 160); }
    }
  }

  /** Mouse and rat: along the wall foot only; flee along the wall into the hole at home; peek; come out. */
  function stepWallRunner(c, env, F, near) {
    if (c.state === S_CALM || c.state === S_MOVE) { calm(c, env, F, 'wallfoot', env.tw * 2.5, P_CALM_A, P_CALM_B, 3); return; }
    if (c.state === S_FLEE) {
      var left = moveTo(c, env, F.run * c.speed, 'wallfoot');
      c.timer++;
      c.frame = (c.dir === D_LEFT || c.dir === D_RIGHT) ? poseCell(c, (Math.floor(c.timer / 2) % 2) ? P_F1 : P_F2) : walkCell(c.dir, c.timer, 1);
      if (left < 1 || c.timer > 120) { c.x = c.hx; c.y = c.hy; c.state = S_HIDE; c.timer = env.rng.range(300, 560); c.dir = D_DOWN; }
      return;
    }
    if (c.state === S_HIDE) {
      if (--c.timer <= 0 && !near) { c.state = S_OUT; c.timer = 0; }
      return;
    }
    if (c.state === S_OUT) {
      /* a peek: the head out of the hole, then the whole mouse */
      c.timer++;
      c.frame = poseCell(c, P_F3);
      if (near) { c.state = S_HIDE; c.timer = env.rng.range(200, 400); return; }
      if (c.timer > 70) { c.state = S_CALM; c.timer = env.rng.range(40, 120); c.dir = c.side ? D_RIGHT : D_LEFT; }
      return;
    }
    if (c.state === S_ALERT) c.state = S_FLEE;
  }

  /** Lizard: bask on its rock; flee in quick darts with freezes between; seen from above, it turns to its heading. */
  function stepLizard(c, env, F, near) {
    var stride = 3;
    if (c.state === S_CALM) {
      c.frame = (Math.floor((c.t + c.phaseT * 300) / 90) % 4 === 3) ? 12 + P_CALM_B * 2 : 12 + P_CALM_A * 2;   /* bask, a push-up now and then */
      if (--c.timer <= 0) { if (pickTarget(c, env, env.tw * 1.3, 'rock')) { c.state = S_MOVE; c.timer = 120; faceAngle(c); } else c.timer = env.rng.range(80, 220); }
      return;
    }
    if (c.state === S_MOVE) {
      var lm = moveTo(c, env, F.walk * 2 * c.speed, 'ground');
      c.walkT++; c.frame = Math.floor(c.walkT / stride) % 3; faceAngle(c);
      if (lm < 1 || --c.timer <= 0) { c.state = S_CALM; c.timer = env.rng.range(120, 300); }
      return;
    }
    if (c.state === S_FLEE) {
      if (c.timer > 0) { c.timer--; c.frame = 12 + P_ALERT * 2; return; }   /* the freeze */
      faceAngle(c);
      var left = moveTo(c, env, F.run * c.speed, 'ground');
      c.walkT++; c.frame = Math.floor(c.walkT / 2) % 3;
      if (left < 1) {
        if (--c.flee <= 0) { if (near) { c.fade = -1; } else { c.state = S_CALM; c.hx = c.x; c.hy = c.y; c.timer = env.rng.range(120, 240); } }
        else { c.timer = 14 + env.rng.int(16); awayTarget(c, env, 1.2); }
      }
      return;
    }
    if (c.state === S_ALERT) c.state = S_FLEE;
  }

  /** Crab: sidle on the sand; claws up, back off sideways, dig in; surface again later. Always front-on. */
  function stepCrab(c, env, F, near, pdx) {
    if (c.state === S_CALM || c.state === S_MOVE) {
      if (c.state === S_MOVE) {
        var lm = moveTo(c, env, F.walk * c.speed, 'sand');
        c.walkT++; c.frame = Math.floor(c.walkT / 4) % 3;
        if (lm < 1 || --c.timer <= 0) { c.state = S_CALM; c.timer = env.rng.range(60, 200); }
        return;
      }
      c.frame = 12 + ((Math.floor((c.t + c.phaseT * 200) / 50) % 3) === 1 ? P_CALM_B : P_CALM_A) * 2;
      if (--c.timer <= 0) {
        /* crabs walk sideways: keep the target on the same row more often than not */
        if (pickTarget(c, env, env.tw * 1.5, 'sand')) { c.ty = c.y + (c.ty - c.y) * 0.3; c.state = S_MOVE; c.timer = 160; }
        else c.timer = env.rng.range(60, 160);
      }
      return;
    }
    if (c.state === S_ALERT) {
      c.frame = 12 + P_ALERT * 2;
      if (--c.timer <= 0) { c.state = S_FLEE; c.timer = 0; c.tx = c.x + (pdx >= 0 ? 1 : -1) * env.tw * 0.9; c.ty = c.y; }
      return;
    }
    if (c.state === S_FLEE) {
      c.timer++;
      if (c.timer < 36) { moveTo(c, env, F.run, 'sand'); c.frame = Math.floor(c.timer / 3) % 3; return; }
      /* dig in: half sunk, eyes only, gone */
      c.frame = 12 + (c.timer < 50 ? P_F1 : P_F2) * 2;
      if (c.timer > 64) { c.state = S_HIDE; c.timer = env.rng.range(300, 520); }
      return;
    }
    if (c.state === S_HIDE) {
      if (--c.timer <= 0 && !near) { pickTarget(c, env, env.tw * 2, 'sand'); c.x = c.tx; c.y = c.ty; c.hx = c.x; c.hy = c.y; c.state = S_OUT; c.timer = 0; }
      return;
    }
    if (c.state === S_OUT) {
      c.timer++;
      c.frame = 12 + (c.timer < 14 ? P_F2 : P_F1) * 2;
      if (near) { c.state = S_FLEE; c.timer = 40; return; }
      if (c.timer > 28) { c.state = S_CALM; c.timer = env.rng.range(60, 160); }
    }
  }

  /** Cat, fox, badger: look first; a cat stalks away at a walk and sits again, a fox or badger trots off. */
  function stepWalker(c, env, F, near) {
    var cat = c.fam === 'cat';
    if (c.state === S_CALM || c.state === S_MOVE) {
      calm(c, env, F, 'ground', env.tw * (cat ? 1.5 : 3), P_CALM_A, P_CALM_B, cat ? 7 : 5);
      return;
    }
    if (c.state === S_ALERT) {
      if (c.dir === D_DOWN || c.dir === D_UP) c.dir = c.side ? D_RIGHT : D_LEFT;
      c.side = env.playerX < c.x ? 0 : 1;   /* it turns to look at the party */
      c.frame = poseCell(c, P_ALERT);
      if (--c.timer <= 0) { c.state = S_FLEE; awayTarget(c, env, cat ? 2.5 : 5); c.timer = 0; c.looked = 0; }
      return;
    }
    if (c.state === S_FLEE) {
      var sp = cat ? F.run : F.run * c.speed;
      var left = moveTo(c, env, sp, 'ground');
      c.timer++;
      if (!cat && c.looked === 0 && c.timer === 40) { c.looked = 1; c.state = S_ALERT; c.timer = 16; c.side = env.playerX < c.x ? 0 : 1; return; }
      c.frame = (!cat && (c.dir === D_LEFT || c.dir === D_RIGHT)) ? poseCell(c, (Math.floor(c.timer / 4) % 2) ? P_F1 : P_F2) : walkCell(c.dir, c.timer, cat ? 6 : 3);
      if (left < 2 || c.timer > 200) {
        c.state = S_CALM; c.hx = c.x; c.hy = c.y; c.timer = env.rng.range(120, 320);
        if (c.dir === D_DOWN || c.dir === D_UP) c.dir = c.side ? D_RIGHT : D_LEFT;
        if (cat) c.side = env.playerX < c.x ? 0 : 1;
      }
    }
  }

  /** Spider: hangs on its thread from the wall above and bobs; reels up out of sight; lets itself down again. */
  function stepSpider(c, env, F, near) {
    if (c.state === S_CALM || c.state === S_MOVE || c.state === S_ALERT) {
      c.state = S_CALM;
      c.lift = c.drop + Math.sin(c.t * 0.03 + c.phaseT * 6) * 2;
      c.frame = 12 + ((Math.floor((c.t + c.phaseT * 100) / 40) % 4) === 0 ? P_CALM_B : P_CALM_A) * 2;
      return;
    }
    if (c.state === S_FLEE) {
      c.lift -= F.run * 2; c.frame = 12 + P_ALERT * 2;
      if (c.lift <= 0) { c.lift = 0; c.state = S_HIDE; c.timer = env.rng.range(260, 480); }
      return;
    }
    if (c.state === S_HIDE) { if (--c.timer <= 0 && !near) { c.state = S_OUT; } return; }
    if (c.state === S_OUT) {
      c.lift += 0.35; c.frame = 12 + P_CALM_A * 2;
      if (near) { c.state = S_FLEE; return; }
      if (c.lift >= c.drop) { c.state = S_CALM; }
    }
  }

  /** @returns {object|null} a checked copy of one buyer look, or null when it is unusable */
  function cleanLook(raw, index) {
    if (!raw || typeof raw !== 'object') return null;
    var fam = String(raw.family || '').trim().toLowerCase();
    if (!FAMILIES[fam]) return null;
    var base = null;
    for (var i = 0; i < LOOKS.length; i++) if (LOOKS[i].family === fam) { base = LOOKS[i]; break; }
    var hex = function (v, d) { var s = String(v || '').trim(); return /^#[0-9a-f]{6}$/i.test(s) ? s.toLowerCase() : d; };
    var size = Number(raw.size);
    var pattern = String(raw.pattern || '').trim().toLowerCase();
    var bs = String(raw.biomes || '').toLowerCase().split(/[\s,]+/).filter(function (b) { return !!BIOMES[b] && b !== 'none'; });
    return {
      id: String(raw.id || ('custom-' + index)).trim().toLowerCase().replace(/[^a-z0-9-]+/g, '-'),
      name: String(raw.name || raw.id || ('Custom ' + index)).trim(),
      family: fam,
      size: String(raw.size === undefined ? '' : raw.size).trim() !== '' && isFinite(size) && size > 0 ? Math.max(0.6, Math.min(1.5, size)) : base.size,
      pattern: PATTERNS[fam].indexOf(pattern) >= 0 ? pattern : base.pattern,
      c1: hex(raw.colour1, base.c1), c2: hex(raw.colour2, base.c2), c3: hex(raw.colour3, base.c3),
      biomes: bs, custom: true
    };
  }

  /** Every pattern value HedgerowPaint draws, per family (the suite checks each is drawn). */
  var PATTERNS = {};
  for (var q = 0; q < FAMILY_ORDER.length; q++) PATTERNS[FAMILY_ORDER[q]] = [];
  for (var r = 0; r < LOOKS.length; r++) if (PATTERNS[LOOKS[r].family].indexOf(LOOKS[r].pattern) < 0) PATTERNS[LOOKS[r].family].push(LOOKS[r].pattern);

  globalThis.CSAF.HedgerowCore = {
    VERSION: '1.0.0',
    FAMILIES: FAMILIES, FAMILY_ORDER: FAMILY_ORDER, BIOMES: BIOMES, LOOKS: LOOKS, PATTERNS: PATTERNS, STOCK: STOCK,
    H_GROUND: H_GROUND, H_WALLFOOT: H_WALLFOOT, H_TREEFOOT: H_TREEFOOT, H_ROCK: H_ROCK, H_SAND: H_SAND, H_HEARTH: H_HEARTH, H_WATER: H_WATER,
    S_CALM: S_CALM, S_MOVE: S_MOVE, S_ALERT: S_ALERT, S_FLEE: S_FLEE, S_HIDE: S_HIDE, S_BALL: S_BALL, S_OUT: S_OUT,
    P_CALM_A: P_CALM_A, P_CALM_B: P_CALM_B, P_ALERT: P_ALERT, P_F1: P_F1, P_F2: P_F2, P_F3: P_F3,
    D_DOWN: D_DOWN, D_LEFT: D_LEFT, D_RIGHT: D_RIGHT, D_UP: D_UP, CELLS_PER_LOOK: CELLS_PER_LOOK,
    hash: hash, Rng: Rng, parseNote: parseNote, parseTags: parseTags, parseRules: parseRules, biomesFor: biomesFor,
    buildHabitat: buildHabitat, isHabitat: isHabitat, phaseOf: phaseOf, eligible: eligible,
    targetCount: targetCount, Animal: Animal, spawn: spawn, step: step, pickTarget: pickTarget, startFlee: startFlee,
    walkCell: walkCell, poseCell: poseCell, cleanLook: cleanLook
  };
})();
