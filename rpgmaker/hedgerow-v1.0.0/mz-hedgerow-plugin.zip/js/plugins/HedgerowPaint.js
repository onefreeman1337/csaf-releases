//=============================================================================
// HedgerowPaint.js — Hedgerow [2/3]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Hedgerow [2/3] — the painter: every animal is drawn here at runtime. No settings here; see Hedgerow.js. v1.0.0
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help HedgerowPaint.js
 *
 * Part 2 of 3. Load all three: HedgerowCore.js, HedgerowPaint.js and
 * Hedgerow.js. Any order works. No image files are loaded: every frame of
 * every animal is drawn with the canvas from a family plan and a coat.
 */

'use strict';

if (typeof globalThis.CSAF === 'undefined') globalThis.CSAF = {};

(function () {
  var TAU = 6.283185307179586;
  var LINE = 'rgba(36,22,12,0.86)';
  var BASE_CELL = 48;          /* one cell per frame at scale 1 (a 48 px tile) */
  var FOOT = 8;                /* the foot line sits this far above the cell's bottom edge (room for a dug-in crab) */
  var DORSAL_LIFT = 14;        /* a lizard's body centre sits this far above the foot line (its whole length fits the cell) */

  /* ------------------------------------------------------------- colour --*/
  /** #rrggbb -> [r,g,b], or null for anything malformed (wing §21c: never NaN channels). */
  function hex(c) { var m = /^#([0-9a-f]{6})$/i.exec(String(c)); if (!m) return null; var n = parseInt(m[1], 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  function toHex(v) { return '#' + ((1 << 24) | (v[0] << 16) | (v[1] << 8) | v[2]).toString(16).slice(1); }
  /** Lighten (k > 0) or darken (k < 0) by an absolute step. A malformed colour comes back unchanged. */
  function shade(c, k) { var v = hex(c); if (!v) return c; for (var i = 0; i < 3; i++) v[i] = Math.max(0, Math.min(255, Math.round(v[i] + k))); return toHex(v); }
  /** Mix two colours (t = 0 -> a, 1 -> b). */
  function mix(a, b, t) { var x = hex(a), y = hex(b); if (!x || !y) return a; return toHex([0, 1, 2].map(function (i) { return Math.round(x[i] + (y[i] - x[i]) * t); })); }
  /** Perceived lightness 0-255 (for picking an eye or outline that reads on the coat). */
  function lum(c) { var v = hex(c); return v ? 0.299 * v[0] + 0.587 * v[1] + 0.114 * v[2] : 128; }

  function ell(ctx, x, y, rx, ry, rot) { ctx.beginPath(); ctx.ellipse(x, y, Math.max(0.1, rx), Math.max(0.1, ry), rot || 0, 0, TAU); }
  function ink(ctx, fill, lw) { ctx.fillStyle = fill; ctx.fill(); ctx.lineWidth = lw === undefined ? 0.8 : lw; ctx.strokeStyle = LINE; ctx.stroke(); }
  /** A coat lit from the upper left: the same light on every animal, so a field of them reads as one place. */
  function coat(ctx, cx, cy, r, base) {
    var g = ctx.createRadialGradient(cx - r * 0.4, cy - r * 0.6, r * 0.1, cx, cy, r * 1.3);
    g.addColorStop(0, shade(base, 30)); g.addColorStop(0.55, base); g.addColorStop(1, shade(base, -40));
    return g;
  }
  function shadow(ctx, rx, alpha) { ctx.fillStyle = 'rgba(16,12,6,' + (alpha || 0.3) + ')'; ell(ctx, 0, -0.4, rx, Math.max(1.2, rx * 0.28)); ctx.fill(); }
  /** A small seeded hash for scattered marks (a cell decides WHERE; the mark's own centre and radius WHAT, Figure_Doctrine §26m). */
  function hseed(s) { var h = 0x811c9dc5; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h >>> 0; }
  function lcg(s) { return (Math.imul(s, 1103515245) + 12345) >>> 0; }
  function eyeCol(L) { return L.family === 'cat' ? (L.pattern === 'plain' && lum(L.c1) > 200 ? L.c3 : (L.family === 'cat' && lum(L.c1) < 60 ? L.c3 : '#c8a830')) : (lum(L.c1) > 215 ? L.c3 : '#140e0a'); }

  /* ------------------------------------------------------------- plans --*/
  /**
   * Body plans for the furred families, in px at scale 1 (a 48 px tile). rx/ry = the torso's half length and
   * half height; leg = leg length below the torso; head = head radius; snout = how far the muzzle reaches;
   * ear = shape and size; tail = shape and size.
   */
  var PLANS = {
    rabbit: { rx: 6.6, ry: 4.6, leg: 1.6, legW: 2.0, head: 3.3, snout: 1.6, ear: 'long', earL: 7.2, earW: 1.9, tail: 'scut', tailL: 2.1, haunch: 3.9 },
    hare: { rx: 8.2, ry: 4.4, leg: 3.8, legW: 1.9, head: 3.3, snout: 2.0, ear: 'long', earL: 8.6, earW: 1.9, tail: 'scut', tailL: 2.0, haunch: 4.2, tips: true },
    squirrel: { rx: 4.6, ry: 3.2, leg: 1.6, legW: 1.5, head: 2.7, snout: 1.4, ear: 'tuft', earL: 2.4, earW: 1.3, tail: 'bushy', tailL: 9.5, tailW: 3.4 },
    hedgehog: { rx: 6.2, ry: 4.4, leg: 0.9, legW: 1.5, head: 2.3, snout: 2.6, ear: 'tiny', earL: 1.0, earW: 1.0, tail: 'none', spines: true },
    mouse: { rx: 3.1, ry: 2.2, leg: 0.6, legW: 0.9, head: 1.7, snout: 1.3, ear: 'round', earL: 1.4, earW: 1.4, tail: 'thin', tailL: 6.8 },
    rat: { rx: 4.9, ry: 2.9, leg: 0.9, legW: 1.2, head: 2.2, snout: 1.9, ear: 'round', earL: 1.5, earW: 1.5, tail: 'thin', tailL: 9.5 },
    cat: { rx: 7.6, ry: 3.8, leg: 4.6, legW: 1.8, head: 3.5, snout: 0.9, ear: 'point', earL: 3.0, earW: 2.0, tail: 'long', tailL: 11, tailW: 1.5 },
    fox: { rx: 8.8, ry: 3.7, leg: 5.0, legW: 1.6, head: 3.2, snout: 3.8, ear: 'point', earL: 3.8, earW: 2.0, tail: 'brush', tailL: 11, tailW: 3.1, socks: true },
    /* long and low with a big wedge head (a short domed body and a small head read as a tortoise, review 2 2026-10-24) */
    badger: { rx: 9.4, ry: 3.9, leg: 2.8, legW: 2.4, head: 3.7, snout: 3.4, ear: 'tiny', earL: 1.3, earW: 1.4, tail: 'stub', tailL: 2.2 }
  };

  /* ------------------------------------------------------- furred: side --*/
  /**
   * One furred animal seen from the side, facing LEFT, foot line at y = 0. `o` is the pose:
   *   lean   torso tilt (+ = front up), crouch 0..1 (legs fold), headDy/headDx (head moved from its rest),
   *   pitch  muzzle angle (+ = down), stride -1..1 (the walk), reach 0..1 (run extended) / gather 0..1 (run bunched),
   *   sit    on the haunches (the torso stands up off the hind end), ball (curled), loaf (a sleeping heap),
   *   earsUp 0..1, tailUp 0..1, eyesShut, pawUp (a fore paw lifted to the face), thump (a hind foot raised).
   */
  function furSide(ctx, L, P, o) {
    var c1 = L.c1, c2 = L.c2, c3 = L.c3, fam = L.family;
    var crouch = o.crouch || 0, leg = P.leg * (1 - crouch * 0.7);
    var reach = o.reach || 0, gather = o.gather || 0;
    var rx = P.rx * (1 + reach * 0.16 - gather * 0.14), ry = P.ry * (1 + gather * 0.08);
    var lean = o.lean || 0;
    var by = -leg - ry + (o.sit ? 0 : 0);
    var bx = 0;
    if (o.sit) { lean = 1.05; bx = 1.4; by = -leg - ry * 0.9; }
    if (o.loaf) { lean = 0; by = -ry * 0.82; leg = 0; }
    var cosL = Math.cos(lean), sinL = Math.sin(lean);
    /* points on the torso, in torso space (u along the body toward the HEAD = -x, v down) */
    function tp(u, v) { return [bx - u * cosL + v * sinL * 0, by - u * sinL * 1 + v * cosL]; }
    var front = tp(rx * 0.78, 0), rear = tp(-rx * 0.72, 0);
    if (o.sit) { rear = [bx + rx * 0.35, -leg - ry * 0.5]; }

    if (!o.noShadow) shadow(ctx, rx * (o.sit ? 0.8 : 1.05), 0.28);
    if (o.ball) { furBall(ctx, L, P, o); return; }

    /* a badger's legs are BLACK under the grizzled grey (grey legs and a boxy grey body read as a raccoon, review
     * 2026-10-24) */
    var legC = fam === 'fox' && P.socks ? c3 : (fam === 'badger' ? shade(c3, 22) : shade(c1, -12));
    var farLeg = shade(legC, -26);
    var st = o.stride || 0;
    /* ---- tail BEHIND (bushy and brush tails are drawn first so the body overlaps their root) */
    if (P.tail === 'bushy') bushyTail(ctx, L, P, rear, o);
    if (P.tail === 'brush') brushTail(ctx, L, P, rear, o);
    if (P.tail === 'long') longTail(ctx, L, P, rear, o);
    if (P.tail === 'thin') thinTail(ctx, L, P, rear, o);

    /* ---- far legs */
    if (!o.loaf) {
      if (o.sit) {
        /* a sitting animal's fore legs reach the GROUND (they floated a few px above it, a mid-body rectangle on
         * the cover's hero rabbit, review 2026-10-24) */
        limb(ctx, front[0] + 1.2, front[1] + ry * 0.4, Math.max(leg + ry * 0.7, -(front[1] + ry * 0.4) - 0.3), P.legW * 0.85, farLeg, 0.08);
      } else {
        limb(ctx, front[0] + 1.2, by + ry * 0.55, leg + ry * 0.45, P.legW * 0.9, farLeg, -0.22 * st - reach * 0.7 + gather * 0.5);
        if (!P.haunch) limb(ctx, rear[0] - 0.6, by + ry * 0.55, leg + ry * 0.45, P.legW * 0.9, farLeg, 0.22 * st + reach * 0.7 - gather * 0.6);
      }
    }
    /* ---- hind haunch (rabbits and hares): a big thigh and a long foot flat on the ground */
    if (P.haunch && !o.loaf) {
      var hx = rear[0] - (o.sit ? 0.6 : 0.8), hy = o.sit ? -P.haunch * 0.95 : by + ry * 0.25;
      var footX = hx - P.haunch * 0.4 + reach * 3.2 - gather * 2.4, footY = -0.8;
      /* the thump: the hind foot lifted high behind, with the strike drawn on the ground under it (a foot raised
       * 2 px read as the grazing pose, review 2026-10-24) */
      if (o.thump) { footX = hx + 2.6; footY = -4.4; }
      if (reach > 0) { footX = hx + 3.4; footY = -1.6 - reach; }
      ctx.save(); ctx.lineCap = 'round';
      ell(ctx, footX - 0.3, footY + 0.2, P.haunch * 0.75, 0.95, o.thump ? -0.5 : 0); ink(ctx, shade(c1, -18), 0.7);
      if (o.thump) {
        ctx.strokeStyle = 'rgba(70,52,30,0.85)'; ctx.lineWidth = 0.7;
        for (var tk = -1; tk <= 1; tk++) { ctx.beginPath(); ctx.moveTo(footX + tk * 1.7, -0.9 - (tk ? 0 : 0.5)); ctx.lineTo(footX + tk * 3.0, -2.4 - (tk ? 0 : 1.1)); ctx.stroke(); }
      }
      ctx.restore();
      ell(ctx, hx, hy, P.haunch, P.haunch * 0.9, 0.2); ink(ctx, coat(ctx, hx, hy, P.haunch, c1), 0.8);
    }
    /* ---- torso */
    ell(ctx, bx, by, rx, ry, lean);
    ink(ctx, coat(ctx, bx, by, Math.max(rx, ry), c1), 0.85);
    ctx.save(); ell(ctx, bx, by, rx, ry, lean); ctx.clip();
    furPattern(ctx, L, P, bx, by, rx, ry, 'side');
    /* the pale belly and chest along the underside */
    if (c2 && L.pattern !== 'plain' || fam === 'fox' || fam === 'badger') { ctx.fillStyle = mix(c2, c1, fam === 'badger' ? 0.65 : 0.15); ctx.globalAlpha = fam === 'badger' ? 0.6 : 0.85; ell(ctx, bx - rx * 0.25, by + ry * 0.95, rx * 0.85, ry * 0.42, lean); ctx.fill(); ctx.globalAlpha = 1; }
    ctx.restore();
    if (P.spines) spineFringe(ctx, L, P, bx, by, rx, ry, o);
    if (P.haunch && !o.loaf) { ctx.save(); ell(ctx, rear[0] - 0.8, o.sit ? -P.haunch * 0.95 : by + ry * 0.25, P.haunch * 0.92, P.haunch * 0.82, 0.2); ctx.fillStyle = coat(ctx, rear[0], by, P.haunch, c1); ctx.globalAlpha = 0.55; ctx.fill(); ctx.globalAlpha = 1; ctx.restore(); }
    /* ---- tail IN FRONT (a scut sits on the rump) */
    if (P.tail === 'scut') scut(ctx, L, P, rear, o, by, ry);
    if (P.tail === 'stub') { ell(ctx, rear[0] + rx * 0.24, by - ry * 0.3, P.tailL, P.tailL * 0.7, 0.4); ink(ctx, shade(c1, 10), 0.6); }
    /* ---- head position (needed for the neck) */
    var hdx = (o.headDx || 0), hdy = (o.headDy || 0);
    var hx0 = front[0] - P.head * 0.55 + hdx, hy0 = front[1] - ry * 0.55 + hdy;
    if (o.sit) { hx0 = front[0] - P.head * 0.15 + hdx; hy0 = front[1] - ry * 0.75 - P.head * 0.4 + hdy; }
    if (o.loaf) { hx0 = bx - rx * 0.85 + hdx; hy0 = by + ry * 0.05 + hdy; }
    /* ---- a neck: an upright body met the head as a ball on an egg (the hero rabbit, review 2026-10-24) */
    if (o.sit) { ell(ctx, (front[0] + hx0) / 2 + 0.4, (front[1] + hy0) / 2 + 0.6, P.head * 0.8, Math.max(P.head * 0.9, Math.abs(front[1] - hy0) * 0.62), 0.25); ctx.fillStyle = coat(ctx, hx0, hy0, P.head * 1.3, c1); ctx.fill(); }
    /* ---- near legs */
    if (!o.loaf) {
      if (o.sit) {
        var pawUp = o.pawUp ? -ry * 0.9 : 0;
        /* a rabbit's or hare's fore paws come down from LOW on the chest (from the shoulder they read as a post,
         * review 2 2026-10-24); a cat or fox sits on long straight fore legs */
        var foreY = P.haunch ? Math.max(front[1] + ry * 0.4, -(leg + ry * 0.75)) : front[1] + ry * 0.4;
        limb(ctx, front[0] - 0.4, (o.pawUp ? front[1] + ry * 0.4 : foreY) + pawUp, o.pawUp ? (leg + ry * 0.7) * 0.55 : Math.max(leg + ry * 0.7 * (P.haunch ? 0 : 1), -foreY - 0.2), P.legW, legC, o.pawUp ? -1.2 : 0.06);
      } else {
        limb(ctx, front[0] - 0.4, by + ry * 0.6, leg + ry * 0.4, P.legW, legC, 0.22 * st - reach * 0.8 + gather * 0.55);
        if (!P.haunch) limb(ctx, rear[0] + 0.4, by + ry * 0.6, leg + ry * 0.4, P.legW, legC, -0.22 * st + reach * 0.8 - gather * 0.7);
      }
    }
    /* ---- head: in profile, or turned to face the party (a cat watching you; a profile looked away, review 2026-10-24) */
    if (o.faceFront) frontHead(ctx, L, P, hx0 + P.head * 0.2, hy0 - 0.2);
    else furHead(ctx, L, P, hx0, hy0, o);
    /* the skull's lower outline across the neck read as a COLLAR (review 2 2026-10-24): coat over the joint */
    if (o.sit && !o.faceFront) { ell(ctx, hx0 + P.head * 0.35, hy0 + P.head * 0.78, P.head * 0.5, P.head * 0.26, 0.2); ctx.fillStyle = coat(ctx, hx0, hy0, P.head * 1.3, c1); ctx.fill(); }
  }

  /** A leg: a rounded stick from an attach point, swung by `ang` (+ = foot forward, toward the head). */
  function limb(ctx, x, y, len, w, col, ang) {
    ctx.save(); ctx.translate(x, y); ctx.rotate(ang || 0);
    ctx.beginPath();
    var r = w / 2;
    ctx.moveTo(-r, 0); ctx.lineTo(-r, len - r); ctx.quadraticCurveTo(-r, len, 0, len); ctx.quadraticCurveTo(r, len, r, len - r); ctx.lineTo(r, 0); ctx.closePath();
    ink(ctx, col, 0.65);
    ctx.restore();
  }

  function furHead(ctx, L, P, hx, hy, o) {
    var c1 = L.c1, c2 = L.c2, c3 = L.c3, fam = L.family, r = P.head;
    var pitch = o.pitch || 0;
    /* ears behind the head */
    earPair(ctx, L, P, hx, hy, o, true);
    /* muzzle: a pointed or blunt snout at the pitch angle */
    var sx = hx - r * 0.7 - P.snout * Math.cos(pitch), sy = hy + r * 0.2 + P.snout * Math.sin(pitch) * 1.1;
    ctx.beginPath();
    ctx.moveTo(hx - r * 0.2, hy - r * 0.62);
    ctx.quadraticCurveTo(sx - 0.2, sy - r * 0.55, sx - 0.4, sy);
    ctx.quadraticCurveTo(sx + 0.4, sy + r * 0.45, hx - r * 0.1, hy + r * 0.78);
    ctx.closePath();
    var muzzle = fam === 'fox' || fam === 'badger' ? c2 : shade(c1, 8);
    ink(ctx, coat(ctx, hx, hy, r, fam === 'fox' ? c1 : muzzle), 0.7);
    /* a badger's black stripe runs down the muzzle to the NOSE; stopping at the skull left a white snout and a
     * band round the eye only, which is a raccoon's mask (review 2026-10-24) */
    if (fam === 'badger') { ctx.save(); ctx.clip(); ctx.fillStyle = c3; badgerBand(ctx, hx, hy, r); ctx.restore(); }
    /* skull */
    ell(ctx, hx, hy, r, r * 0.9, 0);
    ink(ctx, coat(ctx, hx, hy, r, c1), 0.8);
    ctx.save(); ell(ctx, hx, hy, r, r * 0.9, 0); ctx.clip(); headMarks(ctx, L, P, hx, hy, r, 'side'); ctx.restore();
    if (fam === 'fox') { ctx.fillStyle = c2; ell(ctx, hx - r * 0.6, hy + r * 0.55, r * 0.75, r * 0.4, -0.2); ctx.fill(); }
    /* the near ear over the skull */
    earPair(ctx, L, P, hx, hy, o, false);
    /* nose, eye, whisker pad */
    ctx.fillStyle = fam === 'rabbit' || fam === 'mouse' || fam === 'rat' || fam === 'hare' ? '#c8848a' : '#1a120e';
    ell(ctx, sx - 0.1, sy - 0.15, Math.max(0.45, r * 0.16), Math.max(0.4, r * 0.13)); ctx.fill();
    if (o.eyesShut) { ctx.strokeStyle = shade(c1, -70); ctx.lineWidth = 0.6; ctx.beginPath(); ctx.arc(hx - r * 0.3, hy - r * 0.12, r * 0.24, 0.3, 2.8); ctx.stroke(); }
    else {
      ctx.fillStyle = eyeCol(L); ell(ctx, hx - r * 0.32, hy - r * 0.18, Math.max(0.55, r * 0.21), Math.max(0.6, r * 0.24)); ctx.fill();
      if (fam === 'cat' || fam === 'fox') { ctx.fillStyle = '#100a06'; ell(ctx, hx - r * 0.34, hy - r * 0.18, Math.max(0.2, r * 0.07), Math.max(0.5, r * 0.2)); ctx.fill(); }
      ctx.fillStyle = 'rgba(255,255,250,0.85)'; ell(ctx, hx - r * 0.38, hy - r * 0.27, Math.max(0.2, r * 0.07), Math.max(0.2, r * 0.07)); ctx.fill();
    }
  }

  function earPair(ctx, L, P, hx, hy, o, far) {
    var c1 = L.c1, c3 = L.c3, r = P.head, up = o.earsUp === undefined ? 0.6 : o.earsUp;
    var ox = far ? 0.9 : 0, col = far ? shade(c1, -24) : c1;
    if (P.ear === 'long') {
      /* upright when alert, laid back along the back at rest */
      var ang = -0.25 + (1 - up) * 1.05 + (far ? 0.12 : 0);
      ctx.save(); ctx.translate(hx + r * 0.25 + ox, hy - r * 0.55); ctx.rotate(ang);
      ell(ctx, 0, -P.earL * 0.5, P.earW, P.earL * 0.55, 0); ink(ctx, col, 0.7);
      if (!far) { ctx.fillStyle = '#d8a0a0'; ctx.globalAlpha = 0.55; ell(ctx, -0.2, -P.earL * 0.48, P.earW * 0.45, P.earL * 0.42, 0); ctx.fill(); ctx.globalAlpha = 1; }
      if (P.tips) { ctx.save(); ell(ctx, 0, -P.earL * 0.5, P.earW, P.earL * 0.55, 0); ctx.clip(); ctx.fillStyle = c3; ctx.fillRect(-P.earW * 2, -P.earL * 1.2, P.earW * 4, P.earL * 0.38); ctx.restore(); }
      ctx.restore(); return;
    }
    if (P.ear === 'point' || P.ear === 'tuft') {
      var h = P.earL * (0.75 + up * 0.35), w = P.earW;
      var ex = hx + r * 0.15 + ox * 0.8, ey = hy - r * 0.62;
      ctx.beginPath(); ctx.moveTo(ex - w, ey + 0.6); ctx.lineTo(ex - w * 0.15 + (1 - up) * 0.8, ey - h); ctx.lineTo(ex + w * 0.9, ey + 0.4); ctx.closePath();
      ink(ctx, col, 0.7);
      if (!far) { ctx.fillStyle = L.family === 'fox' ? '#24180f' : '#d89a96'; ctx.globalAlpha = L.family === 'fox' ? 0.8 : 0.5; ctx.beginPath(); ctx.moveTo(ex - w * 0.5, ey); ctx.lineTo(ex - w * 0.12, ey - h * 0.68); ctx.lineTo(ex + w * 0.4, ey); ctx.closePath(); ctx.fill(); ctx.globalAlpha = 1; }
      if (P.ear === 'tuft' && !far) { ctx.strokeStyle = shade(c1, -30); ctx.lineWidth = 0.6; ctx.beginPath(); ctx.moveTo(ex - w * 0.15, ey - h); ctx.lineTo(ex - w * 0.3, ey - h - 1.2); ctx.moveTo(ex - w * 0.1, ey - h); ctx.lineTo(ex + 0.3, ey - h - 1.1); ctx.stroke(); }
      return;
    }
    if (P.ear === 'round') {
      ell(ctx, hx + r * 0.3 + ox * 0.6, hy - r * 0.7, P.earW, P.earL * 0.95, 0.2); ink(ctx, col, 0.6);
      if (!far) { ctx.fillStyle = '#e0a4a0'; ctx.globalAlpha = 0.6; ell(ctx, hx + r * 0.3, hy - r * 0.7, P.earW * 0.55, P.earL * 0.55, 0.2); ctx.fill(); ctx.globalAlpha = 1; }
      return;
    }
    if (P.ear === 'tiny' && !far) {
      ell(ctx, hx + r * 0.35, hy - r * 0.68, P.earW, P.earL * 0.7, 0.3); ink(ctx, L.family === 'badger' ? '#f0ece4' : shade(c1, -10), 0.55);
    }
  }

  /** A badger's side stripe: from the nose tip, through the eye, widening back to the ear (one path, filled both on
   *  the skull and on the muzzle, so the two meet). */
  function badgerBand(ctx, hx, hy, r) {
    ctx.beginPath(); ctx.moveTo(hx - r * 2.6, hy + r * 0.05);
    ctx.quadraticCurveTo(hx - r * 0.4, hy - r * 0.75, hx + r * 1.1, hy - r * 0.6);
    ctx.lineTo(hx + r * 1.1, hy + r * 0.2);
    ctx.quadraticCurveTo(hx - r * 0.4, hy + r * 0.15, hx - r * 2.6, hy + r * 0.45);
    ctx.closePath(); ctx.fill();
  }

  function headMarks(ctx, L, P, hx, hy, r, view) {
    var fam = L.family;
    if (fam === 'badger') {
      /* the striped face: white head, a black stripe through each eye from muzzle to ear */
      ctx.fillStyle = L.c2; ctx.fillRect(hx - r * 2, hy - r * 2, r * 4, r * 4);
      ctx.fillStyle = L.c3;
      if (view === 'side') badgerBand(ctx, hx, hy, r);
      else { for (var s = -1; s <= 1; s += 2) { ctx.beginPath(); ctx.moveTo(hx + s * r * 0.18, hy + r * 0.9); ctx.lineTo(hx + s * r * 0.55, hy - r * 1.1); ctx.lineTo(hx + s * r * 0.95, hy - r * 1.0); ctx.lineTo(hx + s * r * 0.42, hy + r * 0.9); ctx.closePath(); ctx.fill(); } }
      return;
    }
    if (L.pattern === 'tabby' || L.pattern === 'tortie') {
      ctx.strokeStyle = L.c2; ctx.lineWidth = 0.55; ctx.globalAlpha = 0.85;
      for (var k = 0; k < 3; k++) { ctx.beginPath(); ctx.moveTo(hx - r * 0.3 + k * r * 0.25, hy - r * 0.95); ctx.lineTo(hx - r * 0.15 + k * r * 0.25, hy - r * 0.45); ctx.stroke(); }
      ctx.globalAlpha = 1;
    }
    if (L.pattern === 'tuxedo') { ctx.fillStyle = L.c2; ell(ctx, hx - r * (view === 'side' ? 0.55 : 0), hy + r * 0.62, r * 0.6, r * 0.42); ctx.fill(); }
    if (L.pattern === 'calico') { ctx.fillStyle = L.c2; ell(ctx, hx + r * 0.45, hy - r * 0.5, r * 0.55, r * 0.5); ctx.fill(); ctx.fillStyle = L.c3; ell(ctx, hx - r * 0.5, hy - r * 0.62, r * 0.4, r * 0.35); ctx.fill(); }
  }

  /** Coat patterns over the torso. Every value named in HedgerowCore.LOOKS is drawn here (suite: axis reads). */
  function furPattern(ctx, L, P, bx, by, rx, ry, view) {
    var s = hseed(L.id), k, x, y;
    switch (L.pattern) {
      case 'agouti':
        /* ticked fur: short dark and light flecks laid along the body */
        for (k = 0; k < 26; k++) {
          s = lcg(s); x = bx - rx + (s % 1000) / 1000 * rx * 2; s = lcg(s); y = by - ry + (s % 1000) / 1000 * ry * 1.4;
          ctx.strokeStyle = (k & 1) ? shade(L.c1, -38) : shade(L.c1, 34); ctx.lineWidth = 0.5; ctx.globalAlpha = 0.7;
          ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 1.1, y + 0.35); ctx.stroke();
        }
        ctx.globalAlpha = 1; break;
      case 'tabby':
        ctx.strokeStyle = L.c2; ctx.lineWidth = Math.max(0.7, ry * 0.2); ctx.globalAlpha = 0.85;
        for (k = -3; k <= 3; k++) { x = bx + k * rx * 0.26; ctx.beginPath(); ctx.moveTo(x - 0.6, by - ry * 1.1); ctx.quadraticCurveTo(x + 0.9, by - ry * 0.2, x - 0.2, by + ry * 0.5); ctx.stroke(); }
        ctx.globalAlpha = 1; break;
      case 'calico':
        ctx.fillStyle = L.c2; ell(ctx, bx - rx * 0.3, by - ry * 0.45, rx * 0.42, ry * 0.55, 0.3); ctx.fill();
        ctx.fillStyle = L.c3; ell(ctx, bx + rx * 0.45, by - ry * 0.35, rx * 0.32, ry * 0.5, -0.3); ctx.fill();
        break;
      case 'tortie':
        for (k = 0; k < 9; k++) { s = lcg(s); x = bx - rx + (s % 1000) / 1000 * rx * 2; s = lcg(s); y = by - ry + (s % 1000) / 1000 * ry * 1.6; ctx.fillStyle = L.c2; ctx.globalAlpha = 0.85; ell(ctx, x, y, 1.1 + (s & 3) * 0.4, 0.9 + ((s >>> 3) & 3) * 0.3, (s & 7) * 0.4); ctx.fill(); }
        ctx.globalAlpha = 1; break;
      case 'tuxedo':
        ctx.fillStyle = L.c2; ell(ctx, bx - rx * 0.55, by + ry * 0.55, rx * 0.5, ry * 0.7, 0); ctx.fill();
        break;
      case 'belly':
        ctx.fillStyle = L.c2; ell(ctx, bx - rx * 0.1, by + ry * 0.85, rx * 0.95, ry * 0.5, 0); ctx.fill();
        break;
      case 'fox':
        ctx.fillStyle = shade(L.c1, -26); ctx.globalAlpha = 0.5; ell(ctx, bx + rx * 0.1, by - ry * 0.7, rx * 0.7, ry * 0.35, 0); ctx.fill(); ctx.globalAlpha = 1;
        break;
      case 'badger':
        /* grizzled grey: dark-tipped guard hairs, darker flanks low down */
        ctx.fillStyle = shade(L.c3, 30); ctx.globalAlpha = 0.45; ell(ctx, bx, by + ry * 0.75, rx * 1.05, ry * 0.5, 0); ctx.fill(); ctx.globalAlpha = 1;
        for (k = 0; k < 22; k++) { s = lcg(s); x = bx - rx + (s % 1000) / 1000 * rx * 2; s = lcg(s); y = by - ry + (s % 1000) / 1000 * ry; ctx.strokeStyle = (k & 1) ? shade(L.c1, -45) : shade(L.c1, 40); ctx.lineWidth = 0.5; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 1.2, y + 0.4); ctx.stroke(); }
        break;
      case 'spines': break;   /* drawn by spineFringe on top of the outline */
      case 'plain': default: break;
    }
  }

  /** A hedgehog's spines: a fringe of short strokes over the back, banded pale-tipped, pointing back and up. */
  function spineFringe(ctx, L, P, bx, by, rx, ry, o) {
    var s = hseed(L.id + 'sp');
    ctx.save(); ctx.lineCap = 'round';
    var n = 46;
    for (var k = 0; k < n; k++) {
      var t = k / (n - 1);
      var a = Math.PI * (1.02 + t * 0.98);                 /* from the head round the back to the rump */
      s = lcg(s);
      var jitter = ((s % 100) / 100 - 0.5) * 0.12;
      var px = bx + Math.cos(a + jitter) * rx * 0.96, py = by + Math.sin(a + jitter) * ry * 0.96;
      if (py > by + ry * 0.3) continue;
      /* bristling: longer spines standing nearly straight OUT (one more px sweeping back read as snuffling, review 2026-10-24) */
      var len = 2.2 + (s >>> 8) % 10 / 10 * 1.2 + (o.bristle ? 2.0 : 0);
      var dirA = a + (o.bristle ? 0.12 : 0.55);              /* spines sweep backward, or stand up */
      var ex = px + Math.cos(dirA) * len, ey = py + Math.sin(dirA) * len;
      ctx.strokeStyle = shade(L.c1, -30); ctx.lineWidth = 0.95; ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(ex, ey); ctx.stroke();
      ctx.strokeStyle = L.c2; ctx.lineWidth = 0.6; ctx.beginPath(); ctx.moveTo(px + (ex - px) * 0.62, py + (ey - py) * 0.62); ctx.lineTo(ex, ey); ctx.stroke();
    }
    /* an inner coat of spine tips over the back */
    for (var j = 0; j < 30; j++) {
      s = lcg(s); var u = (s % 1000) / 1000, v = ((s >>> 10) % 1000) / 1000;
      var qx = bx - rx * 0.75 + u * rx * 1.5, qy = by - ry * 0.85 + v * ry * 0.9;
      ctx.strokeStyle = (j & 1) ? L.c2 : shade(L.c1, -36); ctx.lineWidth = 0.55;
      ctx.beginPath(); ctx.moveTo(qx, qy); ctx.lineTo(qx + 1.2, qy - 0.7); ctx.stroke();
    }
    ctx.restore();
  }

  /** A hedgehog rolled up: a ball of spines, a dark seam where the face is tucked in. */
  function furBall(ctx, L, P, o) {
    var R = P.ry * 1.18, cy = -R + 0.4;
    ell(ctx, 0, cy, R, R * 0.92); ink(ctx, coat(ctx, 0, cy, R, shade(L.c1, -10)), 0.8);
    var s = hseed(L.id + 'ball');
    ctx.save(); ctx.lineCap = 'round';
    for (var k = 0; k < 64; k++) {
      var a = k / 64 * TAU; s = lcg(s);
      var len = 2.1 + ((s % 10) / 10) * 1.1;
      var px = Math.cos(a) * R * 0.92, py = cy + Math.sin(a) * R * 0.86;
      var ex = px + Math.cos(a + 0.3) * len, ey = py + Math.sin(a + 0.3) * len;
      if (ey > -0.2) continue;
      ctx.strokeStyle = shade(L.c1, -32); ctx.lineWidth = 0.95; ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(ex, ey); ctx.stroke();
      ctx.strokeStyle = L.c2; ctx.lineWidth = 0.6; ctx.beginPath(); ctx.moveTo(px + (ex - px) * 0.6, py + (ey - py) * 0.6); ctx.lineTo(ex, ey); ctx.stroke();
    }
    for (var j = 0; j < 26; j++) { s = lcg(s); var u = (s % 1000) / 1000 * TAU, rr = ((s >>> 10) % 1000) / 1000 * R * 0.75; ctx.strokeStyle = (j & 1) ? L.c2 : shade(L.c1, -40); ctx.lineWidth = 0.55; var qx = Math.cos(u) * rr, qy = cy + Math.sin(u) * rr; ctx.beginPath(); ctx.moveTo(qx, qy); ctx.lineTo(qx + 1, qy - 0.8); ctx.stroke(); }
    if (o.peek) { ctx.fillStyle = shade(L.c2, -30); ell(ctx, -R * 0.55, cy + R * 0.45, R * 0.42, R * 0.26, -0.3); ctx.fill(); ctx.fillStyle = '#1a120e'; ell(ctx, -R * 0.8, cy + R * 0.5, 0.5, 0.45); ctx.fill(); }
    ctx.restore();
  }

  function scut(ctx, L, P, rear, o, by, ry) {
    var white = L.family === 'hare' ? '#f2efe8' : (lum(L.c1) > 200 ? L.c2 : '#f4f1ea');
    var x = rear[0] + P.rx * 0.18, y = (o.sit ? -P.haunch * 0.55 : by - ry * 0.25);
    var R = P.tailL * ((o.reach || o.gather) ? 1.25 : 1) * (L.family === 'hare' ? 0.8 : 1);
    ell(ctx, x, y, R, R * 0.9); ink(ctx, white, 0.6);
    /* a hare's scut is dark on top: a thin cap along the upper edge (a half-black disc read as an EYE, contact sheet 2026-10-24) */
    if (L.family === 'hare') { ctx.save(); ell(ctx, x, y, R, R * 0.9); ctx.clip(); ctx.fillStyle = L.c3; ell(ctx, x + R * 0.35, y - R * 0.95, R * 0.95, R * 0.45, 0.4); ctx.fill(); ctx.restore(); }
  }

  /** A squirrel's tail: a big S-curve plume rising over the back. Up (alert, sitting) or arched (foraging) or streaming (running). */
  function bushyTail(ctx, L, P, rear, o) {
    var len = P.tailL, w = P.tailW, x = rear[0] + 0.6, y = rear[1] + 0.8;
    var run = (o.reach || o.gather) ? 1 : 0;
    ctx.save();
    ctx.beginPath();
    if (run) {
      ctx.moveTo(x, y - 1.2);
      ctx.bezierCurveTo(x + len * 0.5, y - w * 1.4, x + len * 0.9, y - w * 0.4, x + len * 1.05, y - w * 1.6);
      ctx.bezierCurveTo(x + len * 0.85, y + w * 0.6, x + len * 0.45, y + w * 0.5, x, y + 1.0);
    } else {
      var up = o.tailUp === undefined ? 1 : o.tailUp;
      ctx.moveTo(x - 0.8, y);
      ctx.bezierCurveTo(x + w * 1.6, y - len * 0.25, x + w * 0.9 - (1 - up) * 2, y - len * 0.75, x + w * 0.2 - (1 - up) * 3, y - len * 0.95);
      ctx.bezierCurveTo(x - w * 0.9 - (1 - up) * 3, y - len * 1.05, x - w * 1.4 - (1 - up) * 3, y - len * 0.7, x - w * 0.4 - (1 - up) * 2, y - len * 0.72);
      ctx.bezierCurveTo(x + w * 0.2, y - len * 0.6, x + w * 0.3, y - len * 0.25, x - w * 0.6, y - 0.6);
    }
    ctx.closePath();
    ink(ctx, coat(ctx, x + w, y - len * 0.5, len * 0.6, L.c1), 0.75);
    /* the fluff: a paler edge of hair along the outer curve */
    ctx.clip();
    ctx.strokeStyle = L.c3; ctx.globalAlpha = 0.55; ctx.lineWidth = 1.1;
    ctx.stroke();
    ctx.restore();
  }
  /** A fox's brush: thick, low, with its pale tip. */
  function brushTail(ctx, L, P, rear, o) {
    var len = P.tailL, w = P.tailW, x = rear[0] + 0.4, y = rear[1] - 0.6;
    var droop = (o.reach || o.gather) ? 0.1 : 0.45;
    ctx.save();
    ctx.beginPath(); ctx.moveTo(x, y - w * 0.4);
    ctx.bezierCurveTo(x + len * 0.4, y - w * 0.8, x + len * 0.8, y + len * droop * 0.4 - w, x + len, y + len * droop);
    ctx.bezierCurveTo(x + len * 0.7, y + len * droop + w * 0.6, x + len * 0.3, y + w * 0.9, x, y + w * 0.5);
    ctx.closePath();
    ink(ctx, coat(ctx, x + len * 0.5, y, len * 0.6, L.c1), 0.75);
    ctx.clip(); ctx.fillStyle = L.c2; ell(ctx, x + len, y + len * droop, w * 1.1, w * 0.9, 0); ctx.fill();
    ctx.restore();
  }
  /** A cat's tail: long, curving up at the end (a question mark when it walks, low when it sits). */
  function longTail(ctx, L, P, rear, o) {
    var len = P.tailL, x = rear[0] + 0.2, y = rear[1] - 1;
    var up = o.tailUp === undefined ? 0.7 : o.tailUp;
    ctx.save(); ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(x, y);
    if (o.sit || o.loaf) { ctx.bezierCurveTo(x + 3, y + 4, x - 2, 0 - 0.8, x - P.rx * 1.2, -1.0); }
    else ctx.bezierCurveTo(x + len * 0.45, y - 1 + (1 - up) * 3, x + len * 0.75, y - len * 0.5 * up, x + len * 0.55, y - len * 0.85 * up - 1);
    ctx.strokeStyle = LINE; ctx.lineWidth = P.tailW + 1.4; ctx.stroke();
    ctx.strokeStyle = L.pattern === 'tabby' ? shade(L.c1, 6) : L.c1; ctx.lineWidth = P.tailW; ctx.stroke();
    if (L.pattern === 'tabby' || L.pattern === 'tortie') { ctx.setLineDash([1, 1.6]); ctx.strokeStyle = L.c2; ctx.stroke(); ctx.setLineDash([]); }
    ctx.restore();
  }
  /** A mouse's or rat's tail: thin and naked, trailing on the ground. */
  function thinTail(ctx, L, P, rear, o) {
    var len = P.tailL, x = rear[0] + 0.4, y = rear[1] + P.ry * 0.3;
    var sw = (o.reach ? -1 : 1) * 1.6;
    ctx.save(); ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(x, y);
    ctx.bezierCurveTo(x + len * 0.35, y + 1.6, x + len * 0.6, y - sw, x + len, y + 0.6 - sw * 0.4);
    ctx.strokeStyle = LINE; ctx.lineWidth = 1.5; ctx.stroke();
    ctx.strokeStyle = L.c3; ctx.lineWidth = 0.75; ctx.stroke();
    ctx.restore();
  }

  /* ------------------------------------------------- furred: front, back --*/
  /** Facing the camera (down). `step` -1, 0, 1. */
  function furFront(ctx, L, P, step, back) {
    var c1 = L.c1, c2 = L.c2, fam = L.family;
    var w = P.ry * 1.25, h = P.ry * 1.05, leg = P.leg, by = -leg - h;
    shadow(ctx, w * 1.15, 0.28);
    var legC = fam === 'fox' && P.socks ? L.c3 : shade(c1, -12);
    if (back) {
      /* from behind: the tail is the face of the animal */
      limb(ctx, -w * 0.5, by + h * 0.5, leg + h * 0.4 + (step > 0 ? -0.6 : 0), P.legW, legC, 0);
      limb(ctx, w * 0.5, by + h * 0.5, leg + h * 0.4 + (step < 0 ? -0.6 : 0), P.legW, legC, 0);
      if (P.tail === 'thin') { ctx.save(); ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(0, by + h * 0.6); ctx.quadraticCurveTo(step * 1.5, by + h + 2, -step, -0.2); ctx.strokeStyle = LINE; ctx.lineWidth = 1.5; ctx.stroke(); ctx.strokeStyle = L.c3; ctx.lineWidth = 0.75; ctx.stroke(); ctx.restore(); }
      /* a squirrel's plume rises BEHIND it and to one side, so the back, head and ears still read from behind
       * (drawn over the body it hid the whole animal, contact sheet 2026-10-24) */
      if (P.tail === 'bushy') { var tx0 = w * 0.55; ctx.beginPath(); ctx.moveTo(tx0 - P.tailW * 0.4, by + h * 0.5); ctx.bezierCurveTo(tx0 + P.tailW * 1.5, by - h * 0.4, tx0 + P.tailW * 0.2, by - P.tailL * 0.8, tx0 + P.tailW * 0.6 + step * 0.4, by - P.tailL); ctx.bezierCurveTo(tx0 + P.tailW * 2.2, by - P.tailL * 0.9, tx0 + P.tailW * 2.4, by - h * 0.2, tx0 + P.tailW * 0.5, by + h * 0.5); ctx.closePath(); ink(ctx, coat(ctx, tx0 + P.tailW, by - P.tailL * 0.5, P.tailL * 0.5, c1), 0.75); }
      ell(ctx, 0, by, w, h); ink(ctx, coat(ctx, 0, by, Math.max(w, h), c1), 0.85);
      ctx.save(); ell(ctx, 0, by, w, h); ctx.clip(); furPattern(ctx, L, P, 0, by, w * 1.4, h, 'back'); ctx.restore();
      if (P.spines) spineDome(ctx, L, 0, by, w, h);
      /* head from behind with the ears */
      var hy = by - h * 0.75;
      backEars(ctx, L, P, 0, hy);
      ell(ctx, 0, hy, P.head * 0.9, P.head * 0.75); ink(ctx, coat(ctx, 0, hy, P.head, c1), 0.7);
      if (fam === 'badger') { ctx.save(); ell(ctx, 0, hy, P.head * 0.9, P.head * 0.75); ctx.clip(); ctx.fillStyle = L.c2; ctx.fillRect(-0.7, hy - P.head, 1.4, P.head * 2); ctx.restore(); }
      if (P.tail === 'scut') { var R = P.tailL * (fam === 'hare' ? 0.95 : 1.15); ell(ctx, 0, by + h * 0.35, R, R * 0.9); ink(ctx, L.family === 'hare' ? '#f2efe8' : (lum(c1) > 200 ? L.c2 : '#f4f1ea'), 0.6); if (fam === 'hare') { ctx.save(); ell(ctx, 0, by + h * 0.35, R, R * 0.9); ctx.clip(); ctx.fillStyle = L.c3; ell(ctx, 0, by + h * 0.35 - R * 0.95, R * 0.9, R * 0.42); ctx.fill(); ctx.restore(); } }
      if (P.tail === 'stub') { ell(ctx, 0, by + h * 0.25, P.tailL, P.tailL * 0.8); ink(ctx, shade(c1, 12), 0.6); }
      if (P.tail === 'brush') { ctx.beginPath(); ctx.moveTo(-P.tailW * 0.6, by + h * 0.3); ctx.quadraticCurveTo(-P.tailW * 1.2 + step, by + h + P.tailL * 0.4, step * 0.8, -0.3); ctx.quadraticCurveTo(P.tailW * 1.2 + step, by + h + P.tailL * 0.4, P.tailW * 0.6, by + h * 0.3); ctx.closePath(); ink(ctx, coat(ctx, 0, by + h, P.tailL * 0.5, c1), 0.75); ctx.fillStyle = L.c2; ell(ctx, step * 0.8, -1.4, P.tailW * 0.7, 1.4); ctx.fill(); }
      if (P.tail === 'long') { ctx.save(); ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(0, by + h * 0.2); ctx.bezierCurveTo(step * 2, by - h * 1.2, step * 3 + 2, by - h * 2.2, step * 2 + 3, by - h * 2.6); ctx.strokeStyle = LINE; ctx.lineWidth = P.tailW + 1.4; ctx.stroke(); ctx.strokeStyle = c1; ctx.lineWidth = P.tailW; ctx.stroke(); ctx.restore(); }
      return;
    }
    /* front: body behind, head in front and low, fore legs */
    if (P.tail === 'bushy') { ctx.beginPath(); ctx.moveTo(-P.tailW * 0.5, by); ctx.bezierCurveTo(-P.tailW * 1.4, by - P.tailL * 0.6, -P.tailW * 0.3, by - P.tailL, P.tailW * 0.4, by - P.tailL * 0.95); ctx.bezierCurveTo(P.tailW * 1.4, by - P.tailL * 0.8, P.tailW * 0.9, by - h, P.tailW * 0.4, by); ctx.closePath(); ink(ctx, coat(ctx, 0, by - P.tailL * 0.5, P.tailL * 0.5, c1), 0.75); }
    if (P.tail === 'long') { ctx.save(); ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(w * 0.4, by); ctx.bezierCurveTo(w * 1.2, by - h * 1.4, w * 0.8, by - h * 2.2, w * 0.3 + step, by - h * 2.5); ctx.strokeStyle = LINE; ctx.lineWidth = P.tailW + 1.4; ctx.stroke(); ctx.strokeStyle = c1; ctx.lineWidth = P.tailW; ctx.stroke(); ctx.restore(); }
    ell(ctx, 0, by - h * 0.1, w, h); ink(ctx, coat(ctx, 0, by, Math.max(w, h), c1), 0.85);
    if (P.spines) spineDome(ctx, L, 0, by - h * 0.1, w, h);
    var fl = leg + h * 0.35;
    limb(ctx, -w * 0.42, by + h * 0.45, fl + (step > 0 ? -0.7 : 0), P.legW, legC, 0);
    limb(ctx, w * 0.42, by + h * 0.45, fl + (step < 0 ? -0.7 : 0), P.legW, legC, 0);
    /* chest */
    if (fam === 'fox' || fam === 'cat' && (L.pattern === 'tuxedo' || L.pattern === 'calico') || L.pattern === 'belly') { ctx.fillStyle = L.c2; ell(ctx, 0, by + h * 0.25, w * 0.42, h * 0.55); ctx.fill(); }
    frontHead(ctx, L, P, 0, by - h * 0.15 + (P.spines ? h * 0.35 : 0));
  }

  /** A head seen face-on: ears, skull, face marks, muzzle, nose and two eyes. One function for the front view and
   *  for a sitting animal that turns its face to the camera (wing §11: one drawing, two callers). */
  function frontHead(ctx, L, P, hx, hy) {
    var c1 = L.c1, fam = L.family, r = P.head;
    frontEars(ctx, L, P, hx, hy);
    ell(ctx, hx, hy, r, r * 0.92); ink(ctx, coat(ctx, hx, hy, r, c1), 0.8);
    ctx.save(); ell(ctx, hx, hy, r, r * 0.92); ctx.clip(); headMarks(ctx, L, P, hx, hy, r, 'front'); ctx.restore();
    var mz = fam === 'fox' ? L.c2 : (fam === 'badger' ? L.c2 : shade(c1, 14));
    ell(ctx, hx, hy + r * 0.45, r * (P.snout > 2.5 ? 0.42 : 0.5), r * (P.snout > 2.5 ? 0.55 : 0.36)); ink(ctx, mz, 0.55);
    ctx.fillStyle = fam === 'rabbit' || fam === 'mouse' || fam === 'rat' || fam === 'hare' ? '#c8848a' : '#1a120e';
    ell(ctx, hx, hy + r * (P.snout > 2.5 ? 0.82 : 0.5), Math.max(0.45, r * 0.15), Math.max(0.4, r * 0.12)); ctx.fill();
    ctx.fillStyle = eyeCol(L);
    for (var e = -1; e <= 1; e += 2) { ell(ctx, hx + e * r * 0.42, hy - r * 0.12, Math.max(0.55, r * 0.19), Math.max(0.6, r * 0.22)); ctx.fill(); }
    if (fam === 'cat' || fam === 'fox') { ctx.fillStyle = '#100a06'; for (var e1 = -1; e1 <= 1; e1 += 2) { ell(ctx, hx + e1 * r * 0.42, hy - r * 0.12, Math.max(0.2, r * 0.06), Math.max(0.5, r * 0.19)); ctx.fill(); } }
    ctx.fillStyle = 'rgba(255,255,250,0.85)';
    for (var e2 = -1; e2 <= 1; e2 += 2) { ell(ctx, hx + e2 * r * 0.42 - r * 0.06, hy - r * 0.2, Math.max(0.2, r * 0.07), Math.max(0.2, r * 0.07)); ctx.fill(); }
  }

  function frontEars(ctx, L, P, hx, hy) {
    var r = P.head, c1 = L.c1;
    for (var s = -1; s <= 1; s += 2) {
      if (P.ear === 'long') { ctx.save(); ctx.translate(hx + s * r * 0.4, hy - r * 0.6); ctx.rotate(s * 0.18); ell(ctx, 0, -P.earL * 0.5, P.earW, P.earL * 0.55, 0); ink(ctx, c1, 0.7); ctx.fillStyle = '#d8a0a0'; ctx.globalAlpha = 0.55; ell(ctx, 0, -P.earL * 0.48, P.earW * 0.45, P.earL * 0.42, 0); ctx.fill(); ctx.globalAlpha = 1; if (P.tips) { ctx.save(); ell(ctx, 0, -P.earL * 0.5, P.earW, P.earL * 0.55, 0); ctx.clip(); ctx.fillStyle = L.c3; ctx.fillRect(-P.earW * 2, -P.earL * 1.2, P.earW * 4, P.earL * 0.38); ctx.restore(); } ctx.restore(); }
      else if (P.ear === 'point' || P.ear === 'tuft') { var ex = hx + s * r * 0.55, ey = hy - r * 0.5; ctx.beginPath(); ctx.moveTo(ex - s * P.earW * 0.9, ey + 0.4); ctx.lineTo(ex + s * 0.4, ey - P.earL); ctx.lineTo(ex + s * P.earW * 0.7, ey + 0.8); ctx.closePath(); ink(ctx, c1, 0.7); ctx.fillStyle = L.family === 'fox' ? '#24180f' : '#d89a96'; ctx.globalAlpha = 0.6; ctx.beginPath(); ctx.moveTo(ex - s * P.earW * 0.35, ey + 0.2); ctx.lineTo(ex + s * 0.3, ey - P.earL * 0.7); ctx.lineTo(ex + s * P.earW * 0.35, ey + 0.4); ctx.closePath(); ctx.fill(); ctx.globalAlpha = 1; }
      else if (P.ear === 'round') { ell(ctx, hx + s * r * 0.75, hy - r * 0.6, P.earW, P.earL); ink(ctx, c1, 0.6); ctx.fillStyle = '#e0a4a0'; ctx.globalAlpha = 0.6; ell(ctx, hx + s * r * 0.75, hy - r * 0.6, P.earW * 0.55, P.earL * 0.6); ctx.fill(); ctx.globalAlpha = 1; }
      else if (P.ear === 'tiny') { ell(ctx, hx + s * r * 0.7, hy - r * 0.62, P.earW, P.earL * 0.7); ink(ctx, L.family === 'badger' ? '#f0ece4' : shade(c1, -10), 0.55); }
    }
  }
  function backEars(ctx, L, P, hx, hy) { frontEars(ctx, L, P, hx, hy); }
  /** A hedgehog seen end-on: the spine dome over the body. */
  function spineDome(ctx, L, cx, cy, w, h) {
    var s = hseed(L.id + 'dome');
    ctx.save(); ctx.lineCap = 'round';
    for (var k = 0; k < 40; k++) {
      var a = Math.PI * (1.0 + k / 39); s = lcg(s);
      var px = cx + Math.cos(a) * w * 0.95, py = cy + Math.sin(a) * h * 0.95, len = 2 + (s % 10) / 10;
      var ex = px + Math.cos(a) * len, ey = py + Math.sin(a) * len - 0.4;
      ctx.strokeStyle = shade(L.c1, -30); ctx.lineWidth = 0.9; ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(ex, ey); ctx.stroke();
      ctx.strokeStyle = L.c2; ctx.lineWidth = 0.55; ctx.beginPath(); ctx.moveTo(px + (ex - px) * 0.6, py + (ey - py) * 0.6); ctx.lineTo(ex, ey); ctx.stroke();
    }
    for (var j = 0; j < 24; j++) { s = lcg(s); var qx = cx - w * 0.8 + (s % 1000) / 1000 * w * 1.6, qy = cy - h * 0.85 + ((s >>> 10) % 1000) / 1000 * h * 1.1; ctx.strokeStyle = (j & 1) ? L.c2 : shade(L.c1, -36); ctx.lineWidth = 0.5; ctx.beginPath(); ctx.moveTo(qx, qy); ctx.lineTo(qx + 0.4, qy - 1); ctx.stroke(); }
    ctx.restore();
  }

  /* ------------------------------------------------------ furred: poses --*/
  /**
   * The six side poses of each furred family, in HedgerowCore's slot order:
   *   CALM_A, CALM_B, ALERT, F1, F2, F3.
   */
  var POSES = {
    rabbit: [{ pitch: 0.9, headDy: 2.2, headDx: -0.6, earsUp: 0.15, crouch: 0.3 }, { crouch: 0.5, earsUp: 0.05, lean: 0.05 }, { sit: true, earsUp: 1 }, { reach: 1, earsUp: 0.2, lean: -0.08 }, { gather: 1, earsUp: 0.3, lean: 0.15 }, { thump: true, earsUp: 1, crouch: 0.2, lean: 0.1 }],
    hare: [{ pitch: 0.9, headDy: 2.4, headDx: -0.6, earsUp: 0.2, crouch: 0.2 }, { crouch: 0.75, earsUp: 0, lean: -0.04 }, { sit: true, earsUp: 1 }, { reach: 1, earsUp: 0.1, lean: -0.1 }, { gather: 1, earsUp: 0.2, lean: 0.12 }, { sit: true, earsUp: 1 }],
    squirrel: [{ pitch: 0.8, headDy: 1.6, headDx: -0.4, tailUp: 0.85 }, { sit: true, pawUp: true, tailUp: 1 }, { sit: true, tailUp: 0.6 }, { reach: 1 }, { gather: 1 }, { climb: true }],
    hedgehog: [{ pitch: 0.7, headDy: 1.0, headDx: -0.8 }, { pitch: 0.2 }, { bristle: true, pitch: 0.6, headDy: 0.8, headDx: 1.2, crouch: 0.5 }, { ball: true }, { ball: true, peek: true }, { pitch: 0.2 }],
    mouse: [{ pitch: -0.5, headDy: -0.8, headDx: -0.3 }, { sit: true, pawUp: true }, { sit: true }, { reach: 1 }, { gather: 1 }, { peekOut: true }],
    rat: [{ pitch: -0.4, headDy: -0.8, headDx: -0.3 }, { sit: true, pawUp: true }, { sit: true }, { reach: 1 }, { gather: 1 }, { peekOut: true }],
    /* calm B is a cat WASHING (a paw to its face, eyes shut); alert is sitting tall, ears up, eyes open (the two
     * sitting poses were one drawing, g4 plate 2026-10-24) */
    /* alert turns the cat's FACE to the camera: it is watching the party (review 2026-10-24) */
    cat: [{ loaf: true, eyesShut: true, earsUp: 0.9, headDy: -1.3 }, { sit: true, pawUp: true, eyesShut: true, tailUp: 0, earsUp: 0.3 }, { sit: true, earsUp: 1, headDy: -1.2, faceFront: true }, { stride: 1, tailUp: 0.4 }, { stride: -1, tailUp: 0.4 }, { tailUp: 1 }],
    /* nosing: the muzzle down at the ground; alert: the head UP and ears pricked (they were one drawing, review 2026-10-24) */
    fox: [{ pitch: 1.35, headDy: 4.4, headDx: -1.8, earsUp: 0.4 }, { sit: true, earsUp: 0.7 }, { earsUp: 1, headDy: -2.6, headDx: 0.6, pitch: -0.25 }, { reach: 1, lean: -0.05 }, { gather: 1, lean: 0.08 }, { earsUp: 1 }],
    badger: [{ pitch: 0.8, headDy: 1.4, headDx: -0.8 }, { pitch: 1.0, headDy: 2.0, crouch: 0.3, lean: -0.15 }, { pitch: -0.5, headDy: -2.6, headDx: 0.6, lean: 0.1 }, { reach: 1 }, { gather: 1 }, { pitch: 0.3 }]
  };

  /**
   * A squirrel climbing its trunk, in PROFILE and turned head-up: the same side view every other pose uses, so the
   * tufted ears, the eye and the plume read as a squirrel. Seen from behind it read as an ant, then a bear cub and a
   * carrot (two reviews, 2026-10-24). Feet grip the trunk line at x ~ 0; the plume hangs below and to the side;
   * the two cells (`which`) swap the legs.
   */
  function climber(ctx, L, P, which) {
    ctx.save();
    ctx.translate(-P.leg - P.ry * 0.6, -15);
    ctx.rotate(Math.PI / 2);   /* the side view faces LEFT; a quarter turn clockwise points the head UP */
    furSide(ctx, L, P, { stride: which ? 1 : -1, tailUp: 0.35, earsUp: 1, noShadow: true });
    ctx.restore();
  }

  /** A mouse's or rat's head and fore paws looking out of its hole (the hole is drawn under it by the layer). */
  function peeker(ctx, L, P) {
    var r = P.head * 1.05, hy = -r * 0.9;
    frontEars(ctx, L, P, 0, hy);
    ell(ctx, 0, hy, r, r * 0.9); ink(ctx, coat(ctx, 0, hy, r, L.c1), 0.75);
    ell(ctx, 0, hy + r * 0.45, r * 0.45, r * 0.32); ink(ctx, shade(L.c1, 14), 0.5);
    ctx.fillStyle = '#c8848a'; ell(ctx, 0, hy + r * 0.55, 0.45, 0.4); ctx.fill();
    ctx.fillStyle = eyeCol(L); ell(ctx, -r * 0.42, hy - r * 0.1, 0.55, 0.6); ctx.fill(); ell(ctx, r * 0.42, hy - r * 0.1, 0.55, 0.6); ctx.fill();
    ctx.strokeStyle = 'rgba(240,236,228,0.7)'; ctx.lineWidth = 0.35;
    for (var s = -1; s <= 1; s += 2) for (var k = 0; k < 2; k++) { ctx.beginPath(); ctx.moveTo(s * r * 0.4, hy + r * 0.5); ctx.lineTo(s * r * 1.6, hy + r * (0.3 + k * 0.4)); ctx.stroke(); }
    ell(ctx, -r * 0.5, -0.4, 0.8, 0.5); ink(ctx, shade(L.c1, -8), 0.45); ell(ctx, r * 0.5, -0.4, 0.8, 0.5); ink(ctx, shade(L.c1, -8), 0.45);
  }

  /* -------------------------------------------------------------- lizard --*/
  /**
   * A lizard seen from above, head UP (-y), centred on the cell; the sprite is rotated to the heading.
   * frame 0..2 = the run (legs and tail swing side to side), pose cells: CALM_A bask (splayed, flat),
   * CALM_B push-up (head raised, front legs straight), ALERT frozen with the head turned.
   */
  function lizard(ctx, L, frame, pose) {
    var c1 = L.c1, c2 = L.c2, c3 = L.c3;
    /* the three still poses differ in SHAPE, not a few tenths (review 2 2026-10-24 found basks, push-up and freeze one
     * drawing): basking = flat, legs splayed wide; push-up = fore legs straight under a lifted, larger head and chest;
     * freeze = the head snapped round and the tail curled hard to one side */
    var sw = pose === null ? [-1, 0, 1][frame] : 0, tsw = pose === 2 ? 1.5 : sw;
    var push = pose === 1 ? 1 : 0, splay = pose === 0 ? 1.35 : 1;
    var cy = -12, BW = 3.2, BH = 6.4;
    ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    /* a soft shadow under the body (an offset oval read as a smudge, review 2) */
    ctx.fillStyle = 'rgba(16,12,6,' + (push ? 0.26 : 0.18) + ')'; ell(ctx, 0.5 + push * 0.8, cy + 1.5 + push * 1.2, BW * 1.1, BH * 1.25); ctx.fill();
    /* legs: elbows out; thicker than a stroke so they read at map size */
    var legs = [[-2.6, cy - 3.6, -1, -1], [2.6, cy - 3.6, 1, -1], [-2.8, cy + 2.8, -1, 1], [2.8, cy + 2.8, 1, 1]];
    for (var i = 0; i < 4; i++) {
      var lg = legs[i], ph = (i === 0 || i === 3) ? sw : -sw, fore = i < 2;
      var kx = lg[0] + lg[2] * 2.7 * splay * (fore && push ? 0.45 : 1), ky = lg[1] + lg[3] * (-0.6 + ph * 1.4) + (fore && push ? 1.2 : 0);
      var fx = kx + lg[2] * 0.7 * (fore && push ? 0.3 : 1), fy = ky + lg[3] * 2.3 - ph * 1.2 + (fore && push ? 1.6 : 0);
      ctx.strokeStyle = LINE; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(lg[0], lg[1]); ctx.lineTo(kx, ky); ctx.lineTo(fx, fy); ctx.stroke();
      ctx.strokeStyle = shade(c1, -10); ctx.lineWidth = 1.4; ctx.stroke();
      ctx.fillStyle = shade(c1, -24); for (var t = -1; t <= 1; t++) { ell(ctx, fx + lg[2] * 0.45 + t * 0.7, fy + lg[3] * 0.65 - Math.abs(t) * 0.35, 0.45, 0.45); ctx.fill(); }
    }
    /* tail: a long tapering S that swings with the run (or curls hard when frozen) */
    var tail = L.pattern === 'stripes' ? c3 : c1;
    ctx.beginPath(); ctx.moveTo(-1.7, cy + 5);
    ctx.bezierCurveTo(-1.6 + tsw * 2.4, cy + 10, 1.4 - tsw * 3, cy + 14, tsw * 2.2, cy + 19);
    ctx.lineTo(tsw * 2.2 + 0.3, cy + 19.4);
    ctx.bezierCurveTo(1.9 - tsw * 3, cy + 14, 0.6 + tsw * 2.4, cy + 10, 1.7, cy + 5); ctx.closePath();
    ink(ctx, tail, 0.65);
    /* body and head (the push-up lifts the chest toward the camera: drawn larger at the front) */
    ell(ctx, 0, cy - push * 0.6, BW * (1 + push * 0.12), BH); ink(ctx, coat(ctx, 0, cy, 5, c1), 0.75);
    var turn = pose === 2 ? 0.75 : 0, hs = push ? 1.3 : 1;
    ctx.save(); ctx.translate(0, cy - 5.2 - push * 1.0); ctx.rotate(turn); ctx.scale(hs, hs); ctx.beginPath(); ctx.moveTo(-2.4, 0); ctx.quadraticCurveTo(-2.7, -3.1, 0, -5.0); ctx.quadraticCurveTo(2.7, -3.1, 2.4, 0); ctx.closePath(); ink(ctx, shade(c1, 8), 0.7);
    ctx.fillStyle = '#100c08'; ell(ctx, -1.55, -2.4, 0.55, 0.65); ctx.fill(); ell(ctx, 1.55, -2.4, 0.55, 0.65); ctx.fill(); ctx.restore();
    /* pattern along the back */
    ctx.save(); ell(ctx, 0, cy - push * 0.6, BW * (1 + push * 0.12), BH); ctx.clip();
    var s = hseed(L.id);
    if (L.pattern === 'speckle') { for (var k = 0; k < 16; k++) { s = lcg(s); ctx.fillStyle = (k & 1) ? c2 : c3; ell(ctx, -2 + (s % 100) / 25, cy - 5.5 + ((s >>> 8) % 100) / 9, 0.4, 0.4); ctx.fill(); } }
    if (L.pattern === 'net') { ctx.strokeStyle = c2; ctx.lineWidth = 0.5; for (var n = 0; n < 6; n++) { ctx.beginPath(); ctx.moveTo(-2.5, cy - 5 + n * 2); ctx.lineTo(0, cy - 4 + n * 2); ctx.lineTo(2.5, cy - 5 + n * 2); ctx.stroke(); } ctx.fillStyle = c3; ctx.fillRect(-0.4, cy - 6, 0.8, 12); }
    if (L.pattern === 'spots') { for (var p = 0; p < 7; p++) { ctx.fillStyle = c2; ell(ctx, (p % 2 ? 1 : -1) * 1.1, cy - 5 + p * 1.6, 0.7, 0.6); ctx.fill(); ctx.fillStyle = c3; ell(ctx, (p % 2 ? -1 : 1) * 1.2, cy - 4.4 + p * 1.6, 0.4, 0.4); ctx.fill(); } }
    if (L.pattern === 'stripes') { ctx.fillStyle = c2; ctx.fillRect(-1.6, cy - 6, 0.6, 12); ctx.fillRect(1.0, cy - 6, 0.6, 12); ctx.fillRect(-0.3, cy - 6, 0.6, 12); }
    ctx.restore();
    ctx.restore();
  }

  /* ---------------------------------------------------------------- crab --*/
  /** A crab, front-on. frame 0..2 = the sidle; pose: 0 claws low, 1 a claw to the mouth, 2 claws up, 3 half dug in, 4 eyes only. */
  function crab(ctx, L, frame, pose) {
    var c1 = L.c1, c2 = L.c2, c3 = L.c3, k = 1;
    var sunk = pose === 3 ? 4.2 : (pose === 4 ? 7.6 : 0);
    var shuffle = pose === null ? [-0.6, 0, 0.6][frame] : 0;
    var cy = -5.2 + sunk;
    ctx.save();
    if (sunk) { ctx.beginPath(); ctx.rect(-20, -30, 40, 30 - 0.2); ctx.clip(); }
    if (!sunk) shadow(ctx, 7.6, 0.28);
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    /* eight walking legs, four a side, bent at the knee */
    /* the legs fan out: the front pair reach forward-out, the back pair back-out, each knee higher than the body
     * edge (four parallel legs at one angle fused into a skirt, contact sheet 2026-10-24) */
    for (var side = -1; side <= 1; side += 2) for (var i = 0; i < 4; i++) {
      var ax = side * 4.4, ay = cy - 0.2 + i * 0.75;
      var ph = ((i & 1) ? shuffle : -shuffle) * side;
      var spread = -0.55 + i * 0.36;
      var kx = ax + side * (2.6 + i * 0.5), ky = ay - 2.0 + spread * 2.2 + ph;
      var fx = kx + side * (1.1 + i * 0.35), fy = cy + 4.4 - sunk + i * 0.25 + Math.abs(ph) * 0.3;
      ctx.strokeStyle = LINE; ctx.lineWidth = 1.15; ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(kx, ky); ctx.lineTo(fx, fy); ctx.stroke();
      ctx.strokeStyle = shade(c1, 6); ctx.lineWidth = 0.5; ctx.stroke();
    }
    /* claws */
    var up = pose === 2 ? 1 : 0, feed = pose === 1;
    for (var s2 = -1; s2 <= 1; s2 += 2) {
      var raise = up ? 5.2 : (feed && s2 < 0 ? 3.0 : 0);
      var ex = s2 * 5.2, ey = cy - 0.6, hx = s2 * (6.2 + up * 1.6), hy = cy - 1.8 - raise;
      ctx.strokeStyle = LINE; ctx.lineWidth = 1.9; ctx.beginPath(); ctx.moveTo(s2 * 3, cy); ctx.lineTo(ex, ey - raise * 0.5); ctx.lineTo(hx, hy); ctx.stroke();
      ctx.strokeStyle = c1; ctx.lineWidth = 1.0; ctx.stroke();
      if (feed && s2 < 0) { hx = -2.2; hy = cy - 2.6; }
      ctx.save(); ctx.translate(hx, hy); ctx.rotate(s2 * (up ? -0.5 : 0.3));
      ell(ctx, 0, -1.2, 1.9, 1.6, 0); ink(ctx, coat(ctx, 0, -1.2, 2, c1), 0.65);
      ctx.beginPath(); ctx.moveTo(-0.6, -2.4); ctx.lineTo(-0.3, -4.3); ctx.lineTo(0.5, -2.6); ctx.closePath(); ink(ctx, shade(c1, -14), 0.5);
      ctx.beginPath(); ctx.moveTo(0.5, -2.2); ctx.lineTo(1.4, -3.8); ctx.lineTo(1.4, -2.0); ctx.closePath(); ink(ctx, shade(c1, -14), 0.5);
      ctx.fillStyle = c3; ell(ctx, -0.2, -4.1, 0.35, 0.35); ctx.fill();
      ctx.restore();
    }
    /* carapace (or a borrowed shell) */
    if (L.pattern === 'shell') {
      ell(ctx, 0, cy - 0.4, 3.2, 2.2); ink(ctx, c1, 0.6);
      ell(ctx, 0.6, cy - 3.2, 5.0, 4.0, 0.2); ink(ctx, coat(ctx, 0, cy - 3, 5, c2), 0.8);
      ctx.strokeStyle = c3; ctx.lineWidth = 0.6; ctx.beginPath();
      for (var a = 0; a < 3 * TAU; a += 0.2) { var rr = 0.4 + a * 0.22; var px = 0.6 + Math.cos(a) * rr, py = cy - 3.2 + Math.sin(a) * rr * 0.8; if (a === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py); }
      ctx.stroke();
    } else {
      ctx.beginPath(); ctx.moveTo(-5.4, cy); ctx.quadraticCurveTo(-5, cy - 4.2, 0, cy - 4.6); ctx.quadraticCurveTo(5, cy - 4.2, 5.4, cy); ctx.quadraticCurveTo(3, cy + 2.6, 0, cy + 2.4); ctx.quadraticCurveTo(-3, cy + 2.6, -5.4, cy); ctx.closePath();
      ink(ctx, coat(ctx, 0, cy - 1.5, 5, c1), 0.8);
      ctx.fillStyle = c2; ctx.globalAlpha = L.pattern === 'pale' ? 0.6 : 0.4; ell(ctx, -1.6, cy - 2.4, 1.6, 0.8, -0.3); ctx.fill(); ell(ctx, 1.8, cy - 2.2, 1.2, 0.6, 0.3); ctx.fill(); ctx.globalAlpha = 1;
    }
    /* eyes on stalks */
    for (var e = -1; e <= 1; e += 2) { ctx.strokeStyle = LINE; ctx.lineWidth = 0.9; ctx.beginPath(); ctx.moveTo(e * 1.2, cy - 3.6); ctx.lineTo(e * 1.6, cy - 6 - up * 0.6); ctx.stroke(); ctx.fillStyle = '#100c08'; ell(ctx, e * 1.6, cy - 6.2 - up * 0.6, 0.75, 0.75); ctx.fill(); ctx.fillStyle = 'rgba(255,255,250,0.8)'; ell(ctx, e * 1.6 - 0.25, cy - 6.45 - up * 0.6, 0.22, 0.22); ctx.fill(); }
    ctx.restore();
    if (sunk) {
      /* the sand mound over the dug-in crab, sprayed on the near side */
      ctx.fillStyle = 'rgba(214,190,140,0.95)'; ctx.strokeStyle = 'rgba(120,96,56,0.6)'; ctx.lineWidth = 0.6;
      ell(ctx, 0, -0.4, 7.6, 2.2); ctx.fill(); ctx.stroke();
      for (var g = 0; g < 7; g++) { ctx.fillStyle = 'rgba(196,170,120,0.9)'; ell(ctx, -6 + g * 2, -1.4 - (g % 2) * 0.8, 0.5, 0.4); ctx.fill(); }
    }
  }

  /* --------------------------------------------------------------- snail --*/
  /** A snail side-on facing LEFT: foot, shell, eye stalks. frame = crawl phase; pose 0..2 calm/stalks/retracting, 3 in shell, 4 coming out. */
  function snail(ctx, L, frame, pose) {
    var c1 = L.c1, c2 = L.c2, c3 = L.c3;
    var ext = pose === null ? [0, 0.7, 1.4][frame] : (pose === 3 ? -3 : (pose === 4 ? -1.2 : (pose === 2 ? -0.4 : 0.5)));
    shadow(ctx, 6, 0.24);
    if (pose !== 3) {
      ctx.beginPath(); ctx.moveTo(4.6, -0.2); ctx.quadraticCurveTo(6.6 + ext * 0.2, -0.4, 6.2, -1.6); ctx.lineTo(-3.8 - ext, -2.4); ctx.quadraticCurveTo(-6.4 - ext, -2.6, -6.2 - ext, -0.4); ctx.closePath();
      ink(ctx, coat(ctx, 0, -1, 5, c3), 0.65);
      var st = pose === 2 ? 0.4 : (pose === 4 ? 0.6 : 1);
      ctx.strokeStyle = LINE; ctx.lineWidth = 1.1; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(-5 - ext, -2.2); ctx.lineTo(-6.6 - ext, -2.2 - 3.4 * st); ctx.moveTo(-4.4 - ext, -2.2); ctx.lineTo(-5.4 - ext, -2.2 - 3.0 * st); ctx.stroke();
      ctx.strokeStyle = shade(c3, 10); ctx.lineWidth = 0.55; ctx.stroke();
      ctx.fillStyle = '#1a140e'; ell(ctx, -6.6 - ext, -2.2 - 3.4 * st, 0.5, 0.5); ctx.fill(); ell(ctx, -5.4 - ext, -2.2 - 3.0 * st, 0.45, 0.45); ctx.fill();
    }
    var sx = 0.6, sy = -5.4, R = 4.4;
    ell(ctx, sx, sy, R, R * 0.95); ink(ctx, coat(ctx, sx, sy, R, c1), 0.8);
    ctx.save(); ell(ctx, sx, sy, R, R * 0.95); ctx.clip();
    if (L.pattern === 'bands') { ctx.strokeStyle = c2; ctx.lineWidth = 0.8; for (var b = 1; b <= 3; b++) { ctx.beginPath(); ctx.arc(sx + 0.4, sy + 0.3, R * b * 0.3, 0, TAU); ctx.stroke(); } }
    ctx.strokeStyle = L.pattern === 'spiral' ? c2 : shade(c1, -50); ctx.lineWidth = 0.7; ctx.beginPath();
    for (var a = 0; a < 2.6 * TAU; a += 0.15) { var rr = R * (0.08 + a / (2.6 * TAU) * 0.9); var px = sx + 0.4 + Math.cos(a) * rr, py = sy + 0.3 + Math.sin(a) * rr; if (a === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py); }
    ctx.stroke();
    if (L.pattern === 'spiral') { ctx.strokeStyle = shade(c1, 34); ctx.lineWidth = 0.4; ctx.globalAlpha = 0.6; for (var t = 0; t < 8; t++) { ctx.beginPath(); ctx.moveTo(sx + Math.cos(t) * R * 0.3, sy + Math.sin(t) * R * 0.3); ctx.lineTo(sx + Math.cos(t) * R, sy + Math.sin(t) * R); ctx.stroke(); } ctx.globalAlpha = 1; }
    ctx.restore();
    if (pose === 3) { ctx.fillStyle = shade(c3, -30); ell(ctx, sx - R * 0.55, -1.4, 1.4, 0.8); ctx.fill(); }
  }

  /* -------------------------------------------------------------- spider --*/
  /** A spider hanging, seen a little from above: two body parts and eight legs. pose 0 relaxed, 1 a leg twitch, 2 legs tucked (reeling up). */
  function spider(ctx, L, pose) {
    var c1 = L.c1, c2 = L.c2, c3 = L.c3, cy = -10, s = L.size || 1;
    var tuck = pose === 2 ? 0.55 : 1, tw = pose === 1 ? 0.5 : 0;
    ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    for (var side = -1; side <= 1; side += 2) for (var i = 0; i < 4; i++) {
      var ax = side * 1.2, ay = cy - 1.4 + i * 0.9;
      var a = (-0.9 + i * 0.6) + (i === 0 ? tw * 0.4 * side : 0);
      var kx = ax + side * Math.cos(a) * 3.4 * tuck, ky = ay + Math.sin(a) * 3.0 * tuck - 1.6;
      var fx = kx + side * Math.cos(a + 0.9) * 3.0 * tuck, fy = ky + Math.sin(a + 0.9) * 3.4 * tuck + 1.2;
      ctx.strokeStyle = LINE; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(kx, ky); ctx.lineTo(fx, fy); ctx.stroke();
      ctx.strokeStyle = shade(c1, 12); ctx.lineWidth = 0.55; ctx.stroke();
    }
    ell(ctx, 0, cy - 1.0, 1.6, 1.5); ink(ctx, coat(ctx, 0, cy - 1, 2, shade(c1, -10)), 0.6);
    ell(ctx, 0, cy + 2.4, 2.4, 2.9); ink(ctx, coat(ctx, 0, cy + 2.4, 3, c1), 0.7);
    if (L.pattern === 'cross') { ctx.fillStyle = c2; ctx.fillRect(-0.35, cy + 0.6, 0.7, 3.6); ctx.fillRect(-1.3, cy + 1.6, 2.6, 0.7); for (var d = 0; d < 4; d++) { ell(ctx, (d & 1 ? 1 : -1) * 1.2, cy + 3.4 + (d >> 1) * 0.9, 0.3, 0.3); ctx.fill(); } }
    else { ctx.fillStyle = c2; ctx.globalAlpha = 0.7; for (var c = 0; c < 3; c++) { ell(ctx, 0, cy + 1.4 + c * 1.1, 1.2 - c * 0.25, 0.3); ctx.fill(); } ctx.globalAlpha = 1; }
    ctx.fillStyle = c3; ell(ctx, -0.5, cy - 2.0, 0.3, 0.3); ctx.fill(); ell(ctx, 0.5, cy - 2.0, 0.3, 0.3); ctx.fill();
    ctx.restore();
  }

  /* ------------------------------------------------------------ dispatch --*/
  var VIEW = { rabbit: 'quad', hare: 'quad', squirrel: 'quad', hedgehog: 'quad', mouse: 'quad', rat: 'quad', cat: 'quad', fox: 'quad', badger: 'quad', lizard: 'dorsal', crab: 'front', snail: 'side2', spider: 'hang' };
  var STEPS = [-1, 0, 1];

  /**
   * Draw ONE cell of one look: cell 0-11 = walk (facing down, left, right, up x steps -1, 0, 1), 12-23 = the
   * six poses x (left, right). Foot at (x, y). `k` = scale (1 = a 48 px tile).
   * @returns {number} how many cells of this look are meaningful (for the suite)
   */
  function drawCell(ctx, L, cell, x, y, k) {
    var fam = L.family, view = VIEW[fam], P = PLANS[fam];
    var size = (L.size || 1) * k;
    ctx.save(); ctx.translate(x, y);
    var walk = cell < 12, dirI = walk ? Math.floor(cell / 3) : -1, step = walk ? STEPS[cell % 3] : 0;
    var pose = walk ? null : Math.floor((cell - 12) / 2), side = walk ? (dirI === 2 ? 1 : 0) : (cell - 12) % 2;
    if (view === 'quad') {
      if (walk && (dirI === 0 || dirI === 3)) { ctx.scale(size, size); furFront(ctx, L, P, step, dirI === 3); }
      else {
        ctx.scale(side ? -size : size, size);
        if (walk) furSide(ctx, L, P, { stride: step, earsUp: 0.6, tailUp: 0.7 });
        else {
          var o = POSES[fam][pose];
          if (o.climb) { ctx.scale(side ? -1 : 1, 1); climber(ctx, L, P, side); }
          else if (o.peekOut) { ctx.scale(side ? -1 : 1, 1); peeker(ctx, L, P); }
          else furSide(ctx, L, P, o);
        }
      }
    } else if (view === 'dorsal') {
      /* the body DORSAL_LIFT above the foot line, so head (-12) to tail tip (+19) fit the cell: at +12 the tail was
       * cut off by the cell's edge in every in-game lizard, a tailless bug (atlas contact sheet, review 2026-10-24) */
      ctx.scale(size, size); ctx.translate(0, 12 - DORSAL_LIFT);
      lizard(ctx, L, walk ? (cell % 3) : 0, walk ? null : (pose <= 2 ? pose : 0));
    } else if (view === 'front') {
      ctx.scale(size, size);
      crab(ctx, L, walk ? (cell % 3) : 0, walk ? null : pose);
    } else if (view === 'side2') {
      ctx.scale(side ? -size : size, size);
      snail(ctx, L, walk ? (cell % 3) : 0, walk ? null : pose);
    } else if (view === 'hang') {
      ctx.scale(size, size); ctx.translate(0, 12);
      spider(ctx, L, walk ? 0 : Math.min(2, pose));
    }
    ctx.restore();
    return 24;
  }

  /* --------------------------------------------------------------- extras --*/
  /** A mouse hole at the foot of a wall: a dark arch with a worn rim. Foot (x, y) = the bottom centre. */
  function drawHole(ctx, x, y, k) {
    ctx.save(); ctx.translate(x, y); ctx.scale(k, k);
    ctx.beginPath(); ctx.moveTo(-4.4, 0); ctx.lineTo(-4.4, -3.4); ctx.arc(0, -3.4, 4.4, Math.PI, 0); ctx.lineTo(4.4, 0); ctx.closePath();
    ctx.fillStyle = 'rgba(120,96,70,0.55)'; ctx.fill();
    ctx.beginPath(); ctx.moveTo(-3.3, 0); ctx.lineTo(-3.3, -3.2); ctx.arc(0, -3.2, 3.3, Math.PI, 0); ctx.lineTo(3.3, 0); ctx.closePath();
    var g = ctx.createLinearGradient(0, -6.5, 0, 0); g.addColorStop(0, '#0c0806'); g.addColorStop(1, '#2a1e16');
    ctx.fillStyle = g; ctx.fill();
    ctx.fillStyle = 'rgba(16,10,6,0.35)'; ell(ctx, 0, 0.2, 4.6, 0.9); ctx.fill();
    ctx.restore();
  }
  /** One unit of spider thread (the layer stretches it to the drop). */
  function drawThread(ctx, x, y, k) { ctx.fillStyle = 'rgba(240,240,236,0.85)'; ctx.fillRect(x - 0.5 * k, y, Math.max(1, k), BASE_CELL * k - 2); }
  /** A puff of dust kicked up by a bolting animal: three sizes. */
  function drawDust(ctx, x, y, k, f) {
    ctx.save(); ctx.translate(x, y); ctx.scale(k, k);
    var r = [1.6, 2.6, 3.4][f], a = [0.5, 0.38, 0.22][f];
    ctx.fillStyle = 'rgba(214,200,170,' + a + ')';
    ell(ctx, -r * 0.6, -r * 0.6, r, r * 0.8); ctx.fill(); ell(ctx, r * 0.5, -r * 0.4, r * 0.8, r * 0.7); ctx.fill(); ell(ctx, 0, -r * 1.2, r * 0.7, r * 0.6); ctx.fill();
    ctx.restore();
  }

  /* --------------------------------------------------------------- atlas --*/
  /**
   * The atlas layout: every look gets CELLS_PER_LOOK cells in a row-major grid, then the extras (hole, thread,
   * three dust puffs). Struck AT the animal scale, so a bigger animal is drawn bigger, never magnified (wing §17b).
   * @returns {{cell:number, cols:number, rows:number, width:number, height:number, first:number[], hole:number, thread:number, dust:number, cells:number}}
   */
  function layout(looks, k) {
    var cell = Math.ceil(BASE_CELL * k), per = 24;
    var cols = Math.max(1, Math.floor(2048 / cell));
    var first = [], n = 0;
    for (var i = 0; i < looks.length; i++) { first.push(n); n += per; }
    var hole = n, thread = n + 1, dust = n + 2; n += 5;
    var rows = Math.ceil(n / cols);
    return { cell: cell, cols: cols, rows: rows, width: cols * cell, height: rows * cell, first: first, hole: hole, thread: thread, dust: dust, cells: n, foot: Math.round(FOOT * k) };
  }

  /**
   * Draw every cell of every look into a context sized by `layout`.
   * @returns {{drawn:number, layout:object}}
   */
  function bakeAtlas(ctx, looks, k) {
    var L = layout(looks, k), drawn = 0;
    ctx.clearRect(0, 0, L.width, L.height);
    for (var i = 0; i < looks.length; i++) {
      for (var c = 0; c < 24; c++) {
        var idx = L.first[i] + c, cx = (idx % L.cols) * L.cell, cy = Math.floor(idx / L.cols) * L.cell;
        ctx.save(); ctx.beginPath(); ctx.rect(cx, cy, L.cell, L.cell); ctx.clip();
        drawCell(ctx, looks[i], c, cx + L.cell / 2, cy + L.cell - L.foot, k);
        ctx.restore();
        drawn++;
      }
    }
    var at = function (idx) { return [(idx % L.cols) * L.cell, Math.floor(idx / L.cols) * L.cell]; };
    var h = at(L.hole); drawHole(ctx, h[0] + L.cell / 2, h[1] + L.cell - L.foot, k); drawn++;
    var t = at(L.thread); drawThread(ctx, t[0] + L.cell / 2, t[1] + 1, k); drawn++;
    for (var f = 0; f < 3; f++) { var d = at(L.dust + f); drawDust(ctx, d[0] + L.cell / 2, d[1] + L.cell - L.foot, k, f); drawn++; }
    return { drawn: drawn, layout: L };
  }

  globalThis.CSAF.HedgerowPaint = {
    VERSION: '1.0.0', BASE_CELL: BASE_CELL, FOOT: FOOT, DORSAL_LIFT: DORSAL_LIFT, PLANS: PLANS, POSES: POSES, VIEW: VIEW,
    drawCell: drawCell, drawHole: drawHole, drawDust: drawDust, layout: layout, bakeAtlas: bakeAtlas,
    hex: hex, shade: shade, mix: mix
  };
})();
