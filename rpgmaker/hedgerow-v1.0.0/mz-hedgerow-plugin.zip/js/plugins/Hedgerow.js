//=============================================================================
// Hedgerow.js — Hedgerow [3/3]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Hedgerow [3/3] — the animals that walk your maps: 13 families, 44 coats, drawn at runtime, placed by your tiles. v1.0.0
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @param enabled
 * @text Animals on
 * @type boolean
 * @default true
 * @desc Turn every animal on or off. The Set Animals On command changes it in play (and it saves).
 *
 * @param density
 * @text Density
 * @type number
 * @decimals 2
 * @min 0
 * @max 4
 * @default 1.00
 * @desc 1 = the natural amount. 0.5 = sparse, 2 = busy. Per map: <Hedgerow density: 1.5> in the map note.
 *
 * @param animalScale
 * @text Animal size
 * @type number
 * @decimals 2
 * @min 0.5
 * @max 3
 * @default 1.50
 * @desc 1.5 suits 48 px tiles (a rabbit about half a tile long). Scaled again by your tile size automatically.
 *
 * @param maxAnimals
 * @text Most animals at once
 * @type number
 * @min 4
 * @max 64
 * @default 24
 *
 * @param fleeRadius
 * @text Flee distance (px)
 * @type number
 * @min 0
 * @max 480
 * @default 110
 * @desc Closer than this to the player, an animal reacts in its own way (a cat and a hedgehog let you a little closer).
 *
 * @param dust
 * @text Dust when they bolt
 * @type boolean
 * @default true
 * @desc Small puffs of dust behind a bolting rabbit, hare, fox or badger.
 *
 * @param biomeRules
 * @text Biome by tileset name
 * @type multiline_string
 * @default Outside=meadow; Field=meadow; Farm=meadow; Forest=forest; Wood=forest; Jungle=forest; Town=town; Village=town; City=town; Beach=coast; Coast=coast; Harbour=coast; Harbor=coast; Desert=desert; Snow=snow; Taiga=snow; Inside=house; Interior=house; House=house; Dungeon=cellar; Cellar=cellar; Sewer=cellar
 * @desc For maps with no <Hedgerow: ...> note: the first word found in the tileset's NAME picks the biomes. No match = no animals.
 *
 * @param townShare
 * @text Town from buildings
 * @type number
 * @decimals 2
 * @min 0
 * @max 1
 * @default 0.04
 * @desc An outdoor map whose building tiles (A3 roofs and walls) cover at least this share is also a town (cats, rats). 0 = off.
 *
 * @param waterTerrainTag
 * @text Water terrain tag
 * @type number
 * @min 0
 * @max 7
 * @default 0
 * @desc Tiles with this terrain tag count as water (as well as A1 water tiles). 0 = off. Crabs live on sand by water.
 *
 * @param treeTerrainTag
 * @text Tree terrain tag
 * @type number
 * @min 0
 * @max 7
 * @default 0
 * @desc Trees on a custom tileset: squirrels live at their foot. MZ's stock trees need nothing. 0 = off.
 *
 * @param rockTerrainTag
 * @text Rock terrain tag
 * @type number
 * @min 0
 * @max 7
 * @default 0
 * @desc Rocks on a custom tileset: lizards bask beside them. MZ's stock boulders need nothing. 0 = off.
 *
 * @param sandTerrainTag
 * @text Sand terrain tag
 * @type number
 * @min 0
 * @max 7
 * @default 0
 * @desc Sand on a custom tileset: crabs live on it within two tiles of water. MZ's stock sand needs nothing. 0 = off.
 *
 * @param hearthTerrainTag
 * @text Hearth terrain tag
 * @type number
 * @min 0
 * @max 7
 * @default 0
 * @desc Fireplaces on a custom tileset: a cat sleeps beside them. MZ's stock fireplaces need nothing. 0 = off.
 *
 * @param lifeRegion
 * @text Animal region
 * @type number
 * @min 0
 * @max 255
 * @default 0
 * @desc If set, animals live only on tiles with this region. 0 = any walkable tile.
 *
 * @param noLifeRegion
 * @text No-animal region
 * @type number
 * @min 0
 * @max 255
 * @default 0
 * @desc Tiles with this region never get animals (a road, a stage). 0 = off.
 *
 * @param timeSource
 * @text Day and night from
 * @type select
 * @option Screen tone (works with tint-based day/night)
 * @value tone
 * @option A switch (ON = night)
 * @value switch
 * @option A variable holding the hour (0-23)
 * @value variable
 * @default tone
 *
 * @param nightSwitch
 * @text Night switch
 * @type switch
 * @default 0
 *
 * @param hourVariable
 * @text Hour variable
 * @type variable
 * @default 0
 *
 * @param families
 * @text Families
 * @type struct<Families>
 * @default {"rabbit":"true","hare":"true","squirrel":"true","hedgehog":"true","mouse":"true","rat":"true","lizard":"true","crab":"true","snail":"true","cat":"true","fox":"true","badger":"true","spider":"true"}
 *
 * @param extraLooks
 * @text Your own coats
 * @type struct<Look>[]
 * @default []
 * @desc Coats of your own, drawn by the same painter. Pick a family and colours; the pattern is optional.
 *
 * @command setEnabled
 * @text Set Animals On
 * @desc Turn every animal on or off (saved with the game).
 * @arg on
 * @text On
 * @type boolean
 * @default true
 *
 * @command setDensity
 * @text Set Density
 * @desc Change how many animals there are (saved with the game).
 * @arg value
 * @text Density
 * @type number
 * @decimals 2
 * @min 0
 * @max 4
 * @default 1.00
 *
 * @command setMapBiomes
 * @text Set This Map's Biomes
 * @desc Override the biomes of the current map (saved). Leave blank to go back to the map's own.
 * @arg biomes
 * @text Biomes
 * @type string
 * @default meadow
 * @desc Any of: meadow forest town coast desert snow house cellar none
 *
 * @command setPhase
 * @text Set Time Of Day
 * @desc Force day, dusk or night for the animals, or go back to automatic.
 * @arg phase
 * @text Phase
 * @type select
 * @option auto
 * @option day
 * @option dusk
 * @option night
 * @default auto
 *
 * @command scatter
 * @text Scatter
 * @desc Every animal on screen takes flight at once (a shout, a bell, a door slammed).
 *
 * @help Hedgerow.js
 *
 * Part 3 of 3 — the only file that touches RPG Maker. Load all three:
 * HedgerowCore.js, HedgerowPaint.js and this file. Any order works.
 *
 * WHAT IT DOES
 * Every map gets the animals that walk a real place. Nothing to place, no
 * events: the plugin reads the map once and decides where each kind lives.
 *   open ground:          rabbits and hares by day; hedgehogs, foxes and
 *                         badgers at dusk and night; snails at dusk or in rain;
 *                         cats in towns and houses
 *   the foot of a wall:   mice (and rats at night) run along it and dive into
 *                         a hole; spiders hang there indoors
 *   the foot of a tree:   squirrels forage round it and climb it
 *   beside rocks:         lizards bask
 *   sand by water:        crabs sidle, and dig in
 *   beside a fireplace:   a cat asleep
 * Every animal is DRAWN by the plugin, in the four facings a character has.
 * No image files ship or are needed.
 *
 * EACH ONE FLEES ITS OWN WAY
 * A rabbit sits up, thumps and bolts in a zig-zag, white tail showing. A hare
 * runs long and straight. A squirrel runs to its tree and climbs out of
 * sight. A hedgehog rolls into a ball until you have gone. A mouse runs along
 * the wall into its hole, then peeks out. A lizard darts and freezes. A crab
 * raises its claws, backs off sideways and digs in. A snail withdraws into its
 * shell. A cat sits up, watches you, then stalks away. A fox looks back once.
 * A spider climbs its thread.
 *
 * WHICH MAPS
 * Map note:      <Hedgerow: meadow town>     <Hedgerow: none>
 *                <Hedgerow density: 1.5>
 * Tileset note:  the same tags, for every map using that tileset, and
 *                <Hedgerow tags: tree 7, rock 6, sand 5, hearth 4, water 1>
 *                to mark the habitats of a custom tileset by terrain tag.
 * Otherwise the tileset's NAME is matched against "Biome by tileset name".
 * With the defaults, Outside maps are meadows (and towns when they have
 * enough buildings), Inside maps are houses, Dungeon maps are cellars.
 * MZ's own trees, boulders, sand and fireplaces are known with no setup.
 *
 * Biomes: meadow, forest, town, coast, desert, snow, house, cellar, none.
 *
 * DAY AND NIGHT
 * By default the screen tone decides: MZ's own "Night" tint is night,
 * "Sunset" is dusk. Any day/night plugin that tints the screen works with no
 * setup. Otherwise point it at a switch or an hour variable. Indoors has no
 * sun: house and cellar animals are out at any hour. Rain brings snails out.
 *
 * SCRIPT CALLS
 *   CSAF.Hedgerow.count()       animals on the map now (hidden ones too)
 *   CSAF.Hedgerow.phase()       'day', 'dusk' or 'night'
 *   CSAF.Hedgerow.biomes()      the current map's biomes
 *   CSAF.Hedgerow.habitat()     habitat tile counts of the current map
 *   CSAF.Hedgerow.lookIds()     every coat id, yours included
 *   CSAF.Hedgerow.scatter()
 *
 * Animals never block, collide with or trigger anything; they are scenery.
 * Their positions are not saved (a map's animals are re-made when you enter
 * it); the commands' settings are.
 *
 * Works beside Vivarium (our flying and swimming life): both read the day
 * the same way, and Hedgerow lives where Vivarium does not.
 */
/*~struct~Families:
 * @param rabbit
 * @text Rabbits
 * @type boolean
 * @default true
 * @param hare
 * @text Hares
 * @type boolean
 * @default true
 * @param squirrel
 * @text Squirrels
 * @type boolean
 * @default true
 * @param hedgehog
 * @text Hedgehogs
 * @type boolean
 * @default true
 * @param mouse
 * @text Mice
 * @type boolean
 * @default true
 * @param rat
 * @text Rats
 * @type boolean
 * @default true
 * @param lizard
 * @text Lizards
 * @type boolean
 * @default true
 * @param crab
 * @text Crabs
 * @type boolean
 * @default true
 * @param snail
 * @text Snails
 * @type boolean
 * @default true
 * @param cat
 * @text Cats
 * @type boolean
 * @default true
 * @param fox
 * @text Foxes
 * @type boolean
 * @default true
 * @param badger
 * @text Badgers
 * @type boolean
 * @default true
 * @param spider
 * @text Spiders
 * @type boolean
 * @default true
 */
/*~struct~Look:
 * @param id
 * @text Id
 * @type string
 * @default my-cat
 * @param name
 * @text Name
 * @type string
 * @default My Cat
 * @param family
 * @text Family
 * @type select
 * @option rabbit
 * @option hare
 * @option squirrel
 * @option hedgehog
 * @option mouse
 * @option rat
 * @option lizard
 * @option crab
 * @option snail
 * @option cat
 * @option fox
 * @option badger
 * @option spider
 * @default cat
 * @param size
 * @text Size (x)
 * @type number
 * @decimals 2
 * @min 0.6
 * @max 1.5
 * @default 1.00
 * @param colour1
 * @text Coat colour
 * @type string
 * @default #6a5a8a
 * @param colour2
 * @text Second colour (belly, mask, bands)
 * @type string
 * @default #e8e0f0
 * @param colour3
 * @text Accent colour (eyes of a pale coat, tips, tail)
 * @type string
 * @default #2a2030
 * @param pattern
 * @text Pattern (optional)
 * @type string
 * @default
 * @desc cat: tabby plain calico tuxedo tortie. rabbit: agouti plain. lizard: speckle net spots stripes. Blank = the family's first.
 * @param biomes
 * @text Only in biomes (optional)
 * @type string
 * @default
 */

'use strict';

if (typeof globalThis.CSAF === 'undefined') globalThis.CSAF = {};

(function () {
  var NAME = 'Hedgerow';
  var _params = null;

  /* ⛔ wing §8 trap 2: siblings are resolved at FIRST USE, never at load — the buyer chooses the order. */
  function C() { return globalThis.CSAF.HedgerowCore; }
  function D() { return globalThis.CSAF.HedgerowPaint; }
  function ready() { return !!(C() && D()); }

  function parseJson(raw, fallback) {
    if (raw && typeof raw === 'object') return raw;
    try { var v = JSON.parse(String(raw === undefined || raw === null ? '' : raw)); return v === null || v === undefined ? fallback : v; } catch (e) { return fallback; }
  }
  /* ⛔ wing §16: parameters arrive as STRINGS; Number('') is 0 and "0" is truthy — coerce, then compare. */
  function num(v, d, lo, hi) {
    if (v === undefined || v === null || String(v).trim() === '') return d;
    var n = Number(v);
    if (!isFinite(n)) return d;
    return Math.max(lo, Math.min(hi, n));
  }
  function bool(v, d) { return v === undefined || v === null || v === '' ? d : String(v) === 'true'; }

  var DEFAULT_RULES = 'Outside=meadow; Field=meadow; Farm=meadow; Forest=forest; Wood=forest; Jungle=forest; Town=town; Village=town; City=town; Beach=coast; Coast=coast; Harbour=coast; Harbor=coast; Desert=desert; Snow=snow; Taiga=snow; Inside=house; Interior=house; House=house; Dungeon=cellar; Cellar=cellar; Sewer=cellar';

  function P() {
    if (_params) return _params;
    var raw = (typeof PluginManager !== 'undefined' && PluginManager.parameters) ? PluginManager.parameters(NAME) : {};
    var fam = parseJson(raw.families, {}), familiesOn = {};
    var order = ['rabbit', 'hare', 'squirrel', 'hedgehog', 'mouse', 'rat', 'lizard', 'crab', 'snail', 'cat', 'fox', 'badger', 'spider'];
    for (var i = 0; i < order.length; i++) familiesOn[order[i]] = bool(fam[order[i]], true);
    var extra = parseJson(raw.extraLooks, []);
    if (!Array.isArray(extra)) extra = [];
    _params = {
      enabled: bool(raw.enabled, true),
      density: num(raw.density, 1, 0, 4),
      animalScale: num(raw.animalScale, 1.5, 0.5, 3),
      maxAnimals: Math.round(num(raw.maxAnimals, 24, 4, 64)),
      fleeRadius: num(raw.fleeRadius, 110, 0, 480),
      dust: bool(raw.dust, true),
      biomeRules: raw.biomeRules === undefined ? DEFAULT_RULES : String(raw.biomeRules),
      townShare: num(raw.townShare, 0.04, 0, 1),
      waterTerrainTag: Math.round(num(raw.waterTerrainTag, 0, 0, 7)),
      treeTerrainTag: Math.round(num(raw.treeTerrainTag, 0, 0, 7)),
      rockTerrainTag: Math.round(num(raw.rockTerrainTag, 0, 0, 7)),
      sandTerrainTag: Math.round(num(raw.sandTerrainTag, 0, 0, 7)),
      hearthTerrainTag: Math.round(num(raw.hearthTerrainTag, 0, 0, 7)),
      lifeRegion: Math.round(num(raw.lifeRegion, 0, 0, 255)),
      noLifeRegion: Math.round(num(raw.noLifeRegion, 0, 0, 255)),
      timeSource: ['tone', 'switch', 'variable'].indexOf(String(raw.timeSource)) >= 0 ? String(raw.timeSource) : 'tone',
      nightSwitch: Math.round(num(raw.nightSwitch, 0, 0, 9999)),
      hourVariable: Math.round(num(raw.hourVariable, 0, 0, 9999)),
      familiesOn: familiesOn,
      extraRaw: extra
    };
    return _params;
  }

  /* -------------------------------------------------------------- looks --*/
  var _looks = null;
  /** Built-in looks plus the buyer's own, each checked (an unusable row is dropped, never guessed). */
  function looks() {
    if (_looks) return _looks;
    var list = C().LOOKS.slice(), seen = {};
    for (var i = 0; i < list.length; i++) seen[list[i].id] = true;
    var extra = P().extraRaw;
    for (var j = 0; j < extra.length; j++) {
      var lk = C().cleanLook(parseJson(extra[j], null), j + 1);
      if (!lk || seen[lk.id]) continue;
      seen[lk.id] = true; list.push(lk);
    }
    _looks = list;
    return _looks;
  }

  /* -------------------------------------------------------------- store --*/
  /** The saved settings: plain, versioned, on Game_System. A newer version is read, never overwritten. */
  function store() {
    if (typeof $gameSystem === 'undefined' || !$gameSystem) return null;
    var s = $gameSystem._csafHedgerow;
    if (!s || typeof s !== 'object' || typeof s.maps !== 'object' || !s.maps || Array.isArray(s.maps)) {
      if (s && typeof s === 'object' && Number(s.v) > 1 && s.maps && typeof s.maps === 'object') return s;
      s = $gameSystem._csafHedgerow = { v: 1, enabled: null, density: null, phase: 'auto', maps: {} };
    }
    return s;
  }
  function isEnabled() { var s = store(); return s && s.enabled !== null && s.enabled !== undefined ? !!s.enabled : P().enabled; }
  function densityBase() {
    var s = store();
    return s && s.density !== null && s.density !== undefined && isFinite(Number(s.density)) ? Number(s.density) : P().density;
  }
  function noteDensity() {
    var note = typeof $dataMap !== 'undefined' && $dataMap ? C().parseNote($dataMap.note).density : null;
    return note === null ? 1 : note;
  }
  function overrideKey() {
    var s = store();
    var v = s && s.maps && typeof $gameMap !== 'undefined' && $gameMap ? s.maps[$gameMap.mapId()] : undefined;
    return v === undefined || v === null ? '' : String(v);
  }

  /* ---------------------------------------------------------- reading --*/
  function tilesetOf() { return (typeof $gameMap !== 'undefined' && $gameMap && $gameMap.tileset) ? $gameMap.tileset() : null; }

  function biomesNow(hab) {
    if (!ready() || typeof $gameMap === 'undefined' || !$gameMap) return ['none'];
    var s = store(), id = $gameMap.mapId(), ts = tilesetOf();
    var ov = s && s.maps && s.maps[id] ? String(s.maps[id]).toLowerCase().split(/[\s,]+/).filter(function (b) { return !!C().BIOMES[b]; }) : null;
    return C().biomesFor({
      override: ov, mapNote: $dataMap ? $dataMap.note : '', tilesetNote: ts ? ts.note : '',
      tilesetName: ts ? ts.name : '', rules: C().parseRules(P().biomeRules),
      buildingShare: hab ? hab.buildingShare : 0, townShare: P().townShare
    });
  }

  var _phaseScratch = { forced: 'auto', hour: null, nightSwitch: false, tone: null };
  function phaseNow() {
    if (!ready()) return 'day';
    var s = store(), p = P(), o = _phaseScratch;
    o.forced = s ? s.phase : 'auto'; o.hour = null; o.nightSwitch = false; o.tone = null;
    if (p.timeSource === 'variable' && p.hourVariable > 0 && $gameVariables) o.hour = $gameVariables.value(p.hourVariable);
    else if (p.timeSource === 'switch' && p.nightSwitch > 0 && $gameSwitches) o.nightSwitch = $gameSwitches.value(p.nightSwitch) === true;
    else if ($gameScreen) o.tone = $gameScreen.tone();
    return C().phaseOf(o);
  }
  function raining() { return typeof $gameScreen !== 'undefined' && $gameScreen && $gameScreen.weatherType && $gameScreen.weatherType() === 'rain'; }

  /** Is any of the tile's four layers one of the stock tiles in `table` (sheet name -> indices)? B-E sheets only. */
  function stockAt(table, ts, x, y) {
    if (!ts || !table) return false;
    for (var z = 0; z < 4; z++) {
      var id = $gameMap.tileId(x, y, z);
      if (id <= 0 || id >= Tilemap.TILE_ID_A5) continue;
      var sheet = ts.tilesetNames[5 + Math.floor(id / 256)];
      var list = table[sheet];
      if (list && list.indexOf(id % 256) >= 0) return true;
    }
    return false;
  }

  /** The habitat of the current map, read from the ENGINE'S own tile, flag, tag and region data. */
  function readHabitat() {
    var p = P(), w = $gameMap.width(), h = $gameMap.height(), ts = tilesetOf(), S = C().STOCK;
    var tags = C().parseTags(ts ? ts.note : '');
    var tTree = tags.tree || p.treeTerrainTag, tRock = tags.rock || p.rockTerrainTag, tSand = tags.sand || p.sandTerrainTag;
    var tHearth = tags.hearth || p.hearthTerrainTag, tWater = tags.water || p.waterTerrainTag;
    var sandKinds = ts ? S.sandKind[ts.tilesetNames[1]] : null;
    /* ⛔ MEASURED 2026-10-24 (_probe/stock_flags.js): MZ's stock Inside flags its A4 wall TOPS passable, so a room's
     * walls read as walkable ground and a cat spawned on top of one (smoke_house.png). Indoors, a wall top is the
     * ceiling: never habitat. Outdoors an A4 top is a cliff top a party may walk, so it stays ground. */
    var nb = biomesNow(null), indoor = nb.indexOf('house') >= 0 || nb.indexOf('cellar') >= 0;
    return C().buildHabitat({
      width: w, height: h,
      isWater: function (x, y) {
        var id = $gameMap.tileId(x, y, 0);
        if (Tilemap.isWaterTile(id) && !Tilemap.isWaterfallTile(id)) return true;
        if (tWater > 0 && $gameMap.terrainTag(x, y) === tWater) return true;
        return false;
      },
      isPassable: function (x, y) {
        if (p.lifeRegion > 0 && $gameMap.regionId(x, y) !== p.lifeRegion) return false;
        if (indoor && Tilemap.isWallTopTile($gameMap.tileId(x, y, 0))) return false;
        return $gameMap.checkPassage(x, y, 0x0f);
      },
      isBlocked: function (x, y) { return p.noLifeRegion > 0 && $gameMap.regionId(x, y) === p.noLifeRegion; },
      isTree: function (x, y) { return (tTree > 0 && $gameMap.terrainTag(x, y) === tTree) || stockAt(S.tree, ts, x, y); },
      isRock: function (x, y) { return (tRock > 0 && $gameMap.terrainTag(x, y) === tRock) || stockAt(S.rock, ts, x, y); },
      isSand: function (x, y) {
        if (tSand > 0 && $gameMap.terrainTag(x, y) === tSand) return true;
        var id = $gameMap.tileId(x, y, 0);
        return !!(sandKinds && Tilemap.isTileA2(id) && sandKinds.indexOf(Tilemap.getAutotileKind(id)) >= 0);
      },
      isHearth: function (x, y) { return (tHearth > 0 && $gameMap.terrainTag(x, y) === tHearth) || stockAt(S.hearth, ts, x, y); },
      isBuilding: function (x, y) { return Tilemap.isTileA3($gameMap.tileId(x, y, 0)); }
    });
  }

  /* -------------------------------------------------------------- atlas --*/
  var _atlas = null;
  function scaleNow() {
    var tw = typeof $gameMap !== 'undefined' && $gameMap ? $gameMap.tileWidth() : 48;
    return P().animalScale * (tw / 48);
  }
  /** One Bitmap holding every frame of every look; baked once per scale and shared by every sprite (one batch). */
  function atlas() {
    var sc = scaleNow();
    if (_atlas && _atlas.sc === sc && _atlas.bitmap && _atlas.bitmap.baseTexture && !_atlas.bitmap.baseTexture.destroyed) return _atlas;
    /* struck AT the animal scale: a bigger animal is drawn bigger, never magnified (wing §17b) */
    var L = D().layout(looks(), sc);
    var bm = new Bitmap(L.width, L.height);
    var res = D().bakeAtlas(bm.context, looks(), sc);
    bm.baseTexture.update();
    _atlas = { bitmap: bm, layout: L, sc: sc, drawn: res.drawn };
    return _atlas;
  }

  /* -------------------------------------------------------------- layer --*/
  var FLEE_DUST = { rabbit: 1, hare: 1, fox: 1, badger: 1, squirrel: 1 };

  /**
   * The map's animals. Every sprite is a direct child of the tilemap at z 3 — the engine's own "same as
   * characters" layer — so animals and the party sort by their feet, and the upper layer (canopies) covers a
   * squirrel that climbs into it. Mouse holes sit at z 1 (on the wall, under everything that walks).
   * Every sprite and every animal record is made HERE, once; the frame loop allocates nothing.
   */
  function HedgerowLayer(spriteset, carry) {
    var p = P(), max = p.maxAnimals;
    this._spriteset = spriteset;
    this._atlas = atlas();
    this._max = max;
    this._pool = carry && carry.pool && carry.pool.length === max ? carry.pool : [];
    if (!this._pool.length) for (var i = 0; i < max; i++) this._pool.push(new (C().Animal)());
    this._puffs = carry && carry.puffs ? carry.puffs : [];
    if (!this._puffs.length) for (var q = 0; q < 12; q++) this._puffs.push({ x: 0, y: 0, t: -1 });
    this._rng = carry && carry.rng ? carry.rng : new (C().Rng)(seedFor($gameMap.mapId()));
    this._hab = carry && carry.hab ? carry.hab : readHabitat();
    this._loopH = $gameMap.isLoopHorizontal();
    this._loopV = $gameMap.isLoopVertical();
    this._biomes = biomesNow(this._hab);
    this._biomeKey = overrideKey();
    this._noteDensity = noteDensity();
    this._phase = phaseNow();
    this._rain = raining();
    this._wasEnabled = isEnabled();
    this._tick = 0;
    var tm = spriteset._tilemap, bm = this._atlas.bitmap, L = this._atlas.layout;
    this._tilemap = tm;
    this._sprites = []; this._extras = []; this._holes = [];
    var ay = (L.cell - L.foot) / L.cell;
    /* a lizard is drawn from above with its body DORSAL_LIFT above the foot line (so its tail fits the cell), and it
     * turns about its body, so its sprites anchor there instead */
    this._ay = ay; this._ayD = (L.cell - L.foot - D().DORSAL_LIFT * this._atlas.sc) / L.cell;
    for (var k = 0; k < max; k++) {
      this._sprites.push(this.sprite(bm, tm, 3, ay));
      this._extras.push(this.sprite(bm, tm, 3, 0));
      this._holes.push(this.sprite(bm, tm, 1, ay));
    }
    this._puffSprites = [];
    for (var r = 0; r < this._puffs.length; r++) this._puffSprites.push(this.sprite(bm, tm, 3, ay));
    this._env = {
      rng: this._rng, hab: this._hab, tw: $gameMap.tileWidth(), th: $gameMap.tileHeight(),
      playerX: 0, playerY: 0, fleeR: p.fleeRadius * ($gameMap.tileWidth() / 48), looks: looks(), spook: 0
    };
    this._eligible = null;
    this._counts = { ground: 0, wallfoot: 0, treefoot: 0, rock: 0, sand: 0, hearth: 0, x0: 0, y0: 0, x1: 0, y1: 0 };
    this.refreshRoster();
    if (!carry) this.populate();
  }

  HedgerowLayer.prototype.sprite = function (bm, tilemap, z, ay) {
    var s = new Sprite(bm);
    s.anchor.x = 0.5; s.anchor.y = ay; s.visible = false; s.z = z;
    s.setFrame(0, 0, 1, 1);
    tilemap.addChild(s);
    return s;
  };

  HedgerowLayer.prototype.refreshRoster = function () {
    var on = isEnabled() && this._biomes.indexOf('none') < 0;
    this._eligible = on ? C().eligible(this._biomes, this._phase, this._hab, looks(), P().familiesOn, this._rain) : {};
  };

  /** A view-window tile coordinate folded onto the map; -1 = off a non-looping map. */
  HedgerowLayer.prototype.foldX = function (x) { var w = this._hab.w; return this._loopH ? ((x % w) + w) % w : (x < 0 || x >= w ? -1 : x); };
  HedgerowLayer.prototype.foldY = function (y) { var h = this._hab.h; return this._loopV ? ((y % h) + h) % h : (y < 0 || y >= h ? -1 : y); };

  /** Habitat tiles of each kind inside the view (plus a one-tile margin). Allocation-free. */
  HedgerowLayer.prototype.viewCounts = function (out) {
    var hab = this._hab, tw = this._env.tw, th = this._env.th, Cc = C();
    var x0 = Math.floor($gameMap.displayX()) - 1, y0 = Math.floor($gameMap.displayY()) - 1;
    var x1 = x0 + Math.ceil(Graphics.width / tw) + 2, y1 = y0 + Math.ceil(Graphics.height / th) + 2;
    out.ground = 0; out.wallfoot = 0; out.treefoot = 0; out.rock = 0; out.sand = 0; out.hearth = 0;
    for (var y = y0; y <= y1; y++) {
      var fy = this.foldY(y);
      if (fy < 0) continue;
      for (var x = x0; x <= x1; x++) {
        var fx = this.foldX(x);
        if (fx < 0) continue;
        var g = hab.grid[fy * hab.w + fx];
        if (g & Cc.H_GROUND) out.ground++;
        if (g & Cc.H_WALLFOOT) out.wallfoot++;
        if (g & Cc.H_TREEFOOT) out.treefoot++;
        if (g & Cc.H_ROCK) out.rock++;
        if (g & Cc.H_SAND) out.sand++;
        if (g & Cc.H_HEARTH) out.hearth++;
      }
    }
    out.x0 = x0; out.y0 = y0; out.x1 = x1; out.y1 = y1;
    return out;
  };

  /**
   * A habitat tile of `kind` inside the view window and away from the player, or -1. Chosen UNIFORMLY among the
   * tiles of that kind actually in view (`v[kind]` of them): start at a random one and take the first far enough
   * from the party, wrapping once. Thirty random darts at the whole window found a sparse habitat (three tree feet
   * among ~285 tiles) about one time in five, so a field with a few trees often had no squirrel at all (fresh
   * install, 2026-10-24). Allocation-free.
   */
  HedgerowLayer.prototype.spot = function (kind, v) {
    var hab = this._hab, env = this._env, Cc = C(), n = v[kind] | 0;
    if (n <= 0) return -1;
    var start = this._rng.int(n), far = env.fleeR * env.fleeR * 1.6;
    for (var pass = 0; pass < 2; pass++) {
      var idx = 0;
      for (var y = v.y0; y <= v.y1; y++) {
        var fy = this.foldY(y);
        if (fy < 0) continue;
        for (var x = v.x0; x <= v.x1; x++) {
          var fx = this.foldX(x);
          if (fx < 0 || !Cc.isHabitat(hab, kind, fx, fy)) continue;
          if (pass === 0 && idx++ < start) continue;
          var dx = (fx + 0.5) * env.tw - env.playerX, dy = (fy + 0.5) * env.th - env.playerY;
          if (dx * dx + dy * dy < far) continue;
          return fy * hab.w + fx;
        }
      }
    }
    return -1;
  };

  HedgerowLayer.prototype.wrap = function (c) {
    var W = this._hab.w * this._env.tw, H = this._hab.h * this._env.th;
    if (this._loopH) { if (c.x >= W) { c.x -= W; c.tx -= W; c.hx -= W; } else if (c.x < 0) { c.x += W; c.tx += W; c.hx += W; } }
    if (this._loopV) { if (c.y >= H) { c.y -= H; c.ty -= H; c.hy -= H; } else if (c.y < 0) { c.y += H; c.ty += H; c.hy += H; } }
  };

  HedgerowLayer.prototype.freeSlot = function () {
    for (var i = 0; i < this._pool.length; i++) if (!this._pool[i].active) return i;
    return -1;
  };

  /**
   * Where on its home tile a family stands: mice and spiders at the wall, squirrels at the TRUNK (which a tree two
   * tiles wide puts on the line between its tiles: the habitat's `trunk` offset), lizards ON their rock.
   */
  HedgerowLayer.prototype.homePoint = function (fam, tx, ty, out) {
    var tw = this._env.tw, th = this._env.th, rng = this._rng, hab = this._hab, i = ty * hab.w + tx;
    var F = C().FAMILIES[fam];
    if (F.habitat === 'wallfoot') { out.x = (tx + rng.range(0.2, 0.8)) * tw; out.y = ty * th + (fam === 'spider' ? 1 : th * 0.16); return out; }
    if (F.habitat === 'treefoot') { out.x = (tx + 0.5 + (hab.trunk ? hab.trunk[i] : 0) / 2) * tw; out.y = ty * th + th * 0.2; return out; }
    if (F.habitat === 'rock' && hab.rock && hab.rock[i]) {
      /* basking on the near half of the rock itself: grey stone under a lizard reads where grass hid a green one */
      var r = hab.rock[i], ox = r === 1 ? -0.72 : (r === 2 ? 0.72 : 0), oy = r === 3 ? -0.62 : (r === 4 ? 0.78 : 0);
      out.x = (tx + 0.5 + ox + (ox ? 0 : rng.range(-0.15, 0.15))) * tw; out.y = (ty + 0.5 + oy + (oy ? 0 : rng.range(-0.1, 0.1))) * th;
      return out;
    }
    out.x = (tx + rng.range(0.2, 0.8)) * tw; out.y = (ty + rng.range(0.35, 0.85)) * th;
    return out;
  };

  var _pt = { x: 0, y: 0 };
  HedgerowLayer.prototype.spawnOne = function (fam, v) {
    var ids = this._eligible[fam];
    if (!ids || !ids.length) return false;
    var slot = this.freeSlot();
    if (slot < 0) return false;
    var F = C().FAMILIES[fam], lookIndex = ids[this._rng.int(ids.length)], lk = looks()[lookIndex];
    var kind = F.habitat;
    /* a cat in a house sleeps by the fire when there is one */
    if (fam === 'cat' && v.hearth > 0 && this._rng.next() < 0.6) kind = 'hearth';
    var at = this.spot(kind, v);
    if (at < 0) return false;
    var tx = at % this._hab.w, ty = Math.floor(at / this._hab.w);
    this.homePoint(fam, tx, ty, _pt);
    C().spawn(this._pool[slot], lookIndex, lk, _pt.x, _pt.y, this._rng);
    return true;
  };

  /** Fill the view to its target at once (the map is alive the moment it appears). */
  HedgerowLayer.prototype.populate = function () {
    var v = this.viewCounts(this._counts);
    for (var fam in this._eligible) {
      var F = C().FAMILIES[fam];
      var want = C().targetCount(fam, v[F.habitat], densityBase() * this._noteDensity);
      for (var i = 0; i < want; i++) if (!this.spawnOne(fam, v)) break;
    }
    for (var j = 0; j < this._pool.length; j++) if (this._pool[j].active) { this._pool[j].alpha = 1; this._pool[j].fade = 0; }
  };

  /** Twice a second: phase, rain and roster changes, then one spawn or one fade-out per family. */
  HedgerowLayer.prototype.maintain = function () {
    var ph = phaseNow(), en = isEnabled(), key = overrideKey(), rn = raining();
    if (ph !== this._phase || en !== this._wasEnabled || key !== this._biomeKey || rn !== this._rain) {
      this._phase = ph; this._wasEnabled = en; this._rain = rn;
      if (key !== this._biomeKey) { this._biomeKey = key; this._biomes = biomesNow(this._hab); }
      this.refreshRoster();
    }
    var v = this.viewCounts(this._counts), d = densityBase() * this._noteDensity, pool = this._pool, Cc = C();
    for (var fi = 0; fi < Cc.FAMILY_ORDER.length; fi++) {
      var fam = Cc.FAMILY_ORDER[fi], have = 0, last = -1, out = !this._eligible[fam];
      for (var i = 0; i < pool.length; i++) {
        if (!pool[i].active || pool[i].fam !== fam || pool[i].fade < 0) continue;
        if (out) { pool[i].fade = -1; continue; }   /* out of season: they leave together */
        have++; if (pool[i].state !== Cc.S_FLEE) last = i;
      }
      if (out) continue;
      var want = Cc.targetCount(fam, v[Cc.FAMILIES[fam].habitat], d);
      if (have < want) this.spawnOne(fam, v);
      else if (have > want && last >= 0) pool[last].fade = -1;
    }
  };

  HedgerowLayer.prototype.puff = function (x, y) {
    for (var i = 0; i < this._puffs.length; i++) { var p = this._puffs[i]; if (p.t < 0) { p.x = x; p.y = y; p.t = 0; return; } }
  };

  HedgerowLayer.prototype.scatter = function () {
    var Cc = C();
    for (var i = 0; i < this._pool.length; i++) {
      var c = this._pool[i];
      if (!c.active || (c.state !== Cc.S_CALM && c.state !== Cc.S_MOVE)) continue;
      Cc.startFlee(c, this._env, Cc.FAMILIES[c.fam]);
    }
  };

  /** One frame. Allocates nothing: every value below is a number written into an existing field. */
  HedgerowLayer.prototype.update = function () {
    var env = this._env, tw = env.tw, th = env.th, Cc = C();
    env.playerX = $gamePlayer._realX * tw + tw / 2;
    env.playerY = $gamePlayer._realY * th + th * 0.8;
    if (++this._tick % 30 === 1) this.maintain();
    var pool = this._pool, L = this._atlas.layout, cell = L.cell, cols = L.cols;
    var W = Graphics.width, H = Graphics.height, margin = tw * 2;
    var lookList = env.looks, dust = P().dust;
    for (var i = 0; i < pool.length; i++) {
      var c = pool[i], s = this._sprites[i], ex = this._extras[i], hole = this._holes[i];
      if (c.active) { Cc.step(c, env); this.wrap(c); }
      if (!c.active) { s.visible = false; ex.visible = false; hole.visible = false; continue; }
      var sx = $gameMap.adjustX(c.x / tw) * tw, sy = $gameMap.adjustY(c.y / th) * th;
      if (sx < -margin || sx > W + margin || sy < -margin || sy > H + margin) { c.active = false; s.visible = false; ex.visible = false; hole.visible = false; continue; }
      var F = Cc.FAMILIES[c.fam];
      /* a mouse hole stays on the wall while its mouse lives here */
      if (F.flee === 'hole') {
        var hidx = L.hole;
        hole.setFrame((hidx % cols) * cell, Math.floor(hidx / cols) * cell, cell, cell);
        hole.x = Math.round($gameMap.adjustX(c.hx / tw) * tw); hole.y = Math.round($gameMap.adjustY(c.hy / th) * th - th * 0.16 + 2);
        hole.opacity = Math.round(255 * Math.min(1, c.alpha * 2)); hole.visible = true;
      } else hole.visible = false;
      if (c.state === Cc.S_HIDE) { s.visible = false; ex.visible = false; continue; }
      var idx = L.first[c.look] + c.frame;
      s.setFrame((idx % cols) * cell, Math.floor(idx / cols) * cell, cell, cell);
      var fy = sy;
      if (F.flee === 'climb') fy = sy - c.lift;
      if (F.flee === 'reel') fy = sy + c.lift;
      if (F.flee === 'hole' && c.state === Cc.S_OUT) { s.x = Math.round(hole.x); fy = hole.y + 1; } else s.x = Math.round(sx);
      s.y = Math.round(fy);
      s.rotation = F.view === 'dorsal' ? c.angle : 0;
      s.anchor.y = F.view === 'dorsal' ? this._ayD : this._ay;
      s.opacity = Math.round(255 * c.alpha);
      s.visible = true;
      /* a spider's thread, from the wall above down to its back */
      if (F.flee === 'reel' && c.lift > 1) {
        var tidx = L.thread;
        ex.setFrame((tidx % cols) * cell, Math.floor(tidx / cols) * cell, cell, cell);
        ex.x = s.x; ex.y = Math.round(sy); ex.scale.y = Math.max(0.02, (c.lift - 6 * this._atlas.sc) / (cell - 2));
        ex.opacity = Math.round(200 * c.alpha); ex.visible = true;
      } else ex.visible = false;
      /* dust behind a bolting runner */
      if (dust && FLEE_DUST[c.fam] && c.state === Cc.S_FLEE && c.lift === 0 && (c.t % 6) === 0 && (c.vx * c.vx + c.vy * c.vy) > 2) this.puff(c.x, c.y);
    }
    for (var r = 0; r < this._puffs.length; r++) {
      var pf = this._puffs[r], ps = this._puffSprites[r];
      if (pf.t < 0) { ps.visible = false; continue; }
      var di = L.dust + Math.min(2, Math.floor(pf.t / 6));
      ps.setFrame((di % cols) * cell, Math.floor(di / cols) * cell, cell, cell);
      ps.x = Math.round($gameMap.adjustX(pf.x / tw) * tw); ps.y = Math.round($gameMap.adjustY(pf.y / th) * th);
      ps.opacity = 255; ps.visible = true;
      if (++pf.t >= 18) pf.t = -1;
    }
  };

  HedgerowLayer.prototype.count = function () {
    var n = 0;
    for (var i = 0; i < this._pool.length; i++) if (this._pool[i].active) n++;
    return n;
  };

  /* ------------------------------------------------------------- seams --*/
  /* The carry-over and the map counter live on globalThis, not in this closure: a buyer who enables the plugin
   * twice gets two closures, and they must agree on ONE layer. */
  var G = globalThis.CSAF._hedgerowShared || (globalThis.CSAF._hedgerowShared = { carry: null, setups: 0, seed: null });
  function seedFor(mapId) { return G.seed !== null ? (G.seed >>> 0) : C().hash('hedgerow:' + mapId); }
  /** The live layer is read off the scene, never remembered: nothing can point at a dead map's layer. */
  function currentLayer() {
    var s = typeof SceneManager !== 'undefined' ? SceneManager._scene : null;
    return s && s._spriteset && s._spriteset._csafHedgerow ? s._spriteset._csafHedgerow : null;
  }

  /* ⛔ wing §24c: every original is SAVED and CALLED. */
  var _Spriteset_Map_createLowerLayer = Spriteset_Map.prototype.createLowerLayer;
  Spriteset_Map.prototype.createLowerLayer = function () {
    _Spriteset_Map_createLowerLayer.call(this);
    if (this._csafHedgerow || !ready() || !this._tilemap || !$gameMap || !$gameMap.mapId()) return;
    /* the same map re-entered from the menu keeps its animals where they were */
    var carry = G.carry && G.carry.mapId === $gameMap.mapId() && G.carry.setups === G.setups ? G.carry : null;
    this._csafHedgerow = new HedgerowLayer(this, carry);
    var L = this._csafHedgerow;
    G.carry = { mapId: $gameMap.mapId(), setups: G.setups, pool: L._pool, puffs: L._puffs, rng: L._rng, hab: L._hab };
  };

  var _Spriteset_Map_update = Spriteset_Map.prototype.update;
  Spriteset_Map.prototype.update = function () {
    _Spriteset_Map_update.call(this);
    var L = this._csafHedgerow;
    if (L && L._frameSeen !== Graphics.frameCount) { L._frameSeen = Graphics.frameCount; L.update(); }
  };

  var _Game_Map_setup = Game_Map.prototype.setup;
  Game_Map.prototype.setup = function (mapId) {
    _Game_Map_setup.call(this, mapId);
    G.setups++;
  };

  var _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () {
    _Game_System_initialize.call(this);
    this._csafHedgerow = { v: 1, enabled: null, density: null, phase: 'auto', maps: {} };
  };

  function setEnabled(on) { var s = store(); if (s) s.enabled = !!on; }
  function setDensity(v) { var s = store(), n = Number(v); if (s && String(v).trim() !== '' && isFinite(n)) s.density = Math.max(0, Math.min(4, n)); }
  function setMapBiomes(text) {
    var s = store();
    if (!s || !$gameMap) return;
    var t = String(text === undefined || text === null ? '' : text).trim();
    if (!t) delete s.maps[$gameMap.mapId()]; else s.maps[$gameMap.mapId()] = t;
  }
  function setPhase(ph) { var s = store(), v = String(ph || 'auto'); if (s) s.phase = ['day', 'dusk', 'night'].indexOf(v) >= 0 ? v : 'auto'; }
  function scatter() { var L = currentLayer(); if (L) L.scatter(); }

  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
    PluginManager.registerCommand(NAME, 'setEnabled', function (a) { setEnabled(String(a.on) === 'true'); });
    PluginManager.registerCommand(NAME, 'setDensity', function (a) { setDensity(a.value); });
    PluginManager.registerCommand(NAME, 'setMapBiomes', function (a) { setMapBiomes(a.biomes); });
    PluginManager.registerCommand(NAME, 'setPhase', function (a) { setPhase(a.phase); });
    PluginManager.registerCommand(NAME, 'scatter', function () { scatter(); });
  }

  globalThis.CSAF.Hedgerow = {
    count: function () { var L = currentLayer(); return L ? L.count() : 0; },
    phase: function () { return phaseNow(); },
    biomes: function () { var L = currentLayer(); return L ? L._biomes.slice() : biomesNow(null); },
    habitat: function () { var L = currentLayer(); return L ? JSON.parse(JSON.stringify(L._hab.counts)) : null; },
    lookIds: function () { return ready() ? looks().map(function (s) { return s.id; }) : []; },
    scatter: scatter, setEnabled: setEnabled, setDensity: setDensity, setMapBiomes: setMapBiomes, setPhase: setPhase,
    store: store, layer: currentLayer, atlas: atlas, looks: looks,
    _setParamsForTest: function (p) { _params = p; _looks = null; _atlas = null; },
    _setSeedForTest: function (s) { G.seed = s === null || s === undefined ? null : Number(s); G.carry = null; }
  };
})();
