//=============================================================================
// Journeywork.js — Journeywork [5/5]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Journeywork [5/5] — draws a real workplace around every working NPC, and points them at the work. The only file that touches the engine.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @param trades
 * @text Trades in use
 * @desc Leave empty to use every trade in JourneyworkCorpus. Otherwise a comma-separated list of trade ids.
 * @type string
 * @default
 *
 * @param drawGround
 * @text Draw worked ground
 * @desc Paint the trodden patch each workplace stands on (ash, wet boards, swept flags...). Strongly recommended.
 * @type boolean
 * @on Draw it
 * @off Props only
 * @default true
 *
 * @param scale
 * @text Workplace scale
 * @desc Overall size of a workplace, 1.0 being tuned for 48px tiles. 0.8 is subtle, 1.2 is imposing.
 * @type number
 * @decimals 2
 * @min 0.50
 * @max 2.00
 * @default 1.00
 *
 * @param faceTheWork
 * @text Stay at the work
 * @desc While an NPC stands on its work tile it keeps that tile and faces the station. It moves normally everywhere else.
 * @type boolean
 * @on Hold it at the work
 * @off Leave movement alone
 * @default true
 *
 * @command setTrade
 * @text Set an event's trade
 * @desc Give an event a workplace at run time. Persists through save/load.
 *
 * @arg eventId
 * @text Event
 * @desc 0 means this event.
 * @type number
 * @min 0
 * @default 0
 *
 * @arg trade
 * @text Trade id
 * @desc A trade id from JourneyworkCorpus, for example smith, cooper, dyer. Empty removes the workplace.
 * @type string
 * @default
 *
 * @command clearTrade
 * @text Clear an event's trade
 * @desc Remove a workplace set with Set an event's trade. The event's own note tag, if any, applies again.
 *
 * @arg eventId
 * @text Event
 * @desc 0 means this event.
 * @type number
 * @min 0
 * @default 0
 *
 * @help
 * Journeywork.js
 *
 * ── WHAT IT DOES ─────────────────────────────────────────────────────────────
 *
 * Put <journeywork: smith> in an event's note and that event gets a smithy drawn around it: an
 * anvil on its stump, a hearth with the fire lit, a rack of tools, a quench tub, crates — none of
 * it a picture file, all of it generated from the trade when the map loads. While the NPC stands
 * at the work, it faces the work.
 *
 * ── IT DOES NOT MOVE ANYBODY ─────────────────────────────────────────────────
 *
 * Journeywork owns no pathing, no schedule and no routine. If you already use a routine plugin,
 * keep it: this furnishes the places your NPCs already walk to. If you use none, the note tag alone
 * is enough — the workplace is drawn at the tile you placed the event on, and it stays there
 * whatever the event does afterwards.
 *
 * ── EXACTLY WHAT "STAY AT THE WORK" DOES ─────────────────────────────────────
 *
 * MEASURED, not summarised. `Game_Event.updateSelfMovement` (rmmz_objects.js:9220) is the single
 * dispatch for BOTH random walking and random turning — `moveTypeRandom` calls `moveRandom`, which
 * does either. So while the NPC is standing on its work tile that method is skipped, and the effect
 * is that the worker keeps its tile AND stops turning at random. That is the whole point: the
 * complaint this answers is that NPCs at their destination "just stand on the spot turning in
 * random directions".
 *
 * What it does NOT touch:
 *   - the NPC anywhere other than its own work tile — normal movement, unchanged;
 *   - forced move routes, `moveTypeCustom`, and anything a routine plugin drives — those do not go
 *     through this branch, so a routine can still walk the worker away and bring it back;
 *   - any event without a Journeywork tag.
 *
 * Turn the parameter off and Journeywork draws the workplace and touches movement not at all.
 *
 * ── LOAD ORDER ───────────────────────────────────────────────────────────────
 *
 * Any order works. Every file resolves its siblings the first time it needs them rather than when
 * it loads, so dragging these five into the Plugin Manager in any sequence is safe. The order below
 * simply reads sensibly in the list:
 *
 *   JourneyworkForms.js · JourneyworkCorpus.js · JourneyworkShop.js · JourneyworkPlace.js ·
 *   Journeywork.js
 *
 * ── TRADES ───────────────────────────────────────────────────────────────────
 *
 * apothecary · baker · bowyer · brewer · butcher · carpenter · chandler · charcoaler · cobbler ·
 * cooper · dyer · fishwife · fletcher · glassblower · grocer · mason · miller · potter ·
 * ropemaker · salter · scribe · smith · tanner · weaver
 *
 * Plugin Command "Set an event's trade" does the same thing at run time and is saved with the game.
 *
 * ── COMPATIBILITY ────────────────────────────────────────────────────────────
 *
 * Every engine method this plugin touches is EXTENDED with its original saved and called, never
 * replaced. Run Internal_Ops/compat_facts.js for the generated list.
 *
 * ── TERMS ────────────────────────────────────────────────────────────────────
 *
 * See LICENSE.txt in the package. Free for commercial and non-commercial RPG Maker MZ projects.
 */

/* global JourneyworkCorpus, JourneyworkPlace, JourneyworkForms, JourneyworkShop,
          PluginManager, Bitmap, Sprite, Game_System, Game_Event, Game_Map, Spriteset_Map,
          Scene_Map, ImageManager */
'use strict';

var Journeywork = (function () {

  var PLUGIN_NAME = 'Journeywork';
  var SAVE_VERSION = 1;

  /*
   * ⛔ SIBLINGS RESOLVE AT FIRST USE, NEVER AT LOAD TIME.
   *
   * Wing §8 trap 2, and this is the file it was written about: the Plugin Manager loads in whatever
   * order the buyer dragged the files in, and the harness loads them ALPHABETICALLY — which puts
   * Journeywork.js FIRST, before all four modules it depends on. A load-time capture would bind
   * `undefined`, and the whole product would no-op behind one console line while every mechanical
   * check stayed green. Ships no plugin_order.json (trap 2b), so the worst case is what gets tested.
   */
  function deps() {
    var d = {
      forms: (typeof JourneyworkForms !== 'undefined' && JourneyworkForms) || null,
      corpus: (typeof JourneyworkCorpus !== 'undefined' && JourneyworkCorpus) || null,
      shop: (typeof JourneyworkShop !== 'undefined' && JourneyworkShop) || null,
      place: (typeof JourneyworkPlace !== 'undefined' && JourneyworkPlace) || null
    };
    d.ready = !!(d.forms && d.corpus && d.shop && d.place);
    return d;
  }

  // ── parameters ─────────────────────────────────────────────────────────────

  var params = null;

  /**
   * Read and cache the plugin parameters.
   * @returns {{trades: Array<string>, drawGround: boolean, scale: number, faceTheWork: boolean}}
   */
  function settings() {
    if (params) return params;
    var raw = (typeof PluginManager !== 'undefined' && PluginManager.parameters)
      ? PluginManager.parameters(PLUGIN_NAME) : {};
    var list = String(raw.trades || '').split(',')
      .map(function (t) { return t.trim(); })
      .filter(function (t) { return t.length > 0; });
    params = {
      trades: list,
      drawGround: String(raw.drawGround !== undefined ? raw.drawGround : 'true') !== 'false',
      scale: Math.max(0.5, Math.min(2, Number(raw.scale) || 1)),
      faceTheWork: String(raw.faceTheWork !== undefined ? raw.faceTheWork : 'true') !== 'false'
    };
    return params;
  }

  /**
   * Is this trade id both real and permitted by the parameters?
   * @param {string} id Trade id.
   * @returns {boolean} True if a workplace should be built for it.
   */
  function tradeAllowed(id) {
    var d = deps();
    if (!d.ready || !id) return false;
    if (!d.corpus.trade(id)) return false;
    var only = settings().trades;
    return only.length === 0 || only.indexOf(id) >= 0;
  }

  // ── which events have a workplace ──────────────────────────────────────────

  var NOTE_TAG = /<\s*journeywork\s*:\s*([A-Za-z0-9_-]+)\s*>/i;

  /**
   * The trade an event should show, honouring a run-time override before the note tag.
   *
   * ⚠️ Reads the event's note through `event()` rather than caching at map load: a plugin command
   * can change it mid-scene, and a cache would then be a second copy of a fact (wing §11a).
   *
   * @param {object} gameEvent A Game_Event.
   * @returns {string|null} Trade id, or null for no workplace.
   */
  function tradeOf(gameEvent) {
    if (!gameEvent) return null;
    var over = overrides();
    var key = String(gameEvent._mapId) + ':' + String(gameEvent._eventId);
    if (Object.prototype.hasOwnProperty.call(over, key)) {
      return over[key] ? String(over[key]) : null;      // an explicit empty override means NO workplace
    }
    var ev = gameEvent.event ? gameEvent.event() : null;
    var note = ev && ev.note ? String(ev.note) : '';
    var m = note.match(NOTE_TAG);
    return m ? m[1] : null;
  }

  /**
   * The persisted override table, created lazily on $gameSystem.
   *
   * ⚠️ Enumerable ON PURPOSE. Wing §13's non-enumerable slot is for RUNTIME caches that must not
   * reach the save file; this is the opposite — a designer's plugin command has to survive a save,
   * so it must be enumerable for JsonEx to see it. It carries its own version so a later schema can
   * migrate rather than guess.
   *
   * @returns {object} Map of "mapId:eventId" -> trade id (or '' for suppressed).
   */
  function overrides() {
    var sys = (typeof $gameSystem !== 'undefined' && $gameSystem) || null;
    if (!sys) return {};
    if (!sys._journeywork || sys._journeywork.version !== SAVE_VERSION) {
      sys._journeywork = migrate(sys._journeywork);
    }
    return sys._journeywork.trades;
  }

  /**
   * Bring a saved slot forward to the current schema.
   * @param {object|undefined} old Whatever was in the save.
   * @returns {{version: number, trades: object}} A current-schema slot.
   */
  function migrate(old) {
    var slot = { version: SAVE_VERSION, trades: {} };
    if (old && old.trades && typeof old.trades === 'object') {
      for (var k in old.trades) {
        if (Object.prototype.hasOwnProperty.call(old.trades, k)) slot.trades[k] = String(old.trades[k]);
      }
    }
    return slot;
  }

  /**
   * Set (or clear, with an empty trade) an event's workplace. Persists through save/load.
   * @param {number} mapId Map id.
   * @param {number} eventId Event id.
   * @param {string} trade Trade id, or '' to suppress the note tag.
   */
  function setTrade(mapId, eventId, trade) {
    overrides()[String(mapId) + ':' + String(eventId)] = String(trade || '');
    invalidate();
  }

  /**
   * Drop an override so the event's own note tag applies again.
   * @param {number} mapId Map id.
   * @param {number} eventId Event id.
   */
  function clearTrade(mapId, eventId) {
    delete overrides()[String(mapId) + ':' + String(eventId)];
    invalidate();
  }

  var dirty = true;

  /** Mark the current map's workplaces as needing a rebuild on the next spriteset update. */
  function invalidate() { dirty = true; }

  /** @returns {boolean} True if the workplaces need rebuilding. */
  function isDirty() { return dirty; }

  /** Clear the rebuild flag. */
  function clean() { dirty = false; }

  // ── building one workplace bitmap ──────────────────────────────────────────

  /*
   * ⛔ ONE BITMAP PER WORKPLACE, BUILT ONCE.
   *
   * Wing §3's quality bar: zero allocation in per-frame hot paths, and the MZ gate's deterministic
   * counters (draw calls <= 60, display-object growth <= 4) are what enforce it. A workplace is
   * a hundred-odd canvas primitives; drawing it per frame would fail the gate on frame one and
   * would be pointless besides, because nothing in it moves. It is painted into a Bitmap when the
   * map loads and thereafter the sprite only has two numbers assigned to it.
   */

  /**
   * Paint one trade into a fresh Bitmap and report where its origin sits inside it.
   *
   * @param {object} trade A JourneyworkCorpus trade.
   * @param {number} tileW Tile width in pixels.
   * @param {number} tileH Tile height in pixels.
   * @param {number} seed Deterministic seed.
   * @returns {{bitmap: object, anchorX: number, anchorY: number, workTile: object}} The painted
   *   workplace, with the offset from the bitmap's top-left to the station's ground point.
   */
  function buildWorkplace(trade, tileW, tileH, seed) {
    var d = deps();
    var s = settings();
    var tile = tileW || 48;

    // Solve once at the origin to learn the extent, then again inside the bitmap. Solving is pure
    // and cheap; guessing the size and clipping the art is not.
    var probe = d.place.solve(trade, { tile: tile, originX: 0, originY: 0, seed: seed, scale: (tile / 48) * s.scale });
    var fp = probe.footprint;
    var w = Math.max(tile, Math.ceil(fp.maxX - fp.minX) + 4);
    var h = Math.max(tile, Math.ceil(fp.maxY - fp.minY) + 4);
    var anchorX = Math.round(-fp.minX) + 2;
    var anchorY = Math.round(-fp.minY) + 2;

    var bitmap = new Bitmap(w, h);
    var ctx = bitmap.context;
    var solved = d.place.solve(trade, {
      tile: tile, originX: anchorX, originY: anchorY, seed: seed, scale: (tile / 48) * s.scale
    });
    d.place.paint(ctx, solved, {
      palette: d.corpus.palette(trade), seed: seed, ground: s.drawGround
    });
    if (bitmap._baseTexture) bitmap._baseTexture.update();
    if (bitmap._setDirty) bitmap._setDirty();

    return {
      bitmap: bitmap, anchorX: anchorX, anchorY: anchorY,
      workTile: solved.workTile, width: w, height: h
    };
  }

  /*
   * ⛔ THE EVENT STANDS ON THE WORK TILE; THE STATION IS DRAWN IN FRONT OF IT.
   *
   * The tempting simplification is to centre the workplace ON the event, and it quietly destroys the
   * one feature the product is sold on: if the NPC is standing inside its own anvil there is nothing
   * for it to face, and `workFrom` — which every trade in the corpus declares, and which the
   * ARCHITECTURE calls load-bearing rather than decorative — becomes ornamental data.
   *
   * So the station is offset one tile AGAINST `workTile`, the event keeps the square it is standing
   * on, and the facing is the direction from the worker to the station.
   */
  var FACING = { '0,1': 8, '0,-1': 2, '1,0': 4, '-1,0': 6 };   // MZ: 2 down, 4 left, 6 right, 8 up

  /**
   * The MZ direction an event should hold while working, derived from the furniture.
   * @param {{dx:number, dy:number}} workTile Where the worker stands relative to the station.
   * @returns {number} An MZ direction (2/4/6/8); defaults to 8.
   */
  function facingFor(workTile) {
    if (!workTile) return 8;
    return FACING[workTile.dx + ',' + workTile.dy] || 8;
  }

  return {
    PLUGIN_NAME: PLUGIN_NAME,
    SAVE_VERSION: SAVE_VERSION,
    deps: deps,
    settings: settings,
    resetSettings: function () { params = null; },
    tradeAllowed: tradeAllowed,
    tradeOf: tradeOf,
    overrides: overrides,
    migrate: migrate,
    setTrade: setTrade,
    clearTrade: clearTrade,
    invalidate: invalidate,
    isDirty: isDirty,
    clean: clean,
    buildWorkplace: buildWorkplace,
    facingFor: facingFor,
    FACING: FACING,
    NOTE_TAG: NOTE_TAG
  };
})();

/*
 * ── ENGINE PATCHES ───────────────────────────────────────────────────────────
 *
 * ⛔ Every one of these saves the original and calls it. Wing §6: patch by prototype extension with
 * saved originals; never clobber a core method outright. `compat_block.js` classifies these against
 * the real engine source and refuses to report "none replaced" unless the measured clobber count is
 * genuinely zero, so this is checked rather than claimed.
 */
(function () {
  'use strict';

  if (typeof Game_System === 'undefined') return;   // required in a bare node test; nothing to patch

  // Rebuild when the map changes.
  var _Game_Map_setup = Game_Map.prototype.setup;
  Game_Map.prototype.setup = function (mapId) {
    _Game_Map_setup.call(this, mapId);
    Journeywork.invalidate();
  };

  /*
   * THE FEATURE THE PRODUCT IS SOLD ON. Quoted from the incumbent's own listing, a buyer's
   * complaint: on reaching their destination the NPCs "just stand on the spot turning in random
   * directions". `updateSelfMovement` is where that turning happens, so while an event is standing
   * at its own work the random branch is skipped and the facing is taken FROM THE FURNITURE.
   *
   * ⚠️ Extended, not replaced: any event without a workplace, and any event with one that has walked
   * away from it, falls through to the engine's own behaviour untouched. Another routine plugin
   * wrapping the same method keeps working, because we call through.
   */
  var _Game_Event_updateSelfMovement = Game_Event.prototype.updateSelfMovement;
  Game_Event.prototype.updateSelfMovement = function () {
    if (Journeywork.settings().faceTheWork && this._journeyworkFacing && this._journeyworkAt) {
      // ⚠️ ONLY WHILE ACTUALLY AT THE WORK. An NPC that has wandered off and is still staring north
      // at nothing looks more broken than the random turning this replaces, and a `_stopCount`
      // check alone cannot tell the two apart.
      if (this.x === this._journeyworkAt.x && this.y === this._journeyworkAt.y
        && !this.isMoving() && this._stopCount > 0) {
        this.setDirection(this._journeyworkFacing);
        return;
      }
    }
    _Game_Event_updateSelfMovement.call(this);
  };

  /*
   * ── THE SPRITE LAYER ───────────────────────────────────────────────────────
   *
   * Workplaces are added as children of the TILEMAP, not of the spriteset, because the tilemap is
   * what sorts characters against each other. `Tilemap._compareChildOrder` sorts on `z` then `y`,
   * and `Sprite_Character` carries `z = screenZ()` (3 for a normal event) with `y = screenY()`, its
   * FEET. Giving a workplace the same z and setting its y to the STATION's ground point therefore
   * makes occlusion fall out of the engine's own rule: an NPC walking behind a hearth is drawn
   * behind it, one walking in front is drawn in front, and nothing here has to know about depth.
   *
   * ⚠️ The anchor is a fraction, so the station's ground point inside the bitmap becomes the
   * sprite's (x, y). That is what lets the sort key be a meaningful baseline rather than the top-left
   * corner of a tall image — which would sort every workplace far behind everything.
   */
  var _Spriteset_Map_createCharacters = Spriteset_Map.prototype.createCharacters;
  Spriteset_Map.prototype.createCharacters = function () {
    _Spriteset_Map_createCharacters.call(this);
    this._journeyworkSprites = [];
    this.createJourneyworkWorkplaces();
  };

  /** Build a sprite for every event on this map that declares a trade. */
  Spriteset_Map.prototype.createJourneyworkWorkplaces = function () {
    var d = Journeywork.deps();
    if (!d.ready || !this._tilemap) return;
    this.destroyJourneyworkWorkplaces();
    var tw = $gameMap.tileWidth(), th = $gameMap.tileHeight();
    var events = $gameMap.events();
    for (var i = 0; i < events.length; i++) {
      var ev = events[i];
      var id = Journeywork.tradeOf(ev);
      if (!Journeywork.tradeAllowed(id)) { ev._journeyworkFacing = 0; continue; }
      var trade = d.corpus.trade(id);
      // Seeded from the event so two smithies in one town differ, and so the SAME smithy is
      // identical every time the map loads (wing §6 rule 2 — a screenshot must be reproducible).
      var built = Journeywork.buildWorkplace(trade, tw, th, 1000 + ev.eventId() * 37 + $gameMap.mapId() * 7);
      var sprite = new Sprite(built.bitmap);
      sprite.anchor.x = built.anchorX / built.width;
      sprite.anchor.y = built.anchorY / built.height;
      sprite.z = 3;                                   // same band as characters, so y sorts them
      /*
       * ⛔ ANCHORED TO THE EVENT'S AUTHORED TILE, NOT TO WHERE THE EVENT CURRENTLY IS.
       *
       * The first version tracked the LIVE position, and the in-engine screenshot showed exactly
       * what that means: the NPC wandered two tiles under random movement and TOOK THE SMITHY WITH
       * HIM. An anvil that walks. Nothing in the suite could have caught it — every assertion was
       * about counts, z bands, textures and teardown, all of which were correct while the product
       * was doing something absurd.
       *
       * A workplace is a PLACE. `event().x/y` is where the designer put it and never changes, so
       * the forge stays where the forge is and the NPC is free to walk away from it and come back —
       * which is precisely the division of labour this product is built on (the routine plugin owns
       * movement, Journeywork owns the place).
       */
      var homeX = ev.event().x - built.workTile.dx;
      var homeY = ev.event().y - built.workTile.dy;
      // Carries the trade ID and the event ID, never a live Game_Event reference: the sprite
      // outlives nothing and needs nothing from the event once its home tile is known, and a held
      // reference is one more thing teardown has to get right.
      sprite._journeywork = {
        built: built, tw: tw, th: th, homeX: homeX, homeY: homeY,
        trade: id, eventId: ev.eventId()
      };
      this._tilemap.addChild(sprite);
      this._journeyworkSprites.push(sprite);
      /*
       * The facing is held only while the worker is ACTUALLY at the work — the tile the station
       * declares. Holding it unconditionally means an NPC three tiles away still stares north at
       * nothing, which looks more broken than the random turning this feature exists to replace.
       */
      ev._journeyworkFacing = Journeywork.facingFor(built.workTile);
      ev._journeyworkAt = { x: ev.event().x, y: ev.event().y };
    }
    Journeywork.clean();
  };

  /** Remove and free every workplace sprite on this spriteset. */
  Spriteset_Map.prototype.destroyJourneyworkWorkplaces = function () {
    var list = this._journeyworkSprites || [];
    for (var i = 0; i < list.length; i++) {
      if (this._tilemap) this._tilemap.removeChild(list[i]);
      // ⚠️ Free the Bitmap explicitly. Wing §6: every listener/timer/observer has a matching
      // teardown, and a per-workplace Bitmap is the largest thing this plugin allocates — leaking
      // one per map transfer is a slow crash on a long play session.
      if (list[i].bitmap && list[i].bitmap.destroy) list[i].bitmap.destroy();
      list[i].bitmap = null;
    }
    this._journeyworkSprites = [];
  };

  /*
   * ⛔ ZERO ALLOCATION IN THE PER-FRAME PATH. Two number assignments per workplace, no object
   * literals, no closures, no array methods (wing §3 quality bar; the MZ gate's deterministic
   * counters are what enforce it). Everything expensive happened once, at map load.
   */
  var _Spriteset_Map_update = Spriteset_Map.prototype.update;
  Spriteset_Map.prototype.update = function () {
    _Spriteset_Map_update.call(this);
    if (Journeywork.isDirty()) { this.createJourneyworkWorkplaces(); return; }
    var list = this._journeyworkSprites;
    if (!list) return;
    for (var i = 0; i < list.length; i++) {
      var jw = list[i]._journeywork;
      // A fixed map tile in screen space. `adjustX/adjustY` are what MZ itself uses for scrolling
      // and looped maps, so a looping map wraps the workplace exactly as it wraps the tiles.
      list[i].x = $gameMap.adjustX(jw.homeX) * jw.tw + jw.tw / 2;
      list[i].y = $gameMap.adjustY(jw.homeY) * jw.th + jw.th;
    }
  };

  // Free the bitmaps when the map scene ends, rather than waiting for the garbage collector to
  // notice a texture it cannot see the size of.
  var _Spriteset_Map_destroy = Spriteset_Map.prototype.destroy;
  Spriteset_Map.prototype.destroy = function (options) {
    this.destroyJourneyworkWorkplaces();
    _Spriteset_Map_destroy.call(this, options);
  };

  // Plugin commands.
  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
    PluginManager.registerCommand(Journeywork.PLUGIN_NAME, 'setTrade', function (args) {
      var id = Number(args.eventId) || 0;
      var ev = id > 0 ? $gameMap.event(id) : this.character(0);
      if (ev) Journeywork.setTrade($gameMap.mapId(), ev.eventId(), String(args.trade || ''));
    });
    PluginManager.registerCommand(Journeywork.PLUGIN_NAME, 'clearTrade', function (args) {
      var id = Number(args.eventId) || 0;
      var ev = id > 0 ? $gameMap.event(id) : this.character(0);
      if (ev) Journeywork.clearTrade($gameMap.mapId(), ev.eventId());
    });
  }
})();
