//=============================================================================
// JourneyworkCorpus.js — Journeywork [1/5]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Journeywork [1/5] — the authored trades. What each workplace is made of, and where the worker stands. Data only.
 * @author Core Systems Asset Factory
 *
 * @help
 * JourneyworkCorpus.js
 *
 * The authored half of the product, and the moat: one entry per trade, naming the STATION the
 * worker stands at and the SATELLITES around it BY ROLE.
 *
 * ⛔ No entry here carries a pixel coordinate. Roles are resolved by JourneyworkPlace, so adding a
 * trade is an act of authoring rather than of layout tuning, and a role that reads badly is fixed
 * ONCE for every trade that uses it (wing §11b: a coordinate constant is an assumption about a
 * pose, and every trade here is a different shape).
 *
 * ROLES: behind · behind-left · behind-right · beside-left · beside-right · fore-left ·
 *        fore-right · overhead
 */

'use strict';

var JourneyworkCorpus = (function () {

  // Materials are named, not spelled out per trade, so a town reads as one place. A trade picks a
  // palette; it never picks a hex.
  var PALETTES = {
    forge:    { wood: '#6b4a2f', iron: '#5d626b', stone: '#6e6a64', cloth: '#8a7a5c', clay: '#9a6a4a', hide: '#8a6a48' },
    market:   { wood: '#8a6740', iron: '#6b7078', stone: '#7a756c', cloth: '#a8574a', clay: '#a9784f', hide: '#8f7050' },
    scriptorium: { wood: '#5f4630', iron: '#666b72', stone: '#7d7870', cloth: '#4f6a8a', clay: '#9c7350', hide: '#8a7052' },
    bakehouse: { wood: '#7d5c3a', iron: '#63686f', stone: '#8d8378', cloth: '#b8a06a', clay: '#a87a52', hide: '#8a6a4a' },
    pottery:  { wood: '#6f5236', iron: '#616670', stone: '#75706a', cloth: '#7f8a6a', clay: '#a9673f', hide: '#8a6a4a' },
    weaving:  { wood: '#74563a', iron: '#666b73', stone: '#7a756e', cloth: '#7a5a8a', clay: '#9c7350', hide: '#8a6a4a' },
    tannery:  { wood: '#63472e', iron: '#5f646c', stone: '#6f6a63', cloth: '#8a7a5c', clay: '#96704a', hide: '#9a7346' },
    apothecary: { wood: '#5c4630', iron: '#666b72', stone: '#7f7a71', cloth: '#5a7a6a', clay: '#9c7350', hide: '#8a6a4a' }
  };

  /*
   * ⚠️ EVERY TRADE DECLARES `workFrom`, AND IT IS LOAD-BEARING RATHER THAN DECORATIVE.
   *
   * The buyer complaint this product answers, quoted from the incumbent's own page, is that on
   * arriving NPCs "just stand on the spot turning in random directions". The facing is therefore a
   * FEATURE, and it must be derived from the furniture rather than guessed: a smith faces the anvil
   * from the south, a weaver sits south of the loom, a fishwife stands BEHIND her stall facing the
   * customer. Getting this from the corpus is what makes the fix structural.
   */
  var TRADES = [
    {
      id: 'smith', name: 'Smith', palette: 'forge', ground: 'ash', station: 'anvil', workFrom: 'south',
      satellites: [
        { prop: 'hearth', role: 'behind-right' },
        { prop: 'toolRack', role: 'behind-left' },
        { prop: 'quenchTub', role: 'beside-right' },
        { prop: 'crateStack', role: 'fore-left' }
      ]
    },
    {
      id: 'fishwife', name: 'Fishwife', palette: 'market', ground: 'boards', station: 'stallTable', workFrom: 'north',
      satellites: [
        { prop: 'canopy', role: 'overhead' },
        { prop: 'catchTray', role: 'onStation' },
        { prop: 'scales', role: 'beside-right' },
        { prop: 'crateStack', role: 'fore-left' }
      ]
    },
    {
      id: 'scribe', name: 'Scribe', palette: 'scriptorium', ground: 'flags', station: 'slopeDesk', workFrom: 'south',
      satellites: [
        { prop: 'shelf', role: 'behind' },
        { prop: 'inkStand', role: 'onStation' },
        { prop: 'quireStack', role: 'beside-left' }
      ]
    },
    {
      id: 'baker', name: 'Baker', palette: 'bakehouse', ground: 'flour', station: 'doughTable', workFrom: 'south',
      satellites: [
        { prop: 'oven', role: 'behind-right' },
        { prop: 'breadRack', role: 'behind-left' },
        { prop: 'crateStack', role: 'fore-right' }
      ]
    },
    {
      id: 'potter', name: 'Potter', palette: 'pottery', ground: 'clay', station: 'wheel', workFrom: 'south',
      satellites: [
        { prop: 'kiln', role: 'behind-right' },
        { prop: 'dryingShelf', role: 'behind-left' },
        { prop: 'clayHeap', role: 'beside-left' }
      ]
    },
    {
      id: 'weaver', name: 'Weaver', palette: 'weaving', ground: 'swept', station: 'loom', workFrom: 'south',
      satellites: [
        { prop: 'clothBolt', role: 'behind-left' },
        { prop: 'spools', role: 'beside-right' },
        { prop: 'crateStack', role: 'fore-left' }
      ]
    },
    {
      id: 'tanner', name: 'Tanner', palette: 'tannery', ground: 'mud', station: 'vat', workFrom: 'south',
      satellites: [
        { prop: 'stretchFrame', role: 'behind-right' },
        { prop: 'toolRack', role: 'behind-left' },
        { prop: 'hidePile', role: 'beside-left' }
      ]
    },
    {
      id: 'apothecary', name: 'Apothecary', palette: 'apothecary', ground: 'sand', station: 'counter', workFrom: 'north',
      satellites: [
        { prop: 'bottleShelf', role: 'behind' },
        { prop: 'herbBunch', role: 'overhead' },
        { prop: 'mortar', role: 'onStation' }
      ]
    },

    /*
     * ─── the wider corpus ────────────────────────────────────────────────────────────────────────
     *
     * ⭐ THE VOLUME IS THE MOAT (CLAUDE.md §1.1 question 3), AND IT IS AUTHORING, NOT CODE. Eight
     * trades is a demo; the reason a buyer cannot reproduce this in a weekend with an LLM is that
     * somebody sat down and decided what a cooper's yard has in it that a chandler's does not.
     *
     * ⚠️ Every trade below is composed from props that ALREADY EXIST, using the variant channel
     * (`opts`) rather than new drawing code — a stave horse is a `workBench` with a stave on it, a
     * dye vat is a `vat` with different liquor, a glass furnace is a `furnace` with a white-hot
     * mouth. That is what keeps the corpus affordable, and it is also what keeps a town coherent:
     * eight yards that share a vocabulary read as one settlement, while eight yards drawn from
     * scratch read as eight art styles.
     *
     * ⛔ The line not to cross: a variant may change what a prop CONTAINS, never what it IS. A
     * corpus whose forty trades are one prop with forty colour schemes has no moat at all.
     */
    {
      id: 'carpenter', name: 'Carpenter', palette: 'forge', ground: 'swept', workFrom: 'south',
      station: { prop: 'workBench', opts: { piece: 'plank' } },
      satellites: [
        { prop: 'timberStack', role: 'behind-right' },
        { prop: 'toolRack', role: 'behind-left' },
        { prop: 'crateStack', role: 'fore-left' }
      ]
    },
    {
      id: 'cooper', name: 'Cooper', palette: 'forge', ground: 'swept', workFrom: 'south',
      station: { prop: 'shaveHorse', opts: { piece: 'stave' } },
      satellites: [
        { prop: 'caskStack', role: 'behind-right' },
        { prop: 'timberStack', role: 'behind-left', opts: { bands: false } },
        { prop: 'quenchTub', role: 'beside-right' }
      ]
    },
    {
      id: 'cobbler', name: 'Cobbler', palette: 'tannery', ground: 'flags', workFrom: 'south',
      station: 'lastBench',
      satellites: [
        { prop: 'wareStand', role: 'behind-right', opts: { wareShape: 'box', wareColours: ['#6d4a34', '#54392a', '#7c5a3c'] } },
        { prop: 'hidePile', role: 'beside-left' },
        { prop: 'toolRack', role: 'behind-left' }
      ]
    },
    {
      id: 'fletcher', name: 'Fletcher', palette: 'forge', ground: 'swept', workFrom: 'south',
      station: { prop: 'workBench', opts: { piece: 'shaft' } },
      satellites: [
        { prop: 'timberStack', role: 'behind-left', opts: { stackColour: '#8a6a42' } },
        { prop: 'wareStand', role: 'behind-right', opts: { wareShape: 'tall', wareColours: ['#b9ac86', '#8a7a56', '#c4b892'] } },
        { prop: 'crateStack', role: 'fore-right' }
      ]
    },
    {
      id: 'bowyer', name: 'Bowyer', palette: 'forge', ground: 'swept', workFrom: 'south',
      station: { prop: 'shaveHorse', opts: { piece: 'bow' } },
      satellites: [
        { prop: 'timberStack', role: 'behind-right' },
        { prop: 'quenchTub', role: 'beside-left' },
        { prop: 'toolRack', role: 'behind-left' }
      ]
    },
    {
      id: 'miller', name: 'Miller', palette: 'bakehouse', ground: 'flour', workFrom: 'south',
      station: 'millStone',
      satellites: [
        { prop: 'sackPile', role: 'behind-left' },
        { prop: 'sackPile', role: 'fore-right', opts: { sackColour: '#b8a878' } },
        { prop: 'crateStack', role: 'behind-right' }
      ]
    },
    {
      id: 'butcher', name: 'Butcher', palette: 'market', ground: 'boards', workFrom: 'south',
      station: { prop: 'workBench', opts: { piece: null } },
      satellites: [
        { prop: 'hangingBeam', role: 'overhead', opts: { hangs: 'meat' } },
        { prop: 'toolRack', role: 'behind-left' },
        { prop: 'quenchTub', role: 'beside-right' }
      ]
    },
    {
      id: 'chandler', name: 'Chandler', palette: 'bakehouse', ground: 'flags', workFrom: 'south',
      station: { prop: 'vat', opts: { liquor: '#e0d2a4' } },
      satellites: [
        { prop: 'hangingBeam', role: 'overhead', opts: { hangs: 'candles' } },
        { prop: 'wareStand', role: 'behind-right', opts: { wareShape: 'tall', wareColours: ['#e8dfc2', '#d8ceb0', '#efe7cd'] } },
        { prop: 'hearth', role: 'behind-left' }
      ]
    },
    {
      id: 'dyer', name: 'Dyer', palette: 'weaving', ground: 'mud', workFrom: 'south',
      station: { prop: 'vat', opts: { liquor: '#4a3f8a' } },
      satellites: [
        { prop: 'clothBolt', role: 'behind-left' },
        { prop: 'vat', role: 'beside-right', opts: { liquor: '#8a3f4a' } },
        { prop: 'hearth', role: 'behind-right' }
      ]
    },
    {
      id: 'brewer', name: 'Brewer', palette: 'bakehouse', ground: 'flags', workFrom: 'south',
      station: { prop: 'vat', opts: { liquor: '#a8792c' } },
      satellites: [
        { prop: 'caskStack', role: 'behind-right' },
        { prop: 'furnace', role: 'behind-left', opts: { dome: 0.8 } },
        { prop: 'sackPile', role: 'fore-left' }
      ]
    },
    {
      id: 'glassblower', name: 'Glassblower', palette: 'pottery', ground: 'ash', workFrom: 'south',
      station: { prop: 'workBench', opts: { piece: null } },
      satellites: [
        { prop: 'furnace', role: 'behind-right', opts: { mouthColour: '#ffe08a', dome: 1.05 } },
        { prop: 'wareStand', role: 'behind-left', opts: { wareShape: 'round', wareColours: ['#7fb4a8', '#5f8f9c', '#9ec4b6'] } },
        { prop: 'quenchTub', role: 'beside-right' }
      ]
    },
    {
      id: 'mason', name: 'Mason', palette: 'pottery', ground: 'sand', workFrom: 'south',
      station: 'banker',
      satellites: [
        { prop: 'timberStack', role: 'behind-right', opts: { stackColour: '#8b877d', bands: false } },
        { prop: 'toolRack', role: 'behind-left' },
        { prop: 'clayHeap', role: 'fore-left' }
      ]
    },
    {
      /*
       * ⛔ THIS ENTRY WAS `fishmonger` AND IT WAS A DUPLICATE OF `fishwife` BY CONSTRUCTION. It
       * declared the SAME palette, the SAME ground, the SAME station and the SAME facing, and three
       * of its four satellites were the fishwife's — so the only difference between two of the
       * twenty-four cells on the hero plate was a canopy against a beam. A fishwife IS a fishmonger;
       * the corpus had one job listed twice.
       *
       * ⭐ IT WAS NOT FOUND BY LOOKING, AND THAT IS THE POINT. Reviewing plate 2 by eye picked out
       * carpenter/cobbler/fletcher as the suspect family. `_probe/silhouette_pairs.js` swept all 276
       * pairs at the size a buyer judges them and ranked **Fishwife / Fishmonger IoU 0.853, tone
       * 23.0** worst by a clear margin over second place at 0.778 — and cobbler did not appear in
       * the top twelve at all. Wing §22b-2: the eye finds the pair it happens to land on, the sweep
       * finds the pair that is actually worst.
       *
       * ⚠️ THE REPLACEMENT IS A DIFFERENT JOB, NOT A RESKIN. A salter cures the catch rather than
       * selling it, so the station is the rack the split fish hang on, the work is done facing it
       * from the south rather than over a counter, and the ground is the sand of a curing yard.
       * ⛔ `stretchFrame` was the obvious station and was REJECTED: it draws a HIDE and takes no
       * variant, so a salter standing at one would be a plate captioning a property the product
       * does not draw (wing §17c). `hangingBeam` already draws fish, so the claim and the pixels
       * agree.
       */
      id: 'salter', name: 'Salter', palette: 'market', ground: 'sand', workFrom: 'south',
      station: { prop: 'hangingBeam', opts: { hangs: 'fish' } },
      satellites: [
        { prop: 'vat', role: 'beside-right', opts: { liquor: '#9fb0b6' } },
        { prop: 'caskStack', role: 'behind-left' },
        { prop: 'crateStack', role: 'fore-left' },
        // ⚠️ The market palette's cloth is a deep red, and three red mounds beside four hanging fish
        // read as RAW MEAT rather than as salt (§22a — the eye takes the nearest common category).
        // Salt sacks are pale coarse linen, so the colour is declared rather than inherited.
        { prop: 'sackPile', role: 'fore-right', opts: { sackColour: '#cfc4a8' } }
      ]
    },
    {
      id: 'ropemaker', name: 'Ropemaker', palette: 'tannery', ground: 'swept', workFrom: 'south',
      station: { prop: 'workBench', opts: { piece: null } },
      satellites: [
        { prop: 'hangingBeam', role: 'overhead', opts: { hangs: 'rope' } },
        { prop: 'sackPile', role: 'behind-left', opts: { sackColour: '#9a8a5c' } },
        { prop: 'caskStack', role: 'behind-right', opts: { caskColour: '#7a5f3c' } }
      ]
    },
    {
      id: 'charcoaler', name: 'Charcoal Burner', palette: 'forge', ground: 'ash', workFrom: 'south',
      station: { prop: 'furnace', opts: { dome: 0.72, mouthColour: '#d8541a' } },
      satellites: [
        { prop: 'timberStack', role: 'behind-left', opts: { stackColour: '#4a3a2c', bands: false } },
        { prop: 'sackPile', role: 'fore-right', opts: { sackColour: '#3e3630' } },
        { prop: 'toolRack', role: 'behind-right' }
      ]
    },
    {
      id: 'grocer', name: 'Grocer', palette: 'market', ground: 'flags', workFrom: 'north',
      station: 'counter',
      satellites: [
        { prop: 'wareStand', role: 'behind', opts: { wareShape: 'round', wareColours: ['#a8563f', '#6f8a4a', '#c2a24a'] } },
        { prop: 'sackPile', role: 'beside-left' },
        { prop: 'scales', role: 'onStation' },
        { prop: 'crateStack', role: 'fore-right' }
      ]
    }
  ];

  /**
   * Look a trade up by id.
   * @param {string} id Trade id.
   * @returns {object|null} The trade, or null.
   */
  function trade(id) {
    for (var i = 0; i < TRADES.length; i++) if (TRADES[i].id === id) return TRADES[i];
    return null;
  }

  /**
   * The palette a trade uses.
   * @param {object} t A trade.
   * @returns {object} Named material colours.
   */
  function palette(t) {
    return PALETTES[t.palette] || PALETTES.forge;
  }

  return {
    TRADES: TRADES, PALETTES: PALETTES, trade: trade, palette: palette,
    ids: TRADES.map(function (t) { return t.id; })
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = JourneyworkCorpus;
