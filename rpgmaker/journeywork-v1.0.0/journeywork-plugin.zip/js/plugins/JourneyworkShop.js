//=============================================================================
// JourneyworkShop.js — Journeywork [3/5]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Journeywork [3/5] — the props. Every workplace object, composed from the form vocabulary. Knows nothing about RPG Maker.
 * @author Core Systems Asset Factory
 *
 * @help
 * JourneyworkShop.js
 *
 * One function per prop. Each is built ONLY from JourneyworkForms primitives, so a prop cannot
 * quietly acquire a hand-tuned coordinate that is right for one trade and wrong for the next
 * (wing §11b: a constant in a figure's coordinate space is an assumption about its pose).
 *
 * Every prop takes (c, o) where o carries {x, yBase, scale, palette, seed} and draws standing on
 * yBase, centred on x. Nothing here reads a global.
 */

/* global JourneyworkForms */
'use strict';

var JourneyworkShop = (function () {

  /**
   * Resolve the sibling at FIRST USE, never at load time. Wing §8 trap 2: the harness loads the
   * plugin folder ALPHABETICALLY, which puts Journeywork.js before the four files it uses, and a
   * load-time capture would bind `undefined` and no-op the whole product behind one console line.
   * @returns {object} The forms module.
   */
  function F() {
    var f = (typeof JourneyworkForms !== 'undefined' && JourneyworkForms)
      || (typeof require !== 'undefined' && require('./JourneyworkForms.js'));
    if (!f) throw new Error('Journeywork: JourneyworkForms.js is not loaded');
    return f;
  }

  // --- smith -----------------------------------------------------------------

  /*
   * ⛔ RE-AUTHORED 2026-09-03. The anvil is the object that says "smithy" and it was reading as a
   * dark lump: its horn was 26 * 0.26 = under 7px at map scale, i.e. below the threshold at which a
   * shape is a shape at all, and dark iron sat on a dark ash floor with nothing separating them.
   *
   * The silhouette is now the recognisable one — a long drawn-out horn, a waisted body and a heavy
   * stump — and the face is lit hard, because the ONE thing a forge scene can rely on for contrast
   * is that the metal catches the fire behind it.
   */
  function anvil(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 22 * s, h = 24 * s;
    f.ground(c, { x: o.x, yBase: o.yBase, w: w * 1.1 });
    /*
     * ⚠️ SECOND REWRITE IN ONE SESSION, AND THE FIRST ONE IS WHY THIS COMMENT EXISTS. Told that the
     * horn is what identifies an anvil, I drew a LONG one — 0.62w, plus a face bar of 0.74w — and
     * the detail render showed the result plainly: one continuous light-grey elongated shape with a
     * pointed nose, sitting horizontally. It read as a FISH. Nothing was wrong with any individual
     * element; the total was 1.36 x w of unbroken horizontal mass, and at map scale a silhouette
     * that wide has no top and no bottom, only a direction.
     *
     * ⭐ The lesson generalises past this prop: at 48px an object is read by its ASPECT and its
     * OUTLINE BREAKS before any of its features. A correct feature drawn large enough to dominate
     * the aspect destroys the read it was added to create. So the anvil is now COMPACT and UPRIGHT —
     * taller than wide, on a visibly tall stump — and the horn is a short stub that breaks the
     * outline on one side only. Being on a block is a stronger signal than the horn ever was.
     */
    var stumpTop = o.yBase - h * 0.52;
    c.fillStyle = f.shade(p.wood, -0.42);                      // the stump: a real vertical block
    c.beginPath();
    c.moveTo(o.x - w * 0.42, o.yBase);
    c.lineTo(o.x + w * 0.42, o.yBase);
    c.lineTo(o.x + w * 0.34, stumpTop);
    c.lineTo(o.x - w * 0.34, stumpTop);
    c.closePath(); c.fill();
    c.fillStyle = f.shade(p.wood, -0.18);                      // lit side of the stump
    c.fillRect(o.x - w * 0.34, stumpTop, w * 0.16, h * 0.52);
    c.strokeStyle = f.shade(p.wood, -0.58); c.lineWidth = 1;
    c.beginPath();
    c.moveTo(o.x - w * 0.05, stumpTop + 2 * s); c.lineTo(o.x - w * 0.02, o.yBase - 1 * s);
    c.stroke();

    var faceY = o.yBase - h;
    c.fillStyle = f.shade(p.iron, -0.36);                      // waist: narrower than foot AND face
    c.beginPath();
    c.moveTo(o.x - w * 0.30, stumpTop);
    c.lineTo(o.x + w * 0.30, stumpTop);
    c.lineTo(o.x + w * 0.20, faceY + h * 0.20);
    c.lineTo(o.x - w * 0.20, faceY + h * 0.20);
    c.closePath(); c.fill();
    c.fillStyle = f.shade(p.iron, -0.18);                      // the block, overhanging the waist
    c.fillRect(o.x - w * 0.40, faceY + h * 0.06, w * 0.80, h * 0.15);
    c.fillStyle = f.shade(p.iron, -0.06);                      // horn: a SHORT stub, one side only
    c.beginPath();
    c.moveTo(o.x + w * 0.38, faceY + h * 0.05);
    c.lineTo(o.x + w * 0.68, faceY + h * 0.12);
    c.lineTo(o.x + w * 0.38, faceY + h * 0.20);
    c.closePath(); c.fill();
    c.fillStyle = f.shade(p.iron, 0.40);                       // the face, lit hard by the forge
    c.fillRect(o.x - w * 0.42, faceY - h * 0.01, w * 0.82, h * 0.08);
    c.fillStyle = f.shade(p.iron, 0.16);
    c.fillRect(o.x + w * 0.38, faceY + h * 0.04, w * 0.22, h * 0.04);
    // A billet cooling on the face — orange is the one hue nothing else in the smithy owns except
    // the fire itself, so it ties the anvil to the hearth and says the place is in use.
    c.fillStyle = '#d9601c';
    c.fillRect(o.x - w * 0.26, faceY - h * 0.045, w * 0.30, h * 0.035);
    c.fillStyle = '#ffb04a';
    c.fillRect(o.x - w * 0.26, faceY - h * 0.045, w * 0.13, h * 0.035);
  }

  function hearth(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 30 * s, h = 30 * s;
    f.ground(c, { x: o.x, yBase: o.yBase, w: w });
    c.fillStyle = f.shade(p.stone, -0.24);
    c.fillRect(o.x - w / 2, o.yBase - h * 0.62, w, h * 0.62);
    c.fillStyle = f.shade(p.stone, 0.10);
    c.fillRect(o.x - w / 2, o.yBase - h * 0.62, w, 3 * s);
    c.fillStyle = '#1b1210';                                   // fire mouth
    c.beginPath();
    c.moveTo(o.x - w * 0.24, o.yBase - h * 0.10);
    c.lineTo(o.x + w * 0.24, o.yBase - h * 0.10);
    c.lineTo(o.x + w * 0.20, o.yBase - h * 0.44);
    c.lineTo(o.x - w * 0.20, o.yBase - h * 0.44);
    c.closePath(); c.fill();
    var r = f.rng(o.seed || 3);
    for (var i = 0; i < 5; i++) {                              // coals, deterministic
      c.fillStyle = i % 2 ? '#ff9a3c' : '#e8541f';
      c.beginPath();
      c.arc(o.x + (r() - 0.5) * w * 0.34, o.yBase - h * 0.16 - r() * h * 0.16, (1 + r() * 2) * s, 0, Math.PI * 2);
      c.fill();
    }
    c.fillStyle = f.shade(p.stone, -0.4);                      // chimney hood
    c.beginPath();
    c.moveTo(o.x - w * 0.50, o.yBase - h * 0.62);
    c.lineTo(o.x + w * 0.50, o.yBase - h * 0.62);
    c.lineTo(o.x + w * 0.22, o.yBase - h);
    c.lineTo(o.x - w * 0.22, o.yBase - h);
    c.closePath(); c.fill();
  }

  function quenchTub(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    f.ground(c, { x: o.x, yBase: o.yBase, w: 16 * s });
    f.vessel(c, { x: o.x, yBase: o.yBase, w: 16 * s, h: 13 * s, colour: p.wood, staves: 5, fill: '#2e5a6b' });
  }

  /**
   * Tools stood in a rack, their handles running PAST the rail — the contents break the outline, so
   * this no longer shares a silhouette with the six other frame-based props (see `shelf`).
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} o {x,yBase,scale,palette,seed}
   */
  function toolRack(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 23 * s, h = 24 * s;
    var top = o.yBase - h;
    f.ground(c, { x: o.x, yBase: o.yBase, w: w });
    f.post(c, { x: o.x - w * 0.44, yBase: o.yBase, height: h, w: 3.4 * s, colour: p.wood });
    f.post(c, { x: o.x + w * 0.44, yBase: o.yBase, height: h, w: 3.4 * s, colour: p.wood });
    f.plank(c, { x: o.x - w * 0.50, y: top + h * 0.30, w: w, h: 3 * s, depth: 2.4 * s, colour: p.wood });
    var r = f.rng(o.seed || 41);
    var kinds = ['hammer', 'tongs', 'punch', 'file'];
    for (var i = 0; i < 4; i++) {
      var tx = o.x - w * 0.33 + i * w * 0.22;
      var lean = (r() - 0.5) * 0.30;                           // no two stand quite straight
      c.save();
      c.translate(tx, o.yBase);
      c.rotate(lean);
      c.fillStyle = f.shade(p.wood, -0.10);                    // the handle, running above the rail
      c.fillRect(-1.2 * s, -h * 1.06, 2.4 * s, h * 1.06);
      var k = kinds[i];
      c.fillStyle = f.shade(p.iron, i % 2 ? 0.06 : -0.12);
      if (k === 'hammer') c.fillRect(-4 * s, -h * 1.12, 8 * s, 4.4 * s);
      else if (k === 'tongs') {                                // two legs, open
        c.fillRect(-3.4 * s, -h * 1.14, 1.8 * s, 6 * s);
        c.fillRect(1.6 * s, -h * 1.14, 1.8 * s, 6 * s);
      } else if (k === 'punch') {
        c.beginPath();
        c.moveTo(-2.4 * s, -h * 1.06); c.lineTo(2.4 * s, -h * 1.06); c.lineTo(0, -h * 1.20);
        c.closePath(); c.fill();
      } else {
        c.fillRect(-1.6 * s, -h * 1.18, 3.2 * s, 7 * s);
      }
      c.restore();
    }
  }

  // --- fishwife / market -----------------------------------------------------

  function stallTable(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 34 * s, h = 14 * s;
    f.ground(c, { x: o.x, yBase: o.yBase, w: w });
    f.post(c, { x: o.x - w * 0.42, yBase: o.yBase, height: h, w: 3 * s, colour: p.wood });
    f.post(c, { x: o.x + w * 0.42, yBase: o.yBase, height: h, w: 3 * s, colour: p.wood });
    f.plank(c, { x: o.x - w / 2, y: o.yBase - h, w: w, h: 4 * s, depth: 4 * s, colour: p.wood, grain: true });
  }

  function canopy(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 38 * s;
    f.post(c, { x: o.x - w * 0.44, yBase: o.yBase, height: 30 * s, w: 3 * s, colour: p.wood });
    f.post(c, { x: o.x + w * 0.44, yBase: o.yBase, height: 30 * s, w: 3 * s, colour: p.wood });
    f.cloth(c, { x: o.x, y: o.yBase - 30 * s, w: w, h: 11 * s, colour: p.cloth, folds: 5, sag: 4 * s });
  }

  function catchTray(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 15 * s;
    f.plank(c, { x: o.x - w / 2, y: o.yBase - 2 * s, w: w, h: 2 * s, depth: 2 * s, colour: p.wood });
    var r = f.rng(o.seed || 11);
    for (var i = 0; i < 4; i++) {                              // the catch itself
      var fx = o.x - w * 0.34 + i * w * 0.22;
      c.fillStyle = i % 2 ? '#9fb6c4' : '#7d97a8';
      c.beginPath();
      c.ellipse(fx, o.yBase - 4 * s - r() * s, 4 * s, 1.8 * s, -0.25, 0, Math.PI * 2);
      c.fill();
    }
  }

  function scales(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var h = 18 * s;
    f.post(c, { x: o.x, yBase: o.yBase, height: h, w: 2 * s, colour: p.iron });
    f.band(c, { x: o.x, y: o.yBase - h, w: 14 * s, colour: f.shade(p.iron, 0.1), thickness: 2 * s });
    for (var d = -1; d <= 1; d += 2) {
      c.strokeStyle = f.shade(p.iron, -0.2); c.lineWidth = 1;
      c.beginPath();
      c.moveTo(o.x + d * 7 * s, o.yBase - h);
      c.lineTo(o.x + d * 7 * s, o.yBase - h + 5 * s);
      c.stroke();
      c.fillStyle = f.shade(p.iron, -0.05);
      c.beginPath();
      c.ellipse(o.x + d * 7 * s, o.yBase - h + 6 * s, 4 * s, 1.6 * s, 0, 0, Math.PI * 2);
      c.fill();
    }
  }

  function crateStack(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 14 * s;
    f.ground(c, { x: o.x, yBase: o.yBase, w: w });
    for (var i = 0; i < 2; i++) {
      var yy = o.yBase - i * 9 * s;
      f.plank(c, { x: o.x - w / 2 + i * 2 * s, y: yy - 9 * s, w: w, h: 9 * s, depth: 3 * s, colour: p.wood, grain: false });
      f.band(c, { x: o.x + i * s, y: yy - 5 * s, w: w, colour: f.shade(p.wood, -0.5), thickness: 1.5 * s });
    }
  }

  // --- scribe ----------------------------------------------------------------

  /*
   * ⛔ RE-AUTHORED 2026-09-03 AFTER LOOKING AT THE 48px SHEET. The first version was two thin posts
   * under a shallow board, and at map scale a scriptorium read as "a diagonal plank leaning on a
   * cabinet" — the single worst cell of the eight. Two things were wrong and only one was obvious.
   *
   *   MASS: two 3px legs put almost no ink on the screen, so the station lost to its own shelf even
   *         after the measured hierarchy clamp said their HEIGHTS were comparable. Height is not
   *         dominance; a tall open frame reads lighter than a short solid body.
   *   ANGLE: a 7px rise over a 26px board is a 15 degree slope, which at 48px is indistinguishable
   *         from a flat table seen in projection. A lectern reads as a lectern because the slope is
   *         steep enough to be unambiguous.
   */
  function slopeDesk(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 27 * s, h = 15 * s;
    f.ground(c, { x: o.x, yBase: o.yBase, w: w });
    // A solid pedestal body, not legs — this is the mass that makes the station win.
    c.fillStyle = f.shade(p.wood, -0.34);
    c.fillRect(o.x - w * 0.40, o.yBase - h, w * 0.80, h);
    c.fillStyle = f.shade(p.wood, -0.48);                      // a recessed panel, so it is not a slab
    c.fillRect(o.x - w * 0.30, o.yBase - h * 0.82, w * 0.60, h * 0.58);
    var top = o.yBase - h;
    var rise = 12 * s;                                         // steep: the read depends on it
    c.fillStyle = f.shade(p.wood, 0.02);                       // the sloped board, lit
    c.beginPath();
    c.moveTo(o.x - w * 0.52, top + 2 * s);
    c.lineTo(o.x + w * 0.50, top - rise);
    c.lineTo(o.x + w * 0.50, top - rise + 4 * s);
    c.lineTo(o.x - w * 0.52, top + 6 * s);
    c.closePath(); c.fill();
    c.fillStyle = f.shade(p.wood, -0.5);                       // the lip that stops the book sliding
    c.fillRect(o.x - w * 0.52, top + 2 * s, w * 0.10, 4.5 * s);
    c.fillStyle = '#efe6d0';                                   // an open bifolium on the slope
    c.beginPath();
    c.moveTo(o.x - w * 0.40, top - 0.4 * s);
    c.lineTo(o.x + w * 0.40, top - rise + 1.6 * s);
    c.lineTo(o.x + w * 0.40, top - rise + 4.4 * s);
    c.lineTo(o.x - w * 0.40, top + 2.4 * s);
    c.closePath(); c.fill();
    c.strokeStyle = '#8d8470'; c.lineWidth = 1; c.globalAlpha = 0.7;
    for (var i = 1; i <= 3; i++) {                             // ruled lines, so it reads as WRITING
      var t = i / 4;
      c.beginPath();
      c.moveTo(o.x - w * 0.36, top + 0.6 * s - rise * t * 0.14 + t * 1.6 * s);
      c.lineTo(o.x + w * 0.34, top - rise + 2.2 * s + t * 1.6 * s);
      c.stroke();
    }
    c.globalAlpha = 1;
    c.fillStyle = f.shade(p.iron, -0.2);                       // the pen, mid-stroke
    c.beginPath();
    c.moveTo(o.x + w * 0.06, top - rise * 0.52);
    c.lineTo(o.x + w * 0.20, top - rise * 0.95 - 7 * s);
    c.lineTo(o.x + w * 0.13, top - rise * 0.95 - 7 * s);
    c.closePath(); c.fill();
  }

  function inkStand(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    f.vessel(c, { x: o.x, yBase: o.yBase, w: 6 * s, h: 5 * s, colour: p.stone, staves: 0, rim: false, fill: '#1c1a2e' });
    f.edge(c, { x: o.x + 2 * s, y: o.yBase - 5 * s, len: 9 * s, spread: 1.6 * s, angle: -1.15, colour: '#f2ead6' });
  }

  function quireStack(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    for (var i = 0; i < 4; i++) {
      f.plank(c, {
        x: o.x - 7 * s + (i % 2) * s, y: o.yBase - (i + 1) * 2.4 * s,
        w: 14 * s, h: 2.2 * s, depth: 2 * s,
        colour: i % 2 ? '#e8dec4' : '#dfd3b4', grain: false
      });
    }
  }

  /*
   * ⛔ THE SHARED-SILHOUETTE DEFECT, FIXED WHERE IT IS WORST. Seven of thirty props were built on
   * `JourneyworkForms.frame` — toolRack, shelf, breadRack, dryingShelf, loom, stretchFrame,
   * bottleShelf — so six of eight trades were dominated by ONE outline: an upright rectangle with
   * horizontal bars, which at 48px reads as a window in every trade that has it.
   *
   * ⭐ The rule that fixes it without abandoning the shared primitive: THE CONTENTS MUST BREAK THE
   * OUTLINE. A rack whose tools project above its rail, a shelf whose scrolls stick out toward the
   * viewer and a loom whose posts run past its beam all have different silhouettes even though the
   * frame underneath them is identical. Silhouette is what survives at map scale; interior detail is
   * not. This is the same lesson wing §11b records for pose, applied to outline.
   *
   * A scriptorium press: pigeonholes, seen end-on, with the rolled ends of scrolls projecting out.
   */
  function shelf(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 23 * s, h = 27 * s;
    var x0 = o.x - w / 2, top = o.yBase - h;
    c.fillStyle = f.shade(p.wood, -0.42);                      // carcase
    c.fillRect(x0, top, w, h);
    c.fillStyle = f.shade(p.wood, -0.62);                      // the dark of the holes
    c.fillRect(x0 + 2 * s, top + 2 * s, w - 4 * s, h - 5 * s);
    c.fillStyle = f.shade(p.wood, -0.24);                      // dividers: 3 rows x 2 columns
    for (var row = 1; row < 3; row++) {
      c.fillRect(x0 + 2 * s, Math.round(top + 2 * s + ((h - 7 * s) * row) / 3), w - 4 * s, 1.8 * s);
    }
    c.fillRect(Math.round(o.x - 0.9 * s), top + 2 * s, 1.8 * s, h - 5 * s);
    c.fillStyle = f.shade(p.wood, 0.14);                       // lit top edge and plinth
    c.fillRect(x0 - 1 * s, top - 2 * s, w + 2 * s, 2.6 * s);
    c.fillRect(x0 - 1 * s, o.yBase - 3 * s, w + 2 * s, 3 * s);
    var r = f.rng(o.seed || 5);
    for (var i = 0; i < 6; i++) {                              // scroll ends, PROJECTING past the front
      var rr = Math.floor(i / 2), cc = i % 2;
      var cx = x0 + 3 * s + cc * (w * 0.48) + (w * 0.20);
      var cy = top + 4 * s + ((h - 7 * s) * rr) / 3 + (h - 7 * s) / 6;
      if (r() > 0.82) continue;                                // a pigeonhole or two left empty
      /*
       * ⚠️ These were '#e5dcc2' at 3.2s radius and read as WHITE EGGS in a rack — the brightest
       * pixels in the whole cell, on a satellite, which is the opposite of the hierarchy the rest of
       * the file works to build. A scroll end is vellum in a dark hole: it wants to be the lightest
       * thing INSIDE the press and darker than the lit rim of the station.
       */
      c.fillStyle = '#cdc2a4';
      c.beginPath(); c.ellipse(cx, cy, 2.6 * s, 2.1 * s, 0, 0, Math.PI * 2); c.fill();
      c.fillStyle = '#9d9077';
      c.beginPath(); c.ellipse(cx + 0.6 * s, cy + 0.4 * s, 1.2 * s, 1.0 * s, 0, 0, Math.PI * 2); c.fill();
      c.fillStyle = ['#8a4a3f', '#4a6f8a', '#7a6a3f'][i % 3]; // a tag hanging off one
      if (i % 3 === 0) c.fillRect(cx - 0.6 * s, cy + 2.4 * s, 1.4 * s, 3.4 * s);
    }
  }

  // --- baker -----------------------------------------------------------------

  function oven(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 30 * s, h = 26 * s;
    f.ground(c, { x: o.x, yBase: o.yBase, w: w });
    c.fillStyle = f.shade(p.stone, -0.2);                      // dome
    c.beginPath();
    c.moveTo(o.x - w / 2, o.yBase);
    c.lineTo(o.x - w / 2, o.yBase - h * 0.4);
    c.quadraticCurveTo(o.x, o.yBase - h * 1.25, o.x + w / 2, o.yBase - h * 0.4);
    c.lineTo(o.x + w / 2, o.yBase);
    c.closePath(); c.fill();
    c.fillStyle = f.shade(p.stone, 0.12);
    c.beginPath();
    c.moveTo(o.x - w * 0.42, o.yBase - h * 0.45);
    c.quadraticCurveTo(o.x - w * 0.12, o.yBase - h * 1.05, o.x, o.yBase - h * 0.95);
    c.lineTo(o.x - w * 0.30, o.yBase - h * 0.42);
    c.closePath(); c.fill();
    c.fillStyle = '#160f0c';                                   // mouth
    c.beginPath();
    c.ellipse(o.x, o.yBase - h * 0.22, w * 0.20, h * 0.20, 0, 0, Math.PI * 2);
    c.fill();
    c.fillStyle = '#ff8a2b';
    c.beginPath();
    c.ellipse(o.x, o.yBase - h * 0.18, w * 0.13, h * 0.11, 0, 0, Math.PI * 2);
    c.fill();
  }

  function doughTable(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 26 * s, h = 13 * s;
    f.ground(c, { x: o.x, yBase: o.yBase, w: w });
    f.post(c, { x: o.x - w * 0.40, yBase: o.yBase, height: h, w: 3 * s, colour: p.wood });
    f.post(c, { x: o.x + w * 0.40, yBase: o.yBase, height: h, w: 3 * s, colour: p.wood });
    f.plank(c, { x: o.x - w / 2, y: o.yBase - h, w: w, h: 3.5 * s, depth: 3 * s, colour: p.wood, grain: true });
    var r = f.rng(o.seed || 13);
    for (var i = 0; i < 3; i++) {                              // rounds proving
      c.fillStyle = '#e6cfa3';
      c.beginPath();
      c.ellipse(o.x - 7 * s + i * 7 * s, o.yBase - h - 2 * s, 3.2 * s, 2.2 * s, 0, 0, Math.PI * 2);
      c.fill();
      r();
    }
  }

  function breadRack(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    f.frame(c, { x: o.x, yBase: o.yBase, w: 24 * s, h: 30 * s, colour: p.wood, thickness: 3 * s, rungs: 2 });
    for (var row = 1; row <= 2; row++) {
      for (var i = 0; i < 3; i++) {
        c.fillStyle = row === 1 ? '#c98f4e' : '#b87c3f';
        c.beginPath();
        c.ellipse(o.x - 7 * s + i * 7 * s, o.yBase - 30 * s + (30 * s * row) / 3 - 2.5 * s, 3.2 * s, 2.4 * s, 0, 0, Math.PI * 2);
        c.fill();
      }
    }
  }

  // --- potter ----------------------------------------------------------------

  function wheel(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    f.ground(c, { x: o.x, yBase: o.yBase, w: 18 * s });
    f.post(c, { x: o.x, yBase: o.yBase, height: 13 * s, w: 4 * s, colour: p.wood });
    c.fillStyle = f.shade(p.wood, -0.35);
    c.beginPath(); c.ellipse(o.x, o.yBase - 13 * s, 9 * s, 3 * s, 0, 0, Math.PI * 2); c.fill();
    c.fillStyle = f.shade(p.wood, 0.10);
    c.beginPath(); c.ellipse(o.x, o.yBase - 14 * s, 9 * s, 3 * s, 0, 0, Math.PI * 2); c.fill();
    f.vessel(c, { x: o.x, yBase: o.yBase - 14 * s, w: 8 * s, h: 8 * s, colour: p.clay, staves: 0, rim: false });
  }

  function kiln(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 24 * s, h = 30 * s;
    f.ground(c, { x: o.x, yBase: o.yBase, w: w });
    c.fillStyle = f.shade(p.clay, -0.3);
    c.beginPath();
    c.moveTo(o.x - w / 2, o.yBase);
    c.lineTo(o.x - w * 0.34, o.yBase - h * 0.8);
    c.lineTo(o.x + w * 0.34, o.yBase - h * 0.8);
    c.lineTo(o.x + w / 2, o.yBase);
    c.closePath(); c.fill();
    f.post(c, { x: o.x, yBase: o.yBase - h * 0.8, height: h * 0.24, w: 6 * s, colour: f.shade(p.clay, -0.45) });
    c.fillStyle = '#170f0c';
    c.fillRect(o.x - w * 0.14, o.yBase - h * 0.30, w * 0.28, h * 0.30);
    c.fillStyle = '#ff7a22';
    c.fillRect(o.x - w * 0.10, o.yBase - h * 0.22, w * 0.20, h * 0.22);
  }

  function clayHeap(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    f.heap(c, { x: o.x, yBase: o.yBase, w: 18 * s, h: 9 * s, colour: p.clay, seed: o.seed || 21, lumps: 8 });
  }

  function dryingShelf(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    f.frame(c, { x: o.x, yBase: o.yBase, w: 22 * s, h: 26 * s, colour: p.wood, thickness: 3 * s, rungs: 2 });
    for (var row = 1; row <= 2; row++) {
      for (var i = 0; i < 3; i++) {
        f.vessel(c, {
          x: o.x - 6.5 * s + i * 6.5 * s,
          yBase: o.yBase - 26 * s + (26 * s * row) / 3,
          w: 5 * s, h: 6 * s, colour: p.clay, staves: 0, rim: false
        });
      }
    }
  }

  // --- weaver ----------------------------------------------------------------

  /*
   * ⛔ RE-AUTHORED 2026-09-03. The first loom was `frame` + eleven full-strength white verticals, and
   * at 48px a weaver's shed read as a BARCODE — the brightest, flattest thing on the sheet, and one
   * more upright rectangle in a corpus that already had six.
   *
   * A loom is recognised by its posts running PAST the top beam and by the cloth beam across its
   * waist, so both now break the outline. The warp is drawn at a fraction of the old strength: it is
   * texture, and texture read at full contrast becomes the subject.
   */
  function loom(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 27 * s, h = 33 * s;
    var x0 = o.x - w / 2, top = o.yBase - h;
    f.ground(c, { x: o.x, yBase: o.yBase, w: w * 1.1 });
    // Posts, run long — the overhang above the beam is the whole silhouette.
    f.post(c, { x: x0 + 2.5 * s, yBase: o.yBase, height: h + 5 * s, w: 4.5 * s, colour: p.wood });
    f.post(c, { x: x0 + w - 2.5 * s, yBase: o.yBase, height: h + 5 * s, w: 4.5 * s, colour: p.wood });
    // Warp beam across the top, overhanging both posts.
    f.plank(c, { x: x0 - 3 * s, y: top - 1 * s, w: w + 6 * s, h: 4 * s, depth: 2.5 * s, colour: p.wood, grain: false });
    c.strokeStyle = '#ded5bd'; c.lineWidth = 1; c.globalAlpha = 0.34;   // warp: texture, not subject
    for (var i = 1; i < 10; i++) {
      var xx = Math.round(x0 + (w * i) / 10) + 0.5;
      c.beginPath(); c.moveTo(xx, top + 4 * s); c.lineTo(xx, o.yBase - h * 0.44); c.stroke();
    }
    c.globalAlpha = 1;
    // The heddle bar, slung across at an angle so the machine reads as working rather than empty.
    c.fillStyle = f.shade(p.wood, -0.5);
    c.save();
    c.translate(o.x, top + h * 0.34);
    c.rotate(-0.06);
    c.fillRect(-w * 0.52, -1.6 * s, w * 1.04, 3.2 * s);
    c.restore();
    // Cloth beam and the web woven so far — a solid mass at the waist, breaking the frame's sides.
    f.plank(c, { x: x0 - 2 * s, y: o.yBase - h * 0.40, w: w + 4 * s, h: 3.4 * s, depth: 2 * s, colour: p.wood });
    c.fillStyle = p.cloth;
    c.fillRect(x0 + 3 * s, o.yBase - h * 0.36, w - 6 * s, h * 0.22);
    c.fillStyle = f.shade(p.cloth, -0.26);                     // a woven band, so it is not flat colour
    for (var b = 0; b < 3; b++) {
      c.fillRect(x0 + 3 * s, o.yBase - h * 0.32 + b * h * 0.06, w - 6 * s, h * 0.022);
    }
    c.fillStyle = f.shade(p.cloth, 0.18);
    c.fillRect(x0 + 3 * s, o.yBase - h * 0.36, w - 6 * s, 1.4 * s);
    // The bench the weaver sits on, in front — it is why the trade has a `workFrom`.
    f.plank(c, { x: o.x - w * 0.34, y: o.yBase - 6 * s, w: w * 0.68, h: 2.8 * s, depth: 2.4 * s, colour: p.wood });
    f.post(c, { x: o.x - w * 0.28, yBase: o.yBase, height: 6 * s, w: 2 * s, colour: p.wood });
    f.post(c, { x: o.x + w * 0.28, yBase: o.yBase, height: 6 * s, w: 2 * s, colour: p.wood });
  }

  function spools(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var cols = ['#a8425a', '#3f6f8a', '#c9a13c'];
    for (var i = 0; i < 3; i++) {
      var xx = o.x - 6 * s + i * 6 * s;
      f.post(c, { x: xx, yBase: o.yBase, height: 8 * s, w: 2 * s, colour: p.wood });
      c.fillStyle = cols[i];
      c.beginPath(); c.ellipse(xx, o.yBase - 5 * s, 3 * s, 3.4 * s, 0, 0, Math.PI * 2); c.fill();
    }
  }

  function clothBolt(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    f.cloth(c, { x: o.x, y: o.yBase - 22 * s, w: 14 * s, h: 22 * s, colour: p.cloth, folds: 3, sag: 3 * s });
  }

  // --- tanner ----------------------------------------------------------------

  /*
   * ⛔ RE-AUTHORED 2026-09-03. Another `frame` rectangle, and the tannery's whole read depended on
   * it. A stretching frame in the world is a LEANING A-frame with the hide lashed inside it and the
   * skin's own ragged outline hanging past the timber — nothing about it is a rectangle. The
   * splayed legs and the irregular hide give it a silhouette no other prop in the corpus shares.
   */
  function stretchFrame(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 27 * s, h = 31 * s;
    var top = o.yBase - h, lean = w * 0.20;
    f.ground(c, { x: o.x, yBase: o.yBase, w: w * 1.05 });
    c.strokeStyle = f.shade(p.wood, -0.22); c.lineWidth = 3.4 * s; c.lineCap = 'round';
    c.beginPath();                                             // splayed legs, meeting near the top
    c.moveTo(o.x - w * 0.46, o.yBase);
    c.lineTo(o.x - lean * 0.55, top);
    c.moveTo(o.x + w * 0.46, o.yBase);
    c.lineTo(o.x + lean * 0.55, top);
    c.stroke();
    c.lineCap = 'butt';
    c.strokeStyle = f.shade(p.wood, -0.05); c.lineWidth = 3 * s;
    c.beginPath();                                             // head bar, overhanging both legs
    c.moveTo(o.x - lean * 1.05, top + 1 * s);
    c.lineTo(o.x + lean * 1.05, top + 1 * s);
    c.stroke();
    // The hide: ragged, asymmetric, hanging past the timber on the lit side.
    c.fillStyle = f.shade(p.hide, 0.04);
    c.beginPath();
    c.moveTo(o.x - w * 0.24, top + 3 * s);
    c.lineTo(o.x + w * 0.22, top + 2 * s);
    c.lineTo(o.x + w * 0.40, top + h * 0.34);
    c.lineTo(o.x + w * 0.26, top + h * 0.72);
    c.lineTo(o.x + w * 0.04, top + h * 0.62);
    c.lineTo(o.x - w * 0.30, top + h * 0.78);
    c.lineTo(o.x - w * 0.42, top + h * 0.36);
    c.closePath(); c.fill();
    c.fillStyle = f.shade(p.hide, -0.30);                      // the flesh side, still damp
    c.beginPath();
    c.moveTo(o.x - w * 0.10, top + 2.6 * s);
    c.lineTo(o.x + w * 0.22, top + 2 * s);
    c.lineTo(o.x + w * 0.36, top + h * 0.36);
    c.lineTo(o.x + w * 0.06, top + h * 0.60);
    c.closePath(); c.fill();
    c.strokeStyle = f.shade(p.wood, -0.55); c.lineWidth = 1;   // lashings out to the timber
    for (var i = 0; i < 5; i++) {
      var t = i / 4;
      var hx = o.x - w * 0.24 + t * w * 0.46, hy = top + 3 * s - t * s;
      c.beginPath();
      c.moveTo(hx, hy);
      c.lineTo(o.x - lean * 1.0 + t * lean * 2.0, top + 1 * s);
      c.stroke();
    }
  }

  /**
   * The tanning vat. Bulked up 2026-09-03: as the station it must be the object the eye lands on,
   * and a plain 20x15 tub was smaller than the crates in other trades. It gets the paddle standing
   * in it — a diagonal, which is the only line in the whole cell that is not vertical.
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} o {x,yBase,scale,palette,seed}
   */
  function vat(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 27 * s, h = 20 * s;
    // VARIANT: what is in it. A tanning pit, a dyer's vat and a brewer's mash tun are one object
    // with different liquor, and the corpus says which (see JourneyworkPlace's variant channel).
    var liquor = o.liquor || '#6b5a34';
    f.ground(c, { x: o.x, yBase: o.yBase, w: w });
    f.vessel(c, { x: o.x, yBase: o.yBase, w: w, h: h, colour: p.wood, staves: 7, fill: liquor });
    c.strokeStyle = f.shade(p.iron, -0.25); c.lineWidth = 2.2 * s;     // two heavy hoops
    c.beginPath();
    c.moveTo(o.x - w * 0.48, o.yBase - h * 0.72); c.lineTo(o.x + w * 0.48, o.yBase - h * 0.72);
    c.moveTo(o.x - w * 0.43, o.yBase - h * 0.24); c.lineTo(o.x + w * 0.43, o.yBase - h * 0.24);
    c.stroke();
    c.fillStyle = f.shade(p.wood, 0.10);                               // the paddle, stood in the liquor
    c.save();
    c.translate(o.x + w * 0.14, o.yBase - h * 0.92);
    c.rotate(0.38);
    c.fillRect(-1.5 * s, -h * 0.95, 3 * s, h * 0.95);
    c.fillStyle = f.shade(p.wood, -0.05);
    c.fillRect(-3.2 * s, -h * 1.16, 6.4 * s, h * 0.26);
    c.restore();
  }

  function hidePile(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    f.heap(c, { x: o.x, yBase: o.yBase, w: 17 * s, h: 7 * s, colour: p.hide, seed: o.seed || 31, lumps: 5 });
  }

  // --- apothecary ------------------------------------------------------------

  /**
   * The apothecary's counter. It was a plain dark bar and disappeared under its own bottle shelf;
   * it now carries the drawer bank that is the recognisable part of the trade, with the ranks of
   * small brass-pulled drawers reading even at map scale.
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} o {x,yBase,scale,palette,seed}
   */
  function counter(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 30 * s, h = 17 * s;
    var x0 = o.x - w / 2;
    f.ground(c, { x: o.x, yBase: o.yBase, w: w });
    c.fillStyle = f.shade(p.wood, -0.34);                       // carcase
    c.fillRect(x0, o.yBase - h, w, h);
    c.fillStyle = f.shade(p.wood, -0.16);                       // drawer fronts, 4 across x 2 down
    for (var row = 0; row < 2; row++) {
      for (var i = 0; i < 4; i++) {
        var dx = x0 + 1.6 * s + i * (w - 3.2 * s) / 4;
        var dy = o.yBase - h + 3.4 * s + row * (h - 5 * s) / 2;
        c.fillRect(dx, dy, (w - 3.2 * s) / 4 - 1.2 * s, (h - 5 * s) / 2 - 1.2 * s);
      }
    }
    c.fillStyle = '#b99a4e';                                    // brass pulls — the trade's tell
    for (var row2 = 0; row2 < 2; row2++) {
      for (var j = 0; j < 4; j++) {
        var px = x0 + 1.6 * s + j * (w - 3.2 * s) / 4 + ((w - 3.2 * s) / 4 - 1.2 * s) / 2;
        var py = o.yBase - h + 3.4 * s + row2 * (h - 5 * s) / 2 + ((h - 5 * s) / 2 - 1.2 * s) / 2;
        c.fillRect(px - 1.1 * s, py - 0.6 * s, 2.2 * s, 1.2 * s);
      }
    }
    f.plank(c, { x: x0 - 1.6 * s, y: o.yBase - h, w: w + 3.2 * s, h: 3.4 * s, depth: 3.2 * s, colour: p.wood, grain: true });
  }

  function mortar(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    f.vessel(c, { x: o.x, yBase: o.yBase, w: 8 * s, h: 6 * s, colour: p.stone, staves: 0, rim: false });
    f.edge(c, { x: o.x + 2 * s, y: o.yBase - 6 * s, len: 7 * s, spread: 1.5 * s, angle: -1.05, colour: f.shade(p.stone, 0.15) });
  }

  function bottleShelf(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    f.frame(c, { x: o.x, yBase: o.yBase, w: 24 * s, h: 28 * s, colour: p.wood, thickness: 3 * s, rungs: 2 });
    var cols = ['#5b8f6a', '#8a5b8f', '#c2a24a', '#4a6f8a', '#a8563f', '#6f8a4a'];
    for (var row = 1; row <= 2; row++) {
      for (var i = 0; i < 3; i++) {
        var xx = o.x - 7 * s + i * 7 * s;
        var yy = o.yBase - 28 * s + (28 * s * row) / 3;
        c.fillStyle = cols[(row - 1) * 3 + i];
        c.fillRect(xx - 1.8 * s, yy - 7 * s, 3.6 * s, 7 * s);
        c.fillStyle = f.shade(cols[(row - 1) * 3 + i], -0.4);
        c.fillRect(xx - 0.8 * s, yy - 9 * s, 1.6 * s, 2 * s);
      }
    }
  }

  function herbBunch(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    f.band(c, { x: o.x, y: o.yBase - 24 * s, w: 18 * s, colour: f.shade(p.wood, -0.3), thickness: 2 * s });
    var r = f.rng(o.seed || 17);
    for (var i = 0; i < 4; i++) {
      var xx = o.x - 6 * s + i * 4 * s;
      c.strokeStyle = i % 2 ? '#6f8a4a' : '#57733c'; c.lineWidth = 1.4 * s;
      c.beginPath();
      c.moveTo(xx, o.yBase - 24 * s);
      c.quadraticCurveTo(xx + (r() - 0.5) * 4 * s, o.yBase - 16 * s, xx + (r() - 0.5) * 5 * s, o.yBase - 9 * s);
      c.stroke();
    }
  }

  // --- shared props for the wider corpus ---------------------------------------
  //
  // ⭐ EVERY PROP BELOW IS AUTHORED TO SERVE SEVERAL TRADES, because the corpus is the moat and a
  // corpus that grows as (trades x its own props) cannot be afforded. `workBench` alone carries the
  // carpenter, cooper, cobbler, fletcher and bowyer by changing what is lying on it.

  /**
   * A heavy work bench with a vice and whatever the trade is working on lying on it.
   * VARIANT `piece`: 'plank' · 'stave' · 'shoe' · 'shaft' · 'bow' · null.
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} o {x,yBase,scale,palette,seed,piece}
   */
  function workBench(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 30 * s, h = 16 * s, x0 = o.x - w / 2, top = o.yBase - h;
    f.ground(c, { x: o.x, yBase: o.yBase, w: w });
    f.post(c, { x: x0 + 3 * s, yBase: o.yBase, height: h, w: 4 * s, colour: p.wood });
    f.post(c, { x: x0 + w - 3 * s, yBase: o.yBase, height: h, w: 4 * s, colour: p.wood });
    c.fillStyle = f.shade(p.wood, -0.44);                     // an apron rail, so it is not two sticks
    c.fillRect(x0 + 3 * s, o.yBase - h * 0.44, w - 6 * s, 2.6 * s);
    f.plank(c, { x: x0, y: top, w: w, h: 4.6 * s, depth: 3.6 * s, colour: p.wood, grain: true });
    c.fillStyle = f.shade(p.iron, -0.16);                     // the vice, hanging off the near end
    c.fillRect(x0 + 1.5 * s, top + 4 * s, 5 * s, 6 * s);
    c.fillRect(x0 + 2.6 * s, top + 9 * s, 2.4 * s, 4 * s);
    var piece = o.piece || null;
    if (piece === 'plank') {
      f.plank(c, { x: x0 + 6 * s, y: top - 3.4 * s, w: w * 0.72, h: 3 * s, depth: 2 * s, colour: f.shade(p.wood, 0.16) });
    } else if (piece === 'stave') {
      c.fillStyle = f.shade(p.wood, 0.14);
      c.beginPath();
      c.moveTo(x0 + 7 * s, top - 1.5 * s);
      c.quadraticCurveTo(o.x, top - 7 * s, x0 + w - 5 * s, top - 1.5 * s);
      c.quadraticCurveTo(o.x, top - 4 * s, x0 + 7 * s, top - 1.5 * s);
      c.closePath(); c.fill();
    } else if (piece === 'shoe') {
      c.fillStyle = f.shade(p.hide, 0.02);
      c.beginPath();
      c.ellipse(o.x + w * 0.10, top - 2.6 * s, 6 * s, 3 * s, -0.12, 0, Math.PI * 2);
      c.fill();
      c.fillStyle = f.shade(p.hide, -0.34);
      c.fillRect(o.x + w * 0.02, top - 5.6 * s, 4.4 * s, 3.4 * s);
    } else if (piece === 'shaft') {
      c.fillStyle = f.shade(p.wood, 0.20);
      for (var i = 0; i < 3; i++) c.fillRect(x0 + 7 * s, top - 2 * s - i * 2.2 * s, w * 0.74, 1.4 * s);
      c.fillStyle = '#d8d2c0';                                 // fletchings, the tell for an arrow bench
      for (var j = 0; j < 3; j++) {
        c.beginPath();
        c.moveTo(x0 + 8 * s, top - 1.6 * s - j * 2.2 * s);
        c.lineTo(x0 + 12 * s, top - 3.4 * s - j * 2.2 * s);
        c.lineTo(x0 + 12 * s, top - 1.4 * s - j * 2.2 * s);
        c.closePath(); c.fill();
      }
    } else if (piece === 'bow') {
      c.strokeStyle = f.shade(p.wood, 0.18); c.lineWidth = 2.4 * s;
      c.beginPath();
      c.moveTo(x0 + 6 * s, top - 1 * s);
      c.quadraticCurveTo(o.x, top - 11 * s, x0 + w - 4 * s, top - 1 * s);
      c.stroke();
      c.strokeStyle = '#cfc6ab'; c.lineWidth = 1;
      c.beginPath(); c.moveTo(x0 + 6 * s, top - 1 * s); c.lineTo(x0 + w - 4 * s, top - 1 * s); c.stroke();
    }
  }

  /**
   * Stacked long material — sawn timber, barrel staves, rolled hides, bundled rushes.
   * VARIANT `stackColour` and `bands`.
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} o {x,yBase,scale,palette,seed,stackColour,bands}
   */
  function timberStack(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 24 * s, col = o.stackColour || p.wood;
    f.ground(c, { x: o.x, yBase: o.yBase, w: w });
    var r = f.rng(o.seed || 51);
    for (var i = 0; i < 5; i++) {
      var jog = (r() - 0.5) * 3 * s;
      f.plank(c, {
        x: o.x - w / 2 + jog, y: o.yBase - (i + 1) * 4.2 * s,
        w: w - Math.abs(jog), h: 4 * s, depth: 2.4 * s,
        colour: f.shade(col, i % 2 ? -0.06 : 0.08), grain: i % 2 === 0
      });
    }
    if (o.bands !== false) {
      c.strokeStyle = f.shade(p.iron, -0.2); c.lineWidth = 1.6 * s;
      c.beginPath();
      c.moveTo(o.x - w * 0.24, o.yBase - 21 * s); c.lineTo(o.x - w * 0.24, o.yBase - 1 * s);
      c.stroke();
    }
  }

  /**
   * A ring of casks — cooper, brewer, vintner, chandler.
   * VARIANT `caskColour`.
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} o {x,yBase,scale,palette,seed,caskColour}
   */
  function caskStack(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var col = o.caskColour || p.wood;
    f.ground(c, { x: o.x, yBase: o.yBase, w: 26 * s });
    for (var i = 0; i < 2; i++) {                              // two on the ground
      f.vessel(c, {
        x: o.x - 6 * s + i * 12 * s, yBase: o.yBase,
        w: 13 * s, h: 15 * s, colour: f.shade(col, i ? -0.08 : 0.04), staves: 5
      });
    }
    f.vessel(c, { x: o.x, yBase: o.yBase - 15 * s, w: 13 * s, h: 14 * s, colour: col, staves: 5 });
  }

  /**
   * A grinding pair — miller's stones, a mason's banker, a tanner's fleshing beam seen end on.
   * VARIANT `runner` draws the upper stone and its handle.
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} o {x,yBase,scale,palette,seed,runner}
   */
  function millStone(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 28 * s;
    f.ground(c, { x: o.x, yBase: o.yBase, w: w });
    c.fillStyle = f.shade(p.wood, -0.42);                      // the frame it sits in
    c.fillRect(o.x - w * 0.46, o.yBase - 9 * s, w * 0.92, 9 * s);
    c.fillStyle = f.shade(p.stone, -0.30);                     // bed stone
    c.beginPath(); c.ellipse(o.x, o.yBase - 9 * s, w * 0.48, w * 0.17, 0, 0, Math.PI * 2); c.fill();
    c.fillStyle = f.shade(p.stone, 0.06);
    c.beginPath(); c.ellipse(o.x, o.yBase - 11 * s, w * 0.48, w * 0.17, 0, 0, Math.PI * 2); c.fill();
    if (o.runner !== false) {
      c.fillStyle = f.shade(p.stone, -0.14);                   // runner stone, offset so both read
      c.beginPath(); c.ellipse(o.x - w * 0.05, o.yBase - 15 * s, w * 0.34, w * 0.12, 0, 0, Math.PI * 2); c.fill();
      c.fillStyle = f.shade(p.stone, 0.20);
      c.beginPath(); c.ellipse(o.x - w * 0.05, o.yBase - 16.6 * s, w * 0.34, w * 0.12, 0, 0, Math.PI * 2); c.fill();
      c.fillStyle = f.shade(p.stone, -0.5);                    // the eye
      c.beginPath(); c.ellipse(o.x - w * 0.05, o.yBase - 16.6 * s, w * 0.07, w * 0.03, 0, 0, Math.PI * 2); c.fill();
      f.post(c, { x: o.x + w * 0.26, yBase: o.yBase - 16 * s, height: 12 * s, w: 2.6 * s, colour: p.wood });
    }
  }

  /**
   * Sacks slumped against each other — miller, baker, grocer, charcoal burner.
   * VARIANT `sackColour`.
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} o {x,yBase,scale,palette,seed,sackColour}
   */
  function sackPile(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var col = o.sackColour || f.shade(p.cloth, 0.06);
    var r = f.rng(o.seed || 61);
    f.ground(c, { x: o.x, yBase: o.yBase, w: 22 * s });
    for (var i = 0; i < 3; i++) {
      var sx = o.x - 6 * s + i * 6 * s, sh = (11 + r() * 4) * s;
      c.fillStyle = f.shade(col, i === 1 ? 0.08 : -0.10);
      c.beginPath();
      c.moveTo(sx - 5 * s, o.yBase);
      c.quadraticCurveTo(sx - 6 * s, o.yBase - sh * 0.7, sx - 2.6 * s, o.yBase - sh);
      c.lineTo(sx + 2.6 * s, o.yBase - sh);
      c.quadraticCurveTo(sx + 6 * s, o.yBase - sh * 0.7, sx + 5 * s, o.yBase);
      c.closePath(); c.fill();
      c.strokeStyle = f.shade(col, -0.42); c.lineWidth = 1.4 * s;   // the tie at the neck
      c.beginPath(); c.moveTo(sx - 2.6 * s, o.yBase - sh + 1 * s); c.lineTo(sx + 2.6 * s, o.yBase - sh + 1 * s); c.stroke();
    }
  }

  /**
   * Things hung from an overhead beam — a butcher's carcasses, a chandler's dipped candles,
   * a herbalist's drying bunches, a fisher's split catch.
   * VARIANT `hangs`: 'meat' · 'candles' · 'fish' · 'rope'.
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} o {x,yBase,scale,palette,seed,hangs}
   */
  function hangingBeam(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 30 * s, beamY = o.yBase - 26 * s;
    var kind = o.hangs || 'meat';
    f.plank(c, { x: o.x - w / 2, y: beamY, w: w, h: 3.4 * s, depth: 2.4 * s, colour: p.wood });
    var r = f.rng(o.seed || 71);
    for (var i = 0; i < 4; i++) {
      var hx = o.x - w * 0.34 + i * w * 0.22;
      c.strokeStyle = f.shade(p.iron, -0.1); c.lineWidth = 1.2 * s;   // the hook
      c.beginPath(); c.moveTo(hx, beamY + 3 * s); c.lineTo(hx, beamY + 6 * s); c.stroke();
      if (kind === 'meat') {
        c.fillStyle = i % 2 ? '#8e4a44' : '#a05a4e';
        c.beginPath();
        c.moveTo(hx - 3.4 * s, beamY + 6 * s);
        c.lineTo(hx + 3.4 * s, beamY + 6 * s);
        c.lineTo(hx + 2.2 * s, beamY + (13 + r() * 4) * s);
        c.lineTo(hx - 2.4 * s, beamY + (12 + r() * 4) * s);
        c.closePath(); c.fill();
        c.fillStyle = '#e0d3bd';
        c.fillRect(hx - 2.6 * s, beamY + 6 * s, 5.2 * s, 1.4 * s);
      } else if (kind === 'candles') {
        for (var k = -1; k <= 1; k++) {
          c.fillStyle = k ? '#d8ceb0' : '#e8dfc2';
          c.fillRect(hx + k * 2.2 * s - 0.8 * s, beamY + 6 * s, 1.6 * s, (9 + r() * 3) * s);
        }
      } else if (kind === 'fish') {
        c.fillStyle = i % 2 ? '#8fa6b4' : '#7c93a4';
        c.beginPath();
        c.ellipse(hx, beamY + 10 * s, 2.6 * s, 5 * s, 0, 0, Math.PI * 2);
        c.fill();
        c.beginPath();
        c.moveTo(hx - 2.4 * s, beamY + 15 * s); c.lineTo(hx + 2.4 * s, beamY + 15 * s);
        c.lineTo(hx, beamY + 12 * s); c.closePath(); c.fill();
      } else {
        c.strokeStyle = f.shade(p.cloth, -0.14); c.lineWidth = 2.2 * s;
        c.beginPath();
        c.moveTo(hx, beamY + 6 * s);
        c.quadraticCurveTo(hx + 3 * s, beamY + 12 * s, hx, beamY + (17 + r() * 3) * s);
        c.stroke();
      }
    }
  }

  /**
   * A domed or hooded fire structure — a glass furnace, a charcoal clamp, a lime kiln, a smokehouse.
   * VARIANT `mouthColour` and `dome` (0.7 squat to 1.3 tall).
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} o {x,yBase,scale,palette,seed,mouthColour,dome}
   */
  function furnace(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 26 * s, h = 28 * s * (o.dome || 1);
    f.ground(c, { x: o.x, yBase: o.yBase, w: w });
    c.fillStyle = f.shade(p.stone, -0.26);
    c.beginPath();
    c.moveTo(o.x - w / 2, o.yBase);
    c.lineTo(o.x - w * 0.42, o.yBase - h * 0.52);
    c.quadraticCurveTo(o.x, o.yBase - h * 1.16, o.x + w * 0.42, o.yBase - h * 0.52);
    c.lineTo(o.x + w / 2, o.yBase);
    c.closePath(); c.fill();
    c.fillStyle = f.shade(p.stone, 0.10);                      // lit shoulder
    c.beginPath();
    c.moveTo(o.x - w * 0.40, o.yBase - h * 0.54);
    c.quadraticCurveTo(o.x - w * 0.12, o.yBase - h * 1.06, o.x + w * 0.02, o.yBase - h * 0.98);
    c.lineTo(o.x - w * 0.24, o.yBase - h * 0.50);
    c.closePath(); c.fill();
    c.strokeStyle = f.shade(p.iron, -0.3); c.lineWidth = 1.8 * s;   // binding hoops
    c.beginPath();
    c.moveTo(o.x - w * 0.44, o.yBase - h * 0.34); c.lineTo(o.x + w * 0.44, o.yBase - h * 0.34);
    c.stroke();
    c.fillStyle = '#170f0c';
    c.fillRect(o.x - w * 0.16, o.yBase - h * 0.34, w * 0.32, h * 0.34);
    c.fillStyle = o.mouthColour || '#ff8a2b';
    c.fillRect(o.x - w * 0.12, o.yBase - h * 0.26, w * 0.24, h * 0.26);
  }

  /**
   * Small wares ranged on a two-tier stand — a cobbler's shoes, a chandler's tapers, a potter's
   * seconds, a grocer's produce.
   * VARIANT `wareColours` (array) and `wareShape`: 'box' · 'round' · 'tall'.
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} o {x,yBase,scale,palette,seed,wareColours,wareShape}
   */
  function wareStand(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 24 * s, h = 22 * s, x0 = o.x - w / 2, top = o.yBase - h;
    var cols = o.wareColours || [f.shade(p.clay, 0.1), f.shade(p.clay, -0.2), f.shade(p.cloth, 0)];
    var shape = o.wareShape || 'box';
    f.ground(c, { x: o.x, yBase: o.yBase, w: w });
    f.post(c, { x: x0 + 2.4 * s, yBase: o.yBase, height: h, w: 3 * s, colour: p.wood });
    f.post(c, { x: x0 + w - 2.4 * s, yBase: o.yBase, height: h, w: 3 * s, colour: p.wood });
    for (var row = 0; row < 2; row++) {
      var sy = top + 3 * s + row * h * 0.46;
      f.plank(c, { x: x0, y: sy, w: w, h: 2.6 * s, depth: 2.2 * s, colour: p.wood });
      for (var i = 0; i < 3; i++) {
        var wx = x0 + 4.5 * s + i * (w - 9 * s) / 2;
        c.fillStyle = cols[(row * 3 + i) % cols.length];
        if (shape === 'round') {
          c.beginPath(); c.ellipse(wx, sy - 2.6 * s, 3 * s, 2.6 * s, 0, 0, Math.PI * 2); c.fill();
        } else if (shape === 'tall') {
          c.fillRect(wx - 1.6 * s, sy - 8 * s, 3.2 * s, 8 * s);
          c.fillStyle = f.shade(cols[(row * 3 + i) % cols.length], -0.4);
          c.fillRect(wx - 0.7 * s, sy - 10 * s, 1.4 * s, 2.2 * s);
        } else {
          c.fillRect(wx - 3 * s, sy - 5 * s, 6 * s, 5 * s);
          c.fillStyle = f.shade(cols[(row * 3 + i) % cols.length], 0.18);
          c.fillRect(wx - 3 * s, sy - 5 * s, 6 * s, 1.2 * s);
        }
      }
    }
  }

  /*
   * ⛔ THESE THREE EXIST BECAUSE THE VARIANT CHANNEL WAS PUSHED PAST WHAT IT CAN DO, AND THE CONTACT
   * SHEET SAID SO IMMEDIATELY.
   *
   * Sixteen trades were added in one pass, seven of them standing at a `workBench` with a different
   * small object lying on it — carpenter, cooper, cobbler, fletcher, bowyer, mason, ropemaker. On
   * the 48px sheet those seven cells were INDISTINGUISHABLE: a bench with a stack behind it, seven
   * times. The `piece` on the bench top is 4-6px at map scale, i.e. below the size at which anything
   * is legible, so the entire differentiation budget was being spent where it cannot be seen.
   *
   * ⭐ That is the shared-silhouette defect this file already fixed once for `frame`, arriving
   * through the mechanism built to PREVENT it — and the boundary is now measured rather than
   * asserted: A VARIANT CAN CHANGE WHAT A PROP CONTAINS, AND ONLY A NEW PROP CAN CHANGE ITS
   * OUTLINE. If two trades differ only in something smaller than about a fifth of the prop, they do
   * not differ at all at map scale.
   *
   * So the trades whose real workplaces have genuinely different furniture get it. A cooper does not
   * stand at a bench, he sits astride a shaving horse; a mason works at a low banker with a block on
   * it; a cobbler sits at a bench low enough to hold between his knees.
   */

  /**
   * A shaving horse: a low sloped beam with a treadle clamp, sat astride. Cooper, bowyer, turner.
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} o {x,yBase,scale,palette,seed,piece}
   */
  function shaveHorse(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 32 * s, h = 14 * s;
    f.ground(c, { x: o.x, yBase: o.yBase, w: w });
    f.post(c, { x: o.x - w * 0.36, yBase: o.yBase, height: h * 0.72, w: 3.4 * s, colour: p.wood });
    f.post(c, { x: o.x + w * 0.34, yBase: o.yBase, height: h, w: 3.4 * s, colour: p.wood });
    c.fillStyle = f.shade(p.wood, -0.10);                      // the beam, sloping up to the head
    c.beginPath();
    c.moveTo(o.x - w * 0.48, o.yBase - h * 0.62);
    c.lineTo(o.x + w * 0.46, o.yBase - h);
    c.lineTo(o.x + w * 0.46, o.yBase - h + 4.4 * s);
    c.lineTo(o.x - w * 0.48, o.yBase - h * 0.62 + 4.4 * s);
    c.closePath(); c.fill();
    c.fillStyle = f.shade(p.wood, 0.16);
    c.beginPath();
    c.moveTo(o.x - w * 0.48, o.yBase - h * 0.62);
    c.lineTo(o.x + w * 0.46, o.yBase - h);
    c.lineTo(o.x + w * 0.46, o.yBase - h + 1.6 * s);
    c.lineTo(o.x - w * 0.48, o.yBase - h * 0.62 + 1.6 * s);
    c.closePath(); c.fill();
    // The swinging head, standing well proud of the beam — this is the shape nothing else has.
    c.fillStyle = f.shade(p.wood, -0.30);
    c.save();
    c.translate(o.x + w * 0.20, o.yBase - h);
    c.rotate(-0.22);
    c.fillRect(-2.2 * s, -13 * s, 4.4 * s, 13 * s);
    c.fillStyle = f.shade(p.wood, -0.05);
    c.fillRect(-6 * s, -14.5 * s, 12 * s, 3.4 * s);
    c.restore();
    c.strokeStyle = f.shade(p.wood, -0.44); c.lineWidth = 2 * s;   // the treadle bar
    c.beginPath();
    c.moveTo(o.x + w * 0.10, o.yBase - 2 * s); c.lineTo(o.x + w * 0.30, o.yBase - h * 0.44);
    c.stroke();
    if (o.piece === 'stave') {
      c.fillStyle = f.shade(p.wood, 0.24);
      c.beginPath();
      c.moveTo(o.x - w * 0.42, o.yBase - h * 0.80);
      c.quadraticCurveTo(o.x - w * 0.05, o.yBase - h * 1.30, o.x + w * 0.22, o.yBase - h * 1.18);
      c.quadraticCurveTo(o.x - w * 0.05, o.yBase - h * 1.06, o.x - w * 0.42, o.yBase - h * 0.64);
      c.closePath(); c.fill();
    } else if (o.piece === 'bow') {
      c.strokeStyle = f.shade(p.wood, 0.22); c.lineWidth = 2.6 * s;
      c.beginPath();
      c.moveTo(o.x - w * 0.44, o.yBase - h * 0.62);
      c.quadraticCurveTo(o.x, o.yBase - h * 1.85, o.x + w * 0.40, o.yBase - h * 1.02);
      c.stroke();
    }
    c.fillStyle = f.shade(p.wood, 0.28);                       // shavings on the floor
    var r = f.rng(o.seed || 81);
    for (var i = 0; i < 7; i++) {
      var sx = o.x + (r() - 0.5) * w * 0.9;
      c.beginPath();
      c.ellipse(sx, o.yBase - 1 * s - r() * 2 * s, 2.4 * s, 1 * s, r() * 2, 0, Math.PI * 2);
      c.fill();
    }
  }

  /**
   * A mason's banker: a squat stone bench carrying the block being cut, with chippings around it.
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} o {x,yBase,scale,palette,seed}
   */
  function banker(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 26 * s, h = 12 * s;
    f.ground(c, { x: o.x, yBase: o.yBase, w: w * 1.15 });
    c.fillStyle = f.shade(p.stone, -0.36);                     // the bench: heavy, low, splayed
    c.beginPath();
    c.moveTo(o.x - w * 0.50, o.yBase);
    c.lineTo(o.x + w * 0.50, o.yBase);
    c.lineTo(o.x + w * 0.42, o.yBase - h);
    c.lineTo(o.x - w * 0.42, o.yBase - h);
    c.closePath(); c.fill();
    c.fillStyle = f.shade(p.stone, -0.08);
    c.fillRect(o.x - w * 0.44, o.yBase - h - 2.4 * s, w * 0.88, 2.8 * s);
    // The block under the chisel — a big pale cube, and the only large flat highlight in the cell.
    c.fillStyle = f.shade(p.stone, 0.26);
    c.fillRect(o.x - w * 0.26, o.yBase - h - 15 * s, w * 0.52, 13 * s);
    c.fillStyle = f.shade(p.stone, 0.44);
    c.beginPath();
    c.moveTo(o.x - w * 0.26, o.yBase - h - 15 * s);
    c.lineTo(o.x - w * 0.18, o.yBase - h - 18.4 * s);
    c.lineTo(o.x + w * 0.34, o.yBase - h - 18.4 * s);
    c.lineTo(o.x + w * 0.26, o.yBase - h - 15 * s);
    c.closePath(); c.fill();
    c.fillStyle = f.shade(p.stone, 0.08);
    c.beginPath();
    c.moveTo(o.x + w * 0.26, o.yBase - h - 15 * s);
    c.lineTo(o.x + w * 0.34, o.yBase - h - 18.4 * s);
    c.lineTo(o.x + w * 0.34, o.yBase - h - 5.4 * s);
    c.lineTo(o.x + w * 0.26, o.yBase - h - 2 * s);
    c.closePath(); c.fill();
    c.strokeStyle = f.shade(p.stone, -0.30); c.lineWidth = 1;  // tooled banding on the worked face
    for (var i = 1; i <= 4; i++) {
      var yy = Math.round(o.yBase - h - 15 * s + i * 2.6 * s) + 0.5;
      c.beginPath(); c.moveTo(o.x - w * 0.23, yy); c.lineTo(o.x + w * 0.23, yy); c.stroke();
    }
    c.fillStyle = f.shade(p.wood, 0.04);                       // mallet and chisel, left leaning
    c.save();
    c.translate(o.x + w * 0.40, o.yBase - h - 3 * s);
    c.rotate(0.42);
    c.fillRect(-1.4 * s, -12 * s, 2.8 * s, 12 * s);
    c.fillStyle = f.shade(p.wood, -0.22);
    c.beginPath(); c.ellipse(0, -13.6 * s, 4 * s, 3.2 * s, 0, 0, Math.PI * 2); c.fill();
    c.restore();
    var r = f.rng(o.seed || 91);                               // chippings
    c.fillStyle = f.shade(p.stone, 0.30);
    for (var j = 0; j < 12; j++) {
      c.fillRect(o.x + (r() - 0.5) * w * 1.2, o.yBase - r() * 3 * s, 1.6 * s, 1.2 * s);
    }
  }

  /**
   * A cobbler's low bench: a seat and a last, worked with the piece held between the knees.
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} o {x,yBase,scale,palette,seed}
   */
  function lastBench(c, o) {
    var f = F(), s = o.scale, p = o.palette;
    var w = 26 * s, h = 10 * s;
    f.ground(c, { x: o.x, yBase: o.yBase, w: w });
    f.post(c, { x: o.x - w * 0.36, yBase: o.yBase, height: h, w: 3 * s, colour: p.wood });
    f.post(c, { x: o.x + w * 0.36, yBase: o.yBase, height: h, w: 3 * s, colour: p.wood });
    f.plank(c, { x: o.x - w * 0.46, y: o.yBase - h, w: w * 0.92, h: 3.4 * s, depth: 2.8 * s, colour: p.wood, grain: true });
    // The last: an iron foot-form on a stalk, which is the trade's one unmistakable object.
    f.post(c, { x: o.x - w * 0.16, yBase: o.yBase - h, height: 11 * s, w: 3 * s, colour: p.iron });
    c.fillStyle = f.shade(p.iron, 0.10);
    c.beginPath();
    c.moveTo(o.x - w * 0.34, o.yBase - h - 11 * s);
    c.lineTo(o.x - w * 0.02, o.yBase - h - 12.6 * s);
    c.lineTo(o.x + w * 0.04, o.yBase - h - 10.2 * s);
    c.lineTo(o.x - w * 0.30, o.yBase - h - 8.6 * s);
    c.closePath(); c.fill();
    c.fillStyle = f.shade(p.hide, 0.02);                       // the upper, being tacked on
    c.beginPath();
    c.moveTo(o.x - w * 0.30, o.yBase - h - 10.6 * s);
    c.lineTo(o.x - w * 0.06, o.yBase - h - 11.8 * s);
    c.lineTo(o.x - w * 0.02, o.yBase - h - 9.6 * s);
    c.lineTo(o.x - w * 0.28, o.yBase - h - 8.4 * s);
    c.closePath(); c.fill();
    // A three-legged stool, the other half of the read: this is a SEATED trade.
    f.plank(c, { x: o.x + w * 0.16, y: o.yBase - 7 * s, w: 10 * s, h: 2.6 * s, depth: 2.2 * s, colour: p.wood });
    f.post(c, { x: o.x + w * 0.22, yBase: o.yBase, height: 7 * s, w: 2 * s, colour: p.wood });
    f.post(c, { x: o.x + w * 0.44, yBase: o.yBase, height: 7 * s, w: 2 * s, colour: p.wood });
    c.fillStyle = f.shade(p.iron, -0.2);                       // tacks scattered on the bench top
    var r = f.rng(o.seed || 101);
    for (var i = 0; i < 6; i++) c.fillRect(o.x + (r() - 0.7) * w * 0.5, o.yBase - h - 1.4 * s, 1.2 * s, 1.2 * s);
  }

  var PROPS = {
    anvil: anvil, hearth: hearth, quenchTub: quenchTub, toolRack: toolRack,
    stallTable: stallTable, canopy: canopy, catchTray: catchTray, scales: scales, crateStack: crateStack,
    slopeDesk: slopeDesk, inkStand: inkStand, quireStack: quireStack, shelf: shelf,
    oven: oven, doughTable: doughTable, breadRack: breadRack,
    wheel: wheel, kiln: kiln, clayHeap: clayHeap, dryingShelf: dryingShelf,
    loom: loom, spools: spools, clothBolt: clothBolt,
    stretchFrame: stretchFrame, vat: vat, hidePile: hidePile,
    counter: counter, mortar: mortar, bottleShelf: bottleShelf, herbBunch: herbBunch,
    workBench: workBench, timberStack: timberStack, caskStack: caskStack, millStone: millStone,
    sackPile: sackPile, hangingBeam: hangingBeam, furnace: furnace, wareStand: wareStand,
    shaveHorse: shaveHorse, banker: banker, lastBench: lastBench
  };

  /**
   * Draw one prop by name.
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {string} name Key in PROPS.
   * @param {object} o {x,yBase,scale,palette,seed}
   */
  function draw(c, name, o) {
    var fn = PROPS[name];
    if (!fn) throw new Error('Journeywork: no prop named "' + name + '"');
    fn(c, o);
  }

  /*
   * ⛔ THE SOLVER MEASURES ITS PROPS. IT IS NEVER TOLD THEIR SIZES.
   *
   * The layout needs each prop's real extent to keep a satellite from towering over the station that
   * names the trade (measured: in five trades of eight the station was the SMALLER object — a 26x16
   * scribe's desk under a 22x28 shelf). The obvious way to supply that is a `SIZES` table beside
   * `PROPS`, and it is exactly the defect wing §11a is written about: a second copy of a constant
   * does not drift, it WINS, and a prop re-authored later would silently keep its old declared
   * height while drawing a new one. Nothing would go red.
   *
   * So the size is DERIVED by drawing the prop once onto a scratch canvas and scanning the alpha
   * channel for its true bounds. It cannot disagree with the art because it IS the art. Results are
   * cached per (prop, scale) — a workplace is solved when a map loads, not per frame.
   *
   * ⚠️ Returns null where no canvas exists (a bare `node -e` require), and the caller must treat that
   * as "unmeasured", never as zero. The contact-sheet probe asserts a non-zero measured count so a
   * silent degrade cannot hide inside a green run (master §2b: an empty result is not a finding).
   */
  var MEASURE_CACHE = {};
  var MEASURE_PAD = 90;

  /**
   * The drawn extent of a prop, in pixels, relative to its (x, yBase) anchor.
   *
   * @param {string} name Key in PROPS.
   * @param {number} scale Draw scale.
   * @param {object} palette Palette to draw with (colour does not move geometry, but alpha can).
   * @param {number} [seed] Deterministic seed.
   * @returns {{w:number, h:number, left:number, right:number, top:number}|null} null if unmeasurable.
   */
  function measure(name, scale, palette, seed, variant) {
    /*
     * ⚠️ THE VARIANT IS PART OF THE CACHE KEY, AND LEAVING IT OUT WOULD BE SILENT. A corpus variant
     * may change a prop's contents and therefore its drawn extent, so `vat` as a brewer's mash tun
     * and `vat` as a dye vat can measure differently. Keying only on (name, scale) would hand the
     * second one the first one's box and the ground patch would be quietly wrong — a stale number
     * with nothing to make it go red.
     */
    var key = name + '@' + scale.toFixed(3) + '#' + (variant ? JSON.stringify(variant) : '-');
    if (Object.prototype.hasOwnProperty.call(MEASURE_CACHE, key)) return MEASURE_CACHE[key];
    if (typeof document === 'undefined' || !document.createElement) return null;

    var size = Math.ceil(MEASURE_PAD * Math.max(1, scale) * 2);
    var cv = document.createElement('canvas');
    cv.width = size; cv.height = size;
    var ctx = cv.getContext('2d', { willReadFrequently: true });
    if (!ctx) return null;

    var ax = size / 2, ay = size * 0.78;                 // anchor: props stand ON yBase and rise
    var arg = { x: ax, yBase: ay, scale: scale, palette: palette, seed: seed || 1 };
    if (variant) {
      for (var vk in variant) if (Object.prototype.hasOwnProperty.call(variant, vk)) arg[vk] = variant[vk];
      arg.x = ax; arg.yBase = ay; arg.scale = scale;
    }
    try {
      draw(ctx, name, arg);
    } catch (e) {
      MEASURE_CACHE[key] = null;
      return null;
    }

    var data = ctx.getImageData(0, 0, size, size).data;
    var minX = size, maxX = -1, minY = size, maxY = -1;
    for (var y = 0; y < size; y++) {
      for (var x = 0; x < size; x++) {
        if (data[(y * size + x) * 4 + 3] > 8) {
          if (x < minX) minX = x;
          if (x > maxX) maxX = x;
          if (y < minY) minY = y;
          if (y > maxY) maxY = y;
        }
      }
    }
    var out = maxX < 0
      ? null                                             // drew nothing at all — unmeasured, not zero
      : { w: maxX - minX + 1, h: maxY - minY + 1, left: ax - minX, right: maxX - ax, top: ay - minY };
    MEASURE_CACHE[key] = out;
    return out;
  }

  return { PROPS: PROPS, draw: draw, measure: measure, names: Object.keys(PROPS) };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = JourneyworkShop;
