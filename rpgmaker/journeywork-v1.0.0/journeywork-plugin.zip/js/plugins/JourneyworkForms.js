//=============================================================================
// JourneyworkForms.js — Journeywork [2/5]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Journeywork [2/5] — the primitive form vocabulary every prop is composed from. Data and drawing only; knows nothing about RPG Maker.
 * @author Core Systems Asset Factory
 *
 * @help
 * JourneyworkForms.js
 *
 * The eight primitives every workplace prop is built out of: plank, post, vessel, frame, cloth,
 * heap, band and edge. A prop is a COMPOSITION of these, never a set of literal coordinates.
 *
 * This file registers no plugin commands and patches nothing. Switching it off removes the whole
 * product's drawing vocabulary, so it must be present, but it never touches the engine.
 */

/* eslint no-unused-vars: 0 */
'use strict';

var JourneyworkForms = (function () {

  /**
   * Deterministic RNG seam. Wing §6 rule 2: never Math.random() in anything a save or a
   * screenshot depends on. Two workplaces of the same trade in the same town must be identical
   * every time the map loads, or a screenshot is not reproducible and a bug is not repeatable.
   * @param {number} seed Any integer.
   * @returns {function(): number} Generator returning [0,1).
   */
  function rng(seed) {
    var s = (seed | 0) || 1;
    return function () {
      s ^= s << 13; s |= 0;
      s ^= s >>> 17;
      s ^= s << 5; s |= 0;
      return ((s >>> 0) % 100000) / 100000;
    };
  }

  /**
   * Shade a hex colour by a signed amount. Used for lit/shadow faces so relief comes from one
   * consistent light rather than from per-prop guesses.
   * @param {string} hex "#rrggbb".
   * @param {number} d -1..1.
   * @returns {string} "#rrggbb".
   */
  function shade(hex, d) {
    var n = parseInt(hex.slice(1), 16);
    var r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    var f = function (v) {
      var x = d >= 0 ? v + (255 - v) * d : v * (1 + d);
      return Math.max(0, Math.min(255, Math.round(x)));
    };
    return '#' + ((1 << 24) + (f(r) << 16) + (f(g) << 8) + f(b)).toString(16).slice(1);
  }

  // ⚠️ ONE light for the whole product. Every form derives its lit and shadow faces from this, so
  // props authored months apart still agree about where the sun is. A per-prop light is how a
  // scene stops reading as one place.
  var LIGHT = { x: -0.55, y: -0.8 };

  /**
   * Aerial perspective: push a colour toward a pale neutral as it recedes.
   *
   * ⭐ ADDED AFTER LOOKING AT THE FIRST 48px CONTACT SHEET, AND IT IS THE FIX FOR A DEFECT THAT
   * LOOKED LIKE A SIZE PROBLEM. Every trade rendered at roughly ONE value: the smith's anvil is
   * dark iron, it stood in front of a dark hearth on a dark ground patch, and it simply
   * disappeared. The obvious reading is "the station is too small", and the obvious fix — scale the
   * station up — treats a CONTRAST problem as a SIZE problem and would have had to be re-tuned for
   * all eight trades separately.
   *
   * Distance is already known (the solver computes every baseline), so contrast can be DERIVED from
   * it: whatever is furthest from the viewer goes pale and grey, and the station — always nearest —
   * is left the richest, darkest thing in the group. One rule, no per-trade constants, and it holds
   * for a trade authored next month (wing §11b: a constant in a figure's coordinate space is an
   * assumption about its pose; the same is true of a constant in its VALUE space).
   *
   * ⛔ THE FIRST VERSION MIXED TOWARD A FIXED PALE NEUTRAL AND MADE THE PROBLEM WORSE ON HALF THE
   * TRADES. MEASURED by rendering it: on the smith's ASH ground (#3a3531) a "receded" prop went
   * LIGHTER than the floor it stood on, so distance INCREASED its contrast and the pale ghost of a
   * hearth shouted louder than the anvil in front of it. The scribe's shelf did the same against
   * flagstones.
   *
   * ⭐ Aerial perspective is not "go pale", it is "approach the background". Real haze works because
   * the background is bright sky; the rule generalises only if the target is whatever the thing is
   * seen AGAINST. Here that is known and is drawn by this very product — the worked-ground patch —
   * so the target is passed in rather than assumed. On ash a distant prop goes dark, on flour it
   * goes pale, and the station stays the highest-contrast object either way.
   *
   * @param {string} hex "#rrggbb".
   * @param {number} k 0 = untouched (nearest), 1 = fully receded.
   * @param {string} [target] "#rrggbb" of the surface it recedes into. Defaults to a mid neutral.
   * @returns {string} "#rrggbb".
   */
  function recede(hex, k, target) {
    if (!(k > 0)) return hex;
    var kk = k > 1 ? 1 : k;
    var n = parseInt(hex.slice(1), 16);
    var r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    var t = parseInt((target || '#7a746a').slice(1), 16);
    var tr = (t >> 16) & 255, tg = (t >> 8) & 255, tb = t & 255;
    var mix = function (v, tv) {
      return Math.max(0, Math.min(255, Math.round(v + (tv - v) * kk)));
    };
    return '#' + ((1 << 24) + (mix(r, tr) << 16) + (mix(g, tg) << 8) + mix(b, tb)).toString(16).slice(1);
  }

  /**
   * Recede every named colour in a palette at once.
   * @param {object} pal Named material colours.
   * @param {number} k 0..1.
   * @param {string} [target] The surface colour to recede into.
   * @returns {object} A new palette; the input is never mutated.
   */
  function recedePalette(pal, k, target) {
    if (!(k > 0)) return pal;
    var out = {};
    for (var key in pal) if (Object.prototype.hasOwnProperty.call(pal, key)) out[key] = recede(pal[key], k, target);
    return out;
  }

  /**
   * A horizontal board seen slightly from above: top face, front face, and end grain.
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} o {x,y,w,h,depth,colour,grain}
   */
  function plank(c, o) {
    var col = o.colour, d = o.depth == null ? Math.max(2, o.h * 0.5) : o.depth;
    c.fillStyle = shade(col, -0.28);                        // front face
    c.fillRect(o.x, o.y, o.w, o.h);
    c.fillStyle = shade(col, 0.12);                         // top face, catching the light
    c.beginPath();
    c.moveTo(o.x, o.y);
    c.lineTo(o.x + d, o.y - d);
    c.lineTo(o.x + o.w + d, o.y - d);
    c.lineTo(o.x + o.w, o.y);
    c.closePath(); c.fill();
    c.fillStyle = shade(col, -0.45);                        // end grain
    c.beginPath();
    c.moveTo(o.x + o.w, o.y);
    c.lineTo(o.x + o.w + d, o.y - d);
    c.lineTo(o.x + o.w + d, o.y - d + o.h);
    c.lineTo(o.x + o.w, o.y + o.h);
    c.closePath(); c.fill();
    if (o.grain) {
      c.strokeStyle = shade(col, -0.5); c.lineWidth = 1; c.globalAlpha = 0.5;
      var n = Math.max(1, Math.floor(o.h / 3));
      for (var i = 1; i <= n; i++) {
        var yy = Math.round(o.y + (o.h * i) / (n + 1)) + 0.5;
        c.beginPath(); c.moveTo(o.x + 1, yy); c.lineTo(o.x + o.w - 1, yy); c.stroke();
      }
      c.globalAlpha = 1;
    }
  }

  /**
   * A vertical timber standing on a baseline.
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} o {x,yBase,height,w,colour}
   */
  function post(c, o) {
    var w = o.w || 4;
    c.fillStyle = shade(o.colour, -0.2);
    c.fillRect(o.x - w / 2, o.yBase - o.height, w, o.height);
    c.fillStyle = shade(o.colour, 0.14);                    // lit edge, from LIGHT.x
    c.fillRect(o.x - w / 2, o.yBase - o.height, Math.max(1, w * 0.35), o.height);
  }

  /**
   * A staved or thrown vessel — tub, vat, pot, quench trough.
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} o {x,yBase,w,h,colour,staves,rim,fill}
   */
  function vessel(c, o) {
    var x = o.x - o.w / 2, top = o.yBase - o.h;
    var taper = o.w * 0.11;
    c.fillStyle = shade(o.colour, -0.22);
    c.beginPath();
    c.moveTo(x + taper, o.yBase);
    c.lineTo(x + o.w - taper, o.yBase);
    c.lineTo(x + o.w, top);
    c.lineTo(x, top);
    c.closePath(); c.fill();
    if (o.staves) {
      c.strokeStyle = shade(o.colour, -0.45); c.lineWidth = 1; c.globalAlpha = 0.65;
      for (var i = 1; i < o.staves; i++) {
        var t = i / o.staves, xx = Math.round(x + o.w * t) + 0.5;
        c.beginPath();
        c.moveTo(xx, top);
        c.lineTo(Math.round(x + taper + (o.w - 2 * taper) * t) + 0.5, o.yBase);
        c.stroke();
      }
      c.globalAlpha = 1;
    }
    if (o.fill) {                                            // liquid, seen as an ellipse
      c.fillStyle = o.fill;
      c.beginPath();
      c.ellipse(o.x, top + 2, o.w * 0.44, o.w * 0.15, 0, 0, Math.PI * 2);
      c.fill();
    }
    if (o.rim !== false) {                                   // iron hoops
      c.strokeStyle = shade(o.colour, -0.55); c.lineWidth = 2;
      c.beginPath(); c.moveTo(x, top + 2); c.lineTo(x + o.w, top + 2); c.stroke();
      c.beginPath();
      c.moveTo(x + taper * 0.5, o.yBase - o.h * 0.32);
      c.lineTo(x + o.w - taper * 0.5, o.yBase - o.h * 0.32);
      c.stroke();
    }
  }

  /**
   * An open rectangular frame — racks, stretching frames, drying screens.
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} o {x,yBase,w,h,colour,rungs,legs}
   */
  function frame(c, o) {
    var x = o.x - o.w / 2, top = o.yBase - o.h, t = o.thickness || 3;
    c.fillStyle = shade(o.colour, -0.18);
    c.fillRect(x, top, o.w, t);                              // head rail
    c.fillRect(x, top, t, o.h);                              // stiles
    c.fillRect(x + o.w - t, top, t, o.h);
    if (o.legs !== false) c.fillRect(x, o.yBase - t, o.w, t);
    if (o.rungs) {
      c.fillStyle = shade(o.colour, -0.3);
      for (var i = 1; i <= o.rungs; i++) {
        var yy = top + (o.h * i) / (o.rungs + 1);
        c.fillRect(x + t, Math.round(yy), o.w - 2 * t, Math.max(1, t - 1));
      }
    }
  }

  /**
   * Draped cloth — awnings, canopies, hanging hides, bolts of woven stuff.
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} o {x,y,w,h,colour,folds,sag}
   */
  function cloth(c, o) {
    var x = o.x - o.w / 2, sag = o.sag == null ? o.h * 0.35 : o.sag;
    c.fillStyle = o.colour;
    c.beginPath();
    c.moveTo(x, o.y);
    c.lineTo(x + o.w, o.y);
    c.lineTo(x + o.w, o.y + o.h - sag);
    c.quadraticCurveTo(o.x, o.y + o.h + sag, x, o.y + o.h - sag);
    c.closePath(); c.fill();
    var n = o.folds || 4;
    c.strokeStyle = shade(o.colour, -0.3); c.lineWidth = 1; c.globalAlpha = 0.55;
    for (var i = 1; i < n; i++) {
      var xx = Math.round(x + (o.w * i) / n) + 0.5;
      var drop = o.y + o.h - sag * (1 - Math.abs(0.5 - i / n) * 1.6);
      c.beginPath(); c.moveTo(xx, o.y + 1); c.lineTo(xx, drop); c.stroke();
    }
    c.globalAlpha = 1;
  }

  /**
   * A loose pile — coal, clay, sand, hides, cut wood. Deterministic from `seed`.
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} o {x,yBase,w,h,colour,seed,lumps}
   */
  function heap(c, o) {
    var r = rng(o.seed || 7), n = o.lumps || 9;
    c.fillStyle = shade(o.colour, -0.3);
    c.beginPath();
    c.moveTo(o.x - o.w / 2, o.yBase);
    c.quadraticCurveTo(o.x, o.yBase - o.h * 1.5, o.x + o.w / 2, o.yBase);
    c.closePath(); c.fill();
    for (var i = 0; i < n; i++) {
      var t = r(), u = r();
      var px = o.x + (t - 0.5) * o.w * 0.82;
      var py = o.yBase - u * o.h * 0.82 - 1;
      var rad = 1.4 + r() * (o.h * 0.18);
      c.fillStyle = shade(o.colour, u > 0.55 ? 0.14 : -0.5);
      c.beginPath(); c.arc(px, py, rad, 0, Math.PI * 2); c.fill();
    }
  }

  /**
   * A metal band or hoop lying across a form — tyres, straps, bindings.
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} o {x,y,w,colour,thickness}
   */
  function band(c, o) {
    c.strokeStyle = o.colour; c.lineWidth = o.thickness || 2;
    c.beginPath(); c.moveTo(o.x - o.w / 2, o.y); c.lineTo(o.x + o.w / 2, o.y); c.stroke();
  }

  /**
   * A worked edge or point — blades, spouts, tips. Drawn as a filled triangle so a tool reads as
   * a tool rather than as a stick.
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} o {x,y,len,spread,angle,colour}
   */
  function edge(c, o) {
    var a = o.angle == null ? -Math.PI / 2 : o.angle, s = o.spread || 3;
    c.fillStyle = o.colour;
    c.beginPath();
    c.moveTo(o.x + Math.cos(a) * o.len, o.y + Math.sin(a) * o.len);
    c.lineTo(o.x + Math.cos(a + Math.PI / 2) * s, o.y + Math.sin(a + Math.PI / 2) * s);
    c.lineTo(o.x + Math.cos(a - Math.PI / 2) * s, o.y + Math.sin(a - Math.PI / 2) * s);
    c.closePath(); c.fill();
  }

  /**
   * A contact shadow. Every prop gets one from the same light, which is most of why a set of
   * objects reads as standing in one place rather than floating.
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} o {x,yBase,w}
   */
  function ground(c, o) {
    c.save();
    c.globalAlpha = 0.28;
    c.fillStyle = '#000000';
    c.beginPath();
    c.ellipse(o.x + o.w * 0.06, o.yBase + 1, o.w * 0.55, Math.max(2, o.w * 0.16), 0, 0, Math.PI * 2);
    c.fill();
    c.restore();
  }

  return {
    rng: rng, shade: shade, recede: recede, recedePalette: recedePalette, LIGHT: LIGHT,
    plank: plank, post: post, vessel: vessel, frame: frame,
    cloth: cloth, heap: heap, band: band, edge: edge, ground: ground,
    FORMS: ['plank', 'post', 'vessel', 'frame', 'cloth', 'heap', 'band', 'edge']
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = JourneyworkForms;
