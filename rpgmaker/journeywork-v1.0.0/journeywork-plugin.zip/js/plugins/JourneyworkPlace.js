//=============================================================================
// JourneyworkPlace.js — Journeywork [4/5]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Journeywork [4/5] — the layout solver. Turns a trade's station and roles into placed props, a footprint, and the tile the worker stands on.
 * @author Core Systems Asset Factory
 *
 * @help
 * JourneyworkPlace.js
 *
 * The whole reason roles exist. A trade says "the hearth is BEHIND-RIGHT of the anvil"; this file
 * decides what that means in pixels, once, for every trade that ever uses that role.
 *
 * ⛔ Depth is resolved ONCE, by baseline Y, so no prop needs a hand-authored z and two props can
 * never disagree about which is in front.
 */

/* global JourneyworkCorpus, JourneyworkShop, JourneyworkForms */
'use strict';

var JourneyworkPlace = (function () {

  /** Resolve siblings at FIRST USE (wing §8 trap 2), never at load time. */
  function C() {
    return (typeof JourneyworkCorpus !== 'undefined' && JourneyworkCorpus)
      || (typeof require !== 'undefined' && require('./JourneyworkCorpus.js'));
  }
  function S() {
    return (typeof JourneyworkShop !== 'undefined' && JourneyworkShop)
      || (typeof require !== 'undefined' && require('./JourneyworkShop.js'));
  }
  function F() {
    return (typeof JourneyworkForms !== 'undefined' && JourneyworkForms)
      || (typeof require !== 'undefined' && require('./JourneyworkForms.js'));
  }

  /*
   * Roles in TILE units relative to the station, which sits at (0,0).
   *   dx  : + is right
   *   dy  : + is toward the viewer (down the screen), so a NEGATIVE dy is further away
   *   lift: drawn above the scene regardless of baseline (canopies, hanging bunches)
   *
   * ⚠️ These are deliberately not symmetrical. A workplace built on a perfect grid reads as a
   * showroom; the small offsets are what make it read as somewhere people work.
   */
  /*
   * ⛔ THESE NUMBERS WERE HALVED AFTER LOOKING AT THE FIRST CONTACT SHEET, AND THAT IS THE WHOLE
   * POINT OF THE SHEET. At ±1.05 tiles every prop stood a clear 48px from its neighbour while the
   * props themselves are only 20-30px wide, so eight trades rendered as eight scatters of small
   * objects on grass — "an anvil, a tub and a rack" rather than "a smithy". Every mechanical check
   * was green: 34 props placed, all four modules loaded, depth sorted correctly.
   *
   * ⭐ A workplace reads as one thing when its props OVERLAP. Satellites now sit close enough to
   * touch the station and to occlude each other, which is what makes the group a scene.
   */
  var ROLES = {
    'behind':        { dx: 0.00, dy: -0.52 },
    'behind-left':   { dx: -0.56, dy: -0.42 },
    'behind-right':  { dx: 0.56, dy: -0.46 },
    'beside-left':   { dx: -0.66, dy: 0.06 },
    'beside-right':  { dx: 0.66, dy: 0.04 },
    'fore-left':     { dx: -0.44, dy: 0.34 },
    'fore-right':    { dx: 0.48, dy: 0.32 },
    'onStation':     { dx: 0.06, dy: 0.00, onStation: true },
    'overhead':      { dx: 0.00, dy: 0.00, lift: true }
  };

  /**
   * Solve a trade into a list of placed props, ready to draw in order.
   *
   * @param {object} trade A JourneyworkCorpus trade.
   * @param {object} opts {tile, originX, originY, scale, seed}
   * @returns {{items: Array<object>, workTile: {dx:number, dy:number}, footprint: object}}
   */
  /*
   * ⛔ THE STATION IS THE SUBJECT AND MUST WIN, AND IT WAS LOSING IN FIVE TRADES OUT OF EIGHT.
   *
   * MEASURED off the first 48px contact sheet by reading the prop dimensions in JourneyworkShop:
   * the station was the SMALLER object in smith (anvil 26x20 vs hearth 30x30), scribe (desk 26x16
   * vs shelf 22x28), potter (wheel 18 vs kiln 24x30), tanner (vat 20x15 vs stretchFrame 26x30) and
   * apothecary (counter 28x14 vs bottleShelf 24x28). That is physically TRUE — a hearth really is
   * bigger than an anvil — and it is still wrong, because the object that NAMES the trade has to be
   * the object the eye lands on.
   *
   * Two derived levers, applied here rather than by re-authoring thirty props:
   *   SCALE     — the station is drawn larger and satellites slightly smaller.
   *   CONTRAST  — `JourneyworkForms.recedePalette` pushes everything behind the station toward a
   *               pale neutral in proportion to its distance, so the station is automatically the
   *               richest thing in every trade including ones authored later.
   *
   * ⚠️ Props sitting ON the station take the STATION's scale, not the satellite scale: a shrunken
   * inkwell on an enlarged desk reads as a mistake rather than as hierarchy.
   */
  /*
   * ⛔ PROPS WERE AUTHORED AT ROUGHLY HALF A TILE AND THAT IS WHY EIGHT WORKPLACES READ AS DOLLHOUSE
   * FURNITURE ON A BROWN MAT. MEASURED off the third contact sheet: a tile is 48px, the biggest prop
   * in the corpus is 34px wide and most are 20-26, so a five-prop workplace covered under half the
   * ground patch it stood on and the rest was empty floor. The eye reads that as "some small objects
   * near each other", which is exactly the failure the ARCHITECTURE doc warns about.
   *
   * ⚠️ The tempting fix is to author every prop bigger, i.e. thirty edits, each of which could be
   * wrong on its own. One scale is a single number, it preserves every relative proportion the
   * corpus already got right, and — because roles are expressed in TILES rather than in prop widths
   * — it also closes the gaps between props without touching the role table.
   */
  var PROP_SCALE = 1.45;
  var STATION_SCALE = 1.16;
  var SATELLITE_SCALE = 0.94;
  var RECESSION = 0.62;                    // ceiling on k, so a distant prop fades but never vanishes

  function solve(trade, opts) {
    var tile = opts.tile || 48;
    var scale = (opts.scale == null ? tile / 48 : opts.scale) * PROP_SCALE;
    var ox = opts.originX, oy = opts.originY;
    var pal = C().palette(trade);
    var seed = opts.seed || 1;

    /*
     * ⛔ A TRADE MAY SPECIFY ITS STATION AS A STRING OR AS {prop, opts}. The `opts` are handed
     * straight to the prop at paint time.
     *
     * ⭐ THIS IS WHAT MAKES A FORTY-TRADE CORPUS AFFORDABLE. Without it every trade needs its own
     * props, so the corpus grows as trades x props and most of the new props are near-duplicates of
     * old ones — which is both a lot of authoring and the shared-silhouette defect arriving from the
     * other direction (see JourneyworkShop.shelf). With it, a `vat` is a tanning pit, a dye vat and
     * a brewer's mash tun depending on what is IN it, and the differences are authored once in the
     * corpus rather than three times in the shop.
     *
     * ⚠️ A variant may change colour, contents and small features. It must NOT change the prop into
     * a different object — that is a new prop, and pretending otherwise is how a corpus ends up with
     * forty trades that all look the same.
     */
    var stationSpec = typeof trade.station === 'string' ? { prop: trade.station } : trade.station;
    var items = [{
      prop: stationSpec.prop, opts: stationSpec.opts || null,
      x: ox, yBase: oy, lift: false, onStation: true, isStation: true,
      scale: scale * STATION_SCALE, palette: pal, seed: seed
    }];

    for (var i = 0; i < trade.satellites.length; i++) {
      var sat = trade.satellites[i];
      var r = ROLES[sat.role];
      if (!r) throw new Error('Journeywork: unknown role "' + sat.role + '" on trade ' + trade.id);
      items.push({
        prop: sat.prop,
        opts: sat.opts || null,
        x: ox + r.dx * tile,
        /*
         * ⛔ AN `onStation` PROP MUST DRAW *AFTER* ITS STATION, AND THE FIRST VERSION DREW IT
         * BEHIND. Giving it a raised baseline (oy - 0.30 tile) put it FURTHER from the viewer under
         * the one depth rule, so the scribe's inkstand and the fishwife's catch sorted ahead of the
         * furniture they sit on. The draw order printed it plainly — `catchTray -> stallTable` —
         * and the picture showed them floating loose beside the table.
         *
         * The fix is to keep the station's OWN baseline for sorting (so it stays in front of
         * everything behind it) and carry the surface lift separately as `surfaceLift`, applied at
         * paint time. Depth and height are different questions and were being answered by one
         * number.
         */
        yBase: r.onStation ? oy : oy + r.dy * tile,
        surfaceLift: r.onStation ? tile * 0.30 : 0,
        lift: !!r.lift,
        onStation: !!r.onStation,
        isStation: false,
        scale: scale * (r.onStation ? STATION_SCALE : SATELLITE_SCALE),
        palette: pal, seed: seed + i * 7 + 3
      });
    }

    /*
     * ⛔ A SATELLITE HEIGHT CEILING WAS BUILT HERE, MEASURED, AND REMOVED THE SAME SESSION. THE
     * REASON IT FAILED IS WORTH MORE THAN THE RULE WAS.
     *
     * The idea: the station names the trade, so scale down any satellite that out-towers it. It was
     * derived rather than typed — `JourneyworkShop.measure` reports the REAL drawn height of each
     * prop by scanning its pixels, so nothing had to be kept in step by hand (wing §11a).
     *
     * ⛔ It fired on FIVE trades and made three of them worse. The tell was that it clamped the
     * BAKER'S OVEN, and the baker was the best-reading cell on the sheet BEFORE the clamp existed —
     * i.e. its positives included a case known-good in advance. The tannery was the loud failure:
     * a vat is a legitimately LOW station, so a 40px stretching frame was squashed to ~21px and the
     * hide, which is the entire silhouette of a tannery, effectively vanished.
     *
     * ⭐ The rule was wrong in its premise, not its threshold. A workplace with a low station and
     * tall satellites is normal and correct — a vat under drying frames, a counter under a bottle
     * shelf, a table under an oven — so height is simply not what dominance is made of. Tuning the
     * ceiling would have been fitting a bar to today's eight trades (CLAUDE.md §2b: a bar invented
     * to fit today's data), and the wing already has the levers that DO work and do not deform the
     * art: the station sits front and centre, is drawn larger, and is the only thing at full
     * contrast once everything behind it recedes into the ground.
     *
     * The MEASUREMENT stays. It earns its place on the footprint below, where it replaced a guess.
     */
    var shop = S();
    var measuredCount = 0;

    /*
     * Contrast from distance, resolved ONCE for the whole group. `k` is how far behind the station
     * a prop sits, in tiles, clamped — so a prop in FRONT of the station keeps full contrast (a dark
     * near object is a repoussoir and helps), and anything behind it fades in proportion.
     *
     * ⚠️ A lifted prop (canopy, hanging herbs) shares the station's baseline, so it would take k=0
     * and hang at full strength over a receded scene. It is given the mean recession of the props it
     * covers instead, which is what keeps a canopy sitting IN the picture rather than on top of it.
     */
    var behind = [];
    for (var j = 0; j < items.length; j++) {
      var it = items[j];
      var k = it.lift ? 0 : Math.max(0, (oy - it.yBase) / (tile * 1.05));
      it.recession = Math.min(RECESSION, k * RECESSION);
      if (!it.lift) behind.push(it.recession);
    }
    var meanRecession = behind.length
      ? behind.reduce(function (a, b) { return a + b; }, 0) / behind.length : 0;
    var forms = F();
    // ⛔ Recede INTO THE GROUND THIS TRADE STANDS ON, never into a fixed haze — see the comment on
    // JourneyworkForms.recede. On ash that darkens a distant prop; on flour it pales it.
    var groundKind = trade.ground || 'swept';
    var recedeInto = (GROUNDS[groundKind] || GROUNDS.swept).base;
    for (var m = 0; m < items.length; m++) {
      if (items[m].lift) items[m].recession = meanRecession;
      items[m].palette = forms.recedePalette(pal, items[m].recession, recedeInto);
    }

    // ⛔ ONE depth rule for the whole product: further from the viewer (smaller yBase) draws first.
    // Lifted props (canopy, hanging herbs) always draw last so they hang OVER the scene.
    items.sort(function (a, b) {
      if (a.lift !== b.lift) return a.lift ? 1 : -1;
      if (a.yBase !== b.yBase) return a.yBase - b.yBase;
      // Same baseline: whatever sits ON the surface draws over whatever IS the surface.
      if (a.onStation !== b.onStation) return a.onStation ? 1 : -1;
      return 0;
    });

    /*
     * ⛔ THE PATCH IS THE UNION OF WHAT THE PROPS ACTUALLY DRAW, NOT OF WHERE THEY ARE ANCHORED.
     *
     * It used to be `min/max of x and yBase, padded by a whole tile in every direction`, which is a
     * guess made before anything could be measured — and the guess was far too generous. Roles sit
     * within ±0.66 tile of the station, so the anchors span about 64px while the pad added 96, and
     * the props themselves are 30-45px: the result was a patch roughly twice the size of its
     * contents, with the difference showing as bare ground on all four sides. A large empty shape
     * around a small group reads as "these objects are lost in a yard", the opposite of what the
     * patch is for.
     *
     * Now that `JourneyworkShop.measure` reports real drawn extents, the patch is derived from them
     * and padded by a fraction of a tile. Unmeasured props fall back to the old anchor pad, so the
     * result is never SMALLER than the content — failing toward a slightly generous patch, which is
     * cosmetic, rather than toward a clipped one, which is a defect.
     */
    var minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (var b = 0; b < items.length; b++) {
      var bi = items[b];
      var bb = bi.lift ? null : shop.measure(bi.prop, bi.scale, pal, bi.seed, bi.opts);
      if (bb) measuredCount++;
      var padX = bb ? 0 : tile * 0.5, padY = bb ? 0 : tile * 0.5;
      var l = bi.x - (bb ? bb.left : 0) - padX;
      var rr = bi.x + (bb ? bb.right : 0) + padX;
      var t2 = bi.yBase - (bb ? bb.top : 0) - padY;
      var bo = bi.yBase + (bb ? 2 : padY);
      if (l < minX) minX = l;
      if (rr > maxX) maxX = rr;
      if (t2 < minY) minY = t2;
      if (bo > maxY) maxY = bo;
    }
    /*
     * ⛔ THE WORKER'S OWN TILE IS PART OF THE WORKED GROUND, AND LEAVING IT OUT WAS VISIBLE THE
     * FIRST TIME THIS RAN IN THE ENGINE RATHER THAN ON A CONTACT SHEET.
     *
     * The contact sheet draws furniture with nobody in it, so it cannot show this at all. In the
     * real runtime the NPC stands one tile off the station — correctly, since you cannot stand
     * inside an anvil — and the patch, derived purely from where the PROPS are, stopped short of
     * them. Every screenshot therefore read as "a person standing near some furniture" instead of
     * "a smith at his anvil", which is the entire proposition.
     *
     * ⭐ A yard is worn where the work happens, and the work happens where the worker stands. So the
     * footprint is extended over `workTile`, and the picture composes itself: the figure is inside
     * the place rather than beside it.
     */
    var wfx = { north: 0, south: 0, east: 1, west: -1 };
    var wfy = { north: -1, south: 1, east: 0, west: 0 };
    var wd = trade.workFrom || 'south';
    var wx = ox + (wfx[wd] || 0) * tile, wy = oy + (wfy[wd] === undefined ? 1 : wfy[wd]) * tile;
    if (wx - tile * 0.40 < minX) minX = wx - tile * 0.40;
    if (wx + tile * 0.40 > maxX) maxX = wx + tile * 0.40;
    if (wy - tile * 0.20 < minY) minY = wy - tile * 0.20;
    if (wy + tile * 0.16 > maxY) maxY = wy + tile * 0.16;

    var footprint = {
      minX: minX - tile * 0.22, maxX: maxX + tile * 0.22,
      minY: minY - tile * 0.10, maxY: maxY + tile * 0.30
    };

    // Where the worker stands, derived from the furniture rather than guessed — this is the fix for
    // the quoted complaint that NPCs "just stand on the spot turning in random directions".
    var wf = { north: { dx: 0, dy: -1 }, south: { dx: 0, dy: 1 }, east: { dx: 1, dy: 0 }, west: { dx: -1, dy: 0 } };
    var workTile = wf[trade.workFrom] || wf.south;

    return {
      items: items, workTile: workTile, footprint: footprint,
      ground: trade.ground || 'swept', measuredCount: measuredCount,
      // Carried so `paintGround` can size its marks to the tile rather than to a 48px assumption.
      unit: tile / 48
    };
  }

  /**
   * The worked ground a trade stands on — trodden earth, ash, spilled clay.
   *
   * ⭐ Added after the first contact sheet, and it does more for legibility than any prop. Props
   * standing on raw grass read as objects that happen to be near each other; the same props on a
   * patch of worked ground read as a PLACE somebody uses. It also gives the eye the group's extent,
   * which is what tells you where one workplace ends and the next begins.
   *
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} solved Result of solve().
   * @param {object} pal Palette.
   * @param {number} seed Deterministic seed.
   */
  /*
   * ⛔ THE PATCH WAS ONE COLOUR FOR ALL EIGHT TRADES AND IT IS THE BIGGEST SINGLE SHAPE IN THE CELL.
   *
   * It was `shade(pal.stone, -0.34)`, and every palette's `stone` is within a few percent of every
   * other, so a smithy, a tannery and a scriptorium all stood on the same brown blob — which is
   * worse than no patch, because a large identical shape actively ARGUES that the eight cells are
   * the same thing. A floor is evidence of the work done on it: ash under a forge, wet boards under
   * a fish stall, swept flags in a scriptorium.
   *
   * ⚠️ Each kind is a base colour plus a MARK RULE, never a texture bitmap — the product ships no
   * PNGs (CLAUDE.md §1.1: the product must GENERATE the beauty).
   */
  var GROUNDS = {
    ash:    { base: '#3a3531', alpha: 0.80, marks: 'cinders' },
    boards: { base: '#5c4b38', alpha: 0.86, marks: 'planking' },
    flags:  { base: '#6f6b62', alpha: 0.80, marks: 'flagstones' },
    flour:  { base: '#7d7364', alpha: 0.78, marks: 'dust' },
    clay:   { base: '#6b4633', alpha: 0.82, marks: 'ruts' },
    swept:  { base: '#5b4e3c', alpha: 0.74, marks: 'sweep' },
    mud:    { base: '#42382c', alpha: 0.86, marks: 'puddles' },
    sand:   { base: '#7a6e58', alpha: 0.76, marks: 'grit' }
  };

  /**
   * The worked ground a trade stands on — ash, wet boards, swept flags, spilled clay.
   *
   * ⭐ Added after the first contact sheet, and it does more for legibility than any prop. Props
   * standing on raw grass read as objects that happen to be near each other; the same props on a
   * patch of worked ground read as a PLACE somebody uses. It also gives the eye the group's extent,
   * which is what tells you where one workplace ends and the next begins.
   *
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} solved Result of solve().
   * @param {object} pal Palette.
   * @param {number} seed Deterministic seed.
   * @param {string} [kind] A key of GROUNDS; falls back to a neutral swept yard.
   */
  function paintGround(c, solved, pal, seed, kind, unit) {
    var f = F();
    var g = GROUNDS[kind] || GROUNDS.swept;
    var fp = solved.footprint;
    var cx = (fp.minX + fp.maxX) / 2, cy = (fp.minY + fp.maxY) / 2;
    var rx = (fp.maxX - fp.minX) * 0.42, ry = (fp.maxY - fp.minY) * 0.40;
    var r = f.rng(seed || 2);
    var i;

    /*
     * ⛔ THE MARKS SCALE WITH THE GROUND. THEY DID NOT, AND IT WAS A DEFECT IN THE PRODUCT RATHER
     * THAN IN THE PICTURE THAT EXPOSED IT.
     *
     * Every cinder, plank line, flagstone joint and puddle was sized in ABSOLUTE pixels — `fillRect(
     * x, y, 1 + r()*2, 1)`, `lineWidth = 1` — tuned by eye at a 48px tile. The patch itself is
     * derived from the footprint and therefore grows with the buyer's tile size, so at 96px tiles
     * the same forty specks are spread over four times the area and the ground goes flat. MEASURED
     * by rendering a store plate at tile 104: eight distinct worked grounds became eight blank
     * blobs, and NOTHING in the project could have reported it — the counts are all correct, the
     * colours are all correct, and the only symptom is that it stops looking like anything.
     *
     * ⚠️ `u` is derived from the caller's tile, and the mark COUNT scales with area (u squared)
     * while mark SIZE scales linearly, because that is what keeps density constant rather than
     * merely keeping the marks visible. Counts are capped so a very large tile cannot turn a ground
     * into a scatter plot.
     */
    var u = unit && unit > 0 ? unit : 1;

    /*
     * ⚠️ TWO KINDS OF MARK, AND SCALING THEM THE SAME WAY WAS WRONG IN THE OTHER DIRECTION.
     *
     * The first fix multiplied EVERY mark count by area, and at a large tile the flour dust and the
     * tannery puddles turned into a heap of overlapping discs — flour read as a pile of coins. The
     * reason is that those marks are already sized as a FRACTION OF THE PATCH (`rx * 0.10`), so they
     * grow on their own; multiplying their count as well double-counts the same growth.
     *
     * ⭐ The rule that holds in both directions: a mark whose SIZE is patch-relative keeps a roughly
     * constant COUNT, and only a mark of ABSOLUTE size (a cinder, a grit speck, a thread scrap)
     * needs more of itself to keep density constant. Two helpers, so the distinction is written
     * down rather than remembered.
     */
    var n = function (base) {                 // absolute-size marks: more of them as the area grows
      return Math.max(1, Math.min(Math.round(base * u * u), Math.round(base * 6)));
    };
    var nRel = function (base) {              // patch-relative marks: barely more, they grow already
      return Math.max(1, Math.round(base * (1 + (u - 1) * 0.35)));
    };

    c.save();

    /*
     * ⛔ THE OUTLINE IS BUILT ONCE INTO AN ARRAY AND TRACED TWICE, RATHER THAN TRACED AND REUSED.
     *
     * A canvas path is NOT part of the drawing state, so it survives save()/restore() — which makes
     * "close the patch, clip, draw marks, restore, stroke the same path for the edge lip" look
     * correct and be wrong: every mark rule below calls beginPath(), so by the time the lip is
     * stroked the current path is the LAST CINDER. It would have drawn a 2px black speck and no
     * outline, silently, in a routine whose output nothing asserts on.
     */
    var outline = [];
    var steps = 22;
    for (i = 0; i <= steps; i++) {
      var a = (i / steps) * Math.PI * 2;
      var k = 0.86 + r() * 0.24;                       // ragged — a worked yard has no clean boundary
      outline.push([cx + Math.cos(a) * rx * k, cy + Math.sin(a) * ry * k]);
    }
    var trace = function () {
      c.beginPath();
      for (var q = 0; q < outline.length; q++) {
        if (q === 0) c.moveTo(outline[q][0], outline[q][1]); else c.lineTo(outline[q][0], outline[q][1]);
      }
      c.closePath();
    };

    // The patch itself, clipped so every mark below stays inside it and no rule needs its own edge test.
    trace();
    c.save();
    c.clip();
    c.globalAlpha = g.alpha;
    c.fillStyle = g.base;
    c.fillRect(cx - rx * 1.3, cy - ry * 1.3, rx * 2.6, ry * 2.6);

    var lo = f.shade(g.base, -0.30), hi = f.shade(g.base, 0.20);
    if (g.marks === 'cinders') {                        // forge: black clinker and a few live embers
      for (i = 0; i < n(34); i++) {
        var cxx = cx + (r() - 0.5) * rx * 2, cyy = cy + (r() - 0.5) * ry * 2;
        c.fillStyle = r() > 0.86 ? '#8a3a16' : lo;
        c.fillRect(cxx, cyy, (1 + r() * 2) * u, (1 + r()) * u);
      }
    } else if (g.marks === 'planking') {                // market: boards laid over wet ground
      c.strokeStyle = lo; c.lineWidth = 1 * u; c.globalAlpha = g.alpha * 0.8;
      for (i = -3; i <= 3; i++) {
        var by = Math.round(cy + i * ry * 0.30) + 0.5;
        c.beginPath(); c.moveTo(cx - rx * 1.2, by); c.lineTo(cx + rx * 1.2, by); c.stroke();
      }
      c.globalAlpha = g.alpha * 0.35; c.fillStyle = '#3d5560';
      c.beginPath(); c.ellipse(cx - rx * 0.42, cy + ry * 0.34, rx * 0.26, ry * 0.13, 0, 0, Math.PI * 2); c.fill();
    } else if (g.marks === 'flagstones') {              // scriptorium: laid stone, swept
      c.strokeStyle = lo; c.lineWidth = 1 * u; c.globalAlpha = g.alpha * 0.7;
      for (i = -2; i <= 2; i++) {
        var fy = Math.round(cy + i * ry * 0.42) + 0.5;
        c.beginPath(); c.moveTo(cx - rx * 1.2, fy); c.lineTo(cx + rx * 1.2, fy); c.stroke();
        for (var j = -2; j <= 2; j++) {
          var fx = Math.round(cx + j * rx * 0.46 + (i % 2 ? rx * 0.23 : 0)) + 0.5;
          c.beginPath(); c.moveTo(fx, fy); c.lineTo(fx, fy + ry * 0.42); c.stroke();
        }
      }
    } else if (g.marks === 'dust') {                    // bakehouse: flour thrown around the table
      c.globalAlpha = g.alpha * 0.5; c.fillStyle = '#d9cfb6';
      for (i = 0; i < nRel(5); i++) {
        c.beginPath();
        c.ellipse(cx + (r() - 0.5) * rx * 1.4, cy + (r() - 0.4) * ry * 1.2,
          rx * (0.10 + r() * 0.13), ry * (0.06 + r() * 0.08), 0, 0, Math.PI * 2);
        c.fill();
      }
    } else if (g.marks === 'ruts') {                    // pottery: barrow ruts and spilled slip
      c.strokeStyle = f.shade(g.base, -0.38); c.lineWidth = 2 * u; c.globalAlpha = g.alpha * 0.85;
      for (i = -1; i <= 1; i += 2) {
        c.beginPath();
        c.moveTo(cx - rx * 1.1, cy + i * ry * 0.16);
        c.quadraticCurveTo(cx, cy + i * ry * 0.34, cx + rx * 1.1, cy + i * ry * 0.10);
        c.stroke();
      }
      c.globalAlpha = g.alpha * 0.45; c.fillStyle = hi;
      for (i = 0; i < n(6); i++) {
        c.beginPath();
        c.arc(cx + (r() - 0.5) * rx * 1.5, cy + (r() - 0.5) * ry * 1.5,
          (1 + r() * 2.4) * Math.min(u, 1.8), 0, Math.PI * 2);
        c.fill();
      }
    } else if (g.marks === 'sweep') {                   // weaving shed: brushed earth, thread scraps
      c.strokeStyle = hi; c.lineWidth = 1 * u; c.globalAlpha = g.alpha * 0.28;
      for (i = 0; i < n(9); i++) {
        var sy = cy + (r() - 0.5) * ry * 1.7;
        c.beginPath();
        c.moveTo(cx - rx * 0.95, sy);
        c.quadraticCurveTo(cx, sy - ry * 0.10, cx + rx * 0.95, sy + ry * 0.05);
        c.stroke();
      }
      c.globalAlpha = g.alpha * 0.9;
      for (i = 0; i < n(7); i++) {
        c.strokeStyle = ['#a8425a', '#3f6f8a', '#c9a13c'][i % 3]; c.lineWidth = 1 * u;
        var tx = cx + (r() - 0.5) * rx * 1.6, ty = cy + (r() - 0.5) * ry * 1.6;
        c.beginPath();
        c.moveTo(tx, ty); c.lineTo(tx + (r() - 0.5) * 7 * u, ty + (r() - 0.5) * 4 * u);
        c.stroke();
      }
    } else if (g.marks === 'puddles') {                 // tannery: churned, standing liquor
      c.globalAlpha = g.alpha * 0.55; c.fillStyle = '#5d5a3a';
      for (i = 0; i < nRel(4); i++) {
        c.beginPath();
        c.ellipse(cx + (r() - 0.5) * rx * 1.5, cy + (r() - 0.4) * ry * 1.4,
          rx * (0.09 + r() * 0.11), ry * (0.05 + r() * 0.06), 0, 0, Math.PI * 2);
        c.fill();
      }
      c.globalAlpha = g.alpha * 0.7; c.strokeStyle = lo; c.lineWidth = 1.5 * u;
      for (i = 0; i < n(7); i++) {
        var mx = cx + (r() - 0.5) * rx * 1.7, my = cy + (r() - 0.5) * ry * 1.7;
        c.beginPath();
        c.moveTo(mx, my); c.lineTo(mx + (r() - 0.5) * 9 * u, my + (r() - 0.5) * 5 * u);
        c.stroke();
      }
    } else {                                            // grit: raked sand and gravel
      for (i = 0; i < n(40); i++) {
        c.fillStyle = r() > 0.5 ? hi : lo;
        c.globalAlpha = g.alpha * 0.5;
        c.fillRect(cx + (r() - 0.5) * rx * 2, cy + (r() - 0.5) * ry * 2, (1 + r()) * u, 1 * u);
      }
    }

    c.restore();                                        // drop the clip

    // A soft dark lip where the yard meets whatever the map already had there.
    trace();
    c.globalAlpha = 0.20;
    c.strokeStyle = '#000000';
    c.lineWidth = 2;
    c.stroke();
    c.globalAlpha = 1;
    c.restore();
  }

  /**
   * Draw a solved workplace.
   * @param {CanvasRenderingContext2D} c Target context.
   * @param {object} solved Result of solve().
   * @param {object} [opts] {ground:boolean, palette, seed}
   */
  function paint(c, solved, opts) {
    var shop = S();
    var o = opts || {};
    if (o.ground !== false && solved.items.length) {
      paintGround(c, solved, o.palette || solved.items[0].palette, o.seed,
        o.groundKind || solved.ground, o.unit || solved.unit);
    }
    for (var i = 0; i < solved.items.length; i++) {
      var it = solved.items[i];
      var arg = {
        x: it.x,
        yBase: it.yBase - (it.surfaceLift || 0),   // depth from yBase, HEIGHT from surfaceLift
        scale: it.scale, palette: it.palette, seed: it.seed
      };
      // The corpus's per-use variant, applied LAST so a trade can override anything the solver set —
      // except the geometry the solver owns, which is why x/yBase/scale are restored below.
      if (it.opts) {
        for (var k in it.opts) if (Object.prototype.hasOwnProperty.call(it.opts, k)) arg[k] = it.opts[k];
        arg.x = it.x;
        arg.yBase = it.yBase - (it.surfaceLift || 0);
        arg.scale = it.scale;
      }
      shop.draw(c, it.prop, arg);
    }
  }

  return {
    ROLES: ROLES, GROUNDS: GROUNDS, solve: solve, paint: paint, paintGround: paintGround,
    STATION_SCALE: STATION_SCALE, SATELLITE_SCALE: SATELLITE_SCALE, RECESSION: RECESSION
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = JourneyworkPlace;
