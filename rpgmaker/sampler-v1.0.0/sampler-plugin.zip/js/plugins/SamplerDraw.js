//=============================================================================
// SamplerDraw.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Sampler draw - woven linen, cross-stitches, clue strips,
 * the embroidery hoop and the finished sampler, all drawn in code. Place BETWEEN
 * SamplerCore and Sampler.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * Every picture Sampler shows is drawn here onto a canvas: no image file is
 * loaded. No parameters of its own. Must be installed below SamplerCore.js and
 * above Sampler.js.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var SamplerDraw = (function () {
  'use strict';
  var TAU = Math.PI * 2;
  var FACE = '"Palatino Linotype", "Book Antiqua", Palatino, "Georgia", serif';
  var LINEN = ['#efe6d2', '#e3d7bd'], TACK = '#4a4038', INK = '#2c2218';

  function rng(seed) { var a = seed >>> 0; return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function rr(ctx, x, y, w, h, r) { r = Math.max(0, Math.min(r, w / 2, h / 2)); ctx.beginPath(); ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r); ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h); ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r); ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.closePath(); }
  function shade(hex, k) { var v = parseInt(String(hex).slice(1), 16); if (!isFinite(v)) return hex; var r = (v >> 16) & 255, g = (v >> 8) & 255, b = v & 255; var f = function (c) { return Math.max(0, Math.min(255, Math.round(k >= 0 ? c + (255 - c) * k : c * (1 + k)))); }; return 'rgb(' + f(r) + ',' + f(g) + ',' + f(b) + ')'; }

  /** The sewing table under everything: dark walnut with a few thread spools and a needle. */
  function drawTable(ctx, W, H) {
    var g = ctx.createLinearGradient(0, 0, W, H); g.addColorStop(0, '#3b271a'); g.addColorStop(1, '#1d120b'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    var r = rng(0x5E3);
    // ⛔ found by looking (2026-09-23): the grain stepped x by 40 and stopped at the last step <= W, so on an 816 px
    // screen the right-hand 16 px were bare gradient, a visible band. Each line now runs one step PAST the edge.
    for (var y = 0; y < H; y += 3) { ctx.strokeStyle = r() < 0.5 ? 'rgba(255,215,170,0.035)' : 'rgba(0,0,0,0.12)'; ctx.lineWidth = 1 + r() * 2; ctx.beginPath(); ctx.moveTo(0, y); for (var x = 0; x < W + 40; x += 40) ctx.lineTo(x, y + Math.sin(x / 110 + y / 37) * 2); ctx.stroke(); }
  }

  /** Relative luminance (0..255 scale) of a '#rrggbb' thread; NaN-safe (an unparseable colour reads as mid-grey). */
  function luma(hex) { var v = parseInt(String(hex).slice(1), 16); if (!isFinite(v)) return 128; return 0.2126 * ((v >> 16) & 255) + 0.7152 * ((v >> 8) & 255) + 0.0722 * (v & 255); }

  /**
   * The two threads the chart is WORKED in before the colours go in: the grey tacking thread (TACK) for the player's
   * stitches, and the palette thread farthest from TACK in colour for the given (locked) stitches, so a given always
   * stands out from the player's work.
   * ⛔ 2026-09-23, measured by looking: working the chart in the palette's darkest thread made the reveal invisible
   * (a navy work stitch and a revealed navy stitch are the same picture), so the tacking grey stays; only the givens
   * moved off a fixed index (threads[3], which in 'harvest' is nearly as dark as TACK).
   * @param {string[]} threads
   * @returns {{work:string, given:string}}
   */
  function workThreads(threads) {
    var a = hexRgbD(TACK), g = 0, best = -1;
    for (var i = 0; i < threads.length; i++) { var b = hexRgbD(threads[i]), d = (a[0] - b[0]) * (a[0] - b[0]) + (a[1] - b[1]) * (a[1] - b[1]) + (a[2] - b[2]) * (a[2] - b[2]); if (d > best) { best = d; g = i; } }
    return { work: TACK, given: threads[g] };
  }
  function hexRgbD(h) { var v = parseInt(String(h).slice(1), 16); return isFinite(v) ? [(v >> 16) & 255, (v >> 8) & 255, v & 255] : [128, 128, 128]; }

  var WREATHS = ['beads', 'garland', 'rope', 'twin'];
  /** The wreath a finished sampler is bordered with, chosen from its seed. */
  function wreathFor(seed) { return WREATHS[Math.floor(rng((seed >>> 0) ^ 0xB0D)() * WREATHS.length) % WREATHS.length]; }

  /** A thread spool at (x, y), seen from the side. */
  function drawSpool(ctx, x, y, colour, s) {
    ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.ellipse(3, 30, 24, 6, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = '#a8804a'; rr(ctx, -22, -30, 44, 8, 3); ctx.fill(); rr(ctx, -22, 22, 44, 8, 3); ctx.fill();
    var g = ctx.createLinearGradient(-18, 0, 18, 0); g.addColorStop(0, shade(colour, -0.35)); g.addColorStop(0.45, shade(colour, 0.25)); g.addColorStop(1, shade(colour, -0.45));
    ctx.fillStyle = g; ctx.fillRect(-18, -22, 36, 44);
    ctx.strokeStyle = shade(colour, -0.25); ctx.lineWidth = 0.8; for (var k = -20; k < 22; k += 3) { ctx.beginPath(); ctx.moveTo(-18, k); ctx.lineTo(18, k + 1.5); ctx.stroke(); }
    ctx.restore();
  }

  /** Woven linen: a warm ground with warp and weft threads. */
  function drawLinen(ctx, x, y, w, h, seed) {
    var g = ctx.createLinearGradient(x, y, x, y + h); g.addColorStop(0, LINEN[0]); g.addColorStop(1, LINEN[1]); ctx.fillStyle = g; ctx.fillRect(x, y, w, h);
    var r = rng(seed >>> 0), i;
    ctx.globalAlpha = 0.18; ctx.strokeStyle = '#b8a47e'; ctx.lineWidth = 1;
    for (i = x + 1; i < x + w; i += 3) { ctx.beginPath(); ctx.moveTo(i + 0.5, y); ctx.lineTo(i + 0.5, y + h); ctx.stroke(); }
    ctx.globalAlpha = 0.12; for (i = y + 1; i < y + h; i += 3) { ctx.beginPath(); ctx.moveTo(x, i + 0.5); ctx.lineTo(x + w, i + 0.5); ctx.stroke(); }
    ctx.globalAlpha = 1;
    for (i = 0; i < w * h / 160; i++) { ctx.fillStyle = r() < 0.5 ? 'rgba(255,255,255,0.25)' : 'rgba(120,95,60,0.12)'; ctx.fillRect(x + r() * w, y + r() * h, 1 + r() * 2, 1); }
  }

  /**
   * One cross-stitch filling a cell at (x, y) of size s: two diagonal thread strokes, the top one crossing over,
   * each lit along its length, with a small shadow on the linen.
   */
  function drawStitch(ctx, x, y, s, colour) {
    var p = s * 0.16, w = Math.max(1.6, s * 0.2), a = [x + p, y + p], b = [x + s - p, y + s - p], c = [x + s - p, y + p], d = [x + p, y + s - p];
    ctx.lineCap = 'round';
    ctx.strokeStyle = 'rgba(40,28,15,0.28)'; ctx.lineWidth = w + 1;
    ctx.beginPath(); ctx.moveTo(a[0] + 1, a[1] + 1.2); ctx.lineTo(b[0] + 1, b[1] + 1.2); ctx.moveTo(c[0] + 1, c[1] + 1.2); ctx.lineTo(d[0] + 1, d[1] + 1.2); ctx.stroke();
    var under = ctx.createLinearGradient(c[0], c[1], d[0], d[1]); under.addColorStop(0, shade(colour, -0.2)); under.addColorStop(0.5, shade(colour, 0.05)); under.addColorStop(1, shade(colour, -0.3));
    ctx.strokeStyle = under; ctx.lineWidth = w; ctx.beginPath(); ctx.moveTo(c[0], c[1]); ctx.lineTo(d[0], d[1]); ctx.stroke();
    var over = ctx.createLinearGradient(a[0], a[1], b[0], b[1]); over.addColorStop(0, shade(colour, 0.05)); over.addColorStop(0.45, shade(colour, 0.32)); over.addColorStop(1, shade(colour, -0.15));
    ctx.strokeStyle = over; ctx.lineWidth = w; ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke();
    if (s >= 14) { ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = Math.max(0.6, w * 0.22); ctx.beginPath(); ctx.moveTo(a[0] + w * 0.2, a[1] - w * 0.1); ctx.lineTo(b[0] - s * 0.3, b[1] - s * 0.34); ctx.stroke(); }
    ctx.lineCap = 'butt';
  }

  /** A cell the player has marked empty: a small pencil cross, faint. */
  function drawMark(ctx, x, y, s) {
    var p = s * 0.36; ctx.strokeStyle = 'rgba(120,90,60,0.55)'; ctx.lineWidth = Math.max(1, s * 0.07); ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(x + p, y + p); ctx.lineTo(x + s - p, y + s - p); ctx.moveTo(x + s - p, y + p); ctx.lineTo(x + p, y + s - p); ctx.stroke(); ctx.lineCap = 'butt';
  }

  /** The chart grid over the linen: fine lines per cell, heavier every fifth, as a printed cross-stitch chart. */
  function drawGrid(ctx, x, y, n, s) {
    for (var i = 0; i <= n; i++) {
      var heavy = i % 5 === 0; ctx.strokeStyle = heavy ? 'rgba(90,64,40,0.55)' : 'rgba(120,95,65,0.25)'; ctx.lineWidth = heavy ? 1.4 : 0.8;
      ctx.beginPath(); ctx.moveTo(x + i * s + 0.5, y); ctx.lineTo(x + i * s + 0.5, y + n * s); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(x, y + i * s + 0.5); ctx.lineTo(x + n * s, y + i * s + 0.5); ctx.stroke();
    }
  }

  /**
   * The clue strips: column clues stacked above, row clues to the left, on paper tape. `done` flags tick a line off.
   * @returns nothing; geometry comes from `L` = {x, y, s, n, top, left}
   */
  function drawClues(ctx, L, clues, rowDone, colDone) {
    var i, j, fs = Math.max(10, Math.min(18, Math.floor(L.s * 0.58)));
    ctx.fillStyle = 'rgba(250,244,230,0.94)'; rr(ctx, L.x, L.y - L.top, L.n * L.s, L.top - 4, 3); ctx.fill(); rr(ctx, L.x - L.left, L.y, L.left - 4, L.n * L.s, 3); ctx.fill();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.font = 'bold ' + fs + 'px ' + FACE;
    for (i = 0; i < L.n; i++) {
      var col = clues.cols[i], cx = L.x + (i + 0.5) * L.s;
      if (i % 2) { ctx.fillStyle = 'rgba(180,150,110,0.12)'; ctx.fillRect(L.x + i * L.s, L.y - L.top, L.s, L.top - 4); }
      for (j = 0; j < col.length; j++) { ctx.fillStyle = colDone[i] ? 'rgba(60,45,30,0.3)' : INK; ctx.fillText(String(col[j]), cx, L.y - 10 - (col.length - 1 - j) * (fs + 3)); }
      var row = clues.rows[i], cy = L.y + (i + 0.5) * L.s;
      if (i % 2) { ctx.fillStyle = 'rgba(180,150,110,0.12)'; ctx.fillRect(L.x - L.left, L.y + i * L.s, L.left - 4, L.s); }
      for (j = 0; j < row.length; j++) { ctx.fillStyle = rowDone[i] ? 'rgba(60,45,30,0.3)' : INK; ctx.fillText(String(row[j]), L.x - 14 - (row.length - 1 - j) * (fs * 0.95 + 4), cy + 1); }
    }
  }

  /**
   * The embroidery hoop drawn around a circle of radius R centred at (cx, cy): an outer and inner beech ring
   * with grain and a brass screw clamp at the top.
   */
  function drawHoop(ctx, cx, cy, R) {
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.beginPath(); ctx.arc(cx + 4, cy + 6, R + 16, 0, TAU); ctx.arc(cx + 4, cy + 6, R - 2, 0, TAU, true); ctx.fill();
    for (var k = 0; k < 2; k++) {
      var r0 = R + (k ? 1 : 7), r1 = R + (k ? 7 : 15);
      var g = ctx.createRadialGradient(cx - R * 0.3, cy - R * 0.3, R * 0.5, cx, cy, r1);
      g.addColorStop(0, k ? '#e8c88e' : '#d9b27a'); g.addColorStop(1, k ? '#a07640' : '#8a6030');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, r1, 0, TAU); ctx.arc(cx, cy, r0, 0, TAU, true); ctx.fill();
      ctx.strokeStyle = 'rgba(90,55,20,0.35)'; ctx.lineWidth = 0.8;
      for (var t = 0; t < 26; t++) { var a0 = t / 26 * TAU; ctx.beginPath(); ctx.arc(cx, cy, (r0 + r1) / 2 + Math.sin(t * 2.3) * 1.5, a0, a0 + 0.18); ctx.stroke(); }
      ctx.strokeStyle = 'rgba(255,240,210,0.5)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(cx, cy, r1 - 1, Math.PI * 1.05, Math.PI * 1.6); ctx.stroke();
    }
    // brass clamp
    var bx = cx, by = cy - R - 16;
    var bg = ctx.createLinearGradient(bx - 10, 0, bx + 10, 0); bg.addColorStop(0, '#8a6120'); bg.addColorStop(0.5, '#f4d88a'); bg.addColorStop(1, '#7a5418');
    ctx.fillStyle = bg; rr(ctx, bx - 12, by - 8, 24, 18, 3); ctx.fill(); rr(ctx, bx - 4, by - 26, 8, 22, 2); ctx.fill();
    ctx.fillStyle = bg; ctx.beginPath(); ctx.ellipse(bx, by - 28, 11, 6, 0, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(60,40,10,0.6)'; ctx.lineWidth = 1; for (var q = -8; q <= 8; q += 4) { ctx.beginPath(); ctx.moveTo(bx + q, by - 32); ctx.lineTo(bx + q, by - 24); ctx.stroke(); }
    ctx.restore();
  }

  /**
   * A finished sampler: linen disc in a hoop with the motif stitched in its threads. Used for the reveal and the
   * collection plates. Draws inside a circle of radius R.
   */
  function drawSampler(ctx, cx, cy, R, puzzle, palette) {
    // ⛔ 2026-09-23: the motif was scaled to 1.36 R with a dashed square round it and read THIN beside the cover (a
    // ring on bare linen). It now sits at 1.2 R inside a generated stitched WREATH, see drawWreath.
    var n = puzzle.n, P = palette.threads, s = Math.max(3, Math.floor((R * 1.2) / n)), gx = cx - n * s / 2, gy = cy - n * s / 2;
    ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.clip();
    drawLinen(ctx, cx - R, cy - R, R * 2, R * 2, puzzle.seed ^ 0x11);
    drawWreath(ctx, cx, cy, R, puzzle, P, s, gx, gy, wreathFor(puzzle.seed));
    for (var i = 0; i < n * n; i++) if (puzzle.cells[i]) drawStitch(ctx, gx + (i % n) * s, gy + Math.floor(i / n) * s, s, P[puzzle.thread[i] % P.length]);
    var vg = ctx.createRadialGradient(cx, cy, R * 0.6, cx, cy, R); vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(60,40,20,0.22)'); ctx.fillStyle = vg; ctx.fillRect(cx - R, cy - R, R * 2, R * 2);
    ctx.restore();
    drawHoop(ctx, cx, cy, R);
  }

  /**
   * A stitched wreath just inside the hoop, on its own fine grid centred on the hoop (so it keeps the motif's four-fold
   * symmetry): cross-stitches whose centres lie one to two stitches in from the edge, patterned by angle. A wreath
   * stitch that would touch a stitched motif cell (its 3 x 3 neighbourhood) is left out, so the wreath wraps round the
   * motif instead of crossing it. Angular patterns are centred on their segment so a mirror maps the pattern onto
   * itself.
   * @param {string} style one of 'beads', 'garland', 'rope', 'twin'
   * @returns {number} how many wreath stitches were drawn
   */
  function drawWreath(ctx, cx, cy, R, puzzle, P, s, gx, gy, style) {
    var ws = Math.max(3, Math.min(s, Math.round(R * 0.08))), K = Math.ceil(R / ws) + 1, n = puzzle.n, A = P[0], B = P[3 % P.length];
    var N = 8 * Math.max(1, Math.round((TAU * R) / (ws * 5 * 8))), drawn = 0;
    for (var j = -K; j < K; j++) for (var i = -K; i < K; i++) {
      var ccx = (i + 0.5) * ws, ccy = (j + 0.5) * ws, d = Math.sqrt(ccx * ccx + ccy * ccy), band = (R - d) / ws;
      if (band < 0.75 || band > 3.75) continue;
      var ring = band < 1.75 ? 1 : (band < 2.75 ? 2 : 3);
      // keep clear of the motif: any stitched motif cell within one cell of this stitch's centre
      var mx = Math.floor((cx + ccx - gx) / s), my = Math.floor((cy + ccy - gy) / s), near = false;
      for (var yy = my - 1; yy <= my + 1 && !near; yy++) for (var xx = mx - 1; xx <= mx + 1; xx++) if (xx >= 0 && yy >= 0 && xx < n && yy < n && puzzle.cells[yy * n + xx]) { near = true; break; }
      if (near) continue;
      var u = (Math.atan2(ccy, ccx) + Math.PI) / TAU, v = u * N, seg = Math.floor(v + 0.5), f = v + 0.5 - seg, col = null;
      // ⛔ found on the contact sheet: beads spaced by grid PARITY ran solid along the diagonals and read as scatter.
      // Beads are now spaced by ANGLE, one stitch per bead, about 2.2 stitches apart along the ring.
      if (style === 'beads') { if (ring === 1) { var bk = beadAt(u, R - 1.25 * ws, ws, 2.2); if (bk >= 0) col = bk % 2 ? A : B; } else if (ring === 3) col = A; }
      // ⛔ found on the contact sheet: a BROKEN garland (clusters with gaps) read as scattered debris round the motif
      // (Figure_Doctrine §26m), and buds keyed to the segment clumped in pairs. The garland is a continuous vine with
      // evenly spaced buds on its inner side (the bead rule).
      else if (style === 'garland') { if (ring === 1) col = A; else if (ring === 2 && beadAt(u, R - 2.25 * ws, ws, 3.2) >= 0) col = B; }
      else if (style === 'rope') { if (ring === 1) col = Math.floor(v * 2 + 0.5) % 2 ? A : B; }
      else if (ring === 1) col = A; else if (ring === 3) col = B;
      if (col) { drawStitch(ctx, cx + i * ws, cy + j * ws, ws, col); drawn++; }
    }
    return drawn;
  }

  /**
   * Evenly spaced beads round a ring of radius r: returns the bead index if the angle u (0..1) falls within half a
   * stitch of a bead centre, else -1. The bead count is a multiple of 8, so the beads keep the four-fold symmetry.
   */
  function beadAt(u, r, ws, spacing) {
    var arc = TAU * r, M = 8 * Math.max(1, Math.round(arc / (ws * spacing * 8))), bv = u * M + 0.5, bk = Math.floor(bv);
    return Math.abs(bv - bk - 0.5) * arc / M < 0.5 * ws ? bk : -1;
  }

  /** A small engraved plaque with a title and a subtitle. */
  function drawPlaque(ctx, cx, cy, w, title, sub) {
    var h = sub ? 52 : 34, x = cx - w / 2, y = cy - h / 2;
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; rr(ctx, x + 3, y + 4, w, h, 6); ctx.fill();
    var g = ctx.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, '#f6dc94'); g.addColorStop(0.5, '#c99a42'); g.addColorStop(1, '#8a6120');
    ctx.fillStyle = g; rr(ctx, x, y, w, h, 6); ctx.fill(); ctx.strokeStyle = 'rgba(60,40,10,0.7)'; ctx.lineWidth = 1; rr(ctx, x + 3, y + 3, w - 6, h - 6, 4); ctx.stroke();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    var size = 18; ctx.font = 'bold ' + size + 'px ' + FACE; while (size > 11 && ctx.measureText(title).width > w - 20) { size--; ctx.font = 'bold ' + size + 'px ' + FACE; }
    ctx.fillStyle = 'rgba(255,245,210,0.6)'; ctx.fillText(title, cx, (sub ? cy - 9 : cy) + 1); ctx.fillStyle = '#3a2408'; ctx.fillText(title, cx, sub ? cy - 9 : cy);
    if (sub) { ctx.font = 'italic 12px ' + FACE; ctx.fillStyle = '#4a3010'; ctx.fillText(sub, cx, cy + 13); }
  }

  /** The side card: pattern name, size, threads and progress. */
  function drawCard(ctx, w, h, info) {
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; rr(ctx, 4, 6, w - 8, h - 8, 6); ctx.fill();
    var g = ctx.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#fbf5e6'); g.addColorStop(1, '#eee2c6'); ctx.fillStyle = g; rr(ctx, 0, 0, w - 8, h - 10, 6); ctx.fill();
    ctx.strokeStyle = '#8a2f3f'; ctx.lineWidth = 1.5; rr(ctx, 6, 6, w - 20, h - 22, 4); ctx.stroke();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#8a2f3f'; ctx.font = 'bold 12px ' + FACE; ctx.fillText('PATTERN CARD', (w - 8) / 2, 24);
    var size = 20; ctx.font = 'bold ' + size + 'px ' + FACE; while (size > 12 && ctx.measureText(info.title).width > w - 36) { size--; ctx.font = 'bold ' + size + 'px ' + FACE; }
    ctx.fillStyle = INK; ctx.fillText(info.title, (w - 8) / 2, 50);
    ctx.font = 'italic 13px ' + FACE; ctx.fillStyle = '#5a4430'; ctx.fillText(info.sub, (w - 8) / 2, 72);
    // thread swatches: short skeins in each colour
    var th = info.threads, sw = Math.min(40, (w - 50) / th.length);
    for (var i = 0; i < th.length; i++) { var sx = (w - 8) / 2 - (th.length * sw) / 2 + i * sw + sw / 2; ctx.strokeStyle = th[i]; ctx.lineWidth = 5; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(sx - 12, 100); ctx.quadraticCurveTo(sx, 88, sx + 12, 100); ctx.stroke(); ctx.lineCap = 'butt'; }
    ctx.font = 'italic 12px ' + FACE; ctx.fillStyle = '#5a4430'; ctx.fillText(info.paletteName + ' threads', (w - 8) / 2, 118);
    // progress: lines complete
    ctx.font = 'bold 15px ' + FACE; ctx.fillStyle = INK; ctx.fillText(info.progress, (w - 8) / 2, 146);
    ctx.font = 'italic 12px ' + FACE; ctx.fillStyle = '#5a4430'; ctx.fillText(info.givens, (w - 8) / 2, 166);
  }

  function drawStatus(ctx, W, H, text) {
    ctx.clearRect(0, 0, W, H);
    var size = 17; ctx.font = 'italic ' + size + 'px ' + FACE; while (size > 11 && ctx.measureText(text).width > W - 10) { size--; ctx.font = 'italic ' + size + 'px ' + FACE; }
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillText(text, W / 2 + 1, H / 2 + 1); ctx.fillStyle = '#f1dfb4'; ctx.fillText(text, W / 2, H / 2);
  }

  /** The cursor: a gilt needle-frame around one cell. */
  function drawCursor(ctx, s) {
    ctx.clearRect(0, 0, s + 8, s + 8);
    ctx.strokeStyle = 'rgba(0,0,0,0.45)'; ctx.lineWidth = 3; ctx.strokeRect(3.5, 4.5, s, s);
    ctx.strokeStyle = '#e8b64a'; ctx.lineWidth = 2.2; ctx.strokeRect(3, 3, s + 1, s + 1);
    ctx.fillStyle = '#fff2c4'; [[3, 3], [s + 4, 3], [3, s + 4], [s + 4, s + 4]].forEach(function (p) { ctx.beginPath(); ctx.arc(p[0], p[1], 2.2, 0, TAU); ctx.fill(); });
  }

  return {
    VERSION: '1.0.0', FACE: FACE, LINEN: LINEN, TACK: TACK, INK: INK, WREATHS: WREATHS, shade: shade, luma: luma, workThreads: workThreads, wreathFor: wreathFor,
    drawTable: drawTable, drawWreath: drawWreath, drawSpool: drawSpool, drawLinen: drawLinen, drawStitch: drawStitch, drawMark: drawMark, drawGrid: drawGrid,
    drawClues: drawClues, drawHoop: drawHoop, drawSampler: drawSampler, drawPlaque: drawPlaque, drawCard: drawCard, drawStatus: drawStatus, drawCursor: drawCursor,
  };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = SamplerDraw;
