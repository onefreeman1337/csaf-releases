//=============================================================================
// SamplerCore.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Sampler core - generated nonogram (picross) puzzles,
 * a line-logic solver and the stitch colours. Place ABOVE SamplerDraw and Sampler.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The puzzle generator and solver for Sampler. No parameters or commands of
 * its own; Sampler.js is the file you configure. Must be installed and listed
 * above Sampler.js.
 *
 * Pure logic: nothing here touches the screen and nothing uses Math.random.
 * Every puzzle is PROVEN solvable by line logic alone before the player sees
 * it: the solver runs on the clues, and where the clues alone leave cells
 * undecided a few stitches are given (drawn in from the start) until the
 * solver completes the whole grid.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var SamplerCore = (function () {
  'use strict';

  var SIZES = [5, 10, 15];
  // Thread palettes: [linen, ink for clues, thread 1..4]. Chosen so every thread reads on the linen.
  var PALETTES = {
    scarlet: { name: 'Scarlet and Gold', threads: ['#b3212e', '#d9a52b', '#6e1420', '#2f5d3a'] },
    indigo: { name: 'Indigo', threads: ['#27407d', '#5f86c9', '#15204a', '#b3212e'] },
    forest: { name: 'Forest', threads: ['#2f6b3a', '#7da849', '#1d3f22', '#c4702a'] },
    rose: { name: 'Rose Garden', threads: ['#b24a72', '#e58fae', '#6b2442', '#3f7a52'] },
    harvest: { name: 'Harvest', threads: ['#b8611d', '#e0a33a', '#6e3510', '#7a2d1d'] },
    midnight: { name: 'Midnight', threads: ['#1f2a44', '#4b6fa8', '#c9a13a', '#8a2f3f'] },
  };
  var PALETTE_IDS = Object.keys(PALETTES);
  // ⛔ 'flower' was CUT 2026-09-23 after two passes on the contact sheet: it stitched a solid square, then a square
  // frame with corner ticks, never a flower (Icon_Doctrine §22a-5: cutting is correct; four that read beat five).
  var FORMS = ['star', 'medallion', 'lattice', 'diamond'];

  function hashString(s) { var h = 0x811c9dc5; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h >>> 0; }
  function rng(seed) {
    var a = seed >>> 0;
    return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function pick(r, a) { return a[Math.floor(r() * a.length) % a.length]; }

  //===========================================================================
  // Motifs. ⛔ Icon_Doctrine §22a: a pattern symmetric about ONE vertical axis
  // reads as a face (spectacles, an emoticon, a skull). Every generated motif is
  // FOUR-FOLD symmetric (both axes and both diagonals), the symmetry of sampler
  // ornament, so it reads as a star, a medallion or a lattice rather than a face.
  //===========================================================================

  /**
   * A generated motif: a filled/empty grid plus a thread index (0..3) for every filled cell.
   * @param {number} seed
   * @param {number} n grid size
   * @param {string} [form] one of FORMS
   * @returns {{n:number, form:string, cells:number[], thread:number[]}}
   */
  function motif(seed, n, form) {
    var r = rng(seed >>> 0), f = FORMS.indexOf(form) >= 0 ? form : pick(r, FORMS);
    var c = (n - 1) / 2, cells = [], thread = [], i, x, y;
    for (i = 0; i < n * n; i++) { cells.push(0); thread.push(0); }
    // one octant decides the rest: a cell (x, y) with x >= y in the quarter nearest the centre
    var bands = 2 + Math.floor(r() * 2), keep = {};
    // ⛔ MEASURED 2026-09-23 (_probe/distinct.js, 300 seeds): 'star' emitted ONE chart per size and 'diamond' 1/3/8,
    // because their rules drew almost nothing at random. Each motif now draws its STRUCTURE once (arm width and
    // length, diagonals, a ring, band positions, studs), so seeds differ in shape, not only in thread colour.
    var P = { armW: r() < 0.5 ? 0.9 : 1.6, diag: r() < 0.6, armL: 0.62 + r() * 0.38, core: 0.12 + r() * 0.33, ring: r() < 0.55 ? 0.42 + r() * 0.42 : -1,
      ringW: 0.45 + r() * 0.45, tip: r() < 0.5, hollow: r() < 0.5, studs: r() < 0.5, b1: 0.35 + r() * 0.25, b2: 0.7 + r() * 0.3, bw: 0.45 + r() * 0.5, outer: 0.78 + r() * 0.17, inner: 0.25 + r() * 0.25 };
    for (y = 0; y <= Math.floor(c); y++) for (x = y; x <= Math.floor(c); x++) {
      var dx = c - x, dy = c - y, d = Math.max(dx, dy), dm = dx + dy, rr = Math.sqrt(dx * dx + dy * dy), on;
      if (f === 'star') on = (Math.min(dx, dy) < P.armW && rr <= c * P.armL + 0.3) || (P.diag && Math.abs(dx - dy) < 0.8 && rr <= c * P.armL * 0.95 + 0.3) || rr < c * P.core + 0.2
        || (P.ring > 0 && Math.abs(rr - c * P.ring) < P.ringW * 0.8) || (P.tip && Math.abs(Math.max(dx, dy) - c * P.armL) < 0.8 && Math.min(dx, dy) < 1.8);
      else if (f === 'medallion') on = (Math.abs(rr - c * P.outer) < 0.75) || (rr < c * P.inner + 0.2 && (!P.hollow || rr > c * P.inner * 0.5)) || (P.ring > 0 && Math.abs(rr - c * (P.inner + P.outer) / 2) < P.ringW * 0.7 && r() < 0.85)
        || (P.diag && Math.abs(dx - dy) < 0.7 && rr > c * P.inner && rr < c * P.outer);
      else if (f === 'lattice') on = ((Math.round(dx) + Math.round(dy)) % 2 === 0 && r() < 0.9) || d >= c - 0.5;
      else on = (Math.abs(dm - c * P.b2) < P.bw + 0.3) || (Math.abs(dm - c * P.b1) < P.bw) || (!P.hollow && dm <= c * 0.22 + 0.3)
        || (P.studs && Math.min(dx, dy) < 0.8 && Math.abs(Math.max(dx, dy) - c * (P.b2 + 0.28)) < 0.8) || (P.diag && Math.abs(dx - dy) < 0.7 && dm > c * P.b1 && dm < c * P.b2);
      // ⛔ a random scatter of single "seed" stitches was removed 2026-09-23: on the contact sheet the lone stitches
      // read as mistakes and noise round every motif (Figure_Doctrine §26m). Variety comes from each rule's own draws.
      keep[x + ',' + y] = on ? 1 + Math.min(bands, Math.floor((d / (c + 0.01)) * (bands + 1))) % (bands + 1) : 0;
    }
    for (y = 0; y < n; y++) for (x = 0; x < n; x++) {
      // fold (x, y) into the octant: reflect into the top-left quarter, then onto x >= y
      var fx = x > c ? n - 1 - x : x, fy = y > c ? n - 1 - y : y;
      if (fx < fy) { var t = fx; fx = fy; fy = t; }
      var v = keep[fx + ',' + fy] || 0;
      cells[y * n + x] = v ? 1 : 0; thread[y * n + x] = v ? (v - 1) % 4 : 0;
    }
    return { n: n, form: f, cells: cells, thread: thread };
  }

  /**
   * A motif from an icon's pixels: RGBA of a size x size image (the caller reads it ONCE, off the play path).
   * A cell is filled where most of its pixels are opaque; its thread is the nearest palette thread to their mean.
   */
  function fromPixels(rgba, size, n, palette) {
    var cells = [], thread = [], P = PALETTES[palette] || PALETTES.scarlet, step = size / n, x, y;
    var th = P.threads.map(hexRgb);
    for (y = 0; y < n; y++) for (x = 0; x < n; x++) {
      var op = 0, tot = 0, sr = 0, sg = 0, sb = 0;
      for (var py = Math.floor(y * step); py < Math.floor((y + 1) * step); py++) for (var px = Math.floor(x * step); px < Math.floor((x + 1) * step); px++) {
        var k = (py * size + px) * 4; tot++;
        if (rgba[k + 3] > 127) { op++; sr += rgba[k]; sg += rgba[k + 1]; sb += rgba[k + 2]; }
      }
      var on = tot > 0 && op * 2 > tot; cells.push(on ? 1 : 0);
      var best = 0, bd = 1e9;
      if (on) for (var t = 0; t < th.length; t++) { var dr = sr / op - th[t][0], dg = sg / op - th[t][1], db = sb / op - th[t][2], dd = dr * dr + dg * dg + db * db; if (dd < bd) { bd = dd; best = t; } }
      thread.push(best);
    }
    return { n: n, form: 'icon', cells: cells, thread: thread };
  }
  function hexRgb(h) { var v = parseInt(String(h).slice(1), 16); return isFinite(v) ? [(v >> 16) & 255, (v >> 8) & 255, v & 255] : [0, 0, 0]; }

  //===========================================================================
  // Clues and the line solver
  //===========================================================================

  /** Run lengths of filled cells in a line. An empty line has the clue [0]. */
  function runs(line) { var out = [], k = 0; for (var i = 0; i < line.length; i++) { if (line[i] === 1) k++; else if (k) { out.push(k); k = 0; } } if (k) out.push(k); return out.length ? out : [0]; }

  /** Row and column clues of a motif. */
  function clues(m) {
    var n = m.n, rows = [], cols = [], x, y;
    for (y = 0; y < n; y++) { var row = []; for (x = 0; x < n; x++) row.push(m.cells[y * n + x]); rows.push(runs(row)); }
    for (x = 0; x < n; x++) { var col = []; for (y = 0; y < n; y++) col.push(m.cells[y * n + x]); cols.push(runs(col)); }
    return { rows: rows, cols: cols };
  }

  /**
   * One line of line logic: given a clue and the line's known cells (-1 unknown, 0 empty, 1 filled), return the
   * cells every arrangement agrees on (as a new array), or null if no arrangement fits.
   */
  function solveLine(clue, known) {
    var L = known.length, blocks = clue.length === 1 && clue[0] === 0 ? [] : clue, k = blocks.length, memo = {};
    function possible(i, j) {
      var key = i * 64 + j; if (key in memo) return memo[key];
      var ok = false, c;
      if (j === k) { ok = true; for (c = i; c < L; c++) if (known[c] === 1) { ok = false; break; } }
      else if (i < L) {
        if (known[i] !== 1 && possible(i + 1, j)) ok = true;
        if (!ok) ok = canPut(i, j) && (i + blocks[j] === L ? j + 1 === k : possible(i + blocks[j] + 1, j + 1));
      }
      memo[key] = ok; return ok;
    }
    function canPut(i, j) { var len = blocks[j]; if (i + len > L) return false; for (var c = i; c < i + len; c++) if (known[c] === 0) return false; return !(i + len < L && known[i + len] === 1); }
    if (!possible(0, 0)) return null;
    var canFill = [], canEmpty = [], seen = {}, stack = [[0, 0]], c;
    for (c = 0; c < L; c++) { canFill.push(false); canEmpty.push(false); }
    while (stack.length) {
      var s = stack.pop(), i = s[0], j = s[1], key = i * 64 + j;
      if (seen[key]) continue; seen[key] = true;
      if (j === k) { for (c = i; c < L; c++) canEmpty[c] = true; continue; }
      if (i >= L) continue;
      if (known[i] !== 1 && possible(i + 1, j)) { canEmpty[i] = true; stack.push([i + 1, j]); }
      if (canPut(i, j)) {
        var end = i + blocks[j];
        if (end === L ? j + 1 === k : possible(end + 1, j + 1)) {
          for (c = i; c < end; c++) canFill[c] = true;
          if (end < L) { canEmpty[end] = true; stack.push([end + 1, j + 1]); } else stack.push([end, j + 1]);
        }
      }
    }
    var out = [];
    for (c = 0; c < L; c++) out.push(canFill[c] && !canEmpty[c] ? 1 : (canEmpty[c] && !canFill[c] ? 0 : -1));
    return out;
  }

  /**
   * Solve by line logic from the clues and any given cells. @returns {{grid:number[], solved:boolean, sweeps:number}}
   */
  function lineSolve(n, cl, givens) {
    var g = [], i, x, y, changed = true, sweeps = 0;
    for (i = 0; i < n * n; i++) g.push(-1);
    if (givens) for (i = 0; i < givens.length; i++) g[givens[i].i] = givens[i].v;
    while (changed && sweeps < 200) {
      changed = false; sweeps++;
      for (y = 0; y < n; y++) {
        var row = g.slice(y * n, y * n + n), sr = solveLine(cl.rows[y], row);
        if (!sr) return { grid: g, solved: false, sweeps: sweeps, contradiction: true };
        for (x = 0; x < n; x++) if (row[x] === -1 && sr[x] !== -1) { g[y * n + x] = sr[x]; changed = true; }
      }
      for (x = 0; x < n; x++) {
        var col = []; for (y = 0; y < n; y++) col.push(g[y * n + x]);
        var sc = solveLine(cl.cols[x], col);
        if (!sc) return { grid: g, solved: false, sweeps: sweeps, contradiction: true };
        for (y = 0; y < n; y++) if (col[y] === -1 && sc[y] !== -1) { g[y * n + x] = sc[y]; changed = true; }
      }
    }
    return { grid: g, solved: g.indexOf(-1) < 0, sweeps: sweeps };
  }

  /**
   * Make a puzzle: a motif, its clues, and the smallest run of given stitches (chosen deterministically, filled
   * cells first) after which line logic alone completes the grid. So every puzzle has exactly one answer and
   * needs no guessing.
   * @param {Object} opt {seed, size?: 5|10|15, form?, palette?, motif?: a ready motif (from an icon)}
   */
  function generate(opt) {
    opt = opt || {};
    var seed = Number(opt.seed) >>> 0, r = rng(seed ^ 0x5A3), n = SIZES.indexOf(Number(opt.size)) >= 0 ? Number(opt.size) : pick(r, SIZES);
    var palette = PALETTE_IDS.indexOf(opt.palette) >= 0 ? opt.palette : pick(r, PALETTE_IDS);
    var given = opt.motif && opt.motif.n ? opt.motif : null;
    if (given) return build(given, seed, palette);
    // ⛔ MEASURED 2026-09-23 (_probe/gen_probe.js): some 15x15 lattices needed 48 given stitches (21% of the grid).
    // A motif is redrawn from the same stream while its fill is outside 30-72% or its puzzle needs more than 8% given.
    // ⛔ found on the contact sheet: when every try missed the fill range the fallback shipped a 13%-fill motif.
    // The range now widens only after 40 tries, and the widened range still has a floor.
    var best = null;
    for (var tries = 0; tries < 60; tries++) {
      var m = motif(seed + tries * 7919, n, opt.form), f = fill(m), lo = tries < 40 ? 0.3 : 0.22, hi = tries < 40 ? 0.72 : 0.8;
      if (f < lo || f > hi) continue;
      var p = build(m, seed, palette);
      if (!best || p.givens.length < best.givens.length) best = p;
      if (p.givens.length <= Math.floor(0.08 * n * n)) return p;
    }
    return best || build(motif(seed, n, opt.form), seed, palette);
  }

  function build(m, seed, palette) {
    var n = m.n;
    var cl = clues(m), givens = [], res = lineSolve(n, cl, givens), order = [];
    for (var i = 0; i < n * n; i++) order.push(i);
    // deterministic order for givens: filled cells nearest the centre first (a given reads as a stitch already in)
    var c = (n - 1) / 2;
    order.sort(function (a, b) { var fa = m.cells[a] ? 0 : 1, fb = m.cells[b] ? 0 : 1; if (fa !== fb) return fa - fb; var da = Math.abs(a % n - c) + Math.abs(Math.floor(a / n) - c), db = Math.abs(b % n - c) + Math.abs(Math.floor(b / n) - c); return da - db || a - b; });
    var guard = 0;
    while (!res.solved && guard++ < n * n) {
      var next = -1; for (var o = 0; o < order.length; o++) if (res.grid[order[o]] === -1) { next = order[o]; break; }
      if (next < 0) break;
      givens.push({ i: next, v: m.cells[next] }); res = lineSolve(n, cl, givens);
    }
    return { v: 1, seed: seed, n: n, form: m.form, palette: palette, cells: m.cells.slice(), thread: m.thread.slice(), clues: cl, givens: givens, solvable: res.solved, sweeps: res.sweeps, fill: Math.round(fill(m) * 1000) / 1000 };
  }
  function fill(m) { var k = 0; for (var i = 0; i < m.cells.length; i++) k += m.cells[i]; return k / m.cells.length; }

  /** Does a player's grid (1 = stitched) satisfy every clue? (The answer is unique, so this is "solved".) */
  function isSolved(p, grid) {
    for (var i = 0; i < p.n * p.n; i++) if ((grid[i] === 1 ? 1 : 0) !== p.cells[i]) return false;
    return true;
  }

  /** Does one line of the player's grid match its clue? (For ticking a clue off as the player works.) */
  function lineDone(clue, line) { var r = runs(line.map(function (v) { return v === 1 ? 1 : 0; })); return r.length === clue.length && r.every(function (v, i) { return v === clue[i]; }); }

  return {
    VERSION: '1.0.0', SIZES: SIZES, PALETTES: PALETTES, PALETTE_IDS: PALETTE_IDS, FORMS: FORMS,
    hashString: hashString, rng: rng, motif: motif, fromPixels: fromPixels, runs: runs, clues: clues, solveLine: solveLine,
    lineSolve: lineSolve, generate: generate, isSolved: isSolved, lineDone: lineDone, fill: fill, hexRgb: hexRgb,
  };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = SamplerCore;
