//=============================================================================
// Sampler.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Sampler - generated nonogram (picross) puzzles, solved
 * stitch by stitch and finished as a cross-stitch sampler in an embroidery hoop.
 * Place BELOW SamplerCore and SamplerDraw.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * Sampler
 * ============================================================================
 *
 * Picross for your game. The player fills a chart from the number clues
 * along its rows and columns: each number is a run of stitches, in order.
 * When the chart is right, the stitches take their colours and the finished
 * piece is set in an embroidery hoop as a cross-stitch sampler.
 *
 * Every puzzle is GENERATED from a seed: the motif (a star, medallion,
 * lattice or diamond ornament, four-fold symmetric like real sampler
 * work), its thread colours and the chart size (5, 10 or 15 stitches). You
 * can also turn any icon in your own IconSet into a puzzle.
 *
 * EVERY PUZZLE IS PROVEN FAIR. Before the player sees it, a line-logic solver
 * works it from the clues. Where the clues alone leave cells undecided, a few
 * stitches are given (sewn in from the start) until the solver completes the
 * whole chart. So every puzzle has exactly one answer and never needs a
 * guess. Generated motifs are redrawn until no more than 8% of the chart
 * would need to be given.
 *
 * ----------------------------------------------------------------------------
 * INSTALLING
 * ----------------------------------------------------------------------------
 * Plugin Manager order, top to bottom:
 *
 *     SamplerCore.js     (the generator and the solver)
 *     SamplerDraw.js     (the drawing)
 *     Sampler.js         (this file: parameters, the command, the scene)
 *
 * ----------------------------------------------------------------------------
 * USING IT
 * ----------------------------------------------------------------------------
 * Add the plugin command "Open Sampler" to an event. Choose the chart size,
 * the motif form, the threads, an optional icon, and a switch and a variable
 * to set when it is finished. The event waits while the player works.
 *
 * Leave the seed blank and the puzzle is keyed to its map and event, so it
 * is the same puzzle every visit, and the stitches the player has already
 * made are kept when they leave and come back.
 *
 * ----------------------------------------------------------------------------
 * CONTROLS
 * ----------------------------------------------------------------------------
 * Arrow keys move the needle. OK stitches (or unpicks) a cell. Shift marks a
 * cell as empty. Escape leaves (the work is kept).
 * Mouse and touch: click to stitch, drag to stitch a line; right-click marks
 * a cell empty (right-click outside the chart leaves).
 *
 * ----------------------------------------------------------------------------
 * COMPATIBILITY
 * ----------------------------------------------------------------------------
 * Sampler adds its own scene and replaces nothing. It extends one engine
 * method (Game_System.initialize) to create its save record, calling the
 * original first.
 *
 * ============================================================================
 * TERMS OF USE
 * ============================================================================
 * Commercial and non-commercial use permitted in RPG Maker projects, credit
 * appreciated but not required. Do not redistribute the source as an asset
 * pack. Every line of this plugin was written with AI assistance.
 *
 * ============================================================================
 *
 * @param stitchSe
 * @text Sound: a stitch
 * @type file
 * @dir audio/se
 * @default Cursor1
 *
 * @param markSe
 * @text Sound: a cell marked empty
 * @type file
 * @dir audio/se
 * @default Cursor2
 *
 * @param finishSe
 * @text Sound: the sampler finished
 * @type file
 * @dir audio/se
 * @default Item3
 *
 * @command open
 * @text Open Sampler
 * @desc Open a picross chart. The event waits until the player finishes or leaves.
 *
 * @arg size
 * @text Chart size
 * @type select
 * @option auto
 * @option 5
 * @option 10
 * @option 15
 * @default 10
 *
 * @arg form
 * @text Motif form
 * @type select
 * @option auto
 * @option star
 * @option medallion
 * @option lattice
 * @option diamond
 * @default auto
 *
 * @arg palette
 * @text Threads
 * @type select
 * @option auto
 * @option scarlet
 * @option indigo
 * @option forest
 * @option rose
 * @option harvest
 * @option midnight
 * @default auto
 *
 * @arg iconIndex
 * @text Icon (optional)
 * @type icon
 * @desc 0 = a generated motif. Otherwise the chart is this icon from your IconSet.
 * @default 0
 *
 * @arg switchId
 * @text Switch: on when finished
 * @type switch
 * @default 0
 *
 * @arg variableId
 * @text Variable: 1 finished, 0 left unfinished
 * @type variable
 * @default 0
 *
 * @arg title
 * @text Title
 * @desc Shown on the pattern card and the plaque. Blank = named after the motif.
 * @default
 *
 * @arg seed
 * @text Seed (optional)
 * @desc Blank = keyed to this map and event.
 * @default
 */

var Sampler = Sampler || {};

(function (M) {
  'use strict';
  var NAME = 'Sampler', SCHEMA = 1;
  var raw = (typeof PluginManager !== 'undefined') ? PluginManager.parameters(NAME) : {};
  function num(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; var n = Number(v); return isFinite(n) ? n : d; }
  function str(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; return String(v).trim(); }
  M.params = { stitchSe: str(raw.stitchSe, 'Cursor1'), markSe: str(raw.markSe, 'Cursor2'), finishSe: str(raw.finishSe, 'Item3') };

  var _deps = null;
  function deps() {
    if (_deps) return _deps;
    var core = (typeof SamplerCore !== 'undefined') ? SamplerCore : null, draw = (typeof SamplerDraw !== 'undefined') ? SamplerDraw : null;
    if (!core || !draw) { if (!deps._w) { deps._w = true; console.error('Sampler: SamplerCore.js and SamplerDraw.js must both be installed and listed ABOVE Sampler.js.'); } return null; }
    _deps = { core: core, draw: draw }; return _deps;
  }
  M.deps = deps;

  function fresh() { return { v: SCHEMA, charts: {} }; }
  function store() {
    if (typeof $gameSystem === 'undefined' || !$gameSystem) return fresh();
    var s = $gameSystem._csafSampler; if (!s || s.v == null) { s = fresh(); $gameSystem._csafSampler = s; }
    if (!s.charts) s.charts = {}; return s;
  }
  M.store = store;
  M.keyFor = function (mapId, eventId) { return 'm' + Number(mapId) + 'e' + Number(eventId); };
  /** @returns {{done:boolean, work:string}} a chart's record: finished or not, and the player's stitches so far */
  M.record = function (key) { var r = store().charts[String(key)]; if (!r) { r = { done: false, work: '' }; store().charts[String(key)] = r; } return r; };
  /** How many charts the player has finished. */
  M.finishedCount = function () { var c = store().charts, k = 0; for (var id in c) if (c[id] && c[id].done) k++; return k; };

  var _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () { _Game_System_initialize.call(this); this._csafSampler = fresh(); };

  var FORM_NAMES = { star: 'Star', medallion: 'Medallion', lattice: 'Lattice', flower: 'Flower', diamond: 'Diamond', icon: 'Emblem' };

  /** Read an icon's 32x32 pixels ONCE, off the play path (Probe_Doctrine §27a). Returns null if the sheet is not loaded. */
  M.iconPixels = function (index) {
    if (typeof ImageManager === 'undefined') return null;
    var sheet = ImageManager.loadSystem('IconSet'); if (!sheet || !sheet.isReady()) return null;
    var pw = ImageManager.iconWidth || 32, ph = ImageManager.iconHeight || 32, sx = (index % 16) * pw, sy = Math.floor(index / 16) * ph;
    var c = document.createElement('canvas'); c.width = pw; c.height = ph; var x = c.getContext('2d');
    x.drawImage(sheet._image || sheet._canvas, sx, sy, pw, ph, 0, 0, pw, ph);
    return { rgba: x.getImageData(0, 0, pw, ph).data, size: pw };
  };

  /** Build a request (and its puzzle) from command arguments. Returns null if the sibling plugins are missing. */
  M.request = function (args, key, mapId, eventId) {
    var d = deps(); if (!d) return null; args = args || {};
    var seedText = str(args.seed, '');
    var seed = seedText === '' ? d.core.hashString(key) : (/^\d+$/.test(seedText) ? (Number(seedText) >>> 0) : d.core.hashString(seedText));
    var size = str(args.size, '10'), form = str(args.form, 'auto'), palette = str(args.palette, 'auto'), icon = Math.max(0, Math.floor(num(args.iconIndex, 0)));
    var opt = { seed: seed, size: size === 'auto' ? null : Number(size), form: form === 'auto' ? null : form, palette: palette === 'auto' ? null : palette };
    if (icon > 0) {
      var px = M.iconPixels(icon), n = [5, 10, 15].indexOf(Number(size)) >= 0 ? Number(size) : 10;
      var pal = d.core.PALETTE_IDS.indexOf(opt.palette) >= 0 ? opt.palette : d.core.PALETTE_IDS[seed % d.core.PALETTE_IDS.length];
      if (px) { opt.motif = d.core.fromPixels(px.rgba, px.size, n, pal); opt.palette = pal; }
    }
    var puzzle = d.core.generate(opt);
    return { key: key, puzzle: puzzle, switchId: Math.max(0, Math.floor(num(args.switchId, 0))), variableId: Math.max(0, Math.floor(num(args.variableId, 0))),
      title: str(args.title, 'The ' + d.core.PALETTES[puzzle.palette].name + ' ' + FORM_NAMES[puzzle.form]), mapId: mapId, eventId: eventId };
  };

  M.open = function (req) { if (!req) return false; SceneManager.push(Scene_Sampler); SceneManager.prepareNextScene(req); return true; };

  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
    PluginManager.registerCommand(NAME, 'open', function (args) {
      var mapId = this._mapId || ($gameMap ? $gameMap.mapId() : 0), eventId = this.eventId ? this.eventId() : 0;
      var seedText = str(args.seed, ''), key = seedText === '' ? M.keyFor(mapId, eventId) : 's' + seedText;
      if (Number(args.iconIndex) > 0) ImageManager.loadSystem('IconSet');
      M.open(M.request(args, key, mapId, eventId));
    });
  }
  M.VERSION = '1.0.0'; M.SCHEMA = SCHEMA;
}(Sampler));

//=============================================================================
// Scene_Sampler
//=============================================================================

function Scene_Sampler() { this.initialize.apply(this, arguments); }
Scene_Sampler.prototype = Object.create(Scene_Base.prototype);
Scene_Sampler.prototype.constructor = Scene_Sampler;
Scene_Sampler.AREA = { x: 24, y: 24, w: 520, h: 576 };   // the chart area on the left
Scene_Sampler.CARD = { x: 560, y: 24, w: 240, h: 196 };

Scene_Sampler.prototype.prepare = function (req) { this._req = req; };

Scene_Sampler.prototype.create = function () {
  Scene_Base.prototype.create.call(this);
  var d = Sampler.deps(); this._d = d; var p = this._req.puzzle; this._p = p; this._pal = d.core.PALETTES[p.palette];
  // the chart is worked in the grey tacking thread; givens in the palette thread farthest from it (SamplerDraw.workThreads)
  this._work = d.draw.workThreads(this._pal.threads);
  this._rec = Sampler.record(this._req.key);
  var n = p.n, i;
  // the player's grid: 1 stitched, 2 marked empty, 0 blank; givens are stitched (or marked) and locked
  this._grid = []; this._locked = [];
  for (i = 0; i < n * n; i++) { this._grid.push(0); this._locked.push(false); }
  for (i = 0; i < p.givens.length; i++) { var g = p.givens[i]; this._grid[g.i] = g.v ? 1 : 2; this._locked[g.i] = true; }
  if (this._rec.work && this._rec.work.length === n * n) for (i = 0; i < n * n; i++) if (!this._locked[i]) this._grid[i] = Number(this._rec.work[i]) || 0;
  this._cx = Math.floor(n / 2); this._cy = Math.floor(n / 2); this._mode = this._rec.done ? 'done' : 'play'; this._frame = 0; this._drag = null;
  this.layout(); this.createBoard(); this.createUi();
  this._rowDone = []; this._colDone = [];
  for (i = 0; i < n; i++) { this._rowDone.push(false); this._colDone.push(false); }
  this.refreshAll();
  if (this._rec.done) this.showFinished(true);
};
Scene_Sampler.prototype.start = function () { Scene_Base.prototype.start.call(this); this.startFadeIn(this.fadeSpeed(), false); };

/** Cell size and clue margins from the chart size and the longest clue lists. */
Scene_Sampler.prototype.layout = function () {
  var p = this._p, n = p.n, A = Scene_Sampler.AREA, maxRow = 0, maxCol = 0, i;
  for (i = 0; i < n; i++) { maxRow = Math.max(maxRow, p.clues.rows[i].length); maxCol = Math.max(maxCol, p.clues.cols[i].length); }
  var s = Math.floor(Math.min((A.w - 30) / (n + maxRow * 0.95 + 0.6), (A.h - 30) / (n + maxCol * 0.8 + 0.6)));
  s = Math.max(16, Math.min(56, s));
  var fs = Math.max(10, Math.min(18, Math.floor(s * 0.58)));
  var left = Math.ceil(maxRow * (fs * 0.95 + 4) + 22), top = Math.ceil(maxCol * (fs + 3) + 18);
  var gw = left + n * s, gh = top + n * s;
  this._L = { s: s, n: n, left: left, top: top, x: A.x + Math.floor((A.w - gw) / 2) + left, y: A.y + Math.floor((A.h - gh) / 2) + top };
};

Scene_Sampler.prototype.createBoard = function () {
  var d = this._d, W = Graphics.width, H = Graphics.height, L = this._L, p = this._p;
  var table = new Bitmap(W, H), ctx = table.context;
  d.draw.drawTable(ctx, W, H);
  d.draw.drawSpool(ctx, 612, 530, this._pal.threads[0], 1.1); d.draw.drawSpool(ctx, 680, 548, this._pal.threads[1], 1.0); d.draw.drawSpool(ctx, 748, 526, this._pal.threads[2], 0.95);
  // the linen the chart is worked on, with a shadow
  ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.fillRect(L.x - 10 + 4, L.y - 10 + 6, L.n * L.s + 20, L.n * L.s + 20);
  d.draw.drawLinen(ctx, L.x - 10, L.y - 10, L.n * L.s + 20, L.n * L.s + 20, p.seed);
  d.draw.drawGrid(ctx, L.x, L.y, L.n, L.s);
  table._baseTexture.update(); this.addChild(new Sprite(table));
  this._clueSprite = new Sprite(new Bitmap(W, H)); this.addChild(this._clueSprite);
  this._stitches = new Sprite(new Bitmap(L.n * L.s, L.n * L.s)); this._stitches.x = L.x; this._stitches.y = L.y; this.addChild(this._stitches);
  this._cursor = new Sprite(new Bitmap(L.s + 8, L.s + 8)); d.draw.drawCursor(this._cursor.bitmap.context, L.s); this._cursor.bitmap._baseTexture.update(); this.addChild(this._cursor);
};

Scene_Sampler.prototype.createUi = function () {
  var C = Scene_Sampler.CARD;
  this._card = new Sprite(new Bitmap(C.w, C.h)); this._card.x = C.x; this._card.y = C.y; this.addChild(this._card);
  this._hint = new Sprite(new Bitmap(240, 120)); this._hint.x = 560; this._hint.y = 236; this.addChild(this._hint);
  var h = this._hint.bitmap.context; h.font = 'italic 13px ' + this._d.draw.FACE; h.fillStyle = '#c9a878'; h.textAlign = 'center'; h.textBaseline = 'middle';
  ['arrows  move the needle', 'OK  stitch or unpick', 'Shift  mark a cell empty', 'click / drag  stitch    right-click  mark', 'Esc  leave (the work is kept)'].forEach(function (s, i) { h.fillText(s, 120, 14 + i * 22); });
  this._hint.bitmap._baseTexture.update();
  this._status = new Sprite(new Bitmap(240, 40)); this._status.x = 560; this._status.y = 372; this.addChild(this._status);
  this._finished = new Sprite(new Bitmap(Graphics.width, Graphics.height)); this._finished.visible = false; this.addChild(this._finished);
};

Scene_Sampler.prototype.playSe = function (n) { if (n && typeof AudioManager !== 'undefined') AudioManager.playSe({ name: n, volume: 80, pitch: 100, pan: 0 }); };
Scene_Sampler.prototype.line = function (isRow, k) { var n = this._p.n, out = []; for (var i = 0; i < n; i++) out.push(this._grid[isRow ? k * n + i : i * n + k]); return out; };

/** Redraw one cell of the stitch layer (only that cell: the bitmap is not repainted every frame). */
Scene_Sampler.prototype.drawCell = function (i, colour) {
  var L = this._L, ctx = this._stitches.bitmap.context, x = (i % L.n) * L.s, y = Math.floor(i / L.n) * L.s;
  ctx.clearRect(x, y, L.s, L.s);
  var v = this._grid[i];
  if (v === 1) this._d.draw.drawStitch(ctx, x, y, L.s, colour || (this._locked[i] ? this._work.given : this._work.work));
  else if (v === 2) this._d.draw.drawMark(ctx, x, y, L.s);
};

Scene_Sampler.prototype.refreshAll = function () {
  for (var i = 0; i < this._p.n * this._p.n; i++) this.drawCell(i);
  this._stitches.bitmap._baseTexture.update();
  this.refreshLines(true);
  this.placeCursor();
  this.setStatus(this._rec.done ? 'The sampler is finished.' : 'Stitch each row to its numbers.');
};

/** Tick off rows and columns whose stitches match their clue; redraw the clue tape only when that changes. */
Scene_Sampler.prototype.refreshLines = function (force) {
  var p = this._p, changed = !!force, done = 0, k;
  for (k = 0; k < p.n; k++) {
    var r = this._d.core.lineDone(p.clues.rows[k], this.line(true, k)), c = this._d.core.lineDone(p.clues.cols[k], this.line(false, k));
    if (r !== this._rowDone[k] || c !== this._colDone[k]) changed = true;
    this._rowDone[k] = r; this._colDone[k] = c; done += (r ? 1 : 0) + (c ? 1 : 0);
  }
  this._linesDone = done;
  if (changed) {
    var b = this._clueSprite.bitmap; b.context.clearRect(0, 0, b.width, b.height);
    this._d.draw.drawClues(b.context, this._L, p.clues, this._rowDone, this._colDone); b._baseTexture.update();
    this.refreshCard();
  }
};

Scene_Sampler.prototype.refreshCard = function () {
  var p = this._p, b = this._card.bitmap;
  this._d.draw.drawCard(b.context, b.width, b.height, { title: this._req.title, sub: p.n + ' x ' + p.n + ' chart', threads: this._pal.threads, paletteName: this._pal.name,
    progress: this._linesDone + ' of ' + (p.n * 2) + ' lines match', givens: p.givens.length ? p.givens.length + ' stitch' + (p.givens.length > 1 ? 'es' : '') + ' given' : 'no stitches given' });
  b._baseTexture.update();
};

Scene_Sampler.prototype.setStatus = function (t) { if (t === this._statusText) return; this._statusText = t; this._d.draw.drawStatus(this._status.bitmap.context, 240, 40, t); this._status.bitmap._baseTexture.update(); };
Scene_Sampler.prototype.placeCursor = function () { var L = this._L; this._cursor.x = L.x + this._cx * L.s - 4; this._cursor.y = L.y + this._cy * L.s - 4; };

/** Set one cell and redraw it; returns true if it changed. */
Scene_Sampler.prototype.setCell = function (i, v) {
  if (this._locked[i] || this._grid[i] === v) return false;
  this._grid[i] = v; this.drawCell(i); this._stitches.bitmap._baseTexture.update();
  return true;
};

Scene_Sampler.prototype.afterEdit = function (se) {
  this.playSe(se); this.refreshLines(false);
  if (this._d.core.isSolved(this._p, this._grid)) this.finish();
};

//---------------------------------------------------------------------------- per frame

Scene_Sampler.prototype.update = function () {
  Scene_Base.prototype.update.call(this);
  this._frame++;
  if (this._mode === 'play') this.updatePlay();
  else if (this._mode === 'reveal') this.updateReveal();
  else if (this._mode === 'done') { if (Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered() || TouchInput.isCancelled()) this.leave(); }
  else if (this._mode === 'leaving' && !this.isBusy()) { this._mode = 'gone'; this.popScene(); }
  this._cursor.visible = this._mode === 'play';
};

Scene_Sampler.prototype.cellAt = function (x, y) { var L = this._L, cx = Math.floor((x - L.x) / L.s), cy = Math.floor((y - L.y) / L.s); return cx >= 0 && cy >= 0 && cx < L.n && cy < L.n ? cy * L.n + cx : -1; };

Scene_Sampler.prototype.updatePlay = function () {
  var n = this._p.n, moved = false;
  if (Input.isRepeated('left')) { this._cx = (this._cx + n - 1) % n; moved = true; }
  else if (Input.isRepeated('right')) { this._cx = (this._cx + 1) % n; moved = true; }
  else if (Input.isRepeated('up')) { this._cy = (this._cy + n - 1) % n; moved = true; }
  else if (Input.isRepeated('down')) { this._cy = (this._cy + 1) % n; moved = true; }
  if (moved) this.placeCursor();
  var i = this._cy * n + this._cx;
  if (Input.isTriggered('ok')) { if (this.setCell(i, this._grid[i] === 1 ? 0 : 1)) this.afterEdit(Sampler.params.stitchSe); return; }
  if (Input.isTriggered('shift')) { if (this.setCell(i, this._grid[i] === 2 ? 0 : 2)) this.afterEdit(Sampler.params.markSe); return; }
  if (Input.isTriggered('cancel')) { this.leave(); return; }
  // mouse: press starts a drag with the value the first cell takes; moving paints that value
  if (TouchInput.isCancelled()) { var ci = this.cellAt(TouchInput.x, TouchInput.y); if (ci < 0) { this.leave(); return; } this.moveTo(ci); if (this.setCell(ci, this._grid[ci] === 2 ? 0 : 2)) this.afterEdit(Sampler.params.markSe); return; }
  // ⛔ found by the in-engine mouse test: a click pressed and released inside one frame stitched NOTHING, because
  // the drag was cleared (not pressed any more) before its first cell was applied. The press itself stitches.
  if (TouchInput.isTriggered()) {
    var t = this.cellAt(TouchInput.x, TouchInput.y);
    if (t >= 0) { this.moveTo(t); this._drag = { v: this._grid[t] === 1 ? 0 : 1, last: t }; if (this.setCell(t, this._drag.v)) { this.afterEdit(Sampler.params.stitchSe); if (this._mode !== 'play') { this._drag = null; return; } } }
  }
  if (this._drag) {
    if (!TouchInput.isPressed()) { this._drag = null; return; }
    var c = this.cellAt(TouchInput.x, TouchInput.y);
    if (c >= 0 && c !== this._drag.last) { this._drag.last = c; this.moveTo(c); if (this.setCell(c, this._drag.v)) this.afterEdit(Sampler.params.stitchSe); }
  }
};
Scene_Sampler.prototype.moveTo = function (i) { this._cx = i % this._p.n; this._cy = Math.floor(i / this._p.n); this.placeCursor(); };

//---------------------------------------------------------------------------- the reveal

/** The chart is right: record it, set the switch and variable, then stitch the colours in from the centre out. */
Scene_Sampler.prototype.finish = function () {
  var p = this._p, n = p.n, c = (n - 1) / 2, order = [];
  this._rec.done = true; this._rec.work = '';
  if (this._req.switchId > 0 && typeof $gameSwitches !== 'undefined') $gameSwitches.setValue(this._req.switchId, true);
  if (this._req.variableId > 0 && typeof $gameVariables !== 'undefined') $gameVariables.setValue(this._req.variableId, 1);
  for (var i = 0; i < n * n; i++) { if (this._grid[i] === 2) { this._grid[i] = 0; this.drawCell(i); } if (p.cells[i]) order.push(i); }
  order.sort(function (a, b) { return (Math.abs(a % n - c) + Math.abs(Math.floor(a / n) - c)) - (Math.abs(b % n - c) + Math.abs(Math.floor(b / n) - c)) || a - b; });
  this._revealOrder = order; this._revealAt = 0; this._mode = 'reveal'; this._revealFrames = 0;
  this._stitches.bitmap._baseTexture.update();
  this.setStatus('The chart is right. Taking the threads...');
};

Scene_Sampler.prototype.updateReveal = function () {
  var per = Math.max(1, Math.ceil(this._revealOrder.length / 45)), k = 0, P = this._pal.threads;
  while (k++ < per && this._revealAt < this._revealOrder.length) { var i = this._revealOrder[this._revealAt++]; this.drawCell(i, P[this._p.thread[i] % P.length]); }
  if (k > 1) this._stitches.bitmap._baseTexture.update();
  if (this._revealAt >= this._revealOrder.length && ++this._revealFrames > 40) this.showFinished(false);
};

/** The finished sampler in its hoop, with a plaque. */
Scene_Sampler.prototype.showFinished = function (already) {
  var b = this._finished.bitmap, ctx = b.context, W = b.width, H = b.height, d = this._d;
  ctx.clearRect(0, 0, W, H);
  ctx.fillStyle = 'rgba(12,7,4,0.72)'; ctx.fillRect(0, 0, W, H);
  d.draw.drawSampler(ctx, W / 2, H / 2 - 24, 214, this._p, this._pal);
  d.draw.drawPlaque(ctx, W / 2, H / 2 + 238, 360, this._req.title, 'Sampler No. ' + Sampler.finishedCount() + '  ·  ' + this._p.n + ' x ' + this._p.n + '  ·  ' + this._pal.name + ' threads');
  b._baseTexture.update(); this._finished.visible = true;
  // ⛔ found by looking: the reveal's "Taking the threads..." stayed on the status line behind the finished hoop
  this.setStatus('The sampler is finished.');
  if (already && this._req.variableId > 0 && typeof $gameVariables !== 'undefined') $gameVariables.setValue(this._req.variableId, 1);
  if (!already) this.playSe(Sampler.params.finishSe);
  this._mode = 'done';
};

Scene_Sampler.prototype.leave = function () {
  if (this._mode === 'leaving' || this._mode === 'gone') return;
  if (!this._rec.done) {
    var w = ''; for (var i = 0; i < this._grid.length; i++) w += this._locked[i] ? '0' : String(this._grid[i]);
    this._rec.work = w;
    if (this._req.variableId > 0 && typeof $gameVariables !== 'undefined') $gameVariables.setValue(this._req.variableId, 0);
  }
  this._mode = 'leaving'; this.startFadeOut(this.fadeSpeed(), false);
};
