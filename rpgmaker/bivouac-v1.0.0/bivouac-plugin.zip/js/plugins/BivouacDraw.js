//=============================================================================
// BivouacDraw.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Bivouac Draw - the constructions. Turns a Bivouac program into marks on a
 * canvas. No engine calls. Place ABOVE Bivouac.js and BELOW BivouacCore.js.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * BivouacDraw.js
 * ============================================================================
 *
 * Every drawn thing in Bivouac is in this file, and each one has its own
 * construction. There are no recolours: a brazier is not a campfire with a
 * different palette, it is a tripod, a bowl, a bed of coals and a lipped rim.
 *
 * It takes a plain CanvasRenderingContext2D. It never touches the engine, so
 * the whole corpus can be rendered and counted from Node.
 *
 *   BivouacDraw.render(ctx, program, opts)   draw a whole program
 *   BivouacDraw.piece(ctx, key, x, y, s, r)  draw one piece of furniture
 *   BivouacDraw.corpus()                     every key this file can draw
 *
 * ----------------------------------------------------------------------------
 * LIGHT
 * ----------------------------------------------------------------------------
 * One light, fixed, from the upper left. Every solid form gets three things and
 * it is not optional: a lit lip on the side facing the light, a darkened side
 * facing away, and a cast shadow on the ground beside it. A form drawn with a
 * gradient and no cast shadow reads as an airbrushed sticker rather than as an
 * object standing on the earth.
 *
 * ============================================================================
 * TERMS OF USE
 * ============================================================================
 * Commercial and non-commercial use permitted in RPG Maker projects.
 * Do not redistribute the source as an asset pack.
 *
 * @param placeholder
 * @text (no parameters)
 * @desc BivouacDraw has no parameters of its own. Configure Bivouac.js instead.
 * @default
 */

'use strict';

var BivouacDraw = BivouacDraw || {};

(function (D) {
  const Core = (typeof BivouacCore !== 'undefined') ? BivouacCore
    : (typeof require !== 'undefined' ? require('./BivouacCore.js') : null);

  /** The one light. x,y is the direction light TRAVELS, already normalised. */
  D.LIGHT = { x: 0.52, y: 0.85 };

  //===========================================================================
  // Colour
  //===========================================================================

  /** @param {number[]} c rgb @param {number} [a] alpha @returns {string} css */
  function rgb(c, a) {
    const r = Math.round(Core.clamp(c[0], 0, 255));
    const g = Math.round(Core.clamp(c[1], 0, 255));
    const b = Math.round(Core.clamp(c[2], 0, 255));
    return (a == null || a >= 1) ? 'rgb(' + r + ',' + g + ',' + b + ')'
      : 'rgba(' + r + ',' + g + ',' + b + ',' + Core.clamp(a, 0, 1).toFixed(3) + ')';
  }

  /** Move a colour toward another by t. @returns {number[]} */
  function mix(a, b, t) {
    const k = Core.clamp(t, 0, 1);
    return [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k];
  }

  /** Lighten/darken by a signed amount. @returns {number[]} */
  function shade(c, t) {
    return t >= 0 ? mix(c, [255, 252, 238], t) : mix(c, [16, 14, 20], -t);
  }

  D.rgb = rgb; D.mix = mix; D.shade = shade;

  //===========================================================================
  // Materials. A material is a triplet plus a grain, and the grain is what
  // stops two materials of similar value reading as the same substance.
  //===========================================================================

  D.MAT = {
    timber: { base: [104, 78, 50], grain: 'lengthwise', rough: 0.5 },
    darkwood: { base: [72, 54, 38], grain: 'lengthwise', rough: 0.6 },
    stone: { base: [122, 120, 114], grain: 'chip', rough: 0.7 },
    darkstone: { base: [78, 76, 78], grain: 'chip', rough: 0.8 },
    metal: { base: [126, 130, 138], grain: 'sheen', rough: 0.15 },
    rust: { base: [124, 78, 48], grain: 'pit', rough: 0.8 },
    cloth: { base: [126, 54, 48], grain: 'weave', rough: 0.4 },
    palecloth: { base: [176, 160, 132], grain: 'weave', rough: 0.4 },
    bone: { base: [206, 198, 176], grain: 'pit', rough: 0.35 },
    hide: { base: [128, 100, 70], grain: 'pore', rough: 0.55 },
    rope: { base: [152, 132, 92], grain: 'twist', rough: 0.5 },
    ember: { base: [214, 98, 34], grain: 'flicker', rough: 0.3 },
    ice: { base: [176, 200, 214], grain: 'facet', rough: 0.25 },
    fungus: { base: [150, 138, 160], grain: 'spot', rough: 0.45 },
    reed: { base: [158, 150, 96], grain: 'lengthwise', rough: 0.45 },
    gold: { base: [190, 154, 62], grain: 'sheen', rough: 0.2 },
  };

  //===========================================================================
  // Primitives. Everything is built from these, so relief is consistent.
  //===========================================================================

  /**
   * Fill a path with relief: the body, a lit lip toward the light, a dark side
   * away from it. This is the only fill used for a solid form.
   * @param {CanvasRenderingContext2D} c the context
   * @param {function():void} path lays the path down
   * @param {string} matKey a key of D.MAT
   * @param {Object} [o] {lip:number, tint:number[], tintAmt:number, alpha:number}
   */
  function form(c, path, matKey, o) {
    const m = D.MAT[matKey] || D.MAT.stone;
    const op = o || {};
    let base = m.base;
    if (op.tint) base = mix(base, op.tint, Core.clamp(op.tintAmt == null ? 0.25 : op.tintAmt, 0, 1));
    const lip = op.lip == null ? 2.0 : op.lip;

    c.save();
    c.beginPath(); path(c); c.closePath();
    if (op.alpha != null) c.globalAlpha = Core.clamp(op.alpha, 0, 1);
    c.fillStyle = rgb(base);
    c.fill();
    // Dark side: the whole form darkened, clipped, then pushed away from the light.
    c.clip();
    c.fillStyle = rgb(shade(base, -0.34));
    c.beginPath(); path(c); c.closePath();
    c.translate(D.LIGHT.x * lip * 1.9, D.LIGHT.y * lip * 1.9);
    c.fill();
    c.restore();

    // Lit lip: the form offset AGAINST the light, drawn light, clipped to the form.
    c.save();
    c.beginPath(); path(c); c.closePath();
    if (op.alpha != null) c.globalAlpha = Core.clamp(op.alpha, 0, 1);
    c.clip();
    c.globalCompositeOperation = 'source-atop';
    c.fillStyle = rgb(shade(base, 0.30));
    c.beginPath(); path(c); c.closePath();
    c.translate(-D.LIGHT.x * lip, -D.LIGHT.y * lip);
    c.fill();
    // and the body back over the middle, so only the rim stays lit
    c.fillStyle = rgb(base);
    c.beginPath(); path(c); c.closePath();
    c.translate(-D.LIGHT.x * lip * 0.9, -D.LIGHT.y * lip * 0.9);
    c.fill();
    c.restore();
  }

  /**
   * The cast shadow an object throws on the ground it stands on. Never optional.
   * @param {CanvasRenderingContext2D} c the context
   * @param {number} x foot x @param {number} y foot y
   * @param {number} w half-width @param {number} h height of the object
   * @param {number} [strength] 0..1
   */
  function cast(c, x, y, w, h, strength) {
    const s = Core.clamp(strength == null ? 0.42 : strength, 0, 1);
    const cx = x + D.LIGHT.x * h * 0.42;
    const cy = y + 2;
    const rx = Math.max(4, w * (1 + h / 220));
    const ry = Math.max(3, w * 0.30);
    c.save();
    // ⛔ MEASURED DEFECT, FIXED: a single flat ellipse read as a CRATER - a hard
    // black hole punched in the ground, which is what a hard-edged dark shape on
    // a lit surface always looks like. A shadow has no edge: it is drawn as
    // nested falloff rings so the penumbra is real rather than implied.
    const rings = 5;
    for (let i = rings; i >= 1; i--) {
      const t = i / rings;
      c.globalAlpha = s * 0.34 * (1 - t * 0.72);
      c.fillStyle = 'rgba(16,12,20,1)';
      c.beginPath();
      c.ellipse(cx, cy, rx * (0.62 + t * 0.66), ry * (0.62 + t * 0.66), 0, 0, Math.PI * 2);
      c.fill();
    }
    // the contact point, where an object actually touches and the shadow is hard
    c.globalAlpha = s * 0.55;
    c.beginPath();
    c.ellipse(cx - D.LIGHT.x * 2, cy - 1, rx * 0.44, ry * 0.42, 0, 0, Math.PI * 2);
    c.fill();
    c.restore();
  }

  /** A round mass. Ridges are chains of these, never a rotated plate. */
  function mass(c, x, y, rx, ry, matKey, o) {
    form(c, (g) => { g.ellipse(x, y, Math.max(0.6, rx), Math.max(0.6, ry), 0, 0, Math.PI * 2); }, matKey, o);
  }

  /** An upright member: post, pole, trunk, leg. */
  function post(c, x, yTop, yBase, w, matKey, o) {
    const op = o || {};
    const lean = op.lean || 0;
    form(c, (g) => {
      g.moveTo(x - w / 2 + lean, yTop);
      g.lineTo(x + w / 2 + lean, yTop);
      g.lineTo(x + w * 0.62, yBase);
      g.lineTo(x - w * 0.62, yBase);
    }, matKey, op);
  }

  /** An angled member: strut, spar, rafter, bone. */
  function beam(c, x0, y0, x1, y1, w, matKey, o) {
    const dx = x1 - x0, dy = y1 - y0;
    const L = Math.hypot(dx, dy) || 1;
    const nx = -dy / L * w / 2, ny = dx / L * w / 2;
    form(c, (g) => {
      g.moveTo(x0 + nx, y0 + ny); g.lineTo(x1 + nx, y1 + ny);
      g.lineTo(x1 - nx, y1 - ny); g.lineTo(x0 - nx, y0 - ny);
    }, matKey, o);
  }

  /** A hanging or stretched sheet, with a real sag. */
  function sheet(c, x0, y0, x1, y1, drop, sag, matKey, o) {
    form(c, (g) => {
      g.moveTo(x0, y0);
      g.quadraticCurveTo((x0 + x1) / 2, (y0 + y1) / 2 + sag, x1, y1);
      g.lineTo(x1 + 2, y1 + drop);
      g.quadraticCurveTo((x0 + x1) / 2, (y0 + y1) / 2 + drop + sag * 1.25, x0 - 2, y0 + drop);
    }, matKey, o);
  }

  /** A cord, drawn as a catenary. */
  function cord(c, x0, y0, x1, y1, sag, matKey) {
    const m = D.MAT[matKey] || D.MAT.rope;
    c.save();
    c.strokeStyle = rgb(shade(m.base, -0.15));
    c.lineWidth = 1.7; c.lineCap = 'round';
    c.beginPath(); c.moveTo(x0, y0);
    c.quadraticCurveTo((x0 + x1) / 2, (y0 + y1) / 2 + sag, x1, y1);
    c.stroke();
    c.strokeStyle = rgb(shade(m.base, 0.28));
    c.lineWidth = 0.8;
    c.beginPath(); c.moveTo(x0, y0 - 0.7);
    c.quadraticCurveTo((x0 + x1) / 2, (y0 + y1) / 2 + sag - 0.7, x1, y1 - 0.7);
    c.stroke();
    c.restore();
  }

  /**
   * Surface grain. Laid AFTER the pigment, never before, or the pigment buries it.
   * @param {CanvasRenderingContext2D} c the context
   * @param {function():void} path the region
   * @param {string} kind a grain name
   * @param {function():number} r a seeded stream
   * @param {number} amount 0..1
   */
  function grain(c, path, kind, r, amount) {
    const n = Math.round(Core.clamp(amount, 0, 1) * 46);
    if (n <= 0) return;
    c.save();
    c.beginPath(); path(c); c.closePath(); c.clip();
    const box = c.__bbox || { x: 0, y: 0, w: 816, h: 624 };
    for (let i = 0; i < n; i++) {
      const x = box.x + r() * box.w;
      const y = box.y + r() * box.h;
      c.globalAlpha = 0.10 + r() * 0.16;
      c.strokeStyle = r() < 0.5 ? 'rgba(255,248,232,1)' : 'rgba(22,18,14,1)';
      c.fillStyle = c.strokeStyle;
      c.lineWidth = 0.8;
      c.beginPath();
      if (kind === 'lengthwise') { c.moveTo(x, y); c.lineTo(x, y + 5 + r() * 12); c.stroke(); }
      else if (kind === 'weave') { c.moveTo(x, y); c.lineTo(x + 4 + r() * 5, y); c.stroke(); }
      else if (kind === 'sheen') { c.moveTo(x, y); c.lineTo(x + 7 + r() * 9, y - 3 - r() * 4); c.stroke(); }
      else if (kind === 'twist') { c.moveTo(x, y); c.lineTo(x + 3, y - 3); c.lineTo(x + 6, y); c.stroke(); }
      else if (kind === 'chip') { c.ellipse(x, y, 1 + r() * 2.2, 0.8 + r() * 1.4, r() * 3, 0, 6.3); c.fill(); }
      else if (kind === 'facet') { c.moveTo(x, y); c.lineTo(x + 5 + r() * 6, y + 3); c.lineTo(x + 2, y + 7); c.fill(); }
      else { c.ellipse(x, y, 0.7 + r() * 1.5, 0.7 + r() * 1.5, 0, 0, 6.3); c.fill(); }
    }
    c.restore();
  }

  D.form = form; D.cast = cast; D.mass = mass; D.post = post;
  D.beam = beam; D.sheet = sheet; D.cord = cord; D.grain = grain;

  //===========================================================================
  // THE GROUND - ten treatments, each its own construction
  //===========================================================================

  /** Lay the apron polygon as a path. */
  function apronPath(c, outline) {
    c.moveTo(outline[0].x, outline[0].y);
    for (let i = 1; i < outline.length; i++) {
      const p = outline[i];
      const q = outline[(i + 1) % outline.length];
      c.quadraticCurveTo(p.x, p.y, (p.x + q.x) / 2, (p.y + q.y) / 2);
    }
  }
  D.apronPath = apronPath;

  /** @returns {{x:number,y:number,w:number,h:number}} bounds of a polygon */
  function bbox(pts) {
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    for (const p of pts) {
      if (p.x < x0) x0 = p.x; if (p.x > x1) x1 = p.x;
      if (p.y < y0) y0 = p.y; if (p.y > y1) y1 = p.y;
    }
    return { x: x0, y: y0, w: Math.max(1, x1 - x0), h: Math.max(1, y1 - y0) };
  }

  /** The ten ground treatments. Each receives a clipped context and its bbox. */
  D.GROUND_DRAW = {
    trodden: function (c, b, r, col) {
      for (let i = 0; i < 34; i++) {
        const x = b.x + r() * b.w, y = b.y + r() * b.h;
        c.globalAlpha = 0.10 + r() * 0.14;
        c.fillStyle = rgb(shade(col, r() < 0.5 ? -0.28 : 0.20));
        c.beginPath(); c.ellipse(x, y, 7 + r() * 16, 3 + r() * 5, r() * 0.7, 0, 6.3); c.fill();
      }
    },
    hardpan: function (c, b, r, col) {
      c.strokeStyle = rgb(shade(col, -0.42)); c.lineWidth = 1.1;
      for (let i = 0; i < 13; i++) {
        let x = b.x + r() * b.w, y = b.y + r() * b.h;
        c.globalAlpha = 0.30 + r() * 0.25;
        c.beginPath(); c.moveTo(x, y);
        for (let k = 0; k < 4; k++) { x += (r() - 0.5) * 34; y += (r() - 0.5) * 20; c.lineTo(x, y); }
        c.stroke();
      }
    },
    ashbed: function (c, b, r, col) {
      for (let i = 0; i < 44; i++) {
        const x = b.x + r() * b.w, y = b.y + r() * b.h, s = 2 + r() * 6;
        c.globalAlpha = 0.16 + r() * 0.30;
        c.fillStyle = rgb(shade(col, r() < 0.3 ? 0.42 : -0.30));
        c.beginPath();
        c.moveTo(x, y); c.lineTo(x + s, y + s * 0.4); c.lineTo(x + s * 0.5, y + s); c.fill();
      }
    },
    rime: function (c, b, r, col) {
      c.lineCap = 'round';
      for (let i = 0; i < 30; i++) {
        const x = b.x + r() * b.w, y = b.y + r() * b.h, L = 4 + r() * 11;
        c.globalAlpha = 0.24 + r() * 0.34;
        c.strokeStyle = rgb(shade(col, 0.5)); c.lineWidth = 0.9;
        for (let k = 0; k < 3; k++) {
          const a = (k / 3) * Math.PI + r() * 0.4;
          c.beginPath(); c.moveTo(x, y); c.lineTo(x + Math.cos(a) * L, y + Math.sin(a) * L * 0.5); c.stroke();
        }
      }
    },
    mire: function (c, b, r, col) {
      for (let i = 0; i < 26; i++) {
        const x = b.x + r() * b.w, y = b.y + r() * b.h;
        c.globalAlpha = 0.22 + r() * 0.26;
        c.fillStyle = rgb(shade(col, -0.40));
        c.beginPath(); c.ellipse(x, y, 6 + r() * 15, 3 + r() * 6, r() * 1.2, 0, 6.3); c.fill();
        c.globalAlpha = 0.20;
        c.fillStyle = rgb(shade(col, 0.34));
        c.beginPath(); c.ellipse(x - 2, y - 2, 4 + r() * 8, 1.6 + r() * 2.6, 0, 0, 6.3); c.fill();
      }
    },
    scorch: function (c, b, r, col) {
      for (let i = 0; i < 22; i++) {
        const x = b.x + r() * b.w, y = b.y + r() * b.h;
        c.globalAlpha = 0.20 + r() * 0.30;
        c.fillStyle = rgb(shade(col, -0.45));
        c.beginPath(); c.ellipse(x, y, 8 + r() * 18, 4 + r() * 8, 0, 0, 6.3); c.fill();
      }
      for (let i = 0; i < 16; i++) {
        const x = b.x + r() * b.w, y = b.y + r() * b.h;
        c.globalAlpha = 0.28 + r() * 0.34;
        c.fillStyle = rgb([190 + r() * 50, 80 + r() * 60, 30]);
        c.beginPath(); c.ellipse(x, y, 0.9 + r() * 1.8, 0.7 + r() * 1.2, 0, 0, 6.3); c.fill();
      }
    },
    blight: function (c, b, r, col) {
      // ⛔ MEASURED DEFECT, FIXED (wing §21b - "the code ran" and "the picture
      // changed" are different claims): the blotch colour was mix(col, [54,68,40],
      // 0.6), which against a base of [84,88,62] is nearly the SAME VALUE, so the
      // plate rendered featureless at every alpha. Blight is a pallor and a rot
      // together, so the blotches now run BOTH ways from the ground.
      for (let i = 0; i < 26; i++) {
        const x = b.x + r() * b.w, y = b.y + r() * b.h, R = 5 + r() * 13;
        const pale = r() < 0.45;
        c.globalAlpha = 0.22 + r() * 0.26;
        c.fillStyle = rgb(pale ? mix(col, [188, 196, 150], 0.72) : mix(col, [38, 44, 26], 0.74));
        c.beginPath();
        for (let k = 0; k <= 9; k++) {
          const a = (k / 9) * 6.283, rr = R * (0.7 + (k % 2 ? 0.34 : 0));
          const px = x + Math.cos(a) * rr, py = y + Math.sin(a) * rr * 0.55;
          if (k === 0) c.moveTo(px, py); else c.lineTo(px, py);
        }
        c.fill();
      }
    },
    drift: function (c, b, r, col) {
      c.lineWidth = 1.6;
      for (let i = 0; i < 20; i++) {
        const y = b.y + (i / 20) * b.h + (r() - 0.5) * 6;
        c.globalAlpha = 0.14 + r() * 0.18;
        c.strokeStyle = rgb(shade(col, r() < 0.5 ? 0.30 : -0.22));
        c.beginPath();
        c.moveTo(b.x, y);
        for (let x = b.x; x < b.x + b.w; x += 24) c.quadraticCurveTo(x + 12, y - 4 - r() * 4, x + 24, y);
        c.stroke();
      }
    },
    flagstone: function (c, b, r, col) {
      const cell = 46;
      c.lineWidth = 1.5;
      for (let gy = b.y; gy < b.y + b.h + cell; gy += cell) {
        const off = ((gy / cell) | 0) % 2 ? cell / 2 : 0;
        for (let gx = b.x - cell; gx < b.x + b.w + cell; gx += cell) {
          const x = gx + off + (r() - 0.5) * 3, y = gy + (r() - 0.5) * 3;
          c.globalAlpha = 0.30;
          c.fillStyle = rgb(shade(col, (r() - 0.5) * 0.30));
          c.beginPath();
          c.moveTo(x + 2, y); c.lineTo(x + cell - 3, y + 1);
          c.lineTo(x + cell - 2, y + cell - 3); c.lineTo(x + 1, y + cell - 2);
          c.fill();
          c.globalAlpha = 0.34;
          c.strokeStyle = rgb(shade(col, -0.45));
          c.stroke();
        }
      }
    },
    sward: function (c, b, r, col) {
      // ⛔ MEASURED DEFECT, FIXED: blades alone over a uniform fill read as a flat
      // GREEN BLOB - the tufts are too fine to break the field at viewing size.
      // Turf is patchy before it is bladed, so the ground is broken into drifts
      // of differing green first and the blades are laid on top of that.
      for (let i = 0; i < 20; i++) {
        const x = b.x + r() * b.w, y = b.y + r() * b.h;
        c.globalAlpha = 0.16 + r() * 0.18;
        c.fillStyle = rgb(mix(col, r() < 0.5 ? [132, 150, 86] : [58, 74, 44], 0.55 + r() * 0.3));
        c.beginPath();
        c.ellipse(x, y, 22 + r() * 46, 10 + r() * 20, r() * 1.2, 0, 6.3);
        c.fill();
      }
      c.globalAlpha = 1;
      c.lineCap = 'round';
      for (let i = 0; i < 130; i++) {
        const x = b.x + r() * b.w, y = b.y + r() * b.h, L = 3 + r() * 8;
        c.globalAlpha = 0.24 + r() * 0.30;
        c.strokeStyle = rgb(shade(mix(col, [118, 142, 78], r() * 0.7), (r() - 0.4) * 0.5));
        c.lineWidth = 1.0;
        c.beginPath(); c.moveTo(x, y);
        c.quadraticCurveTo(x + (r() - 0.5) * 4, y - L * 0.6, x + (r() - 0.5) * 7, y - L);
        c.stroke();
      }
    },
  };

  /**
   * Draw the apron.
   * @param {CanvasRenderingContext2D} c the context
   * @param {Object} op an 'apron' op from a program
   */
  D.apron = function (c, op) {
    const b = bbox(op.outline);
    const r = Core.rng((Core.hash(op.ground) ^ 0x1B873593) >>> 0);
    const col = op.chroma;
    const path = (g) => apronPath(g, op.outline);

    // The body, with a worn centre: the middle of an apron is always more used.
    c.save();
    c.beginPath(); path(c); c.closePath();
    c.fillStyle = rgb(col);
    c.fill();
    c.clip();
    c.__bbox = b;

    // The worn centre. ⛔ MEASURED DEFECT, FIXED: drawn as ONE flat ellipse this
    // read as a hard-edged geometric oval stamped on the ground - the same
    // failure the cast shadows had. Wear has no edge, so it is laid as nested
    // falloff rings and the ground shows through the outer ones.
    const cx = b.x + b.w / 2, cy = b.y + b.h * 0.62;
    const worn = shade(col, -0.30);
    const rings = 6;
    for (let i = rings; i >= 1; i--) {
      const t = i / rings;
      c.globalAlpha = (0.13 + op.wear * 0.10) * (1 - t * 0.62);
      c.fillStyle = rgb(worn);
      c.beginPath();
      c.ellipse(cx, cy, b.w * 0.40 * (0.44 + t * 0.62), b.h * 0.34 * (0.44 + t * 0.62), 0, 0, 6.3);
      c.fill();
    }
    c.globalAlpha = 1;

    const draw = D.GROUND_DRAW[op.ground] || D.GROUND_DRAW.trodden;
    draw(c, b, r, col);
    c.globalAlpha = 1;
    c.restore();

    // The rim. ⛔ MEASURED DEFECT, FIXED: a single hard stroke round the whole
    // outline drew a CUT-OUT - the apron read as a raft laid on the battleback
    // rather than as ground the battleback continues into. Worked earth does not
    // end at a line, it thins out, so the rim is a band of falling alpha and only
    // the lit side keeps a crisp lip.
    c.save();
    c.beginPath(); path(c); c.closePath(); c.clip();
    for (let i = 0; i < 6; i++) {
      c.globalAlpha = 0.30 * (1 - i / 6);
      c.lineWidth = 3 + i * 5;
      c.strokeStyle = rgb(shade(col, -0.30));
      c.beginPath(); path(c); c.closePath(); c.stroke();
    }
    c.restore();
    c.save();
    c.beginPath(); path(c); c.closePath(); c.clip();
    c.beginPath(); path(c); c.closePath();
    c.translate(-D.LIGHT.x * 2.6, -D.LIGHT.y * 2.6);
    c.strokeStyle = rgb(shade(col, 0.32)); c.globalAlpha = 0.34; c.lineWidth = 2.2; c.stroke();
    c.restore();
  };

  //===========================================================================
  // THE MARKS - fourteen, each its own construction
  //===========================================================================

  /** A line of prints walking in from one side toward the band. */
  function trail(c, op, stamp, gap, wobble) {
    const r = Core.rng(op.seed);
    const y0 = op.seat.y + 26;
    const x0 = op.seat.x + op.from * (op.spread * 0.55 + 190);
    const steps = 9;
    for (let i = 0; i < steps; i++) {
      const t = i / steps;
      const x = x0 + (op.seat.x - x0) * t + (r() - 0.5) * wobble;
      const y = y0 - t * 26 + (r() - 0.5) * wobble * 0.6;
      const side = (i % 2) ? 1 : -1;
      c.save();
      c.globalAlpha = (0.16 + r() * 0.24) * (1 - t * 0.35);
      stamp(c, x, y + side * gap, r, side, op);
      c.restore();
    }
  }

  D.MARK_DRAW = {
    boottrack: function (c, op) {
      trail(c, op, (g, x, y, r) => {
        g.fillStyle = 'rgba(28,22,16,1)';
        g.beginPath(); g.ellipse(x, y, 4.4, 2.6, 0.2, 0, 6.3); g.fill();
        g.beginPath(); g.ellipse(x - 4.6, y - 0.6, 2.0, 1.7, 0.2, 0, 6.3); g.fill();
      }, 5, 12);
    },
    clawtrack: function (c, op) {
      // ⛔ MEASURED DEFECT, FIXED: three strokes radiating from one point read as
      // an ARROWHEAD, not a foot. A claw print is toes AROUND A PAD, so the pad
      // is drawn and the toes are separated and set off it.
      trail(c, op, (g, x, y, r) => {
        g.fillStyle = 'rgba(26,20,14,1)';
        g.beginPath(); g.ellipse(x + 1.6, y, 2.6, 2.0, 0, 0, 6.3); g.fill();
        for (let k = -1; k <= 1; k++) {
          const ty = y + k * 3.0;
          g.beginPath();
          g.ellipse(x - 3.4 - r() * 0.8, ty, 1.5, 1.0, -0.3 + k * 0.3, 0, 6.3);
          g.fill();
        }
      }, 6, 14);
    },
    hooftrack: function (c, op) {
      // ⛔⛔ MEASURED DEFECT, FIXED, AND IT IS THE WORST KIND: a stroked arc from
      // 0.18pi to 1.82pi is open on the right by a hair, so every print rendered
      // as the LETTER C. The sheet read as typography scattered over the ground.
      // A hoof is a FILLED CRESCENT - an outer curve minus an inner one - and the
      // gap is at the BACK of the print, which is a shape and not a glyph.
      trail(c, op, (g, x, y) => {
        g.fillStyle = 'rgba(24,18,14,1)';
        g.beginPath();
        g.ellipse(x, y, 4.4, 4.0, 0, Math.PI * 0.10, Math.PI * 1.90);
        g.ellipse(x, y + 0.6, 2.5, 2.3, 0, Math.PI * 1.90, Math.PI * 0.10, true);
        g.fill();
        g.beginPath();
        g.ellipse(x - 0.4, y - 0.6, 4.0, 3.5, 0, Math.PI * 1.06, Math.PI * 1.94);
        g.fill();
      }, 7, 11);
    },
    dragtrack: function (c, op) {
      const r = Core.rng(op.seed);
      const x0 = op.seat.x + op.from * (op.spread * 0.6 + 200);
      c.save(); c.globalAlpha = 0.24; c.strokeStyle = 'rgba(30,24,18,1)';
      c.lineWidth = 9; c.lineCap = 'round';
      c.beginPath(); c.moveTo(x0, op.seat.y + 30);
      c.quadraticCurveTo((x0 + op.seat.x) / 2, op.seat.y + 38 + (r() - 0.5) * 18, op.seat.x, op.seat.y + 14);
      c.stroke();
      c.globalAlpha = 0.20; c.lineWidth = 2.4; c.strokeStyle = 'rgba(210,198,176,1)';
      c.stroke();
      c.restore();
    },
    slithertrack: function (c, op) {
      const r = Core.rng(op.seed);
      const x0 = op.seat.x + op.from * (op.spread * 0.6 + 200);
      c.save(); c.globalAlpha = 0.26; c.strokeStyle = 'rgba(32,26,20,1)';
      c.lineWidth = 6; c.lineCap = 'round'; c.beginPath();
      c.moveTo(x0, op.seat.y + 30);
      for (let i = 1; i <= 6; i++) {
        const t = i / 6;
        c.quadraticCurveTo(x0 + (op.seat.x - x0) * (t - 0.08), op.seat.y + 30 + (i % 2 ? 22 : -14),
          x0 + (op.seat.x - x0) * t, op.seat.y + 30 - t * 16);
      }
      c.stroke(); c.restore();
    },
    cartrut: function (c, op) {
      // ⛔ MEASURED DEFECT, FIXED: drawn at a flat alpha the ruts ran to the frame
      // edge and read as two stray WIRES laid over the battleback. A track fades
      // out as the ground it is pressed into stops being disturbed, so each rut
      // is laid in segments whose alpha falls away from the band.
      const r = Core.rng(op.seed);
      const x0 = op.seat.x + op.from * (op.spread * 0.7 + 230);
      c.save(); c.lineCap = 'round'; c.strokeStyle = 'rgba(28,22,16,1)';
      const segs = 12;
      for (const off of [-11, 11]) {
        const jit = (r() - 0.5) * 12;
        for (let i = 0; i < segs; i++) {
          const t0 = i / segs, t1 = (i + 1) / segs;
          const at = (t) => ({
            x: x0 + (op.seat.x - x0) * t,
            y: op.seat.y + 34 + off + (16 - 34) * t * 0.6 + jit * Math.sin(t * 3),
          });
          const a = at(t0), b2 = at(t1);
          c.globalAlpha = 0.26 * Math.pow(t0, 0.85);
          c.lineWidth = 3.0 + t0 * 2.0;
          c.beginPath(); c.moveTo(a.x, a.y); c.lineTo(b2.x, b2.y); c.stroke();
        }
      }
      c.restore();
    },
    bloodslick: function (c, op) {
      // ⛔ MEASURED DEFECT, FIXED: an alternating-radius polygon is a STAR, so
      // the sheet read as red confetti. A pool has a smooth wandering edge, and
      // it pools DOWNHILL, so each blot gets a run and a few thrown droplets.
      const r = Core.rng(op.seed);
      c.save();
      for (let i = 0; i < 6; i++) {
        const x = op.seat.x + (r() - 0.5) * op.spread, y = op.seat.y + (r() - 0.4) * 46;
        const R = 9 + r() * 15;
        c.globalAlpha = 0.26 + r() * 0.22;
        c.fillStyle = rgb([84 + r() * 30, 18 + r() * 10, 20]);
        c.beginPath();
        for (let k = 0; k <= 12; k++) {
          const a = (k / 12) * 6.283;
          const rr = R * (0.78 + 0.22 * Math.sin(a * 3 + i) + r() * 0.10);
          const px = x + Math.cos(a) * rr, py = y + Math.sin(a) * rr * 0.46;
          if (k === 0) c.moveTo(px, py); else c.quadraticCurveTo(px, py, px, py);
        }
        c.fill();
        for (let k = 0; k < 4; k++) {
          c.globalAlpha = 0.18 + r() * 0.2;
          c.beginPath();
          c.ellipse(x + (r() - 0.5) * R * 2.4, y + (r() - 0.2) * R * 0.9,
            1.0 + r() * 2.0, 0.8 + r() * 1.3, 0, 0, 6.3);
          c.fill();
        }
      }
      c.restore();
    },
    scorchlick: function (c, op) {
      // ⛔ MEASURED DEFECT, FIXED: a dark ellipse with a smaller bright ellipse
      // centred in it is a FRIED EGG. Char is irregular and the heat that is
      // left glows at the EDGES and in cracks, never in a concentric core.
      const r = Core.rng(op.seed);
      c.save();
      for (let i = 0; i < 8; i++) {
        const x = op.seat.x + (r() - 0.5) * op.spread, y = op.seat.y + (r() - 0.35) * 40;
        const R = 9 + r() * 15;
        c.globalAlpha = 0.24 + r() * 0.26;
        c.fillStyle = 'rgba(26,18,14,1)';
        c.beginPath();
        for (let k = 0; k <= 11; k++) {
          const a = (k / 11) * 6.283;
          const rr = R * (0.72 + 0.30 * Math.sin(a * 2.4 + i * 1.7));
          const px = x + Math.cos(a) * rr, py = y + Math.sin(a) * rr * 0.48;
          if (k === 0) c.moveTo(px, py); else c.lineTo(px, py);
        }
        c.fill();
        for (let k = 0; k < 5; k++) {
          const a = r() * 6.283;
          c.globalAlpha = 0.30 + r() * 0.34;
          c.fillStyle = rgb([200 + r() * 50, 90 + r() * 50, 30]);
          c.beginPath();
          c.ellipse(x + Math.cos(a) * R * 0.82, y + Math.sin(a) * R * 0.40,
            0.8 + r() * 1.4, 0.6 + r() * 1.0, 0, 0, 6.3);
          c.fill();
        }
      }
      c.restore();
    },
    webstrand: function (c, op) {
      const r = Core.rng(op.seed);
      c.save(); c.strokeStyle = 'rgba(232,230,224,1)'; c.lineWidth = 0.9;
      for (let i = 0; i < 9; i++) {
        const x0 = op.seat.x - op.spread * 0.5 + r() * op.spread;
        const y0 = op.seat.y - 10 - r() * 40;
        const x1 = x0 + (r() - 0.5) * 90, y1 = op.seat.y + r() * 22;
        c.globalAlpha = 0.16 + r() * 0.22;
        c.beginPath(); c.moveTo(x0, y0);
        c.quadraticCurveTo((x0 + x1) / 2, (y0 + y1) / 2 + 12, x1, y1); c.stroke();
      }
      c.restore();
    },
    frostcreep: function (c, op) {
      const r = Core.rng(op.seed);
      c.save(); c.strokeStyle = 'rgba(214,236,246,1)'; c.lineCap = 'round';
      for (let i = 0; i < 12; i++) {
        let x = op.seat.x + (r() - 0.5) * op.spread, y = op.seat.y + (r() - 0.3) * 38;
        c.globalAlpha = 0.20 + r() * 0.30; c.lineWidth = 1.2;
        for (let k = 0; k < 5; k++) {
          const a = r() * 6.283, L = 5 + r() * 12;
          c.beginPath(); c.moveTo(x, y);
          x += Math.cos(a) * L; y += Math.sin(a) * L * 0.5;
          c.lineTo(x, y); c.stroke();
        }
      }
      c.restore();
    },
    sporebloom: function (c, op) {
      const r = Core.rng(op.seed);
      c.save();
      for (let i = 0; i < 26; i++) {
        const x = op.seat.x + (r() - 0.5) * op.spread, y = op.seat.y + (r() - 0.3) * 44;
        const R = 1.4 + r() * 3.4;
        c.globalAlpha = 0.28 + r() * 0.34;
        c.fillStyle = rgb([148 + r() * 50, 128 + r() * 40, 168 + r() * 40]);
        c.beginPath(); c.ellipse(x, y, R, R * 0.8, 0, 0, 6.3); c.fill();
        c.globalAlpha = 0.24;
        c.fillStyle = 'rgba(248,244,252,1)';
        c.beginPath(); c.ellipse(x - R * 0.3, y - R * 0.3, R * 0.4, R * 0.32, 0, 0, 6.3); c.fill();
      }
      c.restore();
    },
    bonescatter: function (c, op) {
      const r = Core.rng(op.seed);
      c.save();
      for (let i = 0; i < 11; i++) {
        const x = op.seat.x + (r() - 0.5) * op.spread * 1.1, y = op.seat.y + (r() - 0.25) * 46;
        const L = 5 + r() * 12, a = r() * 3.14;
        c.globalAlpha = 0.42 + r() * 0.3;
        beam(c, x, y, x + Math.cos(a) * L, y + Math.sin(a) * L * 0.5, 2.2 + r() * 1.6, 'bone', { lip: 1.0 });
      }
      c.restore();
    },
    gouge: function (c, op) {
      const r = Core.rng(op.seed);
      c.save();
      for (let i = 0; i < 6; i++) {
        const x = op.seat.x + (r() - 0.5) * op.spread, y = op.seat.y + (r() - 0.3) * 36;
        const a = -0.5 + r() * 1.0, L = 22 + r() * 40;
        c.globalAlpha = 0.34;
        c.strokeStyle = 'rgba(24,18,14,1)'; c.lineWidth = 3.4; c.lineCap = 'round';
        c.beginPath(); c.moveTo(x, y); c.lineTo(x + Math.cos(a) * L, y + Math.sin(a) * L * 0.5); c.stroke();
        c.globalAlpha = 0.26;
        c.strokeStyle = 'rgba(190,172,140,1)'; c.lineWidth = 1.3;
        c.beginPath(); c.moveTo(x, y - 1.6);
        c.lineTo(x + Math.cos(a) * L, y + Math.sin(a) * L * 0.5 - 1.6); c.stroke();
      }
      c.restore();
    },
    wardring: function (c, op) {
      const r = Core.rng(op.seed);
      const R = Math.max(54, op.spread * 0.52);
      c.save();
      c.globalAlpha = 0.34; c.strokeStyle = 'rgba(226,216,190,1)'; c.lineWidth = 2.0;
      c.beginPath(); c.ellipse(op.seat.x, op.seat.y + 8, R, R * 0.38, 0, 0, 6.3); c.stroke();
      c.globalAlpha = 0.24; c.lineWidth = 1.1;
      c.beginPath(); c.ellipse(op.seat.x, op.seat.y + 8, R * 0.82, R * 0.31, 0, 0, 6.3); c.stroke();
      // the marks set around it: a repeated charge at a declared pitch
      const pitch = 34;
      const n = Math.max(6, Math.round((2 * Math.PI * R) / pitch));
      for (let i = 0; i < n; i++) {
        const a = (i / n) * 6.283;
        const x = op.seat.x + Math.cos(a) * R * 0.91, y = op.seat.y + 8 + Math.sin(a) * R * 0.345;
        c.globalAlpha = 0.30 + r() * 0.2;
        c.strokeStyle = 'rgba(232,222,198,1)'; c.lineWidth = 1.5;
        c.beginPath(); c.moveTo(x - 3, y - 3); c.lineTo(x + 3, y + 3);
        c.moveTo(x + 3, y - 3); c.lineTo(x - 3, y + 3); c.stroke();
      }
      c.restore();
    },
  };

  //===========================================================================
  // THE FURNITURE - twenty-eight pieces, each its own construction
  //===========================================================================

  /** Flame: a stack of round masses, hottest at the base. */
  function flame(c, x, y, h, r, scale) {
    for (let i = 0; i < 9; i++) {
      const t = i / 9;
      const yy = y - t * h;
      const w = (7 - t * 5) * scale * (0.8 + r() * 0.5);
      c.save();
      c.globalAlpha = 0.34 + (1 - t) * 0.42;
      c.fillStyle = rgb(mix([255, 226, 150], [214, 76, 26], t));
      c.beginPath();
      c.ellipse(x + (r() - 0.5) * 5 * scale, yy, Math.max(1, w), Math.max(1.4, w * 1.5), 0, 0, 6.3);
      c.fill();
      c.restore();
    }
  }

  /** Warm pool a fire throws on the ground under it. */
  function firelight(c, x, y, R) {
    c.save();
    c.globalAlpha = 0.20;
    c.fillStyle = 'rgba(240,170,84,1)';
    c.beginPath(); c.ellipse(x, y + 3, R, R * 0.36, 0, 0, 6.3); c.fill();
    c.globalAlpha = 0.13;
    c.beginPath(); c.ellipse(x, y + 3, R * 1.5, R * 0.55, 0, 0, 6.3); c.fill();
    c.restore();
  }

  D.PIECE_DRAW = {
    campfire: function (c, x, y, s, r) {
      firelight(c, x, y, 38 * s);
      cast(c, x, y, 16 * s, 16 * s, 0.30);
      for (let i = 0; i < 5; i++) {
        const a = (i / 5) * Math.PI + 0.25;
        beam(c, x - Math.cos(a) * 17 * s, y + 2, x + Math.cos(a) * 13 * s, y - 13 * s, 4.6 * s, 'darkwood');
      }
      for (let i = 0; i < 6; i++) {
        mass(c, x + (r() - 0.5) * 20 * s, y + (r() - 0.5) * 5 * s, 3.4 * s, 2.2 * s, 'ember',
          { lip: 0.8, alpha: 0.75 });
      }
      flame(c, x, y - 8 * s, 34 * s, r, s);
    },
    cookpot: function (c, x, y, s, r) {
      cast(c, x, y, 13 * s, 22 * s, 0.34);
      for (const k of [-1, 0, 1]) beam(c, x + k * 12 * s, y + 1, x + k * 2.4 * s, y - 30 * s, 2.4 * s, 'timber');
      cord(c, x - 6 * s, y - 27 * s, x + 6 * s, y - 27 * s, 3 * s, 'rope');
      form(c, (g) => {
        g.moveTo(x - 11 * s, y - 24 * s); g.lineTo(x + 11 * s, y - 24 * s);
        g.quadraticCurveTo(x + 13 * s, y - 10 * s, x, y - 7 * s);
        g.quadraticCurveTo(x - 13 * s, y - 10 * s, x - 11 * s, y - 24 * s);
      }, 'metal', { lip: 2.2 });
      firelight(c, x, y, 20 * s);
    },
    spit: function (c, x, y, s, r) {
      cast(c, x, y, 26 * s, 26 * s, 0.30);
      for (const k of [-1, 1]) {
        beam(c, x + k * 22 * s, y + 2, x + k * 15 * s, y - 30 * s, 3.2 * s, 'timber');
        beam(c, x + k * 12 * s, y + 2, x + k * 15 * s, y - 30 * s, 2.6 * s, 'timber');
      }
      beam(c, x - 24 * s, y - 29 * s, x + 24 * s, y - 29 * s, 2.0 * s, 'metal', { lip: 1.2 });
      // ⛔ MEASURED DEFECT, FIXED: the carcass was one flat ellipse and vanished
      // against the frame, leaving a shape that read as a swing. It is now a body
      // threaded ON the spit - a trunk, a haunch and a shank - so the piece says
      // what it is for.
      form(c, (g) => {
        g.moveTo(x - 15 * s, y - 27 * s);
        g.quadraticCurveTo(x - 4 * s, y - 15 * s, x + 9 * s, y - 20 * s);
        g.quadraticCurveTo(x + 17 * s, y - 24 * s, x + 14 * s, y - 29 * s);
        g.quadraticCurveTo(x, y - 33 * s, x - 15 * s, y - 27 * s);
      }, 'hide', { lip: 2.4, tint: [148, 92, 58], tintAmt: 0.42 });
      beam(c, x + 8 * s, y - 21 * s, x + 15 * s, y - 13 * s, 2.6 * s, 'hide', { lip: 1.2 });
      mass(c, x + 15 * s, y - 12 * s, 2.2 * s, 2.6 * s, 'bone', { lip: 1.0 });
      beam(c, x - 11 * s, y - 24 * s, x - 17 * s, y - 16 * s, 2.2 * s, 'hide', { lip: 1.1 });
      c.save(); c.globalAlpha = 0.30; c.fillStyle = rgb([42, 28, 20]);
      c.beginPath(); c.ellipse(x - 2 * s, y - 22 * s, 7 * s, 3 * s, -0.2, 0, 6.3); c.fill(); c.restore();
      for (let i = 0; i < 4; i++) {
        mass(c, x + (r() - 0.5) * 26 * s, y + 1, 3 * s, 1.8 * s, 'ember', { lip: 0.7, alpha: 0.7 });
      }
      firelight(c, x, y, 26 * s);
    },
    bedroll: function (c, x, y, s, r) {
      // ⛔ MEASURED DEFECT, FIXED: one tapered lump with a ball at one end read
      // as a FISH. A bedroll is a rolled cylinder: it needs a flat end you can
      // see the spiral in, straps around it, and a groundsheet under it.
      cast(c, x, y, 26 * s, 10 * s, 0.28);
      c.save(); c.globalAlpha = 0.28; c.fillStyle = rgb([84, 76, 60]);
      c.beginPath(); c.ellipse(x, y + 2, 30 * s, 7 * s, 0, 0, 6.3); c.fill(); c.restore();
      form(c, (g) => {
        g.moveTo(x - 24 * s, y - 1 * s);
        g.lineTo(x + 20 * s, y - 1 * s);
        g.quadraticCurveTo(x + 26 * s, y - 7 * s, x + 20 * s, y - 13 * s);
        g.lineTo(x - 24 * s, y - 13 * s);
        g.quadraticCurveTo(x - 30 * s, y - 7 * s, x - 24 * s, y - 1 * s);
      }, 'palecloth', { lip: 2.2 });
      // the visible end of the roll, with the spiral that says it is rolled
      form(c, (g) => { g.ellipse(x - 24 * s, y - 7 * s, 5.4 * s, 6.4 * s, 0, 0, 6.3); },
        'palecloth', { lip: 1.8, tint: [140, 126, 100], tintAmt: 0.35 });
      c.save(); c.globalAlpha = 0.45; c.strokeStyle = rgb([96, 86, 68]); c.lineWidth = 1.1;
      c.beginPath();
      for (let k = 0; k < 22; k++) {
        const t = k / 21, a = t * 5.6, rr = (1 + t * 4.2) * s;
        const px = x - 24 * s + Math.cos(a) * rr * 0.85, py = y - 7 * s + Math.sin(a) * rr;
        if (k === 0) c.moveTo(px, py); else c.lineTo(px, py);
      }
      c.stroke(); c.restore();
      for (const sx of [-8, 8]) {
        beam(c, x + sx * s, y - 14 * s, x + sx * s, y - 0.5 * s, 2.4 * s, 'hide', { lip: 1.0 });
        mass(c, x + sx * s, y - 7 * s, 1.8 * s, 1.5 * s, 'metal', { lip: 0.8 });
      }
    },
    leanto: function (c, x, y, s, r) {
      cast(c, x, y, 34 * s, 40 * s, 0.34);
      beam(c, x - 30 * s, y + 2, x + 24 * s, y - 40 * s, 4.0 * s, 'timber');
      beam(c, x + 30 * s, y + 2, x + 24 * s, y - 40 * s, 4.0 * s, 'timber');
      sheet(c, x + 24 * s, y - 38 * s, x - 28 * s, y - 2 * s, 7 * s, 8 * s, 'hide', { lip: 2.4 });
      cord(c, x + 24 * s, y - 40 * s, x + 44 * s, y + 2, 5 * s, 'rope');
      post(c, x + 44 * s, y - 6 * s, y + 3, 3 * s, 'timber');
    },
    stackedarms: function (c, x, y, s, r) {
      cast(c, x, y, 20 * s, 46 * s, 0.34);
      for (let i = -2; i <= 2; i++) {
        const lean = i * 7 * s;
        beam(c, x + lean * 1.9, y + 2, x + lean * 0.3, y - 48 * s, 2.6 * s, 'timber');
        // head: a leaf blade, not a rectangle
        form(c, (g) => {
          const hx = x + lean * 0.3, hy = y - 48 * s;
          g.moveTo(hx, hy - 11 * s);
          g.quadraticCurveTo(hx + 3.4 * s, hy - 4 * s, hx, hy + 2 * s);
          g.quadraticCurveTo(hx - 3.4 * s, hy - 4 * s, hx, hy - 11 * s);
        }, 'metal', { lip: 1.4 });
      }
      cord(c, x - 12 * s, y - 32 * s, x + 12 * s, y - 32 * s, 3.4 * s, 'rope');
    },
    shieldrest: function (c, x, y, s, r) {
      // ⛔ MEASURED DEFECT, FIXED: a plain metal heater shape with a boss in the
      // middle read as a STONE EGG, and the rack behind it was invisible. A
      // shield reads as a shield from its RIM and its device, so both shields now
      // carry a banded rim and a charge, and the rack has two legs to stand on.
      cast(c, x, y, 26 * s, 28 * s, 0.32);
      post(c, x - 22 * s, y - 14 * s, y + 2, 3.2 * s, 'timber', { lean: -2 * s });
      post(c, x + 22 * s, y - 24 * s, y + 2, 3.2 * s, 'timber', { lean: 2 * s });
      beam(c, x - 23 * s, y - 14 * s, x + 23 * s, y - 24 * s, 3.4 * s, 'timber');
      for (const k of [-1, 1]) {
        const sx = x + k * 13 * s, sy = y - 16 * s - k * 6 * s;
        const body = (g) => {
          g.moveTo(sx, sy - 15 * s);
          g.quadraticCurveTo(sx + 12 * s, sy - 10 * s, sx + 10 * s, sy + 4 * s);
          g.quadraticCurveTo(sx, sy + 16 * s, sx - 10 * s, sy + 4 * s);
          g.quadraticCurveTo(sx - 12 * s, sy - 10 * s, sx, sy - 15 * s);
        };
        form(c, body, k > 0 ? 'timber' : 'metal', {
          lip: 2.4, tint: k > 0 ? [128, 48, 42] : [72, 84, 110], tintAmt: 0.46,
        });
        c.save();
        c.beginPath(); body(c); c.closePath();
        c.strokeStyle = rgb(D.MAT.metal.base); c.globalAlpha = 0.75; c.lineWidth = 2.2 * s;
        c.stroke();
        c.restore();
        // the charge: one repeated unit with a centre, never scattered debris
        c.save(); c.globalAlpha = 0.62; c.fillStyle = rgb(k > 0 ? [216, 198, 140] : [196, 206, 224]);
        for (let i = -1; i <= 1; i++) {
          c.beginPath();
          c.moveTo(sx + i * 5 * s, sy - 5 * s);
          c.quadraticCurveTo(sx + i * 5 * s + 3 * s, sy, sx + i * 5 * s, sy + 5 * s);
          c.quadraticCurveTo(sx + i * 5 * s - 3 * s, sy, sx + i * 5 * s, sy - 5 * s);
          c.fill();
        }
        c.restore();
        mass(c, sx, sy - 10 * s, 2.6 * s, 2.4 * s, 'metal', { lip: 1.0 });
      }
    },
    wardrum: function (c, x, y, s, r) {
      cast(c, x, y, 20 * s, 30 * s, 0.34);
      for (const k of [-1, 1]) beam(c, x + k * 15 * s, y + 2, x + k * 5 * s, y - 20 * s, 2.6 * s, 'timber');
      form(c, (g) => {
        g.moveTo(x - 17 * s, y - 34 * s); g.lineTo(x + 17 * s, y - 34 * s);
        g.lineTo(x + 14 * s, y - 14 * s); g.lineTo(x - 14 * s, y - 14 * s);
      }, 'darkwood', { lip: 2.2 });
      form(c, (g) => { g.ellipse(x, y - 34 * s, 17 * s, 6.4 * s, 0, 0, 6.3); }, 'hide', { lip: 2.0 });
      c.save(); c.globalAlpha = 0.5; c.strokeStyle = rgb([70, 56, 40]); c.lineWidth = 1.2;
      const n = 8;
      for (let i = 0; i < n; i++) {
        const a = (i / n) * 6.283;
        c.beginPath();
        c.moveTo(x + Math.cos(a) * 16 * s, y - 34 * s + Math.sin(a) * 6 * s);
        c.lineTo(x + Math.cos(a) * 13 * s, y - 15 * s); c.stroke();
      }
      c.restore();
    },
    standard: function (c, x, y, s, r) {
      cast(c, x, y, 9 * s, 80 * s, 0.40);
      post(c, x, y - 82 * s, y + 2, 3.6 * s, 'timber');
      // finial: a chain of round masses, never a rotated plate
      for (let i = 0; i < 3; i++) {
        mass(c, x, y - 84 * s - i * 5 * s, (4.6 - i * 1.1) * s, (4.6 - i * 1.1) * s, 'gold', { lip: 1.3 });
      }
      sheet(c, x + 2 * s, y - 78 * s, x + 34 * s, y - 70 * s, 34 * s, 5 * s, 'cloth', { lip: 2.6 });
      // the charge: one repeated unit, and a centre for the second shape
      c.save(); c.globalAlpha = 0.62; c.fillStyle = rgb([224, 206, 150]);
      for (let i = 0; i < 3; i++) {
        const cx2 = x + 12 * s + i * 8 * s, cy2 = y - 60 * s + i * 3 * s;
        c.beginPath();
        c.moveTo(cx2, cy2 - 5 * s);
        c.quadraticCurveTo(cx2 + 4 * s, cy2, cx2, cy2 + 5 * s);
        c.quadraticCurveTo(cx2 - 4 * s, cy2, cx2, cy2 - 5 * s);
        c.fill();
      }
      c.restore();
      for (let i = 0; i < 3; i++) cord(c, x + 30 * s, y - 42 * s + i * 4 * s, x + 40 * s, y - 28 * s + i * 6 * s, 4 * s, 'rope');
    },
    palisade: function (c, x, y, s, r) {
      cast(c, x, y, 46 * s, 34 * s, 0.34);
      // the ditch first, then the stakes standing in its spoil
      c.save(); c.globalAlpha = 0.30; c.fillStyle = 'rgba(30,24,18,1)';
      c.beginPath(); c.ellipse(x, y + 8 * s, 52 * s, 8 * s, 0, 0, 6.3); c.fill(); c.restore();
      for (let i = -3; i <= 3; i++) {
        const px = x + i * 15 * s + (r() - 0.5) * 4 * s;
        const h = (30 + r() * 16) * s;
        post(c, px, y - h, y + 2, 5.2 * s, 'timber', { lean: (r() - 0.5) * 3 * s });
        form(c, (g) => {
          g.moveTo(px - 2.6 * s, y - h); g.lineTo(px + 2.6 * s, y - h); g.lineTo(px, y - h - 7 * s);
        }, 'timber', { lip: 1.2 });
      }
      cord(c, x - 44 * s, y - 20 * s, x + 44 * s, y - 22 * s, 6 * s, 'rope');
    },
    chevaux: function (c, x, y, s, r) {
      cast(c, x, y, 30 * s, 24 * s, 0.30);
      for (let i = -1; i <= 1; i++) {
        const px = x + i * 24 * s;
        beam(c, px - 15 * s, y + 3, px + 15 * s, y - 28 * s, 3.4 * s, 'timber');
        beam(c, px + 15 * s, y + 3, px - 15 * s, y - 28 * s, 3.4 * s, 'timber');
        cord(c, px - 6 * s, y - 15 * s, px + 6 * s, y - 15 * s, 2.4 * s, 'rope');
      }
    },
    totem: function (c, x, y, s, r) {
      cast(c, x, y, 13 * s, 66 * s, 0.40);
      post(c, x, y - 70 * s, y + 2, 13 * s, 'darkwood');
      // three carved registers, each a chain of round masses (a ridge, not a plate)
      for (let k = 0; k < 3; k++) {
        const yy = y - 18 * s - k * 21 * s;
        for (let i = -2; i <= 2; i++) {
          mass(c, x + i * 3.1 * s, yy, 2.5 * s, 3.4 * s, 'darkwood', { lip: 1.1 });
        }
        c.save(); c.globalAlpha = 0.5;
        c.fillStyle = rgb(k % 2 ? [168, 82, 46] : [196, 176, 118]);
        c.beginPath(); c.ellipse(x, yy - 6 * s, 4.6 * s, 2.4 * s, 0, 0, 6.3); c.fill();
        c.restore();
      }
      form(c, (g) => {
        g.moveTo(x - 14 * s, y - 70 * s);
        g.lineTo(x + 14 * s, y - 70 * s);
        g.lineTo(x + 8 * s, y - 82 * s);
        g.lineTo(x - 8 * s, y - 82 * s);
      }, 'darkwood', { lip: 2.0 });
    },
    altar: function (c, x, y, s, r) {
      cast(c, x, y, 30 * s, 26 * s, 0.38);
      for (const k of [-1, 1]) post(c, x + k * 20 * s, y - 22 * s, y + 2, 11 * s, 'stone');
      form(c, (g) => {
        g.moveTo(x - 32 * s, y - 24 * s); g.lineTo(x + 32 * s, y - 24 * s);
        g.lineTo(x + 28 * s, y - 31 * s); g.lineTo(x - 28 * s, y - 31 * s);
      }, 'stone', { lip: 2.6 });
      // offerings: three, and the middle one is different
      mass(c, x - 12 * s, y - 34 * s, 4 * s, 3.4 * s, 'gold', { lip: 1.3 });
      mass(c, x + 12 * s, y - 34 * s, 4 * s, 3.4 * s, 'gold', { lip: 1.3 });
      form(c, (g) => {
        g.moveTo(x - 5 * s, y - 33 * s); g.lineTo(x + 5 * s, y - 33 * s);
        g.quadraticCurveTo(x, y - 44 * s, x - 5 * s, y - 33 * s);
      }, 'bone', { lip: 1.6 });
      c.save(); c.globalAlpha = 0.22; c.fillStyle = rgb([210, 186, 120]);
      c.beginPath(); c.ellipse(x, y - 36 * s, 26 * s, 6 * s, 0, 0, 6.3); c.fill(); c.restore();
    },
    brazier: function (c, x, y, s, r) {
      firelight(c, x, y, 30 * s);
      cast(c, x, y, 13 * s, 34 * s, 0.34);
      for (let i = 0; i < 3; i++) {
        const a = (i / 3) * 6.283 + 0.5;
        beam(c, x + Math.cos(a) * 11 * s, y + 2, x, y - 30 * s, 2.6 * s, 'metal');
      }
      form(c, (g) => {
        g.moveTo(x - 15 * s, y - 30 * s); g.lineTo(x + 15 * s, y - 30 * s);
        g.quadraticCurveTo(x + 11 * s, y - 19 * s, x, y - 18 * s);
        g.quadraticCurveTo(x - 11 * s, y - 19 * s, x - 15 * s, y - 30 * s);
      }, 'rust', { lip: 2.2 });
      form(c, (g) => { g.ellipse(x, y - 30 * s, 15 * s, 4.2 * s, 0, 0, 6.3); }, 'rust', { lip: 1.6 });
      for (let i = 0; i < 5; i++) {
        mass(c, x + (r() - 0.5) * 20 * s, y - 31 * s, 2.6 * s, 1.5 * s, 'ember', { lip: 0.6, alpha: 0.8 });
      }
      flame(c, x, y - 32 * s, 24 * s, r, s * 0.8);
    },
    carrionpost: function (c, x, y, s, r) {
      cast(c, x, y, 8 * s, 62 * s, 0.38);
      post(c, x, y - 64 * s, y + 2, 4.6 * s, 'darkwood', { lean: 2 * s });
      cord(c, x - 9 * s, y - 60 * s, x + 9 * s, y - 58 * s, 4 * s, 'rope');
      // the skull: a cranium mass, a muzzle mass, two sockets
      mass(c, x + 1 * s, y - 52 * s, 8 * s, 7 * s, 'bone', { lip: 1.8 });
      mass(c, x + 3 * s, y - 45 * s, 5 * s, 4.4 * s, 'bone', { lip: 1.5 });
      c.save(); c.fillStyle = 'rgba(24,20,18,0.8)';
      c.beginPath(); c.ellipse(x - 2 * s, y - 53 * s, 2.3 * s, 2.0 * s, 0, 0, 6.3); c.fill();
      c.beginPath(); c.ellipse(x + 4.4 * s, y - 53 * s, 2.3 * s, 2.0 * s, 0, 0, 6.3); c.fill();
      c.restore();
      for (let i = 0; i < 3; i++) {
        cord(c, x + 2 * s, y - 40 * s, x + (r() - 0.5) * 16 * s, y - 24 * s + i * 5 * s, 4 * s, 'rope');
      }
    },
    bonemidden: function (c, x, y, s, r) {
      // ⛔ MEASURED DEFECT, FIXED: scattered sticks with one lump on top read as
      // a dead bird, not as a heap of bones. A midden is a PILE - it has a mound
      // under it, the bones sit ON the mound, and one unmistakable skull with
      // sockets is what names the whole thing.
      cast(c, x, y, 26 * s, 18 * s, 0.32);
      form(c, (g) => {
        g.moveTo(x - 30 * s, y + 2);
        g.quadraticCurveTo(x - 14 * s, y - 15 * s, x + 4 * s, y - 14 * s);
        g.quadraticCurveTo(x + 22 * s, y - 13 * s, x + 30 * s, y + 2);
      }, 'darkstone', { lip: 2.0 });
      // ⛔ SECOND PASS. Knuckles at 0.85 of the shaft width MERGED WITH THEIR
      // NEIGHBOURS and the heap read as a pale splat. A bone is a thin shaft with
      // knuckles WIDER THAN THE SHAFT BUT SMALL, separated by a visible gap, and
      // the tone has to vary or sixteen of them are one shape.
      for (let i = 0; i < 15; i++) {
        const bx = x + (r() - 0.5) * 62 * s, by = y - 2 * s - r() * 14 * s;
        const a = (r() - 0.5) * 2.4, L = (12 + r() * 20) * s;
        const w = (1.7 + r() * 1.2) * s;
        const ex = bx + Math.cos(a) * L, ey = by + Math.sin(a) * L * 0.38;
        const age = 0.2 + r() * 0.5;
        const o = { lip: 1.1, tint: [128, 112, 86], tintAmt: age };
        beam(c, bx, by, ex, ey, w, 'bone', o);
        mass(c, bx, by, w * 1.5, w * 1.15, 'bone', o);
        mass(c, ex, ey, w * 1.5, w * 1.15, 'bone', o);
      }
      // the skull, set clear of the heap so it names the whole thing
      const sx = x + 14 * s, sy = y - 24 * s;
      mass(c, sx, sy, 11 * s, 9 * s, 'bone', { lip: 2.2 });
      form(c, (g) => {
        g.moveTo(sx + 4 * s, sy + 2 * s);
        g.quadraticCurveTo(sx + 17 * s, sy + 3 * s, sx + 15 * s, sy + 9 * s);
        g.quadraticCurveTo(sx + 9 * s, sy + 12 * s, sx + 3 * s, sy + 8 * s);
      }, 'bone', { lip: 1.7 });
      c.save(); c.fillStyle = 'rgba(20,16,14,0.88)';
      c.beginPath(); c.ellipse(sx - 1 * s, sy - 1 * s, 3.0 * s, 2.7 * s, -0.2, 0, 6.3); c.fill();
      c.beginPath(); c.ellipse(sx + 7.5 * s, sy + 0.5 * s, 2.6 * s, 2.4 * s, -0.2, 0, 6.3); c.fill();
      c.globalAlpha = 0.55;
      c.beginPath(); c.ellipse(sx + 9 * s, sy + 8 * s, 4.5 * s, 1.5 * s, 0.1, 0, 6.3); c.fill();
      c.restore();
    },
    cage: function (c, x, y, s, r) {
      // ⛔ MEASURED DEFECT, FIXED: a filled panel behind the bars made this read
      // as a CRATE with a grain. A cage is defined by what you can SEE THROUGH
      // it, so there is no panel at all: a dark void, bars over it, and a gap
      // between every pair. The occupant is what makes the void read as interior.
      cast(c, x, y, 22 * s, 36 * s, 0.34);
      c.save();
      c.globalAlpha = 0.72; c.fillStyle = 'rgba(14,11,16,1)';
      c.beginPath();
      c.moveTo(x - 18 * s, y + 1); c.lineTo(x + 18 * s, y + 1);
      c.lineTo(x + 15 * s, y - 35 * s); c.lineTo(x - 15 * s, y - 35 * s);
      c.fill();
      c.restore();
      // a shape huddled inside, so the dark reads as depth rather than as paint
      mass(c, x - 3 * s, y - 9 * s, 8 * s, 7 * s, 'hide', { lip: 1.4, alpha: 0.85 });
      mass(c, x + 5 * s, y - 15 * s, 4.6 * s, 4.2 * s, 'hide', { lip: 1.2, alpha: 0.85 });
      const pitch = 7.5 * s;
      const n = Math.max(4, Math.round((36 * s) / pitch));
      for (let i = 0; i <= n; i++) {
        const t = i / n;
        beam(c, x - 18 * s + t * 36 * s, y + 1, x - 15 * s + t * 30 * s, y - 35 * s,
          1.9 * s, 'rust', { lip: 1.0 });
      }
      for (const yy of [-35, -22, -10, 1]) {
        const k = 1 - Math.abs(yy + 17) / 52;
        beam(c, x - (15 + 3 * k) * s, y + yy * s, x + (15 + 3 * k) * s, y + yy * s,
          2.6 * s, 'rust', { lip: 1.2 });
      }
      // the hasp, which is the one detail that says "this shuts"
      mass(c, x + 15 * s, y - 18 * s, 2.8 * s, 3.6 * s, 'metal', { lip: 1.1 });
    },
    spoilpile: function (c, x, y, s, r) {
      cast(c, x, y, 22 * s, 14 * s, 0.32);
      form(c, (g) => {
        g.moveTo(x - 26 * s, y + 2);
        g.quadraticCurveTo(x - 14 * s, y - 18 * s, x + 2 * s, y - 16 * s);
        g.quadraticCurveTo(x + 20 * s, y - 14 * s, x + 26 * s, y + 2);
      }, 'hide', { lip: 2.2 });
      for (let i = 0; i < 14; i++) {
        const cx2 = x + (r() - 0.5) * 42 * s, cy2 = y - r() * 15 * s;
        mass(c, cx2, cy2, (2.0 + r() * 2.4) * s, (1.6 + r() * 1.6) * s, 'gold', { lip: 0.9 });
      }
      form(c, (g) => {
        g.moveTo(x + 10 * s, y - 14 * s); g.lineTo(x + 18 * s, y - 14 * s);
        g.quadraticCurveTo(x + 14 * s, y - 26 * s, x + 10 * s, y - 14 * s);
      }, 'gold', { lip: 1.4 });
    },
    crates: function (c, x, y, s, r) {
      cast(c, x, y, 24 * s, 28 * s, 0.32);
      const box = (bx, by, w, h, mat) => {
        form(c, (g) => {
          g.moveTo(bx - w, by); g.lineTo(bx + w, by);
          g.lineTo(bx + w * 0.92, by - h); g.lineTo(bx - w * 0.92, by - h);
        }, mat, { lip: 2.2 });
        c.save(); c.globalAlpha = 0.4; c.strokeStyle = rgb([62, 46, 32]); c.lineWidth = 1.3;
        c.beginPath(); c.moveTo(bx - w, by); c.lineTo(bx + w * 0.92, by - h);
        c.moveTo(bx + w, by); c.lineTo(bx - w * 0.92, by - h); c.stroke(); c.restore();
      };
      box(x - 13 * s, y + 2, 15 * s, 19 * s, 'timber');
      box(x + 15 * s, y + 2, 12 * s, 15 * s, 'timber');
      box(x - 10 * s, y - 18 * s, 11 * s, 14 * s, 'darkwood');
      // a barrel is not a crate: round masses and hoops
      form(c, (g) => {
        g.moveTo(x + 28 * s, y + 2);
        g.quadraticCurveTo(x + 36 * s, y - 11 * s, x + 28 * s, y - 22 * s);
        g.lineTo(x + 16 * s, y - 22 * s);
        g.quadraticCurveTo(x + 9 * s, y - 11 * s, x + 16 * s, y + 2);
      }, 'timber', { lip: 2.0 });
      c.save(); c.globalAlpha = 0.5; c.strokeStyle = rgb([84, 70, 56]); c.lineWidth = 1.6;
      for (const yy of [-6, -16]) {
        c.beginPath(); c.moveTo(x + 16 * s, y + yy * s); c.lineTo(x + 28 * s, y + yy * s); c.stroke();
      }
      c.restore();
    },
    dais: function (c, x, y, s, r) {
      cast(c, x, y, 46 * s, 30 * s, 0.42);
      for (let k = 2; k >= 0; k--) {
        const w = (52 - k * 10) * s, h = 9 * s, yy = y + 2 - k * h;
        form(c, (g) => {
          g.moveTo(x - w, yy); g.lineTo(x + w, yy);
          g.lineTo(x + w * 0.94, yy - h); g.lineTo(x - w * 0.94, yy - h);
        }, k === 2 ? 'stone' : 'darkstone', { lip: 2.4 });
      }
      // the seat: a back, two arms, a cushion
      const sy = y + 2 - 27 * s;
      form(c, (g) => {
        g.moveTo(x - 15 * s, sy); g.lineTo(x + 15 * s, sy);
        g.lineTo(x + 12 * s, sy - 34 * s); g.lineTo(x - 12 * s, sy - 34 * s);
      }, 'darkstone', { lip: 2.4 });
      for (const k of [-1, 1]) {
        form(c, (g) => {
          g.moveTo(x + k * 15 * s, sy); g.lineTo(x + k * 19 * s, sy);
          g.lineTo(x + k * 17 * s, sy - 16 * s); g.lineTo(x + k * 13 * s, sy - 16 * s);
        }, 'stone', { lip: 1.8 });
      }
      form(c, (g) => { g.ellipse(x, sy - 2 * s, 14 * s, 4.6 * s, 0, 0, 6.3); }, 'cloth', { lip: 1.8 });
      for (let i = 0; i < 3; i++) {
        mass(c, x - 8 * s + i * 8 * s, sy - 36 * s, 2.8 * s, 3.4 * s, 'gold', { lip: 1.1 });
      }
    },
    hidedryer: function (c, x, y, s, r) {
      cast(c, x, y, 28 * s, 44 * s, 0.32);
      for (const k of [-1, 1]) post(c, x + k * 26 * s, y - 46 * s, y + 2, 3.6 * s, 'timber');
      beam(c, x - 28 * s, y - 46 * s, x + 28 * s, y - 47 * s, 2.8 * s, 'timber');
      for (let i = -1; i <= 1; i++) {
        const hx = x + i * 19 * s;
        form(c, (g) => {
          g.moveTo(hx - 8 * s, y - 45 * s); g.lineTo(hx + 8 * s, y - 45 * s);
          g.quadraticCurveTo(hx + 11 * s, y - 26 * s, hx + 5 * s, y - 16 * s);
          g.quadraticCurveTo(hx, y - 12 * s, hx - 5 * s, y - 16 * s);
          g.quadraticCurveTo(hx - 11 * s, y - 26 * s, hx - 8 * s, y - 45 * s);
        }, 'hide', { lip: 2.2, tint: [150, 120, 82], tintAmt: i === 0 ? 0.4 : 0.1 });
      }
    },
    anvilstone: function (c, x, y, s, r) {
      cast(c, x, y, 18 * s, 22 * s, 0.36);
      post(c, x, y - 14 * s, y + 2, 17 * s, 'darkwood');
      form(c, (g) => {
        g.moveTo(x - 17 * s, y - 16 * s); g.lineTo(x + 13 * s, y - 16 * s);
        g.quadraticCurveTo(x + 25 * s, y - 20 * s, x + 13 * s, y - 24 * s);
        g.lineTo(x - 15 * s, y - 24 * s);
      }, 'metal', { lip: 2.4 });
      form(c, (g) => {
        g.moveTo(x - 12 * s, y - 24 * s); g.lineTo(x + 8 * s, y - 24 * s);
        g.lineTo(x + 6 * s, y - 15 * s); g.lineTo(x - 10 * s, y - 15 * s);
      }, 'metal', { lip: 1.6 });
      beam(c, x + 18 * s, y + 2, x + 24 * s, y - 20 * s, 2.6 * s, 'timber');
      mass(c, x + 24 * s, y - 22 * s, 4.4 * s, 3.2 * s, 'metal', { lip: 1.3 });
    },
    cocoon: function (c, x, y, s, r) {
      cast(c, x, y, 14 * s, 40 * s, 0.28);
      cord(c, x - 20 * s, y - 62 * s, x + 2 * s, y - 48 * s, 3 * s, 'rope');
      cord(c, x + 22 * s, y - 60 * s, x + 2 * s, y - 48 * s, 3 * s, 'rope');
      form(c, (g) => {
        g.moveTo(x, y - 50 * s);
        g.quadraticCurveTo(x + 15 * s, y - 34 * s, x + 7 * s, y - 6 * s);
        g.quadraticCurveTo(x, y + 4 * s, x - 7 * s, y - 6 * s);
        g.quadraticCurveTo(x - 15 * s, y - 34 * s, x, y - 50 * s);
      }, 'palecloth', { lip: 2.4 });
      c.save(); c.globalAlpha = 0.36; c.strokeStyle = 'rgba(248,246,240,1)'; c.lineWidth = 1.0;
      for (let i = 0; i < 9; i++) {
        const t = i / 9, yy = y - 46 * s + t * 44 * s;
        c.beginPath();
        c.moveTo(x - 9 * s, yy); c.quadraticCurveTo(x, yy + 3 * s, x + 9 * s, yy - 1 * s); c.stroke();
      }
      c.restore();
    },
    fungalcluster: function (c, x, y, s, r) {
      cast(c, x, y, 20 * s, 16 * s, 0.26);
      for (let i = 0; i < 7; i++) {
        const fx = x + (r() - 0.5) * 42 * s;
        const h = (10 + r() * 24) * s;
        post(c, fx, y - h, y + 2, (3.2 + r() * 2) * s, 'fungus', { lean: (r() - 0.5) * 2 * s });
        const capW = (6 + r() * 9) * s;
        form(c, (g) => {
          g.moveTo(fx - capW, y - h);
          g.quadraticCurveTo(fx, y - h - capW * 1.05, fx + capW, y - h);
          g.quadraticCurveTo(fx, y - h + capW * 0.28, fx - capW, y - h);
        }, 'fungus', { lip: 1.8, tint: [186, 108, 142], tintAmt: 0.28 + r() * 0.3 });
        c.save(); c.globalAlpha = 0.34; c.fillStyle = 'rgba(252,248,254,1)';
        for (let k = 0; k < 3; k++) {
          c.beginPath();
          c.ellipse(fx + (r() - 0.5) * capW * 1.2, y - h - capW * 0.36, 1.2 * s, 1.0 * s, 0, 0, 6.3);
          c.fill();
        }
        c.restore();
      }
    },
    icecairn: function (c, x, y, s, r) {
      cast(c, x, y, 18 * s, 44 * s, 0.24);
      for (let i = 0; i < 6; i++) {
        const t = i / 6;
        const bx = x + (r() - 0.5) * 22 * s * (1 - t);
        const h = (34 - t * 22) * s;
        const yy = y + 2 - t * 26 * s;
        form(c, (g) => {
          g.moveTo(bx - 7 * s * (1 - t * 0.5), yy);
          g.lineTo(bx + 7 * s * (1 - t * 0.5), yy);
          g.lineTo(bx + 2 * s, yy - h);
          g.lineTo(bx - 3 * s, yy - h * 0.92);
        }, 'ice', { lip: 2.0, alpha: 0.88 });
      }
      c.save(); c.globalAlpha = 0.24; c.fillStyle = 'rgba(206,238,250,1)';
      c.beginPath(); c.ellipse(x, y + 3, 30 * s, 8 * s, 0, 0, 6.3); c.fill(); c.restore();
    },
    cindervent: function (c, x, y, s, r) {
      firelight(c, x, y, 26 * s);
      cast(c, x, y, 24 * s, 12 * s, 0.30);
      form(c, (g) => {
        g.moveTo(x - 30 * s, y + 3);
        g.quadraticCurveTo(x - 12 * s, y - 16 * s, x - 4 * s, y - 15 * s);
        g.lineTo(x + 6 * s, y - 15 * s);
        g.quadraticCurveTo(x + 14 * s, y - 16 * s, x + 30 * s, y + 3);
      }, 'darkstone', { lip: 2.4 });
      c.save();
      c.fillStyle = rgb([212, 92, 28]); c.globalAlpha = 0.8;
      c.beginPath(); c.ellipse(x + 1 * s, y - 14 * s, 6 * s, 2.4 * s, 0, 0, 6.3); c.fill();
      c.restore();
      for (let i = 0; i < 7; i++) {
        const t = i / 7;
        c.save(); c.globalAlpha = 0.5 - t * 0.42;
        c.fillStyle = rgb(mix([255, 208, 130], [140, 60, 30], t));
        c.beginPath();
        c.ellipse(x + (r() - 0.5) * 14 * s, y - 18 * s - t * 30 * s, (2.4 - t * 1.4) * s,
          (2.4 - t * 1.4) * s, 0, 0, 6.3);
        c.fill(); c.restore();
      }
    },
    reedbundle: function (c, x, y, s, r) {
      cast(c, x, y, 13 * s, 40 * s, 0.26);
      for (let i = 0; i < 11; i++) {
        const lean = (r() - 0.5) * 16 * s;
        const h = (28 + r() * 22) * s;
        beam(c, x + lean * 0.3, y + 2, x + lean, y - h, (1.8 + r()) * s, 'reed', { lip: 0.9 });
        form(c, (g) => {
          g.moveTo(x + lean, y - h);
          g.quadraticCurveTo(x + lean + 2.4 * s, y - h - 5 * s, x + lean, y - h - 9 * s);
          g.quadraticCurveTo(x + lean - 2.4 * s, y - h - 5 * s, x + lean, y - h);
        }, 'reed', { lip: 0.9, tint: [124, 96, 52], tintAmt: 0.4 });
      }
      cord(c, x - 9 * s, y - 20 * s, x + 9 * s, y - 20 * s, 2.6 * s, 'rope');
    },
    rootknot: function (c, x, y, s, r) {
      cast(c, x, y, 30 * s, 20 * s, 0.34);
      mass(c, x, y - 12 * s, 20 * s, 13 * s, 'darkwood', { lip: 2.4 });
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * 6.283;
        const L = (18 + r() * 24) * s;
        const ex = x + Math.cos(a) * L, ey = y - 6 * s + Math.sin(a) * L * 0.42;
        beam(c, x, y - 10 * s, ex, ey, (4.4 - Math.abs(Math.sin(a)) * 1.6) * s, 'darkwood', { lip: 1.4 });
        mass(c, ex, ey, 2.6 * s, 2.0 * s, 'darkwood', { lip: 1.0 });
      }
      c.save(); c.globalAlpha = 0.30; c.fillStyle = rgb([96, 118, 74]);
      for (let i = 0; i < 9; i++) {
        c.beginPath();
        c.ellipse(x + (r() - 0.5) * 42 * s, y - 14 * s - r() * 12 * s, 2.8 * s, 1.8 * s, r(), 0, 6.3);
        c.fill();
      }
      c.restore();
    },
  };

  //===========================================================================
  // Public entry points
  //===========================================================================

  /**
   * Draw one piece of furniture at a point.
   * @param {CanvasRenderingContext2D} c the context
   * @param {string} key a key of BivouacCore.FURNITURE
   * @param {number} x foot x @param {number} y foot y
   * @param {number} scale 1 is nominal
   * @param {function():number} r a seeded stream
   * @returns {boolean} whether a construction existed for that key
   */
  D.piece = function (c, key, x, y, scale, r) {
    const f = D.PIECE_DRAW[key];
    if (!f) return false;
    c.save();
    f(c, x, y, Core.clamp(scale, 0.2, 4), r);
    c.restore();
    return true;
  };

  /**
   * Every key this file can actually draw, by family. Exported so a probe can
   * compare it against the vocabulary tables rather than against a typed number.
   * @returns {{grounds: string[], marks: string[], furniture: string[]}}
   */
  D.corpus = function () {
    return {
      grounds: Object.keys(D.GROUND_DRAW),
      marks: Object.keys(D.MARK_DRAW),
      furniture: Object.keys(D.PIECE_DRAW),
    };
  };

  /**
   * Draw a whole program, in program order.
   * @param {CanvasRenderingContext2D} c the context
   * @param {Object} program from BivouacCore.plan
   * @param {Object} [opts] {shadowStrength:number}
   * @returns {{drawn: number, skipped: string[]}} what happened
   */
  D.render = function (c, program, opts) {
    const o = opts || {};
    let drawn = 0;
    const skipped = [];
    for (const op of program.ops) {
      if (op.op === 'apron') { D.apron(c, op); drawn++; }
      else if (op.op === 'mark') {
        const f = D.MARK_DRAW[op.mark];
        if (!f) { skipped.push('mark:' + op.mark); continue; }
        c.save();
        // ⛔ A scatter mark outside the worked ground reads as litter dropped on
        // the battleback (measured: bone scatter below the apron edge on the
        // stock Treant). An `approach` mark carries no clip on purpose - tracks
        // are supposed to come in from off the ground.
        if (op.clip && op.clip.length) {
          c.beginPath(); apronPath(c, op.clip); c.closePath(); c.clip();
        }
        f(c, op);
        c.restore(); drawn++;
      } else if (op.op === 'furniture') {
        const r = Core.rng(op.seed);
        if (!D.piece(c, op.piece, op.x, op.y, op.scale, r)) { skipped.push('furniture:' + op.piece); continue; }
        drawn++;
      } else if (op.op === 'shadow') {
        cast(c, op.x, op.y, 20 * op.weight, 46 * op.weight,
          o.shadowStrength == null ? 0.40 : o.shadowStrength);
        drawn++;
      } else skipped.push('op:' + op.op);
    }
    return { drawn: drawn, skipped: skipped };
  };

  D.VERSION = '1.0.0';
}(BivouacDraw));

if (typeof module !== 'undefined' && module.exports) module.exports = BivouacDraw;
