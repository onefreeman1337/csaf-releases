//=============================================================================
// Bivouac.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Bivouac - every enemy band stages its own ground. Reads your troops and
 * draws the earth they hold, what they brought and the marks they leave. Place BELOW BivouacCore
 * and BivouacDraw.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * Bivouac
 * ============================================================================
 *
 * MZ gives every enemy the same nothing to stand on. A goblin rabble and a
 * demon lord float at the same height over the same battleback, casting no
 * shadow, leaving no trace, surrounded by no sign that anything lives there.
 *
 * Bivouac reads the troop you already made and draws the ground that band
 * holds: a trodden apron shaped by where its members actually stand, cast
 * shadows that seat every battler on it, the things the band brought and set
 * down, and the marks it has left behind.
 *
 * Nothing is loaded from an image file. There is no battleback to draw, no
 * pack to buy and nothing to place by hand. It reads what is already in your
 * database.
 *
 * ----------------------------------------------------------------------------
 * WHAT IT READS, AND WHAT IT DOES WITH IT
 * ----------------------------------------------------------------------------
 * MEMBER POSITIONS   the apron takes its shape from the formation itself.
 * PARAMETERS         each creature's own parameter profile decides its nature:
 *                    raider, warded, quick, adept or great. The nature of the
 *                    band's heaviest member decides which families of furniture
 *                    it fields and which ground it stands on.
 * EXPERIENCE         a band's standing is its place in YOUR OWN enemy database,
 *                    not a number this plugin invented. Five tiers: rabble,
 *                    band, warband, host, champion. Standing buys presence: a
 *                    rabble gets crates and a spit, a champion gets a dais.
 * ELEMENT TRAITS     what a band strikes with sets the earth under it. Fire
 *                    scorches, ice rimes, water mires, earth bakes it hard.
 * BATTLES FOUGHT     a band you keep fighting wears its own ground down.
 *
 * ----------------------------------------------------------------------------
 * INSTALLING
 * ----------------------------------------------------------------------------
 * Plugin Manager order, top to bottom:
 *
 *     BivouacCore.js      (the reading and the composition)
 *     BivouacDraw.js      (the constructions)
 *     Bivouac.js          (this file: parameters, commands, the engine)
 *
 * Nothing else needs changing. Start a battle.
 *
 * ----------------------------------------------------------------------------
 * COMPATIBILITY
 * ----------------------------------------------------------------------------
 * Bivouac adds one sprite to the battle field, behind every battler and in
 * front of the battleback. It extends three engine methods and replaces none,
 * so a plugin that also extends them keeps working whichever order they load
 * in. See the listing for the generated compatibility block.
 *
 * ----------------------------------------------------------------------------
 * PLUGIN COMMANDS
 * ----------------------------------------------------------------------------
 * Set Enabled            turn the staging on or off from an event.
 * Force Ground           make the next battles use one named ground, whatever
 *                        the band would have chosen. Useful for a story fight.
 * Clear Forced Ground    go back to reading the band.
 * Reset Wear             forget how many times a troop has been fought.
 *
 * ============================================================================
 * TERMS OF USE
 * ============================================================================
 * Commercial and non-commercial use permitted in RPG Maker projects, credit
 * appreciated but not required. Do not redistribute the source as an asset
 * pack. Every line of this plugin was written with AI assistance.
 *
 * ============================================================================
 *
 * @param enabled
 * @text Enabled
 * @type boolean
 * @desc Draw staged ground in battle. Turn off to restore stock MZ behaviour.
 * @default true
 *
 * @param drawApron
 * @text Draw the ground
 * @type boolean
 * @desc The worked earth the band stands on.
 * @default true
 *
 * @param drawMarks
 * @text Draw the marks
 * @type boolean
 * @desc Tracks leading in, and what the band has left on the ground.
 * @default true
 *
 * @param drawFurniture
 * @text Draw the furniture
 * @type boolean
 * @desc What the band brought and set down.
 * @default true
 *
 * @param drawShadows
 * @text Draw cast shadows
 * @type boolean
 * @desc Seats every battler on the ground. Turn off if another plugin already
 * draws battler shadows.
 * @default true
 *
 * @param shadowStrength
 * @text Shadow strength
 * @type number
 * @min 0
 * @max 100
 * @desc How dark the cast shadows are, as a percentage.
 * @default 40
 *
 * @param opacity
 * @text Overall opacity
 * @type number
 * @min 0
 * @max 255
 * @desc Opacity of the whole staged layer.
 * @default 255
 *
 * @param offsetY
 * @text Vertical offset
 * @type number
 * @min -400
 * @max 400
 * @desc Nudge the whole staging up or down, for battlebacks with an unusual
 * horizon.
 * @default 0
 *
 * @param wearFromBattles
 * @text Wear from repeat battles
 * @type boolean
 * @desc Fighting the same troop again wears its ground and its belongings.
 * @default true
 *
 * @command setEnabled
 * @text Set Enabled
 * @desc Turn the staged ground on or off.
 *
 * @arg value
 * @text Enabled
 * @type boolean
 * @default true
 *
 * @command forceGround
 * @text Force Ground
 * @desc Use one named ground for every battle until cleared.
 *
 * @arg ground
 * @text Ground
 * @type select
 * @option trodden
 * @option hardpan
 * @option ashbed
 * @option rime
 * @option mire
 * @option scorch
 * @option blight
 * @option drift
 * @option flagstone
 * @option sward
 * @default trodden
 *
 * @command clearGround
 * @text Clear Forced Ground
 * @desc Go back to reading the band.
 *
 * @command resetWear
 * @text Reset Wear
 * @desc Forget how many times troops have been fought.
 *
 * @arg troopId
 * @text Troop id
 * @type number
 * @min 0
 * @desc 0 forgets every troop.
 * @default 0
 */

'use strict';

var Bivouac = Bivouac || {};

(function (M) {
  const NAME = 'Bivouac';
  const SCHEMA = 1;

  //===========================================================================
  // Parameters
  //===========================================================================

  const raw = (typeof PluginManager !== 'undefined') ? PluginManager.parameters(NAME) : {};

  /** A blank parameter is ABSENT, never zero. Number('') is 0 and that is a trap. */
  function num(key, dflt) {
    const v = raw[key];
    if (v === undefined || v === null || String(v).trim() === '') return dflt;
    const n = Number(v);
    return isFinite(n) ? n : dflt;
  }

  /** A boolean parameter arrives as the STRING "true" or "false". */
  function bool(key, dflt) {
    const v = raw[key];
    if (v === undefined || v === null || String(v).trim() === '') return dflt;
    return String(v) === 'true';
  }

  M.params = {
    enabled: bool('enabled', true),
    drawApron: bool('drawApron', true),
    drawMarks: bool('drawMarks', true),
    drawFurniture: bool('drawFurniture', true),
    drawShadows: bool('drawShadows', true),
    shadowStrength: Math.max(0, Math.min(100, num('shadowStrength', 40))) / 100,
    opacity: Math.max(0, Math.min(255, num('opacity', 255))),
    offsetY: num('offsetY', 0),
    wearFromBattles: bool('wearFromBattles', true),
  };

  //===========================================================================
  // Siblings, resolved at FIRST USE.
  //
  // The Plugin Manager loads plugins in the order the BUYER set, and a test for
  // `typeof BivouacCore` at load time answers a question about that order rather
  // than about whether the plugin is installed. Everything that needs a sibling
  // asks for it here, when it is actually needed.
  //===========================================================================

  let _deps = null;

  /**
   * @returns {{core: Object, draw: Object}|null} the siblings, or null with one
   *   console error if the buyer has not installed them.
   */
  function deps() {
    if (_deps) return _deps;
    const core = (typeof BivouacCore !== 'undefined') ? BivouacCore : null;
    const draw = (typeof BivouacDraw !== 'undefined') ? BivouacDraw : null;
    if (!core || !draw) {
      if (!deps._warned) {
        deps._warned = true;
        console.error('Bivouac: BivouacCore.js and BivouacDraw.js must both be installed and '
          + 'listed ABOVE Bivouac.js in the Plugin Manager. Staging is off.');
      }
      return null;
    }
    _deps = { core: core, draw: draw };
    return _deps;
  }

  //===========================================================================
  // Persistence. A versioned record, so a save made today loads in any later
  // version without losing what it knows.
  //===========================================================================

  /**
   * @returns {Object} the plugin's own save record, created on first use
   */
  function store() {
    if (typeof $gameSystem === 'undefined' || !$gameSystem) return { v: SCHEMA, fought: {}, off: false, ground: null };
    if (!$gameSystem._csafBivouac || $gameSystem._csafBivouac.v == null) {
      $gameSystem._csafBivouac = { v: SCHEMA, fought: {}, off: false, ground: null };
    }
    const s = $gameSystem._csafBivouac;
    // Forward-compatible: a record written by a later version keeps its own
    // fields, and anything this version needs is filled in rather than reset.
    if (!s.fought) s.fought = {};
    if (s.off == null) s.off = false;
    if (s.ground === undefined) s.ground = null;
    return s;
  }
  M.store = store;

  /** @param {number} troopId the troop @returns {number} battles fought against it */
  M.timesFought = function (troopId) {
    const n = Number(store().fought[troopId]);
    return isFinite(n) ? n : 0;
  };

  /** Count one more battle against a troop. */
  M.noteFought = function (troopId) {
    if (!M.params.wearFromBattles) return;
    const id = Number(troopId);
    if (!isFinite(id) || id <= 0) return;
    const s = store();
    s.fought[id] = M.timesFought(id) + 1;
  };

  /** @returns {boolean} whether staging should draw right now */
  M.isActive = function () {
    if (!M.params.enabled) return false;
    return !store().off;
  };

  //===========================================================================
  // Composing the staged ground for the current troop
  //===========================================================================

  /**
   * Build the program for whatever troop is currently set up.
   * @returns {Object|null} a program, or null if it cannot or should not draw
   */
  M.programForCurrentTroop = function () {
    const d = deps();
    if (!d) return null;
    if (typeof $gameTroop === 'undefined' || !$gameTroop) return null;
    const troopId = $gameTroop._troopId;
    const data = (typeof $dataTroops !== 'undefined' && $dataTroops) ? $dataTroops[troopId] : null;
    if (!data) return null;

    const program = d.core.compose(data, $dataEnemies, {
      timesFought: M.timesFought(troopId),
      fieldW: Graphics.boxWidth,
      fieldH: Graphics.boxHeight,
      apron: M.params.drawApron,
      marks: M.params.drawMarks,
      furniture: M.params.drawFurniture,
      shadows: M.params.drawShadows,
    });

    const forced = store().ground;
    if (forced && d.core.GROUNDS[forced]) {
      for (const op of program.ops) {
        if (op.op === 'apron') {
          op.ground = forced;
          op.chroma = d.core.GROUNDS[forced].chroma.slice();
          op.grain = d.core.GROUNDS[forced].grain;
          op.rough = d.core.GROUNDS[forced].rough;
        }
      }
      program.meta.ground = forced;
      program.meta.forcedGround = true;
    }
    return program;
  };

  /**
   * Bake a program onto one Bitmap.
   *
   * This happens ONCE, when the battle scene builds its field. Nothing here runs
   * per frame: the result is a single static sprite, so the staged ground costs
   * one draw call for the whole composition however many pieces it contains.
   *
   * @param {Object} program from BivouacCore
   * @returns {Bitmap|null} the baked bitmap
   */
  M.bake = function (program) {
    const d = deps();
    if (!d || !program) return null;
    const w = Graphics.boxWidth;
    const h = Graphics.boxHeight;
    const bmp = new Bitmap(w, h);
    const ctx = bmp.context;
    ctx.save();
    const result = d.draw.render(ctx, program, { shadowStrength: M.params.shadowStrength });
    ctx.restore();
    bmp._baseTexture.update();
    M.lastRender = result;
    M.lastProgram = program;
    if (result.skipped.length) {
      console.warn('Bivouac: ' + result.skipped.length + ' op(s) had no construction and were '
        + 'skipped: ' + result.skipped.join(', '));
    }
    return bmp;
  };

  //===========================================================================
  // Engine seams. Three extensions, no replacements: the original is saved AND
  // called in every one of them.
  //===========================================================================

  const _Spriteset_Battle_createBattleField = Spriteset_Battle.prototype.createBattleField;
  Spriteset_Battle.prototype.createBattleField = function () {
    _Spriteset_Battle_createBattleField.call(this);
    this.csafCreateBivouac();
  };

  /**
   * Add the staged ground to the battle field. Called after the field exists and
   * before any battler sprite is added to it, so the staging is behind them all.
   */
  Spriteset_Battle.prototype.csafCreateBivouac = function () {
    this._csafBivouacSprite = null;
    if (!M.isActive()) return;
    const program = M.programForCurrentTroop();
    if (!program) return;
    const bmp = M.bake(program);
    if (!bmp) return;
    const sprite = new Sprite(bmp);
    sprite.y = M.params.offsetY;
    sprite.opacity = M.params.opacity;
    this._csafBivouacSprite = sprite;
    this._battleField.addChild(sprite);
  };

  const _BattleManager_setup = BattleManager.setup;
  BattleManager.setup = function (troopId, canEscape, canLose) {
    _BattleManager_setup.call(this, troopId, canEscape, canLose);
    M.noteFought(troopId);
  };

  const _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () {
    _Game_System_initialize.call(this);
    this._csafBivouac = { v: SCHEMA, fought: {}, off: false, ground: null };
  };

  //===========================================================================
  // Plugin commands
  //===========================================================================

  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
    PluginManager.registerCommand(NAME, 'setEnabled', function (args) {
      store().off = !(String(args.value) === 'true');
    });
    PluginManager.registerCommand(NAME, 'forceGround', function (args) {
      const d = deps();
      const g = String(args.ground || '').trim();
      if (d && d.core.GROUNDS[g]) store().ground = g;
    });
    PluginManager.registerCommand(NAME, 'clearGround', function () {
      store().ground = null;
    });
    PluginManager.registerCommand(NAME, 'resetWear', function (args) {
      const id = Number(args.troopId);
      const s = store();
      if (!isFinite(id) || id <= 0) s.fought = {};
      else delete s.fought[id];
    });
  }

  M.VERSION = '1.0.0';
  M.SCHEMA = SCHEMA;
  M.deps = deps;
}(Bivouac));
