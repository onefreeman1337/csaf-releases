//=============================================================================
// BivouacCore.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Bivouac Core - reads an enemy troop and composes the ground that band
 * holds, as a draw program. Pure generator; no engine calls. Place ABOVE Bivouac.js.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * BivouacCore.js
 * ============================================================================
 *
 * This file contains NO engine calls and NO rendering. It answers two questions
 * and nothing else:
 *
 *   read(troop, enemies, opts)  ->  a READING   (what kind of band is this?)
 *   plan(reading, opts)         ->  a PROGRAM   (what should be drawn, where?)
 *
 * A PROGRAM is plain data: an ordered array of ops, each with explicit
 * coordinates, sizes and materials. That is deliberate. It means the whole
 * composition can be tested in Node without a canvas, and it means the renderer
 * in Bivouac.js is thin enough to read in one sitting.
 *
 * Nothing in here calls Math.random(). Every choice comes from a seeded stream
 * derived from the troop id, so the same band composes the same ground on every
 * machine and in every save file.
 *
 * ----------------------------------------------------------------------------
 * WHAT IT READS
 * ----------------------------------------------------------------------------
 * From the troop:      each member's enemy id and its x / y on the battle field.
 * From each enemy:     the eight parameters, exp, gold, and the element rate
 *                      traits (code 11) and attack element traits (code 31).
 * From the project:    the exp and hp distribution of EVERY enemy in the
 *                      database, so "strong" means strong FOR THIS GAME rather
 *                      than strong against a number we picked.
 *
 * ----------------------------------------------------------------------------
 * TERMS
 * ----------------------------------------------------------------------------
 * NATURE    what a creature does, read off its own parameter profile:
 *           raider (attack-led), warded (defence-led), quick (agility-led),
 *           adept (magic-led), great (vitality-led).
 * STANDING  where the band sits in this project's own strength distribution:
 *           rabble, band, warband, host, champion.
 * GROUND    the worked earth the band stands on.
 * FURNITURE what the band brought and set down.
 * MARKS     what the band has left on the ground.
 *
 * ============================================================================
 * TERMS OF USE
 * ============================================================================
 * Commercial and non-commercial use permitted in RPG Maker projects.
 * Do not redistribute the source as an asset pack.
 *
 * @param placeholder
 * @text (no parameters)
 * @desc BivouacCore has no parameters of its own. Configure Bivouac.js instead.
 * @default
 */

'use strict';

var BivouacCore = BivouacCore || {};

(function (B) {
  //===========================================================================
  // Seeded randomness. There is exactly one source, and it is never Math.random.
  //===========================================================================

  /**
   * mulberry32 - a small, fast, well-distributed 32-bit PRNG.
   * @param {number} seed any integer
   * @returns {function(): number} a stream returning [0,1)
   */
  B.rng = function (seed) {
    let a = (seed >>> 0) || 1;
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  };

  /**
   * A stable 32-bit hash of a string, so a band's NAME can seed a choice
   * without depending on the order ids happen to fall in.
   * @param {string} s the text
   * @returns {number} the hash
   */
  B.hash = function (s) {
    let h = 2166136261 >>> 0;
    const t = String(s == null ? '' : s);
    for (let i = 0; i < t.length; i++) {
      h ^= t.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return h >>> 0;
  };

  /** @param {function():number} r stream @param {Array} a list @returns {*} one item */
  function pick(r, a) { return a[Math.floor(r() * a.length) % a.length]; }

  /** Clamp with a NaN guard. A NaN must never reach a threshold (wing doctrine). */
  function clamp(v, lo, hi) {
    const n = Number(v);
    if (!isFinite(n)) return lo;
    return n < lo ? lo : (n > hi ? hi : n);
  }

  B.pick = pick;
  B.clamp = clamp;

  //===========================================================================
  // The vocabulary. Every entry here is a DISTINCT DRAWN ENTITY with its own
  // construction in the renderer - not a recolour of its neighbour.
  //===========================================================================

  /**
   * GROUND treatments. `fill` and `detail` name renderer constructions;
   * `chroma` is the ground's own hue family.
   */
  B.GROUNDS = {
    trodden: { chroma: [104, 86, 62], grain: 'scuff', rough: 0.55 },
    hardpan: { chroma: [140, 122, 94], grain: 'crack', rough: 0.30 },
    ashbed: { chroma: [86, 82, 80], grain: 'flake', rough: 0.70 },
    rime: { chroma: [156, 170, 182], grain: 'needle', rough: 0.45 },
    mire: { chroma: [72, 66, 48], grain: 'churn', rough: 0.85 },
    scorch: { chroma: [58, 44, 38], grain: 'cinder', rough: 0.65 },
    blight: { chroma: [84, 88, 62], grain: 'blotch', rough: 0.60 },
    drift: { chroma: [178, 156, 116], grain: 'ripple', rough: 0.35 },
    flagstone: { chroma: [118, 116, 112], grain: 'joint', rough: 0.20 },
    sward: { chroma: [92, 108, 66], grain: 'tuft', rough: 0.50 },
  };

  /**
   * MARKS - what the band has left on the ground. Each is its own construction.
   */
  B.MARKS = {
    boottrack: { weight: 1.0, follows: 'approach' },
    clawtrack: { weight: 1.0, follows: 'approach' },
    hooftrack: { weight: 1.0, follows: 'approach' },
    dragtrack: { weight: 1.1, follows: 'approach' },
    slithertrack: { weight: 0.9, follows: 'approach' },
    cartrut: { weight: 1.2, follows: 'approach' },
    bloodslick: { weight: 0.8, follows: 'scatter' },
    scorchlick: { weight: 0.8, follows: 'scatter' },
    webstrand: { weight: 0.7, follows: 'span' },
    frostcreep: { weight: 0.7, follows: 'scatter' },
    sporebloom: { weight: 0.6, follows: 'scatter' },
    bonescatter: { weight: 0.6, follows: 'scatter' },
    gouge: { weight: 0.9, follows: 'scatter' },
    wardring: { weight: 1.0, follows: 'ring' },
  };

  /**
   * FURNITURE - what the band brought and set down. `bulk` is how much room the
   * piece wants (renderer scales to it); `stand` is the lowest standing tier
   * that may own it, so a rabble never fields a throne.
   */
  B.FURNITURE = {
    campfire: { bulk: 0.9, stand: 0, tags: ['camp', 'warm'] },
    cookpot: { bulk: 0.7, stand: 0, tags: ['camp'] },
    spit: { bulk: 0.9, stand: 0, tags: ['camp', 'meat'] },
    bedroll: { bulk: 0.6, stand: 0, tags: ['camp'] },
    leanto: { bulk: 1.2, stand: 0, tags: ['camp'] },
    stackedarms: { bulk: 0.9, stand: 1, tags: ['war'] },
    shieldrest: { bulk: 0.9, stand: 1, tags: ['war'] },
    wardrum: { bulk: 0.8, stand: 2, tags: ['war', 'rite'] },
    standard: { bulk: 1.4, stand: 2, tags: ['war', 'rank'] },
    palisade: { bulk: 1.5, stand: 1, tags: ['dug'] },
    chevaux: { bulk: 1.1, stand: 1, tags: ['dug', 'war'] },
    totem: { bulk: 1.3, stand: 1, tags: ['rite'] },
    altar: { bulk: 1.1, stand: 2, tags: ['rite'] },
    brazier: { bulk: 0.8, stand: 1, tags: ['rite', 'warm'] },
    carrionpost: { bulk: 1.1, stand: 1, tags: ['rite', 'grim'] },
    bonemidden: { bulk: 0.8, stand: 0, tags: ['grim'] },
    cage: { bulk: 1.0, stand: 1, tags: ['grim', 'spoil'] },
    spoilpile: { bulk: 0.8, stand: 1, tags: ['spoil'] },
    crates: { bulk: 0.9, stand: 0, tags: ['spoil', 'camp'] },
    // ⛔ stand 4, not 3: at 3 the stock HOST and the stock CHAMPION both fielded a
    // dais and their furniture sets became identical (wing §25g - a rank axis
    // nothing draws differently is decorative). A dais is the top of the ladder.
    dais: { bulk: 1.6, stand: 4, tags: ['rank'] },
    hidedryer: { bulk: 1.1, stand: 0, tags: ['camp', 'craft'] },
    anvilstone: { bulk: 0.8, stand: 1, tags: ['craft'] },
    cocoon: { bulk: 1.0, stand: 0, tags: ['nest'] },
    fungalcluster: { bulk: 0.7, stand: 0, tags: ['nest'] },
    icecairn: { bulk: 0.9, stand: 1, tags: ['nest', 'rite'] },
    cindervent: { bulk: 0.8, stand: 1, tags: ['nest'] },
    reedbundle: { bulk: 0.7, stand: 0, tags: ['nest', 'craft'] },
    rootknot: { bulk: 1.2, stand: 0, tags: ['nest'] },
  };

  /**
   * How much ground a piece of furniture covers, as a half-width in pixels.
   *
   * ⛔ ONE DEFINITION, TWO CONSUMERS (wing §11a: a second copy of a constant does
   * not drift, it WINS). The placer uses this to keep a piece from overhanging
   * the apron and the suite uses it to check that none does; if those held
   * separate arithmetic the suite would be certifying its own copy rather than
   * the product's behaviour.
   *
   * @param {string} key a key of B.FURNITURE
   * @param {number} scale the drawn scale
   * @returns {number} the half-width in pixels
   */
  B.footprintHalf = function (key, scale) {
    const f = B.FURNITURE[key];
    return 34 * clamp(scale, 0.1, 8) * (f ? f.bulk : 1);
  };

  /**
   * The five natures, ordered so a TIE breaks toward the MORE SPECIFIC reading.
   *
   * ⛔ THE ORDER IS A MEASURED DECISION, NOT A LIST. Ties are common because MZ's
   * own enemies use round numbers: the stock Crow has attack 25 and agility 25,
   * so `raider` and `quick` score identically at 1.136 and whichever is tested
   * first wins. `raider` is the most generic reading of any creature - almost
   * everything attacks - so it is tested LAST, and `great` is tested first
   * because vitality is on a different scale and rarely ties anything.
   * Known-good case this was set against: stock Crow must read `quick`.
   */
  B.NATURES = ['great', 'adept', 'quick', 'warded', 'raider'];

  /** The five standings, weakest first. */
  B.STANDINGS = ['rabble', 'band', 'warband', 'host', 'champion'];

  /**
   * Every distinct drawn entity this product can put on the ground. Exported so
   * the volume claim is COUNTED from the same table the renderer reads, never
   * typed into a listing by hand.
   * @returns {{grounds: number, marks: number, furniture: number, total: number}}
   */
  B.volume = function () {
    const g = Object.keys(B.GROUNDS).length;
    const m = Object.keys(B.MARKS).length;
    const f = Object.keys(B.FURNITURE).length;
    return { grounds: g, marks: m, furniture: f, total: g + m + f };
  };

  //===========================================================================
  // READING - what kind of band is this?
  //===========================================================================

  /**
   * The project's own strength distribution, so "strong" means strong FOR THIS
   * GAME. Anchoring a tier to a number we invented is how a generator's range
   * dies on a buyer's database.
   * @param {Array<Object>} enemies every $dataEnemies row (holes allowed)
   * @returns {{exp: number[], hp: number[]}} sorted ladders
   */
  B.distribution = function (enemies) {
    const exp = [];
    const hp = [];
    for (const e of (enemies || [])) {
      if (!e) continue;
      const x = Number(e.exp);
      const h = Number(e.params && e.params[0]);
      if (isFinite(x)) exp.push(x);
      if (isFinite(h)) hp.push(h);
    }
    exp.sort((a, b) => a - b);
    hp.sort((a, b) => a - b);
    return { exp, hp };
  };

  /**
   * Where a value sits in a sorted ladder, 0..1. An empty ladder returns 0.5 -
   * an unknown, not a zero, because a zero would silently make every band a
   * rabble on a project we failed to read.
   * @param {number[]} ladder sorted ascending
   * @param {number} v the value
   * @returns {number} the percentile
   */
  B.percentile = function (ladder, v) {
    const n = Number(v);
    if (!ladder || ladder.length === 0 || !isFinite(n)) return 0.5;
    let below = 0;
    for (const x of ladder) { if (x < n) below++; }
    return clamp(below / ladder.length, 0, 1);
  };

  /**
   * A creature's nature, read off its own parameter profile relative to that
   * creature's own average. This is deliberately self-relative: a project where
   * every number is ten times larger must classify identically.
   * @param {Object} enemy a $dataEnemies row
   * @returns {{nature: string, scores: Object}} the reading
   */
  B.natureOf = function (enemy) {
    const p = (enemy && enemy.params) || [];
    const n = (i) => { const v = Number(p[i]); return isFinite(v) ? v : 0; };
    const mhp = n(0), mmp = n(1), atk = n(2), def = n(3), mat = n(4), mdf = n(5), agi = n(6);
    // Offensive/defensive stats share a scale in MZ; hp and mp do not, so hp is
    // compared against the others by its own ratio rather than added to them.
    const core = [atk, def, mat, mdf, agi];
    const mean = core.reduce((t, v) => t + v, 0) / core.length || 1;
    const scores = {
      raider: atk / mean,
      warded: (def + mdf) / (2 * mean),
      // ⛔ The magic pool MULTIPLIES an existing magical lead; it must never be a
      // flat bonus. Added, it out-voted the actual stat lead: MZ's stock Crow
      // (agi 25, mat 20, mp 50) classified `adept` over `quick` by 0.023, so a
      // bird with a mana bar was drawing an altar and a war drum.
      adept: (mat / mean) * (mmp > 0 ? 1.15 : 1.0),
      quick: agi / mean,
      great: mhp / (mean * 12),
    };
    let best = B.NATURES[0];
    for (const k of B.NATURES) { if (scores[k] > scores[best] + 1e-9) best = k; }
    return { nature: best, scores };
  };

  /**
   * The elements a creature deals in: what it strikes with (trait code 31) and
   * what it fears or shrugs off (trait code 11).
   * @param {Object} enemy a $dataEnemies row
   * @returns {{strikes: number[], weakTo: number[], resists: number[]}}
   */
  B.elementsOf = function (enemy) {
    const out = { strikes: [], weakTo: [], resists: [] };
    for (const t of ((enemy && enemy.traits) || [])) {
      if (!t) continue;
      const id = Number(t.dataId);
      const v = Number(t.value);
      if (t.code === 31 && isFinite(id) && id > 0) out.strikes.push(id);
      if (t.code === 11 && isFinite(id) && id > 0 && isFinite(v)) {
        if (v > 1.001) out.weakTo.push(id);
        else if (v < 0.999) out.resists.push(id);
      }
    }
    return out;
  };

  /**
   * Read a troop into a band.
   * @param {Object} troop a $dataTroops row: {id, name, members:[{enemyId,x,y,hidden}]}
   * @param {Array<Object>} enemies every $dataEnemies row
   * @param {Object} [opts] {timesFought:number, fieldW:number, fieldH:number}
   * @returns {Object} the reading
   */
  B.read = function (troop, enemies, opts) {
    const o = opts || {};
    const fieldW = Number(o.fieldW) > 0 ? Number(o.fieldW) : 816;
    const fieldH = Number(o.fieldH) > 0 ? Number(o.fieldH) : 624;
    const dist = B.distribution(enemies);
    const rows = ((troop && troop.members) || []).filter((m) => m && enemies[m.enemyId]);

    const members = rows.map((m) => {
      const e = enemies[m.enemyId];
      const nat = B.natureOf(e);
      const hp = Number((e.params || [])[0]) || 0;
      return {
        enemyId: m.enemyId,
        name: String(e.name || ''),
        x: clamp(m.x, -400, fieldW + 400),
        y: clamp(m.y, -400, fieldH + 400),
        hidden: !!m.hidden,
        nature: nat.nature,
        scores: nat.scores,
        elements: B.elementsOf(e),
        hp: hp,
        exp: Number(e.exp) || 0,
        gold: Number(e.gold) || 0,
        // Footprint: how much ground this creature covers. Derived from its own
        // vitality percentile in the project, so it scales with any numbers.
        weight: clamp(0.55 + B.percentile(dist.hp, hp) * 0.95, 0.4, 1.8),
      };
    });

    const visible = members.filter((m) => !m.hidden);
    const use = visible.length ? visible : members;

    // Standing: the band's total experience against the project's own ladder,
    // nudged by how many of them there are.
    const totalExp = use.reduce((t, m) => t + m.exp, 0);
    const bestExp = use.reduce((t, m) => Math.max(t, m.exp), 0);
    const pct = clamp(
      B.percentile(dist.exp, bestExp) * 0.72 + B.percentile(dist.exp, totalExp) * 0.28,
      0, 1
    );
    let tier = Math.floor(pct * B.STANDINGS.length);
    if (tier >= B.STANDINGS.length) tier = B.STANDINGS.length - 1;

    // Nature of the band: the nature of its heaviest member, with the count of
    // each nature kept so a mixed band can be drawn as mixed.
    const tally = {};
    for (const m of use) tally[m.nature] = (tally[m.nature] || 0) + 1;
    let lead = use[0];
    for (const m of use) { if (m.hp > (lead ? lead.hp : -1)) lead = m; }

    // The ground the band occupies, from the real member positions.
    const xs = use.map((m) => m.x);
    const ys = use.map((m) => m.y);
    const left = xs.length ? Math.min.apply(null, xs) : fieldW / 2;
    const right = xs.length ? Math.max.apply(null, xs) : fieldW / 2;
    const footY = ys.length ? Math.max.apply(null, ys) : fieldH * 0.7;
    const topY = ys.length ? Math.min.apply(null, ys) : footY;

    const elements = { strikes: [], weakTo: [], resists: [] };
    for (const m of use) {
      for (const k of ['strikes', 'weakTo', 'resists']) {
        for (const id of m.elements[k]) if (elements[k].indexOf(id) < 0) elements[k].push(id);
      }
    }

    return {
      troopId: Number(troop && troop.id) || 0,
      name: String((troop && troop.name) || ''),
      seed: (B.hash(String((troop && troop.name) || '') + '#' + (troop && troop.id)) ^ 0x9E3779B9) >>> 0,
      size: use.length,
      members: members,
      visible: use,
      lead: lead || null,
      nature: lead ? lead.nature : 'raider',
      natureTally: tally,
      standing: B.STANDINGS[tier],
      standingTier: tier,
      standingPct: pct,
      elements: elements,
      timesFought: Math.max(0, Math.floor(Number(o.timesFought) || 0)),
      field: { w: fieldW, h: fieldH },
      hull: {
        left: left, right: right, footY: footY, topY: topY,
        span: Math.max(48, right - left),
        centre: (left + right) / 2,
        depth: Math.max(28, footY - topY),
      },
    };
  };

  //===========================================================================
  // CHOOSING - which ground, which marks, which furniture
  //===========================================================================

  /** Element ids MZ ships by default, used only as a HINT and never required. */
  var ELEM = { FIRE: 2, ICE: 3, THUNDER: 4, WATER: 5, EARTH: 6, WIND: 7, LIGHT: 8, DARK: 9 };

  /**
   * The ground a band stands on. Element affinity leads where the band HAS one;
   * otherwise nature decides, so a project that sets no element traits at all
   * still gets a spread of grounds rather than one default.
   * @param {Object} rd a reading
   * @returns {string} a key of B.GROUNDS
   */
  B.groundFor = function (rd) {
    const s = rd.elements.strikes;
    const has = (id) => s.indexOf(id) >= 0;
    if (has(ELEM.FIRE)) return 'scorch';
    if (has(ELEM.ICE)) return 'rime';
    if (has(ELEM.WATER)) return 'mire';
    if (has(ELEM.EARTH)) return 'hardpan';
    if (has(ELEM.DARK)) return 'blight';
    if (has(ELEM.WIND)) return 'drift';
    const byNature = {
      raider: 'trodden', warded: 'flagstone', quick: 'sward',
      adept: 'ashbed', great: 'mire',
    };
    // ⛔ Standing must be VISIBLE, or two bands of different rank draw the same
    // object and the rank axis is decorative. The champion tier works its floor:
    // raw earth becomes worked ground. Measured need - the stock Treant (host)
    // and Hi_monster (champion) share a nature, so without this they shared a
    // ground and differed only by one furniture piece.
    const base = byNature[rd.nature] || 'trodden';
    if (rd.standingTier >= 4) {
      const worked = { trodden: 'hardpan', sward: 'flagstone', mire: 'hardpan', ashbed: 'scorch' };
      if (worked[base]) return worked[base];
    }
    return base;
  };

  /**
   * The marks a band leaves. Returns keys of B.MARKS, longest-lived first.
   * @param {Object} rd a reading
   * @returns {string[]} mark keys
   */
  B.marksFor = function (rd) {
    const out = [];
    const track = {
      raider: 'boottrack', warded: 'boottrack', quick: 'clawtrack',
      adept: 'dragtrack', great: 'hooftrack',
    }[rd.nature] || 'boottrack';
    out.push(track);
    if (rd.standingTier >= 3) out.push('cartrut');

    const s = rd.elements.strikes;
    if (s.indexOf(ELEM.FIRE) >= 0) out.push('scorchlick');
    if (s.indexOf(ELEM.ICE) >= 0) out.push('frostcreep');
    if (s.indexOf(ELEM.DARK) >= 0) out.push('bloodslick');

    if (rd.nature === 'quick' && out.indexOf('webstrand') < 0 && rd.size >= 2) out.push('webstrand');
    if (rd.nature === 'great') out.push('gouge');
    if (rd.nature === 'adept') out.push('wardring');
    if (rd.standingTier >= 2 && out.indexOf('bonescatter') < 0) out.push('bonescatter');
    if (rd.nature === 'warded' && rd.standingTier <= 1) out.push('sporebloom');

    // Never more marks than the ground can carry without reading as litter.
    const cap = 2 + rd.standingTier;
    return out.slice(0, cap);
  };

  /**
   * The furniture a band fields. A piece is eligible only if the band's standing
   * reaches it; the set is then drawn from the tag families its nature keeps.
   * @param {Object} rd a reading
   * @returns {string[]} furniture keys
   */
  B.furnitureFor = function (rd) {
    const r = B.rng(rd.seed ^ 0x51ED270B);
    const wanted = ({
      raider: ['war', 'camp', 'spoil'],
      warded: ['dug', 'war', 'craft'],
      quick: ['nest', 'camp', 'grim'],
      adept: ['rite', 'grim', 'nest'],
      great: ['nest', 'rite', 'grim'],
    }[rd.nature] || ['camp']).slice();

    // ⛔ MEASURED DEFECT, FIXED (wing §25g: the genuine defect is standing being
    // INVISIBLE). `standard` and `dais` are the only two pieces that say a band
    // has rank, and both are tagged `rank` - which appears in NO nature's wanted
    // list. So for a `great` or `quick` band they were unreachable, the forcing
    // rule below silently did nothing, and the stock host and the stock champion
    // came out with identical furniture. A band of rank wants rank BECAUSE of its
    // rank, not because of its nature.
    if (rd.standingTier >= 3) wanted.unshift('rank');

    const eligible = Object.keys(B.FURNITURE).filter((k) => {
      const f = B.FURNITURE[k];
      if (rd.standingTier < f.stand) return false;
      return f.tags.some((t) => wanted.indexOf(t) >= 0);
    });

    // How many pieces: standing buys presence, and a wide band has room for more.
    const room = clamp(Math.round(rd.hull.span / 190), 0, 2);
    let count = clamp(1 + rd.standingTier + room, 1, 6);
    // ⛔ AND THE GROUND HAS THE LAST WORD. Standing alone asked for five pieces on
    // a one-member champion whose apron is ~590 px wide, and the placer could not
    // seat them without standing one on the battler (measured: gaps of 42 and 52
    // against a 52 px requirement). Furniture that does not fit is not presence,
    // it is clutter - a narrow ground simply holds fewer, larger things.
    const widthCap = Math.max(2, Math.floor(B.apronBox(rd).w / 165));
    if (count > widthCap) count = widthCap;
    if (eligible.length === 0) return [];
    if (count > eligible.length) count = eligible.length;

    // Rank by how well a piece matches the band's leading family, then take the
    // top `count` deterministically. A shuffle here would let a champion field
    // nothing but bedrolls.
    const scored = eligible.map((k) => {
      const f = B.FURNITURE[k];
      let s = 0;
      f.tags.forEach((t) => { const i = wanted.indexOf(t); if (i >= 0) s += (3 - i); });
      s += f.stand * 0.6;               // grander pieces sort forward for grand bands
      s += r() * 0.9;                   // seeded tie-break, never a re-order
      return { k: k, s: s };
    }).sort((a, b) => b.s - a.s);

    const out = scored.slice(0, count).map((x) => x.k);
    // A band of rank always shows its rank. `standard` and `dais` are the only
    // two pieces that say so, so one of them is forced in rather than left to
    // the tie-break.
    if (rd.standingTier >= 3 && out.indexOf('dais') < 0 && out.indexOf('standard') < 0) {
      const want = rd.standingTier >= 4 ? 'dais' : 'standard';
      if (eligible.indexOf(want) >= 0) out[out.length - 1] = want;
    }
    return out;
  };

  //===========================================================================
  // PLANNING - where everything goes
  //===========================================================================

  /**
   * Anchor points around a formation, in the order a band fills them. Behind the
   * line first, because that is the space a battler sprite never occupies.
   * @param {Object} rd a reading
   * @returns {Array<{x:number,y:number,depth:number,slot:string}>}
   */
  B.anchors = function (rd) {
    const h = rd.hull;
    // ⛔ MEASURED DEFECT, FIXED: these spread by the HULL, and a hull is 48 px
    // wide when a troop has one member - so a champion's dais, altar, cairn and
    // carrion post were all placed within 20 px of each other and drew on top of
    // one another. Furniture stands on the APRON, so the apron is what it
    // spreads across. Derived from the same outline the renderer fills, never a
    // second copy of the arithmetic (wing §11a).
    const box = B.apronBox(rd);
    // ⛔ ANCHORS HANG OFF THE BAND'S OWN FOOT LINE, NOT OFF THE APRON'S BOX.
    // The apron deliberately runs off the bottom of the screen, so its box centre
    // is somewhere below the frame - anchoring to it put furniture in front of
    // the battlers while the staging sprite is drawn BEHIND them, which is a
    // z-order contradiction the picture cannot resolve. Everything is placed
    // relative to where the band actually stands.
    const foot = h.footY;
    // ⛔ THE DEPTHS HAVE TO BE GENUINELY APART. At `foot - 40` the back row and
    // the flanks sat ~30 px apart, so every piece competed for one narrow band of
    // ground and a five-piece champion could not be placed without overlaps
    // (measured by the suite: carrion post vs altar, gap 0). Pushing the back row
    // properly back both frees the solver and gives the scene a front and a back.
    // ⛔ AND IT MUST STILL BE ON THE APRON. Pushing the back row to `foot - 86`
    // put it ABOVE the apron's own top edge on every one-member troop, so
    // spanAt found no lane at all and the piece was placed against a fallback.
    // A depth is only meaningful inside the shape it is a depth into.
    const back = Math.max(box.y + 26, Math.min(h.topY - 40, foot - 86));
    const pts = B.apronOutline(rd);

    /**
     * A point on the apron at height y, `f` of the way out from the centre
     * (signed), measured against the apron's real width AT THAT HEIGHT.
     *
     * ⛔ THIS EXPRESSES A PREFERENCE, NOT A FINAL POSITION. Clearing battlers and
     * neighbours is done once, by the solver in plan(), because doing it here as
     * well was two solvers disagreeing - and its `|| {centre, half}` fallback had
     * no `left`/`right`, so the clearance arithmetic produced NaN coordinates
     * whenever the lane was missed.
     */
    const at = (y, f, slot, depth) => {
      const sp = B.spanAt(pts, y);
      const centre = sp ? sp.centre : box.cx;
      const half = sp ? sp.half : box.w / 2;
      return { slot: slot, x: centre + f * half * 0.88, y: y, depth: depth };
    };
    // ⛔ ORDER IS FILL ORDER, AND IT IS A MEASURED DECISION. Listed back-first,
    // a two-piece band took backCentre and backLeft and both landed in the same
    // upper-left corner with three quarters of the ground empty. Alternating
    // left and right of centre means the FIRST TWO pieces already span the
    // apron, which is the common case: most troops field two or three.
    return [
      at(foot + 14, -0.80, 'flankLeft', 0.60),
      at(foot + 8, 0.80, 'flankRight', 0.58),
      // ⛔ backCentre IS THE MOST CONFLICTED SLOT AND SO IT IS FILLED LAST. A
      // one-member troop stands at the apron's centre, which is exactly where
      // this anchor is, and near the apron's top edge the ground is too narrow
      // for the solver to move a piece the 52 px it needs. Every other back slot
      // is already offset, so ordering costs nothing and removes the conflict.
      at(back + 16, -0.46, 'backLeft', 0.28),
      at(back + 12, 0.47, 'backRight', 0.28),
      at(back, 0.00, 'backCentre', 0.22),
      at(foot + 62, -0.55, 'foreLeft', 0.90),
      at(foot + 56, 0.56, 'foreRight', 0.90),
    ];
  };

  /**
   * Where the apron's edges are at a given height, by intersecting a horizontal
   * line with the real outline polygon.
   *
   * ⛔ THE BOUNDING BOX IS THE WRONG ANSWER FOR PLACEMENT AND IT LOOKS LIKE THE
   * RIGHT ONE. An apron is widest across its middle, so a piece placed at a
   * fraction of the BOX width but at a height near the top or bottom lands
   * outside the shape - measured: flank furniture hung off the edge on four of
   * five stock troops, standing on the battleback with nothing under it.
   *
   * @param {Array<{x:number,y:number}>} pts the outline
   * @param {number} y the height to measure at
   * @returns {{left:number, right:number, half:number, centre:number}|null}
   */
  B.spanAt = function (pts, y) {
    let lo = Infinity, hi = -Infinity;
    for (let i = 0; i < pts.length; i++) {
      const a = pts[i];
      const b = pts[(i + 1) % pts.length];
      if ((a.y <= y && b.y >= y) || (b.y <= y && a.y >= y)) {
        const d = (b.y - a.y);
        const t = Math.abs(d) < 1e-9 ? 0 : (y - a.y) / d;
        const x = a.x + (b.x - a.x) * t;
        if (x < lo) lo = x;
        if (x > hi) hi = x;
      }
    }
    if (!isFinite(lo) || !isFinite(hi)) return null;
    return { left: lo, right: hi, half: (hi - lo) / 2, centre: (lo + hi) / 2 };
  };

  /**
   * The bounding box of the apron, computed from the apron outline itself so
   * nothing ever holds a second copy of the apron's size.
   * @param {Object} rd a reading
   * @returns {{x:number,y:number,w:number,h:number,cx:number,cy:number}}
   */
  B.apronBox = function (rd) {
    const pts = B.apronOutline(rd);
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    for (const p of pts) {
      if (p.x < x0) x0 = p.x; if (p.x > x1) x1 = p.x;
      if (p.y < y0) y0 = p.y; if (p.y > y1) y1 = p.y;
    }
    return { x: x0, y: y0, w: x1 - x0, h: y1 - y0, cx: (x0 + x1) / 2, cy: (y0 + y1) / 2 };
  };

  /**
   * The outline of the worked ground, as a closed polygon in field coordinates.
   *
   * The shape comes from the real member positions - it is the one thing in a
   * troop that nothing else in the database carries - but a formation is often
   * a straight line, so the apron also takes its DEPTH from the band's mass.
   * An apron derived from the hull alone would be a sliver on the stock data.
   *
   * @param {Object} rd a reading
   * @returns {Array<{x:number,y:number}>} the polygon, clockwise from top-left
   */
  B.apronOutline = function (rd) {
    const r = B.rng(rd.seed ^ 0x2545F491);
    const h = rd.hull;
    const mass = rd.visible.reduce((t, m) => t + m.weight, 0);
    const pad = clamp(46 + mass * 26, 56, 210);
    // ⛔ MEASURED DEFECT, FIXED: sizing the apron from the hull ALONE produced a
    // floating island. MZ's own troops are 1-2 members inside a 144 px span on
    // an 816 px field, so hull+pad gave a 350 px patch with a visible edge all
    // round it - it read as a raft rather than as the ground of a battlefield.
    // The apron is therefore never narrower than a share of the FIELD.
    const halfW = Math.max(h.span / 2 + pad, rd.field.w * 0.36);
    const depth = clamp(Math.max(h.depth + pad * 0.92, rd.field.h * 0.22), 74, 300);
    const cx = h.centre;

    // ⛔⛔ THE APRON IS BUILT FROM ITS TOP AND BOTTOM, NOT FROM A CENTRE, AND THE
    // FIRST TRY GOT THIS WRONG IN BOTH DIRECTIONS.
    // A closed ellipse sitting inside the frame read as an ISLAND - a raft of mud
    // floating on the battleback. Recentring it low enough to leave the frame
    // then moved the whole apron BELOW the battlers' own feet, so the band stood
    // off its own ground and the furniture floated above it.
    // Ground behind the band is bounded by the band; ground in front of it runs
    // toward the viewer and leaves the screen. Those are two different edges and
    // they are computed separately.
    const top = h.topY - depth * 0.52;
    const bottom = Math.max(h.footY + depth * 0.55, rd.field.h + 56);
    const cy = (top + bottom) / 2;
    const ry = (bottom - top) / 2;

    // ⛔ A PLAIN ELLIPSE IS NARROWEST EXACTLY WHERE THE FURNITURE STANDS. The
    // apron runs off the bottom of the screen, so its widest point is below the
    // battlers, and everything placed BEHIND the band sits up in the tapering
    // top - measured: a champion's dais overhung the ground it was standing on.
    // A superellipse keeps its width much further toward the ends, which is also
    // what worked ground actually looks like: a broad area, not a lens.
    const N = 2.7;
    const pts = [];
    const steps = 30;
    for (let i = 0; i < steps; i++) {
      const t = (i / steps) * Math.PI * 2;
      const ct = Math.cos(t);
      const st = Math.sin(t);
      const sx = Math.sign(ct) * Math.pow(Math.abs(ct), 2 / N);
      const sy = Math.sign(st) * Math.pow(Math.abs(st), 2 / N);
      const rrx = halfW * (0.88 + 0.12 * Math.cos(t * 2));
      const rry = ry * (0.90 + 0.10 * Math.sin(t * 3));
      const wob = 1 + (r() - 0.5) * 0.15;
      pts.push({ x: cx + sx * rrx * wob, y: cy + sy * rry * wob });
    }
    return pts;
  };

  /**
   * Compose the whole ground as an ordered draw program.
   *
   * ORDER IS THE CONTRACT: apron, then marks on it, then furniture standing on
   * it, then the cast shadows that tie the battlers to it. The renderer walks
   * this array and nothing else decides z-order.
   *
   * @param {Object} rd a reading from B.read
   * @param {Object} [opts] {shadows:boolean, furniture:boolean, marks:boolean}
   * @returns {{ops: Array<Object>, meta: Object}} the program
   */
  B.plan = function (rd, opts) {
    const o = opts || {};
    const want = {
      apron: o.apron !== false,
      marks: o.marks !== false,
      furniture: o.furniture !== false,
      shadows: o.shadows !== false,
    };
    const r = B.rng(rd.seed ^ 0xA5A5A5A5);
    const ops = [];
    const ground = B.groundFor(rd);
    const outline = B.apronOutline(rd);

    if (want.apron) {
      ops.push({
        op: 'apron',
        ground: ground,
        outline: outline,
        rough: B.GROUNDS[ground].rough,
        chroma: B.GROUNDS[ground].chroma.slice(),
        grain: B.GROUNDS[ground].grain,
        wear: clamp(rd.timesFought / 12, 0, 1),
      });
    }

    const marks = want.marks ? B.marksFor(rd) : [];
    for (let i = 0; i < marks.length; i++) {
      const key = marks[i];
      const m = B.MARKS[key];
      const seat = { x: rd.hull.centre, y: rd.hull.footY };
      ops.push({
        op: 'mark',
        mark: key,
        follows: m.follows,
        // ⛔ A scatter mark that falls OFF the worked ground reads as litter on
        // the battleback - measured: bone scatter landed below the apron edge on
        // the stock Treant. The renderer clips these to the apron. An `approach`
        // mark is deliberately NOT clipped: tracks lead in from outside.
        clip: m.follows !== 'approach' ? outline : null,
        // The approach comes from the side the band's heaviest member stands on,
        // so the tracks lead to the creature that made them.
        from: (rd.lead && rd.lead.x < rd.hull.centre) ? -1 : 1,
        seat: seat,
        // ⛔ MEASURED DEFECT, FIXED: spread came off the HULL, and a one-member
        // troop has a 48 px hull, so a champion's bone scatter and gouges piled
        // into a 30 px clump under its feet. Marks are made across the ground the
        // band OCCUPIES, which is the apron.
        spread: Math.max(rd.hull.span, B.apronBox(rd).w * 0.62) * (0.55 + r() * 0.35),
        weight: m.weight * (0.7 + r() * 0.5),
        seed: (rd.seed + i * 7919) >>> 0,
      });
    }

    const pieces = want.furniture ? B.furnitureFor(rd) : [];
    const anchors = B.anchors(rd);
    const placed = [];
    for (let i = 0; i < pieces.length; i++) {
      const key = pieces[i];
      const f = B.FURNITURE[key];
      const a = anchors[i % anchors.length];
      // Bulk decides how much room the piece asks for; depth decides how far
      // back it stands, which is the only thing that makes the scene read as
      // having a front and a back.
      // ⛔ MEASURED DEFECT, FIXED: at the old range these rendered as MINIATURES.
      // The yardstick is the thing standing next to them - an MZ enemy battler is
      // roughly 100-200 px tall, and a campfire that reads at 40 px beside one
      // looks like a toy. A piece nearer the viewer is drawn larger, which is the
      // only depth cue a flat layer has.
      const scale = clamp(f.bulk * (1.20 + a.depth * 0.62), 0.6, 2.6);

      // ⛔ MEASURED DEFECT, FIXED: the anchors are spread and the member-clearance
      // rule moves pieces OFF them, so two pieces can be pushed onto the same
      // spot - the stock champion drove its carrion post through the middle of
      // its own altar. Clearing a battler and clearing a neighbour are two
      // different constraints and both have to be applied.
      let px = a.x + (r() - 0.5) * 26;
      const py = a.y + (r() - 0.5) * 10;
      const halfOf = B.footprintHalf;
      // ⛔ AND THE SEPARATION MUST NOT PUSH A PIECE OFF THE GROUND. Measured: the
      // stock champion's altar was shoved clear of its own apron and stood on the
      // battleback. Separation runs inside a hard clamp to the apron's real width
      // AT THAT HEIGHT, and the clamp is applied last so it always wins.
      // ⛔⛔ THREE CONSTRAINTS, ONE SOLVER. Clearing a battler was done in
      // anchors(), clearing a neighbour here, and the apron clamp last - so each
      // fix UNDID the one before it and pieces landed back on top of battlers.
      // The suite caught it on three of five stock troops (gap 9, 38 and 17 px).
      // All three are now relaxed together, in the same loop, with the apron
      // clamp applied every pass because leaving the ground is never acceptable.
      // ⛔⛔ A SEARCH, NOT A RELAXATION. Pushing a piece away from a battler, then
      // away from a neighbour, then clamping it back onto the apron is three
      // rules that undo each other: the suite caught pieces oscillating into
      // battlers (gaps of 9, 17, 19 px) and two pieces pinned to the same clamp
      // edge (gap 0). Sampling the whole lane and taking the least-bad position
      // cannot oscillate and always returns the best seat available.
      const lane = B.spanAt(outline, py);
      if (lane) {
        // ⛔ THE MARGIN IS THE PIECE'S OWN FOOTPRINT, NOT A FRACTION OF IT. At
        // 0.6x a standard's centre sat legally inside the lane while 36 px of the
        // object hung over the edge onto the battleback - the clamp was measuring
        // the anchor rather than the thing being placed.
        const margin = Math.min(halfOf(key, scale), lane.half * 0.80);
        const lo = lane.left + margin;
        const hi = lane.right - margin;
        const want = px;
        let bestX = clamp(want, Math.min(lo, hi), Math.max(lo, hi));
        let bestCost = Infinity;
        const SAMPLES = 64;
        for (let k = 0; k <= SAMPLES; k++) {
          const cx2 = lo + ((hi - lo) * k) / SAMPLES;
          let cost = Math.abs(cx2 - want) * 0.16;
          for (const m of rd.visible) {
            if (Math.abs(py - m.y) > 70) continue;
            const need = 52 * m.weight;
            // ⛔ Standing ON a battler is never an acceptable trade. This weight
            // is an order of magnitude above the others deliberately, so the
            // solver will always take a slight neighbour overlap instead.
            cost += Math.max(0, need - Math.abs(cx2 - m.x)) * 40.0;
          }
          for (const p of placed) {
            if (Math.abs(py - p.y) > 58) continue;
            const need = halfOf(key, scale) + halfOf(p.piece, p.scale);
            cost += Math.max(0, need - Math.abs(cx2 - p.x)) * 2.4;
          }
          if (cost < bestCost) { bestCost = cost; bestX = cx2; }
        }
        px = bestX;
      }

      ops.push({
        op: 'furniture',
        piece: key,
        slot: a.slot,
        x: px,
        y: py,
        depth: a.depth,
        scale: scale,
        flip: r() < 0.5 ? -1 : 1,
        wear: clamp(rd.timesFought / 9, 0, 1),
        seed: (rd.seed + 104729 + i * 31337) >>> 0,
      });
      placed.push({ piece: key, x: px, y: py, scale: scale });
    }

    if (want.shadows) {
      for (const m of rd.visible) {
        ops.push({
          op: 'shadow',
          x: m.x,
          y: m.y,
          weight: m.weight,
          enemyId: m.enemyId,
        });
      }
    }

    return {
      ops: ops,
      meta: {
        troopId: rd.troopId,
        name: rd.name,
        ground: ground,
        marks: marks,
        furniture: pieces,
        standing: rd.standing,
        nature: rd.nature,
        size: rd.size,
        seed: rd.seed,
      },
    };
  };

  /**
   * The whole job in one call.
   * @param {Object} troop a $dataTroops row
   * @param {Array<Object>} enemies every $dataEnemies row
   * @param {Object} [opts] passed to read() and plan()
   * @returns {{ops: Array, meta: Object, reading: Object}} the program
   */
  B.compose = function (troop, enemies, opts) {
    const rd = B.read(troop, enemies, opts);
    const p = B.plan(rd, opts);
    p.reading = rd;
    return p;
  };

  /**
   * A short, stable description of what a program will draw. Used by the probes
   * to count distinct outcomes over a database without rendering anything.
   * @param {Object} program from B.plan
   * @returns {string} the profile
   */
  B.profile = function (program) {
    const m = program.meta;
    return [m.ground, m.nature, m.standing, m.size,
      m.marks.slice().sort().join('+'),
      m.furniture.slice().sort().join('+')].join('|');
  };

  B.VERSION = '1.0.0';
}(BivouacCore));

if (typeof module !== 'undefined' && module.exports) module.exports = BivouacCore;
