/*:
 * @target MZ
 * @plugindesc [Strew 1.0] Dresses your own maps from your own tileset in one keypress: flower drifts, tufts at the walls, floor variants. Seeded, re-rollable, undoable.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io/strew
 * @base StrewCore
 * @orderAfter StrewCore
 *
 * @param density
 * @text Density
 * @type number
 * @decimals 2
 * @min 0
 * @max 3
 * @default 1.00
 * @desc Multiplies every scatter rate. 0.5 is a light touch, 1.5 is overgrown.
 *
 * @param maskRegions
 * @text Keep-clear regions
 * @type string
 * @default
 * @desc Region IDs Strew never dresses, comma separated (example: 1,7). Paint them over courtyards, stages, puzzle floors.
 *
 * @param skip
 * @text Leave out
 * @type string
 * @default
 * @desc Kinds to leave out, comma separated: flower, tuft, bush, pebble, rock, wood, variants.
 *
 * @param liveAll
 * @text Live on every map
 * @type boolean
 * @on Yes
 * @off No
 * @default false
 * @desc Yes: every map is dressed as it loads, in memory only, the same way every time. No: only maps with <Strew Live>.
 *
 * @param hotkeys
 * @text Playtest hotkeys
 * @type boolean
 * @on F7 bake, Shift+F7 undo, F6 plan
 * @off Plugin commands only
 * @default true
 * @desc Playtest only. F7 bakes (or rerolls) the current map, Shift+F7 undoes it, F6 shows the plan.
 *
 * @param toast
 * @text Show the result card
 * @type boolean
 * @default true
 * @desc After a bake or undo, show what was placed and the seed for a few seconds.
 *
 * @command bake
 * @text Bake this map (playtest)
 * @desc Dresses the current map and WRITES it to data/MapXXX.json. A second bake replaces the first (a reroll).
 * @arg seed
 * @text Seed
 * @type number
 * @min 0
 * @default 0
 * @desc 0 picks a new seed. Any other number repeats that exact dressing.
 *
 * @command undo
 * @text Undo the last bake (playtest)
 * @desc Removes what the last bake placed and writes the map back. Tiles you painted since are kept.
 *
 * @command live
 * @text Dress this map now (memory only)
 * @desc Dresses the current map in memory without writing any file. Same seed, same result.
 * @arg seed
 * @text Seed
 * @type number
 * @min 0
 * @default 0
 * @desc 0 uses the map's own seed (<Strew Seed: n> or one derived from the map ID).
 *
 * @command plan
 * @text Show or hide the plan
 * @desc Overlays why Strew put things where it did: protected squares, paths, kept-clear regions, each placement.
 * @arg show
 * @type boolean
 * @default true
 *
 * @help Strew.js  (requires StrewCore.js directly above it)
 * ============================================================================
 * Strew reads a map you made by hand and the tileset it uses, and dresses it:
 * flowers in drifts rather than sprinkles, tufts and pebbles thickening where
 * the ground meets a wall or water, debris in corners, bushes against walls,
 * repeated floor tiles broken up by their own variants. It never puts anything
 * on a path, on or beside an event, on a kept-clear region, on a square that
 * already holds an upper tile, and it never places a blocking tile where that
 * would cut a route (it proves the squares around it stay connected first).
 *
 * Everything it places comes from YOUR tileset. It reads the tileset images to
 * find which tiles are flowers, tufts, pebbles, rocks, bushes and wood, and
 * which floor tiles are interchangeable. You can override that reading with
 * tileset notes (below).
 *
 * --- Two ways to use it ------------------------------------------------------
 * BAKE (playtest): walk onto a map, press F7. The map is dressed on screen and
 * written to data/MapXXX.json, with the previous file kept in data/Strew/.
 * Press F7 again for a different arrangement (a reroll replaces the last bake).
 * Shift+F7 removes exactly what Strew placed. Tiles you paint after a bake are
 * never removed by its undo.
 *   IMPORTANT: the editor keeps its own copy of an open map. Save in the editor
 *   BEFORE you bake, and after baking reopen the project (File > Open Project)
 *   before you edit that map again, or the editor will save its old copy over
 *   the bake.
 *
 * LIVE: put <Strew Live> in a map's note (or turn on "Live on every map"). The
 * map is dressed in memory each time it loads, with the same seed every time,
 * and no file is written. Save files are unaffected either way.
 *
 * --- Map notes ---------------------------------------------------------------
 *   <Strew Live>             dress this map as it loads
 *   <Strew Off>              never dress this map (bake refuses too)
 *   <Strew Seed: 1234>       the seed Live mode uses on this map
 *   <Strew Density: 1.4>     this map's density (multiplies the parameter)
 *   <Strew Mask: 3,4>        extra kept-clear region IDs for this map
 *   <Strew Skip: flower>     kinds to leave out on this map
 *
 * --- Tileset notes (override the reading) ------------------------------------
 *   <Strew Flower: 101,102>  these tile IDs are flowers (likewise Tuft, Bush,
 *                            Pebble, Rock, Wood)
 *   <Strew Exclude: 140,141> never place these
 *   <Strew Variants: 1,2,3>  these floor tiles are interchangeable
 * Tile IDs: B sheet 0-255, C 256-511, D 512-767, E 768-1023, A5 1536-1663.
 * On a sheet, a tile's ID is (column < 8 ? 0 : 128) + row * 8 + column % 8,
 * plus the sheet's base.
 *
 * --- Plugin commands -------------------------------------------------------
 *   Bake this map, Undo the last bake, Dress this map now, Show or hide the plan.
 *
 * Bake and Undo work only in playtest on the desktop runtime (they write files).
 * Live mode works everywhere, including deployed and web games.
 *
 * Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.
 */
(function () {
  'use strict';

  const NAME = 'Strew';
  const P = PluginManager.parameters(NAME);
  const toNum = (v, d) => { const s = String(v == null ? '' : v).trim(); if (s === '') return d; const n = Number(s); return Number.isFinite(n) ? n : d; };
  const toList = (v) => String(v || '').split(',').map((x) => x.trim()).filter((x) => x !== '');
  const PARAMS = {
    density: toNum(P.density, 1),
    maskRegions: toList(P.maskRegions).map(Number).filter((n) => Number.isInteger(n) && n > 0),
    skip: toList(P.skip).map((s) => s.toLowerCase()),
    liveAll: String(P.liveAll) === 'true',
    hotkeys: String(P.hotkeys) !== 'false',
    toast: String(P.toast) !== 'false',
  };
  const SHEET_KEYS = ['A1', 'A2', 'A3', 'A4', 'A5', 'B', 'C', 'D', 'E'];

  /** Resolves StrewCore at first use, so plugin load order inside the list cannot break boot. */
  function core() {
    const C = window.StrewCore;
    if (!C) throw new Error('Strew: StrewCore.js is missing. Install it directly above Strew.js and turn it ON.');
    return C;
  }

  // ------------------------------------------------------------------ notes

  function mapNote(dataMap) {
    const note = String((dataMap && dataMap.note) || '');
    const pick = (re) => { const m = note.match(re); return m ? m[1] : null; };
    return {
      off: /<\s*strew\s+off\s*>/i.test(note),
      live: /<\s*strew\s+live\s*>/i.test(note),
      seed: toNum(pick(/<\s*strew\s+seed\s*:\s*(\d+)\s*>/i), 0),
      density: toNum(pick(/<\s*strew\s+density\s*:\s*([0-9.]+)\s*>/i), 1),
      mask: toList(pick(/<\s*strew\s+mask\s*:\s*([0-9 ,]+)>/i)).map(Number).filter((n) => Number.isInteger(n) && n > 0),
      skip: toList(pick(/<\s*strew\s+skip\s*:\s*([a-z ,]+)>/i)).map((s) => s.toLowerCase()),
    };
  }

  // ------------------------------------------------------------------ tileset reading

  const analysisCache = new Map();

  function tilesetBitmaps(tilesetId) {
    const ts = $dataTilesets[tilesetId];
    if (!ts) return [];
    return ts.tilesetNames.map((name) => (name ? ImageManager.loadTileset(name) : null));
  }

  function tilesetReady(tilesetId) {
    return tilesetBitmaps(tilesetId).every((b) => !b || b.isReady());
  }

  /** Reads the tileset once per session (one getImageData per sheet, never during play). */
  function analysisFor(tilesetId) {
    const ts = $dataTilesets[tilesetId];
    const key = tilesetId + '|' + ts.tilesetNames.join('|') + '|' + (ts.note || '');
    if (analysisCache.has(key)) return analysisCache.get(key);
    const bitmaps = tilesetBitmaps(tilesetId);
    const sheets = {};
    bitmaps.forEach((bmp, i) => {
      if (!bmp || !bmp.width) return;
      const img = bmp.context.getImageData(0, 0, bmp.width, bmp.height);
      sheets[SHEET_KEYS[i]] = { px: img.data, w: bmp.width, h: bmp.height };
    });
    const names = {};
    ts.tilesetNames.forEach((n, i) => { names[SHEET_KEYS[i]] = n; });
    const A = core().analyseTileset({ flags: ts.flags, note: ts.note, tileSize: $gameMap.tileWidth ? $gameMap.tileWidth() : 48, sheets, names });
    analysisCache.set(key, A);
    return A;
  }

  function eventsOf(dataMap) {
    return (dataMap.events || []).filter((e) => e).map((e) => ({ x: e.x, y: e.y }));
  }

  function currentMapId() {
    return $gamePlayer && $gamePlayer.isTransferring() ? $gamePlayer.newMapId() : $gameMap.mapId();
  }

  function runDress(dataMap, seed) {
    const n = mapNote(dataMap);
    const A = analysisFor(dataMap.tilesetId);
    return core().dress({
      width: dataMap.width, height: dataMap.height, data: dataMap.data, events: eventsOf(dataMap),
      flags: $dataTilesets[dataMap.tilesetId].flags, analysis: A, seed,
      density: PARAMS.density * n.density, maskRegions: PARAMS.maskRegions.concat(n.mask), skip: PARAMS.skip.concat(n.skip),
    });
  }

  // ------------------------------------------------------------------ file IO (playtest)

  /** The IO seam. Defaults to NW.js fs; tests replace it with Strew.setIO. */
  const nwIO = {
    available() { return Utils.isNwjs() && Utils.isOptionValid('test'); },
    base() { const path = require('path'); return path.dirname(process.mainModule.filename); },
    readText(rel) { const fs = require('fs'), path = require('path'); return fs.readFileSync(path.join(this.base(), rel), 'utf8'); },
    writeText(rel, text) {
      const fs = require('fs'), path = require('path');
      const f = path.join(this.base(), rel);
      fs.mkdirSync(path.dirname(f), { recursive: true });
      const tmp = f + '.strew-tmp';
      fs.writeFileSync(tmp, text, 'utf8');
      fs.renameSync(tmp, f);
    },
    exists(rel) { const fs = require('fs'), path = require('path'); return fs.existsSync(path.join(this.base(), rel)); },
    remove(rel) { const fs = require('fs'), path = require('path'); const f = path.join(this.base(), rel); if (fs.existsSync(f)) fs.unlinkSync(f); },
    list(dirRel) { const fs = require('fs'), path = require('path'); const d = path.join(this.base(), dirRel); return fs.existsSync(d) ? fs.readdirSync(d) : []; },
  };
  let io = nwIO;

  const pad3 = (n) => String(n).padStart(3, '0');
  const mapFile = (id) => 'data/Map' + pad3(id) + '.json';
  const ledgerFile = (id) => 'data/Strew/Map' + pad3(id) + '.strew.json';
  const backupFile = (id, k) => 'data/Strew/Map' + pad3(id) + '.before.' + k + '.json';
  const BACKUPS_KEPT = 5;

  /** Copies new tile data into the live map in place and repaints, so no reload is needed. */
  function pushToLive(newData) {
    const live = $dataMap.data;
    for (let i = 0; i < newData.length; i++) live[i] = newData[i];
    const sp = SceneManager._scene && SceneManager._scene._spriteset;
    if (sp && sp._tilemap) sp._tilemap.refresh();
    if (plan.sprite) plan.sprite.invalidate();
  }

  let bakeCounter = 0;
  function freshSeed(mapId) {
    bakeCounter++;
    return (core().hashString('strew:' + mapId + ':' + bakeCounter + ':' + Date.now()) % 1000000) + 1;
  }

  /**
   * Bake (or reroll) the current map into its file. A reroll first undoes the
   * previous bake on the file, so bakes never stack.
   * @returns {object|null} the core report, or null if refused
   */
  function bake(seedArg) {
    const mapId = $gameMap.mapId();
    if (!io.available()) return refuse('Bake writes the map file, so it runs only in playtest on the desktop runtime.');
    if (mapNote($dataMap).off) return refuse('This map says <Strew Off>.');
    if (!tilesetReady($dataMap.tilesetId)) return refuse('The tileset images are still loading. Try again in a moment.');
    const fileMap = JSON.parse(io.readText(mapFile(mapId)));
    let rerolled = false;
    if (io.exists(ledgerFile(mapId))) {
      const prev = JSON.parse(io.readText(ledgerFile(mapId)));
      core().undo(fileMap.data, prev.ledger);
      rerolled = true;
    }
    const seed = seedArg > 0 ? seedArg : freshSeed(mapId);
    const result = runDress(fileMap, seed);
    let k = Date.now();
    while (io.exists(backupFile(mapId, k))) k++;
    io.writeText(backupFile(mapId, k), JSON.stringify(JSON.parse(io.readText(mapFile(mapId)))));
    pruneBackups(mapId);
    fileMap.data = result.data;
    io.writeText(mapFile(mapId), JSON.stringify(fileMap));
    io.writeText(ledgerFile(mapId), JSON.stringify({ strew: core().VERSION, mapId, seed, at: new Date(k).toISOString(), ledger: result.ledger, report: result.report }));
    pushToLive(result.data);
    plan.last = result;
    result.report.rerolled = rerolled;
    showToast('bake', result.report);
    return result.report;
  }

  /** Keeps the newest BACKUPS_KEPT backups of this map on disk (names carry the time, so they sort). */
  function pruneBackups(mapId) {
    const head = 'Map' + pad3(mapId) + '.before.';
    const stamps = io.list('data/Strew').filter((f) => f.indexOf(head) === 0 && /\.json$/.test(f))
      .map((f) => Number(f.slice(head.length, -5))).filter((n) => Number.isFinite(n)).sort((a, b) => a - b);
    while (stamps.length > BACKUPS_KEPT) io.remove(backupFile(mapId, stamps.shift()));
  }

  /** Undo the last bake on the current map's file. Tiles painted since are kept. */
  function undoBake() {
    const mapId = $gameMap.mapId();
    if (!io.available()) return refuse('Undo writes the map file, so it runs only in playtest on the desktop runtime.');
    if (!io.exists(ledgerFile(mapId))) return refuse('Nothing to undo on this map.');
    const prev = JSON.parse(io.readText(ledgerFile(mapId)));
    const fileMap = JSON.parse(io.readText(mapFile(mapId)));
    const r = core().undo(fileMap.data, prev.ledger);
    io.writeText(mapFile(mapId), JSON.stringify(fileMap));
    io.remove(ledgerFile(mapId));
    pushToLive(fileMap.data);
    plan.last = null;
    const report = { undone: true, restored: r.restored, kept: r.kept, seed: prev.seed };
    showToast('undo', report);
    return report;
  }

  /** Dress the current map in memory only. */
  function liveNow(seedArg) {
    if (!tilesetReady($dataMap.tilesetId)) return refuse('The tileset images are still loading.');
    const n = mapNote($dataMap);
    const seed = seedArg > 0 ? seedArg : (n.seed || defaultSeed($gameMap.mapId()));
    const result = runDress($dataMap, seed);
    pushToLive(result.data);
    plan.last = result;
    showToast('live', result.report);
    return result.report;
  }

  function defaultSeed(mapId) { return (core().hashString('strew-map-' + mapId) % 1000000) + 1; }

  function refuse(why) {
    showToast('refused', { why });
    if (Utils.isOptionValid('test')) console.warn('[Strew] ' + why);
    return null;
  }

  // ------------------------------------------------------------------ live mode on load

  const liveState = { mapId: 0, pending: false, done: false };

  function liveWanted() {
    if (!$dataMap || !$dataMap.data) return false;
    const n = mapNote($dataMap);
    return !n.off && (PARAMS.liveAll || n.live);
  }

  const _Scene_Map_isReady = Scene_Map.prototype.isReady;
  Scene_Map.prototype.isReady = function () {
    if (!this._mapLoaded && DataManager.isMapLoaded() && !$dataMap.__strewDressed && liveWanted()) {
      if (!tilesetReady($dataMap.tilesetId)) return false;
      // In a PLAYER's game a failure here must never stop the map loading: it loads undressed instead.
      let report;
      try {
        const n = mapNote($dataMap);
        const mapId = currentMapId();
        const result = runDress($dataMap, n.seed || defaultSeed(mapId));
        core().apply($dataMap.data, result.ledger);
        plan.last = result;
        report = result.report;
      } catch (e) {
        report = { failed: String(e && e.message ? e.message : e) };
        if (Utils.isOptionValid('test')) console.warn('[Strew] Live dressing skipped: ' + report.failed);
      }
      Object.defineProperty($dataMap, '__strewDressed', { value: report, enumerable: false, configurable: true });
    }
    return _Scene_Map_isReady.call(this);
  };

  // ------------------------------------------------------------------ the result card

  const INK = '#1d1a16', PAPER = '#efe6d2', RULE = '#8a6a3a', DIM = '#6b5a44', HEAD = '#3a2a18';
  const FACE = 'Georgia, "Palatino Linotype", "Book Antiqua", serif';
  const CAT_LABEL = { flower: 'flowers', tuft: 'tufts', bush: 'bushes', pebble: 'pebbles', rock: 'rocks', wood: 'wood' };

  class Strew_Card extends Sprite {
    constructor() {
      super(new Bitmap(360, 200));
      this.x = 18; this.y = 18; this._life = 0; this.opacity = 0;
    }
    present(kind, report, swatches) {
      const b = this.bitmap, W = b.width, H = b.height, ctx = b.context;
      b.clear();
      ctx.save();
      ctx.fillStyle = INK; ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = PAPER; ctx.fillRect(4, 4, W - 8, H - 8);
      ctx.strokeStyle = RULE; ctx.lineWidth = 1; ctx.strokeRect(9.5, 9.5, W - 19, H - 19);
      ctx.restore();
      b.fontFace = FACE; b.outlineWidth = 0;
      b.textColor = HEAD; b.fontSize = 26; b.fontBold = true;
      const title = kind === 'bake' ? (report.rerolled ? 'Rerolled' : 'Strewn') : kind === 'undo' ? 'Undone' : kind === 'live' ? 'Strewn (live)' : 'Not strewn';
      b.drawText(title, 20, 14, 220, 32, 'left');
      b.fontBold = false; b.fontSize = 15; b.textColor = DIM;
      if (report.seed) b.drawText('seed ' + report.seed, W - 160, 20, 140, 24, 'right');
      b.fontSize = 16; b.textColor = INK;
      if (kind === 'refused') {
        b.drawText(String(report.why).slice(0, 48), 20, 60, W - 40, 24, 'left');
        b.drawText(String(report.why).slice(48, 96), 20, 84, W - 40, 24, 'left');
      } else if (kind === 'undo') {
        b.drawText(report.restored + ' tiles removed', 20, 60, W - 40, 24, 'left');
        b.drawText(report.kept + ' kept (painted since the bake)', 20, 86, W - 40, 24, 'left');
      } else {
        let col = 0, row = 0;
        for (const cat of core().CATEGORIES) {
          const count = report.placed[cat];
          if (!count) continue;
          const x = 20 + col * 108, y = 54 + row * 34;
          const sw = swatches[cat];
          if (sw) b.blt(sw.bitmap, sw.sx, sw.sy, sw.s, sw.s, x, y, 30, 30);
          b.drawText(String(count), x + 34, y - 2, 70, 18, 'left');
          b.fontSize = 12; b.textColor = DIM;
          b.drawText(CAT_LABEL[cat], x + 34, y + 14, 70, 16, 'left');
          b.fontSize = 16; b.textColor = INK;
          if (++col === 3) { col = 0; row++; }
        }
        if (report.variants) b.drawText(report.variants + ' floor variants', 20, 58 + (row + (col ? 1 : 0)) * 34, 240, 22, 'left');
      }
      b.fontSize = 12; b.textColor = DIM;
      b.drawText(PARAMS.hotkeys ? 'F7 reroll   Shift+F7 undo   F6 plan' : 'plugin commands: bake, undo, plan', 20, H - 34, W - 40, 18, 'left');
      b.baseTexture.update();
      this._life = 300; this.opacity = 255;
    }
    update() {
      super.update();
      if (this._life > 0) { this._life--; if (this._life < 40) this.opacity = Math.round(255 * this._life / 40); }
    }
  }

  function swatchesFor(result) {
    const out = {};
    if (!result || !$dataTilesets[$dataMap.tilesetId]) return out;
    const A = analysisFor($dataMap.tilesetId);
    const bitmaps = tilesetBitmaps($dataMap.tilesetId);
    const s = A.tileSize;
    for (const cat of core().CATEGORIES) {
      const id = (A.decor[cat] || [])[0];
      if (id == null) continue;
      const c = core().normalTileCell(id);
      const bmp = bitmaps[SHEET_KEYS.indexOf(c.sheet)];
      if (bmp) out[cat] = { bitmap: bmp, sx: c.col * s, sy: c.row * s, s };
    }
    return out;
  }

  const card = { sprite: null };
  function showToast(kind, report) {
    const scene = SceneManager._scene;
    if (!PARAMS.toast || !(scene instanceof Scene_Map)) return;
    if (!card.sprite || card.sprite.parent !== scene) {
      card.sprite = new Strew_Card();
      scene.addChild(card.sprite);
    }
    card.sprite.present(kind, report, swatchesFor(plan.last));
  }

  // ------------------------------------------------------------------ the plan overlay

  const PLAN_COLOURS = {
    guard: 'rgba(214,170,74,0.55)', path: 'rgba(86,120,168,0.42)', mask: 'rgba(186,84,104,0.5)', solid: 'rgba(20,18,16,0.35)',
    flower: '#e8c34a', tuft: '#9fd06a', bush: '#3f8f4e', pebble: '#c9c3b6', rock: '#8f8a80', wood: '#b07a45',
  };

  class Strew_Plan extends Sprite {
    constructor() {
      super(new Bitmap(Graphics.width, Graphics.height));
      this._ox = -1; this._oy = -1; this._dirty = true;
    }
    invalidate() { this._dirty = true; }
    update() {
      super.update();
      const ox = $gameMap.displayX(), oy = $gameMap.displayY();
      if (!this._dirty && ox === this._ox && oy === this._oy) return;
      this._ox = ox; this._oy = oy; this._dirty = false;
      this.redraw(ox, oy);
    }
    redraw(ox, oy) {
      const b = this.bitmap, ctx = b.context, last = plan.last;
      b.clear();
      if (!last) return;
      const tw = $gameMap.tileWidth(), th = $gameMap.tileHeight(), w = $dataMap.width, h = $dataMap.height;
      const x0 = Math.max(0, Math.floor(ox)), y0 = Math.max(0, Math.floor(oy));
      const x1 = Math.min(w, Math.ceil(ox + Graphics.width / tw) + 1), y1 = Math.min(h, Math.ceil(oy + Graphics.height / th) + 1);
      const g = last.plan.guard, pth = last.plan.path, pc = last.plan.placedCat, fp = last.plan.flowerPatch;
      ctx.save();
      for (let y = y0; y < y1; y++) {
        for (let x = x0; x < x1; x++) {
          const i = y * w + x, px = Math.round((x - ox) * tw), py = Math.round((y - oy) * th);
          if (fp[i] > 0.05) { ctx.fillStyle = 'rgba(232,195,74,' + (0.28 * fp[i]).toFixed(3) + ')'; ctx.fillRect(px, py, tw, th); }
          if (pth[i]) { ctx.fillStyle = PLAN_COLOURS.path; ctx.fillRect(px, py, tw, th); }
          if (g[i] === 2) { ctx.fillStyle = PLAN_COLOURS.mask; ctx.fillRect(px, py, tw, th); }
          if (g[i] === 1) {
            ctx.strokeStyle = PLAN_COLOURS.guard; ctx.lineWidth = 2;
            ctx.beginPath();
            for (let k = -th; k < tw; k += 12) { ctx.moveTo(px + k, py + th); ctx.lineTo(px + k + th, py); }
            ctx.save(); ctx.rect(px, py, tw, th); ctx.clip(); ctx.stroke(); ctx.restore();
          }
          const cat = pc[i];
          if (cat) {
            ctx.fillStyle = INK; ctx.beginPath(); ctx.arc(px + tw / 2, py + th / 2, 7.5, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = PLAN_COLOURS[cat]; ctx.beginPath(); ctx.arc(px + tw / 2, py + th / 2, 5.5, 0, Math.PI * 2); ctx.fill();
          }
        }
      }
      ctx.restore();
      drawLegend(b);
      drawPalette(b);
      b.baseTexture.update();
    }
  }

  /** What Strew read from this tileset, kind by kind, with tile IDs to copy into <Strew Exclude: ...>. */
  function drawPalette(b) {
    const A = analysisFor($dataMap.tilesetId), bitmaps = tilesetBitmaps($dataMap.tilesetId), s = A.tileSize;
    const cats = core().CATEGORIES.filter((c) => (A.decor[c] || []).length);
    const PER = 8, CELL = 30, ROW = 40, W = 96 + PER * CELL + 12, H = 44 + Math.max(1, cats.length) * ROW;
    const ctx = b.context, x = 16, y = 16;
    ctx.save();
    ctx.fillStyle = INK; ctx.fillRect(x, y, W, H);
    ctx.fillStyle = PAPER; ctx.fillRect(x + 3, y + 3, W - 6, H - 6);
    ctx.restore();
    b.fontFace = FACE; b.outlineWidth = 0; b.fontBold = true; b.fontSize = 16; b.textColor = HEAD;
    b.drawText('What Strew will place', x + 12, y + 8, W - 24, 22, 'left');
    b.fontBold = false; b.fontSize = 11; b.textColor = DIM;
    const src = Object.values(A.source).indexOf('stock') >= 0 ? 'stock palette (picked by hand)' : 'read from your tileset art';
    b.drawText(src, x + 12, y + 26, W - 24, 16, 'left');
    if (!cats.length) { b.fontSize = 13; b.textColor = INK; b.drawText('nothing to scatter: floor variants only', x + 12, y + 46, W - 24, 18, 'left'); return; }
    cats.forEach((cat, r) => {
      const yy = y + 46 + r * ROW;
      b.fontSize = 13; b.textColor = INK;
      b.drawText(CAT_LABEL[cat], x + 12, yy + 4, 80, 18, 'left');
      (A.decor[cat] || []).slice(0, PER).forEach((id, k) => {
        const c = core().normalTileCell(id), bmp = bitmaps[SHEET_KEYS.indexOf(c.sheet)];
        const dx = x + 92 + k * CELL;
        if (bmp) b.blt(bmp, c.col * s, c.row * s, s, s, dx, yy, 26, 26);
        b.fontSize = 9; b.textColor = DIM;
        b.drawText(String(id), dx - 2, yy + 25, CELL, 12, 'center');
      });
    });
  }

  function drawLegend(b) {
    const ctx = b.context, W = 228, H = 190, x = b.width - W - 16, y = b.height - H - 16;
    ctx.save();
    ctx.fillStyle = INK; ctx.fillRect(x, y, W, H);
    ctx.fillStyle = PAPER; ctx.fillRect(x + 3, y + 3, W - 6, H - 6);
    ctx.restore();
    b.fontFace = FACE; b.outlineWidth = 0; b.fontSize = 17; b.fontBold = true; b.textColor = HEAD;
    b.drawText('Strew plan', x + 14, y + 8, W - 28, 24, 'left');
    b.fontBold = false; b.fontSize = 13; b.textColor = INK;
    const rows = [['guard', 'kept clear: events'], ['path', 'path: nothing on it'], ['mask', 'kept-clear region'], ['flower', 'flower drift field']];
    rows.forEach((r, k) => {
      const yy = y + 38 + k * 21;
      ctx.save(); ctx.fillStyle = r[0] === 'flower' ? 'rgba(232,195,74,0.5)' : PLAN_COLOURS[r[0]]; ctx.fillRect(x + 14, yy + 3, 22, 14); ctx.restore();
      b.drawText(r[1], x + 44, yy, W - 56, 20, 'left');
    });
    core().CATEGORIES.forEach((cat, k) => {
      const cx = x + 22 + (k % 3) * 70, cy = y + H - 42 + Math.floor(k / 3) * 22;
      ctx.save();
      ctx.fillStyle = INK; ctx.beginPath(); ctx.arc(cx, cy, 7.5, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = PLAN_COLOURS[cat]; ctx.beginPath(); ctx.arc(cx, cy, 5.5, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
      b.fontSize = 12; b.textColor = INK;
      b.drawText(cat, cx + 11, cy - 10, 56, 20, 'left');
    });
  }

  const plan = { sprite: null, last: null, shown: false };
  function setPlan(show) {
    const scene = SceneManager._scene;
    plan.shown = !!show;
    if (!(scene instanceof Scene_Map) || !scene._spriteset) return;
    if (show) {
      if (!plan.sprite || plan.sprite.parent !== scene._spriteset) {
        plan.sprite = new Strew_Plan();
        scene._spriteset.addChild(plan.sprite);
      }
      plan.sprite.visible = true; plan.sprite.invalidate();
    } else if (plan.sprite) {
      plan.sprite.visible = false;
    }
  }

  const _Scene_Map_start = Scene_Map.prototype.start;
  Scene_Map.prototype.start = function () {
    _Scene_Map_start.call(this);
    if (plan.shown) setPlan(true);
  };

  // ------------------------------------------------------------------ commands and keys

  /** A file that cannot be read or parsed is a refusal with a reason, never a crash in the buyer's playtest. */
  function guarded(fn, what) {
    return function () {
      try { return fn.apply(null, arguments); } catch (e) { return refuse(what + ' failed: ' + (e && e.message ? e.message : e)); }
    };
  }
  const bakeSafe = guarded(bake, 'Bake'), undoSafe = guarded(undoBake, 'Undo');

  PluginManager.registerCommand(NAME, 'bake', (a) => { bakeSafe(toNum(a.seed, 0)); });
  PluginManager.registerCommand(NAME, 'undo', () => { undoSafe(); });
  PluginManager.registerCommand(NAME, 'live', (a) => { liveNow(toNum(a.seed, 0)); });
  PluginManager.registerCommand(NAME, 'plan', (a) => { setPlan(String(a.show) !== 'false'); });

  function onKey(e) {
    if (!(SceneManager._scene instanceof Scene_Map) || !SceneManager._scene.isActive()) return;
    if (e.keyCode === 118) { e.preventDefault(); if (e.shiftKey) undoSafe(); else bakeSafe(0); }
    else if (e.keyCode === 117) { e.preventDefault(); setPlan(!plan.shown); }
  }
  let keysBound = false;
  function bindKeys() {
    if (keysBound || !PARAMS.hotkeys || !Utils.isOptionValid('test')) return;
    document.addEventListener('keydown', onKey);
    keysBound = true;
  }
  function unbindKeys() { if (keysBound) { document.removeEventListener('keydown', onKey); keysBound = false; } }
  bindKeys();
  window.addEventListener('unload', unbindKeys);

  /** Public surface, for scripts and for the verification harness. */
  window.Strew = {
    params: PARAMS, bake: bakeSafe, undo: undoSafe, live: liveNow, setPlan,
    setIO(next) { io = next || nwIO; },
    lastResult() { return plan.last; },
    analysisFor, tilesetReady, mapNote, defaultSeed,
    dispose: unbindKeys,
  };
})();
