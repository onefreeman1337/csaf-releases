/*:
 * @target MZ
 * @plugindesc [Strew 1.0 core] The map-dressing engine Strew.js drives. Install DIRECTLY ABOVE Strew.js.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io/strew
 *
 * @help StrewCore.js
 * ============================================================================
 * The pure half of Strew. It has no plugin commands and no parameters: it reads
 * a map and a tileset, decides where every flower, tuft, pebble, rock, bush and
 * floor variant goes, and returns the new tile data plus an undo ledger.
 * Strew.js is the half that talks to the engine (playtest bake, live mode,
 * the toast and the plan overlay). Both files are required.
 *
 * Nothing in this file touches the screen, the disk or Math.random(): every
 * pass is a pure function of (map, tileset, seed), so the same seed always
 * gives the same map.
 *
 * Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.
 */
(function (root) {
  'use strict';

  const VERSION = 1;
  /** MZ tile id ranges, copied from rmmz_core.js (Tilemap.TILE_ID_*). */
  const T = { B: 0, C: 256, D: 512, E: 768, A5: 1536, A1: 2048, A2: 2816, A3: 4352, A4: 5888, MAX: 8192 };
  const CATEGORIES = ['bush', 'rock', 'wood', 'pebble', 'tuft', 'flower'];
  /** Worst region-mean distance two fills may show and still be swapped (calibrate.js, see Readme). */
  const VARIANT_REGION_MAX = 22;
  /** A flower tile whose drawing spans less than this share of its square is a single object, not a clump.
   *  MEASURED 2026-10-03 (_probe/_spread.js): the lattice-stamping stock flower (Outside_B 217) spans 0.54;
   *  every clump tile on stock Outside_B and Verdant 01 spans 0.71 to 0.90. The bar sits between. */
  const COMPACT_SPREAD = 0.62;

  /**
   * Hand-picked palettes for RPG Maker MZ's OWN stock sheets, keyed by image name, chosen by
   * looking at every tile. A colour reading cannot tell a boulder from a snowman or a flower bed
   * from a lily pad, and the stock outside sheet holds all of them, so on these sheets the picks
   * replace the reading. IDs are positions on that sheet (0-255). Interior and dungeon sheets get
   * no scatter at all (their small objects are furniture and props, which belong where you put
   * them); floor variants still apply. Edited a stock sheet but kept its name? Use tileset tags.
   */
  const STOCK = {
    Outside_B: { flower: [160, 161, 162, 163, 217, 250], tuft: [152, 155, 218], bush: [153, 154, 166, 246], rock: [159], pebble: [52, 60, 171, 252], wood: [156, 164, 232, 243] },
    Outside_C: {}, Inside_B: {}, Inside_C: {}, Dungeon_B: {}, Dungeon_C: {}, SF_Inside_B: {}, SF_Inside_C: {}, SF_Outside_B: {}, SF_Outside_C: {},
    World_B: {}, World_C: {},
  };

  // ---------------------------------------------------------------- seeded numbers

  /** FNV-1a 32-bit hash of a string. @param {string} s @returns {number} */
  function hashString(s) {
    let h = 0x811c9dc5;
    const str = String(s);
    for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 0x01000193); }
    return h >>> 0;
  }

  /** Integer hash of (seed, x, y) -> uint32. @returns {number} */
  function hash3(seed, x, y) {
    let h = (seed ^ Math.imul(x | 0, 0x27d4eb2d) ^ Math.imul(y | 0, 0x165667b1)) >>> 0;
    h = Math.imul(h ^ (h >>> 15), 0x85ebca6b);
    h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35);
    return (h ^ (h >>> 16)) >>> 0;
  }

  /** Uniform [0,1) from (seed, x, y). */
  function rand3(seed, x, y) { return hash3(seed, x, y) / 4294967296; }

  /** mulberry32 stream. @param {number} a @returns {function(): number} */
  function stream(a) {
    let s = a >>> 0;
    return function () {
      s = (s + 0x6d2b79f5) >>> 0;
      let t = s;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function smooth(t) { return t * t * (3 - 2 * t); }

  /** Value noise in [0,1] on a lattice of the given scale (cells per feature). */
  function valueNoise(seed, x, y, scale) {
    const fx = x / scale, fy = y / scale;
    const x0 = Math.floor(fx), y0 = Math.floor(fy);
    const tx = smooth(fx - x0), ty = smooth(fy - y0);
    const a = rand3(seed, x0, y0), b = rand3(seed, x0 + 1, y0);
    const c = rand3(seed, x0, y0 + 1), d = rand3(seed, x0 + 1, y0 + 1);
    return (a + (b - a) * tx) * (1 - ty) + (c + (d - c) * tx) * ty;
  }

  /** Two-octave noise, normalised back to [0,1]. */
  function fbm(seed, x, y, scale) {
    return (valueNoise(seed, x, y, scale) * 0.68 + valueNoise(seed ^ 0x5bd1e995, x, y, scale / 2.3) * 0.32);
  }

  function smoothstep(e0, e1, v) {
    if (v <= e0) return 0;
    if (v >= e1) return 1;
    return smooth((v - e0) / (e1 - e0));
  }

  // ---------------------------------------------------------------- tile ids

  function isAutotile(id) { return id >= T.A1 && id < T.MAX; }
  function isA1(id) { return id >= T.A1 && id < T.A2; }
  function isA2(id) { return id >= T.A2 && id < T.A3; }
  function isA5(id) { return id >= T.A5 && id < T.A1; }
  function isUpperNormal(id) { return id > 0 && id < T.A5; }
  function autotileKind(id) { return Math.floor((id - T.A1) / 48); }

  /**
   * Where a NORMAL tile (B-E or A5) sits on its sheet, in tiles. Mirrors
   * Tilemap.prototype._addNormalTile (rmmz_core.js:2483-2498).
   * @returns {{sheet:string, col:number, row:number}}
   */
  function normalTileCell(id) {
    const sheet = isA5(id) ? 'A5' : ['B', 'C', 'D', 'E'][Math.floor(id / 256)];
    const col = (Math.floor(id / 128) % 2) * 8 + (id % 8);
    const row = Math.floor((id % 256) / 8) % 16;
    return { sheet, col, row };
  }

  /** Inverse of normalTileCell for B-E (sheetIndex 0..3) and A5 (sheetIndex -1). */
  function normalTileId(sheetIndex, col, row) {
    const base = sheetIndex < 0 ? T.A5 : sheetIndex * 256;
    return base + (col >= 8 ? 128 : 0) + row * 8 + (col % 8);
  }

  // ---------------------------------------------------------------- pixels -> profile

  /**
   * Measures one tile's pixels: coverage, colour families and whether the opaque
   * part touches the tile border (an object that touches the border is a piece
   * of something bigger, never a scatterable decoration).
   * @param {Uint8ClampedArray|Uint8Array|Buffer} px RGBA of the whole sheet
   * @param {number} imgW sheet width in pixels
   * @param {number} sx left of the tile in pixels
   * @param {number} sy top of the tile in pixels
   * @param {number} s tile size in pixels
   */
  function profileTile(px, imgW, sx, sy, s) {
    let n = 0, sr = 0, sg = 0, sb = 0, green = 0, accent = 0, grey = 0, brown = 0, blue = 0, lumSum = 0, lumSq = 0, ax = 0, ay = 0;
    let tn = 0, ts = 0, tw = 0, te = 0, minX = s, maxX = -1, minY = s, maxY = -1;
    const band = Math.max(1, Math.round(s / 24));
    for (let y = 0; y < s; y++) {
      for (let x = 0; x < s; x++) {
        const o = ((sy + y) * imgW + (sx + x)) * 4;
        if (px[o + 3] < 40) continue;
        n++;
        if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y;
        const r = px[o], g = px[o + 1], b = px[o + 2];
        sr += r; sg += g; sb += b;
        const mx = Math.max(r, g, b), mn = Math.min(r, g, b);
        const v = mx / 255, sat = mx === 0 ? 0 : (mx - mn) / mx;
        let hue = 0;
        if (mx !== mn) {
          if (mx === r) hue = 60 * (((g - b) / (mx - mn)) % 6);
          else if (mx === g) hue = 60 * ((b - r) / (mx - mn) + 2);
          else hue = 60 * ((r - g) / (mx - mn) + 4);
          if (hue < 0) hue += 360;
        }
        const lum = 0.299 * r + 0.587 * g + 0.114 * b;
        lumSum += lum; lumSq += lum * lum;
        if (sat < 0.2) grey++;
        else if (hue >= 65 && hue <= 165) green++;
        else if (hue > 165 && hue < 250) blue++;
        else if (hue >= 12 && hue < 52 && v < 0.72 && sat < 0.8) brown++;
        if (sat > 0.42 && v > 0.45 && !(hue >= 65 && hue <= 165) && !(hue >= 12 && hue < 52 && v < 0.72)) {
          accent++;
          ax += Math.cos(hue * Math.PI / 180); ay += Math.sin(hue * Math.PI / 180);
        }
        if (y < band) tn++;
        if (y >= s - band) ts++;
        if (x < band) tw++;
        if (x >= s - band) te++;
      }
    }
    const area = s * s, edge = band * s;
    const d = Math.max(1, n);
    const meanLum = lumSum / d;
    return {
      coverage: n / area,
      r: sr / d, g: sg / d, b: sb / d,
      lum: meanLum, lumStd: Math.sqrt(Math.max(0, lumSq / d - meanLum * meanLum)),
      green: green / d, accent: accent / d, grey: grey / d, brown: brown / d, blue: blue / d,
      touch: Math.max(tn, ts, tw, te) / edge,
      accentHue: accent ? ((Math.atan2(ay, ax) * 180 / Math.PI) + 360) % 360 : -1,
      // How much of the square the drawing spans: a clump of blooms spreads, a single flower is compact.
      spread: maxX < 0 ? 0 : Math.max(maxX - minX + 1, maxY - minY + 1) / s,
    };
  }

  /**
   * Groups flower tiles into SPECIES by the hue of their blooms, so one drift
   * can be all one flower (a patch of yellow, a patch of violet) the way real
   * meadows grow, instead of every colour sprinkled through every patch.
   * @returns {number[][]} tile id groups
   */
  function flowerSpecies(ids, profiles) {
    const groups = [];
    for (const id of ids) {
      const h = profiles.get(id) ? profiles.get(id).accentHue : -1;
      let home = null;
      for (const g of groups) {
        const d = Math.abs(g.hue - h), dd = Math.min(d, 360 - d);
        if (h >= 0 && dd <= 28) { home = g; break; }
      }
      if (home) home.ids.push(id); else groups.push({ hue: h, ids: [id] });
    }
    return groups.map((g) => g.ids);
  }

  /**
   * Decoration category of a profiled tile, or null. Calibrated on CSAF's own
   * Verdant sheets and RPG Maker's stock outside sheets; every threshold is a
   * share of the tile, never a raw pixel count, so it holds at 48 px.
   * @returns {string|null}
   */
  function classifyDecor(p) {
    if (p.coverage < 0.015 || p.coverage > 0.62) return null;
    if (p.touch > 0.2) return null;
    if (p.accent >= 0.1 && p.coverage < 0.38) return 'flower';
    if (p.green >= 0.55) return p.coverage < 0.2 ? 'tuft' : 'bush';
    if (p.grey >= 0.5) return p.coverage < 0.17 ? 'pebble' : 'rock';
    if (p.brown >= 0.4) return 'wood';
    return null;
  }

  /** Ground family of a profiled fill: green | water | stone | earth. */
  function groundFamily(p) {
    if (p.blue >= 0.45) return 'water';
    if (p.green >= 0.45) return 'green';
    if (p.grey >= 0.55) return 'stone';
    return 'earth';
  }

  function colourDistance(a, b) {
    const dr = a.r - b.r, dg = a.g - b.g, db = a.b - b.b;
    return Math.sqrt(dr * dr + dg * dg + db * db);
  }

  /**
   * Eight region means of an opaque tile: four quadrants and four border strips.
   * Two fills are interchangeable only if EVERY region agrees, because a
   * transition tile (dirt with a grass lip) matches the plain fill on its mean
   * colour and differs exactly at one edge, which is where a swap would show.
   * @returns {number[]} 24 numbers (r,g,b per region)
   */
  function regionSignature(px, imgW, sx, sy, s) {
    const h = s >> 1, b = Math.max(2, Math.round(s / 8)), k = Math.max(3, Math.round(s / 6));
    // Quadrants, border strips, and the four CORNER boxes: a 47-mask inner corner is a notch
    // a few pixels across that no quadrant or strip mean can see.
    const rects = [[0, 0, h, h], [h, 0, s, h], [0, h, h, s], [h, h, s, s], [0, 0, s, b], [0, s - b, s, s], [0, 0, b, s], [s - b, 0, s, s],
      [0, 0, k, k], [s - k, 0, s, k], [0, s - k, k, s], [s - k, s - k, s, s]];
    const out = [];
    for (const r of rects) {
      let n = 0, sr = 0, sg = 0, sb = 0;
      for (let y = r[1]; y < r[3]; y++) for (let x = r[0]; x < r[2]; x++) {
        const o = ((sy + y) * imgW + (sx + x)) * 4;
        sr += px[o]; sg += px[o + 1]; sb += px[o + 2]; n++;
      }
      out.push(sr / n, sg / n, sb / n);
    }
    return out;
  }

  /** Largest per-region colour distance between two signatures. */
  function signatureDistance(a, b) {
    let worst = 0;
    for (let i = 0; i < a.length; i += 3) {
      const dr = a[i] - b[i], dg = a[i + 1] - b[i + 1], db = a[i + 2] - b[i + 2];
      worst = Math.max(worst, Math.sqrt(dr * dr + dg * dg + db * db));
    }
    return worst;
  }

  // ---------------------------------------------------------------- tileset analysis

  /** Parses `<Strew Flower: 1,2,3>`-style tags out of a note. @returns {Object<string, number[]>} */
  function parseNoteLists(note) {
    const out = {};
    // Forgiving: a typo in one entry drops that entry, never the whole tag.
    const re = /<\s*strew\s+(flower|tuft|bush|pebble|rock|wood|exclude|variants)\s*:\s*([^>]*)>/gi;
    let m;
    while ((m = re.exec(String(note || ''))) !== null) {
      const key = m[1].toLowerCase();
      // Only real normal-tile positions: B-E (1-1023) and A5 (1536-1663). Anything else is ignored, never placed.
      const ids = m[2].split(',').map((x) => Number(x.trim())).filter((x) => Number.isInteger(x) && ((x > 0 && x < 1024) || (x >= T.A5 && x < T.A5 + 128)));
      if (key === 'variants') (out.variants = out.variants || []).push(ids);
      else out[key] = (out[key] || []).concat(ids);
    }
    return out;
  }

  /**
   * Reads a tileset: which B-E tiles are scatterable decorations (and of what
   * kind), which opaque tiles are interchangeable floor variants of each other,
   * and what ground family every A tile belongs to.
   * @param {object} ts { flags:number[], note:string, tileSize:number,
   *   sheets:{A1..A5,B..E: {px,w,h}|null} }
   */
  function analyseTileset(ts) {
    const s = ts.tileSize || 48;
    const flags = ts.flags || [];
    const notes = parseNoteLists(ts.note);
    const exclude = new Set(notes.exclude || []);
    const decor = { bush: [], rock: [], wood: [], pebble: [], tuft: [], flower: [] };
    const fills = [];
    const profiles = new Map();
    const sheetKeys = ['B', 'C', 'D', 'E'];
    const names = ts.names || {};
    const source = {};
    const scan = (sheetIndex, key) => {
      const sh = ts.sheets && ts.sheets[key];
      if (!sh || !sh.px) return;
      const stock = sheetIndex >= 0 ? STOCK[names[key]] : null;
      if (stock) {
        source[key] = 'stock';
        for (const cat of CATEGORIES) for (const local of stock[cat] || []) {
          const id = sheetIndex * 256 + local;
          if (!exclude.has(id)) decor[cat].push(id);
        }
      } else if (sheetIndex >= 0) source[key] = 'read';
      const cols = Math.floor(sh.w / s), rows = Math.floor(sh.h / s);
      for (let row = 0; row < rows && row < 16; row++) {
        for (let col = 0; col < cols && col < 16; col++) {
          const id = normalTileId(sheetIndex, col, row);
          if (id === 0) continue; // B0 is MZ's empty tile
          const p = profileTile(sh.px, sh.w, col * s, row * s, s);
          if (p.coverage === 0) continue;
          profiles.set(id, p);
          if (exclude.has(id)) continue;
          if (sheetIndex >= 0 && !stock) {
            const cat = classifyDecor(p);
            if (cat) decor[cat].push(id);
          }
          if (p.coverage >= 0.985) { p.sig = regionSignature(sh.px, sh.w, col * s, row * s, s); fills.push(id); }
        }
      }
    };
    scan(-1, 'A5');
    for (let i = 0; i < 4; i++) scan(i, sheetKeys[i]);
    // Hand overrides win over the reading, category by category.
    for (const cat of CATEGORIES) if (notes[cat] && notes[cat].length) decor[cat] = notes[cat].filter((id) => !exclude.has(id));
    // Floor variants: opaque tiles of the same flags whose mean colour and texture agree.
    const variantsOf = new Map();
    const groups = [];
    if (notes.variants) for (const g of notes.variants) groups.push(g.slice());
    else {
      // Linked groups (union-find): a fill joins a group if it is close to ANY member, so a
      // seeded set of four grass variants is one group even when its two extremes differ more.
      const parent = new Map();
      const find = (x) => { while (parent.get(x) !== x) { parent.set(x, parent.get(parent.get(x))); x = parent.get(x); } return x; };
      for (const a of fills) parent.set(a, a);
      for (let i = 0; i < fills.length; i++) {
        const a = fills[i], pa = profiles.get(a);
        for (let j = i + 1; j < fills.length; j++) {
          const b = fills[j], pb = profiles.get(b);
          if ((flags[a] || 0) !== (flags[b] || 0)) continue;
          if (colourDistance(pa, pb) <= 13 && Math.abs(pa.lumStd - pb.lumStd) <= 9 && signatureDistance(pa.sig, pb.sig) <= VARIANT_REGION_MAX) parent.set(find(a), find(b));
        }
      }
      const byRoot = new Map();
      for (const a of fills) { const r = find(a); if (!byRoot.has(r)) byRoot.set(r, []); byRoot.get(r).push(a); }
      for (const g of byRoot.values()) if (g.length > 1) groups.push(g);
    }
    for (const g of groups) for (const id of g) variantsOf.set(id, g);
    // Ground family of every autotile kind that has art, from the interior of its block.
    const kindFamily = new Map();
    const famOfKind = (key, base, kinds, blockW, blockH) => {
      const sh = ts.sheets && ts.sheets[key];
      if (!sh || !sh.px) return;
      for (let k = 0; k < kinds; k++) {
        const bx = (k % 8) * blockW * s, by = Math.floor(k / 8) * blockH * s;
        if (bx + 2 * s > sh.w || by + 3 * s > sh.h) continue;
        const p = profileTile(sh.px, sh.w, bx + Math.floor(s / 2), by + s + Math.floor(s / 2), s);
        if (p.coverage < 0.5) continue;
        kindFamily.set(Math.floor((base - T.A1) / 48) + k, key === 'A1' ? 'water' : groundFamily(p));
      }
    };
    famOfKind('A1', T.A1, 16, 2, 3);
    famOfKind('A2', T.A2, 32, 2, 3);
    const familyOf = (id) => {
      if (id <= 0) return null;
      if (isA1(id)) return 'water';
      if (isAutotile(id)) {
        if (!isA2(id)) return 'wall';
        const f = kindFamily.get(autotileKind(id));
        return f || 'earth';
      }
      const p = profiles.get(id);
      return p && p.coverage >= 0.985 ? groundFamily(p) : null;
    };
    // Variants that carry blooms (a flowered grass) are ACCENTS: they belong in a drift's halo,
    // never sprinkled across the whole field where they read as noise.
    const accentVariant = new Set();
    for (const g of groups) {
      // Relative to the group's plainest member: a whole sand or water fill is "colourful" but plain for itself.
      let floor = Infinity;
      for (const id of g) { const p = profiles.get(id); if (p) floor = Math.min(floor, p.accent); }
      for (const id of g) { const p = profiles.get(id); if (p && p.accent - floor >= 0.004) accentVariant.add(id); }
    }
    const species = flowerSpecies(decor.flower, profiles);
    // A species drawn as ONE small object centred in its square stamps a lattice when packed into a
    // drift (the same object at the same spot in every square). Those are placed sparsely, never touching.
    const compactSpecies = new Set();
    species.forEach((g, k) => { if (g.every((id) => { const p = profiles.get(id); return p && p.spread < COMPACT_SPREAD; })) compactSpecies.add(k); });
    return { decor, species, compactSpecies, variantsOf, accentVariant, groups, profiles, kindFamily, familyOf, tileSize: s, source };
  }

  // ---------------------------------------------------------------- map helpers

  /** MZ's Game_Map.checkPassage over the 4 tile layers (rmmz_objects.js:6592), events ignored. */
  function passableAt(data, flags, w, h, x, y) {
    for (let z = 3; z >= 0; z--) {
      const id = data[(z * h + y) * w + x] || 0;
      const f = flags[id] || 0;
      if ((f & 0x10) !== 0) continue;
      if ((f & 0x0f) === 0) return true;
      if ((f & 0x0f) === 0x0f) return false;
    }
    return false;
  }

  /** 4-neighbour BFS distance from every seed cell over cells where `through(i)` holds. */
  function distanceField(w, h, isSeed, through, cap) {
    const n = w * h, dist = new Int16Array(n).fill(cap), q = new Int32Array(n);
    let head = 0, tail = 0;
    for (let i = 0; i < n; i++) if (isSeed(i)) { dist[i] = 0; q[tail++] = i; }
    while (head < tail) {
      const i = q[head++], d = dist[i] + 1;
      if (d >= cap) continue;
      const x = i % w, y = (i / w) | 0;
      const nb = [x > 0 ? i - 1 : -1, x < w - 1 ? i + 1 : -1, y > 0 ? i - w : -1, y < h - 1 ? i + w : -1];
      for (const j of nb) if (j >= 0 && dist[j] > d && through(j)) { dist[j] = d; q[tail++] = j; }
    }
    return dist;
  }

  /** Number of 4-connected components of the passable set (used by the route proof). */
  function countComponents(w, h, pass) {
    const n = w * h, seen = new Uint8Array(n), q = new Int32Array(n);
    let comps = 0;
    for (let s0 = 0; s0 < n; s0++) {
      if (!pass[s0] || seen[s0]) continue;
      comps++;
      let head = 0, tail = 0;
      q[tail++] = s0; seen[s0] = 1;
      while (head < tail) {
        const i = q[head++], x = i % w, y = (i / w) | 0;
        if (x > 0 && pass[i - 1] && !seen[i - 1]) { seen[i - 1] = 1; q[tail++] = i - 1; }
        if (x < w - 1 && pass[i + 1] && !seen[i + 1]) { seen[i + 1] = 1; q[tail++] = i + 1; }
        if (y > 0 && pass[i - w] && !seen[i - w]) { seen[i - w] = 1; q[tail++] = i - w; }
        if (y < h - 1 && pass[i + w] && !seen[i + w]) { seen[i + w] = 1; q[tail++] = i + w; }
      }
    }
    return comps;
  }

  /** Would blocking cell c split the passable set? Local proof: all of c's passable neighbours stay connected. */
  function blockingIsSafe(w, h, pass, c) {
    const x = c % w, y = (c / w) | 0;
    const nb = [];
    if (x > 0 && pass[c - 1]) nb.push(c - 1);
    if (x < w - 1 && pass[c + 1]) nb.push(c + 1);
    if (y > 0 && pass[c - w]) nb.push(c - w);
    if (y < h - 1 && pass[c + w]) nb.push(c + w);
    if (nb.length <= 1) return true;
    const n = w * h, seen = new Uint8Array(n), q = new Int32Array(n);
    seen[c] = 1;
    let head = 0, tail = 0, found = 1;
    q[tail++] = nb[0]; seen[nb[0]] = 1;
    const want = new Set(nb.slice(1));
    while (head < tail && found < nb.length) {
      const i = q[head++], ix = i % w, iy = (i / w) | 0;
      const cand = [ix > 0 ? i - 1 : -1, ix < w - 1 ? i + 1 : -1, iy > 0 ? i - w : -1, iy < h - 1 ? i + w : -1];
      for (const j of cand) {
        if (j < 0 || seen[j] || !pass[j]) continue;
        seen[j] = 1;
        if (want.has(j)) found++;
        q[tail++] = j;
      }
    }
    return found >= nb.length;
  }

  // ---------------------------------------------------------------- the pass

  /** Defaults for every density knob. Strew.js passes a multiplier, never these. */
  const STYLE = {
    flower: { base: 0.82, spacing: 0, patchScale: 4.6, patchLo: 0.55, patchHi: 0.68 },
    tuft: { base: 0.09, edge: 0.34, spacing: 1 },
    bush: { base: 0.3, spacing: 2 },
    rock: { base: 0.16, corner: 0.42, spacing: 2 },
    pebble: { base: 0.035, edge: 0.22, corner: 0.3, spacing: 1 },
    wood: { base: 0.018, edge: 0.06, spacing: 3 },
    variantRate: 0.3,
  };

  /**
   * Dresses one map. Pure: returns new data and an undo ledger; the input is not mutated.
   * @param {object} input
   *   width, height, data (MZ map data, 6 layers), events [{x,y}], flags (tileset flags),
   *   analysis (from analyseTileset), seed (number), density (multiplier, default 1),
   *   maskRegions (number[]), skip (category names to leave out)
   * @returns {{data:number[], ledger:number[][], report:object, plan:object}}
   */
  function dress(input) {
    const w = input.width, h = input.height, n = w * h;
    const flags = input.flags || [];
    const A = input.analysis;
    const seed = (input.seed >>> 0) || 1;
    // A non-number density is the default, never NaN: NaN fails every comparison, which would place EVERYTHING.
    const dRaw = input.density == null ? 1 : Number(input.density);
    const density = Number.isFinite(dRaw) ? Math.max(0, dRaw) : 1;
    const mask = new Set((input.maskRegions || []).map(Number).filter((r) => r > 0));
    const skip = new Set(input.skip || []);
    const src = input.data;
    const data = src.slice();
    const ledger = [];
    const layer = (z, i) => z * n + i;

    // Cell facts.
    const pass = new Uint8Array(n), family = new Array(n), upperBusy = new Uint8Array(n), region = new Uint8Array(n);
    for (let i = 0; i < n; i++) {
      const x = i % w, y = (i / w) | 0;
      pass[i] = passableAt(src, flags, w, h, x, y) ? 1 : 0;
      const z1 = src[layer(1, i)] || 0, z0 = src[layer(0, i)] || 0;
      family[i] = A.familyOf(z1 && !isUpperNormal(z1) ? z1 : z0) || (z1 ? A.familyOf(z1) : null);
      upperBusy[i] = (src[layer(2, i)] || 0) || (src[layer(3, i)] || 0) ? 1 : 0;
      region[i] = src[layer(5, i)] || 0;
    }
    const passBefore = pass.slice();
    const componentsBefore = countComponents(w, h, pass);

    // Protected: events and the square around them, masked regions.
    const guard = new Uint8Array(n);
    for (const ev of input.events || []) {
      if (ev == null) continue;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        if (Math.abs(dx) + Math.abs(dy) > 1) continue;
        const x = ev.x + dx, y = ev.y + dy;
        if (x >= 0 && y >= 0 && x < w && y < h) guard[y * w + x] = 1;
      }
    }
    for (let i = 0; i < n; i++) if (mask.has(region[i])) guard[i] = 2;

    const CAP = 32;
    // Paths: a connected run of walkable non-green ground that is LONG for its width (a road,
    // never a plaza). Width = twice the deepest inside distance + 1; a run is a path when its
    // area is at least three squares of that width (a 2-wide road qualifies at length 6, a 5x3
    // plaza does not).
    const path = new Uint8Array(n);
    const inside = distanceField(w, h, (i) => {
      const x = i % w, y = (i / w) | 0, f = family[i];
      return (x > 0 && family[i - 1] !== f) || (x < w - 1 && family[i + 1] !== f) || (y > 0 && family[i - w] !== f) || (y < h - 1 && family[i + w] !== f) || !pass[i];
    }, () => true, CAP);
    {
      const comp = new Int32Array(n).fill(-1), q = new Int32Array(n);
      for (let s0 = 0; s0 < n; s0++) {
        if (comp[s0] >= 0 || !pass[s0] || family[s0] === 'green' || family[s0] == null || family[s0] === 'water') continue;
        let head = 0, tail = 0, deep = 0;
        q[tail++] = s0; comp[s0] = s0;
        while (head < tail) {
          const i = q[head++], x = i % w, y = (i / w) | 0;
          if (inside[i] > deep) deep = inside[i];
          for (const j of [x > 0 ? i - 1 : -1, x < w - 1 ? i + 1 : -1, y > 0 ? i - w : -1, y < h - 1 ? i + w : -1]) {
            if (j < 0 || comp[j] >= 0 || !pass[j] || family[j] !== family[s0]) continue;
            comp[j] = s0; q[tail++] = j;
          }
        }
        const width = 2 * deep + 1;
        if (tail >= 3 * width * width && deep <= 2) for (let k = 0; k < tail; k++) path[q[k]] = 1;
      }
    }
    const dBlock = distanceField(w, h, (i) => !pass[i], () => true, CAP);
    const dEdge = distanceField(w, h, (i) => {
      const x = i % w, y = (i / w) | 0;
      const f = family[i];
      return (x > 0 && family[i - 1] !== f) || (x < w - 1 && family[i + 1] !== f) || (y > 0 && family[i - w] !== f) || (y < h - 1 && family[i + w] !== f);
    }, () => true, CAP);
    const dPath = distanceField(w, h, (i) => path[i] === 1, () => true, CAP);

    const blockedNeighbours = (i) => {
      const x = i % w, y = (i / w) | 0;
      return (x === 0 || !pass[i - 1] ? 1 : 0) + (x === w - 1 || !pass[i + 1] ? 1 : 0) + (y === 0 || !pass[i - w] ? 1 : 0) + (y === h - 1 || !pass[i + w] ? 1 : 0);
    };
    const pathFall = (i) => (path[i] ? 0 : dPath[i] === 1 ? 0.25 : dPath[i] === 2 ? 0.6 : 1);

    const placedCat = new Array(n).fill(null);
    const report = { version: VERSION, seed, placed: {}, variants: 0, protected: 0, blockingRefused: 0, cells: n };
    for (const c of CATEGORIES) report.placed[c] = 0;
    for (let i = 0; i < n; i++) if (guard[i] || path[i] || !pass[i] || upperBusy[i]) report.protected++;

    const order = new Int32Array(n);
    const compactIds = new Set();
    if (A.compactSpecies) A.compactSpecies.forEach((k) => (A.species[k] || []).forEach((id) => compactIds.add(id)));
    // The drift field: where flowers gather. Computed for every cell up front because the
    // floor-variant pass also reads it (flowered grass belongs in a drift's halo, nowhere else).
    const flowerPatch = new Float32Array(n);
    const halo = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      if (family[i] !== 'green') continue;
      const pv = fbm(seed ^ 0x9e3779b9, i % w, (i / w) | 0, STYLE.flower.patchScale);
      flowerPatch[i] = smoothstep(STYLE.flower.patchLo, STYLE.flower.patchHi, pv);
      halo[i] = smoothstep(STYLE.flower.patchLo - 0.05, STYLE.flower.patchHi, pv);
    }

    const densityFor = (cat, i) => {
      const fam = family[i], x = i % w, y = (i / w) | 0;
      const nearBlock = dBlock[i] === 1, nearEdge = dEdge[i] <= 1;
      const corner = blockedNeighbours(i) >= 2;
      const S = STYLE[cat];
      switch (cat) {
        case 'flower': {
          if (fam !== 'green') return 0;
          return S.base * flowerPatch[i] * pathFall(i) * (nearBlock ? 0.5 : 1);
        }
        case 'tuft': {
          if (fam !== 'green' && !(nearEdge && fam !== 'water')) return 0;
          const lift = nearBlock || nearEdge ? S.edge : dBlock[i] === 2 ? S.edge * 0.4 : 0;
          const wob = 0.55 + 0.9 * fbm(seed ^ 0x7f4a7c15, x, y, 6);
          return (S.base + lift) * wob * pathFall(i);
        }
        case 'bush':
          return fam === 'green' && nearBlock && !path[i] && dPath[i] > 1 ? S.base * (0.4 + fbm(seed ^ 0x2545f491, x, y, 5)) : 0;
        case 'rock':
          if (!nearBlock || path[i] || dPath[i] <= 1) return 0;
          return corner ? S.corner : S.base * (fam === 'stone' || fam === 'earth' ? 1.4 : 0.6);
        case 'pebble': {
          if (fam === 'water') return 0;
          if (path[i]) return 0;
          let d = fam === 'green' ? 0 : S.base;
          if (nearEdge && fam === 'green' && dEdge[i] === 1) d += S.edge;
          if (corner) d += S.corner;
          return d * pathFall(i);
        }
        case 'wood':
          if (fam !== 'green' || path[i]) return 0;
          return (nearBlock ? S.edge : S.base) * pathFall(i);
        default: return 0;
      }
    };

    const blocks = (id) => {
      const f = flags[id] || 0;
      return (f & 0x10) === 0 && (f & 0x0f) === 0x0f;
    };

    for (const cat of CATEGORIES) {
      const ids = A.decor[cat] || [];
      if (!ids.length || skip.has(cat)) continue;
      const S = STYLE[cat];
      // A seeded shuffle decides the visiting order, so spacing never favours the top-left.
      for (let i = 0; i < n; i++) order[i] = i;
      const rnd = stream(seed ^ hashString(cat));
      for (let i = n - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); const t = order[i]; order[i] = order[j]; order[j] = t; }
      for (let k = 0; k < n; k++) {
        const i = order[k];
        if (!pass[i] || guard[i] || upperBusy[i] || placedCat[i]) continue;
        const dens = densityFor(cat, i) * density;
        if (dens <= 0 || rnd() >= dens) continue;
        if (S.spacing > 0) {
          const x = i % w, y = (i / w) | 0;
          let clash = false;
          for (let dy = -S.spacing; dy <= S.spacing && !clash; dy++) for (let dx = -S.spacing; dx <= S.spacing; dx++) {
            const xx = x + dx, yy = y + dy;
            if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
            if (placedCat[yy * w + xx] === cat) { clash = true; break; }
          }
          if (clash) continue;
        }
        // Pick the tile: hashed, but never the same tile as a 4-neighbour.
        const x = i % w, y = (i / w) | 0;
        const nbIds = [];
        for (const j of [x > 0 ? i - 1 : -1, x < w - 1 ? i + 1 : -1, y > 0 ? i - w : -1, y < h - 1 ? i + w : -1]) if (j >= 0) nbIds.push(data[layer(2, j)] || 0);
        // Flowers: one SPECIES per drift, chosen by a slow field, so a patch reads as one flower.
        let pool = ids;
        if (cat === 'flower' && A.species && A.species.length) {
          let k = 0;
          if (A.species.length > 1) {
            const v = fbm(seed ^ 0x51ed270b, x, y, 9);
            k = Math.min(A.species.length - 1, Math.max(0, Math.floor(((v - 0.28) / 0.44) * A.species.length)));
          }
          pool = A.species[k];
          const compact = !!(A.compactSpecies && A.compactSpecies.has(k));
          if (compact && rnd() >= 0.4) continue;
          // Symmetric: a single flower never touches any flower, and no flower lands beside a single one.
          let touching = false;
          for (let dy = -1; dy <= 1 && !touching; dy++) for (let dx = -1; dx <= 1; dx++) {
            const xx = x + dx, yy = y + dy;
            if (!(dx || dy) || xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
            const j = yy * w + xx;
            if (placedCat[j] === 'flower' && (compact || compactIds.has(data[layer(2, j)]))) { touching = true; break; }
          }
          if (touching) continue;
        }
        let pickIdx = hash3(seed ^ 0x3c6ef372, x, y) % pool.length;
        for (let t = 0; t < pool.length && nbIds.indexOf(pool[pickIdx]) >= 0; t++) pickIdx = (pickIdx + 1) % pool.length;
        const id = pool[pickIdx];
        if (blocks(id)) {
          if (dBlock[i] !== 1 || !blockingIsSafe(w, h, pass, i)) { report.blockingRefused++; continue; }
          pass[i] = 0;
        }
        const zi = layer(2, i);
        ledger.push([zi, data[zi] || 0, id]);
        data[zi] = id;
        placedCat[i] = cat;
        report.placed[cat]++;
      }
    }

    // Floor variants: break up a repeated fill so no two neighbours match where the art allows.
    if (!skip.has('variants') && A.variantsOf.size) {
      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          const i = y * w + x;
          if (src[layer(1, i)] || guard[i] === 2) continue; // kept-clear regions keep their floor too
          const z0 = src[layer(0, i)] || 0;
          const g = A.variantsOf.get(z0);
          if (!g) continue;
          // Only inside a repeated fill: at least two 4-neighbours hold a tile of the same group.
          // A piece of a multi-cell object (a tree's trunk, a grounded bush) sits beside OTHER
          // pieces, so it never qualifies and is never swapped for a piece of something else.
          let same = 0;
          if (x > 0 && g.indexOf(src[layer(0, i - 1)]) >= 0) same++;
          if (x < w - 1 && g.indexOf(src[layer(0, i + 1)]) >= 0) same++;
          if (y > 0 && g.indexOf(src[layer(0, i - w)]) >= 0) same++;
          if (y < h - 1 && g.indexOf(src[layer(0, i + w)]) >= 0) same++;
          if (same < 2) continue;
          // Accented variants (blooms in the grass) only in a drift's halo; plain ones anywhere.
          // Dense at the drift's heart, thinning to nothing at its edge (probability falls with the field).
          const inHalo = halo[i] > 0.05 && rand3(seed ^ 0x2f6b2c1d, x, y) < 0.9 * halo[i] * halo[i];
          const pool = g.filter((t) => (inHalo ? A.accentVariant.has(t) : !A.accentVariant.has(t)));
          if (!pool.length) continue;
          if (!inHalo) {
            const gate = rand3(seed ^ 0x1b873593, x, y);
            if (gate >= STYLE.variantRate * Math.min(2, density)) continue;
          }
          const left = x > 0 ? data[layer(0, i - 1)] : -1, up = y > 0 ? data[layer(0, i - w)] : -1;
          let pick = hash3(seed ^ 0x85ebca6b, x, y) % pool.length;
          for (let t = 0; t < pool.length && (pool[pick] === left || pool[pick] === up || pool[pick] === z0); t++) pick = (pick + 1) % pool.length;
          const id = pool[pick];
          if (id === z0 || id === left || id === up) continue;
          ledger.push([layer(0, i), z0, id]);
          data[layer(0, i)] = id;
          report.variants++;
        }
      }
    }

    report.total = ledger.length;
    report.componentsBefore = componentsBefore;
    report.componentsAfter = countComponents(w, h, pass);
    let lostPass = 0;
    for (let i = 0; i < n; i++) if (passBefore[i] && !pass[i]) lostPass++;
    report.cellsMadeSolid = lostPass;
    return { data, ledger, report, plan: { guard, path, family, placedCat, flowerPatch, halo, dBlock } };
  }

  /**
   * Reverses a ledger on `data` in place, but only where a cell still holds what
   * Strew put there, so edits made after the pass survive the undo.
   * @returns {{restored:number, kept:number}}
   */
  function undo(data, ledger) {
    let restored = 0, kept = 0;
    for (let k = ledger.length - 1; k >= 0; k--) {
      const e = ledger[k];
      if ((data[e[0]] || 0) === e[2]) { data[e[0]] = e[1]; restored++; } else kept++;
    }
    return { restored, kept };
  }

  /** Applies a ledger forward on `data` in place (live mode and bake both use it). */
  function apply(data, ledger) {
    for (const e of ledger) data[e[0]] = e[2];
    return ledger.length;
  }

  const StrewCore = {
    VERSION, T, CATEGORIES, STYLE, STOCK,
    hashString, hash3, rand3, stream, valueNoise, fbm,
    normalTileCell, normalTileId, profileTile, regionSignature, signatureDistance, classifyDecor, groundFamily, parseNoteLists, VARIANT_REGION_MAX,
    analyseTileset, passableAt, distanceField, countComponents, blockingIsSafe,
    dress, undo, apply,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = StrewCore;
  root.StrewCore = StrewCore;
})(typeof window !== 'undefined' ? window : globalThis);
