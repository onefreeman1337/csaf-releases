//=============================================================================
// SentimentArt.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Sentiment [2/3] — the drawing kit: washes, scribbles and the emotion wheel. No engine code. v1.0.0
 * @author CSAF — Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The drawing half of Sentiment. Every function here takes an HTML canvas
 * 2D context and draws on it; none of them knows RPG Maker exists. A face or
 * a battler is never replaced: your own art is drawn first and the feeling is
 * drawn OVER it, the way an artist would mark up a sheet:
 *
 *   a WASH in the feeling's colour, heavier on each rung,
 *   a hand-drawn OUTLINE scribbled around the figure (or the portrait frame),
 *   and the feeling's MARKS: sparkles for happy, falling streaks for sad,
 *   anger crosses and jagged ticks for angry.
 *
 * Every stroke is laid on a pale halo first so it reads on a dark portrait
 * and a light one alike. Every result is baked once per face and rung and
 * cached by Sentiment.js; nothing here runs per frame.
 *
 * Load order: SentimentCore, SentimentArt, Sentiment.
 */
/* eslint-disable no-var */
(function (root) {
  'use strict';

  function core() { return root.CSAF && root.CSAF.SentimentCore; }

  /** Ink and wash per feeling. Every wash colour carries real chroma (never a grey tint). `label` is the badge
   *  word's colour, chosen for at least 7:1 on the badge's plate (tests/art.test.js measures it). */
  var INK = {
    happy: { ink: '#b4570a', mark: '#f4b42a', wash: [255, 196, 70], halo: 'rgba(255,250,232,0.85)', label: '#ffd77a' },
    sad: { ink: '#16357a', mark: '#4f86de', wash: [62, 110, 210], halo: 'rgba(236,244,255,0.85)', label: '#a9c8ff' },
    angry: { ink: '#7d0f08', mark: '#e3402c', wash: [226, 58, 38], halo: 'rgba(255,240,232,0.85)', label: '#ffab9c' },
  };
  /** Wash strength, outline passes and mark count for rungs 1..3. */
  var RUNG = [
    null,
    { wash: 0.22, passes: 2, marks: 3, jitter: 1.0, width: 1.6 },
    { wash: 0.36, passes: 3, marks: 6, jitter: 1.6, width: 2.0 },
    { wash: 0.52, passes: 5, marks: 10, jitter: 2.6, width: 2.4 },
  ];

  function rungOf(rec) {
    var C = core();
    var r = C ? C.normalise(rec) : rec;
    return r && r.e ? { e: r.e, t: r.t, k: RUNG[r.t], c: INK[r.e] } : null;
  }

  /* ---------------------------------------------------------------- strokes */

  /**
   * A pencil stroke through `pts`: drawn twice (pale halo, then ink), each segment wobbled.
   * `haloPad` is how much wider the halo is than the ink (2.2 px unless a small figure asks for less).
   */
  function pencil(ctx, pts, ink, halo, width, jitter, rand, closed, haloPad) {
    if (pts.length < 2) return;
    for (var pass = 0; pass < 2; pass++) {
      ctx.beginPath();
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      ctx.strokeStyle = pass === 0 ? halo : ink;
      ctx.lineWidth = pass === 0 ? width + (haloPad == null ? 2.2 : haloPad) : width;
      ctx.globalAlpha = pass === 0 ? 0.7 : 0.92;
      var n = pts.length + (closed ? 1 : 0);
      for (var i = 0; i < n; i++) {
        var p = pts[i % pts.length];
        var x = p[0] + (rand() - 0.5) * jitter, y = p[1] + (rand() - 0.5) * jitter;
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }

  /** Points around a rectangle, densified so a jitter reads as a hand, not a polygon. */
  function rectPath(x, y, w, h, inset, step, shape, rand) {
    var pts = [];
    var x0 = x + inset, y0 = y + inset, x1 = x + w - inset, y1 = y + h - inset;
    var edges = [[x0, y0, x1, y0], [x1, y0, x1, y1], [x1, y1, x0, y1], [x0, y1, x0, y0]];
    for (var e = 0; e < 4; e++) {
      var E = edges[e], len = Math.hypot(E[2] - E[0], E[3] - E[1]);
      var n = Math.max(2, Math.round(len / step));
      for (var i = 0; i < n; i++) {
        var u = i / n, px = E[0] + (E[2] - E[0]) * u, py = E[1] + (E[3] - E[1]) * u;
        if (shape === 'jag' && i % 2 === 1) {                 // angry: a zig-zag that bites outward
          var nx = (E[3] - E[1]) / len, ny = -(E[2] - E[0]) / len;
          px -= nx * (2 + rand() * 3); py -= ny * (2 + rand() * 3);
        } else if (shape === 'droop' && (e === 0 || e === 2)) { // sad: the long edges sag
          py += Math.sin(u * Math.PI) * (e === 0 ? 3 : 2);
        } else if (shape === 'loop') {                          // happy: a loose bounce
          var k = Math.sin(u * Math.PI * 3) * 1.6;
          px += (E[3] - E[1]) / len * k; py -= (E[2] - E[0]) / len * k;
        }
        pts.push([px, py]);
      }
    }
    return pts;
  }
  var SHAPE = { happy: 'loop', sad: 'droop', angry: 'jag' };

  /* ---------------------------------------------------------------- marks */

  /** Lay a closed or open path twice: a pale halo, then the ink (and an optional fill between). */
  function inked(ctx, R, width, build, fill, inkColour) {
    for (var pass = 0; pass < 2; pass++) {
      ctx.beginPath(); build();
      if (pass === 1 && fill) { ctx.fillStyle = fill; ctx.globalAlpha = 0.95; ctx.fill(); }
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      ctx.strokeStyle = pass === 0 ? R.c.halo : (inkColour || R.c.ink); ctx.lineWidth = pass === 0 ? width + 2.4 : width;
      ctx.globalAlpha = pass === 0 ? 0.75 : 0.95; ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }
  /** Happy: a four-point star with curved flanks, filled gold, inked, slightly turned. */
  function sparkle(ctx, x, y, s, R, rand) {
    var turn = (rand() - 0.5) * 0.5, inner = s * 0.22;
    inked(ctx, R, R.k.width * 0.9, function () {
      for (var a = 0; a < 4; a++) {
        var ang = turn + a * Math.PI / 2, nxt = ang + Math.PI / 2;
        var px = x + Math.cos(ang) * s, py = y + Math.sin(ang) * s;
        if (a === 0) ctx.moveTo(px, py);
        var mid = ang + Math.PI / 4;
        ctx.quadraticCurveTo(x + Math.cos(mid) * inner, y + Math.sin(mid) * inner, x + Math.cos(nxt) * s, y + Math.sin(nxt) * s);
      }
      ctx.closePath();
    }, R.c.mark);
  }
  function streak(ctx, x, y, len, R, rand) {
    var pts = [], n = 5;
    for (var i = 0; i <= n; i++) pts.push([x + (rand() - 0.5) * 1.5 + i * 0.6, y + len * i / n]);
    pencil(ctx, pts, R.c.ink, R.c.halo, R.k.width * 0.9, R.k.jitter * 0.5, rand);
    ctx.beginPath(); ctx.fillStyle = R.c.mark; ctx.globalAlpha = 0.9;          // the drop at the end
    var ex = pts[n][0], ey = pts[n][1];
    ctx.moveTo(ex, ey - 2); ctx.quadraticCurveTo(ex + 3.2, ey + 3, ex, ey + 4.2); ctx.quadraticCurveTo(ex - 3.2, ey + 3, ex, ey - 2); ctx.fill();
    ctx.globalAlpha = 1;
  }
  /** Angry: the popped-vein mark, four curved strokes each bending away from the centre. */
  function angerCross(ctx, x, y, s, R, rand) {
    var turn = (rand() - 0.5) * 0.4, c = Math.cos(turn), sn = Math.sin(turn);
    function P(u, v) { return [x + (u * c - v * sn) * s, y + (u * sn + v * c) * s]; }
    for (var q = 0; q < 4; q++) {
      var dx = q === 0 || q === 3 ? 1 : -1, dy = q < 2 ? 1 : -1;
      var a = P(dx * 0.14, dy * 0.55), k = P(dx * 0.14, dy * 0.14), b = P(dx * 0.55, dy * 0.14);
      inked(ctx, R, R.k.width * 1.8, function () { ctx.moveTo(a[0], a[1]); ctx.quadraticCurveTo(k[0], k[1], b[0], b[1]); }, null, R.c.mark);
    }
  }
  /** Sad, in the wheel: one tear, filled and inked, point up. */
  function tear(ctx, x, y, s, R) {
    inked(ctx, R, R.k.width, function () {
      ctx.moveTo(x, y - s);
      ctx.bezierCurveTo(x + s * 0.18, y - s * 0.45, x + s * 0.62, y - s * 0.05, x + s * 0.62, y + s * 0.32);
      ctx.arc(x, y + s * 0.32, s * 0.62, 0, Math.PI, false);
      ctx.bezierCurveTo(x - s * 0.62, y - s * 0.05, x - s * 0.18, y - s * 0.45, x, y - s);
      ctx.closePath();
    }, R.c.mark);
  }
  function jagTick(ctx, x, y, s, R, rand) {
    pencil(ctx, [[x, y], [x + s * 0.4, y + s * 0.3], [x + s * 0.15, y + s * 0.55], [x + s * 0.6, y + s]], R.c.ink, R.c.halo, R.k.width, R.k.jitter * 0.4, rand);
  }

  /** How far the point (cx, cy) is from the rectangle [x, y, w, h]; 0 inside it. */
  function rectDist(cx, cy, b) {
    var nx = Math.max(b[0], Math.min(cx, b[0] + b[2])), ny = Math.max(b[1], Math.min(cy, b[1] + b[3]));
    return Math.sqrt((cx - nx) * (cx - nx) + (cy - ny) * (cy - ny));
  }

  /**
   * Scatter the feeling's marks over a box. A cell decides WHERE a mark may go; the mark's own
   * jittered centre and size decide WHAT is drawn (never a mark welded to the grid). A mark is kept
   * only when its WHOLE extent stays off `avoid` (the eyes and mouth of a face, the body of a figure)
   * and it does not sit on a mark already placed: tested on the mark's size, never on its centre.
   */
  function marks(ctx, x, y, w, h, R, rand, avoid, size, cap, spotsOut) {
    var n = cap ? Math.min(cap, R.k.marks) : R.k.marks, placed = 0, tries = 0, spots = spotsOut || [];
    var s = size || Math.max(8, Math.min(w, h) * (R.e === 'angry' ? 0.15 : 0.12));
    while (placed < n && tries < n * 16) {
      tries++;
      var px, py, ms = s * (0.75 + rand() * 0.5);
      if (R.e === 'sad') { px = x + w * (0.08 + rand() * 0.84); py = y + h * (0.02 + rand() * 0.1); }
      else { // the edges of the box, where marks do not sit on a face's eyes; m keeps the whole mark inside
        var side = Math.floor(rand() * 4), u = 0.1 + rand() * 0.8, m = s * (R.e === 'happy' ? 1.1 : 0.8);
        px = side === 0 ? x + w * u : side === 1 ? x + w - m : side === 2 ? x + w * u : x + m;
        py = side === 0 ? y + m : side === 1 ? y + h * u : side === 2 ? y + h - m : y + h * u;
      }
      // how far each mark actually reaches from its centre, halo stroke included: a sparkle's points sit at
      // its full size; a vein's tips at 0.57 of it and a tick's far corner at 0.71; a streak falls from the
      // top band. A mark that would reach the box is drawn SMALLER to fit the room it has, and dropped only
      // below half size. Pinned by pixels, not by this arithmetic: Internal_Ops/_probe/marks_clear.js
      if (avoid && R.e !== 'sad') {
        var fit = (rectDist(px, py, avoid) - (R.k.width * 0.9 + 1.4)) / (R.e === 'happy' ? 1 : 0.72);
        if (fit < s * 0.5) continue;
        if (fit < ms) ms = fit;
      }
      var crowded = false;
      for (var j = 0; j < spots.length; j += 3) {
        var dx = px - spots[j], dy = py - spots[j + 1], keep = (R.e === 'sad' ? 0.45 : 1.1) * (ms + spots[j + 2]) * 0.5;
        if (dx * dx + dy * dy < keep * keep) { crowded = true; break; }
      }
      if (crowded) continue;
      spots.push(px, py, ms);
      if (R.e === 'happy') sparkle(ctx, px, py, ms, R, rand);
      else if (R.e === 'sad') streak(ctx, px, py, Math.min(ms * (1.4 + R.t * 0.5), h * 0.24), R, rand);
      else if (placed % 2 === 0) angerCross(ctx, px, py, ms, R, rand); else jagTick(ctx, px - ms / 2, py - ms / 2, ms, R, rand);
      placed++;
    }
    return placed;
  }

  /* ---------------------------------------------------------------- washes */

  /**
   * How each feeling changes the art under it. Not a tint laid on top: a blend that reads the picture.
   *   happy  SCREEN    the art lifts and warms, as if lit from above (a dark face brightens, never muddies)
   *   sad    COLOR     the art keeps its light and loses its colour, drained toward blue from the top down
   *   angry  MULTIPLY  the art darkens toward red from the edges in, the centre left readable
   */
  var BLEND = { happy: 'screen', sad: 'color', angry: 'multiply' };
  var KEEP = null;   // one scratch canvas, reused: the figure's own alpha, restored after the blend

  /** A wash over a region, coloured by the feeling, stronger at the rung; `clipToAlpha` keeps it on the art. */
  function wash(ctx, x, y, w, h, R, clipToAlpha) {
    var c = R.c.wash, a = R.k.wash, keep = null;
    if (clipToAlpha && ctx.canvas && typeof document !== 'undefined') {
      // CPU-backed like the cell it copies (Sentiment.js reads that cell's pixels): no GPU round trip
      if (!KEEP) { KEEP = document.createElement('canvas'); KEEP.getContext('2d', { willReadFrequently: true }); }
      if (KEEP.width < w || KEEP.height < h) { KEEP.width = Math.max(KEEP.width, w); KEEP.height = Math.max(KEEP.height, h); }
      var kg = KEEP.getContext('2d', { willReadFrequently: true });
      kg.clearRect(0, 0, w, h); kg.drawImage(ctx.canvas, x, y, w, h, 0, 0, w, h);
      keep = KEEP;
    }
    ctx.save();
    // a blend paints the transparent ground too, so a figure gets its own alpha back below
    ctx.globalCompositeOperation = keep || !clipToAlpha ? BLEND[R.e] : 'source-atop';
    var g;
    if (R.e === 'happy') { g = ctx.createRadialGradient(x + w / 2, y + h * 0.3, 2, x + w / 2, y + h * 0.4, Math.max(w, h) * 0.8); g.addColorStop(0, 'rgba(' + c + ',' + Math.min(0.9, a * 1.5) + ')'); g.addColorStop(1, 'rgba(' + c + ',' + (a * 0.55) + ')'); }
    else if (R.e === 'sad') { g = ctx.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, 'rgba(' + c + ',' + Math.min(0.95, a * 2.2) + ')'); g.addColorStop(1, 'rgba(' + c + ',' + Math.min(0.95, a * 1.3) + ')'); }
    else { g = ctx.createRadialGradient(x + w / 2, y + h / 2, Math.min(w, h) * 0.2, x + w / 2, y + h / 2, Math.max(w, h) * 0.75); g.addColorStop(0, 'rgba(' + c + ',' + (a * 0.45) + ')'); g.addColorStop(1, 'rgba(' + c + ',' + Math.min(0.95, a * 1.8) + ')'); }
    ctx.fillStyle = g;
    ctx.fillRect(x, y, w, h);
    if (keep) { ctx.globalCompositeOperation = 'destination-in'; ctx.drawImage(keep, 0, 0, w, h, x, y, w, h); }
    ctx.restore();
  }

  /* ---------------------------------------------------------------- portraits */

  /**
   * Draw a treated PORTRAIT: the face first, then the wash, a scribbled frame and the marks.
   * @param {CanvasRenderingContext2D} ctx destination, drawn at (dx, dy)
   * @param {CanvasImageSource} src the face sheet (or any image)
   * @param {number} sx source x  @param {number} sy source y  @param {number} w  @param {number} h
   * @param {number} dx  @param {number} dy
   * @param {{e,t}} rec the feeling
   * @param {number} seed a stable seed for this face (the same face scribbles the same way)
   * @returns {{marks:number, strokes:number}|null} null when calm (the face is drawn untouched)
   */
  function treatFace(ctx, src, sx, sy, w, h, dx, dy, rec, seed) {
    ctx.drawImage(src, sx, sy, w, h, dx, dy, w, h);
    var R = rungOf(rec);
    if (!R) return null;
    var rand = core().rng(seed + R.t * 7919 + R.e.length);
    ctx.save();
    ctx.beginPath(); ctx.rect(dx, dy, w, h); ctx.clip();
    wash(ctx, dx, dy, w, h, R, false);
    var strokes = 0;
    for (var p = 0; p < R.k.passes; p++) {
      pencil(ctx, rectPath(dx, dy, w, h, 3 + p * 1.2, 9, SHAPE[R.e], rand), R.c.ink, R.c.halo, R.k.width, R.k.jitter + p * 0.5, rand, true);
      strokes++;
    }
    // the eyes and mouth of a standard MZ face sit inside this box; no mark's extent may enter it
    var placed = marks(ctx, dx + 4, dy + 4, w - 8, h - 8, R, rand, R.e === 'sad' ? null : [dx + w * 0.24, dy + h * 0.26, w * 0.52, h * 0.56]);
    ctx.restore();
    return { marks: placed, strokes: strokes };
  }

  /* ---------------------------------------------------------------- figures */

  /**
   * The outline of a figure from its alpha: boundary pixels, ordered by angle around the
   * figure's centre and thinned to a step, so a pencil can follow it. Works on any transparent
   * battler or enemy image.
   * @param {ImageData} img
   * @returns {{pts:Array, cx:number, cy:number, box:Array}|null}
   */
  function silhouette(img, step) {
    var W = img.width, H = img.height, d = img.data, edge = [], sx = 0, sy = 0, n = 0;
    var minX = W, minY = H, maxX = 0, maxY = 0;
    function A(x, y) { return x < 0 || y < 0 || x >= W || y >= H ? 0 : d[(y * W + x) * 4 + 3]; }
    for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) {
      if (A(x, y) < 96) continue;
      sx += x; sy += y; n++;
      if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y;
      if (A(x - 1, y) < 96 || A(x + 1, y) < 96 || A(x, y - 1) < 96 || A(x, y + 1) < 96) edge.push([x, y]);
    }
    if (n < 16 || edge.length < 8) return null;
    var cx = sx / n, cy = sy / n;
    // the OUTER boundary only: per angle bucket keep the farthest edge pixel
    var buckets = Math.max(24, Math.min(160, Math.round(edge.length / (step || 3))));
    var far = new Array(buckets);
    for (var i = 0; i < edge.length; i++) {
      var ex = edge[i][0] - cx, ey = edge[i][1] - cy;
      var b = Math.floor(((Math.atan2(ey, ex) + Math.PI) / (Math.PI * 2)) * buckets) % buckets;
      var r2 = ex * ex + ey * ey;
      if (!far[b] || r2 > far[b][2]) far[b] = [edge[i][0], edge[i][1], r2];
    }
    var pts = [];
    for (var k = 0; k < buckets; k++) if (far[k]) pts.push([far[k][0], far[k][1]]);
    return { pts: pts, cx: cx, cy: cy, box: [minX, minY, maxX - minX + 1, maxY - minY + 1] };
  }

  /**
   * Draw a treated FIGURE (an enemy image or one side-view battler cell) into `ctx`, which must
   * already hold the figure at (0,0) on a transparent canvas of the figure's size: the wash
   * stays on the figure (source-atop), the outline scribbles just outside it, the marks sit above.
   * @returns {{marks:number, strokes:number, outline:number}|null}
   */
  function treatFigure(ctx, w, h, rec, seed, pad) {
    var R = rungOf(rec);
    if (!R) return null;
    if (!(w >= 1 && h >= 1)) return { marks: 0, strokes: 0, outline: 0 };
    var rand = core().rng(seed + R.t * 104729 + R.e.length);
    var sil = silhouette(ctx.getImageData(0, 0, w, h), 3);
    wash(ctx, 0, 0, w, h, R, true);
    if (!sil) return { marks: 0, strokes: 0, outline: 0 };
    // The pen, the reach of each pass and the wobble are sized to the FIGURE. At full size on a ~48 px side-view
    // figure in a 64 px cell, five passes reaching ~8 px out, each with a 4.6 px halo, filled the cell to its edge
    // and clamped flat against it, so the actor read as a boxed sticker, not a figure (found by LOOKING at a stock
    // side-view battle, 2026-10-07; enemies of 96 px and up are unchanged). Pinned: _probe/figure_fit.js.
    var fit = Math.max(0.4, Math.min(1, Math.min(sil.box[2], sil.box[3]) / 96));
    var strokes = 0;
    for (var p = 0; p < R.k.passes; p++) {
      var grow = (1.5 + p * 1.1) * fit, pts = [];
      for (var i = 0; i < sil.pts.length; i++) {
        var q = sil.pts[i], vx = q[0] - sil.cx, vy = q[1] - sil.cy, L = Math.hypot(vx, vy) || 1;
        var off = grow + (SHAPE[R.e] === 'jag' && i % 2 ? 2.5 * fit : 0) + (SHAPE[R.e] === 'droop' && vy > 0 ? 1.2 * fit : 0);
        pts.push([Math.max(1.5, Math.min(w - 1.5, q[0] + vx / L * off)), Math.max(1.5, Math.min(h - 1.5, q[1] + vy / L * off))]);
      }
      pencil(ctx, pts, R.c.ink, R.c.halo, R.k.width * (0.5 + 0.5 * fit), R.k.jitter * fit, rand, true, 2.2 * fit);
      strokes++;
    }
    var b = sil.box, top = Math.max(0, b[1] - (pad || 0)), small = b[3] < 72;
    var ms = small ? 6 : Math.max(10, Math.min(28, Math.min(b[2], b[3]) * 0.16));
    var placed = marks(ctx, Math.max(0, b[0] - 6), top, Math.min(w, b[2] + 12), Math.max(24, b[3] * 0.45), R, rand,
      R.e === 'sad' ? null : [b[0] + b[2] * 0.2, b[1] + b[3] * 0.25, b[2] * 0.6, b[3] * 0.75], ms, small ? R.t : 0);
    return { marks: placed, strokes: strokes, outline: sil.pts.length, fit: fit };
  }

  /* ---------------------------------------------------------------- the wheel */

  var WHEEL_HUE = { happy: '#f2b630', angry: '#df4430', sad: '#4c7fd6' };
  var CARD = '#f4ead6', RIM = '#3a2410';
  var LIT_GLYPH = { ink: RIM, mark: '#fff8e6', halo: 'rgba(58,36,16,0.45)' };
  /**
   * The emotion wheel: three segments in advantage order with the arrows that say who beats whom,
   * the current feeling's segment lit and its rung marked by pips. Drawn as cut card with an ink
   * rim, never as a window. Every arrow sits ON the card's own ring, so it reads on any ground
   * (a dark battle portrait or a light menu) — ink chosen for the surface it lands on (wing §17c-1).
   * From radius 20 up, each segment also carries its feeling's own mark, drawn by the same kit.
   * @returns {number} how many segments were drawn (always 3) — for tests
   */
  function drawWheel(ctx, cx, cy, r, rec) {
    var C = core(), R = C.normalise(rec), order = C.ORDER, ring = r * 1.24 + 1, TAU = Math.PI * 2;
    ctx.save();
    // card disc with a drop shadow; the ring between the segments and the rim carries the arrows
    var sh = Math.max(0.8, r * 0.09);
    ctx.beginPath(); ctx.arc(cx + sh, cy + sh * 1.3, ring, 0, TAU); ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fill();
    ctx.beginPath(); ctx.arc(cx, cy, ring, 0, TAU); ctx.fillStyle = CARD; ctx.fill();
    for (var i = 0; i < 3; i++) {
      var e = order[i], a0 = -Math.PI / 2 + i * (TAU / 3) + 0.07, a1 = a0 + TAU / 3 - 0.14;
      var lit = R.e === e;
      ctx.beginPath(); ctx.moveTo(cx, cy); ctx.arc(cx, cy, r * (lit ? 1 : 0.88), a0, a1); ctx.closePath();
      ctx.fillStyle = WHEEL_HUE[e]; ctx.globalAlpha = lit ? 1 : 0.4; ctx.fill(); ctx.globalAlpha = 1;
      if (lit) { ctx.lineWidth = Math.max(1, r * 0.04); ctx.strokeStyle = RIM; ctx.stroke(); }
      if (r >= 20) {                               // the feeling's own mark in its own segment
        var am0 = (a0 + a1) / 2, gx = cx + Math.cos(am0) * r * 0.56, gy = cy + Math.sin(am0) * r * 0.56;
        // a lit segment is filled with the feeling's own hue, which is ALSO its mark colour: there the glyph is cut
        // in cream with the rim's ink, or it vanishes into the segment (wing §17c-1: ink chosen for its ground)
        var G = { e: e, t: 1, c: lit ? LIT_GLYPH : INK[e], k: { width: Math.max(1.2, r * 0.045), jitter: 0, marks: 1, wash: 0, passes: 0 } };
        var gr = core().rng(31 + i);
        ctx.globalAlpha = lit ? 1 : 0.55;
        if (e === 'happy') sparkle(ctx, gx, gy, r * 0.24, G, gr);
        else if (e === 'angry') angerCross(ctx, gx, gy, r * 0.34, G, gr);
        else tear(ctx, gx, gy, r * 0.22, G);
        ctx.globalAlpha = 1;
      }
      if (lit) {                                   // rung pips along the lit segment, inside its rim
        for (var p = 0; p < R.t; p++) {
          var am = a0 + (a1 - a0) * (p + 1) / (R.t + 1);
          ctx.beginPath(); ctx.arc(cx + Math.cos(am) * r * 0.84, cy + Math.sin(am) * r * 0.84, Math.max(1.6, r * 0.075), 0, TAU);
          ctx.fillStyle = '#fff8e6'; ctx.fill(); ctx.lineWidth = Math.max(0.8, r * 0.025); ctx.strokeStyle = RIM; ctx.stroke();
        }
      }
      // the "beats" arrow: on the card ring, from the end of this segment pointing on round to the next one
      var mid = a1 + 0.07, rr = (r + ring) / 2, L = Math.max(2.6, (ring - r) * 0.95), half = L * 0.6;
      var tx = -Math.sin(mid), ty = Math.cos(mid), nx = Math.cos(mid), ny = Math.sin(mid);   // tangent (clockwise), normal
      var bx = cx + nx * rr - tx * L * 0.5, by = cy + ny * rr - ty * L * 0.5;
      ctx.beginPath();
      ctx.moveTo(bx + tx * L, by + ty * L);
      ctx.lineTo(bx + nx * half, by + ny * half);
      ctx.lineTo(bx - nx * half, by - ny * half);
      ctx.closePath(); ctx.fillStyle = RIM; ctx.fill();
    }
    ctx.beginPath(); ctx.arc(cx, cy, ring, 0, TAU); ctx.lineWidth = Math.max(1.2, r * 0.06); ctx.strokeStyle = RIM; ctx.stroke();
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.16, 0, TAU); ctx.fillStyle = RIM; ctx.fill();
    ctx.restore();
    return 3;
  }

  var API = { INK: INK, RUNG: RUNG, treatFace: treatFace, treatFigure: treatFigure, silhouette: silhouette, drawWheel: drawWheel, marks: marks, version: '1.0.0' };
  root.CSAF = root.CSAF || {};
  root.CSAF.SentimentArt = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof window !== 'undefined' ? window : globalThis);
