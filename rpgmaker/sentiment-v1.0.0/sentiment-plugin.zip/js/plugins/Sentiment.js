//=============================================================================
// Sentiment.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Sentiment [3/3] — emotion battles you can SEE: happy, sad and angry drawn over every portrait and enemy, three rungs deep. v1.0.0
 * @author CSAF — Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * Sentiment — happy, sad and angry, drawn on every portrait
 * ============================================================================
 * Load this LAST, after SentimentCore and SentimentArt.
 *
 * WHAT IT DOES
 * Every battler can feel HAPPY, SAD or ANGRY, at three rungs each:
 *   Happy > Ecstatic > Manic      quicker and luckier, guards worse
 *   Sad > Depressed > Miserable   guards better, slower
 *   Angry > Enraged > Furious     hits harder, guards worse
 * The feelings are a rock-paper-scissors: HAPPY beats ANGRY, ANGRY beats SAD,
 * SAD beats HAPPY. An attacker whose feeling beats its target's deals more
 * damage; one whose feeling loses deals less.
 *
 * And every feeling is DRAWN. Your own face art is never replaced: the face is
 * drawn first and the feeling is drawn over it, the way an artist marks up a
 * sheet: a wash in the feeling's colour, a hand-scribbled outline, and the
 * feeling's marks (sparkles, falling streaks, popped veins), heavier on every
 * rung. Enemies get the same treatment around their own silhouette. A small
 * emotion wheel and the rung's name sit on each portrait in battle.
 *
 * INSTALL
 * Copy the three .js files into js/plugins and enable them in this order:
 * SentimentCore, SentimentArt, Sentiment.
 *
 * NOTETAGS
 *  Skills and items (what a hit does to the target's feeling):
 *   <Sentiment: happy>          one rung more of happy (or happy at rung 1
 *                               if the target felt something else)
 *   <Sentiment: sad 2>          straight to rung 2 of sad
 *   <Sentiment: calm>           clears the feeling
 *   <Sentiment target: user>    beside a feeling tag: the feeling lands on
 *                               the user instead, once per action
 *  Actors and enemies:
 *   <Sentiment max: 2>          the highest rung this battler can reach
 *   <Sentiment start: angry 1>  how it enters a battle it starts calm
 *
 * PLUGIN COMMANDS
 *   Set Feeling     an actor (or the whole party) to a feeling and rung
 *   Calm Feeling    clears an actor (or the whole party)
 *
 * SCRIPT
 *   CSAF.Sentiment.get(battler)          { e: 'happy'|'sad'|'angry'|null, t: 0..3 }
 *   CSAF.Sentiment.set(battler, e, t)    set it (t omitted = one rung more)
 *   CSAF.Sentiment.rungName(battler)     'Ecstatic', or '' when calm
 *
 * COMPATIBILITY
 * Extends twelve core methods, every one by saving the original and CALLING it.
 * Nothing is replaced and nothing is overwritten:
 *   Game_BattlerBase.prototype.initMembers     the feeling record
 *   Game_BattlerBase.prototype.paramRate       each rung's stat changes
 *   Game_Battler.prototype.onBattleStart       <Sentiment start>
 *   Game_Battler.prototype.onBattleEnd         clears feelings (parameter)
 *   Game_Action.prototype.makeDamageValue      the wheel's advantage
 *   Game_Action.prototype.applyItemUserEffect  skill and item notetags
 *   Window_StatusBase.prototype.drawActorFace  the drawn-over portrait
 *   Window_BattleStatus.prototype.drawItemImage the wheel and rung name
 *   Window_BattleLog.prototype.displayAffectedStatus "X feels ECSTATIC!"
 *   Sprite_Enemy.prototype.updateBitmap        the drawn-over enemy
 *   Sprite_Actor.prototype.updateBitmap        the drawn-over side-view actor
 *   Scene_Battle.prototype.terminate           frees pictures retired mid-battle
 * Treated pictures are drawn ONCE per face and rung and cached; nothing is
 * drawn per frame.
 * ============================================================================
 *
 * @param advantageRate
 * @text Damage when the feeling wins
 * @desc Damage multiplier when the attacker's feeling beats the target's.
 * @type number
 * @decimals 2
 * @min 0
 * @default 1.50
 *
 * @param disadvantageRate
 * @text Damage when the feeling loses
 * @desc Damage multiplier when the attacker's feeling loses to the target's.
 * @type number
 * @decimals 2
 * @min 0
 * @default 0.50
 *
 * @param clearAfterBattle
 * @text Calm after battle
 * @desc Clear every feeling when a battle ends.
 * @type boolean
 * @default true
 *
 * @param treatEnemies
 * @text Draw over enemies
 * @desc Draw the feeling over enemy images too (front view and side view).
 * @type boolean
 * @default true
 *
 * @param treatActors
 * @text Draw over side-view actors
 * @desc Draw the feeling over the party's side-view battler sheets too.
 * @type boolean
 * @default true
 *
 * @param showBadge
 * @text Wheel on battle portraits
 * @desc Draw the emotion wheel and the rung's name on each battle portrait.
 * @type boolean
 * @default true
 *
 * @param message
 * @text Battle log line
 * @desc Shown when a feeling changes. %1 = the battler, %2 = the rung (MANIC). Blank shows nothing.
 * @type string
 * @default %1 feels %2!
 *
 * @command set
 * @text Set Feeling
 * @desc Give an actor, or the whole party, a feeling.
 *
 * @arg actorId
 * @text Actor
 * @desc 0 = every party member.
 * @type actor
 * @default 0
 *
 * @arg emotion
 * @text Feeling
 * @type select
 * @option happy
 * @option sad
 * @option angry
 * @default happy
 *
 * @arg tier
 * @text Rung
 * @desc 1 to 3. 0 = one rung more than now.
 * @type number
 * @min 0
 * @max 3
 * @default 1
 *
 * @command calm
 * @text Calm Feeling
 * @desc Clear an actor's feeling, or the whole party's.
 *
 * @arg actorId
 * @text Actor
 * @desc 0 = every party member.
 * @type actor
 * @default 0
 */
/* eslint-disable no-var */
(function (root) {
  'use strict';

  var PLUGIN = 'Sentiment';
  var raw = (typeof PluginManager !== 'undefined' && PluginManager.parameters(PLUGIN)) || {};
  // ⛔ parameters arrive as STRINGS and Number('') is 0: a blank is absent, never zero (wing §16)
  function num(v, d) { var s = String(v == null ? '' : v).trim(); if (s === '') return d; var n = Number(s); return isFinite(n) && n >= 0 ? n : d; }
  function bool(v, d) { var s = String(v == null ? '' : v).trim(); return s === '' ? d : s === 'true'; }
  var P = {
    advantage: num(raw.advantageRate, 1.5),
    disadvantage: num(raw.disadvantageRate, 0.5),
    clearAfterBattle: bool(raw.clearAfterBattle, true),
    treatEnemies: bool(raw.treatEnemies, true),
    treatActors: bool(raw.treatActors, true),
    showBadge: bool(raw.showBadge, true),
    message: raw.message == null ? '%1 feels %2!' : String(raw.message),
  };

  /* ⛔ load order is the buyer's choice: resolve siblings at FIRST USE, never at load (wing §8 trap 2) */
  // A missing sibling must never crash a battle: Sentiment then plays every battler calm and says so ONCE.
  var DEPS = null, warned = false;
  var deps = function () {
    if (DEPS) return DEPS;
    var C = root.CSAF && root.CSAF.SentimentCore, A = root.CSAF && root.CSAF.SentimentArt;
    if (C && A) { DEPS = { C: C, A: A }; return DEPS; }
    if (!warned && typeof console !== 'undefined') { warned = true; console.warn('Sentiment: enable SentimentCore and SentimentArt in the Plugin Manager too. Until then every battler plays calm.'); }
    return null;
  };

  /* ---------------------------------------------------------------- the record */

  function capOf(battler) {
    var data = battler.isActor && battler.isActor() ? battler.actor() : battler.enemy && battler.enemy();
    return deps().C.readCap(data && data.note);
  }
  function get(battler) {
    if (!battler || !deps()) return { e: null, t: 0 };
    return deps().C.normalise(battler._csafSentiment, capOf(battler));
  }
  /**
   * Set a battler's feeling. Returns true when the visible rung changed.
   * @param {Game_Battler} battler
   * @param {string} emotion 'happy' | 'sad' | 'angry' | 'calm'
   * @param {number} [tier] 1..3; omitted or 0 = one rung more
   */
  function set(battler, emotion, tier) {
    if (!battler || !deps()) return false;
    var before = get(battler);
    var next = deps().C.push(before, emotion, tier, capOf(battler));
    battler._csafSentiment = { v: 1, e: next.e, t: next.t };
    var changed = before.e !== next.e || before.t !== next.t;
    if (changed && typeof $gameTemp !== 'undefined' && $gameTemp && $gameTemp.requestBattleRefresh) $gameTemp.requestBattleRefresh();
    return changed;
  }
  function rungName(battler) { return deps() ? deps().C.rungName(get(battler)) : ''; }

  var _initMembers = Game_BattlerBase.prototype.initMembers;
  Game_BattlerBase.prototype.initMembers = function () {
    _initMembers.call(this);
    this._csafSentiment = { v: 1, e: null, t: 0 };
  };

  var _paramRate = Game_BattlerBase.prototype.paramRate;
  Game_BattlerBase.prototype.paramRate = function (paramId) {
    var base = _paramRate.call(this, paramId);
    var r = this._csafSentiment;                      // stored normalised by set(); read without allocating
    if (!r || !r.e || !deps()) return base;
    return base * deps().C.paramRate(r, paramId);
  };

  var _onBattleStart = Game_Battler.prototype.onBattleStart;
  Game_Battler.prototype.onBattleStart = function (advantageous) {
    _onBattleStart.call(this, advantageous);
    if (!deps()) return;
    var data = this.isActor() ? this.actor() : this.enemy();
    this._csafSentimentNews = false;
    var start = deps().C.readStart(data && data.note);
    if (start && !get(this).e) set(this, start.e, start.t);
  };

  var _onBattleEnd = Game_Battler.prototype.onBattleEnd;
  Game_Battler.prototype.onBattleEnd = function () {
    _onBattleEnd.call(this);
    if (P.clearAfterBattle) this._csafSentiment = { v: 1, e: null, t: 0 };
  };

  /* ---------------------------------------------------------------- the wheel in damage */

  var _makeDamageValue = Game_Action.prototype.makeDamageValue;
  Game_Action.prototype.makeDamageValue = function (target, critical) {
    var value = _makeDamageValue.call(this, target, critical);
    if (!value || !deps() || !(this.isDamage() || this.isDrain())) return value;
    var rate = deps().C.damageRate(get(this.subject()), get(target), { advantage: P.advantage, disadvantage: P.disadvantage });
    return rate === 1 ? value : Math.round(value * rate);
  };

  var _applyItemUserEffect = Game_Action.prototype.applyItemUserEffect;
  Game_Action.prototype.applyItemUserEffect = function (target) {
    _applyItemUserEffect.call(this, target);
    var item = this.item();
    var tag = item && deps() && deps().C.readTag(item.note);
    if (!tag) return;
    if (tag.toUser) { if (this._csafSentimentToUser) return; this._csafSentimentToUser = true; }
    var who = tag.toUser ? this.subject() : target;
    if (set(who, tag.emotion, tag.tier)) who._csafSentimentNews = true;
  };

  // displayAffectedStatus runs inside displayActionResults, between the damage line and the engine trimming
  // the target's lines (rmmz_windows.js:5731 calls displayAffectedStatus at :5738), so the feeling sits WITH the hit instead of replacing it
  var _displayAffectedStatus = Window_BattleLog.prototype.displayAffectedStatus;
  Window_BattleLog.prototype.displayAffectedStatus = function (target) {
    _displayAffectedStatus.call(this, target);
    var subject = typeof BattleManager !== 'undefined' ? BattleManager._subject : null;
    for (var i = 0; i < 2; i++) {
      var b = i === 0 ? target : subject;
      if (!b || !b._csafSentimentNews) continue;
      b._csafSentimentNews = false;
      var word = rungName(b) || 'calm';
      if (P.message) this.push('addText', P.message.replace('%1', b.name()).replace('%2', word.toUpperCase()));
    }
  };

  /* ---------------------------------------------------------------- pictures, baked once */

  var cache = {}, used = {}, size = 0, tick = 0, retired = [], CACHE_MAX = 96;
  function hit(key) { used[key] = ++tick; return cache[key]; }
  function remember(key, bitmap) {
    cache[key] = bitmap; used[key] = ++tick; size++;
    while (size > CACHE_MAX) {
      var old = null, low = Infinity;
      for (var k in used) if (used[k] < low) { low = used[k]; old = k; }
      var b = cache[old];
      delete cache[old]; delete used[old]; size--;
      if (!b || !b.destroy) continue;
      if (old.charAt(0) === 'b') retired.push(b); else b.destroy();
    }
    return bitmap;
  }
  var _battleTerminate = Scene_Battle.prototype.terminate;
  Scene_Battle.prototype.terminate = function () {
    _battleTerminate.call(this);
    while (retired.length) retired.pop().destroy();     // the sprites that showed them are gone with the scene
  };
  function sourceOf(bitmap) { return bitmap._canvas || bitmap._image; }

  /** A 1-cell Bitmap holding face `index` of `faceName`, drawn over for `rec`. Null until the face sheet loads. */
  function faceBitmap(faceName, faceIndex, rec) {
    if (!faceName) return null;                        // no face to draw over: draw nothing (review 24)
    var key = 'f|' + faceName + '|' + faceIndex + '|' + rec.e + rec.t;
    if (cache[key]) return hit(key);
    var sheet = ImageManager.loadFace(faceName);
    if (!sheet.isReady()) return null;
    var pw = ImageManager.faceWidth, ph = ImageManager.faceHeight;
    var bmp = new Bitmap(pw, ph);
    var D = deps();
    D.A.treatFace(bmp.context, sourceOf(sheet), (faceIndex % 4) * pw, Math.floor(faceIndex / 4) * ph, pw, ph, 0, 0, rec, D.C.hash(faceName + '#' + faceIndex));
    bmp._baseTexture.update();
    return remember(key, bmp);
  }

  /** A treated copy of a whole battler image (an enemy, or a 9x6 side-view sheet cell by cell). */
  function figureBitmap(base, name, rec, cols, rows) {
    var key = 'b|' + name + '|' + cols + 'x' + rows + '|' + rec.e + rec.t;
    if (cache[key]) return hit(key);
    var W = base.width, H = base.height, cw = Math.floor(W / cols), ch = Math.floor(H / rows);
    if (cw < 2 || ch < 2 || !sourceOf(base)) return base;
    var bmp = new Bitmap(W, H), D = deps();
    var cell = document.createElement('canvas'); cell.width = cw; cell.height = ch;
    // the silhouette READS this cell's pixels: keep it on the CPU so a bake never waits on the GPU (wing §27a)
    var cg = cell.getContext('2d', { willReadFrequently: true });
    for (var r = 0; r < rows; r++) for (var c = 0; c < cols; c++) {
      cg.clearRect(0, 0, cw, ch);
      cg.drawImage(sourceOf(base), c * cw, r * ch, cw, ch, 0, 0, cw, ch);
      D.A.treatFigure(cg, cw, ch, rec, D.C.hash(name + '#' + (cols > 1 ? 0 : c)), 8);
      bmp.context.drawImage(cell, c * cw, r * ch);
    }
    cell.width = 0; cell.height = 0;
    bmp._baseTexture.update();
    return remember(key, bmp);
  }

  var MEASURE = null;
  /** The wheel and the rung's name, as one small baked plate. */
  function badgeBitmap(rec) {
    var key = 'w|' + rec.e + rec.t;
    if (cache[key]) return hit(key);
    var D = deps(), word = D.C.rungName(rec).toUpperCase(), font = '700 13px Georgia, "Times New Roman", serif';
    if (!MEASURE) MEASURE = document.createElement('canvas').getContext('2d');   // one context, ever
    MEASURE.font = font;
    var w = Math.ceil(MEASURE.measureText(word).width) + 12;
    var bmp = new Bitmap(30 + w + 8, 30), g = bmp.context;
    D.A.drawWheel(g, 15, 15, 10.6, rec);           // the card ring reaches r * 1.24 + 1 = 14.1: inside the 30 px plate
    g.font = font;
    g.fillStyle = 'rgba(24,15,8,0.96)'; g.beginPath(); g.moveTo(30, 8); g.lineTo(30 + w, 8); g.lineTo(30 + w + 5, 15); g.lineTo(30 + w, 22); g.lineTo(30, 22); g.closePath(); g.fill();
    g.fillStyle = D.A.INK[rec.e].label; g.textBaseline = 'middle'; g.fillText(word, 36, 15.5);
    bmp._baseTexture.update();
    return remember(key, bmp);
  }

  var _drawActorFace = Window_StatusBase.prototype.drawActorFace;
  Window_StatusBase.prototype.drawActorFace = function (actor, x, y, width, height) {
    _drawActorFace.call(this, actor, x, y, width, height);
    var rec = get(actor);
    var bmp = rec.e ? faceBitmap(actor.faceName(), actor.faceIndex(), rec) : null;
    if (!bmp) return;
    // the same arithmetic as Window_Base.prototype.drawFace (rmmz_windows.js:462), on a 1-cell source
    width = width || ImageManager.standardFaceWidth;
    height = height || ImageManager.standardFaceHeight;
    var pw = ImageManager.faceWidth, ph = ImageManager.faceHeight;
    var sw = Math.min(width, pw), sh = Math.min(height, ph);
    var dx = Math.floor(x + Math.max(width - pw, 0) / 2), dy = Math.floor(y + Math.max(height - ph, 0) / 2);
    this.contents.blt(bmp, Math.floor((pw - sw) / 2), Math.floor((ph - sh) / 2), sw, sh, dx, dy);
  };

  var _drawItemImage = Window_BattleStatus.prototype.drawItemImage;
  Window_BattleStatus.prototype.drawItemImage = function (index) {
    _drawItemImage.call(this, index);
    if (!P.showBadge) return;
    var actor = this.actor(index), rec = get(actor);
    if (!rec.e) return;
    var rect = this.faceRect(index), b = badgeBitmap(rec);
    this.contents.blt(b, 0, 0, b.width, b.height, rect.x + 2, rect.y + 2);
  };

  var _enemyUpdateBitmap = Sprite_Enemy.prototype.updateBitmap;
  Sprite_Enemy.prototype.updateBitmap = function () {
    _enemyUpdateBitmap.call(this);
    if (!P.treatEnemies || !this._enemy || !DEPS && !deps()) return;
    // ⛔ this runs EVERY FRAME: no allocation and no notetag parse here (wing §3). set() stores a normalised
    // record, so its raw fields are compared directly. The BASE is whatever the call chain put on the sprite
    // (the engine's load, or another plugin's picture); only our own treated copy is not a base.
    if (this.bitmap !== this._csafSentOut) this._csafSentBase = this.bitmap;
    var r = this._enemy._csafSentiment, e = r ? r.e : null, t = r ? r.t : 0, base = this._csafSentBase;
    if (e === this._csafSentE && t === this._csafSentT && base === this._csafSentFor) return;
    if (this._csafSentFor === undefined && !e) { this._csafSentE = e; this._csafSentT = t; this._csafSentFor = base; return; }
    if (!base || !base.isReady()) return;              // try again next frame; nothing is drawn until it loads
    this._csafSentE = e; this._csafSentT = t; this._csafSentFor = base;
    this._csafSentOut = e ? figureBitmap(base, base._url || this._enemy.battlerName(), get(this._enemy), 1, 1) : base;
    this.bitmap = this._csafSentOut;
  };

  // side view: the actor's 9x6 sheet, treated cell by cell (rmmz_sprites.js:800 sets _mainSprite.bitmap)
  var _actorUpdateBitmap = Sprite_Actor.prototype.updateBitmap;
  Sprite_Actor.prototype.updateBitmap = function () {
    _actorUpdateBitmap.call(this);
    if (!P.treatActors || !this._actor || !this._mainSprite || !DEPS && !deps()) return;
    var ms = this._mainSprite;
    if (ms.bitmap !== this._csafSentOut) this._csafSentBase = ms.bitmap;   // the chain's picture, never our copy
    var r = this._actor._csafSentiment, e = r ? r.e : null, t = r ? r.t : 0, base = this._csafSentBase;
    if (e === this._csafSentE && t === this._csafSentT && base === this._csafSentFor) return;   // every frame: no allocation
    if (this._csafSentFor === undefined && !e) { this._csafSentE = e; this._csafSentT = t; this._csafSentFor = base; return; }
    if (!base || !base.isReady()) return;
    this._csafSentE = e; this._csafSentT = t; this._csafSentFor = base;
    this._csafSentOut = e ? figureBitmap(base, base._url || this._battlerName, get(this._actor), 9, 6) : base;
    ms.bitmap = this._csafSentOut;
  };

  /* ---------------------------------------------------------------- commands and script */

  function partyTargets(actorId) {
    var id = Number(actorId);
    if (id > 0) return [$gameActors.actor(id)];
    return $gameParty.members();
  }
  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
    PluginManager.registerCommand(PLUGIN, 'set', function (args) {
      var list = partyTargets(args.actorId);
      for (var i = 0; i < list.length; i++) set(list[i], String(args.emotion || 'happy'), Number(args.tier) || 0);
    });
    PluginManager.registerCommand(PLUGIN, 'calm', function (args) {
      var list = partyTargets(args.actorId);
      for (var i = 0; i < list.length; i++) set(list[i], 'calm');
    });
  }

  root.CSAF = root.CSAF || {};
  root.CSAF.Sentiment = { get: get, set: set, rungName: rungName, params: P, _cache: cache, _faceBitmap: faceBitmap, _figureBitmap: figureBitmap, _badgeBitmap: badgeBitmap, version: '1.0.0' };
})(typeof window !== 'undefined' ? window : globalThis);
