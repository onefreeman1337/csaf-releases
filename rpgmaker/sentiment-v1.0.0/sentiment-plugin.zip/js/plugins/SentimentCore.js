//=============================================================================
// SentimentCore.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Sentiment [1/3] — the emotion rules. Load first. No engine code. v1.0.0
 * @author CSAF — Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The rules half of Sentiment: which emotion beats which, how far each one
 * can climb, and what every rung does to a battler's numbers. It knows
 * nothing about RPG Maker, so it can be read, tested and reasoned about on
 * its own. Sentiment.js is the only file that touches the engine.
 *
 * Load order: SentimentCore, SentimentArt, Sentiment.
 */
/* eslint-disable no-var */
(function (root) {
  'use strict';

  /**
   * The three emotions and their rungs. Rung names are the words a player reads; `hue` feeds the
   * drawing kit; the wheel order is the advantage cycle (each beats the NEXT one).
   *   HAPPY beats ANGRY, ANGRY beats SAD, SAD beats HAPPY.
   */
  var EMOTIONS = {
    happy: { id: 'happy', rungs: ['Happy', 'Ecstatic', 'Manic'], beats: 'angry' },
    sad: { id: 'sad', rungs: ['Sad', 'Depressed', 'Miserable'], beats: 'happy' },
    angry: { id: 'angry', rungs: ['Angry', 'Enraged', 'Furious'], beats: 'sad' },
  };
  var ORDER = ['happy', 'angry', 'sad'];
  var MAX_TIER = 3;

  /**
   * What each rung does to the eight base parameters (mhp, mmp, atk, def, mat, mdf, agi, luk),
   * as a multiplier per tier: the effect at tier t is 1 + t * step. A buyer can replace the whole
   * table in the plugin parameters. Defaults follow the genre's reading of each feeling:
   *   happy  quicker and luckier, careless (agi up, luk up, def down)
   *   sad    guarded and slow (def and mdf up, agi down)
   *   angry  hits harder, guards worse (atk and mat up, def down)
   */
  var PARAM_STEPS = {
    happy: [0, 0, 0, -0.10, 0, 0, 0.25, 0.50],
    sad: [0, 0, 0, 0.25, 0, 0.25, -0.15, 0],
    angry: [0, 0, 0.25, -0.15, 0.20, -0.10, 0, 0],
  };

  /** Damage from an attacker whose emotion BEATS the target's, and from one it LOSES to. */
  var DEFAULT_RATES = { advantage: 1.5, disadvantage: 0.5 };

  function isEmotion(e) { return e === 'happy' || e === 'sad' || e === 'angry'; }

  /**
   * A normalised sentiment record: { e: 'happy'|'sad'|'angry'|null, t: 0..cap }. Anything else
   * (a stale save, a typo in a notetag, NaN) reads as calm, never as a half-state.
   * @param {*} rec
   * @param {number} [cap]
   * @returns {{e: (string|null), t: number}}
   */
  function normalise(rec, cap) {
    var c = clampCap(cap);
    if (!rec || !isEmotion(rec.e)) return { e: null, t: 0 };
    var t = Math.floor(Number(rec.t));
    if (!(t >= 1)) return { e: null, t: 0 };
    return { e: rec.e, t: Math.min(t, c) };
  }
  function clampCap(cap) {
    var c = Math.floor(Number(cap));
    if (!(c >= 1)) return MAX_TIER;
    return Math.min(c, MAX_TIER);
  }

  /**
   * Apply one push of an emotion, the way a skill, item or command does.
   *   same emotion        climbs one rung (or to `tier` if one is named), never past the cap
   *   another emotion     replaces the feeling at rung 1 (or at `tier`)
   *   'calm'              clears it
   * @param {{e:(string|null),t:number}} rec current record
   * @param {string} emotion 'happy' | 'sad' | 'angry' | 'calm'
   * @param {number} [tier] an explicit rung; omitted or 0 means "one more"
   * @param {number} [cap] the highest rung this battler can reach (1..3)
   * @returns {{e:(string|null),t:number}} a NEW record (the input is never mutated)
   */
  function push(rec, emotion, tier, cap) {
    var cur = normalise(rec, cap), c = clampCap(cap);
    if (emotion === 'calm') return { e: null, t: 0 };
    if (!isEmotion(emotion)) return cur;
    var want = Math.floor(Number(tier));
    if (want >= 1) return { e: emotion, t: Math.min(want, c) };
    if (cur.e === emotion) return { e: emotion, t: Math.min(cur.t + 1, c) };
    return { e: emotion, t: 1 };
  }

  /**
   * Which side of the wheel an attack lands on.
   * @returns {number} +1 the attacker's emotion beats the target's, -1 it loses, 0 neither
   */
  function edge(attackerE, targetE) {
    if (!isEmotion(attackerE) || !isEmotion(targetE)) return 0;
    if (EMOTIONS[attackerE].beats === targetE) return 1;
    if (EMOTIONS[targetE].beats === attackerE) return -1;
    return 0;
  }

  /**
   * The damage multiplier for an attack, from both records.
   * @param {{e,t}} attacker
   * @param {{e,t}} target
   * @param {{advantage:number, disadvantage:number}} [rates]
   */
  function damageRate(attacker, target, rates) {
    var r = rates || DEFAULT_RATES;
    var k = edge(attacker && attacker.e, target && target.e);
    if (k > 0) return finiteOr(r.advantage, DEFAULT_RATES.advantage);
    if (k < 0) return finiteOr(r.disadvantage, DEFAULT_RATES.disadvantage);
    return 1;
  }
  function finiteOr(v, d) { var n = Number(v); return isFinite(n) && n >= 0 ? n : d; }

  /**
   * The multiplier a record puts on base parameter `paramId` (0..7). Never below 0.05: a table
   * that would zero a stat is a mistake in the table, not a design.
   * @param {{e,t}} rec
   * @param {number} paramId
   * @param {Object} [steps] a replacement PARAM_STEPS table
   */
  function paramRate(rec, paramId, steps) {
    // called by the engine every time a stat is read: validate in place, allocate nothing
    if (!rec || !isEmotion(rec.e)) return 1;
    var t = Math.floor(Number(rec.t));
    if (!(t >= 1)) return 1;
    if (t > MAX_TIER) t = MAX_TIER;
    var table = (steps && steps[rec.e]) || PARAM_STEPS[rec.e];
    var s = Number(table[paramId]);
    if (!isFinite(s)) return 1;
    return Math.max(0.05, 1 + t * s);
  }

  /** The word a player reads for a record ('Ecstatic'), or '' when calm. */
  function rungName(rec) {
    var r = normalise(rec);
    return r.e ? EMOTIONS[r.e].rungs[r.t - 1] : '';
  }

  /**
   * Read a <Sentiment: ...> notetag from a database note. Accepted forms (case-insensitive):
   *   <Sentiment: happy>        one more rung of happy
   *   <Sentiment: sad 2>        straight to rung 2
   *   <Sentiment: calm>         clears
   *   <Sentiment target: user>  the push lands on the user instead of the target
   * @param {string} note
   * @returns {{emotion:string, tier:number, toUser:boolean}|null}
   */
  function readTag(note) {
    var text = String(note || '');
    var m = /<\s*sentiment\s*:\s*(happy|sad|angry|calm)(?:\s+(\d+))?\s*>/i.exec(text);
    if (!m) return null;
    var who = /<\s*sentiment\s+target\s*:\s*(user|target)\s*>/i.exec(text);
    return { emotion: m[1].toLowerCase(), tier: m[2] ? Number(m[2]) : 0, toUser: !!(who && who[1].toLowerCase() === 'user') };
  }

  /** <Sentiment max: 2> on an actor or enemy note: the highest rung it can reach. */
  function readCap(note) {
    var m = /<\s*sentiment\s+max\s*:\s*(\d+)\s*>/i.exec(String(note || ''));
    return m ? clampCap(Number(m[1])) : MAX_TIER;
  }

  /** <Sentiment start: angry 1> on an actor or enemy note: how it enters battle. */
  function readStart(note) {
    var m = /<\s*sentiment\s+start\s*:\s*(happy|sad|angry)(?:\s+(\d+))?\s*>/i.exec(String(note || ''));
    return m ? { e: m[1].toLowerCase(), t: m[2] ? Number(m[2]) : 1 } : null;
  }

  /**
   * A small seeded generator (mulberry32) for the drawing kit, so one battler's scribble is the
   * same scribble every time it is drawn. Never used for game rules.
   */
  function rng(seed) {
    var a = (seed >>> 0) || 1;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  /** FNV-1a over a string: a stable seed from a face name and index. */
  function hash(str) {
    var h = 2166136261;
    var s = String(str);
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
  }

  var API = {
    EMOTIONS: EMOTIONS, ORDER: ORDER, MAX_TIER: MAX_TIER, PARAM_STEPS: PARAM_STEPS, DEFAULT_RATES: DEFAULT_RATES,
    isEmotion: isEmotion, normalise: normalise, push: push, edge: edge, damageRate: damageRate,
    paramRate: paramRate, rungName: rungName, readTag: readTag, readCap: readCap, readStart: readStart,
    rng: rng, hash: hash, version: '1.0.0',
  };
  root.CSAF = root.CSAF || {};
  root.CSAF.SentimentCore = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof window !== 'undefined' ? window : globalThis);
