//=============================================================================
// WindowskinFoundryCore.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt (no redistribution of the source).
//=============================================================================
/*:
 * @target MZ
 * @plugindesc v1.0.0 Windowskin Foundry core: reads a palette from tileset pixels and re-strikes a windowskin into it. Load with WindowskinFoundry.js.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * Pure functions, no engine calls: WindowskinFoundry.js uses them. Kept apart so
 * the palette reading and the re-strike are testable outside the engine.
 */

(function (root) {
  'use strict';

  /** RGB 0..255 -> HSL with h in degrees [0,360), s and l in [0,1]. */
  function rgbToHsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2;
    if (mx === mn) return [0, 0, l];
    const d = mx - mn, s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
    let h;
    if (mx === r) h = (g - b) / d + (g < b ? 6 : 0); else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4;
    return [h * 60, s, l];
  }

  /** HSL -> RGB 0..255 (rounded). */
  function hslToRgb(h, s, l) {
    h = ((h % 360) + 360) % 360 / 360;
    if (s === 0) { const v = Math.round(l * 255); return [v, v, v]; }
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
    const f = (t) => { if (t < 0) t += 1; if (t > 1) t -= 1; if (t < 1 / 6) return p + (q - p) * 6 * t; if (t < 1 / 2) return q; if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6; return p; };
    return [Math.round(f(h + 1 / 3) * 255), Math.round(f(h) * 255), Math.round(f(h - 1 / 3) * 255)];
  }

  /** WCAG relative luminance and contrast. */
  function lum(c) { const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]); }
  function contrast(a, b) { const x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); }

  /**
   * Read the palette a set of tileset pixels is painted in: the dominant HUE among chromatic mid-tone pixels (36 bins,
   * each pixel weighted by its chroma, circularly smoothed), that hue's mean saturation, and the share of chromatic
   * pixels that carried it. Transparent and near-grey pixels do not vote.
   * @param {Uint8ClampedArray|Uint8Array|number[]} rgba Pixels, 4 bytes each (several sheets may be concatenated).
   * @param {number} [rank=0] 0 = the dominant hue, 1 = the next distinct one (at least 40 degrees away), 2 = the third.
   * @returns {{hue:number, sat:number, share:number, voters:number}|null} null when no pixel voted.
   */
  function paletteOf(rgba, rank) {
    rank = rank | 0;
    const bins = new Float64Array(36), satSum = new Float64Array(36);
    let voters = 0, total = 0;
    for (let i = 0; i < rgba.length; i += 4) {
      if (rgba[i + 3] < 200) continue;
      const hsl = rgbToHsl(rgba[i], rgba[i + 1], rgba[i + 2]);
      if (hsl[1] < 0.18 || hsl[2] < 0.12 || hsl[2] > 0.88) continue;
      const w = hsl[1] * (1 - Math.abs(2 * hsl[2] - 1)), b = Math.floor(hsl[0] / 10) % 36;
      bins[b] += w; satSum[b] += hsl[1] * w; total += w; voters++;
    }
    if (!voters) return null;
    const smooth = new Float64Array(36);
    // rank on the SAME three-bin sum the share reports (a half-weighted smoothing ranked a 32% hue above a 36% one)
    for (let b = 0; b < 36; b++) smooth[b] = bins[(b + 35) % 36] + bins[b] + bins[(b + 1) % 36];
    const taken = [];
    for (let k = 0; k <= rank; k++) {
      let best = -1, bv = -1;
      for (let b = 0; b < 36; b++) {
        if (taken.some((t) => Math.min(Math.abs(t - b), 36 - Math.abs(t - b)) < 4)) continue;
        if (smooth[b] > bv) { bv = smooth[b]; best = b; }
      }
      if (best < 0 || bv <= 0) return null;
      taken.push(best);
    }
    const b = taken[rank];
    // the hue inside the winning bin, weighted by its neighbours (a bin centre would quantise every palette to 10 degrees)
    const l = bins[(b + 35) % 36], c = bins[b], r = bins[(b + 1) % 36];
    const hue = ((b * 10 + 5 + 10 * (r - l) / Math.max(1e-9, l + c + r)) + 360) % 360;
    const sat = (satSum[(b + 35) % 36] + satSum[b] + satSum[(b + 1) % 36]) / Math.max(1e-9, l + c + r);
    return { hue, sat, share: (l + c + r) / total, voters };
  }

  // The engine's own windowskin layout (rmmz_core.js 4062-4181): which part each pixel belongs to.
  function partOf(x, y) {
    if (y < 96) return x < 96 ? 'back' : 'frame';
    if (x < 96) return 'pattern';
    if (y < 144) return x < 144 ? 'cursor' : 'pause';
    return 'swatch';
  }

  /**
   * Re-strike a windowskin into a palette. Every pixel keeps its HSL lightness and its alpha byte-for-byte (so the layout
   * the engine reads cannot move); hue becomes the palette's; the metal parts (frame, cursor, arrows, pause sign) take the
   * palette's saturation, and the back and pattern a restrained share of it so the field stays a field. The 32 text
   * swatches stay as authored except 0 (normal) and 16 (system), which are re-struck and lifted until they clear `minContrast`
   * on the back as the engine DRAWS it: at backOpacity 192 over a white scene, on the back's lightest row.
   * @param {Uint8Array|Uint8ClampedArray} px 192*192*4 RGBA of the source skin. Not modified.
   * @param {{hue:number, sat:number}} pal From paletteOf.
   * @param {{minContrast?:number, fieldSat?:number}} [opt]
   * @returns {{px:Uint8ClampedArray, normal:number[], system:number[], cNormal:number, cSystem:number}}
   */
  function restrike(px, pal, opt) {
    opt = opt || {};
    const minC = opt.minContrast || 4.5, fieldSat = opt.fieldSat === undefined ? 0.45 : opt.fieldSat;
    const out = new Uint8ClampedArray(px.length);
    // ⛔ LOOKED AT 2026-10-03: metal at the palette's full saturation (0.80 for an infernal set) read as coloured PLASTIC.
    // A metal reads through value contrast and white-running speculars at modest saturation, so the metal parts cap at
    // 0.55 and their highlights (L > 0.72) lose saturation as they brighten.
    const metalSat = Math.max(0.22, Math.min(0.55, pal.sat));
    for (let y = 0; y < 192; y++) for (let x = 0; x < 192; x++) {
      const o = (y * 192 + x) * 4, part = partOf(x, y);
      out[o + 3] = px[o + 3];
      if (part === 'swatch') { out[o] = px[o]; out[o + 1] = px[o + 1]; out[o + 2] = px[o + 2]; continue; }
      const hsl = rgbToHsl(px[o], px[o + 1], px[o + 2]);
      const spec = hsl[2] > 0.72 ? Math.max(0, 1 - (hsl[2] - 0.72) / 0.28) : 1;
      const s = part === 'back' || part === 'pattern' ? Math.min(hsl[1], metalSat * fieldSat) : Math.min(1, (hsl[1] * 0.45 + metalSat * 0.55) * spec);
      const c = hslToRgb(pal.hue, hsl[1] < 0.04 && part !== 'back' && part !== 'pattern' ? hsl[1] : s, hsl[2]);
      out[o] = c[0]; out[o + 1] = c[1]; out[o + 2] = c[2];
    }
    // the back as drawn: its lightest row, at backOpacity 192 over white
    const BO = 192 / 255;
    let light = [0, 0, 0], ll = -1;
    for (let y = 0; y < 95; y++) {
      const s = [0, 0, 0];
      for (let x = 0; x < 95; x++) { const o = (y * 192 + x) * 4; s[0] += out[o]; s[1] += out[o + 1]; s[2] += out[o + 2]; }
      const m = [s[0] / 95, s[1] / 95, s[2] / 95], L = lum(m);
      if (L > ll) { ll = L; light = m; }
    }
    const onWhite = light.map((v) => v * BO + 255 * (1 - BO));
    const lift = (c) => { let k = 0; while (contrast(c, onWhite) < minC && k < 40) { c = [c[0] + (255 - c[0]) * 0.12, c[1] + (255 - c[1]) * 0.12, c[2] + (250 - c[2]) * 0.12]; k++; } return c.map(Math.round); };
    const normal = lift(hslToRgb(pal.hue, 0.18, 0.92)), system = lift(hslToRgb(pal.hue, Math.min(0.7, metalSat + 0.1), 0.74));
    const paint = (n, c) => { const x0 = 96 + (n % 8) * 12, y0 = 144 + Math.floor(n / 8) * 12; for (let y = y0; y < y0 + 12; y++) for (let x = x0; x < x0 + 12; x++) { const o = (y * 192 + x) * 4; out[o] = c[0]; out[o + 1] = c[1]; out[o + 2] = c[2]; out[o + 3] = 255; } };
    paint(0, normal); paint(16, system);
    return { px: out, normal, system, cNormal: contrast(normal, onWhite), cSystem: contrast(system, onWhite) };
  }

  const api = { rgbToHsl, hslToRgb, lum, contrast, paletteOf, partOf, restrike };
  // ALWAYS publish on the root: NW.js can expose `module` in the page, and an either/or would leave the engine without it
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.WindowskinFoundryCore = api;
})(typeof window !== 'undefined' ? window : globalThis);
