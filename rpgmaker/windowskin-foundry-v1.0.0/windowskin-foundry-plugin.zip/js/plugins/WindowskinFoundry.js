//=============================================================================
// WindowskinFoundry.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt (no redistribution of the source).
//=============================================================================
/*:
 * @target MZ
 * @plugindesc v1.0.0 Windowskin Foundry: worked-material windowskins (brass, iron, oak and more), chosen per game or in play.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @param skin
 * @text Window skin
 * @desc The skin every window uses. Leave blank to keep img/system/Window.png.
 * @type file
 * @dir img/system/
 * @default Window_Brass_Stud
 *
 * @command setSkin
 * @text Set window skin
 * @desc Switch every window to another skin. The choice is saved with the game.
 *
 * @arg skin
 * @text Window skin
 * @type file
 * @dir img/system/
 * @default Window_Iron_Bolt
 *
 * @command restrike
 * @text Re-strike from this map's tileset (playtest)
 * @desc Read the current map's tileset images, re-tint a skin into one of their three main hues, and save it to img/system. Playtest only.
 *
 * @arg skin
 * @text Source skin
 * @desc The skin to re-strike. Blank = the skin in force.
 * @type file
 * @dir img/system/
 * @default
 *
 * @arg rank
 * @text Which hue
 * @desc 0 = the tileset's most-used hue, 1 = the second, 2 = the third.
 * @type select
 * @option Most used
 * @value 0
 * @option Second
 * @value 1
 * @option Third
 * @value 2
 * @default 0
 *
 * @arg name
 * @text Save as
 * @desc File name for the new skin (no extension). Blank = Window_<source>_<tileset>R<rank>.
 * @type string
 * @default
 *
 * @arg apply
 * @text Use it now
 * @desc Switch every window to the new skin once it is written.
 * @type boolean
 * @default true
 *
 * @help
 * Windowskin Foundry ships windowskins in RPG Maker MZ's own 192x192 layout,
 * struck in worked materials (a chamfered rim lit from the upper left, plates
 * seated in the corners, a cast shadow onto the window back), so any window in
 * your game takes them with no other change.
 *
 * Plugin command: Set window skin. Every window adopts it at once and the choice
 * is saved with the game.
 *
 * Plugin command: Re-strike (playtest only). Reads the images of the current
 * map's tileset, finds their three main hues, and re-tints a skin into the one
 * you pick: the rim, plates and cursor take the hue, the back keeps its depth,
 * the normal and system text colours are re-struck and lifted until they read
 * at 4.5:1 or better on the window as MZ draws it. The other 30 text colours
 * (HP/MP gauges, damage) are left as they were. The new PNG is written to
 * img/system; a file it would replace is first copied to
 * img/system/WindowskinFoundry_backups. Nothing is written outside a playtest.
 *
 * Requires WindowskinFoundryCore.js (any order).
 */

(() => {
  'use strict';
  const NAME = 'WindowskinFoundry';
  const params = PluginManager.parameters(NAME);
  const DEFAULT_SKIN = String(params.skin || '').trim();

  // ⛔ BREAKIT 2026-10-03: a mistyped name in Set window skin, or a save naming a re-strike the developer later deleted,
  // went straight to ImageManager.loadSystem; the errored bitmap in its cache makes ImageManager.isReady() THROW and the
  // whole game stops on "Failed to load". A name chosen in play is now PROBED through Bitmap.load (outside ImageManager's
  // cache) and adopted only once it has loaded. A name that fails is refused with a console warning, the windows stay on
  // the skin in force, and the refused name is taken out of $gameSystem so a save never carries it. The PARAMETER skin is
  // not probed: a missing parameter file stops at boot like any missing image, as the Readme says.
  const probes = Object.create(null); // name -> 'ok' | 'bad' | Bitmap (still loading)
  let inForce = '';                     // the in-play choice the windows wear ('' = the parameter)
  function probe(name) {
    let s = probes[name];
    if (s === undefined) s = probes[name] = Bitmap.load('img/system/' + Utils.encodeURI(name) + '.png');
    if (typeof s === 'string') return s;
    if (s.isReady()) return (probes[name] = 'ok');
    if (s.isError()) {
      console.warn('[WindowskinFoundry] window skin "' + name + '" could not be loaded from img/system - keeping ' + (inForce || DEFAULT_SKIN || 'Window'));
      return (probes[name] = 'bad');
    }
    return 'loading';
  }

  /** The skin in force: the in-play choice once it has loaded, else the parameter, else '' (stock Window.png). */
  function currentSkin() {
    const sys = $gameSystem;
    const chosen = sys && typeof sys._csafWindowskin === 'string' ? sys._csafWindowskin : '';
    if (chosen !== inForce) {
      const st = !chosen || chosen === DEFAULT_SKIN ? 'ok' : probe(chosen);
      if (st === 'ok') inForce = chosen;
      else if (st === 'bad') sys._csafWindowskin = inForce;
    }
    return inForce || DEFAULT_SKIN;
  }

  const _loadWindowskin = Window_Base.prototype.loadWindowskin;
  Window_Base.prototype.loadWindowskin = function () {
    const name = currentSkin();
    this._csafSkinName = name;
    if (!name) { _loadWindowskin.call(this); return; }
    this.windowskin = ImageManager.loadSystem(name);
  };

  const _update = Window_Base.prototype.update;
  Window_Base.prototype.update = function () {
    _update.call(this);
    // A skin changed in play reaches windows that already exist; a string compare per window per frame, no allocation.
    // ⛔ BREAKIT 2026-10-03: a window class from another plugin that overrides loadWindowskin (to keep its own skin)
    // never sets _csafSkinName, so this check called ITS loadWindowskin every frame (61 calls in 60 frames). The name
    // compared against is recorded here, so any override runs once per swap, never per frame.
    const name = currentSkin();
    if (this._csafSkinName !== name) { this.loadWindowskin(); this._csafSkinName = name; }
  };

  // TEXT COLOURS. MZ reads every text colour (and the pending colour) from img/system/Window.png, loaded ONCE at boot
  // (ColorManager.loadWindowskin, rmmz_managers.js:1750; called from Scene_Boot, rmmz_scenes.js:302) - never from the
  // window's own skin. So a skin under any other name would draw the stock colours. Point ColorManager at the skin in
  // force, and only once its file has arrived, so a swap in play never reads swatches from an unloaded bitmap.
  let colourSkin = '';
  function syncColours() {
    const name = currentSkin() || 'Window';
    if (colourSkin === name) return;
    const bmp = ImageManager.loadSystem(name);
    if (!bmp.isReady()) return;
    ColorManager._windowskin = bmp;
    colourSkin = name;
    // windows already drawn hold the old colours in their bitmaps: redraw them once, on the swap, never per frame
    const scene = SceneManager._scene, layer = scene && scene._windowLayer;
    if (!layer) return;
    for (const w of layer.children) if (w instanceof Window_Base && typeof w.refresh === 'function') w.refresh();
  }

  const _cmLoad = ColorManager.loadWindowskin;
  ColorManager.loadWindowskin = function () {
    _cmLoad.call(this);
    colourSkin = 'Window';
    // at boot there is no $gameSystem yet: the parameter decides, and Scene_Boot waits for the file (isReady)
    if (DEFAULT_SKIN) { this._windowskin = ImageManager.loadSystem(DEFAULT_SKIN); colourSkin = DEFAULT_SKIN; }
  };

  // ⛔ MEASURED 2026-10-03 (Internal_Ops/_probe/swap_cost.js, 16 swaps on the main menu): MZ reads every text colour
  // with Bitmap.getPixel (rmmz_core.js 1518), a readback from the skin's canvas. On a skin used for the first time those
  // readbacks cost 50-90 ms inside ONE frame (26 reads, each a GPU sync); warm, 2-4 ms. So the 32 text colours and the
  // pending colour of the skin in force are read ONCE, from its image drawn into a small canvas kept on the CPU
  // (willReadFrequently), and served from that table; any colour the table cannot answer goes to the engine as before.
  let swatchCtx = null, table = null, tableFor = null;
  function readTable(bmp) {
    const img = bmp._image || bmp._canvas;
    if (!img) return null;
    if (!swatchCtx) { const c = document.createElement('canvas'); c.width = 96; c.height = 72; swatchCtx = c.getContext('2d', { willReadFrequently: true }); }
    swatchCtx.clearRect(0, 0, 96, 72);
    swatchCtx.drawImage(img, 96, 120, 96, 72, 0, 0, 96, 72); // skin x 96..191, y 120..191: the pending pixel and the 32 swatches
    const d = swatchCtx.getImageData(0, 0, 96, 72).data;
    const hex = (x, y) => { const i = (y * 96 + x) * 4; let s = '#'; for (let k = 0; k < 3; k++) s += d[i + k].toString(16).padZero(2); return s; }; // getPixel's own format
    const t = [];
    for (let n = 0; n < 32; n++) t.push(hex((n % 8) * 12 + 6, 24 + Math.floor(n / 8) * 12 + 6));
    t.push(hex(24, 0)); // pendingColor reads (120, 120)
    return t;
  }
  function tableOf(bmp) {
    if (tableFor !== bmp) { table = bmp && bmp.isReady() ? readTable(bmp) : null; tableFor = table ? bmp : null; }
    return table;
  }
  const _textColor = ColorManager.textColor;
  ColorManager.textColor = function (n) {
    const t = n >= 0 && n < 32 ? tableOf(this._windowskin) : null;
    const c = t ? t[n] : undefined;
    return c !== undefined ? c : _textColor.call(this, n);
  };
  const _pendingColor = ColorManager.pendingColor;
  ColorManager.pendingColor = function () {
    const t = tableOf(this._windowskin);
    return t ? t[32] : _pendingColor.call(this);
  };

  const _sceneUpdate = Scene_Base.prototype.update;
  Scene_Base.prototype.update = function () {
    syncColours();
    _sceneUpdate.call(this);
  };

  PluginManager.registerCommand(NAME, 'setSkin', (args) => {
    $gameSystem._csafWindowskin = String(args.skin || '').trim();
  });

  //---------------------------------------------------------------------------
  // Re-strike (playtest only). File access goes through a seam: NW.js fs by default, injectable for tests.
  //---------------------------------------------------------------------------
  let injectedIO = null;
  function nwIO() {
    if (!Utils.isNwjs() || typeof require !== 'function') return null;
    const fs = require('fs'), path = require('path'), base = path.dirname(process.mainModule.filename);
    const abs = (rel) => path.join(base, rel);
    return {
      exists: (rel) => fs.existsSync(abs(rel)),
      read: (rel) => fs.readFileSync(abs(rel)).toString('base64'),
      write: (rel, b64) => { fs.mkdirSync(path.dirname(abs(rel)), { recursive: true }); fs.writeFileSync(abs(rel), Buffer.from(b64, 'base64')); },
    };
  }
  /** Siblings resolve at first use, never at load: the buyer chooses the plugin order (wing §8 trap 2). */
  function core() {
    const c = typeof window !== 'undefined' ? window.WindowskinFoundryCore : null;
    if (!c) throw new Error('WindowskinFoundryCore.js is not loaded - add it in the Plugin Manager');
    return c;
  }
  // ⛔ MZ's Bitmap._onError only sets the state and calls NO listener (rmmz_core.js 1839-1841): a promise waiting on
  // addLoadListener never settles on a missing file (measured: the engine test hung). Poll, with a ceiling. And load
  // through Bitmap.load, never ImageManager: an errored bitmap in ImageManager's cache makes isReady() throw and puts the
  // whole game on the "Failed to load" screen.
  function loadPng(folder, name) { return Bitmap.load(folder + Utils.encodeURI(name) + '.png'); }
  function loaded(bmp) {
    return new Promise((resolve, reject) => {
      const t0 = Date.now();
      const tick = () => {
        if (bmp.isReady()) resolve(bmp);
        else if (bmp.isError() || Date.now() - t0 > 10000) reject(new Error('could not load ' + bmp._url));
        else setTimeout(tick, 30);
      };
      tick();
    });
  }
  function pixelsOf(bmp) { const c = document.createElement('canvas'); c.width = bmp.width; c.height = bmp.height; const g = c.getContext('2d'); g.drawImage(bmp._image || bmp.canvas, 0, 0); return g.getImageData(0, 0, c.width, c.height).data; }

  const state = { last: null };
  /**
   * Re-strike a skin into one of a tileset's three main hues and write it to img/system.
   * @param {{skin?:string, rank?:number|string, name?:string, apply?:boolean|string, tilesetNames?:string[]}} args
   * @returns {Promise<object>} The record also kept on WindowskinFoundry.last: {state:'done'|'refused', ...}.
   */
  async function restrike(args) {
    const refuse = (why) => { state.last = { state: 'refused', why }; console.warn('[WindowskinFoundry] re-strike refused: ' + why); return state.last; };
    try {
      if (!Utils.isOptionValid('test')) return refuse('re-strike runs in a playtest only (it writes files into your project)');
      const io = injectedIO || nwIO();
      if (!io) return refuse('no file access here - run it from a playtest of the desktop editor');
      const C = core();
      const rank = Math.max(0, Math.min(2, Number(args.rank) || 0));
      const src = String(args.skin || '').trim() || currentSkin() || 'Window';
      let names = Array.isArray(args.tilesetNames) ? args.tilesetNames : null;
      let setLabel = 'Custom';
      if (!names) {
        const ts = $gameMap && $dataTilesets[$gameMap.tilesetId()];
        if (!ts) return refuse('no map is loaded, so there is no tileset to read');
        names = ts.tilesetNames; setLabel = String(ts.name || 'Tileset' + ts.id).replace(/[^A-Za-z0-9]+/g, '');
      }
      names = names.filter((n) => n);
      if (!names.length) return refuse('this tileset has no images');
      const sheets = await Promise.all(names.map((n) => loaded(loadPng('img/tilesets/', n))));
      let total = 0; const parts = sheets.map((b) => { const p = pixelsOf(b); total += p.length; return p; });
      const all = new Uint8ClampedArray(total); let k = 0; for (const p of parts) { all.set(p, k); k += p.length; }
      const pal = C.paletteOf(all, rank);
      if (!pal) return refuse('the tileset has no hue at rank ' + rank + ' (too few coloured pixels)');
      const skinBmp = await loaded(loadPng('img/system/', src));
      if (skinBmp.width !== 192 || skinBmp.height !== 192) return refuse(src + ' is ' + skinBmp.width + 'x' + skinBmp.height + ', not a 192x192 windowskin');
      const res = C.restrike(pixelsOf(skinBmp), pal);
      const outName = (String(args.name || '').trim() || (src + '_' + setLabel + 'R' + rank)).replace(/[^A-Za-z0-9_-]+/g, '');
      const rel = 'img/system/' + outName + '.png';
      let backup = null;
      if (io.exists(rel)) { backup = 'img/system/WindowskinFoundry_backups/' + outName + '-' + Date.now() + '.png'; io.write(backup, io.read(rel)); }
      const c = document.createElement('canvas'); c.width = 192; c.height = 192;
      c.getContext('2d').putImageData(new ImageData(res.px, 192, 192), 0, 0);
      io.write(rel, c.toDataURL('image/png').split(',')[1]);
      // MZ caches system images in ImageManager._system keyed by url (rmmz_managers.js 963-978): drop the stale entry so a
      // re-strike over an existing name is seen, and make every live window and the colours reload it
      if (ImageManager._system) delete ImageManager._system['img/system/' + Utils.encodeURI(outName) + '.png'];
      delete probes[outName]; // a name refused earlier (it did not exist then) is probed again now that it does
      const apply = String(args.apply === undefined ? 'true' : args.apply) === 'true';
      if (apply) $gameSystem._csafWindowskin = outName;
      if (apply || outName === currentSkin()) {
        colourSkin = '';
        const layer = SceneManager._scene && SceneManager._scene._windowLayer;
        if (layer) for (const w of layer.children) if (w instanceof Window_Base) w._csafSkinName = null;
      }
      state.last = { state: 'done', file: rel, backup, source: src, hue: pal.hue, sat: pal.sat, share: pal.share, rank, contrast: [res.cNormal, res.cSystem], applied: apply };
      return state.last;
    } catch (e) {
      return refuse(e.message);
    }
  }

  PluginManager.registerCommand(NAME, 'restrike', (args) => { restrike(args); });

  window.WindowskinFoundry = {
    restrike,
    setIO: (io) => { injectedIO = io; },
    get last() { return state.last; },
  };
})();
