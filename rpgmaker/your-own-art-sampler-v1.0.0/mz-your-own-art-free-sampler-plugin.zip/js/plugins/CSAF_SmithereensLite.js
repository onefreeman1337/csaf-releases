/*:
 * @target MZ
 * @plugindesc [v1.0.0] Smithereens Lite (free): pots, jars and urns of your own art burst into curved sherds cut from their own pixels.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io/
 *
 * @param debrisSeconds
 * @text Debris lifetime (seconds)
 * @desc How long the sherds stay on the ground before fading. 0 = until the map changes.
 * @type number
 * @min 0
 * @max 600
 * @default 20
 *
 * @param persistSwitch
 * @text Persist with self switch
 * @desc none = a broken pot returns when the map reloads (the classic pot). A-D = set that self switch instead.
 * @type select
 * @option none
 * @option A
 * @option B
 * @option C
 * @option D
 * @default none
 *
 * @command smash
 * @text Smash event
 * @desc Break a pot marked <smash> or <smash: ceramic>. It bursts into sherds cut from its own graphic.
 * @arg eventId
 * @text Event ID
 * @desc 0 = this event.
 * @type number
 * @min 0
 * @default 0
 *
 * @help CSAF_SmithereensLite.js  (one file, no other plugin needed)
 *
 * The free ceramic break of Smithereens.
 *
 * Mark a pot, jar, vase or urn breakable in the event's Note box:
 *   <smash>              break it as ceramic
 *   <smash: ceramic>     the same, said out loud
 *
 * Then break it with the plugin command "Smash event" (Event ID 0 = this
 * event), for example on an Action Button page of the pot itself. The pot
 * bursts into curved sherds that spiral out from the side it was struck
 * and skitter away from the player, and the sherds lie on the ground for
 * the Debris lifetime, then fade. Every sherd is cut from the exact frame
 * the event is showing (a tile graphic or a character/object sheet), so
 * the break always matches your own art, in any style. Upscaled pixel art
 * breaks along its own pixel grid.
 *
 * By default a broken pot returns when the map is reloaded; set "Persist
 * with self switch" to keep it broken.
 *
 * What this free version does NOT do (the event simply stays as drawn):
 *   any other material word in the tag, a "hits:" or "regrow:" option.
 *
 * Smithereens (https://csaf.itch.io/smithereens) adds wood, stone, crystal,
 * ice, foliage and generic breaks, each coming apart a different way; the
 * 171-tile table of RPG Maker MZ's own stock breakables, so a bare <smash>
 * finds the material for you; gathering nodes that crack with every hit
 * and grow back over play time; and materials by terrain tag and region.
 * Install Smithereens and this Lite stands aside by itself: it reads the
 * same <smash> tags, and its "Smash event" command hands the hit to
 * Smithereens, so no event has to change.
 *
 * Script call: CSAF.SmithereensLite.smash(eventId) -> 'broke', 'queued' or ''
 *
 * Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.
 */

/*
 * HOW THIS FILE WAS MADE: it is a CUT of Smithereens v1.0.0 (SmithereensCore.js, SmithereensCut.js, Smithereens.js),
 * keeping the ceramic path byte-for-byte in behaviour. Internal_Ops/tests/smithereens_lite.test.js loads the paid
 * SmithereensCore as an oracle and requires every fracture and every burst trajectory of this file to equal it.
 */
(function (root) {
  'use strict';
  const CSAF = (root.CSAF = root.CSAF || {});
  if (CSAF.SmithereensLite) return;

  const MIN_FRAGMENT = 3;
  const TAU = Math.PI * 2;

  /**
   * 32-bit FNV-1a string hash.
   * @param {string} str
   * @returns {number} unsigned 32-bit hash
   */
  function hash(str) {
    let h = 2166136261 >>> 0;
    const s = String(str);
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619) >>> 0;
    }
    return h >>> 0;
  }
  // the seed salts Smithereens uses for a ceramic break, so a pot breaks here exactly as it does there
  const FRACTURE_SALT = hash('ceramic');
  const BURST_SALT = hash('burst:ceramic');

  /**
   * Seeded random stream (mulberry32). Never Math.random in a break.
   * @param {number} seed
   * @constructor
   */
  function Rng(seed) {
    this.s = (seed >>> 0) || 1;
  }
  /** @returns {number} a float in [0, 1) */
  Rng.prototype.next = function () {
    let t = (this.s = (this.s + 0x6d2b79f5) >>> 0);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  /** @returns {number} a float in [a, b) */
  Rng.prototype.range = function (a, b) {
    return a + (b - a) * this.next();
  };
  /** @returns {number} an integer in [a, b] inclusive */
  Rng.prototype.int = function (a, b) {
    return a + Math.floor((b - a + 1) * this.next());
  };

  function clamp(v, a, b) {
    return v < a ? a : v > b ? b : v;
  }

  /**
   * Area, bounds and centroid of the opaque pixels of a mask.
   * @param {Uint8Array} mask
   * @param {number} w
   * @param {number} h
   * @returns {{area:number,minX:number,minY:number,maxX:number,maxY:number,cx:number,cy:number}}
   */
  function maskInfo(mask, w, h) {
    let area = 0, minX = w, minY = h, maxX = -1, maxY = -1, sx = 0, sy = 0;
    for (let y = 0; y < h; y++) {
      const row = y * w;
      for (let x = 0; x < w; x++) {
        if (!mask[row + x]) continue;
        area++;
        sx += x + 0.5;
        sy += y + 0.5;
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
    return { area, minX, minY, maxX, maxY, cx: area ? sx / area : w / 2, cy: area ? sy / area : h / 2 };
  }

  // The impact point, coerced: a NaN or missing coordinate becomes the centroid (a NaN must never reach a threshold).
  function impactOf(info, opts) {
    const imp = opts && opts.impact;
    let x = imp ? Number(imp.x) : NaN;
    let y = imp ? Number(imp.y) : NaN;
    if (!isFinite(x)) x = info.cx;
    if (!isFinite(y)) y = info.cy;
    return { x, y };
  }

  function radiusFrom(mask, w, h, px, py) {
    let r = 0;
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        if (!mask[y * w + x]) continue;
        const dx = x + 0.5 - px, dy = y + 0.5 - py;
        const d = dx * dx + dy * dy;
        if (d > r) r = d;
      }
    }
    return Math.sqrt(r) || 1;
  }

  // K sector boundaries around a full turn, widths 0.7-1.3 of the mean.
  function sectorCuts(K, rng) {
    const wts = [];
    let sum = 0;
    for (let k = 0; k < K; k++) {
      const v = rng.range(0.7, 1.3);
      wts.push(v);
      sum += v;
    }
    const base = rng.next() * TAU;
    const cuts = [base];
    let acc = base;
    for (let k = 0; k < K - 1; k++) {
      acc += (wts[k] / sum) * TAU;
      cuts.push(acc);
    }
    return cuts;
  }

  function sectorOf(a, cuts) {
    const base = cuts[0];
    let t = a - base;
    t = t - Math.floor(t / TAU) * TAU + base;
    let s = 0;
    for (let k = 1; k < cuts.length; k++) if (t >= cuts[k]) s = k;
    return s;
  }

  /**
   * The ceramic break: curved sherds, sectors that spiral out from the impact, cut by a wavy ring.
   * Returns { at(x, y) -> raw label >= 0, curl }. x, y are integer pixel coordinates.
   */
  function ceramicCuts(c) {
    const K = c.rng.int(5, 8);
    const cuts = sectorCuts(K, c.rng);
    const curl = c.rng.range(0.6, 1.1) * (c.rng.next() < 0.5 ? -1 : 1);
    const phase = c.rng.next() * TAU;
    const rr = c.rng.range(0.4, 0.55);
    // The curl varies smoothly with angle (0.55x to 1.45x) so each sherd edge bends by its own amount - a uniform
    // curl read as a pinwheel. |d(a)/d(theta)| stays > 0 for |curl| <= 1.1, so sectors never cross.
    const wobPh = c.rng.next() * TAU;
    const imp = c.imp, rmax = c.rmax;
    return {
      curl,
      at: (x, y) => {
        const dx = x + 0.5 - imp.x, dy = y + 0.5 - imp.y;
        const r = Math.sqrt(dx * dx + dy * dy);
        const th = Math.atan2(dy, dx);
        const a = th - curl * (1 + 0.45 * Math.sin(2 * th + wobPh)) * (r / rmax);
        const ring = rmax * (rr + 0.12 * Math.sin(3 * a + phase));
        return sectorOf(a, cuts) * 2 + (r > ring ? 1 : 0);
      },
    };
  }

  // Turn raw labels into final fragments: split every raw label into 4-connected components, merge components
  // smaller than MIN_FRAGMENT into the neighbour they share most edge with, number the survivors in row-major
  // order of their first pixel (deterministic).
  function finalize(raw, w, h) {
    const N = w * h;
    const comp = new Int32Array(N).fill(-1);
    const compRaw = [], compArea = [];
    const stack = new Int32Array(N);
    for (let i = 0; i < N; i++) {
      if (raw[i] < 0 || comp[i] >= 0) continue;
      const id = compRaw.length, L = raw[i];
      compRaw.push(L);
      let area = 0, sp = 0;
      stack[sp++] = i;
      comp[i] = id;
      while (sp) {
        const j = stack[--sp];
        area++;
        const x = j % w;
        if (x > 0 && comp[j - 1] < 0 && raw[j - 1] === L) { comp[j - 1] = id; stack[sp++] = j - 1; }
        if (x < w - 1 && comp[j + 1] < 0 && raw[j + 1] === L) { comp[j + 1] = id; stack[sp++] = j + 1; }
        if (j >= w && comp[j - w] < 0 && raw[j - w] === L) { comp[j - w] = id; stack[sp++] = j - w; }
        if (j + w < N && comp[j + w] < 0 && raw[j + w] === L) { comp[j + w] = id; stack[sp++] = j + w; }
      }
      compArea.push(area);
    }
    const C = compRaw.length;
    const parent = new Int32Array(C);
    for (let k = 0; k < C; k++) parent[k] = k;
    const find = (k) => {
      while (parent[k] !== k) {
        parent[k] = parent[parent[k]];
        k = parent[k];
      }
      return k;
    };
    // merge small components, smallest first, until none has a neighbour left to join
    const isolated = new Uint8Array(C);
    let changed = true;
    while (changed) {
      changed = false;
      let target = -1, tArea = Infinity;
      for (let k = 0; k < C; k++) {
        if (find(k) !== k || compArea[k] >= MIN_FRAGMENT || isolated[k]) continue;
        if (compArea[k] < tArea) { tArea = compArea[k]; target = k; }
      }
      if (target < 0) break;
      const shared = new Map();
      for (let i = 0; i < N; i++) {
        if (comp[i] < 0 || find(comp[i]) !== target) continue;
        const x = i % w;
        const nb = [x > 0 ? i - 1 : -1, x < w - 1 ? i + 1 : -1, i >= w ? i - w : -1, i + w < N ? i + w : -1];
        for (let q = 0; q < 4; q++) {
          const j = nb[q];
          if (j < 0 || comp[j] < 0) continue;
          const r = find(comp[j]);
          if (r !== target) shared.set(r, (shared.get(r) || 0) + 1);
        }
      }
      if (!shared.size) {
        isolated[target] = 1; // an isolated speck: it stays its own fragment
        changed = true;
        continue;
      }
      let best = -1, bestN = -1;
      shared.forEach((n, r) => {
        if (n > bestN || (n === bestN && r < best)) { bestN = n; best = r; }
      });
      parent[target] = best;
      compArea[best] += compArea[target];
      changed = true;
    }
    // number the survivors
    const finalOf = new Int32Array(C).fill(-1);
    const labels = new Int16Array(N).fill(-1);
    let count = 0;
    for (let i = 0; i < N; i++) {
      if (comp[i] < 0) continue;
      const r = find(comp[i]);
      if (finalOf[r] < 0) finalOf[r] = count++;
      labels[i] = finalOf[r];
    }
    return { labels, count };
  }

  /**
   * Bounds, area and centroid of every fragment.
   * @param {Int16Array} labels
   * @param {number} count
   * @param {number} w
   * @returns {Array<{area:number,minX:number,minY:number,maxX:number,maxY:number,cx:number,cy:number}>}
   */
  function pieces(labels, count, w) {
    const out = [];
    for (let k = 0; k < count; k++) out.push({ area: 0, minX: Infinity, minY: Infinity, maxX: -1, maxY: -1, cx: 0, cy: 0 });
    for (let i = 0; i < labels.length; i++) {
      const L = labels[i];
      if (L < 0) continue;
      const p = out[L], x = i % w, y = (i / w) | 0;
      p.area++;
      p.cx += x + 0.5;
      p.cy += y + 0.5;
      if (x < p.minX) p.minX = x;
      if (x > p.maxX) p.maxX = x;
      if (y < p.minY) p.minY = y;
      if (y > p.maxY) p.maxY = y;
    }
    for (const p of out) {
      p.cx /= p.area;
      p.cy /= p.area;
    }
    return out;
  }

  /**
   * Break a graphic into ceramic sherds. Every opaque pixel of `mask` lands in exactly one sherd.
   * @param {Uint8Array} mask  one byte per pixel, non-zero = opaque
   * @param {number} w
   * @param {number} h
   * @param {number} seed      a break seed (map + event + break index, hashed)
   * @param {{impact?:{x:number,y:number}, scale?:number}} [opts]
   * @returns {{material:string, labels:Int16Array, count:number, pieces:Array, impact:{x:number,y:number}, curl?:number, scale?:number}}
   */
  function fracture(mask, w, h, seed, opts) {
    const k = Math.floor(Number(opts && opts.scale)) || 1;
    if (k > 1 && w % k === 0 && h % k === 0) return fractureScaled(mask, w, h, seed, opts, k);
    const info = maskInfo(mask, w, h);
    const imp = impactOf(info, opts || {});
    if (!info.area) {
      return { material: 'ceramic', labels: new Int16Array(w * h).fill(-1), count: 0, pieces: [], impact: imp };
    }
    const rng = new Rng(((Number(seed) >>> 0) ^ FRACTURE_SALT) >>> 0);
    const ctx = { mask, w, h, info, imp, rng, rmax: radiusFrom(mask, w, h, imp.x, imp.y) };
    const gen = ceramicCuts(ctx);
    const raw = new Int32Array(w * h).fill(-1);
    for (let y = info.minY; y <= info.maxY; y++) {
      for (let x = info.minX; x <= info.maxX; x++) {
        const i = y * w + x;
        if (mask[i]) raw[i] = gen.at(x, y);
      }
    }
    const fin = finalize(raw, w, h);
    return { material: 'ceramic', labels: fin.labels, count: fin.count, pieces: pieces(fin.labels, fin.count, w), impact: imp, curl: gen.curl };
  }

  // Upscaled pixel art (a 16 px tile drawn 3x in a 48 px project) breaks along ITS OWN pixel grid: fracture at the
  // native size, then every label covers a whole k x k art pixel.
  function fractureScaled(mask, w, h, seed, opts, k) {
    const nw = w / k, nh = h / k;
    const small = new Uint8Array(nw * nh);
    for (let y = 0; y < nh; y++) for (let x = 0; x < nw; x++) small[y * nw + x] = mask[y * k * w + x * k] ? 1 : 0;
    const o = {};
    const src = opts || {};
    for (const key in src) if (key !== 'scale') o[key] = src[key];
    if (src.impact) o.impact = { x: Number(src.impact.x) / k, y: Number(src.impact.y) / k };
    const r = fracture(small, nw, nh, seed, o);
    const labels = new Int16Array(w * h).fill(-1);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (mask[y * w + x]) labels[y * w + x] = r.labels[((y / k) | 0) * nw + ((x / k) | 0)];
    // a full-resolution pixel whose block's top-left was transparent has no native label: give it its nearest labelled
    // neighbour in the block so every opaque pixel lands in exactly one sherd
    for (let i = 0; i < labels.length; i++) {
      if (!mask[i] || labels[i] >= 0) continue;
      const x = i % w, y = (i / w) | 0, bx = x - (x % k), by = y - (y % k);
      for (let yy = by; yy < by + k && labels[i] < 0; yy++) for (let xx = bx; xx < bx + k; xx++) if (labels[yy * w + xx] >= 0) { labels[i] = labels[yy * w + xx]; break; }
    }
    let count = r.count;
    for (let i = 0; i < labels.length; i++) if (mask[i] && labels[i] < 0) labels[i] = count++; // isolated specks stay their own
    const out = { material: 'ceramic', labels, count, pieces: pieces(labels, count, w), impact: { x: r.impact.x * k, y: r.impact.y * k }, scale: k };
    if (r.curl !== undefined) out.curl = r.curl;
    return out;
  }

  /**
   * The upscale factor of a picture: k when every k x k block is one colour (k = 4, 3 or 2 tried), else 1.
   * @param {Uint8ClampedArray|Uint8Array} rgba
   * @param {number} w
   * @param {number} h
   * @returns {number}
   */
  function detectScale(rgba, w, h) {
    let opaque = 0;
    for (let i = 3; i < rgba.length; i += 4) if (rgba[i]) { opaque++; break; }
    if (!opaque) return 1;
    for (const k of [4, 3, 2]) {
      if (w % k || h % k) continue;
      let same = true;
      for (let y = 0; y < h && same; y++) {
        const by = y - (y % k);
        for (let x = 0; x < w; x++) {
          const a = (y * w + x) * 4, b = (by * w + (x - (x % k))) * 4;
          if (rgba[a] !== rgba[b] || rgba[a + 1] !== rgba[b + 1] || rgba[a + 2] !== rgba[b + 2] || rgba[a + 3] !== rgba[b + 3]) {
            same = false;
            break;
          }
        }
      }
      if (same) return k;
    }
    return 1;
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Sherd physics
  //
  // A sherd lives on the GROUND PLANE at (x, y) with a height h above it; it is drawn at (x, y - h). A burst starts
  // every piece exactly where it sat in the pot (h = distance above the pot's base row), so frame 0 of a break looks
  // like the unbroken pot. Rotation is reported in QUARTER TURNS only: pixel art is never rotated by a fraction.
  // The ceramic motion: launch speed 1.1-2.3, lift 1.2-2.4, gravity 0.32, fastest fall 6, bounce 0.35, ground slide
  // kept 0.86, no air drag, spin 0.14 quarter turns a frame. The per-frame values are stored as 32-bit floats, the
  // way Smithereens keeps them, so a sherd follows exactly the same path there and here.
  // ---------------------------------------------------------------------------------------------------------------
  const SPEED_LO = 1.1, SPEED_HI = 2.3, LIFT_LO = 1.2, LIFT_HI = 2.4, SPIN = 0.14;
  const GRAV = Math.fround(0.32), TERM = Math.fround(6.0), BOUNCE = Math.fround(0.35), FRICT = Math.fround(0.86), DRAG = Math.fround(1.0);
  const REST = 0.04; // below this ground speed a sherd settles
  const SCATTER = 0.7; // share of a piece's ground velocity that scatters it around the pot
  const DRIVE = 0.65; // share that carries it away from the striker
  const DEPTH = 0.9; // depth runs slightly shorter than across on MZ's square-tile ground
  const BOUNCE_MIN = 0.8; // a landing slower than this does not bounce

  /**
   * A fixed-capacity sherd pool; every field is a typed array so the per-frame step allocates nothing.
   * @param {number} capacity
   * @returns {object} the pool (debrisFrames: 0 = debris stays until clear(); fadeFrames: length of the fade)
   */
  function createPool(capacity) {
    const cap = clamp(Math.floor(Number(capacity)) || 192, 1, 4096);
    return {
      capacity: cap,
      live: 0,
      seq: 1,
      debrisFrames: 1200,
      fadeFrames: 45,
      alive: new Uint8Array(cap),
      settled: new Uint8Array(cap),
      piece: new Int16Array(cap),
      serial: new Uint32Array(cap),
      x: new Float32Array(cap),
      y: new Float32Array(cap),
      h: new Float32Array(cap),
      vx: new Float32Array(cap),
      vy: new Float32Array(cap),
      vh: new Float32Array(cap),
      rot: new Float32Array(cap),
      spin: new Float32Array(cap),
      age: new Float32Array(cap),
      settleAge: new Float32Array(cap),
      tag: new Int32Array(cap), // the layer's break id, so it can find a sherd's texture
    };
  }

  // A free slot, else the OLDEST SETTLED sherd (recycled), else -1. A sherd in flight is never taken.
  function takeSlot(pool) {
    if (pool.live < pool.capacity) {
      for (let i = 0; i < pool.capacity; i++) {
        if (!pool.alive[i]) {
          pool.live++;
          return i;
        }
      }
    }
    let best = -1, bestSerial = 0xffffffff;
    for (let i = 0; i < pool.capacity; i++) {
      if (pool.alive[i] && pool.settled[i] && pool.serial[i] < bestSerial) {
        bestSerial = pool.serial[i];
        best = i;
      }
    }
    return best;
  }

  /**
   * Launch every sherd of a fracture result into the pool.
   * @param {object} pool      from createPool
   * @param {object} res       from fracture
   * @param {number} seed
   * @param {{originX:number, originY:number, dirX?:number, dirY?:number, tag?:number}} opts
   *        origin = where the graphic's top-left sits on screen; dir = the strike direction (away from the striker)
   * @returns {number} sherds spawned (fewer than res.count only when the pool is full of sherds in flight)
   */
  function burst(pool, res, seed, opts) {
    const o = opts || {};
    let ox = Number(o.originX), oy = Number(o.originY);
    if (!isFinite(ox)) ox = 0;
    if (!isFinite(oy)) oy = 0;
    let dx = Number(o.dirX), dy = Number(o.dirY);
    if (!isFinite(dx)) dx = 0;
    if (!isFinite(dy)) dy = 0;
    const dl = Math.sqrt(dx * dx + dy * dy);
    if (dl > 0) {
      dx /= dl;
      dy /= dl;
    }
    const tag = Math.floor(Number(o.tag)) || 0;
    const rng = new Rng(((Math.imul(Number(seed) >>> 0, 2654435761) >>> 0) ^ BURST_SALT) >>> 0);
    let baseY = 0, sumA = 0, sumX = 0, minX = Infinity, maxX = -1;
    for (let k = 0; k < res.count; k++) {
      const p = res.pieces[k];
      if (p.maxY + 1 > baseY) baseY = p.maxY + 1;
      sumA += p.area;
      sumX += p.cx * p.area;
      if (p.minX < minX) minX = p.minX;
      if (p.maxX > maxX) maxX = p.maxX;
    }
    const midX = sumA ? sumX / sumA : 0;
    const halfW = Math.max(1, (maxX - minX + 1) / 2);
    let n = 0;
    for (let k = 0; k < res.count; k++) {
      const p = res.pieces[k];
      const i = takeSlot(pool);
      if (i < 0) break;
      n++;
      pool.alive[i] = 1;
      pool.piece[i] = k;
      pool.tag[i] = tag;
      pool.serial[i] = pool.seq++;
      pool.age[i] = 0;
      pool.settleAge[i] = 0;
      pool.rot[i] = 0;
      rng.next(); // Smithereens draws a sway phase here (ceramic never sways); kept so the stream stays in step with it
      pool.x[i] = ox + p.cx;
      pool.y[i] = oy + baseY;
      pool.h[i] = Math.max(0, baseY - p.cy);
      // The scatter direction lives on the GROUND PLANE: across comes from where the piece sat (left pieces go left),
      // depth is seeded per piece.
      let gx = (p.cx - midX) / halfW;
      gx = gx < -1 ? -1 : gx > 1 ? 1 : gx;
      let gy = rng.range(-1, 1);
      const gl = Math.sqrt(gx * gx + gy * gy);
      if (gl > 0.05) {
        gx /= gl;
        gy /= gl;
      } else {
        const a = rng.next() * TAU;
        gx = Math.cos(a);
        gy = Math.sin(a);
      }
      const speed = rng.range(SPEED_LO, SPEED_HI);
      pool.vx[i] = speed * (SCATTER * gx + DRIVE * dx);
      pool.vy[i] = speed * DEPTH * (SCATTER * gy + DRIVE * dy);
      pool.vh[i] = rng.range(LIFT_LO, LIFT_HI);
      pool.spin[i] = SPIN * rng.range(0.5, 1.5) * (rng.next() < 0.5 ? -1 : 1);
      pool.settled[i] = 0;
    }
    return n;
  }

  /**
   * Advance every sherd one frame. Zero allocation: typed arrays and numbers only.
   * @param {object} pool
   */
  function step(pool) {
    const cap = pool.capacity;
    for (let i = 0; i < cap; i++) {
      if (!pool.alive[i]) continue;
      pool.age[i] += 1;
      if (pool.settled[i]) {
        if (pool.debrisFrames > 0 && pool.age[i] - pool.settleAge[i] >= pool.debrisFrames + pool.fadeFrames) {
          pool.alive[i] = 0;
          pool.settled[i] = 0;
          pool.live--;
        }
        continue;
      }
      const airborne = pool.h[i] > 0;
      pool.vh[i] -= GRAV;
      if (pool.vh[i] < -TERM) pool.vh[i] = -TERM;
      if (airborne) {
        pool.vx[i] *= DRAG;
        pool.vy[i] *= DRAG;
        pool.rot[i] += pool.spin[i];
      }
      pool.h[i] += pool.vh[i];
      pool.x[i] += pool.vx[i];
      pool.y[i] += pool.vy[i];
      if (pool.h[i] <= 0) {
        pool.h[i] = 0;
        if (airborne && pool.vh[i] < -BOUNCE_MIN && BOUNCE > 0) {
          pool.vh[i] = -pool.vh[i] * BOUNCE;
        } else {
          pool.vh[i] = 0;
        }
        pool.vx[i] *= FRICT;
        pool.vy[i] *= FRICT;
        if (pool.vh[i] === 0 && Math.abs(pool.vx[i]) + Math.abs(pool.vy[i]) < REST) {
          pool.vx[i] = 0;
          pool.vy[i] = 0;
          pool.rot[i] = Math.round(pool.rot[i]);
          pool.settled[i] = 1;
          pool.settleAge[i] = pool.age[i];
        }
      }
    }
  }

  /** @returns {number} the sherd's rotation in quarter turns, 0..3 */
  function quarter(pool, i) {
    return ((Math.round(pool.rot[i]) % 4) + 4) % 4;
  }

  /** @returns {number} opacity 0..1 (1 in flight and while debris lies, then the fade) */
  function alpha(pool, i) {
    if (!pool.alive[i]) return 0;
    if (!pool.settled[i] || pool.debrisFrames <= 0) return 1;
    const t = pool.age[i] - pool.settleAge[i] - pool.debrisFrames;
    if (t <= 0) return 1;
    return clamp(1 - t / Math.max(1, pool.fadeFrames), 0, 1);
  }

  /** Remove every sherd. */
  function clearPool(pool) {
    pool.alive.fill(0);
    pool.settled.fill(0);
    pool.live = 0;
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Cutting sherds out of the graphic onto one atlas page
  // ---------------------------------------------------------------------------------------------------------------

  /**
   * Opacity mask of one frame inside a bigger sheet (RGBA, row-major).
   * @param {Uint8Array|Uint8ClampedArray} rgba  the whole sheet
   * @param {number} sheetW
   * @param {number} sheetH
   * @param {number} fx    frame left inside the sheet
   * @param {number} fy    frame top inside the sheet
   * @param {number} fw
   * @param {number} fh
   * @param {number} [alphaMin=128]  pixels at or above this alpha are opaque
   * @returns {Uint8Array} fw * fh, 1 = opaque
   */
  function maskFromRGBA(rgba, sheetW, sheetH, fx, fy, fw, fh, alphaMin) {
    const t = Number(alphaMin);
    const th = isFinite(t) ? t : 128;
    const m = new Uint8Array(fw * fh);
    for (let y = 0; y < fh; y++) {
      const sy = fy + y;
      if (sy < 0 || sy >= sheetH) continue;
      for (let x = 0; x < fw; x++) {
        const sx = fx + x;
        if (sx < 0 || sx >= sheetW) continue;
        if (rgba[(sy * sheetW + sx) * 4 + 3] >= th) m[y * fw + x] = 1;
      }
    }
    return m;
  }

  /** A shelf-packed atlas page. @returns {{w:number,h:number,x:number,y:number,rowH:number}} */
  function createPage(w, h) {
    return { w: Math.floor(w), h: Math.floor(h), x: 0, y: 0, rowH: 0 };
  }

  /** Empty a page so it can be reused as a ring. */
  function resetPage(page) {
    page.x = 0;
    page.y = 0;
    page.rowH = 0;
  }

  /**
   * Reserve a w x h rect with `pad` clear pixels around it.
   * @returns {{x:number,y:number}|null} null when the page is full or the rect cannot fit at all (never clipped)
   */
  function place(page, w, h, pad) {
    const p = Math.max(0, Math.floor(Number(pad)) || 0);
    w = Math.floor(w);
    h = Math.floor(h);
    if (!(w > 0 && h > 0) || w + 2 * p > page.w || h + 2 * p > page.h) return null;
    let x = page.x + p, y = page.y + p;
    if (x + w + p > page.w) {
      page.y += page.rowH;
      page.x = 0;
      page.rowH = 0;
      x = p;
      y = page.y + p;
    }
    if (y + h + p > page.h) return null;
    page.x = x + w;
    if (h + p > page.rowH) page.rowH = h + p;
    return { x, y };
  }

  /**
   * Copy every sherd's own pixels from the source frame into its placed rect on the page. Each rect is cleared
   * first, so a reused page never shows a previous break; pixels of other sherds are never written into it.
   * @returns {number} pixels copied
   */
  function cutInto(src, srcW, fx, fy, res, fw, dst, dstW, places) {
    for (let k = 0; k < res.count; k++) {
      const p = res.pieces[k], pl = places[k];
      if (!pl) continue;
      const w = p.maxX - p.minX + 1, h = p.maxY - p.minY + 1;
      for (let y = 0; y < h; y++) {
        const row = ((pl.y + y) * dstW + pl.x) * 4;
        dst.fill(0, row, row + w * 4);
      }
    }
    let n = 0;
    const labels = res.labels;
    for (let i = 0; i < labels.length; i++) {
      const L = labels[i];
      if (L < 0) continue;
      const pl = places[L];
      if (!pl) continue;
      const p = res.pieces[L];
      const x = i % fw, y = (i / fw) | 0;
      const d = ((pl.y + y - p.minY) * dstW + pl.x + x - p.minX) * 4;
      const s = ((fy + y) * srcW + fx + x) * 4;
      dst[d] = src[s];
      dst[d + 1] = src[s + 1];
      dst[d + 2] = src[s + 2];
      dst[d + 3] = src[s + 3];
      n++;
    }
    return n;
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Which events break
  // ---------------------------------------------------------------------------------------------------------------
  // A tag value that is nothing but the word "ceramic" and option tokens (word:value, which the Lite ignores).
  // Anything else - another material, or a typo - is not breakable here: the event stays exactly as drawn.
  const KEEP = /^\s*(?:(?:ceramic|[a-z]+:\S*)(?:\s+|$))*$/i;

  /**
   * @param {*} tag  the event's meta.smash value (true for a bare <smash>, the text after the colon otherwise)
   * @returns {boolean} true when this Lite breaks it
   */
  function tagBreaks(tag) {
    if (tag === undefined || tag === null || tag === false) return false;
    if (typeof tag !== 'string') return true; // a bare <smash>
    return KEEP.test(tag);
  }

  const API = {
    VERSION: '1.0.0',
    MIN_FRAGMENT,
    hash,
    Rng,
    maskInfo,
    fracture,
    detectScale,
    pieces,
    createPool,
    burst,
    step,
    quarter,
    alpha,
    clearPool,
    maskFromRGBA,
    createPage,
    resetPage,
    place,
    cutInto,
    tagBreaks,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  if (typeof Spriteset_Map === 'undefined' || typeof PluginManager === 'undefined') return; // Node: the pure half only

  // ===============================================================================================================
  // The MZ binding
  // ===============================================================================================================
  const NAME = 'CSAF_SmithereensLite';

  /*
   * STANDING ASIDE. The paid Smithereens.js sets CSAF.Smithereens when it loads, and it is the only file that does:
   * SmithereensCore.js and SmithereensCut.js are also shipped by Timber, so their presence proves nothing about
   * Smithereens itself. Smithereens only runs when its two siblings are present too, so all three must be there.
   * Asked at FIRST USE, never at load: the Plugin Manager order is the buyer's choice, and by the time a map or a
   * command runs, every plugin has loaded.
   */
  let _paid = null;
  function paidActive() {
    if (_paid === null) {
      const c = root.CSAF || {};
      _paid = !!(c.Smithereens && typeof c.Smithereens.smash === 'function' && c.SmithereensCore && c.SmithereensCut);
    }
    return _paid;
  }

  // parameters arrive as STRINGS; Number('') is 0 - a blank is the default, never zero
  function num(v, d, lo, hi) {
    if (v === undefined || v === null || String(v).trim() === '') return d;
    const n = Number(v);
    return isFinite(n) ? Math.max(lo, Math.min(hi, n)) : d;
  }
  let _params = null;
  function P() {
    if (_params) return _params;
    const raw = PluginManager.parameters(NAME) || {};
    const ps = String(raw.persistSwitch || 'none');
    _params = {
      debrisSeconds: num(raw.debrisSeconds, 20, 0, 600),
      persist: ['A', 'B', 'C', 'D'].indexOf(ps) >= 0 ? ps : null,
    };
    return _params;
  }

  /** @returns {boolean} true when the event is marked as a pot this Lite breaks */
  function breakable(ev) {
    const data = ev && ev.event ? ev.event() : null;
    return !!(data && data.meta) && tagBreaks(data.meta.smash);
  }

  const POOL_SIZE = 192;
  const PAGE = 1024;
  // Alpha 160, measured for Smithereens: stock object sprites carry a drawn-in drop shadow at alpha 96-159 while object
  // bodies sit at 192-255. At 128 the shadow was cut into black shards. The shadow simply vanishes with the pot.
  const MASK_ALPHA = 160;
  // At most this many pots are CUT per frame; more queue (first in, first out) and keep showing whole until their turn.
  const BREAKS_PER_FRAME = 1;
  // A bounded cache of frames already read, in bytes, because a 96 px object sheet cell costs 4x a 48 px tile.
  const FRAME_CACHE_BYTES = 4 * 1024 * 1024;
  let _sheetSeq = 0;
  const _stats = { breaks: 0, reads: 0 };

  /**
   * The sherd layer: one per map spriteset.
   * @param {Spriteset_Map} spriteset
   * @constructor
   */
  function LiteLayer(spriteset) {
    this._spriteset = spriteset;
    this._pool = createPool(POOL_SIZE);
    this._pool.debrisFrames = Math.round(P().debrisSeconds * 60);
    this._page = createPage(PAGE, PAGE);
    this._atlas = new Bitmap(PAGE, PAGE);
    // a Bitmap is smooth (LINEAR) by default; pixel art is sampled NEAREST, and every sprite sits on whole pixels
    this._atlas.smooth = false;
    this._pixels = null; // the atlas mirror, created on the first break
    this._breaks = 0;
    this._sprites = [];
    // the fractional part of each sherd's centroid inside its frame: the physics tracks the centroid, the sprite is
    // anchored on the whole pixel below it, so the draw subtracts this before rounding (frame 0 = the pot, exactly)
    this._fx = new Float32Array(this._pool.capacity);
    this._fy = new Float32Array(this._pool.capacity);
    for (let i = 0; i < this._pool.capacity; i++) {
      const s = new Sprite(this._atlas);
      s.visible = false;
      s.z = 3;
      this._sprites.push(s);
      spriteset._tilemap.addChild(s);
    }
    this._frameSeen = -1;
    this._budget = BREAKS_PER_FRAME;
    this._queue = [];
    this._scratch = null;
    this._scratchCtx = null;
    this._frames = new Map(); // insertion-ordered: the oldest entry is evicted first
    this._frameBytes = 0;
    this._warmQ = [];         // breakable events whose art has not been read yet
    this._warmSeen = -1;      // how many map events the warm list was built from
    if ($gameMap && $gameMap.events) {
      for (const ev of $gameMap.events()) {
        if (!ev) continue;
        // runtime only, declared non-enumerable (never saved): a loaded game gets a NEW layer with an EMPTY cache
        runtime(ev, '_smlQueued', false);
        runtime(ev, '_smlWarmQ', false);
        if (!ev._erased && breakable(ev)) { runtime(ev, '_smlWarmQ', true); this._warmQ.push(ev); }
      }
      this._warmSeen = $gameMap._events ? $gameMap._events.length : 0;
    }
  }

  /**
   * Read one frame's pixels, its opacity mask and its art scale, through a small scratch canvas, once per graphic.
   * A pixel read is a GPU sync point, so reads happen in the warm pass while a map settles, never during a break.
   * The frame is drawn from the bitmap's own image (`_canvas || _image`, as Bitmap.blt does), never through the
   * `canvas` getter, which builds a canvas copy of the whole sheet (rmmz_core.js:1750).
   * @returns {{img: ImageData, mask: Uint8Array, scale: number, bytes: number}}
   */
  LiteLayer.prototype.readFrame = function (bmp, fx, fy, fw, fh) {
    if (!bmp._smlSheetId) bmp._smlSheetId = 's' + (++_sheetSeq);
    const key = bmp._smlSheetId + ':' + fx + ',' + fy + ',' + fw + ',' + fh;
    const hit = this._frames.get(key);
    if (hit) return hit;
    if (!this._scratch) {
      this._scratch = document.createElement('canvas');
      this._scratch.width = 0;
      this._scratch.height = 0;
    }
    if (this._scratch.width < fw || this._scratch.height < fh) {
      this._scratch.width = Math.max(this._scratch.width, fw);
      this._scratch.height = Math.max(this._scratch.height, fh);
      this._scratchCtx = null; // a resized canvas is a cleared canvas; take its context again
    }
    if (!this._scratchCtx) this._scratchCtx = this._scratch.getContext('2d', { willReadFrequently: true });
    const ctx = this._scratchCtx;
    ctx.clearRect(0, 0, fw, fh);
    ctx.drawImage(bmp._canvas || bmp._image, fx, fy, fw, fh, 0, 0, fw, fh);
    const img = ctx.getImageData(0, 0, fw, fh);
    _stats.reads++;
    const mask = maskFromRGBA(img.data, fw, fh, 0, 0, fw, fh, MASK_ALPHA);
    const entry = { img, mask, scale: detectScale(img.data, fw, fh), bytes: img.data.length + mask.length };
    this._frames.set(key, entry);
    this._frameBytes += entry.bytes;
    while (this._frameBytes > FRAME_CACHE_BYTES && this._frames.size > 1) {
      const oldest = this._frames.keys().next().value;
      this._frameBytes -= this._frames.get(oldest).bytes;
      this._frames.delete(oldest);
    }
    return entry;
  };

  /** Pick up breakable events that did not exist when this layer was built (one length check per frame). */
  LiteLayer.prototype.refillWarm = function () {
    if (!$gameMap._events) return;
    const n = $gameMap._events.length;
    if (n === this._warmSeen) return;
    this._warmSeen = n;
    for (const ev of $gameMap.events()) {
      if (!ev || ev._smlWarmQ || ev._erased || !breakable(ev)) continue;
      runtime(ev, '_smlWarmQ', true);
      this._warmQ.push(ev);
    }
  };

  /**
   * Read ONE not-yet-read pot per frame while the map settles, so the strike never pays for the read. An event whose
   * art has not loaded goes to the BACK of the list rather than blocking the ones behind it.
   * @returns {boolean} true when a frame was read on this call
   */
  LiteLayer.prototype.warmNext = function () {
    let tries = Math.min(4, this._warmQ.length);
    while (tries-- > 0) {
      const ev = this._warmQ.shift();
      if (!ev || ev._erased || !breakable(ev)) continue;
      const spr = spriteOf(this._spriteset, ev);
      const f = spr && spr._frame;
      if (!spr || !spr.bitmap || !spr.bitmap.isReady() || !spr.visible || !(f.width > 0 && f.height > 0)) {
        this._warmQ.push(ev); // its art is still loading: try again later
        continue;
      }
      if (!spr.bitmap._smlSheetId || !this._frames.has(spr.bitmap._smlSheetId + ':' + f.x + ',' + f.y + ',' + f.width + ',' + f.height)) {
        this.readFrame(spr.bitmap, f.x, f.y, f.width, f.height);
        return true; // one read per frame, never a loop over the whole map
      }
    }
    return false;
  };

  /** Read the event's current frame. @returns {{spr, img, mask, fw, fh, scale}|null} */
  LiteLayer.prototype.grab = function (ev) {
    const spr = spriteOf(this._spriteset, ev);
    if (!spr || !spr.bitmap || !spr.bitmap.isReady() || !spr.visible) return null;
    const f = spr._frame;
    let fx = f.x, fy = f.y, fw = f.width, fh = f.height;
    if (fw <= 0 && spr._upperBody && spr._lowerBody) { // bush depth: the body is split in two sprites
      fx = spr._upperBody._frame.x; fy = spr._upperBody._frame.y; fw = spr._upperBody._frame.width;
      fh = spr._upperBody._frame.height + spr._lowerBody._frame.height;
    }
    if (fw <= 0 || fh <= 0) return null;
    const e = this.readFrame(spr.bitmap, fx, fy, fw, fh);
    return { spr, img: e.img, mask: e.mask, fw, fh, scale: e.scale };
  };

  /** Place a fracture on the atlas and launch it. @returns {boolean} */
  LiteLayer.prototype.launch = function (g, res, seed, dx, dy) {
    if (!res.count) return false;
    let places = [];
    for (const p of res.pieces) places.push(place(this._page, p.maxX - p.minX + 1, p.maxY - p.minY + 1, 1));
    if (places.some((q) => !q)) {
      // a full page is recycled together with the debris drawn from it
      clearPool(this._pool);
      resetPage(this._page);
      places = [];
      for (const p of res.pieces) places.push(place(this._page, p.maxX - p.minX + 1, p.maxY - p.minY + 1, 1));
      if (places.some((q) => !q)) return false; // a graphic bigger than the whole page
    }
    if (!this._pixels) this._pixels = new Uint8ClampedArray(PAGE * PAGE * 4);
    cutInto(g.img.data, g.fw, 0, 0, res, g.fw, this._pixels, PAGE, places);
    const ctx = this._atlas.context;
    const whole = new ImageData(this._pixels, PAGE, PAGE);
    for (let k = 0; k < res.count; k++) {
      const p = res.pieces[k], q = places[k];
      ctx.putImageData(whole, 0, 0, q.x, q.y, p.maxX - p.minX + 1, p.maxY - p.minY + 1);
    }
    this._atlas._baseTexture.update();
    // launch: the frame's top-left in MAP pixels, read off the sprite as it is drawn right now
    const spr = g.spr;
    const tw = $gameMap.tileWidth(), th = $gameMap.tileHeight();
    const ox = spr.x + $gameMap.displayX() * tw - g.fw * spr.anchor.x;
    const oy = spr.y + $gameMap.displayY() * th - g.fh * spr.anchor.y;
    const tag = ++this._breaks;
    burst(this._pool, res, seed, { originX: ox, originY: oy, dirX: dx, dirY: dy, tag });
    const pool = this._pool;
    for (let i = 0; i < pool.capacity; i++) {
      if (!pool.alive[i] || pool.tag[i] !== tag || pool.age[i] !== 0) continue;
      const k = pool.piece[i], p = res.pieces[k], q = places[k], s = this._sprites[i];
      const w = p.maxX - p.minX + 1, h = p.maxY - p.minY + 1;
      s.setFrame(q.x, q.y, w, h);
      // the anchor on a WHOLE pixel near the centroid, so a rounded position puts the frame's corner on a whole pixel
      // and a quarter turn about it stays on the grid
      s.anchor.x = Math.floor(p.cx - p.minX) / w;
      s.anchor.y = Math.floor(p.cy - p.minY) / h;
      this._fx[i] = p.cx - p.minX - Math.floor(p.cx - p.minX);
      this._fy[i] = p.cy - p.minY - Math.floor(p.cy - p.minY);
    }
    return true;
  };

  function strikeDir(ev, dirX, dirY) {
    let dx = Number(dirX), dy = Number(dirY);
    if (!isFinite(dx) || !isFinite(dy) || (dx === 0 && dy === 0)) { dx = ev.x - $gamePlayer.x; dy = ev.y - $gamePlayer.y; }
    const dl = Math.sqrt(dx * dx + dy * dy) || 1;
    return { x: dx / dl, y: dy / dl };
  }

  /**
   * Break one pot. Beyond BREAKS_PER_FRAME in one frame the break is queued and happens on a following frame.
   * @returns {string} 'broke', 'queued' or '' (nothing happened)
   */
  LiteLayer.prototype.smash = function (ev, dirX, dirY) {
    if (!breakable(ev) || ev._erased || ev._smlQueued) return '';
    if (this._budget <= 0) {
      runtime(ev, '_smlQueued', true);
      this._queue.push({ ev, dirX, dirY });
      return 'queued';
    }
    this._budget--;
    return this.hit(ev, dirX, dirY);
  };

  /** Drain the queue within this frame's budget, then refill the budget. @returns {number} pots cut this frame */
  LiteLayer.prototype.drain = function () {
    this._budget = BREAKS_PER_FRAME;
    let cut = 0;
    while (this._queue.length && this._budget > 0) {
      const q = this._queue.shift();
      runtime(q.ev, '_smlQueued', false);
      if (!breakable(q.ev) || q.ev._erased) continue;
      this._budget--;
      if (this.hit(q.ev, q.dirX, q.dirY)) cut++;
    }
    return cut;
  };

  LiteLayer.prototype.hit = function (ev, dirX, dirY) {
    const g = this.grab(ev);
    if (!g) return '';
    const d = strikeDir(ev, dirX, dirY);
    const info = maskInfo(g.mask, g.fw, g.fh);
    const impact = { x: info.cx - d.x * g.fw * 0.22, y: info.cy - d.y * g.fh * 0.22 };
    const seed = hash($gameMap.mapId() + ':' + ev.eventId() + ':' + this._breaks);
    const res = fracture(g.mask, g.fw, g.fh, seed, { impact, scale: g.scale });
    if (!this.launch(g, res, seed, d.x, d.y)) return '';
    _stats.breaks++;
    if (P().persist) $gameSelfSwitches.setValue([$gameMap.mapId(), ev.eventId(), P().persist], true);
    else ev.erase();
    return 'broke';
  };

  /** Once per engine frame: step the pool, then place the sprites. Zero allocation. */
  LiteLayer.prototype.update = function () {
    const pool = this._pool;
    const cut = this.drain();
    // read one unread pot per frame while the map settles, never on a frame that is already cutting
    if (!cut && !this._queue.length) {
      this.refillWarm();
      if (this._warmQ.length) this.warmNext();
    }
    if (!pool.live) {
      for (let i = 0; i < this._sprites.length; i++) if (this._sprites[i].visible) this._sprites[i].visible = false;
      return;
    }
    step(pool);
    const tw = $gameMap.tileWidth(), th = $gameMap.tileHeight();
    const sx = $gameMap.displayX() * tw, sy = $gameMap.displayY() * th;
    for (let i = 0; i < pool.capacity; i++) {
      const s = this._sprites[i];
      if (!pool.alive[i]) { if (s.visible) s.visible = false; continue; }
      s.visible = true;
      s.x = Math.round(pool.x[i] - this._fx[i] - sx);
      s.y = Math.round(pool.y[i] - pool.h[i] - this._fy[i] - sy);
      s.rotation = quarter(pool, i) * (Math.PI / 2);
      s.opacity = Math.round(255 * alpha(pool, i));
      s.z = pool.settled[i] ? 1 : 3;
    }
  };

  /** Remove every sherd on this map now. */
  LiteLayer.prototype.clear = function () {
    clearPool(this._pool);
    resetPage(this._page);
  };

  function spriteOf(spriteset, ev) {
    const list = spriteset && spriteset._characterSprites;
    if (!list) return null;
    for (let i = 0; i < list.length; i++) if (list[i]._character === ev) return list[i];
    return null;
  }

  /**
   * A runtime flag on a game event, declared NON-ENUMERABLE so it never rides the save (JsonEx walks Object.keys):
   * a loaded game gets a new layer with an empty cache anyway.
   */
  function runtime(ev, key, value) {
    if (Object.prototype.hasOwnProperty.call(ev, key)) ev[key] = value;
    else Object.defineProperty(ev, key, { value: value, writable: true, enumerable: false, configurable: true });
  }

  function currentLayer() {
    const s = SceneManager._scene;
    return s && s._spriteset && s._spriteset._smlLayer ? s._spriteset._smlLayer : null;
  }

  // every original is SAVED and CALLED
  const _Spriteset_Map_createLowerLayer = Spriteset_Map.prototype.createLowerLayer;
  Spriteset_Map.prototype.createLowerLayer = function () {
    _Spriteset_Map_createLowerLayer.call(this);
    if (this._smlLayer || !this._tilemap || paidActive()) return; // Smithereens installed: it draws every break
    this._smlLayer = new LiteLayer(this);
  };

  const _Spriteset_Map_update = Spriteset_Map.prototype.update;
  Spriteset_Map.prototype.update = function () {
    _Spriteset_Map_update.call(this);
    const L = this._smlLayer;
    if (L && L._frameSeen !== Graphics.frameCount) {
      L._frameSeen = Graphics.frameCount;
      L.update();
    }
  };

  /**
   * Break an event marked <smash>. With Smithereens installed, the hit is handed to it (it then breaks any material).
   * @param {number} eventId
   * @returns {string} 'broke', 'queued' or ''
   */
  function smash(eventId) {
    const ev = $gameMap.event(Math.round(Number(eventId)));
    if (!ev) return '';
    if (paidActive()) return root.CSAF.Smithereens.smash(ev.eventId(), {}) || '';
    const L = currentLayer();
    return L ? L.smash(ev, NaN, NaN) : '';
  }

  PluginManager.registerCommand(NAME, 'smash', function (a) {
    // compare against zero: "0" is truthy as a string
    const n = Math.round(Number(a.eventId));
    const eid = isFinite(n) && n > 0 ? n : this.eventId ? this.eventId() : 0;
    if (eid > 0) smash(eid);
  });

  CSAF.SmithereensLite = {
    version: '1.0.0',
    smash,
    /** @returns {boolean} true when the paid Smithereens is installed and this Lite stands aside */
    standingAside: () => paidActive(),
    /** @returns {{breaks:number, reads:number, live:number, cached:number}} read only */
    stats: () => {
      const L = currentLayer();
      return { breaks: _stats.breaks, reads: _stats.reads, live: L ? L._pool.live : 0, cached: L ? L._frames.size : 0 };
    },
    layer: currentLayer,
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
