/*:
 * @target MZ
 * @plugindesc [v1.0.0] Threshold Lite (free): a door tile from your own tileset swings open when its door event turns.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io/
 *
 * @help CSAF_ThresholdLite.js
 *
 * The free door of Threshold. One door, drawn from YOUR tileset: no door sprite sheet.
 *
 * HOW TO MARK A DOOR
 *   1. Make an event and give it a TILE as its graphic (the door tile from your own tileset, in the B to E tabs).
 *   2. Put this in the event's Note box:   <threshold: door>
 *   When the map loads, the plugin reads that tile's pixels once and builds every frame of a hinged door
 *   swinging inward from it: the leaf foreshortens, its edge shows in the door's own darkest colour, and the
 *   doorway behind it is darkness drawn from the door's own colours. Closed, it shows your tile exactly.
 *
 *   A door two tiles tall (MZ's own wall doors sit across two tiles): mark both tiles, the top one above the
 *   bottom one, each with <threshold: door>. They open as one door, whichever of the two events turns.
 *
 * OPENING IT: YOUR EXISTING DOOR EVENTS ALREADY WORK
 *   The stock MZ door event opens by turning the event: Turn Left, Turn Right, Turn Up with a short wait between
 *   (the Quick Event "Door" makes exactly this). The plugin reads those four directions as the four stages of the
 *   swing (down = closed, left = 1/3, right = 2/3, up = open). A page whose graphic faces up shows the door open.
 *
 * WHAT THE FREE VERSION DOES NOT DO
 *   It opens ONE kind of door: hinged on the left, one tile wide, one or two tiles tall. A note it does not know
 *   leaves the event exactly as stock MZ draws it, so a wrong word never draws a wrong door. That includes
 *   <threshold: door right> and any other shape of marked doors (two side by side, a column of three): those are
 *   all left alone rather than opening half a door.
 *
 *   Threshold (https://csaf.itch.io/threshold) opens seven more kinds from your own tiles: double doors that
 *   part, a portcullis that rises in steps, a floor hatch that lifts and casts its shadow, a shoji that slides,
 *   a curtain that parts, a vault door that rolls aside and a cave mouth that breathes cold air. It also hinges
 *   on the right, opens doors of any size as one, sheds dust from old doors, fills open doorways with warm light
 *   at night, and adds Open, Close and Toggle Door commands with a sound per kind.
 *
 * UPGRADING
 *   Threshold reads the same <threshold: door> note. When Threshold is installed this file steps aside on its
 *   own, so you can leave it in or switch it off: no event changes. A door's open state is saved in the field
 *   Threshold uses, so saves carry over too.
 *
 * Compatibility: replaces no engine method. It extends Game_Event.prototype.setupPageSettings,
 * Game_Event.prototype.update, Sprite_Character.prototype.updateBitmap, Sprite_Character.prototype.updateFrame,
 * Spriteset_Map.prototype.createCharacters and Spriteset_Map.prototype.update (the original always runs).
 *
 * Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.
 *
 * @param stageFrames
 * @text Stage glide
 * @type number
 * @min 1
 * @max 30
 * @default 3
 * @desc Frames to glide from one direction stage to the next when a door event turns (the stock door waits 3).
 */
(function (root) {
  'use strict';
  var NAME = 'CSAF_ThresholdLite';
  var VERSION = '1.0.0';

  // ── the rules half: pure, no engine code. A cut of ThresholdCore.js (Threshold v1.0.0), the `door` kind only. ──
  /*
   * Every pixel of the moving leaf is a COPY of one of your door's own pixels (whole pixel nearest neighbour), so a
   * 48 px door stays crisp at every step of its swing. The only colours that are not your pixels are derived from
   * your pixels: the leaf's own darkest colour (its thickness edge) and the four bands of darkness behind it.
   */
  var STAGE_OF_DIRECTION = { 2: 0, 4: 1 / 3, 6: 2 / 3, 8: 1 };
  var MAX_SWING_DEG = 78;
  var OPEN_STEPS = 12;     // 13 frames, 0/12 .. 12/12, so the four stock stages land exactly on 0, 4, 8, 12

  function clamp(x, a, b) { return x < a ? a : x > b ? b : x; }
  function lum(r, g, b) { return 0.2126 * r + 0.7152 * g + 0.0722 * b; }

  /**
   * Read a `<threshold: ...>` note value. The free version keeps one kind: `door`, hinged on the left.
   * @param {string|boolean} value  the meta value; `true` when the tag had no value
   * @returns {{kind:string}|null}  null for every other kind and for `right` (the event stays stock)
   */
  function parseNote(value) {
    var words = (value === true || value == null ? 'door' : String(value)).toLowerCase().split(/[\s,]+/).filter(Boolean);
    var kind = words[0] || 'door';
    if (kind !== 'door') return null;
    if (words.indexOf('right') >= 0) return null;
    return { kind: 'door' };
  }

  /** @returns {number} the opening stage (0..1) a stock door event's direction stands for */
  function stageOfDirection(d) { return STAGE_OF_DIRECTION[d] != null ? STAGE_OF_DIRECTION[d] : 0; }

  /**
   * The derived palette of one door image: its darkest opaque colour and the bands of darkness behind it.
   * @param {Uint8ClampedArray|number[]} d RGBA @param {number} w @param {number} h
   */
  function analyse(d, w, h) {
    var dark = null, darkL = 1e9, n = 0;
    var bbox = { x0: w, y0: h, x1: 0, y1: 0 };
    for (var i = 0; i < w * h; i++) {
      var a = d[i * 4 + 3];
      if (a < 128) continue;
      var px = i % w, py = Math.floor(i / w);
      if (px < bbox.x0) bbox.x0 = px; if (py < bbox.y0) bbox.y0 = py; if (px + 1 > bbox.x1) bbox.x1 = px + 1; if (py + 1 > bbox.y1) bbox.y1 = py + 1;
      var r = d[i * 4], g = d[i * 4 + 1], b = d[i * 4 + 2], L = lum(r, g, b);
      n++;
      if (L < darkL) { darkL = L; dark = [r, g, b]; }
    }
    if (!n) return { empty: true, opaque: 0, dark: [0, 0, 0], interior: [[8, 7, 10, 255]] };
    var interior = [];
    for (var k = 0; k < 4; k++) {
      var f = 0.16 + k * 0.07;
      interior.push([Math.round(dark[0] * f + 4), Math.round(dark[1] * f + 3), Math.round(dark[2] * f + 6), 255]);
    }
    return { empty: false, opaque: n, bbox: bbox, dark: dark, interior: interior };
  }

  /**
   * How see-through a door is: the share of each row's span, between its first and last SOLID pixel, that is
   * transparent. Bars and grilles drawn over nothing are full of such holes; leaves, arches and panels are not.
   * @returns {number} 0..1
   */
  function holeFraction(d, w, h) {
    var holes = 0, span = 0;
    for (var y = 0; y < h; y++) {
      var a = -1, b = -1;
      for (var x = 0; x < w; x++) if (d[(y * w + x) * 4 + 3] >= 128) { if (a < 0) a = x; b = x; }
      if (a < 0) continue;
      span += b - a + 1;
      for (var x2 = a; x2 <= b; x2++) if (d[(y * w + x2) * 4 + 3] < 128) holes++;
    }
    return span ? holes / span : 0;
  }
  // Threshold's measured bar (30 solid doors read 0 to 0.02; see-through cell bars 0.229 and 0.251)
  var SEE_THROUGH = 0.1;

  function newFrame(w, h) { return { data: new Uint8ClampedArray(w * h * 4), mask: new Uint8Array(w * h), w: w, h: h }; }
  function put(f, x, y, r, g, b, a) { if (x < 0 || y < 0 || x >= f.w || y >= f.h) return; var i = (y * f.w + x) * 4; f.data[i] = r; f.data[i + 1] = g; f.data[i + 2] = b; f.data[i + 3] = a; }
  function copyPx(f, x, y, s, sx, sy, sw) { if (x < 0 || y < 0 || x >= f.w || y >= f.h) return; var i = (y * f.w + x) * 4, j = (sy * sw + sx) * 4; if (s[j + 3] === 0) return; f.data[i] = s[j]; f.data[i + 1] = s[j + 1]; f.data[i + 2] = s[j + 2]; f.data[i + 3] = s[j + 3]; }

  /** Fill the opening with the interior bands and mark it in the mask. */
  function fillInterior(f, A, x0, x1, y0, y1) {
    var H = y1 - y0;
    for (var y = y0; y < y1; y++) {
      var band = A.interior[Math.min(3, Math.floor(4 * (y - y0) / Math.max(1, H)))];
      for (var x = x0; x < x1; x++) { put(f, x, y, band[0], band[1], band[2], 255); f.mask[y * f.w + x] = 1; }
    }
  }

  /**
   * A hinged leaf swinging INTO the doorway, hinged on the left: it foreshortens to cos(angle) of its width
   * (nearest columns), its free edge shrinks toward the middle as it moves away, and its thickness appears as a
   * strip in the leaf's own darkest colour.
   */
  function swingLeaf(f, src, sw, sh, t, A) {
    var ang = t * MAX_SWING_DEG * Math.PI / 180;
    var leafW = Math.max(1, Math.round(sw * Math.cos(ang)));
    if (t >= 1) leafW = Math.max(1, Math.round(sw * 0.12));
    var edge = Math.round(3 * Math.sin(ang) * (sw / 48 > 0.5 ? sw / 48 : 0.5));
    var shrink = 0.16 * Math.sin(ang);
    var cy = (sh - 1) / 2;
    for (var c = 0; c < leafW + edge; c++) {
      var u = c / Math.max(1, leafW);
      var s = 1 - shrink * Math.min(1, u);
      for (var y = 0; y < sh; y++) {
        var yy = Math.round(cy + (y - cy) / s);
        if (yy < 0 || yy >= sh) continue;
        if (c < leafW) {
          copyPx(f, c, y, src, Math.min(sw - 1, Math.floor(c * sw / leafW)), yy, sw);
          f.mask[y * f.w + c] = 0;
        } else {
          put(f, c, y, A.dark[0], A.dark[1], A.dark[2], 255);
          f.mask[y * f.w + c] = 0;
        }
      }
    }
  }

  /**
   * THE ENTRY POINT of the rules half. The pixels of a door tile at one point of its swing.
   * @param {{data:Uint8ClampedArray|number[], w:number, h:number}} src  the door tile
   * @param {number} t  0 closed .. 1 fully open
   * @param {object} [A] a precomputed analyse() of src
   * @returns {{data:Uint8ClampedArray, mask:Uint8Array, w:number, h:number}}  mask = 1 where the doorway shows
   */
  function frame(src, t, A) {
    var w = src.w, h = src.h;
    if (!(w > 0 && h > 0) || src.data.length !== w * h * 4) throw new Error('ThresholdLite.frame: ' + w + 'x' + h + ' does not match ' + src.data.length + ' bytes');
    t = clamp(Number(t) || 0, 0, 1);
    A = A || analyse(src.data, w, h);
    var f = newFrame(w, h);
    if (A.empty) return f;
    if (t === 0) {                                   // closed is EXACTLY your tile, byte for byte
      for (var i = 0; i < src.data.length; i++) f.data[i] = src.data[i];
      return f;
    }
    // the door, not the cell: work on the opaque bounding box, and draw the doorway only inside the door's own solid outline
    var bb = A.bbox, bw = bb.x1 - bb.x0, bh = bb.y1 - bb.y0;
    var sub = new Uint8ClampedArray(bw * bh * 4);
    for (var yy = 0; yy < bh; yy++) for (var xx = 0; xx < bw; xx++) for (var c = 0; c < 4; c++) sub[(yy * bw + xx) * 4 + c] = src.data[((yy + bb.y0) * w + xx + bb.x0) * 4 + c];
    var sf = newFrame(bw, bh);
    var SA = analyse(sub, bw, bh);
    fillInterior(sf, SA, 0, bw, 0, bh);
    swingLeaf(sf, sub, bw, bh, t, SA);
    f.derived = [SA.dark].concat(SA.interior.map(function (q) { return q.slice(0, 3); }));
    // a SEE-THROUGH door (bars or a grille drawn over nothing) leaves transparency where it moves away, never a dark
    // ghost of its own bars
    var see = holeFraction(sub, bw, bh) >= SEE_THROUGH;
    f.seeThrough = see;
    for (var y2 = 0; y2 < bh; y2++) for (var x2 = 0; x2 < bw; x2++) {
      var si = y2 * bw + x2, di = (y2 + bb.y0) * w + x2 + bb.x0;
      if (sf.mask[si] && (see || sub[si * 4 + 3] < 128)) continue;
      if (sf.data[si * 4 + 3] === 0) continue;
      for (var c2 = 0; c2 < 4; c2++) f.data[di * 4 + c2] = sf.data[si * 4 + c2];
      f.mask[di] = sf.mask[si];
    }
    return f;
  }

  var RULES = { parseNote: parseNote, stageOfDirection: stageOfDirection, analyse: analyse, frame: frame, OPEN_STEPS: OPEN_STEPS, STAGE_OF_DIRECTION: STAGE_OF_DIRECTION };

  // Node (the headless suite) gets the rules and nothing else.
  if (typeof module !== 'undefined' && module.exports && typeof PluginManager === 'undefined') { module.exports = RULES; return; }

  // ── the engine half ────────────────────────────────────────────────────────────────────────────────
  var RAW = PluginManager.parameters(NAME);
  // parameters arrive as STRINGS and Number('') is 0: a blank is the default, never zero
  function num(v, d, lo, hi) { if (v === undefined || v === null || String(v).trim() === '') return d; var n = Number(v); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d; }
  var P = { stageFrames: num(RAW.stageFrames, 3, 1, 30) };

  /*
   * STEP ASIDE FOR THE PAID PLUGIN. Threshold.js sets window.Threshold when it loads; this file never does. Asked at
   * FIRST USE (a map), never at load, because the order of the two files in the Plugin Manager is the buyer's choice.
   */
  var _paid = null;
  function paid() { if (_paid === null && typeof $gameMap !== 'undefined' && $gameMap) _paid = !!(root.Threshold && root.Threshold.version); return _paid === true; }

  /**
   * The door spec of an event's CURRENT page, or null. The free version opens a door of ONE tile, or of one tile wide
   * and two tall (MZ's own wall doors are drawn across two tiles: mark both, the top above the bottom, and they open
   * as one). Any other shape of marked doors (side by side, a column of three) is left alone, never half opened.
   * @returns {{kind:string, rows:number, row:number, top:number, mate:number}|null}
   */
  // bumped whenever a marked event sets up a page: a neighbour's page (and so its tile) decides this door's shape
  var specGen = 0;
  function specOf(ev) {
    if (!Object.prototype.hasOwnProperty.call(ev, '_thlSpecCache')) hideRuntimeSlots(ev);
    if (ev._thlSpecPage === ev._pageIndex && ev._thlSpecTile === ev.tileId() && ev._thlSpecMap === $gameMap.mapId() && ev._thlSpecGen === specGen) return ev._thlSpecCache || null;
    ev._thlSpecPage = ev._pageIndex; ev._thlSpecTile = ev.tileId(); ev._thlSpecMap = $gameMap.mapId(); ev._thlSpecGen = specGen;
    var tag = markOf(ev);
    var sp = (tag !== undefined && ev.tileId() > 0 && ev._pageIndex >= 0) ? parseNote(tag) : null;
    if (sp) sp = shapeOf(ev.event(), sp);
    ev._thlSpecCache = sp;
    return sp;
  }
  function markOf(ev) { var d = ev.event(); return d && d.meta ? d.meta.threshold : undefined; }
  /** Would Threshold join this door to a neighbour? Two `door` marks side by side or stacked, neither `nogroup`. */
  function joins(tag) {
    var words = (tag === true || tag == null ? 'door' : String(tag)).toLowerCase().split(/[\s,]+/).filter(Boolean);
    return (words[0] || 'door') === 'door' && words.indexOf('nogroup') < 0;
  }
  /*
   * Read from the MAP DATA, never from $gameMap's events: a page is set up while Game_Map builds its events one by one,
   * so a neighbour with a higher id does not exist yet (measured: the lower half of a stacked pair opened alone).
   */
  /**
   * Is this data event a door tile right now? Its live event's current page decides (a marked event showing a
   * character is no door, as in Threshold); while Game_Map is still building events and it does not exist yet, any
   * page with a tile counts, and the spec is asked again once every page is set up (specGen).
   */
  function isTileDoor(o) {
    var live = $gameMap && $gameMap._events ? $gameMap._events[o.id] : null;
    if (live) return live._pageIndex >= 0 && live.tileId() > 0;
    for (var i = 0; o.pages && i < o.pages.length; i++) if (o.pages[i] && o.pages[i].image && o.pages[i].image.tileId > 0) return true;
    return false;
  }
  function neighbours(me) {
    var out = { up: null, down: null, side: 0 }, list = $dataMap && $dataMap.events;
    if (!list || !me.meta || !joins(me.meta.threshold)) return out;
    for (var i = 0; i < list.length; i++) {
      var o = list[i];
      if (!o || o === me || !o.meta || o.meta.threshold === undefined || !joins(o.meta.threshold) || !isTileDoor(o)) continue;
      var dx = o.x - me.x, dy = o.y - me.y;
      if (dx === 0 && dy === -1) out.up = o; else if (dx === 0 && dy === 1) out.down = o; else if (Math.abs(dx) + Math.abs(dy) === 1) out.side++;
    }
    return out;
  }
  function shapeOf(me, sp) {
    if (!me) return null;
    var n = neighbours(me);
    if (n.side || (n.up && n.down)) return null;
    var mate = n.up || n.down;
    if (!mate) return { kind: sp.kind, rows: 1, row: 0, top: me.id, mate: 0 };
    var m = neighbours(mate);
    if (m.side || (m.up && m.down) || !parseNote(mate.meta.threshold)) return null;   // a column of three, or a mate the free version cannot open
    return { kind: sp.kind, rows: 2, row: n.up ? 1 : 0, top: n.up ? mate.id : me.id, mate: mate.id };
  }
  /**
   * The spec cache is runtime only and must never reach a save: non-enumerable on the INSTANCE, because JsonEx walks
   * Object.keys. The door's state (_thrP, _thrTarget, _thrRate, _thrDir) IS saved, in the fields Threshold uses.
   */
  function hideRuntimeSlots(ev) {
    var keys = ['_thlSpecCache', '_thlSpecPage', '_thlSpecTile', '_thlSpecMap', '_thlSpecGen', '_thlPrevP', '_thlStepAt'];
    for (var i = 0; i < keys.length; i++) Object.defineProperty(ev, keys[i], { value: undefined, writable: true, enumerable: false, configurable: true });
  }
  function progressOf(ev) { return Number(ev._thrP) || 0; }

  var _setupPageSettings = Game_Event.prototype.setupPageSettings;
  Game_Event.prototype.setupPageSettings = function () {
    _setupPageSettings.call(this);
    if (paid()) return;
    if (markOf(this) !== undefined) specGen++;
    if (specOf(this)) {
      // a page shows its door at the stage its graphic's direction says, at once (a page that faces up is open)
      this._thrP = this._thrTarget = stageOfDirection(this.direction());
      this._thrRate = 0;
      this._thrDir = this.direction();
    }
  };

  var _update = Game_Event.prototype.update;
  Game_Event.prototype.update = function () {
    _update.call(this);
    if (paid()) return;
    var sp = specOf(this);
    if (!sp) return;
    var d = this.direction();
    if (d !== this._thrDir) {
      // the stock door protocol: a turn is a stage; glide to it over stageFrames. A two tile door moves as one: the
      // half that turned sets the other half's target too.
      this._thrDir = d;
      setTarget(this, stageOfDirection(d), (1 / 3) / P.stageFrames);
      var mate = sp.mate ? $gameMap.event(sp.mate) : null;
      if (mate && specOf(mate)) {
        setTarget(mate, this._thrTarget, this._thrRate);
        // the other half may already have taken this frame's step toward the OLD target (events update in id order):
        // redo it from where it began, so both halves show the same frame
        if (mate._thlStepAt === Graphics.frameCount) { mate._thrP = mate._thlPrevP; stepProgress(mate); }
      }
    }
    this._thlPrevP = progressOf(this);
    this._thlStepAt = Graphics.frameCount;
    stepProgress(this);
  };
  function setTarget(ev, target, rate) { ev._thrTarget = target; ev._thrRate = rate; }
  /** One frame of glide toward the target. */
  function stepProgress(ev) {
    var p = progressOf(ev), t = Number(ev._thrTarget) || 0, r = Number(ev._thrRate) || 0;
    if (p !== t) ev._thrP = r > 0 ? (p < t ? Math.min(t, p + r) : Math.max(t, p - r)) : t;
  }

  // ── the frames: built once per door tile per map, one per frame while the map settles, never during play ──
  /*
   * A pixel read is a GPU sync point, so each door tile is read ONCE, through a small scratch canvas, and every frame
   * of its swing is computed then. Opening a door afterwards only moves a frame rectangle: no reads, no allocation.
   */
  var Frames = {
    byKey: new Map(), pending: [], scratch: null, sctx: null, built: 0, reads: 0, gen: 0,
    reset: function () {
      this.byKey.forEach(function (e) { if (e.bitmap) e.bitmap.destroy(); });
      this.byKey = new Map(); this.pending = []; this.gen++;
    },
    /**
     * The entry of one door (its tile, or its top and bottom tiles) on this map and tileset. Called on a sprite's cache
     * MISS only (see doorEntry).
     */
    want: function (ev, sp) {
      var tiles = doorTiles(ev, sp);
      var k = $gameMap.mapId() + '@' + $gameMap.tilesetId() + ':' + tiles.join(',');
      var e = this.byKey.get(k);
      if (!e) { e = { state: 'pending', tiles: tiles, tilesetId: $gameMap.tilesetId(), gen: this.gen, key: k }; this.byKey.set(k, e); this.pending.push(k); }
      return e;
    },
    /** Build at most ONE pending door this frame. */
    step: function () {
      for (var i = 0; i < this.pending.length; i++) {
        var e = this.byKey.get(this.pending[i]);
        if (!e || e.state !== 'pending') { this.pending.splice(i--, 1); continue; }
        var ready = true;
        for (var t = 0; t < e.tiles.length; t++) { var b = tilesetBitmapOf(e.tiles[t]); if (!b || !b.isReady()) ready = false; }
        if (!ready) continue;
        this.pending.splice(i, 1);
        this.build(e);
        return true;
      }
      return false;
    },
    build: function (e) {
      var tw = $gameMap.tileWidth(), th = $gameMap.tileHeight(), rows = e.tiles.length, W = tw, H = th * rows;
      if (!this.scratch) { this.scratch = document.createElement('canvas'); this.scratch.width = 0; this.scratch.height = 0; }
      if (this.scratch.width < W || this.scratch.height < H) { this.scratch.width = Math.max(this.scratch.width, W); this.scratch.height = Math.max(this.scratch.height, H); this.sctx = null; }
      if (!this.sctx) this.sctx = this.scratch.getContext('2d', { willReadFrequently: true });
      var ctx = this.sctx;
      ctx.clearRect(0, 0, W, H);
      for (var r = 0; r < rows; r++) {
        var tid = e.tiles[r], b = tilesetBitmapOf(tid);
        var sx = ((Math.floor(tid / 128) % 2) * 8 + (tid % 8)) * tw, sy = (Math.floor((tid % 256) / 8) % 16) * th;
        // read the tileset's own image, exactly as Bitmap.blt does (rmmz_core.js:1502). Never `b.canvas`: that getter
        // builds a canvas COPY of the shared tileset and swaps its texture onto it (rmmz_core.js:1750).
        ctx.drawImage(b._canvas || b._image, sx, sy, tw, th, 0, r * th, tw, th);
      }
      var img = ctx.getImageData(0, 0, W, H);
      this.reads++;
      var src = { data: img.data, w: W, h: H }, A = analyse(src.data, W, H), N = OPEN_STEPS + 1;
      var bmp = new Bitmap(W * N, H);
      for (var n = 0; n < N; n++) {
        var f = frame(src, n / OPEN_STEPS, A);
        bmp.context.putImageData(new ImageData(f.data, W, H), n * W, 0);
      }
      bmp.baseTexture.update();
      e.bitmap = bmp; e.tw = tw; e.th = th; e.state = 'ready';
      this.built++;
    },
  };
  /** The tile ids of a door, top first: the event's own tile, or the top and bottom tiles of a two tile door. */
  function doorTiles(ev, sp) {
    if (sp.rows === 1) return [ev.tileId()];
    var mate = $gameMap.event(sp.mate), mt = mate ? mate.tileId() : 0;
    return sp.row === 0 ? [ev.tileId(), mt] : [mt, ev.tileId()];
  }
  function tilesetBitmapOf(tileId) {
    var ts = $gameMap.tileset();
    var name = ts ? ts.tilesetNames[5 + Math.floor(tileId / 256)] : '';
    return name ? ImageManager.loadTileset(name) : null;
  }

  var _createCharacters = Spriteset_Map.prototype.createCharacters;
  Spriteset_Map.prototype.createCharacters = function () {
    Frames.reset();
    _createCharacters.call(this);
  };
  var _spritesetUpdate = Spriteset_Map.prototype.update;
  Spriteset_Map.prototype.update = function () {
    // build BEFORE the sprites update, so a door built this frame is shown this frame
    if (!paid()) Frames.step();
    _spritesetUpdate.call(this);
  };

  // ── the sprite ─────────────────────────────────────────────────────────────────────────────────────
  /**
   * The door entry a sprite shows, or null. Asked every frame by every character sprite, so the hit path compares
   * numbers and allocates nothing; the keyed lookup runs only when the sprite's tile, tileset or map changed.
   */
  function doorEntry(spr) {
    var ch = spr._character;
    if (paid() || !(ch instanceof Game_Event)) return null;
    var sp = specOf(ch);
    if (!sp) return null;
    var c = spr._thlCache;
    if (c && c.gen === Frames.gen && c.tilesetId === $gameMap.tilesetId() && c.tiles[sp.row] === ch.tileId() && c.tiles.length === sp.rows) return c;
    c = Frames.want(ch, sp);
    spr._thlCache = c;
    return c;
  }

  var _updateBitmap = Sprite_Character.prototype.updateBitmap;
  Sprite_Character.prototype.updateBitmap = function () {
    var e = doorEntry(this);
    if (e && e.state === 'ready') {
      if (this.bitmap !== e.bitmap) {
        this.bitmap = e.bitmap;
        this._thlEntry = e;
        // the stock tracking fields, so the stock path does not swap the tile back next frame
        this._tilesetId = $gameMap.tilesetId(); this._tileId = this._character.tileId();
        this._characterName = this._character.characterName(); this._characterIndex = this._character.characterIndex();
      }
      return;
    }
    if (this._thlEntry) { this._thlEntry = null; this._tileId = -1; }   // left the lite: let the stock path redraw
    _updateBitmap.call(this);
  };

  var _updateFrame = Sprite_Character.prototype.updateFrame;
  Sprite_Character.prototype.updateFrame = function () {
    var e = this._thlEntry;
    if (!e || e.state !== 'ready' || this.bitmap !== e.bitmap) return _updateFrame.call(this);
    var sp = specOf(this._character);
    var n = Math.round(progressOf(this._character) * OPEN_STEPS);
    this.setFrame(n * e.tw, (sp ? sp.row : 0) * e.th, e.tw, e.th);
  };

  // a test and support seam, read only. Deliberately NOT window.Threshold: that name means the paid plugin is here.
  root.CSAF_ThresholdLite = {
    version: VERSION,
    rules: RULES,
    steppedAside: function () { return paid(); },
    stats: function () { return { built: Frames.built, reads: Frames.reads, pending: Frames.pending.length }; },
  };
})(typeof window !== 'undefined' ? window : globalThis);
