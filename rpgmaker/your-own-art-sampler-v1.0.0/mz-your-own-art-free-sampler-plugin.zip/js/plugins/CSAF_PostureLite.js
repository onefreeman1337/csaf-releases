//=============================================================================
// CSAF_PostureLite.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Posture Lite (free): your characters sit on chairs and
 * benches, the seated pose made from the walking sheet they already have.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io/
 *
 * @param seatLift
 * @text Seat height
 * @type number
 * @min 0
 * @max 24
 * @desc Pixels a seated character is raised, so the body rests on the seat. 0 = on the floor.
 * @default 6
 *
 * @param standOnMove
 * @text Stand up on move
 * @type boolean
 * @on Stand up
 * @off Keep the pose
 * @desc When a seated character takes a step, they stand and walk normally.
 * @default true
 *
 * @help
 * POSTURE LITE - the free sit pose of Posture, for RPG Maker MZ.
 *
 * Your characters sit on chairs and benches, and the seated pose is made from
 * the walking sheet each character already has. No new art, no pose sheets.
 * The first time a character sits, this plugin reads that character's
 * standing frames and builds the seated frame from the same pixels: whole
 * pixels moved, never resampled or blended, so the pose keeps the sheet's own
 * outline and colours. Your image files are never changed.
 *
 * INSTALL: copy CSAF_PostureLite.js into js/plugins and turn it ON in the
 * Plugin Manager. It needs no other plugin.
 *
 * MAKE A CHARACTER SIT
 *   Event Note box:              <pose: sit>   the event sits
 *   Comment on an event page:    <pose: sit>   it sits while that page is
 *                                              active; a page without one
 *                                              uses the Note box
 * Put the event on the chair or bench tile. Its facing picks the frame (four
 * facings). "Seat height" raises a seated character onto the seat.
 * "Stand up on move": a seated character who takes a step stands up.
 * Any other pose word is ignored and the event is drawn exactly as stock MZ
 * draws it. The pose is saved with the game.
 *
 * THE FULL PLUGIN
 * This is one pose of Posture (https://csaf.itch.io/posture), which adds
 * eight more from the same sheets: sitfloor, kneel, read, lie, sleep,
 * collapsed, wave and cheer, plus chair and bed regions that pose a character
 * on their own and plugin commands to pose the player or any event.
 * Upgrading changes nothing in your events: Posture reads the same <pose: sit>
 * tags and the same saved pose. When Posture is installed, this file stands
 * aside by itself, so you can leave it on or remove it.
 *
 * Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.
 * Free for commercial and non-commercial RPG Maker projects. Written with AI
 * assistance.
 */

(function () {
  'use strict';

  var root = typeof window !== 'undefined' ? window : globalThis;
  var VERSION = '1.0.0';

  // ===========================================================================================================
  // THE PIXEL RULES (pure: RGBA arrays in, RGBA arrays out; nothing here touches the screen). This is Posture's
  // own seated-pose path, cut out of PostureCore.js unchanged, so a seated frame is the same pixels Posture makes.
  // ===========================================================================================================

  var ALPHA = 16;            // a pixel with alpha above this is part of the figure
  var DIRS = [2, 4, 6, 8];   // sheet rows: down, left, right, up (MZ: characterPatternY = (direction - 2) / 2)

  /** MZ's ImageManager.isBigCharacter: a '$' among the leading '!'/'$' marks makes a one-character sheet. */
  function isBig(name) { var m = /^[!$]+/.exec(String(name || '')); return !!(m && m[0].indexOf('$') >= 0); }

  /**
   * Cell size and the character's block origin, as Sprite_Character.patternWidth/characterBlockX compute them.
   * @param {number} w sheet width @param {number} h sheet height @param {string} name file name @param {number} index
   * @returns {{big:boolean, cw:number, ch:number, bx:number, by:number}}
   */
  function layout(w, h, name, index) {
    var big = isBig(name), cw = Math.floor(big ? w / 3 : w / 12), ch = Math.floor(big ? h / 4 : h / 8), i = big ? 0 : (Number(index) || 0) & 7;
    return { big: big, cw: cw, ch: ch, bx: big ? 0 : (i % 4) * 3, by: big ? 0 : Math.floor(i / 4) * 4 };
  }

  // ---- a cell: a small RGBA grid ---------------------------------------------------------------------------------
  function Cell(w, h) { this.w = w; this.h = h; this.d = new Uint8ClampedArray(w * h * 4); }
  Cell.prototype.a = function (x, y) { return x < 0 || y < 0 || x >= this.w || y >= this.h ? 0 : this.d[(y * this.w + x) * 4 + 3]; };
  Cell.prototype.on = function (x, y) { return this.a(x, y) > ALPHA; };
  /** copy one pixel from another cell (whole pixel, every channel) */
  Cell.prototype.put = function (x, y, src, sx, sy) {
    if (x < 0 || y < 0 || x >= this.w || y >= this.h || !src.on(sx, sy)) return;
    var o = (y * this.w + x) * 4, i = (sy * src.w + sx) * 4;
    this.d[o] = src.d[i]; this.d[o + 1] = src.d[i + 1]; this.d[o + 2] = src.d[i + 2]; this.d[o + 3] = src.d[i + 3];
  };
  Cell.prototype.paint = function (x, y, c) {
    if (x < 0 || y < 0 || x >= this.w || y >= this.h) return;
    var o = (y * this.w + x) * 4; this.d[o] = c[0]; this.d[o + 1] = c[1]; this.d[o + 2] = c[2]; this.d[o + 3] = c[3];
  };
  /** copy source rows [r0, r1] to this cell, shifted by (dx, dy) */
  Cell.prototype.rows = function (src, r0, r1, dx, dy) { for (var y = r0; y <= r1; y++) for (var x = 0; x < src.w; x++) this.put(x + dx, y + dy, src, x, y); };

  /** one frame of a sheet as a Cell (dir 2/4/6/8, pattern 0..2) */
  function frameOf(img, L, dir, pattern) {
    var c = new Cell(L.cw, L.ch), row = L.by + DIRS.indexOf(dir), col = L.bx + pattern;
    for (var y = 0; y < L.ch; y++) for (var x = 0; x < L.cw; x++) {
      var i = (((row * L.ch) + y) * img.width + col * L.cw + x) * 4, o = (y * L.cw + x) * 4;
      c.d[o] = img.data[i]; c.d[o + 1] = img.data[i + 1]; c.d[o + 2] = img.data[i + 2]; c.d[o + 3] = img.data[i + 3];
    }
    return c;
  }

  // ---- measuring the figure ---------------------------------------------------------------------------------------
  /** opaque runs in a row: [[x0, x1], ...] */
  function runs(c, y) { var out = [], x0 = -1; for (var x = 0; x <= c.w; x++) { var on = x < c.w && c.on(x, y); if (on && x0 < 0) x0 = x; if (!on && x0 >= 0) { out.push([x0, x - 1]); x0 = -1; } } return out; }
  function bbox(c) {
    var t = -1, b = -1, l = c.w, r = -1;
    for (var y = 0; y < c.h; y++) for (var x = 0; x < c.w; x++) if (c.on(x, y)) { if (t < 0) t = y; b = y; if (x < l) l = x; if (x > r) r = x; }
    return t < 0 ? null : { top: t, bottom: b, left: l, right: r, height: b - t + 1, width: r - l + 1 };
  }
  /**
   * The body, measured on the standing down-facing frame: bbox, neck, the hip (where the figure gets narrow above the
   * feet: the legs), the leg length, and whether the legs are hidden by a skirt (the bottom fifth of the figure is used).
   * Returns null for an empty frame. Posture's measure, unchanged.
   * @param {Cell} down the standing down-facing frame
   */
  function measure(down) {
    var bb = bbox(down); if (!bb) return null;
    // the neck: the deepest PINCH between the head and the shoulders (at least 3 px deep), else the narrowest row
    // walking down from the head's widest row before the shoulders widen, else the narrowest row in 30%..62%
    var H = bb.height, y, wAt = function (yy) { var rr = runs(down, yy); return rr.length ? rr[rr.length - 1][1] - rr[0][0] + 1 : 0; };
    var pinchY = -1, pinchD = -1, reach = Math.max(3, Math.round(H * 0.25)), maxAbove = 0;
    for (y = bb.top; y < bb.top + Math.floor(H * 0.15); y++) maxAbove = Math.max(maxAbove, wAt(y));
    for (y = bb.top + Math.floor(H * 0.15); y <= bb.top + Math.floor(H * 0.72); y++) {
      var wy = wAt(y), below = 0;
      for (var k2 = y + 1; k2 <= Math.min(bb.bottom, y + reach); k2++) below = Math.max(below, wAt(k2));
      var dep = Math.min(maxAbove - wy, below - wy);
      if (dep >= pinchD) { pinchD = dep; pinchY = y; }
      maxAbove = Math.max(maxAbove, wy);
    }
    var peak = bb.top, pw = 0, lim = bb.top + Math.floor(H * 0.7);
    for (y = bb.top; y <= bb.top + Math.floor(H * 0.5); y++) if (wAt(y) >= pw) { pw = wAt(y); peak = y; } else break;
    var neck = pinchD >= 3 ? pinchY : -1, mn = Infinity, mnY = peak;
    if (neck < 0) for (y = peak; y <= lim; y++) { var wv = wAt(y); if (wv < mn) { mn = wv; mnY = y; } else if (wv >= mn + 3) { neck = mnY; break; } }
    if (neck < 0) {
      var lo = bb.top + Math.floor(H * 0.30), hi = bb.top + Math.ceil(H * 0.62), best = Infinity; neck = lo;
      for (y = lo; y <= hi; y++) { var w = wAt(y); if (w > 0 && w <= best) { best = w; neck = y; } }
    }
    // the hip: rising from the feet, the legs are the rows no wider than the feet band (+2); the first wider row is
    // the hip line. A skirt or robe never shows that step, so it falls back to the bottom fifth of the figure.
    var spanW = function (yy) { var rr = runs(down, yy); return rr.length ? rr[rr.length - 1][1] - rr[0][0] + 1 : 0; };
    var feetW = Math.max(spanW(bb.bottom - 1), spanW(bb.bottom - 2), spanW(bb.bottom - 3)), hip = bb.bottom;
    for (y = bb.bottom - 1; y > neck + 2; y--) { if (spanW(y) <= feetW + 2) hip = y; else break; }
    var legLen = bb.bottom - hip + 1, skirted = legLen < 3 || legLen > H * 0.45 || spanW(hip - 1) < feetW + 4;
    if (skirted) { legLen = Math.max(3, Math.round(H * 0.2)); hip = bb.bottom - legLen + 1; }
    return { top: bb.top, bottom: bb.bottom, left: bb.left, right: bb.right, height: H, width: bb.width, neck: neck, hip: hip, legLen: legLen, skirted: skirted };
  }

  // ---- the seated pose: one Cell of size (W, ch), feet on the source floor ----------------------------------------
  /**
   * The columns the legs occupy in a side frame (one block), measured on the shins only; null if the band is empty.
   */
  function legSpan(c, hip, bottom) {
    var len = bottom - hip + 1, y0 = hip + Math.ceil(len * 0.4), y1 = Math.max(y0, bottom - 2), l = c.w, r = -1;
    for (var y = y0; y <= y1; y++) { var rr = runs(c, y); for (var k = 0; k < rr.length; k++) { if (rr[k][0] < l) l = rr[k][0]; if (rr[k][1] > r) r = rr[k][1]; } }
    return r < 0 ? null : [l, r];
  }

  /**
   * Front or back: drop `drop` rows out of the legs (keeping the hip row and the feet rows), so the upper body comes
   * down by `drop`, then raise the whole figure by `lift` (the seat).
   */
  function compressLegs(src, M, W, drop, lift) {
    var out = new Cell(W, src.h), ox = Math.floor((W - src.w) / 2), bb = bbox(src); if (!bb) return out;
    var hip = bb.bottom - M.legLen + 1, keep = Math.max(1, M.legLen - 1 - drop);
    lift = Math.min(lift, Math.max(0, bb.top + drop));   // never lift a tall figure out of the top of its cell
    out.rows(src, bb.top, hip, ox, drop - lift);                                   // the upper body and the hip row, lowered
    out.rows(src, bb.bottom - keep + 1, bb.bottom, ox, -lift);                     // the feet, at the seat's edge
    return out;
  }

  /**
   * Side view, seated, made by sliding whole BLOCKS of rows: the upper body drops onto the lap, the lap slides half a
   * leg forward under it, and the lower legs slide a whole leg forward. `facing` -1 = left, +1 = right. A skirt or robe
   * is never slid (a slid hem reads as a fin): a skirted figure sits by dropping rows, as from the front.
   */
  function sideSit(src, M, W, lift, facing) {
    if (M.skirted) return compressLegs(src, M, W, M.legLen - Math.max(1, Math.round(M.legLen * 0.35)) - 1, lift);
    var out = new Cell(W, src.h), ox = Math.floor((W - src.w) / 2), bb = bbox(src); if (!bb) return out;
    var hip = bb.bottom - M.legLen + 1, span = legSpan(src, hip, bb.bottom), wL = span ? span[1] - span[0] + 1 : 4;
    var fwd = Math.max(2, Math.round(wL * 0.5)), lapRows = Math.min(2, M.legLen - 1);
    var keep = Math.max(3, Math.ceil(M.legLen * 0.5)), drop = M.legLen - keep;
    out.rows(src, bb.top, hip - 1, ox, drop - lift);                                         // the upper body, lowered
    out.rows(src, hip, hip + lapRows - 1, ox + facing * Math.ceil(fwd / 2), drop - lift);     // the lap, under it
    out.rows(src, bb.bottom - keep + 1, bb.bottom, ox + facing * fwd, -lift);                // lower legs, forward
    return out;
  }

  /** a soft oval shadow on the floor under a figure, drawn only where nothing else is (the one non-character pixel) */
  function shadow(cell, cx, floor, half) {
    for (var y = floor - 1; y <= floor + 1; y++) for (var x = Math.round(cx - half); x <= Math.round(cx + half); x++) {
      var t = (x - cx) / half, v = (y - floor); if (t * t + v * v * 0.6 > 1 || cell.on(x, y)) continue;
      cell.paint(x, y, [0, 0, 0, y === floor ? 72 : 40]);
    }
  }

  /**
   * The seated pose sheet for one character of a sheet. Returns {width, height, data, cw, ch, pose, spec, lift} - a
   * big-character layout (3 columns x 4 rows, rows = down, left, right, up) handed to Sprite_Character like a '$' sheet,
   * or null when the character's standing frame is empty (nothing to seat).
   * @param {{width:number, height:number, data:Uint8ClampedArray}} img the whole source sheet's RGBA pixels
   * @param {string} name the sheet's file name ('$' marks a one-character sheet) @param {number} index character index
   * @param {{lift?:number}} [opt] lift = seat height in pixels (default 6)
   */
  function derive(img, name, index, opt) {
    opt = opt || {};
    var L = layout(img.width, img.height, name, index);
    var stand = {}; for (var k = 0; k < 4; k++) stand[DIRS[k]] = frameOf(img, L, DIRS[k], 1);
    var M = measure(stand[2]); if (!M) return null;
    var lift = Math.max(0, Math.min(Math.floor(M.legLen * 0.9), M.top, Number(opt.lift === undefined ? 6 : opt.lift) || 0));
    var W = L.cw, ch = L.ch;
    var out = { width: W * 3, height: ch * 4, data: new Uint8ClampedArray(W * 3 * ch * 4 * 4), cw: W, ch: ch, pose: 'sit', spec: M, lift: lift };
    for (var r = 0; r < 4; r++) {
      var dir = DIRS[r], src = stand[dir], side = dir === 4 ? -1 : dir === 6 ? 1 : 0, bb = bbox(src), c;
      if (!bb) c = new Cell(W, ch);
      else {
        var ox = Math.floor((W - src.w) / 2), mid = ox + (bb.left + bb.right) / 2;
        c = side ? sideSit(src, M, W, lift, side) : compressLegs(src, M, W, M.legLen - Math.max(1, Math.round(M.legLen * 0.35)) - 1, lift);
        shadow(c, mid, bb.bottom, M.width * 0.55);
      }
      // a held pose shows one frame: the same seated cell in all three columns of the row
      for (var cc = 0; cc < 3; cc++) for (var y = 0; y < ch; y++) for (var x = 0; x < W; x++) {
        var i = (y * W + x) * 4, o = (((r * ch) + y) * out.width + cc * W + x) * 4;
        out.data[o] = c.d[i]; out.data[o + 1] = c.d[i + 1]; out.data[o + 2] = c.d[i + 2]; out.data[o + 3] = c.d[i + 3];
      }
    }
    return out;
  }

  /** a pose word from user text: 'sit', or '' for anything else (the character stands, drawn as stock) */
  function normal(pose) { return String(pose === undefined || pose === null ? '' : pose).trim().toLowerCase() === 'sit' ? 'sit' : ''; }

  var API = { VERSION: VERSION, ALPHA: ALPHA, DIRS: DIRS, isBig: isBig, layout: layout, frameOf: frameOf, measure: measure, bbox: bbox, derive: derive, normal: normal };

  // ===========================================================================================================
  // THE ENGINE SIDE (RPG Maker MZ)
  // ===========================================================================================================
  if (typeof PluginManager === 'undefined' || typeof Game_CharacterBase === 'undefined') { root.CSAF_PostureLite = API; return; }

  var RAW = PluginManager.parameters('CSAF_PostureLite');
  /** parameters arrive as strings; "" is ABSENT, never zero */
  function num(v, def, lo, hi) { if (v === undefined || v === null || String(v).trim() === '') return def; var n = Number(v); return isFinite(n) ? Math.max(lo, Math.min(hi, Math.round(n))) : def; }
  var P = { lift: num(RAW.seatLift, 6, 0, 24), standOnMove: String(RAW.standOnMove === undefined ? 'true' : RAW.standOnMove) !== 'false' };

  /**
   * Is the full Posture plugin installed? Then this file stands aside: every method below calls straight through to
   * the engine's (or Posture's) own. Asked at FIRST USE, never at load: the buyer chooses the load order.
   */
  var PAID = null;
  function paid() { if (PAID === null) PAID = !!(root.Posture && typeof root.Posture.sheetFor === 'function'); return PAID; }

  // ---- the character side: one saved field, the same one Posture saves --------------------------------------------
  /** 'sit' while this character is seated by Posture Lite, else '' */
  Game_CharacterBase.prototype.pslPose = function () { return !paid() && this._csafPose === 'sit' ? 'sit' : ''; };

  var _increaseSteps = Game_CharacterBase.prototype.increaseSteps;
  /** a step stands the character up when "Stand up on move" is on */
  Game_CharacterBase.prototype.increaseSteps = function () {
    _increaseSteps.apply(this, arguments);
    if (!paid() && P.standOnMove && this._csafPose) this._csafPose = '';
  };

  /** the <pose: x> of the active page's comments, else the event note's, else null (no instruction) */
  function poseFromEvent(ev) {
    var page = ev.page(), list = page && page.list, i, m;
    if (list) for (i = 0; i < list.length; i++) {
      var c = list[i]; if (c.code !== 108 && c.code !== 408) continue;
      m = /<pose:\s*([a-z]+)\s*>/i.exec(String(c.parameters[0] || '')); if (m) return m[1];
    }
    var meta = ev.event() && ev.event().meta;
    return meta && meta.pose !== undefined && meta.pose !== true ? String(meta.pose) : null;
  }
  var _setupPageSettings = Game_Event.prototype.setupPageSettings;
  /** a page change applies that page's pose (or the note's); only "sit" seats, any other word stands */
  Game_Event.prototype.setupPageSettings = function () {
    _setupPageSettings.apply(this, arguments);
    if (paid()) return;
    var p = poseFromEvent(this);
    if (p !== null) this._csafPose = normal(p);
  };

  // ---- the sprite side: one seated sheet per (file, character, seat height), built once ------------------------
  var CACHE = {};
  var SOURCE = {};   // the pixels of each loaded sheet, read ONCE (never read pixels during play)
  var STATS = { built: 0, reads: 0 };
  /** the seated sheet for a loaded source bitmap, or null while it is still loading / when there is nothing to seat */
  function sheetFor(name, index) {
    var key = name + '|' + index + '|' + P.lift;
    if (CACHE[key] !== undefined) return CACHE[key];
    var src = ImageManager.loadCharacter(name);
    if (!src || !src.isReady() || !src.width) return null;
    if (!SOURCE[name]) { SOURCE[name] = { width: src.width, height: src.height, data: src.context.getImageData(0, 0, src.width, src.height).data }; STATS.reads++; }
    var out = derive(SOURCE[name], name, index, { lift: P.lift });
    var bmp = null;
    if (out) {
      bmp = new Bitmap(out.width, out.height);
      bmp.context.putImageData(new ImageData(out.data, out.width, out.height), 0, 0);
      bmp._baseTexture.update();
      bmp._pslCell = { cw: out.cw, ch: out.ch };
      STATS.built++;
    }
    CACHE[key] = bmp;
    return bmp;
  }

  var _updateBitmap = Sprite_Character.prototype.updateBitmap;
  /** after the engine picks the sheet, swap in the seated sheet while the character sits (no allocation per frame) */
  Sprite_Character.prototype.updateBitmap = function () {
    _updateBitmap.apply(this, arguments);
    if (paid()) return;
    var ch = this._character, pose = ch && !this._tileId && this._characterName && ch.pslPose ? ch.pslPose() : '';
    if (!pose) {
      if (this._pslBmp) { this.bitmap = ImageManager.loadCharacter(this._characterName); this._pslBmp = null; this._pslName = ''; }
      return;
    }
    if (this._pslBmp && this._pslName === this._characterName && this._pslIndex === this._characterIndex) return;
    var bmp = sheetFor(this._characterName, this._characterIndex);
    if (!bmp) return;
    this.bitmap = bmp; this._pslBmp = bmp; this._pslName = this._characterName; this._pslIndex = this._characterIndex;
  };

  // the engine's own frame math, saved one per statement and CALLED for every character that is not seated
  var _blockX = Sprite_Character.prototype.characterBlockX;
  var _blockY = Sprite_Character.prototype.characterBlockY;
  var _patX = Sprite_Character.prototype.characterPatternX;
  var _pw = Sprite_Character.prototype.patternWidth;
  var _ph = Sprite_Character.prototype.patternHeight;
  /** a seated sheet holds ONE character, laid out like a '$' sheet: no block offset, the middle column */
  Sprite_Character.prototype.characterBlockX = function () { return this._pslBmp ? 0 : _blockX.apply(this, arguments); };
  Sprite_Character.prototype.characterBlockY = function () { return this._pslBmp ? 0 : _blockY.apply(this, arguments); };
  Sprite_Character.prototype.patternWidth = function () { return this._pslBmp ? this._pslBmp._pslCell.cw : _pw.apply(this, arguments); };
  Sprite_Character.prototype.patternHeight = function () { return this._pslBmp ? this._pslBmp._pslCell.ch : _ph.apply(this, arguments); };
  Sprite_Character.prototype.characterPatternX = function () { return this._pslBmp ? 1 : _patX.apply(this, arguments); };

  // a read only support seam: what this file built, and the pose a character holds
  API.P = P;
  API.poseFromEvent = poseFromEvent;
  API.paid = paid;
  API.stats = function () { return { built: STATS.built, reads: STATS.reads, sheets: Object.keys(CACHE).length, paid: paid() }; };
  API.get = function (ch) { return ch && ch.pslPose ? ch.pslPose() : ''; };
  root.CSAF_PostureLite = API;
}());
