/*:
 * @target MZ
 * @plugindesc Unveil 2/3 - the drawing kit: three veils, the reveal rim, the trail, the creature, sparks. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * UnveilDraw.js - part of Unveil v1.0.0. Enable it with UnveilCore.js and
 * Unveil.js (any order). It has no commands or parameters of its own.
 *
 * Every line of this plugin was written with AI assistance.
 */
/*
 * Everything the player sees except the buyer's picture, drawn with the canvas 2D API into whatever context it is handed:
 * the veil (silk, frost or lacquer: three materials, not recolours, wing §21a), the rim struck along every edge of the
 * claimed land, the glowing trail, the creature, the sparks, the player's marker, the score band and the results panel.
 * Pure drawing, no engine calls. The scene redraws the veil only when land is claimed and the trail only when it grows.
 */
var UnveilDraw = (function () {
  'use strict';
  var TAU = Math.PI * 2;
  var FONT = '"Palatino Linotype", "Book Antiqua", Palatino, Georgia, serif';
  var STAGE = {
    silk: { name: 'Silk', a: '#5a0f2a', b: '#8e1d45', fold: '#c94a72', rim: '#f3c86b', trail: '#ffe39a', ink: '#fff2dc', glow: '#ffcf6e' },
    frost: { name: 'Frost', a: '#2c4a66', b: '#5f8db3', fold: '#cfe8ff', rim: '#e8f6ff', trail: '#9ff0ff', ink: '#f2fbff', glow: '#bdf3ff' },
    lacquer: { name: 'Lacquer', a: '#0d0a0e', b: '#2a1219', fold: '#5c3a44', rim: '#d9b25f', trail: '#ff7a59', ink: '#f4ecdc', glow: '#ff9a6e' }
  };
  var THEMES = Object.keys(STAGE);
  function rgba(hex, a) { var n = parseInt(hex.slice(1), 16); return 'rgba(' + (n >> 16 & 255) + ',' + (n >> 8 & 255) + ',' + (n & 255) + ',' + a + ')'; }
  function text(g, s, x, y, size, color, align, weight) { g.font = (weight || '700') + ' ' + size + 'px ' + FONT; g.fillStyle = color; g.textAlign = align || 'left'; g.textBaseline = 'middle'; g.fillText(s, x, y); }
  function roundRect(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.lineTo(x + w - r, y); g.quadraticCurveTo(x + w, y, x + w, y + r); g.lineTo(x + w, y + h - r); g.quadraticCurveTo(x + w, y + h, x + w - r, y + h); g.lineTo(x + r, y + h); g.quadraticCurveTo(x, y + h, x, y + h - r); g.lineTo(x, y + r); g.quadraticCurveTo(x, y, x + r, y); g.closePath(); }
  function scatter(seed) { var s = seed | 0; return function () { s = (s + 0x6D2B79F5) | 0; var t = Math.imul(s ^ (s >>> 15), s | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

  /** The veil material, filling W x H: draped silk folds, frosted glass with ice ferns, or black lacquer with gold waves. */
  function veil(g, W, H, theme, seed) {
    var T = STAGE[theme] || STAGE.silk, rnd = scatter(seed || 7), i;
    var base = g.createLinearGradient(0, 0, W, H); base.addColorStop(0, T.a); base.addColorStop(1, T.b); g.fillStyle = base; g.fillRect(0, 0, W, H);
    if (theme === 'frost') {
      for (i = 0; i < 26; i++) {                                   // ice ferns: branching strokes from seeded roots
        var x = rnd() * W, y = rnd() * H, a = rnd() * TAU, len = 30 + rnd() * 80;
        g.strokeStyle = rgba(T.fold, 0.35 + rnd() * 0.3); g.lineWidth = 1.2;
        for (var b = 0; b < 3; b++) { var ex = x + Math.cos(a) * len, ey = y + Math.sin(a) * len; g.beginPath(); g.moveTo(x, y); g.lineTo(ex, ey); g.stroke();
          for (var f = 1; f < 6; f++) { var px = x + (ex - x) * f / 6, py = y + (ey - y) * f / 6, fl = len * 0.22 * (1 - f / 7); g.beginPath(); g.moveTo(px, py); g.lineTo(px + Math.cos(a + 0.7) * fl, py + Math.sin(a + 0.7) * fl); g.moveTo(px, py); g.lineTo(px + Math.cos(a - 0.7) * fl, py + Math.sin(a - 0.7) * fl); g.stroke(); }
          x = ex; y = ey; a += (rnd() - 0.5) * 1.2; len *= 0.7; }
      }
      for (i = 0; i < 900; i++) { g.fillStyle = rgba('#ffffff', rnd() * 0.18); g.fillRect(rnd() * W, rnd() * H, 2, 2); }
    } else if (theme === 'lacquer') {
      // black lacquer: overlapping wave scales (seigaiha) struck in gold, each row laid over the one above it, then
      // gold dust and a few ink blooms (2026-10-08 look: the first ink wash read as a grey smudge beside silk and frost)
      var sr = 26, row = 0;
      for (var sy = -sr; sy < H + sr; sy += sr / 2, row++) {
        for (var sx = (row % 2) * sr - sr; sx < W + sr * 2; sx += sr * 2) {
          g.fillStyle = base; g.beginPath(); g.arc(sx, sy + sr, sr, Math.PI, TAU); g.closePath(); g.fill();
          for (var ring = 0; ring < 4; ring++) { g.strokeStyle = rgba(T.rim, ring === 0 ? 0.42 : 0.16 + 0.05 * ring); g.lineWidth = ring === 0 ? 1.4 : 1; g.beginPath(); g.arc(sx, sy + sr, sr * (1 - ring * 0.24), Math.PI, TAU); g.stroke(); }
        }
      }
      for (i = 0; i < 14; i++) { var cx = rnd() * W, cy = rnd() * H, r = 60 + rnd() * 160, gr = g.createRadialGradient(cx, cy, 0, cx, cy, r); gr.addColorStop(0, 'rgba(6,4,8,' + (0.35 + rnd() * 0.25) + ')'); gr.addColorStop(1, 'rgba(6,4,8,0)'); g.fillStyle = gr; g.fillRect(cx - r, cy - r, r * 2, r * 2); }
      for (i = 0; i < 700; i++) { g.fillStyle = rgba(T.rim, 0.25 + rnd() * 0.55); var ds = rnd() < 0.85 ? 1 : 2; g.fillRect(rnd() * W, rnd() * H, ds, ds); }
    } else {
      for (i = 0; i < 18; i++) {                                    // silk folds: soft vertical highlights and shadows
        var fx = (i + rnd() * 0.6) * W / 18, fw = 18 + rnd() * 40, fg = g.createLinearGradient(fx - fw, 0, fx + fw, 0);
        fg.addColorStop(0, rgba(T.fold, 0)); fg.addColorStop(0.5, rgba(T.fold, 0.28 + rnd() * 0.18)); fg.addColorStop(1, rgba(T.fold, 0));
        g.fillStyle = fg; g.beginPath(); g.moveTo(fx - fw, 0); g.bezierCurveTo(fx - fw + 20, H * 0.3, fx - fw - 20, H * 0.7, fx - fw + 10, H); g.lineTo(fx + fw + 10, H); g.bezierCurveTo(fx + fw - 20, H * 0.7, fx + fw + 20, H * 0.3, fx + fw, 0); g.closePath(); g.fill();
      }
      g.strokeStyle = rgba(T.rim, 0.25); g.lineWidth = 1;          // a woven damask diamond over the silk
      for (var dx = -H; dx < W; dx += 28) { g.beginPath(); g.moveTo(dx, 0); g.lineTo(dx + H, H); g.stroke(); g.beginPath(); g.moveTo(dx + H, 0); g.lineTo(dx, H); g.stroke(); }
    }
    var vig = g.createRadialGradient(W / 2, H / 2, H * 0.2, W / 2, H / 2, W * 0.7); vig.addColorStop(0, 'rgba(0,0,0,0)'); vig.addColorStop(1, 'rgba(0,0,0,0.35)'); g.fillStyle = vig; g.fillRect(0, 0, W, H);
  }

  /**
   * Cut the claimed land out of a veil already drawn into g (destination-out), then strike the rim along every edge
   * between claimed land and veil. Called when land is claimed, never per frame. Returns the rim segments drawn.
   */
  function cut(g, game, cw, ch, theme) {
    var T = STAGE[theme] || STAGE.silk, cols = game.cols, rows = game.rows, c = game.cells, x, y, rim = 0;
    g.save(); g.globalCompositeOperation = 'destination-out'; g.fillStyle = '#000';
    for (y = 1; y < rows - 1; y++) for (x = 1; x < cols - 1; x++) if (c[y * cols + x] === 1) g.fillRect(x * cw - 0.5, y * ch - 0.5, cw + 1, ch + 1);
    g.restore();
    // the rim runs along every edge between claimed land and veil, the board's own frame included, so the walkway around
    // the screen reads as an edge from the first frame (2026-10-08 look: the frame had no rim and the walkway was invisible)
    g.save(); g.strokeStyle = T.rim; g.lineWidth = 2.2; g.shadowColor = T.glow; g.shadowBlur = 6; g.beginPath();
    for (y = 1; y < rows - 1; y++) for (x = 1; x < cols - 1; x++) {
      if (c[y * cols + x] !== 0) continue;
      if (c[y * cols + x - 1] === 1) { g.moveTo(x * cw, y * ch); g.lineTo(x * cw, (y + 1) * ch); rim++; }
      if (c[y * cols + x + 1] === 1) { g.moveTo((x + 1) * cw, y * ch); g.lineTo((x + 1) * cw, (y + 1) * ch); rim++; }
      if (c[(y - 1) * cols + x] === 1) { g.moveTo(x * cw, y * ch); g.lineTo((x + 1) * cw, y * ch); rim++; }
      if (c[(y + 1) * cols + x] === 1) { g.moveTo(x * cw, (y + 1) * ch); g.lineTo((x + 1) * cw, (y + 1) * ch); rim++; }
    }
    g.stroke(); g.restore();
    return rim;
  }

  /** The trail as a glowing thread through its cells, in order. Redrawn when it grows. */
  function trail(g, game, cw, ch, theme) {
    var T = STAGE[theme] || STAGE.silk;
    if (!game.trailLen) return 0;
    g.save(); g.lineCap = 'round'; g.lineJoin = 'round';
    for (var pass = 0; pass < 2; pass++) {
      g.strokeStyle = pass ? '#ffffff' : T.trail; g.lineWidth = pass ? 1.4 : 4; g.shadowColor = T.glow; g.shadowBlur = pass ? 0 : 10;
      g.beginPath(); g.moveTo((game.sx + 0.5) * cw, (game.sy + 0.5) * ch);
      for (var i = 0; i < game.trailLen; i++) { var k = game.trail[i], x = k % game.cols, y = (k - x) / game.cols; g.lineTo((x + 0.5) * cw, (y + 0.5) * ch); }
      g.stroke();
    }
    g.restore();
    return game.trailLen;
  }

  /** The creature: a many-armed wisp in the veil's glow colour, drawn once into a size x size canvas; the scene spins it. */
  function creature(g, size, theme) {
    var T = STAGE[theme] || STAGE.silk, c = size / 2;
    g.save(); g.translate(c, c);
    var halo = g.createRadialGradient(0, 0, 0, 0, 0, c); halo.addColorStop(0, rgba(T.glow, 0.55)); halo.addColorStop(1, rgba(T.glow, 0)); g.fillStyle = halo; g.fillRect(-c, -c, size, size);
    for (var a = 0; a < 7; a++) { var ang = a * TAU / 7; g.strokeStyle = rgba(T.trail, 0.85); g.lineWidth = 2.4; g.beginPath(); g.moveTo(0, 0);
      g.bezierCurveTo(Math.cos(ang) * c * 0.4, Math.sin(ang) * c * 0.4, Math.cos(ang + 0.6) * c * 0.7, Math.sin(ang + 0.6) * c * 0.7, Math.cos(ang + 0.3) * c * 0.92, Math.sin(ang + 0.3) * c * 0.92); g.stroke();
      g.fillStyle = '#ffffff'; g.beginPath(); g.arc(Math.cos(ang + 0.3) * c * 0.92, Math.sin(ang + 0.3) * c * 0.92, 2, 0, TAU); g.fill(); }
    g.fillStyle = T.trail; g.beginPath(); g.arc(0, 0, c * 0.22, 0, TAU); g.fill(); g.fillStyle = '#1a0b12'; g.beginPath(); g.arc(c * 0.06, -c * 0.04, c * 0.08, 0, TAU); g.fill();
    g.restore();
  }
  /** A spark: an ember with rays. */
  function spark(g, size, theme) {
    var T = STAGE[theme] || STAGE.silk, c = size / 2; g.save(); g.translate(c, c);
    var gl = g.createRadialGradient(0, 0, 0, 0, 0, c); gl.addColorStop(0, '#ffffff'); gl.addColorStop(0.3, T.glow); gl.addColorStop(1, rgba(T.glow, 0)); g.fillStyle = gl; g.fillRect(-c, -c, size, size);
    g.strokeStyle = '#ffffff'; g.lineWidth = 1.5; for (var r = 0; r < 4; r++) { var a = r * Math.PI / 4; g.beginPath(); g.moveTo(Math.cos(a) * c * 0.9, Math.sin(a) * c * 0.9); g.lineTo(-Math.cos(a) * c * 0.9, -Math.sin(a) * c * 0.9); g.stroke(); }
    g.restore();
  }
  /** The player's marker: a cut-diamond needle. */
  function marker(g, size, theme) {
    var T = STAGE[theme] || STAGE.silk, c = size / 2; g.save(); g.translate(c, c);
    g.fillStyle = rgba('#000000', 0.4); g.beginPath(); g.moveTo(1, -c + 3); g.lineTo(c - 1, 1); g.lineTo(1, c - 1); g.lineTo(-c + 3, 1); g.closePath(); g.fill();
    g.fillStyle = T.ink; g.beginPath(); g.moveTo(0, -c + 2); g.lineTo(c - 2, 0); g.lineTo(0, c - 2); g.lineTo(-c + 2, 0); g.closePath(); g.fill();
    g.strokeStyle = T.rim; g.lineWidth = 2; g.stroke(); g.fillStyle = T.rim; g.beginPath(); g.arc(0, 0, c * 0.18, 0, TAU); g.fill();
    g.restore();
  }
  /** The top band: the claimed share against the target, the lives, the stage. Drawn when one of them changes. */
  function hud(g, W, theme, st) {
    var T = STAGE[theme] || STAGE.silk;
    g.save(); g.fillStyle = 'rgba(8,6,10,0.85)'; g.fillRect(0, 0, W, 56);
    var bx = 190, bw = W - 380, by = 18, bh = 18;
    g.fillStyle = 'rgba(255,255,255,0.12)'; roundRect(g, bx, by, bw, bh, 9); g.fill();
    var fw = Math.max(18, bw * Math.min(1, st.percent / 100));
    g.fillStyle = T.rim; roundRect(g, bx, by, fw, bh, 9); g.fill();
    var tx = bx + bw * st.target / 100; g.strokeStyle = '#ffffff'; g.lineWidth = 2; g.beginPath(); g.moveTo(tx, by - 6); g.lineTo(tx, by + bh + 6); g.stroke();
    // the percent in TWO inks, each clipped to what it sits on: dark over the fill, white over the empty track (2026-10-08:
    // white over frost's near-white fill vanished at 91%; dark ink vanished on the track before that)
    var label = st.percent.toFixed(1) + '%', lx = bx + bw / 2, ly = by + bh / 2 + 1;
    g.save(); g.beginPath(); g.rect(bx, by - 2, fw, bh + 4); g.clip(); text(g, label, lx, ly, 14, '#120c10', 'center', '700'); g.restore();
    g.save(); g.beginPath(); g.rect(bx + fw, by - 2, bw - fw + 2, bh + 4); g.clip(); g.shadowColor = 'rgba(0,0,0,0.9)'; g.shadowBlur = 4; text(g, label, lx, ly, 14, '#ffffff', 'center', '700'); g.restore();
    text(g, 'target ' + st.target + '%', tx, 49, 12, T.ink, 'center', '600');
    text(g, T.name, 24, 28, 22, T.ink, 'left', '700');
    for (var i = 0; i < st.livesMax; i++) { g.fillStyle = i < st.lives ? T.rim : 'rgba(255,255,255,0.18)'; g.beginPath(); g.moveTo(W - 30 - i * 26, 16); g.lineTo(W - 22 - i * 26, 28); g.lineTo(W - 30 - i * 26, 40); g.lineTo(W - 38 - i * 26, 28); g.closePath(); g.fill(); }
    g.restore();
  }
  /** The results panel. */
  function resultsPanel(g, W, H, theme, res) {
    var T = STAGE[theme] || STAGE.silk, pw = 440, ph = 230, px = (W - pw) / 2, py = H - ph - 30;
    g.save(); g.fillStyle = 'rgba(8,6,10,0.85)'; roundRect(g, px, py, pw, ph, 14); g.fill(); g.strokeStyle = T.rim; g.lineWidth = 3; roundRect(g, px + 3, py + 3, pw - 6, ph - 6, 12); g.stroke();
    text(g, res.won ? 'UNVEILED' : 'THE VEIL HOLDS', W / 2, py + 44, 28, res.won ? T.rim : '#e0786c', 'center', '700');
    text(g, res.percent.toFixed(1) + '% revealed  ·  target ' + res.target + '%', W / 2, py + 98, 20, T.ink, 'center', '600');
    text(g, res.cuts + (res.cuts === 1 ? ' cut' : ' cuts') + '  ·  ' + res.hits + (res.hits === 1 ? ' life lost' : ' lives lost'), W / 2, py + 136, 18, rgba(T.ink, 0.8), 'center', '600');
    text(g, 'OK to leave', W / 2, py + ph - 26, 15, rgba(T.ink, 0.7), 'center', '600');
    g.restore();
  }
  return { VERSION: '1.0.0', FONT: FONT, STAGE: STAGE, THEMES: THEMES, rgba: rgba, text: text, roundRect: roundRect, veil: veil, cut: cut, trail: trail, creature: creature, spark: spark, marker: marker, hud: hud, resultsPanel: resultsPanel };
}());
if (typeof module !== 'undefined' && module.exports) module.exports = UnveilDraw;
