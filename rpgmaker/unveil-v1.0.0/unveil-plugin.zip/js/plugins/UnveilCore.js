/*:
 * @target MZ
 * @plugindesc Unveil 1/3 - the rules: a Qix-style territory-capture game over your picture. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * UnveilCore.js - part of Unveil v1.0.0. Enable it with UnveilDraw.js and
 * Unveil.js (any order). It has no commands or parameters of its own.
 *
 * Every line of this plugin was written with AI assistance.
 */
/*
 * The rules of a territory-capture game, pure JavaScript with no engine calls, so they run headless in Node exactly as
 * in MZ. The field is a grid of cells: CLAIMED (the picture shows through), OPEN (still veiled) and TRAIL (the line the
 * player is drawing). The player walks the edge of the claimed land; holding "draw" it cuts into the open veil, and when
 * the trail reaches claimed land again every open region that holds no creature is claimed. A creature touching the
 * trail, or a spark running along the edge touching the player, costs a life. Claim the target share to win.
 * Never Math.random: a seeded generator whose state lives on the game.
 */
var UnveilCore = (function () {
  'use strict';
  var OPEN = 0, CLAIMED = 1, TRAIL = 2;
  var SPARK_CLEARANCE = 12;   // a spark moved off enclosed land lands at least this many steps from the player

  function hashString(s) { var h = 0x811c9dc5; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193); } return h >>> 0; }
  function mix(a, b) { var h = Math.imul((a >>> 0) ^ 0x9e3779b9, 0x85ebca6b) ^ (b >>> 0); h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35); return (h ^ (h >>> 16)) >>> 0; }
  function rand(g) { var t = g.rs = (g.rs + 0x6D2B79F5) | 0; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }

  /**
   * A new game.
   * @param {number} seed
   * @param {{cols?:number, rows?:number, target?:number, lives?:number, creatures?:number, sparks?:number, creatureSpeed?:number, sparkEvery?:number}} [opts]
   *   cols x rows cells (96 x 64), target percent to claim (75), lives (3), creatures in the veil (1), sparks on the edge
   *   (2), creature speed in cells a frame (0.35), frames per spark step (3)
   * Balance, measured 2026-10-08 (Internal_Ops/_scripts/balance_probe.js, 200 scripted games a row, unfinished = lost):
   *   careful / reckless script wins: 60%,1,0 sparks 100 / 69-82 · defaults 72-75 / 40-41 · 75%,4 creatures 44-52 / 1-2
   *   · 85%,2,4 sparks 25-31 / 4-10 · 95%,4,6,1 life 0 / 0.
   */
  function createGame(seed, opts) {
    opts = opts || {};
    var cols = Math.max(16, Math.min(160, Math.floor(opts.cols || 96))), rows = Math.max(12, Math.min(120, Math.floor(opts.rows || 64)));
    var g = { v: 1, seed: seed >>> 0, rs: mix(seed >>> 0, 0x0A11) | 0, cols: cols, rows: rows, cells: new Uint8Array(cols * rows),
      target: Math.max(10, Math.min(95, Number(opts.target) || 75)), lives: Math.max(1, Math.floor(opts.lives || 3)),
      creatureSpeed: Math.max(0.05, Math.min(1, Number(opts.creatureSpeed) || 0.35)), sparkEvery: Math.max(1, Math.floor(opts.sparkEvery || 3)),
      px: Math.floor(cols / 2), py: rows - 1, drawing: false, trail: new Int32Array(cols * rows), trailLen: 0, sx: 0, sy: 0,
      creatures: [], sparks: [], claimed: 0, interior: (cols - 2) * (rows - 2), frame: 0, phase: 'play', hits: 0, cuts: 0,
      stack: new Int32Array(cols * rows), mark: new Int32Array(cols * rows), markGen: 0 };
    g.livesMax = g.lives;
    for (var x = 0; x < cols; x++) { g.cells[x] = CLAIMED; g.cells[(rows - 1) * cols + x] = CLAIMED; }
    for (var y = 0; y < rows; y++) { g.cells[y * cols] = CLAIMED; g.cells[y * cols + cols - 1] = CLAIMED; }
    var nc = Math.max(1, Math.min(4, Math.floor(opts.creatures == null ? 1 : opts.creatures)));
    for (var c = 0; c < nc; c++) { var a = rand(g) * Math.PI * 2; g.creatures.push({ x: cols / 2 + (rand(g) - 0.5) * cols * 0.3, y: rows / 2 + (rand(g) - 0.5) * rows * 0.3, vx: Math.cos(a) * g.creatureSpeed, vy: Math.sin(a) * g.creatureSpeed }); }
    var ns = Math.max(0, Math.min(6, Math.floor(opts.sparks == null ? 2 : opts.sparks)));
    for (var s = 0; s < ns; s++) g.sparks.push({ x: s % 2 ? cols - 1 : 0, y: 0, px: -1, py: -1 });
    return g;
  }

  function at(g, x, y) { return (x < 0 || y < 0 || x >= g.cols || y >= g.rows) ? CLAIMED : g.cells[y * g.cols + x]; }
  /** A claimed cell touching the veil (8 neighbours): where the player and the sparks may walk. */
  function isEdge(g, x, y) {
    if (at(g, x, y) !== CLAIMED || x < 0 || y < 0 || x >= g.cols || y >= g.rows) return false;
    for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) { if ((dx || dy) && at(g, x + dx, y + dy) === OPEN) return true; }
    return false;
  }
  /** Percent of the interior claimed (0..100, one decimal). */
  function percent(g) { return Math.round(1000 * g.claimed / g.interior) / 10; }

  /**
   * The nearest edge cell to (x, y), searched outward over the whole grid with the game's own queue and mark buffers (no
   * allocation), preferring one at least minDist steps (Manhattan) from (ax, ay); the plain nearest when none is. Returns
   * the cell index, or -1 when the board has no edge left. A claim can leave the player, or a spark, standing on land
   * that no longer touches the veil: this is where it goes (2026-10-08 balance probe: a box closing onto claimed land
   * enclosed the closing cell and the player could never move again).
   */
  function nearestEdge(g, x, y, ax, ay, minDist) {
    var cols = g.cols, rows = g.rows, head = 0, tail = 0, first = -1, start = y * cols + x;
    g.markGen++; g.stack[tail++] = start; g.mark[start] = g.markGen;
    while (head < tail) {
      var k = g.stack[head++], kx = k % cols, ky = (k - kx) / cols;
      if (isEdge(g, kx, ky)) { if (first < 0) first = k; if (Math.abs(kx - ax) + Math.abs(ky - ay) >= minDist) return k; }
      if (kx > 0 && g.mark[k - 1] !== g.markGen) { g.mark[k - 1] = g.markGen; g.stack[tail++] = k - 1; }
      if (kx < cols - 1 && g.mark[k + 1] !== g.markGen) { g.mark[k + 1] = g.markGen; g.stack[tail++] = k + 1; }
      if (ky > 0 && g.mark[k - cols] !== g.markGen) { g.mark[k - cols] = g.markGen; g.stack[tail++] = k - cols; }
      if (ky < rows - 1 && g.mark[k + cols] !== g.markGen) { g.mark[k + cols] = g.markGen; g.stack[tail++] = k + cols; }
    }
    return first;
  }

  /**
   * Close the trail: the trail becomes claimed land; every open region with no creature in it is claimed too. Uses the
   * game's own stack and mark buffers (no allocation). Returns the cells claimed by this cut.
   */
  function claim(g) {
    var cols = g.cols, n = g.cells.length, before = g.claimed, i;
    for (i = 0; i < g.trailLen; i++) { g.cells[g.trail[i]] = CLAIMED; g.claimed++; }
    g.trailLen = 0; g.drawing = false; g.cuts++;
    // label the regions that hold a creature, then claim every open cell left unlabelled
    g.markGen++;
    for (var c = 0; c < g.creatures.length; c++) {
      var cx = Math.floor(g.creatures[c].x), cy = Math.floor(g.creatures[c].y), start = cy * cols + cx;
      if (g.cells[start] !== OPEN || g.mark[start] === g.markGen) continue;
      var sp = 0; g.stack[sp++] = start; g.mark[start] = g.markGen;
      while (sp) {
        var k = g.stack[--sp], kx = k % cols, ky = (k - kx) / cols;
        if (kx > 0 && g.cells[k - 1] === OPEN && g.mark[k - 1] !== g.markGen) { g.mark[k - 1] = g.markGen; g.stack[sp++] = k - 1; }
        if (kx < cols - 1 && g.cells[k + 1] === OPEN && g.mark[k + 1] !== g.markGen) { g.mark[k + 1] = g.markGen; g.stack[sp++] = k + 1; }
        if (ky > 0 && g.cells[k - cols] === OPEN && g.mark[k - cols] !== g.markGen) { g.mark[k - cols] = g.markGen; g.stack[sp++] = k - cols; }
        if (ky < g.rows - 1 && g.cells[k + cols] === OPEN && g.mark[k + cols] !== g.markGen) { g.mark[k + cols] = g.markGen; g.stack[sp++] = k + cols; }
      }
    }
    for (i = 0; i < n; i++) if (g.cells[i] === OPEN && g.mark[i] !== g.markGen) { g.cells[i] = CLAIMED; g.claimed++; }
    if (percent(g) >= g.target) g.phase = 'won';
    else settle(g);
    return g.claimed - before;
  }

  /** After a claim: whoever now stands on land that touches no veil steps to the nearest edge (sparks: not onto the player). */
  function settle(g) {
    var k;
    if (!isEdge(g, g.px, g.py)) { k = nearestEdge(g, g.px, g.py, g.px, g.py, 0); if (k >= 0) { g.px = k % g.cols; g.py = (k - g.px) / g.cols; } }
    for (var s = 0; s < g.sparks.length; s++) {
      var sp = g.sparks[s];
      if (isEdge(g, sp.x, sp.y)) continue;
      k = nearestEdge(g, sp.x, sp.y, g.px, g.py, SPARK_CLEARANCE);
      if (k >= 0) { sp.x = k % g.cols; sp.y = (k - sp.x) / g.cols; sp.px = -1; sp.py = -1; }
    }
  }

  /** The trail is broken (a creature or a spark): a life lost, the trail erased, the player back where it began. */
  function hit(g) {
    for (var i = 0; i < g.trailLen; i++) g.cells[g.trail[i]] = OPEN;
    if (g.drawing) { g.px = g.sx; g.py = g.sy; }
    g.trailLen = 0; g.drawing = false; g.lives--; g.hits++;
    if (g.lives <= 0) { g.lives = 0; g.phase = 'lost'; }
  }

  /**
   * Move the player one cell (dx, dy one of -1/0/1, not both). Without "draw" the player keeps to the edge of the claimed
   * land; with it, it cuts into the veil. Crossing its own trail is refused. Returns what happened.
   * @returns {string} 'moved' | 'cut' | 'closed' | 'blocked'
   */
  function move(g, dx, dy, draw) {
    if (g.phase !== 'play' || (dx && dy) || (!dx && !dy)) return 'blocked';
    var nx = g.px + dx, ny = g.py + dy;
    if (nx < 0 || ny < 0 || nx >= g.cols || ny >= g.rows) return 'blocked';
    var c = g.cells[ny * g.cols + nx];
    if (!g.drawing) {
      if (c === CLAIMED) { if (!isEdge(g, nx, ny)) return 'blocked'; g.px = nx; g.py = ny; return 'moved'; }
      if (c === OPEN && draw) { g.drawing = true; g.sx = g.px; g.sy = g.py; g.cells[ny * g.cols + nx] = TRAIL; g.trail[g.trailLen++] = ny * g.cols + nx; g.px = nx; g.py = ny; return 'cut'; }
      return 'blocked';
    }
    if (c === TRAIL) return 'blocked';
    g.px = nx; g.py = ny;
    if (c === OPEN) { g.cells[ny * g.cols + nx] = TRAIL; g.trail[g.trailLen++] = ny * g.cols + nx; return 'cut'; }
    claim(g); return 'closed';
  }

  /**
   * One frame of the world: creatures drift through the veil and bounce off claimed land (touching the trail breaks it);
   * sparks run along the edge every sparkEvery frames (touching the player costs a life). Allocates nothing.
   */
  function step(g) {
    if (g.phase !== 'play') return g;
    g.frame++;
    for (var c = 0; c < g.creatures.length; c++) {
      var q = g.creatures[c], nx = q.x + q.vx, ny = q.y + q.vy;
      var hx = at(g, Math.floor(nx), Math.floor(q.y)), hy = at(g, Math.floor(q.x), Math.floor(ny));
      if (hx === TRAIL || hy === TRAIL) { hit(g); if (g.phase !== 'play') return g; continue; }
      if (hx === CLAIMED) { q.vx = -q.vx; nx = q.x; }
      if (hy === CLAIMED) { q.vy = -q.vy; ny = q.y; }
      if (at(g, Math.floor(nx), Math.floor(ny)) === OPEN) { q.x = nx; q.y = ny; }
      else { q.vx = -q.vx; q.vy = -q.vy; }
    }
    if (g.frame % g.sparkEvery === 0) for (var s = 0; s < g.sparks.length; s++) {
      var sp = g.sparks[s];
      if (!isEdge(g, sp.x, sp.y)) { var e = nearestEdge(g, sp.x, sp.y, g.px, g.py, SPARK_CLEARANCE); if (e < 0) continue; sp.x = e % g.cols; sp.y = (e - sp.x) / g.cols; sp.px = -1; sp.py = -1; }
      var bx = -1, by = -1, seen = 0;
      for (var d = 0; d < 4; d++) {
        var ex = sp.x + (d === 0 ? 1 : d === 1 ? -1 : 0), ey = sp.y + (d === 2 ? 1 : d === 3 ? -1 : 0);
        if ((ex === sp.px && ey === sp.py) || !isEdge(g, ex, ey)) continue;
        seen++; if (bx < 0 || rand(g) < 1 / seen) { bx = ex; by = ey; }
      }
      if (bx < 0) { bx = sp.px; by = sp.py; if (bx < 0) continue; }
      sp.px = sp.x; sp.py = sp.y; sp.x = bx; sp.y = by;
      if (sp.x === g.px && sp.y === g.py) { hit(g); if (g.phase !== 'play') return g; }
    }
    return g;
  }

  /** The game's outcome. */
  function results(g) { return { won: g.phase === 'won', lost: g.phase === 'lost', percent: percent(g), target: g.target, lives: g.lives, cuts: g.cuts, hits: g.hits, frames: g.frame }; }

  return { VERSION: '1.0.0', OPEN: OPEN, CLAIMED: CLAIMED, TRAIL: TRAIL, hashString: hashString, mix: mix, createGame: createGame, at: at,
    isEdge: isEdge, percent: percent, nearestEdge: nearestEdge, claim: claim, move: move, step: step, results: results };
}());
if (typeof module !== 'undefined' && module.exports) module.exports = UnveilCore;
