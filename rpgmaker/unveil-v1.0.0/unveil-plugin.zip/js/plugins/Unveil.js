/*:
 * @target MZ
 * @plugindesc Unveil 3/3 - a Qix-style minigame for MZ: claim the board to reveal one of your own pictures.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * UNVEIL v1.0.0 - claim the board, reveal your picture
 * ============================================================================
 * One of your pictures lies under a veil. Walk the edge of the revealed land,
 * hold OK to cut into the veil, and close the cut on revealed land again: every
 * part of the veil with no creature in it falls away. A creature touching your
 * cut, or a spark running the edge touching you, costs a life. Reveal the
 * target share to win.
 *
 * INSTALLING: copy UnveilCore.js, UnveilDraw.js and Unveil.js into js/plugins
 * and enable all three. Any order works.
 *
 * USING IT: add the plugin command "Start Unveil" to an event and name a
 * picture from img/pictures. The event waits while the game runs.
 *
 * CONTROLS: arrow keys move; hold OK (or Shift) to cut. Touch: press and drag
 * toward where you want to go; while pressed you cut, and a cut that stops a
 * cell or two short of revealed land closes onto it. On the results, OK or a
 * click leaves.
 *
 * COMPATIBILITY: Unveil adds its own scene and replaces nothing. It extends
 * two engine methods, each by saving the original and calling it:
 * Game_System.initialize (its save record) and Game_Interpreter.updateWaitMode
 * (so the event waits while the game runs).
 *
 * TERMS OF USE: commercial and non-commercial use permitted in RPG Maker
 * projects, credit appreciated but not required. Do not redistribute the
 * source as an asset pack. Every line of this plugin was written with AI
 * assistance.
 *
 * @param cutSe
 * @text Sound: a cut begins
 * @type file
 * @dir audio/se
 * @default Cursor1
 *
 * @param claimSe
 * @text Sound: land revealed
 * @type file
 * @dir audio/se
 * @default Chime1
 *
 * @param hitSe
 * @text Sound: a life lost
 * @type file
 * @dir audio/se
 * @default Damage1
 *
 * @command unveil
 * @text Start Unveil
 * @desc Run the reveal minigame over one of your pictures. The event waits until it is over.
 *
 * @arg picture
 * @text Picture
 * @type file
 * @dir img/pictures
 * @default
 *
 * @arg stage
 * @text Veil
 * @type select
 * @option auto
 * @option silk
 * @option frost
 * @option lacquer
 * @default auto
 *
 * @arg target
 * @text Target (%)
 * @type number
 * @min 10
 * @max 95
 * @default 75
 *
 * @arg lives
 * @text Lives
 * @type number
 * @min 1
 * @max 9
 * @default 3
 *
 * @arg creatures
 * @text Creatures in the veil
 * @type number
 * @min 1
 * @max 4
 * @default 1
 *
 * @arg sparks
 * @text Sparks on the edge
 * @type number
 * @min 0
 * @max 6
 * @default 2
 *
 * @arg percentVariable
 * @text Variable: percent revealed
 * @type variable
 * @default 0
 *
 * @arg wonSwitch
 * @text Switch: won
 * @type switch
 * @default 0
 *
 * @arg seed
 * @text Seed (optional)
 * @desc Blank = a new game every time. A number or word = the same game every time.
 * @default
 */

var Unveil = Unveil || {};

(function (M) {
  'use strict';
  var NAME = 'Unveil', SCHEMA = 1;
  var raw = (typeof PluginManager !== 'undefined') ? PluginManager.parameters(NAME) : {};
  function num(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; var n = Number(v); return isFinite(n) ? n : d; }
  function str(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; return String(v).trim(); }
  M.params = { cutSe: str(raw.cutSe, 'Cursor1'), claimSe: str(raw.claimSe, 'Chime1'), hitSe: str(raw.hitSe, 'Damage1') };
  var _deps = null;
  function deps() {
    if (_deps) return _deps;
    var core = (typeof UnveilCore !== 'undefined') ? UnveilCore : null, draw = (typeof UnveilDraw !== 'undefined') ? UnveilDraw : null;
    if (!core || !draw) { if (!deps._w) { deps._w = true; console.error('Unveil: enable UnveilCore.js and UnveilDraw.js in the Plugin Manager too.'); } return null; }
    _deps = { core: core, draw: draw }; return _deps;
  }
  M.deps = deps;
  function fresh() { return { v: SCHEMA, played: 0, won: 0, best: 0 }; }
  M.record = function () {
    if (typeof $gameSystem === 'undefined' || !$gameSystem) return fresh();
    var s = $gameSystem._csafUnveil; if (!s || s.v == null) { s = fresh(); $gameSystem._csafUnveil = s; } return s;
  };
  var _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () { _Game_System_initialize.call(this); this._csafUnveil = fresh(); };
  M.request = function (args) {
    var d = deps(); if (!d) return null; args = args || {};
    var seedText = str(args.seed, ''), seed = seedText === '' ? d.core.mix(d.core.hashString('unveil') ^ (M.record().played * 7919), (typeof $gameSystem !== 'undefined' && $gameSystem ? $gameSystem.playtime() : 0) >>> 0)
      : (/^\d+$/.test(seedText) ? (Number(seedText) >>> 0) : d.core.hashString(seedText));
    var stage = str(args.stage, 'auto');
    return { seed: seed, picture: str(args.picture, ''), stage: d.draw.THEMES.indexOf(stage) >= 0 ? stage : null,
      target: Math.max(10, Math.min(95, Math.floor(num(args.target, 75)))), lives: Math.max(1, Math.min(9, Math.floor(num(args.lives, 3)))),
      creatures: Math.max(1, Math.min(4, Math.floor(num(args.creatures, 1)))), sparks: Math.max(0, Math.min(6, Math.floor(num(args.sparks, 2)))),
      percentVariable: Math.max(0, Math.floor(num(args.percentVariable, 0))), wonSwitch: Math.max(0, Math.floor(num(args.wonSwitch, 0))), isRequest: true };
  };
  /** Start a game (script call: the same options as the command). Without a picture it starts nothing and says so once. */
  M.start = function (opts) {
    var req = opts && opts.isRequest ? opts : M.request(opts || {});
    if (!req) return false;
    if (!req.picture) { if (!M._warnedPic) { M._warnedPic = true; console.warn('Unveil: name a picture from img/pictures in the command. No game started.'); } return false; }
    SceneManager.push(Scene_Unveil); SceneManager.prepareNextScene(req); return true;
  };
  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) PluginManager.registerCommand(NAME, 'unveil', function (args) { if (M.start(M.request(args))) this.setWaitMode('unveil'); });
  var _updateWaitMode = Game_Interpreter.prototype.updateWaitMode;
  Game_Interpreter.prototype.updateWaitMode = function () {
    if (this._waitMode === 'unveil') { if (SceneManager._scene instanceof Scene_Unveil || SceneManager._nextScene instanceof Scene_Unveil) return true; this._waitMode = ''; return false; }
    return _updateWaitMode.call(this);
  };
  M.VERSION = '1.0.0';
}(Unveil));

//=============================================================================
// Scene_Unveil
//=============================================================================

function Scene_Unveil() { this.initialize.apply(this, arguments); }
Scene_Unveil.prototype = Object.create(Scene_Message.prototype);
Scene_Unveil.prototype.constructor = Scene_Unveil;
Scene_Unveil.TOP = 56; Scene_Unveil.COLS = 96; Scene_Unveil.ROWS = 64; Scene_Unveil.MOVE_EVERY = 3;
Scene_Unveil.prototype.prepare = function (req) { this._req = req; };
Scene_Unveil.prototype.create = function () {
  Scene_Message.prototype.create.call(this);
  var d = Unveil.deps(), req = this._req; this._d = d;
  this._game = d.core.createGame(req.seed, { cols: Scene_Unveil.COLS, rows: Scene_Unveil.ROWS, target: req.target, lives: req.lives, creatures: req.creatures, sparks: req.sparks });
  this._theme = req.stage || d.draw.THEMES[req.seed % d.draw.THEMES.length];
  this._pic = ImageManager.loadPicture(req.picture);
  this._mode = 'loading'; this._t = 0; this._moveT = 0; this._lastDir = 0;
  this.createWindowLayer(); this.createAllWindows();
};
Scene_Unveil.prototype.start = function () {
  Scene_Message.prototype.start.call(this);
  var D = this._d.draw, W = Graphics.width, H = Graphics.height - Scene_Unveil.TOP, g = this._game, th = this._theme;
  this._cw = W / g.cols; this._ch = H / g.rows;
  var back = new Sprite(new Bitmap(Graphics.width, Graphics.height)); back.bitmap.fillAll('#08060a'); this.addChild(back);
  var pic = new Sprite(this._pic), k = Math.max(W / Math.max(1, this._pic.width), H / Math.max(1, this._pic.height));
  pic.scale.x = k; pic.scale.y = k; pic.x = (W - this._pic.width * k) / 2; pic.y = Scene_Unveil.TOP + (H - this._pic.height * k) / 2;
  var mask = new Sprite(new Bitmap(W, H)); mask.y = Scene_Unveil.TOP; mask.bitmap.fillAll('#ffffff'); pic.mask = mask; this.addChild(mask); this.addChild(pic);
  this._pristine = new Bitmap(W, H); D.veil(this._pristine.context, W, H, th, this._req.seed); this._pristine._baseTexture.update();
  this._veil = new Sprite(new Bitmap(W, H)); this._veil.y = Scene_Unveil.TOP; this.addChild(this._veil); this.redrawVeil();
  this._trail = new Sprite(new Bitmap(W, H)); this._trail.y = Scene_Unveil.TOP; this.addChild(this._trail); this._trailShown = -1;
  var cb = new Bitmap(64, 64); D.creature(cb.context, 64, th); cb._baseTexture.update();
  this._creatures = g.creatures.map(function (q) { var s = new Sprite(cb); s.anchor.x = 0.5; s.anchor.y = 0.5; return s; }, this);
  this._creatures.forEach(function (s) { this.addChild(s); }, this);
  var sb = new Bitmap(24, 24); D.spark(sb.context, 24, th); sb._baseTexture.update();
  this._sparks = g.sparks.map(function () { var s = new Sprite(sb); s.anchor.x = 0.5; s.anchor.y = 0.5; return s; });
  this._sparks.forEach(function (s) { this.addChild(s); }, this);
  var mb = new Bitmap(22, 22); D.marker(mb.context, 22, th); mb._baseTexture.update();
  this._marker = new Sprite(mb); this._marker.anchor.x = 0.5; this._marker.anchor.y = 0.5; this.addChild(this._marker);
  this._hud = new Sprite(new Bitmap(Graphics.width, Scene_Unveil.TOP)); this.addChild(this._hud); this._hudKey = -1; this.drawHud();
  this._results = new Sprite(); this._results.visible = false; this.addChild(this._results);
  this._mode = 'play'; this.startFadeIn(this.fadeSpeed(), false);
};
/** The veil minus the revealed land, with its rim: redrawn only when land is claimed (wing §34a). */
Scene_Unveil.prototype.redrawVeil = function () {
  var b = this._veil.bitmap; b.context.clearRect(0, 0, b.width, b.height); b.context.drawImage(this._pristine._canvas, 0, 0);
  this._d.draw.cut(b.context, this._game, this._cw, this._ch, this._theme); b._baseTexture.update(); this._claimedShown = this._game.claimed;
};
Scene_Unveil.prototype.drawHud = function () {
  var g = this._game, key = g.claimed * 16 + g.lives; if (key === this._hudKey) return; this._hudKey = key;
  var b = this._hud.bitmap; b.context.clearRect(0, 0, b.width, b.height);
  this._d.draw.hud(b.context, Graphics.width, this._theme, { percent: this._d.core.percent(g), target: g.target, lives: g.lives, livesMax: g.livesMax }); b._baseTexture.update();
};
Scene_Unveil.prototype.update = function () {
  Scene_Message.prototype.update.call(this);
  if (this._mode === 'loading' || this.isBusy()) return;
  this._t++;
  if (this._mode === 'play') this.updatePlay();
  else if (this._mode === 'results' && this._t > 30 && (Input.isTriggered('ok') || TouchInput.isTriggered())) this.leave();
};
/** Which way the player is steering this frame: arrows, or toward a pressed touch point along its longer axis. */
Scene_Unveil.prototype.steer = function () {
  var g = this._game;
  if (TouchInput.isPressed()) {
    var tx = Math.floor(TouchInput.x / this._cw), ty = Math.floor((TouchInput.y - Scene_Unveil.TOP) / this._ch), dx = tx - g.px, dy = ty - g.py;
    if (!dx && !dy) return this.magnet();
    return Math.abs(dx) >= Math.abs(dy) ? (dx > 0 ? 6 : 4) : (dy > 0 ? 2 : 8);
  }
  return Input.isPressed('left') ? 4 : Input.isPressed('right') ? 6 : Input.isPressed('up') ? 8 : Input.isPressed('down') ? 2 : 0;
};
/**
 * A finger that stops a cell or two short of revealed land while cutting still closes the cut onto it: keep the last
 * direction when claimed land lies within MAGNET cells ahead (2026-10-08 smoke: a drag to the screen's edge landed on
 * the cell inside the 8 px frame and the cut never closed).
 */
Scene_Unveil.MAGNET = 2;
Scene_Unveil.prototype.magnet = function () {
  var g = this._game, C = this._d.core, d = this._lastDir;
  if (!g.drawing || !d) return 0;
  var ux = d === 4 ? -1 : d === 6 ? 1 : 0, uy = d === 8 ? -1 : d === 2 ? 1 : 0;
  for (var k = 1; k <= Scene_Unveil.MAGNET; k++) { var c = C.at(g, g.px + ux * k, g.py + uy * k); if (c === C.CLAIMED) return d; if (c !== C.OPEN) return 0; }
  return 0;
};
Scene_Unveil.prototype.updatePlay = function () {
  var C = this._d.core, g = this._game, lives = g.lives;
  if (++this._moveT >= Scene_Unveil.MOVE_EVERY) {
    var dir = this.steer();
    if (dir) {
      this._moveT = 0; this._lastDir = dir;
      var draw = Input.isPressed('ok') || Input.isPressed('shift') || TouchInput.isPressed();
      var r = C.move(g, dir === 4 ? -1 : dir === 6 ? 1 : 0, dir === 8 ? -1 : dir === 2 ? 1 : 0, draw);
      if (r === 'cut' && g.trailLen === 1) AudioManager.playSe({ name: Unveil.params.cutSe, volume: 60, pitch: 100, pan: 0 });
      if (r === 'closed') AudioManager.playSe({ name: Unveil.params.claimSe, volume: 85, pitch: 100, pan: 0 });
    }
  }
  C.step(g);
  if (g.lives !== lives) AudioManager.playSe({ name: Unveil.params.hitSe, volume: 85, pitch: 100, pan: 0 });
  if (g.claimed !== this._claimedShown) this.redrawVeil();
  if (g.trailLen !== this._trailShown) { var tb = this._trail.bitmap; tb.context.clearRect(0, 0, tb.width, tb.height); this._d.draw.trail(tb.context, g, this._cw, this._ch, this._theme); tb._baseTexture.update(); this._trailShown = g.trailLen; }
  this.syncSprites(); this.drawHud();
  if (g.phase !== 'play') this.showResults();
};
/** Creatures spin, sparks flicker, the marker follows the player. No allocation. */
Scene_Unveil.prototype.syncSprites = function () {
  var g = this._game, top = Scene_Unveil.TOP, cw = this._cw, ch = this._ch;
  for (var i = 0; i < this._creatures.length; i++) { var s = this._creatures[i], q = g.creatures[i]; s.x = q.x * cw; s.y = top + q.y * ch; s.rotation += 0.06; }
  for (var j = 0; j < this._sparks.length; j++) { var p = this._sparks[j], k = g.sparks[j]; p.x = (k.x + 0.5) * cw; p.y = top + (k.y + 0.5) * ch; p.scale.x = p.scale.y = (g.frame + j) % 6 < 3 ? 1 : 0.8; }
  this._marker.x = (g.px + 0.5) * cw; this._marker.y = top + (g.py + 0.5) * ch;
};
Scene_Unveil.prototype.showResults = function () {
  var res = this._d.core.results(this._game), bmp = new Bitmap(Graphics.width, Graphics.height);
  this._d.draw.resultsPanel(bmp.context, Graphics.width, Graphics.height, this._theme, res); bmp._baseTexture.update();
  // won: the whole picture, nothing over it (2026-10-08 photograph: the creature and the marker still sat on the reveal)
  if (res.won) { this._veil.visible = false; this._trail.visible = false; this._marker.visible = false; this._creatures.forEach(function (s) { s.visible = false; }); this._sparks.forEach(function (s) { s.visible = false; }); }
  this._results.bitmap = bmp; this._results.visible = true; this._res = res; this._mode = 'results'; this._t = 0;
};
Scene_Unveil.prototype.leave = function () {
  var req = this._req, m = this._res, rec = Unveil.record();
  if (req.percentVariable > 0) $gameVariables.setValue(req.percentVariable, Math.floor(m.percent));
  if (req.wonSwitch > 0) $gameSwitches.setValue(req.wonSwitch, m.won);
  rec.played++; if (m.won) rec.won++; rec.best = Math.max(rec.best, Math.floor(m.percent));
  this.popScene();
};
Scene_Unveil.prototype.stop = function () { Scene_Message.prototype.stop.call(this); this.startFadeOut(this.fadeSpeed(), false); };
