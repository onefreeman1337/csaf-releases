//=============================================================================
// DerbyCore.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Derby core - generated snail stables, courses, a seeded
 * race model and calibrated odds. Place ABOVE DerbyDraw and Derby.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The race model and the bookmaker for Derby. No parameters or commands of its
 * own; Derby.js is the file you configure. Must be installed and listed above
 * Derby.js.
 *
 * Pure logic: nothing here touches the screen and nothing uses Math.random.
 * A race is a seed. The same card run from the same seed finishes in the same
 * order on every machine, and the odds on the board are measured from the same
 * race model the player watches.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var DerbyCore = (function () {
  'use strict';

  var LEN = 1000;          // course length in race units
  var BODY = 14;           // one snail length ("a shell") in race units
  var BASE = 3.2;          // units per tick at speed 1.0 on slate
  var MAX_TICKS = 1400;    // a race still running after this is ordered by distance (never observed)
  var CAL_N = 2000;        // races per calibration set
  var SLACK = 0.04;        // a bet may read at most Payback + 4% on the independent verification set
  var Z = 1.64;            // odds are priced on the upper bound of each chance (one-sided 95%)
  var CHASE = 1.03;        // late-chase multiplier (see tick)

  var COURSES = ['kitchen', 'rockery', 'greenhouse', 'orchard', 'mossbank'];
  var SURFACES = ['moss', 'slate', 'sand', 'puddle', 'leaf', 'gravel'];
  var GOINGS = ['dewy', 'damp', 'dry'];
  var PREFS = ['damp', 'dry', 'any'];
  var PATTERNS = ['bands', 'spots', 'flames', 'rays'];
  var CLOTHS = ['plain', 'hoops', 'halves', 'sash', 'quarters', 'chevron'];
  var SHELLS = 10, BODIES = 5, SILKS = 12;

  // Surface speed, and how each going preference moves it. Snails are faster where it is wet.
  // ⛔ MEASURED 2026-09-23 (_probe/odd_card.js): with a +0.20 / -0.12 puddle preference one damp-lover on a wet course
  // won 1,996 of 2,000 races and no price could be offered. A preference is now worth a few per cent over a course.
  var SURF_F = { moss: 1.07, slate: 1.0, sand: 0.86, puddle: 0.9, leaf: 0.95, gravel: 0.9 };
  var PREF_F = { damp: { moss: 0.03, puddle: 0.06, sand: -0.03 }, dry: { sand: 0.05, slate: 0.02, gravel: 0.03, puddle: -0.05 }, any: {} };
  var GOING_F = { dewy: { damp: 0.015, dry: -0.01, any: 0 }, damp: { damp: 0.008, dry: 0, any: 0 }, dry: { dry: 0.015, damp: -0.01, any: 0 } };
  var COURSE_MIX = {
    kitchen: ['slate', 'sand', 'moss', 'leaf', 'puddle', 'slate'],
    rockery: ['gravel', 'slate', 'moss', 'sand', 'gravel'],
    greenhouse: ['slate', 'puddle', 'moss', 'sand', 'leaf'],
    orchard: ['leaf', 'moss', 'gravel', 'slate', 'puddle', 'leaf'],
    mossbank: ['moss', 'puddle', 'leaf', 'slate', 'moss'],
  };
  var COURSE_NAMES = { kitchen: 'Kitchen Garden', rockery: 'Rockery', greenhouse: 'Greenhouse', orchard: 'Orchard', mossbank: 'Moss Bank' };
  var RACE_KINDS = ['Maiden Plate', 'Handicap', 'Stakes', 'Cup', 'Derby'];

  var FIRST = ['Morning', 'Silver', 'Garden', 'Midnight', 'Copper', 'Velvet', 'Thunder', 'Lazy', 'Dapper', 'Mossy', 'Rainy', 'Lucky',
    'Old', 'Little', 'Brave', 'Gentle', 'Sir', 'Lady', 'Captain', 'Duchess', 'Humble', 'Royal', 'Quiet', 'Wild', 'Sunday', 'Amber'];
  var SECOND = ['Dew', 'Trail', 'Spiral', 'Lettuce', 'Clover', 'Pebble', 'Drizzle', 'Comet', 'Thistle', 'Button', 'Bramble', 'Nettle',
    'Glimmer', 'Fern', 'Puddle', 'Marigold', 'Cabbage', 'Acorn', 'Buttercup', 'Hailstone', 'Whistle', 'Parsley', 'Rhubarb', 'Snowdrop'];
  var WHOLE = ['Slow Gin', 'Shell Shock', 'Lettuce Pray', 'Escargot', 'Snailblazer', 'Slime Time', 'Hot Trail', 'Spiral Arm', 'Leaf It Out',
    'Dew Or Die', 'Slow Burn', 'Trailblazer', 'Home Shell', 'Full Spiral', 'Nibbler', 'Soft Shoe', 'Damp Squib', 'Quicksilver'];

  // Fractional odds, shortest to longest. A price is always rounded DOWN this ladder, never up.
  var LADDER = [[1, 10], [1, 8], [1, 6], [1, 5], [2, 9], [1, 4], [2, 7], [1, 3], [4, 11], [2, 5], [4, 9], [1, 2], [8, 15], [4, 7], [8, 13],
    [4, 6], [8, 11], [4, 5], [5, 6], [10, 11], [1, 1], [11, 10], [6, 5], [5, 4], [11, 8], [6, 4], [13, 8], [7, 4], [15, 8], [2, 1], [9, 4],
    [5, 2], [11, 4], [3, 1], [10, 3], [7, 2], [4, 1], [9, 2], [5, 1], [11, 2], [6, 1], [13, 2], [7, 1], [15, 2], [8, 1], [9, 1], [10, 1],
    [11, 1], [12, 1], [14, 1], [16, 1], [20, 1], [25, 1], [33, 1], [40, 1], [50, 1]];

  function hashString(s) { var h = 0x811c9dc5; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h >>> 0; }
  function mix(a, b) { var h = Math.imul((a >>> 0) ^ Math.imul(b >>> 0, 0x9E3779B1), 0x85EBCA6B) >>> 0; h ^= h >>> 13; h = Math.imul(h, 0xC2B2AE35) >>> 0; return (h ^ (h >>> 16)) >>> 0; }
  function rng(seed) {
    var a = seed >>> 0;
    return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  /** The same generator as rng(), with its state held on an object so the race step allocates nothing. */
  function rnd(s) { s.a = (s.a + 0x6D2B79F5) >>> 0; var t = s.a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }
  function pick(r, a) { return a[Math.floor(r() * a.length) % a.length]; }
  function shuffle(r, a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(r() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }

  //===========================================================================
  // Stables: the runners a meeting draws its fields from
  //===========================================================================

  /**
   * A stable of runners. Each has a unique name, a look (shell, body, pattern, silks) and four hidden ratings.
   * @param {number} seed
   * @param {number} [size=12]
   * @returns {Array<Object>}
   */
  function makeStable(seed, size) {
    var n = Math.max(5, Math.min(16, Math.floor(Number(size) || 12)));
    var r = rng(mix(seed >>> 0, 0x57AB1E)), used = {}, out = [];
    for (var i = 0; i < n; i++) {
      var name = '', tries = 0;
      do { name = r() < 0.3 ? pick(r, WHOLE) : pick(r, FIRST) + ' ' + pick(r, SECOND); } while (used[name] && ++tries < 40);
      used[name] = true;
      var s1 = Math.floor(r() * SILKS), s2 = (s1 + 1 + Math.floor(r() * (SILKS - 1))) % SILKS;
      out.push({
        id: i, name: name,
        look: { shell: Math.floor(r() * SHELLS), body: Math.floor(r() * BODIES), pattern: pick(r, PATTERNS), tight: Math.round((0.16 + r() * 0.1) * 1000) / 1000,
          bands: 2 + Math.floor(r() * 4), silk: [s1, s2], cloth: pick(r, CLOTHS), seed: mix(seed, 0x100 + i) },
        speed: Math.round((0.98 + r() * 0.04) * 1000) / 1000,
        stamina: Math.round(r() * 1000) / 1000,
        surge: Math.round(r() * 1000) / 1000,
        temper: Math.round(r() * 1000) / 1000,
        pref: pick(r, PREFS),
      });
    }
    return out;
  }

  /** A course: a theme and 4-6 sections of surface along its length. */
  function makeCourse(seed, theme) {
    var r = rng(mix(seed >>> 0, 0xC0053));
    var th = COURSES.indexOf(theme) >= 0 ? theme : pick(r, COURSES);
    var mixList = COURSE_MIX[th], k = 4 + Math.floor(r() * 3), cuts = [];
    for (var i = 0; i < k - 1; i++) cuts.push(0.12 + r() * 0.76);
    cuts.sort(function (a, b) { return a - b; });
    // no section shorter than 6% of the course: merge cuts that crowd each other
    var clean = []; for (var c = 0; c < cuts.length; c++) if (!clean.length || cuts[c] - clean[clean.length - 1] > 0.06) clean.push(cuts[c]);
    var sections = [], from = 0, last = '';
    for (var s = 0; s <= clean.length; s++) {
      var to = s < clean.length ? Math.round(clean[s] * LEN) : LEN, surf, t = 0;
      do { surf = pick(r, mixList); } while (surf === last && ++t < 10);
      sections.push({ from: from, to: to, surface: surf }); from = to; last = surf;
    }
    return { theme: th, name: COURSE_NAMES[th], len: LEN, sections: sections };
  }

  //===========================================================================
  // The race. tick() is the ONLY race model: the scene calls it, the bookmaker
  // calls it thousands of times to price the card, and the tests call it; all
  // three agree by construction.
  //===========================================================================

  function terrainFactor(runner, surface, going) {
    var f = SURF_F[surface] + (PREF_F[runner.pref][surface] || 0) + (GOING_F[going][runner.pref] || 0);
    return f;
  }

  /**
   * Allocate a race for a field on a course. Everything the step needs is created here, once.
   * @param {Array<Object>} field runners from a stable
   * @param {Object} course from makeCourse
   * @param {string} going 'dewy'|'damp'|'dry'
   */
  function makeRace(field, course, going) {
    var n = field.length, rs = [];
    for (var i = 0; i < n; i++) {
      var f = field[i], tf = [];
      for (var s = 0; s < course.sections.length; s++) tf.push(terrainFactor(f, course.sections[s].surface, going));
      rs.push({ id: f.id, speed: f.speed, stamina: f.stamina, pSurge: 0.004 + 0.01 * f.surge, pStall: 0.002 + 0.008 * f.temper, tf: tf,
        x: 0, prevX: 0, v: 0, vFin: 0, st: 0, stT: 0, n: 0, fin: -1, a: 0, sec: 0 });
    }
    var order = []; for (var k = 0; k < n; k++) order.push(-1);
    return { n: n, course: course, going: going, runners: rs, order: order, nFin: 0, t: 0, leader: -1, leadChanges: 0, leadX: 0, done: false, capped: false, seed: 0 };
  }

  /** Reset a race to the start under a new seed. Allocates nothing. */
  function resetRace(race, seed) {
    race.t = 0; race.nFin = 0; race.leader = -1; race.leadChanges = 0; race.done = false; race.seed = seed >>> 0; race.leadX = 0; race.capped = false;
    for (var i = 0; i < race.n; i++) {
      var s = race.runners[i];
      s.x = 0; s.prevX = 0; s.v = 0; s.vFin = 0; s.st = 0; s.stT = 0; s.n = 0; s.fin = -1; s.sec = 0; s.a = mix(seed, 0xA11 + s.id);
      race.order[i] = -1;
    }
    return race;
  }

  /**
   * Advance the race one tick. No allocation. @returns {boolean} true once every runner has crossed the line
   * State per runner: 0 running, 1 surging (x1.22 for 18-39 ticks), 2 stopped to nibble (x0.35 for 8-23 ticks).
   */
  function tick(race) {
    if (race.done) return true;
    var rs = race.runners, secs = race.course.sections, n = race.n, i;
    race.t++;
    for (i = 0; i < n; i++) {
      var s = rs[i];
      if (s.fin >= 0) { s.prevX = s.x; if (s.x < LEN + 70) s.x += s.v * 0.35; continue; }
      while (s.sec < secs.length - 1 && s.x >= secs[s.sec].to) s.sec++;
      var leafy = secs[s.sec].surface === 'leaf';
      if (s.st === 0) {
        var u = rnd(s);
        if (u < s.pSurge) { s.st = 1; s.stT = 18 + Math.floor(rnd(s) * 22); }
        else if (u < s.pSurge + s.pStall * (leafy ? 2 : 1)) { s.st = 2; s.stT = 8 + Math.floor(rnd(s) * 16); }
      } else if (--s.stT <= 0) s.st = 0;
      var m = s.st === 1 ? 1.22 : (s.st === 2 ? 0.35 : 1);
      var prog = s.x / LEN, fat = prog > 0.55 ? 1 - (1 - s.stamina) * 0.1 * (prog - 0.55) / 0.45 : 1;
      // the late chase: in the last quarter a runner within three shells of the leader finds a little more
      var gap = race.leadX - s.x;
      if (prog > 0.75 && gap > 0.5 && gap < 3 * BODY) m *= CHASE;
      s.n = s.n * 0.92 + (rnd(s) - 0.5) * 0.05;
      var v = BASE * s.speed * s.tf[s.sec] * m * fat * (1 + s.n);
      s.v = v; s.prevX = s.x; s.x += v;
      if (s.x >= LEN) {
        s.fin = race.t - 1 + (LEN - s.prevX) / v; s.vFin = v;
        // insert into the finishing order by exact crossing time (a later index can cross earlier inside one tick)
        var k = race.nFin++;
        while (k > 0 && rs[race.order[k - 1]].fin > s.fin) { race.order[k] = race.order[k - 1]; k--; }
        race.order[k] = i;
      }
    }
    // the leader: furthest along, finished runners first by crossing order
    var lead = race.nFin > 0 ? race.order[0] : 0;
    if (race.nFin === 0) for (i = 1; i < n; i++) if (rs[i].x > rs[lead].x) lead = i;
    if (lead !== race.leader) { if (race.leader >= 0 && race.t > 20 && race.nFin === 0) race.leadChanges++; race.leader = lead; }
    race.leadX = rs[lead].x;
    if (race.nFin === n || race.t >= MAX_TICKS) {
      if (race.nFin < n) {
        // never observed: order the rest by distance so a result always exists
        for (i = 0; i < n; i++) if (rs[i].fin < 0) { rs[i].fin = race.t + (LEN - rs[i].x) / Math.max(0.01, rs[i].v || 0.01); rs[i].vFin = rs[i].v; var q = race.nFin++; while (q > 0 && rs[race.order[q - 1]].fin > rs[i].fin) { race.order[q] = race.order[q - 1]; q--; } race.order[q] = i; }
        race.capped = true;
      }
      race.done = true;
    }
    return race.done;
  }

  /** Run a race to the end from a seed. @returns {Object} the race (read .order, .runners[i].fin) */
  function runRace(race, seed) { resetRace(race, seed); while (!tick(race)) { /* stepping */ } return race; }

  /**
   * The winning margin between two placings, in snail lengths ("shells"): the distance the second runner still
   * had to cover when the first crossed.
   */
  function marginAt(race, place) {
    if (place + 1 >= race.n) return 0;
    var a = race.runners[race.order[place]], b = race.runners[race.order[place + 1]];
    return Math.max(0, (b.fin - a.fin) * (b.vFin || BASE)) / BODY;
  }

  /** Words for a margin. @returns {string} */
  function marginWords(m) {
    if (m < 0.05) return 'a whisker';
    if (m < 0.12) return 'a stalk';
    if (m < 0.25) return 'a head';
    if (m < 0.5) return 'half a shell';
    if (m < 0.8) return 'three-quarters of a shell';
    if (m < 1.5) return 'a shell';
    if (m < 12) return (Math.round(m * 2) / 2) + ' shells';
    return 'a distance';
  }

  //===========================================================================
  // The bookmaker
  //===========================================================================

  /** How many places a Place bet pays on a field of n. */
  function placeTerms(n) { return n >= 8 ? 3 : (n >= 5 ? 2 : 1); }

  function priceFor(pUpper, payback) {
    if (!(pUpper > 0)) return LADDER.length - 1;
    var want = payback / pUpper, best = -1;
    for (var i = 0; i < LADDER.length; i++) { var dec = 1 + LADDER[i][0] / LADDER[i][1]; if (dec <= want + 1e-9) best = i; else break; }
    return best; // -1 = no price can be offered at this payback (a near-certainty)
  }
  function dec(rung) { return rung < 0 ? 0 : 1 + LADDER[rung][0] / LADDER[rung][1]; }

  /** Count wins and places for one set of races into a tally object. */
  function newTally(n) { var t = { N: 0, win: [], place: [], photo: 0, lc: 0 }; for (var i = 0; i < n; i++) { t.win.push(0); t.place.push(0); } return t; }
  function tallyOne(race, t) {
    var k = placeTerms(race.n);
    t.win[race.order[0]]++; for (var i = 0; i < k; i++) t.place[race.order[i]]++;
    if (marginAt(race, 0) < 0.25) t.photo++;
    t.lc += race.leadChanges; t.N++;
  }
  /** Run N races from a seed stream and tally them (tests and probes; the book uses workBook). */
  function tally(race, seedBase, N) { var t = newTally(race.n); for (var j = 0; j < N; j++) { runRace(race, mix(seedBase, j)); tallyOne(race, t); } return t; }

  /**
   * Draw a card for one race and open its book, UNPRICED. Pricing is measured, not guessed, and takes 2 x CAL_N
   * races of the same model the player watches, so it is spread over frames: call workBook(card, budget) until it
   * returns true (the scene chalks the board while it works), or use makeCard() to do it all at once.
   * @param {Array<Object>} stable
   * @param {Object} opt {seed, raceNo?, fieldSize?: 5..8, course?: theme, going?, payback?: 0.5..1.0, kind?}
   */
  function openBook(stable, opt) {
    opt = opt || {};
    var seed = Number(opt.seed) >>> 0, raceNo = Math.max(0, Math.floor(Number(opt.raceNo) || 0));
    var cs = mix(seed, 0xCA2D + raceNo), r = rng(cs);
    var nWant = [5, 6, 7, 8].indexOf(Number(opt.fieldSize)) >= 0 ? Number(opt.fieldSize) : 6 + Math.floor(r() * 3);
    var n = Math.min(nWant, stable.length);
    var idx = shuffle(r, stable.map(function (s, i) { return i; })).slice(0, n);
    var field = idx.map(function (i) { return stable[i]; });
    var course = makeCourse(cs, COURSES.indexOf(opt.course) >= 0 ? opt.course : null);
    var going = GOINGS.indexOf(opt.going) >= 0 ? opt.going : pick(r, GOINGS);
    var payback = Math.max(0.5, Math.min(1.0, Number(opt.payback) || 0.85));
    var kind = opt.kind || RACE_KINDS[raceNo % RACE_KINDS.length];
    var card = { v: 1, seed: seed, raceNo: raceNo, kind: kind, name: 'The ' + course.name + ' ' + kind, field: field, course: course, going: going,
      payback: payback, placeTerms: placeTerms(n), win: [], place: [], raceSeed: mix(cs, 0x5EED), calibrationRaces: CAL_N, priced: false };
    for (var i = 0; i < n; i++) { card.win.push(-1); card.place.push(-1); }
    // the working state is NOT enumerable, so a card saved or copied carries the prices and not the scratch race
    Object.defineProperty(card, '_book', { value: { phase: 'cal', j: 0, race: makeRace(field, course, going), t: newTally(n), steps: 0 }, writable: true, enumerable: false, configurable: true });
    return card;
  }

  /**
   * Run up to `budget` races of pricing work. Phase 1 counts CAL_N races and prices every bet on the UPPER bound of
   * its chance, rounded DOWN the ladder. Phase 2 counts a second, independent CAL_N races and shortens any bet that
   * still reads over Payback + 4% there, re-counting after each shortening (at most 6 times).
   * @returns {boolean} true once the card is priced
   */
  function workBook(card, budget) {
    var bk = card._book; if (!bk || card.priced) return true;
    var n = card.field.length, left = Math.max(1, Math.floor(Number(budget) || CAL_N));
    while (left > 0) {
      var base = bk.phase === 'cal' ? mix(card.raceSeed, 0xCA11) : mix(card.raceSeed, 0x7E57 + bk.steps * 0x101);
      runRace(bk.race, mix(base, bk.j)); tallyOne(bk.race, bk.t); bk.j++; left--;
      if (bk.j < CAL_N) continue;
      var t = bk.t, i;
      if (bk.phase === 'cal') {
        for (i = 0; i < n; i++) {
          var pw = t.win[i] / CAL_N, pp = t.place[i] / CAL_N;
          card.win[i] = priceFor(pw + Z * Math.sqrt(Math.max(pw * (1 - pw), 1 / CAL_N) / CAL_N), card.payback);
          card.place[i] = card.placeTerms >= 2 ? priceFor(pp + Z * Math.sqrt(Math.max(pp * (1 - pp), 1 / CAL_N) / CAL_N), card.payback) : -1;
        }
        card.calibration = { photo: Math.round(t.photo / CAL_N * 1000) / 1000, leadChanges: Math.round(t.lc / CAL_N * 100) / 100 };
        bk.phase = 'ver';
      } else {
        var best = 0, sum = 0, cnt = 0, over = 0;
        for (i = 0; i < n; i++) for (var b = 0; b < 2; b++) {
          var rung = b === 0 ? card.win[i] : card.place[i]; if (rung < 0) continue;
          var ret = (b === 0 ? t.win[i] : t.place[i]) / CAL_N * dec(rung);
          best = Math.max(best, ret); sum += ret; cnt++;
          // ⛔ no standard-error allowance here: the bound is on the reading itself (Pinfall's "best minus se" let
          // a longshot through at Payback + slack + se; a stricter check only ever shortens a price)
          if (ret > card.payback + SLACK && bk.steps < 6) { if (b === 0) card.win[i]--; else card.place[i]--; over++; }
        }
        card.verified = { bestReturn: Math.round(best * 1000) / 1000, meanReturn: Math.round((cnt ? sum / cnt : 0) * 1000) / 1000, steps: bk.steps, races: CAL_N };
        if (!over) { card.priced = true; card._book = null; return true; }
        bk.steps++;
      }
      bk.j = 0; bk.t = newTally(n);
    }
    return false;
  }

  /** Draw and fully price a card in one call (about 2 x CAL_N races). */
  function makeCard(stable, opt) { var c = openBook(stable, opt); workBook(c, Infinity); return c; }

  /** @returns {string} a fractional price, e.g. "5/2", "Evens", or "-" when no price is offered */
  function priceText(rung) { if (rung < 0) return '-'; var f = LADDER[rung]; return f[0] === 1 && f[1] === 1 ? 'Evens' : f[0] + '/' + f[1]; }

  /**
   * What a bet returns (stake included) once the race is run. A losing bet returns 0.
   * @param {Object} card @param {Object} race a finished race @param {{runner:number, type:'win'|'place', stake:number}} bet
   */
  function settle(card, race, bet) {
    if (!bet || !(bet.stake > 0)) return 0;
    var pos = -1; for (var i = 0; i < race.n; i++) if (race.order[i] === bet.runner) pos = i;
    if (bet.type === 'place') return pos >= 0 && pos < card.placeTerms && card.place[bet.runner] >= 0 ? Math.floor(bet.stake * dec(card.place[bet.runner])) : 0;
    return pos === 0 && card.win[bet.runner] >= 0 ? Math.floor(bet.stake * dec(card.win[bet.runner])) : 0;
  }

  /**
   * The form a stable brings to its first meeting: each runner's placings in six earlier races, run by this same
   * model on generated courses (so the form figures are informative, not decoration). Most recent last.
   * @returns {Object<number, number[]>} runner id -> finishing positions (1 = won)
   */
  function initialForm(stable, seed) {
    var form = {}, r = rng(mix(seed >>> 0, 0xF0F0));
    stable.forEach(function (s) { form[s.id] = []; });
    for (var k = 0; k < 6; k++) {
      var n = Math.min(stable.length, 6 + Math.floor(r() * 3));
      var field = shuffle(r, stable.slice()).slice(0, n), course = makeCourse(mix(seed, 0xF000 + k), null), going = pick(r, GOINGS);
      var race = runRace(makeRace(field, course, going), mix(seed, 0xF100 + k));
      for (var p = 0; p < n; p++) form[field[race.order[p]].id].push(p + 1);
    }
    return form;
  }

  return {
    VERSION: '1.0.0', LEN: LEN, BODY: BODY, BASE: BASE, MAX_TICKS: MAX_TICKS, CAL_N: CAL_N, SLACK: SLACK, Z: Z,
    COURSES: COURSES, SURFACES: SURFACES, GOINGS: GOINGS, PREFS: PREFS, PATTERNS: PATTERNS, CLOTHS: CLOTHS, SHELLS: SHELLS, BODIES: BODIES, SILKS: SILKS,
    LADDER: LADDER, RACE_KINDS: RACE_KINDS, COURSE_NAMES: COURSE_NAMES,
    hashString: hashString, mix: mix, rng: rng, makeStable: makeStable, makeCourse: makeCourse, makeRace: makeRace, resetRace: resetRace,
    tick: tick, runRace: runRace, marginAt: marginAt, marginWords: marginWords, placeTerms: placeTerms, makeCard: makeCard, openBook: openBook, workBook: workBook, dec: dec,
    priceText: priceText, settle: settle, initialForm: initialForm, terrainFactor: terrainFactor, tally: tally,
  };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = DerbyCore;
