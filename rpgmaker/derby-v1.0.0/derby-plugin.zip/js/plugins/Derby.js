//=============================================================================
// Derby.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Derby - a race meeting the player can bet on: generated
 * snail runners with real form, garden courses, measured odds, a photo finish
 * and a payout. Place BELOW DerbyCore and DerbyDraw.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * Derby
 * ============================================================================
 *
 * A snail-racing meeting for your game's fairground, tavern garden or noble's
 * lawn. The player reads a race card (every runner's form, the going it likes,
 * its silks and its price), places a Win or Place bet, and watches the race
 * run on a drawn garden course: moss, slate, sand, puddles, leaf litter and
 * gravel, each suiting some runners more than others. Close finishes go to
 * the judge's photograph. Winnings are paid in gold.
 *
 * Everything is GENERATED from a seed: the stable of runners (names, shells,
 * body colours, shell patterns, silks), each race's field, course, going and
 * prices. Nothing is loaded from an image file.
 *
 * THE PRICES ARE MEASURED, NOT GUESSED. When a card is drawn, the bookmaker
 * runs the SAME race model the player watches 2,000 times, counts how often
 * each runner wins and places, prices every bet on the upper bound of that
 * chance and rounds it DOWN a ladder of traditional prices (5/2, 7/4, Evens
 * ...). A second, independent 2,000 races then check the prices, and any bet
 * that still reads over your Payback setting plus 4% is shortened. The
 * pricing uses about a millisecond of each frame while the player reads the
 * card, and the prices are chalked up when it finishes; the card for each
 * later race of a visit is priced while the race before it is being run. The
 * form figures are real results from the same model, so reading them pays.
 *
 * ----------------------------------------------------------------------------
 * INSTALLING
 * ----------------------------------------------------------------------------
 * Plugin Manager order, top to bottom:
 *
 *     DerbyCore.js     (the stables, courses, race model and bookmaker)
 *     DerbyDraw.js     (the drawing)
 *     Derby.js         (this file: parameters, the command, the scene)
 *
 * ----------------------------------------------------------------------------
 * USING IT
 * ----------------------------------------------------------------------------
 * Add the plugin command "Open Race Meeting" to an event. Choose how many
 * races one visit runs, the field size, the course, the going, the stakes
 * and the payback. The event waits while the player is at the course; the
 * net winnings of the visit can be stored in a variable.
 *
 * Leave the seed blank and the meeting is keyed to its map and event: the
 * same stable of runners every visit, their form carrying on from the races
 * the player has watched. With "Fresh races after loading" on (the default),
 * a race is drawn when the player arrives, so reloading a save cannot replay
 * a race whose winner the player already knows.
 *
 * ----------------------------------------------------------------------------
 * CONTROLS
 * ----------------------------------------------------------------------------
 * On the card: up / down choose a runner, left / right change the stake,
 * Shift (or Q / W) switches between Win and Place, OK starts the race,
 * Escape leaves. During the race hold OK to watch at triple speed.
 * Mouse and touch: click a runner, the Win / Place tabs, the - / + buttons,
 * "Off they go!" and "Leave the course".
 *
 * ----------------------------------------------------------------------------
 * COMPATIBILITY
 * ----------------------------------------------------------------------------
 * Derby adds its own scene and replaces nothing. It extends one engine method
 * (Game_System.initialize) to create its save record, calling the original
 * first. Stakes and winnings use the party's gold.
 *
 * ============================================================================
 * TERMS OF USE
 * ============================================================================
 * Commercial and non-commercial use permitted in RPG Maker projects, credit
 * appreciated but not required. Do not redistribute the source as an asset
 * pack. Every line of this plugin was written with AI assistance.
 *
 * ============================================================================
 *
 * @param freshAfterLoad
 * @text Fresh races after loading
 * @type boolean
 * @on Yes
 * @off No
 * @desc Yes = a race is drawn when the player arrives, so reloading a save cannot replay a known result.
 * @default true
 *
 * @param startSe
 * @text Sound: the off
 * @type file
 * @dir audio/se
 * @default Bell3
 *
 * @param finishSe
 * @text Sound: the finish
 * @type file
 * @dir audio/se
 * @default Applause1
 *
 * @param winSe
 * @text Sound: a winning bet
 * @type file
 * @dir audio/se
 * @default Coin
 *
 * @param cursorSe
 * @text Sound: card cursor
 * @type file
 * @dir audio/se
 * @default Cursor2
 *
 * @command open
 * @text Open Race Meeting
 * @desc Open a race meeting. The event waits until the player leaves.
 *
 * @arg races
 * @text Races per visit
 * @type number
 * @min 1
 * @max 5
 * @default 3
 *
 * @arg fieldSize
 * @text Runners per race
 * @type select
 * @option auto
 * @option 5
 * @option 6
 * @option 7
 * @option 8
 * @default auto
 *
 * @arg course
 * @text Course
 * @type select
 * @option auto
 * @option kitchen
 * @option rockery
 * @option greenhouse
 * @option orchard
 * @option mossbank
 * @default auto
 *
 * @arg going
 * @text Going
 * @type select
 * @option auto
 * @option dewy
 * @option damp
 * @option dry
 * @default auto
 *
 * @arg minStake
 * @text Smallest stake (gold)
 * @type number
 * @min 1
 * @default 10
 *
 * @arg maxStake
 * @text Largest stake (gold)
 * @type number
 * @min 1
 * @default 100
 *
 * @arg stakeStep
 * @text Stake step (gold)
 * @type number
 * @min 1
 * @default 10
 *
 * @arg payback
 * @text Payback (%)
 * @type number
 * @min 50
 * @max 100
 * @desc Every price is set so a bet returns about this share of its stake over many races (checked to at most this plus 4%).
 * @default 85
 *
 * @arg variableId
 * @text Variable: net winnings of the visit
 * @type variable
 * @default 0
 *
 * @arg title
 * @text Meeting name
 * @desc Shown on the race card. Blank = named after the course.
 * @default
 *
 * @arg seed
 * @text Seed (optional)
 * @desc Blank = keyed to this map and event.
 * @default
 */

var Derby = Derby || {};

(function (M) {
  'use strict';
  var NAME = 'Derby', SCHEMA = 1;
  var raw = (typeof PluginManager !== 'undefined') ? PluginManager.parameters(NAME) : {};
  function num(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; var n = Number(v); return isFinite(n) ? n : d; }
  function str(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; return String(v).trim(); }
  function bool(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; return String(v).trim() === 'true'; }
  M.params = { freshAfterLoad: bool(raw.freshAfterLoad, true), startSe: str(raw.startSe, 'Bell3'), finishSe: str(raw.finishSe, 'Applause1'),
    winSe: str(raw.winSe, 'Coin'), cursorSe: str(raw.cursorSe, 'Cursor2') };

  var _deps = null;
  function deps() {
    if (_deps) return _deps;
    var core = (typeof DerbyCore !== 'undefined') ? DerbyCore : null, draw = (typeof DerbyDraw !== 'undefined') ? DerbyDraw : null;
    if (!core || !draw) { if (!deps._w) { deps._w = true; console.error('Derby: DerbyCore.js and DerbyDraw.js must both be installed and listed ABOVE Derby.js.'); } return null; }
    _deps = { core: core, draw: draw }; return _deps;
  }
  M.deps = deps;

  function fresh() { return { v: SCHEMA, meetings: {} }; }
  function store() {
    if (typeof $gameSystem === 'undefined' || !$gameSystem) return fresh();
    var s = $gameSystem._csafDerby; if (!s || s.v == null) { s = fresh(); $gameSystem._csafDerby = s; }
    if (!s.meetings) s.meetings = {}; return s;
  }
  M.store = store;
  M.keyFor = function (mapId, eventId) { return 'm' + Number(mapId) + 'e' + Number(eventId); };

  /**
   * A meeting's record: races run, the player's net, and every runner's form (placings, most recent last).
   * @returns {{races:number, net:number, form:Object}}
   */
  M.record = function (key) {
    var m = store().meetings[String(key)];
    if (!m) { m = { races: 0, net: 0, form: null }; store().meetings[String(key)] = m; }
    return m;
  };

  var _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () { _Game_System_initialize.call(this); this._csafDerby = fresh(); };

  /** Build a visit request from command arguments. Returns null if the sibling plugins are missing. */
  M.request = function (args, key, mapId, eventId) {
    var d = deps(); if (!d) return null; args = args || {};
    var seedText = str(args.seed, '');
    var seed = seedText === '' ? d.core.hashString(key) : (/^\d+$/.test(seedText) ? (Number(seedText) >>> 0) : d.core.hashString(seedText));
    var minS = Math.max(1, Math.floor(num(args.minStake, 10))), maxS = Math.max(minS, Math.floor(num(args.maxStake, 100)));
    var course = str(args.course, 'auto'), going = str(args.going, 'auto'), field = str(args.fieldSize, 'auto');
    return { key: key, seed: seed, races: Math.max(1, Math.min(5, Math.floor(num(args.races, 3)))),
      fieldSize: field === 'auto' ? null : Number(field), course: course === 'auto' ? null : course, going: going === 'auto' ? null : going,
      minStake: minS, maxStake: maxS, stakeStep: Math.max(1, Math.floor(num(args.stakeStep, 10))),
      payback: Math.max(50, Math.min(100, num(args.payback, 85))) / 100, variableId: Math.max(0, Math.floor(num(args.variableId, 0))),
      title: str(args.title, ''), mapId: mapId, eventId: eventId, explicitSeed: seedText !== '' };
  };

  /** The stable a meeting races: fixed by the meeting's seed. */
  M.stable = function (req) { return deps().core.makeStable(req.seed, 12); };

  /**
   * Open the card for the next race of a visit (unpriced; the scene prices it over frames).
   * The race seed mixes the meeting, its race counter and, with "Fresh races after loading", the play time
   * in seconds when the player arrived, so a reloaded save draws a different race.
   */
  M.nextCard = function (req, stable, raceIdx, arrival) {
    var d = deps(), rec = M.record(req.key);
    var visit = M.params.freshAfterLoad && !req.explicitSeed ? d.core.mix(req.seed, arrival >>> 0) : req.seed;
    var last = raceIdx === req.races - 1 && req.races > 1;
    var kind = last ? 'Derby' : d.core.RACE_KINDS[rec.races % 4];
    return d.core.openBook(stable, { seed: visit, raceNo: rec.races, fieldSize: req.fieldSize, course: req.course, going: req.going, payback: req.payback, kind: kind });
  };

  M.open = function (req) { if (!req) return false; SceneManager.push(Scene_Derby); SceneManager.prepareNextScene(req); return true; };

  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
    PluginManager.registerCommand(NAME, 'open', function (args) {
      var mapId = this._mapId || ($gameMap ? $gameMap.mapId() : 0), eventId = this.eventId ? this.eventId() : 0;
      var seedText = str(args.seed, ''), key = seedText === '' ? M.keyFor(mapId, eventId) : 's' + seedText;
      M.open(M.request(args, key, mapId, eventId));
    });
  }
  M.VERSION = '1.0.0'; M.SCHEMA = SCHEMA;
}(Derby));

//=============================================================================
// Scene_Derby
//=============================================================================

function Scene_Derby() { this.initialize.apply(this, arguments); }
Scene_Derby.prototype = Object.create(Scene_Base.prototype);
Scene_Derby.prototype.constructor = Scene_Derby;
// ⛔ MEASURED by mz_gate 2026-09-23: a fixed 30 pricing races a frame cost 2.3 ms of update time (budget 2 ms). The book
// now works in 1 ms slices, and the NEXT race's card is priced during the current race, whose frames cost ~0.03 ms.
Scene_Derby.BOOK_MS = 1.0;      // pricing time per frame
Scene_Derby.BOOK_STEP = 4;      // races per clock check inside a slice
Scene_Derby.TICK_FRAMES = 2;    // frames per race tick at normal speed
Scene_Derby.PX = 2.4;           // pixels per race unit on the course strip
Scene_Derby.START_X = 150;      // where the start line sits on the strip
Scene_Derby.VIEW_Y = 72;        // top of the course view
Scene_Derby.VIEW_H = 500;       // height of the course view
Scene_Derby.BOARD_W = 46;       // the lane board at the left edge
Scene_Derby.EDGE_H = 20;        // foreground strip under the lanes

Scene_Derby.prototype.prepare = function (req) { this._req = req; };

Scene_Derby.prototype.create = function () {
  Scene_Base.prototype.create.call(this);
  var d = Derby.deps(); this._d = d;
  this._rec = Derby.record(this._req.key);
  this._stable = Derby.stable(this._req);
  if (!this._rec.form) this._rec.form = d.core.initialForm(this._stable, this._req.seed);
  this._arrival = (typeof $gameSystem !== 'undefined' && $gameSystem) ? $gameSystem.playtime() : 0;
  this._raceIdx = 0; this._net = 0; this._frame = 0; this._mode = 'card'; this._wait = 0;
  this._cardLayer = new Sprite(); this._raceLayer = new Sprite();
  this.addChild(this._cardLayer); this.addChild(this._raceLayer);
  this.createCardStatic();
  this.createPlates();
  this.newCard();
};
Scene_Derby.prototype.start = function () { Scene_Base.prototype.start.call(this); this.startFadeIn(this.fadeSpeed(), false); };

Scene_Derby.prototype.purse = function () { return (typeof $gameParty !== 'undefined' && $gameParty) ? $gameParty.gold() : 0; };
Scene_Derby.prototype.playSe = function (n) { if (n && typeof AudioManager !== 'undefined') AudioManager.playSe({ name: n, volume: 80, pitch: 100, pan: 0 }); };
Scene_Derby.prototype.meetingName = function () { return this._req.title || (this._card ? this._card.course.name + ' Races' : 'Race Meeting'); };

//---------------------------------------------------------------------------- the card

/** The table and the fixed furniture of the card screen, drawn once per visit. */
Scene_Derby.prototype.createCardStatic = function () {
  var W = Graphics.width, H = Graphics.height, d = this._d;
  var table = new Bitmap(W, H); d.draw.drawTable(table.context, W, H); table._baseTexture.update();
  this._cardLayer.addChild(new Sprite(table));
  this._cardSprite = new Sprite(new Bitmap(528, H - 24)); this._cardSprite.x = 12; this._cardSprite.y = 12; this._cardLayer.addChild(this._cardSprite);
  this._pick = new Sprite(new Bitmap(496, 60)); this._pick.x = 28; this._cardLayer.addChild(this._pick);
  this._mapSprite = new Sprite(new Bitmap(256, 124)); this._mapSprite.x = 548; this._mapSprite.y = 10; this._cardLayer.addChild(this._mapSprite);
  this._slip = new Sprite(new Bitmap(256, 344)); this._slip.x = 548; this._slip.y = 138; this._cardLayer.addChild(this._slip);
  this._hint = new Sprite(new Bitmap(256, 130)); this._hint.x = 548; this._hint.y = 486; this._cardLayer.addChild(this._hint);
  var h = this._hint.bitmap.context; h.font = 'italic 13px ' + d.draw.FACE; h.fillStyle = '#c9a878'; h.textAlign = 'center'; h.textBaseline = 'middle';
  ['up / down  choose a runner', 'left / right  change the stake', 'Shift  Win or Place', 'OK  off they go    Esc  leave'].forEach(function (s, i) { h.fillText(s, 128, 18 + i * 22); });
  this._hint.bitmap._baseTexture.update();
};

/**
 * The photograph and the result board: allocated ONCE per visit, and the board's table and paper painted once.
 * ⛔ MEASURED by mz_gate 2026-09-23: allocating and painting a full-screen board at the finish cost one 25-60 ms frame.
 */
Scene_Derby.prototype.createPlates = function () {
  var W = Graphics.width, H = Graphics.height;
  this._photo = new Sprite(new Bitmap(W, H)); this._photo.visible = false;
  this._resultBack = new Sprite(new Bitmap(W, H)); this._d.draw.drawResultBack(this._resultBack.bitmap.context, W, H); this._resultBack.bitmap._baseTexture.update(); this._resultBack.visible = false;
  this._result = new Sprite(new Bitmap(W, H)); this._result.visible = false;
  this.addChild(this._photo); this.addChild(this._resultBack); this.addChild(this._result);
};

/**
 * Work a card's book for at most BOOK_MS of this frame. The prices do not depend on how the work is sliced (every
 * pricing race is keyed by its index), only how many frames it takes. @returns {boolean} true once priced
 */
Scene_Derby.prototype.workBook = function (card) {
  if (!card || card.priced) return true;
  var now = (typeof performance !== 'undefined' && performance.now) ? function () { return performance.now(); } : Date.now, t0 = now(), done = false;
  do { done = this._d.core.workBook(card, Scene_Derby.BOOK_STEP); } while (!done && now() - t0 < Scene_Derby.BOOK_MS);
  return done;
};

/** Draw the next race's card (or take the one already priced during the last race) and open its book. */
Scene_Derby.prototype.newCard = function () {
  var d = this._d;
  this._card = this._nextCard && this._nextIdx === this._raceIdx ? this._nextCard : Derby.nextCard(this._req, this._stable, this._raceIdx, this._arrival);
  this._nextCard = null;
  this._sel = 0; this._type = 'win';
  var purse = this.purse();
  this._stake = purse >= this._req.minStake ? Math.min(this._req.minStake, this._req.maxStake) : 0;
  this._bookShown = -1;
  this._cardLayer.visible = true; this._raceLayer.visible = false;
  this._mode = 'card';
  var n = this._card.field.length;
  this._rowTop = 124; this._rowH = Math.min(62, Math.floor((this._cardSprite.bitmap.height - this._rowTop - 20) / n));
  this.drawCard(); this.drawMap(); this.drawPick(); this.refreshSlip();
};

Scene_Derby.prototype.formOf = function (runner) { var f = this._rec.form && this._rec.form[runner.id]; return f || []; };

Scene_Derby.prototype.drawCard = function () {
  var d = this._d, b = this._cardSprite.bitmap, ctx = b.context, c = this._card, W = b.width, i;
  ctx.clearRect(0, 0, W, b.height);
  d.draw.drawPaper(ctx, 4, 4, W - 12, b.height - 12, c.raceSeed);
  d.draw.drawCardHead(ctx, 4, 4, W - 12, c, this.meetingName(), this._raceIdx, this._req.races);
  d.draw.drawCardColumns(ctx, 20, this._rowTop - 8, W - 40);
  for (i = 0; i < c.field.length; i++) {
    var y = this._rowTop + i * this._rowH;
    if (i % 2 === 1) { ctx.fillStyle = 'rgba(160,120,60,0.07)'; ctx.fillRect(20, y, W - 40, this._rowH); }
    d.draw.drawCardRow(ctx, 20, y, W - 40, this._rowH, { num: i + 1, runner: c.field[i], form: this.formOf(c.field[i]), win: d.core.priceText(c.win[i]), place: d.core.priceText(c.place[i]), priced: c.priced });
  }
  b._baseTexture.update();
};

Scene_Derby.prototype.drawMap = function () { var b = this._mapSprite.bitmap; b.context.clearRect(0, 0, b.width, b.height); this._d.draw.drawCourseMap(b.context, 0, 0, b.width - 6, b.height - 4, this._card, this._d.core); b._baseTexture.update(); };

/** The selection band over the chosen row: one sprite, moved (never redrawn) when the selection changes. */
Scene_Derby.prototype.drawPick = function () {
  var b = this._pick.bitmap, ctx = b.context, h = this._rowH;
  if (b.height !== h) { this._pick.bitmap = new Bitmap(496, h); b = this._pick.bitmap; ctx = b.context; }
  ctx.clearRect(0, 0, b.width, b.height);
  ctx.fillStyle = 'rgba(240,200,80,0.22)'; ctx.fillRect(0, 1, b.width, h - 2);
  ctx.strokeStyle = 'rgba(168,35,42,0.85)'; ctx.lineWidth = 2; ctx.strokeRect(1, 2, b.width - 2, h - 4);
  ctx.fillStyle = '#a8232a'; ctx.beginPath(); ctx.moveTo(-1, h / 2 - 8); ctx.lineTo(9, h / 2); ctx.lineTo(-1, h / 2 + 8); ctx.closePath(); ctx.fill();
  b._baseTexture.update();
  this.placePick();
};
Scene_Derby.prototype.placePick = function () { this._pick.y = this._cardSprite.y + this._rowTop + this._sel * this._rowH; };

Scene_Derby.prototype.returns = function () {
  var c = this._card, rung = this._type === 'win' ? c.win[this._sel] : c.place[this._sel];
  return c.priced && rung >= 0 && this._stake > 0 ? Math.floor(this._stake * this._d.core.dec(rung)) : 0;
};

Scene_Derby.prototype.refreshSlip = function () {
  var c = this._card, d = this._d, i = this._sel;
  this._slipBoxes = d.draw.drawSlip(this._slip.bitmap.context, this._slip.bitmap.width, this._slip.bitmap.height, {
    runner: c.field[i], num: i + 1, type: this._type, stake: this._stake, purse: this.purse(), returns: this.returns(), ready: c.priced,
    winText: c.priced ? d.core.priceText(c.win[i]) : '…', placeText: c.placeTerms < 2 ? '-' : (c.priced ? d.core.priceText(c.place[i]) : '…') });
  this._slip.bitmap._baseTexture.update();
};

Scene_Derby.prototype.updateCard = function () {
  var c = this._card, n = c.field.length;
  if (!c.priced && this.workBook(c)) { this.drawCard(); this.refreshSlip(); }
  if (Input.isRepeated('down')) { this._sel = (this._sel + 1) % n; this.cursorMoved(); }
  else if (Input.isRepeated('up')) { this._sel = (this._sel + n - 1) % n; this.cursorMoved(); }
  else if (Input.isRepeated('right')) this.changeStake(1);
  else if (Input.isRepeated('left')) this.changeStake(-1);
  else if (Input.isTriggered('shift') || Input.isTriggered('pageup') || Input.isTriggered('pagedown')) this.toggleType();
  else if (Input.isTriggered('ok')) this.goOff();
  else if (Input.isTriggered('cancel') || TouchInput.isCancelled()) this.leave();
  else if (TouchInput.isTriggered()) this.cardTouch(TouchInput.x, TouchInput.y);
};

Scene_Derby.prototype.cursorMoved = function () { this.playSe(Derby.params.cursorSe); this.placePick(); this.clampType(); this.refreshSlip(); };
Scene_Derby.prototype.clampType = function () { if (this._type === 'place' && (this._card.placeTerms < 2 || (this._card.priced && this._card.place[this._sel] < 0))) this._type = 'win'; };
Scene_Derby.prototype.toggleType = function () { this._type = this._type === 'win' ? 'place' : 'win'; this.clampType(); this.playSe(Derby.params.cursorSe); this.refreshSlip(); };
Scene_Derby.prototype.changeStake = function (dir) {
  var q = this._req, purse = this.purse(), s = this._stake;
  if (dir > 0) s = s <= 0 ? q.minStake : Math.min(q.maxStake, s + q.stakeStep);
  else s = s - q.stakeStep < q.minStake ? 0 : s - q.stakeStep;
  if (s > purse) s = purse >= q.minStake ? Math.max(q.minStake, Math.floor(purse / q.stakeStep) * q.stakeStep) : 0;
  if (s > purse) s = 0;
  if (s !== this._stake) { this._stake = s; this.playSe(Derby.params.cursorSe); this.refreshSlip(); }
};

Scene_Derby.prototype.cardTouch = function (x, y) {
  var inBox = function (b, ox, oy) { return b && x >= ox + b[0] && x <= ox + b[0] + b[2] && y >= oy + b[1] && y <= oy + b[1] + b[3]; };
  var rowY = y - this._cardSprite.y - this._rowTop, n = this._card.field.length;
  if (x >= this._cardSprite.x + 16 && x <= this._cardSprite.x + 516 && rowY >= 0 && rowY < n * this._rowH) { var i = Math.floor(rowY / this._rowH); if (i !== this._sel) { this._sel = i; this.cursorMoved(); } return; }
  var B = this._slipBoxes, ox = this._slip.x, oy = this._slip.y;
  if (inBox(B.win, ox, oy)) { if (this._type !== 'win') this.toggleType(); }
  else if (inBox(B.place, ox, oy)) { if (this._type !== 'place') this.toggleType(); }
  else if (inBox(B.minus, ox, oy)) this.changeStake(-1);
  else if (inBox(B.plus, ox, oy)) this.changeStake(1);
  else if (inBox(B.go, ox, oy)) this.goOff();
  else if (inBox(B.leave, ox, oy)) this.leave();
};

/** Place the bet (if any) and start the race. */
Scene_Derby.prototype.goOff = function () {
  var c = this._card; if (!c.priced) return;
  var stake = Math.min(this._stake, this.purse());
  if (this.returns() <= 0) stake = 0;
  this._bet = stake > 0 ? { runner: this._sel, type: this._type, stake: stake, rung: this._type === 'win' ? c.win[this._sel] : c.place[this._sel] } : null;
  if (this._bet && typeof $gameParty !== 'undefined' && $gameParty) $gameParty.loseGold(stake);
  if (this._bet) this._net -= stake;
  this._rec.races++;
  this.buildRace();
  // open the next race's card now and price it in the spare time of this race (its frames cost ~0.03 ms)
  if (this._raceIdx + 1 < this._req.races) { this._nextCard = Derby.nextCard(this._req, this._stable, this._raceIdx + 1, this._arrival); this._nextIdx = this._raceIdx + 1; }
  this.playSe(Derby.params.startSe);
};

//---------------------------------------------------------------------------- the race

/** Bake the course and make every sprite the race needs, once per race. */
Scene_Derby.prototype.buildRace = function () {
  var d = this._d, c = this._card, n = c.field.length, W = Graphics.width, L = this._raceLayer, i;
  L.removeChildren();
  var laneH = Math.min(62, Math.floor(420 / n)), top = Scene_Derby.VIEW_H - Scene_Derby.EDGE_H - n * laneH;
  var geo = { w: Math.ceil(Scene_Derby.START_X + d.core.LEN * Scene_Derby.PX + 230), h: Scene_Derby.VIEW_H, top: top, laneH: laneH, startX: Scene_Derby.START_X, px: Scene_Derby.PX };
  this._geo = geo;
  var cb = new Bitmap(geo.w, geo.h); d.draw.drawCourse(cb.context, c, geo, d.core); cb._baseTexture.update();
  this._world = new Sprite(); this._world.y = Scene_Derby.VIEW_Y; L.addChild(this._world);
  this._world.addChild(new Sprite(cb));
  var s = laneH / 68; this._scale = s;
  var trailBmp = new Bitmap(64, Math.max(6, Math.round(laneH * 0.34))); d.draw.drawTrail(trailBmp.context, 64, trailBmp.height); trailBmp._baseTexture.update();
  this._runners = []; this._prevSt = []; this._prevSec = [];
  for (i = 0; i < n; i++) {
    var look = c.field[i].look, laneY = top + (i + 0.62) * laneH;
    var trail = new Sprite(trailBmp); trail.x = Scene_Derby.START_X; trail.y = laneY + 12 * s - trailBmp.height / 2; trail.scale.x = 0; this._world.addChild(trail);
    var bw = Math.ceil(100 * s), bh = Math.ceil(60 * s), body = new Sprite(new Bitmap(bw, bh));
    var bx = body.bitmap.context; bx.save(); bx.translate(48 * s, 36 * s); d.draw.drawBody(bx, look, i + 1, s); bx.restore(); body.bitmap._baseTexture.update();
    body.anchor.x = 48 / 100; body.anchor.y = 36 / 60; body.y = laneY; this._world.addChild(body);
    var sw = Math.ceil(52 * s), shell = new Sprite(new Bitmap(sw, sw));
    var sx = shell.bitmap.context; sx.save(); sx.translate(sw / 2, sw / 2); d.draw.drawShell(sx, look, s); sx.restore(); shell.bitmap._baseTexture.update();
    shell.anchor.x = shell.anchor.y = 0.5; this._world.addChild(shell);
    this._runners.push({ body: body, shell: shell, trail: trail, laneY: laneY, phase: i * 1.7 });
    this._prevSt.push(0); this._prevSec.push(0);
  }
  // the header, strip and dots
  var head = new Bitmap(W, Scene_Derby.VIEW_Y); d.draw.drawRaceHead(head.context, W, Scene_Derby.VIEW_Y, c);
  this._stripX = 60; this._stripW = W - 120; d.draw.drawStrip(head.context, this._stripX, 46, this._stripW, 14, c, d.core); head._baseTexture.update();
  L.addChild(new Sprite(head));
  this._dots = [];
  for (i = 0; i < n; i++) { var dot = new Sprite(new Bitmap(14, 14)); var dx = dot.bitmap.context; dx.save(); dx.translate(7, 7); d.draw.drawDot(dx, c.field[i].look, 5.5); dx.restore(); dot.bitmap._baseTexture.update(); dot.anchor.x = dot.anchor.y = 0.5; dot.y = 53; L.addChild(dot); this._dots.push(dot); }
  // lane board (fixed at the left edge) and commentary
  var board = new Sprite(new Bitmap(Scene_Derby.BOARD_W, n * laneH)); d.draw.drawLaneBoard(board.bitmap.context, Scene_Derby.BOARD_W, n * laneH, c, laneH); board.bitmap._baseTexture.update();
  board.y = Scene_Derby.VIEW_Y + top; L.addChild(board);
  this._comment = new Sprite(new Bitmap(W, Graphics.height - Scene_Derby.VIEW_Y - Scene_Derby.VIEW_H)); this._comment.y = Scene_Derby.VIEW_Y + Scene_Derby.VIEW_H; L.addChild(this._comment);
  this._commentText = ''; this._commentCool = 0;
  // the race itself: the same DerbyCore.tick the bookmaker priced the card with
  this._race = d.core.resetRace(d.core.makeRace(c.field, c.course, c.going), c.raceSeed);
  this._acc = 0; this._camX = 0; this._prevLeader = -1; this._finishSeen = false; this._doneWait = 0;
  this.say('They’re under starter’s orders... and they’re off!');
  this._cardLayer.visible = false; L.visible = true; this._mode = 'race';
  this.placeRunners(0);
};

Scene_Derby.prototype.say = function (text) {
  if (text === this._commentText) return;
  this._commentText = text; this._d.draw.drawCommentary(this._comment.bitmap.context, this._comment.bitmap.width, this._comment.bitmap.height, text);
  this._comment.bitmap._baseTexture.update(); this._commentCool = 50;
};

Scene_Derby.SURFACE_WORDS = { moss: 'onto the moss, and it’s quick', slate: 'onto the slate', sand: 'into the sand, heavy going', puddle: 'into the puddle!', leaf: 'into the leaf litter', gravel: 'over the gravel' };

/** After each tick: find the one thing worth saying. Nothing here runs every frame. */
Scene_Derby.prototype.commentAfterTick = function () {
  var race = this._race, c = this._card, i, rs = race.runners;
  if (race.nFin > 0 && !this._finishSeen) { this._finishSeen = true; var w = race.order[0]; this._commentCool = 0; this.say('No. ' + (w + 1) + ' ' + c.field[w].name + ' is first past the post!'); this.playSe(Derby.params.finishSe); return; }
  if (race.nFin > 0) return;
  var said = false;
  if (race.leader !== this._prevLeader && race.t > 20 && this._commentCool <= 0) { said = true; this.say('No. ' + (race.leader + 1) + ' ' + c.field[race.leader].name + ' takes the lead!'); }
  for (i = 0; i < race.n; i++) {
    var st = rs[i].st;
    if (!said && this._commentCool <= 0 && st !== this._prevSt[i]) {
      if (st === 2) { said = true; this.say(c.field[i].name + ' has stopped for a nibble!'); }
      else if (st === 1 && rs[i].x > 120) { said = true; this.say(c.field[i].name + ' finds a burst of speed!'); }
    }
    this._prevSt[i] = st;
  }
  var L = race.leader >= 0 ? race.leader : 0;
  if (!said && this._commentCool <= 0 && rs[L].sec !== this._prevSec[L]) this.say('The leaders go ' + Scene_Derby.SURFACE_WORDS[c.course.sections[rs[L].sec].surface]);
  for (i = 0; i < race.n; i++) this._prevSec[i] = rs[i].sec;
  this._prevLeader = race.leader;
};

/** Numbers only: position every runner sprite from the race state, interpolated inside the tick. */
Scene_Derby.prototype.placeRunners = function (alpha) {
  var race = this._race, rs = race.runners, px = Scene_Derby.PX, s = this._scale, best = 0, i;
  for (i = 0; i < race.n; i++) {
    var st = rs[i], R = this._runners[i];
    var x = st.prevX + (st.x - st.prevX) * alpha, nose = Scene_Derby.START_X + x * px;
    if (st.st !== 2) R.phase += 0.12 + st.v * 0.05;
    var wig = Math.sin(R.phase);
    // the sprite origin is the snail's own origin; its front (the stalk roots) is 40 units ahead of it
    R.body.x = nose - 40 * s;
    R.body.scale.x = 1 + 0.035 * wig; R.body.scale.y = 1 - 0.02 * wig;
    R.shell.x = R.body.x - 6 * s + 2 * s * wig; R.shell.y = R.laneY - 8 * s - Math.abs(wig) * 1.2 * s;
    R.shell.rotation = st.st === 2 ? -0.12 : 0.04 * wig;
    R.trail.scale.x = Math.max(0, (R.body.x - 36 * s - Scene_Derby.START_X) / 64);
    if (nose > best) best = nose;
    this._dots[i].x = this._stripX + Math.min(1, x / this._d.core.LEN) * this._stripW;
  }
  var target = Math.max(0, Math.min(this._geo.w - Graphics.width, best - Graphics.width * 0.62));
  this._camX += (target - this._camX) * 0.12;
  this._world.x = -Math.round(this._camX);
};

Scene_Derby.prototype.updateRace = function () {
  var core = this._d.core, fast = Input.isPressed('ok') || TouchInput.isPressed();
  this._acc += fast ? 3 : 1;
  while (this._acc >= Scene_Derby.TICK_FRAMES && !this._race.done) { this._acc -= Scene_Derby.TICK_FRAMES; core.tick(this._race); this.commentAfterTick(); }
  if (this._race.done) this._acc = Math.min(this._acc, Scene_Derby.TICK_FRAMES);
  if (this._commentCool > 0) this._commentCool--;
  this.placeRunners(this._race.done ? 1 : this._acc / Scene_Derby.TICK_FRAMES);
  if (this._race.done && ++this._doneWait > 40) {
    if (core.marginAt(this._race, 0) < 0.25) this.showPhoto(); else this.showResult();
  }
};

//---------------------------------------------------------------------------- the photograph and the result

Scene_Derby.prototype.showPhoto = function () {
  var d = this._d, race = this._race, c = this._card, w = race.runners[race.order[0]], shown = [];
  for (var k = 0; k < Math.min(3, race.n); k++) {
    if (k > 0 && d.core.marginAt(race, k - 1) >= 0.25) break;
    var r = race.runners[race.order[k]];
    shown.push({ look: c.field[race.order[k]].look, num: race.order[k] + 1, x: d.core.LEN - (r.fin - w.fin) * (r.vFin || d.core.BASE) });
  }
  d.draw.drawPhoto(this._photo.bitmap.context, Graphics.width, Graphics.height, c, shown, d.core); this._photo.bitmap._baseTexture.update();
  this._photo.visible = true; this._photoShown = shown.length;
  this.say('Photograph! The judge is studying the print...');
  this._mode = 'photo'; this._wait = 150;
};

Scene_Derby.prototype.updatePhoto = function () { if (--this._wait <= 0 || (this._wait < 110 && (Input.isTriggered('ok') || TouchInput.isTriggered()))) this.showResult(); };

/** Settle the bet, record the form, and draw the winners' enclosure. */
Scene_Derby.prototype.showResult = function () {
  var d = this._d, race = this._race, c = this._card, rows = [], i;
  this._photo.visible = false;
  for (i = 0; i < race.n; i++) { var id = c.field[race.order[i]].id; var f = this._rec.form[id] || (this._rec.form[id] = []); f.push(i + 1); if (f.length > 8) f.splice(0, f.length - 8); }
  for (i = 0; i < Math.min(3, race.n); i++) {
    var m = d.core.marginAt(race, i);
    rows.push({ num: race.order[i] + 1, runner: c.field[race.order[i]], sp: d.core.priceText(c.win[race.order[i]]), margin: i < 2 && i + 1 < race.n ? (i === 0 ? 'won by ' : 'beat the third by ') + d.core.marginWords(m) : '' });
  }
  var ret = this._bet ? d.core.settle(c, race, this._bet) : 0, won = ret > 0, bet = '', detail = '';
  if (ret > 0 && typeof $gameParty !== 'undefined' && $gameParty) $gameParty.gainGold(ret);
  this._net += ret; this._rec.net += ret - (this._bet ? this._bet.stake : 0);
  this._lastReturn = ret;
  if (this._bet) {
    var nm = c.field[this._bet.runner].name, pr = d.core.priceText(this._bet.rung);
    bet = won ? 'Your ' + this._bet.stake + ' gold ' + (this._bet.type === 'win' ? 'to win' : 'to place') + ' on ' + nm + ' returns ' + ret + ' gold!' : 'Your ' + this._bet.stake + ' gold on ' + nm + ' is lost.';
    detail = (this._bet.type === 'win' ? 'Win' : 'Place') + ' at ' + pr + '  ·  purse now ' + this.purse() + ' gold' + (this._raceIdx + 1 < this._req.races ? '  ·  OK for the next race' : '  ·  OK to leave');
    if (won) this.playSe(Derby.params.winSe);
  } else { bet = 'No bet on this one.'; detail = 'Purse ' + this.purse() + ' gold' + (this._raceIdx + 1 < this._req.races ? '  ·  OK for the next race' : '  ·  OK to leave'); }
  var headline = 'No. ' + rows[0].num + ' ' + rows[0].runner.name;
  d.draw.drawResult(this._result.bitmap.context, Graphics.width, Graphics.height, c, { rows: rows, bet: bet, won: won, detail: detail, headline: headline });
  this._result.bitmap._baseTexture.update(); this._resultBack.visible = true; this._result.visible = true;
  this._resultRows = rows;
  this._mode = 'result'; this._wait = 20;
};

Scene_Derby.prototype.updateResult = function () {
  if (this._wait > 0) { this._wait--; return; }
  if (Input.isTriggered('ok') || TouchInput.isTriggered()) this.nextRace();
  else if (Input.isTriggered('cancel') || TouchInput.isCancelled()) this.leave();
};

Scene_Derby.prototype.nextRace = function () {
  this._resultBack.visible = false; this._result.visible = false;
  this._raceIdx++;
  if (this._raceIdx >= this._req.races) { this.leave(); return; }
  this._raceLayer.removeChildren(); this._raceLayer.visible = false;
  this.newCard();
};

//---------------------------------------------------------------------------- frame and exit

Scene_Derby.prototype.update = function () {
  Scene_Base.prototype.update.call(this);
  this._frame++;
  if (this._mode !== 'card' && this._nextCard && !this._nextCard.priced) this.workBook(this._nextCard);
  if (this._mode === 'card') this.updateCard();
  else if (this._mode === 'race') this.updateRace();
  else if (this._mode === 'photo') this.updatePhoto();
  else if (this._mode === 'result') this.updateResult();
  else if (this._mode === 'done' && --this._wait <= 0 && !this.isBusy()) { this._mode = 'leaving'; this.finish(); this.popScene(); }
};

Scene_Derby.prototype.finish = function () { if (this._req.variableId > 0 && typeof $gameVariables !== 'undefined') $gameVariables.setValue(this._req.variableId, this._net); };
Scene_Derby.prototype.leave = function () { if (this._mode === 'done' || this._mode === 'leaving') return; this._mode = 'done'; this._wait = 24; this.startFadeOut(this.fadeSpeed(), false); };
