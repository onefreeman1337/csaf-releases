//=============================================================================
// DerbyDraw.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Derby draw - the racing snails, their silks, the garden
 * courses, the race card, the photo finish and the winners' rosettes, all drawn
 * in code. Place BETWEEN DerbyCore and Derby.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * Every picture Derby shows is drawn here onto a canvas: no image file is
 * loaded. No parameters of its own. Must be installed below DerbyCore.js and
 * above Derby.js.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var DerbyDraw = (function () {
  'use strict';
  var TAU = Math.PI * 2;
  var FACE = '"Palatino Linotype", "Book Antiqua", Palatino, "Georgia", serif';

  var SHELLS = [['#e8b04a', '#8a4a12'], ['#c9d6e8', '#4a5a78'], ['#e37a5a', '#6b1f10'], ['#9ad07a', '#2f5a1c'], ['#d9c2f0', '#5a3a8a'],
    ['#f2e6c8', '#8a6a3a'], ['#8fd6cf', '#1f5a5a'], ['#f0b0c8', '#8a2f55'], ['#d8a878', '#5a3418'], ['#b8b8c0', '#2a2a36']];
  var BODIES = ['#c8a988', '#a8b8a0', '#d8b0a0', '#b0a0c0', '#c0b890'];
  var SILKS = ['#c8202a', '#1f4fb8', '#1f8a4a', '#f0c020', '#f4f0e6', '#1a1a1e', '#6a2a9a', '#e8701a', '#5ab0e8', '#e86aa8', '#6a1420', '#9ad02a'];
  var SILK_NAMES = ['red', 'royal blue', 'emerald', 'gold', 'white', 'black', 'purple', 'orange', 'sky blue', 'pink', 'maroon', 'lime'];

  /** Course themes: sky (top, bottom), backdrop, the lane tint that sits under every surface, and ink for labels. */
  var COURSES = {
    kitchen: { sky: ['#f4dcb0', '#e8b98a'], back: '#9a4a2c', edge: '#5a3a22', ink: '#3a2414' },
    rockery: { sky: ['#cfe0ea', '#9fbccc'], back: '#6f8a6a', edge: '#4a4a40', ink: '#26302a' },
    greenhouse: { sky: ['#f6f0c8', '#dfe8b0'], back: '#b8c898', edge: '#5a4a34', ink: '#2e3a1c' },
    orchard: { sky: ['#bfe0f4', '#e6f0d0'], back: '#7aa04a', edge: '#4a3a1e', ink: '#24300f' },
    mossbank: { sky: ['#a8c8a0', '#6f9a70'], back: '#2f5a34', edge: '#1e2e1a', ink: '#12200f' },
  };
  function course(n) { return COURSES[n] || COURSES.kitchen; }

  function rng(seed) { var a = seed >>> 0; return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function rr(ctx, x, y, w, h, r) { r = Math.max(0, Math.min(r, w / 2, h / 2)); ctx.beginPath(); ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r); ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h); ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r); ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.closePath(); }
  function silk(i) { return SILKS[((i % SILKS.length) + SILKS.length) % SILKS.length]; }
  function inkOn(hex) { var v = parseInt(String(hex).slice(1), 16); if (!isFinite(v)) return '#1a1208'; var r = (v >> 16) & 255, g = (v >> 8) & 255, b = v & 255; return (0.299 * r + 0.587 * g + 0.114 * b) > 150 ? '#1a1208' : '#fbf6ea'; }

  //===========================================================================
  // The runner. Construction settled on a contact sheet 2026-09-23: one tapering
  // capsule body with a lit ridge, two stalks from spread roots, a logarithmic
  // spiral shell (Strata's ammonite construction), a pattern and a spiral
  // tightness per runner, and a saddle cloth in the runner's silks on the body.
  //===========================================================================

  /** The saddle cloth: the runner's silks in its pattern, and its number on a white disc. Origin = cloth centre. */
  function drawCloth(ctx, look, num, w, h) {
    var a = silk(look.silk[0]), b = silk(look.silk[1]), x = -w / 2, y = -h / 2;
    ctx.save(); rr(ctx, x, y, w, h, Math.max(1, h * 0.18)); ctx.clip();
    ctx.fillStyle = a; ctx.fillRect(x, y, w, h); ctx.fillStyle = b;
    var c = look.cloth;
    if (c === 'hoops') { for (var i = 0; i < 4; i++) if (i % 2) ctx.fillRect(x, y + i * h / 4, w, h / 4); }
    else if (c === 'halves') ctx.fillRect(x + w / 2, y, w / 2, h);
    else if (c === 'sash') { ctx.beginPath(); ctx.moveTo(x, y + h * 0.1); ctx.lineTo(x + w * 0.3, y); ctx.lineTo(x + w, y + h * 0.9); ctx.lineTo(x + w * 0.7, y + h); ctx.closePath(); ctx.fill(); }
    else if (c === 'quarters') { ctx.fillRect(x + w / 2, y, w / 2, h / 2); ctx.fillRect(x, y + h / 2, w / 2, h / 2); }
    else if (c === 'chevron') { ctx.beginPath(); ctx.moveTo(x, y + h * 0.2); ctx.lineTo(x + w / 2, y + h * 0.7); ctx.lineTo(x + w, y + h * 0.2); ctx.lineTo(x + w, y + h * 0.55); ctx.lineTo(x + w / 2, y + h); ctx.lineTo(x, y + h * 0.55); ctx.closePath(); ctx.fill(); }
    ctx.restore();
    ctx.strokeStyle = 'rgba(30,18,8,0.8)'; ctx.lineWidth = Math.max(0.8, h * 0.06); rr(ctx, x, y, w, h, Math.max(1, h * 0.18)); ctx.stroke();
    if (num != null) {
      var R = h * 0.36;
      ctx.fillStyle = '#fbf8f0'; ctx.beginPath(); ctx.ellipse(0, 0, R * 1.25, R, 0, 0, TAU); ctx.fill();
      ctx.strokeStyle = 'rgba(30,18,8,0.7)'; ctx.lineWidth = Math.max(0.6, h * 0.04); ctx.stroke();
      ctx.fillStyle = '#1a1208'; ctx.font = 'bold ' + Math.max(6, Math.round(h * 0.56)) + 'px ' + FACE; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(String(num), 0, h * 0.03);
    }
  }

  /** The body, stalks and saddle cloth (no shell), drawn around the origin at scale s. */
  function drawBody(ctx, look, num, s) {
    var body = BODIES[look.body % BODIES.length];
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.28)'; ctx.beginPath(); ctx.ellipse(2 * s, 20 * s, 44 * s, 5.5 * s, 0, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.moveTo(-40 * s, 18 * s);
    ctx.bezierCurveTo(-34 * s, 6 * s, 10 * s, 6 * s, 26 * s, 2 * s);
    ctx.bezierCurveTo(36 * s, -2 * s, 42 * s, 8 * s, 38 * s, 16 * s);
    ctx.bezierCurveTo(30 * s, 22 * s, -10 * s, 23 * s, -40 * s, 18 * s); ctx.closePath();
    var bg = ctx.createLinearGradient(0, 0, 0, 24 * s); bg.addColorStop(0, '#fff6ea'); bg.addColorStop(0.3, body); bg.addColorStop(1, '#3a2c20');
    ctx.fillStyle = bg; ctx.fill(); ctx.strokeStyle = 'rgba(40,28,18,0.6)'; ctx.lineWidth = Math.max(0.7, s); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = 1.4 * s; ctx.beginPath(); ctx.moveTo(-28 * s, 11 * s); ctx.quadraticCurveTo(8 * s, 7 * s, 30 * s, 4 * s); ctx.stroke();
    var roots = [[26, -5], [33, 7]];
    for (var k = 0; k < 2; k++) {
      var ox = roots[k][0], dx = roots[k][1];
      ctx.strokeStyle = body; ctx.lineCap = 'round'; ctx.lineWidth = 3.2 * s;
      ctx.beginPath(); ctx.moveTo(ox * s, 4 * s); ctx.quadraticCurveTo((ox + dx * 0.3) * s, -8 * s, (ox + dx) * s, -18 * s); ctx.stroke();
      ctx.fillStyle = '#1a1208'; ctx.beginPath(); ctx.arc((ox + dx) * s, -19 * s, 3 * s, 0, TAU); ctx.fill();
      ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc((ox + dx - 1) * s, -20 * s, 0.9 * s, 0, TAU); ctx.fill();
    }
    ctx.lineCap = 'butt';
    ctx.save(); ctx.translate(14 * s, 13 * s); ctx.rotate(-0.08); drawCloth(ctx, look, num, 22 * s, 13 * s); ctx.restore();
    ctx.restore();
  }

  /** The shell: a logarithmic spiral, banded, patterned and lit from the upper left. Centre at the origin. */
  function drawShell(ctx, look, s) {
    var sh = SHELLS[look.shell % SHELLS.length], R = 22 * s, r = rng(look.seed >>> 0), cx = 0, cy = 0, t, rr0;
    var sg = ctx.createRadialGradient(cx - R * 0.35, cy - R * 0.4, 1, cx, cy, R); sg.addColorStop(0, '#fffaf0'); sg.addColorStop(0.3, sh[0]); sg.addColorStop(1, sh[1]);
    ctx.fillStyle = sg; ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.fill();
    ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, R - 0.5, 0, TAU); ctx.clip(); ctx.globalAlpha = 0.55;
    if (look.pattern === 'bands') { ctx.lineWidth = 3 * s; for (var b = 0; b < look.bands; b++) { rr0 = R * (0.35 + b * 0.6 / look.bands); ctx.strokeStyle = b % 2 ? '#ffffff' : sh[1]; ctx.beginPath(); ctx.arc(cx, cy, rr0, 0, TAU); ctx.stroke(); } }
    else if (look.pattern === 'spots') { for (var k = 0; k < 9; k++) { var a = r() * TAU, d = R * (0.3 + r() * 0.6); ctx.fillStyle = k % 2 ? sh[1] : '#fff6e0'; ctx.beginPath(); ctx.arc(cx + Math.cos(a) * d, cy + Math.sin(a) * d, (2 + r() * 2.5) * s, 0, TAU); ctx.fill(); } }
    else if (look.pattern === 'flames') { ctx.strokeStyle = sh[1]; ctx.lineWidth = 2 * s; for (var f = 0; f < 7; f++) { var a0 = f / 7 * TAU; ctx.beginPath(); for (var q = 0; q <= 6; q++) { var dd = R * (0.2 + q * 0.13), aa = a0 + (q % 2 ? 0.18 : -0.18); if (q === 0) ctx.moveTo(cx + Math.cos(aa) * dd, cy + Math.sin(aa) * dd); else ctx.lineTo(cx + Math.cos(aa) * dd, cy + Math.sin(aa) * dd); } ctx.stroke(); } }
    else { for (var ry = 0; ry < 10; ry++) { var ra = ry / 10 * TAU + 0.2; ctx.strokeStyle = ry % 2 ? '#fff8e8' : sh[1]; ctx.lineWidth = 2.4 * s; ctx.beginPath(); ctx.moveTo(cx + Math.cos(ra) * R * 0.25, cy + Math.sin(ra) * R * 0.25); ctx.lineTo(cx + Math.cos(ra + 0.35) * R, cy + Math.sin(ra + 0.35) * R); ctx.stroke(); } }
    ctx.restore(); ctx.globalAlpha = 1;
    ctx.strokeStyle = 'rgba(40,20,5,0.6)'; ctx.lineWidth = 1.8 * s; ctx.beginPath();
    for (t = 0; t <= 3.4 * TAU; t += 0.06) { rr0 = R * Math.exp(-look.tight * t); var px = cx + rr0 * Math.cos(t + 2.2), py = cy + rr0 * Math.sin(t + 2.2); if (t === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py); }
    ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.45)'; ctx.beginPath(); ctx.ellipse(cx - R * 0.42, cy - R * 0.45, R * 0.22, R * 0.12, -0.6, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(30,14,4,0.55)'; ctx.lineWidth = Math.max(0.7, s); ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.stroke();
  }

  /** A whole runner (body + shell) around the origin, as on the card and the plates. */
  function drawSnail(ctx, look, num, s) {
    drawBody(ctx, look, num, s);
    ctx.save(); ctx.translate(-6 * s, -8 * s); drawShell(ctx, look, s); ctx.restore();
  }

  //===========================================================================
  // Courses. A course is baked ONCE into a long strip: the scenery band, one lane
  // per runner with each section's surface, string lanes, distance posts, the
  // start and the winning post.
  //===========================================================================

  function surfaceBase(name) {
    return { moss: ['#5f8a3a', '#3f6a24'], slate: ['#8a8e94', '#5f646c'], sand: ['#dcc08a', '#c4a46a'], puddle: ['#6f8ea0', '#44657a'], leaf: ['#6a4a2a', '#4a3018'], gravel: ['#a0937e', '#7a6e5c'] }[name] || ['#888', '#666'];
  }

  /** One surface in a rectangle, seeded so a course draws the same every time. */
  function drawSurface(ctx, name, x, y, w, h, r) {
    var c = surfaceBase(name), i, g = ctx.createLinearGradient(0, y, 0, y + h);
    g.addColorStop(0, c[0]); g.addColorStop(1, c[1]); ctx.fillStyle = g; ctx.fillRect(x, y, w, h);
    ctx.save(); ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
    if (name === 'moss') {
      for (i = 0; i < w * h / 40; i++) { ctx.fillStyle = r() < 0.5 ? 'rgba(170,210,110,0.35)' : 'rgba(20,50,10,0.3)'; ctx.beginPath(); ctx.arc(x + r() * w, y + r() * h, 0.8 + r() * 1.8, 0, TAU); ctx.fill(); }
      for (i = 0; i < w / 18; i++) { var tx = x + r() * w, ty = y + r() * h; ctx.strokeStyle = 'rgba(190,230,120,0.5)'; ctx.lineWidth = 1; ctx.beginPath(); for (var k = -2; k <= 2; k++) { ctx.moveTo(tx, ty); ctx.lineTo(tx + k * 1.5, ty - 4 - r() * 3); } ctx.stroke(); }
    } else if (name === 'slate') {
      // ⛔ found by looking: h/2 flags over the whole lane block drew two giant slabs. Flags are a fixed size.
      var fw = 50, fh = 25, rows = Math.ceil(h / fh);
      for (var row = 0; row < rows; row++) for (var fx = x - r() * 30; fx < x + w; fx += fw) {
        fw = 34 + r() * 34; // every flag its own width, so the paving reads as laid stone rather than brick
        var shade = 0.85 + r() * 0.3; ctx.fillStyle = 'rgba(' + Math.round(130 * shade) + ',' + Math.round(136 * shade) + ',' + Math.round(146 * shade) + ',0.55)';
        ctx.fillRect(fx + 1.5, y + row * fh + 1.5, fw - 3, fh - 3);
        ctx.strokeStyle = 'rgba(30,32,38,0.55)'; ctx.lineWidth = 1.5; ctx.strokeRect(fx + 0.75, y + row * fh + 0.75, fw - 1.5, fh - 1.5);
        ctx.strokeStyle = 'rgba(255,255,255,0.18)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(fx + 2, y + row * fh + 2.5); ctx.lineTo(fx + fw - 3, y + row * fh + 2.5); ctx.stroke();
      }
    } else if (name === 'sand') {
      for (i = 0; i < w * h / 25; i++) { ctx.fillStyle = r() < 0.5 ? 'rgba(255,240,200,0.4)' : 'rgba(120,90,40,0.25)'; ctx.fillRect(x + r() * w, y + r() * h, 1, 1); }
      ctx.strokeStyle = 'rgba(150,115,60,0.35)'; ctx.lineWidth = 1;
      for (var yy = y + 6; yy < y + h; yy += 9) { ctx.beginPath(); for (var xx = x; xx <= x + w; xx += 6) ctx.lineTo(xx, yy + Math.sin(xx / 13 + yy) * 1.6); ctx.stroke(); }
    } else if (name === 'puddle') {
      // ⛔ found by looking: a flat blue band did not read as water. Sky caught in the surface, a muddy rim, rings, petals.
      var sky = ctx.createLinearGradient(x, 0, x + w, 0); sky.addColorStop(0, 'rgba(200,225,240,0.0)'); sky.addColorStop(0.5, 'rgba(200,225,240,0.22)'); sky.addColorStop(1, 'rgba(200,225,240,0.0)');
      ctx.fillStyle = sky; ctx.fillRect(x, y, w, h);
      ctx.fillStyle = 'rgba(70,52,30,0.55)'; ctx.fillRect(x, y, 6, h); ctx.fillRect(x + w - 6, y, 6, h);
      for (i = 0; i < w * h / 900; i++) { var cx2 = x + 10 + r() * (w - 20), cy2 = y + r() * h; for (var ring = 1; ring <= 3; ring++) { ctx.strokeStyle = 'rgba(235,245,255,' + (0.4 / ring) + ')'; ctx.lineWidth = 1; ctx.beginPath(); ctx.ellipse(cx2, cy2, ring * 5, ring * 1.8, 0, 0, TAU); ctx.stroke(); } }
      for (i = 0; i < w * h / 2500; i++) { ctx.fillStyle = r() < 0.5 ? 'rgba(240,160,190,0.85)' : 'rgba(255,240,200,0.85)'; ctx.beginPath(); ctx.ellipse(x + 8 + r() * (w - 16), y + r() * h, 3, 1.6, r() * TAU, 0, TAU); ctx.fill(); }
      ctx.fillStyle = 'rgba(40,60,70,0.35)'; ctx.fillRect(x, y, w, 3);
      for (i = 0; i < w / 30; i++) { var px = x + r() * w, py = y + 6 + r() * (h - 12); ctx.strokeStyle = 'rgba(220,240,255,' + (0.25 + r() * 0.35) + ')'; ctx.lineWidth = 1; ctx.beginPath(); ctx.ellipse(px, py, 5 + r() * 10, 1.5 + r() * 2, 0, 0, TAU); ctx.stroke(); }
      for (i = 0; i < w / 12; i++) { ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.fillRect(x + r() * w, y + 4 + r() * (h - 8), 6 + r() * 12, 1); }
    } else if (name === 'leaf') {
      for (i = 0; i < w * h / 180; i++) {
        var lx = x + r() * w, ly = y + r() * h, la = r() * TAU, ls = 4 + r() * 5, hue = ['#b8742a', '#d49a3a', '#8a4a1a', '#a8a03a', '#c0582a'][Math.floor(r() * 5)];
        ctx.save(); ctx.translate(lx, ly); ctx.rotate(la); ctx.fillStyle = hue; ctx.beginPath(); ctx.ellipse(0, 0, ls, ls * 0.45, 0, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(60,30,10,0.6)'; ctx.lineWidth = 0.7; ctx.beginPath(); ctx.moveTo(-ls, 0); ctx.lineTo(ls, 0); ctx.stroke(); ctx.restore();
      }
    } else {
      for (i = 0; i < w * h / 22; i++) { var gx = x + r() * w, gy = y + r() * h, gr = 0.8 + r() * 2.2, v = Math.round(110 + r() * 90); ctx.fillStyle = 'rgb(' + v + ',' + Math.round(v * 0.95) + ',' + Math.round(v * 0.86) + ')'; ctx.beginPath(); ctx.arc(gx, gy, gr, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.25)'; ctx.beginPath(); ctx.arc(gx - gr * 0.3, gy - gr * 0.3, gr * 0.35, 0, TAU); ctx.fill(); }
    }
    ctx.restore();
  }

  /** The scenery band above the lanes, one picture per course theme, repeated along the whole strip. */
  function drawScenery(ctx, theme, x0, w, top, h, r) {
    var T = course(theme), g = ctx.createLinearGradient(0, top, 0, top + h), i, x;
    g.addColorStop(0, T.sky[0]); g.addColorStop(1, T.sky[1]); ctx.fillStyle = g; ctx.fillRect(x0, top, w, h);
    var base = top + h;
    if (theme === 'kitchen') {
      for (var by = top + h - 34; by < base; by += 8) for (x = x0 + ((by / 8) % 2) * 9; x < x0 + w; x += 18) { ctx.fillStyle = r() < 0.5 ? '#a8543a' : '#94452e'; ctx.fillRect(x, by, 16, 6); }
      for (x = x0 + 40; x < x0 + w; x += 110 + r() * 60) {
        ctx.fillStyle = '#c0643a'; ctx.beginPath(); ctx.moveTo(x - 16, base - 26); ctx.lineTo(x + 16, base - 26); ctx.lineTo(x + 11, base); ctx.lineTo(x - 11, base); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#d8784a'; ctx.fillRect(x - 18, base - 30, 36, 6);
        for (i = 0; i < 7; i++) { ctx.fillStyle = ['#6fae3a', '#8ac84a', '#4f8a2a'][i % 3]; ctx.beginPath(); ctx.ellipse(x + (i - 3) * 5, base - 34 - (i % 2) * 6, 7, 10, (i - 3) * 0.3, 0, TAU); ctx.fill(); }
        if (r() < 0.5) { ctx.fillStyle = '#e8d8b0'; ctx.fillRect(x + 20, base - 40, 12, 22); ctx.fillStyle = '#5a3a22'; ctx.fillRect(x + 25, base - 18, 2, 18); }
      }
    } else if (theme === 'rockery') {
      ctx.fillStyle = '#5f7a58'; ctx.beginPath(); ctx.moveTo(x0, base - 28); for (x = x0; x <= x0 + w; x += 20) ctx.lineTo(x, base - 30 - Math.sin(x / 70) * 8 - r() * 4); ctx.lineTo(x0 + w, base); ctx.lineTo(x0, base); ctx.closePath(); ctx.fill();
      for (x = x0 + 20; x < x0 + w; x += 26 + r() * 30) {
        var sr = 10 + r() * 14, sv = Math.round(130 + r() * 50), sg2 = ctx.createRadialGradient(x - sr * 0.4, base - sr * 0.9, 2, x, base - sr * 0.5, sr * 1.2);
        sg2.addColorStop(0, 'rgb(' + (sv + 50) + ',' + (sv + 50) + ',' + (sv + 45) + ')'); sg2.addColorStop(1, 'rgb(' + (sv - 60) + ',' + (sv - 60) + ',' + (sv - 55) + ')');
        ctx.fillStyle = sg2; ctx.beginPath(); ctx.ellipse(x, base - sr * 0.55, sr * 1.3, sr * 0.8, 0, 0, TAU); ctx.fill();
        for (i = 0; i < 5; i++) { ctx.fillStyle = r() < 0.5 ? '#f08ab0' : '#fff4f8'; ctx.beginPath(); ctx.arc(x + (r() - 0.5) * sr * 2, base - sr * 1.2 - r() * 6, 1.8, 0, TAU); ctx.fill(); }
      }
    } else if (theme === 'greenhouse') {
      ctx.fillStyle = 'rgba(255,255,240,0.35)'; ctx.fillRect(x0, top, w, h - 22);
      ctx.strokeStyle = '#f6f4ea'; ctx.lineWidth = 3; for (x = x0; x < x0 + w; x += 64) { ctx.beginPath(); ctx.moveTo(x, top); ctx.lineTo(x, base - 22); ctx.stroke(); }
      ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x0, top + (h - 22) / 2); ctx.lineTo(x0 + w, top + (h - 22) / 2); ctx.stroke();
      ctx.fillStyle = '#8a6a44'; ctx.fillRect(x0, base - 22, w, 22); ctx.fillStyle = '#6a4e30'; ctx.fillRect(x0, base - 22, w, 3);
      for (x = x0 + 30; x < x0 + w; x += 90 + r() * 40) {
        ctx.fillStyle = '#b8603a'; ctx.fillRect(x - 10, base - 34, 20, 13);
        ctx.strokeStyle = '#4a7a2a'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x, base - 34); ctx.quadraticCurveTo(x - 8, base - 50, x + 2, base - 62); ctx.stroke();
        for (i = 0; i < 4; i++) { ctx.fillStyle = i % 2 ? '#d8402a' : '#e86a3a'; ctx.beginPath(); ctx.arc(x - 6 + i * 4, base - 44 - i * 4, 3.4, 0, TAU); ctx.fill(); }
        ctx.fillStyle = '#5a9a3a'; for (i = 0; i < 4; i++) { ctx.beginPath(); ctx.ellipse(x + (i % 2 ? 7 : -7), base - 40 - i * 5, 5, 2.4, (i % 2 ? 0.5 : -0.5), 0, TAU); ctx.fill(); }
      }
    } else if (theme === 'orchard') {
      ctx.fillStyle = '#6f9a3a'; ctx.fillRect(x0, base - 18, w, 18);
      for (x = x0 + 50; x < x0 + w; x += 170 + r() * 60) {
        ctx.fillStyle = '#5a3a1e'; ctx.fillRect(x - 7, top + 10, 14, h - 16);
        ctx.fillStyle = '#4a2e16'; ctx.fillRect(x - 7, top + 10, 4, h - 16);
        ctx.fillStyle = '#4f7a2a'; ctx.beginPath(); ctx.ellipse(x, top + 6, 60, 22, 0, 0, TAU); ctx.fill();
        for (i = 0; i < 6; i++) { ctx.fillStyle = '#c8302a'; ctx.beginPath(); ctx.arc(x + (r() - 0.5) * 100, top + 4 + r() * 18, 3.5, 0, TAU); ctx.fill(); }
        for (i = 0; i < 3; i++) { ctx.fillStyle = '#b8282a'; ctx.beginPath(); ctx.arc(x + 20 + i * 14 + r() * 8, base - 6, 4, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.5)'; ctx.beginPath(); ctx.arc(x + 19 + i * 14, base - 7.5, 1.2, 0, TAU); ctx.fill(); }
      }
      for (x = x0; x < x0 + w; x += 7) { ctx.strokeStyle = r() < 0.5 ? '#86b04a' : '#5a8a2a'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x, base); ctx.lineTo(x + (r() - 0.5) * 4, base - 5 - r() * 7); ctx.stroke(); }
    } else {
      ctx.fillStyle = '#23462a'; ctx.beginPath(); ctx.moveTo(x0, base - 20); for (x = x0; x <= x0 + w; x += 16) ctx.lineTo(x, base - 24 - Math.sin(x / 40) * 6 - r() * 5); ctx.lineTo(x0 + w, base); ctx.lineTo(x0, base); ctx.closePath(); ctx.fill();
      for (x = x0 + 20; x < x0 + w; x += 60 + r() * 50) {
        for (var fr = -3; fr <= 3; fr++) { ctx.strokeStyle = '#4f8a3a'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(x, base - 10); ctx.quadraticCurveTo(x + fr * 8, base - 36, x + fr * 14, base - 30 + Math.abs(fr) * 4); ctx.stroke(); }
        if (r() < 0.55) { var mx = x + 26; ctx.fillStyle = '#efe6d0'; ctx.fillRect(mx - 2, base - 16, 4, 12); ctx.fillStyle = '#c8282a'; ctx.beginPath(); ctx.ellipse(mx, base - 16, 9, 6, 0, Math.PI, TAU); ctx.fill(); ctx.fillStyle = '#ffffff'; for (i = 0; i < 3; i++) { ctx.beginPath(); ctx.arc(mx - 4 + i * 4, base - 19 + (i % 2), 1.2, 0, TAU); ctx.fill(); } }
      }
    }
    ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(x0, base - 3, w, 3);
  }

  /**
   * Bake a course strip for a field. Returns the geometry the scene needs to place runners on it.
   * @param {Object} ctx a canvas 2D context at least (geo.w x geo.h)
   * @param {Object} card a DerbyCore card
   * @param {Object} geo {w, h, top (scenery height), laneH, startX, px (pixels per race unit)}
   */
  function drawCourse(ctx, card, geo, core) {
    var c = card.course, n = card.field.length, T = course(c.theme), r = rng((card.raceSeed ^ 0xC0) >>> 0), i, s;
    ctx.fillStyle = T.edge; ctx.fillRect(0, 0, geo.w, geo.h);
    drawScenery(ctx, c.theme, 0, geo.w, 0, geo.top, r);
    var laneTop = geo.top, laneBottom = geo.top + n * geo.laneH;
    for (s = 0; s < c.sections.length; s++) {
      var sx = s === 0 ? 0 : geo.startX + c.sections[s].from * geo.px, ex = s === c.sections.length - 1 ? geo.w : geo.startX + c.sections[s].to * geo.px;
      drawSurface(ctx, c.sections[s].surface, sx, laneTop, ex - sx, laneBottom - laneTop, r);
      if (s > 0) { ctx.fillStyle = 'rgba(0,0,0,0.18)'; ctx.fillRect(sx - 1, laneTop, 2, laneBottom - laneTop); }
    }
    // lane strings and pegs
    for (i = 0; i <= n; i++) {
      var ly = laneTop + i * geo.laneH;
      ctx.strokeStyle = 'rgba(250,246,230,0.8)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(0, ly + 0.5); ctx.lineTo(geo.w, ly + 0.5); ctx.stroke();
      for (var px = geo.startX % 120; px < geo.w; px += 120) { ctx.fillStyle = '#6a4a2a'; ctx.fillRect(px - 1.5, ly - 4, 3, 7); ctx.fillStyle = '#a8804a'; ctx.fillRect(px - 1.5, ly - 4, 3, 2); }
    }
    // distance posts along the top of the lanes: three-quarters, half, a quarter still to run
    ['¾', '½', '¼'].forEach(function (lab, k) {
      var dx = geo.startX + (k + 1) * 0.25 * core.LEN * geo.px;
      ctx.fillStyle = '#f4efe2'; ctx.fillRect(dx - 2, laneTop - 30, 4, 30); ctx.fillStyle = '#c8202a'; ctx.fillRect(dx - 2, laneTop - 30, 4, 6);
      ctx.fillStyle = '#f4efe2'; ctx.beginPath(); ctx.arc(dx, laneTop - 36, 10, 0, TAU); ctx.fill(); ctx.strokeStyle = '#1a1208'; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = '#1a1208'; ctx.font = 'bold 13px ' + FACE; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(lab, dx, laneTop - 35);
    });
    // the start: a chalk line and a starter's peg with a flag
    ctx.fillStyle = 'rgba(255,255,250,0.9)'; ctx.fillRect(geo.startX - 2, laneTop, 3, laneBottom - laneTop);
    ctx.fillStyle = '#5a3a1e'; ctx.fillRect(geo.startX - 3, laneTop - 44, 3, 44); ctx.fillStyle = '#c8202a'; ctx.beginPath(); ctx.moveTo(geo.startX, laneTop - 44); ctx.lineTo(geo.startX + 20, laneTop - 38); ctx.lineTo(geo.startX, laneTop - 32); ctx.closePath(); ctx.fill();
    // the winning post: a chequer line, a red-and-white post and its disc
    var fx = geo.startX + core.LEN * geo.px;
    for (var q = 0; q < Math.ceil((laneBottom - laneTop) / 6); q++) { ctx.fillStyle = q % 2 ? '#1a1208' : '#fbf8f0'; ctx.fillRect(fx - 3, laneTop + q * 6, 3, 6); ctx.fillStyle = q % 2 ? '#fbf8f0' : '#1a1208'; ctx.fillRect(fx, laneTop + q * 6, 3, 6); }
    // ⛔ found by looking: a fixed 66 px post ran its disc under the header when 8 lanes left a short scenery band
    var postH = Math.max(30, Math.min(60, laneTop - 30)), discY = laneTop - postH - 6;
    for (var pq = 0; pq < 6; pq++) { ctx.fillStyle = pq % 2 ? '#c8202a' : '#fbf8f0'; ctx.fillRect(fx - 3, laneTop - postH + pq * postH / 6, 6, postH / 6 + 0.5); }
    ctx.fillStyle = '#fbf8f0'; ctx.beginPath(); ctx.arc(fx, discY, 13, 0, TAU); ctx.fill(); ctx.fillStyle = '#c8202a'; ctx.beginPath(); ctx.arc(fx, discY, 8, 0, TAU); ctx.fill();
    ctx.strokeStyle = '#1a1208'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(fx, discY, 13, 0, TAU); ctx.stroke();
    // a lettuce leaf past the post in every lane: the prize
    for (i = 0; i < n; i++) { var yy = laneTop + (i + 0.55) * geo.laneH; drawLettuce(ctx, fx + 46, yy, geo.laneH * 0.018 + 0.2); }
    // the foreground edge
    ctx.fillStyle = T.edge; ctx.fillRect(0, laneBottom, geo.w, geo.h - laneBottom); ctx.fillStyle = 'rgba(255,255,255,0.12)'; ctx.fillRect(0, laneBottom, geo.w, 2);
  }

  function drawLettuce(ctx, x, y, s) {
    for (var i = 0; i < 7; i++) { var a = i / 7 * TAU; ctx.fillStyle = i % 2 ? '#8ac84a' : '#6fae3a'; ctx.beginPath(); ctx.ellipse(x + Math.cos(a) * 8 * s, y + Math.sin(a) * 4 * s, 11 * s, 6 * s, a, 0, TAU); ctx.fill(); }
    ctx.fillStyle = '#c8ec8a'; ctx.beginPath(); ctx.ellipse(x, y - 1 * s, 7 * s, 4 * s, 0, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(40,80,20,0.5)'; ctx.lineWidth = 0.8; ctx.beginPath(); ctx.moveTo(x - 6 * s, y); ctx.lineTo(x + 6 * s, y - 1 * s); ctx.stroke();
  }

  /** The glistening trail a runner leaves: a long soft band, scaled along its length by the scene. */
  function drawTrail(ctx, w, h) {
    // ⛔ found by looking: a 0.55-alpha band read as fog across every lane. A trail is a thin wet sheen with glints.
    var g = ctx.createLinearGradient(0, 0, 0, h); g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(0.5, 'rgba(225,238,250,0.26)'); g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = 'rgba(255,255,255,0.5)'; for (var x = 3; x < w; x += 16) ctx.fillRect(x, h * 0.45, 3, 1);
  }

  //===========================================================================
  // The race card
  //===========================================================================

  function drawTable(ctx, W, H) {
    var g = ctx.createLinearGradient(0, 0, W, H); g.addColorStop(0, '#3a2414'); g.addColorStop(1, '#1e1208'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    var r = rng(0x7AB1E);
    for (var y = 0; y < H; y += 3) { ctx.strokeStyle = 'rgba(' + (r() < 0.5 ? '255,210,160,0.035' : '0,0,0,0.12') + ')'; ctx.lineWidth = 1 + r() * 2; ctx.beginPath(); ctx.moveTo(0, y); for (var x = 0; x <= W; x += 40) ctx.lineTo(x, y + Math.sin(x / 90 + y / 30) * 2); ctx.stroke(); }
  }

  function drawPaper(ctx, x, y, w, h, seed) {
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; rr(ctx, x + 4, y + 6, w, h, 4); ctx.fill();
    var g = ctx.createLinearGradient(x, y, x, y + h); g.addColorStop(0, '#fbf5e6'); g.addColorStop(1, '#efe3c6'); ctx.fillStyle = g; rr(ctx, x, y, w, h, 3); ctx.fill();
    var r = rng(seed >>> 0); for (var i = 0; i < w * h / 90; i++) { ctx.fillStyle = r() < 0.5 ? 'rgba(160,120,60,0.06)' : 'rgba(255,255,255,0.25)'; ctx.fillRect(x + r() * w, y + r() * h, 1 + r() * 2, 1); }
    ctx.strokeStyle = '#a8232a'; ctx.lineWidth = 2; ctx.strokeRect(x + 8, y + 8, w - 16, h - 16); ctx.lineWidth = 0.8; ctx.strokeRect(x + 12, y + 12, w - 24, h - 24);
  }

  /** The card's head: meeting, race name, conditions. */
  function drawCardHead(ctx, x, y, w, card, meeting, raceIdx, races) {
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#a8232a'; ctx.font = 'bold 12px ' + FACE; ctx.fillText(String(meeting).toUpperCase() + '   ·   RACE ' + (raceIdx + 1) + ' OF ' + races, x + w / 2, y + 26);
    var size = 30; ctx.font = 'bold ' + size + 'px ' + FACE; while (size > 18 && ctx.measureText(card.name).width > w - 40) { size--; ctx.font = 'bold ' + size + 'px ' + FACE; }
    ctx.fillStyle = '#1e140c'; ctx.fillText(card.name, x + w / 2, y + 54);
    ctx.font = 'italic 13px ' + FACE; ctx.fillStyle = '#5a4430';
    var going = { dewy: 'Dewy', damp: 'Damp', dry: 'Dry' }[card.going];
    ctx.fillText('Going: ' + going + '   ·   ' + card.field.length + ' runners   ·   Place pays ' + (card.placeTerms >= 2 ? 'the first ' + card.placeTerms : 'the winner only'), x + w / 2, y + 80);
    ctx.strokeStyle = '#1e140c'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(x + 24, y + 96); ctx.lineTo(x + w - 24, y + 96); ctx.stroke();
    ctx.lineWidth = 0.6; ctx.beginPath(); ctx.moveTo(x + 24, y + 99); ctx.lineTo(x + w - 24, y + 99); ctx.stroke();
  }

  /** A little glyph for a runner's going preference: a raindrop, a sun, or both halves. */
  function drawPrefGlyph(ctx, x, y, pref) {
    if (pref === 'damp' || pref === 'any') { ctx.fillStyle = '#3a78b8'; ctx.beginPath(); ctx.moveTo(x, y - 7); ctx.quadraticCurveTo(x + 6, y + 1, x, y + 5); ctx.quadraticCurveTo(x - 6, y + 1, x, y - 7); ctx.fill(); }
    if (pref === 'dry' || pref === 'any') { var ox = pref === 'any' ? 14 : 0; ctx.fillStyle = '#e0a020'; ctx.beginPath(); ctx.arc(x + ox, y, 4, 0, TAU); ctx.fill(); ctx.strokeStyle = '#e0a020'; ctx.lineWidth = 1.2; for (var i = 0; i < 8; i++) { var a = i / 8 * TAU; ctx.beginPath(); ctx.moveTo(x + ox + Math.cos(a) * 5.5, y + Math.sin(a) * 5.5); ctx.lineTo(x + ox + Math.cos(a) * 8, y + Math.sin(a) * 8); ctx.stroke(); } }
  }

  /** A chalk price on a slate tablet. */
  function drawChalk(ctx, x, y, w, h, big, small) {
    var g = ctx.createLinearGradient(x, y, x, y + h); g.addColorStop(0, '#34383c'); g.addColorStop(1, '#1e2226'); ctx.fillStyle = g; rr(ctx, x, y, w, h, 4); ctx.fill();
    ctx.strokeStyle = '#8a6a44'; ctx.lineWidth = 2; rr(ctx, x + 1, y + 1, w - 2, h - 2, 4); ctx.stroke();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.font = 'bold 18px ' + FACE; ctx.fillStyle = 'rgba(245,245,235,0.95)'; ctx.fillText(big, x + w / 2, y + h * 0.4);
    ctx.font = 'italic 11px ' + FACE; ctx.fillStyle = 'rgba(220,225,215,0.75)'; ctx.fillText(small, x + w / 2, y + h * 0.78);
  }

  /**
   * One runner row on the card.
   * @param {Object} info {num, runner, form: number[], win: string, place: string, priced: boolean}
   */
  function drawCardRow(ctx, x, y, w, h, info) {
    var look = info.runner.look;
    ctx.save(); ctx.translate(x + 26, y + h / 2); drawCloth(ctx, look, info.num, 34, 26); ctx.restore();
    ctx.save(); ctx.translate(x + 94, y + h / 2 + 6); drawSnail(ctx, look, null, 0.62); ctx.restore();
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    var nx = x + 136, size = 19; ctx.font = 'bold ' + size + 'px ' + FACE;
    while (size > 13 && ctx.measureText(info.runner.name).width > w - 136 - 190) { size--; ctx.font = 'bold ' + size + 'px ' + FACE; }
    ctx.fillStyle = '#1e140c'; ctx.fillText(info.runner.name, nx, y + h * 0.36);
    ctx.font = 'italic 12px ' + FACE; ctx.fillStyle = '#6a5038';
    var likes = { damp: 'likes it damp', dry: 'likes it dry', any: 'any going' }[info.runner.pref];
    // the glyph is one mark (drop or sun) or two side by side ('any'): the words start after it (found by looking)
    ctx.fillText(likes + '  ·  ' + SILK_NAMES[look.silk[0] % SILKS.length] + ' and ' + SILK_NAMES[look.silk[1] % SILKS.length], nx + (info.runner.pref === 'any' ? 30 : 16), y + h * 0.72);
    drawPrefGlyph(ctx, nx + 6, y + h * 0.72, info.runner.pref);
    // form: most recent last, a win in red
    var fx = x + w - 178, figs = info.form.slice(-5);
    ctx.font = 'bold 17px ' + FACE; ctx.textAlign = 'center';
    for (var i = 0; i < 5; i++) { var v = figs[i - (5 - figs.length)]; ctx.fillStyle = v === 1 ? '#a8232a' : '#2a1e14'; ctx.fillText(v == null ? '-' : String(v > 9 ? 0 : v), fx + i * 17, y + h / 2); }
    drawChalk(ctx, x + w - 86, y + 6, 76, h - 12, info.priced ? info.win : '…', info.priced ? (info.place === '-' ? 'win only' : 'place ' + info.place) : 'chalking');
  }

  function drawCardColumns(ctx, x, y, w) {
    ctx.font = 'bold 10px ' + FACE; ctx.fillStyle = '#8a6a44'; ctx.textBaseline = 'middle'; ctx.textAlign = 'center';
    ctx.fillText('NO.', x + 26, y); ctx.fillText('RUNNER', x + 94, y); ctx.textAlign = 'left'; ctx.fillText('NAME', x + 136, y);
    ctx.textAlign = 'center'; ctx.fillText('FORM', x + w - 144, y); ctx.fillText('PRICE', x + w - 48, y);
  }

  /** The bet slip: runner, Win/Place tabs, stake stepper, return, purse, and the two buttons. Returns hit boxes. */
  function drawSlip(ctx, W, H, s) {
    ctx.clearRect(0, 0, W, H);
    drawPaper(ctx, 4, 4, W - 12, H - 12, 0x511B);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#a8232a'; ctx.font = 'bold 13px ' + FACE; ctx.fillText('BET SLIP', W / 2, 32);
    ctx.strokeStyle = '#a8232a'; ctx.lineWidth = 0.8; ctx.beginPath(); ctx.moveTo(30, 44); ctx.lineTo(W - 36, 44); ctx.stroke();
    ctx.save(); ctx.translate(38, 72); drawCloth(ctx, s.runner.look, s.num, 30, 22); ctx.restore();
    var size = 17; ctx.font = 'bold ' + size + 'px ' + FACE; while (size > 12 && ctx.measureText(s.runner.name).width > W - 90) { size--; ctx.font = 'bold ' + size + 'px ' + FACE; }
    ctx.textAlign = 'left'; ctx.fillStyle = '#1e140c'; ctx.fillText(s.runner.name, 60, 72);
    var boxes = {};
    // tabs
    [['win', 'WIN ' + s.winText], ['place', s.placeText === '-' ? 'PLACE -' : 'PLACE ' + s.placeText]].forEach(function (t, i) {
      var bx = 20 + i * ((W - 48) / 2), bw = (W - 48) / 2 - 4, on = s.type === t[0], dis = t[0] === 'place' && s.placeText === '-';
      ctx.fillStyle = on ? '#1e140c' : 'rgba(30,20,12,0.08)'; rr(ctx, bx, 96, bw, 30, 5); ctx.fill();
      ctx.strokeStyle = '#1e140c'; ctx.lineWidth = 1; rr(ctx, bx, 96, bw, 30, 5); ctx.stroke();
      ctx.fillStyle = dis ? 'rgba(30,20,12,0.35)' : (on ? '#fbf5e6' : '#1e140c'); ctx.font = 'bold 13px ' + FACE; ctx.textAlign = 'center'; ctx.fillText(t[1], bx + bw / 2, 111);
      boxes[t[0]] = [bx, 96, bw, 30];
    });
    // stake stepper
    ctx.font = 'italic 12px ' + FACE; ctx.fillStyle = '#6a5038'; ctx.fillText('Stake', W / 2, 146);
    [['minus', '−', 24], ['plus', '+', W - 60]].forEach(function (b) {
      ctx.fillStyle = '#a8232a'; ctx.beginPath(); ctx.arc(b[2] + 16, 174, 15, 0, TAU); ctx.fill();
      ctx.fillStyle = '#fbf5e6'; ctx.font = 'bold 20px ' + FACE; ctx.fillText(b[1], b[2] + 16, 175); boxes[b[0]] = [b[2], 158, 32, 32];
    });
    ctx.fillStyle = '#1e140c'; ctx.font = 'bold 26px ' + FACE; ctx.fillText(s.stake > 0 ? s.stake + ' G' : 'No bet', W / 2, 175);
    ctx.font = 'italic 12px ' + FACE; ctx.fillStyle = '#6a5038';
    ctx.fillText(s.stake > 0 ? (s.returns > 0 ? 'Returns ' + s.returns + ' gold if it ' + (s.type === 'win' ? 'wins' : 'places') : 'No price offered') : 'Just watching this one', W / 2, 206);
    ctx.fillText('Purse: ' + s.purse + ' gold', W / 2, 226);
    // buttons
    var go = [20, 246, W - 44, 40], lv = [20, 294, W - 44, 30];
    ctx.fillStyle = s.ready ? '#2f6a2a' : 'rgba(47,106,42,0.35)'; rr(ctx, go[0], go[1], go[2], go[3], 6); ctx.fill();
    ctx.fillStyle = '#fbf5e6'; ctx.font = 'bold 17px ' + FACE; ctx.fillText(s.ready ? 'Off they go!' : 'The book is not open', W / 2, go[1] + 21);
    ctx.strokeStyle = '#6a5038'; ctx.lineWidth = 1; rr(ctx, lv[0], lv[1], lv[2], lv[3], 6); ctx.stroke();
    ctx.fillStyle = '#6a5038'; ctx.font = 'italic 13px ' + FACE; ctx.fillText('Leave the course', W / 2, lv[1] + 16);
    boxes.go = go; boxes.leave = lv;
    return boxes;
  }

  /** A little map of the course: one bar per section in its surface colour, start and post marked. */
  function drawCourseMap(ctx, x, y, w, h, card, core) {
    var c = card.course, T = course(c.theme);
    drawPaper(ctx, x, y, w, h, 0xC0A5);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#a8232a'; ctx.font = 'bold 12px ' + FACE;
    ctx.fillText(String(c.name).toUpperCase() + ' COURSE', x + w / 2, y + 28);
    var bx = x + 24, bw = w - 48, by = y + 44, bh = 26;
    for (var s = 0; s < c.sections.length; s++) {
      var sx = bx + c.sections[s].from / core.LEN * bw, sw = (c.sections[s].to - c.sections[s].from) / core.LEN * bw;
      drawSurface(ctx, c.sections[s].surface, sx, by, sw, bh, rng(0x5EC + s));
      ctx.strokeStyle = 'rgba(30,20,12,0.6)'; ctx.lineWidth = 1; ctx.strokeRect(sx + 0.5, by + 0.5, sw - 1, bh - 1);
    }
    ctx.fillStyle = '#1e140c'; ctx.fillRect(bx - 2, by - 6, 2, bh + 12); ctx.fillStyle = '#c8202a'; ctx.fillRect(bx + bw, by - 6, 3, bh + 12);
    ctx.font = 'italic 11px ' + FACE; ctx.fillStyle = '#5a4430';
    var seen = {}, names = []; c.sections.forEach(function (q) { if (!seen[q.surface]) { seen[q.surface] = 1; names.push(q.surface); } });
    ctx.fillText(names.join(' · '), x + w / 2, by + bh + 16);
    ctx.fillStyle = T.ink;
  }

  //===========================================================================
  // The race view's furniture
  //===========================================================================

  /** The header over the race: its name and a progress strip the runners' dots travel along. */
  function drawRaceHead(ctx, W, H, card) {
    ctx.clearRect(0, 0, W, H);
    var g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#2a1a10'); g.addColorStop(1, '#170d07'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = '#c9a25a'; ctx.fillRect(0, H - 2, W, 2);
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.font = 'bold 20px ' + FACE; ctx.fillStyle = '#f6e3b4'; ctx.fillText(card.name, 16, 20);
    ctx.textAlign = 'right'; ctx.font = 'italic 13px ' + FACE; ctx.fillStyle = '#c9a878';
    ctx.fillText('Going: ' + { dewy: 'Dewy', damp: 'Damp', dry: 'Dry' }[card.going] + '  ·  ' + card.field.length + ' ran', W - 16, 20);
  }

  /** The strip itself (baked once): sections as coloured bars between the start and the post. */
  function drawStrip(ctx, x, y, w, h, card, core) {
    var c = card.course;
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; rr(ctx, x - 4, y - 4, w + 8, h + 8, 5); ctx.fill();
    for (var s = 0; s < c.sections.length; s++) {
      var sx = x + c.sections[s].from / core.LEN * w, sw = (c.sections[s].to - c.sections[s].from) / core.LEN * w;
      ctx.fillStyle = surfaceBase(c.sections[s].surface)[0]; ctx.fillRect(sx, y, sw, h);
      ctx.fillStyle = 'rgba(255,255,255,0.18)'; ctx.fillRect(sx, y, sw, 2);
    }
    ctx.fillStyle = '#fbf8f0'; ctx.fillRect(x - 1, y - 3, 2, h + 6); ctx.fillStyle = '#c8202a'; ctx.fillRect(x + w - 1, y - 3, 3, h + 6);
  }

  /** A runner's dot on the strip: its first silk with a rim. */
  function drawDot(ctx, look, R) {
    ctx.fillStyle = silk(look.silk[0]); ctx.beginPath(); ctx.arc(0, 0, R, 0, TAU); ctx.fill();
    ctx.fillStyle = silk(look.silk[1]); ctx.beginPath(); ctx.arc(0, 0, R * 0.45, 0, TAU); ctx.fill();
    ctx.strokeStyle = '#1a1208'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(0, 0, R, 0, TAU); ctx.stroke();
  }

  /** The lane board at the left edge: each lane's number cloth, fixed while the course scrolls. */
  function drawLaneBoard(ctx, W, H, card, laneH) {
    ctx.clearRect(0, 0, W, H);
    for (var i = 0; i < card.field.length; i++) {
      var y = i * laneH;
      ctx.fillStyle = 'rgba(20,12,6,0.72)'; ctx.fillRect(0, y + 1, W - 4, laneH - 2);
      ctx.save(); ctx.translate(W / 2 - 2, y + laneH / 2); drawCloth(ctx, card.field[i].look, i + 1, Math.min(34, W - 14), Math.min(24, laneH - 12)); ctx.restore();
    }
  }

  function drawCommentary(ctx, W, H, text) {
    ctx.clearRect(0, 0, W, H);
    var g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, 'rgba(23,13,7,0.92)'); g.addColorStop(1, 'rgba(10,6,3,0.96)'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = '#c9a25a'; ctx.fillRect(0, 0, W, 2);
    var size = 19; ctx.font = 'italic ' + size + 'px ' + FACE; while (size > 12 && ctx.measureText(text).width > W - 40) { size--; ctx.font = 'italic ' + size + 'px ' + FACE; }
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#f6e3b4'; ctx.fillText(text, W / 2, H / 2 + 1);
  }

  //===========================================================================
  // The photograph and the winners' enclosure
  //===========================================================================

  /**
   * The photo finish: a sepia strip photograph of the line, the leaders drawn where they stood when the winner's
   * stalks crossed. `pos` holds each shown runner's x in race units at that instant.
   */
  function drawPhoto(ctx, W, H, card, shown, core) {
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = 'rgba(0,0,0,0.55)'; ctx.fillRect(0, 0, W, H);
    var pw = Math.min(W - 80, 640), ph = 300, px = (W - pw) / 2, py = 110;
    ctx.fillStyle = '#f4ecd8'; ctx.fillRect(px - 14, py - 14, pw + 28, ph + 64);
    ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.fillRect(px - 10, py + ph + 50, pw + 28, 6);
    var g = ctx.createLinearGradient(0, py, 0, py + ph); g.addColorStop(0, '#d8c49a'); g.addColorStop(1, '#8a7048'); ctx.fillStyle = g; ctx.fillRect(px, py, pw, ph);
    var r = rng(card.raceSeed ^ 0xF070);
    for (var i = 0; i < pw * ph / 30; i++) { ctx.fillStyle = r() < 0.5 ? 'rgba(60,40,20,0.12)' : 'rgba(255,240,210,0.12)'; ctx.fillRect(px + r() * pw, py + r() * ph, 1 + r() * 2, 1); }
    // strip-camera time lines and the line itself
    ctx.strokeStyle = 'rgba(50,34,18,0.25)'; ctx.lineWidth = 1; for (var tx = px + 20; tx < px + pw; tx += 40) { ctx.beginPath(); ctx.moveTo(tx, py); ctx.lineTo(tx, py + ph); ctx.stroke(); }
    // ⛔ found by looking: at a fixed 1.2 two runners floated in a mostly empty print. Size them to the lanes.
    var laneH = ph / (shown.length + 0.3), s = Math.min(2.0, laneH / 58), lineX = px + pw * 0.64, scale = 3.2 * s;
    ctx.fillStyle = 'rgba(250,244,228,0.85)'; ctx.fillRect(lineX - 1.5, py, 3, ph);
    ctx.save(); ctx.beginPath(); ctx.rect(px, py, pw, ph); ctx.clip();
    for (var k = 0; k < shown.length; k++) {
      var sh = shown[k], y = py + (k + 0.72) * laneH, nose = lineX + (sh.x - core.LEN) * scale;
      ctx.save(); ctx.translate(nose - 40 * s, y); drawSnail(ctx, sh.look, sh.num, s); ctx.restore();
    }
    // tone the whole print sepia with a colour blend (ctx.filter is not in every browser MZ exports to)
    ctx.globalCompositeOperation = 'color'; ctx.fillStyle = '#8a6a40'; ctx.fillRect(px, py, pw, ph); ctx.globalCompositeOperation = 'source-over';
    ctx.restore();
    ctx.fillStyle = '#3a2410'; ctx.font = 'bold 13px ' + FACE; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText('PHOTOGRAPH  ·  ' + String(card.name).toUpperCase(), px, py + ph + 22);
    ctx.textAlign = 'right'; ctx.font = 'italic 13px ' + FACE; ctx.fillText('the judge’s print', px + pw, py + ph + 22);
    // the stamp
    ctx.save(); ctx.translate(px + pw - 90, py + 46); ctx.rotate(-0.18); ctx.strokeStyle = 'rgba(168,35,42,0.85)'; ctx.lineWidth = 3; rr(ctx, -74, -20, 148, 40, 5); ctx.stroke();
    ctx.fillStyle = 'rgba(168,35,42,0.85)'; ctx.font = 'bold 20px ' + FACE; ctx.textAlign = 'center'; ctx.fillText('PHOTOGRAPH', 0, 1); ctx.restore();
  }

  /** A rosette: ribbon tails, a pleated ring and a centre disc with the placing. */
  function drawRosette(ctx, R, place) {
    var col = ['#c8202a', '#1f4fb8', '#e0b020'][place] || '#6a6a6a';
    ctx.fillStyle = col; for (var t = -1; t <= 1; t += 2) { ctx.beginPath(); ctx.moveTo(t * R * 0.25, R * 0.4); ctx.lineTo(t * R * 0.55, R * 2.1); ctx.lineTo(t * R * 0.3, R * 1.85); ctx.lineTo(t * R * 0.12, R * 2.1); ctx.lineTo(t * R * 0.05, R * 0.4); ctx.closePath(); ctx.fill(); }
    for (var i = 0; i < 20; i++) { var a = i / 20 * TAU; ctx.fillStyle = i % 2 ? col : '#fbf5e6'; ctx.beginPath(); ctx.moveTo(0, 0); ctx.arc(0, 0, R, a, a + TAU / 20); ctx.closePath(); ctx.fill(); }
    ctx.fillStyle = col; ctx.beginPath(); ctx.arc(0, 0, R * 0.62, 0, TAU); ctx.fill();
    ctx.strokeStyle = '#f6e3b4'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(0, 0, R * 0.55, 0, TAU); ctx.stroke();
    ctx.fillStyle = '#fbf5e6'; ctx.font = 'bold ' + Math.round(R * 0.6) + 'px ' + FACE; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(['1st', '2nd', '3rd'][place] || '', 0, 1);
  }

  /**
   * The result board: placed runners with rosettes, margins and starting prices, and how the player's bet went.
   * @param {Object} res {rows:[{num, runner, sp, margin}], bet: string, won: boolean, detail: string}
   */
  /** The result board's table and paper: drawn ONCE per visit (gate: painting it at the finish cost a 25-60 ms frame). */
  function drawResultBack(ctx, W, H) { drawTable(ctx, W, H); drawPaper(ctx, 40, 30, W - 80, H - 60, 0x2E5); }

  function drawResult(ctx, W, H, card, res) {
    ctx.clearRect(0, 0, W, H);
    var x = 40, y = 30, w = W - 80, h = H - 60;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#a8232a'; ctx.font = 'bold 13px ' + FACE; ctx.fillText('RESULT  ·  ' + String(card.name).toUpperCase(), W / 2, y + 34);
    ctx.fillStyle = '#1e140c'; ctx.font = 'bold 28px ' + FACE; ctx.fillText(res.headline, W / 2, y + 64);
    ctx.font = 'italic 13px ' + FACE; ctx.fillStyle = '#5a4430';
    ctx.fillText(card.course.name + ' course  ·  going ' + { dewy: 'dewy', damp: 'damp', dry: 'dry' }[card.going] + '  ·  ' + card.field.length + ' ran', W / 2, y + 90);
    // ⛔ found by looking: 104 px rows left a dead band above the bet line; bigger runners, rows spread to fill
    for (var i = 0; i < res.rows.length; i++) {
      var row = res.rows[i], ry = y + 114 + i * 112;
      ctx.save(); ctx.translate(x + 70, ry + 30); drawRosette(ctx, 26, i); ctx.restore();
      ctx.save(); ctx.translate(x + 196, ry + 48); drawSnail(ctx, row.runner.look, row.num, 1.22); ctx.restore();
      ctx.textAlign = 'left'; ctx.fillStyle = '#1e140c'; ctx.font = 'bold 22px ' + FACE; ctx.fillText(row.runner.name, x + 290, ry + 26);
      ctx.font = 'italic 14px ' + FACE; ctx.fillStyle = '#5a4430';
      ctx.fillText('No. ' + row.num + '  ·  starting price ' + row.sp + (row.margin ? '  ·  ' + row.margin : ''), x + 290, ry + 52);
      if (i < res.rows.length - 1) { ctx.strokeStyle = 'rgba(30,20,12,0.25)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x + 40, ry + 98); ctx.lineTo(x + w - 40, ry + 98); ctx.stroke(); }
    }
    var sy = y + h - 76;
    ctx.fillStyle = res.won ? 'rgba(47,106,42,0.12)' : 'rgba(30,20,12,0.06)'; rr(ctx, x + 40, sy, w - 80, 50, 6); ctx.fill();
    ctx.textAlign = 'center'; ctx.font = 'bold 18px ' + FACE; ctx.fillStyle = res.won ? '#2f6a2a' : '#1e140c'; ctx.fillText(res.bet, W / 2, sy + 18);
    ctx.font = 'italic 13px ' + FACE; ctx.fillStyle = '#5a4430'; ctx.fillText(res.detail, W / 2, sy + 38);
  }

  return {
    VERSION: '1.0.0', FACE: FACE, SHELLS: SHELLS, BODIES: BODIES, SILKS: SILKS, SILK_NAMES: SILK_NAMES, COURSES: COURSES,
    course: course, drawCloth: drawCloth, drawBody: drawBody, drawShell: drawShell, drawSnail: drawSnail, drawSurface: drawSurface,
    drawScenery: drawScenery, drawCourse: drawCourse, drawTrail: drawTrail, drawTable: drawTable, drawPaper: drawPaper, drawCardHead: drawCardHead,
    drawCardRow: drawCardRow, drawCardColumns: drawCardColumns, drawSlip: drawSlip, drawCourseMap: drawCourseMap, drawRaceHead: drawRaceHead,
    drawStrip: drawStrip, drawDot: drawDot, drawLaneBoard: drawLaneBoard, drawCommentary: drawCommentary, drawPhoto: drawPhoto,
    drawRosette: drawRosette, drawResult: drawResult, drawResultBack: drawResultBack, drawLettuce: drawLettuce, inkOn: inkOn,
  };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = DerbyDraw;
