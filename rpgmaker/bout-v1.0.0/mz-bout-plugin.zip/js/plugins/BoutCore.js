/*:
 * @target MZ
 * @plugindesc [v1.0.0] Bout 1/3 - the rules: a real-time one-on-one fight, frame data, guard, rounds, specials from skills. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * BoutCore.js holds the rules Bout uses and touches no part of the engine. Turn it on together with BoutDraw.js and
 * Bout.js; the order does not matter. See Readme_for_Users.md.
 */
/* BoutCore - pure rules, no engine code, runs in Node for the tests (module.exports) and in MZ (window.BoutCore).
 * A fixed 60 Hz step over a 1,000 px stage, x to the right, y up from the ground. Copyright (c) 2026 Core Systems Asset
 * Factory. */
var BoutCore = (function () {
  'use strict';
  function mix(a, b) { var h = (a ^ Math.imul(b | 0, 0x9E3779B1)) >>> 0; h = Math.imul(h ^ (h >>> 16), 0x85EBCA6B) >>> 0; h = Math.imul(h ^ (h >>> 13), 0xC2B2AE35) >>> 0; return (h ^ (h >>> 16)) >>> 0; }
  function hashString(s) { var h = 2166136261 >>> 0; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; } return h >>> 0; }
  function rand(st) { st.rs = (st.rs + 0x6D2B79F5) | 0; var t = st.rs; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }

  // MAX_HP 300: a round of a handful of decisive exchanges, not ~25 (at 1000 any small per-exchange edge compounded into a
  // certain win and every tier beat the one below 100%: balance_probe v3, exp_hp.js 2026-10-12)
  var STAGE_W = 1000, WALL = 40, PUSH_W = 28, MAX_HP = 300, GUARD_MAX = 100, METER_MAX = 100, SPECIAL_COST = 50;
  var WALK_F = 4, WALK_B = 3, JUMP_V = 12, GRAV = 0.55, INTRO = 90, ROUND_END_FRAMES = 150, HITSTOP = 5;
  var INPUT = { LEFT: 1, RIGHT: 2, UP: 4, DOWN: 8, LIGHT: 16, HEAVY: 32, SPECIAL: 64, GUARD: 128 };
  var S = { IDLE: 0, WALK: 1, JUMP: 2, GUARD: 3, ATTACK: 4, HITSTUN: 5, BLOCKSTUN: 6, KO: 7, WIN: 8, CROUCH: 9 };
  /**
   * Where a hit lands, and so which guard stops it: MID (either guard), LOW (only a CROUCHING guard: GUARD + DOWN), HIGH
   * (only a STANDING guard: the jump-in and anything falling from above), THROW (no guard at all, but only a fighter who is
   * standing, walking, crouching or guarding: any strike beats it). Before these, one guard blocked everything and the
   * faster reactor won every exchange (balance_probe 2026-10-11: a 10-frame player beat normal 100% and lost to hard 97%).
   */
  var LEVEL = { MID: 0, LOW: 1, HIGH: 2, THROW: 3 };
  /**
   * normal moves: frames, damage, reach (the gap between the two bodies it covers), stun on hit and on guard, chip, level.
   * Frame advantage on block, as core.test MEASURES it (the formula blockstun - (active - 1 + recovery) reads one frame kinder
   * than the step order delivers): light -2 (safe from a punish, loses a mash-off: at +1 a fighter mashing light kept the
   * hard AI pinned and won 78-85%, balance_probe v3), heavy punishable by a light, a throw that whiffs recovers 22 frames.
   */
  var MOVES = {
    light: { startup: 4, active: 3, recovery: 8, damage: 40, reach: 70, hitstun: 14, blockstun: 9, chip: 0, push: 5, air: false, level: LEVEL.MID },
    low: { startup: 5, active: 3, recovery: 9, damage: 35, reach: 66, hitstun: 13, blockstun: 9, chip: 0, push: 4, air: false, level: LEVEL.LOW },
    heavy: { startup: 9, active: 4, recovery: 16, damage: 70, reach: 92, hitstun: 20, blockstun: 12, chip: 6, push: 9, air: false, level: LEVEL.MID },
    air: { startup: 5, active: 8, recovery: 4, damage: 60, reach: 64, hitstun: 16, blockstun: 10, chip: 3, push: 6, air: true, level: LEVEL.HIGH },
    throw: { startup: 3, active: 2, recovery: 22, damage: 60, reach: 14, hitstun: 34, blockstun: 0, chip: 0, push: 14, air: false, level: LEVEL.THROW },
  };
  /** special shapes: base damage, startup, recovery; the rest is per shape in fire() */
  var SHAPES = {
    projectile: { damage: 70, startup: 12, recovery: 18 }, rush: { damage: 80, startup: 8, recovery: 20 }, rising: { damage: 90, startup: 3, recovery: 26 },
    'ground-wave': { damage: 60, startup: 14, recovery: 18 }, burst: { damage: 85, startup: 18, recovery: 22 }, rain: { damage: 75, startup: 16, recovery: 20 },
    'drain-tether': { damage: 55, startup: 10, recovery: 20 },
  };

  /**
   * A special from one of the fighter's own skills (an MZ database row), or null when the skill deals no damage to an
   * enemy. Shape from the skill's own fields (hit type, scope, speed, damage type); element from the database's element
   * list; tier 1-3 from its MP cost (the stock table carries I / II / III by cost). Measured on the stock database by
   * _probe/stock_specials.js.
   * @param {object} s an RPG Maker MZ skill row @param {string[]} elements $dataSystem.elements
   */
  function specialFrom(s, elements) {
    if (!s || !s.damage || (s.damage.type !== 1 && s.damage.type !== 5) || !(s.scope >= 1 && s.scope <= 6)) return null;
    var phys = s.hitType === 1, all = s.scope === 2, rnd = s.scope >= 3 && s.scope <= 6, shape;
    if (s.damage.type === 5) shape = 'drain-tether'; else if (rnd) shape = 'rain'; else if (phys) shape = all ? 'ground-wave' : (s.speed > 0 ? 'rising' : 'rush'); else shape = all ? 'burst' : 'projectile';
    var eid = s.damage.elementId, element = eid > 0 ? String((elements && elements[eid]) || 'Element ' + eid) : eid === -1 ? 'Weapon' : 'None';
    var cost = Number(s.mpCost) || 0, tier = cost >= 25 ? 3 : cost >= 10 ? 2 : 1, B = SHAPES[shape];
    return { skillId: s.id, name: String(s.name || ''), shape: shape, element: element, tier: tier, damage: B.damage + 25 * (tier - 1), startup: B.startup, recovery: B.recovery };
  }

  function fighter(x, face) { return { x: x, y: 0, vx: 0, vy: 0, face: face, state: S.IDLE, move: '', mf: 0, hitDone: false, hp: MAX_HP, guard: GUARD_MAX, meter: 0, stun: 0, spec: -1, specials: [], lastIn: 0, hits: 0, pd: 0, ph: 0, pb: 0, pc: 0, pp: 0, pdr: 0, pl: 0, blocks: 0, throws: 0 }; }
  function shot() { return { live: false, owner: 0, x: 0, y: 0, vx: 0, vy: 0, spec: null, age: 0, targetX: 0 }; }
  /**
   * A match. o: {seed, rounds (odd, default 3), roundFrames (default 99 s), ai: [null|'easy'|'normal'|'hard', ...]}.
   */
  function createMatch(o) {
    o = o || {};
    var g = { st: { rs: mix(hashString('bout'), (o.seed >>> 0) || 1) | 0 }, rounds: Math.max(1, (o.rounds | 0) || 3), roundFrames: Math.max(60, (o.roundFrames | 0) || 99 * 60),
      ai: [o.ai ? o.ai[0] || null : null, o.ai ? o.ai[1] || null : null], round: 1, wins: [0, 0], phase: 'intro', introT: INTRO, endT: 0, time: 0, timeOver: false, ko: -1,
      winner: -1, freeze: 0, frame: 0, f: [fighter(330, 1), fighter(670, -1)], shots: [shot(), shot()], aiIn: [0, 0], aiT: [0, 0], events: 0 };
    g.time = g.roundFrames;
    return g;
  }
  function resetRound(g) {
    for (var i = 0; i < 2; i++) { var F = g.f[i], keep = F.specials, meter = F.meter; var n = fighter(i ? 670 : 330, i ? -1 : 1); for (var k in n) F[k] = n[k]; F.specials = keep; F.meter = meter; g.shots[i].live = false; }
    g.time = g.roundFrames; g.timeOver = false; g.ko = -1; g.phase = 'intro'; g.introT = INTRO; g.freeze = 0;
  }
  function skipIntro(g) { g.phase = 'fight'; g.introT = 0; }
  function needed(g) { return Math.floor(g.rounds / 2) + 1; }
  function grounded(F) { return F.y <= 0 && F.state !== S.JUMP; }
  function gapOf(g) { return Math.abs(g.f[1].x - g.f[0].x) - PUSH_W * 2; }

  /** does a fighter guarding this frame stop a hit of this level? Holding GUARD guards standing, GUARD + DOWN crouching. */
  function blocks(D, level) {
    if (level === LEVEL.THROW) return false;
    var guarding = (D.lastIn & INPUT.GUARD) && grounded(D) && (D.state === S.IDLE || D.state === S.WALK || D.state === S.GUARD || D.state === S.CROUCH || D.state === S.BLOCKSTUN);
    if (!guarding) return false;
    var low = (D.lastIn & INPUT.DOWN) !== 0;
    return level === LEVEL.MID || (level === LEVEL.LOW && low) || (level === LEVEL.HIGH && !low);
  }
  /** one hit from attacker a on defender d, landing at `level`; the right guard turns it to blockstun + chip; KO ends the round. */
  function land(g, a, d, dmg, hitstun, blockstun, chip, push, level) {
    var A = g.f[a], D = g.f[d];
    if (D.state === S.KO) return;
    if (blocks(D, level) && D.guard > 0) {
      D.hp -= chip; D.guard -= Math.ceil(dmg * 0.25); D.state = S.BLOCKSTUN; D.stun = blockstun; D.vx = A.face * push * 0.6; D.blocks++;
      if (D.guard <= 0) { D.guard = 50; D.state = S.HITSTUN; D.stun = 40; }
    } else {
      if (level === LEVEL.THROW) A.throws++;
      D.hp -= dmg; D.state = S.HITSTUN; D.stun = hitstun; D.vx = A.face * push; D.move = ''; D.spec = -1; if (D.y > 0) { D.vy = 4; }
      A.meter = Math.min(METER_MAX, A.meter + 8); D.meter = Math.min(METER_MAX, D.meter + 4); A.hits++;
    }
    g.freeze = HITSTOP; g.events |= 1;
    if (D.hp <= 0) { D.hp = 0; D.state = S.KO; D.stun = 0; A.state = S.WIN; endRound(g, a); }
  }
  function endRound(g, winnerIdx) {
    if (g.phase !== 'fight') return;
    g.phase = 'roundEnd'; g.endT = ROUND_END_FRAMES; g.ko = winnerIdx;
    if (winnerIdx >= 0) g.wins[winnerIdx]++;
    g.shots[0].live = false; g.shots[1].live = false;
  }

  /** start the fighter's special (index k), paid from its meter, if it has one and the meter allows */
  function startSpecial(g, i, k) {
    var F = g.f[i], sp = F.specials[k];
    if (!sp || F.meter < SPECIAL_COST) return false;
    F.meter -= SPECIAL_COST; F.state = S.ATTACK; F.move = 'special'; F.spec = k; F.mf = 0; F.hitDone = false; F.vx = 0;
    return true;
  }
  /** what a special does on the frame it fires (mf === startup) and while it is active */
  function specialTick(g, i) {
    var F = g.f[i], sp = F.specials[F.spec], o = 1 - i, D = g.f[o], Sh = g.shots[i], gap = gapOf(g), facing = (D.x - F.x) * F.face > 0;
    if (!sp) return;
    if (F.mf === sp.startup) {
      if (sp.shape === 'projectile' || sp.shape === 'ground-wave') { Sh.live = true; Sh.owner = i; Sh.spec = sp; Sh.x = F.x + F.face * 40; Sh.y = sp.shape === 'ground-wave' ? 0 : 60; Sh.vx = F.face * (sp.shape === 'ground-wave' ? 6 : 7 + sp.tier * 2); Sh.vy = 0; Sh.age = 0; }
      else if (sp.shape === 'rain' || sp.shape === 'burst') { Sh.live = true; Sh.owner = i; Sh.spec = sp; Sh.targetX = D.x; Sh.x = D.x; Sh.y = 260; Sh.vx = 0; Sh.vy = -9; Sh.age = 0; }
    }
    var act = F.mf >= sp.startup && F.mf < sp.startup + 12;
    if (!act || F.hitDone) return;
    if (sp.shape === 'rush') { F.vx = F.face * 14; if (gap <= 18 && facing) { F.hitDone = true; F.vx = 0; pend(F, sp.damage, 22, 12, 8, 12, 0, LEVEL.MID); } }
    else if (sp.shape === 'rising') { F.y = Math.max(F.y, (F.mf - sp.startup) * 9); if (gap <= 40 && facing && D.state !== S.KO) { F.hitDone = true; pend(F, sp.damage, 24, 12, 8, 6, 0, LEVEL.MID); } }
    else if (sp.shape === 'drain-tether') { if (gap <= 230 && facing) { F.hitDone = true; pend(F, sp.damage, 18, 10, 4, 3, 0.5, LEVEL.MID); } }
  }
  /** a hit waits until both fighters have moved this frame; step() resolves the two together (they TRADE) */
  function pend(F, dmg, hitstun, blockstun, chip, push, drain, level) { F.pd = dmg; F.ph = hitstun; F.pb = blockstun; F.pc = chip; F.pp = push; F.pdr = drain; F.pl = level; }
  function resolve(g, i) {
    var F = g.f[i], D = g.f[1 - i]; if (!F.pd) return;
    var dmg = F.pd, h0 = D.hp, dr = F.pdr; F.pd = 0; F.pdr = 0;
    land(g, i, 1 - i, dmg, F.ph, F.pb, F.pc, F.pp, F.pl);
    if (dr > 0) F.hp = Math.min(MAX_HP, F.hp + Math.round((h0 - D.hp) * dr));
  }
  function shotTick(g, i) {
    var Sh = g.shots[i]; if (!Sh.live) return;
    var o = 1 - Sh.owner, D = g.f[o];
    Sh.age++; Sh.x += Sh.vx; Sh.y += Sh.vy; if (Sh.y < 0) Sh.y = 0;
    if (Sh.x < 0 || Sh.x > STAGE_W || Sh.age > 240) { Sh.live = false; return; }
    var dx = Math.abs(Sh.x - D.x), sp = Sh.spec;
    var hit = (sp.shape === 'rain' || sp.shape === 'burst') ? (Sh.y <= 0 && dx < PUSH_W + 30) : (dx < PUSH_W + 10 && (sp.shape !== 'ground-wave' || D.y < 30));
    // what falls from above is HIGH (a crouching guard does not stop it), a wave along the ground is LOW, a shot is MID
    if (sp.shape === 'rain' || sp.shape === 'burst') { if (Sh.y <= 0) { Sh.live = false; if (hit) land(g, Sh.owner, o, sp.damage, 20, 10, 6, 4, LEVEL.HIGH); } return; }
    if (hit && D.state !== S.KO) { Sh.live = false; land(g, Sh.owner, o, sp.damage, 18, 10, 6, 6, sp.shape === 'ground-wave' ? LEVEL.LOW : LEVEL.MID); }
  }

  /** one fighter's frame from its input bits. Allocates nothing. */
  function updateFighter(g, i, inp) {
    var F = g.f[i], o = g.f[1 - i], fwd = F.face > 0 ? INPUT.RIGHT : INPUT.LEFT, back = F.face > 0 ? INPUT.LEFT : INPUT.RIGHT, m;
    F.lastIn = inp;
    if (F.state === S.KO || F.state === S.WIN) { F.vx *= 0.8; return; }
    if (F.state === S.HITSTUN || F.state === S.BLOCKSTUN) { if (--F.stun <= 0) { F.stun = 0; F.state = F.y > 0 ? S.JUMP : S.IDLE; } F.vx *= 0.85; return; }
    if (F.state === S.ATTACK) {
      F.mf++;
      if (F.move === 'special') {
        var sp = F.specials[F.spec]; specialTick(g, i);
        if (!sp || F.mf >= sp.startup + 12 + sp.recovery) { F.state = F.y > 0 ? S.JUMP : S.IDLE; F.move = ''; F.spec = -1; F.vx = 0; }
        return;
      }
      m = MOVES[F.move];
      if (!F.hitDone && F.mf >= m.startup && F.mf < m.startup + m.active) {
        var gap = gapOf(g), facing = (o.x - F.x) * F.face > 0, high = m.air ? Math.abs(o.y - F.y) < 90 : o.y < 90;
        // a throw takes only a fighter who is on the ground and free (idle, walking, crouching or guarding): anyone already
        // attacking, airborne, in hitstun or in blockstun is out of its reach, so a strike beats a throw and blockstun is safe
        if (m.level === LEVEL.THROW) high = o.y <= 0 && (o.state === S.IDLE || o.state === S.WALK || o.state === S.GUARD || o.state === S.CROUCH);
        // the hit is PENDING until both fighters have moved this frame (step() resolves both together): landing it here let
        // whichever fighter updated first cancel the other's simultaneous hit (balance_probe: the AI mirror went 88-100%
        // to player 1)
        if (gap <= m.reach && facing && high) { F.hitDone = true; pend(F, m.damage, m.hitstun, m.blockstun, m.chip, m.push, 0, m.level); }
      }
      if (F.mf >= m.startup + m.active + m.recovery) { F.state = F.y > 0 ? S.JUMP : S.IDLE; F.move = ''; }
      if (!m.air) F.vx = 0;
      return;
    }
    // free states: idle, walk, guard, jump
    if (F.state === S.JUMP) { if (inp & (INPUT.LIGHT | INPUT.HEAVY)) { F.state = S.ATTACK; F.move = 'air'; F.mf = 0; F.hitDone = false; } return; }
    if (inp & INPUT.SPECIAL) { var k = (inp & fwd) ? 1 : (inp & back) ? 2 : 0; if (k >= F.specials.length) k = 0; if (startSpecial(g, i, k)) return; }
    // LIGHT + HEAVY together is a throw; DOWN + LIGHT is the crouching low (it must be crouch-guarded)
    var mv = (inp & INPUT.LIGHT) && (inp & INPUT.HEAVY) ? 'throw' : (inp & INPUT.LIGHT) ? ((inp & INPUT.DOWN) ? 'low' : 'light') : (inp & INPUT.HEAVY) ? 'heavy' : '';
    if (mv) { F.state = S.ATTACK; F.move = mv; F.mf = 0; F.hitDone = false; F.vx = 0; return; }
    if (inp & INPUT.UP) { F.state = S.JUMP; F.vy = JUMP_V; F.vx = (inp & fwd) ? F.face * 3.5 : (inp & back) ? -F.face * 3 : 0; F.y = 0.01; return; }
    if (inp & INPUT.GUARD) { F.state = S.GUARD; F.vx = 0; return; }
    if (inp & INPUT.DOWN) { F.state = S.CROUCH; F.vx = 0; return; }
    if (inp & fwd) { F.state = S.WALK; F.vx = F.face * WALK_F; } else if (inp & back) { F.state = S.WALK; F.vx = -F.face * WALK_B; } else { F.state = S.IDLE; F.vx = 0; }
  }
  /**
   * The AI's input for this frame: a decision every `react` + up to `jit` frames (a person's reactions are not a metronome),
   * held in between (seeded, so replayable). `read` is the chance it guards at the RIGHT height: a low seen coming is
   * crouch-guarded, a jump-in stand-guarded, otherwise it guesses. `mix` is how often its close-range offence is a low or a
   * throw rather than a standing hit; `jump` how often it jumps in from mid range.
   */
  // Tiers set from sweeps (exp_ai.js, 2026-10-12, a 300 HP round): a competent scripted player (decides every 10 frames,
  // guards 85% of threats it sees, reads a low 65%) beats easy 83-88%, normal 45-65%, hard 33-35%; normal beats easy 75-83%,
  // hard beats normal 70-73%. The curve is steep in reaction time: hard at react 5 instead of 6 took that player from ~35% to
  // 8-20%, so change these a frame at a time and re-run balance_probe.js.
  var AI = {
    // BEGINNER is for a player new to fighting games (balance_probe v4: a novice beat easy 2-3%). Swept (exp_beginner.js):
    // a novice (18-frame decisions, guards 60% of what it sees) beats it 60-65%, the competent player 100%. A button-masher
    // beats no tier: mashing light is -2 on block and every tier punishes it.
    beginner: { react: 12, jit: 8, guard: 0.7, read: 0.6, aggr: 0.5, mix: 0.35, jump: 0.05, special: 0.15, punish: 0.6, wake: 0.6 },
    easy: { react: 7, jit: 5, guard: 0.94, read: 0.82, aggr: 0.55, mix: 0.5, jump: 0.05, special: 0.3, punish: 0.92, wake: 0.92 },
    normal: { react: 6, jit: 4, guard: 0.95, read: 0.85, aggr: 0.55, mix: 0.55, jump: 0.1, special: 0.3, punish: 0.95, wake: 0.95 },
    hard: { react: 6, jit: 3, guard: 0.96, read: 0.88, aggr: 0.65, mix: 0.6, jump: 0.15, special: 0.4, punish: 1, wake: 1 },
  };
  var TAP = INPUT.LIGHT | INPUT.HEAVY | INPUT.SPECIAL | INPUT.UP;
  function aiInput(g, i) {
    var P = AI[g.ai[i]] || AI.normal, F = g.f[i], O = g.f[1 - i], fwd = F.face > 0 ? INPUT.RIGHT : INPUT.LEFT, back = F.face > 0 ? INPUT.LEFT : INPUT.RIGHT;
    // out of stun the AI may act AT ONCE (a held button out of blockstun), with probability `wake`: a decision clock that
    // ignores the fighter's own recovery let a light-masher keep every tier pinned (balance_probe v3)
    var stunned = F.state === S.HITSTUN || F.state === S.BLOCKSTUN;
    if (stunned) { if (F.stun <= 1 && rand(g.st) < P.wake) g.aiT[i] = 1; }
    if (--g.aiT[i] > 0) { var held = g.aiIn[i]; return held & TAP ? held & ~TAP : held; }
    g.aiT[i] = P.react + Math.floor(rand(g.st) * (P.jit + 1)); var gap = gapOf(g), r = rand(g.st), out = 0;
    var threatened = (O.state === S.ATTACK && O.mf < 10) || g.shots[1 - i].live || (O.y > 30 && gap < 140);
    // a punish: the opponent is recovering from a move that is past its active frames, in reach of a light
    var om = O.state === S.ATTACK && O.move && MOVES[O.move], recovering = om && O.mf >= om.startup + om.active;
    if (recovering && gap <= MOVES.light.reach && rand(g.st) < P.punish) { out = INPUT.LIGHT; g.aiIn[i] = out; return out; }
    if (threatened && r < P.guard) {
      // the guard's height: read the threat right with probability `read`, otherwise the other height
      var wantLow = O.state === S.ATTACK && O.move === 'low', wantHigh = O.y > 0 || (O.state === S.ATTACK && O.move === 'air');
      var right = rand(g.st) < P.read, low = wantLow ? right : wantHigh ? !right : rand(g.st) < 0.5;
      out = INPUT.GUARD | (low ? INPUT.DOWN : 0);
    }
    else if (O.y > 40 && gap < 80 && F.specials.length && F.meter >= SPECIAL_COST && r < P.special + P.guard * 0.3) out = INPUT.SPECIAL;
    else if (gap > 120) { var r2 = rand(g.st); out = (F.specials.length && F.meter >= SPECIAL_COST && r2 < P.special) ? INPUT.SPECIAL : (gap < 260 && r2 > 1 - P.jump) ? INPUT.UP | fwd : fwd; }
    else if (gap > MOVES.light.reach) {
      // THE EDGE OF REACH: walking in here was where a forward-walking masher caught it (trace_match: 38 of 51 hits landed on
      // a WALKING AI). An opponent coming in or swinging is met with a guard or a heavy poke at the edge; a passive one is
      // approached.
      var advancing = (O.vx * (F.x - O.x) > 0) || O.state === S.ATTACK;
      if (advancing) out = r < P.guard ? INPUT.GUARD | (rand(g.st) < 0.3 ? INPUT.DOWN : 0) : (gap <= MOVES.heavy.reach ? INPUT.HEAVY : back);
      else out = r < P.aggr ? (gap <= MOVES.heavy.reach && rand(g.st) < 0.4 ? INPUT.HEAVY : fwd) : INPUT.GUARD;
    }
    else if (gap <= MOVES.light.reach) {
      if (r < P.aggr) {
        var r3 = rand(g.st);
        // a throw only from point blank and mostly against a fighter who is guarding (a throw is the answer to guard)
        if (gap <= MOVES.throw.reach && r3 < P.mix * ((O.state === S.GUARD || O.state === S.CROUCH) ? 0.9 : 0.3)) out = INPUT.LIGHT | INPUT.HEAVY;
        else if (r3 < P.mix) out = INPUT.LIGHT | INPUT.DOWN;
        else out = rand(g.st) < 0.6 ? INPUT.LIGHT : INPUT.HEAVY;
        if (gap > MOVES.light.reach && out !== INPUT.HEAVY) out = fwd;   // beyond a light's reach only the heavy connects: close in
      } else out = rand(g.st) < 0.5 ? back : INPUT.GUARD | (rand(g.st) < 0.5 ? INPUT.DOWN : 0);
    }
    else out = r < P.aggr ? fwd : back;
    g.aiIn[i] = out; return out;
  }
  /**
   * One frame. in0/in1 are INPUT bitmasks for the two fighters (ignored for a fighter the AI plays). Allocates nothing.
   */
  function step(g, in0, in1) {
    g.frame++; g.events = 0;
    if (g.phase === 'matchEnd') return;
    if (g.phase === 'intro') { if (--g.introT <= 0) g.phase = 'fight'; return; }
    if (g.phase === 'roundEnd') {
      g.f[0].vx *= 0.8; g.f[1].vx *= 0.8;
      if (--g.endT <= 0) { var need = needed(g); if (g.wins[0] >= need || g.wins[1] >= need || g.round >= g.rounds) { g.phase = 'matchEnd'; g.winner = g.wins[0] > g.wins[1] ? 0 : g.wins[1] > g.wins[0] ? 1 : -1; } else { g.round++; resetRound(g); } }
      return;
    }
    if (g.freeze > 0) { g.freeze--; return; }
    var a = g.ai[0] ? aiInput(g, 0) : in0, b = g.ai[1] ? aiInput(g, 1) : in1, left = g.f[0].x <= g.f[1].x ? 0 : 1, i, F;
    updateFighter(g, 0, a); if (g.phase !== 'fight') return;
    updateFighter(g, 1, b); if (g.phase !== 'fight') return;
    // simultaneous hits TRADE: both pending normals land, in either order, each with the move it was swinging
    // (the frame's two pending hits are taken in an order that ALTERNATES by frame, so even a double KO favours no seat)
    if (g.frame & 1) { resolve(g, 1); if (g.f[0].state !== S.KO) resolve(g, 0); } else { resolve(g, 0); if (g.f[1].state !== S.KO) resolve(g, 1); }
    g.f[0].pd = 0; g.f[1].pd = 0;
    if (g.phase !== 'fight') return;
    for (i = 0; i < 2; i++) {
      F = g.f[i];
      F.x += F.vx;
      if (F.state === S.JUMP || (F.state === S.ATTACK && F.move === 'air') || F.y > 0) { if (!(F.move === 'special' && F.specials[F.spec] && F.specials[F.spec].shape === 'rising' && F.state === S.ATTACK)) { F.y += F.vy; F.vy -= GRAV; } if (F.y <= 0) { F.y = 0; F.vy = 0; if (F.state === S.JUMP || (F.state === S.ATTACK && F.move === 'air')) { F.state = S.IDLE; F.move = ''; F.vx = 0; } } }
      if (F.x < WALL + PUSH_W) F.x = WALL + PUSH_W; if (F.x > STAGE_W - WALL - PUSH_W) F.x = STAGE_W - WALL - PUSH_W;
    }
    // the pushbox: the left fighter stays left and the two bodies never overlap
    var L = g.f[left], R = g.f[1 - left], over = L.x + PUSH_W * 2 - R.x;
    if (over > 0) { L.x -= over / 2; R.x += over / 2; if (L.x < WALL + PUSH_W) { R.x += WALL + PUSH_W - L.x; L.x = WALL + PUSH_W; } if (R.x > STAGE_W - WALL - PUSH_W) { L.x -= R.x - (STAGE_W - WALL - PUSH_W); R.x = STAGE_W - WALL - PUSH_W; } }
    for (i = 0; i < 2; i++) { F = g.f[i]; if (grounded(F) && F.state !== S.ATTACK && F.state !== S.HITSTUN && F.state !== S.BLOCKSTUN) F.face = g.f[1 - i].x >= F.x ? 1 : -1; }
    // shots also alternate their order by frame (an ordered pair handed every simultaneous projectile KO to the first seat)
    if (g.frame & 1) { shotTick(g, 1); if (g.phase !== 'fight') return; shotTick(g, 0); } else { shotTick(g, 0); if (g.phase !== 'fight') return; shotTick(g, 1); }
    if (g.phase !== 'fight') return;
    if (g.frame % 6 === 0) { if (g.f[0].meter < METER_MAX) g.f[0].meter++; if (g.f[1].meter < METER_MAX) g.f[1].meter++; }
    if (--g.time <= 0) { g.time = 0; g.timeOver = true; var s0 = g.f[0].hp, s1 = g.f[1].hp; endRound(g, s0 > s1 ? 0 : s1 > s0 ? 1 : -1); }
  }
  return { VERSION: '1.0.0', mix: mix, hashString: hashString, rand: rand, STAGE_W: STAGE_W, WALL: WALL, PUSH_W: PUSH_W, MAX_HP: MAX_HP, METER_MAX: METER_MAX, SPECIAL_COST: SPECIAL_COST,
    ROUND_END_FRAMES: ROUND_END_FRAMES, INTRO: INTRO, INPUT: INPUT, S: S, LEVEL: LEVEL, MOVES: MOVES, blocks: blocks, SHAPES: SHAPES, AI: AI, specialFrom: specialFrom, createMatch: createMatch, skipIntro: skipIntro, step: step, resetRound: resetRound };
}());
if (typeof module !== 'undefined' && module.exports) module.exports = BoutCore;
