/*:
 * @target MZ
 * @plugindesc [v1.0.0] Bout 2/3 - the drawing: arenas, health and guard bars, arcade lettering, element hit sparks and every special. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * BoutDraw.js draws everything Bout puts on screen except your fighters, who are your actors' own side-view battler
 * sheets. It touches no part of the engine. Turn it on together with BoutCore.js and Bout.js; the order does not matter.
 */
/* BoutDraw - pure Canvas 2D drawing, no engine code: every function takes a CanvasRenderingContext2D. Runs in MZ
 * (window.BoutDraw) and in headless Chromium for the contact sheets. Copyright (c) 2026 Core Systems Asset Factory. */
var BoutDraw = (function () {
  'use strict';
  function hash(a, b, s) { var h = (Math.imul(a | 0, 374761393) + Math.imul(b | 0, 668265263) + Math.imul(s | 0, 2147483647)) >>> 0; h = Math.imul(h ^ (h >>> 13), 1274126177) >>> 0; return (h ^ (h >>> 16)) / 4294967296; }
  function rgb(c, a) { return 'rgba(' + Math.round(c[0]) + ',' + Math.round(c[1]) + ',' + Math.round(c[2]) + ',' + (a === undefined ? 1 : a) + ')'; }
  function mix(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }
  function lum(c) { return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; }

  //---------------------------------------------------------------------------
  // ELEMENTS: a look per element, DERIVED from the buyer's own element names (MZ's stock list is Physical, Fire, Ice,
  // Thunder, Water, Earth, Wind, Light, Darkness). A name no keyword matches gets a hue hashed from the name itself, so a
  // custom element still has its own colour, never a default (Lazaret lesson, wing §1a: the moat is derivation).
  //---------------------------------------------------------------------------
  var LOOK = {
    fire: { core: [255, 232, 140], hot: [255, 140, 40], dark: [170, 40, 20], form: 'flame' },
    ice: { core: [235, 250, 255], hot: [120, 210, 255], dark: [40, 90, 170], form: 'shard' },
    thunder: { core: [255, 255, 210], hot: [255, 220, 60], dark: [150, 110, 20], form: 'bolt' },
    water: { core: [220, 245, 255], hot: [70, 170, 240], dark: [20, 70, 140], form: 'drop' },
    earth: { core: [240, 210, 160], hot: [170, 120, 70], dark: [90, 60, 35], form: 'rock' },
    wind: { core: [235, 255, 240], hot: [120, 230, 170], dark: [30, 120, 90], form: 'gust' },
    light: { core: [255, 255, 245], hot: [255, 236, 150], dark: [200, 160, 60], form: 'star' },
    dark: { core: [230, 190, 255], hot: [150, 60, 220], dark: [40, 10, 70], form: 'void' },
    physical: { core: [255, 255, 255], hot: [255, 210, 120], dark: [140, 90, 40], form: 'impact' },
  };
  var KEYS = [['fire', /fire|flame|burn|blaze|heat|pyro/], ['ice', /ice|frost|cold|snow|freez|blizz/], ['thunder', /thunder|lightning|bolt|electr|spark|volt|storm/],
    ['water', /water|aqua|tide|wave|rain|sea/], ['earth', /earth|stone|rock|ground|quake|terra|sand/], ['wind', /wind|air|gale|gust|aero|breeze/],
    ['light', /light|holy|sacred|divine|radian|sun/], ['dark', /dark|shadow|void|curse|death|night|evil|abyss/], ['physical', /physical|weapon|none|normal|blade|strike/]];
  var custom = {};
  /** The look for an element NAME (a string from $dataSystem.elements, or 'Weapon' / 'None'). */
  function look(name) {
    var n = String(name || 'none').toLowerCase();
    for (var i = 0; i < KEYS.length; i++) if (KEYS[i][1].test(n)) return LOOK[KEYS[i][0]];
    if (custom[n]) return custom[n];
    var hsh = 0; for (var k = 0; k < n.length; k++) hsh = (Math.imul(hsh, 31) + n.charCodeAt(k)) >>> 0;
    var hue = hsh % 360, c = hsl(hue, 0.85, 0.62), forms = ['flame', 'shard', 'bolt', 'drop', 'rock', 'gust', 'star', 'void'];
    custom[n] = { core: mix(c, [255, 255, 255], 0.65), hot: c, dark: mix(c, [0, 0, 0], 0.6), form: forms[hsh % forms.length], custom: true };
    return custom[n];
  }
  function hsl(h, s, l) { var k = function (n) { return (n + h / 30) % 12; }, a = s * Math.min(l, 1 - l); var f = function (n) { return 255 * (l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)))); }; return [f(0), f(8), f(4)]; }

  //---------------------------------------------------------------------------
  // ARCADE LETTERING: a block alphabet on a 5 x 7 grid of square cells, struck as one path per glyph, filled with a
  // vertical gradient, a dark outline and a hard drop shadow, slanted. No font is used anywhere.
  //---------------------------------------------------------------------------
  var BLOCK = {
    A: ['01110', '10001', '10001', '11111', '10001', '10001', '10001'], B: ['11110', '10001', '11110', '10001', '10001', '10001', '11110'],
    C: ['01111', '10000', '10000', '10000', '10000', '10000', '01111'], D: ['11110', '10001', '10001', '10001', '10001', '10001', '11110'],
    E: ['11111', '10000', '11110', '10000', '10000', '10000', '11111'], F: ['11111', '10000', '11110', '10000', '10000', '10000', '10000'],
    G: ['01111', '10000', '10000', '10011', '10001', '10001', '01111'], H: ['10001', '10001', '11111', '10001', '10001', '10001', '10001'],
    I: ['11111', '00100', '00100', '00100', '00100', '00100', '11111'], J: ['00111', '00001', '00001', '00001', '10001', '10001', '01110'],
    K: ['10001', '10010', '11100', '10010', '10001', '10001', '10001'], L: ['10000', '10000', '10000', '10000', '10000', '10000', '11111'],
    M: ['10001', '11011', '10101', '10001', '10001', '10001', '10001'], N: ['10001', '11001', '10101', '10011', '10001', '10001', '10001'],
    O: ['01110', '10001', '10001', '10001', '10001', '10001', '01110'], P: ['11110', '10001', '10001', '11110', '10000', '10000', '10000'],
    Q: ['01110', '10001', '10001', '10001', '10101', '10010', '01101'], R: ['11110', '10001', '10001', '11110', '10010', '10001', '10001'],
    S: ['01111', '10000', '10000', '01110', '00001', '00001', '11110'], T: ['11111', '00100', '00100', '00100', '00100', '00100', '00100'],
    U: ['10001', '10001', '10001', '10001', '10001', '10001', '01110'], V: ['10001', '10001', '10001', '10001', '01010', '01010', '00100'],
    W: ['10001', '10001', '10001', '10101', '10101', '11011', '10001'], X: ['10001', '01010', '00100', '00100', '01010', '10001', '10001'],
    Y: ['10001', '01010', '00100', '00100', '00100', '00100', '00100'], Z: ['11111', '00010', '00100', '01000', '10000', '10000', '11111'],
    0: ['01110', '10011', '10101', '10101', '11001', '10001', '01110'], 1: ['00100', '01100', '00100', '00100', '00100', '00100', '01110'],
    2: ['01110', '10001', '00001', '00110', '01000', '10000', '11111'], 3: ['11110', '00001', '00001', '01110', '00001', '00001', '11110'],
    4: ['00010', '00110', '01010', '10010', '11111', '00010', '00010'], 5: ['11111', '10000', '11110', '00001', '00001', '10001', '01110'],
    6: ['01110', '10000', '11110', '10001', '10001', '10001', '01110'], 7: ['11111', '00001', '00010', '00100', '01000', '01000', '01000'],
    8: ['01110', '10001', '10001', '01110', '10001', '10001', '01110'], 9: ['01110', '10001', '10001', '01111', '00001', '00001', '01110'],
    '!': ['00100', '00100', '00100', '00100', '00100', '00000', '00100'], '.': ['00000', '00000', '00000', '00000', '00000', '00000', '00100'],
    ':': ['00000', '00100', '00100', '00000', '00100', '00100', '00000'], '-': ['00000', '00000', '00000', '01110', '00000', '00000', '00000'],
    ' ': ['00000', '00000', '00000', '00000', '00000', '00000', '00000'],
  };
  /** Width of a string in px at cell size `u` (a glyph is 5 cells plus 1 of spacing). */
  function textWidth(str, u) { return String(str).length * 6 * u - u; }
  function glyphPath(g, ch, x, y, u, slant) {
    var rows = BLOCK[ch] || BLOCK[' '];
    for (var r = 0; r < 7; r++) for (var c = 0; c < 5; c++) {
      if (rows[r][c] !== '1') continue;
      var sx = (6 - r) * u * slant, x0 = x + c * u + sx, y0 = y + r * u;
      g.moveTo(x0, y0); g.lineTo(x0 + u + 0.4, y0); g.lineTo(x0 + u + 0.4 - u * slant, y0 + u + 0.4); g.lineTo(x0 - u * slant, y0 + u + 0.4); g.closePath();
    }
  }
  /**
   * Strike a string in the arcade alphabet. style: { top, bottom, outline, shadow } colours (arrays), align 'left' |
   * 'center' | 'right'. The cell size `u` makes a glyph 7u tall.
   */
  function drawText(g, str, x, y, u, style, align) {
    str = String(str).toUpperCase(); style = style || {};
    var w = textWidth(str, u), x0 = align === 'center' ? x - w / 2 : align === 'right' ? x - w : x, slant = 0.18;
    var top = style.top || [255, 244, 170], bottom = style.bottom || [255, 150, 40], out = style.outline || [30, 14, 8], sh = style.shadow || [0, 0, 0];
    g.save();
    // the hard drop shadow, then the outline, then the face: three passes of ONE path per string
    var off = Math.max(2, u * 0.45);
    for (var pass = 0; pass < 3; pass++) {
      g.beginPath();
      for (var i = 0; i < str.length; i++) glyphPath(g, str[i], x0 + i * 6 * u + (pass === 0 ? off : 0), y + (pass === 0 ? off : 0), u, slant);
      if (pass === 0) { g.fillStyle = rgb(sh, 0.55); g.fill(); }
      else if (pass === 1) { g.lineJoin = 'miter'; g.strokeStyle = rgb(out); g.lineWidth = Math.max(2, u * 0.7); g.stroke(); }
      else { var gr = g.createLinearGradient(0, y, 0, y + 7 * u); gr.addColorStop(0, rgb(top)); gr.addColorStop(0.55, rgb(mix(top, bottom, 0.6))); gr.addColorStop(1, rgb(bottom)); g.fillStyle = gr; g.fill(); }
    }
    // a bright bevel on the top row of every glyph
    g.beginPath(); for (var j = 0; j < str.length; j++) { var rows = BLOCK[str[j]] || BLOCK[' ']; for (var c = 0; c < 5; c++) if (rows[0][c] === '1') { var bx = x0 + j * 6 * u + c * u + 6 * u * slant; g.rect(bx, y, u, Math.max(1, u * 0.28)); } }
    g.fillStyle = 'rgba(255,255,255,0.55)'; g.fill();
    g.restore();
    return w;
  }

  //---------------------------------------------------------------------------
  // BARS: two tapered health bars mirrored about the centre, a damage trail behind each, round pips for rounds won, a
  // guard bar under each and the special meter in segments at the bottom of the screen.
  //---------------------------------------------------------------------------
  /**
   * The HUD for a match state. o: { w, hp: [a, b] (0..1), trail: [a, b] (0..1, the recent-damage ghost), guard: [a, b]
   * (0..1), meter: [a, b] (0..1), wins: [a, b], need, names: [a, b], time (seconds, or -1 for no timer) }.
   */
  function drawHud(g, o) {
    var W = o.w, cx = W / 2, top = 18, bw = Math.round(W * 0.38), bh = 22;
    for (var side = 0; side < 2; side++) {
      var dir = side === 0 ? -1 : 1, x1 = cx + dir * 46, x0 = x1 + dir * bw;
      // the frame: a slanted plate, wider at the outside end (tapered toward the timer)
      var path = function (inset) { g.beginPath(); g.moveTo(x1, top + inset); g.lineTo(x0 + dir * -inset * 0, top + inset); g.lineTo(x0 - dir * 10, top + bh + 6 - inset); g.lineTo(x1 - dir * 4, top + bh - 2 - inset); g.closePath(); };
      path(-3); g.fillStyle = 'rgba(12,10,20,0.85)'; g.fill(); g.strokeStyle = 'rgba(255,220,140,0.9)'; g.lineWidth = 2; g.stroke();
      // health is anchored at the OUTER end and drains toward the timer, as in the genre (the first contact sheet anchored it
      // at the timer, so damage ate the bar from the outside in)
      var fillBar = function (frac, col, alpha) {
        if (frac <= 0) return; var xs = x0 - dir * bw * Math.max(0, Math.min(1, frac));
        g.save(); path(1); g.clip(); g.fillStyle = col; g.globalAlpha = alpha; g.fillRect(Math.min(x0, xs), top, Math.abs(x0 - xs), bh + 6); g.restore();
      };
      fillBar(o.trail ? o.trail[side] : 0, 'rgb(255,70,50)', 0.9);
      var hp = o.hp[side], hcol = hp > 0.5 ? [250, 214, 60] : hp > 0.25 ? [250, 150, 40] : [235, 60, 40];
      var hg = g.createLinearGradient(0, top, 0, top + bh); hg.addColorStop(0, rgb(mix(hcol, [255, 255, 255], 0.45))); hg.addColorStop(0.5, rgb(hcol)); hg.addColorStop(1, rgb(mix(hcol, [0, 0, 0], 0.35)));
      fillBar(hp, hg, 1);
      // a gloss line across the bar
      g.save(); path(1); g.clip(); g.fillStyle = 'rgba(255,255,255,0.22)'; g.fillRect(Math.min(x0, x1), top + 3, bw, 4); g.restore();
      // guard bar under it, thinner, blue
      var gy = top + bh + 10, gw = bw * 0.62, gx1 = x1 + dir * 6;
      g.fillStyle = 'rgba(12,10,20,0.8)'; g.fillRect(Math.min(gx1, gx1 + dir * gw), gy, gw, 7);
      g.fillStyle = 'rgb(90,170,255)'; var gf = Math.max(0, Math.min(1, o.guard[side])); g.fillRect(dir < 0 ? gx1 - gw * gf : gx1, gy, gw * gf, 7);
      // round pips at the INNER end, beside the timer, under the guard bar (the first sheet put them under the name)
      for (var k = 0; k < (o.need || 2); k++) {
        var px = x1 + dir * (12 + k * 22), py = gy + 4;
        g.beginPath(); g.arc(px, py + 16, 7, 0, Math.PI * 2); g.fillStyle = k < o.wins[side] ? 'rgb(255,214,80)' : 'rgba(12,10,20,0.85)'; g.fill(); g.lineWidth = 2; g.strokeStyle = 'rgb(255,230,160)'; g.stroke();
      }
      // the name, in the arcade alphabet, under the bar on the outside
      if (o.names) drawText(g, String(o.names[side]).slice(0, 12), side === 0 ? x0 + 4 : x0 - 4, gy + 14, 2, { top: [255, 255, 255], bottom: [200, 210, 230] }, side === 0 ? 'left' : 'right');
      // the special meter: segments at the bottom
      var mSeg = 4, segW = 34, mY = o.h - 30, mx0 = side === 0 ? 30 : W - 30 - mSeg * (segW + 4);
      for (var s = 0; s < mSeg; s++) {
        var fillN = Math.max(0, Math.min(1, o.meter[side] * mSeg - s)), sx = mx0 + s * (segW + 4);
        g.fillStyle = 'rgba(12,10,20,0.8)'; g.fillRect(sx, mY, segW, 10);
        if (fillN > 0) { g.fillStyle = fillN >= 1 ? 'rgb(120,255,200)' : 'rgb(60,160,130)'; g.fillRect(sx, mY, segW * fillN, 10); }
      }
    }
    // the timer in a hexagon between the bars
    g.beginPath(); for (var a = 0; a < 6; a++) { var ang = Math.PI / 6 + a * Math.PI / 3; g.lineTo(cx + Math.cos(ang) * 34, top + 12 + Math.sin(ang) * 30); } g.closePath();
    g.fillStyle = 'rgba(12,10,20,0.9)'; g.fill(); g.lineWidth = 2; g.strokeStyle = 'rgb(255,220,140)'; g.stroke();
    var tStr = o.time < 0 ? '--' : String(Math.max(0, Math.ceil(o.time)));
    drawText(g, tStr, cx, top + 1, 3, { top: [255, 255, 255], bottom: [255, 210, 120] }, 'center');
  }

  //---------------------------------------------------------------------------
  // ARENAS: five stages that differ in STRUCTURE, not only colour (wing §21a): what stands behind the fighters, the
  // floor's material and its perspective, and what moves. Each draws a sky, a far layer, a near layer and a floor.
  //---------------------------------------------------------------------------
  var STAGES = {
    dojo: { name: 'Dojo at Dusk', sky: [[60, 40, 70], [230, 120, 80]], floor: [150, 100, 60] },
    courtyard: { name: 'Moonlit Courtyard', sky: [[10, 16, 40], [50, 60, 110]], floor: [90, 96, 110] },
    pier: { name: 'Harbour Pier', sky: [[90, 150, 210], [220, 200, 170]], floor: [120, 86, 60] },
    ruin: { name: 'Desert Ruin', sky: [[190, 120, 70], [250, 210, 140]], floor: [210, 170, 110] },
    shrine: { name: 'Snow Shrine', sky: [[150, 170, 200], [235, 240, 250]], floor: [225, 232, 242] },
  };
  /**
   * One arena, w x h, ground line at `gy` (screen y of the floor's front edge where fighters stand). `cam` scrolls the
   * near layers horizontally (parallax), `t` animates (frames).
   */
  function drawStage(g, key, w, h, gy, cam, t) {
    var S = STAGES[key] || STAGES.dojo; cam = cam || 0; t = t || 0;
    var sky = g.createLinearGradient(0, 0, 0, gy); sky.addColorStop(0, rgb(S.sky[0])); sky.addColorStop(1, rgb(S.sky[1])); g.fillStyle = sky; g.fillRect(0, 0, w, gy);
    var far = function (pts, col) { g.beginPath(); g.moveTo(0, gy); for (var i = 0; i < pts.length; i++) g.lineTo(pts[i][0], pts[i][1]); g.lineTo(w, gy); g.closePath(); g.fillStyle = col; g.fill(); };
    var i, x;
    if (key === 'dojo') {
      // a low sun, layered hills, then the dojo's interior: posts, a rail, hanging banners
      g.beginPath(); g.arc(w * 0.72, gy * 0.62, gy * 0.16, 0, Math.PI * 2); g.fillStyle = 'rgba(255,220,150,0.9)'; g.fill();
      far([[0, gy * 0.7], [w * 0.2, gy * 0.55], [w * 0.45, gy * 0.68], [w * 0.7, gy * 0.5], [w, gy * 0.66]], 'rgba(110,60,80,0.8)');
      far([[0, gy * 0.82], [w * 0.3, gy * 0.74], [w * 0.6, gy * 0.84], [w, gy * 0.76]], 'rgba(70,40,60,0.9)');
      for (i = -1; i < 9; i++) { x = ((i * w / 7 - cam * 0.6) % (w * 10 / 7) + w * 10 / 7) % (w * 10 / 7) - w / 7; g.fillStyle = 'rgb(70,40,28)'; g.fillRect(x, gy * 0.22, 18, gy * 0.78); g.fillStyle = 'rgba(255,190,120,0.25)'; g.fillRect(x + 2, gy * 0.22, 4, gy * 0.78); }
      g.fillStyle = 'rgb(58,32,22)'; g.fillRect(0, gy * 0.18, w, 16); g.fillRect(0, gy * 0.58, w, 8);
      for (i = 0; i < 4; i++) { x = w * (0.16 + i * 0.22) - cam * 0.6 % w; var sway = Math.sin(t * 0.03 + i) * 4; g.fillStyle = i % 2 ? 'rgb(170,40,40)' : 'rgb(230,210,170)'; g.beginPath(); g.moveTo(x, gy * 0.2); g.lineTo(x + 40, gy * 0.2); g.lineTo(x + 40 + sway, gy * 0.48); g.lineTo(x + 20 + sway, gy * 0.42); g.lineTo(x + sway, gy * 0.48); g.closePath(); g.fill(); }
    } else if (key === 'courtyard') {
      // a full moon, stars, a curtain wall with crenellations and lit windows, a stone arch either side
      for (i = 0; i < 70; i++) { g.fillStyle = 'rgba(255,255,255,' + (0.3 + hash(i, 7, 1) * 0.6) + ')'; g.fillRect(hash(i, 1, 2) * w, hash(i, 2, 3) * gy * 0.55, 2, 2); }
      g.beginPath(); g.arc(w * 0.24, gy * 0.26, gy * 0.12, 0, Math.PI * 2); g.fillStyle = 'rgb(240,240,220)'; g.fill(); g.beginPath(); g.arc(w * 0.24 + gy * 0.04, gy * 0.24, gy * 0.11, 0, Math.PI * 2); g.fillStyle = 'rgba(200,205,190,0.35)'; g.fill();
      var wallTop = gy * 0.48; g.fillStyle = 'rgb(46,52,74)'; g.fillRect(0, wallTop, w, gy - wallTop);
      for (x = -((cam * 0.5) % 40) - 40; x < w + 40; x += 40) { g.fillRect(x, wallTop - 16, 24, 16); }
      for (i = 0; i < 6; i++) { x = ((i * w / 5 - cam * 0.5) % (w * 1.2) + w * 1.2) % (w * 1.2) - w * 0.1; g.fillStyle = 'rgb(255,200,110)'; g.fillRect(x, wallTop + 30, 14, 22); g.fillStyle = 'rgba(255,200,110,0.15)'; g.fillRect(x - 8, wallTop + 22, 30, 38); }
      for (var s2 = 0; s2 < 2; s2++) { var ax = s2 ? w - 120 : 0; g.fillStyle = 'rgb(70,76,98)'; g.fillRect(ax, gy * 0.3, 120, gy * 0.7); g.beginPath(); g.fillStyle = 'rgb(28,32,48)'; g.moveTo(ax + 25, gy); g.lineTo(ax + 25, gy * 0.62); g.arc(ax + 60, gy * 0.62, 35, Math.PI, 0); g.lineTo(ax + 95, gy); g.fill(); }
    } else if (key === 'pier') {
      // the sea with a far ship, gulls, a lighthouse, mooring posts and rope along the pier's edge
      g.fillStyle = 'rgb(50,110,160)'; g.fillRect(0, gy * 0.62, w, gy * 0.38);
      for (i = 0; i < 26; i++) { var wx = (hash(i, 3, 9) * w + t * 0.4) % w, wy = gy * 0.64 + hash(i, 4, 9) * gy * 0.3; g.strokeStyle = 'rgba(255,255,255,0.35)'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(wx, wy); g.quadraticCurveTo(wx + 8, wy - 3, wx + 16, wy); g.stroke(); }
      var lx = w * 0.82; g.fillStyle = 'rgb(240,236,226)'; g.beginPath(); g.moveTo(lx - 16, gy * 0.62); g.lineTo(lx - 9, gy * 0.18); g.lineTo(lx + 9, gy * 0.18); g.lineTo(lx + 16, gy * 0.62); g.fill(); g.fillStyle = 'rgb(200,50,40)'; g.fillRect(lx - 12, gy * 0.3, 24, 10); g.fillRect(lx - 14, gy * 0.46, 28, 10); g.fillStyle = 'rgb(255,240,160)'; g.fillRect(lx - 7, gy * 0.12, 14, 10);
      g.fillStyle = 'rgba(60,60,80,0.7)'; g.beginPath(); g.moveTo(w * 0.3, gy * 0.6); g.lineTo(w * 0.42, gy * 0.6); g.lineTo(w * 0.4, gy * 0.63); g.lineTo(w * 0.32, gy * 0.63); g.fill(); g.fillRect(w * 0.355, gy * 0.48, 3, gy * 0.12);
      for (i = 0; i < 3; i++) { var gx = (w * (0.2 + i * 0.25) + t * 0.6 * (i + 1)) % w, gyy = gy * (0.2 + i * 0.07) + Math.sin(t * 0.08 + i) * 6; g.strokeStyle = 'rgb(40,40,50)'; g.lineWidth = 2; g.beginPath(); g.moveTo(gx - 8, gyy); g.quadraticCurveTo(gx - 4, gyy - 5, gx, gyy); g.quadraticCurveTo(gx + 4, gyy - 5, gx + 8, gyy); g.stroke(); }
      for (x = -((cam * 0.9) % 140) - 140; x < w + 140; x += 140) { g.fillStyle = 'rgb(80,54,36)'; g.fillRect(x, gy * 0.74, 16, gy * 0.26); g.fillStyle = 'rgb(110,78,50)'; g.fillRect(x - 2, gy * 0.72, 20, 6); g.strokeStyle = 'rgb(200,180,140)'; g.lineWidth = 3; g.beginPath(); g.moveTo(x + 16, gy * 0.8); g.quadraticCurveTo(x + 78, gy * 0.88, x + 140, gy * 0.8); g.stroke(); }
    } else if (key === 'ruin') {
      // dunes, a broken colonnade with a fallen drum, a sun haze
      g.fillStyle = 'rgba(255,240,200,0.5)'; g.beginPath(); g.arc(w * 0.5, gy * 0.35, gy * 0.3, 0, Math.PI * 2); g.fill();
      far([[0, gy * 0.72], [w * 0.25, gy * 0.6], [w * 0.55, gy * 0.74], [w * 0.8, gy * 0.62], [w, gy * 0.7]], 'rgb(220,160,100)');
      for (i = 0; i < 6; i++) { x = ((i * w / 4.5 - cam * 0.55) % (w * 1.33) + w * 1.33) % (w * 1.33) - w * 0.15; var ht = gy * (0.35 + hash(i, 5, 2) * 0.4); g.fillStyle = 'rgb(200,170,130)'; g.fillRect(x, gy - ht, 34, ht); for (var fl = 0; fl < 4; fl++) { g.fillStyle = 'rgba(120,90,60,0.35)'; g.fillRect(x + 4 + fl * 8, gy - ht, 3, ht); } g.fillStyle = 'rgb(160,130,96)'; g.beginPath(); g.moveTo(x - 4, gy - ht); g.lineTo(x + 10, gy - ht - 10); g.lineTo(x + 22, gy - ht - 4); g.lineTo(x + 38, gy - ht - 12); g.lineTo(x + 38, gy - ht); g.fill(); }
    } else {
      // the snow shrine: torii gate, snowy pines, falling snow
      far([[0, gy * 0.6], [w * 0.3, gy * 0.42], [w * 0.5, gy * 0.56], [w * 0.75, gy * 0.38], [w, gy * 0.55]], 'rgb(190,205,225)');
      for (i = 0; i < 9; i++) { x = ((i * w / 7 - cam * 0.5) % (w * 1.3) + w * 1.3) % (w * 1.3) - w * 0.15; var ph = gy * (0.28 + hash(i, 6, 4) * 0.2); g.fillStyle = 'rgb(40,80,70)'; g.beginPath(); g.moveTo(x, gy * 0.92 - ph); g.lineTo(x + 30, gy * 0.92); g.lineTo(x - 30, gy * 0.92); g.fill(); g.fillStyle = 'rgba(255,255,255,0.85)'; g.beginPath(); g.moveTo(x, gy * 0.92 - ph); g.lineTo(x + 10, gy * 0.92 - ph * 0.68); g.lineTo(x - 10, gy * 0.92 - ph * 0.68); g.fill(); }
      var tx = w * 0.5 - cam * 0.7; g.fillStyle = 'rgb(200,50,40)'; g.fillRect(tx - 120, gy * 0.3, 240, 14); g.fillRect(tx - 100, gy * 0.4, 200, 9); g.fillRect(tx - 90, gy * 0.3, 14, gy * 0.7); g.fillRect(tx + 76, gy * 0.3, 14, gy * 0.7); g.fillStyle = 'rgb(30,26,30)'; g.fillRect(tx - 130, gy * 0.27, 260, 8); g.fillStyle = 'rgba(255,255,255,0.9)'; g.fillRect(tx - 130, gy * 0.25, 260, 4);
      for (i = 0; i < 60; i++) { var sx3 = (hash(i, 9, 1) * w + Math.sin(t * 0.02 + i) * 10) % w, sy3 = (hash(i, 8, 1) * h + t * (0.6 + hash(i, 3, 3))) % gy; g.fillStyle = 'rgba(255,255,255,0.85)'; g.fillRect(sx3, sy3, 3, 3); }
    }
    // the floor: material by stage, perspective boards / flags / sand ripples converging toward a vanishing point
    var fl0 = S.floor, fg = g.createLinearGradient(0, gy, 0, h); fg.addColorStop(0, rgb(mix(fl0, [0, 0, 0], 0.15))); fg.addColorStop(1, rgb(mix(fl0, [0, 0, 0], 0.45))); g.fillStyle = fg; g.fillRect(0, gy, w, h - gy);
    var vx = w * 0.5 - cam * 0.2, lineCol = lum(fl0) > 140 ? 'rgba(0,0,0,0.16)' : 'rgba(255,255,255,0.12)';
    g.strokeStyle = lineCol; g.lineWidth = 1.5;
    if (key === 'ruin' || key === 'shrine') { for (i = 1; i < 7; i++) { var ry = gy + (h - gy) * (i / 7) * (i / 7); g.beginPath(); g.moveTo(0, ry); for (x = 0; x <= w; x += 40) g.lineTo(x, ry + Math.sin(x * 0.02 + i) * 2); g.stroke(); } }
    else { for (i = -12; i <= 12; i++) { g.beginPath(); g.moveTo(vx + i * 30, gy); g.lineTo(vx + i * 180, h); g.stroke(); } if (key === 'courtyard') for (i = 1; i < 6; i++) { var cy2 = gy + (h - gy) * (i / 6) * (i / 6); g.beginPath(); g.moveTo(0, cy2); g.lineTo(w, cy2); g.stroke(); } }
    g.fillStyle = 'rgba(0,0,0,0.25)'; g.fillRect(0, gy, w, 3);
  }

  //---------------------------------------------------------------------------
  // HIT SPARKS: a burst whose STRUCTURE is the element's form (flame tongues, ice shards, a forked bolt, a droplet ring,
  // rock chunks, curved gusts, a star of rays, a void ring with tendrils, an impact star), size by damage, age 0..1.
  //---------------------------------------------------------------------------
  function drawSpark(g, elName, x, y, size, age, seed) {
    var L = look(elName), a = 1 - age, r = size * (0.5 + age * 0.7), n, i, ang, s = seed || 1;
    g.save(); g.translate(x, y); g.globalAlpha = Math.max(0, Math.min(1, a * 1.3));
    var glow = g.createRadialGradient(0, 0, 0, 0, 0, r * 1.2); glow.addColorStop(0, rgb(L.hot, 0.55)); glow.addColorStop(1, rgb(L.hot, 0)); g.fillStyle = glow; g.beginPath(); g.arc(0, 0, r * 1.2, 0, Math.PI * 2); g.fill();
    var f = L.form;
    if (f === 'flame') { n = 7; for (i = 0; i < n; i++) { ang = i / n * Math.PI * 2 + hash(i, s, 1); var len = r * (0.8 + hash(i, s, 2) * 0.5); g.fillStyle = rgb(i % 2 ? L.hot : L.core); g.beginPath(); g.moveTo(Math.cos(ang - 0.25) * r * 0.2, Math.sin(ang - 0.25) * r * 0.2); g.quadraticCurveTo(Math.cos(ang + 0.4) * len * 0.6, Math.sin(ang + 0.4) * len * 0.6, Math.cos(ang) * len, Math.sin(ang) * len); g.quadraticCurveTo(Math.cos(ang - 0.4) * len * 0.5, Math.sin(ang - 0.4) * len * 0.5, Math.cos(ang + 0.25) * r * 0.2, Math.sin(ang + 0.25) * r * 0.2); g.fill(); } }
    else if (f === 'shard') { n = 6; for (i = 0; i < n; i++) { ang = i / n * Math.PI * 2 + hash(i, s, 3) * 0.5; var ln = r * (0.7 + hash(i, s, 4) * 0.6); g.fillStyle = rgb(L.core); g.strokeStyle = rgb(L.dark); g.lineWidth = 1.5; g.beginPath(); g.moveTo(Math.cos(ang) * ln, Math.sin(ang) * ln); g.lineTo(Math.cos(ang + 0.18) * ln * 0.3, Math.sin(ang + 0.18) * ln * 0.3); g.lineTo(Math.cos(ang - 0.18) * ln * 0.3, Math.sin(ang - 0.18) * ln * 0.3); g.closePath(); g.fill(); g.stroke(); } }
    else if (f === 'bolt') { n = 4; g.strokeStyle = rgb(L.core); g.lineWidth = 3; g.lineJoin = 'miter'; for (i = 0; i < n; i++) { ang = i / n * Math.PI * 2 + 0.4; g.beginPath(); g.moveTo(0, 0); var px = 0, py = 0; for (var k = 1; k <= 4; k++) { var d = r * k / 4, j = (hash(i, k, s) - 0.5) * r * 0.5; px = Math.cos(ang) * d - Math.sin(ang) * j; py = Math.sin(ang) * d + Math.cos(ang) * j; g.lineTo(px, py); } g.stroke(); } g.strokeStyle = rgb(L.hot); g.lineWidth = 1; g.stroke(); }
    else if (f === 'drop') { n = 9; for (i = 0; i < n; i++) { ang = i / n * Math.PI * 2; var dr = r * 0.85; g.fillStyle = rgb(L.core); g.beginPath(); g.ellipse(Math.cos(ang) * dr, Math.sin(ang) * dr, r * 0.1, r * 0.17, ang + Math.PI / 2, 0, Math.PI * 2); g.fill(); } g.strokeStyle = rgb(L.hot); g.lineWidth = 2; g.beginPath(); g.arc(0, 0, r * 0.5, 0, Math.PI * 2); g.stroke(); }
    else if (f === 'rock') {
      // chunks big enough to read as stone at fight scale, each lit on its upper face and outlined (the first sheet's
      // brown flecks on grey read as dirt)
      n = 6; for (i = 0; i < n; i++) { ang = i / n * Math.PI * 2 + hash(i, s, 5); var rr = r * (0.55 + hash(i, s, 6) * 0.45), cs = r * (0.22 + hash(i, s, 7) * 0.12), cx2 = Math.cos(ang) * rr, cy2 = Math.sin(ang) * rr;
        g.beginPath(); g.moveTo(cx2 - cs, cy2 - cs * 0.5); g.lineTo(cx2 + cs * 0.7, cy2 - cs); g.lineTo(cx2 + cs, cy2 + cs * 0.6); g.lineTo(cx2 - cs * 0.5, cy2 + cs); g.closePath();
        g.fillStyle = rgb(L.hot); g.fill(); g.lineWidth = 1.5; g.strokeStyle = rgb(L.dark); g.stroke();
        g.beginPath(); g.moveTo(cx2 - cs, cy2 - cs * 0.5); g.lineTo(cx2 + cs * 0.7, cy2 - cs); g.lineTo(cx2 + cs * 0.4, cy2 - cs * 0.35); g.lineTo(cx2 - cs * 0.55, cy2 - cs * 0.1); g.closePath(); g.fillStyle = rgb(L.core); g.fill(); } }
    else if (f === 'gust') { g.strokeStyle = rgb(L.core); g.lineCap = 'round'; for (i = 0; i < 4; i++) { g.lineWidth = 3 - i * 0.5; g.beginPath(); g.arc(0, 0, r * (0.35 + i * 0.2), i * 1.6, i * 1.6 + Math.PI * 1.1); g.stroke(); } }
    else if (f === 'star') { n = 8; g.fillStyle = rgb(L.core); g.beginPath(); for (i = 0; i < n * 2; i++) { ang = i / (n * 2) * Math.PI * 2; var sr = i % 2 ? r * 0.22 : r * (i % 4 ? 0.75 : 1.1); g.lineTo(Math.cos(ang) * sr, Math.sin(ang) * sr); } g.closePath(); g.fill(); }
    else if (f === 'void') { g.fillStyle = rgb(L.dark); g.beginPath(); g.arc(0, 0, r * 0.45, 0, Math.PI * 2); g.fill(); g.strokeStyle = rgb(L.hot); g.lineWidth = 2.5; g.stroke(); for (i = 0; i < 5; i++) { ang = i / 5 * Math.PI * 2 + hash(i, s, 8); g.beginPath(); g.moveTo(Math.cos(ang) * r * 0.45, Math.sin(ang) * r * 0.45); g.quadraticCurveTo(Math.cos(ang + 0.6) * r * 0.8, Math.sin(ang + 0.6) * r * 0.8, Math.cos(ang + 0.2) * r * 1.05, Math.sin(ang + 0.2) * r * 1.05); g.stroke(); } }
    else { n = 10; g.fillStyle = rgb(L.core); g.beginPath(); for (i = 0; i < n * 2; i++) { ang = i / (n * 2) * Math.PI * 2 + 0.2; var ir = i % 2 ? r * 0.3 : r * (0.8 + hash(i, s, 9) * 0.35); g.lineTo(Math.cos(ang) * ir, Math.sin(ang) * ir); } g.closePath(); g.fill(); g.strokeStyle = rgb(L.dark); g.lineWidth = 2; g.stroke(); }
    // a white-hot core on every spark
    g.fillStyle = 'rgba(255,255,255,0.9)'; g.beginPath(); g.arc(0, 0, r * 0.16, 0, Math.PI * 2); g.fill();
    g.restore();
  }

  //---------------------------------------------------------------------------
  // SPECIALS: each delivery shape drawn in its element's look. dir = 1 facing right, -1 left; tier 1..3 makes it bigger
  // and adds a ring; t animates.
  //---------------------------------------------------------------------------
  function drawSpecial(g, shape, elName, x, y, dir, tier, t) {
    var L = look(elName), T = tier || 1, k = 1 + (T - 1) * 0.3, i;
    g.save(); g.translate(x, y); if (dir < 0) g.scale(-1, 1);
    if (shape === 'projectile') {
      for (i = 6; i >= 1; i--) { g.fillStyle = rgb(L.hot, 0.12 * (7 - i) / 6); g.beginPath(); g.ellipse(-i * 12 * k, 0, 16 * k - i, 10 * k - i * 0.8, 0, 0, Math.PI * 2); g.fill(); }
      drawSpark(g, elName, 0, 0, 30 * k, 0.15, (t >> 2) & 7);
      if (T >= 2) { g.strokeStyle = rgb(L.core, 0.8); g.lineWidth = 2; g.beginPath(); g.ellipse(4, 0, 22 * k, 14 * k, 0, 0, Math.PI * 2); g.stroke(); }
    } else if (shape === 'ground-wave') {
      for (i = 0; i < 5; i++) { var hh = (30 + i * 8) * k * (0.8 + 0.2 * Math.sin(t * 0.3 + i)); g.fillStyle = rgb(i % 2 ? L.hot : L.core, 0.85 - i * 0.12); g.beginPath(); g.moveTo(-i * 18, 0); g.lineTo(-i * 18 + 8, -hh); g.lineTo(-i * 18 + 16, 0); g.closePath(); g.fill(); }
    } else if (shape === 'rain' || shape === 'burst') {
      if (shape === 'rain') { for (i = 0; i < 7; i++) { var rx = (i - 3) * 14, ry = -((t * 6 + i * 23) % 120); g.strokeStyle = rgb(L.core, 0.9); g.lineWidth = 3; g.beginPath(); g.moveTo(rx, ry); g.lineTo(rx - 6, ry + 26); g.stroke(); } }
      else { for (i = 0; i < 3; i++) { g.strokeStyle = rgb(L.hot, 0.8 - i * 0.2); g.lineWidth = 6 - i * 1.5; g.beginPath(); g.arc(0, 0, (20 + i * 18 + (t % 20)) * k, 0, Math.PI * 2); g.stroke(); } }
      drawSpark(g, elName, 0, 0, 34 * k, 0.1, 3);
    } else if (shape === 'rush') {
      // speed: tapered streaks of the element trailing behind (staggered, never a stack: the first cut, ovals with lines
      // across them, read as a pile of coins), and a bright crescent shock front ahead of the fighter
      for (i = 0; i < 7; i++) { var sy = (i - 3) * 13 * k, sl = (70 + hash(i, 3, 11) * 60) * k, sx = -14 - hash(i, 4, 11) * 24 - ((t * 9 + i * 17) % 20);
        var sg2 = g.createLinearGradient(sx - sl, 0, sx, 0); sg2.addColorStop(0, rgb(L.hot, 0)); sg2.addColorStop(1, rgb(i % 2 ? L.hot : L.core, 0.9));
        g.fillStyle = sg2; g.beginPath(); g.moveTo(sx - sl, sy); g.lineTo(sx, sy - 3 * k); g.lineTo(sx, sy + 3 * k); g.closePath(); g.fill(); }
      g.strokeStyle = rgb(L.core); g.lineWidth = 4 * k; g.lineCap = 'round'; g.beginPath(); g.arc(-6, 0, 42 * k, -Math.PI * 0.32, Math.PI * 0.32); g.stroke();
      g.strokeStyle = rgb(L.hot, 0.6); g.lineWidth = 9 * k; g.beginPath(); g.arc(-12, 0, 42 * k, -Math.PI * 0.28, Math.PI * 0.28); g.stroke();
    } else if (shape === 'rising') {
      g.strokeStyle = rgb(L.core); g.lineWidth = 5 * k; g.lineCap = 'round'; g.beginPath(); g.arc(-10, 20, 46 * k, -Math.PI * 0.9, -Math.PI * 0.15); g.stroke();
      g.strokeStyle = rgb(L.hot, 0.7); g.lineWidth = 12 * k; g.beginPath(); g.arc(-10, 20, 40 * k, -Math.PI * 0.85, -Math.PI * 0.25); g.stroke();
      drawSpark(g, elName, 28 * k, -18 * k, 22 * k, 0.2, 5);
    } else if (shape === 'drain-tether') {
      var len = 200; g.strokeStyle = rgb(L.hot, 0.85); g.lineWidth = 4; g.beginPath(); g.moveTo(0, 0); for (i = 0; i <= 20; i++) g.lineTo(len * i / 20, Math.sin(i * 0.9 + t * 0.4) * 10 * (1 - Math.abs(i / 10 - 1))); g.stroke();
      for (i = 0; i < 6; i++) { var bx = ((t * 4 + i * 34) % len); g.fillStyle = rgb(L.core); g.beginPath(); g.arc(len - bx, Math.sin(i + t * 0.2) * 6, 4, 0, Math.PI * 2); g.fill(); }
    }
    g.restore();
  }

  return { VERSION: '1.0.0', LOOK: LOOK, STAGES: STAGES, BLOCK: BLOCK, look: look, textWidth: textWidth, drawText: drawText, drawHud: drawHud, drawStage: drawStage, drawSpark: drawSpark, drawSpecial: drawSpecial, hash: hash };
}());
if (typeof module !== 'undefined' && module.exports) module.exports = BoutDraw;
