/*:
 * @target MZ
 * @plugindesc [v1.0.0] Bout 3/3 - a real-time one-on-one fight between two of your actors, their own side-view battlers fighting side-on.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * Install BoutCore.js, BoutDraw.js and Bout.js (this file) and turn all three ON. Any order works: this file finds the
 * other two when a duel starts.
 *
 * START A DUEL from an event with the Plugin Command "Start Duel", or a script call:
 *   Bout.start({ fighter: 1, opponent: 2, ai: 'normal', rounds: 3, stage: 'dojo' })
 *
 * The fighters are your actors' SIDE-VIEW BATTLER sheets (img/sv_actors), so every actor in your database can fight with
 * no new art. Each fighter's SPECIALS come from that actor's own damaging skills: the element and the way the skill
 * reaches its target decide what the special is (a projectile, a rush, a rising strike, a wave along the ground, a rain,
 * a burst, a draining tether). Up to three per fighter.
 *
 * CONTROLS (keyboard / gamepad)
 *   Left / Right walk, Up jumps, Down crouches.
 *   OK (Z, Enter / A) light attack.  Down + OK: a LOW attack (guard it crouching).
 *   Cancel (X, Esc / B) heavy attack.  OK + Cancel together: a THROW (beats any guard, loses to any attack).
 *   Shift (X button) guard: standing stops high and mid attacks, Shift + Down stops lows and mids.
 *   Page Up / Page Down (Q, W / LB, RB) the special: alone the first, with Forward the second, with Back the third.
 *   A special costs half of the green meter, which fills over time and when you land or take hits.
 *
 * RESULTS are written before the event continues: the winner into a variable (1 = the fighter, 2 = the opponent,
 * 0 = a draw), a switch ON when the fighter won, an optional common event. Script call: Bout.lastResult().
 *
 * @param varWinner
 * @text Winner -> variable
 * @desc 1 = your fighter won, 2 = the opponent won, 0 = a draw.
 * @type variable
 * @default 0
 *
 * @param swWin
 * @text Fighter won -> switch
 * @type switch
 * @default 0
 *
 * @param commonEvent
 * @text Common event afterwards
 * @type common_event
 * @default 0
 *
 * @param roundSeconds
 * @text Round timer (seconds)
 * @type number
 * @min 20
 * @max 99
 * @default 99
 *
 * @command start
 * @text Start Duel
 * @desc Two actors fight one-on-one, best of N rounds.
 *
 * @arg fighter
 * @text Fighter (you)
 * @desc None = the party leader.
 * @type actor
 * @default 0
 *
 * @arg opponent
 * @text Opponent
 * @type actor
 * @default 0
 *
 * @arg ai
 * @text Opponent strength
 * @type select
 * @option Beginner
 * @value beginner
 * @option Easy
 * @value easy
 * @option Normal
 * @value normal
 * @option Hard
 * @value hard
 * @default normal
 *
 * @arg rounds
 * @text Rounds (best of)
 * @type select
 * @option 1
 * @value 1
 * @option 3
 * @value 3
 * @option 5
 * @value 5
 * @default 3
 *
 * @arg stage
 * @text Arena
 * @type select
 * @option Dojo at Dusk
 * @value dojo
 * @option Moonlit Courtyard
 * @value courtyard
 * @option Harbour Pier
 * @value pier
 * @option Desert Ruin
 * @value ruin
 * @option Snow Shrine
 * @value shrine
 * @default dojo
 *
 * @arg demo
 * @text Demo (both fighters play themselves)
 * @type boolean
 * @default false
 */

var Bout = Bout || {};

(function () {
  'use strict';
  var NAME = 'Bout', RAW = PluginManager.parameters(NAME);
  /** Parameters arrive as strings; blank means absent, never zero (wing §16). */
  function num(v, d) { var s = String(v === undefined || v === null ? '' : v).trim(); if (s === '') return d; var n = Number(s); return isFinite(n) ? n : d; }
  var P = { varWinner: num(RAW.varWinner, 0), swWin: num(RAW.swWin, 0), commonEvent: num(RAW.commonEvent, 0), roundSeconds: Math.max(20, Math.min(99, num(RAW.roundSeconds, 99))) };
  function deps() {
    var C = window.BoutCore, D = window.BoutDraw;
    if (!C || !D) throw new Error('Bout needs BoutCore.js and BoutDraw.js installed and ON.');
    return { C: C, D: D };
  }
  function rec() { if (!$gameSystem._csafBout) $gameSystem._csafBout = { v: 1, played: 0, won: 0, last: null }; return $gameSystem._csafBout; }

  /**
   * Up to three specials from an actor's own skills (BoutCore.specialFrom: element x delivery shape x tier): the skills
   * it KNOWS first, then the ones its CLASS will learn (in level order), then its attack skill, so every fighter has at least
   * one. MEASURED on the stock database (_probe/stock_actor_skills.js): actors 1-4 know no damaging skill at level 1, so
   * reading known skills alone gave a day-one duel no specials at all.
   */
  function specialsOf(actor) {
    var C = deps().C, out = [], seen = {}, ids = [], i;
    if (!actor) return out;
    var known = actor.skills(); for (i = 0; i < known.length; i++) ids.push(known[i].id);
    var cls = actor.currentClass(), learn = cls && cls.learnings ? cls.learnings.slice().sort(function (a, b) { return a.level - b.level; }) : [];
    for (i = 0; i < learn.length; i++) ids.push(learn[i].skillId);
    ids.push(actor.attackSkillId());
    for (i = 0; i < ids.length && out.length < 3; i++) {
      var sp = C.specialFrom($dataSkills[ids[i]], $dataSystem.elements);
      if (!sp) continue; var key = sp.shape + '|' + sp.element; if (seen[key]) continue; seen[key] = true; out.push(sp);
    }
    return out;
  }

  var pending = null;
  /**
   * Start a duel. args: fighter (actor id, 0 = leader), opponent (actor id), ai ('easy' | 'normal' | 'hard'), rounds (1, 3,
   * 5), stage (an arena key), demo (both fighters played by the AI), seed (optional).
   */
  function start(args) {
    args = args || {};
    var D = deps().D, f = num(args.fighter, 0), o = num(args.opponent, 0);
    var fa = f > 0 ? $gameActors.actor(f) : $gameParty.leader(), oa = o > 0 ? $gameActors.actor(o) : ($gameParty.members()[1] || fa);
    var ai = /^(beginner|easy|normal|hard)$/.test(String(args.ai)) ? String(args.ai) : 'normal';
    var rounds = [1, 3, 5].indexOf(num(args.rounds, 3)) >= 0 ? num(args.rounds, 3) : 3;
    var stage = D.STAGES[String(args.stage || '')] ? String(args.stage) : 'dojo';
    pending = { fighter: fa, opponent: oa, ai: ai, rounds: rounds, stage: stage, demo: args.demo === true || String(args.demo) === 'true', seed: num(args.seed, (Graphics.frameCount * 7919 + rec().played) | 0) };
    SceneManager.push(Scene_Bout);
    return true;
  }
  PluginManager.registerCommand(NAME, 'start', function (a) { start(a); });

  /** A 9 x 6 sheet of 64 px cells holding a plain fighter silhouette, for an actor whose battler image is blank. */
  function standIn(i) {
    var b = new Bitmap(576, 384), g = b.context, col = i ? '#5a1e2a' : '#1e2a46';
    for (var r = 0; r < 6; r++) for (var c = 0; c < 9; c++) {
      var x = c * 64 + 34, y = r * 64 + 62, lean = ((c + r) % 3 - 1) * 2;
      g.fillStyle = col; g.beginPath(); g.ellipse(x + lean, y - 50, 7, 8, 0, 0, Math.PI * 2); g.fill();
      g.fillRect(x - 8 + lean, y - 42, 16, 24); g.fillRect(x - 8, y - 18, 6, 18); g.fillRect(x + 2, y - 18, 6, 18); g.fillRect(x - 20, y - 38, 12, 5);
    }
    b._baseTexture.update();
    return b;
  }

  //---------------------------------------------------------------------------
  // Scene_Bout
  //---------------------------------------------------------------------------
  function Scene_Bout() { this.initialize.apply(this, arguments); }
  Scene_Bout.prototype = Object.create(Scene_Base.prototype);
  Scene_Bout.prototype.constructor = Scene_Bout;

  var LOOP_PAT = [0, 1, 2, 1];   // a looping SV motion cycles 0,1,2,1 (rmmz_sprites.js:854 motionSpeed 12)
  var GROUND = 0.78, ZOOM = 2, SPARK_FRAMES = 6, MOTION = { walk: 0, wait: 1, chant: 2, guard: 3, damage: 4, evade: 5, thrust: 6, swing: 7, missile: 8, skill: 9, spell: 10, victory: 13, dying: 14, dead: 17 };

  Scene_Bout.prototype.initialize = function () {
    Scene_Base.prototype.initialize.call(this);
    this._req = pending; pending = null; this._built = false; this._done = false; this._doneAge = 0;
    this._sheets = this._req ? [ImageManager.loadSvActor(this._req.fighter.battlerName()), ImageManager.loadSvActor(this._req.opponent.battlerName())] : [];
  };
  Scene_Bout.prototype.isReady = function () { return Scene_Base.prototype.isReady.call(this) && this._sheets.every(function (b) { return b.isReady(); }); };
  Scene_Bout.prototype.start = function () { Scene_Base.prototype.start.call(this); if (!this._req) { this.popScene(); return; } this.build(); };

  /** Everything per-frame is allocated here: the arena, the fighters, the shadows, the spark and special atlases, the HUD. */
  Scene_Bout.prototype.build = function () {
    var d = deps(), C = d.C, D = d.D, W = Graphics.width, H = Graphics.height, q = this._req;
    this._C = C; this._D = D; this._gy = Math.round(H * GROUND);
    var g = this._g = C.createMatch({ seed: q.seed, rounds: q.rounds, roundFrames: P.roundSeconds * 60, ai: [q.demo ? q.ai : null, q.ai] });
    g.f[0].specials = specialsOf(q.fighter); g.f[1].specials = specialsOf(q.opponent);
    // the arena: drawn ONCE, a bitmap wider than the screen so the camera can pan over a 1,000 px stage
    this._stageW = Math.max(W, C.STAGE_W);
    var sb = new Bitmap(this._stageW, H); D.drawStage(sb.context, q.stage, this._stageW, H, this._gy, 0, 0); sb._baseTexture.update();
    this._stage = new Sprite(sb); this.addChild(this._stage);
    // shadows, then fighters (SV sheets drawn 2x, nearest)
    this._shadows = []; this._fighters = [];
    for (var i = 0; i < 2; i++) {
      var sh = new Bitmap(96, 20); sh.context.fillStyle = 'rgba(0,0,0,0.35)'; sh.context.beginPath(); sh.context.ellipse(48, 10, 44, 8, 0, 0, Math.PI * 2); sh.context.fill(); sh._baseTexture.update();
      var s = new Sprite(sh); s.anchor.x = 0.5; s.anchor.y = 0.5; this.addChild(s); this._shadows.push(s);
      // an actor with no side-view battler gets a drawn stand-in figure in every cell, never an invisible fighter. A blank name
      // loads ImageManager._emptyBitmap, which is 1 x 1 (rmmz_managers.js:861, 968), not 0 wide: test the NAME and the size
      var actor = i ? q.opponent : q.fighter;
      if (!actor.battlerName() || this._sheets[i].width < 9 || this._sheets[i].height < 6) this._sheets[i] = standIn(i);
      this._sheets[i].smooth = false;
      var fs = new Sprite(this._sheets[i]); fs.anchor.x = 0.5; fs.anchor.y = 1; fs.scale.y = ZOOM; this.addChild(fs); this._fighters.push(fs);
      fs._cw = this._sheets[i].width / 9; fs._ch = this._sheets[i].height / 6; fs._key = -1;
    }
    // shots and sparks: pre-rendered atlases, shown with setFrame (a canvas redrawn every frame re-uploads every frame)
    this._shotSp = []; this._shotKey = [];
    for (var k = 0; k < 2; k++) {
      var specs = g.f[k].specials, ab = new Bitmap(240 * Math.max(1, specs.length), 160 * 4), ag = ab.context;
      for (var si = 0; si < specs.length; si++) for (var fr = 0; fr < 4; fr++) { ag.save(); ag.beginPath(); ag.rect(si * 240, fr * 160, 240, 160); ag.clip(); D.drawSpecial(ag, specs[si].shape, specs[si].element, si * 240 + 150, fr * 160 + 80, 1, specs[si].tier, fr * 3); ag.restore(); }
      ab._baseTexture.update();
      var ss = new Sprite(ab); ss.anchor.x = 150 / 240; ss.anchor.y = 0.5; ss.visible = false; ss.setFrame(0, 0, 240, 160); this.addChild(ss); this._shotSp.push(ss); this._shotKey.push(-1);
    }
    var els = ['Physical'], ei;
    for (k = 0; k < 2; k++) for (ei = 0; ei < g.f[k].specials.length; ei++) if (els.indexOf(g.f[k].specials[ei].element) < 0) els.push(g.f[k].specials[ei].element);
    this._sparkEls = els;
    var kb = new Bitmap(120 * SPARK_FRAMES, 120 * els.length), kg = kb.context;
    for (ei = 0; ei < els.length; ei++) for (fr = 0; fr < SPARK_FRAMES; fr++) D.drawSpark(kg, els[ei], fr * 120 + 60, ei * 120 + 60, 34, fr / SPARK_FRAMES, ei + 1);
    kb._baseTexture.update();
    this._sparks = []; for (k = 0; k < 6; k++) { var sp = new Sprite(kb); sp.anchor.x = 0.5; sp.anchor.y = 0.5; sp.visible = false; sp.setFrame(0, 0, 120, 120); sp._age = -1; sp._row = 0; this.addChild(sp); this._sparks.push(sp); }
    this._sparkNext = 0; this._hp0 = [g.f[0].hp, g.f[1].hp]; this._trail = [1, 1];
    // HUD and banner: repainted only when what they show changes
    this._hud = new Sprite(new Bitmap(W, H)); this.addChild(this._hud); this._hudKey = -1;
    this._banner = new Sprite(new Bitmap(W, 200)); this._banner.y = Math.round(H * 0.24); this.addChild(this._banner); this._bannerKey = -1;
    this._cam = (this._stageW - W) / 2; this._built = true;
    this.place(); this.drawHud(); this.drawBanner();
  };

  /** The fighter's sheet cell for its state: MZ's SV motions (rmmz_sprites.js:653) mapped onto fight states. */
  Scene_Bout.prototype.motionOf = function (F) {
    var C = this._C, S = C.S, M = MOTION, mv = F.move, m;
    if (F.state === S.KO) return M.dead;
    if (F.state === S.WIN) return M.victory;
    if (F.state === S.HITSTUN) return M.damage;
    if (F.state === S.BLOCKSTUN || F.state === S.GUARD) return M.guard;
    if (F.state === S.JUMP) return M.evade;
    if (F.state === S.WALK) return M.walk;
    if (F.state === S.CROUCH) return M.guard;
    if (F.state === S.ATTACK) {
      if (mv === 'special') { var sp = F.specials[F.spec]; m = sp ? sp.shape : ''; return m === 'projectile' ? M.missile : m === 'rush' ? M.thrust : m === 'rising' ? M.swing : m === 'ground-wave' ? M.skill : M.spell; }
      return mv === 'heavy' || mv === 'air' ? M.swing : M.thrust;
    }
    return M.wait;
  };

  /** One frame. Allocates nothing: every object was made in build(). */
  Scene_Bout.prototype.update = function () {
    Scene_Base.prototype.update.call(this);
    if (!this._built) return;
    var C = this._C, g = this._g, I = C.INPUT;
    if (this._done) { this._doneAge++; if (this._doneAge > 60 && (Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered())) this.popScene(); this.drawBanner(); return; }
    var inp = 0;
    if (!this._req.demo) {
      if (Input.isPressed('left')) inp |= I.LEFT; if (Input.isPressed('right')) inp |= I.RIGHT; if (Input.isPressed('up')) inp |= I.UP; if (Input.isPressed('down')) inp |= I.DOWN;
      if (Input.isTriggered('ok')) inp |= I.LIGHT; if (Input.isTriggered('cancel')) inp |= I.HEAVY; if (Input.isPressed('shift')) inp |= I.GUARD;
      if (Input.isTriggered('pageup') || Input.isTriggered('pagedown')) inp |= I.SPECIAL;
    }
    var h0 = g.f[0].hp, h1 = g.f[1].hp;
    this._shotWas0 = g.shots[0].live; this._shotWas1 = g.shots[1].live;
    C.step(g, inp, 0);
    if (g.f[1].hp < h1) this.spark(1, h1 - g.f[1].hp, g.f[0]);
    if (g.f[0].hp < h0) this.spark(0, h0 - g.f[0].hp, g.f[1]);
    if (g.events & 1 && g.f[0].hp === h0 && g.f[1].hp === h1) this.spark(g.f[0].state === C.S.BLOCKSTUN ? 0 : 1, 0, null);
    for (var i = 0; i < 2; i++) { var fr = g.f[i].hp / C.MAX_HP; if (this._trail[i] > fr) this._trail[i] = Math.max(fr, this._trail[i] - 0.004); }
    this.place(); this.drawHud(); this.drawBanner();
    if (g.phase === 'matchEnd' && !this._done) this.finish();
  };

  /** A hit spark on fighter i (the one hit), in the element of what hit it. */
  Scene_Bout.prototype.spark = function (i, dmg, by) {
    var g = this._g, F = g.f[i], sp = this._sparks[this._sparkNext], row = 0;
    this._sparkNext = (this._sparkNext + 1) % this._sparks.length;
    // the element of what hit: a special in progress, or a shot that was flying at the start of this frame and is gone now
    var shotWas = i === 1 ? this._shotWas0 : this._shotWas1, S = g.shots[1 - i];
    if (by && by.move === 'special' && by.specials[by.spec]) row = Math.max(0, this._sparkEls.indexOf(by.specials[by.spec].element));
    else if (by && shotWas && !S.live && S.spec) row = Math.max(0, this._sparkEls.indexOf(S.spec.element));
    sp._row = row; sp._age = 0; sp.visible = true; sp.x = F.x - this._cam - F.face * 18; sp.y = this._gy - F.y - 70; sp.scale.x = sp.scale.y = dmg > 60 ? 1.4 : dmg > 0 ? 1 : 0.7;
  };

  /** Camera, fighters, shadows, shots and sparks to their places for this frame. */
  Scene_Bout.prototype.place = function () {
    var C = this._C, g = this._g, W = Graphics.width, gy = this._gy, i;
    var mid = (g.f[0].x + g.f[1].x) / 2, cam = Math.max(0, Math.min(this._stageW - W, mid - W / 2));
    this._cam += (cam - this._cam) * 0.15; this._stage.x = -Math.round(this._cam);
    for (i = 0; i < 2; i++) {
      var F = g.f[i], fs = this._fighters[i], m = this.motionOf(F), loop = m === MOTION.walk || m === MOTION.wait || m === MOTION.guard || m === MOTION.victory;
      var pat = loop ? LOOP_PAT[(g.frame / 12 | 0) & 3] : (F.state === C.S.ATTACK ? Math.min(2, F.mf / 4 | 0) : m === MOTION.dead ? 2 : 1);
      var key = m * 4 + pat;
      if (key !== fs._key) { fs._key = key; fs.setFrame(((m / 6 | 0) * 3 + pat) * fs._cw, (m % 6) * fs._ch, fs._cw, fs._ch); }
      // SV sheets face LEFT, so a fighter facing right is mirrored; a crouch is the guard pose pressed down
      fs.scale.x = F.face > 0 ? -ZOOM : ZOOM; fs.scale.y = F.state === C.S.CROUCH || (F.state === C.S.ATTACK && F.move === 'low') ? ZOOM * 0.8 : ZOOM;
      fs.x = Math.round(F.x - this._cam); fs.y = Math.round(gy - F.y);
      fs.opacity = F.state === C.S.HITSTUN && (g.frame & 2) ? 200 : 255;
      var sh = this._shadows[i]; sh.x = fs.x; sh.y = gy + 4; sh.scale.x = sh.scale.y = Math.max(0.5, 1 - F.y / 300);
      var S = g.shots[i], ss = this._shotSp[i];
      if (S.live && S.spec) {
        var si = g.f[i].specials.indexOf(S.spec), frm = (g.frame >> 2) & 3, k2 = si * 4 + frm;
        if (k2 !== this._shotKey[i]) { this._shotKey[i] = k2; ss.setFrame(si * 240, frm * 160, 240, 160); }
        ss.visible = true; ss.x = Math.round(S.x - this._cam); ss.y = Math.round(gy - 60 - S.y * 0.5); ss.scale.x = S.vx < 0 ? -1 : 1;
      } else ss.visible = false;
    }
    for (i = 0; i < this._sparks.length; i++) {
      var sp = this._sparks[i]; if (!sp.visible) continue;
      var age = sp._age++, f = age >> 1; if (f >= SPARK_FRAMES) { sp.visible = false; continue; }
      sp.setFrame(f * 120, sp._row * 120, 120, 120);
    }
  };

  /** The HUD, repainted only when a value it shows changes (health and trail in 1/300 steps, seconds, meter quarters). */
  Scene_Bout.prototype.drawHud = function () {
    var C = this._C, g = this._g, f0 = g.f[0], f1 = g.f[1];
    // the trail in 4% steps: in 1% steps a draining trail repainted the whole HUD every 2-3 frames
    var key = f0.hp * 1e9 + f1.hp * 1e6 + Math.round(this._trail[0] * 25) * 1e4 + Math.round(this._trail[1] * 25) * 100 + Math.ceil(g.time / 60) + 0.5 * ((f0.meter / 12.5 | 0) + 9 * (f1.meter / 12.5 | 0) + 81 * (f0.guard / 20 | 0) + 729 * (f1.guard / 20 | 0) + 6561 * (g.wins[0] + 3 * g.wins[1]));
    if (key === this._hudKey) return; this._hudKey = key;
    var b = this._hud.bitmap; b.clear();
    var o = this._hudO || (this._hudO = { w: Graphics.width, h: Graphics.height, hp: [0, 0], trail: [0, 0], guard: [0, 0], meter: [0, 0], wins: [0, 0], need: 2, names: ['', ''], time: 99 });
    o.hp[0] = f0.hp / C.MAX_HP; o.hp[1] = f1.hp / C.MAX_HP; o.trail[0] = this._trail[0]; o.trail[1] = this._trail[1]; o.guard[0] = f0.guard / 100; o.guard[1] = f1.guard / 100;
    o.meter[0] = f0.meter / C.METER_MAX; o.meter[1] = f1.meter / C.METER_MAX; o.wins[0] = g.wins[0]; o.wins[1] = g.wins[1]; o.need = Math.floor(g.rounds / 2) + 1;
    o.names[0] = this._req.fighter.name(); o.names[1] = this._req.opponent.name(); o.time = g.time / 60;
    this._D.drawHud(b.context, o); b._baseTexture.update();
  };

  /** ROUND n, FIGHT!, K.O., TIME, PERFECT, DOUBLE K.O., the winner: painted on a phase change only. */
  Scene_Bout.prototype.drawBanner = function () {
    var g = this._g, key, txt = '';
    if (this._done) key = 900; else if (g.phase === 'intro') key = g.introT > 40 ? 100 + g.round : 200; else if (g.phase === 'roundEnd') key = 300 + g.round; else key = 0;
    if (key === this._bannerKey) return; this._bannerKey = key;
    var b = this._banner.bitmap, W = b.width; b.clear();
    if (key > 100 && key < 200) txt = 'ROUND ' + g.round; else if (key === 200) txt = 'FIGHT!';
    else if (key > 300 && key < 400) { var f = g.f, perfect = g.ko >= 0 && f[g.ko].hp === this._C.MAX_HP; txt = g.ko < 0 ? (g.timeOver ? 'TIME' : 'DOUBLE K.O.') : g.timeOver ? 'TIME' : perfect ? 'PERFECT' : 'K.O.'; }
    else if (key === 900) { var r = rec().last; txt = r.winner === 1 ? (this._req.fighter.name() + ' WINS') : r.winner === 2 ? (this._req.opponent.name() + ' WINS') : 'DRAW'; }
    if (txt) { var u = Math.min(9, Math.floor((W - 40) / (txt.length * 6))); this._D.drawText(b.context, txt.toUpperCase(), W / 2, 40, u, null, 'center'); }
    b._baseTexture.update();
  };

  /** The match is over: results into the game, then the result banner until OK. */
  Scene_Bout.prototype.finish = function () {
    var g = this._g, r = rec(), q = this._req, winner = g.winner === 0 ? 1 : g.winner === 1 ? 2 : 0;
    this._done = true; this._doneAge = 0; r.played++; if (winner === 1 && !q.demo) r.won++;
    r.last = { winner: winner, rounds: g.round, wins: [g.wins[0], g.wins[1]], fighter: q.fighter.actorId(), opponent: q.opponent.actorId(), ai: q.ai, stage: q.stage, demo: q.demo };
    if (!q.demo) {
      if (P.varWinner > 0) $gameVariables.setValue(P.varWinner, winner);
      if (P.swWin > 0) $gameSwitches.setValue(P.swWin, winner === 1);
      if (P.commonEvent > 0) $gameTemp.reserveCommonEvent(P.commonEvent);
    }
    this.drawBanner();
  };

  Bout.VERSION = '1.0.0'; Bout.P = P; Bout.start = start; Bout.specialsOf = specialsOf; Bout.Scene_Bout = Scene_Bout;
  Bout.lastResult = function () { return $gameSystem && $gameSystem._csafBout ? $gameSystem._csafBout.last : null; };
  window.Bout = Bout; window.Scene_Bout = Scene_Bout;
})();
