//=============================================================================
// SpellwrightCore.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Spellwright rules engine: aspects, combination, cost, names and seals. Pair with Spellwright.js.
 * @author CSAF - Core Systems Asset Factory
 * @url https://csaf.itch.io/spellwright
 *
 * @help
 * ============================================================================
 * SpellwrightCore - the rules, with no drawing of windows and no engine calls
 * ============================================================================
 *
 * This file holds everything Spellwright decides: which effects a known spell
 * offers as ASPECTS, which aspects may share a circle, what the new spell
 * costs, what it is called, what it does as a database skill, and the shape
 * of its seal. It never touches $gameParty, a scene or a window, so the whole
 * of it can be tested outside RPG Maker.
 *
 * Install it together with Spellwright.js. The order between the two does not
 * matter: Spellwright.js looks this file up the first time it is used.
 *
 * All of its settings are parameters of Spellwright.js.
 *
 * ============================================================================
 * Terms of use
 * ============================================================================
 * Use in commercial and non-commercial RPG Maker MZ projects. Credit CSAF.
 * Do not redistribute or resell the plugin itself.
 */

'use strict';

var SpellwrightCore = (function () {
  //===========================================================================
  // Deterministic randomness (never Math.random: the same composition must
  // give the same seal on every machine and in every save).
  //===========================================================================

  /**
   * FNV-1a over a string.
   * @param {string} str Input.
   * @param {number} [seed] Basis.
   * @returns {number} Unsigned 32-bit hash.
   */
  function hash32(str, seed) {
    let h = (seed === undefined ? 0x811c9dc5 : seed) >>> 0;
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 0x01000193) >>> 0;
    }
    return h >>> 0;
  }

  /** mulberry32: small, fast, deterministic. */
  class Rng {
    /** @param {number} seed 32-bit seed. */
    constructor(seed) {
      this._s = seed >>> 0;
    }
    /** @returns {number} Float in [0, 1). */
    next() {
      this._s = (this._s + 0x6d2b79f5) >>> 0;
      let t = this._s;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    }
  }

  //===========================================================================
  // Configuration (every value here is a Spellwright.js parameter)
  //===========================================================================

  const CONFIG = {
    cap: 4, // most aspects one circle holds
    magnitudes: [0.6, 0.8, 1.0, 1.25, 1.5], // the five dial positions
    defaultMagnitude: 2, // index into magnitudes
    costExponent: 1.25, // cost grows faster than power
    comboTax: 0.15, // each aspect past the first adds this share of the sum
    reachFactor: 1.5, // widening a single-target effect to all of them
    minCost: 5, // no crafted spell costs less MP than this
    tpToMp: 1, // a TP-cost source counts this many MP per TP
    costFormula: '', // optional override; see Spellwright.js help
    skillType: 1, // the skill type a crafted spell belongs to
    idBase: 3000, // crafted spells live at idBase + 1, idBase + 2, ...
    aspectTypes: [1], // skill types whose spells offer aspects
    deathStateId: 1,
    elementRoots: {
      physical: 'Iron', fire: 'Ember', ice: 'Rime', thunder: 'Storm', lightning: 'Storm', water: 'Tide', earth: 'Stone',
      wind: 'Gale', light: 'Dawn', holy: 'Dawn', darkness: 'Umbral', dark: 'Umbral', none: 'Arcane'
    },
    stateWords: {
      poison: 'Venomed', blind: 'Blinding', silence: 'Hushing', rage: 'Maddening', confusion: 'Bewildering',
      fascination: 'Beguiling', sleep: 'Drowsing', paralysis: 'Binding', stun: 'Stunning'
    },
    blessWords: ['Valiant', 'Valiant', 'Valiant', 'Bulwark', 'Sage’s', 'Warded', 'Swift', 'Fortunate'],
    curseWords: ['Enfeebling', 'Enfeebling', 'Enfeebling', 'Sundering', 'Dulling', 'Unwarding', 'Slowing', 'Ill-starred'],
    intensityWords: ['Faint', 'Lesser', '', 'Greater', 'Grand'],
    // per kind: [one target, all targets, second reading one, second reading all]
    formWords: {
      harm: ['Bolt', 'Tempest', 'Lance', 'Storm'], sap: ['Hush', 'Pall', 'Quiet', 'Stillness'],
      drain: ['Leech', 'Famine', 'Thirst', 'Hunger'], siphon: ['Siphon', 'Drought', 'Draught', 'Dearth'],
      mend: ['Balm', 'Benison', 'Salve', 'Grace'], renew: ['Spring', 'Wellspring', 'Font', 'Fountain'],
      hexOnly: ['Hex', 'Malison', 'Bane', 'Blight'], wardOnly: ['Ward', 'Aegis', 'Shield', 'Bulwark']
    },
    blessNouns: ['Vigor', 'Vigor', 'Might', 'Bastion', 'Insight', 'Warding', 'Haste', 'Fortune'],
    curseNouns: ['Ruin', 'Ruin', 'Frailty', 'Breach', 'Dullness', 'Exposure', 'Sloth', 'Misfortune'],
    cleanseWord: 'Purifying',
    cleanseNoun: 'Purity',
    palettes: null // filled below
  };

  /** Element palettes: ink (the line), glow (the bloom), accent (nodes). */
  const PALETTES = Object.freeze([
    { elementId: 0, ink: '#e4e8ff', glow: '#6b5cff', accent: '#ffffff' },
    { elementId: 1, ink: '#f4e0c8', glow: '#b9772e', accent: '#fff3e0' },
    { elementId: 2, ink: '#ffd6a6', glow: '#ff5418', accent: '#fff0c4' },
    { elementId: 3, ink: '#dcf6ff', glow: '#2ca6ff', accent: '#ffffff' },
    { elementId: 4, ink: '#fff4b4', glow: '#ae4bff', accent: '#ffffff' },
    { elementId: 5, ink: '#c9f1ff', glow: '#1f72ff', accent: '#e9ffff' },
    { elementId: 6, ink: '#f6e3b6', glow: '#94701e', accent: '#fff7da' },
    { elementId: 7, ink: '#dbffe6', glow: '#22c98c', accent: '#f2fff8' },
    { elementId: 8, ink: '#fff7d4', glow: '#ffbf2a', accent: '#ffffff' },
    { elementId: 9, ink: '#e6d4ff', glow: '#7d2fd8', accent: '#f6ecff' }
  ]);
  CONFIG.palettes = PALETTES.slice();

  //===========================================================================
  // Aspects: what a known spell offers
  //===========================================================================

  /** Aspect kinds. A FORM decides what the spell does to HP or MP; a RIDER rides along. */
  const KIND = {
    HARM: 'harm', SAP: 'sap', MEND: 'mend', RENEW: 'renew', DRAIN: 'drain', SIPHON: 'siphon',
    INFLICT: 'inflict', CLEANSE: 'cleanse', BLESS: 'bless', CURSE: 'curse'
  };
  const FORMS = { harm: 1, sap: 2, mend: 3, renew: 4, drain: 5, siphon: 6 };
  const FORM_OF_TYPE = [null, KIND.HARM, KIND.SAP, KIND.MEND, KIND.RENEW, KIND.DRAIN, KIND.SIPHON];
  const KIND_ORDER = ['harm', 'sap', 'drain', 'siphon', 'mend', 'renew', 'inflict', 'curse', 'cleanse', 'bless'];

  /**
   * Which side a scope aims at, and how wide it is. Width decides the crafted
   * spell's reach: the widest source wins.
   * @param {number} scope MZ scope id.
   * @returns {{side:string|null, width:number}} side 'foe' | 'ally' | null.
   */
  function scopeInfo(scope) {
    const s = Number(scope) || 0;
    if (s === 1) return { side: 'foe', width: 2 };
    if (s === 2) return { side: 'foe', width: 3 };
    if (s >= 3 && s <= 6) return { side: 'foe', width: 1 };
    if (s === 7 || s === 12) return { side: 'ally', width: 2 };
    if (s === 11) return { side: 'ally', width: 1 };
    if (s === 8 || s === 13) return { side: 'ally', width: 3 };
    return { side: null, width: 0 }; // 0 none, 9/10 dead allies, 14 everyone: not offered
  }

  /**
   * A skill's MP-equivalent cost.
   * @param {object} skill Skill-shaped object.
   * @param {object} [cfg] Configuration.
   * @returns {number} Cost.
   */
  function sourceCost(skill, cfg) {
    const c = cfg || CONFIG;
    return Number(skill.mpCost || 0) + Number(skill.tpCost || 0) * Number(c.tpToMp);
  }

  /**
   * Does this skill offer aspects at all? Crafted spells never do (no
   * compounding), the type filter applies, and two notetags override it.
   * @param {object} skill Skill.
   * @param {object} [cfg] Configuration.
   * @returns {boolean} Offers aspects.
   */
  function offersAspects(skill, cfg) {
    const c = cfg || CONFIG;
    if (!skill || !skill.name) return false;
    if (skill._csafCrafted) return false;
    const note = String(skill.note || '');
    if (/<spellwright\s+no\s+aspects?>/i.test(note)) return false;
    if (/<spellwright\s+aspects?>/i.test(note)) return true;
    return c.aspectTypes.indexOf(Number(skill.stypeId)) >= 0;
  }

  /**
   * Read one skill into the aspects it offers. Each aspect remembers its
   * source, because the cost of a crafted spell is paid per SOURCE spell.
   * @param {object} skill Skill-shaped object.
   * @param {object} [cfg] Configuration.
   * @returns {object[]} Aspects (possibly empty).
   */
  function readAspects(skill, cfg) {
    const c = cfg || CONFIG;
    if (!offersAspects(skill, c)) return [];
    const info = scopeInfo(skill.scope);
    if (!info.side) return [];
    const out = [];
    const base = {
      sourceId: Number(skill.id), sourceName: String(skill.name), side: info.side, width: info.width,
      scope: Number(skill.scope), cost: sourceCost(skill, c), hitType: Number(skill.hitType || 0),
      animationId: Number(skill.animationId || 0), iconIndex: Number(skill.iconIndex || 0), occasion: Number(skill.occasion || 0)
    };
    const dmg = skill.damage || {};
    const type = Number(dmg.type || 0);
    const form = FORM_OF_TYPE[type] || null;
    if (form) {
      const formula = String(dmg.formula || '0');
      // A recovery aimed at foes, or damage aimed at allies, is a strange spell: not offered.
      const allySide = form === KIND.MEND || form === KIND.RENEW;
      if ((allySide && info.side === 'ally') || (!allySide && info.side === 'foe')) {
        const el = Number(dmg.elementId);
        const elementId = el > 0 ? el : 0; // -1 (normal attack) reads as no element
        out.push(Object.assign({}, base, {
          kind: form, key: form + ':' + elementId, elementId, formula, variance: Number(dmg.variance === undefined ? 20 : dmg.variance),
          critical: !!dmg.critical
        }));
      }
    }
    const cleanse = [];
    const effects = skill.effects || [];
    for (let i = 0; i < effects.length; i++) {
      const e = effects[i];
      const code = Number(e.code);
      const id = Number(e.dataId);
      if (code === 21 && id > 0 && id !== c.deathStateId && info.side === 'foe') {
        out.push(Object.assign({}, base, { kind: KIND.INFLICT, key: 'inflict:' + id, stateId: id, chance: Number(e.value1) }));
      } else if (code === 22 && id > 0 && id !== c.deathStateId && info.side === 'ally') {
        cleanse.push(id);
      } else if (code === 31 && info.side === 'ally') {
        out.push(Object.assign({}, base, { kind: KIND.BLESS, key: 'bless:' + id, paramId: id, turns: Math.max(1, Number(e.value1) || 1) }));
      } else if (code === 32 && info.side === 'foe') {
        out.push(Object.assign({}, base, { kind: KIND.CURSE, key: 'curse:' + id, paramId: id, turns: Math.max(1, Number(e.value1) || 1) }));
      }
    }
    if (cleanse.length) {
      cleanse.sort((a, b) => a - b);
      out.push(Object.assign({}, base, { kind: KIND.CLEANSE, key: 'cleanse:' + cleanse.join('.'), states: cleanse }));
    }
    // An effect that reaches every target is a DIFFERENT aspect from the same
    // effect on one target (Fire III and Flame II both offer Fire harm): the
    // key says so, and the player chooses the reach by choosing the aspect.
    if (info.width >= 3) for (let i = 0; i < out.length; i++) out[i].key += ':all';
    // One skill can list the same buff twice (stock "Spell Enhancement"): keep one.
    const seen = {};
    return out.filter((a) => (seen[a.key] ? false : (seen[a.key] = true)));
  }

  /**
   * The strength an aspect is offered at, for choosing between two known
   * spells that offer the same aspect: a rider's chance, else the source's cost
   * (the developer priced power, so cost is the honest proxy; the formula is
   * never evaluated).
   * @param {object} a Aspect.
   * @returns {number} Rank value.
   */
  function aspectRank(a) {
    if (a.kind === KIND.INFLICT) return a.chance * 1000 + a.cost;
    if (a.kind === KIND.BLESS || a.kind === KIND.CURSE) return a.turns * 1000 + a.cost;
    if (a.kind === KIND.CLEANSE) return a.states.length * 1000 + a.cost;
    return a.cost;
  }

  /**
   * Every aspect a set of known skills offers, one per key: where two spells
   * offer the same aspect the stronger source supplies it.
   * @param {object[]} skills Known skills.
   * @param {object} [cfg] Configuration.
   * @param {object} [locks] Map of source skill id -> true for locked sources.
   * @returns {object[]} Aspects in a stable order.
   */
  function gatherAspects(skills, cfg, locks) {
    const c = cfg || CONFIG;
    const best = {};
    for (let i = 0; i < skills.length; i++) {
      const s = skills[i];
      if (!s || (locks && locks[s.id])) continue;
      const list = readAspects(s, c);
      for (let k = 0; k < list.length; k++) {
        const a = list[k];
        const cur = best[a.key];
        if (!cur || aspectRank(a) > aspectRank(cur) || (aspectRank(a) === aspectRank(cur) && a.sourceId < cur.sourceId)) best[a.key] = a;
      }
    }
    const out = Object.keys(best).map((k) => best[k]);
    out.sort((a, b) => {
      const ka = KIND_ORDER.indexOf(a.kind);
      const kb = KIND_ORDER.indexOf(b.kind);
      if (ka !== kb) return ka - kb;
      const ea = (a.elementId || 0) * 100 + (a.stateId || 0) + (a.paramId || 0);
      const eb = (b.elementId || 0) * 100 + (b.stateId || 0) + (b.paramId || 0);
      if (ea !== eb) return ea - eb;
      return a.key < b.key ? -1 : a.key > b.key ? 1 : 0;
    });
    return out;
  }

  /** @param {object} a Aspect. @returns {boolean} It is a form. */
  function isForm(a) {
    return !!FORMS[a.kind];
  }

  //===========================================================================
  // Combination rules
  //===========================================================================

  /** The reasons an aspect can be refused, as stable codes (the scene letters them). */
  const REFUSE = {
    FULL: 'full', SIDE: 'side', FORM: 'form', SAME_ELEMENT: 'sameElement', ELEMENTS: 'elements', DUPLICATE: 'duplicate'
  };

  /**
   * May this aspect join the circle? Returns the FIRST rule it breaks.
   *  1 every aspect in a circle aims at one side (foes or allies);
   *  2 one form per spell, except that two HARM aspects of different elements
   *    fuse into one two-element harm;
   *  3 no more than `cap` aspects.
   * @param {object[]} chosen Aspects already in the circle.
   * @param {object} a The candidate.
   * @param {number} [cap] Cap.
   * @returns {{ok:boolean, reason:string|null}} Verdict.
   */
  function canAdd(chosen, a, cap) {
    const limit = cap === undefined ? CONFIG.cap : Number(cap);
    for (let i = 0; i < chosen.length; i++) if (chosen[i].key === a.key) return { ok: false, reason: REFUSE.DUPLICATE };
    if (chosen.length >= limit) return { ok: false, reason: REFUSE.FULL };
    if (chosen.length && chosen[0].side !== a.side) return { ok: false, reason: REFUSE.SIDE };
    if (isForm(a)) {
      const forms = chosen.filter(isForm);
      if (forms.length) {
        if (a.kind !== KIND.HARM || forms.some((f) => f.kind !== KIND.HARM)) return { ok: false, reason: REFUSE.FORM };
        if (forms.length >= 2) return { ok: false, reason: REFUSE.ELEMENTS };
        if (forms[0].elementId === a.elementId) return { ok: false, reason: REFUSE.SAME_ELEMENT };
      }
    }
    return { ok: true, reason: null };
  }

  //===========================================================================
  // The composition: what the chosen aspects add up to
  //===========================================================================

  /**
   * Evaluate the cost of a composition. The default is
   *   ceil(sum x (1 + comboTax x (n - 1)) x mult^costExponent x reach)
   * where sum is the cost of each DISTINCT source spell once. A developer
   * formula may replace it; the floor applies either way:
   *   cost >= max(minCost, ceil(dearest source x mult))
   * so a crafted spell is never cheaper than a database spell it was made
   * from, at the same strength.
   * @param {object} v {sum, n, mult, reach, max, tax}.
   * @param {object} [cfg] Configuration.
   * @returns {{cost:number, floor:number, raw:number}} Cost.
   */
  function costOf(v, cfg) {
    const c = cfg || CONFIG;
    let raw = Math.ceil(v.sum * (1 + c.comboTax * (v.n - 1)) * Math.pow(v.mult, c.costExponent) * v.reach);
    if (c.costFormula) {
      try {
        // eslint-disable-next-line no-new-func
        const f = new Function('sum', 'n', 'mult', 'reach', 'max', 'tax', 'return (' + c.costFormula + ');');
        const r = Number(f(v.sum, v.n, v.mult, v.reach, v.max, c.comboTax));
        if (isFinite(r)) raw = Math.ceil(r);
      } catch (e) {
        // a broken formula falls back to the default, never to zero
      }
    }
    const floor = Math.max(Number(c.minCost) || 0, Math.ceil(v.max * v.mult));
    return { cost: Math.max(floor, raw), floor, raw };
  }

  /**
   * Compose the chosen aspects at a magnitude into the crafted spell's
   * mechanics. Pure: the same inputs always give the same composition.
   * When the sources disagree about reach, the spell takes the WIDEST one at
   * the reach factor, unless `narrow` is true: then it keeps the narrowest
   * and pays nothing extra.
   * @param {object[]} chosen Aspects (order is the order they were added).
   * @param {number} magIndex Index into magnitudes.
   * @param {object} [cfg] Configuration.
   * @param {boolean} [narrow] Keep the narrowest reach.
   * @returns {object|null} Composition, or null for an empty circle.
   */
  function compose(chosen, magIndex, cfg, narrow) {
    const c = cfg || CONFIG;
    if (!chosen || !chosen.length) return null;
    const mi = Math.max(0, Math.min(c.magnitudes.length - 1, Math.round(Number(magIndex) || 0)));
    const mult = Number(c.magnitudes[mi]);
    const forms = chosen.filter(isForm);
    const riders = chosen.filter((a) => !isForm(a));
    // the stronger harm supplies the formula of a two-element harm
    let form = null;
    for (let i = 0; i < forms.length; i++) if (!form || forms[i].cost > form.cost) form = forms[i];
    const elements = [];
    for (let i = 0; i < forms.length; i++) if (forms[i].elementId > 0 && elements.indexOf(forms[i].elementId) < 0) elements.push(forms[i].elementId);
    // reach: the widest source (widening is charged), or the narrowest if asked
    let wideA = chosen[0];
    let narrowA = chosen[0];
    for (let i = 1; i < chosen.length; i++) {
      if (chosen[i].width > wideA.width) wideA = chosen[i];
      if (chosen[i].width < narrowA.width) narrowA = chosen[i];
    }
    const mixed = wideA.width > narrowA.width;
    const wide = mixed && narrow ? narrowA : wideA;
    const reach = mixed && !narrow ? Number(c.reachFactor) : 1;
    // cost: each distinct source spell once
    const seen = {};
    let sum = 0;
    let max = 0;
    const sources = [];
    for (let i = 0; i < chosen.length; i++) {
      const a = chosen[i];
      if (seen[a.sourceId]) continue;
      seen[a.sourceId] = true;
      sources.push(a.sourceId);
      sum += a.cost;
      if (a.cost > max) max = a.cost;
    }
    const cost = costOf({ sum, n: chosen.length, mult, reach, max }, c);
    const lead = form || chosen[0];
    return {
      side: chosen[0].side,
      kind: form ? form.kind : chosen[0].side === 'foe' ? 'hexOnly' : 'wardOnly',
      form,
      elements,
      riders,
      aspects: chosen.slice(),
      keys: chosen.map((a) => a.key),
      scope: wide.scope,
      width: wide.width,
      widened: reach > 1,
      mixedReach: mixed,
      narrow: !!(mixed && narrow),
      magIndex: mi,
      mult,
      sources,
      sum,
      max,
      cost: cost.cost,
      costFloor: cost.floor,
      costRaw: cost.raw,
      hitType: lead.hitType,
      animationId: lead.animationId,
      iconIndex: lead.iconIndex,
      occasion: chosen.every((a) => a.occasion === chosen[0].occasion) ? chosen[0].occasion : 1
    };
  }

  //===========================================================================
  // Names
  //===========================================================================

  /**
   * @param {string} s Name.
   * @returns {string} Lower-case lookup key.
   */
  function lk(s) {
    return String(s || '').trim().toLowerCase();
  }

  /**
   * The word an element contributes to a name.
   * @param {number} id Element id.
   * @param {object} ctx {elementName(id)}.
   * @param {object} [cfg] Configuration.
   * @returns {string} Root.
   */
  function elementRoot(id, ctx, cfg) {
    const c = cfg || CONFIG;
    if (!id) return c.elementRoots.none || 'Arcane';
    const nm = ctx && ctx.elementName ? ctx.elementName(id) : '';
    const hit = c.elementRoots[lk(nm)];
    return hit || String(nm || 'Arcane');
  }

  /**
   * The word a rider contributes.
   * @param {object} a Rider aspect.
   * @param {object} ctx {stateName(id)}.
   * @param {object} [cfg] Configuration.
   * @returns {string} Adjective (may contain a space).
   */
  function riderWord(a, ctx, cfg) {
    const c = cfg || CONFIG;
    if (a.kind === KIND.INFLICT) {
      const nm = ctx && ctx.stateName ? ctx.stateName(a.stateId) : '';
      return c.stateWords[lk(nm)] || (nm ? nm + '-touched' : 'Cursed');
    }
    if (a.kind === KIND.BLESS) return c.blessWords[a.paramId] || 'Blessed';
    if (a.kind === KIND.CURSE) return c.curseWords[a.paramId] || 'Withering';
    return c.cleanseWord;
  }

  /**
   * Propose a name for a composition. Variant 0 is the plain reading; higher
   * variants reorder and reword, deterministically.
   * @param {object} comp From compose.
   * @param {object} ctx {elementName, stateName}.
   * @param {number} [variant] Variant index.
   * @param {object} [cfg] Configuration.
   * @returns {string} Name.
   */
  function proposeName(comp, ctx, variant, cfg) {
    const c = cfg || CONFIG;
    if (!comp) return '';
    const v = Math.abs(Number(variant) || 0) % 3;
    const words = c.formWords[comp.kind] || ['Spell', 'Spell', 'Spell', 'Spell'];
    const wide = comp.width >= 3 ? 1 : 0;
    const noun = words[wide] || words[0];
    const alt = words[2 + wide] || noun;
    const intensity = c.intensityWords[comp.magIndex] || '';
    const adj = [];
    for (let i = 0; i < comp.riders.length && adj.length < 2; i++) {
      const w = riderWord(comp.riders[i], ctx, c);
      if (adj.indexOf(w) < 0) adj.push(w);
    }
    let root = '';
    if (comp.form) {
      root = comp.elements.length ? comp.elements.map((e) => elementRoot(e, ctx, c)).join('-') : elementRoot(0, ctx, c);
    }
    let parts;
    if (v === 0) parts = [intensity, adj[0], root, noun];
    else if (v === 1) parts = [intensity, adj[1] || adj[0], root, alt];
    else parts = [intensity, root, alt, comp.riders.length ? 'of ' + riderNoun(comp.riders[0], ctx, c) : ''];
    let name = parts.filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
    if (!name) name = noun;
    return name;
  }

  /**
   * The noun a rider gives an "of ..." name.
   * @param {object} a Rider aspect.
   * @param {object} ctx {stateName(id)}.
   * @param {object} [cfg] Configuration.
   * @returns {string} Noun.
   */
  function riderNoun(a, ctx, cfg) {
    const c = cfg || CONFIG;
    if (a.kind === KIND.INFLICT) {
      const nm = ctx && ctx.stateName ? ctx.stateName(a.stateId) : '';
      return nm || 'Ruin';
    }
    if (a.kind === KIND.BLESS) return c.blessNouns[a.paramId] || 'Vigor';
    if (a.kind === KIND.CURSE) return c.curseNouns[a.paramId] || 'Ruin';
    return c.cleanseNoun;
  }

  /**
   * Make a name unique against names already taken by adding II, III ...
   * @param {string} name Proposed.
   * @param {string[]} taken Existing names.
   * @returns {string} Unique name.
   */
  function uniqueName(name, taken) {
    const set = {};
    for (let i = 0; i < taken.length; i++) set[lk(taken[i])] = true;
    if (!set[lk(name)]) return name;
    const R = ['II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X'];
    for (let i = 0; i < R.length; i++) if (!set[lk(name + ' ' + R[i])]) return name + ' ' + R[i];
    return name + ' ' + (taken.length + 1);
  }

  /**
   * Clean a typed name: printable characters only, trimmed, capped.
   * @param {string} s Typed.
   * @param {number} [max] Length cap.
   * @returns {string} Clean name.
   */
  function cleanName(s, max) {
    const m = max || 36;
    return String(s || '').replace(/[\u0000-\u001f\u007f<>\\]/g, '').replace(/\s+/g, ' ').trim().slice(0, m);
  }

  /**
   * One plain line saying what the spell does, for the skill's description.
   * @param {object} comp Composition.
   * @param {object} ctx {elementName, stateName, paramName, sourceName}.
   * @returns {string} Description.
   */
  function describe(comp, ctx) {
    if (!comp) return '';
    const bits = [];
    const P = (id) => (ctx && ctx.paramName ? ctx.paramName(id) : 'stat ' + id);
    const S = (id) => (ctx && ctx.stateName ? ctx.stateName(id) : 'state ' + id);
    if (comp.form) {
      const el = comp.elements.length ? comp.elements.map((e) => (ctx && ctx.elementName ? ctx.elementName(e) : 'element ' + e)).join('/') + ' ' : '';
      const what = { harm: 'damage', sap: 'MP damage', drain: 'HP drain', siphon: 'MP drain', mend: 'HP recovery', renew: 'MP recovery' }[comp.form.kind];
      bits.push(el || comp.form.kind === 'mend' || comp.form.kind === 'renew' || comp.form.kind === 'siphon' ? el + what : 'Non-elemental ' + what);
    }
    for (let i = 0; i < comp.riders.length; i++) {
      const r = comp.riders[i];
      if (r.kind === KIND.INFLICT) bits.push(S(r.stateId) + ' ' + Math.round(Math.min(1, r.chance * comp.mult) * 100) + '%');
      else if (r.kind === KIND.BLESS) bits.push(P(r.paramId) + ' up');
      else if (r.kind === KIND.CURSE) bits.push(P(r.paramId) + ' down');
      else if (r.kind === KIND.CLEANSE) bits.push('cures ' + r.states.length);
    }
    const reach = comp.width >= 3 ? (comp.side === 'foe' ? 'all foes' : 'all allies') : comp.width === 1 ? (comp.side === 'foe' ? 'random foe' : 'self') : comp.side === 'foe' ? 'one foe' : 'one ally';
    const line = bits.join(', ') + ' (' + reach + ').';
    return line.charAt(0).toUpperCase() + line.slice(1);
  }

  //===========================================================================
  // The crafted spell as a database skill
  //===========================================================================

  /**
   * Build the MZ skill object for a composition. Everything a stock skill
   * carries is present, so Game_Action, the skill windows and other plugins
   * see an ordinary skill.
   * @param {object} comp Composition.
   * @param {string} name Final name.
   * @param {number} id Skill id to use.
   * @param {object} [ctx] Naming context.
   * @param {object} [cfg] Configuration.
   * @returns {object} Skill.
   */
  function toSkill(comp, name, id, ctx, cfg) {
    const c = cfg || CONFIG;
    const effects = [];
    for (let i = 0; i < comp.riders.length; i++) {
      const r = comp.riders[i];
      if (r.kind === KIND.INFLICT) effects.push({ code: 21, dataId: r.stateId, value1: Math.min(1, Math.round(r.chance * comp.mult * 1000) / 1000), value2: 0 });
      else if (r.kind === KIND.CLEANSE) for (let k = 0; k < r.states.length; k++) effects.push({ code: 22, dataId: r.states[k], value1: 1, value2: 0 });
      else if (r.kind === KIND.BLESS) effects.push({ code: 31, dataId: r.paramId, value1: Math.max(1, Math.round(r.turns * comp.mult)), value2: 0 });
      else if (r.kind === KIND.CURSE) effects.push({ code: 32, dataId: r.paramId, value1: Math.max(1, Math.round(r.turns * comp.mult)), value2: 0 });
    }
    const f = comp.form;
    const formula = f ? '(' + f.formula + ') * ' + comp.mult : '0';
    const note = '<spellwright crafted>' + (comp.elements.length > 1 ? '\n<spellwright elements: ' + comp.elements.join(',') + '>' : '');
    return {
      id: Number(id),
      animationId: comp.animationId,
      damage: {
        critical: f ? !!f.critical : false,
        elementId: comp.elements.length ? comp.elements[0] : 0,
        formula,
        type: f ? FORMS[f.kind] : 0,
        variance: f ? f.variance : 20
      },
      description: describe(comp, ctx),
      effects,
      hitType: comp.hitType,
      iconIndex: comp.iconIndex,
      message1: ' casts %1!',
      message2: '',
      mpCost: comp.cost,
      name: String(name),
      note,
      occasion: comp.occasion,
      repeats: 1,
      requiredWtypeId1: 0,
      requiredWtypeId2: 0,
      scope: comp.scope,
      speed: 0,
      stypeId: Number(c.skillType),
      successRate: 100,
      tpCost: 0,
      tpGain: 0,
      messageType: 1,
      _csafCrafted: true
    };
  }

  //===========================================================================
  // The seal: drawn from the composition alone
  //===========================================================================

  const TAU = Math.PI * 2;
  /** Primitive kinds, in a unit space where the seal's rim is radius 1. */
  const P = { RING: 'ring', ARC: 'arc', POLY: 'poly', LINE: 'line', DOT: 'dot', GLYPH: 'glyph' };
  const BASE_SYM = { harm: 5, sap: 7, drain: 6, siphon: 6, mend: 4, renew: 4, hexOnly: 3, wardOnly: 6 };

  /**
   * The glyph a rider is written in on the middle band: a short polyline in a
   * [-0.5, 0.5] box. Each kind has its own figure; the state or stat id varies
   * the count of strokes, so two riders of one kind still read apart.
   * @param {object} r Rider aspect.
   * @returns {number[]} Flat [x0,y0,x1,y1,...] segments.
   */
  function riderGlyph(r) {
    const s = [];
    if (r.kind === KIND.INFLICT) {
      // an affliction mark: a lozenge, crossed by 1-3 strokes chosen by the state
      // (it must not point: up-pointing figures are blessings)
      s.push(0, -0.5, 0.42, 0, 0.42, 0, 0, 0.5, 0, 0.5, -0.42, 0, -0.42, 0, 0, -0.5);
      // ten interior marks, so ten consecutive state ids never share a glyph
      const v = (Number(r.stateId) || 0) % 10;
      const DIAG_A = [-0.18, -0.24, 0.18, 0.24];
      const DIAG_B = [0.18, -0.24, -0.18, 0.24];
      const BAR_H = [-0.28, 0, 0.28, 0];
      const BAR_V = [0, -0.34, 0, 0.34];
      const add = (seg) => { for (let i = 0; i < seg.length; i++) s.push(seg[i]); };
      if (v === 0) add(DIAG_A);
      else if (v === 1) add(DIAG_B);
      else if (v === 2) { add(DIAG_A); add(DIAG_B); }
      else if (v === 3) add(BAR_H);
      else if (v === 4) add(BAR_V);
      else if (v === 5) { add(BAR_H); add(BAR_V); }
      else if (v === 6) s.push(0, -0.22, 0.18, 0, 0.18, 0, 0, 0.22, 0, 0.22, -0.18, 0, -0.18, 0, 0, -0.22);
      else if (v === 7) s.push(-0.06, -0.06, 0.06, 0.06, -0.06, 0.06, 0.06, -0.06);
      else if (v === 8) { add(DIAG_A); add(BAR_H); }
      else { add(DIAG_B); add(BAR_V); }
    } else if (r.kind === KIND.CURSE || r.kind === KIND.BLESS) {
      // chevrons: up for a blessing, down for a curse, 1-3 by stat
      const n = 1 + ((r.paramId || 0) % 3);
      const dir = r.kind === KIND.BLESS ? -1 : 1;
      for (let k = 0; k < n; k++) {
        const y = (k - (n - 1) / 2) * 0.3;
        s.push(-0.4, y - dir * 0.18, 0, y + dir * 0.18, 0, y + dir * 0.18, 0.4, y - dir * 0.18);
      }
    } else {
      // cleanse: a broken square opened at the top, a bar through it
      s.push(-0.36, -0.2, -0.36, 0.4, -0.36, 0.4, 0.36, 0.4, 0.36, 0.4, 0.36, -0.2, -0.5, 0.06, 0.5, 0.06);
      const n = Math.min(3, (r.states || []).length);
      for (let k = 0; k < n; k++) s.push(-0.2 + k * 0.2, -0.5, -0.2 + k * 0.2, -0.3);
    }
    return s;
  }

  /**
   * @param {object} p Primitive.
   * @returns {number} Drawn length in unit space.
   */
  function primLength(p) {
    switch (p.t) {
      case P.RING: return TAU * p.r;
      case P.ARC: return Math.abs(p.a1 - p.a0) * p.r;
      case P.POLY: {
        const step = (TAU * p.skip) / p.n;
        return p.n * 2 * p.r * Math.abs(Math.sin(step / 2));
      }
      case P.LINE: return Math.hypot(p.x1 - p.x0, p.y1 - p.y0);
      case P.DOT: return TAU * p.r;
      case P.GLYPH: {
        let n = 0;
        for (let i = 0; i < p.s.length; i += 4) n += Math.hypot(p.s[i + 2] - p.s[i], p.s[i + 3] - p.s[i + 1]);
        return n * p.size;
      }
      default: return 0;
    }
  }

  /**
   * Generate a composition's seal. Every decision is read from the
   * composition: reach shapes the rim, form shapes the core and fixes the
   * symmetry, riders write the middle band, magnitude adds layers and the cost
   * sets the tick count on the rim. The seed only turns the figure, so the
   * same spell always gets the same seal whoever names it.
   * @param {object} comp Composition.
   * @param {object} [cfg] Configuration.
   * @returns {object} {key, sym, palettes, prims, total}.
   */
  function buildSeal(comp, cfg) {
    const c = cfg || CONFIG;
    const keyStr = comp.keys.slice().sort().join('|') + '#' + comp.magIndex;
    // The turn of the figure comes from the FIRST aspect alone: adding a second
    // aspect must not spin the whole seal, or nothing it shares with the
    // previous seal could stay inscribed while the change draws itself.
    const rng = new Rng(hash32(String(comp.keys[0] || '')));
    const kind = comp.kind;
    const sym = Math.max(3, Math.min(9, (BASE_SYM[kind] || 5) + (comp.riders.length >= 2 ? 1 : 0)));
    const mag = comp.magIndex;
    const pal = comp.elements.length ? comp.elements.map((e) => paletteFor(e, c)) : [paletteFor(0, c)];
    const two = pal.length > 1;
    const prims = [];
    const spin = rng.next() * TAU;
    // colour channel: 0 = first palette, 1 = second, -1 = both (a two-element seal splits its rim)
    const push = (p) => { p.ch = p.ch === undefined ? 0 : p.ch; prims.push(p); };

    // ---- layer 0: the rim, by reach ----
    if (comp.width >= 3) {
      if (two) { push({ t: P.ARC, r: 1, a0: Math.PI / 2, a1: Math.PI * 1.5, w: 1.1, L: 0, ch: 0, id: 'rimA' }); push({ t: P.ARC, r: 1, a0: -Math.PI / 2, a1: Math.PI / 2, w: 1.1, L: 0, ch: 1, id: 'rimB' }); }
      else push({ t: P.RING, r: 1, w: 1.1, L: 0, id: 'rim' });
      push({ t: P.RING, r: 0.925, w: 0.6, L: 0, ch: two ? 1 : 0, id: 'rim2' });
    } else if (comp.width === 1) {
      for (let s = 0; s < sym; s++) {
        const a0 = spin + (s * TAU) / sym + 0.12;
        push({ t: P.ARC, r: 1, a0, a1: a0 + TAU / sym - 0.24, w: 1.0, L: 0, ch: two ? s % 2 : 0, id: 'rimR' + s });
      }
    } else if (two) {
      push({ t: P.ARC, r: 1, a0: Math.PI / 2, a1: Math.PI * 1.5, w: 1.0, L: 0, ch: 0, id: 'rimA' });
      push({ t: P.ARC, r: 1, a0: -Math.PI / 2, a1: Math.PI / 2, w: 1.0, L: 0, ch: 1, id: 'rimB' });
    } else push({ t: P.RING, r: 1, w: 1.0, L: 0, id: 'rim' });

    // ---- layer 0: cost ticks on the rim (a dearer spell is visibly denser) ----
    const ticks = Math.max(sym * 2, Math.min(72, Math.round(comp.cost / 3 / sym) * sym));
    const tickIn = comp.width >= 3 ? 0.94 : 0.955;
    for (let i = 0; i < ticks; i++) {
      const a = spin + (i * TAU) / ticks;
      const long = i % (ticks / sym) === 0;
      const r0 = long ? tickIn - 0.05 : tickIn;
      push({ t: P.LINE, x0: Math.cos(a) * r0, y0: Math.sin(a) * r0, x1: Math.cos(a) * 0.985, y1: Math.sin(a) * 0.985, w: long ? 0.55 : 0.32, L: 0, ch: two ? (Math.cos(a) < 0 ? 0 : 1) : 0, id: 'tick' + i + '/' + ticks });
    }

    // ---- layer 1: the middle band with the riders' glyphs ----
    const band = 0.74;
    push({ t: P.RING, r: band + 0.085, w: 0.42, L: 1, id: 'bandO' });
    push({ t: P.RING, r: band - 0.085, w: 0.42, L: 1, id: 'bandI' });
    const slots = sym * 2;
    if (comp.riders.length) {
      for (let i = 0; i < slots; i++) {
        const r = comp.riders[i % comp.riders.length];
        const a = spin + (i * TAU) / slots;
        push({ t: P.GLYPH, a, r: band, size: 0.135, s: riderGlyph(r), w: 0.7, L: 1, ch: two ? i % 2 : 0, id: 'g' + i + ':' + r.key });
      }
    } else {
      // no riders: the band carries the form's own script, plain ticks between rules
      for (let i = 0; i < slots * 2; i++) {
        const a = spin + (i * TAU) / (slots * 2);
        const h = i % 2 ? 0.035 : 0.06;
        push({ t: P.LINE, x0: Math.cos(a) * (band - h), y0: Math.sin(a) * (band - h), x1: Math.cos(a) * (band + h), y1: Math.sin(a) * (band + h), w: 0.4, L: 1, ch: two ? i % 2 : 0, id: 'script' + i });
      }
    }

    // ---- layer 2: the core, by form ----
    const coreR = 0.5;
    const rot = spin - Math.PI / 2;
    if (kind === 'harm' || kind === 'sap') {
      const skip = kind === 'sap' ? 3 : 2;
      push({ t: P.POLY, r: coreR, n: sym, skip, rot, w: 0.95, L: 2, ch: 0, id: 'star' });
      if (two) push({ t: P.POLY, r: coreR * 0.82, n: sym, skip, rot: rot + Math.PI / sym, w: 0.8, L: 2, ch: 1, id: 'star2' });
      if (kind === 'sap') push({ t: P.RING, r: 0.12, w: 0.7, L: 2, id: 'hollow' });
    } else if (kind === 'drain' || kind === 'siphon') {
      for (let s = 0; s < sym; s++) {
        const a0 = rot + (s * TAU) / sym;
        push({ t: P.ARC, r: coreR - (s % 2) * 0.06, a0, a1: a0 + Math.PI * 0.75, w: 0.85, L: 2, ch: two ? s % 2 : 0, id: 'vortex' + s, inward: kind === 'siphon' ? 0.4 : 0.6 });
      }
      push({ t: P.DOT, r: 0.06, x: 0, y: 0, w: 1, L: 2, id: 'eye', fill: true });
    } else if (kind === 'mend' || kind === 'renew') {
      for (let s = 0; s < sym * 2; s++) {
        const a = rot + (s * TAU) / (sym * 2);
        push({ t: P.ARC, r: coreR * 0.42, cx: Math.cos(a) * coreR * 0.5, cy: Math.sin(a) * coreR * 0.5, a0: 0, a1: TAU, w: 0.6, L: 2, ch: 0, id: 'petal' + s });
      }
      push({ t: P.RING, r: kind === 'renew' ? 0.16 : 0.1, w: 0.7, L: 2, id: 'heart' });
    } else if (kind === 'hexOnly') {
      for (let s = 0; s < sym; s++) {
        const a = rot + (s * TAU) / sym;
        push({ t: P.ARC, r: 0.25, cx: Math.cos(a) * 0.27, cy: Math.sin(a) * 0.27, a0: 0, a1: TAU, w: 0.7, L: 2, id: 'knot' + s });
      }
      push({ t: P.POLY, r: 0.18, n: sym, skip: 1, rot: rot + Math.PI, w: 0.7, L: 2, id: 'knotCore' });
    } else {
      push({ t: P.POLY, r: coreR, n: sym, skip: 1, rot, w: 0.9, L: 2, id: 'shield' });
      push({ t: P.POLY, r: coreR * 0.6, n: sym, skip: 1, rot: rot + Math.PI / sym, w: 0.7, L: 2, id: 'shield2' });
      push({ t: P.RING, r: 0.12, w: 0.6, L: 2, id: 'boss' });
    }

    // ---- layer 3: magnitude adds layers ----
    if (mag >= 1) push({ t: P.RING, r: 0.6, w: 0.35, L: 3, ch: two ? 1 : 0, id: 'm1' });
    if (mag >= 2) {
      for (let s = 0; s < sym; s++) {
        const a = rot + (s * TAU) / sym;
        push({ t: P.LINE, x0: Math.cos(a) * 0.6, y0: Math.sin(a) * 0.6, x1: Math.cos(a) * (band - 0.09), y1: Math.sin(a) * (band - 0.09), w: 0.5, L: 3, id: 'spoke' + s });
      }
    }
    if (mag >= 3) push({ t: P.POLY, r: 0.3, n: sym, skip: sym >= 5 ? 2 : 1, rot: rot + Math.PI / sym, w: 0.6, L: 3, ch: two ? 1 : 0, id: 'm3' });
    if (mag >= 4) {
      for (let s = 0; s < sym; s++) {
        const a0 = spin + (s * TAU) / sym + TAU / sym / 4;
        push({ t: P.ARC, r: 1.07, a0, a1: a0 + TAU / sym / 2, w: 0.5, L: 3, ch: two ? s % 2 : 0, id: 'halo' + s });
      }
    }
    // ---- layer 4: nodes on the star's points, a dot per source spell at the centre ----
    for (let s = 0; s < sym; s++) {
      const a = rot + (s * TAU) / sym;
      push({ t: P.DOT, r: 0.024 + 0.004 * mag, x: Math.cos(a) * coreR, y: Math.sin(a) * coreR, w: 1, L: 4, fill: true, ch: two ? s % 2 : 0, id: 'node' + s });
    }
    if (kind !== 'drain' && kind !== 'siphon') push({ t: P.DOT, r: 0.035, x: 0, y: 0, w: 1, L: 4, fill: true, id: 'pip' });

    // outside-in, like a hand draws it; stable inside a layer. Every primitive is
    // rebuilt in ONE object shape: paint reads their double fields every frame
    // a seal inscribes, and reads across many shapes are megamorphic, which
    // boxes each double (MEASURED: ~22 bytes per stroke per paint, tests/alloc.test.js).
    const ordered = prims.map((p, i) => ({ p, i })).sort((a, b) => a.p.L - b.p.L || a.i - b.i).map((x) => canonPrim(x.p));
    let total = 0;
    for (let i = 0; i < ordered.length; i++) {
      ordered[i].len = primLength(ordered[i]);
      total += ordered[i].len;
    }
    let reach = 1;
    for (let i = 0; i < ordered.length; i++) if (ordered[i].t === P.ARC && !ordered[i].cx && ordered[i].r > reach) reach = ordered[i].r;
    return { key: keyStr, sym, palettes: pal, prims: ordered, total, reach };
  }

  /**
   * One primitive in the single shape every primitive shares (absent fields
   * are 0, null or false, in a fixed order).
   * @param {object} p Primitive as generated.
   * @returns {object} Canonical primitive.
   */
  function canonPrim(p) {
    return {
      t: p.t, id: String(p.id), L: p.L | 0, ch: p.ch | 0, w: +(p.w || 0),
      r: +(p.r || 0), a: +(p.a || 0), a0: +(p.a0 || 0), a1: +(p.a1 || 0),
      n: p.n | 0, skip: p.skip | 0, rot: +(p.rot || 0),
      x0: +(p.x0 || 0), y0: +(p.y0 || 0), x1: +(p.x1 || 0), y1: +(p.y1 || 0),
      x: +(p.x || 0), y: +(p.y || 0), cx: +(p.cx || 0), cy: +(p.cy || 0),
      size: +(p.size || 0), s: p.s || null, inward: +(p.inward || 0), fill: !!p.fill, len: 0
    };
  }

  /**
   * @param {number} elementId Element id.
   * @param {object} [cfg] Configuration.
   * @returns {object} Palette.
   */
  function paletteFor(elementId, cfg) {
    const c = cfg || CONFIG;
    const list = c.palettes || PALETTES;
    for (let i = 0; i < list.length; i++) if (Number(list[i].elementId) === Number(elementId)) return list[i];
    for (let i = 0; i < list.length; i++) if (Number(list[i].elementId) === 0) return list[i];
    return PALETTES[0];
  }

  /**
   * A fingerprint of a seal's geometry (tests: "different spells, different
   * seals" must compare geometry, not object identity).
   * @param {object} seal From buildSeal.
   * @returns {string} Hex.
   */
  function fingerprint(seal) {
    let h = 0x811c9dc5;
    const r3 = (n) => (n === undefined ? '_' : (Math.round(n * 1000) / 1000).toFixed(3));
    for (let i = 0; i < seal.prims.length; i++) {
      const q = seal.prims[i];
      h = hash32(q.t + '|' + r3(q.r) + '|' + r3(q.a) + '|' + r3(q.a0) + '|' + r3(q.a1) + '|' + (q.n || 0) + '|' + (q.skip || 0) + '|' + r3(q.rot) + '|' + r3(q.x0) + '|' + r3(q.y0) + '|' + r3(q.cx) + '|' + r3(q.x) + '|' + q.ch, h);
      if (q.s) for (let k = 0; k < q.s.length; k++) h = hash32(r3(q.s[k]), h);
    }
    for (let i = 0; i < seal.palettes.length; i++) h = hash32(seal.palettes[i].glow, h);
    return (h >>> 0).toString(16).padStart(8, '0');
  }

  //===========================================================================
  // Painting a seal onto a 2D canvas context (used by the scene, the ledger
  // and the battle flash; pure apart from the context it is handed)
  //===========================================================================

  /**
   * Trace one primitive, or the first `frac` of it, as a path.
   * @param {CanvasRenderingContext2D} ctx Context (already translated and scaled).
   * @param {object} p Primitive.
   * @param {number} frac 0..1 of its length.
   */
  function trace(ctx, p, frac) {
    const f = frac >= 1 ? 1 : frac <= 0 ? 0 : frac;
    ctx.beginPath();
    switch (p.t) {
      case P.RING:
        ctx.arc(0, 0, p.r, -Math.PI / 2, -Math.PI / 2 + TAU * f);
        break;
      case P.ARC: {
        const cx = p.cx || 0;
        const cy = p.cy || 0;
        if (p.inward) {
          // a vortex arm: radius shrinks as it turns
          const steps = 18;
          for (let i = 0; i <= steps * f; i++) {
            const k = i / steps;
            const a = p.a0 + (p.a1 - p.a0) * k;
            const rr = p.r * (1 - p.inward * k);
            if (i === 0) ctx.moveTo(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr);
            else ctx.lineTo(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr);
          }
        } else {
          ctx.arc(cx, cy, p.r, p.a0, p.a0 + (p.a1 - p.a0) * f);
        }
        break;
      }
      case P.POLY: {
        const steps = p.n;
        const upto = steps * f;
        for (let i = 0; i <= Math.ceil(upto) && i <= steps; i++) {
          const k = Math.min(i, upto);
          const fl = Math.floor(k);
          const fr = k - fl;
          const a0 = p.rot + (fl * p.skip * TAU) / p.n;
          const a1 = p.rot + ((fl + 1) * p.skip * TAU) / p.n;
          let x = Math.cos(a0) * p.r;
          let y = Math.sin(a0) * p.r;
          if (fr > 0) {
            x += (Math.cos(a1) * p.r - x) * fr;
            y += (Math.sin(a1) * p.r - y) * fr;
          }
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        break;
      }
      case P.LINE:
        ctx.moveTo(p.x0, p.y0);
        ctx.lineTo(p.x0 + (p.x1 - p.x0) * f, p.y0 + (p.y1 - p.y0) * f);
        break;
      case P.DOT:
        ctx.arc(p.x || 0, p.y || 0, p.r * (0.3 + 0.7 * f), 0, TAU);
        break;
      case P.GLYPH: {
        const ca = Math.cos(p.a + Math.PI / 2);
        const sa = Math.sin(p.a + Math.PI / 2);
        const ox = Math.cos(p.a) * p.r;
        const oy = Math.sin(p.a) * p.r;
        const n = p.s.length / 4;
        const upto = n * f;
        for (let i = 0; i < n && i < upto; i++) {
          const k = Math.min(1, upto - i);
          const x0 = p.s[i * 4] * p.size;
          const y0 = p.s[i * 4 + 1] * p.size;
          const x1 = x0 + (p.s[i * 4 + 2] * p.size - x0) * k;
          const y1 = y0 + (p.s[i * 4 + 3] * p.size - y0) * k;
          ctx.moveTo(ox + x0 * ca - y0 * sa, oy + x0 * sa + y0 * ca);
          ctx.lineTo(ox + x1 * ca - y1 * sa, oy + x1 * sa + y1 * ca);
        }
        break;
      }
      default:
        break;
    }
  }

  /**
   * Paint a seal. `progress` walks the total drawn length (so a long ring
   * takes longer than a tick); `doneKeys`, when given, names primitives that
   * are already inscribed (they draw whole whatever the progress, which is
   * how an aspect added to a circle re-inscribes only what it changed).
   * @param {CanvasRenderingContext2D} ctx Context.
   * @param {object} seal From buildSeal.
   * @param {number} cx Centre x in pixels.
   * @param {number} cy Centre y in pixels.
   * @param {number} radius Rim radius in pixels.
   * @param {number} progress 0..1.
   * @param {object} [opts] {lineScale, glow (0..1), doneKeys (object), alpha}.
   */
  // three passes: wide faint bloom, mid glow, the ink line (module-level: paint
  // runs every frame while a seal inscribes and must not allocate)
  const PASSES = Object.freeze([
    Object.freeze({ width: 11, a: 0.14, glowed: true, col: 'glow', comp: 'lighter' }),
    Object.freeze({ width: 4.6, a: 0.36, glowed: true, col: 'glow', comp: 'lighter' }),
    Object.freeze({ width: 1.5, a: 1, glowed: false, col: 'ink', comp: 'source-over' })
  ]);
  const NO_OPTS = Object.freeze({});

  function paint(ctx, seal, cx, cy, radius, progress, opts) {
    const o = opts || NO_OPTS;
    const glow = o.glow === undefined ? 1 : o.glow;
    const lineScale = o.lineScale || 1;
    const alpha = o.alpha === undefined ? 1 : o.alpha;
    const done = o.doneKeys || null;
    const scale = radius / Math.max(1, seal.reach || 1);
    // pending length: what still has to be drawn (already-inscribed parts are free)
    let pending = 0;
    for (let i = 0; i < seal.prims.length; i++) if (!(done && done[seal.prims[i].id])) pending += seal.prims[i].len;
    const target = pending * (progress > 0 ? (progress < 1 ? progress : 1) : 0);
    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(scale, scale);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    for (let pi = 0; pi < PASSES.length; pi++) {
      const pass = PASSES[pi];
      const passAlpha = pass.glowed ? pass.a * glow : pass.a;
      if (passAlpha <= 0) continue;
      ctx.globalCompositeOperation = pass.comp;
      let acc = 0;
      for (let i = 0; i < seal.prims.length; i++) {
        const p = seal.prims[i];
        let frac = 1;
        if (!(done && done[p.id])) {
          // past the progress point: skip THIS stroke, never the rest - an already
          // inscribed stroke later in the order (the core is drawn late) must still draw
          if (acc >= target) continue;
          frac = p.len > 0 ? Math.min(1, (target - acc) / p.len) : 1;
          acc += p.len;
        }
        const pal = seal.palettes[p.ch >= 0 && p.ch < seal.palettes.length ? p.ch : 0];
        const colour = pass.col === 'ink' ? (p.t === P.DOT ? pal.accent : pal.ink) : pal.glow;
        ctx.globalAlpha = passAlpha * alpha;
        ctx.strokeStyle = colour;
        ctx.fillStyle = colour;
        ctx.lineWidth = (pass.width * p.w * lineScale) / scale * (radius / 150);
        trace(ctx, p, frac);
        if (p.t === P.DOT && p.fill && pass.col === 'ink') ctx.fill();
        else ctx.stroke();
      }
    }
    ctx.restore();
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
  }

  //===========================================================================
  // Records: what a save keeps (decisions plus the frozen skill)
  //===========================================================================

  const RECORD_VERSION = 1;

  /**
   * The record a save keeps for one crafted spell. The skill is FROZEN: a
   * developer editing a source spell later does not change a spell the player
   * already made.
   * @param {object} skill From toSkill.
   * @param {number} actorId Crafter.
   * @param {object} comp Composition.
   * @returns {object} Record.
   */
  function makeRecord(skill, actorId, comp) {
    return { v: RECORD_VERSION, id: skill.id, actorId: Number(actorId), keys: comp.keys.slice(), magIndex: comp.magIndex, sources: comp.sources.slice(), elements: comp.elements.slice(), seal: sealSpec(comp), skill: stripSkill(skill) };
  }

  /**
   * Exactly the fields buildSeal reads, as plain data, so a saved spell's seal
   * is rebuilt identically by the ledger and the battle flash.
   * @param {object} comp Composition.
   * @returns {object} Seal spec (a valid argument to buildSeal).
   */
  function sealSpec(comp) {
    return {
      keys: comp.keys.slice(),
      magIndex: comp.magIndex,
      kind: comp.kind,
      width: comp.width,
      elements: comp.elements.slice(),
      cost: comp.cost,
      riders: comp.riders.map((r) => ({ kind: r.kind, key: r.key, stateId: r.stateId, paramId: r.paramId, states: r.states ? r.states.slice() : undefined }))
    };
  }

  /** @param {object} s Skill. @returns {object} Plain copy without runtime fields. */
  function stripSkill(s) {
    const o = {};
    for (const k of Object.keys(s)) if (k !== 'meta' && k !== '_csafCrafted') o[k] = s[k];
    o.damage = Object.assign({}, s.damage);
    o.effects = s.effects.map((e) => Object.assign({}, e));
    return o;
  }

  /**
   * Read a record from a save, tolerating older and newer versions: unknown
   * fields are kept, a missing skill is refused (returns null) rather than
   * guessed.
   * @param {object} r Saved record.
   * @returns {object|null} Usable record.
   */
  function readRecord(r) {
    if (!r || typeof r !== 'object' || !r.skill || !(Number(r.id) > 0)) return null;
    const skill = Object.assign({}, r.skill);
    skill.id = Number(r.id);
    skill.damage = Object.assign({ critical: false, elementId: 0, formula: '0', type: 0, variance: 20 }, r.skill.damage || {});
    skill.effects = Array.isArray(r.skill.effects) ? r.skill.effects.map((e) => Object.assign({}, e)) : [];
    skill._csafCrafted = true;
    return Object.assign({}, r, { v: Number(r.v) || 1, skill });
  }

  /**
   * The element rate for a two-element spell: the MEAN of the target's rates,
   * so a fire-and-ice spell finds half of a fire weakness and half of an ice
   * resistance.
   * @param {number[]} rates Target rates per element.
   * @returns {number} Rate.
   */
  function blendRates(rates) {
    if (!rates.length) return 1;
    let s = 0;
    for (let i = 0; i < rates.length; i++) s += rates[i];
    return s / rates.length;
  }

  /**
   * @param {string} note Skill note.
   * @returns {number[]} Element ids from <spellwright elements: a,b>.
   */
  function noteElements(note) {
    const m = /<spellwright\s+elements:\s*([\d,\s]+)>/i.exec(String(note || ''));
    if (!m) return [];
    return m[1].split(',').map((x) => Number(x)).filter((x) => x > 0);
  }

  /**
   * Replace configuration fields. Unknown keys are ignored so a newer
   * parameter cannot break an older install.
   * @param {object} patch Partial configuration.
   * @returns {object} Live configuration.
   */
  function configure(patch) {
    if (!patch) return CONFIG;
    for (const k of Object.keys(CONFIG)) if (patch[k] !== undefined) CONFIG[k] = patch[k];
    return CONFIG;
  }

  const api = {
    VERSION: '1.0.0', KIND, REFUSE, P, PALETTES, RECORD_VERSION,
    config: () => CONFIG, configure,
    hash32, Rng, scopeInfo, sourceCost, offersAspects, readAspects, gatherAspects, aspectRank, isForm,
    canAdd, costOf, compose, proposeName, uniqueName, cleanName, describe, elementRoot, riderWord,
    riderNoun, toSkill, buildSeal, riderGlyph, primLength, paletteFor, fingerprint, trace, paint,
    makeRecord, sealSpec, readRecord, stripSkill, blendRates, noteElements
  };
  if (typeof window !== 'undefined') window.SpellwrightCore = api;
  return api;
})();

if (typeof module !== 'undefined' && module.exports) module.exports = SpellwrightCore;
