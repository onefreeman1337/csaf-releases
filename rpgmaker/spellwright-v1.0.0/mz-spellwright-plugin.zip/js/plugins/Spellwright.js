//=============================================================================
// Spellwright.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] The player crafts new spells from the effects of spells they know. Each one draws its own magic circle.
 * @author CSAF - Core Systems Asset Factory
 * @url https://csaf.itch.io/spellwright
 *
 * @param cap
 * @text Aspects per spell
 * @type number
 * @min 1
 * @max 6
 * @desc The most aspects one crafted spell may combine. The plugin command can change it per actor.
 * @default 4
 *
 * @param maxPerActor
 * @text Crafted spells per actor
 * @type number
 * @min 1
 * @max 40
 * @desc How many crafted spells one actor may hold at once.
 * @default 6
 *
 * @param aspectTypes
 * @text Skill types that offer aspects
 * @type string
 * @desc Skill type ids (comma separated) whose spells offer aspects. A <spellwright aspect> note adds any skill.
 * @default 1
 *
 * @param skillType
 * @text Crafted spell skill type
 * @type number
 * @min 1
 * @desc The skill type id a crafted spell belongs to (1 = Magic in a new project).
 * @default 1
 *
 * @param minCost
 * @text Minimum cost (MP)
 * @type number
 * @min 0
 * @default 5
 *
 * @param comboTax
 * @text Combination surcharge
 * @type number
 * @decimals 2
 * @min 0
 * @desc Each aspect past the first adds this share of the summed source cost. 0.15 = 15%.
 * @default 0.15
 *
 * @param reachFactor
 * @text Widening multiplier
 * @type number
 * @decimals 2
 * @min 1
 * @desc Cost multiplier when one source hits one target and another hits all, and the spell takes the wider reach.
 * @default 1.50
 *
 * @param costExponent
 * @text Magnitude cost exponent
 * @type number
 * @decimals 2
 * @min 1
 * @desc Cost grows with magnitude to this power, so a stronger spell costs MORE than proportionally.
 * @default 1.25
 *
 * @param magnitudes
 * @text Magnitude steps
 * @type string
 * @desc Five power multipliers for the dial, comma separated, weakest first.
 * @default 0.6, 0.8, 1.0, 1.25, 1.5
 *
 * @param tpToMp
 * @text MP per TP
 * @type number
 * @decimals 2
 * @min 0
 * @desc A source spell that costs TP counts this many MP per TP.
 * @default 1.00
 *
 * @param costFormula
 * @text Cost formula (optional)
 * @type string
 * @desc Replace the cost formula. Variables: sum n mult reach max tax. The floor still applies. Blank = default.
 * @default
 *
 * @param idBase
 * @text First crafted skill id
 * @type number
 * @min 100
 * @desc Crafted spells are added to the database at ids above this. Keep it above your last skill.
 * @default 3000
 *
 * @param craftGold
 * @text Gold per craft
 * @type number
 * @min 0
 * @desc Gold taken each time a spell is inscribed. 0 = free.
 * @default 0
 *
 * @param allowTyping
 * @text Players may type names
 * @type boolean
 * @desc Lets the player type a name with a keyboard. Players without one can always cycle the proposed names.
 * @default true
 *
 * @param resultVariable
 * @text Last crafted skill variable
 * @type variable
 * @desc Receives the skill id of the last spell inscribed. 0 = none.
 * @default 0
 *
 * @param menuCommand
 * @text Main menu command
 * @type string
 * @desc A main menu command that opens the circle for the chosen actor. Blank = no menu command.
 * @default
 *
 * @param menuSwitch
 * @text Menu command switch
 * @type switch
 * @desc When set, the menu command only shows while this switch is ON. 0 = always.
 * @default 0
 *
 * @param battleSeal
 * @text Seal flash in battle
 * @type boolean
 * @desc Inscribes a crafted spell's seal over the battlefield when it is cast.
 * @default true
 *
 * @param elementRoots
 * @text Element name words
 * @type note
 * @desc One per line, Element=Word, matched by your element names. Words for names like "Ember Bolt".
 * @default "Physical=Iron\nFire=Ember\nIce=Rime\nThunder=Storm\nWater=Tide\nEarth=Stone\nWind=Gale\nLight=Dawn\nDarkness=Umbral\nNone=Arcane"
 *
 * @param stateWords
 * @text State name words
 * @type note
 * @desc One per line, State=Word, matched by your state names. Unlisted states use "<State>-touched".
 * @default "Poison=Venomed\nBlind=Blinding\nSilence=Hushing\nRage=Maddening\nConfusion=Bewildering\nFascination=Beguiling\nSleep=Drowsing\nParalysis=Binding\nStun=Stunning"
 *
 * @command open
 * @text Open Spellwright's Circle
 * @desc Opens the crafting circle for one actor.
 *
 * @arg actorId
 * @text Actor
 * @type actor
 * @desc 0 = the party leader.
 * @default 0
 *
 * @command ledger
 * @text Open Spell Ledger
 * @desc Shows the crafted spells of one actor, each with its seal. Shift twice unmakes one.
 *
 * @arg actorId
 * @text Actor
 * @type actor
 * @default 0
 *
 * @command grant
 * @text Craft Spell (scripted)
 * @desc Crafts a spell for an actor from source skills, without opening the circle. For rewards and tutorials.
 *
 * @arg actorId
 * @text Actor
 * @type actor
 * @default 0
 *
 * @arg skills
 * @text Source skills
 * @type skill[]
 * @desc Every aspect these skills offer is added in order, as far as the rules allow.
 * @default []
 *
 * @arg magnitude
 * @text Magnitude (1-5)
 * @type number
 * @min 1
 * @max 5
 * @default 3
 *
 * @arg name
 * @text Name
 * @type string
 * @desc Blank = the proposed name.
 * @default
 *
 * @command unmake
 * @text Unmake Spell
 * @desc Removes crafted spells. Nothing is refunded.
 *
 * @arg actorId
 * @text Actor
 * @type actor
 * @default 0
 *
 * @arg which
 * @text Which
 * @type select
 * @option last
 * @option all
 * @desc The most recent crafted spell, or every one.
 * @default last
 *
 * @command cap
 * @text Set Aspect Cap
 * @desc How many aspects this actor may combine into one spell.
 *
 * @arg actorId
 * @text Actor
 * @type actor
 * @default 0
 *
 * @arg cap
 * @text Cap
 * @type number
 * @min 1
 * @max 6
 * @default 4
 *
 * @command lock
 * @text Lock or Unlock Aspects
 * @desc A locked skill offers no aspects until unlocked (for a library you must reach first).
 *
 * @arg skillId
 * @text Skill
 * @type skill
 * @default 0
 *
 * @arg locked
 * @text Locked
 * @type boolean
 * @default true
 *
 * @command count
 * @text Count Crafted Spells
 * @desc Stores how many crafted spells an actor holds into a variable.
 *
 * @arg actorId
 * @text Actor
 * @type actor
 * @default 0
 *
 * @arg variableId
 * @text Variable
 * @type variable
 * @default 0
 *
 * @help
 * ============================================================================
 * Spellwright - the player writes the spells
 * ============================================================================
 *
 * At a spellwright's circle the player combines the effects of spells their
 * actor already knows (up to a cap), turns a magnitude dial that drives the
 * cost, names the result, and watches its magic circle inscribe itself from
 * the composition. The new spell is a real skill: it shows in the skill list,
 * casts in battle, and saves and loads like any other.
 *
 * Needs SpellwrightCore.js installed too (either order).
 *
 * ASPECTS
 * -------
 * Every learned skill of the skill types in "Skill types that offer aspects"
 * offers aspects read from its own database entry:
 *   damage / MP damage / drain / MP drain / HP and MP recovery  (a FORM)
 *   each Add State, each Add Buff and Add Debuff, a set of Remove States
 * Tag a skill <spellwright aspect> to offer aspects from any type, and
 * <spellwright no aspect> to keep one out. Crafted spells never offer aspects.
 * Where two known spells offer the same aspect, the stronger supplies it.
 *
 * THE RULES OF A CIRCLE
 * ---------------------
 * 1  Every aspect in a circle aims at one side: foes, or allies.
 * 2  One form per spell. Two damage aspects of different elements fuse into
 *    one two-element spell (it meets the mean of the target's two rates).
 * 3  No more aspects than the cap.
 * Reach: when one source hits one target and another hits them all, the
 * spell takes the wider reach at the widening multiplier. Shift keeps the
 * narrow reach instead, at no extra cost.
 *
 * COST
 * ----
 * Each SOURCE spell's cost is counted once:
 *   ceil(sum x (1 + surcharge x (aspects - 1)) x magnitude^exponent x reach)
 * and never less than the dearest source at that magnitude, nor the minimum
 * cost. So a crafted spell is never cheaper than a spell it was made from.
 * A "Cost formula" parameter may replace the first line (JavaScript, like a
 * damage formula; variables sum n mult reach max tax); the floor still holds.
 *
 * CONTROLS IN THE CIRCLE
 * ----------------------
 * Up/Down choose · OK adds or removes an aspect · Left/Right magnitude
 * Shift narrow or wide reach · Cancel removes the last aspect, then leaves
 * Page Down cycles the proposed names · Page Up opens the Ledger
 * The last two rows of the list name the spell and inscribe it. With a
 * keyboard the player can type a name (Enter keeps it, Escape drops it).
 * Mouse and touch: click a row, the dial's halves, a socket to remove.
 *
 * SAVES
 * -----
 * A crafted spell is stored in the save as a record (the spell frozen as it
 * was made). On load each record is added to the database at its own id
 * above "First crafted skill id", and granted to its actor. The ids are never
 * written into the actor's learned list, so a save still loads cleanly if
 * the plugin is ever removed (the crafted spells just disappear).
 *
 * COMPATIBILITY
 * -------------
 * Extends, never replaces: Game_Actor.skills, Game_Action.calcElementRate,
 * DataManager.createGameObjects, DataManager.extractSaveContents,
 * BattleManager.startAction, Window_MenuCommand.addOriginalCommands,
 * Scene_Menu.createCommandWindow, Scene_Menu.onPersonalOk.
 * Adds Scene_Spellwright and Scene_SpellLedger.
 * Plugins that read skill notetags once at database load (for example
 * VisuStella Skills and States Core) do not see crafted spells' notes;
 * crafted spells carry no notetags those plugins need.
 * With Sigil Core installed, crafted spells also get Sigil Core seals in its
 * Grimoire, because they are ordinary skills.
 *
 * ============================================================================
 * Terms of use
 * ============================================================================
 * Use in commercial and non-commercial RPG Maker MZ projects. Credit CSAF.
 * Do not redistribute or resell the plugin itself.
 */

'use strict';

var Spellwright = (function () {
  const PLUGIN = 'Spellwright';
  const raw = typeof PluginManager !== 'undefined' ? PluginManager.parameters(PLUGIN) : {};

  //===========================================================================
  // The core is resolved at FIRST USE, never at load: the Plugin Manager order
  // is the buyer's choice (wing §8 trap 2).
  //===========================================================================
  let _core = null;
  let _configured = false;
  /** @returns {object} SpellwrightCore. */
  function core() {
    if (!_core) {
      _core = typeof SpellwrightCore !== 'undefined' ? SpellwrightCore : typeof window !== 'undefined' ? window.SpellwrightCore : null;
      if (!_core) throw new Error('Spellwright needs SpellwrightCore.js installed and ON in the Plugin Manager.');
    }
    if (!_configured) {
      _configured = true;
      _core.configure(readConfig());
    }
    return _core;
  }

  /** Blank is absent, never zero (wing §16). */
  function num(v, d) {
    const s = String(v === undefined || v === null ? '' : v).trim();
    if (s === '') return d;
    const n = Number(s);
    return isFinite(n) ? n : d;
  }
  /** @returns {boolean} */
  function bool(v, d) {
    const s = String(v === undefined || v === null ? '' : v).trim();
    return s === '' ? d : s === 'true';
  }
  /** Parse "A=B" lines (a note parameter arrives JSON-encoded). */
  function table(v) {
    let s = String(v === undefined || v === null ? '' : v);
    try {
      const j = JSON.parse(s);
      if (typeof j === 'string') s = j;
    } catch (e) {
      // already plain text
    }
    const out = {};
    s.split(/\r?\n/).forEach((line) => {
      const m = /^\s*([^=]+?)\s*=\s*(.+?)\s*$/.exec(line);
      if (m) out[m[1].toLowerCase()] = m[2];
    });
    return out;
  }

  function readConfig() {
    const mags = String(raw.magnitudes || '').split(',').map((x) => Number(x)).filter((x) => isFinite(x) && x > 0);
    const types = String(raw.aspectTypes === undefined ? '1' : raw.aspectTypes).split(',').map((x) => Number(x)).filter((x) => x > 0);
    const patch = {
      cap: num(raw.cap, 4),
      minCost: num(raw.minCost, 5),
      comboTax: num(raw.comboTax, 0.15),
      reachFactor: num(raw.reachFactor, 1.5),
      costExponent: num(raw.costExponent, 1.25),
      tpToMp: num(raw.tpToMp, 1),
      costFormula: String(raw.costFormula || '').trim(),
      skillType: num(raw.skillType, 1),
      idBase: num(raw.idBase, 3000),
      aspectTypes: types.length ? types : [1]
    };
    if (mags.length === 5) patch.magnitudes = mags;
    if (typeof $dataStates !== 'undefined' && $dataStates) {
      // nothing to read here yet; the death state id is MZ's own constant
    }
    const er = table(raw.elementRoots);
    const sw = table(raw.stateWords);
    if (Object.keys(er).length || Object.keys(sw).length) {
      const base = _core.config();
      patch.elementRoots = Object.assign({}, base.elementRoots, er);
      patch.stateWords = Object.assign({}, base.stateWords, sw);
    }
    return patch;
  }

  const OPT = {
    maxPerActor: num(raw.maxPerActor, 6),
    craftGold: num(raw.craftGold, 0),
    allowTyping: bool(raw.allowTyping, true),
    resultVariable: num(raw.resultVariable, 0),
    menuCommand: String(raw.menuCommand || '').trim(),
    menuSwitch: num(raw.menuSwitch, 0),
    battleSeal: bool(raw.battleSeal, true)
  };

  //===========================================================================
  // Saved data: $gameSystem._csafSpellwright = { v, records, caps, locks, next }
  //===========================================================================

  /** @returns {object} The live save block (created on first use). */
  function data() {
    const s = $gameSystem;
    if (!s._csafSpellwright || typeof s._csafSpellwright !== 'object') s._csafSpellwright = { v: 1, records: [], caps: {}, locks: {}, next: 0 };
    const d = s._csafSpellwright;
    if (!Array.isArray(d.records)) d.records = [];
    if (!d.caps || typeof d.caps !== 'object') d.caps = {};
    if (!d.locks || typeof d.locks !== 'object') d.locks = {};
    d.next = Number(d.next) || 0;
    return d;
  }

  /** Bumped whenever the crafted set changes; actors re-read their list then. */
  let version = 0;

  /** The first crafted id, read from the parameter WITHOUT the core (purge runs at New Game). */
  const ID_BASE = num(raw.idBase, 3000);

  /** @returns {object|null} The core if installed (never throws: a New Game must not crash on a missing file). */
  function coreOrNull() {
    try {
      return core();
    } catch (e) {
      return null;
    }
  }
  let warned = false;
  function warnOnce(msg) {
    if (warned) return;
    warned = true;
    if (typeof console !== 'undefined') console.warn('Spellwright: ' + msg);
  }

  /** Remove every crafted skill from $dataSkills (a new game, or before a load). Only ever touches crafted rows. */
  function purge() {
    if (typeof $dataSkills === 'undefined' || !$dataSkills) return;
    for (let i = $dataSkills.length - 1; i > 0; i--) {
      if ($dataSkills[i] && $dataSkills[i]._csafCrafted) $dataSkills[i] = null;
    }
    while ($dataSkills.length > ID_BASE + 1 && !$dataSkills[$dataSkills.length - 1]) $dataSkills.length--;
    version++;
  }

  /**
   * Add one record's skill to the database. A row the DEVELOPER owns is never
   * overwritten: if their database has grown over a crafted id, the crafted
   * spell is skipped (and named in the console) rather than clobbering it.
   * @param {object} rec Record (already read).
   * @returns {object|null} The skill, or null when its id is taken.
   */
  function inject(rec) {
    const s = rec.skill;
    const here = $dataSkills[rec.id];
    if (here && !here._csafCrafted) {
      warnOnce('skill id ' + rec.id + ' belongs to your database, so the crafted spell "' + s.name + '" was not loaded. Raise "First crafted skill id" above your last skill.');
      return null;
    }
    s._csafCrafted = true;
    if (typeof DataManager !== 'undefined' && DataManager.extractMetadata) DataManager.extractMetadata(s);
    s._csafSpellwrightEls = core().noteElements(s.note);
    $dataSkills[rec.id] = s;
    version++;
    return s;
  }

  /** Re-inject every saved record (after a load). Bad records are dropped, never guessed. */
  function injectAll() {
    purge();
    if (typeof $gameSystem === 'undefined' || !$gameSystem || !$gameSystem._csafSpellwright) return;
    const C = coreOrNull();
    if (!C) {
      warnOnce('SpellwrightCore.js is not installed, so crafted spells in this save were not loaded.');
      return;
    }
    const d = data();
    const kept = [];
    for (let i = 0; i < d.records.length; i++) {
      const r = C.readRecord(d.records[i]);
      if (!r) continue;
      kept.push(d.records[i]);
      inject(r);
    }
    d.records = kept;
  }

  /** The next free crafted id: above the base, never a row the developer owns. */
  function nextId() {
    const d = data();
    let id = ID_BASE + d.next + 1;
    while ($dataSkills[id] && !$dataSkills[id]._csafCrafted) id++;
    while ($dataSkills[id]) id++;
    d.next = id - ID_BASE;
    return id;
  }

  /** Crafted skills per actor, cached until `version` moves. */
  const cache = { v: -1, byActor: {} };
  /** @param {number} actorId Actor. @returns {object[]} Crafted skills (shared array: do not mutate). */
  function craftedFor(actorId) {
    if (typeof $gameSystem === 'undefined' || !$gameSystem || !$gameSystem._csafSpellwright) return EMPTY;
    if (cache.v !== version) {
      cache.v = version;
      cache.byActor = {};
      const recs = $gameSystem._csafSpellwright.records || [];
      for (let i = 0; i < recs.length; i++) {
        const r = recs[i];
        const s = $dataSkills[r.id];
        if (!s || !s._csafCrafted) continue;
        (cache.byActor[r.actorId] = cache.byActor[r.actorId] || []).push(s);
      }
    }
    return cache.byActor[actorId] || EMPTY;
  }
  const EMPTY = [];

  /** Seals of saved spells, built once from the record's seal spec. */
  const sealCache = new Map();
  /** @param {number} skillId Crafted skill id. @returns {object|null} Its seal, exactly as the circle drew it. */
  function sealOf(skillId) {
    const id = Number(skillId);
    const recs = typeof $gameSystem !== 'undefined' && $gameSystem && $gameSystem._csafSpellwright ? $gameSystem._csafSpellwright.records : EMPTY;
    let rec = null;
    for (let i = 0; i < recs.length; i++) if (recs[i].id === id) rec = recs[i];
    if (!rec || !rec.seal) return null;
    const key = id + '|' + rec.seal.keys.join(',') + '|' + rec.seal.magIndex + '|' + rec.seal.cost;
    let s = sealCache.get(key);
    if (!s) {
      s = core().buildSeal(rec.seal);
      sealCache.set(key, s);
    }
    return s;
  }

  /** @param {number} actorId 0 = leader. @returns {Game_Actor|null} */
  function actorOf(actorId) {
    const id = Number(actorId) || 0;
    if (id > 0) return $gameActors.actor(id);
    return $gameParty.leader() || null;
  }

  /** Naming context over the buyer's own database. */
  const NAMES = {
    elementName: (id) => ($dataSystem && $dataSystem.elements[id]) || '',
    stateName: (id) => ($dataStates && $dataStates[id] ? $dataStates[id].name : ''),
    paramName: (id) => (typeof TextManager !== 'undefined' ? TextManager.param(id) : 'param ' + id)
  };

  /** @param {Game_Actor} actor Actor. @returns {number} Aspect cap for that actor. */
  function capFor(actor) {
    const d = data();
    const c = Number(d.caps[actor.actorId()]);
    return c > 0 ? c : core().config().cap;
  }

  /** @param {Game_Actor} actor Actor. @returns {object[]} Aspects the actor can draw on now. */
  function aspectsFor(actor) {
    const known = actor.skills().filter((s) => s && !s._csafCrafted);
    return core().gatherAspects(known, null, data().locks);
  }

  /**
   * Inscribe a composition as a new spell for an actor.
   * @param {Game_Actor} actor Crafter.
   * @param {object} comp Composition.
   * @param {string} name Name (cleaned and made unique here).
   * @returns {{ok:boolean, reason?:string, skill?:object}} Result.
   */
  function inscribe(actor, comp, name) {
    const C = core();
    if (!comp) return { ok: false, reason: 'empty' };
    const d = data();
    const mine = craftedFor(actor.actorId());
    if (mine.length >= OPT.maxPerActor) return { ok: false, reason: 'ledgerFull' };
    if (OPT.craftGold > 0 && $gameParty.gold() < OPT.craftGold) return { ok: false, reason: 'gold' };
    const clean = C.cleanName(name) || C.proposeName(comp, NAMES);
    const finalName = C.uniqueName(clean, mine.map((s) => s.name));
    const id = nextId();
    const skill = C.toSkill(comp, finalName, id, NAMES);
    const rec = C.makeRecord(skill, actor.actorId(), comp);
    d.records.push(rec);
    inject(C.readRecord(rec));
    if (OPT.craftGold > 0) $gameParty.loseGold(OPT.craftGold);
    if (OPT.resultVariable > 0) $gameVariables.setValue(OPT.resultVariable, id);
    actor.refresh();
    return { ok: true, skill: $dataSkills[id] };
  }

  /**
   * Remove crafted spells.
   * @param {Game_Actor} actor Actor.
   * @param {string|number} which 'last' | 'all' | a skill id.
   * @returns {number} How many were removed.
   */
  function unmake(actor, which) {
    const d = data();
    const aid = actor.actorId();
    const mine = d.records.filter((r) => r.actorId === aid);
    let drop;
    if (which === 'all') drop = mine;
    else if (which === 'last') drop = mine.length ? [mine[mine.length - 1]] : [];
    else drop = mine.filter((r) => r.id === Number(which));
    for (let i = 0; i < drop.length; i++) {
      const r = drop[i];
      d.records.splice(d.records.indexOf(r), 1);
      if ($dataSkills[r.id] && $dataSkills[r.id]._csafCrafted) $dataSkills[r.id] = null;
    }
    version++;
    actor.refresh();
    return drop.length;
  }

  //===========================================================================
  // Engine extensions (saved originals, always called)
  //===========================================================================

  if (typeof Game_Actor !== 'undefined') {
    const _skills = Game_Actor.prototype.skills;
    Game_Actor.prototype.skills = function () {
      const list = _skills.call(this);
      const extra = craftedFor(this.actorId());
      for (let i = 0; i < extra.length; i++) if (list.indexOf(extra[i]) < 0) list.push(extra[i]);
      return list;
    };

    const _calcElementRate = Game_Action.prototype.calcElementRate;
    Game_Action.prototype.calcElementRate = function (target) {
      const item = this.item();
      const els = item && item._csafSpellwrightEls;
      if (els && els.length > 1) {
        const rates = [];
        for (let i = 0; i < els.length; i++) rates.push(target.elementRate(els[i]));
        return core().blendRates(rates);
      }
      return _calcElementRate.call(this, target);
    };

    const _createGameObjects = DataManager.createGameObjects;
    DataManager.createGameObjects = function () {
      _createGameObjects.call(this);
      purge();
    };

    const _extractSaveContents = DataManager.extractSaveContents;
    DataManager.extractSaveContents = function (contents) {
      _extractSaveContents.call(this, contents);
      injectAll();
    };

    const _startAction = BattleManager.startAction;
    BattleManager.startAction = function () {
      _startAction.call(this);
      const item = this._action && this._action.item();
      if (OPT.battleSeal && item && item._csafCrafted) {
        const sc = SceneManager._scene;
        if (sc && sc._spriteset && sc._spriteset.csafSpellwrightFlash) sc._spriteset.csafSpellwrightFlash(item);
      }
    };
  }

  //===========================================================================
  // Drawing helpers shared by the scenes (all on a Bitmap's own context)
  //===========================================================================

  const SERIF = '"Palatino Linotype", "Book Antiqua", Palatino, Georgia, "Times New Roman", serif';
  const INK = '#e9dcc0';
  const DIM = '#9b8f78';
  const BRASS = '#c9a35c';
  const BRASS_DARK = '#6e5426';
  const TAU = Math.PI * 2;

  /** Mark a bitmap's texture for upload after drawing on its context directly. */
  function touch(bmp) {
    if (bmp._baseTexture && bmp._baseTexture.update) bmp._baseTexture.update();
  }

  /**
   * Empty a bitmap's canvas WITHOUT marking the texture: Bitmap.clear() would
   * mark it too, and the redraw that follows marks it again (two uploads where
   * one is needed). Every redraw here is wipe, draw, touch.
   */
  function wipe(bmp) {
    bmp.context.clearRect(0, 0, bmp.width, bmp.height);
  }

  /**
   * The slate the circle is chalked on: a cool dark gradient, mottled, grained,
   * vignetted, and framed by an engraved double rule. Drawn once.
   * @param {Bitmap} bmp Full-screen bitmap.
   * @param {number} seed Mottle seed.
   */
  function drawSlate(bmp, seed) {
    const g = bmp.context;
    const w = bmp.width;
    const h = bmp.height;
    const gr = g.createRadialGradient(w * 0.36, h * 0.46, 40, w * 0.5, h * 0.5, w * 0.8);
    gr.addColorStop(0, '#232030');
    gr.addColorStop(0.55, '#15131d');
    gr.addColorStop(1, '#08070b');
    g.fillStyle = gr;
    g.fillRect(0, 0, w, h);
    const rng = new (core().Rng)(seed >>> 0);
    for (let i = 0; i < 90; i++) {
      const x = rng.next() * w;
      const y = rng.next() * h;
      const r = 20 + rng.next() * 90;
      const m = g.createRadialGradient(x, y, 0, x, y, r);
      const a = 0.02 + rng.next() * 0.04;
      m.addColorStop(0, rng.next() < 0.5 ? 'rgba(120,110,150,' + a + ')' : 'rgba(0,0,0,' + a * 1.5 + ')');
      m.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = m;
      g.fillRect(x - r, y - r, r * 2, r * 2);
    }
    for (let i = 0; i < 2600; i++) {
      g.fillStyle = rng.next() < 0.5 ? 'rgba(255,255,255,0.035)' : 'rgba(0,0,0,0.09)';
      g.fillRect(rng.next() * w, rng.next() * h, 1, 1);
    }
    const v = g.createRadialGradient(w / 2, h / 2, h * 0.35, w / 2, h / 2, w * 0.72);
    v.addColorStop(0, 'rgba(0,0,0,0)');
    v.addColorStop(1, 'rgba(0,0,0,0.55)');
    g.fillStyle = v;
    g.fillRect(0, 0, w, h);
    g.strokeStyle = 'rgba(201,163,92,0.55)';
    g.lineWidth = 1.5;
    g.strokeRect(10.5, 10.5, w - 21, h - 21);
    g.strokeStyle = 'rgba(201,163,92,0.25)';
    g.lineWidth = 1;
    g.strokeRect(16.5, 16.5, w - 33, h - 33);
    const corner = (x, y, sx, sy) => {
      g.strokeStyle = 'rgba(201,163,92,0.7)';
      g.lineWidth = 1.2;
      g.beginPath();
      g.moveTo(x + sx * 4, y + sy * 26);
      g.lineTo(x + sx * 4, y + sy * 4);
      g.lineTo(x + sx * 26, y + sy * 4);
      g.stroke();
      g.beginPath();
      g.arc(x + sx * 10, y + sy * 10, 3, 0, TAU);
      g.stroke();
    };
    corner(10, 10, 1, 1);
    corner(w - 10, 10, -1, 1);
    corner(10, h - 10, 1, -1);
    corner(w - 10, h - 10, -1, -1);
    touch(bmp);
  }

  /**
   * Letter text with a soft engraved shadow.
   * @param {CanvasRenderingContext2D} g Context.
   * @param {string} s Text.
   * @param {number} x X.
   * @param {number} y Baseline y.
   * @param {object} o {size, italic, colour, align, alpha, spacing, maxWidth}.
   */
  function letter(g, s, x, y, o) {
    g.save();
    g.font = (o.italic ? 'italic ' : '') + (o.bold ? 'bold ' : '') + (o.size || 18) + 'px ' + SERIF;
    g.textAlign = o.align || 'left';
    g.textBaseline = 'alphabetic';
    g.globalAlpha = o.alpha === undefined ? 1 : o.alpha;
    if (o.spacing) {
      try { g.letterSpacing = o.spacing + 'px'; } catch (e) { /* older engines */ }
    }
    g.fillStyle = 'rgba(0,0,0,0.6)';
    if (o.maxWidth) g.fillText(s, x + 1, y + 1.5, o.maxWidth);
    else g.fillText(s, x + 1, y + 1.5);
    g.fillStyle = o.colour || INK;
    if (o.maxWidth) g.fillText(s, x, y, o.maxWidth);
    else g.fillText(s, x, y);
    g.restore();
  }

  /** A short human label for an aspect, with its reach when it reaches everyone. */
  function aspectLabel(a) {
    return aspectBase(a) + (a.width >= 3 ? ', all' : '');
  }

  function aspectBase(a) {
    const C = core();
    const el = a.elementId ? NAMES.elementName(a.elementId) : 'Arcane';
    switch (a.kind) {
      case C.KIND.HARM: return el + ' harm';
      case C.KIND.SAP: return el + ' MP harm';
      case C.KIND.DRAIN: return el + ' drain';
      case C.KIND.SIPHON: return 'MP siphon';
      case C.KIND.MEND: return 'Restore HP';
      case C.KIND.RENEW: return 'Restore MP';
      case C.KIND.INFLICT: return NAMES.stateName(a.stateId) + ' ' + Math.round(a.chance * 100) + '%';
      case C.KIND.BLESS: return NAMES.paramName(a.paramId) + ' up';
      case C.KIND.CURSE: return NAMES.paramName(a.paramId) + ' down';
      case C.KIND.CLEANSE: return 'Cure ' + a.states.length + (a.states.length === 1 ? ' ailment' : ' ailments');
      default: return a.key;
    }
  }

  /**
   * An aspect token: an engraved disc in the element's colours carrying the
   * aspect's own glyph (a form's core figure, a rider's band glyph).
   * @param {CanvasRenderingContext2D} g Context.
   * @param {object} a Aspect.
   * @param {number} x Centre x.
   * @param {number} y Centre y.
   * @param {number} r Radius.
   * @param {number} dim 0..1 (1 = full).
   */
  function drawToken(g, a, x, y, r, dim) {
    const C = core();
    const pal = C.paletteFor(a.elementId || 0);
    const form = C.isForm(a);
    g.save();
    g.globalAlpha = 0.35 + 0.65 * dim;
    const disc = g.createRadialGradient(x - r * 0.3, y - r * 0.35, r * 0.1, x, y, r);
    disc.addColorStop(0, form ? pal.glow : '#7a6a4a');
    disc.addColorStop(0.75, form ? '#1a1424' : '#231c14');
    disc.addColorStop(1, '#0b0910');
    g.fillStyle = disc;
    g.beginPath();
    g.arc(x, y, r, 0, TAU);
    g.fill();
    g.lineWidth = 1.6;
    g.strokeStyle = a.side === 'foe' ? 'rgba(232,120,90,0.9)' : 'rgba(130,214,160,0.9)';
    g.stroke();
    g.lineWidth = 0.8;
    g.strokeStyle = 'rgba(255,240,210,0.35)';
    g.beginPath();
    g.arc(x, y, r - 3, 0, TAU);
    g.stroke();
    g.strokeStyle = form ? pal.ink : '#f0deb4';
    g.fillStyle = g.strokeStyle;
    g.lineWidth = 1.5;
    g.lineCap = 'round';
    g.lineJoin = 'round';
    g.beginPath();
    const k = r * 0.55;
    if (a.kind === C.KIND.HARM || a.kind === C.KIND.SAP) {
      const n = a.kind === C.KIND.SAP ? 7 : 5;
      const sk = a.kind === C.KIND.SAP ? 3 : 2;
      for (let i = 0; i <= n; i++) {
        const t = -Math.PI / 2 + (i * sk * TAU) / n;
        if (i === 0) g.moveTo(x + Math.cos(t) * k, y + Math.sin(t) * k);
        else g.lineTo(x + Math.cos(t) * k, y + Math.sin(t) * k);
      }
      g.stroke();
    } else if (a.kind === C.KIND.DRAIN || a.kind === C.KIND.SIPHON) {
      for (let s = 0; s < 3; s++) {
        g.beginPath();
        for (let i = 0; i <= 12; i++) {
          const q = i / 12;
          const t = (s * TAU) / 3 + q * Math.PI;
          const rr = k * (1 - 0.65 * q);
          if (i === 0) g.moveTo(x + Math.cos(t) * rr, y + Math.sin(t) * rr);
          else g.lineTo(x + Math.cos(t) * rr, y + Math.sin(t) * rr);
        }
        g.stroke();
      }
    } else if (a.kind === C.KIND.MEND || a.kind === C.KIND.RENEW) {
      for (let s = 0; s < 6; s++) {
        const t = (s * TAU) / 6;
        g.beginPath();
        g.arc(x + Math.cos(t) * k * 0.45, y + Math.sin(t) * k * 0.45, k * 0.45, 0, TAU);
        g.stroke();
      }
    } else {
      const s = C.riderGlyph(a);
      const sz = r * 1.15;
      for (let i = 0; i < s.length; i += 4) {
        g.moveTo(x + s[i] * sz, y + s[i + 1] * sz);
        g.lineTo(x + s[i + 2] * sz, y + s[i + 3] * sz);
      }
      g.stroke();
    }
    g.restore();
  }

  //===========================================================================
  // Scene_Spellwright: the crafting circle
  //===========================================================================

  const REASONS = {
    full: 'The circle holds no more aspects',
    side: 'A circle aims at foes or at allies, never both',
    form: 'A spell takes one form; only two harms of different elements fuse',
    sameElement: 'Two harms of one element add nothing',
    elements: 'No more than two elements fuse',
    duplicate: '',
    empty: 'Place an aspect in the circle first',
    ledgerFull: 'This spellwright’s ledger is full',
    gold: 'Not enough gold to inscribe'
  };

  const LAYOUT = { cx: 292, cy: 296, ringR: 206, sealR: 150, panelX: 560, panelY: 26, panelW: 232, rowH: 46, rowsTop: 74, visibleRows: 10 };
  const MSG = { x: 338, y: 24, w: 214, h: 46 };

  class Scene_Spellwright extends Scene_Base {
    /**
     * @param {number} actorId Actor (0 = leader).
     */
    prepare(actorId) {
      this._actorId = Number(actorId) || 0;
    }

    create() {
      super.create();
      const C = core();
      this._actor = actorOf(this._actorId || 0);
      this._cap = this._actor ? capFor(this._actor) : C.config().cap;
      this._aspects = this._actor ? aspectsFor(this._actor) : [];
      this._chosen = [];
      this._mag = C.config().defaultMagnitude;
      this._narrow = false;
      this._variant = 0;
      this._typed = null; // a typed name, or null for the proposal
      this._typing = false;
      this._cursor = 0;
      this._scroll = 0;
      this._comp = null;
      this._seal = null;
      this._sealProgress = 1;
      this._doneKeys = {};
      this._flare = 0;
      this._msgTimer = 0;
      this._cooldown = 0;
      this._frame = 0;
      this._paintOpts = { glow: 1, doneKeys: null, lineScale: 1 };
      this._inscribed = 0;
      this.createLayers();
      this.recompose(false);
      this.refreshPanel();
      this.refreshDial();
      this.refreshRibbon();
      this.refreshHeader();
      this._onKey = this.onKeyDown.bind(this);
      if (typeof document !== 'undefined') document.addEventListener('keydown', this._onKey);
    }

    start() {
      super.start();
      this.startFadeIn(this.fadeSpeed(), false);
    }

    createLayers() {
      const W = Graphics.width;
      const H = Graphics.height;
      this._bgSprite = new Sprite(new Bitmap(W, H));
      drawSlate(this._bgSprite.bitmap, 0x5eed + (this._actor ? this._actor.actorId() : 0));
      this.addChild(this._bgSprite);
      const D = LAYOUT.ringR * 2 + 40;
      this._ringSprite = new Sprite(new Bitmap(D, D));
      this._ringSprite.anchor.set(0.5, 0.5);
      this._ringSprite.move(LAYOUT.cx, LAYOUT.cy);
      this.drawOuterRing(this._ringSprite.bitmap);
      this.addChild(this._ringSprite);
      this._socketSprite = new Sprite(new Bitmap(D, D));
      this._socketSprite.anchor.set(0.5, 0.5);
      this._socketSprite.move(LAYOUT.cx, LAYOUT.cy);
      this.addChild(this._socketSprite);
      const S = LAYOUT.sealR * 2 + 60;
      this._sealBitmap = new Bitmap(S, S);
      this._sealSprite = new Sprite(this._sealBitmap);
      this._sealSprite.anchor.set(0.5, 0.5);
      this._sealSprite.move(LAYOUT.cx, LAYOUT.cy);
      this._sealGlow = new Sprite(this._sealBitmap);
      this._sealGlow.anchor.set(0.5, 0.5);
      this._sealGlow.move(LAYOUT.cx, LAYOUT.cy);
      this._sealGlow.blendMode = PIXI.BLEND_MODES.ADD;
      this._sealGlow.opacity = 60;
      this.addChild(this._sealGlow);
      this.addChild(this._sealSprite);
      this._burst = new Sprite(new Bitmap(S, S));
      this._burst.anchor.set(0.5, 0.5);
      this._burst.move(LAYOUT.cx, LAYOUT.cy);
      this._burst.blendMode = PIXI.BLEND_MODES.ADD;
      this._burst.opacity = 0;
      this.addChild(this._burst);
      this._panelSprite = new Sprite(new Bitmap(LAYOUT.panelW, Graphics.height - LAYOUT.panelY * 2));
      this._panelSprite.move(LAYOUT.panelX, LAYOUT.panelY);
      this.addChild(this._panelSprite);
      this._hiSprite = new Sprite(new Bitmap(LAYOUT.panelW, LAYOUT.rowH));
      this.drawHighlight(this._hiSprite.bitmap);
      this._hiSprite.x = LAYOUT.panelX;
      this.addChild(this._hiSprite);
      this._dialSprite = new Sprite(new Bitmap(300, 112));
      this._dialSprite.move(22, 504);
      this.addChild(this._dialSprite);
      this._needle = new Sprite(new Bitmap(8, 64));
      this._needle.anchor.set(0.5, 0.92);
      this._needle.move(22 + 82, 504 + 92);
      this.drawNeedle(this._needle.bitmap);
      this.addChild(this._needle);
      this._needleAngle = this.needleTarget();
      this._needle.rotation = this._needleAngle;
      this._ribbonSprite = new Sprite(new Bitmap(236, 104));
      this._ribbonSprite.move(318, 508);
      this.addChild(this._ribbonSprite);
      this._headerSprite = new Sprite(new Bitmap(300, 64));
      this._headerSprite.move(22, 20);
      this.addChild(this._headerSprite);
      // messages live in the clear corner right of the title, above the ring's
      // shoulder, where nothing else is ever drawn (two lines, wrapped)
      this._msgSprite = new Sprite(new Bitmap(MSG.w, MSG.h));
      this._msgSprite.move(MSG.x, MSG.y);
      this._msgSprite.opacity = 0;
      this.addChild(this._msgSprite);
    }

    /** The brass ring with its engraved scale; rotates slowly as a sprite. */
    drawOuterRing(bmp) {
      const g = bmp.context;
      const c = bmp.width / 2;
      const R = LAYOUT.ringR;
      g.save();
      g.translate(c, c);
      const band = g.createRadialGradient(0, 0, R - 18, 0, 0, R + 6);
      band.addColorStop(0, 'rgba(110,84,38,0)');
      band.addColorStop(0.55, 'rgba(110,84,38,0.55)');
      band.addColorStop(0.8, 'rgba(201,163,92,0.75)');
      band.addColorStop(1, 'rgba(60,44,20,0.0)');
      g.fillStyle = band;
      g.beginPath();
      g.arc(0, 0, R + 6, 0, TAU);
      g.arc(0, 0, R - 18, 0, TAU, true);
      g.fill();
      g.strokeStyle = BRASS;
      g.lineWidth = 1.4;
      g.beginPath(); g.arc(0, 0, R, 0, TAU); g.stroke();
      g.strokeStyle = 'rgba(201,163,92,0.6)';
      g.lineWidth = 1;
      g.beginPath(); g.arc(0, 0, R - 14, 0, TAU); g.stroke();
      for (let i = 0; i < 120; i++) {
        const a = (i * TAU) / 120;
        const long = i % 10 === 0;
        const r0 = R - (long ? 12 : 6);
        g.strokeStyle = long ? 'rgba(240,214,160,0.85)' : 'rgba(201,163,92,0.55)';
        g.lineWidth = long ? 1.3 : 0.8;
        g.beginPath();
        g.moveTo(Math.cos(a) * r0, Math.sin(a) * r0);
        g.lineTo(Math.cos(a) * (R - 1), Math.sin(a) * (R - 1));
        g.stroke();
      }
      // a chalked inner guide circle and a faint compass rose the seal sits on
      g.strokeStyle = 'rgba(220,210,255,0.10)';
      g.lineWidth = 1;
      g.setLineDash([3, 6]);
      g.beginPath(); g.arc(0, 0, LAYOUT.sealR + 22, 0, TAU); g.stroke();
      g.setLineDash([]);
      for (let i = 0; i < 8; i++) {
        const a = (i * TAU) / 8;
        g.beginPath();
        g.moveTo(Math.cos(a) * (LAYOUT.sealR + 26), Math.sin(a) * (LAYOUT.sealR + 26));
        g.lineTo(Math.cos(a) * (R - 22), Math.sin(a) * (R - 22));
        g.strokeStyle = 'rgba(201,163,92,0.18)';
        g.stroke();
      }
      g.restore();
      touch(bmp);
    }

    /** Socket positions round the ring, one per cap slot, starting at the top. */
    socketPos(i) {
      const a = -Math.PI / 2 + (i * TAU) / this._cap;
      const r = LAYOUT.ringR - 4;
      return { x: Math.cos(a) * r, y: Math.sin(a) * r };
    }

    /** Sockets: brass cups round the ring, filled ones carry the aspect's token. */
    refreshSockets() {
      const bmp = this._socketSprite.bitmap;
      wipe(bmp);
      const g = bmp.context;
      const c = bmp.width / 2;
      for (let i = 0; i < this._cap; i++) {
        const p = this.socketPos(i);
        const x = c + p.x;
        const y = c + p.y;
        g.save();
        const cup = g.createRadialGradient(x, y - 4, 2, x, y, 22);
        cup.addColorStop(0, '#3a2c18');
        cup.addColorStop(1, '#120d07');
        g.fillStyle = cup;
        g.beginPath(); g.arc(x, y, 21, 0, TAU); g.fill();
        g.strokeStyle = BRASS; g.lineWidth = 2;
        g.beginPath(); g.arc(x, y, 21, 0, TAU); g.stroke();
        g.strokeStyle = BRASS_DARK; g.lineWidth = 1;
        g.beginPath(); g.arc(x, y, 24.5, 0, TAU); g.stroke();
        g.restore();
        const a = this._chosen[i];
        if (a) drawToken(g, a, x, y, 17, 1);
        else {
          g.save();
          g.fillStyle = 'rgba(201,163,92,0.35)';
          g.beginPath(); g.arc(x, y, 2.2, 0, TAU); g.fill();
          g.restore();
        }
      }
      touch(bmp);
    }

    drawHighlight(bmp) {
      const g = bmp.context;
      const w = bmp.width;
      const h = bmp.height;
      const gr = g.createLinearGradient(0, 0, w, 0);
      gr.addColorStop(0, 'rgba(201,163,92,0.0)');
      gr.addColorStop(0.15, 'rgba(201,163,92,0.16)');
      gr.addColorStop(1, 'rgba(201,163,92,0.04)');
      g.fillStyle = gr;
      g.fillRect(0, 2, w, h - 4);
      g.strokeStyle = 'rgba(240,214,160,0.9)';
      g.lineWidth = 1.4;
      g.beginPath();
      g.moveTo(10, 6); g.lineTo(4, 6); g.lineTo(4, h - 6); g.lineTo(10, h - 6);
      g.moveTo(w - 10, 6); g.lineTo(w - 4, 6); g.lineTo(w - 4, h - 6); g.lineTo(w - 10, h - 6);
      g.stroke();
      touch(bmp);
    }

    drawNeedle(bmp) {
      const g = bmp.context;
      g.fillStyle = '#f0d9a0';
      g.beginPath();
      g.moveTo(4, 0); g.lineTo(7, 58); g.lineTo(4, 63); g.lineTo(1, 58); g.closePath();
      g.fill();
      g.strokeStyle = 'rgba(60,40,10,0.8)';
      g.lineWidth = 0.8;
      g.stroke();
      touch(bmp);
    }

    /** The rows: every aspect, then "Name" and "Inscribe". */
    rowCount() {
      return this._aspects.length + 2;
    }

    refreshPanel() {
      const C = core();
      const bmp = this._panelSprite.bitmap;
      wipe(bmp);
      const g = bmp.context;
      const w = bmp.width;
      const h = bmp.height;
      g.save();
      const back = g.createLinearGradient(0, 0, 0, h);
      back.addColorStop(0, 'rgba(18,15,24,0.82)');
      back.addColorStop(1, 'rgba(10,8,14,0.9)');
      g.fillStyle = back;
      g.fillRect(0, 0, w, h);
      g.strokeStyle = 'rgba(201,163,92,0.55)';
      g.lineWidth = 1;
      g.strokeRect(0.5, 0.5, w - 1, h - 1);
      g.restore();
      letter(g, 'ASPECTS', w / 2, 30, { size: 17, colour: BRASS, align: 'center', spacing: 4 });
      letter(g, this._aspects.length + ' from ' + (this._actor ? this._actor.name() : '') + '’s spells', w / 2, 50, { size: 12, italic: true, colour: DIM, align: 'center', maxWidth: w - 20 });
      g.strokeStyle = 'rgba(201,163,92,0.35)';
      g.beginPath(); g.moveTo(16, 60); g.lineTo(w - 16, 60); g.stroke();
      const rows = this.rowCount();
      const vis = LAYOUT.visibleRows;
      for (let v = 0; v < vis && this._scroll + v < rows; v++) {
        const i = this._scroll + v;
        const y = LAYOUT.rowsTop - LAYOUT.panelY + v * LAYOUT.rowH + 24 + 36;
        const top = y - 24;
        if (i < this._aspects.length) {
          const a = this._aspects[i];
          const inCircle = this._chosen.indexOf(a) >= 0;
          const ok = inCircle || C.canAdd(this._chosen, a, this._cap).ok;
          drawToken(g, a, 30, top + 22, 16, ok ? 1 : 0.35);
          letter(g, aspectLabel(a), 54, top + 20, { size: 15, colour: inCircle ? '#ffe7a8' : ok ? INK : '#6d6457', maxWidth: w - 64 });
          letter(g, 'from ' + a.sourceName + '  ·  ' + a.cost + ' MP', 54, top + 37, { size: 11, italic: true, colour: ok ? DIM : '#4f4940', maxWidth: w - 64 });
          if (inCircle) {
            g.save(); g.fillStyle = '#ffe7a8'; g.beginPath(); g.arc(w - 14, top + 22, 3, 0, TAU); g.fill(); g.restore();
          }
        } else {
          const nameRow = i === this._aspects.length;
          g.save();
          g.strokeStyle = 'rgba(201,163,92,0.45)';
          g.beginPath(); g.moveTo(20, top + 3); g.lineTo(w - 20, top + 3); g.stroke();
          g.restore();
          letter(g, nameRow ? 'Name the spell' : 'Inscribe', w / 2, top + 29, { size: nameRow ? 16 : 18, italic: nameRow, colour: this._comp ? (nameRow ? INK : '#ffe7a8') : '#6d6457', align: 'center', spacing: nameRow ? 0 : 3 });
        }
      }
      if (this._scroll > 0) letter(g, '▲', w / 2, 70, { size: 10, colour: DIM, align: 'center' });
      if (this._scroll + vis < rows) letter(g, '▼', w / 2, h - 6, { size: 10, colour: DIM, align: 'center' });
      touch(bmp);
      this.placeHighlight();
    }

    placeHighlight() {
      const v = this._cursor - this._scroll;
      this._hiSprite.y = LAYOUT.rowsTop + 36 + v * LAYOUT.rowH;
      this._hiSprite.visible = v >= 0 && v < LAYOUT.visibleRows;
    }

    needleTarget() {
      const n = core().config().magnitudes.length;
      return -1.1 + (2.2 * this._mag) / (n - 1);
    }

    refreshDial() {
      const C = core();
      const bmp = this._dialSprite.bitmap;
      wipe(bmp);
      const g = bmp.context;
      const cx = 82;
      const cy = 92;
      g.save();
      const plate = g.createLinearGradient(0, 0, 0, 112);
      plate.addColorStop(0, 'rgba(40,30,16,0.85)');
      plate.addColorStop(1, 'rgba(14,10,6,0.9)');
      g.fillStyle = plate;
      g.beginPath();
      g.moveTo(4, 110); g.lineTo(4, 30); g.quadraticCurveTo(4, 6, 28, 6); g.lineTo(296, 6); g.lineTo(296, 110); g.closePath();
      g.fill();
      g.strokeStyle = 'rgba(201,163,92,0.6)';
      g.lineWidth = 1;
      g.stroke();
      // the dial arc with five notches
      const mags = C.config().magnitudes;
      g.strokeStyle = BRASS; g.lineWidth = 3;
      g.beginPath(); g.arc(cx, cy, 62, -Math.PI / 2 - 1.18, -Math.PI / 2 + 1.18); g.stroke();
      for (let i = 0; i < mags.length; i++) {
        const a = -Math.PI / 2 - 1.1 + (2.2 * i) / (mags.length - 1);
        const on = i === this._mag;
        g.strokeStyle = on ? '#ffe7a8' : 'rgba(201,163,92,0.7)';
        g.lineWidth = on ? 2.4 : 1.4;
        g.beginPath();
        g.moveTo(cx + Math.cos(a) * 54, cy + Math.sin(a) * 54);
        g.lineTo(cx + Math.cos(a) * 70, cy + Math.sin(a) * 70);
        g.stroke();
      }
      g.fillStyle = '#2a2014';
      g.beginPath(); g.arc(cx, cy, 9, 0, TAU); g.fill();
      g.strokeStyle = BRASS; g.lineWidth = 1.5; g.stroke();
      g.restore();
      const words = C.config().intensityWords;
      letter(g, 'MAGNITUDE', cx, 20, { size: 11, colour: DIM, align: 'center', spacing: 3 });
      // the reading sits either side of the pivot, clear of the needle's sweep
      letter(g, words[this._mag] || 'True', cx - 14, 104, { size: 13, italic: true, colour: INK, align: 'right' });
      letter(g, '×' + mags[this._mag], cx + 14, 104, { size: 13, colour: '#ffe7a8', align: 'left' });
      // the cost gauge: a vial filled to the cost, the floor marked on it
      const gx = 168;
      const gw = 116;
      letter(g, 'COST', gx + gw / 2, 20, { size: 11, colour: DIM, align: 'center', spacing: 3 });
      const comp = this._comp;
      const cost = comp ? comp.cost : 0;
      const maxMp = this._actor ? Math.max(1, this._actor.mmp) : 100;
      g.save();
      g.strokeStyle = 'rgba(201,163,92,0.7)'; g.lineWidth = 1.2;
      g.strokeRect(gx + 0.5, 64.5, gw, 12);
      const fill = Math.min(1, cost / maxMp);
      const vial = g.createLinearGradient(gx, 0, gx + gw, 0);
      vial.addColorStop(0, '#2a62ff');
      vial.addColorStop(1, fill >= 1 ? '#ff5a3c' : '#8fd2ff');
      g.fillStyle = vial;
      g.fillRect(gx + 2, 66, (gw - 3) * fill, 9);
      if (comp) {
        const fx = gx + 2 + (gw - 3) * Math.min(1, comp.costFloor / maxMp);
        g.strokeStyle = '#ffe7a8'; g.lineWidth = 1.5;
        g.beginPath(); g.moveTo(fx, 60); g.lineTo(fx, 81); g.stroke();
      }
      g.restore();
      letter(g, comp ? String(cost) : '—', gx + gw / 2 - 6, 56, { size: 30, colour: comp ? '#dff1ff' : '#6d6457', align: 'right' });
      letter(g, 'MP', gx + gw / 2, 56, { size: 13, colour: DIM });
      if (comp) {
        const reach = comp.mixedReach ? (comp.narrow ? 'narrow reach (Shift)' : 'widened ×' + C.config().reachFactor + ' (Shift)') : comp.width >= 3 ? 'reaches all' : comp.width === 1 ? 'random reach' : 'one target';
        letter(g, 'floor ' + comp.costFloor + '  ·  ' + reach, gx + gw / 2, 98, { size: 10.5, italic: true, colour: DIM, align: 'center', maxWidth: gw + 12 });
      }
      touch(bmp);
    }

    currentName() {
      if (!this._comp) return '';
      if (this._typed !== null) return this._typed;
      return core().proposeName(this._comp, NAMES, this._variant);
    }

    refreshRibbon() {
      const bmp = this._ribbonSprite.bitmap;
      wipe(bmp);
      const g = bmp.context;
      const w = bmp.width;
      g.save();
      // a ribbon with swallowtail ends
      const y0 = 30;
      const y1 = 74;
      const rib = g.createLinearGradient(0, y0, 0, y1);
      rib.addColorStop(0, '#5a1820');
      rib.addColorStop(0.5, '#7a2330');
      rib.addColorStop(1, '#3e0f16');
      g.fillStyle = rib;
      g.beginPath();
      g.moveTo(4, y0); g.lineTo(w - 4, y0); g.lineTo(w - 22, (y0 + y1) / 2); g.lineTo(w - 4, y1); g.lineTo(4, y1); g.lineTo(22, (y0 + y1) / 2); g.closePath();
      g.fill();
      g.strokeStyle = 'rgba(240,200,140,0.55)'; g.lineWidth = 1;
      g.beginPath(); g.moveTo(26, y0 + 4); g.lineTo(w - 26, y0 + 4); g.moveTo(26, y1 - 4); g.lineTo(w - 26, y1 - 4); g.stroke();
      g.restore();
      letter(g, this._typing ? 'TYPE A NAME  ·  Enter keeps it' : this._comp ? 'PROPOSED NAME  ·  Page Down for another' : 'THE NAME APPEARS HERE', w / 2, 22, { size: 10, colour: DIM, align: 'center', spacing: 1.5, maxWidth: w - 8 });
      const nm = this.currentName();
      const show = this._typing ? (this._typed || '') + ((this._frame >> 4) % 2 ? '|' : ' ') : nm;
      letter(g, show || '…', w / 2, 59, { size: show.length > 18 ? 16 : 20, italic: true, colour: '#fbe6c2', align: 'center', maxWidth: w - 52 });
      if (this._comp) letter(g, core().describe(this._comp, NAMES), w / 2, 96, { size: 11, italic: true, colour: DIM, align: 'center', maxWidth: w });
      touch(bmp);
    }

    refreshHeader() {
      const bmp = this._headerSprite.bitmap;
      wipe(bmp);
      const g = bmp.context;
      letter(g, 'Spellwright’s Circle', 0, 26, { size: 22, italic: true, colour: '#f0dcb0' });
      const a = this._actor;
      const sub = a ? a.name() + '  ·  ' + craftedFor(a.actorId()).length + ' of ' + OPT.maxPerActor + ' crafted  ·  up to ' + this._cap + ' aspects' : 'no actor';
      letter(g, sub, 1, 48, { size: 12, colour: DIM, maxWidth: 296 });
      touch(bmp);
    }

    showMessage(code) {
      const text = REASONS[code];
      if (!text) return;
      this.letterMessage(text, '#ffb9a0', 100);
    }

    /** Letter a message into the corner, wrapped to two lines. */
    letterMessage(text, colour, frames) {
      const bmp = this._msgSprite.bitmap;
      wipe(bmp);
      const g = bmp.context;
      g.save();
      g.font = 'italic 14px ' + SERIF;
      const words = String(text).split(' ');
      const lines = [''];
      for (let i = 0; i < words.length; i++) {
        const tryLine = lines[lines.length - 1] ? lines[lines.length - 1] + ' ' + words[i] : words[i];
        if (g.measureText(tryLine).width > bmp.width - 8 && lines[lines.length - 1] && lines.length < 2) lines.push(words[i]);
        else lines[lines.length - 1] = tryLine;
      }
      g.restore();
      for (let i = 0; i < lines.length; i++) letter(g, lines[i], 2, 18 + i * 19, { size: 14, italic: true, colour, maxWidth: bmp.width - 4 });
      touch(bmp);
      this._msgSprite.opacity = 255;
      this._msgTimer = frames;
    }

    /** Rebuild the composition and its seal after any change. */
    recompose(animate) {
      const C = core();
      const prev = this._seal;
      this._comp = C.compose(this._chosen, this._mag, null, this._narrow);
      this._seal = this._comp ? C.buildSeal(this._comp) : null;
      this._doneKeys = {};
      if (prev && this._seal && animate) {
        // what both seals share stays inscribed; only the change draws itself
        const had = {};
        for (let i = 0; i < prev.prims.length; i++) had[prev.prims[i].id + '@' + primSig(prev.prims[i])] = true;
        for (let i = 0; i < this._seal.prims.length; i++) {
          const p = this._seal.prims[i];
          if (had[p.id + '@' + primSig(p)]) this._doneKeys[p.id] = true;
        }
      }
      this._sealProgress = animate ? 0 : 1;
      this.paintSeal();
      this.refreshSockets();
    }

    paintSeal() {
      const bmp = this._sealBitmap;
      wipe(bmp);
      if (this._seal) {
        const o = this._paintOpts;
        o.doneKeys = this._doneKeys;
        o.glow = 1;
        core().paint(bmp.context, this._seal, bmp.width / 2, bmp.height / 2, LAYOUT.sealR, this._sealProgress, o);
      } else {
        const g = bmp.context;
        const none = !this._aspects.length;
        const who = this._actor ? this._actor.name() : 'This actor';
        letter(g, none ? who + ' knows no spell' : 'Place an aspect', bmp.width / 2, bmp.height / 2 - 4, { size: 16, italic: true, colour: 'rgba(233,220,192,0.45)', align: 'center' });
        letter(g, none ? 'whose effects can be drawn on' : 'in the circle', bmp.width / 2, bmp.height / 2 + 16, { size: 16, italic: true, colour: 'rgba(233,220,192,0.45)', align: 'center' });
      }
      touch(bmp);
    }

    // ---- input --------------------------------------------------------------

    onKeyDown(ev) {
      if (!this._typing) return;
      const k = ev.key;
      if (k === 'Enter') {
        this._typing = false;
        this._typed = core().cleanName(this._typed || '') || null;
        this._cooldown = 3;
        SoundManager.playOk();
      } else if (k === 'Escape') {
        this._typing = false;
        this._typed = null;
        this._cooldown = 3;
        SoundManager.playCancel();
      } else if (k === 'Backspace') {
        this._typed = (this._typed || '').slice(0, -1);
      } else if (k && k.length === 1 && (this._typed || '').length < 36) {
        this._typed = (this._typed || '') + k;
      } else return;
      this.refreshRibbon();
    }

    update() {
      super.update();
      this._frame++;
      if (this._cooldown > 0) this._cooldown--;
      else if (!this._typing && !this.isBusy()) this.updateInput();
      this.updateAnimation();
    }

    updateInput() {
      const rows = this.rowCount();
      if (Input.isRepeated('down')) this.moveCursor(1, rows);
      else if (Input.isRepeated('up')) this.moveCursor(-1, rows);
      else if (Input.isRepeated('right')) this.setMagnitude(this._mag + 1);
      else if (Input.isRepeated('left')) this.setMagnitude(this._mag - 1);
      else if (Input.isTriggered('ok')) this.activate(this._cursor);
      else if (Input.isTriggered('shift')) this.toggleReach();
      else if (Input.isTriggered('pagedown')) this.nextName();
      else if (Input.isTriggered('pageup')) this.openLedger();
      else if (Input.isTriggered('cancel')) this.cancel();
      else if (TouchInput.isTriggered()) this.onTouch(TouchInput.x, TouchInput.y);
    }

    moveCursor(d, rows) {
      this._cursor = (this._cursor + d + rows) % rows;
      if (this._cursor < this._scroll) this._scroll = this._cursor;
      else if (this._cursor >= this._scroll + LAYOUT.visibleRows) this._scroll = this._cursor - LAYOUT.visibleRows + 1;
      SoundManager.playCursor();
      this.refreshPanel();
    }

    setMagnitude(m) {
      const n = core().config().magnitudes.length;
      const v = Math.max(0, Math.min(n - 1, m));
      if (v === this._mag) return;
      this._mag = v;
      SoundManager.playCursor();
      this.recompose(true);
      this.refreshDial();
      this.refreshRibbon();
    }

    toggleReach() {
      if (!this._comp || !this._comp.mixedReach) {
        SoundManager.playBuzzer();
        return;
      }
      this._narrow = !this._narrow;
      SoundManager.playCursor();
      this.recompose(true);
      this.refreshDial();
      this.refreshRibbon();
    }

    nextName() {
      if (!this._comp) return;
      this._typed = null;
      this._variant = (this._variant + 1) % 3;
      SoundManager.playCursor();
      this.refreshRibbon();
    }

    activate(i) {
      if (i < this._aspects.length) this.toggleAspect(this._aspects[i]);
      else if (i === this._aspects.length) this.beginName();
      else this.commit();
    }

    toggleAspect(a) {
      const at = this._chosen.indexOf(a);
      if (at >= 0) {
        this._chosen.splice(at, 1);
        SoundManager.playCancel();
      } else {
        const v = core().canAdd(this._chosen, a, this._cap);
        if (!v.ok) {
          SoundManager.playBuzzer();
          this.showMessage(v.reason);
          return;
        }
        this._chosen.push(a);
        SoundManager.playOk();
      }
      if (!this._chosen.length) this._narrow = false;
      this._typed = null;
      this.recompose(true);
      this.refreshPanel();
      this.refreshDial();
      this.refreshRibbon();
    }

    beginName() {
      if (!this._comp) {
        SoundManager.playBuzzer();
        this.showMessage('empty');
        return;
      }
      if (OPT.allowTyping) {
        this._typing = true;
        this._typed = '';
        SoundManager.playOk();
      } else this.nextName();
      this.refreshRibbon();
    }

    commit() {
      if (!this._comp) {
        SoundManager.playBuzzer();
        this.showMessage('empty');
        return;
      }
      const r = inscribe(this._actor, this._comp, this.currentName());
      if (!r.ok) {
        SoundManager.playBuzzer();
        this.showMessage(r.reason);
        return;
      }
      SoundManager.playUseSkill();
      this._inscribed++;
      this._lastSkill = r.skill;
      this._flare = 1;
      this.drawBurst();
      this._aspects = aspectsFor(this._actor);
      this.refreshHeader();
      this.letterMessage(r.skill.name + ' is written into ' + this._actor.name() + '’s spells', '#ffe7a8', 150);
    }

    /** After the flare, the circle is cleared for the next spell. */
    clearCircle() {
      this._chosen.length = 0;
      this._narrow = false;
      this._typed = null;
      this._variant = 0;
      this.recompose(false);
      this.refreshPanel();
      this.refreshDial();
      this.refreshRibbon();
    }

    drawBurst() {
      const bmp = this._burst.bitmap;
      wipe(bmp);
      const g = bmp.context;
      const c = bmp.width / 2;
      const pal = this._seal ? this._seal.palettes[0] : core().paletteFor(0);
      const gr = g.createRadialGradient(c, c, LAYOUT.sealR * 0.2, c, c, LAYOUT.sealR + 24);
      gr.addColorStop(0, 'rgba(255,255,255,0)');
      gr.addColorStop(0.75, pal.glow);
      gr.addColorStop(1, 'rgba(0,0,0,0)');
      g.globalAlpha = 0.55;
      g.fillStyle = gr;
      g.fillRect(0, 0, bmp.width, bmp.height);
      touch(bmp);
    }

    cancel() {
      if (this._chosen.length) {
        this.toggleAspect(this._chosen[this._chosen.length - 1]);
        return;
      }
      SoundManager.playCancel();
      this.popScene();
    }

    openLedger() {
      SoundManager.playOk();
      SceneManager.push(Scene_SpellLedger);
      SceneManager.prepareNextScene(this._actor ? this._actor.actorId() : 0);
    }

    onTouch(x, y) {
      // panel rows
      if (x >= LAYOUT.panelX && x < LAYOUT.panelX + LAYOUT.panelW) {
        const v = Math.floor((y - LAYOUT.rowsTop - 36) / LAYOUT.rowH);
        const i = this._scroll + v;
        if (v >= 0 && v < LAYOUT.visibleRows && i < this.rowCount()) {
          this._cursor = i;
          this.placeHighlight();
          this.activate(i);
        }
        return;
      }
      // dial halves
      if (y >= 504 && x < 168) {
        this.setMagnitude(this._mag + (x < 104 ? -1 : 1));
        return;
      }
      // ribbon: another name
      if (y >= 508 && x >= 318 && x < 554) {
        this.nextName();
        return;
      }
      // a socket: take its aspect out
      for (let i = 0; i < this._chosen.length; i++) {
        const p = this.socketPos(i);
        if (Math.hypot(x - (LAYOUT.cx + p.x), y - (LAYOUT.cy + p.y)) < 24) {
          this.toggleAspect(this._chosen[i]);
          return;
        }
      }
    }

    // ---- animation (sprite properties only: no bitmap is redrawn while idle) --

    updateAnimation() {
      this._ringSprite.rotation += 0.0016;
      this._socketSprite.rotation = 0;
      if (this._sealProgress < 1 && this._seal) {
        // progress moves every frame; the bitmap is repainted on alternate frames
        // (and always on the last), halving texture uploads while a seal inscribes
        this._sealProgress = Math.min(1, this._sealProgress + this.inscribeSpeed());
        if (this._sealProgress >= 1 || (this._frame & 1) === 0) this.paintSeal();
      }
      const breathe = 0.5 + 0.5 * Math.sin(this._frame / 38);
      this._sealGlow.opacity = 40 + 50 * breathe + (this._flare > 0 ? 160 * this._flare : 0);
      this._sealGlow.scale.x = this._sealGlow.scale.y = 1.012 + 0.01 * breathe;
      this._sealSprite.rotation = Math.sin(this._frame / 240) * 0.02;
      this._sealGlow.rotation = this._sealSprite.rotation;
      if (this._flare > 0) {
        this._flare = Math.max(0, this._flare - 1 / 70);
        const k = 1 - this._flare;
        this._burst.opacity = 255 * this._flare;
        this._burst.scale.x = this._burst.scale.y = 0.85 + 0.6 * k;
        if (this._flare === 0) this.clearCircle();
      }
      const target = this.needleTarget();
      const d = target - this._needleAngle;
      if (Math.abs(d) > 0.0005) {
        this._needleAngle += d * 0.25;
        this._needle.rotation = this._needleAngle;
      }
      if (this._msgTimer > 0) {
        this._msgTimer--;
        if (this._msgTimer < 30) this._msgSprite.opacity = (255 * this._msgTimer) / 30;
      }
      if (this._typing && this._frame % 16 === 0) this.refreshRibbon();
    }

    /** Progress per frame: a seal inscribes in about 40 frames whatever its size. */
    inscribeSpeed() {
      return 1 / 40;
    }

    isBusy() {
      return super.isBusy() || this._flare > 0;
    }

    terminate() {
      super.terminate();
      if (typeof document !== 'undefined' && this._onKey) document.removeEventListener('keydown', this._onKey);
    }
  }

  /** A primitive's geometry signature (so "the same mark" means the same place). */
  function primSig(p) {
    const r = (n) => (n === undefined ? '_' : Math.round(n * 1000));
    return p.t + r(p.r) + r(p.a) + r(p.a0) + r(p.a1) + r(p.x0) + r(p.y0) + r(p.x) + r(p.cx) + (p.n || 0) + (p.skip || 0) + r(p.rot) + (p.ch || 0);
  }

  //===========================================================================
  // Scene_SpellLedger: the crafted spells, each with its seal
  //===========================================================================

  class Scene_SpellLedger extends Scene_Base {
    prepare(actorId) {
      this._actorId = Number(actorId) || 0;
    }

    create() {
      super.create();
      this._actor = actorOf(this._actorId || 0);
      this._page = 0;
      this._cursor = 0;
      this._armed = false;
      this._bg = new Sprite(new Bitmap(Graphics.width, Graphics.height));
      drawSlate(this._bg.bitmap, 0x1ed6e4);
      this.addChild(this._bg);
      this._sheet = new Sprite(new Bitmap(Graphics.width, Graphics.height));
      this.addChild(this._sheet);
      this._hi = new Sprite(new Bitmap(188, LEDGER.pitch - 6));
      this.drawHi(this._hi.bitmap);
      this.addChild(this._hi);
      this.refresh();
    }

    spells() {
      return this._actor ? craftedFor(this._actor.actorId()) : EMPTY;
    }

    drawHi(bmp) {
      const g = bmp.context;
      g.strokeStyle = 'rgba(240,214,160,0.85)';
      g.lineWidth = 1.4;
      const w = bmp.width;
      const h = bmp.height;
      g.beginPath();
      g.moveTo(14, 4); g.lineTo(4, 4); g.lineTo(4, 14);
      g.moveTo(w - 14, 4); g.lineTo(w - 4, 4); g.lineTo(w - 4, 14);
      g.moveTo(14, h - 4); g.lineTo(4, h - 4); g.lineTo(4, h - 14);
      g.moveTo(w - 14, h - 4); g.lineTo(w - 4, h - 4); g.lineTo(w - 4, h - 14);
      g.stroke();
      touch(bmp);
    }

    refresh() {
      const C = core();
      const bmp = this._sheet.bitmap;
      wipe(bmp);
      const g = bmp.context;
      const list = this.spells();
      const per = 8;
      const pages = Math.max(1, Math.ceil(list.length / per));
      if (this._page >= pages) this._page = pages - 1;
      letter(g, 'Spell Ledger', 40, 54, { size: 26, italic: true, colour: '#f0dcb0' });
      letter(g, (this._actor ? this._actor.name() : '') + '  ·  ' + list.length + ' crafted' + (pages > 1 ? '  ·  page ' + (this._page + 1) + ' of ' + pages : ''), 42, 76, { size: 13, colour: DIM });
      letter(g, 'Shift twice unmakes the chosen spell  ·  Cancel returns', Graphics.width - 40, 76, { size: 12, italic: true, colour: DIM, align: 'right' });
      if (!list.length) letter(g, 'No spells written yet', Graphics.width / 2, Graphics.height / 2, { size: 20, italic: true, colour: 'rgba(233,220,192,0.5)', align: 'center' });
      for (let k = 0; k < per; k++) {
        const s = list[this._page * per + k];
        if (!s) break;
        const col = k % 4;
        const row = Math.floor(k / 4);
        const x = 40 + col * 186 + 93;
        const y = LEDGER.top + row * LEDGER.pitch + 92;
        const seal = sealOf(s.id);
        if (seal) C.paint(g, seal, x, y, 76, 1, LEDGER_PAINT);
        letter(g, s.name, x, y + 112, { size: 15, italic: true, colour: '#fbe6c2', align: 'center', maxWidth: 176 });
        letter(g, s.mpCost + ' MP', x, y + 132, { size: 12, colour: '#9fd0ff', align: 'center' });
        letter(g, s.description, x, y + 150, { size: 10.5, italic: true, colour: DIM, align: 'center', maxWidth: 178 });
      }
      touch(bmp);
      this.placeHi();
    }

    placeHi() {
      const k = this._cursor;
      const n = this.spells().length - this._page * 8;
      this._hi.visible = n > 0;
      this._hi.x = 40 + (k % 4) * 186;
      this._hi.y = LEDGER.top - 4 + Math.floor(k / 4) * LEDGER.pitch;
    }

    update() {
      super.update();
      const list = this.spells();
      const n = Math.min(8, list.length - this._page * 8);
      if (Input.isRepeated('right')) this.move(1, n);
      else if (Input.isRepeated('left')) this.move(-1, n);
      else if (Input.isRepeated('down')) this.move(4, n);
      else if (Input.isRepeated('up')) this.move(-4, n);
      else if (Input.isTriggered('pagedown')) this.turn(1);
      else if (Input.isTriggered('pageup')) this.turn(-1);
      else if (Input.isTriggered('shift')) this.unmakeChosen();
      else if (Input.isTriggered('cancel') || TouchInput.isCancelled()) {
        SoundManager.playCancel();
        this.popScene();
      }
    }

    move(d, n) {
      if (n <= 0) return;
      this._armed = false;
      this._cursor = Math.max(0, Math.min(n - 1, this._cursor + d));
      SoundManager.playCursor();
      this.placeHi();
    }

    turn(d) {
      const pages = Math.max(1, Math.ceil(this.spells().length / 8));
      const p = Math.max(0, Math.min(pages - 1, this._page + d));
      if (p === this._page) return;
      this._page = p;
      this._cursor = 0;
      SoundManager.playCursor();
      this.refresh();
    }

    unmakeChosen() {
      const s = this.spells()[this._page * 8 + this._cursor];
      if (!s) return;
      if (!this._armed) {
        this._armed = true;
        SoundManager.playBuzzer();
        return;
      }
      this._armed = false;
      unmake(this._actor, s.id);
      SoundManager.playCancel();
      this._cursor = 0;
      this.refresh();
    }
  }
  const LEDGER_PAINT = { glow: 1, lineScale: 1 };
  const LEDGER = { top: 96, pitch: 252 };

  //===========================================================================
  // The battle flash: a crafted spell's seal inscribes over the field
  //===========================================================================

  if (typeof Spriteset_Battle !== 'undefined') {
    Spriteset_Battle.prototype.csafSpellwrightFlash = function (skill) {
      if (!this._csafSwSprite) {
        const b = new Bitmap(360, 360);
        this._csafSwSprite = new Sprite(b);
        this._csafSwSprite.anchor.set(0.5, 0.5);
        this._csafSwSprite.blendMode = PIXI.BLEND_MODES.ADD;
        this._csafSwSprite.move(Graphics.width / 2, Graphics.height * 0.42);
        this._csafSwOpts = { glow: 1, lineScale: 1.2 };
        this.addChild(this._csafSwSprite);
      }
      const seal = sealOf(skill.id);
      this._csafSwSeal = seal;
      this._csafSwT = seal ? 0 : -1;
      this._csafSwSprite.opacity = 255;
    };
    const _update = Spriteset_Battle.prototype.update;
    Spriteset_Battle.prototype.update = function () {
      _update.call(this);
      if (this._csafSwSprite && this._csafSwT >= 0) {
        this._csafSwT++;
        const t = this._csafSwT;
        if (t <= 32) {
          if (t % 2 === 1 && t !== 32) return; // alternate frames: half the uploads
          const b = this._csafSwSprite.bitmap;
          wipe(b);
          core().paint(b.context, this._csafSwSeal, 180, 180, 150, t / 32, this._csafSwOpts);
          touch(b);
        } else if (t <= 60) {
          this._csafSwSprite.opacity = 255 * (1 - (t - 32) / 28);
        } else {
          this._csafSwT = -1;
          this._csafSwSprite.opacity = 0;
        }
      }
    };
  }

  //===========================================================================
  // Main menu command (optional)
  //===========================================================================

  if (typeof Window_MenuCommand !== 'undefined' && OPT.menuCommand) {
    const _add = Window_MenuCommand.prototype.addOriginalCommands;
    Window_MenuCommand.prototype.addOriginalCommands = function () {
      _add.call(this);
      if (OPT.menuSwitch > 0 && !$gameSwitches.value(OPT.menuSwitch)) return;
      this.addCommand(OPT.menuCommand, 'csafSpellwright', true);
    };
    const _cmd = Scene_Menu.prototype.createCommandWindow;
    Scene_Menu.prototype.createCommandWindow = function () {
      _cmd.call(this);
      this._commandWindow.setHandler('csafSpellwright', this.commandPersonal.bind(this));
    };
    const _personal = Scene_Menu.prototype.onPersonalOk;
    Scene_Menu.prototype.onPersonalOk = function () {
      if (this._commandWindow.currentSymbol() === 'csafSpellwright') {
        SceneManager.push(Scene_Spellwright);
        SceneManager.prepareNextScene($gameParty.menuActor().actorId());
        return;
      }
      _personal.call(this);
    };
  }

  //===========================================================================
  // Plugin commands
  //===========================================================================

  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
    PluginManager.registerCommand(PLUGIN, 'open', function (args) {
      const a = actorOf(args.actorId);
      if (!a) return;
      SceneManager.push(Scene_Spellwright);
      SceneManager.prepareNextScene(a.actorId());
    });
    PluginManager.registerCommand(PLUGIN, 'ledger', function (args) {
      const a = actorOf(args.actorId);
      if (!a) return;
      SceneManager.push(Scene_SpellLedger);
      SceneManager.prepareNextScene(a.actorId());
    });
    PluginManager.registerCommand(PLUGIN, 'grant', function (args) {
      const a = actorOf(args.actorId);
      if (!a) return;
      let ids = [];
      try {
        ids = JSON.parse(args.skills || '[]').map((x) => Number(x)).filter((x) => x > 0);
      } catch (e) {
        ids = [];
      }
      api.grant(a, ids, num(args.magnitude, 3) - 1, String(args.name || ''));
    });
    PluginManager.registerCommand(PLUGIN, 'unmake', function (args) {
      const a = actorOf(args.actorId);
      if (a) unmake(a, args.which === 'all' ? 'all' : 'last');
    });
    PluginManager.registerCommand(PLUGIN, 'cap', function (args) {
      const a = actorOf(args.actorId);
      if (a) data().caps[a.actorId()] = Math.max(1, num(args.cap, 4));
    });
    PluginManager.registerCommand(PLUGIN, 'lock', function (args) {
      const id = num(args.skillId, 0);
      if (id <= 0) return;
      if (bool(args.locked, true)) data().locks[id] = true;
      else delete data().locks[id];
    });
    PluginManager.registerCommand(PLUGIN, 'count', function (args) {
      const a = actorOf(args.actorId);
      const v = num(args.variableId, 0);
      if (a && v > 0) $gameVariables.setValue(v, craftedFor(a.actorId()).length);
    });
  }

  const api = {
    core,
    data,
    craftedFor,
    aspectsFor,
    capFor,
    inscribe,
    unmake,
    injectAll,
    purge,
    aspectLabel,
    drawToken,
    NAMES,
    OPT,
    version: () => version,
    /**
     * Craft a spell from source skills without the scene.
     * @param {Game_Actor} actor Crafter.
     * @param {number[]} skillIds Source skills (aspects added in order, as the rules allow).
     * @param {number} magIndex 0..4.
     * @param {string} [name] Name (blank = proposed).
     * @param {boolean} [narrow] Keep the narrow reach.
     * @returns {object} Result of inscribe.
     */
    grant(actor, skillIds, magIndex, name, narrow) {
      const C = core();
      const chosen = [];
      for (let i = 0; i < skillIds.length; i++) {
        const s = $dataSkills[skillIds[i]];
        const list = s ? C.readAspects(Object.assign({}, s, { note: (s.note || '') + '<spellwright aspect>' })) : [];
        for (let k = 0; k < list.length; k++) if (C.canAdd(chosen, list[k], capFor(actor)).ok) chosen.push(list[k]);
      }
      const comp = C.compose(chosen, magIndex, null, narrow);
      return inscribe(actor, comp, name || '');
    }
  };
  if (typeof window !== 'undefined') {
    window.Spellwright = api;
    window.Scene_Spellwright = Scene_Spellwright;
    window.Scene_SpellLedger = Scene_SpellLedger;
  }
  return api;
})();
