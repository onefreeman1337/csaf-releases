//=============================================================================
// Escapement.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Escapement - generated clockwork puzzles. Every lock,
 * clock, orrery or winch becomes a gear train the player must complete.
 * Place BELOW EscapementCore and EscapementDraw.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * Escapement
 * ============================================================================
 *
 * A locked door is usually a switch and a line of text. Escapement turns it
 * into a mechanism the player has to finish: a plate with fixed arbors, a
 * tray of loose wheels, a mainspring that drives, and a payoff that only
 * moves when the train is right.
 *
 *  - Wheels mesh only when their sizes fit the gap between two arbors.
 *  - Every wheel in a train turns the opposite way to the one driving it.
 *  - The payoff will only turn one way. Reach it the wrong way round and the
 *    pawl holds.
 *  - Close a loop of an odd number of wheels and the whole train jams.
 *
 * Every puzzle is GENERATED from a seed, laid around a working train, so it
 * cannot be unsolvable. The same event always gets the same puzzle. Nothing
 * is loaded from an image file: every wheel, plate, jewel and dial is drawn
 * in code.
 *
 * ----------------------------------------------------------------------------
 * INSTALLING
 * ----------------------------------------------------------------------------
 * Plugin Manager order, top to bottom:
 *
 *     EscapementCore.js     (the generator and the gear physics)
 *     EscapementDraw.js     (the drawing)
 *     Escapement.js         (this file: parameters, commands, the scene)
 *
 * ----------------------------------------------------------------------------
 * USING IT
 * ----------------------------------------------------------------------------
 * On any event, add the plugin command "Open Puzzle". Pick a grade (1 easy,
 * 5 hard) and what the train drives: a strongroom LOCK, a CLOCK, an ORRERY or
 * a WINCH. Name a switch to turn ON when it is solved, or a self switch of
 * the event. The event waits while the puzzle is open; the next command runs
 * after the player leaves, so a Conditional Branch on the switch works.
 *
 * Leave the seed blank and the puzzle is keyed to the map and event, so it is
 * stable across saves. Give a seed to share one puzzle between events.
 *
 * Script calls:
 *     Escapement.isSolved("m3e12")   true if that puzzle was solved
 *     Escapement.keyFor(mapId, eventId)
 *
 * ----------------------------------------------------------------------------
 * CONTROLS
 * ----------------------------------------------------------------------------
 * Arrow keys choose an arbor. OK on an empty arbor opens the tray; left and
 * right choose a wheel, OK sets it. OK on a wheel lifts it back into the
 * tray. Escape leaves (the wheels stay where they were). Mouse and touch:
 * click an arbor, then click a wheel in the tray.
 *
 * ----------------------------------------------------------------------------
 * COMPATIBILITY
 * ----------------------------------------------------------------------------
 * Escapement adds its own scene and replaces nothing. It extends one engine
 * method (Game_System.initialize) to create its save record, calling the
 * original first. See the listing for the generated compatibility block.
 *
 * ============================================================================
 * TERMS OF USE
 * ============================================================================
 * Commercial and non-commercial use permitted in RPG Maker projects, credit
 * appreciated but not required. Do not redistribute the source as an asset
 * pack. Every line of this plugin was written with AI assistance.
 *
 * ============================================================================
 *
 * @param defaultGrade
 * @text Default grade
 * @type number
 * @min 1
 * @max 5
 * @desc Difficulty used when a command leaves the grade blank. 1 easy, 5 hard.
 * @default 2
 *
 * @param defaultMetal
 * @text Default metal
 * @type select
 * @option auto
 * @option brass
 * @option steel
 * @option bronze
 * @option verdigris
 * @option gunmetal
 * @desc The alloy the plate and wheels are cut from. auto = chosen by the seed.
 * @default auto
 *
 * @param driveSpeed
 * @text Drive speed
 * @type number
 * @decimals 2
 * @min 0.1
 * @max 5
 * @desc How fast the mainspring turns, in degrees per frame.
 * @default 1.2
 *
 * @param allowLeave
 * @text Allow leaving unsolved
 * @type boolean
 * @desc If false, Escape does nothing until the puzzle is solved.
 * @default true
 *
 * @param placeSe
 * @text Sound: wheel set
 * @type file
 * @dir audio/se
 * @default Equip1
 *
 * @param liftSe
 * @text Sound: wheel lifted
 * @type file
 * @dir audio/se
 * @default Cursor2
 *
 * @param refuseSe
 * @text Sound: refused / jammed
 * @type file
 * @dir audio/se
 * @default Buzzer1
 *
 * @param solveSe
 * @text Sound: solved
 * @type file
 * @dir audio/se
 * @default Open1
 *
 * @param cursorSe
 * @text Sound: cursor
 * @type file
 * @dir audio/se
 * @default Cursor1
 *
 * @command open
 * @text Open Puzzle
 * @desc Open a clockwork puzzle. The event waits until the player leaves it.
 *
 * @arg grade
 * @text Grade
 * @type number
 * @min 0
 * @max 5
 * @desc 1 (easy) to 5 (hard). 0 = the plugin's default grade.
 * @default 0
 *
 * @arg payoff
 * @text What the train drives
 * @type select
 * @option auto
 * @option lock
 * @option clock
 * @option orrery
 * @option winch
 * @default lock
 *
 * @arg metal
 * @text Metal
 * @type select
 * @option default
 * @option auto
 * @option brass
 * @option steel
 * @option bronze
 * @option verdigris
 * @option gunmetal
 * @default default
 *
 * @arg title
 * @text Title
 * @desc The name engraved above the plate. Blank = named after the payoff.
 * @default
 *
 * @arg switchId
 * @text Switch when solved
 * @type switch
 * @desc Turned ON when the puzzle is solved. 0 = none.
 * @default 0
 *
 * @arg selfSwitch
 * @text Self switch when solved
 * @type select
 * @option none
 * @option A
 * @option B
 * @option C
 * @option D
 * @default none
 *
 * @arg seed
 * @text Seed (optional)
 * @desc Blank = keyed to this map and event. Any text or number gives a fixed puzzle.
 * @default
 *
 * @command reset
 * @text Reset Puzzle
 * @desc Forget a puzzle's progress and its solved state.
 *
 * @arg seed
 * @text Seed (optional)
 * @desc Blank = the puzzle keyed to THIS map and event.
 * @default
 */

var Escapement = Escapement || {};

(function (M) {
  'use strict';
  var NAME = 'Escapement';
  var SCHEMA = 1;

  //===========================================================================
  // Parameters. A blank parameter is ABSENT, never zero (Number('') is 0).
  //===========================================================================

  var raw = (typeof PluginManager !== 'undefined') ? PluginManager.parameters(NAME) : {};
  function num(v, dflt) {
    if (v === undefined || v === null || String(v).trim() === '') return dflt;
    var n = Number(v);
    return isFinite(n) ? n : dflt;
  }
  function bool(v, dflt) {
    if (v === undefined || v === null || String(v).trim() === '') return dflt;
    return String(v) === 'true';
  }
  function str(v, dflt) {
    if (v === undefined || v === null || String(v).trim() === '') return dflt;
    return String(v).trim();
  }

  M.params = {
    defaultGrade: Math.max(1, Math.min(5, num(raw.defaultGrade, 2))),
    defaultMetal: str(raw.defaultMetal, 'auto'),
    driveSpeed: Math.max(0.1, Math.min(5, num(raw.driveSpeed, 1.2))) * Math.PI / 180,
    allowLeave: bool(raw.allowLeave, true),
    placeSe: str(raw.placeSe, 'Equip1'),
    liftSe: str(raw.liftSe, 'Cursor2'),
    refuseSe: str(raw.refuseSe, 'Buzzer1'),
    solveSe: str(raw.solveSe, 'Open1'),
    cursorSe: str(raw.cursorSe, 'Cursor1'),
  };

  //===========================================================================
  // Siblings, resolved at FIRST USE (the buyer sets the load order).
  //===========================================================================

  var _deps = null;
  function deps() {
    if (_deps) return _deps;
    var core = (typeof EscapementCore !== 'undefined') ? EscapementCore : null;
    var draw = (typeof EscapementDraw !== 'undefined') ? EscapementDraw : null;
    if (!core || !draw) {
      if (!deps._warned) {
        deps._warned = true;
        console.error('Escapement: EscapementCore.js and EscapementDraw.js must both be installed and '
          + 'listed ABOVE Escapement.js in the Plugin Manager.');
      }
      return null;
    }
    _deps = { core: core, draw: draw };
    return _deps;
  }
  M.deps = deps;

  //===========================================================================
  // Save record: versioned, forward-compatible.
  //===========================================================================

  function fresh() { return { v: SCHEMA, solved: {}, placed: {} }; }
  function store() {
    if (typeof $gameSystem === 'undefined' || !$gameSystem) return fresh();
    var s = $gameSystem._csafEscapement;
    if (!s || s.v == null) { s = fresh(); $gameSystem._csafEscapement = s; }
    if (!s.solved) s.solved = {};
    if (!s.placed) s.placed = {};
    return s;
  }
  M.store = store;

  M.keyFor = function (mapId, eventId) { return 'm' + Number(mapId) + 'e' + Number(eventId); };
  M.isSolved = function (key) { return !!store().solved[String(key)]; };

  var _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () {
    _Game_System_initialize.call(this);
    this._csafEscapement = fresh();
  };

  //===========================================================================
  // Building a request
  //===========================================================================

  var PAYOFF_NAMES = { lock: 'The Strongroom Lock', clock: 'The Tower Clock', orrery: 'The Orrery', winch: 'The Portcullis Winch' };
  var GOALS = { lock: 'the bolt draws back', clock: 'the hands turn true', orrery: 'the planets wheel', winch: 'the weight rises' };
  M.GOALS = GOALS;

  /**
   * Turn plugin-command style arguments into a puzzle request.
   * @param {Object} args raw strings from the command (or a script object)
   * @param {string} key the puzzle's save key
   * @returns {Object} {key, puzzle, title, switchId, selfSwitch, mapId, eventId}
   */
  M.request = function (args, key, mapId, eventId) {
    var d = deps();
    if (!d) return null;
    args = args || {};
    var grade = num(args.grade, 0);
    if (!(grade >= 1)) grade = M.params.defaultGrade;
    var metalArg = str(args.metal, 'default');
    if (metalArg === 'default') metalArg = M.params.defaultMetal;
    var payoff = str(args.payoff, 'lock');
    var seedText = str(args.seed, '');
    var seed = seedText === '' ? d.core.hashString(key)
      : (/^\d+$/.test(seedText) ? (Number(seedText) >>> 0) : d.core.hashString(seedText));
    var pz = d.core.generate({
      seed: seed, grade: grade,
      payoff: payoff === 'auto' ? null : payoff,
      metal: metalArg === 'auto' ? null : metalArg,
    });
    return {
      key: key, puzzle: pz,
      title: str(args.title, PAYOFF_NAMES[pz.payoff]),
      switchId: Math.max(0, Math.floor(num(args.switchId, 0))),
      selfSwitch: ['A', 'B', 'C', 'D'].indexOf(str(args.selfSwitch, 'none')) >= 0 ? str(args.selfSwitch, 'none') : 'none',
      mapId: mapId, eventId: eventId,
    };
  };

  /** Open a request (from a command or a script). */
  M.open = function (req) {
    if (!req) return false;
    SceneManager.push(Scene_Escapement);
    SceneManager.prepareNextScene(req);
    return true;
  };

  /** Called by the scene when the train is right. */
  M.markSolved = function (req, placed) {
    var s = store();
    s.solved[req.key] = true;
    s.placed[req.key] = { seed: req.puzzle.seed, grade: req.puzzle.grade, placed: placed.slice() };
    if (req.switchId > 0 && typeof $gameSwitches !== 'undefined') $gameSwitches.setValue(req.switchId, true);
    if (req.selfSwitch !== 'none' && req.mapId > 0 && req.eventId > 0 && typeof $gameSelfSwitches !== 'undefined') {
      $gameSelfSwitches.setValue([req.mapId, req.eventId, req.selfSwitch], true);
    }
  };

  /** Remember an unfinished train when the player walks away. */
  M.remember = function (req, placed) {
    store().placed[req.key] = { seed: req.puzzle.seed, grade: req.puzzle.grade, placed: placed.slice() };
  };

  /** @returns {Array<number>|null} the remembered placement, if it belongs to THIS puzzle */
  M.recall = function (req) {
    var rec = store().placed[req.key];
    if (!rec || rec.seed !== req.puzzle.seed || rec.grade !== req.puzzle.grade) return null;
    if (!rec.placed || rec.placed.length !== req.puzzle.arbors.length) return null;
    return rec.placed.slice();
  };

  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
    PluginManager.registerCommand(NAME, 'open', function (args) {
      var mapId = this._mapId || ($gameMap ? $gameMap.mapId() : 0);
      var eventId = this.eventId ? this.eventId() : 0;
      var seedText = str(args.seed, '');
      var key = seedText === '' ? M.keyFor(mapId, eventId) : 's' + seedText;
      var req = M.request(args, key, mapId, eventId);
      if (!req) return;
      if (M.isSolved(key)) { M.markSolved(req, M.recall(req) || req.puzzle.arbors.map(function () { return -1; })); return; }
      M.open(req);
    });
    PluginManager.registerCommand(NAME, 'reset', function (args) {
      var mapId = this._mapId || ($gameMap ? $gameMap.mapId() : 0);
      var eventId = this.eventId ? this.eventId() : 0;
      var seedText = str(args.seed, '');
      var key = seedText === '' ? M.keyFor(mapId, eventId) : 's' + seedText;
      var s = store();
      delete s.solved[key];
      delete s.placed[key];
    });
  }

  M.VERSION = '1.0.0';
  M.SCHEMA = SCHEMA;
}(Escapement));

//=============================================================================
// Scene_Escapement
//=============================================================================

function Scene_Escapement() { this.initialize.apply(this, arguments); }
Scene_Escapement.prototype = Object.create(Scene_Base.prototype);
Scene_Escapement.prototype.constructor = Scene_Escapement;

/** Screen placement of the plate and the tray. */
Scene_Escapement.PLATE_X = 88;
Scene_Escapement.PLATE_Y = 76;
Scene_Escapement.TRAY_Y = 500;
Scene_Escapement.TRAY_H = 108;

Scene_Escapement.prototype.initialize = function () {
  Scene_Base.prototype.initialize.call(this);
  this._req = null;
};

Scene_Escapement.prototype.prepare = function (req) { this._req = req; };

Scene_Escapement.prototype.create = function () {
  Scene_Base.prototype.create.call(this);
  var d = Escapement.deps();
  this._d = d;
  var pz = this._req.puzzle;
  this._pz = pz;
  this._placed = Escapement.recall(this._req) || d.core.emptyPlacement(pz);
  this._mode = 'board';      // board | tray | solving | done
  this._cursor = 0;          // arbor index on the board
  this._trayCursor = 0;      // tray index in the tray
  this._theta = 0;           // the drive's angle
  this._frame = 0;
  this._progress = 0;        // payoff progress once solved
  this._doneWait = 0;
  this._status = '';
  this._statusTone = '';
  this._flash = 0;
  this._flashArbor = -1;
  this.createBench();
  this.createShadows();
  this.createPayoff();
  this.createGears();
  this.createTray();
  this.createCursor();
  this.createText();
  this.refreshTrain(true);
};

Scene_Escapement.prototype.start = function () {
  Scene_Base.prototype.start.call(this);
  this.startFadeIn(this.fadeSpeed(), false);
};

//----------------------------------------------------------------------------
// Construction. Everything is drawn ONCE here; per frame only numbers change.
//----------------------------------------------------------------------------

Scene_Escapement.prototype.createBench = function () {
  var d = this._d, pz = this._pz;
  var W = Graphics.width, H = Graphics.height;
  var bmp = new Bitmap(W, H);
  var ctx = bmp.context;
  d.draw.drawBench(ctx, W, H, pz.metal);
  ctx.save();
  ctx.translate(Scene_Escapement.PLATE_X, Scene_Escapement.PLATE_Y);
  d.draw.drawPlate(ctx, pz, null);
  var m = d.draw.metal(pz.metal);
  for (var a = 0; a < pz.arbors.length; a++) d.draw.drawArbor(ctx, pz.arbors[a].x, pz.arbors[a].y, m);
  // each arrow goes on whichever side of its wheel no loose wheel can ever cover
  var maxR = 0;
  for (var t = 0; t < pz.tray.length; t++) maxR = Math.max(maxR, d.core.outerR(pz.tray[t].n));
  var dR = d.core.outerR(pz.drive.n), oR = d.core.outerR(pz.output.n);
  this._driveSide = d.draw.clearSide(pz, pz.drive.x, pz.drive.y, dR, { x: pz.output.x, y: pz.output.y, R: oR }, maxR, pz.plate.payoffX);
  this._outputSide = d.draw.clearSide(pz, pz.output.x, pz.output.y, oR, { x: pz.drive.x, y: pz.drive.y, R: dR }, maxR, pz.plate.payoffX);
  d.draw.drawTurnArrow(ctx, pz.drive.x, pz.drive.y, dR, 1, m, 'mainspring', this._driveSide);
  // the OUTPUT's arrow is the one the player must read, so it is a hint drawn above the wheels
  // (createGears adds it), never an engraving a neighbouring wheel can cover
  this._payoffAnchor = d.draw.drawPayoffBase(ctx, pz);
  ctx.restore();
  bmp._baseTexture.update();
  this._benchSprite = new Sprite(bmp);
  this.addChild(this._benchSprite);
};

Scene_Escapement.prototype.createShadows = function () {
  this._shadowSprite = new Sprite(new Bitmap(this._pz.plate.w + 20, this._pz.plate.h + 20));
  this._shadowSprite.x = Scene_Escapement.PLATE_X;
  this._shadowSprite.y = Scene_Escapement.PLATE_Y;
  this.addChild(this._shadowSprite);
};

/** A sprite holding one drawing, anchored at its centre. */
Scene_Escapement.prototype.makeDrawn = function (w, h, fn) {
  var bmp = new Bitmap(Math.ceil(w), Math.ceil(h));
  var ctx = bmp.context;
  ctx.save();
  ctx.translate(w / 2, h / 2);
  fn(ctx);
  ctx.restore();
  bmp._baseTexture.update();
  var s = new Sprite(bmp);
  s.anchor.x = 0.5; s.anchor.y = 0.5;
  return s;
};

Scene_Escapement.prototype.gearSprite = function (n, style, role) {
  var d = this._d, pz = this._pz;
  var R = d.core.outerR(n) + 2;
  return this.makeDrawn(R * 2, R * 2, function (ctx) {
    d.draw.drawGear(ctx, { n: n, module: d.core.MODULE, style: style, metal: pz.metal, role: role });
  });
};

Scene_Escapement.prototype.glintSprite = function (n) {
  var d = this._d, pz = this._pz;
  var R = d.core.outerR(n);
  var s = this.makeDrawn(R * 2 + 2, R * 2 + 2, function (ctx) { d.draw.drawGlint(ctx, R, d.draw.metal(pz.metal)); });
  s.blendMode = 1; // ADD: the glint lightens the metal under it and never turns with it
  return s;
};

Scene_Escapement.prototype.createGears = function () {
  var pz = this._pz, PX = Scene_Escapement.PLATE_X, PY = Scene_Escapement.PLATE_Y;
  this._driveSprite = this.gearSprite(pz.drive.n, 'disc', 'drive');
  this._driveSprite.x = PX + pz.drive.x; this._driveSprite.y = PY + pz.drive.y;
  this._outputSprite = this.gearSprite(pz.output.n, 'holes', 'output');
  this._outputSprite.x = PX + pz.output.x; this._outputSprite.y = PY + pz.output.y;
  this.addChild(this._driveSprite);
  this.addChild(this._outputSprite);
  // one wheel sprite PER TRAY WHEEL, moved between tray and arbor; never recreated
  this._wheelSprites = [];
  this._wheelGlints = [];
  this._restAngle = [];
  var r = this._d.core.rng((pz.seed ^ 0x77) >>> 0);
  for (var t = 0; t < pz.tray.length; t++) {
    var s = this.gearSprite(pz.tray[t].n, pz.tray[t].style, 'loose');
    this._wheelSprites.push(s);
    this.addChild(s);
    this._restAngle.push(r() * Math.PI * 2);
  }
  for (var g = 0; g < pz.tray.length; g++) {
    var gl = this.glintSprite(pz.tray[g].n);
    gl.visible = false;
    this._wheelGlints.push(gl);
    this.addChild(gl);
  }
  this._driveGlint = this.glintSprite(pz.drive.n);
  this._driveGlint.x = this._driveSprite.x; this._driveGlint.y = this._driveSprite.y;
  this._outputGlint = this.glintSprite(pz.output.n);
  this._outputGlint.x = this._outputSprite.x; this._outputGlint.y = this._outputSprite.y;
  this.addChild(this._driveGlint);
  this.addChild(this._outputGlint);
  var d = this._d, oR = d.core.outerR(pz.output.n), side = this._outputSide, dir = d.core.requiredDir(pz);
  var span = (oR + 90) * 2;
  this._hintSprite = this.makeDrawn(span, span, function (ctx) { d.draw.drawTurnHint(ctx, oR, dir, 'must turn', side); });
  this._hintSprite.x = this._outputSprite.x; this._hintSprite.y = this._outputSprite.y;
  this.addChild(this._hintSprite);
};

Scene_Escapement.prototype.createPayoff = function () {
  var d = this._d, pz = this._pz, PX = Scene_Escapement.PLATE_X, PY = Scene_Escapement.PLATE_Y;
  var a = this._payoffAnchor, acc = d.draw.metal(d.draw.ACCENT[pz.metal] || 'steel'), m = d.draw.metal(pz.metal);
  this._payoffParts = {};
  var P = this._payoffParts;
  if (pz.payoff === 'lock') {
    var L = a.bolt.len;
    // drawn from its centre: the bolt's LEFT END sits at the sprite's x
    P.bolt = this.makeDrawn(L * 2 + 4, 24, function (ctx) { d.draw.drawBolt(ctx, L, m); });
    P.boltX0 = PX + a.bolt.left0;
    P.bolt.x = P.boltX0; P.bolt.y = PY + a.bolt.y;
    P.travel = a.bolt.travel;
    P.shut = this.makeDrawn(56, 16, function (ctx) { d.draw.drawWindowWord(ctx, 'SHUT', false); });
    P.drawn = this.makeDrawn(56, 16, function (ctx) { d.draw.drawWindowWord(ctx, 'DRAWN', true); });
    P.shut.x = P.drawn.x = PX + a.window.x; P.shut.y = P.drawn.y = PY + a.window.y;
    P.drawn.visible = false;
    this.addChild(P.bolt); this.addChild(P.shut); this.addChild(P.drawn);
  } else if (pz.payoff === 'clock') {
    var R = a.dial.R;
    P.hour = this.makeDrawn(20, R * 1.3, function (ctx) { ctx.translate(0, R * 0.3); d.draw.drawHand(ctx, R * 0.5, 3.2, acc, 7); });
    P.minute = this.makeDrawn(16, R * 2, function (ctx) { ctx.translate(0, R * 0.62); d.draw.drawHand(ctx, R * 0.78, 2.2, acc, 9); });
    // the hands pivot at the dial centre: offset the anchor to the hub
    P.hour.anchor.y = (R * 0.65 + R * 0.3) / (R * 1.3); P.minute.anchor.y = (R + R * 0.62) / (R * 2);
    P.hour.x = P.minute.x = PX + a.dial.x; P.hour.y = P.minute.y = PY + a.dial.y;
    P.hour0 = 5.2; P.minute0 = 2.1;
    this.addChild(P.hour); this.addChild(P.minute);
  } else if (pz.payoff === 'orrery') {
    var o = a.orrery;
    P.sun = this.makeDrawn(30, 30, function (ctx) { d.draw.drawSun(ctx, 9); });
    P.sun.x = PX + o.x; P.sun.y = PY + o.y;
    var cols = ['#7fb2ff', '#e46b4c', '#e7d27a'];
    var pr = [4.5, 5.5, 7.5];
    P.arms = [];
    P.armRate = [1.0, 0.62, 0.38];
    P.arm0 = [0.4, 2.3, 4.4];
    for (var i = 0; i < 3; i++) {
      (function (self, len, rad, col) {
        var s = self.makeDrawn(len * 2 + 16, 16, function (ctx) { d.draw.drawPlanetArm(ctx, len, rad, col, acc); });
        s.x = PX + o.x; s.y = PY + o.y;
        P.arms.push(s); self.addChild(s);
      }(this, o.orbits[i], pr[i], cols[i]));
    }
    this.addChild(P.sun);
  } else {
    var w = a.winch;
    P.rope = new Sprite(new Bitmap(3, 1));
    P.rope.bitmap.fillRect(0, 0, 1, 1, '#2c1d10'); P.rope.bitmap.fillRect(1, 0, 1, 1, '#a88452'); P.rope.bitmap.fillRect(2, 0, 1, 1, '#4b331b');
    P.rope.x = PX + w.x - 1; P.rope.y = PY + w.y;
    P.drum = this.makeDrawn(46, 46, function (ctx) { d.draw.drawDrum(ctx, 20, acc); });
    P.drum.x = PX + w.x; P.drum.y = PY + w.y;
    P.weight = this.makeDrawn(30, 70, function (ctx) { ctx.translate(0, -18); d.draw.drawWeight(ctx, m); });
    P.weight.anchor.y = 17 / 70;
    P.top = PY + w.y + 30; P.bottom = PY + w.bottom - 30;
    P.weight.x = PX + w.x;
    this.addChild(P.rope); this.addChild(P.weight); this.addChild(P.drum);
  }
};

Scene_Escapement.prototype.createTray = function () {
  var d = this._d, pz = this._pz;
  var W = pz.plate.w, H = Scene_Escapement.TRAY_H;
  var bmp = new Bitmap(W + 8, H + 8);
  var info = d.draw.drawTray(bmp.context, W, H, pz.tray.length, d.draw.metal(pz.metal));
  bmp._baseTexture.update();
  this._traySprite = new Sprite(bmp);
  this._traySprite.x = Scene_Escapement.PLATE_X; this._traySprite.y = Scene_Escapement.TRAY_Y;
  this.addChildAt(this._traySprite, this.children.indexOf(this._wheelSprites[0]));
  this._slot = info.slot;
  // the scale a wheel sits at in the tray, per wheel, so the biggest still fits its socket
  this._trayScale = [];
  for (var t = 0; t < pz.tray.length; t++) {
    var R = d.core.outerR(pz.tray[t].n);
    this._trayScale.push(Math.min(1, (Math.min(this._slot, H - 16) * 0.46) / R));
  }
};

Scene_Escapement.prototype.traySlotX = function (t) { return Scene_Escapement.PLATE_X + 8 + this._slot * (t + 0.5); };
Scene_Escapement.prototype.traySlotY = function () { return Scene_Escapement.TRAY_Y + Scene_Escapement.TRAY_H / 2; };

Scene_Escapement.prototype.createCursor = function () {
  var d = this._d;
  this._warnSprite = this.makeDrawn(120, 120, function (ctx) { d.draw.drawWarning(ctx, 58); });
  this._warnSprite.visible = false;
  this._warnSprite.blendMode = 1;
  this.addChild(this._warnSprite);
  this._cursorSprite = this.makeDrawn(60, 60, function (ctx) { d.draw.drawCursor(ctx, 17); });
  this.addChild(this._cursorSprite);
};

/** Put the warning halo where the trouble is: the output (pawl) or the jamming mesh. Change-time only. */
Scene_Escapement.prototype.placeWarning = function (ev) {
  var w = this._warnSprite, pz = this._pz, core = this._d.core;
  var PX = Scene_Escapement.PLATE_X, PY = Scene_Escapement.PLATE_Y;
  if (ev.wrongWay) {
    w.visible = true; w.x = PX + pz.output.x; w.y = PY + pz.output.y;
    this._warnScale = (core.outerR(pz.output.n) + 16) / 58;
  } else if (ev.jam && ev.jamEdge) {
    var u = ev.nodes[ev.jamEdge[0]], v = ev.nodes[ev.jamEdge[1]];
    w.visible = true; w.x = PX + (u.x + v.x) / 2; w.y = PY + (u.y + v.y) / 2;
    this._warnScale = 0.8;
  } else {
    w.visible = false;
  }
};

Scene_Escapement.prototype.createText = function () {
  var d = this._d;
  this._headingSprite = new Sprite(new Bitmap(Graphics.width, 60));
  this._headingSprite.y = 10;
  d.draw.drawHeading(this._headingSprite.bitmap.context, Graphics.width, this._req.title, this._pz.grade);
  this._headingSprite.bitmap._baseTexture.update();
  this._statusSprite = new Sprite(new Bitmap(Graphics.width, 40));
  this._statusSprite.y = Scene_Escapement.PLATE_Y + this._pz.plate.h + 8;
  this.addChild(this._headingSprite);
  this.addChild(this._statusSprite);
};

Scene_Escapement.prototype.setStatus = function (text, tone) {
  if (text === this._status && tone === this._statusTone) return;
  this._status = text; this._statusTone = tone || '';
  this._d.draw.drawStatus(this._statusSprite.bitmap.context, Graphics.width, text, tone);
  this._statusSprite.bitmap._baseTexture.update();
};

//----------------------------------------------------------------------------
// The train. Evaluated only when a wheel moves, never per frame.
//----------------------------------------------------------------------------

Scene_Escapement.prototype.refreshTrain = function (initial) {
  var d = this._d, pz = this._pz;
  var ev = d.core.evaluate(pz, this._placed);
  this._ev = ev;
  // shadows, redrawn only on a change
  var sb = this._shadowSprite.bitmap, ctx = sb.context;
  ctx.clearRect(0, 0, sb.width, sb.height);
  d.draw.drawShadow(ctx, pz.drive.x, pz.drive.y, d.core.outerR(pz.drive.n), 1);
  d.draw.drawShadow(ctx, pz.output.x, pz.output.y, d.core.outerR(pz.output.n), 1);
  for (var a = 0; a < pz.arbors.length; a++) {
    if (this._placed[a] >= 0) d.draw.drawShadow(ctx, pz.arbors[a].x, pz.arbors[a].y, d.core.outerR(pz.tray[this._placed[a]].n), 1);
  }
  sb._baseTexture.update();
  // park every wheel: on its arbor, or in its socket
  var PX = Scene_Escapement.PLATE_X, PY = Scene_Escapement.PLATE_Y;
  var onArbor = [];
  for (var t = 0; t < pz.tray.length; t++) onArbor.push(-1);
  for (var b = 0; b < this._placed.length; b++) if (this._placed[b] >= 0) onArbor[this._placed[b]] = b;
  this._wheelArbor = onArbor;
  for (var w = 0; w < pz.tray.length; w++) {
    var s = this._wheelSprites[w], gl = this._wheelGlints[w];
    if (onArbor[w] >= 0) {
      s.x = PX + pz.arbors[onArbor[w]].x; s.y = PY + pz.arbors[onArbor[w]].y;
      s.scale.x = s.scale.y = 1; s.opacity = 255;
      gl.x = s.x; gl.y = s.y; gl.visible = true;
    } else {
      s.x = this.traySlotX(w); s.y = this.traySlotY();
      s.scale.x = s.scale.y = this._trayScale[w]; s.opacity = 255;
      gl.visible = false;
    }
  }
  if (initial) this.setStatus('Complete the train so ' + Escapement.GOALS[pz.payoff] + '.', '');
  else this.describe(ev);
  this.placeWarning(ev);
  if (ev.solved && this._mode !== 'solving' && this._mode !== 'done') {
    this._mode = 'solving';
    this._progress = 0;
    this.playSe(Escapement.params.solveSe);
  }
};

Scene_Escapement.prototype.describe = function (ev) {
  var pz = this._pz;
  var turning = 0;
  for (var i = 2; i < ev.nodes.length; i++) if (ev.nodes[i] && ev.connected[i]) turning++;
  if (ev.jam) return this.setStatus('Jammed: a loop of an odd number of wheels fights itself.', 'bad');
  if (ev.solved) return this.setStatus('It runs. ' + Escapement.GOALS[pz.payoff].charAt(0).toUpperCase() + Escapement.GOALS[pz.payoff].slice(1) + '.', 'good');
  if (ev.wrongWay) return this.setStatus('The pawl holds: the train reaches it turning the wrong way.', 'bad');
  if (turning === 0) return this.setStatus('Nothing turns yet. Start from the mainspring.', '');
  this.setStatus(turning + (turning === 1 ? ' wheel turns' : ' wheels turn') + ' with the mainspring.', '');
};

//----------------------------------------------------------------------------
// Per frame. Numbers only: no allocation in anything called from update().
//----------------------------------------------------------------------------

Scene_Escapement.prototype.update = function () {
  Scene_Base.prototype.update.call(this);
  this._frame++;
  if (this._mode === 'board' || this._mode === 'tray') this.updateInput();
  this.updateTrain();
  this.updatePayoff();
  this.updateCursor();
  if (this._mode === 'solving') {
    this._progress += 1 / 150;
    if (this._progress >= 1) {
      this._progress = 1;
      this._mode = 'done';
      this._doneWait = 70;
      Escapement.markSolved(this._req, this._placed);
    }
  } else if (this._mode === 'done') {
    if (--this._doneWait <= 0 && !this.isBusy()) { this._mode = 'leaving'; this.popScene(); }
  }
};

Scene_Escapement.prototype.stuck = function () { return this._ev.jam || this._ev.wrongWay; };

Scene_Escapement.prototype.updateTrain = function () {
  var ev = this._ev, pz = this._pz;
  var stuck = this.stuck();
  var speed = Escapement.params.driveSpeed * (this._mode === 'solving' ? 2.2 : 1);
  if (!stuck) this._theta += speed;
  var shake = stuck ? 0.035 * Math.sin(this._frame * 0.9) : 0;
  var th = this._theta + shake;
  this._driveSprite.rotation = th;
  // node 1 is the output; node 2 + a is arbor a
  if (ev.connected[1]) this._outputSprite.rotation = ev.s[1] * th + ev.b[1];
  for (var w = 0; w < this._wheelSprites.length; w++) {
    var a = this._wheelArbor[w];
    var s = this._wheelSprites[w];
    if (a >= 0 && ev.connected[2 + a]) s.rotation = ev.s[2 + a] * th + ev.b[2 + a];
    else s.rotation = this._restAngle[w];
  }
  if (this._flash > 0) this._flash--;
  if (this._warnSprite.visible) {
    var k = this._warnScale * (1 + 0.08 * Math.sin(this._frame * 0.25));
    this._warnSprite.scale.x = this._warnSprite.scale.y = k;
  }
};

/** Smoothstep. */
Scene_Escapement.ease = function (p) { return p * p * (3 - 2 * p); };

Scene_Escapement.prototype.updatePayoff = function () {
  var P = this._payoffParts, pz = this._pz, ev = this._ev;
  var e = Scene_Escapement.ease(this._progress);
  var jitter = ev.wrongWay ? 1.5 * Math.sin(this._frame * 1.3) : 0;
  var outTheta = ev.connected[1] ? this._outputSprite.rotation : 0;
  if (pz.payoff === 'lock') {
    P.bolt.x = P.boltX0 + P.travel * e + jitter;
    P.drawn.visible = this._progress >= 0.98;
    P.shut.visible = !P.drawn.visible;
  } else if (pz.payoff === 'clock') {
    // the hands wind forward and come to rest on the hour
    var mTarget = Math.ceil(P.minute0 / (Math.PI * 2) + 3) * Math.PI * 2;
    P.minute.rotation = P.minute0 + (mTarget - P.minute0) * e + jitter * 0.02;
    P.hour.rotation = P.hour0 + ((Math.PI * 2) - P.hour0) * e + jitter * 0.02;
  } else if (pz.payoff === 'orrery') {
    for (var i = 0; i < 3; i++) {
      var free = P.arm0[i] + P.armRate[i] * outTheta * 0.3;
      // the planets come into conjunction at the top of the ring as the train completes
      P.arms[i].rotation = free * (1 - e) + (-Math.PI / 2 + Math.PI * 2 * (3 - i)) * e + jitter * 0.02;
    }
    P.sun.rotation = this._frame * 0.004;
  } else {
    P.drum.rotation = outTheta * 0.5 + jitter * 0.02;
    P.weight.y = P.bottom - (P.bottom - P.top) * e + jitter;
    P.rope.scale.y = Math.max(1, P.weight.y - P.rope.y - 4);
  }
};

Scene_Escapement.prototype.updateCursor = function () {
  var c = this._cursorSprite, pz = this._pz;
  var pulse = 1 + 0.06 * Math.sin(this._frame * 0.12);
  if (this._mode === 'board') {
    var A = pz.arbors[this._cursor];
    c.visible = true;
    c.x = Scene_Escapement.PLATE_X + A.x; c.y = Scene_Escapement.PLATE_Y + A.y;
    var R = this._placed[this._cursor] >= 0 ? this._d.core.outerR(pz.tray[this._placed[this._cursor]].n) + 6 : 17;
    c.scale.x = c.scale.y = (R / 17) * pulse;
  } else if (this._mode === 'tray') {
    c.visible = true;
    c.x = this.traySlotX(this._trayCursor); c.y = this.traySlotY();
    c.scale.x = c.scale.y = (Math.min(this._slot, Scene_Escapement.TRAY_H - 16) * 0.5 / 17) * pulse;
  } else {
    c.visible = false;
  }
  c.opacity = this._flash > 0 && (this._flash >> 2) % 2 === 0 ? 90 : 255;
};

//----------------------------------------------------------------------------
// Input
//----------------------------------------------------------------------------

Scene_Escapement.prototype.playSe = function (name) {
  if (!name || typeof AudioManager === 'undefined') return;
  AudioManager.playSe({ name: name, volume: 90, pitch: 100, pan: 0 });
};

Scene_Escapement.prototype.updateInput = function () {
  if (TouchInput.isTriggered()) { this.onTouch(TouchInput.x, TouchInput.y); return; }
  if (this._mode === 'board') {
    if (Input.isRepeated('left')) this.moveBoard(-1, 0);
    else if (Input.isRepeated('right')) this.moveBoard(1, 0);
    else if (Input.isRepeated('up')) this.moveBoard(0, -1);
    else if (Input.isRepeated('down')) this.moveBoard(0, 1);
    else if (Input.isTriggered('ok')) this.actOnArbor(this._cursor);
    else if (Input.isTriggered('cancel') || TouchInput.isCancelled()) this.leave();
  } else if (this._mode === 'tray') {
    if (Input.isRepeated('left')) this.moveTray(-1);
    else if (Input.isRepeated('right')) this.moveTray(1);
    else if (Input.isTriggered('ok')) this.placeFromTray(this._trayCursor);
    else if (Input.isTriggered('cancel') || TouchInput.isCancelled()) { this._mode = 'board'; this.playSe(Escapement.params.liftSe); }
  }
};

/** Move to the nearest arbor lying within 60 degrees of the pressed direction. */
Scene_Escapement.prototype.moveBoard = function (dx, dy) {
  var pz = this._pz, A = pz.arbors[this._cursor];
  var best = -1, bestScore = 1e9;
  for (var i = 0; i < pz.arbors.length; i++) {
    if (i === this._cursor) continue;
    var vx = pz.arbors[i].x - A.x, vy = pz.arbors[i].y - A.y;
    var along = vx * dx + vy * dy;
    if (along <= 0) continue;
    var across = Math.abs(vx * dy - vy * dx);
    if (across > along * 1.8) continue;
    var score = along + across * 2;
    if (score < bestScore) { bestScore = score; best = i; }
  }
  if (best >= 0) { this._cursor = best; this.playSe(Escapement.params.cursorSe); }
};

Scene_Escapement.prototype.moveTray = function (dir) {
  var n = this._pz.tray.length;
  for (var step = 1; step <= n; step++) {
    var t = (this._trayCursor + dir * step + n * 4) % n;
    if (this._wheelArbor[t] < 0) { this._trayCursor = t; this.playSe(Escapement.params.cursorSe); return; }
  }
};

Scene_Escapement.prototype.firstFreeTray = function () {
  for (var t = 0; t < this._pz.tray.length; t++) if (this._wheelArbor[t] < 0) return t;
  return -1;
};

Scene_Escapement.prototype.actOnArbor = function (a) {
  if (this._placed[a] >= 0) {
    this._placed[a] = -1;
    this.playSe(Escapement.params.liftSe);
    this.refreshTrain(false);
    return;
  }
  var t = this._wheelArbor[this._trayCursor] < 0 ? this._trayCursor : this.firstFreeTray();
  if (t < 0) { this.refuse('Every wheel is already set.'); return; }
  this._trayCursor = t;
  this._mode = 'tray';
  this.playSe(Escapement.params.cursorSe);
};

var ESC_REASONS = {
  collide: 'No room: it fouls a wheel already there.',
  'covers-post': 'No room: it would cover another pivot.',
  'under-gear': 'No room: a wheel already overhangs this pivot.',
  occupied: 'That arbor already carries a wheel.',
  'in-use': 'That wheel is already set.',
};

Scene_Escapement.prototype.placeFromTray = function (t) {
  var c = this._d.core.canPlace(this._pz, this._placed, this._cursor, t);
  if (!c.ok) { this.refuse(ESC_REASONS[c.reason] || 'No room.'); return; }
  this._placed[this._cursor] = t;
  this._mode = 'board';
  this.playSe(Escapement.params.placeSe);
  this.refreshTrain(false);
  if (this._ev.jam) this.playSe(Escapement.params.refuseSe);
};

Scene_Escapement.prototype.refuse = function (text) {
  this._flash = 24;
  this.playSe(Escapement.params.refuseSe);
  this.setStatus(text, 'bad');
};

Scene_Escapement.prototype.onTouch = function (x, y) {
  var pz = this._pz, PX = Scene_Escapement.PLATE_X, PY = Scene_Escapement.PLATE_Y;
  // a wheel in the tray
  if (y >= Scene_Escapement.TRAY_Y && y <= Scene_Escapement.TRAY_Y + Scene_Escapement.TRAY_H) {
    var t = Math.floor((x - PX - 8) / this._slot);
    if (t >= 0 && t < pz.tray.length && this._wheelArbor[t] < 0) {
      this._trayCursor = t;
      if (this._mode === 'tray') this.placeFromTray(t);
    }
    return;
  }
  // an arbor on the plate
  var best = -1, bestD = 1e9;
  for (var a = 0; a < pz.arbors.length; a++) {
    var dx = x - (PX + pz.arbors[a].x), dy = y - (PY + pz.arbors[a].y);
    var dd = Math.sqrt(dx * dx + dy * dy);
    var reach = this._placed[a] >= 0 ? this._d.core.outerR(pz.tray[this._placed[a]].n) : 22;
    if (dd <= reach && dd < bestD) { bestD = dd; best = a; }
  }
  if (best >= 0) { this._cursor = best; this._mode = 'board'; this.actOnArbor(best); }
};

Scene_Escapement.prototype.leave = function () {
  if (!Escapement.params.allowLeave) { this.refuse('The mechanism must be finished first.'); return; }
  Escapement.remember(this._req, this._placed);
  this.playSe(Escapement.params.liftSe);
  this._mode = 'leaving';
  this.popScene();
};
