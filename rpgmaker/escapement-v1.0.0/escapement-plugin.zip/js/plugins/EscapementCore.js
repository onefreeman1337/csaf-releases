//=============================================================================
// EscapementCore.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Escapement core - generates clockwork gear-train puzzles
 * that are solvable by construction. Place ABOVE EscapementDraw and Escapement.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The puzzle generator and the gear physics for Escapement. It has no
 * parameters and no commands of its own; Escapement.js is the file you
 * configure. It must be installed, and listed above Escapement.js.
 *
 * Pure geometry: nothing here touches the screen, and nothing here uses
 * Math.random. Every puzzle comes from a seed, so the same lock is the same
 * lock on every playthrough and every machine.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var EscapementCore = (function () {
  'use strict';

  //===========================================================================
  // Constants. Units are PLATE UNITS: the scene draws them 1:1 as pixels.
  //===========================================================================

  /** Plate size. The payoff mechanism owns the strip right of PAYOFF_X. */
  var PLATE_W = 640;
  var PLATE_H = 380;
  var PAYOFF_X = 520;
  /** Module: pitch radius = teeth * MODULE / 2; addendum = MODULE. */
  var MODULE = 5;
  /** Two gears mesh when their centre distance is the sum of pitch radii within this. */
  var MESH_TOL = 2;
  /** Clearance kept between gears that must NOT touch, beyond the tips of their teeth. */
  var GAP = 6;
  /** The pivot post of an empty arbor; a gear may not be placed over one. */
  var POST_R = 9;
  /** Tooth counts a loose gear may have. Two teeth apart = 5 plate units apart in radius. */
  var TEETH = [12, 14, 16, 18, 20, 22, 24, 28];
  var DRIVE_TEETH = [18, 20, 24];
  var OUTPUT_TEETH = [14, 16, 18];

  var PAYOFFS = ['lock', 'clock', 'orrery', 'winch'];
  var METALS = ['brass', 'steel', 'bronze', 'verdigris', 'gunmetal'];
  var STYLES = ['disc', 'spokes3', 'spokes4', 'spokes5', 'spokes6', 'curved', 'holes', 'cross'];

  /**
   * Difficulty grades. k = gears in the true train; trap = gears in the
   * wrong-direction route (0 = none); dead = dead-end arbors; decoys = loose
   * gears that belong nowhere.
   */
  var GRADES = {
    1: { k: [3, 3], trap: 0, dead: 0, decoys: 1, pool: [18, 20, 22, 24, 28] },
    2: { k: [3, 4], trap: 0, dead: 1, decoys: 1, pool: [16, 18, 20, 22, 24] },
    3: { k: [4, 4], trap: 1, dead: 1, decoys: 1, pool: [14, 16, 18, 20, 22, 24] },
    4: { k: [4, 5], trap: 1, dead: 2, decoys: 2, pool: [12, 14, 16, 18, 20, 22] },
    5: { k: [5, 6], trap: 2, dead: 2, decoys: 2, pool: [12, 14, 16, 18, 20] },
  };

  //===========================================================================
  // Deterministic randomness
  //===========================================================================

  /**
   * FNV-1a over a string, so a puzzle key like "m3e12" becomes a stable seed.
   * @param {string} s any text @returns {number} unsigned 32-bit hash
   */
  function hashString(s) {
    var h = 0x811c9dc5;
    s = String(s);
    for (var i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 0x01000193) >>> 0;
    }
    return h >>> 0;
  }

  /**
   * mulberry32. The ONLY source of randomness in Escapement.
   * @param {number} seed 32-bit seed @returns {function(): number} in [0,1)
   */
  function rng(seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function pick(r, arr) { return arr[Math.floor(r() * arr.length) % arr.length]; }
  function range(r, lo, hi) { return lo + (hi - lo) * r(); }

  //===========================================================================
  // Gear geometry
  //===========================================================================

  /** @param {number} n teeth @returns {number} pitch radius */
  function pitchR(n) { return n * MODULE / 2; }
  /** @param {number} n teeth @returns {number} radius at the tips of the teeth */
  function outerR(n) { return pitchR(n) + MODULE; }

  function dist(ax, ay, bx, by) { var dx = bx - ax, dy = by - ay; return Math.sqrt(dx * dx + dy * dy); }

  /**
   * How two gears relate.
   * @returns {string} 'mesh' | 'collide' | 'free'
   */
  function relation(ax, ay, na, bx, by, nb) {
    var d = dist(ax, ay, bx, by);
    if (Math.abs(d - (pitchR(na) + pitchR(nb))) <= MESH_TOL) return 'mesh';
    if (d < outerR(na) + outerR(nb) + 1) return 'collide';
    return 'free';
  }

  /**
   * Circle-circle intersection: the points at distance ra from A and rb from B.
   * @returns {Array<{x:number,y:number}>} zero, one or two points
   */
  function intersect(ax, ay, ra, bx, by, rb) {
    var d = dist(ax, ay, bx, by);
    if (d > ra + rb || d < Math.abs(ra - rb) || d === 0) return [];
    var a = (ra * ra - rb * rb + d * d) / (2 * d);
    var h2 = ra * ra - a * a;
    if (h2 < 0) return [];
    var h = Math.sqrt(h2);
    var mx = ax + a * (bx - ax) / d, my = ay + a * (by - ay) / d;
    return [
      { x: mx + h * (by - ay) / d, y: my - h * (bx - ax) / d },
      { x: mx - h * (by - ay) / d, y: my + h * (bx - ax) / d },
    ];
  }

  //===========================================================================
  // Generation
  //===========================================================================

  /**
   * True when a gear of n teeth at (x,y) fits on the plate outside the payoff
   * strip (fixed gears are exempt from the strip and pass allowPayoff).
   */
  function inBounds(x, y, n, allowPayoff) {
    var R = outerR(n) + 4;
    if (x - R < 0 || y - R < 0 || y + R > PLATE_H) return false;
    if (x + R > (allowPayoff ? PLATE_W : PAYOFF_X)) return false;
    return true;
  }

  /**
   * Check a candidate gear against a list of gears that must stay CLEAR of it
   * (everything it is not meant to mesh with) and against arbor posts.
   * @param {Array} others [{x,y,n}] @param {Array} posts [{x,y}] posts it may not cover
   */
  function clearOf(x, y, n, others, posts) {
    for (var i = 0; i < others.length; i++) {
      var o = others[i];
      if (dist(x, y, o.x, o.y) < outerR(n) + outerR(o.n) + GAP) return false;
    }
    for (var j = 0; j < posts.length; j++) {
      if (dist(x, y, posts[j].x, posts[j].y) < outerR(n) + POST_R + 2) return false;
    }
    return true;
  }

  /**
   * Try to lay a train of k loose gears from `from` to `to`, meshing each with
   * the next, keeping clear of `avoid`. The last gear is placed EXACTLY by
   * circle intersection, so the train closes without tolerance games.
   * @returns {Array<{x,y,n}>|null} the loose gears in order, or null
   */
  function layTrain(r, from, to, k, pool, avoid) {
    var chain = [];
    var cur = from;
    for (var i = 0; i < k - 1; i++) {
      var ok = false;
      for (var t = 0; t < 30 && !ok; t++) {
        var n = pick(r, pool);
        var want = Math.atan2(to.y - cur.y, to.x - cur.x);
        var left = k - 1 - i; // gears still to lay after this one, including the closer
        var reach = dist(cur.x, cur.y, to.x, to.y);
        var span = pitchR(cur.n) + pitchR(n);
        // slack: how much further the remaining gears could reach than they need to
        var slack = (reach - span) - 0; var budget = left * 2 * pitchR(pool[pool.length - 1]) + pitchR(to.n);
        var wander = Math.max(0.15, Math.min(1.25, (budget - slack) > 0 ? 0.35 + 0.9 * Math.max(0, 1 - slack / Math.max(1, budget)) : 0.2));
        var ang = want + range(r, -wander, wander);
        var x = cur.x + span * Math.cos(ang);
        var y = cur.y + span * Math.sin(ang);
        if (!inBounds(x, y, n, false)) continue;
        // it must stay clear of everything except the gear it meshes with
        var others = avoid.slice();
        for (var c = 0; c < chain.length - 1; c++) others.push(chain[c]);
        if (chain.length === 0) { /* meshes with `from` */ } else others.push(from);
        if (!clearOf(x, y, n, others.filter(function (o) { return o !== cur; }), [])) continue;
        if (dist(x, y, to.x, to.y) < outerR(n) + outerR(to.n) + GAP) continue;
        var g = { x: x, y: y, n: n };
        chain.push(g);
        cur = g;
        ok = true;
      }
      if (!ok) return null;
    }
    // the closer meshes BOTH the last gear and `to`
    var sizes = pool.slice();
    for (var s = sizes.length - 1; s > 0; s--) { var q = Math.floor(r() * (s + 1)); var tmp = sizes[s]; sizes[s] = sizes[q]; sizes[q] = tmp; }
    for (var si = 0; si < sizes.length; si++) {
      var nn = sizes[si];
      var pts = intersect(cur.x, cur.y, pitchR(cur.n) + pitchR(nn), to.x, to.y, pitchR(to.n) + pitchR(nn));
      if (r() < 0.5) pts.reverse();
      for (var pi = 0; pi < pts.length; pi++) {
        var p = pts[pi];
        if (!inBounds(p.x, p.y, nn, false)) continue;
        var others2 = avoid.slice();
        for (var c2 = 0; c2 < chain.length - 1; c2++) others2.push(chain[c2]);
        if (chain.length > 0) others2.push(from);
        others2 = others2.filter(function (o) { return o !== cur && o !== to; });
        if (!clearOf(p.x, p.y, nn, others2, [])) continue;
        chain.push({ x: p.x, y: p.y, n: nn });
        return chain;
      }
    }
    return null;
  }

  /**
   * Generate one puzzle.
   *
   * The true train is laid first and the puzzle is built around it, so a
   * generated puzzle cannot be unsolvable: the solution is the thing it was
   * made from. Traps (a second route to the output of the WRONG parity, which
   * turns the payoff backwards or jams against the true train) and dead-end
   * arbors are added afterwards and may never cover a solution arbor.
   *
   * @param {Object} opt {seed:number, grade:1..5, payoff?, metal?}
   * @returns {Object} the puzzle (plain data, JSON-safe)
   */
  function generate(opt) {
    opt = opt || {};
    var grade = Math.max(1, Math.min(5, Math.round(Number(opt.grade) || 2)));
    var seed = (Number(opt.seed) >>> 0);
    var G = GRADES[grade];
    for (var attempt = 0; attempt < 400; attempt++) {
      var r = rng((seed ^ Math.imul(attempt + 1, 0x9E3779B1)) >>> 0);
      var p = tryGenerate(r, grade, G);
      if (p) {
        p.seed = seed;
        p.grade = grade;
        p.attempt = attempt;
        var r2 = rng((seed ^ 0xA5A5A5A5) >>> 0);
        p.payoff = PAYOFFS.indexOf(opt.payoff) >= 0 ? opt.payoff : pick(r2, PAYOFFS);
        p.metal = METALS.indexOf(opt.metal) >= 0 ? opt.metal : pick(r2, METALS);
        return p;
      }
    }
    throw new Error('EscapementCore.generate: no layout for seed ' + seed + ' grade ' + grade);
  }

  function tryGenerate(r, grade, G) {
    var drive = { x: range(r, 74, 104), y: range(r, 120, 260), n: pick(r, DRIVE_TEETH), role: 'drive' };
    var output = { x: range(r, 450, 470), y: range(r, 110, 270), n: pick(r, OUTPUT_TEETH), role: 'output' };
    if (!inBounds(drive.x, drive.y, drive.n, false)) return null;
    if (!inBounds(output.x, output.y, output.n, true)) return null;
    var k = G.k[0] + Math.floor(r() * (G.k[1] - G.k[0] + 1));
    var train = layTrain(r, drive, output, k, G.pool, []);
    if (!train) return null;
    // every loose gear must be clear of drive and output except its meshing neighbours
    for (var i = 0; i < train.length; i++) {
      if (i > 0 && relation(train[i].x, train[i].y, train[i].n, drive.x, drive.y, drive.n) !== 'free') return null;
      if (i < train.length - 1 && relation(train[i].x, train[i].y, train[i].n, output.x, output.y, output.n) !== 'free') return null;
      for (var j = i + 2; j < train.length; j++) {
        if (relation(train[i].x, train[i].y, train[i].n, train[j].x, train[j].y, train[j].n) !== 'free') return null;
      }
    }
    var arbors = train.map(function (g) { return { x: g.x, y: g.y, kind: 'train' }; });
    var tray = train.map(function (g) { return { n: g.n, kind: 'train' }; });
    var solid = [drive, output].concat(train);

    // --- the trap: a second route of the WRONG parity from a train gear (or the drive) to the output
    var trapInfo = null;
    if (G.trap > 0) {
      for (var tt = 0; tt < 40 && !trapInfo; tt++) {
        var a = G.trap === 2 ? (r() < 0.5 ? 1 : 2) : 1;
        var j0 = Math.floor(r() * train.length); // branch from train gear j0-1 (0 = drive)
        var from = j0 === 0 ? drive : train[j0 - 1];
        var viaTrue = k - j0; // loose gears between `from` and the output on the true train
        if ((viaTrue - a) % 2 === 0) { a = a === 1 ? 2 : 1; if (a > 2) continue; }
        if ((viaTrue - a) % 2 === 0) continue;
        var avoid = solid.filter(function (g) { return g !== from && g !== output; });
        var alt = layTrain(r, from, output, a, G.pool, avoid);
        if (!alt) continue;
        var allPosts = arbors.slice();
        var fine = true;
        for (var q = 0; q < alt.length && fine; q++) {
          for (var pp = 0; pp < allPosts.length; pp++) {
            if (dist(alt[q].x, alt[q].y, allPosts[pp].x, allPosts[pp].y) < outerR(alt[q].n) + POST_R + 2) { fine = false; break; }
          }
          if (dist(alt[q].x, alt[q].y, drive.x, drive.y) < outerR(alt[q].n) + outerR(drive.n) + GAP && from !== drive) fine = false;
        }
        if (!fine) continue;
        trapInfo = { from: j0, gears: alt.length };
        for (var z = 0; z < alt.length; z++) {
          arbors.push({ x: alt[z].x, y: alt[z].y, kind: 'trap' });
          tray.push({ n: alt[z].n, kind: 'trap' });
        }
      }
      if (!trapInfo) return null;
    }

    // --- dead ends: an arbor a real gear would mesh into, going nowhere
    var deadMade = 0;
    for (var dd = 0; dd < 60 && deadMade < G.dead; dd++) {
      var host = pick(r, [drive].concat(train));
      var dn = pick(r, G.pool);
      var ang = range(r, 0, Math.PI * 2);
      var dx = host.x + (pitchR(host.n) + pitchR(dn)) * Math.cos(ang);
      var dy = host.y + (pitchR(host.n) + pitchR(dn)) * Math.sin(ang);
      if (!inBounds(dx, dy, dn, false)) continue;
      var others = solid.filter(function (g) { return g !== host; });
      if (!clearOf(dx, dy, dn, others, [])) continue;
      var tooNear = false;
      for (var ap = 0; ap < arbors.length; ap++) if (dist(dx, dy, arbors[ap].x, arbors[ap].y) < outerR(dn) + POST_R + 6) tooNear = true;
      if (tooNear) continue;
      arbors.push({ x: dx, y: dy, kind: 'dead' });
      tray.push({ n: dn, kind: 'dead' });
      deadMade++;
    }
    if (deadMade < G.dead) return null;

    // --- decoys: loose gears that fit nowhere on purpose (or fit somewhere wrong)
    for (var dc = 0; dc < G.decoys; dc++) tray.push({ n: pick(r, TEETH), kind: 'decoy' });

    // no solution gear may cover ANY arbor post but its own
    for (var s1 = 0; s1 < train.length; s1++) {
      for (var s2 = 0; s2 < arbors.length; s2++) {
        if (s2 === s1) continue;
        if (dist(train[s1].x, train[s1].y, arbors[s2].x, arbors[s2].y) < outerR(train[s1].n) + POST_R + 2) return null;
      }
    }
    // no arbor post under the drive or the output
    for (var s3 = 0; s3 < arbors.length; s3++) {
      if (dist(drive.x, drive.y, arbors[s3].x, arbors[s3].y) < outerR(drive.n) + POST_R + 2) return null;
      if (dist(output.x, output.y, arbors[s3].x, arbors[s3].y) < outerR(output.n) + POST_R + 2) return null;
    }

    // styles: each tray gear gets its own spoke style; the order on the tray is by size
    tray.forEach(function (t) { t.style = pick(r, STYLES); });
    var order = tray.map(function (t, i) { return i; });
    order.sort(function (x, y) { return tray[x].n - tray[y].n || x - y; });
    var sortedTray = order.map(function (i) { return tray[i]; });
    // the solution, re-expressed against the sorted tray
    var solution = [];
    for (var si = 0; si < train.length; si++) solution.push({ arbor: si, tray: order.indexOf(si) });
    // arbors are shuffled so the train is not readable from the arbor order
    var aord = arbors.map(function (a, i) { return i; });
    for (var sh = aord.length - 1; sh > 0; sh--) { var w = Math.floor(r() * (sh + 1)); var tt2 = aord[sh]; aord[sh] = aord[w]; aord[w] = tt2; }
    var shArbors = aord.map(function (i) { return arbors[i]; });
    solution.forEach(function (s) { s.arbor = aord.indexOf(s.arbor); });

    return {
      v: 1,
      plate: { w: PLATE_W, h: PLATE_H, payoffX: PAYOFF_X },
      drive: { x: drive.x, y: drive.y, n: drive.n },
      output: { x: output.x, y: output.y, n: output.n },
      arbors: shArbors.map(function (a) { return { x: a.x, y: a.y, kind: a.kind }; }),
      tray: sortedTray.map(function (t) { return { n: t.n, style: t.style, kind: t.kind }; }),
      solution: solution,
      trap: trapInfo,
      k: k,
    };
  }

  //===========================================================================
  // The train: who meshes, which way everything turns, and whether it jams
  //===========================================================================

  /**
   * Can this loose gear go on this arbor, given what is already placed?
   * @param {Object} pz puzzle @param {Array<number>} placed placed[arbor] = trayIndex or -1
   * @returns {{ok:boolean, reason:string, blocker:number}} blocker: -2 drive, -3 output,
   *   >= 0 an arbor index whose gear or post is in the way
   */
  function canPlace(pz, placed, arbor, trayIdx) {
    if (placed[arbor] >= 0) return { ok: false, reason: 'occupied', blocker: arbor };
    for (var a = 0; a < placed.length; a++) if (placed[a] === trayIdx) return { ok: false, reason: 'in-use', blocker: a };
    var A = pz.arbors[arbor], n = pz.tray[trayIdx].n;
    var fixed = [pz.drive, pz.output];
    for (var f = 0; f < 2; f++) {
      if (relation(A.x, A.y, n, fixed[f].x, fixed[f].y, fixed[f].n) === 'collide') return { ok: false, reason: 'collide', blocker: -2 - f };
    }
    for (var b = 0; b < pz.arbors.length; b++) {
      if (b === arbor) continue;
      var B = pz.arbors[b];
      if (placed[b] >= 0) {
        if (relation(A.x, A.y, n, B.x, B.y, pz.tray[placed[b]].n) === 'collide') return { ok: false, reason: 'collide', blocker: b };
      } else if (dist(A.x, A.y, B.x, B.y) < outerR(n) + POST_R) {
        return { ok: false, reason: 'covers-post', blocker: b };
      }
      // a gear already standing may not cover THIS post (placement would be under it)
      if (placed[b] >= 0 && dist(A.x, A.y, B.x, B.y) < outerR(pz.tray[placed[b]].n) + POST_R) return { ok: false, reason: 'under-gear', blocker: b };
    }
    return { ok: true, reason: 'ok', blocker: -1 };
  }

  /**
   * Evaluate a placement. Node 0 is the drive, node 1 the output, node 2+a is
   * arbor a. Rotation is propagated breadth-first from the drive; a mesh that
   * asks a gear to turn both ways is a JAM.
   *
   * For every connected node the result gives s (turns per drive turn,
   * signed) and b (phase), so a scene can pose every gear from the drive's
   * angle alone: theta = s * thetaDrive + b. The phase makes teeth interleave
   * at every mesh: a tooth of the driver faces a GAP of the driven.
   *
   * @returns {Object} {nodes, edges, connected, jam, jamEdge, outputDir, solved, wrongWay, s, b}
   */
  function evaluate(pz, placed) {
    var nodes = [
      { x: pz.drive.x, y: pz.drive.y, n: pz.drive.n, arbor: -1 },
      { x: pz.output.x, y: pz.output.y, n: pz.output.n, arbor: -1 },
    ];
    for (var a = 0; a < pz.arbors.length; a++) {
      if (placed[a] >= 0) nodes.push({ x: pz.arbors[a].x, y: pz.arbors[a].y, n: pz.tray[placed[a]].n, arbor: a });
      else nodes.push(null);
    }
    var N = nodes.length;
    var adj = [];
    var edges = [];
    for (var i = 0; i < N; i++) adj.push([]);
    for (var p = 0; p < N; p++) {
      if (!nodes[p]) continue;
      for (var q = p + 1; q < N; q++) {
        if (!nodes[q]) continue;
        if (relation(nodes[p].x, nodes[p].y, nodes[p].n, nodes[q].x, nodes[q].y, nodes[q].n) === 'mesh') {
          adj[p].push(q); adj[q].push(p); edges.push([p, q]);
        }
      }
    }
    var s = new Array(N), b = new Array(N), seen = new Array(N);
    for (var z = 0; z < N; z++) { s[z] = 0; b[z] = 0; seen[z] = false; }
    s[0] = 1; b[0] = 0; seen[0] = true;
    var queue = [0], jam = false, jamEdge = null;
    while (queue.length) {
      var u = queue.shift();
      for (var e = 0; e < adj[u].length; e++) {
        var v = adj[u][e];
        var ratio = nodes[u].n / nodes[v].n;
        var sv = -ratio * s[u];
        if (seen[v]) {
          if (Math.sign(s[v]) !== Math.sign(sv)) { jam = true; if (!jamEdge) jamEdge = [u, v]; }
          continue;
        }
        var phi = Math.atan2(nodes[v].y - nodes[u].y, nodes[v].x - nodes[u].x);
        s[v] = sv;
        b[v] = phi + Math.PI + Math.PI / nodes[v].n - ratio * (b[u] - phi);
        seen[v] = true;
        queue.push(v);
      }
    }
    var connected = seen;
    var outputDir = connected[1] ? Math.sign(s[1]) : 0;
    var need = requiredDir(pz);
    var solved = !jam && connected[1] && outputDir === need;
    return {
      nodes: nodes, edges: edges, connected: connected, jam: jam, jamEdge: jamEdge,
      outputDir: outputDir, requiredDir: need, solved: solved,
      wrongWay: !jam && connected[1] && outputDir !== need,
      s: s, b: b,
    };
  }

  /** The direction the output must turn: whatever the true train gives it. */
  function requiredDir(pz) { return (pz.k % 2 === 1) ? 1 : -1; }

  /** @returns {Array<number>} an empty placement for this puzzle */
  function emptyPlacement(pz) { var a = []; for (var i = 0; i < pz.arbors.length; i++) a.push(-1); return a; }

  /** @returns {Array<number>} the placement the puzzle was built from */
  function solutionPlacement(pz) {
    var a = emptyPlacement(pz);
    pz.solution.forEach(function (s) { a[s.arbor] = s.tray; });
    return a;
  }

  //===========================================================================
  // Solver. Used by the test suite to PROVE every generated puzzle solvable and
  // to grade it; the game itself never needs to search.
  //===========================================================================

  /**
   * Grow the train from the drive one legal meshing gear at a time.
   * @returns {{solutions:number, trapStates:number, jamStates:number, nodes:number, firstSolution:Array|null}}
   */
  function solve(pz, limit) {
    limit = limit || 200000;
    var visited = {};
    var out = { solutions: 0, trapStates: 0, jamStates: 0, nodes: 0, firstSolution: null, capped: false };
    var sols = {};
    var start = emptyPlacement(pz);
    var stack = [start];
    while (stack.length) {
      var placed = stack.pop();
      var key = placed.join(',');
      if (visited[key]) continue;
      visited[key] = true;
      if (++out.nodes > limit) { out.capped = true; break; }
      var ev = evaluate(pz, placed);
      if (ev.jam) { out.jamStates++; continue; }
      if (ev.solved) {
        var sk = placed.map(function (t, i) { return t >= 0 ? i + ':' + pz.tray[t].n : ''; }).filter(Boolean).sort().join('|');
        if (!sols[sk]) { sols[sk] = true; out.solutions++; if (!out.firstSolution) out.firstSolution = placed.slice(); }
        continue;
      }
      if (ev.wrongWay) out.trapStates++;
      for (var a = 0; a < pz.arbors.length; a++) {
        if (placed[a] >= 0) continue;
        var triedN = {};
        for (var t = 0; t < pz.tray.length; t++) {
          var n = pz.tray[t].n;
          if (triedN[n]) continue;
          if (placed.indexOf(t) >= 0) continue;
          var c = canPlace(pz, placed, a, t);
          if (!c.ok) continue;
          // only moves that MESH with a turning gear change anything
          var A = pz.arbors[a], meshes = false;
          for (var m = 0; m < ev.nodes.length && !meshes; m++) {
            if (!ev.nodes[m] || !ev.connected[m]) continue;
            if (relation(A.x, A.y, n, ev.nodes[m].x, ev.nodes[m].y, ev.nodes[m].n) === 'mesh') meshes = true;
          }
          if (!meshes) continue;
          triedN[n] = true;
          var nx = placed.slice(); nx[a] = t;
          stack.push(nx);
        }
      }
    }
    return out;
  }

  /**
   * Distinct things this puzzle draws, for the corpus sweep: every loose gear
   * design (teeth x style x metal) plus the fixed pair.
   */
  function designs(pz) {
    var d = {};
    pz.tray.forEach(function (t) { d[t.n + '/' + t.style + '/' + pz.metal] = true; });
    d['drive/' + pz.drive.n + '/' + pz.metal] = true;
    d['output/' + pz.output.n + '/' + pz.payoff + '/' + pz.metal] = true;
    return Object.keys(d);
  }

  return {
    VERSION: '1.0.0',
    PLATE_W: PLATE_W, PLATE_H: PLATE_H, PAYOFF_X: PAYOFF_X, MODULE: MODULE, MESH_TOL: MESH_TOL,
    POST_R: POST_R, TEETH: TEETH, PAYOFFS: PAYOFFS, METALS: METALS, STYLES: STYLES, GRADES: GRADES,
    hashString: hashString, rng: rng, pitchR: pitchR, outerR: outerR, relation: relation,
    intersect: intersect, generate: generate, canPlace: canPlace, evaluate: evaluate,
    requiredDir: requiredDir, emptyPlacement: emptyPlacement, solutionPlacement: solutionPlacement,
    solve: solve, designs: designs,
  };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = EscapementCore;
