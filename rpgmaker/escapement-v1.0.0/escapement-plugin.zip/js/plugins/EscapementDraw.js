//=============================================================================
// EscapementDraw.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Escapement draw - the gears, the plate, the jewelled
 * arbors and the four payoff mechanisms, all drawn in code. Place BETWEEN
 * EscapementCore and Escapement.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * Every picture Escapement shows is drawn here onto a canvas: no image file is
 * loaded. It has no parameters of its own. It must be installed, below
 * EscapementCore.js and above Escapement.js.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var EscapementDraw = (function () {
  'use strict';

  var TAU = Math.PI * 2;

  /** The face used for every word Escapement sets. Chosen, never MZ's own. */
  var FACE = '"Palatino Linotype", "Book Antiqua", Palatino, "Georgia", serif';

  /**
   * Metals. hi/mid/lo are the face ramp, edge the tooth outline, cut the colour
   * an engraved line reads in, glint the specular.
   */
  var METALS = {
    brass:     { hi: '#f4dd97', mid: '#c89b45', lo: '#7d5a1e', edge: '#4a3310', cut: '#5c4115', glint: 'rgba(255,248,214,0.55)', plateHi: '#e6c77a', plateMid: '#b98f3f', plateLo: '#6e4f1b' },
    steel:     { hi: '#e3e8ee', mid: '#8e9aa8', lo: '#46505c', edge: '#1f252c', cut: '#2c343d', glint: 'rgba(240,248,255,0.6)', plateHi: '#b9c6d6', plateMid: '#5f7288', plateLo: '#2b3748' },
    bronze:    { hi: '#e7b98a', mid: '#a86b3c', lo: '#5c3419', edge: '#2e190b', cut: '#442511', glint: 'rgba(255,232,210,0.5)', plateHi: '#d09a68', plateMid: '#8e5630', plateLo: '#4a2912' },
    verdigris: { hi: '#b9e2cf', mid: '#5f9f86', lo: '#2c5647', edge: '#15302a', cut: '#1f4036', glint: 'rgba(225,255,240,0.45)', plateHi: '#9fc9b3', plateMid: '#4d8570', plateLo: '#223f35' },
    gunmetal:  { hi: '#b8b4c4', mid: '#5e5a6c', lo: '#2a2733', edge: '#111016', cut: '#1b1a22', glint: 'rgba(235,230,255,0.5)', plateHi: '#8f8aa0', plateMid: '#454152', plateLo: '#1f1d27' },
  };

  /** Payoff mechanisms are cut in a second alloy so they read as a different part. */
  var ACCENT = { brass: 'steel', steel: 'brass', bronze: 'brass', verdigris: 'bronze', gunmetal: 'brass' };

  //===========================================================================
  // Small helpers
  //===========================================================================

  function rng(seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function metal(name) { return METALS[name] || METALS.brass; }

  /** A face gradient lit from the upper left. */
  function faceGrad(ctx, R, m) {
    var g = ctx.createLinearGradient(-R, -R, R, R);
    g.addColorStop(0, m.hi);
    g.addColorStop(0.45, m.mid);
    g.addColorStop(1, m.lo);
    return g;
  }

  /** Set text engraved into metal: a dark cut with a light lip below it. */
  function engrave(ctx, text, x, y, size, m, align, weight) {
    ctx.save();
    ctx.font = (weight || '') + ' ' + size + 'px ' + FACE;
    ctx.textAlign = align || 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = 'rgba(255,255,255,0.35)';
    ctx.fillText(text, x, y + 1);
    ctx.fillStyle = m.cut;
    ctx.fillText(text, x, y);
    ctx.restore();
  }

  /** A slotted screw head. */
  function screw(ctx, x, y, r, m, ang) {
    ctx.save();
    ctx.translate(x, y);
    var g = ctx.createRadialGradient(-r * 0.35, -r * 0.35, r * 0.1, 0, 0, r);
    g.addColorStop(0, m.hi); g.addColorStop(0.6, m.mid); g.addColorStop(1, m.lo);
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fill();
    ctx.strokeStyle = m.edge; ctx.lineWidth = 1; ctx.stroke();
    ctx.rotate(ang || 0.6);
    ctx.fillStyle = m.edge;
    ctx.fillRect(-r * 0.85, -r * 0.14, r * 1.7, r * 0.28);
    ctx.restore();
  }

  /** A jewel bearing in a gold chaton: what an arbor pivots in. */
  function jewel(ctx, x, y, s) {
    ctx.save();
    ctx.translate(x, y);
    var gold = METALS.brass;
    var g = ctx.createRadialGradient(-s * 0.3, -s * 0.3, 1, 0, 0, s);
    g.addColorStop(0, gold.hi); g.addColorStop(0.7, gold.mid); g.addColorStop(1, gold.lo);
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(0, 0, s, 0, TAU); ctx.fill();
    ctx.strokeStyle = gold.edge; ctx.lineWidth = 1; ctx.stroke();
    // the ruby
    var rr = s * 0.55;
    var rg = ctx.createRadialGradient(-rr * 0.3, -rr * 0.35, 0.5, 0, 0, rr);
    rg.addColorStop(0, '#ffb3c1'); rg.addColorStop(0.35, '#d4213f'); rg.addColorStop(1, '#5a0714');
    ctx.fillStyle = rg;
    ctx.beginPath(); ctx.arc(0, 0, rr, 0, TAU); ctx.fill();
    // the pivot hole
    ctx.fillStyle = '#1a0205';
    ctx.beginPath(); ctx.arc(0, 0, rr * 0.28, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.75)';
    ctx.beginPath(); ctx.arc(-rr * 0.35, -rr * 0.4, rr * 0.18, 0, TAU); ctx.fill();
    ctx.restore();
  }

  //===========================================================================
  // Gears
  //===========================================================================

  /**
   * Trace a gear's tooth outline as one closed path.
   * Teeth are centred on angles k * 2pi / n, tooth 0 pointing along +x, so a
   * sprite rotated by theta shows a tooth at theta: the same convention
   * EscapementCore.evaluate uses to make teeth interleave.
   */
  function toothPath(ctx, n, module) {
    var r = n * module / 2;
    var ra = r + module;          // tip
    var rf = r - 1.25 * module;   // root
    var p = TAU / n;
    ctx.beginPath();
    for (var k = 0; k < n; k++) {
      var c = k * p;
      // root flank, pitch flank, tip land, pitch flank, root flank: a trapezoid with curved flanks
      var pts = [
        [rf, c - 0.5 * p], [rf, c - 0.30 * p], [r, c - 0.24 * p], [ra - 0.3, c - 0.15 * p],
        [ra, c - 0.10 * p], [ra, c + 0.10 * p], [ra - 0.3, c + 0.15 * p], [r, c + 0.24 * p], [rf, c + 0.30 * p],
      ];
      for (var i = 0; i < pts.length; i++) {
        var x = pts[i][0] * Math.cos(pts[i][1]), y = pts[i][0] * Math.sin(pts[i][1]);
        if (k === 0 && i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
    }
    ctx.closePath();
  }

  /**
   * Cut the web of a wheel: the spokes, windows or holes between rim and hub.
   * Drawn as holes in an even-odd path so the plate shows through.
   */
  function webHoles(ctx, style, rIn, hub, seed) {
    var i, a, n;
    if (style === 'disc') return;
    if (style.indexOf('spokes') === 0 || style === 'curved') {
      n = style === 'curved' ? 5 : Number(style.slice(6));
      var spokeHalf = Math.max(0.09, 0.5 / n) * (style === 'curved' ? 0.9 : 1);
      var gapHalf = Math.PI / n - spokeHalf;
      for (i = 0; i < n; i++) {
        a = i * TAU / n + Math.PI / n;
        ctx.moveTo((hub + 3) * Math.cos(a - gapHalf * 0.7), (hub + 3) * Math.sin(a - gapHalf * 0.7));
        if (style === 'curved') {
          var bend = 0.45;
          ctx.quadraticCurveTo((rIn * 0.55) * Math.cos(a - gapHalf + bend), (rIn * 0.55) * Math.sin(a - gapHalf + bend),
            rIn * Math.cos(a - gapHalf + bend * 0.6), rIn * Math.sin(a - gapHalf + bend * 0.6));
          ctx.arc(0, 0, rIn, a - gapHalf + bend * 0.6, a + gapHalf + bend * 0.6);
          ctx.quadraticCurveTo((rIn * 0.55) * Math.cos(a + gapHalf + bend), (rIn * 0.55) * Math.sin(a + gapHalf + bend),
            (hub + 3) * Math.cos(a + gapHalf * 0.7), (hub + 3) * Math.sin(a + gapHalf * 0.7));
        } else {
          ctx.lineTo(rIn * Math.cos(a - gapHalf), rIn * Math.sin(a - gapHalf));
          ctx.arc(0, 0, rIn, a - gapHalf, a + gapHalf);
          ctx.lineTo((hub + 3) * Math.cos(a + gapHalf * 0.7), (hub + 3) * Math.sin(a + gapHalf * 0.7));
        }
        ctx.closePath();
      }
      return;
    }
    if (style === 'holes') {
      n = rIn > 38 ? 6 : 5;
      var ring = (rIn + hub) / 2, hr = Math.min((rIn - hub) * 0.36, ring * Math.sin(Math.PI / n) * 0.72);
      for (i = 0; i < n; i++) {
        a = i * TAU / n;
        ctx.moveTo(ring * Math.cos(a) + hr, ring * Math.sin(a));
        ctx.arc(ring * Math.cos(a), ring * Math.sin(a), hr, 0, TAU);
        ctx.closePath();
      }
      return;
    }
    if (style === 'cross') {
      // four windows shaped like a crossing of two bars: each window a quarter annulus pinched at the bars
      for (i = 0; i < 4; i++) {
        a = i * TAU / 4 + Math.PI / 4;
        var hw = Math.PI / 4 - 0.22;
        ctx.moveTo((hub + 6) * Math.cos(a), (hub + 6) * Math.sin(a));
        ctx.lineTo(rIn * Math.cos(a - hw), rIn * Math.sin(a - hw));
        ctx.arc(0, 0, rIn, a - hw, a + hw);
        ctx.closePath();
      }
    }
  }

  /**
   * Draw one wheel centred at the context origin.
   * @param {CanvasRenderingContext2D} ctx
   * @param {Object} spec {n, module, style, metal, role:'loose'|'drive'|'output', seed}
   * @returns {{ops:number}} a count of construction steps, for the sabotage suite
   */
  function drawGear(ctx, spec) {
    var ops = 0;
    var m = metal(spec.metal);
    var n = spec.n, mod = spec.module || 5;
    var r = n * mod / 2, ra = r + mod, rf = r - 1.25 * mod;
    var rim = rf - Math.max(4, mod * 1.1);
    var hub = Math.max(7, r * 0.2);
    var style = spec.role === 'drive' ? 'disc' : (spec.style || 'spokes5');

    ctx.save();
    // teeth and wheel body in one even-odd path, holes cut out
    toothPath(ctx, n, mod);
    webHoles(ctx, style, rim, hub, spec.seed || 0);
    // the bore
    ctx.moveTo(hub * 0.35, 0); ctx.arc(0, 0, hub * 0.35, 0, TAU);
    ctx.fillStyle = faceGrad(ctx, ra, m);
    ctx.fill('evenodd'); ops++;
    ctx.strokeStyle = m.edge; ctx.lineWidth = 1.2; ctx.stroke(); ops++;

    // circular graining across the face, the watchmaker's finish
    ctx.save();
    toothPath(ctx, n, mod); webHoles(ctx, style, rim, hub, 0);
    ctx.clip('evenodd');
    ctx.lineWidth = 0.6;
    for (var cr = hub + 2; cr < rf; cr += 2.2) {
      ctx.strokeStyle = (Math.round(cr * 7) % 3 === 0) ? 'rgba(255,255,255,0.10)' : 'rgba(0,0,0,0.07)';
      ctx.beginPath(); ctx.arc(0, 0, cr, 0, TAU); ctx.stroke();
    }
    ops++;
    ctx.restore();

    // the rim: a raised ring with a light inner lip and a dark outer groove
    ctx.lineWidth = 1.4;
    ctx.strokeStyle = 'rgba(0,0,0,0.35)';
    ctx.beginPath(); ctx.arc(0, 0, rf - 1, 0, TAU); ctx.stroke();
    if (style !== 'disc') {
      ctx.strokeStyle = 'rgba(255,255,255,0.35)';
      ctx.beginPath(); ctx.arc(0, 0, rim - 0.5, 0, TAU); ctx.stroke();
      ctx.strokeStyle = m.edge; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(0, 0, rim + 0.6, 0, TAU); ctx.stroke();
    }
    ops++;

    if (spec.role === 'drive') {
      // a mainspring barrel: a closed drum, its cover engraved with the coiled spring
      ctx.strokeStyle = m.cut; ctx.lineWidth = 1.2;
      ctx.beginPath();
      for (var t = 0; t < 7 * TAU; t += 0.08) {
        var rr = hub + 2 + (rim - hub - 6) * (t / (7 * TAU));
        var x = rr * Math.cos(t), y = rr * Math.sin(t);
        if (t === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.stroke(); ops++;
      // ratchet wheel on the arbor
      var rw = hub * 1.9;
      ctx.beginPath();
      for (var q = 0; q < 16; q++) {
        var a0 = q * TAU / 16;
        ctx.lineTo(rw * Math.cos(a0), rw * Math.sin(a0));
        ctx.lineTo(rw * 0.78 * Math.cos(a0 + TAU / 16 * 0.85), rw * 0.78 * Math.sin(a0 + TAU / 16 * 0.85));
      }
      ctx.closePath();
      var sm = metal(ACCENT[spec.metal] || 'steel');
      ctx.fillStyle = faceGrad(ctx, rw, sm); ctx.fill(); ctx.strokeStyle = sm.edge; ctx.stroke(); ops++;
    } else if (style === 'disc') {
      // a solid wheel gets a turned recess and a ring of index dots
      ctx.strokeStyle = m.cut; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(0, 0, (rf + hub) * 0.55, 0, TAU); ctx.stroke();
      ctx.fillStyle = m.cut;
      var dots = Math.max(6, Math.round(n / 2));
      for (var d = 0; d < dots; d++) {
        var da = d * TAU / dots;
        ctx.beginPath(); ctx.arc((rf - 5) * Math.cos(da), (rf - 5) * Math.sin(da), 1.1, 0, TAU); ctx.fill();
      }
      ops++;
    }

    // hub boss with three screws and the arbor
    ctx.beginPath(); ctx.arc(0, 0, hub, 0, TAU);
    var hg = ctx.createRadialGradient(-hub * 0.4, -hub * 0.4, 1, 0, 0, hub);
    hg.addColorStop(0, m.hi); hg.addColorStop(1, m.lo);
    ctx.fillStyle = hg; ctx.fill(); ctx.strokeStyle = m.edge; ctx.lineWidth = 1; ctx.stroke(); ops++;
    if (hub >= 9) {
      for (var s = 0; s < 3; s++) {
        var sa = s * TAU / 3 + 0.5;
        screw(ctx, hub * 0.62 * Math.cos(sa), hub * 0.62 * Math.sin(sa), Math.max(1.6, hub * 0.2), metal(ACCENT[spec.metal] || 'steel'), sa * 2);
      }
      ops++;
    }
    var sm2 = metal(ACCENT[spec.metal] || 'steel');
    ctx.beginPath(); ctx.arc(0, 0, Math.max(2.5, hub * 0.3), 0, TAU);
    ctx.fillStyle = sm2.mid; ctx.fill(); ctx.strokeStyle = sm2.edge; ctx.stroke();
    // a timing mark on tooth 0, so a turning wheel visibly turns
    ctx.fillStyle = m.cut;
    ctx.beginPath(); ctx.arc(rf - 3.5, 0, 1.6, 0, TAU); ctx.fill(); ops++;
    ctx.restore();
    return { ops: ops };
  }

  /** Soft cast shadow of a wheel, drawn on the plate beneath it (it does not turn). */
  function drawShadow(ctx, x, y, R, strength) {
    var g = ctx.createRadialGradient(x + 5, y + 7, R * 0.6, x + 5, y + 7, R + 7);
    g.addColorStop(0, 'rgba(0,0,0,' + (0.45 * strength) + ')');
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(x + 5, y + 7, R + 7, 0, TAU); ctx.fill();
  }

  /** The fixed glint over a wheel: light does not turn with the metal. */
  function drawGlint(ctx, R, m) {
    var g = ctx.createRadialGradient(-R * 0.38, -R * 0.42, 1, -R * 0.2, -R * 0.25, R * 0.95);
    g.addColorStop(0, m.glint);
    g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(0, 0, R, 0, TAU); ctx.fill();
  }

  //===========================================================================
  // The plate
  //===========================================================================

  /**
   * The bench: a dark leather mat under the plate, vignetted, with a faint grid
   * of stitching, so the plate sits on SOMETHING.
   */
  function drawBench(ctx, W, H, metalName) {
    var g = ctx.createRadialGradient(W / 2, H * 0.42, 60, W / 2, H / 2, W * 0.75);
    g.addColorStop(0, '#3a2a22');
    g.addColorStop(0.6, '#23180f');
    g.addColorStop(1, '#0b0705');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    // leather grain
    var r = rng(0xBEEF);
    for (var i = 0; i < 2600; i++) {
      ctx.fillStyle = r() < 0.5 ? 'rgba(255,230,200,0.035)' : 'rgba(0,0,0,0.08)';
      ctx.fillRect(r() * W, r() * H, 1 + r() * 2, 1);
    }
    // saddle stitching round the edge
    ctx.strokeStyle = 'rgba(214,176,120,0.35)'; ctx.lineWidth = 1.2; ctx.setLineDash([6, 5]);
    ctx.strokeRect(14.5, 14.5, W - 29, H - 29);
    ctx.setLineDash([]);
  }

  /**
   * The mechanism plate itself, in the puzzle's metal, with its bevel, brushed
   * finish, engraved border, corner screws, and the payoff strip ruled off.
   * @param {CanvasRenderingContext2D} ctx context translated so the plate starts at 0,0
   */
  function drawPlate(ctx, pz, title) {
    var W = pz.plate.w, H = pz.plate.h, m = metal(pz.metal);
    var r = rng((pz.seed >>> 0) ^ 0x51ED);
    // drop shadow
    ctx.fillStyle = 'rgba(0,0,0,0.55)';
    roundRect(ctx, 6, 9, W, H, 14); ctx.fill();
    // body
    var g = ctx.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, m.plateHi); g.addColorStop(0.5, m.plateMid); g.addColorStop(1, m.plateLo);
    ctx.fillStyle = g;
    roundRect(ctx, 0, 0, W, H, 14); ctx.fill();
    // brushed finish: long faint horizontal strokes
    ctx.save(); roundRect(ctx, 0, 0, W, H, 14); ctx.clip();
    for (var i = 0; i < 520; i++) {
      var y = r() * H, x = r() * W, len = 40 + r() * 180;
      ctx.strokeStyle = r() < 0.5 ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)';
      ctx.lineWidth = 0.7;
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + len, y + (r() - 0.5)); ctx.stroke();
    }
    // Geneva stripes across the train side: the watchmaker's decorated plate
    ctx.globalAlpha = 0.09;
    for (var sx = -H; sx < pz.plate.payoffX; sx += 22) {
      var sg = ctx.createLinearGradient(sx, 0, sx + 22, 0);
      sg.addColorStop(0, '#000'); sg.addColorStop(0.5, '#fff'); sg.addColorStop(1, '#000');
      ctx.fillStyle = sg;
      ctx.beginPath(); ctx.moveTo(sx, 0); ctx.lineTo(sx + 22, 0); ctx.lineTo(sx + 22 + H * 0.35, H); ctx.lineTo(sx + H * 0.35, H); ctx.closePath(); ctx.fill();
    }
    ctx.globalAlpha = 1;
    ctx.restore();
    // bevel
    ctx.lineWidth = 3;
    ctx.strokeStyle = 'rgba(255,255,255,0.45)';
    ctx.beginPath(); ctx.moveTo(4, H - 14); ctx.lineTo(4, 14); ctx.quadraticCurveTo(4, 4, 14, 4); ctx.lineTo(W - 14, 4); ctx.stroke();
    ctx.strokeStyle = 'rgba(0,0,0,0.5)';
    ctx.beginPath(); ctx.moveTo(W - 4, 14); ctx.lineTo(W - 4, H - 14); ctx.quadraticCurveTo(W - 4, H - 4, W - 14, H - 4); ctx.lineTo(14, H - 4); ctx.stroke();
    // engraved double border with a knot at each corner
    ctx.strokeStyle = m.cut; ctx.lineWidth = 1.2;
    roundRect(ctx, 14, 14, W - 28, H - 28, 8); ctx.stroke();
    ctx.lineWidth = 0.7;
    roundRect(ctx, 19, 19, W - 38, H - 38, 6); ctx.stroke();
    var corners = [[30, 30], [W - 30, 30], [30, H - 30], [W - 30, H - 30]];
    for (var c = 0; c < 4; c++) screw(ctx, corners[c][0], corners[c][1], 6.5, m, 0.4 + c * 1.1);
    // the payoff strip, ruled off
    ctx.strokeStyle = m.cut; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.moveTo(pz.plate.payoffX, 26); ctx.lineTo(pz.plate.payoffX, H - 26); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.3)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(pz.plate.payoffX + 1.5, 26); ctx.lineTo(pz.plate.payoffX + 1.5, H - 26); ctx.stroke();
    if (title) engrave(ctx, title, pz.plate.payoffX / 2, 22 + 12, 15, m, 'center', 'italic');
  }

  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.closePath();
  }

  /** An empty arbor: a jewelled pivot in a sink, with two chaton screws. */
  function drawArbor(ctx, x, y, m) {
    ctx.fillStyle = 'rgba(0,0,0,0.28)';
    ctx.beginPath(); ctx.arc(x + 1, y + 1.5, 12, 0, TAU); ctx.fill();
    ctx.strokeStyle = m.cut; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(x, y, 12, 0, TAU); ctx.stroke();
    jewel(ctx, x, y, 8);
    screw(ctx, x - 14, y - 7, 2.6, metal('steel'), 0.3);
    screw(ctx, x + 14, y + 7, 2.6, metal('steel'), 1.9);
  }

  /**
   * A curved engraved arrow telling the player which way a wheel must turn,
   * centred on the side `at` (radians) that the caller found clear of arbors.
   */
  function drawTurnArrow(ctx, x, y, R, dir, m, label, at) {
    if (at === undefined) at = -Math.PI * 0.6;
    ctx.save();
    ctx.strokeStyle = m.cut; ctx.fillStyle = m.cut; ctx.lineWidth = 2.2;
    var a0 = at - Math.PI * 0.26, a1 = at + Math.PI * 0.26;
    ctx.beginPath(); ctx.arc(x, y, R + 12, a0, a1); ctx.stroke();
    var tip = dir > 0 ? a1 : a0;
    var tx = x + (R + 12) * Math.cos(tip), ty = y + (R + 12) * Math.sin(tip);
    var tang = tip + (dir > 0 ? Math.PI / 2 : -Math.PI / 2);
    ctx.beginPath();
    ctx.moveTo(tx + 7 * Math.cos(tang), ty + 7 * Math.sin(tang));
    ctx.lineTo(tx + 5 * Math.cos(tang + 2.4), ty + 5 * Math.sin(tang + 2.4));
    ctx.lineTo(tx + 5 * Math.cos(tang - 2.4), ty + 5 * Math.sin(tang - 2.4));
    ctx.closePath(); ctx.fill();
    if (label) engrave(ctx, label, x + (R + 30) * Math.cos(at), y + (R + 30) * Math.sin(at), 12, m, 'center', 'italic');
    ctx.restore();
  }

  /**
   * The same arrow as a HINT that sits above the wheels: cream on a dark
   * outline, so a wheel set beside the output can never hide which way it must
   * turn. Drawn centred on the origin (the output's arbor).
   */
  function drawTurnHint(ctx, R, dir, label, at) {
    ctx.save();
    var a0 = at - Math.PI * 0.26, a1 = at + Math.PI * 0.26, rr = R + 12;
    var tip = dir > 0 ? a1 : a0;
    var tx = rr * Math.cos(tip), ty = rr * Math.sin(tip);
    var tang = tip + (dir > 0 ? Math.PI / 2 : -Math.PI / 2);
    for (var pass = 0; pass < 2; pass++) {
      ctx.strokeStyle = pass === 0 ? 'rgba(20,10,4,0.85)' : '#f6e6bd';
      ctx.fillStyle = ctx.strokeStyle;
      ctx.lineWidth = pass === 0 ? 5 : 2.2;
      ctx.beginPath(); ctx.arc(0, 0, rr, a0, a1); ctx.stroke();
      var s = pass === 0 ? 9.5 : 7;
      ctx.beginPath();
      ctx.moveTo(tx + s * Math.cos(tang), ty + s * Math.sin(tang));
      ctx.lineTo(tx + (s - 2) * Math.cos(tang + 2.4), ty + (s - 2) * Math.sin(tang + 2.4));
      ctx.lineTo(tx + (s - 2) * Math.cos(tang - 2.4), ty + (s - 2) * Math.sin(tang - 2.4));
      ctx.closePath(); ctx.fill();
    }
    if (label) {
      var lx = (R + 32) * Math.cos(at), ly = (R + 32) * Math.sin(at);
      ctx.font = 'italic 13px ' + FACE; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      var w = ctx.measureText(label).width + 12;
      ctx.fillStyle = 'rgba(20,10,4,0.72)'; roundRect(ctx, lx - w / 2, ly - 9, w, 18, 8); ctx.fill();
      ctx.fillStyle = '#f6e6bd'; ctx.fillText(label, lx, ly + 0.5);
    }
    ctx.restore();
  }

  /**
   * Pick the side of a fixed wheel to engrave its arrow on: the direction whose
   * label point lies farthest from every arbor (padded by the biggest loose
   * wheel), from the other fixed wheel, and inside the plate.
   * @returns {number} angle in radians
   */
  function clearSide(pz, cx, cy, R, other, maxLooseR, xMax) {
    var best = -Math.PI / 2, bestScore = -1e9;
    for (var k = 0; k < 16; k++) {
      var at = -Math.PI + k * TAU / 16;
      var lx = cx + (R + 30) * Math.cos(at), ly = cy + (R + 30) * Math.sin(at);
      var score = 1e9;
      for (var i = 0; i < pz.arbors.length; i++) {
        var dx = lx - pz.arbors[i].x, dy = ly - pz.arbors[i].y;
        score = Math.min(score, Math.sqrt(dx * dx + dy * dy) - maxLooseR - 10);
      }
      var ox = lx - other.x, oy = ly - other.y;
      score = Math.min(score, Math.sqrt(ox * ox + oy * oy) - other.R - 10);
      score = Math.min(score, lx - 40, (xMax - 40) - lx, ly - 34, (pz.plate.h - 34) - ly);
      if (score > bestScore) { bestScore = score; best = at; }
    }
    return best;
  }

  //===========================================================================
  // Payoffs: the thing the train is FOR. Each is a static base plus moving parts
  // returned as separate drawings so the scene can move them without redrawing.
  //===========================================================================

  /**
   * Draw a payoff's static base into the strip right of payoffX.
   * @returns {Object} anchor points the moving parts use
   */
  function drawPayoffBase(ctx, pz) {
    var m = metal(pz.metal), a = metal(ACCENT[pz.metal] || 'steel');
    var x0 = pz.plate.payoffX, W = pz.plate.w - x0, H = pz.plate.h, cx = x0 + W / 2;
    var oy = pz.output.y;
    if (pz.payoff === 'lock') {
      // a keeper housing the bolt slides in, riveted; a keyhole escutcheon above it and a
      // window below that reads SHUT or DRAWN (the window's words are a moving part)
      ctx.fillStyle = faceGrad(ctx, 80, a);
      roundRect(ctx, x0 + 10, oy - 30, W - 22, 60, 6); ctx.fill();
      ctx.strokeStyle = a.edge; ctx.lineWidth = 1.2; ctx.stroke();
      for (var i = 0; i < 4; i++) screw(ctx, x0 + 22 + i * ((W - 46) / 3), oy - 22, 2.8, m, i);
      for (var j = 0; j < 4; j++) screw(ctx, x0 + 22 + j * ((W - 46) / 3), oy + 22, 2.8, m, j + 2);
      ctx.fillStyle = 'rgba(0,0,0,0.55)';
      roundRect(ctx, x0 + 14, oy - 11, W - 30, 22, 3); ctx.fill();
      // escutcheon: a shield-shaped plate with a pierced keyhole, placed where there is room
      var ey = oy > H / 2 ? oy - 108 : oy + 108;
      ctx.save(); ctx.translate(cx, ey);
      ctx.fillStyle = 'rgba(0,0,0,0.35)';
      ctx.beginPath(); ctx.moveTo(3, -38); ctx.quadraticCurveTo(35, -34, 33, 2); ctx.quadraticCurveTo(28, 30, 3, 44); ctx.quadraticCurveTo(-24, 30, -27, 2); ctx.quadraticCurveTo(-29, -34, 3, -38); ctx.fill();
      ctx.fillStyle = faceGrad(ctx, 40, a);
      ctx.beginPath(); ctx.moveTo(0, -40); ctx.quadraticCurveTo(32, -36, 30, 0); ctx.quadraticCurveTo(26, 28, 0, 42); ctx.quadraticCurveTo(-26, 28, -30, 0); ctx.quadraticCurveTo(-32, -36, 0, -40); ctx.fill();
      ctx.strokeStyle = a.edge; ctx.lineWidth = 1.2; ctx.stroke();
      ctx.strokeStyle = a.cut; ctx.lineWidth = 0.8;
      ctx.beginPath(); ctx.moveTo(0, -34); ctx.quadraticCurveTo(26, -30, 24, 0); ctx.quadraticCurveTo(21, 23, 0, 35); ctx.quadraticCurveTo(-21, 23, -24, 0); ctx.quadraticCurveTo(-26, -30, 0, -34); ctx.stroke();
      ctx.fillStyle = '#0c0806';
      ctx.beginPath(); ctx.arc(0, -6, 8, 0, TAU); ctx.fill();
      ctx.beginPath(); ctx.moveTo(-5, -1); ctx.lineTo(5, -1); ctx.lineTo(7, 20); ctx.lineTo(-7, 20); ctx.closePath(); ctx.fill();
      screw(ctx, 0, -29, 3, m, 0.2); screw(ctx, 0, 32, 3, m, 1.2);
      ctx.restore();
      // the indicator window
      var wy = oy > H / 2 ? oy + 50 : oy - 50;
      ctx.fillStyle = faceGrad(ctx, 30, a); roundRect(ctx, cx - 34, wy - 13, 68, 26, 5); ctx.fill();
      ctx.strokeStyle = a.edge; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = '#120c08'; roundRect(ctx, cx - 28, wy - 8, 56, 16, 3); ctx.fill();
      engrave(ctx, 'STRONGROOM', cx, 52, 12, m, 'center', 'bold');
      // the bolt: 64 long, poking 26 out of the keeper toward the pinion, withdrawing fully inside
      var slotX = x0 + 14, slotW = W - 30, L = 64;
      return { bolt: { x: slotX, y: oy, w: slotW, len: L, left0: slotX - 26, travel: (slotW - L - 3) + 26 }, window: { x: cx, y: wy } };
    }
    if (pz.payoff === 'clock') {
      var cy = H / 2 + 6, R = Math.min(W / 2 - 8, 56);
      // enamel dial, chapter ring, roman hours
      ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.arc(cx + 3, cy + 4, R + 6, 0, TAU); ctx.fill();
      ctx.fillStyle = faceGrad(ctx, R + 6, m); ctx.beginPath(); ctx.arc(cx, cy, R + 6, 0, TAU); ctx.fill();
      var eg = ctx.createRadialGradient(cx - R * 0.3, cy - R * 0.3, 4, cx, cy, R);
      eg.addColorStop(0, '#fffdf6'); eg.addColorStop(1, '#e8dfc9');
      ctx.fillStyle = eg; ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.fill();
      ctx.strokeStyle = '#2b2118'; ctx.lineWidth = 0.8;
      ctx.beginPath(); ctx.arc(cx, cy, R - 3, 0, TAU); ctx.stroke();
      ctx.beginPath(); ctx.arc(cx, cy, R - 14, 0, TAU); ctx.stroke();
      for (var t = 0; t < 60; t++) {
        var ta = t * TAU / 60, l = t % 5 === 0 ? 5 : 2.5;
        ctx.beginPath(); ctx.moveTo(cx + (R - 3) * Math.cos(ta), cy + (R - 3) * Math.sin(ta));
        ctx.lineTo(cx + (R - 3 - l) * Math.cos(ta), cy + (R - 3 - l) * Math.sin(ta)); ctx.stroke();
      }
      var RN = ['XII', 'I', 'II', 'III', 'IIII', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI'];
      ctx.fillStyle = '#2b2118'; ctx.font = '9px ' + FACE; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      for (var h = 0; h < 12; h++) {
        var ha = h * TAU / 12 - Math.PI / 2;
        ctx.fillText(RN[h], cx + (R - 21) * Math.cos(ha), cy + (R - 21) * Math.sin(ha));
      }
      engrave(ctx, 'HOROLOGE', cx, 52, 12, m, 'center', 'bold');
      return { dial: { x: cx, y: cy, R: R } };
    }
    if (pz.payoff === 'orrery') {
      var ocy = H / 2 + 8;
      // a night-blue enamel sky inside a zodiac ring, so the planets read against something
      ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.beginPath(); ctx.arc(cx + 3, ocy + 4, 60, 0, TAU); ctx.fill();
      ctx.fillStyle = faceGrad(ctx, 60, a); ctx.beginPath(); ctx.arc(cx, ocy, 60, 0, TAU); ctx.fill();
      ctx.strokeStyle = a.edge; ctx.lineWidth = 1; ctx.stroke();
      var sky = ctx.createRadialGradient(cx - 14, ocy - 16, 4, cx, ocy, 54);
      sky.addColorStop(0, '#2c3f7a'); sky.addColorStop(1, '#070b1f');
      ctx.fillStyle = sky; ctx.beginPath(); ctx.arc(cx, ocy, 53, 0, TAU); ctx.fill();
      var sr = rng((pz.seed >>> 0) ^ 0x5A5);
      for (var st = 0; st < 46; st++) {
        var sa = sr() * TAU, sd = 6 + sr() * 45;
        ctx.fillStyle = 'rgba(255,248,220,' + (0.35 + sr() * 0.6) + ')';
        ctx.fillRect(cx + sd * Math.cos(sa), ocy + sd * Math.sin(sa), sr() < 0.15 ? 2 : 1, 1);
      }
      // zodiac ring ticks on the metal
      ctx.strokeStyle = a.cut; ctx.lineWidth = 1;
      for (var zt = 0; zt < 36; zt++) {
        var za = zt * TAU / 36, zl = zt % 3 === 0 ? 5 : 2.5;
        ctx.beginPath(); ctx.moveTo(cx + (59 - zl) * Math.cos(za), ocy + (59 - zl) * Math.sin(za)); ctx.lineTo(cx + 59 * Math.cos(za), ocy + 59 * Math.sin(za)); ctx.stroke();
      }
      ctx.strokeStyle = 'rgba(240,210,140,0.55)'; ctx.lineWidth = 0.9;
      var orbits = [19, 32, 46];
      for (var o = 0; o < 3; o++) { ctx.beginPath(); ctx.arc(cx, ocy, orbits[o], 0, TAU); ctx.stroke(); }
      engrave(ctx, 'ORRERY', cx, 52, 12, m, 'center', 'bold');
      return { orrery: { x: cx, y: ocy, orbits: orbits } };
    }
    // winch: a drum with a chain dropping to a counterweight in a slotted guide
    var dy = 90;
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; roundRect(ctx, cx - 9, dy + 26, 18, H - dy - 60, 4); ctx.fill();
    ctx.strokeStyle = m.cut; ctx.lineWidth = 1; roundRect(ctx, cx - 12, dy + 23, 24, H - dy - 54, 5); ctx.stroke();
    for (var k2 = 0; k2 < 6; k2++) engrave(ctx, String(6 - k2), cx + 24, dy + 40 + k2 * ((H - dy - 90) / 5), 9, m, 'center');
    engrave(ctx, 'WINCH', cx, 52, 12, m, 'center', 'bold');
    return { winch: { x: cx, y: dy, bottom: H - 40 } };
  }

  /** The bolt, drawn at the origin, pointing left: it withdraws to the right. */
  function drawBolt(ctx, w, m) {
    ctx.fillStyle = faceGrad(ctx, w, m);
    roundRect(ctx, 0, -8, w, 16, 3); ctx.fill();
    ctx.strokeStyle = m.edge; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = m.cut;
    for (var i = 8; i < w - 6; i += 6) ctx.fillRect(i, 5, 3, 3); // the rack the pinion drives
    ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.fillRect(3, -6, w - 6, 2);
  }

  /** A clock hand at the origin pointing up. */
  function drawHand(ctx, len, width, m, counter) {
    ctx.fillStyle = m.edge;
    ctx.beginPath();
    ctx.moveTo(-width, 0); ctx.lineTo(-width * 0.45, -len * 0.7);
    ctx.lineTo(0, -len); ctx.lineTo(width * 0.45, -len * 0.7); ctx.lineTo(width, 0);
    ctx.lineTo(width * 0.5, counter); ctx.lineTo(-width * 0.5, counter); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.arc(0, -len * 0.62, width * 0.9, 0, TAU); ctx.fillStyle = '#fffdf6'; ctx.fill();
    ctx.fillStyle = m.edge; ctx.beginPath(); ctx.arc(0, 0, width * 1.3, 0, TAU); ctx.fill();
  }

  /** A planet on an arm; drawn along +x from the origin. */
  function drawPlanetArm(ctx, len, pr, colour, m) {
    ctx.strokeStyle = m.mid; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(len, 0); ctx.stroke();
    var g = ctx.createRadialGradient(len - pr * 0.35, -pr * 0.35, 0.5, len, 0, pr);
    g.addColorStop(0, '#ffffff'); g.addColorStop(0.3, colour); g.addColorStop(1, '#0b0b14');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(len, 0, pr, 0, TAU); ctx.fill();
  }

  /** The sun at the centre of the orrery. */
  function drawSun(ctx, r) {
    var g = ctx.createRadialGradient(-r * 0.3, -r * 0.3, 0.5, 0, 0, r);
    g.addColorStop(0, '#fffbe0'); g.addColorStop(0.4, '#ffc53d'); g.addColorStop(1, '#a4540a');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(255,200,80,0.6)'; ctx.lineWidth = 1.2;
    for (var i = 0; i < 12; i++) {
      var a = i * TAU / 12;
      ctx.beginPath(); ctx.moveTo((r + 2) * Math.cos(a), (r + 2) * Math.sin(a)); ctx.lineTo((r + 6) * Math.cos(a), (r + 6) * Math.sin(a)); ctx.stroke();
    }
  }

  /** The winch drum (turns) at the origin. */
  function drawDrum(ctx, r, m) {
    ctx.fillStyle = faceGrad(ctx, r, m); ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fill();
    ctx.strokeStyle = m.edge; ctx.lineWidth = 1.2; ctx.stroke();
    for (var i = 0; i < 8; i++) {
      var a = i * TAU / 8;
      ctx.beginPath(); ctx.moveTo(4 * Math.cos(a), 4 * Math.sin(a)); ctx.lineTo((r - 3) * Math.cos(a), (r - 3) * Math.sin(a)); ctx.stroke();
    }
    ctx.fillStyle = m.cut; ctx.beginPath(); ctx.arc(0, 0, 4, 0, TAU); ctx.fill();
  }

  /** The counterweight at the origin (hangs from its top centre). */
  function drawWeight(ctx, m) {
    ctx.fillStyle = faceGrad(ctx, 18, m);
    ctx.beginPath(); ctx.moveTo(-11, 6); ctx.lineTo(11, 6); ctx.lineTo(9, 30); ctx.lineTo(-9, 30); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = m.edge; ctx.lineWidth = 1; ctx.stroke();
    ctx.beginPath(); ctx.arc(0, 3, 3.5, 0, TAU); ctx.stroke();
  }

  //===========================================================================
  // The tray, the cursor and the words
  //===========================================================================

  /** The drawer of loose wheels: a velvet-lined tray with one socket per wheel. */
  function drawTray(ctx, W, H, count, m) {
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; roundRect(ctx, 4, 6, W, H, 10); ctx.fill();
    var wood = ctx.createLinearGradient(0, 0, 0, H);
    wood.addColorStop(0, '#6b4226'); wood.addColorStop(1, '#3a2213');
    ctx.fillStyle = wood; roundRect(ctx, 0, 0, W, H, 10); ctx.fill();
    var r = rng(77);
    for (var i = 0; i < 60; i++) {
      ctx.strokeStyle = 'rgba(0,0,0,' + (0.05 + r() * 0.08) + ')'; ctx.lineWidth = 1;
      var y = r() * H; ctx.beginPath(); ctx.moveTo(0, y); ctx.bezierCurveTo(W * 0.3, y + 3, W * 0.6, y - 3, W, y + (r() - 0.5) * 4); ctx.stroke();
    }
    var velvet = ctx.createLinearGradient(0, 8, 0, H - 8);
    velvet.addColorStop(0, '#3d0f1d'); velvet.addColorStop(1, '#1f0610');
    ctx.fillStyle = velvet; roundRect(ctx, 8, 8, W - 16, H - 16, 6); ctx.fill();
    var slot = (W - 16) / Math.max(1, count);
    for (var s = 0; s < count; s++) {
      var cx = 8 + slot * (s + 0.5);
      ctx.fillStyle = 'rgba(0,0,0,0.35)';
      ctx.beginPath(); ctx.arc(cx, H / 2, Math.min(slot, H - 16) * 0.44, 0, TAU); ctx.fill();
    }
    return { slot: slot };
  }

  /** The words in the lock's indicator window, drawn centred at the origin. */
  function drawWindowWord(ctx, word, good) {
    ctx.font = 'bold 12px ' + FACE; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = good ? '#9fe07a' : '#e8604a';
    ctx.fillText(word, 0, 1);
  }

  /** A warning halo: drawn where the pawl holds or where a loop jams. */
  function drawWarning(ctx, R) {
    var g = ctx.createRadialGradient(0, 0, R * 0.6, 0, 0, R);
    g.addColorStop(0, 'rgba(255,70,40,0)'); g.addColorStop(0.75, 'rgba(255,70,40,0.55)'); g.addColorStop(1, 'rgba(255,70,40,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, R, 0, TAU); ctx.fill();
  }

  /** The selector: a loupe ring with four ticks. */
  function drawCursor(ctx, R) {
    ctx.save();
    ctx.strokeStyle = 'rgba(255,236,170,0.95)'; ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.arc(0, 0, R, 0, TAU); ctx.stroke();
    ctx.strokeStyle = 'rgba(40,20,0,0.8)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(0, 0, R + 2.2, 0, TAU); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,236,170,0.95)'; ctx.lineWidth = 2.5;
    for (var i = 0; i < 4; i++) {
      var a = i * TAU / 4 + Math.PI / 4;
      ctx.beginPath(); ctx.moveTo((R + 3) * Math.cos(a), (R + 3) * Math.sin(a)); ctx.lineTo((R + 10) * Math.cos(a), (R + 10) * Math.sin(a)); ctx.stroke();
    }
    ctx.restore();
  }

  /** A line of status text on the bench, in the chosen face. */
  function drawStatus(ctx, W, text, tone) {
    ctx.clearRect(0, 0, W, 40);
    ctx.font = 'italic 17px ' + FACE;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillText(text, W / 2 + 1, 21);
    ctx.fillStyle = tone === 'bad' ? '#ff9c86' : tone === 'good' ? '#c8f5a6' : '#f1dfb4';
    ctx.fillText(text, W / 2, 20);
  }

  /** The heading above the plate: the puzzle's name and grade. */
  function drawHeading(ctx, W, title, grade) {
    ctx.clearRect(0, 0, W, 56);
    ctx.font = '30px ' + FACE; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillText(title, W / 2 + 1, 25);
    var g = ctx.createLinearGradient(0, 8, 0, 42);
    g.addColorStop(0, '#fff1c4'); g.addColorStop(1, '#c9953d');
    ctx.fillStyle = g; ctx.fillText(title, W / 2, 24);
    var ROMAN = ['', 'I', 'II', 'III', 'IV', 'V'];
    ctx.font = 'italic 13px ' + FACE; ctx.fillStyle = '#b89a66';
    ctx.fillText('grade ' + ROMAN[grade] + '   ·   arrows choose an arbor   ·   OK places or lifts a wheel   ·   Esc leaves', W / 2, 48);
  }

  return {
    VERSION: '1.0.0', FACE: FACE, METALS: METALS, ACCENT: ACCENT,
    metal: metal, drawGear: drawGear, toothPath: toothPath, drawShadow: drawShadow, drawGlint: drawGlint,
    drawBench: drawBench, drawPlate: drawPlate, drawArbor: drawArbor, drawTurnArrow: drawTurnArrow, clearSide: clearSide,
    drawWindowWord: drawWindowWord, drawWarning: drawWarning, drawTurnHint: drawTurnHint,
    drawPayoffBase: drawPayoffBase, drawBolt: drawBolt, drawHand: drawHand, drawPlanetArm: drawPlanetArm,
    drawSun: drawSun, drawDrum: drawDrum, drawWeight: drawWeight, drawTray: drawTray, drawCursor: drawCursor,
    drawStatus: drawStatus, drawHeading: drawHeading, engrave: engrave, roundRect: roundRect, jewel: jewel,
  };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = EscapementDraw;
