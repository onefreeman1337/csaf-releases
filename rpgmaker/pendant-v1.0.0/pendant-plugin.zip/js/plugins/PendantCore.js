//=============================================================================
// PendantCore.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Pendant's difference maker: changes the second picture in places, each one measured to be findable.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The difference maker for Pendant.js. Turn this file on with Pendant.js; it
 * has no parameters and no commands of its own (see Pendant.js and the
 * Readme). Recommended above Pendant.js, but any order works.
 *
 * Four kinds of change: an object added that belongs where it lands (twelve
 * objects drawn by this file), an uneven detail mirrored, a patch painted out
 * from its neighbour, an object with an edge of its own recoloured to a colour
 * the picture already uses. Every change must clear a visibility floor or it
 * is undone and another place is tried. The same seed always makes the same
 * changes. It works on plain pixel arrays, so it never touches the engine.
 */

var CSAF = CSAF || {};

(function () {
  'use strict';

  /** A change must move at least this many pixels by at least this much (sum of channel deltas). PROVISIONAL
   *  (2026-10-04 spike: a 3-12 px recolour was invisible, 700+ px mirrors and paint-outs read): to be set BETWEEN a
   *  measured known-fair and known-unfair set before shipping (wing 12b-1), with difficulty as its level. */
  var FLOOR = { px: 120, meanDelta: 60 };
  var CHANGED = 40;   // a pixel counts as changed when its channel deltas sum above this
  /** One boundary step of a recolour counts as a real edge at this seed-to-outside contrast. MEASURED 2026-10-04
   *  (Internal_Ops/_probe/edge_measure.js): objects with their own edge 128-254 (7), tolerance bands in a sky gradient
   *  35-38 (14) - set between them (wing 12b-1). (A gate on the MEAN contrast was tried and removed the same day: it let
   *  a band through whose lower edge met land, and once SHARE existed it could never be the gate that refused.) */
  var STEP = 60;
  /** The share of a recolour's boundary that must be real edge. Set 2026-10-04 by LOOKING (Internal_Ops/_probe/
   *  recolour_audit.js, 103 accepted recolours over six illustrations, 24 viewed at 2x): below 0.75, 9 of 10 viewed
   *  were lighting bands or shadows smeared a new colour (one good: a banner at 0.51); at or above, every one viewed
   *  was an object - a letter, a board square, a trim. A lost good recolour costs a fallback; a glitch costs Gate 1. */
  var SHARE = 0.75;
  /** An added object refuses ground busier than this (luminance standard deviation inside its patch) and needs a body
   *  colour this far from the ground's mean luminance. PROVISIONAL until measured on the illustrations. */
  var BUSY = 24, SEP = 60;
  /** A recolour refuses a region darker than DARK_L whose chroma is under DARK_C (see recolour()). */
  var DARK_L = 45, DARK_C = 25;
  /** An object already in the picture may be drawn again only after this many refusals in a row. */
  var REPEAT_AFTER = 12;

  function seedOf(s) {
    var n = Number(s);
    if (s !== '' && s !== null && s !== undefined && isFinite(n)) return (Math.floor(Math.abs(n)) >>> 0) || 1;
    var h = 2166136261, str = String(s);
    for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    return h || 1;
  }
  function rng(a) {
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /** How visibly b differs from a in the square of half-size r around (cx, cy). @returns {{px:number, meanDelta:number}} */
  function visibility(a, b, cx, cy, r) {
    var W = a.width, H = a.height, n = 0, sum = 0;
    var x0 = Math.max(0, Math.round(cx - r)), x1 = Math.min(W, Math.round(cx + r)), y0 = Math.max(0, Math.round(cy - r)), y1 = Math.min(H, Math.round(cy + r));
    for (var y = y0; y < y1; y++) for (var x = x0; x < x1; x++) {
      var i = (y * W + x) * 4, d = Math.abs(a.data[i] - b.data[i]) + Math.abs(a.data[i + 1] - b.data[i + 1]) + Math.abs(a.data[i + 2] - b.data[i + 2]);
      if (d > CHANGED) { n++; sum += d; }
    }
    return { px: n, meanDelta: n ? Math.round(sum / n) : 0 };
  }

  /**
   * Recolour the flat region around (sx, sy): flood-fill by colour similarity inside a radius, then rotate its
   * channels. Refuses (null, image untouched) when the region is too small (detailed ground) or too large.
   * @returns {{x:number,y:number,r:number,area:number}|null}
   */
  function recolour(img, sx, sy, o) {
    o = o || {};
    var W = img.width, H = img.height, d = img.data, tol = o.tol || 36, rad = o.radius || 40, minA = o.minArea || 300, maxA = o.maxArea || 6000;
    sx = Math.round(sx); sy = Math.round(sy);
    if (sx < 0 || sy < 0 || sx >= W || sy >= H) return null;
    var i0 = (sy * W + sx) * 4, r0 = d[i0], g0 = d[i0 + 1], b0 = d[i0 + 2];
    // (a grey seed is NOT refused: the colour moves to a palette colour, so a grey cart can become a red one - the
    // zero-pixel recolours of grey came from the old channel rotation, removed 2026-10-04)
    var seen = new Uint8Array(W * H), stack = [sy * W + sx], region = [];
    while (stack.length) {
      var p = stack.pop(); if (seen[p]) continue; seen[p] = 1;
      var px = p % W, py = (p - px) / W, i = p * 4;
      if (Math.abs(d[i] - r0) + Math.abs(d[i + 1] - g0) + Math.abs(d[i + 2] - b0) > tol) continue;
      if ((px - sx) * (px - sx) + (py - sy) * (py - sy) > rad * rad) continue;
      region.push(p); if (region.length > maxA) return null;
      if (px > 0) stack.push(p - 1); if (px < W - 1) stack.push(p + 1); if (py > 0) stack.push(p - W); if (py < H - 1) stack.push(p + W);
    }
    if (region.length < minA) return null;
    // NOT A DISC: a region much of whose edge is the radius was cut out of a field. Removed once as "subsumed by the edge
    // share" on the test fixture and RESTORED the same day: on a felt table strewn with jigsaw pieces the pieces' edges
    // carried the share to 0.75 and two round stains shipped through it (recolour_audit 2026-10-04)
    var rim = 0, sr = 0, sg = 0, sb = 0, sxx = 0, syy = 0, k, j, q, qx, qy, inner = (rad - 1.5) * (rad - 1.5);
    for (k = 0; k < region.length; k++) {
      q = region[k]; qx = q % W; qy = (q - qx) / W; j = q * 4;
      if ((qx - sx) * (qx - sx) + (qy - sy) * (qy - sy) > inner) rim++;
      sr += d[j]; sg += d[j + 1]; sb += d[j + 2]; sxx += qx; syy += qy;
    }
    if (rim > 2 * Math.PI * rad * (o.rimMax === undefined ? 0.2 : o.rimMax)) return null;
    // an OBJECT has an EDGE all round. A flood in a gradient (sky, sea) stops where the colour drifts past `tol`, and a
    // flood cut off by the radius stops where nothing changes at all - either way, three pixels outside that boundary
    // the colour is still nearly the seed's. So: the share of boundary steps with real contrast 3 px out (2026-10-04:
    // magenta discs cut from a flat sky, a brown band across the sea; a separate radius gate was subsumed and removed)
    var inR = new Uint8Array(W * H), cs = 0, cn = 0, strong = 0, e, ex, ey, fx, fy, f;
    for (k = 0; k < region.length; k++) inR[region[k]] = 1;
    for (k = 0; k < region.length; k++) {
      q = region[k]; qx = q % W; qy = (q - qx) / W;
      for (e = 0; e < 4; e++) {
        ex = e === 0 ? 1 : e === 1 ? -1 : 0; ey = e === 2 ? 1 : e === 3 ? -1 : 0;
        if (qx + ex < 0 || qy + ey < 0 || qx + ex >= W || qy + ey >= H || inR[(qy + ey) * W + qx + ex]) continue;
        fx = qx + ex * 3; fy = qy + ey * 3;
        if (fx < 0 || fy < 0 || fx >= W || fy >= H) continue;
        f = (fy * W + fx) * 4; var cd = Math.abs(d[f] - r0) + Math.abs(d[f + 1] - g0) + Math.abs(d[f + 2] - b0);
        cs += cd; cn++; if (cd >= STEP) strong++;
      }
    }
    var edge = cn ? Math.round(cs / cn) : 0, share = cn ? Math.round(strong / cn * 100) / 100 : 0;   // edge: diagnostic only
    // most of an OBJECT's boundary is a real edge; a band in a gradient is edged on one side at best
    if (share < (o.share === undefined ? SHARE : o.share)) return null;
    // the change is the OBJECT: its centre and reach, not the flood radius (a 30x18 bar recorded at r 40 took clicks
    // 46 px away as finds and blocked every neighbour by the spacing rule)
    var ccx = sxx / region.length, ccy = syy / region.length, reach2 = 0;
    for (k = 0; k < region.length; k++) { q = region[k]; qx = q % W; qy = (q - qx) / W; reach2 = Math.max(reach2, (qx - ccx) * (qx - ccx) + (qy - ccy) * (qy - ccy)); }
    var n = region.length, mr = sr / n, mg = sg / n, mb = sb / n, mh = hueOf(mr, mg, mb), ml = lumOf(mr, mg, mb);
    // a DARK, COLOURLESS region has no colour to change: "recolouring" it paints a new one ON, which reads as a smear (a
    // tavern board's black edge turned blue). MEASURED 2026-10-04 (_probe/recolour_diag.js, 43 accepted over six
    // illustrations x 12 seeds): 11 smears at l 9-12 / chroma 1-5 and five more at l 19-42 / chroma <= 20; every coloured
    // object sat at l >= 43 or chroma >= 27. The gate sits between (wing 12b-1).
    if (ml < (o.darkL === undefined ? DARK_L : o.darkL) && Math.max(mr, mg, mb) - Math.min(mr, mg, mb) < DARK_C) return null;
    // the new colour is one the PICTURE already uses - another hue at a similar lightness - so the change reads as
    // painted, never as a channel swap (rotation gave magenta skies and grass, 2026-10-04)
    var pal = [];
    for (var y = 3; y < H; y += 7) for (var x = 3; x < W; x += 7) {
      var t = (y * W + x) * 4, tr = d[t], tg = d[t + 1], tb = d[t + 2];
      if (Math.max(tr, tg, tb) - Math.min(tr, tg, tb) < 40 || hueGap(hueOf(tr, tg, tb), mh) < 60 || Math.abs(lumOf(tr, tg, tb) - ml) > 60) continue;
      pal.push(t);
    }
    if (!pal.length) return null;
    var pick = Number(o.pick); if (!(pick >= 0 && pick < 1)) pick = 0.5;
    var to = pal[Math.floor(pick * pal.length)], dr = d[to] - mr, dg = d[to + 1] - mg, db = d[to + 2] - mb, toRGB = [d[to], d[to + 1], d[to + 2]];
    for (k = 0; k < region.length; k++) { j = region[k] * 4; d[j] += dr; d[j + 1] += dg; d[j + 2] += db; }
    return { x: Math.round(ccx), y: Math.round(ccy), r: Math.ceil(Math.sqrt(reach2)) + 1, area: n, to: toRGB, edge: edge, share: share };
  }

  /** Hue in degrees (0 for grey). */
  function hueOf(r, g, b) {
    var mx = Math.max(r, g, b), mn = Math.min(r, g, b), c = mx - mn, h;
    if (!c) return 0;
    if (mx === r) h = ((g - b) / c) % 6; else if (mx === g) h = (b - r) / c + 2; else h = (r - g) / c + 4;
    h *= 60;
    return h < 0 ? h + 360 : h;
  }
  function hueGap(a, b) { var g = Math.abs(a - b) % 360; return g > 180 ? 360 - g : g; }
  function lumOf(r, g, b) { return 0.299 * r + 0.587 * g + 0.114 * b; }

  /** A fixed phase from a centre, so the same place always gets the same outline (no RNG draw: it would shift every
   *  later change of the seed). */
  function phaseOf(cx, cy) { return (((cx * 73856093) ^ (cy * 19349663)) >>> 0) % 6283 / 1000; }

  /**
   * How much of a change shows at offset (x, y) from its centre: 1 in the core, easing to 0 across a feathered rim
   * whose reach wobbles with the angle (72-100% of r), so the edit has no hard circular seam and no disc outline -
   * both gave the answer away in the 2x crops (2026-10-04). Never above 0 at or beyond r, so restore and hit still
   * cover every changed pixel. @returns {number} 0..1
   */
  function edgeWeight(x, y, r, ph) {
    var dist = Math.sqrt(x * x + y * y);
    if (dist >= r) return 0;
    var th = Math.atan2(y, x), reach = r * (0.86 + 0.08 * Math.sin(3 * th + ph) + 0.06 * Math.sin(2 * th + ph * 1.7));
    var t = (reach - dist) / Math.max(3, r * 0.2);
    if (t <= 0) return 0;
    if (t >= 1) return 1;
    return t * t * (3 - 2 * t);
  }

  /** Blend pixel j of `src` into pixel i of `d` by weight w (i is read before it is written, so it is still the original). */
  function blend(d, i, src, j, w) {
    d[i] = d[i] + (src[j] - d[i]) * w; d[i + 1] = d[i + 1] + (src[j + 1] - d[i + 1]) * w; d[i + 2] = d[i + 2] + (src[j + 2] - d[i + 2]) * w;
  }

  /** Mirror the round patch at (cx, cy) left-to-right, only if it is uneven enough to show. @returns {{x,y,r,asym}|null} */
  function mirror(img, cx, cy, r, o) {
    o = o || {};
    var W = img.width, H = img.height, d = img.data, minAsym = o.minAsym === undefined ? 0.08 : o.minAsym;
    cx = Math.round(cx); cy = Math.round(cy);
    if (cx - r < 0 || cy - r < 0 || cx + r >= W || cy + r >= H) return null;
    var diff = 0, n = 0, x, y, i, j;
    for (y = -r; y <= r; y++) for (x = -r; x <= r; x++) {
      if (x * x + y * y > r * r) continue;
      i = ((cy + y) * W + cx + x) * 4; j = ((cy + y) * W + cx - x) * 4;
      diff += Math.abs(d[i] - d[j]) + Math.abs(d[i + 1] - d[j + 1]) + Math.abs(d[i + 2] - d[j + 2]); n++;
    }
    var asym = n ? diff / n / 765 : 0;
    if (asym < minAsym) return null;
    var snap = new Uint8ClampedArray(d), ph = phaseOf(cx, cy), w;
    for (y = -r; y <= r; y++) for (x = -r; x <= r; x++) {
      if ((w = edgeWeight(x, y, r, ph)) <= 0) continue;
      i = ((cy + y) * W + cx + x) * 4; j = ((cy + y) * W + cx - x) * 4;
      blend(d, i, snap, j, w);
    }
    return { x: cx, y: cy, r: r, asym: Math.round(asym * 1000) / 1000 };
  }

  /** Replace the round patch at (cx, cy) with the one dx across. @returns {{x,y,r,dx}|null} */
  function paintOut(img, cx, cy, r, dx) {
    var W = img.width, H = img.height, d = img.data;
    cx = Math.round(cx); cy = Math.round(cy); dx = Math.round(dx);
    if (cx - r < 0 || cy - r < 0 || cx + r >= W || cy + r >= H || cx + dx - r < 0 || cx + dx + r >= W) return null;
    var snap = new Uint8ClampedArray(d), ph = phaseOf(cx, cy), w;
    for (var y = -r; y <= r; y++) for (var x = -r; x <= r; x++) {
      if ((w = edgeWeight(x, y, r, ph)) <= 0) continue;
      blend(d, ((cy + y) * W + cx + x) * 4, snap, ((cy + y) * W + cx + dx + x) * 4, w);
    }
    return { x: cx, y: cy, r: r, dx: dx };
  }

  //---------------------------------------------------------------------------
  // ADDED OBJECTS: a small drawn corpus, rendered from signed distances (pure arithmetic, so it runs in Node and in the
  // engine alike). Object space: u right, v down, the whole object inside the unit DISC (so any tilt stays inside r).
  // Each object is a list of layers drawn in order; a layer's ROLE decides its colour, picked against what it sits on
  // (wing Icon_Doctrine 22e: never a hard-coded ink).
  function sdCircle(u, v, x, y, r) { return Math.sqrt((u - x) * (u - x) + (v - y) * (v - y)) - r; }
  function sdEllipse(u, v, x, y, a, b) { var p = (u - x) / a, q = (v - y) / b; return (Math.sqrt(p * p + q * q) - 1) * Math.min(a, b); }
  function sdRing(u, v, x, y, r, w) { return Math.abs(sdCircle(u, v, x, y, r)) - w; }
  /** A tapered capsule from (ax,ay) radius ra to (bx,by) radius rb. */
  function sdSeg(u, v, ax, ay, bx, by, ra, rb) {
    var pax = u - ax, pay = v - ay, bax = bx - ax, bay = by - ay, h = (pax * bax + pay * bay) / (bax * bax + bay * bay);
    h = h < 0 ? 0 : h > 1 ? 1 : h;
    var dx = pax - bax * h, dy = pay - bay * h;
    return Math.sqrt(dx * dx + dy * dy) - (ra + (rb - ra) * h);
  }
  function sdBox(u, v, x, y, hw, hh, rr) {
    var qx = Math.abs(u - x) - hw + rr, qy = Math.abs(v - y) - hh + rr, ox = Math.max(qx, 0), oy = Math.max(qy, 0);
    return Math.sqrt(ox * ox + oy * oy) + Math.min(Math.max(qx, qy), 0) - rr;
  }
  /** Exact signed distance to a closed polygon (flat array x0,y0,x1,y1...). */
  function sdPoly(u, v, P) {
    var n = P.length / 2, d = (u - P[0]) * (u - P[0]) + (v - P[1]) * (v - P[1]), s = 1;
    for (var i = 0, j = n - 1; i < n; j = i, i++) {
      var ex = P[j * 2] - P[i * 2], ey = P[j * 2 + 1] - P[i * 2 + 1], wx = u - P[i * 2], wy = v - P[i * 2 + 1];
      var t = (wx * ex + wy * ey) / (ex * ex + ey * ey); t = t < 0 ? 0 : t > 1 ? 1 : t;
      var bx = wx - ex * t, by = wy - ey * t; d = Math.min(d, bx * bx + by * by);
      var c1 = v >= P[i * 2 + 1], c2 = v < P[j * 2 + 1], c3 = ex * wy > ey * wx;
      if ((c1 && c2 && c3) || (!c1 && !c2 && !c3)) s = -s;
    }
    return s * Math.sqrt(d);
  }
  /** An ellipse turned by angle a (radians) - a leaf, a petal. */
  function sdLeaf(u, v, x, y, a, b, ang) { var c = Math.cos(ang), s = Math.sin(ang), p = (u - x) * c + (v - y) * s, q = -(u - x) * s + (v - y) * c; return sdEllipse(p, q, 0, 0, a, b); }
  function starPoly(outer, inner, cy) { var P = []; for (var i = 0; i < 10; i++) { var a = -Math.PI / 2 + i * Math.PI / 5, r = i % 2 ? inner : outer; P.push(Math.cos(a) * r, cy + Math.sin(a) * r); } return P; }
  var STAR = starPoly(0.9, 0.38, 0.06);
  var FISH_TAIL = [0.34, 0, 0.82, -0.36, 0.7, 0, 0.82, 0.36], FISH_FIN = [-0.3, -0.25, 0.0, -0.5, 0.12, -0.23];
  var FLAG = [-0.42, -0.7, 0.12, -0.63, 0.72, -0.43, 0.14, -0.33, -0.42, -0.2];
  var LANTERN_CAP = [-0.26, -0.72, 0.26, -0.72, 0.38, -0.54, -0.38, -0.54];
  var BIRD_TAIL = [-0.07, 0.17, 0.07, 0.17, 0, 0.36];
  var KITE = [0, -0.82, 0.44, -0.22, 0, 0.34, -0.44, -0.22];
  var BALLOON_TAPER = [-0.47, -0.16, 0.47, -0.16, 0.15, 0.36, -0.15, 0.36];
  function balloonBody(u, v) { return Math.min(sdCircle(u, v, 0, -0.3, 0.52), sdPoly(u, v, BALLOON_TAPER)); }

  /**
   * The corpus. Roles: body (the object's own colour, picked against the GROUND), ink (outline and dark parts, against
   * the body), stem / leaf (against the ground), gold / cream (small parts, against the body). `pen` 0 = no outline.
   * Every id here is drawn by addObject; the contact sheet (_probe/objects_sheet.js) is the only place a collision shows.
   */
  var OBJECTS = [
    { id: 'fish', body: ['orange', 'red', 'blue', 'silver'], layers: [
      { role: 'body', pen: 1, f: function (u, v) { return Math.min(sdEllipse(u, v, -0.12, 0, 0.55, 0.32), sdPoly(u, v, FISH_TAIL), sdPoly(u, v, FISH_FIN)); } },
      { role: 'ink', pen: 0, f: function (u, v) { return Math.min(sdCircle(u, v, -0.42, -0.07, 0.07), sdSeg(u, v, -0.22, -0.2, -0.2, 0.2, 0.025, 0.025)); } }] },
    { id: 'bird', body: ['white', 'black'], layers: [
      { role: 'body', pen: 0.7, f: function (u, v) {
        return Math.min(sdSeg(u, v, 0, 0.08, -0.42, -0.22, 0.13, 0.1), sdSeg(u, v, -0.42, -0.22, -0.9, 0, 0.1, 0.025),
          sdSeg(u, v, 0, 0.08, 0.38, -0.3, 0.13, 0.1), sdSeg(u, v, 0.38, -0.3, 0.86, -0.18, 0.1, 0.025), sdEllipse(u, v, 0, 0.12, 0.2, 0.11), sdPoly(u, v, BIRD_TAIL)); } }] },
    // a kite and a balloon: the sky's own objects in COLOUR (on a pale day sky the moon cannot separate and the bird was
    // the only thing left, so one puzzle drew three birds, store_shots 2026-10-04)
    { id: 'kite', body: ['red', 'blue', 'orange', 'purple'], layers: [
      { role: 'stem', pen: 0, f: function (u, v) { return Math.min(sdSeg(u, v, 0, 0.34, 0.14, 0.54, 0.022, 0.022), sdSeg(u, v, 0.14, 0.54, 0.02, 0.72, 0.022, 0.022), sdSeg(u, v, 0.02, 0.72, 0.16, 0.9, 0.022, 0.018)); } },
      { role: 'gold', pen: 0.5, f: function (u, v) { return Math.min(sdLeaf(u, v, 0.14, 0.54, 0.09, 0.04, 0.5), sdLeaf(u, v, 0.02, 0.72, 0.09, 0.04, -0.5)); } },
      { role: 'body', pen: 1, f: function (u, v) { return sdPoly(u, v, KITE); } },
      { role: 'ink', pen: 0, f: function (u, v) { return Math.max(Math.min(sdSeg(u, v, 0, -0.8, 0, 0.32, 0.018, 0.018), sdSeg(u, v, -0.42, -0.22, 0.42, -0.22, 0.018, 0.018)), sdPoly(u, v, KITE)); } }] },
    { id: 'balloon', body: ['red', 'orange', 'blue', 'purple'], layers: [
      { role: 'stem', pen: 0, f: function (u, v) { return Math.min(sdSeg(u, v, -0.14, 0.34, -0.11, 0.62, 0.016, 0.016), sdSeg(u, v, 0.14, 0.34, 0.11, 0.62, 0.016, 0.016)); } },
      { role: 'stem', pen: 0.5, f: function (u, v) { return sdBox(u, v, 0, 0.72, 0.13, 0.1, 0.02); } },
      { role: 'body', pen: 1, f: balloonBody },
      { role: 'cream', pen: 0, f: function (u, v) { return Math.max(Math.min(Math.abs(u) - 0.07, Math.abs(Math.abs(u) - 0.3) - 0.05), balloonBody(u, v) + 0.03); } }] },
    { id: 'pennant', body: ['red', 'blue', 'yellow', 'white'], layers: [
      { role: 'stem', pen: 0.6, f: function (u, v) { return sdSeg(u, v, -0.45, 0.8, -0.45, -0.7, 0.05, 0.05); } },
      { role: 'body', pen: 1, f: function (u, v) { return sdPoly(u, v, FLAG); } },
      { role: 'gold', pen: 0.6, f: function (u, v) { return sdCircle(u, v, -0.45, -0.77, 0.09); } }] },
    { id: 'star', body: ['yellow', 'white', 'orange'], layers: [
      { role: 'body', pen: 1, f: function (u, v) { return sdPoly(u, v, STAR); } }] },
    { id: 'flower', body: ['red', 'yellow', 'white', 'purple'], layers: [
      { role: 'stem', pen: 0.6, f: function (u, v) { return sdSeg(u, v, 0.05, 0.92, 0, -0.1, 0.05, 0.06); } },
      { role: 'leaf', pen: 0.7, f: function (u, v) { return sdLeaf(u, v, 0.26, 0.5, 0.27, 0.1, -0.6); } },
      { role: 'body', pen: 1, f: function (u, v) { var d = 9; for (var k = 0; k < 5; k++) { var a = -Math.PI / 2 + k * 1.2566; d = Math.min(d, sdCircle(u, v, Math.cos(a) * 0.27, -0.32 + Math.sin(a) * 0.27, 0.17)); } return d; } },
      { role: 'gold', pen: 0.6, f: function (u, v) { return sdCircle(u, v, 0, -0.32, 0.12); } }] },
    { id: 'key', body: ['yellow', 'black', 'silver'], layers: [
      { role: 'body', pen: 1, f: function (u, v) { return Math.min(sdRing(u, v, -0.55, 0, 0.27, 0.09), sdBox(u, v, 0.28, 0, 0.55, 0.065, 0.02), sdBox(u, v, 0.6, 0.18, 0.055, 0.12, 0.01), sdBox(u, v, 0.77, 0.15, 0.05, 0.09, 0.01)); } }] },
    { id: 'apple', body: ['red', 'yellow', 'green'], layers: [
      { role: 'body', pen: 1, f: function (u, v) { return Math.max(Math.min(sdCircle(u, v, -0.17, 0.12, 0.5), sdCircle(u, v, 0.17, 0.12, 0.5)), -sdCircle(u, v, 0, -0.43, 0.13)); } },
      { role: 'stem', pen: 0.5, f: function (u, v) { return sdSeg(u, v, 0, -0.34, 0.08, -0.72, 0.045, 0.035); } },
      { role: 'leaf', pen: 0.6, f: function (u, v) { return sdLeaf(u, v, 0.27, -0.62, 0.2, 0.08, -0.45); } }] },
    { id: 'moon', body: ['yellow', 'white'], layers: [
      { role: 'body', pen: 1, f: function (u, v) { return Math.max(sdCircle(u, v, -0.04, 0, 0.82), -sdCircle(u, v, 0.32, -0.2, 0.66)); } }] },
    { id: 'mushroom', body: ['red', 'orange'], layers: [
      { role: 'cream', pen: 0.8, f: function (u, v) { return sdBox(u, v, 0, 0.4, 0.2, 0.42, 0.08); } },
      { role: 'body', pen: 1, f: function (u, v) { return Math.max(sdEllipse(u, v, 0, 0, 0.82, 0.6), v); } },
      { role: 'cream', pen: 0, f: function (u, v) { return Math.max(Math.min(sdCircle(u, v, -0.42, -0.2, 0.1), sdCircle(u, v, 0.12, -0.4, 0.12), sdCircle(u, v, 0.46, -0.15, 0.08)), Math.max(sdEllipse(u, v, 0, 0, 0.78, 0.56), v + 0.04)); } }] },
    // the cap, ring and base are METAL picked against the GROUND: inked against the yellow body they went black on a
    // dark ground and the lantern read as a lit window (balance_4.png 2026-10-04)
    { id: 'lantern', body: ['yellow', 'orange'], layers: [
      { role: 'metal', pen: 0.5, f: function (u, v) { return Math.min(sdRing(u, v, 0, -0.84, 0.09, 0.035), sdPoly(u, v, LANTERN_CAP), sdBox(u, v, 0, 0.66, 0.4, 0.07, 0.02)); } },
      { role: 'body', pen: 1, f: function (u, v) { return sdBox(u, v, 0, 0.06, 0.33, 0.52, 0.1); } },
      { role: 'ink', pen: 0, f: function (u, v) { return Math.max(Math.min(sdBox(u, v, 0, 0.06, 0.03, 0.6, 0), sdBox(u, v, 0, 0.06, 0.4, 0.03, 0)), sdBox(u, v, 0, 0.06, 0.33, 0.52, 0.1)); } }] }
  ];
  /** The named colours an object may take. Painterly, not saturated primaries (they must sit in an illustration). */
  var PAINT = { red: [192, 57, 43], orange: [224, 123, 42], yellow: [242, 193, 78], green: [86, 140, 58], blue: [46, 92, 138], purple: [107, 76, 138], white: [244, 239, 228], silver: [186, 192, 198], black: [34, 26, 20] };
  var ROLE = { metal: [[44, 34, 28], [196, 152, 76]], stem: [[74, 110, 52], [110, 78, 48], [40, 30, 22], [200, 190, 160]], leaf: [[86, 140, 58], [52, 96, 44], [170, 200, 110]], gold: [[226, 178, 70], [120, 84, 30]], cream: [[244, 236, 214], [70, 52, 40]], ink: [[34, 24, 18], [246, 238, 222]] };

  /** Where each object can plausibly appear. A fish and an apple floating in a sunset sky read as pasted stickers
   *  (balance_0.png, 2026-10-04): the object must belong to the ground it lands on. */
  var WHERE = { fish: ['water'], bird: ['sky', 'night', 'water'], kite: ['sky'], balloon: ['sky'], moon: ['sky', 'night'], star: ['night'], pennant: ['field', 'earth', 'stone'], flower: ['field', 'earth'], mushroom: ['field', 'earth', 'dark'], apple: ['field', 'earth'], key: ['stone', 'earth', 'dark'], lantern: ['night', 'dark', 'stone', 'earth'] };
  /**
   * What kind of ground the round patch at (cx, cy) is, from its mean colour and its height in the picture:
   * night / dark (low light, upper / lower half), sky / stone (pale and grey), sky / water (blue, upper / lower),
   * field (green), sky / earth (warm: a sunset above, earth and walls below).
   */
  function groundClass(img, cx, cy, r) {
    var W = img.width, d = img.data, n = 0, sr = 0, sg = 0, sb = 0;
    for (var y = -r; y <= r; y += 2) for (var x = -r; x <= r; x += 2) {
      if (x * x + y * y > r * r) continue;
      var px = Math.round(cx + x), py = Math.round(cy + y); if (px < 0 || py < 0 || px >= W || py >= img.height) continue;
      var i = (py * W + px) * 4; sr += d[i]; sg += d[i + 1]; sb += d[i + 2]; n++;
    }
    if (!n) return 'earth';
    var mr = sr / n, mg = sg / n, mb = sb / n, l = lumOf(mr, mg, mb), ch = Math.max(mr, mg, mb) - Math.min(mr, mg, mb), h = hueOf(mr, mg, mb), up = cy / img.height;
    // a night SKY is high and blue-to-neutral; a dark tavern wall or a slate board on a table is not (a crescent moon was
    // set on a slate board at 40% height, balance_4.png 2026-10-04)
    if (l < 70) return up < 0.35 && mb >= mr ? 'night' : 'dark';
    // a grey sky is a LIGHT one (cloud, overcast); a mid-grey high patch is slate or stone (the moon stayed on the slate
    // board after the night fix: its grey read as overcast sky, balance_4.png 2026-10-04)
    if (ch < 25) return up < 0.45 && l > 150 ? 'sky' : 'stone';
    // EVERY sky is light. MEASURED 2026-10-04 (_probe/class_diag.js): the harbour's sky patches read l 152-196, while the
    // tavern's brown wood high in the frame read l 72-82 at a warm hue and was taken for a sunset (a moon on the board, a
    // bird on the wall). A blue patch too dark for sky high up is slate; low down it is water.
    // and a pale CYAN haze near the horizon is sky: the windmill painting's sky read hue 170-180 at l 211-218 and was taken
    // for a field (a mushroom, a flower and an apple in the sky, class_diag.js 2026-10-04) - grass is green and never that pale
    if ((h >= 165 && h <= 260) || (h >= 65 && l > 200)) return up >= 0.5 ? 'water' : l > 110 ? 'sky' : 'stone';
    if (h >= 65 && h < 165) return 'field';
    return up < 0.35 && l > 140 ? 'sky' : 'earth';
  }

  /** The candidate with the most LUMINANCE separation from `bg` (wing 22e). */
  function pickContrast(bg, cands) {
    var lb = lumOf(bg[0], bg[1], bg[2]), best = cands[0], bd = -1;
    for (var i = 0; i < cands.length; i++) { var d = Math.abs(lumOf(cands[i][0], cands[i][1], cands[i][2]) - lb); if (d > bd) { bd = d; best = cands[i]; } }
    return best;
  }

  /**
   * Draw object `which` (an index into OBJECTS) into the round patch at (cx, cy) of radius r. Refuses (null, untouched)
   * when the ground is too busy for an object to read on, or when no body colour separates from it.
   * @returns {{x,y,r,object:string,body:number[],ground:number[],busy:number}|null}
   */
  function addObject(img, cx, cy, r, which, o) {
    o = o || {};
    var W = img.width, H = img.height, d = img.data;
    cx = Math.round(cx); cy = Math.round(cy); r = Math.round(r);
    if (cx - r < 0 || cy - r < 0 || cx + r >= W || cy + r >= H) return null;
    var ob = OBJECTS[((which | 0) % OBJECTS.length + OBJECTS.length) % OBJECTS.length];
    // the ground: its mean colour and how busy it is (luminance spread). An object on busy ground is a hunt, not a find.
    var n = 0, sr = 0, sg = 0, sb = 0, sl = 0, sll = 0, x, y, i, k, bestGap;
    for (y = -r; y <= r; y++) for (x = -r; x <= r; x++) {
      if (x * x + y * y > r * r) continue;
      i = ((cy + y) * W + cx + x) * 4; var l = lumOf(d[i], d[i + 1], d[i + 2]);
      sr += d[i]; sg += d[i + 1]; sb += d[i + 2]; sl += l; sll += l * l; n++;
    }
    var gm = [sr / n, sg / n, sb / n], lm = sl / n, busyness = Math.sqrt(Math.max(0, sll / n - lm * lm));
    if (busyness > (o.maxBusy === undefined ? BUSY : o.maxBusy)) return null;
    var cands = []; for (var k = 0; k < ob.body.length; k++) cands.push(PAINT[ob.body[k]]);
    var body = pickContrast(gm, cands), minSep = o.minSep === undefined ? SEP : o.minSep;
    if (Math.abs(lumOf(body[0], body[1], body[2]) - lm) < minSep) return null;
    // luminance decides what CAN be seen (22e); among the colours nearly as separated as the best, the one furthest in
    // HUE from the ground reads best (a blue kite on a blue sky won on luminance by 98 to red's 90, objects_big.png)
    var bestSep = Math.abs(lumOf(body[0], body[1], body[2]) - lm), gh = hueOf(gm[0], gm[1], gm[2]), gc = Math.max(gm[0], gm[1], gm[2]) - Math.min(gm[0], gm[1], gm[2]);
    // On a NEUTRAL ground (a cloudy sky, chroma under 25) hue means nothing, so the object's own colour order decides
    // (its first colour is the one it is drawn in by preference: a red kite, not the blue that won by luminance)
    for (k = 0, bestGap = -1; k < cands.length; k++) {
      var cs = Math.abs(lumOf(cands[k][0], cands[k][1], cands[k][2]) - lm);
      if (cs < minSep || cs < bestSep * 0.8) continue;
      var cg = gc < 25 ? cands.length - k : Math.max(cands[k][0], cands[k][1], cands[k][2]) - Math.min(cands[k][0], cands[k][1], cands[k][2]) < 40 ? 0 : hueGap(hueOf(cands[k][0], cands[k][1], cands[k][2]), gh);
      if (cg > bestGap) { bestGap = cg; body = cands[k]; }
    }
    // the outline is the body's own colour taken down (a black body keeps a black edge: a silhouette, never a sticker
    // with a pale rim); details drawn INSIDE the body (an eye, lantern bars) take whichever ink separates from it
    var col = { body: body, edge: [body[0] * 0.36, body[1] * 0.36, body[2] * 0.36], ink: pickContrast(body, ROLE.ink), metal: pickContrast(gm, ROLE.metal), stem: pickContrast(gm, ROLE.stem), leaf: pickContrast(gm, ROLE.leaf), gold: pickContrast(body, ROLE.gold), cream: pickContrast(body, ROLE.cream) };
    var s = r / 1.2, flip = o.flip ? -1 : 1, tilt = o.tilt || 0, ct = Math.cos(tilt), st = Math.sin(tilt), pen = Math.max(0.9, s * 0.07);
    var snap = new Uint8ClampedArray(d), L = ob.layers;
    for (y = -r; y <= r; y++) for (x = -r; x <= r; x++) {
      i = ((cy + y) * W + cx + x) * 4;
      // object space: undo the tilt, then the flip
      var px = x / s, py = y / s, u = (px * ct + py * st) * flip, v = -px * st + py * ct;
      // a soft drop shadow first, so the object sits ON the picture rather than floating over it
      var su = ((x - s * 0.08) / s * ct + (y - s * 0.1) / s * st) * flip, sv = -(x - s * 0.08) / s * st + (y - s * 0.1) / s * ct, sd = 9;
      for (k = 0; k < L.length; k++) sd = Math.min(sd, L[k].f(su, sv));
      var sa = 0.32 * clamp01(0.5 - sd * s / 2.5);
      if (sa > 0) { d[i] = d[i] * (1 - sa); d[i + 1] = d[i + 1] * (1 - sa); d[i + 2] = d[i + 2] * (1 - sa); }
      // the ground's own grain carried through the paint (a third of its deviation, in absolute levels: as a RATIO it
      // speckled every object on a dark ground, objects_big.png 2026-10-04), so the object looks painted ON this canvas
      var grain = Math.max(-12, Math.min(12, (lumOf(snap[i], snap[i + 1], snap[i + 2]) - lm) * 0.33));
      var shade = Math.max(0.78, Math.min(1.22, 1 - 0.2 * (u * 0.55 + v * 0.75)));
      for (k = 0; k < L.length; k++) {
        var dd = L[k].f(u, v) * s, c = col[L[k].role], ow = L[k].pen ? pen * L[k].pen : 0;
        var co = clamp01(0.5 - dd), cf = clamp01(0.5 - (dd + ow));
        if (co <= 0) continue;
        if (ow > 0) { var ik = col.edge, oa = co * 0.9; d[i] += (ik[0] - d[i]) * oa; d[i + 1] += (ik[1] - d[i + 1]) * oa; d[i + 2] += (ik[2] - d[i + 2]) * oa; }
        if (cf > 0) { d[i] += (c[0] * shade + grain - d[i]) * cf; d[i + 1] += (c[1] * shade + grain - d[i + 1]) * cf; d[i + 2] += (c[2] * shade + grain - d[i + 2]) * cf; }
      }
    }
    return { x: cx, y: cy, r: r, object: ob.id, body: body, ground: [Math.round(gm[0]), Math.round(gm[1]), Math.round(gm[2])], busy: Math.round(busyness) };
  }
  function clamp01(t) { return t < 0 ? 0 : t > 1 ? 1 : t; }

  function restore(dst, src, cx, cy, r) {
    var W = src.width, H = src.height;
    for (var y = Math.max(0, cy - r); y < Math.min(H, cy + r + 1); y++) for (var x = Math.max(0, cx - r); x < Math.min(W, cx + r + 1); x++) {
      var i = (y * W + x) * 4; dst.data[i] = src.data[i]; dst.data[i + 1] = src.data[i + 1]; dst.data[i + 2] = src.data[i + 2]; dst.data[i + 3] = src.data[i + 3];
    }
  }

  /**
   * The second picture: up to `count` changes (1-12, default 5), each spaced from the others and each clearing the
   * visibility floor; a change that does not clear it is undone and the next place is tried. The original is never
   * touched. @returns {{image:{width,height,data}, changes:Array<{kind,x,y,r}>}}
   */
  function makeDifferences(img, o) {
    o = o || {};
    var W = img.width | 0, H = img.height | 0, out = { width: W, height: H, data: new Uint8ClampedArray(img.data) };
    if (W < 32 || H < 32) return { image: out, changes: [] };
    var want = Math.round(Number(o.count)); if (!isFinite(want)) want = 5; want = Math.max(1, Math.min(12, want));
    var R = rng(seedOf(o.seed === undefined ? 'pendant' : o.seed)), G = 16, cand = [], x, y, k;
    for (y = G * 2; y < H - G * 2; y += G) for (x = G * 2; x < W - G * 2; x += G) cand.push([x + G / 2, y + G / 2]);
    for (k = cand.length - 1; k > 0; k--) { var j = Math.floor(R() * (k + 1)), t = cand[k]; cand[k] = cand[j]; cand[j] = t; }
    // Each slot WANTS a kind (rotating) and keeps it across places; only after HOLD real refusals in a row does it take
    // whichever kind a place allows. Without the hold, paint-out (which never refuses) caught every fallback and made
    // 243 of 420 changes (balance probe 2026-10-04) - a puzzle of near-identical removals.
    // A held slot that falls back tries PAINT-OUT LAST: paint-out never refuses, so put first it re-took every recolour
    // slot a painterly picture could not fill (250 of 420 changes, recolour_audit 2026-10-04).
    // Slot n WANTS kind ROTATION[n % 4] (an added object first: it is the one kind that is not a removal or a flip).
    // ORDER[kind] is the fallback cascade once the hold runs out; paint-out is always LAST.
    var kinds = ['paintout', 'mirror', 'recolour', 'add'], ROTATION = [3, 1, 2, 0], ORDER = [[0, 1, 3, 2], [1, 3, 2, 0], [2, 3, 1, 0], [3, 1, 2, 0]], changes = [], refused = 0, HOLD = 24;
    // o.kinds: the kinds the buyer allows (names); none allowed or none recognised = all four
    if (o.kinds && o.kinds.length) {
      var ok = [], keep = function (q) { return ok[q]; };
      for (k = 0; k < 4; k++) ok[k] = o.kinds.indexOf(kinds[k]) >= 0;
      if (ok[0] || ok[1] || ok[2] || ok[3]) { ROTATION = ROTATION.filter(keep); ORDER = ORDER.map(function (row) { return row.filter(keep); }); }
    }
    // the objects in a seeded order, each tried at most once per picture before any repeats
    var objOrder = [], objNext = 0, scarce = [false, false, false, false], usedObj = []; for (k = 0; k < OBJECTS.length; k++) objOrder.push(k);
    for (k = objOrder.length - 1; k > 0; k--) { var jo = Math.floor(R() * (k + 1)), to = objOrder[k]; objOrder[k] = objOrder[jo]; objOrder[jo] = to; }
    for (var c = 0; c < cand.length && changes.length < want; c++) {
      // a kind that refused a whole hold is SCARCE in this picture: later slots wanting it still try it first at each
      // place, but fall back there and then (two scarce kinds each holding 24 ran a 320x200 picture out of places,
      // 24 of 30 changes made on pure texture, 2026-10-04)
      var kind0 = ROTATION[changes.length % ROTATION.length];
      if (refused >= HOLD) scarce[kind0] = true;
      var cx = cand[c][0], cy = cand[c][1], tries = refused < HOLD && !scarce[kind0] ? 1 : ORDER[kind0].length, made = false, spaced = true;
      for (var a = 0; a < tries; a++) {
        var kind = kinds[ORDER[kind0][a]], r = kind === 'recolour' ? 40 : kind === 'add' ? 20 + Math.floor(R() * 5) : 18 + Math.floor(R() * 7), res = null;
        for (k = 0; k < changes.length; k++) if (Math.hypot(changes[k].x - cx, changes[k].y - cy) < changes[k].r + r + 8) { spaced = false; break; }
        if (!spaced) break;
        if (kind === 'paintout') res = paintOut(out, cx, cy, r, (R() < 0.5 ? -1 : 1) * r * 2.2);
        else if (kind === 'mirror') res = mirror(out, cx, cy, r, { minAsym: 0.08 });
        else if (kind === 'recolour') res = recolour(out, cx, cy, { radius: r, minArea: 300, maxArea: 6000, pick: R() });
        else {
          // the next object in the seeded order that BELONGS on this ground (WHERE); none = refuse here
          var cls = groundClass(out, cx, cy, r), pickO = -1, flipO = R() < 0.5, tiltO = (R() - 0.5) * 0.5;
          // an object not yet in this picture first, then one already used (four birds in one harbour sky, class_diag.js
          // 2026-10-04) - and EVERY fitting object is tried until one draws: offering only the first, a lantern that can
          // never separate from mid-grey refused forever and starved a flat grey picture to 2 of 12 (docs_break.js)
          // a repeat is a LAST resort: only after REPEAT_AFTER refusals in a row may an object already used be drawn again
          // (allowed at once, the windmill painting's pale sky took three birds in one puzzle, store_shots 2026-10-04)
          for (var pass = 0; pass < (refused >= REPEAT_AFTER ? 2 : 1) && !res; pass++) for (var q = 0; q < objOrder.length && !res; q++) {
            var oi = objOrder[(objNext + q) % objOrder.length];
            if (WHERE[OBJECTS[oi].id].indexOf(cls) < 0 || (pass ? !usedObj[oi] : usedObj[oi])) continue;
            res = addObject(out, cx, cy, r, oi, { flip: flipO, tilt: tiltO });
            if (res) pickO = oi;
          }
          objNext++;
          if (res) { res.ground = cls; usedObj[pickO] = true; }
        }
        if (!res) continue;
        var v = visibility(img, out, cx, cy, r + 6);
        if (v.px >= FLOOR.px && v.meanDelta >= FLOOR.meanDelta) { changes.push(res.object ? { kind: kind, x: res.x, y: res.y, r: res.r, object: res.object, ground: res.ground } : { kind: kind, x: res.x, y: res.y, r: res.r }); made = true; break; }
        restore(out, img, Math.round(cx), Math.round(cy), r + 1);
      }
      if (made) refused = 0; else if (spaced) refused++;
    }
    return { image: out, changes: changes };
  }

  /** Which change (index) a click at (x, y) lands on, or -1. */
  function hit(changes, x, y) {
    for (var i = 0; i < changes.length; i++) { var c = changes[i]; if (Math.hypot(c.x - x, c.y - y) <= c.r + 6) return i; }
    return -1;
  }

  CSAF.PendantCore = { VERSION: '1.0.0', FLOOR: FLOOR, seedOf: seedOf, rng: rng, visibility: visibility, recolour: recolour, mirror: mirror, paintOut: paintOut, addObject: addObject, groundClass: groundClass, WHERE: WHERE, OBJECT_IDS: OBJECTS.map(function (b) { return b.id; }), objectDistance: function (k, u, v) { var L = OBJECTS[k].layers, m = 9; for (var i = 0; i < L.length; i++) m = Math.min(m, L[i].f(u, v)); return m; }, pickContrast: pickContrast, makeDifferences: makeDifferences, hit: hit };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.PendantCore;
