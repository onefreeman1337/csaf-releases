//=============================================================================
// Pendant.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Pendant: any picture in your project, hung twice in a gallery, with generated differences to find.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * Recommended order: PendantCore.js, then Pendant.js (this file). Any order
 * works: the files find each other when the first puzzle opens.
 * RPG Maker MV 1.6: also CSAF_MVBridge.js at the TOP of the list. In MV the
 * command is a Plugin Command line:
 *   Pendant start picture=Castle count=5 seed=7
 *   Pendant start picture="Castle at Night" count=7 time=90 hints=2
 * Script call (MZ and MV):
 *   CSAF.Pendant.start({ picture: 'Castle', count: 5, seed: 7, time: 0, hints: 3 })
 *
 * The picture is any file in img/pictures. It is hung twice, side by side (or
 * one above the other when that makes them larger), and the second copy is
 * changed in `count` places: something painted out, a detail mirrored, an
 * object recoloured, or a small drawn object added that belongs where it lands
 * (a bird in a sky, a fish in water, a lantern on a dark wall). Every change
 * is measured to be visible before it is kept. The same seed always makes the
 * same changes; a blank seed makes new ones every time.
 *
 * The player clicks or taps either painting where they differ, or moves the
 * hand with the arrow keys (Shift = faster) and presses OK. A find is ringed in
 * ink on both paintings; a click on nothing is a miss. Q (Page Up), or a press
 * on the plaque, shows a hint. Cancel gives up and shows what was left.
 *
 * Results are written as the puzzle closes, before the event continues:
 * seconds, finds and misses into variables, a switch ON when every difference
 * was found (OFF otherwise), and an optional common event.
 * CSAF.Pendant.lastResult() returns
 * { picture, count, found, misses, hints, seconds, allFound, timedOut, seed }.
 *
 * @param varSeconds
 * @text Seconds -> variable
 * @type variable
 * @default 0
 *
 * @param varFound
 * @text Finds -> variable
 * @type variable
 * @default 0
 *
 * @param varMisses
 * @text Misses -> variable
 * @type variable
 * @default 0
 *
 * @param swAllFound
 * @text All found -> switch
 * @type switch
 * @default 0
 *
 * @param commonEvent
 * @text Common event afterwards
 * @type common_event
 * @default 0
 *
 * @param wall
 * @text Gallery wall
 * @type select
 * @option Green
 * @value green
 * @option Plum
 * @value plum
 * @option Navy
 * @value navy
 * @option Oxblood
 * @value oxblood
 * @default green
 *
 * @param allowAdd
 * @text Changes: add an object
 * @type boolean
 * @default true
 *
 * @param allowRecolour
 * @text Changes: recolour
 * @type boolean
 * @default true
 *
 * @param allowMirror
 * @text Changes: mirror a detail
 * @type boolean
 * @default true
 *
 * @param allowPaintout
 * @text Changes: paint something out
 * @type boolean
 * @default true
 *
 * @command start
 * @text Start a spot-the-difference
 * @desc Hang a picture twice with generated differences for the player to find.
 *
 * @arg picture
 * @text Picture (img/pictures)
 * @type file
 * @dir img/pictures
 * @default
 *
 * @arg count
 * @text Differences
 * @type number
 * @min 1
 * @max 12
 * @default 5
 *
 * @arg seed
 * @text Seed
 * @desc Blank = new differences every time. A number makes the same ones every time.
 * @type string
 * @default
 *
 * @arg time
 * @text Time limit (seconds)
 * @desc 0 = no limit.
 * @type number
 * @min 0
 * @max 3600
 * @default 0
 *
 * @arg hints
 * @text Hints
 * @type number
 * @min 0
 * @max 9
 * @default 3
 */

var CSAF = CSAF || {};

(function () {
  'use strict';
  var NAME = 'Pendant';
  var RAW = PluginManager.parameters(NAME);
  function num(v, d) { var s = String(v === undefined || v === null ? '' : v).trim(); if (s === '') return d; var n = Number(s); return isFinite(n) ? n : d; }
  function bool(v, d) { var s = String(v === undefined || v === null ? '' : v).trim(); return s === '' ? d : s === 'true'; }
  var KINDS = [];
  if (bool(RAW.allowAdd, true)) KINDS.push('add');
  if (bool(RAW.allowRecolour, true)) KINDS.push('recolour');
  if (bool(RAW.allowMirror, true)) KINDS.push('mirror');
  if (bool(RAW.allowPaintout, true)) KINDS.push('paintout');
  var P = { varSeconds: num(RAW.varSeconds, 0), varFound: num(RAW.varFound, 0), varMisses: num(RAW.varMisses, 0), swAllFound: num(RAW.swAllFound, 0), commonEvent: num(RAW.commonEvent, 0), wall: String(RAW.wall || 'green'), kinds: KINDS };
  /** The core, resolved at first use: the buyer chooses the load order. */
  function core() {
    if (!CSAF.PendantCore) throw new Error('Pendant needs PendantCore.js installed and ON.');
    return CSAF.PendantCore;
  }
  /** The gallery's type: a book serif, never the engine's UI font. */
  var FONT = 'Georgia, "Palatino Linotype", "Book Antiqua", Palatino, "Times New Roman", serif';
  /** The wall colours: [base, damask, wainscot]. */
  var WALLS = { green: [[30, 50, 42], [40, 64, 54], [44, 30, 22]], plum: [[52, 30, 44], [66, 40, 56], [40, 26, 22]], navy: [[24, 34, 56], [34, 46, 72], [38, 28, 22]], oxblood: [[66, 24, 24], [82, 34, 32], [36, 24, 18]] };
  /** The longest side of the picture the differences are made on: the visibility floors were measured at 640. */
  var WORK = 640, SHORT = 160, LONG = 2400;
  function uiScale() { return Math.max(1, Math.min(3, Math.min(Graphics.width, Graphics.height) / 624)); }
  function rec() { if (!$gameSystem._csafPendant) $gameSystem._csafPendant = { v: 1, count: 0, last: null }; return $gameSystem._csafPendant; }

  var pending = null;
  function start(args) {
    var pic = String(args.picture || '').trim();
    if (!pic) { console.warn('Pendant: no picture given. Pick a file in img/pictures.'); return false; }
    var r = rec();
    var seedText = String(args.seed === undefined ? '' : args.seed).trim();
    var seed = seedText !== '' ? seedText : ('p' + r.count + 'm' + ($gameMap ? $gameMap.mapId() : 0) + 'f' + Graphics.frameCount);
    var time = args.time !== undefined ? args.time : args.timeLimit;
    pending = { picture: pic, count: Math.max(1, Math.min(12, Math.round(num(args.count, 5)))), seed: seed, time: Math.max(0, Math.min(3600, Math.round(num(time, 0)))), hints: Math.max(0, Math.min(9, Math.round(num(args.hints, 3)))) };
    SceneManager.push(Scene_Pendant);
    return true;
  }
  // MV has no registerCommand until CSAF_MVBridge.js has loaded: say so instead of throwing at boot
  if (typeof PluginManager.registerCommand === 'function') PluginManager.registerCommand(NAME, 'start', function (args) { start(args); });
  else console.warn('Pendant: in RPG Maker MV, put CSAF_MVBridge.js at the TOP of the plugin list, above the Pendant files. The script call CSAF.Pendant.start({...}) still works.');

  //---------------------------------------------------------------------------
  function Scene_Pendant() { this.initialize.apply(this, arguments); }
  Scene_Pendant.prototype = Object.create(Scene_Base.prototype);
  Scene_Pendant.prototype.constructor = Scene_Pendant;

  Scene_Pendant.prototype.initialize = function () {
    Scene_Base.prototype.initialize.call(this);
    this._req = pending; pending = null;
    this._picture = this._req ? ImageManager.loadPicture(this._req.picture) : null;
    this._built = false; this._frames = 0; this._done = false; this._doneAge = 0; this._misses = 0; this._foundN = 0; this._hintsUsed = 0; this._hintAge = -1; this._hudKey = -1;
  };

  Scene_Pendant.prototype.isReady = function () { return Scene_Base.prototype.isReady.call(this) && (!this._picture || this._picture.isReady()); };

  Scene_Pendant.prototype.start = function () {
    Scene_Base.prototype.start.call(this);
    if (!this._req || !this._picture || this._picture.width === 0) { console.warn('Pendant: the picture could not be loaded.'); this.popScene(); return; }
    this.build();
  };

  /**
   * The layout: side by side, or one above the other, whichever hangs the larger paintings, inside a margin that leaves
   * the picture rail above and the plaque below. @returns {{w,h,f,ax,ay,bx,by,stacked}} each painting's picture area
   * (w x h), its frame width f, and the top-left of the two picture areas.
   */
  Scene_Pendant.prototype.solveLayout = function (pw, ph) {
    var W = Graphics.width, H = Graphics.height, S = uiScale(), top = Math.round(46 * S), foot = Math.round(78 * S), side = Math.round(22 * S), gap = Math.round(26 * S);
    var best = null;
    for (var stacked = 0; stacked < 2; stacked++) {
      // frame width is a share of the painting, so solve twice: guess, then refine
      var f = Math.round(14 * S);
      for (var it = 0; it < 3; it++) {
        var aw = stacked ? W - side * 2 - f * 2 : (W - side * 2 - gap - f * 4) / 2, ah = stacked ? (H - top - foot - gap - f * 4) / 2 : H - top - foot - f * 2;
        var k = Math.min(aw / pw, ah / ph), w = Math.max(16, Math.floor(pw * k)), h = Math.max(16, Math.floor(ph * k));
        f = Math.round(Math.max(9 * S, Math.min(30 * S, Math.min(w, h) * 0.075)));
      }
      var L;
      if (stacked) { var x0 = Math.round((W - w) / 2), used = h * 2 + f * 4 + gap, y0 = top + Math.round((H - top - foot - used) / 2) + f; L = { w: w, h: h, f: f, ax: x0, ay: y0, bx: x0, by: y0 + h + f * 2 + gap, stacked: true }; }
      else { var usedW = w * 2 + f * 4 + gap, xa = Math.round((W - usedW) / 2) + f, ya = top + Math.round((H - top - foot - h - f * 2) / 2) + f; L = { w: w, h: h, f: f, ax: xa, ay: ya, bx: xa + w + f * 2 + gap, by: ya, stacked: false }; }
      if (!best || L.w * L.h > best.w * best.h) best = L;
    }
    return best;
  };

  /** Make the differences on a WORK-sized copy of the picture, then hang both copies. */
  Scene_Pendant.prototype.build = function () {
    var C = core(), W = Graphics.width, H = Graphics.height, S = uiScale(), src = this._picture._image || this._picture.canvas;
    // the long side at WORK - but a long thin picture keeps its short side at SHORT or more, or there is no room for a
    // change at all (a 2400 x 200 panorama came out 640 x 53 and never opened, docs_break.js 2026-10-04); long side capped
    var pw = this._picture.width, ph = this._picture.height, k = Math.min(Math.max(WORK / Math.max(pw, ph), SHORT / Math.min(pw, ph)), LONG / Math.max(pw, ph));
    var ww = Math.max(32, Math.round(pw * k)), wh = Math.max(32, Math.round(ph * k));
    var wc = document.createElement('canvas'); wc.width = ww; wc.height = wh;
    var wx = wc.getContext('2d'); wx.drawImage(src, 0, 0, ww, wh);
    var id = wx.getImageData(0, 0, ww, wh), orig = { width: ww, height: wh, data: id.data };
    var res = C.makeDifferences(orig, { count: this._req.count, seed: this._req.seed, kinds: P.kinds });
    // the kinds the buyer allows may find nothing to change on THIS picture (recolour alone on a picture with no edged
    // objects): a puzzle with no differences could never be won, so this picture gets all four kinds instead
    if (!res.changes.length && P.kinds.length < 4) { console.warn('Pendant: the allowed kinds of change found nothing to change on "' + this._req.picture + '"; using all four for this picture.'); res = C.makeDifferences(orig, { count: this._req.count, seed: this._req.seed }); }
    if (!res.changes.length) { console.warn('Pendant: no visible difference could be made on "' + this._req.picture + '".'); this.popScene(); return; }
    this._changes = res.changes; this._found = []; for (var i = 0; i < res.changes.length; i++) this._found.push(false);
    var cc = document.createElement('canvas'); cc.width = ww; cc.height = wh;
    cc.getContext('2d').putImageData(new ImageData(res.image.data, ww, wh), 0, 0);
    this._work = { w: ww, h: wh, original: wc, changed: cc };
    var L = this.solveLayout(ww, wh); this._L = L; this._S = S;
    // the gallery: wall, rail, cords, lights, frames and both paintings in ONE bitmap, drawn once
    var g = new Bitmap(W, H), c = g.context;
    drawWall(c, W, H, S, WALLS[P.wall] || WALLS.green);
    drawHanging(c, L, S);
    drawFrame(c, L.ax, L.ay, L.w, L.h, L.f, S); drawFrame(c, L.bx, L.by, L.w, L.h, L.f, S);
    c.imageSmoothingEnabled = true;
    c.drawImage(wc, L.ax, L.ay, L.w, L.h); c.drawImage(cc, L.bx, L.by, L.w, L.h);
    drawLight(c, L, S);
    g._baseTexture.update();
    this.addChild(new Sprite(g));
    // rings: one pre-drawn ink ring per change and painting, hidden until found (no bitmap work during play)
    this._rings = new Sprite(); this.addChild(this._rings); this._ringSp = [];
    var sc = L.w / ww;
    for (i = 0; i < this._changes.length; i++) {
      var ch = this._changes[i], rr = Math.max(9 * S, (ch.r + 4) * sc), pad = Math.ceil(rr * 0.35 + 4), bmp = new Bitmap(Math.ceil(rr * 2 + pad * 2), Math.ceil(rr * 2 + pad * 2));
      drawRing(bmp.context, bmp.width / 2, bmp.height / 2, rr, i * 1.7 + 0.4, Math.max(1.6, 2.2 * S), false); bmp._baseTexture.update();
      var gb = new Bitmap(bmp.width, bmp.height); drawRing(gb.context, gb.width / 2, gb.height / 2, rr, i * 1.7 + 0.4, Math.max(1.6, 2.2 * S), true); gb._baseTexture.update();
      var pair = [];
      for (var side = 0; side < 2; side++) {
        var sp = new Sprite(bmp); sp.anchor.x = sp.anchor.y = 0.5;
        sp.x = (side ? L.bx : L.ax) + ch.x * sc; sp.y = (side ? L.by : L.ay) + ch.y * sc; sp.visible = false; sp._age = 0; sp._ghost = gb; sp._ink = bmp;
        this._rings.addChild(sp); pair.push(sp);
      }
      this._ringSp.push(pair);
    }
    // misses: a small pool of pre-drawn ticks that fade where the player clicked on nothing
    var mb = new Bitmap(Math.round(26 * S), Math.round(26 * S)); drawMiss(mb.context, mb.width, S); mb._baseTexture.update();
    this._missSp = []; this._missNext = 0;
    for (i = 0; i < 4; i++) { var ms = new Sprite(mb); ms.anchor.x = ms.anchor.y = 0.5; ms.opacity = 0; this.addChild(ms); this._missSp.push(ms); }
    // the hint: a soft lamp-glow that settles over an unfound difference
    var hb = new Bitmap(Math.round(160 * S), Math.round(160 * S)), hx = hb.context, gr = hx.createRadialGradient(hb.width / 2, hb.height / 2, 0, hb.width / 2, hb.height / 2, hb.width / 2);
    // a bright lamplit ring with a dark outer edge, so it reads on a pale sky and a dark wall alike (the first, a soft
    // 0.55 glow, could barely be seen on the harbour's water: MZ_hint.png 2026-10-04)
    gr.addColorStop(0, 'rgba(255,236,170,0)'); gr.addColorStop(0.6, 'rgba(255,236,170,0.06)'); gr.addColorStop(0.7, 'rgba(255,238,170,0.95)'); gr.addColorStop(0.78, 'rgba(255,212,110,0.95)');
    gr.addColorStop(0.84, 'rgba(70,36,4,0.6)'); gr.addColorStop(0.92, 'rgba(40,20,0,0.18)'); gr.addColorStop(1, 'rgba(40,20,0,0)');
    hx.fillStyle = gr; hx.fillRect(0, 0, hb.width, hb.height); hb._baseTexture.update();
    this._hint = []; for (i = 0; i < 2; i++) { var hs = new Sprite(hb); hs.anchor.x = hs.anchor.y = 0.5; hs.opacity = 0; this.addChild(hs); this._hint.push(hs); }
    // the hand: keyboard players move it with the arrows
    var hand = new Bitmap(28, 28), hc = hand.context;
    hc.fillStyle = 'rgba(255,240,205,0.92)'; hc.strokeStyle = 'rgba(40,25,10,0.9)'; hc.lineWidth = 2;
    hc.beginPath(); hc.moveTo(4, 2); hc.lineTo(4, 22); hc.lineTo(10, 16); hc.lineTo(16, 26); hc.lineTo(20, 24); hc.lineTo(14, 14); hc.lineTo(22, 14); hc.closePath(); hc.fill(); hc.stroke(); hand._baseTexture.update();
    this._hand = new Sprite(hand); this._hand.x = Math.round(L.bx + L.w / 2); this._hand.y = Math.round(L.by + L.h / 2); this._hand.visible = false; this.addChild(this._hand);
    // the plaque: found, time, misses, hints
    var pwid = Math.min(W - 40, Math.round(460 * S)), phgt = Math.round(52 * S);
    this._hud = new Sprite(new Bitmap(pwid, phgt)); this._hud.x = Math.round((W - pwid) / 2); this._hud.y = H - Math.round(78 * S) + Math.round(13 * S); this.addChild(this._hud);
    this._built = true;
    this.drawHud();
  };

  //---------------------------------------------------------------------------
  // Drawing (once, at build)

  /** The gallery wall: a damask in the wall's own colour, a dado rail and a wainscot, lit from above. */
  function drawWall(c, W, H, S, col) {
    var b = col[0], d = col[1], wn = col[2], dado = Math.round(H * 0.86);
    c.fillStyle = rgb(b); c.fillRect(0, 0, W, H);
    // damask: a lozenge lattice of small four-petal motifs, pitch from the screen, not a count
    var p = Math.round(34 * S);
    c.fillStyle = rgb(d);
    for (var y = -p, row = 0; y < dado + p; y += p * 0.86, row++) for (var x = (row % 2) * p / 2 - p; x < W + p; x += p) {
      c.beginPath();
      for (var q = 0; q < 4; q++) { var a = q * Math.PI / 2; c.moveTo(x, y); c.quadraticCurveTo(x + Math.cos(a + 0.5) * p * 0.26, y + Math.sin(a + 0.5) * p * 0.26, x + Math.cos(a) * p * 0.22, y + Math.sin(a) * p * 0.22); c.quadraticCurveTo(x + Math.cos(a - 0.5) * p * 0.26, y + Math.sin(a - 0.5) * p * 0.26, x, y); }
      c.fill();
      c.fillRect(x + p / 2 - 1, y + p * 0.43 - 1, 2, 2);
    }
    // the wainscot below the dado rail
    c.fillStyle = rgb(wn); c.fillRect(0, dado, W, H - dado);
    var pn = Math.round(120 * S);
    for (var px = Math.round(((W % pn) / 2)); px < W; px += pn) {
      c.strokeStyle = 'rgba(0,0,0,0.35)'; c.lineWidth = 2; c.strokeRect(px + 8, dado + 10 * S, pn - 16, H - dado - 18 * S);
      c.strokeStyle = 'rgba(255,220,170,0.08)'; c.lineWidth = 1; c.strokeRect(px + 9.5, dado + 11.5 * S, pn - 19, H - dado - 21 * S);
    }
    var rg = c.createLinearGradient(0, dado - 6 * S, 0, dado + 6 * S);
    rg.addColorStop(0, '#6b4a2c'); rg.addColorStop(0.45, '#9a7044'); rg.addColorStop(1, '#3a2615');
    c.fillStyle = rg; c.fillRect(0, dado - 5 * S, W, 10 * S);
    // a vignette: the room darkens towards its corners
    var v = c.createRadialGradient(W / 2, H * 0.42, Math.min(W, H) * 0.25, W / 2, H * 0.42, Math.max(W, H) * 0.75);
    v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(0,0,0,0.55)');
    c.fillStyle = v; c.fillRect(0, 0, W, H);
  }

  /** The picture rail across the top and two cords per painting, meeting at a brass hook: a pendant pair. */
  function drawHanging(c, L, S) {
    var W = Graphics.width, ry = Math.round(14 * S);
    var rg = c.createLinearGradient(0, ry - 5 * S, 0, ry + 5 * S);
    rg.addColorStop(0, '#2a1a0e'); rg.addColorStop(0.4, '#8a6236'); rg.addColorStop(1, '#24160b');
    c.fillStyle = rg; c.fillRect(0, ry - 5 * S, W, 10 * S);
    var boxes = [[L.ax, L.ay], [L.bx, L.by]];
    for (var i = 0; i < 2; i++) {
      var fx = boxes[i][0] - L.f, fy = boxes[i][1] - L.f, fw = L.w + L.f * 2, hx = fx + fw / 2;
      // the lower painting of a stacked pair hangs from the upper frame's foot, so its cords are short
      var hy = (L.stacked && i === 1) ? L.ay + L.h + L.f : ry;
      for (var s = -1; s <= 1; s += 2) {
        var ex = hx + s * fw * 0.32, ey = fy + L.f * 0.3;
        c.strokeStyle = 'rgba(0,0,0,0.35)'; c.lineWidth = 2.6 * S; c.beginPath(); c.moveTo(hx + 2, hy + 3); c.lineTo(ex + 2, ey + 3); c.stroke();
        c.strokeStyle = '#b89254'; c.lineWidth = 1.6 * S; c.beginPath(); c.moveTo(hx, hy); c.lineTo(ex, ey); c.stroke();
        c.strokeStyle = 'rgba(255,240,200,0.45)'; c.lineWidth = 0.7 * S; c.beginPath(); c.moveTo(hx - 0.6, hy); c.lineTo(ex - 0.6, ey); c.stroke();
      }
      var hk = c.createRadialGradient(hx - 1.5 * S, hy - 1.5 * S, 0, hx, hy, 5 * S);
      hk.addColorStop(0, '#fff2c8'); hk.addColorStop(0.5, '#c9a052'); hk.addColorStop(1, '#5a3c14');
      c.fillStyle = hk; c.beginPath(); c.arc(hx, hy, 4.5 * S, 0, Math.PI * 2); c.fill();
    }
  }

  /**
   * A gilt frame around the picture area (x, y, w, h), f wide: a dark outer step, a gilt moulding lit from the upper left,
   * a beaded band whose bead count is DERIVED from each run at a pitch of its own width (wing Icon_Doctrine 22b-1a), and
   * a dark sight edge. Mitred, so each side is its own trapezoid.
   */
  function drawFrame(c, x, y, w, h, f, S) {
    var X0 = x - f, Y0 = y - f, X1 = x + w + f, Y1 = y + h + f;
    c.fillStyle = 'rgba(0,0,0,0.45)'; c.fillRect(X0 + 4 * S, Y0 + 6 * S, X1 - X0, Y1 - Y0);
    // the four mitred sides, each shaded by which way it faces the light (upper left)
    var sides = [[X0, Y0, X1, Y0, X1 - f, Y0 + f, X0 + f, Y0 + f, 1.18], [X1, Y0, X1, Y1, X1 - f, Y1 - f, X1 - f, Y0 + f, 0.78], [X1, Y1, X0, Y1, X0 + f, Y1 - f, X1 - f, Y1 - f, 0.66], [X0, Y1, X0, Y0, X0 + f, Y0 + f, X0 + f, Y1 - f, 1.04]];
    for (var s = 0; s < 4; s++) {
      var q = sides[s], k = q[8];
      c.save(); c.beginPath(); c.moveTo(q[0], q[1]); c.lineTo(q[2], q[3]); c.lineTo(q[4], q[5]); c.lineTo(q[6], q[7]); c.closePath(); c.clip();
      // a moulding profile across the side: dark step, bright round, a hollow, a bright fillet
      var horiz = s % 2 === 0, a0 = horiz ? (s === 0 ? Y0 : Y1) : (s === 3 ? X0 : X1), dir = (s === 0 || s === 3) ? 1 : -1;
      var gr = horiz ? c.createLinearGradient(0, a0, 0, a0 + dir * f) : c.createLinearGradient(a0, 0, a0 + dir * f, 0);
      gr.addColorStop(0, shade([60, 40, 16], k)); gr.addColorStop(0.1, shade([150, 108, 44], k)); gr.addColorStop(0.28, shade([238, 200, 120], k));
      gr.addColorStop(0.45, shade([176, 128, 52], k)); gr.addColorStop(0.62, shade([96, 66, 26], k)); gr.addColorStop(0.78, shade([214, 172, 92], k)); gr.addColorStop(0.9, shade([120, 84, 34], k)); gr.addColorStop(1, shade([40, 26, 10], k));
      c.fillStyle = gr; c.fillRect(X0, Y0, X1 - X0, Y1 - Y0);
      c.restore();
    }
    // the beaded band in the hollow: pitch = bead width, count derived from the real run
    var bd = Math.max(2.2 * S, f * 0.13), off = f * 0.62, pitch = bd * 1.9;
    var runs = [[X0 + off, Y0 + off, X1 - off, Y0 + off], [X1 - off, Y0 + off, X1 - off, Y1 - off], [X1 - off, Y1 - off, X0 + off, Y1 - off], [X0 + off, Y1 - off, X0 + off, Y0 + off]];
    for (var r = 0; r < 4; r++) {
      var R = runs[r], len = Math.hypot(R[2] - R[0], R[3] - R[1]), n = Math.max(2, Math.floor(len / pitch)), step = len / n, ux = (R[2] - R[0]) / len, uy = (R[3] - R[1]) / len;
      for (var b = 0; b < n; b++) {
        var bx = R[0] + ux * (b + 0.5) * step, by = R[1] + uy * (b + 0.5) * step, bg = c.createRadialGradient(bx - bd * 0.25, by - bd * 0.25, 0, bx, by, bd * 0.5);
        bg.addColorStop(0, '#fff0c0'); bg.addColorStop(0.55, '#c49446'); bg.addColorStop(1, '#4a3010');
        c.fillStyle = bg; c.beginPath(); c.arc(bx, by, bd * 0.5, 0, Math.PI * 2); c.fill();
      }
    }
    // corner rosettes where the mitres meet the hollow
    var corners = [[X0 + off, Y0 + off], [X1 - off, Y0 + off], [X1 - off, Y1 - off], [X0 + off, Y1 - off]];
    for (var cn = 0; cn < 4; cn++) {
      var cx = corners[cn][0], cy = corners[cn][1], rr = f * 0.3;
      for (var pt = 0; pt < 4; pt++) { var a = pt * Math.PI / 2 + Math.PI / 4; c.fillStyle = '#d8b066'; c.beginPath(); c.ellipse(cx + Math.cos(a) * rr * 0.45, cy + Math.sin(a) * rr * 0.45, rr * 0.42, rr * 0.22, a, 0, Math.PI * 2); c.fill(); }
      var rg = c.createRadialGradient(cx - rr * 0.15, cy - rr * 0.15, 0, cx, cy, rr * 0.4);
      rg.addColorStop(0, '#fff4cc'); rg.addColorStop(1, '#8a5e20'); c.fillStyle = rg; c.beginPath(); c.arc(cx, cy, rr * 0.36, 0, Math.PI * 2); c.fill();
    }
    // the sight edge: a dark line and a thin gold fillet against the picture
    c.fillStyle = '#1a1006'; c.fillRect(x - 3, y - 3, w + 6, h + 6);
    c.strokeStyle = '#e2c27c'; c.lineWidth = 1; c.strokeRect(x - 1.5, y - 1.5, w + 3, h + 3);
  }

  /** A picture light's warm wash over each painting's upper half (painted over the pictures, very soft). */
  function drawLight(c, L, S) {
    var boxes = [[L.ax, L.ay], [L.bx, L.by]];
    for (var i = 0; i < 2; i++) {
      var x = boxes[i][0], y = boxes[i][1], g = c.createRadialGradient(x + L.w / 2, y - L.f, 0, x + L.w / 2, y - L.f, Math.max(L.w, L.h) * 0.9);
      g.addColorStop(0, 'rgba(255,226,160,0.16)'); g.addColorStop(0.5, 'rgba(255,226,160,0.05)'); g.addColorStop(1, 'rgba(255,226,160,0)');
      c.fillStyle = g; c.fillRect(x - L.f, y - L.f, L.w + L.f * 2, L.h + L.f * 2);
      // the lamp itself: a brass hood on a short arm above the frame
      var lx = x + L.w / 2, ly = y - L.f - 9 * S, hw = Math.min(L.w * 0.22, 46 * S);
      c.fillStyle = 'rgba(0,0,0,0.4)'; c.fillRect(lx - hw + 2, ly - 4 * S + 3, hw * 2, 8 * S);
      var lg = c.createLinearGradient(0, ly - 4 * S, 0, ly + 4 * S); lg.addColorStop(0, '#f2d496'); lg.addColorStop(0.5, '#a87a36'); lg.addColorStop(1, '#4a3010');
      c.fillStyle = lg; c.beginPath(); c.moveTo(lx - hw, ly + 4 * S); c.lineTo(lx - hw * 0.8, ly - 4 * S); c.lineTo(lx + hw * 0.8, ly - 4 * S); c.lineTo(lx + hw, ly + 4 * S); c.closePath(); c.fill();
      c.fillStyle = 'rgba(255,240,190,0.9)'; c.fillRect(lx - hw * 0.92, ly + 3 * S, hw * 1.84, 1.4 * S);
    }
  }

  /**
   * An ink ring drawn by hand: two strokes that do not quite close, the second a little wider, the reach wobbling with
   * the angle. `ghost` draws the reveal ring (a dashed ochre pencil line) for a difference left unfound.
   */
  function drawRing(c, cx, cy, r, ph, lw, ghost) {
    c.save(); c.lineCap = 'round'; c.lineJoin = 'round';
    for (var pass = 0; pass < (ghost ? 1 : 2); pass++) {
      c.beginPath();
      var a0 = ph + pass * 0.9, span = Math.PI * 2 + (ghost ? 0 : 0.35);
      for (var t = 0; t <= 64; t++) {
        var a = a0 + span * t / 64, rr = r * (1 + 0.06 * Math.sin(a * 2 + ph) + 0.03 * Math.sin(a * 5 + ph * 2) + pass * 0.05);
        var px = cx + Math.cos(a) * rr * 1.06, py = cy + Math.sin(a) * rr * 0.96;
        if (t === 0) c.moveTo(px, py); else c.lineTo(px, py);
      }
      if (ghost) { c.setLineDash([lw * 2.4, lw * 2]); c.strokeStyle = 'rgba(30,18,6,0.6)'; c.lineWidth = lw * 2.2; c.stroke(); c.strokeStyle = '#f0c058'; c.lineWidth = lw * 1.1; c.stroke(); }
      else { c.strokeStyle = 'rgba(255,246,226,0.75)'; c.lineWidth = lw * (pass ? 1.6 : 2.4); c.stroke(); c.strokeStyle = pass ? 'rgba(150,20,16,0.85)' : '#b3201a'; c.lineWidth = lw * (pass ? 0.8 : 1.15); c.stroke(); }
    }
    c.restore();
  }

  /** A miss: a short pencil tick-cross, dark with a light edge so it reads on any picture. */
  function drawMiss(c, s, S) {
    c.save(); c.lineCap = 'round';
    var m = s * 0.28;
    for (var pass = 0; pass < 2; pass++) {
      c.strokeStyle = pass ? 'rgba(60,40,30,0.95)' : 'rgba(255,244,224,0.85)'; c.lineWidth = (pass ? 2 : 4) * S;
      c.beginPath(); c.moveTo(m, m); c.lineTo(s - m, s - m); c.moveTo(s - m, m); c.lineTo(m, s - m); c.stroke();
    }
    c.restore();
  }

  function rgb(a) { return 'rgb(' + Math.round(a[0]) + ',' + Math.round(a[1]) + ',' + Math.round(a[2]) + ')'; }
  function shade(a, k) { return 'rgb(' + Math.min(255, Math.round(a[0] * k)) + ',' + Math.min(255, Math.round(a[1] * k)) + ',' + Math.min(255, Math.round(a[2] * k)) + ')'; }
  function roundRect(c, x, y, w, h, r) {
    c.beginPath(); c.moveTo(x + r, y); c.lineTo(x + w - r, y); c.quadraticCurveTo(x + w, y, x + w, y + r); c.lineTo(x + w, y + h - r);
    c.quadraticCurveTo(x + w, y + h, x + w - r, y + h); c.lineTo(x + r, y + h); c.quadraticCurveTo(x, y + h, x, y + h - r);
    c.lineTo(x, y + r); c.quadraticCurveTo(x, y, x + r, y); c.closePath();
  }

  /** The brass plaque: FOUND, TIME (or TIME LEFT), MISSES, HINTS. Redrawn only when what it says changes. */
  Scene_Pendant.prototype.drawHud = function () {
    var secs = Math.floor(this._frames / 60), lim = this._req.time, shown = lim ? Math.max(0, lim - secs) : secs;
    var key = shown * 1e6 + this._foundN * 1e4 + Math.min(99, this._misses) * 1e2 + (this._req.hints - this._hintsUsed);
    if (key === this._hudKey) return;
    this._hudKey = key;
    var b = this._hud.bitmap, w = b.width, h = b.height, c = b.context, S = this._S, n = this._changes.length;
    b.clear();
    c.save();
    var gr = c.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, '#d9b670'); gr.addColorStop(0.18, '#b48a44'); gr.addColorStop(0.55, '#8e6a2e'); gr.addColorStop(1, '#5e4318');
    c.fillStyle = 'rgba(0,0,0,0.45)'; roundRect(c, 3, 4, w - 3, h - 3, 6 * S); c.fill();
    c.fillStyle = gr; roundRect(c, 0.5, 0.5, w - 4, h - 4, 6 * S); c.fill();
    c.strokeStyle = 'rgba(60,40,12,0.8)'; c.lineWidth = 1; roundRect(c, 4.5 * S, 4.5 * S, w - 4 - 9 * S, h - 4 - 9 * S, 4 * S); c.stroke();
    c.strokeStyle = 'rgba(255,240,200,0.5)'; roundRect(c, 5.5 * S, 5.5 * S, w - 4 - 11 * S, h - 4 - 11 * S, 3.5 * S); c.stroke();
    // the four screws
    var sx = [9 * S, w - 13 * S], sy = [9 * S, h - 13 * S];
    for (var i = 0; i < 2; i++) for (var j = 0; j < 2; j++) { c.fillStyle = '#5a3e14'; c.beginPath(); c.arc(sx[i], sy[j], 2.2 * S, 0, Math.PI * 2); c.fill(); c.strokeStyle = 'rgba(255,236,190,0.7)'; c.beginPath(); c.moveTo(sx[i] - 1.5 * S, sy[j] + 1.5 * S); c.lineTo(sx[i] + 1.5 * S, sy[j] - 1.5 * S); c.stroke(); }
    c.restore();
    b.fontFace = FONT; b.outlineWidth = 0; b.fontItalic = false;
    var cols = 4, cw = Math.floor((w - 4 - 40 * S) / cols), x0 = Math.round(20 * S), y1 = Math.round(5 * S), y2 = Math.round(20 * S), mm = Math.floor(shown / 60), ss = shown % 60;
    var labels = ['FOUND', lim ? 'TIME LEFT' : 'TIME', 'MISSES', 'HINTS'], vals = [this._foundN + ' / ' + n, mm + ':' + (ss < 10 ? '0' : '') + ss, String(this._misses), String(this._req.hints - this._hintsUsed)];
    for (i = 0; i < cols; i++) {
      // engraved: a dark cut with a light lower lip
      b.fontSize = Math.round(10 * S); b.textColor = 'rgba(255,240,200,0.55)'; b.drawText(labels[i], x0 + cw * i, y1 + 1, cw, Math.round(16 * S), 'center');
      b.textColor = 'rgba(44,28,8,0.85)'; b.drawText(labels[i], x0 + cw * i, y1, cw, Math.round(16 * S), 'center');
      b.fontSize = Math.round(18 * S); b.textColor = 'rgba(255,240,200,0.5)'; b.drawText(vals[i], x0 + cw * i, y2 + 1, cw, Math.round(22 * S), 'center');
      b.textColor = (i === 1 && lim && shown <= 10) ? '#6a0c08' : '#2a1a06'; b.drawText(vals[i], x0 + cw * i, y2, cw, Math.round(22 * S), 'center');
    }
  };

  //---------------------------------------------------------------------------
  // Play

  /** Which painting (0, 1) and which work-image point a screen point falls on; writes into `out`, no allocation. */
  Scene_Pendant.prototype.toWork = function (x, y, out) {
    var L = this._L, k = this._work.w / L.w;
    if (x >= L.ax && y >= L.ay && x < L.ax + L.w && y < L.ay + L.h) { out.side = 0; out.u = (x - L.ax) * k; out.v = (y - L.ay) * k; return true; }
    if (x >= L.bx && y >= L.by && x < L.bx + L.w && y < L.by + L.h) { out.side = 1; out.u = (x - L.bx) * k; out.v = (y - L.by) * k; return true; }
    return false;
  };
  var PT = { side: 0, u: 0, v: 0 };

  /** A mark at a screen point: a find, a repeat of a find (nothing), a miss, or a press on the wall (nothing). */
  Scene_Pendant.prototype.markAt = function (x, y) {
    if (this._done || !this.toWork(x, y, PT)) return;
    var i = core().hit(this._changes, PT.u, PT.v);
    if (i >= 0 && this._found[i]) return;
    if (i >= 0) {
      this._found[i] = true; this._foundN++;
      for (var s = 0; s < 2; s++) { var sp = this._ringSp[i][s]; sp.visible = true; sp._age = 1; sp.scale.x = sp.scale.y = 1.5; sp.opacity = 0; }
      if (this._hintAge >= 0 && this._hintIdx === i) this._hintAge = -1;
      SoundManager.playOk();
      if (this._foundN === this._changes.length) this.finish(true, false);
      return;
    }
    this._misses++;
    var m = this._missSp[this._missNext]; this._missNext = (this._missNext + 1) % this._missSp.length;
    m.x = x; m.y = y; m.opacity = 255; m.scale.x = m.scale.y = 1.3;
    SoundManager.playBuzzer();
  };

  /** Show a hint: a glow settles over the first unfound difference on both paintings. */
  Scene_Pendant.prototype.hint = function () {
    if (this._done || this._hintsUsed >= this._req.hints || this._hintAge >= 0) return;
    for (var i = 0; i < this._found.length; i++) if (!this._found[i]) break;
    if (i >= this._found.length) return;
    this._hintsUsed++; this._hintIdx = i; this._hintAge = 0;
    var ch = this._changes[i], L = this._L, sc = L.w / this._work.w, want = Math.max(36 * this._S, (ch.r + 30) * sc * 2.4);
    for (var s = 0; s < 2; s++) { var h = this._hint[s]; h.x = (s ? L.bx : L.ax) + ch.x * sc; h.y = (s ? L.by : L.ay) + ch.y * sc; h._scale = want / h.bitmap.width; }
    SoundManager.playCursor();
  };

  /** The ending, once: results written, unfound differences revealed, a plaque. */
  Scene_Pendant.prototype.finish = function (all, timedOut) {
    if (this._done) return;
    this._done = true; this._doneAge = 0; this._allFound = !!all; this._timedOut = !!timedOut;
    var secs = Math.floor(this._frames / 60), r = rec();
    r.count++; r.last = { picture: this._req.picture, count: this._changes.length, found: this._foundN, misses: this._misses, hints: this._hintsUsed, seconds: secs, allFound: this._allFound, timedOut: this._timedOut, seed: String(this._req.seed) };
    if (P.varSeconds) $gameVariables.setValue(P.varSeconds, secs);
    if (P.varFound) $gameVariables.setValue(P.varFound, this._foundN);
    if (P.varMisses) $gameVariables.setValue(P.varMisses, this._misses);
    if (P.swAllFound) $gameSwitches.setValue(P.swAllFound, this._allFound);
    if (P.commonEvent) $gameTemp.reserveCommonEvent(P.commonEvent);
    for (var i = 0; i < this._found.length; i++) if (!this._found[i]) for (var s = 0; s < 2; s++) { var sp = this._ringSp[i][s]; sp.bitmap = sp._ghost; sp.visible = true; sp._age = 1; sp.opacity = 0; sp.scale.x = sp.scale.y = 1.2; }
    this._hint[0].opacity = this._hint[1].opacity = 0; this._hintAge = -1;
    this.drawHud();
    this.buildPlaque(secs);
  };

  Scene_Pendant.prototype.buildPlaque = function (secs) {
    var W = Graphics.width, H = Graphics.height, S = this._S, L = this._L, w = Math.min(W - 40, Math.round(380 * S)), h = Math.round(92 * S), n = this._changes.length;
    var b = new Bitmap(w, h), x = b.context;
    x.save();
    x.fillStyle = 'rgba(20,12,6,0.9)'; roundRect(x, 0.5, 0.5, w - 1, h - 1, 9 * S); x.fill();
    x.strokeStyle = 'rgba(232,196,120,0.8)'; x.lineWidth = Math.max(1, S * 0.9); roundRect(x, 4.5 * S, 4.5 * S, w - 9 * S, h - 9 * S, 6 * S); x.stroke();
    x.fillStyle = x.strokeStyle = 'rgba(232,196,120,0.85)';
    var gap = (this._allFound ? 104 : 118) * S, fy0 = 22 * S;
    for (var s = -1; s <= 1; s += 2) {
      var cx = w / 2 + s * gap;
      x.beginPath(); x.moveTo(cx, fy0); x.lineTo(cx + s * 30 * S, fy0); x.stroke();
      x.beginPath(); x.moveTo(cx + s * 36 * S, fy0); x.lineTo(cx + s * 32 * S, fy0 - 3 * S); x.lineTo(cx + s * 28 * S, fy0); x.lineTo(cx + s * 32 * S, fy0 + 3 * S); x.closePath(); x.fill();
    }
    x.restore();
    b.fontFace = FONT; b.outlineWidth = 0;
    b.fontSize = Math.round(23 * S); b.textColor = '#f4e0b0';
    b.drawText(this._allFound ? 'A L L   F O U N D' : this._timedOut ? 'T I M E' : 'S E T   A S I D E', 0, Math.round(6 * S), w, Math.round(32 * S), 'center');
    var mm = Math.floor(secs / 60), ss = secs % 60, t = mm + ':' + (ss < 10 ? '0' : '') + ss;
    b.fontSize = Math.round(16 * S); b.textColor = '#e8d4aa';
    b.drawText(this._allFound ? (n + ' differences  ·  ' + t + '  ·  ' + this._misses + (this._misses === 1 ? ' miss' : ' misses')) : (this._foundN + ' of ' + n + ' found  ·  ' + t), 0, Math.round(38 * S), w, Math.round(22 * S), 'center');
    b.fontSize = Math.round(12 * S); b.textColor = 'rgba(232,212,170,0.62)';
    b.drawText(this._allFound ? 'OK to continue' : 'the rest are marked  ·  OK to continue', 0, Math.round(62 * S), w, Math.round(18 * S), 'center');
    this._plaque = new Sprite(b); this._plaque.x = Math.round((W - w) / 2);
    // on the wall under the frames when it fits there: over the paintings' middle it hid the very rings the player had
    // just earned (first look, MZ_allfound.png 2026-10-04); else over the lower painting's foot
    // with no room there (1280x720: the fallback over the paintings hid a revealed ring, shot_3 2026-10-04), it takes the
    // counter plaque's place at the foot of the screen, which it repeats
    var below = Math.max(L.ay, L.by) + L.h + L.f + Math.round(6 * S), room = this._hud.y - Math.round(6 * S) - below;
    if (room >= h) this._plaque.y = below + Math.round((room - h) / 2);
    else { this._plaque.y = Math.max(below, H - h - Math.round(6 * S)); this._hud.visible = false; }
    this._plaque.opacity = 0; this.addChild(this._plaque);
  };

  Scene_Pendant.prototype.update = function () {
    Scene_Base.prototype.update.call(this);
    if (!this._built) return;
    // found rings settle in: a quick pop from 1.5 to 1 as they fade up
    for (var i = 0; i < this._ringSp.length; i++) for (var s = 0; s < 2; s++) {
      var sp = this._ringSp[i][s];
      if (sp._age > 0 && sp._age <= 14) { var e = sp._age / 14; e = e * e * (3 - 2 * e); sp.opacity = Math.round(255 * Math.min(1, e * 1.4)); sp.scale.x = sp.scale.y = 1.5 - 0.5 * e; sp._age++; }
    }
    for (i = 0; i < this._missSp.length; i++) { var m = this._missSp[i]; if (m.opacity > 0) { m.opacity = Math.max(0, m.opacity - 9); m.scale.x = m.scale.y = Math.max(1, m.scale.x - 0.02); } }
    if (this._hintAge >= 0) {
      this._hintAge++;
      var t = this._hintAge, op = t < 20 ? t * 12 : t > 150 ? Math.max(0, 255 - (t - 150) * 10) : 230 + Math.round(25 * Math.sin(t * 0.12));
      for (s = 0; s < 2; s++) { var hs = this._hint[s]; hs.opacity = op; hs.scale.x = hs.scale.y = hs._scale * (1 + 0.6 * Math.max(0, 1 - t / 30)); }
      if (t > 176) { this._hintAge = -1; this._hint[0].opacity = this._hint[1].opacity = 0; }
    }
    if (this._done) {
      this._doneAge++;
      if (this._plaque) this._plaque.opacity = Math.max(0, Math.min(255, (this._doneAge - 16) * 12));
      this._hand.visible = false;
      if (this._doneAge > 40 && (Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered())) this.popScene();
      return;
    }
    this._frames++;
    if (this._req.time && this._frames >= this._req.time * 60) { this.finish(false, true); return; }
    // keyboard hand
    var dx = (Input.isPressed('right') ? 1 : 0) - (Input.isPressed('left') ? 1 : 0), dy = (Input.isPressed('down') ? 1 : 0) - (Input.isPressed('up') ? 1 : 0);
    if (dx || dy) { var sp0 = Input.isPressed('shift') ? 9 : 4; this._hand.visible = true; this._hand.x = Math.max(0, Math.min(Graphics.width - 4, this._hand.x + dx * sp0)); this._hand.y = Math.max(0, Math.min(Graphics.height - 4, this._hand.y + dy * sp0)); }
    if (Input.isTriggered('ok')) { this._hand.visible = true; this.markAt(this._hand.x, this._hand.y); }
    if (Input.isTriggered('pageup')) this.hint();
    if (TouchInput.isTriggered()) {
      var hx = TouchInput.x - this._hud.x, hy = TouchInput.y - this._hud.y;
      if (hx >= 0 && hy >= 0 && hx < this._hud.bitmap.width && hy < this._hud.bitmap.height) this.hint();
      else { this._hand.visible = false; this.markAt(TouchInput.x, TouchInput.y); }
    }
    if (!this._done && (Input.isTriggered('cancel') || TouchInput.isCancelled())) this.finish(false, false);
    this.drawHud();
  };

  CSAF.Pendant = { VERSION: '1.0.0', P: P, start: start, Scene_Pendant: Scene_Pendant, lastResult: function () { return $gameSystem && $gameSystem._csafPendant ? $gameSystem._csafPendant.last : null; } };
  window.Scene_Pendant = Scene_Pendant;
})();
