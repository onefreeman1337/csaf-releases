//=============================================================================
// WarhostDraw.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Warhost drawing - soldiers, banners, battlefields and
 * the war record, all drawn from code. Required by Warhost.js.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * WarhostDraw paints everything a Warhost battle shows: every soldier figure
 * (foot, pikes, archers, horse, mages, in each army's livery), every
 * regimental banner (arms generated from the regiment's name), the
 * battlefield itself (meadow, steppe, snow, desert, moor), the formation
 * cards and the war record. No image files are loaded.
 *
 * It has no commands of its own; Warhost.js uses it.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var WarhostDraw = (function () {
  'use strict';

  var FACE = '"Palatino Linotype", "Book Antiqua", Palatino, Georgia, serif';
  var INK = '#2a1d12';

  /* ------------------------------------------------------------------ small helpers */
  function hash2(x, y, s) { var h = (Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263) + Math.imul(s | 0, 2147483647)) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; }
  function smooth(t) { return t * t * (3 - 2 * t); }
  /** Value noise in [0,1). */
  function noise(x, y, s) {
    var xi = Math.floor(x), yi = Math.floor(y), xf = smooth(x - xi), yf = smooth(y - yi);
    var a = hash2(xi, yi, s), b = hash2(xi + 1, yi, s), c = hash2(xi, yi + 1, s), d = hash2(xi + 1, yi + 1, s);
    return a + (b - a) * xf + (c - a) * yf + (a - b - c + d) * xf * yf;
  }
  function fbm(x, y, s) { return noise(x, y, s) * 0.55 + noise(x * 2.1, y * 2.1, s + 7) * 0.28 + noise(x * 4.3, y * 4.3, s + 13) * 0.17; }
  function hexRgb(h) { var m = /^#?([0-9a-f]{6})$/i.exec(String(h || '')); if (!m) return null; var n = parseInt(m[1], 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  function rgb(r, g, b) { return 'rgb(' + Math.round(r) + ',' + Math.round(g) + ',' + Math.round(b) + ')'; }
  function mix(h1, h2, t) { var a = hexRgb(h1), b = hexRgb(h2); if (!a || !b) return h1; return rgb(a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t); }
  function shade(h, k) { var a = hexRgb(h); if (!a) return h; return k < 0 ? rgb(a[0] * (1 + k), a[1] * (1 + k), a[2] * (1 + k)) : rgb(a[0] + (255 - a[0]) * k, a[1] + (255 - a[1]) * k, a[2] + (255 - a[2]) * k); }
  function fitText(ctx, text, maxW, size, style) { ctx.font = (style || 'bold') + ' ' + size + 'px ' + FACE; while (size > 9 && ctx.measureText(text).width > maxW) { size--; ctx.font = (style || 'bold') + ' ' + size + 'px ' + FACE; } return size; }
  function rr(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r); ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h); ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r); ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.closePath(); }

  /* ------------------------------------------------------------------ liveries */
  /** Two armies' colours. side 0 defaults to a blue host, side 1 to a red host; either can be overridden by a #hex. */
  var LIVERIES = [
    { main: '#2f5aa8', trim: '#e9d9a6', dark: '#1a2f5c', metal: '#b9c2cc', skin: '#e2b48c', cloth: '#6b4a2e' },
    { main: '#b02a22', trim: '#1f1a17', dark: '#5c1410', metal: '#aeb4ba', skin: '#d9a57c', cloth: '#4a3a2a' }
  ];
  function livery(side, mainHex) {
    var base = LIVERIES[side ? 1 : 0], out = {}; for (var k in base) out[k] = base[k];
    if (hexRgb(mainHex)) { out.main = mainHex; out.dark = shade(mainHex, -0.45); }
    return out;
  }

  /* ------------------------------------------------------------------ soldiers */
  /** Cell size of the soldier atlas. Every figure is drawn facing RIGHT with its feet at the cell's (CX, FOOT). */
  var CELL = { w: 52, h: 36, cx: 22, foot: 33 };
  var FRAMES = ['stand', 'step', 'strike', 'fallen'];

  function line(ctx, x1, y1, x2, y2, w, c) { ctx.strokeStyle = c; ctx.lineWidth = w; ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); }
  function dot(ctx, x, y, r, c) { ctx.fillStyle = c; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill(); }

  /** One standing figure (not a rider), feet at (x, y). The outline pass draws everything a size fatter in ink first. */
  function figure(ctx, x, y, role, L, frame, pass) {
    var o = pass === 0, ink = '#16100b', grow = o ? 1.1 : 0;
    var step = frame === 1 ? 1.6 : 0, strike = frame === 2;
    var col = function (c) { return o ? ink : c; };
    // legs
    line(ctx, x - 1.2, y - 7, x - 1.6 - step, y - 0.5, 1.9 + grow * 2, col('#3a2c22'));
    line(ctx, x + 1.2, y - 7, x + 1.8 + step, y - 0.5, 1.9 + grow * 2, col('#3a2c22'));
    // body
    var robe = role === 'mage';
    ctx.fillStyle = col(robe ? L.dark : L.main);
    ctx.beginPath();
    if (robe) { ctx.moveTo(x - 3.2 - grow, y - 14.5 - grow); ctx.lineTo(x + 3.2 + grow, y - 14.5 - grow); ctx.lineTo(x + 4.6 + grow, y + grow); ctx.lineTo(x - 4.6 - grow, y + grow); }
    else { ctx.moveTo(x - 3.3 - grow, y - 14.5 - grow); ctx.lineTo(x + 3.3 + grow, y - 14.5 - grow); ctx.lineTo(x + 3.8 + grow, y - 5.5 + grow); ctx.lineTo(x - 3.8 - grow, y - 5.5 + grow); }
    ctx.closePath(); ctx.fill();
    if (!o) {
      ctx.fillStyle = L.trim; ctx.fillRect(x - 3.6, y - 7.4, 7.2, 1.2);                    // belt / hem
      if (!robe) { ctx.fillStyle = L.trim; ctx.fillRect(x - 0.6, y - 14, 1.2, 6.8); }     // tabard stripe
      else { ctx.fillStyle = L.main; ctx.fillRect(x - 0.8, y - 14, 1.6, 14); }
    }
    // head
    dot(ctx, x + 0.4, y - 17.2, 2.7 + grow, col(L.skin));
    // headgear
    ctx.fillStyle = col(role === 'archer' ? L.cloth : role === 'mage' ? L.dark : L.metal);
    ctx.beginPath();
    if (role === 'foot') { ctx.arc(x + 0.4, y - 18, 3.2 + grow, Math.PI, 0); ctx.lineTo(x + 4.6 + grow, y - 17.6); ctx.lineTo(x - 3.8 - grow, y - 17.6); }
    else if (role === 'pike') { ctx.arc(x + 0.4, y - 18.2, 3.0 + grow, Math.PI * 1.05, Math.PI * 1.95); ctx.lineTo(x + 1.2, y - 16); ctx.lineTo(x - 0.4, y - 16); }
    else if (role === 'archer') { ctx.moveTo(x - 3.4 - grow, y - 16); ctx.quadraticCurveTo(x - 2, y - 23 - grow, x + 2.6 + grow, y - 20.5); ctx.lineTo(x + 3.2 + grow, y - 17.5); ctx.lineTo(x - 0.5, y - 19); }
    else if (role === 'mage') { ctx.moveTo(x - 4.6 - grow, y - 18); ctx.lineTo(x + 4.6 + grow, y - 18); ctx.lineTo(x - 1.2, y - 27 - grow); }
    ctx.closePath(); ctx.fill();
    // arms and kit
    if (role === 'foot') {
      var ax = strike ? 7.5 : 4.5, ay = strike ? -15 : -11;
      line(ctx, x + 2.5, y - 13, x + ax, y + ay, 1.4 + grow * 2, col(L.skin));
      line(ctx, x + ax, y + ay, x + ax + (strike ? 6.5 : 1.5), y + ay + (strike ? 1.5 : -7), 1.3 + grow * 2, col('#dfe4ea'));   // sword
      ctx.fillStyle = col(L.dark); ctx.beginPath(); ctx.ellipse(x + 3.6, y - 10, 2.6 + grow, 4.2 + grow, 0, 0, Math.PI * 2); ctx.fill();   // shield
      if (!o) { ctx.fillStyle = L.trim; ctx.beginPath(); ctx.ellipse(x + 3.6, y - 10, 1.4, 2.6, 0, 0, Math.PI * 2); ctx.fill(); dot(ctx, x + 3.6, y - 10, 0.8, L.metal); }
    } else if (role === 'pike') {
      var a = strike ? -0.08 : -0.95, len = 25, bx = x - 3, by = y - 11;
      line(ctx, bx, by, bx + Math.cos(a) * len, by + Math.sin(a) * len, 1.3 + grow * 2, col('#6a4a2a'));
      var tx = bx + Math.cos(a) * len, ty = by + Math.sin(a) * len;
      ctx.fillStyle = col('#e4e8ee'); ctx.beginPath(); ctx.moveTo(tx + Math.cos(a) * 4.5, ty + Math.sin(a) * 4.5); ctx.lineTo(tx + Math.cos(a + 1.6) * 1.6, ty + Math.sin(a + 1.6) * 1.6); ctx.lineTo(tx + Math.cos(a - 1.6) * 1.6, ty + Math.sin(a - 1.6) * 1.6); ctx.closePath(); ctx.fill();
      line(ctx, x + 1, y - 13, x + 5, y - 11 + (strike ? -1 : -3), 1.4 + grow * 2, col(L.skin));
    } else if (role === 'archer') {
      var bxx = x + 5.2, draw = strike ? 3.2 : 0.4;
      ctx.strokeStyle = col('#5a3b1c'); ctx.lineWidth = 1.3 + grow * 2; ctx.beginPath(); ctx.arc(bxx - 3.2, y - 12, 6.2, -1.05, 1.05); ctx.stroke();
      if (!o) { line(ctx, bxx - 3.2 + Math.cos(-1.05) * 6.2, y - 12 + Math.sin(-1.05) * 6.2, bxx - draw - 2.6, y - 12, 0.5, '#e8e0cc'); line(ctx, bxx - draw - 2.6, y - 12, bxx - 3.2 + Math.cos(1.05) * 6.2, y - 12 + Math.sin(1.05) * 6.2, 0.5, '#e8e0cc'); }
      if (strike && !o) line(ctx, bxx - draw - 2.6, y - 12, bxx + 4, y - 12, 0.9, '#d8c8a0');
      line(ctx, x + 1.5, y - 13, bxx + 0.2, y - 12, 1.3 + grow * 2, col(L.skin));
      // quiver
      ctx.fillStyle = col('#6a4526'); ctx.fillRect(x - 4.8 - grow, y - 15 - grow, 2.2 + grow * 2, 6 + grow * 2);
    } else if (role === 'mage') {
      var sx = x + 4.5, top = strike ? y - 27 : y - 23;
      line(ctx, sx, y + 0.5, sx + (strike ? 1.5 : 0), top, 1.2 + grow * 2, col('#4a3220'));
      line(ctx, x + 1.5, y - 13, sx, y - 14 + (strike ? -4 : 0), 1.3 + grow * 2, col(L.skin));
      if (!o) { var g = ctx.createRadialGradient(sx + (strike ? 1.5 : 0), top, 0, sx + (strike ? 1.5 : 0), top, strike ? 6 : 3.5); g.addColorStop(0, '#fffbe8'); g.addColorStop(0.4, strike ? '#ffd76a' : '#9fd8ff'); g.addColorStop(1, 'rgba(120,200,255,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(sx + (strike ? 1.5 : 0), top, strike ? 6 : 3.5, 0, Math.PI * 2); ctx.fill(); }
    }
  }

  /** A mounted figure (horse and rider), feet of the horse at (x, y). */
  function rider(ctx, x, y, L, frame, pass) {
    var o = pass === 0, ink = '#16100b', grow = o ? 1.1 : 0, col = function (c) { return o ? ink : c; };
    var gait = frame === 1 ? 1 : 0, strike = frame === 2;
    var hide = '#6b4428', hideD = '#4a2e1a';
    // legs
    var lx = [-7, -4.5, 5, 7.5];
    for (var k = 0; k < 4; k++) { var sw = (k % 2 ? 1 : -1) * (gait ? 2.2 : 0.4); line(ctx, x + lx[k], y - 7, x + lx[k] + sw, y - 0.3, 1.6 + grow * 2, col(k < 2 ? hideD : hide)); }
    // body
    ctx.fillStyle = col(hide); ctx.beginPath(); ctx.ellipse(x, y - 9, 9.5 + grow, 4.2 + grow, 0, 0, Math.PI * 2); ctx.fill();
    // neck and head
    ctx.beginPath(); ctx.moveTo(x + 6 - grow, y - 11); ctx.lineTo(x + 10 + grow, y - 17 - grow); ctx.lineTo(x + 14 + grow, y - 15 + grow); ctx.lineTo(x + 12.5 + grow, y - 13 + grow); ctx.lineTo(x + 9 + grow, y - 8 + grow); ctx.closePath(); ctx.fill();
    // tail
    line(ctx, x - 9, y - 10, x - 12.5, y - 5 + gait, 1.6 + grow * 2, col('#2a1a10'));
    if (!o) {
      ctx.fillStyle = L.main; ctx.beginPath(); ctx.moveTo(x - 6, y - 12.5); ctx.lineTo(x + 5, y - 12.5); ctx.lineTo(x + 6, y - 6); ctx.lineTo(x - 7, y - 6); ctx.closePath(); ctx.fill();   // caparison
      ctx.fillStyle = L.trim; ctx.fillRect(x - 7, y - 6.8, 13, 1);
      dot(ctx, x + 12.6, y - 15.4, 0.6, '#140c08');
    }
    // rider
    ctx.fillStyle = col(L.main); ctx.beginPath(); ctx.moveTo(x - 2.6 - grow, y - 21 - grow); ctx.lineTo(x + 2.6 + grow, y - 21 - grow); ctx.lineTo(x + 3 + grow, y - 12); ctx.lineTo(x - 3 - grow, y - 12); ctx.closePath(); ctx.fill();
    dot(ctx, x + 0.3, y - 23.6, 2.5 + grow, col(L.skin));
    ctx.fillStyle = col(L.metal); ctx.beginPath(); ctx.arc(x + 0.3, y - 24.3, 2.9 + grow, Math.PI, 0); ctx.closePath(); ctx.fill();
    if (!o) { line(ctx, x - 1, y - 27, x - 3.5, y - 30, 1.4, L.trim); }                                // plume
    // lance
    var la = strike ? 0.02 : -0.55, lb = { x: x - 4, y: y - 17 };
    line(ctx, lb.x, lb.y, lb.x + Math.cos(la) * 26, lb.y + Math.sin(la) * 26, 1.3 + grow * 2, col('#7a5a36'));
    if (!o) { var tx = lb.x + Math.cos(la) * 26, ty = lb.y + Math.sin(la) * 26; ctx.fillStyle = '#e4e8ee'; ctx.beginPath(); ctx.moveTo(tx + Math.cos(la) * 4, ty + Math.sin(la) * 4); ctx.lineTo(tx + Math.cos(la + 1.6) * 1.4, ty + Math.sin(la + 1.6) * 1.4); ctx.lineTo(tx + Math.cos(la - 1.6) * 1.4, ty + Math.sin(la - 1.6) * 1.4); ctx.closePath(); ctx.fill(); ctx.fillStyle = L.trim; ctx.fillRect(tx - 5, ty - 1.5, 3, 3); }
  }

  /**
   * Draw one atlas cell. frame 3 (fallen) lays the standing drawing on its side, darker.
   * @param {CanvasRenderingContext2D} ctx
   */
  function drawCell(ctx, ox, oy, role, L, frame) {
    var x = ox + CELL.cx, y = oy + CELL.foot;
    ctx.save();
    ctx.beginPath(); ctx.rect(ox, oy, CELL.w, CELL.h); ctx.clip();
    if (frame === 3) {
      // a body on the ground: rotated a quarter turn about the feet, a shadow under it
      ctx.fillStyle = 'rgba(20,14,8,0.28)'; ctx.beginPath(); ctx.ellipse(x, y - 1.5, role === 'horse' ? 14 : 10, 2.6, 0, 0, Math.PI * 2); ctx.fill();
      // rotate a quarter turn clockwise about the feet: the head ends up to the RIGHT, the whole body inside the cell
      if (role === 'horse') { ctx.translate(x, y); ctx.scale(1, 0.62); ctx.translate(-x, -y + 4); }
      else { ctx.translate(x - 9, y - 3); ctx.rotate(Math.PI / 2); ctx.translate(-x, -y); }
    } else {
      ctx.fillStyle = 'rgba(20,14,8,0.30)'; ctx.beginPath(); ctx.ellipse(x, y, role === 'horse' ? 11 : 5.5, 1.8, 0, 0, Math.PI * 2); ctx.fill();
    }
    for (var pass = 0; pass < 2; pass++) { if (role === 'horse') rider(ctx, x, y, L, frame, pass); else figure(ctx, x, y, role, L, frame, pass); }
    if (frame === 3) { ctx.globalCompositeOperation = 'source-atop'; ctx.fillStyle = 'rgba(30,22,14,0.35)'; ctx.fillRect(ox, oy, CELL.w, CELL.h); ctx.globalCompositeOperation = 'source-over'; }
    ctx.restore();
  }
  /** The whole atlas: rows = side * 5 + role, columns = frames. Returns the atlas size. */
  function atlasSize(roleIds) { return { w: CELL.w * FRAMES.length, h: CELL.h * roleIds.length * 2 }; }
  function drawAtlas(ctx, roleIds, liveries) {
    for (var s = 0; s < 2; s++) for (var r = 0; r < roleIds.length; r++) for (var f = 0; f < FRAMES.length; f++) drawCell(ctx, f * CELL.w, (s * roleIds.length + r) * CELL.h, roleIds[r], liveries[s], f);
  }

  /* ------------------------------------------------------------------ banners */
  function flagPath(ctx, shape, x, y, w, h) {
    ctx.beginPath();
    if (shape === 'swallowtail') { ctx.moveTo(x, y); ctx.lineTo(x + w, y); ctx.lineTo(x + w * 0.72, y + h / 2); ctx.lineTo(x + w, y + h); ctx.lineTo(x, y + h); }
    else if (shape === 'pennon') { ctx.moveTo(x, y); ctx.lineTo(x + w, y + h * 0.5); ctx.lineTo(x, y + h); }
    else if (shape === 'gonfalon') { ctx.moveTo(x, y); ctx.lineTo(x + w, y); ctx.lineTo(x + w, y + h * 0.72); ctx.lineTo(x + w * 0.83, y + h); ctx.lineTo(x + w * 0.67, y + h * 0.78); ctx.lineTo(x + w * 0.5, y + h); ctx.lineTo(x + w * 0.33, y + h * 0.78); ctx.lineTo(x + w * 0.17, y + h); ctx.lineTo(x, y + h * 0.72); }
    else { ctx.rect(x, y, w, h); }
    ctx.closePath();
  }
  function ordinary(ctx, o, x, y, w, h, c) {
    ctx.fillStyle = c; ctx.strokeStyle = c;
    var cx = x + w / 2, cy = y + h / 2, t = Math.min(w, h);
    switch (o) {
      case 'pale': ctx.fillRect(cx - w * 0.16, y, w * 0.32, h); break;
      case 'fess': ctx.fillRect(x, cy - h * 0.16, w, h * 0.32); break;
      case 'bend': ctx.lineWidth = t * 0.28; ctx.beginPath(); ctx.moveTo(x - 4, y - 4); ctx.lineTo(x + w + 4, y + h + 4); ctx.stroke(); break;
      case 'bendsinister': ctx.lineWidth = t * 0.28; ctx.beginPath(); ctx.moveTo(x + w + 4, y - 4); ctx.lineTo(x - 4, y + h + 4); ctx.stroke(); break;
      case 'chevron': ctx.lineWidth = t * 0.22; ctx.beginPath(); ctx.moveTo(x - 2, y + h * 0.95); ctx.lineTo(cx, y + h * 0.3); ctx.lineTo(x + w + 2, y + h * 0.95); ctx.stroke(); break;
      case 'cross': ctx.fillRect(cx - w * 0.1, y, w * 0.2, h); ctx.fillRect(x, cy - h * 0.1, w, h * 0.2); break;
      case 'saltire': ctx.lineWidth = t * 0.2; ctx.beginPath(); ctx.moveTo(x - 3, y - 3); ctx.lineTo(x + w + 3, y + h + 3); ctx.moveTo(x + w + 3, y - 3); ctx.lineTo(x - 3, y + h + 3); ctx.stroke(); break;
      case 'perpale': ctx.fillRect(cx, y, w / 2 + 2, h); break;
      case 'perfess': ctx.fillRect(x, cy, w, h / 2 + 2); break;
      case 'quarterly': ctx.fillRect(cx, y, w / 2 + 2, h / 2); ctx.fillRect(x, cy, w / 2, h / 2 + 2); break;
      case 'chief': ctx.fillRect(x, y, w, h * 0.3); break;
      case 'bordure': ctx.lineWidth = t * 0.18; ctx.strokeRect(x + t * 0.09, y + t * 0.09, w - t * 0.18, h - t * 0.18); break;
      case 'pile': ctx.beginPath(); ctx.moveTo(x + w * 0.18, y); ctx.lineTo(x + w * 0.82, y); ctx.lineTo(cx, y + h * 0.9); ctx.closePath(); ctx.fill(); break;
      case 'barry': for (var k = 1; k < 6; k += 2) ctx.fillRect(x, y + h * k / 6, w, h / 6); break;
      case 'paly': for (var q = 1; q < 6; q += 2) ctx.fillRect(x + w * q / 6, y, w / 6, h); break;
      default: break;
    }
  }
  function star(ctx, cx, cy, r, pts, inner) { ctx.beginPath(); for (var i = 0; i < pts * 2; i++) { var a = -Math.PI / 2 + i * Math.PI / pts, rr0 = i % 2 ? r * inner : r; ctx.lineTo(cx + Math.cos(a) * rr0, cy + Math.sin(a) * rr0); } ctx.closePath(); ctx.fill(); }
  function charge(ctx, c, cx, cy, r, col, field) {
    ctx.fillStyle = col; ctx.strokeStyle = col; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    switch (c) {
      case 'star': star(ctx, cx, cy, r, 5, 0.42); break;
      case 'sun': star(ctx, cx, cy, r, 12, 0.62); ctx.fillStyle = field; ctx.beginPath(); ctx.arc(cx, cy, r * 0.34, 0, Math.PI * 2); ctx.fill(); break;
      case 'crescent': ctx.beginPath(); ctx.arc(cx, cy, r * 0.85, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = field; ctx.beginPath(); ctx.arc(cx, cy - r * 0.32, r * 0.7, 0, Math.PI * 2); ctx.fill(); break;
      case 'annulet': ctx.lineWidth = r * 0.36; ctx.beginPath(); ctx.arc(cx, cy, r * 0.62, 0, Math.PI * 2); ctx.stroke(); break;
      case 'lozenge': ctx.beginPath(); ctx.moveTo(cx, cy - r); ctx.lineTo(cx + r * 0.62, cy); ctx.lineTo(cx, cy + r); ctx.lineTo(cx - r * 0.62, cy); ctx.closePath(); ctx.fill(); break;
      case 'roundel': ctx.beginPath(); ctx.arc(cx, cy, r * 0.7, 0, Math.PI * 2); ctx.fill(); break;
      case 'crosslet': var t = r * 0.26; ctx.fillRect(cx - t, cy - r, t * 2, r * 2); ctx.fillRect(cx - r * 0.75, cy - r * 0.35 - t, r * 1.5, t * 2); break;
      case 'tower': ctx.fillRect(cx - r * 0.55, cy - r * 0.5, r * 1.1, r * 1.4); for (var m = 0; m < 3; m++) ctx.fillRect(cx - r * 0.55 + m * r * 0.42, cy - r * 0.85, r * 0.26, r * 0.4); ctx.fillStyle = field; ctx.fillRect(cx - r * 0.16, cy + r * 0.35, r * 0.32, r * 0.55); break;
      case 'sword': ctx.lineWidth = r * 0.22; ctx.beginPath(); ctx.moveTo(cx, cy - r); ctx.lineTo(cx, cy + r * 0.55); ctx.stroke(); ctx.lineWidth = r * 0.2; ctx.beginPath(); ctx.moveTo(cx - r * 0.5, cy + r * 0.45); ctx.lineTo(cx + r * 0.5, cy + r * 0.45); ctx.stroke(); ctx.beginPath(); ctx.arc(cx, cy + r * 0.85, r * 0.16, 0, Math.PI * 2); ctx.fill(); break;
      case 'key': ctx.lineWidth = r * 0.22; ctx.beginPath(); ctx.arc(cx, cy - r * 0.55, r * 0.34, 0, Math.PI * 2); ctx.stroke(); ctx.beginPath(); ctx.moveTo(cx, cy - r * 0.2); ctx.lineTo(cx, cy + r); ctx.moveTo(cx, cy + r * 0.6); ctx.lineTo(cx + r * 0.4, cy + r * 0.6); ctx.moveTo(cx, cy + r * 0.9); ctx.lineTo(cx + r * 0.32, cy + r * 0.9); ctx.stroke(); break;
      case 'bird': ctx.beginPath(); ctx.moveTo(cx - r, cy - r * 0.2); ctx.quadraticCurveTo(cx - r * 0.4, cy - r * 0.9, cx, cy - r * 0.1); ctx.quadraticCurveTo(cx + r * 0.4, cy - r * 0.9, cx + r, cy - r * 0.2); ctx.quadraticCurveTo(cx + r * 0.3, cy - r * 0.1, cx + r * 0.2, cy + r * 0.3); ctx.lineTo(cx, cy + r * 0.9); ctx.lineTo(cx - r * 0.2, cy + r * 0.3); ctx.quadraticCurveTo(cx - r * 0.3, cy - r * 0.1, cx - r, cy - r * 0.2); ctx.closePath(); ctx.fill(); break;
      case 'fleur': ctx.beginPath(); ctx.moveTo(cx, cy - r); ctx.quadraticCurveTo(cx + r * 0.42, cy - r * 0.3, cx, cy + r * 0.2); ctx.quadraticCurveTo(cx - r * 0.42, cy - r * 0.3, cx, cy - r); ctx.fill(); ctx.beginPath(); ctx.moveTo(cx - r * 0.1, cy + r * 0.05); ctx.quadraticCurveTo(cx - r * 1.05, cy - r * 0.55, cx - r * 0.75, cy + r * 0.25); ctx.quadraticCurveTo(cx - r * 0.45, cy + r * 0.3, cx - r * 0.1, cy + r * 0.3); ctx.fill(); ctx.beginPath(); ctx.moveTo(cx + r * 0.1, cy + r * 0.05); ctx.quadraticCurveTo(cx + r * 1.05, cy - r * 0.55, cx + r * 0.75, cy + r * 0.25); ctx.quadraticCurveTo(cx + r * 0.45, cy + r * 0.3, cx + r * 0.1, cy + r * 0.3); ctx.fill(); ctx.fillRect(cx - r * 0.55, cy + r * 0.3, r * 1.1, r * 0.2); ctx.beginPath(); ctx.moveTo(cx - r * 0.2, cy + r * 0.5); ctx.lineTo(cx + r * 0.2, cy + r * 0.5); ctx.lineTo(cx, cy + r); ctx.closePath(); ctx.fill(); break;
      case 'axe': ctx.lineWidth = r * 0.18; ctx.beginPath(); ctx.moveTo(cx - r * 0.2, cy + r); ctx.lineTo(cx - r * 0.2, cy - r * 0.9); ctx.stroke(); ctx.beginPath(); ctx.moveTo(cx - r * 0.2, cy - r * 0.8); ctx.quadraticCurveTo(cx + r * 0.95, cy - r, cx + r * 0.75, cy - r * 0.1); ctx.quadraticCurveTo(cx + r * 0.4, cy - r * 0.35, cx - r * 0.2, cy - r * 0.2); ctx.closePath(); ctx.fill(); break;
      default: break;
    }
  }
  /**
   * A banner on its staff: the staff runs down the left, the cloth to the right. (x, y) = the staff top.
   * @param {object} arms from WarhostCore.heraldry
   */
  function drawBanner(ctx, x, y, w, h, arms, staffLen) {
    var fx = x + 2, fy = y + 3;
    // staff and finial
    line(ctx, x, y, x, y + (staffLen || h + 26), 2.2, '#3a2616'); line(ctx, x + 0.6, y, x + 0.6, y + (staffLen || h + 26), 0.8, '#7a5a38');
    ctx.fillStyle = '#d6b050'; ctx.beginPath(); ctx.moveTo(x, y - 6); ctx.lineTo(x + 2.6, y - 1); ctx.lineTo(x - 2.6, y - 1); ctx.closePath(); ctx.fill();
    ctx.save();
    flagPath(ctx, arms.shape, fx, fy, w, h); ctx.fillStyle = arms.field; ctx.fill(); ctx.clip();
    ordinary(ctx, arms.ordinary, fx, fy, w, h, arms.other);
    if (arms.charge !== 'none') { var r = Math.min(w, h) * 0.3, cx = fx + w * (arms.shape === 'pennon' ? 0.36 : 0.46), cy = fy + h * 0.5; if (arms.ordinary === 'chief') cy = fy + h * 0.6; charge(ctx, arms.charge, cx, cy, r, arms.charge2, arms.field); }
    // cloth shading: folds as soft vertical bands
    for (var k = 0; k < 4; k++) { var gx = fx + w * (0.12 + k * 0.25), g = ctx.createLinearGradient(gx - w * 0.12, 0, gx + w * 0.12, 0); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(0.5, k % 2 ? 'rgba(255,255,255,0.10)' : 'rgba(0,0,0,0.16)'); g.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = g; ctx.fillRect(gx - w * 0.12, fy, w * 0.24, h); }
    ctx.restore();
    flagPath(ctx, arms.shape, fx, fy, w, h); ctx.strokeStyle = 'rgba(20,12,6,0.85)'; ctx.lineWidth = 1.2; ctx.stroke();
  }

  /* ------------------------------------------------------------------ battlefields */
  var TERRAINS = {
    meadow: { sky: ['#8fb6d8', '#d9e6e8'], hills: ['#6f8f7a', '#577a60', '#3f6547'], ground: ['#6f9448', '#557a36'], patch: ['#84a854', '#4d7032', '#9aae5a'], tuft: '#3d5e27', stone: '#8a8a7a', flower: ['#e8d24a', '#f0f0e0', '#c85a8a'], road: '#9b8a62', label: 'meadow' },
    steppe: { sky: ['#b9c4c8', '#efe2c4'], hills: ['#a08f72', '#8a7658', '#6f5e44'], ground: ['#b39a5e', '#98804a'], patch: ['#c2a868', '#8e7644', '#a8925a'], tuft: '#7a6636', stone: '#8e8474', flower: ['#d8c070', '#e8dcc0', '#b07040'], road: '#c8b488', label: 'steppe' },
    snow: { sky: ['#9aa8b8', '#dde3ea'], hills: ['#b8c2cc', '#9aa6b2', '#7e8a98'], ground: ['#e6ebef', '#c9d2da'], patch: ['#f4f7f9', '#bcc6d0', '#d8e0e6'], tuft: '#8a9098', stone: '#6e747c', flower: ['#ffffff', '#d0dae4', '#b8c4d0'], road: '#b4b0a8', label: 'snow' },
    desert: { sky: ['#9cc2dc', '#f6e2bc'], hills: ['#d6ae78', '#c49660', '#a87c4c'], ground: ['#e0bf86', '#cfa66c'], patch: ['#ecd09a', '#c69a60', '#d8b47a'], tuft: '#9a7c46', stone: '#a08868', flower: ['#f0e0b0', '#d8a060', '#b88850'], road: '#c8a878', label: 'desert' },
    moor: { sky: ['#7a8490', '#c4c0b4'], hills: ['#5e5a62', '#4c4852', '#3a3640'], ground: ['#6a6448', '#56503a'], patch: ['#7a6e4a', '#4a4632', '#806a5a'], tuft: '#3a3624', stone: '#7a7874', flower: ['#8a5a8a', '#b07aa0', '#d8d0b0'], road: '#8a7e62', label: 'moor' }
  };
  var TERRAIN_IDS = Object.keys(TERRAINS);
  /**
   * The battlefield: sky, three ranges of hills with a keep on one of them, a patched and tufted field, a road. Everything
   * is placed by a seeded hash, so one seed is one field and two seeds are two fields.
   */
  function drawField(ctx, W, H, terrain, seed, top) {
    var T = TERRAINS[terrain] || TERRAINS.meadow, s = (seed >>> 0) % 100000, HZ = top || 190, x, y, k;
    var g = ctx.createLinearGradient(0, 0, 0, HZ); g.addColorStop(0, T.sky[0]); g.addColorStop(1, T.sky[1]); ctx.fillStyle = g; ctx.fillRect(0, 0, W, HZ + 2);
    // clouds
    for (k = 0; k < 7; k++) { var cx = hash2(k, 1, s) * W, cy = 20 + hash2(k, 2, s) * (HZ * 0.45), cw = 60 + hash2(k, 3, s) * 110; ctx.fillStyle = 'rgba(255,255,255,' + (0.18 + hash2(k, 4, s) * 0.2).toFixed(2) + ')'; for (var q = 0; q < 5; q++) { ctx.beginPath(); ctx.ellipse(cx + (q - 2) * cw * 0.2, cy + Math.sin(q * 1.7) * 4, cw * 0.28, 7 + hash2(k, q, s) * 6, 0, 0, Math.PI * 2); ctx.fill(); } }
    // hills: three ranges, far to near; the nearest fades into the field's own colour so no seam line shows at the horizon
    for (var r = 0; r < 3; r++) {
      var base = HZ - 58 + r * 22, amp = 34 - r * 8, fq = 0.004 + r * 0.003;
      var hg = ctx.createLinearGradient(0, base - amp, 0, HZ + 6); hg.addColorStop(0, T.hills[r]); hg.addColorStop(1, r === 2 ? shade(T.ground[0], 0.08) : T.hills[r]);
      ctx.fillStyle = hg; ctx.beginPath(); ctx.moveTo(0, HZ + 6);
      for (x = 0; x <= W; x += 6) ctx.lineTo(x, base - fbm(x * fq, r * 3.3, s + r * 17) * amp * 1.6 + amp * 0.3);
      ctx.lineTo(W, HZ + 6); ctx.closePath(); ctx.fill();
      if (r === 2) {   // a tree line along the near range
        for (k = 0; k < 46; k++) { var tx0 = hash2(k, 21, s) * W, ty0 = base - fbm(tx0 * fq, r * 3.3, s + r * 17) * amp * 1.6 + amp * 0.3 + 4; if (hash2(k, 22, s) < 0.35) continue; ctx.fillStyle = shade(T.hills[2], -0.18 - hash2(k, 23, s) * 0.15); ctx.beginPath(); ctx.ellipse(tx0, ty0 - 4, 4 + hash2(k, 24, s) * 5, 5 + hash2(k, 25, s) * 5, 0, 0, Math.PI * 2); ctx.fill(); }
      }
      if (r === 1) {   // a keep on the middle range
        var kx = 90 + hash2(9, 9, s) * (W - 180), ky = base - fbm(kx * fq, r * 3.3, s + r * 17) * amp * 1.6 + amp * 0.3;
        ctx.fillStyle = shade(T.hills[2], -0.25); ctx.fillRect(kx - 10, ky - 20, 20, 22); ctx.fillRect(kx - 16, ky - 12, 6, 14); ctx.fillRect(kx + 10, ky - 12, 6, 14);
        for (k = 0; k < 4; k++) ctx.fillRect(kx - 10 + k * 6, ky - 24, 3.5, 4);
        line(ctx, kx, ky - 24, kx, ky - 34, 1, shade(T.hills[2], -0.35)); ctx.fillStyle = '#a8322a'; ctx.beginPath(); ctx.moveTo(kx, ky - 34); ctx.lineTo(kx + 8, ky - 31); ctx.lineTo(kx, ky - 28); ctx.closePath(); ctx.fill();
      }
    }
    // ground (starts under the near range, so the range's own gradient carries the seam)
    g = ctx.createLinearGradient(0, HZ, 0, H); g.addColorStop(0, shade(T.ground[0], 0.08)); g.addColorStop(1, T.ground[1]); ctx.fillStyle = g; ctx.fillRect(0, HZ + 5, W, H - HZ - 5);
    // broad light: sunlit swathes and cloud shadows, the large-scale value that makes a field read as land
    for (k = 0; k < 9; k++) { var sx0 = hash2(k, 31, s) * W, sy0 = HZ + 30 + hash2(k, 32, s) * (H - HZ - 30), sr = 90 + hash2(k, 33, s) * 170, lit = k % 3 !== 0; var rg = ctx.createRadialGradient(sx0, sy0, 0, sx0, sy0, sr); rg.addColorStop(0, lit ? 'rgba(255,248,210,0.16)' : 'rgba(20,24,10,0.20)'); rg.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = rg; ctx.save(); ctx.translate(sx0, sy0); ctx.scale(1.8, 0.55); ctx.translate(-sx0, -sy0); ctx.fillRect(sx0 - sr, sy0 - sr, sr * 2, sr * 2); ctx.restore(); }
    // patches (noise-shaped blotches, flattened by the distance)
    for (y = HZ + 4; y < H; y += 3) for (x = 0; x < W; x += 3) {
      var n = fbm(x * 0.010, y * 0.026, s + 101);
      if (n > 0.58) { ctx.fillStyle = T.patch[0]; ctx.globalAlpha = Math.min(0.7, (n - 0.58) * 2.8); ctx.fillRect(x, y, 3, 3); }
      else if (n < 0.38) { ctx.fillStyle = T.patch[1]; ctx.globalAlpha = Math.min(0.62, (0.38 - n) * 2.8); ctx.fillRect(x, y, 3, 3); }
      else if (n > 0.49 && n < 0.51) { ctx.fillStyle = T.patch[2]; ctx.globalAlpha = 0.35; ctx.fillRect(x, y, 3, 3); }
    }
    ctx.globalAlpha = 1;
    // a cart track ACROSS the field, near the viewer, curving once (it must not split the two armies down the middle)
    var ty1 = H - 70 - hash2(3, 3, s) * 50, ty2 = H - 40 - hash2(4, 4, s) * 60, bend = HZ + (H - HZ) * (0.55 + hash2(5, 5, s) * 0.2);
    ctx.lineCap = 'round';
    for (var tr = 0; tr < 2; tr++) { ctx.strokeStyle = tr ? shade(T.road, -0.25) : T.road; ctx.globalAlpha = tr ? 0.35 : 0.42; ctx.lineWidth = tr ? 3 : 14; ctx.beginPath(); ctx.moveTo(-10, ty1 + tr * 4); ctx.quadraticCurveTo(W * 0.5, bend + (ty1 + ty2) * 0.25 - (H - HZ) * 0.1 + tr * 4, W + 10, ty2 + tr * 4); ctx.stroke(); }
    ctx.globalAlpha = 1; ctx.lineCap = 'butt';
    // bushes in the near corners and along the edges
    for (k = 0; k < 16; k++) { var bxs = (k % 2 ? W - 40 : 40) + (hash2(k, 41, s) - 0.5) * 90, bys = HZ + 60 + hash2(k, 42, s) * (H - HZ - 60), br = 5 + hash2(k, 43, s) * 9 * ((bys - HZ) / (H - HZ) + 0.4); ctx.fillStyle = 'rgba(20,14,8,0.25)'; ctx.beginPath(); ctx.ellipse(bxs + 2, bys + br * 0.5, br * 1.2, br * 0.4, 0, 0, Math.PI * 2); ctx.fill(); for (var bq = 0; bq < 4; bq++) { ctx.fillStyle = shade(T.tuft, bq === 3 ? 0.18 : -0.05 * bq); ctx.beginPath(); ctx.arc(bxs + (bq - 1.5) * br * 0.45, bys - bq % 2 * br * 0.3, br * (0.7 - bq * 0.06), 0, Math.PI * 2); ctx.fill(); } }
    // tufts in small clusters, stones, flowers: denser and larger near the viewer
    for (k = 0; k < 260; k++) {
      var py = HZ + 8 + Math.pow(hash2(k, 11, s), 0.75) * (H - HZ - 8), px = hash2(k, 12, s) * W, depth = (py - HZ) / (H - HZ), kind = hash2(k, 13, s);
      if (kind < 0.7) { ctx.strokeStyle = T.tuft; ctx.lineWidth = 0.7 + depth * 0.7; for (var c2 = 0; c2 < 3; c2++) { var cxx = px + (hash2(k, 50 + c2, s) - 0.5) * 10 * (0.5 + depth), hh = 2 + depth * 5 * (0.6 + hash2(k, 60 + c2, s) * 0.6); ctx.beginPath(); ctx.moveTo(cxx, py); ctx.lineTo(cxx - 1.6, py - hh); ctx.moveTo(cxx, py); ctx.lineTo(cxx + 0.3, py - hh * 1.2); ctx.moveTo(cxx, py); ctx.lineTo(cxx + 1.8, py - hh * 0.9); ctx.stroke(); } }
      else if (kind < 0.85) { ctx.fillStyle = T.stone; ctx.beginPath(); ctx.ellipse(px, py, 1.2 + depth * 3, 0.8 + depth * 1.8, 0, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.28)'; ctx.fillRect(px - 0.8, py - 1.2, 1.2 + depth * 1.5, 0.9); }
      else { for (var fl = 0; fl < 5; fl++) { ctx.fillStyle = T.flower[Math.floor(hash2(k, 70 + fl, s) * T.flower.length)]; ctx.fillRect(px + (hash2(k, 80 + fl, s) - 0.5) * 12, py + (hash2(k, 90 + fl, s) - 0.5) * 5, 1 + depth * 1.2, 1 + depth * 1.2); } }
    }
    // vignette
    g = ctx.createRadialGradient(W / 2, H * 0.6, H * 0.3, W / 2, H * 0.6, H * 0.95); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(10,6,2,0.38)'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  }

  /* ------------------------------------------------------------------ fx textures */
  function drawArrow(ctx) { line(ctx, 1, 2, 11, 2, 1, '#3a2a1a'); ctx.fillStyle = '#d8d8d0'; ctx.beginPath(); ctx.moveTo(13, 2); ctx.lineTo(10, 0.4); ctx.lineTo(10, 3.6); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#e8e0d0'; ctx.fillRect(0, 0.6, 3, 1); ctx.fillRect(0, 2.4, 3, 1); }
  function drawPuff(ctx, w) { var g = ctx.createRadialGradient(w / 2, w / 2, 0, w / 2, w / 2, w / 2); g.addColorStop(0, 'rgba(214,196,160,0.75)'); g.addColorStop(0.6, 'rgba(190,172,140,0.35)'); g.addColorStop(1, 'rgba(180,160,130,0)'); ctx.fillStyle = g; ctx.fillRect(0, 0, w, w); }
  function drawBurst(ctx, w) { var c = w / 2, g = ctx.createRadialGradient(c, c, 0, c, c, c); g.addColorStop(0, 'rgba(255,255,240,1)'); g.addColorStop(0.25, 'rgba(255,220,120,0.9)'); g.addColorStop(0.55, 'rgba(255,140,60,0.45)'); g.addColorStop(1, 'rgba(255,90,30,0)'); ctx.fillStyle = g; ctx.fillRect(0, 0, w, w); ctx.strokeStyle = 'rgba(255,240,200,0.8)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(c, c, c * 0.7, 0, Math.PI * 2); ctx.stroke(); }
  function drawSpark(ctx, w) { ctx.fillStyle = '#fff6d8'; star(ctx, w / 2, w / 2, w / 2, 4, 0.28); }

  /* ------------------------------------------------------------------ plates: hud, cards, title, record */
  function plate(ctx, x, y, w, h, tone) {
    var g = ctx.createLinearGradient(0, y, 0, y + h);
    if (tone === 'iron') { g.addColorStop(0, '#3a3430'); g.addColorStop(1, '#221e1b'); } else { g.addColorStop(0, '#f2e6c8'); g.addColorStop(1, '#dcc89c'); }
    rr(ctx, x, y, w, h, 6); ctx.fillStyle = g; ctx.fill();
    ctx.lineWidth = 2; ctx.strokeStyle = tone === 'iron' ? '#b08a48' : '#8a6a3a'; ctx.stroke();
    rr(ctx, x + 4, y + 4, w - 8, h - 8, 4); ctx.lineWidth = 0.8; ctx.strokeStyle = tone === 'iron' ? 'rgba(214,176,96,0.55)' : 'rgba(120,88,44,0.6)'; ctx.stroke();
    if (tone !== 'iron') { for (var k = 0; k < 40; k++) { ctx.fillStyle = 'rgba(120,90,50,' + (0.03 + hash2(k, 7, w) * 0.05).toFixed(3) + ')'; ctx.beginPath(); ctx.arc(x + hash2(k, 1, w) * w, y + hash2(k, 2, h) * h, 2 + hash2(k, 3, w) * 9, 0, Math.PI * 2); ctx.fill(); } }
  }
  /**
   * The strip across the top during the clash: each army's banner, name, and a bar of its strength split into fighting,
   * fled and fallen. info = {names:[a,b], arms:[a,b], count:[a,b], alive:[a,b], fled:[a,b], seconds, title}
   */
  function drawHud(ctx, W, H, info) {
    ctx.clearRect(0, 0, W, H);
    plate(ctx, 6, 4, W - 12, H - 8, 'iron');
    // left half: [banner] name ........ "n of m stand" / bar grows from the left. Right half mirrors it about the centre.
    var barW = W / 2 - 126;
    for (var s = 0; s < 2; s++) {
      var left = s === 0, x0 = left ? 70 : W / 2 + 56, x1 = x0 + barW;   // this half's text and bar run from x0 to x1
      if (info.arms[s]) { if (left) drawBanner(ctx, 22, 12, 30, 22, info.arms[s], 30); else drawBanner(ctx, W - 58, 12, 30, 22, info.arms[s], 30); }
      ctx.textBaseline = 'middle'; ctx.fillStyle = '#f1dfb4';
      var nameSize = fitText(ctx, info.names[s], barW * 0.55, 15, 'bold');
      ctx.textAlign = left ? 'left' : 'right'; ctx.fillText(info.names[s], left ? x0 : x1, 17);
      ctx.font = 'italic 12px ' + FACE; ctx.fillStyle = '#c9a86a'; ctx.textAlign = left ? 'right' : 'left';
      ctx.fillText(info.alive[s] + ' of ' + info.count[s] + ' stand', left ? x1 : x0, 17);
      // the bar: fighting | fled | fallen, each army's grows from its own outer edge
      var y = 30, h = 9, c = Math.max(1, info.count[s]), fa = info.alive[s] / c, ff = info.fled[s] / c;
      ctx.fillStyle = '#120e0b'; ctx.fillRect(x0 - 1, y - 1, barW + 2, h + 2);
      var gl = ctx.createLinearGradient(0, y, 0, y + h); gl.addColorStop(0, s ? '#e2574a' : '#5f8ee0'); gl.addColorStop(1, s ? '#8a1f18' : '#24488e'); ctx.fillStyle = gl;
      if (left) ctx.fillRect(x0, y, barW * fa, h); else ctx.fillRect(x1 - barW * fa, y, barW * fa, h);
      ctx.fillStyle = 'rgba(214,176,96,0.55)';
      if (left) ctx.fillRect(x0 + barW * fa, y, barW * ff, h); else ctx.fillRect(x1 - barW * (fa + ff), y, barW * ff, h);
      for (var t = 1; t < 10; t++) { ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fillRect(x0 + barW * t / 10, y, 1, h); }
      if (nameSize < 9) ctx.font = 'bold 9px ' + FACE;
    }
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#d6b050'; ctx.font = 'bold 18px ' + FACE; ctx.fillText('⚔', W / 2, 19);
    ctx.font = '11px ' + FACE; ctx.fillStyle = '#b8a07a'; ctx.fillText(info.seconds + ' s', W / 2, 36);
  }
  /** A formation drawn as a diagram of dots, pointing right. */
  function diagram(ctx, form, cx, cy, w, h, col) {
    ctx.fillStyle = col; var k, r, c;
    if (form === 'line') { for (c = 0; c < 3; c++) for (r = 0; r < 9; r++) dot(ctx, cx - 6 + c * -7 + 10, cy - 28 + r * 7, 2.1, col); }
    else if (form === 'wedge') { var row = 0, n = 0, width = 1; for (k = 0; k < 25; k++) { dot(ctx, cx + 16 - row * 7, cy + (n - (width - 1) / 2) * 7, 2.1, col); if (++n >= width) { row++; width += 2; n = 0; } } }
    else if (form === 'square') { for (c = 0; c < 5; c++) for (r = 0; r < 5; r++) dot(ctx, cx - 14 + c * 6, cy - 12 + r * 6, 2.1, col); ctx.strokeStyle = col; ctx.lineWidth = 1; ctx.strokeRect(cx - 19, cy - 17, 34, 34); }
    else { for (k = 0; k < 18; k++) dot(ctx, cx - 26 + hash2(k, 1, 5) * 52, cy - 26 + hash2(k, 2, 5) * 52, 2.1, col); }
  }
  /**
   * One formation card. state: 'idle' | 'hover' | 'chosen' | 'enemy' | 'off'.
   * @param {{label:string, motto:string, beats:string}} F
   */
  function drawCard(ctx, x, y, w, h, form, F, beatsLabel, state) {
    ctx.save();
    var lift = state === 'hover' || state === 'chosen' ? -6 : 0; y += lift;
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; rr(ctx, x + 3, y + 5 - lift, w, h, 6); ctx.fill();
    plate(ctx, x, y, w, h, 'parchment');
    if (state === 'chosen' || state === 'hover') { rr(ctx, x - 2, y - 2, w + 4, h + 4, 8); ctx.lineWidth = 3; ctx.strokeStyle = state === 'chosen' ? '#d6a53a' : 'rgba(214,165,58,0.7)'; ctx.stroke(); }
    diagram(ctx, form, x + w / 2, y + 44, w, h, state === 'enemy' ? '#8a2a20' : '#2a3f6a');
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = INK; ctx.font = 'bold 17px ' + FACE; ctx.fillText(F.label.toUpperCase(), x + w / 2, y + 90);
    ctx.fillStyle = '#6a4a2a'; fitText(ctx, 'beats ' + beatsLabel, w - 16, 12, 'italic'); ctx.fillText('beats ' + beatsLabel, x + w / 2, y + 108);
    ctx.fillStyle = '#4a3522'; ctx.font = '10px ' + FACE; wrap(ctx, F.motto, x + w / 2, y + 124, w - 18, 12);
    if (state === 'off') { rr(ctx, x, y, w, h, 6); ctx.fillStyle = 'rgba(40,30,20,0.45)'; ctx.fill(); }
    ctx.restore();
  }
  function wrap(ctx, text, cx, y, maxW, lh) { var words = String(text).split(' '), ln = ''; for (var i = 0; i < words.length; i++) { var t = ln ? ln + ' ' + words[i] : words[i]; if (ctx.measureText(t).width > maxW && ln) { ctx.fillText(ln, cx, y); y += lh; ln = words[i]; } else ln = t; } if (ln) ctx.fillText(ln, cx, y); return y; }
  /** The call to arms: the battle's title on a hanging board. */
  function drawTitle(ctx, W, H, title, sub) {
    ctx.clearRect(0, 0, W, H);
    var w = Math.min(W - 80, 520), h = 94, x = (W - w) / 2, y = 8;
    line(ctx, x + 40, 0, x + 40, y + 8, 2, '#3a2616'); line(ctx, x + w - 40, 0, x + w - 40, y + 8, 2, '#3a2616');
    plate(ctx, x, y, w, h, 'parchment');
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = INK; fitText(ctx, title, w - 60, 30, 'bold'); ctx.fillText(title, W / 2, y + 38);
    ctx.fillStyle = '#6a4a2a'; ctx.font = 'italic 14px ' + FACE; ctx.fillText(sub, W / 2, y + 70);
    ctx.fillStyle = '#8a6a3a'; ctx.fillRect(W / 2 - 110, y + 56, 220, 1);
  }
  /** A note on the field ("The enemy forms a wedge"). */
  function drawNote(ctx, W, H, text, tone) {
    ctx.clearRect(0, 0, W, H);
    ctx.font = 'bold 15px ' + FACE; var w = Math.min(W - 20, ctx.measureText(text).width + 60), x = (W - w) / 2;
    plate(ctx, x, 2, w, H - 4, tone || 'iron');
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = tone === 'parchment' ? INK : '#f1dfb4'; ctx.fillText(text, W / 2, H / 2);
  }
  /**
   * The war record: verdict, then every regiment of both armies with its banner and a bar of who stood, who fled and who
   * fell, then the totals. r = WarhostCore.result(); arms = per-regiment heraldry in r.regiments order.
   */
  function drawRecord(ctx, W, H, r, arms, info) {
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = 'rgba(12,8,4,0.55)'; ctx.fillRect(0, 0, W, H);
    var x = 40, y = 26, w = W - 80, h = H - 52;
    plate(ctx, x, y, w, h, 'parchment');
    var verdict = r.winner === 0 ? 'VICTORY' : r.winner === 1 ? 'DEFEAT' : 'THE FIELD IS HELD BY NEITHER';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = r.winner === 1 ? '#7a1f18' : INK;
    fitText(ctx, verdict, w - 80, 34, 'bold'); ctx.fillText(verdict, W / 2, y + 36);
    ctx.fillStyle = '#6a4a2a'; ctx.font = 'italic 14px ' + FACE; ctx.fillText(info.title + ' · ' + r.seconds + ' seconds · ' + info.formLabels[0] + ' against ' + info.formLabels[1], W / 2, y + 64);
    ctx.fillStyle = '#8a6a3a'; ctx.fillRect(x + 30, y + 80, w - 60, 1);
    var colW = (w - 60) / 2, most = Math.max(r.regiments.filter(function (g) { return g.side === 0; }).length, r.regiments.filter(function (g) { return g.side === 1; }).length, 1);
    var rowH = Math.max(22, Math.min(30, 250 / most)), listEnd = y + 110 + most * rowH;
    for (var s = 0; s < 2; s++) {
      var cx = x + 30 + s * (colW + 0), cy = y + 96;
      ctx.textAlign = 'left'; ctx.fillStyle = s ? '#7a1f18' : '#1f3f7a'; ctx.font = 'bold 14px ' + FACE; ctx.fillText(info.names[s], cx + 4, cy);
      cy += 14;
      var rows = r.regiments.filter(function (g) { return g.side === s; });
      rows.forEach(function (g) {
        var idx = r.regiments.indexOf(g);
        drawBanner(ctx, cx + 8, cy + 4, 20, 14, arms[idx], 20);
        ctx.fillStyle = INK; ctx.font = 'bold 12px ' + FACE; ctx.textAlign = 'left'; fitText(ctx, g.name, colW - 150, 12, 'bold'); ctx.fillText(g.name, cx + 34, cy + 9);
        ctx.font = 'italic 10px ' + FACE; ctx.fillStyle = '#6a4a2a'; ctx.fillText(g.role + (g.routed ? ' · routed' : ''), cx + 34, cy + 21);
        var bx = cx + colW - 120, bw = 100, bh = 8, by = cy + 8, c = Math.max(1, g.count);
        ctx.fillStyle = '#3a2a1a'; ctx.fillRect(bx - 1, by - 1, bw + 2, bh + 2);
        ctx.fillStyle = s ? '#b8453a' : '#3f6fc4'; ctx.fillRect(bx, by, bw * g.survived / c, bh);
        ctx.fillStyle = '#d6b050'; ctx.fillRect(bx + bw * g.survived / c, by, bw * g.fled / c, bh);
        ctx.fillStyle = '#5a4a3a'; ctx.fillRect(bx + bw * (g.survived + g.fled) / c, by, bw * g.dead / c, bh);
        ctx.textAlign = 'right'; ctx.font = '10px ' + FACE; ctx.fillStyle = INK; ctx.fillText(g.survived + ' / ' + g.count, bx + bw, cy + 23);
        cy += rowH;
      });
    }
    // totals
    var ty = y + h - 60;
    // the course of the battle: each army's standing strength over time, and where regiments broke
    if (info.history && info.history.n > 1) drawCourse(ctx, x + 40, listEnd + 14, w - 80, ty - 26 - (listEnd + 14), info.history, info.names);
    ctx.fillStyle = '#8a6a3a'; ctx.fillRect(x + 30, ty - 12, w - 60, 1);
    for (var t = 0; t < 2; t++) { var S = r.sides[t]; ctx.textAlign = t ? 'right' : 'left'; ctx.fillStyle = INK; ctx.font = 'bold 13px ' + FACE; ctx.fillText(S.survived + ' stand · ' + S.fled + ' fled · ' + S.dead + ' fell', t ? x + w - 34 : x + 34, ty + 6); }
    ctx.textAlign = 'center'; ctx.font = 'italic 11px ' + FACE; ctx.fillStyle = '#6a4a2a'; ctx.fillText('blue: stood · gold: fled the field · grey: fell', W / 2, ty + 28);
  }

  /**
   * THE COURSE OF THE BATTLE: two strength lines (share of each army still standing), sampled every half second, with a
   * marker wherever a regiment broke. hist = {n, dt, s0:Float32Array, s1:Float32Array, routs:[{t, side, name}]}
   */
  function drawCourse(ctx, x, y, w, h, hist, names) {
    if (h < 60) return;
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#6a4a2a'; ctx.font = 'bold 11px ' + FACE; ctx.fillText('THE COURSE OF THE BATTLE', x, y + 6);
    var gx = x, gy = y + 18, gw = w, gh = h - 34, n = hist.n, secs = (n - 1) * hist.dt, k;
    ctx.fillStyle = 'rgba(120,88,44,0.08)'; ctx.fillRect(gx, gy, gw, gh);
    ctx.strokeStyle = 'rgba(120,88,44,0.35)'; ctx.lineWidth = 1;
    for (k = 0; k <= 4; k++) { var yy = gy + gh * k / 4; ctx.beginPath(); ctx.moveTo(gx, yy + 0.5); ctx.lineTo(gx + gw, yy + 0.5); ctx.stroke(); }
    ctx.fillStyle = '#6a4a2a'; ctx.font = '9px ' + FACE; ctx.textAlign = 'right'; ctx.fillText('all', gx - 4, gy + 1); ctx.fillText('half', gx - 4, gy + gh / 2); ctx.fillText('none', gx - 4, gy + gh - 1);
    var step = secs > 40 ? 10 : 5; ctx.textAlign = 'center';
    for (var t = 0; t <= secs + 0.01; t += step) { var tx = gx + gw * t / Math.max(1, secs); ctx.fillText(t + 's', tx, gy + gh + 9); }
    var cols = ['#2f5aa8', '#b02a22'];
    for (var s = 0; s < 2; s++) {
      var arr = s ? hist.s1 : hist.s0, px = function (i) { return gx + gw * i / (n - 1); }, py = function (v) { return gy + gh * (1 - v); };
      ctx.beginPath(); ctx.moveTo(px(0), py(0)); for (k = 0; k < n; k++) ctx.lineTo(px(k), py(arr[k])); ctx.lineTo(px(n - 1), py(0)); ctx.closePath();
      ctx.fillStyle = s ? 'rgba(176,42,34,0.14)' : 'rgba(47,90,168,0.14)'; ctx.fill();
      ctx.beginPath(); for (k = 0; k < n; k++) { if (k) ctx.lineTo(px(k), py(arr[k])); else ctx.moveTo(px(k), py(arr[k])); } ctx.strokeStyle = cols[s]; ctx.lineWidth = 2.2; ctx.stroke();
      ctx.fillStyle = cols[s]; ctx.textAlign = s ? 'right' : 'left'; ctx.font = 'bold 10px ' + FACE; ctx.fillText(names[s], s ? gx + gw - 4 : gx + 4, gy + 9 + s * 12);
    }
    var labelled = 0;
    (hist.routs || []).forEach(function (rt) {
      var i = Math.min(n - 1, Math.round(rt.t / hist.dt)), arr = rt.side ? hist.s1 : hist.s0, mx = gx + gw * i / (n - 1), my = gy + gh * (1 - arr[i]);
      ctx.fillStyle = cols[rt.side]; ctx.beginPath(); ctx.moveTo(mx, my - 7); ctx.lineTo(mx + 4.5, my - 1); ctx.lineTo(mx - 4.5, my - 1); ctx.closePath(); ctx.fill();
      if (labelled < 5) { ctx.fillStyle = '#4a3522'; ctx.font = 'italic 9px ' + FACE; ctx.textAlign = 'center'; ctx.fillText(rt.name + ' broke', mx, my - 13 - (labelled % 2) * 10); labelled++; }
    });
  }

  var API = { VERSION: '1.0.0', FACE: FACE, drawCourse: drawCourse, CELL: CELL, FRAMES: FRAMES, LIVERIES: LIVERIES, TERRAINS: TERRAINS, TERRAIN_IDS: TERRAIN_IDS,
    livery: livery, drawCell: drawCell, atlasSize: atlasSize, drawAtlas: drawAtlas, drawBanner: drawBanner, drawField: drawField,
    drawArrow: drawArrow, drawPuff: drawPuff, drawBurst: drawBurst, drawSpark: drawSpark, drawHud: drawHud, drawCard: drawCard,
    drawTitle: drawTitle, drawNote: drawNote, drawRecord: drawRecord, plate: plate, hexRgb: hexRgb, mix: mix, shade: shade, noise: noise };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  return API;
})();
