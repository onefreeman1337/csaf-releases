//=============================================================================
// Warhost.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Warhost - army battles: regiments of drawn soldiers under
 * generated banners clash on a painted field. Formations, routs, a war record.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 * @base WarhostCore
 * @base WarhostDraw
 * @orderAfter WarhostDraw
 *
 * @param playerArmyName
 * @text Your army's name
 * @type text
 * @default Your Host
 *
 * @param playerColour
 * @text Your army's colour
 * @type text
 * @desc A #hex colour for your soldiers' tunics. Blank = royal blue.
 * @default
 *
 * @param enemyColour
 * @text Enemy colour
 * @type text
 * @desc A #hex colour for the enemy's tunics. Blank = crimson.
 * @default
 *
 * @param defaultTerrain
 * @text Default field
 * @type select
 * @option meadow
 * @option steppe
 * @option snow
 * @option desert
 * @option moor
 * @default meadow
 *
 * @param timeLimit
 * @text Time limit (seconds)
 * @type number
 * @min 10
 * @max 600
 * @desc When time runs out the stronger army holds the field (15% ahead), or neither does.
 * @default 60
 *
 * @param showEnemyFormation
 * @text Show the enemy's formation
 * @type boolean
 * @desc ON: the player sees how the enemy has formed before choosing. OFF: the enemy's order is hidden until the clash.
 * @default true
 *
 * @param seHorn
 * @text Sound: horn (start)
 * @type file
 * @dir audio/se
 * @default Horn
 *
 * @param seClash
 * @text Sound: clash of arms
 * @type file
 * @dir audio/se
 * @default Blow3
 *
 * @param seVolley
 * @text Sound: volley
 * @type file
 * @dir audio/se
 * @default Bow1
 *
 * @param seSpell
 * @text Sound: spell burst
 * @type file
 * @dir audio/se
 * @default Fire1
 *
 * @param seCharge
 * @text Sound: cavalry charge
 * @type file
 * @dir audio/se
 * @default Horse
 *
 * @param meVictory
 * @text Music: victory
 * @type file
 * @dir audio/me
 * @default Victory1
 *
 * @param meDefeat
 * @text Music: defeat
 * @type file
 * @dir audio/me
 * @default Defeat1
 *
 * @param battleBgm
 * @text Battle music
 * @type file
 * @dir audio/bgm
 * @desc Played during the battle; the map's music comes back afterwards. Blank = keep the current music.
 * @default Battle2
 *
 * @command battle
 * @text Start Army Battle
 * @desc Opens the battlefield. The event waits until the war record is closed; results are written before it continues.
 *
 * @arg title
 * @text Title
 * @type text
 * @desc Shown on the call to arms and the war record. Blank = "The Battle of <map name>".
 * @default
 *
 * @arg terrain
 * @text Field
 * @type select
 * @option (default)
 * @option meadow
 * @option steppe
 * @option snow
 * @option desert
 * @option moor
 * @default (default)
 *
 * @arg playerArmy
 * @text Your regiments
 * @type struct<Regiment>[]
 * @default ["{\"name\":\"Shieldmen\",\"role\":\"foot\",\"count\":\"40\",\"countVariableId\":\"0\",\"strength\":\"1\"}","{\"name\":\"Pikes\",\"role\":\"pike\",\"count\":\"30\",\"countVariableId\":\"0\",\"strength\":\"1\"}","{\"name\":\"Bowmen\",\"role\":\"archer\",\"count\":\"30\",\"countVariableId\":\"0\",\"strength\":\"1\"}","{\"name\":\"Lancers\",\"role\":\"horse\",\"count\":\"16\",\"countVariableId\":\"0\",\"strength\":\"1\"}"]
 *
 * @arg enemyName
 * @text Enemy army's name
 * @type text
 * @default The Enemy
 *
 * @arg enemyArmy
 * @text Enemy regiments
 * @type struct<Regiment>[]
 * @default ["{\"name\":\"Raiders\",\"role\":\"foot\",\"count\":\"50\",\"countVariableId\":\"0\",\"strength\":\"1\"}","{\"name\":\"Slingers\",\"role\":\"archer\",\"count\":\"30\",\"countVariableId\":\"0\",\"strength\":\"1\"}","{\"name\":\"Riders\",\"role\":\"horse\",\"count\":\"20\",\"countVariableId\":\"0\",\"strength\":\"1\"}","{\"name\":\"Hexers\",\"role\":\"mage\",\"count\":\"8\",\"countVariableId\":\"0\",\"strength\":\"1\"}"]
 *
 * @arg playerFormation
 * @text Your formation
 * @type select
 * @option choose
 * @option line
 * @option wedge
 * @option square
 * @option loose
 * @desc "choose" lets the player pick from four cards before the clash.
 * @default choose
 *
 * @arg enemyFormation
 * @text Enemy formation
 * @type select
 * @option auto
 * @option line
 * @option wedge
 * @option square
 * @option loose
 * @desc "auto" reads the enemy's own make-up (many bows: loose; many riders: wedge; many pikes: square) with a seeded coin.
 * @default auto
 *
 * @arg victorySwitchId
 * @text Victory -> switch
 * @type switch
 * @desc ON after a victory, OFF after a defeat or a draw.
 * @default 0
 *
 * @arg outcomeVariableId
 * @text Outcome -> variable
 * @type variable
 * @desc 1 = victory, 2 = defeat, 3 = neither army held the field.
 * @default 0
 *
 * @arg fallenVariableId
 * @text Your fallen -> variable
 * @type variable
 * @default 0
 *
 * @arg commonEventId
 * @text Common event afterwards
 * @type common_event
 * @default 0
 *
 * @arg seed
 * @text Seed
 * @type text
 * @desc Blank = a different battle every time. A number replays the same battle exactly.
 * @default
 *
 * @help
 * WARHOST - army battles for RPG Maker MZ.
 *
 * Two armies of regiments meet on a painted field. Every soldier is drawn
 * (foot, pikes, archers, horse, mages, in each army's colours), every
 * regiment carries a banner whose arms are generated from its name, and the
 * field itself is painted from a seed. The player picks a formation, then
 * the battle plays out soldier by soldier: volleys arc overhead, spells
 * burst, cavalry charges, regiments break and run. A war record closes it.
 *
 * SETUP
 *   Install WarhostCore.js, WarhostDraw.js and Warhost.js (any order), then
 *   call the plugin command "Start Army Battle" from any event. Declare each
 *   army as a list of regiments.
 *
 * REGIMENTS
 *   name      also decides the banner: the same name always flies the same
 *             arms, so "Iron Company" is recognisable battle after battle.
 *   role      foot | pike | archer | horse | mage
 *   count     soldiers (1 to 99999). Up to 240 figures a side are drawn;
 *             a bigger army is carried at several soldiers per figure and
 *             every number you read back is still in soldiers.
 *   count variable  if set, the count is READ from this variable when the
 *             battle starts and the SURVIVORS are written back to it when it
 *             ends (those who fled come home). Recruit with ordinary event
 *             commands; lose men in battle.
 *   strength  1 = ordinary troops. 1.5 = veterans. 0.5 = levies.
 *
 * WHO BEATS WHOM
 *   Pikes stop horse. Horse runs down archers and mages. Foot cut down
 *   archers and mages who let them close. Archers and mages kill from range.
 *
 * FORMATIONS (the player's choice before the clash)
 *   Line    steady ranks.                         Breaks a loose screen.
 *   Wedge   drive in hard.                        Breaks a line.
 *   Square  shields locked; horse strike at 60%.  Stops a wedge.
 *   Loose   spread out; arrows and spells find little.
 *           Beats a square that has to stand and be shot: with no bows or
 *           mages on the field a loose screen has nothing to dodge.
 *   The counter is how a smaller army gets a chance: measured over 40
 *   seeded battles each, an army at four fifths of the enemy's size that
 *   copied the enemy's formation won none; with the counter it won 5-40%
 *   (mixed armies) and 23-100% (infantry). Readme: the full table.
 *
 * MORALE
 *   A regiment that has lost most of its men while its army is losing may
 *   break and run for its own edge of the field. Those who flee survive.
 *
 * RESULTS (written before the event continues)
 *   Victory switch, outcome variable (1 win, 2 loss, 3 neither), your
 *   fallen, each regiment's survivors to its count variable.
 *
 * CONTROLS
 *   Left/Right or the mouse to choose a formation, OK to confirm.
 *   Hold OK (or the mouse) during the clash to speed it up.
 *
 * SCRIPT
 *   Warhost.lastResult()  the last battle: {winner, seconds, sides, regiments}
 *   Warhost.isOpen()      true while a battle is on screen
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */
/*~struct~Regiment:
 * @param name
 * @text Name
 * @type text
 * @desc Also decides the regiment's banner.
 * @default Regiment
 *
 * @param role
 * @text Role
 * @type select
 * @option foot
 * @option pike
 * @option archer
 * @option horse
 * @option mage
 * @default foot
 *
 * @param count
 * @text Soldiers
 * @type number
 * @min 0
 * @max 99999
 * @default 30
 *
 * @param countVariableId
 * @text Soldiers from/to variable
 * @type variable
 * @desc Read the count from this variable at the start and write the survivors back at the end. 0 = use Soldiers.
 * @default 0
 *
 * @param strength
 * @text Strength
 * @type number
 * @decimals 2
 * @min 0.25
 * @max 4
 * @default 1
 */

var Warhost = (function () {
  'use strict';

  var NAME = 'Warhost';
  var RAW = PluginManager.parameters(NAME);
  var CORE = null, DRAW = null;
  /** ⛔ Sibling files are resolved at FIRST USE, never at load time: the buyer chooses the load order. */
  function deps() {
    if (!CORE) { CORE = window.WarhostCore; DRAW = window.WarhostDraw; }
    if (!CORE || !DRAW) throw new Error('Warhost needs WarhostCore.js and WarhostDraw.js installed and ON in the Plugin Manager.');
    return { core: CORE, draw: DRAW };
  }
  function str(v, d) { return v === undefined || v === null ? d : String(v); }
  function num(v, d) { var s = String(v === undefined || v === null ? '' : v).trim(); if (s === '') return d; var n = Number(s); return isFinite(n) ? n : d; }
  var TERRAINS = ['meadow', 'steppe', 'snow', 'desert', 'moor'];
  var P = {
    playerName: str(RAW.playerArmyName, 'Your Host') || 'Your Host',
    playerColour: str(RAW.playerColour, '').trim(), enemyColour: str(RAW.enemyColour, '').trim(),
    terrain: TERRAINS.indexOf(str(RAW.defaultTerrain, 'meadow')) >= 0 ? str(RAW.defaultTerrain, 'meadow') : 'meadow',
    timeLimit: Math.max(10, Math.min(600, num(RAW.timeLimit, 60))),
    showEnemy: String(RAW.showEnemyFormation) !== 'false',
    se: { horn: str(RAW.seHorn, 'Horn'), clash: str(RAW.seClash, 'Blow3'), volley: str(RAW.seVolley, 'Bow1'), spell: str(RAW.seSpell, 'Fire1'), charge: str(RAW.seCharge, 'Horse') },
    me: { victory: str(RAW.meVictory, 'Victory1'), defeat: str(RAW.meDefeat, 'Defeat1') },
    bgm: str(RAW.battleBgm, 'Battle2')
  };

  /** Parse a struct<Regiment>[] argument (a JSON string of JSON strings, every leaf a string). */
  function parseArmy(raw) {
    var list = []; try { list = JSON.parse(raw || '[]'); } catch (e) { list = []; }
    if (!Array.isArray(list)) return [];
    return list.map(function (s) { var o; try { o = typeof s === 'string' ? JSON.parse(s) : s; } catch (e) { o = null; } return o; }).filter(Boolean).map(function (o) {
      var vid = Math.max(0, Math.floor(num(o.countVariableId, 0)));
      var count = Math.floor(num(o.count, 0));
      if (vid > 0 && typeof $gameVariables !== 'undefined' && $gameVariables) count = Math.floor(num($gameVariables.value(vid), 0));
      return { name: str(o.name, '').trim(), role: str(o.role, 'foot').trim().toLowerCase(), count: count, strength: num(o.strength, 1), countVariableId: vid };
    });
  }

  /** The save record: versioned, created on first use (a save made before install loads cleanly). */
  function rec() {
    var sys = typeof $gameSystem !== 'undefined' ? $gameSystem : null; if (!sys) return null;
    if (!sys._csafWarhost || sys._csafWarhost.v !== 1) sys._csafWarhost = { v: 1, count: 0, last: null };
    return sys._csafWarhost;
  }

  /** Build a battle request from command arguments. Regiments with zero soldiers are dropped; an empty army returns null. */
  function request(args, mapId, eventId) {
    var d = deps(); args = args || {};
    var r = rec(), n = r ? r.count : 0;
    var p = parseArmy(args.playerArmy), e = parseArmy(args.enemyArmy);
    var pn = d.core.normalizeArmy(p, 0), en = d.core.normalizeArmy(e, 1);
    if (!pn.length || !en.length) { console.warn('Warhost: an army with no soldiers cannot take the field (yours ' + pn.length + ' regiments, the enemy ' + en.length + ').'); return null; }
    var seedText = str(args.seed, '').trim();
    var seed = seedText !== '' && isFinite(Number(seedText)) ? (Number(seedText) >>> 0) : (d.core.hashString('m' + mapId + 'e' + eventId + 'n' + n + 't' + Date.now()) >>> 0);
    var terrain = TERRAINS.indexOf(str(args.terrain, '')) >= 0 ? str(args.terrain, '') : P.terrain;
    var pf = str(args.playerFormation, 'choose'), ef = str(args.enemyFormation, 'auto');
    if (d.core.FORM_IDS.indexOf(ef) < 0) ef = d.core.enemyFormation(e, seed);
    var mapName = typeof $gameMap !== 'undefined' && $gameMap && $gameMap.displayName ? $gameMap.displayName() : '';
    return {
      title: str(args.title, '').trim() || (mapName ? 'The Battle of ' + mapName : 'The Battle'),
      terrain: terrain, seed: seed, armies: [p, e], names: [P.playerName, str(args.enemyName, 'The Enemy').trim() || 'The Enemy'],
      playerFormation: d.core.FORM_IDS.indexOf(pf) >= 0 ? pf : 'choose', enemyFormation: ef,
      victorySwitchId: Math.max(0, Math.floor(num(args.victorySwitchId, 0))), outcomeVariableId: Math.max(0, Math.floor(num(args.outcomeVariableId, 0))),
      fallenVariableId: Math.max(0, Math.floor(num(args.fallenVariableId, 0))), commonEventId: Math.max(0, Math.floor(num(args.commonEventId, 0))),
      timeLimit: P.timeLimit
    };
  }

  var OPEN = false;
  function open(req) { if (!req) return false; SceneManager.push(Scene_Warhost); SceneManager.prepareNextScene(req); OPEN = true; return true; }

  /** Write the outcome into the game. Called once, as the war record closes. */
  function apply(req, r) {
    var s = rec(); if (s) { s.count++; s.last = { title: req.title, winner: r.winner, seconds: r.seconds, forms: r.forms, sides: r.sides, regiments: r.regiments }; }
    if (req.victorySwitchId) $gameSwitches.setValue(req.victorySwitchId, r.winner === 0);
    if (req.outcomeVariableId) $gameVariables.setValue(req.outcomeVariableId, r.winner === 0 ? 1 : r.winner === 1 ? 2 : 3);
    if (req.fallenVariableId) $gameVariables.setValue(req.fallenVariableId, r.sides[0].dead);
    // survivors back to each regiment's variable, in declaration order (normalizeArmy dropped empty regiments, so match them the same way)
    for (var side = 0; side < 2; side++) {
      var decl = req.armies[side].filter(function (g) { return Math.floor(num(g.count, 0)) >= 1; }), k = 0;
      r.regiments.forEach(function (g) { if (g.side !== side) return; var dcl = decl[k++]; if (dcl && dcl.countVariableId) $gameVariables.setValue(dcl.countVariableId, g.survived + g.fled); });
    }
    if (req.commonEventId) $gameTemp.reserveCommonEvent(req.commonEventId);
  }

  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
    PluginManager.registerCommand(NAME, 'battle', function (args) {
      var mapId = this._mapId || ($gameMap ? $gameMap.mapId() : 0), eventId = this.eventId ? this.eventId() : 0;
      open(request(args, mapId, eventId));
    });
  }

  return {
    VERSION: '1.0.0', P: P, deps: deps, request: request, open: open, apply: apply, parseArmy: parseArmy,
    isOpen: function () { return OPEN; }, setOpen: function (v) { OPEN = !!v; },
    lastResult: function () { var r = rec(); return r ? r.last : null; },
    playSe: function (n, vol) { if (n) AudioManager.playSe({ name: n, volume: vol || 80, pitch: 100, pan: 0 }); }
  };
})();

//=============================================================================
// Scene_Warhost
//=============================================================================

function Scene_Warhost() { this.initialize.apply(this, arguments); }
Scene_Warhost.prototype = Object.create(Scene_Base.prototype);
Scene_Warhost.prototype.constructor = Scene_Warhost;
Scene_Warhost.ARROWS = 256;
Scene_Warhost.BURSTS = 24;
Scene_Warhost.PUFFS = 64;
Scene_Warhost.SPARKS = 48;
Scene_Warhost.STUCK = 96;
Scene_Warhost.CARDS = { y: 50, w: 170, h: 150, gap: 18 };   // in the sky band: no soldier stands above y 214, so the cards hide no one

Scene_Warhost.prototype.prepare = function (req) { this._req = req; };

Scene_Warhost.prototype.create = function () {
  Scene_Base.prototype.create.call(this);
  var d = Warhost.deps(); this._d = d; var req = this._req, C = d.core;
  this._mid = C.FIELD.mid;
  this._phase = 'intro'; this._age = 0; this._endAge = 0; this._pick = Math.max(0, C.FORM_IDS.indexOf(req.playerFormation === 'choose' ? 'line' : req.playerFormation));
  this._liveries = [d.draw.livery(0, Warhost.P.playerColour), d.draw.livery(1, Warhost.P.enemyColour)];
  this.newBattle(C.FORM_IDS[this._pick]);
  this._arms = this._b.regs.map(function (g) { return C.heraldry(g.name, g.side); });
  var maxSamples = Math.ceil(req.timeLimit * 2) + 4; this._hist = { n: 0, dt: 0.5, s0: new Float32Array(maxSamples), s1: new Float32Array(maxSamples), routs: [] }; this._nextSample = 0;
  this.createField(); this.createSoldiers(); this.createBanners(); this.createFx(); this.createUi();
  this.syncSoldiers(true);
};
/** (Re)deploy for a formation choice. Allocation happens here, on a choice, never per frame. */
Scene_Warhost.prototype.newBattle = function (form) {
  var req = this._req;
  this._form = form;
  this._b = this._d.core.newBattle({ seed: req.seed, armies: req.armies, forms: [form, req.enemyFormation], timeLimit: Math.round(req.timeLimit * 60) });
  if (this._figs && this._figs.length !== this._b.n) throw new Error('Warhost: figure count changed with the formation');
};
Scene_Warhost.prototype.start = function () {
  Scene_Base.prototype.start.call(this); this.startFadeIn(this.fadeSpeed(), false);
  if (Warhost.P.bgm) { this._savedBgm = AudioManager.saveBgm(); AudioManager.playBgm({ name: Warhost.P.bgm, volume: 80, pitch: 100, pan: 0 }); }
  Warhost.playSe(Warhost.P.se.horn, 90);
};

Scene_Warhost.prototype.createField = function () {
  var bmp = new Bitmap(Graphics.width, Graphics.height);
  this._d.draw.drawField(bmp.context, Graphics.width, Graphics.height, this._req.terrain, this._req.seed, 190);
  bmp._baseTexture.update(); this._field = new Sprite(bmp); this.addChild(this._field);
};
Scene_Warhost.prototype.createSoldiers = function () {
  var D = this._d.draw, C = this._d.core, sz = D.atlasSize(C.ROLE_IDS), atlas = new Bitmap(sz.w, sz.h);
  D.drawAtlas(atlas.context, C.ROLE_IDS, this._liveries); atlas._baseTexture.update(); this._atlas = atlas;
  this._tex = [];
  for (var row = 0; row < C.ROLE_IDS.length * 2; row++) { var t = []; for (var f = 0; f < D.FRAMES.length; f++) t.push(new PIXI.Texture(atlas.baseTexture, new PIXI.Rectangle(f * D.CELL.w, row * D.CELL.h, D.CELL.w, D.CELL.h))); this._tex.push(t); }
  this._layer = new PIXI.Container(); this.addChild(this._layer);
  var b = this._b, ax = D.CELL.cx / D.CELL.w, ay = D.CELL.foot / D.CELL.h;
  this._figs = []; this._px = new Float64Array(b.n);
  for (var i = 0; i < b.n; i++) { var s = new PIXI.Sprite(this._tex[0][0]); s.anchor.set(ax, ay); s._k = 0; this._layer.addChild(s); this._figs.push(s); }
};
Scene_Warhost.prototype.createBanners = function () {
  var D = this._d.draw; this._banners = [];
  for (var r = 0; r < this._b.regs.length; r++) {
    var bmp = new Bitmap(56, 84); D.drawBanner(bmp.context, 8, 10, 38, 28, this._arms[r], 70); bmp._baseTexture.update();
    var sp = new Sprite(bmp); sp.anchor.x = 8 / 56; sp.anchor.y = 80 / 84; this.addChild(sp); this._banners.push(sp);
  }
};
Scene_Warhost.prototype.createFx = function () {
  var D = this._d.draw, self = this, i, s;
  function tex(w, h, fn) { var b = new Bitmap(w, h); fn(b.context, w); b._baseTexture.update(); return new PIXI.Texture(b.baseTexture); }
  var arrowT = tex(14, 4, function (c) { D.drawArrow(c); }), burstT = tex(64, 64, function (c, w) { D.drawBurst(c, w); }), puffT = tex(40, 40, function (c, w) { D.drawPuff(c, w); }), sparkT = tex(12, 12, function (c, w) { D.drawSpark(c, w); });
  function pool(n, t, ax, ay, add, into) { var out = []; for (var k = 0; k < n; k++) { var p = new PIXI.Sprite(t); p.anchor.set(ax, ay); p.visible = false; p._life = 0; p._max = 1; if (add) p.blendMode = PIXI.BLEND_MODES.ADD; (into || self).addChild(p); out.push(p); } return out; }
  this._stuck = pool(Scene_Warhost.STUCK, arrowT, 1, 0.5, false, this._layer); this._stuckNext = 0;
  this._puffs = pool(Scene_Warhost.PUFFS, puffT, 0.5, 0.5, false); this._puffNext = 0;
  this._arrows = pool(Scene_Warhost.ARROWS, arrowT, 0.5, 0.5, false);
  this._bursts = pool(Scene_Warhost.BURSTS, burstT, 0.5, 0.5, true); this._burstNext = 0;
  this._sparks = pool(Scene_Warhost.SPARKS, sparkT, 0.5, 0.5, true); this._sparkNext = 0;
  this._orbs = pool(32, burstT, 0.5, 0.5, true);
  for (i = 0; i < this._stuck.length; i++) { s = this._stuck[i]; s.rotation = -0.95; s._k = 0; }
  this._seClock = { clash: 0, volley: 0, spell: 0, charge: 0 };
};
Scene_Warhost.prototype.createUi = function () {
  var W = Graphics.width, D = this._d.draw;
  this._hud = new Sprite(new Bitmap(W, 52)); this._hud.visible = false; this.addChild(this._hud); this._hudKey = -1;
  this._note = new Sprite(new Bitmap(W, 40)); this._note.y = 58; this._note.visible = false; this.addChild(this._note);
  this._cards = new Sprite(new Bitmap(W, 200)); this._cards.y = Scene_Warhost.CARDS.y - 16; this._cards.visible = false; this.addChild(this._cards); this._cardsKey = '';
  this._title = new Sprite(new Bitmap(W, 110)); D.drawTitle(this._title.bitmap.context, W, 110, this._req.title, this._req.names[0] + ' against ' + this._req.names[1]); this._title.bitmap._baseTexture.update(); this._title.y = -110; this.addChild(this._title);
  this._record = new Sprite(new Bitmap(W, Graphics.height)); this._record.visible = false; this.addChild(this._record);
};

//---------------------------------------------------------------------------- per frame (scalars and pooled sprites only)

Scene_Warhost.prototype.update = function () {
  Scene_Base.prototype.update.call(this);
  this._age++;
  var ph = this._phase;
  if (ph === 'intro') this.updateIntro();
  else if (ph === 'choose') this.updateChoose();
  else if (ph === 'clash') this.updateClash();
  else if (ph === 'record') this.updateRecord();
  else if (ph === 'leaving' && !this.isBusy()) { this._phase = 'gone'; Warhost.setOpen(false); this.popScene(); }
  this.updateBanners(); this.updateFx();
};
Scene_Warhost.prototype.updateIntro = function () {
  var a = this._age;
  this._title.y = a < 30 ? -110 + a * (110 + 20) / 30 : (a < 110 ? 20 : 20 - (a - 110) * 4);
  this._title.opacity = a < 110 ? 255 : Math.max(0, 255 - (a - 110) * 9);
  if (a >= 140 || (a > 30 && (Input.isTriggered('ok') || TouchInput.isTriggered()))) {
    this._title.visible = false;
    if (this._req.playerFormation === 'choose') this.enterChoose(); else this.enterClash();
  }
};
Scene_Warhost.prototype.enterChoose = function () {
  this._phase = 'choose'; this._age = 0; this._cards.visible = true; this.refreshCards(); this._note.y = 4;
  var C = this._d.core, ef = C.FORMS[this._req.enemyFormation].label.toLowerCase();
  this.setNote(Warhost.P.showEnemy ? this._req.names[1] + ' forms a ' + ef + '. Choose your order.' : 'Choose your order. The enemy\'s is hidden.');
};
Scene_Warhost.prototype.setNote = function (text) { if (!text) { this._note.visible = false; return; } this._d.draw.drawNote(this._note.bitmap.context, Graphics.width, 40, text, 'iron'); this._note.bitmap._baseTexture.update(); this._note.visible = true; };
Scene_Warhost.prototype.cardX = function (k) { var K = Scene_Warhost.CARDS, total = 4 * K.w + 3 * K.gap; return (Graphics.width - total) / 2 + k * (K.w + K.gap); };
Scene_Warhost.prototype.refreshCards = function () {
  var C = this._d.core, D = this._d.draw, K = Scene_Warhost.CARDS, ctx = this._cards.bitmap.context, key = this._pick + '|' + this._hover;
  if (key === this._cardsKey) return; this._cardsKey = key;
  ctx.clearRect(0, 0, Graphics.width, 200);
  for (var k = 0; k < 4; k++) { var f = C.FORM_IDS[k]; D.drawCard(ctx, this.cardX(k), 16, K.w, K.h, f, C.FORMS[f], C.FORMS[C.FORMS[f].beats].label, k === this._pick ? 'chosen' : (k === this._hover ? 'hover' : 'idle')); }
  this._cards.bitmap._baseTexture.update();
};
Scene_Warhost.prototype.choose = function (k) { if (k === this._pick) return; this._pick = k; this.newBattle(this._d.core.FORM_IDS[k]); this.syncSoldiers(true); this.refreshCards(); Warhost.playSe('Cursor1', 60); };
Scene_Warhost.prototype.updateChoose = function () {
  var K = Scene_Warhost.CARDS;
  if (Input.isRepeated('left')) this.choose((this._pick + 3) % 4);
  else if (Input.isRepeated('right')) this.choose((this._pick + 1) % 4);
  var tx = TouchInput.x, ty = TouchInput.y, hover = -1;
  if (ty >= K.y && ty < K.y + K.h) for (var k = 0; k < 4; k++) if (tx >= this.cardX(k) && tx < this.cardX(k) + K.w) hover = k;
  if (hover !== this._hover) { this._hover = hover; this.refreshCards(); }
  if (TouchInput.isTriggered() && hover >= 0) { if (hover === this._pick) this.enterClash(); else this.choose(hover); return; }
  if (Input.isTriggered('ok') && this._age > 8) this.enterClash();
  this.syncSoldiers(false);
};
Scene_Warhost.prototype.enterClash = function () {
  this._phase = 'clash'; this._age = 0; this._cards.visible = false; this._hud.visible = true; this._hudKey = -1; this._note.y = 58; this._note.opacity = 255;
  this._sideFigs = [0, 0]; for (var i = 0; i < this._b.n; i++) this._sideFigs[this._b.side[i]]++;
  this.sample();
  var C = this._d.core; this.setNote(this._req.names[0] + ': ' + C.FORMS[this._form].label + '   ·   ' + this._req.names[1] + ': ' + C.FORMS[this._req.enemyFormation].label);
  this._noteAge = 0; Warhost.playSe(Warhost.P.se.horn, 90); Warhost.playSe('Battle1', 70);
};
Scene_Warhost.prototype.updateClash = function () {
  var b = this._b, C = this._d.core;
  if (this._note.visible && ++this._noteAge > 150) this._note.opacity = Math.max(0, this._note.opacity - 12);
  if (!b.over) {
    var steps = (Input.isPressed('ok') || Input.isPressed('shift') || TouchInput.isPressed()) ? 3 : 1;
    for (var s = 0; s < steps && !b.over; s++) { var n = C.tick(b); this.onEvents(n); if (b.frame >= this._nextSample || b.over) this.sample(); }
  } else if (++this._endAge > 70) this.enterRecord();
  this.syncSoldiers(false); this.syncProjectiles(); this.refreshHud();
};
/** One point of the course of the battle: the share of each army still standing and fighting (every half second). */
Scene_Warhost.prototype.sample = function () {
  var h = this._hist, b = this._b; if (h.n >= h.s0.length) return;
  h.s0[h.n] = this._sideFigs[0] ? b.sideActive[0] / this._sideFigs[0] : 0; h.s1[h.n] = this._sideFigs[1] ? b.sideActive[1] / this._sideFigs[1] : 0; h.n++;
  this._nextSample = b.frame + 30;
};
Scene_Warhost.prototype.enterRecord = function () {
  var C = this._d.core, r = C.result(this._b), W = Graphics.width, H = Graphics.height; this._result = r;
  this._d.draw.drawRecord(this._record.bitmap.context, W, H, r, this._arms, { title: this._req.title, names: this._req.names, formLabels: [C.FORMS[r.forms[0]].label, C.FORMS[r.forms[1]].label], history: this._hist });
  this._record.bitmap._baseTexture.update(); this._record.visible = true; this._record.opacity = 0; this._note.visible = false;
  this._phase = 'record'; this._age = 0;
  var me = r.winner === 0 ? Warhost.P.me.victory : (r.winner === 1 ? Warhost.P.me.defeat : '');
  if (me) AudioManager.playMe({ name: me, volume: 90, pitch: 100, pan: 0 });
};
Scene_Warhost.prototype.updateRecord = function () {
  this._record.opacity = Math.min(255, this._age * 14);
  if (this._age > 30 && (Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered())) this.leave();
};
Scene_Warhost.prototype.leave = function () {
  if (this._phase === 'leaving') return;
  Warhost.apply(this._req, this._result);
  this._phase = 'leaving'; this.startFadeOut(this.fadeSpeed(), false);
  if (this._savedBgm) AudioManager.replayBgm(this._savedBgm); else if (Warhost.P.bgm) AudioManager.fadeOutBgm(1);
};

/** Pose, place and depth-sort every figure from the core's arrays. */
Scene_Warhost.prototype.syncSoldiers = function (force) {
  var b = this._b, mid = this._mid, f = Graphics.frameCount, nr = this._d.core.ROLE_IDS.length;
  for (var i = 0; i < b.n; i++) {
    var sp = this._figs[i], st = b.state[i];
    if (st === 3) { sp.visible = false; continue; }
    sp.visible = true;
    var x = b.x[i] + mid, y = b.y[i], moved = force ? 0 : Math.abs(x - this._px[i]); this._px[i] = x;
    var frame = st === 1 ? 3 : (b.act[i] < 14 ? 2 : (moved > 0.05 ? ((f + b.slot[i] * 5) >> 3) & 1 : 0));
    var t = this._tex[b.side[i] * nr + b.role[i]][frame]; if (sp.texture !== t) sp.texture = t;
    sp.x = x; sp.y = y;
    var face = st === 1 ? (b.side[i] ? -1 : 1) : b.face[i]; if (sp.scale.x !== face) sp.scale.x = face;
    if (st === 1) { if (sp.alpha !== 0.88) { sp.alpha = 0.88; sp.tint = 0xb8b0a4; } } else if (sp.alpha !== 1) { sp.alpha = 1; sp.tint = 0xffffff; }
    sp._k = st === 1 ? y - 8 : y;
  }
  if (force || (f % 3) === 0) this.sortLayer();
};
/** Insertion sort of the soldier layer by depth: almost sorted every time, so O(n), and no allocation. */
Scene_Warhost.prototype.sortLayer = function () {
  var ch = this._layer.children;
  for (var i = 1; i < ch.length; i++) { var c = ch[i], k = c._k, j = i - 1; while (j >= 0 && ch[j]._k > k) { ch[j + 1] = ch[j]; j--; } ch[j + 1] = c; }
};
Scene_Warhost.prototype.syncProjectiles = function () {
  var b = this._b, mid = this._mid, A = this._arrows, O = this._orbs, na = 0, no = 0;
  for (var k = 0; k < b.pn; k++) {
    if (!b.plive[k]) continue;
    var t = b.pt[k] / b.pT[k], x0 = b.px0[k] + mid, y0 = b.py0[k], x1 = b.px1[k] + mid, y1 = b.py1[k], dx = x1 - x0, dy = y1 - y0;
    if (b.pkind[k] === 1) {
      if (na >= A.length) continue;
      var h = Math.min(90, Math.abs(dx) * 0.28), x = x0 + dx * t, y = y0 + dy * t - h * 4 * t * (1 - t), a = A[na++];
      a.visible = true; a.x = x; a.y = y; a.rotation = Math.atan2(dy - h * 4 * (1 - 2 * t), dx);
    } else {
      if (no >= O.length) continue;
      var o = O[no++], hh = 30; o.visible = true; o.x = x0 + dx * t; o.y = y0 + dy * t - hh * 4 * t * (1 - t); o.scale.x = o.scale.y = 0.28 + 0.06 * Math.sin(t * 20); o.alpha = 0.9;
    }
  }
  for (; na < A.length; na++) if (A[na].visible) A[na].visible = false; else break;
  for (; no < O.length; no++) if (O[no].visible) O[no].visible = false; else break;
};
Scene_Warhost.prototype.onEvents = function (n) {
  var b = this._b, EV = this._d.core.EV, mid = this._mid, f = Graphics.frameCount, se = Warhost.P.se, clk = this._seClock;
  for (var k = 0; k < n; k++) {
    var type = b.evType[k], x = b.evX[k] + mid, y = b.evY[k];
    if (type === EV.BLOW) { this.spark(x, y); if (f - clk.clash > 9) { clk.clash = f; Warhost.playSe(se.clash, 45); } }
    else if (type === EV.DEATH) this.puff(x, y - 4, 0.5);
    else if (type === EV.LOOSE) { if (f - clk.volley > 14) { clk.volley = f; Warhost.playSe(se.volley, 50); } }
    else if (type === EV.ARROW_MISS) this.stick(x, y);
    else if (type === EV.BURST) { this.burst(x, y); if (f - clk.spell > 12) { clk.spell = f; Warhost.playSe(se.spell, 60); } }
    else if (type === EV.CHARGE) { if ((b.slot[b.evA[k]] & 3) === 0) this.puff(x - b.face[b.evA[k]] * 8, y - 2, 0.35); if (f - clk.charge > 90) { clk.charge = f; Warhost.playSe(se.charge, 70); } }
    else if (type === EV.ROUT) { this.puff(x, y - 10, 1.2); var g = b.regs[b.evA[k]]; if (g && this._hist.routs.length < 32) this._hist.routs.push({ t: b.frame / 60, side: g.side, name: g.name }); }   // a rout is a rare event, not a per-frame one
  }
};
Scene_Warhost.prototype.spark = function (x, y) { var p = this._sparks[this._sparkNext]; this._sparkNext = (this._sparkNext + 1) % this._sparks.length; p.visible = true; p.x = x; p.y = y; p._life = p._max = 8; p.scale.x = p.scale.y = 0.9; p.alpha = 1; };
Scene_Warhost.prototype.puff = function (x, y, s) { var p = this._puffs[this._puffNext]; this._puffNext = (this._puffNext + 1) % this._puffs.length; p.visible = true; p.x = x; p.y = y; p._life = p._max = 34; p._s = s; p.scale.x = p.scale.y = s * 0.4; p.alpha = 0.8; };
Scene_Warhost.prototype.burst = function (x, y) { var p = this._bursts[this._burstNext]; this._burstNext = (this._burstNext + 1) % this._bursts.length; p.visible = true; p.x = x; p.y = y - 4; p._life = p._max = 26; p.scale.x = p.scale.y = 0.3; p.alpha = 1; };
Scene_Warhost.prototype.stick = function (x, y) { var p = this._stuck[this._stuckNext]; this._stuckNext = (this._stuckNext + 1) % this._stuck.length; p.visible = true; p.x = x + 4; p.y = y; p._k = y - 9; p.alpha = 0.9; };
Scene_Warhost.prototype.updateFx = function () {
  var i, p, t;
  for (i = 0; i < this._sparks.length; i++) { p = this._sparks[i]; if (!p.visible) continue; if (--p._life <= 0) { p.visible = false; continue; } t = p._life / p._max; p.alpha = t; p.scale.x = p.scale.y = 0.5 + (1 - t) * 0.8; }
  for (i = 0; i < this._puffs.length; i++) { p = this._puffs[i]; if (!p.visible) continue; if (--p._life <= 0) { p.visible = false; continue; } t = p._life / p._max; p.alpha = t * 0.8; p.scale.x = p.scale.y = p._s * (0.4 + (1 - t) * 0.9); p.y -= 0.15; }
  for (i = 0; i < this._bursts.length; i++) { p = this._bursts[i]; if (!p.visible) continue; if (--p._life <= 0) { p.visible = false; continue; } t = p._life / p._max; p.alpha = t; p.scale.x = p.scale.y = 0.3 + (1 - t) * 1.3; }
};
Scene_Warhost.prototype.updateBanners = function () {
  var b = this._b, f = Graphics.frameCount, mid = this._mid;
  for (var r = 0; r < this._banners.length; r++) {
    var sp = this._banners[r], i0 = b.regFig0[r], n = b.regFigN[r], cx = 0, cy = 0, c = 0, fled = 0;
    for (var i = i0; i < i0 + n; i++) { var st = b.state[i]; if (st === 0 || st === 2) { cx += b.x[i]; cy += b.y[i]; c++; if (st === 2) fled++; } }
    if (c > 0) { sp.x = cx / c + mid; sp.y = cy / c - 10; sp._down = 0; }
    var routed = b.regRouted[r] === 1, gone = c === 0;
    var target = gone ? 1.35 : (routed ? 0.7 : 0);
    sp.rotation += (target - sp.rotation) * 0.08;
    sp.skew.x = gone ? 0 : Math.sin((f + r * 37) / 26) * 0.05;
    sp.opacity = gone ? Math.max(90, sp.opacity - 4) : 255;
  }
};
Scene_Warhost.prototype.refreshHud = function () {
  var b = this._b; if ((Graphics.frameCount % 6) !== 0 && this._hudKey !== -1) return;
  var a0 = 0, a1 = 0, f0 = 0, f1 = 0, c0 = 0, c1 = 0;
  for (var r = 0; r < b.regs.length; r++) { var g = b.regs[r], rep = g.count / b.regFigN[r], i0 = b.regFig0[r], n = b.regFigN[r], al = 0, fl = 0; for (var i = i0; i < i0 + n; i++) { if (b.state[i] === 0) al++; else if (b.state[i] >= 2) fl++; } if (g.side === 0) { a0 += al * rep; f0 += fl * rep; c0 += g.count; } else { a1 += al * rep; f1 += fl * rep; c1 += g.count; } }
  a0 = Math.round(a0); a1 = Math.round(a1); f0 = Math.round(f0); f1 = Math.round(f1);
  var sec = Math.floor(b.frame / 60), key = ((a0 * 100003 + a1) * 31 + f0 * 7 + f1) * 61 + sec;
  if (key === this._hudKey) return; this._hudKey = key;
  if (!this._hudInfo) this._hudInfo = { names: this._req.names, arms: [this._arms[0], this._arms[b.regs.findIndex(function (x) { return x.side === 1; })]], count: [0, 0], alive: [0, 0], fled: [0, 0], seconds: 0 };
  var h = this._hudInfo; h.count[0] = c0; h.count[1] = c1; h.alive[0] = a0; h.alive[1] = a1; h.fled[0] = f0; h.fled[1] = f1; h.seconds = sec;
  this._d.draw.drawHud(this._hud.bitmap.context, Graphics.width, 52, h); this._hud.bitmap._baseTexture.update();
};
Scene_Warhost.prototype.terminate = function () { Scene_Base.prototype.terminate.call(this); Warhost.setOpen(false); };
