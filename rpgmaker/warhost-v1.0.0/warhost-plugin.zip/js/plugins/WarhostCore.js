//=============================================================================
// WarhostCore.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Warhost core - the army battle simulation (no drawing).
 * Required by Warhost.js. Put it anywhere in the list.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * WarhostCore holds the rules of an army battle: regiments, formations, the
 * soldier-by-soldier clash, morale and the outcome. It draws nothing and has
 * no commands of its own; Warhost.js uses it.
 *
 * Every battle is seeded: the same armies, formations and seed always play
 * out the same way, frame for frame.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var WarhostCore = (function () {
  'use strict';

  /* ------------------------------------------------------------------ seeded RNG (no allocation per draw) */
  /** FNV-1a string hash -> uint32. */
  function hashString(s) {
    var h = 2166136261 >>> 0; s = String(s);
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    return h >>> 0;
  }
  /** mulberry32 step on a one-slot Uint32Array state. Returns [0, 1). */
  function rnd(st) {
    var t = (st[0] = (st[0] + 0x6D2B79F5) >>> 0);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  function newRng(seed) { var st = new Uint32Array(1); st[0] = (seed >>> 0) || 1; return st; }

  /* ------------------------------------------------------------------ the rules */
  var ROLE_IDS = ['foot', 'pike', 'archer', 'horse', 'mage'];
  /** Per-soldier base values. speed px/frame, reach px, cd frames between blows, range px for shots and spells. */
  var ROLES = {
    foot:   { hp: 12, atk: 3.0, speed: 0.55, reach: 13, cd: 42, range: 0,   shot: 0,   spell: 0,   rout: 0.40, label: 'Foot' },
    pike:   { hp: 12, atk: 2.6, speed: 0.48, reach: 20, cd: 48, range: 0,   shot: 0,   spell: 0,   rout: 0.40, label: 'Pikes' },
    archer: { hp: 8,  atk: 1.2, speed: 0.50, reach: 12, cd: 90, range: 210, shot: 1.45, spell: 0,  rout: 0.45, label: 'Archers' },
    horse:  { hp: 18, atk: 4.2, speed: 1.35, reach: 14, cd: 36, range: 0,   shot: 0,   spell: 0,   rout: 0.35, label: 'Horse' },
    mage:   { hp: 7,  atk: 0.8, speed: 0.42, reach: 12, cd: 170, range: 190, shot: 0,  spell: 3.2, rout: 0.45, label: 'Mages' }
  };
  /** Role-vs-role damage multipliers (attacker row, defender column). Missing = 1. */
  var MATCH = {
    pike: { horse: 2.6 },
    horse: { archer: 1.8, mage: 2.0, pike: 0.55 },
    foot: { archer: 1.3, mage: 1.3 },
    archer: { horse: 0.8 }
  };
  var FORM_IDS = ['line', 'wedge', 'square', 'loose'];
  /**
   * Formations. speed = march multiplier; melee = blow strength; taken.* = damage the formation TAKES by kind; spacing =
   * how far apart the ranks stand. beats = the formation this one breaks in melee (the edge).
   */
  var FORMS = {
    line:   { speed: 1.00, melee: 1.00, taken: { melee: 1.00, shot: 1.00, spell: 1.00, horse: 1.00 }, spacing: 1.00, beats: 'loose',  label: 'Line',   motto: 'Steady ranks. Breaks a loose screen.' },
    wedge:  { speed: 1.00, melee: 1.10, taken: { melee: 1.00, shot: 1.00, spell: 1.00, horse: 1.00 }, spacing: 0.85, beats: 'line',   label: 'Wedge',  motto: 'Drive in hard. Breaks a line.' },
    square: { speed: 0.95, melee: 1.00, taken: { melee: 0.95, shot: 1.00, spell: 1.05, horse: 0.60 }, spacing: 0.72, beats: 'wedge',  label: 'Square', motto: 'Shields locked. Stops a wedge and horse.' },
    loose:  { speed: 1.00, melee: 0.90, taken: { melee: 1.00, shot: 0.82, spell: 0.80, horse: 1.00 }, spacing: 1.60, beats: 'square', label: 'Loose',  motto: 'Spread out. Arrows find little. Outlasts a square.' }
  };
  /**
   * The formation that beats the other deals EDGE times its melee and takes EDGE_GUARD times the other's. Measured
   * 2026-09-28: a one-way melee bonus of 1.25 was swamped by geometry and make-up (square lost to wedge 3%), so the
   * counter is two-way and explicit. The balance probe prints the matrix; re-run it after any change here.
   */
  var EDGE = 1.4, EDGE_GUARD = 0.8;
  /**
   * ⛔ b.x is measured from the CENTRE LINE (screen x = b.x + FIELD.mid). MEASURED 2026-09-28: with screen coordinates a
   * fully deterministic mirror battle went 60/0 to whichever army stood on the LEFT, because a + d and 558 - d do not round
   * alike; IEEE rounding of u and -u is exactly symmetric, so centred coordinates keep a mirrored battle mirrored.
   */
  var FIELD = { w: 816, top: 214, bottom: 590, mid: 408 };
  var CAP_PER_SIDE = 240;  // figures drawn per side; bigger armies are carried at more soldiers per figure

  function num(v, d) { var n = Number(v); return isFinite(n) ? n : d; }
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }

  /**
   * Validate one army declaration. Unknown roles become foot; counts below 1 drop the regiment; strength is clamped.
   * @param {Array<{name:string, role:string, count:number, strength:number}>} list
   * @param {number} side 0 = the player's, 1 = the enemy's
   * @returns {Array} normalised regiments (never empty unless every entry was empty)
   */
  function normalizeArmy(list, side) {
    var out = [];
    (Array.isArray(list) ? list : []).forEach(function (r, k) {
      if (!r) return;
      var count = Math.floor(num(r.count, 0)); if (count < 1) return;
      var role = ROLE_IDS.indexOf(String(r.role || '').toLowerCase()) >= 0 ? String(r.role).toLowerCase() : 'foot';
      out.push({ name: String(r.name || '').trim() || (ROLES[role].label + ' ' + (k + 1)), role: role, count: Math.min(count, 99999),
        strength: clamp(num(r.strength, 1), 0.25, 4), side: side | 0, banner: r.banner ? String(r.banner) : '' });
    });
    return out;
  }

  /**
   * Place a regiment's figures for its formation. Writes into b.x/b.y from index i0, returns nothing.
   * The front face points at the enemy (dir +1 = rightwards).
   */
  function placeBlock(b, i0, n, cx, cy, dir, form, rng, laneH) {
    var sp = 11 * FORMS[form].spacing, k;
    if (form === 'wedge') {
      // rows of 3, 5, 7 ... behind a blunt point facing the enemy (a shallow wedge: a deep one arrives one man at a time)
      var row = 0, inRow = 0, width = 3;
      for (k = 0; k < n; k++) {
        b.x[i0 + k] = cx - dir * row * sp * 0.8;
        b.y[i0 + k] = cy + (inRow - (width - 1) / 2) * sp;
        if (++inRow >= width) { row++; width += 2; inRow = 0; }
      }
      return;
    }
    var rows;
    if (form === 'square') rows = Math.max(1, Math.round(Math.sqrt(n)));
    else rows = Math.max(1, Math.min(Math.floor(laneH / sp), Math.ceil(n / (form === 'line' ? 3 : 4))));
    var cols = Math.ceil(n / rows);
    for (k = 0; k < n; k++) {
      var c = Math.floor(k / rows), r = k % rows;
      var jx = form === 'loose' ? (rnd(rng) - 0.5) * sp * 0.7 : 0, jy = form === 'loose' ? (rnd(rng) - 0.5) * sp * 0.7 : 0;
      b.x[i0 + k] = cx - dir * c * sp + jx;
      b.y[i0 + k] = cy + (r - (rows - 1) / 2) * sp + jy;
    }
    b.cols = cols;
  }

  /**
   * Create a battle.
   * @param {{seed:number, armies:Array, forms:Array<string>, timeLimit:number, cap:number}} o
   */
  function newBattle(o) {
    o = o || {};
    var seed = (num(o.seed, 1) >>> 0) || 1, rng = newRng(seed);
    var armies = [normalizeArmy(o.armies && o.armies[0], 0), normalizeArmy(o.armies && o.armies[1], 1)];
    var forms = [FORM_IDS.indexOf(o.forms && o.forms[0]) >= 0 ? o.forms[0] : 'line', FORM_IDS.indexOf(o.forms && o.forms[1]) >= 0 ? o.forms[1] : 'line'];
    var cap = clamp(Math.floor(num(o.cap, CAP_PER_SIDE)), 8, 600);
    var regs = armies[0].concat(armies[1]);
    // figures per regiment: a side whose soldiers exceed the cap carries several soldiers per figure (rep)
    var total = 0, s, r, k;
    for (s = 0; s < 2; s++) {
      var sum = 0; armies[s].forEach(function (g) { sum += g.count; });
      var scale = sum > cap ? sum / cap : 1;
      armies[s].forEach(function (g) { g.figures = Math.max(1, Math.round(g.count / scale)); g.rep = g.count / g.figures; total += g.figures; });
    }
    var b = {
      seed: seed, rng: rng, frame: 0, over: false, winner: -1, timeLimit: Math.max(600, Math.floor(num(o.timeLimit, 3600))),
      forms: forms, regs: regs, n: total,
      // positions are float64: float32 rounds differently at x=258 than at x=558, and that alone tilted mirror battles
      x: new Float64Array(total), y: new Float64Array(total), nx: new Float64Array(total), ny: new Float64Array(total),
      hp: new Float32Array(total), hpMax: new Float32Array(total),
      cd: new Float32Array(total), side: new Uint8Array(total), role: new Uint8Array(total), reg: new Uint16Array(total),
      state: new Uint8Array(total),   // 0 alive, 1 dead, 2 routing, 3 fled (left the field)
      target: new Int32Array(total), face: new Int8Array(total), charged: new Uint8Array(total), deadAt: new Int32Array(total),
      pend: new Float32Array(total),  // damage waiting for the end of the frame
      slot: new Uint16Array(total),   // index within its own army
      gridHead: new Int32Array(GW * GH), gridNext: new Int32Array(total),
      valour: new Float32Array(regs.length),
      act: new Uint16Array(total),    // frames since the last blow/shot (the scene poses the figure from it)
      // projectiles: arrows and spells in flight
      pn: 0, pMax: 512, px0: new Float32Array(512), py0: new Float32Array(512), px1: new Float32Array(512), py1: new Float32Array(512),
      pt: new Uint16Array(512), pT: new Uint16Array(512), pkind: new Uint8Array(512), pfrom: new Int32Array(512), pto: new Int32Array(512), plive: new Uint8Array(512),
      // per-frame events for the scene: type, x, y, a (who)
      evN: 0, evMax: 1024, evType: new Uint8Array(1024), evX: new Float32Array(1024), evY: new Float32Array(1024), evA: new Int32Array(1024),
      regAlive: new Int32Array(regs.length), regStart: new Int32Array(regs.length), regRouted: new Uint8Array(regs.length),
      regFig0: new Int32Array(regs.length), regFigN: new Int32Array(regs.length),
      sideActive: new Int32Array(2), sideHp0: new Float64Array(2)
    };
    // deploy: front rank (foot, pike), second (archer), rear (mage), wings (horse)
    var i = 0, laneH = FIELD.bottom - FIELD.top;
    for (s = 0; s < 2; s++) {
      var dir = s === 0 ? 1 : -1, front = -dir * 150, sideStart = i;   // x is measured from the centre line
      var groups = { front: [], second: [], rear: [], wing: [] };
      armies[s].forEach(function (g) { (g.role === 'archer' ? groups.second : g.role === 'mage' ? groups.rear : g.role === 'horse' ? groups.wing : groups.front).push(g); });
      if (!groups.front.length && groups.second.length) { groups.front = groups.second; groups.second = []; }
      var place = function (list, x, y0, y1) {
        if (!list.length) return;
        var weight = 0; list.forEach(function (g) { weight += g.figures; });
        var y = y0;
        list.forEach(function (g) {
          var h = (y1 - y0) * g.figures / weight, idx = regs.indexOf(g);
          b.regFig0[idx] = i; b.regFigN[idx] = g.figures; b.regStart[idx] = g.figures; b.regAlive[idx] = g.figures;
          b.valour[idx] = 0.82 + rnd(newRng(hashString(seed + '|valour|' + s + '|' + armies[s].indexOf(g)))) * 0.36;   // this regiment's day: a seeded roll, so no two battles are the same arithmetic
          placeBlock(b, i, g.figures, x, y + h / 2, dir, forms[s], rng, Math.max(20, h - 8));
          for (k = 0; k < g.figures; k++) {
            var R = ROLES[g.role];
            b.side[i] = s; b.role[i] = ROLE_IDS.indexOf(g.role); b.reg[i] = idx; b.slot[i] = i - sideStart;
            b.hpMax[i] = b.hp[i] = R.hp * g.rep * g.strength; b.cd[i] = Math.floor(rnd(rng) * R.cd); b.target[i] = -1; b.face[i] = dir;
            b.x[i] = clamp(b.x[i], 6 - FIELD.mid, FIELD.mid - 6); b.y[i] = clamp(b.y[i], FIELD.top + 4, FIELD.bottom - 4);
            i++;
          }
          y += h;
        });
      };
      var mid = (FIELD.top + FIELD.bottom) / 2, span = laneH * 0.86;
      var hasWing = groups.wing.length > 0, wingH = hasWing ? span * 0.2 : 0;
      place(groups.front, front, mid - span / 2 + wingH, mid + span / 2 - wingH);
      place(groups.second, front - dir * 70, mid - span / 2 + wingH, mid + span / 2 - wingH);
      place(groups.rear, front - dir * 130, mid - span / 2 + wingH + 20, mid + span / 2 - wingH - 20);
      if (hasWing) {
        var top = [], bot = []; groups.wing.forEach(function (g, q) { (q % 2 ? bot : top).push(g); });
        if (!bot.length && top.length > 0) { /* one horse regiment: split the flanks by alternating figures is not possible; put it on top */ }
        place(top, front - dir * 20, mid - span / 2, mid - span / 2 + wingH * 2);
        place(bot, front - dir * 20, mid + span / 2 - wingH * 2, mid + span / 2);
      }
    }
    for (i = 0; i < b.n; i++) b.sideHp0[b.side[i]] += b.hpMax[i];
    countSides(b);
    return b;
  }

  function countSides(b) {
    b.sideActive[0] = 0; b.sideActive[1] = 0;
    for (var i = 0; i < b.n; i++) if (b.state[i] === 0) b.sideActive[b.side[i]]++;
  }
  /** Fighting power of a side (hp-weighted, living and not routing). */
  function power(b, side) {
    var p = 0;
    for (var i = 0; i < b.n; i++) if (b.side[i] === side && b.state[i] === 0) p += b.hp[i] * (ROLES[ROLE_IDS[b.role[i]]].atk + 1);
    return p;
  }

  function emit(b, type, x, y, a) {
    if (b.evN >= b.evMax) return;
    var k = b.evN++; b.evType[k] = type; b.evX[k] = x; b.evY[k] = y; b.evA[k] = a;
  }
  var EV = { BLOW: 1, DEATH: 2, LOOSE: 3, ARROW_HIT: 4, ARROW_MISS: 5, CAST: 6, BURST: 7, ROUT: 8, CHARGE: 9 };

  /** Damage i deals to j by kind ('melee' | 'shot' | 'spell'). */
  function damage(b, i, j, kind) {
    var ra = ROLE_IDS[b.role[i]], rd = ROLE_IDS[b.role[j]], R = ROLES[ra], g = b.regs[b.reg[i]];
    var base = kind === 'shot' ? R.shot : kind === 'spell' ? R.spell : R.atk;
    var m = (MATCH[ra] && MATCH[ra][rd]) || 1;
    var fa = FORMS[b.forms[b.side[i]]], fd = FORMS[b.forms[b.side[j]]];
    var taken = kind === 'melee' ? (ra === 'horse' ? fd.taken.horse * fd.taken.melee : fd.taken.melee) : fd.taken[kind];
    var d = base * g.rep * g.strength * m * taken * b.valour[b.reg[i]];
    if (kind === 'melee') { d *= fa.melee; if (fa.beats === b.forms[b.side[j]]) d *= EDGE; else if (fd.beats === b.forms[b.side[i]]) d *= EDGE_GUARD; }
    // the charge: the first blow lands at 1.6x - except on pikes, which is the whole point of pikes
    if (kind === 'melee' && ra === 'horse' && !b.charged[i]) { if (rd !== 'pike') d *= 1.6; b.charged[i] = 1; }
    return d * (0.85 + rnd(b.rng) * 0.3);
  }
  /**
   * Damage is DEFERRED to the end of the frame so both armies strike simultaneously: a figure killed this frame still lands
   * its own blow this frame. (Measured: applying it at once handed every mirror battle to whichever side was processed
   * first - identical infantry armies in line went 100% to side 0.)
   */
  function hurt(b, j, d) {
    if (b.state[j] !== 0 && b.state[j] !== 2) return;
    b.pend[j] += d;
  }
  function applyDamage(b) {
    for (var j = 0; j < b.n; j++) {
      var d = b.pend[j]; if (d === 0) continue; b.pend[j] = 0;
      if (b.state[j] !== 0 && b.state[j] !== 2) continue;
      b.hp[j] -= d;
      if (b.hp[j] <= 0) {
        b.hp[j] = 0; if (b.state[j] === 0) b.sideActive[b.side[j]]--; b.state[j] = 1; b.deadAt[j] = b.frame; b.regAlive[b.reg[j]]--;
        emit(b, EV.DEATH, b.x[j], b.y[j], j);
      }
    }
  }

  var ENGAGE = 64;         // closer than this to its foe, a figure stops marching in rank and closes on him
  var SEP = 7.5;           // no two standing figures closer than this (friend or foe): lines form where armies meet
  var GRID = 16, GW = Math.ceil(816 / GRID) + 2, GH = Math.ceil(700 / GRID) + 2;
  /** Quantise to 1/256 px: sums of dyadic values are exact in float64, so the ORDER neighbours are visited cannot matter. */
  function q8(v) { return Math.round(v * 256) / 256; }
  /**
   * Push standing figures apart (spatial grid, zero allocation). Reads the start-of-frame positions and writes only into
   * nx/ny, and every push is quantised so its sum is exact, so the result does not depend on the order figures are visited:
   * a mirrored battle stays mirrored (the balance probe's mirror rows check it).
   */
  function separate(b) {
    var head = b.gridHead, next = b.gridNext, i, j, c, cx, cy, ox, oy;
    for (c = 0; c < head.length; c++) head[c] = -1;
    for (i = 0; i < b.n; i++) {
      if (b.state[i] !== 0 && b.state[i] !== 2) { next[i] = -2; continue; }
      cx = Math.floor((b.x[i] + FIELD.mid) / GRID) + 1; cy = Math.floor(b.y[i] / GRID) + 1;
      if (cx < 0) cx = 0; else if (cx >= GW) cx = GW - 1; if (cy < 0) cy = 0; else if (cy >= GH) cy = GH - 1;
      c = cy * GW + cx; next[i] = head[c]; head[c] = i;
    }
    for (i = 0; i < b.n; i++) {
      if (next[i] === -2) continue;
      cx = Math.floor((b.x[i] + FIELD.mid) / GRID) + 1; cy = Math.floor(b.y[i] / GRID) + 1;
      var px = 0, py = 0;
      for (oy = -1; oy <= 1; oy++) for (ox = -1; ox <= 1; ox++) {
        var gx = cx + ox, gy = cy + oy; if (gx < 0 || gy < 0 || gx >= GW || gy >= GH) continue;
        for (j = head[gy * GW + gx]; j >= 0; j = next[j]) {
          if (j === i) continue;
          var dx = b.x[i] - b.x[j], dy = b.y[i] - b.y[j], d2 = dx * dx + dy * dy;
          if (d2 >= SEP * SEP) continue;
          var d = Math.sqrt(d2);
          if (d < 1e-6) { dx = b.side[i] === 0 ? -1 : 1; dy = (b.slot[i] & 1) ? 0.5 : -0.5; d = Math.sqrt(dx * dx + dy * dy); }   // exactly stacked: part by side and parity
          var push = (SEP - d) * 0.35;
          px += q8(dx / d * push); py += q8(dy / d * push);
        }
      }
      b.nx[i] += px; b.ny[i] += py;
    }
  }

  /** Nearest fighting enemy of i (or -1). Squared distances, no allocation. */
  function nearestEnemy(b, i) {
    var best = -1, bd = 1e12, s = b.side[i], x = b.x[i], y = b.y[i];
    for (var j = 0; j < b.n; j++) {
      if (b.side[j] === s || b.state[j] !== 0) continue;
      var dx = b.x[j] - x, dy = b.y[j] - y, d = dx * dx + dy * dy;
      if (d < bd) { bd = d; best = j; }
    }
    return best;
  }

  function launch(b, kind, i, j, x1, y1, T) {
    for (var k = 0; k < b.pMax; k++) {
      if (b.plive[k]) continue;
      b.plive[k] = 1; b.pkind[k] = kind; b.pfrom[k] = i; b.pto[k] = j;
      b.px0[k] = b.x[i]; b.py0[k] = b.y[i] - 6; b.px1[k] = x1; b.py1[k] = y1; b.pt[k] = 0; b.pT[k] = T;
      if (k >= b.pn) b.pn = k + 1;
      return k;
    }
    return -1;
  }

  function landProjectile(b, k) {
    var i = b.pfrom[k], x = b.px1[k], y = b.py1[k], s = b.side[i], j = b.pto[k], q;
    if (b.pkind[k] === 1) {   // arrow
      var hit = -1;
      if (j >= 0 && b.state[j] !== 1 && b.state[j] !== 3) { var dx = b.x[j] - x, dy = b.y[j] - y; if (dx * dx + dy * dy < 16 * 16) hit = j; }
      if (hit < 0) { var bd = 12 * 12; for (q = 0; q < b.n; q++) { if (b.side[q] === s || (b.state[q] !== 0 && b.state[q] !== 2)) continue; var ex = b.x[q] - x, ey = b.y[q] - y, d = ex * ex + ey * ey; if (d < bd) { bd = d; hit = q; } } }
      if (hit >= 0) { hurt(b, hit, damage(b, i, hit, 'shot')); emit(b, EV.ARROW_HIT, x, y, hit); }
      else emit(b, EV.ARROW_MISS, x, y, k);
    } else {                  // spell burst
      var rad = 30;
      emit(b, EV.BURST, x, y, i);
      for (q = 0; q < b.n; q++) {
        if (b.side[q] === s || (b.state[q] !== 0 && b.state[q] !== 2)) continue;
        var fx = b.x[q] - x, fy = b.y[q] - y, dd = fx * fx + fy * fy;
        if (dd < rad * rad) hurt(b, q, damage(b, i, q, 'spell') * (1 - Math.sqrt(dd) / rad * 0.6));
      }
    }
    b.plive[k] = 0;
  }

  /** One frame. Returns the number of events written to b.ev* this frame. */
  function tick(b) {
    b.evN = 0;
    if (b.over) return 0;
    b.frame++;
    var f = b.frame, i, j, k;
    for (i = 0; i < b.n; i++) { b.nx[i] = b.x[i]; b.ny[i] = b.y[i]; }
    // projectiles
    for (k = 0; k < b.pn; k++) { if (!b.plive[k]) continue; if (++b.pt[k] >= b.pT[k]) landProjectile(b, k); }
    while (b.pn > 0 && !b.plive[b.pn - 1]) b.pn--;
    // soldiers
    for (i = 0; i < b.n; i++) {
      var st = b.state[i]; if (st === 1 || st === 3) continue;
      var role = ROLE_IDS[b.role[i]], R = ROLES[role], fm = FORMS[b.forms[b.side[i]]], dir = b.side[i] === 0 ? 1 : -1;
      if (b.act[i] < 60000) b.act[i]++;
      if (st === 2) {   // routing: run for the home edge
        b.nx[i] = b.x[i] - dir * R.speed * 1.5; b.face[i] = -dir;
        if (b.nx[i] < -FIELD.mid - 12 || b.nx[i] > FIELD.mid + 12) { b.state[i] = 3; }
        continue;
      }
      if (b.cd[i] > 0) b.cd[i]--;
      j = b.target[i];
      // staggered by the figure's place IN ITS OWN ARMY: staggering by the global index retargeted mirror figures on
      // different frames whenever side 0's size was not a multiple of 20 (measured: deterministic mixed mirrors 0/1)
      if (j < 0 || b.state[j] !== 0 || ((b.slot[i] + f) % 20) === 0) { j = nearestEnemy(b, i); b.target[i] = j; }
      if (j < 0) continue;
      var dx = b.x[j] - b.x[i], dy = b.y[j] - b.y[i], dist = Math.sqrt(dx * dx + dy * dy) || 0.001;
      b.face[i] = dx >= 0 ? 1 : -1;
      if (R.range > 0 && dist <= R.range && dist > 42) {
        if (b.cd[i] <= 0) {
          b.cd[i] = R.cd * (0.9 + rnd(b.rng) * 0.2); b.act[i] = 0;
          var spread = dist * 0.07;
          var tx = b.x[j] + (rnd(b.rng) - 0.5) * spread * 2, ty = b.y[j] + (rnd(b.rng) - 0.5) * spread;
          if (R.shot > 0) { launch(b, 1, i, j, tx, ty, Math.round(26 + dist / 7)); emit(b, EV.LOOSE, b.x[i], b.y[i], i); }
          else { launch(b, 2, i, j, b.x[j], b.y[j], 34); emit(b, EV.CAST, b.x[i], b.y[i], i); }
        }
        continue;
      }
      if (dist <= R.reach + 2) {
        if (b.cd[i] <= 0) {
          b.cd[i] = R.cd * (0.9 + rnd(b.rng) * 0.2); b.act[i] = 0;
          hurt(b, j, damage(b, i, j, 'melee')); emit(b, EV.BLOW, (b.x[i] + b.x[j]) / 2, (b.y[i] + b.y[j]) / 2 - 6, i);
        }
        continue;
      }
      var sp = R.speed * fm.speed;
      if (role === 'horse' && !b.charged[i] && dist < 140) { sp *= 1.5; if (dist > 120) emit(b, EV.CHARGE, b.x[i], b.y[i], i); }
      if (dist > ENGAGE && role !== 'horse') {
        // the approach: march STRAIGHT AHEAD as a body, drifting only gently toward the enemy's rank, so a regiment arrives
        // as a line and not as a stream (measured: steering every man at his nearest foe collapsed both armies into clumps)
        var ahead = dx >= 0 ? 1 : -1;
        b.nx[i] = b.x[i] + ahead * sp * 0.92; b.ny[i] = b.y[i] + (dy / dist) * sp * 0.22;
      } else { b.nx[i] = b.x[i] + dx / dist * sp; b.ny[i] = b.y[i] + dy / dist * sp * 0.8; }
    }
    separate(b);
    for (i = 0; i < b.n; i++) { if (b.ny[i] < FIELD.top) b.ny[i] = FIELD.top; else if (b.ny[i] > FIELD.bottom) b.ny[i] = FIELD.bottom; }
    // commit the moves: every figure decided from the same start-of-frame positions (order-free by construction)
    for (i = 0; i < b.n; i++) { b.x[i] = b.nx[i]; b.y[i] = b.ny[i]; }
    applyDamage(b);
    // morale, twice a second
    if ((f % 30) === 0) morale(b);
    // end
    if (b.sideActive[0] === 0 || b.sideActive[1] === 0) finish(b, b.sideActive[0] > 0 ? 0 : (b.sideActive[1] > 0 ? 1 : -1));
    else if (f >= b.timeLimit) { var p0 = power(b, 0), p1 = power(b, 1); finish(b, p0 > p1 * 1.15 ? 0 : (p1 > p0 * 1.15 ? 1 : -1)); }
    return b.evN;
  }

  /** A side's standing strength as a SHARE of what it brought (living, not routing, hit points / starting hit points). */
  function share(b, side) {
    var h = 0; for (var i = 0; i < b.n; i++) if (b.side[i] === side && b.state[i] === 0) h += b.hp[i];
    return b.sideHp0[side] > 0 ? h / b.sideHp0[side] : 0;
  }
  /**
   * ⛔ Morale compares SHARES, never raw power: MEASURED 2026-09-28, with hp x attack a horse counted as 2.2 pikes whatever
   * the pike's bonus against horse, so a pike wall that was winning (it dealt 8,368 damage to the riders' 5,223) believed it
   * was losing, broke, and lost 15 of 20. A share of one's own strength is blind to the match-up, which is the point.
   */
  function morale(b) {
    var p0 = share(b, 0), p1 = share(b, 1);
    for (var r = 0; r < b.regs.length; r++) {
      if (b.regRouted[r] || b.regAlive[r] <= 0) continue;
      var g = b.regs[r], frac = b.regAlive[r] / b.regStart[r], mine = g.side === 0 ? p0 : p1, theirs = g.side === 0 ? p1 : p0;
      if (frac < ROLES[g.role].rout && mine < theirs * 0.9 && rnd(b.rng) < 0.5) {
        b.regRouted[r] = 1;
        var i0 = b.regFig0[r], n = b.regFigN[r], cx = 0, cy = 0, c = 0;
        for (var i = i0; i < i0 + n; i++) if (b.state[i] === 0) { b.state[i] = 2; b.sideActive[b.side[i]]--; cx += b.x[i]; cy += b.y[i]; c++; }
        emit(b, EV.ROUT, c ? cx / c : 0, c ? cy / c : 0, r);
      }
    }
  }

  function finish(b, winner) {
    b.over = true; b.winner = winner;
    // routing figures still on the field when it ends count as fled
    for (var i = 0; i < b.n; i++) if (b.state[i] === 2) b.state[i] = 3;
  }

  /** Run to the end (or maxFrames). Returns the frame count. */
  function run(b, maxFrames) { var lim = maxFrames || b.timeLimit + 10; while (!b.over && b.frame < lim) tick(b); return b.frame; }

  /**
   * The outcome in SOLDIERS (not figures). Per regiment: count = survived + fled + dead exactly.
   * @returns {{winner:number, frames:number, sides:Array, regiments:Array}}
   */
  function result(b) {
    var regs = b.regs.map(function (g, r) {
      var alive = 0, fled = 0, i0 = b.regFig0[r], n = b.regFigN[r];
      for (var i = i0; i < i0 + n; i++) { if (b.state[i] === 0) alive++; else if (b.state[i] === 3 || b.state[i] === 2) fled++; }
      var survived = Math.min(g.count, Math.round(alive * g.rep)), gone = Math.min(g.count - survived, Math.round(fled * g.rep));
      return { name: g.name, role: g.role, side: g.side, count: g.count, survived: survived, fled: gone, dead: g.count - survived - gone, routed: !!b.regRouted[r] };
    });
    var sides = [0, 1].map(function (s) {
      var o = { count: 0, survived: 0, fled: 0, dead: 0 };
      regs.forEach(function (g) { if (g.side === s) { o.count += g.count; o.survived += g.survived; o.fled += g.fled; o.dead += g.dead; } });
      return o;
    });
    return { winner: b.winner, frames: b.frame, seconds: Math.round(b.frame / 60), forms: b.forms.slice(), sides: sides, regiments: regs };
  }

  /**
   * The enemy's formation when the battle asks for 'auto': read from its own make-up, then a seeded coin decides between
   * the two fits. It never looks at the player's choice.
   */
  function enemyFormation(regs, seed) {
    var n = { foot: 0, pike: 0, archer: 0, horse: 0, mage: 0 }, t = 0;
    normalizeArmy(regs, 1).forEach(function (g) { n[g.role] += g.count; t += g.count; });
    if (!t) return 'line';
    var st = newRng((seed >>> 0) ^ 0x9E3779B9), a, c;
    if ((n.archer + n.mage) / t > 0.45) { a = 'loose'; c = 'line'; }
    else if (n.horse / t > 0.3) { a = 'wedge'; c = 'line'; }
    else if (n.pike / t > 0.35) { a = 'square'; c = 'line'; }
    else { a = FORM_IDS[Math.floor(rnd(st) * 4)]; c = 'line'; }
    return rnd(st) < 0.7 ? a : c;
  }

  /* ------------------------------------------------------------------ heraldry for banners (drawn by WarhostDraw) */
  var TINCTURES = {
    metals: [{ id: 'or', hex: '#d9a92a' }, { id: 'argent', hex: '#ece6d6' }],
    colours: [{ id: 'gules', hex: '#b3261e' }, { id: 'azure', hex: '#1f4f9a' }, { id: 'vert', hex: '#2f7a3a' }, { id: 'purpure', hex: '#6a2f7e' }, { id: 'sable', hex: '#26221f' }, { id: 'tenne', hex: '#b5651d' }, { id: 'sanguine', hex: '#7a1f2b' }, { id: 'celeste', hex: '#6fa8d8' }]
  };
  var ORDINARIES = ['plain', 'pale', 'fess', 'bend', 'bendsinister', 'chevron', 'cross', 'saltire', 'perpale', 'perfess', 'quarterly', 'chief', 'bordure', 'pile', 'barry', 'paly'];
  var CHARGES = ['none', 'star', 'crescent', 'annulet', 'lozenge', 'roundel', 'crosslet', 'tower', 'sword', 'key', 'sun', 'bird', 'fleur', 'axe'];
  var SHAPES = ['swallowtail', 'square', 'pennon', 'gonfalon'];

  /**
   * A regiment's arms, derived from its name and side (the same name always gets the same banner). The rule of tincture is
   * kept: the charge and ordinary are always a metal on a colour or a colour on a metal.
   */
  function heraldry(name, side, salt) {
    var st = newRng(hashString('arms|' + name + '|' + (side | 0) + '|' + (salt || '')));
    var pick = function (a) { return a[Math.floor(rnd(st) * a.length)]; };
    var metalField = rnd(st) < 0.35, field = metalField ? pick(TINCTURES.metals) : pick(TINCTURES.colours);
    var other = metalField ? pick(TINCTURES.colours) : pick(TINCTURES.metals);
    var ordinary = pick(ORDINARIES), charge = pick(CHARGES);
    if (ordinary === 'plain' && charge === 'none') charge = pick(CHARGES.slice(1));
    var chargeT = ordinary === 'plain' || ordinary === 'bordure' || ordinary === 'chief' ? other : (rnd(st) < 0.5 ? other : (metalField ? pick(TINCTURES.colours) : pick(TINCTURES.metals)));
    return { field: field.hex, fieldId: field.id, other: other.hex, otherId: other.id, ordinary: ordinary, charge: charge, charge2: chargeT.hex, shape: pick(SHAPES), key: field.id + '/' + other.id + '/' + ordinary + '/' + charge };
  }

  var API = {
    VERSION: '1.0.0', ROLES: ROLES, ROLE_IDS: ROLE_IDS, MATCH: MATCH, FORMS: FORMS, FORM_IDS: FORM_IDS, EDGE: EDGE, FIELD: FIELD, EV: EV,
    CAP_PER_SIDE: CAP_PER_SIDE, TINCTURES: TINCTURES, ORDINARIES: ORDINARIES, CHARGES: CHARGES, SHAPES: SHAPES,
    hashString: hashString, newRng: newRng, rnd: rnd, normalizeArmy: normalizeArmy, newBattle: newBattle, tick: tick, run: run,
    result: result, power: power, enemyFormation: enemyFormation, heraldry: heraldry
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  return API;
})();
