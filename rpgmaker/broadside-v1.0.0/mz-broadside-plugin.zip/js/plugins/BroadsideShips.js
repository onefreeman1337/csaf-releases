/*:
 * @target MZ
 * @plugindesc Broadside 2/4 - the ships: any hull, rig, paint scheme and weathering, drawn at any size, with battle damage drawn into them. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * BroadsideShips.js - part of Broadside. Enable it with the other Broadside files (any order). It has no commands or
 * parameters of its own; Broadside.js reads it.
 *
 * The ship generator inside this file is a copy of the one in Shipwright (also by Core Systems Asset Factory), placed
 * under its own name so that owning both products is safe: nothing here reads or changes Shipwright's, and updating
 * one never moves the other.
 *
 * Every line of this plugin was written with AI assistance.
 */
/*
 * Provenance of the copied half (generated, do not hand-edit above the damage-layer marker):
 *   ShipwrightRender.js sha256 04d80478c4c2dfe6
 *   ShipwrightCorpus.js sha256 d971645708838249
 *   ShipwrightHull.js sha256 60a5d0fcfaa6ed81
 *   ShipwrightPortrait.js sha256 c93ab1d870dc315c
 */
//-----------------------------------------------------------------------------
// copied from ShipwrightRender.js (3 namespace references renamed)
//-----------------------------------------------------------------------------
//=============================================================================
// ShipwrightRender.js — Shipwright [1/5]
//=============================================================================
/* (Shipwright plugin header removed; this is a copy inside Broadside) */

var CSAF = CSAF || {};
CSAF.BroadsideShip = CSAF.BroadsideShip || {};

(function () {
  'use strict';

  const R = {};
  CSAF.BroadsideShip.Render = R;

  //---------------------------------------------------------------------------
  // Deterministic RNG. Never Math.random() in generation (wing §6 rule 2):
  // the same database must bind the same books forever, so screenshots reproduce.
  //---------------------------------------------------------------------------

  /**
   * mulberry32 — small, fast, deterministic.
   *
   * NOTE: a previous wing session suspected this generator of a warm-up bias and
   * nearly "fixed" it by discarding early outputs. That was MEASURED over 20,000
   * seeds and REFUTED (wing §21g-1): the first eight outputs give chi-square 2.1
   * on five buckets against 3.46 for outputs 100-108. Do not add a warm-up; it
   * would change every generated artefact and leave a false explanation behind.
   *
   * @param {number} seed Any 32-bit integer.
   * @returns {function(): number} Generator returning [0, 1).
   */
  R.rng = function (seed) {
    let a = seed >>> 0;
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  };

  /**
   * Stable string hash, so a book's seed comes from its own name and never from
   * its position in the database (inserting an item must not re-bind the shelf).
   * @param {string} s Source string.
   * @returns {number} 32-bit unsigned hash.
   */
  R.hash = function (s) {
    let h = 2166136261 >>> 0;
    const str = String(s == null ? '' : s);
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return h >>> 0;
  };

  //---------------------------------------------------------------------------
  // Colour
  //---------------------------------------------------------------------------

  /**
   * Rec. 601 luminance, the scale every separation rule in this file is stated in.
   * @param {number[]} c [r,g,b] 0-255.
   * @returns {number} Luminance 0-255.
   */
  R.lum = function (c) {
    return 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2];
  };

  /** @param {number} v @returns {number} v clamped to 0-255 and rounded. */
  R.clamp255 = function (v) {
    return v < 0 ? 0 : v > 255 ? 255 : Math.round(v);
  };

  /**
   * Mix two colours.
   * @param {number[]} a First colour.
   * @param {number[]} b Second colour.
   * @param {number} t 0 returns a, 1 returns b.
   * @returns {number[]} Mixed colour.
   */
  R.mix = function (a, b, t) {
    return [
      R.clamp255(a[0] + (b[0] - a[0]) * t),
      R.clamp255(a[1] + (b[1] - a[1]) * t),
      R.clamp255(a[2] + (b[2] - a[2]) * t),
    ];
  };

  /** @param {number[]} c Colour. @returns {string} CSS rgb() string. */
  R.css = function (c) {
    return 'rgb(' + R.clamp255(c[0]) + ',' + R.clamp255(c[1]) + ',' + R.clamp255(c[2]) + ')';
  };

  /**
   * How much luminance headroom exists in a direction. This is the number that
   * makes a "separate by N" assertion honest: on a near-white covering there may
   * be only ten levels below white, and demanding thirty is a FALSE RED, not a
   * defect (wing §22e-1, measured on Facet's diamond at luminance 244.9).
   *
   * @param {number[]} c Base colour.
   * @param {number} dir +1 toward white, -1 toward black.
   * @returns {number} Luminance levels available, 0-255.
   */
  R.headroom = function (c, dir) {
    const l = R.lum(c);
    return dir > 0 ? 255 - l : l;
  };

  /**
   * ⛔ THE RULE THIS PRODUCT LIVES OR DIES BY (wing §22e / §22e-1).
   *
   * Any tint whose job is to make something VISIBLE must state its separation in
   * ABSOLUTE terms and solve for it. `shade(x, 1.22)` is a hard-coded contrast
   * RATIO, so separation is proportional to the base: measured across a twelve-seal
   * plate it moved a bright base 27 luminance levels and a dark one only 11, and
   * the device on the darkest seal could not be made out at all.
   *
   * Gold tooling on pale vellum and gold tooling on black goatskin must BOTH read.
   *
   * @param {number[]} base Colour the mark sits on.
   * @param {number} dir +1 lighter, -1 darker.
   * @param {number} minDelta Luminance separation required.
   * @returns {number[]} A colour separated from base by min(minDelta, headroom).
   */
  R.relief = function (base, dir, minDelta) {
    const target = dir > 0 ? [255, 255, 255] : [0, 0, 0];
    const room = R.headroom(base, dir);
    const want = Math.min(minDelta, room);
    if (want <= 0) return base.slice();
    // proportional floor kept so bright bases still get a generous, natural relief
    let lo = 0;
    let hi = 1;
    for (let i = 0; i < 24; i++) {
      const mid = (lo + hi) / 2;
      const got = Math.abs(R.lum(R.mix(base, target, mid)) - R.lum(base));
      if (got < want) lo = mid; else hi = mid;
    }
    return R.mix(base, target, hi);
  };

  /**
   * Pick the most readable ink from candidates for a given ground.
   * Never hard-code an ink: card titles once shipped dark-grey on dark-grey
   * across four whole decks with every mechanical check green (wing §22e).
   *
   * @param {number[]} bg Ground colour.
   * @param {number[][]} candidates Inks to choose between.
   * @returns {number[]} The candidate furthest from bg in luminance.
   */
  R.pickContrast = function (bg, candidates) {
    if (!candidates || !candidates.length) throw new Error('pickContrast: empty candidate set');
    const bl = R.lum(bg);
    let best = candidates[0];
    let bestD = -1;
    for (let i = 0; i < candidates.length; i++) {
      const d = Math.abs(R.lum(candidates[i]) - bl);
      if (d > bestD) { bestD = d; best = candidates[i]; }
    }
    return best;
  };

  /**
   * Perceptual-ish distance between two colours, used by the collision sweep.
   * §22b-2: once an eye finds one collision, compute the metric over the whole
   * corpus and read the ranked list — the eye finds the pair it lands on, the
   * sweep finds the pair that is actually worst.
   *
   * @param {number[]} a First colour.
   * @param {number[]} b Second colour.
   * @returns {number} Weighted RGB distance.
   */
  R.dist = function (a, b) {
    const dr = a[0] - b[0];
    const dg = a[1] - b[1];
    const db = a[2] - b[2];
    // weight green like the eye does
    return Math.sqrt(2 * dr * dr + 4 * dg * dg + 3 * db * db);
  };

  /**
   * @param {number[]} c Colour.
   * @param {number} a Alpha 0-1.
   * @returns {string} CSS rgba() string.
   */
  R.rgba = function (c, a) {
    return 'rgba(' + R.clamp255(c[0]) + ',' + R.clamp255(c[1]) + ','
      + R.clamp255(c[2]) + ',' + a + ')';
  };

  /**
   * Choose an ink that is guaranteed to separate from the ground it is struck
   * on, while keeping the ink's own hue.
   *
   * ⛔ THIS IS §22e's RULE APPLIED TO A NAMED INK RATHER THAN A CHOSEN ONE.
   * `pickContrast` picks the best of several inks; this one keeps the ink you
   * asked for — gold has to stay gold — and moves its LUMINANCE away from the
   * ground until the separation exists. Paper wrapper sits at luminance 158.6
   * and this corpus's gold at 155.0, a separation of 3.6: without this guard a
   * gold-tooled wrapper is a solid rectangle of one tone.
   *
   * @param {number[]} ink Ink colour to preserve.
   * @param {number[]} ground Colour it is struck on.
   * @param {number} minDelta Luminance separation required.
   * @returns {number[]} The ink, moved away from ground if it had to be.
   */
  R.separateFrom = function (ink, ground, minDelta) {
    const li = R.lum(ink);
    const lg = R.lum(ground);
    if (Math.abs(li - lg) >= minDelta) return ink.slice();
    // Move to whichever side of the GROUND has more room. Deciding by the ink's
    // own headroom is wrong: a mid ink on a near-white ground has room in both
    // directions, but only one of them gets away from the ground.
    const dir = (255 - lg) >= lg ? 1 : -1;
    const targetL = dir > 0 ? Math.min(255, lg + minDelta) : Math.max(0, lg - minDelta);
    return R.relief(ink, targetL > li ? 1 : -1, Math.abs(targetL - li));
  };

  /**
   * How much separation `separateFrom` could POSSIBLY deliver for this pair.
   *
   * ⚠️ Wing §22e-1, measured on Facet's diamond: asserting a flat 30 levels goes
   * red on a base with only 10 levels of headroom, and that is arithmetic rather
   * than a defect. A test asserts `min(delta, achievable(...))` — and pairs it
   * with a mid-grey control demanding the FULL delta, so "as much as exists"
   * cannot become a loophole excusing a function that has stopped working.
   *
   * @param {number[]} ink Ink colour.
   * @param {number[]} ground Ground colour.
   * @param {number} minDelta Separation asked for.
   * @returns {number} Separation actually achievable, 0-255.
   */
  R.achievableSeparation = function (ink, ground, minDelta) {
    const li = R.lum(ink);
    const lg = R.lum(ground);
    if (Math.abs(li - lg) >= minDelta) return Math.abs(li - lg);
    const dir = (255 - lg) >= lg ? 1 : -1;
    const targetL = dir > 0 ? Math.min(255, lg + minDelta) : Math.max(0, lg - minDelta);
    const moveDir = targetL > li ? 1 : -1;
    const reach = Math.min(Math.abs(targetL - li), R.headroom(ink, moveDir));
    return Math.abs((li + moveDir * reach) - lg);
  };

  //---------------------------------------------------------------------------
  // Typography — the product's, never the engine's.
  //
  // ⛔ Wing §7's Gate 1 checklist names MZ's default font FIRST: "the single
  // loudest 'this is RPG Maker' signal", and §15a records that NO gate in this
  // factory can catch it — a scene set entirely in $gameSystem.mainFontFace()
  // passed every geometric and pixel check. Nothing in Shipwright ever calls it.
  //
  // A bound volume is described the way a bookseller's catalogue describes one:
  // an old-style serif for the title, and a small even face for the collation
  // line. `_probe/font_check.js` proves the chosen face actually RESOLVES by
  // measuring glyph advances — a family name in a string is a request, not a
  // typeface.
  //---------------------------------------------------------------------------

  /** @type {string} Old-style serif for titles and spine labels. */
  R.FONT_DISPLAY = 'Constantia, "Palatino Linotype", "Book Antiqua", '
    + 'Cambria, Georgia, "Times New Roman", serif';

  /** @type {string} Even, narrow face for the collation line and small caps. */
  R.FONT_TECH = '"Segoe UI Semilight", Corbel, Candara, "Gill Sans MT", '
    + '"Trebuchet MS", "Segoe UI", sans-serif';

  //---------------------------------------------------------------------------
  // The op recorder.
  //
  // Every drawing call in this product goes through one of these. With a real
  // canvas context it draws; with `null` it records COUNTS only, which is how
  // the headless suite can assert that a mark was actually issued.
  //
  // ⚠️ And a count is exactly as far as it goes. Wing §17c-1: an op counter
  // proves a call happened, never that a pixel changed — three hachures were
  // counted, built and stroked in the same ink as the fill they sat on, and the
  // render was a plain triangle. The counts catch a MISSING call; only the
  // separation rules above and a rendered PNG catch an INVISIBLE one.
  //---------------------------------------------------------------------------

  /**
   * @param {CanvasRenderingContext2D|null} ctx Target context, or null to count only.
   * @returns {object} Recorder.
   */
  R.Recorder = function (ctx) {
    const n = { path: 0, fill: 0, stroke: 0, text: 0, clip: 0, poly: 0 };
    const rec = {
      ctx: ctx,
      counts: function () {
        return { path: n.path, fill: n.fill, stroke: n.stroke, text: n.text, clip: n.clip, poly: n.poly };
      },
      save: function () { if (ctx) ctx.save(); },
      restore: function () { if (ctx) ctx.restore(); },
      begin: function () { n.path++; if (ctx) ctx.beginPath(); },
      moveTo: function (x, y) { if (ctx) ctx.moveTo(x, y); },
      lineTo: function (x, y) { if (ctx) ctx.lineTo(x, y); },
      quadTo: function (cx, cy, x, y) { if (ctx) ctx.quadraticCurveTo(cx, cy, x, y); },
      bezTo: function (a, b, c, d, x, y) { if (ctx) ctx.bezierCurveTo(a, b, c, d, x, y); },
      arc: function (cx, cy, r, a0, a1, ccw) { if (ctx) ctx.arc(cx, cy, r, a0, a1, ccw); },
      ellipse: function (cx, cy, rx, ry, rot) {
        if (ctx) ctx.ellipse(cx, cy, rx, ry, rot || 0, 0, Math.PI * 2);
      },
      close: function () { if (ctx) ctx.closePath(); },
      clip: function () { n.clip++; if (ctx) ctx.clip(); },
      fill: function (style) { n.fill++; if (ctx) { ctx.fillStyle = style; ctx.fill(); } },
      stroke: function (style, w) {
        n.stroke++;
        if (ctx) { ctx.strokeStyle = style; ctx.lineWidth = w; ctx.stroke(); }
      },
      /**
       * Fill one closed polygon in one flat colour.
       * @param {number[][]} pts Screen-space [x,y] pairs.
       * @param {string} style CSS fill.
       */
      poly: function (pts, style) {
        n.poly++; n.path++; n.fill++;
        if (!ctx) return;
        ctx.beginPath();
        ctx.moveTo(pts[0][0], pts[0][1]);
        for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
        ctx.closePath();
        ctx.fillStyle = style;
        ctx.fill();
      },
      /**
       * Build a polygon path without filling it, so a caller can clip to it.
       * @param {number[][]} pts Screen-space [x,y] pairs.
       */
      polyPath: function (pts) {
        n.path++;
        if (!ctx) return;
        ctx.beginPath();
        ctx.moveTo(pts[0][0], pts[0][1]);
        for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
        ctx.closePath();
      },
      /**
       * Linear gradient fill across the current path.
       * @param {number[]} p0 Start [x,y].
       * @param {number[]} p1 End [x,y].
       * @param {Array<Array>} stops [[offset, cssColour], ...].
       */
      fillGradient: function (p0, p1, stops) {
        n.fill++;
        if (!ctx) return;
        const g = ctx.createLinearGradient(p0[0], p0[1], p1[0], p1[1]);
        for (let i = 0; i < stops.length; i++) g.addColorStop(stops[i][0], stops[i][1]);
        ctx.fillStyle = g;
        ctx.fill();
      },
      /** @param {number} a Global alpha 0-1. */
      alpha: function (a) { if (ctx) ctx.globalAlpha = a; },
      /**
       * Draw ONTO a receding face in that face's own pixel space.
       *
       * ⭐ THE SCALE IS DELIBERATELY LEFT AT ~1 AND THAT IS THE WHOLE POINT. The
       * obvious transform maps the unit square onto the parallelogram, which
       * scales x by the face's WIDTH and y by its HEIGHT — so on a board 138px
       * wide and 196px tall, a struck device would come out squashed by 0.70 and
       * every stroke width would mean something different on every book. Mapping
       * from face PIXELS instead leaves only the shear and rotation the
       * projection actually calls for, so a device drawn at radius r is still
       * radius r, and the same corpus can be struck on a spine and on a board.
       *
       * @param {number[][]} q Face quad [p00, p10, p11, p01].
       * @param {number} wpx Face width in its own pixels.
       * @param {number} hpx Face height in its own pixels.
       */
      pushFace: function (q, wpx, hpx) {
        if (!ctx) return;
        ctx.save();
        const ax = (q[1][0] - q[0][0]) / wpx;
        const ay = (q[1][1] - q[0][1]) / wpx;
        const cx = (q[3][0] - q[0][0]) / hpx;
        const cy = (q[3][1] - q[0][1]) / hpx;
        ctx.transform(ax, ay, cx, cy, q[0][0], q[0][1]);
      },
      /** Undo the most recent pushFace. */
      popFace: function () { if (ctx) ctx.restore(); },
      /**
       * Draw text.
       * @param {string} s The string.
       * @param {number} x Left edge.
       * @param {number} y Baseline.
       * @param {object} o {size, family, colour, weight, align}.
       */
      text: function (s, x, y, o) {
        n.text++;
        if (!ctx) return;
        ctx.font = (o.weight || '') + ' ' + o.size + 'px ' + (o.family || R.FONT_DISPLAY);
        ctx.fillStyle = typeof o.colour === 'string' ? o.colour : R.css(o.colour);
        ctx.textAlign = o.align || 'left';
        ctx.textBaseline = 'alphabetic';
        ctx.fillText(s, x, y);
      },
      /**
       * Measure a string in a given face.
       * @param {string} s The string.
       * @param {object} o {size, family, weight}.
       * @returns {number} Width in px, or an estimate when there is no context.
       */
      measure: function (s, o) {
        if (!ctx) return String(s).length * o.size * 0.5;
        ctx.font = (o.weight || '') + ' ' + o.size + 'px ' + (o.family || R.FONT_DISPLAY);
        return ctx.measureText(String(s)).width;
      },
    };
    return rec;
  };

  //---------------------------------------------------------------------------
  // Letter-spaced text and the fitter.
  //---------------------------------------------------------------------------

  /**
   * Width of a tracked (letter-spaced) string.
   * @param {object} rec Recorder.
   * @param {string} s The string.
   * @param {object} o {size, family, track}.
   * @returns {number} Width in px.
   */
  R.trackedWidth = function (rec, s, o) {
    const str = String(s);
    const track = o.track || 0;
    let w = 0;
    for (let i = 0; i < str.length; i++) w += rec.measure(str[i], o) + track;
    return w - (str.length ? track : 0);
  };

  /**
   * Draw a tracked string, left-aligned at x with baseline y.
   * @param {object} rec Recorder.
   * @param {string} s The string.
   * @param {number} x Left edge.
   * @param {number} y Baseline.
   * @param {object} o {size, family, colour, track, weight}.
   * @returns {number} The width drawn.
   */
  R.tracked = function (rec, s, x, y, o) {
    const str = String(s);
    const track = o.track || 0;
    let cx = x;
    for (let i = 0; i < str.length; i++) {
      rec.text(str[i], cx, y, o);
      cx += rec.measure(str[i], o) + track;
    }
    return cx - x - (str.length ? track : 0);
  };

  /**
   * Fit a string into a width.
   *
   * ⚠️ Wing §22f: a fitter that can fail to fit MUST say so. `fitTracked` once
   * shrank to its minimum and returned a still-too-wide result which the caller
   * drew anyway, and "SEVEN OF WANDS" shipped as "SEVEN OF WAND". This returns
   * `fits`, and every caller in this product reads it.
   *
   * @param {object} rec Recorder.
   * @param {string} s The string.
   * @param {number} maxW Available width.
   * @param {object} o {size, family, track} — the STARTING style.
   * @param {number} minSize Smallest size allowed.
   * @returns {{size:number, track:number, width:number, fits:boolean}}
   */
  R.fitTracked = function (rec, s, maxW, o, minSize) {
    const floor = minSize || 9;
    let size = o.size;
    let track = o.track || 0;
    let w = R.trackedWidth(rec, s, { size: size, family: o.family, track: track });
    // surrender tracking first — it is the cheapest thing to lose
    while (w > maxW && track > 0) {
      track = Math.max(0, track - 0.3);
      w = R.trackedWidth(rec, s, { size: size, family: o.family, track: track });
    }
    while (w > maxW && size > floor) {
      size -= 1;
      w = R.trackedWidth(rec, s, { size: size, family: o.family, track: track });
    }
    return { size: size, track: track, width: w, fits: w <= maxW };
  };

  //---------------------------------------------------------------------------
  // Geometry helpers
  //---------------------------------------------------------------------------

  /**
   * Rounded rectangle path (does not fill or stroke).
   * ⚠️ `arcTo` throws on a negative radius (wing §8 trap 3) — clamped here so no
   * caller has to remember.
   * @param {object} rec Recorder.
   * @param {number} x Left. @param {number} y Top.
   * @param {number} w Width. @param {number} h Height. @param {number} r Radius.
   */
  R.roundRect = function (rec, x, y, w, h, r) {
    const rr = Math.max(0, Math.min(r, w / 2, h / 2));
    rec.begin();
    rec.moveTo(x + rr, y);
    rec.lineTo(x + w - rr, y);
    rec.quadTo(x + w, y, x + w, y + rr);
    rec.lineTo(x + w, y + h - rr);
    rec.quadTo(x + w, y + h, x + w - rr, y + h);
    rec.lineTo(x + rr, y + h);
    rec.quadTo(x, y + h, x, y + h - rr);
    rec.lineTo(x, y + rr);
    rec.quadTo(x, y, x + rr, y);
    rec.close();
  };

  /**
   * Linearly interpolate two screen points.
   * @param {number[]} a [x,y]. @param {number[]} b [x,y]. @param {number} t 0..1.
   * @returns {number[]} [x,y].
   */
  R.lerp2 = function (a, b, t) {
    return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
  };

  /**
   * Bilinear point inside a quad given as [p00, p10, p11, p01].
   * The whole volume renderer is written in these coordinates, so a board, its
   * grain, its tooling and its furniture cannot disagree about where the board is.
   * @param {number[][]} q Quad corners.
   * @param {number} u 0..1 across (p00 -> p10).
   * @param {number} v 0..1 down (p00 -> p01).
   * @returns {number[]} [x,y].
   */
  R.quadPoint = function (q, u, v) {
    const top = R.lerp2(q[0], q[1], u);
    const bot = R.lerp2(q[3], q[2], u);
    return R.lerp2(top, bot, v);
  };

  /**
   * Sub-quad of a quad, in the parent's own uv coordinates.
   * @param {number[][]} q Parent quad.
   * @param {number} u0 @param {number} v0 @param {number} u1 @param {number} v1
   * @returns {number[][]} [p00, p10, p11, p01].
   */
  R.subQuad = function (q, u0, v0, u1, v1) {
    return [
      R.quadPoint(q, u0, v0), R.quadPoint(q, u1, v0),
      R.quadPoint(q, u1, v1), R.quadPoint(q, u0, v1),
    ];
  };
})();

/* Under Node this lets the suite and the probes require the SHIPPED file rather
 * than a copy, which is the only way a test can be about the product. In MZ
 * `module` does not exist and the line is skipped. */

//-----------------------------------------------------------------------------
// copied from ShipwrightCorpus.js (3 namespace references renamed)
//-----------------------------------------------------------------------------
//=============================================================================
// ShipwrightCorpus.js — Shipwright [2/5]
//=============================================================================
/* (Shipwright plugin header removed; this is a copy inside Broadside) */

var CSAF = CSAF || {};
CSAF.BroadsideShip = CSAF.BroadsideShip || {};

(function () {
  'use strict';

  const C = {};
  CSAF.BroadsideShip.Corpus = C;

  //===========================================================================
  // 1. HULL CLASSES.
  //
  // ⛔ EACH ONE IS A DIFFERENT SILHOUETTE, NOT A DIFFERENT SET OF NUMBERS.
  // Wing §21a: Vista's `cave` rendered as an open starry sky because it was a
  // RECOLOUR of `forest` — "check that variants differ in STRUCTURE, not only
  // parameters". A hull class earns its place by changing the OUTLINE: where
  // the sheer is lowest, how much the ends rake, whether the stern is a square
  // transom or a double-ended point, how deep the forefoot cuts.
  //
  // The parameters are the real ones a draughtsman would loft from, and they
  // are named as such so the source reads like a shipwright wrote it:
  //   freeboard  deck height above the load waterline, / length on deck
  //   draft      depth below the waterline, / length on deck
  //   sheerFwd   rise of the deck line toward the stem, x freeboard
  //   sheerAft   rise of the deck line toward the sternpost, x freeboard
  //   low        where along the length the deck line is lowest
  //   stemRake   forward lean of the stem, / length on deck
  //   sternRake  aft lean of the sternpost, / length on deck
  //   drag       how much deeper the keel runs aft than forward
  //   endsPower  how sharply the bottom sweeps up at the ends (fine vs full)
  //
  // ⛔ AND THREE FIELDS THAT ARE NOT LOFTING PARAMETERS AT ALL — `rudder`,
  // `shields` and `stemHead` — EXIST BECAUSE PROPORTION IS NOT ENOUGH.
  //
  // MEASURED on the pass-8 contact sheet: the cog, the longship and the great
  // hulk read as the same picture. All three are medieval, so all three draw
  // from the same three-rig pool, and what separates them in the table is
  // freeboard, endsPower and rake — i.e. PROPORTION. Wing §22a-5 is explicit
  // that proportion is the first thing to go at reading size, and §22a-2c that
  // the eye assigns a shape to a part by POSITION FIRST and geometry second.
  // Four passes of reshaping a hull that is already correct is the documented
  // way to waste a session.
  //
  // So each of the three gets a mark in a position NOTHING ELSE OCCUPIES, and
  // each mark is real naval history rather than invented decoration:
  //   cog       a STERN RUDDER on a straight sternpost — the cog's actual
  //             historical innovation, and a blade hung outside the after
  //             outline where no other hull has anything at all
  //   longship  a SIDE RUDDER on the quarter, a row of SHIELDS along the
  //             sheer, and a CARVED STEM HEAD. No other hull is allowed
  //             shields, so the row alone settles it
  //   hulk      a SIDE RUDDER, plus the castles it already declares
  // `junk` takes a stern rudder too (it is the other famous early user) and
  // `galley` a side rudder; both are already separated by rig and hull, so
  // these are consistency rather than differentiation.
  //===========================================================================

  /**
   * @type {Array<object>} The hull classes.
   */
  C.HULLS = [
    {
      id: 'cutter', name: 'Cutter',
      bowsprit: 0.34, forecastle: false,
      guns: true,
      freeboard: 0.054, draft: 0.088, sheerFwd: 0.62, sheerAft: 0.22, low: 0.66,
      stemRake: 0.016, sternRake: -0.046, drag: 0.62, endsPower: 1.9,
      stern: 'transom', decks: 1, era: 'age-of-sail',
      note: 'Small, fine, one deck. A steep drag aft and a nearly plumb stem.',
    },
    {
      id: 'sloop', name: 'Sloop',
      bowsprit: 0.15, forecastle: false,
      guns: true,
      freeboard: 0.068, draft: 0.072, sheerFwd: 0.46, sheerAft: 0.38, low: 0.58,
      stemRake: 0.042, sternRake: -0.020, drag: 0.34, endsPower: 2.4,
      stern: 'transom', decks: 1, era: 'age-of-sail',
    },
    {
      id: 'ketch', name: 'Ketch',
      bowsprit: 0.13, forecastle: false,
      guns: false,
      freeboard: 0.084, draft: 0.062, sheerFwd: 0.3, sheerAft: 0.36, low: 0.5,
      stemRake: 0.028, sternRake: 0.006, drag: 0.08, endsPower: 3.6,
      stern: 'counter', decks: 1, era: 'age-of-sail',
    },
    {
      id: 'brig', name: 'Brig',
      bowsprit: 0.185, forecastle: false,
      guns: true,
      freeboard: 0.080, draft: 0.068, sheerFwd: 0.44, sheerAft: 0.50, low: 0.56,
      stemRake: 0.058, sternRake: -0.010, drag: 0.24, endsPower: 2.7,
      stern: 'counter', decks: 1, era: 'age-of-sail',
    },
    {
      id: 'schooner', name: 'Schooner',
      bowsprit: 0.225, forecastle: false,
      guns: false,
      freeboard: 0.064, draft: 0.066, sheerFwd: 0.36, sheerAft: 0.42, low: 0.54,
      stemRake: 0.070, sternRake: -0.038, drag: 0.46, endsPower: 2.1,
      stern: 'counter', decks: 1, era: 'age-of-sail',
      note: 'Long and low with a raking stem — the fastest-looking hull here.',
    },
    {
      id: 'barque', name: 'Barque',
      bowsprit: 0.19, forecastle: false,
      guns: false,
      freeboard: 0.092, draft: 0.074, sheerFwd: 0.26, sheerAft: 0.32, low: 0.52,
      stemRake: 0.036, sternRake: -0.022, drag: 0.06, endsPower: 3.8,
      stern: 'counter', decks: 2, era: 'age-of-sail',
    },
    {
      id: 'frigate', name: 'Frigate',
      bowsprit: 0.2, forecastle: false,
      guns: true,
      freeboard: 0.094, draft: 0.072, sheerFwd: 0.42, sheerAft: 0.54, low: 0.56,
      stemRake: 0.062, sternRake: -0.006, drag: 0.18, endsPower: 3.1,
      stern: 'counter', decks: 2, era: 'age-of-sail',
      note: 'A full gunport row on the wale and a quarter gallery aft.',
    },
    {
      id: 'ship-of-the-line', name: 'Ship of the Line',
      bowsprit: 0.195, forecastle: false,
      guns: true,
      freeboard: 0.112, draft: 0.076, sheerFwd: 0.40, sheerAft: 0.58, low: 0.56,
      stemRake: 0.056, sternRake: -0.004, drag: 0.14, endsPower: 3.4,
      stern: 'counter', decks: 3, era: 'age-of-sail',
      note: 'The tallest freeboard in the corpus and three tiers of gunports.',
    },
    {
      id: 'galleon', name: 'Galleon',
      bowsprit: 0.17, forecastle: false,
      guns: true,
      freeboard: 0.104, draft: 0.074, sheerFwd: 0.62, sheerAft: 1.28, low: 0.48,
      stemRake: 0.086, sternRake: 0.020, drag: 0.30, endsPower: 2.8,
      stern: 'castle', decks: 2, era: 'renaissance',
      note: 'The towering aftercastle is the whole silhouette — sheerAft is the '
        + 'largest in the corpus by a factor of two.',
    },
    {
      id: 'carrack', name: 'Carrack',
      bowsprit: 0.12, forecastle: true,
      guns: false,
      freeboard: 0.098, draft: 0.078, sheerFwd: 1.05, sheerAft: 1.44, low: 0.50,
      stemRake: 0.070, sternRake: 0.034, drag: 0.22, endsPower: 2.3,
      stern: 'castle', decks: 2, era: 'renaissance',
      note: 'Castles at BOTH ends — the only hull whose forward sheer rivals '
        + 'its after sheer, which is what tells it from the galleon.',
    },
    {
      id: 'cog', name: 'Cog',
      bowsprit: 0.055, forecastle: false,
      guns: false, rudder: 'stern',
      freeboard: 0.090, draft: 0.062, sheerFwd: 0.80, sheerAft: 0.86, low: 0.50,
      stemRake: 0.120, sternRake: 0.110, drag: 0.06, endsPower: 1.6,
      stern: 'straight', decks: 1, era: 'medieval',
      note: 'Straight raking stem AND sternpost, nearly flat bottom. A slab.',
    },
    {
      id: 'longship', name: 'Longship',
      bowsprit: 0.02, forecastle: false,
      guns: false, rudder: 'side', shields: true, stemHead: 'carved',
      freeboard: 0.042, draft: 0.040, sheerFwd: 0.96, sheerAft: 0.96, low: 0.50,
      stemRake: 0.088, sternRake: 0.088, drag: 0.00, endsPower: 1.9,
      stern: 'double', decks: 1, era: 'medieval',
      note: 'The only symmetric hull, and the only double-ender. Almost no '
        + 'freeboard — it reads as a blade on the water.',
    },
    {
      id: 'xebec', name: 'Xebec',
      bowsprit: 0.24, forecastle: false,
      guns: true,
      freeboard: 0.058, draft: 0.058, sheerFwd: 0.44, sheerAft: 0.72, low: 0.52,
      stemRake: 0.150, sternRake: -0.052, drag: 0.38, endsPower: 2.0,
      stern: 'counter', decks: 1, era: 'age-of-sail',
      note: 'An enormous overhanging beak forward and a projecting stern — the '
        + 'most extreme stemRake in the corpus.',
    },
    {
      id: 'junk', name: 'Junk',
      bowsprit: 0.03, forecastle: false,
      guns: false, rudder: 'stern',
      freeboard: 0.086, draft: 0.050, sheerFwd: 0.58, sheerAft: 1.10, low: 0.44,
      stemRake: -0.010, sternRake: 0.062, drag: 0.00, endsPower: 1.4,
      stern: 'transom-high', decks: 1, era: 'medieval',
      note: 'Blunt at both ends with a high square stern and no forefoot — the '
        + 'only hull with a NEGATIVE stem rake.',
    },
    {
      id: 'galley', name: 'Galley',
      bowsprit: 0.06, forecastle: false,
      guns: false, rudder: 'side',
      freeboard: 0.038, draft: 0.036, sheerFwd: 0.34, sheerAft: 0.68, low: 0.58,
      stemRake: 0.190, sternRake: -0.026, drag: 0.10, endsPower: 1.7,
      stern: 'counter', decks: 1, era: 'renaissance',
      note: 'Long, low and beaked. Lowest freeboard and longest ram forward.',
    },
    {
      id: 'hulk', name: 'Great Hulk',
      bowsprit: 0.07, forecastle: true,
      guns: false, rudder: 'side',
      freeboard: 0.106, draft: 0.084, sheerFwd: 0.70, sheerAft: 0.92, low: 0.52,
      stemRake: 0.028, sternRake: 0.014, drag: 0.12, endsPower: 4.2,
      stern: 'castle', decks: 2, era: 'medieval',
      note: 'Very full ends — endsPower is the highest here, so the bottom '
        + 'stays deep almost to the posts and the hull reads as a tub.',
    },
  ];

  //===========================================================================
  // 2. RIG PLANS.
  //
  // A rig is a list of masts. Each mast declares where it stands along the
  // length, how tall it is, and what it carries. `sail` is the KIND, and the
  // kinds are genuinely different pictures rather than different sizes:
  //   square  a bellied quadrilateral hung from a yard
  //   gaff    a four-sided fore-and-aft sail bent to a spar at its head
  //   lateen  a huge triangle on a steeply-raked yard crossing the mast
  //   lug     a four-sided sail on a yard slung off-centre
  //===========================================================================

  /**
   * @type {Array<object>} The rig plans.
   */
  C.RIGS = [
    {
      id: 'ship', name: 'Ship rig',
      masts: [
        { at: 0.26, h: 1.02, sail: 'square', yards: 3 },
        { at: 0.50, h: 1.16, sail: 'square', yards: 3 },
        { at: 0.75, h: 0.92, sail: 'square', yards: 2, spanker: true },
      ],
      jibs: 2, staysails: true,
    },
    {
      id: 'barque', name: 'Barque rig',
      masts: [
        { at: 0.26, h: 1.00, sail: 'square', yards: 3 },
        { at: 0.50, h: 1.10, sail: 'square', yards: 3 },
        { at: 0.76, h: 0.86, sail: 'gaff', yards: 0 },
      ],
      jibs: 2, staysails: true,
    },
    {
      id: 'brig', name: 'Brig rig',
      masts: [
        { at: 0.30, h: 0.98, sail: 'square', yards: 3 },
        { at: 0.62, h: 1.06, sail: 'square', yards: 3, spanker: true },
      ],
      jibs: 2, staysails: true,
    },
    {
      id: 'brigantine', name: 'Brigantine rig',
      masts: [
        { at: 0.30, h: 0.96, sail: 'square', yards: 3 },
        { at: 0.63, h: 1.04, sail: 'gaff', yards: 0 },
      ],
      jibs: 2, staysails: true,
    },
    {
      id: 'schooner', name: 'Schooner rig',
      masts: [
        { at: 0.32, h: 0.94, sail: 'gaff', yards: 0 },
        { at: 0.66, h: 1.04, sail: 'gaff', yards: 0 },
      ],
      jibs: 2, staysails: false,
    },
    {
      id: 'ketch', name: 'Ketch rig',
      masts: [
        { at: 0.38, h: 1.06, sail: 'gaff', yards: 0 },
        { at: 0.74, h: 0.68, sail: 'gaff', yards: 0 },
      ],
      jibs: 1, staysails: false,
    },
    {
      id: 'sloop', name: 'Sloop rig',
      masts: [{ at: 0.40, h: 1.14, sail: 'gaff', yards: 0 }],
      jibs: 1, staysails: false,
    },
    {
      id: 'lateen', name: 'Lateen rig',
      masts: [
        { at: 0.34, h: 0.96, sail: 'lateen', yards: 0 },
        { at: 0.70, h: 0.74, sail: 'lateen', yards: 0 },
      ],
      jibs: 0, staysails: false,
    },
    {
      id: 'lug', name: 'Lug rig',
      masts: [
        { at: 0.30, h: 0.78, sail: 'lug', yards: 0 },
        { at: 0.68, h: 0.86, sail: 'lug', yards: 0 },
      ],
      jibs: 0, staysails: false,
    },
    {
      id: 'square-single', name: 'Single square sail',
      masts: [{ at: 0.48, h: 0.88, sail: 'square', yards: 1 }],
      jibs: 0, staysails: false,
    },
  ];

  //===========================================================================
  // 3. PAINT SCHEMES.
  //
  // ⛔ EVERY INK IS PICKED AGAINST WHAT IT SITS ON, NEVER HARD-CODED (wing
  // §22e). What is stored here is the SCHEME — hull, wale, trim, canvas — and
  // the renderer solves relief and contrast against it at draw time. Card names
  // drawn in a palette's own `ground` colour once shipped four decks with every
  // title unreadable.
  //===========================================================================

  /**
   * @type {Array<object>} The paint schemes.
   */
  C.SCHEMES = [
    { id: 'nelson', name: 'Chequer', hull: [232, 214, 176], wale: [28, 26, 26], trim: [176, 138, 62], canvas: [238, 232, 214], gunstripe: true },
    { id: 'black-strake', name: 'Black Strake', hull: [46, 44, 46], wale: [22, 20, 22], trim: [168, 134, 60], canvas: [232, 226, 208], gunstripe: false },
    { id: 'ochre', name: 'Ochre', hull: [190, 142, 70], wale: [72, 46, 26], trim: [214, 186, 112], canvas: [236, 228, 206], gunstripe: false },
    { id: 'tarred', name: 'Tarred', hull: [76, 66, 58], wale: [36, 30, 26], trim: [122, 104, 78], canvas: [214, 206, 186], gunstripe: false },
    { id: 'oxblood', name: 'Oxblood', hull: [116, 48, 44], wale: [58, 24, 22], trim: [186, 152, 74], canvas: [234, 226, 206], gunstripe: false },
    { id: 'verdigris', name: 'Verdigris', hull: [72, 104, 96], wale: [34, 52, 48], trim: [196, 170, 96], canvas: [230, 226, 210], gunstripe: false },
    { id: 'bleached', name: 'Bleached', hull: [206, 198, 178], wale: [128, 116, 98], trim: [166, 150, 116], canvas: [244, 240, 228], gunstripe: false },
    { id: 'royal', name: 'Royal Blue', hull: [44, 62, 104], wale: [24, 32, 56], trim: [206, 176, 84], canvas: [238, 232, 216], gunstripe: true },
  ];

  //===========================================================================
  // 4. WEATHERING STATES.
  //===========================================================================

  /**
   * @type {Array<object>} How hard a life the vessel has had.
   */
  C.WEATHER = [
    { id: 'new', name: 'Newly launched', fouling: 0.00, patch: 0.00, shot: 0 },
    { id: 'worked', name: 'Worked', fouling: 0.22, patch: 0.10, shot: 0 },
    { id: 'salted', name: 'Salted', fouling: 0.46, patch: 0.26, shot: 0 },
    { id: 'battered', name: 'Battered', fouling: 0.62, patch: 0.48, shot: 3 },
    { id: 'derelict', name: 'Derelict', fouling: 0.88, patch: 0.78, shot: 6 },
  ];

  //===========================================================================
  // 5. SAIL STATES. A completely different picture, not a parameter.
  //===========================================================================

  /**
   * @type {Array<object>} What the canvas is doing.
   */
  C.CANVAS_STATE = [
    { id: 'full', name: 'All plain sail', set: 1.00, reef: 0.00 },
    { id: 'topsails', name: 'Topsails only', set: 0.55, reef: 0.00 },
    { id: 'reefed', name: 'Reefed', set: 0.80, reef: 0.42 },
    { id: 'storm', name: 'Storm canvas', set: 0.30, reef: 0.60 },
    { id: 'furled', name: 'Furled', set: 0.00, reef: 0.00 },
  ];

  //===========================================================================
  // 6. VOLUME.
  //
  // ⛔ THE NUMBER THAT MATTERS IS NOT THIS ONE (wing §21i). `volume()` reports
  // what the product COULD make. What a buyer sees is what their own database
  // RESOLVES to, and a classifier written as a decision tree returns exactly
  // one answer per branch — Glaze reported 168 vessels and put TWELVE items in
  // FIVE forms on the shelf, with four visible twins. The honest second number
  // comes from `_probe/spread_check.js` run over a real database, and it is the
  // one to quote.
  //===========================================================================

  /**
   * @returns {object} What the corpus can generate.
   */
  C.volume = function () {
    return {
      hulls: C.HULLS.length,
      rigs: C.RIGS.length,
      schemes: C.SCHEMES.length,
      weather: C.WEATHER.length,
      canvasStates: C.CANVAS_STATE.length,
      /* ⭐ THE §1.1 QUESTION 3 ANSWER, and it is deliberately the count of
       * DISTINCT AUTHORED VISUAL ENTITIES rather than the multiplied total. A
       * product that claims 24,000 ships by multiplying five tables is claiming
       * arithmetic, not craft. What was actually drawn by hand is the hulls,
       * the rigs, the schemes, the weathering states and the canvas states. */
      authoredEntities: C.HULLS.length + C.RIGS.length + C.SCHEMES.length
        + C.WEATHER.length + C.CANVAS_STATE.length,
      /* The combinatorial figure, reported separately and never as the headline. */
      combinations: C.HULLS.length * C.RIGS.length * C.SCHEMES.length
        * C.WEATHER.length * C.CANVAS_STATE.length,
    };
  };

  /** @param {string} id Hull id. @returns {object|null} The hull class. */
  C.hull = function (id) { return C.HULLS.filter((h) => h.id === id)[0] || null; };
  /** @param {string} id Rig id. @returns {object|null} The rig plan. */
  C.rig = function (id) { return C.RIGS.filter((r) => r.id === id)[0] || null; };
  /** @param {string} id Scheme id. @returns {object|null} The paint scheme. */
  C.scheme = function (id) { return C.SCHEMES.filter((s) => s.id === id)[0] || null; };
  /** @param {string} id Weather id. @returns {object|null} The weathering state. */
  C.weather = function (id) { return C.WEATHER.filter((s) => s.id === id)[0] || null; };
  /** @param {string} id Canvas id. @returns {object|null} The canvas state. */
  C.canvas = function (id) { return C.CANVAS_STATE.filter((s) => s.id === id)[0] || null; };

  /** @returns {string[]} Every hull id. */
  C.hullIds = function () { return C.HULLS.map((h) => h.id); };
  /** @returns {string[]} Every rig id. */
  C.rigIds = function () { return C.RIGS.map((r) => r.id); };
}());

//-----------------------------------------------------------------------------
// copied from ShipwrightHull.js (4 namespace references renamed)
//-----------------------------------------------------------------------------
//=============================================================================
// ShipwrightHull.js — Shipwright [3/5]
//=============================================================================
/* (Shipwright plugin header removed; this is a copy inside Broadside) */

var CSAF = CSAF || {};
CSAF.BroadsideShip = CSAF.BroadsideShip || {};

(function () {
  'use strict';

  const H = {};
  CSAF.BroadsideShip.Hull = H;

  /* ⛔ SIBLINGS ARE RESOLVED AT FIRST USE, NEVER AT LOAD TIME (wing §8 trap 2).
   * A four-file product in this wing captured its siblings at load, the harness
   * loaded the folder ALPHABETICALLY, and the whole product no-oped behind one
   * console line — which is exactly what a buyer gets for dragging the files in
   * in the wrong order. */
  let _R = null;
  /** @returns {object} The Render module. */
  function R() {
    if (!_R) {
      _R = CSAF.BroadsideShip.Render;
      if (!_R) throw new Error('Shipwright: ShipwrightRender.js is not loaded.');
    }
    return _R;
  }

  //===========================================================================
  // 1. ⛔ THE RESOLUTION FLOOR. DERIVED FROM THE INK, NEVER TYPED.
  //
  // Wing §22a-2b: the floor is "a function of r * 0.030, not a constant" — and
  // the roadmap's first instruction for this product, taken from what Quires
  // cost, is DERIVE IT BEFORE AUTHORING ANYTHING. Quires' first device corpus
  // had 21 of 21 stroke parts below the floor its own relief offset imposed,
  // and the suite was green because the check tested a corpus field nothing
  // drew with.
  //
  // ⛔ AND THE DANGEROUS FLOOR HERE IS NOT THE STROKE WIDTH. IT IS THE PITCH.
  // A ship is drawn with REPEATED parallel lines — a gang of shrouds, the
  // ratlines across them, the planking seams, the gunport row. Wing §17c-1
  // records the identical defect on Chorograph: hachures were built, stroked
  // and COUNTED, and the rendered PNG was a plain solid triangle, because at
  // the pen that map inks with the gap between them was 1.1 px. A shroud gang
  // whose lines are closer together than the ink is wide is not rigging. It is
  // a filled triangle, and every op counter in this factory will report work.
  //
  // So both numbers below are derived from ONE input — the length on deck in
  // pixels — and the corpus is authored above them rather than tuned to them.
  //===========================================================================

  /**
   * Base ink width for the finest line the portrait draws (running rigging).
   *
   * ⚠️ The `Math.max(1, …)` is not defensive padding, it is the device pixel.
   * Below one pixel a canvas stroke is antialiased into a grey smear, which
   * reads as haze rather than as rope — the feature stops existing while every
   * counter still reports a stroke.
   *
   * @param {number} L Length on deck, in px.
   * @returns {number} Ink width in px.
   */
  H.ink = function (L) {
    return Math.max(1, L * 0.0024);
  };

  /**
   * @type {number} ⛔ THE MEASURED FLOOR: the minimum PAPER, in px, that must
   * survive between two parallel marks for them to read as two marks.
   *
   * MEASURED by `_probe/floor_probe.js` over 4 ink widths x 21 pitches, against
   * a fused control (one solid block, which must report 0 gaps) and a clean
   * control (9 lines, which must report 8). Every failing case left <= 2.4 px of
   * paper; every passing case left >= 2.49 px. The floor is placed in that gap
   * (wing §12b-1, §22b-2: put the threshold in the measured gap, never at a
   * number you like).
   *
   * ⛔ AND THE FIRST VERSION OF THIS WAS A RATIO, WHICH IS THE WRONG SHAPE. A
   * typed `PITCH_RATIO = 2.6` was falsified by its own probe: the first usable
   * ratio is not one number but runs 3.6 -> 2.8 -> 2.2 -> 2.0 as the ink
   * thickens from 1 px to 3 px, so a single ratio is too tight at the thin end
   * (where the fleet-list thumbnail draws) and wasteful at the thick end.
   * Subtracting the ink collapses all four rows onto one constant.
   *
   * This is wing §22e-1 one level over — "any tint whose job is to make
   * something VISIBLE must state its separation in ABSOLUTE terms and solve for
   * it". A ratio is a hard-coded contrast ratio wearing different units, and
   * the eye reads the paper, not the proportion.
   */
  H.PAPER_MIN = 2.6;

  /**
   * ⛔ THE PITCH FLOOR — the closest two parallel lines may be drawn and still
   * read as two lines.
   *
   * @param {number} L Length on deck, in px.
   * @returns {number} Minimum centre-to-centre spacing in px.
   */
  H.pitchFloor = function (L) {
    return H.ink(L) + H.PAPER_MIN;
  };

  /**
   * How many parallel lines fit across a span and still read as separate.
   *
   * ⭐ THIS IS THE POINT OF THE WHOLE SECTION. The shroud count is DERIVED from
   * the span and the ink, never typed as "seven shrouds" — so the same corpus
   * renders honestly at portrait size and at fleet-list size, and a feature
   * that cannot resolve is DROPPED rather than drawn as mush (wing §17c-1: a
   * feature that cannot exist at the product's own scale must move to a scale
   * where it can, or be deleted).
   *
   * @param {number} span Available width in px.
   * @param {number} L Length on deck, in px.
   * @param {number} want The number the rig would carry at full size.
   * @param {number} [markW] Width of ONE mark in px. Defaults to the hairline
   *   ink width. ⛔ Pass it for anything wider than a line — a gunport is a
   *   square, and spacing squares by a hairline's floor packs them into a
   *   continuous band.
   * @returns {number} The number that actually resolves, 0 if none do.
   */
  H.fitLines = function (span, L, want, markW) {
    if (span <= 0) return 0;
    const pitch = (markW === undefined ? H.ink(L) : markW) + H.PAPER_MIN;
    const max = Math.floor(span / pitch) + 1;
    if (max < 2) return 0;
    return Math.min(want, max);
  };

  /**
   * @type {object} The repeated features, described by the geometry they
   * actually occupy — NOT by a length in pixels at which someone decided they
   * look bad.
   *
   * ⛔ THIS TABLE USED TO BE ELEVEN TYPED PIXEL THRESHOLDS, and that is the very
   * defect this file's §1 exists to prevent: wing §22a-6, "an invented threshold
   * manufactures false reds exactly as readily as it hides true ones". Each row
   * now states the SPAN the feature is drawn across (as a fraction of length on
   * deck), how many marks it carries at full size, and the fewest that still say
   * what the feature is. Whether it resolves is then arithmetic against the
   * measured paper floor, and it re-derives itself for free if `ink()` or
   * `PAPER_MIN` ever move.
   *
   * `min` is a statement about MEANING, not about pixels: two shrouds is a pair
   * of lines, three is a gang; one plank seam is a scratch, two is planking.
   */
  H.FEATURES = {
    /* Repeated features. `span` is measured across the direction the marks
     * REPEAT in; `mark` is the width of ONE mark, as a fraction of length on
     * deck, or null when the mark is a hairline drawn at `ink(L)`.
     *
     * ⛔ `mark` EXISTS BECAUSE THE FIRST VERSION OF THIS TABLE DID NOT HAVE IT,
     * and the omission produced visible nonsense the moment the thresholds were
     * printed: gunports resolved at L=18 while the WALE THEY SIT ON resolved at
     * 137. The cause was applying a floor derived for HAIRLINES to marks that
     * are not hairlines — a gunport is a square about 0.02 L wide, not a 1 px
     * line, so its pitch floor is its own width plus the paper, not the ink
     * plus the paper. Wing §22b-2: compare only entries the product DRAWS THE
     * SAME WAY.
     *
     * `needs` is the feature this one hangs on. A rung cannot resolve before
     * the shrouds it is seized to, and a gunport cannot resolve before the wale
     * it is cut through. Without this, arithmetic that is locally correct
     * produces an impossible picture. */
    shrouds: { span: 0.075, mark: null, want: 9, min: 3, needs: 'rig' },
    ratlines: { span: 0.300, mark: null, want: 14, min: 4, needs: 'shrouds' },
    gunports: { span: 0.620, mark: 0.020, want: 11, min: 4, needs: 'wale' },
    planking: { span: 0.090, mark: null, want: 6, min: 3, needs: 'wale' },
    quarterGallery: { span: 0.055, mark: 0.010, want: 4, min: 2, needs: 'wale' },
    /* A row of shields along the gunwale. A repeated feature like the gunports
     * and measured the same way — the mark is the shield's own diameter, not a
     * hairline, so its pitch floor is its width plus the paper (§22a-2d). Three
     * shields are a row; two are a pair of dots, so `min` is 3.
     *
     * ⛔ `readPx` IS LOAD-BEARING HERE AND ITS ABSENCE WAS CAUGHT BY THE SUITE
     * ON THE FIRST RUN. Written with `mark` alone this row resolved at L = 9,
     * because both the span and the mark are FRACTIONS OF L: the ratio between
     * them never changes, so `fitLines` returns the same count at every size
     * and the feature can never be dropped. That is wing §22a-2d's own lesson
     * arriving one level up — "a spacing floor is absolute pixels, not a ratio"
     * — and the shields were the first repeated feature in this corpus whose
     * mark DEPICTS A THING rather than being a line, so they are the first that
     * needed the same absolute floor the figurehead has. A 0.3 px shield is a
     * speck of dust on a gunwale. */
    shields: { span: 0.680, mark: 0.038, want: 12, min: 3, needs: 'hull', readPx: 6 },
  };

  /**
   * @type {object} Features that are single marks rather than repeated ones, so
   * no pitch applies.
   *
   * `w` is the mark's width as a fraction of length on deck, taken from real
   * naval proportion rather than invented: a lower mast is about 1/70 of a
   * ship's length in diameter, a main wale about 1/100, a channel thinner
   * again.
   *
   * ⛔ `readPx` IS A SECOND, DIFFERENT QUESTION AND MOST FEATURES DO NOT HAVE
   * IT. "Can this be drawn?" is answered by the ink floor. "Can this be read as
   * what it IS?" is answered only for marks that depict a SUBJECT — and wing
   * §22a-2b is explicit that below its floor "the eye assigns it to the nearest
   * common category". A wale is a band and a band at 2 px is still a band, so
   * it needs no `readPx`. A figurehead is a carved figure, and a carved figure
   * at 2 px is a dot; the first version of this table let it resolve at L=58,
   * where it is 1.5 px of ink being sold as sculpture.
   */
  H.SOLIDS = {
    wale: { w: 0.010, needs: null },
    /* ⛔ A MAST IS MEASURED BY ITS LENGTH, NOT ITS WIDTH, AND THE FIRST VERSION
     * OF THIS TABLE GOT THAT BACKWARDS. Treating it as a 0.014-wide mark made
     * the whole rig vanish below L=108, and the level-of-detail sheet showed a
     * 64 px vessel as a bare hull sliver with no mast at all — a fleet list of
     * mastless hulls reads as broken, not as honest.
     *
     * The width test is the wrong question here because the renderer ALREADY
     * clamps the mast to the ink floor (`max(ink * 1.6, L * 0.0115)`), so a mast
     * can always be drawn; it is a stick, and a stick stays a stick at one pixel
     * wide. What decides whether it reads is whether it is long enough to be a
     * line rather than a dot. Wing §17c-1 says a feature that cannot exist at
     * the product's own scale must move or be deleted — the corollary is that a
     * feature which CAN exist must not be deleted for failing a test aimed at a
     * different property. */
    rig: { h: 0.72 * 0.9, needs: null, minPx: 10 },
    channels: { w: 0.006, needs: 'shrouds' },
    sails: { w: 0.040, needs: 'rig' },
    figurehead: { w: 0.026, needs: 'hull', readPx: 13 },
    /* ⭐ STEERING GEAR — AND IT IS MEASURED BY LENGTH, LIKE THE RIG, NOT BY THE
     * WIDTH OF ITS BLADE. Written as a 0.022-wide mark needing 11 px it did not
     * resolve until L = 500, which puts it on the hero portrait alone and
     * leaves the cog and the great hulk colliding on every fleet sheet — i.e.
     * absent from the one view the collision was found in.
     *
     * The width test is the wrong question for the same reason it was wrong for
     * the mast: what says "steering gear" is not the thickness of the blade but
     * the LOOM — the tiller reaching inboard over the stern, or the shaft of
     * the steering oar crossing the sheer. That mark is 0.085 to 0.16 of length
     * on deck, and it holds as a line down to about 22 px. Wing §17c-1's
     * corollary, already recorded on the `rig` row above: a feature which CAN
     * exist at a scale must not be deleted for failing a test aimed at a
     * different property. */
    rudder: { h: 0.085, needs: 'hull', minPx: 22 },
  };

  /**
   * Whether a named detail may be drawn at this size.
   *
   * ⛔ DERIVED, NEVER LOOKED UP. A repeated feature resolves when its own marks
   * still leave the MEASURED paper gap between them; a solid one resolves when
   * its width clears the ink floor; and NEITHER resolves before the thing it
   * hangs on. Wing §17c-1: a feature that cannot exist at the product's own
   * scale must move to a scale where it can, or be deleted. Drawing it anyway
   * is the Chorograph hachure — three strokes counted, a solid triangle
   * rendered.
   *
   * @param {string} feature A key of FEATURES or SOLIDS, or 'hull'.
   * @param {number} L Length on deck, in px.
   * @returns {boolean} True when the feature resolves.
   */
  H.resolves = function (feature, L) {
    if (feature === 'hull') return true;
    const f = H.FEATURES[feature];
    if (f) {
      if (f.needs && !H.resolves(f.needs, L)) return false;
      const markW = f.mark === null ? H.ink(L) : f.mark * L;
      /* ⛔ A REPEATED MARK THAT DEPICTS A THING NEEDS AN ABSOLUTE FLOOR TOO.
       * When both `span` and `mark` are fractions of L, `fitLines` is
       * scale-INVARIANT and the row can never be dropped at any size — the
       * suite caught `shields` resolving at L = 9 for exactly this reason. The
       * spacing question ("do these read as separate marks?") and the identity
       * question ("is one of them still the thing it depicts?") are different,
       * and only the second has an absolute answer (wing §22a-2b). */
      if (f.readPx !== undefined && markW < f.readPx) return false;
      return H.fitLines(f.span * L, L, f.want, markW) >= f.min;
    }
    const s = H.SOLIDS[feature];
    if (s) {
      if (s.needs && !H.resolves(s.needs, L)) return false;
      /* A feature measured by LENGTH: it is drawn at the ink floor however thin
       * the geometry says, so the only question is whether it is long enough. */
      if (s.h !== undefined) return s.h * L >= s.minPx;
      if (s.readPx !== undefined && s.w * L < s.readPx) return false;
      return s.w * L >= H.ink(L) * 1.5;
    }
    return false;
  };

  /**
   * The length on deck at which a feature starts to resolve — solved, not typed.
   * Exists so the suite and the store copy can quote a real number, and so a
   * regression in `ink()` or `PAPER_MIN` moves it visibly.
   *
   * @param {string} feature A key of FEATURES or SOLIDS.
   * @returns {number} Length on deck in px, or 0 if it always resolves.
   */
  H.resolvesAt = function (feature) {
    if (feature === 'hull') return 0;
    for (let L = 8; L <= 4000; L++) if (H.resolves(feature, L)) return L;
    return Infinity;
  };

  //===========================================================================
  // 2. THE HULL, LOFTED.
  //
  // ⛔ THE KILL CONDITION, STATED IN THE ROADMAP BEFORE ANY CODE: "a hull
  // crescent with three sticks in it is a CHILD'S DRAWING OF A BOAT", and wing
  // §22a-5b already killed a ship once in this wing — face-on it read as a
  // SMILEY FACE, side-on as a BOWL WITH A HOOK.
  //
  // A shallow crescent IS a bowl. What separates a ship's portrait from a bowl
  // is not detail added on top, it is the OUTLINE (wing §22a-1b: two masses
  // read as one object when the outline flows, as two when it steps):
  //
  //   1. SHEER — the deck line is a shallow catenary, lowest around 0.55 of the
  //      length and rising to BOTH ends, higher aft than forward. A straight or
  //      symmetric deck line is the bowl.
  //   2. STEM AND STERNPOST RAKE — the ends are not the ends of an arc; they
  //      are posts leaning in different directions and by different amounts.
  //   3. TUMBLEHOME — the topsides curve back INWARD above the waterline, so
  //      the widest part of the hull is below the deck. This is the single cue
  //      that says "built of frames" rather than "scooped".
  //   4. THE WALE — a heavy horizontal band running the length, breaking the
  //      hull into two tones. Without it the hull is one flat shape.
  //===========================================================================

  /**
   * The sheer line — height of the deck above the load waterline, as a
   * fraction of freeboard, along the length.
   *
   * @param {number} t 0 at the stem, 1 at the sternpost.
   * @param {object} f Form: {sheerFwd, sheerAft, low}.
   * @returns {number} Multiplier on freeboard, ~1 amidships.
   */
  H.sheer = function (t, f) {
    const low = f.low === undefined ? 0.56 : f.low;
    /* Two half-parabolas meeting at the low point, so the rise forward and the
     * rise aft are independent. A single symmetric curve is the bowl. */
    if (t <= low) {
      const u = (low - t) / (low || 1);
      return 1 + f.sheerFwd * u * u;
    }
    const u = (t - low) / ((1 - low) || 1);
    return 1 + f.sheerAft * u * u;
  };

  /**
   * Build the hull outline as ONE continuous closed polygon.
   *
   * ⛔ ONE OUTLINE, NOT FOUR SHAPES (wing §22a-1b). The mammoth was authored as
   * body + skull + trunk + tusks placed adjacent, and at 420px it read as "a
   * circle, an oval, four posts and a floating hook". A hull assembled from a
   * bottom arc, a bow piece and a transom would fail the same way — the joins
   * become seams and the eye reads three objects. Traced as one path, the stem
   * is a change of direction rather than a join.
   *
   * @param {object} f Form parameters.
   * @param {number} x Centre x of the load waterline.
   * @param {number} y Load waterline y.
   * @param {number} L Length on deck, px.
   * @returns {object} {deck, bottom, outline, stemTop, sternTop, waterline}.
   */
  H.loft = function (f, x, y, L) {
    const half = L / 2;
    const fb = L * f.freeboard;      // freeboard: deck above waterline
    const draft = L * f.draft;       // depth below waterline
    const N = 26;                    // samples along the deck

    const deck = [];
    for (let i = 0; i <= N; i++) {
      const t = i / N;
      const px = x - half + L * t;
      const py = y - fb * H.sheer(t, f);
      deck.push([px, py]);
    }

    /* The bottom: nearly straight with drag aft (deeper at the sternpost than
     * at the forefoot), and a rounded forefoot rather than a corner. */
    const bottom = [];
    const M = 22;
    for (let i = 0; i <= M; i++) {
      const t = 1 - i / M;           // aft to forward
      const px = x - half + L * t;
      /* Rise at both ends: the forefoot sweeps up to the stem, the run sweeps
       * up to the sternpost. `drag` makes the aft end deeper. */
      const ends = Math.pow(Math.abs(t - 0.5) * 2, f.endsPower || 2.6);
      const depth = draft * (1 - ends * 0.92) * (1 + f.drag * (t - 0.5));
      bottom.push([px, y + Math.max(0, depth)]);
    }

    const stemTop = deck[0];
    const sternTop = deck[deck.length - 1];

    /* Stem and sternpost rake. Positive rake leans the post FORWARD of its
     * waterline foot; the two are independent and different, which is half of
     * what separates a hull from an arc. */
    const stemFoot = bottom[bottom.length - 1];
    const sternFoot = bottom[0];
    const stemLean = L * f.stemRake;
    const sternLean = L * f.sternRake;

    const outline = [];
    /* Forward along the deck, aft along the deck, down the sternpost, forward
     * along the bottom, up the stem — one closed loop. */
    for (let i = 0; i < deck.length; i++) outline.push(deck[i]);
    outline.push([sternTop[0] + sternLean, sternTop[1]]);
    outline.push([sternFoot[0], sternFoot[1]]);
    for (let i = 1; i < bottom.length; i++) outline.push(bottom[i]);
    outline.push([stemFoot[0], stemFoot[1]]);
    outline.push([stemTop[0] - stemLean, stemTop[1]]);

    return {
      deck: deck,
      bottom: bottom,
      outline: outline,
      stemTop: [stemTop[0] - stemLean, stemTop[1]],
      sternTop: [sternTop[0] + sternLean, sternTop[1]],
      waterline: y,
      freeboard: fb,
      L: L,
      x: x,
    };
  };

  /**
   * The deck y at a given fraction of the length. Used to stand masts, hang
   * channels and place gunports on the real sheer rather than on a flat line.
   *
   * @param {object} h A lofted hull.
   * @param {number} t 0 at the stem, 1 at the sternpost.
   * @returns {number} y in px.
   */
  H.deckAt = function (h, t) {
    const i = Math.max(0, Math.min(h.deck.length - 1, Math.round(t * (h.deck.length - 1))));
    return h.deck[i][1];
  };

  /**
   * The x at a given fraction of the length.
   * @param {object} h A lofted hull.
   * @param {number} t 0 at the stem, 1 at the sternpost.
   * @returns {number} x in px.
   */
  H.xAt = function (h, t) {
    return h.x - h.L / 2 + h.L * t;
  };

  //===========================================================================
  // 3. THE RIG.
  //
  // ⛔ THE SHROUD GANG IS THE PRODUCT. A mast is a stick; a mast with a gang of
  // shrouds fanning down to a channel is unmistakably a ship, and it is the one
  // cue that survives when the sails are furled. It is also the feature most
  // likely to fuse into a triangle of ink, which is why §1 above derives its
  // count from the pitch floor rather than typing a number.
  //===========================================================================

  /**
   * Draw a tapering, raked mast.
   *
   * ⚠️ Taper is not decoration. A constant-width vertical is a POST; wing
   * §22a-1b records that a limb of constant width reads as a tube. A mast that
   * narrows toward the truck reads as a spar.
   *
   * @param {object} rec Recorder.
   * @param {number} xFoot Foot x.
   * @param {number} yFoot Foot y (on the deck).
   * @param {number} height Height above the foot.
   * @param {number} rake Aft lean as a fraction of height.
   * @param {number} w Width at the foot.
   * @param {string} ink CSS colour.
   * @returns {number[]} The truck [x, y].
   */
  H.mast = function (rec, xFoot, yFoot, height, rake, w, ink) {
    const xTop = xFoot + height * rake;
    const yTop = yFoot - height;
    const wTop = w * 0.42;
    rec.poly([
      [xFoot - w / 2, yFoot],
      [xFoot + w / 2, yFoot],
      [xTop + wTop / 2, yTop],
      [xTop - wTop / 2, yTop],
    ], ink);
    return [xTop, yTop];
  };

  /**
   * Draw a gang of shrouds from a masthead down to a channel, plus ratlines if
   * and only if they resolve.
   *
   * ⛔ THE COUNT IS DERIVED. `want` is what the rig carries at full size; what
   * is actually drawn is what `fitLines` says can be told apart. At fleet-list
   * size that is often 3 instead of 9, and the picture is honest rather than
   * smeared.
   *
   * @param {object} rec Recorder.
   * @param {number[]} head Masthead [x, y].
   * @param {number} cx0 Channel forward end x.
   * @param {number} cx1 Channel aft end x.
   * @param {number} cy Channel y.
   * @param {number} L Length on deck, px.
   * @param {number} want Shrouds at full size.
   * @param {string} ink CSS colour.
   * @returns {object} {shrouds, ratlines} — what was actually drawn.
   */
  H.shrouds = function (rec, head, cx0, cx1, cy, L, want, ink) {
    const span = Math.abs(cx1 - cx0);
    const n = H.fitLines(span, L, want);
    if (n < 2) return { shrouds: 0, ratlines: 0 };

    const w = H.ink(L);
    const pts = [];
    for (let i = 0; i < n; i++) {
      const u = i / (n - 1);
      const bx = cx0 + (cx1 - cx0) * u;
      /* The gang converges at the masthead but not to a single point — real
       * shrouds are seized round the mast over a span of a few feet. */
      const tx = head[0] + (bx - head[0]) * 0.055;
      pts.push([[tx, head[1]], [bx, cy]]);
      rec.begin();
      rec.moveTo(tx, head[1]);
      rec.lineTo(bx, cy);
      rec.stroke(ink, w);
    }

    /* Ratlines: the horizontal rungs. The tightest repeated element on a ship,
     * and the first thing that must be dropped. Their pitch is measured on the
     * NARROWEST part of the gang — the top — because that is where they fuse
     * first, and drawing them from the average would fill the head solid. */
    let rats = 0;
    if (H.resolves('ratlines', L)) {
      const topSpan = Math.abs(pts[n - 1][0][0] - pts[0][0][0]);
      const height = Math.abs(cy - head[1]);
      /* ⛔ THE RUNG PITCH IS PHYSICAL, NOT "AS MANY AS THE FLOOR ALLOWS". The
       * first version asked for `height / (pitchFloor * 2.1)` rungs, which is a
       * request to pack the gang as tightly as the ink permits — 49 per mast at
       * portrait size. Three of those gangs rendered as solid black trapezoids
       * that read as ENORMOUS TAPERED MASTS, and the op counter honestly
       * reported 113 strokes of real work. Ratlines are about 15 inches apart on
       * a real ship, so the pitch is a fraction of her LENGTH and the count
       * falls out of it. */
      const rung = H.fitLines(height, L, Math.round(height / (L * 0.016)));
      /* ⚠️ A rung is only worth drawing where the gang is wide enough to carry
       * more than one gap; up near the seizing it is one blob. */
      for (let j = 1; j < rung; j++) {
        const v = j / rung;
        const wide = topSpan + (span - topSpan) * v;
        if (wide < H.pitchFloor(L) * 2) continue;
        const ax = pts[0][0][0] + (pts[0][1][0] - pts[0][0][0]) * v;
        const bx = pts[n - 1][0][0] + (pts[n - 1][1][0] - pts[n - 1][0][0]) * v;
        const yy = head[1] + (cy - head[1]) * v;
        rec.begin();
        rec.moveTo(ax, yy);
        rec.lineTo(bx, yy);
        rec.stroke(ink, w * 0.8);
        rats++;
      }
    }
    return { shrouds: n, ratlines: rats };
  };

  /**
   * Draw a yard — a horizontal spar tapering to both ends.
   * @param {object} rec Recorder.
   * @param {number} cx Centre x.
   * @param {number} cy Centre y.
   * @param {number} halfLen Half length.
   * @param {number} w Thickness at the slings.
   * @param {string} ink CSS colour.
   */
  H.yard = function (rec, cx, cy, halfLen, w, ink) {
    rec.poly([
      [cx - halfLen, cy - w * 0.22],
      [cx - halfLen * 0.25, cy - w / 2],
      [cx + halfLen * 0.25, cy - w / 2],
      [cx + halfLen, cy - w * 0.22],
      [cx + halfLen, cy + w * 0.22],
      [cx + halfLen * 0.25, cy + w / 2],
      [cx - halfLen * 0.25, cy + w / 2],
      [cx - halfLen, cy + w * 0.22],
    ], ink);
  };

  /**
   * Draw a square sail, bellied by the wind.
   *
   * ⛔ A RECTANGLE IS NOT A SAIL. Canvas under load is a curved surface: the
   * foot scoops, the leeches bow, and the belly throws a shadow down its lee
   * side. A flat quadrilateral reads as a signboard hung off a stick, which is
   * the child's drawing again.
   *
   * @param {object} rec Recorder.
   * @param {number} cx Yard centre x.
   * @param {number} yTop Yard y.
   * @param {number} halfTop Half the yard length.
   * @param {number} drop Sail depth.
   * @param {number} halfFoot Half the foot width.
   * @param {number} belly Belly as a fraction of drop, signed by the wind side.
   * @param {string} cloth CSS fill.
   * @param {string} shade CSS fill for the lee shadow, or null.
   */
  H.squareSail = function (rec, cx, yTop, halfTop, drop, halfFoot, belly, cloth, shade) {
    const b = drop * belly;
    rec.begin();
    rec.moveTo(cx - halfTop, yTop);
    /* Weather leech bows out, foot scoops up, lee leech returns. */
    rec.bezTo(
      cx - halfTop - b * 0.30, yTop + drop * 0.42,
      cx - halfFoot - b * 0.22, yTop + drop * 0.80,
      cx - halfFoot, yTop + drop
    );
    rec.quadTo(cx + b * 0.55, yTop + drop - drop * 0.20, cx + halfFoot, yTop + drop);
    rec.bezTo(
      cx + halfFoot + b * 0.10, yTop + drop * 0.78,
      cx + halfTop + b * 0.16, yTop + drop * 0.40,
      cx + halfTop, yTop
    );
    rec.close();
    rec.fill(cloth);

    if (shade) {
      /* The lee side of the belly. Drawn INSIDE the sail's own path so it can
       * never escape the canvas outline. */
      rec.save();
      rec.begin();
      rec.moveTo(cx - halfTop, yTop);
      rec.bezTo(
        cx - halfTop - b * 0.30, yTop + drop * 0.42,
        cx - halfFoot - b * 0.22, yTop + drop * 0.80,
        cx - halfFoot, yTop + drop
      );
      rec.quadTo(cx + b * 0.55, yTop + drop - drop * 0.20, cx + halfFoot, yTop + drop);
      rec.bezTo(
        cx + halfFoot + b * 0.10, yTop + drop * 0.78,
        cx + halfTop + b * 0.16, yTop + drop * 0.40,
        cx + halfTop, yTop
      );
      rec.close();
      rec.clip();
      rec.begin();
      rec.moveTo(cx + halfTop * 0.10, yTop);
      rec.quadTo(cx + halfTop * 0.30, yTop + drop * 0.55, cx + halfFoot * 0.55, yTop + drop);
      rec.lineTo(cx + halfTop, yTop + drop);
      rec.lineTo(cx + halfTop, yTop);
      rec.close();
      rec.fill(shade);
      rec.restore();
    }
  };

  /**
   * Draw a triangular staysail or jib set on a stay.
   * @param {object} rec Recorder.
   * @param {number[]} head Upper point [x, y].
   * @param {number[]} tack Forward lower point [x, y].
   * @param {number[]} clew Aft lower point [x, y].
   * @param {number} belly Bow of the leech, px.
   * @param {string} cloth CSS fill.
   */
  H.stayFore = function (rec, head, tack, clew, belly, cloth) {
    rec.begin();
    rec.moveTo(head[0], head[1]);
    rec.lineTo(tack[0], tack[1]);
    rec.quadTo(
      (tack[0] + clew[0]) / 2, (tack[1] + clew[1]) / 2 + belly * 0.35,
      clew[0], clew[1]
    );
    rec.quadTo(
      (clew[0] + head[0]) / 2 + belly, (clew[1] + head[1]) / 2,
      head[0], head[1]
    );
    rec.close();
    rec.fill(cloth);
  };

  /**
   * Draw a gaff or lateen sail — a quadrilateral bent to a spar at its head.
   * @param {object} rec Recorder.
   * @param {number[]} throat Forward end of the gaff [x, y].
   * @param {number[]} peak Aft end of the gaff [x, y].
   * @param {number[]} clew Aft lower corner [x, y].
   * @param {number[]} tack Forward lower corner [x, y].
   * @param {number} belly Bow of the leech, px.
   * @param {string} cloth CSS fill.
   */
  H.gaffSail = function (rec, throat, peak, clew, tack, belly, cloth) {
    rec.begin();
    rec.moveTo(throat[0], throat[1]);
    rec.lineTo(peak[0], peak[1]);
    rec.quadTo(
      (peak[0] + clew[0]) / 2 + belly, (peak[1] + clew[1]) / 2,
      clew[0], clew[1]
    );
    rec.quadTo(
      (clew[0] + tack[0]) / 2, (clew[1] + tack[1]) / 2 + belly * 0.4,
      tack[0], tack[1]
    );
    rec.close();
    rec.fill(cloth);
  };

  /**
   * Draw a channel — the platform a shroud gang lands on.
   *
   * ⭐ SMALL AND LOAD-BEARING. Without it the shrouds end in mid-air against
   * the hull side and the eye reads a scribble; with it they land on a shelf
   * and the rig is attached to the ship.
   *
   * @param {object} rec Recorder.
   * @param {number} x0 Forward end.
   * @param {number} x1 Aft end.
   * @param {number} y Top surface y.
   * @param {number} t Thickness.
   * @param {number} out Projection beyond the hull side (visual depth).
   * @param {string} ink CSS colour.
   */
  H.channel = function (rec, x0, x1, y, t, out, ink) {
    rec.poly([
      [x0, y],
      [x1, y],
      [x1 - out * 0.5, y + t],
      [x0 + out * 0.5, y + t],
    ], ink);
  };

}());

//-----------------------------------------------------------------------------
// copied from ShipwrightPortrait.js (6 namespace references renamed)
//-----------------------------------------------------------------------------
//=============================================================================
// ShipwrightPortrait.js — Shipwright [4/5]
//=============================================================================
/* (Shipwright plugin header removed; this is a copy inside Broadside) */

var CSAF = CSAF || {};
CSAF.BroadsideShip = CSAF.BroadsideShip || {};

(function () {
  'use strict';

  const P = {};
  CSAF.BroadsideShip.Portrait = P;

  let _R = null;
  let _H = null;
  let _C = null;
  /** @returns {object} Render module. */
  function R() {
    if (!_R) { _R = CSAF.BroadsideShip.Render; if (!_R) throw new Error('Shipwright: ShipwrightRender.js is not loaded.'); }
    return _R;
  }
  /** @returns {object} Hull module. */
  function H() {
    if (!_H) { _H = CSAF.BroadsideShip.Hull; if (!_H) throw new Error('Shipwright: ShipwrightHull.js is not loaded.'); }
    return _H;
  }
  /** @returns {object} Corpus module. */
  function C() {
    if (!_C) { _C = CSAF.BroadsideShip.Corpus; if (!_C) throw new Error('Shipwright: ShipwrightCorpus.js is not loaded.'); }
    return _C;
  }

  /** @type {number} Total rig height as a multiple of length on deck. */
  P.MAST_H = 0.72;

  /**
   * @type {object} Where things sit on a mast, as a fraction of its total
   * height. Real top-hamper, not invented: the lower mast carries the top
   * (platform) at its head, the topmast carries the crosstrees at its head, and
   * each yard hangs below the head of the mast that carries it.
   *
   * ⛔ `yardSpan` REPLACED A FIXED `yardHalf` OF LENGTH ON DECK, AND THE FIXED
   * VERSION WAS VISIBLY WRONG. A course yard at 0.200 L is 312 px across on a
   * 780 px frigate whose masts stand 187 px apart, so every sail overlapped its
   * neighbours into one sheet of paper. Wing §22g: size a repeated element from
   * the GAP, not from the count. A yard is now a fraction of the SPACE BETWEEN
   * MASTS, which is what actually constrains it on a real deck too.
   */
  P.MAST = {
    topPlatform: 0.42,   // the top, at the lower masthead
    crosstrees: 0.72,    // at the topmast head
    yards: [0.27, 0.53, 0.78],
    yardSpan: [0.46, 0.36, 0.26],   // x the gap between masts
    yardCap: [0.185, 0.145, 0.105], // x length on deck, a ceiling for lone masts
  };

  /**
   * Rig geometry, computed once and shared by `draw` and `metrics`.
   *
   * ⛔ ONE FUNCTION, TWO CALLERS, BY CONSTRUCTION (wing §11: "prefer a shape
   * where the fast path CALLS the slow one to one that re-implements it"). If
   * the bounding box were computed separately from the drawing, the plate would
   * be sized against a rig that no longer matches the one on the canvas, and
   * nothing would go red — the picture would just be clipped, which wing §22a-6
   * records as indistinguishable from a wrong picture.
   *
   * @param {object} rig The rig plan.
   * @param {object} lofted A lofted hull.
   * @param {number} L Length on deck, px.
   * @returns {Array<object>} One entry per mast.
   */
  P._rigGeom = function (rig, lofted, L) {
    const h = H();
    const M = [];
    /* The gap that constrains a yard: the smaller of the distances to the
     * masts either side, falling back to a cap when a mast stands alone. */
    for (let i = 0; i < rig.masts.length; i++) {
      const m = rig.masts[i];
      const xf = h.xAt(lofted, m.at);
      const yf = h.deckAt(lofted, m.at);
      const height = L * P.MAST_H * m.h;
      const rake = 0.045;
      let gap = Infinity;
      if (i > 0) gap = Math.min(gap, Math.abs(m.at - rig.masts[i - 1].at) * L);
      if (i < rig.masts.length - 1) gap = Math.min(gap, Math.abs(rig.masts[i + 1].at - m.at) * L);
      M.push({
        m: m, foot: [xf, yf], height: height, rake: rake, gap: gap,
        /** @param {number} v Fraction of height. @returns {number[]} [x,y]. */
        at: function (v) { return [xf + height * rake * v, yf - height * v]; },
        /** @param {number} j Yard index. @returns {number} Half length, px. */
        yardHalf: function (j) {
          const cap = L * P.MAST.yardCap[j];
          if (!isFinite(gap)) return cap;
          return Math.min(cap, gap * P.MAST.yardSpan[j]);
        },
      });
    }
    return M;
  };

  /**
   * The ink extent of a vessel, relative to `(cx, yWater)`.
   *
   * ⛔ WING §18 AND §22h: "gallery geometry is arithmetic — assert it before
   * rendering", and "a clipped figure and a wrong figure look identical". The
   * first portrait ran its whole upper rig off the top of the frame and every
   * mechanical check stayed green, because a clipped canvas is a valid image.
   * A plate that asks the portrait how big it is cannot make that mistake.
   *
   * @param {object} spec The vessel spec.
   * @param {number} L Length on deck, px.
   * @param {object} [opt] `{underwater: true}` when the caller is NOT painting
   *   the sea back over the hull — a lines draught shows the whole body, and
   *   its bottom is then the keel rather than the load waterline. ⛔ Without
   *   this the draught board fitted the vessel as though she ended at the
   *   waterline and her keel ran down into the title block.
   * @returns {object|null} {top, bottom, left, right} offsets in px, or null
   *   when the spec names something the corpus does not have.
   */
  P.metrics = function (spec, L, opt) {
    const h = H();
    const c = C();
    const hull = c.hull(spec.hull);
    const rig = c.rig(spec.rig);
    if (!hull || !rig) return null;
    const lofted = h.loft(hull, 0, 0, L);
    const M = h && rig ? P._rigGeom(rig, lofted, L) : [];

    let top = 0;
    let left = lofted.stemTop[0];
    let right = lofted.sternTop[0];
    for (let i = 0; i < lofted.outline.length; i++) {
      const p = lofted.outline[i];
      if (p[1] < top) top = p[1];
      if (p[0] < left) left = p[0];
      if (p[0] > right) right = p[0];
    }
    if (h.resolves('rig', L)) {
      for (let i = 0; i < M.length; i++) {
        const mt = M[i];
        const truck = mt.at(1.0);
        if (truck[1] < top) top = truck[1];
        /* The ensign flies aft of the after truck. */
        if (i === M.length - 1) right = Math.max(right, truck[0] + L * 0.062);
        for (let j = 0; j < mt.m.yards && j < P.MAST.yards.length; j++) {
          const pos = mt.at(P.MAST.yards[j]);
          const hl = mt.yardHalf(j);
          left = Math.min(left, pos[0] - hl);
          right = Math.max(right, pos[0] + hl);
        }
      }
      /* The bowsprit reaches furthest forward of anything.
       *
       * ⛔ IT MUST READ THE HULL'S OWN LENGTH, AND FOR ONE PASS IT DID NOT. This
       * line held a hard-coded 0.165 while `draw` had been changed to use
       * `hull.bowsprit`, so the cutter — whose defining feature is a bowsprit of
       * 0.34 — drew 105 px outside the box metrics promised, and the xebec 45.
       * That is the EXACT defect this function exists to prevent (wing §11: two
       * code paths that must agree should agree by construction), and it is why
       * the suite compares the promise against a recording of the real draw
       * instead of trusting either alone. */
      const bl = hull.bowsprit === undefined ? 0.165 : hull.bowsprit;
      left = Math.min(left, lofted.stemTop[0] - L * bl);
    }
    /* The underwater body is normally painted out, so the bottom is the
     * waterline — unless the caller is drawing a lines draught, in which case
     * the keel is the bottom and has to be fitted for. */
    let bottom = 0;
    if (opt && opt.underwater) {
      for (let i = 0; i < lofted.bottom.length; i++) {
        if (lofted.bottom[i][1] > bottom) bottom = lofted.bottom[i][1];
      }
    }
    return { top: top, bottom: bottom, left: left, right: right };
  };

  /**
   * Draw a complete vessel.
   *
   * @param {object} rec Recorder.
   * @param {object} spec {hull, rig, scheme, weather, canvas, seed}.
   * @param {number} cx Centre x of the vessel.
   * @param {number} yWater Load waterline y.
   * @param {number} L Length on deck, px.
   * @param {object} opt {sea} — the sea colour, so the underwater body can be
   *   hidden. ⛔ Without it the hull's whole below-water mass is drawn on top of
   *   the sea and the vessel reads as floating ON the water rather than IN it,
   *   which was the first render's most obvious defect after the rigging.
   * @returns {object} What was actually drawn, for the suite and the captions.
   */
  P.draw = function (rec, spec, cx, yWater, L, opt) {
    const r = R();
    const h = H();
    const c = C();
    const o = opt || {};

    const hull = c.hull(spec.hull);
    const rig = c.rig(spec.rig);
    const sch = c.scheme(spec.scheme);
    const wx = c.weather(spec.weather || 'worked');
    const cv = c.canvas(spec.canvas || 'full');
    /* ⛔ Wing §21c: an unknown id is SKIPPED, never crashed on — a buyer's
     * custom vessel must not take down a scene. */
    if (!hull || !rig || !sch || !wx || !cv) {
      return { drawn: false, reason: 'unknown hull, rig, scheme, weather or canvas id' };
    }

    const ink = h.ink(L);
    const lofted = h.loft(hull, cx, yWater, L);
    const drew = {
      drawn: true, features: [], shrouds: 0, ratlines: 0, gunports: 0,
      masts: 0, sails: 0, tops: 0, castle: false,
      shields: 0, rudder: null, stemHead: false, patches: 0,
    };

    const on = {};
    ['wale', 'rig', 'sails', 'shrouds', 'channels', 'planking', 'gunports',
      'ratlines', 'quarterGallery', 'figurehead', 'rudder',
      'shields'].forEach((k) => { on[k] = h.resolves(k, L); });
    Object.keys(on).forEach((k) => { if (on[k]) drew.features.push(k); });

    const rigInk = r.css(r.relief(sch.wale, -1, 18));
    /* ⛔ THE CANVAS IS SEPARATED FROM THE GROUND IT IS DRAWN ON, NOT USED RAW.
     *
     * MEASURED on the store plates: every scheme's canvas sits between 214 and
     * 244 in luminance and the draught sheet is 224, so a sail drawn in its own
     * colour on the board is cream on cream — visible only by its bolt rope. On
     * the specimen plates it very nearly vanished, and it is no better in the
     * BUYER'S game, because the board is the scene this product ships.
     *
     * That is wing §22e in its original form: an ink chosen independently of
     * what it lands on. `R.separateFrom` already existed for exactly this and
     * was being used for the gold on a paper wrapper and nowhere else — the fix
     * was three lines and a caller, not new machinery (§17c-1's sibling: the
     * function was there, nothing called it).
     *
     * The ground is passed in by whoever knows it; with no ground the colour is
     * untouched, so a caller drawing on sea and sky keeps the cream it wants. */
    const canvasBase = o.ground
      ? r.separateFrom(sch.canvas, o.ground, 22)
      : sch.canvas;
    const canvasCol = r.css(canvasBase);
    /* Reported so the suite can assert what was actually DRAWN WITH rather than
     * re-deriving it beside the product (master §2b: find the consumer). */
    drew.canvasInk = canvasBase.slice();
    /* ⛔ SOLVED, NOT MULTIPLIED (wing §22e-1). `shade(x, k)` is a hard-coded
     * contrast RATIO, so on a dark canvas it moves 11 levels and on a bright
     * one 27 — the lee side of a dark sail simply vanishes.
     *
     * ⚠️ AND THE SHADE AND THE BOLT ROPE HANG OFF THE **SEPARATED** CANVAS, not
     * off the raw scheme colour. Derived from the raw one they would drift away
     * from the cloth the moment the ground moved it, and the sail would gain a
     * lee side and an edge in a tone its own cloth never had — §11: two things
     * that must agree should agree by construction, not by care. */
    const shadeCol = r.css(r.relief(canvasBase, -1, 22));
    /* ⛔ THE BOLT ROPE IS WHY THE FIRST RENDER READ AS FOG. Wing §22c: in a
     * one-colour field two shapes only read as two if their outlines break each
     * other. Ten cream sails on a pale sky with no edge merged into one
     * continuous wedge of paper, and every op counter reported ten fills. */
    const ropeCol = r.css(r.relief(canvasBase, -1, 46));
    const ropeW = Math.max(0.8, ink * 0.7);

    //-----------------------------------------------------------------------
    // 1. RIG GEOMETRY, computed before anything is drawn so the stays and the
    //    shrouds can refer to real mastheads rather than to guesses.
    //-----------------------------------------------------------------------
    const M = on.rig ? P._rigGeom(rig, lofted, L) : [];

    //-----------------------------------------------------------------------
    // 2. MASTS AND TOPS.
    //-----------------------------------------------------------------------
    if (on.rig) {
      const mastW = Math.max(ink * 1.6, L * 0.0115);
      for (let i = 0; i < M.length; i++) {
        const mt = M[i];
        h.mast(rec, mt.foot[0], mt.foot[1], mt.height, mt.rake, mastW, rigInk);
        drew.masts++;
        /* ⭐ THE TOP IS A SMALL SHAPE THAT DOES A LOT. A bare tapering pole is a
         * flagstaff; a pole with a platform partway up and a thinner pole above
         * it is a MAST, and that break is visible at sizes where nothing else
         * in the rig is. It is also what the shroud gang lands against. */
        if (mt.m.sail === 'square' && mt.m.yards > 1) {
          const p = mt.at(P.MAST.topPlatform);
          const tw = Math.max(mastW * 2.6, L * 0.026);
          const th = Math.max(ink, L * 0.006);
          rec.poly([
            [p[0] - tw * 0.42, p[1]],
            [p[0] + tw * 0.58, p[1]],
            [p[0] + tw * 0.46, p[1] + th],
            [p[0] - tw * 0.32, p[1] + th],
          ], rigInk);
          drew.tops++;
        }
      }
    }

    //-----------------------------------------------------------------------
    // 2b. THE SHROUD GANGS — AND THEY ARE DRAWN HERE, BEFORE THE SAILS.
    //
    // ⛔ THEY USED TO BE DRAWN IN SECTION 5, AFTER THE CANVAS, AND THAT PUT A
    // BLACK CROSS-HATCHED WEDGE DOWN THE MIDDLE OF EVERY SQUARE SAIL. The gang
    // head sits at 0.41 of mast height and the course yard at 0.27, so a gang
    // drawn last covers the whole upper half of the course — on `--big cog` the
    // sail read as two pale flags either side of a dark ladder.
    //
    // It is not enough to say the near-side shrouds really are outboard of the
    // courses, which they are: a ship portrait draws the canvas as a plane and
    // shows the rigging ABOVE and BESIDE it, because that is what the eye can
    // resolve. Drawing the gang first keeps every shroud visible on a furled
    // vessel — where wing §3's "the one cue that survives when the sails are
    // furled" applies — and lets the sail cover the part that was only ever
    // noise. Nothing is removed and no count changes; only the order does.
    //-----------------------------------------------------------------------
    if (on.rig && on.shrouds) {
      for (let i = 0; i < M.length; i++) {
        const mt = M[i];
        /* ⛔ THE SPREAD COMES FROM THE SPACE THE MAST HAS, NOT FROM A CONSTANT.
         * A flat `L * 0.052` is 38 px of channel under a 300 px mast, and a
         * gang that narrow is not a fan — it is a LADDER, which is exactly how
         * the single-masted cog read once the sail stopped hiding its lower
         * half. Real lower shrouds spread to very nearly the ship's beam.
         *
         * So it is derived the same way a yard is (wing §22g, size a repeated
         * element from the gap): a lone mast gets the full beam-ish spread and
         * a crowded three-master gets whatever the gap to its neighbour allows,
         * so gangs never overlap. */
        const chanW = isFinite(mt.gap)
          ? Math.min(L * 0.105, mt.gap * 0.40)
          : L * 0.105;
        const cx0 = mt.foot[0] - chanW * 0.44;
        const cx1 = mt.foot[0] + chanW * 0.56;
        const chanY = mt.foot[1] + L * 0.004;
        const head = mt.at(P.MAST.topPlatform * 0.97);
        const got = h.shrouds(rec, head, cx0, cx1, chanY, L, 7, rigInk);
        drew.shrouds += got.shrouds;
        drew.ratlines += got.ratlines;
        if (on.channels) {
          h.channel(rec, cx0 - L * 0.005, cx1 + L * 0.005, chanY,
            Math.max(ink, L * 0.005), L * 0.003, rigInk);
        }
      }
    }

    //-----------------------------------------------------------------------
    // 3. YARDS AND SAILS.
    //
    // ⛔ SAILS ARE SIZED FROM THE GAP TO THE NEXT YARD, NEVER FROM A FIXED
    // FRACTION OF MAST HEIGHT. Wing §22g: size a repeated element from the GAP,
    // not from the count. The first render used a fixed 0.235 of mast height on
    // every yard, which overran the yard above it — ten sails overlapping into
    // one mass of paper.
    //-----------------------------------------------------------------------
    if (on.rig) {
      for (let i = 0; i < M.length; i++) {
        const mt = M[i];
        const m = mt.m;
        if (m.sail === 'square' && m.yards > 0) {
          for (let j = 0; j < m.yards && j < P.MAST.yards.length; j++) {
            const v = P.MAST.yards[j];
            const pos = mt.at(v);
            const halfLen = mt.yardHalf(j);
            h.yard(rec, pos[0], pos[1], halfLen, Math.max(ink, L * 0.0055), rigInk);
            if (!on.sails || cv.set <= 0) continue;
            /* Topsails are set before courses when shortening down, so the
             * LOWEST sail furls first — which makes "topsails only" a different
             * picture rather than a smaller one. */
            const setThis = cv.id === 'topsails' ? (j === 0 ? 0 : 1) : cv.set;
            if (setThis <= 0) continue;
            const nextV = (j + 1 < m.yards && j + 1 < P.MAST.yards.length)
              ? P.MAST.yards[j + 1] : v + 0.20;
            const gap = (nextV - v) * mt.height;
            const drop = gap * 0.84 * setThis * (1 - cv.reef * 0.42);
            /* ⛔ THE FOOT IS AS WIDE AS THE HEAD, AND IT USED TO BE 0.84 OF IT.
             * A quadrilateral that narrows downward and then sags along the
             * bottom is a BUCKET, and once the foot stopped being notched that
             * is exactly what every square sail on the sheet became — the
             * three-masters read as rows of paper cups. On a real square rig
             * the clews are hauled out to the yardarms of the sail BELOW, so
             * the foot is very nearly the width of its own yard; the taper the
             * eye expects comes from the yards getting shorter going up, which
             * `yardSpan` already gives. Wing §22a: the cheapest reading wins,
             * and a downward taper plus a sagging bottom is a vessel, not a
             * sail — which is a particularly bad thing to draw on a ship. */
            P._squareSail(
              rec, pos[0], pos[1] + Math.max(ink, L * 0.0055) / 2,
              halfLen * 0.96, drop, halfLen * 0.99,
              canvasCol, shadeCol, ropeCol, ropeW
            );
            drew.sails++;
          }
        } else if (on.sails && cv.set > 0 && (m.sail === 'gaff' || m.sail === 'lug')) {
          const head = mt.at(0.78);
          const throat = mt.at(0.42);
          const footY = mt.foot[1] - L * 0.010;
          const aft = L * 0.19 * (m.sail === 'lug' ? 0.84 : 1) * (1 - cv.reef * 0.35);
          const pts = [
            [throat[0] - L * 0.003, throat[1]],
            [head[0] + aft * 0.72, head[1] + mt.height * 0.06],
            [mt.foot[0] + aft, footY],
            [mt.foot[0] + L * 0.005, footY],
          ];
          P._quad(rec, pts, L * 0.018, canvasCol, ropeCol, ropeW);
          /* ⭐ BATTENS — the whole identity of a lug sail, and the reason the
           * junk is a different picture from every other two-master here. They
           * are a REPEATED element, so their count comes from `fitLines` against
           * the measured paper floor rather than from a number: a portrait gets
           * the full set of battens and a fleet-list thumbnail gets none at all,
           * instead of a smear of grey across the canvas (wing §17c-1). */
          if (m.sail === 'lug') {
            const top = Math.min(pts[0][1], pts[1][1]);
            const bot = Math.max(pts[2][1], pts[3][1]);
            const nb = h.fitLines(bot - top, L, 7);
            for (let b = 1; b < nb; b++) {
              const v = b / nb;
              const yy = top + (bot - top) * v;
              rec.begin();
              rec.moveTo(pts[0][0] + (pts[3][0] - pts[0][0]) * v, yy);
              rec.lineTo(pts[1][0] + (pts[2][0] - pts[1][0]) * v, yy);
              rec.stroke(ropeCol, Math.max(0.8, ink * 0.75));
            }
          }
          /* ⛔ THE GAFF AND THE BOOM ARE WHAT MAKE THIS A GAFF SAIL. Drawn as
           * canvas alone it is a big pale triangle — the cutter, sloop, ketch
           * and schooner all read as Bermuda-rigged yachts on the first fitted
           * sheet, which is the wrong century for this corpus. Two spars, both
           * heavier than the bolt rope, put the sail in its own period. */
          const spar = Math.max(ink, L * 0.0055);
          rec.begin();
          rec.moveTo(pts[0][0], pts[0][1]);
          rec.lineTo(pts[1][0], pts[1][1]);
          rec.stroke(rigInk, spar);
          rec.begin();
          rec.moveTo(pts[3][0] - L * 0.010, pts[3][1]);
          rec.lineTo(pts[2][0] + L * 0.012, pts[2][1]);
          rec.stroke(rigInk, spar);
          drew.sails++;
        } else if (on.sails && cv.set > 0 && m.sail === 'lateen') {
          /* ⭐ THE CROSSING IS THE IDENTITY OF THE RIG, and the first version
           * did not deliver it: with the peak at 0.94 of mast height the yard
           * stood almost vertical, and on the rig sheet the lateen read as two
           * ordinary triangular sails — a straight §22b collision with the lug
           * two cells away. A lateen yard lies at roughly forty-five degrees
           * and reaches DOWN past the mast forward, so the crossing is a wide
           * X that nothing else in the corpus makes. */
          const fwd = [mt.foot[0] - L * 0.20, mt.foot[1] - mt.height * 0.05];
          const aftP = mt.at(0.80);
          rec.begin();
          rec.moveTo(fwd[0], fwd[1]);
          rec.lineTo(aftP[0] + L * 0.075, aftP[1] - mt.height * 0.03);
          /* Heavier than a bolt rope — a lateen yard is a spar as long as the
           * hull and it has to read as one. */
          rec.stroke(rigInk, Math.max(ink * 1.4, L * 0.0072));
          P._quad(rec, [
            fwd,
            [aftP[0] + L * 0.070, aftP[1] - mt.height * 0.025],
            [mt.foot[0] + L * 0.145, mt.foot[1] - L * 0.010],
            [mt.foot[0] - L * 0.055, mt.foot[1] - L * 0.010],
          ], L * 0.016, canvasCol, ropeCol, ropeW);
          drew.sails++;
        }
      }
    }

    //-----------------------------------------------------------------------
    // 4. HEADSAILS.
    //
    // ⛔ THE FIRST VERSION HUNG THESE FROM 0.62-0.78 OF MAST HEIGHT DOWN TO A
    // TACK 0.19 L FORWARD OF THE STEM, WHICH ON A CUTTER IS A TRIANGLE COVERING
    // HALF THE FRAME. A jib is tacked on the BOWSPRIT and its head reaches the
    // TOPMAST, so both ends must be derived from the bowsprit that is actually
    // drawn — not from the hull.
    //-----------------------------------------------------------------------
    let bowsprit = null;
    if (on.rig && M.length) {
      const stem = lofted.stemTop;
      /* ⛔ THE BOWSPRIT IS A HULL PROPERTY, AND IT IS WHAT TELLS A CUTTER FROM A
       * SLOOP. Those two read as the SAME PICTURE on the first fitted contact
       * sheet — same rig, near-identical hull, a straight §22b collision that
       * makes the whole corpus look generated. A real cutter's bowsprit is
       * enormous, running out nearly a third of her length again, and that is
       * the defining feature of the class rather than a decoration. */
      const bl = hull.bowsprit === undefined ? 0.165 : hull.bowsprit;
      bowsprit = [stem[0] - L * bl, stem[1] - L * (0.030 + bl * 0.10)];
      /* A tapering spar, not a line — the same reason a mast tapers. */
      const bw = Math.max(ink, L * 0.0075);
      rec.poly([
        [stem[0] + L * 0.010, stem[1] + L * 0.006],
        [stem[0] + L * 0.010, stem[1] + L * 0.006 - bw],
        [bowsprit[0], bowsprit[1] - bw * 0.45],
        [bowsprit[0], bowsprit[1] + bw * 0.45],
      ], rigInk);

      if (rig.jibs > 0 && on.sails && cv.set > 0 && cv.id !== 'topsails') {
        const fore = M[0];
        for (let j = 0; j < rig.jibs; j++) {
          const u = 0.50 + j * 0.17;
          const head = fore.at(u);
          const tackU = 1 - j * 0.46;
          const tack = [
            stem[0] + (bowsprit[0] - stem[0]) * tackU,
            stem[1] + (bowsprit[1] - stem[1]) * tackU,
          ];
          const clew = [
            fore.foot[0] - L * 0.085,
            fore.foot[1] - L * 0.020 - fore.height * 0.06,
          ];
          P._tri(rec, head, tack, clew, L * 0.012, canvasCol, ropeCol, ropeW);
          drew.sails++;
        }
      }
    }

    //-----------------------------------------------------------------------
    // 5. STANDING RIGGING.
    //
    // ⛔ THE SHROUDS REACH THE LOWER MASTHEAD, NOT THE TRUCK. The first render
    // ran them to 0.82 of total height over a channel 0.075 L wide and hung 49
    // ratlines in each gang: three solid black trapezoids that read as enormous
    // tapered masts, not as rigging. Real lower shrouds stop at the top; the
    // topmast has its own much narrower gang above it.
    //-----------------------------------------------------------------------
    if (on.rig && on.shrouds) {
      /* ⛔ THE GANG ITSELF IS DRAWN IN SECTION 2b, BEFORE THE SAILS. Only the
       * stays are left here, because they need the bowsprit that section 4
       * computes. See the note at 2b for why the order matters. */
      /* Fore-and-aft stays. Cheap, and they tie the masts into one rig instead
       * of leaving three separate poles. */
      for (let i = 1; i < M.length; i++) {
        const a = M[i].at(P.MAST.crosstrees);
        const b = M[i - 1].foot;
        rec.begin();
        rec.moveTo(a[0], a[1]);
        rec.lineTo(b[0] + L * 0.010, b[1] - L * 0.012);
        rec.stroke(rigInk, ink * 0.8);
      }
      /* ⛔ THE FORESTAY WAS THE LOUDEST MARK ON THE WHOLE CONTACT SHEET AND IT
       * WAS WRONG. Run at full ink from the crosstrees to a bowsprit that was
       * only a stub, it read in every one of sixteen cells as a hard diagonal
       * guy-wire crossing the sky — on the cog and the longship it was the
       * dominant feature of the picture. Two fixes: it lands on the bowsprit
       * that is now actually DRAWN, and a rig carrying no headsails stays it to
       * the STEM HEAD instead, which is what a square-single rig really does. */
      if (M.length) {
        const a = M[0].at(P.MAST.crosstrees);
        const land = (rig.jibs > 0 && bowsprit)
          ? bowsprit
          : [lofted.stemTop[0] + L * 0.004, lofted.stemTop[1] - L * 0.004];
        rec.begin();
        rec.moveTo(a[0], a[1]);
        rec.lineTo(land[0], land[1]);
        rec.stroke(rigInk, Math.max(0.8, ink * 0.62));
      }
    }

    //-----------------------------------------------------------------------
    // 6. THE HULL. One continuous outline (wing §22a-1b).
    //-----------------------------------------------------------------------
    rec.poly(lofted.outline, r.css(sch.hull));

    /* Tumblehome — the topsides fall inward above the wale, so the widest part
     * of the hull is below the deck. From broadside that inward curve reads as
     * a darker band along the top of the sheer. */
    {
      const tb = r.css(r.relief(sch.hull, -1, 13));
      const band = [];
      for (let i = 0; i < lofted.deck.length; i++) band.push([lofted.deck[i][0], lofted.deck[i][1]]);
      for (let i = lofted.deck.length - 1; i >= 0; i--) {
        band.push([lofted.deck[i][0], lofted.deck[i][1] + lofted.freeboard * 0.22]);
      }
      rec.poly(band, tb);
    }

    //-----------------------------------------------------------------------
    // 7. THE STERN STRUCTURE.
    //
    // ⛔ WING §17c, CAUGHT ON THE FIRST CONTACT SHEET: the corpus declared
    // `stern: 'castle'` for the galleon, carrack and hulk, and the galleon's own
    // note says "the towering aftercastle is the whole silhouette" — and NOTHING
    // DREW ONE. An id, a field and a note are three statements about a table;
    // none of them is a mark on a bitmap.
    //-----------------------------------------------------------------------
    if (hull.stern === 'castle' || hull.stern === 'transom-high') {
      const t0 = hull.stern === 'castle' ? 0.68 : 0.76;
      const x0 = h.xAt(lofted, t0);
      const x1 = lofted.sternTop[0];
      const yDeck = h.deckAt(lofted, t0);
      const rise = lofted.freeboard * (hull.stern === 'castle' ? 1.05 : 0.62);
      const pts = [
        [x0, yDeck],
        [x0 + (x1 - x0) * 0.30, yDeck - rise * 0.72],
        [x1 + L * 0.004, lofted.sternTop[1] - rise],
        [x1 + L * 0.004, lofted.sternTop[1]],
      ];
      /* ⛔ THE CASTLE WAS FILLED IN THE HULL'S OWN COLOUR AND THEREFORE COULD
       * NOT BE SEEN. Wing §22c, exactly: in a one-colour field two shapes only
       * read as two if their outlines break each other — a castle painted the
       * same tone as the hull it stands on is not a castle, it is a slightly
       * different hull edge. That is why the pass-8 sheet showed the carrack,
       * the great hulk and the cog as three of the same picture while
       * `drew.castle` honestly reported `true` for two of them (§17c: an id, a
       * field and a flag are three statements about a table; none of them is a
       * mark on a bitmap).
       *
       * A castle is a timber structure standing on the hull and catching the
       * light, so it is LIFTED off the hull by a solved separation rather than
       * a multiplier (§22e-1) and outlined all the way round, not just along
       * the top. */
      /* ⛔ THE FILL IS REPORTED, NOT JUST USED. `drew.castle = true` said a
       * castle had been drawn while it was painted in the hull's own colour and
       * therefore invisible on all eight schemes — an honest flag about a mark
       * nobody could see. Reporting the COLOUR lets the suite assert the one
       * property that matters, and a sabotage arm that puts `sch.hull` back
       * then goes red instead of silently passing. */
      const castleFill = r.relief(sch.hull, 1, 16);
      drew.castleFill = castleFill;
      drew.hullFill = sch.hull;
      rec.poly(pts, r.css(castleFill));
      rec.polyPath(pts);
      rec.stroke(r.css(sch.wale), Math.max(ink, L * 0.005));
      /* ⭐ AND A RAILED TOP, WHICH IS THE PART THAT SURVIVES AT SIZE. The fill
       * separates the castle from the hull; a row of pales along its head
       * breaks the SKYLINE, and wing §22a-4 records that a strong silhouette
       * feature outranks every difference beneath it. Nothing else in the
       * corpus puts a broken edge up there. The count is derived from the
       * measured paper floor, so a fleet thumbnail drops the rail instead of
       * smearing it (§22a-2d). */
      {
        const railW = L * 0.009;
        const span = Math.abs(pts[2][0] - pts[1][0]);
        const nr = h.fitLines(span, L, 5, railW);
        for (let i = 0; i < nr; i++) {
          const u = nr === 1 ? 0.5 : i / (nr - 1);
          const rx = pts[1][0] + (pts[2][0] - pts[1][0]) * u;
          const ry = pts[1][1] + (pts[2][1] - pts[1][1]) * u;
          rec.poly([
            [rx - railW * 0.5, ry - railW * 1.5],
            [rx + railW * 0.5, ry - railW * 1.5],
            [rx + railW * 0.5, ry + railW * 0.4],
            [rx - railW * 0.5, ry + railW * 0.4],
          ], r.css(sch.wale));
        }
      }
      drew.castle = true;

      /* ⛔ THE CARRACK'S OWN NOTE SAYS "CASTLES AT BOTH ENDS ... the only hull
       * whose forward sheer rivals its after sheer, which is what tells it from
       * the galleon" — and with only an aftercastle drawn, the carrack, the cog
       * and the great hulk were three near-identical pictures on the contact
       * sheet. Wing §17c again: a note is a statement about a table, not a mark
       * on a bitmap, and here the missing mark WAS the differentiator. */
      if (hull.forecastle) {
        const f1 = h.xAt(lofted, 0.00);
        const f0 = h.xAt(lofted, 0.26);
        const yD = h.deckAt(lofted, 0.26);
        const fRise = lofted.freeboard * 0.78;
        const fp = [
          [f0, yD],
          [f0 + (f1 - f0) * 0.34, yD - fRise * 0.70],
          [lofted.stemTop[0] - L * 0.004, lofted.stemTop[1] - fRise],
          [lofted.stemTop[0] - L * 0.004, lofted.stemTop[1]],
        ];
        rec.poly(fp, r.css(r.relief(sch.hull, 1, 16)));
        rec.polyPath(fp);
        rec.stroke(r.css(sch.wale), Math.max(ink, L * 0.005));
        {
          const railW = L * 0.009;
          const span = Math.abs(fp[2][0] - fp[1][0]);
          const nr = h.fitLines(span, L, 4, railW);
          for (let i = 0; i < nr; i++) {
            const u = nr === 1 ? 0.5 : i / (nr - 1);
            const rx = fp[1][0] + (fp[2][0] - fp[1][0]) * u;
            const ry = fp[1][1] + (fp[2][1] - fp[1][1]) * u;
            rec.poly([
              [rx - railW * 0.5, ry - railW * 1.5],
              [rx + railW * 0.5, ry - railW * 1.5],
              [rx + railW * 0.5, ry + railW * 0.4],
              [rx - railW * 0.5, ry + railW * 0.4],
            ], r.css(sch.wale));
          }
        }
      }

      if (hull.stern === 'castle' && on.quarterGallery) {
        const gw = L * 0.010;
        const n = h.fitLines(Math.abs(x1 - x0) * 0.45, L, 4, gw);
        const glass = r.css(r.relief(sch.hull, -1, 30));
        for (let i = 0; i < n; i++) {
          const gx = x0 + (x1 - x0) * (0.46 + 0.13 * i);
          const gy = lofted.sternTop[1] - rise * (0.44 - 0.02 * i);
          rec.poly([
            [gx, gy], [gx + gw, gy],
            [gx + gw, gy + gw * 1.5], [gx, gy + gw * 1.5],
          ], glass);
        }
      }
    }

    //-----------------------------------------------------------------------
    // 8. WALE, GUNPORTS, PLANKING.
    //-----------------------------------------------------------------------
    let waleY = null;
    if (on.wale) {
      const t = Math.max(ink * 1.2, L * 0.009);
      const drop = lofted.freeboard * 0.60;
      P._sheerBand(rec, lofted, drop, t, r.css(sch.wale));
      waleY = drop;
      if (hull.decks > 1) {
        P._sheerBand(rec, lofted, lofted.freeboard * 0.28, t * 0.8, r.css(sch.wale));
      }
    }

    /* ⛔ GUNPORTS ARE GATED ON THE HULL, NOT ONLY ON SIZE. The first contact
     * sheet put a neat row of eleven gunports on the LONGSHIP, the cog and the
     * carrack — the arithmetic was right and the picture was absurd. A feature
     * that is physically impossible for a class must be refused by the class. */
    if (on.gunports && waleY !== null && hull.guns) {
      const portW = L * 0.0165;
      const t0 = 0.20;
      const t1 = 0.80;
      const n = h.fitLines((t1 - t0) * L, L, 12, portW * 2.0);
      const portInk = r.css(r.relief(sch.wale, -1, 26));
      /* The chequer is a CONTINUOUS band with ports cut through it. The first
       * version drew a separate rectangle behind each port, which read as a row
       * of little gilt picture frames. */
      if (sch.gunstripe) {
        P._sheerBand(rec, lofted, waleY - portW * 1.30, portW * 2.05, r.css(sch.trim));
        P._sheerBand(rec, lofted, waleY - portW * 1.30, Math.max(1, ink * 0.9), r.css(sch.wale));
        P._sheerBand(rec, lofted, waleY + portW * 0.72, Math.max(1, ink * 0.9), r.css(sch.wale));
      }
      for (let i = 0; i < n; i++) {
        const tt = t0 + (t1 - t0) * (n === 1 ? 0.5 : i / (n - 1));
        const px = h.xAt(lofted, tt);
        const py = h.deckAt(lofted, tt) + waleY - portW * 0.88;
        rec.poly([
          [px - portW / 2, py], [px + portW / 2, py],
          [px + portW / 2, py + portW * 1.20], [px - portW / 2, py + portW * 1.20],
        ], portInk);
        drew.gunports++;
      }
    }

    if (on.planking) {
      const seam = r.css(r.relief(sch.hull, -1, 9));
      const nSeam = h.fitLines(lofted.freeboard * 0.9, L, 5);
      for (let i = 1; i <= nSeam; i++) {
        P._sheerBand(rec, lofted, lofted.freeboard * (0.72 + i * 0.20), Math.max(0.8, ink * 0.5), seam);
      }
    }

    //-----------------------------------------------------------------------
    // 8b. STEERING GEAR, SHIELDS, AND A CARVED STEM HEAD.
    //
    // ⛔ THESE EXIST TO BREAK A THREE-WAY COLLISION, AND THEY ARE PLACED BY
    // POSITION RATHER THAN SHAPED BY GEOMETRY. On the pass-8 contact sheet the
    // cog, the longship and the great hulk were the same picture: three
    // medieval hulls drawing from the same three-rig pool, separated in the
    // corpus only by freeboard, rake and endsPower — i.e. by PROPORTION, which
    // wing §22a-5 records as the first thing to go at reading size.
    //
    // §22a-2c is the rule that actually applies: the eye assigns a shape to a
    // part by POSITION first and geometry second, and no amount of reshaping
    // beats an occupied position. Three separate quarry figures each burned
    // three passes learning that. So each mark below goes somewhere nothing
    // else in the corpus puts anything:
    //
    //   stern rudder   a blade and tiller OUTSIDE the after outline
    //   side rudder    a steering oar on the quarter, angled across the sheer
    //   shields        a row along the gunwale — a position no other hull uses
    //   carved head    a spiral above the stem, clear of the hull outline
    //
    // Every one of them resolves through the same LOD table as the rest of the
    // product, so a fleet thumbnail drops them rather than smearing them
    // (§17c-1: a feature that cannot exist at the product's own scale must move
    // to a scale where it can, or be deleted).
    //-----------------------------------------------------------------------
    if (hull.rudder === 'stern' && on.rudder) {
      /* Hung on the sternpost and raked with it, so it reads as part of the
       * ship rather than a fin stuck on afterwards. The submerged part is
       * painted back over by the sea in section 12, which is exactly right —
       * what stays visible is the head, which is what a viewer would see. */
      const sp = lofted.sternTop;
      const foot = lofted.bottom[0];
      const bladeW = L * 0.022;
      const lean = (sp[0] - foot[0]) * 0.9;
      rec.poly([
        [sp[0], sp[1] + lofted.freeboard * 0.30],
        [sp[0] + bladeW, sp[1] + lofted.freeboard * 0.42],
        [foot[0] + lean + bladeW * 1.15, foot[1] + L * 0.006],
        [foot[0] + lean, foot[1] + L * 0.004],
      ], r.css(r.relief(sch.hull, -1, 22)));
      /* The TILLER — a bar coming inboard over the stern. It is the mark that
       * says "this is steering gear" rather than "this is a fin", and it is
       * the only horizontal thing above the after deck on any hull here. */
      const ty = sp[1] + lofted.freeboard * 0.12;
      rec.begin();
      rec.moveTo(sp[0] + bladeW * 0.4, ty);
      rec.lineTo(sp[0] - L * 0.085, ty - lofted.freeboard * 0.10);
      rec.stroke(r.css(sch.wale), Math.max(ink, L * 0.006));
      drew.rudder = 'stern';
    } else if (hull.rudder === 'side' && on.rudder) {
      /* A steering oar, shipped on the quarter and raking aft-and-down. It
       * crosses the sheer, so part of it stands above the deck line — that
       * crossing is the whole cue, and it is why this cannot be mistaken for
       * the stern rudder above even at a glance. */
      const t0 = 0.86;
      const px = h.xAt(lofted, t0);
      const py = h.deckAt(lofted, t0);
      const len = L * 0.16;
      const w = Math.max(ink * 1.4, L * 0.007);
      const tipX = px + len * 0.52;
      const tipY = py + len * 0.86;
      rec.begin();
      rec.moveTo(px - len * 0.16, py - lofted.freeboard * 0.55);
      rec.lineTo(tipX, tipY);
      rec.stroke(r.css(sch.wale), w);
      /* The blade at its foot, wider than the loom, so the oar is an OAR and
       * not a spar that fell overboard. */
      const bw = L * 0.020;
      rec.poly([
        [tipX - bw * 0.30, tipY - bw * 1.5],
        [tipX + bw * 0.80, tipY - bw * 1.1],
        [tipX + bw * 0.55, tipY + bw * 0.9],
        [tipX - bw * 0.55, tipY + bw * 0.4],
      ], r.css(r.relief(sch.hull, -1, 22)));
      drew.rudder = 'side';
    }

    /* ⭐ SHIELDS. Only the longship carries them, and that is the point: wing
     * §22a-4 says only one hull in a corpus may own any given skyline feature,
     * and a row of discs along the gunwale is a silhouette nothing else here
     * makes. Their count comes from `fitLines` against the measured paper floor
     * (§22a-2d), so a portrait gets the full row and a thumbnail gets none
     * rather than a grey smear along the sheer. */
    if (hull.shields && on.shields) {
      const t0 = 0.16;
      const t1 = 0.84;
      const rad = L * 0.019;
      const n = h.fitLines((t1 - t0) * L, L, 12, rad * 2);
      const face = r.css(r.relief(sch.trim, -1, 16));
      const boss = r.css(r.relief(sch.trim, 1, 22));
      for (let i = 0; i < n; i++) {
        const tt = t0 + (t1 - t0) * (n === 1 ? 0.5 : i / (n - 1));
        const px = h.xAt(lofted, tt);
        const py = h.deckAt(lofted, tt) + rad * 0.30;
        rec.begin();
        rec.arc(px, py, rad, 0, Math.PI * 2, false);
        rec.fill(i % 2 === 0 ? face : r.css(sch.trim));
        rec.begin();
        rec.arc(px, py, rad * 0.28, 0, Math.PI * 2, false);
        rec.fill(boss);
        drew.shields++;
      }
    }

    /* A carved stem head — a spiral rising clear of the stem, the way a
     * Scandinavian post is finished. It sits ABOVE the hull outline, which is
     * an unoccupied position on every other class (§22a-2c). */
    if (hull.stemHead === 'carved' && on.figurehead) {
      const st = lofted.stemTop;
      const s = L * 0.030;
      const ink2 = r.css(r.relief(sch.hull, 1, 20));
      rec.begin();
      rec.moveTo(st[0], st[1]);
      rec.bezTo(st[0] - s * 0.30, st[1] - s * 1.7, st[0] + s * 1.5, st[1] - s * 2.3,
        st[0] + s * 1.25, st[1] - s * 1.15);
      rec.bezTo(st[0] + s * 1.10, st[1] - s * 0.55, st[0] + s * 0.35, st[1] - s * 0.70,
        st[0] + s * 0.55, st[1] - s * 1.25);
      rec.stroke(ink2, Math.max(ink * 1.5, L * 0.008));
      drew.stemHead = true;
    }

    //-----------------------------------------------------------------------
    // 9. FOULING at the waterline, and battle damage.
    //-----------------------------------------------------------------------
    {
      const foulH = L * 0.013 * (0.55 + wx.fouling);
      const foul = r.css(r.relief(sch.hull, -1, 18 + Math.round(wx.fouling * 24)));
      rec.save();
      rec.polyPath(lofted.outline);
      rec.clip();
      rec.poly([
        [cx - L, yWater - foulH], [cx + L, yWater - foulH],
        [cx + L, yWater + L], [cx - L, yWater + L],
      ], foul);
      rec.restore();
    }
    //-----------------------------------------------------------------------
    // 9b. PATCHED STRAKES — replaced planking, in new timber against old.
    //
    // ⛔ WING §17c, FOUND ON A STORE PLATE: every weathering state declares a
    // `patch` amount — 0.00, 0.10, 0.26, 0.48, 0.78 — and NOTHING IN THE
    // PRODUCT DREW IT. The field existed, the corpus test asserted the five
    // states, the caption on the states plate said "a battered hull and a
    // furled rig are different pictures, not dimmer ones", and the picture
    // underneath showed five identical vessels. An id, a number and a test are
    // three statements about a table; none of them is a mark on a bitmap.
    //
    // ⭐ AND DRAWING IT FIXES THE PLATE AS WELL AS THE PRODUCT, which §17c
    // records as the usual shape: the missing content and the weak image are
    // the same hole. Fouling is a band 0.013 L deep — about one and a half
    // pixels at plate size — so it could never have carried the weathering
    // axis on a catalogue plate however dark it was made. A replaced strake is
    // an AREA, so it reads exactly where the band cannot.
    //-----------------------------------------------------------------------
    if (wx.patch > 0 && on.planking) {
      const rng = r.rng(r.hash((spec.seed || spec.hull) + 'patch'));
      /* Count derived from the amount, not typed, and floored so any non-zero
       * patch level draws at least one — a "Worked" hull with 0.10 should show
       * one replaced plank rather than nothing. */
      const n = Math.max(1, Math.round(wx.patch * 7));
      /* New timber is LIGHTER than weathered topsides; a tarred repair on a
       * pale hull is darker. Solved against the hull rather than multiplied,
       * so it separates on every scheme (wing §22e-1). */
      const dir = r.lum(sch.hull) > 128 ? -1 : 1;
      const fresh = r.css(r.relief(sch.hull, dir, 28));
      /* A caulked seam down each side of the repair — a replaced plank is let
       * in between two others and the joint is payed with pitch, so the seam
       * is the darkest thing on it. It is also what stops a patch reading as a
       * smudge at small sizes, where the fill alone is a few pixels. */
      const seam = r.css(r.relief(sch.hull, -1, 46));
      for (let i = 0; i < n; i++) {
        const t0 = 0.10 + rng() * 0.74;
        const tw = 0.045 + rng() * 0.070;
        const t1 = Math.min(0.96, t0 + tw);
        const yTop = lofted.freeboard * (0.10 + rng() * 0.42);
        const yBot = yTop + lofted.freeboard * (0.22 + rng() * 0.26);
        const pts = [];
        const STEPS = 6;
        for (let s = 0; s <= STEPS; s++) {
          const tt = t0 + (t1 - t0) * (s / STEPS);
          pts.push([h.xAt(lofted, tt), h.deckAt(lofted, tt) + yTop]);
        }
        for (let s = STEPS; s >= 0; s--) {
          const tt = t0 + (t1 - t0) * (s / STEPS);
          pts.push([h.xAt(lofted, tt), h.deckAt(lofted, tt) + yBot]);
        }
        rec.poly(pts, fresh);
        rec.polyPath(pts);
        rec.stroke(seam, Math.max(0.8, ink * 0.8));
        drew.patches++;
      }
    }

    if (wx.shot > 0 && on.gunports) {
      const rng = r.rng(r.hash((spec.seed || spec.hull) + 'shot'));
      const hole = r.css(r.relief(sch.hull, -1, 40));
      for (let i = 0; i < wx.shot; i++) {
        const tt = 0.20 + rng() * 0.60;
        const px = h.xAt(lofted, tt);
        const py = h.deckAt(lofted, tt) + lofted.freeboard * (0.30 + rng() * 0.55);
        const rr = L * (0.004 + rng() * 0.004);
        rec.begin();
        rec.arc(px, py, rr, 0, Math.PI * 2, false);
        rec.fill(hole);
      }
    }

    //-----------------------------------------------------------------------
    // 10. FIGUREHEAD — a carved MASS, not a portrait subject. See §22a-5 and
    //     the note in ShipwrightHull's SOLIDS table.
    //-----------------------------------------------------------------------
    if (on.figurehead) {
      const stem = lofted.stemTop;
      const s = L * 0.026;
      rec.begin();
      rec.moveTo(stem[0] + s * 0.20, stem[1] + s * 0.55);
      rec.quadTo(stem[0] - s * 1.10, stem[1] + s * 0.10, stem[0] - s * 0.85, stem[1] - s * 0.70);
      rec.quadTo(stem[0] - s * 0.15, stem[1] - s * 0.40, stem[0] + s * 0.20, stem[1] + s * 0.55);
      rec.close();
      rec.fill(r.css(sch.trim));
    }

    //-----------------------------------------------------------------------
    // 11. ENSIGN.
    //-----------------------------------------------------------------------
    if (on.rig && M.length) {
      const mt = M[M.length - 1];
      const p = mt.at(1.0);
      const fw = L * 0.062;
      const fh = L * 0.026;
      const wave = fh * 0.30;
      rec.begin();
      rec.moveTo(p[0], p[1]);
      rec.quadTo(p[0] + fw * 0.5, p[1] - wave, p[0] + fw, p[1] + wave * 0.4);
      rec.lineTo(p[0] + fw, p[1] + fh + wave * 0.4);
      rec.quadTo(p[0] + fw * 0.5, p[1] + fh - wave, p[0], p[1] + fh);
      rec.close();
      rec.fill(r.css(sch.trim));
    }

    //-----------------------------------------------------------------------
    // 12. ⛔ SINK HER. The underwater body must not be visible.
    //
    //     On the first contact sheet the whole below-water mass of every hull
    //     was drawn over the sea, so sixteen vessels sat ON the water like
    //     paper cut-outs. Painting the sea back over everything below the load
    //     waterline is the whole fix, and it also gives the boot-top its edge.
    //-----------------------------------------------------------------------
    if (o.sea) {
      rec.poly([
        [cx - L, yWater], [cx + L, yWater],
        [cx + L, yWater + L], [cx - L, yWater + L],
      ], r.css(o.sea));
      /* A short shadow under the hull so she displaces water rather than
       * being pasted onto it. */
      const sh = r.css(r.relief(o.sea, -1, 14));
      rec.begin();
      rec.ellipse(cx, yWater + L * 0.008, L * 0.50, L * 0.012, 0);
      rec.fill(sh);
    }

    return drew;
  };

  //=========================================================================
  // Private drawing helpers.
  //=========================================================================

  /**
   * A band following the sheer, at a constant drop below the deck line.
   * @param {object} rec Recorder.
   * @param {object} lofted A lofted hull.
   * @param {number} drop Distance below the deck line.
   * @param {number} t Band thickness.
   * @param {string} col CSS fill.
   */
  P._sheerBand = function (rec, lofted, drop, t, col) {
    const band = [];
    for (let i = 0; i < lofted.deck.length; i++) {
      band.push([lofted.deck[i][0], lofted.deck[i][1] + drop]);
    }
    for (let i = lofted.deck.length - 1; i >= 0; i--) {
      band.push([lofted.deck[i][0], lofted.deck[i][1] + drop + t]);
    }
    rec.poly(band, col);
  };

  /**
   * A square sail: bellied canvas with a lee shadow and a bolt rope.
   * @param {object} rec Recorder.
   * @param {number} cx Yard centre x.
   * @param {number} yTop Yard y.
   * @param {number} halfTop Half the head width.
   * @param {number} drop Sail depth.
   * @param {number} halfFoot Half the foot width.
   * @param {string} cloth CSS fill.
   * @param {string} shade CSS fill for the lee side.
   * @param {string} rope CSS stroke for the bolt rope.
   * @param {number} ropeW Bolt rope width.
   */
  P._squareSail = function (rec, cx, yTop, halfTop, drop, halfFoot, cloth, shade, rope, ropeW) {
    const b = drop * 0.16;
    /**
     * Trace the sail. Kept as one function so the fill, the clip and the bolt
     * rope cannot drift apart (wing §11: prefer a shape where two paths that
     * must agree agree by construction).
     */
    const trace = function () {
      rec.begin();
      rec.moveTo(cx - halfTop, yTop);
      rec.bezTo(
        cx - halfTop - b * 0.26, yTop + drop * 0.44,
        cx - halfFoot - b * 0.18, yTop + drop * 0.82,
        cx - halfFoot, yTop + drop
      );
      /* ⛔ THE FOOT SAGS. It used to be pulled UP at the centre by a control
       * point ABOVE its own endpoints, which cuts a shallow V out of the bottom
       * of the sail — and a pale quadrilateral with a notch bitten out of its
       * foot is not a sail, it is two pennants. Read at size on `--big cog` it
       * was unmistakable. A set sail's foot hangs in a catenary between the
       * clews and bellies DOWNWARD; the sign of this one number is the whole
       * difference (wing §22a: the eye takes the cheapest reading, and two pale
       * masses either side of a vertical are two flags). */
      rec.quadTo(cx, yTop + drop + drop * 0.15, cx + halfFoot, yTop + drop);
      rec.bezTo(
        cx + halfFoot + b * 0.20, yTop + drop * 0.80,
        cx + halfTop + b * 0.28, yTop + drop * 0.42,
        cx + halfTop, yTop
      );
      rec.close();
    };
    trace();
    rec.fill(cloth);
    /* ⛔ AND THE LEE SHADE MUST NOT LAND ON THE CENTRELINE. Its boundary began
     * at `halfTop * 0.06` — dead centre, exactly where the mast stands and
     * exactly where the shroud gang used to be drawn on top — so three separate
     * marks stacked into one hard vertical seam down the middle of every square
     * sail in the corpus. That seam, not the shape, is what made the cog read
     * as two flags on a stick.
     *
     * The shade now starts well outboard at 0.40 and sweeps to the clew, so the
     * lit cloth keeps the centre and the shaded part is a crescent along the
     * leech — which is what a bellied sail actually does with the light. Wing
     * §22c: two shapes read as two only if their outlines break each other, and
     * a tonal edge on the axis of symmetry breaks the sail exactly in half. */
    rec.save();
    trace();
    rec.clip();
    rec.begin();
    rec.moveTo(cx + halfTop * 0.40, yTop);
    rec.quadTo(cx + halfTop * 0.62, yTop + drop * 0.58, cx + halfFoot * 0.88, yTop + drop + drop * 0.06);
    rec.lineTo(cx + halfTop * 1.4, yTop + drop * 1.4);
    rec.lineTo(cx + halfTop * 1.4, yTop);
    rec.close();
    rec.fill(shade);
    rec.restore();
    trace();
    rec.stroke(rope, ropeW);
  };

  /**
   * A four-sided fore-and-aft sail, filled and roped.
   * @param {object} rec Recorder.
   * @param {number[][]} p Four corners, in order.
   * @param {number} belly Bow of the leech, px.
   * @param {string} cloth CSS fill.
   * @param {string} rope CSS stroke.
   * @param {number} ropeW Stroke width.
   */
  P._quad = function (rec, p, belly, cloth, rope, ropeW) {
    const trace = function () {
      rec.begin();
      rec.moveTo(p[0][0], p[0][1]);
      rec.lineTo(p[1][0], p[1][1]);
      rec.quadTo((p[1][0] + p[2][0]) / 2 + belly, (p[1][1] + p[2][1]) / 2, p[2][0], p[2][1]);
      rec.quadTo((p[2][0] + p[3][0]) / 2, (p[2][1] + p[3][1]) / 2 + belly * 0.35, p[3][0], p[3][1]);
      rec.close();
    };
    trace(); rec.fill(cloth);
    trace(); rec.stroke(rope, ropeW);
  };

  /**
   * A triangular headsail, filled and roped.
   * @param {object} rec Recorder.
   * @param {number[]} head Upper point.
   * @param {number[]} tack Forward lower point.
   * @param {number[]} clew Aft lower point.
   * @param {number} belly Bow of the leech, px.
   * @param {string} cloth CSS fill.
   * @param {string} rope CSS stroke.
   * @param {number} ropeW Stroke width.
   */
  P._tri = function (rec, head, tack, clew, belly, cloth, rope, ropeW) {
    const trace = function () {
      rec.begin();
      rec.moveTo(head[0], head[1]);
      rec.lineTo(tack[0], tack[1]);
      rec.quadTo((tack[0] + clew[0]) / 2, (tack[1] + clew[1]) / 2 + belly * 0.30, clew[0], clew[1]);
      rec.quadTo((clew[0] + head[0]) / 2 + belly, (clew[1] + head[1]) / 2, head[0], head[1]);
      rec.close();
    };
    trace(); rec.fill(cloth);
    trace(); rec.stroke(rope, ropeW);
  };
}());

//=== BROADSIDE DAMAGE LAYER (hand-written, kept across rebuilds) ===
/*
 * Battle damage drawn INTO a ship, as structure rather than stickers: shot holes in her side with splintered rims, a
 * topmast shot away and hanging over the side, canvas in rags, every mast gone by the board, scorched planking where a
 * fire burns. Everything is placed from the ship's OWN geometry (the lofted hull, the rig plan's mastheads and yards)
 * through the same functions the portrait uses, so a hole is always on her side and a fallen topmast always hangs from
 * her own masthead, whatever the hull or rig (wing §11b: positions derive from the figure's own joints).
 *
 * Damage is drawn when the state CHANGES, into a bitmap the scene keeps (Broadside.js bakes once per event, never per
 * frame). Holes ACCUMULATE: hole i is always in the same place for the same ship, so a ship at 40% hull shows the
 * holes she had at 70% plus more, never a reshuffle.
 */
(function () {
  'use strict';
  var NS = CSAF.BroadsideShip;
  var D = NS.Damage = {};

  /** Damage thresholds on the rig, shared with BroadsideCore's events (topmast < 0.6, rags < 0.3, dismasted < 0.15). */
  D.RIG = { topmast: 0.6, rags: 0.3, dismasted: 0.15 };
  /**
   * Shot holes at zero hull, per 100 px of length (scaled so a small far ship is not a pepper pot). LOOKED AT in the
   * engine 2026-10-11: 17.6 per 100 px (74 on the 420 px foreground ship) read as a leopard's spots; 5 reads as a
   * battered side with the planking still between the holes.
   */
  D.HOLES_PER_100PX = 5;
  /**
   * How many holes a ship of length L shows at hull fraction `hull` (0..1). The ONE place this is computed: the scene
   * keys its rebake on it, the draw places them (wing §11a: a second copy of a constant wins).
   */
  D.holesTotal = function (L) { return Math.max(3, Math.round(L / 100 * D.HOLES_PER_100PX)); };
  D.holes = function (L, hull) { return Math.round(D.holesTotal(L) * (1 - Math.max(0, Math.min(1, hull)))); };

  /**
   * The drawable damage state of a ship from BroadsideCore's ship record (or any {hull,rig,crew,max,fire}).
   * @param {object} s A BroadsideCore ship.
   * @returns {{hull:number, rig:number, crew:number, fire:boolean, topmast:boolean, rags:boolean, dismasted:boolean}}
   */
  D.state = function (s) {
    var f = function (k) { return s && s.max && s.max[k] > 0 ? Math.max(0, Math.min(1, s[k] / s.max[k])) : 1; };
    var rig = f('rig');
    return { hull: f('hull'), rig: rig, crew: f('crew'), fire: !!(s && s.fire), topmast: rig < D.RIG.topmast, rags: rig < D.RIG.rags, dismasted: rig < D.RIG.dismasted };
  };

  /**
   * The square-sail rectangles of a ship, from the same rig geometry and the same set/reef rule the portrait draws with.
   * @returns {Array<{mast:number, j:number, x:number, y:number, half:number, drop:number}>}
   */
  D.sails = function (spec, cx, yW, L) {
    var C = NS.Corpus, H = NS.Hull, P = NS.Portrait;
    var hull = C.hull(spec.hull), rig = C.rig(spec.rig), cv = C.canvas(spec.canvas || 'full');
    if (!hull || !rig || !cv) return [];
    var M = P._rigGeom(rig, H.loft(hull, cx, yW, L), L), out = [];
    for (var i = 0; i < M.length; i++) {
      var mt = M[i], m = mt.m;
      if (m.sail === 'square' && m.yards > 0) {
        for (var j = 0; j < m.yards && j < P.MAST.yards.length; j++) {
          var setThis = cv.id === 'topsails' ? (j === 0 ? 0 : 1) : cv.set;
          if (setThis <= 0) continue;
          var v = P.MAST.yards[j], nextV = (j + 1 < m.yards && j + 1 < P.MAST.yards.length) ? P.MAST.yards[j + 1] : v + 0.20;
          var pos = mt.at(v), drop = (nextV - v) * mt.height * 0.84 * setThis * (1 - cv.reef * 0.42);
          out.push({ mast: i, j: j, x: pos[0], y: pos[1], half: mt.yardHalf(j) * 0.96, drop: drop });
        }
      } else if (cv.set > 0 && (m.sail === 'gaff' || m.sail === 'lug' || m.sail === 'lateen')) {
        // a fore-and-aft sail: its box, aft of the mast, between the throat and the foot
        var head = mt.at(0.78), aft = L * 0.19 * (1 - cv.reef * 0.35);
        out.push({ mast: i, j: 0, x: mt.foot[0] + aft * 0.5, y: head[1], half: aft * 0.5, drop: mt.foot[1] - head[1] - L * 0.01, foreAft: true });
      }
    }
    return out;
  };

  /** the mast that loses her topmast first: the tallest (the mainmast on a ship) */
  function mainMast(M) { var k = 0; for (var i = 1; i < M.length; i++) if (M[i].height > M[k].height) k = i; return k; }

  /** a jagged hole, as a closed path around (x, y) */
  function holePath(ctx, rng, x, y, r) {
    var n = 7 + Math.floor(rng() * 4);
    ctx.beginPath();
    for (var k = 0; k < n; k++) {
      var a = (k / n) * Math.PI * 2, rr = r * (0.55 + rng() * 0.75);
      if (k === 0) ctx.moveTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr * 0.8); else ctx.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr * 0.8);
    }
    ctx.closePath();
  }

  /**
   * Draw a ship and her damage into a 2D context. The portrait itself is drawn UNCHANGED (the op stream equals
   * Shipwright's, ships.test.js); damage is cut out of and painted onto what it drew.
   * ⛔ The context must hold ONLY this ship (a bitmap of her own): rigging damage erases with destination-out, which
   * would cut through anything already under her.
   * @param {CanvasRenderingContext2D} ctx
   * @param {object} spec {hull, rig, scheme, weather, canvas, seed}
   * @param {number} cx @param {number} yW @param {number} L
   * @param {object} dmg D.state(...) or null for none
   * @returns {object} what was drawn: {drawn, holes, topmast, rags, dismasted, scorch, deckPoints:[[x,y]...]}
   */
  D.draw = function (ctx, spec, cx, yW, L, dmg) {
    var R = NS.Render, C = NS.Corpus, H = NS.Hull, P = NS.Portrait;
    var drew = P.draw(R.Recorder(ctx), spec, cx, yW, L, {});
    var out = { drawn: !!(drew && drew.drawn), holes: 0, topmast: false, rags: 0, dismasted: false, scorch: 0, deckPoints: [] };
    if (!out.drawn) return out;
    var hull = C.hull(spec.hull), rig = C.rig(spec.rig), sch = C.scheme(spec.scheme), lofted = H.loft(hull, cx, yW, L);
    var M = P._rigGeom(rig, lofted, L), seed = String(spec.seed || spec.hull);
    // deck points for fire and boarding effects (Broadside.js animates those), always reported
    for (var t = 0.2; t <= 0.8 + 1e-9; t += 0.15) out.deckPoints.push([H.xAt(lofted, t), H.deckAt(lofted, t)]);
    if (!dmg || (!(dmg.hull < 1) && !dmg.fire && !dmg.topmast && !dmg.rags && !dmg.dismasted)) return out;   // an undamaged ship is the plain portrait, op for op
    // LOOKED AT: a cream rim read as yellow biscuits on oxblood; raw oak splinters are a mid brown, separated from the paint
    var holeCol = R.css(R.relief(sch.hull, -1, 70)), rimCol = R.css(R.separateFrom([142, 108, 70], sch.hull, 26));
    var rigInk = R.css(R.relief(sch.wale, -1, 18)), cloth = R.css(sch.canvas), clothShade = R.css(R.relief(sch.canvas, -1, 26));

    // 1. SHOT HOLES in her side, accumulating: the first n of a fixed seeded sequence
    var total = D.holesTotal(L), n = D.holes(L, dmg.hull);
    var rng = R.rng(R.hash(seed + '|broadside-holes'));
    ctx.save();
    ctx.beginPath(); for (var q = 0; q < lofted.outline.length; q++) { var p = lofted.outline[q]; if (q === 0) ctx.moveTo(p[0], p[1]); else ctx.lineTo(p[0], p[1]); } ctx.closePath(); ctx.clip();
    for (var i = 0; i < total; i++) {
      var tt = 0.08 + rng() * 0.84, dy = 0.18 + rng() * 0.62, rr = L * (0.0068 + rng() * 0.0072), sp = rng();   // draw every value so hole i is fixed
      if (i >= n) continue;
      var hx = H.xAt(lofted, tt), hy = H.deckAt(lofted, tt) + lofted.freeboard * dy;
      // splintered rim first (raw timber, lighter than any paint), then the dark hole over it
      ctx.fillStyle = rimCol; holePath(ctx, rng, hx, hy, rr * 1.55); ctx.fill();
      ctx.fillStyle = holeCol; holePath(ctx, rng, hx, hy, rr); ctx.fill();
      // two or three splinters thrown out of the hole, the way the ball came in
      ctx.strokeStyle = rimCol; ctx.lineWidth = Math.max(0.8, L * 0.0016);
      for (var s = 0; s < 3; s++) { var a = -0.4 + sp * 0.8 + s * 2.1; ctx.beginPath(); ctx.moveTo(hx + Math.cos(a) * rr, hy + Math.sin(a) * rr); ctx.lineTo(hx + Math.cos(a) * rr * 2.3, hy + Math.sin(a) * rr * 1.9); ctx.stroke(); }
      out.holes++;
    }
    // 1b. scorch: a fire blackens the planking above where it burns
    if (dmg.fire) {
      var srng = R.rng(R.hash(seed + '|broadside-scorch'));
      for (var f = 0; f < 3; f++) {
        var ft = 0.3 + srng() * 0.4, fx = H.xAt(lofted, ft), fy = H.deckAt(lofted, ft);
        var g = ctx.createRadialGradient(fx, fy, 0, fx, fy, L * 0.07);
        g.addColorStop(0, 'rgba(18,12,8,0.75)'); g.addColorStop(1, 'rgba(18,12,8,0)');
        ctx.fillStyle = g; ctx.fillRect(fx - L * 0.07, fy - L * 0.01, L * 0.14, lofted.freeboard * 1.2);
        out.scorch++;
      }
    }
    ctx.restore();

    // 2. RIG DAMAGE: cut away what is gone, then draw what is left hanging
    var sails = D.sails(spec, cx, yW, L), wrng = R.rng(R.hash(seed + '|broadside-rig'));
    var cutMasts = [];
    if (dmg.dismasted) { for (var mi = 0; mi < M.length; mi++) cutMasts.push({ i: mi, v: 0.16 + wrng() * 0.10 }); out.dismasted = true; }
    else if (dmg.topmast && M.length) { cutMasts.push({ i: mainMast(M), v: 0.50 + wrng() * 0.08 }); out.topmast = true; }
    var mw = Math.max(1.2, L * 0.0115);
    ctx.save(); ctx.globalCompositeOperation = 'destination-out'; ctx.fillStyle = '#000';
    if (out.dismasted) {
      // everything above the rail goes by the board: masts, headsails, stays, bowsprit (LOOKED AT: a per-mast cut left
      // the jib standing as a flat-topped trapezoid in mid-air, and the forestay ending in the sky)
      var off = L * 0.014;
      ctx.beginPath(); ctx.moveTo(cx - L, yW - L * 2); ctx.lineTo(cx - L, lofted.deck[0][1] - off);
      for (var dq = 0; dq < lofted.deck.length; dq++) ctx.lineTo(lofted.deck[dq][0], lofted.deck[dq][1] - off);
      ctx.lineTo(cx + L, lofted.deck[lofted.deck.length - 1][1] - off); ctx.lineTo(cx + L, yW - L * 2); ctx.closePath(); ctx.fill();
    } else {
      for (var e = 0; e < cutMasts.length; e++) {
        // erase everything of this mast above the cut, across the width of its own yards
        var me = M[cutMasts[e].i], ce = me.at(cutMasts[e].v), reach = Math.max(me.yardHalf(0), L * 0.12) * 1.04;
        ctx.beginPath(); ctx.moveTo(ce[0] - reach, ce[1]); ctx.lineTo(ce[0] + reach, ce[1]); ctx.lineTo(ce[0] + reach, ce[1] - me.height * 1.2); ctx.lineTo(ce[0] - reach, ce[1] - me.height * 1.2); ctx.closePath(); ctx.fill();
      }
    }
    ctx.restore();
    for (var c = 0; c < cutMasts.length; c++) {
      var mt = M[cutMasts[c].i], cut = mt.at(cutMasts[c].v);
      // the lower mast, redrawn where the board-sweep took it (dismasted only), then the stump's splintered top
      if (out.dismasted) { ctx.fillStyle = rigInk; ctx.beginPath(); ctx.moveTo(mt.foot[0] - mw * 0.6, mt.foot[1]); ctx.lineTo(cut[0] - mw * 0.6, cut[1] + 1); ctx.lineTo(cut[0] + mw * 0.6, cut[1] + 1); ctx.lineTo(mt.foot[0] + mw * 0.6, mt.foot[1]); ctx.closePath(); ctx.fill(); }
      ctx.fillStyle = rigInk; ctx.beginPath(); ctx.moveTo(cut[0] - mw * 0.6, cut[1] + 1); ctx.lineTo(cut[0] - mw * 0.5, cut[1] - mw * 1.6); ctx.lineTo(cut[0] - mw * 0.1, cut[1] - mw * 0.6); ctx.lineTo(cut[0] + mw * 0.2, cut[1] - mw * 2.2); ctx.lineTo(cut[0] + mw * 0.6, cut[1] + 1); ctx.closePath(); ctx.fill();
      // the wreckage: the lost spar hangs from the stump over the side, its canvas dragging (it falls aft, to leeward)
      var len = mt.height * (1 - cutMasts[c].v) * (out.dismasted ? 0.75 : 0.9), ang = 0.95 + wrng() * 0.35;
      var ex = cut[0] + Math.sin(ang) * len, ey = cut[1] + Math.cos(ang) * len * 0.92;
      var deckY = H.deckAt(lofted, Math.max(0, Math.min(1, (ex - (cx - L / 2)) / L)));
      if (ey > deckY + lofted.freeboard * 0.6) ey = deckY + lofted.freeboard * 0.6;   // she hangs over the side, not through the hull
      // the sail goes with the spar: a crumpled sheet between the spar and the rail
      ctx.fillStyle = cloth; ctx.strokeStyle = clothShade; ctx.lineWidth = Math.max(0.8, L * 0.0018);
      ctx.beginPath(); ctx.moveTo(cut[0] + (ex - cut[0]) * 0.2, cut[1] + (ey - cut[1]) * 0.2);
      ctx.quadraticCurveTo(cut[0] + (ex - cut[0]) * 0.6 + L * 0.02, cut[1] + (ey - cut[1]) * 0.35 + L * 0.03, ex - L * 0.005, ey - L * 0.004);
      ctx.lineTo(ex - L * 0.035, Math.min(ey + L * 0.03, deckY + lofted.freeboard));
      ctx.quadraticCurveTo(cut[0] + (ex - cut[0]) * 0.4, deckY - L * 0.01, cut[0] + (ex - cut[0]) * 0.1, cut[1] + (deckY - cut[1]) * 0.55);
      ctx.closePath(); ctx.fill(); ctx.stroke();
      // the spar itself
      ctx.strokeStyle = rigInk; ctx.lineWidth = mw * 0.8; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(cut[0], cut[1]); ctx.lineTo(ex, ey); ctx.stroke();
      // loose rigging trailing from the wreck
      ctx.lineWidth = Math.max(0.6, L * 0.0012);
      for (var k = 0; k < 3; k++) { var u = 0.3 + k * 0.25, lx = cut[0] + (ex - cut[0]) * u, ly = cut[1] + (ey - cut[1]) * u; ctx.beginPath(); ctx.moveTo(lx, ly); ctx.quadraticCurveTo(lx + L * 0.015, ly + L * 0.04, lx - L * 0.01 + k * L * 0.012, deckY + L * 0.004); ctx.stroke(); }
    }
    // 3. RAGS: canvas split into strips from the foot, a shot hole or two, a frayed foot.
    // LOOKED AT 2026-10-11: two to four big round holes over a sawtooth foot read as a FACE on every sail (eyes over
    // teeth, the sea showing through). Torn canvas splits ALONG the cloths, so the tears are long thin wedges running up
    // from the foot, the holes are small and never level with each other, and the foot frays finely.
    if (dmg.rags) {
      ctx.save(); ctx.globalCompositeOperation = 'destination-out'; ctx.fillStyle = '#000';
      var rrng = R.rng(R.hash(seed + '|broadside-rags'));
      for (var si = 0; si < sails.length; si++) {
        var sl = sails[si], gone = false;
        for (var cc = 0; cc < cutMasts.length; cc++) if (cutMasts[cc].i === sl.mast && sl.y < M[sl.mast].at(cutMasts[cc].v)[1]) gone = true;
        if (gone) continue;
        var x0 = sl.x - sl.half, w = sl.half * 2, yF = sl.y + sl.drop;
        // long tears up from the foot, each a thin wedge leaning a little, spread unevenly across the sail
        var nt = 2 + Math.floor(rrng() * 2), lane = rrng();
        for (var tt2 = 0; tt2 < nt; tt2++) {
          var fx = x0 + w * (0.12 + ((lane + tt2 * 0.37 + rrng() * 0.12) % 1) * 0.76), tw = w * (0.035 + rrng() * 0.04), th = sl.drop * (0.35 + rrng() * 0.4), lean = (rrng() - 0.5) * w * 0.08;
          ctx.beginPath(); ctx.moveTo(fx - tw, yF + 4); ctx.lineTo(fx + lean - tw * 0.15, yF - th * 0.6); ctx.lineTo(fx + lean * 1.4, yF - th); ctx.lineTo(fx + lean + tw * 0.2, yF - th * 0.55); ctx.lineTo(fx + tw, yF + 4); ctx.closePath(); ctx.fill(); out.rags++;
        }
        // one or two small shot holes, the second never level with the first
        var nh = 1 + Math.floor(rrng() * 2), hy0 = -1;
        for (var h2 = 0; h2 < nh; h2++) {
          var hx2 = sl.x + (rrng() * 2 - 1) * sl.half * 0.6, hy2 = sl.y + sl.drop * (h2 === 0 ? 0.18 + rrng() * 0.3 : 0.55 + rrng() * 0.2), r2 = Math.min(sl.half, sl.drop) * (0.05 + rrng() * 0.04);
          if (h2 && Math.abs(hy2 - hy0) < r2 * 4) hy2 = hy0 + r2 * 4;
          hy0 = hy2; holePath(ctx, rrng, hx2, hy2, r2); ctx.fill(); out.rags++;
        }
        // a frayed foot: many small notches, not teeth
        var notches = 12 + Math.floor(rrng() * 6);
        ctx.beginPath(); ctx.moveTo(x0, yF + 4);
        for (var tk = 0; tk <= notches; tk++) { var xx = x0 + w * tk / notches; ctx.lineTo(xx, yF + 4); ctx.lineTo(xx + w / notches * (0.3 + rrng() * 0.4), yF - sl.drop * (0.015 + rrng() * 0.045)); }
        ctx.lineTo(x0 + w, yF + 4); ctx.closePath(); ctx.fill();
      }
      ctx.restore();
    }
    return out;
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.BroadsideShip;
