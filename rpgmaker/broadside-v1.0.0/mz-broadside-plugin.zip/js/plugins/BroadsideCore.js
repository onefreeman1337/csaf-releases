/*:
 * @target MZ
 * @plugindesc Broadside 1/4 - the rules of a ship duel: range, the weather gauge, the roll, three damage tracks. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * BroadsideCore.js - part of Broadside. Enable it with the other Broadside files (any order). It has no commands or
 * parameters of its own; Broadside.js reads it.
 *
 * Every line of this plugin was written with AI assistance.
 */
/*
 * The duel as PURE state transitions, so it runs in Node exactly as in MZ and a balance probe can play thousands of
 * fights. Never Math.random: a seeded generator whose state is a number on the battle. The animation READS this model;
 * the model never reads the animation (wing §11).
 */
var BroadsideCore = (function () {
  'use strict';

  /* ------------------------------------------------------------ seeded randomness */
  function mix(a, b) { var h = Math.imul((a >>> 0) ^ 0x9e3779b9, 0x85ebca6b) ^ (b >>> 0); h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35); return (h ^ (h >>> 16)) >>> 0; }
  /** mulberry32, state on the object */
  function rand(r) { var t = r.s = (r.s + 0x6D2B79F5) | 0; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }

  /* ------------------------------------------------------------ ships */
  /** ship classes: guns per side, crew, hull strength, rig strength, sailing (speed and pointing) */
  var CLASSES = {
    cutter: { guns: 4, crew: 40, hull: 40, rig: 30, sail: 1.00 },
    sloop: { guns: 8, crew: 70, hull: 60, rig: 40, sail: 0.92 },
    brig: { guns: 10, crew: 100, hull: 80, rig: 55, sail: 0.85 },
    xebec: { guns: 8, crew: 120, hull: 60, rig: 45, sail: 0.95 },
    frigate: { guns: 16, crew: 220, hull: 140, rig: 90, sail: 0.80 },
    galleon: { guns: 14, crew: 260, hull: 180, rig: 100, sail: 0.55 },   // a treasure ship: a deep hull, few guns, the prize a frigate hunts (v0.5 probe: at 20 guns a skilled frigate won 6%)
    'ship-of-the-line': { guns: 34, crew: 600, hull: 320, rig: 150, sail: 0.50 },
  };
  /** every hull the ship generator can draw fights as one of the seven classes (a junk as a brig, a hulk as a galleon) */
  var CLASS_OF_HULL = { cutter: 'cutter', sloop: 'sloop', ketch: 'sloop', brig: 'brig', schooner: 'brig', barque: 'frigate', frigate: 'frigate', 'ship-of-the-line': 'ship-of-the-line', galleon: 'galleon', carrack: 'galleon', cog: 'sloop', longship: 'cutter', xebec: 'xebec', junk: 'brig', galley: 'xebec', hulk: 'galleon' };
  /** the fighting class for a hull id or a class id; unknown falls to a sloop */
  function classOf(id) { return CLASSES[id] ? id : (CLASS_OF_HULL[id] || 'sloop'); }
  /** a ship at the start of a fight, from its class (unknown classes fall to a sloop, never to nothing) */
  function makeShip(id, cls) {
    var k = classOf(cls), c = CLASSES[k];
    return { id: id, cls: k, guns: c.guns, sail: c.sail, max: { hull: c.hull, rig: c.rig, crew: c.crew }, hull: c.hull, rig: c.rig, crew: c.crew, fire: false, events: [] };
  }
  /** a track as a fraction 0..1 */
  function frac(s, k) { return s.max[k] > 0 ? Math.max(0, s[k]) / s.max[k] : 0; }
  /** a ship's effective sailing: a shot-away rig slows her (the topmast and the canvas go with it) */
  function speed(s) { return s.sail * (0.35 + 0.65 * frac(s, 'rig')); }
  /** under 15% rig she has no canvas to steer by: she lies where the sea puts her */
  function dismasted(s) { return frac(s, 'rig') < 0.15; }

  /* ------------------------------------------------------------ the roll */
  /**
   * Where a broadside fired at roll phase `phase` (radians) goes: +1 = high (the up-roll throws into the rig), -1 = low
   * (the down-roll throws into the hull). A gun captain cannot fire exactly on the instant, so the aim the shot gets is
   * the phase plus a crew-dependent error; this returns the INTENDED aim, the model adds the error.
   */
  function aimOf(phase) { return Math.sin(phase); }
  /**
   * How steady the gun deck is at roll phase `phase`: 1 at the top or bottom of the roll, where the ship hangs for an
   * instant, falling to 1 - STEADY_K mid-roll where she is moving fastest. This is what makes the MOMENT matter, not just
   * the half of the roll (v0.4 rewarded any click in the right half: sin() is flat near its peak, so a player 0.9 rad off
   * still won 92% of equal duels, balance_probe). Gunners have always fired on the roll's pause for exactly this reason.
   */
  var STEADY_K = 0.5;   // v0.5 probe: 0.75 made a blind gunner win 0.1% of equal duels (a timing test, not a battle)
  function steadiness(phase) { return 1 - STEADY_K * Math.abs(Math.cos(phase)); }

  /* ------------------------------------------------------------ the hit model */
  var SHOT = {
    round: { hull: 1.0, rig: 0.45, crew: 0.35, maxRange: 1.0 },
    chain: { hull: 0.15, rig: 1.5, crew: 0.25, maxRange: 0.6 },
    grape: { hull: 0.05, rig: 0.2, crew: 0.7, maxRange: 0.3 },   // v0.3: crew 1.6 at 0.35 ended 99% of close fights; v0.5: 1.0 + boarding won 87% against a seasoned captain
  };
  /** the chance one gun hits at a range (0 = alongside, 1 = long range), with the gunners' state and the smoke */
  function hitChance(range, crewFrac, smoke) { return Math.max(0.03, (0.85 - 0.75 * range) * (0.45 + 0.55 * crewFrac) * (1 - 0.35 * smoke)); }
  /**
   * One broadside from `from` into `to`: per gun, a hit roll, then where the ball goes (the aim plus the gun captain's
   * error splits it between high and low), times the shot's effect on that track. Raking (crossing the bow) doubles hull
   * and crew damage and draws no return fire this turn. Returns a report; mutates the target's tracks.
   */
  function broadside(r, from, to, o) {
    var shot = SHOT[o.shot] || SHOT.round, range = o.range, out = { fired: 0, hits: 0, hull: 0, rig: 0, crew: 0, shot: o.shot, aim: 0, outOfRange: false };
    if (range > shot.maxRange + 1e-9) { out.outOfRange = true; return out; }
    // a raked ship answers only with her chase guns (v0.2: no return fire at all made the cross decide every fight)
    var gunsOf = o.raked ? 0.25 : 1;
    var guns = Math.max(1, Math.round(from.guns * gunsOf * (0.55 + 0.45 * frac(from, 'crew')))), aim = aimOf(o.phase), cf = frac(from, 'crew');
    var err = 0.12 + 0.45 * (1 - cf);   // a worn crew cannot hold the moment (v0.2: 0.25 + 0.55 made the moment decorative, balance_probe)
    out.aim = aim;
    var p = hitChance(range, cf, o.smoke || 0) * steadiness(o.phase);
    out.steady = steadiness(o.phase);
    for (var g = 0; g < guns; g++) {
      out.fired++;
      if (rand(r) >= p) continue;
      out.hits++;
      var a = Math.max(-1, Math.min(1, aim + (rand(r) * 2 - 1) * err));
      var high = (a + 1) / 2, rake = o.rake ? 1.5 : 1;
      out.hull += (0.35 + 0.65 * (1 - high)) * shot.hull * 2.2 * rake;   // a high ball still strikes the upper works
      out.rig += high * shot.rig * 2.0;
      out.crew += shot.crew * 3.0 * rake * (0.6 + 0.4 * (1 - high));
    }
    to.hull -= out.hull; to.rig -= out.rig; to.crew -= out.crew;
    return out;
  }

  /* ------------------------------------------------------------ the duel */
  var MOVES = ['close', 'open', 'weather', 'cross', 'hold', 'board'];
  /** the range at which two ships lie yardarm to yardarm: 'close' stops here, and only here can a crew board */
  var ALONGSIDE = 0.06;
  /**
   * The endings, each named for the ship it happened TO: `foe-sunk`, `foe-struck` (her colours came down), `foe-taken`
   * (we carried her deck), `foe-escaped` (she got away) and the same four for `me`. A win is foe-sunk/struck/taken.
   */
  var WINS = ['foe-sunk', 'foe-struck', 'foe-taken'], LOSSES = ['me-sunk', 'me-struck', 'me-taken'];
  /** every ending the rules can produce: the wins, the losses, either ship getting clear, and a parting (both ran) */
  var ENDINGS = WINS.concat(LOSSES, ['foe-escaped', 'me-escaped', 'parted']);
  /**
   * A new duel between the player's ship and an enemy, seeded. Range starts long; who holds the weather gauge comes from
   * the seed unless `o.gauge` says (1 = the player, -1 = the enemy, 0 = neither).
   */
  function duel(meCls, foeCls, seed, o) {
    o = o || {};
    var skill = SKILL.hasOwnProperty(String(o.skill)) ? SKILL[o.skill] : (o.skill === '' || o.skill == null ? NaN : Number(o.skill));
    if (!(skill >= 0 && skill <= 1)) skill = SKILL.seasoned;   // NaN, blank and out-of-range fall to the default, never to 0 (wing §16)
    var r = { s: mix(seed | 0, 0xb0ad) };
    var gauge = o.gauge == null || o.gauge === '' ? (rand(r) < 0.5 ? 1 : -1) : Math.max(-1, Math.min(1, Math.round(Number(o.gauge) || 0)));
    // o.escape === false (or 'false'): neither ship can get away - a boss fight; the range opens no further than 0.95
    var noEscape = o.escape === false || String(o.escape).trim().toLowerCase() === 'false';
    return { me: makeShip('me', meCls), foe: makeShip('foe', foeCls), skill: skill, range: o.range == null ? 0.8 : o.range, gauge: gauge, startGauge: gauge, turn: 0, over: null, crossed: null, noEscape: noEscape, r: r };
  }
  /** can `who` cross the other's bow this turn? only from the weather gauge, at middling range, if she sails faster */
  function canCross(d, who) {
    var a = who === 'me' ? d.me : d.foe, b = who === 'me' ? d.foe : d.me, gauge = who === 'me' ? d.gauge : -d.gauge;
    // a dismasted ship cannot turn away: anyone can cross her bow from any side, at any range a gun reaches (the reward for chain shot)
    if (dismasted(a)) return false;   // and a dismasted ship crosses nobody's
    if (dismasted(b) && d.range <= 0.6) return true;
    return gauge > 0 && d.range <= 0.5 && d.range >= 0.15 && speed(a) > speed(b) * 0.9;
  }
  /** a crew can board only from alongside */
  function canBoard(d) { return d.range <= ALONGSIDE + 1e-9; }
  function legal(d, who) { return MOVES.filter(function (m) { return (m !== 'cross' || canCross(d, who)) && (m !== 'board' || canBoard(d)); }); }
  /** named difficulties for the enemy captain (Broadside.js maps its parameter through this) */
  var SKILL = { green: 0.25, seasoned: 0.55, veteran: 0.8, legend: 0.95 };
  /**
   * The enemy captain, seeded and keyed to state. `d.skill` (0..1) is how good she is: how close to the roll's pause her
   * gunners fire, how hard she fights for the weather gauge, how often she takes the cross when offered, and how well she
   * judges when to run. Every captain plays the same rules as the player (wing §11: one model, read by both sides).
   */
  function foeChoice(d) {
    var r = d.r, k = d.skill, mine = frac(d.foe, 'hull') + frac(d.foe, 'crew'), theirs = frac(d.me, 'hull') + frac(d.me, 'crew');
    var move, shot;
    // alongside with the stronger crew, a captain boards (a skilled one waits for a clearer edge, and takes it more often)
    if (canBoard(d) && d.foe.crew > d.me.crew * (1.6 - 0.3 * k) && rand(r) < 0.3 + 0.6 * k) move = 'board';
    else if (canCross(d, 'foe') && rand(r) < 0.15 + 0.5 * k) move = 'cross';
    // a beaten captain runs (a skilled one runs earlier, while she still has the rig to do it)
    else if (mine < 0.6 + 0.4 * k && theirs > mine + 0.3) move = 'open';
    else if (d.gauge > 0 && rand(r) < 0.25 + 0.6 * k) move = 'weather';   // she is to leeward: fight for the gauge
    else if (d.range > 0.4) move = 'close';
    else move = rand(r) < 0.3 + 0.4 * k ? 'hold' : 'close';
    if (move === 'open') shot = 'chain';   // a runner cuts the pursuer's rig
    // close in, grape: when the player's crew outnumbers hers (boarders are coming), or to clear a deck she means to board
    else if (d.range <= SHOT.grape.maxRange && (d.me.crew > d.foe.crew * 1.1 || (d.foe.crew > d.me.crew * 1.2 && rand(r) < k))) shot = 'grape';
    else shot = 'round';
    // her gunners aim for the pause at the bottom of the roll (top for chain); the spread is her crew's training
    var spread = 1.5 - 1.2 * k;
    var phase = (shot === 'chain' ? Math.PI / 2 : -Math.PI / 2) + (rand(r) * 2 - 1) * spread;
    return { move: move, shot: shot, phase: phase };
  }
  /** apply one ship's manoeuvre to the geometry */
  function manoeuvre(d, who, move) {
    var a = who === 'me' ? d.me : d.foe, r = d.r, sp = speed(a), sign = who === 'me' ? 1 : -1;
    if (dismasted(a) && move !== 'hold' && move !== 'board') return;   // no canvas: she cannot close, run, or claw to windward
    if (move === 'close') d.range = Math.max(ALONGSIDE, d.range - 0.16 * sp);
    // NOT clamped here: whether she got away is judged in turn() after the chaser has moved, and a clamp at 1 first
    // would erase the runner's lead every turn (MEASURED: a frigate chased by a frigate sat at 0.872 for ever)
    else if (move === 'open') d.range = d.range + 0.26 * sp;
    else if (move === 'weather') { if (rand(r) < 0.35 + 0.4 * sp) d.gauge = sign; }
    // crossing the bow is a gamble (v0.2): it comes off 60% of the time, and either way she passes to leeward of the enemy
    else if (move === 'cross') { d.crossed = rand(r) < 0.6 ? who : null; d.gauge = -sign; }
  }
  /**
   * One turn: both captains manoeuvre (the player's choice, then the enemy's), smoke settles on the leeward ship, both
   * fire (a ship crossing the bow rakes and takes no return fire), then thresholds become events. Returns the report.
   * @param {{move:string, shot:string, phase:number}} mine
   */
  function turn(d, mine) {
    if (d.over) return null;
    var rep = { turn: ++d.turn, me: mine, foe: null, fireMe: null, fireFoe: null, events: [] };
    if (legal(d, 'me').indexOf(mine.move) < 0) { mine = { move: 'hold', shot: mine.shot, phase: mine.phase, refused: rep.me.move }; rep.me = mine; }
    var f = foeChoice(d); rep.foe = f;
    // boarding happens before the guns: the boarders are on her deck, not at their guns
    if (mine.move === 'board' || f.move === 'board') {
      rep.board = boarding(d, mine.move === 'board' ? 'me' : 'foe');
      rep.events.push('board:' + rep.board);
      if (d.over) return rep;
    }
    manoeuvre(d, 'me', mine.move); manoeuvre(d, 'foe', f.move);
    // v0.6: escape is judged AFTER both ships have moved. Until v0.5 the runner's own manoeuvre ended the fight before
    // the chaser could answer, so "Bear away" on turn one escaped ANY fight from the opening range (0.8 + 0.21 >= 1),
    // an equal frigate included. Now a chaser that closes takes back her speed's worth of the gap, so only the faster
    // ship (or the one the chaser lets go) gets clear; both bearing away is a parting.
    if (d.noEscape && d.range > 0.95) d.range = 0.95;   // a fight that must be fought out: she never opens past 0.95
    if (!d.over && d.range >= 1 - 1e-9) {
      var meRan = mine.move === 'open', foeRan = f.move === 'open';
      d.over = meRan && foeRan ? 'parted' : (meRan ? 'me-escaped' : (foeRan ? 'foe-escaped' : 'parted'));
    }
    d.range = Math.min(1, d.range);
    if (d.over) { rep.events.push(d.over); return rep; }
    // the leeward ship fires through her own smoke (the weather gauge's real advantage)
    var smokeMe = d.gauge < 0 ? 0.5 : 0.2, smokeFoe = d.gauge > 0 ? 0.5 : 0.2;
    var rakeMe = mine.move === 'cross' && d.crossed === 'me', rakeFoe = f.move === 'cross' && d.crossed === 'foe';
    rep.crossed = d.crossed || null; d.crossed = null;
    rep.fireMe = broadside(d.r, d.me, d.foe, { shot: mine.shot, phase: mine.phase, range: d.range, smoke: smokeMe, rake: rakeMe, raked: rakeFoe });
    rep.fireFoe = broadside(d.r, d.foe, d.me, { shot: f.shot, phase: f.phase, range: d.range, smoke: smokeFoe, rake: rakeFoe, raked: rakeMe });
    rep.events = events(d, 'me').concat(events(d, 'foe'));
    if (d.foe.hull <= 0) d.over = 'foe-sunk'; else if (d.me.hull <= 0) d.over = 'me-sunk';
    else if (frac(d.foe, 'crew') < 0.2) d.over = 'foe-struck'; else if (frac(d.me, 'crew') < 0.2) d.over = 'me-struck';
    return rep;
  }
  /** thresholds crossed this turn, each fired ONCE per ship (the event list on the ship remembers) */
  function events(d, who) {
    var s = who === 'me' ? d.me : d.foe, out = [], r = d.r;
    var add = function (e) { if (s.events.indexOf(e) < 0) { s.events.push(e); out.push(who + ':' + e); } };
    if (frac(s, 'rig') < 0.6) add('topmast');
    if (frac(s, 'rig') < 0.3) add('rags');
    if (dismasted(s)) add('dismasted');
    if (frac(s, 'hull') < 0.5) add('list');
    if (frac(s, 'hull') < 0.35 && !s.fire && rand(r) < 0.4) { s.fire = true; add('fire'); }
    if (s.fire) s.hull -= s.max.hull * 0.04;   // a fire burns on until she sinks or the fight ends
    if (frac(s, 'hull') <= 0) add('sinking');
    return out;
  }
  /**
   * Alongside, `who` sends her boarders. The defenders fight from behind their own bulwarks (x1.25), and the odds are
   * SHARP in the crew ratio (a square law), so boarding an untouched crew is a bad bet and boarding one thinned by grape
   * is the decisive move. Carried: the fight ends `<other>-taken`. Repelled: the boarders lose a third of their number
   * and the defenders a tenth, and the fight goes on. Returns 'carried' or 'repelled'.
   */
  function boarding(d, who) {
    var att = who === 'me' ? d.me : d.foe, def = who === 'me' ? d.foe : d.me;
    var a = Math.max(1, att.crew), b = Math.max(1, def.crew) * 1.25;
    if (rand(d.r) < (a * a) / (a * a + b * b)) { d.over = (who === 'me' ? 'foe' : 'me') + '-taken'; return 'carried'; }
    att.crew -= att.crew * 0.33; def.crew -= def.crew * 0.1;
    if (frac(att, 'crew') < 0.2) d.over = who + '-struck';
    return 'repelled';
  }
  function isWin(over) { return WINS.indexOf(over) >= 0; }
  function isLoss(over) { return LOSSES.indexOf(over) >= 0; }

  return { VERSION: '1.0.0', mix: mix, rand: rand, CLASSES: CLASSES, CLASS_OF_HULL: CLASS_OF_HULL, classOf: classOf, SHOT: SHOT, SKILL: SKILL, MOVES: MOVES, makeShip: makeShip, frac: frac, speed: speed, dismasted: dismasted, aimOf: aimOf, steadiness: steadiness, STEADY_K: STEADY_K, hitChance: hitChance, broadside: broadside, ALONGSIDE: ALONGSIDE, WINS: WINS, LOSSES: LOSSES, ENDINGS: ENDINGS, isWin: isWin, isLoss: isLoss, duel: duel, canCross: canCross, canBoard: canBoard, legal: legal, foeChoice: foeChoice, turn: turn, boarding: boarding };
})();
if (typeof module === 'object' && module.exports) module.exports = BroadsideCore;
