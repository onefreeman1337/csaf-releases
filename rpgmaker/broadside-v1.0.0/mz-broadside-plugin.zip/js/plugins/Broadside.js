/*:
 * @target MZ
 * @plugindesc [v1.0.0] Broadside 4/4 - ship-to-ship battles: two drawn ships duel broadside-on on a painted sea. Manoeuvre for the weather gauge, choose round, chain or grape, and fire on the roll.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 * @base BroadsideCore
 * @base BroadsideShips
 * @base BroadsideSea
 * @orderAfter BroadsideSea
 *
 * @param playerShipName
 * @text Your ship's name
 * @type text
 * @default Resolute
 *
 * @param playerHull
 * @text Your hull
 * @type select
 * @option cutter
 * @option sloop
 * @option ketch
 * @option brig
 * @option schooner
 * @option barque
 * @option frigate
 * @option ship-of-the-line
 * @option galleon
 * @option carrack
 * @option cog
 * @option longship
 * @option xebec
 * @option junk
 * @option galley
 * @option hulk
 * @desc What your ship is. Its fighting class follows from it (a schooner fights as a brig, a barque as a frigate).
 * @default frigate
 *
 * @param playerRig
 * @text Your rig
 * @type select
 * @option ship
 * @option barque
 * @option brig
 * @option brigantine
 * @option schooner
 * @option ketch
 * @option sloop
 * @option lateen
 * @option lug
 * @option square-single
 * @default ship
 *
 * @param playerScheme
 * @text Your paint scheme
 * @type select
 * @option nelson
 * @option black-strake
 * @option ochre
 * @option tarred
 * @option oxblood
 * @option verdigris
 * @option bleached
 * @option royal
 * @default royal
 *
 * @param playerWeather
 * @text Your ship's wear
 * @type select
 * @option new
 * @option worked
 * @option salted
 * @option battered
 * @option derelict
 * @default worked
 *
 * @param playerCanvas
 * @text Your canvas
 * @type select
 * @option full
 * @option topsails
 * @option reefed
 * @option storm
 * @default topsails
 *
 * @param defaultSkill
 * @text Enemy captains
 * @type select
 * @option green
 * @option seasoned
 * @option veteran
 * @option legend
 * @desc How good an enemy captain is unless a battle says otherwise. Seasoned: a player who times the roll wins about half of equal fights.
 * @default seasoned
 *
 * @param defaultSky
 * @text Weather
 * @type select
 * @option random
 * @option afternoon
 * @option dusk
 * @option squall
 * @default random
 *
 * @param seCannon
 * @text Sound: broadside
 * @type file
 * @dir audio/se
 * @default Explosion2
 *
 * @param seSplash
 * @text Sound: shot falling short
 * @type file
 * @dir audio/se
 * @default Water1
 *
 * @param seHit
 * @text Sound: a hit
 * @type file
 * @dir audio/se
 * @default Crash
 *
 * @param seMast
 * @text Sound: a mast falling
 * @type file
 * @dir audio/se
 * @default Collapse4
 *
 * @param battleBgm
 * @text Battle music
 * @type file
 * @dir audio/bgm
 * @desc Played during the fight; the map's music comes back afterwards. Blank = keep the current music.
 * @default Ship3
 *
 * @param seaBgs
 * @text Sea sound
 * @type file
 * @dir audio/bgs
 * @desc A background sound under the fight. Blank = none.
 * @default Sea
 *
 * @param meVictory
 * @text Music: victory
 * @type file
 * @dir audio/me
 * @default Victory1
 *
 * @param meDefeat
 * @text Music: defeat
 * @type file
 * @dir audio/me
 * @default Defeat1
 *
 * @command battle
 * @text Start Sea Battle
 * @desc Opens the duel. The event waits until the log is closed; results are written before it continues.
 *
 * @arg title
 * @text Title
 * @type text
 * @desc Shown on the opening chart and the log. Blank = "An Action off <map name>".
 * @default
 *
 * @arg enemyName
 * @text Enemy ship's name
 * @type text
 * @default Vengeur
 *
 * @arg enemyHull
 * @text Enemy hull
 * @type select
 * @option cutter
 * @option sloop
 * @option ketch
 * @option brig
 * @option schooner
 * @option barque
 * @option frigate
 * @option ship-of-the-line
 * @option galleon
 * @option carrack
 * @option cog
 * @option longship
 * @option xebec
 * @option junk
 * @option galley
 * @option hulk
 * @default frigate
 *
 * @arg enemyRig
 * @text Enemy rig
 * @type select
 * @option ship
 * @option barque
 * @option brig
 * @option brigantine
 * @option schooner
 * @option ketch
 * @option sloop
 * @option lateen
 * @option lug
 * @option square-single
 * @default ship
 *
 * @arg enemyScheme
 * @text Enemy paint scheme
 * @type select
 * @option nelson
 * @option black-strake
 * @option ochre
 * @option tarred
 * @option oxblood
 * @option verdigris
 * @option bleached
 * @option royal
 * @default black-strake
 *
 * @arg enemyWeather
 * @text Enemy wear
 * @type select
 * @option new
 * @option worked
 * @option salted
 * @option battered
 * @option derelict
 * @default salted
 *
 * @arg enemyCanvas
 * @text Enemy canvas
 * @type select
 * @option full
 * @option topsails
 * @option reefed
 * @option storm
 * @default topsails
 *
 * @arg skill
 * @text Enemy captain
 * @type select
 * @option (default)
 * @option green
 * @option seasoned
 * @option veteran
 * @option legend
 * @default (default)
 *
 * @arg gauge
 * @text Who starts with the wind
 * @type select
 * @option chance
 * @option you
 * @option the enemy
 * @desc The weather gauge at the first turn. Chance = decided by the battle's seed.
 * @default chance
 *
 * @arg escape
 * @text Either ship can get away
 * @type boolean
 * @on Yes
 * @off No (fight it out)
 * @desc Yes: a ship that bears away and out-sails her chaser gets clear (outcome 4 or 5). No: a boss fight, nobody leaves.
 * @default true
 *
 * @arg sky
 * @text Weather
 * @type select
 * @option (default)
 * @option afternoon
 * @option dusk
 * @option squall
 * @default (default)
 *
 * @arg seed
 * @text Seed
 * @type text
 * @desc Blank = a new fight every time. A number = the same fight every time (same wind, same enemy choices for the same orders).
 * @default
 *
 * @arg outcomeVariableId
 * @text Outcome to variable
 * @type variable
 * @desc 1 she sank, 2 she struck, 3 we took her, 4 she escaped, 5 we escaped, 6 we struck, 7 she took us, 8 we sank, 9 the ships parted.
 * @default 0
 *
 * @arg victorySwitchId
 * @text Victory to switch
 * @type switch
 * @desc ON when she sank, struck or was taken; OFF otherwise.
 * @default 0
 *
 * @arg hullVariableId
 * @text Your hull, carried over
 * @type variable
 * @desc Read at the start (1-100 = that much hull left; 0 = a sound ship) and written at the end, so damage carries from one fight to the next.
 * @default 0
 *
 * @arg commonEventId
 * @text Common event after
 * @type common_event
 * @default 0
 *
 * @help
 * Broadside.js - naval battles for RPG Maker MZ.
 *
 * Two ships the plugin DRAWS (any of 16 hulls, 10 rigs, 8 paint schemes, 5 states of wear) fight broadside-on on a
 * painted sea, the way an age-of-sail painting shows a duel. Each turn you give two orders:
 *
 *   Manoeuvre   Close, Bear away, Weather gauge, Cross her bow, Hold, Board her
 *   Load with   Round shot (her hull), Chain shot (her rig), Grape (her crew, close in)
 *
 * then FIRE ON THE ROLL: the ship rolls on the swell and a brass dial shows it. Fire at the pause at the bottom of the
 * roll and the broadside goes low and steady into her hull; fire at the top and it goes high into her rig; fire while
 * she is swinging and the shot scatters. Damage is drawn into the ships as it happens: shot holes along her side, a
 * topmast hanging over the side, canvas in rags, fire, every mast gone by the board. A fight ends when a ship sinks,
 * strikes her colours, is carried by boarders, or gets away.
 *
 * Required: BroadsideCore.js, BroadsideShips.js, BroadsideSea.js and this file, all ON. Any order works.
 *
 * Plugin command: Start Sea Battle (Broadside > battle). Script call, same arguments:
 *   Broadside.battle({ enemyName: 'Grey Widow', enemyHull: 'xebec', enemyRig: 'lateen', skill: 'veteran',
 *                      outcomeVariableId: 5, victorySwitchId: 3 });
 *   Broadside.isOpen()      true while a battle is on screen
 *   Broadside.lastResult()  the last fight's record (also kept in the save file)
 *
 * Controls: arrow keys and OK, or the mouse and touch. In the orders, left and right choose, up and down change row,
 * OK confirms. On the dial, OK (or a tap) fires. Shift or holding OK speeds the volleys.
 *
 * The ship generator is a copy of the one in Shipwright (also ours), under its own name: owning both is safe.
 *
 * Every line of this plugin was written with AI assistance. Art is drawn by the code at run time; no image files.
 * Copyright (c) 2026 Core Systems Asset Factory.
 */

var Broadside = (function () {
  'use strict';

  var NAME = 'Broadside';
  var RAW = PluginManager.parameters(NAME);
  var CORE = null, SHIPS = null, SEA = null;
  /** ⛔ Sibling files are resolved at FIRST USE, never at load time: the buyer chooses the load order (wing §8 trap 2). */
  function deps() {
    if (!CORE) { CORE = window.BroadsideCore; SEA = window.BroadsideSea; SHIPS = window.CSAF && window.CSAF.BroadsideShip; }
    if (!CORE || !SEA || !SHIPS || !SHIPS.Damage) throw new Error('Broadside needs BroadsideCore.js, BroadsideShips.js and BroadsideSea.js installed and ON in the Plugin Manager.');
    return { core: CORE, ships: SHIPS, sea: SEA };
  }
  function str(v, d) { return v === undefined || v === null ? d : String(v); }
  /** ⛔ wing §16: parameters are strings; blank is ABSENT, never zero, and "0" is a number, not a truthy flag */
  function num(v, d) { var s = String(v === undefined || v === null ? '' : v).trim(); if (s === '') return d; var n = Number(s); return isFinite(n) ? n : d; }
  function pick(v, list, d) { var s = str(v, '').trim(); return list.indexOf(s) >= 0 ? s : d; }
  var HULLS = ['cutter', 'sloop', 'ketch', 'brig', 'schooner', 'barque', 'frigate', 'ship-of-the-line', 'galleon', 'carrack', 'cog', 'longship', 'xebec', 'junk', 'galley', 'hulk'];
  var RIGS = ['ship', 'barque', 'brig', 'brigantine', 'schooner', 'ketch', 'sloop', 'lateen', 'lug', 'square-single'];
  var SCHEMES = ['nelson', 'black-strake', 'ochre', 'tarred', 'oxblood', 'verdigris', 'bleached', 'royal'];
  var WEARS = ['new', 'worked', 'salted', 'battered', 'derelict'];
  var CANVAS = ['full', 'topsails', 'reefed', 'storm'];
  var SKILLS = ['green', 'seasoned', 'veteran', 'legend'];
  var SKIES = ['afternoon', 'dusk', 'squall'];
  var P = {
    me: { name: str(RAW.playerShipName, 'Resolute').trim() || 'Resolute', hull: pick(RAW.playerHull, HULLS, 'frigate'), rig: pick(RAW.playerRig, RIGS, 'ship'), scheme: pick(RAW.playerScheme, SCHEMES, 'royal'), weather: pick(RAW.playerWeather, WEARS, 'worked'), canvas: pick(RAW.playerCanvas, CANVAS, 'topsails') },
    skill: pick(RAW.defaultSkill, SKILLS, 'seasoned'),
    sky: pick(RAW.defaultSky, SKIES.concat(['random']), 'random'),
    se: { cannon: str(RAW.seCannon, 'Explosion2'), splash: str(RAW.seSplash, 'Water1'), hit: str(RAW.seHit, 'Crash'), mast: str(RAW.seMast, 'Collapse4') },
    bgm: str(RAW.battleBgm, 'Ship3'), bgs: str(RAW.seaBgs, 'Sea'),
    me_: { victory: str(RAW.meVictory, 'Victory1'), defeat: str(RAW.meDefeat, 'Defeat1') },
  };
  /** outcome codes written to the outcome variable */
  var OUTCOME = { 'foe-sunk': 1, 'foe-struck': 2, 'foe-taken': 3, 'foe-escaped': 4, 'me-escaped': 5, 'me-struck': 6, 'me-taken': 7, 'me-sunk': 8, parted: 9 };

  /** The save record: versioned, created on first use (a save made before install loads cleanly). */
  function rec() {
    var sys = typeof $gameSystem !== 'undefined' ? $gameSystem : null; if (!sys) return null;
    if (!sys._csafBroadside || sys._csafBroadside.v !== 1) sys._csafBroadside = { v: 1, fights: 0, wins: 0, last: null };
    return sys._csafBroadside;
  }

  /** Build a battle request from command arguments (strings from the editor, or plain values from a script call). */
  function request(args, mapId, eventId) {
    var d = deps(); args = args || {};
    var r = rec(), n = r ? r.fights : 0;
    var seedText = str(args.seed, '').trim();
    var seed = seedText !== '' && isFinite(Number(seedText)) ? (Number(seedText) >>> 0) : (d.sea.hash('m' + mapId + 'e' + eventId + 'n' + n + 't' + Date.now()) >>> 0);
    var skyArg = pick(args.sky, SKIES, ''), sky = skyArg || (P.sky === 'random' ? SKIES[seed % SKIES.length] : P.sky);
    var g = str(args.gauge, 'chance').trim();
    var hullVar = Math.max(0, Math.floor(num(args.hullVariableId, 0)));
    var startHull = 1;
    if (hullVar && typeof $gameVariables !== 'undefined' && $gameVariables) { var hv = num($gameVariables.value(hullVar), 0); if (hv >= 1 && hv <= 100) startHull = hv / 100; }
    var mapName = typeof $gameMap !== 'undefined' && $gameMap && $gameMap.displayName ? $gameMap.displayName() : '';
    var foe = { name: str(args.enemyName, 'Vengeur').trim() || 'Vengeur', hull: pick(args.enemyHull, HULLS, 'frigate'), rig: pick(args.enemyRig, RIGS, 'ship'), scheme: pick(args.enemyScheme, SCHEMES, 'black-strake'), weather: pick(args.enemyWeather, WEARS, 'salted'), canvas: pick(args.enemyCanvas, CANVAS, 'topsails') };
    return {
      title: str(args.title, '').trim() || (mapName ? 'An Action off ' + mapName : 'An Action at Sea'),
      seed: seed, sky: sky, skill: pick(args.skill, SKILLS, P.skill),
      gauge: g === 'you' ? 1 : (g === 'the enemy' ? -1 : null),
      escape: !(args.escape === false || str(args.escape, 'true').trim().toLowerCase() === 'false'),   // blank or absent = yes
      me: { name: P.me.name, hull: P.me.hull, rig: P.me.rig, scheme: P.me.scheme, weather: P.me.weather, canvas: P.me.canvas, seed: P.me.name },
      foe: { name: foe.name, hull: foe.hull, rig: foe.rig, scheme: foe.scheme, weather: foe.weather, canvas: foe.canvas, seed: foe.name },
      startHull: startHull, hullVariableId: hullVar,
      outcomeVariableId: Math.max(0, Math.floor(num(args.outcomeVariableId, 0))), victorySwitchId: Math.max(0, Math.floor(num(args.victorySwitchId, 0))),
      commonEventId: Math.max(0, Math.floor(num(args.commonEventId, 0))),
    };
  }

  var OPEN = false;
  /** open a battle; refused (false) while one is already on screen, so a second call cannot stack a second scene */
  function open(req) { if (!req || OPEN) return false; SceneManager.push(Scene_Broadside); SceneManager.prepareNextScene(req); OPEN = true; return true; }

  /** Write the outcome into the game. Called once, as the log closes. */
  function apply(req, res) {
    var s = rec(); if (s) { s.fights++; if (res.win) s.wins++; s.last = { title: req.title, enemy: req.foe.name, ending: res.ending, turns: res.turns, me: res.me, foe: res.foe }; }
    if (req.outcomeVariableId) $gameVariables.setValue(req.outcomeVariableId, OUTCOME[res.ending] || 9);
    if (req.victorySwitchId) $gameSwitches.setValue(req.victorySwitchId, !!res.win);
    // 0 reads back as "a sound ship", so a ship that SURVIVED with under half a percent of hull writes 1, never 0;
    // only a ship that sank writes 0
    if (req.hullVariableId) $gameVariables.setValue(req.hullVariableId, Broadside.hullOut(res));
    if (req.commonEventId) $gameTemp.reserveCommonEvent(req.commonEventId);
  }

  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
    PluginManager.registerCommand(NAME, 'battle', function (args) {
      var mapId = this._mapId || ($gameMap ? $gameMap.mapId() : 0), eventId = this.eventId ? this.eventId() : 0;
      open(request(args, mapId, eventId));
    });
  }
  /** Script call: Broadside.battle({...}) with the command's arguments as plain values. */
  function battle(opts) {
    var it = typeof $gameMap !== 'undefined' && $gameMap ? $gameMap._interpreter : null;
    return open(request(opts || {}, $gameMap ? $gameMap.mapId() : 0, it && it.eventId ? it.eventId() : 0));
  }
  function playSe(n, vol, pitch) { if (n) AudioManager.playSe({ name: n, volume: vol || 80, pitch: pitch || 100, pan: 0 }); }
  /** the hull written back to the carried-hull variable: 0 only for a ship that sank, else 1..100 */
  function hullOut(res) { return res.ending === 'me-sunk' ? 0 : Math.max(1, Math.min(100, Math.round(res.me.hull * 100))); }

  return {
    VERSION: '1.0.0', P: P, OUTCOME: OUTCOME, deps: deps, request: request, open: open, apply: apply, battle: battle, playSe: playSe, hullOut: hullOut,
    isOpen: function () { return OPEN; }, setOpen: function (v) { OPEN = !!v; },
    lastResult: function () { var r = rec(); return r ? r.last : null; },
  };
})();

//=============================================================================
// Scene_Broadside
//=============================================================================

function Scene_Broadside() { this.initialize.apply(this, arguments); }
Scene_Broadside.prototype = Object.create(Scene_Base.prototype);
Scene_Broadside.prototype.constructor = Scene_Broadside;

/** the layout, in one place (816 x 624) */
Scene_Broadside.L = {
  me: { x: 262, y: 566, L: 420 },          // the player's ship: waterline centre and length on deck
  foe: { x: 586, y0: 300, y1: 412, L: 300, near: 1.0, far: 0.56 },   // the enemy: baked at L, scaled by range
  roll: { period: 150, ampMe: 0.045, ampFoe: 0.035 },
  card: { w: 300, h: 110 }, compass: { w: 200, h: 110 }, noteY: 122,   // LOOKED AT: at 94 px the flags line ran into the Crew gauge
  orders: { x: 452, y: 372, w: 356, h: 244 }, dial: { x: 488, y: 410, w: 300, h: 196 },
  POOL: { smoke: 72, splash: 32, flash: 40, splinter: 32, flame: 9 },
};

Scene_Broadside.prototype.prepare = function (req) { this._req = req; };

Scene_Broadside.prototype.create = function () {
  Scene_Base.prototype.create.call(this);
  var d = Broadside.deps(), req = this._req; this._dp = d;
  this._duel = d.core.duel(req.me.hull, req.foe.hull, req.seed, { skill: req.skill, gauge: req.gauge, escape: req.escape !== false });
  if (req.startHull < 1) this._duel.me.hull = this._duel.me.max.hull * req.startHull;
  this._phase = 'intro'; this._age = 0; this._t = 0; this._sel = [this.firstLegal(0, 'close'), 0]; this._row = 0; this._log = [];
  this._shown = { me: null, foe: null };   // the damage state each ship was last baked with
  this._rangeShown = this._duel.range; this._rangeFrom = this._duel.range; this._rangeTo = this._duel.range; this._rangeAge = 0;
  this._volley = null; this._notes = []; this._noteAge = 0; this._end = null;
  this.createStage();
  this._hudLast = [-1, -1, -1, -1, -1, -1, -9, -1, -1, -1];   // what the HUD last drew (compared in place: no per-frame allocation)
  this._pre = { me: { hull: 0, rig: 0, crew: 0, max: this._duel.me.max, fire: false }, foe: { hull: 0, rig: 0, crew: 0, max: this._duel.foe.max, fire: false } };
  this.createBackdrop(); this.createShips(); this.createFx(); this.applyDamageBakes(); this.createUi();
  this.layoutShips();
};
Scene_Broadside.prototype.start = function () {
  Scene_Base.prototype.start.call(this); this.startFadeIn(this.fadeSpeed(), false);
  var P = Broadside.P;
  if (P.bgm) { this._savedBgm = AudioManager.saveBgm(); AudioManager.playBgm({ name: P.bgm, volume: 70, pitch: 100, pan: 0 }); }
  if (P.bgs) { this._savedBgs = AudioManager.saveBgs(); AudioManager.playBgs({ name: P.bgs, volume: 60, pitch: 100, pan: 0 }); }
};

//---------------------------------------------------------------------------- building (allocation happens here, never per frame)

Scene_Broadside.prototype.bitmap = function (w, h, fn) { var b = new Bitmap(Math.ceil(w), Math.ceil(h)); fn(b.context, b.width, b.height); b._baseTexture.update(); return b; };
/** the logical stage every layout number in Scene_Broadside.L is written for */
Scene_Broadside.W = 816; Scene_Broadside.H = 624;
/**
 * The whole scene is laid out on one logical 816 x 624 stage, scaled uniformly to fit the project's screen and
 * centred; the sky and the sea extend past it into any spare width or height, so a 1280 x 720 project gets the same
 * duel with more sea at the sides, never a layout pinned to the top-left corner (MEASURED 2026-10-11: the ships, the
 * orders and the dial were placed for 816 x 624 while the backdrop and cards followed Graphics.width).
 * `_vx, _vy, _vw, _vh` are the visible screen in stage coordinates.
 */
Scene_Broadside.prototype.createStage = function () {
  var W = Scene_Broadside.W, H = Scene_Broadside.H, s = Math.min(Graphics.width / W, Graphics.height / H);
  this._k = s; this._ox = Math.round((Graphics.width - W * s) / 2); this._oy = Math.round((Graphics.height - H * s) / 2);
  this._vx = -this._ox / s; this._vy = -this._oy / s; this._vw = Graphics.width / s; this._vh = Graphics.height / s;
  this._root = new Sprite(); this._root.scale.x = this._root.scale.y = s; this._root.x = this._ox; this._root.y = this._oy;
  this.addChild(this._root);
};
/** a screen point (TouchInput) in stage coordinates */
Scene_Broadside.prototype.toStage = function (x, y, out) { out.x = (x - this._ox) / this._k; out.y = (y - this._oy) / this._k; return out; };
Scene_Broadside.prototype.createBackdrop = function () {
  var S = this._dp.sea, req = this._req, vw = this._vw, vh = this._vh, top = -this._vy;
  // the sky's top colour fills any height above the stage, then the painting is laid with its horizon on the stage's
  this._back = new Sprite(this.bitmap(vw, vh, function (c, w, h) { c.fillStyle = S.SKIES[req.sky] ? S.SKIES[req.sky].sky[0] : S.SKIES.afternoon.sky[0]; c.fillRect(0, 0, w, h); c.save(); c.translate(0, top); S.drawBackdrop(c, w, h - top, req.sky, req.seed); c.restore(); }));
  this._back.x = this._vx; this._back.y = this._vy; this._root.addChild(this._back);
  var gb = this.bitmap(vw, vh - top - S.HORIZON, function (c, w, h) { S.drawGlints(c, w, h, req.sky, req.seed); });
  this._glints = [new Sprite(gb), new Sprite(gb)];
  for (var i = 0; i < 2; i++) { this._glints[i].y = S.HORIZON; this._root.addChild(this._glints[i]); }
};
/** a ship: a container holding her baked picture (masked at the sea surface) and the water she pushes aside */
Scene_Broadside.prototype.createShip = function (key, spec, L) {
  var Sh = this._dp.ships, m = Sh.Portrait.metrics(spec, L) || { top: -L, bottom: 0, left: -L * 0.7, right: L * 0.6 };
  var pad = L * 0.12, ox = -m.left + pad, oy = -m.top + pad, w = m.right - m.left + pad * 2 + L * 0.25, h = -m.top + L * 0.14 + pad;
  var bmp = new Bitmap(Math.ceil(w), Math.ceil(h));
  var sp = new Sprite(bmp); sp.anchor.x = ox / bmp.width; sp.anchor.y = oy / bmp.height;
  var wash = new Sprite(this.bitmap(L * 1.35, L * 0.16, (function (sky) { return function (c, ww, hh) { Broadside.deps().sea.drawWash(c, ww, hh, L, sky); }; })(this._req.sky)));
  wash.anchor.x = 0.5; wash.anchor.y = 0.5;
  var mask = new PIXI.Graphics(); this._root.addChild(mask);
  var holder = new Sprite(); holder.addChild(sp); holder.mask = mask; this._root.addChild(holder); this._root.addChild(wash);
  // not baked here: create() calls applyDamageBakes() once both ships exist, so a ship carrying damage from an earlier
  // fight is drawn with it from the first frame, and each ship is baked exactly once at the start (was twice)
  var o = { key: key, spec: spec, L: L, bmp: bmp, sprite: sp, holder: holder, wash: wash, mask: mask, ox: ox, oy: oy, maskY: -1, info: null, flames: [], bakeKey: null, list: 0 };
  return o;
};
/** draw a ship and her damage into her bitmap. Called when her drawn damage CHANGES, never per frame. */
Scene_Broadside.prototype.bake = function (o, dmg) {
  var c = o.bmp.context; c.clearRect(0, 0, o.bmp.width, o.bmp.height);
  o.info = this._dp.ships.Damage.draw(c, o.spec, o.ox, o.oy, o.L, dmg);
  o.bmp._baseTexture.update(); this._bakes = (this._bakes || 0) + 1;
};
Scene_Broadside.prototype.createShips = function () {
  var K = Scene_Broadside.L;
  this._foe = this.createShip('foe', this._req.foe, K.foe.L);   // the far ship first: the near one passes in front of her
  this._me = this.createShip('me', this._req.me, K.me.L);
};
/** a pool of sprites sharing one texture; each carries its own life counters (scalars only) */
Scene_Broadside.prototype.pool = function (n, bmp, ax, ay) {
  var out = [];
  for (var i = 0; i < n; i++) { var s = new Sprite(bmp); s.anchor.x = ax; s.anchor.y = ay; s.visible = false; s._life = 0; s._max = 1; s._vx = 0; s._vy = 0; s._s0 = 1; s._s1 = 1; s._a0 = 1; s._delay = 0; out.push(s); this._fxLayer.addChild(s); }
  out._next = 0; return out;
};
Scene_Broadside.prototype.createFx = function () {
  var S = this._dp.sea, req = this._req, K = Scene_Broadside.L.POOL, self = this;
  this._fxLayer = new Sprite(); this._root.addChild(this._fxLayer);
  var smokeA = this.bitmap(160, 110, function (c, w, h) { S.drawSmoke(c, w, h, req.sky, 1); });
  var smokeB = this.bitmap(160, 110, function (c, w, h) { S.drawSmoke(c, w, h, req.sky, 2); });
  this._smoke = this.pool(K.smoke, smokeA, 0.5, 0.5);
  for (var i = 1; i < this._smoke.length; i += 2) this._smoke[i].bitmap = smokeB;
  this._splash = this.pool(K.splash, this.bitmap(40, 76, function (c, w, h) { S.drawSplash(c, w, h); }), 0.5, 1);
  this._flash = this.pool(K.flash, this.bitmap(56, 30, function (c, w, h) { S.drawFlash(c, w, h); }), 0.05, 0.5);
  this._splinter = this.pool(K.splinter, this.bitmap(44, 44, function (c, w, h) { S.drawSplinter(c, w, h); }), 0.5, 0.5);
  this._flameBmp = [0, 1, 2].map(function (k) { return self.bitmap(34, 52, function (c, w, h) { S.drawFlame(c, w, h, k); }); });
  this._flame = this.pool(K.flame, this._flameBmp[0], 0.5, 1);
};
Scene_Broadside.prototype.createUi = function () {
  var K = Scene_Broadside.L, W = Scene_Broadside.W, S = this._dp.sea, req = this._req;
  this._cardMe = new Sprite(new Bitmap(K.card.w, K.card.h)); this._cardMe.x = 8; this._cardMe.y = 6;
  this._cardFoe = new Sprite(new Bitmap(K.card.w, K.card.h)); this._cardFoe.x = W - K.card.w - 8; this._cardFoe.y = 6;
  this._compass = new Sprite(new Bitmap(K.compass.w, K.compass.h)); this._compass.x = (W - K.compass.w) / 2; this._compass.y = 6;
  this._orders = new Sprite(new Bitmap(K.orders.w, K.orders.h)); this._orders.x = K.orders.x; this._orders.y = K.orders.y; this._orders.visible = false;
  this._dial = new Sprite(new Bitmap(K.dial.w, K.dial.h)); this._dial.x = K.dial.x; this._dial.y = K.dial.y; this._dial.visible = false;
  this._needle = new Sprite(this.bitmap(16, K.dial.h - 70, function (c, w, h) { S.drawNeedle(c, w, h); })); this._needle.anchor.x = 0.5; this._needle.anchor.y = 0;
  this._needle.x = K.dial.x + K.dial.w / 2; this._needle.y = K.dial.y + 30; this._needle.visible = false;
  this._note = new Sprite(new Bitmap(W, 44)); this._note.y = K.noteY; this._note.visible = false;
  this._title = new Sprite(this.bitmap(W, 110, function (c, w, h) { S.drawTitle(c, w, h, req.title, 'The ' + req.me.name + ' against the ' + req.foe.name); })); this._title.y = -110;
  // the log dims the whole visible screen, letterbox included, and centres its plate on the stage
  this._logSp = new Sprite(new Bitmap(Math.ceil(this._vw), Math.ceil(this._vh))); this._logSp.x = this._vx; this._logSp.y = this._vy; this._logSp.visible = false;
  [this._cardMe, this._cardFoe, this._compass, this._orders, this._dial, this._needle, this._note, this._title, this._logSp].forEach(function (s) { this._root.addChild(s); }, this);
  this.refreshHud(true);
  // MEASURED 2026-10-11 (_probe/spike_probe.js): the FIRST drawing of the orders plate took 54 ms and the first banner
  // 12 ms (the typeface and gradient caches warming), each a visible hitch mid-fight. Both are drawn once here, while
  // the scene is being built behind its fade-in, and hidden; the real draws that follow are warm.
  this.refreshOrders(); this._ordersKey = '';
  this._dp.sea.drawNote(this._note.bitmap.context, W, 44, 'Her main topmast goes by the board!', 'bad');
  this._dp.sea.drawDial(this._dial.bitmap.context, K.dial.w, K.dial.h, { target: 'down', note: 'Fire at the BOTTOM of the roll' });
};

//---------------------------------------------------------------------------- per frame (scalars and pooled sprites only)

Scene_Broadside.prototype.update = function () {
  Scene_Base.prototype.update.call(this);
  this._age++; this._t++;
  if (this._bakePending) this._bakePending = this.applyDamageBakes(1);
  var ph = this._phase;
  if (ph === 'intro') this.updateIntro();
  else if (ph === 'orders') this.updateOrders();
  else if (ph === 'aim') this.updateAim();
  else if (ph === 'volley') this.updateVolley();
  else if (ph === 'ending') this.updateEnding();
  else if (ph === 'log') this.updateLog();
  else if (ph === 'leaving' && !this.isBusy()) { this._phase = 'gone'; Broadside.setOpen(false); this.popScene(); }
  this.layoutShips(); this.updateFx(); this.updateNote();
};
/** the roll phase of a ship at the current frame (radians); the player's is the one the dial shows and the shot uses */
Scene_Broadside.prototype.rollPhase = function (who) { var K = Scene_Broadside.L.roll; return (this._t / K.period) * Math.PI * 2 + (who === 'foe' ? 1.9 : 0); };
Scene_Broadside.prototype.layoutShips = function () {
  var K = Scene_Broadside.L, S = this._dp.sea, W = this._glints[0].bitmap.width;   // the glint strip spans the visible width
  // the range tweens toward the core's value over 40 frames after a manoeuvre
  if (this._rangeAge < 40) { this._rangeAge++; var u = this._rangeAge / 40; u = u * u * (3 - 2 * u); this._rangeShown = this._rangeFrom + (this._rangeTo - this._rangeFrom) * u; }
  var near = 1 - this._rangeShown, me = this._me, foe = this._foe;
  var pm = this.rollPhase('me'), pf = this.rollPhase('foe');
  var listMe = this._end && this._end.who === 'me' ? this._end.list : (me.list || 0), listFoe = this._end && this._end.who === 'foe' ? this._end.list : (foe.list || 0);
  var sinkMe = this._end && this._end.who === 'me' ? this._end.sink : 0, sinkFoe = this._end && this._end.who === 'foe' ? this._end.sink : 0;
  // the player's ship
  me.sprite.rotation = -Math.sin(pm) * K.roll.ampMe + listMe; me.holder.x = K.me.x; me.holder.y = K.me.y + Math.sin(pm * 2) * 2.2 + sinkMe;
  me.wash.x = K.me.x; me.wash.y = K.me.y + 2; me.wash.alpha = 0.85 + Math.sin(pm) * 0.1;
  this.setMask(me, K.me.y);
  // the enemy: nearer = larger, lower in the frame
  var sc = K.foe.far + (K.foe.near - K.foe.far) * Math.pow(near, 1.3), fy = K.foe.y0 + (K.foe.y1 - K.foe.y0) * near;
  foe.sprite.rotation = Math.sin(pf) * K.roll.ampFoe + listFoe; foe.sprite.scale.x = foe.sprite.scale.y = sc;
  foe.holder.x = K.foe.x - near * 40; foe.holder.y = fy + Math.sin(pf * 2) * 1.6 * sc + sinkFoe * sc;
  foe.wash.x = foe.holder.x; foe.wash.y = fy + 1; foe.wash.scale.x = foe.wash.scale.y = sc;
  this.setMask(foe, fy);
  // the glints drift with the wind (two copies tile the strip)
  var gx = (this._t * 0.18) % W; this._glints[0].x = this._vx + gx - W; this._glints[1].x = this._vx + gx;
  // the dial's needle follows the player's roll
  if (this._needle.visible) this._needle.rotation = -Math.sin(pm) * 1.0;
  // fires burn on deck, and go out where her deck goes under
  this.layoutFlames(me, 1, K.me.y); this.layoutFlames(foe, sc, fy);
};
/** the sea surface hides everything of a ship below it: a rectangle mask, redrawn only when the waterline moves */
Scene_Broadside.prototype.setMask = function (o, y) {
  var yy = Math.round(y + 1); if (yy === o.maskY) return; o.maskY = yy;
  o.mask.clear(); o.mask.beginFill(0xffffff); o.mask.drawRect(this._vx, this._vy, this._vw, yy - this._vy); o.mask.endFill();
};
/**
 * Fires sit on deck points from the ship's own geometry, rotated with her roll and list. `waterY` is the sea surface
 * at her: LOOKED AT 2026-10-11, a sinking ship's fires kept burning under the sea (the hull is masked, the flames are
 * not), so a fire whose foot is below the surface is hidden.
 */
Scene_Broadside.prototype.layoutFlames = function (o, sc, waterY) {
  for (var i = 0; i < o.flames.length; i++) {
    var f = o.flames[i], p = o.info.deckPoints[f._pt], rot = o.sprite.rotation, x = (p[0] - o.ox) * sc, y = (p[1] - o.oy) * sc;
    f.x = o.holder.x + x * Math.cos(rot) - y * Math.sin(rot); f.y = o.holder.y + x * Math.sin(rot) + y * Math.cos(rot) + 2;
    f.visible = f.y < waterY - 2;
    var k = ((this._t >> 2) + i) % 3; f.bitmap = this._flameBmp[k]; f.scale.x = sc * (0.9 + ((this._t + i * 7) % 11) / 40); f.scale.y = sc * (1 + ((this._t + i * 5) % 13) / 30);
  }
};
Scene_Broadside.prototype.updateIntro = function () {
  var a = this._age;
  this._title.y = a < 30 ? -110 + a * (110 + 130) / 30 : (a < 120 ? 130 : 130 - (a - 120) * 6);
  this._title.opacity = a < 120 ? 255 : Math.max(0, 255 - (a - 120) * 12);
  if (a >= 150 || (a > 30 && (Input.isTriggered('ok') || TouchInput.isTriggered()))) { this._title.visible = false; this.enterOrders(); }
};

//---------------------------------------------------------------------------- orders

/** the fighting classes as the cards and the log name them */
Scene_Broadside.CLS = { cutter: 'Cutter', sloop: 'Sloop', brig: 'Brig', xebec: 'Xebec', frigate: 'Frigate', galleon: 'Galleon', 'ship-of-the-line': 'Ship of the line' };
Scene_Broadside.MOVES = ['close', 'open', 'weather', 'cross', 'hold', 'board'];
Scene_Broadside.SHOTS = ['round', 'chain', 'grape'];
Scene_Broadside.prototype.legalMoves = function () { var L = this._dp.core.legal(this._duel, 'me'), o = {}; for (var i = 0; i < L.length; i++) o[L[i]] = true; return o; };
/** a shot is offered if it can reach her after the manoeuvre you chose (the range she will be at if she holds) */
Scene_Broadside.prototype.legalShots = function () {
  var C = this._dp.core, d = this._duel, mv = Scene_Broadside.MOVES[this._sel[0]], r = d.range, sp = C.speed(d.me);
  if (mv === 'close') r = Math.max(C.ALONGSIDE, r - 0.16 * sp); else if (mv === 'open') r = Math.min(1, r + 0.26 * sp);
  return { round: true, chain: r <= C.SHOT.chain.maxRange + 1e-9, grape: r <= C.SHOT.grape.maxRange + 1e-9 };
};
Scene_Broadside.prototype.firstLegal = function (row, pref) {
  var ids = row ? Scene_Broadside.SHOTS : Scene_Broadside.MOVES, ok = row ? (this._duel ? this.legalShots() : { round: true }) : (this._duel ? this.legalMoves() : { close: true });
  if (pref && ok[pref]) return ids.indexOf(pref);
  for (var i = 0; i < ids.length; i++) if (ok[ids[i]]) return i; return 0;
};
Scene_Broadside.prototype.enterOrders = function () {
  this._phase = 'orders'; this._age = 0; this._row = 0;
  this._bakePending = this.applyDamageBakes(1);   // a rebake costs a portrait draw: done here, where the player is reading, never mid-volley; the second ship next frame
  var lm = this.legalMoves();
  if (!lm[Scene_Broadside.MOVES[this._sel[0]]]) this._sel[0] = this.firstLegal(0, lm.cross ? 'cross' : 'close');
  if (!this.legalShots()[Scene_Broadside.SHOTS[this._sel[1]]]) this._sel[1] = this.firstLegal(1, 'round');
  this._orders.visible = true; this._dial.visible = false; this._needle.visible = false; this._ordersKey = ''; this.refreshOrders();
};
Scene_Broadside.prototype.helpLine = function () {
  var mv = Scene_Broadside.MOVES[this._sel[0]], sh = Scene_Broadside.SHOTS[this._sel[1]], C = this._dp.core, d = this._duel;
  var M = { close: 'Close the range: more hits, and grape and boarding come within reach.', open: d.noEscape ? 'Bear away: open the range. She will not let you go.' : 'Bear away: open the range. Out-sail her and you get clear.', weather: 'Claw up to windward: the ship to windward fires through clear air.', cross: 'Cross her bow and rake her: every gun down her length, only her chase guns answer.', hold: 'Hold your course and fire.', board: 'Lay her aboard. Boarders away: crew against crew.' };
  var S = { round: 'Round shot: into her hull. Fire at the bottom of the roll.', chain: 'Chain shot: cuts her rig. Fire at the top of the roll.', grape: 'Grape: sweeps her deck of men. Close range only.' };
  if (mv === 'board') return M.board + ' (' + Math.round(d.me.crew) + ' of ours against ' + Math.round(d.foe.crew) + ')';
  if (this._row === 0) return M[mv];
  return S[sh];
};
Scene_Broadside.prototype.refreshOrders = function () {
  var key = this._sel[0] + '|' + this._sel[1] + '|' + this._row + '|' + this._duel.turn; if (key === this._ordersKey) return; this._ordersKey = key;
  var K = Scene_Broadside.L.orders, lm = this.legalMoves(), ls = this.legalShots();
  this._dp.sea.drawOrders(this._orders.bitmap.context, K.w, K.h, { title: 'Orders  ·  turn ' + (this._duel.turn + 1), moves: Scene_Broadside.MOVES, legal: lm, shots: Scene_Broadside.SHOTS, shotLegal: Scene_Broadside.MOVES[this._sel[0]] === 'board' ? {} : ls, row: this._row, sel: this._sel, help: this.helpLine() });
  this._orders.bitmap._baseTexture.update();
};
Scene_Broadside.prototype.step = function (row, dir) {
  var ids = row ? Scene_Broadside.SHOTS : Scene_Broadside.MOVES, ok = row ? this.legalShots() : this.legalMoves(), i = this._sel[row];
  for (var k = 0; k < ids.length; k++) { i = (i + dir + ids.length) % ids.length; if (ok[ids[i]]) { this._sel[row] = i; break; } }
  if (row === 0 && !this.legalShots()[Scene_Broadside.SHOTS[this._sel[1]]]) this._sel[1] = this.firstLegal(1, 'round');
  Broadside.playSe('Cursor1', 50);
};
/** which card is under a screen point: [row, index] or null */
Scene_Broadside.prototype.cardAt = function (x, y) {
  // the card grid is the drawing's own (BroadsideSea.ORDERS), never a second copy of its numbers (wing §11a)
  var K = Scene_Broadside.L.orders, G = this._dp.sea.ORDERS, lx = x - K.x - G.pad, ly = y - K.y - G.top, ch = G.ch, gap = G.gap;
  if (lx < 0 || lx > K.w - G.pad * 2 || ly < 0) return null;
  var row = ly < ch ? 0 : (ly >= ch + gap && ly < 2 * ch + gap ? 1 : -1); if (row < 0) return null;
  var n = row ? 3 : 6, i = Math.floor(lx / ((K.w - G.pad * 2) / n)); return i >= 0 && i < n ? [row, i] : null;
};
Scene_Broadside.prototype.updateOrders = function () {
  if (Input.isRepeated('left')) this.step(this._row, -1);
  else if (Input.isRepeated('right')) this.step(this._row, 1);
  else if (Input.isTriggered('down') && Scene_Broadside.MOVES[this._sel[0]] !== 'board') this._row = 1;
  else if (Input.isTriggered('up')) this._row = 0;
  else if (Input.isTriggered('cancel') && this._row === 1) this._row = 0;
  else if (Input.isTriggered('ok') && this._age > 6) {
    if (this._row === 0 && Scene_Broadside.MOVES[this._sel[0]] !== 'board') { this._row = 1; Broadside.playSe('Cursor2', 60); }
    else this.confirmOrders();
  } else if (TouchInput.isTriggered()) {
    var pt = this.toStage(TouchInput.x, TouchInput.y, this._tp || (this._tp = { x: 0, y: 0 })), hit = this.cardAt(pt.x, pt.y);
    if (hit) {
      var ids = hit[0] ? Scene_Broadside.SHOTS : Scene_Broadside.MOVES, ok = hit[0] ? this.legalShots() : this.legalMoves();
      if (ok[ids[hit[1]]] && !(hit[0] === 1 && Scene_Broadside.MOVES[this._sel[0]] === 'board')) {
        var again = this._sel[hit[0]] === hit[1] && this._row === hit[0];
        this._sel[hit[0]] = hit[1]; this._row = hit[0];
        if (hit[0] === 0 && !this.legalShots()[Scene_Broadside.SHOTS[this._sel[1]]]) this._sel[1] = this.firstLegal(1, 'round');
        if (hit[0] === 1 || (again && ids[hit[1]] === 'board')) this.confirmOrders(); else if (hit[0] === 0) { this._row = Scene_Broadside.MOVES[this._sel[0]] === 'board' ? 0 : 1; Broadside.playSe('Cursor2', 60); }
      }
    }
  }
  this.refreshOrders();
};
Scene_Broadside.prototype.confirmOrders = function () {
  this._orders.visible = false; Broadside.playSe('Decision1', 70);
  if (Scene_Broadside.MOVES[this._sel[0]] === 'board') { this.resolve(-Math.PI / 2); return; }
  this._phase = 'aim'; this._age = 0;
  var sh = Scene_Broadside.SHOTS[this._sel[1]], K = Scene_Broadside.L.dial;
  this._dp.sea.drawDial(this._dial.bitmap.context, K.w, K.h, { target: sh === 'chain' ? 'up' : 'down', note: (sh === 'chain' ? 'Chain: fire at the TOP of the roll' : 'Fire at the BOTTOM of the roll') + '  ·  OK or tap' });
  this._dial.bitmap._baseTexture.update(); this._dial.visible = true; this._needle.visible = true;
};

//---------------------------------------------------------------------------- aim and fire

Scene_Broadside.prototype.updateAim = function () {
  if (Input.isTriggered('cancel')) { this._dial.visible = false; this._needle.visible = false; this.enterOrders(); this._row = 1; return; }
  if (this._age > 10 && (Input.isTriggered('ok') || TouchInput.isTriggered())) this.resolve(this.rollPhase('me'));
};
/** how close to the moment the player fired, in words */
Scene_Broadside.prototype.timingWord = function (phase, shot) {
  var target = shot === 'chain' ? Math.PI / 2 : -Math.PI / 2, e = Math.atan2(Math.sin(phase - target), Math.cos(phase - target)), a = Math.abs(e);
  return a < 0.25 ? 'on the roll' : (a < 0.6 ? (e < 0 ? 'a shade early' : 'a shade late') : (a < 1.2 ? (e < 0 ? 'early' : 'late') : 'wild'));
};
/** play one turn of the rules with the orders given, then stage the volley that shows it */
Scene_Broadside.prototype.resolve = function (phase) {
  var C = this._dp.core, d = this._duel, mv = Scene_Broadside.MOVES[this._sel[0]], sh = Scene_Broadside.SHOTS[this._sel[1]];
  // every instrument of the orders is put away here, whoever called (LOOKED AT 2026-10-11: a turn resolved by script
  // left the orders plate standing over the enemy for the whole volley)
  this._orders.visible = false; this._dial.visible = false; this._needle.visible = false;
  var before = { meRange: d.range };
  // the rules resolve the whole turn at once; the HUD must not show a hit before the shot that made it lands
  // (LOOKED AT 2026-10-11: our card read 94% while our own guns were still firing), so the gauges hold these values
  // until each broadside lands (hudShip)
  var pm = this._pre.me, pf = this._pre.foe;
  pm.hull = d.me.hull; pm.rig = d.me.rig; pm.crew = d.me.crew; pm.fire = d.me.fire;
  pf.hull = d.foe.hull; pf.rig = d.foe.rig; pf.crew = d.foe.crew; pf.fire = d.foe.fire;
  var rep = C.turn(d, { move: mv, shot: sh, phase: phase });
  this._rangeFrom = this._rangeShown; this._rangeTo = d.range; this._rangeAge = 0;
  this._volley = { rep: rep, age: 0, word: this.timingWord(phase, sh), shot: sh, from: before.meRange, fast: false, done: false };
  this._phase = 'volley'; this._age = 0;
  this.queueNote(this.manoeuvreLine(rep), rep.crossed === 'foe' ? 'bad' : '');
  this._log.push('Turn ' + rep.turn + ': ' + this.manoeuvreLine(rep));
};
Scene_Broadside.prototype.manoeuvreLine = function (rep) {
  var fn = this._req.foe.name, T = { close: 'We close', open: 'We bear away', weather: 'We claw to windward', cross: 'We cross her bow', hold: 'We hold our course', board: 'We lay her aboard' };
  var F = { close: 'the ' + fn + ' closes', open: 'the ' + fn + ' bears away', weather: 'the ' + fn + ' claws to windward', cross: 'the ' + fn + ' crosses our bow', hold: 'the ' + fn + ' holds on', board: 'the ' + fn + ' lays us aboard' };
  var s = (T[rep.me.move] || 'We hold') + (rep.me.refused ? ' (no room to ' + (rep.me.refused === 'cross' ? 'cross' : rep.me.refused) + ')' : '') + '; ' + (F[rep.foe.move] || '') + '.';
  if (rep.crossed === 'me') s = 'We cross her bow and rake her!'; else if (rep.crossed === 'foe') s = 'She crosses our bow and rakes us!';
  if (rep.board) s = rep.board === 'carried' ? 'Boarders away! The deck is carried!' : 'Boarders away! They are thrown back.';
  return s;
};
/** the volley's beats, in frames from the orders: one table read by the volley AND by the HUD's reveal (wing §11) */
Scene_Broadside.VOLLEY = { fireMe: 44, noteMe: 72, landMe: 74, fireFoe: 118, noteFoe: 146, landFoe: 148, events: 176, done: 200 };
Scene_Broadside.prototype.updateVolley = function () {
  var v = this._volley, rep = v.rep, C = this._dp.core, P = Broadside.P, B = Scene_Broadside.VOLLEY;
  var speed = (Input.isPressed('ok') || Input.isPressed('shift') || TouchInput.isPressed()) ? 2 : 1;
  for (var s = 0; s < speed; s++) {
    var a = ++v.age;
    if (a === B.fireMe && rep.fireMe) this.fireBroadside(this._me, this._foe, rep.fireMe, 'me');
    if (a === B.landMe && rep.fireMe) this.landShot(this._foe, rep.fireMe);
    if (a === B.noteMe && rep.fireMe && !rep.fireMe.outOfRange) this.queueNote(this.fireLine(rep.fireMe, true, v.word), '');
    if (a === B.fireFoe && rep.fireFoe) this.fireBroadside(this._foe, this._me, rep.fireFoe, 'foe');
    if (a === B.landFoe && rep.fireFoe) this.landShot(this._me, rep.fireFoe);
    if (a === B.noteFoe && rep.fireFoe && !rep.fireFoe.outOfRange) this.queueNote(this.fireLine(rep.fireFoe, false), 'bad');
    if (a === B.events) this.onEvents(rep.events);
    if (a >= B.done && this._notes.length === 0 && !v.done) {
      v.done = true;
      if (rep.fireMe) this._log.push('  our ' + rep.fireMe.shot + ': ' + rep.fireMe.hits + ' of ' + rep.fireMe.fired + ' hit (' + v.word + ')');
      if (rep.fireFoe) this._log.push('  her ' + rep.fireFoe.shot + ': ' + rep.fireFoe.hits + ' of ' + rep.fireFoe.fired + ' hit');
      if (this._duel.over || this._duel.turn >= 80) this.enterEnding(); else this.enterOrders();
      return;
    }
  }
  this.refreshHud(false);
};
Scene_Broadside.prototype.fireLine = function (f, ours, word) {
  if (f.outOfRange) return ours ? 'Out of range: our guns are silent.' : 'Her guns cannot reach us.';
  return (ours ? 'Our ' : 'Her ') + f.shot + ' shot: ' + f.hits + ' of ' + f.fired + ' strike home' + (ours && word ? ', fired ' + word : '') + '.';
};
/** the ripple: gun by gun along her side, a flash and a cloud of smoke each */
Scene_Broadside.prototype.fireBroadside = function (from, to, f, who) {
  if (f.outOfRange) return;
  var sc = who === 'me' ? 1 : from.sprite.scale.x, n = Math.min(14, Math.max(3, f.fired)), L = from.L * sc, gauge = this._duel.gauge * (who === 'me' ? 1 : -1);
  for (var i = 0; i < n; i++) {
    var t = 0.18 + 0.64 * (i / Math.max(1, n - 1)), x = from.holder.x - L * 0.5 + L * t, y = from.holder.y - L * 0.035;
    this.spawn(this._flash, x, y, i * 2, 6, 0, 0, 0.7 * sc + 0.3, 0.9 * sc + 0.4, 1);
    // smoke: the windward ship's clears quickly, the leeward ship's hangs about her (the gauge's real advantage)
    // LOOKED AT 2026-10-11: at 220 frames and 0.9 two volleys alongside buried both hulls and every hole in them
    var drift = gauge > 0 ? 0.55 : 0.18;
    this.spawn(this._smoke, x + 10 * sc, y - 4 * sc, i * 2 + 2, gauge > 0 ? 130 : 180, drift, -0.12, 0.45 * sc, (gauge > 0 ? 1.45 : 1.85) * sc + 0.3, gauge > 0 ? 0.68 : 0.8);
  }
  Broadside.playSe(Broadside.P.se.cannon, 80, 100);
};
/** where the shot falls: splinters where it hits, white water where it misses */
Scene_Broadside.prototype.landShot = function (to, f) {
  if (f.outOfRange) return;
  var sc = to === this._me ? 1 : to.sprite.scale.x, L = to.L * sc, r = this._dp.core.rand, rr = { s: (this._duel.turn * 7919 + (to === this._me ? 1 : 2)) >>> 0 };
  var hits = Math.min(12, f.hits), miss = Math.min(10, f.fired - f.hits);
  for (var i = 0; i < hits; i++) { var x = to.holder.x - L * 0.42 + L * 0.84 * r(rr), y = to.holder.y - L * (0.02 + 0.05 * r(rr)) - (f.aim > 0.3 ? L * 0.35 * r(rr) : 0); this.spawn(this._splinter, x, y, i * 2, 16, 0, -0.1, 0.4 * sc + 0.3, 0.9 * sc + 0.4, 1); }
  for (var j = 0; j < miss; j++) { var mx = to.holder.x - L * 0.7 + L * 1.4 * r(rr), my = to.holder.y + (r(rr) - 0.6) * 18 * sc; this.spawn(this._splash, mx, my, j * 2, 36, 0, 0, 0.5 * sc + 0.2, 1.0 * sc + 0.3, 1); }
  if (hits) Broadside.playSe(Broadside.P.se.hit, 70, 100); if (miss) Broadside.playSe(Broadside.P.se.splash, 60, 100);
};
/** take the next sprite of a pool and start it: delay, life, drift, scale from s0 to s1, starting alpha */
Scene_Broadside.prototype.spawn = function (pool, x, y, delay, life, vx, vy, s0, s1, a0) {
  var p = pool[pool._next]; pool._next = (pool._next + 1) % pool.length;
  p.x = x; p.y = y; p._delay = delay; p._life = life; p._max = life; p._vx = vx; p._vy = vy; p._s0 = s0; p._s1 = s1; p._a0 = a0; p.visible = false;
};
Scene_Broadside.prototype.updatePool = function (pool, grav) {
  for (var i = 0; i < pool.length; i++) {
    var p = pool[i]; if (p._life <= 0) continue;
    if (p._delay > 0) { p._delay--; continue; }
    p.visible = true; p._life--; var u = 1 - p._life / p._max;
    p.x += p._vx; p.y += p._vy; if (grav) p._vy += grav;
    var s = p._s0 + (p._s1 - p._s0) * Math.sqrt(u); p.scale.x = s; p.scale.y = grav ? s * (u < 0.4 ? u / 0.4 : 1 - (u - 0.4) * 0.6) : s;
    p.opacity = 255 * p._a0 * (u < 0.1 ? u / 0.1 : 1 - Math.pow(u, 1.6));
    if (p._life <= 0) p.visible = false;
  }
};
Scene_Broadside.prototype.updateFx = function () { this.updatePool(this._smoke, 0); this.updatePool(this._flash, 0); this.updatePool(this._splinter, 0); this.updatePool(this._splash, 0); };

//---------------------------------------------------------------------------- damage, events, notes

Scene_Broadside.EVENT_LINES = {
  topmast: ['Our main topmast is shot away!', 'Her main topmast goes by the board!'],
  rags: ['Our canvas hangs in rags.', 'Her canvas hangs in rags.'],
  dismasted: ['We are dismasted!', 'She is dismasted: she cannot turn away.'],
  list: ['We are holed below and listing.', 'She is holed below: she lists.'],
  fire: ['Fire on our deck!', 'She is afire!'],
  sinking: ['We are going down!', 'She is going down!'],
};
Scene_Broadside.prototype.onEvents = function (events) {
  for (var i = 0; i < events.length; i++) {
    var e = events[i], k = e.indexOf(':'); if (k < 0) continue;
    var who = e.slice(0, k), what = e.slice(k + 1), L = Scene_Broadside.EVENT_LINES[what];
    if (!L) continue;
    this.queueNote(L[who === 'me' ? 0 : 1], who === 'me' ? 'bad' : '');
    this._log.push('  ' + L[who === 'me' ? 0 : 1]);
    if (what === 'topmast' || what === 'dismasted') Broadside.playSe(Broadside.P.se.mast, 80, 100);
    if (what === 'fire') Broadside.playSe('Fire1', 70, 100);
  }
};
/**
 * Rebake a ship only if her DRAWN damage changed (the number of holes, or a flag). `maxBakes` caps how many ships are
 * re-drawn in this call: the turn's change is spread one ship per frame (MEASURED 2026-10-11: both ships re-baked in
 * one frame cost 15 ms of update; one is about half). Returns true while a ship is still waiting to be checked.
 */
Scene_Broadside.prototype.applyDamageBakes = function (maxBakes) {
  var D = this._dp.ships.Damage, left = maxBakes == null ? 2 : maxBakes, pending = false;
  for (var i = 0; i < 2; i++) {
    var o = i ? this._foe : this._me, s = i ? this._duel.foe : this._duel.me, st = D.state(s), holes = D.holes(o.L, st.hull);   // the draw's own count (wing §11a)
    var key = holes * 16 + (st.fire ? 8 : 0) + (st.topmast ? 4 : 0) + (st.rags ? 2 : 0) + (st.dismasted ? 1 : 0);
    if (key !== o.bakeKey) { if (left <= 0) { pending = true; continue; } left--; o.bakeKey = key; this.bake(o, st); this.setFlames(o, st.fire); }
    o.list = st.hull < 0.5 ? (0.5 - st.hull) * 0.12 : 0;
  }
  return pending;
};
Scene_Broadside.prototype.setFlames = function (o, on) {
  var n = on ? 3 : 0;
  while (o.flames.length > n) { var f = o.flames.pop(); f.visible = false; f._owner = null; }
  for (var i = 0; i < this._flame.length && o.flames.length < n; i++) { var p = this._flame[i]; if (!p._owner) { p._owner = o.key; p._pt = (o.flames.length * 2 + 1) % o.info.deckPoints.length; p.visible = true; o.flames.push(p); } }
};
Scene_Broadside.prototype.queueNote = function (text, tone) { if (text) this._notes.push([text, tone]); };
Scene_Broadside.prototype.updateNote = function () {
  if (this._noteAge > 0) { this._noteAge--; if (this._noteAge < 12) this._note.opacity = this._noteAge * 21; if (this._noteAge === 0) this._note.visible = false; return; }
  if (!this._notes.length) return;
  var n = this._notes.shift();
  this._dp.sea.drawNote(this._note.bitmap.context, this._note.bitmap.width, 44, n[0], n[1]); this._note.bitmap._baseTexture.update();
  this._note.visible = true; this._note.opacity = 255; this._noteAge = 58;
};
/**
 * The ship the HUD shows: the live one, except during a volley before the broadside that hits her has landed, when it
 * is her state from before the turn (resolve() keeps it in this._pre).
 */
Scene_Broadside.prototype.hudShip = function (who) {
  var v = this._phase === 'volley' ? this._volley : null, B = Scene_Broadside.VOLLEY;
  if (v && v.age < (who === 'foe' ? B.landMe : B.landFoe)) return this._pre[who];
  return who === 'me' ? this._duel.me : this._duel.foe;
};
/**
 * The two ship cards and the compass: redrawn only when something on them changes. Called every volley frame, so the
 * change test compares numbers in place (no key string, no array per frame: wing §3 zero allocation).
 */
Scene_Broadside.prototype.refreshHud = function (force) {
  var d = this._duel, C = this._dp.core, f = C.frac, sm = this.hudShip('me'), sf = this.hudShip('foe'), last = this._hudLast, changed = !!force;
  var cur0 = Math.round(f(sm, 'hull') * 100), cur1 = Math.round(f(sm, 'rig') * 100), cur2 = Math.round(f(sm, 'crew') * 100);
  var cur3 = Math.round(f(sf, 'hull') * 100), cur4 = Math.round(f(sf, 'rig') * 100), cur5 = Math.round(f(sf, 'crew') * 100);
  var cur6 = d.gauge, cur7 = Math.round(d.range * 100), cur8 = sm.fire ? 1 : 0, cur9 = sf.fire ? 1 : 0;
  if (last[0] !== cur0 || last[1] !== cur1 || last[2] !== cur2 || last[3] !== cur3 || last[4] !== cur4 || last[5] !== cur5 || last[6] !== cur6 || last[7] !== cur7 || last[8] !== cur8 || last[9] !== cur9) changed = true;
  if (!changed) return;
  last[0] = cur0; last[1] = cur1; last[2] = cur2; last[3] = cur3; last[4] = cur4; last[5] = cur5; last[6] = cur6; last[7] = cur7; last[8] = cur8; last[9] = cur9;
  var K = Scene_Broadside.L, S = this._dp.sea, req = this._req, CLS = Scene_Broadside.CLS;
  var flags = function (s) { var o = []; if (s.fire) o.push('afire'); if (C.dismasted(s)) o.push('dismasted'); else if (f(s, 'rig') < 0.6) o.push('topmast gone'); if (f(s, 'hull') < 0.5) o.push('listing'); return o; };
  S.drawShipCard(this._cardMe.bitmap.context, K.card.w, K.card.h, { side: 0, name: req.me.name, cls: CLS[d.me.cls] + ', ' + d.me.guns + ' guns a side', hull: f(sm, 'hull'), rig: f(sm, 'rig'), crew: f(sm, 'crew'), flags: flags(sm) });
  S.drawShipCard(this._cardFoe.bitmap.context, K.card.w, K.card.h, { side: 1, name: req.foe.name, cls: CLS[d.foe.cls] + ', ' + d.foe.guns + ' guns a side', hull: f(sf, 'hull'), rig: f(sf, 'rig'), crew: f(sf, 'crew'), flags: flags(sf) });
  var rl = d.range <= C.ALONGSIDE + 1e-9 ? 'Alongside' : d.range <= C.SHOT.grape.maxRange ? 'Pistol shot' : d.range <= C.SHOT.chain.maxRange ? 'Musket shot' : 'Long gunshot';
  S.drawCompass(this._compass.bitmap.context, K.compass.w, K.compass.h, { windAngle: d.gauge >= 0 ? -Math.PI * 0.75 : -Math.PI * 0.25, gauge: d.gauge, range: 1 - d.range, rangeLabel: rl });
  this._cardMe.bitmap._baseTexture.update(); this._cardFoe.bitmap._baseTexture.update(); this._compass.bitmap._baseTexture.update();
};

//---------------------------------------------------------------------------- the end of a fight

Scene_Broadside.VERDICT = {
  'foe-sunk': ['SHE GOES DOWN', 'The {foe} sank under our guns.'], 'foe-struck': ['SHE STRIKES HER COLOURS', 'The {foe} hauled down her flag.'],
  'foe-taken': ['WE CARRY HER DECK', 'The {foe} was taken by boarding.'], 'foe-escaped': ['SHE GETS AWAY', 'The {foe} ran clear of our guns.'],
  'me-escaped': ['WE GET CLEAR', 'The {me} ran clear of the {foe}.'], 'me-struck': ['WE STRIKE OUR COLOURS', 'The {me} could fight no longer.'],
  'me-taken': ['SHE CARRIES OUR DECK', 'The {me} was taken by boarding.'], 'me-sunk': ['WE ARE SUNK', 'The {me} went down under the {foe}\'s guns.'],
  parted: ['THE SHIPS PART', 'Night fell and the {foe} was lost to sight.'],
};
Scene_Broadside.prototype.enterEnding = function () {
  var d = this._duel, ending = d.over || 'parted', who = /^foe-(sunk)/.test(ending) ? 'foe' : (/^me-(sunk)/.test(ending) ? 'me' : null);
  this._bakePending = this.applyDamageBakes(1); this.refreshHud(true);
  this._orders.visible = false; this._dial.visible = false; this._needle.visible = false;
  this._end = { ending: ending, who: who, list: 0, sink: 0, age: 0 };
  this._phase = 'ending'; this._age = 0;
};
Scene_Broadside.prototype.updateEnding = function () {
  var e = this._end; e.age++;
  if (e.who) { var o = e.who === 'me' ? this._me : this._foe; e.list = Math.min(0.32, e.age * 0.0028) * (e.who === 'me' ? -1 : 1); e.sink = Math.min(o.L * 0.55, e.age * e.age * 0.008); }
  if (e.ending === 'foe-escaped' || e.ending === 'me-escaped') { this._rangeFrom = this._rangeShown; this._rangeTo = 1.15; if (this._rangeAge >= 40) this._rangeAge = 0; }
  if (e.age >= 150 || (e.age > 40 && (Input.isTriggered('ok') || TouchInput.isTriggered()))) this.enterLog();
};
Scene_Broadside.prototype.enterLog = function () {
  var d = this._duel, C = this._dp.core, f = C.frac, req = this._req, e = this._end, V = Scene_Broadside.VERDICT[e.ending] || Scene_Broadside.VERDICT.parted;
  var line = V[1].replace('{foe}', req.foe.name).replace('{me}', req.me.name).replace('{foe}', req.foe.name);
  var CLS = Scene_Broadside.CLS;
  var win = C.isWin(e.ending);
  this._result = { ending: e.ending, win: win, turns: d.turn, me: { hull: f(d.me, 'hull'), rig: f(d.me, 'rig'), crew: f(d.me, 'crew') }, foe: { hull: f(d.foe, 'hull'), rig: f(d.foe, 'rig'), crew: f(d.foe, 'crew') } };
  this._dp.sea.drawLog(this._logSp.bitmap.context, this._logSp.bitmap.width, this._logSp.bitmap.height, { verdict: V[0], line: line, good: win || e.ending === 'me-escaped', turns: d.turn,
    me: { name: req.me.name, cls: CLS[d.me.cls], hull: f(d.me, 'hull'), rig: f(d.me, 'rig'), crew: f(d.me, 'crew') },
    foe: { name: req.foe.name, cls: CLS[d.foe.cls], hull: f(d.foe, 'hull'), rig: f(d.foe, 'rig'), crew: f(d.foe, 'crew') }, log: this._log,
    portrait: { canvas: this._foe.bmp.canvas, waterY: this._foe.oy, caption: 'The ' + req.foe.name + ' at the end of the action' } });
  this._logSp.bitmap._baseTexture.update(); this._logSp.visible = true; this._logSp.opacity = 0;
  this._phase = 'log'; this._age = 0;
  var me = win ? Broadside.P.me_.victory : (C.isLoss(e.ending) ? Broadside.P.me_.defeat : '');
  if (me) AudioManager.playMe({ name: me, volume: 90, pitch: 100, pan: 0 });
};
Scene_Broadside.prototype.updateLog = function () {
  this._logSp.opacity = Math.min(255, this._age * 14);
  if (this._age > 30 && (Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered())) this.leave();
};
Scene_Broadside.prototype.leave = function () {
  if (this._phase === 'leaving') return;
  Broadside.apply(this._req, this._result);
  this._phase = 'leaving'; this.startFadeOut(this.fadeSpeed(), false);
  if (this._savedBgm) AudioManager.replayBgm(this._savedBgm); else if (Broadside.P.bgm) AudioManager.fadeOutBgm(1);
  if (this._savedBgs) AudioManager.replayBgs(this._savedBgs); else if (Broadside.P.bgs) AudioManager.fadeOutBgs(1);
};
Scene_Broadside.prototype.terminate = function () { Scene_Base.prototype.terminate.call(this); Broadside.setOpen(false); };
