/*:
 * @target MZ
 * @plugindesc Broadside 3/4 - the drawn sea and sky, gunsmoke, splashes and flame, and the ship's instruments (gauges, compass, clinometer, orders, the log). No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * BroadsideSea.js - part of Broadside. Enable it with the other Broadside files (any order). It has no commands or
 * parameters of its own; Broadside.js reads it.
 *
 * Every line of this plugin was written with AI assistance.
 */
/*
 * Everything here draws into a 2D canvas context and allocates only when it is called, which the scene does when
 * something CHANGES (a new fight, a damage event, a new order selected), never per frame. Animation is done in the
 * scene by moving, scaling and fading the sprites these drawings become.
 */
var BroadsideSea = (function () {
  'use strict';

  var FACE = '"Palatino Linotype", "Book Antiqua", Palatino, Georgia, serif';
  var INK = '#2a1c10', PAPER = '#efe2c2', PAPER_D = '#d8c39a', RED = '#7a1f18', BRASS = '#b48a3c', BRASS_L = '#e0c27a';

  /* ------------------------------------------------------------ seeded helpers (drawing only) */
  function rng(seed) { var s = (seed >>> 0) || 1; return function () { s = (Math.imul(s, 1103515245) + 12345) >>> 0; return ((s >>> 8) & 0xffffff) / 0x1000000; }; }
  function hash(str) { var h = 2166136261; str = String(str); for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }

  /* ------------------------------------------------------------ the weather of a fight */
  /** three lights a fight can be fought in; the scene picks by parameter or by the seed */
  var SKIES = {
    afternoon: { sky: ['#5b7a99', '#a9b9c4', '#e2dccb'], sea: ['#8a9ea3', '#4f6a74', '#1f313a'], cloud: ['#f4efe2', '#c8cfd4'], crest: [214, 228, 230], smoke: [232, 228, 218] },
    dusk: { sky: ['#3d3a5c', '#b8706a', '#f0b27a'], sea: ['#8a7a80', '#4a4a5c', '#1a1c2a'], cloud: ['#f4c79a', '#8a6a7a'], crest: [240, 196, 160], smoke: [226, 206, 196] },
    squall: { sky: ['#4a545c', '#7c868a', '#a8aca6'], sea: ['#6e7c7c', '#3e4c4e', '#182224'], cloud: ['#9aa2a4', '#5c666a'], crest: [200, 210, 208], smoke: [210, 212, 206] },
  };
  var SKY_IDS = ['afternoon', 'dusk', 'squall'];
  var HORIZON = 250;

  /** the sky and the far sea, painted once per fight */
  function drawBackdrop(ctx, W, H, skyId, seed) {
    var S = SKIES[skyId] || SKIES.afternoon, r = rng(hash('sky' + seed));
    var sky = ctx.createLinearGradient(0, 0, 0, HORIZON); sky.addColorStop(0, S.sky[0]); sky.addColorStop(0.62, S.sky[1]); sky.addColorStop(1, S.sky[2]);
    ctx.fillStyle = sky; ctx.fillRect(0, 0, W, HORIZON);
    // cloud banks: long soft layered ellipses, lit from above, thinning toward the horizon
    for (var i = 0; i < 26; i++) {
      var cy = 30 + Math.pow(r(), 0.8) * 190, cx = r() * W, rw = 50 + r() * 150 * (1 - cy / 300), rh = 7 + r() * 16 * (1 - cy / 320);
      ctx.globalAlpha = 0.18 + r() * 0.22;
      ctx.fillStyle = S.cloud[1]; ctx.beginPath(); ctx.ellipse(cx, cy + rh * 0.35, rw, rh, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = S.cloud[0]; ctx.beginPath(); ctx.ellipse(cx - rw * 0.08, cy, rw * 0.86, rh * 0.8, 0, 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalAlpha = 1;
    // the sea under the horizon
    var sea = ctx.createLinearGradient(0, HORIZON, 0, H); sea.addColorStop(0, S.sea[0]); sea.addColorStop(0.3, S.sea[1]); sea.addColorStop(1, S.sea[2]);
    ctx.fillStyle = sea; ctx.fillRect(0, HORIZON, W, H - HORIZON);
    // a haze line where sea meets sky
    var hz = ctx.createLinearGradient(0, HORIZON - 6, 0, HORIZON + 10); hz.addColorStop(0, 'rgba(255,255,255,0)'); hz.addColorStop(0.5, 'rgba(255,250,236,0.35)'); hz.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = hz; ctx.fillRect(0, HORIZON - 6, W, 16);
    swell(ctx, W, H, S, r, 0, 1, 1);
  }
  /**
   * Painted swell, back to front: each row a filled band whose top edge is the wave (two sines), shaded by distance, the
   * crest lit only where the face tilts toward the light, rows bunching toward the horizon. `t0..t1` picks the rows (the
   * scene paints the near rows into their own layer so they can drift), `alpha` scales the whole layer.
   */
  function swell(ctx, W, H, S, r, t0, t1, alpha) {
    var ROWS = 36;
    for (var k = 0; k < ROWS; k++) {
      var t = k / (ROWS - 1);
      var ph = r() * 6.28, ph2 = r() * 6.28;   // drawn for every row so the rows do not change with t0..t1
      if (t < t0 || t > t1) continue;
      var y = HORIZON + 2 + (H - HORIZON) * Math.pow(t, 1.7), amp = 0.8 + t * 9, wl = 40 + t * 260;
      var wy = function (x) { return y + Math.sin(x / wl * 6.28 + ph) * amp + Math.sin(x / (wl * 0.37) + ph2) * amp * 0.35; };
      ctx.fillStyle = 'rgba(16,30,38,' + ((0.05 + t * 0.10) * alpha) + ')';
      ctx.beginPath(); ctx.moveTo(0, wy(0)); for (var x = 6; x <= W; x += 6) ctx.lineTo(x, wy(x));
      ctx.lineTo(W, y + amp * 3 + 6 + t * 30); ctx.lineTo(0, y + amp * 3 + 6 + t * 30); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(' + S.crest[0] + ',' + S.crest[1] + ',' + S.crest[2] + ',' + ((0.16 + t * 0.22) * alpha) + ')'; ctx.lineWidth = 0.5 + t * 1.4;
      for (var x2 = 0; x2 < W; x2 += 6) { var a = wy(x2), b = wy(x2 + 6); if (b < a - amp * 0.05) { ctx.beginPath(); ctx.moveTo(x2, a); ctx.lineTo(x2 + 6, b); ctx.stroke(); } }
    }
  }
  /** a strip of drifting crest glints, tileable across its width (the scene scrolls two copies) */
  function drawGlints(ctx, W, H, skyId, seed) {
    var S = SKIES[skyId] || SKIES.afternoon, r = rng(hash('glint' + seed));
    ctx.clearRect(0, 0, W, H);
    // LOOKED AT 2026-10-11: 140 glints at up to 0.40 laid a field of white dashes over the swell; fewer and fainter
    for (var i = 0; i < 100; i++) {
      var t = Math.pow(r(), 0.7), y = H * t, len = 4 + t * 26, x = r() * W;
      ctx.strokeStyle = 'rgba(' + S.crest[0] + ',' + S.crest[1] + ',' + S.crest[2] + ',' + (0.08 + t * 0.24) + ')'; ctx.lineWidth = 0.6 + t * 1.3;
      ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x + len * 0.5, y - 1.5 - t * 2, x + len, y); ctx.stroke();
      if (x + len > W) { ctx.beginPath(); ctx.moveTo(x - W, y); ctx.quadraticCurveTo(x - W + len * 0.5, y - 1.5 - t * 2, x - W + len, y); ctx.stroke(); }
    }
  }
  /** the water a hull pushes aside: a soft shadow and a broken line of white water, drawn per ship, centred */
  function drawWash(ctx, w, h, L, skyId) {
    var S = SKIES[skyId] || SKIES.afternoon, cx = w / 2, cy = h / 2, r = rng(hash('wash' + L));
    ctx.clearRect(0, 0, w, h);
    var g = ctx.createRadialGradient(cx, cy, 0, cx, cy, L * 0.55); g.addColorStop(0, 'rgba(10,18,24,0.42)'); g.addColorStop(1, 'rgba(10,18,24,0)');
    ctx.save(); ctx.scale(1, 0.09); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy / 0.09, L * 0.55, 0, Math.PI * 2); ctx.fill(); ctx.restore();
    // white water: overlapping soft lens shapes along the waterline, thicker at the bow wave (left: every ship heads left)
    for (var i = 0; i < 40; i++) {
      var u = r(), x = cx - L * 0.5 + u * L, th = (1.2 + (1 - u) * 2.6) * (L / 300), len = L * (0.03 + r() * 0.06);
      ctx.fillStyle = 'rgba(' + S.crest[0] + ',' + S.crest[1] + ',' + S.crest[2] + ',' + (0.35 + r() * 0.4) + ')';
      ctx.beginPath(); ctx.ellipse(x, cy + (r() - 0.5) * th, len, th, 0, 0, Math.PI * 2); ctx.fill();
    }
    // the bow wave
    ctx.fillStyle = 'rgba(' + S.crest[0] + ',' + S.crest[1] + ',' + S.crest[2] + ',0.8)';
    ctx.beginPath(); ctx.ellipse(cx - L * 0.5, cy - L * 0.004, L * 0.05, L * 0.012, -0.3, 0, Math.PI * 2); ctx.fill();
  }

  /* ------------------------------------------------------------ effect textures (drawn once per fight) */
  /** gunsmoke: a cloud of soft lobes, lit from above, so a puff reads as smoke and not as a bubble */
  function drawSmoke(ctx, w, h, skyId, variant) {
    var S = SKIES[skyId] || SKIES.afternoon, r = rng(hash('smoke' + variant));
    ctx.clearRect(0, 0, w, h);
    for (var i = 0; i < 16; i++) {
      var x = w * (0.22 + r() * 0.56), y = h * (0.3 + r() * 0.45), rad = Math.min(w, h) * (0.16 + r() * 0.2);
      var lit = 0.85 + r() * 0.15, sh = (1 - (y / h)) * 0.25;
      var c0 = 'rgba(' + Math.round(S.smoke[0] * lit) + ',' + Math.round(S.smoke[1] * lit) + ',' + Math.round(S.smoke[2] * lit) + ',' + (0.30 + sh) + ')';
      var g = ctx.createRadialGradient(x - rad * 0.2, y - rad * 0.3, 0, x, y, rad);
      g.addColorStop(0, c0); g.addColorStop(0.7, 'rgba(' + S.smoke[0] + ',' + S.smoke[1] + ',' + S.smoke[2] + ',0.12)'); g.addColorStop(1, 'rgba(' + S.smoke[0] + ',' + S.smoke[1] + ',' + S.smoke[2] + ',0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, rad, 0, Math.PI * 2); ctx.fill();
    }
    // a grey underside: smoke is darker where the light does not reach
    var gb = ctx.createLinearGradient(0, h * 0.4, 0, h * 0.9); gb.addColorStop(0, 'rgba(90,92,96,0)'); gb.addColorStop(1, 'rgba(90,92,96,0.22)');
    ctx.globalCompositeOperation = 'source-atop'; ctx.fillStyle = gb; ctx.fillRect(0, 0, w, h); ctx.globalCompositeOperation = 'source-over';
  }
  /**
   * A shot falling short: jets of water thrown up in a fan from a foaming base, thinning to droplets and mist at the
   * top. LOOKED AT 2026-10-11: the first splash, a solid column with six dots for a crown, read as a milk bottle.
   */
  function drawSplash(ctx, w, h) {
    ctx.clearRect(0, 0, w, h);
    var r = rng(4242);
    var g = ctx.createRadialGradient(w / 2, h * 0.42, 0, w / 2, h * 0.42, w * 0.5); g.addColorStop(0, 'rgba(236,244,246,0.42)'); g.addColorStop(1, 'rgba(236,244,246,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    ctx.lineCap = 'round';
    for (var i = 0; i < 9; i++) {
      var a = (i / 8 - 0.5) * 0.95 + (r() - 0.5) * 0.12, len = h * (0.55 + r() * 0.4) * (1 - Math.abs(a) * 0.45);
      var x0 = w / 2 + (r() - 0.5) * w * 0.2, x1 = w / 2 + Math.sin(a) * len * 0.6, y1 = h - len;
      var lg = ctx.createLinearGradient(0, h, 0, y1); lg.addColorStop(0, 'rgba(242,247,248,0.95)'); lg.addColorStop(1, 'rgba(242,247,248,0.12)');
      ctx.strokeStyle = lg; ctx.lineWidth = 2 + r() * 2.6;
      ctx.beginPath(); ctx.moveTo(x0, h - 2); ctx.quadraticCurveTo(w / 2 + Math.sin(a) * len * 0.2, h - len * 0.62, x1, y1); ctx.stroke();
    }
    for (var k = 0; k < 16; k++) { ctx.fillStyle = 'rgba(244,248,250,' + (0.45 + r() * 0.45) + ')'; ctx.beginPath(); ctx.arc(w / 2 + (r() - 0.5) * w * 0.85, h * (0.04 + r() * 0.46), 0.8 + r() * 1.5, 0, Math.PI * 2); ctx.fill(); }
    ctx.fillStyle = 'rgba(236,242,244,0.9)'; ctx.beginPath(); ctx.ellipse(w / 2, h - 3, w * 0.42, 3.5, 0, 0, Math.PI * 2); ctx.fill();
  }
  /** the muzzle flash: a short orange tongue with a white core */
  function drawFlash(ctx, w, h) {
    ctx.clearRect(0, 0, w, h);
    var g = ctx.createRadialGradient(w * 0.3, h * 0.5, 0, w * 0.3, h * 0.5, w * 0.7);
    g.addColorStop(0, 'rgba(255,252,230,1)'); g.addColorStop(0.25, 'rgba(255,214,120,0.95)'); g.addColorStop(0.6, 'rgba(232,120,40,0.6)'); g.addColorStop(1, 'rgba(160,60,20,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(0, h * 0.5); ctx.quadraticCurveTo(w * 0.4, -h * 0.1, w, h * 0.5); ctx.quadraticCurveTo(w * 0.4, h * 1.1, 0, h * 0.5); ctx.fill();
  }
  /** a hit: timber thrown out of her side */
  function drawSplinter(ctx, w, h) {
    ctx.clearRect(0, 0, w, h);
    var r = rng(77), g = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w / 2);
    g.addColorStop(0, 'rgba(255,230,170,0.95)'); g.addColorStop(0.4, 'rgba(210,140,70,0.6)'); g.addColorStop(1, 'rgba(120,70,30,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(w / 2, h / 2, w / 2, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = 'rgba(110,74,40,0.95)'; ctx.lineCap = 'round';
    for (var i = 0; i < 9; i++) { var a = r() * 6.28, l = w * (0.25 + r() * 0.25); ctx.lineWidth = 1 + r() * 1.6; ctx.beginPath(); ctx.moveTo(w / 2 + Math.cos(a) * w * 0.08, h / 2 + Math.sin(a) * h * 0.08); ctx.lineTo(w / 2 + Math.cos(a) * l, h / 2 + Math.sin(a) * l); ctx.stroke(); }
  }
  /**
   * One frame of a fire on deck (three frames make the flicker): a glow, then leaning tongues of flame, each a
   * red-orange teardrop with a yellow body and a pale core. LOOKED AT 2026-10-11: the first fire, a row of sawtooth
   * triangles in three flat colours, read as a crown, not a flame.
   */
  function drawFlame(ctx, w, h, k) {
    ctx.clearRect(0, 0, w, h);
    var r = rng(900 + k);
    var g = ctx.createRadialGradient(w / 2, h * 0.82, 0, w / 2, h * 0.82, w * 0.6); g.addColorStop(0, 'rgba(255,170,60,0.42)'); g.addColorStop(1, 'rgba(255,120,30,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    var tongue = function (x, y, bw, th, lean, col) {
      ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(x - bw, y);
      ctx.bezierCurveTo(x - bw, y - th * 0.45, x + lean - bw * 0.25, y - th * 0.72, x + lean, y - th);
      ctx.bezierCurveTo(x + lean + bw * 0.25, y - th * 0.72, x + bw, y - th * 0.45, x + bw, y); ctx.closePath(); ctx.fill();
    };
    for (var t = 0; t < 4; t++) {
      var cx = w * (0.28 + 0.44 * r()), th = h * (0.42 + r() * 0.5), bw = w * (0.14 + r() * 0.12), lean = (r() - 0.5) * w * 0.3;
      tongue(cx, h - 2, bw, th, lean, 'rgba(206,70,24,0.82)');
      tongue(cx, h - 2, bw * 0.64, th * 0.74, lean * 0.7, 'rgba(250,158,48,0.92)');
      tongue(cx, h - 2, bw * 0.32, th * 0.44, lean * 0.4, 'rgba(255,238,186,0.95)');
    }
  }

  /* ------------------------------------------------------------ the instruments */
  function rr(ctx, x, y, w, h, rad) { ctx.beginPath(); ctx.moveTo(x + rad, y); ctx.lineTo(x + w - rad, y); ctx.quadraticCurveTo(x + w, y, x + w, y + rad); ctx.lineTo(x + w, y + h - rad); ctx.quadraticCurveTo(x + w, y + h, x + w - rad, y + h); ctx.lineTo(x + rad, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - rad); ctx.lineTo(x, y + rad); ctx.quadraticCurveTo(x, y, x + rad, y); ctx.closePath(); }
  /** a sheet of chart paper with a ruled border and foxing: every panel in the scene sits on one */
  function plate(ctx, x, y, w, h, seed) {
    var r = rng(hash('plate' + seed + w + h));
    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,0.45)'; ctx.shadowBlur = 10; ctx.shadowOffsetY = 3;
    var g = ctx.createLinearGradient(x, y, x, y + h); g.addColorStop(0, PAPER); g.addColorStop(1, PAPER_D);
    ctx.fillStyle = g; rr(ctx, x, y, w, h, 4); ctx.fill();
    ctx.restore();
    // foxing and stains
    ctx.save(); rr(ctx, x, y, w, h, 4); ctx.clip();
    for (var i = 0; i < 10; i++) { var fx = x + r() * w, fy = y + r() * h, fr = 3 + r() * 14; var fg = ctx.createRadialGradient(fx, fy, 0, fx, fy, fr); fg.addColorStop(0, 'rgba(150,104,52,0.10)'); fg.addColorStop(1, 'rgba(150,104,52,0)'); ctx.fillStyle = fg; ctx.fillRect(fx - fr, fy - fr, fr * 2, fr * 2); }
    var eg = ctx.createRadialGradient(x + w / 2, y + h / 2, Math.min(w, h) * 0.3, x + w / 2, y + h / 2, Math.max(w, h) * 0.75); eg.addColorStop(0, 'rgba(120,80,40,0)'); eg.addColorStop(1, 'rgba(120,80,40,0.22)');
    ctx.fillStyle = eg; ctx.fillRect(x, y, w, h);
    ctx.restore();
    // a double rule, the chart-maker's border
    ctx.strokeStyle = INK; ctx.lineWidth = 1.4; rr(ctx, x + 4, y + 4, w - 8, h - 8, 2); ctx.stroke();
    ctx.lineWidth = 0.6; rr(ctx, x + 7, y + 7, w - 14, h - 14, 1); ctx.stroke();
  }
  function fit(ctx, text, maxW, size, style) { ctx.font = (style ? style + ' ' : '') + size + 'px ' + FACE; while (size > 8 && ctx.measureText(text).width > maxW) { size--; ctx.font = (style ? style + ' ' : '') + size + 'px ' + FACE; } return size; }
  /**
   * The text to draw in `maxW`: shrunk from `size`, but never below `minSize`, and cut with an ellipsis if it still
   * does not fit. Sets ctx.font. (MEASURED 2026-10-11, breakit.js: a 90-character ship name shrunk to the 8 px floor
   * and still ran 220 px across her own class label; a shorter name with an emoji collided with it too.)
   */
  function fitText(ctx, text, maxW, size, style, minSize) {
    text = String(text == null ? '' : text); var lo = minSize || 8, s = fit(ctx, text, maxW, size, style);
    if (s < lo) { s = lo; ctx.font = (style ? style + ' ' : '') + s + 'px ' + FACE; }
    if (ctx.measureText(text).width <= maxW) return text;
    var t = text; while (t.length > 1 && ctx.measureText(t + '…').width > maxW) t = t.slice(0, -1);
    return t.replace(/\s+$/, '') + '…';
  }
  /** an engraved scale: ticks, a filled bar in the track's ink, the number */
  function gauge(ctx, x, y, w, label, frac, col, dark) {
    ctx.fillStyle = INK; ctx.font = 'italic 12px ' + FACE; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(label, x, y + 5);
    var bx = x + 44, bw = w - 44 - 34, f = Math.max(0, Math.min(1, frac));
    ctx.fillStyle = 'rgba(60,40,20,0.12)'; ctx.fillRect(bx, y, bw, 10);
    var g = ctx.createLinearGradient(0, y, 0, y + 10); g.addColorStop(0, col); g.addColorStop(1, dark);
    ctx.fillStyle = g; ctx.fillRect(bx, y + 1, bw * f, 8);
    // hatching on the spent part, the engraver's way of saying "gone"
    ctx.save(); ctx.beginPath(); ctx.rect(bx + bw * f, y, bw * (1 - f), 10); ctx.clip(); ctx.strokeStyle = 'rgba(42,28,16,0.35)'; ctx.lineWidth = 0.7;
    for (var hx = bx - 10; hx < bx + bw; hx += 4) { ctx.beginPath(); ctx.moveTo(hx, y + 10); ctx.lineTo(hx + 10, y); ctx.stroke(); }
    ctx.restore();
    ctx.strokeStyle = INK; ctx.lineWidth = 1; ctx.strokeRect(bx + 0.5, y + 0.5, bw - 1, 9);
    for (var t = 1; t < 10; t++) { ctx.beginPath(); ctx.moveTo(bx + bw * t / 10, y + 10); ctx.lineTo(bx + bw * t / 10, y + (t === 5 ? 13 : 12)); ctx.stroke(); }
    ctx.textAlign = 'right'; ctx.font = 'bold 12px ' + FACE; ctx.fillStyle = f < 0.25 ? RED : INK; ctx.fillText(Math.round(f * 100) + '%', x + w, y + 5);
  }
  /**
   * A ship's card: her name, her class, and the three tracks as engraved gauges.
   * info = {name, cls, hull, rig, crew (fractions), side: 0 player / 1 enemy, flags: [..]}
   */
  function drawShipCard(ctx, w, h, info) {
    ctx.clearRect(0, 0, w, h);
    plate(ctx, 2, 2, w - 4, h - 6, 'card' + info.side);   // the paper is the side's, so a card redrawn with new numbers keeps its stains
    // the class label is measured first and the name gets the rest of the line, so the two can never overlap
    ctx.textBaseline = 'middle'; ctx.font = 'italic 12px ' + FACE; var clsW = Math.min(w * 0.55, ctx.measureText(info.cls).width);
    ctx.textAlign = 'left'; ctx.fillStyle = info.side ? RED : '#1f3a66';
    var nm = fitText(ctx, info.name, w - 32 - clsW - 12, 17, 'bold', 12); ctx.fillText(nm, 16, 20);
    ctx.textAlign = 'right'; ctx.fillStyle = '#6a4a2a'; var cl = fitText(ctx, info.cls, clsW, 12, 'italic', 9); ctx.fillText(cl, w - 16, 20);
    // LOOKED AT 2026-10-11: at 94 px tall the flags line was written over the Crew gauge; the card is 110 now and the
    // flags have a row of their own under the gauges
    gauge(ctx, 16, 34, w - 32, 'Hull', info.hull, '#8a5a2e', '#5a3818');
    gauge(ctx, 16, 51, w - 32, 'Rig', info.rig, '#e8dcc0', '#b8a888');
    gauge(ctx, 16, 68, w - 32, 'Crew', info.crew, '#a8402e', '#6a2418');
    if (info.flags && info.flags.length) { ctx.textAlign = 'left'; ctx.fillStyle = RED; var fl = info.flags.join(' · '); ctx.fillText(fitText(ctx, fl, w - 32, 12, 'italic', 10), 16, Math.max(92, h - 20)); }
  }
  /**
   * The compass rose with the wind and the range: who holds the weather gauge, and how far apart the ships lie.
   * info = {windAngle (rad, the direction the wind blows TOWARD), gauge: 1 yours / -1 hers / 0 neither, range 0..1, rangeLabel}
   */
  function drawCompass(ctx, w, h, info) {
    ctx.clearRect(0, 0, w, h);
    plate(ctx, 2, 2, w - 4, h - 6, 'compass');
    var cx = 52, cy = h / 2 - 1, R = Math.min(34, h / 2 - 10);
    // the rose: sixteen points, alternate inks, a fleur at north
    for (var k = 0; k < 16; k++) {
      var a = k * Math.PI / 8 - Math.PI / 2, len = k % 4 === 0 ? R : (k % 2 === 0 ? R * 0.7 : R * 0.48), wid = k % 4 === 0 ? 0.2 : 0.16;
      for (var side = 0; side < 2; side++) {
        ctx.fillStyle = side ? (k % 2 ? '#8a6a3a' : INK) : (k % 2 ? '#d8c08a' : '#6a4a2a');
        ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(a + (side ? wid : -wid)) * len * 0.3, cy + Math.sin(a + (side ? wid : -wid)) * len * 0.3); ctx.lineTo(cx + Math.cos(a) * len, cy + Math.sin(a) * len); ctx.closePath(); ctx.fill();
      }
    }
    ctx.strokeStyle = INK; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(cx, cy, R * 0.86, 0, Math.PI * 2); ctx.stroke();
    ctx.fillStyle = INK; ctx.font = 'bold 9px ' + FACE; ctx.textAlign = 'center'; ctx.fillText('N', cx, cy - R - 1);
    // the wind: a feathered arrow across the rose
    var wa = info.windAngle, ax = Math.cos(wa), ay = Math.sin(wa);
    ctx.strokeStyle = '#1f3a66'; ctx.lineWidth = 2.4; ctx.beginPath(); ctx.moveTo(cx - ax * R * 0.95, cy - ay * R * 0.95); ctx.lineTo(cx + ax * R * 0.8, cy + ay * R * 0.8); ctx.stroke();
    ctx.fillStyle = '#1f3a66'; ctx.beginPath(); ctx.moveTo(cx + ax * R, cy + ay * R); ctx.lineTo(cx + ax * R * 0.68 - ay * 6, cy + ay * R * 0.68 + ax * 6); ctx.lineTo(cx + ax * R * 0.68 + ay * 6, cy + ay * R * 0.68 - ax * 6); ctx.closePath(); ctx.fill();
    for (var f = 0; f < 3; f++) { var fx = cx - ax * R * (0.95 - f * 0.12), fy = cy - ay * R * (0.95 - f * 0.12); ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(fx, fy); ctx.lineTo(fx - ax * 5 - ay * 5, fy - ay * 5 + ax * 5); ctx.stroke(); }
    // the gauge and the range, as words and an engraved scale. LOOKED AT 2026-10-11: on one line "Range" and "Pistol
    // shot" were written over each other and over the marker, and "The enemy's" ran into the border; now every line
    // has its own row and is FITTED to the column
    var tx = 100, tw = w - tx - 14;
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#6a4a2a'; ctx.font = 'italic 11px ' + FACE; ctx.fillText('Weather gauge', tx, 20);
    var gw = info.gauge > 0 ? 'Yours' : (info.gauge < 0 ? 'The enemy\'s' : 'Neither');
    ctx.fillStyle = info.gauge > 0 ? '#1f3a66' : (info.gauge < 0 ? RED : INK); fit(ctx, gw, tw, 14, 'bold'); ctx.fillText(gw, tx, 36);
    ctx.fillStyle = '#6a4a2a'; ctx.font = 'italic 11px ' + FACE; ctx.fillText('Range', tx, 54);
    ctx.fillStyle = INK; fit(ctx, info.rangeLabel, tw, 13, 'bold'); ctx.fillText(info.rangeLabel, tx, 68);
    var sx = tx, sw = tw, sy = h - 26;
    ctx.strokeStyle = INK; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(sx + sw, sy); ctx.stroke();
    for (var t = 0; t <= 4; t++) { ctx.beginPath(); ctx.moveTo(sx + sw * t / 4, sy - 3); ctx.lineTo(sx + sw * t / 4, sy + 3); ctx.stroke(); }
    var mx = sx + sw * Math.max(0, Math.min(1, info.range));
    ctx.fillStyle = RED; ctx.beginPath(); ctx.moveTo(mx, sy - 1); ctx.lineTo(mx - 4.5, sy - 9); ctx.lineTo(mx + 4.5, sy - 9); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#6a4a2a'; ctx.font = 'italic 9px ' + FACE; ctx.textAlign = 'left'; ctx.fillText('far', sx, sy + 9); ctx.textAlign = 'right'; ctx.fillText('alongside', sx + sw, sy + 9);
  }

  /** the icons on the order cards: drawn marks, one per manoeuvre and per shot */
  function icon(ctx, id, x, y, s, ink) {
    ctx.save(); ctx.translate(x, y); ctx.strokeStyle = ink; ctx.fillStyle = ink; ctx.lineWidth = Math.max(1.4, s * 0.09); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    var hullMark = function (hx, hy, k) { ctx.beginPath(); ctx.moveTo(hx - s * 0.32 * k, hy); ctx.quadraticCurveTo(hx, hy + s * 0.22 * k, hx + s * 0.32 * k, hy - s * 0.04 * k); ctx.lineTo(hx - s * 0.32 * k, hy); ctx.fill(); ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(hx, hy - s * 0.4 * k); ctx.stroke(); };
    var arrow = function (x0, y0, x1, y1) { ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); var a = Math.atan2(y1 - y0, x1 - x0); ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x1 - Math.cos(a - 0.5) * s * 0.18, y1 - Math.sin(a - 0.5) * s * 0.18); ctx.lineTo(x1 - Math.cos(a + 0.5) * s * 0.18, y1 - Math.sin(a + 0.5) * s * 0.18); ctx.closePath(); ctx.fill(); };
    if (id === 'close') { hullMark(-s * 0.3, s * 0.1, 0.7); hullMark(s * 0.3, s * 0.1, 0.7); arrow(-s * 0.05, -s * 0.3, s * 0.12, -s * 0.3); arrow(s * 0.05, -s * 0.18, -s * 0.12, -s * 0.18); }
    else if (id === 'open') { hullMark(-s * 0.3, s * 0.1, 0.7); hullMark(s * 0.3, s * 0.1, 0.7); arrow(-s * 0.02, -s * 0.3, -s * 0.36, -s * 0.3); arrow(s * 0.02, -s * 0.3, s * 0.36, -s * 0.3); }
    else if (id === 'weather') { hullMark(0, s * 0.18, 0.8); for (var w = 0; w < 3; w++) { ctx.beginPath(); ctx.moveTo(-s * 0.4, -s * 0.38 + w * s * 0.13); ctx.quadraticCurveTo(-s * 0.1, -s * 0.46 + w * s * 0.13, s * 0.1, -s * 0.38 + w * s * 0.13); ctx.stroke(); } arrow(s * 0.1, -s * 0.12, s * 0.42, -s * 0.12); }
    else if (id === 'cross') { ctx.save(); ctx.translate(s * 0.1, s * 0.05); ctx.rotate(Math.PI / 2); hullMark(0, 0, 0.75); ctx.restore(); ctx.setLineDash([s * 0.08, s * 0.06]); ctx.beginPath(); ctx.moveTo(-s * 0.42, -s * 0.3); ctx.quadraticCurveTo(-s * 0.1, -s * 0.42, s * 0.42, -s * 0.36); ctx.stroke(); ctx.setLineDash([]); arrow(s * 0.3, -s * 0.37, s * 0.44, -s * 0.36); }
    else if (id === 'hold') { hullMark(0, s * 0.15, 0.85); ctx.beginPath(); ctx.moveTo(-s * 0.4, s * 0.34); ctx.lineTo(s * 0.4, s * 0.34); ctx.stroke(); }
    else if (id === 'board') { ctx.beginPath(); ctx.moveTo(-s * 0.35, s * 0.35); ctx.lineTo(s * 0.3, -s * 0.3); ctx.moveTo(s * 0.35, s * 0.35); ctx.lineTo(-s * 0.3, -s * 0.3); ctx.stroke(); ctx.beginPath(); ctx.arc(s * 0.3, -s * 0.3, s * 0.08, 0, 7); ctx.arc(-s * 0.3, -s * 0.3, s * 0.08, 0, 7); ctx.fill(); ctx.lineWidth = s * 0.05; ctx.beginPath(); ctx.moveTo(-s * 0.2, s * 0.2); ctx.lineTo(-s * 0.08, s * 0.32); ctx.moveTo(s * 0.2, s * 0.2); ctx.lineTo(s * 0.08, s * 0.32); ctx.stroke(); }
    else if (id === 'round') { var g = ctx.createRadialGradient(-s * 0.08, -s * 0.1, 0, 0, 0, s * 0.3); g.addColorStop(0, '#8a8a8a'); g.addColorStop(1, ink); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, s * 0.3, 0, Math.PI * 2); ctx.fill(); }
    else if (id === 'chain') { ctx.beginPath(); ctx.arc(-s * 0.3, 0, s * 0.17, 0, 7); ctx.fill(); ctx.beginPath(); ctx.arc(s * 0.3, 0, s * 0.17, 0, 7); ctx.fill(); ctx.lineWidth = s * 0.05; for (var c = 0; c < 4; c++) { ctx.beginPath(); ctx.ellipse(-s * 0.15 + c * s * 0.1, 0, s * 0.06, s * 0.035 + (c % 2) * s * 0.02, 0, 0, 7); ctx.stroke(); } }
    else if (id === 'grape') { for (var gx = 0; gx < 3; gx++) for (var gy = 0; gy < 3; gy++) { ctx.beginPath(); ctx.arc((gx - 1) * s * 0.17 + (gy % 2) * s * 0.05, (gy - 1) * s * 0.16, s * 0.08, 0, 7); ctx.fill(); } ctx.lineWidth = s * 0.04; ctx.strokeRect(-s * 0.32, -s * 0.34, s * 0.64, s * 0.66); }
    ctx.restore();
  }
  var LABEL = { close: 'Close', open: 'Bear away', weather: 'Weather gauge', cross: 'Cross her bow', hold: 'Hold', board: 'Board her', round: 'Round shot', chain: 'Chain shot', grape: 'Grape' };
  /** the orders card grid: read by drawOrders AND by the scene's hit test (wing §11a: one copy of a layout) */
  var ORDERS = { pad: 16, top: 46, ch: 62, gap: 20 };
  /**
   * A card label: one line if it fits at 11 px, else two lines broken at the space nearest the middle (LOOKED AT
   * 2026-10-11: "Cross her bow" fitted to one line on a 54 px card came out at 8 px, unreadable).
   */
  function cardLabel(ctx, text, cx, yBottom, maxW, style) {
    ctx.font = (style ? style + ' ' : '') + '11px ' + FACE;
    if (ctx.measureText(text).width <= maxW || text.indexOf(' ') < 0) { fit(ctx, text, maxW, 11, style); ctx.fillText(text, cx, yBottom); return 1; }
    var best = -1, mid = text.length / 2;
    for (var i = 0; i < text.length; i++) if (text[i] === ' ' && (best < 0 || Math.abs(i - mid) < Math.abs(best - mid))) best = i;
    var a = text.slice(0, best), b = text.slice(best + 1), size = Math.min(fit(ctx, a, maxW, 11, style), fit(ctx, b, maxW, 11, style));
    ctx.font = (style ? style + ' ' : '') + size + 'px ' + FACE; ctx.fillText(a, cx, yBottom - size - 1); ctx.fillText(b, cx, yBottom);
    return 2;
  }
  /**
   * The orders: two rows of drawn cards (manoeuvre, shot), the legal ones in ink, the rest ghosted; the chosen card
   * framed in red; a line of plain words under them saying what the choice does.
   * info = {moves:[ids], legal:{id:true}, shots:[ids], shotLegal:{}, row:0|1, sel:[i,j], hover:[row,i]|null, help:'..', title}
   */
  function drawOrders(ctx, w, h, info) {
    ctx.clearRect(0, 0, w, h);
    plate(ctx, 2, 2, w - 4, h - 6, 'orders');
    var G = ORDERS;
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = INK; ctx.font = 'bold 15px ' + FACE; ctx.fillText(info.title || 'Orders', G.pad, 21);
    var rows = [info.moves, info.shots], legal = [info.legal, info.shotLegal], cw = (w - G.pad * 2) / 6, ch = G.ch;
    for (var rI = 0; rI < 2; rI++) {
      var ids = rows[rI], y0 = G.top + rI * (ch + G.gap), cwr = rI === 1 ? (w - G.pad * 2) / 3 : cw;
      ctx.fillStyle = '#6a4a2a'; ctx.font = 'italic 11px ' + FACE; ctx.textAlign = 'left'; ctx.fillText(rI === 0 ? 'Manoeuvre' : 'Load with', G.pad, y0 - 6);
      for (var i = 0; i < ids.length; i++) {
        var id = ids[i], x = G.pad + i * cwr, ok = !!legal[rI][id], sel = info.sel[rI] === i, focus = info.row === rI && sel;
        ctx.globalAlpha = ok ? 1 : 0.32;
        ctx.fillStyle = sel ? 'rgba(122,31,24,0.10)' : 'rgba(255,250,236,0.35)'; rr(ctx, x + 3, y0 + 2, cwr - 6, ch - 4, 4); ctx.fill();
        ctx.strokeStyle = sel ? RED : 'rgba(42,28,16,0.45)'; ctx.lineWidth = sel ? (focus ? 2.4 : 1.6) : 0.8; rr(ctx, x + 3, y0 + 2, cwr - 6, ch - 4, 4); ctx.stroke();
        ctx.font = (sel ? 'bold ' : '') + '11px ' + FACE;
        var two = ctx.measureText(LABEL[id] || id).width > cwr - 10;
        icon(ctx, id, x + cwr / 2, y0 + (two ? 20 : 24), two ? 24 : 30, sel ? RED : INK);
        ctx.fillStyle = sel ? RED : INK; ctx.textAlign = 'center'; cardLabel(ctx, LABEL[id] || id, x + cwr / 2, y0 + ch - 11, cwr - 10, sel ? 'bold' : '');
        ctx.globalAlpha = 1;
      }
    }
    ctx.fillStyle = INK; ctx.textAlign = 'left'; fit(ctx, info.help || '', w - 32, 12, 'italic'); ctx.fillText(info.help || '', 16, h - 20);
  }
  /**
   * The clinometer: a brass arc with the roll marked on it, the moment to fire shaded, and a note. The NEEDLE is a
   * separate sprite (the scene rotates it per frame); this draws the dial. info = {target: 'down'|'up', amp (rad), note}
   */
  function drawDial(ctx, w, h, info) {
    ctx.clearRect(0, 0, w, h);
    plate(ctx, 2, 2, w - 4, h - 6, 'dial');
    var cx = w / 2, cy = 30, R = h - 62, span = 1.0;   // the arc covers +-1 rad of needle swing (the roll, magnified)
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = INK; ctx.font = 'bold 14px ' + FACE; ctx.fillText('Fire on the roll', cx, 18);
    // the brass arc
    ctx.lineWidth = 12; ctx.strokeStyle = BRASS; ctx.beginPath(); ctx.arc(cx, cy, R, Math.PI / 2 - span, Math.PI / 2 + span); ctx.stroke();
    ctx.lineWidth = 2; ctx.strokeStyle = BRASS_L; ctx.beginPath(); ctx.arc(cx, cy, R - 5, Math.PI / 2 - span, Math.PI / 2 + span); ctx.stroke();
    // the moment: a red-gold sector at the end of the swing the shot wants
    var end = info.target === 'up' ? Math.PI / 2 - span : Math.PI / 2 + span, dir = info.target === 'up' ? 1 : -1;
    ctx.lineWidth = 12; ctx.strokeStyle = RED; ctx.beginPath(); ctx.arc(cx, cy, R, Math.min(end, end + dir * 0.28), Math.max(end, end + dir * 0.28)); ctx.stroke();
    // ticks
    ctx.strokeStyle = INK; ctx.lineWidth = 1;
    for (var t = -5; t <= 5; t++) { var a = Math.PI / 2 + t * span / 5; ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * (R + 7), cy + Math.sin(a) * (R + 7)); ctx.lineTo(cx + Math.cos(a) * (R + (t % 5 === 0 ? 14 : 11)), cy + Math.sin(a) * (R + (t % 5 === 0 ? 14 : 11))); ctx.stroke(); }
    // LOOKED AT 2026-10-11: placed beyond the arc's ends, both words were cut by the plate's edge; placed under the
    // ends, the ticks and the red sector ran through them. They sit ABOVE each end, where the arc never goes.
    ctx.font = 'italic 11px ' + FACE; ctx.fillStyle = '#6a4a2a';
    var ly = cy + Math.sin(Math.PI / 2 + span) * R - 18;
    ctx.textAlign = 'left'; ctx.fillText('down-roll', 16, ly);
    ctx.textAlign = 'right'; ctx.fillText('up-roll', w - 16, ly);
    ctx.textAlign = 'center';
    // the pivot
    ctx.fillStyle = BRASS; ctx.beginPath(); ctx.arc(cx, cy, 7, 0, 7); ctx.fill(); ctx.strokeStyle = INK; ctx.stroke();
    ctx.fillStyle = INK; ctx.font = 'italic 12px ' + FACE; fit(ctx, info.note || '', w - 30, 12, 'italic'); ctx.fillText(info.note || '', cx, h - 18);
  }
  /** the needle sprite's bitmap: a brass pendulum pointing DOWN from its pivot at (w/2, 0) */
  function drawNeedle(ctx, w, h) {
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = INK; ctx.beginPath(); ctx.moveTo(w / 2 - 2.5, 0); ctx.lineTo(w / 2 + 2.5, 0); ctx.lineTo(w / 2 + 1, h - 12); ctx.lineTo(w / 2 - 1, h - 12); ctx.closePath(); ctx.fill();
    ctx.fillStyle = BRASS; ctx.beginPath(); ctx.moveTo(w / 2, h); ctx.lineTo(w / 2 - 6, h - 14); ctx.lineTo(w / 2 + 6, h - 14); ctx.closePath(); ctx.fill(); ctx.strokeStyle = INK; ctx.lineWidth = 1; ctx.stroke();
  }
  /** a banner of words across the sea ("Her mizzen topmast is down!") */
  function drawNote(ctx, w, h, text, tone) {
    ctx.clearRect(0, 0, w, h);
    ctx.font = 'bold 16px ' + FACE; var tw = Math.min(w - 20, ctx.measureText(text).width + 60), x = (w - tw) / 2;
    plate(ctx, x, 2, tw, h - 6, 'note' + text.length);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = tone === 'bad' ? RED : INK; ctx.fillText(fitText(ctx, text, tw - 40, 16, 'bold', 11), w / 2, h / 2 - 1);
  }
  /** the opening: the fight's title on a hanging chart */
  function drawTitle(ctx, w, h, title, sub) {
    ctx.clearRect(0, 0, w, h);
    var tw = Math.min(w - 80, 560), x = (w - tw) / 2;
    plate(ctx, x, 6, tw, h - 12, 'title');
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = INK; ctx.fillText(fitText(ctx, title, tw - 60, 30, 'bold', 16), w / 2, 42);
    ctx.fillStyle = '#8a6a3a'; ctx.fillRect(w / 2 - 120, 62, 240, 1);
    ctx.fillStyle = '#6a4a2a'; ctx.fillText(fitText(ctx, sub, tw - 60, 15, 'italic', 11), w / 2, 80);
  }
  /**
   * The log: the verdict and the account of the fight, written up as a ship's log entry.
   * info = {verdict, line, turns, me:{name,cls,hull,rig,crew}, foe:{...}, log:[strings], good: bool}
   */
  function drawLog(ctx, w, h, info) {
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = 'rgba(10,14,18,0.5)'; ctx.fillRect(0, 0, w, h);
    // the plate is the stage's size whatever the screen (a wide project gets a dimmed margin, not a stretched log)
    var pw = Math.min(w - 140, 676), ph = Math.min(h - 80, 544), x = Math.round((w - pw) / 2), y = Math.round((h - ph) / 2);
    plate(ctx, x, y, pw, ph, 'log');
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = info.good ? '#1f3a66' : RED; ctx.fillText(fitText(ctx, info.verdict, pw - 60, 34, 'bold', 20), w / 2, y + 44);
    ctx.fillStyle = '#6a4a2a'; ctx.fillText(fitText(ctx, info.line, pw - 60, 15, 'italic', 11), w / 2, y + 76);
    ctx.fillStyle = '#8a6a3a'; ctx.fillRect(w / 2 - 160, y + 94, 320, 1);
    var cw = (pw - 60) / 2;
    [info.me, info.foe].forEach(function (s, k) {
      var cx = x + 30 + k * cw, cy = y + 116;
      ctx.textAlign = 'left'; ctx.fillStyle = k ? RED : '#1f3a66'; ctx.fillText(fitText(ctx, s.name, cw - 20, 16, 'bold', 12), cx, cy);
      ctx.fillStyle = '#6a4a2a'; ctx.font = 'italic 12px ' + FACE; ctx.fillText(s.cls, cx, cy + 18);
      gauge(ctx, cx, cy + 32, cw - 24, 'Hull', s.hull, '#8a5a2e', '#5a3818');
      gauge(ctx, cx, cy + 50, cw - 24, 'Rig', s.rig, '#e8dcc0', '#b8a888');
      gauge(ctx, cx, cy + 68, cw - 24, 'Crew', s.crew, '#a8402e', '#6a2418');
    });
    ctx.textAlign = 'left'; ctx.fillStyle = INK; ctx.font = '13px ' + FACE;
    var ly = y + 244, lines = info.log || [];   // LOOKED AT: at +222 the heading sat on the Crew gauges
    ctx.fillStyle = '#6a4a2a'; ctx.font = 'italic 12px ' + FACE; ctx.fillText('From the log', x + 30, ly - 18);
    ctx.fillStyle = INK;
    // the log's lines keep to the left half when the enemy's portrait fills the right (a long name must not run into her)
    var lineW = info.portrait ? pw / 2 - 40 : pw - 60;
    for (var i = Math.max(0, lines.length - 9); i < lines.length && ly < y + ph - 40; i++) { ctx.fillText(fitText(ctx, lines[i], lineW, 13, '', 10), x + 30, ly); ly += 19; }
    // the enemy as she was at the end, drawn into the log's right half like an engraving in a journal, over inked swell
    // (LOOKED AT 2026-10-11: the right half of the log was bare parchment)
    var pt = info.portrait;
    if (pt && pt.canvas && pt.waterY > 0) {
      var ax = x + pw / 2 + 10, aw = pw / 2 - 40, ay = y + 236, ah = ph - 236 - 60, src = pt.canvas;
      var sw = src.width, sh = pt.waterY, k = Math.min(aw / sw, (ah - 26) / sh), dw = sw * k, dh = sh * k, dx = ax + (aw - dw) / 2, dy = ay + (ah - 26 - dh);
      ctx.save(); ctx.globalAlpha = 0.92; ctx.drawImage(src, 0, 0, sw, sh, dx, dy, dw, dh); ctx.restore();
      ctx.strokeStyle = 'rgba(42,28,16,0.75)'; ctx.lineWidth = 1;
      for (var wv = 0; wv < 3; wv++) { var wy = dy + dh + 3 + wv * 6; ctx.beginPath(); for (var wx = 0; wx <= aw; wx += 4) { var yy = wy + Math.sin((wx + wv * 9) / 9) * 1.6; if (wx === 0) ctx.moveTo(ax + wx, yy); else ctx.lineTo(ax + wx, yy); } ctx.stroke(); }
      ctx.textAlign = 'center'; ctx.fillStyle = '#6a4a2a'; ctx.fillText(fitText(ctx, pt.caption || '', aw, 12, 'italic', 10), ax + aw / 2, ay + ah + 6);
    }
    ctx.textAlign = 'center'; ctx.fillStyle = '#6a4a2a'; ctx.font = 'italic 12px ' + FACE; ctx.fillText(info.turns + ' turns  ·  OK to close the log', w / 2, y + ph - 20);
  }

  return {
    VERSION: '1.0.0', FACE: FACE, SKIES: SKIES, SKY_IDS: SKY_IDS, HORIZON: HORIZON, LABEL: LABEL, ORDERS: ORDERS, hash: hash,
    drawBackdrop: drawBackdrop, drawGlints: drawGlints, drawWash: drawWash, drawSmoke: drawSmoke, drawSplash: drawSplash, drawFlash: drawFlash,
    drawSplinter: drawSplinter, drawFlame: drawFlame, drawShipCard: drawShipCard, drawCompass: drawCompass, drawOrders: drawOrders,
    drawDial: drawDial, drawNeedle: drawNeedle, drawNote: drawNote, drawTitle: drawTitle, drawLog: drawLog, plate: plate, icon: icon, fitText: fitText,
  };
})();
if (typeof module === 'object' && module.exports) module.exports = BroadsideSea;
