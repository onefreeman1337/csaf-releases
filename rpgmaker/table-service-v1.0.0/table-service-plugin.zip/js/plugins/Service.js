//=============================================================================
// Service.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Table Service - a serving rush played on your own map:
 * seated customers, order tickets, the pass, patience candles, tips, a ledger.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 * @base ServiceCore
 * @base ServiceDraw
 * @orderAfter ServiceDraw
 *
 * @param houseMenu
 * @text House menu
 * @type note
 * @desc Used when a shift names no items and no item has <Menu>. One dish a line: Name: price. The name decides how it is drawn.
 * @default "Roast Fowl: 60\nPumpkin Soup: 30\nHoney Loaf: 20\nMushroom Stew: 45\nGrilled Trout: 55\nApple Pie: 35\nPale Ale: 15\nMulled Wine: 25\nHerb Salad: 25\nBoar Steak: 70\nCheese Board: 40\nBerry Tart: 35\nSpiced Tea: 12\nRice and Egg: 30\nSausage Plate: 45\nMana Tonic: 50"
 *
 * @param customerSheets
 * @text Customer sheets
 * @type text
 * @desc Leave blank to draw every customer fresh. Or list character sheets with an index, e.g. People1:0, People1:3, People2:5
 * @default
 *
 * @param allowMenu
 * @text Allow menu in a shift
 * @type boolean
 * @desc Can the player open the menu while a shift runs? (The shift pauses while it is open.)
 * @default false
 *
 * @param hudCorner
 * @text Tray corner
 * @type select
 * @option bottom-left
 * @option bottom-right
 * @option top-left
 * @option top-right
 * @desc Where the server's tray (the two hands, the tips and the clock) sits on screen.
 * @default bottom-left
 *
 * @param seSeat
 * @text Sound: seated
 * @type file
 * @dir audio/se
 * @desc Played when a party sits down. Blank = silent.
 * @default
 *
 * @param seOrder
 * @text Sound: order taken
 * @type file
 * @dir audio/se
 * @default
 *
 * @param seReady
 * @text Sound: dish ready
 * @type file
 * @dir audio/se
 * @default
 *
 * @param seServe
 * @text Sound: served
 * @type file
 * @dir audio/se
 * @default
 *
 * @param seWalk
 * @text Sound: walked out
 * @type file
 * @dir audio/se
 * @default
 *
 * @command start
 * @text Start Shift
 * @desc Opens the floor. Customers take the seats marked <Table> on this map; the kitchen's dishes appear at the <Pass>.
 *
 * @arg difficulty
 * @text Difficulty
 * @type select
 * @option easy
 * @option normal
 * @option busy
 * @default normal
 *
 * @arg title
 * @text Title
 * @type text
 * @desc Shown on the opening sign and the ledger. Blank = the map's display name.
 * @default
 *
 * @arg menu
 * @text Menu (item ids)
 * @type text
 * @desc Item ids to serve, e.g. 12, 13, 15. Blank = every item with <Menu>, or the House menu if none has it.
 * @default
 *
 * @arg pay
 * @text Pay the party
 * @type select
 * @option nothing
 * @option tips
 * @option everything
 * @desc What goes into the party's gold when the ledger closes.
 * @default tips
 *
 * @arg takingsVariableId
 * @text Takings -> variable
 * @type variable
 * @default 0
 *
 * @arg tipsVariableId
 * @text Tips -> variable
 * @type variable
 * @default 0
 *
 * @arg starsVariableId
 * @text Stars (0-3) -> variable
 * @type variable
 * @default 0
 *
 * @arg switchId
 * @text Switch ON when done
 * @type switch
 * @default 0
 *
 * @arg commonEventId
 * @text Common event when done
 * @type common_event
 * @default 0
 *
 * @arg seed
 * @text Seed
 * @type text
 * @desc Blank = a new night every time. A number replays the same night.
 * @default
 *
 * @command end
 * @text End Shift Now
 * @desc Closes the floor at once and opens the ledger (parties still waiting are not served).
 *
 * @help
 * TABLE SERVICE - a customer-serving rush on the map you already built.
 *
 * SETUP (three steps)
 *   1. On your dining map, place an event where each customer should sit
 *      (on the chair) and write <Table> in its Note box. <Table: 4> gives
 *      it table number 4; without a number, tables are numbered in event
 *      order. Set the event's direction to face the table: the customer
 *      faces that way, and their plate and candle go on that tile.
 *   2. Place one event on the kitchen counter and write <Pass> in its Note.
 *      Finished dishes wait there.
 *   3. Call the plugin command Start Shift (from a waiter, a door, a sign).
 *
 * PLAYING
 *   Walk up to a customer and press OK (or click them):
 *     - a ringing bell means they want to order: OK takes the order;
 *     - a ticket means they are waiting for food: bring what it lists.
 *   Walk up to the pass and press OK to pick up the next dish (two hands).
 *   With both hands full, OK at the pass swaps; with nothing ready, it puts
 *   a carried dish back. Every customer has a candle: it burns down while
 *   they wait. Serve them before it goes out and they tip; the more candle
 *   left, the bigger the tip. When the last party leaves, the ledger opens.
 *
 * THE MENU
 *   Blank menu: every item with <Menu> in its note is served; if none has
 *   it, the House menu parameter is. Dishes are DRAWN FROM THEIR NAMES
 *   (Pumpkin Soup is a bowl of orange soup, Pale Ale a tankard of foam).
 *   Item notetags:
 *     <Menu>              serve this item when the menu is left blank
 *     <Price: 40>         what it costs a customer (default: the item's price)
 *     <Cook: 5>           seconds in the kitchen (default: drinks 2.5,
 *                         bowls 3.7, plates 5.3)
 *     <Dish: soup>        how to draw it, if the name does not say: bottle,
 *                         mug, cup, glass, soup, stew, pie, cake, bread,
 *                         fish, roast, sausage, steak, noodles, rice, egg,
 *                         cheese, salad, fruit, plate
 *     <Dish Colour: blue> red, orange, amber, yellow, green, blue, purple,
 *                         pink, brown, cream, gold, dark
 *
 * DIFFICULTY (measured over 60 simulated nights each; see the Readme)
 *   easy   8 parties, patient.     normal 12 parties.     busy 15 parties.
 *   A floor with long walks between the pass and the tables is harder:
 *   put the pass near the tables for a gentler night.
 *
 * SCRIPT
 *   Service.isOpen()      true while a shift runs (or its ledger is open)
 *   Service.lastResult()  the last night: {served, parties, walkouts,
 *                         takings, tips, stars, ...} or null
 *
 * The shift is saved with the game and resumes where it was. It pauses
 * while a message shows, while another event runs, while the menu is open,
 * and whenever the player is on a different map.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var Service = (function () {
  'use strict';

  var NAME = 'Service';
  var RAW = PluginManager.parameters(NAME);
  var CORE = null, DRAW = null;
  /** ⛔ Sibling files are resolved at FIRST USE, never at load time: the buyer chooses the load order (wing §8 trap 2). */
  function deps() {
    if (!CORE) { CORE = window.ServiceCore; DRAW = window.ServiceDraw; }
    if (!CORE || !DRAW) throw new Error('Table Service needs ServiceCore.js and ServiceDraw.js installed and ON in the Plugin Manager.');
    return true;
  }
  function parseNote(v) { try { var s = JSON.parse(v); return typeof s === 'string' ? s : String(v || ''); } catch (e) { return String(v || ''); } }
  /** House menu lines "Name: price" -> entries. Blank or malformed lines are skipped. */
  function parseHouse(text) {
    var out = [], lines = String(text || '').split(/\r?\n/);
    for (var i = 0; i < lines.length; i++) { var m = /^\s*(.+?)\s*:\s*(\d+)\s*$/.exec(lines[i]); if (m && m[1]) out.push({ name: m[1], price: Number(m[2]) }); }
    return out;
  }
  var DEFAULT_HOUSE = 'Roast Fowl: 60\nPumpkin Soup: 30\nHoney Loaf: 20\nMushroom Stew: 45\nGrilled Trout: 55\nApple Pie: 35\nPale Ale: 15\nMulled Wine: 25\nHerb Salad: 25\nBoar Steak: 70\nCheese Board: 40\nBerry Tart: 35\nSpiced Tea: 12\nRice and Egg: 30\nSausage Plate: 45\nMana Tonic: 50';
  var P = {
    house: parseHouse(RAW.houseMenu === undefined ? DEFAULT_HOUSE : parseNote(RAW.houseMenu)),
    sheets: String(RAW.customerSheets || '').split(',').map(function (s) { var m = /^\s*([^:\s][^:]*?)\s*:\s*(\d+)\s*$/.exec(s); return m ? { name: m[1], index: Number(m[2]) } : null; }).filter(Boolean),
    allowMenu: String(RAW.allowMenu) === 'true',
    hudCorner: ['bottom-left', 'bottom-right', 'top-left', 'top-right'].indexOf(String(RAW.hudCorner)) >= 0 ? String(RAW.hudCorner) : 'bottom-left',
    se: { seat: String(RAW.seSeat || ''), order: String(RAW.seOrder || ''), ready: String(RAW.seReady || ''), serve: String(RAW.seServe || ''), walk: String(RAW.seWalk || '') },
  };
  if (!P.house.length) P.house = parseHouse(DEFAULT_HOUSE);

  /** The save record: versioned, created on first use (so a save made before install loads cleanly). */
  function rec() {
    var sys = $gameSystem; if (!sys) return null;
    if (!sys._csafService || sys._csafService.v !== 1) sys._csafService = { v: 1, count: 0, shift: null, req: null, ledger: null, last: null };
    return sys._csafService;
  }
  /** Runtime-only state (never saved): effects waiting for the floor layer, the banner, the ledger's age. */
  var RT = { fx: [], banner: 0, ledgerAge: 0, frame: 0 };

  function num(v) { var n = Number(v); return isFinite(n) ? n : 0; }
  function playSe(name) { if (name) AudioManager.playSe({ name: name, volume: 90, pitch: 100, pan: 0 }); }
  function tagOf(ev) {
    var data = ev.event(), meta = (data && data.meta) || {}, t = { table: null, pass: false };
    if (meta.Table !== undefined) t.table = meta.Table === true ? 0 : num(meta.Table);
    if (meta.Pass !== undefined) t.pass = true;
    // a comment on the first page counts too, for buyers who tag with comments
    var page = data && data.pages && data.pages[0], list = (page && page.list) || [];
    for (var i = 0; i < list.length; i++) {
      if (list[i].code !== 108 && list[i].code !== 408) continue;
      var s = String(list[i].parameters[0] || ''), m = /<Table(?:\s*:\s*(\d+))?>/i.exec(s);
      if (m && t.table === null) t.table = m[1] ? Number(m[1]) : 0;
      if (/<Pass>/i.test(s)) t.pass = true;
    }
    return t;
  }
  /** This map's tables (seat id -> event id) and its pass event. Explicit numbers first; the rest numbered after them. */
  function scanMap() {
    var tables = {}, pass = 0, auto = [], used = {};
    $gameMap.events().forEach(function (ev) {
      var t = tagOf(ev);
      if (t.pass && !pass) pass = ev.eventId();
      if (t.table === null) return;
      if (t.table > 0 && !used[t.table]) { tables[t.table] = ev.eventId(); used[t.table] = true; } else auto.push(ev.eventId());
    });
    var n = 1; auto.sort(function (a, b) { return a - b; }).forEach(function (id) { while (used[n]) n++; tables[n] = id; used[n] = true; });
    return { tables: tables, pass: pass };
  }
  /** The night's menu: named item ids, else items tagged <Menu>, else the House menu. */
  function buildMenu(arg) {
    deps();
    var ids = String(arg || '').split(/[\s,]+/).map(Number).filter(function (n) { return n > 0 && $dataItems[n]; }), out = [];
    if (!ids.length) for (var i = 1; i < $dataItems.length; i++) if ($dataItems[i] && $dataItems[i].meta && $dataItems[i].meta.Menu) ids.push(i);
    ids.forEach(function (id) {
      var it = $dataItems[id], meta = it.meta || {}, form = typeof meta.Dish === 'string' ? meta.Dish.trim().toLowerCase() : '', colour = typeof meta['Dish Colour'] === 'string' ? meta['Dish Colour'].trim().toLowerCase() : '';
      var look = DRAW.dishLook({ name: it.name, form: form, colour: colour });
      out.push({ id: id, name: it.name, price: num(meta.Price) > 0 ? num(meta.Price) : (it.price > 0 ? it.price : 10), cook: num(meta.Cook) > 0 ? Math.round(num(meta.Cook) * 60) : DRAW.cookFrames(look.form), form: form, colour: colour });
    });
    if (!out.length) P.house.forEach(function (h, k) { out.push({ id: k + 1, name: h.name, price: h.price > 0 ? h.price : 10, cook: DRAW.cookFrames(DRAW.dishLook(h.name).form), form: '', colour: '', house: true }); });
    return out;
  }
  function menuEntry(req, id) { for (var i = 0; i < req.menu.length; i++) if (req.menu[i].id === id) return req.menu[i]; return null; }
  /** A dish as ServiceDraw wants it: its name plus any form/colour its notetags forced. */
  function dishOf(req, id) { var m = menuEntry(req, id); return m ? { name: m.name, form: m.form, colour: m.colour } : { name: '?' }; }

  /**
   * Start a shift on the current map. Returns false (and says why in the console) when the map has no <Table> event or
   * the night would have no parties.
   */
  function start(args, mapId, eventId) {
    deps();
    var r = rec(); if (r.shift || r.ledger) { console.warn('Table Service: a shift is already open.'); return false; }
    var sc = scanMap(), seatIds = Object.keys(sc.tables).map(Number);
    if (!seatIds.length) { console.warn('Table Service: no event on this map has <Table> in its note.'); return false; }
    var menu = buildMenu(args.menu), diff = Object.prototype.hasOwnProperty.call(CORE.DIFFS, args.difficulty) ? args.difficulty : 'normal';
    var seed = String(args.seed || '').trim() !== '' && isFinite(Number(args.seed)) ? (Number(args.seed) >>> 0) : (CORE.hashString('m' + mapId + 'e' + eventId + 'n' + r.count) >>> 0);
    var plan = CORE.plan({ seed: seed, difficulty: diff, seats: seatIds.map(function (id) { return { id: id }; }), menu: menu.map(function (m) { return { id: m.id, price: m.price, cook: m.cook }; }) });
    if (!plan.parties.length) { console.warn('Table Service: the night has no parties (no menu?).'); return false; }
    r.req = { mapId: mapId, eventId: eventId, title: String(args.title || '').trim() || ($gameMap.displayName() || 'The evening shift'), difficulty: diff, seed: seed,
      pay: ['nothing', 'tips', 'everything'].indexOf(args.pay) >= 0 ? args.pay : 'tips', vars: { takings: num(args.takingsVariableId), tips: num(args.tipsVariableId), stars: num(args.starsVariableId) },
      switchId: num(args.switchId), commonEventId: num(args.commonEventId), tables: sc.tables, pass: sc.pass, menu: menu };
    r.shift = CORE.newShift(plan); r.ledger = null;
    RT.fx.length = 0; RT.banner = 150; RT.ledgerAge = 0;
    return true;
  }
  function end() { var r = rec(); if (r && r.shift && !r.shift.over) { r.shift.over = true; openLedger(); } }

  function isOpen() { var r = rec(); return !!(r && (r.shift || r.ledger)); }
  function isLedgerOpen() { var r = rec(); return !!(r && r.ledger); }
  function onFloor() { var r = rec(); return !!(r && r.shift && !r.ledger && $gameMap && $gameMap.mapId() === r.req.mapId); }

  /** One frame of the shift. Paused off the floor, while a message shows, while another event runs, while the book is open. */
  function update() {
    var r = rec(); if (!r) return;
    RT.frame++;
    if (r.ledger) { RT.ledgerAge++; if (RT.ledgerAge > 40 && (Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered())) closeLedger(); return; }
    var s = r.shift; if (!s) return;
    if (s.over) { openLedger(); return; }
    if ($gameMap.mapId() !== r.req.mapId || $gameMap.isEventRunning() || $gameMessage.isBusy()) return;
    if (RT.banner > 0) RT.banner--;
    var n = CORE.tick(s, 1);
    for (var i = 0; i < n; i++) onEvent(r, s.events[i]);
    if (s.over) openLedger();
  }
  function onEvent(r, e) {
    if (e.type === 'seated') { RT.fx.push({ type: 'seated', party: e.party, seat: e.seat }); playSe(P.se.seat); }
    else if (e.type === 'ready') { RT.fx.push({ type: 'ready', party: e.party }); playSe(P.se.ready); }
    else if (e.type === 'walked') { RT.fx.push({ type: 'walked', party: e.party, seat: e.seat }); if (e.seat) say(e.seat, 'Walked out', 'bad'); playSe(P.se.walk); }
    else if (e.type === 'paid') { RT.fx.push({ type: 'paid', party: e.party, seat: e.seat }); say(e.seat, '+' + e.tip + ' ' + TextManager.currencyUnit + ' tip', 'coin'); }
  }
  /** A floating tag over a seat (or the pass, seat = 'pass'). */
  function say(seat, text, kind) { RT.fx.push({ type: 'tag', seat: seat, text: text, kind: kind || '' }); }

  function seatOfEvent(r, eventId) { var t = r.req.tables; for (var k in t) if (t[k] === eventId) return Number(k); return 0; }

  /**
   * The player acts on whatever is at (x, y): a seated party (take the order, bring their dishes) or the pass (pick up,
   * swap, put back). Returns true when it handled the press (so the event's own page does not also run).
   */
  function serveAt(x, y) {
    if (!onFloor() || $gameMap.isEventRunning()) return false;
    deps();
    var r = rec(), s = r.shift, evs = $gameMap.eventsXy(x, y);
    for (var i = 0; i < evs.length; i++) {
      var id = evs[i].eventId(), seat = seatOfEvent(r, id);
      if (seat) { var pid = s.seats[seat]; if (!pid) return false; return actAtTable(r, s, seat, CORE.party(s, pid)); }
      if (id === r.req.pass) return actAtPass(r, s);
    }
    return false;
  }
  function actAtTable(r, s, seat, q) {
    if (!q) return false;
    if (q.phase === 'waiting') { CORE.takeOrder(s, q.id); RT.fx.push({ type: 'ordered', party: q.id, seat: seat }); say(seat, 'Order taken', 'good'); playSe(P.se.order); return true; }
    if (q.phase === 'ordered') {
      var n = CORE.deliver(s, q.id);
      if (n) { RT.fx.push({ type: 'delivered', party: q.id, seat: seat }); say(seat, q.phase === 'eating' ? 'Served' : 'One more to come', 'good'); playSe(P.se.serve); return true; }
      var atPass = false; for (var k = 0; k < s.pass.length; k++) if (s.pass[k].party === q.id) atPass = true;
      say(seat, s.hands.length ? 'Not their order' : (atPass ? 'Ready at the pass' : 'Still in the kitchen'), s.hands.length ? 'bad' : '');
      return true;
    }
    if (q.phase === 'eating') { say(seat, 'Enjoying it', ''); return true; }
    return false;
  }
  function actAtPass(r, s) {
    if (s.pass.length) {
      if (s.hands.length < CORE.HANDS) { var d = s.pass[0]; CORE.pickUp(s, 0); say('pass', dishOf(r.req, d.item).name + ', table ' + tableOfParty(s, d.party), 'good'); }
      else { CORE.putDown(s, 0); var d2 = s.pass[0]; CORE.pickUp(s, 0); say('pass', 'Swapped for table ' + tableOfParty(s, d2.party), ''); }
    } else if (s.hands.length) { CORE.putDown(s, 0); say('pass', 'Put back on the pass', ''); }
    else say('pass', 'Nothing ready yet', '');
    RT.fx.push({ type: 'pass' });
    return true;
  }
  function tableOfParty(s, pid) { var q = CORE.party(s, pid); return q ? q.seat : '?'; }

  /** The night is over: score it and open the book. */
  function openLedger() {
    var r = rec(), s = r.shift; if (!s || r.ledger) return;
    var sc = CORE.score(s), counts = {}, top = null, marks = [];
    for (var i = 0; i < s.parties.length; i++) {
      var q = s.parties[i]; marks.push(q.phase === 'gone' || q.phase === 'eating' ? 1 : 0);
      if (q.phase === 'gone' || q.phase === 'eating') for (var k = 0; k < q.order.length; k++) { var id = q.order[k]; counts[id] = (counts[id] || 0) + 1; if (!top || counts[id] > top.count) top = { id: id, count: counts[id] }; }
    }
    var dl = { easy: 'Easy', normal: 'Normal', busy: 'Busy' }[r.req.difficulty];
    r.ledger = Object.assign({ title: r.req.title, sub: dl + ' night · ' + s.parties.length + ' parties · ' + Object.keys(r.req.tables).length + ' tables', currency: TextManager.currencyUnit, foot: 'Press OK to close the book.', marks: marks,
      top: top ? { dish: dishOf(r.req, top.id), name: dishOf(r.req, top.id).name, count: top.count } : null }, sc);
    RT.ledgerAge = 0;
  }
  /** Close the book: pay, set the variables and switch, run the common event. */
  function closeLedger() {
    var r = rec(), L = r.ledger; if (!L) return;
    var q = r.req;
    if (q.vars.takings > 0) $gameVariables.setValue(q.vars.takings, L.takings);
    if (q.vars.tips > 0) $gameVariables.setValue(q.vars.tips, L.tips);
    if (q.vars.stars > 0) $gameVariables.setValue(q.vars.stars, L.stars);
    if (q.pay === 'tips') $gameParty.gainGold(L.tips); else if (q.pay === 'everything') $gameParty.gainGold(L.tips + L.takings);
    if (q.switchId > 0) $gameSwitches.setValue(q.switchId, true);
    if (q.commonEventId > 0) $gameTemp.reserveCommonEvent(q.commonEventId);
    r.last = { served: L.served, parties: L.parties, walkouts: L.walkouts, covers: L.covers, takings: L.takings, tips: L.tips, stars: L.stars, grade: L.grade, bestStreak: L.bestStreak, difficulty: q.difficulty, seed: q.seed };
    r.ledger = null; r.shift = null; r.count++; RT.fx.length = 0;
    // ⛔ Found by the in-engine suite: the key that closes the book is still "triggered" this frame, so Escape went on to
    // open the main menu and OK would have started whatever event the player faces. The press belongs to the book.
    Input.clear(); TouchInput.clear();
  }

  // -------------------------------------------------------------------------------------------------------------------
  // The floor: everything drawn over the map while a shift is open
  // -------------------------------------------------------------------------------------------------------------------

  function tileW() { return $gameMap.tileWidth(); }
  function tileH() { return $gameMap.tileHeight(); }
  /** Screen centre-bottom of an event's tile (not the character's 6 px lift). */
  function footOf(ev, out) { out.x = ev.screenX(); out.y = ev.screenY() + ev.shiftY() + ev.jumpHeight(); return out; }
  var DX = { 2: 0, 4: -1, 6: 1, 8: 0 }, DY = { 2: 1, 4: 0, 6: 0, 8: -1 };

  function ServiceFloor() { this.initialize.apply(this, arguments); }
  ServiceFloor.prototype = Object.create(Sprite.prototype);
  ServiceFloor.prototype.constructor = ServiceFloor;
  /** Built from the saved state, so a floor rebuilt after the menu or a load shows exactly what was there. */
  ServiceFloor.prototype.initialize = function (spriteset) {
    Sprite.prototype.initialize.call(this);
    deps();
    this._ss = spriteset; this._tm = spriteset._tilemap; this._pt = { x: 0, y: 0 };
    var tw = tileW(), th = tileH();
    this._shared = { bell: bmp(28, 26, function (c) { DRAW.drawBell(c, 28, 26); }), wax: bmp(9, 30, function (c) { DRAW.drawWax(c, 9, 30); }),
      flame: bmp(12, 18, function (c) { DRAW.drawFlame(c, 12, 18, false); }), gutter: bmp(12, 18, function (c) { DRAW.drawFlame(c, 12, 18, true); }),
      holder: bmp(20, 9, function (c) { DRAW.drawHolder(c, 20, 9); }), puff: bmp(24, 30, function (c) { DRAW.drawPuff(c, 24, 30); }) };
    this._seats = {}; this._seatList = []; var r = rec(), self = this;
    Object.keys(r.req.tables).forEach(function (k) { var S = self.makeSeat(Number(k), r.req.tables[k], tw, th); self._seats[k] = S; self._seatList.push(S); });
    this._pass = new Sprite(new Bitmap(230, 76)); this._pass.anchor.set(0.5, 1); this._pass.z = 3; this._passDirty = true; this._tm.addChild(this._pass);
    this._tags = []; for (var i = 0; i < 8; i++) { var t = new Sprite(new Bitmap(170, 28)); t.anchor.set(0.5, 1); t.z = 8; t.visible = false; t._life = 0; t._seat = 0; this._tm.addChild(t); this._tags.push(t); }
    this._over = new Sprite(); spriteset.addChild(this._over);
    this._hud = new Sprite(new Bitmap(300, 68)); this._hudDirty = true; this._hudTick = -1; this._over.addChild(this._hud);
    this._hud.x = /right/.test(P.hudCorner) ? Graphics.width - 300 - 10 : 10; this._hud.y = /bottom/.test(P.hudCorner) ? Graphics.height - 68 - 8 : 8;
    this._banner = new Sprite(new Bitmap(440, 96)); this._banner.anchor.set(0.5, 0); this._banner.x = Graphics.width / 2; this._banner.visible = false; this._bannerDrawn = false; this._over.addChild(this._banner);
    this._book = new Sprite(); this._book.visible = false; this._bookDrawn = false; this._over.addChild(this._book);
    this.syncAll(true);
  };
  function bmp(w, h, fn) { var b = new Bitmap(w, h); fn(b.context); b._baseTexture.update(); return b; }
  ServiceFloor.prototype.makeSeat = function (seatId, eventId, tw, th) {
    var S = { id: seatId, eventId: eventId, party: 0, phase: '', fade: 0, gone: 0 };
    S.diner = new Sprite(new Bitmap(tw, th)); S.diner.anchor.set(0.5, 1); S.diner.z = 3;
    S.top = new Sprite(new Bitmap(Math.round(tw * 1.5), Math.round(th * 1.1))); S.top.anchor.set(0.5, 0.5); S.top.z = 3;
    S.holder = new Sprite(this._shared.holder); S.holder.anchor.set(0.5, 0.5); S.holder.z = 3;
    S.wax = new Sprite(this._shared.wax); S.wax.anchor.set(0.5, 1); S.wax.z = 3; S.waxH = -1;
    S.flame = new Sprite(this._shared.flame); S.flame.anchor.set(0.5, 1); S.flame.z = 3;
    S.bell = new Sprite(this._shared.bell); S.bell.anchor.set(0.5, 1); S.bell.z = 7;
    S.ticket = new Sprite(new Bitmap(DRAW.TICKET_W, DRAW.ticketHeight(2))); S.ticket.anchor.set(0.5, 1); S.ticket.z = 7; S.ticketParty = 0; S.ticketGot = -1;
    S.puff = new Sprite(this._shared.puff); S.puff.anchor.set(0.5, 1); S.puff.z = 7; S.puff.visible = false; S.puffLife = 0;
    [S.diner, S.top, S.holder, S.wax, S.flame, S.bell, S.ticket, S.puff].forEach(function (sp) { sp.visible = false; this._tm.addChild(sp); }, this);
    return S;
  };
  /** Redraw the seated party's figure (generated, or a frame from the buyer's sheet). */
  ServiceFloor.prototype.drawDiner = function (S, ev, q) {
    var r = rec(), b = S.diner.bitmap, tw = b.width, th = b.height, dir = ev.direction();
    b.clear();
    if (P.sheets.length) {
      var pick = P.sheets[CORE.hashString('s' + r.req.seed + 'p' + q.id) % P.sheets.length], src = ImageManager.loadCharacter(pick.name);
      var draw = function () { var big = ImageManager.isBigCharacter(pick.name), pw = src.width / (big ? 3 : 12), ph = src.height / (big ? 4 : 8), bx = big ? 0 : (pick.index % 4) * 3 * pw, by = big ? 0 : Math.floor(pick.index / 4) * 4 * ph;
        b.clear(); b.blt(src, bx + pw, by + ((dir - 2) / 2) * ph, pw, ph, Math.round((tw - pw) / 2), th - ph); };
      if (src.isReady()) draw(); else src.addLoadListener(draw);
    } else { DRAW.drawFigureOutlined(b.context, 0, 0, tw, DRAW.lookFor(r.req.seed * 31 + q.id), dir, 'seat'); b._baseTexture.update(); }
  };
  /** The table-top: this party's dishes (hot while eating starts, then emptied), drawn once per change. */
  ServiceFloor.prototype.drawTop = function (S, q, eaten) {
    var r = rec(), b = S.top.bitmap, w = b.width, h = b.height, n = q.order.length;
    b.clear(); var ctx = b.context;
    for (var i = 0; i < n; i++) DRAW.drawDish(ctx, w / 2 + (n > 1 ? (i ? 1 : -1) * w * 0.2 : 0), h * 0.58, Math.min(17, w * 0.24), dishOf(r.req, q.order[i]), !eaten, eaten);
    b._baseTexture.update();
  };
  ServiceFloor.prototype.drawTicket = function (S, s, q) {
    if (S.ticketParty === q.id && S.ticketGot === q.got) return;   // numbers, not a key string: this runs every frame
    S.ticketParty = q.id; S.ticketGot = q.got;
    var r = rec(), rows = [], got = q.got;
    for (var i = 0; i < q.order.length; i++) rows.push({ name: dishOf(r.req, q.order[i]).name, done: i < got });
    var b = S.ticket.bitmap, h = DRAW.ticketHeight(q.order.length); b.clear(); DRAW.drawTicket(b.context, b.width, h, { table: S.id, dishes: rows });
    b._baseTexture.update(); S.ticket.setFrame(0, 0, b.width, h);
  };

  /** Bring every seat's sprites into line with the saved state (on creation, and whenever a state event arrives). */
  ServiceFloor.prototype.syncAll = function (instant) {
    var r = rec(), s = r.shift; if (!s) return;
    for (var i = 0; i < this._seatList.length; i++) this.syncSeat(this._seatList[i], s, instant);
  };
  ServiceFloor.prototype.syncSeat = function (S, s, instant) {
    var pid = s.seats[S.id], q = pid ? CORE.party(s, pid) : null, ev = $gameMap.event(S.eventId);
    if (!ev) return;
    if (q && q.id !== S.party) { S.party = q.id; this.drawDiner(S, ev, q); S.fade = instant ? 20 : 0; S.gone = 0; S.ticketParty = 0; S.phase = ''; }
    if (!q && S.party && !S.gone) { S.gone = 1; var was = CORE.party(s, S.party); S.leftPaid = !!(was && was.phase === 'gone'); }   // they left: fade out (a paid party leaves its empty plates)
    if (q && q.phase !== S.phase) {
      S.phase = q.phase;
      if (q.phase === 'eating') { this.drawTop(S, q, false); S.eatenDrawn = false; }
    }
  };

  ServiceFloor.prototype.update = function () {
    Sprite.prototype.update.call(this);
    var r = rec(); if (!r) return;
    var s = r.shift, L = r.ledger, f = RT.frame, i;
    if (s) {
      var dirty = false;
      while (RT.fx.length) { var e = RT.fx.shift(); if (e.type === 'tag') this.launchTag(e); else { dirty = true; if (e.type === 'walked' && e.seat) { var W = this._seats[e.seat]; if (W) { W.puff.visible = true; W.puffLife = 50; } } } }
      if (dirty) { this.syncAll(false); this._passDirty = true; this._hudDirty = true; }
      for (i = 0; i < this._seatList.length; i++) this.placeSeat(this._seatList[i], s, f);
      this.placePass(r, s);
      this.drawHudIfNeeded(r, s, f);
      this._hud.visible = !L && !$gameMessage.isBusy();   // a message box sits where the tray may be; the shift is paused then anyway
    }
    for (i = 0; i < this._tags.length; i++) this.placeTag(this._tags[i]);
    this.updateBanner(r, s);
    this.updateBook(L);
  };
  ServiceFloor.prototype.placeSeat = function (S, s, f) {
    var ev = $gameMap.event(S.eventId), tw = tileW(), th = tileH(); if (!ev) return;
    var pt = footOf(ev, this._pt), dir = ev.direction(), q = S.party ? CORE.party(s, S.party) : null;
    var tx = pt.x + DX[dir] * tw, ty = pt.y - th / 2 + DY[dir] * th;
    var live = !!(q && (q.phase === 'waiting' || q.phase === 'ordered' || q.phase === 'eating')) && !S.gone;
    if (S.gone) { S.gone++; if (S.gone > 30) { S.party = 0; S.gone = 0; S.phase = ''; } }
    var alpha = S.gone ? Math.max(0, 1 - S.gone / 30) : Math.min(1, (S.fade = Math.min(20, S.fade + 1)) / 20);
    S.diner.visible = !!S.party; S.diner.opacity = 255 * alpha;
    S.diner.x = pt.x; S.diner.y = pt.y - (S.gone ? 0 : (1 - alpha) * 10) + (q && q.phase === 'eating' ? (Math.sin((f + S.id * 13) * 0.2) > 0.6 ? -1 : 0) : 0);
    // the table-top (while eating), the candle (while waiting), the bell (before the order), the ticket (after it)
    var eating = live && q.phase === 'eating', waiting = live && (q.phase === 'waiting' || q.phase === 'ordered');
    if (eating && q.eat < CORE.EAT * 0.3 && !S.eatenDrawn) { this.drawTop(S, q, true); S.eatenDrawn = true; }
    S.top.visible = eating || (S.gone > 0 && !!S.leftPaid); S.top.x = tx; S.top.y = ty; S.top.opacity = 255 * (S.gone ? alpha : 1);
    // the candle: on the table's right for a diner facing up or down; on the table's FAR side for one facing sideways, where
    // the ticket above the diner cannot cover it (found by looking at a live floor: it did)
    var cx = tx + (DY[dir] ? tw * 0.36 : DX[dir] * tw * 0.3), cy = ty + (DX[dir] ? -th * 0.06 : -th * 0.12);
    S.holder.visible = S.wax.visible = S.flame.visible = waiting; S.holder.x = S.wax.x = S.flame.x = cx; S.holder.y = cy; S.wax.y = cy;
    if (waiting) {
      var frac = Math.max(0, q.left / q.patience), hh = Math.max(2, Math.round(30 * frac));
      if (hh !== S.waxH) { S.waxH = hh; S.wax.setFrame(0, 30 - hh, 9, hh); }
      S.flame.y = cy - hh + 1; S.flame.bitmap = frac < 0.25 ? this._shared.gutter : this._shared.flame;
      var fl = Math.sin((f + S.id * 7) * 0.35) * 0.08 + Math.sin((f + S.id * 3) * 0.9) * 0.05; S.flame.scale.y = (frac < 0.25 ? 0.8 : 1) + fl; S.flame.scale.x = 1 - fl * 0.5;
    }
    S.bell.visible = live && q.phase === 'waiting'; S.bell.x = pt.x; S.bell.y = pt.y - th - 2;
    if (S.bell.visible) { var ring = (f + S.id * 11) % 80; S.bell.rotation = ring < 20 ? Math.sin(ring * 0.9) * 0.35 * (1 - ring / 20) : 0; }
    S.ticket.visible = live && q.phase === 'ordered'; S.ticket.x = pt.x - DX[dir] * tw * 0.5; S.ticket.y = pt.y - th + 4;
    if (S.ticket.visible) {
      this.drawTicket(S, s, q);
      // ⛔ found by looking at the GIF: the tile beside a diner is where the server stands to serve them, and the ticket
      // above the diner covered the server completely. A ticket the player stands under goes see-through.
      var ppx = $gamePlayer.screenX(), ppy = $gamePlayer.screenY(), half = S.ticket.bitmap.width / 2 + 8;
      S.ticket.opacity = ppx > S.ticket.x - half && ppx < S.ticket.x + half && ppy > S.ticket.y - S.ticket.height && ppy - th < S.ticket.y ? 96 : 255;
    }
    if (S.puffLife > 0) { S.puffLife--; S.puff.x = cx; S.puff.y = cy - 4 - (50 - S.puffLife) * 0.4; S.puff.opacity = 255 * Math.min(1, S.puffLife / 25); if (!S.puffLife) S.puff.visible = false; }
  };
  ServiceFloor.prototype.placePass = function (r, s) {
    var ev = r.req.pass ? $gameMap.event(r.req.pass) : null; this._pass.visible = !!ev; if (!ev) return;
    var pt = footOf(ev, this._pt); this._pass.x = pt.x; this._pass.y = pt.y - 4;
    if (!this._passDirty) return; this._passDirty = false;
    var ready = []; for (var i = 0; i < s.pass.length; i++) ready.push({ name: dishOf(r.req, s.pass[i].item), table: tableOfParty(s, s.pass[i].party) });
    var b = this._pass.bitmap; DRAW.drawPass(b.context, b.width, b.height, ready); b._baseTexture.update();
  };
  ServiceFloor.prototype.drawHudIfNeeded = function (r, s, f) {
    var L = s.ledger, prog = Math.min(1, s.t / s.plan.length), tick = Math.floor(prog * 120);
    if (!this._hudDirty && tick === this._hudTick) return; this._hudDirty = false; this._hudTick = tick;
    var hands = [], b = this._hud.bitmap; for (var i = 0; i < 2; i++) hands.push(s.hands[i] ? { name: dishOf(r.req, s.hands[i].item), table: tableOfParty(s, s.hands[i].party) } : null);
    DRAW.drawHud(b.context, b.width, b.height, { hands: hands, progress: prog, tips: L.tips, currency: TextManager.currencyUnit, served: L.served, walkouts: L.walkouts }); b._baseTexture.update();
  };
  ServiceFloor.prototype.launchTag = function (e) {
    var t = null; for (var i = 0; i < this._tags.length; i++) if (!this._tags[i].visible) { t = this._tags[i]; break; }
    if (!t) { t = this._tags[0]; for (i = 1; i < this._tags.length; i++) if (this._tags[i]._life < t._life) t = this._tags[i]; }
    DRAW.drawTag(t.bitmap.context, t.bitmap.width, t.bitmap.height, e.text, e.kind); t.bitmap._baseTexture.update();
    t._seat = e.seat; t._life = 70; t.visible = true; t._text = e.text;
  };
  ServiceFloor.prototype.placeTag = function (t) {
    if (!t.visible) return;
    var r = rec(); if (!r || !r.req) { t.visible = false; return; }
    var ev = t._seat === 'pass' ? (r.req.pass ? $gameMap.event(r.req.pass) : $gamePlayer) : $gameMap.event(r.req.tables[t._seat]);
    if (!ev) ev = $gamePlayer;
    var pt = footOf(ev, this._pt), age = 70 - t._life; t.x = pt.x; t.y = pt.y - tileH() - 8 - age * 0.35; t.opacity = 255 * Math.min(1, t._life / 20);
    if (--t._life <= 0) t.visible = false;
  };
  ServiceFloor.prototype.updateBanner = function (r, s) {
    var on = !!(s && RT.banner > 0 && !r.ledger);
    if (on && !this._bannerDrawn) { var dl = { easy: 'Easy', normal: 'Normal', busy: 'Busy' }[r.req.difficulty]; DRAW.drawBanner(this._banner.bitmap.context, 440, 96, r.req.title, dl + ' night · ' + s.parties.length + ' parties · ' + Object.keys(r.req.tables).length + ' tables'); this._banner.bitmap._baseTexture.update(); this._bannerDrawn = true; }
    this._banner.visible = on;
    if (on) { var t = 150 - RT.banner; this._banner.y = t < 20 ? -96 + t * 5.3 : (RT.banner < 20 ? 10 - (20 - RT.banner) * 5.3 : 10); }
  };
  ServiceFloor.prototype.updateBook = function (L) {
    if (!L) { this._book.visible = false; this._bookDrawn = false; return; }
    if (!this._bookDrawn) { if (!this._book.bitmap) this._book.bitmap = new Bitmap(Graphics.width, Graphics.height); DRAW.drawLedger(this._book.bitmap.context, Graphics.width, Graphics.height, L); this._book.bitmap._baseTexture.update(); this._bookDrawn = true; }
    this._book.visible = true; this._book.opacity = Math.min(255, RT.ledgerAge * 16);
    this._hud.visible = false;
  };
  ServiceFloor.prototype.teardown = function () {
    var tm = this._tm, self = this;
    for (var i = 0; i < this._seatList.length; i++) { var S = this._seatList[i]; [S.diner, S.top, S.holder, S.wax, S.flame, S.bell, S.ticket, S.puff].forEach(function (sp) { tm.removeChild(sp); }); }
    tm.removeChild(this._pass); this._tags.forEach(function (t) { tm.removeChild(t); });
    if (this._over.parent) this._over.parent.removeChild(this._over);
    if (this.parent) this.parent.removeChild(this);
    self._seats = {};
  };

  /** Called by the spriteset each frame: build the floor when a shift opens here, tear it down when it closes. */
  function updateSpriteset(ss) {
    var r = rec(), want = !!(r && (r.shift || r.ledger) && r.req && $gameMap.mapId() === r.req.mapId);
    if (want && !ss._csafServiceFloor) { ss._csafServiceFloor = new ServiceFloor(ss); ss.addChild(ss._csafServiceFloor); }
    else if (!want && ss._csafServiceFloor) { ss._csafServiceFloor.teardown(); ss._csafServiceFloor = null; }
  }

  // -------------------------------------------------------------------------------------------------------------------
  // Engine seams (each extends a core method and calls the original)
  // -------------------------------------------------------------------------------------------------------------------

  PluginManager.registerCommand(NAME, 'start', function (args) { start(args, $gameMap.mapId(), this.eventId ? this.eventId() : 0); });
  PluginManager.registerCommand(NAME, 'end', function () { end(); });

  var _mapUpdate = Game_Map.prototype.update;
  Game_Map.prototype.update = function (sceneActive) { _mapUpdate.apply(this, arguments); if (sceneActive) update(); };

  /** OK (or a click) on a seated party or the pass is a service action; anything else is the engine's as usual. */
  var _there = Game_Player.prototype.checkEventTriggerThere;
  Game_Player.prototype.checkEventTriggerThere = function (triggers) {
    if (triggers.indexOf(0) >= 0 && onFloor() && this.canStartLocalEvents()) {
      var d = this.direction(), x2 = $gameMap.roundXWithDirection(this.x, d), y2 = $gameMap.roundYWithDirection(this.y, d);
      var hit = serveAt(x2, y2);
      if (!hit && $gameMap.isCounter(x2, y2)) hit = serveAt($gameMap.roundXWithDirection(x2, d), $gameMap.roundYWithDirection(y2, d));
      if (hit) { $gameTemp.clearDestination(); return; }
    }
    _there.apply(this, arguments);
  };
  var _canMove = Game_Player.prototype.canMove;
  Game_Player.prototype.canMove = function () { if (isLedgerOpen() && $gameMap.mapId() === rec().req.mapId) return false; return _canMove.apply(this, arguments); };
  var _menuEnabled = Scene_Map.prototype.isMenuEnabled;
  Scene_Map.prototype.isMenuEnabled = function () { if (isOpen() && !P.allowMenu) return false; return _menuEnabled.apply(this, arguments); };
  var _ssUpdate = Spriteset_Map.prototype.update;
  Spriteset_Map.prototype.update = function () { _ssUpdate.apply(this, arguments); updateSpriteset(this); };

  return {
    VERSION: '1.0.0', P: P, RT: RT, deps: deps, rec: rec, start: start, end: end, isOpen: isOpen, isLedgerOpen: isLedgerOpen,
    serveAt: serveAt, update: update, closeLedger: closeLedger, scanMap: scanMap, buildMenu: buildMenu, dishOf: dishOf, parseHouse: parseHouse,
    lastResult: function () { var r = rec(); return r ? r.last : null; }, ServiceFloor: ServiceFloor,
  };
}());
