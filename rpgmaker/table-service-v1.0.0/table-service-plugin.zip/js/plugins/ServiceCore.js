//=============================================================================
// ServiceCore.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Table Service core - the shift: customers seated at
 * your own tables, orders, the kitchen, patience, tips and the ledger.
 * Place ABOVE ServiceDraw and Service.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The rules of a serving shift for Table Service. No parameters or commands
 * of its own; Service.js is the file you configure. Must be installed and
 * listed above Service.js.
 *
 * Pure logic: nothing here touches the screen and nothing uses Math.random.
 *
 * THE SHIFT. Customers arrive through the shift (faster as it goes on) and
 * take a free seat at one of your tables. The server takes the order at the
 * table; the kitchen cooks it; the dish waits at the pass; the server carries
 * it (two hands) to the right table. Every waiting customer has patience,
 * which runs down while they wait for the server and for the food. Served
 * quickly, they tip well; left too long, they walk out. At the end of the
 * shift the ledger counts covers, takings, tips and walkouts.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var ServiceCore = (function () {
  'use strict';

  function hashString(s) { var h = 0x811c9dc5; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h >>> 0; }
  function rng(seed) { var a = seed >>> 0; return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

  /**
   * Difficulty: how long the shift runs (frames at 60 per second), how many parties come, how patient they are
   * (frames), and how much the arrival rate rises from the first minute to the last.
   * ⛔ Set from Internal_Ops/_scripts/balance_probe.js, never guessed (wing §10). MEASURED 2026-09-28 with the SHIPPED
   * rules (the pass hands over the first dish waiting; the House menu's cook times), 60 shifts per cell, seeds 1000+, two
   * floors (a 6-seat cafe beside the pass; an 8-seat hall with longer walks), stars 0/1/2/3:
   *   easy   skilled cafe 0/0/26/34, hall 0/2/48/10   | careless 48/12/0/0, 59/1/0/0
   *   normal skilled cafe 0/1/55/4,  hall 1/31/28/0   | careless 60/0/0/0 both (walkouts median 9-10 of 12)
   *   busy   skilled cafe 0/18/42/0, hall 5/49/6/0    | careless 60/0/0/0 both (walkouts median 13 of 15)
   * (busy was 17 parties at 1500 patience: skilled 1 star with 4-8 walkouts on BOTH floors, loosened to these.)
   * The floor matters: longer walks cost a star, so the Readme must say so.
   */
  var DIFFS = {
    easy: { length: 5400, parties: 8, patience: 2400, ramp: 1.4 },
    normal: { length: 6300, parties: 12, patience: 2100, ramp: 1.8 },
    busy: { length: 7200, parties: 15, patience: 1850, ramp: 2.2 },
  };
  var HANDS = 2;            // dishes the server can carry at once
  var EAT = 600;            // frames a served party eats before leaving
  var ORDER_TAKE = 30;      // frames spent taking an order at the table (the scene may animate it)
  var PHASES = ['arriving', 'waiting', 'ordered', 'eating', 'gone', 'walked'];

  /**
   * A shift plan from a seed and the buyer's data. Every random choice is made here, once, so the same seed deals the
   * same shift. @param {{seed:number, difficulty?:string, seats:Array<{id:number}>, menu:Array<{id:number, price:number,
   * cook?:number}>}} opt  @returns the plan: its parties (arrival frame, order, patience), in arrival order
   */
  function plan(opt) {
    opt = opt || {};
    var seed = Number(opt.seed) >>> 0, r = rng(seed ^ 0x5EA7), diff = Object.prototype.hasOwnProperty.call(DIFFS, opt.difficulty) ? opt.difficulty : 'normal', D = DIFFS[diff];
    var menu = (opt.menu || []).filter(function (m) { return m && Number(m.id) > 0; }), seats = (opt.seats || []).filter(function (s) { return s && Number(s.id) > 0; });
    var parties = [], n = D.parties, i;
    if (!menu.length || !seats.length) return { v: 1, seed: seed, difficulty: diff, length: D.length, parties: parties, menu: menu, seats: seats };
    // arrival times: the gaps shrink across the shift by the ramp; the last party arrives with at least a patience to spare
    var last = Math.max(600, D.length - D.patience), weights = [], total = 0;
    for (i = 0; i < n; i++) { var w = 1 / (1 + (D.ramp - 1) * (i / Math.max(1, n - 1))) * (0.7 + r() * 0.6); weights.push(w); total += w; }
    var t = 120;
    for (i = 0; i < n; i++) {
      var dishes = r() < 0.35 ? 2 : 1, order = [];
      for (var k = 0; k < dishes; k++) order.push(Number(menu[Math.floor(r() * menu.length) % menu.length].id));
      parties.push({ id: i + 1, at: Math.round(t), order: order, patience: Math.round(D.patience * (0.85 + r() * 0.3)) });
      t += weights[i] / total * (last - 120);
    }
    return { v: 1, seed: seed, difficulty: diff, length: D.length, parties: parties, menu: menu, seats: seats };
  }

  function menuItem(p, id) { for (var i = 0; i < p.menu.length; i++) if (Number(p.menu[i].id) === Number(id)) return p.menu[i]; return null; }
  function cookTime(p, id) { var m = menuItem(p, id); var c = m && Number(m.cook); return c > 0 ? c : 240; }
  function priceOf(p, id) { var m = menuItem(p, id); var c = m && Number(m.price); return c > 0 ? c : 0; }

  /** A fresh shift from a plan. Nothing in it is shared with the plan, so a plan can be replayed. */
  function newShift(p) {
    var s = { v: 1, t: 0, over: false, plan: p, parties: [], seats: {}, pass: [], kitchen: [], hands: [], events: [], nextParty: 0,
      ledger: { covers: 0, served: 0, walkouts: 0, takings: 0, tips: 0, dishes: 0, longestWait: 0, streak: 0, bestStreak: 0 } };
    for (var i = 0; i < p.seats.length; i++) s.seats[p.seats[i].id] = 0;
    for (i = 0; i < p.parties.length; i++) { var q = p.parties[i]; s.parties.push({ id: q.id, at: q.at, order: q.order.slice(), patience: q.patience, left: q.patience, seat: 0, phase: 'arriving', got: 0, waited: 0, tip: 0, eat: 0 }); }
    return s;
  }
  function party(s, id) { for (var i = 0; i < s.parties.length; i++) if (s.parties[i].id === id) return s.parties[i]; return null; }
  function freeSeat(s) { var ids = s.plan.seats; for (var i = 0; i < ids.length; i++) if (!s.seats[ids[i].id]) return ids[i].id; return 0; }

  /**
   * Advance the shift by n frames. Arrivals take a free seat (a party with no seat waits at the door, and its patience
   * runs there too); patience runs down while a party waits for the server or the food (not while eating); the kitchen
   * finishes dishes onto the pass; a party that runs out of patience walks out, and one that has eaten leaves and pays.
   * Events for this call are left in s.events (the array is reused: read it before the next tick).
   * @returns {number} the number of events
   */
  function tick(s, n) {
    s.events.length = 0; if (s.over) return 0; n = Math.max(1, Math.floor(Number(n) || 1));
    for (var f = 0; f < n; f++) {
      s.t++;
      var P = s.parties, i;
      for (i = 0; i < P.length; i++) {
        var q = P[i];
        if (q.phase === 'arriving' && q.at <= s.t) {
          if (!q.seat) { var seat = freeSeat(s); if (seat) { q.seat = seat; s.seats[seat] = q.id; q.phase = 'waiting'; s.events.push({ type: 'seated', party: q.id, seat: seat }); } }
          if (q.phase === 'arriving') { q.left--; q.waited++; if (q.left <= 0) walk(s, q); }
        } else if (q.phase === 'waiting' || q.phase === 'ordered') {
          q.left--; q.waited++; if (q.waited > s.ledger.longestWait) s.ledger.longestWait = q.waited;
          if (q.left <= 0) walk(s, q);
        } else if (q.phase === 'eating') {
          if (--q.eat <= 0) { q.phase = 'gone'; s.seats[q.seat] = 0; s.events.push({ type: 'paid', party: q.id, seat: q.seat, tip: q.tip }); }
        }
      }
      for (i = 0; i < s.kitchen.length; i++) { var k = s.kitchen[i]; if (k.ready > 0 && --k.ready === 0) { s.pass.push({ item: k.item, party: k.party }); s.events.push({ type: 'ready', item: k.item, party: k.party }); } }
      for (i = s.kitchen.length - 1; i >= 0; i--) if (s.kitchen[i].ready === 0) s.kitchen.splice(i, 1);
      if (s.t >= s.plan.length && everyoneDone(s)) { s.over = true; s.events.push({ type: 'close' }); break; }
      if (s.t >= s.plan.length * 2) { s.over = true; s.events.push({ type: 'close' }); break; }   // hard stop: nobody is kept waiting forever
    }
    return s.events.length;
  }
  function everyoneDone(s) { for (var i = 0; i < s.parties.length; i++) { var ph = s.parties[i].phase; if (ph !== 'gone' && ph !== 'walked') return false; } return true; }
  function walk(s, q) {
    q.phase = 'walked'; if (q.seat) s.seats[q.seat] = 0; s.ledger.walkouts++; s.ledger.streak = 0;
    // their dishes still in the kitchen or at the pass are wasted; ones in the server's hands are too
    for (var i = s.kitchen.length - 1; i >= 0; i--) if (s.kitchen[i].party === q.id) s.kitchen.splice(i, 1);
    for (i = s.pass.length - 1; i >= 0; i--) if (s.pass[i].party === q.id) s.pass.splice(i, 1);
    for (i = s.hands.length - 1; i >= 0; i--) if (s.hands[i].party === q.id) s.hands.splice(i, 1);
    s.events.push({ type: 'walked', party: q.id, seat: q.seat });
  }

  /** The server takes a seated party's order: it goes to the kitchen, one dish at a time in order. */
  function takeOrder(s, partyId) {
    var q = party(s, partyId); if (!q || q.phase !== 'waiting' || s.over) return false;
    q.phase = 'ordered'; var cook = 0;
    for (var i = 0; i < q.order.length; i++) { cook += cookTime(s.plan, q.order[i]); s.kitchen.push({ item: q.order[i], party: q.id, ready: cook + ORDER_TAKE }); }
    return true;
  }
  /** The server picks a finished dish up from the pass (a free hand needed). Index into s.pass. */
  function pickUp(s, passIndex) {
    if (s.over || s.hands.length >= HANDS) return false;
    var d = s.pass[passIndex]; if (!d) return false;
    s.pass.splice(passIndex, 1); s.hands.push(d); return true;
  }
  /**
   * The server hands a party what they ordered. Only a dish on ITS OWN ticket counts (a dish for another table is
   * refused; the server keeps it). When the last of a party's dishes lands they eat, and pay when they leave: the price
   * of what they ate, and a tip for the patience they had left.
   * @returns {number} dishes delivered (0 = nothing of theirs in hand)
   */
  function deliver(s, partyId) {
    var q = party(s, partyId); if (!q || q.phase !== 'ordered' || s.over) return 0;
    var n = 0;
    for (var i = s.hands.length - 1; i >= 0; i--) if (s.hands[i].party === q.id) { s.hands.splice(i, 1); q.got++; n++; s.ledger.dishes++; }
    if (n && q.got >= q.order.length) {
      var bill = 0; for (var k = 0; k < q.order.length; k++) bill += priceOf(s.plan, q.order[k]);
      var frac = Math.max(0, q.left / q.patience), tip = Math.floor(bill * (0.05 + 0.35 * frac));
      q.tip = tip; q.phase = 'eating'; q.eat = EAT;
      s.ledger.served++; s.ledger.covers += q.order.length; s.ledger.takings += bill; s.ledger.tips += tip;
      s.ledger.streak++; if (s.ledger.streak > s.ledger.bestStreak) s.ledger.bestStreak = s.ledger.streak;
    }
    return n;
  }
  /** Drop a carried dish back on the pass (so the server can free a hand). */
  function putDown(s, handIndex) { var d = s.hands[handIndex]; if (!d || s.over) return false; s.hands.splice(handIndex, 1); s.pass.push(d); return true; }

  /**
   * The ledger and a verdict: stars 0..3 from the share of parties served and the tips earned against the most they
   * could have been (every party served with full patience). @returns {{served, walkouts, parties, takings, tips,
   * tipShare:number, stars:number, grade:string}}
   */
  function score(s) {
    var L = s.ledger, n = s.parties.length, best = 0;
    for (var i = 0; i < n; i++) { var bill = 0; for (var k = 0; k < s.parties[i].order.length; k++) bill += priceOf(s.plan, s.parties[i].order[k]); best += Math.floor(bill * 0.4); }
    var servedShare = n ? L.served / n : 0, tipShare = best ? L.tips / best : 0;
    var stars = servedShare >= 1 && tipShare >= 0.6 ? 3 : (servedShare >= 0.8 && tipShare >= 0.35 ? 2 : (servedShare >= 0.5 ? 1 : 0));
    return { served: L.served, walkouts: L.walkouts, parties: n, covers: L.covers, takings: L.takings, tips: L.tips, tipShare: Math.round(tipShare * 100) / 100,
      longestWait: L.longestWait, bestStreak: L.bestStreak, stars: stars, grade: ['A rough night', 'A fair night', 'A good night', 'A full house'][stars] };
  }

  return {
    VERSION: '1.0.0', DIFFS: DIFFS, HANDS: HANDS, EAT: EAT, PHASES: PHASES, hashString: hashString, rng: rng,
    plan: plan, newShift: newShift, party: party, freeSeat: freeSeat, tick: tick, takeOrder: takeOrder, pickUp: pickUp, deliver: deliver, putDown: putDown,
    cookTime: cookTime, priceOf: priceOf, score: score,
  };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = ServiceCore;
