//=============================================================================
// ServiceDraw.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Table Service drawing - diners, dishes read from each
 * item's own name, order tickets, patience candles, the pass and the ledger.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 * @base ServiceCore
 * @orderAfter ServiceCore
 *
 * @help
 * Everything Table Service shows over your map is drawn here at runtime with
 * the canvas: no image files are loaded. No parameters or commands of its
 * own; Service.js is the file you configure. Install it with ServiceCore.js
 * and Service.js.
 *
 * DISHES ARE READ FROM THEIR NAMES. "Pumpkin Soup" is served in a bowl the
 * colour of pumpkin, "Pale Ale" in a tankard with a head of foam, "Honey
 * Loaf" as a scored loaf, "Grilled Trout" as a whole fish with lemon. About
 * 170 words are known (soups, stews, roasts, fish, pies, cakes, breads,
 * salads, drinks, potions and more); a name it does not know still gets a
 * plated dish, the same one every time.
 *
 * DINERS ARE GENERATED. Unless you give Service.js your own character
 * sheets, every party is drawn fresh: face, hair and hat, coat and scarf,
 * seated and facing the way your seat event faces.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var ServiceDraw = (function () {
  'use strict';

  var FACE = '"Palatino Linotype", "Book Antiqua", Palatino, "Georgia", serif';
  var HAND = '"Segoe Print", "Bradley Hand", "Comic Sans MS", "Palatino Linotype", cursive';
  var INK = '#2b1d12';
  var TAU = 6.283185307179586;
  function hash(s) { var h = 0x811c9dc5; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h >>> 0; }
  function rr(ctx, x, y, w, h, r) { r = Math.max(0, Math.min(r, w / 2, h / 2)); ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
  function fitText(ctx, text, maxW, size, style, face) { ctx.font = (style || '') + ' ' + size + 'px ' + (face || FACE); while (size > 8 && ctx.measureText(text).width > maxW) { size--; ctx.font = (style || '') + ' ' + size + 'px ' + (face || FACE); } return size; }
  function ell(ctx, x, y, rx, ry, rot) { ctx.beginPath(); ctx.ellipse(x, y, Math.max(0.1, rx), Math.max(0.1, ry), rot || 0, 0, TAU); }
  function hex(c) { return [parseInt(c.slice(1, 3), 16), parseInt(c.slice(3, 5), 16), parseInt(c.slice(5, 7), 16)]; }
  /** Lighten (k > 0) or darken (k < 0) a #rrggbb colour by an absolute step, so a light colour and a dark one move by the same amount (Icon_Doctrine §22e-1). */
  function shade(c, k) { var v = hex(c); for (var i = 0; i < 3; i++) v[i] = Math.max(0, Math.min(255, Math.round(v[i] + k))); return '#' + ((1 << 24) | (v[0] << 16) | (v[1] << 8) | v[2]).toString(16).slice(1); }

  // ---------------------------------------------------------------------------------------------------------------
  // Dishes, read from the name
  // ---------------------------------------------------------------------------------------------------------------

  /**
   * What a dish IS, from the words of its name: the first matching row wins, so drinks are tested before foods
   * ("Herbal Tea" is a cup, not a salad) and pies before fruit ("Apple Pie" is a pie). Word starts only: "ale"
   * matches "Pale Ale" and not "Kale".
   */
  var FORMS = [
    ['bottle', 'potion elixir tonic draught remedy antidote serum philter essence vial drop phial cure'],
    ['mug', 'ale beer mead cider stout lager grog porter bitter'],
    ['cup', 'tea coffee cocoa milk latte chai infusion'],
    ['glass', 'wine champagne sherry brandy cocktail nectar juice water lemonade punch spirit liqueur sake'],
    ['soup', 'soup broth chowder bisque consomme gazpacho'],
    ['stew', 'stew curry porridge gruel chili goulash hotpot pottage casserole oatmeal'],
    ['pie', 'pie pasty quiche pot pie cobbler'],
    ['cake', 'cake tart pudding cookie biscuit pastry scone muffin crepe pancake waffle dessert sweet candy custard eclair'],
    ['bread', 'bread loaf bun roll baguette toast bagel sandwich croissant flatbread biscuit'],
    ['fish', 'fish trout salmon cod eel carp bass herring sardine tuna mackerel perch pike snapper catch'],
    ['roast', 'chicken roast turkey duck goose pheasant fowl drumstick wing quail hen'],
    ['sausage', 'sausage wurst frank banger'],
    ['steak', 'steak beef pork ham lamb mutton venison boar meat chop rib bacon jerky cutlet brisket'],
    ['noodles', 'noodle pasta spaghetti ramen udon macaroni'],
    ['rice', 'rice risotto pilaf onigiri sushi'],
    ['egg', 'egg omelet omelette'],
    ['cheese', 'cheese brie cheddar'],
    ['salad', 'salad herb greens leaf leaves cabbage lettuce spinach weed sprout'],
    ['fruit', 'apple berry berries grape pear peach plum fruit cherry orange banana melon fig'],
  ];
  var PALETTE = {
    amber: ['#e8b04a', '#9a6214'], orange: ['#ec8a3a', '#a4501a'], red: ['#d24a36', '#7e1e14'], purple: ['#8a4aa0', '#4a1e5e'],
    green: ['#7cb44a', '#3e6a1c'], blue: ['#5a8ed8', '#24407e'], brown: ['#9a643a', '#56321a'], cream: ['#f0e2bc', '#b49e70'],
    yellow: ['#f0d04a', '#a88818'], dark: ['#4a3a4a', '#1e141e'], pink: ['#ec9a9a', '#a4545a'], gold: ['#f2cc5a', '#a07818'],
    roast: ['#cc7a36', '#6a300e'],
  };
  var COLOURS = [
    ['amber', 'honey golden gold mead ale beer amber caramel syrup'], ['orange', 'pumpkin carrot orange squash curry apricot sweet potato'],
    ['red', 'tomato red fire apple cherry strawberry beet chili rose flame blood raspberry'], ['purple', 'berry grape plum wine purple blueberry violet lavender'],
    ['green', 'mint herb green pea leaf salad cabbage spinach lime matcha forest moss'], ['blue', 'blue ice frost magic mana sky water sea storm'],
    ['brown', 'mushroom brown beef stew bread coffee cocoa chocolate nut walnut rye stout porter boar gravy'], ['cream', 'cream milk rice white vanilla cheese egg potato porridge oat'],
    ['yellow', 'lemon yellow banana corn butter saffron'], ['dark', 'black dark shadow ink night'], ['pink', 'pink peach salmon ham shrimp'], ['gold', 'elixir royal golden'],
  ];
  var FORM_DEFAULT = { bottle: null, mug: 'amber', cup: 'brown', glass: 'red', soup: 'orange', stew: 'brown', pie: 'red', cake: 'pink', bread: 'amber', fish: 'cream', roast: 'roast', sausage: 'brown', steak: 'brown', noodles: 'cream', rice: 'cream', egg: 'yellow', cheese: 'yellow', salad: 'green', fruit: 'red', plate: 'orange' };
  var FALLBACK = ['plate', 'stew', 'pie', 'roast', 'bread'];
  var RIMS = ['#2f5f8a', '#8a2f3a', '#3a7a4a', '#a8842a', '#4a4a4a'];
  var FORM_WORDS = FORMS.map(function (r) { return [r[0], r[1].split(' ')]; }), COLOUR_WORDS = COLOURS.map(function (r) { return [r[0], r[1].split(' ')]; });
  /**
   * The first of words found in name as a WHOLE word (a plural 's' or 'es' allowed). ⛔ Found by looking at the dish
   * sheet: a word-START match read "Cheese Board" as boar meat and drew a steak, so the word must END too.
   */
  function matchWord(name, words) {
    for (var i = 0; i < words.length; i++) {
      var w = words[i], at = name.indexOf(w);
      while (at >= 0) {
        var pre = at === 0 || !/[a-z]/.test(name.charAt(at - 1)), rest = name.slice(at + w.length), post = !/^[a-z]/.test(rest) || /^(s|es)(?![a-z])/.test(rest);
        if (pre && post) return w;
        at = name.indexOf(w, at + 1);
      }
    }
    return null;
  }
  var FORM_IDS = FORMS.map(function (r) { return r[0]; }).concat(['plate']);

  /**
   * A dish's look from its name: its FORM (what it is and what it is served in), its colours, and the plate's rim.
   * A dish can also be an object {name, form, colour}: a form or colour given there (from a <Dish: soup> or
   * <Dish Colour: blue> notetag) wins over the words.
   * @param {string|{name:string, form?:string, colour?:string}} dish
   * @returns {{form:string, food:string[], rim:string, known:boolean, word:string|null, colour:string, shape:number}}
   */
  function dishLook(dish) {
    var name = dish && typeof dish === 'object' ? dish.name : dish, n = String(name || '').toLowerCase(), h = hash(n), form = null, word = null, i;
    if (dish && typeof dish === 'object' && FORM_IDS.indexOf(String(dish.form || '').toLowerCase()) >= 0) { form = String(dish.form).toLowerCase(); word = 'tag'; }
    for (i = 0; i < FORM_WORDS.length && !form; i++) { var w = matchWord(n, FORM_WORDS[i][1]); if (w) { form = FORM_WORDS[i][0]; word = w; } }
    var known = !!form; if (!form) form = FALLBACK[h % FALLBACK.length];
    var col = null;
    // own properties only: a <Dish Colour: __proto__> must not reach Object.prototype (break-it)
    if (dish && typeof dish === 'object' && Object.prototype.hasOwnProperty.call(PALETTE, String(dish.colour || '').toLowerCase())) col = String(dish.colour).toLowerCase();
    for (i = 0; i < COLOUR_WORDS.length && !col; i++) { if (matchWord(n, COLOUR_WORDS[i][1])) col = COLOUR_WORDS[i][0]; }
    var fromWords = !!col;
    if (!col) col = FORM_DEFAULT[form] || ['red', 'blue', 'green', 'purple', 'amber'][(h >>> 6) % 5];
    // a bottle nobody coloured takes its colour from the name; its SHAPE always does, so two potions of one colour differ
    if (form === 'bottle' && !fromWords && !(dish && dish.colour)) col = ['red', 'blue', 'green', 'purple', 'gold', 'orange', 'pink'][(h >>> 6) % 7];
    return { form: form, food: PALETTE[col], colour: col, rim: RIMS[(h >>> 4) % RIMS.length], known: known, word: word, shape: hash('shape:' + n) % 3 };
  }
  /** Is this form served as a drink (a vessel on its own, no plate)? */
  function isDrink(form) { return form === 'bottle' || form === 'mug' || form === 'cup' || form === 'glass'; }
  /** Rough kitchen time for a form, in frames: a drink is poured, a bowl ladled, a plate cooked. */
  function cookFrames(form) { return isDrink(form) ? 150 : (form === 'soup' || form === 'stew' || form === 'salad' || form === 'bread' || form === 'fruit' || form === 'cheese' ? 220 : 320); }

  function drawPlate(ctx, x, y, r, rim) {
    ctx.fillStyle = 'rgba(0,0,0,0.3)'; ell(ctx, x + r * 0.07, y + r * 0.14, r, r * 0.6); ctx.fill();
    ctx.fillStyle = '#f7f2e6'; ell(ctx, x, y, r, r * 0.6); ctx.fill();
    ctx.fillStyle = '#e6dcc6'; ell(ctx, x, y + r * 0.04, r * 0.7, r * 0.4); ctx.fill();
    ctx.strokeStyle = rim; ctx.lineWidth = Math.max(1, r * 0.08); ell(ctx, x, y, r * 0.86, r * 0.51); ctx.stroke();
    ctx.strokeStyle = 'rgba(90,70,50,0.55)'; ctx.lineWidth = 1; ell(ctx, x, y, r, r * 0.6); ctx.stroke();
  }
  function food(ctx, x, y, r, c) { var g = ctx.createRadialGradient(x - r * 0.3, y - r * 0.3, r * 0.05, x, y, r * 1.05); g.addColorStop(0, shade(c[0], 26)); g.addColorStop(0.55, c[0]); g.addColorStop(1, c[1]); return g; }
  function outline(ctx, w) { ctx.strokeStyle = 'rgba(40,20,5,0.55)'; ctx.lineWidth = Math.max(0.8, w); ctx.stroke(); }
  function steam(ctx, x, y, r, n) { ctx.strokeStyle = 'rgba(255,255,255,0.6)'; ctx.lineWidth = Math.max(1, r * 0.06); ctx.lineCap = 'round'; for (var s = 0; s < n; s++) { var sx = x - r * 0.22 + s * r * 0.22; ctx.beginPath(); ctx.moveTo(sx, y); ctx.bezierCurveTo(sx - r * 0.14, y - r * 0.22, sx + r * 0.14, y - r * 0.38, sx, y - r * 0.6); ctx.stroke(); } ctx.lineCap = 'butt'; }

  /**
   * A dish, drawn as what its name says it is. Centre (x, y) on the table, size r (a plate's radius). hot = steam;
   * eaten = the empty plate or glass that is left (crumbs, a bone, a drained glass).
   */
  function drawDish(ctx, x, y, r, dish, hot, eaten) {
    var L = dishLook(dish), c = L.food, lw = r * 0.05;
    ctx.save();
    if (L.form === 'bottle') drawBottle(ctx, x, y, r, c, eaten, L.shape);
    else if (L.form === 'mug') drawMug(ctx, x, y, r, c, eaten);
    else if (L.form === 'cup') drawCup(ctx, x, y, r, c, eaten, hot);
    else if (L.form === 'glass') drawGlass(ctx, x, y, r, c, eaten);
    else if (L.form === 'soup' || L.form === 'stew') drawBowl(ctx, x, y, r, c, L.rim, eaten, L.form === 'stew', hot);
    else {
      drawPlate(ctx, x, y, r, L.rim);
      if (eaten) drawLeftovers(ctx, x, y, r, L.form, c);
      else {
        DISHES[L.form](ctx, x, y, r, c, lw);
        if (hot && L.form !== 'salad' && L.form !== 'fruit' && L.form !== 'cheese' && L.form !== 'cake') steam(ctx, x, y - r * 0.35, r, 3);
      }
    }
    ctx.restore();
    return L;
  }
  function drawLeftovers(ctx, x, y, r, form, c) {
    ctx.fillStyle = c[1];
    for (var i = 0; i < 6; i++) { var a = i * 1.9 + 0.4, d = r * (0.18 + (i % 3) * 0.14); ctx.beginPath(); ctx.arc(x + Math.cos(a) * d, y + Math.sin(a) * d * 0.55, Math.max(0.8, r * 0.05), 0, TAU); ctx.fill(); }
    if (form === 'roast' || form === 'fish' || form === 'steak') { ctx.strokeStyle = '#efe6d0'; ctx.lineWidth = Math.max(1, r * 0.08); ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x - r * 0.3, y + r * 0.05); ctx.lineTo(x + r * 0.25, y - r * 0.08); ctx.stroke(); ctx.lineCap = 'butt'; }
    ctx.strokeStyle = '#8a8a8a'; ctx.lineWidth = Math.max(1, r * 0.05); ctx.beginPath(); ctx.moveTo(x + r * 0.55, y + r * 0.3); ctx.lineTo(x + r * 0.78, y - r * 0.18); ctx.stroke();   // the fork left on the plate
  }
  var DISHES = {
    roast: function (ctx, x, y, r, c, lw) {   // a roast bird on its back: a glazed breast and two legs raised, white bone ends in paper frills
      for (var s = -1; s <= 1; s += 2) {   // the legs first, so the body overlaps them (Icon_Doctrine §22a-1b: appendages OVERLAP)
        ctx.fillStyle = food(ctx, x + s * r * 0.34, y - r * 0.3, r * 0.22, c); ell(ctx, x + s * r * 0.3, y - r * 0.26, r * 0.2, r * 0.13, s * -0.9); ctx.fill(); outline(ctx, lw);
        ctx.strokeStyle = '#f4ecd8'; ctx.lineWidth = Math.max(1.2, r * 0.08); ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x + s * r * 0.42, y - r * 0.38); ctx.lineTo(x + s * r * 0.56, y - r * 0.56); ctx.stroke(); ctx.lineCap = 'butt';
        ctx.fillStyle = '#fbfaf2'; ell(ctx, x + s * r * 0.58, y - r * 0.6, r * 0.08, r * 0.07); ctx.fill(); outline(ctx, lw * 0.6);
      }
      ctx.fillStyle = food(ctx, x, y - r * 0.05, r * 0.5, c); ell(ctx, x, y - r * 0.02, r * 0.5, r * 0.33); ctx.fill(); outline(ctx, lw);
      ctx.strokeStyle = 'rgba(90,40,10,0.5)'; ctx.lineWidth = Math.max(0.8, r * 0.04); ctx.beginPath(); ctx.moveTo(x, y - r * 0.3); ctx.quadraticCurveTo(x + r * 0.04, y, x, y + r * 0.26); ctx.stroke();   // the breastbone
      ctx.strokeStyle = 'rgba(255,236,190,0.6)'; ctx.lineWidth = Math.max(1, r * 0.05); ctx.beginPath(); ctx.arc(x - r * 0.14, y - r * 0.08, r * 0.2, 3.6, 4.7); ctx.stroke();
      ctx.fillStyle = '#4a8a2a'; ell(ctx, x + r * 0.42, y + r * 0.2, r * 0.1, r * 0.05, -0.4); ctx.fill(); ctx.fillStyle = '#e8a030'; ell(ctx, x - r * 0.46, y + r * 0.18, r * 0.09, r * 0.07); ctx.fill();
    },
    steak: function (ctx, x, y, r, c, lw) {   // a slab with grill bars and a fat edge
      ctx.save(); ctx.translate(x, y - r * 0.05); ctx.rotate(-0.18); ctx.fillStyle = food(ctx, 0, 0, r * 0.55, c); rr(ctx, -r * 0.55, -r * 0.28, r * 1.05, r * 0.52, r * 0.22); ctx.fill(); outline(ctx, lw);
      ctx.strokeStyle = '#f2e2c8'; ctx.lineWidth = Math.max(1, r * 0.06); ctx.beginPath(); ctx.moveTo(-r * 0.45, -r * 0.3); ctx.quadraticCurveTo(0, -r * 0.38, r * 0.42, -r * 0.3); ctx.stroke();
      ctx.strokeStyle = 'rgba(30,12,4,0.8)'; ctx.lineWidth = Math.max(1, r * 0.07); for (var k = 0; k < 3; k++) { ctx.beginPath(); ctx.moveTo(-r * 0.32 + k * r * 0.28, -r * 0.18); ctx.lineTo(-r * 0.18 + k * r * 0.28, r * 0.18); ctx.stroke(); }
      ctx.restore(); ctx.fillStyle = '#5a9a3a'; ell(ctx, x + r * 0.55, y + r * 0.2, r * 0.1, r * 0.06, -0.5); ctx.fill();
    },
    fish: function (ctx, x, y, r, c, lw) {   // a whole fish: body, forked tail, eye, fin, a lemon slice
      var body = ['#d8d0c0', '#8a7a64']; if (c !== PALETTE.cream) body = c;
      ctx.fillStyle = food(ctx, x, y, r * 0.5, body); ctx.beginPath(); ctx.moveTo(x - r * 0.62, y); ctx.quadraticCurveTo(x - r * 0.2, y - r * 0.36, x + r * 0.35, y - r * 0.02); ctx.lineTo(x + r * 0.72, y - r * 0.24); ctx.lineTo(x + r * 0.62, y + r * 0.02); ctx.lineTo(x + r * 0.72, y + r * 0.22); ctx.lineTo(x + r * 0.35, y + r * 0.04); ctx.quadraticCurveTo(x - r * 0.2, y + r * 0.34, x - r * 0.62, y); ctx.closePath(); ctx.fill(); outline(ctx, lw);
      ctx.strokeStyle = 'rgba(40,20,5,0.45)'; ctx.lineWidth = Math.max(0.8, r * 0.04); for (var k = 0; k < 3; k++) { ctx.beginPath(); ctx.moveTo(x - r * 0.12 + k * r * 0.14, y - r * 0.15); ctx.lineTo(x - r * 0.04 + k * r * 0.14, y + r * 0.13); ctx.stroke(); }
      ctx.fillStyle = '#1e140a'; ell(ctx, x - r * 0.44, y - r * 0.04, r * 0.05, r * 0.05); ctx.fill();
      ctx.fillStyle = '#f2d23a'; ctx.beginPath(); ctx.arc(x - r * 0.1, y + r * 0.34, r * 0.14, 3.3, 6.1); ctx.closePath(); ctx.fill(); outline(ctx, lw * 0.7);
    },
    pie: function (ctx, x, y, r, c, lw) {   // a wedge cut from a pie: golden crust top, the filling showing at the cut face
      ctx.fillStyle = c[1]; ctx.beginPath(); ctx.moveTo(x - r * 0.5, y + r * 0.12); ctx.lineTo(x + r * 0.34, y + r * 0.2); ctx.lineTo(x + r * 0.34, y + r * 0.02); ctx.lineTo(x - r * 0.5, y - r * 0.08); ctx.closePath(); ctx.fill();
      ctx.fillStyle = c[0]; ctx.fillRect(x - r * 0.48, y - r * 0.03, r * 0.8, r * 0.1);
      var g = ctx.createLinearGradient(x, y - r * 0.5, x, y); g.addColorStop(0, '#f2cc7a'); g.addColorStop(1, '#b8782e'); ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(x - r * 0.5, y - r * 0.08); ctx.lineTo(x + r * 0.34, y + r * 0.02); ctx.quadraticCurveTo(x + r * 0.55, y - r * 0.3, x + r * 0.3, y - r * 0.46); ctx.closePath(); ctx.fill(); outline(ctx, lw);
      ctx.strokeStyle = 'rgba(120,70,20,0.7)'; ctx.lineWidth = Math.max(0.8, r * 0.04); ctx.beginPath(); ctx.moveTo(x + r * 0.12, y - r * 0.22); ctx.lineTo(x + r * 0.28, y - r * 0.12); ctx.stroke();
      ctx.fillStyle = '#fbf6ea'; ell(ctx, x - r * 0.52, y + r * 0.28, r * 0.13, r * 0.08); ctx.fill();   // a spoon of cream
    },
    cake: function (ctx, x, y, r, c, lw) {   // a layered slice with a berry on top
      var top = shade(c[0], 30);
      ctx.fillStyle = c[1]; ctx.beginPath(); ctx.moveTo(x - r * 0.45, y + r * 0.14); ctx.lineTo(x + r * 0.35, y + r * 0.22); ctx.lineTo(x + r * 0.35, y - r * 0.12); ctx.lineTo(x - r * 0.45, y - r * 0.2); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#fbf2e0'; ctx.fillRect(x - r * 0.44, y - r * 0.09, r * 0.78, r * 0.07); ctx.fillRect(x - r * 0.44, y + r * 0.04, r * 0.78, r * 0.06);
      ctx.fillStyle = top; ctx.beginPath(); ctx.moveTo(x - r * 0.45, y - r * 0.2); ctx.lineTo(x + r * 0.35, y - r * 0.12); ctx.lineTo(x + r * 0.2, y - r * 0.5); ctx.closePath(); ctx.fill(); outline(ctx, lw);
      ctx.fillStyle = '#c0182a'; ell(ctx, x + r * 0.06, y - r * 0.36, r * 0.1, r * 0.1); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.7)'; ell(ctx, x + r * 0.03, y - r * 0.39, r * 0.03, r * 0.03); ctx.fill();
    },
    bread: function (ctx, x, y, r, c, lw) {   // a loaf with three scores, and a small roll
      ctx.fillStyle = food(ctx, x - r * 0.05, y - r * 0.08, r * 0.55, c); ell(ctx, x - r * 0.08, y - r * 0.06, r * 0.55, r * 0.3, -0.1); ctx.fill(); outline(ctx, lw);
      ctx.strokeStyle = shade(c[0], 40); ctx.lineWidth = Math.max(1, r * 0.06); ctx.lineCap = 'round'; for (var k = 0; k < 3; k++) { ctx.beginPath(); ctx.moveTo(x - r * 0.34 + k * r * 0.24, y - r * 0.22); ctx.lineTo(x - r * 0.22 + k * r * 0.24, y + r * 0.02); ctx.stroke(); } ctx.lineCap = 'butt';
      ctx.fillStyle = food(ctx, x + r * 0.5, y + r * 0.18, r * 0.2, c); ell(ctx, x + r * 0.52, y + r * 0.18, r * 0.2, r * 0.15); ctx.fill(); outline(ctx, lw);
    },
    salad: function (ctx, x, y, r, c, lw) {   // a heap of leaves (each its own tone), tomato and a sliced radish
      var tones = [c[0], c[1], shade(c[0], 20), shade(c[1], 16)];
      for (var k = 0; k < 7; k++) { var a = k * 0.9, d = r * (0.1 + (k % 3) * 0.12); ctx.fillStyle = tones[k % 4]; ell(ctx, x + Math.cos(a) * d, y - r * 0.08 + Math.sin(a) * d * 0.5, r * 0.26, r * 0.13, a); ctx.fill(); outline(ctx, lw * 0.6);
        ctx.strokeStyle = 'rgba(255,255,230,0.5)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * d - Math.cos(a) * r * 0.18, y - r * 0.08 + Math.sin(a) * d * 0.5 - Math.sin(a) * r * 0.09); ctx.lineTo(x + Math.cos(a) * d + Math.cos(a) * r * 0.18, y - r * 0.08 + Math.sin(a) * d * 0.5 + Math.sin(a) * r * 0.09); ctx.stroke(); }
      ctx.fillStyle = '#d23a2a'; ell(ctx, x + r * 0.24, y - r * 0.2, r * 0.11, r * 0.1); ctx.fill(); ctx.fillStyle = '#e8506a'; ell(ctx, x - r * 0.3, y + r * 0.06, r * 0.09, r * 0.08); ctx.fill();
    },
    cheese: function (ctx, x, y, r, c, lw) {   // a wedge with holes, a bunch of grapes beside
      ctx.fillStyle = c[1]; ctx.beginPath(); ctx.moveTo(x - r * 0.5, y + r * 0.14); ctx.lineTo(x + r * 0.2, y + r * 0.22); ctx.lineTo(x + r * 0.2, y + r * 0.0); ctx.lineTo(x - r * 0.5, y - r * 0.1); ctx.closePath(); ctx.fill();
      ctx.fillStyle = c[0]; ctx.beginPath(); ctx.moveTo(x - r * 0.5, y - r * 0.1); ctx.lineTo(x + r * 0.2, y); ctx.lineTo(x + r * 0.1, y - r * 0.36); ctx.closePath(); ctx.fill(); outline(ctx, lw);
      ctx.fillStyle = c[1]; [[-0.2, -0.12, 0.06], [0.0, -0.18, 0.04], [-0.3, 0.06, 0.05], [0.05, 0.1, 0.04]].forEach(function (h) { ell(ctx, x + h[0] * r, y + h[1] * r, h[2] * r, h[2] * r * 0.8); ctx.fill(); });
      ctx.fillStyle = '#6a2a6a'; for (var k = 0; k < 5; k++) { ell(ctx, x + r * (0.45 + (k % 2) * 0.12), y + r * (-0.12 + Math.floor(k / 2) * 0.12), r * 0.08, r * 0.08); ctx.fill(); }
    },
    egg: function (ctx, x, y, r, c, lw) {   // a fried egg on toast
      ctx.fillStyle = '#c8904a'; rr(ctx, x - r * 0.5, y - r * 0.28, r * 0.9, r * 0.52, r * 0.1); ctx.fill(); outline(ctx, lw);
      ctx.fillStyle = '#fbfaf2'; ctx.beginPath(); ctx.moveTo(x - r * 0.35, y); ctx.bezierCurveTo(x - r * 0.4, y - r * 0.3, x + r * 0.05, y - r * 0.35, x + r * 0.28, y - r * 0.12); ctx.bezierCurveTo(x + r * 0.42, y + r * 0.1, x - r * 0.1, y + r * 0.26, x - r * 0.35, y); ctx.fill(); outline(ctx, lw * 0.6);
      ctx.fillStyle = food(ctx, x - r * 0.04, y - r * 0.07, r * 0.14, PALETTE.yellow); ell(ctx, x - r * 0.04, y - r * 0.06, r * 0.14, r * 0.11); ctx.fill();
    },
    noodles: function (ctx, x, y, r, c, lw) {   // a nest of noodles in sauce with a sprig
      ctx.fillStyle = PALETTE.red[1]; ell(ctx, x, y, r * 0.55, r * 0.3); ctx.fill();
      ctx.strokeStyle = c[0]; ctx.lineWidth = Math.max(1, r * 0.07); for (var k = 0; k < 5; k++) { ctx.beginPath(); ctx.ellipse(x + (k % 2 ? 0.08 : -0.08) * r, y - r * 0.04 + (k - 2) * r * 0.05, r * (0.44 - k * 0.05), r * (0.2 - k * 0.02), 0.2 * k, 0.3, 5.9); ctx.stroke(); }
      ctx.fillStyle = '#4a8a2a'; ell(ctx, x + r * 0.1, y - r * 0.2, r * 0.1, r * 0.05, -0.4); ctx.fill();
    },
    rice: function (ctx, x, y, r, c, lw) {   // a dome of rice with a pickle and a leaf
      ctx.fillStyle = food(ctx, x, y - r * 0.15, r * 0.45, ['#fbf8ee', '#c8c0a8']); ctx.beginPath(); ctx.ellipse(x, y - r * 0.02, r * 0.45, r * 0.4, 0, 3.1416, TAU); ctx.lineTo(x + r * 0.45, y + r * 0.02); ctx.ellipse(x, y + r * 0.02, r * 0.45, r * 0.16, 0, 0, 3.1416); ctx.fill(); outline(ctx, lw);
      ctx.fillStyle = 'rgba(160,150,120,0.6)'; for (var k = 0; k < 8; k++) ctx.fillRect(x - r * 0.3 + (k * 13 % 7) * r * 0.09, y - r * 0.3 + (k * 5 % 4) * r * 0.08, Math.max(1, r * 0.05), Math.max(1, r * 0.03));
      ctx.fillStyle = c === PALETTE.cream ? '#e8a830' : c[0]; ell(ctx, x + r * 0.5, y + r * 0.12, r * 0.14, r * 0.08, 0.3); ctx.fill(); ctx.fillStyle = '#3a7a2a'; ell(ctx, x - r * 0.5, y + r * 0.12, r * 0.14, r * 0.06, -0.4); ctx.fill();
    },
    fruit: function (ctx, x, y, r, c, lw) {   // three fruit with a stalk and a leaf
      [[-0.28, 0.05], [0.26, 0.08], [0, -0.16]].forEach(function (p, i) { var fx = x + p[0] * r, fy = y + p[1] * r, rad = r * (i === 2 ? 0.24 : 0.26); ctx.fillStyle = food(ctx, fx, fy, rad, c); ell(ctx, fx, fy, rad, rad * 0.92); ctx.fill(); outline(ctx, lw);
        ctx.fillStyle = 'rgba(255,255,255,0.55)'; ell(ctx, fx - rad * 0.35, fy - rad * 0.35, rad * 0.2, rad * 0.13, -0.6); ctx.fill(); ctx.strokeStyle = '#4a2a0a'; ctx.lineWidth = Math.max(1, r * 0.04); ctx.beginPath(); ctx.moveTo(fx, fy - rad * 0.85); ctx.lineTo(fx + rad * 0.15, fy - rad * 1.2); ctx.stroke(); });
      ctx.fillStyle = '#4a8a2a'; ell(ctx, x + r * 0.12, y - r * 0.5, r * 0.12, r * 0.06, -0.6); ctx.fill();
    },
    sausage: function (ctx, x, y, r, c, lw) {   // two curved sausages with mustard
      for (var k = 0; k < 2; k++) { var oy = y - r * 0.14 + k * r * 0.26; ctx.strokeStyle = c[1]; ctx.lineCap = 'round'; ctx.lineWidth = r * 0.26; ctx.beginPath(); ctx.arc(x, oy + r * 0.6, r * 0.62, 4.2, 5.2); ctx.stroke(); ctx.strokeStyle = c[0]; ctx.lineWidth = r * 0.17; ctx.stroke(); ctx.strokeStyle = 'rgba(255,230,190,0.5)'; ctx.lineWidth = r * 0.05; ctx.beginPath(); ctx.arc(x, oy + r * 0.56, r * 0.62, 4.3, 5.1); ctx.stroke(); }
      ctx.lineCap = 'butt'; ctx.fillStyle = '#e8c02a'; ell(ctx, x + r * 0.5, y + r * 0.26, r * 0.12, r * 0.07); ctx.fill();
    },
    plate: function (ctx, x, y, r, c, lw) {   // a generic plated main: a mound, sauce and a sprig
      ctx.fillStyle = 'rgba(140,40,20,0.55)'; ell(ctx, x - r * 0.1, y + r * 0.12, r * 0.5, r * 0.18); ctx.fill();
      ctx.fillStyle = food(ctx, x, y - r * 0.12, r * 0.45, c); ctx.beginPath(); ctx.ellipse(x, y - r * 0.02, r * 0.42, r * 0.34, 0, 3.1416, TAU); ctx.lineTo(x + r * 0.42, y + r * 0.02); ctx.ellipse(x, y + r * 0.02, r * 0.42, r * 0.14, 0, 0, 3.1416); ctx.fill(); outline(ctx, lw);
      ctx.fillStyle = '#4a8a2a'; ell(ctx, x + r * 0.2, y - r * 0.32, r * 0.1, r * 0.05, -0.5); ctx.fill();
    },
  };
  function drawBowl(ctx, x, y, r, c, rim, eaten, chunky, hot) {   // a glazed bowl: body below, rim, the liquid surface inside
    var w = r * 0.78;
    ctx.fillStyle = 'rgba(0,0,0,0.3)'; ell(ctx, x + r * 0.06, y + r * 0.34, w * 0.9, r * 0.2); ctx.fill();
    var g = ctx.createLinearGradient(x - w, 0, x + w, 0); g.addColorStop(0, shade(rim, -20)); g.addColorStop(0.35, shade(rim, 40)); g.addColorStop(1, shade(rim, -40));
    ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(x - w, y - r * 0.12); ctx.bezierCurveTo(x - w, y + r * 0.4, x + w, y + r * 0.4, x + w, y - r * 0.12); ctx.closePath(); ctx.fill(); outline(ctx, r * 0.04);
    ctx.fillStyle = '#f4ecdc'; ell(ctx, x, y - r * 0.12, w, r * 0.26); ctx.fill(); outline(ctx, r * 0.04);
    if (!eaten) {
      ctx.fillStyle = food(ctx, x, y - r * 0.14, w * 0.85, c); ell(ctx, x, y - r * 0.1, w * 0.84, r * 0.2); ctx.fill();
      if (chunky) { ctx.fillStyle = c[1]; [[-0.35, -0.12], [0.1, -0.16], [0.3, -0.06], [-0.1, -0.02]].forEach(function (p) { ell(ctx, x + p[0] * r, y + p[1] * r, r * 0.1, r * 0.06); ctx.fill(); }); ctx.fillStyle = '#e89a3a'; ell(ctx, x - r * 0.2, y - r * 0.16, r * 0.07, r * 0.05); ctx.fill(); }
      else { ctx.strokeStyle = 'rgba(255,250,235,0.85)'; ctx.lineWidth = Math.max(1, r * 0.05); ctx.beginPath(); ctx.arc(x + r * 0.05, y - r * 0.1, r * 0.16, 0.3, 4.9); ctx.stroke(); }
      ctx.fillStyle = '#3f7a2a'; ell(ctx, x + r * 0.3, y - r * 0.16, r * 0.08, r * 0.04, 0.4); ctx.fill();
      if (hot) steam(ctx, x, y - r * 0.28, r, 3);
    } else { ctx.fillStyle = c[1]; ell(ctx, x, y - r * 0.08, w * 0.5, r * 0.08); ctx.globalAlpha = 0.5; ctx.fill(); ctx.globalAlpha = 1; }
    ctx.strokeStyle = '#8a8a8a'; ctx.lineWidth = Math.max(1, r * 0.06); ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x + r * 0.45, y - r * 0.18); ctx.lineTo(x + r * 0.78, y - r * 0.48); ctx.stroke(); ctx.lineCap = 'butt';
  }
  function drawMug(ctx, x, y, r, c, eaten) {   // a wooden tankard with iron hoops and a head of foam
    var w = r * 0.42, top = y - r * 0.55, bot = y + r * 0.3;
    ctx.fillStyle = 'rgba(0,0,0,0.3)'; ell(ctx, x + r * 0.08, bot + r * 0.04, w * 1.2, r * 0.12); ctx.fill();
    ctx.strokeStyle = '#5a3a1a'; ctx.lineWidth = r * 0.12; ctx.beginPath(); ctx.moveTo(x + w, top + r * 0.18); ctx.bezierCurveTo(x + w + r * 0.42, top + r * 0.14, x + w + r * 0.42, bot - r * 0.2, x + w, bot - r * 0.16); ctx.stroke();
    var g = ctx.createLinearGradient(x - w, 0, x + w, 0); g.addColorStop(0, '#6a4020'); g.addColorStop(0.35, '#c08a50'); g.addColorStop(1, '#5a3418');
    ctx.fillStyle = g; rr(ctx, x - w, top, w * 2, bot - top, r * 0.06); ctx.fill(); outline(ctx, r * 0.04);
    ctx.strokeStyle = 'rgba(40,20,5,0.4)'; ctx.lineWidth = 1; for (var k = 1; k < 4; k++) { ctx.beginPath(); ctx.moveTo(x - w + k * w * 0.5, top + 2); ctx.lineTo(x - w + k * w * 0.5, bot - 2); ctx.stroke(); }
    ctx.fillStyle = '#4a4a50'; ctx.fillRect(x - w, top + (bot - top) * 0.22, w * 2, r * 0.07); ctx.fillRect(x - w, top + (bot - top) * 0.74, w * 2, r * 0.07);
    if (!eaten) { ctx.fillStyle = '#fbf6ea'; ell(ctx, x, top, w * 1.08, r * 0.14); ctx.fill(); ell(ctx, x - w * 0.5, top - r * 0.08, w * 0.45, r * 0.12); ctx.fill(); ell(ctx, x + w * 0.4, top - r * 0.06, w * 0.5, r * 0.1); ctx.fill(); ctx.fillStyle = c[1]; ctx.globalAlpha = 0.5; ell(ctx, x, top + r * 0.04, w * 0.6, r * 0.04); ctx.fill(); ctx.globalAlpha = 1; }
    else { ctx.fillStyle = '#2a1a0a'; ell(ctx, x, top, w, r * 0.1); ctx.fill(); }
  }
  function drawCup(ctx, x, y, r, c, eaten, hot) {   // a cup on a saucer
    ctx.fillStyle = 'rgba(0,0,0,0.28)'; ell(ctx, x + r * 0.06, y + r * 0.2, r * 0.7, r * 0.26); ctx.fill();
    ctx.fillStyle = '#f7f2e6'; ell(ctx, x, y + r * 0.14, r * 0.66, r * 0.24); ctx.fill(); outline(ctx, r * 0.04);
    ctx.strokeStyle = '#e8e0cc'; ctx.lineWidth = r * 0.08; ctx.beginPath(); ctx.arc(x + r * 0.4, y - r * 0.06, r * 0.14, -1.4, 1.4); ctx.stroke();
    var g = ctx.createLinearGradient(x - r * 0.4, 0, x + r * 0.4, 0); g.addColorStop(0, '#d8d0bc'); g.addColorStop(0.4, '#fbf8f0'); g.addColorStop(1, '#bcb29a');
    ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(x - r * 0.4, y - r * 0.26); ctx.lineTo(x + r * 0.4, y - r * 0.26); ctx.bezierCurveTo(x + r * 0.38, y + r * 0.1, x + r * 0.2, y + r * 0.16, x, y + r * 0.16); ctx.bezierCurveTo(x - r * 0.2, y + r * 0.16, x - r * 0.38, y + r * 0.1, x - r * 0.4, y - r * 0.26); ctx.fill(); outline(ctx, r * 0.04);
    ctx.strokeStyle = '#3a6a9a'; ctx.lineWidth = Math.max(1, r * 0.05); ctx.beginPath(); ctx.moveTo(x - r * 0.36, y - r * 0.12); ctx.lineTo(x + r * 0.36, y - r * 0.12); ctx.stroke();
    ctx.fillStyle = eaten ? '#e6dcc6' : c[1]; ell(ctx, x, y - r * 0.26, r * 0.38, r * 0.1); ctx.fill(); outline(ctx, r * 0.03);
    if (!eaten && hot) steam(ctx, x, y - r * 0.36, r * 0.8, 2);
  }
  function drawGlass(ctx, x, y, r, c, eaten) {   // a stemmed glass: bowl, stem, foot, the drink, a glint
    ctx.fillStyle = 'rgba(0,0,0,0.25)'; ell(ctx, x + r * 0.06, y + r * 0.36, r * 0.32, r * 0.1); ctx.fill();
    ctx.fillStyle = 'rgba(230,240,245,0.9)'; ell(ctx, x, y + r * 0.34, r * 0.26, r * 0.08); ctx.fill(); ctx.fillRect(x - r * 0.03, y + r * 0.02, r * 0.06, r * 0.32);
    ctx.beginPath(); ctx.moveTo(x - r * 0.34, y - r * 0.6); ctx.bezierCurveTo(x - r * 0.36, y - r * 0.05, x + r * 0.36, y - r * 0.05, x + r * 0.34, y - r * 0.6); ctx.closePath(); ctx.fillStyle = 'rgba(220,235,245,0.35)'; ctx.fill(); ctx.strokeStyle = 'rgba(80,100,120,0.8)'; ctx.lineWidth = Math.max(0.8, r * 0.035); ctx.stroke();
    if (!eaten) { ctx.save(); ctx.clip(); ctx.fillStyle = food(ctx, x, y - r * 0.2, r * 0.4, c); ctx.fillRect(x - r * 0.4, y - r * 0.4, r * 0.8, r * 0.45); ctx.restore(); ctx.fillStyle = shade(c[0], 30); ell(ctx, x, y - r * 0.4, r * 0.32, r * 0.06); ctx.fill(); }
    ctx.strokeStyle = 'rgba(255,255,255,0.85)'; ctx.lineWidth = Math.max(1, r * 0.05); ctx.beginPath(); ctx.moveTo(x - r * 0.22, y - r * 0.5); ctx.quadraticCurveTo(x - r * 0.26, y - r * 0.25, x - r * 0.14, y - r * 0.14); ctx.stroke();
  }
  /** The glass outline of a bottle of one of three shapes: 0 a round flask, 1 a cone (wide foot), 2 a tall slim bottle. */
  function bottlePath(ctx, x, y, r, shape) {
    ctx.beginPath();
    if (shape === 0) { ctx.arc(x, y + r * 0.02, r * 0.38, -1.3, 4.44); ctx.lineTo(x - r * 0.1, y - r * 0.62); ctx.lineTo(x + r * 0.1, y - r * 0.62); ctx.closePath(); }
    else if (shape === 1) { ctx.moveTo(x - r * 0.09, y - r * 0.62); ctx.lineTo(x + r * 0.09, y - r * 0.62); ctx.lineTo(x + r * 0.09, y - r * 0.3); ctx.lineTo(x + r * 0.42, y + r * 0.32); ctx.quadraticCurveTo(x, y + r * 0.44, x - r * 0.42, y + r * 0.32); ctx.lineTo(x - r * 0.09, y - r * 0.3); ctx.closePath(); }
    else { ctx.moveTo(x - r * 0.08, y - r * 0.66); ctx.lineTo(x + r * 0.08, y - r * 0.66); ctx.lineTo(x + r * 0.08, y - r * 0.44); ctx.quadraticCurveTo(x + r * 0.24, y - r * 0.4, x + r * 0.24, y - r * 0.24); ctx.lineTo(x + r * 0.24, y + r * 0.34); ctx.lineTo(x - r * 0.24, y + r * 0.34); ctx.lineTo(x - r * 0.24, y - r * 0.24); ctx.quadraticCurveTo(x - r * 0.24, y - r * 0.4, x - r * 0.08, y - r * 0.44); ctx.closePath(); }
  }
  function drawBottle(ctx, x, y, r, c, eaten, shape) {   // a glass bottle (three shapes) with a cork, the drink, a paper label and a glint
    ctx.fillStyle = 'rgba(0,0,0,0.28)'; ell(ctx, x + r * 0.06, y + r * 0.36, r * 0.46, r * 0.12); ctx.fill();
    bottlePath(ctx, x, y, r, shape); ctx.fillStyle = 'rgba(225,238,245,0.4)'; ctx.fill();
    if (!eaten) { ctx.save(); bottlePath(ctx, x, y, r * 0.95, shape); ctx.clip(); ctx.fillStyle = food(ctx, x - r * 0.1, y, r * 0.4, c); ctx.fillRect(x - r * 0.45, y - r * 0.14, r * 0.9, r * 0.6); ctx.fillStyle = shade(c[0], 34); ctx.fillRect(x - r * 0.45, y - r * 0.16, r * 0.9, r * 0.04); ctx.restore(); }
    bottlePath(ctx, x, y, r, shape); ctx.strokeStyle = 'rgba(70,90,110,0.85)'; ctx.lineWidth = Math.max(0.8, r * 0.04); ctx.stroke();
    var top = shape === 2 ? -0.8 : -0.76;
    ctx.fillStyle = '#b07a44'; rr(ctx, x - r * 0.12, y + r * top, r * 0.24, r * 0.17, r * 0.04); ctx.fill(); outline(ctx, r * 0.03);
    ctx.fillStyle = '#f2e6c4'; ctx.fillRect(x - r * 0.16, y + r * 0.02, r * 0.3, r * 0.16); ctx.strokeStyle = 'rgba(80,50,20,0.6)'; ctx.lineWidth = 0.8; ctx.strokeRect(x - r * 0.16, y + r * 0.02, r * 0.3, r * 0.16);
    ctx.strokeStyle = 'rgba(255,255,255,0.85)'; ctx.lineWidth = Math.max(1, r * 0.05); ctx.beginPath(); ctx.moveTo(x - r * (shape === 2 ? 0.16 : 0.24), y - r * 0.12); ctx.lineTo(x - r * (shape === 2 ? 0.16 : 0.26), y + r * 0.14); ctx.stroke();
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Diners (and the demo's server), generated
  // ---------------------------------------------------------------------------------------------------------------

  var SKIN = ['#f6d7bc', '#eec39c', '#d9a57a', '#b67a50', '#8a5634', '#5e3a22'];
  var HAIR = ['#2a1a10', '#4a2c16', '#7a4a22', '#b07a3a', '#e0b860', '#c8c0b0', '#8a2a1a', '#1e1e2e'];
  var COATS = ['#3a5a8a', '#8a3a3a', '#3a6a4a', '#6a4a8a', '#a8742a', '#4a4a52', '#2a6a7a', '#9a5a6a', '#5a6a2a', '#7a4a2a'];
  var SHIRTS = ['#f2ead8', '#d8e4ee', '#efd8c8', '#e4e8d0'];
  var HATS = ['none', 'none', 'none', 'cap', 'brim', 'hood', 'beret', 'scarf'];
  var STYLES = ['short', 'bob', 'long', 'bun', 'tail', 'crop'];
  var EXTRAS = ['none', 'none', 'scarf', 'glasses', 'beard', 'earring'];
  /**
   * A diner's look from a seed: skin, hair colour and style, hat, coat, shirt and one extra. The same seed is always
   * the same diner. 6 x 8 x 6 x 8 x 10 x 4 x 6 = over a million combinations.
   */
  function lookFor(seed) {
    var h = hash('diner:' + seed), g = function (arr, s) { return arr[(h >>> s) % arr.length]; }, h2 = hash('d2:' + seed);
    var look = { skin: g(SKIN, 0), hair: g(HAIR, 3), style: g(STYLES, 7), hat: g(HATS, 11), coat: g(COATS, 15), shirt: SHIRTS[h2 % 4], extra: EXTRAS[(h2 >>> 3) % EXTRAS.length], hatColour: COATS[(h2 >>> 7) % COATS.length], trim: RIMS[(h2 >>> 11) % RIMS.length] };
    if (look.hat === 'hood') look.hatColour = look.coat;
    if (look.extra === 'beard' && (look.style === 'long' || look.style === 'bun' || look.style === 'tail')) look.extra = 'none';
    return look;
  }
  /** The server's look for the demo sheet: a white apron over a dark waistcoat. */
  function serverLook() { return { skin: SKIN[1], hair: HAIR[1], style: 'crop', hat: 'none', coat: '#2e2a30', shirt: '#f4efe4', extra: 'none', hatColour: '#2e2a30', trim: '#a8842a', apron: true }; }

  /**
   * One figure in one cell: MZ's own proportions (a big head over a small body), in the cell's bottom-centre, facing
   * dir (2 down, 4 left, 6 right, 8 up). pose 'seat' draws the figure seated with its hands on the table's edge;
   * 'walk0' / 'walk1' / 'walk2' draw it standing, legs apart / together / apart the other way. Cell size s (48 in MZ).
   */
  function drawFigure(ctx, ox, oy, s, look, dir, pose, noShadow) {
    var u = s / 48, cx = ox + s / 2, seat = pose === 'seat', step = pose === 'walk0' ? -1 : (pose === 'walk2' ? 1 : 0);
    var bob = seat ? 0 : (step ? -1 : 0) * u;
    var headY = oy + (seat ? 18 : 15) * u + bob, headR = 10.2 * u, bodyTop = oy + (seat ? 27 : 24) * u + bob, bodyBot = oy + (seat ? 44 : 38) * u + bob;
    var side = dir === 4 ? -1 : (dir === 6 ? 1 : 0), back = dir === 8;
    ctx.save();
    // a soft floor shadow for the standing figure; a seated one sits on its chair
    if (!seat && !noShadow) { ctx.fillStyle = 'rgba(0,0,0,0.28)'; ell(ctx, cx, oy + 46 * u, 11 * u, 3 * u); ctx.fill(); }
    // long hair and the hood fall BEHIND the body
    if (!side && (look.style === 'long' || look.hat === 'hood')) { ctx.fillStyle = look.hat === 'hood' ? shade(look.hatColour, -18) : look.hair; rr(ctx, cx - 11.5 * u, headY - 2 * u, 23 * u, (back ? 22 : 18) * u, 6 * u); ctx.fill(); }
    // legs (standing only)
    if (!seat) {
      var legC = shade(look.coat, -30);
      for (var l = -1; l <= 1; l += 2) { var sw = side ? step * l * 3 * u : 0, lx = cx + (side ? sw : l * 3.6 * u + (dir === 2 || back ? step * l * 1.2 * u : 0)), ly = oy + (38 + (side ? 0 : Math.max(0, step * l) * 1.2)) * u + bob;
        ctx.fillStyle = legC; rr(ctx, lx - 2.6 * u, ly - 2 * u, 5.2 * u, 8.6 * u, 1.6 * u); ctx.fill(); ctx.fillStyle = '#2a1a10'; rr(ctx, lx - 3 * u + side * 1 * u, ly + 5.6 * u, 6 * u + (side ? 1.5 * u : 0), 2.6 * u, 1.2 * u); ctx.fill(); }
    }
    // the body: a coat with a lit upper-left, a collar, buttons; the apron if the look has one
    var bw = side ? 14 * u : 20 * u, bx = cx - bw / 2;
    var g = ctx.createLinearGradient(bx, bodyTop, bx + bw, bodyBot); g.addColorStop(0, shade(look.coat, 30)); g.addColorStop(0.5, look.coat); g.addColorStop(1, shade(look.coat, -40));
    ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(bx + 3 * u, bodyTop); ctx.lineTo(bx + bw - 3 * u, bodyTop); ctx.quadraticCurveTo(bx + bw + 1 * u, bodyTop + 1 * u, bx + bw, bodyTop + 6 * u); ctx.lineTo(bx + bw - 1 * u, bodyBot); ctx.lineTo(bx + 1 * u, bodyBot); ctx.lineTo(bx, bodyTop + 6 * u); ctx.quadraticCurveTo(bx - 1 * u, bodyTop + 1 * u, bx + 3 * u, bodyTop); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = 'rgba(20,10,5,0.6)'; ctx.lineWidth = Math.max(1, u); ctx.stroke();
    if (!back && !side) {
      ctx.fillStyle = look.shirt; ctx.beginPath(); ctx.moveTo(cx - 4 * u, bodyTop); ctx.lineTo(cx + 4 * u, bodyTop); ctx.lineTo(cx, bodyTop + 6.5 * u); ctx.closePath(); ctx.fill();
      ctx.fillStyle = look.trim; for (var b = 0; b < 2; b++) { ell(ctx, cx, bodyTop + (8.5 + b * 3.6) * u, 0.9 * u, 0.9 * u); ctx.fill(); }
      if (look.apron) { ctx.fillStyle = '#f7f3ea'; rr(ctx, cx - 7 * u, bodyTop + 7 * u, 14 * u, bodyBot - bodyTop - 5 * u, 2 * u); ctx.fill(); ctx.strokeStyle = 'rgba(120,100,70,0.6)'; ctx.lineWidth = Math.max(0.8, 0.7 * u); ctx.stroke(); ctx.strokeStyle = '#f7f3ea'; ctx.lineWidth = 1.2 * u; ctx.beginPath(); ctx.moveTo(cx - 6 * u, bodyTop + 7 * u); ctx.lineTo(cx - 3 * u, bodyTop); ctx.moveTo(cx + 6 * u, bodyTop + 7 * u); ctx.lineTo(cx + 3 * u, bodyTop); ctx.stroke(); }
    }
    if (side && look.apron) { ctx.fillStyle = '#f7f3ea'; rr(ctx, cx + side * 1 * u - (side > 0 ? 0 : 6 * u), bodyTop + 7 * u, 6 * u, bodyBot - bodyTop - 5 * u, 1.5 * u); ctx.fill(); }
    if (look.extra === 'scarf' && !back) { ctx.fillStyle = look.hatColour; rr(ctx, cx - (side ? 5 : 7) * u, bodyTop - 1.5 * u, (side ? 10 : 14) * u, 4 * u, 2 * u); ctx.fill(); if (!side) { rr(ctx, cx + 2 * u, bodyTop + 1 * u, 3.4 * u, 8 * u, 1.4 * u); ctx.fill(); } }
    // arms: sleeves down the sides; seated hands rest forward on the table's edge
    var skin = look.skin;
    if (side) { var ax = cx + side * 2 * u; ctx.strokeStyle = shade(look.coat, -14); ctx.lineCap = 'round'; ctx.lineWidth = 5 * u; ctx.beginPath(); ctx.moveTo(ax, bodyTop + 3 * u); ctx.lineTo(ax + side * (seat ? 7 : 2 + step * side * -2) * u, bodyTop + (seat ? 11 : 10) * u); ctx.stroke(); ctx.lineCap = 'butt'; ctx.fillStyle = skin; ell(ctx, ax + side * (seat ? 8.5 : 2.5 + step * side * -2) * u, bodyTop + (seat ? 11.5 : 11.5) * u, 2.2 * u, 2.2 * u); ctx.fill(); }
    else {
      for (var a = -1; a <= 1; a += 2) { var sx = cx + a * (bw / 2 - 0.5 * u); ctx.strokeStyle = shade(look.coat, a < 0 ? -6 : -26); ctx.lineCap = 'round'; ctx.lineWidth = 5 * u; ctx.beginPath(); ctx.moveTo(sx, bodyTop + 3 * u);
        if (seat) ctx.lineTo(sx - a * 3 * u, bodyTop + 13 * u); else ctx.lineTo(sx + a * 0.8 * u, bodyTop + 11 * u - (back ? 0 : a * step * 1.2 * u)); ctx.stroke(); ctx.lineCap = 'butt';
        if (!back) { ctx.fillStyle = skin; ell(ctx, seat ? sx - a * 3.4 * u : sx + a * 0.9 * u, bodyTop + (seat ? 14.6 : 12.6) * u, 2.3 * u, 2.1 * u); ctx.fill(); } }
    }
    // the head: skin with a lit cheek, ears, face; then hair; then hat
    var hx = cx + side * 1 * u;
    var hg = ctx.createRadialGradient(hx - 3 * u, headY - 3 * u, 1, hx, headY, headR * 1.1); hg.addColorStop(0, shade(skin, 18)); hg.addColorStop(1, shade(skin, -22));
    ctx.fillStyle = hg; ell(ctx, hx, headY, headR, headR * 0.96); ctx.fill(); ctx.strokeStyle = 'rgba(60,30,15,0.55)'; ctx.lineWidth = Math.max(0.8, 0.8 * u); ctx.stroke();
    if (!back) {
      if (side) {
        ctx.fillStyle = skin; ctx.beginPath(); ctx.moveTo(hx + side * (headR - 1 * u), headY - 1 * u); ctx.lineTo(hx + side * (headR + 2 * u), headY + 2 * u); ctx.lineTo(hx + side * (headR - 0.5 * u), headY + 3 * u); ctx.fill();   // the nose
        ctx.fillStyle = '#1e140c'; rr(ctx, hx + side * 5 * u - 1 * u, headY - 1.5 * u, 2.2 * u, 3.4 * u, 1 * u); ctx.fill();
        ctx.fillStyle = 'rgba(230,110,100,0.35)'; ell(ctx, hx + side * 4.5 * u, headY + 3.2 * u, 2.2 * u, 1.3 * u); ctx.fill();
        ctx.fillStyle = shade(skin, -14); ell(ctx, hx - side * 1.5 * u, headY + 1 * u, 1.8 * u, 2.4 * u); ctx.fill();   // the ear
      } else {
        for (var e = -1; e <= 1; e += 2) { ctx.fillStyle = '#1e140c'; rr(ctx, hx + e * 4.2 * u - 1.1 * u, headY - 0.8 * u, 2.2 * u, 3.6 * u, 1 * u); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,0.8)'; ctx.fillRect(hx + e * 4.2 * u - 0.6 * u, headY - 0.4 * u, 0.8 * u, 0.9 * u); ctx.fillStyle = 'rgba(230,110,100,0.32)'; ell(ctx, hx + e * 5.6 * u, headY + 3.4 * u, 2 * u, 1.2 * u); ctx.fill(); }
        ctx.strokeStyle = 'rgba(90,40,25,0.8)'; ctx.lineWidth = Math.max(0.8, 0.8 * u); ctx.beginPath(); ctx.arc(hx, headY + 3.4 * u, 1.6 * u, 0.4, 2.7); ctx.stroke();
      }
      if (look.extra === 'glasses') { ctx.strokeStyle = '#2a2a2a'; ctx.lineWidth = Math.max(0.8, 0.8 * u); if (side) { ell(ctx, hx + side * 5.4 * u, headY + 0.8 * u, 2.4 * u, 2.2 * u); ctx.stroke(); ctx.beginPath(); ctx.moveTo(hx + side * 3 * u, headY + 0.4 * u); ctx.lineTo(hx - side * 1 * u, headY); ctx.stroke(); } else { for (var q = -1; q <= 1; q += 2) { ell(ctx, hx + q * 4.2 * u, headY + 1 * u, 2.6 * u, 2.4 * u); ctx.stroke(); } ctx.beginPath(); ctx.moveTo(hx - 1.6 * u, headY + 0.6 * u); ctx.lineTo(hx + 1.6 * u, headY + 0.6 * u); ctx.stroke(); } }
      if (look.extra === 'beard') { ctx.fillStyle = look.hair; ctx.beginPath(); if (side) { ctx.moveTo(hx - side * 2 * u, headY + 2 * u); ctx.quadraticCurveTo(hx + side * 2 * u, headY + 12 * u, hx + side * 8 * u, headY + 4.5 * u); ctx.lineTo(hx + side * 4 * u, headY + 5 * u); } else { ctx.moveTo(hx - 8 * u, headY + 1 * u); ctx.quadraticCurveTo(hx, headY + 14 * u, hx + 8 * u, headY + 1 * u); ctx.quadraticCurveTo(hx, headY + 7 * u, hx - 8 * u, headY + 1 * u); } ctx.fill(); }
      if (look.extra === 'earring' && !side) { ctx.fillStyle = '#f2cc5a'; ell(ctx, hx - 9.4 * u, headY + 3.4 * u, 1.1 * u, 1.1 * u); ctx.fill(); }
    }
    drawHair(ctx, hx, headY, headR, u, look, side, back);
    drawHat(ctx, hx, headY, headR, u, look, side, back);
    ctx.restore();
  }
  function drawHair(ctx, hx, hy, R, u, look, side, back) {
    if (look.hat === 'hood' || look.hat === 'scarf') return;
    var c = look.hair; ctx.fillStyle = c; ctx.strokeStyle = shade(c, -24); ctx.lineWidth = Math.max(0.8, 0.8 * u);
    if (back) {   // from behind the hair covers the head
      ctx.beginPath(); ctx.ellipse(hx, hy - 0.5 * u, R + 0.8 * u, R * 0.98, 0, 0, TAU); ctx.fill(); ctx.stroke();
      if (look.style === 'bun') { ell(ctx, hx, hy - R - 1 * u, 4 * u, 3.6 * u); ctx.fill(); ctx.stroke(); }
      if (look.style === 'tail') { rr(ctx, hx - 2.2 * u, hy + 4 * u, 4.4 * u, 11 * u, 2 * u); ctx.fill(); ctx.stroke(); }
      if (look.style === 'long' || look.style === 'bob') { rr(ctx, hx - R - 0.5 * u, hy - 1 * u, 2 * R + 1 * u, (look.style === 'long' ? 17 : 11) * u, 4 * u); ctx.fill(); ctx.stroke(); }
      ctx.strokeStyle = 'rgba(255,255,255,0.2)'; ctx.beginPath(); ctx.arc(hx - 2 * u, hy - 3 * u, R * 0.6, 3.6, 4.6); ctx.stroke(); return;
    }
    // the cap of hair over the crown, with a fringe cut into it
    ctx.beginPath();
    if (side) { ctx.moveTo(hx - side * (R + 1 * u), hy + (look.style === 'crop' ? 0 : 5) * u); ctx.quadraticCurveTo(hx - side * (R + 1.5 * u), hy - R - 1.5 * u, hx + side * 2 * u, hy - R - 1 * u); ctx.quadraticCurveTo(hx + side * (R + 1 * u), hy - R * 0.7, hx + side * (R - 0.5 * u), hy - 2.5 * u); ctx.lineTo(hx + side * 2 * u, hy - 3.5 * u); ctx.lineTo(hx - side * 1 * u, hy + 1 * u); ctx.lineTo(hx - side * 3 * u, hy + (look.style === 'crop' ? 0 : 6) * u); ctx.closePath(); }
    else {
      var fr = look.style === 'crop' ? -4.2 : -2.6;
      ctx.moveTo(hx - R - 0.8 * u, hy + (look.style === 'bob' || look.style === 'long' ? 7 : 1) * u); ctx.quadraticCurveTo(hx - R - 1 * u, hy - R - 2 * u, hx, hy - R - 1.4 * u); ctx.quadraticCurveTo(hx + R + 1 * u, hy - R - 2 * u, hx + R + 0.8 * u, hy + (look.style === 'bob' || look.style === 'long' ? 7 : 1) * u);
      ctx.lineTo(hx + R - 1.5 * u, hy + 0.5 * u); ctx.lineTo(hx + 5 * u, hy + fr * u); ctx.lineTo(hx + 2 * u, hy + (fr + 1.6) * u); ctx.lineTo(hx - 1.5 * u, hy + fr * u); ctx.lineTo(hx - 5 * u, hy + (fr + 1.4) * u); ctx.lineTo(hx - R + 1.5 * u, hy + 0.5 * u); ctx.closePath();
    }
    ctx.fill(); ctx.stroke();
    if (look.style === 'bun') { ell(ctx, hx - side * 3 * u, hy - R - 1.5 * u, 4 * u, 3.6 * u); ctx.fill(); ctx.stroke(); }
    if (look.style === 'tail' && side) { ctx.beginPath(); ctx.moveTo(hx - side * (R - 1 * u), hy - 3 * u); ctx.quadraticCurveTo(hx - side * (R + 6 * u), hy + 2 * u, hx - side * (R + 3 * u), hy + 10 * u); ctx.lineTo(hx - side * (R + 0.5 * u), hy + 6 * u); ctx.closePath(); ctx.fill(); ctx.stroke(); }
    if (look.style === 'long' && side) { rr(ctx, hx - side * R - (side > 0 ? 3 * u : 0), hy - 2 * u, 3.5 * u, 15 * u, 1.8 * u); ctx.fill(); }
    ctx.strokeStyle = 'rgba(255,255,255,0.28)'; ctx.lineWidth = Math.max(0.8, 1 * u); ctx.beginPath(); ctx.arc(hx - 2 * u, hy - 2 * u, R * 0.72, 3.7, 4.5); ctx.stroke();
  }
  function drawHat(ctx, hx, hy, R, u, look, side, back) {
    var c = look.hatColour, dk = shade(c, -34);
    ctx.lineWidth = Math.max(0.8, 0.8 * u); ctx.strokeStyle = shade(c, -60);
    if (look.hat === 'cap') {   // a soft flat cap: a wide, low crown pulled forward over a short peak (not a round helmet)
      if (!back) { ctx.fillStyle = dk; ctx.beginPath(); ctx.ellipse(hx + side * 5 * u, hy - R * 0.36, side ? 7 * u : R * 0.95, 2.4 * u, 0, 0, 3.1416); ctx.closePath(); ctx.fill(); ctx.stroke(); }
      ctx.fillStyle = c; ctx.beginPath(); ctx.ellipse(hx + side * 1.5 * u, hy - R * 0.62, R + 2.6 * u, R * 0.5, side * 0.12, 3.0, 6.43); ctx.quadraticCurveTo(hx, hy - R * 0.2, hx - R - 2 * u, hy - R * 0.5); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = shade(c, -46); ctx.beginPath(); ctx.moveTo(hx - 3 * u, hy - R * 1.08); ctx.quadraticCurveTo(hx + 1 * u, hy - R * 0.8, hx + 4 * u, hy - R * 0.5); ctx.stroke();
    }
    else if (look.hat === 'brim') { ctx.fillStyle = dk; ell(ctx, hx, hy - R * 0.5, R + 5 * u, 3.4 * u); ctx.fill(); ctx.stroke(); ctx.fillStyle = c; rr(ctx, hx - R * 0.7, hy - R * 1.35, R * 1.4, R * 0.9, 3 * u); ctx.fill(); ctx.stroke(); ctx.fillStyle = look.trim; ctx.fillRect(hx - R * 0.7, hy - R * 0.72, R * 1.4, 1.8 * u); }
    else if (look.hat === 'beret') { ctx.fillStyle = c; ctx.beginPath(); ctx.ellipse(hx - (side || 1) * 2 * u, hy - R * 0.72, R + 1.4 * u, R * 0.45, -0.12 * (side || 1), 0, TAU); ctx.fill(); ctx.stroke(); ctx.fillStyle = dk; ell(ctx, hx - (side || 1) * 1 * u, hy - R * 1.12, 1.2 * u, 1.6 * u); ctx.fill(); }
    else if (look.hat === 'hood') { ctx.fillStyle = c; ctx.beginPath(); if (back) ctx.ellipse(hx, hy, R + 2.2 * u, R + 1.8 * u, 0, 0, TAU); else { ctx.ellipse(hx, hy, R + 2.2 * u, R + 1.8 * u, 0, 0, TAU); ctx.ellipse(hx + side * 2 * u, hy + 1.5 * u, R * (side ? 0.72 : 0.8), R * 0.72, 0, 0, TAU, true); } ctx.fill('evenodd'); ctx.stroke(); }
    else if (look.hat === 'scarf') {   // a headscarf tied at the nape: the cloth over the crown, a band of trim, the knot's two ends
      ctx.fillStyle = c; ctx.beginPath(); ctx.ellipse(hx, hy - 1.5 * u, R + 1.4 * u, R + 0.6 * u, 0, 3.0, 6.43); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = look.trim; ctx.lineWidth = 1.4 * u; ctx.beginPath(); ctx.ellipse(hx, hy - 1.5 * u, R + 0.6 * u, R * 0.5, 0, 3.3, 6.12); ctx.stroke();
      var kx = back ? hx : hx - (side || 1) * (R + 1 * u); ctx.fillStyle = shade(c, -12); ctx.strokeStyle = shade(c, -60); ctx.lineWidth = Math.max(0.8, 0.8 * u);
      ctx.beginPath(); ctx.moveTo(kx, hy + 1 * u); ctx.lineTo(kx - (side || 1) * 3 * u, hy + 7 * u); ctx.lineTo(kx + (side ? 0 : 1) * 1 * u, hy + 6 * u); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(kx, hy + 1 * u); ctx.lineTo(kx + (side ? -side * 0.5 : 2.5) * u, hy + 8 * u); ctx.lineTo(kx + (side ? side * 1.5 : 4) * u, hy + 6.5 * u); ctx.closePath(); ctx.fill(); ctx.stroke();
    }
  }

  /**
   * A figure with a dark one-pixel outline round its whole silhouette, the way MZ's own character art is drawn.
   * ⛔ Found by looking at a live floor: a side-facing diner in a brown coat and cap on a brown chair read as a blob. The
   * outline separates any figure from any ground. Scratch canvases are made once per size and reused (a seat change
   * draws a diner; nothing here runs per frame).
   */
  var SCRATCH = {};
  function scratch(key, s) { var c = SCRATCH[key + s]; if (!c) { c = document.createElement('canvas'); c.width = s; c.height = s; SCRATCH[key + s] = c; } var x = c.getContext('2d'); x.setTransform(1, 0, 0, 1, 0, 0); x.globalCompositeOperation = 'source-over'; x.clearRect(0, 0, s, s); return c; }
  function drawFigureOutlined(ctx, ox, oy, s, look, dir, pose) {
    var u = s / 48;
    if (pose !== 'seat') { ctx.fillStyle = 'rgba(0,0,0,0.28)'; ell(ctx, ox + s / 2, oy + 46 * u, 11 * u, 3 * u); ctx.fill(); }
    var fig = scratch('f', s); drawFigure(fig.getContext('2d'), 0, 0, s, look, dir, pose, true);
    var sil = scratch('s', s), y = sil.getContext('2d'); y.drawImage(fig, 0, 0); y.globalCompositeOperation = 'source-in'; y.fillStyle = 'rgba(22,12,6,0.92)'; y.fillRect(0, 0, s, s); y.globalCompositeOperation = 'source-over';
    var k = Math.max(1, Math.round(u));
    ctx.drawImage(sil, ox - k, oy); ctx.drawImage(sil, ox + k, oy); ctx.drawImage(sil, ox, oy - k); ctx.drawImage(sil, ox, oy + k);
    ctx.drawImage(fig, ox, oy);
  }

  /**
   * A whole MZ character sheet for one character ('$' single-character layout): 3 patterns x 4 directions, rows
   * down/left/right/up. pose 'seat' repeats the seated frame across the row; otherwise walk0/walk1/walk2.
   */
  function drawSheet(ctx, look, s, seated) {
    var dirs = [2, 4, 6, 8];
    for (var r = 0; r < 4; r++) for (var p = 0; p < 3; p++) drawFigureOutlined(ctx, p * s, r * s, s, look, dirs[r], seated ? 'seat' : ['walk0', 'walk1', 'walk2'][p]);
  }

  // ---------------------------------------------------------------------------------------------------------------
  // The floor's marks: ticket, bell, candle, the pass, tags, the HUD, coins, stars, the ledger
  // ---------------------------------------------------------------------------------------------------------------

  /**
   * The order ticket pinned above a party: a paper slip with a torn foot and a red pin, the table's number, each dish
   * drawn and named in the server's hand, struck through with a tick once it has been brought. w x h (h from ticketHeight).
   */
  var TICKET_W = 120;
  function ticketHeight(n) { return 32 + 20 * Math.max(1, n); }
  function drawTicket(ctx, w, h, info) {
    ctx.clearRect(0, 0, w, h);
    var x = 3, y = 7, tw = w - 8, th = h - 11, i;
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fillRect(x + 3, y + 3, tw, th);
    ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + tw, y); ctx.lineTo(x + tw, y + th - 4);
    for (i = 0; i <= 10; i++) ctx.lineTo(x + tw - i * tw / 10, y + th - (i % 2 ? 0 : 4));   // the torn foot
    ctx.closePath();
    var g = ctx.createLinearGradient(0, y, 0, y + th); g.addColorStop(0, '#fbf5e3'); g.addColorStop(1, '#eee2c2'); ctx.fillStyle = g; ctx.fill();
    ctx.strokeStyle = 'rgba(120,90,50,0.55)'; ctx.lineWidth = 1; ctx.stroke();
    ctx.strokeStyle = 'rgba(180,60,50,0.55)'; ctx.beginPath(); ctx.moveTo(x + 5, y + 19); ctx.lineTo(x + tw - 5, y + 19); ctx.stroke();
    ctx.fillStyle = '#9a2a1e'; ctx.beginPath(); ctx.arc(x + tw - 12, y + 1, 3.6, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(60,10,5,0.7)'; ctx.lineWidth = 0.8; ctx.stroke(); ctx.fillStyle = 'rgba(255,255,255,0.65)'; ctx.beginPath(); ctx.arc(x + tw - 13, y, 1.2, 0, TAU); ctx.fill();
    ctx.fillStyle = INK; ctx.textBaseline = 'middle'; ctx.textAlign = 'left'; fitText(ctx, 'Table ' + info.table, tw - 10, 12, 'bold'); ctx.fillText('Table ' + info.table, x + 5, y + 10.5);
    var rows = info.dishes || [];
    for (i = 0; i < rows.length; i++) {
      var ry = y + 31 + i * 20;
      drawDish(ctx, x + 12, ry + 1, 8.5, rows[i].name, false, false);
      ctx.fillStyle = rows[i].done ? 'rgba(43,29,18,0.45)' : INK; fitText(ctx, rows[i].name, tw - 38, 12, '', HAND); ctx.fillText(rows[i].name, x + 24, ry);
      if (rows[i].done) { var tw2 = ctx.measureText(rows[i].name).width; ctx.strokeStyle = 'rgba(43,29,18,0.55)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x + 23, ry); ctx.lineTo(x + 25 + tw2, ry); ctx.stroke(); ctx.strokeStyle = 'rgba(40,110,50,0.95)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x + tw - 14, ry); ctx.lineTo(x + tw - 10, ry + 4); ctx.lineTo(x + tw - 3, ry - 6); ctx.stroke(); }
    }
    ctx.restore();
  }

  /** The brass service bell a waiting party wants rung for their order (the scene sways it). w x h. */
  function drawBell(ctx, w, h) {
    ctx.clearRect(0, 0, w, h);
    var cx = w / 2, by = h * 0.82;
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; ell(ctx, cx + 2, by + 3, w * 0.42, h * 0.08); ctx.fill();
    var g = ctx.createLinearGradient(cx - w * 0.4, 0, cx + w * 0.4, 0); g.addColorStop(0, '#8a5a14'); g.addColorStop(0.35, '#fbe7a4'); g.addColorStop(0.6, '#d9aa4a'); g.addColorStop(1, '#6a4410');
    ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(cx - w * 0.4, by); ctx.bezierCurveTo(cx - w * 0.36, h * 0.3, cx + w * 0.36, h * 0.3, cx + w * 0.4, by); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = 'rgba(60,35,5,0.7)'; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = '#5a3a0a'; ctx.fillRect(cx - w * 0.44, by - 1, w * 0.88, 3);
    ctx.fillStyle = '#c99a42'; ctx.beginPath(); ctx.arc(cx, h * 0.3, w * 0.07, 0, TAU); ctx.fill(); ctx.strokeStyle = '#3a2408'; ctx.stroke();
    ctx.restore();
  }

  /** A candle: the wax (drawn full height; the scene crops it as patience burns), its flame, its brass dish. */
  function drawWax(ctx, w, h) {
    ctx.clearRect(0, 0, w, h);
    var g = ctx.createLinearGradient(0, 0, w, 0); g.addColorStop(0, '#d8c9a4'); g.addColorStop(0.4, '#fbf3dc'); g.addColorStop(1, '#bca77a');
    ctx.fillStyle = g; rr(ctx, 1, 0, w - 2, h, 2); ctx.fill();
    ctx.strokeStyle = 'rgba(120,100,60,0.5)'; ctx.lineWidth = 0.8; ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.55)'; ctx.fillRect(3, 2, 1.4, h - 4);
    ctx.fillStyle = 'rgba(210,190,150,0.95)'; ell(ctx, w * 0.74, 5, 1.7, 4.6); ctx.fill();   // a drip
  }
  function drawFlame(ctx, w, h, gutter) {
    ctx.clearRect(0, 0, w, h);
    var cx = w / 2, g = ctx.createRadialGradient(cx, h * 0.62, 1, cx, h * 0.55, h * 0.55);
    if (gutter) { g.addColorStop(0, 'rgba(255,220,160,1)'); g.addColorStop(0.35, 'rgba(240,110,40,0.95)'); g.addColorStop(1, 'rgba(200,40,10,0)'); }
    else { g.addColorStop(0, 'rgba(255,250,210,1)'); g.addColorStop(0.35, 'rgba(255,200,80,0.95)'); g.addColorStop(1, 'rgba(255,120,20,0)'); }
    ctx.fillStyle = 'rgba(255,190,90,0.18)'; ell(ctx, cx, h * 0.55, w * 0.5, h * 0.5); ctx.fill();   // the halo
    ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(cx, 0); ctx.bezierCurveTo(cx + w * 0.4, h * 0.45, cx + w * 0.28, h, cx, h); ctx.bezierCurveTo(cx - w * 0.28, h, cx - w * 0.4, h * 0.45, cx, 0); ctx.fill();
    ctx.fillStyle = '#2a1a0a'; ctx.fillRect(cx - 0.5, h - 4, 1, 4);   // the wick
  }
  function drawHolder(ctx, w, h) {
    ctx.clearRect(0, 0, w, h);
    var g = ctx.createLinearGradient(0, 0, w, 0); g.addColorStop(0, '#8a5a14'); g.addColorStop(0.4, '#f2d890'); g.addColorStop(1, '#6a4410');
    ctx.fillStyle = g; ell(ctx, w / 2, h / 2, w / 2 - 1, h / 2 - 1); ctx.fill();
    ctx.strokeStyle = 'rgba(40,20,0,0.6)'; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = 'rgba(60,35,5,0.5)'; ell(ctx, w / 2, h / 2 - 1, w * 0.22, h * 0.22); ctx.fill();
  }
  /** Smoke from a snuffed candle (a party that walked out). w x h. */
  function drawPuff(ctx, w, h) {
    ctx.clearRect(0, 0, w, h);
    ctx.strokeStyle = 'rgba(220,220,225,0.75)'; ctx.lineWidth = 2; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(w / 2, h); ctx.bezierCurveTo(w * 0.2, h * 0.7, w * 0.8, h * 0.45, w * 0.45, h * 0.2); ctx.bezierCurveTo(w * 0.3, h * 0.05, w * 0.6, 0, w * 0.7, h * 0.05); ctx.stroke();
    ctx.lineCap = 'butt';
  }

  /** The pass: the dishes waiting on the kitchen's counter, steaming, each with a paper flag for its table. w x h. */
  function drawPass(ctx, w, h, ready) {
    ctx.clearRect(0, 0, w, h);
    ctx.save();
    var n = Math.min(4, ready.length), pitch = n > 1 ? Math.min(46, (w - 44) / (n - 1)) : 0, x0 = w / 2 - pitch * (n - 1) / 2;
    for (var i = 0; i < n; i++) {
      var dx = x0 + i * pitch, dy = h - 18;
      drawDish(ctx, dx, dy, 17, ready[i].name, true, false);
      ctx.strokeStyle = '#6a4a2a'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(dx + 13, dy + 2); ctx.lineTo(dx + 13, dy - 22); ctx.stroke();
      ctx.fillStyle = '#fbf5e3'; ctx.beginPath(); ctx.moveTo(dx + 13, dy - 22); ctx.lineTo(dx + 29, dy - 19); ctx.lineTo(dx + 13, dy - 14); ctx.closePath(); ctx.fill(); ctx.strokeStyle = 'rgba(120,90,50,0.7)'; ctx.lineWidth = 0.8; ctx.stroke();
      ctx.fillStyle = INK; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.font = 'bold 9px ' + FACE; ctx.fillText(String(ready[i].table), dx + 19, dy - 18.5);
    }
    if (ready.length > 4) { ctx.fillStyle = '#fbf5e3'; ctx.strokeStyle = 'rgba(20,10,5,0.8)'; ctx.lineWidth = 3; ctx.font = 'bold italic 13px ' + FACE; ctx.textAlign = 'right'; ctx.strokeText('+' + (ready.length - 4), w - 2, h - 6); ctx.fillText('+' + (ready.length - 4), w - 2, h - 6); }
    ctx.restore();
  }

  /** A little paper tag that floats up from a table: 'good' (green), 'bad' (red), 'coin' (gold) or plain. Returns its width. */
  function drawTag(ctx, w, h, text, kind) {
    ctx.clearRect(0, 0, w, h);
    ctx.save();
    ctx.font = 'bold 13px ' + FACE; var tw = Math.min(w - 8, ctx.measureText(text).width + 18), x = (w - tw) / 2, y = 3, th = h - 7;
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; rr(ctx, x + 2, y + 3, tw, th, 5); ctx.fill();
    var bg = kind === 'bad' ? ['#f6dcd4', '#9a2a1e'] : (kind === 'good' ? ['#e4f0d4', '#2e6a2a'] : (kind === 'coin' ? ['#fbeab0', '#7a5410'] : ['#fbf5e3', INK]));
    ctx.fillStyle = bg[0]; rr(ctx, x, y, tw, th, 5); ctx.fill(); ctx.strokeStyle = bg[1]; ctx.lineWidth = 1.2; ctx.stroke();
    if (kind === 'coin') { drawCoins(ctx, x + 10, y + th / 2 + 2, 2, 10, true); }
    ctx.fillStyle = bg[1]; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; fitText(ctx, text, tw - (kind === 'coin' ? 20 : 10), 13, 'bold'); ctx.fillText(text, x + tw / 2 + (kind === 'coin' ? 5 : 0), y + th / 2 + 0.5);
    ctx.restore();
    return tw;
  }

  /**
   * What the server is carrying and how the night is going: two hands (a tray each, the dish on it and its table),
   * the takings so far, and the shift's clock - a brass dial whose hand sweeps once across the shift. W x H.
   */
  function drawHud(ctx, w, h, info) {
    ctx.clearRect(0, 0, w, h);
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; rr(ctx, 3, 4, w - 4, h - 4, 10); ctx.fill();
    var g = ctx.createLinearGradient(0, 0, 0, h); g.addColorStop(0, 'rgba(46,30,18,0.94)'); g.addColorStop(1, 'rgba(24,15,8,0.94)'); ctx.fillStyle = g; rr(ctx, 0, 0, w - 4, h - 4, 10); ctx.fill();
    ctx.strokeStyle = 'rgba(201,154,66,0.85)'; ctx.lineWidth = 1.5; rr(ctx, 3, 3, w - 10, h - 10, 8); ctx.stroke();
    var cy = (h - 4) / 2;
    for (var i = 0; i < 2; i++) {
      var cx = 32 + i * 54; ctx.fillStyle = 'rgba(255,240,210,0.07)'; ell(ctx, cx, cy, 21, 21); ctx.fill(); ctx.strokeStyle = 'rgba(241,223,180,0.45)'; ctx.lineWidth = 1; ctx.stroke();
      if (info.hands[i]) { drawDish(ctx, cx, cy + 3, 15, info.hands[i].name, true, false); ctx.fillStyle = '#9a2a1e'; ell(ctx, cx + 15, cy - 14, 7.5, 7.5); ctx.fill(); ctx.fillStyle = '#fbf5e3'; ctx.font = 'bold 10px ' + FACE; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(String(info.hands[i].table), cx + 15, cy - 13.5); }
      else { ctx.fillStyle = 'rgba(241,223,180,0.4)'; ctx.font = 'italic 10px ' + FACE; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('free', cx, cy); }
    }
    var kx = w - 34, tx0 = 116, tx1 = kx - 26, tcx = (tx0 + tx1) / 2;
    ctx.fillStyle = '#f1dfb4'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; fitText(ctx, info.tips + ' ' + (info.currency || '') + ' in tips', tx1 - tx0, 14, 'bold'); ctx.fillText(info.tips + ' ' + (info.currency || '') + ' in tips', tcx, cy - 9);
    ctx.fillStyle = '#c9b48a'; fitText(ctx, info.served + ' served · ' + info.walkouts + ' walked out', tx1 - tx0, 11, 'italic'); ctx.fillText(info.served + ' served · ' + info.walkouts + ' walked out', tcx, cy + 10);
    // the clock
    var ky = cy; ctx.fillStyle = '#efe4c6'; ell(ctx, kx, ky, 20, 20); ctx.fill(); ctx.strokeStyle = '#c99a42'; ctx.lineWidth = 3; ctx.stroke();
    ctx.strokeStyle = 'rgba(43,29,18,0.5)'; ctx.lineWidth = 1; for (var t = 0; t < 12; t++) { var ta = t * TAU / 12; ctx.beginPath(); ctx.moveTo(kx + Math.cos(ta) * 15, ky + Math.sin(ta) * 15); ctx.lineTo(kx + Math.cos(ta) * 18, ky + Math.sin(ta) * 18); ctx.stroke(); }
    var p = Math.max(0, Math.min(1, info.progress)); ctx.fillStyle = p >= 1 ? 'rgba(160,40,30,0.45)' : 'rgba(180,60,40,0.3)'; ctx.beginPath(); ctx.moveTo(kx, ky); ctx.arc(kx, ky, 16, -1.5708, -1.5708 + TAU * p); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = INK; ctx.lineWidth = 2; var a = -1.5708 + TAU * p; ctx.beginPath(); ctx.moveTo(kx, ky); ctx.lineTo(kx + Math.cos(a) * 14, ky + Math.sin(a) * 14); ctx.stroke();
    ctx.fillStyle = '#c99a42'; ell(ctx, kx, ky, 2.2, 2.2); ctx.fill();
    ctx.restore();
  }

  /** A stack of n coins seen from the side, at (x, baseY), each coin w wide. */
  function drawCoins(ctx, x, baseY, n, w, gold) {
    for (var i = 0; i < n; i++) {
      var y = baseY - i * (w * 0.16), g = ctx.createLinearGradient(x - w / 2, 0, x + w / 2, 0);
      if (gold) { g.addColorStop(0, '#8a5a14'); g.addColorStop(0.45, '#fbe7a4'); g.addColorStop(1, '#8a5a14'); } else { g.addColorStop(0, '#6a4a2a'); g.addColorStop(0.45, '#e0b484'); g.addColorStop(1, '#6a4a2a'); }
      ctx.fillStyle = g; ell(ctx, x + ((i * 7) % 3 - 1), y, w / 2, w * 0.14); ctx.fill(); ctx.strokeStyle = 'rgba(40,20,0,0.55)'; ctx.lineWidth = 0.8; ctx.stroke();
    }
  }
  /** A brass star (the night's rating), filled or hollow. */
  function drawStar(ctx, x, y, r, filled) {
    ctx.beginPath(); for (var i = 0; i < 10; i++) { var a = -1.5708 + i * 0.6283, rad = i % 2 ? r * 0.45 : r; ctx.lineTo(x + Math.cos(a) * rad, y + Math.sin(a) * rad); } ctx.closePath();
    if (filled) { var g = ctx.createLinearGradient(x - r, y - r, x + r, y + r); g.addColorStop(0, '#fbe7a4'); g.addColorStop(1, '#9a6a1c'); ctx.fillStyle = g; ctx.fill(); }
    ctx.strokeStyle = filled ? '#5a3a08' : 'rgba(90,70,40,0.6)'; ctx.lineWidth = 1.5; ctx.stroke();
  }

  /**
   * The shift's ledger: a ruled page in the house book. The night's figures in the left column; takings and tips as
   * stacks of coins as tall as each other's share; every party a line in the margin (a tick served, a cross walked
   * out); the stars and the verdict. W x H (the whole screen, dimmed around the book).
   */
  function drawLedger(ctx, W, H, info) {
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = 'rgba(10,6,3,0.72)'; ctx.fillRect(0, 0, W, H);
    var w = 520, h = Math.min(H - 70, 440), x = Math.round(W / 2 - w / 2), y = Math.round((H - h) / 2) - 10;
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; rr(ctx, x + 8, y + 10, w, h, 6); ctx.fill();
    ctx.fillStyle = '#5a2a1a'; rr(ctx, x - 10, y - 8, w + 20, h + 16, 8); ctx.fill();
    ctx.strokeStyle = '#c99a42'; ctx.lineWidth = 1.2; rr(ctx, x - 6, y - 4, w + 12, h + 8, 6); ctx.stroke();
    var g = ctx.createLinearGradient(x, 0, x + w, 0); g.addColorStop(0, '#e9dcb8'); g.addColorStop(0.08, '#f7eed6'); g.addColorStop(1, '#efe3c2'); ctx.fillStyle = g; rr(ctx, x, y, w, h, 4); ctx.fill();
    ctx.strokeStyle = 'rgba(60,110,160,0.25)'; ctx.lineWidth = 1; for (var ly = y + 78; ly < y + h - 20; ly += 26) { ctx.beginPath(); ctx.moveTo(x + 18, ly); ctx.lineTo(x + w - 18, ly); ctx.stroke(); }
    ctx.strokeStyle = 'rgba(180,60,50,0.45)'; ctx.beginPath(); ctx.moveTo(x + 62, y + 58); ctx.lineTo(x + 62, y + h - 16); ctx.stroke();
    ctx.fillStyle = INK; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; fitText(ctx, info.title, w - 40, 24, 'bold'); ctx.fillText(info.title, x + w / 2, y + 28);
    ctx.font = 'italic 13px ' + FACE; ctx.fillStyle = 'rgba(43,29,18,0.7)'; ctx.fillText(info.sub, x + w / 2, y + 52);
    var rows = [['Parties served', info.served + ' of ' + info.parties], ['Dishes brought', String(info.covers)], ['Takings', info.takings + ' ' + info.currency], ['Tips', info.tips + ' ' + info.currency], ['Walked out', String(info.walkouts)], ['Longest wait', Math.round(info.longestWait / 60) + ' s'], ['Best run', info.bestStreak + ' in a row']];
    for (var i = 0; i < rows.length; i++) {
      var ry = y + 91 + i * 26; ctx.textAlign = 'left'; ctx.font = '15px ' + HAND; ctx.fillStyle = INK; ctx.fillText(rows[i][0], x + 74, ry);
      ctx.textAlign = 'right'; ctx.font = 'bold 15px ' + FACE; ctx.fillStyle = i === 4 && info.walkouts ? '#9a2a1e' : INK; ctx.fillText(rows[i][1], x + 318, ry);
    }
    // every party a mark in the margin: a tick served, a cross walked out
    var marks = info.marks || [];
    for (var m = 0; m < marks.length && m < 18; m++) { var mx = x + 22 + (m % 2) * 18, my = y + 84 + Math.floor(m / 2) * 20; ctx.lineWidth = 2; if (marks[m]) { ctx.strokeStyle = 'rgba(40,110,50,0.9)'; ctx.beginPath(); ctx.moveTo(mx - 5, my); ctx.lineTo(mx - 1, my + 4); ctx.lineTo(mx + 6, my - 6); ctx.stroke(); } else { ctx.strokeStyle = 'rgba(154,42,30,0.9)'; ctx.beginPath(); ctx.moveTo(mx - 5, my - 5); ctx.lineTo(mx + 5, my + 5); ctx.moveTo(mx + 5, my - 5); ctx.lineTo(mx - 5, my + 5); ctx.stroke(); } }
    // takings and tips as coin stacks, scaled together (tips can never look bigger than they were)
    var total = Math.max(1, info.takings), unit = Math.max(1, total / 22), baseY = y + 272;
    drawCoins(ctx, x + 388, baseY, Math.max(1, Math.round(info.takings / unit)), 36, false);
    drawCoins(ctx, x + 452, baseY, info.tips ? Math.max(1, Math.round(info.tips / unit)) : 0, 36, true);
    ctx.fillStyle = 'rgba(43,29,18,0.75)'; ctx.font = 'italic 12px ' + FACE; ctx.textAlign = 'center'; ctx.fillText('takings', x + 388, baseY + 18); ctx.fillText('tips', x + 452, baseY + 18);
    // the night's favourite, drawn: the dish most ordered, and how many times
    if (info.top) { var fy = y + 294; drawDish(ctx, x + 96, fy, 20, info.top.dish, true, false); ctx.textAlign = 'left'; ctx.fillStyle = 'rgba(43,29,18,0.7)'; ctx.font = 'italic 13px ' + FACE; ctx.fillText('The night\'s favourite', x + 126, fy - 9); ctx.fillStyle = INK; fitText(ctx, info.top.name + ' × ' + info.top.count, 200, 16, 'bold'); ctx.fillText(info.top.name + ' × ' + info.top.count, x + 126, fy + 10); }
    for (var s = 0; s < 3; s++) drawStar(ctx, x + w / 2 - 54 + s * 54, y + h - 72, 19, s < info.stars);
    ctx.fillStyle = INK; ctx.font = 'bold 20px ' + FACE; ctx.textAlign = 'center'; ctx.fillText(info.grade, x + w / 2, y + h - 34);
    ctx.font = 'italic 13px ' + FACE; ctx.fillStyle = '#e8d4a8'; ctx.fillText(info.foot, W / 2, Math.min(H - 14, y + h + 26));
    ctx.restore();
  }

  /** The opening banner: a hanging painted sign with the shift's name and the night's size. W x H. */
  function drawBanner(ctx, w, h, title, sub) {
    ctx.clearRect(0, 0, w, h);
    ctx.save();
    ctx.strokeStyle = '#3a2a1a'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(w * 0.22, 0); ctx.lineTo(w * 0.26, 16); ctx.moveTo(w * 0.78, 0); ctx.lineTo(w * 0.74, 16); ctx.stroke();
    ctx.fillStyle = 'rgba(0,0,0,0.4)'; rr(ctx, 14, 18, w - 24, h - 22, 10); ctx.fill();
    var g = ctx.createLinearGradient(0, 14, 0, h - 6); g.addColorStop(0, '#6a3a1e'); g.addColorStop(1, '#3a1e0e'); ctx.fillStyle = g; rr(ctx, 10, 14, w - 24, h - 22, 10); ctx.fill();
    ctx.strokeStyle = '#d9aa4a'; ctx.lineWidth = 2; rr(ctx, 16, 20, w - 36, h - 34, 7); ctx.stroke();
    ctx.fillStyle = '#f6e2b0'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; fitText(ctx, title, w - 70, 26, 'bold'); ctx.fillText(title, w / 2 - 2, h * 0.47);
    ctx.fillStyle = '#d9c090'; fitText(ctx, sub, w - 80, 13, 'italic'); ctx.fillText(sub, w / 2 - 2, h * 0.75);
    ctx.restore();
  }

  return {
    VERSION: '1.0.0', FACE: FACE, HAND: HAND, INK: INK, hash: hash, shade: shade,
    FORMS: FORMS, PALETTE: PALETTE, dishLook: dishLook, isDrink: isDrink, cookFrames: cookFrames, drawDish: drawDish,
    lookFor: lookFor, serverLook: serverLook, drawFigure: drawFigure, drawFigureOutlined: drawFigureOutlined, drawSheet: drawSheet,
    TICKET_W: TICKET_W, ticketHeight: ticketHeight, drawTicket: drawTicket, drawBell: drawBell, drawWax: drawWax, drawFlame: drawFlame, drawHolder: drawHolder, drawPuff: drawPuff,
    drawPass: drawPass, drawTag: drawTag, drawHud: drawHud, drawCoins: drawCoins, drawStar: drawStar, drawLedger: drawLedger, drawBanner: drawBanner,
  };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = ServiceDraw;
