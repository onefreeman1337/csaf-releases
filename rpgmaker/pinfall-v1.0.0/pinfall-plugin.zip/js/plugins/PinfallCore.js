//=============================================================================
// PinfallCore.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Pinfall core - generated pin boards, a deterministic
 * bouncing ball and a calibrated payout table. Place ABOVE PinfallDraw and Pinfall.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The board generator and ball physics for Pinfall. No parameters or commands
 * of its own; Pinfall.js is the file you configure. Must be installed and
 * listed above Pinfall.js.
 *
 * Pure logic: nothing here touches the screen and nothing uses Math.random.
 * The same board, dropped from the same spot on the same numbered ball, falls
 * the same way on every machine.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var PinfallCore = (function () {
  'use strict';

  var W = 440, H = 520;                 // play field
  var BALL_R = 7, PIN_R = 4.5, BUMP_R = 13;
  var POCKET_H = 64;                    // height of the pocket dividers
  var TOP = 70;                         // pins start below the launch rail
  var SUB = 4;                          // physics substeps per frame
  var G = 0.055;                        // gravity per substep
  var VMAX = 5.2;                       // per-substep speed clamp: never more than a pin's diameter, so no tunnelling
  // ⛔ MEASURED 2026-09-23: with E_PIN 0.52 and a 0.16 rad jitter the landing followed the AIM so closely that capping
  // the best aim spot dragged the average return to ~0.6. More bounce and more jitter spread the fall, so aim matters
  // less and the average and the best spot converge on the target.
  var E_PIN = 0.62, E_BUMP = 0.95, E_WALL = 0.6, JITTER = 0.55;
  var MAX_STEPS = 12000;                // 50 s of play: a ball that has not landed by then is placed (never observed)
  var PATTERNS = ['lattice', 'diamond', 'fan', 'waves', 'rings'];
  var THEMES = ['carnival', 'jade', 'midnight', 'ember', 'ivory'];
  var NICE = [0, 0.2, 0.3, 0.5, 0.8, 1, 1.2, 1.5, 2, 3, 5, 8, 10, 15, 25, 50];

  function hashString(s) { var h = 0x811c9dc5; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h >>> 0; }
  function rng(seed) {
    var a = seed >>> 0;
    return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function pick(r, a) { return a[Math.floor(r() * a.length) % a.length]; }

  //===========================================================================
  // Boards
  //===========================================================================

  function layPins(r, pattern) {
    var pins = [], y0 = TOP, y1 = H - POCKET_H - 26, gap = 34 + Math.floor(r() * 6);
    var rows = Math.floor((y1 - y0) / (gap * 0.87));
    for (var row = 0; row <= rows; row++) {
      var y = y0 + row * gap * 0.87;
      var t = row / Math.max(1, rows);
      var off = (row % 2) * gap / 2, half, cx = W / 2, x;
      if (pattern === 'lattice') {
        for (x = 22 + off; x <= W - 22; x += gap) pins.push({ x: x, y: y });
      } else if (pattern === 'diamond') {
        half = (W / 2 - 20) * (t < 0.5 ? 0.35 + t * 1.3 : 1.3 - (t - 0.5) * 0.9);
        for (x = cx - half + off % gap; x <= cx + half; x += gap) pins.push({ x: x, y: y });
      } else if (pattern === 'fan') {
        half = (W / 2 - 20) * (0.18 + 0.82 * t);
        for (x = cx - half + off; x <= cx + half; x += gap) pins.push({ x: x, y: y });
      } else if (pattern === 'waves') {
        var ph = r() * 6;
        for (x = 22 + off; x <= W - 22; x += gap) pins.push({ x: x, y: y + Math.sin(x / 38 + row * 0.7 + ph) * 7 });
      } else {
        var R = 40 + row * gap * 0.95;
        var n = Math.max(3, Math.round(Math.PI * R / gap));
        for (var k = 0; k <= n; k++) { var a = Math.PI * (k / n); var px = cx + Math.cos(a) * R, py = y0 - 30 + Math.sin(a) * R * 0.55 + row * 6; if (px > 18 && px < W - 18 && py > y0 - 4 && py < y1) pins.push({ x: px, y: py }); }
      }
    }
    // keep pins clear of each other AND of the side walls: a ball must always fit through every gap.
    // ⛔ MEASURED 2026-09-23: a pin at x=15.5 left an 11 px gap to the wall for a 14 px ball; 44 of 2,400 drops on
    // diamond boards wedged there forever (no nudge frees a geometric wedge). The wall gap is now >= the ball + 3 px.
    var WALL_MIN = PIN_R + 2 * BALL_R + 3;
    var out = [];
    for (var i = 0; i < pins.length; i++) {
      var p = pins[i]; if (p.x < WALL_MIN || p.x > W - WALL_MIN) continue;
      var ok = true;
      for (var j = 0; j < out.length; j++) { var dx = out[j].x - p.x, dy = out[j].y - p.y; if (dx * dx + dy * dy < Math.pow(2 * BALL_R + 2 * PIN_R + 4, 2)) { ok = false; break; } }
      if (ok) out.push({ x: Math.round(p.x * 10) / 10, y: Math.round(p.y * 10) / 10 });
    }
    return out;
  }

  /**
   * Generate a board and calibrate its payout table so that, measured over a spread of drops, it returns about
   * `rtp` of every stake. The table's SHAPE comes from the board (edge-heavy, centre jackpot or a ladder); only its
   * SCALE is solved for.
   * @param {Object} opt {seed, pockets?: 7|9|11, rtp?: 0.5..1.2, theme?, pattern?}
   */
  function generate(opt) {
    opt = opt || {};
    var seed = Number(opt.seed) >>> 0, r = rng(seed ^ 0x51F);
    var pattern = PATTERNS.indexOf(opt.pattern) >= 0 ? opt.pattern : pick(r, PATTERNS);
    var theme = THEMES.indexOf(opt.theme) >= 0 ? opt.theme : pick(r, THEMES);
    var nP = [7, 9, 11].indexOf(Number(opt.pockets)) >= 0 ? Number(opt.pockets) : pick(r, [7, 9, 11]);
    var rtp = Math.max(0.5, Math.min(1.2, Number(opt.rtp) || 0.9));
    var pins = layPins(r, pattern);
    // 2-4 jewelled bumpers: the boards read plain without them (found by looking, 2026-09-23)
    var bumpers = [], nb = 2 + Math.floor(r() * 3);
    for (var b = 0, t = 0; b < nb && t < 60; t++) {
      var bx = 60 + r() * (W - 120), by = TOP + 60 + r() * (H - POCKET_H - TOP - 140), clear = true;
      for (var i = 0; i < pins.length; i++) { var dx = pins[i].x - bx, dy = pins[i].y - by; if (dx * dx + dy * dy < Math.pow(BUMP_R + PIN_R + 2 * BALL_R + 4, 2)) { clear = false; break; } }
      for (var j = 0; j < bumpers.length; j++) { var ex = bumpers[j].x - bx, ey = bumpers[j].y - by; if (ex * ex + ey * ey < Math.pow(2 * BUMP_R + 2 * BALL_R + 6, 2)) clear = false; }
      if (clear) { bumpers.push({ x: Math.round(bx), y: Math.round(by) }); b++; }
    }
    // ⛔ MEASURED 2026-09-23 by LOOKING at a fan board: a one-sided "ladder" table plus open edge lanes let a player
    // who AIMS beat the house. Tables are symmetric only, and the launcher is limited to the pinned central band.
    var shape = pick(r, ['edges', 'centre']);
    var topRow = pins.filter(function (p) { return p.y < TOP + 20; });
    var tMin = W, tMax = 0; topRow.forEach(function (p) { tMin = Math.min(tMin, p.x); tMax = Math.max(tMax, p.x); });
    var band = W * 0.2;
    var aimMin = Math.max(W / 2 - band, topRow.length ? tMin : W / 2 - band), aimMax = Math.min(W / 2 + band, topRow.length ? tMax : W / 2 + band);
    if (aimMax - aimMin < 40) { aimMin = W / 2 - 20; aimMax = W / 2 + 20; }
    var board = { v: 1, seed: seed, pattern: pattern, theme: theme, pockets: nP, pins: pins, bumpers: bumpers, shape: shape, w: W, h: H, targetRtp: rtp,
      aimMin: Math.round(aimMin), aimMax: Math.round(aimMax) };
    calibrate(board);
    return board;
  }

  // ⛔ MEASURED 2026-09-23 (_probe/aim_truth.js, 8 bins x 400 drops): at 20 drops a bin the noise was +-21-24% of the
  // average while the TRUE aim spread was +-5% (lattice, rings) to +26% (some diamond/fan bins). Capping the max of
  // 16 noisy bins fitted the NOISE and dragged every average to ~0.6. Now: 8 bins x 60 drops, and the bound is on the
  // best bin MINUS its standard error, which is the part of the advantage that is real.
  var BINS = 8, PER_BIN = 60, AIM_SLACK = 0.08;

  /**
   * Calibrate the table against a player who AIMS. 320 drops in 16 aim bins across the launcher's range; the scale
   * is the smaller of (a) the one that makes the AVERAGE return the target and (b) the one that keeps the BEST aim
   * position within target + 8%. So no spot on the rail is a gold farm, as measured on this sample.
   */
  function calibrate(board) {
    var n = board.pockets, c = (n - 1) / 2, i, bIdx, d;
    var binHist = [];
    for (bIdx = 0; bIdx < BINS; bIdx++) { var h = []; for (i = 0; i < n; i++) h.push(0); binHist.push(h); }
    for (bIdx = 0; bIdx < BINS; bIdx++) for (d = 0; d < PER_BIN; d++) {
      var x = board.aimMin + (board.aimMax - board.aimMin) * (bIdx + (d + 0.5) / PER_BIN) / BINS;
      binHist[bIdx][run(board, x, bIdx * PER_BIN + d + 1).pocket]++;
    }
    var s = [];
    for (i = 0; i < n; i++) { var k = Math.abs(i - c) / c; s.push(board.shape === 'edges' ? 0.2 + 3 * k * k : (k === 0 ? 6 : 0.4 + 0.8 * k)); }
    var evalTable = function (mult) {
      var avg = 0, best = 0;
      for (var b2 = 0; b2 < BINS; b2++) {
        var e = 0, e2 = 0;
        for (var j = 0; j < n; j++) { var pj = binHist[b2][j] / PER_BIN; e += pj * mult[j]; e2 += pj * mult[j] * mult[j]; }
        var se = Math.sqrt(Math.max(0, e2 - e * e) / PER_BIN);
        avg += e / BINS; best = Math.max(best, e - se);
      }
      return { avg: avg, best: best };
    };
    var base = evalTable(s);
    var scale = Math.min(board.targetRtp / base.avg, (board.targetRtp + AIM_SLACK) / base.best);
    var mult = s.map(function (v) { return nice(v * scale); }), got = evalTable(mult);
    // rounding moves both numbers; step the scale down until the best aim is inside the bound (or nothing pays)
    for (var t = 0; t < 12 && got.best > board.targetRtp + AIM_SLACK; t++) { scale *= 0.93; mult = s.map(function (v) { return nice(v * scale); }); got = evalTable(mult); }
    board.multipliers = mult; board.rtp = Math.round(got.avg * 1000) / 1000; board.bestAimRtp = Math.round(got.best * 1000) / 1000;
    board.calibrationDrops = BINS * PER_BIN;
    verify(board, s, scale);
  }

  /**
   * ⛔ MEASURED 2026-09-23 (_probe/best_aim.js, 8 bins x 300 drops): one diamond board calibrated inside the bound
   * returned 1.32 at its best aim spot on FRESH balls. So every board is re-measured on a second, independent set of
   * ball numbers, and the table steps down until the verified best spot (minus its standard error) is inside the bound.
   */
  function verify(board, shape, scale) {
    var n = board.pockets, tries = 0;
    var measure = function () {
      var avg = 0, best = 0;
      for (var k = 0; k < BINS; k++) {
        var e = 0, e2 = 0;
        for (var d = 0; d < PER_BIN; d++) {
          var x = board.aimMin + (board.aimMax - board.aimMin) * (k + (d + 0.29) / PER_BIN) / BINS;
          var v = board.multipliers[run(board, x, 100000 + k * PER_BIN + d).pocket]; e += v; e2 += v * v;
        }
        var m = e / PER_BIN, se = Math.sqrt(Math.max(0, e2 / PER_BIN - m * m) / PER_BIN);
        avg += m / BINS; best = Math.max(best, m - se);
      }
      return { avg: avg, best: best };
    };
    var v = measure();
    while (v.best > board.targetRtp + AIM_SLACK && tries++ < 8) {
      scale *= 0.92;
      board.multipliers = shape.map(function (x) { return nice(x * scale); });
      v = measure();
    }
    board.verifiedRtp = Math.round(v.avg * 1000) / 1000; board.verifiedBestAim = Math.round(v.best * 1000) / 1000; board.verifySteps = tries;
    board.calibrationDrops += BINS * PER_BIN;
  }

  function nice(v) { var best = NICE[0]; for (var i = 0; i < NICE.length; i++) if (Math.abs(NICE[i] - v) < Math.abs(best - v)) best = NICE[i]; return best; }

  //===========================================================================
  // The ball. step() is the ONLY physics: the game calls it once a frame and the
  // calibration and the tests run it to the end, so all three agree by construction.
  //===========================================================================

  /** A fresh ball dropped at x. `n` is the ball's number: it seeds the bounce jitter. */
  function ball(board, x, n) {
    return { x: Math.max(BALL_R + 2, Math.min(W - BALL_R - 2, x)), y: 26, vx: 0, vy: 0, n: n >>> 0, r: rng((board.seed ^ Math.imul(n + 1, 0x9E3779B1)) >>> 0), steps: 0, slow: 0, done: false, pocket: -1, hits: 0 };
  }

  /** Advance one FRAME (SUB substeps). No allocation. @returns {boolean} true once the ball has landed */
  function step(board, b) {
    if (b.done) return true;
    var pins = board.pins, bumps = board.bumpers, n = board.pockets, pw = W / n, divTop = H - POCKET_H;
    for (var s = 0; s < SUB; s++) {
      b.vy += G;
      var sp = Math.sqrt(b.vx * b.vx + b.vy * b.vy);
      if (sp > VMAX) { b.vx *= VMAX / sp; b.vy *= VMAX / sp; }
      b.x += b.vx; b.y += b.vy; b.steps++;
      // pins and bumpers
      for (var i = 0; i < pins.length + bumps.length; i++) {
        var p = i < pins.length ? pins[i] : bumps[i - pins.length], pr = i < pins.length ? PIN_R : BUMP_R;
        var dx = b.x - p.x, dy = b.y - p.y, rr = BALL_R + pr, d2 = dx * dx + dy * dy;
        if (d2 >= rr * rr || d2 === 0) continue;
        var d = Math.sqrt(d2), nx = dx / d, ny = dy / d;
        b.x = p.x + nx * rr; b.y = p.y + ny * rr;
        var vn = b.vx * nx + b.vy * ny;
        if (vn < 0) {
          var e = i < pins.length ? E_PIN : E_BUMP;
          b.vx -= (1 + e) * vn * nx; b.vy -= (1 + e) * vn * ny;
          // seeded jitter: a pin is never perfectly round
          var j = (b.r() - 0.5) * JITTER, c = Math.cos(j), sn = Math.sin(j), vx = b.vx * c - b.vy * sn;
          b.vy = b.vx * sn + b.vy * c; b.vx = vx;
          if (i >= pins.length) { b.vx *= 1.05; b.vy *= 1.05; }
          b.hits++;
        }
      }
      // side walls
      if (b.x < BALL_R) { b.x = BALL_R; b.vx = -b.vx * E_WALL; }
      if (b.x > W - BALL_R) { b.x = W - BALL_R; b.vx = -b.vx * E_WALL; }
      // pocket dividers: thin walls at every pocket boundary below divTop
      if (b.y > divTop - BALL_R) {
        for (var k = 1; k < n; k++) {
          var wx = k * pw, ddx = b.x - wx;
          if (Math.abs(ddx) < BALL_R + 1.5) {
            if (b.y < divTop) { var cy = b.y - divTop, cd = Math.sqrt(ddx * ddx + cy * cy); if (cd < BALL_R + 1.5 && cd > 0) { b.x = wx + ddx / cd * (BALL_R + 1.5); b.y = divTop + cy / cd * (BALL_R + 1.5); var vn2 = (b.vx * ddx + b.vy * cy) / cd; if (vn2 < 0) { b.vx -= 1.5 * vn2 * ddx / cd; b.vy -= 1.5 * vn2 * cy / cd; } } }
            else { b.x = wx + (ddx >= 0 ? 1 : -1) * (BALL_R + 1.5); b.vx = -b.vx * 0.4; }
          }
        }
      }
      // anti-stall: a ball resting on a pin gets a seeded nudge, deterministically
      if (Math.abs(b.vx) + Math.abs(b.vy) < 0.05) { if (++b.slow > 40) { b.vx += (b.r() < 0.5 ? -0.6 : 0.6); b.slow = 0; } } else b.slow = 0;
      if (b.y >= H - BALL_R - 1 || b.steps >= MAX_STEPS) {
        b.y = Math.min(b.y, H - BALL_R - 1);
        b.pocket = Math.max(0, Math.min(n - 1, Math.floor(b.x / pw)));
        b.done = true; b.capped = b.steps >= MAX_STEPS;
        return true;
      }
    }
    return false;
  }

  /** Run a drop to the end. @returns {{pocket:number, steps:number, hits:number, capped:boolean}} */
  function run(board, x, n) {
    var b = ball(board, x, n); var frames = 0;
    while (!step(board, b)) frames++;
    return { pocket: b.pocket, steps: b.steps, frames: frames + 1, hits: b.hits, capped: !!b.capped };
  }

  /** @returns {number} the payout for a stake landing in a pocket */
  function payout(board, pocket, stake) { return Math.floor(stake * (board.multipliers[pocket] || 0)); }

  return {
    VERSION: '1.0.0', W: W, H: H, BALL_R: BALL_R, PIN_R: PIN_R, BUMP_R: BUMP_R, POCKET_H: POCKET_H, TOP: TOP, SUB: SUB, VMAX: VMAX,
    PATTERNS: PATTERNS, THEMES: THEMES, MAX_STEPS: MAX_STEPS,
    hashString: hashString, rng: rng, generate: generate, ball: ball, step: step, run: run, payout: payout, nice: nice,
  };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = PinfallCore;
