//=============================================================================
// Pinfall.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Pinfall - generated pachinko and plinko boards. The
 * player stakes gold, drops a ball, and it bounces down to a prize pocket.
 * Place BELOW PinfallCore and PinfallDraw.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * Pinfall
 * ============================================================================
 *
 * A tavern pin board. The player slides the launcher along the rail, stakes
 * gold and lets a steel ball fall through brass pins and jewelled bumpers into
 * a row of prize pockets, each paying a multiple of the stake.
 *
 * Every board is GENERATED from a seed: the pin pattern (lattice, diamond,
 * fan, waves or rings), the bumpers, the number of pockets and the payout
 * table. The table is CALIBRATED when the board is built, against a player
 * who AIMS: the plugin drops 960 balls across the launcher's range, in two
 * independent passes, and scales the pockets so that no spot on the rail
 * pays back more than your Payback setting plus 8%. The average across the
 * rail is lower (about 80% at the default 90%), so the house keeps an edge
 * however well the player aims. The ball's bounce is deterministic, so the
 * same board behaves the same on every machine. Nothing is loaded from an
 * image file.
 *
 * ----------------------------------------------------------------------------
 * INSTALLING
 * ----------------------------------------------------------------------------
 * Plugin Manager order, top to bottom:
 *
 *     PinfallCore.js     (the board generator and the ball physics)
 *     PinfallDraw.js     (the drawing)
 *     Pinfall.js         (this file: parameters, the command, the scene)
 *
 * ----------------------------------------------------------------------------
 * USING IT
 * ----------------------------------------------------------------------------
 * Add the plugin command "Open Board" to an event. Choose the stake per ball,
 * how many balls one visit allows (0 = until the player leaves or runs out of
 * gold), the theme, the pattern, the number of pockets and the payback. The
 * event waits while the player plays; the net winnings of the visit can be
 * stored in a variable.
 *
 * Leave the seed blank and the board is keyed to its map and event, so it is
 * the same board every visit, and the balls keep counting on from the last
 * visit rather than replaying the same drops.
 *
 * ----------------------------------------------------------------------------
 * CONTROLS
 * ----------------------------------------------------------------------------
 * Left / right move the launcher. OK drops a ball. Escape leaves.
 * Mouse and touch: click above the pins to drop from there.
 *
 * ----------------------------------------------------------------------------
 * COMPATIBILITY
 * ----------------------------------------------------------------------------
 * Pinfall adds its own scene and replaces nothing. It extends one engine
 * method (Game_System.initialize) to create its save record, calling the
 * original first. Stakes and winnings use the party's gold.
 *
 * ============================================================================
 * TERMS OF USE
 * ============================================================================
 * Commercial and non-commercial use permitted in RPG Maker projects, credit
 * appreciated but not required. Do not redistribute the source as an asset
 * pack. Every line of this plugin was written with AI assistance.
 *
 * ============================================================================
 *
 * @param dropSe
 * @text Sound: drop
 * @type file
 * @dir audio/se
 * @default Cursor3
 *
 * @param pinSe
 * @text Sound: pin (every few hits)
 * @type file
 * @dir audio/se
 * @default Cursor1
 *
 * @param winSe
 * @text Sound: a paying pocket
 * @type file
 * @dir audio/se
 * @default Coin
 *
 * @param bigWinSe
 * @text Sound: five times the stake or more
 * @type file
 * @dir audio/se
 * @default Item3
 *
 * @command open
 * @text Open Board
 * @desc Open a pin board. The event waits until the player leaves.
 *
 * @arg stake
 * @text Stake per ball (gold)
 * @type number
 * @min 1
 * @default 10
 *
 * @arg balls
 * @text Balls per visit
 * @type number
 * @min 0
 * @desc 0 = until the player leaves or cannot pay the stake.
 * @default 10
 *
 * @arg theme
 * @text Theme
 * @type select
 * @option auto
 * @option carnival
 * @option jade
 * @option midnight
 * @option ember
 * @option ivory
 * @default auto
 *
 * @arg pattern
 * @text Pin pattern
 * @type select
 * @option auto
 * @option lattice
 * @option diamond
 * @option fan
 * @option waves
 * @option rings
 * @default auto
 *
 * @arg pockets
 * @text Pockets
 * @type select
 * @option auto
 * @option 7
 * @option 9
 * @option 11
 * @default auto
 *
 * @arg payback
 * @text Payback (%)
 * @type number
 * @min 50
 * @max 120
 * @desc No spot on the rail returns more than this plus 8% of the stake; the average across the rail is lower.
 * @default 90
 *
 * @arg variableId
 * @text Variable: net winnings of the visit
 * @type variable
 * @default 0
 *
 * @arg title
 * @text Title
 * @desc Blank = named after the theme.
 * @default
 *
 * @arg seed
 * @text Seed (optional)
 * @desc Blank = keyed to this map and event.
 * @default
 */

var Pinfall = Pinfall || {};

(function (M) {
  'use strict';
  var NAME = 'Pinfall', SCHEMA = 1;
  var raw = (typeof PluginManager !== 'undefined') ? PluginManager.parameters(NAME) : {};
  function num(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; var n = Number(v); return isFinite(n) ? n : d; }
  function str(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; return String(v).trim(); }
  M.params = { dropSe: str(raw.dropSe, 'Cursor3'), pinSe: str(raw.pinSe, 'Cursor1'), winSe: str(raw.winSe, 'Coin'), bigWinSe: str(raw.bigWinSe, 'Item3') };

  var _deps = null;
  function deps() {
    if (_deps) return _deps;
    var core = (typeof PinfallCore !== 'undefined') ? PinfallCore : null, draw = (typeof PinfallDraw !== 'undefined') ? PinfallDraw : null;
    if (!core || !draw) { if (!deps._w) { deps._w = true; console.error('Pinfall: PinfallCore.js and PinfallDraw.js must both be installed and listed ABOVE Pinfall.js.'); } return null; }
    _deps = { core: core, draw: draw }; return _deps;
  }
  M.deps = deps;

  function fresh() { return { v: SCHEMA, boards: {} }; }
  function store() {
    if (typeof $gameSystem === 'undefined' || !$gameSystem) return fresh();
    var s = $gameSystem._csafPinfall; if (!s || s.v == null) { s = fresh(); $gameSystem._csafPinfall = s; }
    if (!s.boards) s.boards = {}; return s;
  }
  M.store = store;
  M.keyFor = function (mapId, eventId) { return 'm' + Number(mapId) + 'e' + Number(eventId); };
  /** @returns {{drops:number, net:number}} what has happened on a board so far */
  M.record = function (key) { var r = store().boards[String(key)]; if (!r) { r = { drops: 0, net: 0 }; store().boards[String(key)] = r; } return r; };

  var _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () { _Game_System_initialize.call(this); this._csafPinfall = fresh(); };

  var NAMES = { carnival: 'The Carnival Cascade', jade: 'The Jade Temple Board', midnight: 'The Midnight Board', ember: 'The Ember Pit', ivory: 'The Ivory Parlour' };

  M.request = function (args, key, mapId, eventId) {
    var d = deps(); if (!d) return null; args = args || {};
    var seedText = str(args.seed, '');
    var seed = seedText === '' ? d.core.hashString(key) : (/^\d+$/.test(seedText) ? (Number(seedText) >>> 0) : d.core.hashString(seedText));
    var theme = str(args.theme, 'auto'), pattern = str(args.pattern, 'auto'), pockets = str(args.pockets, 'auto');
    var board = d.core.generate({ seed: seed, theme: theme === 'auto' ? null : theme, pattern: pattern === 'auto' ? null : pattern,
      pockets: pockets === 'auto' ? null : Number(pockets), rtp: Math.max(50, Math.min(120, num(args.payback, 90))) / 100 });
    return { key: key, board: board, stake: Math.max(1, Math.floor(num(args.stake, 10))), balls: Math.max(0, Math.floor(num(args.balls, 10))),
      variableId: Math.max(0, Math.floor(num(args.variableId, 0))), title: str(args.title, NAMES[board.theme]), mapId: mapId, eventId: eventId };
  };

  M.open = function (req) { if (!req) return false; SceneManager.push(Scene_Pinfall); SceneManager.prepareNextScene(req); return true; };

  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
    PluginManager.registerCommand(NAME, 'open', function (args) {
      var mapId = this._mapId || ($gameMap ? $gameMap.mapId() : 0), eventId = this.eventId ? this.eventId() : 0;
      var seedText = str(args.seed, ''), key = seedText === '' ? M.keyFor(mapId, eventId) : 's' + seedText;
      M.open(M.request(args, key, mapId, eventId));
    });
  }
  M.VERSION = '1.0.0'; M.SCHEMA = SCHEMA;
}(Pinfall));

//=============================================================================
// Scene_Pinfall
//=============================================================================

function Scene_Pinfall() { this.initialize.apply(this, arguments); }
Scene_Pinfall.prototype = Object.create(Scene_Base.prototype);
Scene_Pinfall.prototype.constructor = Scene_Pinfall;
Scene_Pinfall.BX = 70;
Scene_Pinfall.BY = 62;
Scene_Pinfall.TRAIL = 12;

Scene_Pinfall.prototype.prepare = function (req) { this._req = req; };

Scene_Pinfall.prototype.create = function () {
  Scene_Base.prototype.create.call(this);
  var d = Pinfall.deps(); this._d = d; var b = this._req.board; this._b = b;
  this._rec = Pinfall.record(this._req.key);
  this._mode = 'aim'; this._frame = 0; this._aimX = b.w / 2; this._ball = null; this._used = 0; this._net = 0; this._last = '-'; this._lastHot = false;
  this._landWait = 0; this._hitsSeen = 0; this._statusText = ''; this._tone = '';
  this.createBoard(); this.createMoving(); this.createUi();
  this.refreshPanel(); this.setStatus('Stake ' + this._req.stake + ' gold a ball. Choose where to drop it.', '');
};
Scene_Pinfall.prototype.start = function () { Scene_Base.prototype.start.call(this); this.startFadeIn(this.fadeSpeed(), false); };

/** Everything that never moves, baked ONCE into two bitmaps. */
Scene_Pinfall.prototype.createBoard = function () {
  var d = this._d, b = this._b, T = d.draw.theme(b.theme), W = Graphics.width, H = Graphics.height, BX = Scene_Pinfall.BX, BY = Scene_Pinfall.BY;
  var hall = new Bitmap(W, H); d.draw.drawHall(hall.context, W, H); d.draw.drawCabinet(hall.context, BX, BY, b.w, b.h, T); hall._baseTexture.update();
  this.addChild(new Sprite(hall));
  var bb = new Bitmap(b.w, b.h), ctx = bb.context;
  d.draw.drawBoard(ctx, b);
  for (var i = 0; i < b.pins.length; i++) d.draw.drawPin(ctx, b.pins[i].x, b.pins[i].y, d.core.PIN_R, T);
  for (var j = 0; j < b.bumpers.length; j++) d.draw.drawBumper(ctx, b.bumpers[j].x, b.bumpers[j].y, d.core.BUMP_R, T);
  d.draw.drawPockets(ctx, b, d.core);
  bb._baseTexture.update();
  this._boardLayer = new Sprite(); this._boardLayer.x = BX; this._boardLayer.y = BY;
  this._boardLayer.addChild(new Sprite(bb));
  this.addChild(this._boardLayer);
};

Scene_Pinfall.prototype.makeDrawn = function (w, h, fn) {
  var bmp = new Bitmap(w, h), ctx = bmp.context; ctx.save(); ctx.translate(w / 2, h / 2); fn(ctx); ctx.restore(); bmp._baseTexture.update();
  var s = new Sprite(bmp); s.anchor.x = s.anchor.y = 0.5; return s;
};

Scene_Pinfall.prototype.createMoving = function () {
  var d = this._d, T = d.draw.theme(this._b.theme), R = d.core.BALL_R, L = this._boardLayer;
  this._winGlow = this.makeDrawn(120, 120, function (ctx) { d.draw.drawGlow(ctx, 58, 'rgba(255,215,120,0.75)'); }); this._winGlow.visible = false; this._winGlow.blendMode = 1; L.addChild(this._winGlow);
  this._trail = [];
  for (var i = 0; i < Scene_Pinfall.TRAIL; i++) { var t = this.makeDrawn(28, 28, function (ctx) { d.draw.drawGlow(ctx, 12, 'rgba(255,240,200,0.5)'); }); t.visible = false; t.blendMode = 1; L.addChild(t); this._trail.push(t); }
  this._trailNext = 0;
  this._ballSprite = this.makeDrawn(2 * R + 4, 2 * R + 4, function (ctx) { d.draw.drawBall(ctx, R); }); this._ballSprite.visible = false; L.addChild(this._ballSprite);
  this._launcher = this.makeDrawn(40, 30, function (ctx) { d.draw.drawLauncher(ctx, T); }); this._launcher.y = 18; L.addChild(this._launcher);
  this._aimBall = this.makeDrawn(2 * R + 4, 2 * R + 4, function (ctx) { d.draw.drawBall(ctx, R); }); this._aimBall.y = 28; L.addChild(this._aimBall);
};

Scene_Pinfall.prototype.createUi = function () {
  var d = this._d, colX = Scene_Pinfall.BX + this._b.w + 40, colW = Graphics.width - colX - 16;
  this._heading = new Sprite(new Bitmap(colW, 110)); this._heading.x = colX; this._heading.y = 20;
  var ctx = this._heading.bitmap.context, words = String(this._req.title).split(' '), lines = [], line = '';
  ctx.font = '24px ' + d.draw.FACE;
  for (var i = 0; i < words.length; i++) { var tryL = line ? line + ' ' + words[i] : words[i]; if (ctx.measureText(tryL).width > colW - 8 && line) { lines.push(line); line = words[i]; } else line = tryL; }
  lines.push(line);
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  for (var k = 0; k < lines.length && k < 3; k++) { ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillText(lines[k], colW / 2 + 1, 18 + k * 30 + 1); ctx.fillStyle = '#f6dfae'; ctx.fillText(lines[k], colW / 2, 18 + k * 30); }
  this._heading.bitmap._baseTexture.update();
  this._panel = new Sprite(new Bitmap(colW, 200)); this._panel.x = colX; this._panel.y = 140;
  // the status line lives in the right column (it sat on the cabinet's bottom edge: found by looking)
  this._status = new Sprite(new Bitmap(colW, 34)); this._status.x = colX; this._status.y = 470;
  this._statusW = colW;
  this._hint = new Sprite(new Bitmap(colW, 90)); this._hint.x = colX; this._hint.y = 360;
  var h = this._hint.bitmap.context; h.font = 'italic 13px ' + d.draw.FACE; h.fillStyle = '#b89a70'; h.textAlign = 'center';
  ['left / right  move the launcher', 'OK  drops a ball', 'Esc  leaves the table', 'no spot pays back over ' + Math.round((this._b.targetRtp + 0.08) * 100) + '%'].forEach(function (s, i) { h.fillText(s, colW / 2, 16 + i * 20); });
  this._hint.bitmap._baseTexture.update();
  this.addChild(this._heading); this.addChild(this._panel); this.addChild(this._hint); this.addChild(this._status);
};

Scene_Pinfall.prototype.purse = function () { return (typeof $gameParty !== 'undefined' && $gameParty) ? $gameParty.gold() : 0; };
Scene_Pinfall.prototype.ballsLeft = function () { return this._req.balls > 0 ? this._req.balls - this._used : Infinity; };

Scene_Pinfall.prototype.refreshPanel = function () {
  var left = this.ballsLeft();
  this._d.draw.drawPanel(this._panel.bitmap.context, this._panel.bitmap.width, 200, { purse: this.purse(), stake: this._req.stake, balls: left === Infinity ? '∞' : left, last: this._last, lastHot: this._lastHot });
  this._panel.bitmap._baseTexture.update();
};

Scene_Pinfall.prototype.setStatus = function (text, tone) {
  if (text === this._statusText && tone === this._tone) return;
  this._statusText = text; this._tone = tone || '';
  this._d.draw.drawStatus(this._status.bitmap.context, this._statusW, text, tone); this._status.bitmap._baseTexture.update();
};

Scene_Pinfall.prototype.playSe = function (n) { if (n && typeof AudioManager !== 'undefined') AudioManager.playSe({ name: n, volume: 80, pitch: 100, pan: 0 }); };

//---------------------------------------------------------------------------- per frame: numbers only

Scene_Pinfall.prototype.update = function () {
  Scene_Base.prototype.update.call(this);
  this._frame++;
  var core = this._d.core;
  if (this._mode === 'aim') this.updateAim();
  else if (this._mode === 'fall') {
    var landed = core.step(this._b, this._ball);
    this._ballSprite.x = this._ball.x; this._ballSprite.y = this._ball.y;
    if ((this._frame & 1) === 0) { var t = this._trail[this._trailNext]; t.visible = true; t.x = this._ball.x; t.y = this._ball.y; t.opacity = 200; this._trailNext = (this._trailNext + 1) % this._trail.length; }
    if (this._ball.hits - this._hitsSeen >= 3) { this._hitsSeen = this._ball.hits; this.playSe(Pinfall.params.pinSe); }
    if (landed) this.land();
  } else if (this._mode === 'land') {
    if (--this._landWait <= 0) this.afterLand();
  } else if (this._mode === 'done') {
    if (--this._landWait <= 0 && !this.isBusy()) { this._mode = 'leaving'; this.finish(); this.popScene(); }
  }
  for (var i = 0; i < this._trail.length; i++) { var s = this._trail[i]; if (s.visible) { s.opacity -= 14; if (s.opacity <= 0) s.visible = false; } }
  if (this._winGlow.visible) { var k = 1 + 0.12 * Math.sin(this._frame * 0.3); this._winGlow.scale.x = this._winGlow.scale.y = k; }
  this._launcher.x = this._aimX; this._aimBall.x = this._aimX; this._aimBall.visible = this._mode === 'aim';
};

Scene_Pinfall.prototype.updateAim = function () {
  var b = this._b;
  // the launcher travels only the band the table was calibrated for (PinfallCore: no aim spot is a gold farm)
  if (Input.isPressed('left')) this._aimX = Math.max(b.aimMin, this._aimX - 3);
  if (Input.isPressed('right')) this._aimX = Math.min(b.aimMax, this._aimX + 3);
  if (TouchInput.isTriggered()) {
    var x = TouchInput.x - Scene_Pinfall.BX, y = TouchInput.y - Scene_Pinfall.BY;
    if (x >= 0 && x <= b.w && y >= -40 && y <= this._d.core.TOP) { this._aimX = Math.max(b.aimMin, Math.min(b.aimMax, x)); this.drop(); return; }
  }
  if (Input.isTriggered('ok')) this.drop();
  else if (Input.isTriggered('cancel') || TouchInput.isCancelled()) this.leave();
};

Scene_Pinfall.prototype.drop = function () {
  if (this.ballsLeft() <= 0) return this.leave();
  if (this.purse() < this._req.stake) { this.setStatus('Not enough gold for the stake.', 'bad'); return; }
  this._aimX = Math.max(this._b.aimMin, Math.min(this._b.aimMax, this._aimX));
  if (typeof $gameParty !== 'undefined' && $gameParty) $gameParty.loseGold(this._req.stake);
  this._used++; this._net -= this._req.stake;
  this._rec.drops++;
  this._ball = this._d.core.ball(this._b, this._aimX, this._rec.drops);
  this._hitsSeen = 0; this._ballSprite.visible = true; this._ballSprite.x = this._ball.x; this._ballSprite.y = this._ball.y;
  this._winGlow.visible = false; this._mode = 'fall';
  this.playSe(Pinfall.params.dropSe); this.refreshPanel(); this.setStatus('The ball falls...', '');
};

Scene_Pinfall.prototype.land = function () {
  var b = this._b, p = this._ball.pocket, m = b.multipliers[p], win = this._d.core.payout(b, p, this._req.stake);
  if (win > 0 && typeof $gameParty !== 'undefined' && $gameParty) $gameParty.gainGold(win);
  this._net += win; this._rec.net += win - this._req.stake;
  this._last = win; this._lastHot = m >= 5;
  var pw = b.w / b.pockets;
  this._winGlow.x = (p + 0.5) * pw; this._winGlow.y = b.h - this._d.core.POCKET_H / 2; this._winGlow.visible = win > 0;
  if (m >= 5) { this.playSe(Pinfall.params.bigWinSe); this.setStatus(m + ' times the stake! ' + win + ' gold.', 'good'); }
  else if (win > 0) { this.playSe(Pinfall.params.winSe); this.setStatus('It pays ' + win + ' gold.', 'good'); }
  else this.setStatus('Nothing this time.', '');
  this.refreshPanel(); this._mode = 'land'; this._landWait = 45;
};

Scene_Pinfall.prototype.afterLand = function () {
  this._ballSprite.visible = false;
  if (this.ballsLeft() <= 0) { this.setStatus('That was the last ball. ' + (this._net >= 0 ? 'Up ' : 'Down ') + Math.abs(this._net) + ' gold.', this._net >= 0 ? 'good' : ''); this._mode = 'done'; this._landWait = 90; return; }
  this._mode = 'aim';
};

Scene_Pinfall.prototype.finish = function () { if (this._req.variableId > 0 && typeof $gameVariables !== 'undefined') $gameVariables.setValue(this._req.variableId, this._net); };
Scene_Pinfall.prototype.leave = function () { this.setStatus('You leave the table ' + (this._net >= 0 ? 'up ' : 'down ') + Math.abs(this._net) + ' gold.', ''); this._mode = 'done'; this._landWait = 30; };
