//=============================================================================
// PinfallDraw.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Pinfall draw - the cabinet, the enamel board, brass pins,
 * jewelled bumpers and the prize pockets, all drawn in code. Place BETWEEN
 * PinfallCore and Pinfall.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * Every picture Pinfall shows is drawn here onto a canvas: no image file is
 * loaded. No parameters of its own. Must be installed below PinfallCore.js
 * and above Pinfall.js.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var PinfallDraw = (function () {
  'use strict';
  var TAU = Math.PI * 2;
  var FACE = '"Palatino Linotype", "Book Antiqua", Palatino, "Georgia", serif';

  /** Board themes: enamel ground (top, bottom), filigree, pin metal (hi, lo), bumper jewel, pocket ink. */
  var THEMES = {
    carnival: { top: '#7a1024', bot: '#3a0510', fil: '#f0c35a', pinHi: '#fff1c2', pinLo: '#9c6a1c', jewel: '#35d07a', ink: '#ffe7a6', wood: ['#5a2412', '#2a0e06'] },
    jade: { top: '#0f5a45', bot: '#052a20', fil: '#e6cf7a', pinHi: '#fff6d4', pinLo: '#a07a25', jewel: '#ff4d6d', ink: '#fdf0c4', wood: ['#3b2a18', '#1a1008'] },
    midnight: { top: '#15235a', bot: '#070b24', fil: '#c9d6ff', pinHi: '#ffffff', pinLo: '#7d8aa6', jewel: '#ffcf3f', ink: '#e8eeff', wood: ['#2b2230', '#0f0b12'] },
    ember: { top: '#3a1a0c', bot: '#120603', fil: '#ff9a3d', pinHi: '#ffe0b8', pinLo: '#8a4a1c', jewel: '#5cc8ff', ink: '#ffd7a8', wood: ['#241611', '#0b0604'] },
    ivory: { top: '#efe4cc', bot: '#cdbb95', fil: '#7a5520', pinHi: '#fff6dc', pinLo: '#8f6a2c', jewel: '#2b6fd6', ink: '#4a3313', wood: ['#6b4a2e', '#3a2616'] },
  };
  function theme(n) { return THEMES[n] || THEMES.carnival; }
  function rng(seed) { var a = seed >>> 0; return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function rr(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r); ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h); ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r); ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.closePath(); }

  /** The hall behind the cabinet. */
  function drawHall(ctx, W, H) {
    var g = ctx.createRadialGradient(W / 2, H * 0.4, 30, W / 2, H / 2, W * 0.8);
    g.addColorStop(0, '#3a2418'); g.addColorStop(0.6, '#1a0f09'); g.addColorStop(1, '#060303');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    var r = rng(0xBA11);
    for (var i = 0; i < 1400; i++) { ctx.fillStyle = r() < 0.5 ? 'rgba(255,220,170,0.03)' : 'rgba(0,0,0,0.12)'; ctx.fillRect(r() * W, r() * H, 1 + r() * 3, 1); }
  }

  /** The cabinet: a lacquered wooden case with brass corners, around the board at (x, y). */
  function drawCabinet(ctx, x, y, w, h, T) {
    ctx.fillStyle = 'rgba(0,0,0,0.55)'; rr(ctx, x - 22, y - 50, w + 52, h + 88, 18); ctx.fill();
    var g = ctx.createLinearGradient(x - 26, 0, x + w + 26, 0); g.addColorStop(0, T.wood[1]); g.addColorStop(0.5, T.wood[0]); g.addColorStop(1, T.wood[1]);
    ctx.fillStyle = g; rr(ctx, x - 26, y - 56, w + 52, h + 88, 18); ctx.fill();
    ctx.strokeStyle = 'rgba(255,220,160,0.25)'; ctx.lineWidth = 1.2; rr(ctx, x - 20, y - 50, w + 40, h + 76, 14); ctx.stroke();
    // brass corner plates
    [[x - 26, y - 56], [x + w + 26, y - 56], [x - 26, y + h + 32], [x + w + 26, y + h + 32]].forEach(function (p, i) {
      ctx.save(); ctx.translate(p[0], p[1]); ctx.rotate(i * Math.PI / 2);
      var bg = ctx.createLinearGradient(0, 0, 24, 24); bg.addColorStop(0, '#f6d98a'); bg.addColorStop(1, '#8a6120');
      ctx.fillStyle = bg; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(26, 0); ctx.quadraticCurveTo(10, 10, 0, 26); ctx.closePath(); ctx.fill(); ctx.restore();
    });
  }

  /** The enamel board: gradient ground, a filigree border and a sunburst behind the pins. */
  function drawBoard(ctx, board) {
    var T = theme(board.theme), W = board.w, H = board.h, r = rng((board.seed ^ 0xF1) >>> 0);
    var g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, T.top); g.addColorStop(1, T.bot);
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    // sunburst rays from the launch rail
    ctx.save(); ctx.globalAlpha = 0.08; ctx.fillStyle = T.fil;
    for (var i = 0; i < 24; i++) { var a0 = Math.PI * (i / 24), a1 = a0 + Math.PI / 48; ctx.beginPath(); ctx.moveTo(W / 2, -40); ctx.lineTo(W / 2 + Math.cos(a0) * 900, -40 + Math.sin(a0) * 900); ctx.lineTo(W / 2 + Math.cos(a1) * 900, -40 + Math.sin(a1) * 900); ctx.closePath(); ctx.fill(); }
    ctx.restore();
    // filigree: scrolled vines up both sides
    ctx.strokeStyle = T.fil; ctx.globalAlpha = 0.35; ctx.lineWidth = 1.2;
    for (var side = 0; side < 2; side++) {
      var sx = side ? W - 6 : 6, dir = side ? -1 : 1;
      ctx.beginPath(); ctx.moveTo(sx, 20);
      for (var y = 20; y < H - 80; y += 40) { ctx.quadraticCurveTo(sx + dir * 5, y + 10, sx, y + 20); ctx.quadraticCurveTo(sx - dir * 1, y + 30, sx, y + 40); }
      ctx.stroke();
      for (var y2 = 40; y2 < H - 90; y2 += 40) { ctx.beginPath(); ctx.arc(sx + dir * 4, y2, 3, 0, TAU); ctx.stroke(); }
    }
    ctx.globalAlpha = 1;
    drawMotif(ctx, board.theme, W, H, T, r);
    ctx.strokeStyle = T.fil; ctx.lineWidth = 2; ctx.strokeRect(1, 1, W - 2, H - 2);
    // the launch rail
    var rail = ctx.createLinearGradient(0, 8, 0, 20); rail.addColorStop(0, T.pinHi); rail.addColorStop(1, T.pinLo);
    ctx.fillStyle = rail; ctx.fillRect(10, 12, W - 20, 5);
  }

  /**
   * The painted motif behind the pins, one per theme. ⛔ Added 2026-09-23 after LOOKING: beside Escapement and
   * Strata the first boards read clean but plain (gradient enamel, brass pins). Each theme now carries its own
   * picture: a star medallion (carnival), cloud scrolls (jade), a moon and starfield (midnight), flame tongues
   * (ember), a damask lattice (ivory). Drawn once into the static board bitmap.
   */
  function drawMotif(ctx, name, W, H, T, r) {
    var cx = W / 2, cy = H * 0.42, i;
    ctx.save();
    if (name === 'carnival') {
      ctx.globalAlpha = 0.18; ctx.fillStyle = T.fil;
      ctx.beginPath(); for (i = 0; i < 16; i++) { var a = i / 16 * TAU, rr0 = i % 2 ? 70 : 150; ctx.lineTo(cx + Math.cos(a) * rr0, cy + Math.sin(a) * rr0); } ctx.closePath(); ctx.fill();
      ctx.globalAlpha = 0.28; ctx.strokeStyle = T.fil; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(cx, cy, 60, 0, TAU); ctx.stroke(); ctx.beginPath(); ctx.arc(cx, cy, 44, 0, TAU); ctx.stroke();
      for (i = 0; i < 26; i++) { ctx.fillStyle = i % 2 ? T.fil : '#ffffff'; ctx.globalAlpha = 0.35; var la = i / 26 * TAU; ctx.beginPath(); ctx.arc(cx + Math.cos(la) * 190, cy + Math.sin(la) * 190, 3, 0, TAU); ctx.fill(); }
    } else if (name === 'jade') {
      ctx.globalAlpha = 0.2; ctx.strokeStyle = T.fil; ctx.lineWidth = 2;
      for (i = 0; i < 9; i++) {
        var x0 = 40 + (i % 3) * 150 + r() * 20, y0 = 90 + Math.floor(i / 3) * 120 + r() * 20;
        ctx.beginPath(); for (var t = 0; t < 3 * TAU; t += 0.2) { var rr1 = 4 + t * 3.2; ctx.lineTo(x0 + Math.cos(t) * rr1, y0 + Math.sin(t) * rr1 * 0.7); } ctx.stroke();
        ctx.beginPath(); ctx.moveTo(x0 + 30, y0 + 6); ctx.bezierCurveTo(x0 + 60, y0 - 16, x0 + 90, y0 + 20, x0 + 120, y0); ctx.stroke();
      }
    } else if (name === 'midnight') {
      for (i = 0; i < 90; i++) { ctx.globalAlpha = 0.2 + r() * 0.6; ctx.fillStyle = '#ffffff'; ctx.fillRect(r() * W, 30 + r() * (H - 120), r() < 0.1 ? 2 : 1, r() < 0.1 ? 2 : 1); }
      ctx.globalAlpha = 0.5; var mg = ctx.createRadialGradient(W * 0.72, 120, 2, W * 0.72, 120, 46); mg.addColorStop(0, '#fffbe6'); mg.addColorStop(0.6, '#d9e2ff'); mg.addColorStop(1, 'rgba(200,210,255,0)');
      ctx.fillStyle = mg; ctx.beginPath(); ctx.arc(W * 0.72, 120, 46, 0, TAU); ctx.fill();
      ctx.globalAlpha = 0.9; ctx.fillStyle = T.top; ctx.beginPath(); ctx.arc(W * 0.72 + 12, 112, 24, 0, TAU); ctx.fill();
    } else if (name === 'ember') {
      for (i = 0; i < 14; i++) {
        var fx = 20 + i * (W - 40) / 13, fh = 90 + r() * 140;
        var fg = ctx.createLinearGradient(0, H - 70, 0, H - 70 - fh); fg.addColorStop(0, 'rgba(255,120,30,0.28)'); fg.addColorStop(1, 'rgba(255,200,80,0)');
        ctx.fillStyle = fg; ctx.beginPath(); ctx.moveTo(fx - 18, H - 70); ctx.quadraticCurveTo(fx - 22, H - 70 - fh * 0.5, fx + (r() - 0.5) * 16, H - 70 - fh); ctx.quadraticCurveTo(fx + 20, H - 70 - fh * 0.5, fx + 18, H - 70); ctx.closePath(); ctx.fill();
      }
    } else {
      ctx.globalAlpha = 0.16; ctx.strokeStyle = T.fil; ctx.lineWidth = 1.2;
      for (var dy = 40; dy < H - 80; dy += 56) for (var dx = 30; dx < W; dx += 56) {
        var ox = dx + ((dy / 56) % 2) * 28;
        ctx.beginPath(); ctx.moveTo(ox, dy - 18); ctx.quadraticCurveTo(ox + 14, dy, ox, dy + 18); ctx.quadraticCurveTo(ox - 14, dy, ox, dy - 18); ctx.stroke();
        ctx.beginPath(); ctx.arc(ox, dy, 3, 0, TAU); ctx.stroke();
      }
    }
    ctx.restore();
  }

  /** A brass pin, drawn at (x, y) on the board bitmap (static: pins never move). */
  function drawPin(ctx, x, y, R, T) {
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.beginPath(); ctx.arc(x + 1.5, y + 2, R + 0.5, 0, TAU); ctx.fill();
    var g = ctx.createRadialGradient(x - R * 0.35, y - R * 0.4, 0.5, x, y, R);
    g.addColorStop(0, T.pinHi); g.addColorStop(0.55, T.pinLo); g.addColorStop(1, '#2a1a08');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, R, 0, TAU); ctx.fill();
  }

  /** A jewelled bumper: a brass ring round a faceted stone. */
  function drawBumper(ctx, x, y, R, T) {
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.beginPath(); ctx.arc(x + 2, y + 3, R + 1, 0, TAU); ctx.fill();
    var ring = ctx.createRadialGradient(x - R * 0.4, y - R * 0.4, 1, x, y, R);
    ring.addColorStop(0, T.pinHi); ring.addColorStop(1, T.pinLo);
    ctx.fillStyle = ring; ctx.beginPath(); ctx.arc(x, y, R, 0, TAU); ctx.fill();
    var jr = R * 0.62;
    var j = ctx.createRadialGradient(x - jr * 0.3, y - jr * 0.35, 0.5, x, y, jr);
    j.addColorStop(0, '#ffffff'); j.addColorStop(0.3, T.jewel); j.addColorStop(1, '#05070a');
    ctx.fillStyle = j; ctx.beginPath();
    for (var k = 0; k < 8; k++) { var a = k / 8 * TAU; ctx.lineTo(x + Math.cos(a) * jr, y + Math.sin(a) * jr); }
    ctx.closePath(); ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 0.8; ctx.stroke();
  }

  /** The pockets: dividers with capped tops, each pocket's multiplier set in the chosen face. */
  function drawPockets(ctx, board, core) {
    var T = theme(board.theme), W = board.w, H = board.h, n = board.pockets, pw = W / n, top = H - core.POCKET_H;
    for (var i = 0; i < n; i++) {
      var m = board.multipliers[i], hot = m >= 5, x = i * pw;
      var g = ctx.createLinearGradient(0, top, 0, H); g.addColorStop(0, 'rgba(0,0,0,0.15)'); g.addColorStop(1, hot ? 'rgba(255,200,80,0.35)' : 'rgba(0,0,0,0.45)');
      ctx.fillStyle = g; ctx.fillRect(x + 2, top + 4, pw - 4, core.POCKET_H - 6);
      ctx.font = (hot ? 'bold ' : '') + (n > 9 ? 13 : 15) + 'px ' + FACE; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      var label = m === 0 ? '0' : (m < 1 ? String(m).replace(/^0/, '') : String(m)) + '×';
      ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillText(label, x + pw / 2 + 1, H - 18 + 1);
      ctx.fillStyle = hot ? '#ffe7a0' : T.ink; ctx.fillText(label, x + pw / 2, H - 18);
    }
    // arched gilt crowns over every pocket, so the row reads as a carved prize rail
    for (var a2 = 0; a2 < n; a2++) {
      var ax = a2 * pw;
      ctx.strokeStyle = T.fil; ctx.lineWidth = 1.6; ctx.globalAlpha = 0.85;
      ctx.beginPath(); ctx.moveTo(ax + 3, top + 14); ctx.quadraticCurveTo(ax + pw / 2, top - 2, ax + pw - 3, top + 14); ctx.stroke();
      ctx.globalAlpha = 1; ctx.fillStyle = T.fil; ctx.beginPath(); ctx.arc(ax + pw / 2, top + 5, 2.2, 0, TAU); ctx.fill();
    }
    for (var k = 1; k < n; k++) {
      var dx = k * pw;
      var dg = ctx.createLinearGradient(dx - 2, 0, dx + 2, 0); dg.addColorStop(0, T.pinLo); dg.addColorStop(0.5, T.pinHi); dg.addColorStop(1, T.pinLo);
      ctx.fillStyle = dg; ctx.fillRect(dx - 1.5, top, 3, core.POCKET_H);
      drawPin(ctx, dx, top, 3, T);
    }
  }

  /** The ball: a polished steel sphere with a sharp highlight, drawn at the origin. */
  function drawBall(ctx, R) {
    var g = ctx.createRadialGradient(-R * 0.35, -R * 0.4, 0.5, 0, 0, R);
    g.addColorStop(0, '#ffffff'); g.addColorStop(0.35, '#d7dde6'); g.addColorStop(0.8, '#6b7482'); g.addColorStop(1, '#262a31');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, R, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.9)'; ctx.beginPath(); ctx.arc(-R * 0.38, -R * 0.42, R * 0.22, 0, TAU); ctx.fill();
  }

  /** A soft glow for the ball's trail and the winning pocket. */
  function drawGlow(ctx, R, colour) {
    var g = ctx.createRadialGradient(0, 0, 0, 0, 0, R); g.addColorStop(0, colour); g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, R, 0, TAU); ctx.fill();
  }

  /** The launcher: a brass carriage on the rail with a drop chute. */
  function drawLauncher(ctx, T) {
    var g = ctx.createLinearGradient(-16, 0, 16, 0); g.addColorStop(0, T.pinLo); g.addColorStop(0.5, T.pinHi); g.addColorStop(1, T.pinLo);
    ctx.fillStyle = g; rr(ctx, -16, -10, 32, 14, 4); ctx.fill();
    ctx.fillStyle = '#1a1208'; ctx.fillRect(-5, 2, 10, 8);
    ctx.fillStyle = T.jewel; ctx.beginPath(); ctx.arc(0, -3, 3, 0, TAU); ctx.fill();
  }

  function drawHeading(ctx, W, title, sub) {
    ctx.clearRect(0, 0, W, 60);
    ctx.font = '30px ' + FACE; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillText(title, W / 2 + 1, 25);
    var g = ctx.createLinearGradient(0, 8, 0, 42); g.addColorStop(0, '#fff0c8'); g.addColorStop(1, '#d19b45');
    ctx.fillStyle = g; ctx.fillText(title, W / 2, 24);
    ctx.font = 'italic 13px ' + FACE; ctx.fillStyle = '#c0a06c'; ctx.fillText(sub, W / 2, 49);
  }

  /** The side panel: purse, stake, balls, last win. */
  function drawPanel(ctx, w, h, info) {
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; rr(ctx, 0, 0, w, h, 10); ctx.fill();
    ctx.strokeStyle = 'rgba(240,200,120,0.4)'; ctx.lineWidth = 1.2; rr(ctx, 0.5, 0.5, w - 1, h - 1, 10); ctx.stroke();
    var rows = [['Purse', info.purse], ['Stake', info.stake], ['Balls', info.balls], ['Last', info.last]];
    ctx.textBaseline = 'middle';
    for (var i = 0; i < rows.length; i++) {
      var y = 26 + i * 48;
      ctx.font = 'italic 14px ' + FACE; ctx.textAlign = 'left'; ctx.fillStyle = '#c0a06c'; ctx.fillText(rows[i][0], 14, y);
      ctx.font = '22px ' + FACE; ctx.textAlign = 'right'; ctx.fillStyle = i === 3 && info.lastHot ? '#ffe39a' : '#f6e6c4'; ctx.fillText(String(rows[i][1]), w - 14, y + 18);
    }
  }

  function drawStatus(ctx, W, text, tone) {
    ctx.clearRect(0, 0, W, 34);
    // shrink to fit the column rather than run off it
    var size = 17; ctx.font = 'italic ' + size + 'px ' + FACE;
    while (size > 11 && ctx.measureText(text).width > W - 8) { size--; ctx.font = 'italic ' + size + 'px ' + FACE; }
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillText(text, W / 2 + 1, 18);
    ctx.fillStyle = tone === 'bad' ? '#ff9c86' : tone === 'good' ? '#c8f5a6' : '#f1dfb4'; ctx.fillText(text, W / 2, 17);
  }

  return { VERSION: '1.0.0', FACE: FACE, THEMES: THEMES, theme: theme, drawHall: drawHall, drawCabinet: drawCabinet, drawBoard: drawBoard, drawPin: drawPin,
    drawBumper: drawBumper, drawPockets: drawPockets, drawBall: drawBall, drawGlow: drawGlow, drawLauncher: drawLauncher, drawHeading: drawHeading,
    drawPanel: drawPanel, drawStatus: drawStatus };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = PinfallDraw;
