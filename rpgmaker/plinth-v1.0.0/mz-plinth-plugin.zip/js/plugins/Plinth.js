/*:
 * @target MZ
 * @plugindesc Plinth 2/2 - statues of your own cast and monsters on the map, live petrification, and stone battlers.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @param material
 * @text Default material
 * @desc The material used when a note or command does not name one.
 * @type select
 * @option granite
 * @option marble
 * @option sandstone
 * @option bronze
 * @option gilt
 * @option obsidian
 * @option ice
 * @default granite
 *
 * @param age
 * @text Default age
 * @desc Weathering, 0 (fresh) to 100 (old): lichen, rain streaks, moss. Used when a note or command does not set one.
 * @type number
 * @min 0
 * @max 100
 * @default 0
 *
 * @param petrifyFrames
 * @text Petrify time
 * @desc Frames the stone takes to climb a character (60 = one second), when the command does not set one.
 * @type number
 * @min 1
 * @max 600
 * @default 90
 *
 * @param blankEyes
 * @text Blank the eyes
 * @desc A statue has no eyes: blank them when a face is found. When no face is found, nothing is blanked.
 * @type boolean
 * @default true
 *
 * @param showBase
 * @text Statue bases
 * @desc Stand every statue event on a drawn base in its own material.
 * @type boolean
 * @default true
 *
 * @param carveNames
 * @text Carve names
 * @desc Cut the actor's or enemy's name into the base (a note's name overrides it).
 * @type boolean
 * @default true
 *
 * @command petrify
 * @text Petrify
 * @desc Stone climbs a character from the feet. It stays stone (and cannot move) until Restore.
 *
 * @arg target
 * @text Target
 * @type select
 * @option Player
 * @value player
 * @option Follower
 * @value follower
 * @option This event
 * @value this
 * @option Event by ID
 * @value event
 * @default this
 *
 * @arg followerIndex
 * @text Follower (1 = first)
 * @type number
 * @min 1
 * @default 1
 *
 * @arg eventId
 * @text Event ID
 * @type number
 * @min 0
 * @default 0
 *
 * @arg material
 * @text Material
 * @desc Blank = the Default material parameter.
 * @type select
 * @option (default)
 * @value
 * @option granite
 * @option marble
 * @option sandstone
 * @option bronze
 * @option gilt
 * @option obsidian
 * @option ice
 * @default
 *
 * @arg age
 * @text Age
 * @desc 0 to 100. Blank = the Default age parameter.
 * @type string
 * @default
 *
 * @arg frames
 * @text Frames
 * @desc Blank = the Petrify time parameter.
 * @type string
 * @default
 *
 * @arg wait
 * @text Wait for completion
 * @type boolean
 * @default false
 *
 * @command restore
 * @text Restore
 * @desc The stone falls away, from the crown down, and the character can move again.
 *
 * @arg target
 * @text Target
 * @type select
 * @option Player
 * @value player
 * @option Follower
 * @value follower
 * @option This event
 * @value this
 * @option Event by ID
 * @value event
 * @default this
 *
 * @arg followerIndex
 * @text Follower (1 = first)
 * @type number
 * @min 1
 * @default 1
 *
 * @arg eventId
 * @text Event ID
 * @type number
 * @min 0
 * @default 0
 *
 * @arg frames
 * @text Frames
 * @desc Blank = the Petrify time parameter.
 * @type string
 * @default
 *
 * @arg wait
 * @text Wait for completion
 * @type boolean
 * @default false
 *
 * @help
 * Plinth.js - part of Plinth v1.0.0. Enable it with PlinthCore.js (any order).
 *
 * STATUES. Put a note on an event:
 *   <statue: actor 3, bronze, age 40>    the walking sprite of actor 3, in bronze, weathered
 *   <statue: enemy 5, marble>            the battler image of enemy 5, as a marble statue
 *   <statue: self, granite>              the event's own graphic
 *   <statue: actor 1, gilt, name: The Founder>   a name of your own, cut into the base
 * The event shows the statue, standing on a drawn base with the name cut in. No image files.
 *
 * PETRIFY / RESTORE (plugin commands). The player, a follower or an event turns to stone from the
 * feet up, and back. A stone character cannot move. Saved with the game.
 *
 * BATTLE. A state with the note <Plinth: granite> (any material) turns the battler to stone while the
 * state holds: enemies, and side-view actors (their motion freezes).
 *
 * Every line of this plugin was written with AI assistance.
 */
(function () {
  'use strict';
  const NAME = 'Plinth';
  const RAW = PluginManager.parameters(NAME);
  const FRAMES = 10;                                  // the creep is baked as this many frames (ARCHITECTURE.md)
  const num = (v, d, lo, hi) => { const s = String(v == null ? '' : v).trim(); const n = Number(s); return s === '' || !isFinite(n) ? d : Math.min(hi, Math.max(lo, n)); };
  const bool = (v, d) => { const s = String(v == null ? '' : v).trim().toLowerCase(); return s === 'true' ? true : s === 'false' ? false : d; };

  // the core is resolved at FIRST USE, never at load: load order is the buyer's choice (wing §8 trap 2)
  let _core = null;
  function Core() {
    if (!_core) {
      _core = window.PlinthCore;
      if (!_core) throw new Error('Plinth: PlinthCore.js is not loaded. Turn it on in the Plugin Manager.');
    }
    return _core;
  }
  let _P = null;
  /** parameters, read once on first use (the material list lives in the core) */
  function P() {
    if (_P) return _P;
    const mat = String(RAW.material || '').trim().toLowerCase();
    _P = {
      material: Core().MATERIALS[mat] ? mat : 'granite',
      age: num(RAW.age, 0, 0, 100),
      frames: num(RAW.petrifyFrames, 90, 1, 600),
      blankEyes: bool(RAW.blankEyes, true),
      showBase: bool(RAW.showBase, true),
      carveNames: bool(RAW.carveNames, true),
    };
    return _P;
  }

  // ── reading pixels: once per bake, from a canvas we own (never bitmap.canvas: Probe_Doctrine §37b) ────────────────
  const Scratch = { cv: null, g: null };
  function readRect(bitmap, sx, sy, w, h) {
    if (!Scratch.cv) { Scratch.cv = document.createElement('canvas'); Scratch.cv.width = 0; Scratch.cv.height = 0; }
    if (Scratch.cv.width < w || Scratch.cv.height < h) { Scratch.cv.width = Math.max(Scratch.cv.width, w); Scratch.cv.height = Math.max(Scratch.cv.height, h); Scratch.g = null; }
    if (!Scratch.g) Scratch.g = Scratch.cv.getContext('2d', { willReadFrequently: true });
    Scratch.g.clearRect(0, 0, w, h);
    Scratch.g.drawImage(bitmap._canvas || bitmap._image, sx, sy, w, h, 0, 0, w, h);
    return Scratch.g.getImageData(0, 0, w, h).data;
  }
  function toBitmap(rgba, w, h) {
    const b = new Bitmap(w, h);
    b.context.putImageData(new ImageData(rgba, w, h), 0, 0);
    b.baseTexture.update();
    return b;
  }
  /** one bake per frame, so a map full of statues settles over a few frames instead of stalling one */
  const Budget = { frame: -1 };
  function takeBake() { if (Budget.frame === Graphics.frameCount) return false; Budget.frame = Graphics.frameCount; return true; }

  /** a character sheet's frame rectangle (MZ's own arithmetic, rmmz_sprites.js:337-370) */
  function charRect(bitmap, name, index, dir, pattern) {
    const big = ImageManager.isBigCharacter(name);
    const pw = bitmap.width / (big ? 3 : 12), ph = bitmap.height / (big ? 4 : 8);
    const bx = big ? 0 : (index % 4) * 3, by = big ? 0 : Math.floor(index / 4) * 4;
    const px = pattern < 3 ? pattern : 1;
    return { sx: (bx + px) * pw, sy: (by + (dir - 2) / 2) * ph, w: pw, h: ph };
  }

  /** strike one frame: analyse, blank the eyes, strike. Returns the analysis, the living and the statue RGBA */
  function strikeFrame(living, w, h, material, age, seed) {
    const C = Core(), A = C.analyse(living, w, h);
    const src = P().blankEyes ? C.blankEyes(A, living).rgba : living;
    return { A, living, statue: C.strike(A, src, material, age, seed) };
  }

  // ── the statue event ────────────────────────────────────────────────────────────────────────────────────────
  /**
   * The statue spec of an event, parsed from its note once and kept (runtime only: declared non-enumerable, so it is
   * never written into a save; JsonEx walks Object.keys).
   * @returns {object|null}
   */
  Game_Event.prototype.plinthStatue = function () {
    if (!Object.prototype.hasOwnProperty.call(this, '_plinthSpec')) {
      Object.defineProperty(this, '_plinthSpec', { value: undefined, writable: true, enumerable: false, configurable: true });
      const data = this.event(), tag = data && data.meta ? data.meta.statue : undefined;
      this._plinthSpec = tag === undefined ? null : Core().parseStatueTag(tag);
      if (this._plinthSpec && this._plinthSpec.errors.length) console.warn('Plinth: event ' + this.eventId() + ' on map ' + $gameMap.mapId() + ': ' + this._plinthSpec.errors.join('; '));
    }
    return this._plinthSpec;
  };

  /** where the statue's figure comes from: {bitmap, rect, name (for the base), key} or null when there is no image */
  function statueSource(ev, spec) {
    if (spec.source === 'actor') {
      const a = $dataActors[spec.id];
      if (!a || !a.characterName) return null;
      const b = ImageManager.loadCharacter(a.characterName);
      return { bitmap: b, kind: 'char', file: a.characterName, index: a.characterIndex, dir: ev.direction(), pattern: 1, label: a.name, key: 'A' + spec.id + '|' + a.characterName + '|' + a.characterIndex + '|' + ev.direction() };
    }
    if (spec.source === 'enemy') {
      const e = $dataEnemies[spec.id];
      if (!e || !e.battlerName) return null;
      const sv = $gameSystem.isSideView(), b = sv ? ImageManager.loadSvEnemy(e.battlerName) : ImageManager.loadEnemy(e.battlerName);
      return { bitmap: b, kind: 'whole', file: e.battlerName, label: e.name, key: 'E' + spec.id + '|' + e.battlerName + '|' + (sv ? 'sv' : 'fv') };
    }
    const name = ev.characterName();
    if (!name || ev.tileId() > 0) return null;
    return { bitmap: ImageManager.loadCharacter(name), kind: 'char', file: name, index: ev.characterIndex(), dir: ev.direction(), pattern: ev.pattern(), label: '', key: 'S|' + name + '|' + ev.characterIndex() + '|' + ev.direction() + '|' + ev.pattern() };
  }

  /** a note's material and age, or the parameters when the note named none */
  function matOf(spec) { return spec.materialGiven ? spec.material : P().material; }
  function ageOf(spec) { return spec.ageGiven ? spec.age : P().age; }

  /** bake a statue on its base: one Bitmap, the base's foot at the bottom edge (the sprite's anchor) */
  function bakeStatue(src, spec) {
    const C = Core(), b = src.bitmap, mat = matOf(spec), age = ageOf(spec);
    const r = src.kind === 'char' ? charRect(b, src.file, src.index, src.dir, src.pattern) : { sx: 0, sy: 0, w: b.width, h: b.height };
    const w = Math.floor(r.w), h = Math.floor(r.h);
    const seed = C.seedOf(src.key + '|' + mat);
    const S = strikeFrame(readRect(b, r.sx, r.sy, w, h), w, h, mat, age, seed);
    if (!P().showBase) return { rgba: S.statue, w, h };
    let label = spec.name != null ? spec.name : (P().carveNames ? src.label : '');
    const bs = C.baseScale(S.A);                         // the plinth grows with the figure (a big battler's base is not a plank)
    let pl = C.base(mat, S.A.bbox.w, label, bs, age, seed);
    if (!pl.fit) { console.warn('Plinth: the name "' + label + '" is longer than ' + C.NAME_MAX + ' letters; the base is left uncut.'); pl = C.base(mat, S.A.bbox.w, '', bs, age, seed); }
    if (pl.missing.length) console.warn('Plinth: the base cannot cut ' + JSON.stringify(pl.missing.join('')) + ' (left blank)');
    // the figure's feet rest on the base's cap: rows below the feet (transparent) are dropped
    const feet = S.A.bbox.y + S.A.bbox.h, W = Math.max(w, pl.w), H = feet + pl.h, out = new Uint8ClampedArray(W * H * 4);
    const fx = Math.floor((W - w) / 2), bx = Math.floor((W - pl.w) / 2);
    for (let y = 0; y < pl.h; y++) for (let x = 0; x < pl.w; x++) { const s = (y * pl.w + x) * 4, d = ((feet + y) * W + bx + x) * 4; out[d] = pl.rgba[s]; out[d + 1] = pl.rgba[s + 1]; out[d + 2] = pl.rgba[s + 2]; out[d + 3] = pl.rgba[s + 3]; }
    for (let y = 0; y < feet; y++) for (let x = 0; x < w; x++) {
      const s = (y * w + x) * 4, a = S.statue[s + 3] / 255;
      if (a <= 0) continue;
      const d = (y * W + fx + x) * 4, ia = 1 - a;
      out[d] = S.statue[s] * a + out[d] * ia; out[d + 1] = S.statue[s + 1] * a + out[d + 1] * ia; out[d + 2] = S.statue[s + 2] * a + out[d + 2] * ia;
      out[d + 3] = Math.max(out[d + 3], S.statue[s + 3]);
    }
    return { rgba: out, w: W, h: H };
  }

  // ── the bake cache, per map: every entry is built once and destroyed with the map's sprites ───────────────────
  const Cache = { map: new Map() };
  function cacheReset() {
    for (const e of Cache.map.values()) if (e.bitmap) e.bitmap.destroy();
    Cache.map = new Map();
  }
  const _createCharacters = Spriteset_Map.prototype.createCharacters;
  Spriteset_Map.prototype.createCharacters = function () {
    cacheReset();
    _createCharacters.call(this);
  };

  /** the statue entry for an event sprite, or null while it is not ready (the stock sprite shows until then) */
  function statueEntry(sp, ev, spec) {
    // re-resolved only when the spec or the event's page changes (a self statue shows its active page's graphic)
    if (sp._plinthSpec !== spec || sp._plinthPage !== ev._pageIndex) { sp._plinthSpec = spec; sp._plinthPage = ev._pageIndex; sp._plinthKey = null; sp._plinthSrc = statueSource(ev, spec); }
    const src = sp._plinthSrc;
    if (!src) return null;
    if (!sp._plinthKey) sp._plinthKey = 'statue|' + src.key + '|' + matOf(spec) + '|' + ageOf(spec) + '|' + (spec.name == null ? '' : spec.name);
    let e = Cache.map.get(sp._plinthKey);
    if (!e) { e = { kind: 'statue', state: 'pending', bitmap: null, w: 0, h: 0 }; Cache.map.set(sp._plinthKey, e); }
    if (e.state === 'pending' && src.bitmap.isReady() && takeBake()) {
      if (src.bitmap.width < 4 || src.bitmap.height < 4) e.state = 'failed';
      else { const r = bakeStatue(src, spec); e.bitmap = toBitmap(r.rgba, r.w, r.h); e.w = r.w; e.h = r.h; e.state = 'ready'; Plinth.baked++; }
    }
    return e.state === 'ready' ? e : null;
  }

  // ── petrification: the record lives on the character (saved), the frames in the cache ────────────────────────
  /** @returns {{v:number,mat:string,age:number,p:number,rate:number}|null} 0 < p <= 1 means stone (partly or whole) */
  Game_CharacterBase.prototype.plinthRecord = function () { return this._plinth || null; };
  Game_CharacterBase.prototype.plinthIsStone = function () { const r = this._plinth; return !!(r && r.p > 0); };

  const _cbUpdate = Game_CharacterBase.prototype.update;
  Game_CharacterBase.prototype.update = function () {
    _cbUpdate.call(this);
    const r = this._plinth;
    if (r && r.rate !== 0) {
      r.p += r.rate;
      if (r.p >= 1) { r.p = 1; r.rate = 0; }
      else if (r.p <= 0) { this._plinth = null; }
    }
  };
  const _updateAnimation = Game_CharacterBase.prototype.updateAnimation;
  Game_CharacterBase.prototype.updateAnimation = function () {
    if (this._plinth && this._plinth.p > 0) return;           // stone does not step
    _updateAnimation.call(this);
  };
  const _canMove = Game_Player.prototype.canMove;
  Game_Player.prototype.canMove = function () {
    if (this._plinth && this._plinth.p > 0) return false;
    return _canMove.call(this);
  };
  const _updateSelfMovement = Game_Event.prototype.updateSelfMovement;
  Game_Event.prototype.updateSelfMovement = function () {
    if (this._plinth && this._plinth.p > 0) return;
    _updateSelfMovement.call(this);
  };

  /** the creep strip for a petrifying character's sprite (FRAMES frames side by side, the last the whole statue) */
  function creepEntry(sp, ch, rec) {
    const name = ch.characterName();
    if (!name || ch.tileId() > 0) return null;
    // the key is rebuilt only when what it names changes (no string per frame)
    if (sp._plinthCName !== name || sp._plinthCIndex !== ch.characterIndex() || sp._plinthCDir !== ch.direction() || sp._plinthCPat !== ch.pattern() || sp._plinthCMat !== rec.mat || sp._plinthCAge !== rec.age) {
      sp._plinthCName = name; sp._plinthCIndex = ch.characterIndex(); sp._plinthCDir = ch.direction(); sp._plinthCPat = ch.pattern(); sp._plinthCMat = rec.mat; sp._plinthCAge = rec.age;
      sp._plinthCKey = 'creep|' + name + '|' + sp._plinthCIndex + '|' + sp._plinthCDir + '|' + sp._plinthCPat + '|' + rec.mat + '|' + rec.age;
    }
    let e = Cache.map.get(sp._plinthCKey);
    if (!e) { e = { kind: 'creep', state: 'pending', bitmap: null, w: 0, h: 0, n: FRAMES }; Cache.map.set(sp._plinthCKey, e); }
    const b = ImageManager.loadCharacter(name);
    if (e.state === 'pending' && b.isReady() && takeBake()) {
      const C = Core(), r = charRect(b, name, sp._plinthCIndex, sp._plinthCDir, sp._plinthCPat), w = Math.floor(r.w), h = Math.floor(r.h);
      const seed = C.seedOf(sp._plinthCKey);
      const S = strikeFrame(readRect(b, r.sx, r.sy, w, h), w, h, rec.mat, rec.age, seed);
      const frames = C.bakeCreep(S.A, S.living, S.statue, FRAMES, seed), strip = new Uint8ClampedArray(w * FRAMES * h * 4);
      for (let k = 0; k < FRAMES; k++) for (let y = 0; y < h; y++) strip.set(frames[k].subarray(y * w * 4, (y + 1) * w * 4), (y * w * FRAMES + k * w) * 4);
      e.bitmap = toBitmap(strip, w * FRAMES, h); e.w = w; e.h = h; e.state = 'ready'; Plinth.baked++;
    }
    return e.state === 'ready' ? e : null;
  }

  // ── the sprite ───────────────────────────────────────────────────────────────────────────────────────────────
  function entryFor(sp) {
    const ch = sp._character;
    if (!ch) return null;
    const rec = ch._plinth;
    if (rec && rec.p > 0) return creepEntry(sp, ch, rec);
    if (ch instanceof Game_Event) { const spec = ch.plinthStatue(); if (spec) return statueEntry(sp, ch, spec); }
    return null;
  }
  const _updateBitmap = Sprite_Character.prototype.updateBitmap;
  Sprite_Character.prototype.updateBitmap = function () {
    const e = entryFor(this);
    if (e) {
      if (this._plinthEntry !== e) { this._plinthEntry = e; this.bitmap = e.bitmap; }
      return;
    }
    if (this._plinthEntry) { this._plinthEntry = null; this._characterName = null; }   // left Plinth: the stock path redraws
    _updateBitmap.call(this);
  };
  // a statue of an actor or an enemy has no page graphic, and MZ hides such a sprite as EMPTY (rmmz_sprites.js:262).
  // MEASURED 2026-10-12: five statues baked, bitmaps and frames correct, all invisible, found by LOOKING at the frame
  const _isEmptyCharacter = Sprite_Character.prototype.isEmptyCharacter;
  Sprite_Character.prototype.isEmptyCharacter = function () {
    if (this._plinthEntry && this.bitmap === this._plinthEntry.bitmap) return false;
    return _isEmptyCharacter.call(this);
  };
  const _updateFrame = Sprite_Character.prototype.updateFrame;
  Sprite_Character.prototype.updateFrame = function () {
    const e = this._plinthEntry;
    if (!e || this.bitmap !== e.bitmap) return _updateFrame.call(this);
    if (this._upperBody) { this._upperBody.visible = false; this._lowerBody.visible = false; }   // a statue is never half in a bush
    if (e.kind === 'statue') { this.setFrame(0, 0, e.w, e.h); return; }
    const p = this._character._plinth ? this._character._plinth.p : 1;
    const k = Math.min(e.n, Math.max(1, Math.ceil(p * e.n))) - 1;
    this.setFrame(k * e.w, 0, e.w, e.h);
  };

  // ── plugin commands ──────────────────────────────────────────────────────────────────────────────────────────
  function targetOf(interp, args) {
    const t = String(args.target || 'this');
    if (t === 'player') return $gamePlayer;
    if (t === 'follower') { const f = $gamePlayer.followers().follower(Math.max(0, num(args.followerIndex, 1, 1, 99) - 1)); return f && f.isVisible() ? f : null; }
    // compare against zero: "0" is truthy as a string (wing §16)
    const id = t === 'event' ? Number(args.eventId) : 0;
    return $gameMap.event(id > 0 ? id : interp.eventId()) || null;
  }
  PluginManager.registerCommand(NAME, 'petrify', function (args) {
    const ch = targetOf(this, args);
    if (!ch) return;
    const m = String(args.material || '').trim().toLowerCase(), mat = Core().MATERIALS[m] ? m : P().material;
    const frames = num(args.frames, P().frames, 1, 600), age = num(args.age, P().age, 0, 100);
    const r = ch._plinth;
    if (r && r.p >= 1 && r.mat === mat) return;                    // already stone
    ch._plinth = { v: 1, mat, age, p: r && r.mat === mat ? r.p : 0, rate: 1 / frames };
    if (String(args.wait) === 'true') this.wait(frames + 1);
  });
  PluginManager.registerCommand(NAME, 'restore', function (args) {
    const ch = targetOf(this, args);
    if (!ch || !ch._plinth) return;
    const frames = num(args.frames, P().frames, 1, 600);
    ch._plinth.rate = -1 / frames;
    if (String(args.wait) === 'true') this.wait(Math.ceil(frames * ch._plinth.p) + 1);
  });

  // ── battle: a state with <Plinth: material> turns the battler to stone while it holds ───────────────────────
  /** the material of the first Plinth state on a battler, or null. Reads the state ids directly (no array per frame) */
  function stateMaterial(battler) {
    const ids = battler._states;
    for (let i = 0; i < ids.length; i++) {
      const st = $dataStates[ids[i]], m = st && st.meta ? st.meta.Plinth : undefined;
      if (m === undefined) continue;
      const id = m === true ? '' : String(m).trim().toLowerCase();
      return Core().MATERIALS[id] ? id : P().material;
    }
    return null;
  }
  /** strike a whole image (an enemy battler) or, for a side-view sheet, every one of its 9 x 6 cells on its own */
  function strikeImage(b, mat, seedKey, cols, rows) {
    const C = Core(), W = b.width, H = b.height, all = readRect(b, 0, 0, W, H), out = new Uint8ClampedArray(all.length);
    const cw = Math.floor(W / cols), chh = Math.floor(H / rows), seed = C.seedOf(seedKey + '|' + mat);
    for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
      const cell = new Uint8ClampedArray(cw * chh * 4);
      for (let y = 0; y < chh; y++) cell.set(all.subarray(((r * chh + y) * W + c * cw) * 4, ((r * chh + y) * W + c * cw + cw) * 4), y * cw * 4);
      const S = strikeFrame(cell, cw, chh, mat, P().age, seed);
      for (let y = 0; y < chh; y++) out.set(S.statue.subarray(y * cw * 4, (y + 1) * cw * 4), ((r * chh + y) * W + c * cw) * 4);
    }
    return toBitmap(out, W, H);
  }
  function battlerStone(sp, battler, holder, cols, rows) {
    const mat = stateMaterial(battler), cur = holder.bitmap;
    if (!mat) {
      if (sp._plinthOn) { sp._plinthOn = null; if (cur === sp._plinthOut) holder.bitmap = sp._plinthSrc; return 'restored'; }
      return null;
    }
    if (mat === sp._plinthOn && cur === sp._plinthOut) return null;
    const src = cur === sp._plinthOut ? sp._plinthSrc : cur;
    if (!src || !src.isReady() || src.width < 4 || src.height < 4 || !takeBake()) return null;
    if (sp._plinthOut) sp._plinthOut.destroy();
    sp._plinthOut = strikeImage(src, mat, String(src.url || src._url || ''), cols, rows);
    sp._plinthSrc = src; sp._plinthOn = mat; holder.bitmap = sp._plinthOut; Plinth.baked++;
    return 'struck';
  }
  const _enemyUpdate = Sprite_Enemy.prototype.update;
  Sprite_Enemy.prototype.update = function () {
    _enemyUpdate.call(this);
    if (!this._enemy) return;
    const r = battlerStone(this, this._enemy, this, 1, 1);
    if (r === 'struck') this.setHue(0);                          // stone is not hue-shifted
    else if (r === 'restored') this.setHue(this._battlerHue);
  };
  const _actorUpdate = Sprite_Actor.prototype.update;
  Sprite_Actor.prototype.update = function () {
    _actorUpdate.call(this);
    if (this._actor && this._mainSprite) battlerStone(this, this._actor, this._mainSprite, 9, 6);
  };
  const _updateMotionCount = Sprite_Actor.prototype.updateMotionCount;
  Sprite_Actor.prototype.updateMotionCount = function () {
    if (this._plinthOn) return;                                  // a stone actor holds its pose
    _updateMotionCount.call(this);
  };
  const _destroyEnemy = Sprite_Enemy.prototype.destroy;
  Sprite_Enemy.prototype.destroy = function (o) { const own = this._plinthOut; this._plinthOut = null; this._plinthSrc = null; _destroyEnemy.call(this, o); if (own) own.destroy(); };
  const _destroyActor = Sprite_Actor.prototype.destroy;
  Sprite_Actor.prototype.destroy = function (o) { const own = this._plinthOut; this._plinthOut = null; this._plinthSrc = null; _destroyActor.call(this, o); if (own) own.destroy(); };

  // a test and support seam, read only
  const Plinth = window.Plinth = { version: '1.0.0', baked: 0, cacheSize: () => Cache.map.size };
})();
