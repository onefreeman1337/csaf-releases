/*:
 * @target MZ
 * @plugindesc Plinth 1/2 - the statue: struck from each character's or enemy's own pixels in seven materials. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * PlinthCore.js - part of Plinth v1.0.0. Enable it with Plinth.js (any order). It has no commands or parameters of its
 * own; Plinth.js reads it.
 *
 * Every line of this plugin was written with AI assistance.
 */
/*
 * The whole picture as PURE pixel operations on an RGBA buffer, so it runs in Node on real character sheets exactly as it
 * runs in MZ. Never Math.random: every grain is a hash of the pixel's position at the art's own pixel scale and a seed.
 * Nothing is ever drawn outside the figure's alpha mask, and every ink comes from the material's ramp at the luminance of
 * the pixel it lands on (never a hard-coded ink over arbitrary art).
 */
var PlinthCore = (function () {
  'use strict';

  /* ------------------------------------------------------------ seeded hashing (no state, so no allocation per pixel) */
  function hash2(x, y, s) { var h = Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263) ^ Math.imul(s | 0, 2246822519); h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; }
  /** smooth value noise in [0,1] at scale `sc` (in the art's own pixels) */
  function noise(x, y, sc, s) {
    var fx = x / sc, fy = y / sc, ix = Math.floor(fx), iy = Math.floor(fy), tx = fx - ix, ty = fy - iy;
    tx = tx * tx * (3 - 2 * tx); ty = ty * ty * (3 - 2 * ty);
    var a = hash2(ix, iy, s), b = hash2(ix + 1, iy, s), c = hash2(ix, iy + 1, s), d = hash2(ix + 1, iy + 1, s);
    return a + (b - a) * tx + (c - a) * ty + (a - b - c + d) * tx * ty;
  }
  /** a string -> a 32-bit seed (FNV-1a), so a statue's grain is stable per image name */
  function seedOf(str) { var h = 0x811c9dc5; str = String(str); for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 0x01000193); } return h >>> 0; }
  function clamp01(v) { return v < 0 ? 0 : v > 1 ? 1 : v; }

  /* ------------------------------------------------------------ analysis (once per image, at load) */
  var ALPHA_IN = 32, SHADOW_ALPHA = 230, SHADOW_LUM = 20;
  /**
   * Read a frame once: its alpha mask, luminance, the 5th/95th luminance percentiles over the mask (so a dark sprite and a
   * pale one both span the whole ramp), distance to the outline, which pixels face the light (nothing above them), the
   * bounding box and the art's native pixel scale.
   * @param {Uint8Array|Uint8ClampedArray|Buffer} px RGBA, w*h*4
   * @param {number} w
   * @param {number} h
   * @returns {{w:number,h:number,mask:Uint8Array,lum:Float32Array,dist:Float32Array,top:Uint8Array,lo:number,hi:number,bbox:{x:number,y:number,w:number,h:number},area:number,px:number}}
   */
  function analyse(px, w, h) {
    var n = w * h, mask = new Uint8Array(n), lum = new Float32Array(n), dist = new Float32Array(n), top = new Uint8Array(n);
    var area = 0, x0 = w, y0 = h, x1 = -1, y1 = -1, i, x, y, hist = new Uint32Array(256);
    for (i = 0; i < n; i++) {
      var o = i * 4;
      lum[i] = 0.2126 * px[o] + 0.7152 * px[o + 1] + 0.0722 * px[o + 2];
      // a battler's painted ground SHADOW (semi-transparent, near-black) is not the figure (ScatheCore, measured on six
      // stock enemies): the statue never strikes it
      if (px[o + 3] > ALPHA_IN && !(px[o + 3] < SHADOW_ALPHA && lum[i] < SHADOW_LUM)) {
        mask[i] = 1; area++; hist[Math.min(255, lum[i] | 0)]++;
        x = i % w; y = (i / w) | 0; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
      }
    }
    var lo = 0, hi = 255, acc = 0, k;
    if (area > 0) {
      for (k = 0; k < 256; k++) { acc += hist[k]; if (acc >= area * 0.05) { lo = k; break; } }
      acc = 0;
      for (k = 255; k >= 0; k--) { acc += hist[k]; if (acc >= area * 0.05) { hi = k; break; } }
    }
    var s = pixelScale(px, w, h, mask);
    // chamfer distance (1, 1.414) to the nearest outside pixel, inside the mask only (ScatheCore's two passes)
    var BIG = 1e6;
    for (i = 0; i < n; i++) dist[i] = mask[i] ? BIG : 0;
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) {
      i = y * w + x; if (!mask[i]) continue;
      dist[i] = Math.min(dist[i], x > 0 ? dist[i - 1] + 1 : 1, y > 0 ? dist[i - w] + 1 : 1, x > 0 && y > 0 ? dist[i - w - 1] + 1.414 : 1.414, x < w - 1 && y > 0 ? dist[i - w + 1] + 1.414 : 1.414);
    }
    for (y = h - 1; y >= 0; y--) for (x = w - 1; x >= 0; x--) {
      i = y * w + x; if (!mask[i]) continue;
      dist[i] = Math.min(dist[i], x < w - 1 ? dist[i + 1] + 1 : 1, y < h - 1 ? dist[i + w] + 1 : 1, x < w - 1 && y < h - 1 ? dist[i + w + 1] + 1.414 : 1.414, x > 0 && y < h - 1 ? dist[i + w - 1] + 1.414 : 1.414);
    }
    // a pixel FACES THE LIGHT when the art's own pixel above it (one native pixel up) is outside the figure
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) { i = y * w + x; if (mask[i] && (y - s < 0 || !mask[i - s * w])) top[i] = 1; }
    return { w: w, h: h, mask: mask, lum: lum, dist: dist, top: top, lo: lo, hi: hi, bbox: { x: x0, y: y0, w: x1 - x0 + 1, h: y1 - y0 + 1 }, area: area, px: s };
  }
  /** the native pixel size: the largest of 4/3/2 dividing nearly every opaque run, else 1 (ScatheCore, measured on 1x-4x) */
  function pixelScale(px, w, h, mask) {
    var hist = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], y, x, r;
    for (y = 0; y < h; y += 2) {
      var run = 0, prev = -1;
      for (x = 0; x < w; x++) {
        var i = y * w + x, o = i * 4, key = mask[i] ? (px[o] << 16 | px[o + 1] << 8 | px[o + 2]) : -2;
        if (key === prev && key !== -2) run++; else { if (prev !== -2 && prev !== -1 && run > 0 && run <= 12) hist[run]++; run = 1; prev = key; }
      }
    }
    var total = 0;
    for (r = 1; r <= 12; r++) total += hist[r];
    if (total < 20 || hist[1] / total > 0.25) return 1;
    for (var s = 4; s >= 2; s--) { var sc = 0; for (r = 1; r <= 12; r++) if (r % s === 0) sc += hist[r]; if (sc / total > 0.85) return s; }
    return 1;
  }

  /**
   * How big a figure is against MZ's own 48 px character, in the art's own pixels: 1 for a walking sprite, ~6 for a 300 px
   * painted battler. Bands (veins, strata, conchoidal bands, streaks) are drawn at this scale so a big statue carries as
   * many bands as a small one, not forty.
   */
  function bandScale(A) { var px = A.px > 0 ? A.px : 1; return Math.max(1, Math.min(8, Math.round(A.bbox.h / (48 * px)))); }
  /**
   * The base's own pixel scale: the art's pixel, or larger for a big figure so the plinth keeps its proportion (MEASURED
   * 2026-10-12 by looking: at scale 1 a 300 px battler stood on an 18 px plank). Capped at 4, the base's own limit.
   */
  function baseScale(A) { var px = A.px > 0 ? A.px : 1; return Math.max(Math.min(4, px), Math.min(4, Math.round(A.bbox.h / 72))); }

  /* ------------------------------------------------------------ materials: a ramp AND a structure each (wing §21a) */
  /**
   * Each material is a luminance ramp (stops [position, r, g, b], positions ascending 0..1) plus a named SURFACE, which is
   * the part a tint cannot make: grain, veins, strata, cast texture with recesses, glints, specular, refraction. `amp` is how
   * far the surface moves a pixel along the ramp; `alpha` scales the figure's own alpha (ice only).
   */
  var MATERIALS = {
    granite: { label: 'Granite', amp: 0.34, alpha: 1, ramp: [[0, 38, 38, 42], [0.35, 92, 90, 92], [0.7, 150, 146, 142], [1, 206, 202, 194]] },
    marble: { label: 'Marble', amp: 0.30, alpha: 1, ramp: [[0, 120, 118, 128], [0.4, 196, 194, 198], [0.75, 232, 230, 226], [1, 252, 250, 244]] },
    sandstone: { label: 'Sandstone', amp: 0.30, alpha: 1, ramp: [[0, 92, 62, 40], [0.4, 168, 124, 82], [0.75, 214, 174, 122], [1, 240, 214, 166]] },
    bronze: { label: 'Bronze', amp: 0.26, alpha: 1, ramp: [[0, 44, 26, 14], [0.35, 112, 70, 34], [0.7, 176, 122, 60], [1, 236, 196, 128]] },
    gilt: { label: 'Gilt', amp: 0.26, alpha: 1, ramp: [[0, 70, 44, 10], [0.35, 150, 104, 28], [0.7, 214, 168, 52], [1, 255, 240, 170]] },
    // inlay: the base's letters are filled with this material instead of cut into shadow (first plinth look 2026-10-12: a
    // shadowed groove on a near-black die was illegible, so black stone takes gilt letters, as real inscriptions do)
    obsidian: { label: 'Obsidian', amp: 0.30, alpha: 1, inlay: 'gilt', ramp: [[0, 8, 6, 14], [0.45, 30, 26, 42], [0.8, 70, 64, 92], [1, 150, 146, 178]] },
    ice: { label: 'Ice', amp: 0.30, alpha: 0.86, ramp: [[0, 40, 86, 128], [0.4, 120, 176, 214], [0.75, 194, 230, 246], [1, 246, 254, 255]] },
  };
  var MATERIAL_IDS = ['granite', 'marble', 'sandstone', 'bronze', 'gilt', 'obsidian', 'ice'];
  /** the verdigris and lichen inks the weathering mixes toward (their own colours, chosen to carry real chroma, §26m) */
  var VERDIGRIS = [64, 150, 120], LICHEN = [150, 160, 60], MOSS = [70, 112, 44];

  var COL = [0, 0, 0];
  /** ramp lookup into the shared COL triple (no allocation per pixel) */
  function rampAt(ramp, t) {
    t = clamp01(t);
    for (var k = 1; k < ramp.length; k++) {
      if (t <= ramp[k][0]) {
        var a = ramp[k - 1], b = ramp[k], u = (t - a[0]) / (b[0] - a[0] || 1);
        COL[0] = a[1] + (b[1] - a[1]) * u; COL[1] = a[2] + (b[2] - a[2]) * u; COL[2] = a[3] + (b[3] - a[3]) * u; return COL;
      }
    }
    var z = ramp[ramp.length - 1]; COL[0] = z[1]; COL[1] = z[2]; COL[2] = z[3]; return COL;
  }

  /**
   * The SURFACE of a material at a pixel, in ramp units (about -1..1 before `amp`): the structure that separates a carved
   * or cast figure from a grey tone. Coordinates are in the art's own pixels (x/px, y/px), so a 2x sheet gets 2x grain.
   */
  function surface(id, A, i, ax, ay, s, gs) {
    // gs: the BAND scale. Veins, strata, conchoidal bands and refraction streaks are drawn at gs (one per 48 px of figure,
    // see bandScale); grain (crystals, mottle, grit) stays at the art's own pixel. MEASURED 2026-10-12 by looking at the
    // in-engine map: obsidian bands at native scale on a 300 px battler read as striped fabric, ~40 stripes across it
    gs = gs > 1 ? gs : 1;
    var bx = ax / gs, by = ay / gs, n1, h;
    switch (id) {
      case 'granite': // sparse dark and light crystals over a broad mottle (first look 2026-10-12: a dense speckle read as TV static and ate the face)
        h = hash2(ax, ay, s);
        return (h < 0.07 ? -0.9 : h > 0.95 ? 0.6 : 0) + (noise(ax, ay, 4, s + 1) - 0.5) * 0.9;
      case 'marble': // warped veins across a pale ground
        n1 = noise(bx, by, 5, s + 2);
        h = Math.abs(Math.sin((bx * 0.42 + by * 0.71 + n1 * 7) * 0.9));
        return (h < 0.16 ? -1.2 : 0.15) + (noise(ax, ay, 2, s + 3) - 0.5) * 0.3;
      case 'sandstone': // broad wavy strata with fine grit (first look 2026-10-12: tight hard strata read as scanlines)
        n1 = noise(bx, by, 9, s + 4);
        h = Math.sin(by * 0.5 + n1 * 2.6);
        return h * 0.5 + (hash2(ax, ay, s + 5) - 0.5) * 0.5;
      case 'bronze': // a soft cast texture (sand-cast mottling)
        return (noise(ax, ay, 2.5, s + 6) - 0.5) * 1.2;
      case 'gilt': // a beaten-leaf mottle
        return (noise(ax, ay, 2, s + 7) - 0.5) * 1.0 + (hash2(ax, ay, s + 8) < 0.06 ? 0.9 : 0);
      case 'obsidian': // conchoidal bands, glassy
        n1 = noise(bx, by, 6, s + 9);
        return Math.sin((bx * 0.6 - by * 0.35) * 1.3 + n1 * 5) * 0.75;
      case 'ice': // diagonal refraction streaks through a clear body (integer cells: the streak test is modular)
        var cx = Math.floor(bx), cy = Math.floor(by);
        h = ((cx + cy * 2 + ((noise(cx, cy, 6, s + 10) * 5) | 0)) % 9 + 9) % 9;
        return (h === 0 ? 1.3 : h === 1 ? 0.6 : 0) + (noise(ax, ay, 4, s + 11) - 0.5) * 0.4;
    }
    return 0;
  }

  /**
   * Strike a frame as a statue.
   * @param {object} A the analyse() result for `src`
   * @param {Uint8Array|Uint8ClampedArray|Buffer} src RGBA of the living figure
   * @param {string} id one of MATERIAL_IDS (an unknown id falls to granite, never to nothing, §21c)
   * @param {number} age 0..100: weathering (lichen on light-facing surfaces, rain streaks, moss at the foot; verdigris on bronze)
   * @param {number} seed
   * @returns {Uint8ClampedArray} a NEW RGBA buffer; pixels outside the mask are copied unchanged
   */
  function strike(A, src, id, age, seed) {
    var M = MATERIALS[id] ? id : 'granite', mat = MATERIALS[M], w = A.w, h = A.h, n = w * h, out = new Uint8ClampedArray(src.length);
    out.set(src);
    var s = (seed >>> 0) || 1, px = A.px > 0 ? A.px : 1, span = A.hi - A.lo, ag = clamp01((+age || 0) / 100);
    if (!(span >= 1)) span = 0; // a one-colour figure: every pixel sits mid-ramp (never a NaN into the ramp, §26e)
    var by0 = A.bbox.y, bh = Math.max(1, A.bbox.h), by1 = by0 + bh - 1, gs = bandScale(A);
    // the row of the last light-facing pixel above, per column: weather runs DOWN from an edge that faces the sky (first
    // look 2026-10-12: a streak spanning the whole column read as a barcode). Allocated per bake, never per frame.
    var lastTop = new Int32Array(w).fill(-1000000), streakLen = (3 + 10 * ag) * px;
    for (var i = 0; i < n; i++) {
      var x = i % w, y = (i / w) | 0;
      if (!A.mask[i]) continue;
      if (A.top[i]) lastTop[x] = y;
      var ax = Math.floor(x / px), ay = Math.floor(y / px), o = i * 4, below = y - lastTop[x];
      var t = span ? (A.lum[i] - A.lo) / span : 0.5;
      t = 0.2 + 0.62 * clamp01(t); // carved stone keeps the form, not the costume's full contrast
      t += 0.14 * (1 - 2 * (y - by0) / bh) * 0.5; // light from above across the whole figure
      if (A.top[i]) t += 0.2; // the lit top edge
      if (A.dist[i] <= 1) t -= 0.16; // the outline reads as a carved edge in shadow
      t += mat.amp * surface(M, A, i, ax, ay, s, gs);
      var c = rampAt(mat.ramp, t), r = c[0], g = c[1], b = c[2];
      // material accents
      if (M === 'bronze') { // verdigris pools in the recesses: dark interior pixels away from the light, deeper with age
        var rec = (1 - clamp01(t * 1.6)) * (A.dist[i] > 1.5 ? 1 : 0.3) * (0.45 + 0.55 * ag) * noise(ax, ay, 2, s + 12);
        r += (VERDIGRIS[0] - r) * rec; g += (VERDIGRIS[1] - g) * rec; b += (VERDIGRIS[2] - b) * rec;
        // cast metal catches the light on its top edges (first look 2026-10-12: without it bronze read as a sepia tint) and
        // carries a broad specular sheen across the form's lit side (second look: still close to sepia): metal is
        // high-contrast, a dark body with bright highlights, where a tint keeps the source's mid-tones
        if (A.top[i]) { r += (255 - r) * 0.5; g += (226 - g) * 0.5; b += (168 - b) * 0.5; }
        else {
          var sheen = clamp01((t - 0.62) * 3.2) * (0.6 + 0.4 * noise(ax, ay, 3, s + 20));
          r += (250 - r) * sheen * 0.55; g += (214 - g) * sheen * 0.55; b += (150 - b) * sheen * 0.55;
          var deep = clamp01((0.42 - t) * 2.6); r *= 1 - deep * 0.45; g *= 1 - deep * 0.45; b *= 1 - deep * 0.4;
        }
      } else if (M === 'gilt' && A.top[i] && hash2(ax, ay, s + 13) < 0.35) { r = 255; g = 250; b = 214; } // glints
      else if (M === 'obsidian' && A.top[i]) { r += (200 - r) * 0.55; g += (204 - g) * 0.55; b += (232 - b) * 0.55; } // specular
      else if (M === 'ice' && A.dist[i] <= 1) { r += (226 - r) * 0.5; g += (248 - g) * 0.5; b += (255 - b) * 0.5; } // cold rim
      // weathering, by age (none at 0)
      if (ag > 0) {
        // lichen grows on surfaces that face up, as round BLOOMS: a cell decides WHERE, the bloom's own jittered centre and
        // radius decide WHAT, sampled over the 3x3 neighbourhood of cells so no bloom is welded to the grid (Figure_Doctrine
        // §26m; first look: single dots along the outline read as fuzz)
        if (below <= 2 * px) {
          var cx = Math.floor(ax / 4), cy = Math.floor(ay / 4), hit = false;
          for (var dy = -1; dy <= 1 && !hit; dy++) for (var dx = -1; dx <= 1 && !hit; dx++) {
            var hx = cx + dx, hy = cy + dy;
            if (hash2(hx, hy, s + 14) >= ag * 0.55) continue;
            var bx = hx * 4 + hash2(hx, hy, s + 17) * 4, byy = hy * 4 + hash2(hx, hy, s + 18) * 4, rad = 0.9 + hash2(hx, hy, s + 19) * 1.4;
            if ((ax + 0.5 - bx) * (ax + 0.5 - bx) + (ay + 0.5 - byy) * (ay + 0.5 - byy) < rad * rad) hit = true;
          }
          if (hit) { var lk = 0.6; r += (LICHEN[0] - r) * lk; g += (LICHEN[1] - g) * lk; b += (LICHEN[2] - b) * lk; }
        }
        // a rain streak runs DOWN from a sky-facing edge and fades over its length
        if (hash2(ax, 0, s + 15) < ag * 0.3 && below < streakLen) { var rs = 0.28 * ag * (1 - below / streakLen); r *= 1 - rs; g *= 1 - rs; b *= 1 - rs; }
        if (y > by1 - 3 * px && hash2(ax, ay, s + 16) < ag * 0.7) { var mk = 0.6; r += (MOSS[0] - r) * mk; g += (MOSS[1] - g) * mk; b += (MOSS[2] - b) * mk; }
      }
      out[o] = r; out[o + 1] = g; out[o + 2] = b; out[o + 3] = src[o + 3] * mat.alpha;
    }
    return out;
  }

  /* ------------------------------------------------------------ blank eyes (a statue has none) */
  /** skin: warm hue, moderate saturation, light value (HSV). Darker or unusual skin tones read as NOT skin, and then nothing is blanked */
  function isSkin(r, g, b) {
    // MEASURED 2026-10-12 (_probe/eye_map.js, Actor1 #0): at s <= 0.68 / v >= 0.45 brown-hair highlights read as skin over
    // twelve rows of hair, so skin is LIGHT and moderately saturated
    var mx = Math.max(r, g, b), mn = Math.min(r, g, b), v = mx / 255, s = mx ? (mx - mn) / mx : 0, hh;
    if (v < 0.68 || s < 0.08 || s > 0.52 || mx !== r) return false;
    hh = 60 * (g - b) / ((mx - mn) || 1);
    return hh >= 0 && hh <= 45;
  }
  /** hue in degrees, saturation, value of an RGB triple, into the shared HSV triple */
  var HSV = [0, 0, 0];
  function hsv(r, g, b) {
    var mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn, hh = 0;
    if (d) { if (mx === r) hh = 60 * (((g - b) / d) % 6); else if (mx === g) hh = 60 * ((b - r) / d + 2); else hh = 60 * ((r - g) / d + 4); }
    if (hh < 0) hh += 360;
    HSV[0] = hh; HSV[1] = mx ? d / mx : 0; HSV[2] = mx / 255; return HSV;
  }
  function hueGap(a, b) { var d = Math.abs(a - b) % 360; return d > 180 ? 360 - d : d; }
  /**
   * Find the eyes and paint the IRIS (and its white highlight) over with the face's own skin, so the strike carves a blank
   * eye under the lid line. Built to fail SAFE (ARCHITECTURE.md buildRisk 1: a wrong guess blanks a mouth or a fringe).
   * MEASURED 2026-10-12 (_probe/eye_map.js): MZ's chibi eyes are large and TOUCH the face outline and the bangs, so the
   * first rule ("a component enclosed by skin") found a pair on 3 of 9 stock front views. This rule finds the FACE as the
   * skin-dense rows of the head band, the HAIR as the dominant hue above it, and an eye as an 8-connected component of
   * IRIS pixels inside the face rows: saturated, not skin, not within 30 degrees of the hair hue, not near-black (the lash
   * line stays, and reads as a carved lid). Front view: the largest pair on overlapping rows, side by side, of similar size.
   * Side view: one component of at least 3 px. Anything else blanks nothing (a brown-eyed, brown-haired face included).
   * @returns {{rgba:Uint8ClampedArray,count:number}} a NEW buffer and how many eye components were blanked (0, 1 or 2)
   */
  function blankEyes(A, src) {
    var w = A.w, h = A.h, out = new Uint8ClampedArray(src.length), bb = A.bbox, i, x, y, o;
    out.set(src);
    if (A.area <= 0) return { rgba: out, count: 0 };
    var y0 = bb.y, y1 = Math.min(h - 1, bb.y + Math.floor(bb.h * 0.6)), sr = 0, sg = 0, sb = 0, sn = 0;
    // the face: the longest run of rows (gaps of up to 2 allowed) holding at least 3 skin pixels
    var fTop = -1, fBot = -1, runTop = -1, gap = 0, bestLen = 0;
    for (y = y0; y <= y1; y++) {
      var cnt = 0;
      for (x = bb.x; x < bb.x + bb.w; x++) { i = y * w + x; o = i * 4; if (A.mask[i] && isSkin(src[o], src[o + 1], src[o + 2])) cnt++; }
      if (cnt >= 3) { if (runTop < 0) runTop = y; gap = 0; if (y - runTop + 1 > bestLen) { bestLen = y - runTop + 1; fTop = runTop; fBot = y; } }
      else if (runTop >= 0 && ++gap > 2) { runTop = -1; gap = 0; }
    }
    if (bestLen < 3) return { rgba: out, count: 0 };
    var sx = 0, fx0 = w, fx1 = -1;
    for (y = fTop; y <= fBot; y++) for (x = bb.x; x < bb.x + bb.w; x++) { i = y * w + x; o = i * 4; if (A.mask[i] && isSkin(src[o], src[o + 1], src[o + 2])) { sr += src[o]; sg += src[o + 1]; sb += src[o + 2]; sn++; sx += x; if (x < fx0) fx0 = x; if (x > fx1) fx1 = x; } }
    // a front-view PAIR is mirrored about the face's centre column; on a side view an eye and a jewel sit on one side
    // (first look 2026-10-12: the pair rule took People1#2's eye and circlet)
    var faceCx = sn ? sx / sn : 0, symTol = Math.max(2, (fx1 - fx0 + 1) * 0.14);
    // the hair hue: the circular mean hue of saturated, non-skin, non-dark pixels ABOVE the face
    var hx = 0, hy = 0, hn = 0;
    for (y = y0; y < fTop; y++) for (x = bb.x; x < bb.x + bb.w; x++) {
      i = y * w + x; o = i * 4; if (!A.mask[i] || isSkin(src[o], src[o + 1], src[o + 2])) continue;
      hsv(src[o], src[o + 1], src[o + 2]); if (HSV[1] < 0.25 || HSV[2] < 0.25) continue;
      hx += Math.cos(HSV[0] * Math.PI / 180); hy += Math.sin(HSV[0] * Math.PI / 180); hn++;
    }
    var hairHue = hn ? (Math.atan2(hy, hx) * 180 / Math.PI + 360) % 360 : -1;
    var iris = new Uint8Array(w * h), label = new Int32Array(w * h), comps = [], stack = [];
    for (y = fTop; y <= fBot; y++) for (x = bb.x; x < bb.x + bb.w; x++) {
      i = y * w + x; o = i * 4; if (!A.mask[i] || A.dist[i] <= 1 || isSkin(src[o], src[o + 1], src[o + 2])) continue;
      hsv(src[o], src[o + 1], src[o + 2]);
      if (HSV[1] >= 0.3 && HSV[2] >= 0.3 && (hairHue < 0 || hueGap(HSV[0], hairHue) > 30)) iris[i] = 1;
    }
    for (y = fTop; y <= fBot; y++) for (x = bb.x; x < bb.x + bb.w; x++) {
      i = y * w + x; if (!iris[i] || label[i]) continue;
      var id = comps.length + 1, c = { px: [], x0: x, x1: x, y0: y, y1: y };
      label[i] = id; stack.length = 0; stack.push(i);
      while (stack.length) {
        var j = stack.pop(), jx = j % w, jy = (j / w) | 0; c.px.push(j);
        if (jx < c.x0) c.x0 = jx; if (jx > c.x1) c.x1 = jx; if (jy < c.y0) c.y0 = jy; if (jy > c.y1) c.y1 = jy;
        for (var ddy = -1; ddy <= 1; ddy++) for (var ddx = -1; ddx <= 1; ddx++) {
          var kx = jx + ddx, ky = jy + ddy; if (kx < 0 || kx >= w || ky < fTop || ky > fBot) continue;
          var k = ky * w + kx; if (iris[k] && !label[k]) { label[k] = id; stack.push(k); }
        }
      }
      comps.push(c);
    }
    var maxPx = Math.max(6, Math.round(bb.w * bb.h * 0.03)), cand = [];
    for (var m = 0; m < comps.length; m++) { var cm = comps[m]; if (cm.px.length >= 2 && cm.px.length <= maxPx) cand.push(cm); }
    var best = null, bestA = 0;
    for (var a = 0; a < cand.length; a++) for (var b2 = a + 1; b2 < cand.length; b2++) {
      var p = cand[a], qq = cand[b2];
      var rowsOverlap = p.y0 <= qq.y1 && qq.y0 <= p.y1, apart = p.x1 < qq.x0 || qq.x1 < p.x0, sizeOk = Math.min(p.px.length, qq.px.length) * 3 >= Math.max(p.px.length, qq.px.length);
      var mirrored = Math.abs((p.x0 + p.x1 + qq.x0 + qq.x1) / 4 - faceCx) <= symTol;
      if (rowsOverlap && apart && sizeOk && mirrored && p.px.length + qq.px.length > bestA) { bestA = p.px.length + qq.px.length; best = [p, qq]; }
    }
    if (!best) {
      var faceMid = fTop + (fBot - fTop) * 0.75, one = null;
      for (var e = 0; e < cand.length; e++) { var ce = cand[e]; if (ce.px.length >= 3 && ce.y1 - ce.y0 >= 1 && ce.y1 <= faceMid && (!one || ce.px.length > one.px.length)) one = ce; }
      if (one) best = [one];
    }
    if (!best || !sn) return { rgba: out, count: 0 };
    sr /= sn; sg /= sn; sb /= sn;
    for (var t = 0; t < best.length; t++) {
      var bc = best[t];
      for (var u = 0; u < bc.px.length; u++) { var po = bc.px[u] * 4; out[po] = sr; out[po + 1] = sg; out[po + 2] = sb; }
      // the iris's white catch-light goes too (a near-white pixel touching the chosen component's box)
      for (y = Math.max(fTop, bc.y0 - 1); y <= Math.min(fBot, bc.y1 + 1); y++) for (x = Math.max(0, bc.x0 - 1); x <= Math.min(w - 1, bc.x1 + 1); x++) {
        i = y * w + x; o = i * 4; if (!A.mask[i]) continue;
        hsv(src[o], src[o + 1], src[o + 2]); if (HSV[1] < 0.15 && HSV[2] > 0.85) { out[o] = sr; out[o + 1] = sg; out[o + 2] = sb; }
      }
    }
    return { rgba: out, count: best.length };
  }

  /* ------------------------------------------------------------ the base, with the name cut into it */
  /**
   * The inscription alphabet: a 5 x 7 block alphabet, copied from CSAF's Bout v1.0.0 (BoutDraw.js BLOCK, shipped and reviewed
   * 2026-10-12), so no new glyph corpus is authored here. Rows top to bottom, '1' = a carved cell.
   */
  var LETTERS = {
    A: ['01110', '10001', '10001', '11111', '10001', '10001', '10001'], B: ['11110', '10001', '11110', '10001', '10001', '10001', '11110'],
    C: ['01111', '10000', '10000', '10000', '10000', '10000', '01111'], D: ['11110', '10001', '10001', '10001', '10001', '10001', '11110'],
    E: ['11111', '10000', '11110', '10000', '10000', '10000', '11111'], F: ['11111', '10000', '11110', '10000', '10000', '10000', '10000'],
    G: ['01111', '10000', '10000', '10011', '10001', '10001', '01111'], H: ['10001', '10001', '11111', '10001', '10001', '10001', '10001'],
    I: ['11111', '00100', '00100', '00100', '00100', '00100', '11111'], J: ['00111', '00001', '00001', '00001', '10001', '10001', '01110'],
    K: ['10001', '10010', '11100', '10010', '10001', '10001', '10001'], L: ['10000', '10000', '10000', '10000', '10000', '10000', '11111'],
    M: ['10001', '11011', '10101', '10001', '10001', '10001', '10001'], N: ['10001', '11001', '10101', '10011', '10001', '10001', '10001'],
    O: ['01110', '10001', '10001', '10001', '10001', '10001', '01110'], P: ['11110', '10001', '10001', '11110', '10000', '10000', '10000'],
    Q: ['01110', '10001', '10001', '10001', '10101', '10010', '01101'], R: ['11110', '10001', '10001', '11110', '10010', '10001', '10001'],
    S: ['01111', '10000', '10000', '01110', '00001', '00001', '11110'], T: ['11111', '00100', '00100', '00100', '00100', '00100', '00100'],
    U: ['10001', '10001', '10001', '10001', '10001', '10001', '01110'], V: ['10001', '10001', '10001', '10001', '01010', '01010', '00100'],
    W: ['10001', '10001', '10001', '10101', '10101', '11011', '10001'], X: ['10001', '01010', '00100', '00100', '01010', '10001', '10001'],
    Y: ['10001', '01010', '00100', '00100', '00100', '00100', '00100'], Z: ['11111', '00010', '00100', '01000', '10000', '10000', '11111'],
    0: ['01110', '10011', '10101', '10101', '11001', '10001', '01110'], 1: ['00100', '01100', '00100', '00100', '00100', '00100', '01110'],
    2: ['01110', '10001', '00001', '00110', '01000', '10000', '11111'], 3: ['11110', '00001', '00001', '01110', '00001', '00001', '11110'],
    4: ['00010', '00110', '01010', '10010', '11111', '00010', '00010'], 5: ['11111', '10000', '11110', '00001', '00001', '10001', '01110'],
    6: ['01110', '10000', '11110', '10001', '10001', '10001', '01110'], 7: ['11111', '00001', '00010', '00100', '01000', '01000', '01000'],
    8: ['01110', '10001', '10001', '01110', '10001', '10001', '01110'], 9: ['01110', '10001', '10001', '01111', '00001', '00001', '01110'],
    '!': ['00100', '00100', '00100', '00100', '00100', '00000', '00100'], '.': ['00000', '00000', '00000', '00000', '00000', '00000', '00100'],
    ':': ['00000', '00100', '00100', '00000', '00100', '00100', '00000'], '-': ['00000', '00000', '00000', '01110', '00000', '00000', '00000'],
    ' ': ['00000', '00000', '00000', '00000', '00000', '00000', '00000'],
  };
  var NAME_MAX = 24;
  /**
   * Draw the base a statue stands on, in the statue's material: a cap (lit top, shadowed underside), a die with the name CUT
   * in (each letter cell a dark core, the cell under it a lit lower lip, light from above) and a two-step foot. Every size
   * is derived: the die is as wide as the wider of the figure and the name (wing §24d: never a typed width). Characters the
   * alphabet lacks are carved as a space AND reported in `missing` (§21c: never skipped silently).
   * @param {string} id material id (unknown -> granite)
   * @param {number} figW the figure's bounding-box width in screen pixels
   * @param {string} name the inscription (upper-cased; at most NAME_MAX characters, else fit is false and nothing is drawn)
   * @param {number} px the art's native pixel scale (1..4)
   * @returns {{rgba:Uint8ClampedArray|null,w:number,h:number,fit:boolean,missing:string[],carved:number,lips:number}}
   */
  function base(id, figW, name, px, age, seed) {
    var M = MATERIALS[id] ? id : 'granite', mat = MATERIALS[M], s = (seed >>> 0) || 1, ag = clamp01((+age || 0) / 100);
    px = px >= 1 && px <= 4 ? px | 0 : 1;
    var str = String(name == null ? '' : name).toUpperCase(), missing = [], k;
    if (str.length > NAME_MAX) return { rgba: null, w: 0, h: 0, fit: false, missing: missing, carved: 0, lips: 0 };
    var text = '';
    for (k = 0; k < str.length; k++) { var ch = str[k]; if (LETTERS[ch]) text += ch; else { text += ' '; missing.push(ch); } }
    var textW = text.length ? text.length * 6 - 1 : 0, figN = Math.ceil(Math.max(1, +figW || 1) / px);
    var dieW = Math.max(figN + 2, textW + 6), Wn = dieW + 8, CAP = 3, DIE = 11, Hn = CAP + DIE + 4;
    var w = Wn * px, h = Hn * px, out = new Uint8ClampedArray(w * h * 4), carved = 0, lips = 0;
    var cut = new Uint8Array(Wn * Hn), tx0 = Math.floor((Wn - textW) / 2), ty0 = CAP + 2, c, r;
    for (k = 0; k < text.length; k++) {
      var rows = LETTERS[text[k]];
      for (r = 0; r < 7; r++) for (c = 0; c < 5; c++) if (rows[r][c] === '1') cut[(ty0 + r) * Wn + tx0 + k * 6 + c] = 1;
    }
    for (var ny = 0; ny < Hn; ny++) for (var nx = 0; nx < Wn; nx++) {
      // the silhouette and the light of each part (light from above, as on the statue)
      var t = -1, face = true;
      if (ny < CAP) { if (nx >= 2 && nx < Wn - 2) t = ny === 0 ? 0.86 : ny === 1 ? 0.68 : 0.36; }
      else if (ny < CAP + DIE) { if (nx >= 4 && nx < Wn - 4) { t = nx === 4 ? 0.64 : nx === Wn - 5 ? 0.4 : 0.55; face = true; } }
      else if (ny < CAP + DIE + 2) { if (nx >= 2 && nx < Wn - 2) t = ny === CAP + DIE ? 0.8 : 0.44; }
      else t = ny === CAP + DIE + 2 ? 0.74 : 0.3;
      if (t < 0) continue;
      var ni = ny * Wn + nx, isCut = cut[ni] === 1, isLip = !isCut && ny > 0 && cut[ni - Wn] === 1;
      // a cut is a groove IN SHADOW (the material's darkest tone, halved) and its lower lip catches the light (the ramp's
      // top). MEASURED 2026-10-12 (core.test 9): cut and lip at t 0.2 / 0.8 read 2.26:1 on marble and 1.94:1 on obsidian,
      // under AA-large; a face no ink can be read on is a defect in the PLATE (wing §25h)
      if (isCut) { t = 0.03; carved++; } else if (isLip) { t = 0.97; lips++; }
      else if (face) t += mat.amp * 0.7 * surface(M, null, 0, nx, ny, s);
      var inlay = isCut && mat.inlay && MATERIALS[mat.inlay];
      var col = inlay ? rampAt(inlay.ramp, 0.62 + (ny - ty0 < 2 ? 0.2 : 0)) : rampAt(mat.ramp, t), rr = col[0], gg = col[1], bb2 = col[2];
      if (isCut && !inlay) { rr *= 0.5; gg *= 0.5; bb2 *= 0.5; }
      if (ag > 0 && !isCut) {
        if (ny >= CAP + DIE && hash2(nx, ny, s + 21) < ag * 0.6) { rr += (MOSS[0] - rr) * 0.6; gg += (MOSS[1] - gg) * 0.6; bb2 += (MOSS[2] - bb2) * 0.6; }
        else if (ny === 0 && hash2(nx, 0, s + 22) < ag * 0.5) { rr += (LICHEN[0] - rr) * 0.55; gg += (LICHEN[1] - gg) * 0.55; bb2 += (LICHEN[2] - bb2) * 0.55; }
      }
      for (var yy = 0; yy < px; yy++) for (var xx = 0; xx < px; xx++) {
        var o = ((ny * px + yy) * w + nx * px + xx) * 4;
        out[o] = rr; out[o + 1] = gg; out[o + 2] = bb2; out[o + 3] = 255 * mat.alpha;
      }
    }
    return { rgba: out, w: w, h: h, fit: true, missing: missing, carved: carved * px * px, lips: lips * px * px, cut: cut, wn: Wn };
  }

  /* ------------------------------------------------------------ petrification: stone climbing from the feet */
  /**
   * One frame of the creep at fraction t (0 = living, 1 = statue). The stone line rises from the figure's feet to its crown;
   * per native column it is broken by up to one native pixel either way, so the front is ragged, and the two native rows
   * just above it are DUST: the stone's own colour lifted toward its ramp top on a scatter, so the line reads as stone
   * spreading, never as a wipe. Rows above stay exactly the living figure; rows below are exactly the statue. Baked, never
   * shaded per frame (ARCHITECTURE.md: the frame gate).
   * @returns {Uint8ClampedArray} a NEW buffer
   */
  function creep(A, living, statue, t, seed) {
    var w = A.w, n = w * A.h, out = new Uint8ClampedArray(living.length), s = (seed >>> 0) || 1, px = A.px > 0 ? A.px : 1;
    t = clamp01(+t || 0);
    if (t <= 0) { out.set(living); return out; }
    if (t >= 1) { out.set(statue); return out; }
    out.set(living);
    var bot = A.bbox.y + A.bbox.h, top = A.bbox.y, line = bot - (bot - top) * t; // the line, in screen rows (stone below it)
    for (var i = 0; i < n; i++) {
      if (!A.mask[i]) continue;
      var x = i % w, y = (i / w) | 0, ax = Math.floor(x / px), o = i * 4;
      var edge = line + (Math.floor(hash2(ax, 0, s + 30) * 3) - 1) * px; // ragged by a native pixel either way
      if (y >= edge) { out[o] = statue[o]; out[o + 1] = statue[o + 1]; out[o + 2] = statue[o + 2]; out[o + 3] = statue[o + 3]; }
      else if (y >= edge - 2 * px && hash2(ax, Math.floor(y / px), s + 31 + ((t * 10) | 0)) < 0.45) {
        out[o] = statue[o] + (255 - statue[o]) * 0.35; out[o + 1] = statue[o + 1] + (255 - statue[o + 1]) * 0.35; out[o + 2] = statue[o + 2] + (255 - statue[o + 2]) * 0.35; out[o + 3] = living[o + 3];
      }
    }
    return out;
  }
  /** bake `frames` creep frames from just-touched to whole (t = k / frames, k = 1..frames); the last equals the statue */
  function bakeCreep(A, living, statue, frames, seed) {
    var list = [], f = Math.max(2, frames | 0);
    for (var k = 1; k <= f; k++) list.push(creep(A, living, statue, k / f, seed));
    return list;
  }

  /* ------------------------------------------------------------ the notetag */
  /**
   * Parse a <statue: ...> value as MZ delivers it. DataManager.extractMetadata keeps everything after the colon, INCLUDING
   * the space (Probe_Doctrine §35b), and a bare <statue> arrives as `true`. Tokens, comma-separated, any order after the
   * source: `actor N` | `enemy N` | `self` (default self), a material id (default granite), `age N` (0..100), `name Text`
   * or `name: Text` (a name cannot contain a comma). Nothing is ignored silently: every token not understood lands in
   * `errors` (wing §21c), and ids are compared as numbers, never tested for truthiness (wing §16).
   * @param {string|boolean} value
   * @returns {{source:string,id:number,material:string,age:number,name:(string|null),errors:string[]}}
   */
  function parseStatueTag(value) {
    // materialGiven / ageGiven say whether the note named them, so the engine can fall back to its parameters (a note
    // that names nothing must not silently mean "granite, age 0" when the buyer chose another default)
    var r = { source: 'self', id: 0, material: 'granite', age: 0, name: null, materialGiven: false, ageGiven: false, errors: [] };
    if (value === true || value == null) return r;
    var parts = String(value).split(','), m;
    for (var k = 0; k < parts.length; k++) {
      var tok = parts[k].trim(), low = tok.toLowerCase();
      if (!tok) continue;
      if ((m = /^(actor|enemy)\s+(\S+)$/.exec(low))) {
        var n = Number(m[2]);
        if (Number.isInteger(n) && n > 0) { r.source = m[1]; r.id = n; } else r.errors.push('"' + tok + '": the id must be a whole number from 1');
      } else if (low === 'self') { r.source = 'self'; r.id = 0; }
      else if (MATERIALS[low]) { r.material = low; r.materialGiven = true; }
      else if ((m = /^age\s*:?\s*(\S+)$/.exec(low))) {
        var a = Number(m[1]);
        if (isFinite(a)) { r.age = a < 0 ? 0 : a > 100 ? 100 : a; r.ageGiven = true; if (a < 0 || a > 100) r.errors.push('"' + tok + '": age is 0 to 100, used ' + r.age); }
        else r.errors.push('"' + tok + '": age must be a number');
      } else if ((m = /^name\s*:?\s*(.+)$/i.exec(tok))) r.name = m[1].trim();
      else r.errors.push('"' + tok + '": not understood (expected actor N, enemy N, self, ' + MATERIAL_IDS.join('/') + ', age N or name Text)');
    }
    return r;
  }

  return { analyse: analyse, pixelScale: pixelScale, bandScale: bandScale, baseScale: baseScale, strike: strike, blankEyes: blankEyes, isSkin: isSkin, base: base, creep: creep, bakeCreep: bakeCreep, parseStatueTag: parseStatueTag, LETTERS: LETTERS, NAME_MAX: NAME_MAX, surface: surface, rampAt: rampAt, seedOf: seedOf, MATERIALS: MATERIALS, MATERIAL_IDS: MATERIAL_IDS, VERSION: '1.0.0' };
})();
if (typeof module === 'object' && module.exports) module.exports = PlinthCore;
