//=============================================================================
// EmbraceCore.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Embrace core - composes two characters' walking
 * sheets into one pair pose: hug, kiss, hold hands, carry, dance and more.
 * Place BELOW PostureCore and ABOVE Embrace.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 * @base PostureCore
 * @orderAfter PostureCore
 *
 * @help
 * The pixel rules of Embrace. No parameters or commands of its own;
 * Embrace.js is the file you configure. Needs PostureCore.js (shipped with
 * Embrace) installed and listed above it.
 *
 * Pure logic on RGBA pixel arrays: nothing here touches the screen.
 *
 * HOW A PAIR IS MADE. Both characters are measured by PostureCore on their
 * own standing frames (head, neck, hip, the arms found from their walk).
 * The two figures are then placed on one canvas, feet on one floor, at the
 * distance the pose asks for (bodies pressed together for a hug, faces
 * touching for a kiss, an arm's length for a handshake), found by comparing
 * the two silhouettes row by row. An arm that reaches for the partner is the
 * character's OWN arm, cut out along the pixels that swing in its walk and
 * turned about its shoulder: whole pixels, never resampled or blended. A
 * figure that lies, kneels or sits takes PostureCore's own frame for it.
 * Overlap is ordered per facing: the arm that wraps a partner is drawn over
 * them, the figure nearer the camera over the one behind.
 *
 * The only pixels that are not the characters' own are the outline closing
 * the side of a body whose arm was moved, and the small flourishes (a heart,
 * a note, a sweat drop, a burst) Embrace.js can switch off.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var EmbraceCore = (function () {
  'use strict';

  var PC = null;
  /** ⛔ PostureCore is resolved at FIRST USE, never at load time: the buyer chooses the load order (wing §8 trap 2). */
  function core() {
    if (!PC) PC = (typeof window !== 'undefined' && window.PostureCore) || (typeof window === 'undefined' && typeof require === 'function' ? require('./PostureCore.js') : null);
    if (!PC) throw new Error('Embrace needs PostureCore.js installed and ON in the Plugin Manager, above EmbraceCore.js.');
    return PC;
  }

  var DIRS = [2, 4, 6, 8];
  var FLOUR = 16;      // rows above the taller head kept free for a flourish
  var DEPTH = 6;       // rows the figure further from the camera stands above the nearer one (front and back views)
  /**
   * Every pair pose. `kind`: 'axis' = the two stand face to face on neighbouring tiles (the sheet's row is the axis:
   * the leader's facing toward the partner), 'move' = the pair moves as one with the leader (the row is the leader's
   * facing, the column its walking step). `anim`: 'still' (one picture), 'loop' (the flourish rises, 0-1-2-1),
   * 'once' (plays 0 -> 1 -> 2 and holds), 'dance' (the rows turn on a clock), 'walk' (the columns are walking steps).
   * `flourish`: what is drawn over the pair when flourishes are on.
   */
  var POSES = {
    hug:       { kind: 'axis', anim: 'still', flourish: null },
    kiss:      { kind: 'axis', anim: 'loop',  flourish: 'heart' },
    handshake: { kind: 'axis', anim: 'loop',  flourish: null },
    highfive:  { kind: 'axis', anim: 'once',  flourish: 'burst' },
    bow:       { kind: 'axis', anim: 'once',  flourish: null },
    dance:     { kind: 'axis', anim: 'dance', flourish: 'note' },
    holdhands: { kind: 'move', anim: 'walk',  flourish: null },
    piggyback: { kind: 'move', anim: 'walk',  flourish: 'sweat' },
    carry:     { kind: 'move', anim: 'walk',  flourish: 'smallheart' },
  };
  var NAMES = Object.keys(POSES);

  /** the flourishes, drawn as pixel art: 'o' outline, 'f' fill, 'h' highlight; colours [outline, fill, highlight] */
  var MARKS = {
    heart:      { rows: ['.oo.oo.', 'ohfofho', 'offfffo', 'offfffo', '.offfo.', '..ofo..', '...o...'], ink: [[96, 22, 44, 255], [226, 64, 92, 255], [255, 176, 186, 255]] },
    smallheart: { rows: ['oo.oo', 'ohfho', 'offfo', '.ofo.', '..o..'], ink: [[96, 22, 44, 255], [234, 92, 118, 255], [255, 184, 196, 255]] },
    note:       { rows: ['...ooo', '...ofo', '...o.o', '...o..', '.ooo..', 'ofho..', 'offo..', '.oo...'], ink: [[40, 32, 52, 255], [250, 236, 196, 255], [255, 255, 240, 255]] },
    sweat:      { rows: ['.o..', '.oo.', 'ohfo', 'offo', 'offo', '.oo.'], ink: [[36, 66, 118, 255], [146, 196, 246, 255], [236, 248, 255, 255]] },
    burst:      { rows: ['...o...', '.o.f.o.', '..ofo..', 'offhffo', '..ofo..', '.o.f.o.', '...o...'], ink: [[120, 74, 20, 255], [255, 220, 96, 255], [255, 252, 220, 255]] },
  };
  function mark(cell, type, cx, top) {
    var m = MARKS[type]; if (!m) return 0;
    var w = m.rows[0].length, x0 = Math.round(cx - w / 2), n = 0;
    for (var y = 0; y < m.rows.length; y++) for (var x = 0; x < w; x++) {
      var ch = m.rows[y].charAt(x), c = ch === 'o' ? m.ink[0] : ch === 'f' ? m.ink[1] : ch === 'h' ? m.ink[2] : null;
      if (c && x0 + x >= 0 && top + y >= 0 && x0 + x < cell.w && top + y < cell.h) { cell.paint(x0 + x, top + y, c); n++; }
    }
    return n;
  }

  // ---- one character, measured once --------------------------------------------------------------------------------
  /** a character of a sheet, measured: its frames, PostureCore's measure, its arms (front and back views), palette */
  function figure(img, name, index) {
    var C = core(), L = C.layout(img.width, img.height, name, index), st = {}, wk = {}, k;
    for (k = 0; k < 4; k++) { var d = DIRS[k]; st[d] = C.frameOf(img, L, d, 1); wk[d] = [C.frameOf(img, L, d, 0), st[d], C.frameOf(img, L, d, 2)]; }
    var M = C.measure(st[2]); if (!M) return null;
    var bb = C.bbox(st[2]);
    var f = { img: img, name: name, index: index, L: L, st: st, wk: wk, M: M, foot: L.ch - 1 - bb.bottom, poses: {} };
    f.arms2 = withFallback(st[2], C.armsFromWalk(st[2], wk[2][0], wk[2][2], M), M);
    f.arms8 = withFallback(st[8], C.armsFromWalk(st[8], wk[8][0], wk[8][2], M), M);
    f.pal = C.palette([st[2], st[4], st[6], st[8]], M, st[2]);
    return f;
  }
  /**
   * ⛔ PostureCore's walk-found arms come back null where a sheet's walk swings nothing at the silhouette (every CSAF
   * Townsfolk, Bighead and Tall fixture, MEASURED 2026-10-27 by _probe/arm_debug.js; Posture itself falls back to a
   * fixed block there, `armBlock`). The same block becomes a MASK here: the outer fifth of the figure from the neck to
   * two rows under the hip (40% of the height on a robe), its opaque pixels only.
   */
  function withFallback(src, found, M) {
    var C = core(), out = [found && found[0] || null, found && found[1] || null], bb = C.bbox(src); if (!bb) return out;
    for (var s = 0; s < 2; s++) {
      if (out[s] && out[s].mask) continue;
      var aw = Math.max(2, Math.round(bb.width * 0.2)), x0 = s === 0 ? bb.left : bb.right - aw + 1, x1 = x0 + aw - 1;
      var y0 = M.neck + 1, y1 = Math.min(bb.bottom - 3, M.skirted ? M.neck + Math.round(M.height * 0.4) : M.hip + 2);
      var mk = new Uint8Array(src.w * src.h), n = 0;
      for (var y = y0; y <= y1; y++) for (var x = x0; x <= x1; x++) if (src.on(x, y)) { mk[y * src.w + x] = 1; n++; }
      if (n < 6 || y1 - y0 < 3) continue;
      out[s] = { x0: x0, x1: x1, y0: y0, y1: y1, walked: false, n: n, fallback: true };
      Object.defineProperty(out[s], 'mask', { value: mk, enumerable: false });
    }
    return out;
  }
  /** one frame of a PostureCore pose for a figure (row = facing, column 1), built once per figure */
  function postureFrame(f, pose, row) {
    var C = core();
    if (!f.poses[pose]) f.poses[pose] = C.derive(f.img, f.name, f.index, pose, { lift: 0 });
    var s = f.poses[pose]; if (!s) return null;
    var c = new C.Cell(s.cw, s.ch);
    for (var y = 0; y < s.ch; y++) for (var x = 0; x < s.cw; x++) {
      var i = ((row * s.ch + y) * s.width + s.cw + x) * 4, o = (y * s.cw + x) * 4;
      // ⛔ PostureCore lays a soft translucent shadow on the FLOOR under a lying or kneeling figure; lifted into someone's
      // arms it would hang in mid-air, so only the figure's own opaque pixels are taken
      if (s.data[i + 3] < 255) continue;
      c.d[o] = s.data[i]; c.d[o + 1] = s.data[i + 1]; c.d[o + 2] = s.data[i + 2]; c.d[o + 3] = s.data[i + 3];
    }
    return c;
  }
  /** the near arm of a figure facing `face` (+1 right, -1 left): its RIGHT arm when facing right, which a down-facing
   *  frame draws on the screen's LEFT (arms2[0]); its left arm when facing left (arms2[1]) */
  function nearArm(f, face) { return face > 0 ? f.arms2[0] : f.arms2[1]; }

  // ---- whole-pixel helpers ------------------------------------------------------------------------------------------
  function copyCell(c) { var C = core(), o = new C.Cell(c.w, c.h); o.d.set(c.d); return o; }
  /** copy every opaque pixel of `src` into `out` at offset (dx, dy); `skip(x, y)` (source coords) leaves a pixel out */
  function stamp(out, src, dx, dy, skip) {
    /* ⛔ A half-pixel offset (an arm pivot sits between two columns) made Cell.put write at a FRACTIONAL index, which
     * shifts every channel by two bytes: the green landed in the alpha and the figure drew as a translucent green ghost
     * (holdhands, CSAF_Bighead#2 + Tall_Warden, 766 partial-alpha px from opaque sheets; _probe/ghost_debug2.js
     * 2026-10-27). Every placement is a whole pixel. */
    dx = Math.round(dx); dy = Math.round(dy);
    var n = 0;
    for (var y = 0; y < src.h; y++) for (var x = 0; x < src.w; x++) if (src.on(x, y) && !(skip && skip(x, y))) { out.put(x + dx, y + dy, src, x, y); n++; }
    return n;
  }
  /** the vertical shift (-3..3) that best lines walk frame `f` up with the standing frame over the torso rows */
  function bobOf(stand, f, M) {
    var best = 0, bestN = -1;
    for (var dy = -3; dy <= 3; dy++) {
      var n = 0;
      for (var y = M.neck + 1; y < M.hip; y++) for (var x = 0; x < stand.w; x++) if (stand.on(x, y) && same(stand, f, x, y, dy)) n++;
      if (n > bestN || (n === bestN && Math.abs(dy) < Math.abs(best))) { bestN = n; best = dy; }
    }
    return best;
  }
  function same(a, b, x, y, dy) {
    var yy = y + dy; if (yy < 0 || yy >= b.h) return false;
    var i = (y * a.w + x) * 4, j = (yy * b.w + x) * 4;
    return a.d[i] === b.d[j] && a.d[i + 1] === b.d[j + 1] && a.d[i + 2] === b.d[j + 2] && a.d[i + 3] === b.d[j + 3];
  }
  /**
   * A figure with its HANGING arm taken away (the arm is about to be drawn reaching for the partner, and a person has
   * one right arm). Front and back views: the arm's own pixels (PostureCore's walk-found mask) are erased and a torso
   * pixel left open beside them takes the outline colour, so the body's side is closed again. Side views: the standing
   * pixels of the torso band that differ from BOTH walking frames are the arm at rest (it swings away in both
   * directions); each is replaced by what the first walking frame shows there once the arm has swung away.
   */
  function withoutArm(src, ab, ink) {
    var c = copyCell(src), W = src.w, x, y; if (!ab || !ab.mask) return c;
    var mk = ab.mask;
    for (y = ab.y0; y <= ab.y1; y++) for (x = ab.x0; x <= ab.x1; x++) if (mk[y * W + x]) c.erase(x, y);
    for (y = ab.y0; y <= ab.y1; y++) for (x = ab.x0 - 1; x <= ab.x1 + 1; x++) {
      if (x < 0 || x >= W || mk[y * W + x] || !c.on(x, y)) continue;
      if ((x > 0 && mk[y * W + x - 1] && !c.on(x - 1, y)) || (x < W - 1 && mk[y * W + x + 1] && !c.on(x + 1, y))) c.paint(x, y, ink);
    }
    return c;
  }
  function withoutSideArm(f, dir) {
    var st = f.st[dir], w0 = f.wk[dir][0], w2 = f.wk[dir][2], M = f.M, c = copyCell(st), n = 0;
    var d0 = bobOf(st, w0, M), d2 = bobOf(st, w2, M), y1 = Math.min(st.h - 1, M.hip + 1);
    for (var y = M.neck + 2; y <= y1; y++) for (var x = 0; x < st.w; x++) {
      if (!st.on(x, y) || same(st, w0, x, y, d0) || same(st, w2, x, y, d2)) continue;
      var yy = y + d0; if (yy < 0 || yy >= w0.h) continue;
      if (w0.on(x, yy)) { c.put(x, y, w0, x, yy); } else c.erase(x, y);
      n++;
    }
    c.armTaken = n;
    return c;
  }
  /** the arm mask's pivot (its shoulder: the middle of its top row, one row down, as PostureCore's raiseMasked) */
  function pivotOf(src, ab) {
    var W = src.w, l = W, r = -1;
    for (var x = ab.x0; x <= ab.x1; x++) if (ab.mask[ab.y0 * W + x]) { if (x < l) l = x; if (x > r) r = x; }
    if (r < 0) { l = ab.x0; r = ab.x1; }
    return { x: (l + r) / 2, y: ab.y0 + 1, len: ab.y1 - ab.y0 };
  }
  /**
   * Draw a figure's own arm (mask `ab` of frame `src`) turned about its shoulder so it points `deg` degrees away from
   * hanging straight down, toward the screen's right when `s` is +1 and its left when -1, with the shoulder at (tx, ty)
   * on `out`. Every destination pixel takes the nearest source pixel of the arm: whole pixels, nothing blended, no
   * holes. `keep(x, y)` (out coords) may refuse a pixel (an arm that passes behind a head). Returns pixels drawn.
   */
  function drawArm(out, src, ab, tx, ty, deg, s, keep, ink) {
    if (!ab || !ab.mask) return 0;
    var W = src.w, pv = pivotOf(src, ab), a = deg * Math.PI / 180, ca = Math.cos(a), sa = Math.sin(a) * s;
    var R = Math.ceil(pv.len + (ab.x1 - ab.x0) + 3), n = 0, x0 = Math.floor(tx - R), y0 = Math.floor(ty - R), side = 2 * R + 2;
    var drawn = ink ? new Uint8Array(side * side) : null;
    for (var qy = y0; qy <= Math.ceil(ty + R); qy++) for (var qx = x0; qx <= Math.ceil(tx + R); qx++) {
      var rx = qx - tx, ry = qy - ty, sx = Math.round(pv.x + ca * rx - sa * ry), sy = Math.round(pv.y + sa * rx + ca * ry);
      if (sx < ab.x0 || sx > ab.x1 || sy < ab.y0 || sy > ab.y1 || !ab.mask[sy * W + sx]) continue;
      if (qx < 0 || qy < 0 || qx >= out.w || qy >= out.h) continue;
      if (keep && !keep(qx, qy)) continue;
      out.put(qx, qy, src, sx, sy); n++;
      if (drawn) drawn[(qy - y0) * side + (qx - x0)] = 1;
    }
    /* ⛔ An arm laid across a partner's body has NO EDGE on its inner side (a hanging arm's inner side abuts its own
     * torso, which the sprite never outlines), so a sleeve over a coat of the same weight read as part of the coat
     * (contact zoom 2026-10-27). The moved arm is closed by an outline in the character's own darkest colour wherever it
     * borders anything that is not itself, except within 2 px of the shoulder, where it joins its own body. */
    if (drawn && n) {
      for (var yy = 0; yy < side; yy++) for (var xx = 0; xx < side; xx++) {
        if (drawn[yy * side + xx]) continue;
        var nb = (xx > 0 && drawn[yy * side + xx - 1]) || (xx < side - 1 && drawn[yy * side + xx + 1]) || (yy > 0 && drawn[(yy - 1) * side + xx]) || (yy < side - 1 && drawn[(yy + 1) * side + xx]);
        if (!nb) continue;
        var ox = xx + x0, oy = yy + y0;
        if (ox < 0 || oy < 0 || ox >= out.w || oy >= out.h || Math.abs(ox - tx) + Math.abs(oy - ty) <= 3) continue;
        if (keep && !keep(ox, oy)) continue;
        out.paint(ox, oy, ink);
      }
    }
    return n;
  }
  /** the angle (degrees from hanging down) and side that point an arm from shoulder (sx, sy) at point (hx, hy) */
  function aim(sx, sy, hx, hy) { return { deg: Math.atan2(Math.abs(hx - sx), hy - sy) * 180 / Math.PI, s: hx >= sx ? 1 : -1 }; }

  /** a figure placed on the canvas: its cell, its offset, and its measure (head/torso bands in canvas rows) */
  function placed(cell, dx, dy, M, headDip) {
    var hd = headDip || 0;
    return { cell: cell, dx: dx, dy: dy, M: M, head: [M.top + dy + hd, M.neck + dy + hd], torso: [M.neck + 1 + dy, M.hip - 1 + dy] };
  }
  function edgeAt(p, y, right) {
    var yy = y - p.dy; if (yy < 0 || yy >= p.cell.h) return null;
    var c = p.cell, x;
    if (right) { for (x = c.w - 1; x >= 0; x--) if (c.on(x, yy)) return x + p.dx; }
    else { for (x = 0; x < c.w; x++) if (c.on(x, yy)) return x + p.dx; }
    return null;
  }
  function inBand(b, y) { return y >= b[0] && y <= b[1]; }
  /**
   * How far right figure R must move (from its current dx) so that, row by row against figure L on its left, every
   * constraint holds: `all` = the least gap over every shared row, `torso` = over rows where both are torso, `head`
   * where both are head. A gap below zero is an overlap. Returns the shift to ADD to R.dx (every constraint met, the
   * tightest one exactly).
   */
  function separate(Lp, Rp, want) {
    var y0 = Math.max(Lp.dy, Rp.dy), y1 = Math.min(Lp.dy + Lp.cell.h, Rp.dy + Rp.cell.h) - 1, mins = { all: Infinity, torso: Infinity, head: Infinity };
    for (var y = y0; y <= y1; y++) {
      var r = edgeAt(Lp, y, true), l = edgeAt(Rp, y, false); if (r === null || l === null) continue;
      var g = l - r - 1;
      if (g < mins.all) mins.all = g;
      if (inBand(Lp.torso, y) && inBand(Rp.torso, y) && g < mins.torso) mins.torso = g;
      if (inBand(Lp.head, y) && inBand(Rp.head, y) && g < mins.head) mins.head = g;
    }
    var shift = -Infinity;
    for (var k in want) if (want[k] !== undefined && isFinite(mins[k])) shift = Math.max(shift, want[k] - mins[k]);
    return isFinite(shift) ? shift : 0;
  }
  /** the least gap between two placed figures over their shared rows (for tests and the pair report) */
  function gapOf(Lp, Rp) { var s = separate(Lp, Rp, { all: 0 }); return -s; }
  /** a placed figure's column centre at canvas row y (its silhouette's middle), or its whole-figure centre */
  function midAt(p, y) { var l = edgeAt(p, y, false), r = edgeAt(p, y, true); if (l === null) { var b = core().bbox(p.cell); return b ? p.dx + (b.left + b.right) / 2 : p.dx + p.cell.w / 2; } return (l + r) / 2; }
  /** move a figure's head (rows top..neck of the source) by (dx, dy), drawn over the body: a lean or a bow */
  function leanHead(src, M, dx, dy) {
    if (!dx && !dy) return src;
    var C = core(), c = copyCell(src), tmp = new C.Cell(src.w, src.h), x, y, bb = C.bbox(src); if (!bb) return c;
    var top = Math.min(bb.top, M.top);
    for (y = top; y <= M.neck; y++) for (x = 0; x < src.w; x++) if (src.on(x, y)) { tmp.put(x, y, src, x, y); c.erase(x, y); }
    for (y = top; y <= M.neck; y++) for (x = 0; x < src.w; x++) c.put(x + dx, y + dy, tmp, x, y);
    return c;
  }
  /** a standing bow in profile: the upper body tips forward (whole rows slid, more at the head) and the head sinks */
  function bowSide(src, M, face, amount) {
    if (!amount) return src;
    var C = core(), c = new C.Cell(src.w, src.h), x, y, bb = C.bbox(src); if (!bb) return c;
    var top = bb.top, hip = M.hip, span = Math.max(1, hip - top), dip = Math.ceil(amount / 2);
    for (y = hip; y <= bb.bottom; y++) for (x = 0; x < src.w; x++) c.put(x, y, src, x, y);
    for (y = M.neck + 1; y < hip; y++) { var sh = Math.round(amount * (hip - y) / span) * face; for (x = 0; x < src.w; x++) c.put(x + sh, y, src, x, y); }
    var hs = Math.round(amount * (hip - M.neck) / span) * face + face;
    for (y = top; y <= M.neck; y++) for (x = 0; x < src.w; x++) c.put(x + hs, y + dip, src, x, y);
    return c;
  }
  /** the near-eye closed on a profile (kiss) or both eyes on a face: PostureCore's own closeEyes */
  function eyesShut(f, cell, profile) { var C = core(); try { var r = C.closeEyes(cell, f.M, f.pal, profile); return r; } catch (e) { return cell; } }

  // ---- the compositions ---------------------------------------------------------------------------------------------
  /**
   * Two figures face to face in PROFILE: `left` faces right, `right` faces left. Returns the drawn canvas pieces and
   * report. `col` is the animation column. The contact rules per pose are named where they are applied.
   */
  function sideAxis(out, pose, left, right, col, FY, report) {
    var C = core(), Lf = left, Rf = right;
    var lc = Lf.st[6], rc = Rf.st[4];
    var arm = { L: null, R: null }, lean = { L: 0, R: 0 }, want = { all: -2, torso: -1 };
    var hL = Lf.M.height, hR = Rf.M.height, taller = hL >= hR ? 'L' : 'R', dipT = Math.min(4, Math.abs(hL - hR));
    if (pose === 'hug' || pose === 'dance') {
      lc = withoutSideArm(Lf, 6); rc = withoutSideArm(Rf, 4);
      /* ⛔ v1 kept heads from overlapping more than 2 px: on a chibi (head twice the torso's width) the BODIES then stood
       * 8 px apart and the arms read as reaching across a gap, not holding (contact zoom 2026-10-27). The bodies press
       * together and the heads overlap, the left one's in front - cheek to cheek, as a hug is drawn at this size - but
       * never past 60% of the smaller head. */
      var hwL = headW(Lf.st[6], Lf.M), hwR = headW(Rf.st[4], Rf.M), cap = Math.round(Math.min(hwL, hwR) * 0.6);
      want = pose === 'hug' ? { torso: -1, all: -cap } : { torso: 0, all: -Math.round(cap * 0.7) };
    } else if (pose === 'kiss') {
      // ⛔ a kiss is FACES touching: the taller one's head comes down (a lean of up to 4 rows), both lean in a pixel
      var dl = taller === 'L' ? dipT : 0, dr = taller === 'R' ? dipT : 0;
      lc = leanHead(withoutSideArm(Lf, 6), Lf.M, 1, dl); rc = leanHead(withoutSideArm(Rf, 4), Rf.M, -1, dr);
      lc = eyesShut(Lf, lc, true); rc = eyesShut(Rf, rc, true);
      lean.L = dl; lean.R = dr;
      want = { head: -1, all: -2 };
    } else if (pose === 'bow') {
      // ⛔ a 4 px tip was invisible at 1x on every pair (contact sheet 2026-10-27): the deep bow tips a fifth of the figure's height
      var deep = Math.max(4, Math.round(Math.min(Lf.M.height, Rf.M.height) * 0.2)), amt = col === 0 ? 0 : col === 1 ? Math.round(deep / 2) : deep;
      lc = bowSide(Lf.st[6], Lf.M, 1, amt); rc = bowSide(Rf.st[4], Rf.M, -1, amt);
      want = { all: 3 };
    } else if (pose === 'handshake' || pose === 'highfive') {
      lc = withoutSideArm(Lf, 6); rc = withoutSideArm(Rf, 4);
      want = { all: 2 };
    }
    var Lp = placed(lc, 0, FY - Lf.M.bottom, Lf.M, lean.L), Rp = placed(rc, 0, FY - Rf.M.bottom, Rf.M, lean.R);
    var baseL = Math.round(out.w / 2 - lc.w), baseR = Math.round(out.w / 2);
    Lp.dx = baseL; Rp.dx = baseR; Rp.dx += separate(Lp, Rp, want);
    var sL = shoulderOf(Lp), sR = shoulderOf(Rp), abL = nearArm(Lf, 1), abR = nearArm(Rf, -1);
    if (pose === 'handshake' || pose === 'highfive') {
      // the hands meet halfway between the shoulders: at the waist for a handshake, over the heads for a high five
      var lenM = Math.min(abL ? pivotOf(Lf.st[2], abL).len : 10, abR ? pivotOf(Rf.st[2], abR).len : 10);
      var reach = pose === 'handshake' ? Math.round(lenM * Math.sin(62 * Math.PI / 180)) : Math.round(lenM * Math.sin(35 * Math.PI / 180));
      var need = sL.x + 2 * reach - 1 - sR.x; if (need > 0) Rp.dx += need;
      sR = shoulderOf(Rp);
    }
    // centre the PAIR on the canvas (its contact point on the canvas's middle column)
    var lb = C.bbox(lc), rb = C.bbox(rc), pairL = Lp.dx + lb.left, pairR = Rp.dx + rb.right, shiftX = Math.round(out.w / 2 - (pairL + pairR + 1) / 2);
    Lp.dx += shiftX; Rp.dx += shiftX; sL = shoulderOf(Lp); sR = shoulderOf(Rp);
    stamp(out, Rp.cell, Rp.dx, Rp.dy); stamp(out, Lp.cell, Lp.dx, Lp.dy);
    var nL = 0, nR = 0;
    /* ⛔ v1 turned each arm by a FIXED angle from a chibi's high shoulder: the arm crossed both faces or pointed into the
     * air over a shorter partner (looked at, contact zoom 2026-10-27). An arm that holds someone is AIMED at a point on
     * their back (the shoulder line or the waist), passes behind both heads, and stops a pixel past the back's edge. */
    var onHead = function (p, x, y) { var yy = y - p.dy, xx = x - p.dx; return yy >= 0 && yy <= p.M.neck && xx >= 0 && xx < p.cell.w && p.cell.on(xx, yy); };
    var holdR = function (x, y) { if (onHead(Lp, x, y) || onHead(Rp, x, y)) return false; var e = edgeAt(Rp, y, true); return e === null ? false : x <= e + 2; };
    var holdL = function (x, y) { if (onHead(Lp, x, y) || onHead(Rp, x, y)) return false; var e = edgeAt(Lp, y, false); return e === null ? false : x >= e - 2; };
    var backPt = function (p, right, rowFrac) { var y = p.dy + p.M.neck + 1 + Math.round((p.M.hip - p.M.neck - 1) * rowFrac), e = edgeAt(p, y, right); return { x: e === null ? midAt(p, y) : e, y: y }; };
    var hold = function (fig, ab, s, partner, partnerRight, frac, keep) {
      var t = backPt(partner, partnerRight, frac), a = aim(s.x, s.y, t.x, t.y);
      var n = drawArm(out, fig.st[2], ab, s.x, s.y, a.deg, a.s, keep, fig.pal.dark);
      // ⛔ a tall robed figure's arm could not REACH a short partner's back, so the back clip left nothing at all (core.test
      // 2026-10-27, CSAF_Tall_Abbess + Townsfolk#4): the arm then reaches as far as it goes, still never over a head
      if (!n) n = drawArm(out, fig.st[2], ab, s.x, s.y, a.deg, a.s, function (x, y) { return !onHead(Lp, x, y) && !onHead(Rp, x, y); }, fig.pal.dark);
      return n;
    };
    if (pose === 'hug' || pose === 'kiss') {
      // one arm round the partner's shoulders, the other round the waist: the taller one reaches over the shoulders
      var hiL = taller === 'L' ? 0.15 : 0.7, hiR = taller === 'L' ? 0.7 : 0.15;
      if (pose !== 'hug') { hiL = taller === 'L' ? 0.75 : 0.2; hiR = taller === 'L' ? 0.2 : 0.75; }
      nL = hold(Lf, abL, sL, Rp, true, hiL, holdR);
      nR = hold(Rf, abR, sR, Lp, false, hiR, holdL);
    } else if (pose === 'dance') {
      var sway = col === 0 ? -1 : col === 2 ? 1 : 0;
      nL = hold(Lf, abL, sL, Rp, true, 0.7 + sway * 0.1, holdR);
      nR = hold(Rf, abR, sR, Lp, false, 0.1, holdL);
    } else if (pose === 'handshake' || pose === 'highfive') {
      var hy, hx = (sL.x + sR.x) / 2;
      if (pose === 'handshake') hy = Math.max(sL.y, sR.y) + Math.round(lenM * Math.cos(62 * Math.PI / 180)) + (col === 0 ? -1 : col === 2 ? 1 : 0);
      else hy = Math.min(sL.y, sR.y) - Math.round(lenM * Math.cos(35 * Math.PI / 180)) + (col === 0 ? -3 : 0);
      var spread = pose === 'highfive' && col === 0 ? 3 : 0;
      var aL = aim(sL.x, sL.y, hx - spread, hy), aR = aim(sR.x, sR.y, hx + spread, hy);
      nL = drawArm(out, Lf.st[2], abL, sL.x, sL.y, aL.deg, aL.s, null, Lf.pal.dark);
      nR = drawArm(out, Rf.st[2], abR, sR.x, sR.y, aR.deg, aR.s, null, Rf.pal.dark);
      report.hands = [Math.round(hx), Math.round(hy)];
    }
    report.gap = gapOf(Lp, Rp); report.arms = [nL, nR]; report.contact = Math.round((sL.x + sR.x) / 2);
    report.top = Math.min(Lp.dy + C.bbox(Lp.cell).top, Rp.dy + C.bbox(Rp.cell).top);
    report.armTaken = [lc.armTaken || 0, rc.armTaken || 0];
    return report;
  }
  /** the widest row of a frame's head (rows top..neck), in pixels */
  function headW(src, M) { var w = 0; for (var y = M.top; y <= M.neck; y++) { var rr = core().runs(src, y); if (rr.length) w = Math.max(w, rr[rr.length - 1][1] - rr[0][0] + 1); } return w || 8; }
  /** the shoulder a profile's near arm turns about: the torso's middle column, two rows under the neck */
  function shoulderOf(p) { var y = p.M.neck + 2 + p.dy; return { x: Math.round(midAt(p, y)), y: y }; }

  /**
   * Front and back views: `back` faces the camera, `front` stands nearer the camera with its back to us (DEPTH rows
   * lower). The figure facing the camera wraps its arms round the nearer one; the nearer one's arms go forward round the
   * other and are hidden by its own body, so they are taken away.
   */
  function vertAxis(out, pose, back, front, col, FY, report) {
    var C = core(), kc = back.st[2], fc = front.st[8], ink = back.pal.dark;
    var gapRows = DEPTH;
    if (pose === 'bow') {
      var amt = col === 0 ? 0 : col === 1 ? 2 : 3;
      kc = leanHead(back.st[2], back.M, 0, amt); fc = leanHead(front.st[8], front.M, 0, amt);
      gapRows = DEPTH + 8;
    } else if (pose === 'handshake' || pose === 'highfive') {
      gapRows = DEPTH + 6;
    }
    var wrap = pose === 'hug' || pose === 'kiss' || pose === 'dance';
    if (wrap) { kc = withoutArm(kc, back.arms2[0], ink); kc = withoutArm(kc, back.arms2[1], ink); fc = withoutArm(fc, front.arms8[0], front.pal.dark); fc = withoutArm(fc, front.arms8[1], front.pal.dark); }
    if (pose === 'kiss') { kc = leanHead(kc, back.M, 0, Math.min(3, 1 + Math.max(0, back.M.height - front.M.height))); kc = eyesShut(back, kc, false); }
    if (pose === 'handshake' || pose === 'highfive') { kc = withoutArm(kc, back.arms2[0], ink); fc = withoutArm(fc, front.arms8[1], front.pal.dark); }
    var kb = C.bbox(kc), fb = C.bbox(fc);
    /* ⛔ v1 stood the two on one column: the nearer figure hid the other completely and the pair read as ONE person
     * (contact sheet 2026-10-27). The one facing the camera stands a little to the side, so its face shows over the
     * nearer one's shoulder; the pair is centred on the canvas. */
    var off = Math.round((kb.right - kb.left + 1) * 0.42);
    var Kp = placed(kc, Math.round(out.w / 2 - (kb.left + kb.right + 1) / 2) + Math.ceil(off / 2), FY - gapRows - back.M.bottom, back.M);
    var Fp = placed(fc, Math.round(out.w / 2 - (fb.left + fb.right + 1) / 2) - Math.floor(off / 2), FY - front.M.bottom, front.M);
    var sway = pose === 'dance' ? (col === 0 ? -1 : col === 2 ? 1 : 0) : 0;
    Kp.dx += sway; Fp.dx += sway;
    stamp(out, Kp.cell, Kp.dx, Kp.dy); stamp(out, Fp.cell, Fp.dx, Fp.dy);
    var cx = Fp.dx + (fb.left + fb.right + 1) / 2, nL = 0, nR = 0;
    var p0 = back.arms2[0] && pivotOf(back.st[2], back.arms2[0]), p1 = back.arms2[1] && pivotOf(back.st[2], back.arms2[1]);
    if (wrap) {
      // both arms round the nearer figure's back, aimed at its spine below the shoulder blades; they cross its back
      // (drawn over it) and never over a head
      var onH = function (p, x, y) { var yy = y - p.dy, xx = x - p.dx; return yy >= 0 && yy <= p.M.neck && xx >= 0 && xx < p.cell.w && p.cell.on(xx, yy); };
      var onBack = function (x, y) { if (onH(Kp, x, y) || onH(Fp, x, y)) return false; var xx = x - Fp.dx, yy = y - Fp.dy; return xx >= -1 && yy >= 0 && xx <= Fp.cell.w && yy < Fp.cell.h && (Fp.cell.on(xx, yy) || Fp.cell.on(xx - 1, yy) || Fp.cell.on(xx + 1, yy) || Kp.cell.on(x - Kp.dx, y - Kp.dy)); };
      var ty = Fp.dy + front.M.neck + 2 + Math.round((front.M.hip - front.M.neck) * (pose === 'dance' ? 0.45 : 0.3));
      var lo = function (x, y) { return x <= cx + 1 && onBack(x, y); }, hi = function (x, y) { return x >= cx - 1 && onBack(x, y); };
      if (p0) { var a0 = aim(p0.x + Kp.dx, p0.y + Kp.dy, cx, ty); nL = drawArm(out, back.st[2], back.arms2[0], p0.x + Kp.dx, p0.y + Kp.dy, a0.deg, a0.s, lo, back.pal.dark); }
      if (p1) {
        if (pose === 'dance') nR = drawArm(out, back.st[2], back.arms2[1], p1.x + Kp.dx, p1.y + Kp.dy, 140, 1, function (x, y) { return !onH(Kp, x, y) && !onH(Fp, x, y); }, back.pal.dark);   // the other hand held up and out
        else { var a1 = aim(p1.x + Kp.dx, p1.y + Kp.dy, cx, ty); nR = drawArm(out, back.st[2], back.arms2[1], p1.x + Kp.dx, p1.y + Kp.dy, a1.deg, a1.s, hi, back.pal.dark); }
      }
    } else if (pose === 'handshake' || pose === 'highfive') {
      // the camera-facing one's right hand (screen left) meets the other's right hand (screen right, seen from behind)
      var q = front.arms8[1] && pivotOf(front.st[8], front.arms8[1]);
      var sx1 = p0 ? p0.x + Kp.dx : cx - 4, sy1 = p0 ? p0.y + Kp.dy : Kp.dy + back.M.neck + 2, sx2 = q ? q.x + Fp.dx : cx + 4, sy2 = q ? q.y + Fp.dy : Fp.dy + front.M.neck + 2;
      var len = Math.min(p0 ? p0.len : 10, q ? q.len : 10), hx = (sx1 + sx2) / 2;
      var hy = pose === 'handshake' ? Math.max(sy1, sy2) + Math.round(len * 0.55) + (col === 1 ? 1 : 0) : Math.min(sy1, sy2) - Math.round(len * 0.8) + (col === 0 ? -2 : 0);
      var a1 = aim(sx1, sy1, hx, hy), a2 = aim(sx2, sy2, hx, hy);
      if (p0) nL = drawArm(out, back.st[2], back.arms2[0], sx1, sy1, a1.deg, a1.s, null, back.pal.dark);
      if (q) nR = drawArm(out, front.st[8], front.arms8[1], sx2, sy2, a2.deg, a2.s, null, front.pal.dark);
      report.hands = [Math.round(hx), Math.round(hy)];
    }
    report.arms = [nL, nR]; report.gap = -1; report.contact = Math.round(cx);
    report.top = Math.min(Kp.dy + kb.top, Fp.dy + fb.top);
    return report;
  }
  /** a figure's walking frame with the standing UPPER body (rows above the hip) and the walking LEGS, lined up by bob */
  function walkBody(f, dir, col) {
    if (col === 1) return f.st[dir];
    var C = core(), st = f.st[dir], wk = f.wk[dir][col], c = new C.Cell(st.w, st.h), b = bobOf(st, wk, f.M), x, y;
    for (y = 0; y < f.M.hip; y++) for (x = 0; x < st.w; x++) c.put(x, y, st, x, y);
    for (y = f.M.hip; y < st.h; y++) for (x = 0; x < st.w; x++) { var yy = y + b; if (yy >= 0 && yy < wk.h) c.put(x, y, wk, x, yy); }
    return c;
  }

  /** HOLD HANDS, walking: A holds B's left hand in its right, so B walks on A's right (screen left facing the camera) */
  function holdHands(out, A, B, dir, col, FY, report) {
    var C = core();
    if (dir === 2 || dir === 8) {
      // facing the camera: B on the screen's left; walking away: B on the screen's right
      var lf = dir === 2 ? B : A, rt = dir === 2 ? A : B, arms = dir === 2 ? 'arms2' : 'arms8';
      var la = lf[arms][1], ra = rt[arms][0];   // the inner arms: the left figure's screen-right arm, the right figure's screen-left
      var lc = withoutArm(walkBody(lf, dir, col), la, lf.pal.dark), rc = withoutArm(walkBody(rt, dir, col), ra, rt.pal.dark);
      var Lp = placed(lc, Math.round(out.w / 2 - lc.w), FY - lf.M.bottom, lf.M), Rp = placed(rc, Math.round(out.w / 2), FY - rt.M.bottom, rt.M);
      Rp.dx += separate(Lp, Rp, { all: 2 });
      var pl = la && pivotOf(lf.st[dir], la), pr = ra && pivotOf(rt.st[dir], ra);
      var len = Math.min(pl ? pl.len : 10, pr ? pr.len : 10);
      if (pl && pr) {
        // the shoulders far enough apart for two arms at ~22 degrees to meet: never closer than the bodies allow
        var D = (pr.x + Rp.dx) - (pl.x + Lp.dx), want = Math.round(2 * len * Math.sin(22 * Math.PI / 180)) + 1;
        if (D < want) Rp.dx += Math.ceil(want - D);
      }
      var lb = C.bbox(lc), rb = C.bbox(rc), shiftX = Math.round(out.w / 2 - (Lp.dx + lb.left + Rp.dx + rb.right + 1) / 2);
      Lp.dx += shiftX; Rp.dx += shiftX;
      stamp(out, Lp.cell, Lp.dx, Lp.dy); stamp(out, Rp.cell, Rp.dx, Rp.dy);
      var n1 = 0, n2 = 0;
      if (pl && pr) {
        var s1 = { x: pl.x + Lp.dx, y: pl.y + Lp.dy }, s2 = { x: pr.x + Rp.dx, y: pr.y + Rp.dy }, hx = (s1.x + s2.x) / 2;
        var hy = Math.max(s1.y, s2.y) + Math.round(Math.sqrt(Math.max(1, len * len - Math.pow((s2.x - s1.x) / 2, 2))));
        var a1 = aim(s1.x, s1.y, hx, hy), a2 = aim(s2.x, s2.y, hx, hy);
        n1 = drawArm(out, lf.st[dir], la, s1.x, s1.y, a1.deg, a1.s, null, lf.pal.dark); n2 = drawArm(out, rt.st[dir], ra, s2.x, s2.y, a2.deg, a2.s, null, rt.pal.dark);
        report.hands = [Math.round(hx), Math.round(hy)];
      }
      report.arms = [n1, n2]; report.gap = gapOf(Lp, Rp); report.top = Math.min(Lp.dy + lb.top, Rp.dy + rb.top);
      return report;
    }
    // in profile: B walks on A's right, which is the NEARER side facing right and the far side facing left
    var face = dir === 6 ? 1 : -1, near = face > 0 ? B : A, far = face > 0 ? A : B;
    var nc = walkBody(near, dir, col), fc = walkBody(far, dir, col), nb = C.bbox(nc), fbb = C.bbox(fc);
    // ⛔ 3 px either side let the nearer one hide most of the farther one in the store GIF (looked at, frame 20,
    // 2026-10-27): they walk a third of a body apart, the farther one a step behind
    var sep = Math.max(5, Math.round(Math.min(fbb.right - fbb.left, nb.right - nb.left) / 3));
    var Fp = placed(fc, Math.round(out.w / 2 - (fbb.left + fbb.right + 1) / 2) - face * sep, FY - DEPTH - far.M.bottom, far.M);
    var Np = placed(nc, Math.round(out.w / 2 - (nb.left + nb.right + 1) / 2) + face * Math.ceil(sep / 2), FY - near.M.bottom, near.M);
    stamp(out, Fp.cell, Fp.dx, Fp.dy); stamp(out, Np.cell, Np.dx, Np.dy);
    report.arms = [0, 0]; report.gap = -1; report.top = Math.min(Fp.dy + fbb.top, Np.dy + nb.top);
    return report;
  }

  /** PIGGYBACK, walking: the carrier walks; the carried rides on its back, legs round its waist, arms over its shoulders */
  function piggyback(out, carrier, rider, dir, col, FY, report) {
    var C = core(), cc = walkBody(carrier, dir, col), cb = C.bbox(cc), CM = carrier.M;
    var Cp = placed(cc, Math.round(out.w / 2 - (cb.left + cb.right + 1) / 2), FY - CM.bottom, CM);
    var rs = rider.st[dir], RM = rider.M, rb = C.bbox(rs);
    // the rider's hip sits high on the carrier's back. ⛔ At the mid-back (0.55) the rider's head hid behind the carrier's
    // own head seen from the front, and the pair read as one person (plates, looked at 2026-10-27): at a quarter of the way
    // down the back the rider's face clears the carrier's head
    var hipY = Cp.dy + CM.neck + Math.round((CM.hip - CM.neck) * 0.25), rdy = hipY - RM.hip;
    var face = dir === 6 ? 1 : dir === 4 ? -1 : 0, cmid = Cp.dx + (cb.left + cb.right + 1) / 2;
    var back = face ? Math.round((cb.right - cb.left + 1) * 0.42) : 0;
    var rdx = Math.round(cmid - (rb.left + rb.right + 1) / 2) - face * back;
    var upper = function (x, y) { return y >= RM.hip; }, legs = function (x, y) { return y < RM.hip; };
    var n = 0, nArm = 0, armsCell = rs;
    if (dir === 2 || dir === 8) {
      var aset = dir === 2 ? rider.arms2 : rider.arms8, body = withoutArm(withoutArm(rs, aset[0], rider.pal.dark), aset[1], rider.pal.dark);
      var mid = Math.round((rb.left + rb.right) / 2), spread = Math.max(2, Math.round((cb.right - cb.left + 1) / 2) - Math.round((rb.right - rb.left + 1) / 4));
      var legLift = Math.max(0, RM.legLen - 2);
      var drawLegs = function () {
        stamp(out, rs, rdx - spread, rdy - legLift, function (x, y) { return y < RM.hip || x > mid; });
        stamp(out, rs, rdx + spread, rdy - legLift, function (x, y) { return y < RM.hip || x <= mid; });
      };
      if (dir === 2) {
        // seen from the front, the rider is BEHIND the carrier: rider first, carrier over, then the rider's arms over the
        // shoulders - never over the carrier's head (they pass behind it, as PostureCore's raised arms do)
        drawLegs(); n += stamp(out, body, rdx, rdy, upper);
        stamp(out, Cp.cell, Cp.dx, Cp.dy);
        var headTop = Cp.dy + CM.top, headBot = Cp.dy + CM.neck;
        var notHead = function (x, y) { return !(y >= headTop && y <= headBot && x - Cp.dx >= 0 && x - Cp.dx < cc.w && cc.on(x - Cp.dx, y - Cp.dy)); };
        for (var s = 0; s < 2; s++) { var ab = rider.arms2[s]; if (!ab) continue; var p = pivotOf(rs, ab); nArm += drawArm(out, rs, ab, p.x + rdx, p.y + rdy, 22, s === 0 ? -1 : 1, notHead, rider.pal.dark); }
      } else {
        // seen from behind, the rider is NEARER the camera: carrier first, the rider over it, arms forward round the neck
        stamp(out, Cp.cell, Cp.dx, Cp.dy); drawLegs(); n += stamp(out, body, rdx, rdy, upper);
      }
    } else {
      // in profile the rider sits behind the carrier's back: its lap and shins come forward round the carrier's waist
      var lap = Math.max(2, Math.round((cb.right - cb.left + 1) * 0.5));
      stamp(out, rs, rdx + face * lap, rdy - Math.max(0, RM.legLen - 3), legs);
      n += stamp(out, rs, rdx, rdy, upper);
      stamp(out, Cp.cell, Cp.dx, Cp.dy);
      var hT = Cp.dy + CM.top, hB = Cp.dy + CM.neck;
      var nh = function (x, y) { return !(y >= hT && y <= hB && x - Cp.dx >= 0 && x - Cp.dx < cc.w && cc.on(x - Cp.dx, y - Cp.dy)); };
      var abn = nearArm(rider, face), rp = abn && pivotOf(rider.st[2], abn);
      if (abn) { var sy = rdy + RM.neck + 2, sxx = Math.round(midAt(placed(rs, rdx, rdy, RM), sy)); nArm = drawArm(out, rider.st[2], abn, sxx, sy, 58, face, nh, rider.pal.dark); }
    }
    report.arms = [0, nArm]; report.rider = n; report.gap = -1;
    report.top = Math.min(Cp.dy + cb.top, rdy + rb.top);
    return report;
  }

  /** CARRY in the arms, walking: the carried one lies across the carrier's arms at the chest (PostureCore's lie frame) */
  function carry(out, carrier, held, dir, col, FY, report) {
    var C = core(), cc = walkBody(carrier, dir, col), cb = C.bbox(cc), CM = carrier.M;
    var Cp = placed(cc, Math.round(out.w / 2 - (cb.left + cb.right + 1) / 2), FY - CM.bottom, CM);
    var face = dir === 6 ? 1 : dir === 4 ? -1 : 0;
    // head toward the carrier in profile (head left when facing right); facing the camera the head is on the screen's left
    var lie = postureFrame(held, 'lie', face < 0 ? 2 : 0);
    if (!lie) return report;
    var lb = C.bbox(lie), chestY = Cp.dy + CM.neck + Math.round((CM.hip - CM.neck) * 0.45);
    var ldy = chestY - Math.round((lb.top + lb.bottom) / 2), cmid = Cp.dx + (cb.left + cb.right + 1) / 2;
    // ⛔ a big-head chibi's chest is low and a tall adult lies thick: centred on that chest, the carried one sank through
    // the floor and out of the cell (core.test 2026-10-27, CSAF_Bighead#1 carrying the Tall Warden). It is held clear of it.
    ldy = Math.min(ldy, FY - 3 - lb.bottom);
    var ldx = Math.round(cmid - (lb.left + lb.right + 1) / 2);
    if (face) ldx += face * Math.round((lb.right - lb.left + 1) * 0.5 - 2);
    var nArm = 0;
    if (dir === 8) { stamp(out, lie, ldx, ldy); stamp(out, Cp.cell, Cp.dx, Cp.dy); }
    else {
      stamp(out, Cp.cell, Cp.dx, Cp.dy); stamp(out, lie, ldx, ldy);
      if (face) {
        // the carrier's near arm under the carried one's back, drawn over its lower half
        var ab = nearArm(carrier, face), p = { x: 0 }, sy = Cp.dy + CM.neck + 2, sx = Math.round(midAt(Cp, sy)), midRow = ldy + Math.round((lb.top + lb.bottom) / 2);
        nArm = drawArm(out, carrier.st[2], ab, sx, sy, 72, face, function (x, y) { return y >= midRow - 1; }, carrier.pal.dark);
      }
    }
    report.arms = [nArm, 0]; report.gap = -1; report.top = Math.min(Cp.dy + cb.top, ldy + lb.top);
    return report;
  }

  /**
   * One pair pose for two characters. Returns {width, height, data, cw, ch, pose, frames} - a big-character layout
   * (3 columns x 4 rows; rows = down, left, right, up) that Embrace.js hands to the leader's Sprite_Character, or null
   * when either character's standing frame is empty. For an 'axis' pose the row is the direction from the leader to
   * the partner; for a 'move' pose it is the leader's facing. `opt.flourish` false leaves the marks off.
   * The canvas's bottom-centre is the sprite's anchor: the contact point of an axis pose (Embrace.js moves the sprite
   * half a tile toward the partner), the leader's own feet for a move pose.
   */
  function derive(imgA, nameA, indexA, imgB, nameB, indexB, pose, opt) {
    opt = opt || {};
    var P = POSES[pose]; if (!P) throw new Error('EmbraceCore: unknown pose "' + pose + '" (known: ' + NAMES.join(', ') + ')');
    var C = core(), A = figure(imgA, nameA, indexA), B = figure(imgB, nameB, indexB);
    if (!A || !B) return null;
    var tall = Math.max(A.M.height, B.M.height), cwMax = Math.max(A.L.cw, B.L.cw);
    var W = A.L.cw + B.L.cw + tall + 16;
    // ⛔ hands raised over the heads (and the burst between them) reached the top of the cell on a tall SF sheet
    // (core.test 2026-10-27, SF_People2#4 + Actor2#1): a high five gets a quarter of the taller figure as headroom
    var lift = P.kind === 'move' ? Math.round(tall * 0.75) : pose === 'highfive' ? Math.round(tall * 0.25) : 0;
    var H = Math.max(A.L.ch, B.L.ch) + lift + FLOUR + DEPTH;
    W += W % 2;
    var FY = H - 1 - A.foot, flour = opt.flourish !== false && P.flourish;
    var frames = [], report = [];
    for (var r = 0; r < 4; r++) {
      var dir = DIRS[r], row = [], rrow = [];
      for (var col = 0; col < 3; col++) {
        var cell = new C.Cell(W, H), rep = { dir: dir, col: col };
        if (P.kind === 'axis') {
          if (dir === 6) sideAxis(cell, pose, A, B, col, FY, rep);
          else if (dir === 4) sideAxis(cell, pose, B, A, col, FY, rep);
          else if (dir === 2) vertAxis(cell, pose, A, B, col, FY, rep);
          else vertAxis(cell, pose, B, A, col, FY, rep);
        } else if (pose === 'holdhands') holdHands(cell, A, B, dir, col, FY, rep);
        else if (pose === 'piggyback') piggyback(cell, A, B, dir, col, FY, rep);
        else carry(cell, A, B, dir, col, FY, rep);
        if (flour && (P.anim !== 'once' || col > 0)) {
          var rise = P.anim === 'loop' ? col * 2 : P.anim === 'walk' ? (col === 1 ? 1 : 0) : 0;
          var mx = rep.contact !== undefined ? rep.contact : Math.round(W / 2) + (P.flourish === 'sweat' ? 8 : 0);
          if (P.flourish === 'burst' && rep.hands) { mx = rep.hands[0]; rep.flourish = mark(cell, 'burst', mx, rep.hands[1] - 3 - (col === 1 ? 1 : 0)); }
          else rep.flourish = mark(cell, P.flourish, mx + (P.flourish === 'note' ? (col - 1) * 3 : 0), Math.max(0, rep.top - MARKS[P.flourish].rows.length - 2 - rise));
        }
        row.push(cell); rrow.push(rep);
      }
      frames.push(row); report.push(rrow);
    }
    var out = { width: W * 3, height: H * 4, data: new Uint8ClampedArray(W * 3 * H * 4 * 4), cw: W, ch: H, pose: pose, anim: P.anim, kind: P.kind, report: report, footA: A.foot };
    for (var rr = 0; rr < 4; rr++) for (var cc = 0; cc < 3; cc++) {
      var f = frames[rr][cc];
      for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) {
        var i = (y * W + x) * 4, o = (((rr * H) + y) * out.width + cc * W + x) * 4;
        out.data[o] = f.d[i]; out.data[o + 1] = f.d[i + 1]; out.data[o + 2] = f.d[i + 2]; out.data[o + 3] = f.d[i + 3];
      }
    }
    return out;
  }

  return { VERSION: '1.0.0', POSES: POSES, NAMES: NAMES, MARKS: MARKS, DIRS: DIRS, FLOUR: FLOUR, DEPTH: DEPTH, derive: derive, figure: figure, drawArm: drawArm, separate: separate, placed: placed, gapOf: gapOf, withoutSideArm: withoutSideArm, core: core,
    /** the building blocks, for the test suite (each is pure: frames in, a new frame out) */
    parts: { walkBody: walkBody, withoutArm: withoutArm, leanHead: leanHead, bowSide: bowSide, headW: headW, postureFrame: postureFrame, mark: mark, sideAxis: sideAxis, vertAxis: vertAxis, holdHands: holdHands, piggyback: piggyback, carry: carry } };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = EmbraceCore;
