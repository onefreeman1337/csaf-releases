//=============================================================================
// Embrace.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Embrace - two of your characters hug, kiss, hold
 * hands, carry one another and dance, made from the sheets they already have.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 * @base EmbraceCore
 * @orderAfter EmbraceCore
 *
 * @param flourishes
 * @text Flourishes
 * @type boolean
 * @on Show
 * @off Hide
 * @desc The small marks over a pair: a heart over a kiss, notes over a dance, a sweat drop over a piggyback, a burst on a high five.
 * @default true
 *
 * @param letGoOnMove
 * @text Let go on a step
 * @type boolean
 * @on Let go
 * @off Hold on
 * @desc For the standing poses (hug, kiss, handshake, high five, bow, dance): when either one takes a step, the pose ends.
 * @default true
 *
 * @param danceTurn
 * @text Dance turn
 * @type number
 * @min 10
 * @max 240
 * @desc Frames a dancing pair holds each facing before turning to the next (60 = one second).
 * @default 40
 *
 * @param markFrames
 * @text Flourish speed
 * @type number
 * @min 4
 * @max 60
 * @desc Frames per step of a rising heart or note, and of a bow or high five playing out.
 * @default 12
 *
 * @command Embrace
 * @text Embrace
 * @desc Two characters take a pair pose. The first one leads: for hold hands, piggyback and carry it is the one who walks (and carries).
 *
 * @arg target
 * @text Who
 * @type select
 * @option player
 * @option this event
 * @option event id
 * @option follower
 * @default this event
 *
 * @arg eventId
 * @text Who: event id or follower number
 * @type number
 * @min 0
 * @desc The event id when "Who" is "event id"; the follower number (1 = the first follower) when "Who" is "follower".
 * @default 0
 *
 * @arg partner
 * @text With
 * @type select
 * @option player
 * @option this event
 * @option event id
 * @option follower
 * @default player
 *
 * @arg partnerId
 * @text With: event id or follower number
 * @type number
 * @min 0
 * @default 0
 *
 * @arg pose
 * @text Pose
 * @type select
 * @option hug
 * @option kiss
 * @option handshake
 * @option highfive
 * @option bow
 * @option dance
 * @option holdhands
 * @option piggyback
 * @option carry
 * @default hug
 *
 * @command LetGo
 * @text Let go
 * @desc Ends the pair pose this character leads or is part of.
 *
 * @arg target
 * @text Who
 * @type select
 * @option player
 * @option this event
 * @option event id
 * @option follower
 * @default this event
 *
 * @arg eventId
 * @text Event id or follower number
 * @type number
 * @min 0
 * @default 0
 *
 * @help
 * EMBRACE - two characters touch: a hug, a kiss, a handshake, a high five, a
 * bow, a slow dance, walking hand in hand, a piggyback and a carry in the
 * arms. Every pair pose is made the first time it is used from BOTH
 * characters' own walking sheets, so any two characters in your project can
 * do it on day one. No new art.
 *
 * INSTALL (Plugin Manager, in this order):
 *   PostureCore.js   (shipped with Embrace; Posture users already have it)
 *   EmbraceCore.js
 *   Embrace.js
 *
 * THE POSES
 *   hug        bodies together, arms round each other         4 facings
 *   kiss       faces together, eyes closed, a heart           4 facings
 *   handshake  hands meet between them                        4 facings
 *   highfive   hands meet over their heads, a burst           4 facings
 *   bow        both bow to each other                         4 facings
 *   dance      a close hold that turns through every facing   turning
 *   holdhands  hand in hand; they walk together               walks
 *   piggyback  the partner rides on the leader's back         walks
 *   carry      the leader carries the partner in its arms     walks
 *
 * STANDING POSES (hug, kiss, handshake, highfive, bow, dance): put the two
 * on neighbouring tiles. They turn to face each other and meet halfway.
 * HOLDHANDS, PIGGYBACK, CARRY: the first character leads and walks; the
 * partner goes with it (hidden as a separate sprite, drawn in the pair)
 * until Let go, then steps off beside the leader.
 *
 * PLUGIN COMMANDS
 *   Embrace   (Who, With, Pose)       Let go   (Who)
 * PAGE COMMENT (a Comment command on an event page)
 *   <embrace: hug, 3>        this event hugs event 3 while the page is on
 *   <embrace: holdhands, player>
 * SCRIPT
 *   Embrace.start($gamePlayer, $gameMap.event(3), 'holdhands');
 *   Embrace.start(5, 0, 'hug');      (event ids; 0 is the player)
 *   Embrace.stop(5);   Embrace.get($gamePlayer)  ->  'holdhands' or ''
 *
 * Pair poses are saved with the game. A pair whose partner is an event
 * ends when the player leaves the map. Your image files are never changed:
 * each pair sheet is built once, in memory, the first time it is needed.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var Embrace = (function () {
  'use strict';

  var NAME = 'Embrace';
  var RAW = PluginManager.parameters(NAME);
  var CORE = null;
  /** ⛔ The siblings are resolved at FIRST USE, never at load time: the buyer chooses the load order (wing §8 trap 2). */
  function deps() { if (!CORE) CORE = window.EmbraceCore; if (!CORE) throw new Error('Embrace needs EmbraceCore.js (and PostureCore.js) installed and ON in the Plugin Manager.'); CORE.core(); return CORE; }

  /** ⛔ parameters arrive as strings; "" is ABSENT, never zero (wing §16) */
  function num(v, def, lo, hi) { if (v === undefined || v === null || String(v).trim() === '') return def; var n = Number(v); return isFinite(n) ? Math.max(lo, Math.min(hi, Math.round(n))) : def; }
  function bool(v, def) { if (v === undefined || v === null || String(v).trim() === '') return def; return String(v) !== 'false'; }
  var P = {
    flourish: bool(RAW.flourishes, true),
    letGo: bool(RAW.letGoOnMove, true),
    turn: num(RAW.danceTurn, 40, 10, 240),
    mark: num(RAW.markFrames, 12, 4, 60),
  };
  var POSE_NAMES = ['hug', 'kiss', 'handshake', 'highfive', 'bow', 'dance', 'holdhands', 'piggyback', 'carry'];
  var MOVING = { holdhands: true, piggyback: true, carry: true };
  var DANCE_ROWS = [0, 1, 3, 2];   // sheet rows down, left, up, right: a quarter turn at a time
  var SCHEMA = 1;

  function normal(pose) { var p = String(pose === undefined || pose === null ? '' : pose).trim().toLowerCase(); return POSE_NAMES.indexOf(p) >= 0 ? p : ''; }

  // ---- who is who: a saved reference, never an object (lossless save round-trip) ----------------------------------
  /** {k:'p'} the player · {k:'e', id} an event of the current map · {k:'f', id} a follower (1 = the first) */
  function refOf(ch) {
    if (!ch) return null;
    if (ch === $gamePlayer) return { k: 'p', id: 0 };
    if (typeof Game_Follower !== 'undefined' && ch instanceof Game_Follower) { var fl = $gamePlayer.followers()._data, i = fl.indexOf(ch); return i >= 0 ? { k: 'f', id: i + 1 } : null; }
    if (typeof Game_Event !== 'undefined' && ch instanceof Game_Event) return { k: 'e', id: ch.eventId() };
    return null;
  }
  function charOf(r) {
    if (!r) return null;
    if (r.k === 'p') return $gamePlayer;
    if (r.k === 'f') return $gamePlayer.followers().follower(r.id - 1) || null;
    if (r.k === 'e') return $gameMap.event(r.id) || null;
    return null;
  }
  /** a character from a script argument: a character, 0 (the player) or an event id */
  function asChar(t) { return typeof t === 'number' ? (t === 0 ? $gamePlayer : $gameMap.event(t) || null) : t || null; }

  /** the direction (2/4/6/8) from one character to a neighbour, or 0 when they are not neighbours */
  function dirTo(a, b) {
    var dx = $gameMap.deltaX(b.x, a.x), dy = $gameMap.deltaY(b.y, a.y);
    if (Math.abs(dx) + Math.abs(dy) !== 1) return 0;
    return dx > 0 ? 6 : dx < 0 ? 4 : dy > 0 ? 2 : 8;
  }

  // ---- starting and ending a pair ----------------------------------------------------------------------------------
  /**
   * Start a pair pose: `a` leads, `b` is the partner. A standing pose turns the two to face each other (they must be
   * neighbours; otherwise the leader's facing is the side the partner is drawn on). Returns true when the pose started.
   */
  function start(a, b, pose) {
    a = asChar(a); b = asChar(b); pose = normal(pose);
    if (!a || !b || a === b || !pose) return false;
    // a pair is drawn from two character SHEETS: a tile-image event or one with no image has none (refused, not half-made)
    if (!a.characterName() || !b.characterName() || a.tileId() > 0 || b.tileId() > 0) return false;
    var ra = refOf(a), rb = refOf(b); if (!ra || !rb) return false;
    stop(a); stop(b);
    var dir = MOVING[pose] ? a.direction() : (dirTo(a, b) || a.direction());
    if (!MOVING[pose]) { a.setDirection(dir); b.setDirection(10 - dir); }
    a._csafEmbrace = { v: SCHEMA, pose: pose, w: rb, dir: dir };
    b._csafHeldBy = { v: SCHEMA, by: ra, pose: pose, through: !!b._through };
    if (MOVING[pose]) b._through = true;
    return true;
  }
  /** end whatever pair this character leads or is held in; a walked-with partner steps off beside the leader */
  function stop(c) {
    c = asChar(c); if (!c) return false;
    var done = false;
    if (c._csafEmbrace) {
      var b = charOf(c._csafEmbrace.w), moving = MOVING[c._csafEmbrace.pose];
      c._csafEmbrace = null; done = true;
      if (b && b._csafHeldBy) { release(b, c, moving); }
    }
    if (c._csafHeldBy) {
      var a = charOf(c._csafHeldBy.by);
      if (a && a._csafEmbrace) a._csafEmbrace = null;
      release(c, a, MOVING[c._csafHeldBy.pose]);
      done = true;
    }
    return done;
  }
  /** the partner is free again: through restored; after a walk it stands on the first open tile beside the leader */
  function release(b, a, moving) {
    var h = b._csafHeldBy; b._csafHeldBy = null;
    if (h) b._through = h.through;
    if (!moving || !a || b === $gamePlayer) return;
    var d = a.direction(), sides = [d === 2 || d === 8 ? 4 : 2, d === 2 || d === 8 ? 6 : 8, 10 - d];
    for (var i = 0; i < 3; i++) {
      var x2 = $gameMap.roundXWithDirection(a.x, sides[i]), y2 = $gameMap.roundYWithDirection(a.y, sides[i]);
      if (a.canPass(a.x, a.y, sides[i]) && !$gameMap.eventsXyNt(x2, y2).length) { b.locate(x2, y2); b.setDirection(d); return; }
    }
  }

  // ---- the character side --------------------------------------------------------------------------------------
  /** the pose this character LEADS ('' = none) */
  Game_CharacterBase.prototype.csafEmbrace = function () { return this._csafEmbrace ? this._csafEmbrace.pose : ''; };
  /** true while this character is drawn as part of another's pair */
  Game_CharacterBase.prototype.csafHeld = function () { return !!this._csafHeldBy; };

  var _update = Game_CharacterBase.prototype.update;
  /** a partner in a walking pose goes where the leader goes (no allocation: fields copied in place) */
  Game_CharacterBase.prototype.update = function () {
    _update.apply(this, arguments);
    /* ⛔ an ERASED event is gone from the map but still an object: a carrier kept drawing an erased rider in its pair, and a
     * carried one stayed hidden after its carrier was erased (breakit_engine.js 2026-10-27). Either side gone ends it. */
    var e = this._csafEmbrace;
    if (e) { var w = charOf(e.w); if (!w || w._erased || this._erased) { stop(this); return; } }
    var h = this._csafHeldBy; if (!h) return;
    var a = charOf(h.by);
    if (!a || a._erased || !a._csafEmbrace) { stop(this); return; }
    if (!MOVING[h.pose]) return;
    this._x = a._x; this._y = a._y; this._realX = a._realX; this._realY = a._realY; this._direction = a._direction;
  };
  var _increaseSteps = Game_CharacterBase.prototype.increaseSteps;
  /** a step ends a STANDING pose (either one), when "Let go on a step" is on */
  Game_CharacterBase.prototype.increaseSteps = function () {
    _increaseSteps.apply(this, arguments);
    if (!P.letGo) return;
    if (this._csafEmbrace && !MOVING[this._csafEmbrace.pose]) stop(this);
    else if (this._csafHeldBy && !MOVING[this._csafHeldBy.pose]) stop(this);
  };
  var _canMove = Game_Player.prototype.canMove;
  /** a player who is being carried (or led by the hand) by someone else does not walk on its own */
  Game_Player.prototype.canMove = function () { return this._csafHeldBy && MOVING[this._csafHeldBy.pose] ? false : _canMove.apply(this, arguments); };
  var _performTransfer = Game_Player.prototype.performTransfer;
  /** leaving the map ends a pair with an EVENT of that map in it (followers come along) */
  Game_Player.prototype.performTransfer = function () {
    if (this.isTransferring() && $gameMap.mapId() !== this._newMapId) {
      if (this._csafEmbrace && this._csafEmbrace.w.k === 'e') stop(this);
      if (this._csafHeldBy && this._csafHeldBy.by.k === 'e') stop(this);
    }
    _performTransfer.apply(this, arguments);
  };

  /** the <embrace: pose, who> of the active page's comments (who: an event id, or "player"), else null */
  function fromPage(ev) {
    var page = ev.page(), list = page && page.list;
    if (list) for (var i = 0; i < list.length; i++) {
      var c = list[i]; if (c.code !== 108 && c.code !== 408) continue;
      var m = /<embrace:\s*([a-z]+)\s*,\s*([a-z0-9]+)\s*>/i.exec(String(c.parameters[0] || ''));
      if (m) return { pose: m[1], who: /^player$/i.test(m[2]) ? 0 : Number(m[2]) };
    }
    return null;
  }
  var _setupPageSettings = Game_Event.prototype.setupPageSettings;
  /** a page with an <embrace: ...> comment starts that pair (once the partner exists on the map) */
  Game_Event.prototype.setupPageSettings = function () {
    _setupPageSettings.apply(this, arguments);
    var e = fromPage(this);
    if (e && isFinite(e.who)) { if (!this._csafPagePair || this._csafPagePair.pose !== normal(e.pose) || this._csafPagePair.who !== e.who) this._csafPagePair = { pose: normal(e.pose), who: e.who, done: false }; }
    else { if (this._csafPagePair && this._csafEmbrace) stop(this); this._csafPagePair = null; }
  };
  var _mapUpdate = Game_Map.prototype.update;
  /**
   * A page pair starts ONCE per page: on the first map frame after the page comes on (every event exists by then).
   * ⛔ v1 re-started it whenever the pair was missing, so a step could never end it (it re-formed the next frame) and a
   * pair started by script with the same partner was stolen back (in_engine.js 2026-10-27, three checks red).
   */
  Game_Map.prototype.update = function () {
    _mapUpdate.apply(this, arguments);
    var evs = this._events;
    for (var i = 0; i < evs.length; i++) {
      var ev = evs[i]; if (!ev || !ev._csafPagePair || ev._csafPagePair.done) continue;
      var pp = ev._csafPagePair;
      if (start(ev, pp.who, pp.pose)) pp.done = true;
    }
  };

  // ---- the sprite side: one pair sheet per (both sheets, pose, flourish) -----------------------------------------------
  var CACHE = {};
  var SOURCE = {};   // the pixels of each loaded sheet, read once (wing §27a: never read pixels during play)
  function pixels(name) {
    if (SOURCE[name]) return SOURCE[name];
    var src = ImageManager.loadCharacter(name);
    if (!src || !src.isReady() || !src.width) return null;
    SOURCE[name] = { width: src.width, height: src.height, data: src.context.getImageData(0, 0, src.width, src.height).data };
    return SOURCE[name];
  }
  /** the pair sheet for two loaded sheets, or null while either is still loading / when there is nothing to draw */
  function sheetFor(nameA, indexA, nameB, indexB, pose) {
    var C = deps(), key = nameA + '|' + indexA + '|' + nameB + '|' + indexB + '|' + pose + '|' + (P.flourish ? 1 : 0);
    if (CACHE[key] !== undefined) return CACHE[key];
    var a = pixels(nameA), b = pixels(nameB); if (!a || !b) return null;
    var out = C.derive(a, nameA, indexA, b, nameB, indexB, pose, { flourish: P.flourish });
    var bmp = null;
    if (out) {
      bmp = new Bitmap(out.width, out.height);
      bmp.context.putImageData(new ImageData(out.data, out.width, out.height), 0, 0);
      bmp._baseTexture.update();
      bmp._csafPair = { pose: pose, cw: out.cw, ch: out.ch, anim: out.anim, kind: out.kind, tops: out.report.map(function (row) { return row[1].top; }) };
    }
    CACHE[key] = bmp;
    return bmp;
  }

  var _updateBitmap = Sprite_Character.prototype.updateBitmap;
  /** a leader shows the pair sheet; the comparisons below allocate nothing per frame */
  Sprite_Character.prototype.updateBitmap = function () {
    _updateBitmap.apply(this, arguments);
    var ch = this._character, e = ch && !this._tileId && this._characterName ? ch._csafEmbrace : null;
    var b = e ? charOf(e.w) : null;
    if (!e || !b || !b.characterName()) {
      if (this._csafPairBmp) { this.bitmap = ImageManager.loadCharacter(this._characterName); this._csafPairBmp = null; this._csafPairPose = ''; if (ch) READY.delete(ch); }
      return;
    }
    if (this._csafPairBmp && this._csafPairPose === e.pose && this._csafPairA === this._characterName && this._csafPairIA === this._characterIndex &&
      this._csafPairB === b.characterName() && this._csafPairIB === b.characterIndex()) return;
    var bmp = sheetFor(this._characterName, this._characterIndex, b.characterName(), b.characterIndex(), e.pose);
    if (!bmp) return;
    this.bitmap = bmp; this._csafPairBmp = bmp; this._csafPairPose = e.pose; this._csafPairT0 = Graphics.frameCount; READY.set(ch, bmp);
    this._csafPairA = this._characterName; this._csafPairIA = this._characterIndex; this._csafPairB = b.characterName(); this._csafPairIB = b.characterIndex();
  };

  /** leaders whose sprite is showing its pair sheet right now (runtime only, never saved; a WeakMap so a lookup per
   *  frame allocates nothing - the first version built a cache key string per partner per frame) */
  var READY = new WeakMap();
  var _updateVisibility = Sprite_Character.prototype.updateVisibility;
  /** the partner's own sprite is hidden while the leader's sprite shows the pair (never before: no empty frame) */
  Sprite_Character.prototype.updateVisibility = function () {
    _updateVisibility.apply(this, arguments);
    var h = this._character && this._character._csafHeldBy;
    if (h) { var a = charOf(h.by); if (a && a._csafEmbrace && READY.get(a)) this.visible = false; }
  };

  var _updatePosition = Sprite_Character.prototype.updatePosition;
  /** a standing pair meets halfway: the sheet's anchor (the contact point) moves half a tile toward the partner */
  Sprite_Character.prototype.updatePosition = function () {
    _updatePosition.apply(this, arguments);
    var b = this._csafPairBmp, e = b && this._character._csafEmbrace; if (!e || b._csafPair.kind !== 'axis') return;
    var d = e.dir;
    this.x += (d === 6 ? 1 : d === 4 ? -1 : 0) * $gameMap.tileWidth() / 2;
    this.y += (d === 2 ? 1 : d === 8 ? -1 : 0) * $gameMap.tileHeight() / 2;
  };

  // the engine's own frame math, saved one per statement and CALLED for every character that leads no pair
  var _blockX = Sprite_Character.prototype.characterBlockX;
  var _blockY = Sprite_Character.prototype.characterBlockY;
  var _patX = Sprite_Character.prototype.characterPatternX;
  var _patY = Sprite_Character.prototype.characterPatternY;
  var _pw = Sprite_Character.prototype.patternWidth;
  var _ph = Sprite_Character.prototype.patternHeight;
  /** a pair sheet holds ONE pair, laid out like a '$' sheet: no block offset */
  Sprite_Character.prototype.characterBlockX = function () { return this._csafPairBmp ? 0 : _blockX.apply(this, arguments); };
  Sprite_Character.prototype.characterBlockY = function () { return this._csafPairBmp ? 0 : _blockY.apply(this, arguments); };
  Sprite_Character.prototype.patternWidth = function () { return this._csafPairBmp ? this._csafPairBmp._csafPair.cw : _pw.apply(this, arguments); };
  Sprite_Character.prototype.patternHeight = function () { return this._csafPairBmp ? this._csafPairBmp._csafPair.ch : _ph.apply(this, arguments); };
  /** the row: a standing pair keeps the side it was started on; a dance turns on a clock; a walking pair faces its way */
  Sprite_Character.prototype.characterPatternY = function () {
    var b = this._csafPairBmp; if (!b) return _patY.apply(this, arguments);
    var info = b._csafPair, e = this._character._csafEmbrace;
    if (info.anim === 'dance') return DANCE_ROWS[Math.floor((Graphics.frameCount - this._csafPairT0) / P.turn) % 4];
    if (info.kind === 'axis' && e) return (e.dir - 2) / 2;
    return _patY.apply(this, arguments);
  };
  /** the column: walking pairs step with the leader; rising flourishes cycle 0-1-2-1; a bow or high five plays once */
  Sprite_Character.prototype.characterPatternX = function () {
    var b = this._csafPairBmp; if (!b) return _patX.apply(this, arguments);
    var info = b._csafPair, t = Graphics.frameCount - this._csafPairT0;
    if (info.anim === 'walk') return _patX.apply(this, arguments);
    if (info.anim === 'still') return 1;
    if (info.anim === 'once') return Math.min(2, Math.floor(t / P.mark));
    var s = Math.floor(t / (info.anim === 'dance' ? P.turn / 2 : P.mark)) % 4; return s === 3 ? 1 : s;
  };

  // ---- commands and the script API -------------------------------------------------------------------------------
  function who(kind, id, interp) {
    kind = String(kind || 'this event');
    if (kind === 'player') return $gamePlayer;
    if (kind === 'follower') return $gamePlayer.followers().follower(Math.max(1, Number(id) || 1) - 1) || null;
    var n = kind === 'event id' ? Number(id) : (interp && interp.eventId ? interp.eventId() : 0);
    return n > 0 ? $gameMap.event(n) || null : null;
  }
  PluginManager.registerCommand(NAME, 'Embrace', function (args) { start(who(args.target, args.eventId, this), who(args.partner, args.partnerId, this), args.pose); });
  PluginManager.registerCommand(NAME, 'LetGo', function (args) { stop(who(args.target, args.eventId, this)); });

  return {
    VERSION: '1.0.0', P: P, POSE_NAMES: POSE_NAMES, MOVING: MOVING, CACHE: CACHE, SOURCE: SOURCE, deps: deps, normal: normal, refOf: refOf, charOf: charOf, dirTo: dirTo, fromPage: fromPage, sheetFor: sheetFor,
    /** Embrace.start(leader, partner, pose) - characters, or 0 (the player) / an event id */
    start: start,
    stop: stop,
    /** the pose a character leads or is held in ('' = none) */
    get: function (t) { var c = asChar(t); if (!c) return ''; return c._csafEmbrace ? c._csafEmbrace.pose : c._csafHeldBy ? c._csafHeldBy.pose : ''; },
  };
}());
