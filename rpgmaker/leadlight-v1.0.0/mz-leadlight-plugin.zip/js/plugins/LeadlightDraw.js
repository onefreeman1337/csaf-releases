/*:
 * @target MZ
 * @plugindesc Leadlight 2/3 - the look: stained-glass panes generated from your picture, shards, the lead bar, the window frame. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * LeadlightDraw.js - part of Leadlight v1.0.0. Enable it with LeadlightCore.js
 * and Leadlight.js (any order). It has no commands or parameters of its own.
 *
 * Every line of this plugin was written with AI assistance.
 */
/*
 * Everything here draws into a 2D canvas context, and only when something CHANGES (a cell cracks or breaks, the HUD
 * numbers move), never per frame. The pane's colours come from LeadlightCore.paneFromPixels: each cell is glazed in the
 * colour of the picture beneath it, so the player first sees a stained-glass version of the picture and then breaks it.
 */
var LeadlightDraw = (function () {
  'use strict';
  var FACE = '"Palatino Linotype", "Book Antiqua", Palatino, Georgia, serif';
  var STYLES = ['leaded', 'cathedral', 'frost', 'brick'];
  var LEAD = '#1c1a1e', LEAD_HI = 'rgba(190,186,196,0.55)', GILT = '#c9a14a', GILT_HI = '#f1d98a';

  function rng(seed) { var s = (seed >>> 0) || 1; return function () { s = (Math.imul(s, 1103515245) + 12345) >>> 0; return ((s >>> 8) & 0xffffff) / 0x1000000; }; }
  function clamp(v) { return v < 0 ? 0 : v > 255 ? 255 : Math.round(v); }
  function css(r, g, b, a) { return 'rgba(' + clamp(r) + ',' + clamp(g) + ',' + clamp(b) + ',' + (a == null ? 1 : a) + ')'; }
  /** rgb -> hsl (0..1) and back */
  function hsl(r, g, b) { r /= 255; g /= 255; b /= 255; var mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, h = 0, s = 0; if (mx !== mn) { var d = mx - mn; s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn); h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h /= 6; } return [h, s, l]; }
  function rgb(h, s, l) { function f(p, q, t) { if (t < 0) t += 1; if (t > 1) t -= 1; if (t < 1 / 6) return p + (q - p) * 6 * t; if (t < 1 / 2) return q; if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6; return p; } if (s === 0) return [l * 255, l * 255, l * 255]; var q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q; return [f(p, q, h + 1 / 3) * 255, f(p, q, h) * 255, f(p, q, h - 1 / 3) * 255]; }

  /**
   * The glass colour of a cell in a style. Glass is LIT from behind: a cell keeps the picture's hue, gains saturation
   * and is held in a luminous band so a dark picture does not become a pane of mud (gate1Risk, research record).
   */
  function glass(c, style) {
    var h = hsl(c.r, c.g, c.b), H = h[0], S = h[1], L = h[2];
    if (style === 'cathedral') { S = Math.min(1, 0.45 + S * 0.9); L = 0.22 + L * 0.42; }
    else if (style === 'frost') { S = S * 0.35; L = 0.68 + L * 0.26; }
    else if (style === 'brick') { S = Math.min(1, S * 0.75 + 0.08); L = 0.20 + L * 0.50; }
    else { S = Math.min(1, 0.25 + S * 0.85); L = 0.26 + L * 0.50; }
    return rgb(H, S, L);
  }

  /**
   * The GLASS: the picture itself, re-coloured the way the style's glass would colour it, drawn ONCE when a game starts
   * (never per frame) into a W x H canvas the cells are then cut from. LOOKED AT 2026-10-11 (pane_sheet.js): a pane of
   * flat mean colours read as a grid of tiles in which the picture could not be recognised, so the pane is now the
   * picture rendered in glass, and breaking a cell swaps the glass for the true picture beneath.
   *   leaded    saturated, posterised to 6 levels, a touch brighter (lit from behind)
   *   cathedral deep jewel tones: strongly saturated, darker, posterised to 4 levels
   *   frost     the picture blurred and paled, as through ice
   *   brick     not used (brick cells are fired clay in the cell's mean colour)
   * @param {CanvasImageSource} src the picture; it is COVER-fitted exactly as the scene draws it
   */
  function glassImage(src, sw, sh, W, H, style) {
    var cv = document.createElement('canvas'); cv.width = W; cv.height = H; var x = cv.getContext('2d');
    var k = Math.max(W / Math.max(1, sw), H / Math.max(1, sh));
    x.fillStyle = '#08060a'; x.fillRect(0, 0, W, H);
    x.filter = style === 'frost' ? 'blur(5px) brightness(1.25) saturate(0.7)' : (style === 'cathedral' ? 'saturate(2.1) brightness(0.92) contrast(1.15)' : 'saturate(1.6) brightness(1.08) contrast(1.08)');
    x.drawImage(src, (W - sw * k) / 2, (H - sh * k) / 2, sw * k, sh * k); x.filter = 'none';
    if (style === 'frost') { x.fillStyle = 'rgba(232,242,250,0.38)'; x.fillRect(0, 0, W, H); return cv; }
    var levels = style === 'cathedral' ? 4 : 6, step = 255 / (levels - 1), id = x.getImageData(0, 0, W, H), d = id.data;
    for (var i = 0; i < d.length; i += 4) { d[i] = Math.round(d[i] / step) * step; d[i + 1] = Math.round(d[i + 1] / step) * step; d[i + 2] = Math.round(d[i + 2] / step) * step; }
    x.putImageData(id, 0, 0);
    return cv;
  }
  /**
   * Draw ONE cell of the pane in its current state (hitsLeft of maxHits) into ctx. Clears the cell first, so a broken
   * cell (hitsLeft 0) is a clear hole the picture shows through.
   */
  function drawCell(ctx, pane, i, hitsLeft, style, seed, glassCv) {
    var c = pane.cells[i], r = rng((seed >>> 0) ^ Math.imul(i + 1, 2654435761));
    var pad = 2;
    ctx.clearRect(c.x - pad, c.y - pad, c.w + pad * 2, c.h + pad * 2);
    if (hitsLeft <= 0) return;
    var g = glass(c, style), x = c.x, y = c.y, w = c.w, h = c.h;
    ctx.save(); ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
    if (glassCv && style !== 'brick') {
      // the picture in glass, cut from the one-time glass image, then the piece's OWN colour laid over its light and
      // dark (canvas `color` blend: hue and saturation from the glass, luminance from the picture), the way a pane is one
      // coloured glass with the shading painted on. LOOKED AT 2026-10-11: without it the glass was so close to the
      // picture that breaking a cell changed almost nothing and the reveal had no reward.
      ctx.drawImage(glassCv, x, y, w, h, x, y, w, h);
      if (style !== 'frost') {
        ctx.globalCompositeOperation = 'color'; ctx.fillStyle = css(g[0], g[1], g[2], style === 'cathedral' ? 0.85 : 0.7); ctx.fillRect(x, y, w, h);
        ctx.globalCompositeOperation = 'source-over';
      }
    } else {
      var lg = ctx.createLinearGradient(x, y, x + w, y + h);
      lg.addColorStop(0, css(g[0] * 1.18 + 14, g[1] * 1.18 + 14, g[2] * 1.18 + 14, 0.95)); lg.addColorStop(0.55, css(g[0], g[1], g[2], 0.93)); lg.addColorStop(1, css(g[0] * 0.72, g[1] * 0.72, g[2] * 0.72, 0.95));
      ctx.fillStyle = lg; ctx.fillRect(x, y, w, h);
    }
    // light through the glass: a soft sheen at a different angle in every cell (LOOKED AT: one shared angle read as
    // stripes printed across the whole pane), darker toward the lead
    var ang = r() * Math.PI * 2, cx0 = x + w / 2, cy0 = y + h / 2, rad = Math.max(w, h) * 0.7;
    var sh = ctx.createLinearGradient(cx0 - Math.cos(ang) * rad, cy0 - Math.sin(ang) * rad, cx0 + Math.cos(ang) * rad, cy0 + Math.sin(ang) * rad);
    sh.addColorStop(0, 'rgba(255,255,245,0.20)'); sh.addColorStop(0.45, 'rgba(255,255,255,0)'); sh.addColorStop(1, 'rgba(0,0,0,0.22)');
    ctx.fillStyle = sh; ctx.fillRect(x, y, w, h);
    if (style === 'frost') {
      // rime: a few fine crystals and sparkles over the blurred picture
      ctx.strokeStyle = 'rgba(255,255,255,0.5)'; ctx.lineWidth = 0.8;
      for (var k = 0; k < 3; k++) { var fx = x + r() * w, fy = y + r() * h, fl = 4 + r() * 7; for (var a = 0; a < 6; a++) { ctx.beginPath(); ctx.moveTo(fx, fy); ctx.lineTo(fx + Math.cos(a * Math.PI / 3) * fl, fy + Math.sin(a * Math.PI / 3) * fl); ctx.stroke(); } }
      for (var s = 0; s < 6; s++) { ctx.fillStyle = 'rgba(255,255,255,' + (0.4 + r() * 0.5) + ')'; ctx.fillRect(x + r() * w, y + r() * h, 1.5, 1.5); }
    } else if (style === 'brick') {
      // fired clay: speckle, a bevel lit from above
      for (var p = 0; p < 26; p++) { var dk = r() < 0.5; ctx.fillStyle = dk ? 'rgba(0,0,0,0.18)' : 'rgba(255,240,220,0.14)'; ctx.fillRect(x + r() * w, y + r() * h, 2, 2); }
      ctx.fillStyle = 'rgba(255,255,255,0.16)'; ctx.fillRect(x, y, w, 3); ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(x, y + h - 3, w, 3);
    } else {
      // glass: a few seed bubbles; in a cathedral pane a painted roundel on a seeded few cells only (LOOKED AT: the same
      // quatrefoil stamped in every cell read as wallpaper)
      for (var q = 0; q < 3; q++) { ctx.strokeStyle = 'rgba(255,255,255,0.28)'; ctx.lineWidth = 0.8; ctx.beginPath(); ctx.arc(x + r() * w, y + r() * h, 1 + r() * 1.6, 0, 7); ctx.stroke(); }
      if (style === 'cathedral' && r() < 0.16) {
        var cx = x + w / 2, cy = y + h / 2, R = Math.min(w, h) * 0.34; ctx.strokeStyle = 'rgba(28,22,20,0.8)'; ctx.lineWidth = 2.4;
        ctx.beginPath(); ctx.arc(cx, cy, R, 0, 7); ctx.stroke();
        for (var f = 0; f < 4; f++) { var fa = f * Math.PI / 2 + Math.PI / 4; ctx.beginPath(); ctx.arc(cx + Math.cos(fa) * R * 0.48, cy + Math.sin(fa) * R * 0.48, R * 0.42, 0, 7); ctx.stroke(); }
        var rg = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 0.3); rg.addColorStop(0, 'rgba(255,244,200,0.85)'); rg.addColorStop(1, 'rgba(255,214,120,0)'); ctx.fillStyle = rg; ctx.beginPath(); ctx.arc(cx, cy, R * 0.3, 0, 7); ctx.fill();
      }
    }
    // cracks: one star for each hit taken, radiating from where a ball would strike (low in the cell)
    var taken = (c.hits || 1) - hitsLeft;
    if (taken > 0) {
      var cr = rng((seed >>> 0) ^ Math.imul(i + 7, 40503));
      for (var t = 0; t < taken; t++) {
        var ix = x + w * (0.3 + cr() * 0.4), iy = y + h * (0.55 + cr() * 0.3), n = 5 + t * 3;
        // the star of an impact: a frosted white spot where the ball struck and bright cracks running from it
        var sp = ctx.createRadialGradient(ix, iy, 0, ix, iy, Math.min(w, h) * 0.22); sp.addColorStop(0, 'rgba(255,255,255,0.75)'); sp.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.fillStyle = sp; ctx.fillRect(x, y, w, h);
        for (var j = 0; j < n; j++) {
          var ang2 = (j / n) * Math.PI * 2 + cr() * 0.4, len = Math.min(w, h) * (0.3 + cr() * 0.55), mx = ix + Math.cos(ang2) * len * 0.5 + (cr() - 0.5) * 4, my = iy + Math.sin(ang2) * len * 0.5 + (cr() - 0.5) * 4;
          ctx.strokeStyle = 'rgba(16,14,20,0.7)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(ix, iy); ctx.lineTo(mx, my); ctx.lineTo(ix + Math.cos(ang2) * len, iy + Math.sin(ang2) * len); ctx.stroke();
          ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(ix, iy); ctx.lineTo(mx, my); ctx.lineTo(ix + Math.cos(ang2) * len, iy + Math.sin(ang2) * len); ctx.stroke();
        }
      }
    }
    ctx.restore();
    // the came (lead) around the cell, or mortar for brick: drawn on the cell's own edge so neighbours share it
    if (style === 'brick') { ctx.strokeStyle = 'rgba(214,206,190,0.9)'; ctx.lineWidth = 2.6; ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1); }
    else { ctx.strokeStyle = LEAD; ctx.lineWidth = style === 'cathedral' ? 6 : 5; ctx.strokeRect(x, y, w, h); ctx.strokeStyle = LEAD_HI; ctx.lineWidth = 0.8; ctx.strokeRect(x - 1, y - 1, w, h); }
  }
  /**
   * Redraw after cell `i` changed: a broken cell is cleared WIDER than the lead (LOOKED AT in the engine 2026-10-11: a
   * 2 px clear left a sliver of each 5 px came between two broken cells, thin ghost lines over the revealed picture),
   * then every live neighbour the wide clear touched repaints itself, lead included.
   */
  function redrawAround(ctx, pane, i, left, style, seed, glassCv) {
    var c = pane.cells[i], P = 5;
    if (left[i] > 0) { drawCell(ctx, pane, i, left[i], style, seed, glassCv); return; }
    ctx.clearRect(c.x - P, c.y - P, c.w + P * 2, c.h + P * 2);
    for (var j = 0; j < pane.cells.length; j++) {
      if (j === i || !left[j]) continue;
      var o = pane.cells[j];
      if (o.x < c.x + c.w + P && o.x + o.w > c.x - P && o.y < c.y + c.h + P && o.y + o.h > c.y - P) drawCell(ctx, pane, j, left[j], style, seed, glassCv);
    }
  }
  /** the whole pane, every cell in its state (`left` = hits left per cell, from LeadlightCore's game, or null = intact) */
  function drawPane(ctx, pane, left, style, seed, glassCv) { for (var i = 0; i < pane.cells.length; i++) drawCell(ctx, pane, i, left ? left[i] : (pane.cells[i].hits || 1), style, seed, glassCv); }

  /** shards: four white glass slivers in a strip (the scene tints a shard with its cell's colour) */
  function drawShards(ctx, s) {
    ctx.clearRect(0, 0, s * 4, s);
    var r = rng(4711);
    for (var k = 0; k < 4; k++) {
      var ox = k * s + s / 2, oy = s / 2; ctx.beginPath();
      for (var p = 0; p < 3 + (k % 2); p++) { var a = p / (3 + (k % 2)) * Math.PI * 2 + r() * 0.6, d = s * (0.18 + r() * 0.3); if (p === 0) ctx.moveTo(ox + Math.cos(a) * d, oy + Math.sin(a) * d); else ctx.lineTo(ox + Math.cos(a) * d, oy + Math.sin(a) * d); }
      ctx.closePath(); ctx.fillStyle = 'rgba(255,255,255,0.92)'; ctx.fill(); ctx.strokeStyle = 'rgba(40,36,44,0.8)'; ctx.lineWidth = 1; ctx.stroke();
    }
  }
  /** the paddle: a bar of lead with a gilt cap at each end and rivets */
  function drawPaddle(ctx, w, h) {
    ctx.clearRect(0, 0, w, h);
    var g = ctx.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#6a6670'); g.addColorStop(0.45, '#34313a'); g.addColorStop(1, '#16141a');
    ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(h / 2, 0); ctx.lineTo(w - h / 2, 0); ctx.arc(w - h / 2, h / 2, h / 2, -Math.PI / 2, Math.PI / 2); ctx.lineTo(h / 2, h); ctx.arc(h / 2, h / 2, h / 2, Math.PI / 2, Math.PI * 1.5); ctx.fill();
    ctx.fillStyle = GILT; ctx.fillRect(0, 2, h * 0.9, h - 4); ctx.fillRect(w - h * 0.9, 2, h * 0.9, h - 4);
    ctx.fillStyle = GILT_HI; ctx.fillRect(0, 2, h * 0.9, 2); ctx.fillRect(w - h * 0.9, 2, h * 0.9, 2);
    ctx.fillStyle = 'rgba(220,214,226,0.7)'; for (var k = 1; k < 6; k++) { ctx.beginPath(); ctx.arc(w * k / 6, h / 2, 1.4, 0, 7); ctx.fill(); }
  }
  /** the ball: a glass bead with a lit core */
  function drawBall(ctx, s) {
    ctx.clearRect(0, 0, s, s);
    var g = ctx.createRadialGradient(s * 0.38, s * 0.36, 0, s / 2, s / 2, s / 2); g.addColorStop(0, '#ffffff'); g.addColorStop(0.35, '#fff1c4'); g.addColorStop(0.8, '#d49a3a'); g.addColorStop(1, 'rgba(120,70,20,0.9)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(s / 2, s / 2, s / 2 - 0.5, 0, 7); ctx.fill();
  }
  /** a falling capsule: a gilt medallion with the power drawn on it (wide: two arrows apart; multi: three beads; slow: an hourglass) */
  function drawCap(ctx, s, kind) {
    ctx.clearRect(0, 0, s, s);
    var c = s / 2; ctx.fillStyle = GILT; ctx.beginPath(); ctx.arc(c, c, c - 1, 0, 7); ctx.fill(); ctx.strokeStyle = '#7a5a1e'; ctx.lineWidth = 1.5; ctx.stroke();
    ctx.fillStyle = '#3a2a10'; ctx.strokeStyle = '#3a2a10'; ctx.lineWidth = 2;
    if (kind === 'wide') { ctx.beginPath(); ctx.moveTo(c - 6, c); ctx.lineTo(c - 2, c - 4); ctx.lineTo(c - 2, c + 4); ctx.fill(); ctx.beginPath(); ctx.moveTo(c + 6, c); ctx.lineTo(c + 2, c - 4); ctx.lineTo(c + 2, c + 4); ctx.fill(); }
    else if (kind === 'multi') { for (var k = -1; k <= 1; k++) { ctx.beginPath(); ctx.arc(c + k * 4.5, c + (k === 0 ? -2 : 2), 2.2, 0, 7); ctx.fill(); } }
    else { ctx.beginPath(); ctx.moveTo(c - 4, c - 5); ctx.lineTo(c + 4, c - 5); ctx.lineTo(c - 4, c + 5); ctx.lineTo(c + 4, c + 5); ctx.closePath(); ctx.stroke(); }
  }
  /**
   * The window: a carved stone frame around the field, a pointed arch over the pane, and the floor of the lane below.
   * The pane area (paneW x paneH at ox, oy) is left clear for the picture and the glass.
   */
  function drawFrame(ctx, W, H, ox, oy, paneW, paneH, laneH) {
    ctx.clearRect(0, 0, W, H);
    var stone = ctx.createLinearGradient(0, 0, 0, H); stone.addColorStop(0, '#3c3640'); stone.addColorStop(1, '#1e1a22');
    ctx.fillStyle = stone; ctx.fillRect(0, 0, W, H);
    // the lane below the pane: a dim chapel floor
    var fl = ctx.createLinearGradient(0, oy + paneH, 0, oy + paneH + laneH); fl.addColorStop(0, '#2a2530'); fl.addColorStop(1, '#141118');
    ctx.fillStyle = fl; ctx.fillRect(ox, oy + paneH, paneW, laneH);
    // the opening for the pane
    ctx.clearRect(ox, oy, paneW, paneH);
    // stone mouldings around the opening, and the gilt fillet
    for (var k = 0; k < 3; k++) { ctx.strokeStyle = k === 1 ? GILT : (k ? '#5c5462' : '#0e0c10'); ctx.lineWidth = k === 1 ? 2 : 4; ctx.strokeRect(ox - 3 - k * 4, oy - 3 - k * 4, paneW + 6 + k * 8, paneH + 6 + k * 8); }
    ctx.strokeStyle = '#4a4350'; ctx.lineWidth = 3; ctx.strokeRect(ox - 16, oy - 16, paneW + 32, paneH + laneH + 28);
    // ashlar joints in the stone
    ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 1;
    for (var y = 6; y < H; y += 28) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(ox - 18, y); ctx.moveTo(ox + paneW + 18, y); ctx.lineTo(W, y); ctx.stroke(); }
  }
  /** the HUD strip: the share broken as a gilt bar, the balls left as beads, the time */
  function drawHud(ctx, w, h, info) {
    ctx.clearRect(0, 0, w, h);
    ctx.textBaseline = 'middle'; ctx.fillStyle = '#efe2c2'; ctx.font = 'bold 18px ' + FACE; ctx.textAlign = 'left'; ctx.fillText(info.title || 'Leadlight', 18, h / 2);
    var bx = w * 0.36, bw = w * 0.32; ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.fillRect(bx, h / 2 - 6, bw, 12);
    ctx.fillStyle = GILT; ctx.fillRect(bx, h / 2 - 6, bw * Math.min(1, info.percent / 100), 12); ctx.strokeStyle = GILT_HI; ctx.lineWidth = 1; ctx.strokeRect(bx + 0.5, h / 2 - 5.5, bw - 1, 11);
    var tx = bx + bw * (info.target / 100); ctx.fillStyle = '#efe2c2'; ctx.fillRect(tx - 1, h / 2 - 9, 2, 18);
    ctx.font = 'italic 13px ' + FACE; ctx.textAlign = 'left'; ctx.fillText(Math.floor(info.percent) + '% broken', bx + bw + 10, h / 2);
    for (var k = 0; k < info.livesMax; k++) { var lx = w - 24 - k * 18; ctx.fillStyle = k < info.lives ? '#f1d98a' : 'rgba(255,255,255,0.15)'; ctx.beginPath(); ctx.arc(lx, h / 2, 6, 0, 7); ctx.fill(); }
  }
  /** the results plate: the verdict and the numbers, on a dark glass panel at the foot of the screen */
  function drawResults(ctx, w, h, res) {
    ctx.clearRect(0, 0, w, h);
    var pw = Math.min(520, w - 40), ph = 128, x = (w - pw) / 2, y = h - ph - 18;
    ctx.fillStyle = 'rgba(12,10,16,0.82)'; ctx.fillRect(x, y, pw, ph); ctx.strokeStyle = GILT; ctx.lineWidth = 2; ctx.strokeRect(x + 4, y + 4, pw - 8, ph - 8);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = res.won ? GILT_HI : '#e8b0a0'; ctx.font = 'bold 28px ' + FACE;
    ctx.fillText(res.won ? 'The pane is broken' : 'The glass holds', w / 2, y + 36);
    ctx.fillStyle = '#efe2c2'; ctx.font = '15px ' + FACE;
    ctx.fillText(Math.floor(res.percent) + '% broken  ·  ' + res.seconds + ' s  ·  ' + res.ballsLost + (res.ballsLost === 1 ? ' ball' : ' balls') + ' lost  ·  best run ' + res.bestCombo, w / 2, y + 72);
    ctx.font = 'italic 13px ' + FACE; ctx.fillStyle = 'rgba(239,226,194,0.75)'; ctx.fillText('OK to leave', w / 2, y + 102);
  }

  return { VERSION: '1.0.0', FACE: FACE, STYLES: STYLES, glass: glass, glassImage: glassImage, drawCell: drawCell, redrawAround: redrawAround, drawPane: drawPane, drawShards: drawShards, drawPaddle: drawPaddle, drawBall: drawBall, drawCap: drawCap, drawFrame: drawFrame, drawHud: drawHud, drawResults: drawResults };
})();
if (typeof module === 'object' && module.exports) module.exports = LeadlightDraw;
