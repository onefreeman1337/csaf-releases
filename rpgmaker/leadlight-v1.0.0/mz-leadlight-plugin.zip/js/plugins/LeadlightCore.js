/*:
 * @target MZ
 * @plugindesc Leadlight 1/3 - the rules: a brick-breaker over a pane read from your picture. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * LeadlightCore.js - part of Leadlight v1.0.0. Enable it with LeadlightDraw.js
 * and Leadlight.js (any order). It has no commands or parameters of its own.
 *
 * Every line of this plugin was written with AI assistance.
 */
/*
 * The rules of a brick-breaker whose bricks are a stained-glass pane cut over one of the buyer's pictures, pure
 * JavaScript with no engine calls, so they run headless in Node exactly as in MZ.
 *
 * The pane is READ from the picture: each cell's glass is the mean colour of the picture beneath it, and its toughness
 * comes from how much the picture varies inside it (an edge, a face, a line of text takes more hits than flat sky).
 * Toughness is assigned by RANK across the pane, so a flat, low-contrast picture still gets tough cells and a busy one
 * does not become all-tough.
 *
 * The ball runs on a FIXED step per frame, split into sub-steps no longer than half its radius, so it cannot pass
 * through a cell or the paddle however fast it goes (the tunnelling a variable step invites). Never Math.random: a
 * seeded generator whose state lives on the game. Zero allocation per frame: balls, capsules and the event ring are
 * fixed-size arrays made when the game is created.
 */
var LeadlightCore = (function () {
  'use strict';

  /* ------------------------------------------------------------ seeded randomness */
  function hashString(s) { var h = 0x811c9dc5; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193); } return h >>> 0; }
  function mix(a, b) { var h = Math.imul((a >>> 0) ^ 0x9e3779b9, 0x85ebca6b) ^ (b >>> 0); h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35); return (h ^ (h >>> 16)) >>> 0; }
  /** mulberry32, state on the object (`o.rs`) */
  function rand(o) { var t = o.rs = (o.rs + 0x6D2B79F5) | 0; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }

  var LAYOUTS = ['grid', 'stagger'];
  var POWERS = ['wide', 'multi', 'slow'];
  var MAX_BALLS = 3, MAX_CAPS = 4, RING = 64;
  /** the smallest angle from vertical a paddle rebound may take, radians (about 13 degrees) */
  var MIN_LEAN = 0.22;
  /** event codes written to the ring: [code, a, b] */
  var EV = { CRACK: 1, BREAK: 2, PADDLE: 3, WALL: 4, LOST: 5, CATCH: 6, DROP: 7, SERVE: 8, FINISH: 9 };

  /* ------------------------------------------------------------ the pane */
  /**
   * The cell rectangles of a pane over a W x H area. 'grid': cols x rows equal cells. 'stagger': brick bond, every odd
   * row shifted by half a cell with a half cell at each end.
   * @returns {Array<{x:number,y:number,w:number,h:number,row:number}>}
   */
  function layoutCells(W, H, cols, rows, layout) {
    var out = [], cw = W / cols, ch = H / rows;
    for (var r = 0; r < rows; r++) {
      var y = r * ch;
      if (layout === 'stagger' && r % 2 === 1) {
        out.push({ x: 0, y: y, w: cw / 2, h: ch, row: r });
        for (var c = 0; c < cols - 1; c++) out.push({ x: cw / 2 + c * cw, y: y, w: cw, h: ch, row: r });
        out.push({ x: W - cw / 2, y: y, w: cw / 2, h: ch, row: r });
      } else for (var c2 = 0; c2 < cols; c2++) out.push({ x: c2 * cw, y: y, w: cw, h: ch, row: r });
    }
    return out;
  }

  /**
   * Read the pane from a picture's RGBA pixels. The picture is fitted to COVER the W x H pane area exactly as the scene
   * draws it (scaled up to fill, centred, the overflow cropped), so a cell's glass is the colour of what lies under it.
   * @param {Uint8ClampedArray|Uint8Array} px RGBA, pw x ph
   * @param {{W:number,H:number,cols?:number,rows?:number,layout?:string,seed?:number,dropRate?:number,powers?:boolean,toughShare?:number[]}} o
   *   toughShare: the share of cells taking 3 and 2 hits, by rank of contrast ([0.10, 0.25])
   * @returns {{W:number,H:number,cols:number,rows:number,layout:string,cells:Array}}
   */
  function paneFromPixels(px, pw, ph, o) {
    o = o || {};
    // 10 x 7 by default: balance_probe v2 (2026-10-11) cleared it in a median 106-124 s at speed 6.5 / target 85; the
    // 12 x 8 pane took 141-171 s, long for a minigame
    var W = o.W, H = o.H, cols = Math.max(4, Math.min(24, Math.floor(o.cols || 10))), rows = Math.max(3, Math.min(16, Math.floor(o.rows || 7)));
    var layout = LAYOUTS.indexOf(o.layout) >= 0 ? o.layout : 'grid';
    var cells = layoutCells(W, H, cols, rows, layout);
    var k = Math.max(W / Math.max(1, pw), H / Math.max(1, ph)), ox = (W - pw * k) / 2, oy = (H - ph * k) / 2;
    for (var i = 0; i < cells.length; i++) {
      var c = cells[i], n = 0, sr = 0, sg = 0, sb = 0, sl = 0, sl2 = 0, S = 8;
      for (var sy = 0; sy < S; sy++) for (var sx = 0; sx < S; sx++) {
        var fx = c.x + (sx + 0.5) * c.w / S, fy = c.y + (sy + 0.5) * c.h / S;
        var ix = Math.max(0, Math.min(pw - 1, Math.floor((fx - ox) / k))), iy = Math.max(0, Math.min(ph - 1, Math.floor((fy - oy) / k)));
        var p = (iy * pw + ix) * 4, a = px[p + 3] / 255;
        // a transparent pixel reads as the dark backing the scene draws behind the picture
        var r = px[p] * a + 8 * (1 - a), g = px[p + 1] * a + 6 * (1 - a), b = px[p + 2] * a + 10 * (1 - a), l = 0.2126 * r + 0.7152 * g + 0.0722 * b;
        sr += r; sg += g; sb += b; sl += l; sl2 += l * l; n++;
      }
      c.r = Math.round(sr / n); c.g = Math.round(sg / n); c.b = Math.round(sb / n); c.lum = sl / n;
      c.contrast = Math.sqrt(Math.max(0, sl2 / n - (sl / n) * (sl / n)));
    }
    // toughness by RANK of contrast (index breaks ties, never the RNG: wing §3, no RNG inside a comparator)
    var share = o.toughShare || [0.10, 0.25], order = cells.map(function (c, j) { return j; });
    order.sort(function (a, b) { return (cells[b].contrast - cells[a].contrast) || (a - b); });
    var n3 = Math.round(cells.length * share[0]), n2 = Math.round(cells.length * share[1]);
    for (var q = 0; q < order.length; q++) cells[order[q]].hits = q < n3 ? 3 : (q < n3 + n2 ? 2 : 1);
    // power-ups: seeded, a share of cells carries one (never the toughest, which already reward the player)
    var rs = { rs: mix((o.seed >>> 0) || 1, 0x1EAD) | 0 }, rate = o.powers === false ? 0 : (o.dropRate == null ? 0.1 : Math.max(0, Math.min(0.5, Number(o.dropRate))));
    for (var d = 0; d < cells.length; d++) { var roll = rand(rs), kind = Math.floor(rand(rs) * POWERS.length); cells[d].power = roll < rate && cells[d].hits < 3 ? POWERS[kind] : null; }
    return { W: W, H: H, cols: cols, rows: rows, layout: layout, cells: cells };
  }

  /* ------------------------------------------------------------ the game */
  /**
   * A new game over a pane.
   * @param {number} seed
   * @param {object} pane paneFromPixels(...)
   * @param {{W?:number,H?:number,paddleW?:number,ballR?:number,speed?:number,maxSpeed?:number,lives?:number,target?:number,paddleSpeed?:number}} [o]
   *   field W x H (the pane's width; H = the whole field, the pane at its top), paddle width (W/6.4), ball radius (7),
   *   speed in px a frame (6.5), max speed (9), lives (3), target share of the pane's AREA to break (85%), paddle speed (12)
   */
  function createGame(seed, pane, o) {
    o = o || {};
    var W = pane.W, H = Math.max(pane.H + 120, Math.floor(o.H || pane.H + 200)), n = pane.cells.length;
    var g = { v: 1, seed: seed >>> 0, rs: mix(seed >>> 0, 0x5E2E) | 0, W: W, H: H, paneH: pane.H, cells: pane.cells, n: n,
      left: new Uint8Array(n), alive: n, areaTotal: 0, areaBroken: 0, broken: 0,
      target: Math.max(0.3, Math.min(1, (Number(o.target) || 85) / 100)),
      paddle: { x: W / 2, y: H - 34, h: 12, w0: Math.max(40, Number(o.paddleW) || W / 6.4), w: 0, speed: Math.max(4, Number(o.paddleSpeed) || 12) },
      ballR: Math.max(3, Number(o.ballR) || 7), baseSpeed: Math.max(1, Number(o.speed) || 6.5), maxSpeed: Math.max(2, Number(o.maxSpeed) || 9), speed: 0,
      balls: [], caps: [], lives: Math.max(1, Math.min(9, Math.floor(o.lives || 3))), ballsLost: 0, frame: 0, phase: 'serve',
      wideT: 0, slowT: 0, combo: 0, bestCombo: 0, paddleHits: 0,
      ev: new Int32Array(RING * 3), evN: 0 };
    g.livesMax = g.lives; g.paddle.w = g.paddle.w0; g.speed = g.baseSpeed;
    for (var i = 0; i < n; i++) { g.left[i] = pane.cells[i].hits || 1; g.areaTotal += pane.cells[i].w * pane.cells[i].h; }
    for (var b = 0; b < MAX_BALLS; b++) g.balls.push({ x: 0, y: 0, vx: 0, vy: 0, active: false, stuck: false });
    for (var c = 0; c < MAX_CAPS; c++) g.caps.push({ x: 0, y: 0, active: false, kind: 0 });
    stickBall(g);
    return g;
  }
  function emit(g, code, a, b) { var k = (g.evN % RING) * 3; g.ev[k] = code; g.ev[k + 1] = a; g.ev[k + 2] = b; g.evN++; }
  /** the event `i` (0-based, total count g.evN) as [code, a, b] into `out` (a caller-owned 3-array); false if overwritten */
  function event(g, i, out) { if (i < g.evN - RING || i >= g.evN) return false; var k = (i % RING) * 3; out[0] = g.ev[k]; out[1] = g.ev[k + 1]; out[2] = g.ev[k + 2]; return true; }
  /** one ball sits on the paddle, the others are put away */
  function stickBall(g) {
    for (var i = 0; i < MAX_BALLS; i++) g.balls[i].active = false;
    var b = g.balls[0]; b.active = true; b.stuck = true; b.vx = 0; b.vy = 0; b.x = g.paddle.x; b.y = g.paddle.y - g.ballR - 1;
    g.phase = 'serve';
  }
  function setSpeed(b, s) { var m = Math.sqrt(b.vx * b.vx + b.vy * b.vy) || 1; b.vx *= s / m; b.vy *= s / m; }
  /** serve the stuck ball: up, with a seeded lean (never straight up, which can trap a ball between two cells) */
  function serve(g) {
    var b = g.balls[0]; if (!b.stuck) return;
    var lean = (0.18 + rand(g) * 0.22) * (rand(g) < 0.5 ? -1 : 1);
    b.stuck = false; b.vx = Math.sin(lean) * g.speed; b.vy = -Math.cos(lean) * g.speed; g.phase = 'play'; g.combo = 0;
    emit(g, EV.SERVE, 0, 0);
  }

  /**
   * One frame. `input.x` = where the paddle wants to be (NaN or undefined to stand still; it moves at most
   * paddle.speed a frame), `input.launch` = serve a ball that sits on the paddle.
   */
  function step(g, input) {
    if (g.phase === 'won' || g.phase === 'lost') return;
    g.frame++;
    var P = g.paddle, tx = input && input.x;
    if (tx === tx && tx != null) { var dx = Math.max(-P.speed, Math.min(P.speed, tx - P.x)); P.x += dx; }
    P.x = Math.max(P.w / 2, Math.min(g.W - P.w / 2, P.x));
    if (g.wideT > 0 && --g.wideT === 0) { P.w = P.w0; P.x = Math.max(P.w / 2, Math.min(g.W - P.w / 2, P.x)); }
    if (g.slowT > 0) g.slowT--;
    if (g.phase === 'serve') { var sb = g.balls[0]; sb.x = P.x; sb.y = P.y - g.ballR - 1; if (input && input.launch) serve(g); else return; }
    var mul = g.slowT > 0 ? 0.65 : 1;
    for (var i = 0; i < MAX_BALLS; i++) { var b = g.balls[i]; if (b.active && !b.stuck) moveBall(g, b, i, mul); }
    for (var c = 0; c < MAX_CAPS; c++) moveCap(g, g.caps[c]);
    var any = false; for (var j = 0; j < MAX_BALLS; j++) if (g.balls[j].active) any = true;
    if (!any && g.phase === 'play') {
      g.lives--; g.ballsLost++; g.combo = 0; emit(g, EV.LOST, g.lives, 0);
      g.wideT = 0; g.slowT = 0; P.w = P.w0; for (var k = 0; k < MAX_CAPS; k++) g.caps[k].active = false;
      if (g.lives <= 0) g.phase = 'lost'; else stickBall(g);
    }
  }
  /** move one ball one frame in sub-steps no longer than half its radius (no tunnelling, test-pinned at 3x speed) */
  function moveBall(g, b, bi, mul) {
    var R = g.ballR, vx = b.vx * mul, vy = b.vy * mul, dist = Math.sqrt(vx * vx + vy * vy), n = Math.max(1, Math.ceil(dist / (R * 0.5)));
    for (var s = 0; s < n && b.active; s++) {
      var px = b.x, py = b.y;
      b.x += vx / n; b.y += vy / n;
      // walls
      if (b.x < R) { b.x = R; b.vx = Math.abs(b.vx); vx = Math.abs(vx); emit(g, EV.WALL, 0, bi); }
      else if (b.x > g.W - R) { b.x = g.W - R; b.vx = -Math.abs(b.vx); vx = -Math.abs(vx); emit(g, EV.WALL, 1, bi); }
      if (b.y < R) { b.y = R; b.vy = Math.abs(b.vy); vy = Math.abs(vy); emit(g, EV.WALL, 2, bi); }
      // the paddle: only a falling ball, and the angle comes from where it meets the bar (Arkanoid control)
      var P = g.paddle;
      if (b.vy > 0 && b.y + R >= P.y && py + R <= P.y + P.h && b.x >= P.x - P.w / 2 - R && b.x <= P.x + P.w / 2 + R) {
        // never closer than MIN_LEAN to vertical: a ball sent straight up returns straight down, so a player who simply
        // follows it locks it in one column for ever (MEASURED 2026-10-11, balance_probe v1: the "lazy" player lost 0
        // balls and cleared 0 of 100 panes in ten minutes)
        var off = Math.max(-1, Math.min(1, (b.x - P.x) / (P.w / 2))), a = off * 1.05, sp = Math.sqrt(b.vx * b.vx + b.vy * b.vy);
        if (Math.abs(a) < MIN_LEAN) a = (a !== 0 ? (a > 0 ? 1 : -1) : (b.vx >= 0 ? 1 : -1)) * MIN_LEAN;
        b.vx = Math.sin(a) * sp; b.vy = -Math.cos(a) * sp; b.y = P.y - R; vx = b.vx * mul; vy = b.vy * mul;
        g.combo = 0; g.paddleHits++; emit(g, EV.PADDLE, Math.round(off * 100), bi);
        continue;
      }
      if (b.y - R > g.H) { b.active = false; break; }
      // cells: the first live cell the ball overlaps this sub-step; the side it came from decides the bounce
      if (b.y - R <= g.paneH) {
        for (var i = 0; i < g.n; i++) {
          if (!g.left[i]) continue;
          var c = g.cells[i], nx = Math.max(c.x, Math.min(b.x, c.x + c.w)), ny = Math.max(c.y, Math.min(b.y, c.y + c.h)), ddx = b.x - nx, ddy = b.y - ny;
          if (ddx * ddx + ddy * ddy > R * R) continue;
          var wasInX = px > c.x && px < c.x + c.w, wasInY = py > c.y && py < c.y + c.h;
          if (wasInX && !wasInY) { b.vy = -b.vy; vy = -vy; } else if (wasInY && !wasInX) { b.vx = -b.vx; vx = -vx; } else { b.vx = -b.vx; b.vy = -b.vy; vx = -vx; vy = -vy; }
          b.x = px; b.y = py;
          hitCell(g, i, bi);
          break;
        }
      }
    }
  }
  function hitCell(g, i, bi) {
    g.left[i]--;
    if (g.left[i] > 0) { emit(g, EV.CRACK, i, bi); return; }
    var c = g.cells[i]; g.alive--; g.broken++; g.areaBroken += c.w * c.h; g.combo++; if (g.combo > g.bestCombo) g.bestCombo = g.combo;
    emit(g, EV.BREAK, i, bi);
    // each broken cell quickens the game a little, to a ceiling
    g.speed = Math.min(g.maxSpeed, g.speed * 1.006);
    for (var k = 0; k < MAX_BALLS; k++) if (g.balls[k].active && !g.balls[k].stuck) setSpeed(g.balls[k], g.speed);
    if (c.power) dropCap(g, c);
    if (g.areaBroken / g.areaTotal >= g.target - 1e-9) finish(g);
  }
  /** the target share is broken: the rest of the pane falls away and the picture is won */
  function finish(g) {
    var rest = 0;
    for (var i = 0; i < g.n; i++) if (g.left[i]) { g.left[i] = 0; g.areaBroken += g.cells[i].w * g.cells[i].h; g.broken++; rest++; }
    g.alive = 0; g.phase = 'won'; emit(g, EV.FINISH, rest, 0);
  }
  function dropCap(g, c) {
    for (var k = 0; k < MAX_CAPS; k++) { var p = g.caps[k]; if (p.active) continue; p.active = true; p.x = c.x + c.w / 2; p.y = c.y + c.h / 2; p.kind = POWERS.indexOf(c.power); emit(g, EV.DROP, p.kind, k); return; }
  }
  function moveCap(g, p) {
    if (!p.active) return;
    p.y += 2.6;
    var P = g.paddle;
    if (p.y + 8 >= P.y && p.y - 8 <= P.y + P.h && Math.abs(p.x - P.x) <= P.w / 2 + 12) { p.active = false; applyPower(g, p.kind); emit(g, EV.CATCH, p.kind, 0); return; }
    if (p.y - 8 > g.H) p.active = false;
  }
  function applyPower(g, kind) {
    var P = g.paddle, name = POWERS[kind];
    if (name === 'wide') { P.w = P.w0 * 1.5; g.wideT = 900; P.x = Math.max(P.w / 2, Math.min(g.W - P.w / 2, P.x)); }
    else if (name === 'slow') g.slowT = 600;
    else if (name === 'multi') {
      var src = null; for (var i = 0; i < MAX_BALLS; i++) if (g.balls[i].active && !g.balls[i].stuck) { src = g.balls[i]; break; }
      if (!src) return;
      for (var j = 0, made = 0; j < MAX_BALLS && made < 2; j++) {
        var b = g.balls[j]; if (b.active) continue;
        var ang = Math.atan2(src.vx, -src.vy) + (made ? 0.45 : -0.45), sp = Math.sqrt(src.vx * src.vx + src.vy * src.vy);
        b.active = true; b.stuck = false; b.x = src.x; b.y = src.y; b.vx = Math.sin(ang) * sp; b.vy = -Math.abs(Math.cos(ang) * sp); made++;
      }
    }
  }

  /** the share of the pane broken, 0..100 */
  function percent(g) { return 100 * g.areaBroken / Math.max(1, g.areaTotal); }
  function results(g) {
    return { won: g.phase === 'won', lost: g.phase === 'lost', percent: percent(g), frames: g.frame, seconds: Math.floor(g.frame / 60), ballsLost: g.ballsLost,
      cellsBroken: g.broken, cellsTotal: g.n, livesLeft: Math.max(0, g.lives), bestCombo: g.bestCombo };
  }

  /**
   * Where the paddle should go to meet the lowest falling ball: its path extrapolated to the paddle's height with
   * reflections off the side walls, plus `bias` (-1..1 of half the paddle) to steer the rebound. Used by the balance
   * probe, the captures and the tests; a game never calls it.
   */
  function landing(g, bias) {
    var best = null, by = -1;
    for (var i = 0; i < MAX_BALLS; i++) { var b = g.balls[i]; if (b.active && !b.stuck && b.vy > 0 && b.y > by) { by = b.y; best = b; } }
    if (!best) { for (var j = 0; j < MAX_BALLS; j++) if (g.balls[j].active && !g.balls[j].stuck) { best = g.balls[j]; break; } if (!best) return g.paddle.x; return best.x; }
    var t = (g.paddle.y - g.ballR - best.y) / best.vy, x = best.x + best.vx * t, span = g.W - 2 * g.ballR, u = ((x - g.ballR) % (2 * span) + 2 * span) % (2 * span);
    x = g.ballR + (u <= span ? u : 2 * span - u);
    return x - (bias || 0) * g.paddle.w / 2;
  }

  return { VERSION: '1.0.0', hashString: hashString, mix: mix, rand: rand, LAYOUTS: LAYOUTS, POWERS: POWERS, EV: EV, MAX_BALLS: MAX_BALLS, MAX_CAPS: MAX_CAPS, RING: RING, MIN_LEAN: MIN_LEAN,
    layoutCells: layoutCells, paneFromPixels: paneFromPixels, createGame: createGame, serve: serve, step: step, event: event, percent: percent, results: results, landing: landing };
})();
if (typeof module === 'object' && module.exports) module.exports = LeadlightCore;
