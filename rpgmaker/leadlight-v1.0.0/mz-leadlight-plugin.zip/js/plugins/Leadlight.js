/*:
 * @target MZ
 * @plugindesc [v1.0.0] Leadlight 3/3 - break a stained-glass pane generated from one of your pictures to reveal it: a brick-breaker minigame.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 * @base LeadlightCore
 * @base LeadlightDraw
 * @orderAfter LeadlightDraw
 *
 * @param breakSe
 * @text Sound: glass breaks
 * @desc An SE from audio/se. (None) = silent.
 * @type file
 * @dir audio/se
 * @default Break
 *
 * @param crackSe
 * @text Sound: glass cracks
 * @desc An SE from audio/se. (None) = silent.
 * @type file
 * @dir audio/se
 * @default Ice1
 *
 * @param paddleSe
 * @text Sound: ball meets the bar
 * @desc An SE from audio/se. (None) = silent.
 * @type file
 * @dir audio/se
 * @default Switch1
 *
 * @param lostSe
 * @text Sound: a ball lost
 * @desc An SE from audio/se. (None) = silent.
 * @type file
 * @dir audio/se
 * @default Damage1
 *
 * @param powerSe
 * @text Sound: a power caught
 * @desc An SE from audio/se. (None) = silent.
 * @type file
 * @dir audio/se
 * @default Powerup
 *
 * @param winSe
 * @text Sound: the pane falls
 * @desc An SE from audio/se. (None) = silent.
 * @type file
 * @dir audio/se
 * @default Chime2
 *
 * @command leadlight
 * @text Start Leadlight
 * @desc Break a stained-glass pane over one of your pictures. The event waits until it is over.
 *
 * @arg picture
 * @text Picture
 * @type file
 * @dir img/pictures
 * @default
 *
 * @arg style
 * @text Pane
 * @type select
 * @option auto
 * @option leaded
 * @option cathedral
 * @option frost
 * @option brick
 * @desc The glass. Auto picks one from the seed.
 * @default auto
 *
 * @arg target
 * @text Target (%)
 * @type number
 * @min 30
 * @max 100
 * @desc Break this share of the pane and the rest falls away.
 * @default 85
 *
 * @arg lives
 * @text Balls
 * @type number
 * @min 1
 * @max 9
 * @default 3
 *
 * @arg powers
 * @text Power-ups
 * @type boolean
 * @on On
 * @off Off
 * @desc Some pieces drop a power when they break: a wider bar, two more balls, or a slower ball.
 * @default true
 *
 * @arg secondsVariable
 * @text Variable: seconds taken
 * @type variable
 * @default 0
 *
 * @arg ballsLostVariable
 * @text Variable: balls lost
 * @type variable
 * @default 0
 *
 * @arg percentVariable
 * @text Variable: percent broken
 * @type variable
 * @default 0
 *
 * @arg clearedSwitch
 * @text Switch: cleared
 * @type switch
 * @default 0
 *
 * @arg seed
 * @text Seed (optional)
 * @desc Blank = a new game every time. A number or word = the same pane, powers and serves every time.
 * @default
 *
 * @help
 * ============================================================================
 * LEADLIGHT v1.0.0 - break the glass, win the picture
 * ============================================================================
 * One of your pictures waits behind a stained-glass pane the plugin makes from
 * that picture: every piece of glass is coloured from the picture beneath it,
 * and the busiest parts of the picture make the toughest glass. Keep the ball in
 * play with the lead bar and break the pane; break the target share and the rest
 * falls away and the picture is yours.
 *
 * INSTALLING: copy LeadlightCore.js, LeadlightDraw.js and Leadlight.js into
 * js/plugins and enable all three. Any order works.
 *
 * USING IT: add the plugin command "Start Leadlight" to an event and name a
 * picture from img/pictures. The event waits while the game runs. Script call:
 *   Leadlight.start({ picture: 'Castle', style: 'frost', lives: 5 });
 *
 * CONTROLS: left and right move the bar, OK (or Space) serves the ball. Mouse
 * and touch: the bar follows the pointer, a click or tap serves. On the
 * results, OK or a click leaves.
 *
 * COMPATIBILITY: Leadlight adds its own scene and replaces nothing. It extends
 * two engine methods, each by saving the original and calling it:
 * Game_System.initialize (its save record) and Game_Interpreter.updateWaitMode
 * (so the event waits while the game runs).
 *
 * TERMS OF USE: commercial and non-commercial use permitted in RPG Maker
 * projects, credit appreciated but not required. Do not redistribute the
 * source as an asset pack. Every line of this plugin was written with AI
 * assistance.
 */

var Leadlight = Leadlight || {};

(function (M) {
  'use strict';
  var NAME = 'Leadlight', SCHEMA = 1;
  var raw = (typeof PluginManager !== 'undefined') ? PluginManager.parameters(NAME) : {};
  function num(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; var n = Number(v); return isFinite(n) ? n : d; }
  function str(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; return String(v).trim(); }
  function bool(v, d) { if (v === true || v === false) return v; var s = str(v, ''); return s === '' ? d : s !== 'false'; }
  /** a sound parameter: (None) in the Plugin Manager is '' and means SILENT; only a key absent from plugins.js takes the default
   *  (docs_probe B1, 2026-10-11: blank read as absent played Break after the buyer had turned it off) */
  function se(v, d) { return (v === undefined || v === null) ? d : String(v).trim(); }
  M.params = { breakSe: se(raw.breakSe, 'Break'), crackSe: se(raw.crackSe, 'Ice1'), paddleSe: se(raw.paddleSe, 'Switch1'), lostSe: se(raw.lostSe, 'Damage1'), powerSe: se(raw.powerSe, 'Powerup'), winSe: se(raw.winSe, 'Chime2') };
  var _deps = null;
  /** ⛔ siblings resolved at FIRST USE, never at load time: the buyer chooses the load order (wing §8 trap 2) */
  function deps() {
    if (_deps) return _deps;
    var core = (typeof LeadlightCore !== 'undefined') ? LeadlightCore : null, draw = (typeof LeadlightDraw !== 'undefined') ? LeadlightDraw : null;
    if (!core || !draw) { if (!deps._w) { deps._w = true; console.error('Leadlight: enable LeadlightCore.js and LeadlightDraw.js in the Plugin Manager too.'); } return null; }
    _deps = { core: core, draw: draw }; return _deps;
  }
  M.deps = deps;
  function fresh() { return { v: SCHEMA, played: 0, cleared: 0, best: 0 }; }
  M.record = function () {
    if (typeof $gameSystem === 'undefined' || !$gameSystem) return fresh();
    var s = $gameSystem._csafLeadlight; if (!s || s.v == null) { s = fresh(); $gameSystem._csafLeadlight = s; } return s;
  };
  var _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () { _Game_System_initialize.call(this); this._csafLeadlight = fresh(); };
  /** a request from command arguments (strings from the editor, or plain values from a script call) */
  M.request = function (args) {
    var d = deps(); if (!d) return null; args = args || {};
    var seedText = str(args.seed, ''), seed = seedText === '' ? d.core.mix(d.core.hashString('leadlight') ^ (M.record().played * 7919), (typeof $gameSystem !== 'undefined' && $gameSystem ? $gameSystem.playtime() : 0) >>> 0)
      : (/^\d+$/.test(seedText) ? (Number(seedText) >>> 0) : d.core.hashString(seedText));
    var style = str(args.style, 'auto');
    return { seed: seed, picture: str(args.picture, ''), style: d.draw.STYLES.indexOf(style) >= 0 ? style : d.draw.STYLES[seed % d.draw.STYLES.length],
      target: Math.max(30, Math.min(100, Math.floor(num(args.target, 85)))), lives: Math.max(1, Math.min(9, Math.floor(num(args.lives, 3)))), powers: bool(args.powers, true),
      secondsVariable: Math.max(0, Math.floor(num(args.secondsVariable, 0))), ballsLostVariable: Math.max(0, Math.floor(num(args.ballsLostVariable, 0))),
      percentVariable: Math.max(0, Math.floor(num(args.percentVariable, 0))), clearedSwitch: Math.max(0, Math.floor(num(args.clearedSwitch, 0))), isRequest: true };
  };
  M._open = false;
  /** start a game (script call: the command's options). Without a picture it starts nothing and says so once; refused while one is open */
  M.start = function (opts) {
    var req = opts && opts.isRequest ? opts : M.request(opts || {});
    if (!req || M._open) return false;
    if (!req.picture) { if (!M._warnedPic) { M._warnedPic = true; console.warn('Leadlight: name a picture from img/pictures in the command. No game started.'); } return false; }
    M._open = true; SceneManager.push(Scene_Leadlight); SceneManager.prepareNextScene(req); return true;
  };
  M.isOpen = function () { return M._open; };
  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) PluginManager.registerCommand(NAME, 'leadlight', function (args) { if (M.start(M.request(args))) this.setWaitMode('leadlight'); });
  var _updateWaitMode = Game_Interpreter.prototype.updateWaitMode;
  Game_Interpreter.prototype.updateWaitMode = function () {
    if (this._waitMode === 'leadlight') { if (SceneManager._scene instanceof Scene_Leadlight || SceneManager._nextScene instanceof Scene_Leadlight) return true; this._waitMode = ''; return false; }
    return _updateWaitMode.call(this);
  };
  M.VERSION = '1.0.0';
}(Leadlight));

//=============================================================================
// Scene_Leadlight
//=============================================================================

function Scene_Leadlight() { this.initialize.apply(this, arguments); }
Scene_Leadlight.prototype = Object.create(Scene_Base.prototype);
Scene_Leadlight.prototype.constructor = Scene_Leadlight;
/** the logical stage every number here is written for; scaled to fit and centred on any screen (as Broadside) */
Scene_Leadlight.W = 816; Scene_Leadlight.H = 624;
Scene_Leadlight.L = { hudH: 44, ox: 24, oy: 58, paneW: 768, paneH: 360, laneH: 190, shards: 28, shardS: 22 };
Scene_Leadlight.prototype.prepare = function (req) { this._req = req; };
Scene_Leadlight.prototype.create = function () {
  Scene_Base.prototype.create.call(this);
  this._d = Leadlight.deps(); this._pic = ImageManager.loadPicture(this._req.picture);
  this._mode = 'loading'; this._t = 0; this._read = 0; this._ev = [0, 0, 0]; this._inp = { x: NaN, launch: false }; this._tp = { x: 0, y: 0 };
  var W = Scene_Leadlight.W, H = Scene_Leadlight.H, s = Math.min(Graphics.width / W, Graphics.height / H);
  this._k = s; this._ox = Math.round((Graphics.width - W * s) / 2); this._oy = Math.round((Graphics.height - H * s) / 2);
  this._root = new Sprite(); this._root.scale.x = this._root.scale.y = s; this._root.x = this._ox; this._root.y = this._oy; this.addChild(this._root);
  var bg = new Sprite(new Bitmap(Graphics.width, Graphics.height)); bg.bitmap.fillAll('#141118'); this.addChildAt(bg, 0);
};
Scene_Leadlight.prototype.start = function () { Scene_Base.prototype.start.call(this); this.startFadeIn(this.fadeSpeed(), false); };
/** built once the picture has loaded: read its pixels ONCE (never during play, Probe_Doctrine §27a), cut the pane */
Scene_Leadlight.prototype.build = function () {
  var C = this._d.core, D = this._d.draw, L = Scene_Leadlight.L, req = this._req, pic = this._pic, pw = Math.max(1, pic.width), ph = Math.max(1, pic.height);
  var src = pic.canvas, px = src.getContext('2d').getImageData(0, 0, pw, ph).data;
  this._pane = C.paneFromPixels(px, pw, ph, { W: L.paneW, H: L.paneH, layout: req.style === 'brick' ? 'stagger' : 'grid', seed: req.seed, powers: req.powers });
  this._game = C.createGame(req.seed, this._pane, { H: L.paneH + L.laneH, lives: req.lives, target: req.target });
  var root = this._root, self = this;
  this._frame = new Sprite(new Bitmap(Scene_Leadlight.W, Scene_Leadlight.H)); D.drawFrame(this._frame.bitmap.context, Scene_Leadlight.W, Scene_Leadlight.H, L.ox, L.oy, L.paneW, L.paneH, L.laneH); this._frame.bitmap._baseTexture.update(); root.addChild(this._frame);
  // the picture, cover-fitted into the pane opening and masked to it
  var k = Math.max(L.paneW / pw, L.paneH / ph), ps = new Sprite(pic); ps.scale.x = ps.scale.y = k; ps.x = L.ox + (L.paneW - pw * k) / 2; ps.y = L.oy + (L.paneH - ph * k) / 2;
  var mask = new PIXI.Graphics(); mask.beginFill(0xffffff); mask.drawRect(L.ox, L.oy, L.paneW, L.paneH); mask.endFill(); root.addChild(mask); ps.mask = mask; root.addChild(ps); this._picSprite = ps;
  // the glass, drawn whole once; a cell is redrawn only when it cracks or breaks
  this._glassCv = req.style === 'brick' ? null : D.glassImage(src, pw, ph, L.paneW, L.paneH, req.style);
  this._paneSp = new Sprite(new Bitmap(L.paneW, L.paneH)); this._paneSp.x = L.ox; this._paneSp.y = L.oy; D.drawPane(this._paneSp.bitmap.context, this._pane, this._game.left, req.style, req.seed, this._glassCv); this._paneSp.bitmap._baseTexture.update(); root.addChild(this._paneSp);
  // shards: one strip of four slivers, a pool of sprites tinted with the colour of the cell they came from
  var sb = new Bitmap(L.shardS * 4, L.shardS); D.drawShards(sb.context, L.shardS); sb._baseTexture.update();
  this._shards = []; for (var i = 0; i < L.shards; i++) { var sh = new Sprite(sb); sh.setFrame((i % 4) * L.shardS, 0, L.shardS, L.shardS); sh.anchor.x = sh.anchor.y = 0.5; sh.visible = false; sh._life = 0; sh._vx = 0; sh._vy = 0; sh._vr = 0; this._shards.push(sh); root.addChild(sh); }
  this._shardNext = 0;
  var P = this._game.paddle; this._paddleBmp = [P.w0, P.w0 * 1.5].map(function (w) { var b = new Bitmap(Math.ceil(w), P.h); D.drawPaddle(b.context, b.width, b.height); b._baseTexture.update(); return b; });
  this._paddle = new Sprite(this._paddleBmp[0]); this._paddle.anchor.x = 0.5; root.addChild(this._paddle);
  var bb = new Bitmap(this._game.ballR * 2 + 2, this._game.ballR * 2 + 2); D.drawBall(bb.context, bb.width); bb._baseTexture.update();
  this._balls = this._game.balls.map(function () { var s = new Sprite(bb); s.anchor.x = s.anchor.y = 0.5; s.visible = false; root.addChild(s); return s; });
  this._capBmp = C.POWERS.map(function (kind) { var b = new Bitmap(22, 22); D.drawCap(b.context, 22, kind); b._baseTexture.update(); return b; });
  this._caps = this._game.caps.map(function () { var s = new Sprite(self._capBmp[0]); s.anchor.x = s.anchor.y = 0.5; s.visible = false; root.addChild(s); return s; });
  this._hud = new Sprite(new Bitmap(Scene_Leadlight.W, L.hudH)); this._hud.y = 6; root.addChild(this._hud); this._hudKey = -1; this.drawHud();
  this._results = new Sprite(new Bitmap(Scene_Leadlight.W, Scene_Leadlight.H)); this._results.visible = false; root.addChild(this._results);
  this._mode = 'play'; this.sync();
};
Scene_Leadlight.prototype.drawHud = function () {
  var g = this._game, C = this._d.core, key = Math.floor(C.percent(g)) * 16 + g.lives; if (key === this._hudKey) return; this._hudKey = key;
  this._d.draw.drawHud(this._hud.bitmap.context, Scene_Leadlight.W, Scene_Leadlight.L.hudH, { title: 'Leadlight', percent: C.percent(g), target: g.target * 100, lives: g.lives, livesMax: g.livesMax }); this._hud.bitmap._baseTexture.update();
};
Scene_Leadlight.prototype.update = function () {
  Scene_Base.prototype.update.call(this);
  if (this._mode === 'loading') { if (this._pic.isReady()) this.build(); return; }
  this._t++;
  if (this._mode === 'play') this.updatePlay();
  else if (this._mode === 'falling') this.updateFalling();
  else if (this._mode === 'results' && this._t > 30 && (Input.isTriggered('ok') || TouchInput.isTriggered())) this.leave();
  this.updateShards();
};
/** where the bar should go this frame: the pointer while one is over the stage, else the arrow keys */
Scene_Leadlight.prototype.steer = function () {
  var g = this._game, P = g.paddle, inp = this._inp, L = Scene_Leadlight.L;
  inp.launch = Input.isTriggered('ok') || TouchInput.isTriggered();
  // MZ reports a mouse moving with no button down as HOVERED, not moved (rmmz_core TouchInput._onHover)
  if (TouchInput.isPressed() || TouchInput.isMoved() || (TouchInput.isHovered && TouchInput.isHovered())) { this._tp.x = (TouchInput.x - this._ox) / this._k - L.ox; inp.x = this._tp.x; this._pointer = true; }
  else if (Input.isPressed('left')) { inp.x = P.x - P.speed; this._pointer = false; }
  else if (Input.isPressed('right')) { inp.x = P.x + P.speed; this._pointer = false; }
  else if (!this._pointer) inp.x = NaN;
  return inp;
};
Scene_Leadlight.prototype.updatePlay = function () {
  var C = this._d.core, g = this._game;
  C.step(g, this.steer());
  this.readEvents(); this.sync(); this.drawHud();
  if (g.phase === 'won') { this._mode = 'falling'; this._fallT = 0; this.playSe(Leadlight.params.winSe, 90); }
  else if (g.phase === 'lost') this.showResults();
};
/** the core's events since the last frame: redraw what changed, throw shards, play sounds. No allocation. */
Scene_Leadlight.prototype.readEvents = function () {
  var C = this._d.core, D = this._d.draw, g = this._game, E = C.EV, ev = this._ev, ctx = this._paneSp.bitmap.context, dirty = false, P = Leadlight.params;
  if (g.evN - this._read > C.RING) this._read = g.evN - C.RING;
  for (; this._read < g.evN; this._read++) {
    if (!C.event(g, this._read, ev)) continue;
    var code = ev[0], i = ev[1];
    if (code === E.CRACK || code === E.BREAK) { D.redrawAround(ctx, this._pane, i, g.left, this._req.style, this._req.seed, this._glassCv); dirty = true; }
    if (code === E.BREAK) { this.throwShards(this._pane.cells[i]); this.playSe(P.breakSe, 75); }
    else if (code === E.CRACK) this.playSe(P.crackSe, 60);
    else if (code === E.PADDLE) this.playSe(P.paddleSe, 45);
    else if (code === E.LOST) this.playSe(P.lostSe, 80);
    else if (code === E.CATCH) this.playSe(P.powerSe, 80);
  }
  if (dirty) this._paneSp.bitmap._baseTexture.update();
};
Scene_Leadlight.prototype.playSe = function (name, vol) { if (name) AudioManager.playSe({ name: name, volume: vol, pitch: 100, pan: 0 }); };
/** a broken cell throws four shards of its own colour, falling and spinning */
Scene_Leadlight.prototype.throwShards = function (c) {
  // the cell's colour taken halfway to white: LOOKED AT 2026-10-11, shards in the cell's own dark red read as flecks of
  // soot against the dark lane, not as glass catching the light
  var L = Scene_Leadlight.L, mix = function (v) { return Math.min(255, Math.round(v + (255 - v) * 0.5)); }, tint = (mix(c.r) << 16) | (mix(c.g) << 8) | mix(c.b);
  for (var k = 0; k < 4; k++) {
    var s = this._shards[this._shardNext]; this._shardNext = (this._shardNext + 1) % this._shards.length;
    s.x = L.ox + c.x + c.w * (0.2 + 0.2 * k); s.y = L.oy + c.y + c.h * (0.3 + 0.15 * (k % 2)); s._vx = (k - 1.5) * 0.9; s._vy = -1.5 - (k % 2); s._vr = (k % 2 ? 0.12 : -0.1); s._life = 70; s.tint = tint; s.opacity = 255; s.rotation = k; s.visible = true;
  }
};
Scene_Leadlight.prototype.updateShards = function () {
  if (!this._shards) return;
  for (var i = 0; i < this._shards.length; i++) { var s = this._shards[i]; if (s._life <= 0) continue; s._life--; s._vy += 0.18; s.x += s._vx; s.y += s._vy; s.rotation += s._vr; s.opacity = s._life < 20 ? s._life * 12 : 255; if (s._life <= 0) s.visible = false; }
};
/** sprites follow the game: the bar (its wide bitmap while the power lasts), the balls, the capsules */
Scene_Leadlight.prototype.sync = function () {
  var g = this._game, L = Scene_Leadlight.L, P = g.paddle;
  this._paddle.bitmap = P.w > P.w0 + 0.5 ? this._paddleBmp[1] : this._paddleBmp[0]; this._paddle.x = L.ox + P.x; this._paddle.y = L.oy + P.y;
  for (var i = 0; i < this._balls.length; i++) { var b = g.balls[i], s = this._balls[i]; s.visible = b.active; s.x = L.ox + b.x; s.y = L.oy + b.y; }
  for (var j = 0; j < this._caps.length; j++) { var c = g.caps[j], cs = this._caps[j]; cs.visible = c.active; if (c.active) { cs.bitmap = this._capBmp[c.kind]; cs.x = L.ox + c.x; cs.y = L.oy + c.y; } }
};
/** the target is broken: the rest of the glass falls away over 40 frames, then the picture is shown with the results */
Scene_Leadlight.prototype.updateFalling = function () {
  this._fallT++; this._paneSp.opacity = Math.max(0, 255 - this._fallT * 7); this._paneSp.y = Scene_Leadlight.L.oy + this._fallT * this._fallT * 0.05;
  if (this._fallT === 1) { for (var i = 0; i < this._balls.length; i++) this._balls[i].visible = false; for (var j = 0; j < this._caps.length; j++) this._caps[j].visible = false; }
  if (this._fallT >= 40) { this._paneSp.visible = false; this.showResults(); }
};
Scene_Leadlight.prototype.showResults = function () {
  var res = this._d.core.results(this._game), b = this._results.bitmap;
  this._d.draw.drawResults(b.context, Scene_Leadlight.W, Scene_Leadlight.H, res); b._baseTexture.update();
  this._results.visible = true; this._res = res; this._mode = 'results'; this._t = 0;
};
Scene_Leadlight.prototype.leave = function () {
  if (this._mode === 'leaving') return;
  var req = this._req, m = this._res, rec = Leadlight.record();
  if (req.secondsVariable > 0) $gameVariables.setValue(req.secondsVariable, m.seconds);
  if (req.ballsLostVariable > 0) $gameVariables.setValue(req.ballsLostVariable, m.ballsLost);
  if (req.percentVariable > 0) $gameVariables.setValue(req.percentVariable, Math.floor(m.percent));
  if (req.clearedSwitch > 0) $gameSwitches.setValue(req.clearedSwitch, m.won);
  rec.played++; if (m.won) rec.cleared++; rec.best = Math.max(rec.best, Math.floor(m.percent));
  this._mode = 'leaving'; this.popScene();
};
Scene_Leadlight.prototype.stop = function () { Scene_Base.prototype.stop.call(this); this.startFadeOut(this.fadeSpeed(), false); };
Scene_Leadlight.prototype.terminate = function () { Scene_Base.prototype.terminate.call(this); Leadlight._open = false; };
