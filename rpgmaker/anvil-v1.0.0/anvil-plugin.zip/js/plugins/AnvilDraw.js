//=============================================================================
// AnvilDraw.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Anvil draw - the smithy, the anvil, the glowing bar, the
 * temper colour chart, sparks, steam and the finished blade, all drawn in code.
 * Place BETWEEN AnvilCore and Anvil.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * Every picture Anvil shows is drawn here onto a canvas: no image file is
 * loaded. No parameters of its own. Must be installed below AnvilCore.js and
 * above Anvil.js.
 *
 * The bar is drawn once per blow, white and shaded; the scene colours it by
 * its heat with a tint, so the glow can fade every frame without repainting.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var AnvilDraw = (function () {
  'use strict';
  var TAU = Math.PI * 2;
  var FACE = '"Palatino Linotype", "Book Antiqua", Palatino, "Georgia", serif';
  var INK = '#2a1d12', PAPER = ['#f3e7cc', '#e2d1ab'];

  function rng(seed) { var a = seed >>> 0; return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function rr(ctx, x, y, w, h, r) { r = Math.max(0, Math.min(r, w / 2, h / 2)); ctx.beginPath(); ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r); ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h); ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r); ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.closePath(); }
  function fitText(ctx, text, maxW, size, style) { ctx.font = (style || 'bold') + ' ' + size + 'px ' + FACE; while (size > 9 && ctx.measureText(text).width > maxW) { size--; ctx.font = (style || 'bold') + ' ' + size + 'px ' + FACE; } return size; }

  // The heat colours, a blackbody ramp from black iron to white heat (h = 0..1). Returned as 0xRRGGBB for a tint.
  var RAMP = [[0, [58, 52, 48]], [0.2, [96, 30, 18]], [0.32, [150, 26, 12]], [0.42, [196, 36, 14]], [0.56, [232, 76, 18]], [0.66, [255, 132, 30]], [0.78, [255, 196, 80]], [0.9, [255, 236, 170]], [1, [255, 250, 225]]];
  /** The colour of metal at heat h, as [r, g, b]. */
  function heatRgb(h) {
    h = Math.max(0, Math.min(1, h));
    for (var i = 1; i < RAMP.length; i++) if (h <= RAMP[i][0]) { var a = RAMP[i - 1], b = RAMP[i], k = (h - a[0]) / (b[0] - a[0]); return [Math.round(a[1][0] + (b[1][0] - a[1][0]) * k), Math.round(a[1][1] + (b[1][1] - a[1][1]) * k), Math.round(a[1][2] + (b[1][2] - a[1][2]) * k)]; }
    return RAMP[RAMP.length - 1][1].slice();
  }
  /** The heat colour as a tint number (no allocation beyond the rgb triple). */
  function heatTint(h) { var c = heatRgb(h); return (c[0] << 16) | (c[1] << 8) | c[2]; }
  function css(c, a) { return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + (a === undefined ? 1 : a) + ')'; }

  var METAL = { steel: ['#eef2f5', '#aab4bd', '#5c666f'], iron: ['#dcdcd6', '#8f8f88', '#4b4a45'], bronze: ['#f6d49a', '#c08a44', '#6e4a1c'], mithril: ['#f2fbff', '#b9d6e6', '#6c8fa6'], blacksteel: ['#9aa0aa', '#4a4f58', '#1c1f24'] };

  //===========================================================================
  // The smithy
  //===========================================================================

  /** Stone wall, the hearth on the left, a quench trough on the right, a timber floor under the anvil. */
  function drawSmithy(ctx, W, H) {
    var r = rng(0x5A1);
    var g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#2a211b'); g.addColorStop(1, '#120d0a'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    // stone courses
    for (var row = 0; row * 34 < 212; row++) {
      var y = row * 34, off = row % 2 ? 36 : 0;
      for (var x = -off; x < W + 72; x += 72 + Math.floor(r() * 10)) {
        var sw = 66 + r() * 10, sh = 29 + r() * 3, v = 38 + Math.floor(r() * 22);
        ctx.fillStyle = 'rgb(' + v + ',' + (v - 6) + ',' + (v - 12) + ')'; rr(ctx, x + 2, y + 2, sw, sh, 5); ctx.fill();
        ctx.fillStyle = 'rgba(255,220,180,0.05)'; rr(ctx, x + 3, y + 3, sw - 2, 6, 3); ctx.fill();
        ctx.fillStyle = 'rgba(0,0,0,0.25)'; rr(ctx, x + 2, y + sh - 4, sw, 5, 3); ctx.fill();
      }
    }
    // timber floor
    for (var p = 0; p < 9; p++) { var fy = 212 + p * 46; var fg = ctx.createLinearGradient(0, fy, 0, fy + 46); fg.addColorStop(0, '#3b2616'); fg.addColorStop(1, '#24170d'); ctx.fillStyle = fg; ctx.fillRect(0, fy, W, 45); ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(0, fy + 45, W, 1); for (var k = 0; k < 14; k++) { ctx.strokeStyle = 'rgba(255,200,150,0.04)'; ctx.beginPath(); ctx.moveTo(0, fy + 4 + k * 3); ctx.bezierCurveTo(W * 0.3, fy + 4 + k * 3 + r() * 3, W * 0.7, fy + 2 + k * 3, W + 4, fy + 4 + k * 3); ctx.stroke(); } }
    // hearth: a brick arch on the left with coals
    var hx = -20, hy = 214, hw = 150, hh = 210;
    ctx.fillStyle = '#4a2a1c'; rr(ctx, hx, hy - 10, hw + 30, hh + 20, 18); ctx.fill();
    for (var b = 0; b < 26; b++) { ctx.fillStyle = b % 2 ? '#6a3522' : '#5a2d1d'; rr(ctx, hx + 4 + (b % 3) * 56, hy - 6 + Math.floor(b / 3) * 26, 52, 22, 3); ctx.fill(); }
    ctx.fillStyle = '#0c0705'; rr(ctx, hx + 14, hy + 20, hw - 6, hh - 40, 60); ctx.fill();
    var cg = ctx.createRadialGradient(hx + 80, hy + hh - 40, 4, hx + 80, hy + hh - 60, 120); cg.addColorStop(0, 'rgba(255,190,80,0.95)'); cg.addColorStop(0.35, 'rgba(230,90,20,0.7)'); cg.addColorStop(1, 'rgba(120,20,5,0)'); ctx.fillStyle = cg; ctx.fillRect(hx, hy, hw + 30, hh);
    for (var c = 0; c < 70; c++) { var cx = hx + 26 + r() * (hw - 30), cy = hy + hh - 34 - r() * 26, cr = 3 + r() * 6; var hot = r(); ctx.fillStyle = hot > 0.6 ? '#ffd27a' : (hot > 0.3 ? '#f07a22' : '#8a2a10'); ctx.beginPath(); ctx.arc(cx, cy, cr, 0, TAU); ctx.fill(); }
    // quench trough bottom right
    var tx = 640, ty = 470, tw = 160, th = 120;
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; rr(ctx, tx + 6, ty + 8, tw, th, 10); ctx.fill();
    ctx.fillStyle = '#4a2f1a'; rr(ctx, tx, ty, tw, th, 10); ctx.fill(); ctx.strokeStyle = '#2a1a0e'; ctx.lineWidth = 3; for (var s = 1; s < 4; s++) { ctx.beginPath(); ctx.moveTo(tx + 6, ty + s * 30); ctx.lineTo(tx + tw - 6, ty + s * 30); ctx.stroke(); }
    var wg = ctx.createLinearGradient(0, ty + 14, 0, ty + th - 14); wg.addColorStop(0, '#1d3a44'); wg.addColorStop(1, '#0b1a20'); ctx.fillStyle = wg; rr(ctx, tx + 12, ty + 14, tw - 24, th - 28, 6); ctx.fill();
    ctx.strokeStyle = 'rgba(160,220,240,0.18)'; ctx.lineWidth = 1; for (var q = 0; q < 6; q++) { ctx.beginPath(); ctx.ellipse(tx + 40 + q * 18, ty + 40 + (q % 3) * 18, 14, 3, 0, 0, TAU); ctx.stroke(); }
    // warm light from the hearth across the room, and a vignette
    var lg = ctx.createRadialGradient(60, 330, 20, 60, 330, 620); lg.addColorStop(0, 'rgba(255,140,50,0.22)'); lg.addColorStop(1, 'rgba(255,140,50,0)'); ctx.fillStyle = lg; ctx.fillRect(0, 0, W, H);
    var vg = ctx.createRadialGradient(W / 2, H / 2, H * 0.3, W / 2, H / 2, H * 0.9); vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.55)'); ctx.fillStyle = vg; ctx.fillRect(0, 0, W, H);
  }

  /** The anvil seen from above: horn to the left, the flat face, the heel with the hardy and pritchel holes, on a stump. */
  var ANV = { x: 176, y: 262, w: 520, h: 132 };
  function drawAnvil(ctx) {
    var A = ANV, cx = A.x, cy = A.y + A.h / 2;
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.beginPath(); ctx.ellipse(cx + A.w / 2 + 10, cy + 20, A.w / 2 + 30, A.h / 2 + 30, 0, 0, TAU); ctx.fill();
    // stump ring showing round the anvil's waist
    var sg = ctx.createRadialGradient(cx + A.w / 2, cy, 20, cx + A.w / 2, cy, 160); sg.addColorStop(0, '#6a4424'); sg.addColorStop(1, '#3a2412'); ctx.fillStyle = sg; ctx.beginPath(); ctx.ellipse(cx + A.w * 0.55, cy + 6, 150, 96, 0, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(30,15,5,0.6)'; for (var ring = 30; ring < 150; ring += 14) { ctx.beginPath(); ctx.ellipse(cx + A.w * 0.55, cy + 6, ring, ring * 0.64, 0, 0, TAU); ctx.stroke(); }
    // ⛔ found by looking (2026-09-27): face + horn alone read as a grey boat. The FEET splay out beyond the face in
    // a top view, darker and lower, and that is what makes the shape an anvil.
    // (a first pass drew the feet as four spikes and they read as FINS: a rounded base plate with a waist reads as feet)
    var fx0 = cx + 150, fx1 = cx + A.w - 10, ft = cy - A.h / 2 - 26, fb = cy + A.h / 2 + 26;
    ctx.fillStyle = '#16181b'; ctx.beginPath(); ctx.moveTo(fx0 + 20, ft); ctx.quadraticCurveTo((fx0 + fx1) / 2, ft + 22, fx1 - 20, ft); ctx.quadraticCurveTo(fx1 + 12, ft, fx1 + 12, ft + 26); ctx.lineTo(fx1 + 12, fb - 26); ctx.quadraticCurveTo(fx1 + 12, fb, fx1 - 20, fb); ctx.quadraticCurveTo((fx0 + fx1) / 2, fb - 22, fx0 + 20, fb); ctx.quadraticCurveTo(fx0 - 12, fb, fx0 - 12, fb - 26); ctx.lineTo(fx0 - 12, ft + 26); ctx.quadraticCurveTo(fx0 - 12, ft, fx0 + 20, ft); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = 'rgba(120,130,140,0.35)'; ctx.lineWidth = 1.5; ctx.stroke();
    // the body outline: horn (a cone to a point) + face + heel
    ctx.save();
    ctx.beginPath(); ctx.moveTo(cx - 40, cy); ctx.quadraticCurveTo(cx + 20, cy - A.h * 0.36, cx + 110, cy - A.h / 2); ctx.lineTo(cx + A.w, cy - A.h / 2); ctx.lineTo(cx + A.w, cy + A.h / 2); ctx.lineTo(cx + 110, cy + A.h / 2); ctx.quadraticCurveTo(cx + 20, cy + A.h * 0.36, cx - 40, cy); ctx.closePath();
    ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.translate(6, 8); ctx.fill(); ctx.translate(-6, -8);
    var fg = ctx.createLinearGradient(0, cy - A.h / 2, 0, cy + A.h / 2); fg.addColorStop(0, '#7c8288'); fg.addColorStop(0.18, '#4a4f55'); fg.addColorStop(0.5, '#2e3237'); fg.addColorStop(0.85, '#3c4147'); fg.addColorStop(1, '#1c1f22'); ctx.fillStyle = fg; ctx.fill();
    ctx.strokeStyle = '#121416'; ctx.lineWidth = 2; ctx.stroke();
    // the horn is round: a highlight along its crown, fading to the point
    ctx.clip(); var hl = ctx.createLinearGradient(cx - 40, 0, cx + 116, 0); hl.addColorStop(0, 'rgba(210,220,230,0)'); hl.addColorStop(1, 'rgba(210,220,230,0.45)'); ctx.strokeStyle = hl; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(cx - 30, cy - 2); ctx.quadraticCurveTo(cx + 40, cy - A.h * 0.2, cx + 116, cy - A.h * 0.26); ctx.stroke();
    ctx.restore();
    // the polished face (a lighter band) and the step to the horn
    var face = ctx.createLinearGradient(0, cy - A.h / 2 + 10, 0, cy + A.h / 2 - 10); face.addColorStop(0, '#8e959c'); face.addColorStop(0.5, '#5d646b'); face.addColorStop(1, '#3d4349');
    ctx.fillStyle = face; rr(ctx, cx + 116, cy - A.h / 2 + 10, A.w - 130, A.h - 20, 6); ctx.fill();
    var r = rng(0xA11); for (var i = 0; i < 260; i++) { ctx.fillStyle = r() < 0.5 ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.12)'; ctx.fillRect(cx + 120 + r() * (A.w - 140), cy - A.h / 2 + 14 + r() * (A.h - 28), 1 + r() * 4, 1); }
    ctx.fillStyle = '#101214'; rr(ctx, cx + A.w - 52, cy - 14, 22, 22, 2); ctx.fill(); ctx.beginPath(); ctx.arc(cx + A.w - 86, cy + 22, 7, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(210,220,230,0.35)'; ctx.lineWidth = 1.2; rr(ctx, cx + 116, cy - A.h / 2 + 10, A.w - 130, A.h - 20, 6); ctx.stroke();
  }

  /** The temper chart pinned to the wall: the colour ramp with the smith's names under it. Returns its geometry. */
  function drawTemperChart(ctx, x, y, w, h, bands, quench) {
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; rr(ctx, x + 3, y + 5, w, h + 34, 5); ctx.fill();
    var pg = ctx.createLinearGradient(0, y, 0, y + h + 34); pg.addColorStop(0, PAPER[0]); pg.addColorStop(1, PAPER[1]); ctx.fillStyle = pg; rr(ctx, x, y, w, h + 34, 5); ctx.fill();
    ctx.strokeStyle = '#6a4a22'; ctx.lineWidth = 1; rr(ctx, x + 4, y + 4, w - 8, h + 26, 3); ctx.stroke();
    ctx.fillStyle = '#6a3a18'; ctx.font = 'bold 11px ' + FACE; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('THE COLOURS OF THE IRON', x + w / 2, y + 12);
    var sx = x + 12, sw = w - 24, sy = y + 22;
    for (var i = 0; i < sw; i++) { ctx.fillStyle = css(heatRgb(i / (sw - 1))); ctx.fillRect(sx + i, sy, 1, h - 16); }
    ctx.strokeStyle = 'rgba(40,20,5,0.8)'; ctx.strokeRect(sx + 0.5, sy + 0.5, sw - 1, h - 17);
    // the quench band bracketed
    var q0 = sx + quench[0] * sw, q1 = sx + quench[1] * sw;
    ctx.strokeStyle = '#1e5a6a'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(q0, sy + h - 12); ctx.lineTo(q0, sy + h - 8); ctx.lineTo(q1, sy + h - 8); ctx.lineTo(q1, sy + h - 12); ctx.stroke();
    ctx.fillStyle = '#1e5a6a'; ctx.font = 'italic 10px ' + FACE; ctx.fillText('quench', (q0 + q1) / 2, sy + h - 1);
    ctx.fillStyle = INK; ctx.font = '10px ' + FACE;
    for (var b = 1; b < bands.length; b++) { var bx = sx + bands[b][0] * sw; ctx.fillStyle = 'rgba(40,20,5,0.5)'; ctx.fillRect(bx, sy, 1, h - 16); }
    // ⛔ found by looking: six names crowded the hot end; four, at band middles
    var names = [[0.1, 'black'], [0.26, 'blood'], [0.49, 'cherry'], [0.72, 'orange'], [0.94, 'white']];
    for (var n = 0; n < names.length; n++) { ctx.fillStyle = INK; ctx.fillText(names[n][1], sx + names[n][0] * sw, sy + h + 8); }
    return { sx: sx, sw: sw, sy: sy, sh: h - 16 };
  }

  /** The pointer that rides the temper chart (a small brass arrow, drawn once; the scene moves it). */
  function drawPointer(ctx) { ctx.clearRect(0, 0, 20, 22); ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.beginPath(); ctx.moveTo(11, 21); ctx.lineTo(2, 5); ctx.lineTo(20, 5); ctx.fill(); var g = ctx.createLinearGradient(0, 0, 18, 0); g.addColorStop(0, '#8a6120'); g.addColorStop(0.5, '#ffe6a0'); g.addColorStop(1, '#8a6120'); ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(10, 19); ctx.lineTo(1, 3); ctx.lineTo(19, 3); ctx.closePath(); ctx.fill(); ctx.strokeStyle = '#3a2408'; ctx.lineWidth = 1; ctx.stroke(); }

  //===========================================================================
  // The bar (drawn white and shaded; the scene tints it by heat)
  //===========================================================================

  /** Bar geometry on screen: x0..x0+len along the anvil face, centred on cy, half-width scale hs px. */
  var BAR = { x0: 200, len: 470, cy: 328, hs: 56 };
  function barPath(ctx, prof, L) { var n = prof.length, i; ctx.beginPath(); for (i = 0; i < n; i++) { var x = L.x0 + (i / (n - 1)) * L.len, y = L.cy - prof[i] * L.hs; if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); } for (i = n - 1; i >= 0; i--) ctx.lineTo(L.x0 + (i / (n - 1)) * L.len, L.cy + prof[i] * L.hs); ctx.closePath(); }
  /**
   * The workpiece on a transparent bitmap the size of the screen area it covers (drawn at bitmap offset ox, oy):
   * a white-to-grey body with a raised spine, facets where the hammer struck, fire scale that the blows knock off,
   * and dark cracks where it was struck too cold.
   */
  function drawWork(ctx, prof, marks, flaws, seed, strikes) {
    var L = BAR, n = prof.length, i;
    ctx.save();
    barPath(ctx, prof, L); ctx.clip();
    var g = ctx.createLinearGradient(0, L.cy - L.hs, 0, L.cy + L.hs); g.addColorStop(0, '#9a9a9a'); g.addColorStop(0.35, '#ffffff'); g.addColorStop(0.55, '#e8e8e8'); g.addColorStop(1, '#6a6a6a'); ctx.fillStyle = g; ctx.fillRect(L.x0 - 4, L.cy - L.hs - 4, L.len + 8, L.hs * 2 + 8);
    // a spine down the centre, and the edge bevels
    ctx.strokeStyle = 'rgba(255,255,255,0.8)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(L.x0, L.cy - 1); ctx.lineTo(L.x0 + L.len, L.cy - 1); ctx.stroke();
    ctx.strokeStyle = 'rgba(0,0,0,0.25)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(L.x0, L.cy + 2); ctx.lineTo(L.x0 + L.len, L.cy + 2); ctx.stroke();
    // hammer facets
    for (i = 0; i < marks.length; i++) { var m = marks[i], mx = L.x0 + (m.p / (n - 1)) * L.len, mw = prof[m.p] * L.hs, rr2 = rng(seed + i * 31)(); ctx.fillStyle = rr2 < 0.5 ? 'rgba(255,255,255,0.12)' : 'rgba(0,0,0,0.09)'; ctx.beginPath(); ctx.ellipse(mx + (rr2 - 0.5) * 6, L.cy + (rr2 - 0.5) * mw * 0.7, 11, Math.max(3, mw * 0.32), 0, 0, TAU); ctx.fill(); }
    // fire scale: dark flakes, fewer as blows knock them off
    // ⛔ found by looking: 160 dark flakes at up to 0.75 alpha read as chips in a biscuit on the hot bar. Fewer, fainter.
    var r = rng(seed ^ 0x5CA), flakes = Math.max(0, 56 - strikes * 3);
    for (i = 0; i < flakes; i++) { var fi = Math.floor(r() * n), fx = L.x0 + (fi / (n - 1)) * L.len + (r() - 0.5) * 8, fw = prof[fi] * L.hs; ctx.fillStyle = 'rgba(40,30,24,' + (0.18 + r() * 0.22) + ')'; ctx.beginPath(); ctx.ellipse(fx, L.cy + (r() * 2 - 1) * fw * 0.8, 1.5 + r() * 3, 0.8 + r() * 1.5, r() * 3, 0, TAU); ctx.fill(); }
    // cracks
    for (i = 0; i < flaws.length; i++) { var p = flaws[i], cxp = L.x0 + (p / (n - 1)) * L.len, cw = prof[p] * L.hs, cr = rng(seed + p * 131 + i); ctx.strokeStyle = 'rgba(10,6,4,0.95)'; ctx.lineWidth = 1.6; ctx.beginPath(); var yy = L.cy - cw; ctx.moveTo(cxp, yy); for (var s = 1; s <= 6; s++) { yy += cw * 0.3; ctx.lineTo(cxp + (cr() - 0.5) * 8, yy); } ctx.stroke(); }
    ctx.restore();
    barPath(ctx, prof, L); ctx.strokeStyle = 'rgba(40,40,40,0.9)'; ctx.lineWidth = 1.4; ctx.stroke();
  }
  /** A soft white halo round the bar; the scene tints it and fades it with the heat. */
  function drawGlow(ctx, prof) {
    var L = BAR; ctx.save(); ctx.filter = 'blur(12px)'; barPath(ctx, prof, L); ctx.fillStyle = 'rgba(255,255,255,0.9)'; ctx.fill(); ctx.lineWidth = 14; ctx.strokeStyle = 'rgba(255,255,255,0.6)'; ctx.stroke(); ctx.restore();
  }
  /** The target silhouette chalked on the anvil face. */
  function drawTarget(ctx, prof) {
    var L = BAR; ctx.save(); ctx.setLineDash([6, 4]); ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(245,240,225,0.75)'; barPath(ctx, prof, L); ctx.stroke(); ctx.setLineDash([]); ctx.restore();
  }

  /** The hammer from above, head down: a round striking face with a peen behind it and the haft running off. */
  function drawHammer(ctx, w, h) {
    ctx.clearRect(0, 0, w, h); var cx = w / 2, cy = h * 0.42;
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.ellipse(cx + 8, cy + 12, 30, 24, 0, 0, TAU); ctx.fill();
    var hg = ctx.createLinearGradient(cx - 10, cy, cx + 90, cy + 90); hg.addColorStop(0, '#9a6a3a'); hg.addColorStop(1, '#5a3a1c'); ctx.strokeStyle = hg; ctx.lineWidth = 12; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(cx + 6, cy + 10); ctx.lineTo(cx + 60, cy + 98); ctx.stroke(); ctx.lineCap = 'butt';
    var g = ctx.createRadialGradient(cx - 8, cy - 8, 2, cx, cy, 30); g.addColorStop(0, '#c9d0d6'); g.addColorStop(0.6, '#5d646b'); g.addColorStop(1, '#262a2e'); ctx.fillStyle = g; rr(ctx, cx - 30, cy - 18, 60, 36, 10); ctx.fill();
    ctx.fillStyle = '#7b838a'; ctx.beginPath(); ctx.arc(cx - 16, cy, 15, 0, TAU); ctx.fill(); ctx.strokeStyle = '#1a1d20'; ctx.lineWidth = 1.5; ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.beginPath(); ctx.arc(cx - 20, cy - 4, 5, 0, TAU); ctx.fill();
  }
  /** A spark: a short white streak with a hot core (tinted per spark by the scene). */
  function drawSpark(ctx) { ctx.clearRect(0, 0, 12, 4); var g = ctx.createLinearGradient(0, 0, 12, 0); g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(0.7, 'rgba(255,255,255,0.9)'); g.addColorStop(1, '#ffffff'); ctx.fillStyle = g; rr(ctx, 0, 0.5, 12, 3, 1.5); ctx.fill(); }
  /** A steam puff: a soft white cloud. */
  function drawPuff(ctx) { ctx.clearRect(0, 0, 48, 48); var g = ctx.createRadialGradient(24, 24, 2, 24, 24, 24); g.addColorStop(0, 'rgba(255,255,255,0.8)'); g.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = g; ctx.fillRect(0, 0, 48, 48); }

  //===========================================================================
  // The finished blade
  //===========================================================================

  /**
   * The forged piece as quenched and finished: the player's own profile (not the target), polished in its metal,
   * with the bevel, a fuller on a sword, the hammer facets and any cracks, and a hilt, haft or socket generated for
   * its family. Drawn horizontally from (x, y) with length len and half-width scale hs.
   */
  function drawBlade(ctx, raw, meta, metal, marks, flaws, x, y, len, hs, seed) {
    // ⛔ found by looking (2026-09-27): the finished piece kept the forge's jitter along its edges. A smith grinds after
    // the quench, so the finished outline is the forged profile smoothed (a 5-tap average); the SHAPE stays the player's.
    var n = raw.length, prof = [], i, k0;
    // ⛔ found by looking: an axe head drawn the full length read as a long wedge. Finished, the head is drawn at 62% of
    // the length on its haft (the forged profile is unchanged; only its drawn scale is).
    if (meta.family === 'axe') { x += len * 0.18; len *= 0.62; }
    for (i = 0; i < n; i++) { var s0 = 0, c0 = 0; for (k0 = Math.max(0, i - 2); k0 <= Math.min(n - 1, i + 2); k0++) { s0 += raw[k0]; c0++; } prof.push(s0 / c0); }
    var M = METAL[metal] || METAL.steel, tangAt = Math.floor((meta.tang || 0) * (n - 1));
    var px = function (k) { return x + (k / (n - 1)) * len; };
    // fittings first (under the blade): grip + guard + pommel, or a wooden haft / socket
    var gx = px(tangAt), r = rng(seed ^ 0xF1);
    if (meta.family === 'axe') {
      // the haft crosses the head at the eye, vertically
      var ex = px(Math.round((meta.eye || 0.2) * (n - 1))), wood2 = ctx.createLinearGradient(ex - 10, 0, ex + 10, 0); wood2.addColorStop(0, '#5a3a1c'); wood2.addColorStop(0.5, '#c08a50'); wood2.addColorStop(1, '#5a3a1c');
      ctx.fillStyle = 'rgba(0,0,0,0.4)'; rr(ctx, ex - 6, y - hs * 1.6, 20, hs * 4.2, 8); ctx.fill();
      ctx.fillStyle = wood2; rr(ctx, ex - 10, y - hs * 1.7, 20, hs * 4.2, 8); ctx.fill();
      ctx.strokeStyle = 'rgba(60,30,10,0.4)'; for (var gk = 0; gk < 6; gk++) { ctx.beginPath(); ctx.moveTo(ex - 7 + gk * 2.6, y - hs * 1.6); ctx.lineTo(ex - 6 + gk * 2.6, y + hs * 2.4); ctx.stroke(); }
    } else if (meta.family === 'spear' || meta.family === 'mace') {
      var wood = ctx.createLinearGradient(0, y - 8, 0, y + 8); wood.addColorStop(0, '#9a6a3a'); wood.addColorStop(0.5, '#c08a50'); wood.addColorStop(1, '#5a3a1c');
      ctx.fillStyle = wood; rr(ctx, x - len * 0.45, y - 8, len * 0.45 + (gx - x) + 4, 16, 6); ctx.fill();
      ctx.strokeStyle = 'rgba(60,30,10,0.4)'; for (var k = 0; k < 8; k++) { ctx.beginPath(); ctx.moveTo(x - len * 0.45 + 6, y - 5 + k * 1.5); ctx.bezierCurveTo(x - len * 0.2, y - 6 + k * 1.6, x, y - 4 + k * 1.4, gx, y - 5 + k * 1.5); ctx.stroke(); }
      ctx.fillStyle = '#3a2a1a'; for (var wr = 0; wr < 3; wr++) { rr(ctx, gx - 18 - wr * 9, y - 9, 5, 18, 2); ctx.fill(); }
    } else {
      var gl = meta.family === 'dagger' ? 70 : (meta.family === 'claw' ? 56 : 104);
      var grip = ctx.createLinearGradient(0, y - 9, 0, y + 9); grip.addColorStop(0, '#5a2a1a'); grip.addColorStop(0.5, '#8a4a2a'); grip.addColorStop(1, '#3a1a0e'); ctx.fillStyle = grip; rr(ctx, gx - gl, y - 9, gl, 18, 5); ctx.fill();
      ctx.strokeStyle = 'rgba(20,8,4,0.6)'; ctx.lineWidth = 1.2; for (var wv = gx - gl + 4; wv < gx - 4; wv += 7) { ctx.beginPath(); ctx.moveTo(wv, y - 9); ctx.lineTo(wv + 5, y + 9); ctx.stroke(); }
      var bg = ctx.createLinearGradient(0, y - 40, 0, y + 40); bg.addColorStop(0, '#6a4a1c'); bg.addColorStop(0.5, '#f0d08a'); bg.addColorStop(1, '#6a4a1c'); ctx.fillStyle = bg;
      var gh = meta.family === 'claw' ? 22 : 34 + Math.floor(r() * 10); rr(ctx, gx - 8, y - gh, 12, gh * 2, 4); ctx.fill(); ctx.beginPath(); ctx.arc(gx - 2, y - gh, 6, 0, TAU); ctx.arc(gx - 2, y + gh, 6, 0, TAU); ctx.fill();
      ctx.beginPath(); ctx.ellipse(gx - gl - 8, y, 12, 13, 0, 0, TAU); ctx.fill(); ctx.strokeStyle = '#3a2408'; ctx.lineWidth = 1; ctx.stroke();
    }
    // the blade: from the tang end to the tip, polished
    ctx.save(); ctx.beginPath();
    for (i = tangAt; i < n; i++) { var yy = y - prof[i] * hs; if (i === tangAt) ctx.moveTo(px(i), yy); else ctx.lineTo(px(i), yy); }
    for (i = n - 1; i >= tangAt; i--) ctx.lineTo(px(i), y + prof[i] * hs);
    ctx.closePath();
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.translate(5, 7); ctx.fill(); ctx.translate(-5, -7);
    var mg = ctx.createLinearGradient(0, y - hs, 0, y + hs); mg.addColorStop(0, M[2]); mg.addColorStop(0.3, M[0]); mg.addColorStop(0.5, M[1]); mg.addColorStop(0.7, M[0]); mg.addColorStop(1, M[2]); ctx.fillStyle = mg; ctx.fill();
    ctx.clip();
    // the ground edge bevels, a fuller, the facets and any cracks
    ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = 1.2; ctx.beginPath(); for (i = tangAt; i < n; i++) { var by = y - prof[i] * hs * 0.62; if (i === tangAt) ctx.moveTo(px(i), by); else ctx.lineTo(px(i), by); } ctx.stroke();
    ctx.strokeStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); for (i = tangAt; i < n; i++) { var by2 = y + prof[i] * hs * 0.62; if (i === tangAt) ctx.moveTo(px(i), by2); else ctx.lineTo(px(i), by2); } ctx.stroke();
    if (meta.fuller) { ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(px(tangAt) + 6, y); ctx.lineTo(px(Math.floor(tangAt + (n - tangAt) * 0.7)), y); ctx.stroke(); ctx.strokeStyle = 'rgba(255,255,255,0.4)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(px(tangAt) + 6, y - 2); ctx.lineTo(px(Math.floor(tangAt + (n - tangAt) * 0.7)), y - 2); ctx.stroke(); }
    if (meta.family === 'mace') { ctx.strokeStyle = 'rgba(0,0,0,0.45)'; ctx.lineWidth = 2; for (var fl = 0; fl < (meta.flanges || 4) * 2; fl++) { var fx = px(tangAt + Math.floor((n - tangAt) * (fl + 0.5) / ((meta.flanges || 4) * 2))); ctx.beginPath(); ctx.moveTo(fx, y - hs); ctx.lineTo(fx, y + hs); ctx.stroke(); } }
    // ⛔ found by looking: facets at 0.14/0.10 alpha as round blots made every blade look spotted. Faint, long, thin.
    for (i = 0; i < marks.length; i++) { var mk = marks[i]; if (mk.p < tangAt) continue; var mr = rng(seed + i * 17)(); ctx.fillStyle = mr < 0.5 ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.045)'; ctx.beginPath(); ctx.ellipse(px(mk.p) + (mr - 0.5) * 5, y + (mr - 0.5) * prof[mk.p] * hs * 0.8, 12, Math.max(2, prof[mk.p] * hs * 0.22), 0, 0, TAU); ctx.fill(); }
    if (meta.family === 'axe') { var ex2 = px(Math.round((meta.eye || 0.2) * (n - 1))); ctx.fillStyle = 'rgba(70,40,18,0.9)'; ctx.beginPath(); ctx.ellipse(ex2, y, 9, prof[Math.round((meta.eye || 0.2) * (n - 1))] * hs * 0.55, 0, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(30,15,5,0.6)'; ctx.stroke(); }
    for (i = 0; i < flaws.length; i++) { var p = flaws[i], cw = prof[p] * hs, cr = rng(seed + p * 97 + i); ctx.strokeStyle = 'rgba(10,6,4,0.9)'; ctx.lineWidth = 1.4; ctx.beginPath(); var cy2 = y - cw; ctx.moveTo(px(p), cy2); for (var s = 1; s <= 5; s++) { cy2 += cw * 0.36; ctx.lineTo(px(p) + (cr() - 0.5) * 7, cy2); } ctx.stroke(); }
    var sh = ctx.createLinearGradient(x, 0, x + len, 0); sh.addColorStop(0, 'rgba(255,255,255,0)'); sh.addColorStop(0.55, 'rgba(255,255,255,0.28)'); sh.addColorStop(0.62, 'rgba(255,255,255,0)'); ctx.fillStyle = sh; ctx.fillRect(x, y - hs, len, hs * 2);
    ctx.restore();
    ctx.strokeStyle = 'rgba(20,24,28,0.8)'; ctx.lineWidth = 1; ctx.beginPath(); for (i = tangAt; i < n; i++) { if (i === tangAt) ctx.moveTo(px(i), y - prof[i] * hs); else ctx.lineTo(px(i), y - prof[i] * hs); } for (i = n - 1; i >= tangAt; i--) ctx.lineTo(px(i), y + prof[i] * hs); ctx.closePath(); ctx.stroke();
  }

  //===========================================================================
  // Cards, ledger, plaques, status, verdict
  //===========================================================================

  function paper(ctx, x, y, w, h, seed) {
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; rr(ctx, x + 4, y + 6, w, h, 5); ctx.fill();
    var g = ctx.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, PAPER[0]); g.addColorStop(1, PAPER[1]); ctx.fillStyle = g; rr(ctx, x, y, w, h, 5); ctx.fill();
    var r = rng(seed); for (var i = 0; i < w * h / 70; i++) { ctx.fillStyle = r() < 0.5 ? 'rgba(140,100,50,0.08)' : 'rgba(255,255,255,0.2)'; ctx.fillRect(x + r() * w, y + r() * h, 1 + r() * 2, 1); }
    var sg = ctx.createRadialGradient(x + w * 0.8, y + h * 0.9, 2, x + w * 0.8, y + h * 0.9, 40); sg.addColorStop(0, 'rgba(60,30,10,0.18)'); sg.addColorStop(1, 'rgba(60,30,10,0)'); ctx.fillStyle = sg; ctx.fillRect(x, y, w, h);
  }
  /** The work order card: what is to be forged, in what metal, and the heats allowed. */
  function drawOrder(ctx, w, h, info) {
    ctx.clearRect(0, 0, w, h); paper(ctx, 0, 0, w - 8, h - 10, 0x0DE);
    var cw = w - 8; ctx.strokeStyle = '#7a4a1a'; ctx.lineWidth = 1.2; rr(ctx, 6, 6, cw - 12, h - 22, 3); ctx.stroke();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#7a3a14'; ctx.font = 'bold 11px ' + FACE; ctx.fillText('WORK ORDER', cw / 2, 20);
    fitText(ctx, info.title, cw - 24, 18); ctx.fillStyle = INK; ctx.fillText(info.title, cw / 2, 44);
    ctx.font = 'italic 12px ' + FACE; ctx.fillStyle = '#5a4030'; ctx.fillText(info.sub, cw / 2, 64);
    // a small drawing of the target, as a pattern on the order
    if (info.profile) { ctx.save(); var pr = info.profile, n = pr.length, sx = 20, sl = cw - 40, sy = 96, hh = 16; ctx.beginPath(); for (var i = 0; i < n; i++) { var x = sx + i / (n - 1) * sl, y = sy - pr[i] * hh; if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); } for (i = n - 1; i >= 0; i--) ctx.lineTo(sx + i / (n - 1) * sl, sy + pr[i] * hh); ctx.closePath(); ctx.fillStyle = 'rgba(60,40,20,0.18)'; ctx.fill(); ctx.strokeStyle = '#3a2410'; ctx.lineWidth = 1.2; ctx.stroke(); ctx.restore(); }
    ctx.font = '12px ' + FACE; ctx.fillStyle = INK; ctx.fillText(info.task, cw / 2, 130);
    ctx.font = 'italic 11px ' + FACE; ctx.fillStyle = '#5a4030'; ctx.fillText(info.task2 || '', cw / 2, 148);
  }
  /** The tally board: heats, blows, cracks, how close to the pattern, and the colour now. */
  function drawTally(ctx, w, h, info) {
    ctx.clearRect(0, 0, w, h); var cw = w - 8;
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; rr(ctx, 4, 6, cw, h - 10, 6); ctx.fill();
    var g = ctx.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#2a2622'); g.addColorStop(1, '#1a1714'); ctx.fillStyle = g; rr(ctx, 0, 0, cw, h - 10, 6); ctx.fill();
    ctx.strokeStyle = '#8a6a3a'; ctx.lineWidth = 1.5; rr(ctx, 5, 5, cw - 10, h - 20, 4); ctx.stroke();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#c9a06a'; ctx.font = 'bold 11px ' + FACE; ctx.fillText('THE TALLY', cw / 2, 18);
    var rows = [['Heats', info.heats + ' of ' + info.maxHeats], ['Blows', String(info.strikes)], ['Cracks', String(info.flaws)], ['To the pattern', info.shape + '%'], ['The iron is', info.colour]];
    for (var i = 0; i < rows.length; i++) { var y = 40 + i * 24; ctx.textAlign = 'left'; ctx.font = 'italic 13px ' + FACE; ctx.fillStyle = '#b8a48a'; ctx.fillText(rows[i][0], 16, y); ctx.textAlign = 'right'; ctx.font = 'bold 14px ' + FACE; ctx.fillStyle = i === 2 && info.flaws ? '#ff8a6a' : '#f1dfb4'; ctx.fillText(rows[i][1], cw - 16, y); ctx.fillStyle = 'rgba(200,160,100,0.15)'; ctx.fillRect(14, y + 11, cw - 28, 1); }
    // ⛔ found by looking: chalk tally marks for the heats sat on the last row; the Heats row already says it
  }
  /** A brass plaque button. state: 'on', 'idle', 'off'. */
  function drawPlaque(ctx, x, y, w, h, text, state) {
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; rr(ctx, x + 3, y + 4, w, h, 6); ctx.fill();
    var g = ctx.createLinearGradient(0, y, 0, y + h);
    if (state === 'off') { g.addColorStop(0, '#6a5a44'); g.addColorStop(1, '#3a2e20'); } else if (state === 'on') { g.addColorStop(0, '#fff0b0'); g.addColorStop(0.5, '#e8b850'); g.addColorStop(1, '#9a6a1e'); } else { g.addColorStop(0, '#f2d890'); g.addColorStop(0.5, '#c99a42'); g.addColorStop(1, '#8a6120'); }
    ctx.fillStyle = g; rr(ctx, x, y, w, h, 6); ctx.fill(); ctx.strokeStyle = 'rgba(60,40,10,0.75)'; ctx.lineWidth = 1; rr(ctx, x + 3, y + 3, w - 6, h - 6, 4); ctx.stroke();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; fitText(ctx, text, w - 24, 15);
    ctx.fillStyle = state === 'off' ? 'rgba(200,180,150,0.45)' : 'rgba(255,245,210,0.6)'; ctx.fillText(text, x + w / 2 + 0.8, y + h / 2 + 1.8); ctx.fillStyle = state === 'off' ? 'rgba(30,20,10,0.8)' : '#3a2408'; ctx.fillText(text, x + w / 2, y + h / 2 + 1);
    ctx.restore();
  }
  function drawStatus(ctx, W, H, text) {
    ctx.clearRect(0, 0, W, H); fitText(ctx, text, W - 10, 17, 'italic');
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = 'rgba(0,0,0,0.7)'; ctx.fillText(text, W / 2 + 1, H / 2 + 1); ctx.fillStyle = '#f1dfb4'; ctx.fillText(text, W / 2, H / 2);
  }
  /** The finished plate: the forged piece large on a cloth, its grade struck on a plaque, the verdict lines under it. */
  function drawVerdict(ctx, W, H, info) {
    ctx.clearRect(0, 0, W, H); ctx.fillStyle = 'rgba(10,6,3,0.84)'; ctx.fillRect(0, 0, W, H);
    var cloth = ctx.createLinearGradient(0, 150, 0, 420); cloth.addColorStop(0, '#3a1a14'); cloth.addColorStop(1, '#22100c'); ctx.fillStyle = 'rgba(0,0,0,0.5)'; rr(ctx, 64, 160, W - 120, 250, 10); ctx.fill(); ctx.fillStyle = cloth; rr(ctx, 58, 152, W - 120, 250, 10); ctx.fill();
    ctx.strokeStyle = 'rgba(200,150,90,0.35)'; ctx.setLineDash([4, 4]); rr(ctx, 70, 164, W - 144, 226, 8); ctx.stroke(); ctx.setLineDash([]);
    var hg = ctx.createRadialGradient(W / 2, 276, 20, W / 2, 276, 360); hg.addColorStop(0, 'rgba(255,220,160,0.18)'); hg.addColorStop(1, 'rgba(255,220,160,0)'); ctx.fillStyle = hg; ctx.fillRect(0, 0, W, H);
    drawBlade(ctx, info.profile, info.meta, info.metal, info.marks, info.flaws, 230, 276, 500, 60, info.seed);
    var good = info.grade >= 3;
    var x = W / 2 - 230, y = 438, w = 460, h = 60;
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; rr(ctx, x + 3, y + 4, w, h, 6); ctx.fill();
    var g = ctx.createLinearGradient(0, y, 0, y + h); if (good) { g.addColorStop(0, '#f6dc94'); g.addColorStop(0.5, '#c99a42'); g.addColorStop(1, '#8a6120'); } else { g.addColorStop(0, '#d8cdbd'); g.addColorStop(0.5, '#9a8e7e'); g.addColorStop(1, '#5e5448'); }
    ctx.fillStyle = g; rr(ctx, x, y, w, h, 6); ctx.fill(); ctx.strokeStyle = 'rgba(60,40,10,0.7)'; rr(ctx, x + 3, y + 3, w - 6, h - 6, 4); ctx.stroke();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; fitText(ctx, info.title, w - 24, 20); ctx.fillStyle = 'rgba(255,245,210,0.6)'; ctx.fillText(info.title, W / 2, y + 20); ctx.fillStyle = '#3a2408'; ctx.fillText(info.title, W / 2, y + 19);
    fitText(ctx, info.sub, w - 24, 13, 'italic'); ctx.fillStyle = '#4a3010'; ctx.fillText(info.sub, W / 2, y + 43);
    ctx.font = 'italic 14px ' + FACE; ctx.fillStyle = '#e8d4a8'; ctx.fillText(info.foot, W / 2, 530);
  }

  return {
    VERSION: '1.0.0', FACE: FACE, INK: INK, RAMP: RAMP, METAL: METAL, ANV: ANV, BAR: BAR,
    rng: rng, heatRgb: heatRgb, heatTint: heatTint, drawSmithy: drawSmithy, drawAnvil: drawAnvil, drawTemperChart: drawTemperChart, drawPointer: drawPointer,
    barPath: barPath, drawWork: drawWork, drawGlow: drawGlow, drawTarget: drawTarget, drawHammer: drawHammer, drawSpark: drawSpark, drawPuff: drawPuff,
    drawBlade: drawBlade, drawOrder: drawOrder, drawTally: drawTally, drawPlaque: drawPlaque, drawStatus: drawStatus, drawVerdict: drawVerdict,
  };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = AnvilDraw;
