//=============================================================================
// Anvil.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Anvil - a hot-metal forging minigame: hammer a glowing
 * bar to a pattern generated from your own weapon, then quench it. Place BELOW
 * AnvilCore and AnvilDraw.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * Anvil
 * ============================================================================
 *
 * A forging minigame for your game. The player works a glowing bar on the
 * anvil toward a pattern chalked on its face, reading the heat by the colour
 * of the metal: blows move hot metal and crack cold metal, the hearth
 * reheats it a limited number of times, and the quench fixes the result -
 * best at cherry red. The forged piece is then shown finished, exactly as
 * the player shaped it, and its quality is handed back to your events.
 *
 * THE PATTERN IS YOUR WEAPON. Name a weapon from your database and the
 * pattern is generated from it: the weapon type picks the family (sword,
 * dagger, axe, spear, mace, claw), the weapon's name picks the metal, and
 * its id, name and attack pick its proportions. Every weapon in your game
 * forges differently.
 *
 * IT PLUGS INTO YOUR CRAFTING. Anvil does not replace a crafting system; it
 * is the step where the player makes the thing. Open it from the event that
 * crafts (or after your crafting plugin's craft), read the quality variable,
 * and decide what that means in your game. It can also give the weapon
 * itself when the quality clears a bar you set.
 *
 * ----------------------------------------------------------------------------
 * INSTALLING
 * ----------------------------------------------------------------------------
 * Plugin Manager order, top to bottom:
 *
 *     AnvilCore.js     (the patterns, the metal and the score)
 *     AnvilDraw.js     (the drawing)
 *     Anvil.js         (this file: parameters, the command, the scene)
 *
 * ----------------------------------------------------------------------------
 * USING IT
 * ----------------------------------------------------------------------------
 * Add the plugin command "Open Anvil" to an event. Choose the weapon (or 0
 * for a generated blade), the difficulty, and the variables and switch to
 * set. The event waits while the player works.
 *
 *   Quality variable      0 to 100
 *   Grade variable        1 Crude, 2 Serviceable, 3 Fine, 4 Masterwork
 *                         (0 if the player left without quenching)
 *   Switch                on when the quality reaches "Quality for the switch"
 *   Give the weapon       adds the weapon to the party when the quality
 *                         reaches the same bar
 *
 * ----------------------------------------------------------------------------
 * CONTROLS
 * ----------------------------------------------------------------------------
 * Left and right move the hammer along the bar. OK strikes. Shift puts the
 * bar back in the hearth. Q quenches. Escape leaves without quenching.
 * Mouse and touch: click the bar to strike there; click the plaques;
 * right-click leaves.
 *
 * ----------------------------------------------------------------------------
 * COMPATIBILITY
 * ----------------------------------------------------------------------------
 * Anvil adds its own scene and replaces nothing. It extends one engine
 * method (Game_System.initialize) to create its save record, calling the
 * original first.
 *
 * ============================================================================
 * TERMS OF USE
 * ============================================================================
 * Commercial and non-commercial use permitted in RPG Maker projects, credit
 * appreciated but not required. Do not redistribute the source as an asset
 * pack. Every line of this plugin was written with AI assistance.
 *
 * ============================================================================
 *
 * @param strikeSe
 * @text Sound: a hammer blow
 * @type file
 * @dir audio/se
 * @default Hammer
 *
 * @param crackSe
 * @text Sound: a blow on cold metal
 * @type file
 * @dir audio/se
 * @default Break
 *
 * @param fireSe
 * @text Sound: into the hearth
 * @type file
 * @dir audio/se
 * @default Fire1
 *
 * @param quenchSe
 * @text Sound: the quench
 * @type file
 * @dir audio/se
 * @default Water1
 *
 * @param finishSe
 * @text Sound: the piece finished
 * @type file
 * @dir audio/se
 * @default Item3
 *
 * @command open
 * @text Open Anvil
 * @desc Open the forge. The event waits until the piece is quenched or the player leaves.
 *
 * @arg weaponId
 * @text Weapon to forge
 * @type weapon
 * @desc The pattern is generated from this weapon. None = a generated blade.
 * @default 0
 *
 * @arg family
 * @text Family (override)
 * @type select
 * @option auto
 * @option sword
 * @option dagger
 * @option axe
 * @option spear
 * @option mace
 * @option claw
 * @default auto
 *
 * @arg difficulty
 * @text Difficulty
 * @type select
 * @option easy
 * @option normal
 * @option hard
 * @default normal
 *
 * @arg variableId
 * @text Variable: quality (0-100)
 * @type variable
 * @default 0
 *
 * @arg gradeVariableId
 * @text Variable: grade (1-4)
 * @type variable
 * @default 0
 *
 * @arg switchId
 * @text Switch: on at the bar
 * @type switch
 * @default 0
 *
 * @arg minQuality
 * @text Quality for the switch
 * @type number
 * @min 0
 * @max 100
 * @default 65
 *
 * @arg give
 * @text Give the weapon at the bar
 * @type boolean
 * @default false
 *
 * @arg title
 * @text Title
 * @desc Shown on the work order. Blank = the weapon's name.
 * @default
 *
 * @arg seed
 * @text Seed (optional)
 * @desc Blank = keyed to this map, event and weapon.
 * @default
 */

var Anvil = Anvil || {};

(function (M) {
  'use strict';
  var NAME = 'Anvil', SCHEMA = 1;
  var raw = (typeof PluginManager !== 'undefined') ? PluginManager.parameters(NAME) : {};
  function num(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; var n = Number(v); return isFinite(n) ? n : d; }
  function str(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; return String(v).trim(); }
  M.params = { strikeSe: str(raw.strikeSe, 'Hammer'), crackSe: str(raw.crackSe, 'Break'), fireSe: str(raw.fireSe, 'Fire1'), quenchSe: str(raw.quenchSe, 'Water1'), finishSe: str(raw.finishSe, 'Item3') };

  var _deps = null;
  function deps() {
    if (_deps) return _deps;
    var core = (typeof AnvilCore !== 'undefined') ? AnvilCore : null, draw = (typeof AnvilDraw !== 'undefined') ? AnvilDraw : null;
    if (!core || !draw) { if (!deps._w) { deps._w = true; console.error('Anvil: AnvilCore.js and AnvilDraw.js must both be installed and listed ABOVE Anvil.js.'); } return null; }
    _deps = { core: core, draw: draw }; return _deps;
  }
  M.deps = deps;

  function fresh() { return { v: SCHEMA, forged: {} }; }
  function store() {
    if (typeof $gameSystem === 'undefined' || !$gameSystem) return fresh();
    var s = $gameSystem._csafAnvil; if (!s || s.v == null) { s = fresh(); $gameSystem._csafAnvil = s; }
    if (!s.forged) s.forged = {}; return s;
  }
  M.store = store;
  M.keyFor = function (mapId, eventId, weaponId) { return 'm' + Number(mapId) + 'e' + Number(eventId) + 'w' + Number(weaponId); };
  /** @returns {{best:number, grade:number, times:number}} what has been forged at this key */
  M.record = function (key) { var r = store().forged[String(key)]; if (!r) { r = { best: 0, grade: 0, times: 0 }; store().forged[String(key)] = r; } return r; };
  /** How many pieces the player has finished at any anvil. */
  M.forgedCount = function () { var c = store().forged, k = 0; for (var id in c) if (c[id]) k += c[id].times || 0; return k; };
  /** The result of the last piece finished: {quality, grade, gradeName, ...} or null. */
  M.lastResult = null;

  var _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () { _Game_System_initialize.call(this); this._csafAnvil = fresh(); };

  /** Read a weapon from the database: name, type name, attack, description. */
  M.weaponSpec = function (id) {
    var w = (typeof $dataWeapons !== 'undefined' && $dataWeapons) ? $dataWeapons[Number(id)] : null;
    if (!w) return null;
    var types = (typeof $dataSystem !== 'undefined' && $dataSystem && $dataSystem.weaponTypes) || [];
    return { id: w.id, name: w.name, typeName: types[w.wtypeId] || '', atk: (w.params && w.params[2]) || 10, description: w.description || '' };
  };

  /** Build a request (and its target) from command arguments. Returns null if the sibling plugins are missing. */
  M.request = function (args, key, mapId, eventId) {
    var d = deps(); if (!d) return null; args = args || {};
    var wid = Math.max(0, Math.floor(num(args.weaponId, 0))), spec = wid ? M.weaponSpec(wid) : null;
    var seedText = str(args.seed, ''), seed = seedText === '' ? d.core.hashString(key + '|' + (spec ? spec.name : '')) : (/^\d+$/.test(seedText) ? (Number(seedText) >>> 0) : d.core.hashString(seedText));
    var famArg = str(args.family, 'auto'), family = d.core.FAMILIES.indexOf(famArg) >= 0 ? famArg : (spec ? d.core.familyOf(spec.typeName, spec.name) : 'sword');
    var metal = spec ? d.core.metalOf(spec.name, spec.description) : 'steel';
    var t = d.core.target({ seed: seed, family: family, atk: spec ? spec.atk : 20, metal: metal, name: spec ? spec.name : '' });
    var diff = str(args.difficulty, 'normal'); if (!d.core.DIFFS[diff]) diff = 'normal';
    var give = String(args.give) === 'true';
    return { key: key, target: t, difficulty: diff, weaponId: spec ? wid : 0, title: str(args.title, spec ? spec.name : 'A Plain Blade'),
      variableId: Math.max(0, Math.floor(num(args.variableId, 0))), gradeVariableId: Math.max(0, Math.floor(num(args.gradeVariableId, 0))),
      switchId: Math.max(0, Math.floor(num(args.switchId, 0))), minQuality: Math.max(0, Math.min(100, Math.floor(num(args.minQuality, 65)))), give: give, mapId: mapId, eventId: eventId };
  };

  M.open = function (req) { if (!req) return false; SceneManager.push(Scene_Anvil); SceneManager.prepareNextScene(req); return true; };

  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
    PluginManager.registerCommand(NAME, 'open', function (args) {
      var mapId = this._mapId || ($gameMap ? $gameMap.mapId() : 0), eventId = this.eventId ? this.eventId() : 0;
      var seedText = str(args.seed, ''), key = seedText === '' ? M.keyFor(mapId, eventId, num(args.weaponId, 0)) : 's' + seedText;
      M.open(M.request(args, key, mapId, eventId));
    });
  }
  M.VERSION = '1.0.0'; M.SCHEMA = SCHEMA;
}(Anvil));

//=============================================================================
// Scene_Anvil
//=============================================================================

function Scene_Anvil() { this.initialize.apply(this, arguments); }
Scene_Anvil.prototype = Object.create(Scene_Base.prototype);
Scene_Anvil.prototype.constructor = Scene_Anvil;
Scene_Anvil.ORDER = { x: 12, y: 14, w: 226, h: 170 };
Scene_Anvil.TALLY = { x: 580, y: 14, w: 226, h: 170 };
Scene_Anvil.CHART = { x: 250, y: 18, w: 316, h: 44 };
Scene_Anvil.STATUS = { x: 160, y: 470, w: 496, h: 40 };
Scene_Anvil.PLAQUES = { x: 200, y: 528, w: 130, h: 32, gap: 142 };
Scene_Anvil.REGION = { x: 180, y: 244, w: 512, h: 170 };   // the bar's bitmaps cover this screen rectangle
Scene_Anvil.SPARKS = 36;
Scene_Anvil.PUFFS = 14;

Scene_Anvil.prototype.prepare = function (req) { this._req = req; };

Scene_Anvil.prototype.create = function () {
  Scene_Base.prototype.create.call(this);
  var d = Anvil.deps(); this._d = d; this._t = this._req.target;
  this._f = d.core.newForge(this._t, this._req.difficulty);
  this._pos = Math.floor(d.core.N / 2); this._mode = 'play'; this._anim = 0; this._statusText = ''; this._plaqueKey = ''; this._tallyKey = ''; this._lastTint = -1;
  // heat -> tint table, built once so the per-frame colour is a lookup (zero allocation in the loop)
  this._tints = []; for (var k = 0; k <= 100; k++) this._tints.push(d.draw.heatTint(k / 100));
  this.createBoard(); this.createBar(); this.createFx(); this.createUi();
  this.refreshWork(); this.refreshTally(); this.refreshPlaques(); this.placeHammer(); this.applyHeat();
  this.setStatus('Strike while it glows. Shift reheats, Q quenches.');
};
Scene_Anvil.prototype.start = function () { Scene_Base.prototype.start.call(this); this.startFadeIn(this.fadeSpeed(), false); };

Scene_Anvil.prototype.createBoard = function () {
  var D = this._d.draw, C = this._d.core, W = Graphics.width, H = Graphics.height, CH = Scene_Anvil.CHART;
  var bmp = new Bitmap(W, H), ctx = bmp.context;
  D.drawSmithy(ctx, W, H); D.drawAnvil(ctx); D.drawTarget(ctx, this._t.profile);
  this._chart = D.drawTemperChart(ctx, CH.x, CH.y, CH.w, CH.h, C.BANDS, C.QUENCH);
  bmp._baseTexture.update(); this.addChild(new Sprite(bmp));
};

Scene_Anvil.prototype.createBar = function () {
  var R = Scene_Anvil.REGION;
  // the bar's container pivots on the bar's centre, so the quench can lower it into the trough (move + shrink)
  var B = this._d.draw.BAR; this._home = { x: B.x0 + B.len / 2, y: B.cy };
  this._barBox = new Sprite(); this._barBox.pivot.x = this._home.x; this._barBox.pivot.y = this._home.y; this._barBox.x = this._home.x; this._barBox.y = this._home.y; this.addChild(this._barBox);
  this._glow = new Sprite(new Bitmap(R.w, R.h)); this._glow.x = R.x; this._glow.y = R.y; this._glow.blendMode = 1; this._barBox.addChild(this._glow);   // PIXI.BLEND_MODES.ADD
  this._work = new Sprite(new Bitmap(R.w, R.h)); this._work.x = R.x; this._work.y = R.y; this._barBox.addChild(this._work);
  var hb = new Bitmap(140, 150); this._d.draw.drawHammer(hb.context, 140, 150); hb._baseTexture.update();
  this._hammer = new Sprite(hb); this._hammer.anchor.x = 0.5; this._hammer.anchor.y = 0.42; this.addChild(this._hammer);
};

Scene_Anvil.prototype.createFx = function () {
  var sb = new Bitmap(12, 4); this._d.draw.drawSpark(sb.context); sb._baseTexture.update();
  var pb = new Bitmap(48, 48); this._d.draw.drawPuff(pb.context); pb._baseTexture.update();
  this._sparks = []; this._puffs = []; var i, s;
  for (i = 0; i < Scene_Anvil.SPARKS; i++) { s = new Sprite(sb); s.anchor.x = 1; s.anchor.y = 0.5; s.blendMode = 1; s.visible = false; s._vx = 0; s._vy = 0; s._life = 0; this.addChild(s); this._sparks.push(s); }
  for (i = 0; i < Scene_Anvil.PUFFS; i++) { s = new Sprite(pb); s.anchor.x = 0.5; s.anchor.y = 0.5; s.visible = false; s._vx = 0; s._vy = 0; s._life = 0; this.addChild(s); this._puffs.push(s); }
  this._fxSeed = 1;
};

Scene_Anvil.prototype.createUi = function () {
  var O = Scene_Anvil.ORDER, T = Scene_Anvil.TALLY, S = Scene_Anvil.STATUS, P = Scene_Anvil.PLAQUES, D = this._d.draw, t = this._t, f = this._f;
  this._order = new Sprite(new Bitmap(O.w, O.h)); this._order.x = O.x; this._order.y = O.y; this.addChild(this._order);
  var fam = t.family, art = /^[aeiou]/.test(fam) ? 'an ' : 'a ';
  D.drawOrder(this._order.bitmap.context, O.w, O.h, { title: this._req.title, sub: art + fam + ', in ' + t.metal, profile: t.profile, task: 'Work the bar to the chalked pattern.', task2: f.maxHeats + ' heats allowed · quench at cherry red' });
  this._order.bitmap._baseTexture.update();
  this._tally = new Sprite(new Bitmap(T.w, T.h)); this._tally.x = T.x; this._tally.y = T.y; this.addChild(this._tally);
  var pb = new Bitmap(20, 22); D.drawPointer(pb.context); pb._baseTexture.update(); this._pointer = new Sprite(pb); this._pointer.y = this._chart.sy - 20; this.addChild(this._pointer);
  this._status = new Sprite(new Bitmap(S.w, S.h)); this._status.x = S.x; this._status.y = S.y; this.addChild(this._status);
  this._plaques = new Sprite(new Bitmap(P.gap * 2 + P.w + 16, P.h + 14)); this._plaques.x = P.x - 6; this._plaques.y = P.y - 6; this.addChild(this._plaques);
  this._verdict = new Sprite(new Bitmap(Graphics.width, Graphics.height)); this._verdict.visible = false; this.addChild(this._verdict);
};

Scene_Anvil.prototype.playSe = function (n) { if (n && typeof AudioManager !== 'undefined') AudioManager.playSe({ name: n, volume: 80, pitch: 100, pan: 0 }); };

//---------------------------------------------------------------------------- redraws (only on change)

/** Redraw the bar and its halo for the current shape (once per blow, never per frame). */
Scene_Anvil.prototype.refreshWork = function () {
  var R = Scene_Anvil.REGION, D = this._d.draw, f = this._f;
  var wc = this._work.bitmap.context; wc.clearRect(0, 0, R.w, R.h); wc.save(); wc.translate(-R.x, -R.y); D.drawWork(wc, f.work, f.marks, f.flaws, this._t.seed, f.strikes); wc.restore(); this._work.bitmap._baseTexture.update();
  var gc = this._glow.bitmap.context; gc.clearRect(0, 0, R.w, R.h); gc.save(); gc.translate(-R.x, -R.y); D.drawGlow(gc, f.work); gc.restore(); this._glow.bitmap._baseTexture.update();
};
Scene_Anvil.prototype.refreshTally = function () {
  var f = this._f, C = this._d.core, colour = C.heatName(f.heat), shape = Math.round(C.shape(this._t, f) * 100), key = f.heats + '|' + f.strikes + '|' + f.flaws.length + '|' + shape + '|' + colour;
  if (key === this._tallyKey) return; this._tallyKey = key;
  var T = Scene_Anvil.TALLY; this._d.draw.drawTally(this._tally.bitmap.context, T.w, T.h, { heats: f.heats, maxHeats: f.maxHeats, strikes: f.strikes, flaws: f.flaws.length, shape: shape, colour: colour }); this._tally.bitmap._baseTexture.update();
};
Scene_Anvil.prototype.plaqueStates = function () {
  var f = this._f, play = this._mode === 'play';
  return [play && f.heat >= 0 ? 'idle' : 'off', play && f.heats < f.maxHeats ? 'idle' : 'off', play ? 'idle' : 'off'];
};
Scene_Anvil.prototype.refreshPlaques = function () {
  var st = this.plaqueStates(), key = st.join('|') + '|' + this._hover; if (key === this._plaqueKey) return; this._plaqueKey = key;
  var P = Scene_Anvil.PLAQUES, b = this._plaques.bitmap, ctx = b.context, labels = ['Strike', 'Reheat', 'Quench'];
  ctx.clearRect(0, 0, b.width, b.height);
  for (var k = 0; k < 3; k++) this._d.draw.drawPlaque(ctx, 6 + k * P.gap, 6, P.w, P.h, labels[k], st[k] === 'idle' && this._hover === k ? 'on' : st[k]);
  b._baseTexture.update();
};
Scene_Anvil.prototype.setStatus = function (t) { if (t === this._statusText) return; this._statusText = t; var S = Scene_Anvil.STATUS; this._d.draw.drawStatus(this._status.bitmap.context, S.w, S.h, t); this._status.bitmap._baseTexture.update(); };

/** Where the hammer hangs over the bar, and the colour of the heat. Scalars only: these run every frame. */
Scene_Anvil.prototype.barX = function (p) { var B = this._d.draw.BAR; return B.x0 + (p / (this._d.core.N - 1)) * B.len; };
Scene_Anvil.prototype.placeHammer = function () { this._hammer.x = this.barX(this._pos); this._hammer.y = this._d.draw.BAR.cy - 30; };
Scene_Anvil.prototype.applyHeat = function () {
  var h = this._f.heat, k = Math.max(0, Math.min(100, Math.round(h * 100)));
  if (k !== this._lastTint) { this._lastTint = k; this._work.tint = this._tints[k]; this._glow.tint = this._tints[k]; }
  this._glow.alpha = h < 0.22 ? 0 : Math.min(0.95, (h - 0.22) * 1.35);
  this._pointer.x = this._chart.sx + h * this._chart.sw - 10;
};

//---------------------------------------------------------------------------- per frame

Scene_Anvil.prototype.update = function () {
  Scene_Base.prototype.update.call(this);
  this.updateFx();
  var m = this._mode;
  if (m === 'play' || m === 'strike') { this._d.core.cool(this._f, 1); this.applyHeat(); if ((Graphics.frameCount & 7) === 0) this.refreshTally(); }
  if (m === 'play') this.updateInput();
  else if (m === 'strike') this.updateStrike();
  else if (m === 'reheat') this.updateReheat();
  else if (m === 'quench') this.updateQuench();
  else if (m === 'reveal') { this._anim++; this._verdict.opacity = Math.min(255, this._anim * 11); if (this._anim >= 24) this._mode = 'done'; }
  else if (m === 'done') { if (Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered() || TouchInput.isCancelled()) this.leave(); }
  else if (m === 'leaving' && !this.isBusy()) { this._mode = 'gone'; this.popScene(); }
};

Scene_Anvil.prototype.updateInput = function () {
  var N = this._d.core.N, P = Scene_Anvil.PLAQUES, B = this._d.draw.BAR;
  if (Input.isRepeated('left')) { this._pos = Math.max(0, this._pos - 1); this.placeHammer(); }
  else if (Input.isRepeated('right')) { this._pos = Math.min(N - 1, this._pos + 1); this.placeHammer(); }
  if (Input.isTriggered('ok')) { this.beginStrike(); return; }
  if (Input.isTriggered('shift')) { this.beginReheat(); return; }
  if (Input.isTriggered('pageup')) { this.beginQuench(); return; }   // the Q key
  if (Input.isTriggered('cancel') || TouchInput.isCancelled()) { this.leave(); return; }
  var tx = TouchInput.x, ty = TouchInput.y, hover = -1;
  if (ty >= P.y && ty < P.y + P.h) for (var k = 0; k < 3; k++) if (tx >= P.x + k * P.gap && tx < P.x + k * P.gap + P.w) hover = k;
  if (hover !== this._hover) { this._hover = hover; this.refreshPlaques(); }
  if (TouchInput.isTriggered()) {
    if (hover === 0) this.beginStrike(); else if (hover === 1) this.beginReheat(); else if (hover === 2) this.beginQuench();
    else if (tx >= B.x0 - 10 && tx <= B.x0 + B.len + 10 && Math.abs(ty - B.cy) <= B.hs + 16) { this._pos = Math.max(0, Math.min(N - 1, Math.round((tx - B.x0) / B.len * (N - 1)))); this.placeHammer(); this.beginStrike(); }
  }
};

Scene_Anvil.prototype.beginStrike = function () { this._mode = 'strike'; this._anim = 0; this.refreshPlaques(); };
/** The blow: the hammer rises (frames 0-5) and falls (6-9); the metal moves on the frame it lands. */
Scene_Anvil.prototype.updateStrike = function () {
  var a = ++this._anim;
  this._hammer.scale.x = this._hammer.scale.y = a <= 5 ? 1 + a * 0.05 : Math.max(1, 1.25 - (a - 5) * 0.08);
  if (a === 8) {
    var out = this._d.core.strike(this._t, this._f, this._pos);
    this.refreshWork(); this.refreshTally(); this.sparkBurst(this.barX(this._pos), this._d.draw.BAR.cy, out && out.cracked ? 6 : 10 + Math.round(this._f.heat * 18));
    this.playSe(out && out.cracked ? Anvil.params.crackSe : Anvil.params.strikeSe);
    if (out && out.cracked) this.setStatus('It cracked: too cold to work. Reheat it.');
    else if (this._f.heat < 0.3) this.setStatus('The colour is going. Reheat soon.');
    else this.setStatus('Strike while it glows. Shift reheats, Q quenches.');
  }
  if (a >= 10) { this._hammer.scale.x = this._hammer.scale.y = 1; this._mode = 'play'; this.refreshPlaques(); }
};

/** Back into the hearth: the bar slides left into the fire, takes the heat, and slides back. */
Scene_Anvil.prototype.beginReheat = function () {
  var f = this._f; if (f.heats >= f.maxHeats) { this.setStatus('No heats left. Quench it now.'); return; }
  this._mode = 'reheat'; this._anim = 0; this.playSe(Anvil.params.fireSe); this.setStatus('Into the fire...'); this.refreshPlaques();
};
Scene_Anvil.prototype.updateReheat = function () {
  var a = ++this._anim;
  this._barBox.x = this._home.x + (a <= 18 ? -a * 22 : (a <= 42 ? -396 : -396 + (a - 42) * 22));
  this._hammer.visible = false;
  if (a === 30) { this._d.core.reheat(this._f); this.applyHeat(); this.refreshTally(); }
  if (a >= 60) { this._barBox.x = this._home.x; this._hammer.visible = true; this._mode = 'play'; this.refreshPlaques(); this.setStatus('Back to white heat. Strike while it glows.'); }
};

/** The quench: steam rises as the bar goes into the trough, and the piece is judged at the colour it had. */
Scene_Anvil.prototype.beginQuench = function () {
  this._qv = this._d.core.quench(this._f); this._mode = 'quench'; this._anim = 0; this.playSe(Anvil.params.quenchSe); this.refreshPlaques();
  this.setStatus('Quenched at ' + this._qv.colour + '.'); this._hammer.visible = false;
};
Scene_Anvil.prototype.updateQuench = function () {
  // ⛔ found by looking (2026-09-27): sliding the bar down 150 px laid it across the floor like a red strip, far from
  // the steam. It now travels to the trough and shrinks as it is lowered in, and the steam rises where it goes under.
  var a = ++this._anim, k = Math.min(1, a / 18), TX = 720, TY = 520;
  this._barBox.x = this._home.x + (TX - this._home.x) * k; this._barBox.y = this._home.y + (TY - this._home.y) * k;
  this._barBox.scale.x = this._barBox.scale.y = 1 - 0.72 * k; this._barBox.alpha = a <= 18 ? 1 : Math.max(0, 1 - (a - 18) / 10);
  if (a >= 14 && a <= 36 && (a & 1) === 0) this.puff(TX - 50 + (a * 13) % 100, TY - 10);
  if (a >= 44) this.finish();
};

//---------------------------------------------------------------------------- sparks and steam (pooled, no allocation)

Scene_Anvil.prototype.nextRand = function () { this._fxSeed = (Math.imul(this._fxSeed, 1103515245) + 12345) >>> 0; return (this._fxSeed >>> 8) / 16777216; };
Scene_Anvil.prototype.sparkBurst = function (x, y, n) {
  var tint = this._tints[Math.min(100, Math.round(Math.max(0.6, this._f.heat) * 100))];
  for (var i = 0, used = 0; i < this._sparks.length && used < n; i++) {
    var s = this._sparks[i]; if (s._life > 0) continue;
    var ang = this.nextRand() * Math.PI * 2, sp = 3 + this.nextRand() * 7;
    s.x = x; s.y = y; s._vx = Math.cos(ang) * sp; s._vy = Math.sin(ang) * sp - 2; s._life = 14 + Math.floor(this.nextRand() * 14); s.visible = true; s.tint = tint; s.rotation = ang; used++;
  }
};
Scene_Anvil.prototype.puff = function (x, y) {
  for (var i = 0; i < this._puffs.length; i++) { var p = this._puffs[i]; if (p._life > 0) continue; p.x = x; p.y = y; p._vx = (this.nextRand() - 0.5) * 1.6; p._vy = -1.4 - this.nextRand() * 1.6; p._life = 40; p.visible = true; p.scale.x = p.scale.y = 0.8; p.alpha = 0.9; return; }
};
Scene_Anvil.prototype.updateFx = function () {
  var i, s;
  for (i = 0; i < this._sparks.length; i++) { s = this._sparks[i]; if (s._life <= 0) continue; s._life--; s.x += s._vx; s.y += s._vy; s._vy += 0.35; s._vx *= 0.96; s.rotation = Math.atan2(s._vy, s._vx); s.alpha = Math.min(1, s._life / 8); if (s._life <= 0) s.visible = false; }
  for (i = 0; i < this._puffs.length; i++) { s = this._puffs[i]; if (s._life <= 0) continue; s._life--; s.x += s._vx; s.y += s._vy; s.scale.x = s.scale.y = s.scale.x + 0.035; s.alpha = s._life / 44; if (s._life <= 0) s.visible = false; }
};

//---------------------------------------------------------------------------- the verdict

Scene_Anvil.prototype.finish = function () {
  var req = this._req, sc = this._d.core.score(this._t, this._f), rec = Anvil.record(req.key), q = this._qv;
  rec.times = (rec.times || 0) + 1; if (sc.quality > rec.best) { rec.best = sc.quality; rec.grade = sc.grade; }
  Anvil.lastResult = sc; this._score = sc;
  var cleared = sc.quality >= req.minQuality, given = false;
  if (req.variableId > 0 && typeof $gameVariables !== 'undefined') $gameVariables.setValue(req.variableId, sc.quality);
  if (req.gradeVariableId > 0 && typeof $gameVariables !== 'undefined') $gameVariables.setValue(req.gradeVariableId, sc.grade);
  if (req.switchId > 0 && typeof $gameSwitches !== 'undefined') $gameSwitches.setValue(req.switchId, cleared);
  if (cleared && req.give && req.weaponId > 0 && typeof $gameParty !== 'undefined' && typeof $dataWeapons !== 'undefined' && $dataWeapons[req.weaponId]) { $gameParty.gainItem($dataWeapons[req.weaponId], 1); given = true; }
  var foot = given ? 'The ' + req.title + ' is yours.' : (req.give && req.weaponId > 0 ? 'Not good enough to keep: the bar is ' + req.minQuality + '.' : 'Press OK to leave the forge.');
  var info = { profile: this._f.work, meta: this._t.meta, metal: this._t.metal, marks: this._f.marks, flaws: this._f.flaws, seed: this._t.seed, grade: sc.grade,
    title: sc.gradeName + ' - quality ' + sc.quality, sub: 'Quenched at ' + q.colour + ' (' + q.note + '). ' + sc.heats + (sc.heats === 1 ? ' heat, ' : ' heats, ') + sc.strikes + ' blows, ' + sc.shape + '% to the pattern' + (sc.flaws ? ', ' + sc.flaws + (sc.flaws === 1 ? ' crack.' : ' cracks.') : '.'), foot: foot };
  var b = this._verdict.bitmap; this._d.draw.drawVerdict(b.context, b.width, b.height, info); b._baseTexture.update();
  this._verdictInfo = info; this._given = given;
  this._verdict.opacity = 0; this._verdict.visible = true; this._anim = 0; this._mode = 'reveal'; this.playSe(Anvil.params.finishSe);
  this.setStatus('');
};

Scene_Anvil.prototype.leave = function () {
  if (this._mode === 'leaving' || this._mode === 'gone') return;
  if (!this._f.quenched && this._req.gradeVariableId > 0 && typeof $gameVariables !== 'undefined') $gameVariables.setValue(this._req.gradeVariableId, 0);
  if (!this._f.quenched && this._req.variableId > 0 && typeof $gameVariables !== 'undefined') $gameVariables.setValue(this._req.variableId, 0);
  this._mode = 'leaving'; this.startFadeOut(this.fadeSpeed(), false);
};
