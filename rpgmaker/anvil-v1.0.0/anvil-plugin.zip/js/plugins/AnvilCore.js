//=============================================================================
// AnvilCore.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Anvil core - forging targets generated from your
 * weapons, the hot-metal model (shaping, cooling, cracks, quench) and the score.
 * Place ABOVE AnvilDraw and Anvil.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The generator, the forging model and the scoring for Anvil. No parameters
 * or commands of its own; Anvil.js is the file you configure. Must be
 * installed and listed above Anvil.js.
 *
 * Pure logic: nothing here touches the screen and nothing uses Math.random.
 *
 * THE TARGET. Every weapon becomes a silhouette to forge toward, generated
 * from its own database entry: the weapon type picks the family (sword,
 * dagger, axe, spear, mace, claw) and the weapon's id, name and attack pick
 * its proportions (blade width, taper, point, ricasso, tang, beard, flanges).
 *
 * THE METAL. The bar is shaped toward the target by each hammer blow, more
 * when it is hotter. It cools while you work; a blow on metal that has gone
 * too cold cracks it. The hearth reheats it, a limited number of times.
 * Quenching fixes the result, and the colour at that moment decides it.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var AnvilCore = (function () {
  'use strict';

  function hashString(s) { var h = 0x811c9dc5; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h >>> 0; }
  function rng(seed) {
    var a = seed >>> 0;
    return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
  function pick(r, a) { return a[Math.floor(r() * a.length) % a.length]; }

  var N = 64;                       // samples along the bar, tang end (0) to tip (N - 1)
  var STOCK = 0.34;                 // the half-width of the bar before any blow
  var COLD = 0.22;                  // below this heat a blow cracks the metal instead of moving it
  var FAMILIES = ['sword', 'dagger', 'axe', 'spear', 'mace', 'claw'];
  // tuned 2026-09-27 against _scripts/balance_probe.js (a skilled smith that keeps its last heat for the quench)
  var DIFFS = { easy: { heats: 6, cool: 1 / 900 }, normal: { heats: 5, cool: 1 / 720 }, hard: { heats: 4, cool: 1 / 560 } };
  var METALS = ['steel', 'iron', 'bronze', 'mithril', 'blacksteel'];

  /**
   * The family a weapon forges as, read from its weapon-type name first and its own name second (the buyer's
   * database, never a fixed id: a project may rename or reorder its types).
   * @param {string} typeName @param {string} name @returns {string}
   */
  function familyOf(typeName, name) {
    var s = String(typeName || '') + ' ' + String(name || '');
    if (/dagger|knife|dirk|stiletto|kunai|tanto/i.test(s)) return 'dagger';
    if (/axe|hatchet|halberd|cleaver/i.test(s)) return 'axe';
    if (/spear|lance|pike|glaive|trident|javelin|naginata/i.test(s)) return 'spear';
    if (/mace|flail|hammer|club|maul|morning ?star|staff|rod|wand|sceptre|scepter/i.test(s)) return 'mace';   // a rod with a worked head
    if (/claw|talon|katar|glove|knuckle/i.test(s)) return 'claw';
    return 'sword';
  }
  /** The metal a weapon is worked in, read from its name and description. */
  function metalOf(name, desc) {
    var s = String(name || '') + ' ' + String(desc || '');
    if (/mithril|silver|elven|moon/i.test(s)) return 'mithril';
    if (/bronze|brass|copper/i.test(s)) return 'bronze';
    if (/dark|black|obsidian|shadow|demon/i.test(s)) return 'blacksteel';
    if (/iron|rusty|crude|old/i.test(s)) return 'iron';
    return 'steel';
  }

  /**
   * A forging target: the half-width profile the blade should take (N samples, 0..1) and what the drawing needs
   * to know (where the tang ends, the point style, the fuller). Deterministic from the spec.
   * @param {{seed:number, family?:string, atk?:number, metal?:string, name?:string}} spec
   */
  function target(spec) {
    spec = spec || {};
    var seed = Number(spec.seed) >>> 0, r = rng(seed ^ 0xA7F1), fam = FAMILIES.indexOf(spec.family) >= 0 ? spec.family : pick(r, FAMILIES);
    var atk = clamp(Number(spec.atk) || 10, 1, 200), heft = clamp(atk / 60, 0.1, 1);   // a stronger weapon is broader
    var w = [], i, meta = { family: fam, point: 'spear', fuller: false, beard: 0, flanges: 0, tang: 0.18 };
    var tang = 0.14 + r() * 0.08, tangW = 0.14 + r() * 0.06;
    if (fam === 'sword' || fam === 'dagger' || fam === 'claw') {
      if (fam === 'dagger') tang = 0.26 + r() * 0.08; if (fam === 'claw') tang = 0.34 + r() * 0.06;
      var base = 0.48 + heft * 0.22 + r() * 0.18 - (fam === 'claw' ? 0.08 : 0), taper = 0.15 + r() * 0.45, pt = 0.1 + r() * 0.14, ric = r() < 0.4 ? 0.04 + r() * 0.05 : 0;
      meta.point = fam === 'claw' ? 'hook' : pick(r, ['spear', 'spear', 'clip', 'round', 'leaf']); meta.fuller = fam === 'sword' && r() < 0.7; meta.tang = tang;
      for (i = 0; i < N; i++) {
        var x = i / (N - 1), v;
        if (x < tang) v = tangW;
        else {
          var u = (x - tang) / (1 - tang);
          v = u < ric ? base * 0.92 : base * (1 - taper * u);
          if (meta.point === 'leaf') v *= 0.86 + 0.28 * Math.sin(Math.PI * Math.min(1, u * 1.2));
          var pu = (u - (1 - pt)) / pt;
          if (pu > 0) v *= meta.point === 'round' ? Math.sqrt(Math.max(0, 1 - pu * pu)) : (meta.point === 'clip' ? (pu < 0.5 ? 1 - pu * 0.5 : Math.max(0, 1.5 - pu * 1.5) * 1) : (meta.point === 'hook' ? Math.max(0, 1 - Math.pow(pu, 0.7)) : Math.max(0, 1 - pu)));
        }
        w.push(v);
      }
    } else if (fam === 'axe') {
      // ⛔ found by looking (2026-09-27): an axe drawn as a wedge continuing its haft read as a chisel. The bar is the
      // HEAD, poll to bit, and the haft crosses it at the eye (the drawing puts the haft through meta.eye).
      var poll = 0.1 + r() * 0.08, eyeW = 0.26 + r() * 0.06, cheek = 0.16 + r() * 0.06, bit = 0.7 + heft * 0.16 + r() * 0.1, k = 1.1 + r() * 1.4;
      var e0 = poll, e1 = poll + 0.16, c1 = e1 + 0.1 + r() * 0.08; meta.eye = (e0 + e1) / 2; meta.tang = 0; meta.point = 'bit'; meta.beard = r() < 0.5 ? 1 : 0;
      for (i = 0; i < N; i++) { var xa = i / (N - 1); w.push(xa < e0 ? eyeW * 0.9 : (xa < e1 ? eyeW : (xa < c1 ? cheek : cheek + (bit - cheek) * Math.pow((xa - c1) / (1 - c1), 1 / k)))); }
    } else if (fam === 'spear') {
      var sock = 0.38 + r() * 0.1, hw = 0.5 + heft * 0.18 + r() * 0.16, q = 0.6 + r() * 0.9; meta.tang = sock; meta.point = 'leaf';
      for (i = 0; i < N; i++) { var xs = i / (N - 1); if (xs < sock) w.push(tangW * 1.2); else { var us = (xs - sock) / (1 - sock); w.push(Math.max(tangW * 0.6, hw * Math.pow(Math.sin(Math.PI * Math.min(0.999, us * 0.92 + 0.04)), q) * (1 - us * 0.25))); } }
    } else { // mace: a haft, then a head with flanges
      var neck = 0.5 + r() * 0.1, head = 0.7 + heft * 0.14 + r() * 0.1, fl = 3 + Math.floor(r() * 4); meta.flanges = fl; meta.tang = neck; meta.point = 'head';
      for (i = 0; i < N; i++) { var xm = i / (N - 1); if (xm < neck) w.push(tangW * 1.1); else { var um = (xm - neck) / (1 - neck); w.push(head * (0.62 + 0.38 * Math.pow(Math.abs(Math.sin(Math.PI * fl * um)), 0.5)) * (um > 0.92 ? 0.8 : 1)); } }
    }
    for (i = 0; i < N; i++) w[i] = clamp(Math.round(w[i] * 1000) / 1000, 0.06, 0.95);
    return { v: 1, seed: seed, family: fam, metal: METALS.indexOf(spec.metal) >= 0 ? spec.metal : 'steel', name: String(spec.name || ''), profile: w, meta: meta };
  }

  /** A fresh forge: the bar of stock at white heat, nothing struck. */
  function newForge(t, difficulty) {
    var d = DIFFS[difficulty] ? difficulty : 'normal', w = [];
    for (var i = 0; i < N; i++) w.push(STOCK);
    return { v: 1, difficulty: d, maxHeats: DIFFS[d].heats, cool: DIFFS[d].cool, heat: 1, heats: 1, strikes: 0, work: w, marks: [], flaws: [], quenched: false, quench: null };
  }

  var R = 3;   // the hammer face covers 2R+1 samples
  var STEP = [0.012, 0.07];   // a blow's step at the face's centre: STEP[0] + STEP[1] x heat efficiency
  /**
   * One hammer blow at sample `pos`. Hot metal moves toward the target, most under the face's centre; cold metal
   * (below COLD) does not move and cracks. Every blow costs heat. Returns what happened.
   * @returns {{moved:number, cracked:boolean}}
   */
  function strike(t, f, pos) {
    if (f.quenched) return null;
    pos = clamp(Math.round(Number(pos) || 0), 0, N - 1);
    var r = rng((t.seed ^ 0x5171) + f.strikes * 7919), out = { moved: 0, cracked: false };
    f.strikes++;
    if (f.heat < COLD) { f.flaws.push(pos); out.cracked = true; f.heat = Math.max(0, f.heat - 0.02); return out; }
    // ⛔ 2026-09-27, found by the two-sided balance bound: a blow that moved metal a FRACTION of the error converged
    // under random hammering, and a careless player reached Fine. A blow now moves the metal a fixed STEP toward the
    // pattern, set by the heat (white heat roughs it out, a cooler bar takes finer work): struck where it is already
    // right, it overshoots. Skill is choosing where, and at what heat.
    var eff = clamp((f.heat - COLD) / 0.5, 0, 1), step = STEP[0] + STEP[1] * eff;
    for (var i = Math.max(0, pos - R); i <= Math.min(N - 1, pos + R); i++) {
      var fall = Math.pow(1 - Math.abs(i - pos) / (R + 1), 1.2), before = f.work[i], e = t.profile[i] - f.work[i];
      f.work[i] += (e >= 0 ? 1 : -1) * step * fall + (r() - 0.5) * 0.012 * (1 - eff);
      f.work[i] = clamp(f.work[i], 0.04, 0.98); out.moved += Math.abs(f.work[i] - before);
    }
    if (f.marks.length < 240) f.marks.push({ p: pos, h: Math.round(f.heat * 100) / 100 });
    f.heat = Math.max(0, f.heat - 0.03);
    return out;
  }
  /** Let the metal cool for `frames` frames. */
  function cool(f, frames) { if (!f.quenched) f.heat = Math.max(0, f.heat - f.cool * (frames || 1)); return f.heat; }
  /** Back into the hearth: full heat, one more heat used. Refused once the heats allowed are spent. */
  function reheat(f) { if (f.quenched || f.heats >= f.maxHeats) return false; f.heats++; f.heat = 1; return true; }

  var BANDS = [[0, 'black'], [0.2, 'faint red'], [0.32, 'blood red'], [0.42, 'cherry'], [0.56, 'bright cherry'], [0.66, 'orange'], [0.78, 'yellow'], [0.9, 'white']];
  /** The smith's name for a heat, from the colour chart. */
  function heatName(h) { var n = BANDS[0][1]; for (var i = 0; i < BANDS.length; i++) if (h >= BANDS[i][0]) n = BANDS[i][1]; return n; }
  var QUENCH = [0.42, 0.66];        // cherry to bright cherry: the colour to quench at

  /** Quench now, at whatever colour the metal is. Returns the quench verdict. */
  function quench(f) {
    if (f.quenched) return f.quench;
    var h = f.heat, q, note;
    if (h >= QUENCH[0] && h <= QUENCH[1]) { q = 1; note = 'true'; }
    else if (h > QUENCH[1]) { q = clamp(1 - (h - QUENCH[1]) * 2.4, 0.2, 1); note = h > 0.82 ? 'warped' : 'hot'; }
    else { q = clamp(1 - (QUENCH[0] - h) * 2.6, 0.3, 1); note = h < 0.3 ? 'soft' : 'cool'; }
    f.quenched = true; f.quench = { heat: Math.round(h * 100) / 100, colour: heatName(h), score: Math.round(q * 100) / 100, note: note };
    return f.quench;
  }

  /**
   * How close the work is to the target: 1 = exact. ⛔ measured 2026-09-27: a slope of 2.2 clamped every raw bar to 0,
   * so the tally read 0% for the first blows and the player had no feedback. At 1.4 the raw bar reads above 0 for
   * every family and each blow moves the figure.
   */
  function shape(t, f) { var e = 0, s = 0; for (var i = 0; i < N; i++) { e += Math.abs(f.work[i] - t.profile[i]); s += t.profile[i]; } return clamp(1 - (e / s) * 1.4, 0, 1); }

  var GRADES = [[0, 'Crude'], [40, 'Serviceable'], [65, 'Fine'], [85, 'Masterwork']];
  /**
   * The forge's verdict: quality 0..100 from the shape (60%), the quench (25%) and the heats used (15%), less 8 per
   * crack; the grade (1 Crude, 2 Serviceable, 3 Fine, 4 Masterwork).
   */
  function score(t, f) {
    var sh = shape(t, f), qn = f.quench ? f.quench.score : 0, eff = clamp(1 - (f.heats - 1) / Math.max(1, f.maxHeats) * 0.5, 0, 1);
    var q = clamp(Math.round(100 * (0.6 * sh + 0.25 * qn + 0.15 * eff) - 8 * f.flaws.length), 0, 100), g = 1;
    for (var i = 0; i < GRADES.length; i++) if (q >= GRADES[i][0]) g = i + 1;
    return { quality: q, grade: g, gradeName: GRADES[g - 1][1], shape: Math.round(sh * 100), quench: Math.round(qn * 100), heats: f.heats, strikes: f.strikes, flaws: f.flaws.length };
  }

  /** The sample the bar most needs struck next (largest weighted error), for hints and the balance probe. */
  function worst(t, f) { var b = 0, bi = 0; for (var i = 0; i < N; i++) { var e = 0; for (var j = Math.max(0, i - R); j <= Math.min(N - 1, i + R); j++) e += Math.abs(t.profile[j] - f.work[j]) * (1 - Math.abs(j - i) / (R + 1)); if (e > b) { b = e; bi = i; } } return bi; }

  return {
    VERSION: '1.0.0', N: N, STOCK: STOCK, COLD: COLD, R: R, FAMILIES: FAMILIES, DIFFS: DIFFS, METALS: METALS, BANDS: BANDS, QUENCH: QUENCH, GRADES: GRADES,
    hashString: hashString, rng: rng, familyOf: familyOf, metalOf: metalOf, target: target, newForge: newForge, strike: strike, cool: cool, reheat: reheat,
    heatName: heatName, quench: quench, shape: shape, score: score, worst: worst,
  };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = AnvilCore;
