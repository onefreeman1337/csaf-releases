/*:
 * @target MZ
 * @plugindesc Fray 3/3 - your party wears the fight: bruises, scorch, frost and torn cloth drawn into your own heroes' faces and side-view battlers, kept until they rest.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io/fray
 *
 * @param bands
 * @text HP bands (percent)
 * @desc Below each of these HP percentages a hero looks one step more spent. Highest first, comma separated.
 * @default 75,50,25
 *
 * @param maxMarks
 * @text Marks per hero
 * @desc The most marks one hero carries at once (older marks stay; new ones stop adding once this is reached).
 * @type number
 * @min 1
 * @max 24
 * @default 10
 *
 * @param faces
 * @text Wear on faces
 * @desc Draw the wear on the hero's face wherever the game draws it for that hero (battle status, menu, status, skills, equipment).
 * @type boolean
 * @default true
 *
 * @param battlers
 * @text Wear on side-view battlers
 * @desc Draw the wear on the hero's side-view battler sheet, every motion frame.
 * @type boolean
 * @default true
 *
 * @param dressings
 * @text Healing items dress wounds
 * @desc A healing item used on a marked hero lays a plaster or a bandage over the worst mark.
 * @type boolean
 * @default true
 *
 * @param mendOnRecoverAll
 * @text Rest mends everything
 * @desc Recover All (an inn, a save point, any event using it) removes every mark.
 * @type boolean
 * @default true
 *
 * @param budget
 * @text Battle bake budget (ms)
 * @desc Milliseconds per frame Fray may spend redrawing worn art during a battle. The work is spread over frames.
 * @type number
 * @decimals 1
 * @min 0.5
 * @max 8
 * @default 1.0
 *
 * @command wear
 * @text Wear a hero
 * @desc Draw a mark onto a hero from an event: a trap, a fall, a cutscene blow.
 *
 * @arg actorId
 * @text Actor
 * @desc The actor to mark. 0 = every party member.
 * @type actor
 * @default 0
 *
 * @arg family
 * @text Kind of mark
 * @type select
 * @option cut
 * @option crack
 * @option scorch
 * @option rime
 * @option fork
 * @option blight
 * @default cut
 *
 * @arg power
 * @text Power
 * @desc 0 to 1. How big the mark is (a hit for a third of max HP or more reads as 1).
 * @type number
 * @decimals 2
 * @min 0
 * @max 1
 * @default 0.6
 *
 * @command mend
 * @text Mend a hero
 * @desc Remove every mark from a hero (the HP-band look still follows HP).
 *
 * @arg actorId
 * @text Actor
 * @desc 0 = every party member.
 * @type actor
 * @default 0
 *
 * @command dress
 * @text Dress a wound
 * @desc Lay a plaster or bandage over a hero's worst undressed mark.
 *
 * @arg actorId
 * @text Actor
 * @desc 0 = every party member.
 * @type actor
 * @default 0
 *
 * @help
 * Fray.js - part of Fray v1.0.0. Enable it with FrayCore.js and ScatheCore.js (any order). ScatheCore.js is the same
 * file Scathe ships: if you own Scathe, keep one copy of it.
 *
 * Every hit a hero takes is drawn into that hero's own art: a blade grazes skin or tears cloth, a blow bruises, fire
 * scorches, ice frosts, lightning leaves a flash burn, poison and darkness a sick bruise. As HP falls past each band the
 * hero looks more spent: the colour drains from the skin, grime sinks in, and at the last band a side-view battler's
 * hem frays. The wear stays after the battle, in every menu, and in the save file (as a short list of decisions, never
 * pixels), until the hero rests. A healing item lays a plaster or a bandage over the worst mark.
 *
 * What it reads: skin, clothing and armour are found from each face's and battler's own colours. Nothing to draw, no
 * extra images. Marks land on cheeks and clothing, never outside the figure.
 *
 * Actor notetag:
 *   <Fray: off>      this hero never shows wear
 *
 * The kind of mark comes from the NAME of the element that hit (Fire, Ice, Thunder, Water, Earth, Poison, Darkness...;
 * a name it does not know is a cut). Faces chosen in Show Text are not changed: Fray draws on the faces the game shows
 * FOR a hero (menus, status, battle status).
 *
 * Plugin commands: Wear a hero, Mend a hero, Dress a wound.
 * Script: $gameActors.actor(1).frayRecord() returns the hero's record; $gameActors.actor(1).frayMend() mends.
 *
 * Every line of this plugin was written with AI assistance.
 */
(function () {
  'use strict';
  var NAME = 'Fray';
  var P = PluginManager.parameters(NAME);
  var BANDS = String(P.bands || '75,50,25').split(',').map(function (s) { return Number(s); }).filter(function (n) { return n > 0 && n < 100; }).sort(function (a, b) { return b - a; });
  var MAX_MARKS = Math.max(1, Math.min(24, Number(P.maxMarks) || 10));
  var FACES = P.faces !== 'false';
  var BATTLERS = P.battlers !== 'false';
  var DRESSINGS = P.dressings !== 'false';
  var MEND_ON_RECOVER = P.mendOnRecoverAll !== 'false';
  var BUDGET = Math.max(0.5, Math.min(8, Number(P.budget) || 1.0));
  var NOTE_OFF = /<Fray:\s*off\s*>/i;

  var DEPS = null;
  /** FrayCore (and through it ScatheCore) resolved at FIRST USE: load order is the buyer's (wing §8 trap 2) */
  function core() {
    if (DEPS) return DEPS;
    if (typeof FrayCore === 'undefined') throw new Error('Fray needs FrayCore.js enabled');
    FrayCore.sc();
    DEPS = FrayCore;
    return DEPS;
  }
  function isOff(actor) { var a = actor && actor.actor && actor.actor(); return !a || NOTE_OFF.test(a.note || ''); }
  function now() { return typeof performance !== 'undefined' ? performance.now() : Date.now(); }

  /* ----------------------------------------------------------------------- the record, on the actor (saved) */
  var CHECKED = typeof WeakSet === 'function' ? new WeakSet() : null;
  /** the hero's wear record: plain JSON, saved with the actor. A record read from a save is normalised once */
  Game_Actor.prototype.frayRecord = function () {
    var C = core();
    if (!this._fray) { this._fray = C.newRecord(C.sc().mix(this.actorId() | 0, 0xf7a1)); if (CHECKED) CHECKED.add(this._fray); }
    else if (CHECKED && !CHECKED.has(this._fray)) { this._fray = C.normalise(this._fray, C.sc().mix(this.actorId() | 0, 0xf7a1)); CHECKED.add(this._fray); }
    return this._fray;
  };
  /** add a mark of a family at a power 0..1; false when the hero is off or full */
  Game_Actor.prototype.frayWear = function (family, power) {
    if (isOff(this)) return false;
    return core().addHit(this.frayRecord(), family, power, MAX_MARKS);
  };
  Game_Actor.prototype.frayMend = function () { if (this._fray) core().mend(this.frayRecord()); };
  Game_Actor.prototype.frayDress = function () { return this._fray ? core().bandage(this.frayRecord()) >= 0 : false; };
  /** a number that changes whenever the picture must change (marks, dressings, mends, band); no allocation */
  function stampOf(actor) {
    var rec = actor._fray, band = core().sc().bandOf(actor.hp, actor.mhp, BANDS), dressed = 0, n = 0, gen = 0;
    if (rec) { n = rec.hits.length; gen = rec.gen; for (var i = 0; i < n; i++) if (rec.hits[i].b) dressed++; }
    return ((gen * 64 + n) * 32 + dressed) * 8 + band;
  }
  function isClean(actor) { return (!actor._fray || !actor._fray.hits.length) && core().sc().bandOf(actor.hp, actor.mhp, BANDS) === 0; }

  /** the element name of an action against a target: the skill's own element, or the attacker's first attack element */
  function elementNameOf(action) {
    var item = action.item(), id = item && item.damage ? item.damage.elementId : 0;
    if (id < 0) { var els = action.subject().attackElements(); id = els.length ? els[0] : 1; }
    return ($dataSystem.elements[id] || '');
  }
  var _executeHpDamage = Game_Action.prototype.executeHpDamage;
  Game_Action.prototype.executeHpDamage = function (target, value) {
    _executeHpDamage.apply(this, arguments);
    if (!(value > 0) || !target || !target.isActor || !target.isActor() || isOff(target)) return;
    target.frayWear(core().sc().familyOf(elementNameOf(this), 'flesh'), (value / Math.max(1, target.mhp)) * 3);
  };
  var _itemEffectRecoverHp = Game_Action.prototype.itemEffectRecoverHp;
  Game_Action.prototype.itemEffectRecoverHp = function (target, effect) {
    var before = target ? target.hp : 0;
    _itemEffectRecoverHp.apply(this, arguments);
    if (DRESSINGS && target && target.isActor && target.isActor() && this.isItem() && target.hp > before && target._fray) target.frayDress();
  };
  // Recover All is defined on Game_BattlerBase (rmmz_objects.js:3061); the saved handle is whatever Game_Actor resolves
  // it to now (the engine's, or another plugin's), so an earlier extension keeps running
  var _recoverAll = Game_Actor.prototype.recoverAll;
  Game_Actor.prototype.recoverAll = function () {
    _recoverAll.apply(this, arguments);
    if (MEND_ON_RECOVER && this._fray) this.frayMend();
  };

  /* ----------------------------------------------------------------------- plugin commands */
  function actorsOf(args) {
    var id = Math.floor(Number(args.actorId));
    if (id === 0) return $gameParty.members();
    var a = id > 0 ? $gameActors.actor(id) : null;
    return a ? [a] : [];
  }
  PluginManager.registerCommand(NAME, 'wear', function (args) {
    var fam = String(args.family || 'cut'), pw = args.power === '' || args.power == null ? 0.6 : Number(args.power);
    actorsOf(args).forEach(function (a) { a.frayWear(fam, pw); });
  });
  PluginManager.registerCommand(NAME, 'mend', function (args) { actorsOf(args).forEach(function (a) { a.frayMend(); }); });
  PluginManager.registerCommand(NAME, 'dress', function (args) { actorsOf(args).forEach(function (a) { a.frayDress(); }); });

  /* ----------------------------------------------------------------------- the worn pictures (runtime only, never saved) */
  /** prepared face cells, shared across battles, keyed by face sheet + index */
  var FACE_PREP = {};
  /** per actor: the worn face bitmap, the battler sheet state, and what each was last baked for */
  var RT = {};
  function rtOf(actor) { var id = actor.actorId(); return RT[id] || (RT[id] = { faceBmp: null, faceStamp: -1, faceKey: '', svName: '', sheet: null, svSrc: null, svBmp: null, svStamp: -1, svShown: -1, svBaking: false, svJob: null, faceQueued: false }); }
  var faceTick = 0;
  /** heroes whose battle face finished baking since the status window last looked */
  var FACE_DONE = [];
  /** read pixels from a canvas WE own (never bitmap.canvas, Probe_Doctrine §37b) */
  function pixelsOf(bmp, sx, sy, w, h) {
    var cv = document.createElement('canvas'); cv.width = w; cv.height = h;
    var g = cv.getContext('2d', { willReadFrequently: true });
    g.drawImage(bmp._canvas || bmp._image, sx, sy, w, h, 0, 0, w, h);
    return g.getImageData(0, 0, w, h).data;
  }
  function facePrep(actor) {
    var name = actor.faceName(), idx = actor.faceIndex(), key = name + '#' + idx;
    if (!name) return null;
    if (FACE_PREP[key]) return FACE_PREP[key];
    var bmp = ImageManager.loadFace(name);
    if (!bmp.isReady()) return null;
    var pw = ImageManager.faceWidth, ph = ImageManager.faceHeight;
    FACE_PREP[key] = core().prepare(pixelsOf(bmp, (idx % 4) * pw, Math.floor(idx / 4) * ph, pw, ph), pw, ph, 'face');
    return FACE_PREP[key];
  }
  function bakeFace(actor, rt) {
    var Pp = facePrep(actor); if (!Pp) return false;
    var key = actor.faceName() + '#' + actor.faceIndex(), pw = Pp.w, ph = Pp.h;
    if (rt.faceKey !== key) rt.faceWork = null;
    // incremental: a new mark at the same band is drawn onto the last face (FrayCore.bakeStep)
    var step = core().bakeStep(Pp, actor.frayRecord(), core().sc().bandOf(actor.hp, actor.mhp, BANDS), null, rt.faceWork);
    rt.faceWork = step.work;
    if (!rt.faceBmp || rt.faceBmp.width !== pw || rt.faceBmp.height !== ph) { if (rt.faceBmp) rt.faceBmp.destroy(); rt.faceBmp = new Bitmap(pw, ph); rt.faceImg = null; }
    if (!rt.faceImg || rt.faceImg.data !== step.rgba) rt.faceImg = new ImageData(step.rgba, pw, ph);
    rt.faceBmp.context.putImageData(rt.faceImg, 0, 0);
    rt.faceBmp._baseTexture.update();
    rt.faceStamp = stampOf(actor); rt.faceKey = key;
    return true;
  }
  /**
   * One slice of a battle face bake: a new mark on an unchanged face is ONE incremental slice; anything else (a band
   * change, a dressing, a mend, a first bake) is sliced: the band look, then one mark per slice, then the dressings.
   * Returns 1 when the face is up to date (uploaded), 0 when more slices remain, -1 when the face cannot be read yet.
   */
  function faceSlice(actor, rt) {
    var C = core(), Pp = facePrep(actor); if (!Pp) return -1;
    var key = actor.faceName() + '#' + actor.faceIndex(), rec = actor.frayRecord(), band = C.sc().bandOf(actor.hp, actor.mhp, BANDS);
    // MEASURED 2026-10-22 (front_debug.js): testing `rt.faceKey !== key` here reset the slice on EVERY call before the
    // first upload (faceKey is still empty), so a hero's first battle face re-queued itself forever. A known face that
    // CHANGED drops the old work; the slice carries its own key
    if (rt.faceKey && rt.faceKey !== key) rt.faceWork = null;
    var W = rt.faceKey === key ? rt.faceWork : null, d = C.dressedOf(rec);
    var incremental = W && !W.open && W.band === band && W.gen === rec.gen && W.dressed === d && W.n <= rec.hits.length && rec.hits.length - W.n <= 1;
    if (!incremental) {
      var S = rt.faceSliceWork;
      if (S && (S.band !== band || S.gen !== rec.gen || S.key !== key)) S = null;   // the moment moved mid-bake: start again
      if (!S) { S = rt.faceSliceWork = C.bakeBegin(Pp, rec, band); S.key = key; return 0; }
      if (!C.bakeMore(Pp, rec, null, S, 1)) return 0;
      C.bakeFinish(Pp, rec, S); rt.faceSliceWork = null; rt.faceWork = S;
      return uploadFace(actor, rt, Pp, S.rgba, key);
    }
    var step = C.bakeStep(Pp, rec, band, null, W);
    rt.faceWork = step.work;
    return uploadFace(actor, rt, Pp, step.rgba, key);
  }
  function uploadFace(actor, rt, Pp, rgba, key) {
    if (!rt.faceBmp || rt.faceBmp.width !== Pp.w || rt.faceBmp.height !== Pp.h) { if (rt.faceBmp) rt.faceBmp.destroy(); rt.faceBmp = new Bitmap(Pp.w, Pp.h); rt.faceImg = null; }
    if (!rt.faceImg || rt.faceImg.data !== rgba) rt.faceImg = new ImageData(rgba, Pp.w, Pp.h);
    rt.faceBmp.context.putImageData(rt.faceImg, 0, 0);
    rt.faceBmp._baseTexture.update();
    rt.faceStamp = stampOf(actor); rt.faceKey = key;
    return 1;
  }
  /**
   * The worn face for a hero, or null to draw the stock face. Outside a battle a stale face is re-baked on the spot (a
   * menu opening is a scene start); in a battle the bake goes to the frame-budgeted queue and the last picture is shown.
   */
  function wornFace(actor) {
    if (!FACES || isOff(actor) || isClean(actor) || !actor.faceName()) return null;
    var rt = rtOf(actor), st = stampOf(actor), key = actor.faceName() + '#' + actor.faceIndex();
    if (rt.faceStamp !== st || rt.faceKey !== key) {
      if (inBattle()) { if (!rt.faceQueued) { rt.faceQueued = true; enqueue({ kind: 'face', actor: actor }); } }
      else bakeFace(actor, rt);
    }
    return rt.faceBmp && rt.faceKey === key ? rt.faceBmp : null;
  }
  var _drawActorFace = Window_StatusBase.prototype.drawActorFace;
  Window_StatusBase.prototype.drawActorFace = function (actor, x, y, width, height) {
    var worn = actor ? wornFace(actor) : null;
    if (!worn) return _drawActorFace.apply(this, arguments);
    // the same arithmetic as Window_Base.prototype.drawFace (rmmz_windows.js:462-476), from the worn single cell
    width = width || ImageManager.standardFaceWidth;
    height = height || ImageManager.standardFaceHeight;
    var pw = ImageManager.faceWidth, ph = ImageManager.faceHeight, sw = Math.min(width, pw), sh = Math.min(height, ph);
    var dx = Math.floor(x + Math.max(width - pw, 0) / 2), dy = Math.floor(y + Math.max(height - ph, 0) / 2);
    this.contents.blt(worn, Math.floor((pw - sw) / 2), Math.floor((ph - sh) / 2), sw, sh, dx, dy);
  };
  function inBattle() { return SceneManager._scene instanceof Scene_Battle; }

  /* ----------------------------------------------------------------------- the frame-budgeted queue (battles) */
  var QUEUE = [];
  function enqueue(job) { QUEUE.push(job); }
  /** one job: a face bake, a battler sheet read, one cell prepared, or one cell baked */
  function runJob(job) {
    var C = core(), rt, a = job.actor;
    if (job.kind === 'face') {
      rt = rtOf(a);
      var done = faceSlice(a, rt);
      if (done === 0) { QUEUE.unshift(job); return; }   // more slices to go: this job runs again next
      rt.faceQueued = false;
      if (done > 0) { faceTick++; if (FACE_DONE.indexOf(a) < 0) FACE_DONE.push(a); }
      return;
    }
    rt = rtOf(a);
    var J = rt.svJob; if (!J || J !== job.sv) return;
    if (job.kind === 'read') {
      // the pixels were normally read at battle start (Scene_Battle.start below); read here only for a sheet that was not
      var b = rt.svSrc, pre = rt.svRead && rt.svRead.src === b ? rt.svRead : null;
      J.px = pre ? pre.px : pixelsOf(b, 0, 0, b.width, b.height); J.W = b.width; J.H = b.height; rt.svRead = null;
      J.cw = Math.floor(J.W / C.SV_COLS); J.ch = Math.floor(J.H / C.SV_ROWS);
      var ref0 = C.cellPixels(J.px, J.W, J.cw, J.ch, 1, 0), S0 = C.surfaces(ref0, J.cw, J.ch, { kind: 'cell' });
      J.model = S0.skinModel; J.chibi = S0.bbox.h < S0.bbox.w * 1.8; J.cells = [];
      for (var i = 0; i < C.SV_COLS * C.SV_ROWS; i++) QUEUE.push({ kind: 'prep', actor: a, sv: J, i: i });
      QUEUE.push({ kind: 'bakeAll', actor: a, sv: J });
      return;
    }
    if (job.kind === 'prep') {
      var cx = job.i % C.SV_COLS, cy = Math.floor(job.i / C.SV_COLS);
      J.cells[job.i] = { cx: cx, cy: cy, P: C.prepare(C.cellPixels(J.px, J.W, J.cw, J.ch, cx, cy), J.cw, J.ch, 'cell', { skin: J.model, chibi: J.chibi }) };
      return;
    }
    if (job.kind === 'bakeAll') {
      // the sheet is prepared: plan a bake of every cell for the CURRENT record, then upload once at the end
      rt.sheet = { W: J.W, H: J.H, cw: J.cw, ch: J.ch, cells: J.cells, ref: J.cells[1] };
      startSheetBake(a, rt);
      return;
    }
    if (job.kind === 'cell') {
      var S = rt.sheet, cell = S.cells[job.i], step = C.bakeStep(cell.P, job.rec, job.band, job.body, rt.cellWork[job.i]), buf = job.buf, r = step.rgba;
      rt.cellWork[job.i] = step.work;
      // a cell whose picture did not move (no new mark reached it) needs no copy: the sheet buffer already holds it
      if (step.added === 0) return;
      for (var y = 0; y < S.ch; y++) { var d = ((cell.cy * S.ch + y) * S.W + cell.cx * S.cw) * 4, s = y * S.cw * 4; for (var k = 0; k < S.cw * 4; k++) buf[d + k] = r[s + k]; }
      return;
    }
    if (job.kind === 'upload') {
      // MEASURED 2026-10-22 (breakit attack 7): one putImageData of a 1152 x 768 HD sheet plus its texture upload was a
      // 16 ms job. The canvas is written one cell ROW per job (the texture still shows the last sheet meanwhile, it is a
      // canvas texture that changes only on update()), and the texture is uploaded once, with the last row
      var Sh = rt.sheet, row = job.row || 0;
      if (!rt.svBmp || rt.svBmp.width !== Sh.W || rt.svBmp.height !== Sh.H) { if (rt.svBmp) rt.svBmp.destroy(); rt.svBmp = new Bitmap(Sh.W, Sh.H); }
      if (!rt.svImg || rt.svImg.data !== job.buf) rt.svImg = new ImageData(job.buf, Sh.W, Sh.H);
      rt.svBmp.context.putImageData(rt.svImg, 0, 0, 0, row * Sh.ch, Sh.W, Sh.ch);
      if (row < C.SV_ROWS - 1) { QUEUE.unshift({ kind: 'upload', actor: a, sv: job.sv, buf: job.buf, stamp: job.stamp, row: row + 1 }); return; }
      rt.svBmp._baseTexture.update();
      rt.svShown = job.stamp; rt.svBaking = false;
    }
  }
  function startSheetBake(a, rt) {
    var C = core(), S = rt.sheet, rec = a.frayRecord(), band = C.sc().bandOf(a.hp, a.mhp, BANDS);
    // a frozen copy of the record: the bake shows exactly one moment even if a hit lands mid-bake
    var snap = { v: rec.v, seed: rec.seed, gen: rec.gen, hits: rec.hits.map(function (h) { return { f: h.f, p: h.p, s: h.s, b: h.b }; }) };
    // one sheet buffer per hero per battle, reused: an incremental cell bake only rewrites the cells it changed
    var body = C.bodyPoints(S, snap), buf = rt.svBuf && rt.svBuf.length === S.W * S.H * 4 ? rt.svBuf : (rt.svBuf = new Uint8ClampedArray(S.W * S.H * 4)), st = stampOf(a);
    if (!rt.cellWork) rt.cellWork = new Array(S.cells.length);
    rt.svBaking = true; rt.svStamp = st;
    for (var i = 0; i < S.cells.length; i++) QUEUE.push({ kind: 'cell', actor: a, sv: rt.svJob, i: i, rec: snap, band: band, body: body, buf: buf });
    QUEUE.push({ kind: 'upload', actor: a, sv: rt.svJob, buf: buf, stamp: st });
  }
  /** run queued jobs until this frame's budget is spent (always at least one, so the queue always drains) */
  // MEASURED 2026-10-22 (mz_gate gate_party_marks, p99 4.7 ms): "run while under budget" started a second ~1 ms job at
  // 0.9 ms. A job now starts only if the last job's own duration still fits in what is left
  var lastJobMs = 0;
  function drain() {
    if (!QUEUE.length) return;
    var t0 = now(), n = 0;
    while (QUEUE.length && (n === 0 || now() - t0 + lastJobMs <= BUDGET)) { var t1 = now(); runJob(QUEUE.shift()); lastJobMs = now() - t1; n++; }
  }
  var _sbUpdate = Scene_Battle.prototype.update;
  Scene_Battle.prototype.update = function () {
    _sbUpdate.apply(this, arguments);
    drain();
  };
  var _sbCreate = Scene_Battle.prototype.create;
  Scene_Battle.prototype.create = function () {
    _sbCreate.apply(this, arguments);
    // faces are prepared before the battle draws (a face read is one pixel read per face, once per session), and a hero
    // who enters the battle already worn has the face baked here, not in a measured battle frame
    if (FACES) $gameParty.members().forEach(function (a) { if (!isOff(a) && facePrep(a) && !isClean(a)) { var rt = rtOf(a); if (rt.faceStamp !== stampOf(a)) bakeFace(a, rt); } });
  };
  var _sbStart = Scene_Battle.prototype.start;
  Scene_Battle.prototype.start = function () {
    _sbStart.apply(this, arguments);
    // MEASURED 2026-10-22 (breakit attack 7): at create() the face images were not loaded yet, so a face's first read and
    // preparation fell into a play frame as a 40.9 ms job. By start() the scene has waited for its images: faces are
    // prepared (and a hero who arrives worn is baked) HERE
    if (FACES) $gameParty.battleMembers().forEach(function (a) { if (!isOff(a) && a.faceName() && facePrep(a) && !isClean(a)) { var rt = rtOf(a); if (rt.faceStamp !== stampOf(a)) bakeFace(a, rt); } });
    // every battler sheet is loaded by now (the scene waited for its images): read each hero's pixels HERE, once, so a
    // pixel read (a GPU sync point, Probe_Doctrine §27a) never lands in a frame of play
    if (!BATTLERS || !$gameSystem.isSideView()) return;
    $gameParty.battleMembers().forEach(function (a) {
      if (isOff(a)) return;
      var rt = rtOf(a), name = a.battlerName(), b = name ? ImageManager.loadSvActor(name) : null;
      if (!b || !b.isReady() || b.width < 9 || b.height < 6) return;
      if (rt.svName !== name) { rt.svName = name; rt.svSrc = b; rt.svJob = null; rt.sheet = null; rt.svShown = -1; rt.svStamp = -1; }
      rt.svRead = { src: b, px: pixelsOf(b, 0, 0, b.width, b.height) };
    });
  };
  var _sbTerminate = Scene_Battle.prototype.terminate;
  Scene_Battle.prototype.terminate = function () {
    _sbTerminate.apply(this, arguments);
    // a battle's battler work dies with it; worn faces carry on to the menus (re-baked there if stale)
    QUEUE.length = 0;
    for (var id in RT) { var rt = RT[id]; rt.svJob = null; rt.sheet = null; rt.svBaking = false; rt.svShown = -1; rt.svStamp = -1; rt.faceQueued = false; if (rt.svBmp) { rt.svBmp.destroy(); rt.svBmp = null; } rt.svSrc = null; rt.svName = ''; rt.svBuf = null; rt.svImg = null; rt.cellWork = null; rt.svRead = null; }
  };

  /* ----------------------------------------------------------------------- the battle status window follows a finished face */
  var _wbsUpdate = Window_BattleStatus.prototype.update;
  Window_BattleStatus.prototype.update = function () {
    _wbsUpdate.apply(this, arguments);
    // MEASURED 2026-10-22 (in_engine.js): a face was only re-baked when the window happened to redraw, and nothing in a
    // battle guarantees a redraw after a hit. The window watches its heroes' stamps itself (party ids, no allocation)
    // and queues the bake; when a bake lands it redraws once
    if (FACES) {
      var ids = $gameParty._actors;
      for (var i = 0; i < ids.length; i++) {
        var a = $gameActors.actor(ids[i]);
        // (MEASURED 2026-10-22, breakit attack 4: a hero with NO face image re-queued a face bake every frame forever)
        if (!a || isOff(a) || isClean(a) || !a.faceName()) continue;
        var rt = rtOf(a);
        if (!rt.faceQueued && rt.faceStamp !== stampOf(a)) { rt.faceQueued = true; enqueue({ kind: 'face', actor: a }); }
      }
    }
    // MEASURED 2026-10-22 (mz_gate gate_party_marks): a full refresh per finished face cost 0.9 bitmap dirties a frame (the
    // ceiling is 0.5). The battle status window's name, gauges and state icons are SPRITES, its contents hold the faces
    // alone, so a finished face redraws only its own face rect
    if (this._frayTick !== faceTick) {
      this._frayTick = faceTick;
      for (var j = 0; j < FACE_DONE.length; j++) {
        for (var k = 0; k < this.maxItems(); k++) {
          if (this.actor(k) !== FACE_DONE[j]) continue;
          var r = this.faceRect(k);
          this.contents.clearRect(r.x, r.y, r.width, r.height);
          this.drawItemImage(k);
        }
      }
      FACE_DONE.length = 0;
    }
  };

  /* ----------------------------------------------------------------------- side-view battlers */
  var _updateBitmap = Sprite_Actor.prototype.updateBitmap;
  Sprite_Actor.prototype.updateBitmap = function () {
    _updateBitmap.apply(this, arguments);
    if (!BATTLERS || !this._actor) return;
    this.updateFray();
  };
  /**
   * Show the worn sheet when there is one for this moment; otherwise ask for one. Nothing allocates per frame: the
   * comparisons are numbers and the work goes to the queue.
   */
  Sprite_Actor.prototype.updateFray = function () {
    var a = this._actor, main = this._mainSprite;
    if (!main || isOff(a) || !$gameSystem.isSideView()) return;
    var rt = rtOf(a), name = a.battlerName();
    if (rt.svName !== name) { rt.svName = name; rt.svSrc = ImageManager.loadSvActor(name); rt.svJob = null; rt.sheet = null; rt.svShown = -1; rt.svStamp = -1; }
    var src = rt.svSrc;
    if (!src || !src.isReady() || src.width < 9 || src.height < 6) return;
    if (isClean(a)) { if (main.bitmap !== src) main.bitmap = src; return; }
    var st = stampOf(a);
    if (!rt.svJob) { rt.svJob = { actor: a }; rt.svStamp = st; QUEUE.push({ kind: 'read', actor: a, sv: rt.svJob }); }
    else if (rt.sheet && !rt.svBaking && rt.svStamp !== st) startSheetBake(a, rt);
    if (rt.svBmp && rt.svShown >= 0 && main.bitmap !== rt.svBmp) main.bitmap = rt.svBmp;
  };

  /* exposed for tests and capture tooling (not an API promise) */
  window.FrayRuntime = { queueLength: function () { return QUEUE.length; }, peek: function () { return QUEUE.length ? QUEUE[0].kind : ''; }, drain: function (ms) { var t0 = now(); while (QUEUE.length && now() - t0 < (ms || 1e9)) runJob(QUEUE.shift()); }, RT: RT, FACE_PREP: FACE_PREP, stampOf: stampOf, BANDS: BANDS };
})();
