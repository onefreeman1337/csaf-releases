/*:
 * @target MZ
 * @plugindesc Fray 2/3 - the wear: skin, cloth and armour found in each hero's own face and battler art, and every mark drawn into them. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * FrayCore.js - part of Fray v1.0.0. Enable it with ScatheCore.js and Fray.js (any order). It has no commands or
 * parameters of its own; Fray.js reads it.
 *
 * Every line of this plugin was written with AI assistance.
 */
/*
 * The whole picture as PURE pixel operations on RGBA buffers, so it runs in Node on real face sheets and side-view
 * battler sheets exactly as it runs in MZ. Never Math.random: every mark is seeded. Every mark lands only on the surface
 * it belongs to (skin, cloth or hard armour), found from the art's own palette, and every ink is derived from the pixels
 * it lands on. Scorch, frost, lightning and blight are ScatheCore's own families, CALLED, never copied (wing §11).
 */
var FrayCore = (function () {
  'use strict';

  var SC = null;
  /** ScatheCore resolved at first use (load order is the buyer's, wing §8 trap 2) */
  function sc() {
    if (SC) return SC;
    if (typeof ScatheCore !== 'undefined') SC = ScatheCore;
    else if (typeof require === 'function') { try { SC = require('./ScatheCore.js'); } catch (e) { SC = null; } }
    if (!SC) throw new Error('Fray needs ScatheCore.js enabled');
    return SC;
  }

  /* ------------------------------------------------------------ colour */
  var HSV = [0, 0, 0];
  /** hue in degrees (0..360), saturation and value in 0..1, written into HSV (no allocation) */
  function hsv(r, g, b) {
    var mx = r > g ? (r > b ? r : b) : (g > b ? g : b), mn = r < g ? (r < b ? r : b) : (g < b ? g : b), d = mx - mn, h = 0;
    if (d > 0) {
      if (mx === r) h = 60 * (((g - b) / d) % 6); else if (mx === g) h = 60 * ((b - r) / d + 2); else h = 60 * ((r - g) / d + 4);
      if (h < 0) h += 360;
    }
    HSV[0] = h; HSV[1] = mx > 0 ? d / mx : 0; HSV[2] = mx / 255;
    return HSV;
  }
  function cb(r, g, b) { return 128 - 0.168736 * r - 0.331264 * g + 0.5 * b; }
  function cr(r, g, b) { return 128 + 0.5 * r - 0.418688 * g - 0.081312 * b; }
  function luma(r, g, b) { return 0.299 * r + 0.587 * g + 0.114 * b; }
  /** a skin CANDIDATE: warm hue, moderate saturation, not too dark (any skin tone: the hue band, never a lightness band) */
  function skinish(r, g, b) {
    var c = hsv(r, g, b);
    return (c[0] <= 48 || c[0] >= 345) && c[1] >= 0.1 && c[1] <= 0.72 && c[2] >= 0.2 && r >= b + 12;
  }

  /* ------------------------------------------------------------ surfaces */
  var SURF = { NONE: 0, SKIN: 1, CLOTH: 2, HARD: 3 };
  function median(arr, n) { if (!n) return 0; var a = Array.prototype.slice.call(arr, 0, n).sort(function (x, y) { return x - y; }); return a[n >> 1]; }

  /**
   * Find what each pixel of one image (a face cell or one battler cell) IS: background, skin, cloth or hard armour.
   * Background is the transparent part, plus (for a painted portrait with an opaque backdrop) whatever floods in from
   * the border in the border's own colour. Skin is seeded from where a face is (the centre of a face cell, the top of a
   * battler) and grown by chroma, so hair the same hue family as the skin but another chroma stays out. Cloth is the
   * non-skin figure below the head; hard is the low-saturation bright part of it (steel, silver, mail).
   * @param {Uint8Array|Uint8ClampedArray} px RGBA, w*h*4
   * @param {{kind:'face'|'cell', skin?:{cb:number,cr:number,tol:number}}} [opts]
   * @returns {{w:number,h:number,surf:Uint8Array,fg:Uint8Array,counts:number[],skinModel:Object|null,headY:number,bbox:Object}}
   */
  function surfaces(px, w, h, opts) {
    opts = opts || {};
    var kind = opts.kind || 'face', n = w * h, i, x, y, o;
    var fg = new Uint8Array(n), surf = new Uint8Array(n);
    for (i = 0; i < n; i++) fg[i] = px[i * 4 + 3] > 32 ? 1 : 0;
    // painted backdrop: flood from the border over pixels near the border's median colour
    var bn = 0, bo = 0, br = [], bg = [], bb = [];
    for (x = 0; x < w; x++) { pushB(x, 0); pushB(x, h - 1); }
    for (y = 1; y < h - 1; y++) { pushB(0, y); pushB(w - 1, y); }
    function pushB(xx, yy) { var k = (yy * w + xx) * 4; bn++; if (px[k + 3] > 32) { bo++; br.push(px[k]); bg.push(px[k + 1]); bb.push(px[k + 2]); } }
    if (kind === 'face' && bo > bn * 0.6) {
      var mr = median(br, br.length), mg = median(bg, bg.length), mb = median(bb, bb.length), dev = [], k2;
      for (k2 = 0; k2 < br.length; k2++) dev.push(Math.abs(br[k2] - mr) + Math.abs(bg[k2] - mg) + Math.abs(bb[k2] - mb));
      var T = Math.max(36, Math.min(90, median(dev, dev.length) * 3 + 18));
      var stack = [], seen = new Uint8Array(n);
      for (x = 0; x < w; x++) { stack.push(x, (h - 1) * w + x); }
      for (y = 0; y < h; y++) { stack.push(y * w, y * w + w - 1); }
      while (stack.length) {
        i = stack.pop(); if (seen[i]) continue; seen[i] = 1;
        o = i * 4;
        if (!fg[i]) continue;
        if (Math.abs(px[o] - mr) + Math.abs(px[o + 1] - mg) + Math.abs(px[o + 2] - mb) > T) continue;
        fg[i] = 0;
        x = i % w; y = (i / w) | 0;
        if (x > 0) stack.push(i - 1); if (x < w - 1) stack.push(i + 1); if (y > 0) stack.push(i - w); if (y < h - 1) stack.push(i + w);
      }
    }
    // figure bbox
    var x0 = w, y0 = h, x1 = -1, y1 = -1;
    for (i = 0; i < n; i++) if (fg[i]) { x = i % w; y = (i / w) | 0; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    var bbox = { x: x0, y: y0, w: x1 - x0 + 1, h: y1 - y0 + 1 };
    if (x1 < 0) return { w: w, h: h, surf: surf, fg: fg, counts: [n, 0, 0, 0], skinModel: null, headY: 0, bbox: { x: 0, y: 0, w: 0, h: 0 } };
    // the skin model: given (one model for a whole battler sheet), or seeded from where the face is
    var model = opts.skin || null;
    if (!model) {
      var sx0, sx1, sy0, sy1;
      // LOOKED AT 2026-10-22 (_out/surf2.png): a window from 22% down took a long fringe as the face (People1 #1: the
      // model came from hair and her face fell below the head line as CLOTH). The seed is the cheeks-nose-mouth zone
      if (kind === 'face') { sx0 = (w * 0.32) | 0; sx1 = (w * 0.68) | 0; sy0 = (h * 0.42) | 0; sy1 = (h * 0.72) | 0; }
      // LOOKED AT 2026-10-22 (_out/surf_sv.png): the top fifth of a stock MZ battler is HAIR (a chibi's head is half its
      // height), so the hair became skin and the face cloth. A battler's face zone comes from its proportions
      else if (bbox.h < bbox.w * 1.8) { sx0 = x0 + ((bbox.w * 0.2) | 0); sx1 = x1 - ((bbox.w * 0.2) | 0); sy0 = y0 + ((bbox.h * 0.24) | 0); sy1 = y0 + ((bbox.h * 0.52) | 0); }
      else { sx0 = x0; sx1 = x1; sy0 = y0 + ((bbox.h * 0.03) | 0); sy1 = y0 + Math.max(2, (bbox.h * 0.18) | 0); }
      var cbs = [], crs = [], ys = [];
      for (y = sy0; y <= sy1; y++) for (x = sx0; x <= sx1; x++) { i = y * w + x; o = i * 4; if (fg[i] && skinish(px[o], px[o + 1], px[o + 2])) { cbs.push(cb(px[o], px[o + 1], px[o + 2])); crs.push(cr(px[o], px[o + 1], px[o + 2])); ys.push(luma(px[o], px[o + 1], px[o + 2])); } }
      var need = kind === 'face' ? (sx1 - sx0) * (sy1 - sy0) * 0.04 : 3;
      // LOOKED AT 2026-10-22 (_out/surf1.png, 32 faces): chroma alone took brown and blond hair and grey beards for skin
      // (the hue family is the same). Hair is far darker (anime brown) or far yellower (blond) than the skin beside it, so
      // the model also carries the skin's own LUMA, relative to this face (a dark-skinned face seeds a dark model)
      if (cbs.length >= need) model = { cb: median(cbs, cbs.length), cr: median(crs, crs.length), y: median(ys, ys.length), tol: kind === 'face' ? 11 : 10, tolY: kind === 'face' ? 62 : 58 };
    }
    var cand = new Uint8Array(n);
    if (model) for (i = 0; i < n; i++) {
      if (!fg[i]) continue; o = i * 4;
      if (!skinish(px[o], px[o + 1], px[o + 2])) continue;
      if (Math.abs(cb(px[o], px[o + 1], px[o + 2]) - model.cb) <= model.tol && Math.abs(cr(px[o], px[o + 1], px[o + 2]) - model.cr) <= model.tol &&
        (model.y === undefined || Math.abs(luma(px[o], px[o + 1], px[o + 2]) - model.y) <= model.tolY)) cand[i] = 1;
    }
    if (kind === 'face' && model) {
      // a face's skin is the region joined to its middle: grow from candidates inside the central window only
      var st2 = [], cx0 = (w * 0.32) | 0, cx1 = (w * 0.68) | 0, cy0 = (h * 0.42) | 0, cy1 = (h * 0.72) | 0;
      for (y = cy0; y <= cy1; y++) for (x = cx0; x <= cx1; x++) { i = y * w + x; if (cand[i]) st2.push(i); }
      while (st2.length) {
        i = st2.pop(); if (surf[i] || !cand[i]) continue; surf[i] = SURF.SKIN;
        x = i % w; y = (i / w) | 0;
        if (x > 0) st2.push(i - 1); if (x < w - 1) st2.push(i + 1); if (y > 0) st2.push(i - w); if (y < h - 1) st2.push(i + w);
        if (x > 0 && y > 0) st2.push(i - w - 1); if (x < w - 1 && y > 0) st2.push(i - w + 1); if (x > 0 && y < h - 1) st2.push(i + w - 1); if (x < w - 1 && y < h - 1) st2.push(i + w + 1);
      }
    } else for (i = 0; i < n; i++) if (cand[i]) surf[i] = SURF.SKIN;
    // the head line: below it the non-skin figure is clothing (or armour); above it it is hair and headgear (no marks)
    var headY;
    if (kind === 'face') {
      // the chin: the lowest row where skin still spans a fifth of the face cell, or 70% down when there is none
      headY = (h * 0.7) | 0;
      for (y = h - 1; y >= 0; y--) { var run = 0; for (x = 0; x < w; x++) if (surf[y * w + x] === SURF.SKIN) run++; if (run >= w * 0.2) { headY = y; break; } }
      headY = Math.min(h - 1, Math.max((h * 0.45) | 0, headY - ((h * 0.04) | 0)));
    } else headY = y0 + Math.max(2, (bbox.h * (opts.chibi || bbox.h < bbox.w * 1.8 ? 0.55 : 0.2)) | 0);
    // a LYING battler (the dead and sleep rows): the head is at one END, not the top. The end holding more skin is the
    // head; its last quarter is excluded the way the rows above the head line are for a standing figure
    var lying = kind === 'cell' && bbox.w > bbox.h * 1.3, headX0 = -1, headX1 = -1;
    if (lying) {
      var q = Math.max(2, (bbox.w * 0.28) | 0), sl = 0, sr = 0;
      for (i = 0; i < n; i++) if (surf[i] === SURF.SKIN) { x = i % w; if (x < x0 + q) sl++; else if (x > x1 - q) sr++; }
      if (sl > sr) { headX0 = x0; headX1 = x0 + q; } else { headX0 = x1 - q; headX1 = x1; }
      headY = y0;
    }
    // the HAIR colour, from the non-skin figure above the head line: long hair falling past the chin is not clothing
    // (LOOKED AT 2026-10-22: a braid below the chin took lightning as if it were cloth)
    var hair = null;
    if (kind === 'face') {
      var hr = [], hg = [], hb = [];
      for (y = (h * 0.12) | 0; y < headY; y++) for (x = 0; x < w; x++) { i = y * w + x; if (!fg[i] || surf[i] === SURF.SKIN) continue; o = i * 4; hr.push(px[o]); hg.push(px[o + 1]); hb.push(px[o + 2]); }
      if (hr.length > w * h * 0.03) hair = [median(hr, hr.length), median(hg, hg.length), median(hb, hb.length)];
    }
    var counts = [0, 0, 0, 0];
    for (i = 0; i < n; i++) {
      if (!fg[i]) { counts[0]++; continue; }
      if (surf[i] === SURF.SKIN) { counts[1]++; continue; }
      y = (i / w) | 0;
      if (y < headY) { counts[0]++; continue; }
      if (hair) { o = i * 4; if (Math.abs(px[o] - hair[0]) + Math.abs(px[o + 1] - hair[1]) + Math.abs(px[o + 2] - hair[2]) < 54) { counts[0]++; continue; } }
      if (lying) { x = i % w; if (x >= headX0 && x <= headX1) { counts[0]++; continue; } }
      o = i * 4;
      // the safe side of a miss: a near-skin pixel the model rejected is NEITHER skin nor cloth, so a tear can never be
      // drawn on a face the model under-read (a graze on hair is the mild failure; a torn-cloth mark on a cheek is not)
      if (model && skinish(px[o], px[o + 1], px[o + 2]) && Math.abs(cb(px[o], px[o + 1], px[o + 2]) - model.cb) <= model.tol * 2.2 && Math.abs(cr(px[o], px[o + 1], px[o + 2]) - model.cr) <= model.tol * 2.2) { counts[0]++; continue; }
      var c = hsv(px[o], px[o + 1], px[o + 2]);
      surf[i] = c[1] < 0.18 && c[2] > 0.42 ? SURF.HARD : SURF.CLOTH;
      counts[surf[i]]++;
    }
    // LOOKED AT 2026-10-22 (plate 2): on painted armour only the specular SPECKLES read as hard, so frost landed as white
    // block noise. Armour and cloth are REGIONS: each non-skin figure pixel takes the majority of its neighbourhood
    // (a box of a twentieth of the image, from an integral image, no per-pixel allocation)
    var rad = Math.max(1, Math.round(Math.min(w, h) / 20)), ih = new Int32Array((w + 1) * (h + 1)), ic = new Int32Array((w + 1) * (h + 1));
    for (y = 0; y < h; y++) { var rh = 0, rc = 0; for (x = 0; x < w; x++) { i = y * w + x; if (surf[i] === SURF.HARD) rh++; else if (surf[i] === SURF.CLOTH) rc++; ih[(y + 1) * (w + 1) + x + 1] = ih[y * (w + 1) + x + 1] + rh; ic[(y + 1) * (w + 1) + x + 1] = ic[y * (w + 1) + x + 1] + rc; } }
    var box = function (A2, xa, ya, xb, yb) { return A2[yb * (w + 1) + xb] - A2[ya * (w + 1) + xb] - A2[yb * (w + 1) + xa] + A2[ya * (w + 1) + xa]; };
    counts[2] = 0; counts[3] = 0;
    for (i = 0; i < n; i++) {
      if (surf[i] !== SURF.HARD && surf[i] !== SURF.CLOTH) continue;
      x = i % w; y = (i / w) | 0;
      var xa = Math.max(0, x - rad), ya = Math.max(0, y - rad), xb = Math.min(w, x + rad + 1), yb = Math.min(h, y + rad + 1);
      surf[i] = box(ih, xa, ya, xb, yb) > box(ic, xa, ya, xb, yb) ? SURF.HARD : SURF.CLOTH;
      counts[surf[i]]++;
    }
    return { w: w, h: h, surf: surf, fg: fg, counts: counts, skinModel: model, headY: headY, bbox: bbox, lying: lying, headRight: lying ? headX0 > x0 : false };
  }

  /* ------------------------------------------------------------ seeded noise (no Math.random anywhere) */
  function hash2(x, y, s) { var h = Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263) ^ Math.imul(s | 0, 2246822519); h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; }
  function noise(x, y, scl, s) {
    var fx = x / scl, fy = y / scl, ix = Math.floor(fx), iy = Math.floor(fy), tx = fx - ix, ty = fy - iy;
    tx = tx * tx * (3 - 2 * tx); ty = ty * ty * (3 - 2 * ty);
    var a = hash2(ix, iy, s), b = hash2(ix + 1, iy, s), c = hash2(ix, iy + 1, s), d = hash2(ix + 1, iy + 1, s);
    return a + (b - a) * tx + (c - a) * ty + (a - b - c + d) * tx * ty;
  }
  function rng(seed) { return { s: sc().mix(seed | 0, 0xf4a7) }; }
  function rand(r) { return sc().rand(r); }

  /* ------------------------------------------------------------ one prepared image (a face cell or a battler cell) */
  /**
   * Everything the marks need about one image, computed ONCE from its pixels: the surfaces, a ScatheCore analysis of the
   * figure (the backdrop removed), and one analysis view per surface, so a Scathe family drawn "on cloth" stops at the
   * skin and never leaves the clothing. Never called during play: Fray.js prepares at the first draw of an actor.
   * @param {Uint8ClampedArray} px RGBA (kept as the clean source)   @param {string} kind 'face' | 'cell'
   * @param {Object} [opts] passed to surfaces() (a sheet's skin model, chibi)
   */
  function prepare(px, w, h, kind, opts) {
    var S = surfaces(px, w, h, Object.assign({ kind: kind }, opts || {}));
    var cut = new Uint8ClampedArray(px.length), i, n = w * h;
    for (i = 0; i < px.length; i++) cut[i] = px[i];
    for (i = 0; i < n; i++) if (!S.fg[i]) cut[i * 4 + 3] = 0;
    var A = sc().analyse(cut, w, h);
    var per = [null, null, null, null];
    for (var k = 1; k <= 3; k++) {
      var m = new Uint8Array(n), area = 0;
      for (i = 0; i < n; i++) if (S.surf[i] === k && A.mask[i]) { m[i] = 1; area++; }
      per[k] = { w: A.w, h: A.h, mask: m, dist: A.dist, lum: A.lum, bbox: A.bbox, area: area, px: A.px };
    }
    var src = new Uint8ClampedArray(px.length);
    for (i = 0; i < px.length; i++) src[i] = px[i];
    // the BODY below the head line, minus skin: where a wrapped bandage may go on a portrait (LOOKED AT 2026-10-22: a
    // wrap clipped to the whole figure crossed two faces)
    var bm = new Uint8Array(n), ba = 0;
    for (i = 0; i < n; i++) if (A.mask[i] && S.surf[i] !== SURF.SKIN && ((i / w) | 0) >= S.headY) { bm[i] = 1; ba++; }
    var body = { w: A.w, h: A.h, mask: bm, dist: A.dist, lum: A.lum, bbox: A.bbox, area: ba, px: A.px };
    return { w: w, h: h, kind: kind, src: src, S: S, A: A, per: per, body: body, size: Math.max(4, Math.min(A.bbox.w, A.bbox.h)) };
  }

  /* ------------------------------------------------------------ the record (what the save keeps: decisions, never pixels) */
  var FAMILIES = ['cut', 'crack', 'scorch', 'rime', 'fork', 'blight'];
  var RECORD_VERSION = 1;
  /** a clean record for one actor */
  function newRecord(seed) { return { v: RECORD_VERSION, seed: seed >>> 0, gen: 0, hits: [] }; }
  /**
   * A record read back from a save: anything this version cannot read is dropped to a clean record rather than thrown on
   * (an old or hand-edited save never crashes a load), and every field is coerced to its type.
   */
  function normalise(rec, seed) {
    if (!rec || typeof rec !== 'object' || rec.v !== RECORD_VERSION || !Array.isArray(rec.hits)) return newRecord(seed);
    var out = newRecord(Number.isFinite(rec.seed) ? rec.seed : seed);
    out.gen = Math.max(0, Math.floor(Number(rec.gen) || 0));
    for (var i = 0; i < rec.hits.length && i < 40; i++) {
      var h = rec.hits[i]; if (!h || typeof h !== 'object') continue;
      out.hits.push({ f: FAMILIES.indexOf(h.f) >= 0 ? h.f : 'cut', p: Math.max(0, Math.min(1, Number(h.p) || 0)), s: (Number(h.s) >>> 0), b: h.b ? 1 : 0 });
    }
    return out;
  }
  /** add one mark (false when the record is full); its seed comes from the record, so the same fight draws the same marks */
  function addHit(rec, family, power, max) {
    if (rec.hits.length >= (max || 12)) return false;
    rec.hits.push({ f: FAMILIES.indexOf(family) >= 0 ? family : 'cut', p: Math.max(0, Math.min(1, Number(power) || 0)), s: sc().mix(rec.seed, rec.hits.length + 1 + rec.gen * 4096), b: 0 });
    return true;
  }
  /** a healing item dresses the worst undressed mark: the strongest, the earliest on a tie. Returns its index or -1 */
  function bandage(rec) {
    var best = -1;
    for (var i = 0; i < rec.hits.length; i++) if (!rec.hits[i].b && (best < 0 || rec.hits[i].p > rec.hits[best].p)) best = i;
    if (best >= 0) rec.hits[best].b = 1;
    return best;
  }
  /** rest: every mark gone (the HP-band wear follows HP by itself) */
  function mend(rec) { rec.hits.length = 0; rec.gen++; }

  /* ------------------------------------------------------------ where a mark lands */
  /**
   * Which surface a hit marks, by its kind and its own seed: a blade grazes skin or tears cloth, fire and frost take the
   * clothing first, a blow bruises skin. A surface the image does not have falls to the next in the list, so every hit
   * marks SOMETHING on every image that has a figure.
   */
  var PREF = {
    cut: [[0.4, 1, 2, 3], [1, 2, 3, 1]], crack: [[0.6, 1, 2, 3], [1, 3, 2, 1]], scorch: [[0.25, 1, 2, 3], [2, 3, 1, 2]],
    rime: [[0.25, 1, 2, 3], [2, 3, 1, 2]], fork: [[0.4, 1, 2, 3], [2, 3, 1, 2]], blight: [[0.6, 1, 2, 3], [2, 1, 3, 2]],
  };
  function surfaceFor(P, hit) {
    var pref = PREF[hit.f] || PREF.cut, r = hash2(hit.s, 7, 11), order = r < pref[0][0] ? pref[0].slice(1) : pref[1].slice(0, 3);
    var minArea = Math.max(6, P.w * P.h * 0.004);
    for (var i = 0; i < order.length; i++) if (P.per[order[i]].area >= minArea) return order[i];
    for (var k = 1; k <= 3; k++) if (P.per[k].area > 0) return k;
    return 0;
  }
  /** the zone of a face cell a mark may land in, per surface (a graze on the cheek and jaw, never the eyes or the hairline) */
  function zoneOf(P, s) {
    if (P.kind !== 'face') return { x0: 0, y0: 0, x1: P.w, y1: P.h };
    // LOOKED AT 2026-10-22 (_out/w2/faces.png): a plaster on the MOUTH read as a cigarette. Skin marks take a cheek: the
    // left or right band beside the nose and mouth, chosen by the hit's own seed
    // (plate 3 LOOKED AT: from 42% down a frost mark sat on an EYE; skin marks start below the eyes)
    if (s === 1) return { x0: P.w * 0.18, y0: P.h * 0.5, x1: P.w * 0.82, y1: P.h * 0.82, gap0: P.w * 0.41, gap1: P.w * 0.59 };
    return { x0: 0, y0: P.S.headY, x1: P.w, y1: P.h };
  }
  /** is (x,y) inside the surface with a margin (a mark centred there has room), at the art's own pixel scale */
  function inset(M, x, y, m) {
    x |= 0; y |= 0;
    for (var dy = -m; dy <= m; dy += Math.max(1, m)) for (var dx = -m; dx <= m; dx += Math.max(1, m)) {
      var X = x + dx, Y = y + dy; if (X < 0 || Y < 0 || X >= M.w || Y >= M.h || !M.mask[Y * M.w + X]) return false;
    }
    return true;
  }
  /**
   * A seeded point on the surface, inside its zone, with room around it, as far as possible from the marks already
   * placed on this image. Deterministic: the same hit seed on the same image always lands in the same place.
   * @returns {{x:number,y:number}|null}
   */
  function place(P, s, hit, placed) {
    var M = P.per[s]; if (!M || !M.area) return null;
    var Z = zoneOf(P, s), r = rng(hit.s ^ (s * 977)), best = null, bestD = -1, found = 0;
    for (var pass = 0; pass < 3 && !best; pass++) {
      var m = pass === 0 ? Math.max(1, Math.round(P.size * 0.035)) : pass === 1 ? 1 : 0;
      for (var t = 0; t < 260 && found < 10; t++) {
        var x = Z.x0 + (Z.x1 - Z.x0) * rand(r), y = Z.y0 + (Z.y1 - Z.y0) * rand(r);
        if (Z.gap0 !== undefined && x > Z.gap0 && x < Z.gap1) continue;
        if (!inset(M, x, y, m)) continue;
        found++;
        var dmin = 1e9;
        for (var k = 0; k < placed.length; k++) { var dx = placed[k].x - x, dy = placed[k].y - y, d = dx * dx + dy * dy; if (d < dmin) dmin = d; }
        if (dmin > bestD) { bestD = dmin; best = { x: x, y: y }; }
      }
    }
    return best;
  }

  /* ------------------------------------------------------------ registering one body across a battler sheet */
  /** the longest run of figure pixels on row y of image P: [left, right] or null */
  function rowSpan(P, y) {
    var w = P.w, fg = P.A.mask, best = null, bl = 0, x = 0;
    y = Math.max(0, Math.min(P.h - 1, y | 0));
    while (x < w) {
      if (!fg[y * w + x]) { x++; continue; }
      var a = x; while (x < w && fg[y * w + x]) x++;
      if (x - a > bl) { bl = x - a; best = [a, x - 1]; }
    }
    return best;
  }
  function colSpan(P, x) {
    var w = P.w, h = P.h, fg = P.A.mask, best = null, bl = 0, y = 0;
    x = Math.max(0, Math.min(w - 1, x | 0));
    while (y < h) {
      if (!fg[y * w + x]) { y++; continue; }
      var a = y; while (y < h && fg[y * w + x]) y++;
      if (y - a > bl) { bl = y - a; best = [a, y - 1]; }
    }
    return best;
  }
  /**
   * A point on the reference cell (the first walk frame) expressed in BODY coordinates: v down the body from the crown
   * (0) to the feet (1), u across the body at that row from its back edge (0) to its front edge (1). The same (u,v) is the
   * same body part in a swing, a guard or a stagger, which is what keeps a mark on the chest in every frame.
   */
  function toBody(R, p) {
    var b = R.A.bbox, v = (p.y - b.y) / Math.max(1, b.h), sp = rowSpan(R, p.y);
    var u = sp ? (p.x - sp[0]) / Math.max(1, sp[1] - sp[0]) : 0.5;
    return { u: Math.max(0, Math.min(1, u)), v: Math.max(0, Math.min(1, v)) };
  }
  /** the body point (u,v) on another cell, standing or lying (the lying rows put the crown at the head end) */
  function fromBody(P, q) {
    var b = P.A.bbox, x, y, sp;
    if (b.w <= 0) return null;
    if (P.S.lying) {
      x = P.S.headRight ? b.x + b.w - 1 - q.v * (b.w - 1) : b.x + q.v * (b.w - 1);
      sp = colSpan(P, x);
      y = sp ? sp[0] + q.u * (sp[1] - sp[0]) : b.y + b.h / 2;
    } else {
      y = b.y + q.v * (b.h - 1);
      sp = rowSpan(P, y);
      x = sp ? sp[0] + q.u * (sp[1] - sp[0]) : b.x + b.w / 2;
    }
    return { x: x, y: y };
  }
  /** nearest pixel of surface s to (x,y) within a small radius, else the nearest figure pixel, else null */
  function snapTo(P, s, x, y) {
    var M = s ? P.per[s] : null, rmax = Math.max(3, Math.round(P.size * 0.25)), fg = P.A.mask;
    for (var rr = 0; rr <= rmax; rr++) for (var dy = -rr; dy <= rr; dy++) for (var dx = -rr; dx <= rr; dx++) {
      if (Math.max(Math.abs(dx), Math.abs(dy)) !== rr) continue;
      var X = (x | 0) + dx, Y = (y | 0) + dy; if (X < 0 || Y < 0 || X >= P.w || Y >= P.h) continue;
      if (M && M.mask[Y * P.w + X]) return { x: X + 0.5, y: Y + 0.5, s: s };
    }
    for (rr = 0; rr <= rmax; rr++) for (dy = -rr; dy <= rr; dy++) for (dx = -rr; dx <= rr; dx++) {
      X = (x | 0) + dx; Y = (y | 0) + dy; if (X < 0 || Y < 0 || X >= P.w || Y >= P.h) continue;
      var i = Y * P.w + X; if (fg[i]) return { x: X + 0.5, y: Y + 0.5, s: P.S.surf[i] };
    }
    return null;
  }

  /* ------------------------------------------------------------ Fray's own marks (pixel operations, clipped to a surface) */
  /** a disc at the art's native pixel scale, clipped to mask M, colour from colFn(x,y) of the CURRENT buffer */
  var INK = [0, 0, 0];
  function ink(r, g, b) { INK[0] = r; INK[1] = g; INK[2] = b; return INK; }
  function dab(out, M, cx, cy, rr, colFn, alpha) {
    var s = M.px || 1, r = Math.max(0.5, rr), x0 = Math.floor(cx - r - 1), x1 = Math.ceil(cx + r + 1), y0 = Math.floor(cy - r - 1), y1 = Math.ceil(cy + r + 1);
    for (var y = y0; y <= y1; y += s) for (var x = x0; x <= x1; x += s) {
      var bx = s > 1 ? Math.floor(x / s) * s : x, by = s > 1 ? Math.floor(y / s) * s : y, dx = bx + s / 2 - cx, dy = by + s / 2 - cy;
      var cov = r + 0.5 - Math.sqrt(dx * dx + dy * dy); if (cov <= 0) continue; if (cov > 1) cov = 1;
      var k = alpha * cov; if (k <= 0) continue; if (k > 1) k = 1;
      for (var yy = 0; yy < s; yy++) for (var xx = 0; xx < s; xx++) {
        var X = bx + xx, Y = by + yy; if (X < 0 || Y < 0 || X >= M.w || Y >= M.h) continue;
        var i = Y * M.w + X; if (!M.mask[i]) continue;
        var o = i * 4, c = colFn(out, o);
        out[o] += (c[0] - out[o]) * k; out[o + 1] += (c[1] - out[o + 1]) * k; out[o + 2] += (c[2] - out[o + 2]) * k;
      }
    }
  }
  function line(out, M, x0, y0, x1, y1, rad, colFn, alpha) {
    var dx = x1 - x0, dy = y1 - y0, L = Math.sqrt(dx * dx + dy * dy), n = Math.max(1, Math.ceil(L / Math.max(0.5, rad * 0.6, (M.px || 1) * 0.5)));
    for (var j = 0; j <= n; j++) dab(out, M, x0 + dx * j / n, y0 + dy * j / n, rad, colFn, alpha);
  }
  /** graze (a blade on skin): three to five short parallel scratches, reddened, over a faint pink halo; no blood runs */
  function graze(out, P, M, pt, hit) {
    // LOOKED AT 2026-10-22 (_out/w1/faces.png): five evenly spaced saturated red dashes read as a "≡" STAMPED on the cheek.
    // An abrasion is a raw PATCH first (skin rubbed red, elongated along the drag), with a few fine scratches of uneven
    // length that are darker skin, not paint, and a scab dot or two
    var r = rng(hit.s), S = P.size, px = M.px || 1, a = -0.9 + rand(r) * 1.8, L = Math.max(3 * px, (0.1 + hit.p * 0.1) * S), n = 2 + (rand(r) * 2.99 | 0);
    var rad = Math.max(0.45 * px, S * 0.0035), ca = Math.cos(a), sa = Math.sin(a), nx = -sa, ny = ca;
    var raw = function (b, o) { return ink(Math.min(255, b[o] * 0.98 + 16), b[o + 1] * 0.74, b[o + 2] * 0.72); };
    for (var j = -3; j <= 3; j++) { var tt = j / 3; dab(out, M, pt.x + ca * L * 0.42 * tt, pt.y + sa * L * 0.42 * tt, L * (0.2 - Math.abs(tt) * 0.08), raw, 0.3); }
    for (var k = 0; k < n; k++) {
      var off = (rand(r) - 0.5) * L * 0.34, len = L * (0.45 + rand(r) * 0.5), sh = (rand(r) - 0.5) * L * 0.35, aj = (rand(r) - 0.5) * 0.16;
      var c2 = Math.cos(a + aj), s2 = Math.sin(a + aj);
      var x0 = pt.x + nx * off - c2 * len / 2 + c2 * sh, y0 = pt.y + ny * off - s2 * len / 2 + s2 * sh;
      // a scratch is broken where the blade skipped: two or three runs along its length
      var runs = 2 + (rand(r) * 1.99 | 0);
      for (var q = 0; q < runs; q++) {
        var t0 = q / runs + rand(r) * 0.1, t1 = (q + 1) / runs - rand(r) * 0.15;
        if (t1 <= t0) continue;
        line(out, M, x0 + c2 * len * t0, y0 + s2 * len * t0, x0 + c2 * len * t1, y0 + s2 * len * t1, rad,
          function (b, o) { return ink(b[o] * 0.66 + 20, b[o + 1] * 0.42, b[o + 2] * 0.42); }, 0.55);
      }
    }
    var dots = 1 + (rand(r) * 2 | 0);
    for (var d = 0; d < dots; d++) dab(out, M, pt.x + (rand(r) - 0.5) * L * 0.5, pt.y + (rand(r) - 0.5) * L * 0.25, Math.max(0.5 * px, S * 0.006), function (b, o) { return ink(b[o] * 0.45 + 14, b[o + 1] * 0.25, b[o + 2] * 0.24); }, 0.7);
  }
  /** bruise (a blow on skin): the skin's own value sunk toward violet in the middle and yellow-green at the rim */
  /** core and rim inks per bruise kind: a blow (violet core, yellow-green rim), sickness (olive-green core, violet rim),
   *  a lightning flash (raw red core, pale blistered rim) */
  // LOOKED AT 2026-10-22 (_out/mbm_aldric.png, mark by mark): a core tint MULTIPLYING the pixel kept the skin's own red,
  // so a bruise read as a MAGENTA paint smear. The core is built from the pixel's LUMA (cl) with only a little of its own
  // colour (co): a dusky bruise on any skin tone, never a hue the skin cannot take. target = l*cl + pixel*co + ca
  var BRUISE = {
    // (Delphine LOOKED AT: at 0.72 the blow read as a pale LAVENDER wash on light skin; deeper and stronger)
    blow: { cl: [0.36, 0.28, 0.44], co: 0.22, ca: [6, 4, 14], m: [0.95, 0.97, 0.8], ma: [0, 5, 0], k: 0.86 },
    burn: { cl: [0.55, 0.34, 0.26], co: 0.4, ca: [16, 2, 0], m: [1.02, 0.96, 0.92], ma: [10, 4, 2], k: 0.75 },
    singe: { cl: [0.3, 0.24, 0.2], co: 0.3, ca: [8, 4, 2], m: [1.0, 0.96, 0.9], ma: [14, 6, 0], k: 0.8 },
    stain: { cl: [0.3, 0.34, 0.22], co: 0.35, ca: [4, 8, 2], m: [0.96, 0.98, 0.9], ma: [0, 4, 0], k: 0.78 },
    sick: { cl: [0.4, 0.46, 0.3], co: 0.3, ca: [6, 12, 2], m: [0.94, 0.86, 0.98], ma: [4, 0, 8], k: 0.72 },
    // (plate 4 LOOKED AT: at k 0.7 the flash burn was barely there; a raw red, stronger)
    flash: { cl: [0.6, 0.3, 0.24], co: 0.38, ca: [16, 0, 0], m: [0.98, 0.94, 0.9], ma: [8, 4, 2], k: 0.86 },
    dent: { cl: [0.45, 0.45, 0.48], co: 0.25, ca: [0, 0, 4], m: [1.14, 1.14, 1.12], ma: [16, 16, 16], k: 0.75 },
    // frost on a painted portrait: a pale cool coat that keeps the form under it (ScatheCore's sparkle needles, crisp on
    // pixel art, read as NOISE at portrait scale)
    frost: { cl: [0.78, 0.86, 0.96], co: 0.15, ca: [40, 52, 70], m: [1.0, 1.02, 1.08], ma: [6, 10, 16], k: 0.62 },
    // frost on SKIN (plate 3 LOOKED AT: the cloth coat on a cheek was an opaque blue blob): a cold blue-white bloom
    frostSkin: { cl: [0.8, 0.88, 0.98], co: 0.3, ca: [26, 34, 50], m: [0.98, 1.0, 1.04], ma: [0, 4, 8], k: 0.4 },
  };
  function bruise(out, P, M, pt, hit, kind) {
    var T = BRUISE[kind || 'blow'];
    var r = rng(hit.s), S = P.size, R = Math.max(2 * (M.px || 1), (0.05 + hit.p * 0.07) * S), ang = rand(r) * Math.PI, asp = 1.15 + rand(r) * 0.35;
    var ca = Math.cos(ang), sa = Math.sin(ang), x0 = Math.max(0, Math.floor(pt.x - R * 1.8)), x1 = Math.min(M.w - 1, Math.ceil(pt.x + R * 1.8));
    var y0 = Math.max(0, Math.floor(pt.y - R * 1.8)), y1 = Math.min(M.h - 1, Math.ceil(pt.y + R * 1.8)), s = M.px || 1, sd = hit.s | 0;
    for (var y = y0; y <= y1; y++) for (var x = x0; x <= x1; x++) {
      var i = y * M.w + x; if (!M.mask[i]) continue;
      var bx = Math.floor(x / s) * s, by = Math.floor(y / s) * s, dx = bx - pt.x, dy = by - pt.y, u = (dx * ca + dy * sa) / asp, v = -dx * sa + dy * ca;
      var d = Math.sqrt(u * u + v * v) / (R * (0.75 + noise(bx, by, Math.max(2, R * 0.5), sd) * 0.5));
      if (d >= 1.35) continue;
      var o = i * 4, core = d < 1 ? Math.pow(1 - d, 0.8) : 0, rim = Math.max(0, 1 - Math.abs(d - 1.0) / 0.35) * 0.5;
      var mot = noise(bx, by, Math.max(2, R * 0.22), sd + 5) * 0.25 + 0.75;
      if (core > 0) {
        var k = Math.min(T.k, core * 0.95) * mot, l0 = 0.2126 * out[o] + 0.7152 * out[o + 1] + 0.0722 * out[o + 2];
        out[o] += (l0 * T.cl[0] + out[o] * T.co + T.ca[0] - out[o]) * k; out[o + 1] += (l0 * T.cl[1] + out[o + 1] * T.co + T.ca[1] - out[o + 1]) * k; out[o + 2] += (l0 * T.cl[2] + out[o + 2] * T.co + T.ca[2] - out[o + 2]) * k;
      }
      if (rim > 0) { var q = rim * mot; out[o] += (out[o] * T.m[0] + T.ma[0] - out[o]) * q; out[o + 1] += (out[o + 1] * T.m[1] + T.ma[1] - out[o + 1]) * q; out[o + 2] += (out[o + 2] * T.m[2] + T.ma[2] - out[o + 2]) * q; }
    }
  }
  /** tear (a blade on cloth): a ragged opening onto a darker under-layer, threads across it, a lit lip and a shadow lip */
  function tear(out, P, M, pt, hit, scale) {
    var r = rng(hit.s), S = P.size, px = M.px || 1, a = -0.7 + rand(r) * 1.4 + (rand(r) < 0.5 ? 0 : Math.PI / 2);
    var L = Math.max(4 * px, (0.12 + hit.p * 0.16) * S * (scale || 1)), Wd = Math.max(1.5 * px, (0.025 + hit.p * 0.035) * S * (scale || 1));
    var ca = Math.cos(a), sa = Math.sin(a), nx = -sa, ny = ca, steps = Math.max(6, Math.ceil(L / Math.max(0.7, px)));
    var under = function (b, o) { return ink(b[o] * 0.3 + 6, b[o + 1] * 0.28 + 5, b[o + 2] * 0.3 + 6); };
    var lit = function (b, o) { return ink(Math.min(255, b[o] * 1.18 + 22), Math.min(255, b[o + 1] * 1.18 + 20), Math.min(255, b[o + 2] * 1.16 + 18)); };
    var shade = function (b, o) { return ink(b[o] * 0.6, b[o + 1] * 0.6, b[o + 2] * 0.62); };
    var thread = function (b, o) { return ink(Math.min(255, b[o] * 1.05 + 30), Math.min(255, b[o + 1] * 1.05 + 28), Math.min(255, b[o + 2] * 1.05 + 26)); };
    var rag = 1;
    for (var j = 0; j <= steps; j++) {
      var t = j / steps, wv = Wd * Math.pow(Math.sin(Math.PI * t), 0.7);
      rag = rag * 0.5 + (0.55 + rand(r) * 0.9) * 0.5;
      var cx = pt.x + ca * L * (t - 0.5), cy = pt.y + sa * L * (t - 0.5), hw = Math.max(0.5 * px, wv * rag);
      // shadow lip below, lit lip above (light comes from the top of the image), the open under-layer between them
      dab(out, M, cx + nx * (hw + px * 0.7), cy + ny * (hw + px * 0.7), Math.max(0.5 * px, px * 0.8), ny > 0 ? shade : lit, 0.55);
      dab(out, M, cx - nx * (hw + px * 0.7), cy - ny * (hw + px * 0.7), Math.max(0.5 * px, px * 0.8), ny > 0 ? lit : shade, 0.55);
      dab(out, M, cx, cy, hw, under, 0.95);
      // a loose thread now and then, stretched across the opening in the cloth's own colour
      if (hw > px && rand(r) < 0.18) line(out, M, cx - nx * hw * 1.2, cy - ny * hw * 1.2, cx + nx * hw * 1.2 + ca * px, cy + ny * hw * 1.2 + sa * px, Math.max(0.4, px * 0.4), thread, 0.7);
    }
  }
  /**
   * A dressing over a mark: on skin a sticking plaster (a pale strip with a padded middle, cut square, a soft shadow),
   * on cloth or armour a wrapped bandage band across the figure. Coloured from a fixed linen hue SHADED by the pixels under
   * it, so it sits in the scene's light rather than glowing.
   */
  function dressing(out, P, pt, hit, s) {
    var M = s === 1 ? P.per[1] : P.A, r = rng(hit.s + 99), S = P.size, px = M.px || 1;
    // LOOKED AT 2026-10-22: a plaster at 0.55 + l/200 glowed near-white on a dark painted face, and a cloth wrap with a
    // pad-coloured checker weave on a portrait read as a glitch block. The linen is lit BY the pixel under it (dimmer on
    // shadowed skin), and the weave is a faint second linen tone, never the pad colour
    // (2026-10-22, plate 4 LOOKED AT: lit by the ALBEDO under it, a bandage on a dark coat went dark grey. Linen is pale
    // whatever it covers; only the scene's light may dim it, so the pixel underneath moves it a little, never a lot)
    var linen = function (b, o) { var l = 0.2126 * b[o] + 0.7152 * b[o + 1] + 0.0722 * b[o + 2], k = 0.7 + Math.min(1, l / 220) * 0.22; return ink(232 * k, 222 * k, 200 * k); };
    var pad = function (b, o) { var l = 0.2126 * b[o] + 0.7152 * b[o + 1] + 0.0722 * b[o + 2], k = 0.66 + Math.min(1, l / 220) * 0.2; return ink(212 * k, 184 * k, 150 * k); };
    var weaveTone = function (b, o) { var l = 0.2126 * b[o] + 0.7152 * b[o + 1] + 0.0722 * b[o + 2], k = 0.64 + Math.min(1, l / 220) * 0.22; return ink(224 * k, 212 * k, 188 * k); };
    var shadow = function (b, o) { return ink(b[o] * 0.62, b[o + 1] * 0.6, b[o + 2] * 0.6); };
    if (s !== 1 && P.kind === 'face') {
      // on a portrait's clothing: three turns of a narrow bandage crossing the mark on a slant, a shadow line between turns
      // (2026-10-22: clipped to a painted scarf's PATCHY cloth mask the wrap broke into white flecks; it wraps the figure)
      var M2 = P.body && P.body.area ? P.body : P.A, ang = 0.35 + rand(r) * 0.3, cl = Math.cos(ang), sl = Math.sin(ang), Lb = S * 0.3, wb = Math.max(1, S * 0.022);
      for (var turn = -1; turn <= 1; turn++) {
        var ox = -sl * turn * wb * 2.3, oy = cl * turn * wb * 2.3, nn = Math.ceil(Lb / 0.8);
        for (var jj = 0; jj <= nn; jj++) { var tb = jj / nn - 0.5; dab(out, M2, pt.x + ox + cl * Lb * tb + 0.8, pt.y + oy + sl * Lb * tb + 1, wb, shadow, 0.35); }
        for (jj = 0; jj <= nn; jj++) { tb = jj / nn - 0.5; dab(out, M2, pt.x + ox + cl * Lb * tb, pt.y + oy + sl * Lb * tb, wb, (jj & 3) === 0 ? weaveTone : linen, 0.92); }
      }
      return;
    }
    if (s === 1) {
      var a = -0.8 + rand(r) * 1.6, L = Math.max(4 * px, S * 0.17), Wd = Math.max(1.5 * px, S * 0.05), ca = Math.cos(a), sa = Math.sin(a), n = Math.max(6, Math.ceil(L / Math.max(0.7, px)));
      for (var j = 0; j <= n; j++) { var t = j / n - 0.5; dab(out, M, pt.x + ca * L * t + px * 0.8, pt.y + sa * L * t + px * 0.9, Wd * 0.55, shadow, 0.4); }
      for (j = 0; j <= n; j++) { t = j / n - 0.5; dab(out, M, pt.x + ca * L * t, pt.y + sa * L * t, Wd * 0.5, Math.abs(t) < 0.18 ? pad : linen, 0.96); }
    } else {
      // the wrap runs across the figure at the mark: a band two to four native pixels deep, its weave every other pixel
      var b = P.A.bbox, horizontal = !(P.S && P.S.lying), half = Math.max(px, S * 0.045);
      var y0 = Math.max(0, Math.floor(pt.y - half)), y1 = Math.min(P.h - 1, Math.ceil(pt.y + half)), x0 = Math.max(0, Math.floor(pt.x - half)), x1 = Math.min(P.w - 1, Math.ceil(pt.x + half));
      var lo = horizontal ? y0 : x0, hi = horizontal ? y1 : x1, sp = horizontal ? rowSpan(P, pt.y) : colSpan(P, pt.x);
      if (!sp) return;
      var reach = Math.max(2 * px, S * 0.22);
      var a0 = Math.max(sp[0], (horizontal ? pt.x : pt.y) - reach), a1 = Math.min(sp[1], (horizontal ? pt.x : pt.y) + reach);
      for (var q = lo; q <= hi; q++) for (var p2 = Math.floor(a0); p2 <= Math.ceil(a1); p2++) {
        var X = horizontal ? p2 : q, Y = horizontal ? q : p2; if (X < 0 || Y < 0 || X >= P.w || Y >= P.h) continue;
        var i = Y * P.w + X; if (!P.A.mask[i]) continue;
        var o = i * 4, edge = q === lo || q === hi, weave = ((Math.floor(p2 / px) + Math.floor(q / px)) & 1) === 0;
        var c = edge ? shadow(out, o) : weave ? linen(out, o) : weaveTone(out, o);
        out[o] = c[0]; out[o + 1] = c[1]; out[o + 2] = c[2];
      }
      void b;
    }
  }

  /** a row of the figure at least half its widest row (a coat hem, not a leg); memoised per image */
  function wideRow(P, y) {
    if (!P._wide) {
      var w = P.w, h = P.h, widths = new Int16Array(h), mx = 0;
      for (var yy = 0; yy < h; yy++) { var sp = rowSpan(P, yy); widths[yy] = sp ? sp[1] - sp[0] + 1 : 0; if (widths[yy] > mx) mx = widths[yy]; }
      P._wide = new Uint8Array(h);
      for (yy = 0; yy < h; yy++) P._wide[yy] = widths[yy] >= mx * 0.5 ? 1 : 0;
      void w;
    }
    return P._wide[y] === 1;
  }

  /* ------------------------------------------------------------ the HP-band look */
  /**
   * The whole figure one step more spent per band: skin drains toward a cold pallor, grime sinks into skin and cloth in
   * patches from band 2, and at band 3 a battler's clothing frays at its hem (notches cut into the outline of the lowest
   * quarter of the cloth). A painted face never gets a hole: its band 3 is deeper grime and a shadow round the face.
   */
  function bandLook(out, P, band, seed) {
    if (band <= 0) return;
    var n = P.w * P.h, S = P.S, A = P.A, gs = Math.max(3, P.size * 0.11), i, x, y, o;
    var hemY = A.bbox.y + A.bbox.h * 0.74, chip = Math.max(1, A.px || 1);
    for (i = 0; i < n; i++) {
      if (!A.mask[i]) continue;
      o = i * 4; x = i % P.w; y = (i / P.w) | 0;
      var s = S.surf[i];
      if (s === 1) {
        var l = 0.2126 * out[o] + 0.7152 * out[o + 1] + 0.0722 * out[o + 2], k = 0.11 * band;
        out[o] += (l * 0.98 - out[o]) * k; out[o + 1] += (l * 1.0 - out[o + 1]) * k; out[o + 2] += (l * 1.04 + 4 - out[o + 2]) * k;
        // (2026-10-22: a band-3 shadow along the figure's outline made a stock face's ear read as cut out; removed. Band 3
        // is the deepest pallor plus band-2 grime at its heaviest)
      }
      // grime: faint from band 1 (MEASURED 2026-10-22: a face with no skin, a monster, showed NOTHING at band 1 when band 1
      // was pallor alone), heavier each band after
      if (s) {
        var g = noise(x, y, gs, seed + 31) - 0.5;
        if (g > 0) { var gk = Math.min(1, g * 4) * (band === 1 ? 0.07 : 0.16 * (band - 1)); out[o] *= 1 - gk; out[o + 1] *= 1 - gk * 1.1; out[o + 2] *= 1 - gk * 1.2; }
      }
      // LOOKED AT 2026-10-22 (_out/w1/svz_warrior.png): fraying every cloth pixel of the lowest quarter cut holes in the
      // TROUSER LEGS (narrow cloth) and the legs read as broken. A hem is WIDE cloth: only rows at least half the figure's
      // width fray, and never deeper than two native pixels
      if (band >= 3 && P.kind === 'cell' && s === 2 && !S.lying && y > hemY && A.dist[i] < 2.2 * chip && wideRow(P, y)) {
        var nb = noise(x, y, Math.max(2, P.size * 0.12), seed + 41);
        if (nb > 0.58 && A.dist[i] < (nb - 0.58) * 10 * chip) out[o + 3] = 0;
      }
    }
  }

  /* ------------------------------------------------------------ bake */
  var SC_MAT = { 1: 'flesh', 2: 'flesh', 3: 'metal' };
  /** draw one hit at a point on one surface: Fray's own mark where it has one, else ScatheCore's family, CALLED */
  function drawHit(out, P, s, pt, hit) {
    var M = P.per[s], f = hit.f;
    if (s === 1 && f === 'cut') return graze(out, P, M, pt, hit);
    if (s === 1 && f === 'crack') return bruise(out, P, M, pt, hit, 'blow');
    // LOOKED AT 2026-10-22: ScatheCore's lightning fern and blight veins on a CHEEK read as purple ink drawn on a face.
    // On skin, lightning leaves a raw flash burn and blight a sick bruise; on cloth and armour they keep Scathe's look
    if (s === 1 && f === 'fork') return bruise(out, P, M, pt, hit, 'flash');
    if (s === 1 && f === 'blight') return bruise(out, P, M, pt, hit, 'sick');
    // MEASURED 2026-10-22 (core.test, 136 faces): ScatheCore's crack walk finds no room on a thin strip of armour (a collar,
    // a pauldron edge) and drew NOTHING in 6 faces. A blow on armour is a DENT: a dark hollow with a lit rim
    if (s === 3 && f === 'crack') return bruise(out, P, M, pt, hit, 'dent');
    // LOOKED AT 2026-10-22 (_out/mbm_delphine2.png): at PORTRAIT scale ScatheCore's families, tuned for 300 px battlers,
    // charred a cheek into a brown-black square and struck lightning as striped glitches. On a face every family but
    // scorch on clothing is Fray's own soft mark; battlers (pixel art) keep Scathe's crisp ones
    if (P.kind === 'face') {
      if (f === 'rime') return bruise(out, P, M, pt, hit, s === 1 ? 'frostSkin' : 'frost');
      if (s === 1 && f === 'scorch') return bruise(out, P, M, pt, hit, 'burn');
      if (s !== 1 && f === 'fork') return bruise(out, P, M, pt, hit, 'singe');
      if (s !== 1 && f === 'blight') return bruise(out, P, M, pt, hit, 'stain');
    }
    if (s === 2 && f === 'cut') return tear(out, P, M, pt, hit, 1);
    if (s === 2 && f === 'crack') return tear(out, P, M, pt, hit, 0.6);
    // ScatheCore draws scorch, rime, fork, blight (and cuts and cracks on armour) on THIS surface only; on skin at a
    // gentler power, so a fireball reddens and blisters a cheek rather than charring it black
    var pw = s === 1 ? hit.p * 0.65 : hit.p;
    var res = sc().bake(M, out, { band: 0, seed: hit.s, hits: [{ family: f, x: pt.x, y: pt.y, power: pw, seed: hit.s }] }, SC_MAT[s]);
    for (var i = 0; i < out.length; i++) out[i] = res[i];
  }
  /**
   * The worn picture of one image: a NEW RGBA buffer from the clean source, the band look, then every hit at its place
   * on its surface, in order, then the dressings. `points` (optional) gives each hit's point for a battler cell, from the
   * sheet's reference cell, so a mark stays on the same body part in every frame. Pure: the same inputs, the same pixels.
   * @param {Object} P prepare() result   @param {Object} rec the record   @param {number} band 0..3
   * @param {Array<{u:number,v:number}>|null} [body] the hits' body coordinates (battler cells)
   * @returns {{rgba:Uint8ClampedArray, placed:Array}}
   */
  function bake(P, rec, band, body) {
    var out = new Uint8ClampedArray(P.src.length), i;
    for (i = 0; i < out.length; i++) out[i] = P.src[i];
    if (!P.A.area) return { rgba: out, placed: [] };
    bandLook(out, P, band | 0, rec.seed | 0);
    var placed = [];
    for (i = 0; i < rec.hits.length; i++) markOne(out, P, rec, i, body, placed);
    dressAll(out, P, rec, placed);
    return { rgba: out, placed: placed };
  }
  /**
   * The dressings of a record. On a FACE every dressing is a plaster on a cheek: a dressed mark that landed on clothing
   * takes its plaster on the nearest cheek point instead (LOOKED AT 2026-10-22: a bandage wrapped on a painted pauldron
   * read as white glitch stripes). A face with no skin found gets no plaster.
   */
  function dressAll(out, P, rec, placed) {
    var used = [];
    for (var i = 0; i < rec.hits.length && i < placed.length; i++) {
      if (!rec.hits[i].b || !placed[i]) continue;
      var pt = placed[i], s = pt.s;
      if (P.kind === 'face' && s !== 1) { pt = P.per[1].area ? place(P, 1, rec.hits[i], used) : null; s = 1; }
      if (!pt) continue;
      used.push(pt);
      dressing(out, P, pt, rec.hits[i], s);
    }
  }
  /** hit i of the record at its place on its surface, appended to `placed` (null when it lands on nothing) */
  function markOne(out, P, rec, i, body, placed) {
    var hit = rec.hits[i], s = surfaceFor(P, hit), pt = null;
    if (!s) { placed.push(null); return; }
    if (body && body[i]) { var q = fromBody(P, body[i]); if (q) { var sn = snapTo(P, s, q.x, q.y); if (sn) { pt = sn; s = sn.s || s; } } }
    else pt = place(P, s, hit, placed.filter(Boolean));
    if (!pt || !s || !P.per[s].area) { placed.push(null); return; }
    drawHit(out, P, s, pt, hit);
    placed.push({ x: pt.x, y: pt.y, s: s });
  }
  function dressedOf(rec) { var d = 0; for (var i = 0; i < rec.hits.length; i++) if (rec.hits[i].b) d++; return d; }
  /**
   * The same picture as bake(), reusing the previous result when only NEW marks arrived (same band, same generation, the
   * same dressings): the new marks are drawn onto the last picture, never a re-bake of every mark. MEASURED 2026-10-22
   * (mz_gate gate_party_autohit): a full re-bake of 54 battler cells per hit kept the battle's bake queue busy and the
   * update half over its 2 ms mean. Without dressings the result is byte-identical to bake() (core.test asserts it); with
   * a dressing on, a new mark lands on top of the dressing until the next full bake.
   * @param {Object|null} prev the `work` of the last call for this image
   * @returns {{rgba:Uint8ClampedArray, placed:Array, work:Object, added:number}} added = -1 for a full bake
   */
  /**
   * A full bake in SLICES, for an engine that must stay inside a frame budget (MEASURED 2026-10-22: a full face bake with
   * six marks is ~2.5 ms warm in Node, each ScatheCore family ~1 ms, and as ONE job it was the battle's p99 frame).
   * begin = the band look; more = the next `count` marks; finish = the dressings. The result equals bake() exactly
   * (core.test asserts it). Returns the same `work` shape bakeStep() uses.
   */
  function bakeBegin(P, rec, band) {
    var out = new Uint8ClampedArray(P.src.length);
    for (var i = 0; i < out.length; i++) out[i] = P.src[i];
    if (P.A.area) bandLook(out, P, band | 0, rec.seed | 0);
    return { band: band, gen: rec.gen, dressed: 0, n: 0, rgba: out, placed: [], open: true };
  }
  function bakeMore(P, rec, body, work, count) {
    var end = Math.min(rec.hits.length, work.n + (count || 1));
    if (P.A.area) for (var i = work.n; i < end; i++) markOne(work.rgba, P, rec, i, body, work.placed);
    else for (i = work.n; i < end; i++) work.placed.push(null);
    work.n = end;
    return work.n >= rec.hits.length;
  }
  function bakeFinish(P, rec, work) {
    dressAll(work.rgba, P, rec, work.placed);
    work.dressed = dressedOf(rec); work.open = false;
    return work;
  }
  function bakeStep(P, rec, band, body, prev) {
    var d = dressedOf(rec), n = rec.hits.length;
    if (prev && !prev.open && prev.band === band && prev.gen === rec.gen && prev.dressed === d && prev.n <= n && prev.rgba.length === P.src.length && P.A.area) {
      for (var i = prev.n; i < n; i++) markOne(prev.rgba, P, rec, i, body, prev.placed);
      var added = n - prev.n; prev.n = n;
      return { rgba: prev.rgba, placed: prev.placed, work: prev, added: added };
    }
    var r = bake(P, rec, band, body);
    return { rgba: r.rgba, placed: r.placed, work: { band: band, gen: rec.gen, dressed: d, n: n, rgba: r.rgba, placed: r.placed }, added: -1 };
  }

  /* ------------------------------------------------------------ battler sheets (9 x 6 cells, MZ's own layout) */
  var SV_COLS = 9, SV_ROWS = 6;
  function cellPixels(px, W, cw, ch, cx, cy) {
    var out = new Uint8ClampedArray(cw * ch * 4);
    for (var y = 0; y < ch; y++) { var s = ((cy * ch + y) * W + cx * cw) * 4, d = y * cw * 4; for (var k = 0; k < cw * 4; k++) out[d + k] = px[s + k]; }
    return out;
  }
  /**
   * Prepare a whole battler sheet: ONE skin model from the first walk frame, applied to all 54 cells, so a mark never
   * changes surface between frames. Returns the cells and the reference cell (walk, frame 1).
   */
  function prepareSheet(px, W, H) {
    var cw = Math.floor(W / SV_COLS), ch = Math.floor(H / SV_ROWS);
    var ref0 = cellPixels(px, W, cw, ch, 1, 0), S0 = surfaces(ref0, cw, ch, { kind: 'cell' });
    var chibi = S0.bbox.h < S0.bbox.w * 1.8, model = S0.skinModel, cells = [];
    for (var cy = 0; cy < SV_ROWS; cy++) for (var cx = 0; cx < SV_COLS; cx++) {
      cells.push({ cx: cx, cy: cy, P: prepare(cellPixels(px, W, cw, ch, cx, cy), cw, ch, 'cell', { skin: model, chibi: chibi }) });
    }
    return { W: W, H: H, cw: cw, ch: ch, cells: cells, ref: cells[1], model: model, chibi: chibi };
  }
  /** the body coordinates of every hit, placed on the reference cell (deterministic from each hit's seed) */
  function bodyPoints(sheet, rec) {
    var R = sheet.ref.P, placed = [], out = [];
    for (var i = 0; i < rec.hits.length; i++) {
      var hit = rec.hits[i], s = surfaceFor(R, hit), pt = s ? place(R, s, hit, placed) : null;
      if (pt) placed.push(pt);
      out.push(pt ? toBody(R, pt) : null);
    }
    return out;
  }
  /** bake one cell of a sheet (the engine bakes cells a few per frame; Node bakes all of them) */
  function bakeCell(sheet, index, rec, band, body) { return bake(sheet.cells[index].P, rec, band, body || bodyPoints(sheet, rec)); }
  /** bake every cell into one RGBA sheet the size of the source */
  function bakeSheet(sheet, rec, band) {
    var out = new Uint8ClampedArray(sheet.W * sheet.H * 4), body = bodyPoints(sheet, rec);
    for (var c = 0; c < sheet.cells.length; c++) {
      var cell = sheet.cells[c], r = bake(cell.P, rec, band, body).rgba;
      for (var y = 0; y < sheet.ch; y++) { var d = ((cell.cy * sheet.ch + y) * sheet.W + cell.cx * sheet.cw) * 4, s = y * sheet.cw * 4; for (var k = 0; k < sheet.cw * 4; k++) out[d + k] = r[s + k]; }
    }
    return out;
  }

  return {
    VERSION: '1.0.0', SURF: SURF, FAMILIES: FAMILIES, RECORD_VERSION: RECORD_VERSION, SV_COLS: SV_COLS, SV_ROWS: SV_ROWS,
    surfaces: surfaces, prepare: prepare, prepareSheet: prepareSheet, cellPixels: cellPixels, bake: bake, bakeStep: bakeStep, bakeBegin: bakeBegin, bakeMore: bakeMore, bakeFinish: bakeFinish, dressedOf: dressedOf, bakeCell: bakeCell, bakeSheet: bakeSheet,
    bodyPoints: bodyPoints, toBody: toBody, fromBody: fromBody, place: place, surfaceFor: surfaceFor,
    newRecord: newRecord, normalise: normalise, addHit: addHit, bandage: bandage, mend: mend,
    hsv: hsv, skinish: skinish, sc: sc,
    /** test seam: draw one hit at a given point on a given surface (the tests clip-check each family alone) */
    __drawHit: drawHit,
  };
})();
if (typeof module === 'object' && module.exports) module.exports = FrayCore;
