//=============================================================================
// Tilestack.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Tilestack: mahjong solitaire as a minigame. Generated layouts, drawn tile sets, every deal solvable.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * Recommended order: TilestackCore.js, TilestackDraw.js, Tilestack.js (this
 * file). Any order works: the files find each other when the first game opens.
 * RPG Maker MV 1.6: also CSAF_MVBridge.js at the TOP of the list. In MV the
 * command is a Plugin Command line:
 *   Tilestack start layout=turtle set=jade seed=7
 *   Tilestack start layout=generated tiles=72 set=lacquer
 * Script call (MZ and MV):
 *   CSAF.Tilestack.start({ layout: 'generated', tiles: 72, set: 'ivory', seed: 7 })
 *
 * Remove two FREE tiles that match: a tile is free when nothing lies on it and
 * its left or right side is open. Any flower matches any flower, and any season
 * any season. Clear the board to win. Every deal can be cleared.
 *
 * Mouse or touch: click a free tile, then its match. Keyboard: the arrows move
 * between free tiles, OK picks, Q (Page Up) shows a hint, W (Page Down) undoes
 * the last pair. If no pair is left, OK shuffles the tiles still on the board
 * (while shuffles last). Cancel sets the game aside.
 *
 * Results are written as the game closes, before the event continues: seconds
 * and moves into variables, a switch ON when cleared (OFF when set aside), and
 * an optional common event. CSAF.Tilestack.lastResult() returns
 * { layout, tiles, cleared, left, seconds, moves, hints, shuffles, seed }.
 *
 * @param varSeconds
 * @text Seconds -> variable
 * @type variable
 * @default 0
 *
 * @param varMoves
 * @text Moves -> variable
 * @type variable
 * @default 0
 *
 * @param swCleared
 * @text Cleared -> switch
 * @type switch
 * @default 0
 *
 * @param commonEvent
 * @text Common event afterwards
 * @type common_event
 * @default 0
 *
 * @param defaultSet
 * @text Default tile set
 * @type select
 * @option ivory
 * @option bone
 * @option jade
 * @option lacquer
 * @option porcelain
 * @default ivory
 *
 * @command start
 * @text Start a game
 * @desc Deal a mahjong solitaire game and let the player clear it.
 *
 * @arg layout
 * @text Layout
 * @type select
 * @option turtle
 * @option generated
 * @default turtle
 *
 * @arg tiles
 * @text About how many tiles (generated)
 * @type number
 * @min 8
 * @max 144
 * @default 72
 *
 * @arg set
 * @text Tile set
 * @desc Blank = the Default tile set parameter.
 * @type select
 * @option
 * @option ivory
 * @option bone
 * @option jade
 * @option lacquer
 * @option porcelain
 * @default
 *
 * @arg hints
 * @text Hints allowed
 * @type number
 * @min 0
 * @max 99
 * @default 3
 *
 * @arg shuffles
 * @text Shuffles allowed
 * @type number
 * @min 0
 * @max 9
 * @default 2
 *
 * @arg seed
 * @text Seed
 * @desc Blank = a new deal every time. A number or word deals the same game every time.
 * @type string
 * @default
 */

var CSAF = CSAF || {};

(function () {
  'use strict';
  var NAME = 'Tilestack';
  var RAW = PluginManager.parameters(NAME);
  function num(v, d) { var s = String(v === undefined || v === null ? '' : v).trim(); if (s === '') return d; var n = Number(s); return isFinite(n) ? n : d; }
  var SETNAMES = ['ivory', 'bone', 'jade', 'lacquer', 'porcelain'];
  var P = { varSeconds: num(RAW.varSeconds, 0), varMoves: num(RAW.varMoves, 0), swCleared: num(RAW.swCleared, 0), commonEvent: num(RAW.commonEvent, 0), defaultSet: SETNAMES.indexOf(String(RAW.defaultSet)) >= 0 ? String(RAW.defaultSet) : 'ivory' };
  /** Siblings resolved at first use: the buyer chooses the load order. */
  function deps() {
    var C = CSAF.TilestackCore, D = CSAF.TilestackDraw;
    if (!C || !D) throw new Error('Tilestack needs TilestackCore.js and TilestackDraw.js installed and ON.');
    return { core: C, draw: D };
  }
  var FONT = 'Georgia, "Palatino Linotype", "Book Antiqua", Palatino, "Times New Roman", serif';
  function uiScale() { return Math.max(1, Math.min(3, Math.min(Graphics.width, Graphics.height) / 624)); }
  function rec() { if (!$gameSystem._csafTilestack) $gameSystem._csafTilestack = { v: 1, count: 0, last: null }; return $gameSystem._csafTilestack; }

  var pending = null;
  function start(args) {
    args = args || {};
    var r = rec(), seedText = String(args.seed === undefined || args.seed === null ? '' : args.seed).trim();
    var layout = String(args.layout || 'turtle').trim() === 'generated' ? 'generated' : 'turtle';
    var setName = String(args.set || '').trim(); if (SETNAMES.indexOf(setName) < 0) setName = P.defaultSet;
    pending = {
      layout: layout, tiles: Math.max(8, Math.min(144, num(args.tiles, 72))), set: setName,
      hints: Math.max(0, Math.min(99, num(args.hints, 3))), shuffles: Math.max(0, Math.min(9, num(args.shuffles, 2))),
      seed: seedText !== '' ? seedText : ('t' + r.count + 'm' + ($gameMap ? $gameMap.mapId() : 0) + 'f' + Graphics.frameCount)
    };
    SceneManager.push(Scene_Tilestack);
    return true;
  }
  // MV has no registerCommand until CSAF_MVBridge.js has loaded: say so instead of throwing at boot
  if (typeof PluginManager.registerCommand === 'function') PluginManager.registerCommand(NAME, 'start', function (args) { start(args); });
  else console.warn('Tilestack: in RPG Maker MV, put CSAF_MVBridge.js at the TOP of the plugin list, above the Tilestack files. The script call CSAF.Tilestack.start({...}) still works.');

  //---------------------------------------------------------------------------
  function Scene_Tilestack() { this.initialize.apply(this, arguments); }
  Scene_Tilestack.prototype = Object.create(Scene_Base.prototype);
  Scene_Tilestack.prototype.constructor = Scene_Tilestack;

  Scene_Tilestack.prototype.initialize = function () {
    Scene_Base.prototype.initialize.call(this);
    this._req = pending; pending = null;
    this._built = false; this._picked = -1; this._frames = 0; this._done = false; this._doneAge = 0; this._hintsUsed = 0; this._shufflesUsed = 0;
    this._fading = []; this._stuck = false; this._cursor = -1;
  };

  Scene_Tilestack.prototype.start = function () {
    Scene_Base.prototype.start.call(this);
    if (!this._req) { this.popScene(); return; }
    this.build();
  };

  /** Lay out the table and every tile; deal once. */
  Scene_Tilestack.prototype.build = function () {
    var d = deps(), W = Graphics.width, H = Graphics.height, S = uiScale(), req = this._req;
    var tb = new Bitmap(W, H); d.draw.drawTable(tb.context, W, H, { seed: 3 }); tb._baseTexture.update();
    this.addChild(new Sprite(tb));
    this._game = d.core.newGame({ layout: req.layout, tiles: req.tiles, seed: req.seed });
    var g = this._game, T = d.draw.feltInset(W, H), hudH = Math.round(40 * S);
    // fit: the board's extent in half-tile units, plus the layer lift, inside the felt under the plaque
    var minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity, maxZ = 0, i;
    for (i = 0; i < g.pos.length; i++) { var p = g.pos[i]; minX = Math.min(minX, p.x); maxX = Math.max(maxX, p.x + 2); minY = Math.min(minY, p.y); maxY = Math.max(maxY, p.y + 2); maxZ = Math.max(maxZ, p.z); }
    var availW = W - T * 2 - 24, availH = H - T * 2 - hudH - 30, aspect = 1.3, lift = 0.16;
    var tw = Math.min(availW / ((maxX - minX) / 2 + maxZ * lift + lift * 1.6), availH / ((maxY - minY) / 2 * aspect + maxZ * lift + lift * 1.8));
    tw = Math.max(10, Math.floor(tw)); var th = Math.round(tw * aspect), dz = Math.max(2, Math.round(tw * lift)), side = Math.max(2, Math.round(tw * 0.12));
    var boardW = (maxX - minX) / 2 * tw + maxZ * dz, boardH = (maxY - minY) / 2 * th + maxZ * dz;
    var ox = Math.round((W - boardW) / 2 - minX / 2 * tw + maxZ * dz), oy = Math.round(T + hudH + 14 + (availH - boardH) / 2 - minY / 2 * th + maxZ * dz);
    this._tw = tw; this._th = th; this._dz = dz;
    // one sprite per tile, drawn back to front: low layers first, then left to right, top to bottom
    var order = []; for (i = 0; i < g.pos.length; i++) order.push(i);
    order.sort(function (a, b) { return (g.pos[a].z - g.pos[b].z) || (g.pos[a].x - g.pos[b].x) || (g.pos[a].y - g.pos[b].y); });
    this._layer = new Sprite(); this.addChild(this._layer);
    this._sp = new Array(g.pos.length); this._order = order;
    var pad = side * 3 + 4;
    for (var k = 0; k < order.length; k++) {
      var t = order[k], q = g.pos[t];
      var bmp = new Bitmap(tw + pad, th + pad), c = bmp.context;
      d.draw.drawBody(c, 0, 0, tw, th, side, { set: req.set, depthShade: (maxZ - q.z) * 0.06 });
      d.draw.drawFace(c, g.face[t], 0, 0, tw, th, req.set); bmp._baseTexture.update();
      var sp = new Sprite(bmp); sp.x = ox + q.x / 2 * tw - q.z * dz; sp.y = oy + q.y / 2 * th - q.z * dz; sp._tile = t;
      this._layer.addChild(sp); this._sp[t] = sp;
    }
    // highlights: one gold frame for the picked tile, two blue frames for a hint (moved, never redrawn)
    var fb = new Bitmap(tw + 8, th + 8); d.draw.drawFrame(fb.context, tw, th, 'pick'); fb._baseTexture.update();
    this._pickSp = new Sprite(fb); this._pickSp.visible = false; this.addChild(this._pickSp);
    this._hintSp = [];
    for (k = 0; k < 2; k++) { var hb = new Bitmap(tw + 8, th + 8); d.draw.drawFrame(hb.context, tw, th, 'hint'); hb._baseTexture.update(); var hs = new Sprite(hb); hs.visible = false; this.addChild(hs); this._hintSp.push(hs); }
    // the keyboard hand
    var hand = new Bitmap(28, 28), hc = hand.context;
    hc.fillStyle = 'rgba(255,240,205,0.95)'; hc.strokeStyle = 'rgba(40,25,10,0.9)'; hc.lineWidth = 2;
    hc.beginPath(); hc.moveTo(4, 2); hc.lineTo(4, 22); hc.lineTo(10, 16); hc.lineTo(16, 26); hc.lineTo(20, 24); hc.lineTo(14, 14); hc.lineTo(22, 14); hc.closePath(); hc.fill(); hc.stroke(); hand._baseTexture.update();
    this._hand = new Sprite(hand); this._hand.visible = false; this.addChild(this._hand);
    // the plaque
    this._S = S; this._hud = new Sprite(new Bitmap(Math.min(W - T * 2 - 16, Math.round(560 * S)), hudH)); this._hud.x = Math.round((W - this._hud.bitmap.width) / 2); this._hud.y = T + 8; this.addChild(this._hud);
    this._hudKey = -1; this._pairsNow = d.core.matchablePairs(g).length;
    this._free = []; this.refreshFree();
    this._built = true; this.drawHud();
  };

  /** Which tiles are free, refreshed only when the board changes (a move, an undo, a shuffle), never per frame. */
  Scene_Tilestack.prototype.refreshFree = function () { deps().core.freeMask(this._game, this._free); };

  Scene_Tilestack.prototype.drawHud = function () {
    var g = this._game, secs = Math.floor(this._frames / 60), left = deps().core.tilesLeft(g);
    var key = secs * 1e7 + left * 1e4 + g.moves * 10 + (this._stuck ? 1 : 0) + this._hintsUsed * 1e9;
    if (key === this._hudKey) return; this._hudKey = key;
    var b = this._hud.bitmap, w = b.width, h = b.height, c = b.context, S = this._S;
    b.clear(); c.save();
    c.fillStyle = 'rgba(18,12,6,0.66)'; c.beginPath(); c.moveTo(7, 0.5); c.arcTo(w - 0.5, 0.5, w - 0.5, h - 0.5, 7); c.arcTo(w - 0.5, h - 0.5, 0.5, h - 0.5, 7); c.arcTo(0.5, h - 0.5, 0.5, 0.5, 7); c.arcTo(0.5, 0.5, w - 0.5, 0.5, 7); c.closePath(); c.fill();
    c.strokeStyle = 'rgba(232,196,120,0.4)'; c.lineWidth = 1; c.strokeRect(4.5, 4.5, w - 9, h - 9);
    var fill = 1 - left / g.pos.length; c.fillStyle = 'rgba(232,196,120,0.18)'; c.fillRect(10, h - Math.round(8 * S), w - 20, Math.max(2, Math.round(2 * S))); c.fillStyle = 'rgba(240,190,96,0.95)'; c.fillRect(10, h - Math.round(8 * S), Math.round((w - 20) * fill), Math.max(2, Math.round(2 * S)));
    c.restore();
    b.fontFace = FONT; b.outlineWidth = 0;
    var q = Math.floor((w - 24) / 4), mm = Math.floor(secs / 60), ss = secs % 60, y1 = Math.round(2 * S), y2 = Math.round(15 * S), lh = Math.round(18 * S), lh2 = Math.round(20 * S);
    b.fontSize = Math.round(12 * S); b.textColor = 'rgba(240,214,160,0.62)';
    b.drawText('TILES', 12, y1, q, lh, 'left'); b.drawText('TIME', 12 + q, y1, q, lh, 'center'); b.drawText('MOVES', 12 + q * 2, y1, q, lh, 'center'); b.drawText(this._stuck ? 'NO PAIRS' : 'HINTS', 12 + q * 3, y1, q, lh, 'right');
    b.fontSize = Math.round(17 * S); b.textColor = '#f6e6c4';
    b.drawText(String(left), 12, y2, q, lh2, 'left'); b.drawText(mm + ':' + (ss < 10 ? '0' : '') + ss, 12 + q, y2, q, lh2, 'center'); b.drawText(String(g.moves), 12 + q * 2, y2, q, lh2, 'center');
    b.drawText(this._stuck ? (this._shufflesUsed < this._req.shuffles ? 'OK: shuffle' : 'Esc') : String(Math.max(0, this._req.hints - this._hintsUsed)), 12 + q * 3, y2, q, lh2, 'right');
  };

  /** The tile whose FACE is under (x, y), topmost first. No allocation. */
  Scene_Tilestack.prototype.tileAt = function (x, y) {
    var g = this._game;
    for (var k = this._order.length - 1; k >= 0; k--) {
      var t = this._order[k], sp = this._sp[t];
      if (g.face[t] === null || !sp.visible) continue;
      if (x >= sp.x && y >= sp.y && x < sp.x + this._tw && y < sp.y + this._th) return t;
    }
    return -1;
  };

  /** Pick or match a tile (mouse, touch or keyboard). */
  Scene_Tilestack.prototype.choose = function (t) {
    var C = deps().core, g = this._game;
    if (t < 0 || g.face[t] === null) return;
    if (!this._free[t]) { SoundManager.playBuzzer(); return; }
    this.clearHint();
    if (this._picked === t) { this._picked = -1; this._pickSp.visible = false; SoundManager.playCancel(); return; }
    if (this._picked >= 0 && C.matches(g.face[this._picked], g.face[t])) {
      var a = this._picked; this._picked = -1; this._pickSp.visible = false;
      if (C.remove(g, a, t)) { this.fadeOut(a); this.fadeOut(t); SoundManager.playOk(); this.afterMove(); }
      return;
    }
    this._picked = t; this.placeFrame(this._pickSp, t); SoundManager.playCursor();
  };

  Scene_Tilestack.prototype.placeFrame = function (sp, t) { var s = this._sp[t]; sp.x = s.x - 3; sp.y = s.y - 3; sp.visible = true; };
  Scene_Tilestack.prototype.clearHint = function () { this._hintSp[0].visible = this._hintSp[1].visible = false; };
  Scene_Tilestack.prototype.fadeOut = function (t) { this._fading.push(this._sp[t]); };

  Scene_Tilestack.prototype.afterMove = function () {
    var C = deps().core, g = this._game;
    this.refreshFree();
    if (C.isCleared(g)) { this.finish(true); return; }
    this._pairsNow = C.matchablePairs(g).length;
    this._stuck = this._pairsNow === 0;
  };

  Scene_Tilestack.prototype.hint = function () {
    if (this._hintsUsed >= this._req.hints || this._stuck) { SoundManager.playBuzzer(); return; }
    var ps = deps().core.matchablePairs(this._game); if (!ps.length) return;
    this._hintsUsed++; this.placeFrame(this._hintSp[0], ps[0][0]); this.placeFrame(this._hintSp[1], ps[0][1]); SoundManager.playCursor();
  };

  Scene_Tilestack.prototype.undoPair = function () {
    var C = deps().core, g = this._game, h = g.history[g.history.length - 1];
    if (!h || !C.undo(g)) { SoundManager.playBuzzer(); return; }
    var a = this._sp[h[0]], b = this._sp[h[1]];
    // an undo inside the 12-frame fade must stop the fade too, or the tiles hide again when it ends
    for (var f = this._fading.length - 1; f >= 0; f--) if (this._fading[f] === a || this._fading[f] === b) this._fading.splice(f, 1);
    a.visible = b.visible = true; a.opacity = b.opacity = 255; a.y = a._y0 !== undefined ? a._y0 : a.y; b.y = b._y0 !== undefined ? b._y0 : b.y;
    g.moves++; this._picked = -1; this._pickSp.visible = false; this.clearHint(); this.afterMove(); SoundManager.playCancel();
  };

  /** Shuffle the tiles still on the board; redraw only their faces' bitmaps (once, on the shuffle). */
  Scene_Tilestack.prototype.reshuffle = function () {
    var dd = deps(), g = this._game;
    if (this._shufflesUsed >= this._req.shuffles || !dd.core.shuffle(g, this._req.seed + ':' + this._shufflesUsed)) { this.finish(false); return; }
    this._shufflesUsed++;
    var maxZ = 0, i; for (i = 0; i < g.pos.length; i++) maxZ = Math.max(maxZ, g.pos[i].z);
    for (i = 0; i < g.pos.length; i++) {
      if (g.face[i] === null) continue;
      var b = this._sp[i].bitmap, side = Math.max(2, Math.round(this._tw * 0.12));
      b.clear(); dd.draw.drawBody(b.context, 0, 0, this._tw, this._th, side, { set: this._req.set, depthShade: (maxZ - g.pos[i].z) * 0.06 }); dd.draw.drawFace(b.context, g.face[i], 0, 0, this._tw, this._th, this._req.set); b._baseTexture.update();
    }
    this._stuck = false; this._pairsNow = dd.core.matchablePairs(g).length; this.refreshFree(); SoundManager.playOk();
  };

  Scene_Tilestack.prototype.finish = function (cleared) {
    if (this._done) return;
    var g = this._game, secs = Math.floor(this._frames / 60), r = rec(), left = deps().core.tilesLeft(g);
    this._done = true; this._cleared = !!cleared; this._doneAge = 0; this._picked = -1; this._pickSp.visible = false; this.clearHint(); this._hand.visible = false;
    r.count++; r.last = { layout: this._req.layout, tiles: g.pos.length, cleared: this._cleared, left: left, seconds: secs, moves: g.moves, hints: this._hintsUsed, shuffles: this._shufflesUsed, seed: String(this._req.seed) };
    if (P.varSeconds) $gameVariables.setValue(P.varSeconds, secs);
    if (P.varMoves) $gameVariables.setValue(P.varMoves, g.moves);
    if (P.swCleared) $gameSwitches.setValue(P.swCleared, this._cleared);
    if (P.commonEvent) $gameTemp.reserveCommonEvent(P.commonEvent);
    this.drawHud();
    if (this._cleared) this.buildFinale();
    this.buildPlaque(secs, left);
  };

  /**
   * The cleared moment (first look: a plaque on empty felt): a gold ghost of the board's footprint fades in where the
   * tiles stood, and the winning pair rises to the middle, drawn LARGE by the renderer (never magnified). Built once.
   */
  Scene_Tilestack.prototype.buildFinale = function () {
    var dd = deps(), g = this._game, W = Graphics.width, H = Graphics.height, S = this._S;
    var ghost = new Bitmap(W, H), c = ghost.context, i;
    c.save(); c.strokeStyle = 'rgba(240,200,120,0.55)'; c.lineWidth = Math.max(1, S); c.fillStyle = 'rgba(240,200,120,0.07)';
    for (i = 0; i < g.pos.length; i++) { if (g.pos[i].z !== 0) continue; var sp = this._sp[i]; c.fillRect(sp.x + 2, sp.y + 2, this._tw - 4, this._th - 4); c.strokeRect(sp.x + 2.5, sp.y + 2.5, this._tw - 5, this._th - 5); }
    c.restore(); ghost._baseTexture.update();
    this._ghost = new Sprite(ghost); this._ghost.opacity = 0; this.addChildAt(this._ghost, 1);
    var last = g.history[g.history.length - 1]; this._win = [];
    if (last) {
      var big = Math.round(Math.min(W * 0.16, H * 0.22, 140 * S)), bh = Math.round(big * 1.3), side = Math.max(3, Math.round(big * 0.12)), gap = Math.round(big * 0.18);
      for (var k = 0; k < 2; k++) {
        var b = new Bitmap(big + side * 3 + 4, bh + side * 3 + 4);
        dd.draw.drawBody(b.context, 0, 0, big, bh, side, { set: this._req.set }); dd.draw.drawFace(b.context, last[2 + k], 0, 0, big, bh, this._req.set); b._baseTexture.update();
        var w = new Sprite(b), from = this._sp[last[k]];
        w._x0 = from.x; w._y0 = from.y; w._s0 = this._tw / big; w._x1 = Math.round(W / 2 + (k ? gap / 2 : -gap / 2 - big)); w._y1 = Math.round(H / 2 - bh - 30 * S);
        w.x = w._x0; w.y = w._y0; w.scale.x = w.scale.y = w._s0; w.opacity = 0; this.addChild(w); this._win.push(w);
      }
    }
  };

  Scene_Tilestack.prototype.buildPlaque = function (secs, left) {
    var W = Graphics.width, H = Graphics.height, S = this._S, g = this._game, w = Math.min(W - 40, Math.round(380 * S)), h = Math.round(92 * S);
    var b = new Bitmap(w, h), x = b.context;
    x.save(); x.fillStyle = 'rgba(20,12,6,0.9)'; x.fillRect(0, 0, w, h); x.strokeStyle = 'rgba(240,200,120,0.8)'; x.lineWidth = Math.max(1, S); x.strokeRect(4.5 * S, 4.5 * S, w - 9 * S, h - 9 * S);
    x.fillStyle = x.strokeStyle; var gap = (this._cleared ? 96 : 120) * S, fy = 22 * S;
    for (var s = -1; s <= 1; s += 2) { var cx = w / 2 + s * gap; x.beginPath(); x.moveTo(cx, fy); x.lineTo(cx + s * 34 * S, fy); x.stroke(); x.beginPath(); x.moveTo(cx + s * 40 * S, fy); x.lineTo(cx + s * 36 * S, fy - 3 * S); x.lineTo(cx + s * 32 * S, fy); x.lineTo(cx + s * 36 * S, fy + 3 * S); x.closePath(); x.fill(); }
    x.restore();
    b.fontFace = FONT; b.outlineWidth = 0; b.fontSize = Math.round(24 * S); b.textColor = '#f6e2b4';
    b.drawText(this._cleared ? 'C L E A R E D' : 'S E T   A S I D E', 0, Math.round(6 * S), w, Math.round(32 * S), 'center');
    var mm = Math.floor(secs / 60), ss = secs % 60, t = mm + ':' + (ss < 10 ? '0' : '') + ss;
    b.fontSize = Math.round(16 * S); b.textColor = '#ead7b0';
    b.drawText(this._cleared ? (g.pos.length + ' tiles  ·  ' + t + '  ·  ' + g.moves + ' moves') : ((g.pos.length - left) + ' of ' + g.pos.length + ' cleared  ·  ' + t), 0, Math.round(38 * S), w, Math.round(22 * S), 'center');
    b.fontSize = Math.round(12 * S); b.textColor = 'rgba(234,215,176,0.6)'; b.drawText('OK to continue', 0, Math.round(62 * S), w, Math.round(18 * S), 'center');
    this._plaque = new Sprite(b); this._plaque.x = Math.round((W - w) / 2); this._plaque.y = Math.round(this._cleared ? H / 2 + 10 * S : (H - h) / 2); this._plaque.opacity = 0; this.addChild(this._plaque);
  };

  /** Keyboard: the free tile nearest the hand in the pressed direction. Allocation only on a key press. */
  Scene_Tilestack.prototype.stepCursor = function (dx, dy) {
    var g = this._game, best = -1, bestD = Infinity, cx, cy;
    if (this._cursor >= 0 && g.face[this._cursor] !== null) { var s0 = this._sp[this._cursor]; cx = s0.x + this._tw / 2; cy = s0.y + this._th / 2; } else { cx = Graphics.width / 2; cy = Graphics.height / 2; dx = dy = 0; }
    for (var t = 0; t < g.face.length; t++) {
      if (g.face[t] === null || t === this._cursor || !this._free[t]) continue;
      var s = this._sp[t], vx = s.x + this._tw / 2 - cx, vy = s.y + this._th / 2 - cy, along = vx * dx + vy * dy;
      if ((dx || dy) && along <= 0) continue;
      var dist = (dx || dy) ? along + Math.abs(vx * dy - vy * dx) * 2 : vx * vx + vy * vy;
      if (dist < bestD) { bestD = dist; best = t; }
    }
    if (best >= 0) { this._cursor = best; var sp = this._sp[best]; this._hand.x = sp.x + this._tw * 0.55; this._hand.y = sp.y + this._th * 0.55; this._hand.visible = true; SoundManager.playCursor(); }
  };

  Scene_Tilestack.prototype.update = function () {
    Scene_Base.prototype.update.call(this);
    if (!this._built) return;
    // removed tiles lift and fade (12 frames), then hide
    for (var f = this._fading.length - 1; f >= 0; f--) {
      var sp = this._fading[f]; if (sp._y0 === undefined) sp._y0 = sp.y;
      sp.opacity -= 22; sp.y -= 1; if (sp.opacity <= 0) { sp.visible = false; sp.y = sp._y0; this._fading.splice(f, 1); }
    }
    if (this._done) {
      this._doneAge++;
      var e = Math.min(1, this._doneAge / 32); e = e * e * (3 - 2 * e);
      if (this._ghost) this._ghost.opacity = Math.round(255 * e);
      for (var wi = 0; this._win && wi < this._win.length; wi++) {
        var ws = this._win[wi]; ws.opacity = Math.min(255, this._doneAge * 16);
        ws.x = ws._x0 + (ws._x1 - ws._x0) * e; ws.y = ws._y0 + (ws._y1 - ws._y0) * e; ws.scale.x = ws.scale.y = ws._s0 + (1 - ws._s0) * e;
      }
      if (this._plaque) this._plaque.opacity = Math.max(0, Math.min(255, (this._doneAge - (this._win && this._win.length ? 20 : 0)) * 14));
      if (this._doneAge > 40 && (Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered())) this.popScene();
      return;
    }
    this._frames++;
    if (Input.isRepeated('left')) this.stepCursor(-1, 0); else if (Input.isRepeated('right')) this.stepCursor(1, 0); else if (Input.isRepeated('up')) this.stepCursor(0, -1); else if (Input.isRepeated('down')) this.stepCursor(0, 1);
    if (Input.isTriggered('ok')) { if (this._stuck) this.reshuffle(); else if (this._cursor >= 0) this.choose(this._cursor); else this.stepCursor(0, 0); }
    if (Input.isTriggered('pageup')) this.hint();
    if (Input.isTriggered('pagedown')) this.undoPair();
    if (TouchInput.isTriggered()) { this._hand.visible = false; if (this._stuck) this.reshuffle(); else this.choose(this.tileAt(TouchInput.x, TouchInput.y)); }
    if (Input.isTriggered('cancel') || TouchInput.isCancelled()) this.finish(false);
    this.drawHud();
  };

  CSAF.Tilestack = { VERSION: '1.0.0', P: P, start: start, Scene_Tilestack: Scene_Tilestack, lastResult: function () { return $gameSystem && $gameSystem._csafTilestack ? $gameSystem._csafTilestack.last : null; } };
  window.Scene_Tilestack = Scene_Tilestack;
})();
