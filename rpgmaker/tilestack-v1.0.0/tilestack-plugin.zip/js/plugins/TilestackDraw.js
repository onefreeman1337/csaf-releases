//=============================================================================
// TilestackDraw.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Tilestack renderer: draws every tile (body and face) in several sets, and the table. Load SECOND.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * Drawing only, onto any canvas 2D context (an MZ/MV Bitmap's context in the
 * game). No image file is loaded: every tile is drawn from its face id and the
 * chosen set.
 *
 * WORK IN PROGRESS (2026-10-04): the tile body, the circles suit and the bamboo
 * suit are drawn; characters, winds, dragons, flowers and seasons are next.
 */

var CSAF = CSAF || {};

(function () {
  'use strict';

  /** The sets: face, back (the dyed layer under the face), and the inks the faces are struck in. */
  var SETS = {
    ivory: { face: '#f3ead6', faceEdge: '#d9ccae', back: '#2f6b4f', backEdge: '#1d4634', blue: '#1f4f8f', green: '#2c7a4b', red: '#b5302a', black: '#2a2420' },
    bone: { face: '#efe3c8', faceEdge: '#d2c09c', back: '#b5873f', backEdge: '#7c5a26', blue: '#23497a', green: '#3d7340', red: '#a8322a', black: '#2b241d' },
    jade: { face: '#dfeee2', faceEdge: '#b9d3c0', back: '#1f5a46', backEdge: '#113a2c', blue: '#21507a', green: '#226b47', red: '#a63a2c', black: '#203029' },
    lacquer: { face: '#1e1a1a', faceEdge: '#0e0c0c', back: '#8e1f1c', backEdge: '#5a110f', blue: '#7fb0e0', green: '#8fd0a0', red: '#e9715f', black: '#e8cf8a' },
    porcelain: { face: '#f7f8fb', faceEdge: '#d6dbe6', back: '#24467e', backEdge: '#152c52', blue: '#1f4fa0', green: '#2f6fb0', red: '#3a5fc0', black: '#1c2f5c' }
  };
  function set(name) { return SETS[name] || SETS.ivory; }

  function rr(c, x, y, w, h, r) {
    c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r);
    c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath();
  }
  function hex(c) { var n = parseInt(String(c).slice(1), 16); return isFinite(n) ? [(n >> 16) & 255, (n >> 8) & 255, n & 255] : null; }
  function mix(a, b, t) { var A = hex(a), B = hex(b); if (!A || !B) return a; var o = []; for (var i = 0; i < 3; i++) o.push(Math.round(A[i] + (B[i] - A[i]) * t)); return 'rgb(' + o.join(',') + ')'; }

  /**
   * One tile's body: a dyed back layer and a carved face, seen from slightly above and to the left, so the block's
   * thickness shows on its lower-right sides. (x, y) is the FACE's top-left; the body extends `d` px right and down.
   * @param {CanvasRenderingContext2D} c
   * @param {{set:string, lit:number, picked:boolean, hint:boolean, dim:boolean}} [o] lit 0..1 = how high the layer is
   */
  function drawBody(c, x, y, w, h, d, o) {
    o = o || {}; var S = set(o.set), r = Math.max(2, w * 0.12);
    c.save();
    // drop shadow on what lies below
    c.fillStyle = 'rgba(0,0,0,0.30)'; rr(c, x + d * 1.4, y + d * 1.6, w, h, r); c.fill();
    // the body's sides: back colour at the bottom, face colour above it (two-layer tile)
    for (var k = d; k > 0; k--) {
      var t = k / d;
      c.fillStyle = t > 0.45 ? mix(S.back, S.backEdge, (t - 0.45) / 0.55) : mix(S.faceEdge, S.back, t / 0.45 * 0.3);
      rr(c, x + k, y + k, w, h, r); c.fill();
    }
    // the face: lit from upper left, a soft darker band toward the lower right edge
    var g = c.createLinearGradient(x, y, x + w, y + h);
    g.addColorStop(0, mix(S.face, '#ffffff', 0.25)); g.addColorStop(0.55, S.face); g.addColorStop(1, S.faceEdge);
    c.fillStyle = g; rr(c, x, y, w, h, r); c.fill();
    c.strokeStyle = 'rgba(255,255,255,0.45)'; c.lineWidth = Math.max(1, w * 0.02); rr(c, x + 1, y + 1, w - 2, h - 2, r * 0.9); c.stroke();
    c.strokeStyle = 'rgba(0,0,0,0.28)'; c.lineWidth = 1; rr(c, x + 0.5, y + 0.5, w - 1, h - 1, r); c.stroke();
    // height reads as light: the caller passes how far below the top layer this tile sits (0 = top)
    if (o.depthShade > 0) { c.fillStyle = 'rgba(30,22,12,' + Math.min(0.4, o.depthShade).toFixed(3) + ')'; rr(c, x, y, w, h, r); c.fill(); }
    if (o.dim) { c.fillStyle = 'rgba(20,14,8,0.32)'; rr(c, x, y, w, h, r); c.fill(); }
    if (o.picked || o.hint) {
      c.strokeStyle = o.picked ? 'rgba(244,196,92,0.95)' : 'rgba(120,200,255,0.9)'; c.lineWidth = Math.max(2, w * 0.06);
      rr(c, x - 1, y - 1, w + 2, h + 2, r * 1.1); c.stroke();
    }
    c.restore();
  }

  // ---- the circles suit: a ring with a flower worked inside it; placements are the traditional ones
  function circle(c, cx, cy, R, ink, accent) {
    c.save();
    c.lineWidth = Math.max(0.9, R * 0.16); c.strokeStyle = ink;
    c.beginPath(); c.arc(cx, cy, R * 0.86, 0, Math.PI * 2); c.stroke();
    c.lineWidth = Math.max(0.7, R * 0.08); c.strokeStyle = accent;
    c.beginPath(); c.arc(cx, cy, R * 0.56, 0, Math.PI * 2); c.stroke();
    // eight petals between the rings, cut into the face rather than laid on it (Icon_Doctrine 22a-2b)
    c.fillStyle = ink;
    for (var i = 0; i < 8; i++) {
      var a = i * Math.PI / 4, px = cx + Math.cos(a) * R * 0.71, py = cy + Math.sin(a) * R * 0.71;
      c.beginPath(); c.arc(px, py, Math.max(0.6, R * 0.075), 0, Math.PI * 2); c.fill();
    }
    c.fillStyle = accent; c.beginPath(); c.arc(cx, cy, Math.max(0.8, R * 0.24), 0, Math.PI * 2); c.fill();
    c.restore();
  }
  /** Circle centres for 1..9 in a unit face [0,1]^2, and which ones take the second ink. */
  var DOTS = {
    1: [[0.5, 0.5]], 2: [[0.5, 0.27], [0.5, 0.73]], 3: [[0.25, 0.22], [0.5, 0.5], [0.75, 0.78]],
    4: [[0.29, 0.27], [0.71, 0.27], [0.29, 0.73], [0.71, 0.73]], 5: [[0.27, 0.22], [0.73, 0.22], [0.5, 0.5], [0.27, 0.78], [0.73, 0.78]],
    6: [[0.29, 0.2], [0.71, 0.2], [0.29, 0.53], [0.71, 0.53], [0.29, 0.82], [0.71, 0.82]],
    7: [[0.22, 0.14], [0.5, 0.24], [0.78, 0.34], [0.29, 0.58], [0.71, 0.58], [0.29, 0.84], [0.71, 0.84]],
    8: [[0.29, 0.13], [0.71, 0.13], [0.29, 0.38], [0.71, 0.38], [0.29, 0.63], [0.71, 0.63], [0.29, 0.88], [0.71, 0.88]],
    9: [[0.22, 0.18], [0.5, 0.18], [0.78, 0.18], [0.22, 0.5], [0.5, 0.5], [0.78, 0.5], [0.22, 0.82], [0.5, 0.82], [0.78, 0.82]]
  };
  function circlesFace(c, n, x, y, w, h, S) {
    var pts = DOTS[n], R = n === 1 ? Math.min(w, h) * 0.36 : Math.min(w * (n >= 7 ? 0.13 : n >= 4 ? 0.17 : 0.2), h * (n === 8 ? 0.1 : n >= 6 ? 0.13 : 0.17));
    for (var i = 0; i < pts.length; i++) {
      var second = (n === 6 && i >= 2) || (n === 7 && i >= 3) || (n === 9 && i >= 3 && i < 6) || (n === 5 && i === 2) || (n === 3 && i === 1) || n === 1;
      circle(c, x + pts[i][0] * w, y + pts[i][1] * h, R, second ? S.red : S.blue, second ? S.green : S.red);
    }
  }

  // ---- the bamboo suit: segmented stalks, each with three nodes; the one is a single ornate stalk in leaf
  // (first look: red elliptical nodes chopped each stalk into stacked beads; a stalk is one continuous tube whose
  // nodes are thin rings in a DARKER SHADE OF ITS OWN INK, waisted slightly between nodes)
  function stalk(c, cx, cy, sw, sh, ink) {
    c.save();
    var top = cy - sh / 2, seg = sh / 3, dark = mix(ink, '#000000', 0.45), lite = mix(ink, '#ffffff', 0.35);
    var g = c.createLinearGradient(cx - sw / 2, 0, cx + sw / 2, 0);
    g.addColorStop(0, dark); g.addColorStop(0.38, lite); g.addColorStop(0.7, ink); g.addColorStop(1, dark);
    c.fillStyle = g;
    c.beginPath();
    for (var s = 0; s < 3; s++) { // each segment waisted a little in the middle
      var y0 = top + s * seg, y1 = y0 + seg, ym = (y0 + y1) / 2, wl = sw * 0.5, wm = sw * 0.42;
      c.moveTo(cx - wl, y0); c.quadraticCurveTo(cx - wm, ym, cx - wl, y1); c.lineTo(cx + wl, y1); c.quadraticCurveTo(cx + wm, ym, cx + wl, y0); c.closePath();
    }
    c.fill();
    c.fillStyle = dark;
    for (var k = 0; k <= 3; k++) { var ny = top + k * seg; rr(c, cx - sw * 0.6, ny - Math.max(0.6, sw * 0.09), sw * 1.2, Math.max(1.2, sw * 0.18), Math.max(0.5, sw * 0.09)); c.fill(); }
    c.restore();
  }
  var STALKS = {
    2: [[0.5, 0.3], [0.5, 0.7]], 3: [[0.5, 0.29], [0.3, 0.71], [0.7, 0.71]], 4: [[0.3, 0.29], [0.7, 0.29], [0.3, 0.71], [0.7, 0.71]],
    5: [[0.24, 0.29], [0.76, 0.29], [0.5, 0.5], [0.24, 0.71], [0.76, 0.71]], 6: [[0.22, 0.29], [0.5, 0.29], [0.78, 0.29], [0.22, 0.71], [0.5, 0.71], [0.78, 0.71]],
    7: [[0.5, 0.17], [0.22, 0.5], [0.5, 0.5], [0.78, 0.5], [0.22, 0.83], [0.5, 0.83], [0.78, 0.83]],
    8: [[0.17, 0.29], [0.39, 0.29], [0.61, 0.29], [0.83, 0.29], [0.17, 0.71], [0.39, 0.71], [0.61, 0.71], [0.83, 0.71]],
    9: [[0.22, 0.17], [0.5, 0.17], [0.78, 0.17], [0.22, 0.5], [0.5, 0.5], [0.78, 0.5], [0.22, 0.83], [0.5, 0.83], [0.78, 0.83]]
  };
  function bambooOne(c, x, y, w, h, S) {
    // one tall stalk leaning a little, with leaves that BRANCH off it (a single stalk alone would read as a "1")
    c.save();
    c.translate(x + w * 0.5, y + h * 0.52); c.rotate(-0.12);
    stalk(c, 0, 0, w * 0.16, h * 0.78, S.green);
    c.fillStyle = S.green;
    var leaves = [[-1, -0.22, -0.9], [1, -0.05, 0.85], [-1, 0.16, -0.7], [1, 0.3, 0.6]];
    for (var i = 0; i < leaves.length; i++) {
      var L = leaves[i], lx = 0, ly = L[1] * h, len = w * 0.36;
      c.save(); c.translate(lx, ly); c.rotate(L[2]);
      c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(len * 0.5 * L[0], -h * 0.06, len * L[0], 0); c.quadraticCurveTo(len * 0.5 * L[0], h * 0.05, 0, 0); c.fill();
      c.restore();
    }
    c.restore();
  }
  function bambooFace(c, n, x, y, w, h, S) {
    if (n === 1) return bambooOne(c, x, y, w, h, S);
    var pts = STALKS[n], sw = w * (n >= 8 ? 0.11 : n >= 6 ? 0.13 : 0.15), sh = h * (n >= 7 ? 0.27 : 0.34);
    for (var i = 0; i < pts.length; i++) {
      var red = (n === 5 && i === 2) || (n === 7 && i === 0) || (n === 9 && (i % 3) === 1);
      stalk(c, x + pts[i][0] * w, y + pts[i][1] * h, sw, sh, red ? S.red : S.green);
    }
  }

  // ---- glyph tiles: characters, winds, the red and green dragons. The glyph comes from a CJK font stack and is
  // PROVEN to resolve (wing §15a: compare its pixels with an unassigned code point, which renders as the missing-glyph
  // box); if it does not, a drawn design stands in. A corner index (1-9, E S W N) is drawn either way.
  var CJK = '"Noto Serif CJK SC","Noto Serif CJK JP","Source Han Serif SC","Yu Mincho","YuMincho","MS Mincho","SimSun","Songti SC","STSong","Hiragino Mincho ProN","Microsoft YaHei",serif';
  var NUM = ['', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
  var WAN = '萬', WIND = { E: '東', S: '南', W: '西', N: '北' }, ZHONG = '中', FA = '發';
  var glyphCache = {};
  /** Does this browser have a font that draws `ch` (not the missing-glyph box, not nothing)? Cached per glyph. */
  function hasGlyph(ch) {
    if (glyphCache[ch] !== undefined) return glyphCache[ch];
    var ok = false;
    try {
      var cv = document.createElement('canvas'); cv.width = cv.height = 40;
      var x = cv.getContext('2d'), strike = function (s) { x.clearRect(0, 0, 40, 40); x.fillStyle = '#000'; x.font = 'bold 30px ' + CJK; x.textBaseline = 'middle'; x.textAlign = 'center'; x.fillText(s, 20, 21); return x.getImageData(0, 0, 40, 40).data; };
      var a = strike(ch), b = strike('͸'), ink = 0, diff = 0;
      for (var i = 3; i < a.length; i += 4) { if (a[i] > 40) ink++; if (Math.abs(a[i] - b[i]) > 40) diff++; }
      ok = ink > 20 && diff > 20;
    } catch (e) { ok = false; }
    glyphCache[ch] = ok;
    return ok;
  }
  function glyph(c, ch, cx, cy, size, ink) {
    c.save(); c.fillStyle = ink; c.font = 'bold ' + Math.round(size) + 'px ' + CJK; c.textAlign = 'center'; c.textBaseline = 'middle';
    c.fillText(ch, cx, cy); c.restore();
  }
  function index(c, txt, x, y, w, h, ink) {
    c.save(); c.fillStyle = ink; c.globalAlpha = 0.85; c.font = 'bold ' + Math.max(7, Math.round(h * 0.15)) + 'px Georgia, "Times New Roman", serif';
    c.textAlign = 'left'; c.textBaseline = 'top'; c.fillText(txt, x + w * 0.02, y); c.restore();
  }
  /** The drawn stand-in for a glyph a player's browser cannot draw: a big serif numeral or letter. */
  function standIn(c, txt, cx, cy, size, ink) {
    c.save(); c.fillStyle = ink; c.font = 'bold ' + Math.round(size) + 'px Georgia, "Times New Roman", serif'; c.textAlign = 'center'; c.textBaseline = 'middle';
    c.fillText(txt, cx, cy); c.restore();
  }
  function charactersFace(c, n, x, y, w, h, S) {
    var cx = x + w / 2;
    if (hasGlyph(NUM[n]) && hasGlyph(WAN)) { glyph(c, NUM[n], cx, y + h * 0.3, h * 0.36, S.black); glyph(c, WAN, cx, y + h * 0.72, h * 0.4, S.red); }
    else { standIn(c, String(n), cx, y + h * 0.36, h * 0.46, S.black); c.save(); c.fillStyle = S.red; c.translate(cx, y + h * 0.76); c.rotate(Math.PI / 4); c.fillRect(-h * 0.08, -h * 0.08, h * 0.16, h * 0.16); c.restore(); }
    index(c, String(n), x, y, w, h, S.red);
  }
  function windFace(c, k, x, y, w, h, S) {
    if (hasGlyph(WIND[k])) glyph(c, WIND[k], x + w / 2, y + h * 0.54, h * 0.6, S.black);
    else standIn(c, k, x + w / 2, y + h * 0.54, h * 0.56, S.black);
    index(c, k, x, y, w, h, S.blue);
  }
  function dragonFace(c, k, x, y, w, h, S) {
    var cx = x + w / 2, cy = y + h / 2;
    if (k === 'W') { // the white dragon is a frame, by tradition: a double blue border with a broken inner line
      c.save(); c.strokeStyle = S.blue; c.lineWidth = Math.max(1.2, w * 0.06); rr(c, x + w * 0.14, y + h * 0.12, w * 0.72, h * 0.76, w * 0.06); c.stroke();
      c.lineWidth = Math.max(0.8, w * 0.025); c.setLineDash([Math.max(2, w * 0.08), Math.max(1.5, w * 0.05)]); rr(c, x + w * 0.24, y + h * 0.2, w * 0.52, h * 0.6, w * 0.04); c.stroke(); c.restore();
      return;
    }
    if (k === 'R') {
      if (hasGlyph(ZHONG)) glyph(c, ZHONG, cx, cy + h * 0.02, h * 0.66, S.red);
      else { c.save(); c.strokeStyle = S.red; c.lineWidth = Math.max(1.5, w * 0.08); c.strokeRect(x + w * 0.24, y + h * 0.34, w * 0.52, h * 0.3); c.beginPath(); c.moveTo(cx, y + h * 0.16); c.lineTo(cx, y + h * 0.86); c.stroke(); c.restore(); }
      return;
    }
    if (hasGlyph(FA)) glyph(c, FA, cx, cy + h * 0.02, h * 0.6, S.green);
    else { c.save(); c.fillStyle = S.green; c.beginPath(); c.moveTo(cx, y + h * 0.16); c.quadraticCurveTo(x + w * 0.86, cy, cx, y + h * 0.86); c.quadraticCurveTo(x + w * 0.14, cy, cx, y + h * 0.16); c.fill(); c.restore(); }
  }

  // ---- flowers (plum, orchid, chrysanthemum, bamboo sprig) and seasons (spring bud, summer sun, autumn leaf, winter
  // snowflake): eight emblems told apart by OUTLINE and colour, each with its number in the corner (Icon_Doctrine 22a)
  function petals(c, cx, cy, n, r, len, wid, fill, rot) {
    c.save(); c.fillStyle = fill; c.translate(cx, cy); c.rotate(rot || 0);
    for (var i = 0; i < n; i++) { c.rotate(Math.PI * 2 / n); c.beginPath(); c.ellipse(0, -r - len / 2, wid, len / 2, 0, 0, Math.PI * 2); c.fill(); }
    c.restore();
  }
  function stem(c, x0, y0, x1, y1, ink, wdt) { c.save(); c.strokeStyle = ink; c.lineWidth = wdt; c.lineCap = 'round'; c.beginPath(); c.moveTo(x0, y0); c.quadraticCurveTo((x0 + x1) / 2 + (y1 - y0) * 0.15, (y0 + y1) / 2, x1, y1); c.stroke(); c.restore(); }
  function bonusFace(c, kind, n, x, y, w, h, S) {
    // (first look: a fixed brown vanished on black lacquer - Icon_Doctrine 22e; the wood colour leans on the set's ink)
    var cx = x + w / 2, cy = y + h * 0.5, u = Math.min(w, h), lw = Math.max(1, u * 0.05), brown = mix(S.black, '#8a5a2e', 0.55);
    if (kind === 'f' && n === 1) { // plum: a twig with three five-petal blossoms
      stem(c, x + w * 0.2, y + h * 0.85, x + w * 0.8, y + h * 0.2, brown, lw);
      [[0.36, 0.62, 0.15], [0.62, 0.36, 0.13], [0.7, 0.68, 0.11]].forEach(function (b) { petals(c, x + w * b[0], y + h * b[1], 5, u * 0.02, u * b[2], u * b[2] * 0.62, '#e48aa6'); c.fillStyle = '#f3d36b'; c.beginPath(); c.arc(x + w * b[0], y + h * b[1], u * 0.035, 0, Math.PI * 2); c.fill(); });
    } else if (kind === 'f' && n === 2) { // orchid: long arching leaves and one purple bloom
      c.save(); c.strokeStyle = S.green; c.lineWidth = lw * 1.2; c.lineCap = 'round';
      [[-0.32, -0.1], [0.3, -0.18], [-0.12, -0.42]].forEach(function (l) { c.beginPath(); c.moveTo(cx, y + h * 0.88); c.quadraticCurveTo(cx + w * l[0] * 1.4, y + h * 0.5, cx + w * l[0], y + h * (0.5 + l[1])); c.stroke(); });
      c.restore(); petals(c, cx + w * 0.08, y + h * 0.34, 3, u * 0.03, u * 0.24, u * 0.09, '#9a5bb5', 0.2); petals(c, cx + w * 0.08, y + h * 0.34, 3, u * 0.02, u * 0.13, u * 0.05, '#d9b3e6', 1.25);
    } else if (kind === 'f' && n === 3) { // chrysanthemum: one dense golden head of thin petals on a leafy stem
      stem(c, cx, y + h * 0.9, cx, y + h * 0.48, S.green, lw);
      petals(c, cx, y + h * 0.4, 18, u * 0.05, u * 0.2, u * 0.035, '#e0a72a'); petals(c, cx, y + h * 0.4, 12, u * 0.03, u * 0.12, u * 0.03, '#f2cf5a', 0.13);
    } else if (kind === 'f' && n === 4) { // lotus: pointed petals cupped over a round pad (first look: the traditional
      // bamboo sprig read as the one-bamboo tile, a green stalk with leaves on both - a deck collision, so the subject
      // changed, Icon_Doctrine 22a-5b; any flower matches any flower, so nothing about play moves)
      c.save(); c.fillStyle = S.green; c.beginPath(); c.ellipse(cx, y + h * 0.74, u * 0.36, u * 0.1, 0, 0, Math.PI * 2); c.fill();
      c.fillStyle = mix(S.face, '#000000', 0.25); c.beginPath(); c.moveTo(cx, y + h * 0.74); c.lineTo(cx + u * 0.3, y + h * 0.7); c.lineTo(cx + u * 0.3, y + h * 0.77); c.closePath(); c.fill();
      var lot = [[-0.62, 0.2, '#e58aa8'], [0.62, 0.2, '#e58aa8'], [-0.3, 0.26, '#f0a9c0'], [0.3, 0.26, '#f0a9c0'], [0, 0.3, '#f7c6d6']];
      lot.forEach(function (p) { c.save(); c.translate(cx, y + h * 0.66); c.rotate(p[0]); c.fillStyle = p[2]; c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(u * 0.12, -u * p[1] * 0.6, 0, -u * p[1] * 1.15); c.quadraticCurveTo(-u * 0.12, -u * p[1] * 0.6, 0, 0); c.fill(); c.restore(); });
      c.restore();
    } else if (kind === 's' && n === 1) { // spring: a green shoot with two leaves and a closed pink bud
      stem(c, cx, y + h * 0.88, cx, y + h * 0.36, S.green, lw * 1.2);
      c.save(); c.fillStyle = S.green; c.beginPath(); c.ellipse(cx - u * 0.13, y + h * 0.64, u * 0.14, u * 0.05, -0.5, 0, Math.PI * 2); c.fill(); c.beginPath(); c.ellipse(cx + u * 0.13, y + h * 0.56, u * 0.14, u * 0.05, 0.5, 0, Math.PI * 2); c.fill();
      c.fillStyle = '#e07a9a'; c.beginPath(); c.moveTo(cx, y + h * 0.16); c.quadraticCurveTo(cx + u * 0.14, y + h * 0.3, cx, y + h * 0.38); c.quadraticCurveTo(cx - u * 0.14, y + h * 0.3, cx, y + h * 0.16); c.fill(); c.restore();
    } else if (kind === 's' && n === 2) { // summer: a sun, a disc with alternating long and short rays
      c.save(); c.strokeStyle = '#d9822b'; c.lineCap = 'round'; c.lineWidth = lw;
      for (var i = 0; i < 12; i++) { var a = i * Math.PI / 6, r0 = u * 0.2, r1 = u * (i % 2 ? 0.3 : 0.38); c.beginPath(); c.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0); c.lineTo(cx + Math.cos(a) * r1, cy + Math.sin(a) * r1); c.stroke(); }
      c.fillStyle = '#e9a630'; c.beginPath(); c.arc(cx, cy, u * 0.16, 0, Math.PI * 2); c.fill(); c.restore();
    } else if (kind === 's' && n === 3) { // autumn: a maple leaf, five pointed lobes on a short stalk
      c.save(); c.fillStyle = '#c4501f'; c.translate(cx, cy - u * 0.02); c.beginPath();
      var pts = [[0, -0.36], [0.07, -0.18], [0.3, -0.24], [0.2, -0.04], [0.34, 0.06], [0.12, 0.1], [0.14, 0.26], [0, 0.16], [-0.14, 0.26], [-0.12, 0.1], [-0.34, 0.06], [-0.2, -0.04], [-0.3, -0.24], [-0.07, -0.18]];
      pts.forEach(function (p, k) { var px = p[0] * u, py = p[1] * u; if (k) c.lineTo(px, py); else c.moveTo(px, py); }); c.closePath(); c.fill();
      c.strokeStyle = brown; c.lineWidth = Math.max(1, u * 0.025); c.beginPath(); c.moveTo(0, 0.16 * u); c.lineTo(0, 0.4 * u); c.stroke(); c.restore();
    } else { // winter: a six-armed snowflake with branched arms
      c.save(); c.strokeStyle = S.blue; c.lineWidth = lw; c.lineCap = 'round'; c.translate(cx, cy);
      for (var j = 0; j < 6; j++) { c.rotate(Math.PI / 3); c.beginPath(); c.moveTo(0, 0); c.lineTo(0, -u * 0.34); c.moveTo(0, -u * 0.2); c.lineTo(u * 0.08, -u * 0.28); c.moveTo(0, -u * 0.2); c.lineTo(-u * 0.08, -u * 0.28); c.stroke(); }
      c.restore();
    }
    index(c, String(n), x, y, w, h, kind === 'f' ? S.red : S.blue);
  }

  /**
   * Draw a face onto the tile face rectangle (inside the body drawn by drawBody). An unknown face draws nothing and
   * returns false, so a caller can see it.
   * @returns {boolean} whether the face was drawn
   */
  function drawFace(c, face, x, y, w, h, setName) {
    var S = set(setName), suit = String(face).charAt(0), rest = String(face).slice(1), n = Number(rest);
    var m = Math.min(w, h) * 0.08, fx = x + m, fy = y + m, fw = w - m * 2, fh = h - m * 2;
    if (suit === 'c' && n >= 1 && n <= 9) { circlesFace(c, n, fx, fy, fw, fh, S); return true; }
    if (suit === 'b' && n >= 1 && n <= 9) { bambooFace(c, n, fx, fy, fw, fh, S); return true; }
    if (suit === 'k' && n >= 1 && n <= 9) { charactersFace(c, n, fx, fy, fw, fh, S); return true; }
    if (suit === 'w' && WIND[rest]) { windFace(c, rest, fx, fy, fw, fh, S); return true; }
    if (suit === 'd' && /^[RGW]$/.test(rest)) { dragonFace(c, rest, fx, fy, fw, fh, S); return true; }
    if ((suit === 'f' || suit === 's') && n >= 1 && n <= 4) { bonusFace(c, suit, n, fx, fy, fw, fh, S); return true; }
    return false;
  }

  /** The wooden rim's width on a w x h table: the felt starts this far in. */
  function feltInset(w, h) { return Math.round(Math.min(w, h) * 0.04); }

  /**
   * The table: a baize mat inside a dark wooden rim, a pool of lamp light over the middle. Drawn once per scene.
   * @param {{seed:*, felt:string, wood:string}} [o]
   */
  function drawTable(c, w, h, o) {
    o = o || {};
    var C = CSAF.TilestackCore, R = C.rng(C.seedOf(o.seed === undefined ? 'table' : o.seed));
    var wood = o.wood || '#3e2618', felt = o.felt || '#1f4a3c', m = feltInset(w, h), i;
    c.fillStyle = wood; c.fillRect(0, 0, w, h);
    for (i = 0; i < 70; i++) {
      var y0 = R() * h; c.strokeStyle = 'rgba(' + (i % 2 ? '255,214,160' : '20,8,2') + ',' + (0.04 + R() * 0.05).toFixed(3) + ')'; c.lineWidth = 1 + R() * 2;
      c.beginPath(); c.moveTo(0, y0); c.bezierCurveTo(w * 0.3, y0 + (R() - 0.5) * 16, w * 0.7, y0 + (R() - 0.5) * 16, w, y0 + (R() - 0.5) * 8); c.stroke();
    }
    c.fillStyle = felt; c.fillRect(m, m, w - m * 2, h - m * 2);
    for (i = 0; i < 1600; i++) { c.fillStyle = 'rgba(' + (R() < 0.5 ? '255,255,255' : '0,0,0') + ',' + (0.02 + R() * 0.03).toFixed(3) + ')'; c.fillRect(m + R() * (w - m * 2), m + R() * (h - m * 2), 1 + R() * 1.5, 1 + R() * 1.5); }
    c.strokeStyle = 'rgba(0,0,0,0.5)'; c.lineWidth = 3; c.strokeRect(m + 1.5, m + 1.5, w - m * 2 - 3, h - m * 2 - 3);
    c.strokeStyle = 'rgba(232,196,120,0.35)'; c.lineWidth = 1; c.strokeRect(m - 0.5, m - 0.5, w - m * 2 + 1, h - m * 2 + 1);
    var lg = c.createRadialGradient(w * 0.5, h * 0.45, Math.min(w, h) * 0.1, w * 0.5, h * 0.5, Math.max(w, h) * 0.75);
    lg.addColorStop(0, 'rgba(255,236,200,0.10)'); lg.addColorStop(1, 'rgba(0,0,0,0.42)'); c.fillStyle = lg; c.fillRect(0, 0, w, h);
  }

  /** A highlight frame for a tile face of w x h: gold for the picked tile, cool blue for a hint. */
  function drawFrame(c, w, h, kind) {
    var r = Math.max(2, w * 0.12), p = 3;
    c.save(); c.lineWidth = Math.max(2, w * 0.07);
    c.shadowColor = kind === 'hint' ? 'rgba(120,200,255,0.9)' : 'rgba(255,200,90,0.9)'; c.shadowBlur = Math.max(4, w * 0.16);
    c.strokeStyle = kind === 'hint' ? 'rgba(150,215,255,0.95)' : 'rgba(250,206,110,0.98)';
    rr(c, p, p, w, h, r); c.stroke(); c.restore();
  }

  CSAF.TilestackDraw = { VERSION: '1.0.0', SETS: SETS, drawBody: drawBody, drawFace: drawFace, drawTable: drawTable, drawFrame: drawFrame, feltInset: feltInset, hasGlyph: hasGlyph, _glyphCache: glyphCache };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.TilestackDraw;
