//=============================================================================
// TilestackCore.js
// Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Tilestack rules: layouts, the free-tile rule and deals that are always solvable. Load FIRST.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The rules only: no drawing, no scene, no engine code. Tilestack.js (the
 * scene and the command) and TilestackDraw.js (the tiles and the table) read it.
 *
 * The game: tiles are stacked in a layout. A tile is FREE when nothing lies on
 * top of it and its left or its right side is open. Remove two free tiles that
 * match; clear the board to win. Any flower matches any flower, and any season
 * any season, as in the traditional set.
 *
 * Every deal is solvable. It is dealt backwards: two free tiles are taken off
 * the full layout and given a matching pair, again and again until the layout
 * is empty, so the order they came off in is a solution. A stuck board can be
 * shuffled the same way, using only the tiles still on it.
 *
 * The same seed always deals the same game; no Math.random anywhere.
 */

var CSAF = CSAF || {};

(function () {
  'use strict';

  /** The 42 faces: three suits of nine, four winds, three dragons, four flowers, four seasons. */
  var FACES = [];
  (function () {
    var s, n;
    for (s = 0; s < 3; s++) for (n = 1; n <= 9; n++) FACES.push('bck'.charAt(s) + n);
    FACES.push('wE', 'wS', 'wW', 'wN', 'dR', 'dG', 'dW');
    for (n = 1; n <= 4; n++) FACES.push('f' + n);
    for (n = 1; n <= 4; n++) FACES.push('s' + n);
  })();

  /** FNV-1a for string seeds; numbers are used as they are. @returns {number} uint32 */
  function seedOf(s) {
    var n = Number(s);
    if (s !== '' && s !== null && s !== undefined && isFinite(n)) return (Math.floor(Math.abs(n)) >>> 0) || 1;
    var h = 2166136261, str = String(s);
    for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    return h || 1;
  }

  /** mulberry32: a small seeded generator, [0, 1). @param {number} a seed @returns {function(): number} */
  function rng(a) {
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /** Match key: every flower is one key, every season another; any other face matches only itself. */
  function keyOf(f) { var c = String(f).charAt(0); return c === 'f' ? 'F' : (c === 's' ? 'S' : String(f)); }
  function matches(a, b) { return a !== null && b !== null && a !== undefined && b !== undefined && keyOf(a) === keyOf(b); }

  /** The traditional 144: four of each of the 34 suit and honour faces, one of each flower and season. */
  function fullSet() {
    var out = [];
    for (var i = 0; i < FACES.length; i++) {
      var f = FACES[i], bonus = /^[fs]\d$/.test(f);
      for (var c = 0; c < (bonus ? 1 : 4); c++) out.push(f);
    }
    return out;
  }

  /** The 72 matching pairs of the full set (flowers and seasons paired among themselves). */
  function allPairs() {
    var out = [], i, f;
    for (i = 0; i < FACES.length; i++) { f = FACES[i]; if (!/^[fs]\d$/.test(f)) { out.push([f, f]); out.push([f, f]); } }
    out.push(['f1', 'f2'], ['f3', 'f4'], ['s1', 's2'], ['s3', 's4']);
    return out;
  }

  // Positions are in HALF-TILE units: a tile at (x, y, z) covers [x, x+2) x [y, y+2) on layer z.
  function P(x, y, z) { return { x: x, y: y, z: z }; }

  /** The classic turtle: 87 + 36 + 16 + 4 + 1 = 144. */
  function turtle() {
    var L = [], x, y, rows = [[1, 12], [3, 10], [2, 11], [1, 12], [1, 12], [2, 11], [3, 10], [1, 12]];
    for (y = 0; y < 8; y++) for (x = rows[y][0]; x <= rows[y][1]; x++) L.push(P(x * 2, y * 2, 0));
    L.push(P(0, 7, 0), P(26, 7, 0), P(28, 7, 0));                         // the end tiles, between rows 3 and 4
    for (y = 1; y <= 6; y++) for (x = 4; x <= 9; x++) L.push(P(x * 2, y * 2, 1));
    for (y = 2; y <= 5; y++) for (x = 5; x <= 8; x++) L.push(P(x * 2, y * 2, 2));
    for (y = 3; y <= 4; y++) for (x = 6; x <= 7; x++) L.push(P(x * 2, y * 2, 3));
    L.push(P(13, 7, 4));                                                  // the cap, over the middle four
    L.style = 'turtle';
    return L;
  }

  function has(set, x, y) { return set[x + ',' + y] === true; }
  /** Upper layers over a footprint: 'stepped' keeps the grid (a tile whose four sides are all built under),
   *  'offset' sits each tile on a 2x2 block below, half a tile across and down. Mirror-symmetric if the footprint is. */
  function layersOver(base, style) {
    var out = base.slice(), cur = base, z = 0;
    while (cur.length && z < 4) {
      var set = {}, next = [], i, p;
      for (i = 0; i < cur.length; i++) set[cur[i].x + ',' + cur[i].y] = true;
      for (i = 0; i < cur.length; i++) {
        p = cur[i];
        if (style === 'stepped' && has(set, p.x - 2, p.y) && has(set, p.x + 2, p.y) && has(set, p.x, p.y - 2) && has(set, p.x, p.y + 2)) next.push(P(p.x, p.y, z + 1));
        if (style === 'offset' && has(set, p.x + 2, p.y) && has(set, p.x, p.y + 2) && has(set, p.x + 2, p.y + 2)) next.push(P(p.x + 1, p.y + 1, z + 1));
      }
      for (i = 0; i < next.length; i++) out.push(next[i]);
      cur = next; z++;
    }
    return out;
  }

  /**
   * A generated layout of about `tiles` tiles: a footprint grown outwards from the middle in mirror pairs, with
   * upper layers in one of two styles. Grows until it reaches the size, then drops one cap tile if the count is odd.
   * @param {{tiles:number, seed:*}} o
   * @returns {Array<{x:number,y:number,z:number}>} with .style
   */
  function generated(o) {
    var want = Math.round(Number(o && o.tiles));
    if (!isFinite(want)) want = 72;
    want = Math.max(8, Math.min(144, want));
    var R = rng(seedOf(String(o && o.seed !== undefined ? o.seed : 'tilestack') + ':layout'));
    var style = R() < 0.5 ? 'stepped' : 'offset';
    // (first look at a plate of six: growing from a random frontier made ragged, tentacled shapes - pillars hanging
    // under a bar, stray spikes. A layout is DESIGNED: every row's half-width follows one smooth seeded profile,
    // mirrored, and the frame grows until it holds the size asked for.)
    var shapes = ['diamond', 'oval', 'hourglass', 'block', 'steps'], shape = shapes[Math.floor(R() * shapes.length)];
    var wob = 0.15 + R() * 0.2, aspect = 1.55 + R() * 0.5;
    function profile(v) {
      var a = Math.abs(v);
      if (shape === 'diamond') return 1 - (0.5 + wob) * a;
      if (shape === 'oval') return Math.sqrt(Math.max(0, 1 - (0.6 + wob) * v * v));
      if (shape === 'hourglass') return 0.5 + (0.3 + wob) * a;
      if (shape === 'steps') return 1 - Math.floor(a * 2.999) * (0.18 + wob * 0.5);
      return a < 0.34 ? 1 - wob : 1;                                         // block, notched at the waist
    }
    var W = 3, H = 2, mid = 1, cy0 = 0, base = [], L = [], guard = 0;
    for (var sc = 2; guard++ < 60; sc++) {
      H = Math.max(2, Math.min(8, Math.round(sc / aspect) + 1)); W = Math.max(3, Math.min(15, sc | 1)); mid = (W - 1) / 2; cy0 = Math.floor(H / 2);
      base = [];
      for (var cy = 0; cy < H; cy++) {
        var v = H > 1 ? (cy - (H - 1) / 2) / ((H - 1) / 2) : 0, half = Math.max(0, Math.round(mid * Math.max(0.12, Math.min(1, profile(v)))));
        for (var cx = mid - half; cx <= mid + half; cx++) base.push(P(cx * 2, cy * 2, 0));
      }
      L = layersOver(base, style);
      if (L.length >= want || (W >= 15 && H >= 8)) break;
    }
    var k;
    // growth overshoots (a ring of cells can add several layers' worth at once; 144 asked once built 150, more than a
    // set holds): take uncovered tiles off, outermost base tiles first, each with its mirror, until it fits
    var axis = W - 1;
    function uncovered(k) { for (var j = 0; j < L.length; j++) if (L[j].z === L[k].z + 1 && Math.abs(L[j].x - L[k].x) < 2 && Math.abs(L[j].y - L[k].y) < 2) return false; return true; }
    while (L.length > want) {
      var bestK = -1, bestS = -Infinity;
      for (k = 0; k < L.length; k++) {
        if (!uncovered(k)) continue;
        var sc = -L[k].z * 1000 + Math.abs(L[k].x - axis) * 4 + Math.abs(L[k].y - cy0 * 2) * 3;
        if (sc > bestS) { bestS = sc; bestK = k; }
      }
      if (bestK < 0) break;
      var t = L[bestK], mirrorK = -1;
      for (k = 0; k < L.length; k++) if (k !== bestK && L[k].z === t.z && L[k].y === t.y && L[k].x === 2 * axis - t.x) { mirrorK = k; break; }
      if (mirrorK >= 0 && uncovered(mirrorK) && L.length - 2 >= want - 1) { L.splice(Math.max(bestK, mirrorK), 1); L.splice(Math.min(bestK, mirrorK), 1); }
      else L.splice(bestK, 1);
    }
    if (L.length % 2) {
      // drop one tile with nothing on it, on the mirror axis if there is one, so the shape stays symmetric
      var top = -1, best = -1;
      for (k = 0; k < L.length; k++) {
        var covered = false;
        for (var j = 0; j < L.length; j++) if (L[j].z === L[k].z + 1 && Math.abs(L[j].x - L[k].x) < 2 && Math.abs(L[j].y - L[k].y) < 2) { covered = true; break; }
        if (covered) continue;
        var score = L[k].z * 10 + (L[k].x === mid * 2 || L[k].x === mid * 2 + 1 ? 5 : 0);
        if (score > best) { best = score; top = k; }
      }
      L.splice(top, 1);
    }
    L.style = style; L.shape = shape;
    return L;
  }

  /** @param {'turtle'|'generated'} name @param {{tiles:number, seed:*}} [o] */
  function layout(name, o) { return name === 'generated' ? generated(o || {}) : turtle(); }

  /** Neighbour tables, once per layout: who lies above each tile, and who touches its left and right sides. */
  function adjacency(pos) {
    var n = pos.length, above = [], left = [], right = [], i, j, a, b;
    for (i = 0; i < n; i++) { above.push([]); left.push([]); right.push([]); }
    for (i = 0; i < n; i++) {
      a = pos[i];
      for (j = 0; j < n; j++) {
        if (i === j) continue; b = pos[j];
        if (b.z === a.z + 1 && Math.abs(b.x - a.x) < 2 && Math.abs(b.y - a.y) < 2) above[i].push(j);
        else if (b.z === a.z && Math.abs(b.y - a.y) < 2) { if (b.x === a.x - 2) left[i].push(j); else if (b.x === a.x + 2) right[i].push(j); }
      }
    }
    return { above: above, left: left, right: right };
  }

  function anyIn(list, present) { for (var k = 0; k < list.length; k++) if (present[list[k]]) return true; return false; }
  function freeIn(adj, present, i) { return !anyIn(adj.above[i], present) && !(anyIn(adj.left[i], present) && anyIn(adj.right[i], present)); }

  /**
   * Deal pairs onto the present tiles backwards (see @help), so the returned order is a solution.
   * @returns {{face:Array, order:Array}|null} null if this shape cannot be cleared in any order
   */
  function dealBackwards(pos, adj, startPresent, pairs, R) {
    var n = pos.length, todo = 0, i;
    for (i = 0; i < n; i++) if (startPresent[i]) todo++;
    for (var attempt = 0; attempt < 60; attempt++) {
      var present = startPresent.slice(), face = new Array(n), order = [], ok = true;
      for (var k = 0; k < todo / 2; k++) {
        var free = [];
        for (i = 0; i < n; i++) if (present[i] && freeIn(adj, present, i)) free.push(i);
        if (free.length < 2) { ok = false; break; }
        var ai = Math.floor(R() * free.length), a = free[ai];
        free.splice(ai, 1);
        var b = free[Math.floor(R() * free.length)];
        face[a] = pairs[k][0]; face[b] = pairs[k][1]; order.push([a, b]);
        present[a] = present[b] = false;
      }
      if (ok) return { face: face, order: order };
    }
    return null;
  }

  function shuffled(arr, R) { var a = arr.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(R() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }

  /** A game over given positions and faces (no solution order). Used by tests and by save loading. */
  function fromLayout(pos, faces, seed) {
    return { pos: pos, adj: adjacency(pos), face: faces.slice(), order: [], history: [], moves: 0, seed: seedOf(seed), style: pos.style || 'custom' };
  }

  /**
   * A new deal. layout 'turtle' (144) or 'generated' (about `tiles`, 8-144); anything else is the turtle.
   * @param {{layout:string, tiles:number, seed:*}} spec
   */
  function newGame(spec) {
    spec = spec || {};
    var seed = spec.seed === undefined || spec.seed === '' ? 'tilestack' : spec.seed;
    var pos = layout(spec.layout === 'generated' ? 'generated' : 'turtle', { tiles: spec.tiles, seed: seed });
    var R = rng(seedOf(String(seed) + ':deal'));
    var pairs = shuffled(allPairs(), R).slice(0, pos.length / 2);
    var adj = adjacency(pos), present = [];
    for (var i = 0; i < pos.length; i++) present.push(true);
    var d = dealBackwards(pos, adj, present, pairs, R);
    if (!d) { pos = turtle(); adj = adjacency(pos); present = []; for (i = 0; i < 144; i++) present.push(true); d = dealBackwards(pos, adj, present, shuffled(allPairs(), R), R); }
    return { pos: pos, adj: adj, face: d.face, order: d.order, history: [], moves: 0, seed: seedOf(seed), style: pos.style };
  }

  function presentOf(g) { var p = []; for (var i = 0; i < g.face.length; i++) p.push(g.face[i] !== null); return p; }
  function isFree(g, i) { return g.face[i] !== null && freeIn(g.adj, presentOf(g), i); }

  var maskPresent = [];
  /**
   * Fill `out` with every tile's free state, reusing both arrays (no allocation): for scenes that ask about many
   * tiles at once (a keyboard cursor), where isFree per tile would build a new array each call.
   * @returns {Array<boolean>} out
   */
  function freeMask(g, out) {
    var n = g.face.length, i;
    maskPresent.length = n; for (i = 0; i < n; i++) maskPresent[i] = g.face[i] !== null;
    out.length = n; for (i = 0; i < n; i++) out[i] = maskPresent[i] && freeIn(g.adj, maskPresent, i);
    return out;
  }

  /** Every pair of free tiles that match, as [i, j] with i < j. Called on a move, never per frame. */
  function matchablePairs(g) {
    var present = presentOf(g), free = [], out = [], i, j;
    for (i = 0; i < g.face.length; i++) if (present[i] && freeIn(g.adj, present, i)) free.push(i);
    for (i = 0; i < free.length; i++) for (j = i + 1; j < free.length; j++) if (matches(g.face[free[i]], g.face[free[j]])) out.push([free[i], free[j]]);
    return out;
  }

  /** Remove a pair if both are free and they match. @returns {boolean} */
  function remove(g, i, j) {
    if (i === j || g.face[i] === null || g.face[j] === null || g.face[i] === undefined || g.face[j] === undefined) return false;
    if (!matches(g.face[i], g.face[j]) || !isFree(g, i) || !isFree(g, j)) return false;
    g.history.push([i, j, g.face[i], g.face[j]]);
    g.face[i] = g.face[j] = null; g.moves++;
    return true;
  }

  /** Put the last pair back. @returns {boolean} */
  function undo(g) { var h = g.history.pop(); if (!h) return false; g.face[h[0]] = h[2]; g.face[h[1]] = h[3]; return true; }

  function tilesLeft(g) { var n = 0; for (var i = 0; i < g.face.length; i++) if (g.face[i] !== null) n++; return n; }
  function isCleared(g) { return tilesLeft(g) === 0; }

  /**
   * Re-deal the tiles still on the board onto the same places so the board is solvable again. Same faces, same
   * places, new arrangement. @returns {boolean} false (and no change) if no order can clear these places at all.
   */
  function shuffle(g, seed) {
    var R = rng(seedOf(String(seed === undefined ? 'shuffle' : seed) + ':shuffle:' + g.moves));
    var groups = {}, i, k, pairs = [];
    for (i = 0; i < g.face.length; i++) if (g.face[i] !== null) { k = keyOf(g.face[i]); (groups[k] = groups[k] || []).push(g.face[i]); }
    for (k in groups) if (Object.prototype.hasOwnProperty.call(groups, k)) for (i = 0; i + 1 < groups[k].length; i += 2) pairs.push([groups[k][i], groups[k][i + 1]]);
    var d = dealBackwards(g.pos, g.adj, presentOf(g), shuffled(pairs, R), R);
    if (!d) return false;
    for (i = 0; i < g.face.length; i++) if (g.face[i] !== null) g.face[i] = d.face[i];
    g.order = d.order; g.history = [];
    return true;
  }

  CSAF.TilestackCore = {
    VERSION: '1.0.0', FACES: FACES, seedOf: seedOf, rng: rng, keyOf: keyOf, matches: matches, fullSet: fullSet,
    layout: layout, adjacency: adjacency, newGame: newGame, fromLayout: fromLayout, isFree: isFree, freeMask: freeMask,
    matchablePairs: matchablePairs, remove: remove, undo: undo, tilesLeft: tilesLeft, isCleared: isCleared, shuffle: shuffle
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.TilestackCore;
