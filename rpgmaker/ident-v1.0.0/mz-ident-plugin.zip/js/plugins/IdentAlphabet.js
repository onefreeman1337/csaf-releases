//=============================================================================
// IdentAlphabet.js — Ident [2/4]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Ident [2/4]: the authored letterform corpus. 80 authored skeletons, five hands, one pen simulation. The wordmark is CUT, not typed.
 * @author Core Systems Asset Factory
 *
 * @help IdentAlphabet.js
 *
 * Part 2 of 4. This is the part of Ident that cannot be generated in an
 * afternoon, and it is the reason the title reads as an OBJECT rather than as
 * text over a picture.
 *
 * WHAT IS IN HERE
 *
 *   SKEL      49 authored skeletons — A-Z, 0-9 and the punctuation a title
 *             uses — each one a set of strokes drawn in a unit design box, in
 *             the order a hand would draw them.
 *   HANDS     5 hands. A hand is not a colour scheme. It declares a PEN
 *             (a broad nib at an angle, or a monoline), whether curves are
 *             SMOOTHED or left as straight facets, a proportion, a terminal
 *             treatment, and its own OVERRIDE skeletons for the letters that
 *             are genuinely built differently in that tradition.
 *   OVERRIDES 31 further authored skeletons across uncial, textura and stave.
 *
 *   80 authored skeletons in total, producing 245 glyphs.
 *
 * THOSE TWO FIGURES ARE PINNED BY A TEST. They read 66 and 180 when this
 * file was first written — hand-counted, and wrong, because the punctuation was
 * left out of the base count. A number in shipped copy that nothing
 * checks is a claim nothing checks, and `Alphabet.volume()` COUNTS them, so the
 * suite asserts the two agree. Edit the corpus and the test tells you.
 *
 * WHY A PEN AND NOT 180 OUTLINES
 *
 * Roman capitals, uncials and blackletter are historically the SAME skeletons
 * written with different tools. Modelling the tool rather than tracing the
 * result is what makes the five hands differ in construction instead of in
 * parameters (a palette is not a composition: a
 * variant that only changes numbers is a recolour). A broad nib held at forty
 * degrees produces blackletter contrast because that is what a broad nib held
 * at forty degrees does.
 *
 * Where the tool is NOT enough — uncial A, E, G, L, M, N, Q, R, T, U; textura
 * A, C, E, G, O, S, U; every round letter in the stave hand — the hand carries
 * an authored override, because those letters really are different shapes and
 * pretending otherwise is the recolour this file exists to avoid.
 *
 * COVERAGE, STATED HONESTLY. This corpus is Latin capitals, digits and
 * punctuation. A title containing anything else — Japanese, Cyrillic, Greek,
 * accented letters — cannot be cut from it. `Alphabet.coverage()` reports the
 * fraction that can be, and IdentCore falls back to a serif display
 * FONT STACK for the remainder. It never falls back to
 * $gameSystem.mainFontFace(), which is the loudest "this is RPG Maker" signal
 * on any screen.
 */

var CSAF = CSAF || {};
CSAF.Ident = CSAF.Ident || {};

(function () {
  'use strict';

  const A = {};
  CSAF.Ident.Alphabet = A;

  /**
   * Resolve sibling modules at FIRST USE, never at load time.
   * A multi-file plugin that captures its siblings at load time does nothing
   * at all when the files are loaded in alphabetical order, which is exactly
   * what a buyer gets for dragging the files into the Plugin Manager.
   * @returns {object} The Render module.
   */
  function R() {
    const r = CSAF.Ident.Render;
    if (!r) throw new Error('Ident: IdentRender.js is not loaded.');
    return r;
  }

  //===========================================================================
  // THE SKELETONS
  //
  // Design box: x runs 0..1 across the glyph's OWN advance width, y runs 0 at
  // the cap line to 1 at the baseline. Descenders go past 1. A stroke is
  // { p: [[x,y]...], c: 1 to smooth as a curve, k: 1 to close the loop }.
  //
  // `w` is the advance in cap heights, and the widths are the Roman ones — E F
  // L B S P R narrow, M W wide, O Q C G D round and broad. Setting every letter
  // to one width is the difference between a wordmark and a spreadsheet.
  //===========================================================================

  /** @type {Object<string, {w:number, s:Array<object>}>} */
  const SKEL = {
    A: { w: 0.70, s: [
      { p: [[0.03, 1.00], [0.50, 0.02]] },
      { p: [[0.50, 0.02], [0.97, 1.00]] },
      { p: [[0.19, 0.70], [0.81, 0.70]] },
    ] },
    B: { w: 0.60, s: [
      { p: [[0.10, 0.02], [0.10, 0.98]] },
      { p: [[0.10, 0.03], [0.56, 0.05], [0.72, 0.26], [0.56, 0.47], [0.10, 0.50]], c: 1 },
      { p: [[0.10, 0.50], [0.64, 0.53], [0.82, 0.74], [0.62, 0.95], [0.10, 0.97]], c: 1 },
    ] },
    C: { w: 0.68, s: [
      { p: [[0.92, 0.24], [0.76, 0.06], [0.44, 0.01], [0.14, 0.20],
        [0.08, 0.52], [0.14, 0.82], [0.44, 0.99], [0.76, 0.94], [0.92, 0.76]], c: 1 },
    ] },
    D: { w: 0.70, s: [
      { p: [[0.10, 0.02], [0.10, 0.98]] },
      { p: [[0.10, 0.02], [0.52, 0.04], [0.86, 0.30], [0.86, 0.70], [0.52, 0.96], [0.10, 0.98]], c: 1 },
    ] },
    E: { w: 0.56, s: [
      { p: [[0.12, 0.02], [0.12, 0.98]] },
      { p: [[0.12, 0.03], [0.88, 0.03]] },
      { p: [[0.12, 0.50], [0.72, 0.50]] },
      { p: [[0.12, 0.97], [0.90, 0.97]] },
    ] },
    F: { w: 0.54, s: [
      { p: [[0.12, 0.02], [0.12, 0.98]] },
      { p: [[0.12, 0.03], [0.88, 0.03]] },
      { p: [[0.12, 0.48], [0.72, 0.48]] },
    ] },
    G: { w: 0.72, s: [
      { p: [[0.92, 0.24], [0.76, 0.06], [0.44, 0.01], [0.14, 0.20], [0.08, 0.52],
        [0.14, 0.82], [0.46, 0.99], [0.78, 0.92], [0.90, 0.72], [0.90, 0.57]], c: 1 },
      { p: [[0.60, 0.57], [0.92, 0.57]] },
    ] },
    H: { w: 0.70, s: [
      { p: [[0.10, 0.02], [0.10, 0.98]] },
      { p: [[0.90, 0.02], [0.90, 0.98]] },
      { p: [[0.10, 0.50], [0.90, 0.50]] },
    ] },
    I: { w: 0.24, s: [{ p: [[0.50, 0.02], [0.50, 0.98]] }] },
    J: { w: 0.46, s: [
      { p: [[0.74, 0.02], [0.74, 0.72], [0.62, 0.95], [0.34, 1.00], [0.10, 0.86]], c: 1 },
    ] },
    K: { w: 0.64, s: [
      { p: [[0.10, 0.02], [0.10, 0.98]] },
      { p: [[0.94, 0.02], [0.14, 0.54]] },
      { p: [[0.34, 0.40], [0.96, 0.98]] },
    ] },
    L: { w: 0.54, s: [
      { p: [[0.12, 0.02], [0.12, 0.97]] },
      { p: [[0.12, 0.97], [0.90, 0.97]] },
    ] },
    M: { w: 0.86, s: [
      { p: [[0.05, 0.98], [0.05, 0.02], [0.50, 0.76], [0.95, 0.02], [0.95, 0.98]] },
    ] },
    N: { w: 0.74, s: [
      { p: [[0.10, 0.98], [0.10, 0.02], [0.90, 0.96], [0.90, 0.02]] },
    ] },
    O: { w: 0.74, s: [
      { p: [[0.50, 0.01], [0.80, 0.13], [0.93, 0.50], [0.80, 0.87],
        [0.50, 0.99], [0.20, 0.87], [0.07, 0.50], [0.20, 0.13]], c: 1, k: 1 },
    ] },
    P: { w: 0.58, s: [
      { p: [[0.10, 0.02], [0.10, 0.98]] },
      { p: [[0.10, 0.03], [0.60, 0.06], [0.80, 0.28], [0.60, 0.51], [0.10, 0.54]], c: 1 },
    ] },
    Q: { w: 0.74, s: [
      { p: [[0.50, 0.01], [0.80, 0.13], [0.93, 0.50], [0.80, 0.87],
        [0.50, 0.99], [0.20, 0.87], [0.07, 0.50], [0.20, 0.13]], c: 1, k: 1 },
      { p: [[0.55, 0.72], [0.74, 0.92], [0.98, 1.12]], c: 1 },
    ] },
    R: { w: 0.62, s: [
      { p: [[0.10, 0.02], [0.10, 0.98]] },
      { p: [[0.10, 0.03], [0.58, 0.06], [0.76, 0.27], [0.58, 0.50], [0.10, 0.53]], c: 1 },
      { p: [[0.40, 0.53], [0.95, 0.98]] },
    ] },
    S: { w: 0.56, s: [
      { p: [[0.88, 0.20], [0.70, 0.04], [0.36, 0.03], [0.16, 0.20], [0.28, 0.42],
        [0.62, 0.55], [0.82, 0.74], [0.70, 0.94], [0.34, 0.99], [0.12, 0.82]], c: 1 },
    ] },
    T: { w: 0.62, s: [
      { p: [[0.03, 0.03], [0.97, 0.03]] },
      { p: [[0.50, 0.03], [0.50, 0.98]] },
    ] },
    U: { w: 0.72, s: [
      { p: [[0.09, 0.02], [0.09, 0.66], [0.24, 0.93], [0.50, 0.99],
        [0.76, 0.93], [0.91, 0.66], [0.91, 0.02]], c: 1 },
    ] },
    V: { w: 0.70, s: [{ p: [[0.03, 0.02], [0.50, 0.98], [0.97, 0.02]] }] },
    W: { w: 0.98, s: [
      { p: [[0.02, 0.02], [0.25, 0.98], [0.50, 0.26], [0.75, 0.98], [0.98, 0.02]] },
    ] },
    X: { w: 0.68, s: [
      { p: [[0.04, 0.02], [0.96, 0.98]] },
      { p: [[0.96, 0.02], [0.04, 0.98]] },
    ] },
    Y: { w: 0.66, s: [
      { p: [[0.03, 0.02], [0.50, 0.50]] },
      { p: [[0.97, 0.02], [0.50, 0.50]] },
      { p: [[0.50, 0.50], [0.50, 0.98]] },
    ] },
    Z: { w: 0.62, s: [
      { p: [[0.07, 0.03], [0.92, 0.03]] },
      { p: [[0.92, 0.03], [0.08, 0.97]] },
      { p: [[0.08, 0.97], [0.93, 0.97]] },
    ] },

    0: { w: 0.62, s: [
      { p: [[0.50, 0.01], [0.80, 0.14], [0.92, 0.50], [0.80, 0.86],
        [0.50, 0.99], [0.20, 0.86], [0.08, 0.50], [0.20, 0.14]], c: 1, k: 1 },
    ] },
    1: { w: 0.40, s: [
      { p: [[0.16, 0.20], [0.52, 0.02], [0.52, 0.97]] },
      { p: [[0.18, 0.97], [0.86, 0.97]] },
    ] },
    2: { w: 0.58, s: [
      { p: [[0.10, 0.22], [0.28, 0.04], [0.62, 0.02], [0.84, 0.22],
        [0.70, 0.50], [0.12, 0.96], [0.90, 0.96]], c: 1 },
    ] },
    3: { w: 0.58, s: [
      { p: [[0.10, 0.14], [0.36, 0.02], [0.72, 0.07], [0.78, 0.28], [0.46, 0.46],
        [0.80, 0.62], [0.74, 0.90], [0.38, 0.99], [0.10, 0.86]], c: 1 },
    ] },
    4: { w: 0.62, s: [
      { p: [[0.72, 0.02], [0.06, 0.70], [0.94, 0.70]] },
      { p: [[0.72, 0.28], [0.72, 0.98]] },
    ] },
    5: { w: 0.58, s: [
      { p: [[0.86, 0.03], [0.22, 0.03], [0.16, 0.42], [0.46, 0.34], [0.80, 0.48],
        [0.84, 0.76], [0.56, 0.98], [0.14, 0.90]], c: 1 },
    ] },
    6: { w: 0.60, s: [
      { p: [[0.84, 0.06], [0.50, 0.01], [0.18, 0.26], [0.10, 0.64], [0.28, 0.94],
        [0.60, 0.98], [0.86, 0.78], [0.74, 0.54], [0.36, 0.50], [0.14, 0.66]], c: 1 },
    ] },
    7: { w: 0.56, s: [{ p: [[0.06, 0.03], [0.92, 0.03], [0.40, 0.98]] }] },
    // TWO loops, not one self-crossing path. A figure-eight authored as a
    // single closed skeleton makes the pen's offset rings cross themselves at
    // the waist, and every hand rendered it as a filled blob.
    8: { w: 0.60, s: [
      { p: [[0.50, 0.02], [0.76, 0.13], [0.74, 0.35], [0.50, 0.48],
        [0.26, 0.35], [0.24, 0.13]], c: 1, k: 1 },
      { p: [[0.50, 0.48], [0.80, 0.62], [0.82, 0.86], [0.50, 0.98],
        [0.18, 0.86], [0.20, 0.62]], c: 1, k: 1 },
    ] },
    9: { w: 0.60, s: [
      { p: [[0.16, 0.94], [0.50, 0.99], [0.82, 0.74], [0.90, 0.36], [0.72, 0.06],
        [0.40, 0.02], [0.14, 0.22], [0.26, 0.46], [0.64, 0.50], [0.86, 0.34]], c: 1 },
    ] },

    ' ': { w: 0.30, s: [] },
    // A point is the pen set down ONCE. Authoring it as a tiny closed loop was
    // wrong: the pen offsets a closed loop into an outer and an inner ring, and
    // a full stop came out as a tiny doughnut. A one-pen-width stroke is both
    // the honest construction and the one that cannot degenerate.
    '.': { w: 0.28, s: [{ p: [[0.50, 0.94], [0.50, 0.95]], d: 1 }] },
    ',': { w: 0.28, s: [{ p: [[0.58, 0.86], [0.50, 0.99], [0.34, 1.13]], c: 1 }] },
    ':': { w: 0.28, s: [
      { p: [[0.50, 0.40], [0.50, 0.41]], d: 1 },
      { p: [[0.50, 0.94], [0.50, 0.95]], d: 1 },
    ] },
    '-': { w: 0.46, s: [{ p: [[0.10, 0.52], [0.90, 0.52]] }] },
    '!': { w: 0.30, s: [
      { p: [[0.50, 0.02], [0.50, 0.64]] },
      { p: [[0.50, 0.94], [0.50, 0.95]], d: 1 },
    ] },
    '?': { w: 0.56, s: [
      { p: [[0.10, 0.22], [0.28, 0.03], [0.66, 0.04], [0.86, 0.24],
        [0.70, 0.46], [0.50, 0.56], [0.50, 0.66]], c: 1 },
      { p: [[0.50, 0.94], [0.50, 0.95]], d: 1 },
    ] },
    "'": { w: 0.22, s: [{ p: [[0.50, 0.02], [0.44, 0.24]] }] },
    '"': { w: 0.38, s: [
      { p: [[0.34, 0.02], [0.28, 0.24]] },
      { p: [[0.70, 0.02], [0.64, 0.24]] },
    ] },
    // An et-ligature, drawn the way a scribe draws one: an S-curve up from the
    // foot into a small closed bowl. The earlier version doubled back on itself
    // and read as a squiggle.
    '&': { w: 0.76, s: [
      { p: [[0.94, 0.96], [0.52, 0.56], [0.26, 0.32], [0.30, 0.10],
        [0.54, 0.04], [0.70, 0.18], [0.58, 0.40], [0.20, 0.68],
        [0.24, 0.92], [0.52, 0.98], [0.80, 0.80]], c: 1 },
    ] },
    '(': { w: 0.34, s: [{ p: [[0.74, 0.00], [0.34, 0.30], [0.34, 0.72], [0.74, 1.02]], c: 1 }] },
    ')': { w: 0.34, s: [{ p: [[0.26, 0.00], [0.66, 0.30], [0.66, 0.72], [0.26, 1.02]], c: 1 }] },
    '/': { w: 0.50, s: [{ p: [[0.06, 1.02], [0.94, 0.00]] }] },
  };

  //===========================================================================
  // THE OVERRIDES.
  //
  // A hand that only re-tints the base skeletons is a recolour. These are the
  // letters that are genuinely built differently in their tradition, authored
  // one at a time.
  //===========================================================================

  /**
   * Uncial: rounded majuscule. The forms that really are uncial.
   *
   * MEASURED on the first contact sheet and CUT: the authentic uncial A and D
   * were authored, rendered, and READ AS "d" AND A REVERSED "c": the eye resolves the cheapest interpretation, arriving through a
   * historically correct letterform rather than through a drawing mistake. A
   * wordmark whose first letter reads as the wrong letter is not a wordmark, so
   * both were cut in place rather than tuned (cutting is the
   * correct move, and the reason stays in the source so nobody re-proposes
   * it). The uncial H — a real "h" — went with them for the same
   * reason. What survives is every rounded form that is UNAMBIGUOUS: E, G, M,
   * N, Q, T, U. The hand stays uncial because its ROUNDNESS and its shallow
   * broad pen carry it, not because of three letters nobody could read.
   */
  const UNCIAL_ALT = {
    // MEASURED on the second contact sheet: with only G, M, N, Q, T, U rounded,
    // the word KINGDOM in uncial and in lapidary differed in ONE letter and the
    // two hands read as one hand at two weights: a palette
    // that is not a composition, arriving through a corpus that was mostly shared.
    // A, L and R were authored with curved sides for exactly this reason: they
    // are common in titles, and each one is unmistakably its own letter, which
    // the authentic uncial A was not.
    A: { w: 0.76, s: [
      { p: [[0.05, 0.98], [0.16, 0.52], [0.42, 0.05]], c: 1 },
      { p: [[0.42, 0.05], [0.72, 0.52], [0.95, 0.98]], c: 1 },
      { p: [[0.20, 0.70], [0.84, 0.70]] },
    ] },
    L: { w: 0.62, s: [
      { p: [[0.14, 0.02], [0.14, 0.70], [0.30, 0.92], [0.58, 0.98], [0.86, 0.86]], c: 1 },
    ] },
    R: { w: 0.68, s: [
      { p: [[0.12, 0.02], [0.12, 0.98]] },
      { p: [[0.12, 0.04], [0.56, 0.06], [0.80, 0.28], [0.56, 0.50], [0.12, 0.53]], c: 1 },
      { p: [[0.40, 0.53], [0.64, 0.72], [0.96, 0.94]], c: 1 },
    ] },
    E: { w: 0.62, s: [
      { p: [[0.88, 0.22], [0.66, 0.03], [0.30, 0.06], [0.12, 0.32], [0.14, 0.62],
        [0.34, 0.94], [0.70, 0.98], [0.90, 0.82]], c: 1 },
      { p: [[0.18, 0.48], [0.68, 0.48]] },
    ] },
    G: { w: 0.66, s: [
      { p: [[0.86, 0.20], [0.62, 0.02], [0.28, 0.10], [0.12, 0.40],
        [0.28, 0.72], [0.62, 0.78], [0.82, 0.62]], c: 1 },
      { p: [[0.82, 0.62], [0.78, 1.02], [0.46, 1.18], [0.16, 1.06]], c: 1 },
    ] },
    M: { w: 0.94, s: [
      { p: [[0.06, 0.98], [0.06, 0.34], [0.24, 0.12], [0.46, 0.30], [0.46, 0.98]], c: 1 },
      { p: [[0.46, 0.34], [0.66, 0.12], [0.90, 0.30], [0.94, 0.98]], c: 1 },
    ] },
    N: { w: 0.76, s: [
      { p: [[0.10, 0.98], [0.10, 0.30], [0.36, 0.12], [0.72, 0.24],
        [0.86, 0.52], [0.86, 0.98]], c: 1 },
    ] },
    Q: { w: 0.74, s: [
      { p: [[0.50, 0.01], [0.80, 0.13], [0.93, 0.50], [0.80, 0.87],
        [0.50, 0.99], [0.20, 0.87], [0.07, 0.50], [0.20, 0.13]], c: 1, k: 1 },
      { p: [[0.36, 0.88], [0.30, 1.06], [0.36, 1.20]], c: 1 },
    ] },
    T: { w: 0.62, s: [
      { p: [[0.06, 0.16], [0.34, 0.02], [0.66, 0.02], [0.94, 0.16]], c: 1 },
      { p: [[0.44, 0.06], [0.44, 0.98]] },
    ] },
    U: { w: 0.76, s: [
      { p: [[0.10, 0.02], [0.10, 0.62], [0.30, 0.94], [0.62, 0.96],
        [0.88, 0.74], [0.88, 0.02]], c: 1 },
      { p: [[0.88, 0.02], [0.88, 0.98]] },
    ] },
  };

  /** Textura: the blackletter letters that are not simply the base faceted. */
  const TEXTURA_ALT = {
    A: { w: 0.66, s: [
      { p: [[0.12, 0.98], [0.12, 0.32], [0.46, 0.18], [0.86, 0.32], [0.86, 0.98]] },
      { p: [[0.86, 0.60], [0.12, 0.60]] },
      { p: [[0.12, 0.32], [0.46, 0.02], [0.86, 0.32]] },
    ] },
    C: { w: 0.62, s: [
      { p: [[0.90, 0.16], [0.56, 0.02], [0.20, 0.14], [0.12, 0.50],
        [0.20, 0.86], [0.56, 0.98], [0.90, 0.84]] },
    ] },
    E: { w: 0.62, s: [
      { p: [[0.90, 0.16], [0.56, 0.02], [0.20, 0.14], [0.12, 0.50],
        [0.20, 0.86], [0.56, 0.98], [0.90, 0.84]] },
      { p: [[0.20, 0.50], [0.72, 0.50]] },
    ] },
    G: { w: 0.66, s: [
      { p: [[0.90, 0.16], [0.56, 0.02], [0.20, 0.14], [0.12, 0.50],
        [0.20, 0.86], [0.58, 0.98], [0.88, 0.84], [0.88, 0.58], [0.56, 0.58]] },
    ] },
    O: { w: 0.68, s: [
      { p: [[0.50, 0.02], [0.90, 0.32], [0.90, 0.68], [0.50, 0.98],
        [0.10, 0.68], [0.10, 0.32]], k: 1 },
    ] },
    S: { w: 0.58, s: [
      { p: [[0.88, 0.18], [0.60, 0.02], [0.22, 0.10], [0.18, 0.34], [0.56, 0.50],
        [0.86, 0.64], [0.82, 0.88], [0.44, 0.98], [0.12, 0.86]] },
    ] },
    // M OVERRIDE (factory machine, 2026-10-16). The base M is ONE polyline (stem, V, stem); in this hand's 40 degree
    // broad nib with no smoothing, its upper V and both joins thinned to nothing, so the V floated low and detached and
    // "GAMES" read as "GAIVIES" (looked at 4x in a fresh install, wax-seal; also on a store plate). Four strokes that
    // OVERLAP at the stem tops cannot leave a gap at a join.
    M: { w: 0.86, s: [
      { p: [[0.08, 0.98], [0.08, 0.04]] },
      { p: [[0.08, 0.04], [0.50, 0.68]] },
      { p: [[0.50, 0.68], [0.92, 0.04]] },
      { p: [[0.92, 0.04], [0.92, 0.98]] },
    ] },
    // NO W OVERRIDE. One was authored — outer stems plus two inner peaks — and
    // it rendered as an unreadable zigzag. The base W is already faceted in
    // this hand because textura does not smooth, which is the whole point of
    // making smoothing a property of the HAND: the shared skeleton is already
    // blackletter here without a second copy of it to go stale.
    U: { w: 0.72, s: [
      { p: [[0.10, 0.02], [0.10, 0.74], [0.34, 0.98], [0.66, 0.98], [0.90, 0.74], [0.90, 0.02]] },
      { p: [[0.90, 0.30], [0.90, 0.98]] },
    ] },
  };

  /**
   * Stave: carved with a chisel, so nothing curves. Every round letter is
   * re-authored as straight facets. This is the hand that proves the five are
   * built differently rather than tinted differently — it shares no curve with
   * any of the others because it contains none.
   */
  const STAVE_ALT = {
    B: { w: 0.58, s: [
      { p: [[0.12, 0.02], [0.12, 0.98]] },
      { p: [[0.12, 0.03], [0.76, 0.26], [0.12, 0.50]] },
      { p: [[0.12, 0.50], [0.86, 0.74], [0.12, 0.97]] },
    ] },
    C: { w: 0.62, s: [{ p: [[0.90, 0.04], [0.16, 0.04], [0.16, 0.96], [0.90, 0.96]] }] },
    D: { w: 0.66, s: [
      { p: [[0.12, 0.02], [0.12, 0.98]] },
      { p: [[0.12, 0.02], [0.88, 0.50], [0.12, 0.98]] },
    ] },
    G: { w: 0.68, s: [
      { p: [[0.90, 0.04], [0.16, 0.04], [0.16, 0.96], [0.90, 0.96], [0.90, 0.54]] },
      { p: [[0.58, 0.54], [0.92, 0.54]] },
    ] },
    J: { w: 0.46, s: [{ p: [[0.76, 0.02], [0.76, 0.80], [0.42, 1.00], [0.08, 0.84]] }] },
    O: { w: 0.70, s: [
      { p: [[0.50, 0.01], [0.95, 0.50], [0.50, 0.99], [0.05, 0.50]], k: 1 },
    ] },
    P: { w: 0.56, s: [
      { p: [[0.12, 0.02], [0.12, 0.98]] },
      { p: [[0.12, 0.03], [0.84, 0.28], [0.12, 0.54]] },
    ] },
    Q: { w: 0.70, s: [
      { p: [[0.50, 0.01], [0.95, 0.50], [0.50, 0.99], [0.05, 0.50]], k: 1 },
      { p: [[0.58, 0.72], [0.98, 1.12]] },
    ] },
    R: { w: 0.60, s: [
      { p: [[0.12, 0.02], [0.12, 0.98]] },
      { p: [[0.12, 0.03], [0.82, 0.27], [0.12, 0.52]] },
      { p: [[0.38, 0.52], [0.94, 0.98]] },
    ] },
    S: { w: 0.56, s: [
      { p: [[0.90, 0.06], [0.18, 0.06], [0.18, 0.50], [0.84, 0.50],
        [0.84, 0.94], [0.10, 0.94]] },
    ] },
    U: { w: 0.70, s: [{ p: [[0.10, 0.02], [0.10, 0.72], [0.50, 0.98], [0.90, 0.72], [0.90, 0.02]] }] },
    0: { w: 0.58, s: [
      { p: [[0.50, 0.01], [0.94, 0.50], [0.50, 0.99], [0.06, 0.50]], k: 1 },
    ] },
    8: { w: 0.58, s: [
      { p: [[0.50, 0.02], [0.86, 0.24], [0.50, 0.48], [0.14, 0.24]], k: 1 },
      { p: [[0.50, 0.50], [0.90, 0.74], [0.50, 0.98], [0.10, 0.74]], k: 1 },
    ] },
  };

  //===========================================================================
  // THE HANDS
  //
  // A hand is a TOOL plus a set of decisions about how that tool is held. The
  // pen angle is the whole reason blackletter looks like blackletter.
  //
  //   nib      'broad'    a chisel nib of finite width held at `angle`; the
  //                       stroke thins toward nothing as it travels along its
  //                       own nib direction, which is what produces contrast.
  //            'mono'     a round pen; the width never changes.
  //   angle    nib angle in DEGREES, measured clockwise from horizontal in
  //            screen space (y down).
  //   thin     the floor, as a fraction of full weight, so a hairline still
  //            resolves at the size a title is actually seen.
  //   smooth   samples per skeleton segment; 0 leaves the polyline as straight
  //            facets. THIS IS A STRUCTURAL SWITCH, not a style one.
  //   terminal 'wedge' flared Roman serif · 'nib' the pen's own angled cut ·
  //            'flat' a square chisel cut · 'round'.
  //===========================================================================

  /** @type {Object<string, object>} */
  const HANDS = {
    lapidary: {
      label: 'Lapidary', note: 'Roman inscriptional capital, chisel-cut',
      nib: 'broad', angle: 0, weight: 0.140, thin: 0.36, smooth: 9,
      terminal: 'wedge', flare: 1.88, serifLen: 0.072,
      widthMul: 1.00, track: 0.120, alt: null,
    },
    uncial: {
      label: 'Uncial', note: 'rounded majuscule, broad pen at a shallow angle',
      nib: 'broad', angle: 24, weight: 0.200, thin: 0.32, smooth: 11,
      terminal: 'nib', flare: 1, serifLen: 0,
      widthMul: 1.20, track: 0.100, alt: UNCIAL_ALT,
    },
    textura: {
      label: 'Textura', note: 'blackletter, broad pen at forty degrees, no curves',
      nib: 'broad', angle: 40, weight: 0.205, thin: 0.22, smooth: 0,
      terminal: 'nib', flare: 1, serifLen: 0,
      widthMul: 0.88, track: 0.110, alt: TEXTURA_ALT,
    },
    stave: {
      label: 'Stave', note: 'carved with a chisel, straight cuts only',
      nib: 'mono', angle: 0, weight: 0.112, thin: 1, smooth: 0,
      terminal: 'flat', flare: 1, serifLen: 0,
      widthMul: 0.90, track: 0.150, alt: STAVE_ALT,
    },
    grotesk: {
      label: 'Grotesk', note: 'geometric monoline, no serif, wide tracking',
      nib: 'mono', angle: 0, weight: 0.104, thin: 1, smooth: 12,
      terminal: 'round', flare: 1, serifLen: 0,
      widthMul: 1.02, track: 0.185, alt: null,
    },
  };

  /** @type {string[]} Hand ids in a stable order. */
  A.HAND_IDS = Object.keys(HANDS);

  /** @returns {string[]} Every character the base corpus carries. */
  A.chars = function () { return Object.keys(SKEL); };

  /**
   * @param {string} id Hand id.
   * @returns {object} The hand record.
   */
  A.hand = function (id) {
    const h = HANDS[id];
    if (!h) throw new Error('Ident: unknown hand "' + id + '"');
    return h;
  };

  /**
   * How many authored skeletons this corpus actually contains, counted rather
   * than asserted: count the work, never the
   * verdict.
   * @returns {{base:number, overrides:number, total:number, glyphs:number}}
   */
  A.volume = function () {
    const base = Object.keys(SKEL).length;
    let over = 0;
    A.HAND_IDS.forEach(function (id) {
      const alt = HANDS[id].alt;
      if (alt) over += Object.keys(alt).length;
    });
    return {
      base: base,
      overrides: over,
      total: base + over,
      glyphs: base * A.HAND_IDS.length,
    };
  };

  /**
   * The skeleton a hand uses for a character — its override if it has one,
   * otherwise the base.
   * @param {string} ch Character (already upper-cased).
   * @param {string} handId Hand id.
   * @returns {object|null} {w, s} or null when the corpus has no such glyph.
   */
  A.skeletonFor = function (ch, handId) {
    const h = A.hand(handId);
    if (h.alt && Object.prototype.hasOwnProperty.call(h.alt, ch)) return h.alt[ch];
    return Object.prototype.hasOwnProperty.call(SKEL, ch) ? SKEL[ch] : null;
  };

  /**
   * Fraction of a string this corpus can cut, and which characters it cannot.
   *
   * Stated because it MATTERS: a Japanese or Cyrillic title cannot be cut from
   * a Latin corpus, and the honest thing is to say so and fall back to the
   * house's display font rather than to draw a row of empty boxes.
   *
   * @param {string} text Any string.
   * @param {string} handId Hand id.
   * @returns {{covered:number, total:number, ratio:number, missing:string[]}}
   */
  A.coverage = function (text, handId) {
    const s = String(text == null ? '' : text).toUpperCase();
    const missing = [];
    let covered = 0;
    for (let i = 0; i < s.length; i++) {
      if (A.skeletonFor(s[i], handId)) covered++;
      else if (missing.indexOf(s[i]) < 0) missing.push(s[i]);
    }
    return {
      covered: covered,
      total: s.length,
      ratio: s.length ? covered / s.length : 1,
      missing: missing,
    };
  };

  //===========================================================================
  // THE PEN
  //===========================================================================

  /**
   * Half-width of the stroke at a point, perpendicular to travel.
   *
   * A broad nib sweeps its full width when it travels ACROSS its own edge and
   * collapses toward nothing when it travels ALONG it. That single line is why
   * a nib at 0 degrees gives Roman capitals (thick stems, thin arms) and a nib
   * at 40 gives blackletter (thick verticals, thin hairline diagonals). It is
   * modelled rather than tabulated because tabulating it would be five sets of
   * outlines pretending to be five hands.
   *
   * `thin` is an ABSOLUTE floor as a fraction of the weight, not a taste
   * setting: below roughly a pixel a hairline stops being a line and becomes a
   * grey smear, so a hand that collapses to a true zero
   * has letters that fall apart at title size.
   *
   * @param {number[]} t Unit tangent [x,y].
   * @param {object} h Hand.
   * @param {number} full Full half-width in px.
   * @returns {number} Half-width in px.
   */
  function halfWidth(t, h, full) {
    if (h.nib === 'mono') return full;
    const a = (h.angle * Math.PI) / 180;
    const nx = Math.cos(a);
    const ny = Math.sin(a);
    // |cross(tangent, nib)| is |sin| of the angle between them.
    const s = Math.abs(t[0] * ny - t[1] * nx);
    return full * (h.thin + (1 - h.thin) * s);
  }

  /**
   * Unit tangent at sample i of a polyline, averaged across the joint so a
   * corner does not produce a spike.
   * @param {number[][]} p Points.
   * @param {number} i Index.
   * @param {boolean} closed Ring.
   * @returns {number[]} Unit [x,y].
   */
  function tangentAt(p, i, closed) {
    const n = p.length;
    const a = closed ? p[(i - 1 + n) % n] : p[Math.max(0, i - 1)];
    const b = closed ? p[(i + 1) % n] : p[Math.min(n - 1, i + 1)];
    let dx = b[0] - a[0];
    let dy = b[1] - a[1];
    const m = Math.hypot(dx, dy);
    if (m < 1e-9) return [1, 0];
    dx /= m; dy /= m;
    return [dx, dy];
  }

  /**
   * Sample one skeleton stroke into px points.
   * Kept separate from the outlining pass because the outliner needs to know
   * where the OTHER strokes of the same glyph run — see `strokeRings`.
   * @param {object} st Stroke {p, c, k, d}.
   * @param {object} h Hand.
   * @param {function} map Design-space [x,y] to px [x,y].
   * @returns {number[][]} Sampled points.
   */
  function samplePts(st, h, map, capH) {
    const r = R();
    let pts = st.p.map(map);
    if (st.c && h.smooth > 0) pts = r.smooth(pts, h.smooth, !!st.k);
    if (pts.length === 1) pts = [pts[0], [pts[0][0] + 0.01, pts[0][1]]];
    // A SERIF NEEDS POINTS TO BE SHAPED ON.
    //
    // MEASURED on the cuts plate at cap height 96: a straight stem is authored
    // as TWO points and is not smoothed (nothing curves), so the wedge ramp had
    // only those two samples to act on and produced a taper across the WHOLE
    // STROKE instead of a foot at each end. Every I, E arm and M leg came out
    // as a wedge rather than a stem with serifs. Nothing threw, every glyph was
    // drawn, and at specimen size it read as "chisel character".
    //
    // Densifying is LINEAR, so a straight line stays exactly straight and the
    // angular hands are untouched in shape. It is applied only to hands with a
    // wedge terminal because that is the only thing that needs it — a broad-nib
    // hand's width is a function of the tangent, which is constant along a
    // straight run, so extra samples there would buy nothing.
    if (h.terminal === 'wedge' && h.serifLen > 0 && capH > 0) {
      const maxSeg = Math.max(1.5, h.serifLen * capH * 0.30);
      const dense = [pts[0]];
      for (let i = 1; i < pts.length; i++) {
        const a = pts[i - 1];
        const b = pts[i];
        const d = Math.hypot(b[0] - a[0], b[1] - a[1]);
        const n = Math.max(1, Math.ceil(d / maxSeg));
        for (let k = 1; k <= n; k++) {
          dense.push([a[0] + ((b[0] - a[0]) * k) / n, a[1] + ((b[1] - a[1]) * k) / n]);
        }
      }
      pts = dense;
    }
    return pts;
  }

  /**
   * Signed area of a ring, used only to decide whether a closed stroke really
   * has a counter. A tiny loop offset by a pen wider than the loop itself
   * produces an INVERTED inner ring, and filling that even-odd punches a hole
   * where there should be a solid mark.
   * @param {number[][]} ring Points.
   * @returns {number} Absolute area, px squared.
   */
  function ringArea(ring) {
    let a = 0;
    for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
      a += (ring[j][0] * ring[i][1]) - (ring[i][0] * ring[j][1]);
    }
    return Math.abs(a) / 2;
  }

  /**
   * The footprint of a pen set down once — a lozenge, the shape a chisel or a
   * cut nib actually leaves.
   * @param {number[]} p Centre, px.
   * @param {number} r Radius, px.
   * @returns {number[][]} Ring.
   */
  function dotRing(p, r) {
    const out = [];
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2 + Math.PI / 8;
      out.push([p[0] + Math.cos(a) * r, p[1] + Math.sin(a) * r]);
    }
    return out;
  }

  /**
   * Is this stroke end a free TERMINAL, or a JUNCTION with another stroke?
   *
   * A SERIF IS CUT WHERE A STROKE ENDS FREE. A junction is not a terminal, and
   * flaring one is what turned every A, M, T and E on the first contact sheet
   * into a blob — the apex of the A carried two flares on top of each other and
   * filled its own counter. Authoring a no-flare flag per stroke end was the
   * obvious fix and it is the wrong one: it would have to be repeated across
   * eighty skeletons and would go stale the moment an override was edited.
   * Deriving it from the geometry costs one loop and cannot go stale.
   *
   * @param {number[]} p The end point, px.
   * @param {number[][][]} others Sampled points of the glyph's other strokes.
   * @param {number} near Distance that counts as touching, px.
   * @returns {boolean} True when another stroke passes within `near`.
   */
  function isJunction(p, others, near) {
    const n2 = near * near;
    for (let s = 0; s < others.length; s++) {
      const pts = others[s];
      for (let i = 0; i < pts.length; i++) {
        const dx = pts[i][0] - p[0];
        const dy = pts[i][1] - p[1];
        if (dx * dx + dy * dy < n2) return true;
      }
    }
    return false;
  }

  /**
   * Turn one sampled stroke into filled outline rings, in px.
   *
   * @param {object} st Stroke {p, c, k, d}.
   * @param {number[][]} pts Its sampled points.
   * @param {object} h Hand.
   * @param {number} full Full half-width, px.
   * @param {number} capH Cap height, px — the serif length is stated against
   *   this and NOT against the stroke's own length, because a serif is the same
   *   size on a short crossbar as on a tall stem. Scaling it by stroke length
   *   made the E's middle arm flare along its entire run.
   * @param {number[][][]} others Sampled points of the glyph's other strokes.
   * @returns {number[][][]} One ring for an open stroke; two for a closed loop.
   */
  function strokeRings(st, pts, h, full, capH, others) {
    const closed = !!st.k;
    const n = pts.length;
    const left = [];
    const right = [];
    // Arc length from each end, used only by the wedge terminal.
    const total = [];
    let acc = 0;
    total.push(0);
    for (let i = 1; i < n; i++) {
      acc += Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]);
      total.push(acc);
    }
    const len = Math.max(1e-6, acc);

    // Serifs are cut in ABSOLUTE units and only at free ends.
    const serifPx = h.serifLen * capH;
    const wedge = !closed && h.terminal === 'wedge' && serifPx > 0;
    const near = full * 1.7;
    const freeStart = wedge && !isJunction(pts[0], others, near);
    const freeEnd = wedge && !isJunction(pts[n - 1], others, near);

    for (let i = 0; i < n; i++) {
      const t = tangentAt(pts, i, closed);
      let hw = halfWidth(t, h, full);
      if (wedge && (freeStart || freeEnd)) {
        const dStart = freeStart ? total[i] : Infinity;
        const dEnd = freeEnd ? len - total[i] : Infinity;
        const d = Math.min(dStart, dEnd);
        const ramp = Math.max(0, 1 - d / serifPx);
        // ADDITIVE against the FULL weight, never multiplicative against the
        // local width. A Roman serif is about half a stem wide whatever stroke
        // it sits on, so a thin arm gets a proportionally bigger foot — which
        // is what a serif is for. Multiplying the local width did the opposite
        // and produced clubs on the stems and nothing on the arms.
        hw += full * (h.flare - 1) * ramp * ramp;
      }
      const nx = -t[1];
      const ny = t[0];
      left.push([pts[i][0] + nx * hw, pts[i][1] + ny * hw]);
      right.push([pts[i][0] - nx * hw, pts[i][1] - ny * hw]);
    }

    if (closed) {
      // Only a loop big enough to survive the pen has a counter. Below that the
      // inner ring inverts and even-odd would punch a hole in a solid mark.
      const outerA = ringArea(left);
      const innerA = ringArea(right);
      const oa = Math.max(outerA, innerA);
      const ia = Math.min(outerA, innerA);
      if (!(oa > 0) || ia / oa < 0.10) return [outerA >= innerA ? left : right];
      return outerA >= innerA ? [left, right] : [right, left];
    }

    // Terminals. A broad-pen hand cuts its ends ALONG the nib, which is the
    // angled entry and exit that makes uncial and textura read as written
    // rather than as drawn.
    let cap0 = [];
    let cap1 = [];
    if (h.terminal === 'nib' && h.nib === 'broad') {
      const a = (h.angle * Math.PI) / 180;
      const u = [Math.cos(a), Math.sin(a)];
      cap0 = nibCap(pts[0], tangentAt(pts, 0, false), u, halfWidth(tangentAt(pts, 0, false), h, full));
      cap1 = nibCap(pts[n - 1], tangentAt(pts, n - 1, false), u,
        halfWidth(tangentAt(pts, n - 1, false), h, full));
    }

    const ring = [];
    if (cap0.length) ring.push(cap0[0]);
    for (let i = 0; i < n; i++) ring.push(left[i]);
    if (cap1.length) ring.push(cap1[0], cap1[1]);
    for (let i = n - 1; i >= 0; i--) ring.push(right[i]);
    if (cap0.length) ring.push(cap0[1]);
    return [ring];
  }

  /**
   * The two corners of an angled nib cap at a stroke end.
   * @param {number[]} p End point.
   * @param {number[]} t Unit tangent there.
   * @param {number[]} u Unit nib direction.
   * @param {number} hw Half-width there.
   * @returns {number[][]} [leftCorner, rightCorner].
   */
  function nibCap(p, t, u, hw) {
    const nx = -t[1];
    const ny = t[0];
    const d = nx * u[0] + ny * u[1];
    // When the pen travels along its own nib the cap line is nearly parallel to
    // the stroke and the projection blows up. Clamp it: the hairline is already
    // at its floor there, and an unclamped spike is a whisker on the letter.
    const s = Math.abs(d) < 0.18 ? hw * 3.2 * (d < 0 ? -1 : 1) : hw / d;
    return [[p[0] + u[0] * s, p[1] + u[1] * s], [p[0] - u[0] * s, p[1] - u[1] * s]];
  }

  /**
   * Every ring of one glyph, in px, positioned at (x, baselineY).
   *
   * @param {string} ch Character (upper-cased by the caller).
   * @param {string} handId Hand id.
   * @param {number} x Left edge of the advance box, px.
   * @param {number} baseY Baseline, px.
   * @param {number} capH Cap height, px.
   * @returns {{rings:number[][][], holes:boolean[], advance:number}|null}
   */
  A.glyphRings = function (ch, handId, x, baseY, capH) {
    const h = A.hand(handId);
    const sk = A.skeletonFor(ch, handId);
    if (!sk) return null;
    const adv = sk.w * h.widthMul * capH;
    const full = (h.weight * capH) / 2;
    const map = function (pt) {
      return [x + pt[0] * adv, baseY - capH + pt[1] * capH];
    };
    // TWO PASSES, and the order matters. Every stroke has to be sampled before
    // any is outlined, because whether a stroke end is a free terminal or a
    // junction is a fact about the WHOLE GLYPH — the crossbar of an H is not a
    // terminal at either end, and nothing local to that stroke knows it.
    const live = [];
    for (let i = 0; i < sk.s.length; i++) {
      const st = sk.s[i];
      if (!st.p || !st.p.length) continue;
      live.push({ st: st, pts: samplePts(st, h, map, capH) });
    }
    const rings = [];
    const holes = [];
    for (let i = 0; i < live.length; i++) {
      // A point mark is the pen SET DOWN, not dragged: it has no direction, so
      // the sweep model has nothing to sweep and produces a 0.6px sliver.
      if (live[i].st.d) {
        rings.push(dotRing(live[i].pts[0], full * 1.15));
        holes.push(false);
        continue;
      }
      const others = [];
      for (let j = 0; j < live.length; j++) if (j !== i) others.push(live[j].pts);
      const out = strokeRings(live[i].st, live[i].pts, h, full, capH, others);
      rings.push(out[0]);
      holes.push(false);
      if (out.length > 1) { rings.push(out[1]); holes.push(true); }
    }
    return { rings: rings, holes: holes, advance: adv };
  };

  /**
   * Advance width of a string, in px, including tracking.
   * @param {string} text Text.
   * @param {string} handId Hand id.
   * @param {number} capH Cap height, px.
   * @returns {number} Width, px.
   */
  A.measure = function (text, handId, capH) {
    const h = A.hand(handId);
    const s = String(text == null ? '' : text).toUpperCase();
    let w = 0;
    let drawn = 0;
    for (let i = 0; i < s.length; i++) {
      const sk = A.skeletonFor(s[i], handId);
      if (!sk) continue;
      w += sk.w * h.widthMul * capH;
      drawn++;
    }
    if (drawn > 1) w += (drawn - 1) * h.track * capH;
    return w;
  };

  /**
   * Fit a line of text to a width by choosing a cap height.
   *
   * A fitter that can fail to fit MUST say so, and every
   * caller in this product reads `fits`. "SEVEN OF WANDS" once shipped as
   * "SEVEN OF WAND" because a fitter returned a too-wide result and the caller
   * drew it anyway.
   *
   * @param {string} text Text.
   * @param {string} handId Hand id.
   * @param {number} maxW Available width, px.
   * @param {number} maxCap Largest cap height to try, px.
   * @param {number} minCap Smallest acceptable cap height, px.
   * @returns {{capH:number, width:number, fits:boolean}}
   */
  A.fit = function (text, handId, maxW, maxCap, minCap) {
    const lo = Math.max(4, minCap || 12);
    let cap = Math.max(lo, maxCap);
    const at1 = A.measure(text, handId, 1);
    if (at1 <= 0) return { capH: cap, width: 0, fits: true };
    cap = Math.min(cap, maxW / at1);
    return { capH: cap, width: at1 * cap, fits: cap >= lo };
  };

  //===========================================================================
  // THE CUTS — how a letter meets the material it is set in.
  //
  // Not decoration: a cut is the only reason an incised letter is visible at
  // all. There is no ink in a carved inscription, only the shadow the groove
  // casts, so every cut here states its separation ABSOLUTELY and solves for it.
  // shade(x, 1.2) would make the letters on a dark ground
  // invisible while every mechanical check stayed green.
  //===========================================================================

  /** @type {string[]} Cut ids in a stable order. */
  A.CUT_IDS = ['incised', 'raised', 'inlaid', 'printed'];

  /**
   * How far the relief flanks are offset from the face, in px.
   *
   * NOT capH * 0.032. MEASURED on the second contact sheet: a hand with real
   * thick/thin contrast has arms at `thin` of its stem, and at specimen size a
   * lapidary arm is 2.0px wide while capH * 0.032 asks for a 1.28px offset —
   * two thirds of the whole stroke. The result is that thick-stemmed letters
   * read as solid ink and thin ones read as edge-lighting, so KINGDOM came out
   * with a bold KI and a washed NGDOM. Nothing threw and every letter was
   * drawn.
   *
   * The offset therefore has to be derived from the THINNEST mark the hand can
   * make, not from the cap height. The resolution floor
   * is a number: measure it and author above it — with the usual absolute floor
   * because below a pixel a relief flank does nothing at all.
   *
   * @param {number} capH Cap height, px.
   * @param {string} handId Hand id.
   * @returns {number} Offset in px.
   */
  A.reliefOffset = function (capH, handId) {
    const h = A.hand(handId);
    const thinHalf = (h.weight * capH * 0.5) * h.thin;
    return Math.max(1, Math.min(capH * 0.032, thinHalf * 0.9));
  };

  /**
   * Draw one line of text, cut into a material.
   *
   * @param {object} rec Recorder.
   * @param {string} text The line.
   * @param {object} o Options:
   *   {number} x Left edge, px.
   *   {number} baseY Baseline, px.
   *   {number} capH Cap height, px.
   *   {string} hand Hand id.
   *   {string} cut Cut id.
   *   {number[]} ground Colour the letters sit on.
   *   {number[]} ink Ink or inlay colour (used by inlaid and printed).
   *   {number} [delta] Luminance separation to solve for. Default 46.
   * @returns {{width:number, glyphs:number, missing:string[]}}
   */
  A.drawLine = function (rec, text, o) {
    const r = R();
    const s = String(text == null ? '' : text).toUpperCase();
    const capH = o.capH;
    const ground = o.ground || [128, 128, 128];
    const delta = o.delta == null ? 46 : o.delta;
    const off = A.reliefOffset(capH, o.hand);

    const shadow = r.relief(ground, -1, delta);
    const lit = r.relief(ground, 1, Math.round(delta * 0.72));
    const floorCol = r.relief(ground, -1, Math.round(delta * 0.42));

    let x = o.x;
    let drawn = 0;
    const missing = [];
    const h = A.hand(o.hand);

    for (let i = 0; i < s.length; i++) {
      const g = A.glyphRings(s[i], o.hand, x, o.baseY, capH);
      if (!g) {
        if (missing.indexOf(s[i]) < 0) missing.push(s[i]);
        continue;
      }
      if (g.rings.length) {
        paint(rec, g, o.cut, { shadow: shadow, lit: lit, floor: floorCol, ink: o.ink, off: off });
        rec.glyph();
      }
      x += g.advance + h.track * capH;
      drawn++;
    }
    return {
      width: drawn ? x - o.x - h.track * capH : 0,
      glyphs: drawn,
      missing: missing,
    };
  };

  /**
   * Fill one glyph's rings, offset, in one colour.
   * The counter of a closed loop is a HOLE in the same path, filled even-odd —
   * canvas has no "punch a hole in what I already drew", and
   * opening a second path with the bounding box fills a solid black square.
   *
   * @param {object} rec Recorder.
   * @param {object} g Glyph rings.
   * @param {number} dx Offset x. @param {number} dy Offset y.
   * @param {number[]} col Colour.
   */
  function fillGlyph(rec, g, dx, dy, col) {
    const r = R();
    const style = r.css(col);
    for (let i = 0; i < g.rings.length; i++) {
      if (g.holes[i]) continue;
      const solid = shift(g.rings[i], dx, dy);
      rec.polyPath(solid);
      if (i + 1 < g.rings.length && g.holes[i + 1]) {
        rec.subPoly(shift(g.rings[i + 1], dx, dy));
      }
      rec.fillEvenOdd(style);
    }
  }

  /**
   * @param {number[][]} ring Points.
   * @param {number} dx Offset x. @param {number} dy Offset y.
   * @returns {number[][]} Shifted copy.
   */
  function shift(ring, dx, dy) {
    const out = new Array(ring.length);
    for (let i = 0; i < ring.length; i++) out[i] = [ring[i][0] + dx, ring[i][1] + dy];
    return out;
  }

  /**
   * Bounding box of a glyph's rings, px.
   * @param {object} g Glyph rings.
   * @returns {{x0:number, y0:number, x1:number, y1:number}}
   */
  function bboxOf(g) {
    let x0 = Infinity;
    let y0 = Infinity;
    let x1 = -Infinity;
    let y1 = -Infinity;
    for (let i = 0; i < g.rings.length; i++) {
      const ring = g.rings[i];
      for (let j = 0; j < ring.length; j++) {
        if (ring[j][0] < x0) x0 = ring[j][0];
        if (ring[j][0] > x1) x1 = ring[j][0];
        if (ring[j][1] < y0) y0 = ring[j][1];
        if (ring[j][1] > y1) y1 = ring[j][1];
      }
    }
    return { x0: x0, y0: y0, x1: x1, y1: y1 };
  }

  /**
   * Fill a glyph's face with a vertical gradient.
   *
   * A flat fill cannot read as METAL. It is the same law
   * one level over: a flat stroke gives an outline, a gradient stroke gives an
   * edge with thickness — and an inlay is the same problem: brass seated in a
   * cut bed catches the light along its top and goes dull at its foot, and
   * without that it is just a bright shape.
   *
   * @param {object} rec Recorder.
   * @param {object} g Glyph rings.
   * @param {Array<Array>} stops [[offset, cssColour], ...].
   */
  function fillGlyphGradient(rec, g, stops) {
    const b = bboxOf(g);
    for (let i = 0; i < g.rings.length; i++) {
      if (g.holes[i]) continue;
      rec.polyPath(g.rings[i]);
      if (i + 1 < g.rings.length && g.holes[i + 1]) rec.subPoly(g.rings[i + 1]);
      rec.fillGradientEvenOdd([b.x0, b.y0], [b.x0, b.y1], stops);
    }
  }

  /**
   * Paint one glyph in a cut.
   * @param {object} rec Recorder.
   * @param {object} g Glyph rings.
   * @param {string} cut Cut id.
   * @param {object} c {shadow, lit, floor, ink, off}.
   */
  function paint(rec, g, cut, c) {
    const r = R();
    const off = c.off;
    switch (cut) {
      case 'raised':
        // Light from the upper left: the top-left edge catches it, the
        // bottom-right throws the shadow, the face sits between them.
        fillGlyph(rec, g, off, off, c.shadow);
        fillGlyph(rec, g, -off * 0.7, -off * 0.7, c.lit);
        fillGlyph(rec, g, 0, 0, r.mix(c.lit, c.floor, 0.45));
        break;
      case 'inlaid': {
        // A BED CUT ALL THE WAY ROUND, then metal seated into it.
        //
        // MEASURED on the second contact sheet: inlaid and printed rendered as
        // the same picture in four rows of five, because both were "a bright
        // fill with a one-pixel edge". Two cells that read as
        // the same cell make the whole set look generated, and the fix is
        // never to tint one of them differently — it is to make them different
        // OBJECTS. An inlay is metal in a groove: it has a bed on every side,
        // not a drop shadow, and its face catches the light along its top.
        const ink = c.ink || c.lit;
        for (let k = 0; k < 4; k++) {
          const a = (Math.PI / 4) + (k * Math.PI) / 2;
          fillGlyph(rec, g, Math.cos(a) * off * 0.95, Math.sin(a) * off * 0.95, c.shadow);
        }
        fillGlyphGradient(rec, g, [
          [0, r.css(r.relief(ink, 1, 26))],
          [0.55, r.css(ink)],
          [1, r.css(r.relief(ink, -1, 30))],
        ]);
        break;
      }
      case 'printed':
        // FLAT. No bed, no lit flank, no relief of any kind — ink lies ON a
        // surface and that flatness is the whole difference from an inlay.
        fillGlyph(rec, g, 0, 0, c.ink || c.shadow);
        break;
      case 'incised':
      default:
        // A V-groove under a light from the upper left. The UPPER-LEFT flank is
        // the one in shadow, which is the opposite of a raised letter and is
        // the entire difference between carved-in and cast-on.
        fillGlyph(rec, g, -off * 0.85, -off * 0.85, c.shadow);
        fillGlyph(rec, g, off * 0.7, off * 0.7, c.lit);
        fillGlyph(rec, g, 0, 0, c.floor);
        break;
    }
  }

  /**
   * Draw a line in a FONT rather than from the corpus — the honest fallback for
   * a title in a script this Latin corpus does not carry.
   *
   * It is still lettered by this product: same cut model, same separation, same
   * relief. What changes is where the outline comes from. It never uses
   * $gameSystem.mainFontFace().
   *
   * @param {object} rec Recorder.
   * @param {string} text The line.
   * @param {object} o Same options as drawLine, plus {family}.
   * @returns {{width:number}}
   */
  A.drawLineFont = function (rec, text, o) {
    const r = R();
    const ground = o.ground || [128, 128, 128];
    const delta = o.delta == null ? 46 : o.delta;
    const off = Math.max(1, o.capH * 0.030);
    const shadow = r.relief(ground, -1, delta);
    const lit = r.relief(ground, 1, Math.round(delta * 0.72));
    const floorCol = r.relief(ground, -1, Math.round(delta * 0.42));
    const size = o.capH * 1.36;
    const style = {
      size: size, family: o.family || r.FONT_DISPLAY,
      colour: shadow, weight: '600', align: 'left', track: o.capH * 0.10,
    };
    const w = r.trackedWidth(rec, text, style);
    const passes = o.cut === 'raised'
      ? [[off, off, shadow], [-off * 0.7, -off * 0.7, lit], [0, 0, r.mix(lit, floorCol, 0.45)]]
      : [[-off * 0.85, -off * 0.85, shadow], [off * 0.7, off * 0.7, lit],
        [0, 0, o.cut === 'inlaid' || o.cut === 'printed' ? (o.ink || floorCol) : floorCol]];
    for (let i = 0; i < passes.length; i++) {
      style.colour = passes[i][2];
      r.tracked(rec, text, o.x + passes[i][0], o.baseY + passes[i][1], style);
    }
    return { width: w };
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.Ident.Alphabet;
