//=============================================================================
// IdentCore.js — Ident [3/4]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Ident [3/4]: the treatments. Fifteen worked materials, fourteen motions, forty named treatments, each one a different material or a different motion from every other.
 * @author Core Systems Asset Factory
 *
 * @help IdentCore.js
 *
 * Part 3 of 4. Adds no commands and changes no engine behaviour on its own;
 * Ident.js plays what this file draws.
 *
 * A TREATMENT is a MATERIAL (what the letters and the ground are made of: gold
 * foil, ink on paper, neon tube, carved slate, satin stitch, wax, pixels...)
 * and a MOTION (how the name arrives: struck, swept by light, written,
 * bled, flickered on, chiselled, stitched, assembled, powered on...). The
 * forty treatments are forty different (material, motion) pairs: no two share
 * both, so no treatment is another one in a different colour.
 *
 * The studio name is the SEED. It picks the palette inside the material, the
 * grain of the ground, the flicker order and the debris, so two studios that
 * choose the same treatment still get two different marks.
 *
 * The name is CUT from the authored letterform corpus in IdentAlphabet.js
 * (Latin capitals, digits and common punctuation). A character outside it is
 * set in a serif display font stack instead; the engine's own font is never
 * used.
 */

var CSAF = CSAF || {};
CSAF.Ident = CSAF.Ident || {};

(function () {
  'use strict';

  const C = {};
  CSAF.Ident.Core = C;
  C.VERSION = '1.0.0';

  // siblings are resolved at FIRST USE, so any Plugin Manager order works
  function R() { const r = CSAF.Ident.Render; if (!r) throw new Error('Ident: IdentRender.js is not loaded. Turn it on in the Plugin Manager.'); return r; }
  function A() { const a = CSAF.Ident.Alphabet; if (!a) throw new Error('Ident: IdentAlphabet.js is not loaded. Turn it on in the Plugin Manager.'); return a; }

  const TAU = Math.PI * 2;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const lerp = (a, b, t) => a + (b - a) * t;
  const ease = {
    out: (t) => 1 - Math.pow(1 - t, 3),
    inOut: (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),
    back: (t) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); },
    bounce: (t) => {
      const n = 7.5625, d = 2.75;
      if (t < 1 / d) return n * t * t;
      if (t < 2 / d) { t -= 1.5 / d; return n * t * t + 0.75; }
      if (t < 2.5 / d) { t -= 2.25 / d; return n * t * t + 0.9375; }
      t -= 2.625 / d; return n * t * t + 0.984375;
    },
  };
  C.ease = ease;
  /** Local progress of item i of n inside a global progress u, with `span` of the whole each item takes. */
  function stagger(u, i, n, span) {
    const s = clamp(span, 0.05, 1);
    const start = n > 1 ? (1 - s) * i / (n - 1) : 0;
    // snapped: (1 - s) + s is not always exactly 1 in floating point, and an arrival must END at rest, not 1e-14 short of it
    const k = (u - start) / s;
    return k >= 1 - 1e-9 ? 1 : clamp(k, 0, 1);
  }
  C.stagger = stagger;

  // ── colour ──────────────────────────────────────────────────────────────────────────────────────
  const hex = (h) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
  const css = (c, a) => (a == null ? `rgb(${c[0] | 0},${c[1] | 0},${c[2] | 0})` : `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${a})`);
  const mix = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
  const shade = (c, k) => (k >= 0 ? mix(c, [255, 255, 255], k) : mix(c, [0, 0, 0], -k));

  // ── canvas helpers (browser only; plan() needs none of them) ────────────────────────────────────
  function mk(w, h) { const c = document.createElement('canvas'); c.width = Math.max(1, Math.ceil(w)); c.height = Math.max(1, Math.ceil(h)); return c; }
  function tint(mask, col, alpha) {
    const c = mk(mask.width, mask.height), g = c.getContext('2d');
    g.drawImage(mask, 0, 0); g.globalCompositeOperation = 'source-in'; g.fillStyle = css(col, alpha == null ? 1 : alpha); g.fillRect(0, 0, c.width, c.height);
    return c;
  }
  function texIn(mask, paint) {
    const c = mk(mask.width, mask.height), g = c.getContext('2d');
    paint(g, c.width, c.height); g.globalCompositeOperation = 'destination-in'; g.drawImage(mask, 0, 0);
    return c;
  }
  function blurred(src, px) {
    const c = mk(src.width, src.height), g = c.getContext('2d');
    g.filter = `blur(${px}px)`; g.drawImage(src, 0, 0); g.filter = 'none';
    return c;
  }
  /** A field computed at reduced resolution and scaled up smoothly, so a full-frame ground costs ~1/16 of a pixel loop. */
  function field(w, h, step, fn) {
    const fw = Math.ceil(w / step), fh = Math.ceil(h / step);
    const c = mk(fw, fh), g = c.getContext('2d'), img = g.createImageData(fw, fh), d = img.data;
    for (let y = 0; y < fh; y++) for (let x = 0; x < fw; x++) {
      const col = fn(x * step, y * step);
      const i = (y * fw + x) * 4; d[i] = col[0]; d[i + 1] = col[1]; d[i + 2] = col[2]; d[i + 3] = 255;
    }
    g.putImageData(img, 0, 0);
    const out = mk(w, h), o = out.getContext('2d');
    o.imageSmoothingEnabled = true; o.drawImage(c, 0, 0, w, h);
    return out;
  }
  /** Fine per-pixel grain, cheap (a hash, not a noise), at alpha `a`: the tooth of paper, board or stone. */
  function grain(g, w, h, seed, a, lightOnly) {
    const img = g.getImageData(0, 0, w, h), d = img.data;
    let s = seed >>> 0;
    for (let i = 0; i < d.length; i += 4) {
      s = (Math.imul(s ^ (s >>> 15), 0x2c1b3c6d) + 0x297a2d39) >>> 0;
      const v = ((s >>> 8) / 16777216 - (lightOnly ? 0 : 0.5)) * a * 255;
      d[i] = clamp(d[i] + v, 0, 255); d[i + 1] = clamp(d[i + 1] + v, 0, 255); d[i + 2] = clamp(d[i + 2] + v, 0, 255);
    }
    g.putImageData(img, 0, 0);
  }
  function vignette(g, w, h, strength) {
    const r = g.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.25, w / 2, h / 2, Math.max(w, h) * 0.75);
    r.addColorStop(0, 'rgba(0,0,0,0)'); r.addColorStop(1, `rgba(0,0,0,${strength})`);
    g.fillStyle = r; g.fillRect(0, 0, w, h);
  }
  const fbm = (x, y, seed, oct) => R().fbm(x, y, seed, oct);

  /** Fill one glyph (rings in local px) as a white mask, union of its strokes, counters punched even-odd. */
  function fillGlyphPath(g, glyph, dx, dy) {
    for (let i = 0; i < glyph.rings.length; i++) {
      if (glyph.holes[i]) continue;
      g.beginPath();
      const ring = glyph.rings[i];
      g.moveTo(ring[0][0] + dx, ring[0][1] + dy);
      for (let k = 1; k < ring.length; k++) g.lineTo(ring[k][0] + dx, ring[k][1] + dy);
      g.closePath();
      if (i + 1 < glyph.rings.length && glyph.holes[i + 1]) {
        const h = glyph.rings[i + 1];
        g.moveTo(h[0][0] + dx, h[0][1] + dy);
        for (let k = 1; k < h.length; k++) g.lineTo(h[k][0] + dx, h[k][1] + dy);
        g.closePath();
      }
      g.fill('evenodd');
    }
  }
  function strokeGlyphPath(g, glyph, dx, dy) {
    for (let i = 0; i < glyph.rings.length; i++) {
      const ring = glyph.rings[i];
      g.beginPath(); g.moveTo(ring[0][0] + dx, ring[0][1] + dy);
      for (let k = 1; k < ring.length; k++) g.lineTo(ring[k][0] + dx, ring[k][1] + dy);
      g.closePath(); g.stroke();
    }
  }
  /** Stroke a letter's outline: its cut rings, or, for a character outside the corpus, the fallback font's outline
   *  (a material whose face IS its outline, the neon tube, would otherwise draw nothing for that character). */
  function strokeLetter(g, L) {
    if (L.glyph.rings.length) { strokeGlyphPath(g, L.glyph, L.dx, L.dy); return; }
    if (!L.text) return;
    g.font = L.text.font; g.textBaseline = 'alphabetic'; g.strokeText(L.text.ch, L.text.x, L.text.y);
  }
  C.FONT_FALLBACK = "'Palatino Linotype', 'Book Antiqua', Palatino, Georgia, 'Times New Roman', serif";

  //===============================================================================================
  // MATERIALS. ground(g, w, h, rng, pal, seed) paints the full frame; face(L) returns the finished
  // letter canvas from the letter's MASK. Each material builds its face by a different CONSTRUCTION
  // (an outline tube, a stitch field, a cell raster, a stipple, a relief...), never by recolouring.
  //===============================================================================================
  const M = {};

  M.foil = {
    label: 'Foil', construction: 'metallic gradient face, struck in with a hairline shadow',
    palettes: [
      { name: 'gold on navy', ground: hex('#162038'), metal: ['#5a3d0e', '#f6dc8a', '#b8862b', '#fff3c8', '#7a5414'] },
      { name: 'silver on oxblood', ground: hex('#3a1016'), metal: ['#4d5157', '#f2f4f7', '#9aa1aa', '#ffffff', '#5d636b'] },
      { name: 'copper on black', ground: hex('#121112'), metal: ['#4a1f0d', '#f2b07a', '#b5643a', '#ffe0c4', '#6b2c12'] },
    ],
    ground(g, w, h, rng, pal, seed) {
      g.drawImage(field(w, h, 4, (x, y) => shade(pal.ground, (fbm(x / 90, y / 90, seed, 3) - 0.5) * 0.25)), 0, 0);
      grain(g, w, h, seed, 0.06); vignette(g, w, h, 0.45);
    },
    face(L) {
      const sh = tint(L.mask, [0, 0, 0], 0.55);
      const face = texIn(L.mask, (g, w, h) => {
        const gr = g.createLinearGradient(0, L.top, 0, L.bottom);
        const m = L.pal.metal; [0, 0.32, 0.55, 0.72, 1].forEach((o, i) => gr.addColorStop(o, m[i]));
        g.fillStyle = gr; g.fillRect(0, 0, w, h);
        for (let k = 0; k < w * h / 900; k++) { g.fillStyle = 'rgba(255,255,240,0.55)'; g.fillRect(L.rng() * w, L.rng() * h, 1, 1); }
      });
      const c = mk(L.w, L.h), g = c.getContext('2d');
      g.drawImage(sh, L.off * 0.8, L.off * 1.2); g.drawImage(face, 0, 0);
      return c;
    },
  };

  M.ink = {
    label: 'Ink', construction: 'ink pooled into paper: a feathered bleed under a ragged edge cut by noise',
    palettes: [
      { name: 'sumi on cream', ground: hex('#efe6d2'), ink: hex('#141210') },
      { name: 'indigo on rice paper', ground: hex('#f3efe4'), ink: hex('#1c2a55') },
      { name: 'sepia on parchment', ground: hex('#e8d6b0'), ink: hex('#4a2a14') },
    ],
    ground(g, w, h, rng, pal, seed) {
      g.drawImage(field(w, h, 3, (x, y) => shade(pal.ground, -(fbm(x / 140, y / 140, seed, 4) - 0.5) * 0.12)), 0, 0);
      g.strokeStyle = css(shade(pal.ground, -0.12), 0.25); g.lineWidth = 0.6;
      for (let k = 0; k < 220; k++) { const x = rng() * w, y = rng() * h, a = rng() * TAU, l = 6 + rng() * 22; g.beginPath(); g.moveTo(x, y); g.quadraticCurveTo(x + Math.cos(a) * l * 0.5 + rng() * 4, y + Math.sin(a) * l * 0.5, x + Math.cos(a) * l, y + Math.sin(a) * l); g.stroke(); }
      grain(g, w, h, seed, 0.05); vignette(g, w, h, 0.18);
    },
    face(L) {
      const halo = tint(blurred(L.mask, L.capH * 0.05), L.pal.ink, 0.28);
      const soft = blurred(L.mask, Math.max(0.8, L.capH * 0.012));
      const g0 = soft.getContext('2d'), img = g0.getImageData(0, 0, soft.width, soft.height), d = img.data;
      for (let i = 0, p = 0; i < d.length; i += 4, p++) {
        const x = p % soft.width, y = (p / soft.width) | 0;
        const n = R().snoise(x / 3.1, y / 3.1, L.seed) - 0.5;
        const a = clamp((d[i + 3] / 255 + n * 0.55 - 0.42) * 6, 0, 1);
        d[i] = L.pal.ink[0]; d[i + 1] = L.pal.ink[1]; d[i + 2] = L.pal.ink[2]; d[i + 3] = a * 255;
      }
      g0.putImageData(img, 0, 0);
      const c = mk(L.w, L.h), g = c.getContext('2d'); g.drawImage(halo, 0, 0); g.drawImage(soft, 0, 0);
      return c;
    },
  };

  M.letterpress = {
    label: 'Letterpress', construction: 'debossed into thick board: ink in the bed, shadow on the upper lip, light on the lower',
    palettes: [
      { name: 'vermilion on cotton', ground: hex('#f1ece2'), ink: hex('#c23a22') },
      { name: 'black on cotton', ground: hex('#ece7dc'), ink: hex('#1d1b1a') },
      { name: 'navy on grey board', ground: hex('#d9d6cf'), ink: hex('#1f3058') },
    ],
    ground(g, w, h, rng, pal, seed) {
      g.fillStyle = css(pal.ground); g.fillRect(0, 0, w, h);
      g.drawImage(field(w, h, 4, (x, y) => shade(pal.ground, (fbm(x / 60, y / 60, seed, 3) - 0.5) * 0.06)), 0, 0);
      grain(g, w, h, seed, 0.07); vignette(g, w, h, 0.22);
    },
    face(L) {
      const c = mk(L.w, L.h), g = c.getContext('2d');
      g.drawImage(tint(L.mask, shade(L.pal.ground, 0.5), 0.9), L.off * 0.9, L.off * 0.9);
      g.drawImage(tint(L.mask, L.pal.ink), 0, 0);
      // the upper lip of the bed: the mask shifted down-right, cut back to the letter, reads as a shadow inside the impression
      const lip = tint(L.mask, [0, 0, 0], 0.45), lg = lip.getContext('2d');
      lg.globalCompositeOperation = 'destination-out'; lg.drawImage(L.mask, L.off * 1.4, L.off * 1.4);
      g.drawImage(lip, 0, 0);
      return c;
    },
  };

  M.neon = {
    label: 'Neon', construction: 'the letter OUTLINE bent as a glass tube: a glow, a coloured tube and a white hot core, on brick',
    palettes: [
      { name: 'hot pink', tube: hex('#ff3fa4'), wall: hex('#2a1d22') },
      { name: 'ice cyan', tube: hex('#3fe6ff'), wall: hex('#1b2024') },
      { name: 'amber', tube: hex('#ffad33'), wall: hex('#24191a') },
    ],
    ground(g, w, h, rng, pal, seed) {
      const bh = Math.round(h / 22), bw = bh * 2.6;
      g.fillStyle = css(shade(pal.wall, -0.45)); g.fillRect(0, 0, w, h);
      for (let row = 0, y = 0; y < h; row++, y += bh) {
        for (let x = -((row % 2) * bw) / 2; x < w; x += bw) {
          g.fillStyle = css(shade(pal.wall, (rng() - 0.5) * 0.25)); g.fillRect(x + 1.5, y + 1.5, bw - 3, bh - 3);
        }
      }
      grain(g, w, h, seed, 0.08); vignette(g, w, h, 0.65);
    },
    face(L) {
      const c = mk(L.w, L.h), g = c.getContext('2d'), lw = Math.max(1.5, L.capH * 0.035);
      g.lineJoin = 'round'; g.lineCap = 'round';
      g.shadowColor = css(L.pal.tube, 0.95); g.shadowBlur = L.capH * 0.22; g.strokeStyle = css(L.pal.tube); g.lineWidth = lw * 1.6;
      strokeLetter(g, L); strokeLetter(g, L);
      g.shadowBlur = 0; g.strokeStyle = css(shade(L.pal.tube, 0.75)); g.lineWidth = lw * 0.55;
      strokeLetter(g, L);
      return c;
    },
  };

  M.slate = {
    label: 'Carved slate', construction: 'a fresh cut: the letter shows the paler stone under the weathered face, a shadowed upper flank and a lit lower one',
    palettes: [
      { name: 'blue slate', stone: hex('#3b4552') },
      { name: 'charcoal', stone: hex('#2f2f31') },
      { name: 'green slate', stone: hex('#34433b') },
    ],
    ground(g, w, h, rng, pal, seed) {
      g.drawImage(field(w, h, 3, (x, y) => shade(pal.stone, (fbm(x / 260, y / 26, seed, 4) - 0.5) * 0.5)), 0, 0);
      g.strokeStyle = css(shade(pal.stone, -0.35), 0.5); g.lineWidth = 1;
      for (let k = 0; k < 14; k++) { const y = rng() * h; g.beginPath(); g.moveTo(0, y); for (let x = 0; x <= w; x += 40) g.lineTo(x, y + (rng() - 0.5) * 6); g.stroke(); }
      grain(g, w, h, seed, 0.09); vignette(g, w, h, 0.4);
    },
    face(L) {
      // a dark groove on dark slate vanished (contact sheet, 2026-10-12): a cut reads because fresh stone is PALER than
      // its weathered face, so the floor is light and the shadowed upper flank does the carving. The flank is a SHIFT of the
      // letter by o, so any stroke thinner than o is ALL flank: at 1.3 x the relief offset the thin arms of E, L and T went
      // dark on dark stone and GAMES read GAMFS (fresh review, 2026-10-12); the shift is held under the thinnest arm
      const c = mk(L.w, L.h), g = c.getContext('2d'), o = Math.max(1, L.off * 0.55);
      g.drawImage(tint(L.mask, shade(L.pal.stone, 0.5)), 0, 0);
      g.drawImage(texIn(L.mask, (q, w, h) => { for (let k = 0; k < w * h / 60; k++) { q.fillStyle = `rgba(255,255,255,${0.15 + L.rng() * 0.2})`; q.fillRect(L.rng() * w, L.rng() * h, 1.5, 1.5); } }), 0, 0);
      const flank = tint(L.mask, shade(L.pal.stone, -0.55)), fg = flank.getContext('2d');
      fg.globalCompositeOperation = 'destination-out'; fg.drawImage(L.mask, o, o);
      g.drawImage(flank, 0, 0);
      return c;
    },
  };

  M.marble = {
    label: 'Marble with metal inlay', construction: 'an incised groove filled with metal leaf, in veined marble',
    palettes: [
      { name: 'carrara and gold', stone: hex('#e9e6e0'), vein: hex('#8b8a8f'), leaf: ['#7a5a12', '#f4d985', '#b88a2e'] },
      { name: 'nero and gold', stone: hex('#1d1c1e'), vein: hex('#d8d4cc'), leaf: ['#7a5a12', '#f4d985', '#b88a2e'] },
      { name: 'verde and silver', stone: hex('#1f3a2f'), vein: hex('#cfe1d6'), leaf: ['#5b6168', '#f4f6f8', '#a5acb5'] },
    ],
    ground(g, w, h, rng, pal, seed) {
      g.drawImage(field(w, h, 2, (x, y) => {
        const v = Math.abs(Math.sin((x * 0.006 + y * 0.004) * 6 + fbm(x / 120, y / 120, seed, 5) * 9));
        return mix(pal.stone, pal.vein, Math.pow(1 - v, 14) * 0.5); // 0.85 fought the inlay (fresh review)
      }), 0, 0);
      grain(g, w, h, seed, 0.03); vignette(g, w, h, 0.3);
    },
    face(L) {
      const c = mk(L.w, L.h), g = c.getContext('2d');
      g.drawImage(tint(L.mask, shade(L.pal.stone, -0.5), 0.8), L.off * 0.6, L.off * 0.6);
      g.drawImage(texIn(L.mask, (q, w, h) => { const gr = q.createLinearGradient(0, L.top, 0, L.bottom); L.pal.leaf.forEach((s, i) => gr.addColorStop(i / 2, s)); q.fillStyle = gr; q.fillRect(0, 0, w, h); }), 0, 0);
      return c;
    },
  };

  M.embroidery = {
    label: 'Embroidery', construction: 'satin stitch: parallel thread stitches clipped to the letter, each with its own sheen, on woven cloth',
    palettes: [
      { name: 'red on linen', cloth: hex('#cfc3a8'), thread: hex('#b3182c') },
      { name: 'gold on navy felt', cloth: hex('#1d2742'), thread: hex('#e3b448') },
      { name: 'white on forest', cloth: hex('#22402d'), thread: hex('#f2efe6') },
    ],
    ground(g, w, h, rng, pal, seed) {
      g.fillStyle = css(pal.cloth); g.fillRect(0, 0, w, h);
      for (let y = 0; y < h; y += 3) { g.fillStyle = css(shade(pal.cloth, ((y / 3) % 2 ? -0.06 : 0.04))); g.fillRect(0, y, w, 1.5); }
      for (let x = 0; x < w; x += 3) { g.fillStyle = css(shade(pal.cloth, ((x / 3) % 2 ? -0.05 : 0.03)), 0.6); g.fillRect(x, 0, 1.5, h); }
      grain(g, w, h, seed, 0.05); vignette(g, w, h, 0.35);
    },
    face(L) {
      const step = Math.max(2.2, L.capH * 0.03);
      const stitches = texIn(L.mask, (q, w, h) => {
        q.lineCap = 'round';
        for (let k = -h; k < w + h; k += step) {
          const t = L.pal.thread;
          q.strokeStyle = css(shade(t, -0.25)); q.lineWidth = step; q.beginPath(); q.moveTo(k, 0); q.lineTo(k + h * 0.6, h); q.stroke();
          q.strokeStyle = css(shade(t, 0.18 + L.rng() * 0.12)); q.lineWidth = step * 0.45; q.beginPath(); q.moveTo(k + step * 0.15, 0); q.lineTo(k + h * 0.6 + step * 0.15, h); q.stroke();
        }
      });
      const c = mk(L.w, L.h), g = c.getContext('2d');
      g.drawImage(tint(L.mask, [0, 0, 0], 0.35), L.off * 0.6, L.off * 0.8);
      g.drawImage(stitches, 0, 0);
      g.strokeStyle = css(shade(L.pal.thread, -0.45)); g.lineWidth = Math.max(1, L.capH * 0.012); g.setLineDash([3, 2]);
      strokeLetter(g, L);
      return c;
    },
  };

  M.wax = {
    label: 'Sealing wax', construction: 'a rounded raised pool: the letter swollen and recut, a glossy highlight and a cast shadow',
    palettes: [
      { name: 'red wax on parchment', ground: hex('#e6d3a8'), wax: hex('#9c1c1c') },
      { name: 'green wax on parchment', ground: hex('#e2d4b0'), wax: hex('#1f5a3a') },
      { name: 'black wax on linen', ground: hex('#d8d0c0'), wax: hex('#1d1a1c') },
    ],
    ground(g, w, h, rng, pal, seed) { M.ink.ground(g, w, h, rng, { ground: pal.ground }, seed); },
    face(L) {
      const swell = blurred(L.mask, Math.max(1, L.capH * 0.03));
      const sg = swell.getContext('2d'), img = sg.getImageData(0, 0, swell.width, swell.height), d = img.data;
      for (let i = 3; i < d.length; i += 4) d[i] = d[i] > 70 ? 255 : 0;
      sg.putImageData(img, 0, 0);
      const c = mk(L.w, L.h), g = c.getContext('2d');
      g.drawImage(tint(blurred(swell, L.capH * 0.03), [0, 0, 0], 0.5), L.off, L.off * 1.6);
      g.drawImage(texIn(swell, (q, w, h) => { const gr = q.createLinearGradient(0, L.top, 0, L.bottom); gr.addColorStop(0, css(shade(L.pal.wax, 0.25))); gr.addColorStop(1, css(shade(L.pal.wax, -0.35))); q.fillStyle = gr; q.fillRect(0, 0, w, h); }), 0, 0);
      const hl = tint(swell, [255, 255, 255], 0.5), hg = hl.getContext('2d');
      hg.globalCompositeOperation = 'destination-out'; hg.drawImage(swell, L.off * 0.9, L.off * 0.9);
      g.drawImage(hl, 0, 0);
      return c;
    },
  };

  M.pixel = {
    label: 'Pixel blocks', construction: 'the letter rasterised to a coarse grid of bevelled blocks',
    palettes: [
      { name: 'arcade cyan', ground: hex('#0c0f1c'), block: hex('#39d6ff'), grid: hex('#1b2238') },
      { name: 'handheld green', ground: hex('#9bbc0f'), block: hex('#0f380f'), grid: hex('#8bac0f') },
      { name: 'amber terminal', ground: hex('#140c04'), block: hex('#ffb000'), grid: hex('#2a1a08') },
    ],
    ground(g, w, h, rng, pal, seed) {
      g.fillStyle = css(pal.ground); g.fillRect(0, 0, w, h);
      g.strokeStyle = css(pal.grid, 0.6); g.lineWidth = 1;
      const s = Math.round(h / 40);
      for (let x = 0; x < w; x += s) { g.beginPath(); g.moveTo(x + 0.5, 0); g.lineTo(x + 0.5, h); g.stroke(); }
      for (let y = 0; y < h; y += s) { g.beginPath(); g.moveTo(0, y + 0.5); g.lineTo(w, y + 0.5); g.stroke(); }
      vignette(g, w, h, 0.35);
    },
    cells(L) {
      // The letter is THICKENED before it is rasterised: its outline is stroked at 0.7 of a cell over the filled mask, so a
      // stroke thinner than a cell still claims every cell it crosses. Thresholding the bare mask lost thin strokes: at
      // 0.42 GAMES read GAI IES, and at 0.2 the stave M still came out as an I and a v (full size frame, 2026-10-12).
      const cell = Math.max(3, Math.round(L.capH / 10));
      const thick = mk(L.w, L.h), tg = thick.getContext('2d');
      tg.drawImage(L.mask, 0, 0);
      tg.strokeStyle = '#fff'; tg.lineJoin = 'round'; tg.lineCap = 'round'; tg.lineWidth = cell * 0.7;
      strokeLetter(tg, L);
      const d = tg.getImageData(0, 0, L.w, L.h).data;
      const out = [];
      for (let y = 0; y < L.h; y += cell) for (let x = 0; x < L.w; x += cell) {
        let on = 0, n = 0;
        for (let yy = y; yy < Math.min(L.h, y + cell); yy++) for (let xx = x; xx < Math.min(L.w, x + cell); xx++) { n++; if (d[(yy * L.w + xx) * 4 + 3] > 127) on++; }
        if (on / n >= 0.35) out.push([x, y]);
      }
      return { cell, cells: out };
    },
    face(L) {
      const { cell, cells } = M.pixel.cells(L);
      L.cells = cells; L.cell = cell;
      const c = mk(L.w, L.h), g = c.getContext('2d'), b = L.pal.block;
      for (const [x, y] of cells) {
        g.fillStyle = css(shade(b, -0.35)); g.fillRect(x, y, cell, cell);
        g.fillStyle = css(shade(b, 0.3)); g.fillRect(x, y, cell - 1, cell - 1);
        g.fillStyle = css(b); g.fillRect(x + 1, y + 1, cell - 2, cell - 2);
      }
      return c;
    },
  };

  M.chalk = {
    label: 'Chalk', construction: 'a stipple: grains of chalk caught by the board inside the letter, thinning at the edge',
    palettes: [
      { name: 'white on slate board', board: hex('#232826'), chalk: hex('#f1efe6') },
      { name: 'yellow on green board', board: hex('#1f3a2c'), chalk: hex('#f5e27a') },
      { name: 'pink on black board', board: hex('#1b1b1d'), chalk: hex('#f3b5c8') },
    ],
    ground(g, w, h, rng, pal, seed) {
      g.drawImage(field(w, h, 4, (x, y) => shade(pal.board, (fbm(x / 180, y / 120, seed, 4) - 0.5) * 0.3)), 0, 0);
      g.strokeStyle = css(pal.chalk, 0.05); g.lineWidth = 18; g.lineCap = 'round';
      for (let k = 0; k < 6; k++) { g.beginPath(); const y = rng() * h; g.moveTo(rng() * w * 0.3, y); g.bezierCurveTo(w * 0.4, y + (rng() - 0.5) * 80, w * 0.6, y + (rng() - 0.5) * 80, w * (0.7 + rng() * 0.3), y + (rng() - 0.5) * 40); g.stroke(); }
      grain(g, w, h, seed, 0.06); vignette(g, w, h, 0.4);
    },
    face(L) {
      const soft = blurred(L.mask, Math.max(0.7, L.capH * 0.008));
      const g0 = soft.getContext('2d'), img = g0.getImageData(0, 0, soft.width, soft.height), d = img.data;
      let s = L.seed >>> 0;
      for (let i = 0, p = 0; i < d.length; i += 4, p++) {
        s = (Math.imul(s ^ (s >>> 15), 0x2c1b3c6d) + 0x297a2d39) >>> 0;
        const r = (s >>> 8) / 16777216;
        const x = p % soft.width, y = (p / soft.width) | 0;
        const streak = R().snoise(x / 1.5, y / 9, L.seed + 3);
        const keep = d[i + 3] / 255 * (0.55 + streak * 0.6) > r;
        d[i] = L.pal.chalk[0]; d[i + 1] = L.pal.chalk[1]; d[i + 2] = L.pal.chalk[2]; d[i + 3] = keep ? 235 : 0;
      }
      g0.putImageData(img, 0, 0);
      return soft;
    },
  };

  M.crt = {
    label: 'CRT phosphor', construction: 'phosphor light: a bloom, a colour ghost and scanlines through the letter, on a dark curved screen',
    palettes: [
      { name: 'green phosphor', phos: hex('#5cff7a') },
      { name: 'amber phosphor', phos: hex('#ffb347') },
      { name: 'white phosphor', phos: hex('#d8ecff') },
    ],
    ground(g, w, h, rng, pal, seed) {
      g.fillStyle = '#050706'; g.fillRect(0, 0, w, h);
      const r = g.createRadialGradient(w / 2, h / 2, 10, w / 2, h / 2, w * 0.7);
      r.addColorStop(0, css(shade(pal.phos, -0.88))); r.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = r; g.fillRect(0, 0, w, h);
      for (let y = 0; y < h; y += 3) { g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(0, y, w, 1); }
      vignette(g, w, h, 0.8);
    },
    face(L) {
      const c = mk(L.w, L.h), g = c.getContext('2d');
      g.drawImage(tint(blurred(L.mask, L.capH * 0.08), L.pal.phos, 0.55), 0, 0);
      g.globalCompositeOperation = 'lighter';
      g.drawImage(tint(L.mask, [255, 40, 60], 0.35), -1.5, 0);
      g.drawImage(tint(L.mask, [40, 120, 255], 0.35), 1.5, 0);
      g.globalCompositeOperation = 'source-over';
      g.drawImage(tint(L.mask, shade(L.pal.phos, 0.35)), 0, 0);
      g.globalCompositeOperation = 'destination-out';
      for (let y = 0; y < L.h; y += 3) { g.fillStyle = 'rgba(0,0,0,0.45)'; g.fillRect(0, y, L.w, 1); }
      return c;
    },
  };

  M.steel = {
    label: 'Engraved steel', construction: 'a graver cut in brushed metal: a dark groove with a bright burnished lower edge, on a screwed plate',
    palettes: [
      { name: 'brushed steel', metal: hex('#8c939b') },
      { name: 'titanium', metal: hex('#6c7686') },
      { name: 'brass plate', metal: hex('#a8873e') },
    ],
    ground(g, w, h, rng, pal, seed) {
      g.drawImage(field(w, h, 2, (x, y) => shade(pal.metal, (R().snoise(x / 400, y / 1.2, seed) - 0.5) * 0.35 + (fbm(x / 300, y / 300, seed + 5, 2) - 0.5) * 0.2)), 0, 0);
      const s = Math.round(h * 0.03);
      for (const [x, y] of [[s * 2, s * 2], [w - s * 2, s * 2], [s * 2, h - s * 2], [w - s * 2, h - s * 2]]) {
        g.fillStyle = css(shade(pal.metal, -0.4)); g.beginPath(); g.arc(x + 1, y + 1, s * 0.7, 0, TAU); g.fill();
        g.fillStyle = css(shade(pal.metal, 0.2)); g.beginPath(); g.arc(x, y, s * 0.7, 0, TAU); g.fill();
        g.strokeStyle = css(shade(pal.metal, -0.5)); g.lineWidth = 2; g.beginPath(); g.moveTo(x - s * 0.5, y - s * 0.2); g.lineTo(x + s * 0.5, y + s * 0.2); g.stroke();
      }
      vignette(g, w, h, 0.3);
    },
    face(L) {
      const c = mk(L.w, L.h), g = c.getContext('2d'), o = L.off;
      g.drawImage(tint(L.mask, shade(L.pal.metal, 0.6)), o * 0.7, o * 0.9);
      g.drawImage(tint(L.mask, shade(L.pal.metal, -0.65)), 0, 0);
      return c;
    },
  };

  M.wood = {
    label: 'Burned wood', construction: 'pyrography: a charred core with a scorched halo, in a sawn wood grain',
    palettes: [
      { name: 'oak', wood: hex('#b88b55') },
      { name: 'walnut', wood: hex('#6e4a2c') },
      { name: 'pine', wood: hex('#d7b17a') },
    ],
    ground(g, w, h, rng, pal, seed) {
      g.drawImage(field(w, h, 2, (x, y) => {
        const ring = Math.sin((y + fbm(x / 220, y / 40, seed, 4) * 70) * 0.18);
        return shade(pal.wood, ring * 0.12 + (fbm(x / 30, y / 400, seed + 2, 2) - 0.5) * 0.2);
      }), 0, 0);
      grain(g, w, h, seed, 0.05); vignette(g, w, h, 0.4);
    },
    face(L) {
      const c = mk(L.w, L.h), g = c.getContext('2d');
      g.drawImage(tint(blurred(L.mask, L.capH * 0.05), [40, 18, 6], 0.55), 0, 0);
      g.drawImage(tint(L.mask, [28, 14, 8]), 0, 0);
      return c;
    },
  };

  M.papercut = {
    label: 'Cut paper', construction: 'a sheet cut to the letter and lifted off the page on a soft cast shadow',
    palettes: [
      { name: 'cream on teal', ground: hex('#17575a'), paper: hex('#f4ead6') },
      { name: 'coral on navy', ground: hex('#1b2440'), paper: hex('#ff7e67') },
      { name: 'yellow on charcoal', ground: hex('#2a2b2e'), paper: hex('#f2c94c') },
    ],
    ground(g, w, h, rng, pal, seed) {
      g.fillStyle = css(pal.ground); g.fillRect(0, 0, w, h);
      g.drawImage(field(w, h, 4, (x, y) => shade(pal.ground, (fbm(x / 80, y / 80, seed, 3) - 0.5) * 0.08)), 0, 0);
      grain(g, w, h, seed, 0.05); vignette(g, w, h, 0.3);
    },
    face(L) {
      const c = mk(L.w, L.h), g = c.getContext('2d');
      g.drawImage(tint(blurred(L.mask, L.capH * 0.04), [0, 0, 0], 0.5), L.off * 1.5, L.off * 2.2);
      g.drawImage(texIn(L.mask, (q, w, h) => { const gr = q.createLinearGradient(0, L.top, 0, L.bottom); gr.addColorStop(0, css(shade(L.pal.paper, 0.1))); gr.addColorStop(1, css(shade(L.pal.paper, -0.1))); q.fillStyle = gr; q.fillRect(0, 0, w, h); }), 0, 0);
      return c;
    },
  };

  M.glass = {
    label: 'Frosted glass', construction: 'translucent frosted panes with a bright cut edge and a diagonal reflection, over soft lights',
    palettes: [
      { name: 'ice', ground: hex('#0d1724'), light: hex('#7fb8ff') },
      { name: 'emerald', ground: hex('#0b1a14'), light: hex('#5ef0a8') },
      { name: 'rose', ground: hex('#1d0e16'), light: hex('#ff8fb8') },
    ],
    ground(g, w, h, rng, pal, seed) {
      const gr = g.createLinearGradient(0, 0, w, h); gr.addColorStop(0, css(pal.ground)); gr.addColorStop(1, css(shade(pal.ground, 0.12))); g.fillStyle = gr; g.fillRect(0, 0, w, h);
      for (let k = 0; k < 28; k++) { const x = rng() * w, y = rng() * h, r = 8 + rng() * 40; const rg = g.createRadialGradient(x, y, 0, x, y, r); rg.addColorStop(0, css(pal.light, 0.22)); rg.addColorStop(1, css(pal.light, 0)); g.fillStyle = rg; g.fillRect(x - r, y - r, r * 2, r * 2); }
      vignette(g, w, h, 0.5);
    },
    face(L) {
      const c = mk(L.w, L.h), g = c.getContext('2d');
      g.drawImage(texIn(L.mask, (q, w, h) => {
        q.fillStyle = css(shade(L.pal.light, 0.6), 0.32); q.fillRect(0, 0, w, h);
        const gr = q.createLinearGradient(0, 0, w, h); gr.addColorStop(0.35, 'rgba(255,255,255,0)'); gr.addColorStop(0.5, 'rgba(255,255,255,0.45)'); gr.addColorStop(0.62, 'rgba(255,255,255,0)'); q.fillStyle = gr; q.fillRect(0, 0, w, h);
      }), 0, 0);
      g.strokeStyle = css(shade(L.pal.light, 0.7), 0.9); g.lineWidth = Math.max(1, L.capH * 0.014);
      strokeLetter(g, L);
      return c;
    },
  };
  C.MATERIALS = M;

  //===============================================================================================
  // MOTIONS. letter(u, i, n, L, P) returns the letter's state at intro progress u in [0, 1]:
  //   { a: alpha, dx, dy, s: scale, clip: null | { kind: 'x'|'y'|'yUp'|'circle'|'rows'|'strips', v }, blur }
  // under(g, P, u) and over(g, P, u, hold) draw what belongs to the motion rather than to a letter.
  // Every motion ends with every letter at rest (a 1, no offset, no clip) and word(1) = 1: asserted by the suite.
  // word(u), optional: a scale applied to the WHOLE name about its centre (letters move together).
  //===============================================================================================
  const REST = Object.freeze({ a: 1, dx: 0, dy: 0, s: 1, clip: null, blur: 0 });
  const st = (o) => Object.assign({ a: 1, dx: 0, dy: 0, s: 1, clip: null, blur: 0 }, o);
  const MO = {};

  MO.stamp = {
    label: 'Struck', note: 'the whole name is driven down onto the surface; dust jumps at the impact',
    // the name FALLS onto the surface as ONE word: it accelerates in (k squared). Scaled per letter about each letter's own
    // centre, neighbours overlapped mid fall into a tangle (in-engine photograph, 2026-10-12); the word scales about its centre
    letter(u) { const k = clamp(u / 0.42, 0, 1); return k >= 1 ? REST : st({ a: clamp(k * 2.5, 0, 1), blur: (1 - k) * 3 }); },
    word(u) { const k = clamp(u / 0.42, 0, 1); return k >= 1 ? 1 : lerp(1.9, 1, k * k); },
    over(g, P, u) {
      if (u < 0.42 || u > 0.9) return;
      const k = (u - 0.42) / 0.48, rng = R().rng(P.seed + 11);
      const r = Math.max(2, P.capH * 0.035);
      for (let p = 0; p < 140; p++) {
        const a = rng() * TAU, sp = 0.3 + rng(), x = P.box.cx + Math.cos(a) * P.box.w * 0.5 * (0.6 + k * sp), y = P.box.y1 + Math.sin(a) * P.capH * 0.6 * k * sp;
        g.fillStyle = css(P.dust, 0.85 * (1 - k)); g.fillRect(x, y, r * (0.5 + rng()), r * (0.5 + rng()));
      }
    },
    shake(u) { const k = (u - 0.42) / 0.14; return k > 0 && k < 1 ? Math.sin(k * 40) * (1 - k) * 4 : 0; },
  };
  MO.sweep = {
    label: 'Swept by light', note: 'the name fades up, then a band of light travels across it',
    letter(u, i, n) { const k = stagger(u, i, n, 0.5) * 2.2; return st({ a: clamp(k, 0, 1) }); },
    over(g, P, u, hold) {
      const k = clamp((u - 0.45) / 0.55, 0, 1);
      if (k <= 0 || k >= 1) return;
      const x = lerp(P.box.x0 - P.box.w * 0.3, P.box.x1 + P.box.w * 0.3, ease.inOut(k));
      const c = P.scratch, sg = c.getContext('2d');
      sg.clearRect(0, 0, c.width, c.height);
      const gr = sg.createLinearGradient(x - P.capH, 0, x + P.capH, 0);
      gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(0.5, 'rgba(255,255,255,0.85)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
      sg.fillStyle = gr; sg.fillRect(0, 0, c.width, c.height);
      sg.globalCompositeOperation = 'destination-in'; sg.drawImage(P.wordMask, 0, 0); sg.globalCompositeOperation = 'source-over';
      g.globalCompositeOperation = 'lighter'; g.drawImage(c, 0, 0); g.globalCompositeOperation = 'source-over';
    },
  };
  MO.write = {
    label: 'Written', note: 'each letter is drawn in turn from left to right, a lit nib at the leading edge',
    letter(u, i, n) { const k = stagger(u, i, n, 1.6 / Math.max(2, n)); return k >= 1 ? REST : st({ a: k > 0 ? 1 : 0, clip: { kind: 'x', v: k } }); },
    over(g, P, u) { const live = P.liveEdge; if (!live) return; g.fillStyle = css(P.glow, 0.9); g.beginPath(); g.arc(live.x, live.y, Math.max(2, P.capH * 0.04), 0, TAU); g.fill(); },
  };
  MO.bleed = {
    label: 'Bled in', note: 'the name soaks up out of a blur, from the middle letters outward',
    letter(u, i, n) { const mid = (n - 1) / 2, order = n > 1 ? Math.abs(i - mid) / mid : 0; const k = clamp((u - order * 0.35) / 0.6, 0, 1); return k >= 1 ? REST : st({ a: ease.out(k), blur: (1 - k) * 10 }); },
  };
  MO.flicker = {
    label: 'Flickered on', note: 'letters catch one at a time in a random order, stuttering before they hold',
    letter(u, i, n, L, P) {
      const at = P.order[i] / Math.max(1, n) * 0.7, k = (u - at) / 0.25;
      if (k <= 0) return st({ a: 0.06 });
      if (k >= 1) return REST;
      const on = Math.sin(k * 37 + i * 11) > -0.2 + k * 0.9 ? 1 : 0.15;
      return st({ a: on });
    },
    hum(hold, i) { return 0.93 + 0.07 * Math.sin(hold * 50 + i * 3); },
  };
  MO.chisel = {
    label: 'Chiselled', note: 'each letter is cut from the bottom up in hard steps, chips falling from the blade',
    letter(u, i, n) { const k = stagger(u, i, n, 2 / Math.max(2, n)); if (k >= 1) return REST; return st({ a: k > 0 ? 1 : 0, clip: { kind: 'yUp', v: Math.floor(k * 7) / 7 } }); },
    over(g, P, u) {
      const rng = R().rng(P.seed + 5);
      for (let p = 0; p < 60; p++) {
        const i = Math.floor(rng() * P.letters.length), L = P.letters[i], k = stagger(u, i, P.letters.length, 2 / Math.max(2, P.letters.length));
        if (k <= 0 || k >= 1) continue;
        const life = (k * 7) % 1, x = L.x + rng() * L.w, y = L.y + L.h * (1 - k) + life * P.capH * 0.6 * (0.5 + rng());
        g.fillStyle = css(P.dust, 0.8 * (1 - life)); g.fillRect(x, y, 2 + rng() * 2, 2);
      }
    },
  };
  MO.stitch = {
    label: 'Row by row', note: 'each letter is laid down row by row, a needle (or a raster beam) bright where the line is',
    letter(u, i, n) { const k = stagger(u, i, n, 1.8 / Math.max(2, n)); return k >= 1 ? REST : st({ a: k > 0 ? 1 : 0, clip: { kind: 'rows', v: k } }); },
    over(g, P) {
      const live = P.liveEdge; if (!live) return;
      // thread gets a needle; anything else drawn row by row (pixels) gets the bright spot of a raster beam
      if (P.material === M.embroidery) { g.strokeStyle = 'rgba(235,240,255,0.95)'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(live.x - 6, live.y - 10); g.lineTo(live.x + 2, live.y + 4); g.stroke(); }
      else { const r = Math.max(3, P.capH * 0.05); g.fillStyle = css(P.glow, 0.95); g.fillRect(live.x - r, live.y - r * 0.6, r * 2, r * 1.2); }
    },
  };
  MO.assemble = {
    label: 'Assembled', note: 'the letters fly in as scattered strips and lock into place',
    letter(u, i, n) { const k = stagger(u, i, n, 0.55); return k >= 1 ? REST : st({ a: clamp(k * 4, 0, 1), clip: { kind: 'strips', v: ease.out(k) } }); },
  };
  MO.poweron = {
    label: 'Powered on', note: 'the screen opens from a bright line, then the name burns in',
    screen(u) { return clamp(u / 0.4, 0, 1); },
    letter(u, i, n) { const k = stagger(clamp((u - 0.35) / 0.65, 0, 1), i, n, 0.6); return st({ a: k, blur: (1 - k) * 4 }); },
  };
  MO.rise = {
    label: 'Risen', note: 'each letter rises out of the line it stands on',
    letter(u, i, n, L) { const k = stagger(u, i, n, 0.5); return k >= 1 ? REST : st({ a: clamp(k * 2, 0, 1), dy: (1 - ease.out(k)) * L.h * 0.7, clip: { kind: 'base', v: 1 } }); },
  };
  MO.type = {
    label: 'Typed', note: 'letters land one at a time with a small kick, a cursor ahead of them',
    letter(u, i, n) { const k = stagger(u, i, n, 0.5 / Math.max(2, n)); if (k <= 0) return st({ a: 0 }); return k >= 1 ? REST : st({ s: lerp(1.25, 1, ease.out(k)) }); },
    over(g, P, u, hold) {
      const n = P.letters.length; let last = -1;
      for (let i = 0; i < n; i++) if (stagger(u, i, n, 0.5 / Math.max(2, n)) > 0) last = i;
      // the cursor is an UNDERSCORE, never a small block: a square at the baseline after the last letter reads as a full
      // stop in the studio's name.
      // and it exists only DURING the arrival: at rest the name is complete, with no extra mark (fresh review)
      if (u >= 1 || hold > 0) return;
      const fade = 1;
      const L = P.letters[Math.max(0, last)], x = last < 0 ? P.box.x0 : L.x + L.w - L.pad * 0.6;
      g.fillStyle = css(P.glow, 0.85 * fade); g.fillRect(x + P.capH * 0.08, P.box.y1 - P.capH * 0.06, P.capH * 0.5, Math.max(2, P.capH * 0.06));
    },
  };
  MO.iris = {
    label: 'Irised', note: 'a circle of light opens from the centre and the name is inside it',
    reveal(u) { return ease.inOut(clamp(u / 0.8, 0, 1)); },
  };
  MO.drop = {
    label: 'Dropped', note: 'letters fall into place one after another and bounce',
    letter(u, i, n, L) { const k = stagger(u, i, n, 0.45); if (k <= 0) return st({ a: 0 }); return k >= 1 ? REST : st({ dy: -(1 - ease.bounce(k)) * L.h * 1.6 }); },
  };
  MO.burn = {
    label: 'Burned in', note: 'a glowing ember line crosses the name and leaves it scorched in behind',
    letter(u, i, n, L, P) { const x = lerp(P.box.x0 - 20, P.box.x1 + 20, clamp(u / 0.85, 0, 1)); const v = clamp((x - L.x) / L.w, 0, 1); return v >= 1 ? REST : st({ a: v > 0 ? 1 : 0, clip: { kind: 'x', v } }); },
    over(g, P, u) {
      const k = clamp(u / 0.85, 0, 1); if (k <= 0 || k >= 1) return;
      const x = lerp(P.box.x0 - 20, P.box.x1 + 20, k);
      const gr = g.createLinearGradient(x - P.capH * 0.4, 0, x + P.capH * 0.1, 0);
      gr.addColorStop(0, 'rgba(255,120,30,0)'); gr.addColorStop(0.8, 'rgba(255,170,60,0.55)'); gr.addColorStop(1, 'rgba(255,240,200,0)');
      g.fillStyle = gr; g.fillRect(x - P.capH * 0.4, P.box.y0 - P.capH * 0.2, P.capH * 0.5, P.box.h + P.capH * 0.4);
    },
  };
  C.MOTIONS = MO;

  //===============================================================================================
  // THE FORTY. Each a (material, motion) pair no other treatment shares, with its own hand.
  //===============================================================================================
  const T = [
    ['foil-strike', 'Foil Strike', 'foil', 'stamp', 'lapidary'],
    ['foil-sweep', 'Foil Sweep', 'foil', 'sweep', 'lapidary'],
    ['foil-drop', 'Foil Drop', 'foil', 'drop', 'grotesk'],
    ['foil-iris', 'Foil Iris', 'foil', 'iris', 'uncial'],
    ['molten-foil', 'Molten Foil', 'foil', 'burn', 'textura'],
    ['ink-bleed', 'Ink Bleed', 'ink', 'bleed', 'uncial'],
    ['ink-script', 'Ink Script', 'ink', 'write', 'uncial'],
    ['woodblock', 'Woodblock', 'ink', 'stamp', 'textura'],
    ['typewriter', 'Typewriter', 'ink', 'type', 'grotesk'],
    ['letterpress', 'Letterpress', 'letterpress', 'stamp', 'grotesk'],
    ['press-proof', 'Press Proof', 'letterpress', 'rise', 'lapidary'],
    ['neon-sign', 'Neon Sign', 'neon', 'flicker', 'grotesk'],
    ['neon-script', 'Neon Script', 'neon', 'write', 'stave'],
    ['neon-power', 'Neon Power', 'neon', 'poweron', 'grotesk'],
    ['slate-chisel', 'Slate Chisel', 'slate', 'chisel', 'lapidary'],
    ['standing-stone', 'Standing Stone', 'slate', 'rise', 'stave'],
    ['inlaid-marble', 'Inlaid Marble', 'marble', 'sweep', 'lapidary'],
    ['marble-chisel', 'Marble Chisel', 'marble', 'chisel', 'uncial'],
    ['embroidered', 'Embroidered', 'embroidery', 'stitch', 'uncial'],
    ['patch', 'Patch', 'embroidery', 'stamp', 'grotesk'],
    ['wax-seal', 'Wax Seal', 'wax', 'stamp', 'textura'],
    ['wax-drop', 'Wax Drop', 'wax', 'drop', 'uncial'],
    ['pixel-assemble', 'Pixel Assemble', 'pixel', 'assemble', 'stave'],
    ['pixel-type', 'Pixel Type', 'pixel', 'type', 'grotesk'],
    ['pixel-raster', 'Pixel Raster', 'pixel', 'stitch', 'stave'],
    ['chalk-hand', 'Chalk Hand', 'chalk', 'write', 'uncial'],
    ['chalk-dust', 'Chalk Dust', 'chalk', 'bleed', 'grotesk'],
    ['crt-power', 'CRT Power On', 'crt', 'poweron', 'grotesk'],
    ['terminal', 'Terminal', 'crt', 'type', 'stave'],
    ['crt-flicker', 'CRT Flicker', 'crt', 'flicker', 'grotesk'],
    ['engraved-plate', 'Engraved Plate', 'steel', 'sweep', 'lapidary'],
    ['steel-stamp', 'Steel Stamp', 'steel', 'stamp', 'grotesk'],
    ['graver', 'Graver', 'steel', 'chisel', 'textura'],
    ['pyrography', 'Pyrography', 'wood', 'burn', 'textura'],
    ['carved-wood', 'Carved Wood', 'wood', 'chisel', 'uncial'],
    ['paper-cut', 'Paper Cut', 'papercut', 'drop', 'grotesk'],
    ['pop-up', 'Pop Up', 'papercut', 'rise', 'lapidary'],
    ['paper-iris', 'Paper Iris', 'papercut', 'iris', 'uncial'],
    ['frosted-iris', 'Frosted Iris', 'glass', 'iris', 'grotesk'],
    ['glass-assemble', 'Glass Assemble', 'glass', 'assemble', 'stave'],
  ];
  C.TREATMENTS = T.map(([id, label, material, motion, hand]) => ({ id, label, material, motion, hand }));
  C.treatment = function (id) {
    const t = C.TREATMENTS.find((x) => x.id === String(id || '').trim().toLowerCase());
    return t || null;
  };

  //===============================================================================================
  // PLAN — pure: the text, the layout and the seed. Needs the alphabet, not a canvas.
  //===============================================================================================
  /** Normalise a studio name: trimmed, inner spaces collapsed, capitals (the corpus is capitals), at most 40 chars. */
  C.normalise = function (s) { return String(s == null ? '' : s).replace(/\s+/g, ' ').trim().slice(0, 40).toUpperCase(); };

  /**
   * Lay out lines of text in a treatment's hand, centred in W x H.
   * @param {Array<{text:string, size:number}>} lines size: cap height as a fraction of H, the largest one wanted
   * @returns {object} plan
   */
  C.plan = function (lines, treatmentId, W, H, opt) {
    const tr = C.treatment(treatmentId);
    if (!tr) throw new Error(`Ident: unknown treatment "${treatmentId}". Use one of: ${C.TREATMENTS.map((t) => t.id).join(', ')}`);
    const alpha = A(), hand = alpha.hand(tr.hand);
    const norm = lines.map((l) => ({ text: C.normalise(l.text), size: l.size })).filter((l) => l.text.length);
    if (!norm.length) throw new Error('Ident: nothing to set (the name is empty)');
    const seed = R().hash(norm.map((l) => l.text).join('|') + '#' + tr.id + '#' + ((opt && opt.salt) || ''));
    const mat = M[tr.material];
    const palette = mat.palettes[seed % mat.palettes.length];
    const maxW = W * 0.8;
    // each line: its cap height is the requested size, shrunk to fit the width; a line that cannot fit at a readable size
    // is broken at the space nearest its middle (a studio name rarely needs more than two lines)
    const out = [];
    for (const l of norm) {
      let cap = l.size * H;
      const fit = alpha.fit(l.text, tr.hand, maxW, cap, H * 0.045);
      if (fit.fits && fit.capH >= cap * 0.6) out.push({ text: l.text, capH: fit.capH });
      else {
        const sp = [...l.text].map((c, i) => (c === ' ' ? i : -1)).filter((i) => i > 0);
        if (!sp.length) out.push({ text: l.text, capH: fit.capH });
        else {
          const mid = l.text.length / 2, at = sp.reduce((b, i) => (Math.abs(i - mid) < Math.abs(b - mid) ? i : b), sp[0]);
          for (const part of [l.text.slice(0, at), l.text.slice(at + 1)]) out.push({ text: part, capH: alpha.fit(part, tr.hand, maxW, cap * 0.85, H * 0.045).capH });
        }
      }
    }
    const gap = (i) => out[i].capH * 0.55;
    let totalH = 0; out.forEach((l, i) => { totalH += l.capH + (i ? gap(i) : 0); });
    let y = (H - totalH) / 2;
    const letters = [];
    let missing = 0;
    out.forEach((l, li) => {
      if (li) y += gap(li);
      const baseY = y + l.capH;
      const width = alpha.measure(l.text, tr.hand, l.capH);
      let x = (W - width) / 2;
      for (const ch of l.text) {
        const g = alpha.glyphRings(ch, tr.hand, x, baseY, l.capH);
        if (g) {
          if (ch !== ' ') letters.push({ ch, line: li, x0: x, baseY, capH: l.capH, glyph: g, advance: g.advance, font: false });
          x += g.advance + hand.track * l.capH;
        } else {
          missing++;
          const adv = l.capH * 0.78;
          letters.push({ ch, line: li, x0: x, baseY, capH: l.capH, glyph: null, advance: adv, font: true });
          x += adv + hand.track * l.capH;
        }
      }
      y = baseY;
    });
    const capH = Math.max(...out.map((l) => l.capH));
    return { lines: out, letters, treatment: tr, material: tr.material, motion: tr.motion, hand: tr.hand, seed, palette, W, H, capH, missing, version: C.VERSION };
  };

  /** Bounding box of one planned letter in frame px (rings, or the font cell). */
  function letterBox(l) {
    if (!l.glyph) return { x0: l.x0, y0: l.baseY - l.capH * 1.05, x1: l.x0 + l.advance, y1: l.baseY + l.capH * 0.25 };
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    for (const ring of l.glyph.rings) for (const p of ring) { if (p[0] < x0) x0 = p[0]; if (p[0] > x1) x1 = p[0]; if (p[1] < y0) y0 = p[1]; if (p[1] > y1) y1 = p[1]; }
    return { x0, y0, x1, y1 };
  }
  C.letterBox = letterBox;

  //===============================================================================================
  // BUILD — browser: the ground, every letter's finished face, the word mask. Done ONCE, before the ident plays.
  //===============================================================================================
  C.build = function (plan) {
    const mat = M[plan.material], mot = MO[plan.motion];
    const rng = R().rng(plan.seed);
    const ground = mk(plan.W, plan.H);
    mat.ground(ground.getContext('2d'), plan.W, plan.H, rng, plan.palette, plan.seed);
    const wordMask = mk(plan.W, plan.H), wg = wordMask.getContext('2d');
    wg.fillStyle = '#fff';
    const letters = plan.letters.map((l, i) => {
      const b = letterBox(l), pad = Math.ceil(l.capH * 0.35);
      const x = Math.floor(b.x0) - pad, y = Math.floor(b.y0) - pad, w = Math.ceil(b.x1 - b.x0) + pad * 2, h = Math.ceil(b.y1 - b.y0) + pad * 2;
      const mask = mk(w, h), mg = mask.getContext('2d');
      mg.fillStyle = '#fff';
      if (l.glyph) fillGlyphPath(mg, l.glyph, -x, -y);
      const text = l.glyph ? null : { ch: l.ch, x: l.x0 - x, y: l.baseY - y, font: `600 ${Math.round(l.capH * 1.36)}px ${C.FONT_FALLBACK}` };
      if (text) { mg.font = text.font; mg.textBaseline = 'alphabetic'; mg.fillText(text.ch, text.x, text.y); }
      wg.drawImage(mask, x, y);
      const L = { mask, text, glyph: l.glyph || { rings: [], holes: [] }, dx: -x, dy: -y, w, h, x, y, pad, capH: l.capH, top: b.y0 - y, bottom: b.y1 - y,
        off: Math.max(1, A().reliefOffset(l.capH, plan.hand)), pal: plan.palette, rng: R().rng(plan.seed + i * 977), seed: plan.seed + i * 131 };
      const face = mat.face(L);
      return { face, mask, x, y, w, h, pad, cx: x + w / 2, cy: y + h / 2, cells: L.cells || null, cell: L.cell || 0 };
    });
    const xs = letters.map((l) => [l.x + l.pad, l.x + l.w - l.pad]).flat(), ys = letters.map((l) => [l.y + l.pad, l.y + l.h - l.pad]).flat();
    const box = { x0: Math.min(...xs), x1: Math.max(...xs), y0: Math.min(...ys), y1: Math.max(...ys) };
    box.w = box.x1 - box.x0; box.h = box.y1 - box.y0; box.cx = (box.x0 + box.x1) / 2; box.cy = (box.y0 + box.y1) / 2;
    const order = letters.map((_, i) => i);
    const orng = R().rng(plan.seed + 77);
    for (let i = order.length - 1; i > 0; i--) { const j = Math.floor(orng() * (i + 1)); [order[i], order[j]] = [order[j], order[i]]; }
    const rank = []; order.forEach((li, k) => { rank[li] = k; });
    const pal = plan.palette;
    const accent = pal.tube || pal.phos || pal.light || pal.thread || pal.block || pal.chalk || pal.ink || [255, 230, 170];
    return { plan, ground, wordMask, letters, box, capH: plan.capH, seed: plan.seed, order: rank, scratch: mk(plan.W, plan.H),
      glow: shade(accent, 0.4), dust: mat === M.chalk ? pal.chalk : shade(accent, 0.2), W: plan.W, H: plan.H, motion: mot, material: mat };
  };

  //===============================================================================================
  // DRAW — one frame. u: intro progress 0..1; hold: seconds since the intro finished (0 during it).
  //===============================================================================================
  C.state = function (P, u, i) {
    const mot = MO[P.plan.motion];
    if (!mot.letter) return REST;
    return mot.letter(clamp(u, 0, 1), i, P.letters.length, P.letters[i], P);
  };
  C.draw = function (g, P, u, hold) {
    const mot = MO[P.plan.motion];
    u = clamp(u, 0, 1); hold = hold || 0;
    g.save();
    g.clearRect(0, 0, P.W, P.H);
    const shake = mot.shake ? mot.shake(u) : 0;
    if (shake) g.translate(shake, shake * 0.6);
    // POWER ON: the ground and letters only exist inside an opening band
    const screen = mot.screen ? mot.screen(u) : 1;
    g.fillStyle = '#000'; g.fillRect(0, 0, P.W, P.H);
    if (screen < 1) {
      const bh = Math.max(2, P.H * ease.out(screen)), y0 = (P.H - bh) / 2;
      g.save(); g.beginPath(); g.rect(0, y0, P.W, bh); g.clip(); g.drawImage(P.ground, 0, 0); g.restore();
      g.fillStyle = `rgba(255,255,255,${0.9 * (1 - screen)})`; g.fillRect(0, y0, P.W, Math.min(bh, 3));
    } else g.drawImage(P.ground, 0, 0);
    if (mot.under) mot.under(g, P, u, hold);
    // IRIS: everything that follows is seen through a growing circle
    let irisR = null;
    if (mot.reveal) {
      irisR = mot.reveal(u) * Math.hypot(P.W, P.H) * 0.6;
      if (irisR < Math.hypot(P.W, P.H) * 0.6) { g.save(); g.beginPath(); g.arc(P.box.cx, P.box.cy, Math.max(0.1, irisR), 0, TAU); g.clip(); }
      else irisR = null;
    }
    P.liveEdge = null;
    // WORD SCALE: a motion that moves the whole name at once scales it about the name's centre, letters together
    const ws = mot.word ? mot.word(u) : 1;
    g.save();
    if (ws !== 1) { g.translate(P.box.cx, P.box.cy); g.scale(ws, ws); g.translate(-P.box.cx, -P.box.cy); }
    for (let i = 0; i < P.letters.length; i++) {
      const L = P.letters[i], s = C.state(P, u, i);
      let a = s.a;
      if (mot.hum && u >= 1) a *= mot.hum(hold, i);
      if (a <= 0.001) continue;
      g.save();
      g.globalAlpha = a;
      if (s.blur > 0.2) g.filter = `blur(${s.blur.toFixed(1)}px)`;
      g.translate(L.cx + s.dx, L.cy + s.dy); if (s.s !== 1) g.scale(s.s, s.s); g.translate(-L.cx, -L.cy);
      const c = s.clip;
      if (c && c.kind === 'strips') {
        const n = 6, sh = L.h / n, rng = R().rng(P.seed + i * 13);
        for (let k = 0; k < n; k++) { const off = (rng() - 0.5) * P.W * 0.6 * (1 - c.v); g.drawImage(L.face, 0, k * sh, L.w, sh, L.x + off, L.y + k * sh, L.w, sh); }
      } else {
        if (c) {
          g.beginPath();
          if (c.kind === 'x') { g.rect(L.x, L.y - 2, L.w * c.v, L.h + 4); P.liveEdge = { x: L.x + L.w * c.v, y: L.y + L.h * 0.55 }; }
          else if (c.kind === 'yUp') { const top = L.y + L.h * (1 - c.v); g.rect(L.x - 2, top, L.w + 4, L.h * c.v + 2); }
          else if (c.kind === 'rows') {
            const rows = 9, rh = L.h / rows, done = c.v * rows, full = Math.floor(done);
            g.rect(L.x, L.y, L.w, rh * full);
            g.rect(L.x, L.y + rh * full, L.w * (done - full), rh);
            P.liveEdge = { x: L.x + L.w * (done - full), y: L.y + rh * (full + 0.5) };
          } else if (c.kind === 'base') { g.rect(L.x - 4, -P.H, L.w + 8, P.H + L.y + L.h - L.pad * 0.9 - (s.dy || 0)); }
          g.clip();
        }
        g.drawImage(L.face, L.x, L.y);
      }
      g.restore();
    }
    g.restore();
    if (irisR !== null) {
      g.restore();
      g.strokeStyle = css(P.glow, 0.6); g.lineWidth = 3; g.beginPath(); g.arc(P.box.cx, P.box.cy, irisR, 0, TAU); g.stroke();
    }
    if (mot.over) mot.over(g, P, u, hold);
    g.restore();
  };

  /** True when the finished ident animates nothing during the hold (every overlay stops at u = 1; only a hum moves): the scene then draws it once. */
  C.isStill = function (P) { const mot = MO[P.plan.motion]; return !mot.hum; };
  /** Coverage of a name in a treatment's hand: the share of its characters the corpus can cut. */
  C.coverage = function (name, treatmentId) { const t = C.treatment(treatmentId); return A().coverage(C.normalise(name), t ? t.hand : 'lapidary'); };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.Ident.Core;
