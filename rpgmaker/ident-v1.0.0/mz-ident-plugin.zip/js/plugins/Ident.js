//=============================================================================
// Ident.js: Ident [4/4]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Ident [4/4]: plays your studio's animated ident before the title screen, set from your studio name in one of forty worked treatments.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 * @base IdentCore
 * @orderAfter IdentCore
 *
 * @help Ident.js
 *
 * Type your studio name, pick a treatment, and the game opens on an animated
 * studio ident: your name struck in gold foil, bled into paper, bent in neon,
 * cut into slate, stitched, pressed in wax, assembled from pixels, powered on
 * a CRT and so on. It plays once each time the game starts, before the title
 * screen, and the player can skip it with OK, Cancel or a tap.
 *
 * An optional second plate, in the same treatment, can credit the engine or a
 * publisher as text (for example MADE WITH / RPG MAKER MZ).
 *
 * Needs IdentRender.js, IdentAlphabet.js and IdentCore.js turned on as well
 * (any order works).
 *
 * The full guide, with every treatment, is in Readme_for_Users.md.
 *
 * @param studioName
 * @text Studio name
 * @type string
 * @default Your Studio
 * @desc The name the ident sets. Capital letters, digits and common punctuation are cut from the built in letterforms.
 *
 * @param treatment
 * @text Treatment
 * @type select
 * @option foil-strike
 * @option foil-sweep
 * @option foil-drop
 * @option foil-iris
 * @option molten-foil
 * @option ink-bleed
 * @option ink-script
 * @option woodblock
 * @option typewriter
 * @option letterpress
 * @option press-proof
 * @option neon-sign
 * @option neon-script
 * @option neon-power
 * @option slate-chisel
 * @option standing-stone
 * @option inlaid-marble
 * @option marble-chisel
 * @option embroidered
 * @option patch
 * @option wax-seal
 * @option wax-drop
 * @option pixel-assemble
 * @option pixel-type
 * @option pixel-raster
 * @option chalk-hand
 * @option chalk-dust
 * @option crt-power
 * @option terminal
 * @option crt-flicker
 * @option engraved-plate
 * @option steel-stamp
 * @option graver
 * @option pyrography
 * @option carved-wood
 * @option paper-cut
 * @option pop-up
 * @option paper-iris
 * @option frosted-iris
 * @option glass-assemble
 * @default foil-strike
 * @desc How the name is made and how it arrives. See the Readme for all forty.
 *
 * @param creditTop
 * @text Credit plate: small line
 * @type string
 * @default
 * @desc The small upper line of the optional second plate, for example MADE WITH. Leave both credit lines empty for no plate.
 *
 * @param creditMain
 * @text Credit plate: main line
 * @type string
 * @default
 * @desc The main line of the optional second plate, for example RPG MAKER MZ. Text only.
 *
 * @param introFrames
 * @text Arrival time
 * @type number
 * @min 30
 * @max 300
 * @default 120
 * @desc Frames the name takes to arrive (60 = one second).
 *
 * @param holdFrames
 * @text Hold time
 * @type number
 * @min 0
 * @max 600
 * @default 100
 * @desc Frames the finished ident stays on screen.
 *
 * @param fadeFrames
 * @text Fade time
 * @type number
 * @min 1
 * @max 120
 * @default 30
 * @desc Frames for each fade out.
 *
 * @param skippable
 * @text Skippable
 * @type boolean
 * @default true
 * @desc OK, Cancel or a tap skips the ident with a short fade.
 *
 * @param sound
 * @text Sound on arrival
 * @type file
 * @dir audio/se/
 * @default
 * @desc A sound effect from your own project, played as the ident starts. Leave empty for silence.
 *
 * @command play
 * @text Play Ident
 * @desc Play the ident now (for example from a credits event), then return. Does nothing during a battle.
 */

var CSAF = CSAF || {};
CSAF.Ident = CSAF.Ident || {};

(() => {
  'use strict';
  const NAME = 'Ident';
  const RAW = PluginManager.parameters(NAME);
  // parameters arrive as STRINGS and Number('') is 0: a blank is the default, never zero
  const num = (v, d, lo, hi) => { if (v === undefined || v === null || String(v).trim() === '') return d; const n = Number(v); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, Math.round(n))) : d; };
  const bool = (v, d) => (String(v) === 'true' ? true : String(v) === 'false' ? false : d);
  const P = {
    studioName: String(RAW.studioName == null || String(RAW.studioName).trim() === '' ? 'Your Studio' : RAW.studioName),
    treatment: String(RAW.treatment || 'foil-strike').trim().toLowerCase(),
    creditTop: String(RAW.creditTop || ''),
    creditMain: String(RAW.creditMain || ''),
    introFrames: num(RAW.introFrames, 120, 30, 300),
    holdFrames: num(RAW.holdFrames, 100, 0, 600),
    fadeFrames: num(RAW.fadeFrames, 30, 1, 120),
    skippable: bool(RAW.skippable, true),
    sound: String(RAW.sound || ''),
  };

  // the core is resolved at FIRST USE, never at load: load order is the buyer's choice
  function Core() {
    const c = CSAF.Ident.Core;
    if (!c) throw new Error('Ident: IdentCore.js is not loaded. Turn on IdentRender, IdentAlphabet and IdentCore in the Plugin Manager.');
    return c;
  }
  /** The treatment to play: the parameter, or the first one if the parameter names none (a typo never stops the game). */
  function treatmentId() { return Core().treatment(P.treatment) ? P.treatment : Core().TREATMENTS[0].id; }

  /** The plates this game shows: the studio ident, then the credit plate if either credit line has text. */
  function plates(w, h) {
    const C = Core(), id = treatmentId(), out = [];
    out.push(C.plan([{ text: P.studioName, size: 0.15 }], id, w, h));
    const top = C.normalise(P.creditTop), main = C.normalise(P.creditMain);
    if (top || main) {
      const lines = [];
      if (top) lines.push({ text: top, size: 0.055 });
      if (main) lines.push({ text: main, size: 0.1 });
      out.push(C.plan(lines, id, w, h, { salt: 'credit' }));
    }
    return out;
  }

  //===========================================================================================
  // Scene_Ident: every plate is built once, then drawn frame by frame into one bitmap.
  //===========================================================================================
  class Scene_Ident extends Scene_Base {
    prepare(mode) { this._mode = mode || 'boot'; }
    create() {
      super.create();
      const w = Graphics.width, h = Graphics.height;
      this._bitmap = new Bitmap(w, h);
      this._sprite = new Sprite(this._bitmap);
      this.addChild(this._sprite);
      this._built = plates(w, h).map((p) => Core().build(p));
      this._index = 0;
      this._frame = 0;
      this._leaving = false;
      this._ended = false;
      this._redraw();
    }
    start() {
      super.start();
      if (P.sound) AudioManager.playSe({ name: P.sound, volume: 90, pitch: 100, pan: 0 });
    }
    isBusy() { return super.isBusy(); }
    /** The phase of the current plate: intro progress u, seconds held, fade (1 = fully visible). */
    phase() {
      const f = this._frame, I = P.introFrames, Hd = P.holdFrames, F = P.fadeFrames;
      const u = Math.min(1, f / I), hold = f > I ? (f - I) / 60 : 0;
      const out = f > I + Hd ? Math.min(1, (f - I - Hd) / F) : 0;
      return { u, hold, fade: 1 - out, done: f >= I + Hd + F };
    }
    update() {
      super.update();
      if (this._ended) return;
      if (P.skippable && !this._leaving && (Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered())) this._leaving = true;
      if (this._leaving) {
        this._sprite.opacity = Math.max(0, this._sprite.opacity - 255 / Math.max(1, Math.round(P.fadeFrames / 2)));
        if (this._sprite.opacity <= 0) this._finish();
        return;
      }
      this._frame++;
      const ph = this.phase();
      if (ph.done) {
        this._index++;
        this._frame = 0;
        if (this._index >= this._built.length) { this._finish(); return; }
      }
      this._redraw();
    }
    _redraw() {
      const ph = this.phase(), P0 = this._built[this._index];
      // once the name is at rest and its arrival animates nothing in the hold, the bitmap is final: only the opacity
      // changes, so the full frame is not redrawn or re-uploaded every frame of the hold and fade
      const still = ph.u >= 1 && Core().isStill(P0);
      // while the name moves (the arrival, and a humming treatment's hold), repaint every SECOND frame: 30 a second,
      // one full-screen texture upload per two frames. MEASURED 2026-10-16 on the factory's mz_gate: repainting every
      // frame cost 1 upload and 1 bitmap repaint per frame through the arrival, twice the gate's ceiling. The frame that
      // brings a still name to rest is always drawn, and so is a plate's first frame (frame 0 is even).
      const skip = !still && (this._frame & 1) === 1;
      if (!skip && !(still && this._still === this._index)) {
        Core().draw(this._bitmap.context, P0, ph.u, ph.hold);
        this._bitmap.baseTexture.update();
        this._uploads = (this._uploads || 0) + 1;
        this._still = still ? this._index : -1;
      }
      this._sprite.opacity = Math.round(255 * ph.fade);
    }
    _finish() {
      this._ended = true;
      if (this._mode === 'push') this.popScene();
      else SceneManager.goto(Scene_Title);
    }
    terminate() {
      super.terminate();
      if (this._bitmap) this._bitmap.destroy();
      this._built = null;
    }
  }
  window.Scene_Ident = Scene_Ident;

  //===========================================================================================
  // The boot hook. The FIRST move to the title screen in a session becomes the ident instead, whoever makes it
  // (the engine's boot scene, or another splash plugin finishing its own splash), so the order in the Plugin Manager
  // does not matter. A battle or event test, and every later return to the title, goes straight through.
  //===========================================================================================
  let shown = false;
  const _goto = SceneManager.goto;
  SceneManager.goto = function (sceneClass) {
    if (sceneClass === Scene_Title && !shown && !DataManager.isBattleTest() && !DataManager.isEventTest()) {
      shown = true;
      _goto.call(this, Scene_Ident);
      if (this._nextScene && this._nextScene.prepare) this._nextScene.prepare('boot');
      return;
    }
    _goto.call(this, sceneClass);
  };

  PluginManager.registerCommand(NAME, 'play', function () {
    // never from a battle: returning to Scene_Battle runs its start() again, which would restart the battle
    if (SceneManager._scene instanceof Scene_Battle) return;
    SceneManager.push(Scene_Ident);
    SceneManager.prepareNextScene('push');
  });

  // a test and support seam, read only
  CSAF.Ident.Player = { version: '1.0.0', params: () => Object.assign({}, P), shown: () => shown, treatment: treatmentId };
})();
