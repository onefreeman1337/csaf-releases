//=============================================================================
// IdentRender.js — Ident [1/4]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Ident [1/4]: drawing and colour primitives. Seeded RNG, colour maths, the absolute separation relief model, deterministic surface noise, path geometry, and the two scale laws every worked surface depends on.
 * @author Core Systems Asset Factory
 *
 * @help IdentRender.js
 *
 * Part 1 of 4. Contains no game logic and adds no commands; it is the drawing
 * and colour layer every other Ident file calls.
 *
 * Recommended Plugin Manager order is IdentRender, IdentAlphabet,
 * IdentCore, Ident — but NOTHING
 * depends on it. Every file resolves its siblings at first use, so any order
 * works, including the alphabetical order the Plugin Manager produces when the
 * folder is dragged in. (A product that captures its siblings at load time
 * can silently do nothing behind one console line; this one cannot.)
 *
 * PROVENANCE. The RNG, colour, relief, recorder, typography and geometry
 * sections are carried forward from earlier, proven code rather than
 * re-derived: a proven font stack is copied, never invented, and the
 * absolute-separation relief model cost a whole specimen plate to get right. What is NEW here is the surface layer — deterministic value
 * noise, and the four material treatments (grain, hammer, tooth, laid) that let
 * a ground read as a worked material rather than as a flat fill — because a
 * title screen is mostly GROUND, and a flat ground is the whole failure.
 */

var CSAF = CSAF || {};
CSAF.Ident = CSAF.Ident || {};

(function () {
  'use strict';

  const R = {};
  CSAF.Ident.Render = R;

  //---------------------------------------------------------------------------
  // Deterministic RNG. Never Math.random() in generation: a title screen must be the same screen every time the player boots the
  // game, or the first thing they see is a game that cannot make up its mind.
  //---------------------------------------------------------------------------

  /**
   * mulberry32 — small, fast, deterministic.
   *
   * NOTE: an earlier review suspected this generator of a warm-up bias
   * and nearly "fixed" it by discarding early outputs. That was MEASURED over
   * 20,000 seeds and REFUTED: the first eight outputs give
   * chi-square 2.1 on five buckets against 3.46 for outputs 100-108. Do not add
   * a warm-up; it would change every generated artefact and leave a false
   * explanation behind.
   *
   * @param {number} seed Any 32-bit integer.
   * @returns {function(): number} Generator returning [0, 1).
   */
  R.rng = function (seed) {
    let a = seed >>> 0;
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  };

  /**
   * Stable string hash, so a screen's seed comes from the game's own title and
   * never from anything positional — adding a party member must not re-cut the
   * title.
   * @param {string} s Source string.
   * @returns {number} 32-bit unsigned hash.
   */
  R.hash = function (s) {
    let h = 2166136261 >>> 0;
    const str = String(s == null ? '' : s);
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return h >>> 0;
  };

  //---------------------------------------------------------------------------
  // Colour
  //---------------------------------------------------------------------------

  /**
   * Rec. 601 luminance, the scale every separation rule in this file is stated
   * in.
   * @param {number[]} c [r,g,b] 0-255.
   * @returns {number} Luminance 0-255.
   */
  R.lum = function (c) {
    return 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2];
  };

  /** @param {number} v Any number. @returns {number} v clamped to 0-255, rounded. */
  R.clamp255 = function (v) {
    return v < 0 ? 0 : v > 255 ? 255 : Math.round(v);
  };

  /**
   * Mix two colours.
   * @param {number[]} a First colour.
   * @param {number[]} b Second colour.
   * @param {number} t 0 returns a, 1 returns b.
   * @returns {number[]} Mixed colour.
   */
  R.mix = function (a, b, t) {
    return [
      R.clamp255(a[0] + (b[0] - a[0]) * t),
      R.clamp255(a[1] + (b[1] - a[1]) * t),
      R.clamp255(a[2] + (b[2] - a[2]) * t),
    ];
  };

  /** @param {number[]} c Colour. @returns {string} CSS rgb() string. */
  R.css = function (c) {
    return 'rgb(' + R.clamp255(c[0]) + ',' + R.clamp255(c[1]) + ',' + R.clamp255(c[2]) + ')';
  };

  /**
   * @param {number[]} c Colour.
   * @param {number} a Alpha 0-1.
   * @returns {string} CSS rgba() string.
   */
  R.rgba = function (c, a) {
    return 'rgba(' + R.clamp255(c[0]) + ',' + R.clamp255(c[1]) + ','
      + R.clamp255(c[2]) + ',' + a + ')';
  };

  /**
   * How much luminance headroom exists in a direction. This is the number that
   * makes a "separate by N" assertion honest: on a near-white vellum there may
   * be only ten levels below white, and demanding thirty is a FALSE RED, not a
   * defect (measured on a pale gem plate at luminance 244.9).
   *
   * @param {number[]} c Base colour.
   * @param {number} dir +1 toward white, -1 toward black.
   * @returns {number} Luminance levels available, 0-255.
   */
  R.headroom = function (c, dir) {
    const l = R.lum(c);
    return dir > 0 ? 255 - l : l;
  };

  /**
   * THE RULE THIS PRODUCT LIVES OR DIES BY.
   *
   * Any tint whose job is to make something VISIBLE must state its separation
   * in ABSOLUTE terms and solve for it. shade(x, 1.22) is a hard-coded contrast
   * RATIO, so separation is proportional to the base: measured across a
   * twelve-seal plate it moved a bright base 27 luminance levels and a dark one
   * only 11, and the device on the darkest seal could not be made out at all.
   *
   * A letter incised into pale vellum and the same letter incised into black
   * lacquer must BOTH read. An incised letter IS separation: there is no ink,
   * only the shadow the cut casts.
   *
   * @param {number[]} base Colour the mark sits on.
   * @param {number} dir +1 lighter, -1 darker.
   * @param {number} minDelta Luminance separation required.
   * @returns {number[]} A colour separated from base by min(minDelta, headroom).
   */
  R.relief = function (base, dir, minDelta) {
    const target = dir > 0 ? [255, 255, 255] : [0, 0, 0];
    const room = R.headroom(base, dir);
    const want = Math.min(minDelta, room);
    if (want <= 0) return base.slice();
    let lo = 0;
    let hi = 1;
    for (let i = 0; i < 24; i++) {
      const mid = (lo + hi) / 2;
      const got = Math.abs(R.lum(R.mix(base, target, mid)) - R.lum(base));
      if (got < want) lo = mid; else hi = mid;
    }
    return R.mix(base, target, hi);
  };

  /**
   * Pick the most readable ink from candidates for a given ground.
   * Never hard-code an ink: card titles once shipped dark-grey on dark-grey
   * across four whole decks with every mechanical check green.
   *
   * @param {number[]} bg Ground colour.
   * @param {number[][]} candidates Inks to choose between.
   * @returns {number[]} The candidate furthest from bg in luminance.
   */
  R.pickContrast = function (bg, candidates) {
    if (!candidates || !candidates.length) throw new Error('pickContrast: empty candidate set');
    const bl = R.lum(bg);
    let best = candidates[0];
    let bestD = -1;
    for (let i = 0; i < candidates.length; i++) {
      const d = Math.abs(R.lum(candidates[i]) - bl);
      if (d > bestD) { bestD = d; best = candidates[i]; }
    }
    return best;
  };

  /**
   * Choose an ink guaranteed to separate from the ground it sits on, while
   * keeping the ink's own hue. `pickContrast` picks the best of several inks;
   * this one keeps the ink you asked for — gold has to stay gold — and moves
   * its LUMINANCE until the separation exists.
   *
   * @param {number[]} ink Ink colour to preserve.
   * @param {number[]} ground Colour it sits on.
   * @param {number} minDelta Luminance separation required.
   * @returns {number[]} The ink, moved away from ground if it had to be.
   */
  R.separateFrom = function (ink, ground, minDelta) {
    const li = R.lum(ink);
    const lg = R.lum(ground);
    if (Math.abs(li - lg) >= minDelta) return ink.slice();
    // Move to whichever side of the GROUND has more room. Deciding by the ink's
    // own headroom is wrong: a mid ink on a near-white ground has room in both
    // directions, but only one of them gets away from the ground.
    const dir = (255 - lg) >= lg ? 1 : -1;
    const targetL = dir > 0 ? Math.min(255, lg + minDelta) : Math.max(0, lg - minDelta);
    return R.relief(ink, targetL > li ? 1 : -1, Math.abs(targetL - li));
  };

  /**
   * How much separation `separateFrom` could POSSIBLY deliver for this pair.
   *
   * Measured on a pale gem plate: asserting a flat 30 levels
   * goes red on a base with only 10 levels of headroom, and that is arithmetic
   * rather than a defect. A test asserts min(delta, achievable(...)) — and
   * pairs it with a mid-grey control demanding the FULL delta, so "as much as
   * exists" cannot become a loophole excusing a function that has stopped
   * working.
   *
   * @param {number[]} ink Ink colour.
   * @param {number[]} ground Ground colour.
   * @param {number} minDelta Separation asked for.
   * @returns {number} Separation actually achievable, 0-255.
   */
  R.achievableSeparation = function (ink, ground, minDelta) {
    const li = R.lum(ink);
    const lg = R.lum(ground);
    if (Math.abs(li - lg) >= minDelta) return Math.abs(li - lg);
    const dir = (255 - lg) >= lg ? 1 : -1;
    const targetL = dir > 0 ? Math.min(255, lg + minDelta) : Math.max(0, lg - minDelta);
    const moveDir = targetL > li ? 1 : -1;
    const reach = Math.min(Math.abs(targetL - li), R.headroom(ink, moveDir));
    return Math.abs((li + moveDir * reach) - lg);
  };

  /**
   * Perceptual-ish distance between two colours, used by the collision sweep.
   * Once an eye finds one collision, compute the metric over the
   * whole corpus and read the ranked list.
   *
   * @param {number[]} a First colour.
   * @param {number[]} b Second colour.
   * @returns {number} Weighted RGB distance.
   */
  R.dist = function (a, b) {
    const dr = a[0] - b[0];
    const dg = a[1] - b[1];
    const db = a[2] - b[2];
    return Math.sqrt(2 * dr * dr + 4 * dg * dg + 3 * db * db);
  };

  //---------------------------------------------------------------------------
  // Typography for the SUPPORTING text only.
  //
  // The wordmark is not set in any of these. It is CUT, letter by letter, from
  // the authored skeletons in IdentAlphabet.js — which is the whole
  // point of the product and the answer to where a scene set
  // entirely in $gameSystem.mainFontFace() passed every geometric and pixel
  // check ever written.
  //
  // These stacks letter the menu labels and the imprint, which are buyer
  // strings in an unknown script and therefore cannot be cut from a Latin
  // corpus. Nothing in Ident ever calls $gameSystem.mainFontFace().
  //---------------------------------------------------------------------------

  /** @type {string} Serif with strong caps, for engraved supporting text. */
  R.FONT_DISPLAY = 'Constantia, "Palatino Linotype", "Book Antiqua", '
    + 'Cambria, Georgia, "Times New Roman", serif';

  /** @type {string} Even, narrow face for small caps and imprint lines. */
  R.FONT_TECH = '"Segoe UI Semilight", Corbel, Candara, "Gill Sans MT", '
    + '"Trebuchet MS", "Segoe UI", sans-serif';

  //---------------------------------------------------------------------------
  // The op recorder.
  //
  // Every drawing call in this product goes through one of these. With a real
  // canvas context it draws; with `null` it records COUNTS only, which is how
  // the headless suite can assert that a mark was actually issued.
  //
  // And a count is exactly as far as it goes. An op counter
  // proves a call happened, never that a pixel changed. The counts catch a
  // MISSING call; only the separation rules above and a rendered PNG catch an
  // INVISIBLE one.
  //---------------------------------------------------------------------------

  /**
   * @param {CanvasRenderingContext2D|null} ctx Target context, or null to count.
   * @returns {object} Recorder.
   */
  R.Recorder = function (ctx) {
    const n = { path: 0, fill: 0, stroke: 0, text: 0, clip: 0, poly: 0, glyph: 0 };
    const rec = {
      ctx: ctx,
      counts: function () {
        return {
          path: n.path, fill: n.fill, stroke: n.stroke,
          text: n.text, clip: n.clip, poly: n.poly, glyph: n.glyph,
        };
      },
      /** Record one cut glyph. Used by the alphabet to prove letters were cut. */
      glyph: function () { n.glyph++; },
      save: function () { if (ctx) ctx.save(); },
      restore: function () { if (ctx) ctx.restore(); },
      begin: function () { n.path++; if (ctx) ctx.beginPath(); },
      moveTo: function (x, y) { if (ctx) ctx.moveTo(x, y); },
      lineTo: function (x, y) { if (ctx) ctx.lineTo(x, y); },
      quadTo: function (cx, cy, x, y) { if (ctx) ctx.quadraticCurveTo(cx, cy, x, y); },
      bezTo: function (a, b, c, d, x, y) { if (ctx) ctx.bezierCurveTo(a, b, c, d, x, y); },
      arc: function (cx, cy, r, a0, a1, ccw) { if (ctx) ctx.arc(cx, cy, r, a0, a1, ccw); },
      ellipse: function (cx, cy, rx, ry, rot) {
        if (ctx) ctx.ellipse(cx, cy, rx, ry, rot || 0, 0, Math.PI * 2);
      },
      rect: function (x, y, w, h) { n.path++; if (ctx) { ctx.beginPath(); ctx.rect(x, y, w, h); } },
      close: function () { if (ctx) ctx.closePath(); },
      clip: function () { n.clip++; if (ctx) ctx.clip(); },
      fill: function (style) { n.fill++; if (ctx) { ctx.fillStyle = style; ctx.fill(); } },
      stroke: function (style, w) {
        n.stroke++;
        if (ctx) { ctx.strokeStyle = style; ctx.lineWidth = w; ctx.stroke(); }
      },
      /** @param {string} cap "butt" | "round" | "square". */
      lineCap: function (cap) { if (ctx) ctx.lineCap = cap; },
      /** @param {string} j "miter" | "round" | "bevel". */
      lineJoin: function (j) { if (ctx) ctx.lineJoin = j; },
      /**
       * Fill one closed polygon in one flat colour.
       * @param {number[][]} pts Screen-space [x,y] pairs.
       * @param {string} style CSS fill.
       */
      poly: function (pts, style) {
        n.poly++; n.path++; n.fill++;
        if (!ctx || !pts.length) return;
        ctx.beginPath();
        ctx.moveTo(pts[0][0], pts[0][1]);
        for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
        ctx.closePath();
        ctx.fillStyle = style;
        ctx.fill();
      },
      /**
       * Build a polygon path without filling it, so a caller can clip to it.
       * @param {number[][]} pts Screen-space [x,y] pairs.
       */
      polyPath: function (pts) {
        n.path++;
        if (!ctx || !pts.length) return;
        ctx.beginPath();
        ctx.moveTo(pts[0][0], pts[0][1]);
        for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
        ctx.closePath();
      },
      /**
       * Add one closed sub-polygon to the CURRENT path without beginning a new
       * one. Needed for evenodd counters: canvas has no
       * "punch a hole in what I already drew"; the hole must be traced in the
       * SAME path as the shape it belongs to and filled once.
       * @param {number[][]} pts Screen-space [x,y] pairs.
       */
      subPoly: function (pts) {
        if (!ctx || !pts.length) return;
        ctx.moveTo(pts[0][0], pts[0][1]);
        for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
        ctx.closePath();
      },
      /** @param {string} style CSS fill. Fills the current path even-odd. */
      fillEvenOdd: function (style) {
        n.fill++;
        if (ctx) { ctx.fillStyle = style; ctx.fill('evenodd'); }
      },
      /**
       * Linear gradient fill across the current path.
       * @param {number[]} p0 Start [x,y].
       * @param {number[]} p1 End [x,y].
       * @param {Array<Array>} stops [[offset, cssColour], ...].
       */
      fillGradient: function (p0, p1, stops) {
        n.fill++;
        if (!ctx) return;
        const g = ctx.createLinearGradient(p0[0], p0[1], p1[0], p1[1]);
        for (let i = 0; i < stops.length; i++) g.addColorStop(stops[i][0], stops[i][1]);
        ctx.fillStyle = g;
        ctx.fill();
      },
      /**
       * Linear gradient fill of the current path, EVEN-ODD.
       *
       * `fillGradient` uses the default nonzero rule, which silently drops
       * every counter — the O of a gold inlay would come out as a solid
       * lozenge. The hole must be traced in the same path and
       * filled once, and "filled once" has to mean filled with the same rule.
       *
       * @param {number[]} p0 Start [x,y].
       * @param {number[]} p1 End [x,y].
       * @param {Array<Array>} stops [[offset, cssColour], ...].
       */
      fillGradientEvenOdd: function (p0, p1, stops) {
        n.fill++;
        if (!ctx) return;
        const g = ctx.createLinearGradient(p0[0], p0[1], p1[0], p1[1]);
        for (let i = 0; i < stops.length; i++) g.addColorStop(stops[i][0], stops[i][1]);
        ctx.fillStyle = g;
        ctx.fill('evenodd');
      },
      /**
       * Radial gradient fill across the current path.
       * @param {number[]} c Centre [x,y].
       * @param {number} r0 Inner radius.
       * @param {number} r1 Outer radius.
       * @param {Array<Array>} stops [[offset, cssColour], ...].
       */
      fillRadial: function (c, r0, r1, stops) {
        n.fill++;
        if (!ctx) return;
        const g = ctx.createRadialGradient(c[0], c[1], r0, c[0], c[1], r1);
        for (let i = 0; i < stops.length; i++) g.addColorStop(stops[i][0], stops[i][1]);
        ctx.fillStyle = g;
        ctx.fill();
      },
      /**
       * Stroke the current path with a linear gradient.
       *
       * THIS IS WHAT MAKES A MOULDING READ AS RAISED RATHER THAN AS A BORDER.
       * A flat stroke gives an outline; a stroke whose colour runs from the lit
       * relief at the upper left to the shadowed relief at the lower right
       * gives an EDGE WITH THICKNESS.
       *
       * @param {number[]} p0 Gradient start [x,y].
       * @param {number[]} p1 Gradient end [x,y].
       * @param {Array<Array>} stops [[offset, cssColour], ...].
       * @param {number} w Stroke width.
       */
      strokeGradient: function (p0, p1, stops, w) {
        n.stroke++;
        if (!ctx) return;
        const g = ctx.createLinearGradient(p0[0], p0[1], p1[0], p1[1]);
        for (let i = 0; i < stops.length; i++) g.addColorStop(stops[i][0], stops[i][1]);
        ctx.strokeStyle = g;
        ctx.lineWidth = w;
        ctx.stroke();
      },
      /** @param {number} a Global alpha 0-1. */
      alpha: function (a) { if (ctx) ctx.globalAlpha = a; },
      /**
       * Draw text.
       * @param {string} s The string.
       * @param {number} x Anchor x.
       * @param {number} y Baseline.
       * @param {object} o {size, family, colour, weight, align}.
       */
      text: function (s, x, y, o) {
        n.text++;
        if (!ctx) return;
        ctx.font = (o.weight || '') + ' ' + o.size + 'px ' + (o.family || R.FONT_DISPLAY);
        ctx.fillStyle = typeof o.colour === 'string' ? o.colour : R.css(o.colour);
        ctx.textAlign = o.align || 'left';
        ctx.textBaseline = 'alphabetic';
        ctx.fillText(s, x, y);
      },
      /**
       * Measure a string in a given face.
       * @param {string} s The string.
       * @param {object} o {size, family, weight}.
       * @returns {number} Width in px, or an estimate when there is no context.
       */
      measure: function (s, o) {
        if (!ctx) return String(s).length * o.size * 0.5;
        ctx.font = (o.weight || '') + ' ' + o.size + 'px ' + (o.family || R.FONT_DISPLAY);
        return ctx.measureText(String(s)).width;
      },
    };
    return rec;
  };

  //---------------------------------------------------------------------------
  // Letter-spaced supporting text and the fitter.
  //---------------------------------------------------------------------------

  /**
   * Width of a tracked (letter-spaced) string.
   * @param {object} rec Recorder.
   * @param {string} s The string.
   * @param {object} o {size, family, track}.
   * @returns {number} Width in px.
   */
  R.trackedWidth = function (rec, s, o) {
    const str = String(s);
    const track = o.track || 0;
    let w = 0;
    for (let i = 0; i < str.length; i++) w += rec.measure(str[i], o) + track;
    return w - (str.length ? track : 0);
  };

  /**
   * Draw a tracked string, left-aligned at x with baseline y.
   * @param {object} rec Recorder.
   * @param {string} s The string.
   * @param {number} x Left edge.
   * @param {number} y Baseline.
   * @param {object} o {size, family, colour, track, weight}.
   * @returns {number} The width drawn.
   */
  R.tracked = function (rec, s, x, y, o) {
    const str = String(s);
    const track = o.track || 0;
    let cx = x;
    const opt = {
      size: o.size, family: o.family, colour: o.colour,
      weight: o.weight, align: 'left',
    };
    for (let i = 0; i < str.length; i++) {
      rec.text(str[i], cx, y, opt);
      cx += rec.measure(str[i], opt) + track;
    }
    return cx - x - (str.length ? track : 0);
  };

  /**
   * Fit a string into a width.
   *
   * A fitter that can fail to fit MUST say so. `fitTracked`
   * once shrank to its minimum and returned a still-too-wide result which the
   * caller drew anyway, and "SEVEN OF WANDS" shipped as "SEVEN OF WAND". This
   * returns `fits`, and every caller in this product reads it.
   *
   * @param {object} rec Recorder.
   * @param {string} s The string.
   * @param {number} maxW Available width.
   * @param {object} o {size, family, track} — the STARTING style.
   * @param {number} minSize Smallest size allowed.
   * @returns {{size:number, track:number, width:number, fits:boolean}}
   */
  R.fitTracked = function (rec, s, maxW, o, minSize) {
    const floor = minSize || 9;
    let size = o.size;
    let track = o.track || 0;
    let w = R.trackedWidth(rec, s, { size: size, family: o.family, track: track });
    while (w > maxW && track > 0) {
      track = Math.max(0, track - 0.3);
      w = R.trackedWidth(rec, s, { size: size, family: o.family, track: track });
    }
    while (w > maxW && size > floor) {
      size -= 1;
      w = R.trackedWidth(rec, s, { size: size, family: o.family, track: track });
    }
    return { size: size, track: track, width: w, fits: w <= maxW };
  };

  //---------------------------------------------------------------------------
  // Geometry
  //---------------------------------------------------------------------------

  /**
   * Rounded rectangle path (does not fill or stroke).
   * `arcTo` throws on a negative radius; it is clamped here
   * so no caller has to remember.
   * @param {object} rec Recorder.
   * @param {number} x Left. @param {number} y Top.
   * @param {number} w Width. @param {number} h Height. @param {number} r Radius.
   */
  R.roundRect = function (rec, x, y, w, h, r) {
    const rr = Math.max(0, Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2));
    rec.begin();
    rec.moveTo(x + rr, y);
    rec.lineTo(x + w - rr, y);
    rec.quadTo(x + w, y, x + w, y + rr);
    rec.lineTo(x + w, y + h - rr);
    rec.quadTo(x + w, y + h, x + w - rr, y + h);
    rec.lineTo(x + rr, y + h);
    rec.quadTo(x, y + h, x, y + h - rr);
    rec.lineTo(x, y + rr);
    rec.quadTo(x, y, x + rr, y);
    rec.close();
  };

  /**
   * Linearly interpolate two screen points.
   * @param {number[]} a [x,y]. @param {number[]} b [x,y]. @param {number} t 0..1.
   * @returns {number[]} [x,y].
   */
  R.lerp2 = function (a, b, t) {
    return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
  };

  /**
   * Resample a polyline through a Catmull-Rom spline.
   *
   * THIS IS A STRUCTURAL TRANSFORM, NOT A STYLE ONE, and it is why the four
   * hands in IdentAlphabet.js differ in construction rather than in
   * parameters: a palette is not a composition. An angular
   * hand simply does not call it, so its O really is a lozenge of straight
   * facets and not a circle with a different colour.
   *
   * @param {number[][]} pts Control points.
   * @param {number} per Samples per segment.
   * @param {boolean} closed Treat as a closed ring.
   * @returns {number[][]} Sampled points.
   */
  R.smooth = function (pts, per, closed) {
    const n = pts.length;
    if (n < 3) return pts.map(function (p) { return [p[0], p[1]]; });
    const steps = Math.max(2, per | 0);
    const out = [];
    const last = closed ? n : n - 1;
    for (let i = 0; i < last; i++) {
      const p0 = pts[closed ? (i - 1 + n) % n : Math.max(0, i - 1)];
      const p1 = pts[i % n];
      const p2 = pts[(i + 1) % n];
      const p3 = pts[closed ? (i + 2) % n : Math.min(n - 1, i + 2)];
      for (let s = 0; s < steps; s++) {
        const t = s / steps;
        const t2 = t * t;
        const t3 = t2 * t;
        out.push([
          0.5 * ((2 * p1[0]) + (-p0[0] + p2[0]) * t
            + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2
            + (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3),
          0.5 * ((2 * p1[1]) + (-p0[1] + p2[1]) * t
            + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2
            + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3),
        ]);
      }
    }
    if (!closed) out.push([pts[n - 1][0], pts[n - 1][1]]);
    return out;
  };

  //---------------------------------------------------------------------------
  // Deterministic surface noise.
  //
  // A title screen is mostly GROUND. A flat fill behind a beautifully cut
  // wordmark is still a flat fill, and it is the single thing that makes a
  // generated screen look generated. Every material here is built from this one
  // noise function so a surface is reproducible frame to frame and machine to
  // machine — Math.random() would make the leather crawl.
  //---------------------------------------------------------------------------

  /**
   * Deterministic 2-D value noise in [0,1). Hash-based, no tables, no state.
   * @param {number} x Sample x.
   * @param {number} y Sample y.
   * @param {number} seed Field seed.
   * @returns {number} Value in [0,1).
   */
  R.noise2 = function (x, y, seed) {
    let h = (seed >>> 0) ^ 0x9E3779B9;
    h = Math.imul(h ^ (Math.floor(x) | 0), 0x85EBCA6B);
    h ^= h >>> 13;
    h = Math.imul(h ^ (Math.floor(y) | 0), 0xC2B2AE35);
    h ^= h >>> 16;
    return (h >>> 0) / 4294967296;
  };

  /**
   * Smoothed value noise — bilinear over the integer lattice.
   * @param {number} x Sample x.
   * @param {number} y Sample y.
   * @param {number} seed Field seed.
   * @returns {number} Value in [0,1].
   */
  R.snoise = function (x, y, seed) {
    const xi = Math.floor(x);
    const yi = Math.floor(y);
    const xf = x - xi;
    const yf = y - yi;
    const u = xf * xf * (3 - 2 * xf);
    const v = yf * yf * (3 - 2 * yf);
    const a = R.noise2(xi, yi, seed);
    const b = R.noise2(xi + 1, yi, seed);
    const c = R.noise2(xi, yi + 1, seed);
    const d = R.noise2(xi + 1, yi + 1, seed);
    return (a + (b - a) * u) + ((c + (d - c) * u) - (a + (b - a) * u)) * v;
  };

  /**
   * Fractal sum of `snoise`, for surfaces with detail at more than one scale.
   * @param {number} x Sample x.
   * @param {number} y Sample y.
   * @param {number} seed Field seed.
   * @param {number} oct Octaves.
   * @returns {number} Value in [0,1].
   */
  R.fbm = function (x, y, seed, oct) {
    let sum = 0;
    let amp = 1;
    let norm = 0;
    let f = 1;
    const n = Math.max(1, oct | 0);
    for (let i = 0; i < n; i++) {
      sum += amp * R.snoise(x * f, y * f, seed + i * 7919);
      norm += amp;
      amp *= 0.5;
      f *= 2;
    }
    return sum / norm;
  };

  //---------------------------------------------------------------------------
  // THE TWO SCALE LAWS. Both are stated in ABSOLUTE
  // PIXELS, because the eye reads pixels and not proportions.
  //---------------------------------------------------------------------------

  /**
   * Derive a pen from the shape it outlines, NEVER from
   * the figure that contains it.
   *
   * One ink width taken from overall height was used for every mark in a
   * product and consumed ALL SIXTEEN CELLS of a contact sheet: on a head of
   * radius 23px it gave a 5px outline — 22% of the radius — and every feature
   * inside disappeared under the border of the shape holding it.
   *
   * THE CONSTANT IS 0.08 OF THE FULL SHORT SIDE, NOT 0.16. The measurement
   * base decides it: read against the full bounding box, min(46,46)*0.16 = 7.36 PERMITS
   * the exact 5px pen the rule exists because of. Read against the RADIUS, as
   * the measured sentence does, 0.16*23 = 3.68 correctly refuses it. Expressed
   * against the full short side that is 0.08.
   *
   * @param {number} w Width of the shape being outlined, px (full extent).
   * @param {number} h Height of the shape being outlined, px (full extent).
   * @param {number} basePen The figure-scale pen, px — treated as a CEILING.
   * @returns {number} Pen width in px.
   */
  R.penFor = function (w, h, basePen) {
    const small = Math.min(Math.abs(w), Math.abs(h));
    return Math.max(0.9, Math.min(basePen, small * 0.08));
  };

  /** @type {number} Paper that must survive BETWEEN two marks, px. */
  R.PAPER_MIN = 2.6;

  /**
   * A spacing floor is ABSOLUTE PIXELS, not a ratio — and
   * a ratio fails at the thin end.
   *
   * MEASURED across 4 ink widths x 21 pitches: the first pitch
   * that leaves real paper is NOT one ratio. It moves by 1.8x across the range.
   * Subtract the ink and all four rows collapse: every failing case left <=
   * 2.4px of paper, every passing case >= 2.49px. So the law is
   * `pitch = ink + PAPER_MIN`.
   *
   * The payoff is a DERIVED count rather than a typed one. A border asking for
   * 40 dentils on a 90px run cannot have 40 — it can have 13 — and the honest
   * answer is to draw 13 rather than smear 40 into a grey band.
   *
   * @param {number} span Length available for the run of marks, px.
   * @param {number} ink Width of one mark, px.
   * @param {number} want How many marks the corpus asked for.
   * @returns {{count:number, pitch:number, fits:boolean}} What actually resolves.
   */
  R.fitLines = function (span, ink, want) {
    const pitch = Math.abs(ink) + R.PAPER_MIN;
    if (!(span > 0) || !(pitch > 0)) return { count: 0, pitch: pitch, fits: false };
    const max = Math.floor(span / pitch);
    const count = Math.max(0, Math.min(want, max));
    return { count: count, pitch: pitch, fits: count >= want };
  };

  /**
   * Derive a repeat count from a PITCH, never take one as a count.
   *
   * Measured on a bezel corpus that declared
   * `marks: 18` for beading, and on a 700px perimeter that put eighteen beads
   * 39px apart — eighteen specks on a bare edge, and all seven treatments
   * rendered as the same yellow rectangle. A COUNT cannot express a worked
   * band, because the right count changes with the size of the piece. Declare
   * the pitch as a multiple of the band thickness and DERIVE the count.
   *
   * @param {number} span Run length, px.
   * @param {number} band Band thickness the pitch is relative to, px.
   * @param {number} pitchMul Pitch as a multiple of `band`.
   * @param {number} ink Mark width, px — for the absolute floor.
   * @returns {{count:number, pitch:number, floored:boolean}}
   */
  R.repeatsFor = function (span, band, pitchMul, ink) {
    const want = Math.max(1, Math.round(span / Math.max(0.001, band * pitchMul)));
    const fit = R.fitLines(span, ink, want);
    return {
      count: Math.max(1, fit.count),
      pitch: span / Math.max(1, fit.count),
      floored: !fit.fits,
    };
  };
})();

/* Under Node this lets the suite and the probes require the SHIPPED file rather
 * than a copy, which is the only way a test can be about the product. In MZ
 * `module` does not exist and the line is skipped. */
if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.Ident.Render;
