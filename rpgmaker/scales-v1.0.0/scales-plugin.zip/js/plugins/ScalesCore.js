//=============================================================================
// ScalesCore.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Scales core - generated weighing puzzles (the
 * counterfeit coin and weighing out a measure), proven winnable by a solver.
 * Place ABOVE ScalesDraw and Scales.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The puzzle generator, the solver and the counterfeiter for Scales. No
 * parameters or commands of its own; Scales.js is the file you configure.
 * Must be installed and listed above Scales.js.
 *
 * Pure logic: nothing here touches the screen and nothing uses Math.random.
 *
 * THE COUNTERFEIT. A hoard of identical coins hides one counterfeit, lighter
 * or heavier. The number of weighings allowed is the smallest number for
 * which a winning strategy EXISTS, found by an exact search of the whole
 * game tree before the player sees the puzzle. The counterfeit is not fixed
 * in advance: after every weighing it is placed wherever the weighings so far
 * leave it most hidden. So a lucky guess cannot win, and a correct strategy
 * always does.
 *
 * THE MEASURE. Weigh out an exact amount of goods with a box of weights,
 * which may go in either pan. Every target is checked reachable by trying
 * every placement of every weight before it is offered.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var ScalesCore = (function () {
  'use strict';

  function hashString(s) { var h = 0x811c9dc5; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h >>> 0; }
  function rng(seed) {
    var a = seed >>> 0;
    return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function pick(r, a) { return a[Math.floor(r() * a.length) % a.length]; }
  function randInt(r, lo, hi) { return lo + (Math.floor(r() * (hi - lo + 1)) % (hi - lo + 1)); }

  //===========================================================================
  // The counterfeit: an exact solver over COUNT states.
  //
  // Coins are interchangeable except for what the weighings have taught about
  // them, so a position is four counts: u coins that could be heavy OR light,
  // h that could only be heavy, l that could only be light, g known genuine.
  // The hypotheses left are 2u + h + l. A weighing puts some of each class on
  // each pan (same number of coins on both). Its three outcomes:
  //   balance    -> every coin on a pan is genuine
  //   left heavy -> the counterfeit is a heavy one on the left or a light one
  //                 on the right: h' = u1 + h1, l' = u2 + l2, the rest genuine
  //   right heavy-> mirror image.
  // solvable(state, k) asks: is there a weighing whose every outcome is
  // solvable in k - 1? It is exact, memoised, and fast for a hoard of 13.
  //===========================================================================

  var MEMO = {};
  function hyps(s) { return 2 * s[0] + s[1] + s[2]; }
  /** The three outcome states of weighing w = [u1,h1,l1,g1,u2,h2,l2,g2] from state s = [u,h,l,g]. */
  function outcomes(s, w) {
    var n = s[0] + s[1] + s[2] + s[3];
    var bal = [s[0] - w[0] - w[4], s[1] - w[1] - w[5], s[2] - w[2] - w[6], 0]; bal[3] = n - bal[0] - bal[1] - bal[2];
    var lh = [0, w[0] + w[1], w[4] + w[6], 0]; lh[3] = n - lh[1] - lh[2];
    var rh = [0, w[4] + w[5], w[0] + w[2], 0]; rh[3] = n - rh[1] - rh[2];
    return [lh, bal, rh];
  }
  /**
   * Can the counterfeit be found (and its direction named) from state s in k more weighings?
   * @param {number[]} s [u, h, l, g]
   * @param {number} k
   * @returns {boolean}
   */
  function solvable(s, k) {
    var H = hyps(s);
    if (H <= 1) return true;
    if (k <= 0 || H > Math.pow(3, k)) return false;
    var key = s.join(',') + '|' + k;
    if (key in MEMO) return MEMO[key];
    var ok = !!firstGoodWeighing(s, k);
    MEMO[key] = ok; return ok;
  }
  /** A weighing whose three outcomes are all solvable in k - 1, or null. (Used by the solver and by the hint proof.) */
  function firstGoodWeighing(s, k) {
    var u = s[0], h = s[1], l = s[2], g = s[3], u1, u2, h1, h2, l1, l2, g1, g2;
    for (u1 = 0; u1 <= u; u1++) for (u2 = 0; u2 <= u - u1; u2++)
    for (h1 = 0; h1 <= h; h1++) for (h2 = 0; h2 <= h - h1; h2++)
    for (l1 = 0; l1 <= l; l1++) for (l2 = 0; l2 <= l - l1; l2++) {
      var a = u1 + h1 + l1, b = u2 + h2 + l2;
      // genuine coins only ever top up the lighter-counted pan
      g1 = b > a ? b - a : 0; g2 = a > b ? a - b : 0;
      if (g1 + g2 > g || a + g1 === 0) continue;
      // canonical: never try the mirror image of a weighing already tried
      if (u1 < u2 || (u1 === u2 && (h1 + l2 < h2 + l1))) continue;
      var w = [u1, h1, l1, g1, u2, h2, l2, g2], o = outcomes(s, w);
      if (solvable(o[0], k - 1) && solvable(o[1], k - 1) && solvable(o[2], k - 1)) return w;
    }
    return null;
  }
  /** The fewest weighings that always find the counterfeit among n coins. `known` = its direction is told. */
  function minWeighings(n, known) {
    var s = known ? [0, n, 0, 0] : [n, 0, 0, 0];
    for (var k = 0; k < 8; k++) if (solvable(s, k)) return k;
    return -1;
  }

  //===========================================================================
  // Mints: one design per hoard (every coin in it is identical - that is the puzzle).
  //===========================================================================

  // names only: the colours live in ScalesDraw.METALS, the one place that paints them (wing §11a: one copy of a constant)
  var METALS = { gold: { name: 'gold' }, silver: { name: 'silver' }, copper: { name: 'copper' }, electrum: { name: 'electrum' }, bronze: { name: 'bronze' } };
  var METAL_IDS = Object.keys(METALS);
  var DEVICES = ['star', 'rosette', 'cross', 'sun', 'crescent', 'tower'];
  var RIMS = ['beaded', 'milled', 'rope'];
  var MINT_NAMES = { star: 'Star', rosette: 'Rose', cross: 'Cross', sun: 'Sun', crescent: 'Moon', tower: 'Tower' };
  var UNITS = { gold: 'crowns', silver: 'marks', copper: 'pence', electrum: 'staters', bronze: 'obols' };

  /** A generated mint: metal, device and its own proportions, rim, legend. Deterministic from the seed. */
  function mint(seed, opt) {
    var r = rng((seed >>> 0) ^ 0x3171), o = opt || {};
    var metal = METAL_IDS.indexOf(o.metal) >= 0 ? o.metal : pick(r, METAL_IDS), device = DEVICES.indexOf(o.device) >= 0 ? o.device : pick(r, DEVICES);
    return { seed: seed >>> 0, metal: metal, device: device, rim: pick(r, RIMS), points: randInt(r, 5, 8), petals: randInt(r, 5, 8), rays: randInt(r, 8, 16),
      inner: 0.34 + r() * 0.14, legend: randInt(r, 18, 30), pellets: r() < 0.5, ring: r() < 0.6, name: 'The ' + MINT_NAMES[device] + ' ' + METALS[metal].name.charAt(0).toUpperCase() + METALS[metal].name.slice(1), unit: UNITS[metal] };
  }

  //===========================================================================
  // Puzzle generation
  //===========================================================================

  var DIFFS = ['easy', 'normal', 'hard'];

  /**
   * A counterfeit puzzle: n coins of one mint, whether the direction is told, and the weighings allowed (the proven
   * minimum). @param {Object} opt {seed, difficulty?, coins?}
   */
  function counterfeit(opt) {
    opt = opt || {};
    var seed = Number(opt.seed) >>> 0, r = rng(seed ^ 0xC0), diff = DIFFS.indexOf(opt.difficulty) >= 0 ? opt.difficulty : pick(r, DIFFS);
    var n, known, dir = 0;
    if (diff === 'easy') { n = pick(r, [3, 4, 6, 8, 9]); known = true; dir = r() < 0.5 ? -1 : 1; }
    else if (diff === 'normal') { n = pick(r, [4, 5, 6, 8, 9]); known = r() < 0.5; dir = known ? (r() < 0.5 ? -1 : 1) : 0; if (known) n = pick(r, [10, 12, 13]); }
    else { n = pick(r, [10, 11, 12]); known = false; }
    var cn = Math.floor(Number(opt.coins));
    if (cn >= 3 && cn <= 13) n = cn;
    var k = minWeighings(n, known);
    return { v: 1, kind: 'counterfeit', seed: seed, difficulty: diff, n: n, known: known, dir: dir, weighings: k, mint: mint(seed ^ 0x77) };
  }

  /** Every signed sum of the weights (each weight on the goods pan, the other pan, or neither) and a way to make it. */
  function reach(weights) {
    var out = {}, n = weights.length, total = Math.pow(3, n);
    for (var c = 0; c < total; c++) {
      var x = c, sum = 0, used = 0, place = [];
      for (var i = 0; i < n; i++) { var d = x % 3; x = (x - d) / 3; var p = d === 2 ? -1 : d; place.push(p); sum += p * weights[i]; if (p) used++; }
      // p = +1: on the far pan (opposite the goods); p = -1: on the goods pan
      if (sum > 0 && (!out[sum] || used < out[sum].used)) out[sum] = { used: used, place: place, bothPans: place.indexOf(-1) >= 0 };
    }
    return out;
  }
  var WEIGHT_SETS = [
    { name: 'the ternary set', w: [1, 3, 9, 27] },
    { name: 'the doubling set', w: [1, 2, 4, 8, 16], bothPans: false },
    { name: "the apothecary's set", w: [1, 2, 5, 10, 20] },
    { name: "the spicer's set", w: [2, 3, 7, 15, 25] },
    { name: "the assayer's set", w: [1, 4, 6, 13, 22] },
  ];
  var GOODS = ['saffron', 'pepper', 'silver dust', 'salt', 'tea', 'cloves', 'myrrh', 'indigo'];

  /**
   * A measure puzzle: a weight box and a target the box can make. easy = one pan is enough; normal/hard = every way
   * to make it needs a weight in the goods pan too (hard = the most weights). @param {Object} opt {seed, difficulty?}
   */
  function measure(opt) {
    opt = opt || {};
    var seed = Number(opt.seed) >>> 0, r = rng(seed ^ 0x5E), diff = DIFFS.indexOf(opt.difficulty) >= 0 ? opt.difficulty : pick(r, DIFFS);
    // ⛔ measured 2026-09-27 (_probe/solver_probe.js): the doubling set makes EVERY target with one pan, so normal and
    // hard fell through to "any target" and served one-weight puzzles. Only sets that HAVE a both-pans target are drawn
    // for normal and hard; the doubling set is an easy-only box.
    var pool = diff === 'easy' ? WEIGHT_SETS : WEIGHT_SETS.filter(function (s) { return s.bothPans !== false; });
    var set = pick(r, pool), R = reach(set.w), cands = [], t;
    for (t in R) {
      var e = R[t], oneSide = true, tt = Number(t);
      // does ANY one-pan way to make t exist? (subset sum)
      oneSide = subsetSum(set.w, tt);
      if (diff === 'easy' ? (oneSide && e.used >= 2) : (!oneSide && (diff === 'hard' ? e.used >= 3 : e.used >= 2))) cands.push(tt);
    }
    if (!cands.length) for (t in R) if (R[t].used >= 2) cands.push(Number(t));
    cands.sort(function (a, b) { return a - b; });
    var target = cands[Math.floor(r() * cands.length) % cands.length];
    return { v: 1, kind: 'measure', seed: seed, difficulty: diff, weights: set.w.slice(), setName: set.name, target: target, goods: pick(r, GOODS), fewest: R[target].used, solution: R[target].place.slice(), bothPans: !subsetSum(set.w, target), mint: mint(seed ^ 0x77) };
  }
  function subsetSum(w, t) { for (var m = 1; m < (1 << w.length); m++) { var s = 0; for (var i = 0; i < w.length; i++) if (m & (1 << i)) s += w[i]; if (s === t) return true; } return false; }

  //===========================================================================
  // Playing a counterfeit puzzle: the counterfeiter (an adversary)
  //===========================================================================

  /** A fresh play state: every coin could be heavy or light (or only the told direction). */
  function newGame(p) {
    var st = [];
    for (var i = 0; i < p.n; i++) st.push(p.known ? (p.dir > 0 ? 'H' : 'L') : 'U');
    return { status: st, left: p.weighings, log: [], over: false };
  }
  function countState(st) { var s = [0, 0, 0, 0]; for (var i = 0; i < st.length; i++) s['UHLG'.indexOf(st[i])]++; return s; }
  /** Every (coin, direction) the weighings still allow. dir +1 heavy, -1 light. */
  function hypotheses(st) { var out = []; for (var i = 0; i < st.length; i++) { if (st[i] === 'U' || st[i] === 'H') out.push({ coin: i, dir: 1 }); if (st[i] === 'U' || st[i] === 'L') out.push({ coin: i, dir: -1 }); } return out; }

  /**
   * Weigh coin lists L against R. Returns the outcome (+1 left pan heavy, 0 balance, -1 right pan heavy) and updates
   * the game, or null if the pans hold different numbers of coins, a coin twice, or no weighings are left.
   * The counterfeiter answers with the outcome that the weighings allow and that hides the coin best: an outcome
   * from which the puzzle can no longer be won, if the player's weighing left one; else the one leaving the most
   * possibilities (ties broken by the puzzle's seed).
   */
  function weigh(p, game, L, R) {
    if (game.over || game.left <= 0 || !L.length || L.length !== R.length) return null;
    var seen = {}, i;
    for (i = 0; i < L.length; i++) { if (seen[L[i]] || L[i] < 0 || L[i] >= p.n) return null; seen[L[i]] = 1; }
    for (i = 0; i < R.length; i++) { if (seen[R[i]] || R[i] < 0 || R[i] >= p.n) return null; seen[R[i]] = 1; }
    var res = [1, 0, -1].map(function (o) { return { o: o, st: after(game.status, L, R, o) }; });
    var live = res.filter(function (x) { return hypotheses(x.st).length > 0; });
    var k = game.left - 1, r = rng((p.seed ^ 0xADD) + game.log.length * 7919 + L.length * 31 + R[0] * 3 + L[0]);
    var lost = live.filter(function (x) { return !solvable(countState(x.st), k); });
    var pool = lost.length ? lost : live, best = -1, choice = [];
    for (i = 0; i < pool.length; i++) { var hn = hypotheses(pool[i].st).length; if (hn > best) { best = hn; choice = [pool[i]]; } else if (hn === best) choice.push(pool[i]); }
    var c = choice[Math.floor(r() * choice.length) % choice.length];
    game.status = c.st; game.left = k; game.log.push({ L: L.slice(), R: R.slice(), o: c.o, hyps: hypotheses(c.st).length, winnable: solvable(countState(c.st), k) });
    return c.o;
  }
  function after(st, L, R, o) {
    var out = st.slice(), onL = {}, onR = {}, i;
    for (i = 0; i < L.length; i++) onL[L[i]] = 1; for (i = 0; i < R.length; i++) onR[R[i]] = 1;
    for (i = 0; i < out.length; i++) {
      var s = out[i]; if (s === 'G') continue;
      var canH = s === 'U' || s === 'H', canL = s === 'U' || s === 'L';
      // under outcome o, could coin i be the heavy one? the light one?
      var hOK = canH && (onL[i] ? o === 1 : onR[i] ? o === -1 : o === 0), lOK = canL && (onL[i] ? o === -1 : onR[i] ? o === 1 : o === 0);
      out[i] = hOK && lOK ? 'U' : hOK ? 'H' : lOK ? 'L' : 'G';
    }
    return out;
  }

  /**
   * A weighing that keeps the puzzle winnable from where the game stands, as real coin numbers: {L, R}, or null if
   * the weighings made so far have already lost it (or nothing is left to learn). Takes the solver's count-level move
   * and fills each class from the coins in that class, lowest numbers first.
   */
  function hint(p, game) {
    var s = countState(game.status);
    if (hyps(s) <= 1 || game.left <= 0) return null;
    var w = firstGoodWeighing(s, game.left); if (!w) return null;
    var pools = { U: [], H: [], L: [], G: [] }, i;
    for (i = 0; i < game.status.length; i++) pools[game.status[i]].push(i);
    var take = function (cls, k) { return pools[cls].splice(0, k); };
    var L = [].concat(take('U', w[0]), take('H', w[1]), take('L', w[2]), take('G', w[3]));
    var R = [].concat(take('U', w[4]), take('H', w[5]), take('L', w[6]), take('G', w[7]));
    return { L: L, R: R };
  }

  /**
   * The player names the counterfeit (and, when it was not told, whether it is heavy or light). Wins only if the
   * weighings have left exactly that one possibility; otherwise the counterfeiter shows another the weighings
   * still allowed. @returns {{won:boolean, coin:number, dir:number}}
   */
  function accuse(p, game, coin, dir) {
    var H = hypotheses(game.status), d = p.known ? p.dir : dir;
    var mine = H.filter(function (h) { return h.coin === coin && h.dir === d; });
    game.over = true;
    if (H.length === 1 && mine.length === 1) { game.result = { won: true, coin: coin, dir: d }; return game.result; }
    var other = H.filter(function (h) { return !(h.coin === coin && h.dir === d); });
    var r = rng(p.seed ^ 0xF00 ^ coin), t = other.length ? other[Math.floor(r() * other.length) % other.length] : H[0];
    game.result = { won: false, coin: t.coin, dir: t.dir };
    return game.result;
  }

  /** Measure mode: the pans balance when goods + weights on the goods pan equal the weights on the far pan. */
  function measureBalance(p, place) { var s = -p.target; for (var i = 0; i < p.weights.length; i++) s += (place[i] || 0) * p.weights[i]; return s; }

  /** A fresh measure play state: every weight in its box (0), +1 = on the far pan, -1 = on the goods pan. */
  function newMeasure(p) { var place = []; for (var i = 0; i < p.weights.length; i++) place.push(0); return { place: place, log: [], over: false }; }

  /**
   * Weigh the goods (the target amount, on the LEFT pan with any weights placed there) against the far pan.
   * @returns {number} +1 the left (goods) pan sinks, 0 the beam is level (solved), -1 the far pan sinks
   */
  function measureWeigh(p, game) {
    if (game.over) return null;
    var s = measureBalance(p, game.place), o = s < 0 ? 1 : (s > 0 ? -1 : 0), used = 0;
    for (var i = 0; i < game.place.length; i++) if (game.place[i]) used++;
    game.log.push({ place: game.place.slice(), o: o, used: used });
    if (o === 0) { game.over = true; game.result = { won: true, weighings: game.log.length, used: used, fewest: p.fewest }; }
    return o;
  }

  return {
    VERSION: '1.0.0', DIFFS: DIFFS, METALS: METALS, METAL_IDS: METAL_IDS, DEVICES: DEVICES, RIMS: RIMS, WEIGHT_SETS: WEIGHT_SETS, GOODS: GOODS,
    hashString: hashString, rng: rng, mint: mint, solvable: solvable, firstGoodWeighing: firstGoodWeighing, outcomes: outcomes, minWeighings: minWeighings,
    counterfeit: counterfeit, measure: measure, reach: reach, subsetSum: subsetSum, newGame: newGame, countState: countState, hypotheses: hypotheses,
    weigh: weigh, accuse: accuse, after: after, hint: hint, measureBalance: measureBalance, newMeasure: newMeasure, measureWeigh: measureWeigh,
  };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = ScalesCore;
