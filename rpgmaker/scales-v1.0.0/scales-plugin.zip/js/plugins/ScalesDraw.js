//=============================================================================
// ScalesDraw.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Scales draw - the brass balance, generated coins, bell
 * weights, the coin tray, the ledger and the counting-house table, all drawn in
 * code. Place BETWEEN ScalesCore and Scales.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * Every picture Scales shows is drawn here onto a canvas: no image file is
 * loaded. No parameters of its own. Must be installed below ScalesCore.js and
 * above Scales.js.
 *
 * The balance is drawn in parts (beam, two pans, the column) so the scene can
 * swing the beam by moving sprites, without repainting anything per frame.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var ScalesDraw = (function () {
  'use strict';
  var TAU = Math.PI * 2;
  var FACE = '"Palatino Linotype", "Book Antiqua", Palatino, "Georgia", serif';
  var INK = '#2c2014', PAPER = ['#f7eed8', '#e9dab8'];
  var BRASS = { lite: '#fff1c0', hi: '#f2d27e', mid: '#c9983e', lo: '#8a6220', dark: '#4e3510' };

  function rng(seed) { var a = seed >>> 0; return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function rr(ctx, x, y, w, h, r) { r = Math.max(0, Math.min(r, w / 2, h / 2)); ctx.beginPath(); ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r); ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h); ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r); ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.closePath(); }
  /** Lighten (k > 0) or darken (k < 0) a '#rrggbb' colour. An unparseable colour is returned unchanged (never NaN). */
  function shade(hex, k) { var v = parseInt(String(hex).slice(1), 16); if (!/^#[0-9a-fA-F]{6}$/.test(String(hex)) || !isFinite(v)) return hex; var r = (v >> 16) & 255, g = (v >> 8) & 255, b = v & 255; var f = function (c) { return Math.max(0, Math.min(255, Math.round(k >= 0 ? c + (255 - c) * k : c * (1 + k)))); }; return 'rgb(' + f(r) + ',' + f(g) + ',' + f(b) + ')'; }
  function brassGrad(ctx, x0, y0, x1, y1) { var g = ctx.createLinearGradient(x0, y0, x1, y1); g.addColorStop(0, BRASS.lo); g.addColorStop(0.3, BRASS.hi); g.addColorStop(0.5, BRASS.lite); g.addColorStop(0.7, BRASS.mid); g.addColorStop(1, BRASS.dark); return g; }

  //===========================================================================
  // The counting-house table
  //===========================================================================

  /**
   * Walnut counter with a green baize inlay, lit by a candle from above the balance. `inlay` {x, y, w, h} moves the
   * baize (default: under the balance and the tray).
   */
  function drawTable(ctx, W, H, inlay) {
    var g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#2e1c10'); g.addColorStop(1, '#170d07'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    var r = rng(0x5CA1);
    // walnut grain, every line running past the edge (Sampler's x=800 band, measured)
    for (var y = 0; y < H; y += 3) { ctx.strokeStyle = r() < 0.5 ? 'rgba(255,210,160,0.03)' : 'rgba(0,0,0,0.13)'; ctx.lineWidth = 1 + r() * 2; ctx.beginPath(); ctx.moveTo(-10, y); for (var x = -10; x < W + 50; x += 40) ctx.lineTo(x, y + Math.sin(x / 97 + y / 41) * 2.2); ctx.stroke(); }
    // baize inlay under the balance and the tray
    var bx = inlay ? inlay.x : 12, by = inlay ? inlay.y : 12, bw = inlay ? inlay.w : 536, bh = inlay ? inlay.h : H - 24, lx = bx + bw / 2;
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; rr(ctx, bx + 3, by + 5, bw, bh, 8); ctx.fill();
    var bg = ctx.createRadialGradient(lx, 190, 40, lx, 260, 460); bg.addColorStop(0, '#2f5a3c'); bg.addColorStop(0.55, '#1e3f29'); bg.addColorStop(1, '#0f2216'); ctx.fillStyle = bg; rr(ctx, bx, by, bw, bh, 8); ctx.fill();
    for (var i = 0; i < bw * bh / 90; i++) { ctx.fillStyle = r() < 0.5 ? 'rgba(160,220,170,0.05)' : 'rgba(0,0,0,0.08)'; ctx.fillRect(bx + r() * bw, by + r() * bh, 1, 1 + r() * 2); }
    // a brass bead round the inlay
    ctx.strokeStyle = BRASS.mid; ctx.lineWidth = 2; rr(ctx, bx + 1, by + 1, bw - 2, bh - 2, 7); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,240,190,0.35)'; ctx.lineWidth = 1; rr(ctx, bx + 3, by + 3, bw - 6, bh - 6, 6); ctx.stroke();
    // candle pool of light, and a vignette
    var lg = ctx.createRadialGradient(lx, 150, 10, lx, 200, 330); lg.addColorStop(0, 'rgba(255,200,120,0.16)'); lg.addColorStop(1, 'rgba(255,200,120,0)'); ctx.fillStyle = lg; ctx.fillRect(0, 0, W, H);
    var vg = ctx.createRadialGradient(W / 2, H / 2, H * 0.35, W / 2, H / 2, H * 0.85); vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.45)'); ctx.fillStyle = vg; ctx.fillRect(0, 0, W, H);
  }

  //===========================================================================
  // The balance, in parts. Geometry is shared with the scene through BAL.
  //===========================================================================

  var BAL = { fx: 270, fy: 104, arm: 180, drop: 168, dishW: 142, dishD: 30, baseY: 366, maxTilt: 0.15 };

  /** The static parts: plinth, fluted column, the scale arc the pointer reads against. */
  function drawStand(ctx) {
    var B = BAL, cx = B.fx;
    ctx.save();
    // shadow on the baize
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.ellipse(cx + 8, B.baseY + 38, 104, 12, 0, 0, TAU); ctx.fill();
    // stepped walnut plinth with brass feet
    var pg = ctx.createLinearGradient(0, B.baseY, 0, B.baseY + 36); pg.addColorStop(0, '#6a4228'); pg.addColorStop(1, '#2d1a0d');
    ctx.fillStyle = pg; rr(ctx, cx - 88, B.baseY + 12, 176, 22, 4); ctx.fill(); rr(ctx, cx - 64, B.baseY, 128, 16, 3); ctx.fill();
    ctx.strokeStyle = 'rgba(255,220,170,0.25)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(cx - 86, B.baseY + 13.5); ctx.lineTo(cx + 86, B.baseY + 13.5); ctx.moveTo(cx - 62, B.baseY + 1.5); ctx.lineTo(cx + 62, B.baseY + 1.5); ctx.stroke();
    [-76, 76].forEach(function (dx) { ctx.fillStyle = brassGrad(ctx, cx + dx - 9, 0, cx + dx + 9, 0); ctx.beginPath(); ctx.ellipse(cx + dx, B.baseY + 36, 10, 4, 0, 0, TAU); ctx.fill(); });
    // column: fluted brass, a base collar and a capital
    var top = B.fy + 16, bot = B.baseY;
    ctx.fillStyle = brassGrad(ctx, cx - 9, 0, cx + 9, 0); ctx.fillRect(cx - 8, top, 16, bot - top);
    ctx.strokeStyle = 'rgba(78,53,16,0.55)'; ctx.lineWidth = 1; for (var f = -4; f <= 4; f += 4) { ctx.beginPath(); ctx.moveTo(cx + f + 0.5, top + 14); ctx.lineTo(cx + f + 0.5, bot - 14); ctx.stroke(); }
    ctx.fillStyle = brassGrad(ctx, cx - 16, 0, cx + 16, 0); rr(ctx, cx - 15, bot - 14, 30, 14, 3); ctx.fill(); rr(ctx, cx - 12, top, 24, 12, 3); ctx.fill();
    ctx.beginPath(); ctx.ellipse(cx, bot - 16, 12, 4, 0, 0, TAU); ctx.fill();
    // the scale arc above the fulcrum (the pointer is on the beam and swings across it)
    var R = 70, a0 = -Math.PI / 2 - 0.42, a1 = -Math.PI / 2 + 0.42;
    ctx.strokeStyle = BRASS.mid; ctx.lineWidth = 7; ctx.beginPath(); ctx.arc(cx, B.fy, R, a0, a1); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,245,210,0.55)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(cx, B.fy, R + 2.5, a0, a1); ctx.stroke();
    ctx.strokeStyle = BRASS.dark; ctx.lineWidth = 1.2;
    for (var k = -6; k <= 6; k++) { var a = -Math.PI / 2 + k * 0.064, l = k === 0 ? 10 : (k % 3 === 0 ? 7 : 4); ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * (R - 3), B.fy + Math.sin(a) * (R - 3)); ctx.lineTo(cx + Math.cos(a) * (R + 3 + (k === 0 ? 4 : 0) - l + 4), B.fy + Math.sin(a) * (R - 3 - l)); ctx.stroke(); }
    // two arms carrying the arc down to the capital
    ctx.strokeStyle = BRASS.lo; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(cx + Math.cos(a0) * R, B.fy + Math.sin(a0) * R); ctx.quadraticCurveTo(cx - 40, B.fy - 6, cx - 10, B.fy + 18); ctx.moveTo(cx + Math.cos(a1) * R, B.fy + Math.sin(a1) * R); ctx.quadraticCurveTo(cx + 40, B.fy - 6, cx + 10, B.fy + 18); ctx.stroke();
    ctx.restore();
  }

  /**
   * The beam, drawn about its pivot at (ox, oy) of its own bitmap (the scene rotates the sprite): a tapered brass
   * beam with scrolled ends, an engraved line, the pointer rising from the pivot. Bitmap size: BEAM_W x BEAM_H.
   */
  var BEAM_W = 420, BEAM_H = 120, BEAM_OX = 210, BEAM_OY = 96;
  function drawBeam(ctx) {
    var ox = BEAM_OX, oy = BEAM_OY, L = BAL.arm;
    ctx.save();
    // pointer: a long needle to the arc, with a counterweight bob
    ctx.fillStyle = brassGrad(ctx, ox - 3, 0, ox + 3, 0); ctx.beginPath(); ctx.moveTo(ox - 3, oy - 4); ctx.lineTo(ox, oy - 78); ctx.lineTo(ox + 3, oy - 4); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = BRASS.dark; ctx.lineWidth = 0.8; ctx.stroke();
    // beam body: thick at the centre, tapering to each end
    var g = ctx.createLinearGradient(0, oy - 9, 0, oy + 9); g.addColorStop(0, BRASS.lite); g.addColorStop(0.35, BRASS.hi); g.addColorStop(0.7, BRASS.mid); g.addColorStop(1, BRASS.dark);
    ctx.fillStyle = g; ctx.beginPath();
    ctx.moveTo(ox - L, oy - 3); ctx.quadraticCurveTo(ox - L / 2, oy - 5, ox - 18, oy - 9); ctx.lineTo(ox + 18, oy - 9); ctx.quadraticCurveTo(ox + L / 2, oy - 5, ox + L, oy - 3);
    ctx.lineTo(ox + L, oy + 3); ctx.quadraticCurveTo(ox + L / 2, oy + 5, ox + 18, oy + 9); ctx.lineTo(ox - 18, oy + 9); ctx.quadraticCurveTo(ox - L / 2, oy + 5, ox - L, oy + 3); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = BRASS.dark; ctx.lineWidth = 1; ctx.stroke();
    // engraved line and punched dots along it
    ctx.strokeStyle = 'rgba(78,53,16,0.6)'; ctx.lineWidth = 0.9; ctx.beginPath(); ctx.moveTo(ox - L + 14, oy); ctx.lineTo(ox - 24, oy); ctx.moveTo(ox + 24, oy); ctx.lineTo(ox + L - 14, oy); ctx.stroke();
    ctx.fillStyle = 'rgba(78,53,16,0.7)'; for (var d = 36; d < L - 20; d += 22) { ctx.beginPath(); ctx.arc(ox - d, oy - 0.2, 1.1, 0, TAU); ctx.arc(ox + d, oy - 0.2, 1.1, 0, TAU); ctx.fill(); }
    // scrolled ends curling up over the hook point
    [-1, 1].forEach(function (s) {
      var ex = ox + s * L;
      ctx.strokeStyle = brassGrad(ctx, ex - 10, oy - 16, ex + 10, oy + 4); ctx.lineWidth = 5; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(ex - s * 6, oy - 1); ctx.quadraticCurveTo(ex + s * 12, oy - 2, ex + s * 12, oy - 12); ctx.quadraticCurveTo(ex + s * 12, oy - 20, ex + s * 4, oy - 19); ctx.quadraticCurveTo(ex - s * 2, oy - 17, ex + s * 2, oy - 11); ctx.stroke();
      ctx.lineCap = 'butt';
      ctx.fillStyle = BRASS.hi; ctx.beginPath(); ctx.arc(ex, oy, 4.2, 0, TAU); ctx.fill(); ctx.strokeStyle = BRASS.dark; ctx.lineWidth = 1; ctx.stroke();
    });
    // the pivot boss
    var bg = ctx.createRadialGradient(ox - 4, oy - 4, 1, ox, oy, 13); bg.addColorStop(0, BRASS.lite); bg.addColorStop(0.6, BRASS.mid); bg.addColorStop(1, BRASS.dark);
    ctx.fillStyle = bg; ctx.beginPath(); ctx.arc(ox, oy, 12, 0, TAU); ctx.fill(); ctx.strokeStyle = BRASS.dark; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = BRASS.dark; ctx.beginPath(); ctx.arc(ox, oy, 3, 0, TAU); ctx.fill();
    ctx.restore();
  }

  /** The fulcrum housing that sits OVER the beam's pivot (static): a stirrup with a knife-edge cap. */
  function drawFulcrum(ctx) {
    var cx = BAL.fx, cy = BAL.fy;
    ctx.save();
    ctx.fillStyle = brassGrad(ctx, cx - 18, 0, cx + 18, 0);
    ctx.beginPath(); ctx.moveTo(cx - 17, cy + 16); ctx.lineTo(cx - 13, cy - 18); ctx.quadraticCurveTo(cx, cy - 27, cx + 13, cy - 18); ctx.lineTo(cx + 17, cy + 16); ctx.lineTo(cx + 9, cy + 16); ctx.lineTo(cx + 7, cy - 12); ctx.quadraticCurveTo(cx, cy - 17, cx - 7, cy - 12); ctx.lineTo(cx - 9, cy + 16); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = BRASS.dark; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = BRASS.lite; ctx.beginPath(); ctx.arc(cx, cy - 22, 4, 0, TAU); ctx.fill(); ctx.strokeStyle = BRASS.dark; ctx.stroke();
    ctx.restore();
  }

  /**
   * A pan and its chains, drawn with the hook at (hx, 6) of its bitmap (PAN_W x PAN_H). `contents(ctx, cx, rimY)` draws
   * whatever lies in the dish, between the dish's back and its front lip. `label` hangs under the dish.
   */
  var PAN_W = 200, PAN_H = 250, PAN_HX = 100;
  function drawPan(ctx, contents, label) {
    var hx = PAN_HX, hy = 6, B = BAL, rimY = hy + B.drop, w = B.dishW, d = B.dishD;
    ctx.clearRect(0, 0, PAN_W, PAN_H);
    ctx.save();
    // hook ring
    ctx.strokeStyle = BRASS.mid; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(hx, hy + 4, 4, 0, TAU); ctx.stroke();
    // three chains: two outer, one to the back of the rim
    var ends = [[hx - w / 2 + 6, rimY], [hx + w / 2 - 6, rimY], [hx, rimY - 8]];
    ends.forEach(function (e, ci) {
      var len = Math.hypot(e[0] - hx, e[1] - hy - 8), n = Math.floor(len / 7);
      for (var i = 0; i < n; i++) {
        var t = (i + 0.5) / n, x = hx + (e[0] - hx) * t, y = hy + 8 + (e[1] - hy - 8) * t, ang = Math.atan2(e[1] - hy, e[0] - hx);
        ctx.strokeStyle = ci === 2 ? 'rgba(138,98,32,0.7)' : (i % 2 ? BRASS.mid : BRASS.hi); ctx.lineWidth = 1.4;
        ctx.beginPath(); if (i % 2) ctx.ellipse(x, y, 1.4, 3.6, ang - Math.PI / 2, 0, TAU); else ctx.ellipse(x, y, 3.6, 1.8, ang, 0, TAU); ctx.stroke();
      }
    });
    // dish: the back of the rim, the contents, then the bowl and the front lip
    ctx.fillStyle = shade(BRASS.lo, -0.2); ctx.beginPath(); ctx.ellipse(hx, rimY, w / 2, 9, 0, Math.PI, TAU); ctx.fill();
    var ig = ctx.createLinearGradient(0, rimY - 9, 0, rimY + 9); ig.addColorStop(0, '#5a3e14'); ig.addColorStop(1, '#8a6224'); ctx.fillStyle = ig; ctx.beginPath(); ctx.ellipse(hx, rimY, w / 2 - 3, 7.5, 0, 0, TAU); ctx.fill();
    if (contents) contents(ctx, hx, rimY);
    var bg = ctx.createLinearGradient(hx - w / 2, 0, hx + w / 2, 0); bg.addColorStop(0, BRASS.dark); bg.addColorStop(0.25, BRASS.mid); bg.addColorStop(0.45, BRASS.lite); bg.addColorStop(0.62, BRASS.hi); bg.addColorStop(1, BRASS.lo);
    ctx.fillStyle = bg; ctx.beginPath(); ctx.moveTo(hx - w / 2, rimY); ctx.bezierCurveTo(hx - w / 2 + 12, rimY + d, hx + w / 2 - 12, rimY + d, hx + w / 2, rimY); ctx.ellipse(hx, rimY, w / 2, 9, 0, 0, Math.PI, false); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = BRASS.dark; ctx.lineWidth = 1; ctx.stroke();
    ctx.strokeStyle = BRASS.lite; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(hx, rimY, w / 2 - 1, 8.5, 0, 0.1, Math.PI - 0.1); ctx.stroke();
    ctx.strokeStyle = 'rgba(78,53,16,0.5)'; ctx.lineWidth = 0.8; ctx.beginPath(); ctx.ellipse(hx, rimY + 12, w / 2 - 22, 5, 0, 0.3, Math.PI - 0.3); ctx.stroke();
    // label: a paper tag hung under the dish
    if (label) {
      ctx.font = 'bold 14px ' + FACE; var tw = Math.min(PAN_W - 10, ctx.measureText(label).width + 20), ty = rimY + d + 14;
      ctx.strokeStyle = 'rgba(210,190,150,0.8)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(hx, rimY + d - 4); ctx.lineTo(hx, ty); ctx.stroke();
      ctx.fillStyle = 'rgba(0,0,0,0.4)'; rr(ctx, hx - tw / 2 + 2, ty + 3, tw, 22, 3); ctx.fill();
      var pg = ctx.createLinearGradient(0, ty, 0, ty + 22); pg.addColorStop(0, PAPER[0]); pg.addColorStop(1, PAPER[1]); ctx.fillStyle = pg; rr(ctx, hx - tw / 2, ty, tw, 22, 3); ctx.fill();
      ctx.fillStyle = INK; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; var fs = 14; while (fs > 9 && ctx.measureText(label).width > tw - 12) { fs--; ctx.font = 'bold ' + fs + 'px ' + FACE; } ctx.fillText(label, hx, ty + 11.5);
    }
    ctx.restore();
  }

  //===========================================================================
  // Coins
  //===========================================================================

  /** The device of a mint as a closed path in a unit circle (radius 1), built into ctx at the current transform. */
  function devicePath(ctx, m) {
    var i, a, n;
    ctx.beginPath();
    if (m.device === 'star') {
      n = m.points; for (i = 0; i < n * 2; i++) { a = -Math.PI / 2 + i * Math.PI / n; var rad = i % 2 ? m.inner * 0.95 : 1; if (i) ctx.lineTo(Math.cos(a) * rad, Math.sin(a) * rad); else ctx.moveTo(Math.cos(a) * rad, Math.sin(a) * rad); } ctx.closePath();
    } else if (m.device === 'rosette') {
      n = m.petals; for (i = 0; i < n; i++) { a = -Math.PI / 2 + i * TAU / n; ctx.moveTo(Math.cos(a) * 0.18, Math.sin(a) * 0.18); ctx.ellipse(Math.cos(a) * 0.55, Math.sin(a) * 0.55, 0.42, 0.24, a, 0, TAU); }
    } else if (m.device === 'cross') {
      var t = 0.16, f = 0.42; // cross patee: arms flare towards the tips
      for (i = 0; i < 4; i++) { var ang = i * Math.PI / 2, c = Math.cos(ang), s = Math.sin(ang); var P = [[t, t], [f, 1], [-f, 1], [-t, t]]; P.forEach(function (p, j) { var x = p[0] * c - p[1] * s, y = p[0] * s + p[1] * c; if (j) ctx.lineTo(x, y); else ctx.moveTo(x, y); }); ctx.closePath(); }
      ctx.rect(-t, -t, 2 * t, 2 * t);
    } else if (m.device === 'sun') {
      n = m.rays; for (i = 0; i < n * 2; i++) { a = -Math.PI / 2 + i * Math.PI / n; var rr2 = i % 2 ? 0.52 : (i % 4 === 0 ? 1 : 0.82); if (i) ctx.lineTo(Math.cos(a) * rr2, Math.sin(a) * rr2); else ctx.moveTo(Math.cos(a) * rr2, Math.sin(a) * rr2); } ctx.closePath();
    } else if (m.device === 'crescent') {
      ctx.arc(-0.08, 0, 0.78, Math.PI * 0.3, Math.PI * 1.7, false); ctx.arc(0.26, 0, 0.62, Math.PI * 1.62, Math.PI * 0.38, true); ctx.closePath();
    } else { // tower: a crenellated keep with a gate
      ctx.moveTo(-0.5, 0.82); ctx.lineTo(-0.5, -0.42); for (i = 0; i < 5; i++) { var x0 = -0.5 + i * 0.25; ctx.lineTo(x0, -0.62); ctx.lineTo(x0 + 0.125, -0.62); ctx.lineTo(x0 + 0.125, -0.42); ctx.lineTo(x0 + 0.25, -0.42); }
      ctx.lineTo(0.5, 0.82); ctx.lineTo(0.17, 0.82); ctx.lineTo(0.17, 0.42); ctx.arc(0, 0.42, 0.17, 0, Math.PI, true); ctx.lineTo(-0.17, 0.82); ctx.closePath();
    }
  }
  /** The small secondary marks of a device (pellets, stars, a window) as dots: [x, y, r] in the unit circle. */
  function deviceDots(m) {
    var out = [], i, a;
    if (m.device === 'star' && m.pellets) for (i = 0; i < m.points; i++) { a = -Math.PI / 2 + (i + 0.5) * TAU / m.points; out.push([Math.cos(a) * 0.82, Math.sin(a) * 0.82, 0.07]); }
    else if (m.device === 'rosette') out.push([0, 0, 0.2]);
    else if (m.device === 'cross' && m.pellets) for (i = 0; i < 4; i++) { a = Math.PI / 4 + i * Math.PI / 2; out.push([Math.cos(a) * 0.62, Math.sin(a) * 0.62, 0.09]); }
    else if (m.device === 'sun') out.push([0, 0, 0.36]);
    else if (m.device === 'crescent') { out.push([0.55, -0.42, 0.08]); out.push([0.66, 0, 0.1]); out.push([0.55, 0.42, 0.08]); }
    else if (m.device === 'tower') { out.push([-0.25, -0.08, 0.07]); out.push([0.25, -0.08, 0.07]); }
    return out;
  }

  /**
   * One coin of mint `m`, face on, at (cx, cy), radius r: thickness, rim treatment, legend, device in relief, lustre.
   * opt.cut draws a banker's test cut showing the base metal inside (the counterfeit, found). opt.dim greys it.
   */
  function drawCoin(ctx, cx, cy, r, m, opt) {
    opt = opt || {};
    var M = METALS[m.metal] || METALS.gold, th = Math.max(1.5, r * 0.09);
    ctx.save();
    // shadow and edge thickness
    ctx.fillStyle = 'rgba(0,0,0,0.38)'; ctx.beginPath(); ctx.ellipse(cx + r * 0.1, cy + r * 0.16, r * 1.02, r * 0.98, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = M.dark; ctx.beginPath(); ctx.arc(cx, cy + th, r, 0, TAU); ctx.fill();
    // face
    var g = ctx.createRadialGradient(cx - r * 0.35, cy - r * 0.4, r * 0.05, cx, cy, r * 1.05); g.addColorStop(0, M.lite); g.addColorStop(0.45, M.face); g.addColorStop(1, M.rim);
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.fill();
    // raised rim
    ctx.lineWidth = Math.max(1.2, r * 0.1); ctx.strokeStyle = M.rim; ctx.beginPath(); ctx.arc(cx, cy, r * 0.94, 0, TAU); ctx.stroke();
    ctx.lineWidth = Math.max(0.6, r * 0.025); ctx.strokeStyle = M.lite; ctx.beginPath(); ctx.arc(cx, cy, r * 0.97, Math.PI * 1.05, Math.PI * 1.7); ctx.stroke();
    // rim treatment
    var i, a, k;
    if (m.rim === 'beaded') { k = Math.max(16, Math.round(r * 1.1)); for (i = 0; i < k; i++) { a = i * TAU / k; emboss(ctx, M, function () { ctx.beginPath(); ctx.arc(cx + Math.cos(a) * r * 0.84, cy + Math.sin(a) * r * 0.84, Math.max(0.7, r * 0.035), 0, TAU); }, r); } }
    else if (m.rim === 'milled') { k = Math.max(24, Math.round(r * 1.6)); ctx.strokeStyle = M.dark; ctx.lineWidth = Math.max(0.6, r * 0.018); for (i = 0; i < k; i++) { a = i * TAU / k; ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * r * 0.9, cy + Math.sin(a) * r * 0.9); ctx.lineTo(cx + Math.cos(a) * r * 0.99, cy + Math.sin(a) * r * 0.99); ctx.stroke(); } }
    else { k = Math.max(14, Math.round(r * 0.9)); ctx.strokeStyle = M.dark; ctx.lineWidth = Math.max(0.7, r * 0.03); for (i = 0; i < k; i++) { a = i * TAU / k; var b = a + TAU / k * 0.7; ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * r * 0.8, cy + Math.sin(a) * r * 0.8); ctx.lineTo(cx + Math.cos(b) * r * 0.88, cy + Math.sin(b) * r * 0.88); ctx.stroke(); } }
    // inner ring and legend
    var dr = m.ring ? 0.64 : 0.72;
    if (m.ring) { ctx.strokeStyle = M.dark; ctx.lineWidth = Math.max(0.6, r * 0.02); ctx.beginPath(); ctx.arc(cx, cy, r * 0.72, 0, TAU); ctx.stroke(); }
    if (r >= 34) legend(ctx, cx, cy, r * 0.78, legendText(m), Math.max(7, r * 0.1), M);
    else if (m.ring) { ctx.fillStyle = M.dark; k = m.legend; for (i = 0; i < k; i++) { a = -Math.PI / 2 + (i + 0.5) * TAU / k; ctx.fillRect(cx + Math.cos(a) * r * 0.77 - 0.5, cy + Math.sin(a) * r * 0.77 - 0.5, 1, 1); } }
    // device in relief
    ctx.save(); ctx.translate(cx, cy); ctx.scale(r * dr * 0.92, r * dr * 0.92);
    var dg = ctx.createLinearGradient(-1, -1, 1, 1); dg.addColorStop(0, M.lite); dg.addColorStop(0.5, M.face); dg.addColorStop(1, M.rim);
    ctx.translate(0.035, 0.05); devicePath(ctx, m); ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fill(); ctx.translate(-0.035, -0.05);
    devicePath(ctx, m); ctx.fillStyle = dg; ctx.fill(); ctx.lineWidth = 1.4 / (r * dr); ctx.strokeStyle = M.dark; ctx.stroke();
    var dots = deviceDots(m);
    for (i = 0; i < dots.length; i++) { var dd = dots[i]; ctx.beginPath(); ctx.arc(dd[0] + 0.03, dd[1] + 0.04, dd[2], 0, TAU); ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fill(); ctx.beginPath(); ctx.arc(dd[0], dd[1], dd[2], 0, TAU); ctx.fillStyle = dg; ctx.fill(); ctx.strokeStyle = M.dark; ctx.stroke(); }
    ctx.restore();
    // lustre
    var lg = ctx.createRadialGradient(cx - r * 0.4, cy - r * 0.45, 0, cx - r * 0.4, cy - r * 0.45, r * 0.8); lg.addColorStop(0, 'rgba(255,255,255,0.35)'); lg.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = lg; ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.fill();
    if (opt.cut) testCut(ctx, cx, cy, r, M, opt.cut, m.metal);
    if (opt.dim) { ctx.fillStyle = 'rgba(20,14,8,0.55)'; ctx.beginPath(); ctx.arc(cx, cy, r + 1, 0, TAU); ctx.fill(); }
    ctx.restore();
  }
  /**
   * What a counterfeit of this metal is made of under its skin, and the colour its cut shows. Heavy = a lead core.
   * Light = copper under gold, silver or electrum; tin under copper or bronze (a copper core under copper would be no
   * counterfeit at all - found by looking at the first verdict plate, 2026-09-27).
   * @returns {{name:string, colour:string}}
   */
  function coreOf(metal, dir) {
    if (dir > 0) return { name: 'lead', colour: '#66625d' };
    return metal === 'copper' || metal === 'bronze' ? { name: 'tin', colour: '#a8a89e' } : { name: 'copper', colour: '#7a4a2a' };
  }
  /** A banker's test cut: a V-shaped chisel cut from the rim toward the centre, exposing a dull base-metal core. */
  function testCut(ctx, cx, cy, r, M, dir, metal) {
    var a = -Math.PI * 0.28, tip = [cx + Math.cos(a) * r * 0.12, cy + Math.sin(a) * r * 0.12], w = 0.26;
    var p1 = [cx + Math.cos(a - w) * r * 1.02, cy + Math.sin(a - w) * r * 1.02], p2 = [cx + Math.cos(a + w) * r * 1.02, cy + Math.sin(a + w) * r * 1.02];
    var core = coreOf(metal, dir).colour;
    var cg = ctx.createLinearGradient(p1[0], p1[1], p2[0], p2[1]); cg.addColorStop(0, shade(core, -0.45)); cg.addColorStop(0.5, shade(core, 0.2)); cg.addColorStop(1, shade(core, -0.3));
    ctx.fillStyle = cg; ctx.beginPath(); ctx.moveTo(tip[0], tip[1]); ctx.lineTo(p1[0], p1[1]); ctx.lineTo(p2[0], p2[1]); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = M.lite; ctx.lineWidth = Math.max(1, r * 0.025); ctx.beginPath(); ctx.moveTo(p1[0], p1[1]); ctx.lineTo(tip[0], tip[1]); ctx.stroke();
    ctx.strokeStyle = M.dark; ctx.beginPath(); ctx.moveTo(tip[0], tip[1]); ctx.lineTo(p2[0], p2[1]); ctx.stroke();
    // the plating's thin skin shows as a bright line along both cut faces near the rim
    ctx.strokeStyle = M.face; ctx.lineWidth = Math.max(1, r * 0.035); ctx.beginPath(); ctx.moveTo(p1[0], p1[1]); ctx.lineTo(p1[0] + (tip[0] - p1[0]) * 0.12, p1[1] + (tip[1] - p1[1]) * 0.12); ctx.moveTo(p2[0], p2[1]); ctx.lineTo(p2[0] + (tip[0] - p2[0]) * 0.12, p2[1] + (tip[1] - p2[1]) * 0.12); ctx.stroke();
  }
  function emboss(ctx, M, pathFn, r) { var o = Math.max(0.5, r * 0.012); ctx.save(); ctx.translate(o, o); pathFn(); ctx.fillStyle = M.dark; ctx.fill(); ctx.restore(); pathFn(); ctx.fillStyle = M.lite; ctx.fill(); }
  function legendText(m) { return (m.name.replace(/^The /, '') + ' · ' + m.unit).toUpperCase() + ' · '; }
  /** Lettering round the coin, reading clockwise from the top, struck in relief. */
  function legend(ctx, cx, cy, R, text, size, M) {
    ctx.save(); ctx.font = 'bold ' + Math.round(size) + 'px ' + FACE; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    // ⛔ found by looking (2026-09-27): on a large coin one pass of the legend covered a quarter of the rim. Repeat it
    // while a whole copy still fits, as a real legend runs round the whole coin.
    var one = ctx.measureText(text).width + text.length * size * 0.12, reps = Math.max(1, Math.floor(TAU * R * 0.94 / one)), full = '';
    for (var q = 0; q < reps; q++) full += text; text = full;
    var total = 0, i, ws = []; for (i = 0; i < text.length; i++) { ws.push(ctx.measureText(text[i]).width + size * 0.12); total += ws[i]; }
    var span = Math.min(TAU * 0.96, total / R), a = -Math.PI / 2 - span / 2;
    for (i = 0; i < text.length; i++) {
      var ai = a + ws[i] / 2 / R; ctx.save(); ctx.translate(cx + Math.cos(ai) * R, cy + Math.sin(ai) * R); ctx.rotate(ai + Math.PI / 2);
      ctx.fillStyle = M.dark; ctx.fillText(text[i], 0.6, 0.7); ctx.fillStyle = M.lite; ctx.fillText(text[i], 0, 0); ctx.restore(); a += ws[i] / R;
    }
    ctx.restore();
  }
  /** A coin lying in a pan, seen at the pan's low angle: a flattened disc with its edge. */
  function drawCoinFlat(ctx, cx, cy, rx, m) {
    var M = METALS[m.metal] || METALS.gold, ry = rx * 0.36;
    ctx.fillStyle = M.dark; ctx.beginPath(); ctx.ellipse(cx, cy + 2, rx, ry, 0, 0, TAU); ctx.fill();
    var g = ctx.createLinearGradient(cx - rx, cy - ry, cx + rx, cy + ry); g.addColorStop(0, M.lite); g.addColorStop(0.5, M.face); g.addColorStop(1, M.rim);
    ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(cx, cy, rx, ry, 0, 0, TAU); ctx.fill();
    ctx.strokeStyle = M.rim; ctx.lineWidth = 1; ctx.beginPath(); ctx.ellipse(cx, cy, rx * 0.78, ry * 0.72, 0, 0, TAU); ctx.stroke();
  }
  /** Coins piled in a dish: rows of flattened discs, the front row lowest. `count` coins of mint m. */
  function pileCoins(ctx, cx, rimY, count, m) {
    var per = [0, 1, 2, 3, 4, 3, 3, 4, 4, 4][Math.min(9, count)] || 4, rows = [], left = count;
    while (left > 0) { var n = Math.min(left, Math.max(1, per - rows.length)); rows.push(n); left -= n; }
    for (var r = rows.length - 1; r >= 0; r--) for (var i = 0; i < rows[r]; i++) drawCoinFlat(ctx, cx + (i - (rows[r] - 1) / 2) * 27 + (r % 2 ? 6 : 0), rimY - 2 - r * 6.5, 15, m);
  }

  var METALS = {
    gold: { face: '#e8b84a', rim: '#b8832a', dark: '#6e4a12', lite: '#fff0b8' },
    silver: { face: '#cfd4d8', rim: '#9aa2a9', dark: '#4c545b', lite: '#ffffff' },
    copper: { face: '#cf7d4a', rim: '#9c5530', dark: '#4e2512', lite: '#ffd2ae' },
    electrum: { face: '#d9c77a', rim: '#a8964e', dark: '#584d20', lite: '#fff6c8' },
    bronze: { face: '#b8894e', rim: '#8a6232', dark: '#43290e', lite: '#f0d2a0' },
  };

  //===========================================================================
  // Weights and goods (the measure puzzle)
  //===========================================================================

  /** Height of the bell weight for a value (bigger weights stand taller). */
  function weightH(v) { return Math.round(20 + 9 * Math.log(1 + v) / Math.log(2)); }
  /** A brass bell weight standing on (cx, by), stamped with its value. */
  function drawWeight(ctx, cx, by, v, opt) {
    opt = opt || {};
    var h = weightH(v), w = h * 0.78, top = by - h;
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.ellipse(cx + 3, by + 1, w * 0.6, w * 0.14, 0, 0, TAU); ctx.fill();
    var g = brassGrad(ctx, cx - w / 2, 0, cx + w / 2, 0);
    ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(cx - w / 2, by); ctx.bezierCurveTo(cx - w / 2, by - h * 0.4, cx - w * 0.3, top + h * 0.3, cx - w * 0.22, top + h * 0.2); ctx.lineTo(cx + w * 0.22, top + h * 0.2); ctx.bezierCurveTo(cx + w * 0.3, top + h * 0.3, cx + w / 2, by - h * 0.4, cx + w / 2, by); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = BRASS.dark; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = shade(BRASS.lo, -0.1); ctx.beginPath(); ctx.ellipse(cx, by, w / 2, w * 0.1, 0, 0, Math.PI); ctx.fill();
    // collar and knob
    ctx.fillStyle = g; rr(ctx, cx - w * 0.26, top + h * 0.12, w * 0.52, h * 0.1, 2); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.arc(cx, top + h * 0.07, Math.max(3, w * 0.13), 0, TAU); ctx.fill(); ctx.stroke();
    // stamped value
    var fs = Math.max(9, Math.round(h * 0.34)); ctx.font = 'bold ' + fs + 'px ' + FACE; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = 'rgba(255,245,210,0.55)'; ctx.fillText(String(v), cx + 0.8, by - h * 0.36 + 0.9); ctx.fillStyle = BRASS.dark; ctx.fillText(String(v), cx, by - h * 0.36);
    if (opt.dim) { ctx.globalCompositeOperation = 'source-atop'; ctx.fillStyle = 'rgba(20,14,8,0.6)'; ctx.fillRect(cx - w, top - 4, w * 2, h + 8); }
    ctx.restore();
    return w;
  }
  var GOODS_LOOK = {
    saffron: ['#c8401e', '#e8742a', '#8a2410'], pepper: ['#2a2420', '#4a3e34', '#141010'], 'silver dust': ['#b8bec4', '#e8ecef', '#7a8288'], salt: ['#f2efe8', '#ffffff', '#c9c4b8'],
    tea: ['#4a5a2a', '#6e7a3a', '#2c3818'], cloves: ['#5a3420', '#7a4a2a', '#3a2010'], myrrh: ['#b8702a', '#e0a050', '#7a4414'], indigo: ['#2a3a8a', '#4a5ab0', '#18204a'],
  };
  /** A heap of goods in a dish, grain by grain, deterministic from the seed. */
  function drawGoods(ctx, cx, rimY, goods, seed) {
    var C = GOODS_LOOK[goods] || GOODS_LOOK.saffron, r = rng(seed ^ 0x600D), w = 52, h = 30;
    var g = ctx.createRadialGradient(cx - 10, rimY - h * 0.7, 2, cx, rimY - 6, w); g.addColorStop(0, C[1]); g.addColorStop(0.6, C[0]); g.addColorStop(1, C[2]);
    ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(cx - w, rimY + 2); ctx.bezierCurveTo(cx - w * 0.6, rimY - h * 0.9, cx + w * 0.6, rimY - h * 0.9, cx + w, rimY + 2); ctx.closePath(); ctx.fill();
    for (var i = 0; i < 260; i++) {
      var t = r() * 2 - 1, x = cx + t * w * 0.95, top = rimY + 2 - (1 - t * t) * h * 0.66, y = top + r() * (rimY + 2 - top);
      ctx.fillStyle = C[Math.floor(r() * 3) % 3]; if (goods === 'saffron' || goods === 'cloves') { ctx.save(); ctx.translate(x, y); ctx.rotate(r() * TAU); ctx.fillRect(-2.5, -0.6, 5, 1.2); ctx.restore(); } else ctx.fillRect(x, y, 1.6 + r() * 1.4, 1.4 + r());
    }
    ctx.fillStyle = 'rgba(255,255,255,0.18)'; ctx.beginPath(); ctx.ellipse(cx - 14, rimY - h * 0.5, 12, 4, -0.2, 0, TAU); ctx.fill();
  }

  //===========================================================================
  // The coin tray and the weight box
  //===========================================================================

  var TRAY = { x: 26, y: 428, w: 508, h: 180 };
  /** Slot centres for n coins in the tray: two rows, centred. */
  function traySlots(n) {
    var T = TRAY, top = Math.ceil(n / 2), bot = n - top, out = [], pitch = Math.min(70, (T.w - 40) / Math.max(1, top));
    // ⛔ found by looking (2026-09-27): rows at +56/+124 put the top row's burned numbers INSIDE the bottom row's
    // recesses (slot 6's number was hidden). Rows at +46/+118 with numbers at +35 keep every number clear.
    for (var i = 0; i < n; i++) { var row = i < top ? 0 : 1, k = row ? i - top : i, cnt = row ? bot : top; out.push({ x: T.x + T.w / 2 + (k - (cnt - 1) / 2) * pitch, y: T.y + (row ? 118 : 46) }); }
    return out;
  }
  /** The wooden counting tray with a round recess and a burned number per coin (static; coins are drawn on top). */
  function drawTray(ctx, n) {
    var T = TRAY; ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; rr(ctx, T.x + 4, T.y + 6, T.w, T.h, 10); ctx.fill();
    var g = ctx.createLinearGradient(0, T.y, 0, T.y + T.h); g.addColorStop(0, '#8a5a32'); g.addColorStop(1, '#5a361c'); ctx.fillStyle = g; rr(ctx, T.x, T.y, T.w, T.h, 10); ctx.fill();
    var r = rng(0x7A7); ctx.lineWidth = 1; for (var y = T.y + 3; y < T.y + T.h - 2; y += 2.5) { ctx.strokeStyle = r() < 0.5 ? 'rgba(255,220,170,0.06)' : 'rgba(40,20,5,0.12)'; ctx.beginPath(); ctx.moveTo(T.x + 4, y); ctx.bezierCurveTo(T.x + T.w * 0.3, y + Math.sin(y) * 2, T.x + T.w * 0.7, y - Math.cos(y) * 2, T.x + T.w - 4, y); ctx.stroke(); }
    ctx.strokeStyle = 'rgba(255,220,170,0.3)'; rr(ctx, T.x + 1.5, T.y + 1.5, T.w - 3, T.h - 3, 9); ctx.stroke();
    ctx.strokeStyle = 'rgba(30,15,5,0.6)'; rr(ctx, T.x + 8, T.y + 8, T.w - 16, T.h - 16, 7); ctx.stroke();
    var S = traySlots(n);
    for (var i = 0; i < n; i++) {
      var s = S[i], rg = ctx.createRadialGradient(s.x, s.y - 6, 4, s.x, s.y, 28); rg.addColorStop(0, '#3a2210'); rg.addColorStop(1, '#5e3a1e');
      ctx.fillStyle = rg; ctx.beginPath(); ctx.arc(s.x, s.y, 27, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(255,220,170,0.25)'; ctx.beginPath(); ctx.arc(s.x, s.y, 27, 0.2, Math.PI - 0.2); ctx.stroke();
      ctx.font = 'bold 13px ' + FACE; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = 'rgba(255,225,180,0.25)'; ctx.fillText(String(i + 1), s.x + 0.7, s.y + 35.7); ctx.fillStyle = '#2a1608'; ctx.fillText(String(i + 1), s.x, s.y + 35);
    }
    ctx.restore();
  }
  /** Slot centres (and base lines) for the weight box. */
  function boxSlots(weights) { var T = TRAY, n = weights.length, out = [], pitch = (T.w - 60) / n; for (var i = 0; i < n; i++) out.push({ x: T.x + 30 + pitch * (i + 0.5), y: T.y + 116 }); return out; }
  /** The fitted weight box: a lined wooden case with a stepped recess per weight and its value burned beside it. */
  function drawBox(ctx, weights, setName) {
    var T = TRAY; ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; rr(ctx, T.x + 4, T.y + 6, T.w, T.h, 8); ctx.fill();
    var g = ctx.createLinearGradient(0, T.y, 0, T.y + T.h); g.addColorStop(0, '#7a4a28'); g.addColorStop(1, '#4a2a14'); ctx.fillStyle = g; rr(ctx, T.x, T.y, T.w, T.h, 8); ctx.fill();
    var lg = ctx.createLinearGradient(0, T.y + 22, 0, T.y + T.h - 12); lg.addColorStop(0, '#5a1a22'); lg.addColorStop(1, '#3a0e14'); ctx.fillStyle = lg; rr(ctx, T.x + 14, T.y + 26, T.w - 28, T.h - 40, 5); ctx.fill();
    var r = rng(0xB0C5); for (var i = 0; i < 900; i++) { ctx.fillStyle = r() < 0.5 ? 'rgba(255,160,170,0.05)' : 'rgba(0,0,0,0.12)'; ctx.fillRect(T.x + 14 + r() * (T.w - 28), T.y + 26 + r() * (T.h - 40), 1, 1); }
    ctx.font = 'italic bold 14px ' + FACE; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = 'rgba(255,225,180,0.75)'; ctx.fillText(setName.replace(/^the /, 'The '), T.x + T.w / 2, T.y + 14);
    var S = boxSlots(weights);
    for (var k = 0; k < weights.length; k++) { var s = S[k], w = weightH(weights[k]) * 0.78; ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.beginPath(); ctx.ellipse(s.x, s.y + 2, w * 0.62, w * 0.16, 0, 0, TAU); ctx.fill(); ctx.font = 'bold 13px ' + FACE; ctx.fillStyle = 'rgba(255,215,190,0.55)'; ctx.fillText(String(weights[k]), s.x, s.y + 24); }
    ctx.restore();
  }

  //===========================================================================
  // Cards, ledger, plaques, status, cursor
  //===========================================================================

  function paper(ctx, x, y, w, h, seed) {
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; rr(ctx, x + 4, y + 6, w, h, 5); ctx.fill();
    var g = ctx.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, PAPER[0]); g.addColorStop(1, PAPER[1]); ctx.fillStyle = g; rr(ctx, x, y, w, h, 5); ctx.fill();
    var r = rng(seed); for (var i = 0; i < w * h / 70; i++) { ctx.fillStyle = r() < 0.5 ? 'rgba(160,120,70,0.07)' : 'rgba(255,255,255,0.2)'; ctx.fillRect(x + r() * w, y + r() * h, 1 + r() * 2, 1); }
    var eg = ctx.createRadialGradient(x + w / 2, y + h / 2, Math.min(w, h) * 0.3, x + w / 2, y + h / 2, Math.max(w, h) * 0.7); eg.addColorStop(0, 'rgba(0,0,0,0)'); eg.addColorStop(1, 'rgba(120,80,30,0.2)'); ctx.fillStyle = eg; rr(ctx, x, y, w, h, 5); ctx.fill();
  }
  function fitText(ctx, text, maxW, size, style) { ctx.font = (style || 'bold') + ' ' + size + 'px ' + FACE; while (size > 9 && ctx.measureText(text).width > maxW) { size--; ctx.font = (style || 'bold') + ' ' + size + 'px ' + FACE; } return size; }
  function wrap(ctx, text, maxW) { var words = String(text).split(' '), lines = [], cur = ''; for (var i = 0; i < words.length; i++) { var t = cur ? cur + ' ' + words[i] : words[i]; if (ctx.measureText(t).width > maxW && cur) { lines.push(cur); cur = words[i]; } else cur = t; } if (cur) lines.push(cur); return lines; }

  /** The mint card (counterfeit) or the order slip (measure): a specimen coin or the goods, a title and the task. */
  function drawCard(ctx, w, h, info) {
    ctx.clearRect(0, 0, w, h); paper(ctx, 0, 0, w - 8, h - 10, 0xCA4D);
    var cw = w - 8; ctx.strokeStyle = '#7a4a1a'; ctx.lineWidth = 1.2; rr(ctx, 6, 6, cw - 12, h - 22, 3); ctx.stroke();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#7a4a1a'; ctx.font = 'bold 11px ' + FACE; ctx.fillText(info.kicker, cw / 2, 20);
    if (info.mint) drawCoin(ctx, 52, 74, 36, info.mint, {});
    else if (info.goods) {
      // ⛔ found by looking: at full size the heap ran off the card's left edge. Drawn at 0.62 in a small brass dish.
      ctx.save(); ctx.translate(52, 92); ctx.fillStyle = brassGrad(ctx, -40, 0, 40, 0); ctx.beginPath(); ctx.ellipse(0, 4, 40, 9, 0, 0, TAU); ctx.fill(); ctx.strokeStyle = BRASS.dark; ctx.lineWidth = 1; ctx.stroke();
      ctx.scale(0.62, 0.62); drawGoods(ctx, 0, 4, info.goods, info.seed || 1); ctx.restore();
    }
    var tx = 96 + (cw - 96) / 2, tw = cw - 104;
    fitText(ctx, info.title, tw, 17); ctx.fillStyle = INK; ctx.fillText(info.title, tx, 56);
    ctx.font = 'italic 12px ' + FACE; ctx.fillStyle = '#5a4430'; var sub = wrap(ctx, info.sub, tw); for (var i = 0; i < Math.min(3, sub.length); i++) ctx.fillText(sub[i], tx, 78 + i * 15);
    ctx.font = '13px ' + FACE; ctx.fillStyle = INK; var t = wrap(ctx, info.task, cw - 28); for (var j = 0; j < Math.min(4, t.length); j++) ctx.fillText(t[j], cw / 2, 128 + j * 17);
  }

  /**
   * The ledger: the weighings allowed as brass tokens, then one line per weighing with a drawn beam showing how it
   * fell. entries: [{text, o}] with o = +1 left sank, 0 level, -1 right sank.
   */
  function drawLedger(ctx, w, h, info) {
    ctx.clearRect(0, 0, w, h); paper(ctx, 0, 0, w - 8, h - 10, 0x1ED6);
    var cw = w - 8, i;
    ctx.strokeStyle = 'rgba(140,40,40,0.5)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(34.5, 8); ctx.lineTo(34.5, h - 18); ctx.stroke();
    ctx.strokeStyle = 'rgba(90,110,160,0.22)'; for (var y = 58; y < h - 16; y += 26) { ctx.beginPath(); ctx.moveTo(8, y + 0.5); ctx.lineTo(cw - 8, y + 0.5); ctx.stroke(); }
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#7a4a1a'; ctx.font = 'bold 12px ' + FACE; ctx.fillText('THE LEDGER', cw / 2, 18);
    // tokens: filled = weighings left
    if (info.allowed > 0) { var tw = 16, x0 = cw / 2 - (info.allowed - 1) * tw / 2; for (i = 0; i < info.allowed; i++) { var full = i < info.left; ctx.fillStyle = full ? brassGrad(ctx, x0 + i * tw - 6, 0, x0 + i * tw + 6, 0) : 'rgba(90,60,30,0.15)'; ctx.beginPath(); ctx.arc(x0 + i * tw, 38, 6, 0, TAU); ctx.fill(); ctx.strokeStyle = full ? BRASS.dark : 'rgba(90,60,30,0.5)'; ctx.stroke(); } }
    else { ctx.font = 'italic 12px ' + FACE; ctx.fillStyle = '#5a4430'; ctx.fillText(info.headline || '', cw / 2, 38); }
    var E = info.entries, show = Math.min(E.length, Math.floor((h - 70) / 26)), start = E.length - show;
    for (i = 0; i < show; i++) {
      var e = E[start + i], ly = 58 + 13 + i * 26;
      ctx.font = 'bold 13px ' + FACE; ctx.fillStyle = '#7a2a1a'; ctx.textAlign = 'center'; ctx.fillText(roman(start + i + 1), 20, ly);
      beamGlyph(ctx, cw - 26, ly + 2, e.o);
      ctx.textAlign = 'left'; var fs = fitText(ctx, e.text, cw - 96, 13, ''); ctx.fillStyle = INK; ctx.fillText(e.text, 42, ly); void fs;
    }
    if (!E.length) { ctx.textAlign = 'center'; ctx.font = 'italic 13px ' + FACE; ctx.fillStyle = 'rgba(90,68,48,0.7)'; ctx.fillText(info.empty || 'No weighings yet.', cw / 2, 71); }
  }
  function roman(n) { return ['', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'][n] || String(n); }
  /** A tiny balance drawn in ink: the beam tilted to show how a weighing fell. */
  function beamGlyph(ctx, cx, cy, o) {
    var a = o > 0 ? -0.35 : (o < 0 ? 0.35 : 0), L = 15; ctx.save(); ctx.strokeStyle = INK; ctx.fillStyle = INK; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.moveTo(cx, cy - 2); ctx.lineTo(cx, cy + 9); ctx.moveTo(cx - 5, cy + 9); ctx.lineTo(cx + 5, cy + 9); ctx.stroke();
    var lx = cx - Math.cos(a) * L, lyy = cy - 2 + Math.sin(a) * L, rx = cx + Math.cos(a) * L, ry = cy - 2 - Math.sin(a) * L;
    ctx.beginPath(); ctx.moveTo(lx, lyy); ctx.lineTo(rx, ry); ctx.stroke();
    [[lx, lyy], [rx, ry]].forEach(function (p) { ctx.beginPath(); ctx.moveTo(p[0] - 5, p[1] + 5); ctx.lineTo(p[0] + 5, p[1] + 5); ctx.lineTo(p[0], p[1]); ctx.closePath(); ctx.stroke(); });
    ctx.restore();
  }

  /** A brass plaque button. state: 'on' (the cursor is on it), 'idle', 'off' (not available now). */
  function drawPlaque(ctx, x, y, w, h, text, state) {
    ctx.save(); ctx.clearRect(x - 4, y - 4, w + 12, h + 12);
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; rr(ctx, x + 3, y + 4, w, h, 6); ctx.fill();
    var g = ctx.createLinearGradient(0, y, 0, y + h);
    if (state === 'off') { g.addColorStop(0, '#6a5a44'); g.addColorStop(1, '#3a2e20'); } else if (state === 'on') { g.addColorStop(0, '#fff0b0'); g.addColorStop(0.5, '#e8b850'); g.addColorStop(1, '#9a6a1e'); } else { g.addColorStop(0, '#f2d890'); g.addColorStop(0.5, '#c99a42'); g.addColorStop(1, '#8a6120'); }
    ctx.fillStyle = g; rr(ctx, x, y, w, h, 6); ctx.fill();
    ctx.strokeStyle = state === 'off' ? 'rgba(30,20,10,0.6)' : 'rgba(60,40,10,0.75)'; ctx.lineWidth = 1; rr(ctx, x + 3, y + 3, w - 6, h - 6, 4); ctx.stroke();
    [[x + 8, y + h / 2], [x + w - 8, y + h / 2]].forEach(function (p) { ctx.fillStyle = state === 'off' ? '#4a3e30' : BRASS.lo; ctx.beginPath(); ctx.arc(p[0], p[1], 2.4, 0, TAU); ctx.fill(); });
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; fitText(ctx, text, w - 34, 15);
    ctx.fillStyle = state === 'off' ? 'rgba(200,180,150,0.45)' : 'rgba(255,245,210,0.6)'; ctx.fillText(text, x + w / 2 + 0.8, y + h / 2 + 1.8); ctx.fillStyle = state === 'off' ? 'rgba(30,20,10,0.8)' : '#3a2408'; ctx.fillText(text, x + w / 2, y + h / 2 + 1);
    ctx.restore();
  }

  function drawStatus(ctx, W, H, text) {
    ctx.clearRect(0, 0, W, H); var size = fitText(ctx, text, W - 10, 17, 'italic'); void size;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = 'rgba(0,0,0,0.65)'; ctx.fillText(text, W / 2 + 1, H / 2 + 1); ctx.fillStyle = '#f1dfb4'; ctx.fillText(text, W / 2, H / 2);
  }

  /** The cursor over a tray slot: a gilt ring with four studs, drawn about the centre of a 76 x 76 bitmap. */
  function drawCursor(ctx) {
    ctx.clearRect(0, 0, 76, 76);
    ctx.strokeStyle = 'rgba(0,0,0,0.5)'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(39, 40, 32, 0, TAU); ctx.stroke();
    ctx.strokeStyle = '#f0c050'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(38, 38, 32, 0, TAU); ctx.stroke();
    ctx.fillStyle = '#fff2c4'; for (var i = 0; i < 4; i++) { var a = i * Math.PI / 2 + Math.PI / 4; ctx.beginPath(); ctx.arc(38 + Math.cos(a) * 32, 38 + Math.sin(a) * 32, 3, 0, TAU); ctx.fill(); }
  }

  /** The finished plate: the verdict coin (cut) or the sealed packet, large, with a plaque. */
  function drawVerdict(ctx, W, H, info) {
    // ⛔ found by looking: at 0.74 the tray's L/R marks and the pan tags showed through behind the plaque as clutter
    ctx.clearRect(0, 0, W, H); ctx.fillStyle = 'rgba(10,6,3,0.86)'; ctx.fillRect(0, 0, W, H);
    var cx = 270, cy = 262;
    var hg = ctx.createRadialGradient(cx, cy, 20, cx, cy, 220); hg.addColorStop(0, 'rgba(255,210,130,0.22)'); hg.addColorStop(1, 'rgba(255,210,130,0)'); ctx.fillStyle = hg; ctx.fillRect(0, 0, W, H);
    if (info.mint) {
      // ⛔ found by looking: genuine coins fanned BEHIND the verdict coin were half hidden and read as clutter. They now
      // stand in a row below it, clear of it, the true ones of the hoard beside the false one.
      drawCoin(ctx, cx, cy - 34, 112, info.mint, { cut: info.dir || 1 });
      var k = Math.min(7, Math.max(2, (info.genuine || 5)));
      for (var i = 0; i < k; i++) drawCoin(ctx, cx + (i - (k - 1) / 2) * 62, cy + 146, 25, info.mint, {});
    } else if (info.goods) drawPacket(ctx, cx, cy, info);
    plaque(ctx, cx, 520, 440, info.title, info.sub, info.won);
  }
  function plaque(ctx, cx, cy, w, title, sub, good) {
    var h = sub ? 56 : 36, x = cx - w / 2, y = cy - h / 2;
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; rr(ctx, x + 3, y + 4, w, h, 6); ctx.fill();
    var g = ctx.createLinearGradient(0, y, 0, y + h); if (good) { g.addColorStop(0, '#f6dc94'); g.addColorStop(0.5, '#c99a42'); g.addColorStop(1, '#8a6120'); } else { g.addColorStop(0, '#d8cdbd'); g.addColorStop(0.5, '#9a8e7e'); g.addColorStop(1, '#5e5448'); }
    ctx.fillStyle = g; rr(ctx, x, y, w, h, 6); ctx.fill(); ctx.strokeStyle = 'rgba(60,40,10,0.7)'; ctx.lineWidth = 1; rr(ctx, x + 3, y + 3, w - 6, h - 6, 4); ctx.stroke();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; fitText(ctx, title, w - 24, 19);
    ctx.fillStyle = 'rgba(255,245,210,0.6)'; ctx.fillText(title, cx, (sub ? cy - 10 : cy) + 1); ctx.fillStyle = '#3a2408'; ctx.fillText(title, cx, sub ? cy - 10 : cy);
    if (sub) { fitText(ctx, sub, w - 24, 13, 'italic'); ctx.fillStyle = '#4a3010'; ctx.fillText(sub, cx, cy + 14); }
  }
  /** A paper packet of the weighed goods, folded and sealed with wax, with its label. */
  function drawPacket(ctx, cx, cy, info) {
    var w = 190, h = 150, x = cx - w / 2, y = cy - h / 2 - 20;
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.beginPath(); ctx.ellipse(cx + 8, y + h + 12, w * 0.6, 14, 0, 0, TAU); ctx.fill();
    var g = ctx.createLinearGradient(x, y, x + w, y + h); g.addColorStop(0, '#efe0bc'); g.addColorStop(1, '#c9b48a'); ctx.fillStyle = g;
    ctx.beginPath(); ctx.moveTo(x, y + 20); ctx.lineTo(x + w, y + 20); ctx.lineTo(x + w - 10, y + h); ctx.lineTo(x + 10, y + h); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#d9c69a'; ctx.beginPath(); ctx.moveTo(x - 4, y + 20); ctx.lineTo(cx, y - 18); ctx.lineTo(x + w + 4, y + 20); ctx.lineTo(cx, y + 46); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = 'rgba(90,60,20,0.5)'; ctx.lineWidth = 1; ctx.stroke();
    ctx.strokeStyle = '#8a2a20'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(cx, y - 14); ctx.lineTo(cx, y + h - 2); ctx.moveTo(x + 8, y + 70); ctx.lineTo(x + w - 8, y + 70); ctx.stroke();
    var sg = ctx.createRadialGradient(cx - 6, y + 40, 2, cx, y + 46, 24); sg.addColorStop(0, '#e05848'); sg.addColorStop(1, '#7a1a14'); ctx.fillStyle = sg; ctx.beginPath();
    for (var i = 0; i < 14; i++) { var a = i / 14 * TAU, rad = 22 + (i % 2 ? 3 : 0); if (i) ctx.lineTo(cx + Math.cos(a) * rad, y + 46 + Math.sin(a) * rad); else ctx.moveTo(cx + Math.cos(a) * rad, y + 46 + Math.sin(a) * rad); } ctx.closePath(); ctx.fill();
    ctx.strokeStyle = 'rgba(255,200,180,0.5)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(cx, y + 46, 13, 0, TAU); ctx.stroke();
    ctx.font = 'bold 16px ' + FACE; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = 'rgba(255,220,200,0.8)'; ctx.fillText(String(info.amount), cx, y + 47);
    paper(ctx, x + 26, y + 88, w - 52, 44, 0x1ABE); ctx.fillStyle = INK; fitText(ctx, info.label, w - 64, 15); ctx.fillText(info.label, cx, y + 110);
    // ⛔ found by looking: a loose heap beside the packet read as a stray blob. The weights that did the weighing stand
    // under it instead, far pan on the right and goods pan on the left, as the answer written out in brass.
    if (info.weights && info.place) {
      var gl = [], fr = [], j; for (j = 0; j < info.weights.length; j++) { if (info.place[j] < 0) gl.push(info.weights[j]); else if (info.place[j] > 0) fr.push(info.weights[j]); }
      // each group sits beside the packet's foot (right-aligned on the left, left-aligned on the right), clear of the
      // pan tags (⛔ found by looking: a group at cx - 200 sat on the "goods + 9" tag)
      var width = function (list) { var s = 0; for (var q = 0; q < list.length; q++) s += weightH(list[q]) * 0.78 + 8; return s; };
      var row = function (list, x0, cap) { var wx = x0; ctx.font = 'italic 12px ' + FACE; ctx.fillStyle = '#e8d4a8'; ctx.textAlign = 'center'; ctx.fillText(cap, x0 + width(list) / 2, y + h + 86); for (var q = 0; q < list.length; q++) { var ww = weightH(list[q]) * 0.78; drawWeight(ctx, wx + ww / 2, y + h + 66, list[q]); wx += ww + 8; } };
      if (gl.length) row(gl, cx - 24 - width(gl), 'with the goods'); row(fr, cx + 24, 'on the far pan');
    }
  }

  return {
    VERSION: '1.0.0', FACE: FACE, INK: INK, BRASS: BRASS, BAL: BAL, METALS: METALS, GOODS_LOOK: GOODS_LOOK, TRAY: TRAY,
    BEAM_W: BEAM_W, BEAM_H: BEAM_H, BEAM_OX: BEAM_OX, BEAM_OY: BEAM_OY, PAN_W: PAN_W, PAN_H: PAN_H, PAN_HX: PAN_HX,
    shade: shade, rng: rng, coreOf: coreOf, drawTable: drawTable, drawStand: drawStand, drawBeam: drawBeam, drawFulcrum: drawFulcrum, drawPan: drawPan,
    devicePath: devicePath, deviceDots: deviceDots, drawCoin: drawCoin, drawCoinFlat: drawCoinFlat, pileCoins: pileCoins, legendText: legendText,
    weightH: weightH, drawWeight: drawWeight, drawGoods: drawGoods, traySlots: traySlots, drawTray: drawTray, boxSlots: boxSlots, drawBox: drawBox,
    drawCard: drawCard, drawLedger: drawLedger, beamGlyph: beamGlyph, roman: roman, drawPlaque: drawPlaque, drawStatus: drawStatus, drawCursor: drawCursor,
    drawVerdict: drawVerdict, drawPacket: drawPacket,
  };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = ScalesDraw;
