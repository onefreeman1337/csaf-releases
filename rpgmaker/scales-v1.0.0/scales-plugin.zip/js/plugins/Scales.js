//=============================================================================
// Scales.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Scales - weighing puzzles on a drawn brass balance: find
 * the counterfeit coin in a set number of weighings, or weigh out an order.
 * Place BELOW ScalesCore and ScalesDraw.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * Scales
 * ============================================================================
 *
 * Two weighing puzzles for your game, played on a brass balance at a
 * money-changer's counter.
 *
 * THE COUNTERFEIT. A hoard of identical coins hides one false coin, lighter
 * or heavier than the rest. The player puts coins on the two pans, weighs,
 * and reads the beam, then names the false coin (and whether it is heavy or
 * light, if they were not told). The number of weighings allowed is the
 * FEWEST that always suffice, worked out by an exact search before the puzzle
 * is shown. The false coin is not fixed in advance: after every weighing it
 * is wherever the weighings so far leave it best hidden. So a lucky guess
 * cannot win, and a correct method always does.
 *
 * THE MEASURE. Weigh out an exact order of goods with a box of weights. A
 * weight may go in either pan: on the far pan it counts for the goods, on the
 * goods pan it counts against them. Every order is checked to be possible
 * with the box before it is offered, and harder orders need weights in both
 * pans.
 *
 * Every mint (metal, device, rim, legend) and every hoard and order is
 * GENERATED from a seed.
 *
 * ----------------------------------------------------------------------------
 * INSTALLING
 * ----------------------------------------------------------------------------
 * Plugin Manager order, top to bottom:
 *
 *     ScalesCore.js     (the generator, the solver and the counterfeiter)
 *     ScalesDraw.js     (the drawing)
 *     Scales.js         (this file: parameters, the command, the scene)
 *
 * ----------------------------------------------------------------------------
 * USING IT
 * ----------------------------------------------------------------------------
 * Add the plugin command "Open Scales" to an event and choose the puzzle,
 * the difficulty, and optionally the number of coins, the metal and the
 * device, plus a switch and a variable to set with the result. The event
 * waits while the player works.
 *
 * The variable is set to 1 when the puzzle is solved, 2 when the player named
 * the wrong coin, and 0 when they left without an answer. The switch turns ON
 * only when the puzzle is solved.
 *
 * Leave the seed blank and the puzzle is keyed to its map and event, so it
 * is the same puzzle every visit. A solved puzzle reopens solved. Leaving an
 * unsolved counterfeit puzzle starts it afresh next time.
 *
 * ----------------------------------------------------------------------------
 * CONTROLS
 * ----------------------------------------------------------------------------
 * Arrow keys move between the coins (or weights) and the brass plaques. OK
 * moves the coin under the cursor: tray, left pan, right pan, tray. For a
 * weight: box, far pan, goods pan, box. Shift weighs. Escape leaves (or backs
 * out of naming a coin).
 * Mouse and touch: click a coin, a weight or a plaque; right-click leaves.
 *
 * ----------------------------------------------------------------------------
 * COMPATIBILITY
 * ----------------------------------------------------------------------------
 * Scales adds its own scene and replaces nothing. It extends one engine
 * method (Game_System.initialize) to create its save record, calling the
 * original first.
 *
 * ============================================================================
 * TERMS OF USE
 * ============================================================================
 * Commercial and non-commercial use permitted in RPG Maker projects, credit
 * appreciated but not required. Do not redistribute the source as an asset
 * pack. Every line of this plugin was written with AI assistance.
 *
 * ============================================================================
 *
 * @param placeSe
 * @text Sound: a coin or weight moved
 * @type file
 * @dir audio/se
 * @default Coin
 *
 * @param weighSe
 * @text Sound: the beam released
 * @type file
 * @dir audio/se
 * @default Chain
 *
 * @param winSe
 * @text Sound: solved
 * @type file
 * @dir audio/se
 * @default Chime2
 *
 * @param loseSe
 * @text Sound: the wrong coin named
 * @type file
 * @dir audio/se
 * @default Buzzer2
 *
 * @command open
 * @text Open Scales
 * @desc Open a weighing puzzle. The event waits until the player finishes or leaves.
 *
 * @arg puzzle
 * @text Puzzle
 * @type select
 * @option counterfeit
 * @option measure
 * @default counterfeit
 *
 * @arg difficulty
 * @text Difficulty
 * @type select
 * @option auto
 * @option easy
 * @option normal
 * @option hard
 * @default normal
 *
 * @arg coins
 * @text Coins in the hoard
 * @type number
 * @min 0
 * @max 13
 * @desc Counterfeit only. 0 = chosen by the difficulty. 3 to 13 = this many coins.
 * @default 0
 *
 * @arg metal
 * @text Metal
 * @type select
 * @option auto
 * @option gold
 * @option silver
 * @option copper
 * @option electrum
 * @option bronze
 * @default auto
 *
 * @arg device
 * @text Device on the coins
 * @type select
 * @option auto
 * @option star
 * @option rosette
 * @option cross
 * @option sun
 * @option crescent
 * @option tower
 * @default auto
 *
 * @arg switchId
 * @text Switch: on when solved
 * @type switch
 * @default 0
 *
 * @arg variableId
 * @text Variable: 1 solved, 2 wrong coin, 0 left
 * @type variable
 * @default 0
 *
 * @arg title
 * @text Title
 * @desc Shown on the card. Blank = named after the mint or the order.
 * @default
 *
 * @arg seed
 * @text Seed (optional)
 * @desc Blank = keyed to this map and event.
 * @default
 */

var Scales = Scales || {};

(function (M) {
  'use strict';
  var NAME = 'Scales', SCHEMA = 1;
  var raw = (typeof PluginManager !== 'undefined') ? PluginManager.parameters(NAME) : {};
  function num(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; var n = Number(v); return isFinite(n) ? n : d; }
  function str(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; return String(v).trim(); }
  M.params = { placeSe: str(raw.placeSe, 'Coin'), weighSe: str(raw.weighSe, 'Chain'), winSe: str(raw.winSe, 'Chime2'), loseSe: str(raw.loseSe, 'Buzzer2') };

  var _deps = null;
  function deps() {
    if (_deps) return _deps;
    var core = (typeof ScalesCore !== 'undefined') ? ScalesCore : null, draw = (typeof ScalesDraw !== 'undefined') ? ScalesDraw : null;
    if (!core || !draw) { if (!deps._w) { deps._w = true; console.error('Scales: ScalesCore.js and ScalesDraw.js must both be installed and listed ABOVE Scales.js.'); } return null; }
    _deps = { core: core, draw: draw }; return _deps;
  }
  M.deps = deps;

  function fresh() { return { v: SCHEMA, puzzles: {} }; }
  function store() {
    if (typeof $gameSystem === 'undefined' || !$gameSystem) return fresh();
    var s = $gameSystem._csafScales; if (!s || s.v == null) { s = fresh(); $gameSystem._csafScales = s; }
    if (!s.puzzles) s.puzzles = {}; return s;
  }
  M.store = store;
  M.keyFor = function (mapId, eventId) { return 'm' + Number(mapId) + 'e' + Number(eventId); };
  /** @returns {{done:boolean, won:boolean, tries:number}} a puzzle's record */
  M.record = function (key) { var r = store().puzzles[String(key)]; if (!r) { r = { done: false, won: false, tries: 0 }; store().puzzles[String(key)] = r; } return r; };
  /** How many puzzles the player has solved. */
  M.solvedCount = function () { var c = store().puzzles, k = 0; for (var id in c) if (c[id] && c[id].won) k++; return k; };

  var _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () { _Game_System_initialize.call(this); this._csafScales = fresh(); };

  /** Build a request (and its puzzle) from command arguments. Returns null if the sibling plugins are missing. */
  M.request = function (args, key, mapId, eventId) {
    var d = deps(); if (!d) return null; args = args || {};
    var seedText = str(args.seed, '');
    var seed = seedText === '' ? d.core.hashString(key) : (/^\d+$/.test(seedText) ? (Number(seedText) >>> 0) : d.core.hashString(seedText));
    var kind = str(args.puzzle, 'counterfeit') === 'measure' ? 'measure' : 'counterfeit', diff = str(args.difficulty, 'normal');
    var opt = { seed: seed, difficulty: diff === 'auto' ? null : diff, coins: Math.floor(num(args.coins, 0)) };
    var p = kind === 'measure' ? d.core.measure(opt) : d.core.counterfeit(opt);
    // metal and device restyle the hoard's mint without changing the puzzle
    var metal = str(args.metal, 'auto'), device = str(args.device, 'auto');
    if (metal !== 'auto' || device !== 'auto') p.mint = d.core.mint(p.mint.seed, { metal: metal, device: device });
    var title = str(args.title, kind === 'measure' ? p.target + ' drams of ' + p.goods : p.mint.name);
    return { key: key, puzzle: p, switchId: Math.max(0, Math.floor(num(args.switchId, 0))), variableId: Math.max(0, Math.floor(num(args.variableId, 0))), title: title, mapId: mapId, eventId: eventId };
  };

  M.open = function (req) { if (!req) return false; SceneManager.push(Scene_Scales); SceneManager.prepareNextScene(req); return true; };

  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
    PluginManager.registerCommand(NAME, 'open', function (args) {
      var mapId = this._mapId || ($gameMap ? $gameMap.mapId() : 0), eventId = this.eventId ? this.eventId() : 0;
      var seedText = str(args.seed, ''), key = seedText === '' ? M.keyFor(mapId, eventId) : 's' + seedText;
      M.open(M.request(args, key, mapId, eventId));
    });
  }
  var WORDS = ['no', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen'];
  M.word = function (n) { return WORDS[n] || String(n); };
  M.VERSION = '1.0.0'; M.SCHEMA = SCHEMA;
}(Scales));

//=============================================================================
// Scene_Scales
//=============================================================================

function Scene_Scales() { this.initialize.apply(this, arguments); }
Scene_Scales.prototype = Object.create(Scene_Base.prototype);
Scene_Scales.prototype.constructor = Scene_Scales;
Scene_Scales.CARD = { x: 560, y: 20, w: 240, h: 196 };
Scene_Scales.LEDGER = { x: 560, y: 222, w: 240, h: 248 };
Scene_Scales.STATUS = { x: 552, y: 470, w: 256, h: 38 };
Scene_Scales.PLAQUES = { x: 564, y: 512, w: 228, h: 30, gap: 34 };

Scene_Scales.prototype.prepare = function (req) { this._req = req; };

Scene_Scales.prototype.create = function () {
  Scene_Base.prototype.create.call(this);
  var d = Scales.deps(); this._d = d; var p = this._req.puzzle; this._p = p;
  this._measure = p.kind === 'measure';
  this._rec = Scales.record(this._req.key);
  this._game = this._measure ? d.core.newMeasure(p) : d.core.newGame(p);
  // where each coin (or weight) is: 0 tray/box, 1 left pan, 2 right pan
  this._pos = []; var n = this._measure ? p.weights.length : p.n, i;
  for (i = 0; i < n; i++) this._pos.push(0);
  this._items = n; this._cursor = 0; this._mode = 'play'; this._theta = 0; this._omega = 0; this._target = 0; this._frame = 0; this._verdictT = 0;
  this._statusText = ''; this._plaqueKey = ''; this._panKeyL = null; this._panKeyR = null;
  this.createBoard(); this.createUi();
  this.refreshPans(); this.refreshTray(); this.refreshLedger(); this.refreshPlaques(); this.placeCursor(); this.applyBeam();
  this.setStatus(this._measure ? 'OK moves a weight. Shift weighs. Esc leaves.' : 'OK moves a coin. Shift weighs. Esc leaves.');
  if (this._rec.won) this.showVerdict(true);
};
Scene_Scales.prototype.start = function () { Scene_Base.prototype.start.call(this); this.startFadeIn(this.fadeSpeed(), false); };

Scene_Scales.prototype.createBoard = function () {
  var d = this._d, D = d.draw, W = Graphics.width, H = Graphics.height, B = D.BAL, p = this._p;
  var table = new Bitmap(W, H), ctx = table.context;
  D.drawTable(ctx, W, H); D.drawStand(ctx);
  if (this._measure) D.drawBox(ctx, p.weights, p.setName); else D.drawTray(ctx, p.n);
  table._baseTexture.update(); this.addChild(new Sprite(table));
  this._panL = new Sprite(new Bitmap(D.PAN_W, D.PAN_H)); this._panR = new Sprite(new Bitmap(D.PAN_W, D.PAN_H));
  this.addChild(this._panL); this.addChild(this._panR);
  var beam = new Bitmap(D.BEAM_W, D.BEAM_H); D.drawBeam(beam.context); beam._baseTexture.update();
  this._beam = new Sprite(beam); this._beam.anchor.x = D.BEAM_OX / D.BEAM_W; this._beam.anchor.y = D.BEAM_OY / D.BEAM_H; this._beam.x = B.fx; this._beam.y = B.fy; this.addChild(this._beam);
  var ful = new Bitmap(80, 60); ful.context.translate(40 - B.fx, 34 - B.fy); D.drawFulcrum(ful.context); ful._baseTexture.update();
  var fs = new Sprite(ful); fs.x = B.fx - 40; fs.y = B.fy - 34; this.addChild(fs);
  // the tray layer is only as big as the tray (it is redrawn on every move; a full-screen bitmap would upload 4x the texels)
  var T = D.TRAY; this._tray = new Sprite(new Bitmap(T.w + 24, T.h + 24)); this._tray.x = T.x - 12; this._tray.y = T.y - 12; this.addChild(this._tray);
  this._ring = new Sprite(new Bitmap(76, 76)); D.drawCursor(this._ring.bitmap.context); this._ring.bitmap._baseTexture.update(); this._ring.anchor.x = 0.5; this._ring.anchor.y = 0.5; this.addChild(this._ring);
};

Scene_Scales.prototype.createUi = function () {
  var C = Scene_Scales.CARD, L = Scene_Scales.LEDGER, S = Scene_Scales.STATUS, p = this._p, D = this._d.draw;
  this._card = new Sprite(new Bitmap(C.w, C.h)); this._card.x = C.x; this._card.y = C.y; this.addChild(this._card);
  var info = this._measure
    ? { kicker: 'THE ORDER', goods: p.goods, seed: p.seed, title: this._req.title, sub: p.setName + ': ' + p.weights.join(', '), task: 'Weigh it out exactly. A weight may go in either pan.' }
    : { kicker: 'THE COUNTERFEIT', mint: p.mint, title: this._req.title, sub: Scales.word(p.n) + ' ' + p.mint.unit + ', all alike', task: this.taskText() };
  D.drawCard(this._card.bitmap.context, C.w, C.h, info); this._card.bitmap._baseTexture.update();
  this._ledger = new Sprite(new Bitmap(L.w, L.h)); this._ledger.x = L.x; this._ledger.y = L.y; this.addChild(this._ledger);
  this._status = new Sprite(new Bitmap(S.w, S.h)); this._status.x = S.x; this._status.y = S.y; this.addChild(this._status);
  var P = Scene_Scales.PLAQUES; this._plaques = new Sprite(new Bitmap(P.w + 20, P.gap * 3 + 16)); this._plaques.x = P.x - 8; this._plaques.y = P.y - 8; this.addChild(this._plaques);
  this._verdict = new Sprite(new Bitmap(Graphics.width, Graphics.height)); this._verdict.visible = false; this.addChild(this._verdict);
};

Scene_Scales.prototype.taskText = function () {
  var p = this._p, k = Scales.word(p.weighings) + (p.weighings === 1 ? ' weighing' : ' weighings');
  if (p.known) return 'One is false and ' + (p.dir > 0 ? 'HEAVIER' : 'LIGHTER') + ' than the rest. Find it in ' + k + '.';
  return 'One is false, heavier or lighter. Find it, and say which, in ' + k + '.';
};

Scene_Scales.prototype.playSe = function (n) { if (n && typeof AudioManager !== 'undefined') AudioManager.playSe({ name: n, volume: 80, pitch: 100, pan: 0 }); };

//---------------------------------------------------------------------------- what is where

/** Coin (or weight) indices on a side: 1 left, 2 right. */
Scene_Scales.prototype.onSide = function (side) { var out = []; for (var i = 0; i < this._pos.length; i++) if (this._pos[i] === side) out.push(i); return out; };
/** The item positions the cursor can visit: tray/box slots, then the plaques. */
Scene_Scales.prototype.itemXY = function (i) {
  var D = this._d.draw, P = Scene_Scales.PLAQUES;
  if (i < this._items) { var s = this._measure ? D.boxSlots(this._p.weights)[i] : D.traySlots(this._p.n)[i]; return this._measure ? { x: s.x, y: s.y - 24 } : s; }
  var k = i - this._items; return { x: P.x + P.w / 2, y: P.y + k * P.gap + P.h / 2 };
};
Scene_Scales.prototype.plaqueCount = function () { return 3; };
Scene_Scales.prototype.plaqueLabels = function () {
  if (this._mode === 'dir') return ['Heavier', 'Lighter', 'Back'];
  if (this._measure) return ['Weigh', 'Clear the pans', 'Leave the counter'];
  return ['Weigh', 'Clear the pans', this._mode === 'accuse' ? 'Back' : 'Name the false coin'];
};
Scene_Scales.prototype.canWeigh = function () {
  if (this._mode !== 'play') return false;
  if (this._measure) return !this._game.over;
  var L = this.onSide(1).length; return this._game.left > 0 && L > 0 && L === this.onSide(2).length;
};
Scene_Scales.prototype.plaqueState = function (k) {
  if (this._mode === 'dir') return this._cursor === this._items + k ? 'on' : 'idle';
  var on = this._cursor === this._items + k;
  if (k === 0 && !this.canWeigh()) return 'off';
  if (k === 1 && (this._mode !== 'play' || (!this.onSide(1).length && !this.onSide(2).length))) return 'off';
  if (k === 2 && !this._measure && this._mode !== 'play' && this._mode !== 'accuse') return 'off';
  return on ? 'on' : 'idle';
};

//---------------------------------------------------------------------------- redraws (only on change)

Scene_Scales.prototype.refreshPans = function () {
  var D = this._d.draw, p = this._p, self = this;
  var L = this.onSide(1), R = this.onSide(2);
  // only the pan whose contents changed is repainted (a move touches one pan, or two when a coin crosses over)
  var kl = L.join(','), kr = R.join(','), doL = kl !== this._panKeyL, doR = kr !== this._panKeyR;
  this._panKeyL = kl; this._panKeyR = kr; if (!doL && !doR) return;
  var label = function (list) { var t = []; for (var i = 0; i < list.length; i++) t.push(self._measure ? p.weights[list[i]] : list[i] + 1); return t.join(self._measure ? ' + ' : ' · '); };
  // weights standing in a pan, scaled so the row fits the span [x0, x0 + span] (a dish is 142 px across)
  var stand = function (ctx, rimY, list, x0, span) {
    var ws = 0, i; for (i = 0; i < list.length; i++) ws += D.weightH(p.weights[list[i]]) * 0.78 + 4;
    var sc = Math.min(0.8, span / Math.max(1, ws)), x = x0 + (span - ws * sc) / 2;
    for (i = 0; i < list.length; i++) { var w = D.weightH(p.weights[list[i]]) * 0.78 * sc; ctx.save(); ctx.translate(x + w / 2, rimY + 3); ctx.scale(sc, sc); D.drawWeight(ctx, 0, 0, p.weights[list[i]]); ctx.restore(); x += w + 4 * sc; }
  };
  if (this._measure) {
    // ⛔ found by looking: the heap at cx - 28, full size, overhung the dish's left rim. Beside weights it is drawn at 0.78.
    if (doL) D.drawPan(this._panL.bitmap.context, function (ctx, cx, rimY) { if (L.length) { ctx.save(); ctx.translate(cx - 26, rimY); ctx.scale(0.78, 0.78); D.drawGoods(ctx, 0, 0, p.goods, p.seed); ctx.restore(); stand(ctx, rimY, L, cx + 2, 60); } else D.drawGoods(ctx, cx, rimY, p.goods, p.seed); }, L.length ? 'goods + ' + label(L) : p.target + ' drams of ' + p.goods);
    if (doR) D.drawPan(this._panR.bitmap.context, R.length ? function (ctx, cx, rimY) { stand(ctx, rimY, R, cx - 64, 128); } : null, R.length ? label(R) : 'the far pan');
  } else {
    if (doL) D.drawPan(this._panL.bitmap.context, L.length ? function (ctx, cx, rimY) { D.pileCoins(ctx, cx, rimY, L.length, p.mint); } : null, L.length ? label(L) : '');
    if (doR) D.drawPan(this._panR.bitmap.context, R.length ? function (ctx, cx, rimY) { D.pileCoins(ctx, cx, rimY, R.length, p.mint); } : null, R.length ? label(R) : '');
  }
  if (doL) this._panL.bitmap._baseTexture.update(); if (doR) this._panR.bitmap._baseTexture.update();
};

Scene_Scales.prototype.refreshTray = function () {
  var D = this._d.draw, p = this._p, b = this._tray.bitmap, ctx = b.context, i;
  ctx.clearRect(0, 0, b.width, b.height); ctx.save(); ctx.translate(-this._tray.x, -this._tray.y);
  this.drawTrayContents(D, p, ctx); ctx.restore();
  b._baseTexture.update();
};
Scene_Scales.prototype.drawTrayContents = function (D, p, ctx) {
  var i;
  if (this._measure) { var S = D.boxSlots(p.weights); for (i = 0; i < p.weights.length; i++) if (this._pos[i] === 0) D.drawWeight(ctx, S[i].x, S[i].y, p.weights[i]); }
  else {
    var T = D.traySlots(p.n);
    for (i = 0; i < p.n; i++) {
      if (this._pos[i] === 0) D.drawCoin(ctx, T[i].x, T[i].y, 23, p.mint, {});
      else { ctx.font = 'italic bold 20px ' + D.FACE; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = 'rgba(240,225,190,0.5)'; ctx.fillText(this._pos[i] === 1 ? 'L' : 'R', T[i].x, T[i].y + 1); }
    }
  }
};

Scene_Scales.prototype.ledgerText = function (e) {
  var p = this._p, i, a = [], b = [];
  if (this._measure) {
    for (i = 0; i < e.place.length; i++) { if (e.place[i] < 0) a.push(p.weights[i]); else if (e.place[i] > 0) b.push(p.weights[i]); }
    return 'goods' + (a.length ? ' + ' + a.join(' + ') : '') + '  v  ' + (b.length ? b.join(' + ') : 'nothing');
  }
  for (i = 0; i < e.L.length; i++) a.push(e.L[i] + 1); for (i = 0; i < e.R.length; i++) b.push(e.R[i] + 1);
  return a.join('·') + '  v  ' + b.join('·');
};

Scene_Scales.prototype.refreshLedger = function () {
  var L = Scene_Scales.LEDGER, g = this._game, E = [], i;
  for (i = 0; i < g.log.length; i++) E.push({ text: this.ledgerText(g.log[i]), o: g.log[i].o });
  var info = this._measure ? { allowed: 0, left: 0, headline: 'Weighings: ' + g.log.length + '   fewest weights: ' + this._p.fewest, entries: E, empty: 'Nothing weighed yet.' }
    : { allowed: this._p.weighings, left: g.left, entries: E, empty: 'No weighings yet.' };
  this._d.draw.drawLedger(this._ledger.bitmap.context, L.w, L.h, info); this._ledger.bitmap._baseTexture.update();
};

Scene_Scales.prototype.refreshPlaques = function () {
  var P = Scene_Scales.PLAQUES, labels = this.plaqueLabels(), key = this._mode + '|' + this._cursor + '|', st = [], k;
  for (k = 0; k < 3; k++) { st.push(this.plaqueState(k)); key += labels[k] + st[k]; }
  if (key === this._plaqueKey) return; this._plaqueKey = key;
  var b = this._plaques.bitmap, ctx = b.context; ctx.clearRect(0, 0, b.width, b.height);
  ctx.save(); ctx.translate(8 - P.x, 8 - P.y);
  for (k = 0; k < 3; k++) this._d.draw.drawPlaque(ctx, P.x, P.y + k * P.gap, P.w, P.h, labels[k], st[k]);
  ctx.restore(); b._baseTexture.update();
};

Scene_Scales.prototype.setStatus = function (t) { if (t === this._statusText) return; this._statusText = t; var S = Scene_Scales.STATUS; this._d.draw.drawStatus(this._status.bitmap.context, S.w, S.h, t); this._status.bitmap._baseTexture.update(); };
Scene_Scales.prototype.placeCursor = function () {
  var onItem = this._cursor < this._items && (this._mode === 'play' || this._mode === 'accuse');
  this._ring.visible = onItem; if (onItem) { var xy = this.itemXY(this._cursor); this._ring.x = xy.x; this._ring.y = xy.y; }
  this.refreshPlaques();
};

//---------------------------------------------------------------------------- the beam

/** Place the beam and hang the pans from its ends. Scalars only: this runs every frame of a swing. */
Scene_Scales.prototype.applyBeam = function () {
  var D = this._d.draw, B = D.BAL, c = Math.cos(this._theta), s = Math.sin(this._theta);
  this._beam.rotation = this._theta;
  this._panL.x = B.fx - c * B.arm - D.PAN_HX; this._panL.y = B.fy - s * B.arm - 6;
  this._panR.x = B.fx + c * B.arm - D.PAN_HX; this._panR.y = B.fy + s * B.arm - 6;
};
/** A damped swing toward the target angle. Returns true while still moving. */
Scene_Scales.prototype.updateBeam = function () {
  var e = this._theta - this._target;
  if (Math.abs(e) < 0.0008 && Math.abs(this._omega) < 0.0008) { if (this._theta !== this._target) { this._theta = this._target; this._omega = 0; this.applyBeam(); } return false; }
  this._omega += -0.018 * e - 0.11 * this._omega; this._theta += this._omega; this.applyBeam(); return true;
};

//---------------------------------------------------------------------------- per frame

Scene_Scales.prototype.update = function () {
  Scene_Base.prototype.update.call(this);
  this._frame++;
  var moving = this.updateBeam();
  if (this._mode === 'play' || this._mode === 'accuse' || this._mode === 'dir') this.updateInput();
  else if (this._mode === 'swing') { if (!moving) this.afterSwing(); }
  else if (this._mode === 'reveal') this.updateVerdict();
  else if (this._mode === 'done') { if (Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered() || TouchInput.isCancelled()) this.leave(); }
  else if (this._mode === 'leaving' && !this.isBusy()) { this._mode = 'gone'; this.popScene(); }
};

/** The cursor's next item in a direction: the nearest item that way, preferring the same line. */
Scene_Scales.prototype.nearest = function (dx, dy) {
  var here = this.itemXY(this._cursor), best = -1, bestScore = 1e9, n = this._items + 3;
  for (var i = 0; i < n; i++) {
    if (i === this._cursor || !this.selectable(i)) continue;
    var xy = this.itemXY(i), px = (xy.x - here.x) * dx + (xy.y - here.y) * dy, sx = Math.abs((xy.x - here.x) * dy) + Math.abs((xy.y - here.y) * dx);
    if (px <= 8) continue; var score = px + sx * 2.5; if (score < bestScore) { bestScore = score; best = i; }
  }
  return best;
};
Scene_Scales.prototype.selectable = function (i) { if (this._mode === 'dir') return i >= this._items; if (this._mode === 'accuse') return i < this._items || i === this._items + 2; return true; };

Scene_Scales.prototype.moveCursor = function (i) { if (i < 0 || i === this._cursor) return; this._cursor = i; this.placeCursor(); };

Scene_Scales.prototype.updateInput = function () {
  var t = -1;
  if (Input.isRepeated('left')) t = this.nearest(-1, 0); else if (Input.isRepeated('right')) t = this.nearest(1, 0);
  else if (Input.isRepeated('up')) t = this.nearest(0, -1); else if (Input.isRepeated('down')) t = this.nearest(0, 1);
  if (t >= 0) { this.moveCursor(t); if (typeof SoundManager !== 'undefined') SoundManager.playCursor(); }
  if (Input.isTriggered('ok')) { this.activate(this._cursor); return; }
  if (Input.isTriggered('shift') && this._mode === 'play') { this.weigh(); return; }
  if (Input.isTriggered('cancel') || TouchInput.isCancelled()) { this.back(); return; }
  if (TouchInput.isTriggered()) { var hit = this.itemAt(TouchInput.x, TouchInput.y); if (hit >= 0 && this.selectable(hit)) { this.moveCursor(hit); this.activate(hit); } }
};
Scene_Scales.prototype.itemAt = function (x, y) {
  var P = Scene_Scales.PLAQUES, i;
  for (i = 0; i < 3; i++) if (x >= P.x && x < P.x + P.w && y >= P.y + i * P.gap && y < P.y + i * P.gap + P.h) return this._items + i;
  for (i = 0; i < this._items; i++) { var xy = this.itemXY(i), r = this._measure ? 32 : 28; if ((x - xy.x) * (x - xy.x) + (y - xy.y) * (y - xy.y) <= r * r) return i; }
  return -1;
};

Scene_Scales.prototype.back = function () {
  if (this._mode === 'dir') { this._mode = 'accuse'; this._cursor = this._pick; this.setStatus('Which coin is false?'); this.placeCursor(); return; }
  if (this._mode === 'accuse') { this._mode = 'play'; this.setStatus('OK moves a coin. Shift weighs. Esc leaves.'); this.placeCursor(); return; }
  this.leave();
};

Scene_Scales.prototype.activate = function (i) {
  var k = i - this._items;
  if (this._mode === 'dir') { if (k === 0) this.accuse(this._pick, 1); else if (k === 1) this.accuse(this._pick, -1); else this.back(); return; }
  if (this._mode === 'accuse') {
    if (k === 2) { this.back(); return; }
    if (i < this._items) { this._pick = i; if (this._p.known) this.accuse(i, this._p.dir); else { this._mode = 'dir'; this._cursor = this._items; this.setStatus('Coin ' + (i + 1) + ': heavier or lighter?'); this.placeCursor(); } }
    return;
  }
  if (i < this._items) { this.moveItem(i); return; }
  if (k === 0) this.weigh();
  else if (k === 1) this.clearPans();
  else if (this._measure) this.leave();
  else { this._mode = 'accuse'; this._cursor = 0; this.setStatus('Which coin is false?'); this.placeCursor(); }
};

/** OK on a coin: tray -> left -> right -> tray. On a weight: box -> far (right) -> goods (left) -> box. */
Scene_Scales.prototype.moveItem = function (i) {
  var c = this._pos[i];
  this._pos[i] = this._measure ? (c === 0 ? 2 : (c === 2 ? 1 : 0)) : (c === 0 ? 1 : (c === 1 ? 2 : 0));
  this.panChanged(); this.playSe(Scales.params.placeSe);
};
Scene_Scales.prototype.clearPans = function () { var any = false; for (var i = 0; i < this._pos.length; i++) if (this._pos[i]) { this._pos[i] = 0; any = true; } if (any) { this.panChanged(); this.playSe(Scales.params.placeSe); } };
/** The pans changed: the arrest takes the beam back to level, and the pans and tray are redrawn. */
Scene_Scales.prototype.panChanged = function () { this._target = 0; this.refreshPans(); this.refreshTray(); this.refreshPlaques(); var L = this.onSide(1).length, R = this.onSide(2).length; if (!this._measure) this.setStatus(L || R ? (L === R ? L + ' against ' + R + '. Shift weighs.' : 'The pans must hold the same number of coins.') : 'OK moves a coin. Shift weighs. Esc leaves.'); };

Scene_Scales.prototype.weigh = function () {
  if (!this.canWeigh()) { if (!this._measure && this._game.left <= 0) this.setStatus('No weighings left. Name the false coin.'); return; }
  // ⛔ found by the in-engine test (2026-09-27): the scene moved weights in _pos and never told the puzzle, so every
  // order weighed as empty pans and could not be solved. The pans are copied into the game before each weighing:
  // the far (right) pan counts +1, the goods (left) pan -1.
  if (this._measure) for (var i = 0; i < this._pos.length; i++) this._game.place[i] = this._pos[i] === 2 ? 1 : (this._pos[i] === 1 ? -1 : 0);
  var o = this._measure ? this._d.core.measureWeigh(this._p, this._game) : this._d.core.weigh(this._p, this._game, this.onSide(1), this.onSide(2));
  if (o === null) return;
  // a level result still swings: the beam is released, rocks and comes to rest level
  this._last = o; this._target = -o * this._d.draw.BAL.maxTilt; this._omega += o === 0 ? 0.014 : -o * 0.02;
  this._mode = 'swing'; this.refreshLedger(); this.refreshPlaques(); this.placeCursor(); this.playSe(Scales.params.weighSe);
  this.setStatus('The beam is released...');
};
Scene_Scales.prototype.afterSwing = function () {
  var o = this._last;
  if (this._measure && o === 0) { this.finish(true); return; }
  this._mode = 'play'; this.placeCursor();
  var said = o > 0 ? 'The left pan sank.' : (o < 0 ? 'The right pan sank.' : 'The beam holds level.');
  if (this._measure) said = o > 0 ? 'The goods pan sank: too little on the far pan.' : 'The far pan sank: too much against the goods.';
  else if (this._game.left <= 0) said += ' Name the false coin.';
  this.setStatus(said);
};

Scene_Scales.prototype.accuse = function (coin, dir) {
  var r = this._d.core.accuse(this._p, this._game, coin, dir);
  this._result = r; this.finish(r.won);
};

//---------------------------------------------------------------------------- the verdict

Scene_Scales.prototype.finish = function (won) {
  var rec = this._rec, v = won ? 1 : 2;
  rec.tries = (rec.tries || 0) + 1;
  if (won) {
    rec.done = true; rec.won = true; rec.weighings = this._game.log.length;
    if (this._result) { rec.coin = this._result.coin; rec.dir = this._result.dir; }
    if (this._measure) { var last = this._game.log[this._game.log.length - 1]; rec.place = last.place.slice(); rec.used = last.used; }
  }
  if (won && this._req.switchId > 0 && typeof $gameSwitches !== 'undefined') $gameSwitches.setValue(this._req.switchId, true);
  if (this._req.variableId > 0 && typeof $gameVariables !== 'undefined') $gameVariables.setValue(this._req.variableId, v);
  this.playSe(won ? Scales.params.winSe : Scales.params.loseSe);
  this.drawVerdict(won); this._verdict.opacity = 0; this._verdict.visible = true; this._verdictT = 0; this._mode = 'reveal'; this._ring.visible = false; this.refreshPlaques();
};
Scene_Scales.prototype.drawVerdict = function (won) {
  var p = this._p, D = this._d.draw, b = this._verdict.bitmap, info;
  if (this._measure) {
    // a reopened puzzle reads the player's own answer from the record, not the generator's
    var n = this._game.log.length, last = n ? this._game.log[n - 1] : null, g = n || this._rec.weighings || 1;
    var used = last ? last.used : (this._rec.used || p.fewest), place = last ? last.place : (this._rec.place || p.solution);
    info = { goods: p.goods, amount: p.target, label: p.target + ' drams of ' + p.goods, seed: p.seed, weights: p.weights, place: place, won: true,
      title: this._req.title + ', weighed out', sub: 'in ' + Scales.word(g) + (g === 1 ? ' weighing' : ' weighings') + ' with ' + Scales.word(used) + (used === 1 ? ' weight' : ' weights') + (used <= p.fewest ? ' (the fewest there are)' : ' (it can be done with ' + Scales.word(p.fewest) + ')') };
  } else {
    var r = this._result || { coin: this._rec.coin, dir: this._rec.dir, won: true }, core = D.coreOf(p.mint.metal, r.dir), k = this._game.log.length || this._rec.weighings || 0;
    info = { mint: p.mint, dir: r.dir, won: won, genuine: Math.min(7, p.n - 1),
      title: (won ? 'Found: ' : 'Not that one. It was ') + 'No. ' + (r.coin + 1) + ', ' + (r.dir > 0 ? 'heavier' : 'lighter'),
      sub: (won ? 'In ' + Scales.word(k) + (k === 1 ? ' weighing' : ' weighings') + '. ' : 'The weighings still allowed it. ') + 'The cut shows ' + core.name + ' under the ' + p.mint.metal + '.' };
  }
  D.drawVerdict(b.context, b.width, b.height, info); b._baseTexture.update();
  this._verdictInfo = info;
};
Scene_Scales.prototype.updateVerdict = function () {
  this._verdictT++; this._verdict.opacity = Math.min(255, Math.round(this._verdictT * 255 / 24));
  if (this._verdictT >= 30) { this._mode = 'done'; this.setStatus(this._verdictInfo && this._verdictInfo.won ? 'Solved.' : 'The counterfeiter wins this time.'); }
};
/** A solved puzzle reopened: straight to the verdict. */
Scene_Scales.prototype.showVerdict = function () {
  this._game.over = true;
  this.drawVerdict(true); this._verdict.opacity = 255; this._verdict.visible = true; this._mode = 'done'; this._ring.visible = false; this.setStatus('Solved.');
  if (this._req.variableId > 0 && typeof $gameVariables !== 'undefined') $gameVariables.setValue(this._req.variableId, 1);
  this.refreshPlaques();
};

Scene_Scales.prototype.leave = function () {
  if (this._mode === 'leaving' || this._mode === 'gone') return;
  if (this._mode !== 'done' && this._req.variableId > 0 && typeof $gameVariables !== 'undefined') $gameVariables.setValue(this._req.variableId, 0);
  this._mode = 'leaving'; this.startFadeOut(this.fadeSpeed(), false);
};
