//=============================================================================
// Goose.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Goose 3/3 - party board games for MZ, laid out and drawn by the plugin.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * Goose
 * ============================================================================
 *
 * A board game for your festival, tavern, casino or side quest: the party
 * leader races up to three rivals along a trail of spaces, rolling a die,
 * choosing at forks between a shortcut full of hazards and a scenic route
 * full of coins. The board is GENERATED from a seed and DRAWN by the plugin:
 * a landscape (meadow, desert, snowfield, coast, forest or volcano), the
 * trail, every space tile, the tokens and the dice. Nothing is loaded from an
 * image file except your own face graphics on the tokens.
 *
 * Spaces: Coins (+3), Loss (-3), Chest (5 to 10 coins), Event (runs one of
 * YOUR common events), Warp (jumps to its exit), Roll again, Snare (lose a
 * turn), Gust (blown back 2 to 4), Boost (forward 2 to 4), Start and Goal.
 *
 * ----------------------------------------------------------------------------
 * INSTALLING
 * ----------------------------------------------------------------------------
 * Copy GooseCore.js, GooseDraw.js and Goose.js into js/plugins and enable all
 * three. Any order works: each file finds the others when a game starts.
 *
 * ----------------------------------------------------------------------------
 * USING IT
 * ----------------------------------------------------------------------------
 * Add the plugin command "Play Board Game" to an event. The event waits while
 * the game is played. Results go to the variables and switch you choose:
 * the player's place (1 = won), the coins the player ended with, and a switch
 * turned ON when the player wins. Coins can be paid out as gold.
 *
 * Event spaces run the common events you list, like a battle event: show
 * text, give items, change gold, set switches. Commands that need the map
 * (moving events, transferring the player) wait until the game is over.
 *
 * Leave the seed blank and every visit lays out a new board; give a seed and
 * the same board appears every time.
 *
 * ----------------------------------------------------------------------------
 * CONTROLS
 * ----------------------------------------------------------------------------
 * OK (or a click / tap) rolls the die. At a fork, left / right (or up / down)
 * picks a route and OK takes it; or click the space you want. Hold OK to
 * hurry the rivals' turns. At the end, OK leaves.
 *
 * ----------------------------------------------------------------------------
 * SCRIPT
 * ----------------------------------------------------------------------------
 *   Goose.play({ length: 36, rivals: 2, theme: 'coast' })    same options as the command
 *   Goose.record()                                           { v, played, won }
 *
 * ----------------------------------------------------------------------------
 * COMPATIBILITY
 * ----------------------------------------------------------------------------
 * Goose adds its own scene and replaces nothing. It extends two engine
 * methods, each by saving the original and calling it: Game_System.initialize
 * (its save record) and Game_Interpreter.updateWaitMode (so the event waits
 * while the game is played).
 *
 * ============================================================================
 * TERMS OF USE
 * ============================================================================
 * Commercial and non-commercial use permitted in RPG Maker projects, credit
 * appreciated but not required. Do not redistribute the source as an asset
 * pack. Every line of this plugin was written with AI assistance.
 * ============================================================================
 *
 * @param rollSe
 * @text Sound: the roll
 * @type file
 * @dir audio/se
 * @default Knock
 *
 * @param stepSe
 * @text Sound: a step
 * @type file
 * @dir audio/se
 * @default Cursor1
 *
 * @param coinSe
 * @text Sound: coins
 * @type file
 * @dir audio/se
 * @default Coin
 *
 * @param badSe
 * @text Sound: a hazard
 * @type file
 * @dir audio/se
 * @default Buzzer1
 *
 * @param winMe
 * @text Music effect: a win
 * @type file
 * @dir audio/me
 * @default Victory1
 *
 * @command play
 * @text Play Board Game
 * @desc Lay out a board and race it. The event waits until the game is over.
 *
 * @arg length
 * @text Spaces on the trail
 * @type number
 * @min 24
 * @max 60
 * @default 36
 *
 * @arg forks
 * @text Forks
 * @type number
 * @min 0
 * @max 3
 * @default 2
 *
 * @arg theme
 * @text Landscape
 * @type select
 * @option auto
 * @option meadow
 * @option desert
 * @option snowfield
 * @option coast
 * @option forest
 * @option volcano
 * @default auto
 *
 * @arg rivals
 * @text Rivals
 * @type number
 * @min 1
 * @max 3
 * @default 3
 *
 * @arg rivalActors
 * @text Rival actors (faces and names)
 * @desc Optional. Actors whose names and faces the rivals use, in seat order. Blank = named rivals with plain tokens.
 * @type actor[]
 * @default []
 *
 * @arg rivalNames
 * @text Rival names
 * @desc Used when no rival actors are given. Comma separated.
 * @default Pip, Marlowe, Wren
 *
 * @arg temper
 * @text Rival temper
 * @type select
 * @option mixed
 * @option bold
 * @option steady
 * @option canny
 * @desc bold takes shortcuts, steady the scenic routes, canny takes the shortcut only when behind. mixed = one of each.
 * @default mixed
 *
 * @arg dice
 * @text Dice
 * @type select
 * @option 1
 * @option 2
 * @default 1
 *
 * @arg maxTurns
 * @text Round limit
 * @type number
 * @min 5
 * @max 99
 * @default 30
 *
 * @arg eventCommons
 * @text Event space common events
 * @desc Each common event listed gets one Event space on the board (up to 6).
 * @type common_event[]
 * @default []
 *
 * @arg placeVariable
 * @text Variable: player's place
 * @type variable
 * @default 0
 *
 * @arg coinsVariable
 * @text Variable: player's coins
 * @type variable
 * @default 0
 *
 * @arg wonSwitch
 * @text Switch: player won
 * @type switch
 * @default 0
 *
 * @arg goldPerCoin
 * @text Gold per coin
 * @desc Coins paid out as gold at the end. 0 = no payout.
 * @type number
 * @min 0
 * @default 0
 *
 * @arg seed
 * @text Seed (optional)
 * @desc Blank = a new board every visit. A number or word = the same board every time.
 * @default
 */

var Goose = Goose || {};

(function (M) {
  'use strict';
  var NAME = 'Goose', SCHEMA = 1;
  var raw = (typeof PluginManager !== 'undefined') ? PluginManager.parameters(NAME) : {};
  // ⛔ parameters arrive as STRINGS: blank is absent, never zero (wing §16)
  function num(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; var n = Number(v); return isFinite(n) ? n : d; }
  function str(v, d) { if (v === undefined || v === null || String(v).trim() === '') return d; return String(v).trim(); }
  function list(v) { try { var a = JSON.parse(v || '[]'); return Array.isArray(a) ? a.map(Number).filter(function (n) { return n > 0; }) : []; } catch (e) { return []; } }
  // every default is a file the stock RTP ships (2026-10-08: a 'Dice' default stopped the game at the first roll with
  // "Failed to load: audio/se/Dice.ogg" - there is no such stock sound); pinned by _probe/smoke.js against BlankProject
  M.params = { rollSe: str(raw.rollSe, 'Knock'), stepSe: str(raw.stepSe, 'Cursor1'), coinSe: str(raw.coinSe, 'Coin'), badSe: str(raw.badSe, 'Buzzer1'), winMe: str(raw.winMe, 'Victory1') };

  /* ⛔ load order is the buyer's choice: resolve siblings at FIRST USE, never at load (wing §8 trap 2) */
  var _deps = null;
  function deps() {
    if (_deps) return _deps;
    var core = (typeof GooseCore !== 'undefined') ? GooseCore : null, draw = (typeof GooseDraw !== 'undefined') ? GooseDraw : null;
    if (!core || !draw) { if (!deps._w) { deps._w = true; console.error('Goose: enable GooseCore.js and GooseDraw.js in the Plugin Manager too.'); } return null; }
    _deps = { core: core, draw: draw }; return _deps;
  }
  M.deps = deps;

  function fresh() { return { v: SCHEMA, played: 0, won: 0 }; }
  M.record = function () {
    if (typeof $gameSystem === 'undefined' || !$gameSystem) return fresh();
    var s = $gameSystem._csafGoose; if (!s || s.v == null) { s = fresh(); $gameSystem._csafGoose = s; }
    return s;
  };
  var _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () { _Game_System_initialize.call(this); this._csafGoose = fresh(); };

  /** A game request from command arguments (or a script call's options). Null when the siblings are missing. */
  M.request = function (args) {
    var d = deps(); if (!d) return null; args = args || {};
    var seedText = str(args.seed, ''), seed;
    // blank: a new board every visit, from the play time and the games already played (never the wall clock, so a
    // saved game replays the same way)
    if (seedText === '') seed = d.core.mix(d.core.hashString('goose') ^ (M.record().played * 7919), (typeof $gameSystem !== 'undefined' && $gameSystem ? $gameSystem.playtime() : 0) >>> 0);
    else seed = /^\d+$/.test(seedText) ? (Number(seedText) >>> 0) : d.core.hashString(seedText);
    var rivals = Math.max(1, Math.min(3, Math.floor(num(args.rivals, 3))));
    var actors = Array.isArray(args.rivalActors) ? args.rivalActors : list(args.rivalActors);
    var names = str(args.rivalNames, 'Pip, Marlowe, Wren').split(',').map(function (s) { return s.trim(); }).filter(Boolean);
    var temper = str(args.temper, 'mixed'), tempers = temper === 'mixed' ? ['bold', 'canny', 'steady'] : [temper, temper, temper];
    var theme = str(args.theme, 'auto');
    return { seed: seed, length: Math.max(24, Math.min(60, Math.floor(num(args.length, 36)))), forks: Math.max(0, Math.min(3, Math.floor(num(args.forks, 2)))),
      theme: theme === 'auto' ? null : theme, rivals: rivals, rivalActors: actors, rivalNames: names, tempers: tempers,
      dice: Math.floor(num(args.dice, 1)) === 2 ? 2 : 1, maxTurns: Math.max(5, Math.min(99, Math.floor(num(args.maxTurns, 30)))),
      eventIds: Array.isArray(args.eventCommons) ? args.eventCommons : list(args.eventCommons),
      placeVariable: Math.max(0, Math.floor(num(args.placeVariable, 0))), coinsVariable: Math.max(0, Math.floor(num(args.coinsVariable, 0))),
      wonSwitch: Math.max(0, Math.floor(num(args.wonSwitch, 0))), goldPerCoin: Math.max(0, Math.floor(num(args.goldPerCoin, 0))) };
  };
  /** Start a game. Returns false (and plays nothing) when the siblings are missing. */
  M.play = function (opts) {
    var req = opts && opts.seed != null && opts.length != null && opts.tempers ? opts : M.request(opts || {});
    if (!req) return false;
    SceneManager.push(Scene_Goose); SceneManager.prepareNextScene(req); return true;
  };

  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
    PluginManager.registerCommand(NAME, 'play', function (args) {
      if (M.play(M.request(args))) this.setWaitMode('goose');
    });
  }
  // the event waits while the game scene is up (the same shape as the engine's own wait modes)
  var _updateWaitMode = Game_Interpreter.prototype.updateWaitMode;
  Game_Interpreter.prototype.updateWaitMode = function () {
    if (this._waitMode === 'goose') {
      if (SceneManager._scene instanceof Scene_Goose || SceneManager._nextScene instanceof Scene_Goose) return true;
      this._waitMode = '';
      return false;
    }
    return _updateWaitMode.call(this);
  };
  M.VERSION = '1.0.0'; M.SCHEMA = SCHEMA;
}(Goose));

//=============================================================================
// Scene_Goose
//=============================================================================

function Scene_Goose() { this.initialize.apply(this, arguments); }
Scene_Goose.prototype = Object.create(Scene_Message.prototype);
Scene_Goose.prototype.constructor = Scene_Goose;
Scene_Goose.HOP = 12;          // frames per space moved
Scene_Goose.GLIDE = 26;        // frames for a warp, gust or boost glide
Scene_Goose.BANNER = 56;       // frames an effect banner holds
Scene_Goose.AI_WAIT = 18;      // frames a rival waits before rolling
Scene_Goose.ROLL = 34;         // frames the die tumbles
Scene_Goose.CAM = 0.14;        // camera easing per frame
Scene_Goose.HUD_H = 78;        // the racer cards along the bottom

Scene_Goose.prototype.prepare = function (req) { this._req = req; };

Scene_Goose.prototype.create = function () {
  Scene_Message.prototype.create.call(this);
  var d = Goose.deps(), req = this._req, C = d.core;
  this._d = d;
  this._board = C.makeBoard(req.seed, { length: req.length, forks: req.forks, theme: req.theme, eventIds: req.eventIds });
  var leader = $gameParty.leader(), racers = [{ name: leader ? leader.name() : 'You', ai: 'player', actor: leader }];
  for (var i = 0; i < req.rivals; i++) {
    var a = req.rivalActors[i] ? $gameActors.actor(req.rivalActors[i]) : null;
    racers.push({ name: a ? a.name() : (req.rivalNames[i] || ('Rival ' + (i + 1))), ai: req.tempers[i % req.tempers.length], actor: a });
  }
  this._actors = racers.map(function (r) { return r.actor || null; });
  this._actors.forEach(function (a) { if (a && a.faceName()) ImageManager.loadFace(a.faceName()); });
  this._race = C.createRace(this._board, racers.map(function (r) { return { name: r.name, ai: r.ai }; }), C.mix(req.seed, 0xBEEF), { dice: req.dice, maxTurns: req.maxTurns });
  this._world = new Sprite(); this._hud = new Sprite();
  this.addChild(this._world); this.addChild(this._hud);
  this.createWindowLayer();
  this.createAllWindows();
  this._interp = new Game_Interpreter();
  this._mode = 'loading'; this._t = 0; this._camX = 0; this._camY = 0; this._hop = null; this._choice = 0; this._options = null; this._fx = null;
};

Scene_Goose.prototype.start = function () {
  Scene_Message.prototype.start.call(this);
  this.buildWorld(); this.buildTokens(); this.buildHud();
  this.focus(this._board.nodes[this._board.start], true);
  this.banner(this._board.name, 'First to the goal wins. Coins count too.', 80);
  this._mode = 'intro';
  this.startFadeIn(this.fadeSpeed(), false);
};

//---------------------------------------------------------------------------- building (once per game)

/** The landscape, the trail and every tile, baked into one bitmap the size of the world. */
Scene_Goose.prototype.buildWorld = function () {
  var b = this._board, bmp = new Bitmap(b.W, b.H), g = bmp.context;
  this._landscape = this._d.draw.landscape(g, b);
  this._tileCounts = this._d.draw.tiles(g, b);
  bmp._baseTexture.update();
  this._ground = new Sprite(bmp); this._world.addChild(this._ground);
  this._arrows = [];
  for (var i = 0; i < 2; i++) {                            // the fork chooser: two drawn arrows, baked once
    var ab = new Bitmap(64, 64), ag = ab.context;
    ag.translate(32, 32); ag.fillStyle = '#fff4d6'; ag.strokeStyle = '#4a321b'; ag.lineWidth = 3;
    ag.beginPath(); ag.moveTo(-14, -24); ag.lineTo(14, -24); ag.lineTo(14, 2); ag.lineTo(26, 2); ag.lineTo(0, 28); ag.lineTo(-26, 2); ag.lineTo(-14, 2); ag.closePath(); ag.fill(); ag.stroke();
    ab._baseTexture.update();
    var s = new Sprite(ab); s.anchor.x = 0.5; s.anchor.y = 1; s.visible = false; this._world.addChild(s); this._arrows.push(s);
  }
  this._tokenLayer = new Sprite(); this._world.addChild(this._tokenLayer);
};

/** One token per racer, the racer's face (if it has one) on a medallion above the pawn. */
Scene_Goose.prototype.buildTokens = function () {
  var D = this._d.draw, self = this;
  this._tokens = this._race.racers.map(function (r, i) {
    var bmp = new Bitmap(96, 150), a = self._actors[i];
    var faceFn = null;
    if (a && a.faceName()) {
      var sheet = ImageManager.loadFace(a.faceName()), fi = a.faceIndex(), pw = ImageManager.faceWidth, ph = ImageManager.faceHeight;
      faceFn = function (g, x, y, rad) { g.drawImage(sheet._canvas || sheet._image, (fi % 4) * pw, Math.floor(fi / 4) * ph, pw, ph, x - rad, y - rad, rad * 2, rad * 2); };
    }
    D.token(bmp.context, 48, 140, 62, i, faceFn, String(i + 1));
    bmp._baseTexture.update();
    var s = new Sprite(bmp); s.anchor.x = 0.5; s.anchor.y = 140 / 150;
    self._tokenLayer.addChild(s);
    return s;
  });
  this.placeTokens();
};

/** Stand each token on its node, spread so tokens sharing a space do not cover each other. */
Scene_Goose.prototype.placeTokens = function () {
  var rs = this._race.racers, nodes = this._board.nodes, i, k, same;
  for (i = 0; i < rs.length; i++) {
    if (this._hop && this._hop.racer === i) continue;
    same = 0; for (k = 0; k < i; k++) if (rs[k].at === rs[i].at) same++;
    var n = nodes[rs[i].at];
    // tokens sharing a space fan out to either side of it, so each pawn's number stays readable
    var k2 = rs.filter(function (r) { return r.at === rs[i].at; }).length, off = (same - (k2 - 1) / 2) * 20;
    this._tokens[i].x = n.x + off; this._tokens[i].y = n.y + 4 + Math.abs(off) * 0.15;
  }
  this.sortTokens();
};
Scene_Goose.prototype.sortTokens = function () { this._tokenLayer.children.sort(function (a, b) { return a.y - b.y; }); };

/** The HUD: racer cards (redrawn when a number changes), the die (six faces baked once), the banner and the prompt. */
Scene_Goose.prototype.buildHud = function () {
  var D = this._d.draw;
  this._cards = new Sprite(new Bitmap(Graphics.width, Scene_Goose.HUD_H)); this._cards.y = Graphics.height - Scene_Goose.HUD_H; this._hud.addChild(this._cards);
  this._dieFaces = [];
  for (var p = 1; p <= 6; p++) { var db = new Bitmap(120, 120); D.bigDie(db.context, 56, 64, 72, p, 0); db._baseTexture.update(); this._dieFaces.push(db); }
  this._dice = [];
  for (var k = 0; k < this._race.dice; k++) {                 // one sprite per die, side by side (2026-10-08: with two dice a
    var dsp = new Sprite(this._dieFaces[0]);                 // single die once showed half the total)
    dsp.anchor.x = dsp.anchor.y = 0.5; dsp.x = Graphics.width / 2 + (k - (this._race.dice - 1) / 2) * 96; dsp.y = Graphics.height / 2 - 30; dsp.visible = false;
    this._hud.addChild(dsp); this._dice.push(dsp);
  }
  this._die = this._dice[0];
  this._banner = new Sprite(new Bitmap(560, 92)); this._banner.anchor.x = 0.5; this._banner.x = Graphics.width / 2; this._banner.y = 18; this._banner.visible = false; this._hud.addChild(this._banner);
  this._prompt = new Sprite(new Bitmap(360, 46)); this._prompt.anchor.x = 0.5; this._prompt.x = Graphics.width / 2; this._prompt.y = Graphics.height - Scene_Goose.HUD_H - 58; this._prompt.visible = false; this._hud.addChild(this._prompt);
  this._results = new Sprite(); this._results.visible = false; this._hud.addChild(this._results);
  this.refreshCards();
};

Scene_Goose.prototype.refreshCards = function () {
  var D = this._d.draw, C = this._d.core, bmp = this._cards.bitmap, g = bmp.context, rs = this._race.racers, n = rs.length, w = (Graphics.width - 20) / n;
  var dist = C.distToGoal(this._board);
  bmp.clear();
  for (var i = 0; i < n; i++) {
    var x = 10 + i * w, on = i === this._race.current && this._race.phase !== 'done';
    D.plate(g, x + 4, 8, w - 8, Scene_Goose.HUD_H - 14, { paper: on ? '#fff3cf' : '#efe3c8' });
    D.token(g, x + 30, 64, 34, i, null, String(i + 1));
    D.text(g, rs[i].name, x + 56, 28, 17, '#2a1d14', 'left', '700');
    D.coinIcon(g, x + 64, 52, 8);
    D.text(g, String(rs[i].coins), x + 78, 53, 17, '#2a1d14', 'left', '700');
    D.text(g, rs[i].finished ? 'home' : (dist[rs[i].at] + ' to go'), x + w - 16, 53, 14, '#6a4e2e', 'right', '600');
    if (rs[i].skip) D.text(g, 'snared', x + w - 16, 28, 13, '#a3352d', 'right', '700');
  }
  bmp._baseTexture.update();
};

Scene_Goose.prototype.banner = function (title, sub, frames) {
  var D = this._d.draw, bmp = this._banner.bitmap, g = bmp.context;
  bmp.clear();
  D.plate(g, 4, 4, bmp.width - 10, sub ? 82 : 56);
  D.text(g, title, bmp.width / 2, 32, 26, '#2a1d14', 'center', '700');
  if (sub) D.text(g, sub, bmp.width / 2, 63, 16, '#5b4128', 'center', '600');
  bmp._baseTexture.update();
  // the banner never covers the racer it is about: on a board too short for the camera to scroll, the current token
  // can sit in the top band, so the banner drops to just above the racer cards (2026-10-08, coast board, two dice)
  var tok = this._tokens && this._tokens[this._race.current], sy = tok ? tok.y + this._world.y : Graphics.height;
  this._banner.y = sy < 200 ? Graphics.height - Scene_Goose.HUD_H - 160 : 18;   // clear of the prompt plate below it
  this._banner.visible = true; this._bannerT = frames || Scene_Goose.BANNER;
};
Scene_Goose.prototype.prompt = function (text) {
  var D = this._d.draw, bmp = this._prompt.bitmap, g = bmp.context;
  bmp.clear(); D.plate(g, 3, 3, bmp.width - 8, bmp.height - 8, { paper: '#fff6dc' }); D.text(g, text, bmp.width / 2, bmp.height / 2 - 1, 18, '#2a1d14', 'center', '700');
  bmp._baseTexture.update(); this._prompt.visible = true;
};

//---------------------------------------------------------------------------- the camera

Scene_Goose.prototype.focus = function (pt, snap) {
  // the point sits a little BELOW the middle of the view: the banner lives at the top (2026-10-08: the intro banner
  // covered the start and all four tokens on it)
  var b = this._board, W = Graphics.width, H = Graphics.height - Scene_Goose.HUD_H;
  this._camTX = b.W <= W ? (W - b.W) / 2 : Math.max(W - b.W, Math.min(0, W / 2 - pt.x));
  this._camTY = b.H <= H ? (H - b.H) / 2 : Math.max(H - b.H, Math.min(0, H * 0.58 - pt.y));
  if (snap) { this._camX = this._camTX; this._camY = this._camTY; }
};
Scene_Goose.prototype.updateCamera = function () {
  this._camX += (this._camTX - this._camX) * Scene_Goose.CAM; this._camY += (this._camTY - this._camY) * Scene_Goose.CAM;
  this._world.x = Math.round(this._camX); this._world.y = Math.round(this._camY);
};

//---------------------------------------------------------------------------- the turn

Scene_Goose.prototype.update = function () {
  Scene_Message.prototype.update.call(this);
  if (this._mode === 'loading') return;
  this.updateCamera();
  if (this._bannerT > 0 && --this._bannerT === 0) this._banner.visible = false;
  if (this._interp.isRunning()) {
    this._interp.update();
    // ⛔ waits that only the MAP can end (a transfer, a move route, a vehicle, a gather) would hang the game here: the
    // command still takes effect (a reserved transfer happens when the player is back on the map), the event goes on
    var wm = this._interp._waitMode;
    if (wm === 'transfer' || wm === 'route' || wm === 'vehicle' || wm === 'gather' || wm === 'balloon' || wm === 'animation') this._interp._waitMode = '';
    return;
  }
  if ($gameMessage.isBusy() || this.isBusy()) return;
  this._t++;
  var fast = Input.isPressed('ok') || TouchInput.isPressed();
  switch (this._mode) {
    case 'intro': if (this._t > 70 || (this._t > 12 && this.triggered())) this.nextTurn(); break;
    case 'await': this.updateAwait(); break;
    case 'roll':
      if (this._t % 4 === 0) for (var k = 0; k < this._dice.length; k++) this._dice[k].bitmap = this._dieFaces[(this._t * 7 + k * 3 + this._race.current) % 6];
      if (this._t >= Scene_Goose.ROLL) this.showRoll();
      break;
    case 'shown': if (this._t >= 22) { this.showDice(false); this.beginStep(); } break;
    case 'hop': this.updateHop(fast); break;
    case 'choose': this.updateChoose(); break;
    case 'glide': this.updateHop(fast); break;
    case 'effect': if (this._t >= (fast && !this.isPlayer() ? 20 : 44)) this.finishTurn(); break;
    case 'results': if (this._t > 30 && this.triggered()) this.leave(); break;
  }
};
Scene_Goose.prototype.triggered = function () { return Input.isTriggered('ok') || TouchInput.isTriggered(); };
Scene_Goose.prototype.isPlayer = function () { return this._race.racers[this._race.current].ai === 'player'; };
Scene_Goose.prototype.cur = function () { return this._race.racers[this._race.current]; };
Scene_Goose.prototype.playSe = function (n) { if (n) AudioManager.playSe({ name: n, volume: 80, pitch: 100, pan: 0 }); };

Scene_Goose.prototype.nextTurn = function () {
  this._mode = 'await'; this._t = 0;
  this.focus(this._board.nodes[this.cur().at]);
  this.refreshCards();
  if (this.isPlayer()) this.prompt(this.cur().skip ? 'Snared! OK to wait a turn' : 'Your turn: OK to roll'); else this._prompt.visible = false;
};
Scene_Goose.prototype.updateAwait = function () {
  if (this.isPlayer() ? !this.triggered() : this._t < Scene_Goose.AI_WAIT) return;
  this._prompt.visible = false;
  var v = this._d.core.roll(this._race);
  if (this._race.phase === 'end') { this.effect({ kind: 'skipped' }); return; }
  this._rolled = v; this._mode = 'roll'; this._t = 0; this.showDice(true); this.playSe(Goose.params.rollSe);
};
Scene_Goose.prototype.showDice = function (on) { for (var k = 0; k < this._dice.length; k++) this._dice[k].visible = on; };
Scene_Goose.prototype.showRoll = function () {
  var v = this._rolled, faces = this._race.faces || [v];
  for (var k = 0; k < this._dice.length; k++) this._dice[k].bitmap = this._dieFaces[Math.max(0, Math.min(5, (faces[k] || 1) - 1))];
  this.banner(this.cur().name + ' rolls ' + v, null, 30);
  this._mode = 'shown'; this._t = 0;
};

/** One space forward: ask the core, then animate the hop. At a fork the player chooses first. */
Scene_Goose.prototype.beginStep = function (choice) {
  var C = this._d.core, r = this._race;
  if (r.phase !== 'move') { this.resolve(); return; }
  var m = C.stepOne(r, this._board, choice);
  if (m.needChoice) { this.beginChoose(m.options); return; }
  this.hopTo(m.from, m.to, Scene_Goose.HOP, 'hop');
};
Scene_Goose.prototype.hopTo = function (from, to, frames, mode) {
  var a = this._board.nodes[from], b = this._board.nodes[to];
  this._hop = { racer: this._race.current, ax: a.x, ay: a.y, bx: b.x, by: b.y, f: 0, n: frames, mode: mode };
  this._mode = mode; this._t = 0;
};
Scene_Goose.prototype.updateHop = function (fast) {
  var h = this._hop, tok = this._tokens[h.racer];
  h.f += fast && !this.isPlayer() ? 2 : 1;
  var u = Math.min(1, h.f / h.n), lift = h.mode === 'hop' ? Math.sin(u * Math.PI) * 22 : Math.sin(u * Math.PI) * 60;
  tok.x = h.ax + (h.bx - h.ax) * u; tok.y = h.ay + (h.by - h.ay) * u + 4 - lift;
  this._camTX = 0; this.focus({ x: tok.x, y: tok.y });
  if (u < 1) return;
  this._hop = null; this.placeTokens();
  if (h.mode === 'hop') { this.playSe(Goose.params.stepSe); this.beginStep(); } else this.finishTurn();
};

Scene_Goose.prototype.beginChoose = function (options) {
  this._options = options; this._choice = 0; this._mode = 'choose'; this._t = 0;
  this.prompt('A fork: choose a route, OK to go');
  this.showArrows();
};
Scene_Goose.prototype.showArrows = function () {
  for (var i = 0; i < 2; i++) {
    var n = this._board.nodes[this._options[i]], s = this._arrows[i];
    s.x = n.x; s.y = n.y - 24; s.visible = true; s.opacity = i === this._choice ? 255 : 120; s.scale.x = s.scale.y = i === this._choice ? 1 : 0.8;
  }
};
Scene_Goose.prototype.updateChoose = function () {
  if (Input.isTriggered('left') || Input.isTriggered('right') || Input.isTriggered('up') || Input.isTriggered('down')) { this._choice = 1 - this._choice; this.showArrows(); this.playSe(Goose.params.stepSe); }
  var pick = -1;
  if (TouchInput.isTriggered()) {
    for (var i = 0; i < 2; i++) { var n = this._board.nodes[this._options[i]], dx = TouchInput.x - (n.x + this._world.x), dy = TouchInput.y - (n.y + this._world.y); if (dx * dx + dy * dy < 40 * 40) pick = i; }
  }
  if (Input.isTriggered('ok')) pick = this._choice;
  if (pick < 0) return;
  this._arrows[0].visible = this._arrows[1].visible = false; this._prompt.visible = false;
  this.beginStep(this._options[pick]);
};

/** The racer has stopped: resolve the space and show what it did. */
Scene_Goose.prototype.resolve = function () {
  var r = this._race;
  if (r.phase === 'end') { this.effect(r.last || { kind: 'none' }); return; }
  var fx = this._d.core.land(r, this._board);
  if (fx.eventId && $dataCommonEvents[fx.eventId]) this._interp.setup($dataCommonEvents[fx.eventId].list, 0);
  this.effect(fx);
};
Scene_Goose.prototype.effect = function (fx) {
  var who = this.cur().name, P = Goose.params, words = {
    coin: [who + ' +' + fx.coins + ' coins', null, P.coinSe], loss: [fx.coins ? who + ' drops ' + (-fx.coins) + ' coins' : 'A loss space, but the purse is empty', null, P.badSe],
    chest: ['A chest! +' + fx.coins + ' coins', null, P.coinSe], event: ['An event space', null, null], warp: ['Warp!', who + ' is carried along the trail', null],
    again: [fx.again ? 'Roll again!' : 'Roll again (already used this turn)', null, null], snare: ['Snared!', who + ' loses the next turn', P.badSe],
    gust: ['A gust!', who + ' is blown back ' + (fx.back || 0), P.badSe], boost: ['Boost!', who + ' runs ahead ' + (fx.forward || 0), null],
    finish: [who + ' reaches the goal!', 'Place ' + (fx.place || this._race.order.length), null], skipped: [who + ' is snared', 'and waits this turn out', null],
  }[fx.kind] || [null, null, null];
  if (words[0]) this.banner(words[0], words[1], Scene_Goose.BANNER);
  this.playSe(words[2]);
  this.refreshCards();
  if (fx.to != null && fx.kind !== 'finish') {                // warp, gust and boost glide to where they land
    var tok = this._tokens[this._race.current], n = this._board.nodes[fx.to];
    this._hop = { racer: this._race.current, ax: tok.x, ay: tok.y - 4, bx: n.x, by: n.y, f: 0, n: Scene_Goose.GLIDE, mode: 'glide' };
    this._mode = 'glide'; this._t = 0; return;
  }
  this._mode = 'effect'; this._t = 0;
};
Scene_Goose.prototype.finishTurn = function () {
  var r = this._race, C = this._d.core;
  this.placeTokens(); this.refreshCards();
  if (r.phase === 'roll') { this.nextTurn(); return; }          // roll again: same racer
  if (C.endTurn(r) === 'done') { this.showResults(); return; }
  this.nextTurn();
};

//---------------------------------------------------------------------------- the end

Scene_Goose.prototype.showResults = function () {
  var D = this._d.draw, C = this._d.core, res = C.results(this._race, this._board), W = Graphics.width, H = Graphics.height;
  this._final = res;
  var bmp = new Bitmap(W, H), g = bmp.context, pw = 460, ph = 120 + res.length * 64, px = (W - pw) / 2, py = (H - ph) / 2 - 20;
  g.fillStyle = 'rgba(20,14,8,0.45)'; g.fillRect(0, 0, W, H);
  D.plate(g, px, py, pw, ph);
  D.text(g, this._board.name, W / 2, py + 40, 28, '#2a1d14', 'center', '700');
  D.text(g, 'after ' + Math.min(this._race.turn, this._race.maxTurns) + ' rounds', W / 2, py + 72, 16, '#6a4e2e', 'center', '600');
  var places = ['1st', '2nd', '3rd', '4th'];
  for (var i = 0; i < res.length; i++) {
    var y = py + 112 + i * 64;
    D.text(g, places[i], px + 36, y, 24, i === 0 ? '#9a6a12' : '#4a321b', 'left', '700');
    D.token(g, px + 120, y + 26, 40, res[i].racer, null, String(res[i].racer + 1));
    D.text(g, res[i].name, px + 150, y, 21, '#2a1d14', 'left', '700');
    D.coinIcon(g, px + pw - 110, y, 9); D.text(g, String(res[i].coins), px + pw - 92, y + 1, 20, '#2a1d14', 'left', '700');
  }
  D.text(g, 'OK to leave the table', W / 2, py + ph - 26, 15, '#6a4e2e', 'center', '600');
  bmp._baseTexture.update();
  this._results.bitmap = bmp; this._results.visible = true; this._banner.visible = false; this._prompt.visible = false; this.showDice(false);
  this._mode = 'results'; this._t = 0;
  var me = null; for (i = 0; i < res.length; i++) if (this._race.racers[res[i].racer].ai === 'player') me = res[i];
  this._mine = me;
  if (me && me.place === 1 && Goose.params.winMe) AudioManager.playMe({ name: Goose.params.winMe, volume: 90, pitch: 100, pan: 0 });
};
Scene_Goose.prototype.leave = function () {
  var req = this._req, me = this._mine, rec = Goose.record();
  if (me) {
    if (req.placeVariable > 0) $gameVariables.setValue(req.placeVariable, me.place);
    if (req.coinsVariable > 0) $gameVariables.setValue(req.coinsVariable, me.coins);
    if (req.wonSwitch > 0) $gameSwitches.setValue(req.wonSwitch, me.place === 1);
    if (req.goldPerCoin > 0) $gameParty.gainGold(me.coins * req.goldPerCoin);
    rec.played++; if (me.place === 1) rec.won++;
  }
  this.popScene();
};
Scene_Goose.prototype.stop = function () { Scene_Message.prototype.stop.call(this); this.startFadeOut(this.fadeSpeed(), false); };
