//=============================================================================
// GooseDraw.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Goose 2/3 - the drawing kit: landscapes, trails, tiles, tokens, dice. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The drawing kit for Goose. No parameters or commands of its own. It knows
 * nothing about RPG Maker: it draws on a canvas 2D context. No image, font or
 * sound file ships with Goose.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var GooseDraw = (function (root) {
  'use strict';
  function core() { return root.GooseCore || (typeof GooseCore !== 'undefined' ? GooseCore : null); }

  var TAU = Math.PI * 2;
  var FONT = '"Palatino Linotype", "Book Antiqua", Palatino, Georgia, serif';

  /* ---------------------------------------------------------------- colour */

  function hex(c) { var n = parseInt(c.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  function css(rgb, a) { return a == null ? 'rgb(' + rgb.map(Math.round).join(',') + ')' : 'rgba(' + rgb.map(Math.round).join(',') + ',' + a + ')'; }
  function toHex(rgb) { return '#' + rgb.map(function (v) { var s = Math.max(0, Math.min(255, Math.round(v))).toString(16); return s.length < 2 ? '0' + s : s; }).join(''); }
  /** Lighten (k > 0) or darken (k < 0) a #rrggbb colour. Returns #rrggbb, so it composes with hex() (2026-10-08: it
   *  returned rgb(...), hex() parsed that as NaN, and the trail's centre stroke silently drew in the wrong colour). */
  function shade(c, k) { var h = hex(c); return toHex(h.map(function (v) { return k >= 0 ? v + (255 - v) * k : v * (1 + k); })); }
  function lum(c) { var h = hex(c).map(function (v) { v /= 255; return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * h[0] + 0.7152 * h[1] + 0.0722 * h[2]; }
  function contrast(a, b) { var x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); }
  /** The ink that reads best on `bg` (Icon_Doctrine §22e: never hard-code an ink). */
  function pickInk(bg, inks) { var best = inks[0], bc = 0; for (var i = 0; i < inks.length; i++) { var c = contrast(bg, inks[i]); if (c > bc) { bc = c; best = inks[i]; } } return best; }

  /* ---------------------------------------------------------------- themes */

  // ground, its variation, the trail's surface and edging, the tile RIM material, decor
  var THEME = {
    meadow: { ground: '#86b25e', ground2: '#6f9c4b', speck: '#a9c972', path: '#d2ad73', edge: '#8a6a3c', stones: '#b8925a', rim: '#a8743f', rimDark: '#6e4a24', grain: 'wood', decor: ['tree', 'bush', 'flowers', 'flowers', 'rock'] },
    desert: { ground: '#e2c08a', ground2: '#d4ab6d', speck: '#efd3a2', path: '#b98a55', edge: '#8c6034', stones: '#a37847', rim: '#cf7650', rimDark: '#8f3f26', grain: 'strata', decor: ['cactus', 'rock', 'dune', 'dune', 'bones'] },
    snowfield: { ground: '#eaf0f5', ground2: '#d5e1ea', speck: '#ffffff', path: '#a8bbcf', edge: '#6f86a0', stones: '#c3d1df', rim: '#9fd0e6', rimDark: '#5a8fb0', grain: 'ice', decor: ['pine', 'pine', 'drift', 'rock', 'drift'] },
    coast: { ground: '#ecd8a4', ground2: '#dfc58a', speck: '#f6e8c4', path: '#a87b4b', edge: '#6b4a2a', stones: '#c49a64', rim: '#f0e2cb', rimDark: '#b89c78', grain: 'shell', decor: ['palm', 'shell', 'rock', 'grass', 'shell'], sea: '#4f9dc4' },
    forest: { ground: '#4f7d46', ground2: '#3f6a39', speck: '#6c9a58', path: '#8d6b45', edge: '#4f3a22', stones: '#a5845a', rim: '#8e9c80', rimDark: '#56634a', grain: 'moss', decor: ['tree', 'tree', 'mushroom', 'fern', 'fern'] },
    volcano: { ground: '#463a3b', ground2: '#3a2f31', speck: '#5d4e4c', path: '#6b574e', edge: '#2c2223', stones: '#86705f', rim: '#3a3140', rimDark: '#1c1620', grain: 'obsidian', decor: ['crack', 'crack', 'rock', 'spire', 'ash'], glow: '#ff7a2a' },
  };
  // the kind's FACE colour is the same in every theme, so a player learns it once
  var KIND = {
    start: { face: '#f7f1e3', name: 'Start' }, goal: { face: '#f2cf5b', name: 'Goal' },
    coin: { face: '#3f86d6', name: 'Coins' }, loss: { face: '#d0483e', name: 'Loss' }, chest: { face: '#e9a93a', name: 'Chest' },
    event: { face: '#8e63cf', name: 'Event' }, warp: { face: '#2bb3a6', name: 'Warp' }, again: { face: '#55b85f', name: 'Roll again' },
    snare: { face: '#6b6670', name: 'Snare' }, gust: { face: '#a6d3e4', name: 'Gust' }, boost: { face: '#f08a3a', name: 'Boost' },
  };
  var INKS = ['#2a1d14', '#fff8ea'];
  var RACER = ['#d94141', '#3f78d4', '#e8b52f', '#4fae5a'];

  /* ---------------------------------------------------------------- the landscape */

  function distToSeg(px, py, ax, ay, bx, by) {
    var dx = bx - ax, dy = by - ay, L = dx * dx + dy * dy, t = L ? ((px - ax) * dx + (py - ay) * dy) / L : 0;
    t = t < 0 ? 0 : t > 1 ? 1 : t;
    var x = ax + dx * t - px, y = ay + dy * t - py; return Math.sqrt(x * x + y * y);
  }
  function edges(board) { var out = []; board.nodes.forEach(function (n) { n.next.forEach(function (m) { out.push([n, board.nodes[m]]); }); }); return out; }
  function clearOf(board, segs, x, y, pad) {
    for (var i = 0; i < segs.length; i++) if (distToSeg(x, y, segs[i][0].x, segs[i][0].y, segs[i][1].x, segs[i][1].y) < pad) return false;
    return true;
  }

  /** Paint the ground: base, soft patches, speckle, and (coast) the sea along the bottom edge. */
  function ground(ctx, board, T, r) {
    var W = board.W, H = board.H, i;
    ctx.fillStyle = T.ground; ctx.fillRect(0, 0, W, H);
    for (i = 0; i < Math.round(W * H / 9000); i++) {
      var x = r() * W, y = r() * H, rad = 30 + r() * 90, g = ctx.createRadialGradient(x, y, 0, x, y, rad);
      g.addColorStop(0, css(hex(r() < 0.5 ? T.ground2 : T.speck), 0.35)); g.addColorStop(1, css(hex(T.ground), 0));
      ctx.fillStyle = g; ctx.fillRect(x - rad, y - rad, rad * 2, rad * 2);
    }
    ctx.fillStyle = css(hex(T.speck), 0.5);
    for (i = 0; i < Math.round(W * H / 700); i++) ctx.fillRect(Math.floor(r() * W), Math.floor(r() * H), 1 + Math.floor(r() * 2), 1);
    ctx.fillStyle = css(hex(T.ground2), 0.55);
    for (i = 0; i < Math.round(W * H / 900); i++) ctx.fillRect(Math.floor(r() * W), Math.floor(r() * H), 1, 1 + Math.floor(r() * 2));
    if (T.sea) {                                           // a shoreline with foam along the far edge
      ctx.save(); ctx.beginPath(); ctx.moveTo(0, H);
      for (var x2 = 0; x2 <= W; x2 += 16) ctx.lineTo(x2, H - 56 - 14 * Math.sin(x2 / 70) - 8 * Math.sin(x2 / 23 + 1));
      ctx.lineTo(W, H); ctx.closePath();
      var sg = ctx.createLinearGradient(0, H - 90, 0, H); sg.addColorStop(0, T.sea); sg.addColorStop(1, shade(T.sea, -0.35));
      ctx.fillStyle = sg; ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.75)'; ctx.lineWidth = 3; ctx.stroke(); ctx.restore();
    }
    if (T.glow) {                                          // volcano: a lava glow from below the far edge
      var gg = ctx.createLinearGradient(0, H - 160, 0, H); gg.addColorStop(0, 'rgba(255,90,20,0)'); gg.addColorStop(1, 'rgba(255,90,20,0.35)');
      ctx.fillStyle = gg; ctx.fillRect(0, H - 160, W, 160);
    }
  }

  /** One piece of scenery at (x, y), size s, in the theme's palette. Returns true if it drew. */
  function decor(ctx, kind, x, y, s, T, r) {
    ctx.save(); ctx.translate(x, y);
    function shadow(w) { ctx.fillStyle = 'rgba(0,0,0,0.18)'; ctx.beginPath(); ctx.ellipse(w * 0.15, 2, w, w * 0.32, 0, 0, TAU); ctx.fill(); }
    if (kind === 'tree') {
      shadow(s * 0.9);
      ctx.fillStyle = '#6b4a2b'; ctx.fillRect(-s * 0.09, -s * 0.5, s * 0.18, s * 0.55);
      var greens = [shade(T.ground2, -0.25), shade(T.ground2, -0.05), shade(T.ground, 0.12)];
      for (var k = 0; k < 3; k++) { ctx.fillStyle = greens[k]; ctx.beginPath(); ctx.arc((k - 1) * s * 0.18, -s * (0.75 + k * 0.12) + (k === 1 ? -s * 0.1 : 0), s * (0.42 - k * 0.07), 0, TAU); ctx.fill(); }
    } else if (kind === 'pine') {
      shadow(s * 0.7);
      ctx.fillStyle = '#5b4330'; ctx.fillRect(-s * 0.07, -s * 0.3, s * 0.14, s * 0.32);
      for (var t = 0; t < 3; t++) {
        ctx.fillStyle = t % 2 ? '#2f5b48' : '#3a6b55'; ctx.beginPath();
        var top = -s * (0.55 + t * 0.32), wd = s * (0.55 - t * 0.12);
        ctx.moveTo(0, top - s * 0.4); ctx.lineTo(wd, top + s * 0.1); ctx.lineTo(-wd, top + s * 0.1); ctx.closePath(); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.85)'; ctx.beginPath(); ctx.moveTo(0, top - s * 0.4); ctx.lineTo(wd * 0.45, top - s * 0.1); ctx.lineTo(-wd * 0.3, top - s * 0.14); ctx.closePath(); ctx.fill();
      }
    } else if (kind === 'bush' || kind === 'fern' || kind === 'grass') {
      var c0 = kind === 'grass' ? '#8aa65a' : shade(T.ground2, -0.2);
      ctx.strokeStyle = c0; ctx.lineWidth = Math.max(1.5, s * 0.07); ctx.lineCap = 'round';
      for (var b = 0; b < 7; b++) { var a = -Math.PI / 2 + (b - 3) * 0.28; ctx.beginPath(); ctx.moveTo(0, 0); ctx.quadraticCurveTo(Math.cos(a) * s * 0.3, Math.sin(a) * s * 0.5, Math.cos(a) * s * 0.55, Math.sin(a) * s * 0.75); ctx.stroke(); }
    } else if (kind === 'flowers') {
      var fc = ['#f4e36b', '#f6f2ea', '#e98bb4', '#b490e8'][Math.floor(r() * 4)];
      for (var f = 0; f < 5; f++) { var fx = (r() - 0.5) * s, fy = (r() - 0.5) * s * 0.6; ctx.fillStyle = fc; ctx.beginPath(); ctx.arc(fx, fy, s * 0.07, 0, TAU); ctx.fill(); ctx.fillStyle = '#d8902b'; ctx.fillRect(fx - 0.5, fy - 0.5, 1.5, 1.5); }
    } else if (kind === 'rock') {
      shadow(s * 0.45);
      var rc = T.grain === 'obsidian' ? '#5a4a52' : T.grain === 'ice' ? '#8a9cae' : '#9a8f84';
      ctx.fillStyle = rc; ctx.beginPath(); ctx.moveTo(-s * 0.4, 0); ctx.lineTo(-s * 0.3, -s * 0.3); ctx.lineTo(s * 0.05, -s * 0.42); ctx.lineTo(s * 0.4, -s * 0.18); ctx.lineTo(s * 0.42, 0); ctx.closePath(); ctx.fill();
      ctx.fillStyle = shade(rc, 0.25); ctx.beginPath(); ctx.moveTo(-s * 0.3, -s * 0.3); ctx.lineTo(s * 0.05, -s * 0.42); ctx.lineTo(0, -s * 0.15); ctx.closePath(); ctx.fill();
    } else if (kind === 'cactus') {
      shadow(s * 0.4);
      ctx.strokeStyle = '#4f8a4a'; ctx.lineCap = 'round'; ctx.lineWidth = s * 0.2;
      ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -s * 0.9); ctx.stroke();
      ctx.lineWidth = s * 0.13; ctx.beginPath(); ctx.moveTo(0, -s * 0.45); ctx.lineTo(s * 0.28, -s * 0.45); ctx.lineTo(s * 0.28, -s * 0.72); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, -s * 0.3); ctx.lineTo(-s * 0.24, -s * 0.3); ctx.lineTo(-s * 0.24, -s * 0.55); ctx.stroke();
    } else if (kind === 'dune') {
      ctx.strokeStyle = css(hex(T.ground2), 0.9); ctx.lineWidth = 2;
      for (var d = 0; d < 3; d++) { ctx.beginPath(); ctx.moveTo(-s, d * 7); ctx.quadraticCurveTo(0, d * 7 - s * 0.3, s, d * 7); ctx.stroke(); }
    } else if (kind === 'bones') {
      ctx.strokeStyle = '#f1e8d6'; ctx.lineWidth = 2.2; ctx.lineCap = 'round';
      for (var bo = 0; bo < 3; bo++) { ctx.beginPath(); ctx.arc(0, s * 0.1, s * (0.2 + bo * 0.1), Math.PI * 1.1, Math.PI * 1.9); ctx.stroke(); }
    } else if (kind === 'drift') {
      ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.ellipse(0, 0, s * 0.7, s * 0.2, 0, Math.PI, TAU); ctx.fill();
      ctx.strokeStyle = 'rgba(120,150,180,0.5)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.ellipse(0, 0, s * 0.7, s * 0.2, 0, Math.PI, TAU); ctx.stroke();
    } else if (kind === 'palm') {
      shadow(s * 0.6);
      ctx.strokeStyle = '#8a6440'; ctx.lineWidth = s * 0.12; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(0, 0); ctx.quadraticCurveTo(s * 0.2, -s * 0.6, s * 0.08, -s * 1.15); ctx.stroke();
      ctx.strokeStyle = '#3f8d4c'; ctx.lineWidth = s * 0.09;
      for (var p = 0; p < 5; p++) { var pa = -Math.PI / 2 + (p - 2) * 0.62; ctx.beginPath(); ctx.moveTo(s * 0.08, -s * 1.15); ctx.quadraticCurveTo(s * 0.08 + Math.cos(pa) * s * 0.4, -s * 1.15 + Math.sin(pa) * s * 0.2 - s * 0.1, s * 0.08 + Math.cos(pa) * s * 0.65, -s * 1.15 + Math.sin(pa) * s * 0.45 + s * 0.2); ctx.stroke(); }
    } else if (kind === 'shell') {
      ctx.fillStyle = '#f6e3cf'; ctx.beginPath(); ctx.moveTo(0, 0); ctx.arc(0, 0, s * 0.22, Math.PI, TAU); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = '#c99b78'; ctx.lineWidth = 1; for (var sl = -2; sl <= 2; sl++) { ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(sl * s * 0.09, -s * 0.2); ctx.stroke(); }
    } else if (kind === 'mushroom') {
      ctx.fillStyle = '#efe4d0'; ctx.fillRect(-s * 0.06, -s * 0.25, s * 0.12, s * 0.25);
      ctx.fillStyle = '#c4473b'; ctx.beginPath(); ctx.arc(0, -s * 0.25, s * 0.22, Math.PI, TAU); ctx.fill();
      ctx.fillStyle = '#fff4e6'; ctx.beginPath(); ctx.arc(-s * 0.08, -s * 0.33, s * 0.04, 0, TAU); ctx.arc(s * 0.08, -s * 0.3, s * 0.035, 0, TAU); ctx.fill();
    } else if (kind === 'crack') {
      ctx.strokeStyle = T.glow || '#ff7a2a'; ctx.lineWidth = 2.2; ctx.shadowColor = T.glow || '#ff7a2a'; ctx.shadowBlur = 8;
      ctx.beginPath(); ctx.moveTo(-s * 0.6, 0); ctx.lineTo(-s * 0.2, -s * 0.12); ctx.lineTo(0, s * 0.08); ctx.lineTo(s * 0.35, -s * 0.05); ctx.lineTo(s * 0.6, s * 0.1); ctx.stroke();
    } else if (kind === 'spire') {
      shadow(s * 0.4);
      ctx.fillStyle = '#2b2328'; ctx.beginPath(); ctx.moveTo(-s * 0.25, 0); ctx.lineTo(-s * 0.05, -s * 0.95); ctx.lineTo(s * 0.12, -s * 0.6); ctx.lineTo(s * 0.25, 0); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#4a3d44'; ctx.beginPath(); ctx.moveTo(-s * 0.05, -s * 0.95); ctx.lineTo(s * 0.12, -s * 0.6); ctx.lineTo(0, -s * 0.5); ctx.closePath(); ctx.fill();
    } else if (kind === 'ash') {
      ctx.fillStyle = 'rgba(30,24,26,0.55)'; for (var as = 0; as < 6; as++) { ctx.beginPath(); ctx.arc((r() - 0.5) * s, (r() - 0.5) * s * 0.5, 1 + r() * 2, 0, TAU); ctx.fill(); }
    } else { ctx.restore(); return false; }
    ctx.restore();
    return true;
  }

  /** The trail: an edging, the surface, then the theme's stones along it. Every edge of the board, detours included. */
  function trail(ctx, board, T, r) {
    var segs = edges(board);
    ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    function stroke(w, c) { ctx.strokeStyle = c; ctx.lineWidth = w; segs.forEach(function (s) { ctx.beginPath(); ctx.moveTo(s[0].x, s[0].y); ctx.lineTo(s[1].x, s[1].y); ctx.stroke(); }); }
    stroke(34, css(hex(T.edge), 0.85));
    stroke(26, T.path);
    stroke(10, css(hex(shade(T.path, 0.12)), 0.6));
    ctx.fillStyle = T.stones;
    segs.forEach(function (s) {                          // stones at a PITCH along each edge (Icon_Doctrine §22b-1a), never a count
      var dx = s[1].x - s[0].x, dy = s[1].y - s[0].y, L = Math.sqrt(dx * dx + dy * dy), n = Math.floor(L / 11);
      for (var k = 1; k < n; k++) {
        var u = k / n, side = (k % 2 ? 1 : -1) * (5 + r() * 5), nx = -dy / L, ny = dx / L;
        ctx.beginPath(); ctx.ellipse(s[0].x + dx * u + nx * side, s[0].y + dy * u + ny * side, 2 + r() * 1.6, 1.4 + r(), r() * 3, 0, TAU); ctx.fill();
      }
    });
    ctx.restore();
  }

  /** Bake the whole landscape (ground, scenery clear of the trail, the trail) for a board. Returns counts for tests. */
  function landscape(ctx, board) {
    var C = core(), T = THEME[board.theme] || THEME.meadow, r = C.rng(C.mix(board.seed, 0x1A4D)), segs = edges(board), drawn = 0, tried = 0;
    ground(ctx, board, T, r);
    var items = [];
    var N = Math.round(board.W * board.H / 5200);
    for (var i = 0; i < N; i++) {
      tried++;
      var x = 20 + r() * (board.W - 40), y = 30 + r() * (board.H - 50), s = 14 + r() * 22;
      if (!clearOf(board, segs, x, y, 40 + s * 0.6)) continue;
      if (T.sea && y > board.H - 80) continue;
      items.push({ x: x, y: y, s: s, kind: T.decor[Math.floor(r() * T.decor.length)] });
    }
    items.sort(function (a, b) { return a.y - b.y; });            // nearer things over farther ones
    for (var k = 0; k < items.length; k++) if (decor(ctx, items[k].kind, items[k].x, items[k].y, items[k].s, T, r)) drawn++;
    trail(ctx, board, T, r);
    return { decor: drawn, tried: tried, edges: segs.length };
  }

  /* ---------------------------------------------------------------- glyphs (one hand, asymmetric, Icon_Doctrine §22) */

  var GLYPH = {
    // ⛔ 2026-10-08 contact sheet: a ring with a star and a glint read as a BOMB with a lit fuse, and a cracked coin as
    // an EGG (Icon_Doctrine §22a). Coins are now drawn the way a coin is recognised: a STACK seen from the side.
    // (second pass, same sheet: hollow side-on coins read as a SPRING; coins are now solid cylinders with grooves)
    coin: function (g, r, ink) {                          // two stacks of coins, a tall one behind and a short one in front
      g.fillStyle = ink;
      coinStack(g, r * 0.2, r * 0.3, r * 0.3, r * 0.11, 4, r * 0.17);
      coinStack(g, -r * 0.24, r * 0.5, r * 0.32, r * 0.12, 2, r * 0.17);
    },
    loss: function (g, r, ink) {                          // a short stack of coins and a heavy arrow pointing DOWN beside it
      g.fillStyle = ink;
      coinStack(g, -r * 0.22, r * 0.42, r * 0.32, r * 0.12, 3, r * 0.17);
      g.beginPath(); g.moveTo(r * 0.3, -r * 0.62); g.lineTo(r * 0.5, -r * 0.62); g.lineTo(r * 0.5, r * 0.02); g.lineTo(r * 0.66, r * 0.02);
      g.lineTo(r * 0.4, r * 0.5); g.lineTo(r * 0.14, r * 0.02); g.lineTo(r * 0.3, r * 0.02); g.closePath(); g.fill();
    },
    chest: function (g, r, ink) {                         // a chest with a domed lid, a band and a hasp, lid ajar
      g.fillStyle = ink;
      g.fillRect(-r * 0.62, -r * 0.05, r * 1.24, r * 0.6);
      g.beginPath(); g.moveTo(-r * 0.62, -r * 0.14); g.quadraticCurveTo(-r * 0.6, -r * 0.62, 0, -r * 0.66); g.quadraticCurveTo(r * 0.62, -r * 0.62, r * 0.66, -r * 0.24); g.closePath(); g.fill();
      g.globalCompositeOperation = 'destination-out';
      g.fillRect(-r * 0.62, -r * 0.12, r * 1.3, r * 0.08);
      g.fillRect(-r * 0.09, -r * 0.03, r * 0.18, r * 0.24);
      g.globalCompositeOperation = 'source-over';
    },
    event: function (g, r, ink) {                         // an unrolled scroll with an exclamation mark
      g.fillStyle = ink;
      g.beginPath(); g.moveTo(-r * 0.5, -r * 0.55); g.lineTo(r * 0.38, -r * 0.55); g.quadraticCurveTo(r * 0.6, -r * 0.4, r * 0.4, -r * 0.25); g.lineTo(r * 0.4, r * 0.55); g.lineTo(-r * 0.5, r * 0.55); g.quadraticCurveTo(-r * 0.66, r * 0.4, -r * 0.5, r * 0.25); g.closePath(); g.fill();
      g.globalCompositeOperation = 'destination-out';
      g.beginPath(); g.moveTo(-r * 0.12, -r * 0.38); g.lineTo(r * 0.1, -r * 0.38); g.lineTo(r * 0.03, r * 0.16); g.lineTo(-r * 0.05, r * 0.16); g.closePath(); g.fill();
      g.beginPath(); g.arc(-r * 0.01, r * 0.33, r * 0.08, 0, TAU); g.fill();
      g.globalCompositeOperation = 'source-over';
    },
    warp: function (g, r, ink) {                          // a spiral, wide at the mouth
      g.strokeStyle = ink; g.lineCap = 'round'; g.lineWidth = r * 0.14; g.beginPath();
      for (var t = 0; t <= 1.0001; t += 0.02) { var a = t * Math.PI * 3.6, rad = r * (0.06 + 0.56 * t); g[t === 0 ? 'moveTo' : 'lineTo'](Math.cos(a) * rad, Math.sin(a) * rad); }
      g.stroke();
    },
    again: function (g, r, ink) {                         // two dice, one tumbling
      die(g, -r * 0.22, r * 0.12, r * 0.5, 0.15, ink, 3);
      die(g, r * 0.28, -r * 0.24, r * 0.4, -0.5, ink, 5);
    },
    // ⛔ 2026-10-08 contact sheet: trap jaws read as a MAGNIFYING GLASS. The space costs a turn, and an hourglass says so.
    snare: function (g, r, ink) {                         // an hourglass, tipped, the sand mostly run
      g.save(); g.rotate(0.22); g.fillStyle = ink; g.strokeStyle = ink; g.lineWidth = r * 0.1; g.lineCap = 'round';
      g.fillRect(-r * 0.4, -r * 0.66, r * 0.8, r * 0.12); g.fillRect(-r * 0.4, r * 0.54, r * 0.8, r * 0.12);
      g.beginPath(); g.moveTo(-r * 0.3, -r * 0.54); g.quadraticCurveTo(-r * 0.3, -r * 0.08, 0, 0); g.quadraticCurveTo(-r * 0.3, r * 0.08, -r * 0.3, r * 0.54);
      g.moveTo(r * 0.3, -r * 0.54); g.quadraticCurveTo(r * 0.3, -r * 0.08, 0, 0); g.quadraticCurveTo(r * 0.3, r * 0.08, r * 0.3, r * 0.54); g.stroke();
      g.beginPath(); g.moveTo(-r * 0.22, r * 0.52); g.quadraticCurveTo(0, r * 0.2, r * 0.22, r * 0.52); g.closePath(); g.fill();   // the run sand
      g.beginPath(); g.moveTo(-r * 0.1, -r * 0.3); g.lineTo(r * 0.1, -r * 0.3); g.lineTo(0, -r * 0.12); g.closePath(); g.fill();      // what is left
      g.fillRect(-r * 0.025, -r * 0.05, r * 0.05, r * 0.4);
      g.restore();
    },
    gust: function (g, r, ink) {                          // three wind strokes blowing BACK (to the left), curled at the end
      g.strokeStyle = ink; g.lineCap = 'round'; g.lineWidth = r * 0.12;
      [[-0.32, 0.62], [0.02, 0.8], [0.34, 0.5]].forEach(function (w, i) {
        var y = w[0] * r, L = w[1] * r; g.beginPath(); g.moveTo(r * 0.55, y); g.lineTo(r * 0.55 - L, y);
        g.arc(r * 0.55 - L, y - r * 0.12, r * 0.12, Math.PI / 2, Math.PI * (i === 1 ? 2.1 : 1.8), false); g.stroke();
      });
    },
    boost: function (g, r, ink) {                         // two chevrons forward, the second smaller (motion)
      g.fillStyle = ink;
      [[-0.32, 1], [0.22, 0.75]].forEach(function (c) {
        var x = c[0] * r, k = c[1];
        g.beginPath(); g.moveTo(x - r * 0.18 * k, -r * 0.5 * k); g.lineTo(x + r * 0.32 * k, 0); g.lineTo(x - r * 0.18 * k, r * 0.5 * k); g.lineTo(x - r * 0.4 * k, r * 0.5 * k); g.lineTo(x + r * 0.1 * k, 0); g.lineTo(x - r * 0.4 * k, -r * 0.5 * k); g.closePath(); g.fill();
      });
    },
    start: function (g, r, ink) {                         // a pennant on a pole
      g.fillStyle = ink; g.fillRect(-r * 0.36, -r * 0.62, r * 0.1, r * 1.24);
      g.beginPath(); g.moveTo(-r * 0.26, -r * 0.6); g.quadraticCurveTo(r * 0.15, -r * 0.5, r * 0.55, -r * 0.42); g.quadraticCurveTo(r * 0.12, -r * 0.24, -r * 0.26, -r * 0.12); g.closePath(); g.fill();
      g.beginPath(); g.ellipse(-r * 0.31, r * 0.6, r * 0.24, r * 0.07, 0, 0, TAU); g.fill();
    },
    goal: function (g, r, ink) {                          // a trophy cup with handles and a stepped foot
      g.fillStyle = ink; g.strokeStyle = ink; g.lineWidth = r * 0.1;
      g.beginPath(); g.moveTo(-r * 0.42, -r * 0.55); g.lineTo(r * 0.42, -r * 0.55); g.quadraticCurveTo(r * 0.4, r * 0.05, 0, r * 0.12); g.quadraticCurveTo(-r * 0.4, r * 0.05, -r * 0.42, -r * 0.55); g.fill();
      g.beginPath(); g.arc(-r * 0.46, -r * 0.3, r * 0.17, Math.PI * 0.5, Math.PI * 1.5); g.stroke();
      g.beginPath(); g.arc(r * 0.46, -r * 0.3, r * 0.17, -Math.PI * 0.5, Math.PI * 0.5); g.stroke();
      g.fillRect(-r * 0.07, r * 0.1, r * 0.14, r * 0.26); g.fillRect(-r * 0.3, r * 0.36, r * 0.6, r * 0.12); g.fillRect(-r * 0.4, r * 0.5, r * 0.8, r * 0.1);
    },
  };
  /**
   * A stack of `n` coins as one solid cylinder (bottom at yb, coin thickness `step`), the joins between coins cut as
   * grooves along their lower rims and the top coin's face ringed, all on the glyph's own layer (§22d).
   */
  function coinStack(g, x, yb, w, h, n, step) {
    var yt = yb - (n - 1) * step;
    g.beginPath(); g.ellipse(x, yb, w, h, 0, 0, Math.PI); g.lineTo(x - w, yt); g.ellipse(x, yt, w, h, 0, Math.PI, TAU); g.lineTo(x + w, yb); g.closePath(); g.fill();
    g.beginPath(); g.ellipse(x, yt, w, h, 0, 0, TAU); g.fill();
    g.save(); g.globalCompositeOperation = 'destination-out'; g.lineWidth = Math.max(1, step * 0.22);
    for (var k = 0; k < n; k++) { g.beginPath(); g.ellipse(x, yt + k * step, w, h, 0, Math.PI * 0.1, Math.PI * 0.9); g.stroke(); }
    g.beginPath(); g.ellipse(x, yt, w * 0.62, h * 0.52, 0, 0, TAU); g.stroke();
    g.restore();
  }
  function star(g, x, y, s, ink) {
    g.fillStyle = ink; g.beginPath();
    for (var i = 0; i < 10; i++) { var a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? s * 0.45 : s; g[i ? 'lineTo' : 'moveTo'](x + Math.cos(a) * rr, y + Math.sin(a) * rr); }
    g.closePath(); g.fill();
  }
  /** A die face of `pips`, rounded square, rotated by `rot`. */
  function die(g, x, y, s, rot, ink, pips, face) {
    g.save(); g.translate(x, y); g.rotate(rot);
    var h = s / 2, rr = s * 0.18;
    g.beginPath(); g.moveTo(-h + rr, -h); g.arcTo(h, -h, h, h, rr); g.arcTo(h, h, -h, h, rr); g.arcTo(-h, h, -h, -h, rr); g.arcTo(-h, -h, h, -h, rr); g.closePath();
    g.fillStyle = face || ink; g.fill();
    if (face) { g.strokeStyle = ink; g.lineWidth = Math.max(1, s * 0.06); g.stroke(); }
    var P = { 1: [[0, 0]], 2: [[-1, -1], [1, 1]], 3: [[-1, -1], [0, 0], [1, 1]], 4: [[-1, -1], [1, -1], [-1, 1], [1, 1]], 5: [[-1, -1], [1, -1], [0, 0], [-1, 1], [1, 1]], 6: [[-1, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [1, 1]] }[pips] || [];
    if (!face) g.globalCompositeOperation = 'destination-out';
    g.fillStyle = face ? ink : '#000';
    for (var i = 0; i < P.length; i++) { g.beginPath(); g.arc(P[i][0] * s * 0.25, P[i][1] * s * 0.25, s * 0.09, 0, TAU); g.fill(); }
    g.restore();
  }

  /* ---------------------------------------------------------------- tiles */

  /** The rim material, worked per theme: wood grain, sandstone strata, ice facets, shell ribs, moss, obsidian glints. */
  function rim(g, r, T, seed) {
    var C = core(), rr = C.rng(seed);
    var gr = g.createRadialGradient(-r * 0.3, -r * 0.35, r * 0.2, 0, 0, r * 1.05);
    gr.addColorStop(0, shade(T.rim, 0.25)); gr.addColorStop(1, T.rimDark);
    g.fillStyle = gr; g.beginPath(); g.arc(0, 0, r, 0, TAU); g.fill();
    g.save(); g.beginPath(); g.arc(0, 0, r, 0, TAU); g.clip();
    g.strokeStyle = css(hex(T.rimDark), 0.55); g.lineWidth = 1;
    var k;
    if (T.grain === 'wood') for (k = 0; k < 7; k++) { g.beginPath(); g.ellipse(r * 0.15, r * 0.1, r * (0.3 + k * 0.12), r * (0.2 + k * 0.1), 0.3, 0, TAU); g.stroke(); }
    else if (T.grain === 'strata') for (k = -4; k <= 4; k++) { g.beginPath(); g.moveTo(-r, k * r * 0.22 + rr() * 3); g.quadraticCurveTo(0, k * r * 0.22 - 4, r, k * r * 0.22 + rr() * 3); g.stroke(); }
    else if (T.grain === 'ice') { g.strokeStyle = 'rgba(255,255,255,0.7)'; for (k = 0; k < 5; k++) { var a = rr() * TAU; g.beginPath(); g.moveTo(0, 0); g.lineTo(Math.cos(a) * r, Math.sin(a) * r); g.stroke(); } }
    else if (T.grain === 'shell') for (k = 0; k < 12; k++) { var a2 = k / 12 * TAU; g.beginPath(); g.moveTo(Math.cos(a2) * r * 0.7, Math.sin(a2) * r * 0.7); g.lineTo(Math.cos(a2) * r, Math.sin(a2) * r); g.stroke(); }
    else if (T.grain === 'moss') { g.fillStyle = 'rgba(92,140,70,0.75)'; for (k = 0; k < 14; k++) { var a3 = rr() * TAU, d = r * (0.8 + rr() * 0.2); g.beginPath(); g.arc(Math.cos(a3) * d, Math.sin(a3) * d, 2 + rr() * 3, 0, TAU); g.fill(); } }
    else if (T.grain === 'obsidian') { g.strokeStyle = 'rgba(255,122,42,0.8)'; g.lineWidth = 1.2; for (k = 0; k < 3; k++) { var a4 = rr() * TAU; g.beginPath(); g.moveTo(Math.cos(a4) * r * 0.75, Math.sin(a4) * r * 0.75); g.lineTo(Math.cos(a4 + 0.3) * r, Math.sin(a4 + 0.3) * r); g.stroke(); } }
    g.restore();
    g.strokeStyle = css(hex(T.rimDark), 0.9); g.lineWidth = 1.5; g.beginPath(); g.arc(0, 0, r - 0.75, 0, TAU); g.stroke();
  }

  /**
   * One space tile centred at (x, y) with radius r: a drop shadow, the theme's rim, the kind's face (raised: lit upper
   * left, shadowed lower right), the kind's glyph in the ink that reads on that face, and the extra marks a node carries
   * (a warp exit's ring, a fork's signpost is drawn separately).
   * @returns {{ink:string, kind:string}}
   */
  function tile(g, x, y, r, node, theme) {
    var T = THEME[theme] || THEME.meadow, K = KIND[node.kind] || KIND.coin;
    g.save(); g.translate(x, y);
    g.fillStyle = 'rgba(0,0,0,0.28)'; g.beginPath(); g.ellipse(r * 0.12, r * 0.22, r * 1.02, r * 0.95, 0, 0, TAU); g.fill();
    rim(g, r, T, (node.id || 0) * 7919 + 13);
    var fr = r * 0.72, fg = g.createRadialGradient(-fr * 0.35, -fr * 0.4, fr * 0.1, 0, 0, fr * 1.05);
    fg.addColorStop(0, shade(K.face, 0.28)); fg.addColorStop(0.7, K.face); fg.addColorStop(1, shade(K.face, -0.22));
    g.fillStyle = fg; g.beginPath(); g.arc(0, 0, fr, 0, TAU); g.fill();
    g.strokeStyle = 'rgba(255,255,255,0.45)'; g.lineWidth = 1.4; g.beginPath(); g.arc(0, 0, fr - 1, Math.PI * 0.95, Math.PI * 1.75); g.stroke();
    g.strokeStyle = 'rgba(0,0,0,0.35)'; g.beginPath(); g.arc(0, 0, fr - 1, Math.PI * 1.95, Math.PI * 2.75); g.stroke();
    var ink = pickInk(K.face, INKS);
    g.save(); g.beginPath(); g.arc(0, 0, fr * 0.98, 0, TAU); g.clip();
    // glyphs that cut holes (destination-out) cut them on their OWN layer, never through the tile (Icon_Doctrine §22d)
    var lay = layerFor(Math.ceil(fr * 2) + 4);
    lay.g.clearRect(0, 0, lay.c.width, lay.c.height); lay.g.save(); lay.g.translate(lay.c.width / 2, lay.c.height / 2);
    GLYPH[node.kind](lay.g, fr * 0.92, ink);
    lay.g.restore();
    g.drawImage(lay.c, -lay.c.width / 2, -lay.c.height / 2);
    g.restore();
    if (node.warpExit) {                                     // the receiving end of a warp: a teal ring with a notch
      g.strokeStyle = KIND.warp.face; g.lineWidth = 3; g.beginPath(); g.arc(0, 0, r + 4, -Math.PI * 0.35, Math.PI * 1.45); g.stroke();
    }
    g.restore();
    return { ink: ink, kind: node.kind };
  }
  var LAYER = null;
  function layerFor(size) {
    if (!LAYER || LAYER.c.width < size) { var c = document.createElement('canvas'); c.width = c.height = size; LAYER = { c: c, g: c.getContext('2d') }; }
    return LAYER;
  }

  /** A signpost beside a fork: a post and two boards pointing down each route. */
  function signpost(g, x, y, a1, a2, T) {
    g.save(); g.translate(x, y);
    g.fillStyle = 'rgba(0,0,0,0.25)'; g.beginPath(); g.ellipse(3, 2, 9, 3, 0, 0, TAU); g.fill();
    g.fillStyle = '#6b4a2b'; g.fillRect(-2.5, -40, 5, 42);
    [a1, a2].forEach(function (a, i) {
      g.save(); g.translate(0, -34 + i * 11); g.rotate(Math.cos(a) >= 0 ? Math.atan2(Math.sin(a), Math.cos(a)) * 0.25 : Math.PI + Math.atan2(Math.sin(a), Math.cos(a)) * 0.25);
      g.fillStyle = i ? '#b98a55' : '#d2a46a'; g.strokeStyle = '#4a321b'; g.lineWidth = 1.2;
      g.beginPath(); g.moveTo(0, -4); g.lineTo(20, -4); g.lineTo(26, 0); g.lineTo(20, 4); g.lineTo(0, 4); g.closePath(); g.fill(); g.stroke();
      g.restore();
    });
    g.restore();
  }

  /** Bake every tile and signpost of a board onto ctx. Returns per-kind counts (for tests: a declared kind must draw). */
  function tiles(ctx, board) {
    var C = core(), counts = {};
    board.nodes.forEach(function (n) { tile(ctx, n.x, n.y, C.TILE_R, n, board.theme); counts[n.kind] = (counts[n.kind] || 0) + 1; });
    board.forks.forEach(function (f) {
      var A = board.nodes[f.at], n1 = board.nodes[A.next[0]], n2 = board.nodes[A.next[1]];
      signpost(ctx, A.x - 34, A.y - 6, Math.atan2(n1.y - A.y, n1.x - A.x), Math.atan2(n2.y - A.y, n2.x - A.x), THEME[board.theme]);
      counts.signpost = (counts.signpost || 0) + 1;
    });
    return counts;
  }

  /* ---------------------------------------------------------------- tokens and dice */

  /**
   * A racer's token: a turned wooden pawn in the racer's colour on a round base, a number on its collar, and (if the
   * scene passes one) a face medallion drawn by `faceFn(g, x, y, radius)` above it.
   */
  function token(g, x, y, s, idx, faceFn, label) {
    var col = RACER[idx % RACER.length];
    g.save(); g.translate(x, y);
    g.fillStyle = 'rgba(0,0,0,0.3)'; g.beginPath(); g.ellipse(2, 2, s * 0.5, s * 0.18, 0, 0, TAU); g.fill();
    var body = g.createLinearGradient(-s * 0.4, 0, s * 0.4, 0); body.addColorStop(0, shade(col, 0.3)); body.addColorStop(0.55, col); body.addColorStop(1, shade(col, -0.35));
    g.fillStyle = body; g.strokeStyle = shade(col, -0.55); g.lineWidth = 1.2;
    g.beginPath(); g.ellipse(0, 0, s * 0.46, s * 0.16, 0, 0, TAU); g.fill(); g.stroke();
    g.beginPath(); g.moveTo(-s * 0.36, -s * 0.06); g.quadraticCurveTo(-s * 0.12, -s * 0.4, -s * 0.16, -s * 0.72); g.lineTo(s * 0.16, -s * 0.72); g.quadraticCurveTo(s * 0.12, -s * 0.4, s * 0.36, -s * 0.06); g.closePath(); g.fill(); g.stroke();
    g.beginPath(); g.ellipse(0, -s * 0.74, s * 0.24, s * 0.07, 0, 0, TAU); g.fill(); g.stroke();
    g.beginPath(); g.arc(0, -s * 0.98, s * 0.22, 0, TAU); g.fill(); g.stroke();
    g.fillStyle = 'rgba(255,255,255,0.45)'; g.beginPath(); g.arc(-s * 0.07, -s * 1.05, s * 0.07, 0, TAU); g.fill();
    if (label) { g.fillStyle = pickInk(col, INKS); g.font = '700 ' + Math.round(s * 0.26) + 'px ' + FONT; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(label, 0, -s * 0.38); }
    if (faceFn) {
      var fy = -s * 1.62, fr2 = s * 0.42;
      g.fillStyle = shade(col, -0.45); g.beginPath(); g.moveTo(-3, fy + fr2); g.lineTo(0, -s * 1.18); g.lineTo(3, fy + fr2); g.fill();
      g.fillStyle = '#f7efe0'; g.beginPath(); g.arc(0, fy, fr2 + 3, 0, TAU); g.fill();
      g.save(); g.beginPath(); g.arc(0, fy, fr2, 0, TAU); g.clip(); faceFn(g, 0, fy, fr2); g.restore();
      g.strokeStyle = col; g.lineWidth = 2.5; g.beginPath(); g.arc(0, fy, fr2 + 1.5, 0, TAU); g.stroke();
    }
    g.restore();
  }

  /** A large die for the roll: ivory face with drawn pips, a top and side face for depth. */
  function bigDie(g, x, y, s, pips, tilt) {
    g.save(); g.translate(x, y); g.rotate(tilt || 0);
    var h = s / 2, d = s * 0.18;
    g.fillStyle = 'rgba(0,0,0,0.3)'; g.beginPath(); g.ellipse(d * 0.6, h + d * 0.6, h * 1.05, h * 0.28, 0, 0, TAU); g.fill();
    g.fillStyle = '#d9cdb6'; g.beginPath(); g.moveTo(-h, -h); g.lineTo(-h + d, -h - d); g.lineTo(h + d, -h - d); g.lineTo(h, -h); g.closePath(); g.fill();
    g.fillStyle = '#bfb197'; g.beginPath(); g.moveTo(h, -h); g.lineTo(h + d, -h - d); g.lineTo(h + d, h - d); g.lineTo(h, h); g.closePath(); g.fill();
    die(g, 0, 0, s, 0, '#2a1d14', pips, '#f6efe1');
    g.restore();
  }

  /* ---------------------------------------------------------------- plates (HUD) */

  /** A paper plate with an inked border (the HUD's furniture). */
  function plate(g, x, y, w, h, opts) {
    opts = opts || {};
    g.save();
    g.fillStyle = 'rgba(0,0,0,0.3)'; roundRect(g, x + 3, y + 4, w, h, 10); g.fill();
    var pg = g.createLinearGradient(0, y, 0, y + h); pg.addColorStop(0, opts.paper || '#f4ead4'); pg.addColorStop(1, shade(opts.paper || '#f4ead4', -0.08));
    g.fillStyle = pg; roundRect(g, x, y, w, h, 10); g.fill();
    g.strokeStyle = opts.ink || '#4a321b'; g.lineWidth = 2; roundRect(g, x + 1, y + 1, w - 2, h - 2, 9); g.stroke();
    g.strokeStyle = css(hex(opts.ink || '#4a321b'), 0.35); g.lineWidth = 1; roundRect(g, x + 5, y + 5, w - 10, h - 10, 6); g.stroke();
    g.restore();
  }
  function roundRect(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
  function text(g, s, x, y, size, color, align, weight) {
    g.font = (weight || '700') + ' ' + size + 'px ' + FONT; g.fillStyle = color || '#2a1d14'; g.textAlign = align || 'left'; g.textBaseline = 'middle'; g.fillText(s, x, y);
  }
  /** A small coin icon for the HUD. */
  function coinIcon(g, x, y, s) {
    g.save(); g.translate(x, y);
    var cg = g.createRadialGradient(-s * 0.3, -s * 0.3, 1, 0, 0, s); cg.addColorStop(0, '#fff1a8'); cg.addColorStop(1, '#c9921f');
    g.fillStyle = cg; g.beginPath(); g.arc(0, 0, s, 0, TAU); g.fill(); g.strokeStyle = '#8a5d10'; g.lineWidth = 1.2; g.stroke();
    star(g, 0, 0, s * 0.5, '#8a5d10'); g.restore();
  }

  return {
    VERSION: '1.0.0', FONT: FONT, THEME: THEME, KIND: KIND, RACER: RACER, INKS: INKS, GLYPH: GLYPH,
    hex: hex, shade: shade, lum: lum, contrast: contrast, pickInk: pickInk,
    landscape: landscape, ground: ground, decor: decor, trail: trail, tiles: tiles, tile: tile, signpost: signpost,
    token: token, bigDie: bigDie, die: die, plate: plate, roundRect: roundRect, text: text, coinIcon: coinIcon, star: star,
  };
}(typeof window !== 'undefined' ? window : globalThis));

if (typeof module !== 'undefined' && module.exports) module.exports = GooseDraw;
