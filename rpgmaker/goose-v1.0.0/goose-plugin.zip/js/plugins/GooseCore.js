//=============================================================================
// GooseCore.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [v1.0.0] Goose 1/3 - the rules: generated boards, the race, the rivals. No engine code.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * The rules for Goose. No parameters or commands of its own; Goose.js is the
 * file you configure.
 *
 * Pure logic: nothing here touches the screen and nothing uses Math.random.
 * A board is a seed: the same seed lays out the same trail, forks and spaces
 * on every machine. A race is a seed too, so the same race replays the same
 * dice.
 *
 * Terms: commercial and non-commercial use in RPG Maker projects. Written
 * with AI assistance.
 */

var GooseCore = (function () {
  'use strict';

  var TILE_R = 26;                 // a space tile's radius in world pixels
  var MIN_GAP = TILE_R * 2 + 12;   // the closest two space centres may be (tile + a strip of ground)
  var SPACING = 104;               // target distance between neighbouring spaces along the trail
  var ROW_H = 300;                 // distance between the trail's rows (room for a detour either side)
  var MARGIN = 150;                // world margin around the trail
  var MIN_LEN = 24, MAX_LEN = 60;
  var THEMES = ['meadow', 'desert', 'snowfield', 'coast', 'forest', 'volcano'];
  var THEME_NAMES = { meadow: 'Meadow Trail', desert: 'Dune Road', snowfield: 'Snowfield Run', coast: 'Coast Path', forest: 'Forest Way', volcano: 'Ember Pass' };
  var KINDS = ['start', 'goal', 'coin', 'loss', 'chest', 'event', 'warp', 'again', 'snare', 'gust', 'boost'];
  var HAZARD = { loss: 1, snare: 1, gust: 1 };
  var COINS = { coin: 3, loss: -3 };
  var CHEST_MIN = 5, CHEST_MAX = 10;
  var MOVE_MIN = 2, MOVE_MAX = 4;  // gust and boost distance
  var TEMPERS = ['bold', 'steady', 'canny'];
  // The plain trail is filled from this MIX by a shuffled enumeration (wing §21g: never per-space independent draws,
  // whose tail always holds a degenerate run). Coins fill whatever the rounded counts leave.
  var MIX = { loss: 0.12, again: 0.08, snare: 0.07, gust: 0.07, boost: 0.08, chest: 0.05 };

  /* ---------------------------------------------------------------- seeds */

  /** FNV-1a over a string: a stable seed from text. */
  function hashString(str) {
    var h = 2166136261, s = String(str);
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
  }
  /** Mix two 32-bit values into one seed. */
  function mix(a, b) {
    var h = Math.imul((a >>> 0) ^ 0x9E3779B9, 0x85EBCA6B) ^ Math.imul((b >>> 0) + 0x632BE5AB, 0xC2B2AE35);
    h ^= h >>> 15; h = Math.imul(h, 0x2C1B3C6D); h ^= h >>> 12;
    return h >>> 0;
  }
  /** mulberry32 as a closure: for generation, where nothing needs to be saved mid-way. */
  function rng(seed) {
    var a = (seed >>> 0) || 1;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  /** mulberry32 on a SAVED state field, so a race in progress can be saved and resumed with the same dice. */
  function draw(state) {
    state.r = (state.r + 0x6D2B79F5) >>> 0;
    var t = state.r;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  function pick(r, arr) { return arr[Math.floor(r() * arr.length)]; }
  function shuffle(r, a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(r() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function clampInt(v, lo, hi, d) { var n = Math.floor(Number(v)); return isFinite(n) ? Math.max(lo, Math.min(hi, n)) : d; }

  /* ---------------------------------------------------------------- the trail */

  /**
   * The serpentine centreline: `rows` straight runs joined by half-turns, sized so `length` spaces sit about
   * SPACING apart. Returns a dense polyline of {x, y, s (arc length), row, turn}.
   */
  function centreline(length, r) {
    var arc = (length - 1) * SPACING, rows = 2, wr = (arc - Math.PI * ROW_H / 2) / 2;
    while (wr > 1500 && rows < 6) { rows++; wr = (arc - (rows - 1) * Math.PI * ROW_H / 2) / rows; }
    wr = Math.max(560, wr);
    // the half-turns bulge ROW_H/2 beyond the straight runs: the runs start that far in, or the turn spaces sit on the
    // world's edge half cut off (2026-10-08, seen on the board contact sheet)
    var X0 = MARGIN + ROW_H / 2;
    var W = Math.round(wr + MARGIN * 2 + ROW_H), H = Math.round((rows - 1) * ROW_H + MARGIN * 2);
    var amp = 10 + r() * 16, freq = 1 + Math.floor(r() * 2), phase = r() * Math.PI * 2;
    var pts = [], s = 0, last = null, STEP = 4;
    function push(x, y, row, turn) {
      if (last) s += Math.sqrt((x - last.x) * (x - last.x) + (y - last.y) * (y - last.y));
      last = { x: x, y: y, s: s, row: row, turn: turn }; pts.push(last);
    }
    for (var i = 0; i < rows; i++) {
      var y0 = MARGIN + i * ROW_H, ltr = i % 2 === 0, n = Math.ceil(wr / STEP);
      for (var k = 0; k <= n; k++) {
        var u = k / n, x = ltr ? X0 + u * wr : X0 + wr - u * wr;
        push(x, y0 + amp * Math.sin(phase + i * 1.7 + u * Math.PI * 2 * freq) * Math.sin(u * Math.PI), i, false);
      }
      if (i < rows - 1) {                                       // half-turn to the next row
        var cx = ltr ? X0 + wr : X0, cy = y0 + ROW_H / 2, rad = ROW_H / 2, m = Math.ceil(Math.PI * rad / STEP);
        for (var j = 1; j < m; j++) {
          var a = -Math.PI / 2 + Math.PI * j / m;
          push(ltr ? cx + Math.cos(a) * rad : cx - Math.cos(a) * rad, cy + Math.sin(a) * rad, i, true);
        }
      }
    }
    return { pts: pts, total: s, W: W, H: H, rows: rows };
  }
  function pointAt(line, s) {
    var p = line.pts, lo = 0, hi = p.length - 1;
    while (hi - lo > 1) { var mid = (lo + hi) >> 1; if (p[mid].s <= s) lo = mid; else hi = mid; }
    var a = p[lo], b = p[hi], t = b.s > a.s ? (s - a.s) / (b.s - a.s) : 0;
    return { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t, row: t < 0.5 ? a.row : b.row, turn: a.turn || b.turn };
  }
  function dist(a, b) { return Math.sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y)); }
  /** The quadratic curve of a detour from A to B bowing by h along the normal; m spaces at equal arc length. */
  function detourPoints(A, B, h, m) {
    var dx = B.x - A.x, dy = B.y - A.y, L = Math.sqrt(dx * dx + dy * dy) || 1, nx = -dy / L, ny = dx / L;
    var C = { x: (A.x + B.x) / 2 + nx * h * 2, y: (A.y + B.y) / 2 + ny * h * 2 };   // control point: the apex sits at h
    var N = 200, acc = [0], prev = A, i;
    function q(t) { var u = 1 - t; return { x: u * u * A.x + 2 * u * t * C.x + t * t * B.x, y: u * u * A.y + 2 * u * t * C.y + t * t * B.y }; }
    for (i = 1; i <= N; i++) { var p = q(i / N); acc.push(acc[i - 1] + dist(prev, p)); prev = p; }
    var out = [], total = acc[N];
    for (var k = 1; k <= m; k++) {
      var want = total * k / (m + 1), j = 1;
      while (j < N && acc[j] < want) j++;
      var t0 = (j - 1) / N, t1 = j / N, f = acc[j] > acc[j - 1] ? (want - acc[j - 1]) / (acc[j] - acc[j - 1]) : 0;
      out.push(q(t0 + (t1 - t0) * f));
    }
    return { pts: out, length: total, apex: q(0.5) };
  }

  /* ---------------------------------------------------------------- the board */

  /**
   * Generate a board.
   * @param {number} seed
   * @param {{length?:number, forks?:number, theme?:string, eventIds?:number[], warps?:boolean}} [opts]
   * @returns {{v:number, seed:number, theme:string, name:string, W:number, H:number, start:number, goal:number,
   *   nodes:Array<{id:number,kind:string,next:number[],x:number,y:number,route:string,fork:boolean,pair?:number,
   *   warpExit?:boolean,eventId?:number,move?:number,chest?:number}>, forks:Array, attempts:number}}
   */
  function makeBoard(seed, opts) {
    opts = opts || {};
    var length = clampInt(opts.length, MIN_LEN, MAX_LEN, 40);
    var wantForks = clampInt(opts.forks, 0, 3, length >= 36 ? 2 : 1);
    var theme = THEMES.indexOf(opts.theme) >= 0 ? opts.theme : null;
    var eventIds = (opts.eventIds || []).map(Number).filter(function (n) { return n > 0 && isFinite(n); }).slice(0, 6);
    var r = rng(mix(seed >>> 0, 0x60053));
    if (!theme) theme = pick(r, THEMES);
    var line = centreline(length, r), nodes = [], i;
    var step = line.total / (length - 1);
    for (i = 0; i < length; i++) {
      var p = pointAt(line, Math.min(line.total, i * step));
      nodes.push({ id: i, kind: 'coin', next: i < length - 1 ? [i + 1] : [], x: Math.round(p.x), y: Math.round(p.y), row: p.row, turn: p.turn, route: 'trail', fork: false });
    }
    nodes[0].kind = 'start'; nodes[length - 1].kind = 'goal';

    // ---- forks: a detour from main node a that rejoins at b, both on the same straight run
    var forks = [], attempts = 0, taken = {};
    var cands = [];
    for (var a = 2; a < length - 6; a++) for (var k = 4; k <= 7; k++) {
      var b = a + k; if (b > length - 3) continue;
      var ok = true;
      for (i = a; i <= b; i++) if (nodes[i].turn || nodes[i].row !== nodes[a].row) { ok = false; break; }
      if (ok) cands.push([a, b]);
    }
    shuffle(r, cands);
    for (var c = 0; c < cands.length && forks.length < wantForks; c++) {
      var A = cands[c][0], B = cands[c][1], free = true;
      for (i = A - 2; i <= B + 2; i++) if (taken[i]) { free = false; break; }
      if (!free) continue;
      var kk = B - A, shortcut = r() < 0.5;
      var m = shortcut ? Math.max(1, Math.round((kk - 1) * 0.45)) : kk - 1 + 2 + Math.floor(r() * 2);
      var sign = r() < 0.5 ? 1 : -1, placed = null;
      for (var tryBow = 0; tryBow < 6 && !placed; tryBow++) {
        attempts++;
        if (tryBow === 3) sign = -sign;                 // three tries on one side, then three on the other
        // the bow never reaches the next row (ROW_H): capped at 0.45 of it whatever the chord
        var chord = dist(nodes[A], nodes[B]), h = sign * Math.min(ROW_H * 0.45, chord * (shortcut ? 0.22 : 0.42) * (1 + (tryBow % 3) * 0.12));
        var d = detourPoints(nodes[A], nodes[B], h, m), clear = true;
        for (var q = 0; q < d.pts.length && clear; q++) {
          var P = d.pts[q];
          if (P.x < TILE_R + 8 || P.y < TILE_R + 8 || P.x > line.W - TILE_R - 8 || P.y > line.H - TILE_R - 8) clear = false;
          // +2: positions are rounded to whole pixels afterwards, which can close a gap by up to 1.5 px
          // (2026-10-08: a pair placed at 64.4 px validated at 64 against a 64 px floor)
          for (i = 0; i < nodes.length && clear; i++) if (dist(P, nodes[i]) < MIN_GAP + 2) clear = false;
          if (q > 0 && dist(P, d.pts[q - 1]) < MIN_GAP + 2) clear = false;
        }
        if (clear) placed = d;
      }
      if (!placed) continue;
      var ids = [];
      for (var q2 = 0; q2 < placed.pts.length; q2++) {
        var id = nodes.length;
        nodes.push({ id: id, kind: 'coin', next: [], x: Math.round(placed.pts[q2].x), y: Math.round(placed.pts[q2].y), row: nodes[A].row, turn: false, route: shortcut ? 'shortcut' : 'scenic', fork: false });
        ids.push(id);
      }
      for (q2 = 0; q2 < ids.length; q2++) nodes[ids[q2]].next = [q2 < ids.length - 1 ? ids[q2 + 1] : B];
      nodes[A].next = [A + 1, ids[0]];
      nodes[A].fork = true; nodes[B].join = true;
      for (i = A + 1; i < B; i++) nodes[i].route = shortcut ? 'scenic' : 'shortcut';   // the main run is the OTHER route
      for (i = A - 2; i <= B + 2; i++) taken[i] = true;
      forks.push({ at: A, rejoin: B, detour: ids, detourIs: shortcut ? 'shortcut' : 'scenic', mainSteps: kk, detourSteps: ids.length + 1, bow: placed.apex });
    }
    forks.sort(function (x, y) { return x.at - y.at; });

    // ---- kinds. Routes inside a fork get their character; the open trail gets the shuffled MIX.
    function routeIds(f, which) { var out = [], i2; if ((f.detourIs === which)) return f.detour.slice(); for (i2 = f.at + 1; i2 < f.rejoin; i2++) out.push(i2); return out; }
    for (var fi = 0; fi < forks.length; fi++) {
      var f = forks[fi], sc = routeIds(f, 'shortcut'), sn = routeIds(f, 'scenic');
      // the shortcut: at least half its spaces are hazards, the rest an "again" or a boost; never a coin
      var bagS = []; for (i = 0; i < sc.length; i++) bagS.push(i % 2 === 0 ? pick(r, ['snare', 'gust', 'loss']) : pick(r, ['again', 'boost', 'loss']));
      shuffle(r, bagS); for (i = 0; i < sc.length; i++) nodes[sc[i]].kind = bagS[i];
      // the scenic route: coins, and one chest
      for (i = 0; i < sn.length; i++) nodes[sn[i]].kind = 'coin';
      nodes[sn[Math.floor(r() * sn.length)]].kind = 'chest';
    }
    var open = [];
    for (i = 1; i < length - 1; i++) if (nodes[i].route === 'trail' && !nodes[i].fork && !nodes[i].join) open.push(i);
    // warps: a forward pair always (from 28 spaces), a backward pair from 44, mouths on the open trail only
    var warps = [];
    function freeCoin(n) { return n > 1 && n < length - 2 && open.indexOf(n) >= 0 && nodes[n].kind === 'coin' && !nodes[n].warpExit; }
    function placeWarp(lo, hi, jumpLo, jumpHi) {
      var mouths = open.filter(function (n) { return n >= lo && n <= hi; }), jumps = [];
      for (var jv = jumpLo; jv <= jumpHi; jv++) jumps.push(jv);
      shuffle(r, mouths);
      for (var w = 0; w < mouths.length; w++) {
        shuffle(r, jumps);
        for (var jj = 0; jj < jumps.length; jj++) {
          var mth = mouths[w], ex = mth + jumps[jj];
          // a mouth is never another warp's exit, an exit never a mouth: no chains, no loops (2026-10-08: the
          // backward pair once opened on the forward pair's exit)
          if (!freeCoin(mth) || !freeCoin(ex)) continue;
          nodes[mth].kind = 'warp'; nodes[mth].pair = ex; nodes[ex].warpExit = true; nodes[ex].pairOf = mth;
          warps.push({ mouth: mth, exit: ex });
          return true;
        }
      }
      return false;
    }
    if (opts.warps !== false && length >= 28) placeWarp(Math.floor(length * 0.18), Math.floor(length * 0.5), 7, 11) || placeWarp(2, Math.floor(length * 0.7), 5, 11);
    if (opts.warps !== false && length >= 44) placeWarp(Math.floor(length * 0.6), Math.floor(length * 0.85), -9, -6) || placeWarp(Math.floor(length * 0.4), length - 3, -9, -5);
    var plain = open.filter(function (n) { return nodes[n].kind === 'coin' && !nodes[n].warpExit; });
    // events: one space per configured common event, spread evenly along the open trail
    var events = [];
    for (var e = 0; e < eventIds.length && plain.length; e++) {
      var at = plain[Math.min(plain.length - 1, Math.floor((e + 0.5) * plain.length / eventIds.length))];
      if (nodes[at].kind !== 'coin') continue;
      nodes[at].kind = 'event'; nodes[at].eventId = eventIds[e]; events.push(at);
    }
    plain = plain.filter(function (n) { return nodes[n].kind === 'coin'; });
    var bag = [];
    Object.keys(MIX).forEach(function (kd) { for (var c2 = Math.round(MIX[kd] * plain.length); c2 > 0; c2--) bag.push(kd); });
    while (bag.length < plain.length) bag.push('coin');
    bag.length = plain.length;
    shuffle(r, bag);
    // repair, in trail order: no hazard right after another hazard or the start. The kind BEFORE a space is the bag's
    // (already final, we walk forward) when that space is plain too, else the node's own fixed kind. A hazard that
    // must move swaps with the next non-hazard further on (checked again when the walk reaches it); none left -> coin.
    for (i = 0; i < plain.length; i++) {
      var p0 = plain[i] - 1, prevKind = (i > 0 && plain[i - 1] === p0) ? bag[i - 1] : nodes[p0].kind;
      if (!HAZARD[bag[i]] || !(HAZARD[prevKind] || prevKind === 'start')) continue;
      var j2 = i + 1;
      while (j2 < plain.length && HAZARD[bag[j2]]) j2++;
      if (j2 < plain.length) { var tmp = bag[j2]; bag[j2] = bag[i]; bag[i] = tmp; } else bag[i] = 'coin';
    }
    for (i = 0; i < plain.length; i++) nodes[plain[i]].kind = bag[i];
    // fixed amounts, chosen now so the board is the whole record of what a space does
    for (i = 0; i < nodes.length; i++) {
      var nd = nodes[i];
      if (nd.kind === 'gust' || nd.kind === 'boost') nd.move = MOVE_MIN + Math.floor(r() * (MOVE_MAX - MOVE_MIN + 1));
      if (nd.kind === 'chest') nd.chest = CHEST_MIN + Math.floor(r() * (CHEST_MAX - CHEST_MIN + 1));
    }
    return { v: 1, seed: seed >>> 0, theme: theme, name: THEME_NAMES[theme], W: line.W, H: line.H, rows: line.rows, length: length,
      start: 0, goal: length - 1, nodes: nodes, forks: forks, warps: warps, events: events, attempts: attempts };
  }

  /* ---------------------------------------------------------------- reading a board */

  /** Fewest moves from every node to the goal, along the trail's edges (warps excluded: they are jumps). */
  function distToGoal(board) {
    var n = board.nodes.length, d = new Array(n), changed = true, i, k;
    for (i = 0; i < n; i++) d[i] = Infinity;
    d[board.goal] = 0;
    while (changed) {
      changed = false;
      for (i = 0; i < n; i++) for (k = 0; k < board.nodes[i].next.length; k++) {
        var v = d[board.nodes[i].next[k]] + 1;
        if (v < d[i]) { d[i] = v; changed = true; }
      }
    }
    return d;
  }
  /** Structural checks a generated board must pass. Returns the problems found (empty = sound). */
  function validate(board) {
    var problems = [], nodes = board.nodes, d = distToGoal(board), i, k;
    for (i = 0; i < nodes.length; i++) {
      var nd = nodes[i];
      if (KINDS.indexOf(nd.kind) < 0) problems.push('node ' + i + ' has unknown kind ' + nd.kind);
      if (i !== board.goal && nd.next.length === 0) problems.push('dead end at ' + i);
      if (!isFinite(d[i])) problems.push('goal unreachable from ' + i);
      for (k = 0; k < nd.next.length; k++) if (!(nd.next[k] >= 0 && nd.next[k] < nodes.length)) problems.push('bad edge ' + i + '->' + nd.next[k]);
      if (nd.kind === 'warp' && (nodes[nd.pair] == null || nodes[nd.pair].kind === 'warp')) problems.push('warp ' + i + ' has no proper exit');
      if (nd.kind === 'event' && !(nd.eventId > 0)) problems.push('event space ' + i + ' has no common event');
      for (k = i + 1; k < nodes.length; k++) if (dist(nd, nodes[k]) < MIN_GAP) problems.push('spaces ' + i + ' and ' + k + ' overlap (' + Math.round(dist(nd, nodes[k])) + ' px)');
    }
    // acyclic along edges: a walk can never return to a node it left
    var state = new Array(nodes.length);
    function visit(u) { if (state[u] === 1) return true; if (state[u] === 2) return false; state[u] = 1; for (var j = 0; j < nodes[u].next.length; j++) if (visit(nodes[u].next[j])) return true; state[u] = 2; return false; }
    if (visit(board.start)) problems.push('the trail has a cycle');
    if (nodes[board.start].kind !== 'start' || nodes[board.goal].kind !== 'goal') problems.push('start/goal kinds wrong');
    return problems;
  }
  /** Coins a route is worth on average (coin +3, loss -3, chest its amount), from node `from` until it reaches `until`. */
  function routeValue(board, from, until) {
    var v = 0, steps = 0, at = from, guard = 0;
    while (at !== until && guard++ < 200) {
      var nd = board.nodes[at];
      if (nd.kind === 'coin') v += COINS.coin; else if (nd.kind === 'loss') v += COINS.loss; else if (nd.kind === 'chest') v += nd.chest || 0;
      else if (nd.kind === 'snare') v -= 4; else if (nd.kind === 'gust') v -= (nd.move || 3) * 1.2;
      steps++; at = nd.next[0];
    }
    return { coins: v, steps: steps };
  }

  /* ---------------------------------------------------------------- the race */

  /**
   * A race on a board. `racers` = [{name, ai:'player'|'bold'|'steady'|'canny', coins?}]. Plain JSON: save it as it is.
   * @param {Object} board
   * @param {Array} racers
   * @param {number} seed
   * @param {{dice?:number, maxTurns?:number, startCoins?:number}} [opts]
   */
  function createRace(board, racers, seed, opts) {
    opts = opts || {};
    var rs = racers.map(function (x, i) {
      return { name: String(x.name || ('Racer ' + (i + 1))), ai: TEMPERS.indexOf(x.ai) >= 0 ? x.ai : (x.ai === 'player' ? 'player' : 'steady'),
        at: board.start, coins: clampInt(x.coins != null ? x.coins : opts.startCoins, 0, 9999, 0), skip: false, finished: false, finishTurn: null, path: [board.start], token: i };
    });
    return { v: 1, seed: seed >>> 0, r: mix(seed >>> 0, 0xD1CE) >>> 0, dice: clampInt(opts.dice, 1, 2, 1), maxTurns: clampInt(opts.maxTurns, 5, 99, 40),
      turn: 1, current: 0, phase: 'roll', steps: 0, rolled: 0, againUsed: false, racers: rs, order: [], last: null };
  }
  function cur(state) { return state.racers[state.current]; }

  /** Roll for the current racer. A snared racer's roll is 0 and its turn ends (phase 'end'). */
  function roll(state) {
    var rc = cur(state);
    if (state.phase !== 'roll') throw new Error('Goose: roll() in phase ' + state.phase);
    if (rc.skip) { rc.skip = false; state.rolled = 0; state.steps = 0; state.phase = 'end'; state.last = { kind: 'skipped', racer: state.current }; return 0; }
    var v = 0; state.faces = [];
    for (var i = 0; i < state.dice; i++) { var f = 1 + Math.floor(draw(state) * 6); state.faces.push(f); v += f; }   // each die's face, for the scene to show
    state.rolled = v; state.steps = v; state.phase = 'move';
    return v;
  }
  /** The routes open to the current racer at its node (more than one = a fork to choose at). */
  function options(state, board) { return board.nodes[cur(state).at].next.slice(); }

  /**
   * What a rival chooses at a fork. bold: always the shortcut. steady: always the scenic route. canny: the scenic route
   * while it is in touch with the leader, the shortcut once it trails by CANNY_GAP moves or more.
   * MEASURED 2026-10-08 (_probe/balance_probe.js, 2 seed sets x 1,500 races x 3 lengths, seats rotated): with the first
   * third temperament ("greedy", coins per step) the rivals read bold 46% / steady 27% / greedy 27% wins and steady and
   * greedy ended with the same coins: greedy WAS steady, so it was replaced by canny. With canny (same probe, same
   * sets): wins bold 41-46% / canny 29-33% / steady 24-27%, mean coins on a 40-space board bold 12.9 / canny 18.4 /
   * steady 23.0 - three different players. A lone racer taking the shortcut finished sooner 58% of the time and ended
   * richer 10%: the fork is a race-or-coins decision, not a free one. Rounds (4 racers): 24 spaces median 8, 40 median
   * 13, 60 median 20.
   */
  var CANNY_GAP = 4;
  function aiChoice(state, board, racer) {
    var nd = board.nodes[racer.at];
    if (nd.next.length < 2) return nd.next[0];
    var f = null;
    for (var i = 0; i < board.forks.length; i++) if (board.forks[i].at === racer.at) { f = board.forks[i]; break; }
    var shortFirst = f && f.detourIs === 'shortcut' ? nd.next[1] : nd.next[0], scenicFirst = shortFirst === nd.next[0] ? nd.next[1] : nd.next[0];
    if (racer.ai === 'bold') return shortFirst;
    if (racer.ai !== 'canny') return scenicFirst;
    var d = distToGoal(board), mine = d[racer.at], best = Infinity;
    for (var k = 0; k < state.racers.length; k++) best = Math.min(best, state.racers[k].finished ? 0 : d[state.racers[k].at]);
    return mine - best >= CANNY_GAP ? shortFirst : scenicFirst;
  }

  /**
   * Move the current racer one space. At a fork the player must pass `choice` (a node id from options());
   * without one, returns {needChoice:true, options}. A rival chooses for itself.
   * @returns {{from:number, to:number, needChoice?:boolean, options?:number[], finished?:boolean}}
   */
  function stepOne(state, board, choice) {
    if (state.phase !== 'move') throw new Error('Goose: stepOne() in phase ' + state.phase);
    var rc = cur(state), nd = board.nodes[rc.at], to;
    if (nd.next.length > 1) {
      if (choice != null && nd.next.indexOf(Number(choice)) >= 0) to = Number(choice);
      else if (rc.ai === 'player') return { from: rc.at, to: rc.at, needChoice: true, options: nd.next.slice() };
      else to = aiChoice(state, board, rc);
    } else to = nd.next[0];
    var from = rc.at;
    rc.at = to; rc.path.push(to); state.steps--;
    if (to === board.goal) {
      rc.finished = true; rc.finishTurn = state.turn; state.order.push(state.current); state.steps = 0; state.phase = 'end';
      state.last = { kind: 'finish', racer: state.current, place: state.order.length };
      return { from: from, to: to, finished: true };
    }
    if (state.steps <= 0) state.phase = 'land';
    return { from: from, to: to };
  }

  /**
   * Resolve the space the current racer stopped on. Returns what happened, for the scene to show:
   * {kind, coins (change), to (a node moved to), again, skip, eventId}. Moving effects (warp, gust, boost) do not
   * resolve the space they arrive on (no chains), except that reaching the goal finishes the racer.
   */
  function land(state, board) {
    if (state.phase !== 'land') throw new Error('Goose: land() in phase ' + state.phase);
    var rc = cur(state), nd = board.nodes[rc.at], fx = { kind: nd.kind, racer: state.current, at: rc.at, coins: 0 };
    state.phase = 'end';
    if (nd.kind === 'coin' || nd.kind === 'loss') { fx.coins = Math.max(-rc.coins, COINS[nd.kind]); rc.coins += fx.coins; }
    else if (nd.kind === 'chest') { fx.coins = nd.chest || CHEST_MIN; rc.coins += fx.coins; }
    else if (nd.kind === 'event') { fx.eventId = nd.eventId; }
    else if (nd.kind === 'warp') { rc.at = nd.pair; rc.path.push(nd.pair); fx.to = nd.pair; }
    else if (nd.kind === 'again') { if (!state.againUsed) { state.againUsed = true; state.phase = 'roll'; fx.again = true; } }
    else if (nd.kind === 'snare') { rc.skip = true; fx.skip = true; }
    else if (nd.kind === 'gust') {                          // blown back along the path the racer actually walked
      var back = Math.min(nd.move || MOVE_MIN, rc.path.length - 1);
      for (var b = 0; b < back; b++) rc.path.pop();
      rc.at = rc.path[rc.path.length - 1]; fx.to = rc.at; fx.back = back;
    } else if (nd.kind === 'boost') {                       // forward, a rival choosing at forks, the player too (first route)
      var n = nd.move || MOVE_MIN, at = rc.at;
      for (var s = 0; s < n && at !== board.goal; s++) { at = board.nodes[at].next.length > 1 ? (rc.ai === 'player' ? board.nodes[at].next[0] : aiChoice(state, board, { ai: rc.ai, at: at })) : board.nodes[at].next[0]; rc.path.push(at); }
      rc.at = at; fx.to = at; fx.forward = n;
      if (at === board.goal) { rc.finished = true; rc.finishTurn = state.turn; state.order.push(state.current); fx.finished = true; }
    }
    state.last = fx;
    return fx;
  }

  /** Hand the dice to the next racer still running; close the race when it is over. Returns the new phase. */
  function endTurn(state) {
    if (state.phase !== 'end') throw new Error('Goose: endTurn() in phase ' + state.phase);
    state.againUsed = false;
    var n = state.racers.length, player = -1, i;
    for (i = 0; i < n; i++) if (state.racers[i].ai === 'player') player = i;
    var allDone = state.racers.every(function (x) { return x.finished; });
    if (allDone || (player >= 0 && state.racers[player].finished)) { state.phase = 'done'; return state.phase; }
    var wrapped = false;
    for (var k = 1; k <= n; k++) {
      if (state.current + k >= n) wrapped = true;       // passing the last seat starts a new round
      var nx = (state.current + k) % n;
      if (!state.racers[nx].finished) { state.current = nx; break; }
    }
    if (wrapped) state.turn++;
    if (state.turn > state.maxTurns) { state.phase = 'done'; return state.phase; }
    state.phase = 'roll';
    return state.phase;
  }

  /** Final places: finish order first, then fewest moves left to the goal, then coins. */
  function results(state, board) {
    var d = distToGoal(board), idx = state.racers.map(function (x, i) { return i; });
    idx.sort(function (a, b) {
      var fa = state.order.indexOf(a), fb = state.order.indexOf(b);
      if (fa >= 0 || fb >= 0) return (fa < 0 ? 99 : fa) - (fb < 0 ? 99 : fb);
      var da = d[state.racers[a].at], db = d[state.racers[b].at];
      if (da !== db) return da - db;
      return state.racers[b].coins - state.racers[a].coins || a - b;
    });
    return idx.map(function (i, p) { var x = state.racers[i]; return { racer: i, name: x.name, place: p + 1, coins: x.coins, finished: x.finished, left: d[x.at] }; });
  }

  /** Run a whole race with every racer choosing for itself (the player as 'steady'). For the balance probe and tests. */
  function simulate(board, racers, seed, opts) {
    var rs = racers.map(function (x) { return { name: x.name, ai: x.ai === 'player' ? 'steady' : x.ai, coins: x.coins }; });
    var st = createRace(board, rs, seed, opts), guard = 0;
    if (opts && opts.playerIndex != null) st.racers[opts.playerIndex].ai = 'player';
    while (st.phase !== 'done' && guard++ < 5000) {
      if (st.phase === 'roll') roll(st);
      while (st.phase === 'move') { var m = stepOne(st, board, null); if (m.needChoice) stepOne(st, board, aiChoice(st, board, { ai: 'steady', at: cur(st).at })); }
      if (st.phase === 'land') land(st, board);
      if (st.phase === 'end') endTurn(st);
    }
    return { state: st, results: results(st, board), turns: st.turn };
  }

  return {
    VERSION: '1.0.0', TILE_R: TILE_R, MIN_GAP: MIN_GAP, SPACING: SPACING, MIN_LEN: MIN_LEN, MAX_LEN: MAX_LEN,
    THEMES: THEMES, THEME_NAMES: THEME_NAMES, KINDS: KINDS, HAZARD: HAZARD, COINS: COINS, MIX: MIX, TEMPERS: TEMPERS,
    CHEST_MIN: CHEST_MIN, CHEST_MAX: CHEST_MAX, MOVE_MIN: MOVE_MIN, MOVE_MAX: MOVE_MAX,
    hashString: hashString, mix: mix, rng: rng, draw: draw,
    makeBoard: makeBoard, distToGoal: distToGoal, validate: validate, routeValue: routeValue,
    createRace: createRace, roll: roll, options: options, aiChoice: aiChoice, stepOne: stepOne, land: land, endTurn: endTurn,
    results: results, simulate: simulate,
  };
}());

if (typeof module !== 'undefined' && module.exports) module.exports = GooseCore;
