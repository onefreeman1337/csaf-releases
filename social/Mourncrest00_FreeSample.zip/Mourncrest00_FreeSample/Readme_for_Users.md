# Mourncrest 00 — The First Rung

**A free three-character way into the Mourncrest series.** Three of the common dead — a risen
gravedigger, a shambling villager and a bloated drowned corpse — a standing pose in each of four
directions, at **native 64x64.**

> ⚠️ **AI DISCLOSURE — read this first, because you deserve to decide with it in hand.**
> **The art in this pack is generated with an AI image model.** Every sprite was produced with
> **PixelLab**, a pixel-art diffusion model, on a paid plan that grants commercial rights, and then
> palette-locked and cut by tooling we wrote. The code in that pipeline was written with AI
> assistance too. The itch listing is tagged **Generative AI: Graphics = yes, Code = yes**. If you
> would rather not use AI-generated assets, please don't download this — no hard feelings, and
> thank you for reading this far.
>
> What we *can* offer instead of a claim about how it was made is a **mechanical proof of what you
> actually receive** — see below. Every number in it is re-derived from the decoded pixels of the
> exact files in this download, and you can re-run it yourself.

---

## What is in the box

| | |
| --- | --- |
| **Characters** | the sexton · the revenant · the drowned |
| **Directions** | south, west, east, north (4) |
| **Poses** | a standing (idle) pose in each direction |
| **Frames** | **12** distinct frames (3 characters x 4 directions) |
| **Grid size** | **64x64 — generated natively at that size, nothing upscaled** |
| **Palette** | **48 colours**, the Mourncrest series palette |
| **Files** | 15 PNGs, plus `pack.json` and `frames.json` |

Every frame ships as an individual PNG in `64x64/frames/`, and packed into a per-character sheet
in `64x64/sheets/` (row order down / left / right / up — RPG Maker character-sheet order).
`frames.json` gives every frame's exact `x, y, w, h`, so you can slice the sheets yourself if you
prefer.

---

## The cast

| | |
| --- | --- |
| **The Sexton** | The barrow's gravedigger, risen. He plants a broad iron shovel before him at rest. |
| **The Revenant** | A newly risen villager, its clothes rotting off in rags. |
| **The Drowned** | A corpse up from the marsh, swollen far wider than the living. |

---

## Why you can trust it is not slop

Every pack in this series ships a **mechanical consistency proof**, re-derived from the decoded
pixels of the exact files you are holding — not a claim about how the art was made:

- every opaque pixel falls inside the **48-colour** Mourncrest palette
- every frame is exactly **64x64** with strictly binary alpha — no stray anti-aliased edges
- **9,434** opaque pixels in the pack, counted, and you can re-run the count

Across the top-selling asset packs measured on itch, not one advertises palette conformance, grid
alignment or format integrity. A generated pack's real risk is that frame 40 will not match frame
1. This is the checkable answer to that.

---

## The full Mourncrest series

This is the entry rung. If it fits your game, the rest of the barrow is here:

- **Mourncrest 01: The Restless Dead** (also free) — six undead: skeleton, wraith, ghoul, wight,
  gravebound, bone-hound.
- **Mourncrest 02: The Pale Choir** — the cult that keeps the barrow.
- **Mourncrest 03: Beasts of the Barrow** — the vermin and worse.
- **Mourncrest 04: The Iron Wardens** — the order that hunts the dead.
- **The Mourncrest Collection** — all four paid packs together.

The paid packs also add **full walk-cycle animation**, a native **128x128** grid, ready-to-drop
**RPG Maker MZ** character sheets, and **Godot / Unity / GameMaker** import metadata. All of them
share this exact palette, so anything here stands beside anything there.

---

## Licence

Use in any project, personal or commercial, no royalty, no attribution required. Don't resell the
sprites themselves as an asset pack. Full terms in `LICENSE.txt`.
