extends Node2D
## Tidewater demo backdrop: a simple world drawn in code for each family, so refraction, reflection and the underwater
## filters have something to work on. Demo only; the pack does not need it.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

var mode := "surface"
var theme := {}
var lake := PackedVector2Array()
var surface_y := 430.0
var view := Vector2(1280, 720)
var _t := 0.0
var _frozen := false
var _rng := RandomNumberGenerator.new()


func setup(p_mode: String, p_theme: Dictionary, p_lake: PackedVector2Array, p_surface_y: float) -> void:
	mode = p_mode
	theme = p_theme
	lake = p_lake
	surface_y = p_surface_y
	queue_redraw()


func freeze_at(seconds: float) -> void:
	_t = seconds
	_frozen = true
	queue_redraw()


func play() -> void:
	_frozen = false


func _process(delta: float) -> void:
	if _frozen:
		return
	_t += delta
	if mode == "dive" or mode == "side":
		queue_redraw()


func _c(key: String, fallback: Color) -> Color:
	return theme.get(key, fallback)


func _gradient(rect: Rect2, top: Color, bottom: Color) -> void:
	draw_polygon(PackedVector2Array([rect.position, Vector2(rect.end.x, rect.position.y),
			rect.end, Vector2(rect.position.x, rect.end.y)]), PackedColorArray([top, top, bottom, bottom]))


func _draw() -> void:
	_rng.seed = 7
	match mode:
		"surface":
			_draw_topdown()
		"side":
			_draw_side(surface_y, true)
		"fall":
			_draw_fall()
		"dive":
			_draw_seabed()


func _draw_topdown() -> void:
	var g1 := _c("ground", Color(0.33, 0.52, 0.24))
	var g2 := _c("ground2", Color(0.27, 0.45, 0.2))
	draw_rect(Rect2(Vector2(-200, -200), view + Vector2(400, 400)), g1)
	for i in 2600:
		var p := Vector2(_rng.randf_range(-40, view.x + 40), _rng.randf_range(-40, view.y + 40))
		draw_circle(p, _rng.randf_range(2.0, 7.0), g2 if i % 2 == 0 else g1.lightened(0.08))
	if lake.size() > 2:
		var beach := Geometry2D.offset_polygon(lake, 22.0, Geometry2D.JOIN_ROUND)
		var wet := Geometry2D.offset_polygon(lake, 9.0, Geometry2D.JOIN_ROUND)
		for poly in beach:
			draw_colored_polygon(poly, _c("beach", Color(0.78, 0.7, 0.5)))
		for poly in wet:
			draw_colored_polygon(poly, _c("wet", Color(0.6, 0.53, 0.38)))
	# rocks and trees around the water, never on it
	var far := Geometry2D.offset_polygon(lake, 60.0, Geometry2D.JOIN_ROUND)
	for i in 70:
		var p := Vector2(_rng.randf_range(20, view.x - 20), _rng.randf_range(20, view.y - 20))
		var blocked := false
		for poly in far:
			if Geometry2D.is_point_in_polygon(p, poly):
				blocked = true
		if blocked:
			continue
		if i % 3 == 0:
			var r := _rng.randf_range(8, 16)
			draw_circle(p + Vector2(3, 4), r, Color(0, 0, 0, 0.25))
			draw_circle(p, r, _c("rock", Color(0.5, 0.5, 0.52)))
			draw_circle(p - Vector2(r * 0.3, r * 0.3), r * 0.5, _c("rock", Color(0.5, 0.5, 0.52)).lightened(0.2))
		else:
			var r2 := _rng.randf_range(18, 34)
			draw_circle(p + Vector2(6, 8), r2, Color(0, 0, 0, 0.28))
			draw_circle(p, r2, _c("tree", Color(0.16, 0.36, 0.17)))
			draw_circle(p - Vector2(r2 * 0.25, r2 * 0.3), r2 * 0.62, _c("tree", Color(0.16, 0.36, 0.17)).lightened(0.15))


func _draw_side(sy: float, full: bool) -> void:
	_gradient(Rect2(-200, -200, view.x + 400, sy + 200), _c("sky_top", Color(0.36, 0.6, 0.86)), _c("sky_low", Color(0.78, 0.88, 0.95)))
	# far hills
	var hills := PackedVector2Array([Vector2(-200, sy)])
	for i in 34:
		var x := -200.0 + i * 50.0
		hills.append(Vector2(x, sy - 120.0 - sin(i * 0.7) * 50.0 - sin(i * 1.9) * 22.0))
	hills.append(Vector2(view.x + 200, sy))
	draw_colored_polygon(hills, _c("hill", Color(0.42, 0.58, 0.62)))
	var near := PackedVector2Array([Vector2(-200, sy)])
	for i in 34:
		var x2 := -200.0 + i * 50.0
		near.append(Vector2(x2, sy - 50.0 - sin(i * 1.1 + 2.0) * 30.0 - sin(i * 2.7) * 12.0))
	near.append(Vector2(view.x + 200, sy))
	draw_colored_polygon(near, _c("hill2", Color(0.27, 0.45, 0.32)))
	# trees on the near bank
	for i in 22:
		var tx := _rng.randf_range(-40, view.x + 40)
		var th := _rng.randf_range(50, 110)
		var base := Vector2(tx, sy - 40.0 - sin(tx * 0.02) * 20.0)
		draw_colored_polygon(PackedVector2Array([base + Vector2(-th * 0.28, 0), base + Vector2(0, -th),
				base + Vector2(th * 0.28, 0)]), _c("tree", Color(0.14, 0.3, 0.2)))
	# clouds
	var cloud := _c("cloud", Color(1, 1, 1, 0.75))
	for i in 7:
		var c := Vector2(fmod(i * 230.0 + _t * 8.0, view.x + 300) - 150, 70.0 + (i % 3) * 45.0)
		var w := 70.0 + 40.0 * absf(sin(i * 2.3))
		draw_set_transform(c + Vector2(0, 6), 0.0, Vector2(1.0, 0.32))
		draw_circle(Vector2.ZERO, w, cloud.darkened(0.08))
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		for k in 6:
			var off := Vector2((float(k) / 5.0 - 0.5) * w * 1.3, -absf(sin(k * 1.9 + i)) * 12.0 - (10.0 if k == 2 or k == 3 else 0.0))
			var r := w * (0.22 + 0.14 * absf(sin(k * 2.7 + i * 1.3)))
			draw_set_transform(c + off, 0.0, Vector2(1.25, 0.85))
			draw_circle(Vector2.ZERO, r, cloud)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		draw_set_transform(c + Vector2(0, 2), 0.0, Vector2(1.0, 0.22))
		draw_circle(Vector2.ZERO, w * 0.9, cloud)
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if not full:
		return
	# under the water: a sand floor, rocks, weed - what the water bends
	_gradient(Rect2(-200, sy, view.x + 400, view.y + 600), _c("under_top", Color(0.5, 0.62, 0.55)), _c("under_low", Color(0.28, 0.32, 0.3)))
	var floor_y := sy + 230.0
	var sand := PackedVector2Array([Vector2(-200, view.y + 600)])
	for i in 34:
		var x3 := -200.0 + i * 50.0
		sand.append(Vector2(x3, floor_y + sin(i * 0.9) * 18.0))
	sand.append(Vector2(view.x + 200, view.y + 600))
	draw_colored_polygon(sand, _c("sand", Color(0.76, 0.66, 0.46)))
	for i in 14:
		var rp := Vector2(_rng.randf_range(0, view.x), floor_y + _rng.randf_range(-10, 30))
		var rr := _rng.randf_range(14, 40)
		draw_circle(rp, rr, _c("rock", Color(0.42, 0.44, 0.46)))
		draw_circle(rp - Vector2(rr * 0.3, rr * 0.35), rr * 0.5, _c("rock", Color(0.42, 0.44, 0.46)).lightened(0.18))
	for i in 18:
		var wx := _rng.randf_range(0, view.x)
		var pts := PackedVector2Array()
		for k in 9:
			var yy := floor_y - k * 16.0
			pts.append(Vector2(wx + sin(k * 0.6 + _t * 1.2 + wx) * (3.0 + k * 1.4), yy))
		draw_polyline(pts, _c("weed", Color(0.25, 0.55, 0.3)), 5.0, true)
	# a wooden pier on the left, its posts standing in the water, a figure on it
	var deck_y := sy - 26.0
	draw_rect(Rect2(-20, deck_y, 360, 14), Color(0.45, 0.3, 0.18))
	draw_rect(Rect2(-20, deck_y, 360, 4), Color(0.6, 0.42, 0.26))
	for k in 5:
		var px := 20.0 + k * 75.0
		draw_rect(Rect2(px, deck_y + 14, 14, 260), Color(0.36, 0.24, 0.14))
	var fig := Vector2(250, deck_y)
	draw_rect(Rect2(fig.x - 9, fig.y - 44, 18, 30), Color(0.85, 0.32, 0.22))
	draw_rect(Rect2(fig.x - 8, fig.y - 14, 6, 14), Color(0.2, 0.2, 0.3))
	draw_rect(Rect2(fig.x + 2, fig.y - 14, 6, 14), Color(0.2, 0.2, 0.3))
	draw_circle(fig + Vector2(0, -54), 10.0, Color(0.95, 0.8, 0.65))
	# a stone bank on the right
	draw_colored_polygon(PackedVector2Array([Vector2(1020, sy + 6), Vector2(1060, sy - 40), Vector2(1180, sy - 60),
			Vector2(view.x + 40, sy - 70), Vector2(view.x + 40, sy + 300), Vector2(1100, sy + 260)]), _c("bank",
			Color(0.38, 0.36, 0.34)))
	draw_colored_polygon(PackedVector2Array([Vector2(1060, sy - 40), Vector2(1180, sy - 60),
			Vector2(view.x + 40, sy - 70), Vector2(view.x + 40, sy - 58), Vector2(1180, sy - 48), Vector2(1066, sy - 30)]),
			_c("grass_edge", Color(0.3, 0.55, 0.25)))


func _draw_fall() -> void:
	var sy := 600.0
	_draw_side(sy, false)
	# a cliff with a notch the water pours through
	var rock := _c("cliff", Color(0.32, 0.3, 0.3))
	var lip := 150.0
	var left := PackedVector2Array([Vector2(-50, view.y + 50), Vector2(-50, 120), Vector2(200, 100), Vector2(420, 130), Vector2(560, lip), Vector2(570, sy + 40)])
	var right := PackedVector2Array([Vector2(710, sy + 40), Vector2(720, lip), Vector2(880, 120), Vector2(1080, 90),
			Vector2(view.x + 50, 110), Vector2(view.x + 50, view.y + 50)])
	draw_colored_polygon(left, rock)
	draw_colored_polygon(right, rock)
	draw_rect(Rect2(560, lip + 10, 160, sy - lip), rock.darkened(0.35))
	for i in 60:
		var p := Vector2(_rng.randf_range(0, view.x), _rng.randf_range(120, view.y))
		if p.x > 545 and p.x < 735:
			continue
		draw_rect(Rect2(p, Vector2(_rng.randf_range(20, 70), 3)), rock.darkened(0.2))
		draw_rect(Rect2(p + Vector2(0, -3), Vector2(_rng.randf_range(10, 40), 2)), rock.lightened(0.15))
	draw_rect(Rect2(-50, 104, 610, 10), _c("grass_edge", Color(0.3, 0.55, 0.25)))
	draw_rect(Rect2(720, 100, view.x - 670, 10), _c("grass_edge", Color(0.3, 0.55, 0.25)))
	draw_rect(Rect2(-50, sy, view.x + 100, view.y), _c("under_top", Color(0.3, 0.42, 0.45)))


func _draw_seabed() -> void:
	_gradient(Rect2(-200, -200, view.x + 400, view.y + 400), _c("sea_top", Color(0.32, 0.66, 0.74)), _c("sea_low", Color(0.12, 0.3, 0.42)))
	var floor_y := 560.0
	var sand := PackedVector2Array([Vector2(-200, view.y + 200)])
	for i in 34:
		var x := -200.0 + i * 50.0
		sand.append(Vector2(x, floor_y + sin(i * 0.8) * 26.0 + sin(i * 2.3) * 8.0))
	sand.append(Vector2(view.x + 200, view.y + 200))
	draw_colored_polygon(sand, _c("sand", Color(0.82, 0.72, 0.5)))
	for i in 12:
		var rp := Vector2(_rng.randf_range(0, view.x), floor_y + _rng.randf_range(-20, 40))
		var rr := _rng.randf_range(20, 56)
		draw_circle(rp, rr, Color(0.36, 0.38, 0.42))
		draw_circle(rp - Vector2(rr * 0.3, rr * 0.35), rr * 0.5, Color(0.48, 0.5, 0.54))
	# corals
	for i in 16:
		var cp := Vector2(_rng.randf_range(0, view.x), floor_y + _rng.randf_range(-30, 10))
		var cc := [Color(0.95, 0.45, 0.4), Color(0.98, 0.7, 0.3), Color(0.8, 0.4, 0.75)][i % 3] as Color
		for k in 6:
			draw_circle(cp + Vector2(sin(k * 2.1) * 14.0, -k * 7.0), 9.0 - k, cc)
	# kelp swaying
	for i in 16:
		var kx := 30.0 + i * 82.0 + sin(i * 3.1) * 20.0
		var pts := PackedVector2Array()
		for k in 16:
			var yy := floor_y + 10.0 - k * 26.0
			pts.append(Vector2(kx + sin(k * 0.4 + _t * 0.9 + i) * (4.0 + k * 2.2), yy))
		draw_polyline(pts, Color(0.22, 0.5, 0.28), 9.0, true)
		draw_polyline(pts, Color(0.32, 0.64, 0.34), 3.0, true)
	# a school of fish
	for i in 14:
		var fx := fmod(i * 97.0 + _t * (40.0 + (i % 4) * 8.0), view.x + 200.0) - 100.0
		var fy := 200.0 + (i % 5) * 46.0 + sin(_t * 1.5 + i) * 6.0
		var fc := [Color(1.0, 0.75, 0.25), Color(0.95, 0.5, 0.3), Color(0.6, 0.85, 1.0)][i % 3] as Color
		draw_colored_polygon(PackedVector2Array([Vector2(fx - 26, fy), Vector2(fx - 36, fy - 9), Vector2(fx - 36, fy + 9)]), fc.darkened(0.2))
		draw_set_transform(Vector2(fx - 12, fy), 0.0, Vector2(1.6, 1.0))
		draw_circle(Vector2.ZERO, 9.0, fc)
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		draw_circle(Vector2(fx - 4, fy - 2), 2.0, Color(0.1, 0.1, 0.15))
	# a sunken chest
	var ch := Vector2(880, floor_y - 6)
	draw_rect(Rect2(ch, Vector2(70, 42)), Color(0.45, 0.28, 0.15))
	draw_rect(Rect2(ch + Vector2(0, -16), Vector2(70, 18)), Color(0.55, 0.34, 0.18))
	draw_rect(Rect2(ch + Vector2(31, -6), Vector2(8, 12)), Color(0.95, 0.8, 0.3))
