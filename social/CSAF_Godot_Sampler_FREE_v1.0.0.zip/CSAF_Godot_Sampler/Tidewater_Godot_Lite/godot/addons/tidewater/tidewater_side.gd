@tool
class_name TidewaterSide
extends Node2D
## Side-on water for platformers: a pool, sea, canal or lava pit seen from the side. The node's origin is the middle of
## the still surface; the water fills `size` below it. It bends what is behind it, mirrors what is above it, and ripples
## where things hit it:
##
##   var pool := TidewaterCatalog.instantiate("clear_pool") as TidewaterSide
##   pool.size = Vector2(640, 180)
##   add_child(pool)
##   pool.splash(player.global_position.x, 1.0)        # when the player lands in it
##   crate.global_position.y = pool.get_surface_y(crate.global_position.x)   # bob a float on it
##
## Put it AFTER the things it should refract and reflect (later in the tree or a higher z_index): it reads the screen.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

## Emitted by splash(), with the global x and strength, for your own sound or particles.
signal splashed(global_x: float, strength: float)

const COLUMNS := 64
const STEP := 1.0 / 60.0

## Recolour: deep, shallow, foam and glow colours. Leave empty to keep the material's own colours.
@export var palette: TidewaterPalette:
	set(value):
		if palette and palette.changed.is_connected(_apply_static):
			palette.changed.disconnect(_apply_static)
		palette = value
		if palette:
			palette.changed.connect(_apply_static)
		_apply_static()
## Width and depth of the water, in pixels. The surface runs along the top edge, centred on the origin.
@export var size := Vector2(480, 200):
	set(value):
		size = value.max(Vector2(8, 8))
		_apply_static()
		queue_redraw()
## Room drawn above the surface for waves, heat shimmer, mist and bubbles that break the surface.
@export_range(0.0, 256.0, 1.0) var headroom := 48.0:
	set(value):
		headroom = value
		_apply_static()
		queue_redraw()
## Playback speed multiplier.
@export_range(0.0, 4.0, 0.01, "or_greater") var speed_scale := 1.0
## Brightness of highlights, glints and glow.
@export_range(0.0, 3.0, 0.01) var intensity := 1.0:
	set(value):
		intensity = value
		_apply_static()
## Size of the ripples, bubbles and caustics (2 = twice as large).
@export_range(0.25, 4.0, 0.01) var pattern_scale := 1.0:
	set(value):
		pattern_scale = value
		_apply_static()
## Height of the rolling swell, in pixels.
@export_range(0.0, 32.0, 0.1) var wave_height := 3.0:
	set(value):
		wave_height = value
		_apply_static()
## Length of one swell, in pixels.
@export_range(8.0, 1024.0, 1.0) var wave_length := 120.0:
	set(value):
		wave_length = value
		_apply_static()
## Speed of the swell.
@export_range(0.0, 8.0, 0.01) var wave_speed := 1.2:
	set(value):
		wave_speed = value
		_apply_static()
## How far what is behind the water is bent, in pixels.
@export_range(0.0, 32.0, 0.1) var refraction := 5.0:
	set(value):
		refraction = value
		_apply_static()
## How strongly the water mirrors what is above it (0 = not at all).
@export_range(0.0, 1.0, 0.01) var reflection := 0.25:
	set(value):
		reflection = value
		_apply_static()
## How far below the surface the reflection reaches before it fades, in pixels (mirror-calm water: hundreds).
@export_range(4.0, 1024.0, 1.0) var reflection_depth := 36.0:
	set(value):
		reflection_depth = value
		_apply_static()
## How clear the water is near the surface (1 = glass, 0 = opaque).
@export_range(0.0, 1.0, 0.01) var clarity := 0.5:
	set(value):
		clarity = value
		_apply_static()
## Ripple springs: how stiff, how fast they calm, how far a splash travels.
@export_range(0.001, 0.2, 0.001) var stiffness := 0.025
@export_range(0.0, 0.2, 0.001) var damping := 0.03
@export_range(0.0, 0.5, 0.001) var spread := 0.22
## Seconds into the animation shown by seek_preview() and thumbnails.
@export_range(0.0, 60.0, 0.01) var preview_time := 2.0
## When on, seek_preview() also shows a splash on the left of the surface.
@export var preview_splash := true

var _t := 0.0
var _frozen := false
var _acc := 0.0
var _h := PackedFloat32Array()
var _v := PackedFloat32Array()
var _active := false


func _init() -> void:
	_h.resize(COLUMNS)
	_v.resize(COLUMNS)


func _ready() -> void:
	_apply_static()
	_push_time()
	_push_springs()
	queue_redraw()


func _draw() -> void:
	draw_rect(Rect2(-size.x * 0.5, -headroom, size.x, size.y + headroom), Color.WHITE)


func _process(delta: float) -> void:
	if _frozen:
		return
	_t += delta * speed_scale
	_push_time()
	if _active:
		_acc += delta * speed_scale
		var n := 0
		while _acc >= STEP and n < 8:
			_acc -= STEP
			n += 1
			_step_springs()
		_push_springs()


## Pushes the surface down at a global x (strength 1 = a body landing; negative pulls it up).
func splash(global_x: float, strength := 1.0) -> void:
	var lx := to_local(Vector2(global_x, global_position.y)).x
	var f := (lx + size.x * 0.5) / size.x * float(COLUMNS - 1)
	if f < -1.0 or f > float(COLUMNS):
		return
	var i := clampi(int(round(f)), 0, COLUMNS - 1)
	for k in range(-2, 3):
		var j := i + k
		if j >= 0 and j < COLUMNS:
			_v[j] += strength * 6.0 * (1.0 - absf(float(k)) * 0.3)
	_active = true
	splashed.emit(global_x, strength)


## The global y of the surface at a global x: the swell plus splash ripples (not the fine noise ripple).
func get_surface_y(global_x: float) -> float:
	var lx := to_local(Vector2(global_x, global_position.y)).x
	var k := TAU / maxf(wave_length, 1.0)
	var sw := wave_height * (0.6 * sin(lx * k + _t * wave_speed) + 0.4 * sin(lx * k * 2.13 - _t * wave_speed * 1.3 + 1.3))
	var f := clampf((lx + size.x * 0.5) / size.x, 0.0, 1.0) * float(COLUMNS - 1)
	var i := int(floor(f))
	var sp := lerpf(_h[i], _h[mini(i + 1, COLUMNS - 1)], f - float(i))
	return to_global(Vector2(lx, sw + sp)).y


## True when a global point is below the surface and inside the water's width and depth.
func is_underwater(global_point: Vector2) -> bool:
	var lp := to_local(global_point)
	return absf(lp.x) <= size.x * 0.5 and lp.y <= size.y and global_point.y >= get_surface_y(global_point.x)


## Freeze on a moment `seconds` into the animation (stills, thumbnails).
func seek(seconds: float) -> void:
	_t = maxf(seconds, 0.0)
	_frozen = true
	_push_time()


## Resume animating after seek().
func play() -> void:
	_frozen = false


## Calms every ripple at once.
func calm() -> void:
	for i in COLUMNS:
		_h[i] = 0.0
		_v[i] = 0.0
	_active = false
	_push_springs()


func seek_preview() -> void:
	calm()
	if preview_splash:
		splash(to_global(Vector2(-size.x * 0.22, 0.0)).x, 1.2)
		for i in 26:
			_step_springs()
		_push_springs()
	seek(preview_time)


## Alias of seek_preview(), called by CSAF's capture harness when it photographs each preset.
func csaf_preview() -> void:
	seek_preview()


func _step_springs() -> void:
	var still := true
	for i in COLUMNS:
		var a := -stiffness * _h[i] - damping * _v[i]
		_v[i] += a
		_h[i] += _v[i]
	for _p in 2:
		for i in COLUMNS:
			if i > 0:
				var dl := spread * (_h[i] - _h[i - 1])
				_v[i - 1] += dl
			if i < COLUMNS - 1:
				var dr := spread * (_h[i] - _h[i + 1])
				_v[i + 1] += dr
	for i in COLUMNS:
		if absf(_h[i]) > 0.01 or absf(_v[i]) > 0.01:
			still = false
	if still:
		_active = false


func _mat() -> ShaderMaterial:
	return material as ShaderMaterial


func _push_time() -> void:
	var m := _mat()
	if m:
		RenderingServer.material_set_param(m.get_rid(), &"tw_time", _t)


func _push_springs() -> void:
	var m := _mat()
	if m:
		RenderingServer.material_set_param(m.get_rid(), &"springs", _h)


func _apply_static() -> void:
	var m := _mat()
	if m == null:
		return
	var rid := m.get_rid()
	RenderingServer.material_set_param(rid, &"size", size)
	RenderingServer.material_set_param(rid, &"headroom", headroom)
	RenderingServer.material_set_param(rid, &"intensity", intensity)
	RenderingServer.material_set_param(rid, &"pattern_scale", pattern_scale)
	RenderingServer.material_set_param(rid, &"wave_height", wave_height)
	RenderingServer.material_set_param(rid, &"wave_length", wave_length)
	RenderingServer.material_set_param(rid, &"wave_speed", wave_speed)
	RenderingServer.material_set_param(rid, &"refraction", refraction)
	RenderingServer.material_set_param(rid, &"reflection", reflection)
	RenderingServer.material_set_param(rid, &"reflection_depth", reflection_depth)
	RenderingServer.material_set_param(rid, &"clarity", clarity)
	RenderingServer.material_set_param(rid, &"spring_count", COLUMNS)
	if palette:
		palette.apply_to(rid)
