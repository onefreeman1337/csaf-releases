@tool
class_name TidewaterFall
extends Node2D
## A waterfall, cascade, outflow, drip line or fountain. The node's origin is the centre of the falling water: `size` is
## its width and its drop, the top edge is the lip and the bottom edge is where it lands. The splash, pool and mist
## spread past that box (turn them off with `basin`).
##
##   var fall := TidewaterCatalog.instantiate("waterfall") as TidewaterFall
##   fall.size = Vector2(96, 320)
##   fall.position = cliff_edge + Vector2(0, 160)
##   add_child(fall)
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

## Recolour: deep, shallow, foam and glow colours. Leave empty to keep the material's own colours.
@export var palette: TidewaterPalette:
	set(value):
		if palette and palette.changed.is_connected(_apply_static):
			palette.changed.disconnect(_apply_static)
		palette = value
		if palette:
			palette.changed.connect(_apply_static)
		_apply_static()
## Width and drop of the falling water, in pixels.
@export var size := Vector2(120, 240):
	set(value):
		size = value.max(Vector2(4, 8))
		_apply_static()
		queue_redraw()
## How fast the water falls, in pixels per second.
@export_range(0.0, 1000.0, 1.0) var fall_speed := 220.0:
	set(value):
		fall_speed = value
		_apply_static()
## Draw the splash, pool and mist where it lands.
@export var basin := true:
	set(value):
		basin = value
		_apply_static()
## Playback speed multiplier.
@export_range(0.0, 4.0, 0.01, "or_greater") var speed_scale := 1.0
## Brightness of highlights, glints and glow.
@export_range(0.0, 3.0, 0.01) var intensity := 1.0:
	set(value):
		intensity = value
		_apply_static()
## Size of the streaks and foam (2 = twice as large).
@export_range(0.25, 4.0, 0.01) var pattern_scale := 1.0:
	set(value):
		pattern_scale = value
		_apply_static()
## Seconds into the animation shown by seek_preview() and thumbnails.
@export_range(0.0, 60.0, 0.01) var preview_time := 2.0

var _t := 0.0
var _frozen := false


func _ready() -> void:
	_apply_static()
	_push_time()
	queue_redraw()


## The box the shader draws in: the fall plus room for the splash, pool and mist around its foot.
func get_draw_rect() -> Rect2:
	var w := maxf(size.x * 2.8, size.x + 140.0)
	return Rect2(-w * 0.5, -size.y * 0.5 - 12.0, w, size.y + 12.0 + 64.0)


func _draw() -> void:
	draw_rect(get_draw_rect(), Color.WHITE)


func _process(delta: float) -> void:
	if _frozen:
		return
	_t += delta * speed_scale
	_push_time()


## Freeze on a moment `seconds` into the animation (stills, thumbnails).
func seek(seconds: float) -> void:
	_t = maxf(seconds, 0.0)
	_frozen = true
	_push_time()


## Resume animating after seek().
func play() -> void:
	_frozen = false


func seek_preview() -> void:
	seek(preview_time)


## Alias of seek_preview(), called by CSAF's capture harness when it photographs each preset.
func csaf_preview() -> void:
	seek_preview()


func _mat() -> ShaderMaterial:
	return material as ShaderMaterial


func _push_time() -> void:
	var m := _mat()
	if m:
		RenderingServer.material_set_param(m.get_rid(), &"tw_time", _t)


func _apply_static() -> void:
	var m := _mat()
	if m == null:
		return
	var rid := m.get_rid()
	RenderingServer.material_set_param(rid, &"size", size)
	RenderingServer.material_set_param(rid, &"fall_speed", fall_speed)
	RenderingServer.material_set_param(rid, &"basin", 1.0 if basin else 0.0)
	RenderingServer.material_set_param(rid, &"intensity", intensity)
	RenderingServer.material_set_param(rid, &"pattern_scale", pattern_scale)
	if palette:
		palette.apply_to(rid)
