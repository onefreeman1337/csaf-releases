@tool
class_name TidewaterLayer
extends Node2D
## A full-screen underwater or water-light filter on its own CanvasLayer: it reads the screen under it and tints, bends
## or lights it. Fade it with fade_in() / fade_out(), or give it a `surface` and it fades itself in as the camera goes
## below that line and out as it comes back up:
##
##   var dive := TidewaterCatalog.instantiate("deep_dive") as TidewaterLayer
##   dive.surface = $Lake          # a TidewaterSide, or any Node2D whose y is the waterline
##   add_child(dive)
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

## Emitted when a fade_out() reaches zero.
signal faded_out

## Recolour: deep, shallow, foam and glow colours. Leave empty to keep the material's own colours.
@export var palette: TidewaterPalette:
	set(value):
		if palette and palette.changed.is_connected(_apply_static):
			palette.changed.disconnect(_apply_static)
		palette = value
		if palette:
			palette.changed.connect(_apply_static)
		_apply_static()
## Strength of the filter, 0..1 (fades and the surface follow move this).
@export_range(0.0, 1.0, 0.01) var amount := 1.0:
	set(value):
		amount = value
		_push_amount()
## Playback speed multiplier.
@export_range(0.0, 4.0, 0.01, "or_greater") var speed_scale := 1.0
## Brightness of caustics, shafts, motes and glow.
@export_range(0.0, 3.0, 0.01) var intensity := 1.0:
	set(value):
		intensity = value
		_apply_static()
## Size of the caustics, bubbles and particles (2 = twice as large).
@export_range(0.25, 4.0, 0.01) var pattern_scale := 1.0:
	set(value):
		pattern_scale = value
		_apply_static()
## How far the view sways, in pixels.
@export_range(0.0, 16.0, 0.1) var wobble := 2.0:
	set(value):
		wobble = value
		_apply_static()
## CanvasLayer order: put the filter above the world and below your UI.
@export var layer := 4:
	set(value):
		layer = value
		if _canvas:
			_canvas.layer = value
## Optional waterline: when set, `amount` follows the camera - 0 above this node's y, 1 below it.
@export var surface: Node2D
## Height in pixels over which the filter fades in as the camera crosses the waterline.
@export_range(1.0, 512.0, 1.0) var blend_px := 48.0
## Seconds into the animation shown by seek_preview() and thumbnails.
@export_range(0.0, 60.0, 0.01) var preview_time := 2.0

var _t := 0.0
var _frozen := false
var _fade_from := 1.0
var _fade_to := 1.0
var _fade_len := 0.0
var _fade_t := 0.0
var _canvas: CanvasLayer
var _rect: ColorRect


func _ready() -> void:
	_canvas = get_node_or_null("Canvas") as CanvasLayer
	if _canvas:
		_canvas.layer = layer
	_rect = get_node_or_null("Canvas/Filter") as ColorRect
	_apply_static()
	_push_amount()
	_push_time()


func _process(delta: float) -> void:
	if _rect:
		var vs := get_viewport().get_visible_rect().size
		if _rect.size != vs:
			_rect.size = vs
			_apply_static()
	if _frozen:
		return
	_t += delta * speed_scale
	if _fade_len > 0.0:
		_fade_t += delta
		amount = lerpf(_fade_from, _fade_to, clampf(_fade_t / _fade_len, 0.0, 1.0))
		if _fade_t >= _fade_len:
			_fade_len = 0.0
			if _fade_to <= 0.0:
				faded_out.emit()
	elif is_instance_valid(surface) and not Engine.is_editor_hint():
		amount = _depth_amount()
	_push_time()


## 0..1: how far below the waterline the centre of the view is, over blend_px.
func _depth_amount() -> float:
	var vp := get_viewport()
	var centre := vp.get_canvas_transform().affine_inverse() * (vp.get_visible_rect().size * 0.5)
	var line_y := surface.global_position.y
	if surface.has_method("get_surface_y"):
		line_y = surface.call("get_surface_y", centre.x)
	return clampf((centre.y - line_y) / blend_px + 0.5, 0.0, 1.0)


## Fade the filter in from nothing over `seconds`.
func fade_in(seconds := 1.0) -> void:
	_start_fade(0.0, 1.0, seconds)


## Fade the filter out over `seconds`; emits faded_out at the end.
func fade_out(seconds := 1.0) -> void:
	_start_fade(amount, 0.0, seconds)


## Freeze on a moment `seconds` into the animation (stills, thumbnails).
func seek(seconds: float) -> void:
	_t = maxf(seconds, 0.0)
	_frozen = true
	_push_time()


## Resume animating after seek().
func play() -> void:
	_frozen = false


func seek_preview() -> void:
	seek(preview_time)


## Alias of seek_preview(), called by CSAF's capture harness when it photographs each preset.
func csaf_preview() -> void:
	seek_preview()


func _start_fade(from: float, to: float, seconds: float) -> void:
	_frozen = false
	_fade_from = from
	_fade_to = to
	_fade_len = maxf(seconds, 0.001)
	_fade_t = 0.0
	amount = from


func _mat() -> ShaderMaterial:
	return _rect.material as ShaderMaterial if _rect else null


func _push_time() -> void:
	var m := _mat()
	if m:
		RenderingServer.material_set_param(m.get_rid(), &"tw_time", _t)


func _push_amount() -> void:
	var m := _mat()
	if m:
		RenderingServer.material_set_param(m.get_rid(), &"amount", amount)


func _apply_static() -> void:
	var m := _mat()
	if m == null:
		return
	var rid := m.get_rid()
	RenderingServer.material_set_param(rid, &"intensity", intensity)
	RenderingServer.material_set_param(rid, &"pattern_scale", pattern_scale)
	RenderingServer.material_set_param(rid, &"wobble", wobble)
	RenderingServer.material_set_param(rid, &"view_size", _rect.size)
	if palette:
		palette.apply_to(rid)
