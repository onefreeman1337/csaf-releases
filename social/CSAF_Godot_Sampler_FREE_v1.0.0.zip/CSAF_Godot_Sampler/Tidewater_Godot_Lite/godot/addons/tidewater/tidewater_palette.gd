@tool
class_name TidewaterPalette
extends Resource
## The four colours of a Tidewater preset. Assign one to any Tidewater node to recolour it; edit it and every node that
## shares it follows.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

## Colour of deep water (the body's middle, the bottom of a pool, a filter's darkest tone).
@export var deep := Color(0.05, 0.2, 0.36):
	set(value):
		deep = value
		emit_changed()
## Colour of shallow water (near the shore, near the surface).
@export var shallow := Color(0.18, 0.55, 0.68):
	set(value):
		shallow = value
		emit_changed()
## Colour of foam, surf, spray and bubbles.
@export var foam := Color(0.92, 0.97, 1.0):
	set(value):
		foam = value
		emit_changed()
## Colour of light: glints, caustics, highlights, glow.
@export var glow := Color(0.75, 0.95, 1.0):
	set(value):
		glow = value
		emit_changed()


## Pushes the four colours into a material's `deep`, `shallow`, `foam` and `glow` uniforms.
func apply_to(material_rid: RID) -> void:
	RenderingServer.material_set_param(material_rid, &"deep", deep)
	RenderingServer.material_set_param(material_rid, &"shallow", shallow)
	RenderingServer.material_set_param(material_rid, &"foam", foam)
	RenderingServer.material_set_param(material_rid, &"glow", glow)
