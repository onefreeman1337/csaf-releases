@tool
class_name TidewaterBody
extends Polygon2D
## A top-down body of water: a lake, sea, river, pool of lava. Draw its outline with the Polygon2D editor (or leave the
## default shape) and the shoreline follows: the body bakes a distance field from its own polygon, so depth, surf and
## foam land along whatever edge you drew. Or point `tile_mask` at a TileMapLayer and the water fills that layer's used
## cells instead, with the shore along the tile edges.
##
##   var lake := TidewaterCatalog.instantiate("lagoon") as TidewaterBody
##   lake.polygon = PackedVector2Array([Vector2(0, 0), Vector2(300, -20), Vector2(340, 160), Vector2(20, 200)])
##   add_child(lake)
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

## Emitted after the shoreline field is rebuilt.
signal baked

## Recolour: deep, shallow, foam and glow colours. Leave empty to keep the material's own colours.
@export var palette: TidewaterPalette:
	set(value):
		if palette and palette.changed.is_connected(_apply_static):
			palette.changed.disconnect(_apply_static)
		palette = value
		if palette:
			palette.changed.connect(_apply_static)
		_apply_static()
## Playback speed multiplier.
@export_range(0.0, 4.0, 0.01, "or_greater") var speed_scale := 1.0
## Brightness of highlights, glints and glow.
@export_range(0.0, 3.0, 0.01) var intensity := 1.0:
	set(value):
		intensity = value
		_apply_static()
## Size of the ripples, swell and caustics (2 = twice as large).
@export_range(0.25, 4.0, 0.01) var pattern_scale := 1.0:
	set(value):
		pattern_scale = value
		_apply_static()
## Width of the surf, foam or rim along the shore, in pixels.
@export_range(0.0, 64.0, 0.5) var foam_width := 10.0:
	set(value):
		foam_width = value
		_dirty = true
## Distance from the shore, in pixels, at which the water reaches its deep colour.
@export_range(4.0, 256.0, 1.0) var depth := 60.0:
	set(value):
		depth = value
		_dirty = true
## Direction the current runs (rivers; other kinds drift with it).
@export var flow := Vector2(1.0, 0.0):
	set(value):
		flow = value
		_apply_static()
## Optional: fill the used cells of this TileMapLayer instead of the polygon. Paint water tiles on their own layer.
@export var tile_mask: TileMapLayer:
	set(value):
		if tile_mask and tile_mask.changed.is_connected(_on_mask_changed):
			tile_mask.changed.disconnect(_on_mask_changed)
		tile_mask = value
		if tile_mask:
			tile_mask.changed.connect(_on_mask_changed)
		_dirty = true
## How often, in seconds, the body checks tile_mask for painted or erased cells and rebakes (0 = never; call bake()).
## Godot 4.7's TileMapLayer.changed does not fire for set_cell / erase_cell at runtime, so the cells are watched.
@export_range(0.0, 5.0, 0.05) var mask_check_interval := 0.25
## Resolution of the shoreline field in pixels per sample (smaller = finer, slower to bake).
@export_range(1.0, 16.0, 0.5) var bake_texel := 4.0:
	set(value):
		bake_texel = value
		_dirty = true
## Seconds into the animation shown by seek_preview() and thumbnails.
@export_range(0.0, 60.0, 0.01) var preview_time := 2.0
@export_tool_button("Bake shoreline") var bake_button := bake

const MAX_GRID := 256

var _t := 0.0
var _frozen := false
var _dirty := true
var _last_poly := PackedVector2Array()
var _sdf: ImageTexture
var _img: Image
var _origin := Vector2.ZERO
var _size := Vector2.ONE
var _reach := 96.0
var _mask_sig := 0
var _mask_wait := 0.0


## An organic lake outline of the given half size, for a body created from code.
static func default_shape(half := Vector2(200, 115), points := 28, wobble := 1.0) -> PackedVector2Array:
	var out := PackedVector2Array()
	for i in points:
		var a := TAU * float(i) / float(points)
		var r := 1.0 + wobble * (0.1 * sin(3.0 * a + 0.5) + 0.06 * sin(5.0 * a + 1.3) + 0.03 * sin(9.0 * a + 2.1))
		out.append(Vector2(cos(a) * half.x, sin(a) * half.y) * r)
	return out


func _ready() -> void:
	if polygon.is_empty():
		polygon = default_shape()
	bake()
	_push_time()


func _process(delta: float) -> void:
	if tile_mask and mask_check_interval > 0.0:
		_mask_wait += delta
		if _mask_wait >= mask_check_interval:
			_mask_wait = 0.0
			if _mask_signature() != _mask_sig:
				_dirty = true
	if _dirty or (tile_mask == null and polygon != _last_poly):
		bake()
	if _frozen:
		return
	_t += delta * speed_scale
	_push_time()


## Freeze on a moment `seconds` into the animation (stills, thumbnails).
func seek(seconds: float) -> void:
	_t = maxf(seconds, 0.0)
	_frozen = true
	_push_time()


## Resume animating after seek().
func play() -> void:
	_frozen = false


func seek_preview() -> void:
	seek(preview_time)


## Alias of seek_preview(), called by CSAF's capture harness when it photographs each preset.
func csaf_preview() -> void:
	if _dirty:
		bake()
	seek_preview()


## The shoreline distance at a point in this node's local space: > 0 in the water, < 0 on land (pixels).
func shore_distance(local_point: Vector2) -> float:
	if _img == null:
		return 0.0
	var uv := (local_point - _origin) / _size
	if uv.x < 0.0 or uv.y < 0.0 or uv.x > 1.0 or uv.y > 1.0:
		return -_reach
	var c := _img.get_pixel(clampi(int(uv.x * _img.get_width()), 0, _img.get_width() - 1), clampi(int(uv.y * _img.get_height()), 0, _img.get_height() - 1))
	return (c.r - 0.5) * 2.0 * _reach


## True when a local point is in the water.
func is_water(local_point: Vector2) -> bool:
	return shore_distance(local_point) > 0.0


## Rebuilds the shoreline field from the polygon (or tile_mask). Called for you when either changes.
func bake() -> void:
	_dirty = false
	var rect := _mask_rect()
	if rect.size.x < 1.0 or rect.size.y < 1.0:
		return
	var tex := maxf(bake_texel, 0.5)
	rect = rect.grow(tex * 2.0)
	var w := ceili(rect.size.x / tex)
	var h := ceili(rect.size.y / tex)
	var shrink := maxf(float(w) / MAX_GRID, float(h) / MAX_GRID)
	if shrink > 1.0:
		w = ceili(w / shrink)
		h = ceili(h / shrink)
	w = maxi(w, 4)
	h = maxi(h, 4)
	var cell := Vector2(rect.size.x / w, rect.size.y / h)
	var inside := PackedByteArray()
	inside.resize(w * h)
	var poly := polygon
	for y in h:
		for x in w:
			var p := rect.position + Vector2(x + 0.5, y + 0.5) * cell
			inside[y * w + x] = 1 if _is_water_at(p, poly) else 0
	var d_in := _chamfer(inside, w, h, 1)
	var d_out := _chamfer(inside, w, h, 0)
	var pitch := (cell.x + cell.y) * 0.5
	_reach = maxf(maxf(depth, foam_width * 2.5), 16.0) + pitch * 2.0
	var img := Image.create(w, h, false, Image.FORMAT_RGBA8)
	for y in h:
		for x in w:
			var i := y * w + x
			var dpx := (d_in[i] - 0.5) * pitch if inside[i] == 1 else -(d_out[i] - 0.5) * pitch
			var v := clampf(0.5 + dpx / (2.0 * _reach), 0.0, 1.0)
			img.set_pixel(x, y, Color(v, v, v, 1.0))
	if _sdf and _sdf.get_width() == w and _sdf.get_height() == h:
		_sdf.update(img)
	else:
		_sdf = ImageTexture.create_from_image(img)
	_img = img
	_origin = rect.position
	_size = rect.size
	_last_poly = polygon.duplicate()
	_mask_sig = _mask_signature()
	_apply_static()
	baked.emit()


func _mask_rect() -> Rect2:
	if tile_mask and tile_mask.tile_set:
		var used := tile_mask.get_used_rect()
		if used.size == Vector2i.ZERO:
			return Rect2()
		var ts := Vector2(tile_mask.tile_set.tile_size)
		var a := Vector2(used.position) * ts
		var b := Vector2(used.end) * ts
		var corners := [Vector2(a.x, a.y), Vector2(b.x, a.y), Vector2(a.x, b.y), Vector2(b.x, b.y)]
		var r := Rect2(to_local(tile_mask.to_global(corners[0])), Vector2.ZERO)
		for c in corners:
			r = r.expand(to_local(tile_mask.to_global(c)))
		var outline := PackedVector2Array([r.position, Vector2(r.end.x, r.position.y), r.end, Vector2(r.position.x, r.end.y)])
		if polygon != outline:
			polygon = outline
		return r
	if polygon.size() < 3:
		return Rect2()
	var r2 := Rect2(polygon[0], Vector2.ZERO)
	for p in polygon:
		r2 = r2.expand(p)
	return r2


func _is_water_at(p: Vector2, poly: PackedVector2Array) -> bool:
	if tile_mask and tile_mask.tile_set:
		var cell := tile_mask.local_to_map(tile_mask.to_local(to_global(p)))
		return tile_mask.get_cell_source_id(cell) != -1
	return Geometry2D.is_point_in_polygon(p, poly)


# Two-pass chamfer distance (in cells) from every cell whose mask equals `target` to the nearest cell that does not.
func _chamfer(mask: PackedByteArray, w: int, h: int, target: int) -> PackedFloat32Array:
	var big := float(w + h) * 2.0
	var d := PackedFloat32Array()
	d.resize(w * h)
	for i in w * h:
		d[i] = big if mask[i] == target else 0.0
	const D1 := 1.0
	const D2 := 1.41421
	for y in h:
		for x in w:
			var i := y * w + x
			var v := d[i]
			if v == 0.0:
				continue
			if x > 0:
				v = minf(v, d[i - 1] + D1)
			if y > 0:
				v = minf(v, d[i - w] + D1)
				if x > 0:
					v = minf(v, d[i - w - 1] + D2)
				if x < w - 1:
					v = minf(v, d[i - w + 1] + D2)
			d[i] = v
	for y in range(h - 1, -1, -1):
		for x in range(w - 1, -1, -1):
			var i := y * w + x
			var v := d[i]
			if v == 0.0:
				continue
			if x < w - 1:
				v = minf(v, d[i + 1] + D1)
			if y < h - 1:
				v = minf(v, d[i + w] + D1)
				if x < w - 1:
					v = minf(v, d[i + w + 1] + D2)
				if x > 0:
					v = minf(v, d[i + w - 1] + D2)
			d[i] = v
	return d


func _on_mask_changed() -> void:
	_dirty = true


# A cheap fingerprint of which cells the mask layer has painted (0 when there is no mask).
func _mask_signature() -> int:
	if tile_mask == null:
		return 0
	return hash(tile_mask.get_used_cells())


func _mat() -> ShaderMaterial:
	return material as ShaderMaterial


func _push_time() -> void:
	var m := _mat()
	if m:
		RenderingServer.material_set_param(m.get_rid(), &"tw_time", _t)


func _apply_static() -> void:
	var m := _mat()
	if m == null:
		return
	var rid := m.get_rid()
	RenderingServer.material_set_param(rid, &"intensity", intensity)
	RenderingServer.material_set_param(rid, &"pattern_scale", pattern_scale)
	RenderingServer.material_set_param(rid, &"foam_width", foam_width)
	RenderingServer.material_set_param(rid, &"depth_px", depth)
	RenderingServer.material_set_param(rid, &"flow", flow)
	if _sdf:
		RenderingServer.material_set_param(rid, &"shore_sdf", _sdf.get_rid())
		RenderingServer.material_set_param(rid, &"sdf_origin", _origin)
		RenderingServer.material_set_param(rid, &"sdf_size", _size)
		RenderingServer.material_set_param(rid, &"sdf_reach", _reach)
	if palette:
		palette.apply_to(rid)
