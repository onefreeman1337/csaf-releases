class_name TidewaterCatalog
extends RefCounted
## Every Tidewater preset, by id. Generated; do not edit by hand.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

const FAMILIES: Array[String] = ["surface", "side", "fall", "dive"]
const PRESETS: Array[Dictionary] = [
	{"id": "lake", "name": "Lake", "family": "surface", "path": "res://addons/tidewater/presets/surface/lake.tscn"},
	{"id": "lagoon", "name": "Lagoon", "family": "surface", "path": "res://addons/tidewater/presets/surface/lagoon.tscn"},
	{"id": "lava", "name": "Lava", "family": "surface", "path": "res://addons/tidewater/presets/surface/lava.tscn"},
	{"id": "clear_pool", "name": "Clear Pool", "family": "side", "path": "res://addons/tidewater/presets/side/clear_pool.tscn"},
	{"id": "ocean_swell", "name": "Ocean Swell", "family": "side", "path": "res://addons/tidewater/presets/side/ocean_swell.tscn"},
	{"id": "mirror_lake", "name": "Mirror Lake", "family": "side", "path": "res://addons/tidewater/presets/side/mirror_lake.tscn"},
	{"id": "waterfall", "name": "Waterfall", "family": "fall", "path": "res://addons/tidewater/presets/fall/waterfall.tscn"},
	{"id": "lavafall", "name": "Lavafall", "family": "fall", "path": "res://addons/tidewater/presets/fall/lavafall.tscn"},
	{"id": "drip_ledge", "name": "Drip Ledge", "family": "fall", "path": "res://addons/tidewater/presets/fall/drip_ledge.tscn"},
	{"id": "shallow_dive", "name": "Shallow Dive", "family": "dive", "path": "res://addons/tidewater/presets/dive/shallow_dive.tscn"},
	{"id": "deep_dive", "name": "Deep Dive", "family": "dive", "path": "res://addons/tidewater/presets/dive/deep_dive.tscn"},
	{"id": "caustic_floor", "name": "Caustic Floor", "family": "dive", "path": "res://addons/tidewater/presets/dive/caustic_floor.tscn"},
]


static func path_of(id: String) -> String:
	for p in PRESETS:
		if p["id"] == id:
			return p["path"]
	return ""


## A new node for the preset id (a TidewaterBody, TidewaterSide, TidewaterFall or TidewaterLayer), or null.
static func instantiate(id: String) -> Node2D:
	var path := path_of(id)
	if path == "":
		push_warning("Tidewater: no preset named %s" % id)
		return null
	return (load(path) as PackedScene).instantiate() as Node2D


static func ids_for_family(family: String) -> Array[String]:
	var out: Array[String] = []
	for p in PRESETS:
		if p["family"] == family:
			out.append(p["id"])
	return out
