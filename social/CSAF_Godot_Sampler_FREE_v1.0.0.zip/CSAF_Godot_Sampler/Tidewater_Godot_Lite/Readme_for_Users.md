# Tidewater Lite - 12 Free 2D Water Shaders for Godot 4

Twelve real presets from Tidewater, free under MIT: a lake, a lagoon and lava seen from above (their depth and surf
follow the outline you draw), a clear pool, an ocean swell and a mirror lake seen from the side (they bend what is behind
them, mirror what is above them and ripple where things land), a waterfall, a lavafall and a drip ledge, and the shallow
dive, deep dive and caustic floor underwater filters. Every one is computed while the game runs; every colour is a
parameter.

- **Godot version:** built and tested on **Godot 4.7.2**, under **both renderers: Forward+ and Compatibility**. Older
  4.x versions were NOT run, so they are not claimed.
- **The full pack** has 48 presets (open sea, river, swamp, frozen pond, pixel sea, acid vat, cave water, arctic water,
  mana fall, fountain jet, abyss, under ice, wet lens and more): https://csaf.itch.io/tidewater-godot

## Install

Copy `godot/addons/tidewater/` into your project's `addons/` folder. No plugin to enable.

## Use it

Instance a scene from `res://addons/tidewater/presets/<family>/<id>.tscn`, or:

```gdscript
var lake := TidewaterCatalog.instantiate("lagoon") as TidewaterBody
lake.polygon = PackedVector2Array([Vector2(0, 0), Vector2(420, -30), Vector2(460, 200), Vector2(30, 240)])
add_child(lake)

var pool := TidewaterCatalog.instantiate("clear_pool") as TidewaterSide
pool.position = Vector2(640, 400)
add_child(pool)
pool.splash(player.global_position.x, 1.0)

var dive := TidewaterCatalog.instantiate("deep_dive") as TidewaterLayer
dive.surface = pool
add_child(dive)
```

The 12 ids: `lake`, `lagoon`, `lava` (TidewaterBody), `clear_pool`, `ocean_swell`, `mirror_lake` (TidewaterSide),
`waterfall`, `lavafall`, `drip_ledge` (TidewaterFall), `shallow_dive`, `deep_dive`, `caustic_floor` (TidewaterLayer).
Every node takes a `palette` (deep, shallow, foam and glow colours), `speed_scale`, `intensity` and `pattern_scale`;
`seek(seconds)` freezes it for a screenshot and `play()` resumes. A TidewaterBody can fill the used cells of a
TileMapLayer instead of its polygon (`tile_mask`). Put a TidewaterSide after the scenery it should refract and reflect.

Open the `godot/` folder as a project and press Play for the demo: Left / Right preset, 1-4 family, click or Space to
splash, V to dive the camera through the surface.

## Licence

MIT (see `LICENSE.txt`). This lite is AI-generated: the shaders, scenes, scripts and demo were written by an AI.

Core Systems Asset Factory
