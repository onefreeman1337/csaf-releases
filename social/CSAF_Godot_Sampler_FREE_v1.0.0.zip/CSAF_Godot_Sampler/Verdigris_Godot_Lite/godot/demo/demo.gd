extends Node2D
## Verdigris demo: every preset on five sample props, the age driven live by a VerdigrisAger, and the same preset shown
## at five ages side by side.
##   Left / Right   previous / next preset        Up / Down   previous / next group
##   1-5   shield, bell, stele, door, pixel-art shield
##   Space   sweep the age 0 -> 1 (VerdigrisAger.age_to)      [ / ]   age -0.05 / +0.05 (or drag the bar)
##   H   hide the help line
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

const LITE := true
const PROPS := [
	["Shield", "res://addons/verdigris/samples/shield.png", 2.0, false],
	["Bell", "res://addons/verdigris/samples/bell.png", 2.0, false],
	["Stele", "res://addons/verdigris/samples/stele.png", 2.0, false],
	["Door", "res://addons/verdigris/samples/door.png", 2.0, false],
	["Pixel shield", "res://addons/verdigris/samples/shield_px.png", 8.0, true],
]
const STRIP_AGES := [0.0, 0.25, 0.5, 0.75, 1.0]
const BAR := Rect2(784, 214, 440, 18)
const INK := Color(0.95, 0.92, 0.84)
const GOLD := Color(0.86, 0.66, 0.3)

var ids: Array[String] = []
var index := 0
var prop := 0
var hero: Sprite2D
var ager: VerdigrisAger
var strip: Array[Sprite2D] = []
var title: Label
var sub: Label
var age_label: Label
var props_label: Label
var help: Label
var dragging := false


func _ready() -> void:
	ids = Verdigris.ids()
	hero = Sprite2D.new()
	hero.position = Vector2(392, 372)
	add_child(hero)
	ager = VerdigrisAger.new()
	ager.make_unique = false
	hero.add_child(ager)
	ager.aged.connect(func(_v: float) -> void: _refresh_age())
	for i in STRIP_AGES.size():
		var s := Sprite2D.new()
		s.position = Vector2(830 + i * 98, 452)
		add_child(s)
		strip.append(s)
	title = _label(Vector2(784, 64), 34, INK)
	sub = _label(Vector2(786, 112), 17, Color(0.72, 0.74, 0.78))
	age_label = _label(Vector2(786, 178), 17, INK)
	props_label = _label(Vector2(786, 560), 16, Color(0.8, 0.8, 0.82))
	_label(Vector2(786, 312), 15, Color(0.62, 0.64, 0.68)).text = "the same preset at five ages: 0, 0.25, 0.5, 0.75, 1"
	help = _label(Vector2(40, 680), 15, Color(0.82, 0.82, 0.8))
	help.text = "Left/Right preset   Up/Down group   1-5 prop   Space sweep age   [ ] age   drag the bar   H help"
	if LITE:
		_label(Vector2(786, 612), 15, GOLD).text = "Verdigris Lite: 12 of the 48 presets. The full pack: csaf.itch.io/verdigris-godot"
	_set_prop(0)
	_show(0)


func _label(pos: Vector2, size: int, colour: Color) -> Label:
	var l := Label.new()
	l.position = pos
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", colour)
	l.add_theme_color_override("font_outline_color", Color(0.04, 0.05, 0.06))
	l.add_theme_constant_override("outline_size", 4)
	add_child(l)
	return l


func _show(i: int) -> void:
	index = wrapi(i, 0, ids.size())
	var id := ids[index]
	var keep := ager.age if hero.material else 0.62
	Verdigris.apply(hero, id, keep)
	ager.age = keep
	for k in strip.size():
		Verdigris.apply(strip[k], id, STRIP_AGES[k])
		(strip[k].material as ShaderMaterial).set_shader_parameter("animate", 1.0)
	_apply_prop_params()
	var row := Verdigris.info(id)
	title.text = String(row["name"])
	sub.text = "%s   -   preset %d of %d   -   res://addons/verdigris/materials/%s/%s.tres" % [String(row["group"]).capitalize(), index + 1, ids.size(), row["group"], id]
	_refresh_age()


func _set_prop(k: int) -> void:
	prop = clampi(k, 0, PROPS.size() - 1)
	var p: Array = PROPS[prop]
	var tex := load(String(p[1])) as Texture2D
	var pixel := bool(p[3])
	hero.texture = tex
	hero.scale = Vector2.ONE * float(p[2])
	hero.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST if pixel else CanvasItem.TEXTURE_FILTER_LINEAR
	for s in strip:
		s.texture = tex
		s.scale = Vector2.ONE * (1.45 if pixel else 0.36)
		s.texture_filter = hero.texture_filter
	_apply_prop_params()
	var names: Array[String] = []
	for i in PROPS.size():
		names.append(("[%d %s]" if i == prop else " %d %s ") % [i + 1, PROPS[i][0]])
	props_label.text = "  ".join(names)
	queue_redraw()


## Pixel-art props get pixel_size 1 (patterns snap to the texture's own pixels) and a shorter reach.
func _apply_prop_params() -> void:
	var pixel := bool(PROPS[prop][3])
	for item in [hero] + strip:
		var m := (item as Sprite2D).material as ShaderMaterial
		if m:
			m.set_shader_parameter("pixel_size", 1.0 if pixel else 0.0)
			m.set_shader_parameter("reach", 2.5 if pixel else 8.0)
			m.set_shader_parameter("scale", 0.25 if pixel else 1.0)


func _refresh_age() -> void:
	if age_label:
		age_label.text = "age  %.2f" % ager.age
	queue_redraw()


func _group_step(d: int) -> void:
	var g := String(Verdigris.info(ids[index])["group"])
	var i := index
	for k in ids.size():
		i = wrapi(i + d, 0, ids.size())
		if String(Verdigris.info(ids[i])["group"]) != g:
			break
	_show(i)


func _unhandled_input(e: InputEvent) -> void:
	if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT:
		dragging = e.pressed and BAR.grow(8.0).has_point(e.position)
		if dragging:
			_drag_to(e.position.x)
	elif e is InputEventMouseMotion and dragging:
		_drag_to(e.position.x)
	if not (e is InputEventKey and e.pressed and not e.echo):
		return
	match e.keycode:
		KEY_RIGHT: _show(index + 1)
		KEY_LEFT: _show(index - 1)
		KEY_DOWN: _group_step(1)
		KEY_UP: _group_step(-1)
		KEY_1, KEY_2, KEY_3, KEY_4, KEY_5: _set_prop(e.keycode - KEY_1)
		KEY_SPACE:
			ager.age = 0.0
			ager.age_to(1.0, 4.0)
		KEY_BRACKETLEFT: ager.age_by(-0.05)
		KEY_BRACKETRIGHT: ager.age_by(0.05)
		KEY_H: help.visible = not help.visible


func _drag_to(x: float) -> void:
	ager.age = clampf((x - BAR.position.x) / BAR.size.x, 0.0, 1.0)


func _draw() -> void:
	var w := 1280.0
	var h := 720.0
	draw_polygon(PackedVector2Array([Vector2(0, 0), Vector2(w, 0), Vector2(w, h), Vector2(0, h)]),
		PackedColorArray([Color(0.13, 0.15, 0.18), Color(0.1, 0.11, 0.13), Color(0.06, 0.07, 0.08), Color(0.09, 0.1, 0.12)]))
	# the hero's plinth: a soft floor shadow and a stage disc
	for i in 6:
		var r := 230.0 - i * 18.0
		draw_set_transform(Vector2(392, 632), 0.0, Vector2(1.0, 0.18))
		draw_circle(Vector2.ZERO, r, Color(0.0, 0.0, 0.0, 0.08))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	draw_line(Vector2(752, 48), Vector2(752, 650), Color(1, 1, 1, 0.08), 1.0)
	# the age bar
	draw_rect(BAR, Color(0.05, 0.06, 0.07))
	draw_rect(Rect2(BAR.position, Vector2(BAR.size.x * ager.age, BAR.size.y)), GOLD)
	draw_rect(BAR, Color(1, 1, 1, 0.25), false, 1.0)
	for k in 5:
		var x := BAR.position.x + BAR.size.x * k / 4.0
		draw_line(Vector2(x, BAR.end.y + 2), Vector2(x, BAR.end.y + 8), Color(1, 1, 1, 0.3), 1.0)
	# five-ages strip frames
	for i in STRIP_AGES.size():
		var c := Vector2(830 + i * 98, 452)
		draw_rect(Rect2(c - Vector2(46, 62), Vector2(92, 124)), Color(1, 1, 1, 0.04))
		draw_string(ThemeDB.fallback_font, c + Vector2(-14, 82), "%.2f" % STRIP_AGES[i], HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color(0.7, 0.72, 0.76))
