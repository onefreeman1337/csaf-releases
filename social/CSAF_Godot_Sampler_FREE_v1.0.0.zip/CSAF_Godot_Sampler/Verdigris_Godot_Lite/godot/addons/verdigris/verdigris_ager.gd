class_name VerdigrisAger
extends Node
## Drives the age of a Verdigris material over time or from a game value. Add it as a child of the node wearing the
## material (a Sprite2D, TileMapLayer, TextureRect...) or point `target` at it.
##
##   $Gate/VerdigrisAger.age_to(1.0, 30.0)          # rust the gate over thirty seconds
##   $Hull/VerdigrisAger.drive(days_at_sea, 0, 90)   # barnacles follow a number you already track
##   $Statue/VerdigrisAger.set_preset("petrify")     # swap the state, keep the age
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

## Emitted whenever the age changes.
signal aged(value: float)
## Emitted when an age_to() tween arrives.
signal age_reached(value: float)

## The node wearing the material. Empty = this node's parent.
@export var target: NodePath
## Give the target its own copy of the material on ready, so other nodes sharing the same preset .tres do not age with it.
@export var make_unique := true
## Optional: a preset id to put on the target on ready (see Verdigris.ids()). Empty keeps the target's own material.
@export var preset := ""
## 0 = untouched, 1 = fully taken.
@export_range(0.0, 1.0, 0.001) var age := 0.0:
	set(value):
		age = clampf(value, 0.0, 1.0)
		_push()

var _tween: Tween


func _ready() -> void:
	var item := _item()
	if item == null:
		return
	if preset != "":
		Verdigris.apply(item, preset, age)
	elif make_unique and item.material is ShaderMaterial:
		item.material = item.material.duplicate()
	_push()


## Tweens the age to `value` over `seconds` and returns the Tween (await it, or listen for age_reached).
func age_to(value: float, seconds: float, trans := Tween.TRANS_SINE) -> Tween:
	if _tween and _tween.is_valid():
		_tween.kill()
	_tween = create_tween()
	_tween.tween_property(self, "age", clampf(value, 0.0, 1.0), maxf(seconds, 0.0)).set_trans(trans).set_ease(Tween.EASE_IN_OUT)
	_tween.finished.connect(func() -> void: age_reached.emit(age))
	return _tween


## Adds `delta` to the age (negative restores).
func age_by(delta: float) -> void:
	age = age + delta


## Maps a game value onto the age: `value` at `from` is 0, at `to` is 1 (days, damage, turns, water level...).
func drive(value: float, from: float, to: float) -> void:
	age = 0.0 if is_equal_approx(from, to) else inverse_lerp(from, to, value)


## Swaps the target to another preset, keeping the current age.
func set_preset(id: String) -> void:
	var item := _item()
	if item:
		preset = id
		Verdigris.apply(item, id, age)


func _item() -> CanvasItem:
	var n: Node = get_node_or_null(target) if not target.is_empty() else get_parent()
	return n as CanvasItem


func _push() -> void:
	if not is_inside_tree():
		return
	var item := _item()
	if item and item.material is ShaderMaterial:
		(item.material as ShaderMaterial).set_shader_parameter("age", age)
		aged.emit(age)
