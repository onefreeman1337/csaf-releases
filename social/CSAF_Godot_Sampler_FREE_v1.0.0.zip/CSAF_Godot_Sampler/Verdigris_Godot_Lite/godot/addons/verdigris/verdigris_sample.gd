@tool
class_name VerdigrisSample
extends Sprite2D
## A Verdigris preset preview: one of the pack's sample props wearing one preset material. The demo, the catalogue
## previews and CSAF's capture harness use these; in your own game you put the MATERIAL on your own sprite instead
## (Verdigris.apply(), or drag addons/verdigris/materials/<group>/<id>.tres onto the node's Material slot).
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

## The catalogue id of the preset this preview shows.
@export var preset_id := ""
## The age a still of this preview is taken at (-1 keeps the material's own age).
@export_range(-1.0, 1.0, 0.001) var preview_age := -1.0


## Freezes the preview on its showcase age with animation stopped, on a private copy of the material so the shared
## preset .tres is never edited. Called by CSAF's capture harness before it photographs each preset.
func csaf_preview() -> void:
	var m := material as ShaderMaterial
	if m == null:
		return
	m = m.duplicate() as ShaderMaterial
	m.set_shader_parameter("animate", 0.0)
	if preview_age >= 0.0:
		m.set_shader_parameter("age", preview_age)
	material = m
