# Verdigris Lite - 12 Free Material Ageing Shaders for Godot 4

Twelve real states from Verdigris, free under MIT: rust bloom, verdigris and gilding (corrosion), hoarfrost, snow cap and
icicles (frost), moss, ivy and mushrooms (growth), peeling paint, cracks and scorch (wear). Each one ages your own 2D art
while the game runs, grown by ONE number, `age`, from 0 (untouched) to 1 (fully taken), reading your sprite's own edges,
top faces and crevices. Nothing is painted in advance.

- **Godot version:** built and tested on **Godot 4.7.2**, under **both renderers: Forward+ and Compatibility**. Older
  4.x versions were NOT run, so they are not claimed.
- **The full pack** has 48 states (scale rust, tarnish, frozen solid, needle frost, lichen, barnacles, blight, petrify,
  crumble and more): https://csaf.itch.io/verdigris-godot

## Install

Copy `godot/addons/verdigris/` into your project's `addons/` folder. No plugin to enable.

## Use it

Drag a material from `res://addons/verdigris/materials/<group>/<id>.tres` onto the Material slot of a `Sprite2D`,
`AnimatedSprite2D`, `TileMapLayer` or `TextureRect`, then move its `age`. Or:

```gdscript
Verdigris.apply($Gate, "rust_bloom", 0.0)
var ager := VerdigrisAger.new()
$Gate.add_child(ager)
ager.age_to(1.0, 10.0)
```

The 12 ids: `rust_bloom`, `verdigris`, `gilded`, `hoarfrost`, `snow_cap`, `icicles`, `moss`, `ivy`, `mushrooms`,
`peeling_paint`, `cracks`, `scorch`. Shader parameters on every material: `age`, `amount`, `col_a` / `col_b` / `col_c`
(the recolour), `scale`, `reach`, `pixel_size` (1 for pixel art), `seed`, `animate`.

Leave a transparent border around art that should grow outward: `snow_cap`, `icicles` and `moss` draw into the empty pixels
around your sprite.

## Licence

MIT, see `LICENSE.txt`. AI-generated: the shaders, scenes and scripts were written by an AI.

Core Systems Asset Factory
