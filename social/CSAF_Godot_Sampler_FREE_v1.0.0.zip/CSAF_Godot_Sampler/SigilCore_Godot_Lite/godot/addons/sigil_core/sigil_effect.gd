@tool
class_name SigilEffect
extends Node2D
## One Sigil Core seal: a procedural magic circle with three states.
##
##   CAST   the seal draws itself on, layer by layer, over cast_time seconds, then HOLDS
##   HOLD   the layers counter-rotate and breathe until you break it or stop it
##   BREAK  the seal cracks by sector and scatters over break_time seconds, then hides
##
##   var seal: SigilEffect = SigilCatalog.instantiate("ember_03")
##   seal.position = caster.global_position
##   add_child(seal)            # autoplay casts it
##   ...
##   seal.break_seal()          # when the spell fires; free_when_broken removes it
##
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

## Emitted when the cast finishes drawing and the seal starts holding.
signal cast_finished
## Emitted when a break finishes.
signal broken

enum State { IDLE, CAST, HOLD, BREAK }

## Three colours: core (hottest line centre), mid (line body), edge (glow).
@export var palette: SigilPalette:
	set(value):
		if palette and palette.changed.is_connected(_apply_static):
			palette.changed.disconnect(_apply_static)
		palette = value
		if palette and not palette.changed.is_connected(_apply_static):
			palette.changed.connect(_apply_static)
		_apply_static()
## Seconds the cast takes to draw the seal on.
@export_range(0.05, 10.0, 0.01, "or_greater", "suffix:s") var cast_time := 1.2
## Seconds the break takes.
@export_range(0.05, 10.0, 0.01, "or_greater", "suffix:s") var break_time := 0.6
## Cast automatically when the node enters the tree (at runtime). Off = hidden until cast() or hold().
@export var autoplay := true
## Playback speed multiplier for every state.
@export_range(0.0, 4.0, 0.01, "or_greater") var speed_scale := 1.0
## Uniform size multiplier (sets the node scale).
@export_range(0.1, 8.0, 0.01, "or_greater") var effect_scale := 1.0:
	set(value):
		effect_scale = value
		scale = Vector2.ONE * value
## Brightness multiplier.
@export_range(0.0, 3.0, 0.01) var intensity := 1.0:
	set(value):
		intensity = value
		_apply_static()
## 1 = pure light (adds to the scene), 0 = normal blending (reads on bright backgrounds).
@export_range(0.0, 1.0, 0.01) var additive := 1.0:
	set(value):
		additive = value
		_apply_static()
## Rotation speed of the layers while holding (negative turns the other way).
@export_range(-2.0, 2.0, 0.01) var spin := 0.25:
	set(value):
		spin = value
		_apply_static()
## 1 = facing the camera; lower values lay the seal on the ground in perspective.
@export_range(0.2, 1.0, 0.01) var squash := 1.0:
	set(value):
		squash = value
		_apply_static()
## Free the node after a break.
@export var free_when_broken := false

@export_group("Preview")
## Seconds into the hold shown by seek_preview() and thumbnails.
@export_range(0.0, 10.0, 0.01) var preview_time := 0.8
## Animate the seal inside the editor viewport (cast, hold, break, repeat).
@export var editor_preview := true

var state: State = State.IDLE
var _t := 0.0
var _hold_t := 0.0
var _frozen := false
var _mats: Array[ShaderMaterial] = []


func _ready() -> void:
	_collect()
	_apply_static()
	if Engine.is_editor_hint():
		cast()
	elif autoplay:
		cast()
	else:
		visible = false


func _process(delta: float) -> void:
	if _frozen or state == State.IDLE:
		return
	var dt := delta * speed_scale
	_t += dt
	_hold_t += dt
	match state:
		State.CAST:
			if _t >= cast_time:
				_enter_hold()
				cast_finished.emit()
			else:
				_push(0, _t / maxf(cast_time, 0.001))
		State.HOLD:
			_push(1, 1.0)
			if Engine.is_editor_hint() and editor_preview and _t > 2.5:
				break_seal()
		State.BREAK:
			if _t >= break_time:
				_push(2, 1.0)
				state = State.IDLE
				visible = false
				broken.emit()
				if Engine.is_editor_hint() and editor_preview:
					cast()
				elif free_when_broken:
					queue_free()
			else:
				_push(2, _t / maxf(break_time, 0.001))


## Draw the seal on from nothing, then hold.
func cast() -> void:
	_collect()
	state = State.CAST
	_t = 0.0
	_hold_t = 0.0
	_frozen = false
	visible = true
	_push(0, 0.0)


## Show the seal fully drawn and holding, skipping the cast.
func hold() -> void:
	_collect()
	visible = true
	_frozen = false
	_enter_hold()


## Crack and scatter the seal, then hide it (and free it if free_when_broken).
func break_seal() -> void:
	if state == State.IDLE:
		return
	state = State.BREAK
	_t = 0.0
	_frozen = false


## Hide immediately.
func stop() -> void:
	state = State.IDLE
	_frozen = false
	visible = false


func is_active() -> bool:
	return state != State.IDLE


## Freeze on a moment: state CAST/HOLD/BREAK at fraction (cast, break) or seconds into the hold.
func seek(to_state: State, amount: float) -> void:
	_collect()
	visible = true
	_frozen = true
	state = to_state
	match to_state:
		State.CAST:
			_push(0, clampf(amount, 0.0, 1.0))
		State.BREAK:
			_push(2, clampf(amount, 0.0, 1.0))
		_:
			_hold_t = maxf(amount, 0.0)
			_push(1, 1.0)


## Freeze on the showcase frame (holding, preview_time seconds in).
func seek_preview() -> void:
	seek(State.HOLD, preview_time)


## Alias of seek_preview(), called by CSAF's capture harness when it photographs each preset.
func csaf_preview() -> void:
	seek_preview()


func _enter_hold() -> void:
	state = State.HOLD
	_t = 0.0
	_push(1, 1.0)


func _push(ph: int, pr: float) -> void:
	for m in _mats:
		RenderingServer.material_set_param(m.get_rid(), &"phase", ph)
		RenderingServer.material_set_param(m.get_rid(), &"progress", pr)
		RenderingServer.material_set_param(m.get_rid(), &"sc_time", _hold_t)


func _collect() -> void:
	_mats.clear()
	if not is_inside_tree():
		return
	for c in find_children("*", "CanvasItem", true, false):
		var ci := c as CanvasItem
		if ci and ci.material is ShaderMaterial:
			_mats.append(ci.material as ShaderMaterial)


func _apply_static() -> void:
	if not is_inside_tree():
		return
	if _mats.is_empty():
		_collect()
	for m in _mats:
		var rid := m.get_rid()
		RenderingServer.material_set_param(rid, &"intensity", intensity)
		RenderingServer.material_set_param(rid, &"additive", additive)
		RenderingServer.material_set_param(rid, &"spin", spin)
		RenderingServer.material_set_param(rid, &"squash", squash)
		if palette:
			RenderingServer.material_set_param(rid, &"core_color", palette.core)
			RenderingServer.material_set_param(rid, &"mid_color", palette.mid)
			RenderingServer.material_set_param(rid, &"edge_color", palette.edge)
