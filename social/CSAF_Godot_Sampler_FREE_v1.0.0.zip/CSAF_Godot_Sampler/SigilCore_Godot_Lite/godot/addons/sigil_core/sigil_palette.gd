@tool
class_name SigilPalette
extends Resource
## Three colours that recolour any Sigil Core seal: core (line centre), mid (line body), edge (glow and fill).
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

@export var core := Color(1.0, 0.95, 0.82):
	set(value):
		core = value
		emit_changed()
@export var mid := Color(1.0, 0.62, 0.25):
	set(value):
		mid = value
		emit_changed()
@export var edge := Color(0.75, 0.25, 0.08):
	set(value):
		edge = value
		emit_changed()


## A copy with every colour shifted round the hue wheel (0..1).
func hue_shifted(amount: float) -> SigilPalette:
	var p := SigilPalette.new()
	p.core = _shift(core, amount)
	p.mid = _shift(mid, amount)
	p.edge = _shift(edge, amount)
	return p


static func _shift(c: Color, amount: float) -> Color:
	return Color.from_hsv(fposmod(c.h + amount, 1.0), c.s, c.v, c.a)
