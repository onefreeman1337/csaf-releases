class_name SigilCatalog
extends RefCounted
## Every Sigil Core seal, by id. Generated from the pack's spec table; do not edit by hand.
##
##   var seal := SigilCatalog.instantiate("tide_04")
##   seal.position = where
##   add_child(seal)
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

const SCHOOLS: Array[String] = ["ember", "tide"]
const SEALS: Array[Dictionary] = [
	{"id": "ember_01", "school": "ember", "name": "Kindle", "path": "res://addons/sigil_core/seals/ember/ember_01.tscn"},
	{"id": "ember_02", "school": "ember", "name": "Pyre Ward", "path": "res://addons/sigil_core/seals/ember/ember_02.tscn"},
	{"id": "ember_03", "school": "ember", "name": "Cinder Oath", "path": "res://addons/sigil_core/seals/ember/ember_03.tscn"},
	{"id": "ember_04", "school": "ember", "name": "Ashen Crown", "path": "res://addons/sigil_core/seals/ember/ember_04.tscn"},
	{"id": "ember_05", "school": "ember", "name": "Brand", "path": "res://addons/sigil_core/seals/ember/ember_05.tscn"},
	{"id": "ember_06", "school": "ember", "name": "Hearth Seal", "path": "res://addons/sigil_core/seals/ember/ember_06.tscn"},
	{"id": "tide_01", "school": "tide", "name": "Undertow", "path": "res://addons/sigil_core/seals/tide/tide_01.tscn"},
	{"id": "tide_02", "school": "tide", "name": "Tidewall", "path": "res://addons/sigil_core/seals/tide/tide_02.tscn"},
	{"id": "tide_03", "school": "tide", "name": "Brine Lock", "path": "res://addons/sigil_core/seals/tide/tide_03.tscn"},
	{"id": "tide_04", "school": "tide", "name": "Fathom", "path": "res://addons/sigil_core/seals/tide/tide_04.tscn"},
	{"id": "tide_05", "school": "tide", "name": "Riptide", "path": "res://addons/sigil_core/seals/tide/tide_05.tscn"},
	{"id": "tide_06", "school": "tide", "name": "Still Water", "path": "res://addons/sigil_core/seals/tide/tide_06.tscn"},
]


## The scene path of a seal id ("" when unknown).
static func path_of(id: String) -> String:
	for s in SEALS:
		if s["id"] == id:
			return s["path"]
	return ""


## A new instance of a seal, or null when the id is unknown.
static func instantiate(id: String) -> SigilEffect:
	var path := path_of(id)
	if path == "":
		push_warning("Sigil Core: no seal named %s" % id)
		return null
	return (load(path) as PackedScene).instantiate() as SigilEffect


## Every seal id of one school.
static func ids_for_school(school: String) -> Array[String]:
	var out: Array[String] = []
	for s in SEALS:
		if s["school"] == school:
			out.append(s["id"])
	return out
