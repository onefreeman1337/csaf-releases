extends Node2D
## Sigil Core demo browser. Run demo/demo.tscn (the project's main scene).
##
##   Left / Right   previous / next school          Tab   one school (10 seals) or all 60 at once
##   C              cast every seal on screen        B     break every seal on screen
##   H              hold every seal on its showcase frame (H again to play)
##   P              cycle the palette                Click cast the seal under the mouse at the mouse
##   F12            save a screenshot to user://
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

const PALETTE_DIR := "res://addons/sigil_core/palettes/"
const TOP := 96.0
const BOTTOM := 56.0
const MARGIN := 24.0

var _all_view := false
var _school := 0
var _palette := -1
var _hold := false
var _cells: Array[Dictionary] = []
var _labels: Array[Label] = []
var _ui: CanvasLayer
var _title: Label
var _sub: Label
var _hint: Label


func _ready() -> void:
	_ui = CanvasLayer.new()
	add_child(_ui)
	_title = _label(30, Color(1.0, 0.92, 0.78))
	_title.position = Vector2(MARGIN, 14)
	_sub = _label(16, Color(0.7, 0.72, 0.82))
	_sub.position = Vector2(MARGIN, 56)
	_hint = _label(14, Color(0.55, 0.57, 0.66))
	_rebuild()
	get_viewport().size_changed.connect(_rebuild)


func _label(size: int, colour: Color) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", colour)
	l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.6))
	l.add_theme_constant_override("shadow_offset_y", 2)
	_ui.add_child(l)
	return l


func _ids() -> Array[String]:
	if _all_view:
		var all: Array[String] = []
		for s in SigilCatalog.SEALS:
			all.append(s["id"])
		return all
	return SigilCatalog.ids_for_school(SigilCatalog.SCHOOLS[_school])


func _name_of(id: String) -> String:
	for s in SigilCatalog.SEALS:
		if s["id"] == id:
			return s["name"]
	return id


func _rebuild() -> void:
	for c in _cells:
		(c["fx"] as Node).queue_free()
	for l in _labels:
		l.queue_free()
	_cells.clear()
	_labels.clear()
	var view := get_viewport_rect().size
	var ids := _ids()
	var g := Vector2i(10, 6) if _all_view else Vector2i(5, 2)
	var cw := (view.x - MARGIN * 2.0) / g.x
	var ch := (view.y - TOP - BOTTOM) / g.y
	for i in ids.size():
		var cell := Rect2(MARGIN + (i % g.x) * cw, TOP + int(i / g.x) * ch, cw, ch)
		var fx := SigilCatalog.instantiate(ids[i])
		if fx == null:
			continue
		var s := minf((cell.size.x - 12.0) / 300.0, (cell.size.y - (12.0 if _all_view else 34.0)) / 300.0)
		fx.effect_scale = s
		fx.position = cell.get_center() + Vector2(0, 0 if _all_view else -10)
		add_child(fx)
		_apply_palette(fx)
		if _hold:
			fx.seek_preview()
		_cells.append({"fx": fx, "rect": cell, "id": ids[i]})
		if not _all_view:
			var l := _label(14, Color(0.78, 0.8, 0.88))
			l.text = "%s  ·  %s" % [_name_of(ids[i]), ids[i]]
			l.position = cell.position + Vector2(8, cell.size.y - 24)
			_labels.append(l)
	var sch: String = SigilCatalog.SCHOOLS[_school]
	_title.text = "Sigil Core  ·  %s" % ("all %d seals" % ids.size() if _all_view else sch.capitalize())
	_sub.text = "every school, every seal" if _all_view else "school %d of %d  ·  10 seals" % [_school + 1, SigilCatalog.SCHOOLS.size()]
	_hint.text = "Left/Right school   Tab all   C cast   B break   H hold%s   P palette (%s)   Click cast   F12 screenshot" % [" (on)" if _hold else "", _palette_name()]
	_hint.position = Vector2(MARGIN, view.y - 34)
	queue_redraw()


func _palette_name() -> String:
	return "school" if _palette < 0 else String(SigilCatalog.SCHOOLS[_palette])


func _apply_palette(fx: SigilEffect) -> void:
	if _palette < 0:
		return
	var p := load(PALETTE_DIR + String(SigilCatalog.SCHOOLS[_palette]) + ".tres") as SigilPalette
	if p:
		fx.palette = p


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		match (event as InputEventKey).keycode:
			KEY_RIGHT:
				_school = posmod(_school + 1, SigilCatalog.SCHOOLS.size())
				_rebuild()
			KEY_LEFT:
				_school = posmod(_school - 1, SigilCatalog.SCHOOLS.size())
				_rebuild()
			KEY_TAB:
				_all_view = not _all_view
				_rebuild()
			KEY_C:
				_hold = false
				for c in _cells:
					(c["fx"] as SigilEffect).cast()
			KEY_B:
				for c in _cells:
					(c["fx"] as SigilEffect).break_seal()
			KEY_H:
				_hold = not _hold
				_rebuild()
			KEY_P:
				_palette += 1
				if _palette >= SigilCatalog.SCHOOLS.size():
					_palette = -1
				_rebuild()
			KEY_F12:
				var img := get_viewport().get_texture().get_image()
				var f := "user://sigil_core_%s.png" % Time.get_datetime_string_from_system().replace(":", "-")
				img.save_png(f)
				print("Sigil Core: saved ", ProjectSettings.globalize_path(f))
	elif event is InputEventMouseButton and event.pressed and (event as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT:
		var at := (event as InputEventMouseButton).position
		for c in _cells:
			if (c["rect"] as Rect2).has_point(at):
				var fx := SigilCatalog.instantiate(c["id"])
				fx.position = at
				fx.free_when_broken = true
				add_child(fx)
				_apply_palette(fx)
				get_tree().create_timer(fx.cast_time + 0.8).timeout.connect(fx.break_seal)
				return


func _draw() -> void:
	var view := get_viewport_rect().size
	var bands := 24
	for i in bands:
		var t := float(i) / bands
		draw_rect(Rect2(0, view.y * t, view.x, view.y / bands + 1.0), Color(0.07, 0.065, 0.1).lerp(Color(0.03, 0.03, 0.045), t))
	draw_line(Vector2(MARGIN, TOP - 10), Vector2(view.x - MARGIN, TOP - 10), Color(1.0, 0.75, 0.4, 0.35), 2.0)
	for c in _cells:
		var r: Rect2 = c["rect"]
		draw_rect(r.grow(-5.0), Color(1, 1, 1, 0.022), true)
		draw_rect(r.grow(-5.0), Color(1, 1, 1, 0.06), false, 1.0)
