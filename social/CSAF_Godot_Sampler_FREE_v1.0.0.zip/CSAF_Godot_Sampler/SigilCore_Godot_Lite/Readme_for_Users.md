# Sigil Core Lite - 12 free magic circles for Godot 4

A free, MIT-licensed sampler of Sigil Core for Godot 4: 12 real seals from the full pack (six Ember, six Tide). Each seal
is drawn live by a shader and casts (draws itself on), holds (layers counter-rotate) and breaks.

- **Godot version:** built and tested on **Godot 4.7.2**, under **both renderers: Forward+ and Compatibility**. Older 4.x
  versions were NOT run.
- **Seals:** `ember_01` to `ember_06`, `tide_01` to `tide_06`.
- **What the lite leaves out:** the rune bands (the ring of glyphs) and the shattering break are stripped from this
  lite's shader; here a break fades the seal out. They are in the full pack.

## Install

Copy `godot/addons/sigil_core/` into your project's `addons/` folder. No plugin to enable.

```gdscript
var seal := SigilCatalog.instantiate("ember_01")
seal.position = where
add_child(seal)        # casts on its own
seal.break_seal()      # later
```

Open `godot/` as a project and press Play for the demo.

## The full pack

**Sigil Core for Godot 4** has 60 seals in six schools (Ember, Tide, Gale, Stone, Radiance, Umbra), rune bands, the
shattering break and the same API: https://csaf.itch.io/sigil-core-godot

## Licence

MIT (see `LICENSE.txt`). This lite is AI-generated: the shader, scenes and scripts were written by an AI.

Core Systems Asset Factory
