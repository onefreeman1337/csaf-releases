# Cartography Lite - 12 free journey map styles for Godot 4

Twelve real styles from **Cartography - Journey Maps Drawn as the Player Travels, for Godot 4**, free under the MIT
licence. A recorder follows your player and remembers every cell they have seen, the road they walked and the places they
found; a map Control draws that as a finished sheet, and the unexplored part stays blank paper with a ragged edge that
moves as they walk. Paper, coasts, hatching, symbols, compass roses, frames and lettering are all drawn by code.

- **Godot version:** built and tested on **Godot 4.7.2**, under **both renderers: Forward+ and Compatibility**. Older 4.x
  versions were NOT run, so they are not claimed.
- **The 12 styles:** survey `explorers_parchment`, `royal_atlas`, `treasure_map` · sea charts `admiralty_chart`,
  `portolan`, `pirate_chart` · dungeon plans `graph_paper`, `blueprint`, `crypt` · arcane `star_chart`,
  `pixel_overworld`, `dreamscape`.

## Install

Copy `godot/addons/cartography/` into your project's `addons/` folder. No plugin to enable. Keep the folder name: the
styles reference `res://addons/cartography/` by path. To browse first, open `godot/` as a project and press Play
(Left / Right: style, Tab: island / dungeon, WASD: walk, Space: pause, R: set out again, E: export a PNG).

## Use it

```gdscript
var rec := CartographyRecorder.new()
rec.journey = CartographyJourney.new()
rec.tile_layer = $World/Ground                    # optional: kinds come from a "map_kind" custom data layer
$Player.add_child(rec)                            # records while the player moves

var map := CartographyMap.new()
map.size = Vector2(800, 520)
map.journey = rec.journey
map.style = Cartography.style("explorers_parchment")
$PauseMenu.add_child(map)

await map.export_png("user://my_journey.png")     # the player's map as a PNG
```

The classes are the same as the full pack's (`CartographyJourney`, `CartographyRecorder`, `CartographyMap`,
`CartographyStyle`, `CartographyLettering`, `CartographyDraw`, `CartographySample`, `Cartography`), but this copy only
contains the drawing code these twelve styles use: a style property set to a value none of them uses falls back to the
plainest drawing.

The full pack has 48 styles in four families (survey, sea charts, dungeon plans, arcane and modern):
https://csaf.itch.io/cartography-godot
