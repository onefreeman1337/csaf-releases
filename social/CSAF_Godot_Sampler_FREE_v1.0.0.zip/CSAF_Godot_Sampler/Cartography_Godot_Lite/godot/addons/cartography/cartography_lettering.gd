class_name CartographyLettering
extends RefCounted
## Map lettering drawn as ink strokes (no font file). Capitals, digits and common punctuation are single-stroke
## glyphs on a 4 x 6 grid; lower case is set as small capitals, the way survey maps letter names.
## Hands: 0 engraved capitals, 1 italic, 2 stencil, 3 pixel, 4 brush.
##   CartographyLettering.draw_text(canvas_item, "Port Ashen", Vector2(40, 60), 10.0, Color.BLACK, 0)
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

const GLYPHS := {
	"A": "0,6 2,0 4,6;0.8,3.8 3.2,3.8",
	"B": "0,6 0,0 2.8,0 3.6,0.7 3.6,2.2 2.8,3 0,3;2.8,3 3.8,3.8 3.8,5.2 3,6 0,6",
	"C": "4,1 3,0 1,0 0,1.2 0,4.8 1,6 3,6 4,5",
	"D": "0,0 0,6 2.4,6 3.6,5 4,3.5 4,2.5 3.6,1 2.4,0 0,0",
	"E": "3.8,0 0,0 0,6 3.8,6;0,3 2.6,3",
	"F": "3.8,0 0,0 0,6;0,3 2.6,3",
	"G": "4,1 3,0 1,0 0,1.2 0,4.8 1,6 3,6 4,5 4,3.4 2.4,3.4",
	"H": "0,0 0,6;4,0 4,6;0,3 4,3",
	"I": "1,0 1,6;0,0 2,0;0,6 2,6",
	"J": "3.5,0 3.5,4.8 2.5,6 1,6 0,5",
	"K": "0,0 0,6;4,0 0,3.6;1.4,2.6 4,6",
	"L": "0,0 0,6 3.6,6",
	"M": "0,6 0,0 2.5,4 5,0 5,6",
	"N": "0,6 0,0 4,6 4,0",
	"O": "1,0 3,0 4,1.2 4,4.8 3,6 1,6 0,4.8 0,1.2 1,0",
	"P": "0,6 0,0 3,0 4,0.9 4,2.3 3,3.2 0,3.2",
	"Q": "1,0 3,0 4,1.2 4,4.8 3,6 1,6 0,4.8 0,1.2 1,0;2.4,4.4 4.2,6.4",
	"R": "0,6 0,0 3,0 4,0.9 4,2.3 3,3.2 0,3.2;2,3.2 4,6",
	"S": "4,1 3,0 1,0 0,1 0,2.2 1,3 3,3 4,3.8 4,5 3,6 1,6 0,5",
	"T": "0,0 4,0;2,0 2,6",
	"U": "0,0 0,4.8 1,6 3,6 4,4.8 4,0",
	"V": "0,0 2,6 4,0",
	"W": "0,0 1.2,6 2.5,2 3.8,6 5,0",
	"X": "0,0 4,6;4,0 0,6",
	"Y": "0,0 2,3 4,0;2,3 2,6",
	"Z": "0,0 4,0 0,6 4,6",
	"0": "1,0 2.5,0 3.5,1.2 3.5,4.8 2.5,6 1,6 0,4.8 0,1.2 1,0",
	"1": "0.4,1.2 1.6,0 1.6,6;0.4,6 2.6,6",
	"2": "0,1.2 1,0 3,0 4,1 4,2.2 0,6 4,6",
	"3": "0,0.8 1,0 3,0 4,1 4,2 3,3 1.6,3;3,3 4,4 4,5 3,6 1,6 0,5.2",
	"4": "3,6 3,0 0,4.2 4,4.2",
	"5": "4,0 0.4,0 0,2.8 2.8,2.6 4,3.6 4,5 3,6 1,6 0,5.2",
	"6": "3.6,0.6 2.6,0 1,0 0,1.4 0,4.8 1,6 3,6 4,5 4,3.8 3,3 1,3 0,3.8",
	"7": "0,0 4,0 1.4,6",
	"8": "1,0 3,0 4,0.8 4,2.2 3,3 1,3 0,2.2 0,0.8 1,0;1,3 0,3.9 0,5.1 1,6 3,6 4,5.1 4,3.9 3,3",
	"9": "4,2.2 3,3 1,3 0,2.2 0,1 1,0 3,0 4,1.2 4,4.6 3,6 1,6 0.4,5.4",
	".": "0.5,5.5 0.5,6",
	",": "0.6,5.5 0.6,6 0.1,6.8",
	"'": "0.5,0 0.5,1.4",
	"-": "0,3.4 3,3.4",
	"!": "0.5,0 0.5,4.2;0.5,5.5 0.5,6",
	"?": "0,1 1,0 3,0 4,1 4,2 2,3.4 2,4.4;2,5.5 2,6",
	":": "0.5,1.8 0.5,2.3;0.5,5.5 0.5,6",
	"/": "3,0 0,6",
	"&": "4,6 0.6,2 0.6,0.9 1.5,0 2.6,0 3.2,0.9 3.2,1.8 0,4.2 0,5.2 1,6 2.4,6 4,3.6",
}
const WIDTHS := {"I": 2.0, "M": 5.0, "W": 5.0, "0": 3.5, "1": 2.6, ".": 1.0, ",": 1.0, "'": 1.0, "!": 1.0, ":": 1.0, "-": 3.0, "/": 3.0}
const SPACE := 2.6

static var _cache := {}


## The strokes of one glyph in grid units (x 0..width, y 0..6, y down), or [] for unknown characters.
static func glyph(ch: String) -> Array:
	if _cache.has(ch):
		return _cache[ch]
	var out := []
	var src: String = GLYPHS.get(ch, "")
	if src != "":
		for stroke in src.split(";"):
			var pts := PackedVector2Array()
			for pair in stroke.strip_edges().split(" "):
				var xy := pair.split(",")
				if xy.size() == 2:
					pts.append(Vector2(float(xy[0]), float(xy[1])))
			if pts.size() >= 2:
				out.append(pts)
	_cache[ch] = out
	return out


static func _advance(ch: String) -> float:
	if ch == " ":
		return SPACE
	return float(WIDTHS.get(ch, 4.0))


static func _tracking(mode: int) -> float:
	match mode:
		2:
			return 2.0
		3:
			return 1.5
		_:
			return 1.4


## The width in pixels of `text` at cap height `size`.
static func measure(text: String, size: float, mode: int = 0) -> float:
	var u := size / 6.0
	var w := 0.0
	var n := 0
	for i in text.length():
		var ch := text[i]
		var small := ch != ch.to_upper()
		var s := 0.78 if small else 1.0
		w += (_advance(ch.to_upper()) + _tracking(mode)) * u * s
		n += 1
	return maxf(0.0, w - _tracking(mode) * u)


## Draws `text` with its baseline-left corner at `pos`. `halo` (alpha > 0) draws a wider stroke first so the
## letters read over hatching. `align` 0 left, 1 centre, 2 right.
static func draw_text(ci: CanvasItem, text: String, pos: Vector2, size: float, color: Color, mode: int = 0, halo := Color(0, 0, 0, 0), align := 0, wobble := 0.0, seed := 1) -> void:
	var u := size / 6.0
	var x := pos.x
	if align == 1:
		x -= measure(text, size, mode) * 0.5
	elif align == 2:
		x -= measure(text, size, mode)
	var weight := _weight(mode, size)
	var slant := 0.24 if mode == 1 else 0.0
	var jobs := []
	for i in text.length():
		var ch := text[i]
		var up := ch.to_upper()
		var small := ch != up
		var s := 0.78 if small else 1.0
		var gu := u * s
		var base := Vector2(x, pos.y)
		for stroke: PackedVector2Array in glyph(up):
			var pts := PackedVector2Array()
			for k in stroke.size():
				var g := stroke[k]
				var p := base + Vector2(g.x * gu + (6.0 - g.y) * gu * slant, (g.y - 6.0) * gu)
				if wobble > 0.0:
					var h := float(posmod(hash(Vector3i(i, k, seed)), 1000)) / 1000.0 - 0.5
					var h2 := float(posmod(hash(Vector3i(k, i, seed + 7)), 1000)) / 1000.0 - 0.5
					p += Vector2(h, h2) * wobble * gu * 0.5
				pts.append(p)
			jobs.append(pts)
		x += (_advance(up) + _tracking(mode)) * gu
	if mode == 3:
		_draw_pixel(ci, jobs, u, color, halo)
		return
	if halo.a > 0.0:
		for pts in jobs:
			_stroke(ci, pts, halo, weight + maxf(2.0, size * 0.28), mode)
	for pts in jobs:
		_stroke(ci, pts, color, weight, mode)


static func _weight(mode: int, size: float) -> float:
	match mode:
		1:
			return maxf(1.0, size * 0.12)
		2:
			return maxf(1.2, size * 0.17)
		4:
			return maxf(1.4, size * 0.22)
		_:
			return maxf(0.9, size * 0.1)


static func _stroke(ci: CanvasItem, pts: PackedVector2Array, color: Color, w: float, mode: int) -> void:
	if pts.size() == 2 and pts[0].distance_to(pts[1]) < 0.01:
		ci.draw_circle(pts[0], w * 0.6, color)
		return
	ci.draw_polyline(pts, color, w, true)
	if mode == 4 or mode == 2:
		ci.draw_circle(pts[0], w * 0.5, color)
		ci.draw_circle(pts[pts.size() - 1], w * 0.5, color)


static func _draw_pixel(ci: CanvasItem, jobs: Array, u: float, color: Color, halo: Color) -> void:
	var cell := maxf(1.0, roundf(u))
	var seen := {}
	var cells := []
	for pts: PackedVector2Array in jobs:
		for k in pts.size() - 1:
			var a := pts[k]
			var b := pts[k + 1]
			var steps := int(ceilf(a.distance_to(b) / (cell * 0.5))) + 1
			for s in steps + 1:
				var p := a.lerp(b, float(s) / float(steps))
				var c := Vector2i(floori(p.x / cell), floori(p.y / cell))
				if not seen.has(c):
					seen[c] = true
					cells.append(c)
	if halo.a > 0.0:
		for c: Vector2i in cells:
			ci.draw_rect(Rect2(Vector2(c) * cell - Vector2.ONE * cell, Vector2.ONE * cell * 3.0), halo)
	for c: Vector2i in cells:
		ci.draw_rect(Rect2(Vector2(c) * cell, Vector2.ONE * cell), color)
