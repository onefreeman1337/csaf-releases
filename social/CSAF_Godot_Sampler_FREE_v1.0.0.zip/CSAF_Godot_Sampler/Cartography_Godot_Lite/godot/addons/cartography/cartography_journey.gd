@tool
class_name CartographyJourney
extends Resource
## What the player has seen: revealed map cells (each with a terrain kind), the route walked, and named places.
## A CartographyRecorder fills one in as the player moves; a CartographyMap draws it in any CartographyStyle.
## It is a plain Resource, so ResourceSaver.save() works, and to_dict() / from_dict() give a JSON-safe copy for save files.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

## Terrain kinds a cell can hold. GROUND is any walkable open land or floor; WALL is solid rock or a building wall.
enum Kind { VOID = 0, GROUND = 1, WATER = 2, DEEP = 3, FOREST = 4, MOUNTAIN = 5, SAND = 6, SNOW = 7, WALL = 8, FLOOR = 9 }

## Place kinds, each drawn with its own map icon.
enum Place { TOWN = 0, CASTLE = 1, CAVE = 2, RUIN = 3, CAMP = 4, PORT = 5, SHRINE = 6, TREASURE = 7, PEAK = 8, DANGER = 9, DOOR = 10, STAIRS = 11 }

const KIND_NAMES := ["void", "ground", "water", "deep", "forest", "mountain", "sand", "snow", "wall", "floor"]
const PLACE_NAMES := ["town", "castle", "cave", "ruin", "camp", "port", "shrine", "treasure", "peak", "danger", "door", "stairs"]

## Size of one map cell in world pixels (a TileMapLayer's tile size is the natural choice).
@export var cell_size := 16.0
## The map's title, lettered in the cartouche.
@export var title := "The Journey"
## Revealed cells: Vector2i cell -> Kind.
@export var cells: Dictionary[Vector2i, int] = {}
## The route walked, in world pixels, oldest first.
@export var route := PackedVector2Array()
## Named places: each {"name": String, "position": Vector2 (world px), "kind": Place}.
@export var places: Array[Dictionary] = []
## Region names lettered large across the map once their spot is revealed: each {"name": String, "position": Vector2}.
@export var areas: Array[Dictionary] = []

var _bounds := Rect2i()
var _bounds_valid := false
var _revision := 0
# append-only log of revealed cells (x, y pairs) so a map can redraw only what is new; _epoch changes on clear/load
var _log := PackedInt32Array()
var _epoch := 0


## True once at least one cell is revealed.
func is_empty() -> bool:
	return cells.is_empty()


## A counter that rises on every change; a CartographyMap compares it to know when to redraw.
func revision() -> int:
	return _revision


## Reveals one cell as `kind`. Returns true if anything changed.
func reveal(cell: Vector2i, kind: int) -> bool:
	if cells.get(cell, -1) == kind:
		return false
	cells[cell] = kind
	_log.append(cell.x)
	_log.append(cell.y)
	if _bounds_valid:
		_bounds = Rect2i(cell, Vector2i.ONE) if cells.size() == 1 else _bounds.merge(Rect2i(cell, Vector2i.ONE))
	_touch()
	return true


## Reveals a filled circle of cells around `center` (cells), asking `kind_at` (Callable(Vector2i) -> int) for each kind.
## Returns how many cells changed.
func reveal_circle(center: Vector2i, radius: int, kind_at: Callable) -> int:
	var n := 0
	var r2 := radius * radius + radius
	for y in range(-radius, radius + 1):
		for x in range(-radius, radius + 1):
			if x * x + y * y > r2:
				continue
			var c := center + Vector2i(x, y)
			if cells.has(c):
				continue
			cells[c] = int(kind_at.call(c))
			_log.append(c.x)
			_log.append(c.y)
			n += 1
	if n > 0:
		_bounds_valid = false
		_touch()
	return n


## How many reveals have been logged since the last clear/load (a map reads the log to redraw only new cells).
func log_size() -> int:
	return _log.size() / 2


## The cell of logged reveal `i`.
func log_cell(i: int) -> Vector2i:
	return Vector2i(_log[i * 2], _log[i * 2 + 1])


## Changes whenever the journey is cleared or loaded (a map then rebuilds from scratch).
func epoch() -> int:
	return _epoch


## The kind of a revealed cell, or -1 when the cell is unexplored.
func kind_at(cell: Vector2i) -> int:
	return cells.get(cell, -1)


## True when `cell` has been revealed.
func is_revealed(cell: Vector2i) -> bool:
	return cells.has(cell)


## Appends a route point (world px). Points closer than `min_step` to the last one are skipped.
func add_route_point(p: Vector2, min_step := 0.0) -> bool:
	if route.size() > 0 and route[route.size() - 1].distance_to(p) < min_step:
		return false
	route.append(p)
	_touch()
	return true


## Adds or renames a place at a world position.
func add_place(place_name: String, world_position: Vector2, kind: int = Place.TOWN) -> void:
	for p in places:
		if Vector2(p.get("position", Vector2.INF)).distance_to(world_position) < cell_size * 0.5:
			p["name"] = place_name
			p["kind"] = kind
			_touch()
			return
	places.append({"name": place_name, "position": world_position, "kind": kind})
	_touch()


## Names a region (a forest, a sea, a wing of a dungeon). It is lettered once the cell under it is revealed.
func add_area(area_name: String, world_position: Vector2) -> void:
	areas.append({"name": area_name, "position": world_position})
	_touch()


## The bounding rectangle of every revealed cell (cells).
func bounds() -> Rect2i:
	if _bounds_valid:
		return _bounds
	var first := true
	var r := Rect2i()
	for c: Vector2i in cells:
		if first:
			r = Rect2i(c, Vector2i.ONE)
			first = false
		else:
			r = r.merge(Rect2i(c, Vector2i.ONE))
	_bounds = r
	_bounds_valid = true
	return r


## Converts a world position to its cell.
func world_to_cell(p: Vector2) -> Vector2i:
	return Vector2i(floori(p.x / cell_size), floori(p.y / cell_size))


## Forgets everything.
func clear() -> void:
	cells.clear()
	route.clear()
	places.clear()
	areas.clear()
	_log.clear()
	_epoch += 1
	_bounds_valid = false
	_touch()


## A JSON-safe copy (for a save file).
func to_dict() -> Dictionary:
	var flat := PackedInt32Array()
	for c: Vector2i in cells:
		flat.append(c.x)
		flat.append(c.y)
		flat.append(int(cells[c]))
	var pts := []
	for p in route:
		pts.append([snappedf(p.x, 0.1), snappedf(p.y, 0.1)])
	var pl := []
	for p in places:
		var pos := Vector2(p.get("position", Vector2.ZERO))
		pl.append({"name": str(p.get("name", "")), "x": pos.x, "y": pos.y, "kind": int(p.get("kind", 0))})
	var ar := []
	for a in areas:
		var pos := Vector2(a.get("position", Vector2.ZERO))
		ar.append({"name": str(a.get("name", "")), "x": pos.x, "y": pos.y})
	return {"format": "cartography/1", "cell_size": cell_size, "title": title, "cells": Array(flat), "route": pts, "places": pl, "areas": ar}


## Restores from to_dict(). Unknown or damaged fields are skipped, never fatal.
func from_dict(d: Dictionary) -> void:
	cells.clear()
	route.clear()
	places.clear()
	areas.clear()
	var cs := _num(d.get("cell_size"), cell_size)
	cell_size = cs if cs > 0.0 else cell_size
	if d.get("title") is String:
		title = d["title"]
	var flat: Variant = d.get("cells")
	if flat is Array:
		for i in range(0, flat.size() - 2, 3):
			if _is_num(flat[i]) and _is_num(flat[i + 1]) and _is_num(flat[i + 2]):
				cells[Vector2i(int(flat[i]), int(flat[i + 1]))] = clampi(int(flat[i + 2]), 0, Kind.FLOOR)
	var rt: Variant = d.get("route")
	if rt is Array:
		for p in rt:
			if p is Array and p.size() >= 2 and _is_num(p[0]) and _is_num(p[1]):
				route.append(Vector2(float(p[0]), float(p[1])))
	var pl: Variant = d.get("places")
	if pl is Array:
		for p in pl:
			if p is Dictionary:
				places.append({"name": str(p.get("name", "")), "position": Vector2(_num(p.get("x"), 0.0), _num(p.get("y"), 0.0)), "kind": clampi(int(_num(p.get("kind"), 0.0)), 0, Place.STAIRS)})
	var ar: Variant = d.get("areas")
	if ar is Array:
		for a in ar:
			if a is Dictionary:
				areas.append({"name": str(a.get("name", "")), "position": Vector2(_num(a.get("x"), 0.0), _num(a.get("y"), 0.0))})
	_log.clear()
	_epoch += 1
	_bounds_valid = false
	_touch()


## Writes the journey as JSON to `path` (user:// or res://). Returns an Error.
func save_json(path: String) -> Error:
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		return FileAccess.get_open_error()
	f.store_string(JSON.stringify(to_dict()))
	return OK


## Reads a journey written by save_json(). Returns an Error.
func load_json(path: String) -> Error:
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return FileAccess.get_open_error()
	var v: Variant = JSON.parse_string(f.get_as_text())
	if typeof(v) != TYPE_DICTIONARY:
		return ERR_PARSE_ERROR
	from_dict(v)
	return OK


static func _is_num(v: Variant) -> bool:
	return typeof(v) == TYPE_INT or typeof(v) == TYPE_FLOAT


static func _num(v: Variant, fallback: float) -> float:
	return float(v) if _is_num(v) else fallback


func _touch() -> void:
	_revision += 1
	emit_changed()
