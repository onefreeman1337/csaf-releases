@tool
extends Node2D
## The scene every Cartography preset ships as: one map sheet in one style over a sample journey, centred on this
## node. Open any presets/*.tscn in the editor to see the style; the .tres beside it is what you reuse.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

@export var style: CartographyStyle
## 0 the island realm, 1 the dungeon.
@export_enum("Island realm", "Dungeon") var sample := 0
@export var sheet_size := Vector2(472, 312)

var map: CartographyMap


func _ready() -> void:
	_ensure()


func _ensure() -> void:
	if map != null:
		return
	map = CartographyMap.new()
	map.size = sheet_size
	map.position = -sheet_size * 0.5
	map.journey = CartographySample.overworld() if sample == 0 else CartographySample.dungeon()
	map.scale_units = "LEAGUES" if sample == 0 else "PACES"
	map.style = style
	add_child(map, false, Node.INTERNAL_MODE_FRONT)


## Called by capture tools: build and draw the sheet now instead of on the next refresh tick.
func csaf_preview() -> void:
	_ensure()
	map.refresh()
