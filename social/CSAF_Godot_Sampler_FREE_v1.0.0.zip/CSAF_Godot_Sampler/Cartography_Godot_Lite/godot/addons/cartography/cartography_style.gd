@tool
class_name CartographyStyle
extends Resource
## One map look. Every Cartography preset is one of these (.tres under addons/cartography/styles/); duplicate one and
## move any value to make your own. Colours are the recolour: change them and the whole map follows.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

@export_group("Paper")
## 0 plain, 1 parchment (stains + fibres), 2 graph paper, 3 blueprint, 4 ruled notebook, 5 night sky, 6 terminal, 7 felt / board
@export_range(0, 7) var paper_mode := 1
@export var paper_color := Color("e9dcbc")
## Stains, grid lines, stars or scanlines, depending on the paper.
@export var paper_color2 := Color("b89d6a")
@export_range(0.0, 1.0) var grain := 0.35
@export_range(0.0, 1.0) var stains := 0.4
@export_range(0.0, 1.0) var vignette := 0.35
## Fold creases across the sheet (0 = flat).
@export_range(0, 4) var creases := 0
## Charred, torn edge of the sheet (0 = clean cut).
@export_range(0.0, 1.0) var burnt_edge := 0.0

@export_group("Land")
## 0 flat fill, 1 hatching, 2 stipple, 3 watercolour wash, 4 outline only, 5 contour lines, 6 hill shade
@export_range(0, 6) var land_mode := 1
@export var land_color := Color("e2cf9f")
## Hatching, stipple and contour ink.
@export var land_ink := Color("6b4a2b")
@export_range(2.0, 24.0) var hatch_spacing := 6.0
@export_range(-180.0, 180.0) var hatch_angle := 45.0
## Ink lines (px) where forest, hills, sand and snow meet (0 = none; stained glass leads, crayon outlines).
@export_range(0.0, 4.0) var terrain_lines := 0.0
@export var forest_color := Color("7d8a4a")
@export var mountain_color := Color("9a7a52")
@export var sand_color := Color("e8d29a")
@export var snow_color := Color("f6f4ee")

@export_group("Water")
## 0 flat, 1 ripple lines along the coast, 2 engraved horizontal lines, 3 wash (deepens offshore), 4 none (paper),
## 5 depth bands, 6 wave marks
@export_range(0, 6) var sea_mode := 1
@export var water_color := Color("c9cfb0")
@export var deep_color := Color("a8b49a")
@export_range(0, 12) var ripple_count := 4
@export_range(0.02, 0.3) var ripple_spacing := 0.08

@export_group("Coast and walls")
@export_range(0.0, 6.0) var coast_width := 1.6
@export var coast_color := Color("4a3322")
## A soft shadow (or glow) hugging the coast on the water side.
@export_range(0.0, 1.0) var coast_halo := 0.3
## Interior walls: 0 solid fill, 1 hatched, 2 crosshatched rock, 3 outline only, 4 stone blocks
@export_range(0, 4) var wall_mode := 1
@export var wall_color := Color("3a2a1c")

@export_group("Unexplored")
## 0 blank paper, 1 hatched, 2 dark fog, 3 drifting cloud, 4 grid only
@export_range(0, 4) var fog_mode := 0
@export var fog_color := Color("d8c9a4")
## 0 soft fade, 1 ragged ink, 2 torn line, 3 glowing rim
@export_range(0, 3) var edge_mode := 1
@export_range(0.0, 1.0) var edge_width := 0.5

@export_group("Grid")
## 0 none, 1 cell grid, 2 lat/long graticule, 3 dot grid, 4 lettered map squares
@export_range(0, 4) var grid_mode := 0
@export var grid_color := Color(0.4, 0.3, 0.2, 0.25)
@export_range(1, 64) var grid_every := 8
## Rhumb lines radiating from compass points across the sea (portolan charts).
@export_range(0, 32) var rhumb_lines := 0
@export var rhumb_color := Color(0.55, 0.2, 0.15, 0.5)

@export_group("Symbols")
## 0 none, 1 pen sketch, 2 bold woodcut, 3 painted, 4 pixel, 5 plan symbols, 6 neon
@export_range(0, 6) var glyph_mode := 1
@export var glyph_color := Color("4a3322")
@export_range(0.0, 2.0) var glyph_density := 1.0
@export_range(0.5, 2.5) var glyph_size := 1.0
## Depth soundings (small numbers) scattered over open water.
@export var soundings := false
## A sea creature drawn in open water.
@export var sea_creature := false

@export_group("Route")
## 0 hidden, 1 dashed, 2 dotted, 3 solid with arrows, 4 footprints, 5 double line, 6 glowing, 7 pixel steps,
## 8 constellation (straight lines from place to place, a star on each)
@export_range(0, 8) var route_mode := 1
@export var route_color := Color("a3322a")
@export_range(0.5, 6.0) var route_width := 2.6
## Where the player is now: 0 cross, 1 ship, 2 figure, 3 flag, 4 pin, 5 radar blip
@export_range(0, 5) var marker_mode := 0
@export var marker_color := Color("a3322a")

@export_group("Places and lettering")
## 0 pen icons, 1 dots, 2 painted icons, 3 pixel icons, 4 neon icons
@export_range(0, 4) var place_mode := 0
@export var label_color := Color("3a2618")
## 0 engraved capitals, 1 italic hand, 2 stencil, 3 pixel, 4 brush
@export_range(0, 4) var font_mode := 0
@export_range(6.0, 20.0) var label_size := 9.0
## A light halo behind letters so they read over hatching.
@export var label_halo := true

@export_group("Compass, frame, title")
## 0 none, 1 north arrow, 2 four-point star, 3 sixteen-point rose, 4 rose with fleur-de-lis, 5 sun rose, 6 modern ring,
## 7 pixel, 8 radar sweep
@export_range(0, 8) var compass_mode := 3
## 0 top left, 1 top right, 2 bottom left, 3 bottom right
@export_range(0, 3) var compass_corner := 3
@export_range(0.5, 2.5) var compass_size := 1.0
@export var compass_color := Color("4a3322")
@export var compass_accent := Color("a3322a")
## 0 none, 1 single rule, 2 double rule, 3 graduated checker band, 4 rope, 5 corner flourishes, 6 terminal brackets,
## 7 plan title block, 8 gilded, 9 pixel
@export_range(0, 9) var frame_mode := 2
@export var frame_color := Color("4a3322")
@export_range(0.0, 1.0) var frame_width := 0.5
## Space between the sheet edge and the map, as a fraction of the shorter side.
@export_range(0.0, 0.2) var margin := 0.05
## 0 none, 1 framed box, 2 scroll banner, 3 ribbon, 4 terminal header, 5 plan block, 6 plain title
@export_range(0, 6) var cartouche_mode := 2
## 0 top left, 1 top right, 2 bottom left, 3 bottom right, 4 top centre
@export_range(0, 4) var cartouche_corner := 0
@export var title_color := Color("3a2618")
@export var scale_bar := true

@export_group("Finish")
## 0 none, 1 pixelate, 2 scanlines, 3 bloom-ish glow
@export_range(0, 3) var finish_mode := 0
@export_range(0.0, 1.0) var finish_amount := 0.5
## Hand-drawn wobble on every ink line.
@export_range(0.0, 1.0) var wobble := 0.3
## How many cells of the journey fit across the sheet (0 = fit everything explored).
@export_range(0.0, 400.0) var zoom_cells := 0.0
@export var seed := 1
