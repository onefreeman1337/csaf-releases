class_name CartographyRecorder
extends Node
## Records a journey while the player moves: reveals the cells around them, drops route points, and asks a
## TileMapLayer (or your own Callable) what kind of ground each new cell is. Add it as a child of the player.
##
##   var rec := CartographyRecorder.new()
##   rec.journey = CartographyJourney.new()
##   rec.tile_layer = $World/Ground          # optional: kinds come from the tiles
##   $Player.add_child(rec)
##
## Kinds, in order: terrain_callable (if set) -> the tile's custom data layer `kind_data_layer` (a String such as
## "water" / "forest" / "wall", or an int Kind) -> a tile with a collision polygon is WALL -> any other tile is GROUND
## -> no tile at all is `empty_kind`.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

## Emitted after new cells were revealed (count = how many).
signal revealed(count: int)

## The journey to fill. Created for you if left empty.
@export var journey: CartographyJourney
## The node whose position is recorded. Defaults to the parent.
@export var target: Node2D
## Optional: kinds are read from this layer's tiles. Its tile size also becomes the journey's cell size.
@export var tile_layer: TileMapLayer
## How far the player sees, in cells.
@export_range(1, 64) var reveal_radius := 5
## Minimum distance (world px) between two recorded route points.
@export var route_step := 20.0
## Name of the TileSet custom data layer holding each tile's map kind.
@export var kind_data_layer := "map_kind"
## Kind used where the tile layer has no tile.
@export var empty_kind := CartographyJourney.Kind.WATER
## Stop recording without removing the node.
@export var recording := true

## Optional: Callable(cell: Vector2i) -> int (a CartographyJourney.Kind). Overrides everything else.
var terrain_callable := Callable()

var _last_cell := Vector2i(2147483647, 2147483647)
var _data_layer_ok := -1


func _ready() -> void:
	if journey == null:
		journey = CartographyJourney.new()
	if target == null and get_parent() is Node2D:
		target = get_parent() as Node2D
	if tile_layer != null and tile_layer.tile_set != null:
		journey.cell_size = float(tile_layer.tile_set.tile_size.x)


func _physics_process(_delta: float) -> void:
	if recording:
		record_now()


## Records the target's current position immediately (call it yourself after a teleport or a load).
func record_now() -> void:
	if target == null or journey == null:
		return
	var p := _world_pos()
	journey.add_route_point(p, route_step)
	var cell := journey.world_to_cell(p)
	if cell != _last_cell:
		_last_cell = cell
		var n := journey.reveal_circle(cell, reveal_radius, kind_at)
		if n > 0:
			revealed.emit(n)


## The map kind of any cell, by the rules in the class description.
func kind_at(cell: Vector2i) -> int:
	if terrain_callable.is_valid():
		return int(terrain_callable.call(cell))
	if tile_layer == null:
		return CartographyJourney.Kind.GROUND
	var tcell := cell
	var ts := tile_layer.tile_set
	if ts != null and float(ts.tile_size.x) != journey.cell_size:
		tcell = tile_layer.local_to_map(tile_layer.to_local(Vector2(cell) * journey.cell_size + Vector2.ONE * journey.cell_size * 0.5))
	var data := tile_layer.get_cell_tile_data(tcell)
	if data == null:
		return empty_kind
	if _data_layer_ok < 0:
		_data_layer_ok = 1 if (ts != null and ts.get_custom_data_layer_by_name(kind_data_layer) >= 0) else 0
	if _data_layer_ok == 1:
		var v: Variant = data.get_custom_data(kind_data_layer)
		if typeof(v) == TYPE_INT:
			return clampi(int(v), 0, CartographyJourney.Kind.FLOOR)
		if typeof(v) == TYPE_STRING or typeof(v) == TYPE_STRING_NAME:
			var i := CartographyJourney.KIND_NAMES.find(String(v).to_lower())
			if i >= 0:
				return i
	if ts != null and ts.get_physics_layers_count() > 0 and data.get_collision_polygons_count(0) > 0:
		return CartographyJourney.Kind.WALL
	return CartographyJourney.Kind.GROUND


## Marks a named place at the target's position (a town gate, a cave mouth...).
func mark_place(place_name: String, kind: int = CartographyJourney.Place.TOWN) -> void:
	if target != null and journey != null:
		journey.add_place(place_name, _world_pos(), kind)


func _world_pos() -> Vector2:
	if tile_layer != null:
		return tile_layer.to_local(target.global_position)
	return target.global_position
