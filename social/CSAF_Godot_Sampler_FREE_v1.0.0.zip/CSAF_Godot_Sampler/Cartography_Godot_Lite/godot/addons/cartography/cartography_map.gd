@tool
class_name CartographyMap
extends Control
## Draws a CartographyJourney as a finished map sheet in a CartographyStyle, and keeps redrawing while the journey
## grows. Put it in your pause menu, a journal page or a corner of the HUD; size it like any Control.
##
##   $Map.journey = $Player/CartographyRecorder.journey
##   $Map.style = Cartography.style("explorers_parchment")
##   await $Map.export_png("user://my_journey.png")      # the player's map as a PNG
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

const MAP_SHADER := preload("res://addons/cartography/shaders/cartography_map.gdshader")
const FINISH_SHADER := preload("res://addons/cartography/shaders/cartography_finish.gdshader")
const K := CartographyJourney.Kind
const CREATURE_SIZE := 30.0

enum View { FIT_EXPLORED, FOLLOW, FIXED }

@export var journey: CartographyJourney:
	set(v):
		if journey != null and journey.changed.is_connected(_on_journey_changed):
			journey.changed.disconnect(_on_journey_changed)
		journey = v
		if journey != null and not journey.changed.is_connected(_on_journey_changed):
			journey.changed.connect(_on_journey_changed)
		_dirty = true
@export var style: CartographyStyle:
	set(v):
		style = v
		_dirty = true
## FIT_EXPLORED frames everything seen so far; FOLLOW centres on the newest route point (a minimap);
## FIXED shows `fixed_rect` (cells).
@export var view := View.FIT_EXPLORED:
	set(v):
		view = v
		_dirty = true
@export var fixed_rect := Rect2i(0, 0, 64, 40)
## Cells across the sheet in FOLLOW view.
@export var follow_cells := 48.0
@export var show_route := true
@export var show_places := true
@export var show_title := true
## Seconds between redraws while the journey keeps changing (recording during play).
@export var refresh_interval := 0.2
## The units under the scale bar.
@export var scale_units := "LEAGUES"

var _paper: ColorRect
var _ink_map: Control
var _ink_sheet: Control
var _finish: ColorRect
var _mat: ShaderMaterial
var _fmat: ShaderMaterial
var _dirty := true
var _since := 0.0
var _img_a: Image
var _img_b: Image
var _img_h: Image
var _tex_a: ImageTexture
var _tex_b: ImageTexture
var _tex_c: ImageTexture
var _origin := Vector2i.ZERO
var _fsize := Vector2i.ONE
var _view_origin := Vector2.ZERO
var _cpp := 0.25
var _map_rect := Rect2()
var _unit := 1.0
var _glyphs: Array = []
var _soundings: Array = []
var _creature := Vector2.INF
var _route_px := PackedVector2Array()
var _cart_rect := Rect2()
var _compass_c := Vector2.INF
var _compass_r := 0.0
var _scale_p := Vector2.INF
var _scale_len := 0.0
var _reserved: Array[Rect2] = []
var _place_labels: Array = []
var _area_labels: Array = []


func _init() -> void:
	clip_contents = true


func _ready() -> void:
	_build_children()
	resized.connect(func() -> void: _dirty = true)
	_dirty = true


func _build_children() -> void:
	if _paper != null:
		return
	_paper = ColorRect.new()
	_paper.name = "Paper"
	_paper.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_mat = ShaderMaterial.new()
	_mat.shader = MAP_SHADER
	_paper.material = _mat
	add_child(_paper, false, Node.INTERNAL_MODE_FRONT)
	_ink_map = Control.new()
	_ink_map.name = "InkMap"
	_ink_map.clip_contents = true
	_ink_map.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ink_map.draw.connect(_draw_map_ink)
	add_child(_ink_map, false, Node.INTERNAL_MODE_FRONT)
	_ink_sheet = Control.new()
	_ink_sheet.name = "InkSheet"
	_ink_sheet.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ink_sheet.draw.connect(_draw_sheet_ink)
	add_child(_ink_sheet, false, Node.INTERNAL_MODE_FRONT)
	_finish = ColorRect.new()
	_finish.name = "Finish"
	_finish.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fmat = ShaderMaterial.new()
	_fmat.shader = FINISH_SHADER
	_finish.material = _fmat
	_finish.visible = false
	add_child(_finish, false, Node.INTERNAL_MODE_FRONT)


func _process(delta: float) -> void:
	_since += delta
	# a hidden map does not redraw; it catches up the moment it is shown again
	if _dirty and _since >= refresh_interval and is_visible_in_tree():
		refresh()


func _on_journey_changed() -> void:
	_dirty = true


## Rebuilds and redraws now (normally automatic).
func refresh() -> void:
	_build_children()
	_since = 0.0
	_dirty = false
	if style == null:
		style = CartographyStyle.new()
	var full := Rect2(Vector2.ZERO, size)
	for c in [_paper, _ink_sheet, _finish]:
		c.position = Vector2.ZERO
		c.size = size
	_unit = maxf(0.6, minf(size.x, size.y) / 320.0)
	var m := style.margin * minf(size.x, size.y) + _frame_band()
	_map_rect = full.grow(-m)
	if _map_rect.size.x < 8.0 or _map_rect.size.y < 8.0:
		_map_rect = full
	_ink_map.position = _map_rect.position
	_ink_map.size = _map_rect.size
	_build_fields()
	_compute_view()
	_apply_style()
	_sheet_layout()
	_layout()
	_label_layout()
	_ink_map.queue_redraw()
	_ink_sheet.queue_redraw()


func _frame_band() -> float:
	match style.frame_mode:
		3:
			return _unit * (3.0 + style.frame_width * 4.0) + _unit * 2.0
		4:
			return _unit * 6.0
		8:
			return _unit * (4.0 + style.frame_width * 3.0) + _unit * 2.0
		0:
			return 0.0
		_:
			return _unit * 4.0


# ---- fields ------------------------------------------------------------------------------------------------------

static func _height_of(k: int) -> float:
	match k:
		K.GROUND, K.FLOOR:
			return 0.25
		K.SAND:
			return 0.12
		K.FOREST:
			return 0.36
		K.MOUNTAIN:
			return 0.78
		K.SNOW:
			return 1.0
		K.WALL:
			return 0.5
		_:
			return 0.0


## The three field texels of each kind (index = CartographyJourney.Kind), built once.
static var _texels: Array = []


static func _texels_for(k: int) -> Array:
	if _texels.is_empty():
		for kind in 10:
			var ground := 1.0 if kind in [K.GROUND, K.FOREST, K.MOUNTAIN, K.SAND, K.SNOW, K.FLOOR] else 0.0
			var deep := 1.0 if kind == K.DEEP else 0.0
			var wall := 1.0 if (kind == K.WALL or kind == K.VOID) else 0.0
			_texels.append([Color(ground, 1.0, deep, wall),
				Color(1.0 if kind == K.FOREST else 0.0, 1.0 if (kind == K.MOUNTAIN or kind == K.SNOW) else 0.0, 1.0 if kind == K.SAND else 0.0, 1.0 if kind == K.SNOW else 0.0),
				Color(ground, 1.0, _height_of(kind), wall)])
	return _texels[clampi(k, 0, 9)]


func _write_cell(c: Vector2i, k: int) -> void:
	var lx := c.x - _origin.x
	var ly := c.y - _origin.y
	if lx < 0 or ly < 0 or lx >= _fsize.x or ly >= _fsize.y:
		return
	var t: Array = _texels_for(k)
	_img_a.set_pixel(lx, ly, t[0])
	_img_b.set_pixel(lx, ly, t[1])
	_img_h.set_pixel(lx, ly, t[2])


var _seen_epoch := -1
var _seen_log := 0
var _seen_journey: CartographyJourney


func _build_fields() -> void:
	var b := Rect2i(0, 0, 8, 8)
	if journey != null and not journey.is_empty():
		b = journey.bounds()
	if view == View.FIXED:
		b = fixed_rect
	# Incremental when the same journey only grew inside the current images: write just the newly logged cells.
	var inside := _img_a != null and Rect2i(_origin, _fsize).grow(-2).encloses(b)
	if journey != null and inside and _seen_journey == journey and _seen_epoch == journey.epoch() and _seen_log <= journey.log_size():
		for i in range(_seen_log, journey.log_size()):
			var c := journey.log_cell(i)
			_write_cell(c, journey.kind_at(c))
		_seen_log = journey.log_size()
	else:
		var pad := 10 if view == View.FIXED else 24
		var sz := b.size + Vector2i(pad * 2, pad * 2)
		sz.x = clampi(sz.x, 8, 1024)
		sz.y = clampi(sz.y, 8, 1024)
		_origin = b.position - Vector2i(pad, pad)
		_fsize = sz
		_img_a = Image.create_empty(sz.x, sz.y, false, Image.FORMAT_RGBA8)
		_img_b = Image.create_empty(sz.x, sz.y, false, Image.FORMAT_RGBA8)
		_img_h = Image.create_empty(sz.x, sz.y, false, Image.FORMAT_RGBA8)
		if journey != null:
			for c: Vector2i in journey.cells:
				_write_cell(c, int(journey.cells[c]))
			_seen_epoch = journey.epoch()
			_seen_log = journey.log_size()
		_seen_journey = journey
	var s := _fsize
	# One texel per cell: the shader's tent kernel and bilinear filtering do the smoothing. (MEASURED 2026-10-23: six
	# texels per cell cost ~250 ms per redraw at 1280x720 in cubic resizes and texture uploads.)
	var up := 1
	var fa := _img_a
	var fb := _img_b
	var fc := _img_h.duplicate() as Image
	var w := s.x
	var h := s.y
	for i in 3:
		w = maxi(2, w / 2)
		h = maxi(2, h / 2)
		fc.resize(w, h, Image.INTERPOLATE_BILINEAR)
	fc.resize(s.x * up, s.y * up, Image.INTERPOLATE_CUBIC)
	_tex_a = _upload(_tex_a, fa)
	_tex_b = _upload(_tex_b, fb)
	_tex_c = _upload(_tex_c, fc)


# Reuses the texture when the size is unchanged (an update, not a new GPU texture every redraw).
static func _upload(tex: ImageTexture, img: Image) -> ImageTexture:
	if tex != null and tex.get_size() == Vector2(img.get_size()):
		tex.update(img)
		return tex
	return ImageTexture.create_from_image(img)


func _compute_view() -> void:
	var mr := _map_rect
	var b := Rect2(Vector2.ZERO, Vector2(8, 8))
	if journey != null and not journey.is_empty():
		b = Rect2(journey.bounds())
	if view == View.FIXED:
		b = Rect2(fixed_rect)
	var cpp := maxf(b.size.x / maxf(1.0, mr.size.x), b.size.y / maxf(1.0, mr.size.y)) * 1.06
	var centre := b.get_center()
	if style.zoom_cells > 0.0:
		cpp = style.zoom_cells / maxf(1.0, mr.size.x)
	if view == View.FOLLOW:
		cpp = follow_cells / maxf(1.0, mr.size.x)
		if journey != null and journey.route.size() > 0:
			centre = journey.route[journey.route.size() - 1] / journey.cell_size
	_cpp = maxf(cpp, 0.001)
	_view_origin = centre - (mr.position + mr.size * 0.5) * _cpp


## Map cell coordinates (fractional) -> this control's local pixels.
func cell_to_local(cell: Vector2) -> Vector2:
	return (cell - _view_origin) / _cpp


## World pixels (the journey's space) -> this control's local pixels.
func world_to_local(p: Vector2) -> Vector2:
	var cs := journey.cell_size if journey != null else 16.0
	return cell_to_local(p / cs)


func _apply_style() -> void:
	var st := style
	var m := _mat
	m.set_shader_parameter("fields_a", _tex_a)
	m.set_shader_parameter("fields_b", _tex_b)
	m.set_shader_parameter("fields_c", _tex_c)
	m.set_shader_parameter("field_origin", Vector2(_origin))
	m.set_shader_parameter("field_size", Vector2(_fsize))
	m.set_shader_parameter("view_origin", _view_origin)
	m.set_shader_parameter("cells_per_px", _cpp)
	m.set_shader_parameter("rect_size", size)
	m.set_shader_parameter("map_rect", Vector4(_map_rect.position.x, _map_rect.position.y, _map_rect.size.x, _map_rect.size.y))
	m.set_shader_parameter("ink_scale", _unit)
	m.set_shader_parameter("seed", float(st.seed))
	for p in ["paper_mode", "creases", "land_mode", "sea_mode", "ripple_count", "wall_mode", "fog_mode", "edge_mode", "grid_mode"]:
		m.set_shader_parameter(p, int(st.get(p)))
	for p in ["grain", "stains", "vignette", "burnt_edge", "hatch_spacing", "hatch_angle", "terrain_lines", "ripple_spacing", "coast_width", "coast_halo", "edge_width"]:
		m.set_shader_parameter(p, float(st.get(p)))
	for p in ["paper_color", "paper_color2", "land_color", "land_ink", "forest_color", "mountain_color", "sand_color", "snow_color", "water_color", "deep_color", "coast_color", "wall_color", "fog_color", "grid_color"]:
		m.set_shader_parameter(p, st.get(p))
	m.set_shader_parameter("grid_every", float(st.grid_every))
	m.set_shader_parameter("rim_color", st.marker_color)
	m.set_shader_parameter("rhumb_count", st.rhumb_lines)
	m.set_shader_parameter("rhumb_color", st.rhumb_color)
	m.set_shader_parameter("rhumb_centre", _map_rect.get_center() + Vector2(_map_rect.size.x * 0.08, _map_rect.size.y * 0.1))
	m.set_shader_parameter("rhumb_radius", minf(_map_rect.size.x, _map_rect.size.y) * 0.42)
	_finish.visible = st.finish_mode != 0
	if _finish.visible:
		_fmat.set_shader_parameter("mode", st.finish_mode)
		_fmat.set_shader_parameter("amount", st.finish_amount)
		_fmat.set_shader_parameter("ink_scale", _unit)
		# pixelate the sheet only (ink stays crisp on the pixel grid); scanlines and glow go over everything
		move_child(_finish, 1 if st.finish_mode == 1 else 3)


# ---- the sheet's furniture: title, compass, scale bar -----------------------------------------------------------------

func _sheet_layout() -> void:
	var st := style
	_reserved.clear()
	_cart_rect = Rect2()
	if show_title and journey != null:
		_cart_rect = CartographyDraw.cartouche_rect(_map_rect, st.cartouche_corner, st.cartouche_mode, journey.title, st.font_mode, _unit)
	# places and their names, for the furniture to dodge
	var places_busy: Array[Rect2] = []
	var fs := st.label_size * _unit
	if journey != null:
		for p in journey.places:
			var ip := world_to_local(Vector2(p.get("position", Vector2.ZERO)))
			var w := CartographyLettering.measure(str(p.get("name", "")), fs, st.font_mode)
			places_busy.append(Rect2(ip - Vector2(w + 10.0 * _unit, fs + 6.0 * _unit), Vector2(w * 2.0 + 20.0 * _unit, fs * 2.0 + 12.0 * _unit)))
	_compass_c = Vector2.INF
	if st.compass_mode > 0:
		_compass_r = 26.0 * _unit * st.compass_size
		var m := _compass_r * 1.35 + 4.0 * _unit
		var corners := [_map_rect.position + Vector2(m, m), Vector2(_map_rect.end.x - m, _map_rect.position.y + m), Vector2(_map_rect.position.x + m, _map_rect.end.y - m), _map_rect.end - Vector2(m, m)]
		# the style's corner first, then the others: the one that covers the least (title, places, explored map)
		var order := [st.compass_corner, st.compass_corner ^ 1, st.compass_corner ^ 2, 3 - st.compass_corner]
		var best := INF
		for k in order.size():
			var c: Vector2 = corners[order[k]]
			var cr := Rect2(c - Vector2(_compass_r, _compass_r) * 1.2, Vector2(_compass_r, _compass_r) * 2.4)
			var score := _cover_score(cr, places_busy) + float(k) * 0.04
			if score < best:
				best = score
				_compass_c = c
	_scale_p = Vector2.INF
	if st.scale_bar and journey != null:
		var cells10 := 10.0
		_scale_len = cells10 / _cpp
		while _scale_len > _map_rect.size.x * 0.28:
			cells10 *= 0.5
			_scale_len = cells10 / _cpp
		while _scale_len < _map_rect.size.x * 0.12:
			cells10 *= 2.0
			_scale_len = cells10 / _cpp
		# the first corner whose bar clears the title, the compass and every place and its name
		var busy: Array[Rect2] = places_busy.duplicate()
		if _cart_rect.has_area():
			busy.append(_cart_rect.grow(4.0 * _unit))
		if _compass_c != Vector2.INF:
			busy.append(Rect2(_compass_c - Vector2(_compass_r, _compass_r) * 1.3, Vector2(_compass_r, _compass_r) * 2.6))
		var left := _map_rect.position.x + 10.0 * _unit
		var right := _map_rect.end.x - _scale_len - 10.0 * _unit
		var bottom := _map_rect.end.y - 16.0 * _unit
		var top := _map_rect.position.y + 14.0 * _unit
		var order := [Vector2(left, bottom), Vector2(right, bottom), Vector2(left, top), Vector2(right, top)]
		if st.compass_corner % 2 == 0:
			order = [Vector2(right, bottom), Vector2(left, bottom), Vector2(right, top), Vector2(left, top)]
		_scale_p = order[0]
		var best_s := INF
		for k in order.size():
			var cand: Vector2 = order[k]
			var r := Rect2(cand + Vector2(-8.0, -9.0) * _unit, Vector2(_scale_len + 16.0 * _unit, 24.0 * _unit))
			var score := _cover_score(r, busy) + float(k) * 0.04
			if score < best_s:
				best_s = score
				_scale_p = cand
		if best_s >= 10.0:
			_scale_p = Vector2.INF   # every corner is taken: no bar beats a bar drawn over a name
	var o := _map_rect.position
	if _cart_rect.has_area():
		_reserved.append(Rect2(_cart_rect.position - o, _cart_rect.size).grow(4.0 * _unit))
	if _compass_c != Vector2.INF:
		var cr := _compass_r * 1.3
		_reserved.append(Rect2(_compass_c - o - Vector2(cr, cr), Vector2(cr, cr) * 2.0))
	if _scale_p != Vector2.INF:
		_reserved.append(Rect2(_scale_p - o + Vector2(-8.0, -8.0) * _unit, Vector2(_scale_len + 16.0 * _unit, 22.0 * _unit)))


# ---- layout of symbols ----------------------------------------------------------------------------------------------

func _kind(c: Vector2i) -> int:
	if journey == null:
		return -1
	return journey.kind_at(c)


func _same_around(c: Vector2i, cls: Array, r: int) -> bool:
	for dy in range(-r, r + 1):
		for dx in range(-r, r + 1):
			if not (_kind(c + Vector2i(dx, dy)) in cls):
				return false
	return true


func _layout() -> void:
	_glyphs.clear()
	_soundings.clear()
	_creature = Vector2.INF
	_route_px = PackedVector2Array()
	if journey == null or journey.is_empty():
		return
	var st := style
	var gs := 11.0 * _unit * st.glyph_size
	var step := gs * 1.15 / maxf(0.2, st.glyph_density)
	var mr := Rect2(Vector2.ZERO, _map_rect.size)
	if st.glyph_mode > 0 and st.glyph_density > 0.0:
		var y := step * 0.5
		var row := 0
		while y < mr.size.y + gs:
			var x := step * (0.5 if row % 2 == 0 else 1.0)
			while x < mr.size.x + gs:
				var j := Vector2(CartographyDraw.rnd(int(x), int(y), st.seed) - 0.5, CartographyDraw.rnd(int(y), int(x), st.seed + 1) - 0.5) * step * 0.7
				var p := Vector2(x, y) + j
				var cellf := _view_origin + (p + _map_rect.position) * _cpp
				var c := Vector2i(floori(cellf.x), floori(cellf.y))
				var k := _kind(c)
				var sd := posmod(hash(c), 100000)
				if k == K.MOUNTAIN or k == K.SNOW:
					if _same_around(c, [K.MOUNTAIN, K.SNOW, K.FOREST, K.GROUND], 1):
						_glyphs.append([0, p, gs * (1.0 if k == K.MOUNTAIN else 1.15), sd, k == K.SNOW])
				elif k == K.FOREST:
					if _same_around(c, [K.FOREST, K.GROUND, K.MOUNTAIN], 1) and CartographyDraw.rnd(sd, 2, 9) < 0.85:
						_glyphs.append([1, p, gs * 0.8, sd, false])
				elif k == K.SAND:
					if CartographyDraw.rnd(sd, 4, 1) < 0.5 and _same_around(c, [K.SAND, K.GROUND], 1):
						_glyphs.append([3, p, gs * 0.7, sd, false])
				elif k == K.DEEP and st.sea_mode != 2:
					if CartographyDraw.rnd(sd, 7, 3) < 0.28 and _same_around(c, [K.DEEP], 2):
						_glyphs.append([2, p, gs * 0.8, sd, false])
				x += step
			y += step * 0.86
			row += 1
		_glyphs.sort_custom(func(a: Array, b: Array) -> bool: return (a[1] as Vector2).y < (b[1] as Vector2).y)
	if st.soundings:
		var ss := 26.0 * _unit
		var y2 := ss * 0.5
		while y2 < mr.size.y:
			var x2 := ss * 0.5
			while x2 < mr.size.x:
				var p2 := Vector2(x2, y2) + Vector2(CartographyDraw.rnd(int(x2), int(y2), 7) - 0.5, CartographyDraw.rnd(int(y2), int(x2), 9) - 0.5) * ss * 0.6
				var cf := _view_origin + (p2 + _map_rect.position) * _cpp
				var c2 := Vector2i(floori(cf.x), floori(cf.y))
				var k2 := _kind(c2)
				if (k2 == K.WATER or k2 == K.DEEP) and _same_around(c2, [K.WATER, K.DEEP], 1):
					var d := 2 + int(CartographyDraw.rnd(c2.x, c2.y, 3) * 6.0) if k2 == K.WATER else 9 + int(CartographyDraw.rnd(c2.x, c2.y, 3) * 24.0)
					_soundings.append([p2, str(d)])
				x2 += ss
			y2 += ss
	if journey.route.size() > 1:
		var raw := PackedVector2Array()
		for p4 in journey.route:
			var lp := world_to_local(p4) - _map_rect.position
			if raw.is_empty() or raw[raw.size() - 1].distance_to(lp) > 2.5 * _unit:
				raw.append(lp)
		_route_px = _chaikin(_chaikin(raw))


## How much a piece of sheet furniture at `r` (this control's pixels) would cover: 10 per title or place it hits,
## plus the fraction of it that lies over explored map.
func _cover_score(r: Rect2, busy: Array) -> float:
	var s := 0.0
	if _cart_rect.has_area() and _cart_rect.intersects(r) and not busy.has(_cart_rect.grow(4.0 * _unit)):
		s += 10.0
	for b: Rect2 in busy:
		if b.intersects(r):
			s += 10.0
	if journey != null and not journey.is_empty():
		var hit := 0
		for y in 5:
			for x in 5:
				var p := r.position + r.size * Vector2((float(x) + 0.5) / 5.0, (float(y) + 0.5) / 5.0)
				var cf := _view_origin + p * _cpp
				if journey.is_revealed(Vector2i(floori(cf.x), floori(cf.y))):
					hit += 1
		s += float(hit) / 25.0
	return s


func _free_at(r: Rect2, taken: Array) -> bool:
	if not Rect2(Vector2.ZERO, _map_rect.size).grow(-2.0 * _unit).encloses(r):
		return false
	for t: Rect2 in _reserved:
		if t.intersects(r):
			return false
	for t: Rect2 in taken:
		if t.intersects(r):
			return false
	return true


## Places every label where it collides with nothing: place names right of their icon (else left, above, below),
## region names at their spot (else nudged, else dropped).
func _label_layout() -> void:
	_place_labels.clear()
	_area_labels.clear()
	if journey == null:
		return
	var st := style
	var fs := st.label_size * _unit
	var isz := 13.0 * _unit
	var taken: Array = []
	if show_places:
		var sheet := Rect2(Vector2.ZERO, _map_rect.size).grow(-isz * 0.5)
		for p in journey.places:
			var ip := world_to_local(Vector2(p.get("position", Vector2.ZERO))) - _map_rect.position
			taken.append(Rect2(ip - Vector2(isz, isz) * 0.5, Vector2(isz, isz)))
		for p in journey.places:
			var ip := world_to_local(Vector2(p.get("position", Vector2.ZERO))) - _map_rect.position
			if not sheet.has_point(ip):
				continue
			var nm := str(p.get("name", ""))
			var w := CartographyLettering.measure(nm, fs, st.font_mode)
			var tries := [[Vector2(isz * 0.62, fs * 0.4), 0], [Vector2(-isz * 0.62, fs * 0.4), 2], [Vector2(0, -isz * 0.7), 1], [Vector2(0, isz * 0.7 + fs), 1]]
			var chosen: Array = []
			for t in tries:
				var at: Vector2 = ip + t[0]
				var x0: float = at.x - (w if t[1] == 2 else (w * 0.5 if t[1] == 1 else 0.0))
				var r := Rect2(Vector2(x0, at.y - fs), Vector2(w, fs * 1.2))
				if _free_at(r, taken.filter(func(q: Rect2) -> bool: return not q.has_point(ip))):
					chosen = [at, t[1], r]
					break
			if chosen.is_empty():
				# nothing is free: take the first spot that stays on the sheet, else the right side pulled inside it
				var inner := Rect2(Vector2.ZERO, _map_rect.size).grow(-2.0 * _unit)
				for t in tries:
					var at: Vector2 = ip + t[0]
					var x0: float = at.x - (w if t[1] == 2 else (w * 0.5 if t[1] == 1 else 0.0))
					var r := Rect2(Vector2(x0, at.y - fs), Vector2(w, fs * 1.2))
					if inner.encloses(r):
						chosen = [at, t[1], r]
						break
				if chosen.is_empty():
					var at2: Vector2 = ip + tries[1][0] if ip.x > _map_rect.size.x * 0.5 else ip + tries[0][0]
					var al := 2 if ip.x > _map_rect.size.x * 0.5 else 0
					at2.x = clampf(at2.x, inner.position.x + (w if al == 2 else 0.0), inner.end.x - (0.0 if al == 2 else w))
					chosen = [at2, al, Rect2()]
			if nm != "" and (chosen[2] as Rect2).has_area():
				taken.append(chosen[2])
			_place_labels.append([ip, chosen[0], chosen[1], nm, int(p.get("kind", 0))])
	var afs := fs * 1.05
	var amode := 1 if st.font_mode == 0 else st.font_mode
	for a in journey.areas:
		var wp := Vector2(a.get("position", Vector2.ZERO))
		if not journey.is_revealed(journey.world_to_cell(wp)):
			continue
		var txt := _spaced(str(a.get("name", "")).to_upper())
		var w := CartographyLettering.measure(txt, afs, amode)
		var base := world_to_local(wp) - _map_rect.position
		var placed := false
		for off in [Vector2.ZERO, Vector2(0, afs * 1.8), Vector2(0, -afs * 1.8), Vector2(w * 0.3, 0), Vector2(-w * 0.3, 0), Vector2(0, afs * 3.6), Vector2(0, -afs * 3.6)]:
			var c: Vector2 = base + off
			c.x = clampf(c.x, w * 0.5 + 4.0 * _unit, _map_rect.size.x - w * 0.5 - 4.0 * _unit)
			var r := Rect2(Vector2(c.x - w * 0.5, c.y - afs), Vector2(w, afs * 1.3))
			if _free_at(r, taken):
				taken.append(r)
				_area_labels.append([c, txt])
				placed = true
				break
		if not placed:
			continue
	_place_creature(taken)


## The sea creature goes in the widest open water whose body clears every place, every name, the route and the furniture.
func _place_creature(taken: Array) -> void:
	_creature = Vector2.INF
	if not style.sea_creature or journey == null:
		return
	var s := CREATURE_SIZE * _unit
	var body := Vector2(s * 1.25, s * 0.45)
	var mr := Rect2(Vector2.ZERO, _map_rect.size).grow(-8.0 * _unit)
	var best := -1
	for c: Vector2i in journey.cells:
		var k: int = journey.cells[c]
		if (k != K.DEEP and k != K.WATER) or posmod(c.x + c.y * 3, 2) != 0:
			continue
		var p := cell_to_local(Vector2(c) + Vector2(0.5, 0.5)) - _map_rect.position
		var box := Rect2(p - Vector2(body.x * 0.5, body.y * 0.75), body)
		if not mr.encloses(box):
			continue
		var r := 1
		while r < 14 and _same_around(c, [K.DEEP, K.WATER], r):
			r += 1
		if r <= best or float(r) / _cpp < body.x * 0.35:
			continue
		var clear := true
		for t: Rect2 in _reserved:
			if t.intersects(box):
				clear = false
		for t: Rect2 in taken:
			if clear and t.intersects(box.grow(4.0 * _unit)):
				clear = false
		for q in _route_px:
			if clear and box.grow(3.0 * _unit).has_point(q):
				clear = false
		if clear:
			best = r
			_creature = p


static func _chaikin(pts: PackedVector2Array) -> PackedVector2Array:
	if pts.size() < 3:
		return pts
	var out := PackedVector2Array([pts[0]])
	for i in pts.size() - 1:
		out.append(pts[i].lerp(pts[i + 1], 0.25))
		out.append(pts[i].lerp(pts[i + 1], 0.75))
	out.append(pts[pts.size() - 1])
	return out


# ---- drawing ---------------------------------------------------------------------------------------------------------

func _draw_map_ink() -> void:
	if style == null or journey == null:
		return
	var st := style
	var ci := _ink_map
	var paper := st.paper_color
	for g in _glyphs:
		match int(g[0]):
			0:
				CartographyDraw.mountain(ci, g[1], g[2], st.glyph_mode, st.mountain_color.darkened(0.45) if st.glyph_mode == 3 else st.glyph_color, paper, g[3], g[4])
			1:
				CartographyDraw.tree(ci, g[1], g[2], st.glyph_mode, st.forest_color if st.glyph_mode == 3 else st.glyph_color, paper, g[3])
			2:
				CartographyDraw.wave(ci, g[1], g[2], st.glyph_mode, st.coast_color if st.glyph_mode != 6 else st.glyph_color, g[3])
			3:
				CartographyDraw.dune(ci, g[1], g[2], st.glyph_mode, st.glyph_color, g[3])
	var fs := st.label_size * _unit
	for s in _soundings:
		CartographyLettering.draw_text(ci, s[1], s[0], fs * 0.48, st.coast_color, st.font_mode, Color(0, 0, 0, 0), 1)
	if _creature != Vector2.INF:
		# in the coast ink: it is drawn on water, and the coast line is the ink the style made to read on its water
		CartographyDraw.sea_creature(ci, _creature, CREATURE_SIZE * _unit, st.coast_color, paper, st.glyph_mode)
	# the halo is whichever of paper and land contrasts more with the lettering, so names read on either
	var lum := func(c: Color) -> float: return c.r * 0.3 + c.g * 0.59 + c.b * 0.11
	var hb := st.paper_color
	if absf(lum.call(st.land_color) - lum.call(st.label_color)) > absf(lum.call(st.paper_color) - lum.call(st.label_color)):
		hb = st.land_color
	var halo := Color(hb, 0.85) if st.label_halo else Color(0, 0, 0, 0)
	if show_route and st.route_mode > 0:
		if st.route_mode == 8:
			var stars := PackedVector2Array()
			for pl in _place_labels:
				stars.append(pl[0])
			if _route_px.size() > 0:
				stars.append(_route_px[_route_px.size() - 1])
			CartographyDraw.route(ci, stars, 8, st.route_color, st.route_width * _unit, paper)
		elif _route_px.size() > 1:
			CartographyDraw.route(ci, _route_px, st.route_mode, st.route_color, st.route_width * _unit, paper)
	# region names: large, tracked capitals, lettered over the route so a name is never cut by it
	var acol := st.label_color
	acol.a *= 0.8
	for a in _area_labels:
		CartographyLettering.draw_text(ci, a[1], a[0], fs * 1.05, acol, 1 if st.font_mode == 0 else st.font_mode, halo, 1, st.wobble, st.seed)
	if show_places:
		var isz := 13.0 * _unit
		for pl in _place_labels:
			CartographyDraw.place_icon(ci, pl[0], isz, pl[4], st.place_mode, st.label_color, st.compass_accent, paper)
		for pl in _place_labels:
			if str(pl[3]) != "":
				CartographyLettering.draw_text(ci, pl[3], pl[1], fs, st.label_color, st.font_mode, halo, pl[2], st.wobble * 0.6, st.seed)
	if show_route and _route_px.size() > 0:
		CartographyDraw.marker(ci, _route_px[_route_px.size() - 1], 14.0 * _unit, st.marker_mode, st.marker_color, paper)


static func _spaced(s: String) -> String:
	var out := ""
	for i in s.length():
		out += s[i]
		if i < s.length() - 1:
			out += " " if s[i] != " " else "  "
	return out


func _draw_sheet_ink() -> void:
	if style == null:
		return
	var st := style
	var ci := _ink_sheet
	var paper := st.paper_color
	if st.frame_mode > 0:
		CartographyDraw.frame(ci, _map_rect, st.frame_mode, st.frame_color, st.compass_accent, paper, st.frame_width, _unit)
	if st.grid_mode == 4:
		var fs := 5.0 * _unit
		var every := float(st.grid_every) / _cpp
		var x0 := fposmod(-_view_origin.x / _cpp, every)
		var i := 0
		var x := x0
		while x < _map_rect.size.x:
			var col_idx := int(floor((_view_origin.x + (x + every * 0.5) * _cpp) / float(st.grid_every)))
			CartographyLettering.draw_text(ci, char(65 + posmod(col_idx, 26)), Vector2(_map_rect.position.x + x + every * 0.5, _map_rect.position.y - 2.0 * _unit), fs, st.frame_color, st.font_mode, Color(0, 0, 0, 0), 1)
			x += every
			i += 1
		var y0 := fposmod(-_view_origin.y / _cpp, every)
		var y := y0
		while y < _map_rect.size.y:
			var row_idx := int(floor((_view_origin.y + (y + every * 0.5) * _cpp) / float(st.grid_every)))
			CartographyLettering.draw_text(ci, str(posmod(row_idx, 99) + 1), Vector2(_map_rect.position.x - 3.0 * _unit, _map_rect.position.y + y + every * 0.5 + fs * 0.5), fs, st.frame_color, st.font_mode, Color(0, 0, 0, 0), 2)
			y += every
	if _cart_rect.has_area() and journey != null:
		CartographyDraw.cartouche(ci, _cart_rect, st.cartouche_mode, journey.title, st.title_color, st.compass_accent, paper, st.font_mode, _unit)
	if _compass_c != Vector2.INF:
		CartographyDraw.compass(ci, _compass_c, _compass_r, st.compass_mode, st.compass_color, st.compass_accent, paper, st.font_mode)
	if _scale_p != Vector2.INF:
		CartographyDraw.scale_bar(ci, _scale_p, _scale_len, st.frame_color, paper, st.font_mode, _unit, scale_units)


# ---- export ------------------------------------------------------------------------------------------------------------

## Renders this map (same journey, same style) at `px_size` into an Image. Call with await.
func render_image(px_size := Vector2i(1600, 1000)) -> Image:
	var vp := SubViewport.new()
	vp.size = px_size
	vp.transparent_bg = false
	vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	var copy := CartographyMap.new()
	copy.journey = journey
	copy.style = style
	copy.view = view
	copy.fixed_rect = fixed_rect
	copy.follow_cells = follow_cells * float(px_size.x) / maxf(1.0, size.x)
	copy.show_route = show_route
	copy.show_places = show_places
	copy.show_title = show_title
	copy.scale_units = scale_units
	copy.size = Vector2(px_size)
	vp.add_child(copy)
	add_child(vp, false, Node.INTERNAL_MODE_BACK)
	copy.refresh()
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var img := vp.get_texture().get_image()
	vp.queue_free()
	return img


## Saves the map as a PNG (user:// or an absolute path). Call with await. Returns an Error.
func export_png(path: String, px_size := Vector2i(1600, 1000)) -> Error:
	var img: Image = await render_image(px_size)
	if img == null or img.is_empty():
		return ERR_CANT_CREATE
	return img.save_png(path)
