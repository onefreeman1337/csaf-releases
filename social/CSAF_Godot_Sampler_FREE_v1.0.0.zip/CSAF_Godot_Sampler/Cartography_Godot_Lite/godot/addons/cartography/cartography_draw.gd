class_name CartographyDraw
extends RefCounted
## The ink of a Cartography map: terrain symbols, place icons, the route, compass roses, frames, cartouches and the
## scale bar, each drawn with CanvasItem calls (no image files). CartographyMap calls these; you can call them from
## your own _draw() too. Symbol hands: 1 pen, 2 woodcut, 3 painted, 4 pixel, 5 plan, 6 neon.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

const TAU_ := TAU


static func rnd(a: int, b: int, c: int) -> float:
	return float(posmod(hash(Vector3i(a, b, c)), 10000)) / 10000.0


## A polyline with a hand-drawn wobble. `wob` 0 = ruler straight.
static func ink(ci: CanvasItem, pts: PackedVector2Array, col: Color, w: float, wob := 0.0, seed := 0) -> void:
	if pts.size() < 2:
		return
	if wob <= 0.0:
		ci.draw_polyline(pts, col, w, true)
		return
	var out := PackedVector2Array()
	for i in pts.size() - 1:
		var a := pts[i]
		var b := pts[i + 1]
		var n := maxi(1, int(a.distance_to(b) / 6.0))
		var nrm := (b - a).orthogonal().normalized()
		for k in n:
			var t := float(k) / float(n)
			var j := (rnd(i, k, seed) - 0.5) * wob * 1.2
			out.append(a.lerp(b, t) + nrm * j)
	out.append(pts[pts.size() - 1])
	ci.draw_polyline(out, col, w, true)


static func _neon(ci: CanvasItem, pts: PackedVector2Array, col: Color, w: float) -> void:
	var g := col
	g.a = 0.18
	ci.draw_polyline(pts, g, w * 4.0, true)
	g.a = 0.45
	ci.draw_polyline(pts, g, w * 2.0, true)
	ci.draw_polyline(pts, col.lerp(Color.WHITE, 0.45), w, true)


static func _px(ci: CanvasItem, p: Vector2, u: float, col: Color) -> void:
	ci.draw_rect(Rect2(Vector2(floorf(p.x / u), floorf(p.y / u)) * u, Vector2(u, u)), col)


# ---- terrain symbols ---------------------------------------------------------------------------------------------

## A mountain symbol standing on `p` (its base centre), `s` px tall.
static func mountain(ci: CanvasItem, p: Vector2, s: float, mode: int, col: Color, paper: Color, seed: int, snow := false) -> void:
	var w := s * (0.75 + rnd(seed, 1, 3) * 0.4)
	var peak := p + Vector2((rnd(seed, 2, 3) - 0.5) * s * 0.25, -s)
	var l := p + Vector2(-w, 0)
	var r := p + Vector2(w, 0)
	match mode:
		3:
			var mid := p + Vector2(peak.x - p.x, 0)
			ci.draw_colored_polygon(PackedVector2Array([l, peak, mid]), col.lightened(0.25))
			ci.draw_colored_polygon(PackedVector2Array([mid, peak, r]), col.darkened(0.25))
			if snow:
				var c1 := peak.lerp(l, 0.32)
				var c2 := peak.lerp(r, 0.32)
				ci.draw_colored_polygon(PackedVector2Array([c1, peak, c2, peak.lerp(mid, 0.4)]), Color(0.97, 0.97, 0.95))
			ci.draw_polyline(PackedVector2Array([l, peak, r]), col.darkened(0.55), maxf(1.0, s * 0.06), true)
		4:
			var u := maxf(1.0, roundf(s / 6.0))
			for row in 6:
				var half := row
				for k in range(-half, half + 1):
					var c := col.darkened(0.3) if k > 0 else col.lightened(0.15)
					if snow and row < 2:
						c = Color(0.96, 0.96, 0.94)
					_px(ci, p + Vector2(k * u, (row - 6) * u), u, c)
		5:
			ci.draw_polyline(PackedVector2Array([l.lerp(p, 0.3), peak.lerp(p, 0.25), r.lerp(p, 0.3)]), col, maxf(1.0, s * 0.08), true)
		6:
			_neon(ci, PackedVector2Array([l, peak, r]), col, maxf(1.0, s * 0.06))
		_:
			ink(ci, PackedVector2Array([l, peak, r]), col, maxf(1.0, s * 0.07), s * 0.06, seed)
			for i in 3:
				var t := 0.25 + i * 0.22
				var a := peak.lerp(r, t)
				ci.draw_line(a, a + Vector2(-s * 0.22, s * 0.18), col, maxf(0.8, s * 0.05), true)
			if snow:
				ci.draw_polyline(PackedVector2Array([peak.lerp(l, 0.3), peak.lerp(p, 0.22), peak.lerp(r, 0.3)]), col, maxf(0.8, s * 0.05), true)


## A tree standing on `p`, `s` px tall. Conifers and broadleaves alternate by seed.
static func tree(ci: CanvasItem, p: Vector2, s: float, mode: int, col: Color, paper: Color, seed: int) -> void:
	var conifer := rnd(seed, 5, 1) < 0.45
	var crown := p + Vector2(0, -s * 0.62)
	var cr := s * 0.34
	match mode:
		3:
			ci.draw_line(p, p + Vector2(0, -s * 0.3), Color(0.36, 0.24, 0.14), maxf(1.0, s * 0.1))
			if conifer:
				ci.draw_colored_polygon(PackedVector2Array([p + Vector2(-s * 0.32, -s * 0.15), p + Vector2(0, -s), p + Vector2(s * 0.32, -s * 0.15)]), col.darkened(0.1))
			else:
				ci.draw_circle(crown, cr, col)
				ci.draw_circle(crown + Vector2(-cr * 0.3, -cr * 0.3), cr * 0.45, col.lightened(0.25))
		4:
			var u := maxf(1.0, roundf(s / 6.0))
			_px(ci, p + Vector2(0, -u), u, col.darkened(0.5))
			for row in 4:
				var half := 1 if row == 0 or row == 3 else 2
				for k in range(-half, half):
					_px(ci, p + Vector2(k * u, -(row + 2) * u), u, col if k < 0 else col.darkened(0.2))
		5:
			ci.draw_arc(crown, cr * 0.7, 0.0, TAU_, 10, col, maxf(1.0, s * 0.08), true)
		6:
			if conifer:
				_neon(ci, PackedVector2Array([p + Vector2(-s * 0.3, -s * 0.15), p + Vector2(0, -s), p + Vector2(s * 0.3, -s * 0.15), p + Vector2(-s * 0.3, -s * 0.15)]), col, maxf(1.0, s * 0.06))
			else:
				var g := col
				g.a = 0.3
				ci.draw_arc(crown, cr, 0.0, TAU_, 12, g, s * 0.2, true)
				ci.draw_arc(crown, cr, 0.0, TAU_, 12, col.lerp(Color.WHITE, 0.4), maxf(1.0, s * 0.06), true)
		_:
			ci.draw_line(p, p + Vector2(0, -s * 0.28), col, maxf(0.8, s * 0.06), true)
			if conifer:
				ink(ci, PackedVector2Array([p + Vector2(-s * 0.3, -s * 0.18), p + Vector2(0, -s), p + Vector2(s * 0.3, -s * 0.18), p + Vector2(-s * 0.3, -s * 0.18)]), col, maxf(0.8, s * 0.06), s * 0.04, seed)
			else:
				ci.draw_arc(crown, cr, PI * 0.15, PI * 2.05, 12, col, maxf(0.8, s * 0.06), true)


## Two small wave crests on open water.
static func wave(ci: CanvasItem, p: Vector2, s: float, mode: int, col: Color, seed: int) -> void:
	var w := maxf(0.8, s * 0.07)
	match mode:
		4:
			var u := maxf(1.0, roundf(s / 7.0))
			for k in 4:
				_px(ci, p + Vector2((k - 2) * u, -u * (1 if k % 2 == 0 else 0)), u, col)
		6:
			_neon(ci, PackedVector2Array([p + Vector2(-s * 0.4, 0), p + Vector2(-s * 0.2, -s * 0.15), p + Vector2(0, 0), p + Vector2(s * 0.2, -s * 0.15), p + Vector2(s * 0.4, 0)]), col, w)
		5:
			ci.draw_line(p + Vector2(-s * 0.3, 0), p + Vector2(s * 0.3, 0), col, w, true)
		_:
			for k in 2:
				var o := p + Vector2(k * s * 0.42 - s * 0.21, -k * s * 0.12)
				ci.draw_arc(o, s * 0.2, PI * 1.15, PI * 1.85, 6, col, w, true)


## A dune: an arc with a shaded lee side.
static func dune(ci: CanvasItem, p: Vector2, s: float, mode: int, col: Color, seed: int) -> void:
	var w := maxf(0.8, s * 0.06)
	if mode == 4:
		var u := maxf(1.0, roundf(s / 7.0))
		for k in 5:
			_px(ci, p + Vector2((k - 2) * u, -u * (2 - absi(k - 2))), u, col)
		return
	ci.draw_arc(p, s * 0.35, PI * 1.1, PI * 1.9, 8, col, w, true)
	for i in 3:
		ci.draw_circle(p + Vector2((rnd(seed, i, 2) - 0.2) * s * 0.4, s * 0.05 + rnd(seed, i, 5) * s * 0.12), maxf(0.6, s * 0.035), col)


# ---- places ------------------------------------------------------------------------------------------------------

## The icon of a place kind (CartographyJourney.Place) centred on `p`, about `s` px across.
static func place_icon(ci: CanvasItem, p: Vector2, s: float, kind: int, mode: int, col: Color, accent: Color, paper: Color) -> void:
	var w := maxf(1.0, s * 0.09)
	if mode == 1:
		ci.draw_circle(p, s * 0.22, paper)
		ci.draw_circle(p, s * 0.16, col)
		return
	if mode == 3:
		var u := maxf(1.0, roundf(s / 8.0))
		for y in 5:
			for x in 5:
				if (x + y) % 2 == 0 or kind == 7:
					_px(ci, p + Vector2((x - 2) * u, (y - 2) * u), u, accent if kind == 7 or kind == 9 else col)
		return
	var fill := paper
	var neon := mode == 4
	var c := col
	match kind:
		0:
			for k in 3:
				var o := p + Vector2((k - 1) * s * 0.3, (0.12 if k == 1 else 0.0) * s)
				var house := _shape(o, s, [-0.13, 0.18, -0.13, -0.02, 0.0, -0.18, 0.13, -0.02, 0.13, 0.18, -0.13, 0.18])
				if mode == 2:
					ci.draw_colored_polygon(house, fill)
					ci.draw_colored_polygon(PackedVector2Array([o + Vector2(-s * 0.15, -s * 0.01), o + Vector2(0, -s * 0.2), o + Vector2(s * 0.15, -s * 0.01)]), accent)
				_poly(ci, house, c, w, neon)
		1:
			# a keep with three merlons
			var body := _shape(p, s, [-0.3, 0.3, -0.3, -0.2, -0.18, -0.2, -0.18, -0.1, -0.06, -0.1, -0.06, -0.2, 0.06, -0.2,
				0.06, -0.1, 0.18, -0.1, 0.18, -0.2, 0.3, -0.2, 0.3, 0.3, -0.3, 0.3])
			if mode == 2:
				ci.draw_colored_polygon(body, fill)
			_poly(ci, body, c, w, neon)
			ci.draw_line(p + Vector2(0, -s * 0.2), p + Vector2(0, -s * 0.48), c, w, true)
			ci.draw_colored_polygon(PackedVector2Array([p + Vector2(0, -s * 0.48), p + Vector2(s * 0.2, -s * 0.42), p + Vector2(0, -s * 0.36)]), accent)
		2:
			var arch := PackedVector2Array()
			for i in 9:
				var a := PI + PI * float(i) / 8.0
				arch.append(p + Vector2(cos(a) * s * 0.3, sin(a) * s * 0.32 + s * 0.15))
			var solid := arch.duplicate()
			ci.draw_colored_polygon(solid, c.darkened(0.2) if not neon else Color(c, 0.35))
			_poly(ci, arch, c, w, neon)
			ci.draw_line(p + Vector2(-s * 0.42, s * 0.15), p + Vector2(s * 0.42, s * 0.15), c, w, true)
		3:
			for k in 3:
				var x := (k - 1) * s * 0.22
				var top := -s * (0.3 if k != 2 else 0.1) + (s * 0.12 if k == 0 else 0.0)
				ci.draw_line(p + Vector2(x, s * 0.25), p + Vector2(x, top), c, w * 1.6, true)
			ci.draw_line(p + Vector2(-s * 0.35, s * 0.25), p + Vector2(s * 0.35, s * 0.25), c, w, true)
			ci.draw_line(p + Vector2(-s * 0.3, -s * 0.3), p + Vector2(0.0, -s * 0.33), c, w, true)
		4:
			var tent := PackedVector2Array([p + Vector2(-s * 0.32, s * 0.25), p + Vector2(0, -s * 0.25), p + Vector2(s * 0.32, s * 0.25), p + Vector2(-s * 0.32, s * 0.25)])
			if mode == 2:
				ci.draw_colored_polygon(tent, accent.lightened(0.2))
			_poly(ci, tent, c, w, neon)
			ci.draw_line(p + Vector2(0, -s * 0.25), p + Vector2(0, -s * 0.45), c, w, true)
			ci.draw_line(p + Vector2(0, s * 0.25), p + Vector2(0, s * 0.02), c, w, true)
		5:
			ci.draw_arc(p + Vector2(0, -s * 0.28), s * 0.08, 0.0, TAU_, 8, c, w, true)
			ci.draw_line(p + Vector2(0, -s * 0.2), p + Vector2(0, s * 0.32), c, w * 1.3, true)
			ci.draw_line(p + Vector2(-s * 0.15, -s * 0.08), p + Vector2(s * 0.15, -s * 0.08), c, w, true)
			ci.draw_arc(p + Vector2(0, s * 0.05), s * 0.27, PI * 0.15, PI * 0.85, 10, c, w, true)
		6:
			for i in 8:
				var a := TAU_ * float(i) / 8.0
				var r := s * (0.36 if i % 2 == 0 else 0.22)
				ci.draw_line(p + Vector2(cos(a), sin(a)) * s * 0.1, p + Vector2(cos(a), sin(a)) * r, accent if i % 2 == 0 else c, w, true)
			ci.draw_circle(p, s * 0.09, c)
		7:
			var xw := w * 1.8
			ci.draw_line(p + Vector2(-s * 0.26, -s * 0.26), p + Vector2(s * 0.26, s * 0.26), accent, xw, true)
			ci.draw_line(p + Vector2(s * 0.26, -s * 0.26), p + Vector2(-s * 0.26, s * 0.26), accent, xw, true)
		8:
			var tri := PackedVector2Array([p + Vector2(-s * 0.3, s * 0.22), p + Vector2(0, -s * 0.3), p + Vector2(s * 0.3, s * 0.22), p + Vector2(-s * 0.3, s * 0.22)])
			if mode == 2:
				ci.draw_colored_polygon(tri, c)
			else:
				_poly(ci, tri, c, w, neon)
			ci.draw_circle(p + Vector2(0, -s * 0.3), w * 1.2, accent)
		9:
			ci.draw_circle(p + Vector2(0, -s * 0.05), s * 0.24, c)
			ci.draw_rect(Rect2(p + Vector2(-s * 0.13, s * 0.1), Vector2(s * 0.26, s * 0.16)), c)
			ci.draw_circle(p + Vector2(-s * 0.09, -s * 0.07), s * 0.065, paper)
			ci.draw_circle(p + Vector2(s * 0.09, -s * 0.07), s * 0.065, paper)
			ci.draw_line(p + Vector2(0, s * 0.12), p + Vector2(0, s * 0.25), paper, maxf(1.0, w * 0.8))
		10:
			var door := _shape(p, s, [-0.18, 0.28, -0.18, -0.08, -0.1, -0.24, 0.1, -0.24, 0.18, -0.08, 0.18, 0.28])
			ci.draw_colored_polygon(door, fill)
			_poly(ci, door, c, w, neon)
			ci.draw_line(p + Vector2(-s * 0.3, s * 0.28), p + Vector2(s * 0.3, s * 0.28), c, w, true)
		11:
			for i in 4:
				var y := -s * 0.27 + i * s * 0.18
				ci.draw_line(p + Vector2(-s * 0.3 + i * s * 0.05, y), p + Vector2(s * 0.3 - i * s * 0.05, y), c, w, true)
			ci.draw_line(p + Vector2(-s * 0.32, -s * 0.32), p + Vector2(-s * 0.15, s * 0.3), c, w, true)
			ci.draw_line(p + Vector2(s * 0.32, -s * 0.32), p + Vector2(s * 0.15, s * 0.3), c, w, true)


## A polygon from flat (x, y) pairs in units of `s`, around `p`.
static func _shape(p: Vector2, s: float, xy: Array) -> PackedVector2Array:
	var out := PackedVector2Array()
	for i in range(0, xy.size() - 1, 2):
		out.append(p + Vector2(float(xy[i]), float(xy[i + 1])) * s)
	return out


static func _poly(ci: CanvasItem, pts: PackedVector2Array, col: Color, w: float, neon: bool) -> void:
	if neon:
		_neon(ci, pts, col, w)
	else:
		ci.draw_polyline(pts, col, w, true)


# ---- the route and the player's marker ----------------------------------------------------------------------------

## Draws the route (px points, oldest first) in a style: 1 dashed, 2 dotted, 3 solid + arrows, 4 footprints,
## 5 double line, 6 glowing, 7 pixel steps.
static func route(ci: CanvasItem, pts: PackedVector2Array, mode: int, col: Color, w: float, paper: Color) -> void:
	if pts.size() < 2 or mode == 0:
		return
	match mode:
		1:
			var cum := _cumulative(pts)
			var total: float = cum[cum.size() - 1]
			var dash := w * 3.2 + 2.0
			var gap := w * 2.2 + 1.5
			var d := 0.0
			while d < total:
				var sub := _subpath(pts, cum, d, minf(total, d + dash))
				if sub.size() >= 2:
					ci.draw_polyline(sub, col, w, true)
				d += dash + gap
		2:
			_along(pts, 2.2 * w + 2.0, func(a: Vector2, _b: Vector2, _i: int) -> void:
				ci.draw_circle(a, w * 0.62, col))
		3:
			ci.draw_polyline(pts, col, w, true)
			_along(pts, 26.0, func(a: Vector2, b: Vector2, i: int) -> void:
				if i % 4 == 2:
					var d := (b - a).normalized()
					var n := d.orthogonal()
					var tip := a + d * w * 2.4
					ci.draw_colored_polygon(PackedVector2Array([tip, a - d * w * 1.2 + n * w * 2.0, a - d * w * 0.4, a - d * w * 1.2 - n * w * 2.0]), col))
		7:
			var u := maxf(2.0, roundf(w * 1.4))
			_along(pts, u * 2.0, func(a: Vector2, _b: Vector2, _i: int) -> void:
				_px(ci, a, u, col))
		8:
			var faint := col
			faint.a = 0.55
			ci.draw_polyline(pts, faint, maxf(1.0, w * 0.45), true)
			for i in pts.size():
				var s := w * (2.6 if i == 0 or i == pts.size() - 1 else 2.0)
				var glow := col
				glow.a = 0.25
				ci.draw_circle(pts[i], s * 1.1, glow)
				var star := _shape(pts[i], s, [0.0, -1.6, 0.3, -0.3, 1.6, 0.0, 0.3, 0.3, 0.0, 1.6, -0.3, 0.3, -1.6, 0.0, -0.3, -0.3])
				ci.draw_colored_polygon(star, col.lerp(Color.WHITE, 0.4))
			return
		_:
			ci.draw_polyline(pts, col, w, true)
	ci.draw_circle(pts[0], w * 1.4, paper)
	ci.draw_arc(pts[0], w * 1.4, 0.0, TAU_, 12, col, maxf(1.0, w * 0.5), true)


static func _cumulative(pts: PackedVector2Array) -> PackedFloat32Array:
	var cum := PackedFloat32Array([0.0])
	for i in range(1, pts.size()):
		cum.append(cum[i - 1] + pts[i - 1].distance_to(pts[i]))
	return cum


## The point at arc length `d` along a polyline.
static func _point_at(pts: PackedVector2Array, cum: PackedFloat32Array, d: float) -> Vector2:
	var i := cum.bsearch(d)
	if i <= 0:
		return pts[0]
	if i >= pts.size():
		return pts[pts.size() - 1]
	var seg := cum[i] - cum[i - 1]
	return pts[i - 1].lerp(pts[i], (d - cum[i - 1]) / maxf(seg, 0.0001))


## The piece of a polyline between arc lengths d0 and d1.
static func _subpath(pts: PackedVector2Array, cum: PackedFloat32Array, d0: float, d1: float) -> PackedVector2Array:
	var out := PackedVector2Array([_point_at(pts, cum, d0)])
	for i in pts.size():
		if cum[i] > d0 and cum[i] < d1:
			out.append(pts[i])
	out.append(_point_at(pts, cum, d1))
	return out


## Calls f(point, a point a little further on, index) every `step` px of arc length along a polyline.
static func _along(pts: PackedVector2Array, step: float, f: Callable) -> void:
	var cum := _cumulative(pts)
	var total: float = cum[cum.size() - 1]
	var d := step * 0.5
	var idx := 0
	while d < total:
		var p := _point_at(pts, cum, d)
		var q := _point_at(pts, cum, minf(total, d + maxf(1.0, step * 0.4)))
		if q.distance_to(p) < 0.01:
			q = p + Vector2(0.01, 0)
		f.call(p, q, idx)
		idx += 1
		d += step


static func _offset(pts: PackedVector2Array, d: float) -> PackedVector2Array:
	var out := PackedVector2Array()
	for i in pts.size():
		var a := pts[maxi(0, i - 1)]
		var b := pts[mini(pts.size() - 1, i + 1)]
		var n := (b - a).orthogonal().normalized()
		out.append(pts[i] + n * d)
	return out


## The "you are here" marker: 0 cross, 1 ship, 2 figure, 3 flag, 4 pin, 5 radar blip.
static func marker(ci: CanvasItem, p: Vector2, s: float, mode: int, col: Color, paper: Color, heading := 0.0) -> void:
	var w := maxf(1.2, s * 0.12)
	match mode:
		1:
			ci.draw_set_transform(p, 0.0, Vector2.ONE)
			var hull := PackedVector2Array([Vector2(-s * 0.5, 0), Vector2(s * 0.5, 0), Vector2(s * 0.32, s * 0.22), Vector2(-s * 0.36, s * 0.22)])
			ci.draw_colored_polygon(hull, col)
			ci.draw_line(Vector2(0, 0), Vector2(0, -s * 0.7), col, w * 0.7, true)
			ci.draw_colored_polygon(PackedVector2Array([Vector2(s * 0.04, -s * 0.66), Vector2(s * 0.38, -s * 0.12), Vector2(s * 0.04, -s * 0.12)]), paper)
			ci.draw_polyline(PackedVector2Array([Vector2(s * 0.04, -s * 0.66), Vector2(s * 0.38, -s * 0.12), Vector2(s * 0.04, -s * 0.12)]), col, w * 0.5, true)
			ci.draw_colored_polygon(PackedVector2Array([Vector2(-s * 0.04, -s * 0.55), Vector2(-s * 0.3, -s * 0.12), Vector2(-s * 0.04, -s * 0.12)]), paper)
			ci.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		3:
			ci.draw_line(p + Vector2(0, s * 0.2), p + Vector2(0, -s * 0.6), col, w * 0.8, true)
			ci.draw_colored_polygon(PackedVector2Array([p + Vector2(0, -s * 0.6), p + Vector2(s * 0.42, -s * 0.46), p + Vector2(0, -s * 0.3)]), col)
			ci.draw_circle(p + Vector2(0, s * 0.2), w, col)
		4:
			ci.draw_circle(p + Vector2(0, -s * 0.5), s * 0.24, col)
			ci.draw_colored_polygon(PackedVector2Array([p + Vector2(-s * 0.2, -s * 0.4), p, p + Vector2(s * 0.2, -s * 0.4)]), col)
			ci.draw_circle(p + Vector2(0, -s * 0.5), s * 0.09, paper)
		5:
			var g := col
			for k in 3:
				g.a = 0.5 - k * 0.15
				ci.draw_arc(p, s * (0.2 + k * 0.18), 0.0, TAU_, 18, g, w * 0.6, true)
			ci.draw_circle(p, s * 0.12, col.lerp(Color.WHITE, 0.5))
		_:
			ci.draw_line(p + Vector2(-s * 0.3, -s * 0.3), p + Vector2(s * 0.3, s * 0.3), col, w * 1.3, true)
			ci.draw_line(p + Vector2(s * 0.3, -s * 0.3), p + Vector2(-s * 0.3, s * 0.3), col, w * 1.3, true)


# ---- compass roses ----------------------------------------------------------------------------------------------

## A compass rose centred on `c`, radius `r`: 1 north arrow, 2 four-point star, 3 sixteen points, 4 with fleur-de-lis,
## 5 sun rose, 6 modern ring, 7 pixel, 8 radar sweep.
static func compass(ci: CanvasItem, c: Vector2, r: float, mode: int, col: Color, accent: Color, paper: Color, font_mode: int) -> void:
	var w := maxf(1.0, r * 0.035)
	match mode:
		1:
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(0, -r), c + Vector2(r * 0.28, r * 0.5), c + Vector2(0, r * 0.25)]), col)
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(0, -r), c + Vector2(0, r * 0.25), c + Vector2(-r * 0.28, r * 0.5)]), paper)
			ci.draw_polyline(PackedVector2Array([c + Vector2(0, -r), c + Vector2(r * 0.28, r * 0.5), c + Vector2(0, r * 0.25), c + Vector2(-r * 0.28, r * 0.5), c + Vector2(0, -r)]), col, w, true)
			CartographyLettering.draw_text(ci, "N", c + Vector2(0, r * 1.05), r * 0.38, col, font_mode, Color(0, 0, 0, 0), 1)
		2, 3, 4:
			if mode >= 3:
				ci.draw_arc(c, r * 0.62, 0.0, TAU_, 48, col, w, true)
				ci.draw_arc(c, r * 0.56, 0.0, TAU_, 48, col, w * 0.6, true)
			if mode == 4:
				ci.draw_arc(c, r * 1.02, 0.0, TAU_, 64, col, w, true)
				ci.draw_arc(c, r * 0.9, 0.0, TAU_, 64, col, w * 0.6, true)
				for i in 64:
					var a := TAU_ * float(i) / 64.0
					var l := 0.06 if i % 2 == 1 else 0.12
					ci.draw_line(c + Vector2(cos(a), sin(a)) * r * 0.9, c + Vector2(cos(a), sin(a)) * r * (0.9 + l), col, w * 0.6, true)
			var tiers := [[4, 0.0, 1.0], [4, PI / 4.0, 0.62]]
			if mode >= 3:
				tiers.append([8, PI / 8.0, 0.42])
			for t in range(tiers.size() - 1, -1, -1):
				var n: int = tiers[t][0]
				var a0: float = tiers[t][1]
				var len_: float = tiers[t][2]
				for i in n:
					var a := a0 + TAU_ * float(i) / float(n) - PI / 2.0
					var tip := c + Vector2(cos(a), sin(a)) * r * len_
					var side := Vector2(cos(a + PI / 2.0), sin(a + PI / 2.0)) * r * len_ * 0.18
					var base := c + Vector2(cos(a), sin(a)) * r * len_ * 0.12
					var dark := col if (t == 0 and i == 0 and mode == 4) == false else accent
					ci.draw_colored_polygon(PackedVector2Array([tip, base + side, c]), dark)
					ci.draw_colored_polygon(PackedVector2Array([tip, c, base - side]), paper)
					ci.draw_polyline(PackedVector2Array([tip, base + side, c, base - side, tip]), col, w * 0.7, true)
			ci.draw_circle(c, r * 0.05, col)
			if mode == 4:
				_fleur(ci, c + Vector2(0, -r * 1.18), r * 0.2, accent)
			else:
				CartographyLettering.draw_text(ci, "N", c + Vector2(0, -r * 1.08), r * 0.3, col, font_mode, Color(paper, 0.8), 1)
		5:
			for i in 24:
				var a := TAU_ * float(i) / 24.0
				var l := r * (0.95 if i % 2 == 0 else 0.7)
				var pts := PackedVector2Array()
				for k in 7:
					var t := float(k) / 6.0
					var rr := lerpf(r * 0.38, l, t)
					var aa := a + sin(t * PI * 2.0) * 0.05
					pts.append(c + Vector2(cos(aa), sin(aa)) * rr)
				ci.draw_polyline(pts, accent if i % 2 == 0 else col, w, true)
			ci.draw_circle(c, r * 0.36, accent)
			ci.draw_arc(c, r * 0.36, 0.0, TAU_, 24, col, w, true)
			ci.draw_circle(c, r * 0.24, paper)
			CartographyLettering.draw_text(ci, "N", c + Vector2(0, r * 0.1), r * 0.26, col, font_mode, Color(0, 0, 0, 0), 1)
		6:
			ci.draw_arc(c, r * 0.8, 0.0, TAU_, 48, col, w, true)
			for i in 36:
				var a := TAU_ * float(i) / 36.0
				var l := 0.12 if i % 9 == 0 else 0.06
				ci.draw_line(c + Vector2(cos(a), sin(a)) * r * 0.8, c + Vector2(cos(a), sin(a)) * r * (0.8 - l), col, w * 0.7, true)
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(0, -r * 0.62), c + Vector2(r * 0.14, 0), c + Vector2(-r * 0.14, 0)]), accent)
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(0, r * 0.62), c + Vector2(-r * 0.14, 0), c + Vector2(r * 0.14, 0)]), col)
			CartographyLettering.draw_text(ci, "N", c + Vector2(0, -r * 0.92), r * 0.24, col, font_mode, Color(0, 0, 0, 0), 1)
		7:
			var u := maxf(1.0, roundf(r / 8.0))
			for k in range(-6, 7):
				_px(ci, c + Vector2(0, k * u), u, accent if k < 0 else col)
				_px(ci, c + Vector2(k * u, 0), u, col)
			for k in range(-2, 3):
				_px(ci, c + Vector2(k * u, -5 * u), u, accent)
			CartographyLettering.draw_text(ci, "N", c + Vector2(0, -r * 0.95), r * 0.3, accent, 3, Color(0, 0, 0, 0), 1)
static func _fleur(ci: CanvasItem, p: Vector2, s: float, col: Color) -> void:
	ci.draw_colored_polygon(PackedVector2Array([p + Vector2(0, -s * 1.2), p + Vector2(s * 0.3, -s * 0.2), p + Vector2(0, s * 0.5), p + Vector2(-s * 0.3, -s * 0.2)]), col)
	ci.draw_arc(p + Vector2(-s * 0.55, -s * 0.2), s * 0.42, -PI * 0.1, PI * 0.9, 10, col, maxf(1.0, s * 0.22), true)
	ci.draw_arc(p + Vector2(s * 0.55, -s * 0.2), s * 0.42, PI * 0.1, -PI * 0.9, 10, col, maxf(1.0, s * 0.22), true)
	ci.draw_rect(Rect2(p + Vector2(-s * 0.55, s * 0.25), Vector2(s * 1.1, s * 0.22)), col)


# ---- frame, cartouche, scale bar ----------------------------------------------------------------------------------

## The neatline around the map rect `r`: 1 single, 2 double, 3 graduated checker band, 4 rope, 5 corner flourishes,
## 6 terminal brackets, 7 plan block, 8 gilded, 9 pixel.
static func frame(ci: CanvasItem, r: Rect2, mode: int, col: Color, accent: Color, paper: Color, k: float, unit: float) -> void:
	var w := maxf(1.0, unit * (0.8 + k * 1.6))
	match mode:
		1:
			ci.draw_rect(r, col, false, w)
		2, 7:
			ci.draw_rect(r.grow(w * 2.2), col, false, w * 1.6)
			ci.draw_rect(r, col, false, maxf(1.0, w * 0.6))
		3:
			var band := unit * (3.0 + k * 4.0)
			var outer := r.grow(band)
			ci.draw_rect(outer, col, false, maxf(1.0, w * 0.7))
			ci.draw_rect(r, col, false, maxf(1.0, w * 0.7))
			var seg := band * 2.2
			for side in 4:
				var horiz := side < 2
				var length := r.size.x if horiz else r.size.y
				var n := int(length / seg)
				for i in n:
					if i % 2 == 1:
						continue
					var a := float(i) * length / float(n)
					var b := float(i + 1) * length / float(n)
					var rect: Rect2
					match side:
						0:
							rect = Rect2(r.position.x + a, outer.position.y, b - a, band)
						1:
							rect = Rect2(r.position.x + a, r.end.y, b - a, band)
						2:
							rect = Rect2(outer.position.x, r.position.y + a, band, b - a)
						_:
							rect = Rect2(r.end.x, r.position.y + a, band, b - a)
					ci.draw_rect(rect, col)
			for corner in [outer.position, Vector2(r.end.x, outer.position.y), Vector2(outer.position.x, r.end.y), r.end]:
				ci.draw_rect(Rect2(corner, Vector2(band, band)), accent)
		4:
			var band := unit * 4.0
			var outer := r.grow(band)
			ci.draw_rect(outer, col, false, maxf(1.0, w * 0.6))
			ci.draw_rect(r, col, false, maxf(1.0, w * 0.6))
			var step := band * 0.9
			for side in 4:
				var a0: Vector2
				var dir: Vector2
				var length: float
				match side:
					0:
						a0 = outer.position + Vector2(0, band * 0.5)
						dir = Vector2.RIGHT
						length = outer.size.x
					1:
						a0 = Vector2(outer.position.x, r.end.y + band * 0.5)
						dir = Vector2.RIGHT
						length = outer.size.x
					2:
						a0 = outer.position + Vector2(band * 0.5, 0)
						dir = Vector2.DOWN
						length = outer.size.y
					_:
						a0 = Vector2(r.end.x + band * 0.5, outer.position.y)
						dir = Vector2.DOWN
						length = outer.size.y
				var n := int(length / step)
				var nrm := dir.orthogonal()
				for i in n:
					var p := a0 + dir * (float(i) + 0.5) * step
					ci.draw_line(p - dir * step * 0.45 - nrm * band * 0.35, p + dir * step * 0.45 + nrm * band * 0.35, col, maxf(1.0, w * 0.7), true)
		5:
			ci.draw_rect(r.grow(w * 2.2), col, false, w * 1.4)
			ci.draw_rect(r, col, false, maxf(1.0, w * 0.6))
			var s := unit * 9.0
			for i in 4:
				var cp: Vector2 = [r.position, Vector2(r.end.x, r.position.y), Vector2(r.position.x, r.end.y), r.end][i]
				var sx := 1.0 if i % 2 == 0 else -1.0
				var sy := 1.0 if i < 2 else -1.0
				ci.draw_arc(cp + Vector2(sx, sy) * s * 0.55, s * 0.45, 0.0, TAU_, 16, col, w, true)
				ci.draw_arc(cp + Vector2(sx * s * 1.4, sy * s * 0.35), s * 0.3, 0.0, PI if sy > 0 else -PI, 10, col, w * 0.8, true)
				ci.draw_arc(cp + Vector2(sx * s * 0.35, sy * s * 1.4), s * 0.3, -PI / 2.0, PI / 2.0, 10, col, w * 0.8, true)
				ci.draw_circle(cp + Vector2(sx, sy) * s * 0.55, s * 0.14, accent)
		9:
			var u := maxf(2.0, roundf(unit * 2.0))
			var outer := r.grow(u * 2.0)
			ci.draw_rect(Rect2(outer.position, Vector2(outer.size.x, u)), col)
			ci.draw_rect(Rect2(Vector2(outer.position.x, outer.end.y - u), Vector2(outer.size.x, u)), col)
			ci.draw_rect(Rect2(outer.position, Vector2(u, outer.size.y)), col)
			ci.draw_rect(Rect2(Vector2(outer.end.x - u, outer.position.y), Vector2(u, outer.size.y)), col)
			for corner in [outer.position, Vector2(outer.end.x - u * 3.0, outer.position.y), Vector2(outer.position.x, outer.end.y - u * 3.0), outer.end - Vector2(u * 3.0, u * 3.0)]:
				ci.draw_rect(Rect2(corner, Vector2(u * 3.0, u * 3.0)), accent)


## Where the title cartouche goes inside `area` at a corner (0 TL, 1 TR, 2 BL, 3 BR, 4 top centre). Empty when hidden.
static func cartouche_rect(area: Rect2, corner: int, mode: int, title: String, font_mode: int, unit: float) -> Rect2:
	if mode == 0 or title == "":
		return Rect2()
	var fs := unit * 8.5
	var tw := CartographyLettering.measure(title, fs, font_mode)
	var pad := unit * 7.0
	var size := Vector2(tw + pad * 2.0, fs + pad * 1.6)
	if mode == 5:
		size = Vector2(maxf(tw + pad * 2.0, unit * 90.0), fs * 3.6)
	if mode == 3:
		size.x += size.y * 1.6
	var m := unit * 6.0
	var pos: Vector2
	match corner:
		1:
			pos = Vector2(area.end.x - size.x - m, area.position.y + m)
		2:
			pos = Vector2(area.position.x + m, area.end.y - size.y - m)
		3:
			pos = area.end - size - Vector2(m, m)
		4:
			pos = Vector2(area.position.x + (area.size.x - size.x) * 0.5, area.position.y + m)
		_:
			pos = area.position + Vector2(m, m)
	if mode == 3:
		return Rect2(pos + Vector2(size.y * 0.8, 0), size - Vector2(size.y * 1.6, 0))
	return Rect2(pos, size)


## Draws the title cartouche into `r` (from cartouche_rect): 1 framed box, 2 scroll, 3 ribbon, 4 terminal header,
## 5 plan block, 6 plain title.
static func cartouche(ci: CanvasItem, r: Rect2, mode: int, title: String, col: Color, accent: Color, paper: Color, font_mode: int, unit: float) -> void:
	if mode == 0 or title == "" or not r.has_area():
		return
	var fs := unit * 8.5
	var base := Vector2(r.position.x + r.size.x * 0.5, r.position.y + r.size.y * 0.5 + fs * 0.5)
	var lw := maxf(1.0, unit * 0.9)
	match mode:
		1:
			ci.draw_rect(r, paper)
			ci.draw_rect(r, col, false, lw * 1.4)
			ci.draw_rect(r.grow(-unit * 2.2), col, false, lw * 0.6)
			for cp in [r.position, Vector2(r.end.x, r.position.y), Vector2(r.position.x, r.end.y), r.end]:
				ci.draw_circle(cp, unit * 2.0, accent)
		2:
			ci.draw_rect(r, paper)
			ci.draw_line(r.position, Vector2(r.end.x, r.position.y), col, lw, true)
			ci.draw_line(Vector2(r.position.x, r.end.y), r.end, col, lw, true)
			var rr := r.size.y * 0.5
			for side in 2:
				var x := r.position.x if side == 0 else r.end.x
				var sgn := -1.0 if side == 0 else 1.0
				ci.draw_circle(Vector2(x, r.position.y + rr), rr * 0.95, paper)
				ci.draw_arc(Vector2(x, r.position.y + rr), rr, -PI / 2.0, PI / 2.0 if side == 1 else -PI * 1.5, 16, col, lw, true)
				ci.draw_arc(Vector2(x + sgn * rr * 0.35, r.position.y + rr * 1.25), rr * 0.4, 0.0, TAU_, 12, col, lw * 0.8, true)
		3:
			var tail := r.size.y * 0.8
			var y1 := r.position.y + r.size.y * 0.15
			var ym := r.position.y + r.size.y * 0.5
			var y2 := r.end.y - r.size.y * 0.15
			var ribbon := PackedVector2Array([r.position, Vector2(r.end.x, r.position.y), Vector2(r.end.x + tail, y1),
				Vector2(r.end.x + tail * 0.6, ym), Vector2(r.end.x + tail, y2), r.end, Vector2(r.position.x, r.end.y),
				Vector2(r.position.x - tail, y2), Vector2(r.position.x - tail * 0.6, ym), Vector2(r.position.x - tail, y1)])
			ci.draw_colored_polygon(ribbon, accent)
			ribbon.append(r.position)
			ci.draw_polyline(ribbon, col, lw, true)
			CartographyLettering.draw_text(ci, title, base, fs, paper, font_mode, Color(0, 0, 0, 0), 1)
			return
		4:
			ci.draw_rect(r, Color(paper, 0.85))
			ci.draw_rect(r, col, false, lw)
			ci.draw_rect(Rect2(r.position, Vector2(unit * 3.0, r.size.y)), col)
			CartographyLettering.draw_text(ci, title, base, fs, col, font_mode, Color(0, 0, 0, 0), 1)
			return
		5:
			ci.draw_rect(r, paper)
			ci.draw_rect(r, col, false, lw * 1.2)
			ci.draw_line(Vector2(r.position.x, r.position.y + fs * 2.0), Vector2(r.end.x, r.position.y + fs * 2.0), col, lw * 0.7)
			ci.draw_line(Vector2(r.position.x + r.size.x * 0.5, r.position.y + fs * 2.0), Vector2(r.position.x + r.size.x * 0.5, r.end.y), col, lw * 0.7)
			CartographyLettering.draw_text(ci, title, Vector2(base.x, r.position.y + fs * 1.45), fs, col, font_mode, Color(0, 0, 0, 0), 1)
			CartographyLettering.draw_text(ci, "SHEET 1", Vector2(r.position.x + r.size.x * 0.25, r.end.y - fs * 0.45), fs * 0.5, col, font_mode, Color(0, 0, 0, 0), 1)
			CartographyLettering.draw_text(ci, "SURVEYED", Vector2(r.position.x + r.size.x * 0.75, r.end.y - fs * 0.45), fs * 0.5, col, font_mode, Color(0, 0, 0, 0), 1)
			return
	CartographyLettering.draw_text(ci, title, base, fs, col, font_mode, Color(paper, 0.0), 1)


## An alternating scale bar from `p` (left end), `length` px, labelled in `units`.
static func scale_bar(ci: CanvasItem, p: Vector2, length: float, col: Color, paper: Color, font_mode: int, unit: float, units := "LEAGUES") -> void:
	var h := unit * 2.4
	var n := 4
	for i in n:
		var r := Rect2(p + Vector2(length * float(i) / float(n), 0), Vector2(length / float(n), h))
		ci.draw_rect(r, col if i % 2 == 0 else paper)
	ci.draw_rect(Rect2(p, Vector2(length, h)), col, false, maxf(1.0, unit * 0.5))
	var fs := unit * 4.0
	CartographyLettering.draw_text(ci, "0", p + Vector2(0, -unit * 1.5), fs, col, font_mode, Color(0, 0, 0, 0), 1)
	CartographyLettering.draw_text(ci, "10", p + Vector2(length, -unit * 1.5), fs, col, font_mode, Color(0, 0, 0, 0), 1)
	CartographyLettering.draw_text(ci, units, p + Vector2(length * 0.5, h + fs + unit * 1.5), fs, col, font_mode, Color(0, 0, 0, 0), 1)


## A sea serpent in three humps, head to the right, about `s` px long.
static func sea_creature(ci: CanvasItem, p: Vector2, s: float, col: Color, paper: Color, mode: int) -> void:
	var w := maxf(1.0, s * 0.045)
	for k in 3:
		var c := p + Vector2((k - 1) * s * 0.28, 0)
		var pts := PackedVector2Array()
		for i in 13:
			var a := PI + PI * float(i) / 12.0
			pts.append(c + Vector2(cos(a) * s * 0.12, sin(a) * s * 0.13))
		if mode == 3 or mode == 2:
			var fill := pts.duplicate()
			ci.draw_colored_polygon(fill, col if mode == 2 else col.lightened(0.3))
		ci.draw_polyline(pts, col, w, true)
		ci.draw_line(c + Vector2(-s * 0.08, -s * 0.13), c + Vector2(-s * 0.02, -s * 0.2), col, w, true)
	var head := p + Vector2(s * 0.5, -s * 0.12)
	ci.draw_circle(head, s * 0.07, col)
	ci.draw_circle(head + Vector2(s * 0.02, -s * 0.02), s * 0.018, paper)
	ci.draw_line(head + Vector2(s * 0.06, s * 0.01), head + Vector2(s * 0.13, s * 0.03), col, w, true)
	ci.draw_line(p + Vector2(-s * 0.42, 0), p + Vector2(-s * 0.55, -s * 0.1), col, w, true)
	ci.draw_line(p + Vector2(-s * 0.42, 0), p + Vector2(-s * 0.55, s * 0.06), col, w, true)
	for k in 4:
		var x := p.x - s * 0.45 + k * s * 0.3
		ci.draw_line(Vector2(x, p.y + s * 0.02), Vector2(x + s * 0.12, p.y + s * 0.02), col, w * 0.7, true)
