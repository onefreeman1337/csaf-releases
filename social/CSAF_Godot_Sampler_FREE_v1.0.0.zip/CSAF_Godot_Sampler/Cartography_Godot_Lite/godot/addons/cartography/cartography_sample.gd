class_name CartographySample
extends RefCounted
## Two ready-made worlds for previews and the demo: an island realm and a dungeon. Each has a terrain function (the
## same thing a CartographyRecorder asks your TileMapLayer for) and a scripted journey through it. Deterministic.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

const K := CartographyJourney.Kind
const P := CartographyJourney.Place
const OW_SIZE := Vector2i(150, 96)
const DG_SIZE := Vector2i(96, 64)
const CELL := 16.0

static var _ow_cache: CartographyJourney
static var _dg_cache: CartographyJourney
static var _noise: FastNoiseLite
static var _moist: FastNoiseLite
static var _ow_kinds := PackedByteArray()
static var _dg_kinds := PackedByteArray()

# The overworld route: [cell x, cell y, reveal radius, place name, place kind (-1 none)]
const OW_ROUTE := [
	[46, 78, 12, "Saltmere", 5],
	[52, 66, 0, "", -1],
	[44, 56, 12, "Thornfield", 0],
	[34, 50, 10, "", -1],
	[36, 42, 0, "", -1],
	[40, 36, 11, "Old Barrow", 3],
	[52, 30, 0, "", -1],
	[60, 24, 17, "Cragspire", 8],
	[70, 32, 0, "", -1],
	[74, 44, 12, "Greywatch", 1],
	[86, 50, 11, "Wayrest", 4],
	[100, 46, 10, "", -1],
	[114, 38, 0, "", -1],
	[122, 30, 13, "The Sunken Bell", 6],
	[128, 22, 9, "", -1],
]
const OW_AREAS := [["The Greenwold", 30, 58], ["Ember Peaks", 66, 16], ["Sea of Lanterns", 94, 56], ["Gull Isle", 126, 38]]

# Dungeon rooms: [x, y, w, h] (floor cells); circular rooms are [cx, cy, r, -1]
const DG_ROOMS := [[6, 40, 12, 9], [24, 28, 14, 11], [48, 20, 7, -1], [62, 34, 16, 10], [40, 44, 14, 12], [76, 10, 14, 13], [62, 6, 8, 7], [84, 40, 8, 14]]
const DG_HALLS := [[0, 1], [1, 2], [2, 3], [1, 4], [4, 3], [3, 5], [5, 6], [3, 7]]
const DG_ROUTE := [
	[11, 44, 10, "Entrance", 11],
	[24, 40, 3, "", -1],
	[30, 33, 11, "Campfire", 4],
	[44, 25, 3, "", -1],
	[48, 20, 10, "Shrine of Ash", 6],
	[56, 28, 3, "", -1],
	[69, 39, 12, "Iron Door", 10],
	[46, 50, 10, "", -1],
	[60, 46, 3, "", -1],
	[72, 30, 3, "", -1],
	[82, 17, 11, "The Warden", 9],
]
const DG_AREAS := [["Upper Vaults", 30, 26], ["Drowned Hall", 47, 59], ["Warden's Keep", 83, 9]]


static func _setup_noise() -> void:
	if _noise != null:
		return
	_noise = FastNoiseLite.new()
	_noise.seed = 1337
	_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_noise.frequency = 0.035
	_noise.fractal_type = FastNoiseLite.FRACTAL_FBM
	_noise.fractal_octaves = 5
	_moist = FastNoiseLite.new()
	_moist.seed = 4242
	_moist.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_moist.frequency = 0.05
	_moist.fractal_type = FastNoiseLite.FRACTAL_FBM
	_moist.fractal_octaves = 3


static func _blob(c: Vector2, centre: Vector2, radius: Vector2) -> float:
	var d := (c - centre) / radius
	return exp(-d.dot(d) * 1.6)


## The overworld's height at a cell, 0 (deep sea) .. 1 (peak).
static func overworld_height(cell: Vector2i) -> float:
	_setup_noise()
	var c := Vector2(cell)
	var land := maxf(_blob(c, Vector2(52, 50), Vector2(44, 34)), maxf(_blob(c, Vector2(124, 30), Vector2(17, 13)) * 0.95, _blob(c, Vector2(110, 76), Vector2(9, 7)) * 0.85))
	var ridge := _blob(c, Vector2(62, 24), Vector2(22, 9)) * 0.42
	var n := _noise.get_noise_2d(c.x, c.y) * 0.5 + 0.5
	return clampf(land * 0.62 + ridge + (n - 0.5) * 0.55 + 0.08, 0.0, 1.0)


## The overworld's terrain kind at a cell (CartographyJourney.Kind).
static func overworld_kind(cell: Vector2i) -> int:
	if cell.x < 0 or cell.y < 0 or cell.x >= OW_SIZE.x or cell.y >= OW_SIZE.y:
		return K.DEEP
	if _ow_kinds.size() == OW_SIZE.x * OW_SIZE.y:
		return _ow_kinds[cell.y * OW_SIZE.x + cell.x]
	return _classify(cell)


static func _classify(cell: Vector2i) -> int:
	var h := overworld_height(cell)
	if h < 0.3:
		return K.DEEP
	if h < 0.42:
		return K.WATER
	if h < 0.455:
		return K.SAND
	if h > 0.8:
		return K.SNOW
	if h > 0.67:
		return K.MOUNTAIN
	var m := _moist.get_noise_2d(float(cell.x), float(cell.y)) * 0.5 + 0.5
	if m > 0.53:
		return K.FOREST
	return K.GROUND


static func _bake_overworld() -> void:
	if _ow_kinds.size() == OW_SIZE.x * OW_SIZE.y:
		return
	var buf := PackedByteArray()
	buf.resize(OW_SIZE.x * OW_SIZE.y)
	for y in OW_SIZE.y:
		for x in OW_SIZE.x:
			buf[y * OW_SIZE.x + x] = _classify(Vector2i(x, y))
	_ow_kinds = buf


## The dungeon's terrain kind at a cell: FLOOR in rooms and halls, WATER/DEEP in the drowned hall, WALL around them,
## VOID (solid rock) elsewhere.
static func dungeon_kind(cell: Vector2i) -> int:
	if cell.x < 0 or cell.y < 0 or cell.x >= DG_SIZE.x or cell.y >= DG_SIZE.y:
		return K.VOID
	_bake_dungeon()
	return _dg_kinds[cell.y * DG_SIZE.x + cell.x]


static func _room_rect(r: Array) -> Rect2i:
	if int(r[3]) < 0:
		return Rect2i(int(r[0]) - int(r[2]), int(r[1]) - int(r[2]), int(r[2]) * 2 + 1, int(r[2]) * 2 + 1)
	return Rect2i(int(r[0]), int(r[1]), int(r[2]), int(r[3]))


static func _bake_dungeon() -> void:
	if _dg_kinds.size() == DG_SIZE.x * DG_SIZE.y:
		return
	var w := DG_SIZE.x
	var buf := PackedByteArray()
	buf.resize(DG_SIZE.x * DG_SIZE.y)
	var floor_at := func(x: int, y: int) -> void:
		if x >= 0 and y >= 0 and x < DG_SIZE.x and y < DG_SIZE.y:
			buf[y * w + x] = K.FLOOR
	for r in DG_ROOMS:
		if int(r[3]) < 0:
			var c := Vector2i(int(r[0]), int(r[1]))
			var rad := int(r[2])
			for y in range(-rad, rad + 1):
				for x in range(-rad, rad + 1):
					if x * x + y * y <= rad * rad + rad:
						floor_at.call(c.x + x, c.y + y)
		else:
			for y in range(int(r[1]), int(r[1]) + int(r[3])):
				for x in range(int(r[0]), int(r[0]) + int(r[2])):
					floor_at.call(x, y)
	for h in DG_HALLS:
		var a := _room_rect(DG_ROOMS[int(h[0])]).get_center()
		var b := _room_rect(DG_ROOMS[int(h[1])]).get_center()
		var x := a.x
		var y := a.y
		while x != b.x:
			floor_at.call(x, y)
			floor_at.call(x, y + 1)
			x += signi(b.x - x)
		while y != b.y:
			floor_at.call(x, y)
			floor_at.call(x + 1, y)
			y += signi(b.y - y)
		floor_at.call(x, y)
	# the drowned hall: a pool in room 4, deep in the middle
	var pool := _room_rect(DG_ROOMS[4])
	var pc := Vector2(pool.get_center())
	for y in range(pool.position.y, pool.end.y):
		for x in range(pool.position.x, pool.end.x):
			var d := Vector2(x, y).distance_to(pc + Vector2(0, 1.5))
			if d < 3.6:
				buf[y * w + x] = K.DEEP
			elif d < 5.6:
				buf[y * w + x] = K.WATER
	# walls: two cells of wall around every open cell
	var open := buf.duplicate()
	for y in DG_SIZE.y:
		for x in DG_SIZE.x:
			if open[y * w + x] != K.VOID:
				continue
			var near := false
			for dy in range(-2, 3):
				for dx in range(-2, 3):
					var xx := x + dx
					var yy := y + dy
					if xx >= 0 and yy >= 0 and xx < DG_SIZE.x and yy < DG_SIZE.y and open[yy * w + xx] != K.VOID:
						near = true
			if near:
				buf[y * w + x] = K.WALL
	_dg_kinds = buf


## The cell path of a route table, interpolated with a gentle meander, as world px points.
static func route_points(table: Array, wander: float, seed: int) -> PackedVector2Array:
	var out := PackedVector2Array()
	for i in table.size() - 1:
		var a := Vector2(float(table[i][0]), float(table[i][1]))
		var b := Vector2(float(table[i + 1][0]), float(table[i + 1][1]))
		var n := maxi(2, int(a.distance_to(b) * 2.0))
		var nrm := (b - a).orthogonal().normalized()
		for k in n:
			var t := float(k) / float(n)
			var m := sin(t * PI) * sin(t * PI * 3.0 + float(i + seed)) * wander
			out.append((a.lerp(b, t) + nrm * m + Vector2(0.5, 0.5)) * CELL)
	var last: Array = table[table.size() - 1]
	out.append((Vector2(float(last[0]), float(last[1])) + Vector2(0.5, 0.5)) * CELL)
	return out


## Walks a journey along a route table up to `progress` (0..1 of the route): every step reveals `walk_radius` cells
## around the walker, and a row whose radius is larger (a town, a peak) reveals that much once on arrival.
static func walk(j: CartographyJourney, table: Array, kind_fn: Callable, progress := 1.0, wander := 2.2, seed := 3, walk_radius := 8) -> void:
	var pts := route_points(table, wander, seed)
	var stop := int(clampf(progress, 0.0, 1.0) * float(pts.size() - 1))
	var marks := {}
	for i in table.size():
		marks[Vector2i(int(table[i][0]), int(table[i][1]))] = i
	for i in stop + 1:
		var p := pts[i]
		j.add_route_point(p, 10.0)
		var c := j.world_to_cell(p)
		if marks.has(c):
			var row: Array = table[marks[c]]
			if str(row[3]) != "":
				j.add_place(str(row[3]), p, int(row[4]))
			if int(row[2]) > walk_radius:
				j.reveal_circle(c, int(row[2]), kind_fn)
			marks.erase(c)
		j.reveal_circle(c, walk_radius, kind_fn)


## The island realm, fully walked (cached; treat it as read-only).
static func overworld() -> CartographyJourney:
	if _ow_cache == null:
		_bake_overworld()
		var j := CartographyJourney.new()
		j.cell_size = CELL
		j.title = "The Lantern Coast"
		walk(j, OW_ROUTE, overworld_kind)
		for a in OW_AREAS:
			j.add_area(str(a[0]), (Vector2(float(a[1]), float(a[2])) + Vector2(0.5, 0.5)) * CELL)
		_ow_cache = j
	return _ow_cache


## The dungeon, fully walked (cached; treat it as read-only).
static func dungeon() -> CartographyJourney:
	if _dg_cache == null:
		_bake_dungeon()
		var j := CartographyJourney.new()
		j.cell_size = CELL
		j.title = "The Hollow Deep"
		walk(j, DG_ROUTE, dungeon_kind, 1.0, 0.6, 5, 3)
		for a in DG_AREAS:
			j.add_area(str(a[0]), (Vector2(float(a[1]), float(a[2])) + Vector2(0.5, 0.5)) * CELL)
		_dg_cache = j
	return _dg_cache
