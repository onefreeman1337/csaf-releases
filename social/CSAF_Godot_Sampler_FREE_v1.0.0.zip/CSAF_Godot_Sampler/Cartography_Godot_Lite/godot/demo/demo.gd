extends Control
## Cartography demo: an explorer walks the island (or the dungeon) with a CartographyRecorder, and the map fills in as
## they go. LEFT / RIGHT change the style, TAB switches world, WASD walks the explorer yourself, SPACE pauses,
## R sets out again, E exports the map as a PNG.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

const LITE := true
const SPEED := 110.0
const INK := Color("e9dcbc")
const DIM := Color("9a8a6a")
const DESK := Color("17130f")

var map: CartographyMap
var explorer: Node2D
var recorder: CartographyRecorder
var ids: Array[String] = []
var index := 0
var world := 0
var route := PackedVector2Array()
var route_d := 0.0
var cum := PackedFloat32Array()
var paused := false
var manual := false
var marks := {}
var status := ""
var status_t := 0.0
var _redraw_t := 0.0


func _ready() -> void:
	ids = Cartography.ids()
	map = CartographyMap.new()
	map.position = Vector2(24, 24)
	map.size = Vector2(880, 672)
	map.refresh_interval = 0.12
	add_child(map)
	explorer = Node2D.new()
	add_child(explorer)
	_set_out()


func _set_out() -> void:
	var table: Array = CartographySample.OW_ROUTE if world == 0 else CartographySample.DG_ROUTE
	route = CartographySample.route_points(table, 2.2 if world == 0 else 0.6, 3 if world == 0 else 5)
	cum = PackedFloat32Array([0.0])
	for i in range(1, route.size()):
		cum.append(cum[i - 1] + route[i - 1].distance_to(route[i]))
	marks.clear()
	for row in table:
		marks[Vector2i(int(row[0]), int(row[1]))] = row
	route_d = 0.0
	manual = false
	if recorder != null:
		recorder.queue_free()
	recorder = CartographyRecorder.new()
	recorder.journey = CartographyJourney.new()
	recorder.journey.cell_size = CartographySample.CELL
	recorder.journey.title = "The Lantern Coast" if world == 0 else "The Hollow Deep"
	recorder.reveal_radius = 8 if world == 0 else 3
	recorder.route_step = 10.0
	recorder.terrain_callable = CartographySample.overworld_kind if world == 0 else CartographySample.dungeon_kind
	explorer.position = route[0]
	explorer.add_child(recorder)
	var areas: Array = CartographySample.OW_AREAS if world == 0 else CartographySample.DG_AREAS
	for a in areas:
		recorder.journey.add_area(str(a[0]), (Vector2(float(a[1]), float(a[2])) + Vector2(0.5, 0.5)) * CartographySample.CELL)
	map.view = CartographyMap.View.FIXED
	map.fixed_rect = Rect2i(Vector2i.ZERO, CartographySample.OW_SIZE if world == 0 else CartographySample.DG_SIZE)
	map.scale_units = "LEAGUES" if world == 0 else "PACES"
	map.journey = recorder.journey
	_pick_style_for_world()


func _pick_style_for_world() -> void:
	var row := Cartography.info(ids[index])
	if (row.get("sample", "") == "dungeon") != (world == 1):
		for i in ids.size():
			var r := Cartography.info(ids[i])
			if (r.get("sample", "") == "dungeon") == (world == 1):
				index = i
				break
	map.style = Cartography.style(ids[index])
	queue_redraw()


func _process(delta: float) -> void:
	status_t = maxf(0.0, status_t - delta)
	_redraw_t += delta
	if _redraw_t > 0.5:
		_redraw_t = 0.0
		queue_redraw()
	if paused:
		return
	var move := Vector2.ZERO
	if Input.is_physical_key_pressed(KEY_A):
		move.x -= 1.0
	if Input.is_physical_key_pressed(KEY_D):
		move.x += 1.0
	if Input.is_physical_key_pressed(KEY_W):
		move.y -= 1.0
	if Input.is_physical_key_pressed(KEY_S):
		move.y += 1.0
	if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_D):
		manual = true
		explorer.position += move.normalized() * SPEED * 1.2 * delta
		return
	if manual or cum.size() < 2:
		return
	var total: float = cum[cum.size() - 1]
	if route_d >= total:
		return
	route_d = minf(total, route_d + SPEED * delta)
	var i := cum.bsearch(route_d)
	i = clampi(i, 1, route.size() - 1)
	var t := (route_d - cum[i - 1]) / maxf(0.001, cum[i] - cum[i - 1])
	explorer.position = route[i - 1].lerp(route[i], t)
	var c := recorder.journey.world_to_cell(explorer.position)
	if marks.has(c):
		var row: Array = marks[c]
		marks.erase(c)
		if str(row[3]) != "":
			recorder.mark_place(str(row[3]), int(row[4]))
		if int(row[2]) > recorder.reveal_radius:
			recorder.journey.reveal_circle(c, int(row[2]), recorder.kind_at)


func _unhandled_key_input(event: InputEvent) -> void:
	var k := event as InputEventKey
	if k == null or not k.pressed or k.echo:
		return
	match k.physical_keycode:
		KEY_RIGHT, KEY_PERIOD:
			_step_style(1)
		KEY_LEFT, KEY_COMMA:
			_step_style(-1)
		KEY_TAB:
			world = 1 - world
			_set_out()
		KEY_SPACE:
			paused = not paused
			queue_redraw()
		KEY_R:
			_set_out()
		KEY_E:
			_export()


func _step_style(d: int) -> void:
	var n := ids.size()
	for s in n:
		index = posmod(index + d, n)
		if (Cartography.info(ids[index]).get("sample", "") == "dungeon") == (world == 1):
			break
	map.style = Cartography.style(ids[index])
	queue_redraw()


func _export() -> void:
	var path := "user://cartography_%s.png" % ids[index]
	var err: Error = await map.export_png(path, Vector2i(1760, 1344))
	status = ("Saved %s" % ProjectSettings.globalize_path(path)) if err == OK else ("Export failed (%d)" % err)
	status_t = 4.0
	queue_redraw()
	print("CARTOGRAPHY_EXPORT|%s|%d" % [path, err])


func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), DESK)
	var x := 928.0
	var card := Rect2(x, 24, 328, 672)
	draw_rect(card, Color("2a231c"))
	draw_rect(card, Color("5a4a36"), false, 2.0)
	draw_rect(card.grow(-6), Color("5a4a36"), false, 1.0)
	var L := CartographyLettering
	L.draw_text(self, "CARTOGRAPHY", Vector2(x + 164, 76), 22.0, INK, 0, Color(0, 0, 0, 0), 1)
	L.draw_text(self, "journey maps for Godot 4", Vector2(x + 164, 100), 9.0, DIM, 1, Color(0, 0, 0, 0), 1)
	draw_line(Vector2(x + 30, 116), Vector2(x + 298, 116), Color("5a4a36"), 1.0)
	var row := Cartography.info(ids[index])
	var fam := str(row.get("family", ""))
	L.draw_text(self, "%d / %d" % [index + 1, ids.size()], Vector2(x + 164, 150), 10.0, DIM, 0, Color(0, 0, 0, 0), 1)
	L.draw_text(self, str(row.get("name", "")), Vector2(x + 164, 182), 15.0, INK, 0, Color(0, 0, 0, 0), 1)
	L.draw_text(self, fam.to_upper(), Vector2(x + 164, 204), 9.0, Color("c8963a"), 2, Color(0, 0, 0, 0), 1)
	var fy := 240.0
	for f in Cartography.FAMILIES:
		var on := f == fam
		var col := INK if on else Color("6a5a44")
		if on:
			draw_rect(Rect2(x + 40, fy - 13, 248, 18), Color("3a3024"))
		L.draw_text(self, "%s  (%d)" % [f.to_upper(), Cartography.ids_for_family(f).size()], Vector2(x + 52, fy), 9.0, col, 0)
		fy += 24.0
	var hints := [["LEFT / RIGHT", "style"], ["TAB", "island / dungeon"], ["W A S D", "walk yourself"], ["SPACE", "pause" if not paused else "resume"], ["R", "set out again"], ["E", "export as PNG"]]
	var hy := 380.0
	for h in hints:
		L.draw_text(self, h[0], Vector2(x + 44, hy), 9.0, Color("c8963a"), 2)
		L.draw_text(self, h[1], Vector2(x + 300, hy), 9.0, INK, 1, Color(0, 0, 0, 0), 2)
		hy += 26.0
	var cells := recorder.journey.cells.size() if recorder != null else 0
	L.draw_text(self, "%d cells mapped" % cells, Vector2(x + 164, 560), 9.0, DIM, 0, Color(0, 0, 0, 0), 1)
	if LITE:
		L.draw_text(self, "LITE: 12 OF 48 STYLES", Vector2(x + 164, 600), 9.0, Color("c8963a"), 2, Color(0, 0, 0, 0), 1)
		L.draw_text(self, "csaf.itch.io/cartography-godot", Vector2(x + 164, 620), 8.0, INK, 1, Color(0, 0, 0, 0), 1)
	if status_t > 0.0:
		L.draw_text(self, status.left(46), Vector2(x + 164, 660), 7.0, INK, 1, Color(0, 0, 0, 0), 1)
