# Weatherglass Lite - 12 free 2D weather shaders for Godot 4

The free sampler of **Weatherglass**: full-screen weather layers drawn live by shaders, on their own CanvasLayer so they
follow the screen, with a `WeatherController` that blends from one weather to the next. No images ship.

- **Godot version:** built and tested on **Godot 4.7.2**, under **both renderers: Forward+ and Compatibility**. Older 4.x
  versions were NOT run, so they are not claimed.
- **In the lite (12):** precip `drizzle`, `downpour`, `gentle_snow` · air `fog_bank`, `dust_motes`, `embers` · sky
  `god_rays`, `starfield`, `lightning` · nature `falling_leaves`, `cherry_petals`, `fireflies`.

**The full pack** has 48 layers: adds storm rain, rain on glass, sleet, hail, blizzards, snow globes, meteor showers,
mist, haze, sandstorms, pollen, ash, smoke, spores, aurora, moonlight, sunsets, rainbows, cloud shadows, lantern light,
caustics, sun glare, heat haze, dandelion seeds, bubbles, ripples, puddle splashes, feathers, magic dust, sparks, snow
clumps and floating lanterns. The lite's shaders carry only the 12 layers above.

## Install

1. Copy `godot/addons/weatherglass/` into your project's `addons/` folder.
2. No plugin to enable: `WeatherLayer`, `WeatherController`, `WeatherPalette` and `WeatherCatalog` register themselves.

## Use it

```gdscript
var weather := WeatherController.new()
add_child(weather)
weather.set_weather("downpour", 2.0)
weather.add_weather("lightning", 1.0)
weather.clear(3.0)
```

Exported on every layer: `palette` (`tint` and `glow`), `amount`, `speed_scale`, `intensity`, `wind`, `layer`,
`preview_time`. Demo controls: Left / Right preset · Up / Down group · B blend to the next · S stack fog · C clear · H help.

## Licence and AI disclosure

MIT (see `LICENSE.txt`). This lite is AI-generated: the shaders, scenes and scripts were written by an AI.

Core Systems Asset Factory
