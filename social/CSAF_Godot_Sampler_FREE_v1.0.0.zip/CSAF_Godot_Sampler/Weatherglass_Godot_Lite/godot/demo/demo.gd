extends Node2D
## Weatherglass demo: every preset over a small drawn landscape, and the WeatherController blending between them.
##   Left / Right   previous / next preset          Up / Down   previous / next group
##   B   blend to the next preset over 3 s (WeatherController.set_weather)    S   stack fog_bank on top    C   clear
##   H   hide the help line
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

var index := 0
var controller: WeatherController
var label: Label
var help: Label
var ids: Array[String] = []


func _ready() -> void:
	for p in WeatherCatalog.PRESETS:
		ids.append(String(p["id"]))
	controller = WeatherController.new()
	add_child(controller)
	var ui := CanvasLayer.new()
	ui.layer = 20
	add_child(ui)
	label = Label.new()
	label.position = Vector2(28, 16)
	label.add_theme_font_size_override("font_size", 26)
	label.add_theme_color_override("font_color", Color(0.96, 0.94, 0.88))
	label.add_theme_color_override("font_outline_color", Color(0.05, 0.06, 0.08))
	label.add_theme_constant_override("outline_size", 6)
	ui.add_child(label)
	help = Label.new()
	help.position = Vector2(28, 680)
	help.add_theme_font_size_override("font_size", 15)
	help.add_theme_color_override("font_color", Color(0.9, 0.9, 0.86))
	help.add_theme_color_override("font_outline_color", Color(0.05, 0.06, 0.08))
	help.add_theme_constant_override("outline_size", 4)
	help.text = "Left/Right preset   Up/Down group   B blend to next (3 s)   S stack fog   C clear   H help"
	ui.add_child(help)
	_show(0, 0.0)


func _show(i: int, blend: float) -> void:
	index = wrapi(i, 0, ids.size())
	controller.set_weather(ids[index], blend)
	var g := String(WeatherCatalog.PRESETS[index]["group"])
	label.text = "%s  -  %s   (%d / %d)" % [g.capitalize(), ids[index].capitalize(), index + 1, ids.size()]


func _group_step(d: int) -> void:
	var g := String(WeatherCatalog.PRESETS[index]["group"])
	var i := index
	for k in ids.size():
		i = wrapi(i + d, 0, ids.size())
		if String(WeatherCatalog.PRESETS[i]["group"]) != g:
			break
	_show(i, 0.0)


func _unhandled_input(e: InputEvent) -> void:
	if not (e is InputEventKey and e.pressed and not e.echo):
		return
	match e.keycode:
		KEY_RIGHT: _show(index + 1, 0.0)
		KEY_LEFT: _show(index - 1, 0.0)
		KEY_DOWN: _group_step(1)
		KEY_UP: _group_step(-1)
		KEY_B: _show(index + 1, 3.0)
		KEY_S: controller.add_weather("fog_bank", 1.5)
		KEY_C: controller.clear(1.0)
		KEY_H: help.visible = not help.visible


func _draw() -> void:
	# a small night-and-day-neutral landscape the weather sits over: sky bands, two hill lines, a row of rooftops
	var w := 1280.0
	var h := 720.0
	# the sky: a smooth vertical gradient (twelve flat bands read as stripes behind the weather)
	var sky := PackedColorArray([Color(0.2, 0.26, 0.36), Color(0.2, 0.26, 0.36), Color(0.46, 0.52, 0.58), Color(0.46, 0.52, 0.58)])
	draw_polygon(PackedVector2Array([Vector2(0, 0), Vector2(w, 0), Vector2(w, h * 0.62), Vector2(0, h * 0.62)]), PackedColorArray([sky[0], sky[1], sky[2], sky[3]]))
	var far := PackedVector2Array([Vector2(0, h)])
	var near := PackedVector2Array([Vector2(0, h)])
	for x in range(0, 1281, 32):
		far.append(Vector2(x, h * 0.58 + sin(x * 0.006) * 40.0 + sin(x * 0.017) * 14.0))
		near.append(Vector2(x, h * 0.7 + sin(x * 0.004 + 2.0) * 30.0 + sin(x * 0.021) * 10.0))
	far.append(Vector2(w, h))
	near.append(Vector2(w, h))
	draw_colored_polygon(far, Color(0.24, 0.3, 0.32))
	draw_colored_polygon(near, Color(0.16, 0.21, 0.2))
	for i in 9:
		var x := 120.0 + i * 120.0
		var y := h * 0.74 + sin(i * 1.7) * 12.0
		draw_rect(Rect2(x, y, 64, 56), Color(0.12, 0.13, 0.15))
		draw_colored_polygon(PackedVector2Array([Vector2(x - 8, y), Vector2(x + 32, y - 34), Vector2(x + 72, y)]), Color(0.1, 0.1, 0.12))
		draw_rect(Rect2(x + 22, y + 18, 14, 14), Color(0.95, 0.75, 0.4) if i % 3 != 1 else Color(0.2, 0.22, 0.26))
	draw_rect(Rect2(0, h * 0.86, w, h * 0.14), Color(0.12, 0.15, 0.14))
