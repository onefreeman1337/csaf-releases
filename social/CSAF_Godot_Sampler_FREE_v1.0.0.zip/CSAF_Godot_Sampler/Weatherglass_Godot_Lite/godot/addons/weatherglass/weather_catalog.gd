class_name WeatherCatalog
extends RefCounted
## Every Weatherglass preset, by id. Generated; do not edit by hand.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

const GROUPS: Array[String] = ["precip", "air", "sky", "nature"]
const PRESETS: Array[Dictionary] = [
	{"id": "drizzle", "group": "precip", "path": "res://addons/weatherglass/presets/precip/drizzle.tscn"},
	{"id": "downpour", "group": "precip", "path": "res://addons/weatherglass/presets/precip/downpour.tscn"},
	{"id": "gentle_snow", "group": "precip", "path": "res://addons/weatherglass/presets/precip/gentle_snow.tscn"},
	{"id": "fog_bank", "group": "air", "path": "res://addons/weatherglass/presets/air/fog_bank.tscn"},
	{"id": "dust_motes", "group": "air", "path": "res://addons/weatherglass/presets/air/dust_motes.tscn"},
	{"id": "embers", "group": "air", "path": "res://addons/weatherglass/presets/air/embers.tscn"},
	{"id": "god_rays", "group": "sky", "path": "res://addons/weatherglass/presets/sky/god_rays.tscn"},
	{"id": "starfield", "group": "sky", "path": "res://addons/weatherglass/presets/sky/starfield.tscn"},
	{"id": "lightning", "group": "sky", "path": "res://addons/weatherglass/presets/sky/lightning.tscn"},
	{"id": "falling_leaves", "group": "nature", "path": "res://addons/weatherglass/presets/nature/falling_leaves.tscn"},
	{"id": "cherry_petals", "group": "nature", "path": "res://addons/weatherglass/presets/nature/cherry_petals.tscn"},
	{"id": "fireflies", "group": "nature", "path": "res://addons/weatherglass/presets/nature/fireflies.tscn"},
]


static func path_of(id: String) -> String:
	for p in PRESETS:
		if p["id"] == id:
			return p["path"]
	return ""


static func instantiate(id: String) -> WeatherLayer:
	var path := path_of(id)
	if path == "":
		push_warning("Weatherglass: no preset named %s" % id)
		return null
	return (load(path) as PackedScene).instantiate() as WeatherLayer


static func ids_for_group(group: String) -> Array[String]:
	var out: Array[String] = []
	for p in PRESETS:
		if p["group"] == group:
			out.append(p["id"])
	return out
