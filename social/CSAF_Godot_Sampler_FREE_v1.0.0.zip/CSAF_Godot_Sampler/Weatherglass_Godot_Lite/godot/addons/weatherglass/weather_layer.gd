@tool
class_name WeatherLayer
extends Node2D
## One Weatherglass preset: a full-screen weather layer drawn by a shader, on its own CanvasLayer so it follows the
## screen, not the world. Fade it in and out with fade_in() / fade_out(), or let a WeatherController blend between layers.
##
##   var rain := WeatherCatalog.instantiate("downpour")
##   add_child(rain)
##   rain.fade_in(2.0)
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

## Emitted when a fade_out() reaches zero.
signal faded_out

## Body colour (tint) and highlight colour (glow) of the weather.
@export var palette: WeatherPalette:
	set(value):
		palette = value
		_apply_static()
## Strength of the weather, 0..1 (fades move this).
@export_range(0.0, 1.0, 0.01) var amount := 1.0:
	set(value):
		amount = value
		_push_amount()
## Playback speed multiplier.
@export_range(0.0, 4.0, 0.01, "or_greater") var speed_scale := 1.0
## Brightness multiplier.
@export_range(0.0, 3.0, 0.01) var intensity := 1.0:
	set(value):
		intensity = value
		_apply_static()
## Horizontal wind (-2..2), read by the rain, snow and drift layers.
@export_range(-2.0, 2.0, 0.01) var wind := 0.0:
	set(value):
		wind = value
		_apply_static()
## CanvasLayer order: put weather above the world and below your UI.
@export var layer := 5:
	set(value):
		layer = value
		if _canvas:
			_canvas.layer = value
## Seconds into the weather shown by seek_preview() and thumbnails.
@export_range(0.0, 60.0, 0.01) var preview_time := 2.0

var _t := 0.0
var _frozen := false
var _fade_from := 1.0
var _fade_to := 1.0
var _fade_len := 0.0
var _fade_t := 0.0
var _canvas: CanvasLayer
var _rect: ColorRect


func _ready() -> void:
	_canvas = get_node_or_null("Canvas") as CanvasLayer
	if _canvas:
		_canvas.layer = layer
	_rect = get_node_or_null("Canvas/Weather") as ColorRect
	_apply_static()
	_push_amount()
	_push_time()


func _process(delta: float) -> void:
	if _rect:
		var vs := get_viewport().get_visible_rect().size
		if _rect.size != vs:
			_rect.size = vs
			_apply_static()
	if _frozen:
		return
	_t += delta * speed_scale
	if _fade_len > 0.0:
		_fade_t += delta
		amount = lerpf(_fade_from, _fade_to, clampf(_fade_t / _fade_len, 0.0, 1.0))
		if _fade_t >= _fade_len:
			_fade_len = 0.0
			if _fade_to <= 0.0:
				faded_out.emit()
	_push_time()


## Fade the weather in from nothing over `seconds`.
func fade_in(seconds := 1.5) -> void:
	_start_fade(0.0, 1.0, seconds)


## Fade the weather out over `seconds`; emits faded_out at the end.
func fade_out(seconds := 1.5) -> void:
	_start_fade(amount, 0.0, seconds)


## Freeze on a moment `seconds` into the weather (stills, thumbnails).
func seek(seconds: float) -> void:
	_t = maxf(seconds, 0.0)
	_frozen = true
	_push_time()


func seek_preview() -> void:
	seek(preview_time)


## Alias of seek_preview(), called by CSAF's capture harness when it photographs each preset.
func csaf_preview() -> void:
	seek_preview()


func _start_fade(from: float, to: float, seconds: float) -> void:
	_frozen = false
	_fade_from = from
	_fade_to = to
	_fade_len = maxf(seconds, 0.001)
	_fade_t = 0.0
	amount = from


func _mat() -> ShaderMaterial:
	return _rect.material as ShaderMaterial if _rect else null


func _push_time() -> void:
	var m := _mat()
	if m:
		RenderingServer.material_set_param(m.get_rid(), &"wg_time", _t)


func _push_amount() -> void:
	var m := _mat()
	if m:
		RenderingServer.material_set_param(m.get_rid(), &"amount", amount)


func _apply_static() -> void:
	var m := _mat()
	if m == null:
		return
	var rid := m.get_rid()
	RenderingServer.material_set_param(rid, &"intensity", intensity)
	RenderingServer.material_set_param(rid, &"wind", wind)
	RenderingServer.material_set_param(rid, &"view_size", _rect.size)
	if palette:
		RenderingServer.material_set_param(rid, &"tint", palette.tint)
		RenderingServer.material_set_param(rid, &"glow", palette.glow)
