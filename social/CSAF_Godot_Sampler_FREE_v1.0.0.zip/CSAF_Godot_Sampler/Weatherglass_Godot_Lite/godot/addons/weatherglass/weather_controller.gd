class_name WeatherController
extends Node
## Blends between Weatherglass presets: set_weather("downpour", 3.0) fades the current weather out and the new one in
## over three seconds. Layers can be stacked (rain + fog + lightning) with add_weather(). Add it to your scene (or as an
## autoload) and call it from your game.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

## Emitted when a blend finishes.
signal weather_changed(ids: Array)

var _active: Dictionary = {}


## Replace every active weather with `ids` (one id or an Array of ids), crossfading over `seconds`.
func set_weather(ids, seconds := 2.0) -> void:
	var want: Array = ids if ids is Array else [ids]
	for id in _active.keys():
		if not want.has(id):
			_remove(id, seconds)
	for id in want:
		if not _active.has(id):
			add_weather(id, seconds)
	get_tree().create_timer(seconds).timeout.connect(func() -> void: weather_changed.emit(want))


## Fade one weather in on top of whatever is active.
func add_weather(id: String, seconds := 2.0) -> WeatherLayer:
	if _active.has(id):
		return _active[id]
	var layer := WeatherCatalog.instantiate(id)
	if layer == null:
		return null
	add_child(layer)
	layer.fade_in(seconds)
	_active[id] = layer
	return layer


## Fade one weather out and free it.
func remove_weather(id: String, seconds := 2.0) -> void:
	_remove(id, seconds)


## Clear all weather.
func clear(seconds := 2.0) -> void:
	for id in _active.keys():
		_remove(id, seconds)


func active_ids() -> Array:
	return _active.keys()


func _remove(id: String, seconds: float) -> void:
	if not _active.has(id):
		return
	var layer: WeatherLayer = _active[id]
	_active.erase(id)
	layer.faded_out.connect(layer.queue_free)
	layer.fade_out(seconds)
