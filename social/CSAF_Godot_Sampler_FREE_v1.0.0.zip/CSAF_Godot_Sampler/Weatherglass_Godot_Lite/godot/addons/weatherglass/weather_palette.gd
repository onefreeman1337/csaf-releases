@tool
class_name WeatherPalette
extends Resource
## Two colours that recolour any Weatherglass layer: tint (the body of rain, fog, leaves) and glow (highlights, flashes).
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

@export var tint := Color(0.75, 0.82, 0.95):
	set(value):
		tint = value
		emit_changed()
@export var glow := Color(1.0, 1.0, 1.0):
	set(value):
		glow = value
		emit_changed()
