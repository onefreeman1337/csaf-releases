extends Node2D
## One Fogbank look, previewed over the demo crypt in ONE fixed situation: an explorer came up from the chasm hall, crossed
## the library and stands in the second room with a lantern (radius 104 px, walls block it). Every scene in demo/presets/ is
## this script with a different look, so the looks are compared on identical ground. The crypt with no fog at all is the
## CONTROL (demo/control.tscn): every look must visibly change it. Open one and press F6 to see it alone.
## Copyright (c) 2026 Core Systems Asset Factory.

## The map point (pixels) at the centre of the 480 x 320 capture window.
const VIEW := Vector2(240, 176)
## The explorer's route so far, map pixels; it ends where the explorer stands.
const ROUTE := [Vector2(72, 280), Vector2(104, 216), Vector2(104, 168), Vector2(104, 120), Vector2(152, 104), Vector2(200, 104), Vector2(248, 96), Vector2(280, 88)]
const SIGHT := 104.0

@export var look: FogLook
## FogBank.Memory as an int (0 none, 1 dim, 2 keep, 3 fade).
@export var memory := 1
## Seconds into the look's motion to show (negative = the bank's own preview_time).
@export var show_time := -1.0
## A cone instead of a radius (degrees; 360 = radius).
@export var cone := 360.0

var crypt: DemoCrypt
var walker: DemoWalker
var bank: FogBank


func _ready() -> void:
	crypt = DemoCrypt.new()
	crypt.position = -VIEW
	add_child(crypt)
	crypt.build()
	walker = DemoWalker.new()
	walker.position = ROUTE[ROUTE.size() - 1] - VIEW
	add_child(walker)
	if look == null:
		return
	var rv := FogRevealer.new()
	rv.radius = SIGHT if cone >= 359.5 else SIGHT * 1.6
	rv.cone_degrees = cone
	rv.near_radius = 20.0 if cone < 359.5 else 0.0
	rv.auto_face = false
	rv.facing = Vector2(1, 0.15)
	rv.position = Vector2(0, -6)
	walker.add_child(rv)
	bank = FogBank.new()
	bank.position = -VIEW
	bank.cell_size = 8.0
	bank.fog_rect = Rect2(Vector2.ZERO, crypt.map_size)
	bank.memory = memory
	bank.wall_layer = crypt.ground
	bank.look = look
	add_child(bank)


## Called by the CSAF capture stage: the route is walked, the look seeks to its showcase moment, and everything holds still
## so both renderers photograph the same instant.
func csaf_preview() -> void:
	if bank == null:
		return
	var pts := PackedVector2Array()
	for p in ROUTE:
		pts.append(crypt.to_global(p))
	bank.trace_path(pts, SIGHT)
	if show_time >= 0.0:
		bank.seek(show_time)
	else:
		bank.csaf_preview()
	for c in get_children():
		c.process_mode = Node.PROCESS_MODE_DISABLED
