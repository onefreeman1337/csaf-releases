class_name DemoCrypt
extends Node2D
## The demo dungeon: paints "The Sunken Crypt" (Verdant 05 Depths' sample map, see crypt/NOTICE.txt) into two TileMapLayers.
## Your game uses your own map; this gives the demo something to hide. The ground layer's TileSet marks every wall tile with
## the custom data `fog_blocks = true`, which is exactly what FogBank.wall_layer reads. Top-left origin, 704 x 352 pixels.
## Copyright (c) 2026 Core Systems Asset Factory.

const TILESET := preload("res://demo/crypt/crypt_tiles.tres")
const MAP_PATH := "res://demo/crypt/crypt_map.json"
const CELL := 16

var ground: TileMapLayer
var props: TileMapLayer
var map_size := Vector2.ZERO


func _ready() -> void:
	build()


func build() -> void:
	if ground != null:
		return
	var f := FileAccess.open(MAP_PATH, FileAccess.READ)
	var data: Dictionary = JSON.parse_string(f.get_as_text())
	map_size = Vector2(int(data["cols"]) * CELL, int(data["rows"]) * CELL)
	ground = _layer("Ground", data["layers"]["ground"])
	props = _layer("Props", data["layers"]["props"])


## True if a point (this node's coordinates) is inside a wall tile.
func is_wall(p: Vector2) -> bool:
	if ground == null:
		return false
	var td := ground.get_cell_tile_data(ground.local_to_map(p))
	return td != null and bool(td.get_custom_data("fog_blocks"))


func _layer(n: String, cells: Array) -> TileMapLayer:
	var l := TileMapLayer.new()
	l.name = n
	l.tile_set = TILESET
	for e in cells:
		l.set_cell(Vector2i(int(e[0]), int(e[1])), 0, Vector2i(int(e[2]), int(e[3])))
	add_child(l)
	return l
