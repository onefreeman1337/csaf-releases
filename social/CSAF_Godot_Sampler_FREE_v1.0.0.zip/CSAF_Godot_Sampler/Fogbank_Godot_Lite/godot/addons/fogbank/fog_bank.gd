@tool
class_name FogBank
extends Node2D
## Fog of war over a 2D map. Put ONE FogBank over your level (after the map in the tree, or above it by z_index), set
## fog_rect to cover the map and give it a FogLook. Every FogRevealer in the scene clears it; walls from a TileMapLayer
## (or nodes in the "fogbank_wall" group) block sight. What the player has explored is remembered per `memory`.
##
## The visibility is a small mask (one texel per cell_size pixels) computed here on the CPU and smoothed by the shader, so a
## grid of revealed cells reads as one continuous fog. The look is a shader; nothing here draws the fog itself.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

enum Memory {
	NONE, ## Line of sight only: anything out of sight is fog again.
	DIM, ## Explored ground stays visible, re-graded by the look (the strategy-game "seen before" state).
	KEEP, ## Explored ground stays fully clear.
	FADE, ## Explored ground slowly returns to fog over forget_seconds.
}

## Emitted when the share of explored cells changes by at least 1 %.
signal explored_changed(ratio: float)

## The look. Swap it at runtime with FogbankCatalog.look("cloud_sea") or any FogLook you made.
@export var look: FogLook:
	set(v):
		if look != null and look.changed.is_connected(_apply_look):
			look.changed.disconnect(_apply_look)
		look = v
		if look != null and not look.changed.is_connected(_apply_look):
			look.changed.connect(_apply_look)
		_apply_look()
## The area the fog covers, in this node's coordinates.
@export var fog_rect := Rect2(0, 0, 640, 360):
	set(v):
		fog_rect = v
		_alloc()
## World pixels per mask cell. Smaller = finer sight edges and more CPU per frame.
@export_range(2.0, 64.0, 1.0) var cell_size := 8.0:
	set(v):
		cell_size = v
		_alloc()
@export var memory: Memory = Memory.DIM:
	set(v):
		memory = v
		_dirty = true
		if _mat != null:
			_mat.set_shader_parameter("u_memory_mode", int(memory))
## FADE: seconds for explored ground to go back to fog.
@export_range(0.5, 600.0, 0.5) var forget_seconds := 12.0
@export_group("Walls")
## Every cell of this layer whose tile has the custom data `wall_data` set to true blocks sight. If the TileSet has no such
## custom data layer, every used cell of the layer blocks sight.
@export var wall_layer: TileMapLayer:
	set(v):
		wall_layer = v
		_walls_dirty = true
@export var wall_data := "fog_blocks"
## Polygon2D, LightOccluder2D and CollisionPolygon2D nodes in this group block sight too.
@export var wall_group := "fogbank_wall"
@export_group("")
@export var revealer_group := "fogbank_revealer"
## Seconds into the look's motion that csaf_preview() shows.
@export var preview_time := 2.0

var _w := 0
var _h := 0
var _buf := PackedByteArray()
var _wall := PackedByteArray()
var _img: Image
var _tex: ImageTexture
var _mat: ShaderMaterial
var _rect: ColorRect
var _t := 0.0
var _box := Rect2i()
var _sig: Array = []
var _dirty := true
var _walls_dirty := true
var _fade_acc := 0.0
var _last_ratio := -1.0


func _ready() -> void:
	var bb := BackBufferCopy.new()
	bb.copy_mode = BackBufferCopy.COPY_MODE_VIEWPORT
	add_child(bb, false, Node.INTERNAL_MODE_FRONT)
	_mat = ShaderMaterial.new()
	_rect = ColorRect.new()
	_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_rect.material = _mat
	add_child(_rect, false, Node.INTERNAL_MODE_FRONT)
	_alloc()
	if look == null:
		look = FogLook.new()
	_apply_look()
	_update(0.0)


func _process(delta: float) -> void:
	_t += delta
	if _mat != null:
		_mat.set_shader_parameter("u_time", _t)
	_update(delta)


# ---------------------------------------------------------------- the public API

## Seeks the look's animation (cutscenes, a still for a screenshot).
func seek(t: float) -> void:
	_t = t
	if _mat != null:
		_mat.set_shader_parameter("u_time", _t)
	_update(0.0)


## Called by the CSAF capture stage: the look seeks to its showcase moment.
func csaf_preview() -> void:
	seek(preview_time)


## 0..1: how clearly a world point is in sight right now.
func visibility_at(world: Vector2) -> float:
	var c := _cell_of(world)
	return 0.0 if c < 0 else float(_buf[c * 4]) / 255.0


func is_visible_at(world: Vector2) -> bool:
	return visibility_at(world) >= 0.5


## True if a world point has been seen at some time (or is in sight now).
func is_explored_at(world: Vector2) -> bool:
	var c := _cell_of(world)
	return c >= 0 and maxi(_buf[c * 4], _buf[c * 4 + 1]) >= 128


## Share of the fog's open cells (walls excluded) explored so far, 0..1.
func explored_ratio() -> float:
	var open := 0
	var seen := 0
	for c in _w * _h:
		if _wall[c] == 1:
			continue
		open += 1
		if maxi(_buf[c * 4], _buf[c * 4 + 1]) >= 128:
			seen += 1
	return 0.0 if open == 0 else float(seen) / float(open)


## Marks a circle as explored (a map scroll, a flare, a scouting report). Walls stop it unless through_walls.
func reveal_circle(world: Vector2, radius: float, through_walls := false) -> void:
	_stamp(func(): _cast(_cellf(world), radius / cell_size, 0.0, TAU, 0.15, 1.0, through_walls))


## Marks a world rectangle as explored.
func reveal_rect(world_rect: Rect2) -> void:
	_stamp(func(): _fill_rect(world_rect, 255))


## Marks one cell of a TileMapLayer as explored (turn-based and grid games reveal whole tiles; the shader still draws one
## continuous fog over them).
func reveal_tile(layer: TileMapLayer, coords: Vector2i) -> void:
	if layer == null or layer.tile_set == null:
		return
	var ts := Vector2(layer.tile_set.tile_size) * layer.global_scale
	var centre := layer.to_global(layer.map_to_local(coords))
	reveal_rect(Rect2(centre - ts * 0.5, ts))


## Walks a path of world points as if a revealer had walked it (restoring a run, a scripted scout). With FADE memory the
## older end of the path is already fading.
func trace_path(points: PackedVector2Array, radius := 96.0, through_walls := false) -> void:
	if points.is_empty() or _w == 0:
		return
	var dense := PackedVector2Array()
	for i in points.size():
		if i == 0:
			dense.append(points[0])
			continue
		var a := points[i - 1]
		var b := points[i]
		var n := maxi(1, ceili(a.distance_to(b) / cell_size))
		for k in range(1, n + 1):
			dense.append(a.lerp(b, float(k) / float(n)))
	for i in dense.size():
		var age := 1.0 if memory != Memory.FADE else lerpf(0.3, 1.0, float(i + 1) / float(dense.size()))
		_clear_visible()
		_cast(_cellf(dense[i]), radius / cell_size, 0.0, TAU, 0.3, 1.0, through_walls)
		_commit_explored(age)
	_clear_visible()
	_dirty = true
	_update(0.0)


## Everything explored.
func reveal_all() -> void:
	for c in _w * _h:
		_buf[c * 4 + 1] = 255
	_dirty = true
	_update(0.0)


## Forget everything explored.
func reset() -> void:
	for c in _w * _h:
		_buf[c * 4] = 0
		_buf[c * 4 + 1] = 0
	_dirty = true
	_update(0.0)


## The explored memory as bytes (one per cell), for your save file.
func get_state() -> PackedByteArray:
	var out := PackedByteArray()
	out.resize(_w * _h)
	for c in _w * _h:
		out[c] = _buf[c * 4 + 1]
	return out


## Restores get_state()'s bytes. Returns false (and changes nothing) if the fog's size changed since they were saved.
func set_state(data: PackedByteArray) -> bool:
	if data.size() != _w * _h:
		push_warning("FogBank: saved state is %d cells, this fog has %d" % [data.size(), _w * _h])
		return false
	for c in _w * _h:
		_buf[c * 4 + 1] = data[c]
	_dirty = true
	_update(0.0)
	return true


## Re-reads the walls (after you change the wall layer or move a wall node).
func rebuild_walls() -> void:
	_walls_dirty = true
	_dirty = true
	_update(0.0)


## The mask texture (R visible, G explored, B wall), if you want it in a shader of your own.
func get_mask_texture() -> Texture2D:
	return _tex


# ---------------------------------------------------------------- internals

func _apply_look() -> void:
	if _mat == null or look == null:
		return
	look.apply_to(_mat)
	_bind()


func _bind() -> void:
	if _mat == null:
		return
	_mat.set_shader_parameter("u_mask", _tex)
	_mat.set_shader_parameter("u_cells", Vector2(_w, _h))
	_mat.set_shader_parameter("u_rect_size", fog_rect.size)
	_mat.set_shader_parameter("u_cell_px", cell_size)
	_mat.set_shader_parameter("u_time", _t)
	_mat.set_shader_parameter("u_memory_mode", int(memory))


func _alloc() -> void:
	if _rect == null:
		return
	_w = maxi(1, ceili(fog_rect.size.x / cell_size))
	_h = maxi(1, ceili(fog_rect.size.y / cell_size))
	_buf = PackedByteArray()
	_buf.resize(_w * _h * 4)
	for c in _w * _h:
		_buf[c * 4 + 3] = 255
	_img = Image.create_from_data(_w, _h, false, Image.FORMAT_RGBA8, _buf)
	_tex = ImageTexture.create_from_image(_img)
	_rect.position = fog_rect.position
	_rect.size = fog_rect.size
	_box = Rect2i()
	_sig = []
	_walls_dirty = true
	_dirty = true
	_bind()


func _cellf(world: Vector2) -> Vector2:
	return (to_local(world) - fog_rect.position) / cell_size


func _cell_of(world: Vector2) -> int:
	var f := _cellf(world)
	var x := floori(f.x)
	var y := floori(f.y)
	if x < 0 or y < 0 or x >= _w or y >= _h:
		return -1
	return y * _w + x


func _revealers() -> Array[FogRevealer]:
	var out: Array[FogRevealer] = []
	if not is_inside_tree():
		return out
	for n in get_tree().get_nodes_in_group(revealer_group):
		if n is FogRevealer and (n as FogRevealer).enabled and (n as FogRevealer).is_visible_in_tree():
			out.append(n as FogRevealer)
	return out


func _update(delta: float) -> void:
	if _rect == null or _w == 0:
		return
	if _walls_dirty:
		_build_walls()
	var revs := _revealers()
	var sig: Array = []
	for r in revs:
		r.track()
		sig.append([r.global_position.snapped(Vector2(0.25, 0.25)), r.get_facing().snapped(Vector2(0.01, 0.01)), r.radius, r.cone_degrees, r.near_radius, r.softness, r.strength, r.sees_through_walls])
	var changed := _dirty or sig != _sig
	if memory == Memory.FADE and delta > 0.0:
		changed = _fade(delta) or changed
	if not changed:
		return
	_clear_visible()
	for r in revs:
		var o := _cellf(r.global_position)
		var rad := r.radius / cell_size
		if r.cone_degrees >= 359.5:
			_cast(o, rad, 0.0, TAU, r.softness, r.strength, r.sees_through_walls)
		else:
			var f := r.get_facing().rotated(-global_rotation)
			var half := deg_to_rad(r.cone_degrees) * 0.5
			_cast(o, rad, f.angle() - half, half * 2.0, r.softness, r.strength, r.sees_through_walls)
			if r.near_radius > 0.0:
				_cast(o, r.near_radius / cell_size, 0.0, TAU, 0.6, r.strength, r.sees_through_walls)
	if memory != Memory.NONE:
		_commit_explored(1.0)
	_sig = sig
	_dirty = false
	_upload()


# Casts rays from a cell-space origin; writes the visible channel (R) as max().
func _cast(o: Vector2, rad: float, a0: float, span: float, soft: float, strength: float, through: bool) -> void:
	if rad <= 0.0:
		return
	var full := span >= TAU - 0.001
	var rays := clampi(ceili(span * rad * 1.7), 24, 1200)
	var edge := minf(span * 0.12, 0.2)
	var inner := 1.0 - clampf(soft, 0.0, 1.0)
	var bx0 := clampi(floori(o.x - rad) - 1, 0, _w)
	var by0 := clampi(floori(o.y - rad) - 1, 0, _h)
	var bx1 := clampi(ceili(o.x + rad) + 2, 0, _w)
	var by1 := clampi(ceili(o.y + rad) + 2, 0, _h)
	var b := Rect2i(bx0, by0, bx1 - bx0, by1 - by0)
	_box = b if _box.size == Vector2i.ZERO else _box.merge(b)
	for i in rays:
		var a := a0 + span * (float(i) + 0.5) / float(rays)
		var dx := cos(a)
		var dy := sin(a)
		var af := 1.0
		if not full and edge > 0.0:
			af = smoothstep(0.0, 1.0, minf(a - a0, a0 + span - a) / edge)
		var d := 0.0
		var last := -1
		while d <= rad:
			var x := floori(o.x + dx * d)
			var y := floori(o.y + dy * d)
			if x < 0 or y < 0 or x >= _w or y >= _h:
				break
			var c := y * _w + x
			if c != last:
				last = c
				var k := d / rad
				var v := 1.0 if k <= inner else 1.0 - smoothstep(inner, 1.0, k)
				var bv := int(v * af * strength * 255.0)
				if bv > _buf[c * 4]:
					_buf[c * 4] = bv
				if not through and _wall[c] == 1 and d > 0.75:
					break
			d += 0.55


func _clear_visible() -> void:
	if _box.size == Vector2i.ZERO:
		return
	for y in range(_box.position.y, _box.end.y):
		for x in range(_box.position.x, _box.end.x):
			_buf[(y * _w + x) * 4] = 0
	_box = Rect2i()


# Copies what is in sight into the explored channel (G = max(G, R * age)).
func _commit_explored(age: float) -> void:
	if _box.size == Vector2i.ZERO:
		return
	for y in range(_box.position.y, _box.end.y):
		for x in range(_box.position.x, _box.end.x):
			var c := (y * _w + x) * 4
			var v := int(_buf[c] * age)
			if v > _buf[c + 1]:
				_buf[c + 1] = v


func _fade(delta: float) -> bool:
	_fade_acc += delta
	if _fade_acc < 0.1:
		return false
	var dec := maxi(1, int(255.0 * _fade_acc / maxf(forget_seconds, 0.1)))
	_fade_acc = 0.0
	var any := false
	for c in _w * _h:
		var g := _buf[c * 4 + 1]
		if g > 0 and _buf[c * 4] < g:
			_buf[c * 4 + 1] = maxi(0, g - dec)
			any = true
	return any


func _stamp(cast: Callable) -> void:
	_clear_visible()
	cast.call()
	_commit_explored(1.0)
	_clear_visible()
	_dirty = true
	_update(0.0)


func _fill_rect(world_rect: Rect2, value: int) -> void:
	var a := (to_local(world_rect.position) - fog_rect.position) / cell_size
	var z := (to_local(world_rect.end) - fog_rect.position) / cell_size
	var x0 := clampi(floori(minf(a.x, z.x)), 0, _w)
	var y0 := clampi(floori(minf(a.y, z.y)), 0, _h)
	var x1 := clampi(ceili(maxf(a.x, z.x)), 0, _w)
	var y1 := clampi(ceili(maxf(a.y, z.y)), 0, _h)
	for y in range(y0, y1):
		for x in range(x0, x1):
			var c := (y * _w + x) * 4 + 1
			_buf[c] = maxi(_buf[c], value)


func _build_walls() -> void:
	_walls_dirty = false
	_wall = PackedByteArray()
	_wall.resize(_w * _h)
	if wall_layer != null and wall_layer.tile_set != null:
		var ts := wall_layer.tile_set
		var use_data := ts.get_custom_data_layer_by_name(wall_data) >= 0
		var half := Vector2(ts.tile_size) * 0.5 * wall_layer.global_scale
		for cell in wall_layer.get_used_cells():
			if use_data:
				var td := wall_layer.get_cell_tile_data(cell)
				if td == null or not bool(td.get_custom_data(wall_data)):
					continue
			var centre := wall_layer.to_global(wall_layer.map_to_local(cell))
			_mark_wall_rect(Rect2(centre - half, half * 2.0))
	if is_inside_tree() and wall_group != "":
		for n in get_tree().get_nodes_in_group(wall_group):
			var poly := PackedVector2Array()
			var xf := Transform2D.IDENTITY
			if n is Polygon2D:
				poly = (n as Polygon2D).polygon
				xf = (n as Polygon2D).global_transform
			elif n is CollisionPolygon2D:
				poly = (n as CollisionPolygon2D).polygon
				xf = (n as CollisionPolygon2D).global_transform
			elif n is LightOccluder2D and (n as LightOccluder2D).occluder != null:
				poly = (n as LightOccluder2D).occluder.polygon
				xf = (n as LightOccluder2D).global_transform
			if poly.size() >= 3:
				_mark_wall_poly(xf * poly)
	for c in _w * _h:
		_buf[c * 4 + 2] = 255 if _wall[c] == 1 else 0


func _mark_wall_rect(world_rect: Rect2) -> void:
	var a := (to_local(world_rect.position) - fog_rect.position) / cell_size
	var z := (to_local(world_rect.end) - fog_rect.position) / cell_size
	for y in range(clampi(floori(minf(a.y, z.y) + 0.5), 0, _h), clampi(floori(maxf(a.y, z.y) + 0.5), 0, _h)):
		for x in range(clampi(floori(minf(a.x, z.x) + 0.5), 0, _w), clampi(floori(maxf(a.x, z.x) + 0.5), 0, _w)):
			_wall[y * _w + x] = 1


func _mark_wall_poly(world_poly: PackedVector2Array) -> void:
	var local := PackedVector2Array()
	for p in world_poly:
		local.append((to_local(p) - fog_rect.position) / cell_size)
	var r := Rect2(local[0], Vector2.ZERO)
	for p in local:
		r = r.expand(p)
	for y in range(clampi(floori(r.position.y), 0, _h), clampi(ceili(r.end.y), 0, _h)):
		for x in range(clampi(floori(r.position.x), 0, _w), clampi(ceili(r.end.x), 0, _w)):
			if Geometry2D.is_point_in_polygon(Vector2(x + 0.5, y + 0.5), local):
				_wall[y * _w + x] = 1


func _upload() -> void:
	_img.set_data(_w, _h, false, Image.FORMAT_RGBA8, _buf)
	_tex.update(_img)
	if explored_changed.get_connections().size() > 0:
		var r := explored_ratio()
		if absf(r - _last_ratio) >= 0.01:
			_last_ratio = r
			explored_changed.emit(r)
