@tool
class_name FogLook
extends Resource
## One Fogbank look: which family shader draws it, which of that family's twelve styles, and every parameter of it.
## The 48 shipped presets are FogLook resources (addons/fogbank/looks/<family>/<id>.tres). Recolour one by changing
## its colours; every field here is a parameter, never a different preset.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

enum Family { WEATHER, PAPER, GRID, ARCANE }

const SHADERS := [
	"res://addons/fogbank/shaders/fog_weather.gdshader",
	"res://addons/fogbank/shaders/fog_paper.gdshader",
	"res://addons/fogbank/shaders/fog_grid.gdshader",
	"res://addons/fogbank/shaders/fog_arcane.gdshader",
]

@export var title := "Smoke"
@export var family: Family = Family.WEATHER:
	set(v):
		family = v
		emit_changed()
## Which of the family's twelve styles (0..11); the family shader's header lists them.
@export_range(0, 11, 1) var style := 0:
	set(v):
		style = v
		emit_changed()
## The body of the fog.
@export var fog_color := Color(0.42, 0.43, 0.46):
	set(v):
		fog_color = v
		emit_changed()
## A second colour the style uses (a glow, a rim, a grid line, a highlight, a second hue).
@export var accent_color := Color(1.0, 0.8, 0.45):
	set(v):
		accent_color = v
		emit_changed()
## The tint of ground that was explored but is not in sight now.
@export var memory_color := Color(0.45, 0.5, 0.65):
	set(v):
		memory_color = v
		emit_changed()
## How opaque the unknown is (1 = solid).
@export_range(0.0, 1.0, 0.01) var density := 1.0:
	set(v):
		density = v
		emit_changed()
## How strongly remembered ground is re-graded (0 = it looks like ground in sight).
@export_range(0.0, 1.0, 0.01) var memory_strength := 0.7:
	set(v):
		memory_strength = v
		emit_changed()
## Size of the fog's features (2 = twice as large).
@export_range(0.1, 8.0, 0.05) var scale := 1.0:
	set(v):
		scale = v
		emit_changed()
## Wind, pixels per second.
@export var drift := Vector2(6, 2):
	set(v):
		drift = v
		emit_changed()
## Animation speed multiplier (0 freezes it).
@export_range(0.0, 8.0, 0.05) var speed := 1.0:
	set(v):
		speed = v
		emit_changed()
## Width of the boundary between known and unknown (0 = hard, 1 = very soft).
@export_range(0.0, 1.0, 0.01) var edge := 0.5:
	set(v):
		edge = v
		emit_changed()
## How much the style's own texture shapes that boundary (0 = a smooth curve).
@export_range(0.0, 1.0, 0.01) var edge_noise := 0.5:
	set(v):
		edge_noise = v
		emit_changed()
## Moves the noise pattern without changing the look.
@export var noise_seed := 0:
	set(v):
		noise_seed = v
		emit_changed()


## Writes this look into a ShaderMaterial (the material's shader is set to the family's).
func apply_to(mat: ShaderMaterial) -> void:
	var sh: Shader = load(SHADERS[int(family)])
	if mat.shader != sh:
		mat.shader = sh
	mat.set_shader_parameter("u_style", style)
	mat.set_shader_parameter("u_fog", fog_color)
	mat.set_shader_parameter("u_accent", accent_color)
	mat.set_shader_parameter("u_memory", memory_color)
	mat.set_shader_parameter("u_density", density)
	mat.set_shader_parameter("u_memory_strength", memory_strength)
	mat.set_shader_parameter("u_scale", scale)
	mat.set_shader_parameter("u_drift", drift)
	mat.set_shader_parameter("u_speed", speed)
	mat.set_shader_parameter("u_edge", edge)
	mat.set_shader_parameter("u_edge_noise", edge_noise)
	mat.set_shader_parameter("u_seed", float(noise_seed % 97))
