@tool
class_name FogRevealer
extends Node2D
## Anything that SEES: add it as a child of a player, a unit, a torch or a watchtower. Every FogBank in the scene reads
## every enabled FogRevealer (they join the "fogbank_revealer" group). A radius, or a cone with an optional near circle
## (the flashlight-and-peripheral-vision look); walls block it unless sees_through_walls is on.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

const GROUP := "fogbank_revealer"

@export var enabled := true
## How far it sees, in world pixels.
@export_range(4.0, 4096.0, 1.0) var radius := 96.0:
	set(v):
		radius = v
		queue_redraw()
## 360 = all round; less = a cone that points along `facing`.
@export_range(5.0, 360.0, 1.0) var cone_degrees := 360.0:
	set(v):
		cone_degrees = v
		queue_redraw()
## A cone's direction when it is not following movement (or always, with auto_face off). Rotating this node also turns it.
@export var facing := Vector2.RIGHT
## Point the cone the way this node is moving.
@export var auto_face := true
## With a cone: a small all-round circle of sight around the eyes, world pixels (0 = none).
@export_range(0.0, 1024.0, 1.0) var near_radius := 0.0
## How gradually sight fades out towards the radius (0 = a hard edge).
@export_range(0.0, 1.0, 0.01) var softness := 0.35
## 0..1: a dim lamp reveals ground only partly.
@export_range(0.0, 1.0, 0.01) var strength := 1.0
@export var sees_through_walls := false
## Draw the radius and cone in the editor.
@export var show_gizmo := true

var _face := Vector2.RIGHT
var _last := Vector2.INF


func _enter_tree() -> void:
	add_to_group(GROUP)


func _ready() -> void:
	_face = facing.normalized() if facing.length() > 0.0 else Vector2.RIGHT


## The direction the cone points, in world space.
func get_facing() -> Vector2:
	if auto_face:
		return _face
	var f := facing.normalized() if facing.length() > 0.0 else Vector2.RIGHT
	return f.rotated(global_rotation)


## Called by FogBank once per update: follows movement when auto_face is on.
func track() -> void:
	var p := global_position
	if auto_face and _last != Vector2.INF and p.distance_to(_last) > 0.3:
		_face = _face.lerp((p - _last).normalized(), 0.3).normalized()
	elif not auto_face:
		_face = get_facing()
	_last = p


## Points the cone at once (a cutscene, a turn-based facing change).
func face(dir: Vector2) -> void:
	if dir.length() > 0.0:
		_face = dir.normalized()
		facing = _face


func _draw() -> void:
	if not Engine.is_editor_hint() or not show_gizmo:
		return
	var c := Color(1.0, 0.85, 0.4, 0.7)
	if cone_degrees >= 359.5:
		draw_arc(Vector2.ZERO, radius, 0.0, TAU, 48, c, 1.0)
	else:
		var a := facing.angle()
		var h := deg_to_rad(cone_degrees) * 0.5
		draw_arc(Vector2.ZERO, radius, a - h, a + h, 24, c, 1.0)
		draw_line(Vector2.ZERO, Vector2.from_angle(a - h) * radius, c, 1.0)
		draw_line(Vector2.ZERO, Vector2.from_angle(a + h) * radius, c, 1.0)
		if near_radius > 0.0:
			draw_arc(Vector2.ZERO, near_radius, 0.0, TAU, 24, c, 1.0)
