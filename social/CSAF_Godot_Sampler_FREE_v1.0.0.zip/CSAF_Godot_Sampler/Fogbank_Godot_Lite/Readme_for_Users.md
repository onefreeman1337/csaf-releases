# Fogbank Lite - 12 free 2D fog of war looks for Godot 4

Twelve real looks from **Fogbank - 2D Fog of War in 48 Generated Looks for Godot 4**, free under the MIT licence, with the
whole fog of war system: what the player has not seen is hidden, what they have seen is remembered, what they can see now
is clear, and walls block sight. Every look is a shader computed while the game runs.

- **Godot version:** built and tested on **Godot 4.7.2**, under **both renderers: Forward+ and Compatibility**. Older 4.x
  versions were NOT run, so they are not claimed.
- **The 12 looks:** weather `smoke`, `night_shroud`, `river_mist` · paper `parchment`, `pencil_hatch`, `blueprint` ·
  grids `square_tiles`, `pixel_dither`, `halftone` · arcane `void_tendrils`, `starfield`, `static`.

## Install

Copy `godot/addons/fogbank/` into your project's `addons/` folder. No plugin to enable. Keep the folder name: the looks
and preset scenes reference `res://addons/fogbank/` by path. To browse first, open `godot/` as a project and press Play
(WASD walk · Tab / Q / E look · M memory mode · C cone · F reveal all · R reset · G reveal the tile under the mouse).

## Use it

```gdscript
var fog := FogbankCatalog.instantiate("parchment")
fog.fog_rect = Rect2(0, 0, 1024, 768)      # the area it covers
fog.wall_layer = $Walls                    # optional: tiles with custom data fog_blocks = true block sight
add_child(fog)

var eyes := FogRevealer.new()              # anything that sees
eyes.radius = 120.0
$Player.add_child(eyes)
```

`FogBank.memory`: `NONE` (line of sight only), `DIM` (explored ground stays, re-graded; default), `KEEP` (stays clear),
`FADE` (forgets over `forget_seconds`). API: `visibility_at`, `is_visible_at`, `is_explored_at`, `explored_ratio`,
`reveal_circle`, `reveal_rect`, `reveal_tile`, `trace_path`, `reveal_all`, `reset`, `get_state` / `set_state` (saves),
`rebuild_walls`, `seek`, `get_mask_texture`. `FogRevealer`: `radius`, `cone_degrees`, `facing`, `auto_face`, `face()`,
`near_radius`, `softness`, `strength`, `sees_through_walls`, `enabled`. Every look's colours, scale, drift, speed, density,
edge and memory tint are parameters on its `FogLook`.

## The full pack

The other 36 looks (cloud sea, storm front, sandstorm, ash, toxic miasma, frost, steam, pollen, deep water, torn paper, a
burning map, ink wash, watercolour, sea chart, linen, woodcut, gilded vellum, stained glass, hex clouds, hex tiles,
handheld pixels, iso diamonds, low poly, a game board, tactical radar, masonry, mosaic, aurora, shadow realm, ice
crystals, hologram, blood mist, holy veil, ghost fire, embers and rune wards) are in the paid pack:
https://csaf.itch.io/fogbank-godot

## Licence

MIT (see LICENSE.txt), except the demo crypt's tiles, which are from a paid tileset and may not be redistributed as a
tileset. AI-generated: every shader, scene and script was written by an AI.
