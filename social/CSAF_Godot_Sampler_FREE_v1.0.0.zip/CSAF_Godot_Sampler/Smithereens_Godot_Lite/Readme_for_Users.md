# Smithereens Lite - 12 Free 2D Break Styles for Godot 4

Twelve real styles from Smithereens, free under MIT: breakables for 2D Godot 4 games that come apart the way their
material would, cut from your own sprite at runtime. Curved pot sherds and spilt grain, crate planks along the grain,
barrel staves and hoops, rock chunks, bricks in their courses, crystal facets that glint, ice slabs that skate and melt,
a pane that webs out and rains down, a bush cut to its stub, mown grass, clattering bones.

- **Godot version:** built and tested on **Godot 4.7.2**, Forward+ and Compatibility. Older 4.x versions were NOT run.
- **In the box:** 12 styles (`styles/<material>/<id>.tres`), a preview scene each, the `Breakable2D`, `SmashStyle`,
  `SmashDebris`, `SmashFracture`, `SmashCracks` and `Smithereens` classes, the sample props those styles use, a demo.

## Install

Copy `godot/addons/smithereens/` into your project's `addons/` folder. No plugin to enable. Open `godot/` as a project
and press Play to try it: click a prop to strike it, Space breaks the page, R restores, Left / Right change the page.

```gdscript
var b := Breakable2D.new()
b.style = Smithereens.style("pot_burst")
$Pot.add_child(b)                 # a Sprite2D or AnimatedSprite2D
b.hit(player.global_position)     # cracks first on multi-hit styles; the last hit breaks it
```

The styles here: `pot_burst`, `grain_spill`, `crate_planks`, `barrel_staves`, `rock_chunks`, `wall_bricks`,
`crystal_facets`, `ice_slabs`, `pane_spiderweb`, `bush_cut`, `grass_mow`, `bone_clatter`.

## The full pack

Smithereens has 48 styles in 8 materials (ceramic, wood, stone, crystal, ice, glass, foliage, and sacks, bones and
gourds): topples that break again where they land, ore that glints, glowing geode cores, resonance cracks and a
shockwave, splinter storms, ash, wine pools, melting ice, petals, spores and embers, 47 sample props.
https://csaf.itch.io/smithereens-godot

MIT licence (see `LICENSE.txt`). AI-generated, code and sample props. Copyright Core Systems Asset Factory.
