class_name SmashFracture
extends RefCounted
## The fracture maps. Every generator returns cells that PARTITION a rectangle exactly (shared edges are built
## once and used by both neighbours), so a break never loses or doubles a pixel of the sprite it cuts.
## Coordinates are sprite pixels. Seeded: the same RandomNumberGenerator state gives the same cells.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.


## Cells for a whole sprite of `size` px, struck at `impact`.
static func cells(style: SmashStyle, size: Vector2, impact: Vector2, rng: RandomNumberGenerator) -> Array[PackedVector2Array]:
	var rect := Rect2(Vector2(-1, -1), size + Vector2(2, 2))
	return cells_in(style, rect, impact, rng)


## Cells covering `rect`.
static func cells_in(style: SmashStyle, rect: Rect2, impact: Vector2, rng: RandomNumberGenerator) -> Array[PackedVector2Array]:
	var n := maxi(2, style.pieces)
	var out: Array[PackedVector2Array] = []
	match style.fracture:
		SmashStyle.Fracture.SHERDS:
			out = radial(rect, impact, n, style.curve, style.rings, style.jag, rng, false)
		SmashStyle.Fracture.SPIDERWEB:
			out = radial(rect, impact, n, 0.0, maxi(2, style.rings), style.jag * 0.35, rng, true)
		SmashStyle.Fracture.STRIPS:
			out = strips(rect, style.grain_angle, n, style.jag, style.bow, style.cross_breaks, rng)
		SmashStyle.Fracture.CHUNKS:
			out = voronoi(rect, impact, n, style.impact_bias, style.stretch, style.grain_angle, rng)
		SmashStyle.Fracture.FACETS:
			out = facets(rect, impact, n, style.impact_bias, rng)
		SmashStyle.Fracture.BRICKS:
			out = bricks(rect, n, rng)
		_:
			out = voronoi(rect, impact, n, style.impact_bias, style.stretch, style.grain_angle, rng)
	return clip_all(out, rect_poly(rect))


## Cells of one polygon (a piece breaking again when it lands, the part above a stub).
static func cells_of(style: SmashStyle, poly: PackedVector2Array, impact: Vector2, rng: RandomNumberGenerator) -> Array[PackedVector2Array]:
	var r := bounds(poly).grow(1.0)
	var cs := cells_in(style, r, impact, rng)
	return clip_all(cs, poly)


static func clip_all(cs: Array[PackedVector2Array], to: PackedVector2Array) -> Array[PackedVector2Array]:
	var out: Array[PackedVector2Array] = []
	for c in cs:
		if c.size() < 3:
			continue
		for r in Geometry2D.intersect_polygons(c, to):
			if r.size() >= 3 and absf(area(r)) > 0.35:
				out.append(r)
	return out


static func rect_poly(r: Rect2) -> PackedVector2Array:
	return PackedVector2Array([r.position, Vector2(r.end.x, r.position.y), r.end, Vector2(r.position.x, r.end.y)])


static func bounds(poly: PackedVector2Array) -> Rect2:
	var r := Rect2(poly[0], Vector2.ZERO)
	for p in poly:
		r = r.expand(p)
	return r


static func area(poly: PackedVector2Array) -> float:
	var a := 0.0
	var n := poly.size()
	for i in n:
		var p := poly[i]
		var q := poly[(i + 1) % n]
		a += p.x * q.y - q.x * p.y
	return a * 0.5


static func centroid(poly: PackedVector2Array) -> Vector2:
	var c := Vector2.ZERO
	for p in poly:
		c += p
	return c / maxf(1.0, float(poly.size()))


# ------------------------------------------------------------------ SHERDS and SPIDERWEB
static func radial(rect: Rect2, c: Vector2, pieces: int, curve: float, rings: int, jag: float, rng: RandomNumberGenerator, straight: bool) -> Array[PackedVector2Array]:
	var robj := maxf(rect.size.x, rect.size.y) * 0.5
	var rmax := 0.0
	for k in rect_poly(rect):
		rmax = maxf(rmax, c.distance_to(k))
	rmax = maxf(rmax * 1.12, 4.0)
	rings = clampi(rings, 1, 5)
	var ns := clampi(int(round(float(pieces) / float(rings))), 3, 26)
	var base := rng.randf() * TAU
	var ang := PackedFloat32Array()
	var bend := PackedFloat32Array()
	for i in ns:
		ang.append(base + (float(i) + rng.randf_range(-0.32, 0.32)) * TAU / float(ns))
		bend.append(curve * rng.randf_range(0.35, 0.8) * (1.0 if rng.randf() < 0.5 else -1.0))
	# ring radii: 0, inner rings over the object, then the outer bound
	var rad := PackedFloat32Array([0.0])
	var wob := PackedFloat32Array([0.0])
	var frq := PackedFloat32Array([0.0])
	var pha := PackedFloat32Array([0.0])
	for j in range(1, rings):
		var t := float(j) / float(rings)
		if straight:
			t = pow(t, 1.35)
		rad.append(robj * t * 1.25 * rng.randf_range(0.85, 1.12))
		wob.append(rng.randf_range(0.04, 0.16) * (0.4 if straight else 1.0))
		frq.append(float(rng.randi_range(2, 5)))
		pha.append(rng.randf() * TAU)
	rad.append(rmax)
	wob.append(0.0)
	frq.append(0.0)
	pha.append(0.0)
	var nr := rad.size()
	# P[i][j]: where spoke i meets ring j
	var P: Array[PackedVector2Array] = []
	for i in ns:
		var col := PackedVector2Array()
		for j in nr:
			col.append(_spoke_pt(c, ang[i], bend[i], _ring_r(rad[j], wob[j], frq[j], pha[j], ang[i]), robj))
		P.append(col)
	var out: Array[PackedVector2Array] = []
	for i in ns:
		var i2 := (i + 1) % ns
		var a0 := ang[i]
		var a1 := ang[i2]
		if a1 <= a0:
			a1 += TAU
		for j in nr - 1:
			var poly := PackedVector2Array()
			# inner arc on ring j from spoke i to spoke i+1 (a single point at the centre)
			if j == 0:
				poly.append(c)
			else:
				poly.append_array(_arc(c, P[i][j], P[i2][j], a0, a1, rad[j], wob[j], frq[j], pha[j], straight, jag, i * 31 + j, robj))
			# spoke i+1 outward from ring j to ring j+1
			var s2 := _spoke(c, ang[i2], bend[i2], P[i2][j], P[i2][j + 1], straight, jag, i2 * 17 + j, robj)
			_append_skip_first(poly, s2)
			# outer arc on ring j+1, backward
			var arc := _arc(c, P[i][j + 1], P[i2][j + 1], a0, a1, rad[j + 1], wob[j + 1], frq[j + 1], pha[j + 1], straight, jag, i * 31 + j + 1, robj)
			arc.reverse()
			_append_skip_first(poly, arc)
			# spoke i inward
			var s1 := _spoke(c, ang[i], bend[i], P[i][j], P[i][j + 1], straight, jag, i * 17 + j, robj)
			s1.reverse()
			_append_skip_first(poly, s1)
			if poly.size() > 1 and poly[poly.size() - 1].is_equal_approx(poly[0]):
				poly.remove_at(poly.size() - 1)
			if poly.size() >= 3:
				out.append(poly)
	return out


static func _ring_r(r: float, w: float, f: float, p: float, a: float) -> float:
	return r * (1.0 + w * sin(f * a + p))


static func _spoke_pt(c: Vector2, a: float, b: float, r: float, robj: float) -> Vector2:
	return c + Vector2.from_angle(a + b * sin(clampf(r / maxf(1.0, robj * 1.6), 0.0, 1.0) * PI)) * r


static func _spoke(c: Vector2, a: float, b: float, from: Vector2, to: Vector2, straight: bool, jag: float, key: int, robj: float) -> PackedVector2Array:
	var out := PackedVector2Array([from])
	var r0 := from.distance_to(c)
	var r1 := to.distance_to(c)
	var m := 1 if straight else 4
	for k in range(1, m):
		var t := float(k) / float(m)
		var r := lerpf(r0, r1, t)
		var p := _spoke_pt(c, a, b, r, robj)
		var nrm := Vector2.from_angle(a).orthogonal()
		var fade := clampf(r / maxf(1.0, robj * 0.35), 0.0, 1.0)
		p += nrm * jag * fade * (_h(key, k) - 0.5) * 1.6
		out.append(p)
	out.append(to)
	return out


static func _arc(c: Vector2, from: Vector2, to: Vector2, a0: float, a1: float, r: float, w: float, f: float, ph: float, straight: bool, jag: float, key: int, robj: float) -> PackedVector2Array:
	var out := PackedVector2Array([from])
	var span := a1 - a0
	var m := 1 if straight and r < robj * 4.0 else maxi(2, int(ceil(span / 0.28)))
	var fa := (from - c).angle()
	var ta := (to - c).angle()
	while ta <= fa:
		ta += TAU
	if ta - fa > TAU * 0.99:
		ta = fa + span
	for k in range(1, m):
		var t := float(k) / float(m)
		var a := lerpf(fa, ta, t)
		var rr := _ring_r(r, w, f, ph, a)
		var fade := clampf(rr / maxf(1.0, robj * 0.35), 0.0, 1.0)
		rr += jag * fade * (_h(key, k + 50) - 0.5) * 1.4
		out.append(c + Vector2.from_angle(a) * rr)
	out.append(to)
	return out


static func _h(a: int, b: int) -> float:
	var x := (a * 374761393 + b * 668265263) & 0x7fffffff
	x = ((x ^ (x >> 13)) * 1274126177) & 0x7fffffff
	return float(x % 10007) / 10007.0


static func _append_skip_first(dst: PackedVector2Array, src: PackedVector2Array) -> void:
	for k in range(1, src.size()):
		dst.append(src[k])


# ------------------------------------------------------------------ STRIPS (planks, staves, splinters, straw)
static func strips(rect: Rect2, angle_deg: float, count: int, jag: float, bow: float, breaks: int, rng: RandomNumberGenerator) -> Array[PackedVector2Array]:
	var g := Vector2.from_angle(deg_to_rad(angle_deg))
	var n := g.orthogonal()
	var umin := INF
	var umax := -INF
	var vmin := INF
	var vmax := -INF
	for p in rect_poly(rect):
		umin = minf(umin, p.dot(n))
		umax = maxf(umax, p.dot(n))
		vmin = minf(vmin, p.dot(g))
		vmax = maxf(vmax, p.dot(g))
	umin -= 1.0
	umax += 1.0
	vmin -= 1.0
	vmax += 1.0
	count = clampi(count, 2, 40)
	var sp := (umax - umin) / float(count)
	var uc := (umin + umax) * 0.5
	var S := 9
	# boundary k sampled at S points along the grain
	var B: Array[PackedVector2Array] = []
	for k in count + 1:
		var u := umin + sp * float(k)
		if k > 0 and k < count:
			u += rng.randf_range(-0.28, 0.28) * sp
		var line := PackedVector2Array()
		var sgn := signf(u - uc)
		for s in S:
			var t := float(s) / float(S - 1)
			var off := 0.0
			if k > 0 and k < count:
				off = jag * rng.randf_range(-0.5, 0.5) + bow * sp * 0.22 * sin(PI * t) * sgn
			line.append(Vector2(u + off, lerpf(vmin, vmax, t)))
		B.append(line)
	var out: Array[PackedVector2Array] = []
	for k in count:
		var cutsv := PackedFloat32Array([vmin])
		var nb := breaks
		if nb > 0 and rng.randf() < 0.25:
			nb -= 1
		for b in nb:
			cutsv.append(lerpf(vmin, vmax, rng.randf_range(0.2, 0.8)))
		cutsv.append(vmax)
		cutsv.sort()
		# break lines across strip k
		var lines: Array[PackedVector2Array] = []
		for b in cutsv.size():
			var va := cutsv[b]
			var pa := _bound_at(B[k], va)
			var pb := _bound_at(B[k + 1], va)
			var ln := PackedVector2Array([pa])
			if b > 0 and b < cutsv.size() - 1:
				var zz := rng.randi_range(2, 3)
				for z in range(1, zz):
					var t := float(z) / float(zz)
					var p := pa.lerp(pb, t)
					p.y += (jag * 1.8 + 1.0) * (1.0 if z % 2 == 0 else -1.0) * rng.randf_range(0.5, 1.0)
					ln.append(p)
			ln.append(pb)
			lines.append(ln)
		for b in cutsv.size() - 1:
			var poly := PackedVector2Array()
			poly.append_array(_bound_between(B[k], cutsv[b], cutsv[b + 1]))
			_append_skip_first(poly, lines[b + 1])
			var right := _bound_between(B[k + 1], cutsv[b], cutsv[b + 1])
			right.reverse()
			_append_skip_first(poly, right)
			var back := lines[b].duplicate()
			back.reverse()
			_append_skip_first(poly, back)
			if poly.size() > 1 and poly[poly.size() - 1].is_equal_approx(poly[0]):
				poly.remove_at(poly.size() - 1)
			# (u, v) -> pixels
			var px := PackedVector2Array()
			for q in poly:
				px.append(n * q.x + g * q.y)
			if px.size() >= 3:
				out.append(px)
	return out


static func _bound_at(line: PackedVector2Array, v: float) -> Vector2:
	for s in line.size() - 1:
		var a := line[s]
		var b := line[s + 1]
		if v >= a.y and v <= b.y:
			var t := (v - a.y) / maxf(0.0001, b.y - a.y)
			return a.lerp(b, t)
	return line[0] if v < line[0].y else line[line.size() - 1]


static func _bound_between(line: PackedVector2Array, va: float, vb: float) -> PackedVector2Array:
	var out := PackedVector2Array([_bound_at(line, va)])
	for p in line:
		if p.y > va + 0.01 and p.y < vb - 0.01:
			out.append(p)
	out.append(_bound_at(line, vb))
	return out


# ------------------------------------------------------------------ CHUNKS (Voronoi, optionally stretched along the grain)
static func voronoi(rect: Rect2, impact: Vector2, count: int, bias: float, stretch: float, angle_deg: float, rng: RandomNumberGenerator) -> Array[PackedVector2Array]:
	count = clampi(count, 2, 90)
	var seeds := PackedVector2Array()
	var dmin := sqrt(rect.get_area() / float(count)) * 0.5
	var tries := 0
	while seeds.size() < count and tries < count * 60:
		tries += 1
		var p: Vector2
		if rng.randf() < bias:
			p = impact + Vector2(rng.randfn(0.0, 1.0), rng.randfn(0.0, 1.0)) * rect.size * 0.22
			p = p.clamp(rect.position, rect.end)
		else:
			p = rect.position + Vector2(rng.randf(), rng.randf()) * rect.size
		var ok := true
		var near := dmin * (0.55 if p.distance_to(impact) < rect.size.length() * 0.25 else 1.0)
		for q in seeds:
			if q.distance_to(p) < near:
				ok = false
				break
		if ok:
			seeds.append(p)
	# work in a space where the grain is shortened, so cells come out long along it
	var rot := deg_to_rad(angle_deg)
	var k := maxf(1.0, stretch)
	var fwd := func(p: Vector2) -> Vector2:
		var r := p.rotated(-rot)
		return Vector2(r.x / k, r.y)
	var inv := func(p: Vector2) -> Vector2:
		return Vector2(p.x * k, p.y).rotated(rot)
	var box := PackedVector2Array()
	for p in rect_poly(rect):
		box.append(fwd.call(p))
	var ts := PackedVector2Array()
	for s in seeds:
		ts.append(fwd.call(s))
	var out: Array[PackedVector2Array] = []
	for i in ts.size():
		var cell := box
		for j in ts.size():
			if i == j:
				continue
			var m := (ts[i] + ts[j]) * 0.5
			var d := ts[j] - ts[i]
			cell = _half_plane(cell, m, d)
			if cell.size() < 3:
				break
		if cell.size() >= 3:
			var back := PackedVector2Array()
			for p in cell:
				back.append(inv.call(p))
			out.append(back)
	return out


## Keeps the part of a convex polygon where (x - m).d <= 0.
static func _half_plane(poly: PackedVector2Array, m: Vector2, d: Vector2) -> PackedVector2Array:
	var out := PackedVector2Array()
	var n := poly.size()
	for i in n:
		var a := poly[i]
		var b := poly[(i + 1) % n]
		var da := (a - m).dot(d)
		var db := (b - m).dot(d)
		if da <= 0.0:
			out.append(a)
		if (da < 0.0 and db > 0.0) or (da > 0.0 and db < 0.0):
			out.append(a.lerp(b, da / (da - db)))
	return out


# ------------------------------------------------------------------ FACETS (Delaunay triangles)
static func facets(rect: Rect2, impact: Vector2, count: int, bias: float, rng: RandomNumberGenerator) -> Array[PackedVector2Array]:
	var pts := PackedVector2Array(rect_poly(rect))
	var edge := maxi(2, int(round(sqrt(float(count)) * 0.9)))
	for e in range(1, edge):
		var t := (float(e) + rng.randf_range(-0.3, 0.3)) / float(edge)
		pts.append(Vector2(lerpf(rect.position.x, rect.end.x, t), rect.position.y))
		pts.append(Vector2(lerpf(rect.position.x, rect.end.x, t), rect.end.y))
		pts.append(Vector2(rect.position.x, lerpf(rect.position.y, rect.end.y, t)))
		pts.append(Vector2(rect.end.x, lerpf(rect.position.y, rect.end.y, t)))
	pts.append(impact.clamp(rect.position + Vector2.ONE, rect.end - Vector2.ONE))
	var inner := maxi(1, count / 2 - edge)
	for i in inner:
		var p: Vector2
		if rng.randf() < bias:
			p = impact + Vector2(rng.randfn(0.0, 1.0), rng.randfn(0.0, 1.0)) * rect.size * 0.2
		else:
			p = rect.position + Vector2(rng.randf_range(0.08, 0.92), rng.randf_range(0.08, 0.92)) * rect.size
		pts.append(p.clamp(rect.position + Vector2.ONE, rect.end - Vector2.ONE))
	var tri := Geometry2D.triangulate_delaunay(pts)
	var out: Array[PackedVector2Array] = []
	for t in range(0, tri.size() - 2, 3):
		var poly := PackedVector2Array([pts[tri[t]], pts[tri[t + 1]], pts[tri[t + 2]]])
		if absf(area(poly)) > 0.3:
			out.append(poly)
	return out


# ------------------------------------------------------------------ BRICKS (running bond, some bricks stay together)
static func bricks(rect: Rect2, count: int, rng: RandomNumberGenerator) -> Array[PackedVector2Array]:
	var rows := clampi(int(round(sqrt(float(count) * 0.55 * rect.size.y / maxf(1.0, rect.size.x)))), 2, 14)
	var cols := clampi(int(round(float(count) / float(rows))), 2, 14)
	var bw := rect.size.x / float(cols)
	var bh := rect.size.y / float(rows)
	var out: Array[PackedVector2Array] = []
	for r in rows:
		var y0 := rect.position.y + bh * float(r)
		var off := bw * 0.5 if r % 2 == 1 else 0.0
		var xs := PackedFloat32Array([rect.position.x])
		var x := rect.position.x + bw - off
		if off > 0.0:
			x = rect.position.x + off
		while x < rect.end.x - 0.5:
			xs.append(x)
			x += bw
		xs.append(rect.end.x)
		var k := 0
		while k < xs.size() - 1:
			var span := 1
			if k + 2 < xs.size() and rng.randf() < 0.35:
				span = 2
			out.append(rect_poly(Rect2(xs[k], y0, xs[k + span] - xs[k], bh)))
			k += span
	return out


# ------------------------------------------------------------------ SPLIT (long jagged cuts: halves, tears)


## A jagged polyline through q along dir, long enough to cross anything of size span.
static func jagged_line(q: Vector2, dirv: Vector2, span: float, jag: float, rng: RandomNumberGenerator) -> PackedVector2Array:
	var nrm := dirv.orthogonal()
	var line := PackedVector2Array([q - dirv * span])
	var steps := maxi(2, int(span / 3.0))
	for s in range(1, steps):
		var t := float(s) / float(steps)
		line.append(q + dirv * lerpf(-span * 0.5, span * 0.5, t) + nrm * jag * rng.randf_range(-1.0, 1.0))
	line.append(q + dirv * span)
	return line


## Both sides of a polygon cut by a polyline; side = the normal pointing at the second half.
static func cut_polygon(p: PackedVector2Array, line: PackedVector2Array, side: Vector2, span: float) -> Array[PackedVector2Array]:
	var half := line.duplicate()
	half.append(line[line.size() - 1] + side * span * 2.0)
	half.append(line[0] + side * span * 2.0)
	if Geometry2D.is_polygon_clockwise(half):
		half.reverse()
	var out: Array[PackedVector2Array] = []
	for r in Geometry2D.intersect_polygons(p, half):
		if r.size() >= 3 and absf(area(r)) > 0.35:
			out.append(r)
	for r in Geometry2D.clip_polygons(p, half):
		if r.size() >= 3 and absf(area(r)) > 0.35:
			out.append(r)
	return out


## The two parts of a polygon either side of a cut: [below, above] (each an Array of polygons).
static func cut_pair(p: PackedVector2Array, line: PackedVector2Array, span: float) -> Array:
	var below := line.duplicate()
	below.append(line[line.size() - 1] + Vector2(0, span * 2.0))
	below.append(line[0] + Vector2(0, span * 2.0))
	if Geometry2D.is_polygon_clockwise(below):
		below.reverse()
	var lo: Array[PackedVector2Array] = []
	var hi: Array[PackedVector2Array] = []
	for r in Geometry2D.intersect_polygons(p, below):
		if r.size() >= 3 and absf(area(r)) > 0.35:
			lo.append(r)
	for r in Geometry2D.clip_polygons(p, below):
		if r.size() >= 3 and absf(area(r)) > 0.35:
			hi.append(r)
	return [lo, hi]
