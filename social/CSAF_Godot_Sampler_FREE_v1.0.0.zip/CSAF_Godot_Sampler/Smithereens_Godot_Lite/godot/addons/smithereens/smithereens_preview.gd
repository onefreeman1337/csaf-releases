extends Node2D
## A style's preview scene: one of the pack's sample props, struck from the left and broken by the style, again and
## again (run the scene to watch it). csaf_preview() photographs one exact moment of the break instead.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

@export var style: SmashStyle
@export var prop: Texture2D
@export var prop_scale := 3.0
@export var view: Breakable2D.View = Breakable2D.View.SIDE
## Seconds after the break that csaf_preview() shows.
@export var preview_time := 0.24
## The prop's base line, in this scene's pixels.
@export var base_y := 76.0

var sprite: Sprite2D
var breakable: Breakable2D
var _t := 0.0
var _debris: Array[SmashDebris] = []
var _frozen := false


func _ready() -> void:
	_spawn()


func _spawn() -> void:
	if prop == null or style == null:
		return
	sprite = Sprite2D.new()
	sprite.texture = prop
	sprite.scale = Vector2.ONE * prop_scale
	sprite.position = Vector2(0.0, base_y - float(prop.get_height()) * prop_scale * 0.5)
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	add_child(sprite)
	breakable = Breakable2D.new()
	breakable.style = style
	breakable.view = view
	breakable.on_break = Breakable2D.OnBreak.HIDE
	breakable.fracture_seed = absi(hash(style.resource_path)) % 100000 + 1
	sprite.add_child(breakable)
	breakable.broken.connect(func(d: SmashDebris) -> void: _debris.append(d))


## Where the blow comes from: the left, a little above the middle.
func striker() -> Vector2:
	return sprite.global_position + Vector2(-60.0 * prop_scale, -4.0 * prop_scale)


func csaf_preview() -> void:
	_frozen = true
	set_process(false)
	if breakable == null:
		return
	var need := breakable.hits_needed()
	if need > 1:
		breakable.crack_to(need - 1, striker())
	var d := breakable.smash(striker())
	if d:
		d.advance(preview_time)
		d.set_process(false)
		d.queue_redraw()


## The cracked stage before the last blow (for stills of multi-hit styles).
func csaf_cracked() -> void:
	_frozen = true
	set_process(false)
	if breakable:
		breakable.crack_to(breakable.hits_needed() - 1, striker())


func _process(delta: float) -> void:
	if _frozen or breakable == null:
		return
	_t += delta
	var need := breakable.hits_needed()
	var hit_at := 0.7 + 0.42 * float(breakable.hits_taken)
	if not breakable.is_broken() and _t >= hit_at:
		breakable.hit(striker())
	elif breakable.is_broken() and _t > 0.7 + 0.42 * float(need) + 2.6:
		for d in _debris:
			if is_instance_valid(d):
				d.queue_free()
		_debris.clear()
		breakable.restore()
		_t = 0.0
