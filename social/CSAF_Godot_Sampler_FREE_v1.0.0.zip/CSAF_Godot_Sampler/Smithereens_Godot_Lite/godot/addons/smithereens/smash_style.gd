@tool
class_name SmashStyle
extends Resource
## How one breakable comes apart: the fracture it is cut by, how the pieces move, what is left on the ground,
## and the cracks each hit draws before the last one breaks it. A recolour or a stronger blow is a parameter
## here, never a new style. All distances are authored for a 48 px tall object and scale with the sprite.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

## SHERDS: curved shards round the blow (pottery). STRIPS: long pieces along the grain (planks, staves, straw).
## CHUNKS: angular cells (stone, clumps; stretch makes kindling). FACETS: triangles (crystal, glass).
## SPIDERWEB: spokes and rings (panes, ice). BRICKS: running bond. SPLIT: a few long jagged cuts (halves).
enum Fracture { SHERDS, STRIPS, CHUNKS, FACETS, SPIDERWEB, BRICKS, SPLIT }
## STUB: the part below the cut stays rooted (bushes, grass). TOPPLE: the part above falls whole and can break on landing.
enum Cut { NONE, STUB, TOPPLE }
enum Spin { FREE, QUARTER, NONE }
enum Bits { NONE, LEAVES, PETALS, SPLINTERS, STRAW, SPORES, SPARKS, CHIPS, SNOW, SEEDS, DROPLETS, HOOPS, GLITTER, EMBERS }
enum Spill { NONE, GRAIN, LIQUID, ASH, PUDDLE }
enum Crack { NONE, HAIRLINE, GRAIN, JAGGED, FACET, SPIDERWEB }

@export var material_name := "ceramic"

@export_group("Fracture")
@export var fracture: Fracture = Fracture.SHERDS
## Roughly how many pieces (each fracture interprets it: SHERDS = spokes x rings, STRIPS = strips).
@export_range(2, 80) var pieces := 10
## SHERDS: how far the cuts bend into arcs. 0 = straight.
@export_range(0.0, 1.0) var curve := 0.5
## SHERDS / SPIDERWEB: rings of cuts round the blow.
@export_range(1, 5) var rings := 2
## STRIPS / SPLIT / CHUNKS stretch: the grain direction in degrees (90 = vertical).
@export_range(-180.0, 180.0) var grain_angle := 90.0
## How ragged a cut edge is, in sprite pixels.
@export_range(0.0, 4.0) var jag := 1.0
## STRIPS: how far staves bow outward.
@export_range(0.0, 3.0) var bow := 0.0
## STRIPS: breaks across each strip.
@export_range(0, 4) var cross_breaks := 1
## CHUNKS: elongate cells along grain_angle (kindling, bone).
@export_range(1.0, 4.0) var stretch := 1.0
## CHUNKS / FACETS: smaller pieces near the blow.
@export_range(0.0, 1.0) var impact_bias := 0.4
## SPLIT: how many long cuts.
@export_range(1, 4) var cuts := 1
@export var cut: Cut = Cut.NONE
## STUB / TOPPLE: where the cut is, as a fraction of the height measured from the base.
@export_range(0.05, 0.95) var cut_height := 0.3
@export_range(-60.0, 60.0) var cut_angle := 0.0
## TOPPLE: the falling part breaks by `fracture` when it lands.
@export var land_break := true

@export_group("Motion")
## Outward speed (px/s for a 48 px object).
@export var burst := 90.0
## Upward speed at the break.
@export var lift := 80.0
@export var gravity := 420.0
@export_range(0.0, 0.9) var bounce := 0.3
## Ground friction: how quickly a landed piece stops sliding (ice is low).
@export var friction := 6.0
## Spin in radians per second (small pieces spin faster).
@export var spin := 6.0
@export var spin_mode: Spin = Spin.FREE
## The cone, in degrees, round the direction away from the striker.
@export_range(0.0, 360.0) var spread := 200.0
## 0 bursts outward, 1 drops where it stood (rubble, crumbling).
@export_range(0.0, 1.0) var collapse := 0.0
## Air drag (cloth, leaves, paper).
@export var drag := 0.0
## Side to side sway while falling.
@export var flutter := 0.0
## Pieces shrink away over their life (ice).
@export_range(0.0, 1.0) var melt := 0.0

@export_group("Debris")
## Seconds the debris stays after the break; 0 keeps it.
@export var debris_seconds := 6.0
@export var fade_seconds := 1.2
## Landed pieces darken a little, so debris reads as debris.
@export_range(0.0, 1.0) var settle_darken := 0.15
@export var shadows := true
## Pieces near the blow glow and fade (geodes, cores).
@export_range(0.0, 2.0) var inner_glow := 0.0
## Multiplies the pieces.
@export var tint := Color(1, 1, 1, 1)

@export_group("Extras")
@export_range(0, 40) var dust := 6
## Alpha 0 = mixed from the sprite's own colours.
@export var dust_color := Color(0, 0, 0, 0)
@export_range(0.2, 3.0) var dust_size := 1.0
@export var bits: Bits = Bits.NONE
@export_range(0, 120) var bits_amount := 0
## Alpha 0 = sampled from the sprite.
@export var bits_color := Color(0, 0, 0, 0)
@export var spill: Spill = Spill.NONE
@export var spill_color := Color(0, 0, 0, 0)
@export_range(0.2, 3.0) var spill_size := 1.0
@export_range(0, 20) var glints := 0
@export var glint_color := Color(1, 1, 1, 1)
@export var shockwave := false
## A white flash on the pieces at the break.
@export_range(0.0, 1.0) var flash := 0.5

@export_group("Hits")
## Hits it takes; every hit before the last draws the next crack stage.
@export_range(1, 8) var hits := 1
@export var crack: Crack = Crack.HAIRLINE
## Alpha 0 = a deep shade of the sprite under each crack pixel.
@export var crack_color := Color(0, 0, 0, 0)
## Cracks drawn bright instead of dark (crystal resonance).
@export var crack_glow := false
@export_range(0, 12) var chips_per_hit := 3
## Pixels the sprite jolts on a hit.
@export var shake := 1.5
