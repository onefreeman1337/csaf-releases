class_name SmashDebris
extends Node2D
## What a break leaves: the pieces cut from the sprite (each textured with the sprite's own pixels), their flight,
## bounce and slide, the dust, glints, bits, spills and puddles, and the debris that stays on the ground.
## Coordinates are the broken sprite's local pixels; the node takes the sprite's transform, so it y-sorts and
## scales with the world. One node per break, freed when its debris fades (or kept, if debris_seconds is 0).
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

signal finished

## Every live SmashDebris, oldest first: when the pieces on screen pass max_pieces_total the oldest settled
## debris fades early, so a room of breakables can never grow without bound.
static var live: Array[SmashDebris] = []
static var max_pieces_total := 1600

class Piece:
	var pts := PackedVector2Array()
	var uvs := PackedVector2Array()
	var tris := PackedInt32Array()
	var src := PackedVector2Array()
	var c := Vector2.ZERO
	var g := Vector2.ZERO
	var h := 0.0
	var vel := Vector2.ZERO
	var vh := 0.0
	var rot := 0.0
	var vrot := 0.0
	var rest := 0.0
	var radius := 1.0
	var area := 0.0
	var fixed := false
	var land_break := false
	var landed := false
	var settled := false
	var glow := 0.0
	var age := 0.0
	var phase := 0.0

class Mote:
	var kind := 0
	var p := Vector2.ZERO
	var h := 0.0
	var vel := Vector2.ZERO
	var vh := 0.0
	var rot := 0.0
	var vrot := 0.0
	var size := 1.0
	var col := Color.WHITE
	var life := 1.0
	var age := 0.0
	var delay := 0.0
	var phase := 0.0
	var follow := -1
	var grounded := false

const DUST := 100
const GLINT := 101
const RING := 102

var style: SmashStyle
var k := 1.0
var depth := 0.25
var base_y := 0.0
var pieces: Array[Piece] = []
var motes: Array[Mote] = []
var time := 0.0
var tex: ImageTexture
var tex_size := Vector2.ONE
var pad := 2.0
var rng := RandomNumberGenerator.new()
var palette := PackedColorArray()
var vivid := PackedColorArray()
var mean := Color(0.5, 0.5, 0.5)
var spill_at := Vector2.ZERO
var spill_shape := PackedVector2Array()
var spill_dots := PackedVector3Array()
var spill_cols := PackedColorArray()
var _glow: Node2D
var _sleeping := false
var _retiring := false
var _fade := 1.0
var _order: Array[Piece] = []
var _tdata := PackedByteArray()
var _rect_pos := Vector2.ZERO
## Bits start at the blow instead of across the object (the chips of a hit).
var bits_at_impact := false


func _init() -> void:
	_glow = Node2D.new()
	var m := CanvasItemMaterial.new()
	m.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	_glow.material = m
	_glow.draw.connect(_draw_glow)
	add_child(_glow)


func _enter_tree() -> void:
	if not live.has(self):
		live.append(self)


func _exit_tree() -> void:
	live.erase(self)


## Sets the debris up from one frame of a sprite. img = the frame (cracks already baked in), rect = where that frame
## is drawn in the sprite's local space, cells = the fracture (frame pixels), impact (frame pixels), push = away
## from the striker, view_depth = 0.25 side view, 0.9 top down.
func setup(p_style: SmashStyle, img: Image, rect: Rect2, cells: Array[PackedVector2Array], impact: Vector2, push: Vector2, view_depth: float, seed_value: int) -> void:
	style = p_style
	rng.seed = seed_value
	depth = view_depth
	k = clampf(rect.size.y / 48.0, 0.2, 6.0)
	var data := img.get_data()
	var w := img.get_width()
	var hh := img.get_height()
	# palette + the base line (the lowest opaque row)
	var bottom := 0
	var top := hh
	var sum := Vector3.ZERO
	var count := 0
	for y in hh:
		for x in w:
			var i := (y * w + x) * 4
			if data[i + 3] > 127:
				bottom = maxi(bottom, y)
				top = mini(top, y)
				var col := Color8(data[i], data[i + 1], data[i + 2])
				sum += Vector3(col.r, col.g, col.b)
				count += 1
				if (x * 7 + y * 13) % 5 == 0:
					palette.append(col)
					if col.s > 0.35 and col.v > 0.35:
						vivid.append(col)
	if count == 0:
		return
	mean = Color(sum.x / count, sum.y / count, sum.z / count)
	if palette.is_empty():
		palette.append(mean)
	if vivid.is_empty():
		vivid = palette
	base_y = rect.position.y + float(bottom) + 1.0
	# the texture: the frame with a transparent border so no UV ever clamps onto an edge pixel
	var padded := Image.create(w + int(pad) * 2, hh + int(pad) * 2, false, Image.FORMAT_RGBA8)
	padded.fill(Color(0, 0, 0, 0))
	padded.blit_rect(img, Rect2i(0, 0, w, hh), Vector2i(int(pad), int(pad)))
	tex = ImageTexture.create_from_image(padded)
	tex_size = Vector2(padded.get_size())
	_tdata = padded.get_data()
	_rect_pos = rect.position
	var push_n := push.normalized() if push.length() > 0.01 else Vector2.RIGHT
	var imp_local := rect.position + impact
	var static_cells: Array[PackedVector2Array] = []
	var moving: Array[PackedVector2Array] = cells
	var topple: Array[PackedVector2Array] = []
	if style.cut != SmashStyle.Cut.NONE:
		var y_cut := float(bottom) + 1.0 - style.cut_height * float(bottom + 1 - top)
		var line := SmashFracture.jagged_line(Vector2(w * 0.5, y_cut), Vector2.from_angle(deg_to_rad(style.cut_angle)), float(maxi(w, hh)) * 2.0, style.jag * 0.8 + 0.4, rng)
		var whole := SmashFracture.rect_poly(Rect2(-1, -1, w + 2, hh + 2))
		var pair := SmashFracture.cut_pair(whole, line, float(maxi(w, hh)) * 2.0)
		static_cells = pair[0]
		var above: Array[PackedVector2Array] = pair[1]
		moving = []
		if style.cut == SmashStyle.Cut.TOPPLE:
			pass
		if topple.is_empty():
			for poly in above:
				moving.append_array(SmashFracture.cells_of(style, poly, impact, rng))
	for poly in static_cells:
		var p := _make_piece(poly, rect)
		if p:
			p.fixed = true
			p.settled = true
			p.g = Vector2(p.c.x, base_y)
			p.h = base_y - p.c.y
			pieces.append(p)
	for poly in moving:
		var p := _make_piece(poly, rect)
		if p:
			_launch(p, imp_local, push_n, 1.0)
			pieces.append(p)
	for poly in topple:
		var p := _make_piece(poly, rect)
		if p:
			p.g = Vector2(p.c.x, base_y)
			p.h = base_y - p.c.y
			p.vel = Vector2(push_n.x * style.burst * 0.45, rng.randf_range(-0.2, 0.2) * style.burst * depth) * k
			p.vh = style.lift * 0.55 * k
			p.vrot = signf(push_n.x if absf(push_n.x) > 0.1 else 1.0) * style.spin * 0.35
			p.land_break = style.land_break
			p.rest = minf(p.rest, p.h)
			pieces.append(p)
	# inner glow: the pieces nearest the blow
	_spawn_extras(rect, imp_local, push_n)
	_order = pieces.duplicate()
	_enforce_budget()


func _make_piece(poly: PackedVector2Array, rect: Rect2) -> Piece:
	if poly.size() < 3:
		return null
	var area := absf(SmashFracture.area(poly))
	if area < 0.6:
		return null
	# the centroid of what is actually painted inside the cell (a cell may reach past the art)
	var b := SmashFracture.bounds(poly)
	var data := _tdata
	var tw := int(tex_size.x)
	var sum := Vector2.ZERO
	var n := 0
	var stepi := 1 if b.get_area() < 3000.0 else 2
	var y := int(floor(b.position.y))
	while y <= int(ceil(b.end.y)):
		var x := int(floor(b.position.x))
		while x <= int(ceil(b.end.x)):
			var tx := x + int(pad)
			var ty := y + int(pad)
			if tx >= 0 and ty >= 0 and tx < tw and ty < int(tex_size.y) and data[(ty * tw + tx) * 4 + 3] > 127:
				if Geometry2D.is_point_in_polygon(Vector2(x + 0.5, y + 0.5), poly):
					sum += Vector2(x + 0.5, y + 0.5)
					n += 1
			x += stepi
		y += stepi
	if n == 0:
		return null
	var p := Piece.new()
	var cf := sum / float(n)
	p.src = poly
	p.c = rect.position + cf
	p.area = float(n * stepi * stepi)
	p.radius = sqrt(p.area / PI)
	for q in poly:
		p.pts.append(q - cf)
		p.uvs.append((q + Vector2(pad, pad)) / tex_size)
	p.tris = Geometry2D.triangulate_polygon(poly)
	if p.tris.size() < 3:
		var hull := Geometry2D.convex_hull(poly)
		p.pts.clear()
		p.uvs.clear()
		for i in hull.size() - 1:
			p.pts.append(hull[i] - cf)
			p.uvs.append((hull[i] + Vector2(pad, pad)) / tex_size)
		p.tris = Geometry2D.triangulate_polygon(hull.slice(0, hull.size() - 1))
		if p.tris.size() < 3:
			return null
	var lo := Vector2(INF, INF)
	var hi := -lo
	for q in p.pts:
		lo = lo.min(q)
		hi = hi.max(q)
	p.rest = minf(hi.x - lo.x, hi.y - lo.y) * 0.4
	p.phase = rng.randf() * TAU
	return p


func _launch(p: Piece, imp: Vector2, push: Vector2, power: float) -> void:
	var out := p.c - imp
	out = out.normalized() if out.length() > 0.5 else Vector2.from_angle(rng.randf() * TAU)
	var a := push.angle() + deg_to_rad(rng.randf_range(-style.spread, style.spread) * 0.5)
	var d := Vector2.from_angle(a).lerp(out, 0.55).normalized()
	var sp := style.burst * k * rng.randf_range(0.55, 1.25) * (1.0 - style.collapse * 0.85) * power
	p.g = Vector2(p.c.x, base_y)
	p.h = base_y - p.c.y
	p.rest = minf(p.rest, maxf(0.0, p.h))
	p.vel = Vector2(d.x * sp, rng.randf_range(-1.0, 1.0) * sp * depth)
	p.vh = (style.lift * k * rng.randf_range(0.45, 1.15) * (1.0 - style.collapse) + maxf(0.0, -d.y) * sp * 0.6) * power
	if style.collapse > 0.0:
		p.vh -= style.collapse * 20.0 * k
	var small := clampf(14.0 / (p.radius + 4.0), 0.4, 2.5)
	p.vrot = rng.randf_range(-1.0, 1.0) * style.spin * small


func _sample(vivid_first: bool) -> Color:
	var src := vivid if vivid_first and not vivid.is_empty() else palette
	return src[rng.randi() % src.size()]


func _spawn_extras(rect: Rect2, imp: Vector2, push: Vector2) -> void:
	var dc := style.dust_color if style.dust_color.a > 0.0 else Color(mean.lerp(Color(0.86, 0.83, 0.78), 0.5), 0.55)
	for i in style.dust:
		var m := Mote.new()
		m.kind = DUST
		m.p = Vector2(lerpf(rect.position.x + rect.size.x * 0.15, rect.end.x - rect.size.x * 0.15, rng.randf()), lerpf(base_y - rect.size.y * 0.55, base_y - 2.0, rng.randf()))
		m.p = m.p.lerp(imp, 0.25)
		m.vel = Vector2(rng.randf_range(-1.0, 1.0) * 30.0 + push.x * 14.0, rng.randf_range(-22.0, -6.0)) * k
		m.size = rng.randf_range(2.2, 4.2) * style.dust_size * k
		m.life = rng.randf_range(0.5, 0.95)
		m.delay = rng.randf_range(0.0, 0.08)
		m.col = dc
		motes.append(m)
	if style.bits != SmashStyle.Bits.NONE:
		for i in style.bits_amount:
			motes.append(_bit(style.bits, imp, push, rect))
	for i in style.glints:
		if pieces.is_empty():
			break
		var m := Mote.new()
		m.kind = GLINT
		m.follow = rng.randi() % pieces.size()
		m.delay = rng.randf_range(0.0, 0.45)
		m.life = rng.randf_range(0.22, 0.4)
		m.size = rng.randf_range(2.5, 4.5) * k
		m.col = style.glint_color
		m.phase = rng.randf() * PI
		motes.append(m)
	if style.spill != SmashStyle.Spill.NONE:
		_make_spill(rect)


func _bit(kind: int, imp: Vector2, push: Vector2, rect: Rect2) -> Mote:
	var m := Mote.new()
	m.kind = kind
	var start := Vector2(lerpf(rect.position.x + rect.size.x * 0.2, rect.end.x - rect.size.x * 0.2, rng.randf()), lerpf(base_y - rect.size.y * 0.8, base_y - 2.0, rng.randf()))
	if bits_at_impact:
		start = imp + Vector2(rng.randf_range(-2.0, 2.0), rng.randf_range(-2.0, 2.0)) * k
	m.p = Vector2(start.x, base_y)
	m.h = base_y - start.y
	var a := push.angle() + deg_to_rad(rng.randf_range(-style.spread, style.spread) * 0.5)
	var sp := style.burst * k * rng.randf_range(0.4, 1.3)
	m.vel = Vector2(cos(a) * sp, rng.randf_range(-1.0, 1.0) * sp * depth)
	m.vh = style.lift * k * rng.randf_range(0.6, 1.5)
	m.rot = rng.randf() * TAU
	m.vrot = rng.randf_range(-8.0, 8.0)
	m.size = rng.randf_range(1.6, 3.0) * k
	m.life = rng.randf_range(1.2, 2.4)
	m.phase = rng.randf() * TAU
	m.col = style.bits_color if style.bits_color.a > 0.0 else _sample(kind == SmashStyle.Bits.PETALS or kind == SmashStyle.Bits.LEAVES)
	match kind:
		SmashStyle.Bits.SPORES, SmashStyle.Bits.EMBERS:
			m.vh = rng.randf_range(10.0, 40.0) * k
			m.vel *= 0.3
			m.size = rng.randf_range(0.8, 1.6) * k
			m.life = rng.randf_range(1.0, 2.0)
		SmashStyle.Bits.SPARKS:
			m.vel *= 2.2
			m.vh *= 1.4
			m.life = rng.randf_range(0.25, 0.5)
			m.size = rng.randf_range(0.6, 1.1) * k
		SmashStyle.Bits.HOOPS:
			m.size = rect.size.x * 0.34
			m.vel *= 0.35
			m.vh *= 0.5
			m.h = base_y - lerpf(rect.position.y + rect.size.y * 0.25, rect.position.y + rect.size.y * 0.8, rng.randf())
			m.life = 99.0
		SmashStyle.Bits.GLITTER:
			m.size = rng.randf_range(1.0, 1.8) * k
			m.life = rng.randf_range(0.8, 1.6)
		SmashStyle.Bits.DROPLETS:
			m.size = rng.randf_range(0.9, 1.6) * k
			m.vel *= 1.3
			m.life = 3.0
		SmashStyle.Bits.STRAW, SmashStyle.Bits.SPLINTERS:
			m.size = rng.randf_range(2.0, 3.6) * k
	return m


func _make_spill(rect: Rect2) -> void:
	spill_at = Vector2(rect.get_center().x, base_y)
	var r := rect.size.x * 0.55 * style.spill_size
	match style.spill:
		SmashStyle.Spill.GRAIN, SmashStyle.Spill.ASH:
			var base := style.spill_color if style.spill_color.a > 0.0 else mean
			for i in int(70.0 * style.spill_size):
				var a := rng.randf() * TAU
				var d := sqrt(rng.randf())
				spill_dots.append(Vector3(cos(a) * d * r, sin(a) * d * r * (0.3 + depth * 0.4), d))
				var cc := base.darkened(rng.randf_range(0.0, 0.35)) if rng.randf() < 0.6 else base.lightened(rng.randf_range(0.05, 0.3))
				spill_cols.append(cc)
		SmashStyle.Spill.LIQUID, SmashStyle.Spill.PUDDLE:
			var n := 20
			for i in n:
				var a2 := TAU * float(i) / float(n)
				var rr := r * rng.randf_range(0.7, 1.1)
				spill_shape.append(Vector2(cos(a2) * rr, sin(a2) * rr * (0.24 + depth * 0.14)))


func _process(delta: float) -> void:
	step(minf(delta, 1.0 / 20.0))


## Advances the simulation by `seconds` in fixed steps (a deterministic photograph: no frame clock involved).
func advance(seconds: float) -> void:
	var t := 0.0
	while t < seconds - 0.0001:
		step(1.0 / 60.0)
		t += 1.0 / 60.0


func step(dt: float) -> void:
	time += dt
	var busy := false
	var grav := style.gravity * k
	var new_pieces: Array[Piece] = []
	for p in pieces:
		if p.fixed or p.settled:
			continue
		busy = true
		p.age += dt
		p.vh -= grav * dt
		if style.drag > 0.0:
			var dr := exp(-style.drag * dt)
			p.vel *= dr
			p.vh = maxf(p.vh, -grav / (style.drag * 2.0 + 0.6))
		if style.flutter > 0.0 and p.h > p.rest + 1.0:
			p.vel.x += sin(p.age * 7.0 + p.phase) * style.flutter * k * dt * 30.0
		p.h += p.vh * dt
		p.g += p.vel * dt
		p.rot += p.vrot * dt
		if p.h <= p.rest:
			p.h = p.rest
			if not p.landed:
				p.landed = true
				if p.land_break:
					new_pieces.append_array(_shatter_on_land(p))
					continue
				if p.area > 60.0 * k * k and absf(p.vh) > 60.0 * k and style.dust > 0:
					_land_puff(p)
			if p.vh < -35.0 * k and style.bounce > 0.0:
				p.vh = -p.vh * style.bounce
				p.vrot *= 0.55
				p.vel *= 0.72
			else:
				p.vh = 0.0
			p.vel *= exp(-style.friction * dt)
			p.vrot *= exp(-style.friction * 1.6 * dt)
			if p.vh == 0.0 and p.vel.length() < 2.5 * k:
				p.settled = true
				p.vel = Vector2.ZERO
				if style.spin_mode == SmashStyle.Spin.QUARTER:
					p.rot = snappedf(p.rot, PI * 0.5)
	if not new_pieces.is_empty():
		var keep: Array[Piece] = []
		for p in pieces:
			if p.area >= 0.0:
				keep.append(p)
		keep.append_array(new_pieces)
		pieces = keep
		_order = pieces.duplicate()
	for m in motes:
		if m.delay > 0.0:
			m.delay -= dt
			busy = true
			continue
		if m.age >= m.life:
			continue
		busy = true
		m.age += dt
		_step_mote(m, dt, grav)
	if style.melt > 0.0 or style.spill != SmashStyle.Spill.NONE or style.inner_glow > 0.0:
		busy = busy or time < 3.0
	# lifetime
	if style.debris_seconds > 0.0 and time > style.debris_seconds:
		_fade = clampf(1.0 - (time - style.debris_seconds) / maxf(0.05, style.fade_seconds), 0.0, 1.0)
		busy = true
		if _fade <= 0.0:
			finished.emit()
			queue_free()
			return
	if busy:
		_order.sort_custom(func(a: Piece, b: Piece) -> bool: return a.g.y < b.g.y if not is_equal_approx(a.g.y, b.g.y) else a.c.y < b.c.y)
		queue_redraw()
		_glow.queue_redraw()
	elif not _sleeping:
		_sleeping = true
		queue_redraw()
		_glow.queue_redraw()
		set_process(false)


func _step_mote(m: Mote, dt: float, grav: float) -> void:
	match m.kind:
		DUST:
			m.p += m.vel * dt
			m.vel *= exp(-2.5 * dt)
		GLINT, RING:
			pass
		SmashStyle.Bits.SPORES, SmashStyle.Bits.EMBERS:
			m.h += m.vh * dt
			m.p.x += sin(m.age * 3.0 + m.phase) * 6.0 * k * dt + m.vel.x * dt
			m.vh *= exp(-0.6 * dt)
		_:
			if m.grounded:
				return
			var light := m.kind == SmashStyle.Bits.LEAVES or m.kind == SmashStyle.Bits.PETALS or m.kind == SmashStyle.Bits.STRAW or m.kind == SmashStyle.Bits.SNOW or m.kind == SmashStyle.Bits.GLITTER
			m.vh -= grav * dt * (0.35 if light else 1.0)
			if light:
				m.vh = maxf(m.vh, -32.0 * k)
				m.vel *= exp(-1.8 * dt)
				m.p.x += sin(m.age * 6.0 + m.phase) * 14.0 * k * dt
			m.h += m.vh * dt
			m.p += m.vel * dt
			m.rot += m.vrot * dt * (0.5 if light else 1.0)
			if m.h <= 0.0:
				m.h = 0.0
				if m.kind == SmashStyle.Bits.HOOPS and m.vh < -40.0 * k:
					m.vh = -m.vh * 0.35
				else:
					m.grounded = true
					m.vel = Vector2.ZERO
					if m.kind == SmashStyle.Bits.DROPLETS or m.kind == SmashStyle.Bits.SPARKS:
						m.age = m.life


func _land_puff(p: Piece) -> void:
	for i in 3:
		var m := Mote.new()
		m.kind = DUST
		m.p = Vector2(p.g.x + rng.randf_range(-p.radius, p.radius), p.g.y - 1.0)
		m.vel = Vector2(rng.randf_range(-24.0, 24.0), rng.randf_range(-10.0, -2.0)) * k
		m.size = rng.randf_range(1.8, 3.2) * style.dust_size * k
		m.life = rng.randf_range(0.5, 0.8)
		m.col = style.dust_color if style.dust_color.a > 0.0 else Color(mean.lerp(Color(0.86, 0.83, 0.78), 0.5), 0.5)
		motes.append(m)


func _shatter_on_land(p: Piece) -> Array[Piece]:
	var out: Array[Piece] = []
	var cells := SmashFracture.cells_of(style, p.src, p.src[0], rng)
	var draw_pos := Vector2(p.g.x, p.g.y - p.h)
	for poly in cells:
		var q := _make_piece(poly, Rect2(_rect_pos, Vector2.ONE))
		if q == null:
			continue
		var world := draw_pos + (q.c - p.c).rotated(p.rot)
		q.rot = p.rot
		q.g = Vector2(world.x, p.g.y + rng.randf_range(-1.0, 1.0) * depth * 3.0)
		q.h = maxf(0.0, p.g.y - world.y)
		q.rest = minf(q.rest, q.h)
		var outv := (world - draw_pos).normalized() if world.distance_to(draw_pos) > 0.5 else Vector2.from_angle(rng.randf() * TAU)
		var sp := style.burst * k * rng.randf_range(0.4, 0.9)
		q.vel = p.vel * 0.4 + Vector2(outv.x * sp, rng.randf_range(-1.0, 1.0) * sp * depth)
		q.vh = style.lift * k * rng.randf_range(0.3, 0.75)
		q.vrot = rng.randf_range(-1.0, 1.0) * style.spin
		q.glow = p.glow
		out.append(q)
	if out.is_empty():
		return out
	p.area = -1.0
	_land_puff(p)
	_land_puff(p)
	return out


func _enforce_budget() -> void:
	var total := 0
	for d in live:
		total += d.pieces.size()
	var i := 0
	while total > max_pieces_total and i < live.size():
		var d := live[i]
		i += 1
		if d == self or d._retiring or d.style == null:
			continue
		d.retire()
		total -= d.pieces.size()


## Fades this debris out now (used by the global budget; call it yourself to clear a room).
func retire(seconds: float = 0.4) -> void:
	_retiring = true
	style = style.duplicate() as SmashStyle
	style.debris_seconds = time + 0.01
	style.fade_seconds = seconds
	_sleeping = false
	set_process(true)


# ------------------------------------------------------------------ drawing
func _piece_color(p: Piece) -> Color:
	var col := style.tint
	if p.settled and not p.fixed:
		col = col.darkened(style.settle_darken)
	col.a *= _fade
	if style.melt > 0.0 and not p.fixed:
		col.a *= clampf(1.0 - style.melt * p.age / maxf(0.5, style.debris_seconds if style.debris_seconds > 0.0 else 4.0), 0.0, 1.0)
	return col


func _piece_scale(p: Piece) -> float:
	if style.melt <= 0.0 or p.fixed:
		return 1.0
	return clampf(1.0 - style.melt * 0.6 * p.age / maxf(0.5, style.debris_seconds if style.debris_seconds > 0.0 else 4.0), 0.25, 1.0)


func _piece_rot(p: Piece) -> float:
	match style.spin_mode:
		SmashStyle.Spin.QUARTER:
			return snappedf(p.rot, PI * 0.5)
		SmashStyle.Spin.NONE:
			return 0.0
	return p.rot


func _draw() -> void:
	if style == null or tex == null:
		return
	var ci := get_canvas_item()
	_draw_spill()
	# shadows of airborne pieces
	if style.shadows:
		for p in _order:
			if p.fixed or p.h <= p.rest + 0.5:
				continue
			var a := clampf(0.28 * (1.0 - (p.h - p.rest) / (60.0 * k)), 0.0, 0.28) * _fade
			if a <= 0.01:
				continue
			draw_set_transform(Vector2(p.g.x, p.g.y), 0.0, Vector2(1.0, 0.35))
			draw_circle(Vector2.ZERO, p.radius * 0.9 + 1.0, Color(0, 0, 0, a))
		draw_set_transform(Vector2.ZERO)
	for p in _order:
		var s := _piece_scale(p)
		draw_set_transform(Vector2(p.g.x, p.g.y - p.h), _piece_rot(p), Vector2(s, s))
		RenderingServer.canvas_item_add_triangle_array(ci, p.tris, p.pts, PackedColorArray([_piece_color(p)]), p.uvs, PackedInt32Array(), PackedFloat32Array(), tex.get_rid())
	draw_set_transform(Vector2.ZERO)
	for m in motes:
		if m.delay > 0.0 or m.age >= m.life:
			continue
		_draw_mote(m)
	draw_set_transform(Vector2.ZERO)


func _draw_spill() -> void:
	var grow := clampf(time / 0.45, 0.0, 1.0)
	grow = 1.0 - pow(1.0 - grow, 3.0)
	match style.spill:
		SmashStyle.Spill.GRAIN, SmashStyle.Spill.ASH:
			for i in spill_dots.size():
				var d := spill_dots[i]
				if d.z > grow:
					continue
				var c := spill_cols[i]
				c.a *= _fade
				draw_rect(Rect2(spill_at + Vector2(d.x, d.y) * grow - Vector2(0.5, 0.5) * k, Vector2(1.0, 1.0) * k), c)
		SmashStyle.Spill.LIQUID, SmashStyle.Spill.PUDDLE:
			if spill_shape.size() < 3:
				return
			# a pool that spreads from the base over most of a second: a dark rim, the body, a thin lit sheen
			var s := 1.0 - pow(1.0 - clampf(time / 0.9, 0.0, 1.0), 2.0)
			if style.spill == SmashStyle.Spill.PUDDLE:
				var life := style.debris_seconds if style.debris_seconds > 0.0 else 8.0
				s = clampf(time / 1.4, 0.0, 1.0) * clampf(1.0 - (time - 1.4) / life, 0.25, 1.0)
			if s <= 0.02:
				return
			var base := style.spill_color if style.spill_color.a > 0.0 else Color(mean, 0.7)
			base.a *= _fade
			var rim := PackedVector2Array()
			var body := PackedVector2Array()
			var sheen := PackedVector2Array()
			for i in spill_shape.size():
				var q := spill_shape[i]
				rim.append(spill_at + q * s)
				body.append(spill_at + q * s * 0.86 + Vector2(0, -0.6) * k)
				if i % 2 == 0:
					sheen.append(spill_at + Vector2(q.x * 0.45, q.y * 0.2) * s + Vector2(-q.x * 0.1 * s, -1.2 * k))
			draw_colored_polygon(rim, Color(base.darkened(0.35), base.a))
			draw_colored_polygon(body, base)
			if sheen.size() >= 3:
				draw_colored_polygon(sheen, Color(base.lightened(0.45), base.a * 0.5))


func _draw_mote(m: Mote) -> void:
	var t := clampf(m.age / maxf(0.001, m.life), 0.0, 1.0)
	var a := 1.0 - t
	var pos := m.p - Vector2(0, m.h)
	var col := m.col
	match m.kind:
		DUST:
			# a small solid puff that swells a little, lifts and thins out: a shaded body and a lit cap
			var r := m.size * (0.55 + 0.75 * (1.0 - pow(1.0 - t, 2.0))) * (1.0 - 0.35 * t * t)
			var al := minf(1.0, col.a * 1.4) * pow(a, 1.2) * _fade
			draw_circle(m.p, r, Color(col.darkened(0.18), al * 0.85))
			draw_circle(m.p + Vector2(-0.18, -0.22) * r, r * 0.7, Color(col.lightened(0.12), al * 0.9))
		GLINT, RING, SmashStyle.Bits.SPORES, SmashStyle.Bits.EMBERS, SmashStyle.Bits.SPARKS, SmashStyle.Bits.GLITTER:
			pass
		SmashStyle.Bits.LEAVES:
			draw_set_transform(pos, m.rot, Vector2.ONE)
			var s := m.size
			draw_colored_polygon(PackedVector2Array([Vector2(-s * 1.2, 0), Vector2(-s * 0.2, -s * 0.55), Vector2(s * 1.2, 0), Vector2(-s * 0.2, s * 0.55)]), Color(col, col.a * _fade * (a if t > 0.7 else 1.0)))
			draw_line(Vector2(-s, 0), Vector2(s, 0), Color(col.darkened(0.35), _fade), maxf(0.5, s * 0.18))
			draw_set_transform(Vector2.ZERO)
		SmashStyle.Bits.PETALS, SmashStyle.Bits.SEEDS:
			draw_set_transform(pos, m.rot, Vector2(1.0, 0.6))
			draw_circle(Vector2.ZERO, m.size * (0.9 if m.kind == SmashStyle.Bits.PETALS else 0.55), Color(col, _fade * (a * 1.5 if t > 0.6 else 1.0)))
			draw_set_transform(Vector2.ZERO)
		SmashStyle.Bits.SPLINTERS, SmashStyle.Bits.STRAW:
			var d := Vector2.from_angle(m.rot) * m.size
			draw_line(pos - d, pos + d, Color(col, _fade * (a * 2.0 if t > 0.5 else 1.0)), maxf(0.6, k * (0.7 if m.kind == SmashStyle.Bits.STRAW else 1.0)))
		SmashStyle.Bits.CHIPS:
			draw_set_transform(pos, m.rot, Vector2.ONE)
			var s2 := m.size * 0.8
			draw_colored_polygon(PackedVector2Array([Vector2(-s2, s2 * 0.6), Vector2(s2 * 0.2, -s2), Vector2(s2, s2 * 0.4)]), Color(col, _fade * (a * 2.0 if t > 0.5 else 1.0)))
			draw_set_transform(Vector2.ZERO)
		SmashStyle.Bits.SNOW:
			draw_circle(pos, m.size * 0.55, Color(col.lightened(0.5), _fade * (a * 2.0 if t > 0.5 else 1.0)))
		SmashStyle.Bits.DROPLETS:
			draw_circle(pos, m.size * 0.6, Color(col, _fade))
			draw_circle(pos - Vector2(0.25, 0.25) * m.size, m.size * 0.22, Color(col.lightened(0.6), _fade))
		SmashStyle.Bits.HOOPS:
			# an iron band seen edge-on as it tumbles: a dark ring, thick, with a lit front edge
			var tilt := 0.18 + 0.5 * absf(sin(m.rot * 0.5))
			draw_set_transform(pos, sin(m.rot * 0.3) * 0.5, Vector2(1.0, tilt))
			draw_arc(Vector2.ZERO, m.size, 0.0, TAU, 32, Color(0.11, 0.11, 0.13, _fade), 2.4 * k)
			draw_arc(Vector2.ZERO, m.size, PI * 0.15, PI * 0.85, 12, Color(0.42, 0.44, 0.48, _fade), 1.0 * k)
			draw_set_transform(Vector2.ZERO)


func _draw_glow() -> void:
	if style == null:
		return
	var gci := _glow.get_canvas_item()
	# the break flash and inner glow on the pieces themselves
	var fl := style.flash * clampf(1.0 - time / 0.09, 0.0, 1.0)
	for p in _order:
		var g := fl + p.glow * clampf(1.0 - time / 1.6, 0.0, 1.0)
		if g <= 0.01 or p.fixed:
			continue
		_glow.draw_set_transform(Vector2(p.g.x, p.g.y - p.h), _piece_rot(p), Vector2.ONE * _piece_scale(p))
		RenderingServer.canvas_item_add_triangle_array(gci, p.tris, p.pts, PackedColorArray([Color(g, g * 0.95, g * 0.9, 1.0)]), p.uvs, PackedInt32Array(), PackedFloat32Array(), tex.get_rid())
	_glow.draw_set_transform(Vector2.ZERO)
	for m in motes:
		if m.delay > 0.0 or m.age >= m.life:
			continue
		var t := clampf(m.age / maxf(0.001, m.life), 0.0, 1.0)
		var pos := m.p - Vector2(0, m.h)
		match m.kind:
			GLINT:
				if m.follow < 0 or m.follow >= pieces.size():
					continue
				var p2 := pieces[m.follow]
				var at := Vector2(p2.g.x, p2.g.y - p2.h) + Vector2(cos(m.phase), sin(m.phase)) * p2.radius * 0.5
				var s := m.size * sin(t * PI)
				var c := Color(m.col, _fade)
				_glow.draw_colored_polygon(PackedVector2Array([at + Vector2(-s * 1.6, 0), at + Vector2(0, -s * 0.22), at + Vector2(s * 1.6, 0), at + Vector2(0, s * 0.22)]), c)
				_glow.draw_colored_polygon(PackedVector2Array([at + Vector2(0, -s * 1.6), at + Vector2(s * 0.22, 0), at + Vector2(0, s * 1.6), at + Vector2(-s * 0.22, 0)]), c)
				_glow.draw_circle(at, s * 0.45, Color(m.col, 0.6 * _fade))
			RING:
				var r := 3.0 * k + m.size * (1.0 - pow(1.0 - t, 2.0))
				_glow.draw_set_transform(m.p, 0.0, Vector2(1.0, 0.55 + depth * 0.3))
				_glow.draw_arc(Vector2.ZERO, r, 0.0, TAU, 48, Color(m.col, (1.0 - t) * 0.35), 7.0 * k)
				_glow.draw_arc(Vector2.ZERO, r, 0.0, TAU, 48, Color(m.col.lightened(0.4), 1.0 - t), 2.6 * k)
				_glow.draw_set_transform(Vector2.ZERO)
			SmashStyle.Bits.SPORES, SmashStyle.Bits.EMBERS:
				var c2 := m.col if m.kind == SmashStyle.Bits.SPORES else Color(1.0, 0.55, 0.15)
				_glow.draw_circle(pos, m.size * 1.8, Color(c2, 0.25 * (1.0 - t)))
				_glow.draw_circle(pos, m.size * 0.8, Color(c2.lightened(0.4), 0.9 * (1.0 - t)))
			SmashStyle.Bits.SPARKS:
				var dirv := (m.vel + Vector2(0, -m.vh)).normalized() * m.size * 4.0
				_glow.draw_line(pos - dirv, pos, Color(1.0, 0.75, 0.35, 1.0 - t), maxf(0.6, m.size))
			SmashStyle.Bits.GLITTER:
				var s2 := m.size * (0.6 + 0.6 * absf(sin(m.age * 18.0 + m.phase)))
				var c3 := Color(m.col.lightened(0.5), (1.0 - t) * _fade)
				_glow.draw_colored_polygon(PackedVector2Array([pos + Vector2(-s2, 0), pos + Vector2(0, -s2), pos + Vector2(s2, 0), pos + Vector2(0, s2)]), c3)
