class_name SmashCracks
extends RefCounted
## Crack networks drawn over the sprite between hits. Each crack is a set of whole sprite pixels, walked out from the
## blow over OPAQUE pixels only (a crack never leaves the art), each pixel carrying the moment it appears (0..1), so
## stage 1 of 3 shows the first third of the network and the final hit bakes all of it into the pieces.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

var pixels := PackedVector2Array()
var times := PackedFloat32Array()
var dark := PackedColorArray()
var light_at := PackedVector2Array()
var light := PackedColorArray()
var light_times := PackedFloat32Array()

var _img: Image
var _data: PackedByteArray
var _w := 0
var _h := 0
var _seen := {}


## Builds the network for one frame image, struck at `impact` (pixels), pushed along `push`.
static func build(img: Image, impact: Vector2, push: Vector2, style: SmashStyle, rng: RandomNumberGenerator) -> SmashCracks:
	var c := SmashCracks.new()
	c._img = img
	c._data = img.get_data()
	c._w = img.get_width()
	c._h = img.get_height()
	if style == null or style.crack == SmashStyle.Crack.NONE:
		return c
	var size := float(maxi(c._w, c._h))
	var away := push.angle() if push.length() > 0.01 else rng.randf() * TAU
	match style.crack:
		SmashStyle.Crack.HAIRLINE:
			var n := rng.randi_range(3, 4)
			for i in n:
				var a := away + rng.randf_range(-1.4, 1.4) + PI * (1.0 if i == n - 1 else 0.0)
				c._walk(impact, a, size * rng.randf_range(0.45, 0.8), 0.28, 0.06, 0.0, 1.0, 0, rng, 0)
		SmashStyle.Crack.GRAIN:
			var g := deg_to_rad(style.grain_angle)
			for i in 3:
				var o := Vector2.from_angle(g).orthogonal() * float(i - 1) * rng.randf_range(1.5, 3.0)
				c._walk(impact + o, g, size * rng.randf_range(0.5, 0.9), 0.05, 0.04, float(i) * 0.2, 0.8, 0, rng, 1)
				c._walk(impact + o, g + PI, size * rng.randf_range(0.4, 0.8), 0.05, 0.04, float(i) * 0.2, 0.8, 0, rng, 1)
		SmashStyle.Crack.JAGGED:
			for i in rng.randi_range(3, 4):
				c._zigzag(impact, away + rng.randf_range(-1.6, 1.6), size * rng.randf_range(0.45, 0.85), float(i) * 0.15, rng)
		SmashStyle.Crack.FACET:
			var n2 := rng.randi_range(4, 6)
			for i in n2:
				var a2 := away + (float(i) / float(n2)) * TAU + rng.randf_range(-0.25, 0.25)
				c._walk(impact, a2, size, 0.0, 0.0, float(i) / float(n2) * 0.6, 0.4, 0, rng, 0)
		SmashStyle.Crack.SPIDERWEB:
			c._web(impact, size, rng)
	c._shade(style)
	return c


func _ok(q: Vector2i) -> bool:
	if q.x < 0 or q.y < 0 or q.x >= _w or q.y >= _h:
		return false
	return _data[(q.y * _w + q.x) * 4 + 3] > 127


func _add(q: Vector2i, t: float) -> void:
	var key := q.y * 4096 + q.x
	if _seen.has(key):
		return
	_seen[key] = true
	pixels.append(Vector2(q))
	times.append(clampf(t, 0.0, 1.0))


func _walk(from: Vector2, a: float, length: float, turn: float, branch: float, t0: float, tspan: float, depth: int, rng: RandomNumberGenerator, kind: int) -> void:
	var p := from
	var n := int(length)
	for i in n:
		if turn > 0.0:
			a += rng.randfn(0.0, turn) * 0.5
		p += Vector2.from_angle(a)
		var q := Vector2i(roundi(p.x), roundi(p.y))
		if not _ok(q):
			break
		var t := t0 + tspan * float(i) / maxf(1.0, float(n))
		_add(q, t)
		if kind == 1 and i % 5 == 3 and rng.randf() < 0.5:
			var side := Vector2.from_angle(a).orthogonal() * (1.0 if rng.randf() < 0.5 else -1.0)
			var tick := Vector2i(roundi(p.x + side.x), roundi(p.y + side.y))
			if _ok(tick):
				_add(tick, t)
		if depth < 2 and branch > 0.0 and rng.randf() < branch:
			_walk(p, a + rng.randf_range(0.5, 1.1) * (1.0 if rng.randf() < 0.5 else -1.0), length * 0.45, turn, branch * 0.5, t, tspan * 0.5, depth + 1, rng, kind)


func _zigzag(from: Vector2, a: float, length: float, t0: float, rng: RandomNumberGenerator) -> void:
	var p := from
	var done := 0.0
	var sgn := 1.0
	while done < length:
		var seg := rng.randf_range(3.0, 6.0)
		var b := a + sgn * rng.randf_range(0.45, 0.95)
		sgn = -sgn
		var stop := false
		for s in int(seg):
			p += Vector2.from_angle(b)
			var q := Vector2i(roundi(p.x), roundi(p.y))
			if not _ok(q):
				stop = true
				break
			_add(q, t0 + (1.0 - t0) * (done + float(s)) / length)
		done += seg
		if stop:
			break
		if rng.randf() < 0.2:
			_zigzag(p, a + rng.randf_range(-1.0, 1.0), (length - done) * 0.4, t0 + (1.0 - t0) * done / length, rng)


func _web(c: Vector2, size: float, rng: RandomNumberGenerator) -> void:
	var n := rng.randi_range(6, 8)
	var base := rng.randf() * TAU
	var ends: Array[PackedVector2Array] = []
	for i in n:
		var a := base + (float(i) + rng.randf_range(-0.25, 0.25)) * TAU / float(n)
		var pts := PackedVector2Array()
		var p := c
		for s in int(size):
			p += Vector2.from_angle(a)
			var q := Vector2i(roundi(p.x), roundi(p.y))
			if not _ok(q):
				break
			_add(q, 0.15 + 0.45 * float(s) / size)
			pts.append(p)
		ends.append(pts)
	# rings joining the spokes at two radii
	for r in [size * 0.14, size * 0.3]:
		for i in n:
			var a1: PackedVector2Array = ends[i]
			var a2: PackedVector2Array = ends[(i + 1) % n]
			var k := int(r)
			if a1.size() <= k or a2.size() <= k:
				continue
			var p1 := a1[k] + Vector2(rng.randf_range(-1, 1), rng.randf_range(-1, 1))
			var p2 := a2[k]
			var steps := int(p1.distance_to(p2))
			for s in steps + 1:
				var q := Vector2i(p1.lerp(p2, float(s) / maxf(1.0, float(steps))).round())
				if _ok(q):
					_add(q, 0.55 + r / size)


## Colours: each crack pixel a deep shade of the sprite under it; a lit edge one pixel down and right.
func _shade(style: SmashStyle) -> void:
	var cracked := {}
	for p in pixels:
		cracked[int(p.y) * 4096 + int(p.x)] = true
	for i in pixels.size():
		var q := Vector2i(pixels[i])
		var under := _img.get_pixel(q.x, q.y)
		var col: Color
		if style.crack_glow:
			col = under.lerp(style.glint_color, 0.75)
			col.a = 1.0
		elif style.crack_color.a > 0.0:
			col = style.crack_color
		else:
			col = Color(under.r * 0.3, under.g * 0.28, under.b * 0.32, 1.0)
		dark.append(col)
		var l := q + Vector2i(1, 1)
		if _ok(l) and not cracked.has(l.y * 4096 + l.x):
			var u2 := _img.get_pixel(l.x, l.y)
			var lc := u2.lightened(0.35)
			lc.a = 0.85
			light_at.append(Vector2(l))
			light.append(lc)
			light_times.append(times[i])


## Paints every crack pixel up to `stage` (0..1) into an image (the pieces of a cracked object keep their cracks).
func bake(img: Image, stage: float) -> void:
	for i in light_at.size():
		if light_times[i] <= stage:
			img.set_pixelv(Vector2i(light_at[i]), light[i])
	for i in pixels.size():
		if times[i] <= stage:
			img.set_pixelv(Vector2i(pixels[i]), dark[i])
