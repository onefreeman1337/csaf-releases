@icon("res://addons/smithereens/icon_breakable.svg")
class_name Breakable2D
extends Node2D
## Makes the sprite it is placed under breakable. Add it as a child of a Sprite2D or AnimatedSprite2D, give it a
## SmashStyle, and call hit() (or smash()). Every hit before the last draws the next crack stage over the sprite;
## the last one cuts the sprite's CURRENT frame into pieces by its material and hands them to a SmashDebris.
##
##   $Pot/Breakable2D.hit(player.global_position)        # one blow from the player's side
##   $Crate/Breakable2D.smash()                           # break now, whatever hits remain
##   Smithereens.break_node($Barrel, "barrel_staves")      # no node needed
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

signal struck(hits_taken: int, hits_left: int)
signal broken(debris: SmashDebris)
signal restored

enum View { SIDE, TOP_DOWN }
enum OnBreak { FREE, HIDE, KEEP }

@export var style: SmashStyle
## The sprite to break. Empty = the parent.
@export var target: NodePath
## SIDE: pieces fall to the object's base line. TOP_DOWN: they scatter round it on the ground.
@export var view: View = View.SIDE
## Hits before it breaks; 0 = the style's own count.
@export_range(0, 8) var hits_override := 0
## What happens to the sprite when it breaks. HIDE keeps it for restore() (and regrow).
@export var on_break: OnBreak = OnBreak.FREE
## Seconds until a HIDDEN breakable comes back (gathering nodes); 0 = never by itself.
@export var regrow_seconds := 0.0
## Where the debris is added. Empty = the sprite's parent (so it y-sorts with the world).
@export var debris_parent: NodePath
## Fixes the fracture; 0 = derived from the node's path (two pots side by side never break alike).
@export var fracture_seed := 0
@export var shake_target := true
@export var flash_target := true

var hits_taken := 0
var _cracks: SmashCracks
var _crack_stage := 0.0
var _broken := false
var _shake_t := 0.0
var _shake_origin := Vector2.ZERO
var _rng := RandomNumberGenerator.new()
var _push := Vector2.RIGHT


func _ready() -> void:
	set_process(false)


## The node being broken (the parent unless `target` says otherwise).
func get_target() -> Node2D:
	if target != NodePath(""):
		return get_node_or_null(target) as Node2D
	return get_parent() as Node2D


func hits_needed() -> int:
	if hits_override > 0:
		return hits_override
	return maxi(1, style.hits if style else 1)


func is_broken() -> bool:
	return _broken


## One blow. from_global = where the blow came from (the striker), INF = straight on.
func hit(from_global: Vector2 = Vector2.INF, damage: int = 1) -> void:
	if _broken or style == null:
		return
	hits_taken += maxi(1, damage)
	var need := hits_needed()
	if hits_taken >= need:
		smash(from_global)
		return
	var f := frame()
	if f.is_empty():
		return
	var img: Image = f["image"]
	var rect: Rect2 = f["rect"]
	var info := _impact(from_global, img, rect)
	if _cracks == null:
		_rng.seed = _seed() + 7
		_cracks = SmashCracks.build(img, info[0], info[1], style, _rng)
	_crack_stage = float(hits_taken) / float(maxi(1, need - 1))
	_sync()
	queue_redraw()
	_chips(img, rect, info[0], info[1])
	_jolt()
	struck.emit(hits_taken, need - hits_taken)


## Draws the crack stage for `taken` hits without chips or shake (previews, loading a saved node).
func crack_to(taken: int, from_global: Vector2 = Vector2.INF) -> void:
	if style == null or taken <= 0:
		return
	var f := frame()
	if f.is_empty():
		return
	var info := _impact(from_global, f["image"], f["rect"])
	_rng.seed = _seed() + 7
	_cracks = SmashCracks.build(f["image"], info[0], info[1], style, _rng)
	hits_taken = mini(taken, hits_needed() - 1)
	_crack_stage = float(hits_taken) / float(maxi(1, hits_needed() - 1))
	_sync()
	queue_redraw()


## Breaks it now. Returns the SmashDebris (null if nothing could be cut).
func smash(from_global: Vector2 = Vector2.INF) -> SmashDebris:
	if _broken or style == null:
		return null
	var tgt := get_target()
	var f := frame()
	if tgt == null or f.is_empty():
		return null
	var img: Image = (f["image"] as Image).duplicate()
	var rect: Rect2 = f["rect"]
	var info := _impact(from_global, img, rect)
	if _cracks != null and _crack_stage > 0.0:
		_cracks.bake(img, _crack_stage)
	_rng.seed = _seed()
	var cells := SmashFracture.cells(style, Vector2(img.get_size()), info[0], _rng)
	var d := SmashDebris.new()
	d.name = "Smithereens_" + str(tgt.name)
	var parent := get_node_or_null(debris_parent) if debris_parent != NodePath("") else tgt.get_parent()
	if parent == null:
		parent = tgt
	parent.add_child(d)
	d.global_transform = tgt.global_transform
	d.texture_filter = tgt.texture_filter
	if tgt is CanvasItem:
		d.z_index = (tgt as CanvasItem).z_index
	d.setup(style, img, rect, cells, info[0], info[1], 0.9 if view == View.TOP_DOWN else 0.25, _seed() + 13)
	_broken = true
	_cracks = null
	_crack_stage = 0.0
	queue_redraw()
	broken.emit(d)
	match on_break:
		OnBreak.FREE:
			tgt.queue_free()
		OnBreak.HIDE:
			tgt.visible = false
			if regrow_seconds > 0.0:
				get_tree().create_timer(regrow_seconds, false).timeout.connect(restore)
		OnBreak.KEEP:
			pass
	return d


## Brings a HIDDEN (or kept) breakable back whole.
func restore() -> void:
	var tgt := get_target()
	if tgt == null:
		return
	tgt.visible = true
	_broken = false
	hits_taken = 0
	_cracks = null
	_crack_stage = 0.0
	queue_redraw()
	restored.emit()


## The frame being shown right now: {image (RGBA8, flips applied), rect (where it draws in the sprite's local space)}.
func frame() -> Dictionary:
	var tgt := get_target()
	var img: Image
	var rect := Rect2()
	if tgt is Sprite2D:
		var s := tgt as Sprite2D
		if s.texture == null:
			return {}
		img = s.texture.get_image()
		if img == null:
			return {}
		if img.is_compressed():
			img.decompress()
		var reg := Rect2i(Vector2i.ZERO, img.get_size())
		if s.region_enabled:
			reg = Rect2i(s.region_rect)
		if s.hframes > 1 or s.vframes > 1:
			var fs := Vector2i(reg.size.x / s.hframes, reg.size.y / s.vframes)
			reg = Rect2i(reg.position + Vector2i(s.frame_coords.x * fs.x, s.frame_coords.y * fs.y), fs)
		img = img.get_region(reg)
		if s.flip_h:
			img.flip_x()
		if s.flip_v:
			img.flip_y()
		rect = s.get_rect()
	elif tgt is AnimatedSprite2D:
		var a := tgt as AnimatedSprite2D
		if a.sprite_frames == null or not a.sprite_frames.has_animation(a.animation):
			return {}
		var t := a.sprite_frames.get_frame_texture(a.animation, a.frame)
		if t == null:
			return {}
		img = t.get_image()
		if img == null:
			return {}
		if img.is_compressed():
			img.decompress()
		img = img.duplicate()
		if a.flip_h:
			img.flip_x()
		if a.flip_v:
			img.flip_y()
		var sz := Vector2(img.get_size())
		rect = Rect2(a.offset - (sz * 0.5 if a.centered else Vector2.ZERO), sz)
	else:
		return {}
	if img.get_format() != Image.FORMAT_RGBA8:
		img.convert(Image.FORMAT_RGBA8)
	return {"image": img, "rect": rect}


func _seed() -> int:
	if fracture_seed != 0:
		return fracture_seed
	var tgt := get_target()
	return hash(str(tgt.get_path()) if tgt and tgt.is_inside_tree() else str(get_instance_id()))


## [impact in frame pixels, push direction]: the blow lands on the art where a line from the striker to the
## sprite's middle first meets an opaque pixel, then a little inside it.
func _impact(from_global: Vector2, img: Image, rect: Rect2) -> Array:
	var tgt := get_target()
	var size := Vector2(img.get_size())
	var mid := size * 0.5
	var data := img.get_data()
	var w := img.get_width()
	var push := Vector2.RIGHT
	if from_global == Vector2.INF or tgt == null:
		var r := RandomNumberGenerator.new()
		r.seed = _seed() + hits_taken
		_push = Vector2.from_angle(r.randf_range(-0.3, 0.3)) * (1.0 if r.randf() < 0.5 else -1.0)
		return [mid, _push]
	var from_local := tgt.to_local(from_global) - rect.position
	push = (mid - from_local)
	push = Vector2(push.x, push.y * 0.35).normalized() if push.length() > 0.1 else Vector2.RIGHT
	var hitp := mid
	var steps := int(from_local.distance_to(mid)) + 1
	for s in steps:
		var q := from_local.lerp(mid, float(s) / float(steps))
		var qi := Vector2i(int(q.x), int(q.y))
		if qi.x >= 0 and qi.y >= 0 and qi.x < w and qi.y < img.get_height() and data[(qi.y * w + qi.x) * 4 + 3] > 127:
			hitp = q
			break
	var inside := hitp.lerp(mid, 0.22)
	_push = push
	return [inside, push]


func _sync() -> void:
	var tgt := get_target()
	if tgt and tgt != get_parent():
		top_level = true
		global_transform = tgt.global_transform


func _chips(img: Image, rect: Rect2, impact: Vector2, push: Vector2) -> void:
	if style.chips_per_hit <= 0 and style.dust <= 0:
		return
	var tgt := get_target()
	var d := SmashDebris.new()
	var parent := get_node_or_null(debris_parent) if debris_parent != NodePath("") else tgt.get_parent()
	parent.add_child(d)
	d.global_transform = tgt.global_transform
	d.texture_filter = tgt.texture_filter
	var chip_style := style.duplicate() as SmashStyle
	chip_style.bits = SmashStyle.Bits.CHIPS
	chip_style.bits_amount = style.chips_per_hit
	chip_style.bits_color = Color(0, 0, 0, 0)
	chip_style.dust = mini(style.dust, 2)
	chip_style.dust_size = style.dust_size * 0.6
	chip_style.glints = mini(style.glints, 1)
	chip_style.spill = SmashStyle.Spill.NONE
	chip_style.shockwave = false
	chip_style.spread = 120.0
	chip_style.burst = style.burst * 0.6
	chip_style.lift = maxf(40.0, style.lift * 0.6)
	chip_style.debris_seconds = 2.0
	chip_style.fade_seconds = 0.3
	chip_style.inner_glow = 0.0
	chip_style.cut = SmashStyle.Cut.NONE
	var empty: Array[PackedVector2Array] = []
	d.bits_at_impact = true
	d.setup(chip_style, img, rect, empty, impact, push, 0.9 if view == View.TOP_DOWN else 0.25, _seed() + hits_taken * 101)


func _jolt() -> void:
	var tgt := get_target()
	if tgt == null:
		return
	if flash_target:
		var was := tgt.modulate
		tgt.modulate = Color(1.0 + style.flash * 1.5, 1.0 + style.flash * 1.5, 1.0 + style.flash * 1.5, was.a)
		get_tree().create_timer(0.06, false).timeout.connect(func() -> void:
			if is_instance_valid(tgt):
				tgt.modulate = was)
	if shake_target and style.shake > 0.0:
		if _shake_t <= 0.0:
			_shake_origin = tgt.position
		_shake_t = 0.16
		set_process(true)


func _process(delta: float) -> void:
	var tgt := get_target()
	if tgt == null:
		set_process(false)
		return
	_shake_t -= delta
	if _shake_t <= 0.0:
		tgt.position = _shake_origin
		set_process(false)
		return
	var amp := style.shake * (_shake_t / 0.16) * absf(tgt.global_scale.x)
	tgt.position = _shake_origin + Vector2(_push.x * sin(_shake_t * 90.0) * amp, 0.0)


func _draw() -> void:
	if _cracks == null or _crack_stage <= 0.0:
		return
	var f := frame()
	if f.is_empty():
		return
	var o: Vector2 = (f["rect"] as Rect2).position
	for i in _cracks.light_at.size():
		if _cracks.light_times[i] <= _crack_stage:
			draw_rect(Rect2(o + _cracks.light_at[i], Vector2.ONE), _cracks.light[i])
	for i in _cracks.pixels.size():
		if _cracks.times[i] <= _crack_stage:
			draw_rect(Rect2(o + _cracks.pixels[i], Vector2.ONE), _cracks.dark[i])
