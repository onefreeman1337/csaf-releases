extends Node2D
## Smithereens demo. Eight material pages of six breakables each, plus an overview of all 48.
##   click a prop: strike it from the mouse's side (multi-hit styles crack first)
##   Space: break the whole page in a cascade    R: restore everything    Left / Right: change page
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

const PAGE_SCALE := 3.0
const GRID_SCALE := 1.25
const LITE := false

var page := 1
var items: Array[Dictionary] = []
var _cascade := -1.0
var _cascade_i := 0
var _font: Font
var _title := ""
var _hint := "click a prop to strike it  ·  Space: break the page  ·  R: restore  ·  Left/Right: page"


func _ready() -> void:
	_font = ThemeDB.fallback_font
	_build()


func pages() -> int:
	return Smithereens.MATERIALS.size() + 1


func _build() -> void:
	for it in items:
		if is_instance_valid(it["root"]):
			it["root"].queue_free()
	items.clear()
	for d in SmashDebris.live.duplicate():
		if is_instance_valid(d):
			d.queue_free()
	var view := get_viewport_rect().size
	var rows: Array[Dictionary] = []
	if page == 0:
		rows = Smithereens.STYLES.duplicate()
		_title = "SMITHEREENS  ·  all %d break styles" % rows.size()
	else:
		var mat := Smithereens.MATERIALS[page - 1]
		for s in Smithereens.STYLES:
			if s["material"] == mat:
				rows.append(s)
		_title = "SMITHEREENS  ·  %s" % mat.capitalize()
	var cols := 8 if page == 0 else 3
	var sc := GRID_SCALE if page == 0 else PAGE_SCALE * 0.72
	var cell := Vector2(view.x / float(cols), (view.y - 120.0) / ceilf(float(rows.size()) / float(cols)))
	for i in rows.size():
		var row: Dictionary = rows[i]
		var st := Smithereens.style(String(row["id"]))
		var tex := Smithereens.prop(String(row["id"]))
		if st == null or tex == null:
			continue
		var root := Node2D.new()
		var cx := (float(i % cols) + 0.5) * cell.x
		var base := 96.0 + (float(i / cols) + 1.0) * cell.y - (14.0 if page == 0 else 30.0)
		root.position = Vector2(cx, base)
		add_child(root)
		var spr := Sprite2D.new()
		spr.texture = tex
		spr.scale = Vector2.ONE * sc
		spr.position = Vector2(0.0, -float(tex.get_height()) * sc * 0.5)
		root.add_child(spr)
		var b := Breakable2D.new()
		b.style = st
		b.on_break = Breakable2D.OnBreak.HIDE
		b.fracture_seed = 1000 + i
		b.view = Breakable2D.View.TOP_DOWN if String(row["id"]) in ["grain_spill", "jug_splash", "snowman_burst", "bush_cut", "flower_petals", "hedge_burst", "sack_tear", "pumpkin_smash"] else Breakable2D.View.SIDE
		spr.add_child(b)
		items.append({"root": root, "sprite": spr, "b": b, "id": row["id"], "name": row["name"], "size": Vector2(tex.get_size()) * sc})
	queue_redraw()


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		var mp := get_global_mouse_position()
		for it in items:
			var spr: Sprite2D = it["sprite"]
			var r := Rect2(spr.global_position - it["size"] * 0.5, it["size"]).grow(8.0)
			if spr.visible and r.has_point(mp):
				var side := -1.0 if mp.x < spr.global_position.x else 1.0
				(it["b"] as Breakable2D).hit(spr.global_position + Vector2(side * 200.0, -10.0))
				break
	elif event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_SPACE:
				_cascade = 0.0
				_cascade_i = 0
			KEY_R:
				_build()
			KEY_RIGHT:
				page = (page + 1) % pages()
				_build()
			KEY_LEFT:
				page = (page - 1 + pages()) % pages()
				_build()


func _process(delta: float) -> void:
	if _cascade < 0.0:
		return
	_cascade += delta
	while _cascade_i < items.size() and _cascade >= float(_cascade_i) * (0.06 if page == 0 else 0.22):
		var it := items[_cascade_i]
		var spr: Sprite2D = it["sprite"]
		if spr.visible:
			(it["b"] as Breakable2D).smash(spr.global_position + Vector2(-200.0, -10.0))
		_cascade_i += 1
	if _cascade_i >= items.size():
		_cascade = -1.0


## Strikes item i once (the store capture and the tests use it).
func strike(i: int, from_left := true) -> void:
	if i < 0 or i >= items.size():
		return
	var spr: Sprite2D = items[i]["sprite"]
	(items[i]["b"] as Breakable2D).hit(spr.global_position + Vector2(-200.0 if from_left else 200.0, -10.0))


func _draw() -> void:
	var view := get_viewport_rect().size
	# a stage: dark wall, a warm floor band under every row of props
	draw_rect(Rect2(Vector2.ZERO, view), Color(0.09, 0.1, 0.12))
	for it in items:
		var base: float = (it["root"] as Node2D).position.y
		var cx: float = (it["root"] as Node2D).position.x
		var w := view.x / (8.0 if page == 0 else 3.0)
		draw_rect(Rect2(cx - w * 0.5, base, w, 3.0), Color(0.2, 0.18, 0.17))
		draw_rect(Rect2(cx - w * 0.5, base + 3.0, w, (22.0 if page == 0 else 44.0)), Color(0.15, 0.14, 0.14))
		draw_string_outline(_font, Vector2(cx - w * 0.5 + 8.0, base + (17.0 if page == 0 else 30.0)), String(it["name"]), HORIZONTAL_ALIGNMENT_LEFT, w - 16.0, 12 if page == 0 else 18, 4, Color(0.05, 0.05, 0.06))
		draw_string(_font, Vector2(cx - w * 0.5 + 8.0, base + (17.0 if page == 0 else 30.0)), String(it["name"]), HORIZONTAL_ALIGNMENT_LEFT, w - 16.0, 12 if page == 0 else 18, Color(0.92, 0.84, 0.7))
	draw_rect(Rect2(0, 0, view.x, 64), Color(0.06, 0.06, 0.08))
	draw_string(_font, Vector2(24, 40), _title, HORIZONTAL_ALIGNMENT_LEFT, -1, 26, Color(0.96, 0.82, 0.6))
	draw_string(_font, Vector2(24, view.y - 14), _hint, HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color(0.6, 0.62, 0.66))
