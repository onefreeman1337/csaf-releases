@tool
class_name EmberfluxEffect
extends Node2D
## One Emberflux VFX preset. Drives every shader layer below it from one clock and one palette.
##
## Instance a preset scene, set its position (and rotation for projectiles and beams), and it plays.
## One-shot presets (hits, slashes, bursts) play once and hide; loop presets (projectiles, auras, shields,
## status marks, sigils, vortices) run until stop() is called.
##
##   var fx: EmberfluxEffect = preload("res://addons/emberflux/presets/fire/fire_impact.tscn").instantiate()
##   fx.position = target.global_position
##   fx.free_when_finished = true
##   add_child(fx)
##
## In the editor every preset previews itself (turn off editor_preview to stop it).
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

## Emitted when a one-shot preset reaches the end of its duration.
signal finished

## The three colours of the effect. Swap it to recolour; the element's shapes stay.
@export var palette: EmberfluxPalette:
	set(value):
		if palette and palette.changed.is_connected(_apply_palette):
			palette.changed.disconnect(_apply_palette)
		palette = value
		if palette and not palette.changed.is_connected(_apply_palette):
			palette.changed.connect(_apply_palette)
		_apply_palette()
## Seconds for one play of a one-shot, or one cycle of a loop's progress value.
@export_range(0.05, 10.0, 0.01, "or_greater", "suffix:s") var duration := 0.8
## Loop presets ship with this on. Turn it on for a one-shot to repeat it.
@export var looping := false
## Start playing as soon as the node enters the tree (at runtime).
@export var autoplay := true
## Playback speed multiplier.
@export_range(0.0, 4.0, 0.01, "or_greater") var speed_scale := 1.0
## Uniform size multiplier (sets the node scale).
@export_range(0.1, 8.0, 0.01, "or_greater") var effect_scale := 1.0:
	set(value):
		effect_scale = value
		scale = Vector2.ONE * value
## Brightness multiplier. Above 1 pushes more of the effect into the core colour.
@export_range(0.0, 3.0, 0.01) var intensity := 1.0:
	set(value):
		intensity = value
		_apply_static()
## 1 = pure light (adds to what is behind it), 0 = normal alpha blend (reads on bright backgrounds).
@export_range(0.0, 1.0, 0.01) var additive := 1.0:
	set(value):
		additive = value
		_apply_static()
## Queue the node for deletion when a one-shot finishes.
@export var free_when_finished := false

@export_group("Preview")
## The moment (0..1 of duration) shown by seek_preview() and in thumbnails.
@export_range(0.0, 1.0, 0.01) var preview_progress := 0.35
## Animate this preset inside the editor viewport.
@export var editor_preview := true

var _elapsed := 0.0
var _playing := false
var _frozen := false
var _materials: Array[ShaderMaterial] = []


func _ready() -> void:
	_collect()
	_apply_palette()
	_apply_static()
	if Engine.is_editor_hint():
		_playing = editor_preview
		_push(preview_progress * duration)
	elif autoplay:
		play()
	else:
		visible = false


func _process(delta: float) -> void:
	if _frozen or not _playing:
		return
	_elapsed += delta * speed_scale
	if Engine.is_editor_hint():
		if not editor_preview:
			return
		var cycle := duration + (0.0 if looping else 0.45)
		if _elapsed > cycle:
			_elapsed = fmod(_elapsed, cycle)
		_apply_aspect()
		_push(_elapsed)
		return
	if not looping and _elapsed >= duration:
		_push(duration)
		_playing = false
		visible = false
		finished.emit()
		if free_when_finished:
			queue_free()
		return
	_push(_elapsed)


## Start (or restart) the effect from the beginning.
func play() -> void:
	_collect()
	_elapsed = 0.0
	_playing = true
	_frozen = false
	visible = true
	_push(0.0)


## Stop and hide the effect.
func stop() -> void:
	_playing = false
	_frozen = false
	visible = false


func is_playing() -> bool:
	return _playing


## Jump to a point of the effect (0..1 of duration). With hold, the effect freezes there (thumbnails, stills).
func seek(fraction: float, hold := true) -> void:
	_collect()
	_elapsed = clampf(fraction, 0.0, 1.0) * duration
	_frozen = hold
	_playing = true
	visible = true
	_push(_elapsed)


## Freeze on the preset's showcase moment (preview_progress). Used by the demo and by thumbnail tools.
func seek_preview() -> void:
	seek(preview_progress, true)


## Alias of seek_preview(), called by CSAF's headless capture harness when it photographs each preset.
func csaf_preview() -> void:
	seek_preview()


func _push(time_s: float) -> void:
	var pr := 0.0
	if looping:
		pr = fposmod(time_s / maxf(duration, 0.001), 1.0)
	else:
		pr = clampf(time_s / maxf(duration, 0.001), 0.0, 1.0)
	for m in _materials:
		RenderingServer.material_set_param(m.get_rid(), &"progress", pr)
		RenderingServer.material_set_param(m.get_rid(), &"ef_time", time_s)


func _collect() -> void:
	_materials.clear()
	if not is_inside_tree():
		return
	for c in find_children("*", "CanvasItem", true, false):
		var ci := c as CanvasItem
		if ci and ci.material is ShaderMaterial:
			_materials.append(ci.material as ShaderMaterial)


func _apply_palette() -> void:
	if not is_inside_tree() or palette == null:
		return
	if _materials.is_empty():
		_collect()
	for m in _materials:
		RenderingServer.material_set_param(m.get_rid(), &"core_color", palette.core)
		RenderingServer.material_set_param(m.get_rid(), &"mid_color", palette.mid)
		RenderingServer.material_set_param(m.get_rid(), &"edge_color", palette.edge)


func _apply_static() -> void:
	if not is_inside_tree():
		return
	if _materials.is_empty():
		_collect()
	for m in _materials:
		RenderingServer.material_set_param(m.get_rid(), &"intensity", intensity)
		RenderingServer.material_set_param(m.get_rid(), &"additive", additive)
	_apply_aspect()


# Keeps each layer's shader aspect equal to the layer's own width / height, so a resized layer never stretches.
func _apply_aspect() -> void:
	for c in find_children("*", "Control", true, false):
		var ctl := c as Control
		if ctl and ctl.material is ShaderMaterial and ctl.size.y > 0.0:
			RenderingServer.material_set_param(ctl.material.get_rid(), &"aspect", ctl.size.x / ctl.size.y)
