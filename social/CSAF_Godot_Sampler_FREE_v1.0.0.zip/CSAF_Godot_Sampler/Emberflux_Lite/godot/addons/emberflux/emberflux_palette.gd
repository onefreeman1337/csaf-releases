@tool
class_name EmberfluxPalette
extends Resource
## Three colours that recolour any Emberflux preset.
##
## core is the hottest, brightest part of an effect; mid is its body; edge is the falloff and outer glow.
## Assign a palette to an EmberfluxEffect (or edit this one) and every shader layer of that effect follows.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

@export var core := Color(1.0, 0.96, 0.84):
	set(value):
		core = value
		emit_changed()
@export var mid := Color(1.0, 0.56, 0.14):
	set(value):
		mid = value
		emit_changed()
@export var edge := Color(0.78, 0.14, 0.05):
	set(value):
		edge = value
		emit_changed()


## A copy with every colour shifted round the hue wheel (0..1). Handy for quick team or variant colours.
func hue_shifted(amount: float) -> EmberfluxPalette:
	var p := EmberfluxPalette.new()
	p.core = _shift(core, amount)
	p.mid = _shift(mid, amount)
	p.edge = _shift(edge, amount)
	return p


static func _shift(c: Color, amount: float) -> Color:
	return Color.from_hsv(fposmod(c.h + amount, 1.0), c.s, c.v, c.a)
