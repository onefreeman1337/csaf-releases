class_name EmberfluxCatalog
extends RefCounted
## Every Emberflux preset, by id. Generated from the pack's spec table; do not edit by hand.
##
##   var fx := EmberfluxCatalog.instantiate("frost_shockwave")
##   fx.position = where
##   add_child(fx)
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

const ELEMENTS: Array[String] = ["fire", "frost"]
const FAMILIES: Array[String] = [
	"impact",
	"slash",
	"nova",
	"shockwave",
	"orb",
	"aura",
]
const PRESETS: Array[Dictionary] = [
	{"id": "fire_impact", "element": "fire", "family": "impact", "group": "hit", "loop": false, "path": "res://addons/emberflux/presets/fire/fire_impact.tscn"},
	{"id": "frost_impact", "element": "frost", "family": "impact", "group": "hit", "loop": false, "path": "res://addons/emberflux/presets/frost/frost_impact.tscn"},
	{"id": "fire_slash", "element": "fire", "family": "slash", "group": "slash", "loop": false, "path": "res://addons/emberflux/presets/fire/fire_slash.tscn"},
	{"id": "frost_slash", "element": "frost", "family": "slash", "group": "slash", "loop": false, "path": "res://addons/emberflux/presets/frost/frost_slash.tscn"},
	{"id": "fire_nova", "element": "fire", "family": "nova", "group": "burst", "loop": false, "path": "res://addons/emberflux/presets/fire/fire_nova.tscn"},
	{"id": "frost_nova", "element": "frost", "family": "nova", "group": "burst", "loop": false, "path": "res://addons/emberflux/presets/frost/frost_nova.tscn"},
	{"id": "fire_shockwave", "element": "fire", "family": "shockwave", "group": "burst", "loop": false, "path": "res://addons/emberflux/presets/fire/fire_shockwave.tscn"},
	{"id": "frost_shockwave", "element": "frost", "family": "shockwave", "group": "burst", "loop": false, "path": "res://addons/emberflux/presets/frost/frost_shockwave.tscn"},
	{"id": "fire_orb", "element": "fire", "family": "orb", "group": "projectile", "loop": true, "path": "res://addons/emberflux/presets/fire/fire_orb.tscn"},
	{"id": "frost_orb", "element": "frost", "family": "orb", "group": "projectile", "loop": true, "path": "res://addons/emberflux/presets/frost/frost_orb.tscn"},
	{"id": "fire_aura", "element": "fire", "family": "aura", "group": "buff", "loop": true, "path": "res://addons/emberflux/presets/fire/fire_aura.tscn"},
	{"id": "frost_aura", "element": "frost", "family": "aura", "group": "buff", "loop": true, "path": "res://addons/emberflux/presets/frost/frost_aura.tscn"},
]


## The scene path of a preset id ("" when unknown).
static func path_of(id: String) -> String:
	for p in PRESETS:
		if p["id"] == id:
			return p["path"]
	return ""


## A new instance of a preset, or null when the id is unknown.
static func instantiate(id: String) -> EmberfluxEffect:
	var path := path_of(id)
	if path == "":
		push_warning("Emberflux: no preset named %s" % id)
		return null
	return (load(path) as PackedScene).instantiate() as EmberfluxEffect


## Every preset id of one element ("fire", "frost", "storm", "venom", "void", "radiant").
static func ids_for_element(element: String) -> Array[String]:
	var out: Array[String] = []
	for p in PRESETS:
		if p["element"] == element:
			out.append(p["id"])
	return out


## Every preset id of one family ("impact", "slash", "orb", ...).
static func ids_for_family(family: String) -> Array[String]:
	var out: Array[String] = []
	for p in PRESETS:
		if p["family"] == family:
			out.append(p["id"])
	return out
