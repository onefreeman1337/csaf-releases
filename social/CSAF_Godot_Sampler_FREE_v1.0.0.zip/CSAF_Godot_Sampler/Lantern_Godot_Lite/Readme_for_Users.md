# Lantern Lite - 12 free 2D lighting presets for Godot 4

Twelve real presets from **Lantern - 2D Lighting, Day-Night and Flicker Presets for Godot 4**, free under the MIT licence.
Every one is computed while the game runs: the light shapes are drawn into textures by code, the flames flicker on noise
curves, the skies are colour grades, the darkness is a shader.

- **Godot version:** built and tested on **Godot 4.7.2**, under **both renderers: Forward+ and Compatibility**. Older 4.x
  versions were NOT run, so they are not claimed.
- **The 12 presets:**
  light shapes `cottage_window` (four warm panes thrown down from a window), `leaf_dapple` (moonlight through leaves),
  `door_ajar` (a wedge of light from a door) ·
  living sources `candle`, `wall_torch`, `street_lamp` ·
  skies `golden_hour`, `blue_hour`, `moonlit` ·
  darkness that follows the player `torch_radius`, `fog_of_war` (remembers where you have been), `lamp_reveal`
  (holes of light around every lamp).

## Install

Copy `godot/addons/lantern/` into your project's `addons/` folder. No plugin to enable. Keep the folder name: the preset
scenes reference `res://addons/lantern/` by path. To browse first, open `godot/` as a project and press Play
(Left / Right: preset, Up / Down: family, Space: day cycle, WASD: walk in the darkness family).

## Use it

```gdscript
var sky := LanternCatalog.instantiate("moonlit") as LanternSky
add_child(sky)                                    # the night (one per scene)
var win := LanternCatalog.instantiate("cottage_window") as LanternLight
win.position = Vector2(320, 180)                  # the bottom of the window; the light falls down from there
win.follow_night = true                           # on at dusk, off by day
add_child(win)
var shade := LanternCatalog.instantiate("torch_radius") as LanternShade
player.add_child(shade)                           # darkness that follows the player
```

The classes are the same as the full pack's (`LanternLight`, `LanternCookie`, `LanternSource`, `LanternSky`,
`LanternSkyLook`, `LanternClock`, `LanternShade`, `LanternCatalog`, `LanternUtil`), but this copy only contains the code
for the shapes, flicker curves, sources, sky features and darkness kinds these twelve presets use. Put HUD layers on a
CanvasLayer above 5 so the sky grade and the darkness do not cover them.

## The full pack

**Lantern** has all 48 presets: chapel arches, rose windows and leaded stained glass, blinds, bars, paper screens, a
pierced tin lantern and a grate; campfires with embers, a swinging oil lantern, a forge, a failing neon sign, a
fluorescent tube, a searchlight, a beacon, a wisp and fireflies; twelve skies including sunrise, high noon, sunset,
overcast, a thunderstorm with lightning and an aurora; and twelve darkness layers including a flashlight cone, retro
bands, a cave pocket, sonar, a blizzard, a nightmare, binoculars, night vision and a stage spotlight.
https://csaf.itch.io/lantern-godot

## Licence

MIT (see `LICENSE.txt`). The demo town tiles are from Verdant 09 Town by the same studio and are covered by the same
licence here. The code was written by an AI.
