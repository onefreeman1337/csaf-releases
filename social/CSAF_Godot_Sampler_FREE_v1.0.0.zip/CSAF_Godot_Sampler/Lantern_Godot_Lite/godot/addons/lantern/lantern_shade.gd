class_name LanternShade
extends Node2D
## Darkness that follows the player: a torch radius, a flashlight cone, retro stepped bands, fog of war that remembers,
## a ragged cave pocket, sonar rings, a blizzard or smoke haze, a heartbeat nightmare, holes around every lamp, a pair
## of binoculars, night vision, or a stage spotlight. Add it as a child of the player (or point `target` at them).
## Children of this node (a LanternLight, say) travel with the target. The darkness itself is drawn in its own
## CanvasLayer at runtime, so the editor stays readable.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

enum Kind { RADIUS, CONE, BANDS, FOG_OF_WAR, CAVE, SONAR, HAZE, NIGHTMARE, REVEAL, BINOCULARS, NIGHT_VISION, SPOTLIGHT }

const SHADER := preload("res://addons/lantern/shaders/lantern_shade.gdshader")

@export var kind: Kind = Kind.RADIUS
## The node the darkness centres on (empty = this node's parent).
@export var target: NodePath
## Radius of sight in world pixels (the camera's zoom is applied for you).
@export_range(8.0, 4096.0, 1.0) var radius: float = 90.0
@export_range(0.0, 1.0, 0.01) var softness: float = 0.35
## The colour beyond sight; its alpha is how opaque the dark is (HAZE: the haze colour).
@export var darkness: Color = Color(0.0, 0.0, 0.02, 0.97)
## Rim / trace / vein colour; its alpha is the rim's strength where the kind uses one.
@export var rim_color: Color = Color(1.0, 0.6, 0.25, 0.0)
@export_range(5.0, 180.0, 0.5) var cone_degrees: float = 70.0
## CONE: the beam's direction when the target is not moving (or always, with auto_face off).
@export var facing: Vector2 = Vector2.RIGHT
@export var auto_face: bool = true
## BANDS: size of one pixel step, world pixels.
@export_range(1.0, 32.0, 1.0) var pixel_size: float = 4.0
## Radius breathing (torchlight), as a fraction of the radius.
@export_range(0.0, 0.3, 0.005) var breathe: float = 0.03
@export_range(0.05, 6.0, 0.05) var breathe_speed: float = 1.0
@export_group("Reveal")
## REVEAL: every node in this group gets its own hole (up to 8; a LanternLight uses 85% of its radius,
## anything else its "lantern_reveal_radius" metadata or this shade's radius).
@export var reveal_group: String = "lantern_reveal"
@export_group("Fog of war")
## World rectangle the fog covers, cell size in world pixels, and how bright remembered ground stays (0..1).
@export var fog_rect: Rect2 = Rect2(-640, -360, 1280, 720)
@export_range(2.0, 128.0, 1.0) var fog_cell: float = 16.0
@export_range(0.0, 1.0, 0.01) var fog_memory: float = 0.5
@export_group("")
## CanvasLayer index (keep it under your UI).
@export var layer: int = 5
@export var seed: int = 1
## Seconds into the motion that csaf_preview() shows.
@export var preview_time: float = 2.0

var _t := 0.0
var _layer: CanvasLayer
var _rect: ColorRect
var _mat: ShaderMaterial
var _fog: Image
var _fog_tex: ImageTexture
var _fog_dirty := false
var _last := Vector2.INF
var _face := Vector2.RIGHT


func _ready() -> void:
	_face = facing.normalized() if facing.length() > 0.0 else Vector2.RIGHT
	_layer = CanvasLayer.new()
	_layer.layer = layer
	add_child(_layer, false, Node.INTERNAL_MODE_BACK)
	var bb := BackBufferCopy.new()
	bb.copy_mode = BackBufferCopy.COPY_MODE_VIEWPORT
	_layer.add_child(bb)
	_rect = ColorRect.new()
	_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_mat = ShaderMaterial.new()
	_mat.shader = SHADER
	_rect.material = _mat
	_layer.add_child(_rect)
	var cells := Vector2i(maxi(1, ceili(fog_rect.size.x / fog_cell)), maxi(1, ceili(fog_rect.size.y / fog_cell)))
	_fog = Image.create(cells.x, cells.y, false, Image.FORMAT_R8)
	_fog_tex = ImageTexture.create_from_image(_fog)
	_update()


func _process(delta: float) -> void:
	_t += delta
	_update()


func seek(t: float) -> void:
	_t = t
	_update()


func csaf_preview() -> void:
	seek(preview_time)


## The node being followed.
func get_target() -> Node2D:
	if not target.is_empty():
		return get_node_or_null(target) as Node2D
	return get_parent() as Node2D


## Mark every fog cell within sight of each world point as explored (a walked path, or a save being restored).
func reveal_path(points: PackedVector2Array) -> void:
	for p in points:
		_reveal(p)
	_flush_fog()


## The explored cells (white = seen). Save it with your game; give it back with set_fog_image().
func get_fog_image() -> Image:
	return _fog.duplicate() as Image


func set_fog_image(img: Image) -> void:
	if img != null and img.get_size() == _fog.get_size():
		_fog = img.duplicate() as Image
		_fog.convert(Image.FORMAT_R8)
		_fog_dirty = true
		_flush_fog()


## Forget everything explored.
func clear_fog() -> void:
	_fog.fill(Color(0, 0, 0))
	_fog_dirty = true
	_flush_fog()


func _reveal(world: Vector2) -> void:
	var rr := radius * 0.9
	var c0 := Vector2i(floori((world.x - rr - fog_rect.position.x) / fog_cell), floori((world.y - rr - fog_rect.position.y) / fog_cell))
	var c1 := Vector2i(floori((world.x + rr - fog_rect.position.x) / fog_cell), floori((world.y + rr - fog_rect.position.y) / fog_cell))
	for y in range(maxi(0, c0.y), mini(_fog.get_height(), c1.y + 1)):
		for x in range(maxi(0, c0.x), mini(_fog.get_width(), c1.x + 1)):
			var centre := fog_rect.position + (Vector2(x, y) + Vector2(0.5, 0.5)) * fog_cell
			if centre.distance_to(world) <= rr and _fog.get_pixel(x, y).r < 0.5:
				_fog.set_pixel(x, y, Color(1, 1, 1))
				_fog_dirty = true


func _flush_fog() -> void:
	if _fog_dirty and _fog_tex != null:
		_fog_tex.update(_fog)
		_fog_dirty = false


func _update() -> void:
	if _mat == null:
		return
	var tgt := get_target()
	var world := global_position
	if tgt != null and tgt != self:
		world = tgt.global_position
		if tgt != get_parent():
			global_position = world
	var vp := get_viewport()
	var xf := get_global_transform_with_canvas() if tgt == null else tgt.get_global_transform_with_canvas()
	var canvas := vp.get_canvas_transform() if vp != null else Transform2D.IDENTITY
	var zoom := canvas.get_scale().x
	if auto_face and _last != Vector2.INF and world.distance_to(_last) > 0.4:
		_face = _face.lerp((world - _last).normalized(), 0.25).normalized()
	elif not auto_face:
		_face = facing.normalized() if facing.length() > 0.0 else Vector2.RIGHT
	_last = world
	if kind == Kind.CONE:
		# a carried beam (any LanternLight child) points where the cone points
		for c in get_children():
			if c is LanternLight:
				(c as LanternLight).rotation = _face.angle()
	if kind == Kind.FOG_OF_WAR:
		_reveal(world)
		_flush_fog()
	var holes: Array[Vector3] = []
	if kind == Kind.REVEAL:
		for n in get_tree().get_nodes_in_group(reveal_group):
			if holes.size() >= 8 or not (n is Node2D) or not (n as Node2D).is_visible_in_tree():
				continue
			var hr := radius
			if n is LanternLight:
				hr = (n as LanternLight).radius * 0.85
			elif n.has_meta("lantern_reveal_radius"):
				hr = float(n.get_meta("lantern_reveal_radius"))
			var hp := (n as Node2D).get_global_transform_with_canvas().origin
			holes.append(Vector3(hp.x, hp.y, hr * zoom))
	var hole_count := holes.size()
	var packed := PackedVector3Array(holes)
	while packed.size() < 8:
		packed.append(Vector3(-99999.0, -99999.0, 0.0))
	var pulse := 1.0 + breathe * (LanternUtil.fbm1(_t * 3.0 * breathe_speed, seed) - 0.5) * 2.0
	_mat.set_shader_parameter("kind", int(kind))
	_mat.set_shader_parameter("screen_px", vp.get_visible_rect().size if vp != null else Vector2(1280, 720))
	_mat.set_shader_parameter("target_px", xf.origin)
	_mat.set_shader_parameter("radius_px", radius * zoom)
	_mat.set_shader_parameter("softness", softness)
	_mat.set_shader_parameter("darkness", darkness)
	_mat.set_shader_parameter("rim", rim_color)
	_mat.set_shader_parameter("facing", _face)
	_mat.set_shader_parameter("cone_degrees", cone_degrees)
	_mat.set_shader_parameter("pixel_size", pixel_size * zoom)
	_mat.set_shader_parameter("t", _t)
	_mat.set_shader_parameter("pulse", pulse)
	_mat.set_shader_parameter("seed", float(seed % 89) * 1.7)
	_mat.set_shader_parameter("hole_count", hole_count)
	_mat.set_shader_parameter("holes", packed)
	_mat.set_shader_parameter("fog_tex", _fog_tex)
	_mat.set_shader_parameter("fog_origin_px", canvas * fog_rect.position)
	_mat.set_shader_parameter("fog_cell_px", Vector2(fog_cell, fog_cell) * zoom)
	_mat.set_shader_parameter("fog_cells", Vector2(_fog.get_width(), _fog.get_height()))
	_mat.set_shader_parameter("memory", fog_memory)
