class_name LanternUtil
extends RefCounted
## Small deterministic helpers shared by every Lantern node: hashes, 1D value noise, and the scene's ambient colour
## (so an emissive source can stay bright under a CanvasModulate night).
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.


## A repeatable pseudo-random number in [0, 1) for an integer and a seed.
static func hash1(i: int, seed: int = 0) -> float:
	var h := (i * 374761393 + seed * 668265263) & 0x7fffffff
	h = ((h ^ (h >> 13)) * 1274126177) & 0x7fffffff
	h = h ^ (h >> 16)
	return float(h & 0xffff) / 65536.0


## Smooth 1D value noise in [0, 1].
static func noise1(x: float, seed: int = 0) -> float:
	var i := int(floorf(x))
	var f := x - floorf(x)
	var u := f * f * (3.0 - 2.0 * f)
	return lerpf(hash1(i, seed), hash1(i + 1, seed), u)


## Two octaves of noise1, in [0, 1].
static func fbm1(x: float, seed: int = 0) -> float:
	return noise1(x, seed) * 0.65 + noise1(x * 2.7 + 13.1, seed + 7) * 0.35


## The ambient colour the canvas of `node` is multiplied by: the active LanternSky's ambient if one is in the tree,
## else the first visible CanvasModulate found, else white. Cached per frame by the caller.
static func ambient_for(node: Node) -> Color:
	if node == null or not node.is_inside_tree():
		return Color.WHITE
	var tree := node.get_tree()
	for s in tree.get_nodes_in_group("lantern_sky"):
		if s.has_method("get_ambient") and s.is_inside_tree():
			return s.call("get_ambient")
	var stack: Array[Node] = [tree.current_scene if tree.current_scene != null else tree.root]
	while not stack.is_empty():
		var n: Node = stack.pop_back()
		if n is CanvasModulate and (n as CanvasModulate).visible:
			return (n as CanvasModulate).color
		for c in n.get_children():
			stack.append(c)
	return Color.WHITE


## 1 / ambient per channel, clamped, so `COLOR * comp` under a CanvasModulate of `ambient` reads as the intended colour.
static func compensation(ambient: Color) -> Color:
	return Color(1.0 / maxf(ambient.r, 0.08), 1.0 / maxf(ambient.g, 0.08), 1.0 / maxf(ambient.b, 0.08), 1.0)
