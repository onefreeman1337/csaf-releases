@tool
class_name LanternCookie
extends Resource
## A light SHAPE, generated at runtime (never a shipped image): window panes, an arched chapel window, a rose window,
## leaded lancet glass, blinds, bars, leaf dapple, a paper lattice, a pierced tin lantern, a door left ajar, a grate,
## a lantern cage, a beam cone or a soft flame pool. `make_texture()` paints it into an ImageTexture once per recipe and
## caches it, so forty lights sharing one recipe cost one texture.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

enum Shape { SOFT, PANES, ARCH, ROSE, LANCET, SLATS, BARS, LEAVES, LATTICE, PIERCED, CRACK, GRATE, CAGE, CONE }
## RADIAL: the pool fades out from the centre (a lamp). THROW: the shape is thrown downward from the light's position,
## widening and fading with distance (light from a window falling across the ground).
enum Fade { RADIAL, THROW }

@export var shape: Shape = Shape.PANES:
	set(v): shape = v; emit_changed()
@export var fade: Fade = Fade.RADIAL:
	set(v): fade = v; emit_changed()
## Panes across / bars / petals / rings of holes, depending on the shape.
@export_range(1, 16) var columns: int = 2:
	set(v): columns = v; emit_changed()
## Panes down / slats / rings, depending on the shape.
@export_range(1, 16) var rows: int = 2:
	set(v): rows = v; emit_changed()
## Width of a mullion, bar, lead line or slat gap, as a fraction of one cell.
@export_range(0.0, 0.6) var bar: float = 0.12:
	set(v): bar = v; emit_changed()
## Blur of the shape's edges (0 = razor sharp, 1 = very soft).
@export_range(0.0, 1.0) var softness: float = 0.25:
	set(v): softness = v; emit_changed()
## Exponent of the fade: higher = the pool dies off sooner.
@export_range(0.2, 4.0) var falloff: float = 1.4:
	set(v): falloff = v; emit_changed()
## Throw only: the pool leans sideways as it falls (light entering at an angle).
@export_range(-1.0, 1.0) var shear: float = 0.0:
	set(v): shear = v; emit_changed()
## Width of the window inside the texture relative to its height (0.5 = a tall narrow window).
@export_range(0.2, 1.0) var aspect: float = 0.8:
	set(v): aspect = v; emit_changed()
## Stained glass colours, picked per pane by a seeded hash. Empty = clear glass (white light, tinted by the light colour).
@export var glass: PackedColorArray = PackedColorArray():
	set(v): glass = v; emit_changed()
## Opening of a CONE or CRACK, in degrees.
@export_range(2.0, 180.0) var cone_degrees: float = 40.0:
	set(v): cone_degrees = v; emit_changed()
## Radial only: height of the pool relative to its width (0.4 = a wide flat pool under a long tube).
@export_range(0.1, 1.0) var squash: float = 1.0:
	set(v): squash = v; emit_changed()
## Seed for leaf gaps, glass colours and paper grain.
@export var seed: int = 1:
	set(v): seed = v; emit_changed()
## Texture size in pixels (the light's radius scales it; 256 is plenty for pixel-art games).
@export_range(64, 512, 32) var size: int = 256:
	set(v): size = v; emit_changed()

static var _cache: Dictionary = {}
static var _pending: Dictionary = {}


## The texture for this recipe, generated on first use and cached by recipe.
func make_texture() -> ImageTexture:
	var key := _key()
	if _cache.has(key):
		var t: ImageTexture = _cache[key]
		return t
	var tex := ImageTexture.create_from_image(make_image())
	_cache[key] = tex
	return tex


## The texture if this recipe is already painted; otherwise null, and the recipe is painted on a worker thread and
## `done` is called with the texture on the main thread when it is ready (a LanternLight shows a soft placeholder
## meanwhile). Lights sharing a recipe share one paint.
func request_texture(done: Callable) -> ImageTexture:
	var key := _key()
	if _cache.has(key):
		var t: ImageTexture = _cache[key]
		return t
	if _pending.has(key):
		(_pending[key]["waiting"] as Array).append(done)
		return null
	var entry := {"waiting": [done], "task": -1}
	_pending[key] = entry
	var snapshot := duplicate() as LanternCookie   # the worker reads its own copy; the inspector may edit this one
	entry["task"] = WorkerThreadPool.add_task(_paint_on_worker.bind(snapshot, key), false, "Lantern cookie")
	return null


## How many recipes are being painted on worker threads right now (0 = every requested shape is in place).
static func painting_count() -> int:
	return _pending.size()


## True while a recipe is being painted on a worker thread.
func is_painting() -> bool:
	return _pending.has(_key())


## Paint every recipe in `cookies` now (synchronously), so no light waits for its shape later. Call it while a level
## loads. Returns the number of recipes that were painted (already cached ones are skipped).
static func prewarm(cookies: Array) -> int:
	var n := 0
	for c in cookies:
		var ck := c as LanternCookie
		if ck != null and not _cache.has(ck._key()):
			ck.make_texture()
			n += 1
	return n


## Forget every cached cookie texture (call after editing recipes in bulk at runtime).
static func clear_cache() -> void:
	_cache.clear()


static func _paint_on_worker(ck: LanternCookie, key: String) -> void:
	var img := ck.make_image()
	(func() -> void: LanternCookie._finish_paint(key, img)).call_deferred()


static func _finish_paint(key: String, img: Image) -> void:
	var tex: ImageTexture
	if _cache.has(key):
		tex = _cache[key]
	else:
		tex = ImageTexture.create_from_image(img)
		_cache[key] = tex
	var entry: Dictionary = _pending.get(key, {})
	_pending.erase(key)
	var task: int = entry.get("task", -1)
	if task >= 0:
		WorkerThreadPool.wait_for_task_completion(task)   # the task has already returned its image; this releases it
	var waiting: Array = entry.get("waiting", [])
	for cb in waiting:
		var c := cb as Callable
		if c.is_valid():
			c.call(tex)


func _key() -> String:
	return "%d|%d|%d|%d|%.3f|%.3f|%.3f|%.3f|%.3f|%.3f|%s|%.2f|%d|%d" % [shape, fade, columns, rows, bar, softness, falloff, shear, aspect, squash, str(glass), cone_degrees, seed, size]


## Paint the cookie into an RGBA8 Image (white/stained light on black, alpha 1).
## Clear glass is painted in ONE channel (a third of the work); the fade is computed first and the shape only where
## the fade can show it. Safe to call from a worker thread (it reads only this resource).
func make_image() -> Image:
	var n := size
	var count := n * n
	var mono := glass.is_empty()
	var fa := PackedFloat32Array()
	var r := PackedFloat32Array()
	var g := PackedFloat32Array()
	var b := PackedFloat32Array()
	fa.resize(count)
	r.resize(count)
	if not mono:
		g.resize(count)
		b.resize(count)
	var leaves := _leaf_blobs() if shape == Shape.LEAVES else PackedVector3Array()
	var inv := 2.0 / n
	for y in n:
		var py := (y + 0.5) * inv - 1.0
		var row := y * n
		for x in n:
			var p := Vector2((x + 0.5) * inv - 1.0, py)
			var f := _fade_at(p)
			fa[row + x] = f
			if f <= 0.0005:
				continue
			var c := _shade_at(p)
			r[row + x] = c.r
			if not mono:
				g[row + x] = c.g
				b[row + x] = c.b
	if shape == Shape.LEAVES:
		_stamp_leaves(leaves, r, g, b, n, mono)
	var rad := int(round(softness * n / 24.0))
	if rad > 0:
		_blur(r, n, rad)
		if not mono:
			_blur(g, n, rad)
			_blur(b, n, rad)
	var bytes := PackedByteArray()
	bytes.resize(count * 4)
	for i in count:
		var f := fa[i]
		var vr := int(clampf(r[i] * f, 0.0, 1.0) * 255.0)
		bytes[i * 4] = vr
		bytes[i * 4 + 1] = vr if mono else int(clampf(g[i] * f, 0.0, 1.0) * 255.0)
		bytes[i * 4 + 2] = vr if mono else int(clampf(b[i] * f, 0.0, 1.0) * 255.0)
		bytes[i * 4 + 3] = 255
	return Image.create_from_data(n, n, false, Image.FORMAT_RGBA8, bytes)


# --- fades -------------------------------------------------------------------------------------------------------

func _throw_uv(p: Vector2) -> Vector2:
	# window space for a THROW cookie: v 0 at the light (top of the texture's lower half region) .. 1 far end
	var v := (p.y + 0.92) / 1.84
	var w := 0.9 * aspect * (1.0 + 0.3 * v)
	var u := (p.x - shear * v * 0.9) / w
	return Vector2(u * 0.5 + 0.5, v)


func _fade_at(p: Vector2) -> float:
	var edge := 1.0 - smoothstep(0.9, 1.0, maxf(absf(p.x), absf(p.y)))
	if fade == Fade.THROW:
		var q := _throw_uv(p)
		if q.y < 0.0 or q.y > 1.0:
			return 0.0
		return pow(1.0 - q.y, falloff) * smoothstep(0.0, 0.06, q.y) * edge
	var d := Vector2(p.x, p.y / squash).length()
	var f := clampf(1.0 - d, 0.0, 1.0)
	return pow(f, falloff) * edge


# --- shapes ------------------------------------------------------------------------------------------------------

func _unit(p: Vector2) -> Vector2:
	# the shape's own unit square: thrown, or centred and aspect-fitted in a radial cookie
	# a THROW cookie is a window seen from inside: the sill lands next to the wall, the top of the window farthest out
	if fade == Fade.THROW:
		var q := _throw_uv(p)
		return Vector2(q.x, 1.0 - q.y)
	return Vector2(p.x / (0.78 * aspect) * 0.5 + 0.5, p.y / 0.78 * 0.5 + 0.5)


func _glass(cell: int) -> Color:
	if glass.is_empty():
		return Color.WHITE
	return glass[int(LanternUtil.hash1(cell, seed) * glass.size()) % glass.size()]


func _bars(u: float, cells: int, w: float) -> float:
	var c := fposmod(u * cells, 1.0)
	return 1.0 if (c > w * 0.5 and c < 1.0 - w * 0.5) else 0.0


func _inside(u: Vector2) -> bool:
	return u.x >= 0.0 and u.x <= 1.0 and u.y >= 0.0 and u.y <= 1.0


func _shade_at(p: Vector2) -> Color:
	match shape:
		Shape.PANES:
			var u := _unit(p)
			if not _inside(u):
				return Color.BLACK
			var m := _bars(u.x, columns, bar) * _bars(u.y, rows, bar)
			var cell := int(u.x * columns) + int(u.y * rows) * 17
			return _glass(cell) * m
		Shape.LEAVES:
			return Color.WHITE * 0.06   # the gaps are stamped after this pass (_stamp_leaves)
		Shape.CRACK:
			var a := atan2(p.x, p.y)
			var half := deg_to_rad(cone_degrees) * 0.5
			var edge := 1.0 - smoothstep(half * 0.7, half, absf(a))
			var core := 1.0 - smoothstep(half * 0.12, half * 0.5, absf(a))
			return Color.WHITE * clampf(edge * 0.75 + core * 0.5, 0.0, 1.0) * (1.0 if p.y > -0.05 else 0.0)
	# SOFT: a warm-cored pool with a faint bounce ring and a little grain, not the engine's flat gradient
	var d := p.length()
	var bounce := 0.1 * exp(-pow((d - 0.62) / 0.1, 2.0))
	var grain := 0.94 + 0.06 * LanternUtil.noise1(atan2(p.y, p.x) * 6.0 + d * 3.0, seed)
	return Color.WHITE * clampf((1.0 + bounce) * grain, 0.0, 1.0)


func _leaf_blobs() -> PackedVector3Array:
	var out := PackedVector3Array()
	var count := columns * rows * 2 + 8
	for i in count:
		var x := LanternUtil.hash1(i * 3, seed) * 1.6 - 0.8
		var y := LanternUtil.hash1(i * 3 + 1, seed) * 1.6 - 0.8
		var rr := 0.05 + 0.1 * pow(LanternUtil.hash1(i * 3 + 2, seed), 1.4)
		out.append(Vector3(x, y, rr))
	return out


## Leaf gaps: each blob only touches the pixels of its own bounding box (a per-pixel loop over every blob is ~5 M steps).
## Each gap is a lobed, tilted ellipse (a hole between leaves), never a clean disc.
static func _stamp_leaves(blobs: PackedVector3Array, r: PackedFloat32Array, g: PackedFloat32Array, b: PackedFloat32Array, n: int, mono: bool) -> void:
	var k := 0
	for bl in blobs:
		k += 1
		var ang := LanternUtil.hash1(k * 5, 91) * TAU
		var elong := 0.55 + 0.45 * LanternUtil.hash1(k * 5 + 1, 91)
		var ph1 := LanternUtil.hash1(k * 5 + 2, 91) * TAU
		var ph2 := LanternUtil.hash1(k * 5 + 3, 91) * TAU
		var ca := cos(ang)
		var sa := sin(ang)
		var cx := (bl.x * 0.5 + 0.5) * n
		var cy := (bl.y * 0.5 + 0.5) * n
		var ext := bl.z * 0.5 * n * 1.4
		for y in range(maxi(0, int(cy - ext) - 1), mini(n, int(cy + ext) + 2)):
			for x in range(maxi(0, int(cx - ext) - 1), mini(n, int(cx + ext) + 2)):
				var dx := (x + 0.5 - cx) / n * 2.0
				var dy := (y + 0.5 - cy) / n * 2.0
				var u := dx * ca + dy * sa
				var v := (-dx * sa + dy * ca) / elong
				var th := atan2(v, u)
				var lobe := 1.0 + 0.22 * sin(3.0 * th + ph1) + 0.12 * sin(5.0 * th + ph2)
				var t := 1.0 - smoothstep(bl.z * 0.5 * lobe, bl.z * lobe, sqrt(u * u + v * v))
				if t <= 0.0:
					continue
				var i := y * n + x
				r[i] = minf(1.0, r[i] + t)
				if not mono:
					g[i] = minf(1.0, g[i] + t)
					b[i] = minf(1.0, b[i] + t)


static func _blur(a: PackedFloat32Array, n: int, rad: int) -> void:
	var tmp := PackedFloat32Array()
	tmp.resize(a.size())
	var w := float(rad * 2 + 1)
	for y in n:
		var acc := 0.0
		var row := y * n
		for k in range(-rad, rad + 1):
			acc += a[row + clampi(k, 0, n - 1)]
		for x in n:
			tmp[row + x] = acc / w
			acc += a[row + clampi(x + rad + 1, 0, n - 1)] - a[row + clampi(x - rad, 0, n - 1)]
	for x in n:
		var acc := 0.0
		for k in range(-rad, rad + 1):
			acc += tmp[clampi(k, 0, n - 1) * n + x]
		for y in n:
			a[y * n + x] = acc / w
			acc += tmp[clampi(y + rad + 1, 0, n - 1) * n + x] - tmp[clampi(y - rad, 0, n - 1) * n + x]
