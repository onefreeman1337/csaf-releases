@tool
class_name LanternSource
extends Node2D
## The thing that GIVES the light, drawn in code at pixel-art scale: a candle, a wall torch, a campfire with rising
## embers, a hanging oil lantern, a hearth, a street lamp, a neon sign, a fluorescent tube, a warning beacon, a
## searchlight, a floating orb, or a swarm of fireflies (each with its own small light). Put it under a LanternLight:
## it pulses with that light's flicker. The glowing parts are emissive (they ignore the night); the wood, iron and
## stone are lit like everything else in your scene.
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

enum Kind { NONE, CANDLE, TORCH, CAMPFIRE, LANTERN, HEARTH, STREET_LAMP, NEON, TUBE, BEACON, SEARCHLIGHT, ORB, FIREFLIES, TIN }
enum Glyph { STAR, MOON, ARROW, HEART, CUP, BOLT }

const SHADER := preload("res://addons/lantern/shaders/lantern_source.gdshader")

@export var kind: Kind = Kind.CANDLE:
	set(v): kind = v; _rebuild_flies(); _redraw()
@export var flame_core: Color = Color(1.0, 0.96, 0.72):
	set(v): flame_core = v; _push()
@export var flame_mid: Color = Color(1.0, 0.62, 0.16):
	set(v): flame_mid = v; _push()
@export var flame_edge: Color = Color(0.78, 0.16, 0.04):
	set(v): flame_edge = v; _push()
## Neon, tube, lamp glass, beacon, orb and firefly colour.
@export var glow_color: Color = Color(1.0, 0.35, 0.75):
	set(v): glow_color = v; _redraw()
## Wood / iron / stone colour of the fixture (lit by your lights like the rest of the scene).
@export var body_color: Color = Color(0.36, 0.26, 0.2):
	set(v): body_color = v; _redraw()
## The neon sign's picture.
@export var glyph: Glyph = Glyph.STAR:
	set(v): glyph = v; _redraw()
## Fireflies in the swarm / embers above a campfire.
@export_range(0, 48) var count: int = 12:
	set(v): count = v; _rebuild_flies(); _redraw()
## Firefly wander radius in pixels.
@export_range(4.0, 400.0) var spread: float = 60.0
## Overall size multiplier (1 = sized for 16 px tiles).
@export_range(0.25, 8.0, 0.05) var size_scale: float = 1.0:
	set(v): size_scale = v; _redraw()
@export var seed: int = 1:
	set(v): seed = v; _push()

var _t := 0.0
var _seeked := false
var _body: _Layer
var _glow: _Layer
var _mat: ShaderMaterial
var _flies: Array[PointLight2D] = []
var _comp_timer := 0.0
static var _white: ImageTexture


func _ready() -> void:
	if _white == null:
		var img := Image.create(4, 4, false, Image.FORMAT_RGBA8)
		img.fill(Color.WHITE)
		_white = ImageTexture.create_from_image(img)
	_body = _Layer.new()
	_body.src = self
	_body.glow = false
	add_child(_body, false, Node.INTERNAL_MODE_FRONT)
	_glow = _Layer.new()
	_glow.src = self
	_glow.glow = true
	_mat = ShaderMaterial.new()
	_mat.shader = SHADER
	_glow.material = _mat
	add_child(_glow, false, Node.INTERNAL_MODE_BACK)
	_rebuild_flies()
	_push()
	_update_comp()


func _process(delta: float) -> void:
	_t += delta
	_comp_timer -= delta
	if _comp_timer <= 0.0:
		_comp_timer = 0.25
		_update_comp()
	_push()
	_redraw()


## Jump to `t` seconds (the parent LanternLight calls this from csaf_preview()).
func seek(t: float) -> void:
	_t = t
	_update_comp()
	_push()
	_redraw()


func _time() -> float:
	var p := get_parent()
	if p is LanternLight:
		return (p as LanternLight).get_time()
	return _t


func _level() -> float:
	var p := get_parent()
	if p is LanternLight:
		var l := p as LanternLight
		if l.intensity <= 0.0:
			return 0.0
		return clampf(l.get_level(), 0.0, 1.6)
	return 1.0


func _update_comp() -> void:
	if _mat != null and is_inside_tree():
		_mat.set_shader_parameter("comp", LanternUtil.compensation(LanternUtil.ambient_for(self)))


func _push() -> void:
	if _mat == null:
		return
	_mat.set_shader_parameter("t", _time())
	_mat.set_shader_parameter("level", _level())
	_mat.set_shader_parameter("seed", float(seed % 97) * 1.37)
	_mat.set_shader_parameter("flame_core", flame_core)
	_mat.set_shader_parameter("flame_mid", flame_mid)
	_mat.set_shader_parameter("flame_edge", flame_edge)
	if kind == Kind.FIREFLIES:
		_move_flies()


func _redraw() -> void:
	if _body != null:
		_body.queue_redraw()
		_glow.queue_redraw()


# --- fireflies: each one is a real small PointLight2D -------------------------------------------------------------

func _rebuild_flies() -> void:
	for f in _flies:
		f.queue_free()
	_flies.clear()
	if kind != Kind.FIREFLIES or not is_inside_tree():
		return


func fly_position(i: int, t: float) -> Vector2:
	var s := seed * 131 + i * 17
	var home := Vector2(LanternUtil.hash1(i * 2, seed) - 0.5, LanternUtil.hash1(i * 2 + 1, seed) - 0.5) * spread * 1.6
	var wander := Vector2(LanternUtil.fbm1(t * 0.35 + i * 7.1, s) - 0.5, LanternUtil.fbm1(t * 0.31 + i * 3.3, s + 50) - 0.5)
	return home + wander * spread * 0.9


func fly_blink(i: int, t: float) -> float:
	return clampf(sin(t * 1.9 + LanternUtil.hash1(i, seed + 3) * TAU) * 1.7 - 0.25, 0.0, 1.0)


func _move_flies() -> void:
	var t := _time()
	var lv := _level()
	for i in _flies.size():
		_flies[i].position = fly_position(i, t)
		_flies[i].energy = 1.7 * fly_blink(i, t) * lv
		_flies[i].color = glow_color


# --- drawing ------------------------------------------------------------------------------------------------------

func _px(c: CanvasItem, x: float, y: float, w: float, h: float, col: Color) -> void:
	var s := size_scale
	c.draw_rect(Rect2(round(x * s), round(y * s), maxf(1.0, round(w * s)), maxf(1.0, round(h * s))), col)


## A flame quad: the vertex colour carries its texel size (so the shader can snap) and mode 0.1.
func _flame(c: CanvasItem, cx: float, bottom: float, w: float, h: float) -> void:
	var s := size_scale
	var rw := maxf(2.0, round(w * s))
	var rh := maxf(2.0, round(h * s))
	c.draw_texture_rect(_white, Rect2(round(cx * s - rw * 0.5), round(bottom * s - rh), rw, rh), false, Color(rw / 64.0, rh / 64.0, 0.0, 0.1))


func _disc(c: CanvasItem, p: Vector2, r: float, col: Color) -> void:
	var s := size_scale
	var rr := r * s
	c.draw_texture_rect(_white, Rect2(p * s - Vector2(rr, rr), Vector2(rr, rr) * 2.0), false, Color(col.r, col.g, col.b, 0.3))


func _tube(c: CanvasItem, a: Vector2, b: Vector2, w: float, col: Color) -> void:
	var s := size_scale
	var d := (b - a) * s
	var ln := d.length()
	if ln < 0.01:
		return
	c.draw_set_transform(a * s, d.angle(), Vector2.ONE)
	c.draw_texture_rect(_white, Rect2(0.0, -w * s * 0.5, ln, w * s), false, Color(col.r, col.g, col.b, 0.5))
	c.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _solid(c: CanvasItem, x: float, y: float, w: float, h: float, col: Color) -> void:
	var s := size_scale
	c.draw_texture_rect(_white, Rect2(round(x * s), round(y * s), maxf(1.0, round(w * s)), maxf(1.0, round(h * s))), false, Color(col.r, col.g, col.b, 0.7))


func _shade(col: Color, k: float) -> Color:
	return Color(col.r * k, col.g * k, col.b * k, 1.0)


func _draw_layer(c: CanvasItem, glow: bool) -> void:
	var t := _time()
	var bc := body_color
	var dark := _shade(bc, 0.6)
	match kind:
		Kind.CANDLE:
			if glow:
				_flame(c, 0.0, -7.0, 5.0, 9.0)
			else:
				_px(c, -4, -1, 8, 2, Color(0.42, 0.38, 0.36))
				_px(c, -1.5, -7, 3, 6, Color(0.92, 0.86, 0.72))
				_px(c, 0.5, -7, 1, 6, Color(0.74, 0.66, 0.52))
		Kind.TORCH:
			if glow:
				_flame(c, 0.0, -9.0, 8.0, 14.0)
			else:
				_px(c, -1, -10, 2, 9, bc)
				_px(c, 0, -10, 1, 9, dark)
				_px(c, -2, -4, 4, 2, Color(0.22, 0.22, 0.24))
				_px(c, -2, -11, 4, 2, Color(0.3, 0.3, 0.32))
		Kind.STREET_LAMP:
			if glow:
				_solid(c, -3, -25, 6, 4, glow_color)
				_disc(c, Vector2(0, -23), 8.0, glow_color)
			else:
				_px(c, -1, -21, 2, 21, Color(0.16, 0.17, 0.2))
				_px(c, -3, -2, 6, 2, Color(0.2, 0.21, 0.24))
				_px(c, -4, -27, 8, 2, Color(0.2, 0.21, 0.24))
				_px(c, -4, -21, 8, 1, Color(0.2, 0.21, 0.24))
func _glyph_lines() -> PackedVector2Array:
	var out := PackedVector2Array()
	match glyph:
		Glyph.STAR:
			var pts: Array[Vector2] = []
			for i in 5:
				var a := -PI * 0.5 + TAU * i * 2.0 / 5.0
				pts.append(Vector2(cos(a), sin(a)) * 11.0)
			for i in 5:
				out.append(pts[i])
				out.append(pts[(i + 1) % 5])
		Glyph.MOON:
			_arc(out, Vector2.ZERO, 11.0, PI * 0.35, PI * 1.65, 10)
			_arc(out, Vector2(5, 0), 8.5, PI * 0.5, PI * 1.5, 8)
		Glyph.ARROW:
			out.append_array(PackedVector2Array([Vector2(-12, 0), Vector2(10, 0), Vector2(10, 0), Vector2(3, -7), Vector2(10, 0), Vector2(3, 7)]))
		Glyph.HEART:
			_arc(out, Vector2(-5, -3), 5.5, PI, TAU, 6)
			_arc(out, Vector2(5, -3), 5.5, PI, TAU, 6)
			out.append_array(PackedVector2Array([Vector2(-10.5, -3), Vector2(0, 10), Vector2(10.5, -3), Vector2(0, 10)]))
		Glyph.CUP:
			out.append_array(PackedVector2Array([Vector2(-10, -9), Vector2(10, -9), Vector2(-10, -9), Vector2(0, 2), Vector2(10, -9), Vector2(0, 2)]))
			out.append_array(PackedVector2Array([Vector2(0, 2), Vector2(0, 9), Vector2(-5, 9), Vector2(5, 9), Vector2(3, -6), Vector2(4, -5)]))
		Glyph.BOLT:
			out.append_array(PackedVector2Array([Vector2(4, -12), Vector2(-4, 1), Vector2(-4, 1), Vector2(3, 1), Vector2(3, 1), Vector2(-4, 12)]))
	return out


func _arc(out: PackedVector2Array, c: Vector2, r: float, a0: float, a1: float, n: int) -> void:
	for i in n:
		var a := lerpf(a0, a1, float(i) / n)
		var b := lerpf(a0, a1, float(i + 1) / n)
		out.append(c + Vector2(cos(a), sin(a)) * r)
		out.append(c + Vector2(cos(b), sin(b)) * r)


class _Layer extends Node2D:
	var src: LanternSource
	var glow := false

	func _draw() -> void:
		if src != null:
			src._draw_layer(self, glow)
