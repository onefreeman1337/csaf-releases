class_name LanternClock
extends Node
## Runs a day: walks a LanternSky through a list of looks pinned to hours, blending between neighbours, so dawn
## becomes morning becomes noon and the follow_night lights come on at dusk by themselves.
##   clock.hour = 18.5        # jump
##   clock.day_seconds = 240  # one full day every four minutes
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

signal hour_changed(hour: float)

## The LanternSky this clock drives (empty = the first LanternSky in the scene).
@export var sky: NodePath
## Looks for the day, in order, each pinned to the hour in `hours` with the same index.
@export var looks: Array[LanternSkyLook] = []
@export var hours: PackedFloat32Array = PackedFloat32Array()
## Real seconds for a full 24 hours.
@export_range(5.0, 7200.0, 1.0) var day_seconds: float = 240.0
@export_range(0.0, 24.0, 0.01) var hour: float = 18.0
@export var running: bool = true

var _sky: LanternSky


func _ready() -> void:
	_resolve()
	_apply()


func _process(delta: float) -> void:
	if running:
		hour = fposmod(hour + delta * 24.0 / day_seconds, 24.0)
		hour_changed.emit(hour)
	_apply()


## The blended look for any hour (wraps around midnight).
func look_at_hour(h: float) -> LanternSkyLook:
	var n := mini(looks.size(), hours.size())
	if n == 0:
		return null
	if n == 1:
		return looks[0]
	h = fposmod(h, 24.0)
	for i in n:
		var a := hours[i]
		var b := hours[(i + 1) % n]
		var span := fposmod(b - a, 24.0)
		var into := fposmod(h - a, 24.0)
		if span > 0.0 and into <= span:
			return LanternSkyLook.mix_looks(looks[i], looks[(i + 1) % n], smoothstep(0.0, 1.0, into / span))
	return looks[0]


func _resolve() -> void:
	if not sky.is_empty():
		_sky = get_node_or_null(sky) as LanternSky
	if _sky == null:
		for s in get_tree().get_nodes_in_group("lantern_sky"):
			if s is LanternSky:
				_sky = s
				break


func _apply() -> void:
	if _sky == null:
		_resolve()
	if _sky == null:
		return
	var l := look_at_hour(hour)
	if l != null:
		_sky.set_current(l)
