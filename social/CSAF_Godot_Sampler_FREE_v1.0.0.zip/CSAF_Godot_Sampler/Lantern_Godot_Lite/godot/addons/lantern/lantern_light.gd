@tool
class_name LanternLight
extends PointLight2D
## A PointLight2D whose SHAPE is generated (a LanternCookie) and whose life is a flicker curve: candle, torch, fire,
## failing neon, a fluorescent tube that will not start, a breathing orb, a searchlight sweep, a spinning beacon, a
## swinging lantern or a wandering firefly. Drop a preset scene in, or add this node and give it a cookie.
## Colour, intensity, radius and the flicker are this node's exports; the PointLight2D texture/energy/colour/scale are
## driven from them every frame (so they are not saved into your scene).
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

enum Flicker { STEADY, CANDLE, TORCH, FIRE, NEON, STROBE, PULSE, SWEEP, SPIN, SWAY, FIREFLY }

## The light's shape. Empty = a plain soft pool.
@export var cookie: LanternCookie:
	set(v):
		if cookie != null and cookie.changed.is_connected(_rebuild):
			cookie.changed.disconnect(_rebuild)
		cookie = v
		if cookie != null and not cookie.changed.is_connected(_rebuild):
			cookie.changed.connect(_rebuild)
		_rebuild()
## Light colour (multiplies the cookie, so stained glass keeps its colours under white).
@export var light_color: Color = Color(1.0, 0.78, 0.5):
	set(v): light_color = v; _apply()
## Brightness before the flicker.
@export_range(0.0, 8.0, 0.01) var intensity: float = 1.2:
	set(v): intensity = v; _apply()
## Radius of the pool in pixels (half the cookie's width on screen).
@export_range(4.0, 2048.0, 1.0) var radius: float = 96.0:
	set(v): radius = v; _rebuild()
@export_group("Flicker")
@export var flicker: Flicker = Flicker.STEADY:
	set(v): flicker = v; _apply()
## How deep the dips go (0 = steady, 1 = all the way down).
@export_range(0.0, 1.0, 0.01) var flicker_depth: float = 0.3
## Speed multiplier of the flicker curve.
@export_range(0.05, 8.0, 0.01) var flicker_speed: float = 1.0
## Two lights with the same flicker and different seeds never pulse together.
@export var flicker_seed: int = 1
## How far the colour cools toward ember red on a dip (fires), 0..1.
@export_range(0.0, 1.0, 0.01) var ember_shift: float = 0.0
## SWEEP: total arc in degrees. SWAY: swing in degrees. FIREFLY: wander distance in pixels.
@export_range(0.0, 360.0, 0.5) var reach: float = 60.0
@export_group("Night")
## Follow the LanternSky's night: the light fades out by day and comes on at dusk (LanternSky.lights_on).
@export var follow_night: bool = false
@export_group("")
## Paint a cookie that is not cached yet on a worker thread (a soft placeholder shows for a few frames) instead of
## blocking the frame. Off = paint immediately. The editor always paints immediately.
@export var async_cookie: bool = true
## Seconds into the flicker that the editor preview and csaf_preview() show.
@export var preview_time: float = 2.0

## Emitted when the light's real shape is in place (at once if its recipe was already painted).
signal cookie_ready

var _t := 0.0
var _rest_rotation := 0.0
var _rest_position := Vector2.ZERO
var _level := 1.0
var _ready_done := false


func _ready() -> void:
	_rest_rotation = rotation
	_rest_position = position
	_ready_done = true
	_rebuild()
	if Engine.is_editor_hint():
		_t = preview_time
	_apply()


func _validate_property(property: Dictionary) -> void:
	if property.name in ["texture", "energy", "color", "texture_scale", "offset"]:
		property.usage &= ~PROPERTY_USAGE_STORAGE


func _process(delta: float) -> void:
	_t += delta
	_apply()


## Jump the flicker to `t` seconds (deterministic: the same t always draws the same frame).
func seek(t: float) -> void:
	_t = t
	_apply()


## The CSAF capture stage calls this; so can you, to freeze a preset at its showcase moment (the shape is painted
## now, synchronously, if it was still on a worker thread).
func csaf_preview() -> void:
	_rebuild(true)
	seek(preview_time)
	for c in get_children():
		if c.has_method("seek"):
			c.call("seek", preview_time)


## The flicker's current brightness factor (0..1+), for anything that should pulse with the light (LanternSource).
func get_level() -> float:
	return _level


func get_time() -> float:
	return _t


## True once the light's real shape is in place (false for the few frames a new recipe is painted on a worker thread).
func is_cookie_ready() -> bool:
	return texture != null and texture != _placeholder()


func _rebuild(sync: bool = false) -> void:
	if not _ready_done and not Engine.is_editor_hint():
		return
	var ck := cookie if cookie != null else _default_cookie()
	if sync or Engine.is_editor_hint() or not async_cookie:
		texture = ck.make_texture()
	else:
		var t := ck.request_texture(_cookie_arrived.bind(ck._key()))
		texture = t if t != null else _placeholder()
		if t != null:
			cookie_ready.emit.call_deferred()
	_apply()


func _cookie_arrived(tex: ImageTexture, key: String) -> void:
	var ck := cookie if cookie != null else _default_cookie()
	if ck._key() == key:
		texture = tex
		_apply()
		cookie_ready.emit()


static var _soft: LanternCookie
static var _ph: GradientTexture2D


## The soft radial pool a light shows while its cookie is painted (built by the engine, instant).
static func _placeholder() -> GradientTexture2D:
	if _ph == null:
		_ph = GradientTexture2D.new()
		_ph.width = 64
		_ph.height = 64
		_ph.fill = GradientTexture2D.FILL_RADIAL
		_ph.fill_from = Vector2(0.5, 0.5)
		_ph.fill_to = Vector2(1.0, 0.5)
		var g := Gradient.new()
		g.set_color(0, Color(0.9, 0.9, 0.9))
		g.set_color(1, Color(0, 0, 0))
		_ph.gradient = g
	return _ph


static func _default_cookie() -> LanternCookie:
	if _soft == null:
		_soft = LanternCookie.new()
		_soft.shape = LanternCookie.Shape.SOFT
		_soft.falloff = 1.6
	return _soft


func _apply() -> void:
	if not is_inside_tree():
		return
	var e := 1.0
	var sc := 1.0
	var rot := 0.0
	var off := Vector2.ZERO
	var s := flicker_seed
	var t := _t * flicker_speed
	var d := flicker_depth
	match flicker:
		Flicker.CANDLE:
			var n := LanternUtil.fbm1(t * 6.0, s)
			e = 1.0 - d * (0.65 * n + 0.35 * LanternUtil.noise1(t * 17.0, s + 1))
			sc = 1.0 - d * 0.12 * n
			off = Vector2(LanternUtil.noise1(t * 5.0, s + 2) - 0.5, LanternUtil.noise1(t * 4.0, s + 3) - 0.5) * 3.0 * d
		Flicker.TORCH:
			var n := LanternUtil.fbm1(t * 9.0, s)
			e = 1.0 - d * n * 1.05
			sc = 1.0 + d * 0.16 * (LanternUtil.noise1(t * 5.0, s + 1) - 0.5) * 2.0
			off = Vector2(LanternUtil.noise1(t * 7.0, s + 2) - 0.5, LanternUtil.noise1(t * 6.0, s + 3) - 0.5) * 6.0 * d
	if follow_night:
		e *= _night_level()
	_level = maxf(e, 0.0)
	energy = intensity * _level
	var c := light_color
	if ember_shift > 0.0:
		c = c.lerp(Color(c.r, c.g * 0.45, c.b * 0.25), clampf((1.0 - e) * 1.6, 0.0, 1.0) * ember_shift)
	color = c
	var ck := cookie if cookie != null else _default_cookie()
	var tex_w := float(texture.get_width()) if texture != null else float(ck.size)
	texture_scale = radius * 2.0 / tex_w * sc
	var base_off := Vector2(0.0, radius * sc * 0.92) if ck.fade == LanternCookie.Fade.THROW else Vector2.ZERO
	offset = base_off + off
	if not Engine.is_editor_hint() and _ready_done and flicker in [Flicker.SWEEP, Flicker.SPIN, Flicker.SWAY]:
		rotation = _rest_rotation + rot


func _night_level() -> float:
	for sky in get_tree().get_nodes_in_group("lantern_sky"):
		if sky.has_method("get_lights_on"):
			var v: float = sky.call("get_lights_on")
			return v
	return 1.0
