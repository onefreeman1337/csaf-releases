@tool
class_name LanternSky
extends Node2D
## The time of day for a 2D scene: drop it in once. It owns the scene's CanvasModulate (the ambient every LanternLight
## adds on top of) and, at runtime, a full-screen grade in its own CanvasLayer (sun side, shafts, clouds, aurora,
## lightning, haze). LanternLights with follow_night fade in and out with `look.lights_on`. Blend between looks with
## blend_to(), or let a LanternClock run the day.
## Only ONE LanternSky should be active per scene (it replaces any CanvasModulate you had).
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

signal look_changed(look: LanternSkyLook)

const SHADER := preload("res://addons/lantern/shaders/lantern_sky.gdshader")

@export var look: LanternSkyLook:
	set(v):
		look = v
		_current = v
		_from = null
		_apply()
## CanvasLayer index of the grade (keep it under your UI's layer so menus are not graded).
@export var grade_layer: int = 3
## Draw the full-screen grade (off = ambient colour only, the cheapest option).
@export var grade: bool = true
## Seconds into the sky's motion (clouds, shafts, lightning) shown by the editor preview and csaf_preview().
@export var preview_time: float = 2.0

var _t := 0.0
var _cm: CanvasModulate
var _layer: CanvasLayer
var _rect: ColorRect
var _mat: ShaderMaterial
var _current: LanternSkyLook
var _from: LanternSkyLook
var _to: LanternSkyLook
var _blend := 1.0
var _blend_len := 0.0


func _enter_tree() -> void:
	add_to_group("lantern_sky")


func _exit_tree() -> void:
	remove_from_group("lantern_sky")


func _ready() -> void:
	_cm = CanvasModulate.new()
	add_child(_cm, false, Node.INTERNAL_MODE_FRONT)
	if not Engine.is_editor_hint() and grade:
		_layer = CanvasLayer.new()
		_layer.layer = grade_layer
		add_child(_layer, false, Node.INTERNAL_MODE_BACK)
		var bb := BackBufferCopy.new()
		bb.copy_mode = BackBufferCopy.COPY_MODE_VIEWPORT
		_layer.add_child(bb)
		_rect = ColorRect.new()
		_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
		_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_mat = ShaderMaterial.new()
		_mat.shader = SHADER
		_rect.material = _mat
		_layer.add_child(_rect)
	if Engine.is_editor_hint():
		_t = preview_time
	_current = look
	_apply()


func _process(delta: float) -> void:
	_t += delta
	if _from != null and _to != null and _blend < 1.0:
		_blend = minf(1.0, _blend + delta / maxf(_blend_len, 0.001))
		_current = LanternSkyLook.mix_looks(_from, _to, smoothstep(0.0, 1.0, _blend))
		if _blend >= 1.0:
			_current = _to
			look = _to
			look_changed.emit(_to)
	_apply()


## Fade from the current look to `target` over `seconds`.
func blend_to(target: LanternSkyLook, seconds: float = 2.0) -> void:
	if seconds <= 0.0 or _current == null:
		look = target
		look_changed.emit(target)
		return
	_from = _current
	_to = target
	_blend = 0.0
	_blend_len = seconds


## Show an arbitrary in-between look right now (LanternClock uses this).
func set_current(l: LanternSkyLook) -> void:
	_current = l
	_apply()


func get_current() -> LanternSkyLook:
	return _current


## The ambient colour the scene is multiplied by (lightning included). LanternSource reads it to stay emissive.
func get_ambient() -> Color:
	if _current == null:
		return Color.WHITE
	var f := _flash_now()
	return _current.ambient.lerp(Color(0.9, 0.95, 1.0), clampf(f, 0.0, 1.0) * 0.45)


## How far the follow_night lights are on, 0..1.
func get_lights_on() -> float:
	return _current.lights_on if _current != null else 0.0


func seek(t: float) -> void:
	_t = t
	_apply()


## Seek to preview_time; a stormy look seeks to the peak of its first lightning strike instead.
func csaf_preview() -> void:
	if _current != null and _current.flash > 0.0:
		seek(strike_time(1) + 0.06)
	else:
		seek(preview_time)


## When strike number `k` starts, in seconds (strikes are jittered within each `flash_every` window).
func strike_time(k: int) -> float:
	var every := _current.flash_every if _current != null else 6.0
	return k * every + LanternUtil.hash1(k, 7) * every * 0.5


func _flash_now() -> float:
	if _current == null or _current.flash <= 0.0:
		return 0.0
	var every := _current.flash_every
	var k := int(floor(_t / every))
	var dt := _t - strike_time(k)
	if dt < 0.0 or dt > 0.9:
		return 0.0
	# a double flash: a bright strike, a dip, a second strike, then decay
	var a := exp(-dt * 9.0) + 0.75 * exp(-maxf(dt - 0.18, 0.0) * 7.0) * (1.0 if dt > 0.18 else 0.0)
	return _current.flash * a


func _apply() -> void:
	if _cm == null or _current == null:
		return
	_cm.color = get_ambient()
	if _mat == null:
		return
	var L := _current
	var vp := get_viewport()
	if vp != null:
		_mat.set_shader_parameter("screen_px", vp.get_visible_rect().size)
	_mat.set_shader_parameter("t", _t)
	_mat.set_shader_parameter("exposure", L.exposure)
	_mat.set_shader_parameter("contrast", L.contrast)
	_mat.set_shader_parameter("saturation", L.saturation)
	_mat.set_shader_parameter("shadow_tint", L.shadow_tint)
	_mat.set_shader_parameter("highlight_tint", L.highlight_tint)
	_mat.set_shader_parameter("sun_dir", L.sun_dir)
	_mat.set_shader_parameter("sun_strength", L.sun_strength)
	_mat.set_shader_parameter("sun_color", L.sun_color)
	_mat.set_shader_parameter("shafts", L.shafts)
	_mat.set_shader_parameter("shaft_width", L.shaft_width)
	_mat.set_shader_parameter("clouds", L.clouds)
	_mat.set_shader_parameter("cloud_scale", L.cloud_scale)
	_mat.set_shader_parameter("wind", L.wind)
	_mat.set_shader_parameter("aurora", L.aurora)
	_mat.set_shader_parameter("aurora_a", L.aurora_a)
	_mat.set_shader_parameter("aurora_b", L.aurora_b)
	_mat.set_shader_parameter("flash_now", _flash_now())
	_mat.set_shader_parameter("haze", L.haze)
	_mat.set_shader_parameter("haze_color", L.haze_color)
	_mat.set_shader_parameter("vignette", L.vignette)
