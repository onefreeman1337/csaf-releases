@tool
class_name LanternSkyLook
extends Resource
## One time of day or weather, as numbers a LanternSky turns into light: the ambient colour of the whole scene (it is a
## CanvasModulate), a colour grade (exposure, contrast, saturation, split toning), the sun's direction and warmth, light
## shafts, drifting cloud shadow, an aurora, lightning, haze and a vignette, and how far the LanternLights marked
## follow_night are switched on. Two looks blend smoothly (LanternSky.blend_to, LanternClock).
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

@export var title: String = "Look"
@export_group("Ambient")
## The CanvasModulate colour: everything in the scene is multiplied by it; your lights add on top.
@export var ambient: Color = Color(1, 1, 1)
## 0 = every follow_night light is off, 1 = fully on.
@export_range(0.0, 1.0, 0.01) var lights_on: float = 0.0
@export_group("Grade")
@export_range(0.0, 3.0, 0.01) var exposure: float = 1.0
@export_range(0.2, 2.5, 0.01) var contrast: float = 1.0
@export_range(0.0, 2.0, 0.01) var saturation: float = 1.0
## Colour pushed into the darks.
@export var shadow_tint: Color = Color(1, 1, 1)
## Colour pushed into the lights.
@export var highlight_tint: Color = Color(1, 1, 1)
@export_group("Sun")
## Screen direction the light comes FROM (normalised in the shader).
@export var sun_dir: Vector2 = Vector2(-0.6, -0.8)
## How much brighter the sun side is than the far side.
@export_range(0.0, 2.0, 0.01) var sun_strength: float = 0.0
@export var sun_color: Color = Color(1.0, 0.85, 0.6)
## Light shafts across the scene, along the sun direction.
@export_range(0.0, 1.5, 0.01) var shafts: float = 0.0
@export_range(4.0, 80.0, 0.5) var shaft_width: float = 18.0
@export_group("Weather")
## Cloud shadows drifting over the scene (0 = clear sky).
@export_range(0.0, 1.0, 0.01) var clouds: float = 0.0
@export_range(0.5, 12.0, 0.1) var cloud_scale: float = 3.0
@export var wind: Vector2 = Vector2(0.02, 0.006)
## Aurora curtains washing the scene from the top.
@export_range(0.0, 1.5, 0.01) var aurora: float = 0.0
@export var aurora_a: Color = Color(0.2, 1.0, 0.6)
@export var aurora_b: Color = Color(0.6, 0.3, 1.0)
## Lightning: strength of each flash (0 = none). Flashes come every `flash_every` seconds, jittered.
@export_range(0.0, 3.0, 0.01) var flash: float = 0.0
@export_range(1.0, 30.0, 0.1) var flash_every: float = 6.0
## Even haze over the scene (fog, smoke, dust), in haze_color.
@export_range(0.0, 1.0, 0.01) var haze: float = 0.0
@export var haze_color: Color = Color(0.7, 0.75, 0.8)
@export_range(0.0, 1.5, 0.01) var vignette: float = 0.0


const FIELDS := ["ambient", "lights_on", "exposure", "contrast", "saturation", "shadow_tint", "highlight_tint", "sun_dir",
	"sun_strength", "sun_color", "shafts", "shaft_width", "clouds", "cloud_scale", "wind", "aurora", "aurora_a", "aurora_b",
	"flash", "flash_every", "haze", "haze_color", "vignette"]


## A new look `t` of the way from `a` to `b` (every field interpolated).
static func mix_looks(a: LanternSkyLook, b: LanternSkyLook, t: float) -> LanternSkyLook:
	var out := LanternSkyLook.new()
	for f in FIELDS:
		var va: Variant = a.get(f)
		var vb: Variant = b.get(f)
		if typeof(va) == TYPE_FLOAT:
			out.set(f, lerpf(va, vb, t))
		elif typeof(va) == TYPE_COLOR:
			out.set(f, (va as Color).lerp(vb, t))
		elif typeof(va) == TYPE_VECTOR2:
			out.set(f, (va as Vector2).lerp(vb, t))
	out.title = a.title if t < 0.5 else b.title
	return out
