class_name DemoWalker
extends Node2D
## A small hooded traveller for the demo (pixel art drawn in code). Arrow keys / WASD / left stick walk it when
## `controllable` is on. Copyright (c) 2026 Core Systems Asset Factory.

const ART := [
	"....hhhh....",
	"...hHHHHh...",
	"..hHHHHHHh..",
	"..hHssssHh..",
	"..hHsEsEHh..",
	"...hssssh...",
	"..cCCCCCCc..",
	".cCCCbbCCCc.",
	".cCCCbbCCCc.",
	".sCCCCCCCCs.",
	"..cCCCCCCc..",
	"..cCCCCCCc..",
	"...pp..pp...",
	"...pp..pp...",
	"...bb..bb...",
]
const PAL := {
	"h": Color(0.22, 0.16, 0.2), "H": Color(0.42, 0.24, 0.3), "s": Color(0.94, 0.78, 0.62), "E": Color(0.16, 0.12, 0.14),
	"c": Color(0.2, 0.18, 0.28), "C": Color(0.34, 0.32, 0.5), "b": Color(0.48, 0.34, 0.22), "p": Color(0.26, 0.24, 0.3),
}

@export var controllable := false
@export var speed := 70.0
@export var bounds := Rect2(-200, -136, 400, 272)

var facing := Vector2.RIGHT


func _process(delta: float) -> void:
	if not controllable:
		return
	var v := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	if Input.is_physical_key_pressed(KEY_A): v.x -= 1.0
	if Input.is_physical_key_pressed(KEY_D): v.x += 1.0
	if Input.is_physical_key_pressed(KEY_W): v.y -= 1.0
	if Input.is_physical_key_pressed(KEY_S): v.y += 1.0
	if v.length() > 0.01:
		v = v.limit_length(1.0)
		facing = v.normalized()
		position = (position + v * speed * delta).clamp(bounds.position, bounds.end)


func _draw() -> void:
	var w: int = (ART[0] as String).length()
	var h := ART.size()
	draw_set_transform(Vector2(-w * 0.5, -h + 2), 0.0, Vector2.ONE)
	draw_rect(Rect2(1, h - 2, w - 2, 2), Color(0, 0, 0, 0.35))
	for y in h:
		var row: String = ART[y]
		for x in w:
			var ch := row[x]
			if PAL.has(ch):
				draw_rect(Rect2(x, y, 1, 1), PAL[ch])
