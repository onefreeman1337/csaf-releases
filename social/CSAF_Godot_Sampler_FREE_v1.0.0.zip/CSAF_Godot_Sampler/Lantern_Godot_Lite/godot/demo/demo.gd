extends Node2D
## Lantern demo: every preset over the demo town at night, one at a time, plus a running day.
##   Left / Right or Q / E   previous / next preset      Up / Down or Tab   family
##   Space                   the day cycle (ten skies on a LanternClock, the town's lights coming on at dusk)
##   WASD / arrows           walk, in the darkness family (the darkness follows the traveller)
## Run it from the editor (F5). Copyright (c) 2026 Core Systems Asset Factory.

const FAMILY_TITLES := {"cookie": "Light shapes", "flame": "Living sources", "sky": "Times of day and weather", "shade": "Darkness that follows you"}
const DAY_HOURS := {"pre_dawn": 4.5, "sunrise": 6.0, "morning": 8.0, "high_noon": 12.0, "golden_hour": 16.5, "sunset": 18.2,
	"blue_hour": 19.2, "moonlit": 21.5, "new_moon": 1.0, "aurora_night": 23.5}

@onready var stage: Node2D = $Stage
@onready var cam: Camera2D = $Camera
@onready var title: Label = $UI/Title
@onready var sub: Label = $UI/Sub
@onready var hint: Label = $UI/Hint

var families: Array[String] = []
var fam := 0
var idx := 0
var current: Node
var day_mode := false
var clock: LanternClock


func _ready() -> void:
	families = LanternCatalog.FAMILIES.duplicate()
	cam.zoom = Vector2(2.5, 2.5)
	cam.position = Vector2.ZERO
	_show()


func _unhandled_input(e: InputEvent) -> void:
	if not (e is InputEventKey or e is InputEventJoypadButton) or not e.is_pressed() or e.is_echo():
		return
	var key := (e as InputEventKey).physical_keycode if e is InputEventKey else KEY_NONE
	if key == KEY_SPACE or e.is_action("ui_accept"):
		day_mode = not day_mode
		_show()
	elif key == KEY_E or key == KEY_PAGEDOWN:
		step(1)
	elif key == KEY_Q or key == KEY_PAGEUP:
		step(-1)
	elif key == KEY_TAB:
		step_family(1)
	elif families[fam] == "shade" and not day_mode:
		return   # the arrows walk the traveller
	elif e.is_action("ui_right"):
		step(1)
	elif e.is_action("ui_left"):
		step(-1)
	elif e.is_action("ui_down"):
		step_family(1)
	elif e.is_action("ui_up"):
		step_family(-1)


func step(d: int) -> void:
	day_mode = false
	var ids := LanternCatalog.ids_for_family(families[fam])
	idx = posmod(idx + d, ids.size())
	_show()


func step_family(d: int) -> void:
	day_mode = false
	fam = posmod(fam + d, families.size())
	idx = 0
	_show()


## Show a preset by id (the capture harness uses this for the store pages).
func show_preset(id: String) -> void:
	for f in families.size():
		var ids := LanternCatalog.ids_for_family(families[f])
		var i := ids.find(id)
		if i >= 0:
			fam = f
			idx = i
			day_mode = false
			_show()
			return


## Hide or show the title and key hints (the capture harness hides them for clean frames).
func set_ui_visible(v: bool) -> void:
	$UI.visible = v


## Jump the day cycle to an hour (the capture harness uses this).
func show_hour(h: float) -> void:
	day_mode = true
	_show()
	clock.hour = h
	clock.running = false
	clock._apply()


func _show() -> void:
	if current != null:
		current.queue_free()
		current = null
	clock = null
	if day_mode:
		var root := Node2D.new()
		root.add_child(DemoTown.new())
		var preview = load("res://demo/preview.gd")
		preview.add_rig(root)
		var sky := LanternSky.new()
		root.add_child(sky)
		clock = LanternClock.new()
		clock.day_seconds = 120.0
		var hours := PackedFloat32Array()
		var looks: Array[LanternSkyLook] = []
		var keys := DAY_HOURS.keys()
		keys.sort_custom(func(a, b): return DAY_HOURS[a] < DAY_HOURS[b])
		for k in keys:
			var l := LanternCatalog.look(k)
			if l != null:
				looks.append(l)
				hours.append(DAY_HOURS[k])
		clock.looks = looks
		clock.hours = hours
		clock.hour = 16.0
		root.add_child(clock)
		sky.look = looks[0] if not looks.is_empty() else null
		stage.add_child(root)
		current = root
		title.text = "Lantern  ·  the day cycle"
		sub.text = "%d skies on a LanternClock · the windows and lamps come on by themselves at dusk" % looks.size()
		hint.text = "Space: back to the presets"
		return
	var ids := LanternCatalog.ids_for_family(families[fam])
	if ids.is_empty():
		return
	var id := ids[idx]
	var scene := load("res://demo/presets/%s.tscn" % id) as PackedScene
	current = scene.instantiate()
	stage.add_child(current)
	var walker: Variant = current.get("walker")
	if walker is DemoWalker:
		(walker as DemoWalker).controllable = true
	var name_s := id
	for p in LanternCatalog.PRESETS:
		if p["id"] == id:
			name_s = p["name"]
	title.text = "Lantern  ·  %s" % name_s
	sub.text = "%s  ·  %d / %d" % [FAMILY_TITLES.get(families[fam], families[fam]), idx + 1, ids.size()]
	if families[fam] == "shade":
		hint.text = "WASD / arrows: walk    Q / E: preset    Tab: family    Space: day cycle"
	else:
		hint.text = "Left / Right (Q / E): preset    Up / Down (Tab): family    Space: day cycle"
