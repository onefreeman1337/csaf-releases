extends Node2D
## One Lantern preset, previewed over the demo town at night. Every scene in demo/presets/ is this script with a
## different preset; open one and press F6 to see it alone. The night is Godot's own CanvasModulate (the CONTROL,
## demo/control.tscn): every preset must visibly improve on it. A sky preset replaces that night with its own look and
## switches on the town's follow_night lights. Copyright (c) 2026 Core Systems Asset Factory.

## The night every preview starts from: a plain CanvasModulate, nothing else.
const NIGHT := Color(0.26, 0.28, 0.42)
const RIG := [
	["res://addons/lantern/presets/cookie/cottage_window.tscn", Vector2(-120, -50), 0.0],
	["res://addons/lantern/presets/flame/street_lamp.tscn", Vector2(-60, 16), 0.0],
	["res://addons/lantern/presets/flame/street_lamp.tscn", Vector2(150, 16), 0.0],
	["res://addons/lantern/presets/flame/wall_torch.tscn", Vector2(-80, -52), 0.0],
]
const LAMPS := [Vector2(-60, 16), Vector2(150, 16), Vector2(-150, -30), Vector2(60, 60)]

@export var preset: PackedScene
@export_enum("control", "cookie", "flame", "sky", "shade") var family: String = "control"
## Where the preset sits in the town (town coordinates, origin at the centre).
@export var home := Vector2.ZERO
## Rotation of a light, degrees.
@export var aim := 0.0
## Shade previews: the walker's path so far (fog of war remembers it).
@export var path := PackedVector2Array()
## Shade previews: street lamps that join the "lantern_reveal" group.
@export var reveal_lamps := false
## Seconds into the preset's motion to show (negative = the preset's own preview_time).
@export var show_time := -1.0

var town: DemoTown
var instance: Node
var walker: DemoWalker


func _ready() -> void:
	town = DemoTown.new()
	add_child(town)
	if family != "sky":
		var cm := CanvasModulate.new()
		cm.color = NIGHT
		add_child(cm)
	if preset == null:
		return
	match family:
		"cookie", "flame":
			instance = preset.instantiate()
			(instance as Node2D).position = home
			(instance as Node2D).rotation_degrees = aim
			add_child(instance)
		"sky":
			add_rig(self)
			instance = preset.instantiate()
			add_child(instance)
		"shade":
			if reveal_lamps:
				for p in LAMPS:
					var lamp: Node2D = (load("res://addons/lantern/presets/flame/street_lamp.tscn") as PackedScene).instantiate()
					lamp.position = p
					lamp.add_to_group("lantern_reveal")
					add_child(lamp)
			walker = DemoWalker.new()
			walker.position = home
			add_child(walker)
			instance = preset.instantiate()
			if instance is LanternShade:
				# the preset's fog rectangle is given in TOWN coordinates; the shade reads world coordinates
				var fr: Rect2 = (instance as LanternShade).fog_rect
				(instance as LanternShade).fog_rect = Rect2(to_global(fr.position), fr.size)
			walker.add_child(instance)


## The town's own lights (windows, lamps, a torch), all follow_night: a sky decides whether they are on.
static func add_rig(parent: Node) -> void:
	for r in RIG:
		var n: Node2D = (load(r[0]) as PackedScene).instantiate()
		n.position = r[1]
		n.rotation_degrees = r[2]
		if n is LanternLight:
			(n as LanternLight).follow_night = true
		parent.add_child(n)


## Called by the CSAF capture stage: every Lantern node seeks to its showcase moment and then holds still, so both
## renderers photograph the same instant.
func csaf_preview() -> void:
	if instance is LanternShade and not path.is_empty():
		var world := PackedVector2Array()
		for p in path:
			world.append(to_global(p))
		(instance as LanternShade).reveal_path(world)
	var stack: Array[Node] = []
	for c in get_children():
		stack.append(c)
	while not stack.is_empty():
		var n: Node = stack.pop_back()
		if show_time >= 0.0 and n.has_method("seek"):
			n.call("seek", show_time)
		elif n.has_method("csaf_preview"):
			n.call("csaf_preview")
		for c in n.get_children(true):
			stack.append(c)
	for c in get_children():
		c.process_mode = Node.PROCESS_MODE_DISABLED
