# Wrack Lite for Godot 4 - 12 free aftermath recipes

The free sampler of **Wrack for Godot 4**: turn the town you already built into its aftermath without editing your map.
Wrack swaps each TileMapLayer's TileSet for a duplicate whose tiles carry one shader; the shader recomputes every pixel of
YOUR tiles from what the tile is (roof, wall, paving, grass...) and noise in world pixels, and smoke, sparks, mist and
motes are drawn over the map. `restore()` puts your own TileSet back.

- **Godot version:** built and tested on **Godot 4.7.2**, under **both renderers: Forward+ and Compatibility**. Older 4.x
  versions were NOT run, so they are not claimed.
- **In the lite:** 12 recipes in 3 families, the `Wrack` node, `WrackRecipe`, `WrackRoles`, `WrackDressing` and the demo.
- **Burned:** Blaze (`burned_blaze`), Smoulder (`burned_smoulder`), Firestorm Night (`burned_firestorm`), Scorched Fields
  (`burned_scorched_fields`).
- **Overgrown:** Ivy Creep (`overgrown_ivy_creep`), Reclaimed (`overgrown_reclaimed`), Moss Hollow
  (`overgrown_moss_hollow`), Wild Bloom (`overgrown_wild_bloom`).
- **Flooded:** Rain-Soaked (`flooded_rain_soaked`), Shallow Flood (`flooded_shallow`), Deep Flood (`flooded_deep`),
  Swamp (`flooded_swamp`).

**The full pack** (https://csaf.itch.io/wrack-godot) has 40 recipes in 8 families (adds Ruined, Abandoned, Blighted,
Parched and Haunted) and the layers they need: 1 px cracks and dried-mud cells, salt and ash crust, boarded and broken
windows, mud left by floods, craters, glowing veins, and pools of light thrown by lit windows.

## Install

1. Copy `godot/addons/wrack/` into your project's `addons/` folder (you get `res://addons/wrack/`).
2. No plugin to enable: the classes `Wrack`, `WrackRecipe`, `WrackRoles` and `WrackDressing` register themselves.

To see it first, open the `godot/` folder as a project in Godot 4.7 and press Play.

## Use it

```gdscript
$Wrack.layers = [$Ground, $Buildings]
$Wrack.apply(load("res://addons/wrack/recipes/burned_blaze.tres"))
await $Wrack.transition_to(load("res://addons/wrack/recipes/overgrown_reclaimed.tres"), "years", 4.0)
$Wrack.set_region_rect(Rect2i(10, 4, 6, 5))   # only these cells change
$Wrack.restore()
```

Modes for `transition_to`: `"fire"`, `"years"`, `"fade"`, `"flood"`. Tag your tiles with a custom data layer named
`wrack_role` (String: `paving`, `soil`, `grass`, `foliage`, `water`, `wall`, `roof`, `prop`) for the best result; untagged
tiles are read from the texture file name, then from their colours. The demo fixture shows the tagging.

Demo controls: Left / Right recipe · Up / Down family · F fire sweep · Y years · W flood · T fade · G market square only ·
A whole map · R restore · H help line.

## Licence and AI disclosure

MIT for everything except `godot/demo/fixture/` (the demo tiles; see `LICENSE.txt` and the fixture's `NOTICE.txt`). This
lite is AI-generated: the shader, scripts, scenes and recipes were written by an AI.

Core Systems Asset Factory
