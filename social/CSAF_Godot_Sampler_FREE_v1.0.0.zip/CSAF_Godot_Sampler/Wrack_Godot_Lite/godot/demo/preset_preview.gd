extends Node2D
## One preset, previewed: the demo town with one WrackRecipe applied. Every scene in demo/presets/ is this script with a
## different recipe; open one and press F6 to see that aftermath on its own. Copyright (c) 2026 Core Systems Asset Factory.

@export var recipe: WrackRecipe

var hamlet: WrackHamlet
var wrack: Wrack


func _ready() -> void:
	hamlet = WrackHamlet.new()
	add_child(hamlet)
	hamlet.build()
	wrack = Wrack.new()
	wrack.apply_on_ready = false
	wrack.layers = [hamlet.ground, hamlet.props]
	add_child(wrack)
	if recipe != null:
		wrack.apply(recipe)


## Called by the CSAF capture stage: the aftermath is fully applied the moment the scene is ready, so nothing to seek.
func csaf_preview() -> void:
	if wrack != null and recipe != null:
		wrack.set_progress(1.0)
