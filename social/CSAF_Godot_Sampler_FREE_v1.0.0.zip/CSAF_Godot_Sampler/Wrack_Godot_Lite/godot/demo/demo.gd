extends Node2D
## Wrack demo: the High Street and every aftermath in the pack.
##   Left / Right   previous / next recipe          Up / Down   previous / next family
##   F  play it in as a fire sweep    Y  as years passing    W  as a flood rising    T  as a fade
##   G  only the market square (region)    A  whole map again    R  restore the town    H  hide this help
## Copyright (c) 2026 Core Systems Asset Factory.

const RECIPE_DIR := "res://addons/wrack/recipes/"

var recipes: Array[WrackRecipe] = []
var index := 0
var hamlet: WrackHamlet
var wrack: Wrack
var label: Label
var help: Label
var busy := false


func _ready() -> void:
	for f in _recipe_files():
		var r := load(RECIPE_DIR + f) as WrackRecipe
		if r != null:
			recipes.append(r)
	hamlet = WrackHamlet.new()
	hamlet.scale = Vector2(2, 2)
	hamlet.position = Vector2(640, 380)
	add_child(hamlet)
	hamlet.build()
	wrack = Wrack.new()
	wrack.apply_on_ready = false
	wrack.layers = [hamlet.ground, hamlet.props]
	hamlet.add_child(wrack)
	var ui := CanvasLayer.new()
	add_child(ui)
	label = Label.new()
	label.position = Vector2(32, 18)
	label.add_theme_font_size_override("font_size", 26)
	label.add_theme_color_override("font_color", Color(1.0, 0.9, 0.78))
	label.add_theme_color_override("font_outline_color", Color(0.08, 0.06, 0.05))
	label.add_theme_constant_override("outline_size", 6)
	ui.add_child(label)
	help = Label.new()
	help.position = Vector2(32, 676)
	help.add_theme_font_size_override("font_size", 15)
	help.add_theme_color_override("font_color", Color(0.85, 0.82, 0.76))
	help.text = "Left/Right recipe   Up/Down family   F fire   Y years   W flood   T fade   G market square only   A whole map   R restore   H help"
	ui.add_child(help)
	if not recipes.is_empty():
		_show(0)


func _recipe_files() -> PackedStringArray:
	var out := PackedStringArray()
	for f in DirAccess.get_files_at(RECIPE_DIR):
		var n := f.trim_suffix(".remap")
		if n.ends_with(".tres") and not out.has(n):
			out.append(n)
	out.sort()
	return out


func _show(i: int) -> void:
	index = wrapi(i, 0, recipes.size())
	var r := recipes[index]
	wrack.apply(r)
	_caption(r)


func _caption(r: WrackRecipe) -> void:
	label.text = "%s  -  %s   (%d / %d)" % [r.family.capitalize(), r.title, index + 1, recipes.size()]


func _family_step(d: int) -> void:
	var fam := recipes[index].family
	var i := index
	for k in recipes.size():
		i = wrapi(i + d, 0, recipes.size())
		if recipes[i].family != fam:
			break
	if d < 0:
		var f2 := recipes[i].family
		while recipes[wrapi(i - 1, 0, recipes.size())].family == f2 and wrapi(i - 1, 0, recipes.size()) != index:
			i = wrapi(i - 1, 0, recipes.size())
	_show(i)


func _play(mode: String) -> void:
	if busy:
		return
	busy = true
	var r := recipes[index]
	await wrack.transition_to(r, mode, 3.5 if mode != "fade" else 1.5)
	busy = false


func _unhandled_input(e: InputEvent) -> void:
	if not (e is InputEventKey and e.pressed and not e.echo) or recipes.is_empty():
		return
	match e.keycode:
		KEY_RIGHT: _show(index + 1)
		KEY_LEFT: _show(index - 1)
		KEY_DOWN: _family_step(1)
		KEY_UP: _family_step(-1)
		KEY_F: _play("fire")
		KEY_Y: _play("years")
		KEY_W: _play("flood")
		KEY_T: _play("fade")
		KEY_G: wrack.set_region_rect(Rect2i(8, 5, 12, 7))
		KEY_A: wrack.clear_region()
		KEY_R:
			wrack.restore()
			label.text = "The High Street, as built"
		KEY_H: help.visible = not help.visible
