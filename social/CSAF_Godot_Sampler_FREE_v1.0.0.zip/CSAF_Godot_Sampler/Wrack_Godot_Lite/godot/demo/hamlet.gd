class_name WrackHamlet
extends Node2D
## The demo town: paints "The High Street" (Verdant 09 Town's sample map, see fixture/NOTICE.txt) into two TileMapLayers,
## ground and props, from fixture/hamlet_map.json. Your own game uses your own TileMapLayers; this only gives the demo
## something to burn. Copyright (c) 2026 Core Systems Asset Factory.

const TILESET := preload("res://demo/fixture/hamlet_tiles.tres")
const MAP_PATH := "res://demo/fixture/hamlet_map.json"

@export var centred := true

var ground: TileMapLayer
var props: TileMapLayer
var map_size := Vector2.ZERO


func _ready() -> void:
	build()


func build() -> void:
	if ground != null:
		return
	var f := FileAccess.open(MAP_PATH, FileAccess.READ)
	var data: Dictionary = JSON.parse_string(f.get_as_text())
	var cell := int(data["cell"])
	map_size = Vector2(int(data["cols"]) * cell, int(data["rows"]) * cell)
	ground = _layer("Ground", data["layers"]["ground"])
	props = _layer("Props", data["layers"]["props"])
	if centred:
		ground.position = -map_size * 0.5
		props.position = -map_size * 0.5


func _layer(n: String, cells: Array) -> TileMapLayer:
	var l := TileMapLayer.new()
	l.name = n
	l.tile_set = TILESET
	for e in cells:
		l.set_cell(Vector2i(int(e[0]), int(e[1])), 0, Vector2i(int(e[2]), int(e[3])))
	add_child(l)
	return l
