class_name WrackDressing
extends Node2D
## What an aftermath adds ON TOP of the tiles: smoke rising from roofs, sparks, a drifting mist, floating motes.
## Built by Wrack from the recipe's Dressing group; every piece is drawn at runtime (CPUParticles2D and one mist shader),
## so it runs under Forward+ and Compatibility alike. Copyright (c) 2026 Core Systems Asset Factory.

const MIST_SHADER := preload("res://addons/wrack/wrack_mist.gdshader")

var region: Array = []:
	set(v):
		region = v
		if _recipe != null:
			_build()
var reveal := 1.0:
	set(v):
		reveal = clampf(v, 0.0, 1.0)
		modulate.a = reveal

var _recipe: WrackRecipe
var _cells := {}
var _windows := []
var _rect := Rect2()
var _cell := Vector2(16, 16)
var _soft: Texture2D
var _add: CanvasItemMaterial


func setup(r: WrackRecipe, cells_by_role: Dictionary, map_rect: Rect2, cell: Vector2, windows: Array = []) -> void:
	_recipe = r
	_cells = cells_by_role
	_windows = windows
	_rect = map_rect
	_cell = cell
	_build()


func _build() -> void:
	for c in get_children():
		c.queue_free()
	if _recipe == null:
		return
	# a headless run (dedicated server, CI) draws nothing, and its dummy renderer logs "Parameter material is null"
	# for the dressing's particles, so no dressing is built there (MEASURED 2026-10-17, fi_test --mode=badinput)
	if DisplayServer.get_name() == "headless":
		return
	var k := clampf(_recipe.intensity, 0.0, 1.5)
	var roofs := _pick(7, _recipe.smoke_amount * k, 7)
	for p in roofs:
		if _recipe.smoke_amount > 0.0:
			add_child(_smoke(p, _recipe.smoke_amount * k))
		if _recipe.spark_amount > 0.0:
			add_child(_sparks(p, _recipe.spark_amount * k))
	if _recipe.spark_amount > 0.0 and _recipe.smoke_amount <= 0.0:
		for p in _pick(7, _recipe.spark_amount * k, 6):
			add_child(_sparks(p, _recipe.spark_amount * k))
	if _recipe.mote_amount > 0.0:
		add_child(_motes(_recipe.mote_amount * k))
	if _recipe.mist_amount > 0.0:
		add_child(_mist(_recipe.mist_amount * k))




## Up to max_n cells of a role, spread evenly and chosen by the recipe's seed so the same recipe always smokes the same roofs.
func _pick(role: int, amount: float, max_n: int) -> Array:
	var list: Array = _cells.get(role, [])
	if not region.is_empty():
		list = list.filter(func(e): return region.has(e["cell"]))
	if list.is_empty() or amount <= 0.0:
		return []
	var n := clampi(int(ceil(amount * max_n)), 1, max_n)
	var sorted := list.duplicate()
	sorted.sort_custom(func(a, b): return a["pos"].x < b["pos"].x if absf(a["pos"].x - b["pos"].x) > 0.5 else a["pos"].y < b["pos"].y)
	var out := []
	var off := int(absf(_recipe.seed) * 7.0) % maxi(sorted.size(), 1)
	for i in n:
		var idx := (off + int(float(i) * float(sorted.size()) / float(n))) % sorted.size()
		out.append(sorted[idx]["pos"])
	return out


func _soft_dot() -> Texture2D:
	if _soft == null:
		var g := Gradient.new()
		g.set_color(0, Color(1, 1, 1, 1))
		g.set_color(1, Color(1, 1, 1, 0))
		var t := GradientTexture2D.new()
		t.gradient = g
		t.fill = GradientTexture2D.FILL_RADIAL
		t.fill_from = Vector2(0.5, 0.5)
		t.fill_to = Vector2(0.5, 0.0)
		t.width = 32
		t.height = 32
		_soft = t
	return _soft


func _seeded(p: CPUParticles2D) -> void:
	if "use_fixed_seed" in p:
		p.set("use_fixed_seed", true)
		p.set("seed", int(absf(_recipe.seed) * 1000.0) + get_child_count())


func _smoke(at: Vector2, amount: float) -> CPUParticles2D:
	var p := CPUParticles2D.new()
	_seeded(p)
	p.position = at
	p.texture = _soft_dot()
	p.amount = int(10 + amount * 14)
	p.lifetime = 4.5
	p.preprocess = 4.5
	p.direction = Vector2(0.25, -1.0)
	p.spread = 12.0
	p.gravity = Vector2(4.0, -2.0)
	p.initial_velocity_min = 9.0
	p.initial_velocity_max = 15.0
	p.scale_amount_min = 0.35
	p.scale_amount_max = 0.6
	var sc := Curve.new()
	sc.add_point(Vector2(0.0, 0.5))
	sc.add_point(Vector2(1.0, 1.6))
	p.scale_amount_curve = sc
	var ramp := Gradient.new()
	var c := _recipe.smoke_color
	ramp.set_color(0, Color(c.r, c.g, c.b, 0.0))
	ramp.add_point(0.12, Color(c.r, c.g, c.b, c.a))
	ramp.set_color(ramp.get_point_count() - 1, Color(c.r * 1.3, c.g * 1.3, c.b * 1.3, 0.0))
	p.color_ramp = ramp
	return p


func _sparks(at: Vector2, amount: float) -> CPUParticles2D:
	var p := CPUParticles2D.new()
	_seeded(p)
	p.position = at
	p.amount = int(6 + amount * 12)
	p.lifetime = 1.6
	p.preprocess = 1.6
	p.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	p.emission_rect_extents = _cell * 0.45
	p.direction = Vector2(0.0, -1.0)
	p.spread = 25.0
	p.gravity = Vector2(6.0, -10.0)
	p.initial_velocity_min = 12.0
	p.initial_velocity_max = 26.0
	p.scale_amount_min = 1.0
	p.scale_amount_max = 2.0
	var ramp := Gradient.new()
	var c := _recipe.spark_color
	ramp.set_color(0, Color(1.0, 0.95, 0.7, 1.0))
	ramp.add_point(0.4, c)
	ramp.set_color(ramp.get_point_count() - 1, Color(c.r, c.g * 0.5, 0.0, 0.0))
	p.color_ramp = ramp
	return p


func _motes(amount: float) -> CPUParticles2D:
	var p := CPUParticles2D.new()
	_seeded(p)
	p.position = _rect.get_center()
	p.amount = int(12 + amount * 50)
	p.lifetime = 6.0
	p.preprocess = 6.0
	p.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	p.emission_rect_extents = _rect.size * 0.5
	p.direction = Vector2(0.0, -1.0)
	p.spread = 180.0
	p.gravity = Vector2.ZERO
	p.initial_velocity_min = 2.0
	p.initial_velocity_max = 6.0
	p.scale_amount_min = 1.0
	p.scale_amount_max = 2.0
	var ramp := Gradient.new()
	var c := _recipe.mote_color
	ramp.set_color(0, Color(c.r, c.g, c.b, 0.0))
	ramp.add_point(0.3, c)
	ramp.add_point(0.7, Color(c.r, c.g, c.b, c.a * 0.4))
	ramp.set_color(ramp.get_point_count() - 1, Color(c.r, c.g, c.b, 0.0))
	p.color_ramp = ramp
	return p


func _mist(amount: float) -> ColorRect:
	var r := ColorRect.new()
	r.position = _rect.position
	r.size = _rect.size
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var m := ShaderMaterial.new()
	m.shader = MIST_SHADER
	m.set_shader_parameter("mist_color", _recipe.mist_color)
	m.set_shader_parameter("amount", amount)
	m.set_shader_parameter("seed", _recipe.seed)
	r.material = m
	return r
