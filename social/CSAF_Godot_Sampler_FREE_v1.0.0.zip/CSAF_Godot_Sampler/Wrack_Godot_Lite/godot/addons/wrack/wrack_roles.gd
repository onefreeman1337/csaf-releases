class_name WrackRoles
extends RefCounted
## Decides what every tile IS (roof, wall, paving...) so an aftermath can treat a roof like a roof. In order:
##   1. a custom data layer named "wrack_role" on your TileSet (String: paving, soil, grass, foliage, water, wall, roof, prop)
##   2. a keyword in the atlas texture's file name (e.g. "roof", "thatch", "brick", "water", "hedge")
##   3. the tile's own colours (blue = water, green = grass or foliage, anything else = paving)
## Roofs and walls cannot be told apart by colour, so tag them (1) or name the texture (2) for the full effect.
## Copyright (c) 2026 Core Systems Asset Factory.

const ROLE_NAMES := ["unknown", "paving", "soil", "grass", "foliage", "water", "wall", "roof", "prop"]
const LAYER_NAME := "wrack_role"
const KEYWORDS := [
	["roof", "roof"], ["thatch", "roof"], ["shingle", "roof"], ["slate", "roof"], ["shake", "roof"], ["tiles_roof", "roof"],
	["wall", "wall"], ["brick", "wall"], ["plaster", "wall"], ["daub", "wall"], ["timber", "wall"], ["facade", "wall"],
	["water", "water"], ["sea", "water"], ["lake", "water"], ["river", "water"], ["pond", "water"], ["ocean", "water"],
	["tree", "foliage"], ["bush", "foliage"], ["hedge", "foliage"], ["leaf", "foliage"], ["foliage", "foliage"], ["forest", "foliage"],
	["grass", "grass"], ["meadow", "grass"], ["lawn", "grass"],
	["dirt", "soil"], ["soil", "soil"], ["farm", "soil"], ["tilth", "soil"], ["mud", "soil"], ["sand", "soil"],
	["cobble", "paving"], ["path", "paving"], ["road", "paving"], ["stone", "paving"], ["floor", "paving"], ["pave", "paving"],
	["prop", "prop"], ["object", "prop"], ["furniture", "prop"], ["deco", "prop"],
]


static func role_id(name: String) -> int:
	var i := ROLE_NAMES.find(name.strip_edges().to_lower())
	return maxi(i, 0)


## Returns {"texture": ImageTexture (role per pixel in the red channel), "counts": {role_name: tiles},
## "tiles": {Vector2i atlas coords: role id}, "windows": {Vector2i atlas coords: Vector2 glass centre inside the tile}}
## for one atlas source. A window is 4+ glass pixels (blue-dominant, the same test the shader uses) on a wall or roof tile.
static func build(ts: TileSet, source_id: int) -> Dictionary:
	var src := ts.get_source(source_id) as TileSetAtlasSource
	var counts := {}
	var tiles := {}
	var windows := {}
	if src == null or src.texture == null:
		return {"texture": null, "counts": counts, "tiles": tiles, "windows": windows}
	var tex_img := src.texture.get_image()
	if tex_img.is_compressed():
		tex_img.decompress()
	var size := src.texture.get_size()
	var img := Image.create(int(size.x), int(size.y), false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 1))
	var layer := -1
	for i in ts.get_custom_data_layers_count():
		if ts.get_custom_data_layer_name(i) == LAYER_NAME:
			layer = i
	var by_name := _keyword_role(src.texture.resource_path)
	for t in src.get_tiles_count():
		var coords := src.get_tile_id(t)
		var role := ""
		if layer >= 0:
			var td := src.get_tile_data(coords, 0)
			if td != null:
				role = str(td.get_custom_data_by_layer_id(layer))
		if role == "":
			role = by_name
		var rect := src.get_tile_texture_region(coords)
		if role == "":
			role = _colour_role(tex_img, rect)
		var id := role_id(role)
		counts[ROLE_NAMES[id]] = int(counts.get(ROLE_NAMES[id], 0)) + 1
		tiles[coords] = id
		# every animation frame of the tile gets the role (frame 0's region alone left animated tiles unknown)
		for fi in maxi(src.get_tile_animation_frames_count(coords), 1):
			img.fill_rect(src.get_tile_texture_region(coords, fi), Color8(id, 0, 0, 255))
		if id == 6 or id == 7:
			var w := _glass_centre(tex_img, rect)
			if w.x >= 0.0:
				windows[coords] = w
	return {"texture": ImageTexture.create_from_image(img), "counts": counts, "tiles": tiles, "windows": windows}


static func _glass_centre(img: Image, rect: Rect2i) -> Vector2:
	var sum := Vector2.ZERO
	var n := 0
	for y in range(rect.position.y, mini(rect.end.y, img.get_height())):
		for x in range(rect.position.x, mini(rect.end.x, img.get_width())):
			var c := img.get_pixel(x, y)
			var green := c.g > c.r + 0.035 and c.g > c.b + 0.02
			var l := c.r * 0.299 + c.g * 0.587 + c.b * 0.114
			if c.a > 0.5 and c.b > c.r + 0.1 and c.b > c.g + 0.01 and l > 0.28 and not green:
				sum += Vector2(x - rect.position.x, y - rect.position.y) + Vector2(0.5, 0.5)
				n += 1
	return sum / float(n) if n >= 4 else Vector2(-1, -1)


static func _keyword_role(path: String) -> String:
	var f := path.get_file().to_lower()
	for kw in KEYWORDS:
		if f.contains(kw[0]):
			return kw[1]
	return ""


static func _colour_role(img: Image, rect: Rect2i) -> String:
	var r := 0.0
	var g := 0.0
	var b := 0.0
	var opaque := 0
	var total := 0
	for y in range(rect.position.y, rect.end.y):
		for x in range(rect.position.x, rect.end.x):
			if x >= img.get_width() or y >= img.get_height():
				continue
			total += 1
			var c := img.get_pixel(x, y)
			if c.a > 0.5:
				opaque += 1
				r += c.r
				g += c.g
				b += c.b
	if opaque == 0:
		return "unknown"
	r /= opaque
	g /= opaque
	b /= opaque
	if b > r + 0.06 and b >= g - 0.02:
		return "water"
	if g > r + 0.04 and g > b + 0.02:
		return "foliage" if opaque < total * 0.9 else "grass"
	return "paving" if opaque >= total * 0.9 else "prop"
