@tool
class_name WrackRecipe
extends Resource
## One aftermath: every number the Wrack shader reads, plus the dressing (smoke, embers, mist) drawn over the map.
## Change any field in the inspector and the town redraws. `intensity` scales every *_amount at once.
## Copyright (c) 2026 Core Systems Asset Factory.

const ROLE_BITS := {"paving": 1, "soil": 2, "grass": 3, "foliage": 4, "water": 5, "wall": 6, "roof": 7, "prop": 8}

@export var title := "Untitled aftermath"
@export var family := "burned"
@export_range(0.0, 1.5, 0.01) var intensity := 1.0
@export var seed := 0.0

@export_group("Grade")
@export_range(0.0, 1.5, 0.01) var saturation := 1.0
@export_range(0.2, 1.5, 0.01) var brightness := 1.0
@export var tint := Color(1, 1, 1)
@export_range(0.0, 1.0, 0.01) var tint_amount := 0.0

@export_group("Burn")
@export_range(0.0, 1.0, 0.01) var char_amount := 0.0
@export var char_roles: PackedStringArray = PackedStringArray()
@export_range(0.0, 1.0, 0.01) var char_patch := 0.0
@export var char_dark := Color(0.07, 0.055, 0.05)
@export var char_light := Color(0.34, 0.27, 0.22)
@export_range(0.0, 1.0, 0.01) var soot_amount := 0.0
@export_range(0.0, 1.0, 0.01) var ember_amount := 0.0
@export var ember_color := Color(1.0, 0.52, 0.12)

@export_group("Roof holes")
@export_range(0.0, 1.0, 0.01) var hole_amount := 0.0
@export_range(6.0, 60.0, 0.5) var hole_scale := 22.0
@export var hole_void := Color(0.06, 0.04, 0.035)
@export var hole_rim := Color(0.95, 0.42, 0.1)
@export_range(0.0, 0.2, 0.005) var hole_rim_width := 0.05
@export_range(0.0, 1.0, 1.0) var rafters := 0.0
@export var rafter_color := Color(0.36, 0.3, 0.26)


@export_group("Drifts (ash, dust, sand)")
@export_range(0.0, 1.0, 0.01) var ash_amount := 0.0
@export var ash_roles: PackedStringArray = PackedStringArray()
@export var ash_color := Color(0.62, 0.6, 0.57)
@export_range(4.0, 40.0, 0.5) var ash_scale := 14.0

@export_group("Windows and doors")
@export_range(0.0, 1.0, 0.01) var glow_amount := 0.0
@export var glow_color := Color(1.0, 0.45, 0.1)

@export_group("Growth")
@export_range(0.0, 1.0, 0.01) var ivy_amount := 0.0
@export_range(0.0, 1.0, 0.01) var moss_amount := 0.0
@export_range(0.0, 1.0, 0.01) var creep_amount := 0.0
@export var growth_dark := Color(0.13, 0.3, 0.12)
@export var growth_light := Color(0.36, 0.58, 0.22)
@export_range(0.0, 1.0, 0.01) var bloom_amount := 0.0
@export var bloom_color := Color(0.95, 0.85, 0.35)
@export_range(0.0, 1.0, 0.01) var foliage_dry := 0.0
@export var foliage_target := Color(0.62, 0.52, 0.28)

@export_group("Water")
@export_range(0.0, 1.0, 0.01) var flood_amount := 0.0
@export var water_shallow := Color(0.3, 0.5, 0.56)
@export var water_deep := Color(0.12, 0.25, 0.34)
@export_range(0.0, 1.0, 0.01) var water_clarity := 0.35
@export_range(0.0, 0.6, 0.01) var waterline := 0.0
@export var silt_color := Color(0.4, 0.34, 0.24)

@export_group("Dressing")
@export_range(0.0, 1.0, 0.01) var smoke_amount := 0.0
@export var smoke_color := Color(0.18, 0.16, 0.15, 0.55)
@export_range(0.0, 1.0, 0.01) var spark_amount := 0.0
@export var spark_color := Color(1.0, 0.6, 0.2)
@export_range(0.0, 1.0, 0.01) var mist_amount := 0.0
@export var mist_color := Color(0.75, 0.8, 0.85, 0.35)
@export_range(0.0, 1.0, 0.01) var mote_amount := 0.0
@export var mote_color := Color(0.85, 1.0, 0.55)

const AMOUNTS := [
	"char_amount", "soot_amount", "ember_amount", "hole_amount", "crack_amount", "ash_amount", "glow_amount",
	"board_amount", "ivy_amount", "moss_amount", "creep_amount", "bloom_amount", "foliage_dry", "flood_amount",
	"silt_amount", "vein_amount", "crater_amount", "waterline", "broken_amount",
]
const PLAIN := [
	"saturation", "brightness", "tint_amount", "char_patch", "hole_scale", "hole_rim_width", "rafters", "ash_scale",
	"ash_crust", "water_clarity",
]
const COLOURS := [
	"tint", "char_dark", "char_light", "ember_color", "hole_void", "hole_rim", "rafter_color", "crack_color", "ash_color",
	"glow_color", "board_color", "growth_dark", "growth_light", "bloom_color", "foliage_target", "water_shallow",
	"water_deep", "silt_color", "vein_color", "crater_rim",
]
const ROLE_MASKS := ["char_roles", "crack_roles", "ash_roles"]


static func role_mask(names: PackedStringArray) -> int:
	var m := 0
	for n in names:
		if ROLE_BITS.has(n):
			m |= 1 << int(ROLE_BITS[n])
	return m


## Writes this recipe into a Wrack ShaderMaterial (Wrack calls this; you rarely need to).
func write_to(mat: ShaderMaterial) -> void:
	var k := clampf(intensity, 0.0, 1.5)
	for n in AMOUNTS:
		if n in self:
			var v := float(get(n))
			mat.set_shader_parameter(n, clampf(v * k, 0.0, 1.0) if n != "waterline" else v * minf(k, 1.0))
	for n in PLAIN + COLOURS:
		if n in self:
			mat.set_shader_parameter(n, get(n))
	for n in ROLE_MASKS:
		if n in self:
			mat.set_shader_parameter(n, role_mask(get(n)))
	mat.set_shader_parameter("seed", seed)
