class_name Wrack
extends Node2D
## Wrack: turns the town you already built into its aftermath - burned, ruined, overgrown, flooded, abandoned, blighted,
## buried or haunted - without editing your map. Add a Wrack node AFTER your TileMapLayers (same parent, same position),
## list the layers, give it a WrackRecipe. It swaps each layer's TileSet for a DUPLICATE whose tiles carry the Wrack shader,
## and draws the recipe's dressing (smoke, sparks, mist, motes) over the map. restore() puts your own TileSet back.
##
##   $Wrack.apply(load("res://addons/wrack/recipes/burned_blaze.tres"))
##   await $Wrack.transition_to(load(".../overgrown_ivy_creep.tres"), "years", 4.0)
##   $Wrack.set_region_rect(Rect2i(10, 4, 6, 5))   # only these cells change
##   $Wrack.restore()
## Copyright (c) 2026 Core Systems Asset Factory.

signal transition_finished

const SHADER := preload("res://addons/wrack/wrack.gdshader")
const MODES := {"none": 0, "fire": 1, "years": 2, "fade": 3, "flood": 4}

@export var layers: Array[TileMapLayer] = []
@export var recipe: WrackRecipe
@export var apply_on_ready := true

var _original := {}      # TileMapLayer -> its own TileSet
var _derived := {}       # original TileSet -> derived TileSet
var _materials: Array[ShaderMaterial] = []
var _tile_roles := {}    # original TileSet -> {source_id: {coords: role id}}
var _tile_windows := {}  # original TileSet -> {source_id: {coords: glass centre inside the tile}}
var _dressing: WrackDressing
var _tween: Tween


func _ready() -> void:
	if apply_on_ready and recipe != null:
		apply(recipe)


## Applies a recipe at once (no transition).
func apply(r: WrackRecipe) -> void:
	if r == null:
		push_warning("Wrack.apply(null): no recipe given, nothing changed")
		return
	recipe = r
	_ensure_derived()
	for m in _materials:
		r.write_to(m)
		m.set_shader_parameter("progress", 1.0)
		m.set_shader_parameter("transition_mode", 0)
	_dressing_for(r, 1.0)


## Plays the change in: mode "fire" (a burning front sweeps from `from` to `to`, in this node's local pixels), "years"
## (patches creep in), "fade", or "flood" (water rises from `from` toward `to`). Await it or listen for transition_finished.
func transition_to(r: WrackRecipe, mode := "fade", duration := 3.0, from := Vector2.ZERO, to := Vector2.ZERO) -> void:
	if r == null:
		push_warning("Wrack.transition_to(null): no recipe given, nothing changed")
		transition_finished.emit()
		return
	if not MODES.has(mode):
		push_warning("Wrack.transition_to: unknown mode \"%s\", using \"fade\" (modes: fire, years, fade, flood)" % mode)
		mode = "fade"
	recipe = r
	_ensure_derived()
	var span := _map_rect()
	if from == Vector2.ZERO and to == Vector2.ZERO:
		if mode == "flood":
			# water rises from the bottom edge of the map to the top
			from = Vector2(span.position.x + span.size.x * 0.5, span.end.y)
			to = Vector2(span.position.x + span.size.x * 0.5, span.position.y)
		else:
			from = Vector2(span.position.x, span.position.y + span.size.y * 0.5)
			to = Vector2(span.end.x, span.position.y + span.size.y * 0.5)
	var gfrom := to_global(from)
	var gto := to_global(to)
	# the moving edge: a fire front burns in the recipe's ember colour, a flood front is a pale line of foam
	var front := r.ember_color if mode == "fire" else Color(0.86, 0.94, 0.98)
	for m in _materials:
		r.write_to(m)
		m.set_shader_parameter("transition_mode", int(MODES.get(mode, 3)))
		m.set_shader_parameter("sweep_from", gfrom)
		m.set_shader_parameter("sweep_to", gto)
		m.set_shader_parameter("front_color", front)
		m.set_shader_parameter("progress", 0.0)
	_dressing_for(r, 0.0)
	if _tween != null:
		_tween.kill()
	_tween = create_tween()
	_tween.tween_method(_set_progress, 0.0, 1.0, maxf(duration, 0.01))
	await _tween.finished
	transition_finished.emit()


## Shows the aftermath at a fraction of its transition (0..1), for scrubbing or for a still at the moment of change.
func set_progress(p: float) -> void:
	_set_progress(clampf(p, 0.0, 1.0))


## Only the given cells (in the first layer's map coordinates) change; everything else stays as you built it.
func set_region_cells(cells: Array[Vector2i]) -> void:
	if cells.is_empty() or layers.is_empty():
		clear_region()
		return
	var lo := cells[0]
	var hi := cells[0]
	for c in cells:
		lo = Vector2i(mini(lo.x, c.x), mini(lo.y, c.y))
		hi = Vector2i(maxi(hi.x, c.x), maxi(hi.y, c.y))
	var size := hi - lo + Vector2i.ONE
	var img := Image.create(size.x, size.y, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 1))
	for c in cells:
		img.set_pixel(c.x - lo.x, c.y - lo.y, Color(1, 1, 1, 1))
	var l0: TileMapLayer = layers[0]
	var cell_size := Vector2(l0.tile_set.tile_size) * l0.global_scale
	var origin := l0.to_global(l0.map_to_local(lo) - Vector2(l0.tile_set.tile_size) * 0.5)
	_ensure_derived()
	for m in _materials:
		m.set_shader_parameter("use_region", true)
		m.set_shader_parameter("region_mask", ImageTexture.create_from_image(img))
		m.set_shader_parameter("region_origin", origin)
		m.set_shader_parameter("region_size_cells", Vector2(size))
		m.set_shader_parameter("cell_px", cell_size)
	if _dressing != null:
		_dressing.region = cells


## Only cells inside rect (map coordinates of the first layer) change.
func set_region_rect(rect: Rect2i) -> void:
	var cells: Array[Vector2i] = []
	for y in range(rect.position.y, rect.end.y):
		for x in range(rect.position.x, rect.end.x):
			cells.append(Vector2i(x, y))
	set_region_cells(cells)


func clear_region() -> void:
	for m in _materials:
		m.set_shader_parameter("use_region", false)
	if _dressing != null:
		_dressing.region = []


## Puts every layer's own TileSet back and removes the dressing. Your map was never edited.
func restore() -> void:
	for l in _original:
		if is_instance_valid(l):
			(l as TileMapLayer).tile_set = _original[l]
	# keep the derived TileSets and their materials alive a moment: the layers let go of them on their next deferred
	# update, and freeing them first logged "Parameter material is null" (MEASURED 2026-10-17, headless restore)
	if is_inside_tree() and not _derived.is_empty():
		var keep := [_derived.values(), _materials.duplicate()]
		get_tree().create_timer(0.25, true, false, true).timeout.connect(_drop.bind(keep))
	_original.clear()
	_derived.clear()
	_materials.clear()
	_tile_roles.clear()
	_tile_windows.clear()
	if _dressing != null:
		_dressing.queue_free()
		_dressing = null


## Role counts per layer, for debugging what Wrack thinks your tiles are.
func describe_roles() -> Dictionary:
	_ensure_derived()
	var out := {}
	for ts in _tile_roles:
		var counts := {}
		for sid in _tile_roles[ts]:
			for coords in _tile_roles[ts][sid]:
				var n: String = WrackRoles.ROLE_NAMES[int(_tile_roles[ts][sid][coords])]
				counts[n] = int(counts.get(n, 0)) + 1
		out[ts.resource_path if ts.resource_path != "" else str(ts)] = counts
	return out


static func _drop(_keep: Array) -> void:
	pass


func _set_progress(p: float) -> void:
	for m in _materials:
		m.set_shader_parameter("progress", p)
	if _dressing != null:
		_dressing.reveal = p


func _ensure_derived() -> void:
	for l in layers:
		if l == null or l.tile_set == null or _original.has(l):
			continue
		var own: TileSet = l.tile_set
		if not _derived.has(own):
			_derived[own] = _derive(own)
		_original[l] = own
		l.tile_set = _derived[own]
	var cell := Vector2(16, 16)
	if not layers.is_empty() and layers[0] != null and _original.has(layers[0]):
		cell = Vector2((_original[layers[0]] as TileSet).tile_size) * layers[0].global_scale
	for m in _materials:
		m.set_shader_parameter("cell_px", cell)


func _derive(own: TileSet) -> TileSet:
	var d: TileSet = own.duplicate(true)
	var roles := {}
	var windows := {}
	for i in d.get_source_count():
		var sid := d.get_source_id(i)
		var src := d.get_source(sid) as TileSetAtlasSource
		if src == null:
			continue
		var built := WrackRoles.build(own, sid)
		roles[sid] = built["tiles"]
		windows[sid] = built["windows"]
		var mat := ShaderMaterial.new()
		mat.shader = SHADER
		if built["texture"] != null:
			mat.set_shader_parameter("role_map", built["texture"])
			mat.set_shader_parameter("has_role_map", true)
		_materials.append(mat)
		for t in src.get_tiles_count():
			var coords := src.get_tile_id(t)
			for a in src.get_alternative_tiles_count(coords):
				var td := src.get_tile_data(coords, src.get_alternative_tile_id(coords, a))
				if td != null:
					td.material = mat
	_tile_roles[own] = roles
	_tile_windows[own] = windows
	return d


func _map_rect() -> Rect2:
	var r := Rect2()
	var first := true
	for l in layers:
		if l == null or l.tile_set == null:
			continue
		var used := l.get_used_rect()
		var ts := Vector2(l.tile_set.tile_size)
		var a := to_local(l.to_global(l.map_to_local(used.position) - ts * 0.5))
		var b := to_local(l.to_global(l.map_to_local(used.end) - ts * 0.5))
		var lr := Rect2(a, b - a)
		r = lr if first else r.merge(lr)
		first = false
	return r


func _dressing_for(r: WrackRecipe, reveal: float) -> void:
	if _dressing == null:
		_dressing = WrackDressing.new()
		_dressing.name = "WrackDressing"
		add_child(_dressing)
	var cells_by_role := {}
	var windows := []
	for l in layers:
		if l == null or not _original.has(l):
			continue
		var own: TileSet = _original[l]
		var roles: Dictionary = _tile_roles.get(own, {})
		var wins: Dictionary = _tile_windows.get(own, {})
		var half := Vector2(own.tile_size) * 0.5
		for c in l.get_used_cells():
			var sid := l.get_cell_source_id(c)
			var ac := l.get_cell_atlas_coords(c)
			var role := int((roles.get(sid, {}) as Dictionary).get(ac, 0))
			var p := to_local(l.to_global(l.map_to_local(c)))
			if not cells_by_role.has(role):
				cells_by_role[role] = []
			cells_by_role[role].append({"pos": p, "cell": c})
			var w: Dictionary = wins.get(sid, {})
			if w.has(ac):
				windows.append({"pos": to_local(l.to_global(l.map_to_local(c) - half + (w[ac] as Vector2))), "cell": c})
	# the dressing draws in THIS node's space: one cell in local units, whatever the parents' scale
	var cell := Vector2(16, 16)
	if not layers.is_empty() and layers[0] != null and _original.has(layers[0]):
		cell = Vector2((_original[layers[0]] as TileSet).tile_size) * layers[0].global_scale / global_scale
	_dressing.setup(r, cells_by_role, _map_rect(), cell, windows)
	_dressing.reveal = reveal
