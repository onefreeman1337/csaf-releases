class_name JigsawBoard
extends Node2D
## Jigsaw for Godot 4 - a playable jigsaw of any Texture2D, drawn in one of the pack's styles.
##
## Give it a picture, a piece count and a JigsawStyle and it cuts the picture, lays the pieces out on the table beside
## the tray and lets the player assemble it with the mouse, touch, keyboard or a gamepad. Hold the peek action to see
## the box lid. When the last piece clicks in, the style's ending plays and `solved` fires; `finished` fires when the
## player closes the puzzle (solved or set aside). Await it:
##     var result: Dictionary = await $JigsawBoard.finished
##     # {solved, pieces, placed, seconds, moves, peeks, seed, style, tiling, edge}
## Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.

## A piece clicked into place.
signal piece_placed(placed: int, total: int)
## The last piece clicked in (fires before the ending plays).
signal solved(result: Dictionary)
## The puzzle closed: solved and confirmed, or set aside. Carries the result.
signal finished(result: Dictionary)

enum State { IDLE, PLAYING, ENDING, DONE, PREVIEW }

const ENDING_TIME := 1.25
const DEFAULT_STYLE := "styles/parlour.tres"

## The picture to cut. Any Texture2D (an imported PNG/JPG, a ViewportTexture, an ImageTexture).
@export var picture: Texture2D
## About how many pieces (4 to 256). Grid cuts hit it near-exactly; lattice cuts land close (see the Readme).
@export_range(4, 256, 1) var pieces := 24
## Blank = a new cut every time. Any number or word cuts the same puzzle every time.
@export var seed_text := ""
## The look. Empty = the Parlour style.
@export var style: JigsawStyle

@export_group("Layout")
## Fill the viewport (and follow it when it is resized). Off = use board_size.
@export var fit_viewport := true
@export var board_size := Vector2(1280, 720)
## Draw round this node's origin instead of from its top-left.
@export var centered := false
## How much of the width (or height, on a portrait screen) the tray may take.
@export_range(0.35, 0.8, 0.01) var frame_share := 0.6

@export_group("Play")
## Cut and lay out the puzzle as soon as the node enters the tree.
@export var autostart := true
## How close to its place (board pixels at 720 high; scales with the board) a piece must land to click in.
@export_range(4.0, 60.0, 1.0) var snap_distance := 16.0
## Loose pieces start turned; the rotate action, a right click or the wheel turns the held piece.
@export var rotation_enabled := false
## The cancel action (or a right click with nothing held) sets the puzzle aside.
@export var allow_set_aside := true
## After the ending, wait for a click or the pick/cancel action before `finished`.
@export var close_on_confirm := true
## Show a drawn hand the arrow keys / left stick move (it hides when the mouse moves).
@export var keyboard_hand := true
## Read a gamepad's face buttons directly as well as the actions: A picks up / puts down, B drops or sets aside, X turns,
## the left shoulder (held) shows the box lid. Godot's default ui_accept / ui_cancel have no gamepad button, so this is on.
@export var gamepad_buttons := true
## Start in the showcase state (part assembled, one piece in the air). Used by the preset scenes.
@export var showcase := false
@export_range(0.0, 1.0, 0.01) var showcase_placed := 0.55

@export_group("Actions")
@export var action_pick: StringName = &"ui_accept"
@export var action_cancel: StringName = &"ui_cancel"
@export var action_rotate: StringName = &"ui_focus_next"
@export var action_peek: StringName = &"ui_page_up"
@export var action_left: StringName = &"ui_left"
@export var action_right: StringName = &"ui_right"
@export var action_up: StringName = &"ui_up"
@export var action_down: StringName = &"ui_down"

var state := State.IDLE
var cut := {}
var seed_used := 0
var table_rect := Rect2()
var frame_rect := Rect2()
var plaque_rect := Rect2()
var scale_k := 1.0
var placed_count := 0
var moves := 0
var peeks := 0
var seconds := 0.0

var _pieces: Array[JigsawPiece] = []
var _guides: Array = []
var _placed_layer: Node2D
var _loose_layer: Node2D
var _fx: Node2D
var _plaque: Node2D
var _hand: Node2D
var _face_mat: ShaderMaterial
var _held: JigsawPiece = null
var _grab := Vector2.ZERO
var _hand_pos := Vector2.ZERO
var _hand_on := false
var _peek := 0.0
var _peeking := false
var _end_t := 0.0
var _border := 4.0
var _cell := Vector2(40, 40)
var _shown_seconds := -1
var _result := {}
var _emitted := false
var _sparks: Array = []
var _keep_seed := false
var _built := false


func _ready() -> void:
	if style == null:
		style = default_style()
	_placed_layer = Node2D.new()
	_placed_layer.name = "Placed"
	_loose_layer = Node2D.new()
	_loose_layer.name = "Loose"
	_fx = Node2D.new()
	_fx.name = "Fx"
	_plaque = Node2D.new()
	_plaque.name = "Plaque"
	_hand = Node2D.new()
	_hand.name = "Hand"
	for n in [_placed_layer, _loose_layer, _fx, _plaque, _hand]:
		add_child(n)
	_fx.draw.connect(_draw_fx)
	_plaque.draw.connect(_draw_plaque)
	_hand.draw.connect(_draw_hand)
	if fit_viewport:
		get_viewport().size_changed.connect(_on_resize)
	if autostart:
		start()
	if showcase:
		preview(showcase_placed)


## The Parlour style shipped beside this script (found relative to it, so a renamed addon folder still works).
static func default_style() -> JigsawStyle:
	var dir: String = (JigsawBoard as Script).resource_path.get_base_dir()
	var path := dir.path_join(DEFAULT_STYLE)
	if ResourceLoader.exists(path):
		var s: Variant = load(path)
		if s is JigsawStyle:
			return s
	return JigsawStyle.new()


## Cuts the picture and lays the pieces out. Optional arguments override the exported ones.
func start(p_picture: Texture2D = null, p_pieces: int = -1, p_seed: Variant = null) -> void:
	if p_picture:
		picture = p_picture
	if p_pieces > 0:
		pieces = p_pieces
	if p_seed != null:
		seed_text = str(p_seed)
	if style == null:
		style = default_style()
	_keep_seed = false
	_build()
	placed_count = 0
	moves = 0
	peeks = 0
	seconds = 0.0
	_shown_seconds = -1
	_emitted = false
	_result = {}
	_sparks.clear()
	_end_t = 0.0
	state = State.PLAYING if _built else State.IDLE
	if _fx:
		_fx.queue_redraw()
		_plaque.queue_redraw()


## Shows the puzzle part assembled with one piece in the air (no input, no clock). The preset scenes use it.
func preview(fraction: float = 0.55) -> void:
	if not _built:
		start()
	if not _built:
		return
	state = State.PREVIEW
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_used + 99
	var order: Array[int] = []
	for i in _pieces.size():
		order.append(i)
	for i in range(order.size() - 1, 0, -1):
		var j := rng.randi_range(0, i)
		var t := order[i]
		order[i] = order[j]
		order[j] = t
	var k := clampi(int(round(fraction * _pieces.size())), 0, _pieces.size() - 1)
	for i in k:
		_place(_pieces[order[i]], false)
	_scatter(true)
	placed_count = k
	moves = k + int(k * 0.4)
	seconds = 60.0 + k * 4.0
	if k < _pieces.size():
		var p := _pieces[order[k]]
		p.set_turn(0)
		p.lifted = true
		p.scale = Vector2.ONE * 1.05
		p.position = p.home + Vector2(_cell.x * 0.32, -_cell.y * 0.26)
		_loose_layer.move_child(p, _loose_layer.get_child_count() - 1)
		p.queue_redraw()
	_plaque.queue_redraw()


## The gate's capture hook: the showcase state.
func csaf_preview() -> void:
	preview(showcase_placed)


## Sets the puzzle aside: `finished` fires with solved = false.
func set_aside() -> void:
	if state != State.PLAYING:
		return
	if _held:
		_drop_back()
	_result = _make_result(false)
	state = State.DONE
	_finish()


## Puts every remaining piece in place and plays the ending (a "skip" button, or a test).
func solve_now() -> void:
	if state != State.PLAYING:
		return
	if _held:
		_drop_back()
	for p in _pieces:
		if not p.placed:
			_place(p, false)
			placed_count += 1
	_solve()


## The result so far: {solved, pieces, placed, seconds, moves, peeks, seed, style, tiling, edge}.
func get_result() -> Dictionary:
	return _result if not _result.is_empty() else _make_result(false)


## How many pieces this cut really made.
func piece_count() -> int:
	return _pieces.size()


## The pieces (JigsawPiece nodes), in cut order.
func get_pieces() -> Array[JigsawPiece]:
	return _pieces


# --- building -----------------------------------------------------------------------------------------------------

func _build() -> void:
	for layer in [_placed_layer, _loose_layer]:
		for c in layer.get_children():
			layer.remove_child(c)
			c.queue_free()
	_pieces.clear()
	_guides.clear()
	_held = null
	var size := get_viewport_rect().size if fit_viewport else board_size
	size = Vector2(maxf(160.0, size.x), maxf(120.0, size.y))
	table_rect = Rect2(-size * 0.5 if centered else Vector2.ZERO, size)
	_built = false
	if picture == null:
		push_warning("JigsawBoard: no picture set, so there is nothing to cut. Set `picture` or call start(texture).")
		_layout(Vector2(4, 3))
		queue_redraw()
		return
	if not _keep_seed:
		seed_used = JigsawCut.seed_of(seed_text) if seed_text.strip_edges() != "" else randi_range(1, 2147483646)
	# the cutter works on at least 16 x 16; a smaller picture is cut at that size and its UVs scaled back to the texture
	var tex_size := picture.get_size()
	var psize := Vector2(maxf(16.0, tex_size.x), maxf(16.0, tex_size.y))
	var uv_k := tex_size / psize
	cut = JigsawCut.cut(psize.x, psize.y, pieces, seed_used, style.cut_options())
	_layout(psize)
	var dir: String = (JigsawBoard as Script).resource_path.get_base_dir()
	_face_mat = ShaderMaterial.new()
	_face_mat.shader = load(dir.path_join("shaders/jigsaw_face.gdshader"))
	_face_mat.set_shader_parameter("tint", style.face_tint)
	_face_mat.set_shader_parameter("saturation", style.face_saturation)
	_face_mat.set_shader_parameter("brightness", style.face_brightness)
	_face_mat.set_shader_parameter("sepia", style.face_sepia)
	_face_mat.set_shader_parameter("posterize", style.face_posterize)
	_face_mat.set_shader_parameter("pixels", style.face_pixels)
	_face_mat.set_shader_parameter("picture_size", tex_size)
	_face_mat.set_shader_parameter("frost", 0.22 if style.finish == JigsawStyle.Finish.FROST else 0.0)
	_face_mat.set_shader_parameter("frost_color", style.glow_color)
	var biggest := Vector2.ZERO
	for pc: Dictionary in cut["pieces"]:
		var cen: Vector2 = pc["centroid"]
		var local := PackedVector2Array()
		var guide := PackedVector2Array()
		var uv := PackedVector2Array()
		for p: Vector2 in pc["outline"]:
			local.append((p - cen) * scale_k)
			guide.append(frame_rect.position + p * scale_k)
			uv.append(p * uv_k)
		guide.append(guide[0])
		_guides.append(guide)
		var r: Rect2 = pc["rect"]
		biggest = biggest.max(r.size * scale_k)
		var piece := JigsawPiece.new()
		piece.name = "Piece%d" % pc["id"]
		piece.setup(pc["id"], local, uv, pc["tris"], picture, _face_mat, style, minf(r.size.x, r.size.y) * scale_k)
		piece.home = frame_rect.position + cen * scale_k
		_pieces.append(piece)
		_loose_layer.add_child(piece)
	_cell = biggest * 1.04 + Vector2(4, 4)
	_scatter()
	_built = true
	queue_redraw()


func _layout(psize: Vector2) -> void:
	var s := table_rect.size
	var short := minf(s.x, s.y)
	var m := roundf(short * 0.045)
	var inner := table_rect.grow(-m)
	var gap := roundf(short * 0.03)
	_border = maxf(3.0, roundf(short * 0.014))
	var portrait := s.y > s.x * 1.05
	var area: Rect2
	if portrait:
		var ph := clampf(s.y * 0.055, 26.0, 84.0)
		area = Rect2(inner.position + Vector2(gap, gap), Vector2(inner.size.x - gap * 2.0, inner.size.y * frame_share * 0.8))
		plaque_rect = Rect2(inner.position.x + inner.size.x * 0.08, inner.end.y - ph - gap * 0.5, inner.size.x * 0.84, ph)
	else:
		var ph := clampf(s.y * 0.1, 26.0, 72.0)
		area = Rect2(inner.position + Vector2(gap, gap), Vector2(inner.size.x * frame_share - gap, inner.size.y - gap * 2.0))
		var pw := minf(inner.size.x * (1.0 - frame_share) - gap * 1.5, ph * 6.6)
		plaque_rect = Rect2(inner.end.x - pw - gap * 0.5, inner.end.y - ph - gap * 0.5, pw, ph)
	scale_k = minf((area.size.x - _border * 2.0) / psize.x, (area.size.y - _border * 2.0) / psize.y)
	var fs := psize * scale_k
	frame_rect = Rect2((area.position + (area.size - fs) * 0.5).round(), fs)


## Lays the pieces out round the tray: each on a spot of its own while there is room, the rest overlapping, every one
## kept wholly on the table and off the tray and the plaque. loose_only re-lays just the pieces not yet placed.
func _scatter(loose_only: bool = false) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_used * 31 + 7
	var todo: Array[JigsawPiece] = []
	for p in _pieces:
		if not (loose_only and p.placed):
			todo.append(p)
	var short := minf(table_rect.size.x, table_rect.size.y)
	var inner := table_rect.grow(-roundf(short * 0.03))
	var blocked := [frame_rect.grow(_border + 3.0), plaque_rect.grow(4.0)]
	var spots: Array[Vector2] = []
	var cols := int(inner.size.x / _cell.x)
	var rows := int(inner.size.y / _cell.y)
	var off := inner.position + (inner.size - Vector2(cols, rows) * _cell) * 0.5
	for r in rows:
		for c in cols:
			var cr := Rect2(off + Vector2(c, r) * _cell, _cell)
			var free := true
			for b: Rect2 in blocked:
				if b.intersects(cr):
					free = false
					break
			if free:
				spots.append(cr.get_center())
	for i in range(spots.size() - 1, 0, -1):
		var j := rng.randi_range(0, i)
		var t := spots[i]
		spots[i] = spots[j]
		spots[j] = t
	# not enough room on its own spot for every piece: the rest overlap, centres kept far enough in that the whole piece
	# stays on the table, and off the tray and the plaque
	var safe := Rect2(inner.position + _cell * 0.5, (inner.size - _cell).max(Vector2.ZERO))
	if safe.size.x < inner.size.x * 0.25 or safe.size.y < inner.size.y * 0.25:
		safe = inner
	var tries := 0
	while spots.size() < todo.size() and tries < 20000:
		tries += 1
		var p := safe.position + Vector2(rng.randf() * safe.size.x, rng.randf() * safe.size.y)
		if frame_rect.grow(_border + _cell.x * 0.3).has_point(p) or plaque_rect.grow(_cell.x * 0.3).has_point(p):
			continue
		spots.append(p)
	for i in todo.size():
		var piece := todo[i]
		var bb := Rect2(piece.outline[0], Vector2.ZERO)
		for q in piece.outline:
			bb = bb.expand(q)
		var slack := (_cell - bb.size) * 0.35
		var spot: Vector2 = spots[i] if i < spots.size() else frame_rect.get_center()
		piece.position = spot - bb.get_center() + Vector2(rng.randf_range(-slack.x, slack.x), rng.randf_range(-slack.y, slack.y))
		piece.set_turn(rng.randi_range(0, 3) if rotation_enabled else 0)


func _on_resize() -> void:
	if not fit_viewport or not _built:
		return
	var placed_ids: Array[int] = []
	for p in _pieces:
		if p.placed:
			placed_ids.append(p.index)
	var was := state
	_keep_seed = true
	_build()
	_keep_seed = false
	for id in placed_ids:
		if id < _pieces.size():
			_place(_pieces[id], false)
	if was == State.PREVIEW:
		preview(showcase_placed)
	else:
		state = was
	_fx.queue_redraw()
	_plaque.queue_redraw()


# --- play ---------------------------------------------------------------------------------------------------------

func _has(action: StringName) -> bool:
	return action != &"" and InputMap.has_action(action)


func _act(event: InputEvent, action: StringName) -> bool:
	if _has(action) and event.is_action_pressed(action):
		return true
	var jb := event as InputEventJoypadButton
	if gamepad_buttons and jb and jb.pressed:
		if action == action_pick:
			return jb.button_index == JOY_BUTTON_A
		if action == action_cancel:
			return jb.button_index == JOY_BUTTON_B
		if action == action_rotate:
			return jb.button_index == JOY_BUTTON_X
	return false


func _local(screen_pos: Vector2) -> Vector2:
	return get_global_transform_with_canvas().affine_inverse() * screen_pos


func _unhandled_input(event: InputEvent) -> void:
	if state == State.ENDING or state == State.DONE:
		if close_on_confirm and _end_t >= ENDING_TIME and not _emitted:
			var mbe := event as InputEventMouseButton
			var click := mbe != null and mbe.pressed
			if click or _act(event, action_pick) or _act(event, action_cancel):
				_finish()
				get_viewport().set_input_as_handled()
		return
	if state != State.PLAYING:
		return
	var touch_direct := not bool(ProjectSettings.get_setting("input_devices/pointing/emulate_mouse_from_touch", true))
	var mb := event as InputEventMouseButton
	var mm := event as InputEventMouseMotion
	var st := event as InputEventScreenTouch
	var sd := event as InputEventScreenDrag
	if mb:
		var p := _local(mb.position)
		if mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				_hand_on = false
				_hand.queue_redraw()
				_pick_at(p)
			elif _held:
				_drop()
			get_viewport().set_input_as_handled()
		elif mb.pressed and (mb.button_index == MOUSE_BUTTON_WHEEL_UP or mb.button_index == MOUSE_BUTTON_WHEEL_DOWN):
			if rotation_enabled and _held:
				_held.set_turn(_held.turn + (1 if mb.button_index == MOUSE_BUTTON_WHEEL_DOWN else -1))
				get_viewport().set_input_as_handled()
		elif mb.pressed and mb.button_index == MOUSE_BUTTON_RIGHT:
			if rotation_enabled:
				var target := _held if _held else _piece_at(p)
				if target:
					target.set_turn(target.turn + 1)
			elif allow_set_aside and not _held:
				set_aside()
			get_viewport().set_input_as_handled()
	elif mm:
		if _hand_on and mm.relative.length() > 0.5:
			_hand_on = false
			_hand.queue_redraw()
		if _held and not _hand_on:
			_held.position = _local(mm.position) + _grab
	elif touch_direct and st:
		if st.pressed:
			_pick_at(_local(st.position))
		elif _held:
			_drop()
		get_viewport().set_input_as_handled()
	elif touch_direct and sd:
		if _held:
			_held.position = _local(sd.position) + _grab
	elif _act(event, action_pick):
		if not _hand_on:
			_show_hand()
		if _held:
			_drop()
		else:
			_pick_at(_hand_pos)
		get_viewport().set_input_as_handled()
	elif _act(event, action_cancel):
		if _held:
			_drop()
		elif allow_set_aside:
			set_aside()
		get_viewport().set_input_as_handled()
	elif _act(event, action_rotate):
		if rotation_enabled:
			var target := _held if _held else (_piece_at(_hand_pos) if _hand_on else null)
			if target:
				target.set_turn(target.turn + 1)
			get_viewport().set_input_as_handled()


func _process(delta: float) -> void:
	if state == State.PLAYING:
		seconds += delta
		if int(seconds) != _shown_seconds:
			_shown_seconds = int(seconds)
			_plaque.queue_redraw()
		if keyboard_hand and _has(action_left) and _has(action_right) and _has(action_up) and _has(action_down):
			var v := Input.get_vector(action_left, action_right, action_up, action_down)
			if v.length() > 0.05:
				if not _hand_on:
					_show_hand()
				var speed := minf(table_rect.size.x, table_rect.size.y) * (1.1 if Input.is_key_pressed(KEY_SHIFT) else 0.5)
				_hand_pos = (_hand_pos + v * speed * delta).clamp(table_rect.position, table_rect.end)
				if _held:
					_held.position = _hand_pos + _grab
				_hand.queue_redraw()
		var want := (_has(action_peek) and Input.is_action_pressed(action_peek)) or (gamepad_buttons and _pad_held(JOY_BUTTON_LEFT_SHOULDER))
		if want and not _peeking:
			peeks += 1
		_peeking = want
		var target := 1.0 if want else 0.0
		if not is_equal_approx(_peek, target):
			_peek = move_toward(_peek, target, delta * 5.0)
			_fx.queue_redraw()
	elif state == State.ENDING or state == State.DONE:
		if _end_t < ENDING_TIME + 0.6:
			_end_t += delta
			for s in _sparks:
				s[0] += s[1] * delta
				s[1] *= 0.94
				s[2] -= delta
			_fx.queue_redraw()
		if state == State.ENDING and _end_t >= ENDING_TIME:
			state = State.DONE
			if not close_on_confirm:
				_finish()


func _pad_held(button: JoyButton) -> bool:
	if Input.is_joy_button_pressed(0, button):
		return true
	for id in Input.get_connected_joypads():
		if Input.is_joy_button_pressed(id, button):
			return true
	return false


func _show_hand() -> void:
	_hand_on = true
	_hand_pos = _held.position if _held else frame_rect.get_center()
	_hand.queue_redraw()


func _piece_at(p: Vector2) -> JigsawPiece:
	var kids := _loose_layer.get_children()
	for i in range(kids.size() - 1, -1, -1):
		var piece := kids[i] as JigsawPiece
		if piece and piece.hit(p):
			return piece
	return null


func _pick_at(p: Vector2) -> void:
	var piece := _piece_at(p)
	if piece == null:
		return
	_held = piece
	_grab = piece.position - p
	piece.lifted = true
	piece.scale = Vector2.ONE * 1.05
	_loose_layer.move_child(piece, _loose_layer.get_child_count() - 1)
	piece.queue_redraw()


func _snap_px() -> float:
	return snap_distance * clampf(minf(table_rect.size.x, table_rect.size.y) / 720.0, 0.4, 3.0)


func _drop() -> void:
	var piece := _held
	_held = null
	moves += 1
	piece.lifted = false
	piece.scale = Vector2.ONE
	if piece.turn == 0 and piece.position.distance_to(piece.home) <= _snap_px():
		_place(piece, true)
		placed_count += 1
		piece_placed.emit(placed_count, _pieces.size())
		if placed_count >= _pieces.size():
			_solve()
	else:
		piece.queue_redraw()
	_plaque.queue_redraw()


func _drop_back() -> void:
	_held.lifted = false
	_held.scale = Vector2.ONE
	_held.queue_redraw()
	_held = null


func _place(piece: JigsawPiece, pulse: bool) -> void:
	piece.placed = true
	piece.lifted = false
	piece.scale = Vector2.ONE
	piece.set_turn(0)
	piece.position = piece.home
	if piece.get_parent() != _placed_layer:
		piece.get_parent().remove_child(piece)
		_placed_layer.add_child(piece)
	if pulse:
		piece.flash = 1.0
		piece.set_process(true)
	piece.queue_redraw()


func _solve() -> void:
	state = State.ENDING
	_end_t = 0.0
	_result = _make_result(true)
	_sparks.clear()
	if style.ending == JigsawStyle.Ending.SPARKLE:
		var rng := RandomNumberGenerator.new()
		rng.seed = seed_used + 5
		for i in 90:
			var edge := rng.randi_range(0, 3)
			var t := rng.randf()
			var p := frame_rect.position + (Vector2(t * frame_rect.size.x, 0.0) if edge == 0 else
				(Vector2(t * frame_rect.size.x, frame_rect.size.y) if edge == 1 else
				(Vector2(0.0, t * frame_rect.size.y) if edge == 2 else Vector2(frame_rect.size.x, t * frame_rect.size.y))))
			var out := (p - frame_rect.get_center()).normalized()
			_sparks.append([p, out.rotated(rng.randf_range(-0.6, 0.6)) * rng.randf_range(60.0, 260.0) * scale_k * 2.0, rng.randf_range(0.6, 1.5), rng.randf_range(2.0, 6.0)])
	solved.emit(_result)
	_fx.queue_redraw()
	_plaque.queue_redraw()


func _finish() -> void:
	if _emitted:
		return
	_emitted = true
	if _result.is_empty():
		_result = _make_result(false)
	finished.emit(_result)


func _make_result(is_solved: bool) -> Dictionary:
	return {"solved": is_solved, "pieces": _pieces.size(), "placed": placed_count, "seconds": int(seconds), "moves": moves,
		"peeks": peeks, "seed": seed_used, "style": style.display_name if style else "",
		"tiling": JigsawCut.TILING_NAMES[style.tiling] if style else "", "edge": JigsawCut.EDGE_NAMES[style.edge] if style else ""}


# --- drawing ------------------------------------------------------------------------------------------------------

func _draw() -> void:
	if style == null:
		return
	if style.draw_table:
		JigsawPaint.table(self, table_rect, style, 1201 + style.table * 7)
	JigsawPaint.tray(self, frame_rect, _border, style, picture, _guides)


func _draw_plaque() -> void:
	if style == null or plaque_rect.size.x < 20.0:
		return
	var done: bool = state == State.ENDING or (state == State.DONE and bool(_result.get("solved", false)))
	JigsawPaint.plaque(_plaque, plaque_rect, style, placed_count, _pieces.size(), int(seconds), moves, done)


func _draw_hand() -> void:
	if _hand_on and state == State.PLAYING:
		JigsawPaint.hand(_hand, _hand_pos, clampf(_cell.y * 0.4, 14.0, 36.0), Color(0.98, 0.95, 0.88), _held != null)


func _draw_fx() -> void:
	if picture == null:
		return
	if _peek > 0.01 and state == State.PLAYING:
		_fx.draw_rect(frame_rect.grow(3.0), Color(0, 0, 0, 0.3 * _peek))
		_fx.draw_texture_rect(picture, frame_rect, false, Color(1, 1, 1, _peek))
	if state != State.ENDING and state != State.DONE:
		return
	if not _result.get("solved", false):
		return
	var t := clampf(_end_t / ENDING_TIME, 0.0, 1.0)
	var e := ease(t, -2.0)
	match style.ending:
		JigsawStyle.Ending.RISE:
			var big := minf(table_rect.size.x * 0.82 / frame_rect.size.x, table_rect.size.y * 0.74 / frame_rect.size.y)
			big = clampf(big, 1.0, 1.25)
			var target := Rect2(table_rect.get_center() - frame_rect.size * big * 0.5 - Vector2(0, table_rect.size.y * 0.04), frame_rect.size * big)
			var r := Rect2(frame_rect.position.lerp(target.position, e), frame_rect.size.lerp(target.size, e))
			_fx.draw_rect(Rect2(r.position + Vector2(6, 10) * e, r.size), Color(0, 0, 0, 0.45 * e))
			_fx.draw_rect(r.grow(_border), style.frame_color)
			_fx.draw_texture_rect(picture, r, false)
			_fx.draw_rect(r.grow(_border * 0.5), Color(style.ending_color, 0.5 * e), false, maxf(1.0, _border * 0.4))
		JigsawStyle.Ending.SPARKLE:
			_fx.draw_texture_rect(picture, frame_rect, false, Color(1, 1, 1, minf(1.0, t * 2.0)))
			for sp in _sparks:
				var life: float = sp[2]
				if life <= 0.0:
					continue
				var c := Color(style.ending_color, clampf(life, 0.0, 1.0))
				var rad: float = sp[3] * clampf(life, 0.2, 1.0) * maxf(0.6, scale_k * 2.0)
				var pp: Vector2 = sp[0]
				_fx.draw_colored_polygon(PackedVector2Array([pp + Vector2(0, -rad), pp + Vector2(rad * 0.25, 0), pp + Vector2(0, rad), pp + Vector2(-rad * 0.25, 0)]), c)
				_fx.draw_colored_polygon(PackedVector2Array([pp + Vector2(-rad, 0), pp + Vector2(0, -rad * 0.25), pp + Vector2(rad, 0), pp + Vector2(0, rad * 0.25)]), c)
		JigsawStyle.Ending.SHINE:
			_fx.draw_texture_rect(picture, frame_rect, false, Color(1, 1, 1, minf(1.0, t * 2.5)))
			var w := frame_rect.size.x
			var x := frame_rect.position.x - w * 0.4 + (w * 1.8) * e
			var bw := w * 0.16
			var band := PackedVector2Array([Vector2(x, frame_rect.position.y), Vector2(x + bw, frame_rect.position.y),
				Vector2(x + bw - frame_rect.size.y * 0.5, frame_rect.end.y), Vector2(x - frame_rect.size.y * 0.5, frame_rect.end.y)])
			var rectp := PackedVector2Array([frame_rect.position, Vector2(frame_rect.end.x, frame_rect.position.y), frame_rect.end, Vector2(frame_rect.position.x, frame_rect.end.y)])
			for part in Geometry2D.intersect_polygons(band, rectp):
				_fx.draw_colored_polygon(part, Color(style.ending_color, 0.45 * (1.0 - absf(e - 0.5))))
			_fx.draw_rect(frame_rect, Color(style.ending_color, 0.6 * e), false, maxf(1.0, _border * 0.4))
		JigsawStyle.Ending.GLOW:
			_fx.draw_texture_rect(picture, frame_rect, false, Color(1, 1, 1, minf(1.0, t * 2.0)))
			var pulse := 0.5 + 0.5 * sin(_end_t * 6.0)
			for k in 5:
				_fx.draw_rect(frame_rect.grow(_border + k * 3.0 * maxf(1.0, scale_k * 2.0)), Color(style.ending_color, (0.35 - k * 0.06) * e * (0.6 + 0.4 * pulse)), false, 2.0 * maxf(1.0, scale_k * 2.0))
