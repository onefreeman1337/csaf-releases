class_name JigsawMinigame
extends CanvasLayer
## Jigsaw for Godot 4 - the one-call minigame. Opens a full-screen puzzle over whatever is running, waits for the
## player to solve it or set it aside, closes itself and hands back the result:
##
##     var result := await JigsawMinigame.open(self, preload("res://art/castle.png"), {
##         "pieces": 48, "style": preload("res://addons/jigsaw/styles/parlour.tres"), "seed": "chapter-3", "pause": true})
##     if result.solved:
##         open_the_gate()
##
## options (all optional): pieces (int, 24), style (JigsawStyle), seed (int or String; blank = new cut every time),
## rotation (bool), pause (bool: pauses the tree while the puzzle is up), layer (int, 64), snap (float, 16),
## set_aside (bool, true: Esc / right click gives up).
## Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.

## The board inside this layer.
var board: JigsawBoard


## Opens a puzzle of `picture` as a layer on top of `host`'s scene and returns the result when it closes:
## {solved, pieces, placed, seconds, moves, peeks, seed, style, tiling, edge}.
static func open(host: Node, picture: Texture2D, options: Dictionary = {}) -> Dictionary:
	var layer := JigsawMinigame.new()
	layer.layer = int(options.get("layer", 64))
	layer.process_mode = Node.PROCESS_MODE_ALWAYS
	var b := JigsawBoard.new()
	b.picture = picture
	b.pieces = int(options.get("pieces", 24))
	b.seed_text = str(options.get("seed", ""))
	b.rotation_enabled = bool(options.get("rotation", false))
	b.snap_distance = float(options.get("snap", 16.0))
	b.allow_set_aside = bool(options.get("set_aside", true))
	if options.get("style") is JigsawStyle:
		b.style = options["style"]
	b.fit_viewport = true
	layer.board = b
	layer.add_child(b)
	var tree := host.get_tree()
	var pause := bool(options.get("pause", false))
	var was_paused := tree.paused
	if pause:
		tree.paused = true
	# deferred: open() may be called from a _ready while the root is still adding children
	tree.root.add_child.call_deferred(layer)
	var result: Dictionary = await b.finished
	if pause:
		tree.paused = was_paused
	layer.queue_free()
	return result
