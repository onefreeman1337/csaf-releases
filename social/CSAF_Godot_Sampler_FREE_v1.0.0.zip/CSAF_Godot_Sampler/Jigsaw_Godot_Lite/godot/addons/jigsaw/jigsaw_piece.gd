class_name JigsawPiece
extends Node2D
## Jigsaw for Godot 4 - one piece. This node draws the shadow and the piece's thickness; a textured Polygon2D child is
## the face (your picture, graded by the style's shader); a second child draws the rim last (bevel, cut line, glow,
## gloss). Light comes from the upper left of the SCREEN, so a turned piece is lit the same way as the rest.
## Built by JigsawBoard; you never need to make one yourself.
## Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.

const LIGHT := Vector2(-0.70710678, -0.70710678)

## Index of this piece in the board's cut.
var index := 0
## Where this piece's centre sits (board space) when it is in place.
var home := Vector2.ZERO
## True once the piece has clicked into place.
var placed := false
## True while the player carries it.
var lifted := false
## Quarter turns away from upright (0 = upright).
var turn := 0
## 1 right after the piece clicks in, fading to 0.
var flash := 0.0

var style: JigsawStyle
var outline := PackedVector2Array()
var face: Polygon2D
var rim: Node2D
var size_px := 32.0
var _inward := PackedVector2Array()
var _tris := PackedInt32Array()
var _shadow: Array[PackedVector2Array] = []
var _shadow_tris: Array[PackedInt32Array] = []
var _closed := PackedVector2Array()
var _wobble := PackedVector2Array()


## Builds the piece. local_outline is in board pixels round this piece's centre; uv is the same outline in picture
## pixels; tris is the cut's triangulation of that outline (JigsawCut, done once in picture pixels, reused at any
## scale); size is the piece's smaller side in board pixels (it sets the bevel, line and shadow widths).
func setup(p_index: int, local_outline: PackedVector2Array, uv: PackedVector2Array, tris: PackedInt32Array, picture: Texture2D,
		face_material: Material, p_style: JigsawStyle, size: float) -> void:
	index = p_index
	outline = local_outline
	_tris = tris
	style = p_style
	size_px = maxf(4.0, size)
	face = Polygon2D.new()
	face.name = "Face"
	face.polygon = outline
	face.uv = uv
	if _tris.size() >= 3:
		var parts: Array = []
		for i in range(0, _tris.size(), 3):
			parts.append(PackedInt32Array([_tris[i], _tris[i + 1], _tris[i + 2]]))
		face.polygons = parts
	face.texture = picture
	face.material = face_material
	face.antialiased = style.finish != JigsawStyle.Finish.PIXEL
	if style.finish == JigsawStyle.Finish.PIXEL or style.face_pixels > 0.0:
		face.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	add_child(face)
	rim = Node2D.new()
	rim.name = "Rim"
	add_child(rim)
	rim.draw.connect(_draw_rim)
	_closed = outline.duplicate()
	_closed.append(outline[0])
	_build_normals()
	var b := bevel_px()
	_shadow.clear()
	_shadow_tris.clear()
	for grow in [b * 1.6, b * 0.8]:
		var polys := Geometry2D.offset_polygon(outline, grow, Geometry2D.JOIN_ROUND)
		var sp: PackedVector2Array = polys[0] if polys.size() > 0 else outline
		var st := Geometry2D.triangulate_polygon(sp)
		# an offset outline the triangulator refuses (MEASURED: 1 of 173,472, a 0.22x porcelain piece) falls back
		_shadow.append(sp if st.size() >= 3 else outline)
		_shadow_tris.append(st if st.size() >= 3 else _tris)
	_shadow.append(outline)
	_shadow_tris.append(_tris)
	if style.finish == JigsawStyle.Finish.INK:
		var rng := RandomNumberGenerator.new()
		rng.seed = 7919 + index * 31
		_wobble = PackedVector2Array()
		for i in _closed.size():
			var j := i % outline.size()
			_wobble.append(_closed[i] + _inward[j] * (line_px() * (0.6 + rng.randf() * 1.4)))


## The lit bevel's width in board pixels.
func bevel_px() -> float:
	return clampf(size_px * 0.035 * style.bevel, 0.0, 14.0)


## The cut line's width in board pixels.
func line_px() -> float:
	return maxf(0.5, size_px * 0.012) * style.edge_width


## The thickness shown under the piece in board pixels.
func thickness_px() -> float:
	return size_px * 0.06 * style.thickness


## True when a point in the parent's space lies on this piece.
func hit(point: Vector2) -> bool:
	return Geometry2D.is_point_in_polygon(transform.affine_inverse() * point, outline)


## Turns the piece to a number of quarter turns and redraws its light.
func set_turn(q: int) -> void:
	turn = posmod(q, 4)
	rotation = turn * PI * 0.5
	queue_redraw()
	if rim:
		rim.queue_redraw()


func _ready() -> void:
	set_process(flash > 0.0)


func _process(delta: float) -> void:
	flash = maxf(0.0, flash - delta * 2.2)
	rim.queue_redraw()
	if flash <= 0.0:
		set_process(false)


func _build_normals() -> void:
	var n := outline.size()
	_inward.resize(n)
	var seg := PackedVector2Array()
	seg.resize(n)
	for i in n:
		var d := (outline[(i + 1) % n] - outline[i])
		var l := d.length()
		seg[i] = Vector2(-d.y, d.x) / l if l > 0.0001 else Vector2.ZERO
	for i in n:
		var a := seg[(i - 1 + n) % n]
		var c := seg[i]
		var m := a + c
		if m.length() < 0.0001:
			m = c
		m = m.normalized()
		var k := m.dot(c)
		_inward[i] = m / clampf(k, 0.5, 1.0)


func _draw() -> void:
	var inv := -rotation
	var b := maxf(1.0, bevel_px())
	# shadow: soft layers, deeper when the piece is lifted, almost none once placed
	var sc := style.shadow_color
	if style.finish != JigsawStyle.Finish.NEON or not placed:
		var reach := 0.35 if placed else (3.2 if lifted else 1.0)
		var off := Vector2(0.75, 1.0) * b * reach * (1.0 + thickness_px() / maxf(1.0, b) * 0.4)
		if style.finish == JigsawStyle.Finish.PIXEL:
			draw_set_transform((Vector2(1, 1) * maxf(2.0, b * 1.2) * (2.0 if lifted else (0.0 if placed else 1.0))).rotated(inv))
			if not placed:
				_fill(self, outline, _tris, Color(sc.r, sc.g, sc.b, sc.a * 1.2))
		else:
			var alphas := [0.22, 0.32, 0.46]
			if lifted:
				alphas = [0.16, 0.22, 0.3]
			for i in _shadow.size():
				draw_set_transform((off * (1.0 + 0.5 * (2 - i) * (1.0 if lifted else 0.5))).rotated(inv))
				_fill(self, _shadow[i], _shadow_tris[i], Color(sc.r, sc.g, sc.b, sc.a * alphas[i] * (0.5 if placed else 1.0)))
		draw_set_transform(Vector2.ZERO)
	# thickness: the piece's side, stacked toward the lower right
	var t := thickness_px()
	if t > 0.5 and not placed:
		var layers := clampi(int(ceil(t)), 1, 10)
		for i in range(layers, 0, -1):
			var f := float(i) / layers
			draw_set_transform((Vector2(0.55, 0.8) * t * f).rotated(inv))
			_fill(self, outline, _tris, style.side_color.darkened(0.35 * f))
		draw_set_transform(Vector2.ZERO)
	elif t > 0.5:
		draw_set_transform((Vector2(0.55, 0.8) * minf(t, b) * 0.6).rotated(inv))
		_fill(self, outline, _tris, style.side_color.darkened(0.3))
		draw_set_transform(Vector2.ZERO)


## Fills a polygon from its precomputed triangles (never re-triangulated at draw time).
static func _fill(ci: CanvasItem, pts: PackedVector2Array, tris: PackedInt32Array, col: Color) -> void:
	if tris.size() >= 3:
		RenderingServer.canvas_item_add_triangle_array(ci.get_canvas_item(), tris, pts, PackedColorArray([col]))


func _draw_rim() -> void:
	var f := style.finish
	var b := bevel_px()
	var lw := line_px()
	var n := outline.size()
	var world_light := LIGHT.rotated(-rotation)
	# the bevel: a strip inside the outline, lit by the angle each stretch of edge faces
	if b > 0.2 and f != JigsawStyle.Finish.PIXEL:
		var pts := PackedVector2Array()
		var cols := PackedColorArray()
		var idx := PackedInt32Array()
		var even := f in [JigsawStyle.Finish.FROST, JigsawStyle.Finish.PAPER]
		for i in n:
			var outward := -_inward[i].normalized()
			var k := outward.dot(world_light)
			var c: Color
			if even:
				c = style.rim_light
			elif k >= 0.0:
				c = Color(style.rim_light, style.rim_light.a * k)
			else:
				c = Color(style.rim_shade, style.rim_shade.a * -k)
			pts.append(outline[i])
			pts.append(outline[i] + _inward[i] * b)
			cols.append(c)
			cols.append(Color(c, c.a if f == JigsawStyle.Finish.PAPER else 0.0))
		for i in n:
			var o0 := i * 2
			var o1 := ((i + 1) % n) * 2
			idx.append_array(PackedInt32Array([o0, o1, o1 + 1, o0, o1 + 1, o0 + 1]))
		RenderingServer.canvas_item_add_triangle_array(rim.get_canvas_item(), idx, pts, cols)
	# a sheen: linear, brightest at the lit corner
	if style.gloss > 0.0:
		var ext := 1.0
		for p in outline:
			ext = maxf(ext, absf(p.dot(world_light)))
		var gcol := PackedColorArray()
		for p in outline:
			var tt := p.dot(world_light) / ext
			gcol.append(Color(1, 1, 1, style.gloss * clampf(tt * 0.6 + 0.15, 0.0, 1.0)))
		if _tris.size() >= 3:
			RenderingServer.canvas_item_add_triangle_array(rim.get_canvas_item(), _tris, outline, gcol)
	match f:
		# the wide, soft glow strokes skip antialiasing (it doubles their geometry; MEASURED 256 neon pieces, Compatibility)
		JigsawStyle.Finish.NEON:
			rim.draw_polyline(_closed, Color(style.glow_color, 0.1), lw * 7.0, false)
			rim.draw_polyline(_closed, Color(style.glow_color, 0.24), lw * 3.5, false)
			rim.draw_polyline(_closed, Color(style.glow_color, 0.95), lw * 1.3, true)
			rim.draw_polyline(_closed, Color(1, 1, 1, 0.75), lw * 0.45, true)
		JigsawStyle.Finish.GILDED:
			rim.draw_polyline(_closed, style.edge_color.darkened(0.45), lw * 2.6, true)
			rim.draw_polyline(_closed, style.edge_color, lw * 1.7, true)
			rim.draw_polyline(_inset(lw * 0.35), Color(style.ending_color, 0.85), lw * 0.5, true)
		JigsawStyle.Finish.INK:
			rim.draw_polyline(_closed, style.edge_color, lw * 1.2, true)
			rim.draw_polyline(_wobble, Color(style.edge_color, style.edge_color.a * 0.45), lw * 0.6, true)
		JigsawStyle.Finish.PAPER:
			rim.draw_polyline(_closed, style.edge_color, lw * 0.8, true)
		_:
			rim.draw_polyline(_closed, style.edge_color, lw, true)
	if flash > 0.0:
		rim.draw_polyline(_closed, Color(style.ending_color, flash * 0.9), lw * 2.5 + b, true)


func _inset(d: float) -> PackedVector2Array:
	var out := PackedVector2Array()
	for i in _closed.size():
		var j := i % outline.size()
		out.append(_closed[i] + _inward[j] * d)
	return out
