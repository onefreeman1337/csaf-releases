@tool
class_name JigsawStyle
extends Resource
## Jigsaw for Godot 4 - one look for a puzzle: how it is cut, how a piece is finished, the table it is laid on, the
## frame, the plaque and the ending. The 48 styles in addons/jigsaw/styles/ are instances of this; duplicate one and
## move any slider to make your own. Every colour is a parameter, never a new style.
## Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.

enum Finish { CARD, WOOD, GLASS, GILDED, PORCELAIN, INK, PIXEL, NEON, FROST, SLAB, METAL, PAPER }
enum Table { FELT, SLATE, PARCHMENT, VELVET, TATAMI, MARBLE, PLANKS, NEON_GRID, PIXEL_TILES, LEATHER, SNOW, STARFIELD }
enum Ending { RISE, SPARKLE, SHINE, GLOW }

const FINISH_NAMES := ["card", "wood", "glass", "gilded", "porcelain", "ink", "pixel", "neon", "frost", "slab", "metal", "paper"]
const TABLE_NAMES := ["felt", "slate", "parchment", "velvet", "tatami", "marble", "planks", "neon_grid", "pixel_tiles", "leather", "snow", "starfield"]

@export var display_name := "Parlour"

@export_group("Cut")
## How the picture is divided (see JigsawCut.Tiling).
@export_enum("Grid", "Brick", "Hex", "Triangle", "Diamond", "Rings", "Shard") var tiling := 0
## The curve every shared side is drawn with (see JigsawCut.Edge).
@export_enum("Straight", "Classic", "Bulb", "Petite", "Twin", "Wave", "Dovetail", "Crenel", "Saw", "Button", "Lean") var edge := 1
## How far inner corners wander, as a share of a piece.
@export_range(0.0, 0.35, 0.01) var corner_jitter := 0.05
## Size of every tab and socket.
@export_range(0.5, 1.6, 0.01) var knob_scale := 1.0
## How much each tab leans and wobbles.
@export_range(0.0, 0.1, 0.005) var wobble := 0.035
## Pixel-art sides on grid and brick cuts: steps of this many picture pixels (0 = smooth).
@export_range(0.0, 32.0, 1.0) var pixel_steps := 0.0

@export_group("Piece")
@export_enum("Card", "Wood", "Glass", "Gilded", "Porcelain", "Ink", "Pixel", "Neon", "Frost", "Slab", "Metal", "Paper") var finish := 0
## Width of the lit bevel round each piece, x the default for its size.
@export_range(0.0, 3.0, 0.05) var bevel := 1.0
## Colour of the light side of the bevel.
@export var rim_light := Color(1.0, 0.96, 0.88, 0.3)
## Colour of the shaded side of the bevel.
@export var rim_shade := Color(0.08, 0.05, 0.02, 0.42)
## The cut line itself.
@export var edge_color := Color(0.19, 0.15, 0.1, 0.85)
## Width of the cut line, x the default for the piece size.
@export_range(0.0, 6.0, 0.05) var edge_width := 1.0
## The colour of a piece's thickness (wood, slab and metal finishes show it).
@export var side_color := Color(0.35, 0.24, 0.14, 1.0)
## Thickness shown under a piece, x the default for its size (0 = flat card).
@export_range(0.0, 4.0, 0.05) var thickness := 0.0
## Glow round the edges (neon, frost and glass finishes use it).
@export var glow_color := Color(0.3, 0.9, 1.0, 1.0)
## Shadow under a loose piece.
@export var shadow_color := Color(0.0, 0.0, 0.0, 0.42)
## Picture tint and grade on the piece faces.
@export var face_tint := Color(1, 1, 1, 1)
@export_range(0.0, 2.0, 0.01) var face_saturation := 1.0
@export_range(0.2, 2.0, 0.01) var face_brightness := 1.0
@export_range(0.0, 1.0, 0.01) var face_sepia := 0.0
## Posterise the faces to this many levels per channel (0 = off).
@export_range(0.0, 16.0, 1.0) var face_posterize := 0.0
## Pixelate the faces: one block per this many picture pixels (0 = off).
@export_range(0.0, 32.0, 1.0) var face_pixels := 0.0
## A diagonal sheen across each piece (porcelain, glass).
@export_range(0.0, 1.0, 0.01) var gloss := 0.0

@export_group("Table")
@export_enum("Felt", "Slate", "Parchment", "Velvet", "Tatami", "Marble", "Planks", "Neon Grid", "Pixel Tiles", "Leather", "Snow", "Starfield") var table := 0
## The table's main colour, its second colour and its accent (rim, veins, stitching, grid lines, stars).
@export var table_main := Color(0.14, 0.27, 0.23, 1.0)
@export var table_second := Color(0.35, 0.23, 0.13, 1.0)
@export var table_accent := Color(1.0, 0.94, 0.82, 1.0)
## Darkening at the table's edges.
@export_range(0.0, 1.0, 0.01) var vignette := 0.38
## Draw the table at all (off = pieces and frame over your own scene).
@export var draw_table := true

@export_group("Frame")
## The tray the picture is assembled in.
@export var frame_color := Color(0.22, 0.15, 0.09, 1.0)
@export var tray_color := Color(0.07, 0.1, 0.09, 1.0)
## How strongly the picture shows through in the empty tray (0 = not at all).
@export_range(0.0, 0.6, 0.01) var ghost := 0.16
## How strongly the cut lines are printed in the empty tray.
@export_range(0.0, 1.0, 0.01) var guides := 0.18

@export_group("Plaque")
@export var plaque_color := Color(0.16, 0.11, 0.07, 0.94)
@export var plaque_ink := Color(0.96, 0.88, 0.7, 1.0)
@export var seal_color := Color(0.62, 0.1, 0.1, 1.0)
## A font for the plaque's numbers; empty = the drawn numerals (no font file needed).
@export var font: Font

@export_group("Ending")
@export_enum("Rise", "Sparkle", "Shine", "Glow") var ending := 0
@export var ending_color := Color(1.0, 0.92, 0.6, 1.0)


## The options JigsawCut.cut() takes, from this style.
func cut_options() -> Dictionary:
	return {"tiling": tiling, "edge": edge, "corner_jitter": corner_jitter, "knob_scale": knob_scale, "wobble": wobble,
		"pixel_snap": pixel_steps}
