class_name JigsawPaint
extends RefCounted
## Jigsaw for Godot 4 - everything around the pieces, drawn in code: twelve tables, the tray, the plaque with its own
## drawn numerals (no font file needed), the wax seal, the keyboard hand. Static functions that draw onto any
## CanvasItem during its draw. Seeded, so a table looks the same every time.
## Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.

const GLYPHS := {
	"1": [[Vector2(0.25, 0.4), Vector2(0.55, 0.1), Vector2(0.55, 1.5)], [Vector2(0.25, 1.5), Vector2(0.85, 1.5)]],
	"2": [[Vector2(0.12, 0.42), Vector2(0.2, 0.2), Vector2(0.45, 0.08), Vector2(0.75, 0.12), Vector2(0.88, 0.38),
		Vector2(0.8, 0.65), Vector2(0.12, 1.5), Vector2(0.9, 1.5)]],
	"3": [[Vector2(0.12, 0.22), Vector2(0.4, 0.08), Vector2(0.75, 0.14), Vector2(0.85, 0.4), Vector2(0.68, 0.68), Vector2(0.4, 0.75)],
		[Vector2(0.55, 0.74), Vector2(0.85, 0.95), Vector2(0.88, 1.25), Vector2(0.62, 1.5), Vector2(0.3, 1.52), Vector2(0.1, 1.36)]],
	"4": [[Vector2(0.72, 1.52), Vector2(0.72, 0.08), Vector2(0.08, 1.08), Vector2(0.95, 1.08)]],
	"5": [[Vector2(0.86, 0.1), Vector2(0.22, 0.1), Vector2(0.16, 0.72), Vector2(0.45, 0.62), Vector2(0.78, 0.75), Vector2(0.9, 1.08),
		Vector2(0.75, 1.4), Vector2(0.45, 1.53), Vector2(0.12, 1.4)]],
	"6": [[Vector2(0.8, 0.16), Vector2(0.5, 0.08), Vector2(0.22, 0.3), Vector2(0.12, 0.8), Vector2(0.18, 1.3), Vector2(0.48, 1.53),
		Vector2(0.8, 1.4), Vector2(0.9, 1.08), Vector2(0.75, 0.82), Vector2(0.48, 0.75), Vector2(0.2, 0.92)]],
	"7": [[Vector2(0.1, 0.1), Vector2(0.9, 0.1), Vector2(0.38, 1.52)]],
	"9": [[Vector2(0.85, 0.62), Vector2(0.6, 0.82), Vector2(0.3, 0.78), Vector2(0.12, 0.5), Vector2(0.25, 0.15), Vector2(0.55, 0.08),
		Vector2(0.85, 0.25), Vector2(0.9, 0.75), Vector2(0.78, 1.28), Vector2(0.5, 1.52), Vector2(0.18, 1.42)]],
	"/": [[Vector2(0.85, 0.05), Vector2(0.15, 1.55)]],
}


static func _rng(seed_value: int) -> RandomNumberGenerator:
	var r := RandomNumberGenerator.new()
	r.seed = seed_value
	return r


## closed repeats the first point at the end (for polylines); a filled polygon must not repeat it.
static func _ellipse(c: Vector2, rx: float, ry: float, n: int = 24, closed: bool = true) -> PackedVector2Array:
	var out := PackedVector2Array()
	for i in (n + 1 if closed else n):
		out.append(c + Vector2(cos(TAU * i / n) * rx, sin(TAU * i / n) * ry))
	return out


static func _wavy(a: Vector2, b: Vector2, amp: float, r: RandomNumberGenerator, n: int = 12) -> PackedVector2Array:
	var out := PackedVector2Array()
	var nrm := (b - a).orthogonal().normalized()
	var p1 := r.randf() * TAU
	var p2 := r.randf() * TAU
	for i in n + 1:
		var t := float(i) / n
		out.append(a.lerp(b, t) + nrm * amp * (sin(t * 5.0 + p1) * 0.7 + sin(t * 11.0 + p2) * 0.3))
	return out


## Darkens a rect's edges with a smooth falloff (a ring mesh from an inner ellipse to the rect's border).
static func vignette(ci: CanvasItem, rect: Rect2, strength: float, col: Color = Color.BLACK, inner: float = 0.5) -> void:
	if strength <= 0.0:
		return
	var c := rect.get_center()
	var hs := rect.size * 0.5
	var angles: Array[float] = []
	for i in 48:
		angles.append(TAU * i / 48.0)
	for corner in [hs, Vector2(-hs.x, hs.y), -hs, Vector2(hs.x, -hs.y)]:
		angles.append(fposmod(corner.angle(), TAU))
	angles.sort()
	var pts := PackedVector2Array()
	var cols := PackedColorArray()
	for a in angles:
		var d := Vector2.from_angle(a)
		var t := minf(hs.x / maxf(0.0001, absf(d.x)), hs.y / maxf(0.0001, absf(d.y)))
		pts.append(c + d * t)
		pts.append(c + Vector2(d.x * hs.x, d.y * hs.y) * inner)
		cols.append(Color(col, strength))
		cols.append(Color(col, 0.0))
	var idx := PackedInt32Array()
	var n := angles.size()
	for i in n:
		var o0 := i * 2
		var o1 := ((i + 1) % n) * 2
		idx.append_array(PackedInt32Array([o0, o1, o1 + 1, o0, o1 + 1, o0 + 1]))
	RenderingServer.canvas_item_add_triangle_array(ci.get_canvas_item(), idx, pts, cols)


static func _vgrad(ci: CanvasItem, rect: Rect2, top: Color, bottom: Color) -> void:
	ci.draw_polygon(PackedVector2Array([rect.position, Vector2(rect.end.x, rect.position.y), rect.end, Vector2(rect.position.x, rect.end.y)]),
		PackedColorArray([top, top, bottom, bottom]))


static func _soft_dot(ci: CanvasItem, c: Vector2, r: float, col: Color) -> void:
	for k in 3:
		ci.draw_circle(c, r * (1.0 - k * 0.3), Color(col, col.a * 0.45))


## The table under everything, by kind. seed_value keeps it the same every time.
static func table(ci: CanvasItem, rect: Rect2, s: JigsawStyle, seed_value: int) -> void:
	var r := _rng(seed_value * 7 + 13)
	var m := roundf(minf(rect.size.x, rect.size.y) * 0.045)
	var u := minf(rect.size.x, rect.size.y) / 720.0
	match s.table:
		JigsawStyle.Table.FELT:
			ci.draw_rect(rect, s.table_second)
			for i in 70:
				var y := rect.position.y + r.randf() * rect.size.y
				var a := Vector2(rect.position.x, y)
				var b := Vector2(rect.end.x, y + (r.randf() - 0.5) * 20.0 * u)
				var light := i % 2 == 1
				ci.draw_polyline(_wavy(a, b, 6.0 * u, r), Color(1.0, 0.86, 0.66, 0.06 + r.randf() * 0.05) if light else Color(0.12, 0.06, 0.02, 0.07 + r.randf() * 0.06), (1.0 + r.randf() * 2.5) * u, true)
			var mat := rect.grow(-m)
			ci.draw_rect(mat, s.table_main)
			for i in 1100:
				var p := mat.position + Vector2(r.randf() * mat.size.x, r.randf() * mat.size.y)
				ci.draw_rect(Rect2(p, Vector2.ONE * (1.0 + r.randf() * 1.6) * u), Color(1, 1, 1, 0.03) if r.randf() < 0.5 else Color(0, 0, 0, 0.045))
			ci.draw_rect(mat.grow(-1.5 * u), Color(0, 0, 0, 0.45), false, 3.0 * u)
			ci.draw_rect(mat.grow(0.5), Color(s.table_accent, 0.18), false, 1.0)
			vignette(ci, mat, s.vignette * 0.8, Color.BLACK, 0.45)
		JigsawStyle.Table.SLATE:
			ci.draw_rect(rect, s.table_main)
			for i in 150:
				var c := rect.position + Vector2(r.randf() * rect.size.x, r.randf() * rect.size.y)
				_soft_dot(ci, c, (10.0 + r.randf() * 50.0) * u, Color(s.table_second if r.randf() < 0.6 else s.table_main.lightened(0.12), 0.06))
			for i in 70:
				var a := rect.position + Vector2(r.randf() * rect.size.x, r.randf() * rect.size.y)
				ci.draw_line(a, a + Vector2.from_angle(r.randf() * TAU) * (6.0 + r.randf() * 30.0) * u, Color(s.table_accent, 0.05 + r.randf() * 0.05), 1.0)
			ci.draw_rect(rect.grow(-m * 0.5), Color(s.table_accent, 0.35), false, 2.0 * u)
			ci.draw_rect(rect.grow(-m * 0.5 - 4.0 * u), Color(s.table_accent, 0.14), false, 1.0)
		JigsawStyle.Table.PARCHMENT:
			ci.draw_rect(rect, s.table_main)
			for i in 34:
				var c := rect.position + Vector2(r.randf() * rect.size.x, r.randf() * rect.size.y)
				_soft_dot(ci, c, (30.0 + r.randf() * 90.0) * u, Color(s.table_second, 0.05))
			for i in 420:
				var a := rect.position + Vector2(r.randf() * rect.size.x, r.randf() * rect.size.y)
				var b := a + Vector2.from_angle(r.randf() * PI * 0.25 - PI * 0.125) * (8.0 + r.randf() * 26.0) * u
				ci.draw_line(a, b, Color(s.table_second, 0.06), 1.0)
			_compass(ci, rect.position + Vector2(rect.size.x * 0.84, rect.size.y * 0.2), 60.0 * u, Color(s.table_accent, 0.22))
			vignette(ci, rect, s.vignette, s.table_second.darkened(0.4), 0.55)
		JigsawStyle.Table.VELVET:
			ci.draw_rect(rect, s.table_main)
			vignette(ci, rect, 0.5, s.table_second, 0.05)
			for i in 260:
				var c := rect.position + Vector2(r.randf() * rect.size.x, r.randf() * rect.size.y)
				var e := _ellipse(c, (12.0 + r.randf() * 30.0) * u, (2.0 + r.randf() * 5.0) * u, 10, false)
				var rot := r.randf() * TAU
				for k in e.size():
					e[k] = c + (e[k] - c).rotated(rot)
				ci.draw_colored_polygon(e, Color(s.table_second, 0.05) if r.randf() < 0.5 else Color(0, 0, 0, 0.06))
			for i in 140:
				ci.draw_circle(rect.position + Vector2(r.randf() * rect.size.x, r.randf() * rect.size.y), (0.5 + r.randf() * 1.1) * u, Color(s.table_accent, 0.2 + r.randf() * 0.4))
			vignette(ci, rect, s.vignette, Color.BLACK, 0.5)
		JigsawStyle.Table.TATAMI:
			var rows := 2
			var mh := rect.size.y / rows
			var band := 9.0 * u
			for row in rows:
				var mr := Rect2(rect.position + Vector2(0, row * mh), Vector2(rect.size.x, mh))
				ci.draw_rect(mr, s.table_main)
				var yy := mr.position.y
				var k := 0
				while yy < mr.end.y:
					ci.draw_rect(Rect2(mr.position.x, yy, mr.size.x, 2.0 * u), Color(0, 0, 0, 0.07) if k % 2 == 0 else Color(1, 1, 0.9, 0.05))
					yy += 3.4 * u
					k += 1
				for side: float in [mr.position.y, mr.end.y - band]:
					ci.draw_rect(Rect2(mr.position.x, side, mr.size.x, band), s.table_second)
					var x := mr.position.x + 6.0 * u
					while x < mr.end.x:
						var cy := side + band * 0.5
						ci.draw_colored_polygon(PackedVector2Array([Vector2(x, cy - band * 0.3), Vector2(x + band * 0.3, cy), Vector2(x, cy + band * 0.3), Vector2(x - band * 0.3, cy)]), Color(s.table_accent, 0.7))
						x += band * 1.4
			ci.draw_line(Vector2(rect.position.x + rect.size.x * 0.62, rect.position.y), Vector2(rect.position.x + rect.size.x * 0.62, rect.position.y + mh), Color(0, 0, 0, 0.25), 2.0 * u)
			vignette(ci, rect, s.vignette, Color.BLACK, 0.5)
		JigsawStyle.Table.MARBLE:
			ci.draw_rect(rect, s.table_main)
			for i in 60:
				var c := rect.position + Vector2(r.randf() * rect.size.x, r.randf() * rect.size.y)
				_soft_dot(ci, c, (40.0 + r.randf() * 110.0) * u, Color(s.table_second, 0.035))
			for i in 16:
				var p := rect.position + Vector2(r.randf() * rect.size.x, r.randf() * rect.size.y)
				var ang := r.randf() * TAU
				var line := PackedVector2Array([p])
				for k in 46:
					ang += (r.randf() - 0.5) * 0.7
					p += Vector2.from_angle(ang) * (10.0 + r.randf() * 12.0) * u
					line.append(p)
				var gold := i < 3
				ci.draw_polyline(line, Color(s.table_accent if gold else s.table_second, 0.55 if gold else 0.2 + r.randf() * 0.25), (0.6 + r.randf() * (1.0 if gold else 2.0)) * u, true)
			vignette(ci, rect, s.vignette, s.table_second.darkened(0.5), 0.55)
		JigsawStyle.Table.LEATHER:
			ci.draw_rect(rect, s.table_main)
			for i in 700:
				ci.draw_circle(rect.position + Vector2(r.randf() * rect.size.x, r.randf() * rect.size.y), (0.8 + r.randf() * 2.4) * u, Color(s.table_second, 0.07))
			for i in 46:
				var a := rect.position + Vector2(r.randf() * rect.size.x, r.randf() * rect.size.y)
				ci.draw_polyline(_wavy(a, a + Vector2.from_angle(r.randf() * TAU) * (20.0 + r.randf() * 50.0) * u, 3.0 * u, r, 8), Color(s.table_second, 0.12), 1.2 * u, true)
			var inner := rect.grow(-m)
			ci.draw_rect(inner, Color(0, 0, 0, 0.35), false, 3.0 * u)
			ci.draw_rect(inner.grow(-2.0 * u), Color(s.table_main.lightened(0.25), 0.4), false, 1.0)
			var st := inner.grow(m * 0.42)
			var corners := [st.position, Vector2(st.end.x, st.position.y), st.end, Vector2(st.position.x, st.end.y)]
			for k in 4:
				var a: Vector2 = corners[k]
				var b: Vector2 = corners[(k + 1) % 4]
				var span := a.distance_to(b)
				var d := (b - a) / span
				var x := 0.0
				while x < span:
					ci.draw_line(a + d * x, a + d * minf(span, x + 7.0 * u), Color(s.table_accent, 0.8), 1.6 * u)
					x += 12.0 * u
				var cc: Vector2 = corners[k]
				var q := 9.0 * u
				ci.draw_colored_polygon(PackedVector2Array([cc + Vector2(0, -q), cc + Vector2(q, 0), cc + Vector2(0, q), cc + Vector2(-q, 0)]), Color(s.table_accent, 0.7))
			vignette(ci, rect, s.vignette, Color.BLACK, 0.5)
		_:
			ci.draw_rect(rect, s.table_main)
			vignette(ci, rect, s.vignette, Color.BLACK, 0.5)


static func _compass(ci: CanvasItem, c: Vector2, r: float, col: Color) -> void:
	ci.draw_arc(c, r, 0, TAU, 48, col, 1.5, true)
	ci.draw_arc(c, r * 0.82, 0, TAU, 48, col, 1.0, true)
	for i in 16:
		var d := Vector2.from_angle(i * TAU / 16.0)
		ci.draw_line(c + d * r * 0.82, c + d * r, col, 1.0, true)
	for i in 4:
		var d := Vector2.from_angle(i * PI * 0.5 - PI * 0.5)
		var sd := d.orthogonal() * r * 0.12
		ci.draw_colored_polygon(PackedVector2Array([c + d * r * 1.1, c + sd, c - sd]), col)
	for i in 4:
		var d := Vector2.from_angle(i * PI * 0.5 - PI * 0.25)
		var sd := d.orthogonal() * r * 0.08
		ci.draw_colored_polygon(PackedVector2Array([c + d * r * 0.6, c + sd, c - sd]), Color(col, col.a * 0.7))


## The tray: a frame round the picture's place, the tray floor, the ghost picture and the printed cut lines.
static func tray(ci: CanvasItem, frame: Rect2, border: float, s: JigsawStyle, picture: Texture2D, guides: Array) -> void:
	var outer := frame.grow(border)
	ci.draw_rect(outer.grow(border * 0.6), Color(0, 0, 0, 0.22))
	ci.draw_rect(outer, s.frame_color)
	ci.draw_line(outer.position, Vector2(outer.end.x, outer.position.y), s.frame_color.lightened(0.3), maxf(1.0, border * 0.25))
	ci.draw_line(outer.position, Vector2(outer.position.x, outer.end.y), s.frame_color.lightened(0.2), maxf(1.0, border * 0.25))
	ci.draw_line(Vector2(outer.position.x, outer.end.y), outer.end, s.frame_color.darkened(0.4), maxf(1.0, border * 0.25))
	ci.draw_line(Vector2(outer.end.x, outer.position.y), outer.end, s.frame_color.darkened(0.35), maxf(1.0, border * 0.25))
	ci.draw_rect(frame, s.tray_color)
	if picture and s.ghost > 0.0:
		ci.draw_texture_rect(picture, frame, false, Color(1, 1, 1, s.ghost))
	for k in 3:
		var w := (3.0 - k) * maxf(1.0, border * 0.35)
		ci.draw_line(frame.position + Vector2(0, w * 0.5), Vector2(frame.end.x, frame.position.y + w * 0.5), Color(0, 0, 0, 0.16), w)
		ci.draw_line(frame.position + Vector2(w * 0.5, 0), Vector2(frame.position.x + w * 0.5, frame.end.y), Color(0, 0, 0, 0.12), w)
	if s.guides > 0.0:
		var gc := Color(s.edge_color, s.guides) if s.finish != JigsawStyle.Finish.NEON else Color(s.glow_color, s.guides)
		for g in guides:
			ci.draw_polyline(g, gc, 1.0, true)


## Numerals drawn as strokes (0-9, "/", ":"); h = cap height in pixels. Returns the width drawn.
static func numerals(ci: CanvasItem, text: String, pos: Vector2, h: float, col: Color, font: Font = null) -> float:
	if font:
		var fs := int(maxf(6.0, h * 1.25))
		ci.draw_string(font, pos + Vector2(0, h), text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, col)
		return font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
	var sc := h / 1.6
	var lw := maxf(1.0, h * 0.13)
	var x := 0.0
	for ch in text:
		var adv := 0.62 * h
		if ch == ":":
			adv = 0.36 * h
			for dy in [0.55, 1.2]:
				ci.draw_circle(pos + Vector2(x + adv * 0.5, dy * sc), lw * 0.75, col)
		elif ch == "0" or ch == "8":
			var shapes: Array = []
			if ch == "0":
				shapes.append(_ellipse(Vector2(0.5, 0.8), 0.4, 0.72, 20))
			else:
				shapes.append(_ellipse(Vector2(0.5, 0.43), 0.32, 0.34, 16))
				shapes.append(_ellipse(Vector2(0.5, 1.13), 0.38, 0.4, 16))
			for shp in shapes:
				var pts := PackedVector2Array()
				for q in shp:
					pts.append(pos + Vector2(x, 0) + q * sc)
				ci.draw_polyline(pts, col, lw, true)
		elif GLYPHS.has(ch):
			for stroke in GLYPHS[ch]:
				var pts := PackedVector2Array()
				for q in stroke:
					pts.append(pos + Vector2(x, 0) + q * sc)
				ci.draw_polyline(pts, col, lw, true)
				ci.draw_circle(pts[0], lw * 0.5, col)
				ci.draw_circle(pts[pts.size() - 1], lw * 0.5, col)
		else:
			adv = 0.4 * h
		x += adv + 0.12 * h
	return x


static func numerals_width(text: String, h: float, font: Font = null) -> float:
	if font:
		return font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, int(maxf(6.0, h * 1.25))).x
	var x := 0.0
	for ch in text:
		x += (0.36 * h if ch == ":" else (0.62 * h if (GLYPHS.has(ch) or ch == "0" or ch == "8") else 0.4 * h)) + 0.12 * h
	return x


static func _round_rect(r: Rect2, rad: float) -> PackedVector2Array:
	var out := PackedVector2Array()
	rad = minf(rad, minf(r.size.x, r.size.y) * 0.5)
	var cs := [r.position + Vector2(rad, rad), Vector2(r.end.x - rad, r.position.y + rad), r.end - Vector2(rad, rad), Vector2(r.position.x + rad, r.end.y - rad)]
	for k in 4:
		for i in 7:
			var a := PI + k * PI * 0.5 + i * PI / 12.0
			out.append(cs[k] + Vector2.from_angle(a) * rad)
	return out


static func _icon(ci: CanvasItem, kind: int, c: Vector2, s: float, col: Color) -> void:
	match kind:
		0:
			var q := s * 0.34
			ci.draw_rect(Rect2(c - Vector2(q, q) + Vector2(-s * 0.05, s * 0.05), Vector2(q, q) * 2.0), col)
			ci.draw_circle(c + Vector2(-s * 0.05, -q + s * 0.05 - s * 0.1), s * 0.15, col)
			ci.draw_circle(c + Vector2(q - s * 0.05 + s * 0.1, s * 0.05), s * 0.15, col)
		1:
			ci.draw_arc(c, s * 0.42, 0, TAU, 24, col, maxf(1.0, s * 0.1), true)
			ci.draw_line(c, c + Vector2(0, -s * 0.28), col, maxf(1.0, s * 0.1), true)
			ci.draw_line(c, c + Vector2(s * 0.2, s * 0.08), col, maxf(1.0, s * 0.1), true)
		2:
			var lw := maxf(1.0, s * 0.1)
			for d in [Vector2.UP, Vector2.DOWN, Vector2.LEFT, Vector2.RIGHT]:
				var tip: Vector2 = c + d * s * 0.45
				ci.draw_line(c, tip, col, lw, true)
				var sd: Vector2 = d.orthogonal() * s * 0.14
				ci.draw_colored_polygon(PackedVector2Array([tip + d * s * 0.05, tip - d * s * 0.16 + sd, tip - d * s * 0.16 - sd]), col)


## The plaque: pieces placed, time and moves; a wax seal joins them when the puzzle is solved.
static func plaque(ci: CanvasItem, r: Rect2, s: JigsawStyle, placed: int, total: int, seconds: int, moves: int, solved: bool) -> void:
	var pr := _round_rect(r, r.size.y * 0.22)
	var shadow := PackedVector2Array()
	for p in pr:
		shadow.append(p + Vector2(2, 3))
	ci.draw_colored_polygon(shadow, Color(0, 0, 0, 0.3))
	ci.draw_colored_polygon(pr, s.plaque_color)
	var closed := pr.duplicate()
	closed.append(pr[0])
	ci.draw_polyline(closed, Color(s.plaque_ink, 0.35), maxf(1.0, r.size.y * 0.03), true)
	var inner := _round_rect(r.grow(-r.size.y * 0.1), r.size.y * 0.16)
	inner.append(inner[0])
	ci.draw_polyline(inner, Color(s.plaque_ink, 0.14), 1.0, true)
	var h := r.size.y * 0.36
	var items := ["%d/%d" % [placed, total], "%d:%02d" % [floori(seconds / 60.0), seconds % 60], "%d" % moves]
	var widths: Array[float] = []
	var sum := 0.0
	for t in items:
		var wv := numerals_width(t, h, s.font) + h * 1.3
		widths.append(wv)
		sum += wv
	var seal_w := r.size.y * 0.9 if solved else 0.0
	var gap := maxf(4.0, (r.size.x - sum - seal_w - r.size.y * 0.4) / (items.size() + (1 if solved else 0)))
	var x := r.position.x + r.size.y * 0.2 + gap * 0.5
	var cy := r.get_center().y
	for i in items.size():
		_icon(ci, i, Vector2(x + h * 0.45, cy), h, Color(s.plaque_ink, 0.85))
		var tx := x + h * 1.2
		numerals(ci, items[i], Vector2(tx + 1, cy - h * 0.5 + 1), h, Color(0, 0, 0, 0.35), s.font)
		numerals(ci, items[i], Vector2(tx, cy - h * 0.5), h, s.plaque_ink, s.font)
		x += widths[i] + gap
	if solved:
		seal(ci, Vector2(x + seal_w * 0.4, cy), r.size.y * 0.42, s)


## A wax seal with a tick: the "solved" mark.
static func seal(ci: CanvasItem, c: Vector2, rad: float, s: JigsawStyle) -> void:
	var pts := PackedVector2Array()
	for i in 72:
		var a := TAU * i / 72.0
		pts.append(c + Vector2.from_angle(a) * rad * (1.0 + 0.07 * cos(a * 12.0)))
	ci.draw_colored_polygon(pts, s.seal_color.darkened(0.3))
	ci.draw_circle(c - Vector2(rad, rad) * 0.04, rad * 0.86, s.seal_color)
	ci.draw_arc(c, rad * 0.68, 0, TAU, 32, s.seal_color.darkened(0.35), maxf(1.0, rad * 0.08), true)
	ci.draw_arc(c, rad * 0.8, PI * 1.05, PI * 1.6, 12, Color(1, 1, 1, 0.3), maxf(1.0, rad * 0.08), true)
	ci.draw_polyline(PackedVector2Array([c + Vector2(-0.34, 0.0) * rad, c + Vector2(-0.08, 0.28) * rad, c + Vector2(0.38, -0.3) * rad]),
		Color(s.ending_color, 0.95), maxf(1.5, rad * 0.16), true)


## The keyboard / gamepad hand: a drawn pointer with a dark outline.
static func hand(ci: CanvasItem, tip: Vector2, s: float, col: Color, holding: bool) -> void:
	var shape := PackedVector2Array([Vector2(0, 0), Vector2(0, 1.0), Vector2(0.27, 0.76), Vector2(0.46, 1.16), Vector2(0.62, 1.08), Vector2(0.44, 0.7), Vector2(0.8, 0.7)])
	var pts := PackedVector2Array()
	for p in shape:
		pts.append(tip + p * s * (0.9 if holding else 1.0))
	var sh := PackedVector2Array()
	for p in pts:
		sh.append(p + Vector2(2, 3))
	ci.draw_colored_polygon(sh, Color(0, 0, 0, 0.35))
	ci.draw_colored_polygon(pts, col)
	pts.append(pts[0])
	ci.draw_polyline(pts, Color(0.08, 0.06, 0.05, 1.0), maxf(1.0, s * 0.07), true)
