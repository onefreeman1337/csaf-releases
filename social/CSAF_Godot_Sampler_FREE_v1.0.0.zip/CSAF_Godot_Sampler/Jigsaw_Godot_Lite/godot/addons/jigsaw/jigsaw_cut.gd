class_name JigsawCut
extends RefCounted
## Jigsaw for Godot 4 - the cutter. Cuts a w x h picture into interlocking pieces from a seed: a TILING (how the
## picture is divided) times an EDGE (the curve every shared side is drawn with). Pure maths: no nodes, no drawing.
##
## Every inner side is ONE curve shared by the two pieces it separates (one walks it forwards, the other backwards),
## so a tab always meets its own socket and the pieces tile the picture exactly. The same seed cuts the same puzzle.
## A piece whose outline would cross itself has its sides cut straight instead (counted in "straightened").
## Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.

enum Tiling { GRID, BRICK, HEX, TRIANGLE, DIAMOND, RINGS, SHARD }
enum Edge { STRAIGHT, CLASSIC, BULB, PETITE, TWIN, WAVE, DOVETAIL, CRENEL, SAW, BUTTON, LEAN }

const MIN_PIECES := 4
const MAX_PIECES := 256
## The rings cut's centre disk, as a share of a ring's width (0.8 made it 3.4x a ring piece; measured 2026-10-21).
const RING_CORE := 0.56
const TILING_NAMES := ["grid", "brick", "hex", "triangle", "diamond", "rings", "shard"]
const EDGE_NAMES := ["straight", "classic", "bulb", "petite", "twin", "wave", "dovetail", "crenel", "saw", "button", "lean"]


## The vertex soup a tiling builds: positions by lattice key, cells as vertex-index loops, arc sides for RINGS.
class Soup:
	var pos: Array[Vector2] = []
	var key_index := {}
	var cells: Array[PackedInt32Array] = []
	var arcs := {}
	var centre := Vector2.ZERO

	func vid(key: Vector3i, p: Vector2) -> int:
		if key_index.has(key):
			return key_index[key]
		key_index[key] = pos.size()
		pos.append(p)
		return pos.size() - 1

	func add_cell(ids: PackedInt32Array) -> void:
		var clean := PackedInt32Array()
		for i in ids.size():
			if clean.size() > 0 and clean[clean.size() - 1] == ids[i]:
				continue
			clean.append(ids[i])
		if clean.size() > 1 and clean[0] == clean[clean.size() - 1]:
			clean.remove_at(clean.size() - 1)
		if clean.size() >= 3:
			cells.append(clean)


## A seed from anything: an int is used as it is, a numeric string as its number, any other text by its hash.
static func seed_of(v: Variant) -> int:
	if typeof(v) == TYPE_INT:
		return maxi(1, absi(v) & 0x7FFFFFFF)
	if typeof(v) == TYPE_FLOAT:
		return maxi(1, absi(int(v)) & 0x7FFFFFFF)
	var s := str(v).strip_edges()
	if s == "":
		return 1
	if s.is_valid_int():
		return maxi(1, absi(s.to_int()) & 0x7FFFFFFF)
	return maxi(1, s.hash() & 0x7FFFFFFF)


## The near-square grid closest to n pieces on a w x h picture (2 to 16 a side).
static func grid_for(w: float, h: float, n: int) -> Vector2i:
	n = clampi(n, MIN_PIECES, MAX_PIECES)
	var best := Vector2i(2, 2)
	var best_score := INF
	for rows in range(2, 17):
		for cols in range(2, 17):
			var aspect := (w / cols) / (h / rows)
			var score := absf(cols * rows - n) / float(n) + absf(log(aspect)) * 0.8
			if score < best_score:
				best_score = score
				best = Vector2i(cols, rows)
	return best


## Cuts a w x h picture into about `pieces` pieces.
## opts: tiling (Tiling), edge (Edge), corner_jitter (0..0.35 of a cell), knob_scale (0.5..1.6), wobble (0..0.1),
## pixel_snap (px; 0 = smooth). Returns {w, h, seed, tiling, edge, requested, pieces:[{id, outline, centroid, rect,
## area}], straightened, merged, dropped}. Every outline is in picture pixels and runs clockwise on screen (a
## positive shoelace area with y down), so a side's inward normal is (-dir.y, dir.x).
static func cut(w: float, h: float, pieces: int, seed_value: Variant, opts: Dictionary = {}) -> Dictionary:
	var n := clampi(pieces, MIN_PIECES, MAX_PIECES)
	var res := _cut_once(w, h, n, seed_value, opts)
	# lattice tilings land near n, not on it; never above the 256 cap
	var tries := 0
	var ask := n
	while res["pieces"].size() > MAX_PIECES and tries < 4:
		ask = maxi(MIN_PIECES, int(ask * float(MAX_PIECES) / res["pieces"].size()) - 2)
		res = _cut_once(w, h, ask, seed_value, opts)
		tries += 1
	res["requested"] = n
	return res


static func _cut_once(w: float, h: float, n: int, seed_value: Variant, opts: Dictionary) -> Dictionary:
	w = maxf(16.0, w)
	h = maxf(16.0, h)
	var tiling: int = clampi(int(opts.get("tiling", Tiling.GRID)), 0, Tiling.size() - 1)
	var edge: int = clampi(int(opts.get("edge", Edge.CLASSIC)), 0, Edge.size() - 1)
	var jitter := clampf(float(opts.get("corner_jitter", 0.05)), 0.0, 0.35)
	var knob := clampf(float(opts.get("knob_scale", 1.0)), 0.5, 1.6)
	var wob := clampf(float(opts.get("wobble", 0.035)), 0.0, 0.1)
	# pixel steps on grid and brick only (every corner square, nothing clipped); the other tilings stay smooth
	var snap := maxf(0.0, float(opts.get("pixel_snap", 0.0)))
	if not tiling in [Tiling.GRID, Tiling.BRICK]:
		snap = 0.0
	var sd := seed_of(seed_value)
	var rng := RandomNumberGenerator.new()
	rng.seed = sd
	var s := Soup.new()
	var cell := 1.0
	match tiling:
		Tiling.HEX:
			cell = _hex(s, w, h, n, rng)
		_:
			cell = _grid(s, w, h, n, rng, false)
	var clipped := tiling in [Tiling.HEX, Tiling.TRIANGLE, Tiling.DIAMOND, Tiling.RINGS]
	_jitter(s, w, h, cell * jitter, clipped, rng)
	# sides, shared: one record per vertex pair, in a fixed order so the seed decides every curve
	var edges := {}
	for ci in s.cells.size():
		var ids := s.cells[ci]
		for k in ids.size():
			var a := ids[k]
			var b := ids[(k + 1) % ids.size()]
			var key := _ek(a, b)
			if not edges.has(key):
				edges[key] = {"a": a, "b": b, "cells": [], "pts": PackedVector2Array(), "base": PackedVector2Array(), "shaped": false}
			edges[key]["cells"].append(ci)
	var inner := Rect2(1.0, 1.0, w - 2.0, h - 2.0)
	for key in edges:
		var e: Dictionary = edges[key]
		var pa := s.pos[e["a"]]
		var pb := s.pos[e["b"]]
		var base := _arc(s.centre, pa, pb) if s.arcs.has(key) else PackedVector2Array([pa, pb])
		e["base"] = base
		var pts := base
		var shaped: bool = e["cells"].size() == 2 and edge != Edge.STRAIGHT
		if shaped and clipped and not (inner.has_point(pa) and inner.has_point(pb)):
			shaped = false
		if shaped and _length(base) < cell * 0.18:
			shaped = false
		var sgn := 1.0 if rng.randf() < 0.5 else -1.0
		var prof := _profile(edge, rng, knob, wob)
		if shaped:
			pts = _apply(base, prof, sgn)
			if clipped:
				for p in pts:
					if not inner.has_point(p):
						pts = base
						shaped = false
						break
		e["shaped"] = shaped
		e["pts"] = _pixelate(pts, snap, w, h) if snap > 0.0 else pts
	# outlines; a cell whose outline crosses itself gets its sides cut straight (both neighbours follow)
	var outlines: Array[PackedVector2Array] = []
	for ci in s.cells.size():
		outlines.append(_outline(s.cells[ci], edges))
	var straightened := 0
	for pass_i in 4:
		var bad: Array[int] = []
		for ci in s.cells.size():
			if not _simple(outlines[ci]):
				bad.append(ci)
		if bad.is_empty():
			break
		var touched := {}
		for ci in bad:
			var ids := s.cells[ci]
			for k in ids.size():
				var key := _ek(ids[k], ids[(k + 1) % ids.size()])
				var e: Dictionary = edges[key]
				if e["shaped"]:
					straightened += 1
					e["shaped"] = false
				# last resort for pixel steps that pinch a corner: that side goes smooth (both neighbours follow)
				e["pts"] = _pixelate(e["base"], snap, w, h) if (snap > 0.0 and pass_i < 2) else e["base"]
				for c2 in e["cells"]:
					touched[c2] = true
		for ci in touched:
			outlines[ci] = _outline(s.cells[ci], edges)
	# clip lattice tilings to the picture, then fold slivers into a neighbour
	var alive: Array[bool] = []
	alive.resize(outlines.size())
	alive.fill(true)
	var dropped := 0
	var merged := 0
	if clipped:
		var frame := PackedVector2Array([Vector2(0, 0), Vector2(w, 0), Vector2(w, h), Vector2(0, h)])
		for ci in outlines.size():
			var parts := Geometry2D.intersect_polygons(outlines[ci], frame)
			var best := PackedVector2Array()
			var best_a := 0.0
			for part in parts:
				var a := absf(_area(part))
				if a > best_a:
					best_a = a
					best = part
			if best_a < 1.0:
				alive[ci] = false
				dropped += 1
			else:
				outlines[ci] = best
		merged = _merge_slivers(s, edges, outlines, alive)
	var out: Array = []
	for ci in outlines.size():
		if not alive[ci]:
			continue
		var poly := _clean(outlines[ci])
		if _area(poly) < 0.0:
			poly.reverse()
		var rect := Rect2(poly[0], Vector2.ZERO)
		for p in poly:
			rect = rect.expand(p)
		# triangulated ONCE, here, in picture pixels: a scaled copy keeps the same triangles, so drawing at any board size
		# never asks the engine to re-triangulate (it mis-rounds some scaled pixel outlines: 4 of 173,472 measured)
		out.append({"id": out.size(), "outline": poly, "tris": Geometry2D.triangulate_polygon(poly), "centroid": _centroid(poly),
			"rect": rect, "area": absf(_area(poly))})
	return {"w": w, "h": h, "seed": sd, "tiling": tiling, "edge": edge, "requested": n, "pieces": out,
		"straightened": straightened, "merged": merged, "dropped": dropped}


# --- tilings ------------------------------------------------------------------------------------------------------

static func _grid(s: Soup, w: float, h: float, n: int, rng: RandomNumberGenerator, split: bool) -> float:
	var g := grid_for(w, h, n)
	var cw := w / g.x
	var ch := h / g.y
	for r in g.y:
		for c in g.x:
			var tl := s.vid(Vector3i(c, r, 0), Vector2(c * cw, r * ch))
			var tr := s.vid(Vector3i(c + 1, r, 0), Vector2((c + 1) * cw, r * ch))
			var br := s.vid(Vector3i(c + 1, r + 1, 0), Vector2((c + 1) * cw, (r + 1) * ch))
			var bl := s.vid(Vector3i(c, r + 1, 0), Vector2(c * cw, (r + 1) * ch))
			if not split:
				s.add_cell(PackedInt32Array([tl, tr, br, bl]))
			elif rng.randf() < 0.5:
				s.add_cell(PackedInt32Array([tl, tr, br]))
				s.add_cell(PackedInt32Array([tl, br, bl]))
			else:
				s.add_cell(PackedInt32Array([tl, tr, bl]))
				s.add_cell(PackedInt32Array([tr, br, bl]))
	return minf(cw, ch)


static func _hex(s: Soup, w: float, h: float, n: int, rng: RandomNumberGenerator) -> float:
	var R := sqrt(w * h / (float(n) * 2.598))
	var hw := sqrt(3.0) * R
	var o := Vector2(-rng.randf() * hw, -rng.randf() * 1.5 * R)
	var cols := int(ceil(w / hw)) + 2
	var rows := int(ceil(h / (1.5 * R))) + 2
	var corners := [Vector2i(0, -2), Vector2i(1, -1), Vector2i(1, 1), Vector2i(0, 2), Vector2i(-1, 1), Vector2i(-1, -1)]
	for j in rows:
		for i in cols:
			var kx := i * 2 + (j % 2)
			var ky := j * 3
			var ids := PackedInt32Array()
			for cn: Vector2i in corners:
				var vx := kx + cn.x
				var vy := ky + cn.y
				ids.append(s.vid(Vector3i(vx, vy, 0), o + Vector2(vx * hw * 0.5, vy * R * 0.5)))
			s.add_cell(ids)
	return R


static func _jitter(s: Soup, w: float, h: float, amount: float, free: bool, rng: RandomNumberGenerator) -> void:
	if amount <= 0.0:
		return
	for i in s.pos.size():
		var p := s.pos[i]
		var dx := (rng.randf() * 2.0 - 1.0) * amount
		var dy := (rng.randf() * 2.0 - 1.0) * amount
		if free:
			s.pos[i] = p + Vector2(dx, dy)
			continue
		var on_x := p.x < 0.01 or p.x > w - 0.01
		var on_y := p.y < 0.01 or p.y > h - 0.01
		if on_x and on_y:
			continue
		s.pos[i] = Vector2(p.x if on_x else p.x + dx, p.y if on_y else p.y + dy)


# --- sides --------------------------------------------------------------------------------------------------------

static func _ek(a: int, b: int) -> int:
	return mini(a, b) * 1048576 + maxi(a, b)


static func _arc(c: Vector2, pa: Vector2, pb: Vector2) -> PackedVector2Array:
	var ta := (pa - c).angle()
	var tb := (pb - c).angle()
	var d := wrapf(tb - ta, -PI, PI)
	var ra := (pa - c).length()
	var rb := (pb - c).length()
	var steps := maxi(3, int(ceil(absf(d) * maxf(ra, rb) / 6.0)))
	var out := PackedVector2Array([pa])
	for i in range(1, steps):
		var t := float(i) / steps
		out.append(c + Vector2.from_angle(ta + d * t) * lerpf(ra, rb, t))
	out.append(pb)
	return out


static func _length(p: PackedVector2Array) -> float:
	var l := 0.0
	for i in p.size() - 1:
		l += p[i].distance_to(p[i + 1])
	return l


## The profile of one side in (u along, v across) units of its length; v > 0 bulges to the chosen side.
static func _profile(kind: int, rng: RandomNumberGenerator, knob: float, wob: float) -> PackedVector2Array:
	var a := (rng.randf() * 2.0 - 1.0) * wob
	var b := (rng.randf() * 2.0 - 1.0) * wob
	var c := (rng.randf() * 2.0 - 1.0) * wob
	var d := (rng.randf() * 2.0 - 1.0) * wob
	var e := (rng.randf() * 2.0 - 1.0) * wob
	var t := (0.085 + rng.randf() * 0.025) * knob
	var lean := (0.9 if rng.randf() < 0.5 else -0.9) * t
	match kind:
		Edge.CLASSIC, Edge.PETITE, Edge.LEAN:
			if kind == Edge.PETITE:
				t *= 0.66
			var l := lean if kind == Edge.LEAN else 0.0
			return _bez([Vector2(0, 0), Vector2(0.2, a), Vector2(0.5 + b + d, -t + c), Vector2(0.5 - t + b + l * 0.3, t + c),
				Vector2(0.5 - 2.0 * t + b - d + l, 3.0 * t + c), Vector2(0.5 + 2.0 * t + b - d + l, 3.0 * t + c),
				Vector2(0.5 + t + b + l * 0.3, t + c), Vector2(0.5 + b + d, -t + c), Vector2(0.8, e), Vector2(1, 0)], 8)
		Edge.BULB:
			return _bez([Vector2(0, 0), Vector2(0.22, a), Vector2(0.5 + b, -0.8 * t + c), Vector2(0.5 - 0.55 * t + b, 1.1 * t + c),
				Vector2(0.5 - 2.6 * t + b, 3.9 * t + c), Vector2(0.5 + 2.6 * t + b, 3.9 * t + c),
				Vector2(0.5 + 0.55 * t + b, 1.1 * t + c), Vector2(0.5 + b, -0.8 * t + c), Vector2(0.78, e), Vector2(1, 0)], 9)
		Edge.WAVE:
			var amp := (0.075 + rng.randf() * 0.03) * knob
			var ph := rng.randf() * TAU
			var out := PackedVector2Array()
			for i in 25:
				var u := i / 24.0
				out.append(Vector2(u, amp * sin(TAU * u) + amp * 0.25 * sin(2.0 * TAU * u + ph) * sin(PI * u)))
			return out
	return PackedVector2Array([Vector2(0, 0), Vector2(1, 0)])


static func _bez(ctrl: Array, steps: int) -> PackedVector2Array:
	var out := PackedVector2Array([ctrl[0]])
	for sgi in (ctrl.size() - 1) / 3:
		var p0: Vector2 = ctrl[sgi * 3]
		var p1: Vector2 = ctrl[sgi * 3 + 1]
		var p2: Vector2 = ctrl[sgi * 3 + 2]
		var p3: Vector2 = ctrl[sgi * 3 + 3]
		for i in range(1, steps + 1):
			out.append(p0.bezier_interpolate(p1, p2, p3, float(i) / steps))
	return out


## Lays a profile along a base polyline (straight or an arc); the ends land exactly on the base's ends.
static func _apply(base: PackedVector2Array, prof: PackedVector2Array, sgn: float) -> PackedVector2Array:
	var cum := PackedFloat32Array([0.0])
	for i in base.size() - 1:
		cum.append(cum[i] + base[i].distance_to(base[i + 1]))
	var total := cum[cum.size() - 1]
	var out := PackedVector2Array()
	for q in prof:
		var at := clampf(q.x, 0.0, 1.0) * total
		var seg := 0
		while seg < base.size() - 2 and cum[seg + 1] < at:
			seg += 1
		var span := maxf(0.0001, cum[seg + 1] - cum[seg])
		var dir := (base[seg + 1] - base[seg]) / span
		var p := base[seg] + dir * (at - cum[seg]) + dir * (q.x - clampf(q.x, 0.0, 1.0)) * total
		out.append(p + Vector2(-dir.y, dir.x) * (q.y * total * sgn))
	out[0] = base[0]
	out[out.size() - 1] = base[base.size() - 1]
	return out


## Pixel-art sides: resampled, snapped to a grid of `px` and stepped like a staircase (same steps both ways).
static func _pixelate(pts: PackedVector2Array, px: float, w: float, h: float) -> PackedVector2Array:
	var dense := PackedVector2Array([pts[0]])
	for i in pts.size() - 1:
		var a := pts[i]
		var b := pts[i + 1]
		var steps := maxi(1, int(ceil(a.distance_to(b) / (px * 0.34))))
		for k in range(1, steps + 1):
			dense.append(a.lerp(b, float(k) / steps))
	var on_grid := PackedVector2Array()
	for p in dense:
		# a point ON the picture's edge keeps that coordinate, so the border never moves inward by a part pixel
		var qx := p.x if (p.x <= 0.001 or p.x >= w - 0.001) else clampf(roundf(p.x / px) * px, 0.0, w)
		var qy := p.y if (p.y <= 0.001 or p.y >= h - 0.001) else clampf(roundf(p.y / px) * px, 0.0, h)
		var q := Vector2(qx, qy)
		if on_grid.is_empty() or q != on_grid[on_grid.size() - 1]:
			on_grid.append(q)
	var stairs := PackedVector2Array([on_grid[0]])
	for i in range(1, on_grid.size()):
		var a := stairs[stairs.size() - 1]
		var b := on_grid[i]
		if a.x != b.x and a.y != b.y:
			stairs.append(Vector2(b.x, a.y))
		stairs.append(b)
	# fold out zero-width spikes (A, B, A) and straight-through middles
	var changed := true
	while changed:
		changed = false
		var clean := PackedVector2Array()
		for p in stairs:
			if clean.size() >= 1 and clean[clean.size() - 1] == p:
				continue
			if clean.size() >= 2 and clean[clean.size() - 2] == p:
				clean.remove_at(clean.size() - 1)
				changed = true
				continue
			if clean.size() >= 2:
				var p0 := clean[clean.size() - 2]
				var p1 := clean[clean.size() - 1]
				if absf((p1 - p0).cross(p - p1)) < 0.001 and (p1 - p0).dot(p - p1) > 0.0:
					clean[clean.size() - 1] = p
					changed = true
					continue
			clean.append(p)
		stairs = clean
	if stairs.size() < 2:
		return PackedVector2Array([on_grid[0], on_grid[on_grid.size() - 1]])
	return stairs


static func _outline(ids: PackedInt32Array, edges: Dictionary) -> PackedVector2Array:
	var out := PackedVector2Array()
	for k in ids.size():
		var a := ids[k]
		var b := ids[(k + 1) % ids.size()]
		var e: Dictionary = edges[_ek(a, b)]
		var pts: PackedVector2Array = e["pts"]
		if e["a"] != a:
			pts = pts.duplicate()
			pts.reverse()
		for i in pts.size() - 1:
			out.append(pts[i])
	return _clean(out)


## True when an outline is a simple polygon: no vertex repeats (a pinch, where a pixel-stepped knob's neck closes to
## nothing), it triangulates, and the triangles add up to its shoelace area.
static func _simple(poly: PackedVector2Array) -> bool:
	if poly.size() < 3:
		return false
	var seen := {}
	for p in poly:
		if seen.has(p):
			return false
		seen[p] = true
	var tri := Geometry2D.triangulate_polygon(poly)
	if tri.size() < 3:
		return false
	var ta := 0.0
	for i in range(0, tri.size(), 3):
		ta += absf((poly[tri[i + 1]] - poly[tri[i]]).cross(poly[tri[i + 2]] - poly[tri[i]])) * 0.5
	var sa := absf(_area(poly))
	return sa > 0.5 and absf(ta - sa) <= maxf(0.5, sa * 0.004)


## Drops repeated points, points on a straight run and zero-width spikes (out and straight back), which appear where two
## pixel-stepped sides meet. They hold no area, so the tiling is unchanged, but the engine's triangulator refuses them at
## some scales (MEASURED: 6 of 43,368 pieces, pixel styles only, "triangulation failed").
static func _clean(poly: PackedVector2Array) -> PackedVector2Array:
	var pts := poly.duplicate()
	var changed := true
	while changed and pts.size() > 3:
		changed = false
		var n := pts.size()
		for i in n:
			var a := pts[(i - 1 + n) % n]
			var b := pts[i]
			var c := pts[(i + 1) % n]
			var ab := b - a
			var bc := c - b
			if ab.length_squared() < 1e-8 or absf(ab.cross(bc)) <= 1e-9 * maxf(1e-9, ab.length() * bc.length()):
				pts.remove_at(i)
				changed = true
				break
	return pts


static func _area(poly: PackedVector2Array) -> float:
	var a := 0.0
	for i in poly.size():
		var p := poly[i]
		var q := poly[(i + 1) % poly.size()]
		a += p.x * q.y - q.x * p.y
	return a * 0.5


static func _centroid(poly: PackedVector2Array) -> Vector2:
	var a := 0.0
	var c := Vector2.ZERO
	for i in poly.size():
		var p := poly[i]
		var q := poly[(i + 1) % poly.size()]
		var k := p.x * q.y - q.x * p.y
		a += k
		c += (p + q) * k
	if absf(a) < 0.0001:
		var m := Vector2.ZERO
		for p in poly:
			m += p
		return m / maxf(1.0, poly.size())
	return c / (3.0 * a)


static func _merge_slivers(s: Soup, edges: Dictionary, outlines: Array[PackedVector2Array], alive: Array[bool]) -> int:
	var areas: Array[float] = []
	var live: Array[float] = []
	for ci in outlines.size():
		var a := absf(_area(outlines[ci])) if alive[ci] else 0.0
		areas.append(a)
		if alive[ci]:
			live.append(a)
	if live.size() < 3:
		return 0
	live.sort()
	var median := live[live.size() / 2]
	# who touches whom, from the shared sides
	var near: Array = []
	for ci in outlines.size():
		near.append({})
	for key in edges:
		var cs: Array = edges[key]["cells"]
		if cs.size() == 2:
			near[cs[0]][cs[1]] = true
			near[cs[1]][cs[0]] = true
	var order: Array[int] = []
	for ci in outlines.size():
		if alive[ci] and areas[ci] < median * 0.4:
			order.append(ci)
	order.sort_custom(func(x: int, y: int) -> bool: return areas[x] < areas[y])
	var merged := 0
	for ci in order:
		if not alive[ci]:
			continue
		# a sliver joins a FULL-SIZE neighbour only, and never grows it past ~2 pieces: merging into another sliver
		# chained a whole border row into one long piece (measured: hex, 1200x800, 30 pieces, seed 24)
		var cands: Array = []
		for nb in near[ci]:
			if alive[nb] and nb != ci and areas[nb] >= median * 0.4 and areas[nb] + areas[ci] <= median * 1.9:
				cands.append(nb)
		cands.sort_custom(func(x: int, y: int) -> bool: return areas[x] < areas[y])
		for nb in cands:
			var res := Geometry2D.merge_polygons(outlines[nb], outlines[ci])
			if res.size() != 1:
				continue
			outlines[nb] = res[0]
			areas[nb] += areas[ci]
			alive[ci] = false
			for other in near[ci]:
				if other != nb:
					near[nb][other] = true
					near[other][nb] = true
			merged += 1
			break
	return merged
