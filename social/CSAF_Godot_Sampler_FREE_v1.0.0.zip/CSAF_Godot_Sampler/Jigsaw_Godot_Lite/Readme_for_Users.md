# Jigsaw for Godot 4 - free lite (12 styles, MIT)

**Version 1.0.0, for Godot 4.7** (tested on Godot 4.7.2; older versions were not run).

This is the free lite of **Jigsaw for Godot 4** (https://csaf.itch.io/jigsaw-godot): 12 of its 48 styles, exactly as they are in the full pack, with the grid and hex cuts; the straight, classic, bulb, petite, wave and lean sides; the card, paper, ink, gilded, porcelain and neon finishes; and the felt, slate, parchment, velvet, tatami, marble and leather tables. The full pack adds the brick, triangle, diamond, rings and shard cuts, the twin, dovetail, crenel, saw and button sides, the wood, glass, pixel, frost, slab and metal finishes, the planks, neon grid, pixel tiles, snow and starfield tables, and 36 more styles. A style asking for one of those here falls back to a grid cut, straight sides, the plain finish or a plain table.

**Any Texture2D becomes a jigsaw puzzle your players put together.** Give it a picture and a piece count and it cuts the
picture, lays the pieces out on a table beside a tray and lets the player assemble it with the mouse, touch, the keyboard
or a gamepad. Every cut is generated from a seed: each shared side is ONE curve, so a tab always meets its own socket and
the pieces tile the picture exactly, and no two seeds cut the same puzzle. Each piece is lit, bevelled and shadowed from
its own outline; the table, tray, plaque and ending are drawn in code. The only images in the pack are four demo pictures.

It runs under **Forward+ and Compatibility** (and Mobile), with no GDExtension and no plugin to enable.

## Install

1. Copy the `addons/jigsaw/` folder into your project's `addons/` folder and **keep the folder name**: the styles, preset
   scenes and pictures point at `res://addons/jigsaw/`. (Measured: in a renamed folder Godot prints errors naming the
   missing `res://addons/jigsaw/` paths, so a wrong path is loud, never silent.)
2. That is all: the classes (`JigsawBoard`, `JigsawMinigame`, `JigsawStyle`, `JigsawCut`, `JigsawPiece`, `JigsawPaint`)
   register themselves. There is nothing to enable in Project Settings > Plugins.

To try it first, open the `godot/` folder of this download as a project and run it: the demo plays every style.

## Quick start: one call

```gdscript
var result := await JigsawMinigame.open(self, preload("res://art/castle.png"), {
	"pieces": 48,
	"style": preload("res://addons/jigsaw/styles/parlour.tres"),
	"seed": "chapter-3",      # blank or missing = a new cut every time
	"pause": true,            # pause the game while the puzzle is up
})
if result.solved:
	open_the_gate()
```

`open()` adds a full-screen layer, waits until the player solves the puzzle and clicks (or sets it aside), removes the layer
and returns the result. Options: `pieces` (24), `style` (Parlour), `seed`, `rotation` (false), `pause` (false),
`layer` (64), `snap` (16), `set_aside` (true).

## Quick start: a node in your scene

Add a **Node2D**, attach `addons/jigsaw/jigsaw_board.gd` (or instance any scene in `addons/jigsaw/presets/`), set
`picture` and `style`, and run. Then:

```gdscript
var result: Dictionary = await $JigsawBoard.finished
```

### The result

`{solved, pieces, placed, seconds, moves, peeks, seed, style, tiling, edge}`: `seconds` is whole seconds played, `moves`
counts every time a piece is put down (placed or not), `peeks` counts looks at the box lid, `seed` re-cuts the same
puzzle when passed back as `seed_text`.

## JigsawBoard

| Property | Default | What it does |
| --- | --- | --- |
| `picture` | none | The Texture2D to cut. With none, the board warns once and draws the table and an empty tray. |
| `pieces` | 24 | About how many pieces, 4 to 256 (see "Piece counts"). |
| `seed_text` | "" | Blank = a new cut every time; any number or word cuts the same puzzle every time. |
| `style` | Parlour | A `JigsawStyle` (the 48 are in `addons/jigsaw/styles/`). |
| `fit_viewport` | true | Fill the viewport and follow it when it is resized; off = use `board_size`. |
| `board_size` | 1280 x 720 | The board's size when `fit_viewport` is off. |
| `centered` | false | Draw round the node's origin instead of from its top-left. |
| `frame_share` | 0.6 | How much of the width (height, on a portrait screen) the tray may take. |
| `autostart` | true | Cut and lay out as soon as the node enters the tree. |
| `snap_distance` | 16 | How close (pixels on a 720 high board; it scales with the board) a piece must land to click in. |
| `rotation_enabled` | false | Loose pieces start turned; the player turns them back. |
| `allow_set_aside` | true | Cancel (or a right click with nothing held, when rotation is off) gives up. |
| `close_on_confirm` | true | After the ending, `finished` waits for a click or the pick/cancel action. |
| `keyboard_hand` | true | A drawn hand the arrow keys / left stick move. |
| `gamepad_buttons` | true | Also read a gamepad's A, B, X and left shoulder directly (Godot's default `ui_accept` and `ui_cancel` have no gamepad button). |
| `showcase` | false | Start part-assembled with one piece in the air (the preset scenes use it). |
| `action_*` | ui_* | The InputMap actions it reads (see "Controls"); any missing action is simply ignored. |

Signals: `piece_placed(placed, total)` · `solved(result)` (the moment the last piece clicks in) · `finished(result)`.
Methods: `start(picture = null, pieces = -1, seed = null)` · `preview(fraction)` · `set_aside()` · `solve_now()` ·
`get_result()` · `piece_count()` · `get_pieces()`.

## Controls (defaults)

| Do this | Mouse / touch | Keyboard / gamepad |
| --- | --- | --- |
| Move the hand | - | `ui_left/right/up/down` (arrows, d-pad, left stick); hold Shift to go faster |
| Pick up / put down | press, drag, let go | `ui_accept` (Enter, Space) or gamepad A |
| Turn the held piece (rotation on) | right click or the wheel | `ui_focus_next` (Tab) or gamepad X |
| Look at the box lid | - | hold `ui_page_up` (Page Up) or the gamepad's left shoulder |
| Set the puzzle aside | right click with nothing held (rotation off) | `ui_cancel` (Esc) or gamepad B, with nothing held |

Touch works through Godot's "Emulate Mouse From Touch" (on by default); with that setting off, the board reads the touch
events itself. Every action name is an exported property, so remap them to your own actions.

## Styles

Each style is a `JigsawStyle` resource: how the picture is cut (tiling x sides), how a piece is finished, the table, the
tray, the plaque and the ending. Open any `.tres` in the inspector and move a slider; duplicate one to make your own.
Colours, piece count, seed and snap are parameters, never styles.

| id | name | cut | sides | finish | table | demo picture |
| --- | --- | --- | --- | --- | --- | --- |
| `parlour` | Parlour | grid | classic | card | felt | harbour |
| `casino` | Casino | grid | bulb | gilded | felt | night_market |
| `schoolhouse` | Schoolhouse | grid | petite | paper | slate | harbour |
| `scriptorium` | Scriptorium | grid | lean | ink | parchment | autumn_shrine |
| `herbarium` | Herbarium | grid | wave | paper | parchment | pixel_valley |
| `crown` | Crown Velvet | grid | bulb | gilded | velvet | autumn_shrine |
| `midnight_club` | Midnight Club | hex | classic | neon | velvet | pixel_valley |
| `shoji` | Shoji | grid | straight | paper | tatami | harbour |
| `teahouse` | Teahouse | hex | wave | porcelain | tatami | night_market |
| `palace` | Palace | grid | bulb | porcelain | marble | harbour |
| `adventurer` | Adventurer | grid | lean | card | leather | autumn_shrine |
| `grimoire` | Grimoire | grid | bulb | gilded | leather | night_market |

**Cuts (tiling):** grid, hex. **Sides:** straight, classic, bulb, petite, wave, lean. **Finishes:** card, paper, ink, gilded,
porcelain, neon. **Tables:** felt, slate, parchment, velvet, tatami, marble, leather. **Endings:** rise, sparkle, shine, glow.
`pixel_steps` gives stepped pixel-art sides on grid cuts.

## Piece counts

Grid cuts pick the near-square grid closest to your number (on the measured pictures, 1200 x 800, 1024 x 687 and 800 x 1200, asking for 12, 48, 150 and 256 gave exactly 12, 48, 150 and 256). The lattice cuts land close to it, never above
256 (measured over 1232 cuts at 12, 48, 150 and 256: brick, hex, triangle, diamond, rings and shard gave 12 to 20 pieces for 12, 42 to 57 for 48, 141 to 162 for 150 and 243 to 256 for 256). A grid or brick side has at most 16 pieces,
so a very wide or very tall picture gets fewer (measured: a 2400 x 200 picture asked for 256 gives 32). A piece whose sides would cross itself is cut with
straight sides instead, and lattice pieces cut to a sliver at the picture's edge join a neighbour.

## Performance

Measured on a 1280 x 720 board with vsync off, on integrated AMD Radeon graphics: about 70 pieces cost under 10 ms a frame in both renderers; 256 pieces cost under 12 ms a frame in Forward+ and under 25 ms in Compatibility (the neon and glass finishes are the heaviest). Cutting and laying out 256 pieces takes under half a second, once, when the puzzle opens.

## Files

- `addons/jigsaw/`: `jigsaw_board.gd`, `jigsaw_minigame.gd`, `jigsaw_style.gd`, `jigsaw_cut.gd`, `jigsaw_piece.gd`,
  `jigsaw_paint.gd`, `shaders/jigsaw_face.gdshader`, `styles/` (12 styles), `presets/` (12 showcase scenes, 480 x 320),
  `pictures/` (the four demo pictures).
- `demo/`: the style browser (Q / E style, R new cut, W picture, S solve, T rotation).
- `pack.json`: the style list, machine-readable.

The demo pictures were made with an AI image model; you may use them in your game. No third-party code is included.

## Terms

See `LICENSE.txt`. MIT: use, change and share it freely, keep the notice.

Made by Core Systems Asset Factory, https://csaf.itch.io
