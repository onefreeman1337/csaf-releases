/* ================================================================================================
 * gates.js — THE FOUR GATES. Two POSITIONAL, two PROCEDURAL, and never a combinatorial one.
 * ================================================================================================
 * DESIGN.md §4 is the binding constraint and it was MEASURED at candidate stage, before any code:
 *
 *     combinatorial-small (pick from 12)      D1 0.2x    REJECTED
 *     combinatorial-large (3 of 20)           D1 80.1x   REJECTED on fairness (4.90 attempts)
 *     procedural (perform an unlisted act)    D1 27.8x   USABLE
 *     positional (know WHERE to go)           D1 91.5x   USABLE
 *
 * > ⛔ EVERY GATE IN THIS GAME IS POSITIONAL OR PROCEDURAL. NEVER COMBINATORIAL.
 * > No keypads. No rune-sequence doors. No pick-the-right-word dialogue locks.
 *
 * ⭐ THE ONE STRUCTURAL DECISION IN THIS FILE, AND IT IS WHAT MAKES THE NO-BRUTE-FORCE NUMBERS MEAN
 * ANYTHING: **THE KNOWER AND THE BRUTE-FORCER RUN THE SAME ATTEMPT CODE.** They differ in exactly
 * one thing — which candidate they try first. There is no privileged path a knowing player takes, so
 * a comparison between them cannot be a comparison between a well-written script and a badly-written
 * one. §6b-6 rule 2, paid for on LANTERNBOUND: two sabotage arms stayed green because the helper
 * built its combat from the encounter's own config and ignored the override, i.e. the checker read a
 * different input from the thing under test. One factory for the object under test, and every check
 * takes it from there.
 *
 * ⚠️⚠️ SCOPE, STATED BEFORE THE CLAIMS RATHER THAN AFTER THEM. Each gate builds its OWN fixture
 * room. Master §2b's Godot row: *a harness that only ever constructs ONE input shape has an opinion
 * about one input shape, and "verified" earns exactly that scope.* So the NO-BRUTE-FORCE results
 * here are about the gate MECHANISM inside a purpose-built chamber. They are NOT about traversal
 * costs in the assembled shaft, which does not exist yet (DESIGN §7 build order item 6). ⛔ WHEN THE
 * SHAFT IS ASSEMBLED THESE GATES MUST BE RE-RUN IN SITU — the four fixtures below are deliberately
 * built from the same primitives the real shaft will use, so that re-run is a change of room and not
 * a rewrite.
 *
 * ⛔ A MEASURED CONSTRAINT ON EVERY FUTURE LEVEL IN THIS GAME, DISCOVERED BY BUILDING THESE:
 * **THE CORD IS A STRAIGHT LINE FROM HAND TO BOB AND IT DOES NOT CATCH ON EDGES.** So no gate may
 * require the weight to end up under an overhang while the line is out: the cord would render
 * through solid rock, and §6b-5 rule 3 is explicit that a picture contradicting the collision model
 * is a mechanical failure and not a mood. Three drafts of the gates below wanted exactly that (a
 * plate under a shelf, a niche in a wall, a low side tunnel) and all three were cut for this reason
 * BEFORE being built. The instrument's reach is therefore VERTICAL — which is what `GRATE` is for.
 * If a later session wants lateral reach it must first implement a cord that pivots on a corner, and
 * that is a physics change with its own suite, not a level trick.
 *
 * ⛔ DUAL-MODE + IIFE (§6b-5 rules 1 and 2). ⛔ NO `Math.random`. ⭐ THE CALLER OWNS THE CLOCK.
 * ---------------------------------------------------------------------------------------------- */
'use strict';

(function (root) {
  const PLAT = (typeof require === 'function') ? require('./plat.js') : root.PL_PLAT;
  const LINE = (typeof require === 'function') ? require('./line.js') : root.PL_LINE;
  /* ⛔ NO `require('./lamp.js')` — the lamp is OUT OF SLICE as of 2026-09-03 (see Shaft, below).
   * `_lamp_selftest.js`'s OUT-OF-SLICE guard scans this file's stripped source for it. */

  const T = PLAT.DEFAULTS.tile;
  const OPEN = PLAT.OPEN, ROCK = PLAT.ROCK, GRATE = PLAT.GRATE;

  /* Where the reel is held, as a fraction of the body's height above its feet. Chest height. ONE
   * declaration: the renderer, the gates and every harness read it from here, because a second copy
   * of this number is a place the weight and the picture can disagree (§6d-10). */
  const HAND_FRAC = 0.6;

  /* ---- fixture helpers ------------------------------------------------------------------------
   * ⚠️ `fill` takes an INCLUSIVE tile range, because every gate below is described in terms of "cols
   * 2..41" and an off-by-one in a level is a puzzle that is quietly wrong rather than an error. */
  function fill(room, c0, r0, c1, r1, mat) {
    for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) room.set(c, r, mat);
    return room;
  }
  function solidRoom(cols, rows) {
    const r = new PLAT.Room(cols, rows);
    fill(r, 0, 0, cols - 1, rows - 1, ROCK);
    return r;
  }

  /* ================================================================================================
   * THE SURVEY ROOFLINE — how a player knows WHICH bay they are standing in.
   * ================================================================================================
   * ⛔⛔ DESIGN §4c: a positional gate asks the player to RETURN to a place they learned, and the
   * harness's knower is handed the answer as a COORDINATE while a human has to RECOGNISE it. Baked as
   * a picture, the first gallery was three uniform bands of masonry over a hundred and forty
   * identical bays — so the knowledge the gate tests could not be held by a player at all, and every
   * D1 figure was an answer to a narrower question than it read as.
   *
   * ⭐⭐ THE OBVIOUS FIX IS MEASURED FATAL AND THE SECOND-MOST OBVIOUS ONE IS TOO, WHICH IS WHY THIS
   * IS A ROOFLINE AND NOT A ROW OF SIGNPOSTS.
   *   1. MARK THE ANSWER'S BAY. `_probe_sight.js`'s marked-plate control prices that at **22.0x to a
   *      searcher** — the gate collapses completely.
   *   2. MARK SOME BAYS (an arch every ten, a survey post every five). That partitions the bays into
   *      a MARKED set and an UNMARKED one, and either subset is a smaller search space than the
   *      corridor: a searcher who learns the answer is never under an arch skips those bays, and
   *      `_probe_cost.js` prices that exactly — at 15% of bays marked the barred gallery falls from
   *      22.2x to 19.3x, under the pre-registered bar, and it keeps falling linearly with density.
   *      ⇒ **ANY VISIBLE DISTINCTION AMONG CANDIDATES IS A PARTITION, AND A PARTITION IS A SMALLER
   *      SEARCH SPACE.** A landmark scheme that marks a subset cannot be free.
   *
   * ✅ SO NO BAY IS MARKED AND EVERY BAY IS DISTINCT: the gallery's CEILING steps between three
   * heights, and the sequence of heights is a **de Bruijn sequence**, in which every window of
   * `ROOF_WINDOW` consecutive bays occurs exactly once. A player who can see four bays of roof knows
   * precisely where they are; a searcher gains NOTHING, because there is no subset to prefer — the
   * partition is into classes of ONE, which is the same as no partition at all. DESIGN §4c's law
   * ("landmarks DENSE and UNIFORM — every candidate describable — and never correlated with the
   * answer") is satisfied by construction rather than by inspection.
   *
   * ⛔ THE HEADROOM RULE IS WHAT KEEPS IT FREE: the roof only ever occupies rows the body cannot
   * reach anyway. `standableSlots` requires the two tiles ABOVE the floor to be open, so a ceiling at
   * `floorRow-3` or higher removes no candidate and cannot change any D1 figure. Asserted, not
   * assumed — `_probe_landmarks.js` requires the candidate count to be IDENTICAL with the roofline on
   * and off.
   * ⚠️ And the sequence is generated from a fixed rule that has no access to the plate, so it cannot
   * correlate with the answer by accident. That is a property of the CODE, and it is checked as one.
   */
  const ROOF_HEIGHTS = 3;    /* three ceiling levels — the alphabet                                  */
  const ROOF_WINDOW = 5;     /* every run of 5 bays is unique: 3^5 = 243 distinct windows            */

  /* Standard FKM/Lyndon-word de Bruijn construction. Deterministic, no Math.random (§ house rule). */
  function deBruijn(k, n) {
    const a = new Array(k * n).fill(0), seq = [];
    (function db(t, p) {
      if (t > n) {
        if (n % p === 0) for (let i = 1; i <= p; i++) seq.push(a[i]);
      } else {
        a[t] = a[t - p]; db(t + 1, p);
        for (let j = a[t - p] + 1; j < k; j++) { a[t] = j; db(t + 1, t); }
      }
    })(1, 1);
    return seq;
  }
  /* ⛔⛔ A DE BRUIJN SEQUENCE IS BALANCED OVER ITS FULL PERIOD AND **NOT** OVER A PREFIX, AND A LEVEL
   * ONLY EVER USES A PREFIX. MEASURED 2026-09-03 by `_probe_landmarks.js` on the first 64 symbols of
   * the raw FKM output: heights occur **37 / 16 / 11**, not 21 / 21 / 22. The construction emits
   * Lyndon words in lexicographic order, so the start of the sequence is dominated by the lowest
   * symbol (00000, 00001, 00002, 00011...) and the highest roof becomes a RARE MARK — eleven bays out
   * of sixty-four. That is precisely the "mark some bays" failure this whole scheme exists to avoid,
   * arriving through the internals of the generator rather than through the level design, and it was
   * invisible to every assertion about window UNIQUENESS (which was, and still is, perfect).
   * ⇒ ROTATE. The window-uniqueness property is CYCLIC, so every rotation preserves it exactly, and
   * the offset is chosen by SEARCHING all of them for the one whose prefixes are most balanced at the
   * lengths this game actually builds. Derived, never typed — a hand-picked offset would go stale the
   * first time a gallery changed length. */
  const ROOF_PREFIX_LENGTHS = [64, 140];         /* the gallery lengths in the slice */
  function balanceOf(seq, n) {
    const c = new Array(ROOF_HEIGHTS).fill(0);
    for (let i = 0; i < n; i++) c[seq[i % seq.length]]++;
    return Math.min(...c) / n;                    /* the share held by the RAREST height */
  }
  const ROOF_SEQ = (function () {
    const raw = deBruijn(ROOF_HEIGHTS, ROOF_WINDOW);   /* length 243 */
    let best = null;
    for (let off = 0; off < raw.length; off++) {
      const rot = raw.slice(off).concat(raw.slice(0, off));
      const score = Math.min(...ROOF_PREFIX_LENGTHS.map((n) => balanceOf(rot, n)));
      if (!best || score > best.score) best = { score: score, rot: rot, off: off };
    }
    return best.rot;
  })();

  /* ⛔⛔ THE LOWEST ROOF MUST CLEAR A FULL JUMP, AND THAT IS DERIVED FROM plat.js, NEVER TYPED.
   * ------------------------------------------------------------------------------------------------
   * The first build put the roof at `floorRow - 3` — 48 px of air — which clears a standing body
   * (22 px) and NOT a jump (apex `jumpSpeed^2 / 2g` = 36.3 px, so 58.3 px are needed). The result was
   * a MEASURED regression in a gate this file had already proved: `the-fall`'s SWEEP CONTROL went
   * from `held` to OPENED, because a sweeper holding jump bonks its head under a low bay, and a
   * player stopped dead is a weight that comes to rest — §4b's law, arriving through the ceiling.
   * ⭐ ISOLATED ONE VARIABLE AT A TIME BEFORE BEING FIXED (`_iso_fall.js`, §6b-13 rule 8): roof on +
   * new reel rate OPENS, roof OFF + new reel rate HELD, roof on + OLD reel rate OPENS, both old HELD.
   * The roofline was the cause and the reel rate was not, and the both-old control proves the
   * regression was new rather than pre-existing.
   * ⇒ §6b-14 rule 2 as a hard requirement rather than a habit: **a presentation change must be proven
   * to change NOTHING physical.** The clearance below is computed from plat.js's own jump constants,
   * so it cannot go stale if the jump is ever retuned, and `_probe_landmarks.js` asserts both that no
   * candidate is lost AND that the sweep controls still hold. */
  const JUMP_APEX = (PLAT.DEFAULTS.jumpSpeed * PLAT.DEFAULTS.jumpSpeed) / (2 * PLAT.DEFAULTS.gravity);
  const ROOF_CLEAR_PX = PLAT.DEFAULTS.h + JUMP_APEX;                 /* 22 + 36.3 = 58.3 px */
  const ROOF_MIN_TILES = Math.ceil(ROOF_CLEAR_PX / T);               /* 4 tiles of air, minimum */

  /* The ceiling row for bay index `i`, given the floor. 0 = lowest roof, ROOF_HEIGHTS-1 = highest. */
  function roofRow(i, floorRow) {
    return floorRow - ROOF_MIN_TILES - ROOF_SEQ[((i % ROOF_SEQ.length) + ROOF_SEQ.length) % ROOF_SEQ.length];
  }

  /* Carve a gallery: for each column, open everything from its own roof down to the floor. */
  function carveGallery(room, c0, c1, floorRow) {
    for (let c = c0; c <= c1; c++) {
      for (let r = roofRow(c - c0, floorRow); r <= floorRow - 1; r++) room.set(c, r, OPEN);
    }
    return room;
  }
  /* The address a player can read off the roof: the window of heights at this bay. Used by the
   * probe to prove uniqueness; the GAME never needs it, because the player reads the picture. */
  function roofWindow(i) {
    const w = [];
    for (let j = 0; j < ROOF_WINDOW; j++) w.push(ROOF_SEQ[(i + j) % ROOF_SEQ.length]);
    return w.join('');
  }

  /* ⛔ CANDIDATES ARE DERIVED FROM THE ROOM, NEVER TYPED. A hand-listed candidate set goes stale the
   * first time a fixture moves, silently, and then the brute-force ratio is a number about a level
   * that no longer exists (§6d-16: a hand-listed table of confusable pairs goes stale the first time
   * a device is redrawn). This walks the actual geometry and returns every place a player could
   * stand and lower the weight. */
  function standableSlots(room, surfaceRow, c0, c1) {
    const out = [];
    for (let c = c0; c <= c1; c++) {
      const floor = room.at(c, surfaceRow);
      if (floor !== ROCK && floor !== GRATE) continue;        /* nothing to stand on */
      if (room.at(c, surfaceRow - 1) !== OPEN) continue;      /* no headroom */
      if (room.at(c, surfaceRow - 2) !== OPEN) continue;      /* body is 22 px: two tiles of it */
      out.push({ x: (c + 0.5) * T, feetY: surfaceRow * T, col: c, surfaceRow: surfaceRow });
    }
    return out;
  }

  /* ================================================================================================
   * Shaft — owns the room, the body, the line and the gates, and steps them in ONE order.
   * ================================================================================================
   * ⭐ THE ORDER IS THE DESIGN: the body moves first, then the line is stepped with the body's hand as
   * its anchor. Stepping the line first would advance the weight against last frame's hand position,
   * which is a one-frame lie that shows up as the cord lagging behind a running player.
   */
  function Shaft(fixture) {
    if (!fixture || !fixture.room) throw new Error('Shaft: a fixture with a room is required');
    this.fixture = fixture;
    this.room = fixture.room;
    this.body = new PLAT.Body(fixture.spawn.x, fixture.spawn.y, {}, this.room);
    this.line = new LINE.Line({});
    const h = this.hand();
    this.line.attach(h.x, h.y);
    /* ⛔⛔ THERE IS NO LAMP HERE, AND ITS ABSENCE IS A DECISION TAKEN ON A MEASUREMENT — 2026-09-03,
     * DESIGN §3a. The shaft used to carry one so that the dominance race compared two real
     * configurations; the race read 1.00x, and the three options for giving it a bite (light gates
     * `read()` · dark removes local confirmation · cut it) were resolved by `_probe_sight.js`:
     *
     *     TOTAL, free, permanent sight of the whole room — which is the CEILING of what any lamp of
     *     any radius burning for any length of time could ever buy — is worth 0.97-1.03x against NO
     *     sight at all, on all four gates. A marked-plate positive control in the same run reads
     *     22.0x, so the instrument can see a sight advantage when there is one to see.
     *
     * The cause is structural and it kills options A and B together: a knowledge gate is DEFINED by
     * its answer being invisible (§4 — "nothing marks it and nothing lists it"), and a light reveals
     * what is visible. The two sets do not intersect. ⇒ the lamp is CUT from the slice; `lamp.js` and
     * its mechanical self-test stay in the tree for a future project, and `_lamp_selftest.js` holds a
     * guard that goes RED if any slice module reads a lamp again without re-opening this. */
    this.datum = fixture.datum || null;
    this.frames = 0;
    this.gate = { open: false, everOpen: false, satFrames: 0, firstOpenFrame: -1 };
    this.def = fixture.gate;
    /* the barrier starts CLOSED if this gate has one */
    if (this.def && this.def.barrier) this.setBarrier(true);
  }

  Shaft.prototype.hand = function () {
    return { x: this.body.x, y: this.body.y - this.body.cfg.h * HAND_FRAC };
  };

  /* A barrier's CLOSED material is declared per gate. A door across a corridor is ROCK; a hatch in a
   * floor is GRATE — bars you can stand on and see through, which is what makes the hatch legible as
   * a way down that is currently shut rather than as a piece of wall. */
  Shaft.prototype.setBarrier = function (closed) {
    const b = this.def.barrier;
    fill(this.room, b.c0, b.r0, b.c1, b.r1, closed ? (this.def.barrierMaterial || ROCK) : OPEN);
  };

  /* Does the player's own body currently overlap the barrier's tiles? */
  Shaft.prototype.inBarrier = function () {
    const b = this.def.barrier;
    const hw = this.body.cfg.w / 2;
    const l = this.body.x - hw, r = this.body.x + hw;
    const t = this.body.y - this.body.cfg.h, bo = this.body.y;
    return r > b.c0 * T && l < (b.c1 + 1) * T && bo > b.r0 * T && t < (b.r1 + 1) * T;
  };

  Shaft.prototype.step = function (dt, input) {
    const inp = input || {};
    this.body.step(dt, inp, this.room);
    const h = this.hand();
    this.line.step(dt, inp, this.room, h.x, h.y);
    this.frames++;

    const sat = !!this.def.satisfied(this);
    if (sat) {
      this.gate.satFrames++;
      if (!this.gate.everOpen) this.gate.firstOpenFrame = this.frames;
      this.gate.everOpen = true;
    }
    /* ⚠️ LATCH vs HOLD is a real design difference and it is declared per gate, not assumed. A
     * mechanism that trips STAYS tripped; a door held open by a weight closes when the weight
     * leaves. Three of these four latch; the third does not, and that is the whole of its puzzle. */
    this.gate.open = this.def.latch ? this.gate.everOpen : sat;

    if (this.def.barrier) {
      /* ⛔ A PORTCULLIS DOES NOT CLOSE THROUGH THE PLAYER, AND THIS IS A DECISION RATHER THAN A
       * DEFAULT. `overlapsSolid` fails CLOSED, so filling the barrier's tiles while a body stands in
       * them freezes that body in rock with every check green — the §0z shape where a guard working
       * and a defect are indistinguishable. It stays open while occupied. */
      this.setBarrier(!this.gate.open && !this.inBarrier());
    }
    return this;
  };

  /* Convenience for the gates: is the weight resting inside a named tile span, with slack? */
  function weighted(shaft, c0, c1, row) {
    const h = shaft.hand();
    if (!shaft.line.weight(h.x, h.y)) return false;
    const bx = shaft.line.bx, by = shaft.line.by;
    if (bx < c0 * T || bx > (c1 + 1) * T) return false;
    /* the weight must be standing ON that row, not merely above it somewhere */
    return Math.abs((by + LINE.DEFAULTS.bob / 2) - row * T) < 2.0;
  }

  /* ================================================================================================
   * G1 — THE BARRED GALLERY.  POSITIONAL.  "Know WHICH."
   * ================================================================================================
   * A gallery floored with iron bars. You can see the chamber below and you can never go there; the
   * weight can. One plate on that chamber's floor opens the way on. Nothing marks it and nothing
   * lists it — the knowledge is a place, and the only act is the one act the instrument has.
   */
  /* ⛔⛔ THE GALLERY IS 140 BAYS LONG BECAUSE THE PRE-REGISTERED BAR SAYS SO, AND THAT IS THE MOST
   * USEFUL THING THIS FILE PRODUCED. The first build made it 40 bays and measured D1 at **10.5x**
   * against a bar of 20x. The tempting move was to lower the bar; the second-most tempting was to
   * declare the mechanism broken. Both are wrong, and the arithmetic says why:
   *
   *     ratio(n) = (n/2)(t + a) / ((n/2)t + a)       t = walk between adjacent bays (0.123 s)
   *                                                  a = the cost of one attempt   (3.4 s)
   *
   * — which rises with n toward a CEILING of `1 + a/t` = **27.8x**, reached from below. So the bar is
   * satisfiable and it fixes the size: n = 140 gives 20x, and no gallery of this shape can ever beat
   * 28x however long it is, because the searcher pays the same per-bay walk the knower does.
   * ⭐ THAT CEILING IS THE REAL FINDING and it generalises past this game: **the brute-force
   * advantage of a positional gate is bounded by how expensive one attempt is RELATIVE to travel
   * between candidates, so candidates that are cheap to reach are candidates that are cheap to
   * exhaust.** A corridor of adjacent bays is the WORST case of that, and it is what this fixture is.
   * ⚠️ It also reconciles this file with DESIGN §4, which measured the same archetype at 91.5x — that
   * model assumed `posAttempt: 25 s` and `travelToGate: 8 s` (`Research/dominance_metroidbrainia.json`),
   * i.e. candidates scattered across a region rather than laid side by side. §6b-2b rule 3: before
   * calling two instruments contradictory, check they are measuring the same fight. They were not,
   * and the DENSE arrangement measured here is the pessimistic one — so a real shaft that spreads
   * these bays over several chambers can only do better. */
  /* ⛔⛔ 140 BAYS -> 64, AND A CHAMBER FOUR TILES DEEP -> EIGHT. BOTH ARE CORRECTIONS ON A
   * MEASUREMENT (`_probe_cost.js`, 2026-09-03) AND NEITHER IS A LOOSENING OF THE BAR.
   *
   * 1. **The formula above was wrong, and wrong in the direction that made this corridor long.** It
   *    charges ONE travel cost to both agents. They do not travel the same way: a searcher walks a
   *    bay, STOPS, lowers, reels in, walks a bay (MEASURED 0.4333 s/bay), while a knower RUNS the
   *    corridor once (MEASURED 0.1260 s/bay over the same ground, 3.4x cheaper). Corrected —
   *    `ratio(n) = (n/2)(tStop + a) / ((n/2)tRun + a0)` — the model tracks the harness to **0.6%**,
   *    where the old one was out by 68%, and it says the 20x bar is met at **86 bays**, not 140.
   * 2. ⛔ **AND THE HEADLINE D1 WAS PARTLY AN ARTEFACT OF THE HARNESS.** `PAY_OUT` models a player who
   *    holds the key until the reel is EMPTY. A player who lets go when the weight LANDS is cheaper,
   *    and the searcher pays that difference n/2 times against the knower's once — so this gate read
   *    **22.4x under the shipped model and 13.6x under the efficient one**, i.e. it never met its own
   *    bar. The other three gates barely move (25.6 -> 25.6, 62.6 -> 58.1, 22.1 -> 25.6) and the
   *    reason names the cause: on those the weight either never rests or rests at nearly full
   *    extension, so the two models are THE SAME ACT. Only this gate had a shallow chamber.
   * ⇒ The chamber is now EIGHT tiles deep (plate row 17, span 138.2 px against a 160 px cord,
   *   21.8 px of slack — comfortably above `line.js` `slackEps` 0.75), so paying out fully and
   *   paying out until it lands converge; and with `payRate`/`reelRate` slowed 1.5x (see line.js) the
   *   gate reads **21.3x under the STRICTER model** at 64 bays.
   * ⭐ The point of the whole exercise is DESIGN §4c: 64 bays is a corridor a player can hold in
   *   their head, and 140 was not. The bar did not move; the arithmetic under it was wrong, and one
   *   of the two levers in it had never been touched. */
  const G1_BAYS = 64, G1_LAST = 1 + G1_BAYS, G1_FLOOR = 9, G1_PLATE_ROW = 17;
  const G1 = {
    id: 'barred-gallery',
    kind: 'positional',
    latch: true,
    title: 'THE BARRED GALLERY',
    knowledge: 'which of sixty-four bays the plate lies under',
    plate: { c0: 46, c1: 46, row: G1_PLATE_ROW },
    build: function () {
      const room = solidRoom(G1_LAST + 4, G1_PLATE_ROW + 4);
      carveGallery(room, 2, G1_LAST, G1_FLOOR);              /* gallery air under a de Bruijn roof */
      fill(room, 2, G1_FLOOR, G1_LAST, G1_FLOOR, GRATE);     /* the barred floor */
      fill(room, 2, G1_FLOOR + 1, G1_LAST, G1_PLATE_ROW - 1, OPEN);  /* the deep chamber below */
      return { room: room, spawn: { x: 3.5 * T, y: G1_FLOOR * T }, gate: G1 };
    },
    satisfied: function (shaft) { return weighted(shaft, G1.plate.c0, G1.plate.c1, G1.plate.row); },
    candidates: function (shaft) { return standableSlots(shaft.room, G1_FLOOR, 2, G1_LAST).map((s) => ({ x: s.x, col: s.col })); },
    answerCol: 46,
    attempt: 'lower',
  };

  /* ================================================================================================
   * G2 — THE SUMP.  POSITIONAL, in TWO dimensions.  "Know that you cannot do it from up here."
   * ================================================================================================
   * The same act, one level down. The sump's floor is 218 px below the gallery's hand and the cord is
   * 160 px long, so from the gallery the weight hangs TAUT in the dark above the plate, touching
   * nothing — which is exactly what `line.weight()` refuses (a bob held up by its own cord presses
   * nothing). The knowledge is not a bay, it is a LEVEL: there is a floor under the bars and a way
   * down at the gallery's end.
   * ⭐ THIS IS THE GATE THAT MAKES A HORIZONTAL SWEEP USELESS. §6b-15's coverage argument in reverse:
   * a searcher who sweeps one row exhausts a whole surface and learns nothing, because the answer is
   * not on that surface at all.
   */
  /* ⛔⛔ THE PLATE IS ON AN OPEN FLOOR AND **NOT** IN A PIT, AND THAT IS A CORRECTION, NOT A CHOICE.
   * The first build put it at the bottom of a narrow sump and the SWEEP CONTROL opened the gate on
   * four of its five modes. The mechanism is worth writing down because it is a law about every
   * plate this game will ever have:
   *   there is NO FLOOR FRICTION, so a weight dragged behind a walking player slides until the cord
   *   catches it — i.e. it comes to rest at FULL EXTENSION, where the slack is ~0 and
   *   `line.weight()` correctly refuses it. A dragged weight therefore cannot press anything...
   *   UNLESS something STOPS it: a wall, a corner, or a pit. Anything that traps the weight lets
   *   slack develop while the player is still nearby, and that is a weight SET DOWN by accident.
   * ⇒ **A PLATE MUST LIE ON OPEN FLOOR, MORE THAN A CORD-LENGTH FROM ANY WALL OR PIT THAT COULD HOLD
   *    THE WEIGHT STILL.** The sump idea is not lost — the DEPTH is still the puzzle, it is just the
   *    chamber that is deep rather than a hole in its floor. */
  const G2 = {
    id: 'the-sump',
    kind: 'positional',
    latch: true,
    title: 'THE SUMP',
    knowledge: 'that the plate cannot be reached from the gallery at all, and that there is a floor below it',
    plate: { c0: 40, c1: 40, row: 20 },
    descendAtX: 70.5 * T,                     /* walk off the gallery's right end and fall */
    build: function () {
      const room = solidRoom(75, 26);
      carveGallery(room, 2, 71, 9);           /* gallery air under the same de Bruijn roof */
      fill(room, 2, 9, 68, 9, GRATE);         /* barred gallery floor, ending at col 68 */
      fill(room, 69, 9, 71, 9, OPEN);         /* the way down: a hole at the gallery's end */
      /* ⭐ TEN TILES OF AIR, AND THE NUMBER IS LOAD-BEARING. The cord is 160 px. From the gallery the
       * hand sits at y 130.8 and this chamber's floor rests the weight at y 317, a span of 186.2 —
       * so from up there the weight hangs TAUT in the dark, touching nothing, and `line.weight()`
       * refuses it everywhere along the gallery. From the chamber's own floor the same weight sits
       * at a span of 10.2 with 149.8 px of slack. The gate is not hidden; it is out of reach. */
      fill(room, 2, 10, 71, 19, OPEN);
      return { room: room, spawn: { x: 3.5 * T, y: 9 * T }, gate: G2 };
    },
    satisfied: function (shaft) { return weighted(shaft, G2.plate.c0, G2.plate.c1, G2.plate.row); },
    candidates: function (shaft) {
      /* ⚠️ ORDER IS THE SEARCHER'S ORDER AND IT IS THE GENEROUS ONE: sweep the surface you are
       * standing on, then take the only way down and sweep that. A searcher who had to guess to
       * descend would cost more, so this understates the brute-force figure — against interest. */
      const gallery = standableSlots(shaft.room, 9, 2, 68).map((s) => ({ x: s.x, col: s.col, level: 'gallery' }));
      const below = standableSlots(shaft.room, 20, 2, 71).map((s) => ({ x: s.x, col: s.col, level: 'chamber' }));
      below.reverse();                        /* you arrive at the right-hand end, so you sweep back */
      return gallery.concat(below);
    },
    answerCol: 40,
    answerLevel: 'chamber',
    attempt: 'lower',
    route: function (cand, shaft) {
      /* Waypoints, in order. Descending is free; there is no way back up, which is why the searcher
       * exhausts the gallery FIRST.
       * ⚠️ THE ROUTE READS THE SHAFT, and that is not laziness — a searcher already standing in the
       * chamber must not be sent back to the hole it fell through. Charging it that walk on every
       * one of forty candidates would inflate the brute-force cost by roughly a third, and every
       * number in the NO-BRUTE-FORCE table is supposed to be the GENEROUS reading of what a
       * determined player without the knowledge would spend (§6b-4 rule 1: an arm you configured is
       * not evidence, and a cost you padded is not a measurement). */
      if (cand.level !== 'chamber') return [cand.x];
      const alreadyBelow = shaft && shaft.body.y >= 20 * T - 1;
      return alreadyBelow ? [cand.x] : [G2.descendAtX, cand.x];
    },
  };

  /* ================================================================================================
   * G3 — THE HOLD.  PROCEDURAL.  "Leave it behind."
   * ================================================================================================
   * The door is held open by the weight and by nothing else, so the player has to walk away from
   * their own instrument and through the door while the cord is still paid out — losing, for as long
   * as it takes, the ability to know where they are. That is DESIGN §3's kept coincidence stated as a
   * puzzle: the line measures AND acts, and here it cannot do both.
   *
   * ⛔ IT DOES NOT LATCH. Everything else in this file trips and stays tripped; this one is true only
   * while the weight is down, which is why walking too far is a fail state you can see — the cord
   * goes taut, snatches the weight off the plate, and the bars shut under your feet.
   * ⭐ AND THE POSITIONAL HALF IS NOT DECORATION: the hatch is at most 160 px of cord from the plate,
   * so a player who lowers in the wrong bay has NO route to it with the weight down.
   *
   * ⛔⛔ IT WAS A DOOR ACROSS THE GALLERY AND THE SWEEP CONTROL OPENED IT. That is worth recording as
   * a law rather than as a bug, because it is the same law G2 taught one gate earlier:
   *   a closed door is A WALL, and a wall is FREE STILLNESS. The sweeper ran into the door, stopped,
   *   and the weight it had been dragging swung to rest a cord-length behind it — which was, by the
   *   geometry the design REQUIRES (the plate must be within a cord of the far side of the door),
   *   exactly on the plate. Measured twice, at `player x=1099 weight x=987 slack=25.0`.
   * ⇒ The two configurations were not separable by geometry OR by slack, because the knower standing
   *   past the door and the sweeper pinned against it end up in nearly the same posture. **A HATCH
   *   HAS NO NEAR SIDE TO BE PINNED AGAINST.** The plate now sits nine hundred pixels from the
   *   nearest wall — well beyond a cord — so nothing can hold the weight still on it by accident,
   *   which is G1's property restated. The mechanic is also better: the bars you were standing on
   *   open while the weight holds them, and you drop through the floor you could not pass.
   */
  const G3 = {
    id: 'the-hold',
    kind: 'procedural',
    latch: false,
    title: 'THE HOLD',
    knowledge: 'that you must leave the weight where it lies and walk on without it',
    plate: { c0: 60, c1: 61, row: 13 },
    /* the HATCH: two bays of the gallery's own floor, barred when the plate is unweighted */
    barrier: { c0: 64, c1: 65, r0: 9, r1: 9 },
    barrierMaterial: GRATE,
    throughX: 64.5 * T,                       /* stand on the hatch */
    build: function () {
      const room = solidRoom(145, 20);
      carveGallery(room, 2, 141, 9);
      fill(room, 2, 9, 141, 9, GRATE);
      fill(room, 2, 10, 141, 12, OPEN);
      return { room: room, spawn: { x: 3.5 * T, y: 9 * T }, gate: G3 };
    },
    /* the DOOR's own condition — the weight on the plate */
    satisfied: function (shaft) { return weighted(shaft, G3.plate.c0, G3.plate.c1, G3.plate.row); },
    /* ...and the gate is only PASSED when the player is THROUGH it, which is a different fact: they
     * have to be standing on the chamber floor below, having dropped through the bars they were
     * walking on. ⚠️ `onGround` matters — mid-fall is not through. */
    passed: function (shaft) { return shaft.body.y >= 13 * T - 1 && shaft.body.onGround; },
    /* ⚠️ THE DOOR ITSELF REMOVES A BAY FROM THE CANDIDATE SPACE while it is closed — col 66 has no
     * headroom — so this count is 139 rather than 140 and it is a function of the door's STATE. Said
     * out loud because a later reader comparing gate sizes would otherwise find an off-by-one. */
    candidates: function (shaft) { return standableSlots(shaft.room, 9, 2, 141).map((s) => ({ x: s.x, col: s.col })); },
    answerCol: 60,
    attempt: 'lower-then-walk',
  };

  /* ================================================================================================
   * G4 — THE FALL.  PROCEDURAL.  "The weight is not a key, it is a hammer."
   * ================================================================================================
   * A seal in the floor of a deep chamber. Lowering the weight onto it does nothing at all — a
   * lowering arrives at 97-168 px/s (MEASURED, `_probe_arrival.js`) and the seal answers only to a
   * blow, which `line.js` defines as an arrival worth a full tile of free fall, 219.1 px/s.
   *
   * ⭐ THE ACT, AND IT IS THE ONE THING IN THIS GAME THAT JOINS THE TWO SYSTEMS: with the weight
   * resting at nearly full extension there are only a few pixels of slack in the cord, so JUMPING
   * snatches it up the length of the jump and it falls back onto the seal hard. Nothing lists it.
   * Nothing on the surface of the game suggests that the platformer verb does anything to the
   * instrument. ⚠️ It is forgiving on purpose — the weight is already plumb over the seal before you
   * jump, so there is nothing to aim, which is what keeps a procedural gate inside DESIGN §4's
   * fairness bar (D3: the knower acts once and is certain).
   */
  const G4 = {
    id: 'the-fall',
    kind: 'procedural',
    latch: true,
    title: 'THE FALL',
    knowledge: 'that the seal answers to a blow and not to a weight, and that the jump is what strikes it',
    seal: { c0: 70, c1: 72, row: 18 },
    build: function () {
      const room = solidRoom(145, 22);
      carveGallery(room, 2, 141, 9);
      fill(room, 2, 9, 141, 9, GRATE);
      /* ⭐ THE DEPTH IS THE MECHANISM. Eight tiles of air puts the resting weight at a span of 154.2
       * against 160 px of cord — SIX pixels of slack — so a jump of 36 px snatches it thirty pixels
       * up the line and it falls back onto the seal at ~300 px/s, comfortably past the 219.1 px/s a
       * blow requires. Make this chamber shallower and the jump does nothing at all. */
      fill(room, 2, 10, 141, 17, OPEN);
      return { room: room, spawn: { x: 3.5 * T, y: 9 * T }, gate: G4 };
    },
    /* ⛔ THE BLOW MUST BE SQUARE, AND THAT CLAUSE IS HERE BECAUSE THE SWEEP CONTROL PUT IT HERE.
     * Without `plumbTol` a player holding jump while running with the line out strikes EVERYTHING it
     * drags over — measured, the sweeper opened this gate at `player x=1103 weight x=1133 slack=2.3`,
     * because at near-full extension every jump snatches the weight up and drops it again. A weight
     * hanging plumb under a standing player lands flat on what is beneath it; a weight arriving from
     * a hundred and forty pixels to the side is a graze. MEASURED, `_probe_plumb.js`: the knower's
     * blow lands at |dx| **7.6 px** and the squarest blow a sweeping player lands ON THIS SEAL is
     * **30.9 px**, so one tile sits between them with about 2x of margin on each side — and the
     * suite RE-DERIVES both numbers every run (S1c) rather than trusting this comment.
     * ⚠️⚠️ THE HONEST CAVEAT, and it is why this clause is not the whole answer: across the same
     * sweep the smallest |dx| ANYWHERE in the chamber is **0.5 px**. A dragged weight does sometimes
     * come to rest and land square — just not where the seal is. So the angle clause separates the
     * two players HERE because of where the seal sits, which is the same law the plates obey:
     * **a seal must not be placed where a dragged weight comes to rest** (a wall, a corner, a pit).
     * ⛔ A later session moving this seal must re-run `_probe_plumb.js`, not assume the margin. */
    /* ⛔ 16 (one tile) -> 12, MOVED 2026-09-03 BECAUSE THE MEASURED POPULATIONS MOVED, NOT BY FEEL.
     * The de Bruijn roofline changed how a sweeping player travels this chamber, and `_probe_plumb.js`
     * re-measured both populations: the knower's worst blow is now |dx| **7.5 px** and the squarest
     * blow a sweeper lands ON THIS SEAL is **21.5 px** (it was 7.6 and 30.9 under a flat roof). One
     * tile no longer sits with margin inside that window — 16 x 1.5 = 24 is outside 21.5 — and S1c
     * caught it. 12 is the geometric centre of the new window (sqrt(7.5 x 21.5) = 12.7, rounded to a
     * whole number of pixels), so it carries 1.6x of margin on each side.
     * ⚠️ It is a CONSTANT and the suite RE-DERIVES the window every run rather than trusting this
     * comment; if a later change moves the populations again, S1c goes red rather than silent. */
    plumbTol: 12,
    satisfied: function (shaft) {
      const im = shaft.line.impact;
      if (im.atStep < 0) return false;
      if (im.speed <= shaft.line.impactSpeed()) return false;
      if (Math.abs(im.dx) > G4.plumbTol) return false;
      if (im.x < G4.seal.c0 * T || im.x > (G4.seal.c1 + 1) * T) return false;
      return Math.abs((im.y + LINE.DEFAULTS.bob / 2) - G4.seal.row * T) < 3.0;
    },
    candidates: function (shaft) { return standableSlots(shaft.room, 9, 2, 141).map((s) => ({ x: s.x, col: s.col })); },
    answerCol: 71,
    attempt: 'lower-then-jump',
  };

  const GATES = [G1, G2, G3, G4];

  /* ================================================================================================
   * THE ATTEMPT RUNNER — the SAME code for the knower and the brute-forcer.
   * ================================================================================================
   * Phases are declarative so that "what a player does at a candidate" is written once per gate kind
   * and cannot quietly differ between the two agents being compared.
   * ⛔ EVERY PHASE HAS A FRAME CAP AND A CAP IS REPORTED, NEVER SWALLOWED. §6b-9 rule 2: a
   * three-valued outcome read through a two-valued field is a green lie waiting — a phase that ran
   * out of frames is neither a success nor a failure of the DESIGN, it is a failure of the harness,
   * and the two must not share a value.
   */
  const DT = 1 / 60;
  const CAP = { walk: 2400, payOut: 300, settle: 400, jump: 90, reel: 300 };
  const STALL_FRAMES = 90;   /* 1.5 s of no progress toward the goal — long enough to clear a step */

  /* ⛔ STALLING IS DETECTED BY **PROGRESS TOWARD THE GOAL**, NEVER BY "DID THE POSITION CHANGE".
   * §6b-4 rule 2, paid for on LANTERNBOUND: a bot that OSCILLATES is a wedged bot that defeats a
   * moved-or-not detector, and one there walked 25,900 px with its distance to the goal constant for
   * 200 seconds. It matters here for a second reason too — a walk into a CLOSED DOOR is the correct
   * outcome of a naive attempt at G3, and if that took the full 2400-frame cap the brute-force cost
   * of a wrong strategy would be forty seconds of harness rather than the second and a half a player
   * would spend before turning round. ⚠️ A stall is reported SEPARATELY from a cap: one is the world
   * refusing, the other is the harness giving up, and a three-valued outcome read through a
   * two-valued field is a green lie waiting (§6b-9 rule 2). */
  function walkPhase(targetX) {
    let best = Infinity, stall = 0;
    return {
      name: 'walk->' + Math.round(targetX),
      cap: CAP.walk,
      stalled: false,
      input: function (shaft) {
        const dx = targetX - shaft.body.x;
        const inp = {};
        if (dx > 1.5) inp.right = true; else if (dx < -1.5) inp.left = true;
        /* jump when the walk is not making progress: a step up, a closed door, a wall. A bot that
         * cannot get past furniture produces a red that describes the BOT (§6b-3 rule 1). */
        if (shaft.body.onGround && Math.abs(shaft.body.vx) < 6 && Math.abs(dx) > 1.5) {
          inp.jump = true; inp.jumpHeld = true;
        }
        return inp;
      },
      done: function (shaft) {
        const d = Math.abs(shaft.body.x - targetX);
        if (d < best - 0.5) { best = d; stall = 0; } else stall++;
        if (d <= 2.5 && shaft.body.onGround && Math.abs(shaft.body.vx) < 12) return true;
        if (stall > STALL_FRAMES) { this.stalled = true; return true; }
        return false;
      },
    };
  }
  const PAY_OUT = {
    name: 'payOut',
    cap: CAP.payOut,
    input: function () { return { payOut: true }; },
    done: function (shaft) { return shaft.line.out >= shaft.line.maxLen - 1e-6; },
  };
  const SETTLE = {
    name: 'settle',
    cap: CAP.settle,
    input: function () { return {}; },
    /* ⚠️ SETTLING IS ALLOWED TO END WITHOUT THE WEIGHT RESTING, and that is not a harness failure: a
     * weight hanging taut in a shaft too deep for the cord NEVER rests, and that is precisely the
     * state G2 is about. The phase ends when the weight has stopped moving, resting or not. */
    done: function (shaft) { return Math.hypot(shaft.line.bvx, shaft.line.bvy) <= LINE.DEFAULTS.restSpeed; },
  };
  const REEL_IN = {
    name: 'reelIn',
    cap: CAP.reel,
    input: function () { return { reelIn: true }; },
    done: function (shaft) { return shaft.line.out <= 0; },
  };
  const JUMP = {
    name: 'jump',
    cap: CAP.jump,
    input: function (shaft, n) { return n < 10 ? { jump: n === 0, jumpHeld: true } : {}; },
    done: function (shaft, n) { return n > 45 && shaft.body.onGround; },
  };

  /* The plan for one attempt at one candidate. `variant` is how much the agent KNOWS about the act —
   * never about the answer, which is the candidate itself. */
  /* ⛔ EVERY PLAN STARTS BY REELING IN, AND THAT IS A FIX FOR A MEASURED DEFECT RATHER THAN TIDINESS.
   * A search is ONE continuous session, so the second attempt inherits whatever the first left
   * behind. With `lower-then-walk` the informed plan deliberately never reels in — that is its whole
   * point — so on the first build the searcher walked its remaining 138 candidates DRAGGING the
   * weight, `PAY_OUT` was already satisfied and completed instantly, and the weight was never under
   * the hand at any of them. The gate opened ZERO times for a knowing searcher while the knower
   * opened it on its first try, i.e. a red that described the harness. Bringing the weight to hand
   * before walking is also what a player does. */
  function plan(gate, cand, variant, shaft) {
    const waypoints = gate.route ? gate.route(cand, shaft) : [cand.x];
    const walkIn = waypoints.map(walkPhase);
    const lower = [REEL_IN].concat(walkIn, [PAY_OUT, SETTLE]);
    if (gate.attempt === 'lower') return lower;
    if (gate.attempt === 'lower-then-jump') {
      /* NAIVE: lower and wait, which is the whole of what the positional gates ask for.
       * INFORMED: lower, and then jump on the line. */
      return variant === 'naive' ? lower : lower.concat([JUMP, SETTLE]);
    }
    if (gate.attempt === 'lower-then-walk') {
      /* NAIVE: take your instrument with you, which is what anyone does with a tool.
       * INFORMED: leave it lying there and walk on without it. The ONLY difference between the two
       * plans is one `REEL_IN`, which is as close as this file can get to saying "the act is the
       * thing being tested, and nothing else differs". */
      return variant === 'naive'
        ? lower.concat([REEL_IN, walkPhase(gate.throughX)])
        : lower.concat([walkPhase(gate.throughX)]);
    }
    throw new Error('plan: unknown attempt kind ' + gate.attempt);
  }

  /**
   * Run one attempt and report what happened. Returns counts of WORK — frames, seconds, which phase
   * capped — plus the outcome, never a bare boolean (master §2b rule 2).
   */
  /* ⚠️ `mkPlan` EXISTS SO A PROBE CAN ASK WHAT THIS HARNESS DOES NOT SEE, AND FOR NO OTHER REASON.
   * The wing's standing question (§0z) is *name the states, directions and inputs this instrument
   * never sees, then go and look at one*. This runner models a player who holds the pay-out key until
   * the reel is EMPTY; a player who lets go the moment the weight lands is a different, cheaper
   * player, and the searcher pays that difference n/2 times while the knower pays it once — so the
   * headline D1 number is sensitive to a choice nobody had ever varied. `_probe_cost.js` varies it.
   * ⛔ It is an override for MEASUREMENT, never a second shipped plan: two plans that can disagree
   * about what an attempt costs is the §6b-6 rule 2 defect (the checker reading a different input
   * from the thing under test). Every ASSERTION in the suite uses the default. */
  function runAttempt(shaft, gate, cand, variant, mkPlan) {
    const phases = (mkPlan || plan)(gate, cand, variant, shaft);
    const openBefore = shaft.gate.everOpen;
    let frames = 0, capped = null, stalled = null;
    /* per-phase frame counts. ⭐ Needed by the LAMP (build order item 5), whose whole economy is the
     * cost of LOOKING: the oil an attempt spends is the time spent watching the weight settle, so
     * `settle` has to be separable from `walk`. Counts of work, and they cost nothing to keep. */
    const byPhase = {};
    for (const ph of phases) {
      let n = 0;
      while (!ph.done(shaft, n)) {
        if (n >= ph.cap) { capped = ph.name; break; }
        shaft.step(DT, ph.input(shaft, n));
        n++; frames++;
      }
      const key = ph.name.replace(/->-?\d+/, '');
      byPhase[key] = (byPhase[key] || 0) + n;
      if (ph.stalled && !stalled) stalled = ph.name;
      if (capped) break;
    }
    /* ⛔ "THIS ATTEMPT OPENED IT", NOT "IT IS OPEN". Three of the four gates LATCH, so on a
     * continuous search every attempt after the winning one would read `open === true` and the
     * searcher's cost would collapse to the cost of its first attempt. Credit the attempt during
     * which the state actually CHANGED. §6b-9 rule 2's family: reading a persistent fact as if it
     * were a per-attempt one is how a harness reports work it did not do. */
    const win = gate.passed ? gate.passed(shaft) : (shaft.gate.everOpen && !openBefore);
    return {
      opened: !!win,
      gateEverOpen: shaft.gate.everOpen,
      frames: frames,
      seconds: frames * DT,
      byPhase: byPhase,
      settleSeconds: (byPhase.settle || 0) * DT,
      capped: capped,
      stalled: stalled,
    };
  }

  /* A fresh shaft per attempt. ⛔ §6b-14 rule 1, paid for on HEARTHWARD: an arm that inherits the
   * previous arm's state is not a sample of the design, and there it produced a design finding that
   * was 3.8x wrong and read as a story. Every attempt below starts from the spawn point. */
  function freshShaft(gate) { return new Shaft(gate.build()); }

  const API = {
    Shaft: Shaft, GATES: GATES, G1: G1, G2: G2, G3: G3, G4: G4,
    standableSlots: standableSlots, runAttempt: runAttempt, freshShaft: freshShaft,
    plan: plan, fill: fill, solidRoom: solidRoom,
    /* the phase primitives, exported for `mkPlan` probes only — see runAttempt's header */
    PHASES: { REEL_IN: REEL_IN, PAY_OUT: PAY_OUT, SETTLE: SETTLE, JUMP: JUMP, walkPhase: walkPhase, CAP: CAP },
    /* the survey roofline — exported so a probe can prove it is uniform, dense and answer-blind */
    ROOF_SEQ: ROOF_SEQ, ROOF_WINDOW: ROOF_WINDOW, ROOF_HEIGHTS: ROOF_HEIGHTS,
    ROOF_MIN_TILES: ROOF_MIN_TILES, JUMP_APEX: JUMP_APEX, ROOF_CLEAR_PX: ROOF_CLEAR_PX,
    roofRow: roofRow, roofWindow: roofWindow, carveGallery: carveGallery, deBruijn: deBruijn,
    HAND_FRAC: HAND_FRAC, DT: DT, T: T,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  root.PL_GATES = API;
})(typeof globalThis !== 'undefined' ? globalThis : this);
