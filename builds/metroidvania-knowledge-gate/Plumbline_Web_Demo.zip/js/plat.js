/* ================================================================================================
 * plat.js — PLUMBLINE's platformer core. Run, jump, dash, and collide with a tile grid.
 * ================================================================================================
 * DESIGN.md §2: the primary input is continuous platforming and there is no menu in the loop, so
 * this file IS the game's verb. Everything else in PLUMBLINE is a thing you reach by moving well.
 *
 * ⛔ DUAL-MODE BY CONSTRUCTION, AND IT IS NOT OPTIONAL. Wing §6b-5 rule 1: a bare `require()` at the
 * top of a file that a `<script>` tag also loads is a fatal ReferenceError whose only symptom is a
 * blank canvas. And §6b-5 rule 2: plain `<script>` tags share ONE global scope, so every top-level
 * `const` here would collide with an identically-named one in a sibling file — hence the IIFE. Both
 * of those cost LANTERNBOUND real sessions; they are paid for once, here, at the start.
 *
 * ⛔ NO `Math.random` ANYWHERE IN THIS FILE. A balance harness that cannot replay a run cannot
 * investigate one (§6b rule 1), and PLUMBLINE's gates are POSITIONAL — a physics core that is not
 * deterministic makes "can the player reach that ledge?" unanswerable.
 *
 * ⭐ WHO OWNS THE CLOCK: the CALLER does. `step(dt)` advances by exactly the dt it is handed and
 * reads real time never. §6b-2's closing rule — the LANTERNBOUND flame burned at twice its tuned
 * rate because both the model and the browser were advancing it — cost a whole balance document.
 * ---------------------------------------------------------------------------------------------- */
'use strict';

(function (root) {
  /* ---- tuning. Every number is a FEEL constant and none of them is a difficulty knob. ---------- */
  const DEF = {
    tile: 16,               /* px. The grid PLUMBLINE's rooms are authored on.                     */
    w: 10, h: 22,           /* px, the player's AABB — narrower than a tile so doorways forgive    */

    runAccel: 1400,         /* px/s^2 while a direction is held                                    */
    runDecel: 2000,         /* px/s^2 while nothing is held (crisper than accel: stopping is snappy)*/
    runMax: 130,            /* px/s                                                                */
    airControl: 0.65,       /* fraction of runAccel that applies with no ground under you          */

    gravity: 1500,          /* px/s^2                                                              */
    fallMax: 520,           /* px/s terminal — see the substep note in step()                      */
    jumpSpeed: 330,         /* px/s upward impulse                                                 */
    /* ⭐ VARIABLE JUMP HEIGHT, and it is one line: releasing the button early CUTS the remaining
     * upward velocity instead of switching gravity. A player who taps gets a small hop and a player
     * who holds gets the full arc, from one number, with no second gravity constant to keep in sync. */
    jumpCut: 0.45,

    /* ⚠️ COYOTE TIME AND JUMP BUFFER ARE NOT POLISH, THEY ARE THE DIFFERENCE BETWEEN A GAME THAT
     * FEELS BROKEN AND ONE THAT DOES NOT — and in a game whose gates are POSITIONAL (DESIGN §4) they
     * are load-bearing: a player who knows exactly where the ledge is and still misses it by two
     * frames will conclude the KNOWLEDGE was wrong, which is the one wrong lesson this game can
     * teach. */
    coyote: 0.10,           /* sec after leaving ground during which a jump still fires            */
    jumpBuffer: 0.12,       /* sec before landing during which a jump press is remembered          */

    dashSpeed: 300,         /* px/s                                                                */
    dashTime: 0.16,         /* sec the dash lasts                                                  */
    dashCooldown: 0.45,     /* sec before another dash — refreshed on landing, see step()          */

    /* ⛔ THE SUBSTEP CEILING. At fallMax 520 px/s and a 1/60 s frame the body moves 8.7 px, which is
     * already over half a 16 px tile; one bad frame (a tab regaining focus, a slow machine) and a
     * body TUNNELS through a floor. Movement is therefore split so no substep exceeds this. It is
     * expressed in PIXELS rather than as a substep count so it stays correct if `tile` changes. */
    maxStepPx: 4,

    /* ⛔ A BODY NEVER PASSES BARS. Declared here rather than assumed absent, because `overlapsSolid`
     * reads it off the shape's cfg and an undeclared key would make the asymmetry above depend on a
     * property nobody wrote down. line.js's bob shim is the one place this is true. */
    passGrate: false,
  };

  /* ---- tile MATERIALS. Three, and the third is what makes the plumb line a reach rather than a
   * gadget: BARS. A grating is solid to a body (10 px wide, 22 tall) and open to the 6 px bob, so a
   * player standing on a barred floor can see the chamber below, can lower the weight into it, and
   * cannot go there. Every positional gate in DESIGN §5 depends on exactly that asymmetry.
   * ⛔ IT IS A MATERIAL, NOT A SECOND OPINION ABOUT COLLISION (§6d-10). There is still ONE
   * `Room.solid`; it takes WHO IS ASKING. A separate `bobSolid()` would be the second implementation
   * of a shared fact that this wing has been bitten by. */
  const OPEN = 0, ROCK = 1, GRATE = 2;

  /* A room is a plain grid of materials. `solid(tx, ty, passGrate)` is the ONE declaration of what
   * blocks — every query goes through it so a later session cannot add a second opinion (§6d-10). */
  function Room(cols, rows, cells) {
    this.cols = cols; this.rows = rows;
    this.cells = cells || new Uint8Array(cols * rows);
  }
  Room.prototype.solid = function (tx, ty, passGrate) {
    /* ⛔ OUT OF BOUNDS IS SOLID, AND THAT IS A DECISION RATHER THAN A DEFAULT. An open-world edge
     * would let a mis-tuned dash launch the player into nothing with no way back, and a silent
     * `false` here is exactly the unnamed-fallback shape §0z warns about. Rooms are sealed.
     * ⚠️ And out of bounds is solid to the BOB TOO, grate-passing or not: a weight that can leave
     * the world is a weight the player can lose, which DESIGN §3's reversibility rule forbids. */
    if (tx < 0 || ty < 0 || tx >= this.cols || ty >= this.rows) return true;
    const v = this.cells[ty * this.cols + tx];
    if (v === OPEN) return false;
    if (v === GRATE && passGrate) return false;
    return true;
  };
  Room.prototype.set = function (tx, ty, v) {
    if (tx < 0 || ty < 0 || tx >= this.cols || ty >= this.rows) return;
    /* ⛔ REFUSE AN UNKNOWN MATERIAL BY NAME. The old spelling was `v ? 1 : 0`, which silently turned
     * a GRATE (2) into plain rock — a typo'd material would have produced a level that is subtly
     * wrong everywhere and errors nowhere, which is the whole §0z silent-refusal family. */
    const n = (v === true) ? ROCK : (v === false ? OPEN : v);
    if (n !== OPEN && n !== ROCK && n !== GRATE) {
      throw new Error('Room.set: unknown material ' + JSON.stringify(v) + ' — expected 0 (open), 1 (rock) or 2 (grate)');
    }
    this.cells[ty * this.cols + tx] = n;
  };
  Room.prototype.at = function (tx, ty) {
    if (tx < 0 || ty < 0 || tx >= this.cols || ty >= this.rows) return ROCK;
    return this.cells[ty * this.cols + tx];
  };

  /* ⛔⛔ PASS THE ROOM. `onGround` IS A FACT ABOUT THE WORLD AND A CONSTRUCTOR THAT GUESSES IT LIES.
   * MEASURED 2026-09-03: the first version of this file initialised `onGround = false`
   * unconditionally, and that single false value produced TWO separate defects before the suite was
   * even finished —
   *   (1) a body constructed standing on a floor read its first step as a TOUCHDOWN, so the landing
   *       refresh wiped the dash cooldown the same frame the dash set it, and holding the dash key
   *       chained dashes forever (arm 7c, `dashes=2`);
   *   (2) a harness latching "the frame the body left the ground" latched frame 0, so an arm that
   *       believed it was testing a jump 30 frames into a FALL was testing one 30 frames into a
   *       WALK (arms 5b/5c).
   * Two unrelated symptoms, one bad default. ⇒ if a room is supplied the ground state is DERIVED;
   * if it is not, `onGround` is `null` — *unknown* — rather than a confident `false`, so a caller
   * that forgot cannot be silently told the body is airborne. Wing §0z: a silent refusal is correct
   * behaviour that cannot be told apart from a failure, so it gets a name. */
  function Body(x, y, cfg, room) {
    this.cfg = Object.assign({}, DEF, cfg || {});
    this.x = x; this.y = y;          /* CENTRE-X, FEET-Y — feet, because every gate in this game is
                                      * about standing somewhere exact and feet are what stands.   */
    this.vx = 0; this.vy = 0;
    this.onGround = room ? overlapsSolid(this, room, this.x, this.y + 0.5) : null;
    this.coyoteLeft = this.onGround ? this.cfg.coyote : 0;
    this.bufferLeft = 0;
    this.dashLeft = 0;
    this.dashCd = 0;
    this.dashDir = 0;
    this.facing = 1;
    /* counts of WORK, never verdicts (master §2b rule 2) — the self-test reads these */
    this.stats = { substeps: 0, hitsX: 0, hitsY: 0, jumps: 0, dashes: 0 };
  }

  /* AABB in world px. Kept as one function so the collision query and the debug draw cannot drift. */
  function aabb(b) {
    const hw = b.cfg.w / 2;
    return { l: b.x - hw, r: b.x + hw, t: b.y - b.cfg.h, b: b.y };
  }

  function overlapsSolid(b, room, x, y) {
    const hw = b.cfg.w / 2, T = b.cfg.tile;
    const l = x - hw, r = x + hw, t = y - b.cfg.h, bo = y;
    /* ⚠️ The -1e-6 on the far edges is what stops a body EXACTLY tile-aligned from reporting a
     * collision with the tile it is merely touching. Without it a player standing precisely on a
     * tile boundary reads as inside the wall beside them and cannot walk — the same fail-closed
     * shape as LANTERNBOUND's pixels-into-a-tile-bounds-check (§0z). */
    const tx0 = Math.floor(l / T), tx1 = Math.floor((r - 1e-6) / T);
    const ty0 = Math.floor(t / T), ty1 = Math.floor((bo - 1e-6) / T);
    /* WHO IS ASKING, carried on the shape's own cfg so there is one place it is declared. A body
     * leaves it false; line.js's bob shim sets it true. */
    const pass = !!b.cfg.passGrate;
    for (let ty = ty0; ty <= ty1; ty++) {
      for (let tx = tx0; tx <= tx1; tx++) if (room.solid(tx, ty, pass)) return true;
    }
    return false;
  }

  /**
   * One tick. `input` is {left, right, jump, jumpHeld, dash} — booleans only, because DESIGN §2
   * promises there is no menu in the loop and an input struct is where menus start.
   * ⚠️ `jump` is an EDGE (pressed this frame); `jumpHeld` is a LEVEL. They are different facts and
   * conflating them is how variable jump height silently stops working.
   */
  Body.prototype.step = function (dt, input, room) {
    const c = this.cfg;
    const inp = input || {};
    /* ⚠️ If the body was built without a room, its ground state is UNKNOWN (null), not false. Derive
     * it here, once, before anything reads it — otherwise `!wasOn` below treats "I was never told"
     * as "I was in the air" and manufactures a phantom landing on frame one (see the Body header). */
    if (this.onGround === null) {
      this.onGround = overlapsSolid(this, room, this.x, this.y + 0.5);
      if (this.onGround) this.coyoteLeft = c.coyote;
    }
    const dir = (inp.right ? 1 : 0) - (inp.left ? 1 : 0);
    if (dir !== 0) this.facing = dir;
    let startedDash = false;

    /* ---- timers. Decremented FIRST so a press this frame gets its full window. ---------------- */
    if (this.coyoteLeft > 0) this.coyoteLeft = Math.max(0, this.coyoteLeft - dt);
    if (this.bufferLeft > 0) this.bufferLeft = Math.max(0, this.bufferLeft - dt);
    if (this.dashCd > 0) this.dashCd = Math.max(0, this.dashCd - dt);
    if (inp.jump) this.bufferLeft = c.jumpBuffer;

    /* ---- dash. Overrides horizontal control for its duration, which is the whole point: a dash is
     * a COMMITMENT, and a committed move is what makes a positional gate a test of knowing rather
     * than of wiggling. ---------------------------------------------------------------------- */
    if (this.dashLeft > 0) {
      this.dashLeft = Math.max(0, this.dashLeft - dt);
      this.vx = this.dashDir * c.dashSpeed;
      this.vy = 0;                       /* a flat dash — readable, and it makes gaps measurable */
    } else {
      if (inp.dash && this.dashCd <= 0) {
        this.dashLeft = c.dashTime;
        this.dashCd = c.dashCooldown;
        this.dashDir = dir !== 0 ? dir : this.facing;
        this.vx = this.dashDir * c.dashSpeed;
        this.vy = 0;
        this.stats.dashes++;
        startedDash = true;
      } else {
        /* ---- run ---------------------------------------------------------------------------- */
        const accel = (this.onGround ? c.runAccel : c.runAccel * c.airControl) * dt;
        if (dir !== 0) {
          this.vx += dir * accel;
          if (this.vx > c.runMax) this.vx = c.runMax;
          if (this.vx < -c.runMax) this.vx = -c.runMax;
        } else {
          const d = c.runDecel * dt;
          if (this.vx > 0) this.vx = Math.max(0, this.vx - d);
          else if (this.vx < 0) this.vx = Math.min(0, this.vx + d);
        }
      }

      /* ---- jump: buffered press + (grounded OR coyote) ------------------------------------- */
      if (this.bufferLeft > 0 && (this.onGround || this.coyoteLeft > 0)) {
        this.vy = -c.jumpSpeed;
        this.onGround = false;
        this.coyoteLeft = 0;
        this.bufferLeft = 0;
        this.stats.jumps++;
      }
      /* variable height: release while still rising and the rest of the arc is cut */
      if (!inp.jumpHeld && this.vy < 0) this.vy *= (1 - c.jumpCut * Math.min(1, dt * 60));

      /* ---- gravity -------------------------------------------------------------------------- */
      this.vy += c.gravity * dt;
      if (this.vy > c.fallMax) this.vy = c.fallMax;
    }

    /* ---- integrate, SUBSTEPPED so nothing tunnels ------------------------------------------- */
    const dist = Math.max(Math.abs(this.vx * dt), Math.abs(this.vy * dt));
    const n = Math.max(1, Math.ceil(dist / c.maxStepPx));
    const sdt = dt / n;
    let landed = false;
    for (let i = 0; i < n; i++) {
      this.stats.substeps++;
      /* X then Y, resolved separately — the standard and the only one that lets a body slide along
       * a wall instead of sticking to it. */
      const nx = this.x + this.vx * sdt;
      if (overlapsSolid(this, room, nx, this.y)) {
        this.vx = 0; this.stats.hitsX++;
        if (this.dashLeft > 0) this.dashLeft = 0;   /* a dash into a wall ENDS; it does not grind */
      } else this.x = nx;

      const ny = this.y + this.vy * sdt;
      if (overlapsSolid(this, room, this.x, ny)) {
        if (this.vy > 0) landed = true;
        this.vy = 0; this.stats.hitsY++;
      } else this.y = ny;
    }

    /* ---- ground state, derived from the world and never remembered ---------------------------- */
    const wasOn = this.onGround;
    this.onGround = landed || overlapsSolid(this, room, this.x, this.y + 0.5);
    if (this.onGround) {
      this.coyoteLeft = c.coyote;
      /* ⛔⛔ THE LANDING REFRESH, AND ITS TWO GUARDS — BOTH PAID FOR BY A RED IN `_plat_selftest`
       * ARM 7c, WHICH MEASURED **TWO** DASHES INSIDE ONE COOLDOWN.
       * Landing refreshes the dash (the reward for touching down), and the naive spelling
       * `if (!wasOn) this.dashCd = 0` has a hole big enough to delete the cooldown entirely:
       *   (a) A GROUND DASH REFRESHES ITSELF. A `Body` is constructed with `onGround = false`, so
       *       its FIRST step on solid floor reads as a landing — on the very frame the dash set the
       *       cooldown, wiping it. Holding the dash key then chained dashes forever.
       *   (b) More generally, ANY dash begun on the frame of a touchdown would clear its own
       *       cooldown, which is wing §6b-2 rule 4 exactly: *a fail state whose remedy is free and
       *       infinitely repeatable is not a fail state.* A dash cooldown that can be refreshed by
       *       the dash itself is not a cooldown, and every later claim about traversal distance
       *       would have been measured against a player who can dash every frame.
       * ⇒ refresh only on a REAL touchdown that is not this frame's dash, and never while a dash is
       * still running. An AIR dash followed by a landing still refreshes, which is the intent. */
      if (!wasOn && !startedDash && this.dashLeft <= 0) this.dashCd = 0;
    }
    return this;
  };

  const API = {
    Body: Body, Room: Room, DEFAULTS: DEF, aabb: aabb, overlapsSolid: overlapsSolid,
    OPEN: OPEN, ROCK: ROCK, GRATE: GRATE,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  root.PL_PLAT = API;
})(typeof globalThis !== 'undefined' ? globalThis : this);
