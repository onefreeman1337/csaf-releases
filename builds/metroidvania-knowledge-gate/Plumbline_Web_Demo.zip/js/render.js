/* ================================================================================================
 * render.js — draw the shaft. The picture whose whole subject is DEPTH.
 * ================================================================================================
 * ⛔⛔ THE DEFECT THIS FILE EXISTS TO FIX, NAMED BEFORE IT WAS WRITTEN. The offline bake
 * (`Internal_Ops/_look_shaft.js`) was opened and LOOKED AT on 2026-09-04, and the honest reading was:
 * the masonry edges and the de Bruijn roofline are correct and legible, and **the gallery air and the
 * deep chamber below the bars are drawn with the SAME dimmed background**, so a game about how deep
 * you are is a flat picture from top to bottom. Nothing in the frame is lit, although the pack ships
 * `anim_wall_torch` and `anim_brazier`. ⇒ two things here are not decoration:
 *
 *   1. A DEPTH GRADE. Everything dims with world depth, on a curve, so falling is visible as going
 *      dark and the bottom of a chamber is a different PLACE from the top of it.
 *   2. LIGHT. Braziers along the gallery, each throwing a warm pool. They are the only thing in the
 *      picture that says "somebody was here before you", which is the whole premise.
 *
 * ⛔⛔ THE LIGHTS MAY NEVER KNOW WHERE THE ANSWER IS. DESIGN §4c and `_probe_sight.js` between them
 * are unambiguous: marking the answer's bay converts a knowledge gate into a visible one, priced at
 * **22.0x** to a searcher — it would destroy the gate outright. So `brazierAt()` below is a function
 * of the COLUMN ALONE, with a fixed period, and it reads nothing from the gate, the plate, the seal
 * or the answer. `_render_selftest.js` asserts that as a CLASS over this file's source, not as an
 * example, because a rule that lives only in a comment is not a rule.
 *
 * ⛔ IT IS DECORATION, NOT GEOMETRY. Braziers are drawn; they are never written into `room.cells`.
 * The shipped region therefore stays cell-for-cell the gated fixture (`_world_selftest` arm A), and
 * a presentation change is proven to change nothing physical — gates.js records paying for exactly
 * that rule when a roofline change silently opened THE FALL.
 *
 * ⛔ NO `fetch`. The atlas arrives as `PL_ATLAS` from a generated `<script>` and sheets load as
 * `<img>`, both of which work under `file://` — master §2b, LANTERNBOUND's textureless paid build.
 * ---------------------------------------------------------------------------------------------- */
'use strict';

(function (root) {
  const PLAT = root.PL_PLAT;
  const ATLAS = root.PL_ATLAS;

  const CELL = ATLAS.cell;
  const PACK = 'verdant-05-depths';
  const IRON = 'plumbline-ironwork';

  /* ---- sheet loading ---------------------------------------------------------------------------
   * ⚠️ Every path comes from the atlas's own `file` field rather than being guessed — re-derive,
   * never restate — so a moved asset root fails loudly instead of drawing nothing. */
  const sheets = {};
  let pending = 0, failed = [];
  function loadAll(base, done) {
    const jobs = [];
    for (const [packId, pk] of Object.entries(ATLAS.packs)) {
      for (const [name, s] of Object.entries(pk.sheets)) jobs.push([packId + '/' + name, base + s.file]);
    }
    jobs.push(['sprite/surveyor', base + 'sprites/surveyor_idle_east.png']);
    pending = jobs.length;
    if (!pending) { done(['atlas declares no sheets at all']); return; }
    for (const [key, url] of jobs) {
      const img = new Image();
      img.onload = function () { sheets[key] = img; if (--pending === 0) done(failed); };
      /* ⛔ A FAILED SHEET IS NAMED AND COUNTED, never swallowed. A renderer that quietly draws
       * nothing for a missing asset is how a missing asset ships (master §2b, and _look_shaft's own
       * magenta placeholder exists for the same reason). */
      img.onerror = function () { failed.push(url); if (--pending === 0) done(failed); };
      img.src = url;
    }
  }

  function tileRec(qualified) {
    const i = qualified.indexOf('/');
    const packId = qualified.slice(0, i), id = qualified.slice(i + 1);
    const pk = ATLAS.packs[packId];
    if (!pk) return null;
    const t = pk.tiles[id];
    return t ? { t: t, packId: packId } : null;
  }

  /* ---- blob47, read out of the pack and never typed here (§6d-10) -------------------------------
   * ⛔ ONE AUTOTILE PER REGION, chosen by the region's declared `material`. It was a single
   * module-level `mason_on_flag` for every room, which is what made all four rooms the same picture
   * (dedupe: 7 shots -> 2 distinct). ⚠️ A missing or unknown material THROWS rather than falling
   * back to mason: a silent fallback is exactly how four rooms became one, and §0z is explicit that
   * a silent refusal cannot be told apart from a failure. */
  const AUTOTILES = {};
  for (const a of (ATLAS.packs[PACK].autotiles || [])) AUTOTILES[a.name] = a;
  function autoFor(region) {
    const name = region && region.def ? region.def.material : null;
    if (!name) throw new Error('render: region "' + (region && region.def ? region.def.id : '?')
      + '" declares no `material` — every region must name its own autotile, or all four rooms draw identically');
    const a = AUTOTILES[name];
    if (!a) throw new Error('render: the pack has no autotile "' + name + '" (it has: '
      + Object.keys(AUTOTILES).join(', ') + ')');
    return a;
  }
  const BIT = { n: 1, ne: 2, e: 4, se: 8, s: 16, sw: 32, w: 64, nw: 128 };
  function isRock(room, c, r) {
    if (c < 0 || r < 0 || c >= room.cols || r >= room.rows) return true;   /* outside is solid */
    return room.at(c, r) === PLAT.ROCK;
  }
  function blobMask(room, c, r) {
    const n = isRock(room, c, r - 1), e = isRock(room, c + 1, r), s = isRock(room, c, r + 1), w = isRock(room, c - 1, r);
    let m = 0;
    if (n) m |= BIT.n; if (e) m |= BIT.e; if (s) m |= BIT.s; if (w) m |= BIT.w;
    /* a corner bit counts only when BOTH its adjacent edges are solid — 47 cases, not 256 */
    if (n && e && isRock(room, c + 1, r - 1)) m |= BIT.ne;
    if (s && e && isRock(room, c + 1, r + 1)) m |= BIT.se;
    if (s && w && isRock(room, c - 1, r + 1)) m |= BIT.sw;
    if (n && w && isRock(room, c - 1, r - 1)) m |= BIT.nw;
    return m;
  }
  /* deterministic variant pick — ⛔ NO Math.random anywhere in this project */
  function pick(list, c, r) {
    const h = ((c * 73856093) ^ (r * 19349663)) >>> 0;
    return list[h % list.length];
  }
  /* the background wall: `flag` in the built rooms, `flag_cracked` deeper down. Derived from the
   * pack's own ids so a re-generated pack cannot leave this naming tiles that no longer exist. */
  function bgSetFor(region) {
    const want = (region && region.def && region.def.bg) ? region.def.bg : 'flag';
    const re = new RegExp('^' + want + '_[0-9]+$');
    const out = Object.keys(ATLAS.packs[PACK].tiles).filter((k) => re.test(k)).map((k) => PACK + '/' + k);
    if (!out.length) throw new Error('render: the pack has no background tiles matching ' + want + '_N');
    return out;
  }
  /* ⛔⛔ FILTERED BY ROLE, AND IT WAS NOT. This read every tile in the ironwork pack, which was
   * correct for exactly as long as that pack held nothing but bars. The moment the brazier was
   * generated into it (2026-09-04) the GRATE floor started drawing braziers as floor tiles — a
   * shared list widened for one consumer, silently changing another. Wing §6d-10 is this shape in a
   * font; master §2b's tilesets row is it in an asset pack. The pack declares a `role` per tile and
   * `stage_art.js` carries it through the atlas, so the reader asks for what it means. */
  const barsOf = (pk) => Object.keys(pk.tiles).filter((k) => pk.tiles[k].role === 'terrain-fill');
  const BARS = ATLAS.packs[IRON] ? barsOf(ATLAS.packs[IRON]).map((k) => IRON + '/' + k) : [];
  if (ATLAS.packs[IRON] && !BARS.length) throw new Error('render: the ironwork pack declares no terrain-fill tile — the barred floor would draw nothing');

  /* ================================================================================================
   * THE BRAZIERS — the only light, and answer-blind by construction.
   * ================================================================================================
   * ⛔ A FUNCTION OF THE COLUMN ALONE. Period 9 with offset 4, chosen only so it is coprime with the
   * roofline's own period and therefore cannot beat against it to make some bays distinguishable.
   * It reads nothing about any gate. Do not "improve" this by lighting the interesting parts.
   */
  const BRAZIER_PERIOD = 9, BRAZIER_OFFSET = 4;
  function brazierAt(col) { return ((col % BRAZIER_PERIOD) + BRAZIER_PERIOD) % BRAZIER_PERIOD === BRAZIER_OFFSET; }

  /* Where a region's braziers actually stand: on the gallery floor, in a bay with headroom. Derived
   * from the room so it cannot name a hand-typed column. */
  function braziers(room, floorRow) {
    const out = [];
    for (let c = 1; c < room.cols - 1; c++) {
      if (!brazierAt(c)) continue;
      const f = room.at(c, floorRow);
      if (f !== PLAT.ROCK && f !== PLAT.GRATE) continue;
      if (room.at(c, floorRow - 1) !== PLAT.OPEN) continue;
      out.push({ col: c, row: floorRow - 1, x: (c + 0.5) * CELL, y: floorRow * CELL });
    }
    return out;
  }

  /* ================================================================================================
   * THE DEPTH GRADE — the fix for the flat picture.
   * ================================================================================================
   * `0` at the top of the room, `1` at the bottom. Squared, so the change is slow near the surface
   * and fast in the deep, which is what descending a shaft looks like. ⚠️ It is a MULTIPLIER on the
   * drawn image and touches nothing the model reads — sight was measured worth 0.97-1.03x here
   * (`_probe_sight.js`), so this cannot make the game easier or harder, only legible.
   */
  /* ⛔ PER REGION, NOT ONE CONSTANT. Each room declares how much light survives at its floor, so the
   * four rooms get darker as the shaft goes down (0.34 -> 0.28 -> 0.24 -> 0.18). That is half of
   * what makes them distinguishable at a glance; the material is the other half. */
  const FLOOR_LIGHT_DEFAULT = 0.30;
  function gradeAt(worldY, room, floorLight) {
    const t = Math.max(0, Math.min(1, worldY / (room.rows * CELL)));
    const fl = (typeof floorLight === 'number') ? floorLight : FLOOR_LIGHT_DEFAULT;
    return 1 - (1 - fl) * t * t;
  }

  /* ================================================================================================
   * bakeRoom — the whole region drawn once to an offscreen canvas.
   * ================================================================================================
   * Rooms top out at 145x26 tiles (2320x416 px), so one bake is cheap and a per-frame blit is free.
   * ⛔ Re-baked whenever the geometry CHANGES — carving an exit must be visible, and a cached
   * picture of a room that has moved is a stale proof of the oldest kind.
   */
  /* ⛔⛔ NOT ONE PIXEL IS READ BACK, AND THAT IS A `file://` REQUIREMENT RATHER THAN AN OPTIMISATION.
   * The first version of this function dimmed the background with `getImageData`/`putImageData`.
   * An `<img>` loaded from `file://` TAINTS a canvas, so `getImageData` throws a SecurityError there
   * — i.e. the http-served web demo would have been perfect and the Electron desktop build, which is
   * the PAID product (DESIGN §5), would have died on its first frame. That is master §2b's
   * LANTERNBOUND row exactly: *the same defect wearing the same disguise one layer down.* Every
   * effect below is therefore a COMPOSITE (`multiply`, `lighter`) over a second canvas, which needs
   * no read-back and is faster anyway. Do not reintroduce a pixel read here. */
  function bakeRoom(room, floorRow, region) {
    const auto = autoFor(region);
    const FLAGS = bgSetFor(region);
    const floorLight = region && region.def ? region.def.floorLight : undefined;
    const cv = document.createElement('canvas');
    cv.width = room.cols * CELL; cv.height = room.rows * CELL;
    const g = cv.getContext('2d');
    g.imageSmoothingEnabled = false;
    g.fillStyle = '#08090d';
    g.fillRect(0, 0, cv.width, cv.height);

    /* LAYER 1 — the background wall, drawn everywhere and then knocked back as a whole, so a solid
     * tile's transparent pixels never punch through to the void and the mass reads in FRONT of it. */
    const bg = document.createElement('canvas');
    bg.width = cv.width; bg.height = cv.height;
    const bgc = bg.getContext('2d');
    bgc.imageSmoothingEnabled = false;
    for (let r = 0; r < room.rows; r++) {
      for (let c = 0; c < room.cols; c++) drawTile(bgc, pick(FLAGS, c, r), c * CELL, r * CELL);
    }
    bgc.globalCompositeOperation = 'multiply';
    bgc.fillStyle = 'rgb(107,107,117)';        /* ~0.42 red/green, ~0.46 blue: depth reads cooler */
    bgc.fillRect(0, 0, bg.width, bg.height);
    bgc.globalCompositeOperation = 'source-over';
    g.drawImage(bg, 0, 0);

    /* LAYER 2 — the solid mass and the bars, at full strength on top */
    for (let r = 0; r < room.rows; r++) {
      for (let c = 0; c < room.cols; c++) {
        const dx = c * CELL, dy = r * CELL;
        const mat = room.at(c, r);
        if (mat === PLAT.ROCK) {
          const id = auto.masks[String(blobMask(room, c, r))];
          if (id) drawTile(g, PACK + '/' + id, dx, dy);
        } else if (mat === PLAT.GRATE && BARS.length) {
          drawTile(g, pick(BARS, c, r), dx, dy);
        }
      }
    }

    /* THE DEPTH GRADE, multiplied over everything */
    const grad = g.createLinearGradient(0, 0, 0, cv.height);
    for (let i = 0; i <= 8; i++) {
      const t = i / 8;
      const v = gradeAt(t * cv.height, room, floorLight);
      grad.addColorStop(t, 'rgba(' + Math.round(v * 255) + ',' + Math.round(v * 255) + ',' + Math.round(v * 258 > 255 ? 255 : v * 258) + ',1)');
    }
    g.globalCompositeOperation = 'multiply';
    g.fillStyle = grad;
    g.fillRect(0, 0, cv.width, cv.height);
    g.globalCompositeOperation = 'source-over';

    /* THE LIGHT POOLS, added back on top of the grade so a lit bay is genuinely brighter */
    g.globalCompositeOperation = 'lighter';
    for (const b of braziers(room, floorRow)) {
      const rad = CELL * 5.5;
      const rg = g.createRadialGradient(b.x, b.y - CELL * 0.6, 2, b.x, b.y - CELL * 0.6, rad);
      rg.addColorStop(0, 'rgba(255,190,110,0.42)');
      rg.addColorStop(0.45, 'rgba(217,95,16,0.16)');
      rg.addColorStop(1, 'rgba(140,42,6,0)');
      g.fillStyle = rg;
      g.fillRect(b.x - rad, b.y - CELL * 0.6 - rad, rad * 2, rad * 2);
    }
    g.globalCompositeOperation = 'source-over';
    return cv;
  }

  function drawTile(g, qualified, dx, dy) {
    const rec = tileRec(qualified);
    if (!rec) return false;
    const img = sheets[rec.packId + '/' + rec.t.sheet];
    if (!img) return false;
    g.drawImage(img, rec.t.x, rec.t.y, CELL, CELL, dx, dy, CELL, CELL);
    return true;
  }

  /* ================================================================================================
   * Renderer
   * ================================================================================================ */
  function Renderer(canvas, viewW, viewH) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.ctx.imageSmoothingEnabled = false;
    this.viewW = viewW; this.viewH = viewH;
    this.baked = null; this.bakedFor = null; this.bakedStamp = -1;
    this.camX = 0; this.camY = 0;
    this.t = 0;
    /* counts of WORK, never verdicts */
    this.stats = { frames: 0, bakes: 0, missingTiles: 0 };
  }

  /* ================================================================================================
   * titleBackdrop — the shaft, behind the title card.
   * ================================================================================================
   * ⛔ THE TITLE SCREEN WAS A PLUMB LINE ON PURE BLACK, and it is one of seven store images. Judged
   * against Gate 1's own references (Meridian's skill tree, Sigil Core's grimoire) it was ~70% empty
   * and — worse for a store page — it showed a buyer NOTHING about how the game looks. A player's
   * first impression of a pixel-art game should contain some pixel art.
   * ⭐ It is drawn from the SAME tile atlas the game draws, so the title is a picture of the product
   * rather than a picture made for the title: masonry walls either side, the flagged dark between
   * them, and the depth grade this game's whole subject is. */
  Renderer.prototype.titleBackdrop = function (g, w, h) {
    const pk = ATLAS.packs[PACK];
    const mason = Object.keys(pk.tiles).filter((k) => /^mason_?[0-9]*$/.test(k)).map((k) => PACK + '/' + k);
    const flags = Object.keys(pk.tiles).filter((k) => /^flag_[0-9]+$/.test(k)).map((k) => PACK + '/' + k);
    if (!mason.length || !flags.length) return false;

    g.fillStyle = '#08090d';
    g.fillRect(0, 0, w, h);
    const cols = Math.ceil(w / CELL), rows = Math.ceil(h / CELL);
    /* the shaft: a wall of about three tiles each side, the rest open air */
    const WALL = 3;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const isWall = (c < WALL) || (c >= cols - WALL);
        drawTile(g, pick(isWall ? mason : flags, c, r), c * CELL, r * CELL);
      }
    }
    /* knock the whole thing back so it is a BACKDROP and the title reads over it, then run the same
     * depth grade down it — the one effect this game is about */
    g.globalCompositeOperation = 'multiply';
    const grad = g.createLinearGradient(0, 0, 0, h);
    grad.addColorStop(0, 'rgba(96,92,96,1)');
    grad.addColorStop(0.55, 'rgba(52,50,58,1)');
    grad.addColorStop(1, 'rgba(20,20,28,1)');
    g.fillStyle = grad;
    g.fillRect(0, 0, w, h);
    g.globalCompositeOperation = 'source-over';
    return true;
  };

  Renderer.prototype.bake = function (region) {
    /* ⛔ the stamp is the region's OPENED state, so carving an exit re-bakes. A cached picture of a
     * room that has changed is the stale-proof defect with a canvas in front of it. */
    const stamp = (region.opened ? 1 : 0);
    if (this.baked && this.bakedFor === region && this.bakedStamp === stamp) return this.baked;
    this.baked = bakeRoom(region.room, region.def.gate === undefined ? 9 : galleryFloor(region), region);
    this.bakedFor = region; this.bakedStamp = stamp;
    this.stats.bakes++;
    return this.baked;
  };

  /* Which row is this region's walkable gallery? DERIVED — the row with the most GRATE in it, because
   * the barred gallery floor is the one surface every region shares. ⚠️ Never typed per region: a
   * hand-listed row goes stale the first time a fixture moves (gates.js's own candidates rule). */
  function galleryFloor(region) {
    const room = region.room;
    let best = 9, bestN = -1;
    for (let r = 0; r < room.rows; r++) {
      let n = 0;
      for (let c = 0; c < room.cols; c++) if (room.at(c, r) === PLAT.GRATE) n++;
      if (n > bestN) { bestN = n; best = r; }
    }
    return best;
  }

  Renderer.prototype.frame = function (region, dt) {
    const g = this.ctx;
    this.t += dt;
    this.stats.frames++;
    const baked = this.bake(region);
    const b = region.shaft.body;

    /* camera: centred, clamped to the room, and a touch ahead of the fall so a drop shows where it
     * is going rather than where it has been */
    const targetX = b.x - this.viewW / 2;
    const targetY = b.y - this.viewH * 0.55 + Math.min(60, Math.max(-20, b.vy * 0.12));
    this.camX = clamp(targetX, 0, Math.max(0, baked.width - this.viewW));
    this.camY = clamp(targetY, 0, Math.max(0, baked.height - this.viewH));
    const cx = Math.round(this.camX), cy = Math.round(this.camY);

    g.fillStyle = '#05060a';
    g.fillRect(0, 0, this.viewW, this.viewH);
    g.drawImage(baked, cx, cy, this.viewW, this.viewH, 0, 0, this.viewW, this.viewH);

    /* ---- brazier flames, animated on top of the baked pools ------------------------------------
     * ⛔⛔ THE BRAZIER COMES FROM `IRON`, NOT FROM `PACK`, AND THAT IS THE FIX FOR A SHIPPED DEFECT.
     * MEASURED 2026-09-04 by screenshotting the running build and zooming 8x: verdant-05-depths's
     * `anim_brazier` frames are OPAQUE and carry that pack's own cold blue-grey stone as their
     * background, so every brazier drew a cold rectangle onto this game's warm depth-graded masonry
     * with the 16x16 tile boundary plainly visible — §0-ART-b rule 1's sticker, three per screen.
     * `gen_ironwork.js` now generates the brazier in-project with real alpha, in the palette derived
     * from that same pack, and its self-test carries a CONTROL that fails on an opaque-backed frame.
     * ⭐ It is also the one `role: 'prop'` tile that was sneaking past `stage_art.js`'s top-down
     * exclusion, because it arrived through the animation table rather than the tile list.
     * ⭐ AND IT IS DRAWN AFTER THE LIGHT PASS ON PURPOSE (§0z's drawing-order rule): a flame is
     * EMISSIVE, so multiplying it by the depth grade would assert that the room lights the fire. */
    const floorRow = galleryFloor(region);
    /* ⛔⛔ A MISSING ANIMATION USED TO DRAW NOTHING, SILENTLY, AND IT HAPPENED. MEASURED 2026-09-04:
     * `stage_art.js` rewrote `assets/tiles/atlas.json` with the new brazier while the page reads
     * `js/atlas_data.js`, which is DERIVED from it by `build_web.js` — and that had not been re-run.
     * So the lookup returned undefined, `if (anim)` quietly skipped the whole block, and the game
     * rendered three light pools with NO LAMP IN ANY OF THEM. Every gate stayed green; only a
     * screenshot showed it. §6d-17's two-ancestors defect, and §0z's dead reader: a silent skip is
     * correct behaviour that cannot be told apart from a failure. It is now COUNTED and NAMED. */
    const anim = (ATLAS.packs[IRON].animations || []).find((a) => a.name === 'anim_brazier');
    if (!anim) {
      this.stats.missingTiles++;
      if (!this._warnedBrazier) {
        this._warnedBrazier = true;
        throw new Error('render: the ironwork pack declares no `anim_brazier` — the shaft would draw '
          + 'lit pools with no lamp in them. Run stage_art.js then build_web.js (js/atlas_data.js is '
          + 'DERIVED from assets/tiles/atlas.json and goes stale on its own).');
      }
    } else {
      const seq = anim.sequence || [0, 1, 2, 1];
      for (const br of braziers(region.room, floorRow)) {
        const sx = br.x - cx, sy = br.y - cy;
        if (sx < -CELL * 2 || sx > this.viewW + CELL * 2) continue;
        /* per-brazier phase from the column, so they do not all flicker in lockstep. Deterministic. */
        const k = seq[(Math.floor(this.t * 7.5) + br.col) % seq.length];
        if (!drawTile(g, IRON + '/' + anim.frames[k], Math.round(sx - CELL / 2), Math.round(sy - CELL))) {
          this.stats.missingTiles++;   /* a named frame the atlas does not hold — counted, not shrugged */
        }
      }
    }

    /* ---- the cord and the weight -------------------------------------------------------------
     * ⭐ DRAWN FROM THE MODEL'S OWN NUMBERS — hand and bob come straight off the shaft, so the
     * picture cannot disagree with the physics about where the weight is. */
    const L = region.shaft.line;
    if (L.out > 0) {
      const h = region.shaft.hand();
      g.strokeStyle = L.taut ? 'rgba(224,210,182,0.95)' : 'rgba(168,156,136,0.75)';
      g.lineWidth = 1;
      g.beginPath();
      g.moveTo(Math.round(h.x - cx) + 0.5, Math.round(h.y - cy) + 0.5);
      g.lineTo(Math.round(L.bx - cx) + 0.5, Math.round(L.by - cy) + 0.5);
      g.stroke();
      /* the knots — one per mark, so the cord SHOWS the unit the depth is reported in */
      const marks = Math.floor(L.out / CELL);
      const dxu = (L.bx - h.x), dyu = (L.by - h.y), len = Math.hypot(dxu, dyu) || 1;
      for (let m = 1; m <= marks; m++) {
        const f = (m * CELL) / L.out;
        if (f > 1) break;
        const kx = h.x + dxu * f * (len / len), ky = h.y + dyu * f;
        g.fillStyle = 'rgba(240,217,122,0.85)';
        g.fillRect(Math.round(kx - cx), Math.round(ky - cy), 1, 1);
      }
      /* the bob */
      const bs = L.cfg.bob;
      g.fillStyle = L.resting ? '#f0d97a' : '#c9a038';
      g.fillRect(Math.round(L.bx - bs / 2 - cx), Math.round(L.by - bs / 2 - cy), bs, bs);
      g.fillStyle = 'rgba(20,16,10,0.9)';
      g.fillRect(Math.round(L.bx - bs / 2 - cx), Math.round(L.by + bs / 2 - 1 - cy), bs, 1);
    }

    /* ---- the surveyor ------------------------------------------------------------------------- */
    const spr = sheets['sprite/surveyor'];
    const px = Math.round(b.x - cx), py = Math.round(b.y - cy);
    if (spr) {
      const sw = spr.width, sh = spr.height;
      g.save();
      g.translate(px, py);
      if (b.facing < 0) g.scale(-1, 1);
      g.drawImage(spr, -Math.round(sw / 2), -sh, sw, sh);
      g.restore();
    } else {
      this.stats.missingTiles++;
      g.fillStyle = '#ff00ff';                       /* loud, never plausible */
      g.fillRect(px - b.cfg.w / 2, py - b.cfg.h, b.cfg.w, b.cfg.h);
    }
    return this;
  };

  function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

  const API = {
    Renderer: Renderer, loadAll: loadAll, CELL: CELL, brazierAt: brazierAt, braziers: braziers,
    gradeAt: gradeAt, blobMask: blobMask, galleryFloor: galleryFloor,
    BRAZIER_PERIOD: BRAZIER_PERIOD, BRAZIER_OFFSET: BRAZIER_OFFSET, FLOOR_LIGHT: FLOOR_LIGHT_DEFAULT,
    sheetsLoaded: function () { return Object.keys(sheets).length; },
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  root.PL_RENDER = API;
})(typeof globalThis !== 'undefined' ? globalThis : this);
