/* ================================================================================================
 * game.js — the shell. Input, the loop, the four screens, and the HUD.
 * ================================================================================================
 * ⭐ THE CALLER OWNS THE CLOCK, AND THIS FILE IS THE CALLER. `plat.js`, `line.js` and `gates.js` all
 * advance by exactly the dt they are handed and read real time never — master §6b-2's closing rule,
 * paid for on LANTERNBOUND where a flame burned at twice its tuned rate because the model and the
 * browser were both advancing it. So the fixed-step accumulator below is the ONLY place real time
 * enters the simulation, and it steps at exactly the `DT` the whole proof was measured at.
 *
 * ⛔ THE SIMULATION STEP IS FIXED AT 1/60 AND IS NOT THE FRAME RATE. Every number in
 * `_gates_selftest.js` — the 20x dominance bar included — is denominated in 1/60 s steps. A
 * variable-dt game loop would silently make this a different game from the one that was proven, on
 * every machine, differently. A slow frame runs more steps; it never runs a bigger one.
 *
 * ⛔ AND THE ACCUMULATOR IS CLAMPED. A backgrounded tab returns with a multi-second delta, and an
 * unclamped catch-up would run thousands of steps in one frame — the tab-away case §1.1b's `breakit`
 * category names explicitly.
 * ---------------------------------------------------------------------------------------------- */
'use strict';

(function (root) {
  const WORLD = root.PL_WORLD;
  const RENDER = root.PL_RENDER;
  const AUDIO = root.PL_AUDIO;

  const DT = 1 / 60;
  const MAX_CATCHUP = 5;            /* steps per frame, i.e. never more than ~83 ms of catch-up */
  const VIEW_W = 480, VIEW_H = 270; /* 16:9 at a scale itch's embed and a phone both handle */

  /* ---- input ------------------------------------------------------------------------------------
   * ⚠️ `jump` is an EDGE and `jumpHeld` is a LEVEL — plat.js is explicit that conflating them is how
   * variable jump height silently stops working. The edge is consumed by the STEP, not by the frame,
   * so a press inside a frame that runs two steps is not delivered twice. */
  const KEYS = {
    left: ['ArrowLeft', 'KeyA'], right: ['ArrowRight', 'KeyD'],
    jump: ['KeyZ', 'Space', 'KeyK'], dash: ['KeyX', 'ShiftLeft', 'ShiftRight', 'KeyL'],
    payOut: ['ArrowDown', 'KeyS'], reelIn: ['ArrowUp', 'KeyW'],
    read: ['KeyC', 'Enter'], restart: ['KeyR'],
    /* wing §1b: ship a mute toggle and honour it. It is one key because a player who wants silence
     * wants it NOW, not after finding a menu — and this game has no menu by design. */
    mute: ['KeyM'],
  };
  function Input() {
    this.down = {};
    this.pressed = {};          /* edges, cleared when a step consumes them */
    const self = this;
    const map = {};
    for (const [act, codes] of Object.entries(KEYS)) for (const c of codes) map[c] = act;
    this.onKey = function (e, isDown) {
      const act = map[e.code];
      if (!act) return;
      /* ⛔ Space and the arrows scroll the page inside an itch iframe — that is the single most
       * common way an embedded browser game feels broken. */
      e.preventDefault();
      if (isDown && !self.down[act]) self.pressed[act] = true;
      self.down[act] = isDown;
    };
    window.addEventListener('keydown', function (e) { self.onKey(e, true); }, { passive: false });
    window.addEventListener('keyup', function (e) { self.onKey(e, false); }, { passive: false });
    /* a lost focus must not leave a key stuck down — the tab-away case */
    window.addEventListener('blur', function () { self.down = {}; self.pressed = {}; });
  }
  Input.prototype.take = function () {
    const o = {
      left: !!this.down.left, right: !!this.down.right,
      jump: !!this.pressed.jump, jumpHeld: !!this.down.jump,
      dash: !!this.pressed.dash || !!this.down.dash,
      payOut: !!this.down.payOut, reelIn: !!this.down.reelIn,
    };
    this.pressed.jump = false; this.pressed.dash = false;
    return o;
  };

  /* ================================================================================================
   * Game
   * ================================================================================================ */
  const SCREEN = { LOADING: 'loading', TITLE: 'title', PLAYING: 'playing', ENDING: 'ending', ERROR: 'error' };

  function Game(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.ctx.imageSmoothingEnabled = false;
    this.input = new Input();
    this.renderer = new RENDER.Renderer(canvas, VIEW_W, VIEW_H);
    this.screen = SCREEN.LOADING;
    this.run = null;
    this.acc = 0; this.last = 0;
    this.banner = null;            /* {lines, t} — the region title on arrival */
    this.reading = null;           /* {text, t} — the last depth the instrument gave */
    this.errorText = '';
    this.muted = false;
    this.lastRegionIndex = -1;
    /* counts of WORK, never verdicts (master §2b rule 2) */
    this.stats = { frames: 0, steps: 0, reads: 0, refusals: 0, longestFrameMs: 0 };
  }

  Game.prototype.start = function (assetBase) {
    const self = this;
    RENDER.loadAll(assetBase, function (failed) {
      if (failed && failed.length) {
        /* ⛔ NAMED, NEVER A BLANK CANVAS. A game that fails to load its art and shows black is
         * indistinguishable from a game that crashed, and both are indistinguishable from a game
         * that is merely slow (§0z: a silent refusal is correct behaviour that cannot be told apart
         * from a failure). */
        self.screen = SCREEN.ERROR;
        self.errorText = failed.length + ' asset(s) failed to load:\n' + failed.slice(0, 6).join('\n');
        return;
      }
      self.screen = SCREEN.TITLE;
    });
    this.last = now();
    const loop = function () { self.tick(); root.requestAnimationFrame(loop); };
    root.requestAnimationFrame(loop);
    return this;
  };

  function now() { return (root.performance && root.performance.now) ? root.performance.now() : Date.now(); }

  Game.prototype.beginRun = function () {
    this.run = new WORLD.Run();
    this.screen = SCREEN.PLAYING;
    this.lastRegionIndex = -1;
    this.reading = null;
    /* ⛔ THE SHAFT HAS NO SCORE, AND THAT IS THE DESIGN. audio.js's room tone drops in pitch and
     * closes down as you descend — "the depth is the melody". A written loop under it would be two
     * pieces of music at once, and it would bury the one channel that is telling the player
     * something. The written tracks play where there is no shaft: the title and the ending. */
    if (AUDIO) { AUDIO.stopMusic(); AUDIO.start(); }
    return this;
  };

  Game.prototype.tick = function () {
    const t = now();
    let elapsed = (t - this.last) / 1000;
    this.stats.longestFrameMs = Math.max(this.stats.longestFrameMs, (t - this.last));
    this.last = t;
    if (!isFinite(elapsed) || elapsed < 0) elapsed = 0;
    this.stats.frames++;

    /* ⭐ ANY key is the gesture the autoplay policy was waiting for. Handled before the screens so a
     * refused track starts on the FIRST thing the player touches, whatever it was. */
    if (AUDIO) {
      if (this.input.pressed.mute) {
        this.input.pressed.mute = false;
        this.muted = AUDIO.setMuted(!AUDIO.isMuted());
      }
      if (Object.keys(this.input.down).some((k) => this.input.down[k])) AUDIO.resumePending();
    }

    if (this.screen === SCREEN.TITLE) {
      /* the written theme belongs here and at the ending; the shaft has its own procedural voice */
      if (AUDIO) AUDIO.music('mus_descent', true);
      if (this.input.pressed.jump || this.input.down.jump) { this.input.pressed.jump = false; this.beginRun(); }
      this.drawTitle();
      return;
    }
    if (this.screen === SCREEN.LOADING) { this.drawCentred(['LOADING']); return; }
    if (this.screen === SCREEN.ERROR) { this.drawCentred(this.errorText.split('\n'), '#d95f10'); return; }
    if (this.screen === SCREEN.ENDING) {
      if (AUDIO) AUDIO.music('mus_datum', false);
      if (this.input.pressed.restart) { this.input.pressed.restart = false; this.screen = SCREEN.TITLE; }
      this.drawEnding();
      return;
    }

    /* ---- PLAYING: fixed-step simulation ------------------------------------------------------- */
    this.acc += elapsed;
    let steps = 0;
    while (this.acc >= DT && steps < MAX_CATCHUP) {
      const inp = this.input.take();
      this.acc -= DT; steps++;
      if (!this.advance(inp)) break;
    }
    /* ⛔ a starved accumulator must be DROPPED, never carried: carrying it makes the next frame run
     * the same catch-up again and the game runs permanently in slow motion after one hitch */
    if (this.acc > DT * MAX_CATCHUP) this.acc = 0;

    if (this.screen !== SCREEN.PLAYING) return;

    /* the read is an EDGE, taken outside the step so holding it does not spam the instrument */
    if (this.input.pressed.read) { this.input.pressed.read = false; this.doRead(); }

    this.postStep(elapsed);
    this.drawFrame(elapsed);
  };

  /* ================================================================================================
   * advance / doRead / postStep / drawFrame — ONE implementation each, called by the rAF loop above
   * AND by the harness hook below.
   * ================================================================================================
   * ⛔⛔ THE HOOK MUST NOT BE A SECOND STEP LOOP. Wing §6d-10: a harness written beside a proven one
   * is a second opinion about the thing under test, and this project has already paid for it once
   * (`_world_selftest.js`'s hand-rolled walker failed a gate that the proven phase primitives open).
   * If `stepN` re-implemented what `tick` does, the harness would certify a game nobody ships. So the
   * loop body was EXTRACTED rather than copied, and both callers run the identical code.
   */

  /* One fixed-step advance. Returns false when the run has just ended. */
  Game.prototype.advance = function (inp) {
    const before = this.run.regionIndex;
    /* ⭐ THE BLOW IS DETECTED BY THE MODEL'S OWN IMPACT RECORD, not by guessing from a velocity.
     * `line.impact.atStep` is -1 until the weight has ever arrived hard, and it carries the step it
     * happened on — so a NEW blow is a step index this game has not sounded yet. Deriving it any
     * other way would be a second opinion about a fact line.js already owns (§6d-10). */
    const impactBefore = this.run.region.shaft.line.impact.atStep;
    this.run.step(DT, inp);
    this.stats.steps++;
    const impactAfter = this.run.region ? this.run.region.shaft.line.impact.atStep : impactBefore;
    if (AUDIO && impactAfter > impactBefore) AUDIO.cue('blow');
    if (this.run.regionIndex !== before && AUDIO) AUDIO.cue('descend');
    if (this.run.complete) { this.screen = SCREEN.ENDING; if (AUDIO) AUDIO.cue('ending'); return false; }
    return true;
  };

  /* The instrument. ⚠️ A REFUSAL IS SHOWN, never swallowed — line.js names every one of them and
   * §0z is explicit that a silent refusal cannot be told apart from a failure. */
  Game.prototype.doRead = function () {
    const r = this.run.region.read();
    if (r.ok) {
      this.stats.reads++;
      this.reading = { text: 'TRUE DEPTH  ' + r.marks.toFixed(1) + ' marks', t: 4.0, ok: true };
      if (AUDIO) AUDIO.cue('read');
    } else {
      this.stats.refusals++;
      this.reading = { text: r.reason, t: 3.0, ok: false };
      if (AUDIO) AUDIO.cue('refuse');
    }
    return r;
  };

  Game.prototype.postStep = function (elapsed) {
    if (this.run.regionIndex !== this.lastRegionIndex) {
      this.lastRegionIndex = this.run.regionIndex;
      const d = this.run.region.def;
      this.banner = { lines: [d.title, d.brief], t: 5.0 };
    }
    /* ⛔⛔ UI TIMERS ARE CLAMPED, AND THE SIMULATION'S CLAMP DOES NOT COVER THEM. MEASURED 2026-09-04
     * in Chrome: a backgrounded tab throttles `requestAnimationFrame` hard and returns a frame with
     * `longestFrameMs 18343` — an eighteen-second delta. The accumulator above already refuses to run
     * eighteen seconds of physics, but these two countdowns were being decremented by the RAW delta,
     * so a region title or a depth reading on screen when the player tabs away is GONE the instant
     * they come back, and on any hitch it flickers. ⇒ a message is timed in FRAMES-ish, not in
     * wall-clock seconds, because its whole purpose is to be READ. Same root cause as the
     * accumulator, one layer up, and it needed its own fix because it is a different clock consumer. */
    const uiDt = Math.min(elapsed, 1 / 15);
    if (this.banner) { this.banner.t -= uiDt; if (this.banner.t <= 0) this.banner = null; }
    if (this.reading) { this.reading.t -= uiDt; if (this.reading.t <= 0) this.reading = null; }

    /* the room tone tracks how deep in THIS room the player is — 0 at its top, 1 at its floor */
    if (AUDIO) {
      const rm = this.run.region.room;
      AUDIO.update(elapsed, this.run.region.shaft.body.y / (rm.rows * RENDER.CELL));
    }
  };

  /* Draw whatever screen is current. ⚠️ The harness photographs through THIS, so a screenshot is the
   * same pixels a player sees rather than a picture the test drew for itself. */
  Game.prototype.drawFrame = function (dt) {
    if (this.screen === SCREEN.PLAYING) { this.renderer.frame(this.run.region, dt || DT); this.drawHud(); }
    else if (this.screen === SCREEN.ENDING) this.drawEnding();
    else if (this.screen === SCREEN.TITLE) this.drawTitle();
    else if (this.screen === SCREEN.LOADING) this.drawCentred(['LOADING']);
    else if (this.screen === SCREEN.ERROR) this.drawCentred(this.errorText.split('\n'), '#d95f10');
  };

  /* ⛔ THE HARNESS HOOK — wing §1a rule 2 makes this MANDATORY on every web wrapper this wing ships.
   * A claude-in-chrome tab is `visibilityState: "hidden"`, so `requestAnimationFrame` never fires and
   * a perfectly healthy build reads `frames: 0` forever. PROOFMARK was nine seconds from being
   * rebuilt to "fix" a title plate that was never broken. This lets a hidden tab, or a test, drive
   * the simulation deliberately at exactly the DT everything was proven at.
   *   `inputFn` is an input object, or a function (game, i) -> input, so a scripted plan can steer.
   * Returns the number of steps actually run — a COUNT, never a verdict (master §2b rule 2). */
  Game.prototype.stepN = function (n, inputFn) {
    let ran = 0;
    const fn = (typeof inputFn === 'function') ? inputFn : function () { return inputFn || {}; };
    for (let i = 0; i < n; i++) {
      if (this.screen !== SCREEN.PLAYING) break;
      const alive = this.advance(fn(this, i) || {});
      ran++;
      if (!alive) break;
    }
    if (this.screen === SCREEN.PLAYING) this.postStep(ran * DT);
    this.drawFrame(DT);
    return ran;
  };

  /* ================================================================================================
   * HUD and screens. ⚠️ Typography is drawn, not styled — the canvas is the product and a DOM
   * overlay would not survive a screenshot, a fullscreen or an itch embed the same way.
   * ================================================================================================ */
  function shade(g, x, y, w, h, a) { g.fillStyle = 'rgba(8,9,13,' + a + ')'; g.fillRect(x, y, w, h); }
  function font(size) { return (size || 8) + 'px ui-monospace, "DejaVu Sans Mono", Menlo, Consolas, monospace'; }

  Game.prototype.text = function (s, x, y, colour, size, align) {
    const g = this.ctx;
    g.font = font(size);
    g.textAlign = align || 'left';
    g.textBaseline = 'top';
    g.fillStyle = 'rgba(5,6,10,0.9)';
    g.fillText(s, x + 1, y + 1);
    g.fillStyle = colour || '#e0d2b6';
    g.fillText(s, x, y);
  };

  /* ⛔⛔ A PLATE IS MEASURED FROM ITS OWN TEXT, NEVER TYPED. MEASURED 2026-09-04 by screenshotting the
   * running build and zooming in: the reel readout was drawn over a hand-typed 92 px shade box and
   * rendered as `LINE 10.0 / 10 ma` + the word `rks` standing on pale masonry, unreadable. The
   * top-right region label had NO plate at all and sat on the same pale stone.
   * ⭐ The typed width is the whole defect and it is master §2b's family: a constant that describes
   * something it does not re-derive certifies whatever that thing later becomes. One longer region
   * title, one more digit on the reel, one different font fallback on somebody else's machine, and
   * the text leaves the box again — silently, because nothing measures it. `measureText` cannot
   * drift, so this plate is correct for a string nobody has written yet. */
  Game.prototype.plate = function (s, x, y, size, align, alpha) {
    const g = this.ctx;
    g.font = font(size);
    const w = Math.ceil(g.measureText(s).width) + 8;
    const h = (size || 8) + 6;
    const left = align === 'right' ? x - w + 4 : (align === 'center' ? x - w / 2 : x - 4);
    shade(g, Math.round(left), Math.round(y - 3), w, h, alpha === undefined ? 0.62 : alpha);
    return w;
  };

  Game.prototype.drawHud = function () {
    const g = this.ctx, reg = this.run.region, L = reg.shaft.line;
    /* the reel — the one persistent number, because it is the budget the whole game is played on */
    const marks = L.out / RENDER.CELL;
    const reel = 'LINE  ' + marks.toFixed(1) + ' / ' + (L.maxLen / RENDER.CELL).toFixed(0) + ' marks';
    const rw = this.plate(reel, 11, 9, 8, 'left', 0.62);
    this.text(reel, 11, 9, '#c9a038', 8);
    const bw = rw - 12, f = L.out / L.maxLen;
    shade(g, 7, 19, rw, 8, 0.62);
    g.fillStyle = 'rgba(70,62,44,0.9)'; g.fillRect(11, 21, bw, 3);
    g.fillStyle = L.taut ? '#f0d97a' : '#8a6a1e'; g.fillRect(11, 21, Math.round(bw * f), 3);

    /* the region, small and always there, so a player always knows which room they are in */
    const label = String(this.run.regionIndex + 1) + '/' + WORLD.REGIONS.length + '  ' + reg.def.title;
    this.plate(label, VIEW_W - 6, 8, 8, 'right', 0.62);
    this.text(label, VIEW_W - 6, 8, reg.solved ? '#8fbf6a' : 'rgba(198,184,160,0.95)', 8, 'right');
    if (reg.solved) {
      /* ⚠️ was #8c2a06 — a dark rust red on pale masonry, measured unreadable in a screenshot. The
       * one line telling the player the gate they just solved DID something has to be the most
       * legible thing on screen, not the least. */
      const way = 'THE WAY ON IS OPEN';
      this.plate(way, VIEW_W - 6, 19, 8, 'right', 0.62);
      this.text(way, VIEW_W - 6, 19, '#f0d97a', 8, 'right');
    }

    if (this.reading) {
      const a = Math.min(1, this.reading.t);
      shade(g, 0, VIEW_H - 44, VIEW_W, 16, 0.72 * a);
      this.text(this.reading.text, VIEW_W / 2, VIEW_H - 40, this.reading.ok ? '#f0d97a' : '#d0a68a', 8, 'center');
    }
    if (this.banner) {
      const a = Math.min(1, this.banner.t / 1.2);
      shade(g, 0, 74, VIEW_W, 34, 0.72 * a);
      this.text(this.banner.lines[0], VIEW_W / 2, 80, 'rgba(240,217,122,' + a + ')', 12, 'center');
      this.text(this.banner.lines[1], VIEW_W / 2, 96, 'rgba(198,184,160,' + a + ')', 8, 'center');
    }
    /* controls, only while the first region is unsolved — a tutorial that never goes away is a HUD */
    if (this.run.regionIndex === 0 && !reg.solved) {
      shade(g, 0, VIEW_H - 14, VIEW_W, 14, 0.62);
      this.text('MOVE arrows   JUMP Z   DASH X   LOWER down   REEL up   READ C   MUTE M',
        VIEW_W / 2, VIEW_H - 11, 'rgba(198,184,160,0.95)', 8, 'center');
    }
    /* the one persistent piece of state a player can change and must be able to SEE */
    if (this.muted) this.text('MUTED', 11, VIEW_H - 26, 'rgba(168,156,136,0.9)', 8);
  };

  Game.prototype.drawCentred = function (lines, colour) {
    const g = this.ctx;
    g.fillStyle = '#08090d'; g.fillRect(0, 0, VIEW_W, VIEW_H);
    for (let i = 0; i < lines.length; i++) {
      this.text(lines[i], VIEW_W / 2, VIEW_H / 2 - (lines.length * 6) + i * 12, colour || '#e0d2b6', 8, 'center');
    }
  };

  Game.prototype.drawTitle = function () {
    const g = this.ctx;
    /* ⛔ THE SHAFT IS BEHIND THE TITLE. It was pure black — ~70% empty, and it showed a buyer nothing
     * about how a pixel-art game looks, on one of seven store images. The backdrop is drawn from the
     * game's OWN tile atlas so the title card is a picture of the product. If the atlas is somehow
     * unavailable the flat fill is still correct, so this can degrade but not break. */
    if (!this.renderer.titleBackdrop(g, VIEW_W, VIEW_H)) {
      g.fillStyle = '#08090d'; g.fillRect(0, 0, VIEW_W, VIEW_H);
    }
    /* a plumb line, drawn: the title screen is the instrument */
    const cx = VIEW_W / 2;
    g.strokeStyle = '#8a8070'; g.lineWidth = 1;
    g.beginPath(); g.moveTo(cx + 0.5, 0); g.lineTo(cx + 0.5, 150); g.stroke();
    for (let m = 1; m <= 9; m++) { g.fillStyle = '#c9a038'; g.fillRect(cx - 1, m * 16, 3, 1); }
    g.fillStyle = '#f0d97a'; g.fillRect(cx - 3, 150, 6, 8);
    g.fillStyle = 'rgba(20,16,10,0.9)'; g.fillRect(cx - 3, 157, 6, 1);

    this.text('PLUMBLINE', cx, 172, '#e0d2b6', 20, 'center');
    this.text('every door was already open to somebody who knew where it was', cx, 198, 'rgba(168,156,136,0.9)', 8, 'center');
    this.text('PRESS Z', cx, 222, '#f0d97a', 10, 'center');
    /* ⛔ THE MUTE IS ANNOUNCED. §6b-9 rule 5: a mechanic the screen never mentions is not a mechanic,
     * and a player who wants silence should not have to guess a key. */
    this.text(this.muted ? 'M  sound off' : 'M  sound on', cx, 240, 'rgba(138,128,112,0.95)', 8, 'center');
    this.text('Core Systems Asset Factory', cx, 254, 'rgba(107,99,87,0.9)', 8, 'center');
  };

  /* ⛔⛔ WRAPPED AGAINST A MEASURED WIDTH, NEVER A CHARACTER COUNT — AND THE UNWRAPPED VERSION
   * SHIPPED A CLIPPED ENDING. MEASURED 2026-09-04 (`Internal_Ops/verify_text_fit.js`, which records
   * what `fillText` actually reached rather than restating any layout constant): three of the ending's
   * survey lines drew to x=518 on a 480 px canvas and were cut mid-word — *"the shaft between them
   * was neve"*. That is the PAYOFF OF THE ENTIRE GAME, truncated, on the one screen a player reads
   * word for word. Wing §6d-2 records this class on a Game Boy ("overflow is equally silent") and
   * §6d-9 rule 4 records a column budget that was one character wrong for three months.
   * ⭐ A character count would not have fixed it either: `endingLines()` DERIVES its numbers from the
   * region datums, so the line length changes with the design. `measureText` cannot drift.
   * ⚠️ Continuation lines are indented past the survey's own indent, so a wrapped detail line still
   * reads as belonging to the survey above it rather than as a new statement. */
  Game.prototype.wrapText = function (s, maxW, size) {
    const g = this.ctx;
    g.font = font(size);
    if (!s || g.measureText(s).width <= maxW) return [s];
    const indent = (s.match(/^\s*/) || [''])[0];
    const words = s.trim().split(/\s+/);
    const out = [];
    let cur = indent;
    for (const w of words) {
      const trial = cur.trim() ? cur + ' ' + w : indent + w;
      if (cur.trim() && g.measureText(trial).width > maxW) { out.push(cur); cur = indent + '   ' + w; }
      else cur = trial;
    }
    if (cur.trim()) out.push(cur);
    return out;
  };

  Game.prototype.drawEnding = function () {
    const g = this.ctx;
    g.fillStyle = '#08090d'; g.fillRect(0, 0, VIEW_W, VIEW_H);
    const MARGIN = 16;
    const maxW = VIEW_W - MARGIN * 2;
    /* the demo stops at the sump and says so; the paid build resolves the three surveys */
    const demo = WORLD.EDITION === 'demo';
    const lines = demo ? WORLD.demoEndLines() : WORLD.endingLines();
    let y = 12;
    for (const ln of lines) {
      if (ln === '') { y += 5; continue; }
      const isSurvey = ln.indexOf('SURVEY') === 0 || ln.indexOf('ALL THREE') === 0 || ln.indexOf('THE SUMP IS') === 0;
      const colour = isSurvey ? '#f0d97a' : (ln.indexOf('   ') === 0 ? '#a89c88' : '#e0d2b6');
      for (const part of this.wrapText(ln, maxW, 8)) { this.text(part, MARGIN, y, colour, 8); y += 10; }
    }
    this.text('R  to descend again', VIEW_W - 12, VIEW_H - 14, '#f0d97a', 8, 'right');
  };

  const API = { Game: Game, SCREEN: SCREEN, VIEW_W: VIEW_W, VIEW_H: VIEW_H, DT: DT, KEYS: KEYS };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  root.PL_GAME = API;
})(typeof globalThis !== 'undefined' ? globalThis : this);
