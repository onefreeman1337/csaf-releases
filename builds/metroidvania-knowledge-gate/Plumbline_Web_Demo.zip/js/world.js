/* ================================================================================================
 * world.js — THE SHAFT. The four validated gates, joined into one descent, with a real ending.
 * ================================================================================================
 * DESIGN.md §5: the vertical slice is ONE shaft and FOUR gates. `gates.js` proved those four gates
 * in isolation — D1 per gate and D2 across the slice — and this file is the ONLY place they become
 * a game. It adds exactly three things and nothing else:
 *
 *   1. A DATUM per region, so the instrument's MEASURING half works at all (see the block below).
 *   2. An EXIT per region, carved ONLY on completion, so finishing a gate visibly opens the way on.
 *   3. The order, the titles, and the ending the four regions add up to.
 *
 * ⛔⛔ THE GEOMETRY IS NOT TOUCHED BEFORE A GATE IS SOLVED, AND THAT IS ASSERTED, NOT PROMISED.
 * Every region is built by its own gate's `build()` — the same function the dominance proof ran on —
 * and `_world_selftest.js` compares the shipped region's cells to a fresh `gate.build()` cell for
 * cell while the gate is unsolved. If a later session widens a corridor here to make the game
 * friendlier, that test goes red and the D1/D2 figures stop being claims about this build. Master
 * §2b's whole family is "a proof about something that is no longer the thing that ships"; this is
 * the cheapest available guard against joining it.
 *
 * ⛔⛔ THE DATUM GAP, MEASURED 2026-09-04 AND THE REASON THIS FILE EXISTS AT ALL.
 * `gates.js` fixtures return no `datum` key, so `Shaft` sets `this.datum = null` and `line.read()`
 * answers `no-datum — this region declares no true depth` in ALL FOUR of them:
 *
 *     node -e "...new G.Shaft(g.build()); pay out 160px; s.line.read(s.datum)"
 *       -> {"ok":false,"reason":"no datum — this region declares no true depth","code":"no-datum"}
 *
 * That is not a defect in `gates.js` — a dominance harness does not need to read a depth, and the
 * `stowed` refusal fires first so nothing in the suites ever reached it. But it means HALF THE
 * INSTRUMENT, and the half the game is NAMED AFTER, is dead in every fixture. Regions declare their
 * datum here, and `_world_selftest.js` asserts a real reading in every one of the four.
 *
 * ⭐ AND THE DATUMS ARE THE STORY. DESIGN §1: *you are lowered into a sealed shaft to find out why
 * the last three surveys disagree.* A region's `topMarks` is its TRUE depth; its `topY` is where
 * that edge is DRAWN. `line.js`'s Datum header is explicit that a region whose datum is merely
 * `topY * marksPerPx` is a region the plumb line is redundant in — so the gaps below are real
 * unmapped shaft between the drawn rooms, and they are what the three surveys each missed a
 * different part of. The eye counts tiles and is wrong; the line reads marks and is right.
 *
 * ⛔ DUAL-MODE + IIFE, for the two reasons wing §6b-5 charges LANTERNBOUND sessions for: a bare
 * `require()` in a file a `<script>` tag also loads is a fatal ReferenceError whose only symptom is
 * a blank canvas, and plain `<script>` tags share ONE global scope.
 * ⛔ NO `Math.random`. ⭐ THE CALLER OWNS THE CLOCK.
 * ---------------------------------------------------------------------------------------------- */
'use strict';

(function (root) {
  const PLAT = (typeof require === 'function') ? require('./plat.js') : root.PL_PLAT;
  const LINE = (typeof require === 'function') ? require('./line.js') : root.PL_LINE;
  const GATES = (typeof require === 'function') ? require('./gates.js') : root.PL_GATES;

  const T = GATES.T;
  const OPEN = PLAT.OPEN, ROCK = PLAT.ROCK, GRATE = PLAT.GRATE;

  /* ================================================================================================
   * THE REGIONS.
   * ================================================================================================
   * `drop`  — a span of the BARRED surface that opens on completion, so the player can descend to
   *           the exit. Two regions need one (the player solves them from the gallery); two do not
   *           (the player is already in the chamber). ⚠️ Declared per region rather than derived,
   *           because "where the player is standing when the gate opens" is a fact about the PUZZLE
   *           and deriving it would be a second opinion about the design.
   * `exit`  — a doorway carved from the end wall on completion. The player finishes the region by
   *           standing in it. Its floor is the region's own rock, so nothing is invented to hold it.
   * `datum` — {topMarks, topY}: the true depth of this region's top edge, and where it is drawn.
   *
   * ⛔⛔ `material` / `floorLight` / `bg` — EACH ROOM LOOKS DIFFERENT, AND THAT IS A DESIGN
   * REQUIREMENT RATHER THAN DECORATION. MEASURED 2026-09-04 (`Kernel/capture/dedupe.js` over the
   * captured gallery): seven store shots resolved to **2 visually distinct images**, with THE HOLD
   * and THE FALL at Hamming distance 7 and 6 — the same picture with different text. Master §4.2b
   * says five frames of one screen argues the product has one screen; worse, this is a game whose
   * entire progression is KNOWING WHERE YOU ARE, and four indistinguishable rooms make that
   * impossible by construction.
   * ⭐ §6b-16 rule 5 required landmarks to be dense and uniform WITHIN a region so every bay is
   * describable. Nobody had asked the same question BETWEEN regions — the wing's own standing
   * question ("name the states this instrument never sees") pointed at the one axis the landmark
   * work never covered.
   * ⇒ the four materials are a descent OUT of the surveyed world and back into rock: cut masonry
   * (surveyed, built, brightest) -> moss (wet, where water collects) -> brick (built, engineered —
   * this is the room with a mechanism in it) -> raw chasm (never built, never reached, darkest).
   * ⚠️ The CELLS are untouched: these fields change only how the room is DRAWN, so
   * `_world_selftest.js`'s cell-for-cell comparison against each gate's own fixture still holds and
   * the D1/D2 dominance figures still describe what ships.
   */
  /* ================================================================================================
   * THE EDITION SEAM — one declaration, overridden by ONE inline <script> in the demo's page.
   * ================================================================================================
   * ⛔⛔ A PAID LISTING MUST OWN BYTES A BUYER CANNOT GET FREE. Master §2b records LANTERNBOUND
   * reaching "CLEARED FOR PUBLISH" **twice** at $14.99 with nothing to sell: 509 green assertions,
   * a complete TEST_REPORT and preflight exit 0, over a project whose only artefact on disk was its
   * FREE web demo. Nothing in the factory asserts that a paid product exists, so every instrument
   * was correct about the thing it measured and the product did not.
   *
   * ⛔ AND IT IS NOT SOLVED BY A PACKAGER THAT REWRITES SOURCE (wing §1-BUILD): that makes the bytes
   * a buyer runs bytes no gate ever ran against. So the edition is DECLARED here, defaulting to the
   * full game, and the demo page sets `window.PL_EDITION = 'demo'` in one inline script before these
   * modules load. Every shipped module is therefore BYTE-IDENTICAL between the demo and the paid
   * build — which `build_editions.js` proves by sha256 — and the only difference is a single word in
   * one generated HTML file.
   *
   * ⭐ WHAT THE DEMO IS: the first TWO regions, which is a real vertical slice rather than a teaser
   * (wing §1). THE BARRED GALLERY teaches that the weight is the key and that the answer is a PLACE;
   * THE SUMP teaches that the place is not where you are standing. After those two a player knows
   * exactly what this game is, which is where the buying decision is honestly made. The paid build
   * carries THE HOLD, THE FALL and the authored ending that resolves the three surveys.
   */
  const DEMO_REGION_COUNT = 2;

  const ALL_REGIONS = [
    {
      id: 'barred-gallery',
      gate: GATES.G1,
      title: 'THE BARRED GALLERY',
      /* what the player is told on arrival — never the answer, only the situation */
      brief: 'Sixty-four bays. A barred floor you cannot pass. Something below answers to weight.',
      /* the survey line that is WRONG about this region, quoted at the ending */
      survey: 'FIRST SURVEY: "gallery floor at 9 marks; nothing beneath it."',
      drop: { c0: 64, c1: 65, row: 9 },
      exit: { c0: 66, c1: 67, r0: 15, r1: 16, floorRow: 17 },
      datum: { topMarks: 0, topY: 0 },
      material: 'mason_on_flag', floorLight: 0.34, bg: 'flag',
    },
    {
      id: 'the-sump',
      gate: GATES.G2,
      title: 'THE SUMP',
      brief: 'The gallery ends. What you are looking for is not on the floor you are standing on.',
      survey: 'SECOND SURVEY: "gallery continues to 71; terminates in rock."',
      drop: null,                                   /* the gallery already ends in a hole */
      exit: { c0: 72, c1: 73, r0: 18, r1: 19, floorRow: 20 },
      /* ⭐ 34, not 20. The drawn room is 26 tiles tall and the gallery in it is drawn at the same
       * height as the last one, so the eye says "I have come down 11 tiles". The line says 34. The
       * difference is the unmapped drop between the two, which is what the first survey stopped at. */
      datum: { topMarks: 34, topY: 0 },
      material: 'moss_on_flag', floorLight: 0.28, bg: 'flag',
    },
    {
      id: 'the-hold',
      gate: GATES.G3,
      title: 'THE HOLD',
      brief: 'A hatch in the floor, held shut. The weight can hold it open. You cannot hold it and pass it.',
      survey: 'THIRD SURVEY: "hatch at 64; no mechanism found."',
      drop: null,                                   /* the hatch IS the way down, and it is the gate */
      exit: { c0: 142, c1: 143, r0: 11, r1: 12, floorRow: 13 },
      datum: { topMarks: 71, topY: 0 },
      material: 'brick_on_flag', floorLight: 0.24, bg: 'flag_cracked',
    },
    {
      id: 'the-fall',
      gate: GATES.G4,
      title: 'THE FALL',
      brief: 'A seal in the floor of the deep chamber. It has not moved for a very long time.',
      survey: 'ALL THREE SURVEYS: "bottom not reached."',
      drop: { c0: 139, c1: 140, row: 9 },
      exit: { c0: 142, c1: 143, r0: 16, r1: 17, floorRow: 18 },
      datum: { topMarks: 96, topY: 0 },
      material: 'chasm_on_flag', floorLight: 0.18, bg: 'flag_cracked',
    },
  ];

  /* ⚠️ READ ONCE, AT LOAD. The edition cannot change while a run is in progress — a game that could
   * would have two different `REGIONS.length` values inside one descent, and the HUD prints that
   * number. Under node (`_world_selftest.js`) `root.PL_EDITION` is undefined, so the suites always
   * measure the FULL game, which is the thing the dominance proof describes. */
  const EDITION = (root.PL_EDITION === 'demo') ? 'demo' : 'full';
  const REGIONS = EDITION === 'demo' ? ALL_REGIONS.slice(0, DEMO_REGION_COUNT) : ALL_REGIONS;

  /* ================================================================================================
   * Region — one gate, playable.
   * ================================================================================================
   * ⭐ IT WRAPS `GATES.Shaft` RATHER THAN REIMPLEMENTING IT. The shipped game therefore steps the
   * body, the line, the gate condition and the barrier through the EXACT code the dominance proof
   * ran, in the same order. A second step loop here would be master §6d-10's "second opinion about a
   * shared fact" with a proof attached to the wrong one.
   */
  function Region(index) {
    const def = REGIONS[index];
    if (!def) throw new Error('Region: no region at index ' + index);
    this.index = index;
    this.def = def;
    const fixture = def.gate.build();
    fixture.datum = new LINE.Datum(def.datum.topMarks, def.datum.topY, LINE.DEFAULTS.marksPerPx);
    this.shaft = new GATES.Shaft(fixture);
    this.room = this.shaft.room;
    /* ⛔ THREE-VALUED, NOT TWO. `solved` is the gate's own condition; `opened` is whether the exit
     * geometry has been carved; `done` is whether the player has walked into it. Collapsing any two
     * of them is §0z's tri-state-through-a-boolean shape — a player standing on a solved plate has
     * not finished the region, and a region whose exit is carved is not one the player has left. */
    this.solved = false;
    this.opened = false;
    this.done = false;
    /* counts of WORK, never verdicts (master §2b rule 2) */
    this.stats = { frames: 0, reads: 0, refusals: 0, solvedAtFrame: -1, doneAtFrame: -1 };
  }

  /* The gate's own completion fact. ⚠️ THREE of the four latch and are answered by `gate.open`; THE
   * HOLD does not latch and is answered by `passed()` — being through it, which is a different fact
   * from having pressed it (gates.js G3). Read the gate's own declaration rather than assuming. */
  Region.prototype.isSolved = function () {
    const d = this.def.gate;
    if (typeof d.passed === 'function') return !!d.passed(this.shaft);
    return !!this.shaft.gate.open;
  };

  /* Carve the way on. Called ONCE, on the frame the gate is first solved. */
  Region.prototype.openExit = function () {
    if (this.opened) return this;
    const d = this.def;
    if (d.drop) GATES.fill(this.room, d.drop.c0, d.drop.row, d.drop.c1, d.drop.row, OPEN);
    GATES.fill(this.room, d.exit.c0, d.exit.r0, d.exit.c1, d.exit.r1, OPEN);
    this.opened = true;
    return this;
  };

  /* Is the player standing in the doorway? ⚠️ `onGround` is required: falling PAST an exit is not
   * arriving at one, and without it a region could complete mid-air on a frame the player never saw. */
  Region.prototype.atExit = function () {
    if (!this.opened) return false;
    const b = this.shaft.body;
    if (!b.onGround) return false;
    const e = this.def.exit;
    const hw = b.cfg.w / 2;
    return (b.x + hw) > e.c0 * T && (b.x - hw) < (e.c1 + 1) * T
      && Math.abs(b.y - e.floorRow * T) < 1.0;
  };

  Region.prototype.step = function (dt, input) {
    if (this.done) return this;
    this.shaft.step(dt, input);
    this.stats.frames++;
    if (!this.solved && this.isSolved()) {
      this.solved = true;
      this.stats.solvedAtFrame = this.stats.frames;
      this.openExit();
    }
    if (this.solved && this.atExit()) {
      this.done = true;
      this.stats.doneAtFrame = this.stats.frames;
    }
    return this;
  };

  /* The instrument's MEASURING half, wired to this region's declared datum. Returns line.js's own
   * result object unchanged — including its NAMED refusals, which are the whole point (§0z). */
  Region.prototype.read = function () {
    const r = this.shaft.line.read(this.shaft.datum);
    if (r.ok) this.stats.reads++; else this.stats.refusals++;
    return r;
  };

  /* ================================================================================================
   * Run — the whole descent, and the only thing game.js talks to.
   * ================================================================================================ */
  function Run() {
    this.regionIndex = 0;
    this.region = new Region(0);
    this.complete = false;
    this.stats = { frames: 0, regionsDone: 0 };
  }

  Run.prototype.step = function (dt, input) {
    if (this.complete) return this;
    this.stats.frames++;
    this.region.step(dt, input);
    if (this.region.done) {
      this.stats.regionsDone++;
      if (this.regionIndex + 1 >= REGIONS.length) {
        this.complete = true;
      } else {
        this.regionIndex++;
        this.region = new Region(this.regionIndex);
      }
    }
    return this;
  };

  /* ================================================================================================
   * THE ENDING — why the three surveys disagreed.
   * ================================================================================================
   * ⭐ It is DERIVED from the datums rather than typed, so a session that re-tunes a region's depth
   * cannot leave the ending stating a number the game no longer contains. Master §2b's stale-figure
   * row, applied to prose: a measurement copied into a listing is the same defect as one copied into
   * a checker.
   */
  function endingLines() {
    const out = [];
    const total = REGIONS[REGIONS.length - 1].datum.topMarks;
    out.push('You come back up with nothing in your hands.');
    out.push('');
    out.push('The three surveys did not disagree. Each one was right, and each one stopped.');
    out.push('');
    for (let i = 0; i < REGIONS.length; i++) {
      const r = REGIONS[i];
      const drawnTop = 0;
      const gap = i === 0 ? 0 : r.datum.topMarks - REGIONS[i - 1].datum.topMarks;
      out.push(r.survey);
      out.push(i === 0
        ? '   ' + r.title + ' begins at 0 marks. That much everyone had.'
        : '   ' + r.title + ' begins at ' + r.datum.topMarks + ' marks — ' + gap
          + ' below the room above it, and the shaft between them was never drawn.');
      void drawnTop;
    }
    out.push('');
    out.push('Every survey measured from the mark it was lowered to, and every survey');
    out.push('assumed the room below began where the room above ended. None of them did.');
    out.push('');
    out.push('True depth of the seal: ' + (total + 18) + ' marks.');
    out.push('You are the first person to have measured it, and the only thing');
    out.push('you are taking out of this shaft is that you know where it is.');
    return out;
  }

  /* ================================================================================================
   * THE DEMO'S CLOSING CARD.
   * ================================================================================================
   * ⛔ IT TELLS THE TRUTH AND IT DOES NOT SPOIL THE ANSWER. It says exactly how much of the game the
   * player has seen, names what is in the paid build, and — because the whole product is that the
   * surveys disagree — it states the question the remaining two regions answer WITHOUT answering it.
   * ⚠️ The counts are DERIVED from the region tables, never typed: a session that adds a region or
   * moves the demo boundary cannot leave this card stating a number the game no longer contains
   * (master §2b, the stale-figure row, applied to store-facing prose).
   */
  function demoEndLines() {
    const done = REGIONS.length, all = ALL_REGIONS.length;
    return [
      'THE SUMP IS AS FAR AS THIS DEMO GOES.',
      '',
      'You have descended ' + done + ' of the ' + all + ' regions of the shaft, and you have',
      'everything you need to read the rest of it: the weight finds what',
      'the eye cannot, and the line tells you a depth the room is lying about.',
      '',
      'Below you are THE HOLD and THE FALL, and the reason the three',
      'surveys disagree. The full descent is the paid build.',
      '',
      'Nothing here was withheld to make you buy it. This is the',
      'first half of the game, and it ends where it stops teaching you.',
    ];
  }

  const API = {
    REGIONS: REGIONS, ALL_REGIONS: ALL_REGIONS, EDITION: EDITION,
    DEMO_REGION_COUNT: DEMO_REGION_COUNT,
    Region: Region, Run: Run, endingLines: endingLines, demoEndLines: demoEndLines, T: T,
    OPEN: OPEN, ROCK: ROCK, GRATE: GRATE,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  root.PL_WORLD = API;
})(typeof globalThis !== 'undefined' ? globalThis : this);
