/* ================================================================================================
 * line.js — THE PLUMB LINE. The one instrument in PLUMBLINE, and it carries two roles on purpose.
 * ================================================================================================
 * DESIGN.md §3: a weighted cord on a reel. (1) IT MEASURES — paid out and settled, it reports TRUE
 * depth, in a shaft whose visual layout lies about depth constantly. (2) IT ACTS — lowered onto a
 * plate with slack in the cord, its weight rests where the player cannot stand.
 *
 * ⛔⛔ THE RULE THAT KEEPS THIS OUT OF HEARTHWARD'S GRAVE, WRITTEN AS CODE AND NOT AS A PREFERENCE.
 * §6b-15's COINCIDENCE TEST fired on this design before a line of it existed: one noun (the line)
 * carries two roles (measure, act), which is structurally HEARTHWARD's fatal `weapon == health`.
 * DESIGN §3 keeps it, and the whole difference is REVERSIBILITY BY THE PLAYER'S OWN HAND:
 *
 *   >  THE LINE MAY NEVER BE DESTROYED, STOLEN, CUT, OR MADE UNAVAILABLE BY ANYTHING OTHER THAN
 *   >  THE PLAYER'S OWN HAND.
 *
 * So this module exposes NO verb that shortens or removes the line except `reelIn`, which is a held
 * key. There is no `cut()`, no `sever()`, no `drop()`, no damage hook and no `maxLen` setter. That is
 * asserted mechanically in `_line_selftest.js` arm 10 — as a CLASS over the source text and over the
 * runtime, not as an example — because a rule that lives only in a comment is not a rule (§6b-2b
 * rule 2: *a bound stated in a comment is not a bound*).
 *
 * ⛔ DUAL-MODE + IIFE, for the two reasons §6b-5 charges LANTERNBOUND sessions for: a bare
 * `require()` in a file a `<script>` tag also loads is a fatal ReferenceError whose only symptom is a
 * blank canvas, and plain `<script>` tags share ONE global scope so every top-level `const` here
 * would collide with a sibling's.
 *
 * ⛔ NO `Math.random`. ⭐ THE CALLER OWNS THE CLOCK — `step(dt, ...)` advances by exactly the dt it is
 * handed and reads real time never (§6b-2's closing rule: LANTERNBOUND's flame burned at twice its
 * tuned rate because the model and the browser were both advancing it).
 *
 * ⛔ ONE OPINION ABOUT WHAT BLOCKS. Every collision query in this file goes through plat.js's
 * `overlapsSolid`, which goes through `Room.solid`. §6d-10: a second implementation of a shared fact
 * is a place a product moves without anyone editing it.
 * ---------------------------------------------------------------------------------------------- */
'use strict';

(function (root) {
  const PLAT = (typeof require === 'function') ? require('./plat.js') : root.PL_PLAT;

  const DEF = {
    tile: 16,

    maxLen: 160,          /* px of cord on the reel = 10 marks. A budget, and a legible one.        */
    /* ⛔⛔ THE REEL RATE IS THE LEVEL DESIGNER'S ONLY FREE LEVER ON HOW LONG A CORRIDOR HAS TO BE, AND
     * IT WAS SLOWED 2026-09-03 ON A MEASUREMENT. Do not re-tune either of these by feel.
     * `_probe_cost.js` derives the cost of one attempt `a` and of one bay of travel, and shows D1
     * (brute-force cost / knower cost) is bounded by (tStop + a) / tRun. `a` is almost entirely these
     * two numbers — pay-out and reel-in are linear in the cord and inversely linear in the rate — so
     * a fast reel forces a LONG gallery to clear the same 20x bar, and DESIGN §4c records that a
     * gallery long enough to clear it at the old rates (140 bays) cannot be navigated by a human.
     *
     * ⛔⛔ AND THE OBVIOUS VERSION OF THIS CHANGE WAS TRIED FIRST AND WAS WRONG, WHICH IS WHY BOTH
     * NUMBERS ARE COMMENTED TOGETHER. Slowing BOTH rates by 1.5x gave the right `a` and broke the
     * game: `_line_selftest` arm 14k fell to `worstLowering 49.3 px/s` (from ~97) because **a lowered
     * weight descends no faster than the cord is paid out**, so a slower pay-out makes a LOWERING and
     * a BLOW less distinguishable — and `_gates_selftest`'s sweep control then OPENED THE FALL. The
     * line above this one used to claim "the reel rate does NOT govern the arrival"; that is true of
     * the REEL and false of the PAY-OUT, and the two had been written as one fact.
     * ⇒ `payRate` is a PHYSICS constant (it sets how hard a lowering can land) and is left alone.
     * `reelRate` touches nothing but cost, so it carries the whole change. */
    payRate: 90,          /* px/s paid out while the key is held. ⛔ NOT a tuning knob — see above.  */
    reelRate: 45,         /* px/s reeled in  (was 140). Hauling a weight back UP by hand is the slow
                           * half of using a plumb line, so this is also the more physical ordering.
                           * ⚠️ DESIGN §3's reversibility rule is a FEEL requirement and still holds:
                           * a full 160 px recovery is 3.6 s — seconds, by the player's own hand, and
                           * never taken from them. It is what makes putting the instrument down a
                           * decision instead of a reflex (DESIGN §3a, the lamp's replacement).       */

    bob: 6,               /* px, the weight's square AABB                                           */
    gravity: 1500,        /* px/s^2 — the same world gravity plat.js uses                           */
    /* ⭐ MEASURED, not chosen by feel — `_probe_damping.js`, and the first answer was WRONG in both
     * directions. This knob sets THE PLAYER'S COST OF A READING: from a 200 px/s sideways kick,
     * time-to-first-reading is 128 frames (2.13 s) at 0.6, 208 (3.47 s) at 0, and 50 at 2.0; the
     * swing amplitude at frame 900 spans over a million-fold across the sweep. ⚠️ A first probe
     * called it INERT on a flat row of 68/68/68/69/71/63 — that metric was the first frame the bob
     * crossed plumb, i.e. HALF A PENDULUM PERIOD, which is a property of the cord's LENGTH and not
     * of damping at all. The knob was fine; the instrument was measuring the wrong quantity. */
    drag: 0.6,            /* per second of velocity bled off                                        */
    maxStepPx: 3,         /* substep ceiling — a swinging bob outruns a 16 px tile easily            */

    /* ⚠️ THE REST THRESHOLD IS A MEASUREMENT GATE, NOT POLISH. `read()` refuses above it, so this
     * number decides how long a player waits for a depth. Chosen at ~1/8 of a tile per second: below
     * that the bob is visibly still, so the refusal never contradicts what the screen shows. */
    restSpeed: 2.0,       /* px/s                                                                   */
    slackEps: 0.75,       /* px. Below this the cord counts as TAUT — see `weight()`.               */

    /* ⭐ THE WEIGHT IS ALSO A HAMMER, and this is the number that says what counts as a BLOW rather
     * than as a LOWERING. ⛔ IT IS A DROP HEIGHT, NOT A SPEED, ON PURPOSE: a speed threshold is a
     * magic number a later session cannot argue with, while "the weight must arrive from a fall of
     * at least one tile" is a sentence a level designer can check with their eyes. The speed is
     * DERIVED — sqrt(2*g*h) = 219.1 px/s — so changing gravity cannot silently move what counts as
     * a strike.
     *
     * ⛔⛔ THIS NUMBER WAS 8 AND WAS WRONG, AND THE ARGUMENT FOR 8 WAS THE INTERESTING PART. It was
     * justified against a weight that merely SITS on a floor: a resting bob re-arrives every frame
     * at one frame of free fall (g*dt = 25 px/s), so any threshold between 25 and 155 looked
     * comfortably untuned. **That compared the wrong two things.** The gate has to tell a LOWERED
     * weight from a DROPPED one, and a lowering is nothing like a sitting — MEASURED,
     * `_probe_arrival.js`, sweeping 1..9 tiles:
     *
     *      LOWERED (payOut held all the way)   97.5 - 168.1 px/s
     *      DROPPED (cord already out, gravity) 281.2 - 588.2 px/s   (>= 2 tiles)
     *
     * so the old floor of 154.9 px/s sat INSIDE the lowered band and a 6- or 8-tile lowering
     * registered as a strike. ⭐ It was caught by a FALSE-RED CONTROL — S7b, which asks whether
     * halving the threshold still refuses a lowering — going red, i.e. by the arm whose only job is
     * to prove the bar is not balanced on today's fixture. 16 px puts the floor at 219.1, roughly
     * centred in the 168-281 gap (+51 / -62). ⚠️ The reel rate does NOT govern the arrival: the bob
     * free-falls between the frames the cord catches it, which is why a lowering arrives at four to
     * seven times a sitting. */
    impactDrop: 16,       /* px of free fall an arrival must be worth before it counts as a blow    */

    marksPerPx: 1 / 16,   /* one mark per tile. The cord is knotted every mark.                     */
  };

  /* ---- refusal reasons. ⛔ NAMED, NEVER A BARE null ---------------------------------------------
   * §0z, paid for on LANTERNBOUND: *a silent refusal is correct behaviour that cannot be told apart
   * from a failure.* `restore()` there returned a bare null on eight conditions, so a hostile input,
   * a version skew and an outright defect were indistinguishable — and the one that was actually
   * happening (pixels handed to a tile-indexed bounds check) imitated the guard working. */
  const REFUSE = {
    STOWED: 'stowed — the line is on the reel; pay it out to take a reading',
    SWINGING: 'swinging — the weight has not settled; wait for it to hang still',
    NO_DATUM: 'no datum — this region declares no true depth',
  };

  /* A DATUM is a region's declaration of where it REALLY is, and it is the whole lie the game tells.
   * `topMarks` is the TRUE depth of the region's top edge; `topY` is where that edge is DRAWN. The
   * two are independent by construction, which is exactly why an eye counting tiles cannot replace
   * the instrument — and why a region whose datum is merely `topMarks = topY * marksPerPx` is a
   * region the plumb line is redundant in. Levels supply these; this module only reads them. */
  function Datum(topMarks, topY, marksPerPx) {
    if (typeof topMarks !== 'number' || !isFinite(topMarks)) throw new Error('Datum: topMarks must be a finite number');
    if (typeof topY !== 'number' || !isFinite(topY)) throw new Error('Datum: topY must be a finite number');
    this.topMarks = topMarks;
    this.topY = topY;
    this.marksPerPx = (typeof marksPerPx === 'number' && isFinite(marksPerPx)) ? marksPerPx : DEF.marksPerPx;
  }
  /* The one conversion. Both `read()` and any level tool must come through it (§6d-10). */
  Datum.prototype.marksAt = function (worldY) {
    return this.topMarks + (worldY - this.topY) * this.marksPerPx;
  };

  function Line(cfg) {
    this.cfg = Object.assign({}, DEF, cfg || {});
    /* ⛔ maxLen is frozen at construction and there is no setter. See the header rule. */
    Object.defineProperty(this, 'maxLen', {
      value: this.cfg.maxLen, writable: false, configurable: false, enumerable: true,
    });
    this.out = 0;                 /* px of cord paid out */
    this.bx = 0; this.by = 0;     /* bob CENTRE, world px */
    this.bvx = 0; this.bvy = 0;
    this.pax = null; this.pay = null;   /* previous anchor, for the anchor's own velocity */
    this.taut = false;
    this.resting = false;
    /* ⛔ THE LAST BLOW, AND `atStep: -1` MEANS *NEVER STRUCK* RATHER THAN *STRUCK AT THE START*.
     * §0z: a silent refusal is correct behaviour that cannot be told apart from a failure — a zeroed
     * step index would make "no impact has ever happened" indistinguishable from "one happened on
     * frame 0", and a gate reading it would open itself on construction. */
    this.impact = { speed: 0, x: 0, y: 0, dx: 0, atStep: -1 };
    /* counts of WORK, never verdicts (master §2b rule 2) */
    this.stats = { steps: 0, substeps: 0, paidOut: 0, reeledIn: 0, tautFrames: 0, restFrames: 0, reads: 0, refusals: 0, impacts: 0 };
  }

  /* The speed an arrival must beat to count as a blow, DERIVED from the drop height in cfg. Exposed
   * so a gate can quote it rather than restating it — master §2b's stale-proof-figure row: a checker
   * holding its own copy of the number it checks certifies whatever that number later becomes. */
  Line.prototype.impactSpeed = function () {
    return Math.sqrt(2 * this.cfg.gravity * this.cfg.impactDrop);
  };

  /* Put the bob in the player's hand. Called once when a body first carries the line. */
  Line.prototype.attach = function (ax, ay) {
    this.bx = ax; this.by = ay;
    this.bvx = 0; this.bvy = 0;
    this.pax = ax; this.pay = ay;
    this.out = 0;
    this.taut = false;
    this.resting = false;
    /* a fresh attachment has struck nothing — see the constructor's note on why this is -1 */
    this.impact = { speed: 0, x: 0, y: 0, dx: 0, atStep: -1 };
    return this;
  };

  /* The bob's collision shape, expressed as a plat.js Body-alike so there is exactly ONE overlap
   * implementation in the project. plat's `overlapsSolid` takes FEET-y, so a centred bob is offset
   * by half its height. */
  /* ⛔ `passGrate: true` IS THE INSTRUMENT'S ENTIRE REACH, AND IT IS DECLARED EXACTLY HERE. A
   * grating is solid to the player's 10x22 body and open to this 6 px weight (plat.js `GRATE`), so
   * the line goes where the player cannot — which is what makes a POSITIONAL gate a use of the
   * instrument rather than a walk. If this line is ever deleted the plumb line degenerates into a
   * thing you drop at your own feet, and every gate in gates.js becomes unopenable. */
  function bobShim(c) { return { cfg: { w: c.bob, h: c.bob, tile: c.tile, passGrate: true } }; }
  Line.prototype.bobHits = function (room, cx, cy) {
    return PLAT.overlapsSolid(bobShim(this.cfg), room, cx, cy + this.cfg.bob / 2);
  };

  /**
   * One tick.
   * `input` is {payOut, reelIn} — booleans, both held keys. `ax, ay` is the anchor: the player's
   * hand, in world px. The caller passes it every frame rather than holding a reference to a body,
   * so this module has no opinion about what is carrying it.
   */
  Line.prototype.step = function (dt, input, room, ax, ay) {
    const c = this.cfg;
    const inp = input || {};
    this.stats.steps++;

    if (this.pax === null) { this.pax = ax; this.pay = ay; }
    /* the anchor's own velocity — needed so the taut constraint removes RELATIVE radial motion and
     * not absolute, or running with a taut cord bleeds the swing away instead of driving it */
    const avx = dt > 0 ? (ax - this.pax) / dt : 0;
    const avy = dt > 0 ? (ay - this.pay) / dt : 0;

    /* ---- the reel. The only two verbs that change how much cord is out. ---------------------- */
    if (inp.payOut && !inp.reelIn) {
      const before = this.out;
      this.out = Math.min(this.maxLen, this.out + c.payRate * dt);
      this.stats.paidOut += this.out - before;
    } else if (inp.reelIn && !inp.payOut) {
      const before = this.out;
      this.out = Math.max(0, this.out - c.reelRate * dt);
      this.stats.reeledIn += before - this.out;
    }

    if (this.out <= 0) {
      /* ---- stowed: the bob is in the hand. No physics, no reading, no weight. ---------------- */
      this.out = 0;
      this.bx = ax; this.by = ay;
      this.bvx = 0; this.bvy = 0;
      this.taut = false;
      this.resting = false;
      this.pax = ax; this.pay = ay;
      return this;
    }

    /* ---- integrate the bob ------------------------------------------------------------------- */
    this.bvy += c.gravity * dt;
    const damp = Math.max(0, 1 - c.drag * dt);
    this.bvx *= damp; this.bvy *= damp;

    const dist = Math.max(Math.abs(this.bvx * dt), Math.abs(this.bvy * dt));
    const n = Math.max(1, Math.ceil(dist / c.maxStepPx));
    const sdt = dt / n;
    const blow = this.impactSpeed();
    for (let i = 0; i < n; i++) {
      this.stats.substeps++;
      const nx = this.bx + this.bvx * sdt;
      if (this.bobHits(room, nx, this.by)) this.bvx = 0; else this.bx = nx;
      const ny = this.by + this.bvy * sdt;
      if (this.bobHits(room, this.bx, ny)) {
        /* ⛔ RECORD THE ARRIVAL SPEED **BEFORE** ZEROING IT, and only downward arrivals: a seal in
         * the floor is struck from above. A bob that merely sits on a floor re-arrives every frame
         * at one frame of free fall, so the threshold is what separates a BLOW from SITTING — see
         * `impactDrop`. Counts of work, never verdicts. */
        if (this.bvy > blow) {
          /* ⭐ `dx` IS THE ANGLE OF THE CORD AT THE MOMENT OF THE BLOW, and it is recorded because a
           * consumer needs to tell a SQUARE strike from a GLANCING one. A weight hanging plumb under
           * a standing player lands flat on what is beneath it; a weight being dragged along behind
           * a running one arrives from a hundred and forty pixels to the side. Both are "arrivals
           * above the blow speed" and only one of them is somebody hitting something on purpose.
           * MEASURED need: without this, gates.js's seal was struck by the SWEEP CONTROL — a player
           * holding jump while running with the line out strikes everything it drags over. */
          this.impact = { speed: this.bvy, x: this.bx, y: this.by, dx: this.bx - ax, atStep: this.stats.steps };
          this.stats.impacts++;
        }
        this.bvy = 0;
      } else this.by = ny;
    }

    /* ---- the cord: a rope constraint, not a rigid rod ----------------------------------------
     * A rope only pulls. Inside `out` the bob is in free fall and the cord is SLACK — which is the
     * entire mechanism behind `weight()` below, so it is not an approximation, it is the design. */
    let dx = this.bx - ax, dy = this.by - ay;
    let d = Math.hypot(dx, dy);
    this.taut = false;
    if (d > this.out) {
      const nxu = dx / (d || 1), nyu = dy / (d || 1);
      /* positional projection. Swing EMERGES from this: moving the anchor sweeps the bob along the
       * circle and gravity then does the work. No swing impulse anywhere — a player swings the
       * weight by running and stopping, which is DESIGN §2's "the state changes under you". */
      const tx = ax + nxu * this.out, ty = ay + nyu * this.out;
      /* ⚠️ but the cord may not shove the bob THROUGH a wall. If the taut position is inside solid
       * rock the bob stays where it is and the cord simply reads taut — which is what a real cord
       * snagged on an edge does, and it is also what stops the constraint teleporting the weight
       * past geometry the player is using it to probe. */
      if (!this.bobHits(room, tx, ty)) { this.bx = tx; this.by = ty; }
      /* remove only OUTWARD RELATIVE radial velocity (a rope pulls, never pushes) */
      const vr = (this.bvx - avx) * nxu + (this.bvy - avy) * nyu;
      if (vr > 0) { this.bvx -= vr * nxu; this.bvy -= vr * nyu; }
      this.taut = true;
      this.stats.tautFrames++;
      dx = this.bx - ax; dy = this.by - ay; d = Math.hypot(dx, dy);
    }

    /* ---- resting: supported from below, and slow ---------------------------------------------
     * DERIVED from the world every frame and never remembered — plat.js's `onGround` comment says
     * why: a constructor (or a cache) that guesses a fact about the world lies about it. */
    const speed = Math.hypot(this.bvx, this.bvy);
    this.resting = speed <= c.restSpeed && this.bobHits(room, this.bx, this.by + 0.5);
    if (this.resting) this.stats.restFrames++;

    this.pax = ax; this.pay = ay;
    return this;
  };

  /* Distance from anchor to bob RIGHT NOW — always ≤ `out`, and strictly less when the cord is slack. */
  Line.prototype.span = function (ax, ay) { return Math.hypot(this.bx - ax, this.by - ay); };
  Line.prototype.slack = function (ax, ay) { return this.out - this.span(ax, ay); };

  /* ================================================================================================
   * WEIGHT — the ACTING half, and the rule that makes it a PROCEDURAL gate rather than a switch.
   * ================================================================================================
   * ⛔ A BOB HELD UP BY A TAUT CORD PUTS NO WEIGHT ON WHAT IT IS TOUCHING. That is physics, it is
   * honest, and it is the whole puzzle: to press a plate you must pay out ENOUGH cord that the weight
   * is standing on the plate rather than dangling against it. There is no list to pick from and
   * nothing to enumerate — DESIGN §4's dominance test rejected every combinatorial gate archetype
   * and passed the PROCEDURAL one (27.8x) precisely because a knower acts once and is certain while
   * a brute-forcer must first reconstruct a search space nobody handed them.
   *
   * ⚠️ BOTH BOUNDS, IN THE SAME EDIT (§6b-2b rule 1: a one-sided claim cannot see drift in its
   * permissive direction). `_line_selftest.js` arm 4 asserts BOTH that a slack resting bob weighs
   * AND that a taut hanging bob does not — the second is the one that rots silently.
   */
  Line.prototype.weight = function (ax, ay) {
    if (this.out <= 0) return false;
    if (!this.resting) return false;
    return this.slack(ax, ay) > this.cfg.slackEps;
  };

  /* ================================================================================================
   * READ — the MEASURING half. Returns TRUE depth in marks, or a NAMED refusal.
   * ================================================================================================
   * It reads the BOB's depth, not the player's, which is the instrument's whole reach: you learn the
   * true depth of a place you cannot stand by lowering the weight into it.
   */
  Line.prototype.read = function (datum) {
    if (this.out <= 0) { this.stats.refusals++; return { ok: false, reason: REFUSE.STOWED, code: 'stowed' }; }
    if (!datum) { this.stats.refusals++; return { ok: false, reason: REFUSE.NO_DATUM, code: 'no-datum' }; }
    const speed = Math.hypot(this.bvx, this.bvy);
    if (speed > this.cfg.restSpeed) {
      this.stats.refusals++;
      return { ok: false, reason: REFUSE.SWINGING, code: 'swinging', speed: speed };
    }
    this.stats.reads++;
    return { ok: true, marks: datum.marksAt(this.by), y: this.by };
  };

  const API = { Line: Line, Datum: Datum, DEFAULTS: DEF, REFUSE: REFUSE };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  root.PL_LINE = API;
})(typeof globalThis !== 'undefined' ? globalThis : this);
