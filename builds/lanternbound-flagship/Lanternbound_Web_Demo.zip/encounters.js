'use strict';
/* ================================================================================================
 * encounters.js — THE AUTHORED ENCOUNTERS OF THE SLICE. Two so far, and both are TEACHERS.
 * ================================================================================================
 *
 * ⛔ WHY THESE ARE AUTHORED WHEN EVERY OTHER LOCK IN THIS GAME IS GENERATED.
 * `combat.js` generates twelve satisfiable locks per fight, which is DESIGN §3's answer to "one
 * rotation beats everything". That is right for the game and WRONG for its first ten minutes:
 * MEASURED 2026-09-01 (`skill_grid.js`, 60 seeds/cell) a player who understands the colours but has
 * not worked out the ORDERING rule wins 0.0% of fights — at perfect timing and at random timing
 * alike, a flat row. `burial_probe.js` says why: that player assembles the correct sequence in 60.2%
 * of rounds and then BURIES it with a later action in 40.5% of them. Two times out of three they had
 * it and threw it away.
 *
 * The rule they have not been told is this one, and it is the whole game:
 *
 *      ⭐ THE LOCK IS READ WHEN THE ROUND ENDS, OFF THE TOP OF THE STACK.
 *         Whoever acts LAST writes the top. A right colour at the wrong moment is a wrong colour.
 *
 * A generated lock set cannot teach that, because it changes every round and the player cannot tell
 * whether they failed on colours, on order, or on timing. So the first two encounters are hand-built
 * to isolate exactly one variable each, they REPEAT ONE LOCK so a failure can be re-attempted
 * against the same puzzle, and every claim made about them below is PROVEN BY EXHAUSTIVE SEARCH in
 * `encounter_gates.js` — over the real `combat.js` model, never over a restatement of it.
 *
 * ⚠️ AND THE GENEROUS FLAME HERE IS DIEGETIC, NOT A DIFFICULTY DIAL. Both fights happen inside the
 * light of a road shrine, which is why the lantern is full and burns slow. The lesson being taught is
 * ORDERING; darkness is a second lesson and teaching two at once is how you teach neither. The
 * player meets the real burn rate the moment they leave the shrine's light, which is also the first
 * time the overworld's dark means anything.
 *
 * ⛔ THE COLOUR SOURCES ARE THE DESIGN. From `combat.js` ROSTER, and every claim below rests on it:
 *      EMBER    Sable.strike (15) · Wren.emberdart (10)      <- TWO sources, one of them the trap
 *      PALE     Sable.palecut (11) · Oren.hush (8, heals)    <- TWO sources
 *      AZURE    Wren.chill (13)                              <- ONE source
 *      VERDANT  Oren.bramble (12)                            <- ONE source
 * Each character acts exactly once per round. Scarcity is what makes ORDER a decision.
 */

/* ⛔ WRAPPED IN AN IIFE, AND THE SMOKE TEST IS WHY. Plain <script> tags share ONE global scope, so
 * this file's top-level `const API` collided with the identically-named one in `combat.js` and the
 * WHOLE FILE aborted with "Identifier 'API' has already been declared" — a fatal error whose only
 * symptom in a browser is a blank canvas. Wing CLAUDE.md §6b-5 rule 2 records this exact failure
 * from the overworld build and prescribes the class fix rather than renaming the identifier, because
 * two modules written to the same house style will always collide. Caught here by `ui_smoke.js`
 * before a browser ever loaded the page. */
(function () {
/* ------------------------------------------------------------------------------------------------
 * ENCOUNTER 1 — THE HOUND AT THE WAYMARK
 * TEACHES: the lock is read at the END of the round.
 *
 * Lock [VERDANT, AZURE]. VERDANT has one source (Oren) and AZURE has one source (Wren), so the last
 * two pushes must be Oren.bramble then Wren.chill and Sable must not push after them. The line a new player
 * actually takes is the one the UI lists top to bottom — Sable, Wren, Oren — and that line ends with
 * Oren's VERDANT on top of Wren's AZURE, i.e. the correct pair in the wrong order. It fails.
 *
 * ⭐ THAT IS THE ENTIRE POINT: the first failure is ONE SWAP away from the win, so the lesson is
 * legible from the result screen rather than from a tutorial box. Proven in `encounter_gates.js`:
 * the natural line fails, the swapped line wins, and EVERY winning line ends Oren then Wren.
 *
 * ⚠️ MEASURED, AND IT CORRECTED THIS COMMENT: there are FIVE breaking lines, not three, because a
 * RELIGHT PUSHES NO COLOUR AND THEREFORE BURIES NOTHING — so Sable may also act last by spending the
 * oil. This file first claimed "Sable must go first" and the exhaustive prover refused it. That is a
 * richer rule than the one I typed and the encounter teaches it for free: the thing that overwrites
 * the top of the stack is a PUSH, not a turn.
 * ---------------------------------------------------------------------------------------------- */
const E1 = {
  id: 'first-hound',
  ordinal: 1,
  /* ⭐ NAMED FOR A PROP THAT WAS LOOKED AT, AND IT WAS RENAMED BECAUSE OF WHAT THE LOOK SHOWED.
   * This was "THE HOUND AT THE MILESTONE" until the Highland pack's props were rendered at zoom and
   * opened (`_highland_props_sheet.js` -> `Spike/highland_props.png`): the **Milestone** is the
   * weakest object in the set — a flat grey box that will read as a smudge at the shipping 2x —
   * and the **Waymark cairn** is the strongest stone in it. Naming the game's first fight after the
   * worst prop in its only tileset is a Gate 1 failure you get to avoid for free by looking first.
   * ⭐ The rename also makes the diegetic claim TRUE rather than asserted: the pack ships an
   * ANIMATED FIREPIT (`firepit_anim`), so the shrine light this encounter's generous flame rests on
   * is a real object that can actually be placed beside the cairn. */
  name: 'THE HOUND AT THE WAYMARK',
  place: 'the waymark cairn, beside a lit firepit on the moor road',
  enemyName: 'BONE HOUND',
  brief: 'It waits for the round to end before it bites.',
  teaches: {
    rule: 'The lock is read when the ROUND ENDS, off the TOP of the stack. Whoever acts last writes the top.',
    isolatedVariable: 'ordering',
    /* what the gate must prove, in words, so a failing claim names the lesson it broke */
    claims: [
      'the lock can be broken at all',
      'every breaking line ends Oren.bramble then Wren.chill',
      'the natural top-to-bottom line (Sable, Wren, Oren) FAILS',
      'swapping the last two actions WINS',
      'the party survives three consecutive failures',
      'the enemy cannot die before the lesson is asked',
      'the lock never goes dark during the fight',
    ],
  },
  lock: ['VERDANT', 'AZURE'],
  cfg: {
    /* the shrine's light — see the diegetic note at the head of this file */
    startFlame: 100,
    flameBurnMsToEmpty: 90000,
    /* ⛔ A TEACHING ENCOUNTER MAY NOT KILL THE STUDENT FOR NEEDING THREE ATTEMPTS. Wren has the
     * lowest pool at 40, so 12 x 3 = 36 leaves her alive after failing the lesson three times
     * running. Proven, not asserted: gate claim `survives-three-failures`. */
    enemyDamage: 12,
    /* short: ~36 damage a round at ordinary timing, so four rounds even with two failures */
    enemyHp: 120,
    /* one charge, so relight remains a real choice — but see E2, where it cannot be afforded */
    oilCharges: 1,
    /* ⛔ THE WARDEN IS OFF FOR BOTH TEACHERS. §6b-6 rule 4: a teaching encounter must isolate ONE
     * variable, and this one teaches ORDERING. An enemy that also changes which colour is worth
     * hitting would mean a failed round could be the ordering rule OR the hardening, and the player
     * cannot tell which — which teaches neither. Same reason their flame is generous and diegetic. */
    enemyHardens: false,
  },
};

/* ------------------------------------------------------------------------------------------------
 * ENCOUNTER 2 — THE MIRE-WIGHT
 * TEACHES: two characters can push the same colour, and taking the obvious one strands the
 * character you needed at the end.
 *
 * Lock [EMBER, VERDANT, PALE] — three long, so all three characters must push and NOBODY CAN
 * RELIGHT. VERDANT is Oren's alone, so Oren is spent in the middle; PALE must therefore come from
 * SABLE; so EMBER must come from WREN. Exactly one line in the whole space breaks it:
 *
 *      Wren.emberdart  ->  Oren.bramble  ->  Sable.palecut
 *
 * ⭐ THE TRAP IS THE BEST ATTACK IN THE GAME. Sable.strike is the obvious EMBER (power 15 against
 * Wren's 10) and taking it makes the lock UNBREAKABLE that round, because the only remaining PALE
 * belongs to Oren, who has to be the VERDANT. Nothing tells the player they lost the round on their
 * FIRST action; that is the lesson, and it is DESIGN §3's sentence made concrete: "a well-aimed
 * ability at the wrong time buries the colour someone else needed."
 *
 * ⚠️ Second lesson, free, from the same lock: a three-colour lock costs you the relight, because
 * three pushes need three characters. The player meets the oil economy as a CONSEQUENCE rather than
 * as a rule. Proven: `no-relight-in-any-breaking-line`.
 * ---------------------------------------------------------------------------------------------- */
const E2 = {
  id: 'mire-wight',
  ordinal: 2,
  name: 'THE MIRE-WIGHT',
  place: 'the drowned shrine below the ford',
  enemyName: 'MIRE-WIGHT',
  brief: 'Two of you can make fire. Only one of you can make it and still be there at the end.',
  teaches: {
    rule: 'A colour has more than one source. Spending the wrong source strands the character you needed last.',
    isolatedVariable: 'sourcing',
    claims: [
      'exactly one line in the whole space breaks the lock',
      'no breaking line uses Sable.strike — the strongest attack is the trap',
      'no breaking line contains a relight — a three-colour lock costs the oil',
      'THE LEARNER LOSES — a party that never breaks the lock cannot win by attrition',
      'the planner wins — the lesson, once learned, is sufficient',
      'the lesson is observable — the learner survives long enough to watch the trap spring',
      'no character dies to the first landed lock',
      'the enemy cannot die before the lesson is asked',
    ],
  },
  lock: ['EMBER', 'VERDANT', 'PALE'],
  cfg: {
    startFlame: 100,
    flameBurnMsToEmpty: 90000,
    /* ⛔ THESE TWO NUMBERS WERE 150 hp / 18 dmg AND THAT VERSION REWARDED THE MISTAKE IT TEACHES.
     * MEASURED 2026-09-01 (`teach_probe.js`, 300 seeds): the learner sprang the trap in 100% of
     * rounds, broke ZERO locks — and won 100% of the fights anyway, in three rounds, because a
     * 150 hp enemy dies to ordinary attacks long before 18 damage a round matters. An encounter
     * that provokes the intended error and then hands out a win teaches that the lock is optional,
     * which is worse than teaching nothing.
     * ⚠️ AND THE GATE MISSED IT BECAUSE IT WAS MEASURING THE WRONG PLAYER — `a-fumbler-cannot-mash-
     * through` tests the WORST input (weakest attack, always missed), and the real first-ten-minutes
     * player is much better than that: good abilities, decent timing, no idea about ordering. Wing
     * §6b-3 rule 2 says exactly this and I still did it: a floor and a ceiling with no learner
     * between them cannot see the only player whose experience IS the onboarding.
     * ⭐ Swept (`_e2_tune.js`, 24 cells, both policies at perfect timing): 340/26 is the shortest
     * fight where the learner LOSES (0/120, dying around round 6.5 — long enough to watch the trap
     * spring five times) while the planner WINS (120/120, 7 rounds, untouched).
     *
     * ⛔⛔ AND 340/26 WAS THEN REVERTED, BECAUSE MAKING THE LEARNER LOSE MADE THIS ENCOUNTER
     * UNWINNABLE. At 26 damage the enemy kills SABLE in round 2 — and this lock needs all three
     * characters (VERDANT is Oren's alone, so the remaining PALE must be Sable's). **One death and
     * the lock cannot be broken by anybody, ever.** The party then grinds to a wipe having done
     * nothing wrong, with nothing on screen to say the puzzle had become impossible. Found by
     * reading a fight log, not by any check; the exhaustive prover only ever enumerated round one
     * with a full party, so "exhaustive" was exhaustive over the wrong domain.
     * ⭐ THE GENERAL RULE THAT FELL OUT, now a gate claim (`NO-UNBREAKABLE-STATE`): a fight may
     * never reach a state where its own lock is unsolvable — EITHER the lock survives any single
     * death, OR the encounter cannot kill. A lock-blind party can only be beaten by DEATH (breaking
     * a lock prevents damage, it does not add any), so for a three-colour lock those two demands are
     * mutually exclusive and the lock's fragility decides. ⇒ E2's job is to SPRING THE TRAP, which
     * it does in 100% of rounds (`teach_probe.js`), and the binding of the lesson belongs to the
     * first fight whose lock survives a death. */
    enemyDamage: 14,
    enemyHp: 150,
    oilCharges: 1,
    /* ⛔ OFF, exactly as E1 — this teacher isolates SOURCING. See E1's note. */
    enemyHardens: false,
  },
};

/* ================================================================================================
 * THE TWO BOSSES — E3 and E4. Authored 2026-09-02.
 * ================================================================================================
 *
 * ⛔ A BOSS IS NOT A TEACHER, AND AUTHORING IT MEANS SOMETHING DIFFERENT. E1 and E2 repeat ONE lock
 * so a failure can be re-attempted against the same puzzle; that is right for a lesson and wrong for
 * a climax, where a fixed puzzle becomes a combination to be typed in. The bosses therefore keep
 * their GENERATED locks (`lockShape` in the bestiary) and what gets authored is everything else:
 * the place, the framing, and — the part that matters — THE CLAIMS THEY MUST BE HELD TO.
 *
 * ⭐ THE STATS ARE READ OUT OF THE BESTIARY, NEVER RETYPED HERE. `bestiary.js` already owns
 * hp/damage/hardenCount/lockShape for both, and a second copy in this file is master §2b's
 * stale-figure row waiting to happen: the two would drift and the gate would certify whichever one
 * it happened to import. `combatOptions` below merges the creature's cfg underneath the
 * encounter's, so this file may only ever ADD to the bestiary, never silently contradict it.
 *
 * ⛔⛔ AND THE REASON THESE NEEDED A GATE OF THEIR OWN, WHICH IS WING §6b-8 ARRIVING SOMEWHERE NEW.
 * `generateLocks` refuses to emit an unbreakable lock — but "breakable" is computed by
 * `reachableSequences()`, which quantified over the FULL ROSTER. The party's colour sources are
 * uneven: EMBER x2 and PALE x2, but AZURE is Wren's alone and VERDANT is Oren's alone. So a lock
 * demanding both AZURE and VERDANT needs both of those specific characters alive — and a boss at
 * 400-490 HP dealing 30-38 a hit is exactly where somebody dies. The teachers were safe from this
 * by accident (they cannot lose a character before the lesson lands, which their gates prove); the
 * bosses are not, and nothing had ever asked. `boss_gates.js` asks.
 * ---------------------------------------------------------------------------------------------- */

const E3 = {
  id: 'the-hierophant',
  ordinal: 3,
  boss: true,
  creature: 'hierophant',
  name: 'THE HIEROPHANT',
  place: 'the stone ring at the heart of the cairn field, under open sky',
  enemyName: 'THE HIEROPHANT',
  /* ⚠️ The brief is the ONLY warning the player gets, and it is deliberately about the clock rather
   * than about the hardening — the hardening is legible on screen (the UI lists the resisted
   * colours), the drain is not. Tell them the invisible half. */
  brief: 'It has been waiting in this ring a long time, and it drinks the light while you work.',
  teaches: {
    /* ⛔ A BOSS TEACHES NOTHING NEW. Bestiary `whyItDiffers`: "a boss that teaches is a boss that
     * kills you while you read it". This COMPOSES two axes already met separately on the moor —
     * the gravebound's adaptation and the fen bat's clock. */
    rule: 'Nothing new. Everything the moor taught you, at once, with the lantern running out.',
    isolatedVariable: 'none — this is the composition, not a lesson',
    claims: [
      'every lock this creature can generate is breakable by a FULL party',
      'the lock space survives the loss of any single character',
      'a competent party wins',
      'a party that ignores the locks LOSES — a boss must be a test',
      'the fight outlasts the lantern, so the dark half is actually reached',
      'no round can arrive with no legal action',
    ],
  },
  /* ⛔ NO `lock` FIELD ON PURPOSE. Its presence is what makes `combatOptions` pin a repeated lock;
   * a boss must roll a fresh one every round or it is a combination lock, not a fight. */
  cfg: {
    /* ⚠️ The boss does NOT get shrine light. E1/E2's generous flame is diegetic (they happen beside
     * a lit firepit) and this happens in the open at the heart of a burial ground — so it inherits
     * the walk-in carry like any other overworld ambush, which is the whole point of the lantern. */
    flameBurnMsToEmpty: 30000,
  },
};

const E4 = {
  id: 'the-barrow-wyrm',
  ordinal: 4,
  boss: true,
  creature: 'barrowwyrm',
  name: 'THE BARROW WYRM',
  place: 'the long barrow itself, opened — the end of the slice',
  enemyName: 'THE BARROW WYRM',
  brief: 'It remembers the last two things that hurt it. There is nowhere comfortable left to stand.',
  teaches: {
    rule: 'Nothing new. You cannot settle into one colour; keep moving around the whole wheel.',
    isolatedVariable: 'none — this is the climax',
    claims: [
      'every lock this creature can generate is breakable by a FULL party',
      'the lock space survives the loss of any single character',
      'a competent party wins',
      'a party that ignores the locks LOSES — a boss must be a test',
      'ENCIRCLEMENT bites: two colours are blunted at once for most of the fight',
      'no round can arrive with no legal action',
    ],
  },
  cfg: {
    flameBurnMsToEmpty: 30000,
  },
};

const ENCOUNTERS = [E1, E2, E3, E4];

/** The encounter a fresh save starts on. */
function firstEncounter() { return ENCOUNTERS[0]; }

function encounterById(id) { return ENCOUNTERS.find((e) => e.id === id) || null; }

/** The one AFTER `id`, or null at the end of what is authored. */
function nextEncounter(id) {
  const i = ENCOUNTERS.findIndex((e) => e.id === id);
  return i >= 0 && i + 1 < ENCOUNTERS.length ? ENCOUNTERS[i + 1] : null;
}

/**
 * Options for `new Combat(...)` for an authored encounter.
 * ⛔ The lock REPEATS (one-element list) on purpose: a teaching encounter that re-rolls its puzzle
 * after a failure teaches nothing, because the player cannot tell a fixed mistake from a new lock.
 * ⚠️ `carry` (the flame and oil walked in with, DESIGN §4) deliberately does NOT apply to the
 * teachers — they happen in shrine light — and the gate proves the light survives the fight.
 */
function combatOptions(enc, opts = {}) {
  if (!enc) throw new Error('combatOptions: no encounter');

  /* ⭐ A BOSS RESOLVES ITS STATS THROUGH THE BESTIARY, so hp/damage/hardenCount/lockShape have
   * exactly ONE home. The encounter's own cfg layers ON TOP, so this file can add the flame rule
   * without being able to silently contradict the creature's numbers. */
  let base = {};
  if (enc.creature) {
    const B = requireBestiary();
    const c = B && B.byId(enc.creature);
    /* ⛔ THROW, never fall back to {}. A boss silently fought at combat.js's DEFAULT hp because a
     * lookup missed is the "unconfigured default is not a decision" row in master §2b — it would
     * gate green, play easy, and nobody would see a number that looked wrong. */
    if (!c) throw new Error(`combatOptions: encounter "${enc.id}" names creature "${enc.creature}" and the bestiary has no such id`);
    base = c.cfg || {};
  }

  const o = {
    seed: opts.seed >>> 0,
    externalClock: opts.externalClock === true,
    cfg: { ...base, ...enc.cfg, ...(opts.cfg || {}) },
  };
  /* ⛔ ONLY a pinned `lock` produces a repeated puzzle. A boss has none, so `Combat` generates from
   * `cfg.lockShape` — a climax that re-rolls, rather than a combination to be typed in. */
  if (enc.lock) o.locks = [enc.lock.slice()];
  if (opts.locksHideWhenDark !== undefined) o.locksHideWhenDark = opts.locksHideWhenDark;
  return o;
}

/* The bestiary is a sibling module and this file must load in a browser <script> too, so the
 * require is lazy and guarded exactly like the dual-mode footer below (wing §6b-5 rule 1). */
function requireBestiary() {
  if (typeof module !== 'undefined' && module.exports) return require('./bestiary');
  /* matches the footer convention below — `window.LB_BESTIARY`, set by bestiary.js's own footer.
   * ⚠️ index.html must therefore load bestiary.js BEFORE encounters.js; ui_smoke.js asserts it. */
  return typeof window !== 'undefined' ? window.LB_BESTIARY : null;
}

const API = { ENCOUNTERS, firstEncounter, encounterById, nextEncounter, combatOptions };

/* Dual-mode, wing CLAUDE.md §6b-5 rule 1: a bare `require()` at the top of a file that a <script>
 * tag also loads is a fatal ReferenceError whose only symptom is a blank canvas. */
if (typeof module !== 'undefined' && module.exports) module.exports = API;
if (typeof window !== 'undefined') window.LB_ENC = API;
}());
