'use strict';
/* ================================================================================================
 * paths.js — WHERE THE ART AND THE AUDIO LIVE. One declaration, two layouts, zero source rewriting.
 * ================================================================================================
 *
 * ⛔ WHY THIS EXISTS. Until 2026-09-03 the string `'../../Product_Release/assets/'` was written out
 * FOUR TIMES — in `stage.js`, `world_art.js`, `overworld_ui.js` and (as `audio/`) `audio.js` — and it
 * encodes a fact about the DIRECTORY LAYOUT, not about any of those modules. That is the shared-fact
 * defect (wing §6d-10) applied to the one thing that has to change when the game is packaged: the
 * prototype runs at `Internal_Ops/proto/` with the assets two levels up, and the shipped web build
 * runs with `assets/` sitting right beside `index.html`.
 *
 * ⭐ THE ALTERNATIVE WAS A PACKAGER THAT REWRITES SOURCE, AND THAT IS THE WORSE OPTION BY A LOT.
 * `Product_Release` ships raw and human-auditable (master §3), and a build step that edits four
 * string literals on the way out means the bytes a buyer downloads are not the bytes any gate ran
 * against — master §2b's "a LOCAL fix is not a PUBLISHED fix", built into the pipeline on purpose.
 * With this file the shipped module bytes are IDENTICAL to the source bytes and only the HTML page
 * differs, which is a thing a human can check by reading two lines.
 *
 * HOW A PAGE OVERRIDES IT: declare `window.LB_PATHS` BEFORE this script tag.
 *
 *     <script>window.LB_PATHS = { assets: 'assets/', audio: 'audio/' };</script>
 *     <script src="paths.js"></script>
 *
 * ⚠️ THE DEFAULT IS THE PROTOTYPE LAYOUT, NOT A GUESS. Every harness in this project loads the proto
 * pages directly off disk, so defaulting to anything else would break the entire test suite to
 * benefit one consumer. A page that wants the other layout says so in one line, above.
 * ---------------------------------------------------------------------------------------------- */
(function () {
  /* ⛔ THE PAGE NAMES ARE THE SAME CLASS OF FACT AS THE ASSET BASE, AND THEY BITE HARDER.
   * `ui.js` navigates to `'overworld.html'` and `overworld_ui.js` navigates to `'index.html'` — the
   * walk-to-fight seam, in both directions, spelled as literals in two modules. In the prototype
   * the COMBAT page is `index.html`; in a shipped web build `index.html` must be the ENTRY (itch
   * serves it as the embed root), so combat has to move and the overworld has to take its name.
   * With the literals in the modules, packaging means rewriting the navigation of a seam this
   * project has already lost its entire second half to once. It is a table now. */
  const DEFAULTS = {
    assets: '../../Product_Release/assets/',
    audio: '../../Product_Release/audio/',
    pages: { combat: 'index.html', overworld: 'overworld.html' },
  };

  if (typeof window !== 'undefined') {
    const given = window.LB_PATHS || {};
    /* ⚠️ MERGED, NOT REPLACED. A page that overrides only `assets` must still get a working `audio`;
     * a half-declared override that silently blanked the other key would produce a game with art and
     * no sound, and audio failures in this project are already the quietest kind of failure there is
     * (every `au()` call is wrapped so a sound can never break the walk). */
    window.LB_PATHS = {
      assets: given.assets || DEFAULTS.assets,
      audio: given.audio || DEFAULTS.audio,
      pages: Object.assign({}, DEFAULTS.pages, given.pages || {}),
    };
  }

  if (typeof module !== 'undefined' && module.exports) module.exports = DEFAULTS;
}());
