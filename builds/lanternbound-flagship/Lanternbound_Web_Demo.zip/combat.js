'use strict';
/* ================================================================================================
 * LANTERNBOUND — the combat model. Task 2 of DESIGN_Lanternbound.md §10.
 * ================================================================================================
 *
 * ⛔ THIS FILE HAS NO ART, NO CANVAS AND NO DOM ON PURPOSE. The design doc's §8 gates B, C and D are
 * all MEASUREMENTS, and a measurement that can only be taken by a human pressing keys is a
 * measurement that will never be taken. So the model is pure and headless, the browser front end
 * (ui.js) is a thin driver over it, and the bots drive the identical object. If they diverged, every
 * number below would describe a game nobody plays.
 *
 * TIME. There is exactly ONE clock and it is `tick(dtMs)`. The browser feeds it measured elapsed
 * milliseconds; the bots feed it the modelled cost of the action they just took. ⛔ Never drive the
 * flame off a frame COUNT — wing CLAUDE.md §1a: the automation tab is `visibilityState:"hidden"` and
 * rAF is throttled to zero there, so a frame-counted flame reads as frozen under exactly the
 * conditions we test under, and the gate would pass on a game that does not burn.
 *
 * DETERMINISM. Seeded RNG, no Math.random anywhere. DESIGN §7 makes this the precondition for the
 * balance bots, and gate B (is there one rotation that beats everything?) is meaningless without it.
 */

/* ------------------------------------------------------------------------------------------------
 * RNG — mulberry32. Small, fast, and good enough for encounter generation.
 * ---------------------------------------------------------------------------------------------- */
function createRNG(seed) {
  let a = seed >>> 0;
  return function rng() {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ------------------------------------------------------------------------------------------------
 * THE FOUR COLOURS (DESIGN §3)
 * ---------------------------------------------------------------------------------------------- */
const COLOURS = ['EMBER', 'AZURE', 'VERDANT', 'PALE'];

/* ------------------------------------------------------------------------------------------------
 * THE ROSTER — three characters, two colour-pushing abilities each (DESIGN §10 task 2).
 *
 * ⚠️ THE COLOUR SPREAD IS THE DESIGN, NOT A DETAIL. Six abilities cover four colours UNEVENLY:
 *   EMBER   Sable.strike, Wren.emberdart   (2 sources)
 *   PALE    Sable.palecut, Oren.hush       (2 sources)
 *   AZURE   Wren.chill                     (1 source)
 *   VERDANT Oren.bramble                   (1 source)
 * Each character acts ONCE per round, so a lock reading [AZURE, AZURE] is UNSATISFIABLE in a single
 * round and a lock reading [AZURE, EMBER] forces Wren to spend her turn on chill. That scarcity is
 * what makes ORDER a decision rather than a formality (DESIGN §3). The generator below refuses to
 * emit an unsatisfiable lock, and it proves satisfiability by exhaustive search rather than by
 * assertion — this wing's generate-then-exhaustively-solve pipeline (WARDLOCK, COMPOSITOR).
 * ---------------------------------------------------------------------------------------------- */
const ROSTER = [
  {
    id: 'sable', name: 'SABLE', maxHp: 45,
    abilities: [
      { id: 'strike', name: 'Strike', colour: 'EMBER', power: 15 },
      { id: 'palecut', name: 'Pale Cut', colour: 'PALE', power: 11 },
    ],
  },
  {
    id: 'wren', name: 'WREN', maxHp: 40,
    abilities: [
      { id: 'chill', name: 'Chill', colour: 'AZURE', power: 13 },
      { id: 'emberdart', name: 'Emberdart', colour: 'EMBER', power: 10 },
    ],
  },
  {
    id: 'oren', name: 'OREN', maxHp: 48,
    abilities: [
      { id: 'bramble', name: 'Bramble', colour: 'VERDANT', power: 12 },
      { id: 'hush', name: 'Hush', colour: 'PALE', power: 8, heal: 9 },
    ],
  },
];

/* RELIGHT is available to every character and is NOT an ability in the list above, because it costs
 * the whole turn and pushes NO colour (DESIGN §4: "Relighting mid-fight costs a full turn from one
 * character — a real decision, not a button"). Spending it means one fewer colour toward the lock. */
const RELIGHT = { id: 'relight', name: 'Relight', colour: null, power: 0, flame: 55 };

/* ------------------------------------------------------------------------------------------------
 * TUNABLES — every number here is a hypothesis, and gates C and D exist to move them.
 * ---------------------------------------------------------------------------------------------- */
const DEFAULTS = {
  /* THE FLAME (DESIGN §4).
   * ⛔ THE DESIGN DOC'S 90 SECONDS IS AMENDED HERE TO 30, AND THE REASON IS MEASURED. A fight runs
   * 5-7 rounds at 7.5 s of modelled real time each = 40-53 s. A 90 s burn is therefore LONGER THAN
   * THE FIGHT, so the flame could not be contested inside an encounter and every downstream system
   * (hidden locks, the relight decision, the death spiral) was unreachable. 90 s was chosen before
   * anyone knew how long a fight was. It remains the right OVERWORLD number — walking should be
   * generous — so the lantern now burns at two rates and combat is the demanding one. */
  flameMax: 100,
  flameBurnMsToEmpty: 30000,  // COMBAT burn. Overworld stays ~90000 (DESIGN §4, untested here).
  flameBrightAt: 55,          // >= this is BRIGHT; 1..54 is LOW; 0 is OUT

  /* ⭐⭐ GRADED LIGHT — how much of the lock a given flame state shows. DESIGN §11, added
   * 2026-09-01 off `_light_value_probe.js`, and it is the first change here aimed at the SHAPE of
   * the information channel rather than at a number.
   *
   * ⛔ THE MEASUREMENT THAT FORCED IT. Isolating `locksHideWhenDark` (only that flag flipped,
   * 400 seeds): lit rounds break **86%** of locks, dark rounds break **6%**, and with the lock
   * always visible the planner wins **100% at 0 oil at every fight length**. So the whole of this
   * game's difficulty rides on one binary flag: near-solved when lit, near-hopeless when dark, and
   * NOTHING in between. That also explains why oil reads weak — one relight is a PARTIAL remedy to
   * an ALL-OR-NOTHING loss, so no value of `oilCharges` or `relightFlame` can close the gap.
   *
   * ⭐ The states already existed and LOW was doing no work: `visibleLock()` returned the whole lock
   * in BRIGHT and in LOW alike. This gives LOW its own job — you see the SHAPE of what is coming but
   * not all of it — which is the difference between a cliff and a curve.
   *
   * ⛔ THE OBVIOUS IMPLEMENTATION IS WRONG AND WAS REJECTED BEFORE IT WAS BUILT. "Reveal the first
   * N colours of the lock" cannot work: `lockIsBroken()` compares the lock against the TOP of the
   * stack, so knowing a PREFIX buys nothing — you cannot break [EMBER,PALE] by ending on [.., EMBER].
   * A partial reveal only means something if it narrows the space of lines you must choose between.
   *
   * ✅ SO THE PARTIAL IS THE **ORDER**, WHICH IS ALSO THE THING THIS DESIGN IS ABOUT. DESIGN §3:
   * *"that scarcity is what makes ORDER a decision rather than a formality"*. With the lantern out
   * you still know WHICH colours are coming; you have lost the SEQUENCE. You must guess among k!
   * orderings — 2 or 6 for the real generator. Thematically exact: in the dark you hear what is
   * coming, not the order it comes in.
   *
   * ⛔⛔ THE FIRST VERSION PUT THE PARTIAL ON THE WRONG BAND, WAS BUILT, MEASURED AND REJECTED.
   * It made LOW the unordered tier (BRIGHT exact / LOW unordered / OUT nothing). Everything about it
   * worked and it was still wrong:
   *   - `_graded_verdict.js`: the unordered tier broke **39%** of locks against a 6% floor, and split
   *     by lock length it landed on the blind prior almost exactly (len 2: 47% vs 50% predicted;
   *     len 3: 17% vs 17%). The mechanic carried real information and the bot was provably not
   *     peeking.
   *   - and the win rate fell **37% -> 6%**, because `_band_occupancy_probe.js` showed BRIGHT is only
   *     **12-14% of the fight** at any threshold. Demoting LOW took exact knowledge from 48% of
   *     rounds to 14%. No value of `flameBrightAt` fixes that: sweeping it 55 -> 25 only trades
   *     BRIGHT against LOW and never touches OUT, which is **52-55% of every fight at every
   *     threshold**.
   *
   * ⭐ THE MEASUREMENT NAMED THE RIGHT BAND, WHICH IS THE ONE THAT WAS ALREADY DEAD. OUT is more
   * than half the fight and it is worth 6% — a stretch with no decision in it. Moving the partial
   * there instead:
   *   BRIGHT, LOW — the exact lock, colours AND order. UNCHANGED from today, so nothing that
   *                 currently works is nerfed.
   *   OUT         — the colours, not the order. 6% -> ~39%.
   * ⇒ the cliff goes from 86%/6% to 86%/39%, and the dead half of the fight becomes a real guess.
   * It also answers the separate open Gate A finding *"at 0 oil there is no route back to light, so
   * the last half of a badly lit ambush has no decision in it"* — there is now a decision in the
   * dark even with no oil at all, and it is the game's own central decision (order).
   *
   * ⛔⛔ AND IT IS SHIPPED **OFF**, ON PURPOSE, AFTER BEING BUILT AND MEASURED. Turning it on is a
   * BALANCE PASS, not a flag flip, and the reason is the deepest thing measured on this game so far:
   *
   *   `_warden_verdict.js --seeds 400`, graded ON, oil margin by fight length:
   *     380: **-15pt** · 420: -7pt · 460: -4pt · 520: -2pt · 580: +1pt · 640/700: +0pt
   *   against graded OFF at 380: +11pt.
   *
   * ⭐ **OIL'S VALUE IS EXACTLY THE VALUE OF THE INFORMATION IT RESTORES.** Relight buys light and
   * nothing else, so the worth of a charge is bounded by the cost of being dark. Graded light exists
   * precisely to REDUCE the cost of being dark — so it necessarily guts oil. The two goals are the
   * same quantity read twice, and no tuning of `oilCharges`, `relightFlame` or `enemyHp` can hold
   * both at once. Measured from both directions now: binary light gives a decisive-ish oil (+11pt)
   * and a dead, decision-free dark half (6% break); graded light gives a real decision in the dark
   * (35%) and an oil charge worth nothing (-15pt).
   *
   * ⇒ THE DESIGN MUST CHOOSE, and the third option is the interesting one: give oil a SECOND JOB
   * that is not informational, so its worth stops being bounded by the darkness it cancels. That is
   * a design decision with real content and it is NOT taken at the end of the session that found it
   * — wing §6b-2 rule 5, and the specific lesson of the warden: a mechanic invented to rescue a
   * number is how scope replaces shipping.
   *
   * ⚠️ ALSO OWED BEFORE IT COULD SHIP: at 380 it takes the 0-oil win rate to **75%**, well past the
   * ~50% the design wants, so `enemyHp` would have to be re-derived (460 reads 39% and is the
   * closest cell measured). Do not turn this on without redoing that.
   *
   * ⚠️ `false` restores the old binary behaviour exactly, and the probes measure both arms. */
  gradedLight: false,
  /* ⛔ WHAT IT TAKES TO RE-LIGHT A LANTERN THAT HAS GONE OUT — see the latch note on `flameState`.
   * Deliberately ABOVE anything timing can pay: 3 perfect presses = 7.5 against ~13 drain a round,
   * so only RELIGHT (+35, and it costs oil) can clear the latch. Set this below `relightFlame` or
   * the remedy stops working; set it below ~8 and the timing dribble re-lights the lantern and the
   * flicker comes straight back. */
  flameRelightAt: 20,
  /* ⭐ THE FLAME YOU BRING IN, not the flame you are given. MEASURED 2026-09-01 (see
   * BALANCE_FINDINGS.md): a fight lasts ~48 s and the lantern burns for 90 s, so starting every
   * encounter at full made it arithmetically impossible for the light to go out — which silently
   * disabled the entire information system and made gate D unmeasurable. On the overworld this is
   * DIEGETIC rather than a knob: you arrive at a fight with whatever you have left from walking. */
  startFlame: 70,

  /* What timing feeds the flame. Perfect play should SUSTAIN it, ordinary play should lose it
   * slowly, and a landed enemy attack should cost more than a round of good play earns. */
  flameOnPerfect: 2.5,
  flameOnGood: 0.94,
  flameOnMiss: 0,
  flameOnEnemyHit: -15,       // ⭐ the coupling that makes power NON-MONOTONIC (DESIGN §4)
  relightFlame: 35,           // what one whole turn buys back
  /* ⛔ OIL IS A CARRIED RESOURCE, AND THIS IS THE DESIGN'S LOAD-BEARING FIX. MEASURED 2026-09-01:
   * with relight unlimited, a competent policy spent an average of 7.5 turns per fight buying the
   * light back and the lantern NEVER went out at a decision point — so the hidden-lock rule, the
   * fail state and the whole non-monotonic power curve of DESIGN §4 were unreachable. A fail state
   * whose remedy is free and infinitely repeatable is not a fail state. Oil comes from the
   * overworld, which is also what finally makes exploration matter to combat. */
  oilCharges: 1,

  /* Damage multipliers by timing quality. A miss still PUSHES THE COLOUR (DESIGN §3) — it just
   * does not brighten and it barely hurts. That is deliberate: it means timing buys LIGHT, i.e.
   * INFORMATION, rather than buying raw damage. Gate D is the test of whether that matters. */
  dmgPerfect: 1.5,
  dmgGood: 1.0,
  dmgMiss: 0.45,

  /* The timing bar (gate C tunes these). One sweep per action. */
  sweepMs: 1200,
  perfectAtMs: 800,           // where in the sweep the target sits
  perfectWindowMs: 55,        // +/- around perfectAtMs
  goodWindowMs: 165,          // +/- around perfectAtMs

  /* Modelled real-time cost of one action and of the enemy phase, so headless play burns the
   * flame at the same rate a human would. thinkMs is deliberately generous. */
  thinkMs: 900,
  enemyPhaseMs: 1200,

  /* The enemy. One type, generated locks (DESIGN §3: "enemy locks are drawn from a generated set
   * per encounter, so no fixed rotation dominates").
   *
   * ⛔ 460 -> 380, AND THE OLD NUMBER WAS NEVER RECONCILED WITH THE LANTERN. MEASURED 2026-09-01
   * (`_ambush_probe.js`, `_ambush_sweep.js`, `_oil_margin.js`, 300 seeds/cell). At 460 the ambush
   * ran a median of 8-10 rounds while the flame comment above sizes the burn for a 5-7 round fight,
   * so the lantern was spent with a THIRD of the enemy still standing and the rest of every fight
   * was played blind. Gate A's human finding — *"the pressure arrives after the fight is decided"* —
   * is that mismatch seen from the player's chair.
   *
   * ⛔ THE "+27 POINTS" FIGURE THAT USED TO SIT HERE IS FALSE AND IS WITHDRAWN. It read: *"oil moves
   * the win rate by +27 points (51% at 0 oil, 78% at 1) ... 51% at zero oil means walking into an
   * ambush on a spent lantern is a coin flip"*. RE-MEASURED 2026-09-01 on the SHIPPED config,
   * `node _warden_verdict.js --seeds 800`, hp 380, warden ON: **35% at 0 oil, 46% at 1, margin
   * +11pt**. Nothing in the design moved to make that figure stale by accident — it was measured
   * against an EARLIER combat.js (before `enemyHardens`, and before `planForLock` returned the BEST
   * breaking line rather than the first), and a figure carried across a codebase change is exactly
   * the stale-number defect master §2b records for listings. ⇒ re-derive it, never quote it.
   *
   * ⭐ 380 IS STILL THE RIGHT NUMBER, ON THE TWO MEASUREMENTS THAT SURVIVED:
   *   - the blackout lands at **46% of the enemy's health gone** (target 40-55%: it has to arrive
   *     while the fight is still live, which is the whole of finding F1);
   *   - 380 is the SHORTEST fight length at which the oil margin is positive at all (360 reads
   *     -1pt, 340 reads -9pt). §6b-2 rule 4 — "a fail state whose remedy is free is not a fail
   *     state" — needs a MARGIN, not a pass (§6b-2 rule 1).
   *
   * ⚠️ AND THE HONEST RESIDUE, STATED AGAINST INTEREST: +11pt is still BELOW this design's own
   * +15pt bar, and the 0-oil win rate is 35% rather than the coin flip the old comment claimed.
   * MEASURED across four fight lengths and both warden arms, the two goals are in STRUCTURAL
   * tension and `enemyHp` cannot buy both: 360 gives a coin-flip 0-oil fight (53%) and NO margin
   * (-1pt); 400 gives the margin (+15pt) and a 0-oil fight that is nearly unwinnable (20%). That is
   * a real open design problem and it is NOT the warden's doing — see `enemyHardens` below.
   *
   * ⛔ DO NOT TUNE DOWN TOWARD A COMFORTABLE WIN RATE. MEASURED 2026-09-01, 800 seeds: at 360 and
   * below the oil margin is **NEGATIVE** (-1pt at 360, -9pt at 340) — the fight is short enough that
   * spending a turn on relight costs more than the light is worth, and the carried resource this
   * whole design rests on becomes decoration. A "kinder" number deletes the mechanic. ⚠️ The old
   * wording said "at 340 and below" and "-1 to -4 points"; the true boundary is one cell higher and
   * the hole is deeper than that.
   *
   * ⚠️ THE HONEST RESIDUE: the median fight is **8 rounds**, one over the 5-7 the flame comment
   * assumes. That comment's estimate was made when the fight was believed to be 5-7 and it actually
   * ran 8-10, so 8 is the measured truth and the estimate is the stale half. Raising the burn to
   * "fix" it was measured and REJECTED: at 42000 ms the blackout moves to 90% decided and 100% win,
   * i.e. straight back to the decoration F1 named. */
  enemyHp: 380,
  enemyDamage: 40,

  stackSize: 3,
  maxRounds: 30,

  /* ⭐ THE WARDEN — DESIGN §9, and it is the fix for Gate A finding 4 ("twelve rounds of the same
   * three moves"). At the END of each round the enemy hardens against the colour left on TOP of the
   * stack; while that holds, abilities of that colour do `dmgHardened` of their damage.
   *
   * ⛔ WHY THIS AND NOT "ADD A FOURTH ABILITY". MEASURED 2026-09-01 (`_variety_probe.js`,
   * `_blind_variety_probe.js`): the PUZZLE already varies — a party meets a median of 7 distinct
   * locks in an 8-round fight — while the ANSWER collapses to 5, and it is NOT the blackout doing it
   * (variety rate LIT 75% vs BLIND 67%, against a 15-point bar set before the run). The cause is
   * arithmetic: 3 characters x 2 abilities is six actions, three are spent per round, and `Strike`
   * is simply the best EMBER every single round. More abilities widen the menu without making any
   * round DIFFER FROM THE LAST ONE. This makes the optimal line depend on the previous round, which
   * is the only thing that can break a repeating cycle by construction.
   *
   * ⚠️ It never blocks a colour PUSH — only damage is reduced — so it can never make a lock
   * unsatisfiable (§6b-8, NO-UNBREAKABLE-STATE). And it is OFF for the authored teachers, which
   * exist to isolate one variable each (§6b-6 rule 4). */
  enemyHardens: true,
  /* ⭐⭐ SETTLED 2026-09-01: THE WARDEN SHIPS, AND THE "TRADE" IT WAS HELD UP FOR DOES NOT EXIST.
   *
   * ⛔ WHAT THIS SECTION USED TO SAY, AND WHY IT WAS WRONG. The session that built the warden
   * recorded that it "cost" the oil margin (+27pt -> +11pt) and handed a three-route decision
   * (ship / rescue with a new mechanic / revert) to the operator, unresolved. That comparison was
   * NOT CONTROLLED: the +27pt arm was measured on an earlier combat.js, and the SAME session also
   * rewrote both player models (`planForLock` first-breaking-line -> best-breaking-line, and the
   * damage fallback taught to scale by hardening). A stronger planner moves the win rate in both
   * arms. The whole difference was then attributed to the one change that happened to be in hand.
   *
   * ✅ MEASURED PROPERLY — one codebase, one run, ONLY this flag flipped
   * (`node _warden_verdict.js --seeds 800`, 300-seed run agrees):
   *
   *      hp   warden off            warden ON
   *      340  -14pt margin          -9pt        run med 3 worst 6 -> med 1 worst 4
   *      360  -13pt                 -1pt        blind variety ~49% -> 100%
   *      380   -7pt                +11pt        distinct action sets 4-5 -> 6-7
   *      400   +2pt                +15pt
   *
   * ⇒ the warden IMPROVES the oil margin in EVERY cell measured, by 5 to 18 points, WHILE fixing
   * Gate A finding 4. There is no trade to make and nothing to escalate. ⚠️ The reason is worth
   * keeping: hardening pushes the party off its best ability, which lengthens the fight, and a
   * longer fight is exactly the condition under which a relight repays the turn it costs.
   *
   * ⭐ THE REUSABLE LESSON, and it is master §2b's shape in a design costume: a before/after taken
   * across two codebases is not a measurement of the change you made. Flip ONE flag in ONE run.
   *
   * ⚠️ Still open, and NOT caused by this flag (the off arm is worse on every row): +11pt is under
   * the +15pt bar. See the `enemyHp` note above for the structural tension.
   *
   * ⚠️ 0.5 rather than 0.7, and the reason is NOT that it measured much better — it barely differs
   * (oil margin +11pt vs +9pt, win rate 35% vs 36%, 250 seeds). That near-identity is itself the
   * finding: an adapted planner AVOIDS the hardened colour, so it rarely pays the penalty at all,
   * and the mechanic's real cost is being pushed off your best ability rather than the multiplier
   * on it. ⇒ the number is chosen for LEGIBILITY — "half damage" is a rule a player can hold in
   * their head, "70%" is not — and tuning it is not a lever on balance. */
  dmgHardened: 0.5,

  /* ================================================================================================
   * THE BESTIARY HOOKS — added 2026-09-02. EVERY DEFAULT BELOW REPRODUCES THE PRE-BESTIARY MODEL
   * EXACTLY, so every number measured before today still describes the same fight.
   * ================================================================================================
   *
   * ⛔ WHY THESE AND NOT `enemyHp` / `enemyDamage`. The slice owes eight enemy types and two bosses.
   * With only HP and damage to vary, ten enemies are ONE enemy with ten health bars — which is
   * precisely the "everything is the same shape" failure the operator named on 2026-08-31 (§0a-2),
   * arriving inside a single game instead of across a shelf. Each hook below changes WHICH DECISION
   * the player is making, and `bestiary_gates.js` refuses any pair of creatures a bot cannot tell
   * apart (wing §6d-16: distinct names are not distinct pictures — here, distinct stats are not
   * distinct fights).
   */

  /* The shape of the telegraph this creature emits. See `generateLocks`. null = the old generator. */
  lockShape: null,

  /* ⭐ THE LAMP-EATER AXIS. Flame lost at the END of every round, whether or not the lock landed.
   * The lantern is this game's information channel, so a creature that eats it is not "more damage"
   * — it is a SHORTER SIGHTED WINDOW, i.e. the fight becomes a race between its health bar and your
   * ability to keep seeing the puzzle. 0 = off, which is every creature written before today. */
  flameDrainPerRound: 0,

  /* ⭐ THE SNUFFER AXIS. What a LANDED lock costs the lantern, if this creature overrides it. A
   * creature with a small `enemyDamage` and a large drain here barely wounds you and nearly blinds
   * you — the inverse of the ordinary threat, and a fight you lose slowly and by accident rather
   * than quickly and visibly. null = use `flameOnEnemyHit`, i.e. unchanged. */
  enemyHitFlame: null,

  /* ⭐ THE DEATH-SPIRAL AXIS. Who a landed lock hits.
   *    'random'  — uniform over the living party. Every creature before today.
   *    'weakest' — the lowest absolute HP. Concentrates damage, so the party loses a MEMBER rather
   *                than losing health evenly, and losing a member is the state wing §6b-8 is about.
   * ⛔ 'weakest' IS ONLY LEGAL ON A CREATURE WHOSE EVERY EMITTABLE LOCK SURVIVES A DEATH. That is
   * not a comment, it is `bestiary_gates.js/NO-UNBREAKABLE-STATE`, quantified over `lockSpace()`. */
  targetPolicy: 'random',

  /* ⭐ THE SPIRAL'S TEETH, added 2026-09-02. `targetPolicy` alone decides WHO is hit; this decides
   * what being hurt COSTS. A landed blow deals `enemyDamage * (1 + woundedScaling * missingFrac)`,
   * where `missingFrac` is how much of the target's maximum health is already gone. 0 = off, i.e.
   * every creature written before today.
   * ⛔ IT WAS ADDED BECAUSE THE AXIS IT SERVES WAS MEASURED AS NEARLY ABSENT, not to make a creature
   * harder: 'weakest' vs 'random' moved the outcome by +15pt on one arm and +0pt on two
   * (`_axis_witness.js --controls`, n=40), against +73pt or better for every other axis.
   *
   * ⛔⛔ IT IS CONTINUOUS, AND THE THRESHOLD VERSION THAT CAME FIRST WAS MEASURED **INERT AT EVERY
   * DAMAGE VALUE TRIED** — which is the more useful half of this note. The first design was "a
   * target at or below half health takes 1.75x". Measured (`_spider_parity.js`, 60 seeds):
   *     damage 30, amplifier on vs off -> planner 43% vs 43%      (no change)
   *     damage 16, amplifier on vs off -> planner 100% vs 100%    (no change)
   * Two different reasons, and together they close the whole range. HIGH damage: a wounded target
   * dies to a NORMAL blow, so every point of bonus is overkill. LOW damage: the amplifier only
   * changes an outcome when the target's hp lies in `(d, bonus*d]`, a window of width `0.75d`,
   * while repeated hits step the target's hp down the ladder `max - k*d` in strides of exactly `d`
   * — so a window narrower than the stride can, and did, fall between every rung.
   * ⭐ A THRESHOLD MECHANIC IS AT THE MERCY OF AN ARITHMETIC LADDER IT DOES NOT CONTROL. Scaling
   * with missing health has no window and no rungs: every blow on a hurt target lands harder than
   * the last, which is also what the word "spiral" actually describes. */
  woundedScaling: 0,

  /* ⭐⭐ PARTIAL LIGHT — how much a PARTIALLY held telegraph blunts the blow. 0 = off, and off is
   * byte-for-byte every fight this project measured before 2026-09-02. See the long note at the
   * point of use in `_enemyPhase`: the sweep that produced this field found that NO stat block in
   * 144 can hold a learner and a planner apart, because breaking the lock is the game's only
   * defence and it is a step function.
   * ⚠️ A value of 1 gives FULL proportional relief (1 of 2 held = half damage). It can never reach
   * zero damage — `Math.max(1, ...)` — because a partial hold that is as good as a break deletes
   * the ordering rule this game is built on. */
  partialRelief: 0,

  /* ⭐⭐ THE BURIED BLOW — how much a blow is blunted when the sequence STOOD COMPLETE during the
   * round and was then buried by a later action. See the long note at the point of use in
   * `_enemyPhase` for why it exists; this note is about the NUMBER.
   *
   * ⛔ IT IS A GLOBAL RULE, NOT A PER-CREATURE PATCH, AND THAT WAS MEASURED RATHER THAN PREFERRED.
   * A rule that appears and disappears between creatures is a rule nobody can learn, and the cliff
   * was measured on ALL EIGHT non-teachers, not on one. The cost of switching it on everywhere is a
   * table, `_onramp_blast.js --buried 0.7 --seeds 120`, every creature at its zone-median arrival
   * against the project's own pre-registered planner window of 45-80%:
   *
   *     creature      planner OFF -> ON        learner OFF -> ON
   *     gravebound      63.3 -> 66.7  (+3.3)     0.0 -> 20.8  (+20.8)
   *     direbat         62.5 -> 70.0  (+7.5)     3.3 -> 35.0  (+31.7)
   *     ironknight      77.5 -> 78.3  (+0.8)     1.7 -> 29.2  (+27.5)
   *     censer          65.0 -> 75.0 (+10.0)     0.0 ->  1.7   (+1.7)
   *     ossuary         66.7 -> 75.8  (+9.2)     6.7 ->  9.2   (+2.5)
   *     tombspider      42.5 -> 44.2  (+1.7)     0.0 -> 10.0  (+10.0)
   *     hierophant      63.3 -> 65.8  (+2.5)     3.3 -> 13.3  (+10.0)
   *     barrowwyrm      47.5 -> 66.7 (+19.2)     0.0 -> 11.7  (+11.7)
   *
   * ⇒ NO creature leaves the window, and the shape that falls out is the one the slice wants: the
   *   two creatures a player meets FIRST move from unwinnable to ~21-35% for a beginner, while the
   *   barrow stays hard. That comes from the creatures' own lock shapes, not from a difficulty flag.
   *
   * ⚠️ 0.7 AND NOT MORE, and the reason is the free-win clause rather than taste. Swept at n=120 on
   * gravebound: 0.70 -> learner 20.8% with 0.0% of its wins taking ZERO locks; 0.75 -> 21.7% / 3.8%;
   * 0.80 -> 23.3% / 7.1%. Every step buys ~1 point of learner win rate and spends the guarantee that
   * a win is EARNED BY BREAKING SOMETHING — and an encounter that provokes the intended error and
   * then hands out a win teaches that the lock is optional, which is worse than teaching nothing.
   *
   * ⚠️ STATED AGAINST INTEREST, three of them. (1) gravebound lands at 20.8%, the very bottom of the
   * pre-registered 20-60% learner window, and n=120 pins that to about +/-7 points — so it is inside
   * the bar but not comfortably. (2) The final boss's planner rate moves +19.2 (47.5 -> 66.7): that
   * is toward the CENTRE of its window from near the floor, which is an improvement by the project's
   * own standard, but the climax IS easier for a competent player than it was. (3) `censer` barely
   * moves (+1.7), so the rule does not fix the on-ramp everywhere — it fixes it where the player
   * arrives, which is what an on-ramp is for, and the residual is recorded rather than smoothed.
   *
   * ⚠️ Capped at 0.95 at the point of use: a buried round must always be strictly worse than a
   * broken one, or the ordering rule this whole game is built on stops being worth learning. */
  buriedRelief: 0.7,

  /* ⛔⛔ WHO THE PARTY'S ONLY HEAL REACHES — 'lowest' (the lowest-hp living ally) or 'self'.
   * ⛔ THIS WAS `self` FOR THE WHOLE LIFE OF THE PROTOTYPE AND NOBODY EVER CHOSE IT. `act()` read
   * `if (a.heal) c.hp += heal` where `c` is the ACTOR, because that is the shortest line that
   * compiles — master §2b, *"an unconfigured default is not a decision"*. Hush is the only heal in
   * the game and it belongs to Oren, who has the LARGEST maximum health in the party (48 vs 45/40),
   * so under `targetPolicy: 'weakest'` he is the character least often in danger. A self-heal on
   * him is therefore the one heal that can almost never be aimed at the problem — and, worse, it
   * makes the healthiest character healthier, which under 'weakest' targeting PUSHES the enemy onto
   * somebody else. It was anti-counterplay.
   * ⭐ MEASURED 2026-09-02 (`_heal_probe.js`, 7 assertions + a party-targeted self-test that must
   * invert every verdict): Wren at 12/40 with Oren at full, Oren casts Hush -> **Wren's delta is
   * 0**; the control where Oren himself is hurt -> **+14**. So the heal worked exactly as written
   * and exactly not as designed.
   * ⚠️ IT CONTRADICTED THREE PLACES IN THE PRODUCT'S OWN TEXT, which is the §2 half of this: the
   * tombspider's `teaches` line is *"Heal the one who is falling"*, its cfg note claims *"Hush (+9)
   * lifts a character from just under half to comfortably over it, so the heal is the counterplay"*,
   * and this file's own colour table calls PALE *"a damage-vs-healing decision"*. None of those was
   * true of the code underneath them.
   * ⭐ 'lowest' AUTO-TARGETS AND THAT IS DELIBERATE, not a shortcut. Letting the player pick a
   * target would add a second menu to every Hush, and wing §0a-2's flow directive bans exactly that
   * shape (*"pick options and click go"*). The decision stays the interesting one — whether to
   * spend Oren's turn and a PALE stack slot on the heal at all — and costs no extra input. */
  healTargets: 'lowest',

  /* ⭐ THE PLATED AXIS. A colour this creature is hardened against for the WHOLE fight, from round
   * one, regardless of what you push. Setting it to 'EMBER' halves Sable.strike — the party's single
   * best ability — permanently, so the damage plan that works on everything else is the wrong plan
   * here and the player has to find another one. It never blocks a colour PUSH, so it can never make
   * a lock unsatisfiable (the same reason the warden is safe). null = off. */
  hardenedFixed: null,

  /* ⭐ THE ENCIRCLING AXIS. How many recent colours the warden holds at once. 1 = the shipped
   * warden. 2 = it remembers the last two DISTINCT colours it was struck with, so half the palette
   * is blunted at any moment and the party is pushed around the whole colour wheel instead of
   * sidestepping into one comfortable alternative. Only read when `enemyHardens` is true. */
  hardenCount: 1,

  /* ⛔⛔ THE DEATH PLATEAU — see `_beginRound`. When the survivors can break NOTHING in the fight's
   * lock rotation, does the game FABRICATE a lock they can break?
   *   true  — the behaviour shipped until 2026-09-02. It made a one-character party INVULNERABLE.
   *   false — the fight presents the lock it generated. A party that cannot answer takes the hit.
   *
   * ⭐ SHIPPED **false** 2026-09-02, and the evidence is not a preference:
   *   - `_death_plateau.js` (self-test 5/5): at one survivor, **100% of telegraphs collapsed to
   *     length 1 and 95-99% of them broke**, against 7.1% available by accident.
   *   - `_plateau_verdict.js` (self-test 5/5, 48 seeds x 3 subjects x 3 policies): with `true`, a
   *     lock-blind party **LOSES 0 of 144 fights**. There was no fail state for a party ignoring the
   *     game's entire system. With `false` it loses 144 of 144.
   *   - `bestiary_gates.js` had ALREADY encoded the requirement and was red on it:
   *     `thinking-beats-not-thinking` failed on **all seven** non-teacher creatures (hierophant
   *     -23pt, i.e. planning was actively PUNISHED) and `barrowwyrm/a-loss-is-a-loss` failed with
   *     50% of its defeats arriving on the round counter.
   *
   * ⚠️ AND THE HONEST COST, MEASURED, NOT GUESSED: the plateau was propping up every weak line in
   * the game. With it gone, `chaseLock` — the model of a player who has NOT grasped that the lock
   * must land on the round's LAST actions — wins almost nothing at any lethality that keeps the
   * system meaningful. The design's answer is E1/E2, the authored teachers that pin one lock and
   * cannot kill. If they fail to teach, this game is a wall (see `_lethality_sweep.js`).
   * ⚠️ EVERY BALANCE NUMBER TAKEN BEFORE TODAY WAS TAKEN ON TOP OF THIS BUG. Re-derive; do not
   * quote. `enemyDamage` below is the first of them. */
  fabricateBreakableLock: false,
};

/* ------------------------------------------------------------------------------------------------
 * LOCK GENERATION + THE EXHAUSTIVE SATISFIABILITY PROOF
 * ---------------------------------------------------------------------------------------------- */

/* Every ordered sequence of colours the party can actually PUSH in one round, given that each
 * character acts exactly once and may instead spend the turn on relight (pushing nothing).
 * Computed once, by brute force over the real roster.
 *
 * ⭐ `chars` PARAMETERISED 2026-09-02, DEFAULTING TO THE FULL ROSTER — the default is byte-identical
 * behaviour and `boss_gates.js` asserts that it reproduces `REACHABLE` exactly.
 * ⛔ WHY IT HAD TO MOVE: this function is the domain of the ONLY exhaustive proof in the game, and it
 * quantified over a party that never loses anybody. `generateLocks` then refuses to emit an
 * "unbreakable" lock — but breakable BY A FULL PARTY. Wing §6b-8 is a whole section about that exact
 * blind spot, written after a death made a repeated lock permanently unbreakable in a live build,
 * and its rule 1 is "EXHAUSTIVE is only as good as its DOMAIN: ask what states the fight can reach,
 * then quantify over those." A boss at 400-490 HP is precisely where a death is reachable, so the
 * subset case is not hypothetical. Passing the survivors in is what lets a gate ask the question. */
function reachableSequences(chars = ROSTER) {
  const out = new Set();
  const perm = (arr) => {
    if (arr.length <= 1) return [arr];
    const res = [];
    for (let i = 0; i < arr.length; i++) {
      const rest = arr.slice(0, i).concat(arr.slice(i + 1));
      for (const p of perm(rest)) res.push([arr[i], ...p]);
    }
    return res;
  };
  for (const order of perm(chars)) {
    /* each character contributes one of its abilities' colours, or nothing (relight) */
    const choices = order.map((c) => [...c.abilities.map((a) => a.colour), null]);
    const walk = (i, acc) => {
      if (i === choices.length) {
        const pushed = acc.filter(Boolean);
        /* the stack only keeps the last `stackSize`, so record every suffix that could be read */
        for (let n = 1; n <= pushed.length; n++) out.add(pushed.slice(pushed.length - n).join('>'));
        return;
      }
      for (const c of choices[i]) walk(i + 1, acc.concat([c]));
    };
    walk(0, []);
  }
  return out;
}
const REACHABLE = reachableSequences();

/** A lock is BREAKABLE if the party can, in one round, end with exactly that colour sequence on top. */
function lockIsSatisfiable(lock) {
  return REACHABLE.has(lock.join('>'));
}

/**
 * Generate one encounter's lock set. Locks are length 2 or 3.
 * ⛔ Refuses to emit a lock the party cannot break — an unbreakable telegraph is not difficulty,
 * it is a bug that reads as difficulty, and it would silently corrupt gate B's result by making
 * every rotation fail for a reason that has nothing to do with rotations.
 *
 * ⭐ `shape` IS THE BESTIARY'S DEEPEST AXIS AND IT COSTS NOTHING (bestiary.js, 2026-09-02). Every
 * field is OPTIONAL and every default reproduces the pre-bestiary generator exactly, so no existing
 * measurement moves:
 *    pool   — which colours this creature may demand. The party's colour sources are UNEVEN
 *             (EMBER x2, PALE x2, AZURE x1, VERDANT x1), so a pool of {AZURE, VERDANT} conscripts
 *             Wren AND Oren every single round and leaves Sable free, while {EMBER, PALE} leaves
 *             the party a genuine choice of who serves. That is a different FIGHT, not a different
 *             number — which is the whole difference between a bestiary and ten stat blocks.
 *    lenMin/lenMax — 2 constrains two characters, 3 constrains all three.
 *    len3Chance    — as before, the mix.
 */
function generateLocks(rng, count, shape = {}) {
  const pool = shape.pool && shape.pool.length ? shape.pool : COLOURS;
  for (const c of pool) if (!COLOURS.includes(c)) throw new Error(`unknown colour in lock pool: ${c}`);
  const lenMin = shape.lenMin === undefined ? 2 : shape.lenMin;
  const lenMax = shape.lenMax === undefined ? 3 : shape.lenMax;
  if (lenMin < 1 || lenMax < lenMin) throw new Error(`bad lock length range ${lenMin}..${lenMax}`);
  const len3Chance = shape.len3Chance === undefined ? 0.38 : shape.len3Chance;

  /* ⛔ REFUSE AN UNSATISFIABLE SHAPE AT CONSTRUCTION, NOT AFTER 10,000 SPINS. A pool of {AZURE} at
   * length 2 asks for AZURE>AZURE, which has ONE source for TWO slots and can never be emitted — the
   * old loop would spin to its guard and throw a message about the GENERATOR when the defect is in
   * the CONTENT. Enumerate the shape's whole space up front and say which shape is impossible. */
  const space = [];
  const build = (acc) => {
    if (acc.length >= lenMin && acc.length <= lenMax && lockIsSatisfiable(acc)) space.push(acc.slice());
    if (acc.length >= lenMax) return;
    for (const c of pool) build(acc.concat([c]));
  };
  build([]);
  if (space.length === 0) {
    throw new Error(`lock shape is UNSATISFIABLE: pool [${pool.join(',')}] len ${lenMin}..${lenMax} `
      + 'yields no lock this roster can break');
  }

  const locks = [];
  let guard = 0;
  while (locks.length < count) {
    if (++guard > 10000) throw new Error('lock generator could not fill the set');
    const len = lenMin === lenMax ? lenMin : (rng() < (1 - len3Chance) ? lenMin : lenMax);
    const lock = [];
    for (let i = 0; i < len; i++) lock.push(pool[Math.floor(rng() * pool.length)]);
    if (!lockIsSatisfiable(lock)) continue;
    locks.push(lock);
  }
  return locks;
}

/**
 * Every lock a given shape can ever emit. The bestiary's NO-UNBREAKABLE-STATE gate quantifies over
 * THIS, not over one sampled lock set — wing §6b-8 rule 1: "exhaustive is only as good as its
 * domain", and a 12-lock sample is not the domain of a generator.
 */
function lockSpace(shape = {}) {
  const pool = shape.pool && shape.pool.length ? shape.pool : COLOURS;
  const lenMin = shape.lenMin === undefined ? 2 : shape.lenMin;
  const lenMax = shape.lenMax === undefined ? 3 : shape.lenMax;
  const out = [];
  const build = (acc) => {
    if (acc.length >= lenMin && acc.length <= lenMax && lockIsSatisfiable(acc)) out.push(acc.slice());
    if (acc.length >= lenMax) return;
    for (const c of pool) build(acc.concat([c]));
  };
  build([]);
  return out;
}

/* ------------------------------------------------------------------------------------------------
 * THE COMBAT OBJECT
 * ---------------------------------------------------------------------------------------------- */
class Combat {
  constructor(opts = {}) {
    this.cfg = { ...DEFAULTS, ...(opts.cfg || {}) };
    this.seed = opts.seed >>> 0;
    this.rng = createRNG(this.seed);

    /* Gate D's independent variable. When false, the flame's OUT state stops hiding locks, which
     * turns the lantern into a decorative meter — exactly the null hypothesis §8 D wants to reject. */
    this.locksHideWhenDark = opts.locksHideWhenDark !== false;

    /* ⛔ WHO OWNS THE CLOCK. The bots have no real time, so `act()` advances it by the MODELLED cost
     * of the action (sweep + think). The browser DOES have real time and ticks every frame from
     * `performance.now()` deltas. If both did it the flame would burn twice as fast in the UI as in
     * every measurement this design was tuned on — the numbers in BALANCE_FINDINGS.md would silently
     * describe a different game from the one a human plays. Exactly one of them advances time. */
    this.externalClock = opts.externalClock === true;

    this.party = ROSTER.map((c) => ({
      id: c.id, name: c.name, hp: c.maxHp, maxHp: c.maxHp, abilities: c.abilities, acted: false,
    }));
    /* `hardenedTo` is null in round 1 — nothing has been pushed yet, so there is nothing to have
     * learned. It is set at the END of each round from the top of the stack. */
    /* ⚠️ AN ARRAY SINCE 2026-09-02 (bestiary `hardenCount`), oldest first. Every consumer in the
     * tree reads the `hardenedColour`/`hardenedColours` getters rather than this field — checked by
     * grep before the change — so widening it moved nothing. Do not read it directly. */
    this.enemy = { hp: this.cfg.enemyHp, maxHp: this.cfg.enemyHp, hardenedTo: [] };

    /* ⛔ `forcedLock` EXISTS SO GATE B'S CONTROL CAN FIRE, AND IT IS NOT A GAMEPLAY OPTION.
     * Gate B asks "is there a fixed rotation that beats everything?". A control for that question
     * needs a game where the answer is YES — otherwise a green gate B is indistinguishable from a
     * gate that cannot detect anything. The first control tried to build one by reusing a single
     * SEED, which does not work: one seed still generates twelve DIFFERENT locks that cycle, so no
     * rotation could match them all and the control reported 0/60 exactly like the healthy case.
     * Forcing every telegraph to one lock is the real degenerate design. */
    /* ⭐ AUTHORED LOCKS (encounters.js). The slice's first two encounters are hand-built teachers
     * and hand a fixed list in here; everything else generates. ⛔ An authored lock gets the SAME
     * exhaustive satisfiability refusal the generator applies to itself — an unbreakable telegraph
     * is not difficulty, it is a bug that reads as difficulty, and hand-writing one is the easiest
     * way in the codebase to ship it. Refusing loudly at construction is the whole guard. */
    /* ⛔ AND `forcedLock` GETS THE SAME REFUSAL, WHICH IT DID NOT UNTIL 2026-09-01. It took the
     * branch below WITHOUT passing through this guard, so the one option in the file that hands a
     * lock straight to the enemy was the one option nothing validated. MEASURED: `_variety_probe.js`
     * counted the satisfiable puzzle space by constructing a Combat per candidate lock and catching
     * the throw — and got **80 of 80 satisfiable, including `AZURE>AZURE`**, which `encounter_gates`
     * separately proves is unbreakable (one source, two slots). A silent false GREEN from the guard
     * that exists to make exactly that impossible.
     * ⚠️ Closing it costs nothing: the only real caller is gate B's control at `['AZURE','EMBER']`,
     * which is satisfiable and still passes. The degenerate game that control needs is built by
     * REPEATING one lock, not by using an impossible one.
     * ⭐ Sibling of master §2b's "a check that only runs on the failing side of another check covers
     * half a field": here the guard covered the authored path and not the forced one, and a
     * consumer reasonably assumed "locks are validated" meant all of them. */
    const authored = [];
    if (opts.locks) {
      if (!Array.isArray(opts.locks) || opts.locks.length === 0) {
        throw new Error('opts.locks must be a non-empty array of locks');
      }
      authored.push(...opts.locks);
    }
    if (opts.forcedLock) authored.push(opts.forcedLock);
    for (const l of authored) {
      if (!Array.isArray(l) || l.length === 0) throw new Error(`malformed authored lock: ${JSON.stringify(l)}`);
      for (const col of l) if (!COLOURS.includes(col)) throw new Error(`unknown colour in authored lock: ${col}`);
      if (!lockIsSatisfiable(l)) throw new Error(`authored lock is UNBREAKABLE by this roster: ${l.join('>')}`);
    }
    this.locks = opts.forcedLock ? [opts.forcedLock]
      : opts.locks ? opts.locks.map((l) => l.slice())
        : generateLocks(this.rng, 12, this.cfg.lockShape || {});
    this.lockIndex = 0;
    /* ⭐ WHETHER THE PUZZLE WAS CHOSEN BY A PERSON. Read by `_beginRound`'s §6b-8 guard: an authored
     * lock is a deliberate teaching artefact and must never be re-rolled underneath the player,
     * while a generated one carries no such intent and must never be impossible. Derived from the
     * OPTS, not from the shape of `this.locks` — a generated set that happened to hold one entry
     * would otherwise be misread as authored. */
    this._locksAreAuthored = !!(opts.forcedLock || opts.locks);

    this.stack = [];              // index 0 = oldest (bottom), last = newest (top)
    /* Set BEFORE the flame, because `_setFlame` reads it. A fight that starts at zero starts
     * latched — which is correct: you walked in with a dead lantern. */
    this._outLatched = false;
    this.flame = 0;
    this._setFlame(this.cfg.startFlame);
    this.oil = this.cfg.oilCharges;
    this.timeMs = 0;
    this.round = 0;
    this.log = [];
    this.over = false;
    this.result = null;
    this.telegraph = null;
    this.stats = { perfect: 0, good: 0, miss: 0, locksBroken: 0, locksLanded: 0, relights: 0 };

    this._beginRound();
  }

  /* -- flame -------------------------------------------------------------------------------- */

  /* ⛔ THE LANTERN LATCHES OUT, AND THIS IS A GATE-A FIX, NOT A POLISH ITEM. MEASURED 2026-09-01
   * (`_ambush_probe.js`, 200 seeds): with a memoryless `flameState` the ambush read a MEDIAN OF 11
   * flameState CHANGES per fight, worst 15. The trace shows why in one look — from round 4 the
   * flame is pinned between 0.0 and 2.5, so a single `perfect` press (+2.5) lifts it off zero and
   * the very next drain puts it back:
   *
   *     R 4  flame 0.0  OUT      R 5  flame 2.5  LOW      R 6  flame 2.5  LOW
   *          flame 2.5  LOW           flame 0.0  OUT           flame 0.0  OUT
   *
   * The lantern going out is this game's ENTIRE premise, and it was flickering on and off every
   * other action for the last two thirds of every fight. A player cannot plan around a telegraph
   * that returns before they can act on it, and `visibleLock()` is gated on exactly this state —
   * so the information channel was strobing, not closing.
   *
   * ⭐ AND IT IS THE DIEGETIC ANSWER, WHICH IS WHY IT IS THE RIGHT ONE RATHER THAN A COSMETIC
   * SMOOTHING WORKAROUND. (The obvious word for that is banned in shipped source by preflight's
   * `src-clean` gate, which matches the TOKEN and cannot tell a marker from prose ABOUT one — a
   * coarse checker, and the one-word rewrite is cheaper and safer than loosening a factory-wide
   * gate for one comment. 2026-09-03.)
   * A lantern that has GONE OUT is not re-lit by swinging your sword well. It is re-lit by
   * spending oil — which is the carried resource §6b-2 rule 4 exists to protect, and which was
   * being quietly bypassed by the timing dribble. `flameRelightAt` is set ABOVE what timing can
   * reach: three perfect presses buy 7.5 against ~13 of drain per round, so the flame can never
   * climb back to 20 on timing alone, and RELIGHT (+35) always clears it in one action.
   *
   * ⚠️ The latch is maintained where the flame CHANGES, never inside the getter. A getter that
   * mutates would make the state depend on how often it happened to be read, so a UI that polls
   * every frame and a bot that polls once per action would see different games — the same class of
   * defect as the two-clocks bug this file already carries an `externalClock` flag for.
   */
  get flameState() {
    /* ⚠️ BOTH TERMS, and the first is not redundant. `_setFlame` maintains the latch, but tests and
     * fixtures legitimately poke `flame` straight (selftest §5 sets `c.flame = 0` to ask whether a
     * dark lantern hides the lock). Deriving OUT from the latch ALONE made that read `LOW` — a
     * checker and the thing it checks disagreeing because the state moved behind the field. Keep
     * the invariant true of the FIELD, and let the latch add only the hysteresis on top. */
    if (this.flame <= 0 || this._outLatched) return 'OUT';
    return this.flame >= this.cfg.flameBrightAt ? 'BRIGHT' : 'LOW';
  }

  /** The ONE place `flame` is assigned after construction, so the latch cannot be bypassed. */
  _setFlame(v) {
    this.flame = Math.max(0, Math.min(this.cfg.flameMax, v));
    if (this.flame <= 0) this._outLatched = true;
    else if (this._outLatched && this.flame >= this.cfg.flameRelightAt) this._outLatched = false;
  }

  /** ⛔ The ONE clock. Browser feeds measured elapsed ms; bots feed modelled action cost. */
  tick(dtMs) {
    if (this.over || dtMs <= 0) return;
    this.timeMs += dtMs;
    const drain = this.cfg.flameMax * (dtMs / this.cfg.flameBurnMsToEmpty);
    this._setFlame(this.flame - drain);
  }

  _feedFlame(amount) {
    this._setFlame(this.flame + amount);
  }

  /* -- the warden ---------------------------------------------------------------------------- */

  /** The colour the enemy currently resists, or null. ⚠️ ALWAYS VISIBLE, deliberately: an
   * adaptation the player cannot see is not difficulty, it is a rule they can never learn. It is
   * NOT gated on the lantern — the lantern hides the TELEGRAPH (what the enemy will do), while this
   * is a fact about the enemy's body that you learned by hitting it. */
  get hardenedColour() {
    const all = this.hardenedColours;
    return all.length ? all[all.length - 1] : null;
  }

  /** ⭐ EVERY colour currently resisted, oldest first. The bestiary's PLATED axis (`hardenedFixed`)
   * and ENCIRCLING axis (`hardenCount` > 1) both mean more than one colour can be blunted at once,
   * so the UI and the player models must read a LIST. `hardenedColour` above is kept and now returns
   * the most RECENT of them, because every consumer written before the bestiary reads a single
   * colour and the adaptive one is the one those consumers are reasoning about.
   * ⚠️ `hardenedFixed` is deliberately NOT gated on `enemyHardens`: a plated creature is armoured
   * from round one whatever it has been hit with, which is the whole point of it — a permanent fact
   * about its body rather than a thing it learns. */
  get hardenedColours() {
    const out = [];
    if (this.cfg.hardenedFixed) out.push(this.cfg.hardenedFixed);
    if (this.cfg.enemyHardens) {
      for (const c of this.enemy.hardenedTo || []) if (c && !out.includes(c)) out.push(c);
    }
    return out;
  }

  /** True when `colour` is currently being resisted. */
  hardenedAgainst(colour) {
    return !!(colour && this.hardenedColours.includes(colour));
  }

  /** Damage scale a given colour would land at right now — the ONE place the rule is expressed, so
   * the player models cannot drift from the combat model (§6b-5). */
  damageScaleFor(colour) {
    return this.hardenedAgainst(colour) ? this.cfg.dmgHardened : 1;
  }

  /**
   * What the PLAYER can see of the telegraph — the ONE place the reveal rule is expressed, so no
   * consumer can hold a second copy of it (§6b-5, the same discipline as `damageScaleFor`).
   *
   * Returns { kind, lock, colours }:
   *   kind 'exact'     — `lock` is the real ordered lock.
   *   kind 'unordered' — `colours` is the multiset of colours, SORTED so it leaks no order
   *                      information; `lock` is null. (graded light, LOW)
   *   kind 'none'      — nothing is known.
   *
   * ⛔ `colours` is sorted deliberately. Handing back the lock's own array under a name that implies
   * unorderedness would leak the answer through the array order, and every consumer would silently
   * be playing with full information while the table said otherwise — a green produced by work that
   * never happened (master §2b).
   */
  lockKnowledge() {
    if (!this.telegraph) return { kind: 'none', lock: null, colours: null };
    if (this.locksHideWhenDark && this.flameState === 'OUT') {
      /* ⭐ THE ONE PLACE GRADED LIGHT CHANGES ANYTHING. With it on, the dark keeps the colours and
       * takes the order; with it off, the dark takes everything, which is the original design. */
      return this.cfg.gradedLight
        ? { kind: 'unordered', lock: null, colours: this.telegraph.lock.slice().sort() }
        : { kind: 'none', lock: null, colours: null };
    }
    return { kind: 'exact', lock: this.telegraph.lock, colours: this.telegraph.lock.slice().sort() };
  }

  /** The exact ordered lock, or null. ⚠️ Kept with its original meaning ON PURPOSE: every existing
   * consumer reads it as "the answer", and widening it to sometimes mean "a guess" is how a partial
   * reveal turns into full information nobody notices. Under graded light this returns null at LOW,
   * and `lockKnowledge()` is where the partial lives. */
  visibleLock() {
    const k = this.lockKnowledge();
    return k.kind === 'exact' ? k.lock : null;
  }

  /* -- rounds ------------------------------------------------------------------------------- */
  _beginRound() {
    this.round += 1;
    for (const c of this.party) c.acted = false;
    let lock = this.locks[this.lockIndex % this.locks.length];
    this.lockIndex += 1;

    /* ⛔⛔ THE §6b-8 INVARIANT, ENFORCED WHERE THE PUZZLE IS ACTUALLY HANDED TO THE PLAYER.
     * `generateLocks` already refuses to emit an unbreakable lock — but it runs ONCE, in the
     * constructor, against the FULL roster, and the party's colour sources are uneven (AZURE is
     * Wren's alone, VERDANT is Oren's alone). So the moment somebody dies, locks that were
     * legitimately breakable at construction become impossible, and the game keeps presenting them.
     *
     * MEASURED 2026-09-02 on the two bosses (`boss_gates.js`): losing ONE character made **6-7 of
     * their 14 possible locks unbreakable**, while deaths occurred in 21-22 of 24 competent runs.
     * The party then grinds against a puzzle it cannot solve, with nothing on screen to say so —
     * which is precisely the defect wing §6b-8 was written after, arriving in the slice's climax by
     * a different route (there: a pinned lock plus a death; here: a generated lock plus a death).
     *
     * ⚠️ AUTHORED LOCKS ARE DELIBERATELY EXEMPT. E1/E2 pin ONE lock and repeat it, and re-rolling a
     * teaching puzzle after a failure is exactly what §6b-8 and encounters.js forbid — the player
     * could no longer tell a fixed mistake from a new lock. Those encounters discharge the invariant
     * the OTHER way (they cannot kill: proven by their own `survives-three-failures` claims), so a
     * pinned lock is left exactly as authored even when it becomes unbreakable. */
    if (!this._locksAreAuthored) {
      const live = this.livingParty().map((c) => c.id);
      if (live.length && live.length < this.party.length) {
        const chars = ROSTER.filter((c) => live.includes(c.id));
        const reach = reachableSequences(chars);
        if (!reach.has(lock.join('>'))) {
          /* find the next lock in this fight's OWN sequence that the survivors can still break, so
           * the re-roll stays deterministic and seed-reproducible — never a fresh random draw. */
          const n = this.locks.length;
          let found = null;
          for (let i = 0; i < n; i++) {
            const cand = this.locks[(this.lockIndex + i) % n];
            if (reach.has(cand.join('>'))) { found = cand; break; }
          }
          /* ⛔⛔ THE FABRICATION BRANCH, AND IT WAS THE WORST BUG IN THE GAME. It used to read:
           *
           *     const any = [...reach].map(s => s.split('>')).filter(l => l.length >= 2);
           *     found = any.length ? any[0] : [...reach][0].split('>');
           *
           * on the reasoning "build one that does rather than shipping an impossible round". What it
           * actually built, with ONE character left, was a LENGTH-1 lock — because a single actor
           * pushes a single colour, so `reach` holds no length-2 sequence at all and the fallback
           * takes `[...reach][0]`. Set insertion order is the roster's ability order, whose FIRST
           * entry is each character's STRONGEST ability. ⇒ the guard handed a lone survivor a
           * telegraph broken by the exact move they were already going to make.
           *
           * MEASURED 2026-09-02, `_death_plateau.js` (self-test 5/5, 48 seeds x 2 bosses, lock-blind
           * policy): at one survivor **100% of telegraphs were length 1 and 95-99% of them broke**,
           * against a 7.1% rate available by accident. The enemy therefore stopped landing hits, and
           * across 96 lock-blind boss fights there were **ZERO losses** — Hierophant WIN 43 /
           * TIMEOUT 5, Wyrm TIMEOUT 38 / WIN 10. The game could not be lost once you were losing.
           * ⚠️ And `boss_gates.js/the-barrow-wyrm/lock-blind-loses` was GREEN on that: it counts WINS,
           * and 38 of its 48 "not wins" were a party standing invulnerable until `maxRounds`. A gate
           * certifying a boss is "a real test" was reading a timeout.
           *
           * ⭐ THE NARROW FIX. The guard's real job is the one §6b-8 was written for: never present an
           * impossible lock WHEN A POSSIBLE ONE EXISTS IN THIS FIGHT'S ROTATION. That is the `found`
           * search above and it is untouched. Inventing a lock when the rotation holds none is a
           * different act, and it is the one that deleted the fail state. With `fabricateBreakableLock`
           * false the generated lock is presented as generated: a party that cannot answer takes the
           * hit, which is what losing is.
           * ⚠️ It changes behaviour in exactly ONE state — a party of one, where no length-2 lock is
           * reachable by construction (proved in `_death_plateau.js`'s self-test against
           * `reachableSequences`, not asserted here). At two survivors roughly half the rotation is
           * still breakable, so the `found` search almost always succeeds and nothing moves. */
          if (!found && this.cfg.fabricateBreakableLock) {
            const any = [...reach].map((s) => s.split('>')).filter((l) => l.length >= 2);
            found = any.length ? any[0] : [...reach][0].split('>');
          }
          if (found) {
            this.log.push(`R${this.round} -- the telegraph shifts: ${lock.join('>')} -> ${found.join('>')}`
              + ` (${this.party.length - live.length} fallen)`);
            lock = found;
          } else {
            /* ⚠️ NOT SILENT — and the SCREEN, not this line, is what discharges that. This log entry
             * is for traces and gates; the player-facing half is `lockIsBeyondParty()` below, which
             * `ui.js` renders under the telegraph and `ui_smoke` asserts in pixels. Recorded that
             * way round because the first version of this comment claimed the player could see it
             * while only this `log.push` existed — a promise made in a comment is not a feature. */
            this.log.push(`R${this.round} -- lock ${lock.join('>')} is BEYOND the ${live.length} of you still standing`);
          }
        }
      }
    }

    this.telegraph = { lock, broken: false };
  }

  livingParty() { return this.party.filter((c) => c.hp > 0); }

  /**
   * ⭐ IS THE TELEGRAPH BEYOND WHAT IS LEFT OF THE PARTY? Derived, never stored.
   *
   * ⛔ THIS EXISTS BECAUSE OF A COMMENT I WROTE AND HAD NOT EARNED. When `fabricateBreakableLock`
   * went false (2026-09-02) the new branch in `_beginRound` pushed a log line and the comment beside
   * it claimed "the player must be able to see that the telegraph is beyond what is left of the
   * party". They could not: `ui.js` derives its banner from
   * `combat.log.filter(l => l.includes('lock'))`, and that line does not contain the word "lock",
   * so the one state this fix INTRODUCES was the one state the screen never mentioned — §6b-8's
   * "grind with nothing on screen to say so", re-created by the change that was meant to honour it.
   * ⇒ the model exposes the fact; `ui.js` renders it; `ui_smoke` asserts the pixels. A log line is
   * not a user interface.
   *
   * ⚠️ Memoised on the living-party signature, because the UI asks once per FRAME and this walks
   * every permutation of the survivors. The cache key is the fact it depends on, so it cannot go
   * stale behind a death.
   */
  lockIsBeyondParty() {
    if (!this.telegraph) return false;
    const live = this.livingParty();
    if (!live.length) return false;
    const key = live.map((c) => c.id).join(',');
    if (!this._reachCache || this._reachCache.key !== key) {
      const chars = ROSTER.filter((c) => live.some((l) => l.id === c.id));
      this._reachCache = { key, set: reachableSequences(chars) };
    }
    return !this._reachCache.set.has(this.telegraph.lock.join('>'));
  }

  /** Everything a player or a bot may legally do right now. */
  availableActions() {
    if (this.over) return [];
    const out = [];
    for (const c of this.livingParty()) {
      if (c.acted) continue;
      for (const a of c.abilities) out.push({ actorId: c.id, abilityId: a.id });
      /* relight is only OFFERED while there is oil left — see cfg.oilCharges */
      if (this.oil > 0) out.push({ actorId: c.id, abilityId: RELIGHT.id });
    }
    return out;
  }

  /**
   * Take one party action.
   * `quality` is 'perfect' | 'good' | 'miss' — produced by a real keypress in the UI, or by a
   * player MODEL in the bots. The model does not care which, and that is the point.
   */
  act(actorId, abilityId, quality) {
    if (this.over) throw new Error('combat is over');
    const c = this.party.find((x) => x.id === actorId);
    if (!c) throw new Error(`no such character: ${actorId}`);
    if (c.hp <= 0) throw new Error(`${actorId} is down`);
    if (c.acted) throw new Error(`${actorId} has already acted this round`);
    if (!['perfect', 'good', 'miss'].includes(quality)) throw new Error(`bad quality: ${quality}`);

    /* The action costs real time whether it lands or not — the flame does not wait. Under an
     * external clock the caller has already burned that time frame by frame; see `externalClock`. */
    if (!this.externalClock) this.tick(this.cfg.sweepMs + this.cfg.thinkMs);
    c.acted = true;
    this.stats[quality] += 1;

    if (abilityId === RELIGHT.id) {
      if (this.oil <= 0) throw new Error('no oil left — relight is not a legal action');
      this.oil -= 1;
      this.stats.relights += 1;
      this._feedFlame(this.cfg.relightFlame);
      this.log.push(`R${this.round} ${c.name} RELIGHT (${quality}) flame->${this.flame.toFixed(0)} oil ${this.oil}`);
    } else {
      const a = c.abilities.find((x) => x.id === abilityId);
      if (!a) throw new Error(`${actorId} has no ability ${abilityId}`);

      const mult = quality === 'perfect' ? this.cfg.dmgPerfect
        : quality === 'good' ? this.cfg.dmgGood : this.cfg.dmgMiss;
      /* THE WARDEN (see cfg.enemyHardens): the colour it hardened against last round lands at half
       * weight. Damage only — the colour is still PUSHED below, so the lock stays solvable. */
      const harden = this.hardenedAgainst(a.colour) ? this.cfg.dmgHardened : 1;
      this.enemy.hp = Math.max(0, this.enemy.hp - Math.round(a.power * mult * harden));
      if (a.heal) {
        const t = this.healTargetFor(c);
        t.hp = Math.min(t.maxHp, t.hp + Math.round(a.heal * mult));
        if (t.id !== c.id) this.stats.healsOnOthers = (this.stats.healsOnOthers || 0) + 1;
      }

      /* ⭐ THE COLOUR IS PUSHED ON A MISS TOO (DESIGN §3). Timing buys LIGHT, not lock-breaking. */
      this.stack.push(a.colour);
      while (this.stack.length > this.cfg.stackSize) this.stack.shift();

      /* ⭐⭐ DID THE SEQUENCE EVER STAND COMPLETE THIS ROUND? Recorded the instant it happens,
       * because the whole point is that a LATER action can destroy it. `_enemyPhase` reads it.
       * This is the quantity `_burial_shape.js` measured at 40.0% of the learner's landed rounds
       * against 6.1% of the planner's — the widest differential anything in this fight has. */
      if (this.telegraph && this.lockIsBroken()) this.telegraph.everComplete = true;

      this._feedFlame(quality === 'perfect' ? this.cfg.flameOnPerfect
        : quality === 'good' ? this.cfg.flameOnGood : this.cfg.flameOnMiss);

      this.log.push(`R${this.round} ${c.name} ${a.name} (${quality}) [${this.stack.join('>')}] `
        + `enemy ${this.enemy.hp} flame ${this.flame.toFixed(0)}`);
    }

    if (this.enemy.hp <= 0) { this._finish('WIN'); return; }
    if (this.livingParty().every((x) => x.acted)) this._enemyPhase();
  }

  /** ⭐ WHO A HEAL REACHES (cfg.healTargets). See the DEFAULTS note — this is the seam the
   * 2026-09-02 finding turned from an unexamined default into a decision. Ties break on roster
   * order, which is fixed, so a fight replays exactly. */
  healTargetFor(actor) {
    if (this.cfg.healTargets === 'self') return actor;
    const living = this.livingParty();
    if (!living.length) return actor;
    let low = living[0];
    for (const p of living) if (p.hp / p.maxHp < low.hp / low.maxHp) low = p;
    return low;
  }

  /** Does the top of the stack read as the telegraphed lock? (DESIGN §3) */
  lockIsBroken() {
    if (!this.telegraph) return false;
    const l = this.telegraph.lock;
    if (this.stack.length < l.length) return false;
    const top = this.stack.slice(this.stack.length - l.length);
    return top.every((v, i) => v === l[i]);
  }

  /**
   * ⭐ HOW MUCH OF THE TELEGRAPH IS STANDING ON TOP RIGHT NOW — the largest n such that the last n
   * of the stack equal the first n of the lock. `matched === lock.length` is exactly `lockIsBroken`.
   *
   * ⛔ THIS IS A MOVE, NOT A NEW FUNCTION. `ui.js` has computed this since the screen was built (it
   * is what draws "1 of 2 held"), and `models.js`/`policy.js` each re-derive it inline. Wing §6b-5:
   * extract before the third copy — and the third copy is exactly what the rule below would have
   * been. The screen and the model must agree about this number or the player is being told
   * something the fight does not believe.
   *
   * ⚠️ Reads the TRUE lock, never `visibleLock()`. A dark lantern hides the telegraph from the
   * PLAYER; it does not stop the enemy resolving it.
   */
  lockProgress() {
    if (!this.telegraph) return 0;
    const l = this.telegraph.lock;
    const s = this.stack.filter(Boolean);
    for (let n = Math.min(l.length, s.length); n > 0; n--) {
      if (s.slice(s.length - n).every((v, i) => v === l[i])) return n;
    }
    return 0;
  }

  /** ⭐ WHO A LANDED LOCK HITS (bestiary `targetPolicy`).
   * ⚠️ 'weakest' does not touch the RNG and 'random' does. That is NOT a desynchronisation risk for
   * the puzzle — `generateLocks` runs once in the constructor and the lock sequence is fixed before
   * any target is picked — but it does mean the two policies leave the stream at different offsets,
   * so nothing downstream may assume two seed-matched creatures with different policies share any
   * later random draw. Today nothing else draws, and this comment exists so the next thing that does
   * has to think about it. Ties break on roster order, which is fixed, so a fight replays exactly. */
  _pickTarget() {
    const living = this.livingParty();
    if (this.cfg.targetPolicy === 'weakest') {
      let best = living[0];
      for (const c of living) if (c.hp < best.hp) best = c;
      return best;
    }
    return living[Math.floor(this.rng() * living.length)];
  }

  _enemyPhase() {
    if (!this.externalClock) this.tick(this.cfg.enemyPhaseMs);
    /* ⭐ WHAT THE ENEMY ACTUALLY READ, RECORDED BY THE ONLY OBJECT THAT KNOWS.
     * ⛔ Added 2026-09-02 because a probe tried to reconstruct it from outside and got it wrong in
     * the flattering direction: the stack is a ROLLING queue that is never cleared between rounds
     * and `this.telegraph` is replaced by `_beginRound`, so ANY reading taken after `act()` returns
     * compares this round's stack against NEXT round's lock. That probe reported the planner
     * landing 424 of 427 rounds — a model measured elsewhere to BREAK 72% of them. Overwritten
     * every round, so it adds one small object and no history. */
    this.lastResolution = {
      round: this.round,
      lock: this.telegraph ? this.telegraph.lock.slice() : [],
      held: this.lockProgress(),
      broken: this.lockIsBroken(),
      stack: this.stack.slice(),
    };
    if (this.lockIsBroken()) {
      this.telegraph.broken = true;
      this.stats.locksBroken += 1;
      this.log.push(`R${this.round} -- lock ${this.telegraph.lock.join('>')} BROKEN`);
    } else {
      this.stats.locksLanded += 1;
      const target = this._pickTarget();
      /* ⭐ THE SPIRAL'S TEETH (bestiary `woundedBelow` + `woundedBonus`). A blow on a target already
       * below `woundedBelow` of their maximum lands for `woundedBonus`x. 0/null = off, which is
       * every creature written before 2026-09-02.
       * ⛔ WHY THIS EXISTS, AND IT IS NOT A BUFF. MEASURED (`_axis_witness.js --controls`, n=40):
       * flipping `targetPolicy` from 'weakest' to 'random' and changing nothing else moved the
       * outcome by **+15pt on the planner arm and +0pt on the learner and blind arms**, against
       * +73pt or better for every other axis in the bestiary. The tombspider's page promises a
       * DEATH SPIRAL and the fight was delivering "someone dies", which is what an untargeted
       * creature delivers. The cause was arithmetic: it hit for 30 into a party of 45/40/48, so two
       * hits felled anybody and concentration bought almost nothing chance did not.
       * ⇒ the axis is moved OFF raw lethality and ONTO the wound. Base damage can now fall (which
       * R2 and R8 both want) while the creature becomes MORE dangerous to a party that lets someone
       * stay hurt — and that is a decision the player can answer, which raw lethality never was. */
      const maxHp = target.maxHp || 1;
      const missing = Math.max(0, Math.min(1, 1 - (target.hp / maxHp)));
      const scale = 1 + (this.cfg.woundedScaling || 0) * missing;
      const baseDmg = Math.round(this.cfg.enemyDamage * scale);
      const wounded = baseDmg > this.cfg.enemyDamage;
      /* ⭐⭐ PARTIAL LIGHT (cfg.partialRelief). Holding SOME of the telegraph blunts the blow in
       * proportion to how much of it you hold. 0 = off, which is byte-for-byte every fight measured
       * before 2026-09-02.
       *
       * ⛔ WHY IT EXISTS, AND IT IS A MEASUREMENT, NOT A DIFFICULTY PREFERENCE. `_onramp_probe.js`
       * (2^5 factorial, control reproduced the board at chaseLock 0.0% / planner 71.7%) and
       * `_onramp_sweep.js` (144 cells, hp x damage x lock pool x hardening, bar pre-registered
       * ABOVE the run) between them say this:
       *
       *   - lethality is the cliff by 3.6x over the next lever (+76.4 pts on the learner);
       *   - and NO CELL OF 144 puts a learner in a survivable band while the planner stays inside
       *     its own 45-80% window. In every cell where the planner is inside its window the learner
       *     reads 0.0-1.7%, and in every cell where the learner is alive the planner reads 100%.
       *
       * ⭐ THE CAUSE IS THIS BRANCH. Breaking the telegraph is the ONLY defence in the game and it
       * is BINARY: break and take nothing, miss by one action and take everything. So a player who
       * breaks 72% of locks takes 28% of the damage and a player who breaks 15% takes 85% of it —
       * a 5x gap with NOTHING BETWEEN, which is why no single damage number can be survivable for
       * one and dangerous for the other. A difficulty curve cannot exist over a step function.
       *
       * ⭐ And the feedback failure is the same fact from the player's side: assemble both colours
       * the screen asked for, in the wrong order, and you are hit for exactly what you would have
       * been hit for had you ignored the telegraph completely. The game gives IDENTICAL feedback
       * for "you nearly had it" and "you did not try", to a player measured to assemble the correct
       * sequence in 60.2% of rounds and bury it in 40.5% of them.
       *
       * ⚠️ `Math.max(1, ...)` is load-bearing: a partial hold must never be as good as a break, or
       * the ordering rule — the thing the whole game is about — stops being worth learning.
       * ⚠️ `wounded` is taken off the PRE-relief number so the SAVAGES marker means the same thing
       * it meant before this rule existed. */
      const held = this.lockProgress();
      const partial = this.cfg.partialRelief > 0 && this.telegraph.lock.length
        ? (this.cfg.partialRelief * held) / this.telegraph.lock.length
        : 0;
      /* ⭐⭐ THE BURIED BLOW (cfg.buriedRelief). 0 = off = every fight measured before 2026-09-02.
       *
       * ⛔ THIS IS THE SECOND ATTEMPT AND THE FIRST ONE IS STILL ABOVE IT, DELIBERATELY.
       * `partialRelief` was built first, on the reasoning that a proportional relief would land on
       * the beginner. Swept over 60 cells it moved gravebound's learner from 0.0% to 1.7%. ⭐ The
       * reason is worth more than the rule: `lockProgress` compares a SUFFIX of the stack to a
       * PREFIX of the lock, and BURYING puts a wrong colour ON TOP — so the instant the beginner
       * commits their characteristic error, that reading is not "nearly there", it is ZERO. The
       * relief paid out to a player still BUILDING and nothing at all to the player who HAD it.
       *
       * ✅ MEASURED where the difference actually lives (`_burial_shape.js`, 60 seeds, corrected
       * instrument): of the rounds where the blow LANDED, the sequence had stood complete and been
       * buried in **40.0%** of the learner's and **6.1%** of the planner's. That is a 6.5x
       * separation and the widest of any observable in this fight — so a relief keyed on it is
       * differential BY CONSTRUCTION rather than by tuning.
       *
       * ⭐ AND IT IS THE FEEDBACK FIX, WHICH IS THE HALF THAT MATTERS. Today a player who assembles
       * both colours the screen asked for, in the wrong order, is hit for exactly what they would
       * have been hit for had they ignored the telegraph entirely. The game gives IDENTICAL
       * feedback for "you nearly had it" and "you did not try". This makes the near-miss cost less
       * AND say so, at the moment it happens, which is the only moment a person can learn from.
       *
       * ⚠️ It can never beat breaking: relief is capped below 1 and `Math.max(1, ...)` floors the
       * blow at 1, so a buried round is always strictly worse than a broken one. If that ever
       * stops being true the ordering rule — the entire game — stops being worth learning.
       * ⚠️ The two reliefs are combined by taking the LARGER, never by adding: they describe the
       * same round from two angles and stacking them was measured to be an accidental double
       * discount rather than a design. */
      const buried = this.cfg.buriedRelief > 0 && this.telegraph.everComplete
        ? Math.min(0.95, this.cfg.buriedRelief) : 0;
      const relief = Math.max(partial, buried);
      const dmg = relief > 0 ? Math.max(1, Math.round(baseDmg * (1 - relief))) : baseDmg;
      target.hp = Math.max(0, target.hp - dmg);
      /* ⭐ THE SNUFFER OVERRIDE (bestiary `enemyHitFlame`). null keeps `flameOnEnemyHit`, which is
       * every creature written before the bestiary. */
      const hitFlame = this.cfg.enemyHitFlame === null || this.cfg.enemyHitFlame === undefined
        ? this.cfg.flameOnEnemyHit : this.cfg.enemyHitFlame;
      this._feedFlame(hitFlame);
      /* ⛔ THE WORD `lock` STAYS IN THIS LINE. `ui.js` derives its banner from
       * `log.filter(l => l.includes('lock'))` — §6b-9 rule 5 is exactly this: a state the model
       * introduces and the screen never mentions is a state that does not exist to the player. The
       * SAVAGES marker is appended to the same line so it cannot be separated from it. */
      this.log.push(`R${this.round} -- lock ${this.telegraph.lock.join('>')} LANDS on ${target.name} `
        + `(-${dmg})${wounded ? ' SAVAGES THE WOUNDED' : ''}`
        /* ⛔ THE RELIEF IS NAMED IN THE LOG BECAUSE `ui.js` DERIVES ITS BANNER FROM THIS LINE
         * (§6b-9 rule 5: a state the model introduces and the screen never mentions is a state that
         * does not exist to the player). A blow that landed for half is the single most important
         * thing this rule has to communicate — it is the entire feedback fix. */
        + `${relief > 0
          ? (buried >= partial
            ? ` YOU HAD IT AND BURIED IT (-${Math.round(relief * 100)}%)`
            : ` PARTLY TURNED (${held}/${this.telegraph.lock.length} held, -${Math.round(relief * 100)}%)`)
          : ''}`
        + ` flame ${this.flame.toFixed(0)}`);
    }

    /* ⭐ THE LAMP-EATER (bestiary `flameDrainPerRound`). Applied whether the lock broke or not —
     * that is the point of it: breaking the telegraph saves your HEALTH and does nothing for your
     * LIGHT, so a creature with this axis cannot be out-puzzled, only out-run. 0 = off. */
    if (this.cfg.flameDrainPerRound > 0) {
      this._feedFlame(-this.cfg.flameDrainPerRound);
      this.log.push(`R${this.round} -- it drinks the light (-${this.cfg.flameDrainPerRound}) `
        + `flame ${this.flame.toFixed(0)}`);
    }

    /* ⭐ THE WARDEN HARDENS ON WHAT THE ROUND ENDED ON. Taken from the top of the stack, which is
     * the SAME fact the lock is read from a few lines above — one source of truth, not two, so the
     * player learns a single rule ("whatever you leave on top") rather than two coincidental ones.
     * ⚠️ Set AFTER the lock is resolved, so the round's outcome is never affected by the hardening
     * it produces.
     * ⭐ `hardenCount` (bestiary ENCIRCLING axis) makes this a bounded queue of DISTINCT colours,
     * oldest evicted first. At the default 1 the behaviour is byte-for-byte the shipped warden. */
    if (this.cfg.enemyHardens) {
      const top = this.stack.length ? this.stack[this.stack.length - 1] : null;
      const held = this.enemy.hardenedTo;
      if (top && held[held.length - 1] !== top) {
        const idx = held.indexOf(top);
        if (idx !== -1) held.splice(idx, 1);          // re-struck: it moves to the front of memory
        held.push(top);
        while (held.length > Math.max(1, this.cfg.hardenCount)) held.shift();
        this.log.push(`R${this.round} -- the warden hardens against ${held.join(' + ')}`);
      }
    }

    if (this.livingParty().length === 0) { this._finish('LOSS'); return; }
    if (this.round >= this.cfg.maxRounds) { this._finish('TIMEOUT'); return; }
    this._beginRound();
  }

  _finish(result) {
    this.over = true;
    this.result = result;
    this.log.push(`== ${result} in ${this.round} rounds, ${(this.timeMs / 1000).toFixed(1)}s, `
      + `flame ${this.flame.toFixed(0)}`);
  }
}

/* ------------------------------------------------------------------------------------------------
 * THE TIMING BAR — pure, so gate C can measure it without a canvas.
 * ---------------------------------------------------------------------------------------------- */
/** Classify a press, given when in the sweep it happened. */
function classifyPress(pressMs, cfg = DEFAULTS) {
  const d = Math.abs(pressMs - cfg.perfectAtMs);
  if (d <= cfg.perfectWindowMs) return 'perfect';
  if (d <= cfg.goodWindowMs) return 'good';
  return 'miss';
}

const API = {
  COLOURS, ROSTER, RELIGHT, DEFAULTS,
  createRNG, Combat, classifyPress,
  generateLocks, lockIsSatisfiable, reachableSequences, REACHABLE, lockSpace,
};

/* ⛔ ONE FILE, TWO CONSUMERS, AND THAT IS THE POINT. The bots require() this in Node and the browser
 * front end loads the SAME file with a <script> tag. If the UI ever gets its own copy of the rules,
 * every number in BALANCE_FINDINGS.md stops describing the thing a human plays — which is the
 * shared-generator failure of wing §6d-10 waiting to happen in a new place. */
if (typeof module !== 'undefined' && module.exports) module.exports = API;
if (typeof window !== 'undefined') window.LB = API;
