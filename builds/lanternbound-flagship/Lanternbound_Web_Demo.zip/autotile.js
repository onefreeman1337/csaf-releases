'use strict';
/* ================================================================================================
 * autotile.js — RESOLVE A NEIGHBOURHOOD TO ONE OF THE PACK'S 47 BLOB TILES.
 * ================================================================================================
 *
 * WHY THIS FILE EXISTS. Until 2026-09-02 the overworld drew terrain as five flat colours
 * (`TERRAIN = { GRASS: '#333f31', PATH: '#57503e', ... }` in `overworld_ui.js`), while the COMBAT
 * screen drew real 32 px Highland tiles. The overworld is where most of the playtime is and where
 * the flow directive's primary verb lives — *walk a night moor with a lantern* — so the game's main
 * screen was the one with no art in it. Frames opened this session: `Playtest/gate_a/001` is dark
 * green rectangles and a WHITE BOX for the player.
 *
 * THE BIT LAYOUT IS DERIVED FROM THE PACK, NOT ASSUMED. Every autotile tile in
 * `VerdantHD01_Highland/tiles.json` carries a numeric `mask` beside its `maskName`, and reading the
 * 47 pairs out gives the layout unambiguously:
 *
 *      N=1  NE=2  E=4  SE=8  S=16  SW=32  W=64  NW=128        (clockwise from north)
 *
 * checked against the pack's own numbers: `nesw` = 1+4+16+64 = **85** ✓, `ne_ne` = 1+4+2 = **7** ✓,
 * `nes_nese` = 1+4+16+2+8 = **31** ✓, `nw_nw` = 1+64+128 = **193** ✓, `fill` = **255** ✓.
 * ⛔ Guessing this layout would have been the classic silent failure: a wrong bit order still draws
 * a tile for every cell, so nothing errors and nothing is empty — the edges are simply WRONG, which
 * is only visible by looking at a rendered map, and only if you know what right looks like.
 *
 * THE REDUCTION. A raw 8-neighbour mask has 256 values; a blob set ships 47. A CORNER only matters
 * when both of its adjacent CARDINALS are also the same material — otherwise the corner is hidden
 * behind the edge that is already being drawn. So NE survives only if N and E are set, and so on.
 * That maps all 256 onto the 47, and `--self-test` proves it exhaustively rather than by argument:
 * for every set in the atlas, all 256 raw masks resolve to a tile that EXISTS.
 *
 *   node autotile.js --self-test
 * ---------------------------------------------------------------------------------------------- */
(function () {
  const N = 1, NE = 2, E = 4, SE = 8, S = 16, SW = 32, W = 64, NW = 128;

  /**
   * Reduce a raw 8-neighbour mask to the canonical blob mask the pack ships a tile for.
   * A corner bit survives only when both adjacent cardinal bits are set.
   */
  function canonical(raw) {
    let m = raw & (N | E | S | W);
    if ((raw & NE) && (raw & N) && (raw & E)) m |= NE;
    if ((raw & SE) && (raw & S) && (raw & E)) m |= SE;
    if ((raw & SW) && (raw & S) && (raw & W)) m |= SW;
    if ((raw & NW) && (raw & N) && (raw & W)) m |= NW;
    return m;
  }

  /**
   * Build the raw mask for cell (x,y) from a `same(x,y) -> bool` predicate.
   * ⛔ OUT OF BOUNDS COUNTS AS SAME. A map edge is not a material boundary the player can see, and
   * treating it as one draws a coastline around the whole world — every region would look like an
   * island. The overworld already walls its border in ROCK, so the visible edge is authored.
   */
  function maskAt(x, y, same) {
    let m = 0;
    if (same(x, y - 1)) m |= N;
    if (same(x + 1, y - 1)) m |= NE;
    if (same(x + 1, y)) m |= E;
    if (same(x + 1, y + 1)) m |= SE;
    if (same(x, y + 1)) m |= S;
    if (same(x - 1, y + 1)) m |= SW;
    if (same(x - 1, y)) m |= W;
    if (same(x - 1, y - 1)) m |= NW;
    return m;
  }

  /**
   * Pick the tile id for one cell of an autotile set.
   * `sets` is the atlas's `sets` map: { setName: { maskNumber: tileId } }.
   * Returns null when the set is unknown, so a caller can fall back rather than draw nothing.
   */
  function tileFor(sets, setName, x, y, same) {
    const set = sets && sets[setName];
    if (!set) return null;
    return set[canonical(maskAt(x, y, same))] || set[255] || null;
  }

  /**
   * A stable per-cell variant index for a fill material that ships `_1.._n`.
   * ⛔ HASHED FROM THE COORDINATES, NEVER RANDOM: the terrain must be identical every frame, or the
   * moor visibly boils as the camera moves. Same reason `stage.js` hashes its scenery.
   */
  function variant(x, y, n, salt = 0) {
    let h = (x * 374761393 + y * 668265263 + salt * 2246822519) >>> 0;
    h = ((h ^ (h >>> 13)) * 1274126177) >>> 0;
    return (h >>> 8) % n;
  }

  const API = { canonical, maskAt, tileFor, variant, BITS: { N, NE, E, SE, S, SW, W, NW } };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  if (typeof window !== 'undefined') window.LB_AUTOTILE = API;

  /* -- self-test ------------------------------------------------------------------------------ */
  /* ⛔ `require.main === module` — "am I the program being run?", NOT merely "is --self-test in
   * argv?". MEASURED 2026-09-02: the argv form fires whenever ANY process carrying that flag
   * requires this file (world_art.js does), so this suite printed into another tool's report AND
   * ended by writing `process.exitCode` — one module setting another's verdict at require time. A
   * required module that PASSES silently sets 0, which can clear a caller's real failure. Blast
   * radius measured at 2 files factory-wide (`_probe_selftest_leak.js`); the other 19 argv-guarded
   * files are standalone scripts, where the argv form is correct. */
  if (typeof require === 'function' && typeof process !== 'undefined'
      && typeof module !== 'undefined' && require.main === module
      && process.argv && process.argv.includes('--self-test')) {
    const fs = require('node:fs');
    const path = require('node:path');
    let pass = 0, fail = 0;
    const check = (name, ok, detail = '') => {
      if (ok) { pass++; console.log(`  PASS  ${name}   ${detail}`); }
      else { fail++; console.log(`  FAIL  ${name}   ${detail}`); }
    };

    /* 1. the bit layout, against the pack's OWN published numbers — not against this file's constants */
    /* proto/ -> Internal_Ops/ -> the project root. `stage.js` loads art from the same '../../'. */
    const atlasPath = path.join(__dirname, '..', '..', 'Product_Release', 'assets', 'tiles', 'atlas.json');
    const atlas = JSON.parse(fs.readFileSync(atlasPath, 'utf8'));
    check('atlas is present and non-empty', atlas.tileCount > 400, `${atlas.tileCount} tiles`);

    /* ⛔ PACK-QUALIFIED. The atlas merges two tileset packs and keys everything `"<pack>:<id>"`,
     * because they share five bare ids; a lookup by bare name silently returns undefined here and
     * the WRONG pack's tile in a table. Added 2026-09-02 with the second pack. */
    const SET = 'highland:scree_on_sward';
    const named = { 85: 'nesw', 7: 'ne_ne', 31: 'nes_nese', 193: 'nw_nw', 255: 'fill', 0: 'single' };
    let layoutOk = true; const bad = [];
    for (const [m, nm] of Object.entries(named)) {
      const id = atlas.sets[SET] && atlas.sets[SET][m];
      if (id !== `highland:scree_on_sward_${nm}`) { layoutOk = false; bad.push(`${m}->${id}`); }
    }
    check('mask numbers match the pack\'s own maskNames', layoutOk, bad.join(' '));

    /* 2. THE COMPLETENESS PROOF, and it is the whole point of the file: every one of the 256 raw
     *    neighbourhoods a real map can produce must resolve to a tile that EXISTS, for every set.
     *    A hole here is a blank cell that only appears on one map shape. */
    let holes = 0; const holeDetail = [];
    const setNames = Object.keys(atlas.sets);
    for (const sn of setNames) {
      for (let raw = 0; raw < 256; raw++) {
        const id = atlas.sets[sn][canonical(raw)];
        if (!id || !atlas.tiles[id]) { holes++; if (holeDetail.length < 5) holeDetail.push(`${sn}:${raw}`); }
      }
    }
    check(`all 256 masks resolve for all ${setNames.length} sets`, holes === 0 && setNames.length > 0,
      holes ? `${holes} hole(s): ${holeDetail.join(' ')}` : `${setNames.length * 256} lookups, 0 holes`);

    /* 3. the reduction must actually REDUCE — 256 raw masks onto exactly 47 canonical ones */
    const distinct = new Set();
    for (let raw = 0; raw < 256; raw++) distinct.add(canonical(raw));
    check('256 raw masks reduce to exactly 47 canonical', distinct.size === 47, `got ${distinct.size}`);

    /* 4. a corner with no adjacent cardinals must be DROPPED (the reduction's whole rule) */
    check('lone NE corner is dropped', canonical(NE) === 0, `canonical(2)=${canonical(NE)}`);
    check('NE kept when N and E present', canonical(N | E | NE) === (N | E | NE), `=${canonical(N | E | NE)}`);
    check('NE dropped when only N present', canonical(N | NE) === N, `=${canonical(N | NE)}`);

    /* 5. maskAt must read the neighbourhood in the layout above — a transposed or mirrored reader
     *    is the silent failure this file's header warns about, so assert one asymmetric case */
    const onlyEast = maskAt(5, 5, (x, y) => x === 6 && y === 5);
    check('maskAt reads EAST as bit 4', onlyEast === E, `got ${onlyEast}`);
    const onlySouth = maskAt(5, 5, (x, y) => x === 5 && y === 6);
    check('maskAt reads SOUTH as bit 16', onlySouth === S, `got ${onlySouth}`);

    /* 6. variant() must be stable and spread */
    const a1 = variant(3, 9, 4), a2 = variant(3, 9, 4);
    check('variant is stable for one cell', a1 === a2, `${a1}==${a2}`);
    const counts = [0, 0, 0, 0];
    for (let x = 0; x < 40; x++) for (let y = 0; y < 40; y++) counts[variant(x, y, 4)]++;
    check('variant spreads over all 4 fills', counts.every((c) => c > 200), counts.join('/'));

    /* 6b. THE MULTI-CELL FOOTPRINT SURVIVED INTO THE ATLAS. 15 of the pack's 497 tiles are bigger
     *     than one cell and a consumer that assumes 32x32 draws a quarter of each with no error —
     *     master §2b records exactly this field costing the tilesets wing 24 tiles of shipped art.
     *     ⛔ Assert the set is NON-EMPTY first: `every()` over zero rows is vacuously true, which is
     *     the other half of that same catalogue row. */
    const multi = Object.entries(atlas.tiles).filter(([, t]) => (t.w || 1) > 1 || (t.h || 1) > 1);
    check('atlas carries multi-cell props', multi.length > 0, `${multi.length} tiles bigger than one cell`);
    check('every multi-cell prop has both dimensions',
      multi.length > 0 && multi.every(([, t]) => t.w >= 1 && t.h >= 1),
      multi.slice(0, 4).map(([id, t]) => `${id}=${t.w}x${t.h}`).join(' '));
    const menhir = atlas.tiles['highland:menhir'];
    check('menhir is 1x2 as the pack declares', !!menhir && menhir.w === 1 && menhir.h === 2,
      menhir ? `${menhir.w}x${menhir.h}` : 'absent');

    /* 7. tileFor falls back rather than returning garbage for an unknown set */
    check('tileFor(unknown set) returns null', tileFor(atlas.sets, 'no_such_set', 0, 0, () => true) === null);

    console.log(`\n  ${pass} passed, ${fail} failed`);
    process.exitCode = fail ? 1 : 0;
  }
}());
