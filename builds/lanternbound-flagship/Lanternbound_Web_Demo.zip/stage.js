'use strict';
/* ================================================================================================
 * stage.js — THE BATTLE STAGE. First-party art, drawn.
 * ================================================================================================
 * ⛔ WHY THIS FILE EXISTS. Gate A was re-run on 2026-09-01 and the frames were OPENED: the enemy was
 * a plain grey rounded rectangle, the screen was mostly empty black, and nothing on it resembled the
 * "JRPG-style, SNES-era graphics, cute anime styling" the directive that created this project asked
 * for (wing CLAUDE.md §0a-2). Several sessions had measured win rates on a game with no art. Master
 * §1.1a: THE LOOK IS THE PRODUCT.
 *
 * ⛔ AND THE EXPENSIVE HALF WAS ALREADY PAID FOR. `Internal_Ops/spike_battle_backdrop.js` had
 * already composed this exact scene — Highland tiles, Wildmark party, Mourncrest undead, at the
 * shipping 2x, at all three light levels — and measured every figure's edge contrast against its own
 * local backdrop. It was never wired into the front end. This file is that composition made live;
 * the placement rules, the zoom and the light curve are TAKEN from it rather than re-derived.
 *
 * ⛔ THE LIGHT CURVE IS THE SPIKE'S, NOT A NEW ONE: `k = 0.18 + 0.82t` with a warm additive term.
 * The floor is load-bearing — wing §6b-5 rule 3 says "too dark to see" is a mechanical failure, not
 * a mood, and the spike measured that the PARTY is the darker group (interior luminance 56-99
 * against the undead's 119-133), so a linear-to-black falloff would take your own party first.
 *
 * ⚠️ SOUTH FRAMES ONLY. wildmark-01 has a known cross-facing quiver defect and a within-cycle split,
 * both on east and west (Sprites CLAUDE.md §3e-i-d). South is the seed frame and correct by
 * construction, so a front-view battle screen is the one composition that imports no known defect.
 * ============================================================================================== */
(function () {
  /* Every asset path resolves into the RELEASE tree. The prototype loads the same bytes the game
   * ships; there is no second copy to go stale.
   * Provenance + sha256 for all 30: Product_Release/assets/ASSET_PROVENANCE.json.
   * ⛔ THE BASE IS DECLARED ONCE, IN `paths.js`, AND WAS WRITTEN OUT FOUR TIMES UNTIL 2026-09-03 —
   * it is a fact about the directory LAYOUT, not about this module, and the packaged build puts the
   * assets somewhere else. See the head of `paths.js` for why the alternative (a packager that
   * rewrites these string literals on the way out) is the worse option. */
  const BASE = (typeof window !== 'undefined' && window.LB_PATHS)
    ? window.LB_PATHS.assets : '../../Product_Release/assets/';

  /* ⛔ NATIVE SIZES, ASSERTED AND NEVER ASSUMED. Wing §5a: a geometry constant written for one pack
   * silently slices another at exit 0. `loadAll` refuses any image whose natural size disagrees. */
  const SPRITE_PX = 64;
  const TILE_PX = 32;
  /* which staged tileset pack the loose combat tiles below come from — see loadAll() */
  const TILE_PACK = 'highland';
  const ZOOM = 2;                     /* the spike's shipping zoom */
  const CELL = TILE_PX * ZOOM;        /* 64 */

  const PARTY_ART = ['sable', 'wren', 'oren'];

  /* ⛔⛔ THE ENEMY ROSTER IS READ OUT OF `bestiary.js`, AND IT USED TO BE TYPED HERE.
   *
   * This line was `['bonehound', 'wight', 'gravebound', 'wraith']` — a SECOND declaration of the
   * game's enemy roster, in a file whose job is drawing. It was already wrong the moment the
   * bestiary landed: it named `wraith`, which no creature uses, and knew nothing about the six new
   * ones, so the ten-creature slice would have rendered as four sprites with the boss drawn as a
   * random moor animal.
   *
   * Wing §6d-10 is the precedent and it is the most expensive lesson in this wing's file: five sold
   * cartridges took a silent out-of-bounds read because each carried its own hand-typed copy of an
   * alphabet that a shared generator owned. **A shared generator is a shared FACT, and every
   * consumer holding its own copy is a place the product moves without anyone editing it.**
   *
   * ⚠️ DUAL-MODE, because this file is loaded by a plain <script> tag as well as by `require` — and
   * ⛔ a bare `require()` at the top of a file a <script> tag also loads is a fatal ReferenceError
   * whose only symptom is a blank canvas (wing §6b-5 rule 1). The <script> path needs `bestiary.js`
   * to load BEFORE `stage.js`; index.html orders them that way and `ui_smoke` would go red if it
   * ever stopped, because `enemyKey` would throw on a null roster rather than silently guessing. */
  const BESTIARY = (typeof require === 'function') ? require('./bestiary')
    : (typeof window !== 'undefined' ? window.LB_BESTIARY : null);
  if (!BESTIARY) throw new Error('stage.js needs bestiary.js loaded first — it owns the enemy roster');
  const ENEMY_ART = BESTIARY.CREATURES.map((c) => c.sprite.art);
  const GROUND = ['sward_1', 'sward_2', 'sward_3', 'sward_4'];
  const BACK = ['scree_1', 'scree_2', 'scree_3', 'scree_4'];
  const PROPS = ['cairn', 'menhir', 'boulder', 'thorn', 'gorse', 'rocks', 'fern'];

  /* Which sprite a named enemy uses — DERIVED from the same roster, so a creature added to the
   * bestiary is drawable the moment it exists and can never be silently mapped to the wrong body.
   * ⚠️ Keyed on the creature's display `name`, because that is what `encounters.js` authors into
   * `enemyName` and what the nameplate shows; the two must agree or the picture contradicts the
   * label, which is the §6d-14 class (the reference and the ROM agreeing on a lie). */
  const ENEMY_FOR = Object.fromEntries(BESTIARY.CREATURES.map((c) => [c.name, c.sprite.art]));

  const img = {};
  let ready = false;
  let failed = [];

  function load(rel) {
    return new Promise((resolve) => {
      const i = new Image();
      i.onload = () => resolve({ rel, i });
      i.onerror = () => resolve({ rel, i: null });
      i.src = BASE + rel;
    });
  }

  async function loadAll() {
    const want = [
      ...PARTY_ART.map((n) => [`p_${n}`, `sprites/party/${n}.png`, SPRITE_PX]),
      ...ENEMY_ART.flatMap((n) => [0, 1, 2].map((f) => [`e_${n}_${f}`, `sprites/enemy/${n}_${f}.png`, SPRITE_PX])),
      /* ⛔ `TILE_PACK` — the loose combat tiles are namespaced by PACK on disk. Two staged tilesets
       * share five ids (`well`, `cart`, `logpile`, `barrel`, `trough`), so a flat `tiles/<id>.png`
       * tree lets the second pack staged silently overwrite the first. These fifteen are all
       * highland; a farmstead backdrop would name its own pack rather than reuse this constant. */
      ...GROUND.map((n) => [`t_${n}`, `tiles/${TILE_PACK}/${n}.png`, TILE_PX]),
      ...BACK.map((n) => [`t_${n}`, `tiles/${TILE_PACK}/${n}.png`, TILE_PX]),
      ...PROPS.map((n) => [`t_${n}`, `tiles/${TILE_PACK}/${n}.png`, null]),
    ];
    const got = await Promise.all(want.map(([, rel]) => load(rel)));
    failed = [];
    want.forEach(([key, rel, expect], idx) => {
      const g = got[idx];
      if (!g.i) { failed.push(`${rel} (did not load)`); return; }
      /* ⛔ A WRONG-SIZED IMAGE IS WORSE THAN A MISSING ONE — it draws, at the wrong scale, and every
       * placement below silently means something else. Props are legitimately non-square (menhir is
       * 32x64), so only the graded assets carry a size assertion. */
      if (expect !== null && (g.i.naturalWidth !== expect || g.i.naturalHeight !== expect)) {
        failed.push(`${rel} is ${g.i.naturalWidth}x${g.i.naturalHeight}, expected ${expect}x${expect}`);
        return;
      }
      img[key] = g.i;
    });
    ready = failed.length === 0;
    return { ready, failed: failed.slice(), loaded: Object.keys(img).length };
  }

  /* -- deterministic scatter --------------------------------------------------------------------
   * The backdrop must not re-shuffle every frame, and two fights with the same seed must look the
   * same. A tiny integer hash over (x, y, salt) does both without holding any state. */
  function h32(x, y, salt) {
    let n = (x * 374761393 + y * 668265263 + salt * 2147483647) | 0;
    n = (n ^ (n >>> 13)) * 1274126177;
    return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
  }

  /**
   * Draw the backdrop: a scree slope above the horizon, heath sward below it, with a deterministic
   * variant per cell so the ground does not read as wallpaper.
   * ⛔ Tilesets CLAUDE.md / wing §0-ART-b rule 2: texture must never live in a tile that repeats on
   * a fixed period — the variation goes in the VARIANT CHOICE, scattered, never in one base tile.
   */
  function backdrop(g, w, stageH, horizon, seed) {
    for (let y = 0; y < stageH; y += CELL) {
      for (let x = 0; x < w; x += CELL) {
        const below = y + CELL / 2 >= horizon;
        const set = below ? GROUND : BACK;
        const pick = set[Math.floor(h32(x / CELL, y / CELL, seed) * set.length) % set.length];
        const t = img[`t_${pick}`];
        if (t) g.drawImage(t, 0, 0, TILE_PX, TILE_PX, x, y, CELL, CELL);
      }
    }
    /* ⭐ DEPTH, added 2026-09-02. Gate A's frames were LOOKED AT and the upper band was the worst
     * region in the picture: everything above `horizon - 46` is bare tiled scree with no feature in
     * it at all, so it read as a flat wall with visible tile repetition rather than as a slope
     * going away from you. Two procedural cues fix it, both deterministic from the SAME seed the
     * tiles use, and both drawn rather than shipped — no new art.
     *
     * 1. A FAR RIDGELINE. One silhouette whose top edge is a summed-hash curve, filled darker than
     *    the scree. A single occluding edge is the cheapest real depth cue there is: it splits one
     *    flat plane into a near slope and a far one.
     * 2. ATMOSPHERIC HAZE that strengthens with height. Distance desaturates and lifts toward the
     *    sky, and here it also breaks up the tile period, which wing §0-ART-b wants killed anyway.
     *    Cool, because the only warm light in this game is the lantern. */
    /* ⛔⛔ TWO RIDGES AND A SKY, ADDED 2026-09-02 — AND THE REASON IS A COST THIS FILE INCURRED, NOT
     * A NICE-TO-HAVE. `ui.js` grew STAGE_H 236 -> 340 the same session so the scene would stop being
     * 42% of the screen. **The stage grew and the CONTENT did not.** Verified from the code rather
     * than from a look, because four looks were falsified that day: `scenery()` places all seven
     * props between `horizon-46` and `horizon-8`, and the single ridge sat at `horizon-62` — so with
     * horizon at 168 there was NOTHING above y=106, i.e. 31% of the stage held gradients only. A
     * bigger empty band is a worse picture than a small full one, and shipping the layout change
     * without this would have traded one measured defect for another.
     *
     * ⛔⛔ AND THE FIRST VERSION OF THE SECOND RIDGE DID NOT EXIST IN THE PICTURE — measured, not
     * guessed. It filled from its curve UP to the top, exactly like the original single ridge, so
     * both fills darkened the SAME SKY and the only difference across the far curve was 0.42 of a
     * near-black over a near-black. `_stage_look.js --horizon 80` found **531 of 722 columns with no
     * edge at all** in that window and locked onto the near ridge at meanRow 96.2 instead. The code
     * ran, nothing errored, and the sky was the sky it had always been. ⭐ Sibling of the star bug
     * found in the same pass: BOTH were "drawn correctly, somewhere invisible".
     *
     * ✅ THE SHAPE THAT WORKS IS THE GENRE'S OWN: a ridge is a SILHOUETTE FILLED DOWNWARD from its
     * crest to the horizon, over the scree, not a wash over the sky. Then the near mass occludes the
     * far one below its own crest and both crests are visible as edges — which is what a layered
     * SNES battle backdrop is. Aerial perspective sets the tones: the FAR mass is LIGHTER and hazier
     * (it has more air in front of it), the NEAR mass darker. ⛔ Getting that order backwards is the
     * single most common way a layered backdrop reads as flat, so the two alphas are commented as a
     * PAIR and neither may be tuned alone.
     * ⚠️ Both are translucent so the scree texture still reads through them — a flat silhouette
     * would trade the tile detail this pack ships for a shape, and the measured grid ratio (1.00)
     * says that texture is not costing anything. */
    const ridge = (base, amp, saltA, saltB, style) => {
      g.save();
      g.beginPath();
      g.moveTo(0, base + amp);
      for (let x = 0; x <= w; x += 8) {
        const n = (h32(x / 8, saltA, seed) + h32(x / 24, saltB, seed) * 2) / 3;  /* two octaves */
        g.lineTo(x, base - Math.round(n * amp) + 8);
      }
      /* down to the horizon and back along it — the mass, not the sky above it */
      g.lineTo(w, horizon); g.lineTo(0, horizon); g.closePath();
      /* ⛔⛔ THE MASS FADES OUT BEFORE IT REACHES THE HORIZON, AND THAT IS A DEFECT FIX, NOT A
       * FLOURISH. Filled flat to `horizon` these silhouettes laid one uniform tone right up to the
       * scree/sward boundary and ERASED the tile-level raggedness that was making that boundary
       * read as a place rather than as a cut: `_stage_look.js` measured the main horizon going
       * **modeShare 7.1% -> 36.1% and sd 15.13 -> 8.11 px in the same edit** — more than a third of
       * columns changing material on ONE row. ⭐ So a change that fixed the sky measurably degraded
       * the ground, in a direction nobody was looking, and only a number aimed at the OTHER end of
       * the stage caught it. Fading the last stretch to zero coverage hands the boundary back to
       * the tiles. */
      g.clip();
      const fade = g.createLinearGradient(0, Math.max(0, base - amp), 0, horizon);
      fade.addColorStop(0, style);
      fade.addColorStop(0.62, style);
      fade.addColorStop(1, style.replace(/,\s*[\d.]+\)$/, ',0)'));
      g.fillStyle = fade;
      g.fillRect(0, 0, w, horizon);
      g.restore();
    };
    const ridgeBase = Math.max(18, horizon - 62);
    const farBase = Math.max(12, ridgeBase - 34);
    /* THE SKY above the far crest: darkened to near black so the stars have something to sit on and
     * the enemy nameplate stays readable over pale scree (a measured requirement — see ui.js). */
    const skyGrad = g.createLinearGradient(0, 0, 0, Math.max(2, farBase));
    skyGrad.addColorStop(0, 'rgba(8,9,14,0.88)');
    skyGrad.addColorStop(1, 'rgba(8,9,14,0.55)');
    g.fillStyle = skyGrad;
    g.fillRect(0, 0, w, Math.max(2, farBase));
    /* ⛔ THE PAIR. Far is LIGHTER (more air in front of it), near is DARKER. Reversed, the backdrop
     * reads flat and every check still passes. */
    ridge(farBase, 16, 131, 149, 'rgba(52,60,80,0.46)');
    ridge(ridgeBase, 22, 31, 57, 'rgba(16,18,26,0.62)');

    const haze = g.createLinearGradient(0, 0, 0, horizon);
    haze.addColorStop(0, 'rgba(38,44,60,0.62)');
    haze.addColorStop(0.55, 'rgba(38,44,60,0.30)');
    haze.addColorStop(1, 'rgba(38,44,60,0)');
    g.fillStyle = haze;
    g.fillRect(0, 0, w, horizon);

    /* the horizon itself: one soft dark band, so scree does not simply stop */
    const grad = g.createLinearGradient(0, horizon - 18, 0, horizon + 10);
    grad.addColorStop(0, 'rgba(0,0,0,0)');
    grad.addColorStop(0.6, 'rgba(0,0,0,0.34)');
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = grad;
    g.fillRect(0, horizon - 18, w, 28);
  }

  /**
   * ⭐ THE STAR FIELD — the cheapest content in the game and the only thing above the far ridge.
   *
   * ⛔⛔ IT IS A SEPARATE CALL, AND THE ORDERING IS THE WHOLE POINT. `ui.js` paints a sky wash
   * (`rgba(6,6,12,0.82)` fading out by y=96) over the backdrop so the enemy nameplate is readable
   * against pale scree — a measured requirement, not a preference. Stars drawn inside `backdrop()`
   * sit UNDER that wash and under both ridge fills: at 0.42 + 0.55 + 0.82 of covering alpha a 0.3
   * star is gone. It would have rendered, thrown nothing, and produced a sky with no stars in it —
   * a green result from work that happened where nobody can see it. So this is called AFTER the
   * wash, by the one file that knows the wash exists.
   * ⚠️ BOUNDED ABOVE THE FAR RIDGE (`farBase - 6`), so a star never appears in front of a hill. The
   * bound is recomputed here from the same two constants `backdrop()` uses rather than passed in —
   * ⛔ and that is a shared fact with two copies, so both live on this line and move together.
   */
  function sky(g, w, horizon, seed) {
    const farBase = Math.max(12, Math.max(18, horizon - 62) - 34);
    const band = Math.max(4, farBase - 6);
    for (let i = 0; i < 44; i++) {
      const sx = Math.round(h32(i, 71, seed) * w);
      const sy = Math.round(h32(i, 83, seed) * band) + 2;
      const a = 0.30 + h32(i, 97, seed) * 0.45;
      g.fillStyle = `rgba(214,220,238,${a.toFixed(3)})`;
      g.fillRect(sx, sy, 1, 1);
      /* a handful of brighter ones with a cross flare, so the field is not uniform noise */
      if (h32(i, 109, seed) > 0.86) {
        g.fillStyle = `rgba(226,230,244,${(a * 0.7).toFixed(3)})`;
        g.fillRect(sx, sy - 1, 1, 3);
        g.fillRect(sx - 1, sy, 3, 1);
      }
    }
  }

  /**
   * Standing scenery. Placed from the same hash so a given seed always yields the same moor, and
   * kept OUT of the two bands the figures occupy (wing §0-ART-b: a prop must stand IN the ground,
   * so every prop tile here is one of the pack's `_on_*` variants' base form drawn over turf).
   */
  /**
   * ⛔⛔ `keepClear` — THE ENEMY'S OWN COLUMN, AND IT EXISTS BECAUSE OF SOMETHING ONLY THE COMPOSED
   * SCENE COULD SHOW.
   *
   * `_bestiary_sheet.js` proved all ten creatures have distinct silhouettes on a flat colour. Wing
   * §0-ART-b rule 5 warns in writing that a catalogue grid **destroys the arrangement**, so anything
   * that only goes wrong in the composition is invisible in it — and `_shot_creature.js` found
   * exactly that: THE BARROW WYRM, a tall pale grey coil, standing beside the **menhir**, a tall pale
   * grey standing stone, with `rocks` and the `cairn` under its feet. In the flame-OUT frame the two
   * pale masses are close to indistinguishable. The creature was competing with the furniture for the
   * one silhouette the player most needs to read.
   *
   * ⚠️ THE PROPS ARE DISPLACED, NEVER DROPPED, and that is the whole design of this fix. The previous
   * Gate A look recorded the stage's upper band as "sparse, the first thing to fix next"; deleting
   * three of seven props to clear a lane would trade a legibility bug for the emptiness that was
   * already the outstanding complaint. Each prop that would overlap the enemy's box slides to the
   * nearer side of it and stays on screen.
   *
   * ⚠️ And it is CONSERVATIVE about the enemy's width on purpose: the caller passes the real drawn
   * box (which now varies per creature via `drawScale`), so the lane widens for a boss and narrows
   * for a fen bat, rather than reserving one hand-typed gap that is wrong for both.
   */
  function scenery(g, w, horizon, seed, keepClear) {
    const spots = [
      { rel: 'menhir', x: 0.86, y: horizon - 46 },
      { rel: 'cairn', x: 0.60, y: horizon - 22 },
      { rel: 'boulder', x: 0.07, y: horizon - 14 },
      { rel: 'thorn', x: 0.30, y: horizon - 26 },
      { rel: 'gorse', x: 0.44, y: horizon - 12 },
      { rel: 'rocks', x: 0.73, y: horizon - 8 },
      { rel: 'fern', x: 0.19, y: horizon - 18 },
    ];
    let displaced = 0;
    spots.forEach((s, i) => {
      const t = img[`t_${s.rel}`];
      if (!t) return;
      const jitter = Math.floor((h32(i, 7, seed) - 0.5) * 40);
      let dx = Math.round(s.x * w) + jitter;
      const dw = t.naturalWidth * ZOOM;

      if (keepClear && dx < keepClear.x1 && dx + dw > keepClear.x0) {
        /* push to whichever side is nearer, then clamp on screen. A prop shoved off the canvas is
         * the same as a deleted one, so the clamp is not optional. */
        const centre = dx + dw / 2;
        const lane = (keepClear.x0 + keepClear.x1) / 2;
        dx = centre < lane ? keepClear.x0 - dw - 4 : keepClear.x1 + 4;
        dx = Math.max(2, Math.min(w - dw - 2, dx));
        displaced += 1;
      }

      g.drawImage(t, 0, 0, t.naturalWidth, t.naturalHeight,
        dx, Math.round(s.y), dw, t.naturalHeight * ZOOM);
    });
    /* ⛔ REPORTED, so a caller (and `_scenery_clearance.js`) can COUNT the work rather than trust the
     * verdict — master §2b rule 2. A silently-zero displacement would mean the lane is not reaching
     * the props at all, which looks exactly like "there was nothing to move". */
    return { props: spots.length, displaced };
  }

  /**
   * ⛔ THE LANTERN, AND IT IS THE GAME'S OWN RULE MADE VISIBLE. `combat.js` hides the telegraph when
   * the flame is OUT; until now the screen only *said* so in text. Here the light physically stops
   * reaching the enemy, which is what the mechanic has always claimed to be about.
   * The curve is `spike_battle_backdrop.js`'s, measured against every figure's edge contrast.
   */
  /* ⭐ `floor` — HOW DARK THE FAR SIDE OF THE LIGHT GETS, added 2026-09-02 for the overworld, and it
   * is a genuine DESIGN difference between the two screens rather than a knob:
   *   · COMBAT floors at 70. Wing §6b-5 rule 3: "too dark to see" is a mechanical failure, and the
   *     enemy must stay readable even at flame OUT or the fight becomes a guess about pixels rather
   *     than about locks. That 70 is half of a TUNED PAIR with the night grade below (§0z) and ⛔ must
   *     not be changed without re-opening both frames.
   *   · THE OVERWORLD floors at 0. Out there, what is beyond the lantern must be genuinely BLACK —
   *     unseen terrain is the information system, and a visible floor would draw the shape of the
   *     map through the dark and hand the player a free minimap.
   * Parameterised rather than forked: one lighting model, one owner, and the difference is named
   * here instead of drifting between two copies (§6d-10). */
  function light(g, w, stageH, cx, cy, radius, floor = 70) {
    /* ⭐ THE NIGHT GRADE, added 2026-09-02 after LOOKING at Gate A's frames side by side.
     * The flame-OUT frame was genuinely atmospheric; the flame-BRIGHT frame was a flat, saturated
     * MIDDAY MEADOW with a faint vignette — on a screen headed "SOMETHING IN THE DARK", in a game
     * whose entire premise is a lantern holding back the dark. The lighting was not broken (the
     * control frame proved that); the problem was that the scene was a DAY scene being darkened,
     * so the only thing hiding the daylight was the darkness itself. At full flame there was
     * nothing left to hide it.
     * ⇒ Grade the whole stage to night FIRST, uniformly, so the lantern's warm add below is the
     * only light source in the picture. Cool and desaturating, because moonlight is blue and
     * firelight is the only warm thing on a moor at night.
     * ⚠️ This darkens the flame-OUT case too, which was already correct — so the radial floor
     * below was raised 46 -> 70 in the same edit to hold that frame roughly where it was. The two
     * numbers are a PAIR; changing one without the other moves a frame that was already right. */
    g.save();
    g.globalCompositeOperation = 'multiply';
    g.fillStyle = 'rgb(150,160,190)';
    g.fillRect(0, 0, w, stageH);
    g.restore();

    /* darken away from the flame, to a floor that is dark but never black */
    const dark = g.createRadialGradient(cx, cy, 0, cx, cy, radius);
    dark.addColorStop(0, 'rgb(255,255,255)');
    dark.addColorStop(1, `rgb(${floor},${floor},${floor})`);
    g.save();
    g.globalCompositeOperation = 'multiply';
    g.fillStyle = dark;
    g.fillRect(0, 0, w, stageH);
    g.restore();
    /* and add the flame's own warmth back near the source */
    const warm = g.createRadialGradient(cx, cy, 0, cx, cy, radius);
    warm.addColorStop(0, 'rgba(255,206,140,0.30)');
    warm.addColorStop(0.55, 'rgba(255,186,110,0.10)');
    warm.addColorStop(1, 'rgba(0,0,0,0)');
    g.save();
    g.globalCompositeOperation = 'lighter';
    g.fillStyle = warm;
    g.fillRect(0, 0, w, stageH);
    g.restore();
  }

  /**
   * Draw one 64px sprite so its FEET land on `footY` and it is centred on `cx`.
   * ⛔ THE FOOT ROW IS MEASURED PER FRAME, NOT ASSUMED. `_measure_art_0901.js` read the real bboxes:
   * party feet sit at y=58..61 inside a 64 canvas and the undead at 56..63, so anchoring on the
   * canvas bottom would float every figure a different distance above the turf.
   */
  function figure(g, image, cx, footY, footRow, opts = {}) {
    if (!image) return;
    /* ⭐ `opts.scale` — PER-CREATURE DRAW SIZE, added 2026-09-02 after opening the bestiary contact
     * sheet. Every creature rendered at one size and the result was that THE BARROW WYRM, the final
     * boss, stood exactly as tall as a mid-slice common, while the OSSUARY OOZE carried the largest
     * health pool in the game (620) as one of the smallest figures on screen. **A player reads SIZE
     * as THREAT before they read a health bar**, so a flat scale was actively lying about the
     * difficulty curve — a §6d-14-class defect where every check agrees because the wrongness is
     * baked into all of them.
     * ⚠️ The scale multiplies the DRAWN size only; the foot anchor is recomputed from it so a bigger
     * creature still stands ON the turf rather than floating (the anchor is `footRow`, measured per
     * frame — see the note above — and it scales with the sprite or the whole measurement is void).
     * Default 1 reproduces every frame captured before today exactly. */
    const scale = opts.scale || 1;
    const s = SPRITE_PX * ZOOM * scale;
    const dx = Math.round(cx - s / 2 + (opts.dx || 0));
    const dy = Math.round(footY - (footRow + 1) * ZOOM * scale + (opts.dy || 0));
    g.save();
    if (opts.alpha !== undefined) g.globalAlpha = opts.alpha;
    /* a soft contact shadow, so the figure stands ON the turf instead of floating over it */
    if (opts.shadow !== false) {
      g.save();
      g.globalAlpha = (opts.alpha === undefined ? 1 : opts.alpha) * 0.38;
      g.fillStyle = '#000';
      g.beginPath();
      /* ⚠️ THE SHADOW SCALES WITH THE FIGURE. A bigger creature casting a common-sized shadow is the
       * "pasted onto the turf" reading the 2026-09-02 Gate A look already flagged as still-weak, and
       * a boss drawn 35% larger over an unchanged ellipse makes it worse rather than better. */
      g.ellipse(Math.round(cx + (opts.dx || 0)), Math.round(footY - 1),
        (opts.shadowW || 26) * scale, 6 * Math.sqrt(scale), 0, 0, Math.PI * 2);
      g.fill();
      g.restore();
    }
    g.drawImage(image, 0, 0, SPRITE_PX, SPRITE_PX, dx, dy, s, s);
    /* the hit flash: the sprite re-drawn as a solid silhouette, so it reads at any size */
    if (opts.flash) {
      g.globalCompositeOperation = 'source-atop';
      g.globalAlpha = opts.flash;
      g.fillStyle = '#fff';
      g.fillRect(dx, dy, s, s);
    }
    g.restore();
  }

  /** ⛔ The flash above must not paint the WHOLE canvas white when a browser lacks `source-atop`.
   * Drawing it inside a save/restore around the sprite's own rect is what bounds it; the rect is
   * derived from the same dx/dy the sprite used, never from the canvas. */

  const API = {
    ZOOM, CELL, SPRITE_PX, TILE_PX,
    ENEMY_FOR, ENEMY_ART, PARTY_ART,
    loadAll, backdrop, sky, scenery, light, figure, h32,
    get ready() { return ready; },
    get failed() { return failed.slice(); },
    img,
    /** Which enemy sprite key a fight should use — named encounters get theirs, generated fights
     * get a deterministic one from the seed so a re-run of the same seed shows the same monster. */
    enemyKey(enemyName, seed) {
      const named = enemyName && ENEMY_FOR[enemyName];
      if (named) return named;
      return ENEMY_ART[Math.floor(h32(seed | 0, 11, 3) * ENEMY_ART.length) % ENEMY_ART.length];
    },
    /** ⭐ How large this creature draws — see `figure`'s `opts.scale`. Keyed on the ART key rather
     * than the display name so it answers for a generated fight too, where there is no name.
     * ⚠️ Falls back to 1 rather than throwing: an unknown key means a sprite the bestiary does not
     * own, and drawing it at native size is a visible oddity, while throwing here would blank the
     * canvas mid-fight. Report-don't-refuse is right on the DRAW path and wrong on the LOAD path,
     * which is why `stage.js` still throws when the bestiary is missing entirely. */
    enemyScale(artKey) {
      const c = BESTIARY.CREATURES.find((x) => x.sprite.art === artKey);
      return (c && c.drawScale) || 1;
    },
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  if (typeof window !== 'undefined') window.LB_STAGE = API;
}());
