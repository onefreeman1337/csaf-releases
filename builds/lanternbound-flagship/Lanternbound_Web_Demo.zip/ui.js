'use strict';
/* ================================================================================================
 * LANTERNBOUND — the browser front end.
 * ================================================================================================
 * This exists for ONE reason: DESIGN §8 gate A, the ninety-second human test, which no bot can run.
 * Every rule comes from combat.js — the SAME file the balance bots drive — so what a human plays
 * here is the game the measurements describe.
 *
 * ⛔ THIS HEADER SAID "GREY BOXES ON PURPOSE" AND "IT DRAWS NO ART" UNTIL 2026-09-01, AND BY THEN
 * THAT SENTENCE WAS THE PROBLEM RATHER THAN A DISCLAIMER. Gate A was run, the frames were opened,
 * and it failed for exactly the reason the header licensed: a grey rectangle where a boss should
 * be, on a mostly empty black screen, on a project whose founding directive asked for "JRPG-style,
 * SNES-era graphics, cute anime styling, WITH MUSIC" (wing §0a-2). Several sessions had measured
 * win rates, oil margins and blackout timing on a game with no art. Master §1.1a is the correction:
 * THE LOOK IS THE PRODUCT. The stage now draws first-party art (stage.js) and this file's job is
 * the readout beneath it. ⚠️ Music and SFX are still absent and are still owed (§0-ART rule 4).
 *
 * ⛔ THE CLOCK IS MEASURED ELAPSED TIME, NEVER A FRAME COUNT (wing CLAUDE.md §1a). The automation
 * tab runs at `visibilityState:"hidden"` where rAF is throttled to zero, so a frame-counted flame
 * would read as frozen under exactly the conditions this gets tested under. `Combat` is constructed
 * with `externalClock:true` so it does not ALSO advance time inside act().
 */
(function () {
  const { Combat, DEFAULTS, classifyPress } = window.LB;

  /* ⛔ H WAS 460 AND IT CLIPPED A LEGAL ACTION. With all three characters still to act there are
   * NINE options (3 × 2 abilities + 3 relights); the list wraps at 4 per row from y=396 in 30 px
   * steps, so option 9 lands at y=456..480 and the ninth box was drawn off the bottom of a 460 px
   * canvas. Pressing "9" still worked, so the game was never wrong — it just never showed you one
   * of the things you could do. No test could see this: ui_smoke drives the model, not the pixels.
   * Found by photographing a real round and looking at it. */
  const W = 720; const H = 560;
  const cv = document.getElementById('screen');
  cv.width = W; cv.height = H;
  const g = cv.getContext('2d');

  /* ⭐ THE STAGE. Everything above y=STAGE_H is the fight as a PICTURE — first-party Highland turf,
   * the Wildmark party, a Mourncrest undead, lit by the lantern the game is named after. Everything
   * below it is the readout. Gate A failed on 2026-09-01 for one reason and it was not balance: the
   * enemy was a grey rectangle on empty black. Master §1.1a — the look IS the product.
   * ⛔ H WENT 500 -> 560 TO MAKE ROOM, AND THE ACTION LIST MOVED WITH IT. The comment above records
   * a legal ninth action drawn off the bottom of a 460 px canvas; the same arithmetic is redone here
   * and re-asserted every frame through `overflowY`, which is recorded from the ACTUAL draw. */
  /* ⛔⛔ THE STAGE WENT 236 -> 340 ON 2026-09-02, AND IT IS THE OPERATOR'S OWN COMPLAINT STATED AS
   * GEOMETRY. Gate A's frames were opened and measured that day; the light, the horizon, the tile
   * period, the shadows and the hit feedback all came back CORRECT (Devlog: three visual findings
   * measured and all three false). The one thing that survived was a ratio: **the scene had 236 of
   * 562 px = 42% of the screen and the form controls had 58%.** The 2026-08-31 directive says *"all
   * the games lately are like control a console and hit go"* — the combat underneath is timed and
   * continuous, but a SCREENSHOT cannot see a 260 ms timing window, and what a screenshot showed
   * was a diorama strip above a stack of widgets. SNES front-view JRPGs give the scene roughly two
   * thirds; 340/560 is 61%.
   * ⛔ THE SPACE WAS NOT INVENTED, IT WAS RECLAIMED: the party's three 216x44 readout boxes moved
   * ONTO the stage as nameplates under their own figures, which is both where a JRPG puts them and
   * where the player is already looking, and the lantern/telegraph/stack rows were folded from four
   * stacked rows into one three-column band. Nothing was deleted.
   * ⚠️ EVERY Y BELOW IS REDONE AGAINST THE CANVAS, NEVER OFFSET FROM THE OLD ONE — the same rule the
   * previous H 500 -> 560 move recorded, and for the same reason: an offset chain hides which row is
   * actually wrong when one of them collides. */
  const STAGE_H = 340;
  const HORIZON = 168;               /* where scree gives way to sward */
  const PARTY_FOOT_Y = 296;          /* the turf line the party stands on */
  const ENEMY_FOOT_Y = 280;          /* the undead stands further back, so slightly higher */
  /* ⭐ THE NAMEPLATE BAND — the party's status, on the stage, under their own feet. It must END
   * inside STAGE_H or the stage clip eats it, which is why PARTY_FOOT_Y leaves 44 px beneath.
   * ⚠️ AND IT MUST CLEAR THE LOWEST FOOT, NOT THE NOMINAL ONE. First written as PLATE_Y 306 against
   * PARTY_FOOT_Y 300 — but the depth stagger below pushes the nearest member DOWN by +6, so that
   * member's boots landed on exactly 306 and the plate touched them. The clearance is measured
   * against `PARTY_FOOT_Y + max(foot offset)`, which is the only number that means anything here.
   * Found in the first MID-FIGHT frame Gate A ever captured; the cold open could not show it,
   * because it is only obvious once the eye has somewhere else to be. */
  const PLATE_Y = 306;
  /* ⭐ DEPTH STAGGER. Three figures on one foot line at one scale read as a character-select lineup
   * — the second finding that survived the Gate A measurement. The party sprites are SOUTH idles by
   * deliberate choice (Wildmark's east/west frames carry known defects and south is the seed frame),
   * so the fix may never be a different facing; it has to be arrangement. Each member stands a few
   * pixels further forward or back and is drawn at the scale that depth implies, which is the
   * cheapest real depth cue there is after an occluding edge. */
  const PARTY_DEPTH = [
    { dx: -6, foot: +4, scale: 1.03 },   /* SABLE, nearest the camera */
    { dx: 0, foot: -8, scale: 0.96 },    /* WREN, furthest back */
    { dx: +5, foot: 0, scale: 1.0 },     /* OREN */
  ];
  /* ⛔ THE CLEARANCE, ASSERTED RATHER THAN ASSUMED. `PLATE_Y` must clear the LOWEST foot, and the
   * lowest foot is `PARTY_FOOT_Y + max(foot)`, not `PARTY_FOOT_Y`. This threw nothing when it was
   * wrong — the plate simply sat on a pair of boots — so it gets a load-time check rather than a
   * comment, and the plate must also finish inside the stage clip or the readout is silently eaten.
   * ⚠️ Deliberately a THROW: a status readout drawn over a character is a legibility bug on the one
   * surface the player reads under pressure, and the alternative is another defect that ships until
   * somebody happens to photograph the right frame. */
  {
    const lowestFoot = PARTY_FOOT_Y + Math.max(...PARTY_DEPTH.map((d) => d.foot));
    if (PLATE_Y < lowestFoot + 4) {
      throw new Error(`ui.js: PLATE_Y ${PLATE_Y} does not clear the lowest party foot ${lowestFoot} by 4px`);
    }
    if (PLATE_Y + 26 > STAGE_H) {
      throw new Error(`ui.js: the nameplate band ends at ${PLATE_Y + 26}, past the stage clip at ${STAGE_H}`);
    }
  }
  /* ⭐ THE LANTERN SITS WITH THE PARTY, NOT IN THE MIDDLE OF THE FIELD. DESIGN §4 says losing the
   * flame costs you information about the ENEMY, and `spike_battle_backdrop.js` warned in writing
   * that a badly-placed light takes your own party first — "the lantern stops being a tension
   * mechanic and becomes a legibility bug". Centred on the canvas it lit empty grass; leaned toward
   * the party the thing that fades as the flame dies is the enemy, which is the mechanic. */
  /* ⚠️ CY MOVED 150 -> 236 WITH THE STAGE. It is not a free constant: it must sit ON the party, and
   * the party's feet moved 222 -> 300. Left at 150 the pool would have lit the empty slope above
   * them and the figures would have stood in their own shadow — the exact "the lantern takes your
   * own party first" failure `spike_battle_backdrop.js` warned about in writing. */
  const LIGHT_CX = 320; const LIGHT_CY = 236;

  /* The stage renderer, if it loaded. ⛔ EVERY USE IS GUARDED: `ui_smoke.js` runs this file in a
   * sandbox with no `Image` and no stage.js at all, and a 404 on any asset must degrade to the old
   * readable screen rather than to a blank canvas. Art is allowed to be missing; the game is not
   * allowed to disappear when it is. */
  const ST = (typeof window !== 'undefined' && window.LB_STAGE) ? window.LB_STAGE : null;
  let artReady = false;
  let artFailed = [];
  if (ST && typeof Image !== 'undefined') {
    ST.loadAll().then((r) => {
      artReady = r.ready; artFailed = r.failed;
      if (!r.ready) console.warn('[LB] stage art incomplete:', r.failed);
    });
  }

  /* ⭐ AUDIO. Guarded exactly like the art: `ui_smoke.js` has no Web Audio at all, and a browser
   * keeps the context suspended until a user gesture, so every call below must be safe as a no-op.
   * A silent game must still be a playable one — audio is an enhancement, never a dependency. */
  const AU = (typeof window !== 'undefined' && window.LB_AUDIO) ? window.LB_AUDIO : null;
  function au(fn, ...args) { if (AU && AU[fn]) { try { return AU[fn](...args); } catch (e) { /* never break the game for a sound */ } } return null; }

  /* The four colours are GAME STATE, not decoration, so they are drawn as colours. Everything
   * else is grey — this prototype must never be mistaken for a look. */
  const COLOUR_HEX = { EMBER: '#d9723a', AZURE: '#4a8fc4', VERDANT: '#5f9e57', PALE: '#b9b2c9' };

  let combat = null;
  let phase = 'choose';          // choose | timing | resolved | over
  let pending = null;            // {actorId, abilityId}
  let sweepStart = 0;            // performance.now() at bar start
  let lastQuality = null;
  let lastFlash = 0;
  let seed = 1;
  let lastT = 0;
  let banner = '';
  /* 'good' | 'near' | 'bad' — WHICH of the three round outcomes the banner is reporting. Kept
   * beside the string rather than re-derived from it, because matching on banner TEXT is how a
   * colour silently goes wrong the next time the wording changes. */
  let bannerTone = 'bad';
  let overflowY = 0;             // lowest pixel the action list actually drew to, this frame

  /* ⭐ THE FEEDBACK LAYER — operator directive 2026-08-31 (§0a-2): "all the games lately are like
   * control a console and hit go... I want more flowing fun games." The MECHANIC here is turn based
   * and stays that way; what was missing is that nothing on screen ever MOVED. These four pieces of
   * state are the whole difference between a form and a fight, and every one of them is derived
   * from the model rather than scripted beside it:
   *   hitAt/hitAmount   the enemy is struck   -> a white flash and a shake, from a real hp delta
   *   lungeUntil        the actor steps in    -> which figure acted, from the committed action
   *   floats[]          damage and press quality rise off the enemy and fade
   *   lastEnemyHp       so a delta can be SEEN rather than announced
   * ⛔ NONE OF IT TOUCHES combat.js. The bots drive the same model they always did. */
  let lastEnemyHp = null;
  let hitAt = -1e9; let hitAmount = 0;
  let lungeActor = null; let lungeUntil = 0;
  let floats = [];

  /* ⭐ THE CARRY-IN. DESIGN §4: "a fight starts with the flame you WALKED IN WITH." When the
   * overworld page hands off it leaves the carried flame and oil here; this is the only place that
   * claim becomes true rather than asserted.
   * ⚠️ Guarded on every side. With no sessionStorage, no carry, or a malformed one, the fight uses
   * the tuned defaults exactly as before — which is also why `ui_smoke` (which stubs the DOM and
   * sets nothing) still measures the same 23 constants it always did. */
  function readCarry() {
    try {
      if (typeof sessionStorage === 'undefined') return null;
      const raw = sessionStorage.getItem('LB_CARRY');
      if (!raw) return null;
      sessionStorage.removeItem('LB_CARRY');
      const c = JSON.parse(raw);
      if (!c || typeof c.flame !== 'number' || !isFinite(c.flame)) return null;
      return {
        flame: Math.max(0, Math.min(100, c.flame)),
        oil: Math.max(0, c.oil | 0),
        /* ⭐ WHICH CREATURE (2026-09-02). Validated against the ROSTER, not merely typechecked: a
         * carry naming a creature that does not exist must fall back to a generated fight, never
         * throw and never silently draw the wrong body. sessionStorage is player-writable. */
        creature: (typeof c.creature === 'string' && c.creature) ? c.creature : null,
        /* ⭐⭐ THE WALK, CARRIED OPAQUELY SO THE FIGHT CAN HAND YOU BACK (2026-09-02). This page does
         * not read a single field of `resume` and must not start: the world's shape has exactly one
         * owner (`overworld.js`), and a combat screen that learns what a monster list looks like is
         * a second opinion waiting to disagree. It is a token — held, and returned. */
        resume: (c.resume && typeof c.resume === 'object') ? c.resume : null,
        monsterIndex: Number.isInteger(c.monsterIndex) ? c.monsterIndex : -1,
      };
    } catch (e) { return null; }
  }

  let carried = null;

  /* ⭐ THE AUTHORED TEACHERS (encounters.js). MEASURED 2026-09-01 (`skill_grid.js`): a player who
   * understands the colours but not the ORDERING rule wins 0.0% of generated fights — a flat row at
   * every timing skill. A generated lock set cannot teach that rule because it changes every round,
   * so the player cannot tell whether they failed on colours, on order or on timing. The first two
   * fights are hand-built to isolate one variable each and REPEAT ONE LOCK, so a failure can be
   * re-attempted against the same puzzle. Every claim about them is proven by exhaustive search in
   * `encounter_gates.js` (25/25, 5/5 sabotage arms firing).
   * ⚠️ Guarded exactly like the carry-in: if encounters.js is not loaded, the front end falls back
   * to generated fights and behaves precisely as it did before. */
  const ENC = (typeof window !== 'undefined' && window.LB_ENC) ? window.LB_ENC : null;
  /* the roster, for turning a carried creature id into a real fight. Guarded exactly like ENC: if
   * bestiary.js is not loaded the ambush falls back to a generated fight and behaves as before. */
  const BEST = (typeof window !== 'undefined' && window.LB_BESTIARY) ? window.LB_BESTIARY : null;
  let encounter = null;

  /**
   * ⛔ AN OVERWORLD AMBUSH IS NEVER A TEACHER. The teachers happen at the road shrines, in shrine
   * light, with a fixed lock; an ambush is whatever caught you, with the flame you walked in with.
   * Mixing them would put a scripted puzzle behind a random amount of light and teach nothing.
   */
  function newFight(s, encId) {
    seed = s;
    carried = readCarry();
    if (carried) {
      encounter = null;
      /* ⭐ THE AMBUSH IS NOW THE CREATURE THAT CAUGHT YOU. Until 2026-09-02 every ambush was one
       * generated fight with default stats, so the eight roamers in the bestiary — built, gated,
       * photographed — could not be met by playing. `combatOptions` merges the creature's own cfg
       * (hp, damage, hardening, lock) and the CARRY overrides the lantern on top, in that order:
       * the creature decides the fight, the walk decides the light. */
      const cr = (BEST && carried.creature) ? BEST.byId(carried.creature) : null;
      const base = cr
        ? BEST.combatOptions(cr, { seed: s, externalClock: true })
        : { seed: s, externalClock: true, cfg: {} };
      base.externalClock = true;
      base.cfg = { ...(base.cfg || {}), startFlame: carried.flame, oilCharges: carried.oil };
      combat = new Combat(base);
      /* ⛔ SETTING THE NAME IS THE WHOLE WIRING, AND DELIBERATELY SO. `stage.js` already owns the
       * name -> sprite map (`ENEMY_FOR`, derived from this same roster), and the draw path resolves
       * it via `ST.enemyKey(enemy.name)`. Caching an art key here would be a SECOND copy of that
       * mapping — the shared-fact defect (§6d-10) — and the two would drift the first time a
       * creature was renamed. One fact, one owner. */
      if (cr) combat.enemy.name = cr.name;
      banner = cr
        ? `AMBUSHED BY ${cr.name} — you fight with the lantern you walked in with`
        : 'AMBUSHED — you fight with the lantern you walked in with';
    } else if (ENC && encId !== null) {
      encounter = ENC.encounterById(encId) || ENC.firstEncounter();
      combat = new Combat(ENC.combatOptions(encounter, { seed: s, externalClock: true }));
      banner = '';
    } else {
      encounter = null;
      combat = new Combat({ seed: s, externalClock: true });
      banner = '';
    }
    phase = 'choose'; pending = null; lastQuality = null;
    lastT = performance.now();
    /* ⛔ RESET THE FEEDBACK LAYER WITH THE FIGHT. A damage number left over from the last encounter
     * would float above a fresh enemy and read as a hit that never happened. */
    lastEnemyHp = combat.enemy.hp; hitAt = -1e9; hitAmount = 0;
    lungeActor = null; lungeUntil = 0; floats = [];
    /* the battle theme, restarted only when it is not already the thing playing (playMusic is a
     * no-op on a repeat call, so an encounter chain does not restart the music every fight) */
    au('playMusic', 'mus_battle');
  }

  /**
   * What comes after the current fight.
   * ⛔ A LOSS REPEATS THE SAME ENCOUNTER. That is the entire mechanism by which a teacher teaches:
   * the lock is fixed, so the second attempt is the same puzzle with one fact more. Re-rolling it
   * after a failure would hand the player a new problem at exactly the moment they had learned
   * something about the old one.
   */
  function advance() {
    if (!encounter) { newFight(seed + 1, null); return; }
    if (combat && combat.result !== 'WIN') { newFight(seed + 1, encounter.id); return; }
    const next = ENC.nextEncounter(encounter.id);
    newFight(seed + 1, next ? next.id : null);
  }

  /**
   * ⭐⭐ HAND THE PLAYER BACK TO THE WALK — the leg that did not exist until 2026-09-02.
   *
   * ⛔ THE SHAPE IS DELIBERATE: this page writes a blob it did not author and does not read. The
   * snapshot came from `overworld.js` (`world.snapshot()`), rode in on `LB_CARRY`, and rides out on
   * `LB_RETURN` with exactly three things ADDED — the lantern the fight ended on, the oil left, and
   * whether it was won. Everything else about a walk stays the overworld's business, so there is no
   * second definition of a world anywhere on this page (§6d-10).
   * ⚠️ THE LANTERN THAT COMES BACK IS THE ONE THE FIGHT ENDED ON, not the one it started with. That
   * is the whole point of the resource: a long fight costs you the light you continue on, and if it
   * went out in there you walk out of it in the dark.
   */
  function returnToWalk() {
    try {
      sessionStorage.setItem('LB_RETURN', JSON.stringify({
        resume: carried.resume,
        monsterIndex: carried.monsterIndex,
        flame: combat ? combat.flame : 0,
        oil: combat ? combat.oil : 0,
        won: !!(combat && combat.result === 'WIN'),
      }));
      /* the page name is declared in `paths.js`, because a shipped build renames both halves of
       * this seam (the overworld becomes `index.html`) — see the note there */
      window.location.href = (window.LB_PATHS && window.LB_PATHS.pages.overworld) || 'overworld.html';
    } catch (e) {
      /* no sessionStorage: stay on the result card rather than navigating to a walk that would
       * silently restart from the beginning of the moor */
      banner = 'CANNOT RETURN — storage unavailable';
      bannerTone = 'bad';
    }
  }

  /* -- input ------------------------------------------------------------------------------- */
  function options() { return combat ? combat.availableActions() : []; }

  window.addEventListener('keydown', (e) => {
    if (e.repeat) return;
    /* ⛔ THE FIRST KEYPRESS IS THE GESTURE THAT UNLOCKS AUDIO. Browsers start an AudioContext
     * SUSPENDED and every later start() is then silent with NO ERROR ANYWHERE — the commonest way
     * game audio works in development and ships mute. Resuming here means the very first thing the
     * player does turns the sound on, and they never see a "click to enable audio" gate. */
    au('resume');
    if (e.code === 'KeyM') { au('toggleMute'); e.preventDefault(); return; }
    if (phase === 'over') {
      /* ⭐⭐ BACK TO THE WALK — the return leg of a seam that was one way until 2026-09-02. Offered
       * ONLY when this fight was reached from the overworld, because on a standalone combat page
       * there is nothing to go back to and a key that promises a place you cannot reach is worse
       * than no key. `R` keeps its old meaning in both cases, so nothing that existed before moves. */
      if (e.code === 'Space' && carried && carried.resume) { returnToWalk(); e.preventDefault(); return; }
      if (e.code === 'KeyR') { advance(); e.preventDefault(); }
      return;
    }
    if (phase === 'choose') {
      const n = parseInt(e.key, 10);
      const opts = options();
      if (n >= 1 && n <= opts.length) {
        pending = opts[n - 1];
        phase = 'timing';
        sweepStart = performance.now();
        au('sfx', 'select');
        e.preventDefault();
      }
      return;
    }
    if (phase === 'timing' && e.code === 'Space') {
      const at = performance.now() - sweepStart;
      commit(classifyPress(at, combat.cfg));
      e.preventDefault();
    }
  });

  function commit(quality) {
    lastQuality = quality; lastFlash = performance.now();
    const before = combat.round;
    /* ⛔ THE DAMAGE NUMBER IS A MEASURED DELTA, NEVER THE ABILITY'S `power`. A press quality, the
     * warden's hardening and a dead actor all change what actually lands, so reading `power` off the
     * roster would print a number the fight did not use — master §2's honesty rule pointed at a
     * pixel. Read hp either side of act() and show the difference. */
    const hpBefore = combat.enemy.hp;
    const actor = pending.actorId;
    combat.act(pending.actorId, pending.abilityId, quality);
    const dealt = hpBefore - combat.enemy.hp;
    const now = performance.now();
    if (dealt > 0) {
      hitAt = now; hitAmount = dealt;
      floats.push({ t: `-${dealt}`, colour: '#f0e0c0', size: 22, at: now, dy: 0 });
    }
    floats.push({
      t: quality.toUpperCase(),
      colour: quality === 'perfect' ? '#8fd07f' : quality === 'good' ? '#d0c87f' : '#d08f7f',
      size: 14, at: now, dy: 22,
    });
    /* keep the list bounded — a long fight must not grow an unbounded array behind the screen */
    if (floats.length > 12) floats = floats.slice(-12);
    lungeActor = actor; lungeUntil = now + 260;
    pending = null;

    /* ⭐ THE EAR AND THE EYE DESCRIBE THE SAME EVENT. Every cue below fires off the SAME model
     * change that moved a pixel: the press quality that drew the float, the hp delta that drew the
     * flash, the log line that set the banner. Nothing here is a second source of truth. */
    au('sfx', quality);
    if (dealt > 0) au('sfx', 'hit');

    if (combat.over) {
      phase = 'over'; banner = combat.result;
      if (combat.result === 'WIN') au('sting', 'mus_victory'); else au('sfx', 'down');
      return;
    }
    if (combat.round !== before) {
      const last = combat.log.filter((l) => l.includes('lock')).pop() || '';
      const broke = last.includes('BROKEN');
      /* ⭐⭐ THE THIRD OUTCOME, AND IT IS THE ENTIRE POINT OF `cfg.buriedRelief`.
       * Until 2026-09-02 this line said LOCK BROKEN or THE LOCK LANDS and nothing else — so a
       * player who assembled both colours the screen asked for, in the wrong order, was told
       * exactly what a player who ignored the telegraph completely was told, and hit for exactly
       * the same amount. The game gave IDENTICAL feedback for "you nearly had it" and "you did not
       * try", to a player MEASURED to do the former in 40.0% of the rounds they lose
       * (`_burial_shape.js`, against the planner's 6.1%).
       * ⛔ The model now blunts that blow, and a mechanic the screen never mentions is a mechanic
       * that does not exist to the player (§6b-9 rule 5) — which would have made the whole fix
       * invisible and left the on-ramp exactly as steep as it was.
       * ⚠️ Derived from the SAME log line as `broke`, not from a second read of the model. */
      const buried = last.includes('BURIED IT');
      banner = broke ? 'LOCK BROKEN' : buried ? 'YOU HAD IT — AND BURIED IT' : 'THE LOCK LANDS';
      /* amber, not red: a near miss is not the same event as a clean hit, and the colour is the
       * fastest thing on screen to read */
      bannerTone = broke ? 'good' : buried ? 'near' : 'bad';
      au('sfx', broke ? 'lockBroken' : 'lockLanded');
    }
    phase = 'choose';
  }

  /* -- loop -------------------------------------------------------------------------------- */
  function frame(now) {
    if (!combat) { requestAnimationFrame(frame); return; }
    /* ⛔ MEASURED ELAPSED TIME. Clamped so an alt-tab of thirty seconds does not silently kill the
     * lantern while nobody was looking — a pause is not play. */
    const dt = Math.min(now - lastT, 100);
    lastT = now;
    const flameBefore = combat.flame;
    const stateBefore = combat.flameState;
    if (phase !== 'over') combat.tick(dt);

    /* ⭐ THE LANTERN, HEARD. The filter follows the CONTINUOUS flame, not the three named states, so
     * the world closes down gradually instead of stepping at two thresholds — a step would announce
     * the threshold, and the whole design is that you feel the light going rather than get told.
     * ⚠️ Driven from the model every frame, so it can never disagree with the picture. */
    au('setFlame', combat.flame / combat.cfg.flameMax);
    /* the two transitions worth a SOUND rather than a slope */
    if (stateBefore !== 'OUT' && combat.flameState === 'OUT') au('sfx', 'guttering');
    if (combat.flame > flameBefore + 1) au('sfx', 'relight');

    /* a sweep that runs off the end is a MISS, and it must resolve itself or the game hangs */
    if (phase === 'timing' && now - sweepStart > combat.cfg.sweepMs) commit('miss');

    draw(now);
    requestAnimationFrame(frame);
  }

  /* -- drawing ------------------------------------------------------------------------------ */
  function box(x, y, w, h, fill, stroke) {
    if (fill) { g.fillStyle = fill; g.fillRect(x, y, w, h); }
    if (stroke) { g.strokeStyle = stroke; g.lineWidth = 2; g.strokeRect(x + 1, y + 1, w - 2, h - 2); }
  }
  /* Greedy word wrap. ⚠️ Character-counted, not pixel-measured, and that is a deliberate limit:
   * `measureText` is stubbed in the headless smoke test, so a pixel-measured wrap would be checked
   * against a constant there and prove nothing. WRAP_COLS is set for the 11 px face used below with
   * the enemy box at x>=290 as the hard edge; the real proof is a photographed frame. */
  const WRAP_COLS = 36;
  function wrap(s, cols) {
    const out = []; let line = '';
    for (const w of String(s).split(/\s+/)) {
      if (!line) { line = w; } else if ((line + ' ' + w).length <= cols) { line += ' ' + w; } else { out.push(line); line = w; }
    }
    if (line) out.push(line);
    return out;
  }

  function text(s, x, y, size = 13, colour = '#ddd', align = 'left') {
    g.fillStyle = colour; g.textAlign = align;
    g.font = `${size}px ui-monospace, Consolas, monospace`;
    g.fillText(s, x, y);
  }

  /* How much of the lock is already standing on top of the stack: the largest n such that the last
   * n of the stack equal the first n of the lock. This is the quantity the whole round is played
   * against, and it was previously computed nowhere and displayed nowhere. */
  function lockProgress(stack, lock) {
    if (!lock || !lock.length) return 0;
    const s = stack.filter(Boolean);
    for (let n = Math.min(lock.length, s.length); n > 0; n--) {
      if (s.slice(-n).join('>') === lock.slice(0, n).join('>')) return n;
    }
    return 0;
  }

  /* ================================================================================================
   * THE STAGE. Drawn first, under everything, and it is the reason this file exists at all now.
   * ============================================================================================== */
  function drawStage(now, c, r) {
    const seed0 = (encounter ? encounter.id.length * 31 : 0) + (seed | 0);

    /* ⛔⛔ CLIP THE WHOLE STAGE, AND IT IS NOT TIDINESS — IT WAS A VISIBLE DEFECT.
     * `backdrop()` lays 64 px tile rows, so the last row starts at y=192 and runs to 256 — TWENTY
     * pixels past STAGE_H. The lantern's multiply pass covers only 0..STAGE_H, so those twenty
     * pixels were the ONLY unlit thing on screen: a strip of full-brightness daylight grass sitting
     * under a night scene, with the round banner printed green-on-green on top of it. Found by
     * opening the captured frames, invisible to every check in this project — the smoke test drives
     * the model and the capture harness only counts console errors. */
    g.save();
    g.beginPath(); g.rect(0, 0, W, STAGE_H); g.clip();

    /* ⛔ RESOLVED BEFORE THE BACKDROP, BECAUSE THE SCENERY NEEDS TO KNOW WHERE THE ENEMY WILL STAND.
     * `scenery()` takes a keep-clear lane so a tall pale prop does not end up shoulder to shoulder
     * with a tall pale creature (see the note on `scenery` in stage.js — found by photographing the
     * barrow wyrm beside the menhir, invisible on any contact sheet). The lane is the creature's REAL
     * drawn box, which varies with `drawScale`, so it widens for a boss and narrows for a fen bat. */
    const eCx0 = 512;
    const enemyName0 = c.enemy.name || (encounter && encounter.enemyName) || 'SOMETHING IN THE DARK';
    const eKey0 = ST ? ST.enemyKey(enemyName0, seed0) : null;
    const eScale0 = (ST && ST.enemyScale) ? ST.enemyScale(eKey0) : 1;
    const eHalf0 = (64 * 2 * eScale0) / 2;
    const keepClear = { x0: Math.round(eCx0 - eHalf0) - 10, x1: Math.round(eCx0 + eHalf0) + 10 };

    if (artReady) {
      ST.backdrop(g, W, STAGE_H, HORIZON, seed0);
      /* the night sky: a dark wash over the scree, so the nameplate has something to sit on. The
       * scree tiles are pale and the readout above them was measured unreadable against them. */
      const sky = g.createLinearGradient(0, 0, 0, 96);
      sky.addColorStop(0, 'rgba(6,6,12,0.82)');
      sky.addColorStop(1, 'rgba(6,6,12,0)');
      g.fillStyle = sky; g.fillRect(0, 0, W, 96);
      ST.scenery(g, W, HORIZON, seed0, keepClear);
    } else {
      /* ⛔ THE HONEST FALLBACK. If the art did not load the screen must still be PLAYABLE, so this
       * is the old flat field — not a blank canvas, and visibly not the real thing. */
      g.fillStyle = '#15171a'; g.fillRect(0, 0, W, HORIZON);
      g.fillStyle = '#1b2119'; g.fillRect(0, HORIZON, W, STAGE_H - HORIZON);
    }

    /* -- the enemy -------------------------------------------------------------------------- */
    const shake = (now - hitAt < 220) ? Math.round(Math.sin((now - hitAt) / 18) * (1 - (now - hitAt) / 220) * 7) : 0;
    const flash = (now - hitAt < 150) ? 0.72 * (1 - (now - hitAt) / 150) : 0;
    const eCx = eCx0;
    /* ⛔⛔ ONE NAME, RESOLVED ONCE — AND UNTIL 2026-09-02 THERE WERE TWO, WHICH IS HOW THE SCREEN
     * CAME TO SHOW A WYRM LABELLED "BONE HOUND".
     *
     * The SPRITE was chosen from `c.enemy.name || encounter.enemyName` while the NAMEPLATE was drawn
     * from `encounter.enemyName` alone. Two sources of truth for one fact — wing §6d-14's shape,
     * where the artefact and the label agree on a lie because nobody asked which one was authoritative.
     * It could not bite while the game had only two authored teachers, whose two sources always
     * agree. ⭐ THE BESTIARY IS EXACTLY THE THING THAT MAKES THEM DISAGREE: a generated fight has no
     * `encounter`, so the nameplate would have read "SOMETHING IN THE DARK" over a perfectly
     * identifiable Iron Warden — or, on a retry after an authored fight, a STALE creature's name over
     * a different creature's body.
     * ⚠️ FOUND BY PHOTOGRAPHING IT (`_shot_creature.js`), not by any check, and the shot that found
     * it was aimed at something else entirely. Wing §6b-3 rule 4, fourth time in this wing. */
    const enemyName = enemyName0;   /* resolved above, before the scenery lane */
    if (artReady) {
      /* ⭐ THE ONLY THING ON THIS SCREEN THAT MOVES WITHOUT THE PLAYER. Mourncrest ships a 3-frame
       * WALK and no idle, so the battle idle is that walk played slowly in place — which is exactly
       * what an undead sway looks like, and §0a-2 asks for state that changes under the player. */
      const key = eKey0;
      const fr = Math.floor(now / 420) % 3;
      const bob = Math.round(Math.sin(now / 700) * 2);
      /* ⭐ SIZE IS THE FIRST THING A PLAYER READS ABOUT A MONSTER, and until 2026-09-02 every
       * creature drew at exactly one size — so the final boss stood as tall as a mid-slice common
       * and the 620-HP ooze was among the smallest things on screen. The scale is the bestiary's,
       * looked up by art key, so the picture and the difficulty curve cannot drift apart. */
      ST.figure(g, ST.img[`e_${key}_${fr}`], eCx + shake, ENEMY_FOOT_Y + bob, 61,
        { flash, shadowW: 30, scale: eScale0 });
    } else {
      box(eCx - 70 + shake, ENEMY_FOOT_Y - 110, 140, 110, '#3a3a42', '#6a6a76');
    }

    /* -- the party -------------------------------------------------------------------------- */
    /* ⛔ DRAWN BACK TO FRONT. With a depth stagger the figures can now overlap, and painter's order
     * is the only thing that makes an overlap read as depth rather than as a mistake. Sorted by
     * foot line — the one further UP the stage is further away, so it is drawn first. The nameplates
     * are a SEPARATE pass below, because a plate drawn between two figures would be occluded by the
     * nearer one and a status readout must never be half-hidden. */
    const partyOrder = c.party.map((p, i) => i)
      .sort((a, b) => (PARTY_FOOT_Y + (PARTY_DEPTH[a] || {}).foot) - (PARTY_FOOT_Y + (PARTY_DEPTH[b] || {}).foot));
    const partyCx = (i) => 96 + i * 104 + ((PARTY_DEPTH[i] || {}).dx || 0);
    partyOrder.forEach((i) => {
      const p = c.party[i];
      const d = PARTY_DEPTH[i] || { dx: 0, foot: 0, scale: 1 };
      const cx = partyCx(i);
      const down = p.hp <= 0;
      const lunging = lungeActor === p.id && now < lungeUntil;
      const step = lunging ? Math.round(Math.sin((1 - (lungeUntil - now) / 260) * Math.PI) * 18) : 0;
      /* a slow individual bob so three standing figures do not read as one static row */
      const bob = down ? 0 : Math.round(Math.sin(now / 820 + i * 2.1) * 2);
      if (artReady) {
        ST.figure(g, ST.img[`p_${ST.PARTY_ART[i] || 'sable'}`], cx + step, PARTY_FOOT_Y + d.foot + bob, 58,
          { alpha: down ? 0.28 : 1, shadowW: 22, scale: d.scale });
      } else {
        box(cx - 22 + step, PARTY_FOOT_Y + d.foot - 96, 44, 96, down ? '#1c1c20' : '#2c2c34', '#4a4a54');
      }
    });

    /* -- the party's nameplates, ON the stage under their own feet -------------------------- *
     * ⭐ THIS IS WHERE THE 56 PX CAME FROM. Three 216x44 boxes used to sit in their own row below
     * the stage, naming figures the player was looking at somewhere else. A JRPG puts the status on
     * the character; so does this, and the stage got the difference.
     * ⛔ ON A PLATE, NOT ON THE GRASS. Text straight over lit turf is the legibility failure this
     * wing has already recorded twice; the plate is dark and slightly translucent so the scene shows
     * through without the numbers competing with it.
     * ⚠️ The plate row is FLAT even though the figures are staggered — a ragged row of readouts
     * reads as a bug, and 7 px of depth is invisible at this distance anyway. */
    c.party.forEach((p, i) => {
      const cx = partyCx(i);
      const down = p.hp <= 0;
      const pw = 92;
      const px0 = Math.round(cx - pw / 2);
      g.save();
      g.globalAlpha = 0.72;
      box(px0, PLATE_Y, pw, 26, down ? '#180f0f' : '#0d0f12', p.acted ? '#3a3a44' : '#7a7a8a');
      g.restore();
      text(down ? 'DOWN' : p.name, px0 + 6, PLATE_Y + 12, 11, down ? '#c06a6a' : '#ddd');
      text(`${Math.max(0, p.hp)}`, px0 + pw - 6, PLATE_Y + 12, 11, down ? '#7a5a5a' : '#aaa', 'right');
      box(px0 + 6, PLATE_Y + 17, pw - 12, 5, '#25252b');
      box(px0 + 6, PLATE_Y + 17, (pw - 12) * Math.max(0, p.hp / p.maxHp), 5, down ? '#444' : '#5f9e57');
    });

    /* -- the lantern ------------------------------------------------------------------------- */
    if (artReady) ST.light(g, W, STAGE_H, LIGHT_CX, LIGHT_CY, r);
    /* ⛔⛔ THE STARS GO ON AFTER THE LIGHT, AND THE FIRST ATTEMPT PUT THEM BEFORE IT — CODE RAN,
     * NOTHING ERRORED, AND THE PICTURE WAS INDISTINGUISHABLE FROM THE ONE BEFORE THE EDIT.
     * `light()` is a MULTIPLY over the whole stage: the night grade (~0.63) times a radial that
     * floors at 70/255 far from the flame, so the top of a 340 px stage is scaled by roughly 0.17
     * before anything else. MEASURED by `_stage_look.js --profile`: the sky bands run mean 7.8-23.9
     * against a ground at 47-59. Anything drawn up there as a LIT SURFACE is crushed.
     * ⭐ THE PRINCIPLE, and it is physics rather than a workaround: a star is EMISSIVE. Multiplying
     * it by the lantern's falloff says the lantern illuminates the sky, which is exactly backwards.
     * The floating damage text a few lines below is drawn after the light for the same reason and
     * says so in its own comment — this is that rule applied to the one other emissive thing on
     * screen. The RIDGES stay before the light, because a hillside IS a lit surface.
     * ⚠️ Guarded: `ui_smoke` runs this file with no stage.js at all. */
    if (artReady && ST.sky) ST.sky(g, W, HORIZON, seed0);
    else {
      const grad0 = g.createRadialGradient(LIGHT_CX, LIGHT_CY, 20, LIGHT_CX, LIGHT_CY, r);
      grad0.addColorStop(0, 'rgba(255,214,150,0.13)');
      grad0.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = grad0; g.fillRect(0, 0, W, STAGE_H);
    }

    /* -- floating combat text, ABOVE the light so a damage number is never swallowed by the dark --
     * ⛔ SUPPRESSED ONCE THE FIGHT IS OVER, for the same reason the banner and the old corner
     * readout are (GATE A FINDING 3): the last press of a fight means nothing on a result screen,
     * and a `-4 GOOD` still hanging over a dead enemy behind the WIN card is that finding growing
     * back through a new code path. Caught by opening 009_combat_result_win.png. */
    floats = (phase === 'over') ? [] : floats.filter((f) => now - f.at < 900);
    for (const f of floats) {
      const age = (now - f.at) / 900;
      g.save();
      g.globalAlpha = Math.max(0, 1 - age * age);
      text(f.t, eCx, ENEMY_FOOT_Y - 118 + f.dy - Math.round(age * 34), f.size, f.colour, 'center');
      g.restore();
    }

    /* -- the enemy's nameplate, over the stage like a boss bar -------------------------------- */
    const eName = enemyName;   /* ⛔ ONE resolver, above — see the note at `const enemyName` */
    const ehp = c.enemy.hp / c.enemy.maxHp;
    text(eName, W / 2, 26, 13, '#d8d0c0', 'center');
    box(W / 2 - 130, 34, 260, 9, 'rgba(8,8,10,0.72)', '#5a5a66');
    box(W / 2 - 128, 36, 256 * Math.max(0, ehp), 5, ehp > 0.35 ? '#b8545a' : '#e07a44');
    text(`${c.enemy.hp} / ${c.enemy.maxHp}`, W / 2, 58, 11, '#c4bcac', 'center');

    /* ⭐ THE WARDEN, DRAWN — combat.js `enemyHardens`. Shown ALWAYS and NOT gated on the lantern: the
     * lantern hides the TELEGRAPH (what the enemy will do next), while this is a fact about its body
     * that you learned by hitting it. An adaptation the player cannot see is not difficulty, it is a
     * rule they can never learn. */
    /* ⛔⛔ IT DRAWS THE LIST, NOT THE LATEST — AND DRAWING THE LATEST WAS A LIVE DEFECT FROM THE
     * MOMENT THE BESTIARY LANDED (2026-09-02). Two creatures hold more than one hardened colour:
     * THE IRON WARDEN is plated against EMBER for the whole fight (`hardenedFixed`) and THE BARROW
     * WYRM, the slice's final boss, holds the last TWO colours it was struck with (`hardenCount: 2`)
     * — that IS its entire axis. `hardenedColour` (singular) returns only the most recent, so the
     * wyrm would have shown ONE of its two plates and the player would have been punished by a rule
     * the screen was actively contradicting.
     * ⚠️ Nothing mechanical could have caught it: `hardenedColours` was added and correct, the model
     * gates read the model, and every existing UI check reads the same singular getter this line
     * did. It is the §6b-3 rule 4 class — a model test cannot see a pixel — and it was found by
     * asking what the new bosses would LOOK like, before drawing them.
     * ⚠️ Capped at two swatches: `hardenCount` is 2 at most today and the row has ~110px before it
     * reaches the enemy figure at x=512. If a creature ever holds three, this row needs a re-layout,
     * not a third swatch squeezed in — so it asserts rather than silently overflowing. */
    const hardened = c.hardenedColours || (c.hardenedColour ? [c.hardenedColour] : []);
    if (hardened.length) {
      let hx0 = 0;
      for (const col of hardened.slice(0, 2)) {
        const hx = COLOUR_HEX[col] || '#ddd';
        g.fillStyle = hx; g.fillRect(W / 2 - 62 + hx0, 66, 9, 9);
        hx0 += 13;
      }
      const label = hardened.length > 1 ? hardened.slice(0, 2).join(' + ') : hardened[0];
      text(`HARDENED ${label}`, W / 2 - 62 + hx0 + 5, 75, 11,
        COLOUR_HEX[hardened[hardened.length - 1]] || '#ddd', 'left');
    }

    /* ⭐ WHICH FIGHT THIS IS. The teachers are named places, not "encounter 3", because the whole
     * point of a fixed lock is that the player recognises the SAME puzzle on the retry.
     * ⚠️ LEFT COLUMN ONLY, AND THE WIDTH IS LOAD-BEARING. The nameplate above is centred and the
     * enemy figure stands at x=512, so this text is wrapped to WRAP_COLS characters and capped at
     * three lines. §6b-3 rule 4: the two text collisions already fixed in this file were both
     * invisible to every check and found by photographing the page. */
    if (encounter) {
      text(encounter.name, 20, 20, 11, '#b6ac96');
      wrap(encounter.brief, WRAP_COLS).slice(0, 3).forEach((ln, i) => {
        text(ln, 20, 36 + i * 14, 11, '#8c8474');
      });
    }

    g.restore();                       /* end of the stage clip */

    g.fillStyle = '#0b0b0e'; g.fillRect(0, STAGE_H, W, 3);

    /* ⭐ THE AUDIO BADGE. A game that is silently muted, or whose context a browser never let start,
     * looks EXACTLY like a game with no audio — so the state is on screen rather than assumed. It
     * names the key that changes it, because a mute nobody can find is a bug report. */
    if (AU && AU.available) {
      const on = AU.ready && !AU.muted;
      text(on ? '♪ M mute' : (AU.muted ? '♪ MUTED  (M)' : '♪ press a key for sound'),
        W - 14, STAGE_H - 10, 10, on ? '#6d6d7a' : '#9a8a5a', 'right');
    }
  }

  function draw(now) {
    const c = combat;
    const dark = c.flameState === 'OUT';

    g.fillStyle = dark ? '#08080a' : '#101014';
    g.fillRect(0, 0, W, H);

    /* the light radius — the lantern's visible job.
     * ⚠️ THESE THREE NUMBERS ARE READ OUT OF THIS FILE BY `spike_battle_backdrop.js`, which measures
     * every figure's edge contrast against its own local backdrop at each of them. Changing the
     * EXPRESSION shape breaks that spike loudly (it refuses to guess); changing the VALUES silently
     * invalidates its measurements. Do neither without re-running it. */
    /* ⚠️ BRIGHT was 520 on a 722x236 stage with the light at (320,150) — the farthest corner sits
     * only 429px away, so at r=520 the falloff never really began and full flame lit the whole
     * stage flat. 430 puts the corner past the gradient's end so a lantern reads as a POOL of
     * light even at its brightest, which is what a lantern is. LOW/OUT unchanged: the Gate A
     * frames for those were already right and this edit must not move them. */
    const r = c.flameState === 'BRIGHT' ? 430 : c.flameState === 'LOW' ? 300 : 130;

    drawStage(now, c, r);

    /* THE TELEGRAPH — the whole information system in one row.
     * ⚠️ Y-POSITIONS HERE ARE LOAD-BEARING. The round banner used to be drawn at y=172 and this
     * label at y=182, so "LOCK BROKEN" printed straight THROUGH the word "TELEGRAPH" — found by
     * photographing the running page and looking at it, invisible to ui_smoke and to every gate.
     * ⚠️ EVERY ROW BELOW MOVED DOWN WHEN THE STAGE WAS ADDED (H 500 -> 560, STAGE_H 236). The
     * arithmetic is redone here rather than offset, so each number can be read against the canvas. */
    const lock = c.visibleLock();
    const matched = lockProgress(c.stack, lock);
    const lockHeld = !!lock && matched === lock.length;
    text('TELEGRAPH', W / 2, 376, 11, '#8a8a96', 'center');
    if (lock) {
      const bw = 46; const total = lock.length * (bw + 8) - 8;
      lock.forEach((col, i) => {
        const x = W / 2 - total / 2 + i * (bw + 8);
        /* ⭐ THE MATCH READOUT. Without it the player must recompute, every single action, which
         * suffix of a three-slot stack equals which prefix of the lock — and a headless playtest
         * of the OBVIOUS strategy (chase the next needed colour) lost 100% of fights at PERFECT
         * timing because it could not see it had already buried the sequence. Showing what is HELD
         * is legibility; showing what to PLAY would delete the decision, so it is not shown.
         * ⚠️ A tick glyph was tried first and drawn above the box, where it collided with the
         * TELEGRAPH label and read as clutter — found by looking at the frame. Held colours are
         * now simply LIT and unheld ones dimmed, which needs no extra ink at all. */
        const done = i < matched;
        g.globalAlpha = done ? 1 : 0.34;
        box(x, 382, bw, 28, COLOUR_HEX[col], done ? '#f0f0f4' : '#000');
        text(col[0], x + bw / 2, 402, 14, '#101014', 'center');
        g.globalAlpha = 1;
      });
      /* ⛔ THE STATE THE OLD BUILD COULD NOT REACH AND THE NEW ONE MUST NAME. Since
       * `fabricateBreakableLock` went false (combat.js, 2026-09-02) the game will present a lock the
       * SURVIVORS cannot break — which is what losing looks like, and is deliberate. It must not be
       * silent: §6b-8's whole complaint about the original defect was "the party grinds against a
       * puzzle it cannot solve, WITH NOTHING ON SCREEN TO SAY SO", and shipping this fix without
       * this row would have re-created that sentence exactly. The player is told, so a death reads
       * as a consequence rather than as the game breaking.
       * ⚠️ Read from the MODEL (`lockIsBeyondParty`), never recomputed here — the reachability rule
       * has exactly one owner (§6b-5, the same discipline as `damageScaleFor`). */
      if (typeof c.lockIsBeyondParty === 'function' && c.lockIsBeyondParty()) {
        text('BEYOND THE ONES STILL STANDING', W / 2, 424, 11, '#c06a6a', 'center');
      } else if (matched === lock.length) {
        text('SEQUENCE HELD — DO NOT BURY IT', W / 2, 424, 11, '#8fd07f', 'center');
      } else {
        text(`${matched} of ${lock.length} held`, W / 2, 424, 11, '#7a7a88', 'center');
      }
    } else if (dark) {
      /* ⛔⛔ THIS WAS ONE 48-CHARACTER CENTRED STRING AND IT RAN STRAIGHT THROUGH THE STACK BOXES.
       * MEASURED 2026-09-02 by photographing the flame-OUT frame: at 14 px it spans roughly x
       * 190..530, and the new three-column band puts the STACK column at x=470. The bright frame
       * cannot show it — there is no lock-hidden state at full flame — so this is the wing's
       * LOOK IN PAIRS rule paying for itself on the first frame after a layout change, and it is
       * the FIFTH text collision in this file, every one found by looking at a picture.
       * ⚠️ The centre column is ~154 px wide, which is about 25 characters at 11 px. A centred
       * string wider than that is not a layout choice, it is a collision waiting for a state
       * nobody screenshotted — so this is three short lines, each measured against that budget,
       * rather than one long one nudged sideways. */
      text('?   ?   ?', W / 2, 402, 14, '#c06a6a', 'center');
      text('THE LANTERN IS OUT', W / 2, 418, 11, '#c06a6a', 'center');
      text('YOU ARE GUESSING', W / 2, 431, 11, '#c06a6a', 'center');
    } else {
      text('(none)', W / 2, 402, 14, '#666', 'center');
    }

    /* ⭐ ONE BAND, THREE COLUMNS — lantern LEFT, telegraph CENTRE, stack RIGHT. These were four
     * stacked rows (stack label, flame label, flame bar, oil, party) occupying y=334..430; folding
     * them side by side is where the rest of the stage's 104 px came from.
     * ⛔ THE COLUMNS MUST NOT MEET. The centre column is the lock, centred on W/2 and up to three
     * 46 px boxes wide = 154 px, i.e. x 283..437 at its widest. LEFT therefore ends at 224 and RIGHT
     * begins at 470. ⚠️ ui_smoke section 10 checks horizontal text collisions with a monospace width
     * model and is the control on this arithmetic — it exists because two earlier rows in this file
     * collided invisibly and were found only by photographing the page. */
    const LCOL = 24; const RCOL = 470;

    /* THE LANTERN — left column */
    text(`LANTERN  ${c.flameState}`, LCOL, 376, 11, dark ? '#c06a6a' : '#8a8a96');
    box(LCOL, 382, 200, 16, '#25252b', '#4a4a54');
    const f = c.flame / c.cfg.flameMax;
    box(LCOL + 2, 384, 196 * f, 12, f > 0.55 ? '#e0b060' : f > 0 ? '#a06a34' : '#000');
    text(`OIL ${'*'.repeat(c.oil) || '(none)'}`, LCOL, 412, 12, c.oil ? '#e0b060' : '#7a5a3a');
    text(`round ${c.round}   ${(c.timeMs / 1000).toFixed(1)}s`, LCOL, 428, 11, '#6a6a76');

    /* THE LANTERN STACK — right column. ⚠️ 3 boxes at 44+6 pitch = 470..614 on a 720 canvas. */
    text('STACK  (oldest left)', RCOL, 376, 11, '#8a8a96');
    for (let i = 0; i < c.cfg.stackSize; i++) {
      const col = c.stack[i];
      box(RCOL + i * 50, 382, 44, 28, col ? COLOUR_HEX[col] : '#25252b', '#4a4a54');
      if (col) text(col[0], RCOL + i * 50 + 22, 402, 14, '#101014', 'center');
    }

    /* THE ACTION LIST or THE TIMING BAR */
    if (phase === 'choose') {
      const opts = options();
      overflowY = 0;
      text(lockHeld ? 'CHOOSE  (number key)   — RED ACTIONS WILL BURY THE SEQUENCE'
        : 'CHOOSE  (number key)', 24, 444, 11, lockHeld ? '#c08a8a' : '#8a8a96');
      opts.forEach((o, i) => {
        const ch = c.party.find((p) => p.id === o.actorId);
        const ab = o.abilityId === 'relight' ? { name: 'Relight', colour: null }
          : ch.abilities.find((a) => a.id === o.abilityId);
        /* ⚠️ NINE options is legal (three actors x two abilities, plus Relight), so this grid must
         * fit THREE rows: 448 + 2*30 + 24 = 532 on a 560 canvas. That arithmetic is the reason the
         * UI band could not be squeezed below ~220 px, and `overflowY` below re-asserts it from the
         * ACTUAL draw every frame rather than from these constants. */
        const x = 24 + (i % 4) * 172; const y = 452 + Math.floor(i / 4) * 30;
        /* ⛔ RECORDED FROM THE ACTUAL DRAW, never recomputed from the constants above — a checker
         * that restates the layout it is checking can only prove that assignment works. The
         * playtest harness asserts this against the real canvas height every frame. */
        overflowY = Math.max(overflowY, y + 24);
        /* ⭐ THE BURIAL WARNING, and it is the most evidence-backed line in this file.
         * MEASURED (burial_probe.js, 60 seeds): a player who understands colours but not ordering
         * assembles the correct sequence in 60.2% of rounds and then BURIES IT with a later action
         * in 40.5% — two out of every three times they get it right. The planner buries 4.3%. So
         * the wall in front of a new player is not "which colours"; it is that the lock only counts
         * when the round ENDS, and pushing the right colour at the wrong moment looks identical to
         * pushing the wrong one. This marks the CONSEQUENCE, never the answer: it says "this one
         * destroys what you are holding", and leaves the decision (preserve, or take the damage)
         * entirely with the player. */
        const buries = lockHeld && ab.colour;
        box(x, y, 164, 24, '#26262e', buries ? '#8a4a4a' : '#4a4a54');
        if (ab.colour) box(x + 4, y + 4, 16, 16, COLOUR_HEX[ab.colour], '#000');
        text(`${i + 1} ${ch.name.slice(0, 4)} ${ab.name}`, x + 26, y + 17, 11, buries ? '#c08a8a' : '#ccc');
      });
    } else if (phase === 'timing') {
      const t = performance.now() - sweepStart;
      const bx = 24; const bw = W - 48; const by = 452;
      text('PRESS SPACE ON THE MARK', W / 2, 444, 11, '#8a8a96', 'center');
      box(bx, by, bw, 26, '#25252b', '#4a4a54');
      /* windows, drawn to scale so the player can actually learn them */
      const px = (ms) => bx + bw * (ms / c.cfg.sweepMs);
      box(px(c.cfg.perfectAtMs - c.cfg.goodWindowMs), by, px(2 * c.cfg.goodWindowMs) - bx, 26, '#3a4a3a');
      box(px(c.cfg.perfectAtMs - c.cfg.perfectWindowMs), by, px(2 * c.cfg.perfectWindowMs) - bx, 26, '#5f9e57');
      box(px(Math.min(t, c.cfg.sweepMs)) - 2, by - 4, 4, 34, '#e8e8f0');
    }

    /* ⛔ TRANSIENT COMBAT FEEDBACK IS SUPPRESSED ON THE RESULT SCREEN — GATE A FINDING 3. The press
     * quality used to draw right-aligned at (W-24, 250) and the result word draws centred at
     * (W/2, 240) in a 34 px face, so the two shared a horizontal band and the last press of the
     * fight sat in the corner of the WIN card. Neither means anything once the fight is over, so
     * the fix is to stop drawing them rather than to nudge a coordinate.
     * ⭐ THE CORNER READOUT IS NOW GONE ENTIRELY, not moved: press quality rises off the ENEMY as
     * floating combat text (drawStage), beside the damage number, where the player is already
     * looking. That is the same fix one step further — a coordinate that does not exist cannot
     * collide with anything.
     * ⚠️ The banner sits on its OWN row at y=252, between the stage edge (239) and the TELEGRAPH
     * label (268), because it is the one string here whose length varies a lot. */
    if (phase !== 'over' && banner) {
      /* ⚠️ THREE tones, because there are now three round outcomes. Taken from `bannerTone`, never
       * from the banner STRING — a colour keyed on wording goes wrong the day the wording changes,
       * and this row's history is already a note about text that collided after a move. */
      const tone = bannerTone === 'good' ? '#8fd07f' : bannerTone === 'near' ? '#d0c87f' : '#d08f7f';
      text(banner, W / 2, 358, 13, tone, 'center');
    }

    if (phase === 'over') {
      /* ⛔ AND THE WASH WAS THE OTHER HALF OF FINDING 3. At 0.72 alpha the ENTIRE combat screen —
       * the option list, the enemy box, the stack, the lock — stayed legible underneath, so the
       * summary line was read against a field of unrelated text. A result screen needs an OPAQUE
       * surface of its own; the wash then only has to dim the surrounding context. */
      g.fillStyle = 'rgba(0,0,0,0.72)'; g.fillRect(0, 0, W, H);

      const cardW = 560; const cardH = 148;
      const cardX = (W - cardW) / 2; const cardY = H / 2 - 74;
      g.fillStyle = '#14141a';
      g.fillRect(cardX, cardY, cardW, cardH);
      g.strokeStyle = combat.result === 'WIN' ? '#8fd07f' : '#d08f7f';
      g.lineWidth = 2;
      g.strokeRect(cardX + 0.5, cardY + 0.5, cardW - 1, cardH - 1);

      text(combat.result, W / 2, cardY + 52, 34, combat.result === 'WIN' ? '#8fd07f' : '#d08f7f', 'center');
      /* Two short lines rather than one long one: the single line ran ~75 characters and had to be
       * read across the full width of the card at 12 px. */
      text(`${combat.round} rounds  ·  ${(combat.timeMs / 1000).toFixed(1)}s  ·  `
        + `perfect ${combat.stats.perfect}  good ${combat.stats.good}  miss ${combat.stats.miss}`,
      W / 2, cardY + 84, 12, '#aaa', 'center');
      text(`locks ${combat.stats.locksBroken} broken / ${combat.stats.locksLanded} landed`,
        W / 2, cardY + 104, 12, '#aaa', 'center');
      /* ⭐ THE WAY BACK, offered only when there IS one. On a walk this is the ONLY thing the player
       * should want — R re-rolls a standalone fight and would throw the whole crossing away — so it
       * gets the warm colour and the top line. ⛔ A key that promises a place you cannot reach is
       * worse than no key, which is why the standalone page still says only what it can do. */
      if (carried && carried.resume) {
        text('SPACE — back to the walk, on the lantern you have left',
          W / 2, cardY + 130, 13, '#e0b060', 'center');
      } else {
        text('R — next encounter', W / 2, cardY + 130, 13, '#8a8a96', 'center');
      }
    }
  }

  /* ⛔ GUARDED, BECAUSE `#again` IS PROTOTYPE FURNITURE AND THE SHIPPED PAGE HAS NONE. MEASURED
   * 2026-09-03 by `verify_web_build.js`, on the first run against the built tree: this line threw
   * `TypeError: Cannot read properties of null (reading 'addEventListener')` on `combat.html`, which
   * carries a canvas and nothing else — on itch the game IS an iframe the size of the canvas, so a
   * button beside it would either scroll the player off the game or shrink it.
   * ⭐ Nothing in `_suites.js` could have seen this. All 508 assertions run against the PROTOTYPE
   * page, which has the button; the defect lives in the difference between two HTML files, and the
   * only instrument that can reach it is one that drives the shipped bytes. Same shape as the art
   * base and the page names — every packaging difference in this game fails silently or late.
   * ⚠️ The button was always a convenience: `advance()` is on the keyboard too, so the shipped game
   * loses nothing by not having it. */
  const againBtn = document.getElementById('again');
  if (againBtn) againBtn.addEventListener('click', () => advance());

  /* ⛔ READ-ONLY TEST SEAM. Gate A is this wing's to close (§0z — no human tester), and "nobody has
   * ever seen a frame of this" is a
   * separate and cheaper failure, and it is fixed by driving the REAL page headlessly and LOOKING
   * (wing CLAUDE.md §6: look at rendered output). This exposes state for OBSERVATION only — it
   * sets nothing and the game never reads it, so it cannot become a second code path. Keys are
   * still the only input; playtest_headless.js presses them like a player. */
  window.LB_UI = {
    get combat() { return combat; },
    get phase() { return phase; },
    get options() { return options(); },
    get drawnBottom() { return overflowY; },
    get canvasHeight() { return cv.height; },
    get encounter() { return encounter; },
    /* ⛔⛔ THE COLUMN GEOMETRY, PUBLISHED SO A CHECKER CAN ASSERT IT — AND IT EXISTS BECAUSE A
     * COLLISION SHIPPED THROUGH A CHECKER THAT COULD NOT SEE IT. 2026-09-02: the flame-OUT screen
     * drew a 48-character centred warning straight through the lantern-stack boxes. A new ui_smoke
     * arm was written for exactly that screen, and the BREAK TEST — putting the defect back —
     * REPORTED GREEN. The reason is the checker's real scope: it compares `fillText` against
     * `fillText`, and the stack at that moment holds no colours, so there was no TEXT in the right
     * column to collide with. The string ran through three empty BOXES, and boxes are `fillRect`.
     * ⭐ So "no text collides" was a true statement about text-vs-text that read as a statement
     * about the screen. Extending it to text-vs-any-rect is not the fix: nearly every label in this
     * file sits on a panel by design, so that check would be a false-red factory.
     * ✅ The invariant that IS true and IS checkable is the one this layout actually introduced:
     * the UI band is three columns and NO STRING MAY CROSS A GUTTER. Published here rather than
     * copied into the test, so the layout has ONE owner (§6d-10) and a future column move cannot
     * leave a checker asserting yesterday's geometry. */
    get layout() {
      return {
        stageH: STAGE_H, canvasW: W, canvasH: H,
        /* the three-column band, in canvas coordinates */
        band: { top: STAGE_H + 4, bottom: 434 },
        /* x ranges each column's ink must stay inside; the gaps between them are the gutters */
        columns: [
          { id: 'left', x0: 0, x1: 232 },
          { id: 'centre', x0: 240, x1: 460 },
          { id: 'right', x0: 462, x1: W },
        ],
        /* ⚠️ EXEMPT: the banner is deliberately full-width and centred on its own row above the
         * columns, which is why it has that row to itself. Named here so the exemption is a
         * decision on the record rather than a checker quietly skipping a string. */
        fullWidthRows: [{ y0: STAGE_H + 4, y1: 366, why: 'the round banner has its own row' }],
      };
    },
    /* ⛔ GATE A MUST NOT PHOTOGRAPH THE FALLBACK SCREEN AND CALL IT ART. The stage degrades
     * gracefully when an asset is missing, which is correct behaviour and an excellent way to
     * produce a green capture run of a game that is still grey boxes. `gate_a_loop.js` reads these
     * and REFUSES to judge the frames unless the art is actually on them. */
    get artReady() { return artReady; },
    get artFailed() { return artFailed.slice(); },
    /* ⭐ THE ROUND'S VERDICT AS THE PLAYER IS TOLD IT. Exposed 2026-09-02 with `buriedRelief`: the
     * model now distinguishes THREE round outcomes and the whole value of that rule is that the
     * screen says which one happened, so "the screen says it" has to be checkable. Read-only, like
     * everything else here — `ui_smoke.js` drives real KEYS and reads this back. */
    get banner() { return banner; },
    get bannerTone() { return bannerTone; },
    /* ⚠️ OBSERVATION ONLY, and audio is deliberately NOT gated the way art is. A headless capture
     * runs with no user gesture, so the context is legitimately suspended and `audioReady` is
     * legitimately false — refusing to photograph on that would be a false red about a working
     * game. What IS reportable is whether the LAYER loaded and whether it recorded any failures. */
    get audioAvailable() { return !!(AU && AU.available); },
    get audioReady() { return !!(AU && AU.ready); },
    get audioState() { return AU ? AU.state : 'absent'; },
    get audioFailed() { return AU ? AU.failed : []; },
    newFight,
    advance,
  };

  /* ⭐ A COLD START BEGINS ON ENCOUNTER 1, not on a generated fight. This is the onboarding fix:
   * the first thing a new player meets is the puzzle that teaches the end-of-round rule. */
  newFight(1, ENC ? ENC.firstEncounter().id : null);
  requestAnimationFrame(frame);
}());
