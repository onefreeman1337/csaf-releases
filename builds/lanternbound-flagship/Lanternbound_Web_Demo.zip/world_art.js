'use strict';
/* ================================================================================================
 * world_art.js — THE OVERWORLD'S TILE LAYER. Sheets + atlas + the 47-blob autotiler.
 * ================================================================================================
 *
 * ⛔ WHY THE OVERWORLD HAD NO ART UNTIL NOW, STATED PLAINLY BECAUSE IT IS THE POINT. `stage.js`
 * draws the COMBAT screen from real Highland tiles and real sprites. `overworld_ui.js` drew five
 * flat colours and a WHITE RECTANGLE for the player — and the overworld is where most of the
 * playtime is and where the flow directive's primary verb lives (*walk a night moor with a
 * lantern*). Opening `Playtest/gate_a/001_cold_open_moor.png` shows it: dark green squares, a white
 * box. Wing §1.1 asks whether the product puts something BEAUTIFUL in front of the player; on the
 * game's main screen the answer was no.
 *
 * ⭐ THE ZOOM DECISION, AND IT IS DELIBERATELY DIFFERENT FROM COMBAT'S. DESIGN §6's coherence spike
 * fixed one rule: **both layers on a screen must render at the same integer zoom**, so one art pixel
 * is the same size in the ground and in the figures. Combat renders 32 px tiles and 64 px sprites at
 * **2x**. The overworld renders the same art at **1x**, and that satisfies the rule identically:
 * 1 art px = 1 screen px in BOTH layers, and the party leader still stands exactly two tiles tall,
 * which is the proportion the spike proved.
 * Two reasons 1x is right out here, and neither is convenience:
 *   1. **The lantern needs somewhere to fail.** `radiusBright` is 190 WORLD px — a MEASURED balance
 *      number tied to monster sight and the 30 s burn, not a rendering knob. At 1x that lights a
 *      380 px disc inside a 760x520 frame, so the dark the game is about is on screen. At 2x the
 *      same disc is 760 px across and fills the canvas edge to edge: the premise would be invisible
 *      for exactly the reason the combat night-grade defect was invisible.
 *   2. **It is the genre convention.** SNES JRPGs draw small field sprites and large battle sprites
 *      (Chrono Trigger, FF6). Field 1x / battle 2x is that convention, not an inconsistency.
 *
 * ⛔ AND THE ATLAS IS THE PACK'S, NOT OURS. `_stage_art_0901.js` derives `tiles/atlas.json` from
 * `VerdantHD01_Highland/tiles.json` in the same pass that copies the sheets, so tile coordinates are
 * the ones the tileset wing published. Nothing here measures a sheet by eye. (Master §2b: a figure
 * copied out of an artefact goes stale the moment the artefact is rebuilt.)
 * ---------------------------------------------------------------------------------------------- */
(function () {
  const AT = (typeof require === 'function' && typeof module !== 'undefined' && module.exports)
    ? require('./autotile')
    : (typeof window !== 'undefined' ? window.LB_AUTOTILE : null);
  if (!AT) throw new Error('world_art.js needs autotile.js loaded first — it owns the blob resolver');

  /* ⛔ TWO levels, and it must stay identical to `stage.js`'s. The page is served from
   * `Internal_Ops/proto/`, so one `..` lands on `Internal_Ops` and every asset 404s — which does NOT
   * throw: `loadAll` simply reports not-ready and the moor draws its flat-colour fallback, i.e. a
   * clean run over the exact screen this file exists to replace. Measured 2026-09-02: written with
   * one `..` it produced two 404s and a green-looking capture. */
  /* ⛔ AND SINCE 2026-09-03 IT IS DECLARED ONCE, IN `paths.js`. The comment above says this string
   * "must stay identical to stage.js's" — which is a rule a human has to remember, about a fact the
   * packaged build changes. Four copies existed; now there is one, and the note above survives as
   * the reason a wrong base is so hard to notice (it 404s SILENTLY into the fallback renderer). */
  const BASE = (typeof window !== 'undefined' && window.LB_PATHS)
    ? window.LB_PATHS.assets : '../../Product_Release/assets/';
  const CELL = 32;                       // art pixels per tile, from the pack
  const ZOOM = 1;                        // see the header — field is 1x, battle is 2x

  /* ------------------------------------------------------------------------------------------------
   * THE MATERIAL TABLE — the one place a terrain kind becomes art.
   * ⛔ Keyed by the overworld's OWN tile enum names, resolved against `overworld.js` at wire time, so
   * this file never holds a second copy of that enum (§6d-10: a shared generator is a shared fact,
   * and every consumer holding its own copy is a place the game moves without anyone editing it).
   * ---------------------------------------------------------------------------------------------- */
  /* ------------------------------------------------------------------------------------------------
   * ⛔⛔ EVERY ID BELOW IS PACK-QUALIFIED — `"<pack>:<id>"` — AND THAT IS LOAD-BEARING, NOT STYLE.
   * ------------------------------------------------------------------------------------------------
   * The staged tree carries TWO tileset packs (highland for the moor and the cairn field, farmstead
   * for the town), and MEASURED 2026-09-02 they share FIVE tile ids — `well`, `cart`, `logpile`,
   * `barrel`, `trough` — plus four sheet basenames. Unqualified, one of each pair silently wins the
   * merge and a table asking for `well` gets whichever pack was staged last: a wrong tile, drawn
   * correctly, with nothing thrown and every check green.
   *
   * ⛔ THERE IS NO DEFAULT PACK, DELIBERATELY. A `pack` field that defaults to highland would make
   * every un-migrated row keep working while meaning something nobody chose — master §2b's "an
   * unconfigured default is not a decision". Naming the pack in every id makes an omission a hard
   * red in `_atlas_gate.js` instead of a silent resolution.
   * ---------------------------------------------------------------------------------------------- */
  const MATERIAL = {
    /* GRASS is the BASE FILL every other material blends onto — highland's autotile sets are all
     * `<x>_on_sward`, so sward is the canvas and everything else is painted over it. */
    GRASS: { base: ['highland:sward_1', 'highland:sward_2', 'highland:sward_3', 'highland:sward_4'] },
    PATH: { set: 'highland:loam_on_sward' },
    /* the moor's crag outcrops get the same shadow treatment as the cairn field's walls, so a solid
     * cell reads as solid on BOTH maps rather than the two screens teaching different rules */
    ROCK: { set: 'highland:crag_on_sward', shade: 0.4 },
    WATER: { set: 'highland:tarn_on_sward' },
    /* A blocked "TREE" cell is heath carrying something a walker cannot push through.
     * ⛔ IT USED TO BE `thorn`/`gorse` AND THAT WAS WRONG, VISIBLY. Photographed at 3x 2026-09-02:
     * a thorn on bare heath reads as a BROWN POST, and because the generator scatters 6% of the map
     * as trees, vertically adjacent pairs are common and stack into a totem pole. The pack ships
     * actual trees — `pine` and `rowan`, both `sizeCells [2,2]` — which were undrawable until the
     * footprint fix in the same session, because a 32x32 blit renders a 2x2 tree as its top-left
     * quarter (a stump). Thorn and gorse stay, as ground SCATTER, which is what they are.
     * ⛔ AND `pine` WAS THEN TRIED AND REJECTED ON A LOOK, WHICH IS THE ONLY INSTRUMENT THAT COULD
     * HAVE CAUGHT IT: the pine's mid-green body sits at almost exactly the value of lit sward under
     * the night grade, so the fill vanishes and only its dark branch outlines survive — it
     * photographed as a LADDER standing on the moor. Nothing errored; the tree was drawn correctly
     * and was simply invisible against its own background.
     * ✅ `rowan` is the choice, on contrast and on story: a round canopy over a brown trunk with red
     * berries reads as a tree at a glance and is the only warm colour on a night moor besides the
     * lantern.
     * ⛔ AND `rowan` WAS WRONG TOO — MEASURED, after three props had been chosen and rejected by
     * eye across three capture cycles. `_prop_contrast.js` (self-test 5/5) reports the fraction of
     * each prop's own pixels that sit within ±6 luma of lit sward, i.e. HOW MUCH OF THE OBJECT IS
     * NOT THERE, post-night-grade: **thorn 61% · boulder 68% · rocks 59% · rowan 55% · pine 35% ·
     * cairn 33% · menhir 8% · gorse 0%.** Every eyeball verdict this session is reproduced by that
     * one number, and the mean-luma version of the same tool ranked them almost exactly backwards.
     * ✅ So a blocked cell is a STANDING STONE or a GORSE THICKET — the two things measured to read
     * against the ground, and the two things that actually stop a walker on a treeless moor, which
     * is what DESIGN §6 said this biome was in the first place ("a moor has no forest"). */
    TREE: { set: 'highland:heath_on_sward', props: ['highland:menhir', 'highland:gorse'] },
  };
  /* ------------------------------------------------------------------------------------------------
   * THE CAIRN FIELD's table — the SAME tile enum, different art. That is the whole trick: a wall is
   * a wall to the collision code, so the barrow needed no new tile types, no gate changes and no
   * re-measured balance. It is a different PLACE because of layout, roster and these six rows.
   * ⛔ MEASURED 2026-09-02 (`_prop_contrast.js --ground scree_1`): scree (luma 70.2) and sward (68.1)
   * produce IDENTICAL camouflage percentages for all nine props, so the moor's measured prop choices
   * transfer here unchanged and did not need re-deriving by eye. (Control: against heath, 48.4, the
   * table moves hard — boulder 68% -> 11% — which is what proves the measurement is real.)
   * ---------------------------------------------------------------------------------------------- */
  /* ⛔ THE CAIRN FIELD USES FILLS, NOT BLEND SETS, AND THE FIRST CAPTURE IS WHY. Every autotile set
   * the pack ships is `<material>_on_SWARD`, so a blend edge REVEALS SWARD — and the first barrow
   * frame had bright GREEN GRASS edging the processional way and the wall lines, in a stone burial
   * ground. Nothing errored; the tiles were the correct tiles, doing exactly what they are for.
   * ⇒ Out here the base is SCREE and each material draws its own `_1.._4` fill, so nothing green can
   * appear. The cost is hard tile edges instead of blended ones, which on a floor of loose stone and
   * dry-stone walling reads as rubble and coursing rather than as a mistake. The moor keeps the
   * blending, because the moor is what the blend masks were authored for. */
  const SITE_MATERIAL = {
    /* ⛔ THE THREE-WAY SEPARATION IS MEASURED, BECAUSE TWO OF THE THREE WERE INVISIBLE BY EYE.
     * Mean luma of the pack's own tiles: scree 112.0 · crag 107.6 · sward 108.7 · tarn 97.8 ·
     * loam 83.0 · heath 77.5 · bluff 182.6. A floor, a wall and a path must all separate from EACH
     * OTHER, and the obvious reading (scree floor, crag wall, loam path) fails on the pair that
     * matters most: **crag wall against scree floor is Δ4.4 luma** — the enclosing wall of the site
     * was the same colour as its floor, and the transverse walls were only findable by their lit
     * edge. The best triple the pack allows:
     *      floor HEATH 77.5 · path SCREE 112.0 (Δ34.5) · wall CRAG 107.6 (Δ30.0)
     * i.e. a laid STONE way across dark turf, walled in grey crag — which is what a processional way
     * through a burial ground actually looks like, and it also makes the site read grimmer than the
     * bright sward moor, so the two places are told apart at a glance.
     * ⚠️ path-vs-wall is only Δ4.4, and that is accepted knowingly: they meet only where the way
     * passes a wall gap, and the lit edge on blocked cells carries that boundary. */
    __base: ['highland:heath_1', 'highland:heath_2', 'highland:heath_3', 'highland:heath_4'],
    /* the floor is the base — dark moorland turf over the graves */
    GRASS: {},
    /* the processional way: laid pale stone, the one thing here that is meant to be followed */
    PATH: { fill: ['highland:scree_1', 'highland:scree_2', 'highland:scree_3', 'highland:scree_4'] },
    /* ⛔ CRAG, NOT BLUFF — DESIGN §6 says "walled in by bluff and crag" and half of that is wrong.
     * MEASURED 2026-09-02 (mean RGB of the pack's own tiles): `bluff_1` is rgb(150,201,98), i.e.
     * BRIGHT GRASS GREEN — it is a grassy cliff TOP, not a stone face — while `crag_1` is
     * rgb(114,106,100), grey stone. Built from bluff, the transverse walls photographed as green
     * bands running across a burial ground. `crag` is the pack's rock and is what a dry-stone wall
     * should be made of. ⚠️ A material's NAME is not its colour; look at the pixels. */
    ROCK: { fill: ['highland:crag_1', 'highland:crag_2', 'highland:crag_3', 'highland:crag_4'], shade: 0.5 },
    /* the sunk tarn the bestiary names */
    WATER: { fill: ['highland:tarn_1', 'highland:tarn_2', 'highland:tarn_3', 'highland:tarn_4'] },
    /* ⭐ AND THE FLOOR CHANGE MADE THIS ROW FREE. Against SCREE it was a stated compromise — menhir
     * 8% camouflaged but cairn 33% ("partly lost"), accepted only because a cairn field without
     * cairns is a naming lie. Measured against HEATH, which is now the floor: **cairn 0%** and
     * **menhir 17%**. Both read, and the compromise is gone.
     * ⚠️ These figures are floor-specific: re-run `_prop_contrast.js --ground heath_1` if the floor
     * ever moves again, because contrast is a RELATION and not a property of the prop. */
    TREE: { props: ['highland:menhir', 'highland:cairn'] },
  };

  /* ------------------------------------------------------------------------------------------------
   * ALDERMOOR's table — the slice's THIRD place, and the first drawn from a SECOND tileset pack.
   * ------------------------------------------------------------------------------------------------
   * ⭐ THE WHOLE POINT IS THAT IT IS NOT THE SAME STONE. The moor and the barrow are both highland:
   * sward, heath, scree, crag. A hamlet built from those would be the barrow with the walls moved —
   * the "generated content all looks the same" failure, arriving through the art rather than the
   * layout. `VerdantHD02_Farmstead` is a different palette AND a different vocabulary (pasture,
   * yard, furrow, stubble, hedge, pond, and a farm's worth of props), so the third place is told
   * apart at a glance, which is the same test the barrow's heath/scree/crag triple was chosen on.
   *
   * ⭐ AND THE TWO PACKS ARE BUILT TO MEET: farmstead ships `pasture_on_sward`, i.e. its ground
   * blends onto the moor's own base material. The seam between the two places is authored art, not a
   * hard cut — which is exactly the reason the staged tree had to be namespaced by pack before this
   * table could be written (both packs ship `grounds.png`, `props.png`, `water.png`, `animated.png`
   * and five shared tile ids).
   *
   * ⛔ EVERY ID IS FARMSTEAD-QUALIFIED. A bare `well` would resolve to whichever pack was staged
   * last, and BOTH packs ship a `well` — the collision is not hypothetical, it is one of the five.
   * ---------------------------------------------------------------------------------------------- */
  const TOWN_MATERIAL = {
    /* pasture is the canvas: farmstead's autotile sets are all `<x>_on_pasture` */
    __base: ['farmstead:pasture_1', 'farmstead:pasture_2', 'farmstead:pasture_3', 'farmstead:pasture_4'],
    /* open ground inside the hedges — grazing, and the strips between the worked field lines */
    GRASS: {},
    /* ⛔ THE LANE AND THE YARD ARE ONE TILE TYPE AND MUST STAY SO. `generateTown` draws both as
     * `T.PATH`, because to collision they are identical — trodden, walkable ground. Splitting them
     * would mean a new enum value, which the barrow's header already argues against: it would touch
     * collision, every gate and every sweep to express a purely visual difference. `yard_on_pasture`
     * blends both, and the lane reads as a lane because of its SHAPE, not its material. */
    PATH: { set: 'farmstead:yard_on_pasture' },
    /* ⛔ ROCK IS A COTTAGE WALL HERE, NOT A CLIFF, and it is shaded for the reason the barrow's crag
     * is: a wall is a vertical surface in shadow. Without the shade a pale yard-coloured building
     * sits in a pale yard and the picture says "walk here" where the collision says otherwise —
     * the exact defect measured on the barrow's crag walls (Δ4.4 luma against its own floor).
     * `stubble` is the pack's dry straw-gold fill, which is what a thatched cob wall looks like from
     * above, and it is the only farmstead material that is neither ground nor crop. */
    ROCK: {
      fill: ['farmstead:stubble_1', 'farmstead:stubble_2', 'farmstead:stubble_3', 'farmstead:stubble_4'],
      shade: 0.45,
    },
    WATER: { set: 'farmstead:pond_on_pasture' },
    /* ⛔ A BLOCKED "TREE" IS A HEDGE, and hedges are what enclose a hamlet and divide its fields.
     * `groundKinds` is what makes the blend correct: the hedge's mask must be computed over the
     * GROUND it stands on, not over its own tile type. Without it every hedge cell would be an
     * isolated pasture island ringed with blend edges — the exact defect the barrow's header
     * records, which draws a tile for every cell, throws nothing, and only shows up as a rash of
     * little outlines across the fields. */
    /* ⛔ NO `props` ROW. A hedge IS the blend set — the pack's `hedge_on_pasture` masks draw the run
     * and its ends, so hanging a prop on top would put a beeskep inside every hedge cell. The skeps
     * and stooks are SCATTER, on the open pasture where a farm actually leaves them. */
    TREE: {
      set: 'farmstead:hedge_on_pasture',
      groundKinds: ['TREE', 'GRASS'],
    },
  };

  let atlas = null;
  const sheets = {};
  let ready = false;
  let failed = [];

  function load(rel) {
    return new Promise((resolve) => {
      const i = new Image();
      i.onload = () => resolve({ rel, i });
      i.onerror = () => resolve({ rel, i: null });
      i.src = BASE + rel;
    });
  }

  async function loadAll() {
    failed = [];
    try {
      const res = await fetch(`${BASE}tiles/atlas.json`);
      atlas = await res.json();
    } catch (e) {
      failed.push(`atlas.json (${e && e.message})`);
      ready = false;
      return { ready, failed: failed.slice(), tiles: 0 };
    }
    /* ⛔ REFUSE AN EMPTY ATLAS. Every draw below is a lookup, and lookups into an empty map fail
     * silently by drawing nothing — a blank moor that reports success (master §2b, the vacuous
     * `every()` row). */
    if (!atlas || !atlas.tiles || Object.keys(atlas.tiles).length === 0) {
      failed.push('atlas.json holds ZERO tiles');
      ready = false;
      return { ready, failed: failed.slice(), tiles: 0 };
    }

    const got = await Promise.all(atlas.sheets.map((s) => load(`tiles/sheets/${s}`)));
    atlas.sheets.forEach((s, idx) => {
      const g = got[idx];
      if (!g.i) { failed.push(`sheets/${s} (did not load)`); return; }
      sheets[s] = g.i;
    });
    ready = failed.length === 0;
    return { ready, failed: failed.slice(), tiles: Object.keys(atlas.tiles).length };
  }

  /**
   * Blit one atlas tile at screen (sx, sy). Returns false when the id is unknown, never throws.
   * ⛔ MULTI-CELL PROPS ARE DRAWN AT THEIR REAL FOOTPRINT AND ANCHORED BY THE FOOT. A `pine` is
   * `sizeCells [2,2]` and a `menhir` is `[1,2]`; blitting a fixed 32x32 source rect draws the
   * top-left QUARTER of each — a stump where a tree should be, with nothing thrown and nothing
   * logged. The extra height grows UPWARD (`sy - (h-1)*CELL`) because a tall object stands on its
   * cell rather than hanging from it, which is also how `stage.js` places its 32x64 menhir.
   */
  function blit(g, id, sx, sy, zoom = ZOOM) {
    const t = atlas && atlas.tiles[id];
    if (!t) return false;
    const sh = sheets[t.s];
    if (!sh) return false;
    const cw = (t.w || 1) * CELL;
    const ch = (t.h || 1) * CELL;
    g.drawImage(sh, t.x, t.y, cw, ch,
      sx, sy - (ch - CELL) * zoom, cw * zoom, ch * zoom);
    return true;
  }

  /**
   * Draw one terrain cell: the sward base, then the material's blob tile, then any prop.
   * `kindName` is the overworld enum NAME ('GRASS' | 'PATH' | ...), `same` answers "is (x,y) the
   * same material as this cell" for the blob mask.
   */
  /**
   * ⛔ THE MASK IS COMPUTED OVER A MATERIAL, NOT OVER A TILE TYPE, AND THE BARROW IS WHY.
   * `kindAt(x,y)` returns the neighbour's kind NAME (or `null` out of bounds, which counts as same).
   * A material row may declare `groundKinds` — the set of tile types that share its floor — because
   * "is my neighbour the same TILE TYPE" and "is my neighbour the same GROUND" are different
   * questions and only the second one draws correct edges.
   * In the cairn field the floor is scree and BOTH `GRASS` (open ground) and `TREE` (a standing
   * stone) stand on it. Masked by tile type, every menhir cell would be an isolated scree ISLAND
   * ringed with blend edges, sitting in the middle of a scree floor — a defect that draws a tile for
   * every cell, throws nothing, and is only visible as a rash of little outlines across the site.
   */
  function cell(g, kindName, tx, ty, sx, sy, kindAt, zoom = ZOOM, table = MATERIAL) {
    const m = table[kindName];
    const group = (m && m.groundKinds) ? new Set(m.groundKinds) : new Set([kindName]);
    const same = (nx, ny) => {
      const k = kindAt(nx, ny);
      return k === null ? true : group.has(k);
    };
    /* the base always draws, so a cell is never a hole even if a material lookup misses.
     * ⛔ It is ALWAYS sward, in both tables, because every autotile set the pack ships is
     * `<material>_on_sward` — sward is the canvas the blend masks are cut against. The cairn field
     * paints scree over it everywhere, which is why its GRASS row is `scree_on_sward` rather than a
     * base list: the floor is a blended material, not a fill. */
    const baseSet = table.__base || MATERIAL.GRASS.base;
    blit(g, baseSet[AT.variant(tx, ty, baseSet.length)], sx, sy, zoom);
    if (!m) return;
    /* a FILL row draws one of its own variants with no blend mask (see SITE_MATERIAL's header) */
    if (m.fill) blit(g, m.fill[AT.variant(tx, ty, m.fill.length, 3)], sx, sy, zoom);
    else if (m.set) {
      const id = AT.tileFor(atlas.sets, m.set, tx, ty, same);
      if (id) blit(g, id, sx, sy, zoom);
    }
    /* ⛔ `shade` — A WALL IS A VERTICAL SURFACE IN SHADOW, AND WITHOUT SAYING SO IT READS AS A ROAD.
     * MEASURED: the pack ships eight materials and no wall-face tile, and the only non-green stones
     * are crag (luma 107.6) and scree (112.0) — Δ4.4. So with a scree processional way, the crag
     * walls of the cairn field photographed as a PALE STONE CROSSING running through the site: the
     * picture said "walk here" where the collision said "you cannot", which is worse than ugly.
     * Darkening the wall's own fill encodes the thing that is actually true — it is a face standing
     * above the floor, lit only along its top edge (drawn by overworld_ui.js) — and separates it
     * from a path made of nearly the same stone without needing a tile the pack does not have. */
    if (m.shade) {
      g.save();
      g.globalAlpha *= m.shade;
      g.fillStyle = '#000';
      g.fillRect(sx, sy, CELL * zoom, CELL * zoom);
      g.restore();
    }
    if (m.props) {
      const p = m.props[AT.variant(tx, ty, m.props.length, 7)];
      /* ⛔ A PROP WIDER THAN ITS CELL IS CENTRED ON IT, NOT HUNG OFF ITS LEFT EDGE. A 2-cell tree
       * blitted from the cell origin sits entirely to the RIGHT of the thing it is meant to be
       * standing on, so the canopy shades the wrong tile and the trunk misses the blocked cell the
       * player actually collides with — the picture would contradict the collision. */
      const t = atlas && atlas.tiles[p];
      const dx = t && t.w > 1 ? -((t.w - 1) * CELL * zoom) / 2 : 0;
      /* a contact shadow under anything that stands taller than its cell, for the same reason
       * `stage.js` gives one to every figure: without it a tall prop floats, and on a screen lit by
       * one moving point source a floating object is the first thing that reads as wrong */
      if (t && t.h > 1) {
        g.save();
        g.globalAlpha *= 0.4; g.fillStyle = '#000';
        g.beginPath();
        g.ellipse(sx + (CELL * zoom) / 2, sy + CELL * zoom - 4 * zoom, 13 * zoom, 5 * zoom, 0, 0, Math.PI * 2);
        g.fill();
        g.restore();
      }
      blit(g, p, sx + dx, sy, zoom);
    }
  }

  /* ------------------------------------------------------------------------------------------------
   * SCATTER — sparse decoration on open ground, PER PACK.
   * ------------------------------------------------------------------------------------------------
   * ⛔ IT IS KEYED BY PACK BECAUSE THE MOOR'S SCATTER IS MOOR PLANTS. This was one flat list of
   * highland ids (`fern`, `rocks`, `gorse`) and the town initially reused it — which would have
   * strewn moorland gorse and loose scree across a farmstead's grazing pasture, drawn perfectly, in
   * the one place whose whole job is to look like somewhere ELSE. Nothing would have errored: both
   * packs are staged, both ids resolve, and `art_gates` would have stayed green because the ids are
   * real. The defect is only visible by looking, which is why the LIST is per-place rather than the
   * decision being made at the call site.
   *
   * Hoisted to module scope so `art_gates.js` can READ the ids this file actually draws rather than
   * keeping a second copy of them — a list the gate declares for itself is a list that drifts, and
   * the drift is invisible in exactly the direction that matters (master §2b).
   * ---------------------------------------------------------------------------------------------- */
  const SCATTER_PROPS = ['highland:fern', 'highland:rocks', 'highland:gorse'];
  /* a worked hamlet's stray gear: a skep by the hedge, a stook left standing, a bale in the grass */
  const TOWN_SCATTER_PROPS = ['farmstead:beeskep', 'farmstead:stook', 'farmstead:haybale'];

  /* ------------------------------------------------------------------------------------------------
   * ⛔ THE TOWN'S TWO LANDMARKS, AS ART RATHER THAN AS SHAPES. 2026-09-03.
   * ------------------------------------------------------------------------------------------------
   * Photographed on the day the town became reachable (wing §0z), and both were coder art in the
   * first screen a player will ever see of this game:
   *   · the oil cache drew as a 10x14 FLAT ORANGE RECTANGLE with a brown outline — on the moor that
   *     passes as a dropped flask, but the design's own words for the town are "the oil cache is a
   *     WELL rather than a scatter, so refuelling has a location and a RITUAL". A rectangle is not
   *     a ritual, and `farmstead:well_on_yard` has been sitting in the staged atlas the whole time.
   *   · the goal drew as a BLACK BOX WITH THE WORD "GATE" ON IT, in a hedge the pack ships a
   *     five-bar gate for.
   * ⚠️ Declared HERE, not in `overworld_ui.js`, on purpose: `namedIds()` is what `art_gates.js`
   * reads, so an id declared in the renderer would be drawn by the game and checked by nothing —
   * and an unresolved tile is not a runtime error, `blit()` returns false and draws NOTHING. A
   * landmark that silently fails to draw is the well being invisible again, with a green suite.
   * ---------------------------------------------------------------------------------------------- */
  const TOWN_LANDMARKS = {
    /* the oil cache: a stone well standing in the farmyard */
    cache: 'farmstead:well_on_yard',
    /* the north gate: a five-bar gate in the hedge line, which is the way out of the slice's only
     * safe ground */
    goal: 'farmstead:fivebar_gate_on_yard',
  };

  /**
   * A scattered decoration for open ground — sparse, deterministic, and never on a blocked cell.
   * ⛔ `props` is PASSED, not defaulted to the moor's: a caller that forgets is a town strewn with
   * moor plants, and a default would make that the silent outcome (master §2b — an unconfigured
   * default is not a decision).
   */
  function scatter(g, tx, ty, sx, sy, zoom = ZOOM, density = 11, props = SCATTER_PROPS) {
    if (AT.variant(tx, ty, density, 23) !== 0) return;
    blit(g, props[AT.variant(tx, ty, props.length, 31)], sx, sy, zoom);
  }

  /**
   * ⭐ EVERY ATLAS NAME THIS FILE CAN ASK FOR, DERIVED FROM THE TABLES THEMSELVES.
   *
   * ⛔ It walks the tables rather than listing their contents, so a row added to a material table is
   * covered the moment it is written. A hand-maintained list here would be a THIRD copy of the same
   * fact and would go stale silently — which is the whole failure this namespace exists to end.
   * Returns `{ tiles: [...qualified ids], sets: [...qualified set names] }`.
   */
  /* ⛔ `scatterLists` IS A PARAMETER, not baked in. Written with both lists hard-coded into the
   * seed set, this function answered "every id this MODULE can draw" even when asked about ONE
   * table — so `town_gates.js`'s "the town table is built from the farmstead pack" arm read the
   * moor's `highland:fern` back and failed a correct table. The gate was right and the query was
   * wrong, which is master §2b's "when an instrument disagrees with something you have LOOKED at,
   * suspect the instrument". The default still covers everything, so `art_gates.js` is unchanged. */
  function namedIds(tables = { MATERIAL, SITE_MATERIAL, TOWN_MATERIAL },
    scatterLists = [SCATTER_PROPS, TOWN_SCATTER_PROPS, Object.values(TOWN_LANDMARKS)]) {
    const tiles = new Set(scatterLists.flat());
    const sets = new Set();
    for (const table of Object.values(tables)) {
      for (const [k, row] of Object.entries(table)) {
        if (k === '__base') { row.forEach((id) => tiles.add(id)); continue; }
        if (!row || typeof row !== 'object') continue;
        for (const id of row.base || []) tiles.add(id);
        for (const id of row.fill || []) tiles.add(id);
        for (const id of row.props || []) tiles.add(id);
        if (row.set) sets.add(row.set);
      }
    }
    return { tiles: [...tiles], sets: [...sets] };
  }

  const API = {
    loadAll, blit, cell, scatter, MATERIAL, SITE_MATERIAL, TOWN_MATERIAL, CELL, ZOOM,
    namedIds, SCATTER_PROPS, TOWN_SCATTER_PROPS, TOWN_LANDMARKS,
    get ready() { return ready; },
    get failed() { return failed.slice(); },
    get atlas() { return atlas; },
    /* test seam: let a harness inject an atlas without a network */
    _setAtlas(a) { atlas = a; },
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  if (typeof window !== 'undefined') window.LB_WORLD_ART = API;
}());
