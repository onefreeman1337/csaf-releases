'use strict';
/* ================================================================================================
 * LANTERNBOUND — THE OVERWORLD MODEL. Task 4 of DESIGN_Lanternbound.md §10, and the flow layer.
 * ================================================================================================
 *
 * WHY THIS EXISTS, STATED BLUNTLY. The wing's flow directive (CLAUDE.md §0a-2) says a candidate
 * fails if its primary input is "select an option and press go". DESIGN §2 defended the combat
 * against that charge by claiming the timed press was the product — and on 2026-09-01 that claim
 * was MEASURED FALSE (`skill_grid.js`: for a player who has not solved the ordering puzzle the
 * timing mechanic is completely inert, 0.0% win at perfect hands and at random hands alike).
 *
 * ⇒ So the flow in this game is NOT in the combat. It is here, or it is nowhere: continuous
 * movement, a light that burns down while you walk, and monsters you can see and choose to avoid.
 * DESIGN §4 already says the fight "starts with the flame you WALKED IN WITH" and that oil is
 * "carried from the overworld" — both of those are claims about a thing that did not exist. This is
 * that thing, and §5 of this file is the gate that asks whether it is a real decision or a corridor.
 *
 * ⛔ NO DOM, NO CANVAS, NO ART — same discipline as combat.js, for the same reason: every claim
 * below has to be answerable by a bot before any content is drawn.
 *
 * ⛔ ONE CLOCK. `tick(dtMs)`. The browser feeds measured elapsed ms (wing CLAUDE.md §1a: the
 * automation tab throttles rAF to zero, so a frame-counted burn reads as frozen under exactly the
 * conditions we test under). Bots feed the modelled cost of the step they took.
 *
 * ⭐ THE ONE IDEA THAT MAKES THE DARK A DECISION RATHER THAN A PUNISHMENT: darkness cuts BOTH ways.
 * You cannot see the monsters, and the monsters cannot see you. Walking dark is a legitimate tactic
 * — cheaper in oil, blind in navigation — rather than pure loss. That matters beyond feel: the
 * measured beginner death-spiral (BALANCE_FINDINGS §A3, new players end 100% of fights in darkness)
 * needs at least one place where losing the light is not simply worse.
 */

/* ⛔ DUAL MODE, AND IT IS NOT OPTIONAL. This file is loaded BOTH by Node (selftest, gates, sweep)
 * and by a plain <script> tag in the browser. A bare `require('./combat')` is correct in Node and a
 * fatal ReferenceError in the browser, where combat.js has already published itself as `window.LB`
 * — and the failure is silent from the outside: the page loads, the canvas stays blank, and the
 * only symptom is that the test seam never appears. Measured exactly that way 2026-09-01.
 *
 * ⛔ AND THE WHOLE FILE IS WRAPPED IN AN IIFE, WHICH IS THE SECOND HALF OF THE SAME TRAP AND THE
 * more important half. Plain <script> tags ALL SHARE ONE GLOBAL SCOPE, so every top-level `const`
 * here collides with combat.js's identically-named one — `createRNG` first, then `DEFAULTS`, with
 * `TILE`, `T` and `dist` queued behind them. Each collision throws
 * "Identifier 'X' has already been declared", which aborts this entire file, leaves `window.LBW`
 * undefined, and surfaces ONLY as a blank canvas. ⚠️ Node's module scope hides all of it, so every
 * Node suite stayed green while the page was dead — renaming one identifier at a time is
 * whack-a-mole against a scope problem. One IIFE fixes the class. */
(function () {
const makeRNG = (typeof require === 'function')
  ? require('./combat').createRNG
  : window.LB.createRNG;

/* ⭐ THE ROSTER, added 2026-09-02. Until now every monster on the moor was ANONYMOUS: it had a
 * position and a chase state and nothing else, so walking into any of them produced the same
 * authored teacher fight. Ten creatures existed, were gated, were photographed — and TWO were
 * reachable by playing. The bestiary is the single source of the roster (§6d-10: one shared fact,
 * never a second hand-typed copy), and `firstSeen` is what places a creature in a zone. */
const BESTIARY = (typeof require === 'function')
  ? require('./bestiary')
  : (typeof window !== 'undefined' ? window.LB_BESTIARY : null);

/* ------------------------------------------------------------------------------------------------
 * TERRAIN
 * ---------------------------------------------------------------------------------------------- */
const TILE = 32;              // art pixels; the render layer draws at 2x (DESIGN §6 coherence spike)
const T = { GRASS: 0, PATH: 1, ROCK: 2, WATER: 3, TREE: 4 };
const BLOCKED = new Set([T.ROCK, T.WATER, T.TREE]);

/* ⛔⛔ ZONES THAT ARE DELIBERATELY EMPTY OF CREATURES — a WHITELIST, never a fallback.
 *
 * The roster check below throws when a zone has no creatures, because an empty roster spawns an
 * empty world and reports success. The town is genuinely empty and that is its entire point, so it
 * needs an exemption — and the shape of the exemption matters more than the exemption.
 *
 * Master §2b: *"everyone reviews a guard's invariant and its search; nobody reviews what it does
 * when the search fails, and that branch encodes a design decision no one made."* This wing shipped
 * exactly that defect a session ago — a guard against an unsolvable puzzle FABRICATED a solvable one
 * when its search failed, which made a boss invulnerable under a green gate. So the exemption is a
 * named set that a zone must be ADDED to, checked in BOTH directions: a safe zone that somehow has
 * creatures is as much a defect as an unsafe zone that has none, and `town_gates.js` asserts both.
 * A zone typo therefore still throws, instead of silently becoming safe. */
const SAFE_ZONES = new Set(['town']);

/* ⭐ THE ONE LIST OF PLACES. Every zone the model can build, and the generator that builds it — read
 * by the constructor, by `restore()` and by the gates, so a fourth place is added in exactly one
 * spot. Declared here rather than beside the constructor because `restore` is a free function that
 * also needs it. (Assigned below the generator declarations by hoisting; `function` declarations
 * hoist, so the references are live by the time anything constructs an Overworld.) */
const GENERATORS = {
  moor: (rng) => generateRegion(rng),
  barrow: (rng) => generateBarrow(rng),
  town: (rng) => generateTown(rng),
};

const DEFAULTS = {
  /* THE LANTERN ON THE OVERWORLD. DESIGN §4 says "~90 s" and admits the figure is UNTESTED because
   * there was no overworld to test it on.
   *
   * ⛔ IT IS NOW TESTED AND 90 s WAS WRONG BY THREE TIMES. MEASURED 2026-09-01 (`burn_sweep.js`,
   * 20 seeds x 7 cells): a beeline crossing of this region takes **31.2 s**, and at 90 s, 70 s and
   * 55 s the player spends **0.0%** of the walk in darkness — the light simply cannot run out, so
   * §4's "that is what makes the overworld tense without adding an enemy" was false. Darkness first
   * becomes reachable at 45 s (0.3%) and becomes a real event at 30 s (9.2%), with the region still
   * finishable in 100% of runs. 30 s is the SLOWEST value meeting both pre-registered properties —
   * deliberately not the darkest, because the darkest cell is always the shortest burn and that is
   * the metric eating the mechanic (wing CLAUDE.md §6b-2 rule 5).
   *
   * ⭐ AND THE CONSEQUENCE IS A DESIGN SIMPLIFICATION, NOT JUST A NUMBER: this is the same 30 s the
   * combat model uses, so DESIGN §4's "the lantern burns at two rates" is unnecessary. ONE lantern,
   * ONE burn rate, one number for the player to learn — and a crossing that costs almost exactly a
   * full lantern, which is why oil on the map is a real decision rather than a pickup. */
  flameMax: 100,
  flameBurnMsToEmpty: 30000,
  flameBrightAt: 55,

  /* Light radius in WORLD pixels, by flame state. This is simultaneously the lighting, the
   * information system and the stealth system — one number doing three jobs (DESIGN §4). */
  radiusBright: 190,
  radiusLow: 120,
  radiusOut: 46,
  /* ⭐ HOW CLOSE YOU MUST COME TO A PLACED BOSS BEFORE IT IS A FIGHT. A CONFIG VALUE, not a literal,
   * because it was 20 and that made the end of the slice skippable (see the contact test), and a
   * number whose wrongness cost an entire authored ending should be measurable rather than edited:
   * `_spine_probe.js` can now sweep it and show the before and after on the same instrument.
   * ⛔ It must exceed the boss placement offset (`TILE * 1.5` = 48) or the ring can be reached
   * through the gap between the two of them. */
  bossReach: 52,

  /* Movement. Free pixel movement with tile collision — genuinely continuous, which is the whole
   * point (§0a-2's flow test asks what the hands do CONTINUOUSLY). */
  walkSpeed: 108,             // world px per second
  playerRadius: 10,

  /* Monsters. They wake when they can SEE you, and sight is symmetric with your lantern. */
  monsterSpeed: 78,
  monsterSightBright: 210,    // how far a monster can see a LIT player
  monsterSightDark: 54,       // ...and an unlit one. The stealth window.
  monsterGiveUpMs: 3200,
  /* ⭐ EXPOSED 2026-09-02 AT THEIR EXISTING VALUES — a refactor, not a change. They were literals
   * (`area / 620`, `rng() * 90`) inside the constructor, which meant `_encounter_rate.js` could only
   * sweep them by holding its own COPY of the placement code — and a sweep that measures a copy of
   * the thing is not measuring the thing (master §2b). Defaults reproduce the shipped behaviour
   * exactly; every gate and balance sweep is unaffected. */
  monsterEvery: 620,          // one monster per N tiles of region area
  monsterWander: 90,          // how far a patrolling monster strays from where it spawned, in px

  /* ⭐ THE LURE — added 2026-09-02 to answer THE MOOR QUESTION, and it is a DESIGN change, not a
   * tuning one. `_encounter_rate.js` measured the moor at 8/60 ambushes and proved with three null
   * controls that no parameter reaches it: a monster strays <=`monsterWander` from its spawn, so
   * whether a crossing meets one is decided AT SPAWN. The sweep saturates at 19/60 on 3.6x the
   * monsters, so density cannot buy it either.
   *
   * ⛔ The two options handed over were "accept 13%" and "funnel the path through ridge passes".
   * Both leave the ENCOUNTER RATE A CONSTANT — a property of the map, which the player cannot
   * touch. This is the third option and it is the one the premise already implies: A LIT LANTERN IS
   * A BEACON. Monsters do not need to SEE you to start drifting toward the light; sight (210/54)
   * still governs the CHASE, so the stealth system is untouched.
   *
   * ⇒ The rate stops being a map constant and becomes A PLAYER DECISION, taken continuously while
   * walking (§0a-2's flow test), and it gives the overworld lantern the second job §4 wanted: light
   * lets you see AND draws what is out there. Burning BRIGHT costs more than burning LOW, so the
   * flame level is a risk dial rather than a countdown.
   *
   * ⛔ THE RADII ARE THRESHOLDS AGAINST A MEASURED DISTANCE, NOT TASTE, and the sweep is a CLIFF
   * rather than a gradient. Median distance to the NEAREST monster while standing is 799px, so a
   * beacon shorter than that reaches nobody on a typical seed: the standing ambush rate is 0/60 at
   * every radius up to 620 and 19/60 at 800. The first answer here was 620 — derived from the
   * median closest approach on a WALKING crossing (551px) — and it raised the walking rate while
   * leaving standing at 0/60, i.e. it moved a number without fixing the thing the investigation
   * started from. ⇒ BRIGHT 900 clears the threshold; LOW 340 sits deliberately UNDER it, so
   * dimming buys back "nobody can reach me" and the flame is a dial with a felt step.
   * MEASURED (`_lure_probe.js`, 60 seeds, 6/6 properties): moor crossing 8/60 -> 28/60, held lit
   * 35/60, crossed dark 2/60, standing lit 0/60 -> 28/60. */
  monsterLureBright: 900,     // px a BRIGHT lantern is noticed from (0 = mechanic off)
  monsterLureLow: 340,        // ...and a LOW one. An OUT lantern is never a beacon, by construction.
  monsterLureLoseMs: 2600,    // how long a lured monster keeps drifting after the light goes out

  oilPerCache: 1,
  flamePerCache: 30,          // a cache also tops the lantern up somewhat
  startFlame: 100,
  startOil: 0,
  maxOil: 3,
};

/* ------------------------------------------------------------------------------------------------
 * REGION GENERATION — one Highland region (DESIGN §6: the slice is HIGHLAND because
 * VerdantHD01_Highland is the only 32 px tileset that exists).
 * ---------------------------------------------------------------------------------------------- */
/* ⛔ REGION SIZE IS A MEASURED NUMBER, NOT A GUESS — and the first guess was wrong in exactly the
 * way DESIGN §4's original 90-second combat burn was wrong (chosen before anyone knew how long the
 * thing it pressures actually takes). MEASURED 2026-09-01 at 48x34: a beeline crossing walked
 * 1,326 px at 108 px/s = **12.3 seconds** against a 90-second lantern, so the flame stood at 88.8
 * when the first fight started and the overworld lantern was never under any pressure at all. A
 * region you cross in twelve seconds is a room. At 100x72 the same crossing is ~36 s, which is the
 * first point at which "manage your light while exploring" is a sentence about the game. */
function generateRegion(rng, w = 100, h = 72) {
  const tiles = new Array(w * h).fill(T.GRASS);
  const at = (x, y) => y * w + x;

  /* a ridge of rock across the middle with two passes through it — the reason a route decision
   * exists at all. Without an obstacle the map is a corridor and §5's gate should say so. */
  const ridgeY = Math.floor(h * 0.45);
  const passA = Math.floor(w * 0.22);
  const passB = Math.floor(w * 0.74);
  for (let x = 0; x < w; x++) {
    const wob = Math.floor(Math.sin(x * 0.37) * 1.6);
    for (let dy = -1; dy <= 1; dy++) {
      const y = ridgeY + wob + dy;
      if (y > 0 && y < h) tiles[at(x, y)] = T.ROCK;
    }
  }
  for (const px of [passA, passB]) {
    for (let x = px - 1; x <= px + 1; x++) {
      for (let dy = -2; dy <= 2; dy++) {
        const y = ridgeY + Math.floor(Math.sin(x * 0.37) * 1.6) + dy;
        if (x > 0 && x < w && y > 0 && y < h) tiles[at(x, y)] = T.PATH;
      }
    }
  }

  /* a tarn, and scattered woodland */
  const lx = Math.floor(w * 0.55); const ly = Math.floor(h * 0.76);
  for (let y = ly - 3; y <= ly + 3; y++) {
    for (let x = lx - 5; x <= lx + 5; x++) {
      if (x <= 0 || y <= 0 || x >= w - 1 || y >= h - 1) continue;
      const d = ((x - lx) / 5) ** 2 + ((y - ly) / 3) ** 2;
      if (d < 1) tiles[at(x, y)] = T.WATER;
    }
  }
  for (let i = 0; i < Math.floor(w * h * 0.06); i++) {
    const x = 1 + Math.floor(rng() * (w - 2));
    const y = 1 + Math.floor(rng() * (h - 2));
    if (tiles[at(x, y)] === T.GRASS) tiles[at(x, y)] = T.TREE;
  }
  for (let x = 0; x < w; x++) { tiles[at(x, 0)] = T.ROCK; tiles[at(x, h - 1)] = T.ROCK; }
  for (let y = 0; y < h; y++) { tiles[at(0, y)] = T.ROCK; tiles[at(w - 1, y)] = T.ROCK; }

  return { w, h, tiles };
}

/* ------------------------------------------------------------------------------------------------
 * THE CAIRN FIELD — the slice's second place, and the one six of the ten creatures live in.
 * ------------------------------------------------------------------------------------------------
 * ⛔ IT IS OUTDOORS, AND THAT IS A MEASURED DECISION, NOT A STYLE ONE. DESIGN §5 asked for a
 * dungeon; DESIGN §6 proved the factory owns no 32 px interior tileset (re-derived 2026-09-02 by
 * `_hd_pack_census.js`: 22 tileset packs, 20 at 16 px, and the only two at 32 px are outdoor
 * moorland sets whose interior-vocabulary probe returns NONE). Rendering a 16 px dungeon beside
 * 64 px sprites would put the world's pixels at 4 screen px against the characters' 2 — the exact
 * "pasted in from another game" failure the coherence spike exists to prevent. So the barrow is an
 * ENCLOSED OUTDOOR SITE: walled by bluff, floored with scree, furnished with standing stones and
 * cairns. It costs no art from any other wing and it is a better fit — a lantern that goes out is
 * more interesting on an open burial ground at night than in a corridor lit by something else.
 *
 * ⭐ IT REUSES THE TILE ENUM RATHER THAN EXTENDING IT, DELIBERATELY. Adding SCREE and BLUFF as new
 * `T` values would touch collision, every gate, the balance sweeps and the renderer, to express a
 * difference that is purely VISUAL: a wall is a wall. The barrow is a different PLACE because it is
 * a different LAYOUT, a different ART TABLE (`world_art.js` SITE_MATERIAL) and a different ROSTER —
 * the walkable/blocked semantics are identical and every measured number still applies.
 *
 * The layout is AUTHORED in shape and seeded in detail, because a burial ground is a made thing:
 *   · one enclosure, walled all round, with ONE breach in the south wall (the way in)
 *   · a processional way running north from the breach to the heart
 *   · transverse walls with gaps, so the way is a sequence of courts rather than a corridor
 *   · a sunk tarn among the cairns (the ossuary ooze's water, named in the bestiary)
 *   · the heart: an open stone ring at the north end, where the bosses are PLACED
 * ---------------------------------------------------------------------------------------------- */
function generateBarrow(rng, w = 64, h = 48) {
  const tiles = new Array(w * h).fill(T.ROCK);      // solid, then cut the site out of it
  const at = (x, y) => y * w + x;

  /* the enclosure: scree floor inset from the border, so the wall is thick enough to read */
  const M = 3;
  for (let y = M; y < h - M; y++) for (let x = M; x < w - M; x++) tiles[at(x, y)] = T.GRASS;

  /* ⛔ ONE WAY IN, and it is the thing the bestiary names ("the breach in the dry-stone wall").
   * Cut through the FULL margin or the site is sealed and every reachability check fails. */
  const breachX = Math.floor(w * 0.5);
  for (let x = breachX - 1; x <= breachX + 1; x++) {
    for (let y = h - M - 1; y < h; y++) tiles[at(x, y)] = T.PATH;
  }

  /* the processional way: south breach to the heart, as PATH so it reads as trodden ground */
  const heartY = M + 6;
  for (let y = heartY; y < h - M; y++) {
    for (let x = breachX - 1; x <= breachX + 1; x++) tiles[at(x, y)] = T.PATH;
  }

  /* transverse walls with an offset gap each, turning the way into a sequence of courts.
   * ⛔ THE GAP NEVER SITS ON THE PROCESSIONAL WAY, or the wall is not a wall — it is a doorway the
   * player walks straight through without ever leaving the path, and the courts stop existing. */
  const courts = 3;
  for (let i = 1; i <= courts; i++) {
    const y = Math.round(M + ((h - 2 * M) * i) / (courts + 1));
    for (let x = M; x < w - M; x++) tiles[at(x, y)] = T.ROCK;
    const left = i % 2 === 1;
    const gapX = left ? Math.round(w * 0.22) : Math.round(w * 0.78);
    for (let x = gapX - 1; x <= gapX + 1; x++) if (x > M && x < w - M) tiles[at(x, y)] = T.GRASS;
    /* and the way itself must still pass, so re-cut it after the wall */
    for (let x = breachX - 1; x <= breachX + 1; x++) tiles[at(x, y)] = T.PATH;
  }

  /* the sunk tarn among the cairns — the OSSUARY OOZE's water, named in the bestiary */
  const lx = Math.round(w * 0.24); const ly = Math.round(h * 0.62);
  for (let y = ly - 3; y <= ly + 3; y++) {
    for (let x = lx - 4; x <= lx + 4; x++) {
      if (x <= M || y <= M || x >= w - M - 1 || y >= h - M - 1) continue;
      if (((x - lx) / 4) ** 2 + ((y - ly) / 3) ** 2 < 1) tiles[at(x, y)] = T.WATER;
    }
  }

  /* standing stones and cairns, scattered but never ON the way and never sealing a gap.
   * TREE is the enum's "blocked thing standing on open ground" and the barrow's art table draws it
   * as a menhir or a cairn — see world_art.js SITE_MATERIAL. */
  const nStones = Math.round(w * h * 0.045);
  for (let i = 0; i < nStones; i++) {
    const x = M + 1 + Math.floor(rng() * (w - 2 * M - 2));
    const y = M + 1 + Math.floor(rng() * (h - 2 * M - 2));
    if (tiles[at(x, y)] !== T.GRASS) continue;
    if (Math.abs(x - breachX) <= 2) continue;                 // keep the way clear
    tiles[at(x, y)] = T.TREE;
  }

  /* THE HEART: an open stone ring at the north end. Cleared first so nothing scattered above can
   * block it, then ringed, then the way is re-cut into it. */
  const hx = breachX; const hy = heartY;
  for (let y = hy - 3; y <= hy + 3; y++) {
    for (let x = hx - 5; x <= hx + 5; x++) {
      if (x <= M || y <= M || x >= w - M - 1 || y >= h - M - 1) continue;
      tiles[at(x, y)] = T.GRASS;
    }
  }
  for (let a = 0; a < 16; a++) {
    const x = Math.round(hx + Math.cos((a / 16) * Math.PI * 2) * 5);
    const y = Math.round(hy + Math.sin((a / 16) * Math.PI * 2) * 3);
    if (x <= M || y <= M || x >= w - M - 1 || y >= h - M - 1) continue;
    tiles[at(x, y)] = T.TREE;
  }
  for (let y = hy; y < hy + 4; y++) tiles[at(hx, y)] = T.PATH;   // the way enters the ring

  return { w, h, tiles, kind: 'barrow', heart: { x: hx, y: hy }, breach: { x: breachX, y: h - M } };
}

/* ------------------------------------------------------------------------------------------------
 * ALDERMOOR — the slice's THIRD place, and the only SAFE one.
 * ------------------------------------------------------------------------------------------------
 * ⭐ WHY A TOWN EARNS ITS PLACE IN A SLICE THIS SMALL, stated as a mechanic and not as scenery. The
 * game is one long held breath: the lantern burns down, the dark closes, something is out there. A
 * held breath needs somewhere to let it out, or the tension flattens into noise — and the player has
 * nowhere to stand still and look at the game they are playing. The town is that place:
 *   · NO monsters and NO encounters, so it is the one screen where standing still is safe;
 *   · the oil cache is a WELL rather than a scatter, so refuelling has a location and a ritual;
 *   · it is lit — hearths and a lantern over the gate — so the light/dark language reads in reverse
 *     for one screen, which is what makes the moor read as dark when you walk back out.
 *
 * ⛔ IT USES THE FARMSTEAD PACK, AND THAT IS WHY THE ART PIPELINE WAS NAMESPACED FIRST. The moor and
 * the barrow are highland; a hamlet built from highland tiles would be the same grey stone in a
 * different arrangement, i.e. a re-lit barrow. `VerdantHD02_Farmstead` ships the pasture, yard,
 * hedge, furrow, stubble and pond materials plus a well, henhouse, dovecote, cart and haystack —
 * and, critically, `pasture_on_sward`, which blends its ground onto the moor's own base, so the two
 * places meet instead of butting. Staging it beside the highland pack silently overwrote FOUR sheets
 * and FIVE tile ids until `_stage_art_0901.js` was namespaced by pack.
 *
 * ⛔ AUTHORED IN SHAPE, SEEDED IN DETAIL — like the barrow, and for the same reason: a settlement is
 * a made thing. A fully generated village reads as a random scatter of huts, which is precisely the
 * "generated content looks samey" failure the wing's queue keeps warning about.
 *   · a lane running north-south, entering at the south gate and leaving at the north
 *   · a yard around the lane's middle, where the buildings and the well stand
 *   · hedged field strips east and west (furrow and stubble), so the fields read as WORKED
 *   · a pond in the south-east corner
 *   · a hedge boundary all round with exactly TWO gaps: the two gates
 * ---------------------------------------------------------------------------------------------- */
function generateTown(rng, w = 48, h = 40) {
  const tiles = new Array(w * h).fill(T.GRASS);   // GRASS is pasture here — see TOWN_MATERIAL
  const at = (x, y) => y * w + x;

  /* the hedge boundary. TREE is the enum's "blocked thing standing on open ground"; the town's art
   * table draws it as HEDGE, which is what encloses a hamlet. Reusing the enum rather than extending
   * it is the same decision the barrow made: a wall is a wall to collision, and every gate, sweep
   * and reachability check keeps working untouched. */
  for (let x = 0; x < w; x++) { tiles[at(x, 0)] = T.TREE; tiles[at(x, h - 1)] = T.TREE; }
  for (let y = 0; y < h; y++) { tiles[at(0, y)] = T.TREE; tiles[at(w - 1, y)] = T.TREE; }

  /* THE LANE, south gate to north gate, three tiles wide so two figures pass */
  const laneX = Math.floor(w * 0.5);
  for (let y = 0; y < h; y++) {
    for (let x = laneX - 1; x <= laneX + 1; x++) tiles[at(x, y)] = T.PATH;
  }

  /* THE YARD — trodden ground round the middle of the lane, where the buildings stand. Drawn as a
   * rectangle of PATH so the art table can lay `yard_on_pasture` over it. */
  const yardY = Math.floor(h * 0.45);
  for (let y = yardY - 5; y <= yardY + 5; y++) {
    for (let x = laneX - 8; x <= laneX + 8; x++) {
      if (x <= 0 || y <= 0 || x >= w - 1 || y >= h - 1) continue;
      tiles[at(x, y)] = T.PATH;
    }
  }

  /* ⛔ THE BUILDINGS ARE BLOCKED CELLS, NOT ART. A cottage the player walks through is a painted
   * floor, and the picture would contradict the collision — the failure the wing already paid for
   * when crag walls photographed as a pale stone crossing. Four blocks, placed off the lane so the
   * way through is never sealed. */
  const blocks = [
    { x: laneX - 7, y: yardY - 4, w: 4, h: 3 },
    { x: laneX + 3, y: yardY - 4, w: 4, h: 3 },
    { x: laneX - 7, y: yardY + 2, w: 4, h: 3 },
    { x: laneX + 4, y: yardY + 2, w: 3, h: 3 },
  ];
  for (const b of blocks) {
    for (let y = b.y; y < b.y + b.h; y++) {
      for (let x = b.x; x < b.x + b.w; x++) {
        if (x <= 0 || y <= 0 || x >= w - 1 || y >= h - 1) continue;
        if (Math.abs(x - laneX) <= 1) continue;            // never build on the lane
        tiles[at(x, y)] = T.ROCK;                          // drawn as a cottage wall
      }
    }
  }

  /* THE FIELD STRIPS — hedged runs east and west of the yard, north and south of it. Every other
   * strip is left as pasture so the fields read as a rotation rather than as stripes. */
  const strip = (x0, x1, y0, y1) => {
    for (let y = y0; y <= y1; y += 3) {
      for (let x = x0; x <= x1; x++) {
        if (x <= 0 || y <= 0 || x >= w - 1 || y >= h - 1) continue;
        if (tiles[at(x, y)] !== T.GRASS) continue;
        tiles[at(x, y)] = T.TREE;                          // a hedge line between strips
      }
    }
  };
  strip(2, laneX - 3, 3, yardY - 8);
  strip(laneX + 3, w - 3, 3, yardY - 8);
  strip(2, laneX - 3, yardY + 9, h - 4);
  strip(laneX + 3, w - 3, yardY + 9, h - 4);

  /* THE POND, south-east, clear of the lane and the yard */
  const px = Math.round(w * 0.78); const py = Math.round(h * 0.80);
  for (let y = py - 3; y <= py + 3; y++) {
    for (let x = px - 4; x <= px + 4; x++) {
      if (x <= 1 || y <= 1 || x >= w - 2 || y >= h - 2) continue;
      if (((x - px) / 4) ** 2 + ((y - py) / 3) ** 2 < 1) tiles[at(x, y)] = T.WATER;
    }
  }

  /* THE GATES — the boundary's only two gaps, and the reason the town is not sealed. Cut LAST so
   * nothing above can close them. */
  for (let x = laneX - 1; x <= laneX + 1; x++) { tiles[at(x, 0)] = T.PATH; tiles[at(x, h - 1)] = T.PATH; }

  /* ⛔ AND THE LANE IS RE-CUT LAST, for the same reason the barrow re-cuts its processional way after
   * every transverse wall: a strip or a building that clipped it would sever the town in half, and a
   * severed town still generates, still draws, and only fails as an unreachable north gate. */
  for (let y = 0; y < h; y++) {
    for (let x = laneX - 1; x <= laneX + 1; x++) tiles[at(x, y)] = T.PATH;
  }

  /* the well: the town's oil, at the yard's centre, one tile east of the lane so it is beside the
   * way rather than on it */
  const well = { x: laneX + 3, y: yardY };
  if (tiles[at(well.x, well.y)] === T.ROCK) tiles[at(well.x, well.y)] = T.PATH;

  return {
    w, h, tiles, kind: 'town',
    gateSouth: { x: laneX, y: h - 1 },
    gateNorth: { x: laneX, y: 0 },
    well,
  };
}

function isBlocked(region, tx, ty) {
  if (tx < 0 || ty < 0 || tx >= region.w || ty >= region.h) return true;
  return BLOCKED.has(region.tiles[ty * region.w + tx]);
}

/**
 * Every tile reachable on foot from `start`. Flood fill, computed ONCE per region.
 *
 * ⛔ THIS EXISTS BECAUSE THE FIRST VERSION SHIPPED UNREACHABLE GOALS. MEASURED 2026-09-01: 20% of
 * beeline runs never arrived, and the cause was not the bots — the rock ridge and the tarn cut the
 * map into pockets, and a goal placed at random can land in one the player cannot walk to. A player
 * would have searched a region for a dungeon mouth that could not be reached, which reads as a
 * cruel puzzle rather than a bug and is exactly the kind of thing that never gets diagnosed from a
 * play report. Placement is now restricted to the player's own connected component.
 */
function reachableSet(region, start) {
  const seen = new Uint8Array(region.w * region.h);
  const sx = Math.floor(start.x / TILE); const sy = Math.floor(start.y / TILE);
  if (isBlocked(region, sx, sy)) return seen;
  const q = [sy * region.w + sx];
  seen[sy * region.w + sx] = 1;
  for (let head = 0; head < q.length; head++) {
    const cur = q[head];
    const cx = cur % region.w; const cy = (cur - cx) / region.w;
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const nx = cx + dx; const ny = cy + dy;
      if (nx < 0 || ny < 0 || nx >= region.w || ny >= region.h) continue;
      const ni = ny * region.w + nx;
      if (seen[ni] || isBlocked(region, nx, ny)) continue;
      seen[ni] = 1; q.push(ni);
    }
  }
  return seen;
}

/** Nearest open tile centre to a world point — used to place things without landing them in rock. */
function findOpen(region, rng, near = null, tries = 4000, reach = null) {
  let best = null; let bestD = -1;
  for (let i = 0; i < tries; i++) {
    const tx = 1 + Math.floor(rng() * (region.w - 2));
    const ty = 1 + Math.floor(rng() * (region.h - 2));
    if (isBlocked(region, tx, ty)) continue;
    if (reach && !reach[ty * region.w + tx]) continue;   // ⛔ never place where the player cannot walk
    const p = { x: tx * TILE + TILE / 2, y: ty * TILE + TILE / 2 };
    if (near) {
      const d = Math.hypot(p.x - near.x, p.y - near.y);
      if (d < near.minDist) {
        /* remember the furthest near-miss, so a demand that cannot be met degrades to the best
         * available tile rather than to null — a null goal is an unfinishable region. */
        if (d > bestD) { bestD = d; best = p; }
        continue;
      }
    }
    return p;
  }
  return best;
}

const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

/* ------------------------------------------------------------------------------------------------
 * THE OVERWORLD
 * ---------------------------------------------------------------------------------------------- */
class Overworld {
  constructor(opts = {}) {
    this.cfg = Object.assign({}, DEFAULTS, opts.cfg || {});
    /* ⛔ THE SEED IS KEPT, because the whole region is a pure function of it and that is what makes
     * a walk RESUMABLE after a fight (see `snapshot()`). Until 2026-09-02 it was consumed into the
     * rng and forgotten, which is part of why nobody could come back from an ambush. */
    this.seed = opts.seed === undefined ? 1 : opts.seed;
    this.rng = makeRNG(this.seed);
    /* ⭐ THE ZONE PICKS THE MAP. Set before anything reads it, because the roster, the generator and
     * the goal semantics all key off it. Default 'moor' keeps every existing caller and every gate
     * behaving exactly as before. */
    this.zone = opts.zone || 'moor';
    /* ⛔ A TABLE, NOT A TERNARY CHAIN WITH A FALL-THROUGH. 2026-09-03. This read
     * `zone === 'barrow' ? … : zone === 'town' ? … : generateRegion(…)`, so ANY unknown zone — a
     * typo, a stale save, a fourth place added in one file and not the other — silently became the
     * MOOR, with the moor's roster and the moor's goal semantics, and nothing thrown. That is
     * master §2b's "an unconfigured default is not a decision" and it is the same shape
     * `overworld_ui.js`'s ZONES table replaced upstairs on the same day; keeping the model's copy
     * as a ternary would leave the hole one file below the fix.
     * ⚠️ `GENERATORS` is exported so `restore()` and the gates validate against ONE list. It used to
     * be spelled out again inside `restore` as `zone !== 'moor' && zone !== 'barrow'`, which is how
     * a town that generates, renders and plays perfectly was refused on the way back from a fight. */
    const gen = GENERATORS[this.zone];
    if (!gen) throw new Error(`overworld: unknown zone "${this.zone}" — add it to GENERATORS, `
      + 'never let it fall through to the moor');
    this.region = gen(this.rng);
    this.externalClock = opts.externalClock === true;
    /* ⭐ SAFE means "this zone is DECLARED to hold no creatures", and it is checked against the
     * bestiary below rather than merely asserted here. */
    this.safe = SAFE_ZONES.has(this.zone);

    /* ⛔ IN THE BARROW THE PLAYER ENTERS AT THE BREACH, NEVER AT A RANDOM OPEN TILE. A burial ground
     * you wake up in the middle of is not a place you walked into, and a random start can also land
     * PAST a transverse wall, silently skipping the courts the layout exists to create. */
    /* ⛔ IN THE TOWN THE PLAYER ENTERS AT THE SOUTH GATE, for the barrow's reason exactly: you walk
     * INTO a settlement, and a random open tile can start you behind a hedge or inside the fields. */
    const start = this.zone === 'barrow'
      ? { x: this.region.breach.x * TILE + TILE / 2, y: (this.region.h - 2) * TILE }
      : this.zone === 'town'
        ? { x: this.region.gateSouth.x * TILE + TILE / 2, y: (this.region.h - 2) * TILE }
        : findOpen(this.region, this.rng);
    this.player = { x: start.x, y: start.y };
    this.flame = this.cfg.startFlame;
    this.oil = this.cfg.startOil;
    this.timeMs = 0;
    this.distanceWalked = 0;

    /* the goal: the dungeon mouth, deliberately on the FAR side of the ridge */
    /* ⚠️ Everything placed below SCALES WITH THE REGION. Fixed counts and fixed distances were
     * written against a 48x34 map; carried onto a 100x72 one they put six monsters in a world four
     * times the size and a goal 900 px away on a 3,900 px diagonal — i.e. they would have silently
     * turned the enlargement into an empty field with a short walk across it. */
    const diag = Math.hypot(this.region.w, this.region.h) * TILE;
    const area = this.region.w * this.region.h;
    /* the player's own connected component — everything placed below must be inside it */
    this.reach = reachableSet(this.region, this.player);
    const R = (near) => findOpen(this.region, this.rng, near, 4000, this.reach);

    /* ⛔ THE BARROW'S GOAL IS ITS HEART, NOT A RANDOM FAR TILE. The stone ring is the authored end
     * of the slice and where the bosses stand; picking a goal at random would put the ending
     * somewhere the layout says nothing about. */
    /* ⛔ THE TOWN'S GOAL IS THE NORTH GATE — the way OUT, onto the moor. A town is a place you pass
     * through, so its objective is its far door, not a landmark inside it. */
    this.goal = this.zone === 'barrow'
      ? { x: this.region.heart.x * TILE + TILE / 2, y: this.region.heart.y * TILE + TILE / 2 }
      : this.zone === 'town'
        ? { x: this.region.gateNorth.x * TILE + TILE / 2, y: TILE }
        : (R({ x: this.player.x, y: this.player.y, minDist: diag * 0.62 }) || R(null));

    this.caches = [];
    if (this.zone === 'town') {
      /* ⭐ ONE CACHE, AT THE WELL. Scattering oil across a safe town would make the hub the cheapest
       * place to farm fuel and would delete the moor's scarcity, which is the resource the whole
       * lantern mechanic is built on. One refill with a LOCATION is a ritual; six are a supply
       * depot. */
      this.caches.push({ x: this.region.well.x * TILE + TILE / 2, y: this.region.well.y * TILE + TILE / 2, taken: false });
    } else {
      const nCaches = Math.max(4, Math.round(area / 900));
      for (let i = 0; i < nCaches; i++) {
        const p = R({ x: this.player.x, y: this.player.y, minDist: diag * 0.16 });
        if (p) this.caches.push({ x: p.x, y: p.y, taken: false });
      }
    }

    /* ⭐ EACH MONSTER IS NOW A NAMED CREATURE. Before 2026-09-02 they were anonymous positions and
     * every ambush produced the same authored fight, so eight of the ten gated creatures could not
     * be met by playing. The roster comes from the bestiary filtered by ZONE, and the pick is from
     * the region's OWN seeded rng so a seed reproduces the same moor exactly — the balance sweeps
     * and `gate_a_loop.js` both depend on that determinism. */
    /* (this.zone is set at the top of the constructor — the generator needs it before this point) */
    const roster = this.safe ? [] : (BESTIARY ? BESTIARY.byZone(this.zone) : []);
    if (BESTIARY && !this.safe && roster.length === 0) {
      throw new Error(`overworld: zone "${this.zone}" has NO creatures — an empty roster spawns an `
        + 'empty world and reports success. If it is MEANT to be empty, add it to SAFE_ZONES.');
    }
    /* ⛔ AND THE CONVERSE, which is the half a whitelist normally forgets: a zone declared SAFE that
     * the bestiary nonetheless populates would silently drop those creatures — content built, gated
     * and unreachable, which is this project's own worst shipped defect (`LB_RETURN`). */
    if (BESTIARY && this.safe && BESTIARY.byZone(this.zone).length > 0) {
      throw new Error(`overworld: zone "${this.zone}" is in SAFE_ZONES but the bestiary gives it `
        + `${BESTIARY.byZone(this.zone).length} creature(s) — one of the two is wrong`);
    }

    /* ⛔ THE OFFSET IS DRAWN ONCE, HERE. Drawing it inside the loop would re-randomise every pick
     * and silently collapse the round-robin back into the uniform draw it exists to replace — a
     * change that looks correct, runs clean, and quietly restores the 32% miss rate. */
    const rosterOffset = roster.length ? Math.floor(this.rng() * roster.length) : 0;

    this.monsters = [];
    /* ⛔ A SAFE ZONE SPAWNS ZERO MONSTERS, and the count is forced to 0 rather than the loop being
     * skipped, so `nMonsters` stays a real number every gate can read and assert on. */
    const nMonsters = this.safe ? 0 : Math.max(5, Math.round(area / this.cfg.monsterEvery));
    for (let i = 0; i < nMonsters; i++) {
      const p = R({ x: this.player.x, y: this.player.y, minDist: diag * 0.2 });
      if (!p) continue;
      /* ⛔ ROUND-ROBIN WITH A SEEDED OFFSET, NOT A FREE RANDOM DRAW. A uniform draw over four
       * creatures leaves at least one absent from a given region about 32% of the time (1 - 4!·S(n,4)/4^n
       * at n=8), i.e. a third of playthroughs never meet a creature that was built, gated and
       * photographed. Round-robin guarantees every roster member appears once the region holds at
       * least `roster.length` monsters, and the seeded offset keeps regions from all opening with
       * the same one. */
      const cr = roster.length ? roster[(i + rosterOffset) % roster.length] : null;
      this.monsters.push({
        x: p.x, y: p.y, home: { x: p.x, y: p.y },
        state: 'patrol', chaseMs: 0, lureMs: 0, defeated: false,
        wander: { x: p.x, y: p.y }, retargetMs: 0,
        creature: cr ? cr.id : null,
        art: cr ? cr.sprite.art : null,
      });
    }

    /* ⭐ BOSSES ARE PLACED, NEVER ROAMED. A boss that wanders can be met first, met by accident, or
     * missed entirely, and this one is the END of the slice — the bestiary says so ("the DEMO ENDS
     * HERE"). It stands AT the heart and does not move: `state:'placed'` is excluded from the patrol
     * and chase update, so it is a landmark until you walk into it.
     * ⚠️ It is still an ordinary entry in `monsters`, so it inherits the ambush path, the carry and
     * the sprite draw for free — the alternative was a second encounter mechanism for one case,
     * which is how two code paths for one idea get born. */
    this.bosses = [];
    if (BESTIARY && this.zone === 'barrow') {
      const bs = BESTIARY.byZone(this.zone, { boss: true });
      bs.forEach((b, i) => {
        const m = {
          x: this.goal.x + (i === 0 ? -TILE : TILE) * 1.5, y: this.goal.y,
          home: { x: this.goal.x, y: this.goal.y },
          state: 'placed', chaseMs: 0, defeated: false,
          wander: { x: this.goal.x, y: this.goal.y }, retargetMs: 0,
          creature: b.id, art: b.sprite.art, boss: true,
        };
        this.monsters.push(m);
        this.bosses.push(m);
      });
    }

    this.encounter = null;   // set when a monster catches the player
    this.arrived = false;
    this.log = [];
    /* instrumentation for §5's gate — every claim about "the overworld couples to combat" is a
     * claim about these numbers */
    this.stats = {
      cachesTaken: 0, encounters: 0, msDark: 0, msLit: 0, sneakedPast: 0, spotted: 0,
      /* lured = times a monster started drifting toward the light; lureLost = times the light died
       * or moved away before it arrived. Kept SEPARATE from spotted/sneakedPast so the new mechanic
       * cannot silently move a number an existing gate already asserts against. */
      lured: 0, lureLost: 0,
    };
  }

  get flameState() {
    if (this.flame <= 0) return 'OUT';
    return this.flame >= this.cfg.flameBrightAt ? 'BRIGHT' : 'LOW';
  }

  get lightRadius() {
    const s = this.flameState;
    return s === 'BRIGHT' ? this.cfg.radiusBright : s === 'LOW' ? this.cfg.radiusLow : this.cfg.radiusOut;
  }

  /** Can a monster at `m` see the player right now? Symmetric with the lantern — that is the point. */
  monsterCanSee(m) {
    const sight = this.flameState === 'OUT' ? this.cfg.monsterSightDark : this.cfg.monsterSightBright;
    return dist(m, this.player) <= sight;
  }

  /**
   * How far away the LANTERN ITSELF is noticed, which is not how far the PLAYER is seen.
   * ⛔ These are deliberately different numbers doing different jobs: sight (210/54) decides
   * whether a monster hunts you, the lure decides whether it is anywhere near you in the first
   * place. An OUT lantern returns 0 — there is no beacon to notice — and that single line is what
   * makes darkness the counterplay rather than a cosmetic.
   */
  get lureRadius() {
    const s = this.flameState;
    if (s === 'OUT') return 0;
    return s === 'BRIGHT' ? this.cfg.monsterLureBright : this.cfg.monsterLureLow;
  }

  /** Is `thing` inside the player's own light? Everything outside it is not drawn and not known. */
  isVisible(thing) { return dist(thing, this.player) <= this.lightRadius; }

  canStand(x, y) {
    const r = this.cfg.playerRadius;
    for (const [dx, dy] of [[-r, -r], [r, -r], [-r, r], [r, r]]) {
      if (isBlocked(this.region, Math.floor((x + dx) / TILE), Math.floor((y + dy) / TILE))) return false;
    }
    return true;
  }

  /**
   * Advance the world. `dir` is a unit-ish {x,y} from the player's input (0,0 = standing still).
   * ⛔ Movement is resolved per AXIS so that sliding along a wall works; a single combined test
   * makes the player stick on corners, which reads as a broken game rather than a tight one.
   */
  tick(dtMs, dir = { x: 0, y: 0 }) {
    if (this.encounter || this.arrived) return;
    const dt = dtMs / 1000;
    this.timeMs += dtMs;

    /* the lantern burns whether you move or not — standing still is not free.
     * ⛔ THE EPSILON CLAMP IS NOT COSMETIC. Burning exactly the full duration leaves a floating
     * point residue (100 - 1875 * 0.05333... ≈ 1.4e-14), and `flameState` tests `flame <= 0`, so
     * the lantern reads LOW forever on a bar the player sees as empty — lit for free, and the OUT
     * state (which is the whole information and stealth system) never arrives. Found by a selftest
     * assertion that the default burn empties the lantern in its own stated duration. */
    this.flame = Math.max(0, this.flame - (this.cfg.flameMax / this.cfg.flameBurnMsToEmpty) * dtMs);
    if (this.flame < 1e-6) this.flame = 0;
    if (this.flameState === 'OUT') this.stats.msDark += dtMs; else this.stats.msLit += dtMs;

    const len = Math.hypot(dir.x, dir.y) || 1;
    const vx = (dir.x / len) * this.cfg.walkSpeed * dt;
    const vy = (dir.y / len) * this.cfg.walkSpeed * dt;
    const moving = dir.x !== 0 || dir.y !== 0;

    if (moving) {
      const before = { x: this.player.x, y: this.player.y };
      let movedX = false; let movedY = false;
      if (vx && this.canStand(this.player.x + vx, this.player.y)) { this.player.x += vx; movedX = true; }
      if (vy && this.canStand(this.player.x, this.player.y + vy)) { this.player.y += vy; movedY = true; }

      /* CORNER RELIEF: when one axis is blocked, slide along the OTHER toward the centre line of
       * the tile being entered, so an off-centre 20 px body squares up and fits through a 32 px
       * gap instead of catching on the corner. This is ordinary 2D game feel — without it a player
       * holding a direction key against a doorway sticks on nothing.
       *
       * ⚠️ HONEST PROVENANCE, because the first version of this comment claimed a receipt it did
       * not have. It was added to explain 8-of-30 bot runs that never reached the dungeon, and it
       * did NOT fix them — the run after this change was byte-for-byte the same. The real cause was
       * in the GATE HARNESS (it held a stale movement delta for a whole replan interval and walked
       * 35.6 px past a waypoint 20 px away, oscillating across the one tile it needed). This code
       * is kept because it is correct for a human on a keyboard, not because it fixed that. ⛔ A
       * fix that ships with someone else's receipt attached is how a wrong diagnosis becomes
       * permanent. */
      const CENTRE = (v) => (Math.floor(v / TILE) + 0.5) * TILE;
      if (vy && !movedY) {
        const cx = CENTRE(this.player.x);
        const nudge = Math.sign(cx - this.player.x) * Math.min(Math.abs(vy), Math.abs(cx - this.player.x));
        if (nudge && this.canStand(this.player.x + nudge, this.player.y)) this.player.x += nudge;
      }
      if (vx && !movedX) {
        const cy = CENTRE(this.player.y);
        const nudge = Math.sign(cy - this.player.y) * Math.min(Math.abs(vx), Math.abs(cy - this.player.y));
        if (nudge && this.canStand(this.player.x, this.player.y + nudge)) this.player.y += nudge;
      }

      this.distanceWalked += dist(before, this.player);
    }

    for (const c of this.caches) {
      if (c.taken) continue;
      if (dist(c, this.player) < 22) {
        c.taken = true;
        this.oil = Math.min(this.cfg.maxOil, this.oil + this.cfg.oilPerCache);
        this.flame = Math.min(this.cfg.flameMax, this.flame + this.cfg.flamePerCache);
        this.stats.cachesTaken++;
        this.log.push(`oil cache at ${this.timeMs | 0}ms`);
      }
    }

    for (const m of this.monsters) {
      if (m.defeated) continue;
      /* ⛔ A PLACED BOSS DOES NOT PATROL, CHASE, OR GIVE UP — it stands at the heart until you walk
       * into it. It still falls through to the contact test below, so the ambush, the carry and the
       * sprite all work exactly as for a roamer; only the movement is skipped. Putting the `continue`
       * before the contact test would make the boss unfightable, which is the kind of bug that
       * passes every gate because nothing asserts you CAN reach the end of the slice. */
      if (m.state === 'placed') {
        /* ⛔⛔ 52, NOT 20 — AND THE 20 MEANT THE END OF THE SLICE WAS WALKED PAST EVERY SINGLE TIME.
         * MEASURED 2026-09-02 (`_spine_probe.js`, 24 seeds, the real model): two bosses placed in
         * every barrow and **0 of 24 runs fought one**. The geometry says why: they stand at
         * `goal.x ± TILE*1.5` = 48 px either side of the ring, `arrived` fires at 26 px, and this
         * test was 20 px — so a player pathing to the goal arrives in the GAP BETWEEN THEM without
         * ever coming close enough to trigger either, and a placed boss never chases (correctly —
         * it is a landmark), which removes the only other way it could have been met.
         * ⭐ NEITHER BOSS WAS BROKEN. `boss_gates` (17/17) proves each is fair, winnable and a real
         * test. It proves the FIGHT is good; nothing proved the fight HAPPENS.
         * ⭐⭐ AND THE COMMENT DIRECTLY ABOVE FORESAW THIS EXACT BUG — "the kind of bug that passes
         * every gate because nothing asserts you CAN reach the end of the slice" — and guarded the
         * version it imagined, a `continue` placed before the contact test. **The defect arrived
         * through the NUMBER instead.** Foreseeing a failure mode protects you only from the
         * spelling of it you happened to picture.
         * ⚠️ 52 > 48 by design: the ring cannot be reached without standing in reach of what guards
         * it. It is derived from the placement above, so if that offset moves this must move too —
         * which is why both now say so in the same words. */
        if (dist(m, this.player) < this.cfg.bossReach) {
          this.encounter = { monster: m, flame: this.flame, oil: this.oil, creature: m.creature || null };
          this.stats.encounters++;
          this.log.push(`BOSS encounter at ${this.timeMs | 0}ms flame ${this.flame.toFixed(1)} oil ${this.oil}`
            + ` vs ${m.creature}`);
          return;
        }
        continue;
      }
      const sees = this.monsterCanSee(m);
      if (sees) {
        if (m.state !== 'chase') this.stats.spotted++;
        m.state = 'chase'; m.chaseMs = 0;
      } else if (m.state === 'chase') {
        m.chaseMs += dtMs;
        if (m.chaseMs > this.cfg.monsterGiveUpMs) { m.state = 'patrol'; this.stats.sneakedPast++; }
      } else if (this.lureRadius > 0) {
        /* ⭐ THE LURE. A monster that cannot SEE the player can still notice the LIGHT, from much
         * further away, and drift toward it at patrol pace. It only becomes a chase if the sight
         * test above then passes — so this changes WHO IS NEAR YOU, never how stealth resolves.
         * ⛔ `lureRadius` is 0 whenever the lantern is OUT (see the getter), so going dark severs
         * this completely: that is the counterplay, and `_lure_probe.js` pre-registers it. */
        if (dist(m, this.player) <= this.lureRadius) {
          if (m.state !== 'lure') { m.state = 'lure'; this.stats.lured++; }
          m.lureMs = 0;
        } else if (m.state === 'lure') {
          m.lureMs += dtMs;
          if (m.lureMs > this.cfg.monsterLureLoseMs) { m.state = 'patrol'; this.stats.lureLost++; }
        }
      } else if (m.state === 'lure') {
        /* the light went OUT this tick — hold the drift briefly, then lose it. Without this a
         * monster snaps back to patrol the instant the flame dies, which reads as the world
         * noticing the player's UI rather than the player's lantern. */
        m.lureMs += dtMs;
        if (m.lureMs > this.cfg.monsterLureLoseMs) { m.state = 'patrol'; this.stats.lureLost++; }
      }

      let tx; let ty;
      if (m.state === 'chase' || m.state === 'lure') { tx = this.player.x; ty = this.player.y; } else {
        m.retargetMs -= dtMs;
        if (m.retargetMs <= 0) {
          m.retargetMs = 1800 + this.rng() * 2200;
          const a = this.rng() * Math.PI * 2; const r = this.rng() * this.cfg.monsterWander;
          m.wander = { x: m.home.x + Math.cos(a) * r, y: m.home.y + Math.sin(a) * r };
        }
        tx = m.wander.x; ty = m.wander.y;
      }
      const d = Math.hypot(tx - m.x, ty - m.y);
      if (d > 2) {
        const sp = this.cfg.monsterSpeed * dt * (m.state === 'chase' ? 1 : 0.55);
        const nx = m.x + ((tx - m.x) / d) * sp;
        const ny = m.y + ((ty - m.y) / d) * sp;
        if (!isBlocked(this.region, Math.floor(nx / TILE), Math.floor(m.y / TILE))) m.x = nx;
        if (!isBlocked(this.region, Math.floor(m.x / TILE), Math.floor(ny / TILE))) m.y = ny;
      }

      if (dist(m, this.player) < 20) {
        /* ⭐ THE COUPLING DESIGN §4 CLAIMS AND HAD NEVER BUILT: the fight begins with the flame and
         * the oil you walked in with, not with a full lantern. */
        /* ⭐ AND WHICH CREATURE. Without this the handoff carries only flame and oil, so combat
         * has no way to know what caught you and every ambush is the same authored teacher. */
        this.encounter = { monster: m, flame: this.flame, oil: this.oil, creature: m.creature || null };
        this.stats.encounters++;
        this.log.push(`encounter at ${this.timeMs | 0}ms flame ${this.flame.toFixed(1)} oil ${this.oil}`
          + ` vs ${m.creature || 'anonymous'}`);
        return;
      }
    }

    /* ⛔ AND THE RING IS EARNED, NOT TOUCHED. `overworld_ui.js` has always described this ending as
     * "reaching the stone ring, HAVING GOT PAST WHAT STANDS IN IT" — and the model never implemented
     * the second half, so the ending fired on proximity alone. The wider contact radius above makes
     * a boss hard to slip past; this makes it impossible, which is what the design says.
     * ⚠️ `[].every()` IS TRUE, and here that is the INTENDED meaning rather than a vacuous pass
     * (master §2b): the moor has no bosses, so "all of them are beaten" is correct for it. Written
     * against `this.bosses`, which is empty outside the barrow by construction. */
    const guarded = (this.bosses || []).some((b) => !b.defeated);
    if (dist(this.goal, this.player) < 26 && !guarded) {
      this.arrived = true;
      this.log.push(`arrived at ${this.timeMs | 0}ms flame ${this.flame.toFixed(1)} oil ${this.oil}`);
    }
  }

  /* ================================================================================================
   * ⛔⛔ THE WALK, MADE RESUMABLE — THE OTHER HALF OF A SEAM THAT WAS ONE-WAY. Added 2026-09-02.
   * ================================================================================================
   * `overworld_ui.js` has always READ `sessionStorage.LB_RETURN` to restore the lantern after a
   * fight, and NOTHING HAS EVER WRITTEN IT (`seam_gates.js` now fails on exactly that). The walk
   * handed you into a fight and the fight had nowhere to hand you back, so the moor's goal, the
   * breach, the whole cairn field, both bosses and the authored ending card were built, gated and
   * unreachable in play. `resolveEncounter()` below has always existed to take the outcome — it
   * simply had no caller that could survive a page navigation.
   *
   * ⭐ THE REGION IS A PURE FUNCTION OF THE SEED, so a snapshot does not have to carry a map: it
   * carries the seed and the handful of facts the generator cannot re-derive — where you stood,
   * which monsters are dead, which caches are spent, and the lantern.
   * ⛔ AND THE RESTORE REFUSES RATHER THAN GUESSES. Monsters are matched BY INDEX, which is only
   * valid because generation is deterministic — so `restore` re-derives the roster and compares the
   * creature ids in order; a mismatch (a bestiary edit between save and load, a hand-edited
   * sessionStorage — it is player-writable) returns null and the caller starts a fresh region. A
   * restore that silently applied "defeated" to the wrong creature would be worse than no restore,
   * because it would look like it worked.
   */
  snapshot() {
    return {
      v: 1,
      seed: this.seed,
      zone: this.zone,
      player: { x: this.player.x, y: this.player.y },
      flame: this.flame,
      oil: this.oil,
      timeMs: this.timeMs,
      distanceWalked: this.distanceWalked,
      stats: Object.assign({}, this.stats),
      /* creature id is carried for the INTEGRITY CHECK, not to rebuild from */
      monsters: this.monsters.map((m) => ({ c: m.creature || null, d: !!m.defeated, x: m.x, y: m.y })),
      caches: this.caches.map((c) => (c.taken ? 1 : 0)),
    };
  }

  /** Resolve an encounter the caller has finished elsewhere (combat.js owns the fight itself). */
  resolveEncounter({ won, flame, oil }) {
    if (!this.encounter) return;
    if (won) this.encounter.monster.defeated = true;
    else this.encounter.monster.state = 'patrol';
    this.flame = flame === undefined ? this.flame : flame;
    this.oil = oil === undefined ? this.oil : oil;
    /* push the monster off the player so the next tick does not instantly re-trigger */
    const m = this.encounter.monster;
    const d = dist(m, this.player) || 1;
    m.x += ((m.x - this.player.x) / d) * 90;
    m.y += ((m.y - this.player.y) / d) * 90;
    m.chaseMs = 0; m.state = 'patrol';
    this.encounter = null;
  }
}

/**
 * Rebuild a walk from `snapshot()`. Returns an `Overworld`, or **null** if the snapshot cannot be
 * trusted — see the note on `snapshot()` for why refusing beats guessing.
 * ⚠️ Every field is re-validated rather than typechecked once: `sessionStorage` is player-writable,
 * so this is parsing hostile input, not reading our own memory.
 */
function restore(snap, opts = {}) {
  /* ⛔ EVERY REFUSAL NAMES ITSELF. The first build of this returned a bare `null` on eight different
   * conditions, and when the round trip failed in `gate_a_loop.js` the harness could report only
   * "you are on a fresh walk" — true, useless, and indistinguishable between a hostile snapshot, a
   * roster change and a bug in this function. A silent refusal is the exact shape this project keeps
   * finding: correct behaviour that cannot be told apart from a defect. `restore.lastRefusal` is
   * read by the page and surfaced to the harness. */
  restore.lastRefusal = null;
  const no = (why) => { restore.lastRefusal = why; return null; };

  if (!snap || snap.v !== 1) return no(`bad or missing snapshot (v=${snap && snap.v})`);
  if (typeof snap.seed !== 'number' || !isFinite(snap.seed)) return no('seed is not a finite number');
  /* ⛔ VALIDATED AGAINST THE MODEL'S OWN ZONE LIST, NOT A SECOND COPY OF IT. This line used to read
   * `snap.zone !== 'moor' && snap.zone !== 'barrow'` — written when there were two places, correct
   * for exactly as long as that was true, and then wrong in the most expensive possible direction:
   * a walk that began in Aldermoor could not come back from a fight, and the refusal named a zone
   * the model builds perfectly well. A hard-coded list beside a table is a divergence with a date
   * on it (wing §6d-10). */
  if (!GENERATORS[snap.zone]) return no(`unknown zone "${snap.zone}"`);
  if (!Array.isArray(snap.monsters) || !Array.isArray(snap.caches)) return no('monsters/caches are not arrays');
  if (!snap.player || typeof snap.player.x !== 'number' || typeof snap.player.y !== 'number') return no('no player position');
  if (typeof snap.flame !== 'number' || !isFinite(snap.flame)) return no('flame is not a finite number');

  const w = new Overworld(Object.assign({}, opts, { seed: snap.seed, zone: snap.zone }));

  /* ⛔ THE INTEGRITY CHECK. Index matching is only valid while generation is deterministic; if the
   * bestiary, the generator or the config changed between save and load, the same seed yields a
   * different roster and applying `defeated` by index would mark the WRONG creature dead. */
  if (w.monsters.length !== snap.monsters.length) {
    return no(`roster size changed: regenerated ${w.monsters.length}, snapshot ${snap.monsters.length}`);
  }
  for (let i = 0; i < w.monsters.length; i++) {
    if ((w.monsters[i].creature || null) !== (snap.monsters[i].c || null)) {
      return no(`roster order changed at ${i}: regenerated "${w.monsters[i].creature}", snapshot "${snap.monsters[i].c}"`);
    }
  }
  if (w.caches.length !== snap.caches.length) {
    return no(`cache count changed: regenerated ${w.caches.length}, snapshot ${snap.caches.length}`);
  }

  /* ⛔ THE PLAYER MUST LAND SOMEWHERE WALKABLE. A hand-edited position inside a wall would make the
   * game unplayable in a way that looks like a physics bug; refusing sends them to a fresh region.
   * ⛔⛔ IN TILE COORDINATES. `isBlocked(region, tx, ty)` indexes `region.tiles`, and the snapshot
   * stores PIXELS. Written with pixels this refused every single resume — (2136,908) against a
   * region 100 tiles wide is out of bounds, and `isBlocked` returns TRUE for out of bounds, so a
   * player standing on open grass was reported "inside a wall" and the whole return leg fell back
   * to a fresh walk. ⭐ A UNIT MISMATCH INTO A BOUNDS CHECK FAILS CLOSED AND LOOKS EXACTLY LIKE THE
   * CONDITION IT GUARDS AGAINST — and it was only visible because the refusal names its reason;
   * a bare `null` would have made this "resume silently never works". */
  const ptx = Math.floor(snap.player.x / TILE);
  const pty = Math.floor(snap.player.y / TILE);
  if (isBlocked(w.region, ptx, pty)) {
    return no(`player tile (${ptx},${pty}) from px (${Math.round(snap.player.x)},${Math.round(snap.player.y)}) is blocked`);
  }
  w.player.x = snap.player.x;
  w.player.y = snap.player.y;

  w.flame = Math.max(0, Math.min(w.cfg.flameMax, snap.flame));
  w.oil = Math.max(0, snap.oil | 0);
  w.timeMs = Math.max(0, Number(snap.timeMs) || 0);
  w.distanceWalked = Math.max(0, Number(snap.distanceWalked) || 0);
  if (snap.stats && typeof snap.stats === 'object') {
    for (const k of Object.keys(w.stats)) {
      if (typeof snap.stats[k] === 'number' && isFinite(snap.stats[k])) w.stats[k] = snap.stats[k];
    }
  }
  snap.monsters.forEach((s, i) => {
    const m = w.monsters[i];
    m.defeated = !!s.d;
    /* ⚠️ A PLACED boss keeps its authored position — it is a landmark, not a roamer, and letting a
     * snapshot move it would put the end of the slice somewhere the layout says nothing about. */
    /* ⛔ TILE COORDINATES here too — see the note on the player check above. */
    if (m.state !== 'placed' && typeof s.x === 'number' && typeof s.y === 'number'
        && !isBlocked(w.region, Math.floor(s.x / TILE), Math.floor(s.y / TILE))) {
      m.x = s.x; m.y = s.y; m.home = { x: s.x, y: s.y }; m.wander = { x: s.x, y: s.y };
    }
    m.state = m.state === 'placed' ? 'placed' : 'patrol';
    m.chaseMs = 0;
  });
  snap.caches.forEach((t, i) => { w.caches[i].taken = !!t; });
  return w;
}

const API = { Overworld, DEFAULTS, TILE, T, BLOCKED, generateRegion, generateBarrow, generateTown, GENERATORS, SAFE_ZONES, isBlocked, dist, findOpen, reachableSet, restore };
if (typeof module !== 'undefined' && module.exports) module.exports = API;
if (typeof window !== 'undefined') window.LBW = API;
}());
