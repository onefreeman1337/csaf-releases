'use strict';
/* ================================================================================================
 * audio.js — LANTERNBOUND's runtime audio. Music from files, SFX from oscillators.
 * ================================================================================================
 * ⛔ WHY THE SPLIT. `preflight -> game-audio-assets` counts FILES and its own text says procedural
 * synthesis "is fine for SFX and needs no AI tag, but it is not a whole audio layer". So the MUSIC
 * ships as three .ogg files composed in Internal_Ops/Audio/compose.js, and the SFX are synthesised
 * here at runtime: bespoke, our own IP, zero bytes, and impossible to get a licence wrong. That is
 * the same shape BrassOrrery settled on and it is the doctrine's intended reading, not a dodge.
 *
 * ⭐ THE LANTERN FILTER IS THE POINT OF THIS FILE, AND IT IS THE CHEAPEST GOOD IDEA IN THE PROJECT.
 * One BiquadFilter on the music bus, its cutoff driven by the SAME flame value combat.js burns.
 * As the lantern dies the score goes muffled and quiet along with the picture, and when it gutters
 * out the music is a rumble behind a wall. The game's whole premise — you are losing the light —
 * becomes something you HEAR without a single extra asset or line of design. DESIGN §4 says losing
 * the flame costs you information; this makes the loss sensory rather than announced.
 *
 * ⛔ EVERY ENTRY POINT IS A NO-OP WITHOUT AudioContext. `ui_smoke.js` runs the front end in a Node
 * sandbox with no Web Audio at all, and a browser blocks audio until a user gesture. Neither may
 * break the game: audio is an enhancement and a silent game must still be a playable one.
 * ============================================================================================== */
(function () {
  /* declared once in `paths.js` since 2026-09-03 — see the head of that file */
  const BASE = (typeof window !== 'undefined' && window.LB_PATHS)
    ? window.LB_PATHS.audio : '../../Product_Release/audio/';

  const AC = (typeof window !== 'undefined')
    && (window.AudioContext || window.webkitAudioContext);

  let ctx = null;
  let musicBus = null;      /* gain -> filter -> master */
  let lanternFilter = null;
  let sfxBus = null;
  let master = null;
  let current = null;       /* { name, source, gain } */
  let manifest = null;
  const buffers = {};
  let muted = false;
  let failed = [];

  /* the flame the filter is following, 0..1, so a resume mid-fight opens to the right place */
  let flame01 = 1;

  function ready() { return !!ctx && !!master; }

  /**
   * Build the graph. MUST be called from a user gesture or the context starts suspended and every
   * later `start()` is silent with no error anywhere — the commonest way browser audio "works" in
   * development and ships mute.
   */
  function init() {
    if (ctx || !AC) return ready();
    try {
      ctx = new AC();
      master = ctx.createGain();
      master.gain.value = 0.85;
      master.connect(ctx.destination);

      lanternFilter = ctx.createBiquadFilter();
      lanternFilter.type = 'lowpass';
      lanternFilter.frequency.value = 18000;
      lanternFilter.Q.value = 0.7;
      lanternFilter.connect(master);

      musicBus = ctx.createGain();
      musicBus.gain.value = 0.55;
      musicBus.connect(lanternFilter);

      /* ⛔ SFX DO NOT GO THROUGH THE LANTERN FILTER. The music is the WORLD and the world goes dark
       * with the flame; a UI click is the player's own hand and must stay crisp and legible at the
       * exact moment the screen is hardest to read. Routing both through one filter would make the
       * game least responsive precisely when it is most tense. */
      sfxBus = ctx.createGain();
      sfxBus.gain.value = 0.6;
      sfxBus.connect(master);
      return true;
    } catch (e) {
      failed.push(`AudioContext: ${e.message}`);
      ctx = null;
      return false;
    }
  }

  /** Browsers suspend the context until a gesture; call this from any input handler. */
  function resume() {
    if (!ctx) { init(); }
    if (ctx && ctx.state === 'suspended' && ctx.resume) ctx.resume().catch(() => {});
    return ready();
  }

  async function loadManifest() {
    if (manifest) return manifest;
    try {
      const r = await fetch(`${BASE}tracks.json`);
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      manifest = await r.json();
    } catch (e) {
      failed.push(`tracks.json: ${e.message}`);
      manifest = { tracks: [] };
    }
    return manifest;
  }

  async function load(name) {
    if (buffers[name]) return buffers[name];
    if (!ready()) return null;
    try {
      const r = await fetch(`${BASE}${name}.ogg`);
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const bytes = await r.arrayBuffer();
      buffers[name] = await ctx.decodeAudioData(bytes);
      return buffers[name];
    } catch (e) {
      failed.push(`${name}.ogg: ${e.message}`);
      return null;
    }
  }

  /**
   * Loop a track, crossfading out whatever is playing.
   * ⛔ THE LOOP POINT COMES FROM THE MANIFEST, NEVER FROM A CONSTANT HERE. The renderer appends a
   * release-and-reverb tail, so looping the whole buffer leaves an audible gap at the wrap;
   * compose.js measures each track and writes `loopEnd`, so if synth.js ever retunes its reverb the
   * number moves with it. A duration typed into this file could not notice (master §2b: an assert
   * must re-derive, never restate).
   */
  async function playMusic(name, opts = {}) {
    if (!ready()) return false;
    await loadManifest();
    const buf = await load(name);
    if (!buf) return false;
    if (current && current.name === name && !opts.restart) return true;

    const now = ctx.currentTime;
    if (current) {
      const old = current;
      old.gain.gain.cancelScheduledValues(now);
      old.gain.gain.setValueAtTime(old.gain.gain.value, now);
      old.gain.gain.linearRampToValueAtTime(0.0001, now + 0.6);
      try { old.source.stop(now + 0.7); } catch (e) { /* already stopped */ }
    }

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, now);
    g.gain.linearRampToValueAtTime(1, now + (opts.fadeIn == null ? 0.8 : opts.fadeIn));
    g.connect(musicBus);

    const src = ctx.createBufferSource();
    src.buffer = buf;
    const meta = (manifest.tracks || []).find((t) => t.name === name);
    if (opts.loop === false) {
      src.loop = false;
    } else {
      src.loop = true;
      src.loopStart = 0;
      src.loopEnd = (meta && meta.loopEnd > 0) ? meta.loopEnd : buf.duration;
    }
    src.connect(g);
    src.start(now);
    current = { name, source: src, gain: g };
    return true;
  }

  /** A one-shot over the top of the music, ducking it briefly. Used for the win sting. */
  async function sting(name) {
    if (!ready()) return false;
    const buf = await load(name);
    if (!buf) return false;
    const now = ctx.currentTime;
    if (current) {
      current.gain.gain.cancelScheduledValues(now);
      current.gain.gain.setValueAtTime(current.gain.gain.value, now);
      current.gain.gain.linearRampToValueAtTime(0.12, now + 0.25);
    }
    const g = ctx.createGain();
    g.gain.value = 1.1;
    g.connect(musicBus);
    const src = ctx.createBufferSource();
    src.buffer = buf; src.connect(g); src.start(now);
    return true;
  }

  function stopMusic(fade = 0.5) {
    if (!ready() || !current) return;
    const now = ctx.currentTime;
    current.gain.gain.cancelScheduledValues(now);
    current.gain.gain.setValueAtTime(current.gain.gain.value, now);
    current.gain.gain.linearRampToValueAtTime(0.0001, now + fade);
    try { current.source.stop(now + fade + 0.1); } catch (e) { /* already stopped */ }
    current = null;
  }

  /**
   * ⭐ THE LANTERN, HEARD. `f01` is flame/flameMax, straight off the combat model.
   * The map is EXPONENTIAL because pitch perception is: a linear cutoff sweep spends almost all of
   * its travel in a range nobody can hear changing. 400 Hz at nothing left, ~19 kHz at full — so a
   * dying lantern audibly closes the world down, and a relight opens it back up.
   */
  function setFlame(f01) {
    flame01 = Math.max(0, Math.min(1, Number(f01) || 0));
    if (!ready()) return;
    /* ⭐ FLOOR LOWERED 400 -> 200 Hz on 2026-09-02, from a MEASUREMENT, not a preference.
     * `Audio/audio_gate.js` found the lantern bit mus_battle hard (melody:bass fell 9.3 dB across
     * the sweep) and mus_moor almost not at all (3.2 dB) — because the moor's melodic voices sit
     * LOWER (bell 392-698, soft 330-587) than the battle's lead (466-932), so a 400 Hz corner
     * passed most of the moor's tune. Since overworld_ui.js drives this filter too, a dying
     * lantern was nearly INAUDIBLE in the place the player spends most of their time.
     * `Audio/_lantern_floor_probe.js` swept candidate floors with the top pinned at 19.2 kHz so
     * full flame is unchanged:
     *     floor 400 -> moor 3.2 dB, battle  9.3     floor 200 -> moor  7.9, battle 19.8
     *     floor 320 -> moor 4.4 dB, battle 12.5     floor 160 -> moor 10.1, battle 23.3
     *     floor 260 -> moor 5.8 dB, battle 15.6     floor 120 -> moor 12.9, battle 27.7
     * 200 Hz is the MINIMAL change that gets both cues over a 6 dB bar, which is why it was
     * chosen over the more dramatic rows — those stay available, with numbers, if a playtest
     * ever asks for more. 19200/200 = 96, so the multiplier moves with the floor. */
    const cutoff = 200 * Math.pow(96, flame01);
    const now = ctx.currentTime;
    /* setTargetAtTime, not setValueAtTime: this is called every frame and a stepped filter clicks */
    lanternFilter.frequency.setTargetAtTime(cutoff, now, 0.25);
    /* and the world gets quieter as well as duller — but never to nothing */
    musicBus.gain.setTargetAtTime(0.28 + 0.27 * flame01, now, 0.35);
  }

  /* ------------------------------------------------------------------ SFX ---------------------
   * Synthesised per fire from oscillators and filtered noise. Bespoke, zero bytes, CSAF's own IP,
   * and NOT generative AI — itch is explicit that self-contained procedural synthesis is not, so no
   * Gen-AI audio tag is owed (master §4.1).
   */
  function noiseBuffer(seconds) {
    const n = Math.floor(ctx.sampleRate * seconds);
    const b = ctx.createBuffer(1, n, ctx.sampleRate);
    const d = b.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    return b;
  }

  /** One shaped oscillator note. */
  function tone(o) {
    const t0 = ctx.currentTime + (o.delay || 0);
    const osc = ctx.createOscillator();
    osc.type = o.wave || 'square';
    osc.frequency.setValueAtTime(o.from, t0);
    if (o.to && o.to !== o.from) osc.frequency.exponentialRampToValueAtTime(Math.max(1, o.to), t0 + o.dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(o.gain || 0.2, t0 + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + o.dur);
    osc.connect(g); g.connect(sfxBus);
    osc.start(t0); osc.stop(t0 + o.dur + 0.02);
  }

  /** One shaped noise burst. */
  function hiss(o) {
    const t0 = ctx.currentTime + (o.delay || 0);
    const src = ctx.createBufferSource();
    src.buffer = noiseBuffer(o.dur + 0.02);
    const f = ctx.createBiquadFilter();
    f.type = o.type || 'bandpass';
    f.frequency.setValueAtTime(o.from, t0);
    if (o.to && o.to !== o.from) f.frequency.exponentialRampToValueAtTime(Math.max(1, o.to), t0 + o.dur);
    f.Q.value = o.q == null ? 1.2 : o.q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(o.gain || 0.15, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + o.dur);
    src.connect(f); f.connect(g); g.connect(sfxBus);
    src.start(t0); src.stop(t0 + o.dur + 0.02);
  }

  /* Each entry is designed against something the player can SEE on screen, so the ear and the eye
   * are describing the same event. */
  const SFX = {
    select:     () => tone({ wave: 'square', from: 660, to: 880, dur: 0.06, gain: 0.10 }),
    /* the three press qualities are one gesture at three heights — the player learns the pitch */
    perfect:    () => { tone({ wave: 'square', from: 880, to: 1760, dur: 0.09, gain: 0.16 });
      tone({ wave: 'square', from: 1320, to: 2640, dur: 0.10, gain: 0.09, delay: 0.05 }); },
    good:       () => tone({ wave: 'square', from: 660, to: 990, dur: 0.09, gain: 0.13 }),
    miss:       () => tone({ wave: 'sawtooth', from: 320, to: 150, dur: 0.16, gain: 0.12 }),
    hit:        () => { hiss({ from: 1800, to: 300, dur: 0.14, gain: 0.20, q: 0.9 });
      tone({ wave: 'triangle', from: 180, to: 70, dur: 0.16, gain: 0.20 }); },
    /* the round won: a rising third, the only consonant SFX in the set */
    lockBroken: () => { tone({ wave: 'triangle', from: 587, dur: 0.13, gain: 0.15 });
      tone({ wave: 'triangle', from: 880, dur: 0.20, gain: 0.15, delay: 0.09 }); },
    /* the enemy's attack landing: low, blunt, no pitch movement to hold on to */
    lockLanded: () => { tone({ wave: 'sawtooth', from: 140, to: 90, dur: 0.28, gain: 0.20 });
      hiss({ from: 700, to: 200, dur: 0.22, gain: 0.14, q: 0.7 }); },
    relight:    () => { hiss({ from: 400, to: 3000, dur: 0.30, gain: 0.16, q: 0.6 });
      tone({ wave: 'triangle', from: 330, to: 660, dur: 0.32, gain: 0.12 }); },
    /* the flame going out: the only sound in the set that FALLS all the way to nothing */
    guttering:  () => { hiss({ from: 2200, to: 180, dur: 0.55, gain: 0.18, q: 0.8 });
      tone({ wave: 'sine', from: 220, to: 60, dur: 0.60, gain: 0.10 }); },
    down:       () => { tone({ wave: 'sawtooth', from: 300, to: 60, dur: 0.45, gain: 0.16 }); },
  };

  function sfx(name) {
    if (!ready() || muted) return false;
    const f = SFX[name];
    if (!f) return false;
    try { f(); return true; } catch (e) { return false; }
  }

  function setMuted(v) {
    muted = !!v;
    try { window.localStorage.setItem('LB_MUTED', muted ? '1' : '0'); } catch (e) { /* private mode */ }
    if (ready()) master.gain.setTargetAtTime(muted ? 0 : 0.85, ctx.currentTime, 0.05);
    return muted;
  }
  try { muted = window.localStorage.getItem('LB_MUTED') === '1'; } catch (e) { muted = false; }

  const API = {
    init, resume, playMusic, stopMusic, sting, setFlame, sfx,
    setMuted, toggleMute: () => setMuted(!muted),
    get muted() { return muted; },
    get available() { return !!AC; },
    get ready() { return ready(); },
    get state() { return ctx ? ctx.state : 'none'; },
    get failed() { return failed.slice(); },
    get playing() { return current ? current.name : null; },
    get flame() { return flame01; },
    SFX_NAMES: Object.keys(SFX),
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  if (typeof window !== 'undefined') window.LB_AUDIO = API;
}());
