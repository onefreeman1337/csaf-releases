'use strict';
/* ================================================================================================
 * LANTERNBOUND — the OVERWORLD front end. GREY BOXES ON PURPOSE.
 * ================================================================================================
 * Exists so DESIGN §8 gate A can be run on the LOOP rather than on the combat alone. §A2 measured
 * that the timed press does not decide outcomes, which means the flow this game promises lives out
 * here — so a fun review that never leaves the battle screen is testing the wrong half.
 *
 * ⛔ ONE COMBAT RENDERER, EVER. When a monster catches you this page does NOT draw a fight; it
 * stores the carried flame and oil and hands off to `index.html`, which owns combat rendering. Two
 * renderers for one model is the shared-fact trap the wing has already paid for (CLAUDE.md §6d-10:
 * a shared generator is a shared fact, and every consumer holding its own copy is a place the game
 * moves without anyone editing it).
 *
 * ⛔ MEASURED ELAPSED TIME, NEVER A FRAME COUNT (wing §1a) — the automation tab throttles rAF to
 * zero, so a frame-counted lantern reads as frozen under exactly the conditions we test under.
 */
(function () {
  /* ⛔ BLOCKED comes from the MODEL, never re-listed here. Which tiles stop the player is a
   * collision fact owned by overworld.js; a second copy in the renderer is a place where the
   * picture and the collision can silently disagree (§6d-10). */
  const { Overworld, TILE, T, BLOCKED, restore } = window.LBW;

  const W = 760; const H = 520;
  const cv = document.getElementById('screen');
  cv.width = W; cv.height = H;
  const g = cv.getContext('2d');

  /* Terrain reads as VALUE, not hue — the lantern is the only real colour on screen, which is the
   * whole point of the art direction this prototype stands in for.
   *
   * ⛔ THE FIRST PALETTE WAS TOO DARK TO PLAY. Photographing a real crossing showed an
   * undifferentiated black blob: grass (#232a24) and ROCK (#15161a) were indistinguishable at the
   * alphas the falloff produced, so a player could not see what they were about to walk into. In a
   * game whose whole flow layer is moving through a space, not being able to see the space is a
   * mechanical failure, not a mood. Open ground is now clearly lighter than blocked ground, and
   * walls get a lit top edge so they read as solid rather than as absence. The DARK still comes
   * from the lantern going out, which is where the fear is supposed to come from. */
  const TERRAIN = {
    [T.GRASS]: '#333f31',
    [T.PATH]: '#57503e',
    [T.ROCK]: '#0c0d11',
    [T.WATER]: '#20384f',
    [T.TREE]: '#1e2f20',
  };
  const WALL_EDGE = { [T.ROCK]: '#4a4a58', [T.TREE]: '#3a5238', [T.WATER]: '#3a5a78' };

  /* ⭐ THE ART LAYER, added 2026-09-02. The flat colours above are now the FALLBACK, not the
   * product — kept, and kept working, because a game that draws nothing when a sheet 404s is worse
   * than a game that draws squares, and because `overworld_selftest.js` runs with no DOM images.
   * ⛔ The enum-name bridge is deliberate: `world_art.js` must never hold its own copy of the tile
   * enum (§6d-10, the shared-fact rule), so the NAME is resolved here, once, from `T` itself. */
  const ART = window.LB_WORLD_ART || null;
  /* the combat stage, for its `light()` ONLY — one lighting model for the whole game */
  const ST = window.LB_STAGE || null;
  const HUD_H = 52;                      // the HUD strip at the foot; the lit world stops above it
  const KIND_NAME = Object.fromEntries(Object.entries(T).map(([name, v]) => [v, name]));
  let artReady = false;
  const SPRITE_PX = 64;
  const field = {};

  function loadFieldSprite(key, rel) {
    const i = new Image();
    i.onload = () => { if (i.naturalWidth === SPRITE_PX) field[key] = i; };
    /* the base is declared once in `paths.js` — see the note there */
    const base = (typeof window !== 'undefined' && window.LB_PATHS)
      ? window.LB_PATHS.assets : '../../Product_Release/assets/';
    i.src = `${base}${rel}`;
  }

  let world = null;
  /* why the last resume attempt did or did not take — read by gate_a_loop leg 3 */
  let resumeDiag = null;
  let seed = 1;
  let lastT = 0;
  const keys = new Set();

  /* ================================================================================================
   * ⭐ THE STORY PLAYHEAD. Added 2026-09-02 — see the head of `story.js` for why it did not exist.
   * ================================================================================================
   * ⛔ EVERY BEAT FIRES ON THIS PAGE, DELIBERATELY, INCLUDING THE BOSS ONES. A fight is a full page
   * navigation to `index.html`, and this project has already lost its entire second half to one
   * thing read across that seam and written by nothing. Boss beats therefore fire on the RETURN
   * (`resumeFromFight` below, where the outcome and the creature are both in hand) rather than on
   * the combat page, so the narrative layer never crosses the seam at all — only the small `seen`
   * set does, and `story_gates.js` round-trips it.
   *
   * ⛔ `LB_STORY_SEEN` IS READ **AND** WRITTEN HERE, in this file, and nowhere else. That is the
   * invariant `seam_gates.js` enforces for every storage key in the game.
   */
  const STORY = window.LB_STORY || null;
  const SEEN_KEY = 'LB_STORY_SEEN';

  function loadStory() {
    if (!STORY) return null;
    try {
      const raw = sessionStorage.getItem(SEEN_KEY);
      return raw ? STORY.Story.from(JSON.parse(raw)) : new STORY.Story();
    } catch (e) {
      /* storage unavailable or corrupt: a fresh playhead replays a scene, which is the harmless
       * failure. Never let the story layer cost the player their walk. */
      return new STORY.Story();
    }
  }

  let story = loadStory();

  function saveStory() {
    if (!story) return;
    try { sessionStorage.setItem(SEEN_KEY, JSON.stringify(story.toJSON())); } catch (e) { /* fine */ }
  }

  /** Hand the playhead a trigger. Null-safe, so the page still runs with story.js absent. */
  function beat(trigger) {
    if (!story) return null;
    const b = story.fire(trigger);
    if (b) saveStory();
    return b;
  }

  /* ------------------------------------------------------------------------------------------------
   * ⛔ ONE ZONE TABLE, NOT A CHAIN OF `zone === 'barrow'` TERNARIES.
   * ------------------------------------------------------------------------------------------------
   * This file tested `zone === 'barrow'` in SIX places — the art table, the scatter, the goal marker,
   * the SPACE handler, the arrival beat and the HUD. With two zones that reads fine, because
   * "barrow" and "not barrow" are the same partition however you spell it. The third zone breaks
   * that: a town is not a barrow, so every `: MATERIAL` fallback silently claimed the town was the
   * MOOR — the moor's sward and heath drawn over a farmstead layout, with nothing thrown.
   *
   * ⭐ That is master §2b's "an unconfigured default is not a decision" in a renderer. A table makes
   * a missing zone a visible hole (`undefined`) instead of a silent inheritance, and it puts every
   * per-zone fact for one place on ONE line where they can be read together.
   * ---------------------------------------------------------------------------------------------- */
  /* ⛔⛔ AND `canEnterMouth: true/false` WAS THE SAME DEFECT ONE LEVEL DOWN. 2026-09-03.
   * A boolean called "can you go on" cannot say WHERE, so the only caller hard-coded the
   * destination (`enterBarrow()`), and the town — which sets the flag false — had no way out at
   * all. Three zones with one hard-coded edge is a graph with a hole in it. `nextZone` names the
   * edge, so a place that can be left declares where it leads and the transition is one function.
   * ⚠️ `goalLabel` moved in here for the same reason: the renderer was still asking
   * `w.zone === 'town' ? 'GATE' : 'MOUTH'` fifty lines away, which is precisely the per-zone
   * conditional this table was created to collect.
   * ⚠️ READ THE TWO BEAT FIELDS AS A PAIR, they are about OPPOSITE ENDS of a visit:
   *     `arriveBeat` — fired when the player reaches THIS zone's goal (its exit).
   *     `enterBeat`  — fired when the player arrives IN this zone from somewhere else.
   * `enterNext()` reads `enterBeat` off the DESTINATION. Filled the other way round — 'barrow' on
   * the moor's row, meaning "the beat for going to the barrow" — the town's departure played the
   * cairn-field scene on open moorland and entering the barrow played nothing, which is two beats
   * wrong from one field read in the wrong direction. Caught 2026-09-03 by story_gates 3b, in the
   * same run that first crossed the seam. */
  const ZONES = {
    /* the safe hub, and where every run begins: the last lit place, one well, no creatures */
    town: {
      art: () => ART.TOWN_MATERIAL, scatterProps: () => ART.TOWN_SCATTER_PROPS,
      showGoalMarker: true, goalLabel: 'GATE', arriveBeat: 'gate',
      nextZone: 'moor', enterBeat: null,
      /* ⭐ ALDERMOOR IS LIT, AND UNTIL 2026-09-03 THAT WAS A COMMENT RATHER THAN A PICTURE.
       * `overworld.js`'s own header says the town "is lit — hearths and a lantern over the gate — so
       * the light/dark language reads in REVERSE for one screen, which is what makes the moor read
       * as dark when you walk back out". MEASURED on the first frames ever taken of it: at FULL
       * lantern the town was 90.1% below luma 40 against the burial ground's 91.3% — the safe hamlet
       * and the graveyard were the same picture, so the reversal the design is built on did not
       * exist. ⚠️ The moor's floor of 0 is not a house style, it is the INFORMATION MECHANIC: a
       * visible floor out there draws the map through the dark and hands the player a free minimap.
       * Nothing hunts you in Aldermoor, so there is no information to protect and the reason does
       * not carry. Value chosen by measuring, not taste — see the devlog for the sweep. */
      lightFloor: 46,
      /* the whole viewport: a hamlet you can only see one lantern-width of is not a hamlet, and
       * there is no information to protect here (nothing hunts you), which is the ONLY reason the
       * moor culls tight. */
      cullMult: 99,
    },
    moor: {
      art: () => ART.MATERIAL, scatterProps: () => ART.SCATTER_PROPS,
      showGoalMarker: true, goalLabel: 'MOUTH', arriveBeat: 'breach',
      /* entered from the town, and the `gate` beat has just been read at the other side of the
       * hedge — a second scene here would be two cards on one decision */
      nextZone: 'barrow', enterBeat: null,
      lightFloor: 0, cullMult: 1.9,
    },
    barrow: {
      art: () => ART.SITE_MATERIAL, scatterProps: null,
      showGoalMarker: false, goalLabel: 'MOUTH', arriveBeat: 'ring',
      nextZone: null, enterBeat: 'barrow',
      lightFloor: 0, cullMult: 1.9,
    },
  };
  /* ⛔ THROWS on an unknown zone rather than falling back to the moor. A zone typo that silently
   * rendered as the moor is precisely the class this table replaces. */
  function ZONE(z) {
    const cfg = ZONES[z];
    if (!cfg) throw new Error(`overworld_ui: unknown zone "${z}" — add it to ZONES, never default it`);
    return cfg;
  }
  const ZONE_ART = (z) => ZONE(z).art();

  /* ⛔ NO DEFAULT ZONE ANY MORE. `zone = 'moor'` was an unconfigured default standing in for a
   * decision (master §2b), and it is exactly how the town became unreachable: both callers that
   * mattered — the boot and `R` — simply omitted the argument, so the only place the game could
   * ever start was the one the parameter list happened to name. Every caller now says where. */
  function newRegion(s, zone) {
    if (!zone) throw new Error('overworld_ui: newRegion needs an explicit zone — a default here is '
      + 'a decision nobody made, and it is what left Aldermoor unreachable for a day');
    seed = s;
    world = new Overworld({ seed: s, externalClock: true, zone });
    lastT = performance.now();
  }

  /**
   * ⭐⭐ COME BACK FROM A FIGHT — and this replaces a version that could not possibly have worked.
   *
   * ⛔ THE OLD CODE LIVED INSIDE `newRegion` AND RESTORED ONLY `flame` AND `oil`, ONTO A REGION IT
   * HAD JUST REGENERATED. Even if something had written `LB_RETURN` (nothing ever did — that is the
   * defect `seam_gates.js` now fails on), the player would have been returned to the START of the
   * moor with every monster alive, including the one they had just killed, and every cache refilled
   * — i.e. an infinite loop against the same ambush. **The dead reader was hiding a second bug**: a
   * restore that carried two numbers across a seam that loses a world.
   *
   * ✅ `overworld.js restore()` rebuilds the walk from a snapshot the WORLD authored: the region is
   * a pure function of the seed, so the snapshot only carries what the generator cannot re-derive.
   * It REFUSES (returns null) if the roster no longer matches by index, and a refusal starts a fresh
   * region rather than a subtly wrong one.
   * ⚠️ `resolveEncounter` is the model's own method for taking a fight's outcome, and it has existed
   * unused this whole time. It is called here, which is the first caller it has ever had.
   */
  function resumeFromFight() {
    let r = null;
    try {
      const back = sessionStorage.getItem('LB_RETURN');
      if (!back) { resumeDiag = 'no LB_RETURN in sessionStorage'; return false; }
      sessionStorage.removeItem('LB_RETURN');
      r = JSON.parse(back);
    } catch (e) { resumeDiag = `storage/parse failed: ${e.message}`; return false; }
    if (!r || !r.resume) { resumeDiag = 'LB_RETURN carried no resume snapshot'; return false; }

    const w = restore(r.resume, { externalClock: true });
    if (!w) {
      /* ⛔ SURFACED, NOT SWALLOWED. Falling through to a fresh region is the right BEHAVIOUR and the
       * wrong thing to be silent about — a resumed walk and a restarted one look identical on the
       * first frame, so without this the harness can only report "you are on a walk". */
      resumeDiag = `restore refused: ${restore.lastRefusal || 'no reason recorded'}`;
      return false;
    }
    resumeDiag = 'resumed';

    world = w;
    seed = w.seed;
    /* ⛔ THE OUTCOME IS APPLIED THROUGH THE MODEL, not by poking the monster. `resolveEncounter`
     * also pushes the loser off the player so the next tick cannot instantly re-trigger the same
     * ambush — which, on a page that has just navigated back, is the difference between a walk and
     * a loop. Faking `encounter` is how a caller uses that method from outside the tick. */
    const idx = Number.isInteger(r.monsterIndex) ? r.monsterIndex : -1;
    /* ⛔ READ THE CREATURE BEFORE RESOLVING. `resolveEncounter` clears `world.encounter`, so asking
     * afterwards which creature this was returns null and every boss beat is silently skipped. */
    const slain = (idx >= 0 && idx < world.monsters.length) ? (world.monsters[idx].creature || null) : null;
    if (idx >= 0 && idx < world.monsters.length) {
      world.encounter = { monster: world.monsters[idx] };
      world.resolveEncounter({ won: !!r.won, flame: r.flame, oil: r.oil });
    } else {
      /* no monster to resolve (a hand-edited return) — still honour the lantern the fight ended on */
      if (typeof r.flame === 'number') world.flame = Math.max(0, r.flame);
      if (typeof r.oil === 'number') world.oil = Math.max(0, r.oil | 0);
    }

    /* ⭐ THE BEATS A WON FIGHT EARNS. Order matters: `firstWin` is the ordering lesson and must be
     * the one the player reads first if a boss somehow also falls in the same return. `fire()`
     * QUEUES rather than drops, so both are kept either way — see the note on Story.fire. */
    if (r.won) {
      beat('firstWin');
      const B = window.LB_BESTIARY || null;
      const c = slain && B ? B.byId(slain) : null;
      if (c && c.tier === 'boss') beat(`boss:${c.id}`);
    }

    lastT = performance.now();
    return true;
  }

  /**
   * ⭐ ONE PLACE HANDS YOU INTO THE NEXT (2026-09-02, generalised 2026-09-03). Until 09-02 reaching
   * the mouth set `arrived` and the game stopped at a summary card — the goal was labelled MOUTH and
   * there was nothing behind it, which is why six of the ten creatures were unreachable. This was
   * then written as `enterBarrow()`, i.e. the one edge the game had at the time, and the town
   * inherited the same dead end: a place with an arrival card, an authored beat and nowhere to go.
   * ⛔ THE LANTERN AND THE OIL CARRY ACROSS, exactly as they do into a fight. Walking out of
   * Aldermoor on a full lantern is fine — the well is right there — but arriving at the barrow on
   * one would make the moor crossing free, and the whole design claim is that the route decides
   * what the next place inherits.
   * ⚠️ Refuses loudly rather than silently doing nothing: a zone with no `nextZone` should never
   * have offered the player the key in the first place, so reaching here is a wiring bug.
   */
  function enterNext() {
    const to = ZONE(world.zone).nextZone;
    if (!to) throw new Error(`overworld_ui: zone "${world.zone}" has no nextZone — the goal card `
      + 'must not offer SPACE from a place with nowhere to go');
    const flame = world.flame; const oil = world.oil;
    newRegion(seed, to);
    world.flame = flame; world.oil = oil;
    const b = ZONE(to).enterBeat;
    if (b) beat(b);
  }

  /* ⭐ THE ART LOAD. Guarded on every side like the audio below: the moor must be WALKABLE with no
   * art at all, because `overworld_selftest.js` and the headless bots run with no images and the
   * flat-colour fallback is the only reason they can. Art is an enhancement to a working game, never
   * a dependency of one — the same shape as the `artReady` guard in ui.js.
   * ⛔ AND `artReady` FLIPS ONLY WHEN EVERY SHEET LOADED. A half-loaded atlas draws a moor with
   * holes in it and reports success, which is the exact failure `stage.js` guards with its size
   * assertions: a wrong or missing image still draws, so nothing errors and the picture is wrong. */
  if (ART) {
    ART.loadAll().then((r) => {
      artReady = r.ready;
      if (!r.ready) console.warn('[LB] overworld art NOT ready:', r.failed.join(' · '));
      else console.log(`[LB] overworld art ready — ${r.tiles} tiles`);
    }).catch((e) => { artReady = false; console.warn('[LB] overworld art failed:', e && e.message); });
    /* the field sprites: the party LEADER and every creature the bestiary can put on this map.
     * ⭐ ALL THREE of the party are loaded, not just the one who walks the map: the scene panel
     * draws the SPEAKER's bust, and WREN and OREN never appear on the overworld but do most of the
     * talking. Their PNGs were already in the package and were simply never asked for. */
    for (const who of ['sable', 'wren', 'oren']) loadFieldSprite(`p_${who}`, `sprites/party/${who}.png`);
    const rosterArt = (window.LB_BESTIARY ? window.LB_BESTIARY.CREATURES : []).map((c) => c.sprite.art);
    for (const a of [...new Set(rosterArt)]) {
      for (const f of [0, 1, 2]) loadFieldSprite(`e_${a}_${f}`, `sprites/enemy/${a}_${f}.png`);
    }
  }

  /* ⭐ AUDIO, guarded on every side exactly as in ui.js: the smoke harnesses have no Web Audio and
   * a browser keeps the context suspended until a gesture. A silent moor must still be a walkable
   * one — audio is an enhancement, never a dependency. */
  const AU = (typeof window !== 'undefined' && window.LB_AUDIO) ? window.LB_AUDIO : null;
  function au(fn, ...args) { if (AU && AU[fn]) { try { return AU[fn](...args); } catch (e) { /* never break the walk for a sound */ } } return null; }

  window.addEventListener('keydown', (e) => {
    /* the first keypress is the gesture that unlocks audio — see the note in ui.js */
    au('resume');
    au('playMusic', 'mus_moor');
    if (e.code === 'KeyM') { au('toggleMute'); e.preventDefault(); return; }
    /* ⛔ R IS A NEW RUN, SO IT IS ALSO A NEW STORY. Without this the opening scene plays once per
     * browser session and every later run starts in silence on a moor nobody has explained. The
     * `seen` set is a property of a RUN, not of the tab. */
    if (e.code === 'KeyR') {
      if (STORY) { story = new STORY.Story(); saveStory(); }
      /* ⛔ A NEW RUN STARTS WHERE A RUN STARTS — IN ALDERMOOR. Restarting onto the moor would put
       * the player past the only safe screen in the slice and past the `gate` beat, i.e. every
       * run after the first would be a different, worse game than the first one. */
      newRegion(seed + 1, 'town');
      beat('open');
      e.preventDefault(); return;
    }

    /* ⭐⭐ A SCENE OWNS THE KEYBOARD WHILE IT IS UP, AND IT MUST BE FIRST.
     * ⛔ IT SITS ABOVE THE `Space`-AT-THE-MOUTH BRANCH ON PURPOSE. The `breach` beat fires exactly
     * when `world.arrived` becomes true, so the two want the same key at the same moment: below
     * this branch, the first SPACE the player pressed to read the scene would ALSO have walked them
     * into the barrow, and the beat they were reading would have been closed by the zone change
     * they did not ask for. Reading a scene and taking a decision must never be the same press. */
    if (story && story.playing) {
      if (e.code === 'Space' || e.code === 'Enter') { story.advance(); saveStory(); e.preventDefault(); return; }
      if (e.code === 'Escape') { story.close(); saveStory(); e.preventDefault(); return; }
      /* every other key is swallowed: the world is not ticking, so buffering a walk direction here
       * would apply it the instant the panel closed, in a direction chosen several lines ago. */
      e.preventDefault(); return;
    }

    /* SPACE at the mouth goes in. Guarded on `arrived` and on the zone, so it does nothing at any
     * other moment and cannot become a teleport. */
    if (e.code === 'Space' && world && world.arrived && ZONE(world.zone).nextZone) {
      enterNext(); e.preventDefault(); return;
    }
    keys.add(e.code);
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) e.preventDefault();
  });
  window.addEventListener('keyup', (e) => keys.delete(e.code));

  function inputDir() {
    let x = 0; let y = 0;
    if (keys.has('KeyW') || keys.has('ArrowUp')) y -= 1;
    if (keys.has('KeyS') || keys.has('ArrowDown')) y += 1;
    if (keys.has('KeyA') || keys.has('ArrowLeft')) x -= 1;
    if (keys.has('KeyD') || keys.has('ArrowRight')) x += 1;
    return { x, y };
  }

  /* -- the loop ------------------------------------------------------------------------------ */
  function frame(now) {
    if (!world) { requestAnimationFrame(frame); return; }
    /* clamped: an alt-tab of thirty seconds must not silently burn the lantern down while nobody
     * is looking. A pause is not play. */
    const dt = Math.min(now - lastT, 100);
    lastT = now;

    /* ⛔ A SCENE STOPS THE WORLD, AND "THE WORLD" INCLUDES THE LANTERN. `tick` is what burns the
     * flame, so letting it run under a panel would charge the player oil for reading dialogue —
     * and the `dark` beat would then fire mid-scene off a lantern that died while they read. */
    const inScene = !!(story && story.playing);
    if (!inScene && !world.encounter && !world.arrived) world.tick(dt, inputDir());

    /* ⭐ THE WORLD-STATE BEATS, derived every frame rather than pushed from the place that changes
     * the field. `beat()` is idempotent (seen, queued or playing all return null), so asking every
     * frame is cheaper to reason about than finding every site that can set `arrived` — and it
     * cannot miss one, which is how `LB_RETURN` came to be read by a writer that did not exist. */
    if (!world.encounter) {
      /* ⛔ NOT IN A SAFE ZONE. The `dark` beat is the moor's lesson and its lines say so — "I can't
       * see the road" / "Neither can they. Walk quiet and we may pass" — which is a scene about
       * being hunted. Aldermoor spawns nothing, so firing it there tells the player something
       * FALSE about the place they are standing in, and burns the beat (it is `seen` once) before
       * the moment it was written for. Found 2026-09-03 by photographing the town and reading a
       * panel about creatures over a screen that has none. */
      if (world.flame <= 0 && !world.safe) beat('dark');
      if (world.arrived) beat(ZONE(world.zone).arriveBeat);
    }

    /* the same lantern filter the fight uses, driven by the same field — so the moor and the ambush
     * it hands you into sound like one continuous place rather than two screens */
    au('setFlame', world.flame / world.cfg.flameMax);

    draw(now);

    if (world.encounter) { handOffToCombat(); return; }
    requestAnimationFrame(frame);
  }

  /** ⛔ The handoff. This page never draws a fight. */
  function handOffToCombat() {
    try {
      sessionStorage.setItem('LB_CARRY', JSON.stringify({
        flame: world.encounter.flame, oil: world.encounter.oil, seed,
        /* ⭐ WHICH CREATURE CAUGHT YOU (2026-09-02). `gate_a_loop.js` asserts the carry ARRIVES and
         * is read against the values the walk ended with; this field joins that contract, so the
         * fight you get is the monster you walked into rather than a fixed teacher. */
        creature: world.encounter.creature || null,
        /* ⭐⭐ THE WALK ITSELF, so the fight has somewhere to hand you BACK to (2026-09-02). Before
         * this the seam was one way: `LB_RETURN` was read by this file and written by nobody, so the
         * breach, the cairn field, both bosses and the ending were unreachable behind the first
         * ambush. ⛔ It is OPAQUE TO THE COMBAT PAGE — `ui.js` carries the blob and never reads a
         * field of it, so the world's shape keeps exactly one owner (§6d-10) and the combat screen
         * cannot grow a second opinion about what a walk is.
         * ⚠️ `monsterIndex` is the one thing combat must hand back BESIDES its own outcome: which
         * monster this fight was, so a win can mark the right one dead. Taken from the world here,
         * where the encounter is still in hand. */
        resume: world.snapshot(),
        monsterIndex: world.monsters.indexOf(world.encounter.monster),
      }));
      /* declared in `paths.js`: a shipped build renames both halves of this seam */
      window.location.href = (window.LB_PATHS && window.LB_PATHS.pages.combat) || 'index.html';
    } catch (e) {
      /* no sessionStorage (file:// in some browsers): degrade to a message rather than a dead page */
      g.fillStyle = 'rgba(0,0,0,0.8)'; g.fillRect(0, 0, W, H);
      text(`AMBUSHED — flame ${world.encounter.flame.toFixed(0)}, oil ${world.encounter.oil}`,
        W / 2, H / 2, 20, '#e0b060', 'center');
      text('(cannot hand off: sessionStorage unavailable)', W / 2, H / 2 + 26, 12, '#8a8a96', 'center');
    }
  }

  /* -- drawing ------------------------------------------------------------------------------- */
  function text(s, x, y, size = 13, colour = '#ddd', align = 'left') {
    g.fillStyle = colour; g.textAlign = align;
    g.font = `${size}px ui-monospace, Consolas, monospace`;
    g.fillText(s, x, y);
  }

  function draw(now) {
    const w = world;
    const R = w.region;
    /* ⛔ THE CAMERA IS CLAMPED TO THE MAP, AND A WIDE CULL IS WHAT MADE THAT NECESSARY. 2026-09-03.
     * A player-centred camera shows whatever is beyond the region as pure black, and on the moor
     * that was invisible: the tight cull stopped the drawn world well before the map ran out, so
     * the edge of the WORLD and the edge of the LIGHT were never both on screen. Aldermoor draws
     * its whole viewport (it is lit, and small — 48x40 against a 760x520 window), and the player
     * starts two tiles inside the south gate, so the first frame of the game had a HARD HORIZONTAL
     * BLACK BAND across the bottom third with a straight top edge. That is the "blocky octagon of
     * map against pure black" defect this file already records one screen up, arriving from the
     * other direction — darkness with a ruler-straight edge reads as a broken renderer, not as
     * night. ⚠️ Only clamps on an axis where the map is BIGGER than the window; a region narrower
     * than the viewport stays centred, or the clamp would shove it into a corner.
     * ⭐ It is a strict improvement for the other zones too, and it costs them nothing: they are big
     * enough that the clamp only ever engages within half a screen of a border. */
    const clamp = (v, lo, hi) => (hi < lo ? (lo + hi) / 2 : Math.max(lo, Math.min(hi, v)));
    const camX = clamp(w.player.x - W / 2, 0, R.w * TILE - W);
    const camY = clamp(w.player.y - H / 2, 0, R.h * TILE - H);

    g.fillStyle = '#050506'; g.fillRect(0, 0, W, H);

    /* terrain, but only the tiles the light reaches — the lantern IS the information system, so
     * drawing the whole map "because we have it" would delete the mechanic the gates measured. */
    const r = w.lightRadius;
    /* which art table this map is drawn with — the ONLY visual difference between the moor and the
     * cairn field, because both use the same tile enum and the same collision (world_art.js) */
    const artTable = ART && ZONE_ART(w.zone);
    const x0 = Math.max(0, Math.floor((camX - 8) / TILE));
    const x1 = Math.min(R.w - 1, Math.ceil((camX + W + 8) / TILE));
    const y0 = Math.max(0, Math.floor((camY - 8) / TILE));
    const y1 = Math.min(R.h - 1, Math.ceil((camY + H + 8) / TILE));
    for (let ty = y0; ty <= y1; ty++) {
      for (let tx = x0; tx <= x1; tx++) {
        const cx = tx * TILE + TILE / 2; const cy = ty * TILE + TILE / 2;
        const d = Math.hypot(cx - w.player.x, cy - w.player.y);
        /* ⛔ THE CULL RADIUS IS NOT THE LIGHT RADIUS, and the first art capture showed why. Culling
         * at `r + TILE` ends the drawn world on a 32 px STAIRCASE, which photographs as a blocky
         * octagon of map against pure black — it reads as a hole in the world rather than as
         * darkness. With art, terrain is drawn well PAST the light and `light()` (floored at 0 out
         * here) takes it to true black, so the boundary is a gradient and the staircase is buried
         * inside it. ⚠️ This does NOT hand the player a free minimap: the floor is black, so unseen
         * ground is genuinely unseen. Monsters and caches are still culled by `isVisible` — those
         * are the information mechanic; the ground is not. */
        /* ⛔ AND THE CULL, NOT THE LIGHT FLOOR, IS WHAT DECIDES HOW MUCH OF A PLACE EXISTS.
         * MEASURED 2026-09-03: giving the town an ambient floor of 46 moved its mean luma 9.7 -> 16.2
         * and its dark-fraction only 90.1% -> 88.6%, because a floor can only light tiles that were
         * DRAWN, and everything past this radius is never drawn at all. The knob that looked like
         * the answer was working correctly on 12% of the screen. ⇒ a zone that is meant to READ as
         * lit needs both, and they live on one row of the table so they cannot drift apart. */
        if (d > (artReady ? r * ZONE(w.zone).cullMult + TILE : r + TILE)) continue;
        /* falloff, so the edge of the light is a gradient rather than a hard disc.
         * ⚠️ LINEAR, not squared: the squared curve crushed everything past half the radius to
         * near-black, which is what made the world unreadable in the first capture. */
        const a = Math.max(0, Math.min(1, 1 - (d / (r + TILE))));
        const kind = R.tiles[ty * R.w + tx];
        const sx = Math.round(cx - TILE / 2 - camX); const sy = Math.round(cy - TILE / 2 - camY);
        /* ⛔ PER-TILE ALPHA IS FOR THE FALLBACK ONLY, AND THE FIRST ART CAPTURE SHOWED WHY. With
         * flat colours a per-tile alpha step is invisible; with real texture it draws the 32 px GRID
         * as a checkerboard of brightness — every tile a flat plate at its own opacity. Photographed
         * 2026-09-02 and unmistakable. Real art is drawn at FULL alpha and lit afterwards, per
         * pixel, by the same `light()` the combat stage uses. */
        g.globalAlpha = artReady ? 1 : 0.10 + 0.90 * a;
        if (artReady) {
          /* `kindAt` reports a neighbour's kind NAME, or null out of bounds (which counts as same —
           * see autotile.js; the region border is authored ROCK, so the visible edge of the world is
           * a real cliff rather than a coastline drawn around the map). world_art decides what
           * "same" MEANS per material, because tile type and ground material are different questions
           * — in the cairn field a standing stone stands ON the scree floor. */
          const kindAt = (nx, ny) => ((nx < 0 || ny < 0 || nx >= R.w || ny >= R.h)
            ? null
            : KIND_NAME[R.tiles[ny * R.w + nx]]);
          ART.cell(g, KIND_NAME[kind], tx, ty, sx, sy, kindAt, ART.ZOOM, artTable);
          const sp = ZONE(w.zone).scatterProps;
          if (kind === T.GRASS && sp) ART.scatter(g, tx, ty, sx, sy, ART.ZOOM, 11, sp());
          /* ⛔ THE LIT EDGE ON SOLID GROUND SURVIVES THE MOVE TO ART — DELETING IT BROUGHT THE
           * ORIGINAL DEFECT STRAIGHT BACK. The flat-colour renderer added this after a measured
           * failure ("an undifferentiated black blob... a player could not see what they were about
           * to walk into"), and dropping it as "the art will handle it" reproduced the same problem
           * in green instead of black: a rowan's canopy sits at almost exactly the value of lit
           * sward, so a tree photographed as a floating stool and a crag edge disappeared entirely.
           * ⚠️ Art does not automatically carry gameplay legibility. What separates an obstacle here
           * is a light EDGE — the same affordance, drawn over the texture instead of instead of it,
           * and warm because the lantern is the only thing lighting it. */
          if (BLOCKED.has(kind)) {
            const lit = Math.max(0, Math.min(1, 1 - (d / (r + TILE))));
            if (lit > 0.02) {
              g.save();
              g.globalAlpha = lit * 0.5;
              g.fillStyle = kind === T.WATER ? '#7aa8c8' : '#c8b48a';
              g.fillRect(sx, sy, TILE, 2);
              g.restore();
            }
          }
        } else {
          g.fillStyle = TERRAIN[kind] || '#202020';
          g.fillRect(sx, sy, TILE, TILE);
          /* a lit top edge on anything solid, so walls read as SOLID rather than as absence */
          if (WALL_EDGE[kind]) {
            g.globalAlpha = (0.10 + 0.90 * a) * 0.55;
            g.fillStyle = WALL_EDGE[kind];
            g.fillRect(sx, sy, TILE, 3);
          }
        }
      }
    }
    g.globalAlpha = 1;

    /* ⛔ THE LANTERN IS APPLIED AFTER THE FIGURES, NOT HERE — see the note above the ST.light call
     * below. Lighting the ground and then drawing an unlit monster on top of it puts a fully bright
     * creature in the pitch dark, which deletes the stealth mechanic from the picture. */
    const warmFallback = () => {
      const grad = g.createRadialGradient(W / 2, H / 2, 8, W / 2, H / 2, r);
      const warm = w.flameState === 'OUT' ? 'rgba(120,120,150,0.05)' : 'rgba(255,206,140,0.13)';
      grad.addColorStop(0, warm); grad.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = grad; g.fillRect(0, 0, W, H);
    };

    /* oil caches — only if lit.
     * ⭐ IN THE TOWN THE CACHE IS THE WELL, drawn from the pack (see world_art TOWN_LANDMARKS). The
     * flat rectangle below stays as the fallback for the moor, for the no-art harnesses, and for the
     * case where the tile fails to resolve — `blit()` returns false rather than throwing, so without
     * a fallback an unresolved landmark is simply an invisible one. */
    /* ⛔ TAKES THE KEY, NOT THE ID, AND THAT IS THE WHOLE POINT. Written as `landmark(id, …)` the
     * caller has to evaluate `ART.TOWN_LANDMARKS.goal` to build the argument, which THROWS in every
     * harness that runs with no art — `ART` is null there, and the guard inside this function never
     * gets the chance to run. The no-art path is not an edge case in this project: it is what
     * `overworld_selftest`, the balance bots and `story_gates` 3b all run on, and this wing's own
     * doctrine is that art is an enhancement to a working game, never a dependency of one. Passing
     * the KEY keeps every art reference on the guarded side of the check. Crashed 31 assertions into
     * story_gates on 2026-09-03, the run after it was written. */
    const landmark = (key, sx, sy) => {
      if (!artReady || !ART || !ART.TOWN_LANDMARKS) return false;
      const id = ART.TOWN_LANDMARKS[key];
      if (!id) return false;
      return ART.blit(g, id, sx - (ART.CELL * ART.ZOOM) / 2, sy - (ART.CELL * ART.ZOOM) / 2);
    };
    for (const c of w.caches) {
      if (c.taken || !w.isVisible(c)) continue;
      const sx = c.x - camX; const sy = c.y - camY;
      if (w.zone === 'town' && landmark('cache', sx, sy)) continue;
      g.fillStyle = '#e0b060'; g.fillRect(sx - 5, sy - 7, 10, 14);
      g.strokeStyle = '#6a4a20'; g.lineWidth = 1; g.strokeRect(sx - 5, sy - 7, 10, 14);
    }

    /* ⛔ THE MOUTH MARKER IS A MOOR THING ONLY. In the barrow the goal IS the stone ring, which is
     * drawn out of real tiles and standing stones — painting a black "MOUTH" box in the middle of it
     * put an untextured rectangle over the one authored landmark in the game (photographed
     * 2026-09-02, `barrow_heart_bright.png`). A marker for a place that is already visible is not a
     * marker, it is an occlusion. */
    if (ZONE(w.zone).showGoalMarker && w.isVisible(w.goal)) {
      const sx = w.goal.x - camX; const sy = w.goal.y - camY;
      /* ⭐ THE TOWN'S GOAL IS A FIVE-BAR GATE IN THE HEDGE, not a black box with a word on it. The
       * label still prints above it, because the gate is the OBJECTIVE and a landmark the player
       * cannot name is a landmark they walk past. Moor keeps the box: its goal is a break in a wall
       * the pack has no tile for, and the box is legible there against open heath. */
      if (!(w.zone === 'town' && landmark('goal', sx, sy))) {
        g.fillStyle = '#0b0b0e'; g.fillRect(sx - 13, sy - 15, 26, 30);
        g.strokeStyle = '#7a6a4a'; g.lineWidth = 2; g.strokeRect(sx - 13, sy - 15, 26, 30);
      }
      text(ZONE(w.zone).goalLabel, sx, sy - 20, 10, '#9a8a6a', 'center');
    }

    /* monsters — ONLY the ones inside the light. This is the mechanic, not an optimisation.
     * ⭐ Each one now draws its OWN creature, from the sprite the bestiary names, and its walk
     * cycle runs while it moves — so what is coming out of the dark is legible before it reaches
     * you, and a chase is a picture rather than a red square. */
    for (const m of w.monsters) {
      if (m.defeated || !w.isVisible(m)) continue;
      const sx = Math.round(m.x - camX); const sy = Math.round(m.y - camY);
      const art = m.art && field[`e_${m.art}_0`] ? m.art : null;
      if (art) {
        /* the 3-frame Mourncrest walk, swayed slowly when idle and stepped when chasing */
        const fr = m.state === 'chase'
          ? Math.floor(now / 130) % 3
          : Math.floor(now / 520) % 3;
        const im = field[`e_${art}_${fr}`] || field[`e_${art}_0`];
        /* a contact shadow, or a figure floats on the turf (stage.js pays the same cost) */
        g.save();
        g.globalAlpha = g.globalAlpha * 0.45;
        g.fillStyle = '#000';
        g.beginPath(); g.ellipse(sx, sy + 2, 13, 5, 0, 0, Math.PI * 2); g.fill();
        g.restore();
        if (m.state === 'chase') {
          /* the tell that it has SEEN you, kept from the box version because it is load-bearing:
           * the stealth window is the whole point and the player must be able to read it */
          g.save();
          g.shadowColor = '#c04040'; g.shadowBlur = 14;
          g.drawImage(im, sx - SPRITE_PX / 2, sy - SPRITE_PX + 6);
          g.restore();
        } else {
          g.drawImage(im, sx - SPRITE_PX / 2, sy - SPRITE_PX + 6);
        }
      } else {
        g.fillStyle = m.state === 'chase' ? '#a8484c' : '#4a4450';
        g.fillRect(sx - 9, sy - 9, 18, 18);
        g.strokeStyle = m.state === 'chase' ? '#e08a8a' : '#6a6476';
        g.lineWidth = 2; g.strokeRect(sx - 9, sy - 9, 18, 18);
      }
    }

    /* the party — the LEADER on the field, which is the SNES convention and the reason the field
     * sprite is 1x while the battle sprite is 2x (world_art.js header). */
    if (field.p_sable) {
      g.save();
      g.globalAlpha = 0.45; g.fillStyle = '#000';
      g.beginPath(); g.ellipse(W / 2, H / 2 + 2, 12, 5, 0, 0, Math.PI * 2); g.fill();
      g.restore();
      g.drawImage(field.p_sable, W / 2 - SPRITE_PX / 2, H / 2 - SPRITE_PX + 6);
    } else {
      g.fillStyle = '#d8d2c4'; g.fillRect(W / 2 - 7, H / 2 - 9, 14, 18);
      g.strokeStyle = '#f0e8d8'; g.lineWidth = 1; g.strokeRect(W / 2 - 7, H / 2 - 9, 14, 18);
    }

    /* ⭐ THE LANTERN, OVER EVERYTHING, FROM THE COMBAT STAGE'S OWN FUNCTION (2026-09-02).
     * ⛔ NOT A SECOND COPY OF THE LIGHTING. `stage.js`'s `light()` carries the night grade and the
     * radial floor as a TUNED PAIR (wing §0z: changing one without the other moves a frame that was
     * already right), and it was measured this session at falloff 0.215 / warmth +14.1. Writing the
     * overworld its own version would be the shared-fact defect (§6d-10) applied to the single most
     * visible thing in the game, and the two would drift the first time either was tuned.
     * ⛔ AFTER the figures, because that is what makes darkness mean anything: a monster outside the
     * pool is DARK, not merely undrawn. */
    /* ⛔ THE FULL CANVAS HEIGHT, NOT `H - HUD_H`. Lighting only down to the HUD left the strip of
     * terrain BEHIND the HUD unlit, and the HUD bar is `rgba(6,6,8,0.82)` — translucent — so a band
     * of full-brightness daylit moor showed through it along the bottom of the screen. Photographed
     * 2026-09-02. The HUD is drawn after this, so darkening under it costs nothing. */
    if (artReady && ST && ST.light) ST.light(g, W, H, W / 2, H / 2, r, ZONE(w.zone).lightFloor);
    else warmFallback();

    /* ---- HUD -------------------------------------------------------------------------------- */
    g.fillStyle = 'rgba(6,6,8,0.82)'; g.fillRect(0, H - HUD_H, W, HUD_H);
    const dark = w.flameState === 'OUT';
    text(`LANTERN  ${w.flameState}`, 16, H - 32, 11, dark ? '#c06a6a' : '#8a8a96');
    g.fillStyle = '#25252b'; g.fillRect(16, H - 26, 220, 12);
    const f = w.flame / w.cfg.flameMax;
    g.fillStyle = f > 0.55 ? '#e0b060' : f > 0 ? '#a06a34' : '#3a2a1a';
    g.fillRect(16, H - 26, 220 * f, 12);
    text(`OIL ${'*'.repeat(w.oil) || '(none)'}`, 252, H - 16, 12, w.oil ? '#e0b060' : '#6a5a3a');
    text(`${(w.timeMs / 1000).toFixed(0)}s`, 252, H - 32, 11, '#6a6a76');

    if (dark) {
      /* ⛔ "THEM" IS A LIE IN A SAFE ZONE, and it is the same defect as the `dark` BEAT firing in
       * Aldermoor — both were written when every place in the game was hostile. In a town with no
       * creatures the line promises a stealth trade the player is not making, and the honest line
       * is the one that matters there: you are about to walk out of here on an empty lantern.
       * Found 2026-09-03 by photographing the town's flame-OUT frame and READING the HUD in it. */
      text(w.safe
        ? 'THE LANTERN IS OUT — fill it at the well before you take the road'
        : 'THE LANTERN IS OUT — you cannot see them, and they cannot see you',
      W - 16, H - 32, 12, '#c06a6a', 'right');
    } else {
      const open = w.caches.filter((c) => !c.taken).length;
      text(`${open} oil cache${open === 1 ? '' : 's'} left in the region`, W - 16, H - 32, 12, '#7a7a88', 'right');
    }
    text('WASD / arrows to walk   ·   R for a new region', W - 16, H - 14, 11, '#5a5a66', 'right');

    if (w.arrived && !(story && story.playing)) {
      g.fillStyle = 'rgba(0,0,0,0.74)'; g.fillRect(0, 0, W, H);
      if (w.zone === 'barrow') {
        /* the end of the slice — reaching the stone ring, having got past what stands in it */
        text('THE STONE RING', W / 2, H / 2 - 8, 26, '#e0b060', 'center');
        text(`${(w.timeMs / 1000).toFixed(1)}s in the cairn field  ·  lantern ${w.flame.toFixed(0)}`
          + `  ·  ${w.stats.encounters} fight(s)`, W / 2, H / 2 + 18, 12, '#aaa', 'center');
        text('R — begin again on the moor', W / 2, H / 2 + 44, 12, '#8a8a96', 'center');
      } else if (w.zone === 'town') {
        /* ⛔ THE TOWN'S ARRIVAL IS A DEPARTURE. Reaching the north gate means leaving the only safe
         * ground in the slice, so the card names the cost rather than congratulating the player —
         * a full lantern and no walls, which is the trade the whole moor is built on. */
        /* ⛔ THE PROMPT SAID `R` AND `R` IS A RESTART. 2026-09-03: this card read "R — walk out onto
         * the moor" directly under a line showing the lantern and oil you are carrying, i.e. it
         * promised the crossing would inherit them, while `R` wipes the story, re-seeds the region
         * and hands back a full lantern. The departure is the same decision the breach is, so it
         * takes the same key and the same grammar: SPACE carries what you have. */
        text('THE NORTH GATE', W / 2, H / 2 - 8, 26, '#e0b060', 'center');
        text(`${(w.timeMs / 1000).toFixed(1)}s in Aldermoor  ·  lantern ${w.flame.toFixed(0)}  ·  oil ${w.oil}`,
          W / 2, H / 2 + 18, 12, '#aaa', 'center');
        text('past the hedge the light is all you have', W / 2, H / 2 + 40, 12, '#8a8a96', 'center');
        text('SPACE — walk out onto the moor, on the lantern you filled', W / 2, H / 2 + 64, 13, '#e0b060', 'center');
      } else {
        text('THE BREACH IN THE WALL', W / 2, H / 2 - 8, 26, '#e0b060', 'center');
        text(`${(w.timeMs / 1000).toFixed(1)}s on the moor  ·  lantern ${w.flame.toFixed(0)}  ·  oil ${w.oil}`
          + `  ·  ${w.stats.encounters} fight(s)  ·  ${w.stats.cachesTaken} cache(s)`,
        W / 2, H / 2 + 18, 12, '#aaa', 'center');
        /* ⛔ SPACE, not an automatic transition: walking into the next PLACE on the lantern you have
         * left is a decision, and taking it away would delete the one the whole crossing sets up. */
        text('SPACE — go in, on the lantern you have left', W / 2, H / 2 + 44, 13, '#e0b060', 'center');
      }
    }

    drawScene();
  }

  /* ================================================================================================
   * ⭐ THE SCENE PANEL — where the authored beats are actually seen. 2026-09-02.
   * ================================================================================================
   * ⛔ EVERY NUMBER BELOW IS PUBLISHED ON `LBW_SCENE` AND THE GATE READS IT FROM THERE. Master §2b:
   * the layout gate that certified "no text collides" over a real collision did so because the
   * geometry lived in one file and the assertion in another. A panel whose box the checker has to
   * guess at is a checker asserting its own arithmetic.
   *
   * ⛔ IT DRAWS LAST, OVER EVERYTHING, AND IT DIMS WHAT IS UNDER IT. Drawn under the HUD the speaker
   * plate lands on the oil counter; drawn without the scrim the moor's own light shows through the
   * body text at exactly the flame levels the scene is most likely to fire at.
   * ---------------------------------------------------------------------------------------------- */
  /* ⛔ THE FIRST BUILD PUT THIS AT `y: H - 168` AND ITS BOTTOM EDGE CUT THE HUD IN HALF. Found by
   * photographing the opening scene and looking at it (wing §0z) — the lantern bar, "OIL (none)"
   * and "WASD / arrows to walk" were sliced along their middles by the panel's lower border, which
   * reads as a broken window rather than a text box. Nothing else could have caught it: every
   * string was inside the canvas, none overlapped another string, and the panel drew exactly where
   * it was told to. ✅ The panel is now derived from HUD_H so it sits ABOVE the strip with a gap,
   * and `story_gates.js` section 5 asserts nothing but the scene's own text is inside this box. */
  const SCENE = {
    x: 24,
    w: W - 48,
    h: 144,
    gap: 8,                    // clear air between the panel and the HUD strip
    pad: 22,
    nameSize: 13,
    bodySize: 15,
    hintSize: 11,
  };
  SCENE.y = H - HUD_H - SCENE.gap - SCENE.h;
  SCENE.hudTop = H - HUD_H;    // published so the gate reads the strip, never restates it

  /* ⭐ THE SPEAKER PORTRAIT. The party art is first-party and already in the package
   * (`Product_Release/assets/sprites/party/*.png`, 64x64 — MEASURED off the PNG headers, not
   * assumed). ⛔ INTEGER ZOOM ONLY: the coherence spike's finding is that one art pixel must be the
   * same size everywhere, and 64 -> 128 is the 2x the world layer already renders at. A 1.5x
   * portrait would be the "pasted in from another game" read that spike exists to prevent. */
  SCENE.portrait = 128;
  SCENE.portraitX = SCENE.x + SCENE.pad;
  SCENE.portraitY = SCENE.y + (SCENE.h - SCENE.portrait) / 2;
  SCENE.textX = SCENE.portraitX + SCENE.portrait + 18;
  SCENE.textW = (SCENE.x + SCENE.w - SCENE.pad) - SCENE.textX;
  SCENE.rowH = 21;

  function drawScene() {
    if (!story || !story.playing) return;
    const a = story.active;
    if (!a) return;

    /* the whole frame dims, not just behind the box — a cutscene is a change of attention */
    g.fillStyle = 'rgba(4,4,6,0.62)'; g.fillRect(0, 0, W, H);

    g.fillStyle = 'rgba(10,10,14,0.94)';
    g.fillRect(SCENE.x, SCENE.y, SCENE.w, SCENE.h);
    /* a warm rule along the top edge: the lantern is the only real colour in this game's palette */
    g.fillStyle = '#e0b060';
    g.fillRect(SCENE.x, SCENE.y, SCENE.w, 2);
    g.fillStyle = 'rgba(224,176,96,0.22)';
    g.fillRect(SCENE.x, SCENE.y + SCENE.h - 1, SCENE.w, 1);

    /* ⭐ THE PORTRAIT. Absent art is not a failure: the panel simply carries no bust, exactly as the
     * moor draws flat colours when the atlas 404s. A scene that will not render without a PNG is a
     * dependency, not an enhancement (the same guard shape as `artReady` above). */
    const bust = a.who ? field[`p_${a.who.toLowerCase()}`] : null;
    if (bust) {
      /* a plate behind it so a dark sprite still reads against the dark panel */
      g.fillStyle = 'rgba(28,26,32,0.9)';
      g.fillRect(SCENE.portraitX - 4, SCENE.portraitY - 4, SCENE.portrait + 8, SCENE.portrait + 8);
      g.imageSmoothingEnabled = false;               // pixel art, at an integer zoom
      g.drawImage(bust, SCENE.portraitX, SCENE.portraitY, SCENE.portrait, SCENE.portrait);
    }

    let ty = SCENE.y + SCENE.pad + SCENE.nameSize;
    if (a.who) text(a.who, SCENE.textX, ty, SCENE.nameSize, '#e0b060', 'left');
    /* ⛔ THE BODY STARTS AT A FIXED OFFSET WHETHER OR NOT THERE IS A PLATE. Letting narration begin
     * where the name would sit makes the text jump up and down the panel every time the speaker
     * comes and goes, which reads as the box twitching rather than as a change of voice. */
    ty += 30;
    /* wrapped with story.js's OWN wrap at story.js's OWN budget, so what the gate measures is what
     * the player reads — never a second wrapper here (wing §6d-10) */
    for (const row of STORY.wrap(a.text)) {
      text(row, SCENE.textX, ty, SCENE.bodySize, a.who ? '#dcdce4' : '#a8a8b8', 'left');
      ty += SCENE.rowH;
    }

    /* the advance hint, and the place, on the bottom row — right and left so they cannot meet */
    text(a.place, SCENE.textX, SCENE.y + SCENE.h - 14, SCENE.hintSize, '#5a5a66', 'left');
    text(`${a.index + 1}/${a.total}   SPACE`, SCENE.x + SCENE.w - SCENE.pad,
      SCENE.y + SCENE.h - 14, SCENE.hintSize, '#8a8a96', 'right');
  }

  /* read-only, for story_gates.js — the panel's own geometry, never a second copy of it */
  window.LBW_SCENE = SCENE;

  /* ⛔ READ-ONLY TEST SEAM (same contract as ui.js): observation only, sets nothing, and the game
   * never reads it, so it cannot become a second code path. Keys remain the only input. */
  window.LBW_UI = {
    get world() { return world; },
    get resumeDiag() { return resumeDiag; },
    get keys() { return keys; },
    /* the live playhead, for gate_a_loop and story_gates. Observation only, like every other member
     * of this seam: the game reads none of it, so it cannot become a second code path. */
    get story() { return story; },
    press(code) { keys.add(code); },
    release(code) { keys.delete(code); },
    newRegion,
  };

  /* ⛔ A RETURN FROM A FIGHT COMES FIRST. Booting straight into newRegion(1) would throw away a
   * pending LB_RETURN and drop the player at the start of the moor with everything respawned — the
   * exact failure the old inline restore would have produced. A refused or absent return falls
   * through to a fresh walk, which is the only other correct outcome. */
  /* ⛔ `open` FIRES ONLY ON A FRESH WALK, NOT ON A RESUME. Returning from a fight is not the start
   * of a story, and playing the opening scene there would also throw away the flame the player just
   * fought on by stopping the world at the worst possible moment. */
  if (!resumeFromFight()) { newRegion(1, 'town'); beat('open'); }
  requestAnimationFrame(frame);
}());
