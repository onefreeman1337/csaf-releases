'use strict';
/* ================================================================================================
 * bestiary.js — THE TEN CREATURES OF THE SLICE. Eight enemies and two bosses.
 * ================================================================================================
 *
 * ⛔ THE FAILURE THIS FILE EXISTS TO AVOID, NAMED FIRST.
 *
 * DESIGN §5 owes the slice "eight enemy types and two bosses". The model as it stood could vary an
 * enemy's HEALTH, its DAMAGE and whether it hardens — and nothing else. Ten creatures built on that
 * are ONE creature with ten health bars, and the player meets the same fight ten times at increasing
 * length. That is exactly the drift the operator named on 2026-08-31 (wing §0a-2, *"all the games
 * lately are like control a console and hit go"*), arriving INSIDE one game instead of across a
 * shelf, and it is the single most likely way this flagship ends up boring.
 *
 * ⭐ SO EVERY CREATURE HERE IS A DIFFERENT *DECISION*, AND THE AXIS IS NAMED IN ITS OWN RECORD.
 * The hooks are in `combat.js` under "THE BESTIARY HOOKS"; all of them default to the pre-bestiary
 * behaviour, so no measurement taken before 2026-09-02 has moved (verified: selftest 56/56,
 * encounter_gates 30/30, both exit 0 after the widening).
 *
 * ⛔ AND "DIFFERENT" IS PROVEN, NOT ASSERTED. `bestiary_gates.js` runs a PAIRWISE DISTINCTNESS
 * SWEEP over all 45 creature pairs: for each pair it plays the same policies at the same seeds
 * against both and asks whether the OUTCOME PROFILE separates them. Wing §6d-16 is the precedent
 * and the reason — *"an eye finds the pair it happens to land on; a sweep finds the pair that is
 * actually worst"* — and there it was silhouettes, here it is fights. Two creatures a bot cannot
 * tell apart are one creature with two names, whatever their stat lines say.
 *
 * ------------------------------------------------------------------------------------------------
 * THE AXES, AND WHY EACH ONE IS A DECISION RATHER THAN A NUMBER
 * ------------------------------------------------------------------------------------------------
 * The party's colour sources are DELIBERATELY UNEVEN (combat.js ROSTER):
 *      EMBER    Sable.strike (15)  ·  Wren.emberdart (10)     <- 2 sources
 *      PALE     Sable.palecut (11) ·  Oren.hush (8, heals 9)  <- 2 sources
 *      AZURE    Wren.chill (13)                               <- 1 source
 *      VERDANT  Oren.bramble (12)                             <- 1 source
 * Each character acts once per round. So the POOL a creature draws its telegraph from decides WHICH
 * CHARACTERS ARE CONSCRIPTED and which are free, and that is the texture of the fight:
 *
 *   pool {AZURE, VERDANT}  — one source each. Wren and Oren are spoken for EVERY round; Sable is
 *                            always free to hit. A fight with no choices and full damage.
 *   pool {EMBER, PALE}     — two sources each. Almost any pair of characters can serve, so the
 *                            player chooses WHO, and the choice is a damage-vs-healing decision
 *                            (Oren.hush heals; Sable.palecut does not).
 *   full pool              — the general case, and the only one where all four colours matter.
 *
 *   LENGTH 2 constrains two characters and leaves one free.
 *   LENGTH 3 constrains all three and leaves nothing — and ⛔ MEASURED 2026-09-02
 *   (`_carryover_probe.js`): a len-3 lock is unbreakable in one round by a two-actor party in
 *   15 of 15 (lock, dead-member) pairs tested, and carry-over rescues it over two rounds in only
 *   5 of 15 — and then only if the SAME lock stands both rounds. ⇒ length 3 is safe on a creature
 *   that repeats its telegraph or cannot kill, and is an unwinnable state on a killer that
 *   re-rolls. That is why the len-3 creatures below are the two teachers and the ooze.
 *
 * ------------------------------------------------------------------------------------------------
 * THE ART — first-party, licence-clean, and it is NOT the constraint
 * ------------------------------------------------------------------------------------------------
 * MEASURED 2026-09-02 from the sprites wing's own published trees: 22 distinct creature sprites
 * across four packs — Mourncrest01_RestlessDead (boneHound, ghoul, gravebound, skeleton, wight,
 * wraith), Mourncrest02_PaleChoir (acolyte, censer-bearer, cultist, hierophant, thrall),
 * Mourncrest03_BarrowBeasts (barrowWyrm, carrionCrow, direBat, ossuaryOoze, tombSpider),
 * Mourncrest04_IronWardens (inquisitor, knight, templar). Every creature below names a real one.
 * ⛔ COPY into this project's tree; never write `Wings/Sprites` (master §11, wing §0-ART rule 3).
 * ⚠️ SOUTH frames only — the known wildmark facing defects are on east/west and south is the seed
 * frame, correct by construction (`_next_action.txt`, 2026-09-01).
 */

/* ⛔ WRAPPED IN AN IIFE, AND THE SMOKE TEST IS WHY — the same refusal `encounters.js` carries at its
 * head, earned again on 2026-09-02 within minutes of this file existing. Plain <script> tags share
 * ONE global scope, so this file's top-level `const COLOURS` (destructured from combat.js, so it
 * cannot even be blamed on carelessness) collided with the identically-named one in `combat.js` and
 * the WHOLE FILE aborted with "Identifier 'COLOURS' has already been declared" — a fatal error whose
 * only symptom in a browser is a blank canvas.
 * ⭐ Wing §6b-5 rule 2 prescribes the class fix rather than renaming the identifier, and it is right
 * for a reason this incident demonstrates: the colliding name was one I did not choose and would
 * never have thought to rename. `ui_smoke.js` caught it before a browser ever loaded the page. */
(function () {
const LB = (typeof require === 'function') ? require('./combat') : (typeof window !== 'undefined' ? window.LB : null);
if (!LB) throw new Error('bestiary.js needs combat.js loaded first — it owns the colour set');
const { COLOURS } = LB;

const E = 'EMBER'; const A = 'AZURE'; const V = 'VERDANT'; const P = 'PALE';

/* ------------------------------------------------------------------------------------------------
 * THE CREATURES
 *
 * `axis`         — the ONE thing this creature is for. If two creatures share an axis they are the
 *                  same creature; the distinctness sweep is what actually enforces that.
 * `cfg`          — overrides onto combat.js DEFAULTS. Anything absent is the default.
 * `sprite`       — pack + creature key, so the art wiring is a lookup and never a guess.
 * `teaches`      — what a player should be able to SAY after beating it. A creature whose lesson
 *                  cannot be written in one sentence is a stat block.
 * `firstSeen`    — where in the slice it appears. The order IS the difficulty curve.
 *
 * ⛔⛔ EVERY `enemyHp` / `enemyDamage` BELOW WAS RE-DERIVED 2026-09-02 BECAUSE TEACHING THE PLANNER
 * TO HEAL SILENTLY INVALIDATED THE WHOLE TABLE, AND NOTHING IN THE TREE COULD SEE IT.
 *
 * `models.js healUrgency` (2026-09-02) gave the planner Oren's Hush as a party heal: ~4 casts x 9 hp
 * = ~36 hp of sustain against a party pool of 133, a 27% swing. Every number in this file had been
 * read off `_bestiary_sweep.js` against a planner that COULD NOT do that. MEASURED consequence, one
 * `bestiary_gates.js` run at 60 seeds/creature:
 *     censer 100% · ossuary 100% · barrowwyrm 100% · hierophant 98% · direbat 88% · gravebound 85%
 * against the window `_bestiary_sweep.js` pre-registers in its own header, *"PLANNER 45-80% — a
 * fight a competent player usually wins, and can lose."* SIX of eight non-teachers were above it,
 * INCLUDING BOTH BOSSES — a boss an optimal planner never loses is not a boss.
 *
 * ⛔ AND THE GATE REPORTED **54/54 CLAIMS PROVEN** THE WHOLE TIME, because `winnable` only ever
 * asked whether the number was BIG ENOUGH: a floor of 25% and no ceiling at all. The missing half of
 * the window is now `<creature>/losable` and it goes red on exactly those six while passing
 * tombspider (48%) and ironknight (75%), so it is not a blanket red. ⭐ The reusable shape is master
 * §2b's "a check that only runs on the failing side of another check covers half a field", arriving
 * in a balance table: **a bound stated in a comment is not a bound, and a one-sided gate cannot tell
 * you that your game got easier.**
 *
 * ✅ THE NEW NUMBERS ARE READ OFF A SWEEP, NOT TYPED. `_bestiary_sweep.js` (grids re-centred the same
 * day — two of them did not even CONTAIN the creature they swept) proposes cells at 24 seeds;
 * `_cell_verify.js` (self-test 5/5) then re-measures each CANDIDATE at 60 — the count the gate
 * itself judges at — before anything is written here, because the surface is a CLIFF in the damage
 * dimension (censer reads 100 -> 83 -> 33 -> 29 across four adjacent damage values) and a cell picked
 * at 24 seeds can land anywhere at 60. Writing the sweep's suggestion straight in and then running
 * the gate would be verifying against the field you just wrote (master §2b).
 *
 * ⚠️ AND THE HONEST ERROR BAR, STATED AGAINST INTEREST. The gate is DETERMINISTIC — always seeds
 * 1..60 — so it cannot flap between runs. But 60 seeds estimates a true win rate to about ±12 points
 * at 95% (binomial SE ~6.2pt at p=0.7), against a window only 35 points wide. So these cells are
 * aimed at the MIDDLE (63-72%) rather than at the edges, and no creature here should be quoted as
 * "a 70% fight" without saying n=60. Every figure below is the 60-seed reading.
 * ---------------------------------------------------------------------------------------------- */
const CREATURES = [

  /* ============================================================================================ */
  {
    id: 'bonehound',
    name: 'BONE HOUND',
    sprite: { pack: 'Mourncrest01_RestlessDead', key: 'boneHound', art: 'bonehound' },
    drawScale: 1.00,
    tier: 'teacher',
    firstSeen: 'the waymark cairn, on the moor road',
    /* ⛔ `zone` IS DATA, NOT PROSE. Placement used to be inferrable only from the sentence above,
     * and a placement engine that parses English is a placement engine that silently drops a
     * creature the day someone rewrites a description. Added 2026-09-02 with the barrow site. */
    zone: 'moor',
    axis: 'ORDER — the lock is read at the END of the round, off the top of the stack.',
    teaches: 'Whoever acts last writes the top. A right colour at the wrong moment is a wrong colour.',
    /* ⛔ AUTHORED, NOT GENERATED, and `encounters.js` owns the full reasoning. It is listed here so
     * the bestiary is the ONE place the slice's creatures are enumerated — a roster split across two
     * files is how a creature gets shipped ungated (wing §6d-13's "collect first, emit last"). */
    encounterId: 'first-hound',
    cfg: {
      enemyHp: 120, enemyDamage: 12, enemyHardens: false,
      startFlame: 100, flameBurnMsToEmpty: 90000, oilCharges: 1,
    },
    lock: [V, A],
    whyItDiffers: 'Both its colours have exactly ONE source, so the breaking line is nearly forced '
      + 'and the only remaining freedom is the order. That is the point: the first failure is one '
      + 'swap away from the win, so the lesson is legible from the result screen.',
  },

  /* ============================================================================================ */
  {
    id: 'mirewight',
    name: 'MIRE-WIGHT',
    sprite: { pack: 'Mourncrest01_RestlessDead', key: 'wight', art: 'wight' },
    drawScale: 1.00,
    tier: 'teacher',
    firstSeen: 'the sunk causeway below the cairn',
    zone: 'moor',
    axis: 'SCARCITY — two characters can push the same colour, and the obvious one strands the rest.',
    teaches: 'Ask who ELSE can push this, before you spend the character who can push nothing else.',
    encounterId: 'mire-wight',
    cfg: {
      enemyHp: 150, enemyDamage: 14, enemyHardens: false,
      startFlame: 100, flameBurnMsToEmpty: 90000, oilCharges: 1,
    },
    lock: [E, V, P],
    whyItDiffers: 'Length 3 conscripts the WHOLE party, so there is exactly one breaking line and '
      + 'reaching for Sable.strike (the best EMBER) strands PALE with nobody left to push it. '
      + '⛔ Its damage is small BY REQUIREMENT, not by taste: a len-3 lock becomes unbreakable the '
      + 'moment anyone dies (wing §6b-8), so this creature must be unable to kill.',
  },

  /* ============================================================================================ */
  {
    id: 'gravebound',
    /* ⛔⛔ THE SPRITE WAS `gravebound` AND IT WAS SWAPPED AFTER LOOKING AT THE CONTACT SHEET.
     * `_bestiary_sheet.js` rendered all ten on the stage's own sward colour and the gravebound was
     * the clear weakest of the set: a muddy brown MOUND with a skeleton in it, no readable
     * silhouette, reading as a pile of dirt rather than a creature — and it is the FIRST non-teacher
     * fight in the slice, i.e. the first real monster the player ever meets.
     * ⭐ `_alternates_sheet.js` then rendered the NINE first-party creatures the bestiary had not
     * taken, and the ghoul is both a stronger silhouette (hunched, limbed, unmistakably alive) and a
     * better fit for THIS axis: this creature is the one that LEARNS, and a hunched watching thing
     * reads as adaptive where a static mound cannot. Cost: one line, because `bestiary.js` owns the
     * roster and `stage.js` derives from it (the swap would have been a three-file edit yesterday).
     * ⚠️ THE NAME MOVED WITH THE PICTURE, deliberately. A creature called GRAVEBOUND drawn as a
     * ghoul is the §6d-14 shape — every artefact agreeing on a label that does not match what is on
     * screen — so it is MOOR GHOUL. The `id` stays `gravebound` because ids are slugs and churning
     * one costs every record that references it for no gain. */
    name: 'MOOR GHOUL',
    sprite: { pack: 'Mourncrest01_RestlessDead', key: 'ghoul', art: 'ghoul' },
    drawScale: 1.00,
    tier: 'common',
    firstSeen: 'the open moor, after the causeway',
    zone: 'moor',
    axis: 'ADAPTATION — it hardens against whatever you left on top last round.',
    teaches: 'The best line this round depends on the line you played last round.',
    cfg: {
      /* hp 240 -> 300, damage UNCHANGED. 85% -> 72% (60 seeds, blind control 0%, margin +72pt).
       * One dimension moved on purpose: this creature's identity is ADAPTATION, and its damage is
       * what makes a hardened round hurt, so the health bar is the honest place to take the
       * planner's new sustain back out. 280/46 also lands in window at 75% and was rejected as
       * nearer the ceiling than the middle. */
      enemyHp: 300, enemyDamage: 46, enemyHardens: true, hardenCount: 1,
      lockShape: { pool: COLOURS, lenMin: 2, lenMax: 2 },
    },
    whyItDiffers: 'The reference fight, and the only one whose optimal play is a FUNCTION OF HISTORY '
      + 'rather than of the current telegraph. Its lock is length 2 over the full pool, so the puzzle '
      + 'itself is the easiest in the bestiary and the difficulty is entirely in the adaptation.',
  },

  /* ============================================================================================ */
  {
    id: 'direbat',
    name: 'FEN BAT',
    sprite: { pack: 'Mourncrest03_BarrowBeasts', key: 'direBat', art: 'direbat' },
    drawScale: 0.85,
    tier: 'common',
    firstSeen: 'the crag path, wherever the walls close in',
    zone: 'moor',
    axis: 'THE RACE — it eats the lantern every round whether or not you break its lock.',
    teaches: 'Some fights cannot be out-puzzled, only out-run. Spend the light, do not hoard it.',
    cfg: {
      /* hp 280 -> 340, damage UNCHANGED. 88% -> 70% (60 seeds, blind 5%, margin +65pt). The bat's
       * axis is `flameDrainPerRound` — it eats the lantern — so its threat is the SHORTENING of the
       * sighted window, not the size of its blows; 400/32 measured identically (70%) and was
       * rejected because it moves the damage number this creature is deliberately unremarkable in. */
      enemyHp: 340, enemyDamage: 40, enemyHardens: false,
      flameDrainPerRound: 7,
      lockShape: { pool: COLOURS, lenMin: 2, lenMax: 2 },
    },
    whyItDiffers: 'The ONLY creature against which perfect play still loses the light. Breaking its '
      + 'telegraph protects your health and does nothing for your sight, so the fight has a clock '
      + 'that skill cannot stop — and its health is low BECAUSE of that, so the answer is aggression '
      + 'rather than patience. Every other creature rewards patience.',
  },

  /* ============================================================================================ */
  {
    id: 'tombspider',
    name: 'TOMB SPIDER',
    sprite: { pack: 'Mourncrest03_BarrowBeasts', key: 'tombSpider', art: 'tombspider' },
    drawScale: 0.90,
    tier: 'common',
    /* ⛔ REWRITTEN 2026-09-02. The five strings below described a DUNGEON INTERIOR — "stair",
     * "flooded gallery", "sealed door", "choir vault", "under the barrow" — and DESIGN §6 killed the
     * interior on 2026-09-01 for a MEASURED reason (no 32 px interior tileset exists, re-derived
     * this session: 22 packs, 20 at 16 px, the two 32 px ones both outdoor moorland with zero
     * interior vocabulary). The slice is a CAIRN FIELD, walled by bluff and crag with scree
     * underfoot. Two files in one product disagreeing about whether a place is indoors is the
     * shared-fact defect (§6d-10) wearing prose, and the bestiary was the copy nobody updated. */
    firstSeen: 'the breach in the dry-stone wall, where the cairn field begins',
    zone: 'barrow',
    axis: 'THE SPIRAL — it always strikes whoever is already hurt.',
    teaches: 'Damage that concentrates costs a CHARACTER, not health. Heal the one who is falling.',
    cfg: {
      /* ⭐ DAMAGE 30 -> 20, AND IT IS A PARITY CHOICE, NOT A NERF. `_spider_parity.js` (60 seeds, at
       * this creature's own barrow arrival) holds the planner's win rate at the SHIPPED 43.3% while
       * the scaling below becomes live: 20 measures 43.3%, exactly the figure the old 30-damage
       * creature produced. Difficulty is where it was; only WHERE the damage lands has changed.
       * ⛔ 20 is also a CEILING, derived not chosen: above half of the smallest maximum health in
       * the party (Wren, 40) a hurt character dies to a NORMAL blow, so every point of wounded
       * scaling is lost to the clamp and the axis cannot exist. Measured inert at 22-30.
       *
       * ⛔⛔ 480/20 WAS OUTSIDE THE PRE-REGISTERED WINDOW AND SHIPPED THAT WAY FOR A DAY, CARRIED AS
       * "the deliberate tombspider red". IT WAS NOT DELIBERATE, IT WAS UNFINISHED. MEASURED
       * 2026-09-03 (`_cell_verify.js`, 60 seeds, the gate's own `meanSignature`): planner **37%**
       * against the window 45-80 that `_bestiary_sweep.js`'s header pre-registered above every
       * number in this file. The 43.3% the paragraph above cites is REAL and was taken at
       * `_spider_parity.js`'s own arrival fixture; the gate judges at a different one, so the two
       * instruments were measuring different fights and only one of them decides whether this
       * creature ships (master §2b: a fixture constant is part of the claim).
       * ✅ RE-DERIVED, NOT TYPED, and at the JUDGING seed count rather than a sweep's: 510/18 reads
       * **planner 65% · blind 0% · margin +65pt · 2.03 party-downs per fight**, which is inside the
       * design's stated aim of 63-72% rather than merely inside the window.
       * ⚠️ AND THE CELL WAS CHOSEN FOR ITS NEIGHBOURHOOD, NOT ITS POINT VALUE. This surface is a
       * CLIFF — 540/18 reads 42%, 560/18 reads 28%, and the shipped 480/20 sat on the far side of it
       * — because the win rate is a THRESHOLD on party-wipe (downs/fight moves smoothly 1.68 -> 2.90
       * across the same cells while win% falls off a shelf). 500/18 = 75%, 510/18 = 65%,
       * 520/18 = 60%: the whole +-10 hp band is inside the window, which is the most robustness
       * available anywhere on this axis. At n=60 a reading carries ~+-12pt at 95%, so quote this as
       * "a 65% fight at n=60", never as 65%.
       * ⛔ Damage 18 stays UNDER the ceiling the paragraph above derives (half of Wren's 40), so the
       * wounded-scaling axis is preserved, not traded away; `axis-fires` re-measured after the move. */
      enemyHp: 510, enemyDamage: 18, enemyHardens: false,
      targetPolicy: 'weakest',
      /* ⛔⛔ THE AXIS WAS NEARLY ABSENT AND ONLY A CONTROL FOUND IT. MEASURED 2026-09-02
       * (`_axis_witness.js --controls`, n=40, at this creature's own barrow arrival): flipping
       * `targetPolicy` from 'weakest' to 'random' and changing NOTHING else moved the outcome by
       * **+15pt on the planner arm and +0pt on the learner and blind arms**, against +73pt or
       * better for every other axis in this file. The cause was arithmetic, not code: 30 damage
       * into a party of 45/40/48 fells anybody in two hits, so concentrating them bought almost
       * exactly what chance already did. ⇒ **the page promised a death spiral and the fight
       * delivered "someone dies", which is what an untargeted creature delivers.**
       * ✅ `targetPolicy` decides WHO is hit; these two decide what BEING HURT COSTS. A blow on a
       * target at or below half health lands for 1.75x. That is the sentence two lines above this
       * cfg — *"Heal the one who is falling"* — finally being a rule instead of a hope: Oren's Hush
       * (+9) lifts a character from just under half to comfortably over it, so the heal is the
       * counterplay and the creature's own telegraph can demand the very colour it lives on.
       * ⚠️ Base damage is expected to FALL to pay for it (the re-derivation chooses it), so this is
       * not a buff: a fresh party is safer than before and a neglected one is in far more trouble.
       * ⛔ CONTINUOUS, NOT A THRESHOLD, AND THE THRESHOLD VERSION WAS MEASURED INERT AT EVERY DAMAGE
       * VALUE TRIED (43%->43% at 30, 100%->100% at 16). `combat.js`'s note on `woundedScaling`
       * carries the arithmetic; the short version is that a "below half health" trigger is at the
       * mercy of the hp ladder `max - k*damage`, and this creature's ladder stepped straight over
       * the window. Damage now rises smoothly with how hurt the target already is. */
      woundedScaling: 0.9,
      /* ⛔ LENGTH 2 IS NOT A DIFFICULTY CHOICE, IT IS THE §6b-8 INVARIANT. This creature is built to
       * kill a party member, so its lock space must survive that death — which len 3 cannot
       * (measured, `_carryover_probe.js`). `bestiary_gates.js/NO-UNBREAKABLE-STATE` proves it over
       * the creature's WHOLE lock space, not over a sampled set.
       *
       * ⛔⛔ AND THE POOL WAS [AZURE, VERDANT] UNTIL THE GATE REFUSED IT — TWICE, FOR TWO REASONS,
       * AND THE SECOND ONE IS THE INTERESTING ONE.
       *   (1) NO-UNBREAKABLE-STATE: two single-source colours at length 2 yield a space of exactly
       *       TWO locks (AZURE>VERDANT, VERDANT>AZURE), and losing EITHER Wren or Oren strands BOTH.
       *       On a creature explicitly built to kill a party member, that is the §6b-8 dead end in
       *       its purest form.
       *   (2) ⭐ `axis-fires` moved the signature by EXACTLY 0.0000 — the disconnected-variable
       *       shape wing §6b-2 rule 2 names, and a zero that means something. With only two possible
       *       telegraphs the planner broke every single one, so no lock ever LANDED, so the
       *       targeting rule this creature exists for never once executed. Its axis was decoration
       *       on top of a puzzle too thin to reach it. A two-lock creature is not a hard creature;
       *       it is a creature with no puzzle.
       * ✅ PALE joins the pool: the space goes 2 -> 7, every death leaves live locks (proven by the
       * gate, not by the arithmetic in this comment), and the fight is deep enough that the party
       * takes hits — which is the only condition under which "it strikes whoever is hurt" is a rule
       * rather than a sentence. ⚠️ PALE is also Oren.hush, the heal, which sharpens the intended
       * tension rather than blunting it: the creature can demand the very ability you need to spend
       * on the character it is killing. */
      lockShape: { pool: [A, V, P], lenMin: 2, lenMax: 2 },
    },
    whyItDiffers: 'Its pool leans on the SINGLE-SOURCE colours, so Wren and Oren are conscripted far '
      + 'more often than elsewhere — and PALE is Oren.hush, the party\'s only heal, so the telegraph '
      + 'can demand the exact ability you need to spend on the character it is killing. The fight is '
      + 'a tug between breaking the lock and keeping the falling member alive, and it is the only '
      + 'creature where those two compete for the same turn.',
  },

  /* ============================================================================================ */
  {
    id: 'censer',
    name: 'CENSER-BEARER',
    sprite: { pack: 'Mourncrest02_PaleChoir', key: 'censer-bearer', art: 'censer' },
    drawScale: 1.05,
    tier: 'common',
    firstSeen: 'the processional way, where the choir is heard first',
    zone: 'barrow',
    axis: 'THE SNUFFER — its blow barely wounds you and nearly puts the lantern out.',
    teaches: 'Losing is not always losing health. This one takes the thing you SEE with.',
    cfg: {
      /* hp 360 -> 520, damage UNCHANGED. 100% -> 63% (60 seeds, blind 0%, margin +63pt). ⚠️ THE
       * WHOLE GRID HELD EXACTLY ONE CELL IN WINDOW, which is worth recording rather than smoothing
       * over: the censer's `enemyHitFlame: -45` means a landed lock nearly blinds you outright, so
       * its win rate falls off a cliff in the damage dimension (360hp reads 100 / 83 / 33 / 29 across
       * dmg 26 / 34 / 42 / 50). Raising damage on THIS creature is not a difficulty knob, it is an
       * on/off switch — hp is the only smooth axis it has. 480/26 was measured at 82% and refused. */
      enemyHp: 620, enemyDamage: 20, enemyHardens: false,
      enemyHitFlame: -45,
      lockShape: { pool: [P, E], lenMin: 2, lenMax: 2 },
    },
    whyItDiffers: 'The inverse threat. Every other creature punishes a failed lock in HP; this one '
      + 'costs almost none and takes 45 flame, so two missed telegraphs blind you outright and the '
      + 'rest of the fight is played on guesswork. Its pool is the two DOUBLE-source colours, so the '
      + 'puzzle is easy while you can see it — which is exactly what makes going blind the whole '
      + 'fight rather than an inconvenience.',
  },

  /* ============================================================================================ */
  {
    id: 'ossuary',
    name: 'OSSUARY OOZE',
    sprite: { pack: 'Mourncrest03_BarrowBeasts', key: 'ossuaryOoze', art: 'ossuary' },
    drawScale: 1.15,   /* capped by _scale_collision.js — see the note above */
    tier: 'common',
    firstSeen: 'the sunk tarn among the cairns',
    zone: 'barrow',
    axis: 'THE GRIND — every telegraph is length 3, so the whole party is spoken for every round.',
    teaches: 'When nothing is free, the only lever left is TIMING. Perfect presses are the fight.',
    cfg: {
      /* ⛔⛔ IT EMITTED LENGTH 3 *ONLY* AND THE GATE REFUSED IT: all 36 locks in its space are
       * stranded by the death of ANY member, and death was reachable at 11 damage (simulated, seed
       * 9 — not argued from hit points, wing §6b-8 rule 2). "Every telegraph needs all three of you"
       * and "one of you can die" are simply incompatible, and the pure form of this creature is an
       * unwinnable state waiting for a bad seed.
       *
       * ⛔ THE TEMPTING FIX WAS TO DROP THE DAMAGE UNTIL NOBODY CAN DIE. Rejected: it makes the
       * creature unable to threaten anything, and a fight you cannot lose is not the "grind" this
       * entry claims to be — that is §6b-2 rule 5, tuning until the metric goes green and deleting
       * the mechanic on the way past.
       * ✅ THE FIX IS THE MIX. `len3Chance: 0.82` keeps four rounds in five fully conscripted, which
       * is the axis, while the remaining fifth is a length-2 telegraph that a two-actor party can
       * still answer — so a death costs the party dearly and never ends the puzzle. The 18% is not
       * a taste: it is the smallest share that leaves a live lock after every death, and the gate
       * re-derives that rather than trusting this sentence. */
      /* hp 620 -> 820, damage UNCHANGED. 100% -> 70% (60 seeds, blind 7%, margin +63pt). The ooze is
       * the LONG fight — length-3 locks 82% of the time — so its health bar IS its axis and raising
       * it is the change that keeps the creature itself. Damage must stay low: at 26 the planner
       * collapses to 29% and the blind control to 8%, i.e. the margin evaporates and the puzzle stops
       * mattering. 870/18 (50%) and 920/18 (45%) are also in window and were rejected as sitting on
       * the floor rather than the middle. */
      enemyHp: 820, enemyDamage: 18, enemyHardens: false,
      lockShape: { pool: COLOURS, lenMin: 2, lenMax: 3, len3Chance: 0.82 },
    },
    whyItDiffers: 'Four rounds in five it leaves NO free character — no damage-vs-lock decision, no '
      + 'one held in reserve, no heal to spare — so the skill expression collapses onto the timing '
      + 'bar and the flame economy is won or lost purely on presses. The fifth round is the breath, '
      + 'and learning to spend it is the fight.',
  },

  /* ============================================================================================ */
  {
    id: 'ironknight',
    name: 'IRON WARDEN',
    sprite: { pack: 'Mourncrest04_IronWardens', key: 'knight', art: 'ironknight' },
    drawScale: 1.10,
    tier: 'common',
    firstSeen: 'the sealed cist at the field\'s heart',
    zone: 'barrow',
    axis: 'THE PLATED — hardened against EMBER from the first round, permanently.',
    teaches: 'Your best ability is not always your best ability. Find the second plan.',
    cfg: {
      enemyHp: 340, enemyDamage: 40, enemyHardens: false,
      hardenedFixed: E,
      lockShape: { pool: COLOURS, lenMin: 2, lenMax: 2 },
    },
    whyItDiffers: 'Sable.strike is the party\'s single strongest ability at 15 power and it lands at '
      + 'half weight here for the WHOLE fight, from round one, with nothing the player can do about '
      + 'it. Unlike the gravebound the armour never moves, so it is not an adaptation puzzle at all '
      + '— it is a standing tax that makes the party\'s default damage plan the wrong one. The '
      + 'answer is Wren.chill and Oren.bramble carrying the damage, which is the reverse of every '
      + 'other fight in the slice.',
  },

  /* ============================================================================================ */
  {
    id: 'hierophant',
    name: 'THE HIEROPHANT',
    sprite: { pack: 'Mourncrest02_PaleChoir', key: 'hierophant', art: 'hierophant' },
    drawScale: 1.22,   /* capped by _scale_collision.js — see the note above */
    tier: 'boss',
    firstSeen: 'the stone ring under open sky — the DEMO ENDS HERE (wing §1: the demo stops at the first boss)',
    zone: 'barrow',
    axis: 'ADAPTATION UNDER A CLOCK — it hardens AND it drinks the light.',
    teaches: 'Everything the moor taught you, at once, with the lantern running out while you do it.',
    /* ⛔⛔ hp 400 -> 320 ON 2026-09-02, AND IT IS A CORRECTION, NOT A TUNE. The old numbers were
     * chosen while `combat.fabricateBreakableLock` was true, i.e. while a party reduced to one
     * character became INVULNERABLE (`_death_plateau.js`: 100% of telegraphs collapsed to length 1
     * at one survivor, 95-99% of them broke). Every boss stat was therefore fitted to a fight that
     * could not be lost from behind. With that gone this creature read `competent-wins 12/24`
     * against the gate's own bar of 20/24.
     * ⭐ 320/38 is DERIVED, by `_boss_rederive.js` (self-test 9/9, 99 cells, 24 seeds per policy —
     * the same n `boss_gates.js` uses, and its self-test asserts it reproduces the gate's printed
     * numbers exactly). It is the cheapest pair-with-the-wyrm satisfying six requirements stated
     * before the grid was run: planner >= 20/24, lock-blind <= 2/24 with ZERO timeouts, the axis
     * intact, and the learner (planner + naive hands) between 20% and 60%.
     * ⚠️ THE DAMAGE IS DELIBERATELY UNCHANGED at 38. This creature's threat is meant to be sharp;
     * what was wrong was the LENGTH, because a 400-hp fight against a lantern that dies in three
     * rounds is a fight played almost entirely blind. At 320 the median is 7 rounds and all 24
     * competent runs still end with the lantern OUT, so the axis is untouched. */
    cfg: {
      /* hp 320 -> 400, damage UNCHANGED. 98% -> 67% (60 seeds, blind 0%, margin +67pt). A boss the
       * planner loses one fight in three. 360/38 was measured at 87% and refused — the step from 360
       * to 400 is worth 20 points, which is the cliff this bestiary's note warns about, so do not
       * split it further without re-measuring at 60. */
      enemyHp: 400, enemyDamage: 38, enemyHardens: true, hardenCount: 1, oilCharges: 1,
      flameDrainPerRound: 5,
      lockShape: { pool: COLOURS, lenMin: 2, lenMax: 2 },
    },
    whyItDiffers: 'Boss 1 is deliberately a COMPOSITION of two axes the player has already met '
      + 'separately (gravebound\'s adaptation, the fen bat\'s clock) rather than a new rule learned '
      + 'in a boss fight. A boss that teaches is a boss that kills you while you read it; a boss '
      + 'that COMBINES is one the player can plan for on the walk in — which is the only kind that '
      + 'is fair at the end of a demo.',
  },

  /* ============================================================================================ */
  {
    id: 'barrowwyrm',
    name: 'THE BARROW WYRM',
    sprite: { pack: 'Mourncrest03_BarrowBeasts', key: 'barrowWyrm', art: 'barrowwyrm' },
    /* ⛔ 1.45 WAS TRIED FIRST AND IT COLLIDED WITH THE ENEMY HEALTH BAR — measured, not eyeballed.
     * `_scale_collision.js` parses the layout constants OUT of `ui.js` and reported the sprite's top
     * edge at y=26 against a bar occupying y=34..43 and x=230..490. The final boss would have been
     * drawn THROUGH its own health bar, in the one fight where the player is watching that bar
     * hardest. Wing §6b-3 rule 4: a model test cannot see a pixel, and `ui_smoke` was 14/14 green
     * over a canvas that drew an action off the bottom edge.
     * ⚠️ 1.30 IS A CEILING IMPOSED BY THE LAYOUT, NOT A DESIGN PREFERENCE. The enemy's feet sit at
     * y=206 and the top ~75px of the stage is UI furniture, so ~1.30 is all the room there is. To
     * make the final boss genuinely tower, the nameplate and health bar have to MOVE — a deliberate
     * layout pass, never a scale nudge, because nudging the scale is how the bar gets drawn over. */
    drawScale: 1.30,
    tier: 'boss',
    firstSeen: 'the long barrow itself, opened — the end of the slice',
    zone: 'barrow',
    axis: 'ENCIRCLEMENT — it holds TWO colours hardened at once, so half the palette is blunted.',
    teaches: 'You cannot sidestep into one comfortable colour. Keep moving around the whole wheel.',
    /* ⛔⛔ 490/30 -> 470/16 ON 2026-09-02, same correction as the Hierophant above and the same
     * receipt (`_boss_rederive.js`). Under the plateau this creature read `competent-wins 10/24`.
     * ⭐ WHY THE DAMAGE FALLS SO FAR AND THE HEALTH BARELY MOVES — it is this boss's own axis, and
     * `bestiary_gates.js/a-loss-is-a-loss` had already written the reason down before this session:
     * *"if damage does not move the outcome, the party is not losing to damage. Two hardened colours
     * blunt the party's output, the fight runs long, and the loss arrives on the round counter."*
     * ⇒ ENCIRCLEMENT kills by attrition of your OUTPUT, not by the size of its hits, so its damage
     * is the wrong dial and its length is the right one. 470 keeps the median at 12 rounds — five
     * longer than the demo boss — while 16 stops it from simply out-damaging a party it has already
     * blunted. All 24 competent runs still reach two colours blunted at once.
     * ⚠️ AND THE PAIRING IS THE POINT, WHICH NO PER-BOSS GATE CAN SEE. `boss_gates.js` checks each
     * boss alone, so two individually-legal bosses can still be in the wrong ORDER — the first pass
     * of the sweep picked a pair where the demo boss was HARDER than the climax. The shipped pair is
     * chosen under an explicit cross-boss requirement: the climax is 21 points harder for a learner
     * and 5 rounds longer. */
    cfg: {
      /* damage 16 -> 24, hp UNCHANGED at 520. 100% -> 52% (60 seeds, blind 0%, margin +52pt), and it
       * is the DAMAGE that had to move, which is the sharpest single lesson of this re-derivation.
       * At 16 the wyrm was hitting for less than one Hush restores (9 hp, ~4 casts a fight), so the
       * planner's new heal did not merely help against it — it CANCELLED the creature outright, and
       * no amount of health could fix that: the sweep reads **100% at every hp from 470 to 740** at
       * damage 16. ⭐ A health bar cannot make a fight dangerous when the party out-heals the incoming
       * rate; that is a race the enemy is not in. hp then went 470 -> 520 to put the final boss at
       * the BOTTOM of the window (52%) rather than the top (470/24 measured 70%) — it is the last
       * fight in the slice and should be the hardest thing in it. */
      enemyHp: 520, enemyDamage: 24, enemyHardens: true, hardenCount: 2, oilCharges: 2,
      lockShape: { pool: COLOURS, lenMin: 2, lenMax: 2 },
    },
    whyItDiffers: 'The gravebound\'s answer is to step off the hardened colour onto a comfortable '
      + 'one; this one remembers the last TWO, so the comfortable colour is the one it hardened '
      + 'against a round ago and the party is pushed all the way round the wheel. It is the only '
      + 'creature that makes all four colours matter for DAMAGE rather than only for the lock, and '
      + 'that is why it closes the slice.',
  },
];

/* ------------------------------------------------------------------------------------------------
 * ACCESS
 * ---------------------------------------------------------------------------------------------- */
function byId(id) { return CREATURES.find((c) => c.id === id) || null; }
function enemies() { return CREATURES.filter((c) => c.tier !== 'boss'); }
function bosses() { return CREATURES.filter((c) => c.tier === 'boss'); }

/** The creatures that walk one zone. `boss:false` excludes bosses, which are PLACED, never roamed. */
function byZone(zone, { boss = false } = {}) {
  return CREATURES.filter((c) => c.zone === zone && (boss ? c.tier === 'boss' : c.tier !== 'boss'));
}
/** Every zone named by the roster — derived, so adding a zone needs no second list. */
function zones() { return [...new Set(CREATURES.map((c) => c.zone))].filter(Boolean); }

/** The combat options for one creature. `encounterId` creatures hand their authored lock through. */
function combatOptions(creature, opts = {}) {
  const o = { seed: opts.seed === undefined ? 1 : opts.seed, cfg: { ...creature.cfg, ...(opts.cfg || {}) } };
  if (creature.lock) o.locks = [creature.lock.slice()];
  if (opts.locksHideWhenDark !== undefined) o.locksHideWhenDark = opts.locksHideWhenDark;
  if (opts.externalClock !== undefined) o.externalClock = opts.externalClock;
  return o;
}

/* ⛔ A COUNT THE SLICE'S OWN SPEC CAN BE CHECKED AGAINST, DERIVED AND NEVER TYPED. DESIGN §5 says
 * "eight enemy types and two bosses"; a hand-typed 8 here would go stale the first time a creature
 * is cut, silently, which is master §2b's stale-proof-figure row in a content file. */
const CENSUS = {
  get enemies() { return enemies().length; },
  get bosses() { return bosses().length; },
  get total() { return CREATURES.length; },
};

/* ⛔ EVERY CREATURE MUST DECLARE A ZONE, AND THE CHECK IS AT LOAD TIME. A creature with no zone is
 * placed nowhere — it exists, gates green, photographs beautifully and is unreachable by playing,
 * which is precisely the state six of these ten were in until 2026-09-02. Throwing here means the
 * page dies loudly on the next session's first run instead of quietly shipping a hole. */
{
  const ZONES = new Set(['moor', 'barrow']);
  const orphans = CREATURES.filter((c) => !ZONES.has(c.zone));
  if (orphans.length) {
    throw new Error(`bestiary: ${orphans.length} creature(s) with no known zone: `
      + `${orphans.map((c) => c.id).join(', ')} — a creature with no zone is unreachable by playing`);
  }
}

const API = { CREATURES, byId, enemies, bosses, byZone, zones, combatOptions, CENSUS };
if (typeof module !== 'undefined' && module.exports) module.exports = API;
if (typeof window !== 'undefined') window.LB_BESTIARY = API;
}());
