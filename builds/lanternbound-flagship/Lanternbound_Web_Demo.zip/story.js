'use strict';
/* ================================================================================================
 * story.js — THE AUTHORED BEATS. The half of "a story JRPG" that did not exist until 2026-09-02.
 * ================================================================================================
 *
 * ⛔ WHY THIS FILE EXISTS. `state.json` has sold this product as "a SNES/anime STORY JRPG" since
 * 2026-08-31 and justifies $14.99 with, verbatim, "an AUTHORED CAMPAIGN". A content inventory on
 * 2026-09-02 found ZERO narrative constructs in the project — no dialogue, no NPC, no scene, no
 * speaker, no authored line — and the word "story" appearing in DESIGN_Lanternbound.md exactly once,
 * inside the pejorative "a UI meter with a story attached". 380 green assertions across 14 suites
 * said nothing about it, because every one of them is about combat, the overworld or the art. That
 * is master §2b's half-a-field shape applied to a PRODUCT: a true statement about the systems,
 * read as a statement about the game.
 *
 * ⭐ THE WORLD WAS ALREADY WRITTEN — IT WAS JUST NEVER SPOKEN. `bestiary.js` carries a `firstSeen`
 * for every creature ("the waymark cairn, on the moor road", "the sunk causeway below the cairn",
 * "the stone ring under open sky", "the long barrow itself, opened") and an `axis`/`teaches` pair
 * naming what each fight is FOR. Nothing here invents a setting; it voices the one the bestiary and
 * the overworld had already committed to, which is why the beats can name real mechanics without
 * turning into a tutorial pasted over a different game.
 *
 * ⭐ AND THE BEATS DO A SECOND JOB THE PROJECT HAD OPEN. `openDesignQuestions_2026_09_02` item ONE
 * is that nothing TEACHES the end-of-round ordering rule; the on-ramp fix that followed was
 * mechanical (`buriedRelief`) and its own note says "THE SAYING IS THE MECHANIC". `firstWin` below
 * is where the party says it out loud, in OREN's voice, immediately after the first fight the
 * player wins — which is the one moment the lesson is about something that just happened to them.
 *
 * ⛔ PURE BY CONSTRUCTION: no DOM, no canvas, no timers. The renderer lives in `overworld_ui.js`
 * and the gates drive this module directly in Node. A beat that can only be reached through a
 * browser is a beat no gate can prove is reachable, and this project has already shipped an entire
 * unreachable second half for exactly that reason (master §2b, `LB_RETURN`).
 * ---------------------------------------------------------------------------------------------- */
(function () {
  /* ⛔ THE BROWSER GLOBAL IS `window.LB`, NOT `window.LB_COMBAT`. The first draft of this line
   * guessed the latter by analogy with `LB_BESTIARY`/`LB_STAGE`, and the guess FAILED SILENTLY: the
   * roster came back empty, and the roster check below is guarded with `NAMES.size &&` against a
   * vacuous pass — so in the browser it would simply not have run, while Node kept it green. That
   * is master §2b's `[].every()` row: a check that quietly covers nothing on the platform that
   * actually ships. The size assertion below is what makes the mistake loud instead of invisible. */
  const COMBAT = (typeof module !== 'undefined' && module.exports)
    ? require('./combat.js')
    : (typeof window !== 'undefined' ? window.LB : null);

  /* ------------------------------------------------------------------------------------------------
   * THE TRIGGER SET — closed, and checked at load time.
   * ⛔ A beat with a trigger nothing fires is the same defect as bestiary.js's creature with no zone:
   * it exists, it gates green, it reads beautifully and it is UNREACHABLE BY PLAYING. That check is
   * why six of ten creatures were found orphaned on 2026-09-02, and it is copied here deliberately.
   * ⚠️ Membership in this set proves the trigger is SPELLED right, never that anything FIRES it.
   * Only `story_gates.js` section 3 can prove that, by playing the game.
   * ---------------------------------------------------------------------------------------------- */
  const TRIGGERS = new Set([
    'open',              // a fresh run begins, in Aldermoor (never on a resume from a fight)
    /* ⛔ ADDED 2026-09-03, AND IT WAS ALREADY BEING FIRED. `overworld_ui.js` read
     * `ZONES.town.arriveBeat = 'gate'` and the frame loop called `beat('gate')` on arrival — but
     * `gate` was not in this set, so `byTrigger` returned undefined and `fire()` returned null.
     * The town's one authored moment was a SILENT NO-OP, and no gate could see it: story_gates 3a
     * scanned only `beat()` literal arguments and the table indirection hid the string entirely. */
    'gate',              // the north gate of Aldermoor: the party leaves the last lit place
    'dark',              // the lantern reaches zero on the OVERWORLD for the first time
    'firstWin',          // the player returns from the first fight they won
    'breach',            // the moor's goal: the break in the wall
    'barrow',            // arriving inside the cairn field
    'boss:hierophant',   // boss 1 down — the free demo ends here (bestiary firstSeen)
    'boss:barrowwyrm',   // boss 2 down
    'ring',              // the stone ring: the end of the slice
  ]);

  /* ------------------------------------------------------------------------------------------------
   * HOW A LINE BECOMES ROWS ON THE PANEL.
   *
   * ⛔ THE FIRST BUILD ALLOWED EXACTLY ONE ROW OF 68 CHARACTERS, AND THAT CONSTRAINT WAS ABOUT TO
   * REWRITE THE PROSE. Adding a 128 px speaker portrait narrowed the text column to ~58 characters
   * and put NINE authored lines over the bound — so the choice was to butcher nine lines to fit a
   * layout decision, or to let the renderer wrap. A one-row rule makes every future layout change
   * an editing pass on the script, which is the tail wagging the dog.
   *
   * ⭐ `ROW_CHARS` IS A DECLARATION AND THE GATE HOLDS IT HONEST. This module cannot see the panel,
   * so it states the budget it was authored against; `story_gates.js` reads the LIVE panel geometry
   * and asserts that many characters really do fit. Neither number is copied into the other, and a
   * layout change that narrows the column fails the gate instead of silently clipping the writing.
   * ---------------------------------------------------------------------------------------------- */
  const ROW_CHARS = 56;        // characters per rendered row; the gate proves the panel affords it
  const MAX_ROWS = 2;          // rows a single authored line may occupy
  const MAX_LINE_CHARS = 68;   // an overall sanity bound on one authored line

  /**
   * Greedy word wrap. ⚠️ Pure and shared: the UI wraps with THIS function at THIS budget, so what a
   * gate measures is what a player reads (wing §6d-10 — a second copy is a place the two diverge).
   */
  function wrap(text, chars = ROW_CHARS) {
    const words = String(text).split(/\s+/).filter(Boolean);
    const rows = [];
    let row = '';
    for (const w of words) {
      if (!row) { row = w; continue; }
      if ((`${row} ${w}`).length <= chars) row += ` ${w}`;
      else { rows.push(row); row = w; }
    }
    if (row) rows.push(row);
    return rows.length ? rows : [''];
  }

  /* ------------------------------------------------------------------------------------------------
   * THE BEATS.
   * `who` is a ROSTER name or null for narration. Load-time checked against combat.js's ROSTER, so
   * renaming a character breaks this file loudly instead of printing a name nobody in the game has.
   * ---------------------------------------------------------------------------------------------- */
  const BEATS = [
    {
      id: 'open',
      trigger: 'open',
      /* ⚠️ THE PLACE MOVED, THE LINES DID NOT. A run now begins in Aldermoor rather than already out
       * on the moor, so the scene is the party standing in the last lit town looking at a road whose
       * lamps are out — which is what these lines always described. Changing `place` and leaving the
       * writing alone is the honest edit: "ours is the last one lit" is a claim about the ROAD. */
      place: 'Aldermoor, before the road',
      lines: [
        { who: null, text: 'The lamps along the moor road have gone out, one by one.' },
        { who: 'SABLE', text: "Ours is the last one lit. That isn't a boast. It's the problem." },
        { who: 'WREN', text: 'How far to the stone ring?' },
        { who: 'SABLE', text: 'Two hours if we walk. Longer if we stop.' },
        { who: 'OREN', text: "We'll stop. Things out here have learned to wait for the dark." },
        { who: 'SABLE', text: "Then keep the flame up. It's the only thing that sees for us." },
      ],
    },
    {
      /* ⭐ THE DEPARTURE. The town's arrival is a LEAVING, and the card behind this scene says so —
       * so the beat names what is being given up rather than congratulating the player for a walk
       * across a safe field. It is the only beat in the run that happens somewhere warm. */
      id: 'gate',
      trigger: 'gate',
      place: "Aldermoor's north gate",
      lines: [
        { who: null, text: 'The lantern over the gate is the last one still burning here.' },
        { who: 'WREN', text: 'Nobody came out to see us off.' },
        { who: 'OREN', text: 'Nobody opens a door after dark. That is the whole of it.' },
        { who: 'SABLE', text: 'Then we go. Two hours to the ring, and the wick is ours now.' },
      ],
    },
    {
      id: 'dark',
      trigger: 'dark',
      place: 'wherever the lantern finally fails',
      lines: [
        { who: null, text: 'The wick gutters, catches nothing, and goes out.' },
        { who: 'WREN', text: "I can't see the road." },
        { who: 'OREN', text: 'Neither can they. Walk quiet and we may pass.' },
        { who: 'SABLE', text: 'Or find the oil. Your call, and it is a real one.' },
      ],
    },
    {
      /* ⭐ THE TEACHING BEAT. Its three middle lines are the end-of-round ordering rule stated in
       * plain words, at the first moment the player has personally seen it happen. bonehound's own
       * `teaches` field reads "Whoever acts last writes the top. A right colour at the wrong moment
       * is a wrong colour." — this is that sentence, given to a character. */
      id: 'firstWin',
      trigger: 'firstWin',
      place: 'standing over the first thing that got up',
      lines: [
        { who: 'WREN', text: "It closed itself. I hit it and it just... closed." },
        { who: 'OREN', text: 'They shut against colour. You have to open them in order.' },
        { who: 'OREN', text: 'Whoever moves last writes the top of the lantern.' },
        { who: 'SABLE', text: 'Right colour, wrong moment, is a wrong colour. Remember it.' },
      ],
    },
    {
      id: 'breach',
      trigger: 'breach',
      place: 'the break in the wall',
      lines: [
        { who: null, text: 'The wall runs off into the dark both ways. Here, it is broken.' },
        { who: 'WREN', text: 'Somebody broke this from the inside.' },
        { who: 'OREN', text: 'Somebody did. A long time ago, and not with hands.' },
        { who: 'SABLE', text: 'We go in on the lantern we have. Not the one we wish we had.' },
      ],
    },
    {
      id: 'barrow',
      trigger: 'barrow',
      place: 'the cairn field',
      lines: [
        { who: null, text: 'Cairns, in rows, as far as the light goes.' },
        { who: 'WREN', text: 'These are graves.' },
        { who: 'SABLE', text: 'These are markers. The graves are underneath.' },
        { who: 'OREN', text: 'Keep to the middle. The stones remember being walked on.' },
      ],
    },
    {
      id: 'boss-hierophant',
      trigger: 'boss:hierophant',
      place: 'the stone ring under open sky',
      lines: [
        { who: null, text: 'The censer falls. The light it was drinking comes back, slowly.' },
        { who: 'WREN', text: 'It was taking the flame. Drinking it.' },
        { who: 'OREN', text: 'It was. And it will not be the last thing here that does.' },
        { who: 'SABLE', text: 'Then we spend less time standing still. Move.' },
      ],
    },
    {
      id: 'boss-barrowwyrm',
      trigger: 'boss:barrowwyrm',
      place: 'the long barrow, opened',
      lines: [
        { who: null, text: 'The wyrm settles, and the barrow is quiet for the first time.' },
        { who: 'WREN', text: 'It held two colours at once. I had to go the whole way round.' },
        { who: 'OREN', text: 'That is what the road asks of you, at the end of it.' },
        { who: 'SABLE', text: 'Not the end. The ring is the end. Come on.' },
      ],
    },
    {
      id: 'ring',
      trigger: 'ring',
      place: 'the stone ring',
      lines: [
        { who: null, text: 'The ring stands open to the sky, and the cradle is cold.' },
        { who: 'SABLE', text: 'Hold it steady.' },
        { who: null, text: 'She lifts the lantern into the cradle. The ring takes it.' },
        { who: null, text: 'One light. Then, far off, another. Then the next.' },
        { who: 'WREN', text: "They're lighting. All down the road, they're lighting." },
        { who: 'OREN', text: 'That is what it was for.' },
        { who: 'SABLE', text: "Then we walked it right. Let's go home while we can see." },
        { who: null, text: 'THE LANTERN ROAD — end of the first crossing.' },
      ],
    },
  ];

  /* ------------------------------------------------------------------------------------------------
   * LOAD-TIME INTEGRITY. Throws, loudly, on the next session's first run — never a silent hole.
   * Mirrors the zone check at the foot of bestiary.js, and for the same reason.
   * ---------------------------------------------------------------------------------------------- */
  {
    const ids = BEATS.map((b) => b.id);
    const dupes = ids.filter((id, i) => ids.indexOf(id) !== i);
    if (dupes.length) throw new Error(`story: duplicate beat id(s): ${[...new Set(dupes)].join(', ')}`);

    const badTrigger = BEATS.filter((b) => !TRIGGERS.has(b.trigger));
    if (badTrigger.length) {
      throw new Error(`story: ${badTrigger.length} beat(s) with a trigger outside the closed set: `
        + `${badTrigger.map((b) => `${b.id}->${b.trigger}`).join(', ')}`);
    }

    /* ⛔ A TRIGGER WITH NO BEAT IS AS BAD AS A BEAT WITH NO TRIGGER — it is a hook the UI fires into
     * nothing, which reads at the call site as "this moment has a scene" and does not. */
    const unused = [...TRIGGERS].filter((t) => !BEATS.some((b) => b.trigger === t));
    if (unused.length) throw new Error(`story: trigger(s) with no beat: ${unused.join(', ')}`);

    const NAMES = new Set((COMBAT && COMBAT.ROSTER ? COMBAT.ROSTER : []).map((c) => c.name));
    /* ⛔ AN EMPTY ROSTER IS A LOAD-ORDER DEFECT, NOT A REASON TO SKIP THE CHECK. Every environment
     * that loads this file can reach combat.js — Node by require, the browser by script order — so
     * "no names to check against" only ever means the wiring is wrong, and skipping quietly is how
     * the `window.LB_COMBAT` typo above stayed invisible. Master §2b: require a non-empty set
     * before believing anything you assert over it. */
    if (!NAMES.size) {
      throw new Error('story: the party roster is empty, so no speaker could be verified. '
        + 'combat.js must load before story.js (browser: script order in overworld.html).');
    }
    for (const b of BEATS) {
      if (!Array.isArray(b.lines) || !b.lines.length) throw new Error(`story: beat ${b.id} has no lines`);
      for (const [i, l] of b.lines.entries()) {
        if (!l.text || !String(l.text).trim()) throw new Error(`story: beat ${b.id} line ${i} is empty`);
        if (String(l.text).length > MAX_LINE_CHARS) {
          throw new Error(`story: beat ${b.id} line ${i} is ${String(l.text).length} chars, over the `
            + `${MAX_LINE_CHARS}-char panel row: "${l.text}"`);
        }
        const rows = wrap(l.text);
        if (rows.length > MAX_ROWS) {
          throw new Error(`story: beat ${b.id} line ${i} wraps to ${rows.length} rows at `
            + `${ROW_CHARS} chars, over the ${MAX_ROWS}-row panel: "${l.text}"`);
        }
        /* ⛔ A SINGLE WORD LONGER THAN THE BUDGET CANNOT WRAP — greedy wrapping emits it as an
         * over-long row and the panel clips it. Checked explicitly, because `rows.length <= 2` is
         * true for that case and would pass it straight through. */
        const fat = rows.find((r) => r.length > ROW_CHARS);
        if (fat) {
          throw new Error(`story: beat ${b.id} line ${i} contains an unwrappable ${fat.length}-char `
            + `run over the ${ROW_CHARS}-char row: "${fat}"`);
        }
        /* NAMES is guaranteed non-empty by the throw above, so this check can never pass vacuously. */
        if (l.who !== null && !NAMES.has(l.who)) {
          throw new Error(`story: beat ${b.id} line ${i} is spoken by "${l.who}", who is not in the `
            + `party roster (${[...NAMES].join(', ')})`);
        }
      }
    }
  }

  const byTrigger = (t) => BEATS.find((b) => b.trigger === t) || null;

  /* ------------------------------------------------------------------------------------------------
   * THE PLAYHEAD. Holds which beats have been seen and which one is on screen.
   *
   * ⛔ `seen` IS PART OF THE SAVE, NOT OF THE PAGE. A fight is a full page navigation in this game,
   * so anything the story remembers has to survive one. `toJSON`/`from` are that contract and
   * `story_gates.js` section 4 round-trips them, because the last thing in this project that was
   * read across that seam and never written cost the entire second half of the game.
   * ---------------------------------------------------------------------------------------------- */
  class Story {
    constructor(opts = {}) {
      this.seen = new Set(Array.isArray(opts.seen) ? opts.seen : []);
      this.beat = null;   // the beat on screen, or null
      this.index = 0;     // which line of it
      this.queue = [];    // beats fired while another was playing, in order
      this.fired = [];    // every trigger this playhead has been handed, in order (diagnostic)
    }

    /**
     * Hand the playhead a trigger. Safe to call every frame: a repeat is a no-op.
     * Returns the beat that opened or queued, or null.
     *
     * ⛔ IT QUEUES, IT DOES NOT DROP, AND THE FIRST VERSION DROPPED. `fire()` originally returned
     * null whenever a scene was already up — correct-looking, because it protects the scene on
     * screen, and WRONG, because the beat that arrived is then never seen and never marked seen, so
     * it is silently gone for that run. Two triggers genuinely can land together: `resumeFromFight`
     * fires `firstWin` and a `boss:*` beat in the same call, and the overworld can reach `breach`
     * on the same frame the lantern dies. That is the project's own dead-reader shape one level up
     * — a beat that exists, gates green, and never reaches the player.
     */
    fire(trigger) {
      this.fired.push(trigger);
      const b = byTrigger(trigger);
      if (!b || this.seen.has(b.id)) return null;
      if (this.beat === b || this.queue.includes(b)) return null;   // already up or already waiting
      if (this.beat) { this.queue.push(b); return b; }
      this.beat = b; this.index = 0;
      return b;
    }

    /** The line on screen, or null when nothing is playing. */
    get active() {
      if (!this.beat) return null;
      const line = this.beat.lines[this.index];
      return {
        beatId: this.beat.id,
        place: this.beat.place,
        who: line.who,
        text: line.text,
        index: this.index,
        total: this.beat.lines.length,
        last: this.index === this.beat.lines.length - 1,
      };
    }

    /** True while a scene is up — the caller must not tick the world. */
    get playing() { return this.beat !== null; }

    /**
     * Advance one line. Returns true if a scene is still up afterwards.
     * ⛔ FALLING OFF THE END CLOSES THE SCENE AND MARKS IT SEEN. An advance past the last line that
     * left `beat` set would freeze the game behind a panel with no way out — the soft-lock this
     * method exists to make impossible, and `story_gates.js` section 2 asserts it by over-advancing.
     */
    advance() {
      if (!this.beat) return false;
      this.index += 1;
      /* ⚠️ `close()` PROMOTES THE QUEUE, so the answer to "is a scene still up?" after falling off
       * the end is not a constant `false` — it is whether anything was waiting behind this beat.
       * Returning a hard false here would have told the caller to resume the world while a promoted
       * beat was on screen, i.e. the game running underneath its own cutscene. */
      if (this.index >= this.beat.lines.length) { this.close(); return this.playing; }
      return true;
    }

    /**
     * Dismiss the whole scene (the player skipped it). Marks it seen, exactly like reading it, then
     * promotes whatever was waiting behind it — so a queued beat cannot be stranded by a skip.
     */
    close() {
      if (!this.beat) return;
      this.seen.add(this.beat.id);
      this.beat = this.queue.shift() || null;
      this.index = 0;
    }

    toJSON() { return { v: 1, seen: [...this.seen] }; }

    /**
     * Rebuild from `toJSON()`. ⚠️ This is parsing HOSTILE input — the payload rides in
     * `sessionStorage`, which the player can edit — so it validates rather than typechecks, and an
     * unrecognised beat id is DROPPED rather than carried. Dropping is right where refusing is
     * wrong: a bad story save must not cost the player their walk, it may only replay a scene.
     */
    static from(json) {
      if (!json || json.v !== 1 || !Array.isArray(json.seen)) return new Story();
      const known = new Set(BEATS.map((b) => b.id));
      return new Story({ seen: json.seen.filter((id) => typeof id === 'string' && known.has(id)) });
    }
  }

  const CENSUS = {
    beats: BEATS.length,
    lines: BEATS.reduce((n, b) => n + b.lines.length, 0),
    spokenLines: BEATS.reduce((n, b) => n + b.lines.filter((l) => l.who).length, 0),
    speakers: [...new Set(BEATS.flatMap((b) => b.lines.map((l) => l.who).filter(Boolean)))],
    words: BEATS.reduce((n, b) => n + b.lines.reduce((m, l) => m + l.text.split(/\s+/).length, 0), 0),
  };

  const API = { BEATS, TRIGGERS, MAX_LINE_CHARS, ROW_CHARS, MAX_ROWS, wrap, Story, byTrigger, CENSUS };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  if (typeof window !== 'undefined') window.LB_STORY = API;
}());
