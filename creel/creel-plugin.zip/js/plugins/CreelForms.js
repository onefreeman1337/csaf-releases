/*:
 * @target MZ
 * @plugindesc [Creel] Body-plan corpus — 12 authored fish body plans as envelope pairs. Library file; no parameters.
 * @author Core Systems Asset Factory
 *
 * @help
 * CreelForms.js
 *
 * This file is HALF THE PRODUCT. It authors twelve fish body plans as pure data
 * and answers three questions about them: where is the body's edge at this x,
 * what is its closed outline, and how far does it reach.
 *
 * It has NO dependency on RPG Maker MZ and makes no engine calls, so it can be
 * read, diffed, rendered and checked offline before any of it reaches a Bitmap.
 *
 * Load order does not matter. Nothing here resolves a sibling file.
 */

var CreelForms = CreelForms || {};

(function (F) {
    'use strict';

    // =============================================================================================
    // WHY A FISH IS AN ENVELOPE PAIR AND NOT A PILE OF MASSES
    //
    // 1. A FISH IS ONE CLOSED SILHOUETTE. Loose stacked masses give a lumpy contour with internal
    //    seams that show the instant two masses take slightly different colours. (Wing doctrine
    //    22a-1b: a chain of abutting masses reads as a chain — author the spine as ONE outline.)
    //
    // 2. THE PATTERN MUST BE CLIPPED IN GEOMETRY, NOT PAINTED AND MASKED. That needs an exact,
    //    cheap answer to "where does the body start and stop at this x", for any x. A pile of
    //    ellipses cannot answer it. `span()` answers it in two array lookups and a lerp.
    //
    // So a form is TWO PROFILES over one axial parameter u, tail (u=0) to snout (u=1): a TOP edge
    // and a BOTTOM edge, INDEPENDENT of one another.
    //
    // The independence is not a nicety — half the corpus IS the asymmetry. `hatchet` is a flat back
    // over a deep keeled belly; `flathead` is a flat top with the mass forward; `spindle` has a
    // belly curve that `torpedo` specifically does not. A single half-depth with a mirror flag
    // cannot express any of those, and six of the twelve would collapse toward each other — which
    // is exactly the collision the product's kill condition names.
    //
    // COORDINATES. Unit box [-0.5, 0.5] on both axes, y DOWN, origin at the optical centre.
    // Every fish is TAIL-LEFT / HEAD-RIGHT. Nothing here flips an axis.
    // =============================================================================================

    // ⛔ THE EXTENT BUDGET IS A DISC, NOT A SQUARE: the test is hypot(x, y) <= BODY_BOX. A specimen
    // is drawn into round frames as well as square ones, and a square budget lets a corner escape a
    // round one.
    //
    // ⛔ AND THE BUDGET IS SHARED WITH THE FIN SET. A body that fits and a fin set that fits can
    // overflow TOGETHER, because a fin attaches to the body's own edge and its reach is body depth
    // PLUS fin extent. Each form declares `finBudget` — the maximum |y| any fin on this form may
    // reach — and the suite is required to measure the COMBINED extent of every form x fin-set
    // pairing against BODY_BOX, never either alone.
    F.BODY_BOX = 0.50;

    // Sample count per edge. A form is sampled once at profile time and reused; nothing resamples
    // per frame.
    F.SAMPLES = 56;

    // Part roles. A part carries a ROLE, never a colour — the livery layer resolves a role against
    // the species being drawn, which is what lets one form appear in many palettes without the
    // geometry knowing about any of them.
    F.ROLE = {
        BODY: 'body',
        BELLY: 'belly',
        FIN: 'fin',
        MARK: 'mark',
        EYE: 'eye',
        EDGE: 'edge'
    };

    F.IDS = [
        'spindle', 'torpedo', 'disc', 'sunfish', 'eel', 'ribbon',
        'flathead', 'hatchet', 'angler', 'ray', 'fan', 'pike'
    ];

    // =============================================================================================
    // THE ENVELOPE
    //
    // One curve shape, six numbers, used twice per form. It peaks at `p`, falling to `r0` of full
    // depth at the tail and `r1` at the snout, with independent exponents either side.
    //
    // ⚠️ THE EXPONENTS ARE THE WHOLE VOCABULARY AND ARE NOT INTERCHANGEABLE WITH THE RATIOS.
    // A high r0 makes the tail end DEEP (a truncated rear — `sunfish`). A high e0 makes the taper
    // toward the tail LATE, so the body stays full and then drops away (a peduncle — `spindle`).
    // Confusing the two is how `torpedo` and `spindle` end up as the same bar.
    // =============================================================================================

    /**
     * Evaluate one envelope at axial position u.
     * @param {number} u  0 at the tail, 1 at the snout.
     * @param {{H:number,p:number,r0:number,r1:number,e0:number,e1:number}} e
     * @returns {number} half-depth, in unit-box units, always >= 0.
     */
    F.env = function (u, e) {
        var s, t;
        if (u <= e.p) {
            t = (e.p <= 0) ? 1 : (u / e.p);
            s = e.r0 + (1 - e.r0) * Math.pow(t, e.e0);
        } else {
            t = (e.p >= 1) ? 1 : ((1 - u) / (1 - e.p));
            s = e.r1 + (1 - e.r1) * Math.pow(t, e.e1);
        }
        return e.H * s;
    };

    /** Shorthand so a form's declaration reads as a table rather than as six object literals. */
    function e(H, p, r0, r1, e0, e1) {
        return { H: H, p: p, r0: r0, r1: r1, e0: e0, e1: e1 };
    }

    // =============================================================================================
    // PER-EDGE RIPPLE — the one silhouette event the envelope structurally CANNOT produce.
    //
    // `env` is monotonic either side of its peak, so it can only make convex-ish outlines. Five of
    // the twelve forms therefore came out as the same horizontal lozenge at different aspect
    // ratios, and PROPORTION is the first thing to go at reading size — no ratio was ever going to
    // separate five of them.
    //
    // A ripple applied to ONE edge is a SKYLINE FEATURE, and a skyline feature outranks every
    // difference beneath it. Only one form in this corpus may own any given one.
    //
    // ⚠️ It is scaled by sin(pi*u) so it vanishes at both ends: a ripple that does not die out
    // leaves a hard step at the tail and the snout, and an outline that stops abruptly reads as
    // damage rather than as form.
    // =============================================================================================

    /**
     * @param {number} u
     * @param {?{amp:number, cyc:number, phase:number}} w  absent = no ripple.
     */
    function ripple(u, w) {
        if (!w || !w.amp) return 0;
        return Math.sin((u * w.cyc + (w.phase || 0)) * 2 * Math.PI) * w.amp * Math.sin(Math.PI * u);
    }
    F.ripple = ripple;

    // =============================================================================================
    // THE TWELVE SPECS
    //
    // Each entry is pure data — no engine calls, nothing sampled — so the whole corpus can be read
    // and checked before any of it is drawn.
    //
    //   x0, x1      axial extent: peduncle (tail junction) to snout.
    //   top, bot    the two envelopes, as HALF-DEPTHS above and below the spine.
    //   waveAmp     spine displacement amplitude (serpentine forms only).
    //   waveCyc     spine displacement cycles across the body.
    //   girth       cross-section WIDTH as a fraction of its DEPTH. Not drawn — this is a side view —
    //               but it is a real property of a body plan and it is what makes MASS physical.
    //               1.00 is round in cross-section; below is laterally compressed; ABOVE is
    //               dorsally flattened, which is why `flathead` is 1.40 and `ray` is 2.20.
    //   finUnit     the depth a FIN SET sizes itself against. 0 means "use the body depth", true for
    //               eleven of the twelve. `fan` overrides it because its body is small BY DESIGN and
    //               its identification is its SPAN.
    //   dorsal0/1   the u range along the back where a dorsal fin may sit.
    //   pect        [u, side] anchor for a pectoral fin; side is a fraction of local depth.
    //   tail        caudal fin scale, as a multiple of the peduncle half-depth.
    //   finBudget   THE SHARED-BUDGET TERM. Maximum |y| any fin on this form may reach.
    //   eye         [u, side] eye anchor.
    //   extra       id for form-intrinsic geometry drawn outside the body envelope. '' for none.
    //   reads       ⛔ THE ACCEPTANCE CRITERION, not decoration. What this silhouette must read as
    //               on the contact sheet at the size the product is actually seen at. The sheet
    //               PRINTS this string beside the specimen, so a caption cannot drift away from the
    //               corpus (wing 17c: a caption's claim must be derived, never typed).
    //
    // ⛔ `extra` IS NOT OPTIONAL. Four forms carry part of their identification OUTSIDE the body
    // envelope — a ray IS its pectoral sweep, a fan IS its fin span, an angler IS its lure, a pike
    // IS its jaw — and those four must read correctly with EVERY fin set, including the plainest.
    // Putting that geometry in the fin set instead would make the form legible in one pairing out
    // of eight.
    // =============================================================================================

    var SPEC = {

        // The baseline everything else is judged against: streamlined, deepest a third back from
        // the snout, WITH A BELLY. The belly envelope is ~30% deeper than the back and peaks
        // slightly further aft, and that is the whole of what separates this from `torpedo`.
        // ⛔ r0 IS 0.105, NOT 0.255. MEASURED: at 0.255 there is no visible tail wrist at all and the
        // form reads as a plain leaf — its own caption was claiming a feature the picture did not
        // contain. A peduncle is what says "fast open-water fish", and it is this form's only
        // skyline feature, so it has to be a genuine pinch.
        spindle: {
            x0: -0.250, x1: 0.440,
            top: e(0.116, 0.640, 0.105, 0.045, 1.85, 0.78),
            bot: e(0.150, 0.580, 0.110, 0.055, 1.75, 0.72),
            waveAmp: 0.000, waveCyc: 0.0, girth: 0.85, finUnit: 0.00,
            dorsal0: 0.42, dorsal1: 0.80, pect: [0.66, 0.62], tail: 2.05,
            finBudget: 0.360, eye: [0.855, -0.30], extra: '',
            reads: 'a streamlined fish with a belly and a narrow tail wrist'
        },

        // Near-cylindrical: a straight bar with rounded ends and a BLUNT nose. r1 is 0.62 rather
        // than spindle's 0.045 — the nose does not come to a point — and both exponents are above 2
        // so depth holds flat across the middle instead of curving.
        // ⚠️ NOT `spindle`: no belly. top and bot carry the same numbers ON PURPOSE.
        // ⛔ r0/r1 RAISED TO 0.86/0.80. MEASURED: at 0.64 the ends are two thirds of the middle,
        // which is a VISIBLE taper, so the form read as another pointed lozenge and collided with
        // `spindle` at 0.286 — the closest pair in the corpus. Its identity is that it does NOT
        // taper; anything less than a near-parallel bar is a different fish.
        torpedo: {
            x0: -0.265, x1: 0.450,
            top: e(0.113, 0.500, 0.860, 0.800, 3.20, 3.00),
            bot: e(0.113, 0.500, 0.860, 0.800, 3.20, 3.00),
            waveAmp: 0.000, waveCyc: 0.0, girth: 1.00, finUnit: 0.00,
            dorsal0: 0.40, dorsal1: 0.78, pect: [0.64, 0.66], tail: 1.55,
            finBudget: 0.355, eye: [0.860, -0.30], extra: '',
            reads: 'a blunt-nosed cylinder held at even depth end to end'
        },

        // A coin on edge: laterally compressed, and as close to CIRCULAR as the corpus gets.
        // ⚠️ Genuinely ROUND (0.475 long by 0.49 deep). `sunfish` is pushed the other way — taller
        // than long — so the two separate by PROPORTION rather than by a detail neither shows at
        // thumbnail size.
        disc: {
            x0: -0.175, x1: 0.300,
            top: e(0.245, 0.470, 0.115, 0.075, 0.46, 0.52),
            bot: e(0.245, 0.500, 0.115, 0.075, 0.46, 0.52),
            waveAmp: 0.000, waveCyc: 0.0, girth: 0.30, finUnit: 0.00,
            dorsal0: 0.30, dorsal1: 0.74, pect: [0.62, 0.42], tail: 0.85,
            finBudget: 0.430, eye: [0.800, -0.38], extra: '',
            reads: 'a round coin on edge, as wide as it is deep'
        },

        // A circle with the back sliced off flat, and TALLER THAN IT IS LONG — 0.415 by 0.60, the
        // most extreme depth-to-length ratio in the corpus. The truncated rear is the identity and
        // `tail` is 0.26 so the caudal is a nub rather than a fin.
        //
        // ⛔⛔ IT RENDERED AS A RECTANGLE — A BAG, OR A SHIELD — AND EVERY NUMBER IN THE PROJECT WAS
        // HAPPY WITH IT. FOUND BY OPENING THE SHEET AND LOOKING, 2026-09-03.
        //
        // The old envelopes were `e(0.300, 0.640, 0.970, 0.070, 1.45, 0.50)`. Walk them: `env`
        // returns `r0 + (1-r0)*t^e0` below the peak, so with r0 = 0.970 the half-depth travels from
        // 0.970 to 1.000 across the whole first 64% of the body. That is a STRAIGHT HORIZONTAL LINE
        // to within 3%, on both envelopes at once — so the silhouette was a flat top, a flat bottom
        // and a flat rear wall. **Three straight sides is a box, whatever the sixth number says**,
        // and the pointed snout (r1 = 0.070 collapsing to a needle) only made it read as a bag with
        // a corner pulled out.
        //
        // ⚠️ THE COMMENT ABOVE IT WAS THE TRAP, AND IT WAS ARGUING FOR THE DEFECT: "r0 = 0.97 on
        // both envelopes gives a near-vertical rear wall" is TRUE, and it is a statement about the
        // 3% of the outline at the rear while being silent about the 64% it flattens. Wing §20c — a
        // comment explaining why a number is right is not evidence that it is.
        //
        // The truncation is kept because it is the form's identity and its separation from `disc`
        // (a trailing-edge difference, wing §22a-3, which is the axis that survives reading size).
        // What changes is that the rear wall is now SHORTER than the body's own maximum depth, which
        // is what a mola actually is — the body bulges above and below the clavus — so the outline
        // has to curve from the wall out to the peak instead of running flat to it:
        //
        //   r0 0.970 -> 0.720   the rear wall is 43% of full depth: still a wall, no longer the
        //                       whole flank
        //   e0 1.450 -> 0.620   an exponent below 1 rises FAST off the wall and then eases, so the
        //                       shoulder is a curve; above 1 it crept, which is what flattened it
        //   r1 0.070 -> 0.300   a blunt snout. A mola has no point on it, and the needle was doing
        //                       the same work as `pike`'s.
        sunfish: {
            x0: -0.095, x1: 0.320,
            top: e(0.300, 0.640, 0.720, 0.300, 0.62, 0.50),
            bot: e(0.300, 0.620, 0.720, 0.305, 0.62, 0.50),
            waveAmp: 0.000, waveCyc: 0.0, girth: 0.35, finUnit: 0.00,
            // ⛔ THE DORSAL RUN IS 0.10-0.80, NOT 0.22-0.62. MEASURED: on the short run all eight
            // fin sets rendered as the same picture (sunfish/sail vs sunfish/spine = 0.0197) —
            // this body is so large that a fin confined to the middle of its back is swallowed.
            // A mola's dorsal and anal lobes are its PROPULSION and run to the very rear, so the
            // long run is the honest shape as well as the separating one.
            dorsal0: 0.10, dorsal1: 0.80, pect: [0.66, 0.40], tail: 0.26,
            finBudget: 0.470, eye: [0.815, -0.40], extra: '',
            reads: 'taller than it is long, with the rear cut off square'
        },

        // A wavy line with mass. Length 0.83 against a depth of 0.10 — eight to one — over a spine
        // wave of 1.35 cycles.
        // ⛔ MUST NOT CLOSE INTO A LOOP. 1.35 cycles at amplitude 0.115 reads as serpentine at
        // reading size without the body crossing itself. Two full cycles read as a knot.
        // ⛔ IT NEEDED A HEAD AND A TAIL. MEASURED: at r0 0.72 / r1 0.56 the depth barely moves from
        // end to end, so it rendered as a CONSTANT-WIDTH WAVY BAND — a sine wave, not an animal. A
        // limb of constant width reads as a tube; taper is what makes an outline a body. The tail
        // now runs out to a point (r0 0.20) and the head is the deepest part of the fish
        // (p 0.86, r1 0.95), which is what an eel actually is.
        eel: {
            x0: -0.380, x1: 0.450,
            top: e(0.055, 0.860, 0.200, 0.950, 1.35, 1.40),
            bot: e(0.060, 0.860, 0.200, 0.950, 1.35, 1.40),
            // ⛔ finUnit IS OVERRIDDEN. Sized against its own body depth (0.115) every fin on this
            // form came out at ~0.03 and all eight sets read alike. An eel's median fin genuinely
            // runs most of its length, so the unit is the fin's own scale, not the body's.
            waveAmp: 0.115, waveCyc: 1.35, girth: 0.95, finUnit: 0.115,
            dorsal0: 0.12, dorsal1: 0.90, pect: [0.80, 0.90], tail: 1.15,
            finBudget: 0.290, eye: [0.905, -0.40], extra: '',
            reads: 'a long serpentine body tapering to a point, with a blunt head'
        },

        // A wide banner: an eel's length carried at three times an eel's depth, held straight.
        // ⚠️ NOT `eel` — three times the depth and no meaningful spine wave. NOT `disc` — twice the
        // length. These three are the corpus's length/depth extremes, and stating them as RATIOS
        // rather than as adjectives is what keeps them apart at reading size.
        // ⛔ THE UNDULATING DORSAL EDGE IS THIS FORM'S WHOLE IDENTITY, and it is the one thing the
        // envelope alone cannot draw. Without it `ribbon` was a third horizontal lozenge sitting
        // between `spindle` and `torpedo`. A real ribbonfish carries a rippling crest along its
        // whole back, so the ripple is honest as well as useful — and NO OTHER FORM MAY OWN IT.
        // The belly stays smooth: a ripple on both edges reads as a caterpillar (22a).
        ribbon: {
            x0: -0.355, x1: 0.440,
            // ⛔ r0 STAYS BLUNT AT 0.700. TAPERING THE TAIL WAS TRIED AND MEASURED WORSE IN BOTH
            // DIRECTIONS — do not re-derive it. Reasoning that a ribbonfish "runs out to nothing
            // behind" and setting r0 0.26 moved ribbon/ray from 0.377 to 0.245 and torpedo/ribbon
            // from 0.302 to 0.259, because a form tapered at both ends IS a lozenge and this
            // corpus's densest cluster is lozenges. A blunt tail is what keeps it a BANNER.
            //
            // ⚠️ And the crest cannot be judged by this metric at all: refining it from 3 coarse
            // lobes to 10 fine ones plainly improved the reading and moved torpedo/ribbon the
            // WRONG way, 0.331 -> 0.302. A fine edge is legible to a viewer and occupies almost no
            // pixels, so an area metric is structurally blind to it. The trap is to coarsen the
            // crest until the number moves, which buys a worse picture for a better score.
            top: e(0.150, 0.500, 0.700, 0.420, 1.60, 1.50),
            bot: e(0.168, 0.500, 0.700, 0.420, 1.60, 1.50),
            // ⛔ cyc 7.0 / amp 0.022, NOT 3.5 / 0.042. At three tall round lobes the crest read as
            // CARTOON CLOUD BUMPS — a crown, not a fin. A crest is a FINE, high-frequency ripple;
            // at low frequency and high amplitude each lobe becomes a mass in its own right and
            // the eye reads the masses instead of the edge.
            topWave: { amp: 0.022, cyc: 7.0, phase: 0.12 },
            // ⛔ THE SPINE WAVE IS OFF. It put a visible kink in the BELLY, which is `eel`'s cue —
            // and with the crest now carrying this form's identity, a second wavy edge only made
            // the outline read as a caterpillar. One form, one skyline feature.
            waveAmp: 0.000, waveCyc: 0.0, girth: 0.15, finUnit: 0.00,
            dorsal0: 0.22, dorsal1: 0.86, pect: [0.78, 0.70], tail: 0.85,
            finBudget: 0.400, eye: [0.885, -0.38], extra: '',
            reads: 'a long deep banner with a rippling crest along its back'
        },

        // A wedge, widest AT THE HEAD. p = 0.90 on the belly envelope puts the deepest point
        // forward of the eye, which is the stated separator from a reversed `spindle`. The back is
        // nearly flat (H 0.062, both exponents high) because the form is dorsally flattened.
        // The asymmetry is pushed further: a back that is very nearly a STRAIGHT LINE over a belly
        // carrying all the mass. `hatchet` owns the deep keel amidships; this one owns the flat
        // top, and the two must not be softened toward each other.
        flathead: {
            x0: -0.255, x1: 0.445,
            top: e(0.046, 0.780, 0.300, 0.520, 1.80, 1.60),
            bot: e(0.196, 0.900, 0.185, 0.640, 1.35, 1.90),
            waveAmp: 0.000, waveCyc: 0.0, girth: 1.40, finUnit: 0.00,
            dorsal0: 0.32, dorsal1: 0.70, pect: [0.80, 0.86], tail: 1.70,
            finBudget: 0.350, eye: [0.885, -0.72], extra: '',
            reads: 'a flat-backed wedge carrying its mass at the head'
        },

        // A cleaver: the BACK is straight and the belly is a deep curved keel.
        // ⚠️ NOT `disc`, which curves both ways. The asymmetry is 4.6:1 — the deepest belly in the
        // corpus against one of the shallowest backs — and it is the ONLY thing carrying the
        // distinction, so neither number may be softened toward the other.
        hatchet: {
            x0: -0.180, x1: 0.360,
            top: e(0.058, 0.560, 0.620, 0.420, 2.10, 1.70),
            bot: e(0.268, 0.520, 0.180, 0.140, 1.05, 0.88),
            waveAmp: 0.000, waveCyc: 0.0, girth: 0.22, finUnit: 0.00,
            dorsal0: 0.30, dorsal1: 0.72, pect: [0.66, 0.50], tail: 0.95,
            finBudget: 0.415, eye: [0.845, -0.55], extra: '',
            reads: 'a straight back over a deep keeled belly, like a cleaver'
        },

        // A head with an afterthought. The mass is FORWARD — p = 0.86 on both envelopes, against
        // `sunfish`'s central mass — and the rear third is a shrunken stalk (r0 = 0.13).
        // The illicium is `extra`: an angler without its lure is just a bad sunfish.
        angler: {
            x0: -0.185, x1: 0.395,
            top: e(0.205, 0.860, 0.130, 0.180, 1.90, 1.05),
            bot: e(0.212, 0.880, 0.130, 0.190, 1.90, 1.00),
            waveAmp: 0.000, waveCyc: 0.0, girth: 0.90, finUnit: 0.00,
            dorsal0: 0.20, dorsal1: 0.52, pect: [0.72, 0.72], tail: 0.95,
            finBudget: 0.385, eye: [0.830, -0.56], extra: 'illicium',
            reads: 'a huge forward head on a shrunken stalk, carrying a lure'
        },

        // A kite with a string.
        // ⚠️ A kite is NOT a rhombus — a symmetrical rhombus reads as a four-pointed compass star
        // and collides with `fan`. So: WIDER THAN TALL (0.72 by 0.53), widest point FORWARD of
        // centre (p = 0.62), and the rear comes to an actual point (r0 = 0.012) where the whip
        // attaches. The whip carries real length and weight or the form is a rhombus after all.
        // ⛔ FLATTER AND WIDER THAN IT WAS. MEASURED: at depth 0.523 it was a big central mass and
        // collided with `disc` at 0.291 — a pair my eye did not flag and the sweep found. A ray is
        // a FLAT thing: dropping the depth to ~0.40 while keeping the length makes it read as a
        // wing rather than as another blob, and the straight-sided taper (exponent 1.0) is what
        // keeps its corners sharp.
        ray: {
            x0: -0.310, x1: 0.410,
            top: e(0.202, 0.620, 0.012, 0.020, 1.00, 1.05),
            bot: e(0.202, 0.620, 0.012, 0.020, 1.00, 1.05),
            waveAmp: 0.000, waveCyc: 0.0, girth: 2.20, finUnit: 0.00,
            dorsal0: 0.34, dorsal1: 0.58, pect: [0.52, 0.95], tail: 0.00,
            finBudget: 0.420, eye: [0.800, -0.26], extra: 'whip',
            reads: 'a forward-weighted kite trailing a long whip tail'
        },

        // A square of fin with a body inside it.
        // ⛔ THE SPAN IS FLAT-TOPPED AND NEAR-SQUARE, not a lens. A raised cosine over the whole
        // body gives a smooth diamond — identical to `ray`'s — and, far worse, it SWALLOWS THE FIN
        // SET: every fin set then draws the same silhouette. The span is inset from both ends of
        // the body, so the dorsal and caudal of every fin set still project past it.
        //
        // ⛔ THE DORSAL RANGE IS THE WHOLE BODY AND THE BUDGET IS ABOVE THE SPAN'S REACH. Both are
        // consequences of that same defect: a fin set confined inside the span in BOTH axes cannot
        // project past it at any value.
        // ⛔ THE BODY IS LONGER THAN IT WAS (0.56, not 0.46). With the span reaching equally above
        // and below a short body the whole form came out TALLER THAN LONG, which is `sunfish`'s
        // cue, and a tall spiky oval reads as a pinecone. A fan-finned fish is a horizontal animal
        // wearing a curtain; the body has to state the horizontal.
        fan: {
            x0: -0.260, x1: 0.300,
            top: e(0.112, 0.520, 0.320, 0.120, 0.90, 0.80),
            bot: e(0.118, 0.520, 0.320, 0.120, 0.90, 0.80),
            waveAmp: 0.000, waveCyc: 0.0, girth: 0.25, finUnit: 0.30,
            dorsal0: 0.10, dorsal1: 0.92, pect: [0.62, 0.55], tail: 0.95,
            finBudget: 0.470, eye: [0.800, -0.42], extra: 'fanspan',
            reads: 'a small body inside a squared-off curtain of fin'
        },

        // An arrow. Long, straight, and the jaw is carried a THIRD of the length forward — p is
        // 0.38, well aft, so the body is already tapering by mid-length and the head is a long
        // point rather than a blunt end.
        // ⚠️ NOT `torpedo`, which is blunt-nosed with its depth held flat to the front.
        // ⛔ IT WAS A SPLINTER. MEASURED: at H 0.094 with r1 0.66 it drew 1,288 ink pixels — the
        // third-thinnest form in the corpus — and read as a dash with a hook floating beside it.
        // Two changes: real depth (H 0.118), and a snout that runs out to a LONG STRAIGHT POINT
        // (r1 0.16, e1 1.10 — an exponent near 1 is a straight-sided taper, which is what makes an
        // arrow an arrow rather than a curve).
        pike: {
            x0: -0.255, x1: 0.340,
            top: e(0.118, 0.380, 0.430, 0.160, 1.30, 1.10),
            bot: e(0.124, 0.360, 0.430, 0.175, 1.30, 1.10),
            waveAmp: 0.000, waveCyc: 0.0, girth: 0.80, finUnit: 0.00,
            dorsal0: 0.30, dorsal1: 0.62, pect: [0.58, 0.70], tail: 1.85,
            finBudget: 0.345, eye: [0.880, -0.44], extra: 'jaw',
            reads: 'a long tapering arrow with a drawn-out jaw'
        }
    };

    /**
     * The authored spec for a form id, or undefined.
     * ⚠️ An unknown id returns undefined and NEVER throws — a buyer's custom species must not
     * crash a fishing scene.
     * @param {string} id
     */
    F.spec = function (id) {
        return Object.prototype.hasOwnProperty.call(SPEC, id) ? SPEC[id] : undefined;
    };

    /** Display name for a form id. */
    F.name = function (id) {
        if (!Object.prototype.hasOwnProperty.call(SPEC, id)) return '?';
        return id.charAt(0).toUpperCase() + id.slice(1);
    };

    /** The acceptance criterion a specimen must satisfy on the contact sheet. */
    F.reads = function (id) {
        var s = F.spec(id);
        return s ? s.reads : '';
    };

    // =============================================================================================
    // SAMPLING
    // =============================================================================================

    /**
     * Build the sampled profile for a form. This is the struct every other file talks to; nothing
     * downstream reads a spec directly.
     *
     *   n          number of samples
     *   x[]        axial positions, STRICTLY ASCENDING (relied on by span())
     *   yt[], yb[] top and bottom edge, ABSOLUTE (spine displacement already applied)
     *   sp[]       the spine itself, for pattern centring and the lateral line
     *
     * @param {string} id
     * @param {number} [n] sample count; defaults to F.SAMPLES.
     */
    F.profile = function (id, n) {
        var s = F.spec(id);
        if (!s) return undefined;
        var N = (n === undefined) ? F.SAMPLES : n;
        var x = new Array(N + 1);
        var yt = new Array(N + 1);
        var yb = new Array(N + 1);
        var sp = new Array(N + 1);
        var i, u, y;
        for (i = 0; i <= N; i++) {
            u = i / N;
            y = (s.waveAmp === 0) ? 0
                : Math.sin((u * s.waveCyc + 0.18) * 2 * Math.PI) * s.waveAmp;
            x[i] = s.x0 + (s.x1 - s.x0) * u;
            sp[i] = y;
            yt[i] = y - F.env(u, s.top) - ripple(u, s.topWave);
            yb[i] = y + F.env(u, s.bot) + ripple(u, s.botWave);
        }
        return { id: id, spec: s, n: N, x: x, yt: yt, yb: yb, sp: sp };
    };

    /**
     * The body's top edge, bottom edge and spine at an arbitrary x, or null outside the body.
     *
     * ⛔ THIS IS THE FUNCTION THE WHOLE PATTERN SYSTEM STANDS ON. Every pattern element is clipped
     * to the body IN GEOMETRY rather than painted and masked, and this is what makes that
     * affordable: two lookups and a lerp per element.
     *
     * ⚠️ It returns the EDGES, not a half-depth about zero. On `hatchet` those differ by a factor
     * of four, and a caller that assumes symmetry puts every stripe outside the fish.
     *
     * @returns {?{top:number, bot:number, spine:number}}
     */
    F.span = function (prof, x) {
        var n = prof.n;
        if (x <= prof.x[0]) {
            if (x < prof.x[0]) return null;
            return { top: prof.yt[0], bot: prof.yb[0], spine: prof.sp[0] };
        }
        if (x >= prof.x[n]) {
            if (x > prof.x[n]) return null;
            return { top: prof.yt[n], bot: prof.yb[n], spine: prof.sp[n] };
        }
        // x is a linear ramp from x0 to x1, so the index is exact arithmetic, not a search.
        var t = (x - prof.x[0]) / (prof.x[n] - prof.x[0]) * n;
        var i = Math.min(Math.max(Math.floor(t), 0), n - 1);
        var f = t - i;
        return {
            top: prof.yt[i] + (prof.yt[i + 1] - prof.yt[i]) * f,
            bot: prof.yb[i] + (prof.yb[i + 1] - prof.yb[i]) * f,
            spine: prof.sp[i] + (prof.sp[i + 1] - prof.sp[i]) * f
        };
    };

    /**
     * The closed outline ring: along the TOP from tail to snout, then back along the BOTTOM.
     * Returned as a flat array of {x, y} in unit-box coordinates, first point not repeated.
     *
     * This is what the renderer traces as ONE path and fills ONCE — canvas has no "punch a hole in
     * what I already drew", so any hole must be traced in the same path as the shape it belongs to.
     */
    F.outline = function (prof) {
        var n = prof.n, i, out = [];
        for (i = 0; i <= n; i++) out.push({ x: prof.x[i], y: prof.yt[i] });
        for (i = n; i >= 0; i--) out.push({ x: prof.x[i], y: prof.yb[i] });
        return out;
    };

    /**
     * Greatest distance from the origin reached by the body outline.
     * ⛔ hypot, not max(|x|,|y|) — the budget is a DISC (see F.BODY_BOX).
     */
    F.extent = function (prof) {
        var o = F.outline(prof), m = 0, i, d;
        for (i = 0; i < o.length; i++) {
            d = Math.sqrt(o[i].x * o[i].x + o[i].y * o[i].y);
            if (d > m) m = d;
        }
        return m;
    };

    /** Axial length of a form, in unit-box units. */
    F.length = function (prof) {
        return prof.x[prof.n] - prof.x[0];
    };

    /** Greatest top-to-bottom depth of a form, in unit-box units. */
    F.depth = function (prof) {
        var m = 0, i, d;
        for (i = 0; i <= prof.n; i++) {
            d = prof.yb[i] - prof.yt[i];
            if (d > m) m = d;
        }
        return m;
    };

    /**
     * Where a fin attaches, in unit-box coordinates.
     * `side` is a signed fraction of the LOCAL half-depth: -1 is the back edge, +1 the belly edge,
     * 0 the spine. Derived from the body's own edge so a form's pose cannot desynchronise from the
     * things hung off it (wing 11b: a coordinate constant is an assumption about a pose).
     * @returns {?{x:number, y:number, top:number, bot:number, spine:number}}
     */
    F.anchor = function (prof, u, side) {
        var x = prof.x[0] + (prof.x[prof.n] - prof.x[0]) * u;
        var sp = F.span(prof, x);
        if (!sp) return null;
        var half = (side < 0) ? (sp.spine - sp.top) : (sp.bot - sp.spine);
        return {
            x: x,
            y: sp.spine + half * side,
            top: sp.top,
            bot: sp.bot,
            spine: sp.spine
        };
    };

    // =============================================================================================
    // FORM-INTRINSIC EXTRA GEOMETRY
    //
    // Four forms carry part of their identification OUTSIDE the body envelope. This geometry is
    // emitted here, with the form, rather than in a fin set — a form must read correctly with EVERY
    // fin set, and geometry living in a fin set is legible in one pairing out of eight.
    //
    // Every shape is returned as a CLOSED RING of unit-box points. Rings, not strokes, for two
    // reasons: a ring can be traced into the same path as the body and filled once (canvas cannot
    // punch a hole in what it has already drawn), and a ring carries real TAPER, which a constant
    // stroke width cannot — a limb of constant width reads as a tube (wing 22a-1b).
    //
    // ⛔ A POINT IS A CLOSURE ON THE WIDTH, NOT A SWEEP ACROSS THE OUTLINE. `taper()` walks up one
    // side and back down the other from ONE half-width function, so a tip is simply the place where
    // the width goes to nothing. Building a point by crossing the two sides leaves a needle.
    // =============================================================================================

    /**
     * Build a closed tapered ring from a spine.
     * @param {Array<{x:number,y:number}>} spine  ordered points, base first.
     * @param {function(number):number} halfW  half-width at parameter t in [0,1].
     */
    function taper(spine, halfW) {
        var m = spine.length - 1, i, t, nx, ny, len, w, a = [], b = [];
        for (i = 0; i <= m; i++) {
            t = i / m;
            // Normal from the local spine direction, so the ring stays perpendicular through a bend.
            var p0 = spine[Math.max(i - 1, 0)];
            var p1 = spine[Math.min(i + 1, m)];
            nx = -(p1.y - p0.y);
            ny = (p1.x - p0.x);
            len = Math.sqrt(nx * nx + ny * ny) || 1;
            nx /= len; ny /= len;
            w = halfW(t);
            a.push({ x: spine[i].x + nx * w, y: spine[i].y + ny * w });
            b.push({ x: spine[i].x - nx * w, y: spine[i].y - ny * w });
        }
        b.reverse();
        return a.concat(b);
    }

    /** Sample a quadratic bezier into `n + 1` points. */
    function quad(p0, c, p1, n) {
        var out = [], i, t, u;
        for (i = 0; i <= n; i++) {
            t = i / n; u = 1 - t;
            out.push({
                x: u * u * p0.x + 2 * u * t * c.x + t * t * p1.x,
                y: u * u * p0.y + 2 * u * t * c.y + t * t * p1.y
            });
        }
        return out;
    }

    /**
     * Form-intrinsic geometry outside the body envelope.
     * @returns {Array<{id:string, role:string, ring:Array<{x:number,y:number}>}>} possibly empty.
     */
    F.extra = function (prof, opts) {
        var s = prof.spec, out = [];
        if (!s.extra) return out;
        // ⛔ `opts.caudalK` LETS THE FIN SET REACH THE ONE FORM WHOSE TAIL LIVES IN `extra`.
        // MEASURED: a ray has no caudal fin at all (`tail: 0`), so all eight of its pairings were
        // ONE silhouette — ray/lance against ray/trail scored 0.0082, i.e. the same picture. That
        // is the "eight silhouettes are one silhouette" defect, and on this form the honest place
        // to carry the variation is the WHIP, which is anatomically the tail. It is passed as a
        // plain number rather than read from CreelFins so this file keeps no sibling dependency.
        var ck = (opts && typeof opts.caudalK === 'number') ? opts.caudalK : 1.0;
        // ⚠️ AND THE STYLE, NOT ONLY THE SCALAR. Keying the whip on `caudalK` alone left
        // ray/lance against ray/trail at 0.0122 — the same picture — because those two sets carry
        // nearly equal caudalK (1.25 and 1.20). A scalar shared by two sets cannot separate them;
        // the tail's SHAPE is what actually differs between a lance and a streamer.
        var cs = (opts && opts.caudal) ? opts.caudal : 'round';

        if (s.extra === 'illicium') {
            // An angler is a huge head plus A LURE ON A ROD. Both halves are required: the rod is
            // what says "angler" and the bulb is what terminates it — a rod without a terminal blob
            // reads as a stray scratch (wing 22a-2b: an appendage below the resolution floor gets
            // assigned to the nearest common category).
            var brow = F.anchor(prof, 0.72, -1.0);
            var rod = quad(
                { x: brow.x, y: brow.y },
                { x: brow.x + 0.075, y: brow.y - 0.175 },
                { x: brow.x + 0.150, y: brow.y - 0.105 },
                14
            );
            out.push({
                id: 'rod', role: F.ROLE.FIN,
                ring: F.fitToDisc(taper(rod, function (t) { return 0.0135 * (1 - 0.45 * t); }),
                                  brow.x, brow.y, F.BODY_BOX)
            });
            // The bulb sits at the rod's own tip — derived, so the two cannot drift apart.
            var tip = rod[rod.length - 1];
            out.push({ id: 'lure', role: F.ROLE.MARK, ring: disc(tip.x, tip.y, 0.0325, 14) });

        } else if (s.extra === 'whip') {
            // A ray IS its trailing whip. It must be LONG and it must carry weight at the root, or
            // the kite reads as a rhombus and collides with `fan`.
            var root = { x: prof.x[0] + 0.018, y: prof.sp[0] };   // rooted INSIDE, so no seam
            var K = Math.min(Math.max(ck, 0.4), 1.5);
            //                        length x   width x   droop
            var STYLE = {
                round: [0.86, 1.42, 0.085],   // short and thick, a stub
                fork:  [1.00, 1.00, 0.055],
                fan:   [0.80, 1.60, 0.020],   // broad-based and stubby
                lance: [1.30, 0.78, 0.008],   // long, stiff and straight
                trail: [1.55, 0.46, 0.115]    // a long thin streamer with real droop
            };
            var st = STYLE[cs] || STYLE.fork;
            var L = (0.115 + 0.145 * K) * st[0];
            var W = (0.020 + 0.014 * K) * st[1];
            var whip = quad(
                root,
                { x: root.x - L * 0.62, y: root.y + st[2] * 1.6 },
                { x: root.x - L, y: root.y + st[2] * 0.4 },
                18
            );
            var wring = taper(whip, function (t) { return W * (1 - t) * (1 - t) + 0.0035; });
            out.push({
                id: 'whip', role: F.ROLE.FIN,
                ring: F.fitToDisc(wring, root.x, root.y, F.BODY_BOX)
            });

        } else if (s.extra === 'fanspan') {
            // ⛔ FLAT-TOPPED AND NEAR-SQUARE, and INSET from both ends of the body. A raised cosine
            // over the whole body gives a smooth lens — a diamond identical to `ray`'s — and it
            // swallows the fin set whole. The plateau exponent is what makes it a curtain rather
            // than a lens.
            // ⛔ THE SPAN SWALLOWED THE BODY WHOLE AND THE FORM RENDERED AS A PLAIN EGG. MEASURED:
            // at reach 0.355 over u 0.16-0.88 it drew 3,780 ink pixels — the MOST of any form —
            // and the caption "a small body inside a squared-off curtain of fin" described a
            // picture containing neither a body nor a curtain. Three changes, and the third is the
            // one that matters:
            //
            //  1. reach 0.355 -> 0.255, so the body's own outline is still visible inside it.
            //  2. inset u 0.16-0.88 -> 0.235-0.795, so the head and the tail project fore and aft.
            //  3. ⛔ A SCALLOPED TRAILING EDGE. Two things of the same gross shape are told apart
            //     by what their outline does at the EDGE, never by what is drawn inside it — and a
            //     smooth oval says "egg" whatever its proportions. Rays fanning to a scalloped
            //     margin say "fin" immediately, and no other form in this corpus owns that.
            // ⛔ LOBES 10 AT DEPTH 0.055, NOT 6 AT 0.16. MEASURED by looking at 300px: six lobes
            // 16% deep are six coarse triangles, and coarse triangles on a taper are TEETH — the
            // form read as a pinecone. The rule ("a fin is told apart by what its trailing edge
            // does") was right and its execution was below the size it needed: a scallop only says
            // "fin rays" when it is fine relative to the span it sits on.
            var u0 = 0.235, u1 = 0.795, reach = 0.235, N = 64, i, u, r, ta = [], ba = [];
            var LOBES = 10, LOBE_DEPTH = 0.055;
            for (i = 0; i <= N; i++) {
                var t = i / N;
                u = u0 + (u1 - u0) * t;
                r = Math.pow(Math.sin(Math.PI * t), 0.30);      // plateau, not a lens
                // The scallop is a fraction of the local reach, so it dies out with the span
                // itself and cannot leave a hard step at either shoulder.
                var scal = 1 - LOBE_DEPTH * (0.5 - 0.5 * Math.cos(t * LOBES * 2 * Math.PI));
                var xx = prof.x[0] + (prof.x[prof.n] - prof.x[0]) * u;
                var spn = F.span(prof, xx);
                ta.push({ x: xx, y: (spn ? spn.top : 0) - reach * r * scal });
                ba.push({ x: xx, y: (spn ? spn.bot : 0) + reach * r * scal });
            }
            ba.reverse();
            // ⛔⛔ FIN RAYS, AND THEY ARE A TONAL FIX AS MUCH AS AN ANATOMICAL ONE.
            //
            // MEASURED 2026-09-03, `_probe/visibility.js` §2 — how much of a specimen falls within
            // 14 luminance of the ground it is drawn on, over 432 form x livery x ground cells:
            //
            //     fan/abyssal on window     79.93% faint    <- worst in the corpus
            //     fan/albino  on paper      76.56% faint    <- second worst
            //     hatchet/abyssal on window 57.99% faint    <- the next form down
            //
            // `fan` failed at BOTH ENDS of the palette while no other form came near it, which is
            // the signature of a FORM defect rather than a livery interaction. The cause is that
            // the body is drawn with a counter-shading gradient and every form-intrinsic extra is
            // drawn with ONE FLAT FILL — and on this form the extra is most of the picture. So a
            // buyer putting a dark species on the dark MZ window, or a pale one on a light panel,
            // got a contour with nothing inside it.
            //
            // ⚠️ THE OBVIOUS FIXES WERE BOTH REJECTED BEFORE BEING WRITTEN. Darkening the fin until
            // the number clears is wing §14a's trap (obey the symptom, make the picture worse), and
            // a gradient across the span cannot help the dark-on-dark case at all, because every
            // stop of a dark livery's ramp is still dark.
            //
            // Rays work for a reason that survives any ground: they are struck at an ABSOLUTE
            // separation from the fin they sit on (wing §22e-1), so wherever the fin colour lands
            // within 14 of the ground, the rays are still ~26 clear of it. The area stops being one
            // tone, which is the actual defect.
            //
            // Doctrine obeyed deliberately: the count is derived from a PITCH and never typed
            // (§22b-1a), a ray that cannot resolve is DROPPED rather than crowded (§22a-2d), the
            // rays are keyed to the scallop VALLEYS so they terminate where a real fin's rays do
            // rather than being laid on as separate strokes that detach (§22a-2b), and they are
            // handed to the renderer as geometry because only the renderer knows the livery.
            var ribs = [], rb, rt;
            for (i = 0; i < LOBES; i++) {
                // One ray per scallop valley: t at the valley is (i + 0.5) / LOBES, which is where
                // `scal` is at its minimum and therefore where the margin steps in.
                var rt0 = (i + 0.5) / LOBES;
                var ru = u0 + (u1 - u0) * rt0;
                var rr = Math.pow(Math.sin(Math.PI * rt0), 0.30);
                var rsc = 1 - LOBE_DEPTH * (0.5 - 0.5 * Math.cos(rt0 * LOBES * 2 * Math.PI));
                var rx = prof.x[0] + (prof.x[prof.n] - prof.x[0]) * ru;
                var rspn = F.span(prof, rx);
                if (!rspn) continue;
                // ⚠️ A ray runs from just INSIDE the body's own edge to just short of the margin.
                // Starting it on the edge puts it under the body contour where it cannot be seen,
                // and running it to the margin puts it under the span contour for the same reason.
                rt = reach * rr * rsc;
                if (rt < 0.030) continue;          // below this a ray is a scratch, not structure
                ribs.push([
                    { x: rx, y: rspn.top - rt * 0.10 },
                    { x: rx, y: rspn.top - rt * 0.88 }
                ]);
                ribs.push([
                    { x: rx, y: rspn.bot + rt * 0.10 },
                    { x: rx, y: rspn.bot + rt * 0.88 }
                ]);
            }
            out.push({ id: 'span', role: F.ROLE.FIN, ring: ta.concat(ba), ribs: ribs });

        } else if (s.extra === 'jaw') {
            // A pike is read from its GAPE. The lower jaw runs forward past the snout and the ring
            // closes back along the jawline, so the snout steps rather than blending — two masses
            // read as two when their silhouette STEPS (wing 22a-1b).
            // ⛔ THE ROOT IS 0.19 BACK FROM THE SNOUT, NOT 0.09. An appendage must OVERLAP the mass
            // it grows from, never abut it: at the old root the newly pointed snout is almost no
            // depth at all, so the jaw read as a hook floating beside the fish rather than as part
            // of it. Rooted deep inside the head, the join is a change of direction instead of a
            // seam, and the gape still projects past the snout where the identification lives.
            var sn = prof.x[prof.n];
            var root = F.span(prof, sn - 0.190);
            var rb = root ? root.bot : 0.03;
            var rs = root ? root.spine : 0;
            out.push({
                id: 'jaw', role: F.ROLE.BODY,
                // ⛔ THE ROOT SITS INSIDE THE BODY AND THE DROP BELOW THE BELLY IS 0.016, NOT 0.034.
                // At the larger drop the jaw hung below the belly line for its whole root length,
                // so it read as a thin flange detached from the fish rather than as part of the
                // head — the gap between two nearly-parallel edges is what the eye picks up, not
                // the shapes either side of it. Rooted ABOVE the belly (rb - 0.030) it merges, and
                // it is thicker end to end so it survives at reading size.
                ring: [
                    { x: sn - 0.190, y: rb - 0.030 },
                    { x: sn + 0.062, y: rs + 0.022 },
                    { x: sn + 0.066, y: rs + 0.052 },
                    { x: sn - 0.170, y: rb + 0.016 }
                ]
            });
        }
        return out;
    };

    // =============================================================================================
    // FITTING TO THE BUDGET DISC
    //
    // ⛔ CLAMPING A LENGTH IS NOT ENOUGH, AND CLAMPING PER POINT IS WRONG. A budget bounds where a
    // part may REACH, while a length is measured from a root that is ALREADY DISPLACED — measured,
    // length-clamping alone left 20 of 96 pairings outside the disc at up to 0.7248. And clamping
    // each sample independently drags the outside samples along the circle and BENDS the part,
    // turning a shaped margin into a flat arc: a shape must be SHORTENED, never deformed.
    //
    // So scale the whole ring uniformly about its own root by the largest factor that keeps every
    // point inside. The part keeps its shape, stays attached, and the budget is true BY
    // CONSTRUCTION rather than by care.
    //
    // ⚠️ It lives here, not in CreelFins, because `extra` needs it too — a ray's whip is form
    // geometry and it overflowed the disc the moment it started responding to the fin set. One
    // implementation, two readers.
    // =============================================================================================

    /** Largest k in [0,1] keeping every point of `ring`, scaled about (rx,ry) by k, inside R. */
    F.fitFactor = function (ring, rx, ry, R) {
        var k = 1, i, dx, dy, a, b, c, disc, t;
        var rr = rx * rx + ry * ry;
        for (i = 0; i < ring.length; i++) {
            dx = ring[i].x - rx; dy = ring[i].y - ry;
            a = dx * dx + dy * dy;
            if (a < 1e-12) continue;
            b = 2 * (rx * dx + ry * dy);
            c = rr - R * R;
            if (c > 0) return 0;                       // the ROOT is already outside the disc
            disc = b * b - 4 * a * c;
            if (disc <= 0) continue;
            t = (-b + Math.sqrt(disc)) / (2 * a);
            if (t < k) k = t;
        }
        return Math.max(0, k);
    };

    /** Scale a ring about (rx,ry) so it fits the budget disc, preserving its shape. */
    F.fitToDisc = function (ring, rx, ry, R) {
        var k = F.fitFactor(ring, rx, ry, R), i, out;
        if (k >= 0.9999) return ring;
        out = new Array(ring.length);
        for (i = 0; i < ring.length; i++) {
            out[i] = { x: rx + (ring[i].x - rx) * k, y: ry + (ring[i].y - ry) * k };
        }
        return out;
    };

    /** A closed circular ring. */
    function disc(cx, cy, r, n) {
        var out = [], i, a;
        for (i = 0; i < n; i++) {
            a = (i / n) * Math.PI * 2;
            out.push({ x: cx + Math.cos(a) * r, y: cy + Math.sin(a) * r });
        }
        return out;
    }
    F.disc = disc;

    /**
     * Greatest distance from the origin reached by the body AND its form-intrinsic extras.
     * ⛔ This, not F.extent, is what the shared disc budget must be measured against — an `extra`
     * is part of the silhouette, so a ray's whip and a fan's span spend the same budget a fin does.
     */
    F.extentWithExtras = function (prof, opts) {
        var m = F.extent(prof), ex = F.extra(prof, opts), i, j, p, d;
        for (i = 0; i < ex.length; i++) {
            for (j = 0; j < ex[i].ring.length; j++) {
                p = ex[i].ring[j];
                d = Math.sqrt(p.x * p.x + p.y * p.y);
                if (d > m) m = d;
            }
        }
        return m;
    };

})(CreelForms);

if (typeof module !== 'undefined' && module.exports) module.exports = CreelForms;
