/*:
 * @target MZ
 * @plugindesc [Creel] Palette corpus and role resolution — 12 liveries. Library file; no parameters.
 * @author Core Systems Asset Factory
 *
 * @help
 * CreelLivery.js
 *
 * The fourth axis, and the one that must NOT be doing the work. Body plan x fin set x pattern give
 * the silhouette and the marks; a livery only says what colour they are.
 *
 * ⛔ A PALETTE IS NOT A COMPOSITION. If two species are told apart only by their colours, the
 * corpus is one fish recoloured — which is this product's stated kill condition. That is why every
 * distinctness measurement in this project holds the palette FIXED, and why this file is the last
 * one written rather than the first.
 *
 * ⛔ AND NO INK IS EVER HARD-CODED. A colour is chosen by LUMINANCE against what it actually sits
 * on. A mark drawn in a colour picked independently of its ground is invisible on some member of
 * the corpus, and nothing mechanical can see it: the shape is drawn, sized, placed and its colour
 * parses. Only opening the picture finds it, and only on the palette you happened to render.
 *
 * Load order does not matter. Siblings are resolved at FIRST USE.
 */

var CreelLivery = CreelLivery || {};

(function (L) {
    'use strict';

    function forms() {
        var F = (typeof CreelForms !== 'undefined') ? CreelForms : null;
        if (!F) throw new Error('Creel: CreelForms.js is not loaded.');
        return F;
    }

    // =============================================================================================
    // COLOUR
    // =============================================================================================

    /** Relative luminance 0-255, the weighted average the eye actually reads. */
    L.lum = function (c) { return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; };

    function clamp255(v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }

    L.css = function (c) {
        return 'rgb(' + Math.round(clamp255(c[0])) + ',' + Math.round(clamp255(c[1]))
             + ',' + Math.round(clamp255(c[2])) + ')';
    };

    /** Mix two colours by t. */
    L.mix = function (a, b, t) {
        return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
    };

    /**
     * Move a colour toward white or black by EXACTLY enough to shift its luminance by `minDelta`.
     *
     * ⛔ A MULTIPLIER IS A HARD-CODED CONTRAST RATIO, AND IT FAILS AT BOTH ENDS. `shade(c, 1.22)`
     * moves a bright colour 27 luminance levels and a dark one 11, so the same call that gives a
     * pale fish a clear relief leaves a dark one with none at all. Any tint whose job is to make
     * something VISIBLE has to state its separation in ABSOLUTE terms and solve for it.
     *
     * ⚠️ AND THE HONEST BOUND IS `min(want, headroom)`. There is nothing brighter than white: a
     * near-white body has only a few levels above it, so demanding a fixed delta there is a false
     * red, not a defect. Return all the separation that exists and let the caller assert that.
     */
    L.relief = function (c, dir, minDelta) {
        var target = dir > 0 ? [255, 255, 255] : [0, 0, 0];
        var l0 = L.lum(c), lt = dir > 0 ? 255 : 0;
        var head = Math.abs(lt - l0);
        if (head < 0.001) return c.slice();
        var want = Math.min(minDelta, head);
        // A proportional term as a FLOOR, so bright bases still get a generous, natural relief.
        var t = Math.max(want / head, 0.06);
        return L.mix(c, target, Math.min(t, 1));
    };

    /**
     * Pick whichever candidate reads best against `bg`.
     * ⛔ Never "the palette's dark colour" — on a dark livery that is dark-on-dark and every mark
     * in the species vanishes.
     */
    L.pickContrast = function (bg, candidates) {
        var lb = L.lum(bg), best = candidates[0], bestD = -1, i, d;
        for (i = 0; i < candidates.length; i++) {
            d = Math.abs(L.lum(candidates[i]) - lb);
            if (d > bestD) { bestD = d; best = candidates[i]; }
        }
        return best;
    };

    /** The separation `pickContrast` actually achieved — so a caller can assert it, not assume it. */
    L.contrastOf = function (bg, fg) { return Math.abs(L.lum(fg) - L.lum(bg)); };

    // =============================================================================================
    // THE TWELVE LIVERIES
    //
    //   back    the dorsal colour, at the top of the counter-shading ramp
    //   belly   the ventral colour — a fish is dark above and pale below, always, because that is
    //           what counter-shading IS and it is the single strongest "this is a fish" cue
    //   mark    the pattern ink, as a PREFERENCE; the resolver may reject it (see markFor)
    //   fin     fin membrane
    //   accent  a second mark colour, for the parts that need two (an ocellus has three rings)
    // =============================================================================================

    var LIV = {
        trout:     { back: [82, 96, 62],  belly: [226, 214, 186], mark: [38, 42, 30],  fin: [120, 122, 88],  accent: [196, 84, 56],  reads: 'olive back, cream belly, dark speckling' },
        char:      { back: [46, 62, 84],  belly: [232, 176, 128], mark: [222, 232, 240], fin: [92, 104, 122], accent: [214, 96, 62],  reads: 'blue-black back over an orange belly' },
        perch:     { back: [78, 84, 40],  belly: [216, 204, 150], mark: [34, 36, 22],  fin: [186, 96, 46],   accent: [208, 132, 52], reads: 'banded olive with red fins' },
        koi:       { back: [236, 238, 234], belly: [248, 248, 244], mark: [206, 78, 40], fin: [232, 224, 214], accent: [30, 28, 26],  reads: 'white ground with red and black' },
        abyssal:   { back: [26, 28, 36],  belly: [44, 46, 58],    mark: [96, 108, 130], fin: [34, 36, 46],   accent: [128, 214, 198], reads: 'near-black with a cold glimmer' },
        reef:      { back: [214, 132, 32], belly: [244, 226, 176], mark: [40, 34, 40],  fin: [232, 176, 56],  accent: [60, 130, 178], reads: 'hot orange with hard dark marks' },
        silver:    { back: [126, 138, 148], belly: [238, 240, 242], mark: [78, 88, 98],  fin: [158, 168, 178], accent: [44, 52, 60],  reads: 'plain bright silver, faintly marked' },
        pike:      { back: [72, 84, 52],  belly: [206, 202, 170], mark: [186, 196, 150], fin: [104, 112, 74], accent: [58, 62, 40],  reads: 'weedy green with pale flank marks' },
        carp:      { back: [118, 96, 54], belly: [206, 186, 138], mark: [70, 56, 32],   fin: [138, 116, 74], accent: [92, 74, 44],   reads: 'bronze, low contrast' },
        tropical:  { back: [42, 96, 150], belly: [236, 232, 128], mark: [22, 30, 46],   fin: [232, 208, 88], accent: [232, 96, 120], reads: 'blue and yellow, high contrast' },
        albino:    { back: [242, 232, 228], belly: [252, 248, 246], mark: [216, 176, 172], fin: [246, 236, 232], accent: [198, 96, 96], reads: 'near-white throughout' },
        ember:     { back: [92, 34, 30],  belly: [214, 134, 72],  mark: [30, 18, 16],   fin: [166, 66, 38],  accent: [244, 196, 96], reads: 'deep red over a hot belly' }
    };

    L.IDS = ['trout', 'char', 'perch', 'koi', 'abyssal', 'reef',
             'silver', 'pike', 'carp', 'tropical', 'albino', 'ember'];

    L.liv = function (id) {
        return Object.prototype.hasOwnProperty.call(LIV, id) ? LIV[id] : undefined;
    };
    L.name = function (id) {
        return Object.prototype.hasOwnProperty.call(LIV, id)
            ? id.charAt(0).toUpperCase() + id.slice(1) : '?';
    };
    L.reads = function (id) {
        var v = L.liv(id);
        return v ? v.reads : '';
    };

    // =============================================================================================
    // COUNTER-SHADING
    //
    // A fish is dark above and pale below. It is the strongest single cue that a shape is a fish
    // rather than a leaf, and it costs one gradient.
    // =============================================================================================

    // ⛔⛔ THE RAMP IS SOLVED, NOT TYPED — AND THE TWELVE PALETTES ABOVE WERE THE ONE PLACE IN THIS
    // PRODUCT THAT TYPED A SEPARATION INSTEAD OF SOLVING FOR ONE.
    //
    // This file's own header says no ink is ever hard-coded and that a colour is chosen by
    // luminance against what it sits on. `markFor`, `pickContrast` and `relief` all obey that. The
    // BODY did not: `back` and `belly` were authored as literals, so a livery could be written with
    // no counter-shading at all — and counter-shading is, by this product's own account, the single
    // strongest cue that a shape is a fish rather than a leaf.
    //
    // MEASURED 2026-09-03, `Internal_Ops/_probe/visibility.js` — 432 form x livery x ground
    // renders, pixels read back, over three grounds (a cream store plate, pure white, a dark MZ
    // window). "Ghost" = more than 60% of the specimen's own pixels within 14 luminance of the
    // ground it is drawn on:
    //
    //     koi      ramp  10.4   ->   9 ghosts, all on pale ground
    //     albino   ramp  14.9   ->  11 ghosts, all on pale ground
    //     abyssal  ramp  18.3   ->  11 ghosts, all on the dark window
    //     ------------------------- the measured gap, 4.6x wide -------------------------
    //     reef     ramp  84.0   ->  0        carp 89.1, ember 100.5, silver 103.5, pike 121.4,
    //     ...                                perch 123.1, trout 124.0, char 124.3, tropical 136.9
    //                                        -> 0 ghosts, every one
    //
    // The split is PERFECT in both directions: every livery under 20 ghosts, every livery over 84
    // does not, no exceptions on either side. That is why MIN_RAMP is placed inside that gap rather
    // than chosen — wing §12b-1 and §22b-2: compute the statistic on a known-good and a known-bad
    // input and put the threshold between them. A number I liked would have been an invented
    // threshold, and those manufacture false reds exactly as readily as they hide true ones.
    //
    // ⚠️ THIS IS NOT "MAKE THE PALE FISH DARKER UNTIL THE NUMBER PASSES" (wing §14a's trap). A real
    // white koi and a real albino trout both show a shaded back in any light; what was missing was
    // the shading, not the whiteness. The belly keeps its authored colour wherever it can.
    L.MIN_RAMP = 52;

    /**
     * The back and belly colours a livery actually renders with, after the counter-shading ramp
     * has been solved to `L.MIN_RAMP`.
     *
     * ⛔ ONE DECLARATION, TWO READERS. `bodyAt` is the only caller, and nothing else may compute a
     * back or a belly of its own — a second copy of a derived value does not drift, it WINS, and it
     * presents as a stale build (wing §11a).
     *
     * @returns {{back:Array<number>, belly:Array<number>, ramp:number, want:number}}
     */
    L.ramp = function (liv) {
        var lb = L.lum(liv.back), lp = L.lum(liv.belly);
        var have = Math.abs(lp - lb);
        if (have >= L.MIN_RAMP) {
            return { back: liv.back, belly: liv.belly, ramp: have, want: L.MIN_RAMP };
        }
        // ⛔ AND THE HONEST BOUND IS `min(want, headroom)`. There is nothing darker than black and
        // nothing brighter than white, so a near-black livery simply cannot deliver a full ramp by
        // darkening — demanding one there is arithmetic, not a defect (§22e-1, measured twice in
        // this factory on `[0,0,0]` and again on diamond at luminance 244.9).
        var downRoom = lb;              // how far the BACK can still darken
        var upRoom = 255 - lp;          // how far the BELLY can still lighten
        var need = L.MIN_RAMP - have;
        var total = downRoom + upRoom;
        // Split the need in proportion to the headroom each end actually has. Spending it all on
        // one end first would drive `abyssal`'s back to pure black — losing the cold blue that IS
        // that livery — when its belly has 209 levels of room going the other way, which is also
        // what a real deep-water fish's counter-illumination looks like.
        var down = total > 0.001 ? Math.min(need * downRoom / total, downRoom) : 0;
        var up = total > 0.001 ? Math.min(need * upRoom / total, upRoom) : 0;
        var back = down > 0.25 ? L.relief(liv.back, -1, down) : liv.back;
        var belly = up > 0.25 ? L.relief(liv.belly, +1, up) : liv.belly;
        return {
            back: back, belly: belly,
            ramp: Math.abs(L.lum(belly) - L.lum(back)), want: L.MIN_RAMP
        };
    };

    /**
     * The body colour at a given depth fraction (0 = the back, 1 = the belly).
     * ⚠️ Non-linear on purpose: the transition sits low on the flank, as it does on a real fish.
     * A linear ramp reads as a cylinder lit from above, which is a different animal.
     */
    L.bodyAt = function (liv, f) {
        var t = Math.pow(Math.min(Math.max(f, 0), 1), 1.45);
        var r = L.ramp(liv);
        return L.mix(r.back, r.belly, t);
    };

    /**
     * The ink for a pattern mark, GUARANTEED to be readable against the body it lands on.
     *
     * ⛔ THE LIVERY'S DECLARED `mark` IS A PREFERENCE, NOT AN ANSWER. On `koi` the preferred mark
     * is a red that sits close in luminance to the white ground; on `abyssal` the body is already
     * near-black. A mark whose colour is chosen without asking what it sits on is invisible
     * somewhere in a twelve-palette corpus, always — so the preference is taken only when it
     * clears the floor, and otherwise the best available candidate wins.
     *
     * @param {number} minSep  the luminance separation a mark must achieve.
     */
    L.markFor = function (liv, ground, minSep) {
        var want = (minSep === undefined) ? 42 : minSep;
        if (L.contrastOf(ground, liv.mark) >= want) return liv.mark;
        return L.pickContrast(ground, [
            liv.mark, liv.accent,
            L.relief(ground, -1, want), L.relief(ground, +1, want)
        ]);
    };

    /**
     * Resolve a part ROLE to a colour. Geometry never knows about colour; this is the only place
     * the two meet, which is what lets one form appear in twelve liveries without any outline
     * changing.
     */
    L.roleColour = function (liv, role, ground) {
        var F = forms();
        switch (role) {
            case F.ROLE.BODY:  return ground;
            case F.ROLE.BELLY: return liv.belly;
            case F.ROLE.FIN:   return liv.fin;
            case F.ROLE.MARK:  return L.markFor(liv, ground);
            case F.ROLE.EYE:   return L.pickContrast(ground, [[16, 14, 12], [244, 242, 238]]);
            case F.ROLE.EDGE:  return L.relief(ground, -1, 30);
            default:           return ground;
        }
    };

})(CreelLivery);

if (typeof module !== 'undefined' && module.exports) module.exports = CreelLivery;
