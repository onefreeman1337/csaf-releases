/*:
 * @target MZ
 * @plugindesc [Creel] Pattern corpus — 10 markings, clipped to the body in geometry. Library file; no parameters.
 * @author Core Systems Asset Factory
 *
 * @help
 * CreelPattern.js
 *
 * The third axis. 12 body plans x 8 fin sets x 10 patterns, and the pattern layer changes
 * NOT ONE OUTLINE — that separation is what lets the catalogue be large without becoming mush.
 *
 * ⛔ EVERY PATTERN ELEMENT IS CLIPPED IN GEOMETRY, NOT PAINTED AND MASKED. `ctx.clip()` exists and
 * is the obvious move; it is the wrong one here. A save/clip/restore per element is state-thrash on
 * a path this product draws hundreds of times, a clipped element is still DRAWN, and one that is
 * never emitted costs nothing. `CreelForms.span()` answers "where does the body start and stop at
 * this x" in two array lookups and a lerp, which is cheaper than the clip and also tells a spot how
 * big it is allowed to be.
 *
 * ⚠️ span() returns the EDGES, not a half-depth about zero. On `hatchet` those differ by a factor
 * of four, and a caller that assumes symmetry puts every stripe outside the fish.
 *
 * ⛔ DENSITY IS DERIVED FROM THE DRAWN SIZE, NEVER TYPED. A count that is right on a 300px plate is
 * a grey smear on a 96px specimen. Every pattern declares a PITCH in pixels and derives its count
 * from the real run, so a feature that cannot resolve at the size a specimen is actually seen at
 * simply emits fewer marks instead of mush.
 *
 * Load order does not matter. Siblings are resolved at FIRST USE.
 */

var CreelPattern = CreelPattern || {};

(function (P) {
    'use strict';

    function forms() {
        var F = (typeof CreelForms !== 'undefined') ? CreelForms : null;
        if (!F) throw new Error('Creel: CreelForms.js is not loaded.');
        return F;
    }

    P.IDS = ['plain', 'bars', 'stripes', 'spots', 'speckle',
             'mottle', 'saddle', 'ocelli', 'chevron', 'net'];

    // =============================================================================================
    // THE DETERMINISTIC SEAM
    //
    // ⛔ NEVER Math.random(). A species must draw byte-identically every time, or a save/load, a
    // re-bake and a store capture all disagree.
    //
    // ⛔ AND THE WARM-UP HAPPENS AT SEEDING, NOT AT THE CALL SITE. A generator's first draw is very
    // nearly a straight line in the seed for any run of NEARBY seeds — and nearby seeds are exactly
    // what a caller iterating `base + index` produces. The GameMaker wing measured a rare event
    // that should fire 30% of the time firing 0 times in 440 trials for this reason. Discarding
    // here means no future caller can pay for it again.
    // =============================================================================================

    /**
     * @param {number} seed
     * @returns {function(): number} uniform in [0,1)
     */
    P.rng = function (seed) {
        var s = (seed >>> 0) || 1;
        var f = function () {
            s |= 0; s = (s + 0x6D2B79F5) | 0;
            var t = Math.imul(s ^ (s >>> 15), 1 | s);
            t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
            return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
        };
        for (var i = 0; i < 8; i++) f();      // warm up HERE, once, for every caller
        return f;
    };

    // =============================================================================================
    // GEOMETRIC CLIPPING
    // =============================================================================================

    /**
     * How much room a mark centred at (x, y) has before it leaves the body.
     * @returns {number} 0 when the point is outside the body at all.
     */
    function room(F, prof, x, y) {
        var s = F.span(prof, x);
        if (!s) return 0;
        if (y <= s.top || y >= s.bot) return 0;
        return Math.min(y - s.top, s.bot - y);
    }
    P.room = room;

    /** A band across the body between two axial positions, following BOTH edges. */
    function band(F, prof, x0, x1, tFrac, bFrac, n) {
        var top = [], bot = [], i, t, x, s;
        for (i = 0; i <= n; i++) {
            t = i / n;
            x = x0 + (x1 - x0) * t;
            s = F.span(prof, x);
            if (!s) continue;
            var d = s.bot - s.top;
            top.push({ x: x, y: s.top + d * tFrac });
            bot.push({ x: x, y: s.top + d * bFrac });
        }
        if (top.length < 2) return null;
        bot.reverse();
        return top.concat(bot);
    }

    /**
     * A disc that never leaves the body.
     *
     * ⛔ A MARK OCCUPIES A RANGE OF X, SO IT MUST FIT AT ALL OF THEM. Capping the radius by the
     * room at the mark's CENTRE is correct there and wrong at its left and right extremes, because
     * a fish narrows toward both ends — MEASURED, 53 points escaped the body that way, all of them
     * spots on the shoulder or near the snout where the body is closing fastest. Sample the room
     * across the mark's own footprint and take the tightest.
     */
    function fittedDisc(F, prof, x, y, r) {
        var rr = Math.min(r, room(F, prof, x, y) * 0.92);
        if (rr < 0.006) return null;               // below this it is not a mark, it is noise
        // Two iterations: the first shrink changes the footprint, so the room at the NEW extremes
        // has to be asked again. It converges immediately because shrinking only ever helps.
        var pass, k, avail;
        for (pass = 0; pass < 2; pass++) {
            for (k = -1; k <= 1; k++) {
                avail = room(F, prof, x + rr * k, y);
                if (avail <= 0) return null;
                if (avail * 0.92 < rr) rr = avail * 0.92;
            }
        }
        if (rr < 0.006) return null;
        return F.disc(x, y, rr, 14);
    }

    /**
     * The body's span over a WHOLE x-footprint, not at a point.
     *
     * EXACT rather than sampled: an envelope is piecewise linear, so the maximum of `top` and the
     * minimum of `bot` over an interval can only occur at an endpoint or at a VERTEX. Sampling at
     * a fixed stride steps over vertices and reports a window wider than the truth, which is the
     * permissive direction — so the vertices inside the interval are enumerated explicitly.
     *
     * @returns {?{top:number, bot:number}} null when the footprint leaves the body altogether.
     */
    function spanWindow(F, prof, xa, xb) {
        var top = -Infinity, bot = Infinity, i, s, xs = [xa, xb];
        for (i = 0; i <= prof.n; i++) {
            if (prof.x[i] > xa && prof.x[i] < xb) xs.push(prof.x[i]);
        }
        for (i = 0; i < xs.length; i++) {
            s = F.span(prof, xs[i]);
            if (!s) return null;
            if (s.top > top) top = s.top;
            if (s.bot < bot) bot = s.bot;
        }
        return (bot > top) ? { top: top, bot: bot } : null;
    }
    P.spanWindow = spanWindow;

    /**
     * Solve a mark's RADIUS and its Y TOGETHER, inside the window its own footprint can see.
     *
     * ⛔⛔ THE FOURTH INSTANCE IN THIS FILE OF "A MARK OCCUPIES A RANGE OF X SO IT MUST FIT AT ALL
     * OF THEM", and the first where obeying it half way DELETED a whole pattern from a third of the
     * corpus. `mottle` took its y from the span at its own SPINE and then demanded that y still be
     * inside the body a radius to either side. On a form whose two envelopes are independent — the
     * premise of this corpus (ARCHITECTURE §3) — the body MOVES vertically as x changes, so a y
     * comfortably inside at the centre is outside a sixth of a body away.
     *
     * MEASURED 2026-09-03, `_probe/visibility.js`, pixels read back off the shipped renderer:
     * `hatchet/mottle/*` emitted **0 marks on all 12 liveries** and rendered silently plain, and
     * `fan/mottle/*` emitted 2 — 48 of 1296 cells under the 2% repaint floor, every one of them
     * mottle, on eel / fan / pike / hatchet.
     *
     * ⚠️ THE PREVIOUS REPAIR WAS AIMED AT THE RADIUS AND COULD NOT HAVE WORKED. It halved the
     * radius up to five times and kept y fixed; five halvings of 0.1161 is 0.0036, which is under
     * this function's own noise floor, so the mark was dropped by the guard instead of by the
     * clamp — the same outcome through a different door. **Shrinking a mark cannot fix a mark that
     * is in the wrong PLACE**, and no number of passes changes that.
     *
     * So both unknowns are solved at once: shrink toward what the window allows, and MOVE the
     * centre inboard far enough for the radius to fit. Convergence is monotone — a smaller radius
     * means a narrower footprint, which means a WIDER window and a smaller requirement — so this
     * terminates on the noise floor rather than on the pass budget.
     *
     * @param {number} yf  wanted vertical position as a fraction of the local depth. Honoured
     *                     inside the legal window, so the caller's jitter survives relocation.
     * @param {number} ex  half-footprint in x as a multiple of r (1 for a disc, >1 for an ellipse).
     * @returns {?{x:number, y:number, r:number}} null only when nothing of readable size fits.
     */
    // `mottle` geometry, declared once because two places read it (the solver's footprint and the
    // ring it finally emits) and wing §11a records what a second copy of a constant does: it does
    // not drift, it WINS, and a correct edit to one copy then changes nothing.
    var MOT_WIDE = 1.25;      // a blotch is this much wider than it is deep
    var MOT_WOBBLE = 1.16;    // the largest multiple of the nominal radius its wobble reaches

    function placedMark(F, prof, x, yf, r, ex, guard) {
        var g = (guard === undefined) ? 0.92 : guard;
        var pass, half, w, avail, y, lo, hi;
        for (pass = 0; pass < 24 && r >= 0.008; pass++) {
            half = r * ex;
            w = spanWindow(F, prof, x - half, x + half);
            if (!w) { r *= 0.5; continue; }          // footprint left the body: shrink and re-ask
            avail = (w.bot - w.top) * 0.5 * g;       // the deepest mark this window can hold at all
            if (avail < r) { r = avail; continue; }
            y = w.top + (w.bot - w.top) * yf;
            lo = w.top + r / g;
            hi = w.bot - r / g;
            if (y < lo) y = lo;
            if (y > hi) y = hi;
            return { x: x, y: y, r: r };
        }
        return null;
    }
    P.placedMark = placedMark;

    // =============================================================================================
    // THE TEN PATTERNS
    //
    //   pitchPx   the SPACING the marks want, in PIXELS of the finished drawing. The count is
    //             derived from the real run at the real scale — declaring a count instead is what
    //             makes a treatment read as beading on a plate and as specks on a thumbnail.
    //   reads     the acceptance criterion, printed on the contact sheet beside the specimen.
    // =============================================================================================

    // ⛔ `countMode` EXISTS BECAUSE A CHECK CAUGHT ME ASSUMING ONE ANSWER FITS BOTH KINDS.
    //
    // The probe requires every size-derived count to MOVE between 96px and 320px, and `saddle` and
    // `ocelli` did not move on 23 of 108 pairs. The obvious reading is that their derivation is
    // dead — and the obvious fix, lowering their floors until the number moves, would have been
    // WRONG, because their counts are not a resolution property at all.
    //
    // A fish has about five saddles and one to three eye-spots whether you draw it at 96 pixels or
    // at 320. That is anatomy, not level of detail. What the drawn size legitimately decides for
    // these is whether the marks RESOLVE — below the pitch floor they are dropped, not multiplied.
    //
    //   'resolution' — count derives from the drawn size (freckles, stripes, mesh).
    //   'biological' — count derives from the BODY, in unit space; size only gates whether the
    //                  marks are drawn at all. The probe asserts the count is STABLE across sizes
    //                  and that the resolution gate exists, which is a real claim rather than an
    //                  exemption.
    var PAT = {
        plain:   { pitchPx: 0,  mode: 'resolution', reads: 'no markings — counter-shading alone' },
        bars:    { pitchPx: 15, mode: 'resolution', reads: 'upright bars crossing the whole flank' },
        stripes: { pitchPx: 11, mode: 'resolution', reads: 'lengthways stripes following the body' },
        spots:   { pitchPx: 19, mode: 'resolution', reads: 'round spots on an even scatter' },
        speckle: { pitchPx: 8,  mode: 'resolution', reads: 'fine dense freckling' },
        // ⚠️ `reads` is the acceptance criterion, so it has to describe what separates this pattern
        // from its neighbours. "Irregular soft blotches" was true of a picture that was also true
        // of `spots`; what makes mottling mottling is that the blotches RUN TOGETHER.
        mottle:  { pitchPx: 26, mode: 'resolution',
                   reads: 'irregular blotches running together into marbling' },
        net:     { pitchPx: 14, mode: 'resolution', reads: 'a reticulated net over the flank' },
        chevron: { pitchPx: 17, mode: 'resolution', reads: 'nested V marks pointing forward' },
        saddle:  { pitchPx: 34, mode: 'biological', perUnit: 7.2, minPx: 13,
                   reads: 'heavy saddles over the back only' },
        ocelli:  { pitchPx: 30, mode: 'biological', perUnit: 3.1, minPx: 22,
                   reads: 'few large ringed eye-spots' }
    };

    P.pat = function (id) {
        return Object.prototype.hasOwnProperty.call(PAT, id) ? PAT[id] : undefined;
    };
    P.name = function (id) {
        return Object.prototype.hasOwnProperty.call(PAT, id)
            ? id.charAt(0).toUpperCase() + id.slice(1) : '?';
    };
    P.reads = function (id) {
        var p = P.pat(id);
        return p ? p.reads : '';
    };

    /**
     * Pattern rings for one species, already clipped to the body.
     *
     * @param {object} prof   a CreelForms profile
     * @param {string} id     pattern id
     * @param {number} scale  PIXELS per unit-box unit — the drawn size. Density derives from this.
     * @param {number} seed   deterministic seed
     * @returns {Array<{id:string, role:string, ring:Array}>} empty for `plain` or an unknown id.
     */
    P.parts = function (prof, id, scale, seed) {
        var F = forms(), p = P.pat(id), out = [];
        if (!p || id === 'plain' || !prof) return out;

        var rnd = P.rng(seed || 1);
        var L = F.length(prof);
        var x0 = prof.x[0], x1 = prof.x[prof.n];
        // ⛔ THE COUNT IS DERIVED. `pitchPx / scale` converts the wanted spacing into unit-box
        // units at the size this specimen is actually being drawn at.
        var pitch = p.pitchPx / Math.max(scale, 1);
        var n = Math.max(2, Math.round(L / pitch));
        var i, j, t, x, s, y, r;

        if (id === 'bars') {
            // Upright bars. They stop short of the belly so the counter-shading still reads —
            // a bar taken edge to edge turns the fish into a barcode.
            for (i = 0; i < n; i++) {
                t = (i + 0.5) / n;
                x = x0 + L * t;
                var w = pitch * (0.30 + 0.16 * rnd());
                var g = band(F, prof, x - w, x + w, 0.02, 0.72 + 0.18 * rnd(), 6);
                if (g) out.push({ id: 'bar', role: F.ROLE.MARK, ring: g });
            }
        } else if (id === 'stripes') {
            // Lengthways bands at constant FRACTIONS of the local depth, so they follow the body's
            // own curvature instead of running straight through it.
            var rows = Math.max(2, Math.round((F.depth(prof) / pitch)));
            for (i = 0; i < rows; i++) {
                var f0 = 0.08 + (0.84 / rows) * i;
                var f1 = f0 + (0.84 / rows) * 0.52;
                var gg = band(F, prof, x0 + L * 0.04, x0 + L * 0.94, f0, f1, 22);
                if (gg) out.push({ id: 'stripe', role: F.ROLE.MARK, ring: gg });
            }
        } else if (id === 'spots' || id === 'speckle') {
            r = (id === 'speckle') ? pitch * 0.20 : pitch * 0.30;
            var rowsN = Math.max(2, Math.round(F.depth(prof) / pitch));
            for (i = 0; i < n; i++) {
                for (j = 0; j < rowsN; j++) {
                    x = x0 + L * ((i + 0.5 + (rnd() - 0.5) * 0.55) / n);
                    s = F.span(prof, x);
                    if (!s) continue;
                    y = s.top + (s.bot - s.top) * ((j + 0.5 + (rnd() - 0.5) * 0.5) / rowsN);
                    var d1 = fittedDisc(F, prof, x, y, r * (0.7 + 0.6 * rnd()));
                    if (d1) out.push({ id: 'spot', role: F.ROLE.MARK, ring: d1 });
                }
            }
        } else if (id === 'mottle') {
            // ⛔⛔ A COUNT DERIVED FROM LENGTH ALONE CANNOT COVER A FLANK, AND EVERY CHECK IN THIS
            // PROJECT PASSED OVER IT FOR A DAY.
            //
            // `mottle` used to share the `saddle` branch and take its count from the body's LENGTH
            // (`n = L / pitch`), while the marks it emits cover an AREA. On any form that is short
            // or shallow that arithmetic yields ONE blotch.
            //
            // MEASURED 2026-09-03, `Internal_Ops/_probe/visibility.js` — the shipped renderer run
            // and the PIXELS READ BACK, 1296 cells, against the same fish drawn `plain`:
            //
            //     mottle   median repaint  4.70%   min 0.39%   60 of 144 cells under 2%
            //     ...      corpus median  19.66%
            //     bars     median repaint 45.74%
            //
            //     eel/mottle/*      0.39-0.52%   marks emitted: 1
            //     ray/mottle/*      0.63-0.71%   marks emitted: 1
            //     and the same on disc, flathead and spindle — 5 of 12 forms, all 12 liveries.
            //
            // ⛔ EVERY EXISTING CHECK WAS GREEN, and each was honest about its own question:
            // `patterns.js` check 4 asked whether `parts()` returned a non-empty array (it did —
            // one element), check 1 asked whether the count moved with the drawn size (it did),
            // check 3 asked whether the marks were inside the body (they were). Three true
            // statements about an ARRAY. Wing §17c-1: an op counter proves a call happened, never
            // that a pixel changed; §22a-2e: a value, a test and a caption are three statements
            // about a table, and none of them is a mark on a bitmap.
            //
            // ⚠️ AND THE OBVIOUS FIX IS THE WRONG ONE. Making the single blotch huge and dark until
            // the repaint number clears is wing §14a's trap committed against markings: it obeys
            // the symptom and makes the picture worse. Mottling is a FIELD, not a row — so the
            // count derives from BOTH dimensions the mark covers, exactly as `spots` and `speckle`
            // already do.
            //
            // What keeps it from becoming `spots`: blotches are spaced CLOSER than their own
            // diameter, so they run together into marbling instead of reading as dots. That is
            // §22b-1's law — spacing-to-size is a design variable, not a rendering detail — and it
            // is the whole difference between the two patterns.
            var mRows = Math.max(1, Math.round(F.depth(prof) / pitch));
            var mCols = Math.max(2, n);
            for (i = 0; i < mCols; i++) {
                for (j = 0; j < mRows; j++) {
                    // Jitter is large relative to the cell so the field reads as irregular rather
                    // than as a lattice — a regular grid of blobs is a printed textile, not an
                    // animal.
                    x = x0 + L * (0.10 + 0.80 * ((i + 0.5 + (rnd() - 0.5) * 0.80) / mCols));
                    // ⚠️ Rows stop short of the very edge. A centre ON the contour has no room in
                    // either direction, so a mark placed there can only ever be dropped. This is a
                    // FRACTION now, resolved against the legal window rather than against the span
                    // at the spine — see `placedMark`.
                    var myf = Math.min(0.86, Math.max(0.14,
                        (j + 0.5 + (rnd() - 0.5) * 0.80) / mRows));
                    // OVERLAP IS THE POINT: 0.62 of the pitch against `spots`' 0.30 means adjacent
                    // blotches touch and merge. Their radius is bounded by every dimension of the
                    // thing they sit on, not just the one the spacing runs along.
                    var mr = pitch * 0.62 * (0.72 + 0.56 * rnd());
                    mr = Math.min(mr, F.depth(prof) * 0.40);
                    var mEnd = Math.min(x - prof.x[0], prof.x[prof.n] - x) / (1.25 * 1.14);
                    if (mEnd < mr) mr = mEnd;
                    // ⛔⛔ A BLOTCH THAT DOES NOT FIT IS SMALLER, NEVER ABSENT — AND SAYING SO IN A
                    // COMMENT IS NOT THE SAME AS DOING IT. THIS BRANCH SAID IT AND DID NOT DO IT.
                    //
                    // MEASURED, `_probe/mottle_why.js`, `hatchet` at 120px — printed rather than
                    // reasoned about, after two repairs aimed from guesses:
                    //
                    //   candidate 0   x=-0.0088  y=0.1089   span at x [-0.0426, 0.1790]
                    //     r wanted 0.1161 -> after probes 0.0000   KILLED BY probe k=-1
                    //     k=-1  x=-0.1742  span=[-0.0360, 0.0520]  y inside? NO
                    //
                    // The mark's y is comfortably inside the body at its own x and OUTSIDE it a
                    // sixth of the body away, because `hatchet`'s two envelopes are independent and
                    // the whole body MOVES vertically as x changes. Wing §11b: a constant in a
                    // figure's coordinate space is an assumption about its pose, and this one
                    // assumed a flat fish.
                    //
                    // ⚠️ The previous "fix" — dropping the `break` so the loop took a minimum
                    // instead of zeroing — produced BYTE-IDENTICAL output, because `mav <= 0` and
                    // `mr = 0` both fall through to the same `continue`. A repair that cannot
                    // change the result is the no-op break test of wing §12b, committed against
                    // the product instead of against a check.
                    //
                    // The real answer is a solve, not a clamp: an over-large radius reaches into a
                    // part of the fish that has nothing to do with where the mark sits, so HALVE it
                    // and ask again. It converges immediately (shrinking only ever helps) and it
                    // is the honest picture too — mottling really is finer where the flank is
                    // shallower.
                    // A blotch is an ELLIPSE `MOT_WIDE` wide by 1 deep whose wobble reaches
                    // `MOT_WOBBLE` of the nominal radius at its worst, so its true half-footprint
                    // in x is r*MOT_WIDE*MOT_WOBBLE and its true half-depth is r*MOT_WOBBLE. Both
                    // factors are handed to the SOLVER rather than applied to its answer
                    // afterwards, because a budget bounds where a part may REACH, and a reach
                    // measured from an already-displaced root is not bounded at all (wing
                    // evidence, `sharedBudgetDisc`).
                    // ⚠️ ONE CONSTANT, TWO READERS (wing §11a: a second copy does not drift, it
                    // wins). The previous code bounded the room by 1.14 and then drew the ring at
                    // up to 0.70+0.46 = 1.16, so every blotch was allowed to exceed its own
                    // solved budget by 1.7%.
                    var mFit = placedMark(F, prof, x, myf, mr * MOT_WOBBLE, MOT_WIDE, 0.92);
                    if (!mFit) continue;           // genuinely sub-pixel: noise, not a mark
                    var mring = [], MK = 16, ma;
                    for (var mq = 0; mq < MK; mq++) {
                        ma = (mq / MK) * Math.PI * 2;
                        var mrr = (mFit.r / MOT_WOBBLE) * (MOT_WOBBLE - 0.46 + 0.46 * rnd());
                        mring.push({
                            x: mFit.x + Math.cos(ma) * mrr * MOT_WIDE,
                            y: mFit.y + Math.sin(ma) * mrr
                        });
                    }
                    out.push({ id: 'mottle', role: F.ROLE.MARK, ring: mring });
                }
            }
        } else if (id === 'saddle') {
            // Blotches over the BACK only — that is what makes a saddle a saddle rather than a
            // blotch, and it is why it needs its own id at all.
            // BIOLOGICAL: a fish has about five saddles whether you draw it at 96px or at 320, so
            // the count comes from the body and the drawn size only decides whether the marks
            // resolve at all (see `countMode`).
            var cnt;
            if (p.minPx && (L * scale) / (L * p.perUnit) < p.minPx) return out;  // cannot resolve
            cnt = Math.max(2, Math.round(L * p.perUnit));
            for (i = 0; i < cnt; i++) {
                // ⛔ SADDLES SIT ON THE FLANK, NOT ON THE PEDUNCLE. Spread across the FULL length,
                // a two-mark saddle on a short body centres its first mark a quarter along and its
                // footprint reaches the TAIL TIP, where the depth is zero — so the mark was
                // rejected and `disc` and `sunfish` rendered silently plain. Confining placement to
                // the middle 70% is both the fix and what a real fish looks like: nothing is marked
                // out on the tail wrist.
                x = x0 + L * (0.15 + 0.70 * ((i + 0.5) / cnt + (rnd() - 0.5) * 0.10));
                s = F.span(prof, x);
                if (!s) continue;
                y = s.top + (s.bot - s.top) * (0.16 + 0.14 * rnd());
                // ⛔ THE WOBBLE MAKES THE FOOTPRINT LAW WORSE. A saddle reaches 1.25 x its radius in
                // X and up to 1.14 x it in Y (the 0.72-1.14 wobble), so the room at its CENTRE says
                // nothing about where its edge lands. Cap against the worst point of the footprint
                // it will actually occupy, INCLUDING the wobble's own maximum — a bound that
                // ignores the randomness is a bound on the average case.
                //
                // ⛔ AND THE SPACING IS `L / count`, NOT `pitchPx`, BECAUSE THE COUNT IS BIOLOGICAL.
                // A mark's size comes from the spacing between marks, and the quantity that
                // actually varies here is the count, not the pitch. Using `pitchPx` gave a radius
                // of 0.176 on a body 0.475 long and four forms rendered SILENTLY PLAIN.
                // ⚠️ This used to be one branch shared with `mottle` and a `p.mode` ternary chose
                // between the two spacings. `mottle` now has its own branch (it needed a 2D count,
                // not a 1D one), so the ternary is gone: a conditional whose other arm is
                // unreachable is a claim about a case that no longer exists (§25h — a no-op ternary
                // puts the intent in the source and leaves it out of the picture).
                var rad = (L / Math.max(cnt, 1)) * 0.40;
                // ⛔ AND A BLOTCH CAN NEVER BE DEEPER THAN THE FISH. On `eel` — 0.115 deep, about
                // 14px at specimen size — a radius derived from the axial pitch is larger than the
                // whole body, so every mark was rejected and the cell rendered silently plain.
                // Capping against DEPTH is the second half of the same law that caps against
                // length: a mark's size is bounded by every dimension of the thing it sits on, not
                // just the one its spacing happens to run along.
                rad = Math.min(rad, F.depth(prof) * 0.34);
                var WOB = 1.14, XK = 1.25, k2, av2;
                // ⛔ A BLOTCH NEAR THE SNOUT IS SMALLER, NOT ABSENT. Bounding the footprint only by
                // the ROOM at each probe point meant a probe landing past the body's own end
                // returned nothing and the blotch was rejected outright — so the two roundest,
                // shortest forms emitted NO mottle at all and rendered silently plain. Bound the
                // radius by the distance to the nearer end FIRST; the room loop then only ever
                // shrinks it further, and a mark can always fit somewhere.
                var byEnd = Math.min(x - prof.x[0], prof.x[prof.n] - x) / (XK * WOB);
                if (byEnd < rad) rad = byEnd;
                for (k2 = -1; k2 <= 1; k2++) {
                    av2 = room(F, prof, x + rad * XK * WOB * k2, y);
                    if (av2 <= 0) { rad = 0; break; }
                    if (av2 / WOB * 0.92 < rad) rad = av2 / WOB * 0.92;
                }
                if (rad < 0.008) continue;
                var ring = [], K = 16, a;
                for (j = 0; j < K; j++) {
                    a = (j / K) * Math.PI * 2;
                    var rr2 = rad * (0.72 + 0.42 * rnd());
                    ring.push({ x: x + Math.cos(a) * rr2 * XK, y: y + Math.sin(a) * rr2 });
                }
                out.push({ id: id, role: F.ROLE.MARK, ring: ring });
            }
        } else if (id === 'ocelli') {
            // ⛔ AN OCELLUS HAS A FIXED INTERNAL ORDER — a dark ring, a bright iris, a dark pupil —
            // so it needs a PAIR of roles, not one "contrasting" ink. Asking only "what contrasts
            // with this surface" gives all three rings the same answer and the eye-spot vanishes.
            // BIOLOGICAL: one to three eye-spots is anatomy, not level of detail. Below the pitch
            // floor they are dropped entirely rather than shrunk into unreadable dots.
            if (p.minPx && (L * scale) / Math.max(1, Math.round(L * p.perUnit)) < p.minPx) return out;
            var oc = Math.max(1, Math.round(L * p.perUnit));
            for (i = 0; i < oc; i++) {
                x = x0 + L * (0.18 + 0.62 * ((i + 0.5) / oc));
                s = F.span(prof, x);
                if (!s) continue;
                // ⛔ NEVER AN EQUAL PAIR AT THE SAME HEIGHT. Two equal rings side by side read as
                // SPECTACLES — it is the first row of the doctrine's own table of misreadings, and
                // `hatchet` with two ocelli did exactly that. Alternating the height by a third of
                // the depth breaks the pairing, and asymmetry is the general defence.
                y = s.top + (s.bot - s.top)
                    * (0.30 + (i % 2) * 0.22 + 0.14 * rnd());
                var av = room(F, prof, x, y);
                if (av <= 0) continue;
                // Same law: an eye-spot is sized by how far apart the eye-spots are.
                var R0 = Math.min((L / Math.max(oc, 1)) * 0.34, av * 0.9);
                if (R0 < 0.012) continue;
                // ⛔ ONE offset for the WHOLE group, taken from the OUTERMOST ring. Fitting each
                // ring separately moves each by its own radius and the three stop being concentric
                // — which is precisely a spiral, not an eye.
                out.push({ id: 'ocellusRing', role: F.ROLE.MARK, ring: F.disc(x, y, R0, 16) });
                out.push({ id: 'ocellusIris', role: F.ROLE.BELLY, ring: F.disc(x, y, R0 * 0.62, 14) });
                out.push({ id: 'ocellusPupil', role: F.ROLE.EYE, ring: F.disc(x, y, R0 * 0.28, 12) });
            }
        } else if (id === 'chevron') {
            for (i = 0; i < n; i++) {
                t = (i + 0.5) / n;
                x = x0 + L * t;
                s = F.span(prof, x);
                if (!s) continue;
                // ⛔ EVERY VERTEX TAKES ITS DEPTH FROM THE SPAN AT ITS OWN X. The first version
                // computed all six from `span(x)` — the span at the chevron's SPINE — and then
                // placed the apex at `x + apex`, where the body is narrower. On a tapering form
                // the apex landed outside the fish. A depth fraction is only meaningful against
                // the span it was measured from.
                var wv = pitch * 0.30, apex = pitch * 0.62;
                var at = function (xx, f) {
                    var ss = F.span(prof, xx);
                    if (!ss) return null;
                    return { x: xx, y: ss.top + (ss.bot - ss.top) * f };
                };
                var g2 = [at(x, 0.10), at(x + apex, 0.50), at(x, 0.90),
                          at(x - wv, 0.90), at(x + apex - wv, 0.50), at(x - wv, 0.10)];
                if (g2.indexOf(null) < 0) {
                    out.push({ id: 'chevron', role: F.ROLE.MARK, ring: g2 });
                }
            }
        } else if (id === 'net') {
            // A mesh: thin bands both ways. Thin, because a net whose bars are as wide as its holes
            // is a solid fill with a grid drawn on it.
            var thin = pitch * 0.16;
            for (i = 0; i < n; i++) {
                x = x0 + L * ((i + 0.5) / n);
                var gv = band(F, prof, x - thin, x + thin, 0.06, 0.94, 5);
                if (gv) out.push({ id: 'mesh', role: F.ROLE.MARK, ring: gv });
            }
            // ⛔ THE BAND'S HALF-HEIGHT IS DERIVED FROM THE ROW SPACING, NOT TYPED. It was 0.055 of
            // the local depth against rows spaced 0.88/hr apart — so on a deep round body, where
            // hr comes out at 8, the spacing is 0.11 and the bands MEET EXACTLY. `disc/net`
            // rendered as a solid black fish, which is the failure this pattern's own comment
            // warns about ("a net whose bars are as wide as its holes is a solid fill with a grid
            // drawn on it"). At 0.40 of the spacing the holes are 60% of the run at every depth.
            var hr = Math.max(2, Math.round(F.depth(prof) / pitch));
            var rowGap = 0.88 / hr, halfBand = rowGap * 0.20;
            for (j = 0; j < hr; j++) {
                var hf = 0.06 + rowGap * (j + 0.5);
                var gh = band(F, prof, x0 + L * 0.04, x0 + L * 0.94,
                    hf - halfBand, hf + halfBand, 20);
                if (gh) out.push({ id: 'mesh', role: F.ROLE.MARK, ring: gh });
            }
        }
        return out;
    };

})(CreelPattern);

if (typeof module !== 'undefined' && module.exports) module.exports = CreelPattern;
