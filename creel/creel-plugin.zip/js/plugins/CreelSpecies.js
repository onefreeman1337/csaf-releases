//=================================================================================================
// CreelSpecies.js
//=================================================================================================
/*:
 * @target MZ
 * @plugindesc [Creel] Species declaration, database ingestion, resolution and the bake cache. This is the file that carries the parameters.
 * @author Core Systems Asset Factory
 *
 * @param species
 * @text Species
 * @desc Declare species here if you own no fishing system, or to override what Creel reads from the database.
 * @type struct<Species>[]
 * @default []
 *
 * @param readDatabase
 * @text Read the database
 * @desc Treat any Item, Weapon or Armor carrying a <creel> note tag as a species. Works with ANY fishing system that awards an item.
 * @type boolean
 * @on Read it
 * @off Ignore it
 * @default true
 *
 * @param cacheEntries
 * @text Baked specimen cache
 * @desc How many rendered specimens to keep in memory. Each is one Bitmap. 0 disables caching (slow; for debugging only).
 * @type number
 * @min 0
 * @max 512
 * @default 48
 *
 * @param specimenSize
 * @text Default specimen size
 * @desc Pixel width of a baked specimen when nothing asks for a specific size.
 * @type number
 * @min 24
 * @max 512
 * @default 160
 *
 * @command recordCatch
 * @text Record a catch
 * @desc Add a species to the player's record. Call this from whatever fishing system you already own.
 *
 * @arg key
 * @text Species key
 * @desc The species key, or the exact NAME of the item your fishing system awarded.
 * @type string
 * @default
 *
 * @arg length
 * @text Length
 * @desc Length of this individual, in whatever unit your game uses. 0 records the catch without a length.
 * @type number
 * @min 0
 * @default 0
 *
 * @command clearRecord
 * @text Clear the record
 * @desc Forget every catch. For New Game+ or a testing switch.
 *
 * @command countCaught
 * @text Count species caught
 * @desc Write the number of DISTINCT species recorded into a variable.
 *
 * @arg variableId
 * @text Variable
 * @type variable
 * @default 0
 *
 * @help
 * ------------------------------------------------------------------------------------------------
 * Creel — the fish draw themselves.
 * ------------------------------------------------------------------------------------------------
 *
 * Creel does not catch fish. Nine plugins already do that, and they are good. Creel draws the
 * fish, at runtime, from the species' own data — so a project with sixty species has sixty
 * distinct specimens and not one PNG.
 *
 * HOW IT FINDS YOUR SPECIES
 *
 *   1. The <creel> note tag on any Item, Weapon or Armor. Every fishing system awards an item,
 *      so this route works whichever one you own, without an adapter and without a name check.
 *
 *          <creel>                                 this item is a fish; draw it from its name
 *          <creel: form=eel, livery=silver>        pin the axes you care about, derive the rest
 *          <creel: rarity=4>                       rare fish get grander fins and showier colour
 *
 *   2. The Species parameter, for a project that owns no fishing system at all, or to override
 *      what the database says.
 *
 *   3. CreelSpecies.declare({...}) from another plugin's code, if you are a plugin author.
 *
 * WHAT A SPECIES IS
 *
 *      species = body plan  x  fin set  x  pattern  x  palette
 *
 *   Twelve body plans, eight fin sets, ten patterns and twelve liveries. Any axis you leave
 *   unset is DERIVED from the species' own name — read through a vocabulary first (an "eel" gets
 *   the eel body, a "sunfish" the deep one) and hashed when the vocabulary has nothing to say.
 *   The derivation is deterministic: the same name is always the same fish, in every playthrough
 *   and on every machine.
 *
 * WHAT IT COSTS PER FRAME
 *
 *   Nothing. A specimen is drawn ONCE into a cached Bitmap and blitted thereafter. Hold the
 *   Bitmap you were given; do not call bitmapFor in an update loop.
 *
 * LOAD ORDER
 *
 *   Any. Every file in this product resolves its siblings at first use, not at load time, so the
 *   Plugin Manager may hold them in any order. CreelSpecies is the only one with parameters.
 *
 * SAVE DATA
 *
 *   The catch record lives on $gameSystem and is versioned; older saves are migrated forward on
 *   load. The specimen cache is deliberately NOT saved (JsonEx would serialise every baked
 *   bitmap into the save file) and is held on a non-enumerable property so it cannot be.
 *
 * ------------------------------------------------------------------------------------------------
 * Terms of use: see LICENSE.txt in this package.
 * ------------------------------------------------------------------------------------------------
 */
/*~struct~Species:
 * @param key
 * @text Key
 * @desc Unique id for this species. If it matches an item NAME, your fishing system needs no extra wiring.
 * @type string
 * @default
 *
 * @param name
 * @text Display name
 * @desc Shown in the catalogue. Leave blank to use the key.
 * @type string
 * @default
 *
 * @param form
 * @text Body plan
 * @desc Leave blank to derive it from the name.
 * @type select
 * @option (derive from the name)
 * @value
 * @option Spindle
 * @value spindle
 * @option Torpedo
 * @value torpedo
 * @option Disc
 * @value disc
 * @option Sunfish
 * @value sunfish
 * @option Eel
 * @value eel
 * @option Ribbon
 * @value ribbon
 * @option Flathead
 * @value flathead
 * @option Hatchet
 * @value hatchet
 * @option Angler
 * @value angler
 * @option Ray
 * @value ray
 * @option Fan
 * @value fan
 * @option Pike
 * @value pike
 * @default
 *
 * @param finset
 * @text Fin set
 * @desc Leave blank to derive it from the name and the rarity.
 * @type select
 * @option (derive)
 * @value
 * @option Plain
 * @value plain
 * @option Sail
 * @value sail
 * @option Fork
 * @value fork
 * @option Lance
 * @value lance
 * @option Fringe
 * @value fringe
 * @option Spine
 * @value spine
 * @option Paddle
 * @value paddle
 * @option Trail
 * @value trail
 * @default
 *
 * @param pattern
 * @text Pattern
 * @desc Leave blank to derive it from the name.
 * @type select
 * @option (derive)
 * @value
 * @option Plain
 * @value plain
 * @option Bars
 * @value bars
 * @option Stripes
 * @value stripes
 * @option Spots
 * @value spots
 * @option Speckle
 * @value speckle
 * @option Mottle
 * @value mottle
 * @option Saddle
 * @value saddle
 * @option Ocelli
 * @value ocelli
 * @option Chevron
 * @value chevron
 * @option Net
 * @value net
 * @default
 *
 * @param livery
 * @text Livery
 * @desc Leave blank to derive it from the name and the rarity.
 * @type select
 * @option (derive)
 * @value
 * @option Trout
 * @value trout
 * @option Char
 * @value char
 * @option Perch
 * @value perch
 * @option Koi
 * @value koi
 * @option Abyssal
 * @value abyssal
 * @option Reef
 * @value reef
 * @option Silver
 * @value silver
 * @option Pike
 * @value pike
 * @option Carp
 * @value carp
 * @option Tropical
 * @value tropical
 * @option Albino
 * @value albino
 * @option Ember
 * @value ember
 * @default
 *
 * @param rarity
 * @text Rarity
 * @desc 0 common to 4 legendary. Raises the fin set and the livery into the showier half of each corpus.
 * @type number
 * @min 0
 * @max 4
 * @default 0
 */

var CreelSpecies = CreelSpecies || {};

(function (S) {
    'use strict';

    // =============================================================================================
    // SIBLINGS, RESOLVED AT FIRST USE — NEVER AT LOAD TIME
    //
    // ⛔ Wing §8 trap 2, measured on a four-file product: `mz_harness build` loads the plugin folder
    //    ALPHABETICALLY, and that is also what a buyer gets for dragging files into the Plugin
    //    Manager in the wrong order. Capturing a sibling at load time makes the whole product no-op
    //    behind one console line. This product ships NO plugin_order.json on purpose (§8 trap 2b),
    //    so the harness exercises the alphabetical worst case every run.
    // =============================================================================================

    var _deps = null;
    /** @returns {?{F:object,Fn:object,P:object,L:object,R:object}} null until every sibling exists. */
    function deps() {
        if (_deps) return _deps;
        if (typeof CreelForms === 'undefined' || typeof CreelFins === 'undefined'
            || typeof CreelPattern === 'undefined' || typeof CreelLivery === 'undefined'
            || typeof CreelRender === 'undefined') return null;
        _deps = { F: CreelForms, Fn: CreelFins, P: CreelPattern, L: CreelLivery, R: CreelRender };
        return _deps;
    }
    S.deps = deps;

    // =============================================================================================
    // PARAMETERS
    //
    // ⛔ Plugin parameters arrive as STRINGS, and `Number('')` is 0 rather than NaN, so a blank
    //    field reads as a deliberate zero unless it is treated as ABSENT (wing §16).
    // ⛔ And `"0"` is TRUTHY. An id is coerced with Number() and compared against zero; the raw
    //    property is never tested — that exact mistake disabled Augury's headline feature with
    //    every headless check green.
    // ⛔ A `struct<T>[]` is DOUBLE-encoded: a JSON string of JSON strings, and every leaf arrives as
    //    a string whatever the declared @type says.
    // =============================================================================================

    /** Blank means ABSENT. Never 0, never false. */
    function str(v) {
        return (v === undefined || v === null || String(v).trim() === '') ? null : String(v).trim();
    }
    /** @returns {number} `dflt` when the parameter is blank; the number otherwise. */
    function num(v, dflt) {
        var s = str(v);
        if (s === null) return dflt;
        var n = Number(s);
        return isFinite(n) ? n : dflt;
    }
    function bool(v, dflt) {
        var s = str(v);
        if (s === null) return dflt;
        return s === 'true' || s === 'on' || s === '1';
    }
    /** Parse the double-encoded struct array. Never throws: a malformed row is skipped. */
    function structArray(raw) {
        var s = str(raw);
        if (s === null) return [];
        var outer;
        try { outer = JSON.parse(s); } catch (e) { return []; }
        if (!Array.isArray(outer)) return [];
        var out = [];
        for (var i = 0; i < outer.length; i++) {
            try { out.push(JSON.parse(outer[i])); } catch (e) { /* skip the row, not the list */ }
        }
        return out;
    }

    var _params = null;
    function params() {
        if (_params) return _params;
        var p = {};
        if (typeof PluginManager !== 'undefined' && PluginManager.parameters) {
            p = PluginManager.parameters('CreelSpecies') || {};
        }
        _params = {
            species: structArray(p.species),
            readDatabase: bool(p.readDatabase, true),
            cacheEntries: Math.max(0, Math.floor(num(p.cacheEntries, 48))),
            specimenSize: Math.max(24, Math.floor(num(p.specimenSize, 160)))
        };
        return _params;
    }
    S.params = params;

    // =============================================================================================
    // THE DERIVATION
    //
    // Every axis a buyer leaves blank is derived from the species' OWN NAME. Two stages, in this
    // order, and the order is the design:
    //
    //   1. A VOCABULARY. An "eel" gets the eel body, a "sunfish" the deep one, a "koi" the koi
    //      livery. This is the craft half and it is what makes the output feel authored rather
    //      than assigned.
    //   2. A HASH, over the whole name, for everything the vocabulary has nothing to say about.
    //
    // ⛔ WHY BOTH, AND WHY THE HASH IS NOT OPTIONAL. Wing §21i: a classifier written as a decision
    //    tree returns exactly one answer per branch, so a project with six similar entries gets one
    //    picture six times — `volume()` reports 11,520 species and the buyer sees four. A vocabulary
    //    ALONE is that decision tree. The hash guarantees spread wherever the vocabulary is silent,
    //    and `Internal_Ops/_probe/spread_check.js` measures what a real buyer's list resolves to
    //    rather than what the corpus could theoretically produce.
    //
    // ⛔ AND THE VOCABULARY MUST NOT READ WHAT KADOKAWA SHIPPED (wing §24a). Creel only ever reads
    //    names the buyer wrote — a species key, or an item they tagged <creel> themselves. It never
    //    scores the stock database, because what Kadokawa shipped says nothing about a buyer's game.
    // =============================================================================================

    /**
     * FNV-1a, 32-bit. Deterministic across machines and playthroughs; nothing here is Math.random.
     * @param {string} s
     * @param {number} [salt] mixed in first, so one name can drive several independent axes.
     */
    S.hash = function (s, salt) {
        var h = 2166136261 >>> 0;
        var k = (salt || 0) >>> 0;
        h = (h ^ k) >>> 0;
        h = Math.imul(h, 16777619) >>> 0;
        var t = String(s === undefined || s === null ? '' : s).toLowerCase();
        for (var i = 0; i < t.length; i++) {
            h = (h ^ t.charCodeAt(i)) >>> 0;
            h = Math.imul(h, 16777619) >>> 0;
        }
        // ⚠️ One final avalanche. Without it two names differing only in their LAST character land
        // in adjacent buckets, which shows up as "Brown Trout" and "Brook Trout" drawing the same
        // fish — the exact collapse §21i is about.
        h = (h ^ (h >>> 15)) >>> 0;
        h = Math.imul(h, 2246822507) >>> 0;
        h = (h ^ (h >>> 13)) >>> 0;
        return h >>> 0;
    };

    /** Pick from an ordered list by a salted hash of `s`. */
    function pick(list, s, salt) {
        return list[S.hash(s, salt) % list.length];
    }

    // ---- the vocabulary --------------------------------------------------------------------------
    // Each entry is [words, id]. A word matches as a whole token or as a suffix of one, so
    // "Rainbow Trout" and "Lake-trout" both hit `trout`. Longer words are tested first, so
    // "sunfish" cannot be captured by "fish".

    var FORM_WORDS = [
        [['eel', 'lamprey', 'conger', 'moray', 'elver'], 'eel'],
        [['ray', 'skate', 'manta', 'stingray'], 'ray'],
        [['sunfish', 'bream', 'discus', 'moonfish', 'opah'], 'sunfish'],
        [['disc', 'butterflyfish', 'angelfish', 'tang', 'sunny'], 'disc'],
        [['pike', 'gar', 'needlefish', 'barracuda', 'muskie'], 'pike'],
        [['angler', 'anglerfish', 'monkfish', 'lophius', 'toadfish', 'frogfish'], 'angler'],
        [['ribbon', 'oarfish', 'cutlassfish', 'dealfish'], 'ribbon'],
        [['flathead', 'flounder', 'sole', 'plaice', 'halibut', 'turbot', 'dab'], 'flathead'],
        [['hatchet', 'hatchetfish', 'shad', 'herring', 'sprat', 'sardine'], 'hatchet'],
        [['fan', 'lionfish', 'firefish', 'sailfin', 'betta'], 'fan'],
        [['torpedo', 'tuna', 'mackerel', 'bonito', 'salmon', 'marlin', 'swordfish'], 'torpedo'],
        [['spindle', 'trout', 'char', 'carp', 'perch', 'bass', 'roach', 'rudd',
          'minnow', 'dace', 'chub', 'koi', 'goldfish', 'cod', 'haddock'], 'spindle']
    ];

    var PATTERN_WORDS = [
        [['spotted', 'spot', 'dotted', 'leopard', 'freckled'], 'spots'],
        [['speckled', 'speckle', 'flecked', 'peppered', 'stippled'], 'speckle'],
        [['striped', 'stripe', 'lined', 'ribboned'], 'stripes'],
        [['barred', 'bar', 'banded', 'zebra', 'tiger'], 'bars'],
        [['mottled', 'mottle', 'marbled', 'clouded', 'dappled'], 'mottle'],
        [['saddled', 'saddle', 'blotched'], 'saddle'],
        [['ocellated', 'ocelli', 'eyespot', 'peacock', 'argus'], 'ocelli'],
        [['chevron', 'arrow', 'vermiculated', 'zigzag'], 'chevron'],
        [['net', 'netted', 'reticulated', 'lattice', 'mesh', 'honeycomb'], 'net'],
        [['plain', 'clear', 'blank'], 'plain']
    ];

    var LIVERY_WORDS = [
        [['koi', 'nishikigoi'], 'koi'],
        [['albino', 'ghost', 'white', 'pale', 'snow', 'moon'], 'albino'],
        [['abyssal', 'abyss', 'deep', 'void', 'midnight', 'lantern', 'shadow'], 'abyssal'],
        [['ember', 'fire', 'flame', 'crimson', 'blood', 'ruby', 'magma'], 'ember'],
        [['silver', 'chrome', 'steel', 'mirror', 'quicksilver'], 'silver'],
        [['reef', 'coral', 'clown', 'sunset', 'amber'], 'reef'],
        [['tropical', 'parrot', 'rainbow', 'azure', 'sapphire', 'jewel'], 'tropical'],
        [['carp', 'bronze', 'mud', 'copper', 'river'], 'carp'],
        [['pike', 'weed', 'reed', 'marsh', 'bog'], 'pike'],
        [['perch', 'sunny'], 'perch'],
        [['char', 'brook', 'arctic'], 'char'],
        [['trout', 'brown', 'olive', 'creek'], 'trout']
    ];

    var FINSET_WORDS = [
        [['sail', 'sailfin', 'sailfish', 'sunfish'], 'sail'],
        [['fork', 'forked', 'tuna', 'mackerel', 'herring'], 'fork'],
        [['lance', 'spear', 'sword', 'marlin', 'needle'], 'lance'],
        [['fringe', 'fringed', 'frilled', 'lion', 'lionfish', 'veil'], 'fringe'],
        [['spine', 'spined', 'spiny', 'thorn', 'urchin', 'stickleback'], 'spine'],
        [['paddle', 'lungfish', 'coelacanth', 'ganoid'], 'paddle'],
        [['trail', 'streamer', 'ribbon', 'comet', 'betta'], 'trail']
    ];

    /**
     * Split a name into lower-case word tokens. Digits and punctuation are separators, so
     * "Trout (Large)" and "trout-large" tokenise identically.
     * @returns {Array<string>}
     */
    function tokens(name) {
        return String(name || '').toLowerCase().split(/[^a-z]+/).filter(function (t) { return t; });
    }

    /**
     * Look a name up in a vocabulary table.
     *
     * ⛔⛔ THE HEAD NOUN WINS, AND THAT IS THE LAST TOKEN. A FISH NAME IS "MODIFIER HEAD".
     *
     * MEASURED 2026-09-03 by `_probe/spread_check.js` on a cosy-freshwater buyer list — the most
     * likely list this product will ever meet — which resolved **70% of twenty species onto one
     * body plan** and rendered `River Trout` and `Grass Carp` as the SAME PICTURE.
     *
     * The cause was a silent tie-break. This function scored a candidate by WORD LENGTH ONLY, with
     * `if (word.length <= bestLen) continue;` discarding every later word of equal length — so a
     * tie was decided by the order the rows happen to sit in the table. `river` (5, in the `carp`
     * row) and `trout` (5, in the `trout` row) tie, `carp` is declared four rows earlier, and
     * therefore **every "River <anything>" in a buyer's tackle box came out carp-coloured**.
     * `River Perch` too. Nothing could see it: a wrong-but-valid livery id renders perfectly, and
     * `volume()` still reported 11,520 species (wing §21i — the corpus size is what the product
     * COULD make, never what a buyer's list resolves to).
     *
     * ⚠️ AND THE OBVIOUS FIX WOULD HAVE BEEN A GUESS. Reordering the rows so `trout` precedes
     * `carp` fixes this pair and leaves the mechanism — the next tie is decided by table order too,
     * and the table would have acquired an invisible dependency on its own line numbering.
     *
     * English compounds put the head last: "River Trout", "Brown Trout", "Grass Carp", "Manta Ray",
     * "Moray Eel", "Sea Bass". So the rule is positional, not lexical: **walk the tokens from the
     * END and take the first one the vocabulary can answer at all**, resolving ties within that one
     * token by word length as before. A modifier can still speak when the head noun is a word the
     * vocabulary does not know ("Deep Lurker" -> `abyssal` from `deep`), which is the fallback that
     * makes this safe rather than merely different.
     *
     * ⚠️ Longest word WITHIN the chosen token, so "sunfish" cannot be captured by "sun" and
     * "anglerfish" cannot be captured by "angler" from a different row.
     *
     * @returns {?string} the id, or null when the vocabulary has nothing to say.
     */
    function vocab(table, name) {
        var toks = tokens(name);
        if (!toks.length) return null;
        for (var t = toks.length - 1; t >= 0; t--) {
            var best = null, bestLen = 0;
            for (var r = 0; r < table.length; r++) {
                var words = table[r][0], id = table[r][1];
                for (var w = 0; w < words.length; w++) {
                    var word = words[w];
                    if (word.length <= bestLen) continue;
                    // whole token, or the token ends with the word ("laketrout", "sea-bass")
                    if (toks[t] === word || (toks[t].length > word.length
                        && toks[t].slice(-word.length) === word)) {
                        best = id; bestLen = word.length;
                    }
                }
            }
            if (best !== null) return best;
        }
        return null;
    }
    S.vocab = function (which, name) {
        var t = { form: FORM_WORDS, pattern: PATTERN_WORDS, livery: LIVERY_WORDS, finset: FINSET_WORDS }[which];
        return t ? vocab(t, name) : null;
    };

    // ---- rarity ---------------------------------------------------------------------------------
    // ⛔ WHY A TIER AND NOT A SLIDING WINDOW. Wing §25g measured the sliding-window version on
    //    Cartouche: widening a rank window made collisions WORSE (74.8% -> 90.8%), because a wider
    //    window overlaps its neighbours more than it spreads within one rank. Two tiers over an
    //    ORDERED corpus keep the full width of each tier available to the hash, so rarity is
    //    visible without narrowing the spread to a handful of cells. §25g's real finding is that
    //    the defect worth gating is rank being INVISIBLE, and a tier makes it visible by
    //    construction: no modest fin set can appear on a legendary fish.

    var FINSET_MODEST = ['plain', 'fork', 'paddle', 'spine'];
    var FINSET_GRAND = ['sail', 'lance', 'fringe', 'trail'];
    var LIVERY_MODEST = ['trout', 'char', 'perch', 'silver', 'pike', 'carp'];
    var LIVERY_SHOWY = ['koi', 'abyssal', 'reef', 'tropical', 'albino', 'ember'];

    /** Rarity 0-4 clamped; >= 3 is the showy half. */
    function rarityOf(v) {
        var n = Math.floor(num(v, 0));
        return n < 0 ? 0 : (n > 4 ? 4 : n);
    }

    /**
     * Resolve one declared entry into the four axes a renderer needs.
     *
     * Explicit wins, then the vocabulary, then the hash. Deterministic in all three cases.
     *
     * @param {{key:string, name?:string, form?:string, finset?:string, pattern?:string,
     *          livery?:string, rarity?:(number|string), seed?:(number|string)}} entry
     * @returns {?{form:string,finset:string,pattern:string,livery:string,seed:number}}
     *          null when an explicitly declared id does not exist in the corpus — the caller
     *          SKIPS it. A buyer's typo must never crash a fishing scene (wing §21c).
     */
    S.specFor = function (entry) {
        var d = deps();
        if (!d || !entry) return null;
        var key = str(entry.key) || str(entry.name) || '';
        var text = (str(entry.name) || '') + ' ' + key;
        var rar = rarityOf(entry.rarity);

        function axis(explicit, which, ids, salt, tierModest, tierShowy) {
            var e = str(explicit);
            // An explicit id that the corpus does not contain returns `undefined`, which the
            // caller turns into a SKIPPED species. It must not fall through to the derivation:
            // silently drawing a different fish from the one a buyer typed is worse than drawing
            // none, because nothing anywhere would report it.
            if (e !== null) return ids.indexOf(e) > -1 ? e : undefined;
            var v = S.vocab(which, text);
            if (v && ids.indexOf(v) > -1) return v;
            var pool = (tierModest && tierShowy) ? (rar >= 3 ? tierShowy : tierModest) : ids;
            return pick(pool, key, salt);
        }

        var form = axis(entry.form, 'form', d.F.IDS, 0x01);
        var finset = axis(entry.finset, 'finset', d.Fn.IDS, 0x02, FINSET_MODEST, FINSET_GRAND);
        var pattern = axis(entry.pattern, 'pattern', d.P.IDS, 0x03);
        var livery = axis(entry.livery, 'livery', d.L.IDS, 0x04, LIVERY_MODEST, LIVERY_SHOWY);

        // An explicitly declared id that does not exist is a typo in the buyer's data. Skip the
        // species rather than substituting one silently — a wrong fish is worse than none, and a
        // thrown error mid-scene is worse than both.
        if (form === undefined || finset === undefined || pattern === undefined || livery === undefined) {
            return null;
        }
        var seed = str(entry.seed) !== null ? Math.floor(num(entry.seed, 1)) : (S.hash(key, 0x05) % 65536) + 1;
        return { form: form, finset: finset, pattern: pattern, livery: livery, seed: seed };
    };

    // =============================================================================================
    // THE REGISTRY
    // =============================================================================================

    var _registry = null;      // key -> {key, name, spec, rarity, source}
    var _order = null;         // declaration order, so the catalogue is stable

    /** Rebuild from parameters + database. Idempotent; safe to call again after a database edit. */
    S.rebuild = function () {
        _registry = {};
        _order = [];
        var i, p = params();
        for (i = 0; i < p.species.length; i++) S.declare(p.species[i], 'parameter');
        if (p.readDatabase) S.readDatabase();
        return _order.length;
    };

    /**
     * Declare one species. Later declarations of the same key REPLACE earlier ones, so a
     * parameter row can override a note tag.
     * @returns {boolean} false when the entry could not be resolved (and was therefore skipped).
     */
    S.declare = function (entry, source) {
        if (_registry === null) { _registry = {}; _order = []; }
        var key = str(entry && entry.key) || str(entry && entry.name);
        if (key === null) return false;
        var spec = S.specFor(entry);
        if (!spec) return false;
        if (!Object.prototype.hasOwnProperty.call(_registry, key)) _order.push(key);
        _registry[key] = {
            key: key,
            name: str(entry.name) || key,
            spec: spec,
            rarity: rarityOf(entry.rarity),
            source: source || 'code'
        };
        return true;
    };

    /**
     * Read every <creel> note tag in the database.
     *
     * ⭐ THIS IS THE ADAPTER, AND IT IS ONE ADAPTER RATHER THAN NINE. Every fishing system measured
     *    on the store awards the player an ITEM; none of them agrees with any other about global
     *    names, data shapes or hook points. Reading the note tag on the item they all already
     *    create is a FEATURE TEST rather than a name check (architecture §7), it needs no knowledge
     *    of which plugin is installed, and it cannot break when one of them updates.
     */
    S.readDatabase = function () {
        var books = [];
        if (typeof $dataItems !== 'undefined' && $dataItems) books.push($dataItems);
        if (typeof $dataWeapons !== 'undefined' && $dataWeapons) books.push($dataWeapons);
        if (typeof $dataArmors !== 'undefined' && $dataArmors) books.push($dataArmors);
        var found = 0;
        for (var b = 0; b < books.length; b++) {
            var book = books[b];
            for (var i = 1; i < book.length; i++) {
                var row = book[i];
                if (!row || typeof row.note !== 'string') continue;
                var e = S.parseNote(row.note, row.name);
                if (!e) continue;
                if (S.declare(e, 'note')) found++;
            }
        }
        return found;
    };

    /**
     * Parse a <creel> note tag.
     *   <creel>                              -> {} (everything derived)
     *   <creel: form=eel, livery=silver>     -> those axes pinned
     * @returns {?object} null when the note carries no creel tag at all.
     */
    S.parseNote = function (note, itemName) {
        var m = /<\s*creel\s*(?::([^>]*))?>/i.exec(String(note || ''));
        if (!m) return null;
        var e = { key: str(itemName) || '', name: str(itemName) || '' };
        var body = str(m[1]);
        if (body !== null) {
            var bits = body.split(',');
            for (var i = 0; i < bits.length; i++) {
                var kv = bits[i].split('=');
                if (kv.length !== 2) continue;
                var k = kv[0].trim().toLowerCase(), v = kv[1].trim();
                // ⚠️ Only fields this product understands. An unknown key is IGNORED rather than
                // stored, so a typo cannot silently become an axis nothing reads.
                if (['form', 'finset', 'pattern', 'livery', 'rarity', 'seed', 'key', 'name'].indexOf(k) > -1) {
                    e[k] = v;
                }
            }
        }
        return e;
    };

    function registry() {
        if (_registry === null) S.rebuild();
        return _registry;
    }

    /** @returns {Array<string>} every known species key, in declaration order. */
    S.keys = function () { registry(); return _order.slice(); };
    /** @returns {number} how many species this project actually resolves. Never the corpus size. */
    S.count = function () { registry(); return _order.length; };
    /** @returns {?object} the registry record, or null for an unknown key. */
    S.get = function (key) {
        var r = registry();
        var k = str(key);
        if (k === null) return null;
        if (Object.prototype.hasOwnProperty.call(r, k)) return r[k];
        // A case-insensitive second pass, because an item name typed into a plugin command rarely
        // matches its database capitalisation exactly.
        var lower = k.toLowerCase();
        for (var i = 0; i < _order.length; i++) {
            if (_order[i].toLowerCase() === lower) return r[_order[i]];
        }
        return null;
    };

    // =============================================================================================
    // THE BAKE CACHE
    //
    // ⛔ Wing doctrine: zero allocation in per-frame hot paths, draw calls <= 60. A specimen is
    //    hundreds of path operations, so drawing one per frame per fish fails the MZ gate on frame
    //    one. A specimen is rendered ONCE into a Bitmap and blitted thereafter.
    //
    // ⚠️ HOLD THE BITMAP YOU ARE GIVEN. `bitmapFor` builds a string key, which allocates — it is a
    //    SETUP call, not an update call. Nothing in this product calls it from an update loop and
    //    neither should a buyer.
    // =============================================================================================

    var _cache = null;     // key -> Bitmap
    var _lru = null;       // insertion order; eviction is oldest-first and therefore deterministic

    function cacheKey(spec, size) {
        return spec.form + '|' + spec.finset + '|' + spec.pattern + '|' + spec.livery
            + '|' + spec.seed + '|' + size;
    }

    /**
     * Render a spec into a Bitmap, or return the cached one.
     * @param {object} spec  from S.specFor
     * @param {number} [size]  unit-box width in pixels; defaults to the specimenSize parameter.
     * @returns {?Bitmap} null when the renderer is unavailable or the spec does not draw.
     */
    S.bitmapFor = function (spec, size) {
        var d = deps();
        if (!d || !spec) return null;
        if (typeof Bitmap === 'undefined') return null;
        var px = Math.max(24, Math.floor(size || params().specimenSize));
        var k = cacheKey(spec, px);
        if (_cache === null) { _cache = {}; _lru = []; }
        if (Object.prototype.hasOwnProperty.call(_cache, k)) return _cache[k];

        // The extent budget is a disc of radius 0.5 in the unit box and is SHARED by the body and
        // the fin set, so everything fits inside `px`. The margin is for the contour stroke only,
        // which is drawn centred on the outline and therefore hangs half its width outside.
        var margin = Math.max(2, Math.ceil(px * 0.02));
        var w = px + margin * 2;
        var bmp = new Bitmap(w, w);
        var ctx = bmp.context;
        var T = d.R.transform(w / 2, w / 2, px);
        var drew = d.R.specimen(ctx, T, spec);
        if (!drew) return null;
        if (bmp._baseTexture) bmp._baseTexture.update();

        var limit = params().cacheEntries;
        if (limit > 0) {
            _cache[k] = bmp;
            _lru.push(k);
            while (_lru.length > limit) {
                var old = _lru.shift();
                if (_cache[old] && _cache[old].destroy) _cache[old].destroy();
                delete _cache[old];
            }
        }
        return bmp;
    };

    /** Bake by species key. Returns null for an unknown key — never throws. */
    S.bitmapForKey = function (key, size) {
        var rec = S.get(key);
        return rec ? S.bitmapFor(rec.spec, size) : null;
    };

    /** Drop every baked bitmap. Called on a load, because a save may carry a different database. */
    S.clearCache = function () {
        if (_cache) {
            for (var k in _cache) {
                if (Object.prototype.hasOwnProperty.call(_cache, k)
                    && _cache[k] && _cache[k].destroy) _cache[k].destroy();
            }
        }
        _cache = null; _lru = null;
    };
    /** For the suite: how many bitmaps are live. */
    S.cacheSize = function () { return _lru ? _lru.length : 0; };

    // =============================================================================================
    // THE CATCH RECORD, AND THE SAVE SEAM
    //
    // ⛔ Wing §13: `JsonEx.stringify` and `JsonEx.makeDeepCopy` both bypass a `makeSaveContents`
    //    hook, so a runtime cache hung on $gameSystem is written into the save file twice over.
    //    `JsonEx._encode` walks `Object.keys` — enumerable own properties — so a NON-ENUMERABLE
    //    slot is invisible to it. That is the fix; a hook is only a backstop.
    //
    //    The RECORD is different and must be saved, so it is a plain enumerable property with a
    //    version number and a forward migration.
    // =============================================================================================

    S.RECORD_VERSION = 1;

    function newRecord() { return { v: S.RECORD_VERSION, caught: {} }; }

    /**
     * Bring a record forward from any earlier shape. Lossless: an unknown future version is
     * returned untouched rather than reset, because destroying a player's record to satisfy a
     * version check is worse than carrying a field we do not read.
     */
    S.migrate = function (rec) {
        if (!rec || typeof rec !== 'object') return newRecord();
        var v = Number(rec.v);
        if (!isFinite(v) || v < 1) {
            // v0: the pre-versioned shape was a bare map of key -> count.
            var out = newRecord();
            for (var k in rec) {
                if (!Object.prototype.hasOwnProperty.call(rec, k) || k === 'v' || k === 'caught') continue;
                var n = Number(rec[k]);
                out.caught[k] = { n: isFinite(n) && n > 0 ? n : 1, best: 0 };
            }
            return out;
        }
        if (!rec.caught || typeof rec.caught !== 'object') rec.caught = {};
        return rec;
    };

    /** The live record, migrating on first touch. Returns null outside a running game. */
    S.record = function () {
        if (typeof $gameSystem === 'undefined' || !$gameSystem) return null;
        $gameSystem._creelRecord = S.migrate($gameSystem._creelRecord);
        return $gameSystem._creelRecord;
    };

    /**
     * Record one catch.
     * @param {string} key  a species key, or the item name your fishing system awarded.
     * @param {number} [length]  0 records the catch without a length.
     * @returns {boolean} false for an unknown species — the caller is not told off, and nothing
     *          throws, because a buyer's fishing system may award items Creel does not draw.
     */
    S.recordCatch = function (key, length) {
        var rec = S.record();
        var found = S.get(key);
        if (!rec || !found) return false;
        var c = rec.caught[found.key];
        var len = Math.max(0, num(length, 0));
        if (!c) { c = rec.caught[found.key] = { n: 0, best: 0 }; }
        c.n += 1;
        if (len > c.best) c.best = len;
        return true;
    };

    S.isCaught = function (key) {
        var rec = S.record(), found = S.get(key);
        if (!rec || !found) return false;
        return !!rec.caught[found.key];
    };
    S.caughtCount = function () {
        var rec = S.record();
        if (!rec) return 0;
        return Object.keys(rec.caught).length;
    };
    S.clearRecord = function () {
        if (typeof $gameSystem === 'undefined' || !$gameSystem) return;
        $gameSystem._creelRecord = newRecord();
    };

    // =============================================================================================
    // ENGINE SEAMS
    //
    // ⛔ Every patch below is a SAVED-ORIGINAL PROTOTYPE EXTENSION and every one CALLS THROUGH.
    //    Wing §24c: a saved handle that is never invoked is a REPLACEMENT with a courtesy handle,
    //    and a listing that says "extends, co-exists" on that basis is false. These genuinely
    //    extend, so the generated compatibility block is honest.
    //
    // ⛔ The names are verified against the engine by Internal_Ops/_probe/verify_method_names.js,
    //    which reads them out of THIS source rather than a hand-maintained list — §23a, where
    //    `Game_Party.prototype.recoverAll` did not exist and stored `undefined` as the original.
    // =============================================================================================

    /**
     * Install the non-enumerable runtime slot on a Game_System instance.
     *
     * ⛔ DELIBERATELY A MODULE-LOCAL FUNCTION AND NOT A NEW PROTOTYPE METHOD. Hanging
     *    `Game_System.prototype._creelSomething` on a core class is an ADDITION to somebody else's
     *    class — it survives into every save's prototype chain, it collides by name with any other
     *    plugin that has the same idea, and `_probe/verify_method_names.js` correctly reports an
     *    added name on a core class as a defect. A closure has none of those properties.
     */
    function installRuntimeSlot(sys) {
        if (!sys) return;
        Object.defineProperty(sys, '_creelRuntime', {
            value: null, writable: true, enumerable: false, configurable: true
        });
    }
    S._installRuntimeSlot = installRuntimeSlot;   // exported for the suite, not for the engine

    (function () {
        if (typeof Game_System === 'undefined') return;   // headless: nothing to patch

        var _init = Game_System.prototype.initialize;
        Game_System.prototype.initialize = function () {
            _init.apply(this, arguments);                  // ⚠️ apply(arguments), never call(a, b)
            installRuntimeSlot(this);
            this._creelRecord = newRecord();
        };

        if (typeof DataManager === 'undefined') return;

        // A save written before this plugin was installed has no slot at all, and JsonEx rebuilds
        // the object without ever running initialize. Re-install it on extraction.
        var _extract = DataManager.extractSaveContents;
        DataManager.extractSaveContents = function (contents) {
            _extract.apply(this, arguments);
            if (typeof $gameSystem !== 'undefined' && $gameSystem) {
                if (!Object.prototype.hasOwnProperty.call($gameSystem, '_creelRuntime')) {
                    installRuntimeSlot($gameSystem);
                }
                $gameSystem._creelRecord = S.migrate($gameSystem._creelRecord);
            }
            // A different save may carry a different database; a baked bitmap is not portable
            // across that, and a stale one is a WRONG fish rather than a missing one.
            S.clearCache();
            _registry = null;
        };
    }());

    // =============================================================================================
    // PLUGIN COMMANDS
    //
    // ⛔ Wing §24b: `mz_gate` reports NOT CLEAN when a product registers zero plugin commands, and
    //    the honest fix is to give the product the commands it should have had — never to argue
    //    with the guard.
    // =============================================================================================

    if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
        PluginManager.registerCommand('CreelSpecies', 'recordCatch', function (args) {
            S.recordCatch(args.key, num(args.length, 0));
        });
        PluginManager.registerCommand('CreelSpecies', 'clearRecord', function () {
            S.clearRecord();
        });
        PluginManager.registerCommand('CreelSpecies', 'countCaught', function (args) {
            // ⛔ `"0"` is TRUTHY, so the id is coerced and compared against zero (wing §16).
            var id = Math.floor(num(args.variableId, 0));
            if (id > 0 && typeof $gameVariables !== 'undefined' && $gameVariables) {
                $gameVariables.setValue(id, S.caughtCount());
            }
        });
    }

}(CreelSpecies));
