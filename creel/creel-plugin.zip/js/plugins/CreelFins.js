/*:
 * @target MZ
 * @plugindesc [Creel] Fin-set corpus — 8 authored fin sets. Library file; no parameters.
 * @author Core Systems Asset Factory
 *
 * @help
 * CreelFins.js
 *
 * The second half of the corpus. 12 body plans x 8 fin sets is 96 SILHOUETTES, and pattern and
 * palette then multiply the catalogue on top of that WITHOUT CHANGING A SINGLE OUTLINE. That
 * separation is the load-bearing idea of the whole product: it is what lets the catalogue be large
 * without becoming mush.
 *
 * ⛔ A FIN SET SPENDS THE FORM'S BUDGET, NOT ITS OWN. A fin attaches to the body's own edge, so its
 * reach is body depth PLUS fin extent — a body that fits and a fin set that fits can overflow
 * together. Every form declares `finBudget`, this file is required to respect it, and the suite
 * measures the COMBINED extent of all 96 pairings rather than either alone.
 *
 * ⛔ EVERY FIN IS ANCHORED TO THE BODY'S OWN EDGE, never to a typed coordinate. A corpus whose
 * premise is that every form has a different profile is the one place a coordinate constant is
 * always wrong: a dorsal is a RISE FROM THE BACK, not a height.
 *
 * Load order does not matter. Siblings are resolved at FIRST USE.
 */

var CreelFins = CreelFins || {};

(function (Fn) {
    'use strict';

    function forms() {
        var F = (typeof CreelForms !== 'undefined') ? CreelForms : null;
        if (!F) throw new Error('Creel: CreelForms.js is not loaded.');
        return F;
    }

    Fn.IDS = ['plain', 'sail', 'fork', 'lance', 'fringe', 'spine', 'paddle', 'trail'];

    /**
     * ⛔ A REPEATED TREATMENT DECLARES A PITCH AND DERIVES ITS COUNT. A count cannot express a
     * worked edge, because the right count changes with the size of the piece: scallops read as
     * scallops only when they nearly touch, and "touching" is a statement about pitch relative to
     * mark size, not about how many there are.
     *
     * ⚠️ It returns a NUMBER, deliberately. The obvious richer shape — {count, pitch, floored} —
     * is exactly what silently kills a `for (i = 0; i < n; i++)` loop when a call site reads it as
     * a scalar: `0 < {}` is false, the body never runs, and nothing throws or reads zero.
     *
     * @param {number} run  the length the treatment must cover, in unit-box units.
     * @param {number} pitch  desired spacing between marks, in unit-box units.
     * @returns {number} at least 2.
     */
    Fn.repeatsFor = function (run, pitch) {
        return Math.max(2, Math.round(Math.abs(run) / Math.max(pitch, 1e-6)));
    };

    // =============================================================================================
    // THE EIGHT SETS
    //
    //   caudal      shape of the tail fin: round | fork | lance | fan | trail
    //   caudalK     tail size, as a multiple of the form's own fin unit x the form's `tail`
    //   dorsal      shape of the back fin: low | sail | spine | fringe
    //   dorsalK     dorsal height, as a multiple of the fin unit
    //   analK       anal-fin height (0 = none)
    //   pectK       pectoral length
    //   edge        'smooth' | 'scallop' | 'saw' — what the trailing edge DOES.
    //
    // ⛔ `edge` IS NOT DECORATION. Two things of the same gross shape are told apart by what their
    // outline does at the trailing edge, never by what is drawn inside them — interior detail is
    // invisible at reading size. It is the axis that keeps `fringe` and `spine` apart when both are
    // tall-finned, and no two sets may share both a caudal shape and an edge.
    // =============================================================================================

    var SET = {
        // The control. Everything else is judged against it, and it exists so a buyer's plainest
        // species still reads as a fish rather than as a body with nothing on it.
        plain: {
            caudal: 'fork', caudalK: 0.62, dorsal: 'low', dorsalK: 0.42,
            analK: 0.26, pectK: 0.40, edge: 'smooth',
            reads: 'small neat fins and a shallow fork'
        },
        // A sailfin. The dorsal runs most of the back and is TALLER than the body is deep.
        sail: {
            caudal: 'round', caudalK: 0.72, dorsal: 'sail', dorsalK: 1.30,
            analK: 0.40, pectK: 0.46, edge: 'smooth',
            reads: 'a towering sail down the whole back'
        },
        // A tuna's tail: a deep, hard, symmetrical fork and almost nothing else.
        fork: {
            caudal: 'fork', caudalK: 1.15, dorsal: 'low', dorsalK: 0.34,
            analK: 0.22, pectK: 0.52, edge: 'smooth',
            reads: 'a deeply forked tail on a spare, hard-finned body'
        },
        // A single point behind, as a swordtail or a lancetfish carries it.
        lance: {
            caudal: 'lance', caudalK: 1.25, dorsal: 'low', dorsalK: 0.52,
            analK: 0.30, pectK: 0.40, edge: 'smooth',
            reads: 'one long point behind, like a lance'
        },
        // A veiltail: everything soft, rounded and oversized.
        fringe: {
            caudal: 'fan', caudalK: 1.05, dorsal: 'fringe', dorsalK: 0.86,
            analK: 0.62, pectK: 0.62, edge: 'scallop',
            reads: 'soft oversized fins with a scalloped margin'
        },
        // Hard rays. A lionfish's spines: the same gross height as `fringe` and the opposite edge.
        spine: {
            caudal: 'fan', caudalK: 0.80, dorsal: 'spine', dorsalK: 1.05,
            analK: 0.44, pectK: 0.70, edge: 'saw',
            reads: 'stiff separated spines with a sawn margin'
        },
        // Broad rounded paddles: the caudal is a round oar and the pectorals are wings.
        paddle: {
            caudal: 'round', caudalK: 1.00, dorsal: 'low', dorsalK: 0.46,
            analK: 0.34, pectK: 0.96, edge: 'smooth',
            reads: 'broad rounded paddles and wing-like pectorals'
        },
        // Filaments. A fork whose lobe tips draw out into long trailing streamers.
        trail: {
            caudal: 'trail', caudalK: 1.20, dorsal: 'low', dorsalK: 0.56,
            analK: 0.30, pectK: 0.44, edge: 'smooth',
            reads: 'long streamers trailing from the tail lobes'
        }
    };

    /** @param {string} id */
    Fn.set = function (id) {
        return Object.prototype.hasOwnProperty.call(SET, id) ? SET[id] : undefined;
    };
    Fn.name = function (id) {
        return Object.prototype.hasOwnProperty.call(SET, id)
            ? id.charAt(0).toUpperCase() + id.slice(1) : '?';
    };
    Fn.reads = function (id) {
        var s = Fn.set(id);
        return s ? s.reads : '';
    };

    // =============================================================================================
    // THE SHARED BUDGET, AND WHY CLAMPING THE LENGTH IS NOT ENOUGH
    //
    // ⛔ MEASURED: clamping each fin's LENGTH to the form's `finBudget` left 20 of 96 pairings
    // outside the 0.5 budget disc, worst 0.7248. The mistake is a units one and it is the third
    // scale living at the same corner: `finBudget` bounds where a fin may REACH, and a length is
    // measured from an ANCHOR THAT IS ALREADY DISPLACED — a dorsal 0.36 tall growing off a back
    // already at y = -0.12 reaches -0.48, and the caudal sweeps BACKWARD from a peduncle that is
    // already most of the way to the tail end of the box.
    //
    // ⛔ AND PER-POINT CLAMPING IS NOT THE FIX EITHER: clamping each sample independently drags the
    // outside samples along the disc and BENDS the fin, silently turning a shaped margin into a
    // flat arc. A shape must be SHORTENED, not deformed.
    //
    // So: build the fin at its nominal size, then scale the whole ring UNIFORMLY about its own root
    // by the largest factor that keeps every point inside the disc. The fin keeps its shape and
    // stays attached, and the budget becomes true by construction rather than by care.
    // =============================================================================================

    // ⛔ ONE IMPLEMENTATION, TWO READERS. The fit lives in CreelForms because `extra` geometry
    // needs it as much as a fin does — a second copy here would not drift, it would WIN wherever
    // it was called, and a correct edit to the other one would silently change nothing.
    function fitToDisc(ring, rx, ry, R) { return forms().fitToDisc(ring, rx, ry, R); }
    Fn.fitFactor = function (ring, rx, ry, R) { return forms().fitFactor(ring, rx, ry, R); };

    // =============================================================================================
    // EDGE TREATMENTS
    // =============================================================================================

    /**
     * Multiplier applied to a fin's reach at parameter t, giving its trailing edge a treatment.
     * @param {string} kind  smooth | scallop | saw
     * @param {number} t  0..1 along the fin margin
     * @param {number} n  number of marks across that margin — DERIVED from a pitch, never typed.
     */
    function edgeAt(kind, t, n) {
        if (kind === 'scallop') {
            // Fine and shallow. Deep coarse lobes stop reading as a margin and become masses in
            // their own right — six lobes at 16% depth read as TEETH, measured on this product.
            return 1 - 0.060 * (0.5 - 0.5 * Math.cos(t * n * 2 * Math.PI));
        }
        if (kind === 'saw') {
            // Asymmetric: a slow rise and a sharp drop. A symmetric ripple reads as soft whatever
            // its depth, so the ASYMMETRY is what says "hard ray" rather than the amplitude.
            var f = (t * n) % 1;
            return 1 - 0.115 * f;
        }
        return 1;
    }

    // =============================================================================================
    // THE FINS
    // =============================================================================================

    /**
     * The unit a fin set sizes itself against on a given form.
     * 0 on the form means "use the body's own depth", true for eleven of the twelve — `fan`
     * overrides it because its body is small BY DESIGN and its identification is its span, so a
     * fin sized against that body would be swallowed by it.
     */
    function unitFor(F, prof) {
        return prof.spec.finUnit || (F.depth(prof) * 0.5);
    }
    Fn.unitFor = function (prof) { return unitFor(forms(), prof); };

    /**
     * The caudal fin: a sweep back from the peduncle, whose RADIUS PROFILE is its identity.
     *
     * One parameterisation covers all five shapes, which is what keeps them comparable: for t
     * across the margin, reach = k * shape(t). A fork DIPS in the middle, a lance PEAKS there, a
     * round is flat, and a trail is a fork whose ends run past the lobes.
     */
    function caudal(F, prof, s, budget) {
        var spec = prof.spec;
        if (spec.tail <= 0) return null;                 // a ray has no caudal at all
        var u = unitFor(F, prof);
        var reach = Math.min(spec.tail * u * s.caudalK, budget);
        if (reach <= 0.012) return null;

        // ⛔ THE ROOT IS PUSHED INTO THE BODY, NOT LAID AGAINST IT. Two separately-filled shapes
        // that merely touch leave a ONE-PIXEL SEAM of background between them under antialiasing —
        // visible as a pale vertical line at the tail junction of every blunt-tailed form. An
        // appendage must overlap the mass it grows from, so the join is a change of direction
        // rather than an edge.
        var OVERLAP = 0.020;
        var inner = F.span(prof, prof.x[0] + OVERLAP);
        var rootT = { x: prof.x[0] + OVERLAP, y: inner ? inner.top : prof.yt[0] };
        var rootB = { x: prof.x[0] + OVERLAP, y: inner ? inner.bot : prof.yb[0] };
        var cx = prof.x[0], cy = prof.sp[0];

        var SPREAD = (s.caudal === 'lance') ? 0.62 : 1.02;   // radians either side of straight back
        var N = 30, i, t, ang, r, shape;
        var n = Fn.repeatsFor(reach * 2, 0.030);             // edge marks, DERIVED from the run
        var pts = [rootT];
        for (i = 0; i <= N; i++) {
            t = i / N;
            ang = -SPREAD + (2 * SPREAD) * t;
            switch (s.caudal) {
                case 'fork':
                    shape = 0.34 + 0.66 * Math.pow(Math.abs(t * 2 - 1), 1.35); break;
                case 'lance':
                    shape = 0.22 + 0.78 * Math.pow(Math.sin(Math.PI * t), 1.60); break;
                case 'trail':
                    // The lobe TIPS run past the fork, which is the whole cue. A trail whose ends
                    // stop level with a fork's is just a fork.
                    shape = 0.28 + 0.72 * Math.pow(Math.abs(t * 2 - 1), 2.60);
                    shape += 0.62 * Math.pow(Math.abs(t * 2 - 1), 9.0);
                    break;
                case 'fan':
                    shape = 0.88 + 0.12 * Math.sin(Math.PI * t); break;
                default:                                     // round
                    shape = 0.80 + 0.20 * Math.sin(Math.PI * t); break;
            }
            r = reach * shape * edgeAt(s.edge, t, n);
            pts.push({
                x: cx - Math.cos(ang) * r,
                y: cy + Math.sin(ang) * r
            });
        }
        pts.push(rootB);
        return { id: 'caudal', role: F.ROLE.FIN,
                 ring: fitToDisc(pts, cx, cy, F.BODY_BOX) };
    }

    /**
     * A fin riding one edge of the body between two axial positions.
     * ⛔ Its root FOLLOWS the body's own edge, sample by sample, so a fin and the form it sits on
     * cannot desynchronise. Taking the root from a constant is how a garment ends up drawn above
     * its own waist on a differently-posed figure.
     * @param {number} side  -1 for the back, +1 for the belly.
     */
    function ridgeFin(F, prof, u0, u1, height, style, edge, side, id) {
        if (height <= 0.010) return null;
        var N = 34, i, t, u, a, h, shape;
        var run = (u1 - u0) * F.length(prof);
        var n = Fn.repeatsFor(run, 0.034);
        var root = [], marg = [];
        for (i = 0; i <= N; i++) {
            t = i / N;
            u = u0 + (u1 - u0) * t;
            a = F.anchor(prof, u, side);
            if (!a) continue;
            root.push({ x: a.x, y: a.y });
            switch (style) {
                case 'sail':
                    shape = Math.pow(Math.sin(Math.PI * t), 0.55); break;
                case 'spine':
                    // Separated hard rays: a saw whose teeth grow toward the middle of the run.
                    shape = Math.pow(Math.sin(Math.PI * t), 0.85)
                          * (0.72 + 0.28 * Math.abs(Math.sin(t * n * Math.PI)));
                    break;
                case 'fringe':
                    shape = Math.pow(Math.sin(Math.PI * t), 0.72); break;
                default:                                     // low
                    shape = Math.pow(Math.sin(Math.PI * t), 1.15); break;
            }
            h = height * shape * edgeAt(edge, t, n);
            marg.push({ x: a.x - h * 0.20, y: a.y + side * h });
        }
        if (root.length < 3) return null;
        marg.reverse();
        var mid = root[Math.floor(root.length / 2)];
        return { id: id, role: F.ROLE.FIN,
                 ring: fitToDisc(root.concat(marg), mid.x, mid.y, F.BODY_BOX) };
    }

    /**
     * A pectoral fin: a leaf springing from the flank and swept back and DOWN.
     *
     * ⛔ IT USED TO BE DRAWN ENTIRELY INSIDE THE BODY, AND NOTHING COULD SEE IT. Anchored at the
     * form's `pect` side fraction (0.4-0.95 of the way from spine to belly, i.e. INSIDE the
     * outline) and swept `pectK * unit * 1.35` — about 0.067 on a spindle — it never once reached
     * the body's own edge. So `pectK` ranged 0.40 to 0.96 across the eight sets, a 2.4x spread,
     * and changed NOTHING about any silhouette; `paddle`, whose entire stated identity is
     * "wing-like pectorals", had none at all.
     *
     * ⚠️ It was invisible to every instrument. The ring was built, filled and counted; the
     * collision sweep saw a real difference between sets because the OTHER fins differ; and in
     * flat ink the buried fin showed only as a faint pale seam where its antialiased edge lay
     * under the body's. It was found by drawing every part in its own colour and looking.
     *
     * Three changes, and the first is the one that matters: the fin is ROOTED ON THE BODY'S OWN
     * EDGE (side 1.0 = the belly line) rather than inside it, so any length at all projects; the
     * sweep is steeper so it clears a deep-bellied form; and the reach is scaled against the fin
     * unit rather than a third of it.
     */
    function pectoral(F, prof, s, budget) {
        var u = unitFor(F, prof);
        // ⛔ A PECTORAL'S LENGTH IS A LONGITUDINAL DIMENSION AND MUST COME FROM THE BODY'S LENGTH,
        // NOT FROM A DEPTH-DERIVED UNIT. Sized at `pectK * unit * 2.35`, a fringe pectoral on the
        // round-bodied `disc` came out 0.353 long against a body only 0.475 long — 74% of the fish
        // — and swept back over the whole belly, BURYING THE ANAL FIN in the three sets with the
        // largest pectorals. That is the same defect this function was just fixed for, recreated
        // one part over, and the with/without check caught it the first time it ran.
        //
        // The `unit` floor stays so a very short body still gets a fin that reads; because the
        // root now sits ON the body's edge, any length at all projects.
        var len = Math.min(Math.max(s.pectK * F.length(prof) * 0.42, 0.34 * u), budget * 0.85);
        if (len <= 0.012) return null;
        // Root ON the edge, not in the flank. `pect[1]` still chooses WHERE along the flank the
        // fin sits for this form, but it can no longer bury it.
        var a = F.anchor(prof, prof.spec.pect[0], 1.0);
        if (!a) return null;
        var N = 18, i, t, pts = [], back = [];
        for (i = 0; i <= N; i++) {
            t = i / N;
            // swept back and down, widening then closing — a leaf, not a stick
            // ⛔ DOWN MORE THAN BACK. At 0.78 back / 0.72 down the fin ran aft along the belly and
            // landed on top of the ANAL fin, burying it on every round-bodied form. A pectoral is
            // held OUT from the flank just behind the gill cover; it is the anal fin that lies
            // aft, and the two only fight when the pectoral is drawn as a trailing streamer.
            var ax = a.x - len * t * 0.34;
            var ay = a.y + len * t * 0.94;
            var w = len * 0.30 * Math.sin(Math.PI * Math.pow(t, 0.85));
            pts.push({ x: ax, y: ay - w });
            back.push({ x: ax, y: ay + w });
        }
        back.reverse();
        return { id: 'pect', role: F.ROLE.FIN,
                 ring: fitToDisc(pts.concat(back), a.x, a.y, F.BODY_BOX) };
    }

    /**
     * Every fin of one set on one form, as rings in unit-box coordinates.
     * ⚠️ An unknown form id or set id returns an EMPTY array and never throws — a buyer's custom
     * species must not crash a fishing scene.
     * @returns {Array<{id:string, role:string, ring:Array<{x:number,y:number}>}>}
     */
    Fn.parts = function (prof, setId) {
        var F = forms(), s = Fn.set(setId), out = [], p;
        if (!prof || !s) return out;
        var spec = prof.spec;
        var u = unitFor(F, prof);

        // ⛔ THE BUDGET IS THE FORM'S, AND IT IS SPENT AGAINST WHAT THE BODY ALREADY REACHES.
        // A fin's own budget is what is LEFT: the form declares the furthest any fin on it may
        // reach, and a fin growing from a deep belly starts closer to that ceiling than one growing
        // from a shallow back.
        var budget = spec.finBudget;

        p = caudal(F, prof, s, budget);
        if (p) out.push(p);

        p = ridgeFin(F, prof, spec.dorsal0, spec.dorsal1,
            Math.min(s.dorsalK * u, budget * 0.80), s.dorsal, s.edge, -1, 'dorsal');
        if (p) out.push(p);

        // The anal fin sits BEHIND the dorsal's run, not under it — two fins mirrored about the
        // spine at the same station read as one lens with a line through it.
        // ⚠️ AND THE ANAL FIN RUNS AFT, ending well before the pectoral's station. Anatomically
        // that is simply where an anal fin is, and it is what stops the two competing for the same
        // stretch of belly on a short deep body.
        p = ridgeFin(F, prof, spec.dorsal0 * 0.80, spec.dorsal0 + (spec.dorsal1 - spec.dorsal0) * 0.45,
            Math.min(s.analK * u, budget * 0.70), 'low', s.edge, 1, 'anal');
        if (p) out.push(p);

        p = pectoral(F, prof, s, budget);
        if (p) out.push(p);

        return out;
    };

    /** Greatest distance from the origin reached by body + extras + this fin set. */
    Fn.combinedExtent = function (prof, setId) {
        var F = forms(), s0 = Fn.set(setId);
        var m = F.extentWithExtras(prof, s0 ? { caudalK: s0.caudalK } : null);
        var ps = Fn.parts(prof, setId), i, j, p, d;
        for (i = 0; i < ps.length; i++) {
            for (j = 0; j < ps[i].ring.length; j++) {
                p = ps[i].ring[j];
                d = Math.sqrt(p.x * p.x + p.y * p.y);
                if (d > m) m = d;
            }
        }
        return m;
    };

})(CreelFins);

if (typeof module !== 'undefined' && module.exports) module.exports = CreelFins;
