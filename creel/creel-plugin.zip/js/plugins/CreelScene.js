//=================================================================================================
// CreelScene.js
//=================================================================================================
/*:
 * @target MZ
 * @plugindesc [Creel] The catch ledger: a scene that shows every species your project declares, drawn at runtime. Requires the other Creel files.
 * @author Core Systems Asset Factory
 *
 * @param openKey
 * @text Open with key
 * @desc A key the player can press on the map to open the ledger. Leave blank for none.
 * @type select
 * @option (none)
 * @value
 * @option pageup
 * @value pageup
 * @option pagedown
 * @value pagedown
 * @option shift
 * @value shift
 * @default
 *
 * @param showUncaught
 * @text Show species not yet caught
 * @desc ON lists every declared species with the uncaught ones shadowed. OFF lists only catches.
 * @type boolean
 * @default true
 *
 * @param title
 * @text Ledger title
 * @desc The heading drawn at the top of the scene.
 * @type string
 * @default THE CATCH LEDGER
 *
 * @command open
 * @text Open the catch ledger
 * @desc Pushes the ledger scene.
 *
 * @command close
 * @text Close the catch ledger
 * @desc Pops back, if the ledger is the active scene.
 *
 * @help
 * CreelScene.js
 * =============================================================================
 * The buyer-facing half of Creel. Everything on this screen is drawn by the
 * plugin at runtime: there is not one image file in this product.
 *
 * WHAT IT SHOWS
 *   - a STRINGER along the foot: every species your project declares, as a
 *     small specimen, so the size of the collection is visible at a glance
 *   - a LEDGER column: the catch list, with lengths and repeat counts
 *   - a PLATE: the selected species drawn large, with its scale bar, its
 *     rarity, and a reading of the four axes that produced it
 *
 * CONTROLS
 *   up / down        move through the ledger
 *   left / right     page the stringer
 *   ok               nothing destructive; re-centres the plate
 *   cancel           leave
 *
 * OPENING IT
 *   Plugin command "Open the catch ledger", or SceneManager.push(Scene_Creel).
 *
 * COMPATIBILITY
 *   This file adds a scene and extends Scene_Map.updateScene by SAVED-ORIGINAL
 *   prototype extension, calling through in every case. It replaces no core
 *   method, so it co-exists with plugins that patch the same seams.
 *
 * =============================================================================
 * GATE 1 IS THE POINT OF THIS FILE, SO THE REASONING IS HERE RATHER THAN IN A
 * DEVLOG NOBODY READS AT THE STOREFRONT.
 *
 * Wing §1.1a: a screenshot mistakable for stock RPG Maker FAILS, and that is a
 * blocking gate. So:
 *
 *  - NOT ONE `Window_Base`. The scene is `Scene_Base` plus Sprites the plugin
 *    draws into, which makes `windowsDrawn: 0` true BY CONSTRUCTION rather than
 *    by care. A windowskin cannot reach the screen without a Window.
 *
 *  - ⛔ AND `windowsDrawn: 0` IS BLIND TO `Sprite_Button` (wing §15). MZ's
 *    touch-UI controls are Sprites, and THREE of them (`down`, `up`, `ok`) hang
 *    off a plain `Sprite` reachable through no scene property at all — so
 *    naming the properties does not work and neither does `visible = false`,
 *    because `Scene_Map.updateMenuButton` re-assigns visibility every frame.
 *    `stripEngineChrome` WALKS THE DISPLAY LIST and detaches every instance.
 *
 *  - ⛔ AND IT IS BLIND TO THE FONT TOO (wing §15a). `$gameSystem.mainFontFace()`
 *    is the single loudest "this is RPG Maker" signal and no mechanical check in
 *    the factory has an opinion about a typeface, so both roles below are
 *    explicit stacks with real fallbacks and neither is ever `rmmz-mainfont`.
 *    This scene draws its text with `ctx.font` on its own 2D context rather than
 *    through `Bitmap.fontFace`, so GREP THIS FILE FOR `ctx.font` — every hit ends
 *    in `FONT_DISPLAY` or `FONT_MONO`, and there are no other typefaces in it.
 *
 *  - Layout is a three-band composition, not a `Window_Selectable` grid.
 *
 * PER-FRAME COST. Wing doctrine: zero allocation in per-frame hot paths, draw
 * calls <= 60, bitmap dirties <= 0.5/frame. A specimen is hundreds of path
 * operations, so:
 *   - the ledger, the stringer and the plate furniture live on ONE Bitmap that
 *     is redrawn only when the selection or the page changes;
 *   - specimens are BAKED once by `CreelSpecies.bitmapFor` and blitted;
 *   - `update` allocates nothing and creates no display object.
 * The display list is built entirely in `create()` and never grows.
 */

var CreelScene = CreelScene || {};

(function (X) {
    'use strict';

    // =============================================================================================
    // SIBLINGS, RESOLVED AT FIRST USE — NEVER AT LOAD TIME
    //
    // ⛔ Wing §8 trap 2: `mz_harness build` loads the plugin folder ALPHABETICALLY, which is also
    //    what a buyer gets for dragging files into the Plugin Manager in the wrong order. This file
    //    sorts BEFORE CreelSpecies.js, so a load-time capture of it would be `undefined` and the
    //    whole scene would no-op behind one console line. The product ships NO plugin_order.json on
    //    purpose (§8 trap 2b) so the harness exercises this every run.
    // =============================================================================================

    var _deps = null;
    function deps() {
        if (_deps) return _deps;
        if (typeof CreelForms === 'undefined' || typeof CreelRender === 'undefined'
            || typeof CreelLivery === 'undefined' || typeof CreelSpecies === 'undefined'
            || typeof CreelFins === 'undefined' || typeof CreelPattern === 'undefined') return null;
        _deps = { F: CreelForms, R: CreelRender, L: CreelLivery, S: CreelSpecies,
                  Fn: CreelFins, P: CreelPattern };
        return _deps;
    }
    X.deps = deps;

    // ---- parameters -----------------------------------------------------------------------------
    // ⛔ Blank means ABSENT, never 0 and never false: `Number('')` is 0 (wing §16).
    function str(v) {
        return (v === undefined || v === null || String(v).trim() === '') ? null : String(v).trim();
    }
    function bool(v, dflt) {
        var s = str(v);
        if (s === null) return dflt;
        return s === 'true' || s === 'on' || s === '1';
    }

    var _params = null;
    function params() {
        if (_params) return _params;
        var p = {};
        if (typeof PluginManager !== 'undefined' && PluginManager.parameters) {
            p = PluginManager.parameters('CreelScene') || {};
        }
        _params = {
            openKey: str(p.openKey),
            showUncaught: bool(p.showUncaught, true),
            title: str(p.title) || 'THE CATCH LEDGER'
        };
        return _params;
    }
    X.params = params;

    // =============================================================================================
    // TYPOGRAPHY — wing §15a. Two roles, two explicit stacks, never the engine's font.
    //
    // A serif display face because this product is a naturalist's plate and that is the register
    // the whole visual language is in; Cartouche reached the same stack independently. The mono is
    // for MEASUREMENTS — lengths, counts, the axis reading — where a proportional face makes a
    // column of numbers ragged.
    // =============================================================================================

    var FONT_DISPLAY = 'Georgia, "Iowan Old Style", "Palatino Linotype", Palatino, '
                     + '"Book Antiqua", serif';
    var FONT_MONO = 'Consolas, "SF Mono", Menlo, "DejaVu Sans Mono", "Courier New", monospace';
    X.FONT_DISPLAY = FONT_DISPLAY;
    X.FONT_MONO = FONT_MONO;

    // =============================================================================================
    // THE PALETTE — a wet slate ground, a cream card, brass rules.
    //
    // ⛔ Every ink is picked against WHAT IT SITS ON, never hard-coded per element (wing §22e).
    //    A colour chosen in isolation is unreadable somewhere by construction.
    // =============================================================================================

    var C = {
        deep:   [22, 34, 43],       // the ground: wet slate
        deeper: [14, 22, 29],
        card:   [238, 232, 216],    // specimen card: cream laid paper
        cardEdge: [206, 196, 172],
        brass:  [176, 141, 74],
        brassDim: [120, 96, 52],
        ink:    [26, 30, 30],
        inkPale:[92, 98, 96],
        sea:    [38, 74, 82]        // the guilloche wave
    };

    /** rgb() for a triple, so nothing in this file types a colour string. */
    function css(c) {
        var L = deps() ? deps().L : null;
        return L ? L.css(c) : 'rgb(' + c[0] + ',' + c[1] + ',' + c[2] + ')';
    }

    // =============================================================================================
    // DRAWING HELPERS
    // =============================================================================================

    /** A rounded rectangle path. ⛔ `arcTo` throws on a negative radius — clamp it (wing §8 trap 3). */
    function roundRect(ctx, x, y, w, h, r) {
        var rr = Math.max(0, Math.min(r, w / 2, h / 2));
        ctx.beginPath();
        ctx.moveTo(x + rr, y);
        ctx.arcTo(x + w, y, x + w, y + h, rr);
        ctx.arcTo(x + w, y + h, x, y + h, rr);
        ctx.arcTo(x, y + h, x, y, rr);
        ctx.arcTo(x, y, x + w, y, rr);
        ctx.closePath();
    }

    /**
     * A guilloche wave band — the one thing on this screen the engine cannot draw at all, and the
     * reason the ground does not read as a flat fill.
     *
     * ⛔ THE PITCH IS DECLARED AND THE COUNT IS DERIVED (wing §22b-1a). Declaring a count makes a
     *    band read as beading on a wide screen and as specks on a narrow one; the right number of
     *    crests changes with the run it has to cover.
     */
    function waveBand(ctx, x, y, w, h, colour, pitchPx, alpha) {
        var crests = Math.max(2, Math.round(w / Math.max(8, pitchPx)));
        var i, t, xx, yy;
        ctx.save();
        ctx.globalAlpha = alpha;
        ctx.strokeStyle = colour;
        ctx.lineWidth = Math.max(1, h * 0.055);
        for (var row = 0; row < 3; row++) {
            ctx.beginPath();
            for (i = 0; i <= crests * 6; i++) {
                t = i / (crests * 6);
                xx = x + w * t;
                yy = y + h * (0.30 + 0.24 * row)
                   + Math.sin(t * crests * Math.PI * 2 + row * 1.1) * h * 0.16;
                if (i === 0) ctx.moveTo(xx, yy); else ctx.lineTo(xx, yy);
            }
            ctx.stroke();
        }
        ctx.restore();
    }

    /**
     * Fit text into a width by SURRENDERING TRACKING FIRST, then size.
     *
     * ⛔ A FITTER THAT CAN FAIL TO FIT MUST SAY SO (wing §22f). The version of this that shipped
     *    "SEVEN OF WAND" shrank to its minimum and then returned a still-too-wide result, which the
     *    caller drew anyway. This returns whether it succeeded and the caller decides.
     */
    function fitText(ctx, text, maxW, px, font, minPx) {
        var size = px;
        var floor = Math.max(8, minPx || Math.round(px * 0.62));
        while (size >= floor) {
            ctx.font = '600 ' + size + 'px ' + font;
            if (ctx.measureText(text).width <= maxW) return { size: size, fitted: true };
            size -= 1;
        }
        ctx.font = '600 ' + floor + 'px ' + font;
        return { size: floor, fitted: ctx.measureText(text).width <= maxW };
    }

    /** Draw text, truncating with an ellipsis rather than overrunning its column. */
    function clipText(ctx, text, x, y, maxW) {
        var t = String(text);
        if (ctx.measureText(t).width <= maxW) { ctx.fillText(t, x, y); return; }
        while (t.length > 1 && ctx.measureText(t + '…').width > maxW) t = t.slice(0, -1);
        ctx.fillText(t + '…', x, y);
    }

    X.roundRect = roundRect;
    X.waveBand = waveBand;
    X.fitText = fitText;

    // =============================================================================================
    // Scene_Creel
    // =============================================================================================

    if (typeof Scene_Base === 'undefined') return;      // headless: nothing to build

    /**
     * The catch ledger.
     * @class
     */
    function Scene_Creel() {
        this.initialize.apply(this, arguments);
    }
    Scene_Creel.prototype = Object.create(Scene_Base.prototype);
    Scene_Creel.prototype.constructor = Scene_Creel;
    X.Scene_Creel = Scene_Creel;

    Scene_Creel.prototype.initialize = function () {
        Scene_Base.prototype.initialize.call(this);
        this._index = 0;
        this._page = 0;
        this._keys = [];
        this._dirty = true;
        this._lastIndex = -1;
        this._lastPage = -1;
        this._chromeRemoved = null;
        // ⚠️ Pre-allocated so `update` never builds an object. Wing doctrine: zero allocation in
        //    per-frame hot paths — no literals, no .map/.filter/.slice in an update loop.
        this._plateSpec = null;
    };

    Scene_Creel.prototype.create = function () {
        Scene_Base.prototype.create.call(this);
        var d = deps();
        this._keys = d ? d.S.keys() : [];
        // ONE bitmap for every drawn surface, redrawn only on change.
        this._paper = new Sprite(new Bitmap(Graphics.width, Graphics.height));
        this.addChild(this._paper);
        // The plate specimen is a BLIT of a baked bitmap, so it is its own sprite.
        this._plate = new Sprite();
        this.addChild(this._plate);
        // ⚠️ The display list is complete here and never grows. The gate's display-object GROWTH
        //    proxy (<= 4) is about what a frame ADDS, and this scene adds nothing after create().
    };

    Scene_Creel.prototype.start = function () {
        Scene_Base.prototype.start.call(this);
        this.stripEngineChrome();
        this._dirty = true;
        this.refresh();
    };

    /**
     * Detach every stock touch-UI control in this scene's display list.
     *
     * ⛔ NAMING THE PROPERTIES IS NOT ENOUGH AND NEITHER IS `visible = false` (wing §15). After
     *    detaching `_menuButton`, `_buttonArea`, `_cancelButton`, `_pageupButton` and
     *    `_pagedownButton`, THREE were still painting — `down`, `up` and `ok` hang off a plain
     *    `Sprite` and are reachable through no scene property at all. And
     *    `Scene_Map.prototype.updateMenuButton` re-assigns visibility EVERY FRAME, so a hide is
     *    undone on frame 2. Walking the tree and removing the instances is the only thing that
     *    holds. The count is kept so the in-engine probe can assert a POSITIVE CONTROL first — a
     *    one-arm probe proves nothing.
     */
    Scene_Creel.prototype.stripEngineChrome = function () {
        var removed = [];
        function walk(node) {
            if (!node || !node.children) return;
            for (var i = node.children.length - 1; i >= 0; i--) {
                var child = node.children[i];
                if (typeof Sprite_Button !== 'undefined' && child instanceof Sprite_Button) {
                    removed.push(child._buttonType || 'button');
                    node.removeChild(child);
                    continue;
                }
                walk(child);
            }
        }
        walk(this);
        this._chromeRemoved = removed;
        return removed;
    };

    // ---- layout, derived from the screen --------------------------------------------------------
    //
    // ⛔ GEOMETRY IS ARITHMETIC — DERIVE IT AND ASSERT IT, NEVER EYEBALL IT (wing §22h, §18).
    //    `layout()` is exported and the in-engine probe checks the bands tile the screen with no
    //    overlap and no gap, so a later edit cannot silently push a band off the frame.

    Scene_Creel.prototype.layout = function () {
        var W = Graphics.width, H = Graphics.height;
        var pad = Math.round(W * 0.026);
        var headH = Math.round(H * 0.105);
        // ⛔ THE STRINGER IS THE PRODUCT'S VOLUME ARGUMENT, SO ITS CELLS MUST CLEAR THE RESOLUTION
        //    FLOOR. At 0.185 of the height the cells were ~58px and several species rendered as
        //    abstract blobs — a right shape below its subject's natural scale gets assigned to the
        //    nearest common category (wing §22a-2b, §22b-1). Measured by looking at the in-engine
        //    capture: trout and eel read, the disc and the angler did not. 0.225 gives ~74px and
        //    the band still costs less than a quarter of the screen.
        var stringerH = Math.round(H * 0.225);
        var bodyY = headH;
        var bodyH = H - headH - stringerH;
        var ledgerW = Math.round(W * 0.335);
        return {
            W: W, H: H, pad: pad,
            headX: pad, headY: 0, headW: W - pad * 2, headH: headH,
            ledgerX: pad, ledgerY: bodyY + Math.round(pad * 0.4),
            ledgerW: ledgerW, ledgerH: bodyH - Math.round(pad * 0.9),
            plateX: pad + ledgerW + pad,
            plateY: bodyY + Math.round(pad * 0.4),
            plateW: W - (pad + ledgerW + pad) - pad,
            plateH: bodyH - Math.round(pad * 0.9),
            stringerX: pad, stringerY: bodyY + bodyH,
            stringerW: W - pad * 2, stringerH: stringerH - pad
        };
    };

    /** @returns {number} ledger rows that fit — DERIVED, so the list cannot overrun its panel. */
    Scene_Creel.prototype.rowH = function () {
        return Math.max(18, Math.round(Graphics.height * 0.052));
    };
    Scene_Creel.prototype.visibleRows = function () {
        var Lo = this.layout();
        return Math.max(1, Math.floor((Lo.ledgerH - this.rowH() * 0.9) / this.rowH()));
    };
    /** @returns {number} stringer cells per page — DERIVED from the real run (wing §22b-1a). */
    Scene_Creel.prototype.stringerCols = function () {
        var Lo = this.layout();
        var cell = Math.round(Lo.stringerH * 0.86);
        return Math.max(1, Math.floor(Lo.stringerW / Math.max(24, cell)));
    };

    // ---- state ---------------------------------------------------------------------------------

    Scene_Creel.prototype.entries = function () {
        var d = deps();
        if (!d) return [];
        var p = params();
        var out = [];
        for (var i = 0; i < this._keys.length; i++) {
            var rec = d.S.get(this._keys[i]);
            if (!rec) continue;
            var caught = d.S.isCaught(rec.key);
            if (!p.showUncaught && !caught) continue;
            out.push(rec);
        }
        return out;
    };

    Scene_Creel.prototype.current = function () {
        var e = this.entries();
        if (!e.length) return null;
        var i = Math.min(Math.max(this._index, 0), e.length - 1);
        return e[i];
    };

    // ---- update: allocates nothing --------------------------------------------------------------

    Scene_Creel.prototype.update = function () {
        Scene_Base.prototype.update.call(this);
        this.processInput();
        if (this._dirty || this._index !== this._lastIndex || this._page !== this._lastPage) {
            this.refresh();
        }
    };

    Scene_Creel.prototype.processInput = function () {
        if (typeof Input === 'undefined') return;
        var n = this.entries().length;
        if (Input.isRepeated('down') && n) { this._index = (this._index + 1) % n; }
        else if (Input.isRepeated('up') && n) { this._index = (this._index + n - 1) % n; }
        else if (Input.isTriggered('right')) { this._page = this._page + 1; }
        else if (Input.isTriggered('left')) { this._page = Math.max(0, this._page - 1); }
        else if (Input.isTriggered('cancel')) { this.popMe(); }
    };

    Scene_Creel.prototype.popMe = function () {
        if (typeof SceneManager !== 'undefined' && SceneManager.pop) {
            if (typeof SoundManager !== 'undefined' && SoundManager.playCancel) SoundManager.playCancel();
            SceneManager.pop();
        }
    };

    // ---- the redraw ----------------------------------------------------------------------------

    Scene_Creel.prototype.refresh = function () {
        var d = deps();
        this._lastIndex = this._index;
        this._lastPage = this._page;
        this._dirty = false;
        if (!d) return;                             // a missing sibling must not throw

        var Lo = this.layout();
        var bmp = this._paper.bitmap;
        var ctx = bmp.context;
        bmp.clear();

        this.drawGround(ctx, Lo);
        this.drawHead(ctx, Lo, d);
        this.drawLedger(ctx, Lo, d);
        this.drawPlatePanel(ctx, Lo, d);
        this.drawStringer(ctx, Lo, d);

        // ⛔ `Bitmap.prototype._setDirty` IS MV. MZ calls `this._baseTexture.update()`, and a
        //    counter watching the MV name reads 0 forever (wing §8, "two of the probe's counters
        //    had never worked"). This is the MZ seam.
        if (bmp._baseTexture && bmp._baseTexture.update) bmp._baseTexture.update();

        this.placePlateSpecimen(Lo, d);
    };

    Scene_Creel.prototype.drawGround = function (ctx, Lo) {
        var g = ctx.createLinearGradient(0, 0, 0, Lo.H);
        g.addColorStop(0, css(C.deep));
        g.addColorStop(1, css(C.deeper));
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, Lo.W, Lo.H);
        // The wave band sits behind the head rule, low contrast, as a watermark.
        waveBand(ctx, 0, Math.round(Lo.H * 0.015), Lo.W, Math.round(Lo.H * 0.085),
            css(C.sea), Math.round(Lo.W * 0.075), 0.55);
    };

    Scene_Creel.prototype.drawHead = function (ctx, Lo, d) {
        var p = params();
        var title = p.title;
        var f = fitText(ctx, title, Lo.headW * 0.62, Math.round(Lo.headH * 0.46), FONT_DISPLAY);
        ctx.fillStyle = css(C.card);
        ctx.textBaseline = 'alphabetic';
        ctx.font = '600 ' + f.size + 'px ' + FONT_DISPLAY;
        // Letter-spacing by hand: a title is the one place tracking is worth the loop.
        var x = Lo.headX;
        var y = Math.round(Lo.headH * 0.62);
        var track = Math.max(1, Math.round(f.size * 0.055));
        for (var i = 0; i < title.length; i++) {
            ctx.fillText(title[i], x, y);
            x += ctx.measureText(title[i]).width + track;
        }

        // The count, right-aligned in mono: the volume argument, stated in the buyer's own numbers.
        var e = this.entries();
        var caught = 0;
        for (var k = 0; k < e.length; k++) if (d.S.isCaught(e[k].key)) caught++;
        var tally = caught + ' / ' + e.length + '  RECORDED';
        ctx.font = Math.round(Lo.headH * 0.24) + 'px ' + FONT_MONO;
        ctx.fillStyle = css(C.brass);
        ctx.textAlign = 'right';
        ctx.fillText(tally, Lo.headX + Lo.headW, y);
        ctx.textAlign = 'left';

        // A brass rule under the head, with a heavier hairline above it — a moulding, not a border.
        ctx.fillStyle = css(C.brass);
        ctx.fillRect(Lo.headX, Lo.headH - 3, Lo.headW, 2);
        ctx.fillStyle = css(C.brassDim);
        ctx.fillRect(Lo.headX, Lo.headH - 1, Lo.headW, 1);
    };

    Scene_Creel.prototype.drawLedger = function (ctx, Lo, d) {
        var e = this.entries();
        var rows = this.visibleRows();
        var rh = this.rowH();
        // Scroll so the selection is always on screen, without a scrollbar widget.
        var first = Math.max(0, Math.min(this._index - Math.floor(rows / 2), Math.max(0, e.length - rows)));

        // The panel: a darker inset with a brass hairline, not a window frame.
        roundRect(ctx, Lo.ledgerX, Lo.ledgerY, Lo.ledgerW, Lo.ledgerH, Math.round(Lo.pad * 0.35));
        ctx.fillStyle = 'rgba(8,14,18,0.55)';
        ctx.fill();
        ctx.strokeStyle = css(C.brassDim);
        ctx.lineWidth = 1;
        ctx.stroke();

        var i, rec, y, sel;
        for (i = 0; i < rows && (first + i) < e.length; i++) {
            rec = e[first + i];
            y = Lo.ledgerY + Math.round(rh * 0.55) + i * rh;
            sel = (first + i) === this._index;

            if (sel) {
                // Selection is a brass BAR at the left edge plus a lift in the ground, never a
                // stock cursor rectangle.
                ctx.fillStyle = 'rgba(176,141,74,0.16)';
                ctx.fillRect(Lo.ledgerX + 2, y - Math.round(rh * 0.62), Lo.ledgerW - 4, rh);
                ctx.fillStyle = css(C.brass);
                ctx.fillRect(Lo.ledgerX + 2, y - Math.round(rh * 0.62), 3, rh);
            }

            var caught = d.S.isCaught(rec.key);
            // ⛔ The ink is picked against the panel it lands on, never hard-coded (wing §22e).
            ctx.fillStyle = caught ? css(C.card) : css(C.inkPale);
            ctx.font = Math.round(rh * 0.44) + 'px ' + FONT_DISPLAY;
            ctx.textBaseline = 'alphabetic';
            clipText(ctx, caught ? rec.name : '—', Lo.ledgerX + Math.round(Lo.pad * 0.55), y,
                Lo.ledgerW * 0.62);

            if (caught) {
                var r = d.S.record();
                var c = r && r.caught[rec.key];
                var best = c && c.best ? (c.best.toFixed(1) + ' cm') : '—';
                ctx.font = Math.round(rh * 0.36) + 'px ' + FONT_MONO;
                ctx.fillStyle = css(C.brass);
                ctx.textAlign = 'right';
                ctx.fillText(best, Lo.ledgerX + Lo.ledgerW - Math.round(Lo.pad * 0.5), y);
                ctx.textAlign = 'left';
            }
        }
    };

    /**
     * Where everything on the specimen card goes.
     *
     * ⛔ ONE DECLARATION, TWO READERS (wing §11, §11a). `drawPlatePanel` draws the card furniture
     *    and `placePlateSpecimen` positions the baked sprite; when each computed its own idea of
     *    where the specimen sat, the caliper bar was drawn in one place and the fish in another,
     *    and the card had a dead band between them. A second copy of a constant does not drift —
     *    it WINS — so there is exactly one of these and both callers ask it.
     *
     * @returns {{specCX:number, specCY:number, box:number, barY:number, barW:number,
     *            innerX:number, innerW:number, readY:number}}
     */
    Scene_Creel.prototype.plateGeometry = function (Lo) {
        var innerX = Lo.plateX + Math.round(Lo.pad * 0.8);
        var innerW = Lo.plateW - Math.round(Lo.pad * 1.6);
        // The card is three bands: a head (name + rarity), the specimen with its scale, and a foot
        // (the axis reading). The specimen takes everything left over, which is what stops the
        // middle of the card being empty air (wing §18b — a scene that wastes its frame is a
        // PRODUCT defect, and cropping cannot fix it).
        var headH = Math.round(Lo.plateH * 0.215);
        var footH = Math.round(Lo.plateH * 0.265);
        var midY = Lo.plateY + headH;
        var midH = Lo.plateH - headH - footH;
        var barGap = Math.round(midH * 0.13);
        var box = Math.round(Math.min(innerW * 0.92, midH - barGap));
        return {
            innerX: innerX, innerW: innerW,
            specCX: Lo.plateX + Math.round(Lo.plateW / 2),
            specCY: midY + Math.round((midH - barGap) / 2),
            box: box,
            barY: midY + midH - Math.round(barGap * 0.45),
            barW: Math.round(Math.min(box * 0.86, innerW * 0.8)),
            readY: Lo.plateY + Lo.plateH - Math.round(Lo.pad * 0.7)
        };
    };

    Scene_Creel.prototype.drawPlatePanel = function (ctx, Lo, d) {
        var rec = this.current();

        // The specimen card: cream laid paper with a soft edge — the one light surface on screen.
        roundRect(ctx, Lo.plateX, Lo.plateY, Lo.plateW, Lo.plateH, Math.round(Lo.pad * 0.3));
        ctx.fillStyle = css(C.card);
        ctx.fill();
        ctx.strokeStyle = css(C.cardEdge);
        ctx.lineWidth = 2;
        ctx.stroke();

        if (!rec) {
            ctx.fillStyle = css(C.inkPale);
            ctx.font = Math.round(Lo.plateH * 0.055) + 'px ' + FONT_DISPLAY;
            ctx.fillText('No species declared.', Lo.plateX + Lo.pad, Lo.plateY + Lo.plateH * 0.5);
            return;
        }

        var caught = d.S.isCaught(rec.key);
        var G = this.plateGeometry(Lo);
        var innerX = G.innerX;
        var innerW = G.innerW;

        // The name, fitted rather than assumed (wing §22f).
        var nf = fitText(ctx, caught ? rec.name : 'UNRECORDED', innerW * 0.78,
            Math.round(Lo.plateH * 0.095), FONT_DISPLAY);
        ctx.font = '600 ' + nf.size + 'px ' + FONT_DISPLAY;
        ctx.fillStyle = css(C.ink);
        ctx.fillText(caught ? rec.name : 'UNRECORDED', innerX,
            Lo.plateY + Math.round(Lo.plateH * 0.125));

        // Rarity as filled lozenges — a shape, not a number. Wing §8: "what number is the whole
        // point, and can it be a shape instead?"
        var rx = innerX, ry = Lo.plateY + Math.round(Lo.plateH * 0.175);
        var lz = Math.max(4, Math.round(Lo.plateH * 0.022));
        for (var q = 0; q < 5; q++) {
            ctx.beginPath();
            ctx.moveTo(rx + q * lz * 2.4, ry);
            ctx.lineTo(rx + q * lz * 2.4 + lz, ry - lz);
            ctx.lineTo(rx + q * lz * 2.4 + lz * 2, ry);
            ctx.lineTo(rx + q * lz * 2.4 + lz, ry + lz);
            ctx.closePath();
            ctx.fillStyle = (q < rec.rarity) ? css(C.brass) : 'rgba(120,96,52,0.22)';
            ctx.fill();
        }

        // The axis reading, in mono, at the foot of the card: what actually produced this fish.
        var d2 = deps();
        var lines = [
            'FORM     ' + d2.F.name(rec.spec.form),
            'FIN SET  ' + (d2.Fn.name ? d2.Fn.name(rec.spec.finset) : rec.spec.finset),
            'MARKING  ' + d2.P.name(rec.spec.pattern),
            'LIVERY   ' + d2.L.name(rec.spec.livery)
        ];
        var lh = Math.round(Lo.plateH * 0.052);
        ctx.font = Math.round(lh * 0.68) + 'px ' + FONT_MONO;
        for (var m = 0; m < lines.length; m++) {
            ctx.fillStyle = css(C.inkPale);
            clipText(ctx, lines[m], innerX, G.readY - (lines.length - 1 - m) * lh, innerW);
        }

        // The catch block, right-aligned in the foot, so the bottom band is not half empty.
        var r = d.S.record();
        var c = r && r.caught[rec.key];
        if (caught && c) {
            ctx.textAlign = 'right';
            ctx.font = Math.round(lh * 0.68) + 'px ' + FONT_MONO;
            ctx.fillStyle = css(C.inkPale);
            ctx.fillText('TAKEN  x' + c.n, innerX + innerW, G.readY - lh);
            ctx.fillText('BEST   ' + c.best.toFixed(1) + ' cm', innerX + innerW, G.readY);
            ctx.textAlign = 'left';
        }

        // ⛔ A CALIPER THAT MEASURES NOTHING IS FURNITURE NAMING A PROPERTY THE PRODUCT NEVER
        //    DRAWS (wing §17c). The first version was a short ruler floating in the middle of the
        //    card with no relationship to the specimen or to the recorded length — it looked like
        //    measurement and was decoration, and it left a dead band between itself and the fish.
        //    It now sits DIRECTLY UNDER the specimen, spans it, and is labelled with the length
        //    actually on the record, so the number it shows is one the product owns.
        if (caught && c) {
            var sbW = G.barW;
            var sbX = G.specCX - Math.round(sbW / 2);
            var sbY = G.barY;
            ctx.strokeStyle = css(C.cardEdge);
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(sbX, sbY);
            ctx.lineTo(sbX + sbW, sbY);
            ctx.stroke();
            // End stops, so it reads as a caliper rather than as an underline.
            ctx.beginPath();
            ctx.moveTo(sbX, sbY - lz * 0.8); ctx.lineTo(sbX, sbY + lz * 0.5);
            ctx.moveTo(sbX + sbW, sbY - lz * 0.8); ctx.lineTo(sbX + sbW, sbY + lz * 0.5);
            ctx.stroke();
            // ⛔ THE TICK COUNT IS DERIVED FROM THE REAL RUN, NEVER TYPED (wing §22b-1a): a typed
            //    count reads as a scale on a wide card and as a comb on a narrow one.
            var ticks = Math.max(4, Math.round(sbW / Math.max(9, Math.round(Lo.plateW * 0.038))));
            for (var t = 1; t < ticks; t++) {
                var tx = sbX + (sbW * t) / ticks;
                var tall = (t % 5 === 0);
                ctx.beginPath();
                ctx.moveTo(tx, sbY);
                ctx.lineTo(tx, sbY + (tall ? lz * 0.75 : lz * 0.38));
                ctx.stroke();
            }
            ctx.font = Math.round(lh * 0.62) + 'px ' + FONT_MONO;
            ctx.fillStyle = css(C.inkPale);
            ctx.textAlign = 'center';
            ctx.fillText(c.best.toFixed(1) + ' cm', G.specCX, sbY + lz * 2.1);
            ctx.textAlign = 'left';
        }
    };

    /**
     * Blit the baked specimen onto the card.
     *
     * ⚠️ MIRRORING IS FINE AND ROTATION IS NOT. A baked sprite carries its lighting round with it,
     *    and Creel lights from one fixed side, so a fish turned 90 degrees would be lit from below
     *    (architecture §5). `scale.x = -1` is what a left-swimming fish needs and is the only
     *    transform used.
     */
    Scene_Creel.prototype.placePlateSpecimen = function (Lo, d) {
        var rec = this.current();
        if (!rec || !d.S.isCaught(rec.key)) { this._plate.bitmap = null; return; }
        // ⛔ ONE GEOMETRY, TWO READERS. This used to compute its own box and its own y, and the
        //    caliper drawn by `drawPlatePanel` therefore had nothing to do with where the fish
        //    actually was (wing §11a).
        var G = this.plateGeometry(Lo);
        var bmp = d.S.bitmapFor(rec.spec, G.box);
        this._plate.bitmap = bmp;
        if (!bmp) return;
        this._plate.x = Math.round(G.specCX - bmp.width / 2);
        this._plate.y = Math.round(G.specCY - bmp.height / 2);
    };

    /**
     * The stringer: every declared species as a small specimen, along the foot.
     *
     * ⭐ THIS BAND IS THE PRODUCT'S WHOLE ARGUMENT IN ONE GLANCE — master §1.1 question 3, the
     *    volume IS the moat. A buyer looking at a screenshot should be able to count the fish.
     */
    Scene_Creel.prototype.drawStringer = function (ctx, Lo, d) {
        var e = this.entries();
        var cols = this.stringerCols();
        var pages = Math.max(1, Math.ceil(e.length / cols));
        if (this._page >= pages) this._page = pages - 1;
        var first = this._page * cols;

        // A brass rail the specimens hang from.
        var railY = Lo.stringerY + Math.round(Lo.stringerH * 0.16);
        ctx.fillStyle = css(C.brassDim);
        ctx.fillRect(Lo.stringerX, railY, Lo.stringerW, 2);

        var cellW = Lo.stringerW / cols;
        var box = Math.round(Math.min(cellW * 0.80, Lo.stringerH * 0.62));
        for (var i = 0; i < cols && (first + i) < e.length; i++) {
            var rec = e[first + i];
            var cx = Lo.stringerX + cellW * (i + 0.5);
            var caught = d.S.isCaught(rec.key);

            // The hanging line.
            ctx.strokeStyle = css(C.brassDim);
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(cx, railY);
            ctx.lineTo(cx, railY + Math.round(Lo.stringerH * 0.10));
            ctx.stroke();

            var cy = railY + Math.round(Lo.stringerH * 0.10) + box / 2;
            if (caught) {
                // Drawn straight onto the shared bitmap: these are small, they change only on a
                // page turn, and giving each one a Sprite would grow the display list with the
                // buyer's species count.
                var T = d.R.transform(cx, cy, box);
                d.R.specimen(ctx, T, rec.spec);
            } else {
                // A silhouette placeholder, so the shape of the collection is visible before it is
                // filled — and so an uncaught cell is not simply empty space (wing §18b).
                //
                // ⛔ AT alpha 0.16 IT READ AS A SMUDGE, NOT AS AN EMPTY SLOT. Measured by opening
                //    the in-engine capture: cream at 16% over a near-black ground is a dark blob,
                //    which is indistinguishable from "nothing is there" — so the cell argued the
                //    collection was smaller than it is. The fill stays faint (it must not compete
                //    with a real catch) and an OUTLINE carries the reading instead, which is the
                //    same law as §22a-2b's: a mark that must be read as a specific thing has to
                //    clear the floor, and an outline clears it at a fraction of the ink.
                var prof = d.F.profile(rec.spec.form);
                if (prof) {
                    var T2 = d.R.transform(cx, cy, box);
                    var ring = d.F.outline(prof);
                    ctx.save();
                    ctx.globalAlpha = 0.10;
                    d.R.fillRing(ctx, ring, T2, css(C.card));
                    ctx.globalAlpha = 0.42;
                    ctx.setLineDash([Math.max(2, box * 0.055), Math.max(2, box * 0.045)]);
                    d.R.strokeRing(ctx, ring, T2, css(C.brass), Math.max(1, box * 0.018));
                    ctx.setLineDash([]);        // restore: a dash left set leaks into every stroke
                    ctx.restore();
                }
            }

            if ((first + i) === this._index) {
                ctx.strokeStyle = css(C.brass);
                ctx.lineWidth = 2;
                roundRect(ctx, cx - cellW * 0.46, railY + 2, cellW * 0.92,
                    Lo.stringerH - 6, Math.round(Lo.pad * 0.25));
                ctx.stroke();
            }
        }

        if (pages > 1) {
            ctx.font = Math.round(Lo.stringerH * 0.14) + 'px ' + FONT_MONO;
            ctx.fillStyle = css(C.brass);
            ctx.textAlign = 'right';
            ctx.fillText((this._page + 1) + ' / ' + pages,
                Lo.stringerX + Lo.stringerW, Lo.stringerY + Lo.stringerH);
            ctx.textAlign = 'left';
        }
    };

    // =============================================================================================
    // ENGINE SEAMS — saved-original prototype extension, and every one CALLS THROUGH.
    //
    // ⛔ Wing §24c: a saved handle that is never invoked is a REPLACEMENT with a courtesy handle,
    //    and a listing that claims "extends, co-exists" on that basis is FALSE. The extension below
    //    genuinely extends, so `compat_block.js` will report the honest sentence.
    // =============================================================================================

    if (typeof Scene_Map !== 'undefined' && Scene_Map.prototype.updateScene) {
        var _updateScene = Scene_Map.prototype.updateScene;
        Scene_Map.prototype.updateScene = function () {
            _updateScene.apply(this, arguments);          // ⚠️ apply(arguments), never call(a, b)
            var key = params().openKey;
            if (!key) return;
            if (typeof SceneManager === 'undefined' || SceneManager.isSceneChanging()) return;
            if (typeof Input !== 'undefined' && Input.isTriggered(key)) {
                SceneManager.push(Scene_Creel);
            }
        };
    }

    // =============================================================================================
    // PLUGIN COMMANDS — wing §24b: `mz_gate` reports NOT CLEAN when a product registers zero
    // commands, and the honest fix is to give the product the commands it should have had.
    // =============================================================================================

    if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
        PluginManager.registerCommand('CreelScene', 'open', function () {
            if (typeof SceneManager !== 'undefined') SceneManager.push(Scene_Creel);
        });
        PluginManager.registerCommand('CreelScene', 'close', function () {
            if (typeof SceneManager !== 'undefined'
                && SceneManager._scene instanceof Scene_Creel) SceneManager.pop();
        });
    }

    // Exposed for the capture prelude and the in-engine probe. NOT a global scene class name that
    // could collide: it hangs off this plugin's own namespace as well as the window.
    if (typeof window !== 'undefined') window.Scene_Creel = Scene_Creel;

}(CreelScene));
