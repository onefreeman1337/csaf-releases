/*:
 * @target MZ
 * @plugindesc [Creel] Canvas drawing primitives. Library file; no parameters.
 * @author Core Systems Asset Factory
 *
 * @help
 * CreelRender.js
 *
 * Every mark Creel puts on a bitmap goes through this file. It takes unit-box geometry
 * (see CreelForms.js) and a transform, and draws into a plain 2D canvas context — so
 * the same code renders a specimen inside RPG Maker MZ and renders the store's own
 * contact sheets, offline. There is no second implementation of anything here.
 *
 * ⛔ PER-FRAME COST. Drawing a fish is hundreds of path operations. Nothing here runs in an
 * update loop: a specimen is rendered ONCE into a cached bitmap and thereafter blitted.
 * Allocation inside a bake is free; allocation per frame is a defect.
 *
 * Load order does not matter. Sibling files are resolved at FIRST USE, never at load time.
 */

var CreelRender = CreelRender || {};

(function (R) {
    'use strict';

    // ⛔ RESOLVE SIBLINGS AT FIRST USE, NEVER AT LOAD TIME. The Plugin Manager loads in whatever
    // order the buyer dragged the files in, and the headless harness loads them ALPHABETICALLY —
    // which is the worst case a buyer can create. Capturing a sibling at load time is how a
    // multi-file product no-ops behind one console line with every headless check green.
    function forms() {
        var F = (typeof CreelForms !== 'undefined') ? CreelForms : null;
        if (!F) throw new Error('Creel: CreelForms.js is not loaded.');
        return F;
    }
    R.forms = forms;

    // =============================================================================================
    // TRANSFORM
    //
    // Unit box [-0.5, 0.5] -> pixels. `size` is the box's full width in pixels, so a specimen
    // drawn at size 120 occupies at most 120px corner to corner of its own budget disc.
    // =============================================================================================

    /**
     * @param {number} cx  centre x, pixels
     * @param {number} cy  centre y, pixels
     * @param {number} size  unit-box width in pixels
     * @param {number} [flip]  -1 draws the fish facing LEFT. Mirroring is safe; arbitrary rotation
     *                 is not, because a baked specimen carries its lighting round with it.
     */
    R.transform = function (cx, cy, size, flip) {
        return { cx: cx, cy: cy, s: size, f: (flip === -1) ? -1 : 1 };
    };

    /** Project a unit-box point to pixels. */
    R.px = function (T, x, y) { return T.cx + x * T.s * T.f; };
    R.py = function (T, x, y) { return T.cy + y * T.s; };

    // =============================================================================================
    // PATHS
    // =============================================================================================

    /**
     * Trace one closed ring of unit-box points into the current path.
     * ⚠️ Does NOT begin or close the path — the caller decides, because a hole must be traced into
     * the SAME path as the shape it belongs to. Canvas has no "punch a hole in what I already
     * drew": `destination-out` erases to transparent through everything behind, and opening an
     * evenodd path with the shape's bounding box fills box-minus-holes, i.e. a solid rectangle.
     */
    R.traceRing = function (ctx, ring, T) {
        if (!ring || ring.length < 2) return;
        var i;
        ctx.moveTo(T.cx + ring[0].x * T.s * T.f, T.cy + ring[0].y * T.s);
        for (i = 1; i < ring.length; i++) {
            ctx.lineTo(T.cx + ring[i].x * T.s * T.f, T.cy + ring[i].y * T.s);
        }
        ctx.closePath();
    };

    /** Fill one ring in a flat colour. */
    R.fillRing = function (ctx, ring, T, colour) {
        ctx.beginPath();
        R.traceRing(ctx, ring, T);
        ctx.fillStyle = colour;
        ctx.fill();
    };

    /**
     * Stroke an OPEN polyline — a fin ray, a rib, anything that is a line rather than a boundary.
     *
     * ⚠️ Deliberately not `strokeRing`, which calls `closePath()`. Closing a two-point line strokes
     * it back over itself: the picture is identical, the cost is doubled, and any later join or cap
     * work silently applies twice.
     */
    R.strokeLine = function (ctx, pts, T, colour, w) {
        if (!pts || pts.length < 2) return;
        var i;
        ctx.beginPath();
        ctx.moveTo(T.cx + pts[0].x * T.s * T.f, T.cy + pts[0].y * T.s);
        for (i = 1; i < pts.length; i++) {
            ctx.lineTo(T.cx + pts[i].x * T.s * T.f, T.cy + pts[i].y * T.s);
        }
        ctx.strokeStyle = colour;
        ctx.lineWidth = w;
        ctx.lineCap = 'round';
        ctx.stroke();
        ctx.lineCap = 'butt';        // restore: a cap left set leaks into every later stroke
    };

    /** Stroke one ring's outline. `w` is in PIXELS, not unit-box units. */
    R.strokeRing = function (ctx, ring, T, colour, w) {
        ctx.beginPath();
        R.traceRing(ctx, ring, T);
        ctx.strokeStyle = colour;
        ctx.lineWidth = w;
        ctx.lineJoin = 'round';
        ctx.stroke();
    };

    // =============================================================================================
    // THE PEN
    //
    // ⛔ AN OUTLINE MUST BE SIZED BY THE SHAPE IT OUTLINES, NOT BY THE FIGURE. One ink width derived
    // from overall figure size and used for every mark consumes small shapes entirely: on an eye of
    // radius 3px a 2px outline is 66% of the radius and the eye becomes a dot of ink.
    //
    // The base is the SHORT SIDE of the shape's own bounding box, and the coefficient is 0.08
    // against that short side. (Stated against a RADIUS the same law reads 0.16; the two spellings
    // differ by 2x and the permissive one is a no-op on exactly the case the rule exists for.)
    // =============================================================================================

    R.PEN_MIN = 0.9;      // below this a stroke stops being a line and becomes a grey smear
    R.PEN_COEF = 0.08;

    /**
     * Pen width in pixels for a shape, bounded by the shape's own size.
     * @param {number} figurePen  the figure-scale pen, in pixels.
     * @param {Array<{x:number,y:number}>} ring  the shape being outlined.
     * @param {number} scale  pixels per unit-box unit.
     */
    R.penFor = function (figurePen, ring, scale) {
        var i, x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity;
        for (i = 0; i < ring.length; i++) {
            if (ring[i].x < x0) x0 = ring[i].x;
            if (ring[i].x > x1) x1 = ring[i].x;
            if (ring[i].y < y0) y0 = ring[i].y;
            if (ring[i].y > y1) y1 = ring[i].y;
        }
        var shortSide = Math.min(x1 - x0, y1 - y0) * scale;
        return Math.max(R.PEN_MIN, Math.min(figurePen, shortSide * R.PEN_COEF));
    };

    // =============================================================================================
    // SILHOUETTE
    //
    // The judgement instrument. Fills the body and every form-intrinsic extra in ONE flat ink.
    //
    // ⛔ A PALETTE IS NOT A COMPOSITION. The kill condition for this product is that many species
    // must not read as one fish recoloured, so distinctness is judged on the SILHOUETTE with the
    // colour held fixed. A distance measured over coloured specimens is a measure of the palette.
    // =============================================================================================

    /**
     * Draw a form's complete silhouette in one flat ink.
     * @param {CanvasRenderingContext2D} ctx
     * @param {object} prof  a CreelForms profile.
     */
    R.silhouette = function (ctx, prof, T, ink, setId) {
        var F = forms(), i;
        // FINS FIRST, so they sit behind the body — a fin is attached under the flank, and drawing
        // it over the body puts a seam across the animal the moment the two take different
        // colours. Painter's order is not a detail when the layers can differ.
        if (setId && typeof CreelFins !== 'undefined') {
            var fs = CreelFins.parts(prof, setId);
            for (i = 0; i < fs.length; i++) R.fillRing(ctx, fs[i].ring, T, ink);
        }
        R.fillRing(ctx, F.outline(prof), T, ink);
        // The fin set reaches `extra` too — on `ray` the whip IS the tail, so a set that did not
        // touch it made all eight of that form's pairings one picture.
        var set = (setId && typeof CreelFins !== 'undefined') ? CreelFins.set(setId) : null;
        var ex = F.extra(prof, set ? { caudalK: set.caudalK, caudal: set.caudal } : null);
        // Extras are filled SEPARATELY rather than traced into the body's path. Under nonzero
        // winding two overlapping rings of opposite direction cancel to a HOLE, and the winding of
        // an authored ring is not something a caller should have to reason about.
        for (i = 0; i < ex.length; i++) R.fillRing(ctx, ex[i].ring, T, ink);
    };

    // =============================================================================================
    // THE SPECIMEN — all four axes composed
    //
    // species = body plan x fin set x pattern x palette. This is the only function that knows about
    // all four, and it is the one a buyer's game calls.
    // =============================================================================================

    /**
     * Draw a complete specimen.
     * @param {object} spec {form, finset, pattern, livery, seed}
     */
    R.specimen = function (ctx, T, spec) {
        var F = forms();
        var Fn = (typeof CreelFins !== 'undefined') ? CreelFins : null;
        var P = (typeof CreelPattern !== 'undefined') ? CreelPattern : null;
        var L = (typeof CreelLivery !== 'undefined') ? CreelLivery : null;
        if (!L) throw new Error('Creel: CreelLivery.js is not loaded.');

        var prof = F.profile(spec.form);
        var liv = L.liv(spec.livery);
        // ⚠️ An unknown id is SKIPPED, never thrown: a buyer's custom species must not crash a
        // fishing scene halfway through drawing it.
        if (!prof || !liv) return false;

        var i, set = (Fn && spec.finset) ? Fn.set(spec.finset) : null;

        // 1. FINS, behind the body. A fin attaches under the flank; drawing it over the body puts
        //    a seam across the animal the moment the two take different colours — and here they
        //    always do.
        // ⛔ THE CONTOUR IS COMPUTED FIRST AND APPLIED TO EVERY PART, NOT JUST THE BODY. Stroking
        //    only the body left `fan` — whose identity IS its span, drawn in fin colour — as an
        //    invisible ghost on the pale liveries, because the outermost thing on that form is not
        //    the body at all. Whichever part reaches furthest is the one carrying the silhouette.
        var mid = L.bodyAt(liv, 0.45);
        var edge = L.css(L.relief(mid, L.lum(mid) > 128 ? -1 : +1, 52));
        var pen = Math.max(1, T.s * 0.0075);

        if (Fn && spec.finset) {
            var fs = Fn.parts(prof, spec.finset);
            for (i = 0; i < fs.length; i++) {
                R.fillRing(ctx, fs[i].ring, T, L.css(L.roleColour(liv, fs[i].role, liv.fin)));
                R.strokeRing(ctx, fs[i].ring, T, edge, pen);
            }
        }

        // 2. THE BODY, counter-shaded. Dark above, pale below — the single strongest cue that a
        //    shape is a fish rather than a leaf, and it costs one gradient.
        var yTop = Infinity, yBot = -Infinity;
        for (i = 0; i <= prof.n; i++) {
            if (prof.yt[i] < yTop) yTop = prof.yt[i];
            if (prof.yb[i] > yBot) yBot = prof.yb[i];
        }
        var g = ctx.createLinearGradient(0, T.cy + yTop * T.s, 0, T.cy + yBot * T.s);
        for (i = 0; i <= 6; i++) g.addColorStop(i / 6, L.css(L.bodyAt(liv, i / 6)));
        ctx.beginPath();
        R.traceRing(ctx, F.outline(prof), T);
        ctx.fillStyle = g;
        ctx.fill();

        // 2b. THE CONTOUR. ⛔ A SPECIMEN IS DRAWN ONTO A GROUND THIS PRODUCT DOES NOT OWN.
        //     MEASURED by looking: the `albino` livery (body [242,232,228] over [252,248,246])
        //     rendered as an almost invisible fish — and that is not a store-plate artefact, it is
        //     what a buyer gets when they put a pale species on any light background. The specimen
        //     therefore carries its OWN edge.
        //
        //     The direction is chosen by the body's luminance, never fixed: a pale fish needs a
        //     dark contour and a dark one needs a light contour, and a hard-coded ink is invisible
        //     on half the corpus by construction. The separation is stated ABSOLUTELY, because a
        //     multiplier is a hard-coded contrast ratio that fails at both ends of the range.
        R.strokeRing(ctx, F.outline(prof), T, edge, pen);

        // 3. FORM-INTRINSIC EXTRAS, contoured for the same reason.
        var ex = F.extra(prof, set ? { caudalK: set.caudalK, caudal: set.caudal } : null);
        for (i = 0; i < ex.length; i++) {
            var exCol = L.roleColour(liv, ex[i].role, liv.fin);
            // ⛔ AN EXTRA IS MODELLED, NOT FLAT — AND THE BODY ALREADY WAS, WHICH IS THE TELL.
            //    Step 2 above lights the body with a counter-shading gradient because one flat tone
            //    does not read as a solid object. Every form-intrinsic extra was nonetheless filled
            //    with a single colour, and on `fan` — where the extra IS most of the animal — that
            //    left the biggest surface in the corpus as one unlit slab. A fin catches the same
            //    light as the flank it grows from, so it gets the same treatment; the two paths now
            //    make the same claim about the same light instead of disagreeing by omission.
            //    Separation is stated ABSOLUTELY at both ends (wing §22e-1), so a near-black livery
            //    gets all the modelling that exists rather than a proportional share of nothing.
            var exTop = Infinity, exBot = -Infinity, eq;
            for (eq = 0; eq < ex[i].ring.length; eq++) {
                if (ex[i].ring[eq].y < exTop) exTop = ex[i].ring[eq].y;
                if (ex[i].ring[eq].y > exBot) exBot = ex[i].ring[eq].y;
            }
            var exFill;
            if (exBot - exTop > 0.02) {
                var eg = ctx.createLinearGradient(0, T.cy + exTop * T.s, 0, T.cy + exBot * T.s);
                eg.addColorStop(0, L.css(L.relief(exCol, +1, 16)));
                eg.addColorStop(0.42, L.css(exCol));
                eg.addColorStop(1, L.css(L.relief(exCol, -1, 20)));
                exFill = eg;
            } else {
                exFill = L.css(exCol);        // too shallow to model: a gradient would be a band
            }
            ctx.beginPath();
            R.traceRing(ctx, ex[i].ring, T);
            ctx.fillStyle = exFill;
            ctx.fill();
            // 3b. RAYS INSIDE A LARGE EXTRA, struck at an ABSOLUTE separation from the fin they sit
            //     on. ⛔ NEVER a multiplier: a multiplier is a hard-coded contrast RATIO, so it
            //     moves a bright base tens of levels and a dark one almost none, which is exactly
            //     how `fan/abyssal` came to be 79.93% indistinguishable from the ground it was
            //     drawn on (wing §22e-1, and `CreelForms`' fanspan block for the measurement).
            //     Direction is chosen by the fin's own luminance, so neither end of the palette is
            //     a special case.
            if (ex[i].ribs && ex[i].ribs.length) {
                var ribCol = L.css(L.relief(exCol, L.lum(exCol) > 128 ? -1 : +1, 40));
                // A ray is a line INSIDE a shape, so its pen comes from the shape it marks, not
                // from the figure (wing §22a-2f). Half the contour pen reads as structure; the
                // full pen reads as a second outline.
                var ribPen = Math.max(1, pen * 0.62);
                for (var rq = 0; rq < ex[i].ribs.length; rq++) {
                    R.strokeLine(ctx, ex[i].ribs[rq], T, ribCol, ribPen);
                }
            }
            R.strokeRing(ctx, ex[i].ring, T, edge, pen);
        }

        // 4. PATTERN. ⛔ Each mark takes its ink against the ground AT ITS OWN DEPTH, not against
        //    one body colour — the body is a gradient, so a single ink is readable on the back and
        //    invisible on the belly of the very same fish.
        if (P && spec.pattern && spec.pattern !== 'plain') {
            var marks = P.parts(prof, spec.pattern, T.s, spec.seed || 1);
            for (i = 0; i < marks.length; i++) {
                var c = 0, k, mid = 0;
                for (k = 0; k < marks[i].ring.length; k++) { mid += marks[i].ring[k].y; c++; }
                mid = c ? mid / c : 0;
                var sp = F.span(prof, marks[i].ring[0].x);
                var f = sp ? (mid - sp.top) / Math.max(sp.bot - sp.top, 1e-6) : 0.5;
                var ground = L.bodyAt(liv, f);
                R.fillRing(ctx, marks[i].ring, T, L.css(L.roleColour(liv, marks[i].role, ground)));
            }
        }

        // 5. THE EYE, last, so nothing covers it. A fish with no eye reads as a dead one.
        var ey = prof.spec.eye;
        var a = F.anchor(prof, ey[0], ey[1]);
        if (a) {
            var er = Math.max(0.012, F.depth(prof) * 0.085);
            var ground2 = L.bodyAt(liv, 0.30);
            R.fillRing(ctx, F.disc(a.x, a.y, er, 14), T,
                L.css(L.relief(ground2, L.lum(ground2) > 128 ? -1 : +1, 46)));
            R.fillRing(ctx, F.disc(a.x, a.y, er * 0.48, 12), T,
                L.css(L.pickContrast(ground2, [[14, 12, 10], [246, 244, 240]])));
        }
        return true;
    };

    /** How many distinct species this corpus can produce. Derived, never typed. */
    R.volume = function () {
        var F = forms();
        var Fn = (typeof CreelFins !== 'undefined') ? CreelFins : null;
        var P = (typeof CreelPattern !== 'undefined') ? CreelPattern : null;
        var L = (typeof CreelLivery !== 'undefined') ? CreelLivery : null;
        return {
            forms: F.IDS.length,
            finsets: Fn ? Fn.IDS.length : 0,
            patterns: P ? P.IDS.length : 0,
            liveries: L ? L.IDS.length : 0,
            silhouettes: F.IDS.length * (Fn ? Fn.IDS.length : 1),
            species: F.IDS.length * (Fn ? Fn.IDS.length : 1)
                   * (P ? P.IDS.length : 1) * (L ? L.IDS.length : 1)
        };
    };

    // =============================================================================================
    // GEOMETRY CHECKS
    //
    // These are used by the suite and by the contact-sheet probe. They live in the shipped file on
    // purpose: an authored outline that self-intersects fills the wrong region SILENTLY, and the
    // check that catches it should travel with the geometry it checks.
    // =============================================================================================

    /**
     * Total turning of a closed ring, in revolutions. A simple polygon turns exactly once; a
     * figure-of-eight turns zero times.
     * ⚠️ THE CHEAP TEST, AND NOT A COMPLETE ONE. A polygon with one crossed-over flap still
     * accumulates exactly one revolution, so this passes on most real self-intersections. Use it
     * WITH R.isSimple, never instead of it.
     */
    R.turning = function (ring) {
        var n = ring.length, i, total = 0;
        for (i = 0; i < n; i++) {
            var a = ring[(i - 1 + n) % n], b = ring[i], c = ring[(i + 1) % n];
            var v1x = b.x - a.x, v1y = b.y - a.y;
            var v2x = c.x - b.x, v2y = c.y - b.y;
            var l1 = Math.sqrt(v1x * v1x + v1y * v1y);
            var l2 = Math.sqrt(v2x * v2x + v2y * v2y);
            if (l1 < 1e-12 || l2 < 1e-12) continue;
            var cross = (v1x * v2y - v1y * v2x) / (l1 * l2);
            var dot = (v1x * v2x + v1y * v2y) / (l1 * l2);
            total += Math.atan2(cross, dot);
        }
        return total / (Math.PI * 2);
    };

    function segHit(p1, p2, p3, p4) {
        function d(ax, ay, bx, by, cx, cy) { return (bx - ax) * (cy - ay) - (by - ay) * (cx - ax); }
        var d1 = d(p3.x, p3.y, p4.x, p4.y, p1.x, p1.y);
        var d2 = d(p3.x, p3.y, p4.x, p4.y, p2.x, p2.y);
        var d3 = d(p1.x, p1.y, p2.x, p2.y, p3.x, p3.y);
        var d4 = d(p1.x, p1.y, p2.x, p2.y, p4.x, p4.y);
        return ((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) &&
               ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0));
    }

    /**
     * True when no two NON-ADJACENT edges of a closed ring cross.
     * This is the definitive test that R.turning is not. O(n^2) on a few hundred points is nothing
     * in a suite and it is never run at draw time.
     */
    R.isSimple = function (ring) {
        var n = ring.length, i, j;
        for (i = 0; i < n; i++) {
            for (j = i + 1; j < n; j++) {
                if (i === j) continue;
                if (j === (i + 1) % n || i === (j + 1) % n) continue;   // adjacent
                if (i === 0 && j === n - 1) continue;                   // the closing edge
                if (segHit(ring[i], ring[(i + 1) % n], ring[j], ring[(j + 1) % n])) {
                    return false;
                }
            }
        }
        return true;
    };

})(CreelRender);

if (typeof module !== 'undefined' && module.exports) module.exports = CreelRender;
