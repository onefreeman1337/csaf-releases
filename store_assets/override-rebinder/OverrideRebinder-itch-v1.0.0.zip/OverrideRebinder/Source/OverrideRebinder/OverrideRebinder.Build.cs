// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

using UnrealBuildTool;

/*
 * Dependencies are deliberately minimal and each one is justified, because an unjustified module
 * here is a compile-time cost on every buyer's build and a surface this plugin does not need.
 */
public class OverrideRebinder : ModuleRules
{
	public OverrideRebinder(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

		// ⛔ Zero warnings is the wing's gate, and a warning is a defect. This makes the module hold
		// itself to that rather than relying on the packaging gate to notice.
		bWarningsAsErrors = true;

		PublicDependencyModuleNames.AddRange(new string[]
		{
			"Core",
			"CoreUObject",

			// THE SUBJECT OF THE PRODUCT. The exact surface used, all verified in the 5.8 tree:
			//   Classes/Components/MeshComponent.h:29   OverrideMaterials - read ONLY. The header
			//                                  states verbatim that these "must NOT be set directly
			//                                  or a race condition can occur between GC and the
			//                                  rendering thread", so every write goes through:
			//   Private/Components/MeshComponent.cpp:144 SetMaterialByName(FName, UMaterialInterface*)
			//   Private/Components/MeshComponent.cpp:55  GetMaterialByName(FName) - the snapshot read.
			//   Private/Components/StaticMeshComponent.cpp:2877 GetMaterialSlotNames() - the key set.
			// ⚠️ The defect being repaired is StaticMeshComponent.cpp:1987 / SkeletalMeshComponent.cpp
			//    :1573 calling CleanUpOverrideMaterials(), which truncates the array BY INDEX.
			"Engine",
		});

		PrivateDependencyModuleNames.AddRange(new string[]
		{
			// The whole traversal design. GetReferencers(PackageName, Out, EDependencyCategory::Package)
			// yields the on-disk packages referencing a redelivered mesh - the only packages that can
			// hold an affected override - so the tool never blanket-loads the project (wing rule).
			// ⭐ It is also what makes World Partition work with no special mode: under WP each actor
			//    is its own external package and references the mesh directly.
			"AssetRegistry",

			// The commandlet host and the package save:
			//   Editor/UnrealEd/Public/FileHelpers.h:86
			//     UEditorLoadingAndSavingUtils::SavePackages(const TArray<UPackage*>&, bool bOnlyDirty)
			"UnrealEd",

			// The undo journal is JSON on disk, so -Revert can replay a run the editor no longer has
			// in memory. Written BEFORE the first package is saved.
			// ⚠️ Json only. JsonUtilities is the UStruct<->Json bridge and nothing here uses it; an
			//    unused module is a compile cost on every buyer's build.
			"Json",

			// Packages are checked out before they are written; a read-only file is a refusal to
			// report, never a silent skip.
			//   Developer/SourceControl/Public/SourceControlHelpers.h:335 CheckOutOrAddFile
			//   Developer/SourceControl/Public/SourceControlHelpers.h:608 PackageFilename(const UPackage*)
			// The checkout is skipped entirely when ISourceControlModule::Get().IsEnabled() is false,
			// so a project with no source control pays nothing and is not blocked by it.
			"SourceControl",
		});
	}
}
