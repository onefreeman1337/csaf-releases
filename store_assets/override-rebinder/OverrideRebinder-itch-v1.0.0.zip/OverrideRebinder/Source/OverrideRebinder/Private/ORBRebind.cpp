// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

#include "ORBRebind.h"

#include "AssetRegistry/AssetRegistryModule.h"
#include "AssetRegistry/IAssetRegistry.h"
#include "Components/MeshComponent.h"
#include "Engine/World.h"
#include "FileHelpers.h"
#include "GameFramework/Actor.h"
#include "ISourceControlModule.h"
#include "Materials/MaterialInterface.h"
#include "ORBManifest.h"
#include "ORBScan.h"
#include "SourceControlHelpers.h"
#include "UObject/Package.h"
#include "UObject/UObjectGlobals.h"

DEFINE_LOG_CATEGORY_STATIC(LogORBRebind, Log, All);

namespace
{
	/**
	 * `/Game/Meshes/SM_Crate.SM_Crate` -> `/Game/Meshes/SM_Crate`.
	 *
	 * The asset registry's referencer graph is keyed by PACKAGE name; handing it an object path
	 * returns nothing, which would silently report that no map references a mesh that every map
	 * references.
	 */
	FString ObjectPathToPackageName(const FString& ObjectPath)
	{
		int32 Dot = INDEX_NONE;
		if (ObjectPath.FindChar(TEXT('.'), Dot))
		{
			return ObjectPath.Left(Dot);
		}
		return ObjectPath;
	}

	/** Open a map by package name and hand back the world inside it. */
	UWorld* LoadWorldByPackage(const FString& PackageName)
	{
		/*
		 * Nothing here calls CollectGarbage, which is what keeps the worlds this function returns
		 * alive for the whole run. That is the standard commandlet arrangement and it is stated
		 * rather than assumed, because adding a GC call anywhere in this file would silently
		 * invalidate every pointer held across the loop below.
		 */
		UPackage* Package = LoadPackage(nullptr, *PackageName, LOAD_None);
		if (Package == nullptr)
		{
			return nullptr;
		}
		return UWorld::FindWorldInPackage(Package);
	}

	/** Find one actor of a world by its full path name. */
	AActor* FindActorByPath(const TArray<AActor*>& Actors, const FString& ActorPath)
	{
		for (AActor* Actor : Actors)
		{
			if (IsValid(Actor) && Actor->GetPathName() == ActorPath)
			{
				return Actor;
			}
		}
		return nullptr;
	}

	UMeshComponent* FindMeshComponentByName(AActor* Actor, const FString& ComponentName)
	{
		TArray<UMeshComponent*> Components;
		Actor->GetComponents(Components);
		for (UMeshComponent* Component : Components)
		{
			if (IsValid(Component) && Component->GetName() == ComponentName)
			{
				return Component;
			}
		}
		return nullptr;
	}

	/** What is bound at one index right now, as a path string. Empty when nothing is. */
	FString BoundAt(const UMeshComponent* Component, int32 Index)
	{
		const UMaterialInterface* Current = Component->OverrideMaterials.IsValidIndex(Index)
			? Component->OverrideMaterials[Index]
			: nullptr;
		return Current != nullptr ? Current->GetPathName() : FString();
	}

	/**
	 * Check the package out when source control is running, and REPORT rather than skip on refusal.
	 *
	 * A read-only file that is silently passed over is a row the report claims to have fixed and did
	 * not. Returning false makes the caller record it as a problem.
	 */
	bool TryCheckOut(UPackage* Package, FORBRunResult& Result)
	{
		if (Package == nullptr)
		{
			return false;
		}
		if (!ISourceControlModule::Get().IsEnabled())
		{
			return true;
		}

		const FString Filename = USourceControlHelpers::PackageFilename(Package);
		if (Filename.IsEmpty())
		{
			return true;
		}

		if (USourceControlHelpers::CheckOutOrAddFile(Filename, /*bSilent*/ true))
		{
			++Result.Counters.PackagesCheckedOut;
			return true;
		}

		Result.Problems.Add(FString::Printf(
			TEXT("source control would not check out %s, so it was left untouched."), *Package->GetName()));
		return false;
	}

	/** Group manifest rows by the map that has to be opened to reach them. */
	void GroupByWorld(const TArray<FORBOverrideRecord>& Records, TMap<FString, TArray<int32>>& OutGroups)
	{
		for (int32 Index = 0; Index < Records.Num(); ++Index)
		{
			OutGroups.FindOrAdd(Records[Index].WorldPackage).Add(Index);
		}
	}
}

namespace ORBRebind
{
	bool Run(const FORBArgs& Args, FORBRunResult& Result, FString& OutError)
	{
		TArray<FORBOverrideRecord> Records;
		if (!ORBManifest::LoadSnapshot(Args.ManifestPath, Records, OutError))
		{
			return false;
		}
		Result.ManifestPath = Args.ManifestPath;

		// -Paths NARROWS a rebind; it does not define it. The manifest is what defines the work.
		if (Args.Paths.Num() > 0)
		{
			Records.RemoveAll([&Args](const FORBOverrideRecord& Record)
			{
				for (const FString& Path : Args.Paths)
				{
					if (Record.WorldPackage.StartsWith(Path, ESearchCase::IgnoreCase))
					{
						return false;
					}
				}
				return true;
			});
		}

		if (Records.Num() == 0)
		{
			// Not an error to report here - the caller turns "nothing to work on" into an exit code,
			// because whether that is a failure is a policy decision and not this function's.
			return true;
		}

		if (!ORBScan::PrepareRegistry(Args.Paths, OutError))
		{
			Result.bScanFailed = true;
			return false;
		}

		/*
		 * COVERAGE, measured rather than asserted.
		 *
		 * GetReferencers over each mesh the snapshot mentions gives every on-disk package that can
		 * possibly hold an affected override. Comparing that against the packages the snapshot
		 * actually has rows for is the honest number: a package that references the mesh and is NOT
		 * in the snapshot holds overrides placed after the snapshot was taken, and this tool cannot
		 * put those back. The report says so instead of implying full coverage.
		 */
		{
			IAssetRegistry& AssetRegistry =
				FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry")).Get();

			TSet<FString> MeshPackages;
			TSet<FString> CoveredPackages;
			for (const FORBOverrideRecord& Record : Records)
			{
				MeshPackages.Add(ObjectPathToPackageName(Record.MeshPackage));
				CoveredPackages.Add(Record.ActorPackage);
			}

			TSet<FName> Referencing;
			for (const FString& MeshPackage : MeshPackages)
			{
				TArray<FName> Referencers;
				AssetRegistry.GetReferencers(FName(*MeshPackage), Referencers,
					UE::AssetRegistry::EDependencyCategory::Package);
				for (const FName& Referencer : Referencers)
				{
					Referencing.Add(Referencer);
				}
			}

			Result.Counters.ReferencingPackagesFound = Referencing.Num();
			for (const FName& Referencer : Referencing)
			{
				if (CoveredPackages.Contains(Referencer.ToString()))
				{
					++Result.Counters.ReferencingPackagesCovered;
				}
			}
		}

		TMap<FString, TArray<int32>> Groups;
		GroupByWorld(Records, Groups);
		Result.Counters.WorldsOffered = Groups.Num();

		/*
		 * ⚠️ SORTED, BECAUSE TMap ITERATION ORDER IS NOT AN ORDER. A TMap yields its pairs in hash
		 * order, so the sequence in which maps are processed - and therefore the order of the
		 * journal, of the map sections in the report, and of the sections a store plate captures -
		 * varied between runs over identical input. Sorting by package name makes a run reproducible,
		 * which is the property a buyer needs when they diff two reports or replay a journal.
		 */
		TArray<FString> WorldOrder;
		Groups.GenerateKeyArray(WorldOrder);
		WorldOrder.Sort();

		TArray<FORBJournalEntry> Journal;
		TArray<UPackage*> PackagesToSave;

		for (const FString& WorldPackage : WorldOrder)
		{
			const TPair<FString, TArray<int32>> Group(WorldPackage, Groups[WorldPackage]);
			UWorld* World = LoadWorldByPackage(Group.Key);
			if (World == nullptr)
			{
				for (int32 RowIndex : Group.Value)
				{
					FORBRowResult Row;
					Row.Record = Records[RowIndex];
					Row.Status = EORBRowStatus::TargetMissing;
					Row.Detail = TEXT("the map named by this row could not be opened");
					Result.Rows.Add(MoveTemp(Row));
				}
				Result.Problems.Add(FString::Printf(TEXT("could not open %s"), *Group.Key));
				continue;
			}
			++Result.Counters.WorldsOpened;

			TArray<AActor*> Actors;
			ORBScan::CollectActors(World, Actors, Result.Counters);

			/*
			 * Index the actors once. Resolving each row by walking every actor is O(rows x actors),
			 * and on a dense map that is the difference between seconds and minutes for a command
			 * whose whole selling point is that it runs while somebody is waiting.
			 */
			TMap<FString, AActor*> ActorsByPath;
			for (AActor* Actor : Actors)
			{
				if (IsValid(Actor))
				{
					ActorsByPath.Add(Actor->GetPathName(), Actor);
				}
			}

			/*
			 * ⭐ SUB-GROUP BY COMPONENT, AND THIS IS NOT AN OPTIMISATION.
			 *
			 * "Is this override one the snapshot never recorded?" is a question about a WHOLE
			 * component: the snapshot holds every override that component had, so a slot with no row
			 * is recorded as EMPTY rather than unknown. A loop that sees one row at a time cannot ask
			 * it, which is exactly why the first implementation re-bound the moved slot correctly and
			 * left the displaced material sitting on the slot that took its place.
			 */
			TArray<FString> ComponentOrder;
			TMap<FString, TArray<int32>> ByComponent;
			for (int32 RowIndex : Group.Value)
			{
				const FString Key = Records[RowIndex].ActorPath + TEXT("|") + Records[RowIndex].ComponentName;
				if (!ByComponent.Contains(Key))
				{
					ComponentOrder.Add(Key);
				}
				ByComponent.FindOrAdd(Key).Add(RowIndex);
			}

			// Journal entries produced for THIS map only, so a verification failure can roll back
			// exactly the map that failed and nothing else.
			TArray<FORBJournalEntry> GroupJournal;
			bool bGroupFailed = false;

			for (const FString& ComponentKey : ComponentOrder)
			{
				if (bGroupFailed)
				{
					break;
				}

				const TArray<int32>& ComponentRows = ByComponent[ComponentKey];
				const FORBOverrideRecord& First = Records[ComponentRows[0]];

				AActor* Actor = ActorsByPath.FindRef(First.ActorPath);
				UMeshComponent* Component = Actor != nullptr
					? FindMeshComponentByName(Actor, First.ComponentName)
					: nullptr;

				if (Component == nullptr)
				{
					for (int32 RowIndex : ComponentRows)
					{
						FORBRowResult Row;
						Row.Record = Records[RowIndex];
						Row.Status = EORBRowStatus::TargetMissing;
						Row.Detail = Actor == nullptr
							? TEXT("the actor is no longer in this map")
							: TEXT("the actor no longer has a mesh component with this name");
						Result.Rows.Add(MoveTemp(Row));
					}
					continue;
				}
				++Result.Counters.MeshComponentsSeen;

				FString MeshPackage;
				if (!ORBScan::GetMeshPackage(Component, MeshPackage))
				{
					const FString ClassName = Component->GetClass()->GetName();
					Result.Counters.UnsupportedComponentClasses.AddUnique(ClassName);
					for (int32 RowIndex : ComponentRows)
					{
						FORBRowResult Row;
						Row.Record = Records[RowIndex];
						Row.Status = EORBRowStatus::UnsupportedComponent;
						Row.Detail = FString::Printf(
							TEXT("%s is neither a static nor a skinned mesh component"), *ClassName);
						++Result.Counters.UnsupportedComponents;
						Result.Rows.Add(MoveTemp(Row));
					}
					continue;
				}

				UPackage* ActorPackage = Actor->GetPackage();

				// Every slot name the snapshot recorded FOR THIS COMPONENT. Anything else that is
				// carrying an override now was not in the snapshot.
				TSet<FName> RecordedSlots;
				for (int32 RowIndex : ComponentRows)
				{
					RecordedSlots.Add(Records[RowIndex].SlotName);
				}

				for (int32 RowIndex : ComponentRows)
				{
					const FORBOverrideRecord& Record = Records[RowIndex];

					FORBRowResult Row;
					Row.Record = Record;

					/*
					 * Re-read per row rather than once per component. An earlier row for this same
					 * component may have just written to it, and deciding the next row against a
					 * stale picture is how "already correct" gets reported over a slot that is not.
					 */
					FORBRebindQuery Query;
					ORBScan::ReadCurrentBindings(Component, Query);

					const FORBRebindOutcome Outcome = ORBDecideRebind(Record, Query);
					Row.TargetIndex = Outcome.TargetIndex;
					Row.bIndexMoved = Outcome.bIndexMoved;
					if (Outcome.TargetIndex != INDEX_NONE)
					{
						Row.MaterialBefore = BoundAt(Component, Outcome.TargetIndex);
					}

					switch (Outcome.Decision)
					{
					case EORBDecision::RefusedSlotMissing:
						Row.Status = EORBRowStatus::RefusedSlotMissing;
						Row.Detail = FString::Printf(
							TEXT("\"%s\" is not a slot on %s any more. Left exactly as it was."),
							*Record.SlotName.ToString(), *MeshPackage);
						Result.Rows.Add(MoveTemp(Row));
						continue;

					case EORBDecision::RefusedAmbiguous:
						Row.Status = EORBRowStatus::RefusedAmbiguous;
						Row.Detail = FString::Printf(
							TEXT("\"%s\" names more than one slot on %s, so it does not identify one target. Left exactly as it was."),
							*Record.SlotName.ToString(), *MeshPackage);
						Result.Rows.Add(MoveTemp(Row));
						continue;

					case EORBDecision::AlreadyCorrect:
						Row.Status = EORBRowStatus::AlreadyCorrect;
						Result.Rows.Add(MoveTemp(Row));
						continue;

					default:
						break;
					}

					// From here the rule says REBIND.
					if (!Args.bApply)
					{
						Row.Status = EORBRowStatus::WouldRebind;
						Result.Rows.Add(MoveTemp(Row));
						continue;
					}

					UMaterialInterface* Material = LoadObject<UMaterialInterface>(
						nullptr, *Record.OverrideMaterialPackage);
					if (Material == nullptr)
					{
						/*
						 * Rule 2: never write a material VALUE it did not read. The only thing this
						 * tool ever assigns is the exact asset the snapshot recorded, so an asset
						 * that will not load is a refusal - not an invitation to substitute
						 * something plausible.
						 */
						Row.Status = EORBRowStatus::MaterialMissing;
						Row.Detail = FString::Printf(TEXT("%s could not be loaded"),
							*Record.OverrideMaterialPackage);
						Result.Rows.Add(MoveTemp(Row));
						continue;
					}

					if (!TryCheckOut(ActorPackage, Result))
					{
						Row.Status = EORBRowStatus::TargetMissing;
						Row.Detail = TEXT("the package holding this actor could not be checked out");
						Result.Rows.Add(MoveTemp(Row));
						continue;
					}

					Component->Modify();

					/*
					 * THE WRITE. SetMaterialByName resolves the index through the engine's own
					 * GetMaterialIndex and calls SetMaterial, which does the invalidation an array
					 * assignment skips: the material parameter cache, MarkRenderStateDirty,
					 * body-instance physical materials, and the editor's static-lighting
					 * re-registration.
					 */
					Component->SetMaterialByName(Record.SlotName, Material);

					// READ IT BACK. A write that reports success is not a write (master CLAUDE.md).
					const FString After = BoundAt(Component, Outcome.TargetIndex);
					if (After != Record.OverrideMaterialPackage)
					{
						Row.Status = EORBRowStatus::VerifyFailed;
						Row.Detail = FString::Printf(
							TEXT("wrote %s and read back \"%s\""),
							*Record.OverrideMaterialPackage, After.IsEmpty() ? TEXT("nothing") : *After);
						Result.Rows.Add(MoveTemp(Row));
						bGroupFailed = true;
						break;
					}

					FORBJournalEntry Entry;
					Entry.WorldPackage = Record.WorldPackage;
					Entry.ActorPackage = ActorPackage != nullptr ? ActorPackage->GetName() : Record.ActorPackage;
					Entry.ActorPath = Record.ActorPath;
					Entry.ComponentName = Record.ComponentName;
					Entry.SlotName = Record.SlotName;
					Entry.TargetIndex = Outcome.TargetIndex;
					Entry.MaterialBefore = Row.MaterialBefore;
					Entry.MaterialAfter = Record.OverrideMaterialPackage;
					GroupJournal.Add(Entry);

					if (ActorPackage != nullptr)
					{
						PackagesToSave.AddUnique(ActorPackage);
					}

					Row.Status = EORBRowStatus::Rebound;
					Result.Rows.Add(MoveTemp(Row));
				}

				if (bGroupFailed)
				{
					break;
				}

				/*
				 * ⭐ THE OTHER HALF OF A REORDER.
				 *
				 * Everything above put each recorded slot back by name. What it cannot see is the
				 * material left behind at the OLD index - which, after a reorder, is now a different
				 * slot entirely. The snapshot recorded that slot as having no override, so an
				 * override sitting there is either engine wreckage or something added after the
				 * snapshot, and those two are not distinguishable from here.
				 *
				 * ⛔ So the default REPORTS and -Strict CLEARS. Deleting somebody's later work
				 * unasked is a worse failure than leaving wreckage and naming it - and a plain
				 * -Apply returns exit 4 rather than claiming a clean bill over an actor that still
				 * renders the wrong material.
				 */
				FORBRebindQuery Final;
				ORBScan::ReadCurrentBindings(Component, Final);
				for (int32 Index = 0; Index < Final.CurrentSlotNames.Num(); ++Index)
				{
					const FName SlotName = Final.CurrentSlotNames[Index];
					if (SlotName.IsNone() || RecordedSlots.Contains(SlotName))
					{
						continue;
					}
					const FString Current = Final.CurrentOverrideAtIndex.IsValidIndex(Index)
						? Final.CurrentOverrideAtIndex[Index]
						: FString();
					if (Current.IsEmpty())
					{
						continue;
					}

					FORBRowResult Row;
					Row.Record = First;
					Row.Record.SlotName = SlotName;
					Row.Record.SlotIndexAtSnapshot = INDEX_NONE;
					Row.Record.OverrideMaterialPackage = FString();
					Row.TargetIndex = Index;
					Row.MaterialBefore = Current;

					if (!Args.bApply || !Args.bStrict)
					{
						Row.Status = EORBRowStatus::UnrecordedOverrideReported;
						Row.Detail = FString::Printf(
							TEXT("the snapshot recorded no override on \"%s\", and %s is bound there now. ")
							TEXT("Re-run with -Strict to clear it, or leave it if somebody set it deliberately."),
							*SlotName.ToString(), *Current);
						Result.Rows.Add(MoveTemp(Row));
						continue;
					}

					if (!TryCheckOut(ActorPackage, Result))
					{
						Row.Status = EORBRowStatus::TargetMissing;
						Row.Detail = TEXT("the package holding this actor could not be checked out");
						Result.Rows.Add(MoveTemp(Row));
						continue;
					}

					Component->Modify();
					Component->SetMaterialByName(SlotName, nullptr);

					const FString After = BoundAt(Component, Index);
					if (!After.IsEmpty())
					{
						Row.Status = EORBRowStatus::VerifyFailed;
						Row.Detail = FString::Printf(
							TEXT("cleared \"%s\" and read back %s"), *SlotName.ToString(), *After);
						Result.Rows.Add(MoveTemp(Row));
						bGroupFailed = true;
						break;
					}

					FORBJournalEntry Entry;
					Entry.WorldPackage = First.WorldPackage;
					Entry.ActorPackage = ActorPackage != nullptr ? ActorPackage->GetName() : First.ActorPackage;
					Entry.ActorPath = First.ActorPath;
					Entry.ComponentName = First.ComponentName;
					Entry.SlotName = SlotName;
					Entry.TargetIndex = Index;
					Entry.MaterialBefore = Current;
					Entry.MaterialAfter = FString();
					GroupJournal.Add(Entry);

					if (ActorPackage != nullptr)
					{
						PackagesToSave.AddUnique(ActorPackage);
					}

					Row.Status = EORBRowStatus::UnrecordedOverrideCleared;
					Result.Rows.Add(MoveTemp(Row));
				}
			}

			if (bGroupFailed)
			{
				/*
				 * ROLL THE WHOLE MAP BACK. A partially rebound map is worse than an untouched one:
				 * it is a map whose overrides half agree with the snapshot and half do not, and
				 * nothing downstream could tell which half.
				 */
				Result.bRolledBack = true;
				for (int32 Index = GroupJournal.Num() - 1; Index >= 0; --Index)
				{
					const FORBJournalEntry& Entry = GroupJournal[Index];
					AActor* Actor = FindActorByPath(Actors, Entry.ActorPath);
					UMeshComponent* Component = Actor != nullptr
						? FindMeshComponentByName(Actor, Entry.ComponentName)
						: nullptr;
					if (Component == nullptr)
					{
						continue;
					}
					UMaterialInterface* Previous = Entry.MaterialBefore.IsEmpty()
						? nullptr
						: LoadObject<UMaterialInterface>(nullptr, *Entry.MaterialBefore);
					Component->Modify();
					Component->SetMaterialByName(Entry.SlotName, Previous);
				}

				// Nothing from this map is saved, and its rows are already recorded as VerifyFailed.
				for (const FORBJournalEntry& Entry : GroupJournal)
				{
					PackagesToSave.RemoveAll([&Entry](const UPackage* Package)
					{
						return Package != nullptr && Package->GetName() == Entry.ActorPackage;
					});
				}
				Result.Problems.Add(FString::Printf(
					TEXT("%s was rolled back: a write did not read back as written, so no part of that map was saved."),
					*Group.Key));
				continue;
			}

			Journal.Append(GroupJournal);
		}

		if (Args.bApply && Journal.Num() > 0)
		{
			/*
			 * THE JOURNAL IS WRITTEN BEFORE THE FIRST PACKAGE IS SAVED, which is the whole reason
			 * -Revert can undo a run that was killed halfway through saving.
			 */
			FString JournalError;
			if (!ORBManifest::SaveJournal(Args.JournalPath, Journal, JournalError))
			{
				OutError = FString::Printf(
					TEXT("the undo journal could not be written (%s), so NOTHING was saved."), *JournalError);
				return false;
			}
			Result.JournalPath = Args.JournalPath;

			if (UEditorLoadingAndSavingUtils::SavePackages(PackagesToSave, /*bOnlyDirty*/ false))
			{
				Result.Counters.PackagesSaved = PackagesToSave.Num();
			}
			else
			{
				Result.Problems.Add(TEXT("the editor reported that at least one package could not be saved. ")
					TEXT("The journal was already written, so -Revert can undo whatever did land."));
			}
		}

		UE_LOG(LogORBRebind, Display,
			TEXT("rebind: %d map(s) offered, %d opened, %d row(s), %d rebound, %d refused, ")
			TEXT("%d not in the snapshot (%d cleared), %d package(s) saved"),
			Result.Counters.WorldsOffered, Result.Counters.WorldsOpened, Result.Rows.Num(),
			Result.CountRows(EORBRowStatus::Rebound), Result.CountRefusals(),
			Result.CountRows(EORBRowStatus::UnrecordedOverrideReported),
			Result.CountRows(EORBRowStatus::UnrecordedOverrideCleared),
			Result.Counters.PackagesSaved);

		return true;
	}

	bool Revert(const FORBArgs& Args, FORBRunResult& Result, FString& OutError)
	{
		TArray<FORBJournalEntry> Entries;
		if (!ORBManifest::LoadJournal(Args.JournalPath, Entries, OutError))
		{
			return false;
		}
		Result.JournalPath = Args.JournalPath;

		if (Entries.Num() == 0)
		{
			return true;
		}

		TMap<FString, TArray<int32>> Groups;
		for (int32 Index = 0; Index < Entries.Num(); ++Index)
		{
			Groups.FindOrAdd(Entries[Index].WorldPackage).Add(Index);
		}
		Result.Counters.WorldsOffered = Groups.Num();

		// Sorted for the same reason as the rebind path above: a replay must not depend on hash order.
		TArray<FString> WorldOrder;
		Groups.GenerateKeyArray(WorldOrder);
		WorldOrder.Sort();

		TArray<UPackage*> PackagesToSave;

		for (const FString& WorldPackage : WorldOrder)
		{
			const TPair<FString, TArray<int32>> Group(WorldPackage, Groups[WorldPackage]);
			UWorld* World = LoadWorldByPackage(Group.Key);
			if (World == nullptr)
			{
				Result.Problems.Add(FString::Printf(TEXT("could not open %s to revert it"), *Group.Key));
				continue;
			}
			++Result.Counters.WorldsOpened;

			TArray<AActor*> Actors;
			ORBScan::CollectActors(World, Actors, Result.Counters);

			for (int32 EntryIndex : Group.Value)
			{
				const FORBJournalEntry& Entry = Entries[EntryIndex];

				FORBRowResult Row;
				Row.Record.WorldPackage = Entry.WorldPackage;
				Row.Record.ActorPackage = Entry.ActorPackage;
				Row.Record.ActorPath = Entry.ActorPath;
				Row.Record.ComponentName = Entry.ComponentName;
				Row.Record.SlotName = Entry.SlotName;
				Row.Record.OverrideMaterialPackage = Entry.MaterialBefore;
				Row.TargetIndex = Entry.TargetIndex;
				Row.MaterialBefore = Entry.MaterialAfter;

				AActor* Actor = FindActorByPath(Actors, Entry.ActorPath);
				UMeshComponent* Component = Actor != nullptr
					? FindMeshComponentByName(Actor, Entry.ComponentName)
					: nullptr;
				if (Component == nullptr)
				{
					Row.Status = EORBRowStatus::TargetMissing;
					Row.Detail = TEXT("the actor or component this entry names is no longer in the map");
					Result.Rows.Add(MoveTemp(Row));
					continue;
				}

				const int32 Index = Component->GetMaterialIndex(Entry.SlotName);
				if (Index == INDEX_NONE)
				{
					Row.Status = EORBRowStatus::RefusedSlotMissing;
					Row.Detail = TEXT("the slot this entry names no longer exists on the mesh");
					Result.Rows.Add(MoveTemp(Row));
					continue;
				}
				Row.TargetIndex = Index;

				/*
				 * ASK THE SECOND QUESTION BEFORE REPORTING A FAILURE.
				 *
				 * A slot that already holds its pre-run value has nothing to undo, and that is a
				 * SUCCESS. A sibling product in this wing turned exactly this case into six warnings
				 * and a non-zero exit code over a revert that was provably correct - the false red
				 * cost as much as a false green would have.
				 */
				const FString Current = BoundAt(Component, Index);
				if (Current == Entry.MaterialBefore)
				{
					Row.Status = EORBRowStatus::AlreadyAtPreviousValue;
					Result.Rows.Add(MoveTemp(Row));
					continue;
				}

				UMaterialInterface* Previous = nullptr;
				if (!Entry.MaterialBefore.IsEmpty())
				{
					Previous = LoadObject<UMaterialInterface>(nullptr, *Entry.MaterialBefore);
					if (Previous == nullptr)
					{
						Row.Status = EORBRowStatus::MaterialMissing;
						Row.Detail = FString::Printf(
							TEXT("%s could not be loaded, so this slot was left as it is"), *Entry.MaterialBefore);
						Result.Rows.Add(MoveTemp(Row));
						continue;
					}
				}

				UPackage* ActorPackage = Actor->GetPackage();
				if (!TryCheckOut(ActorPackage, Result))
				{
					Row.Status = EORBRowStatus::TargetMissing;
					Row.Detail = TEXT("the package holding this actor could not be checked out");
					Result.Rows.Add(MoveTemp(Row));
					continue;
				}

				Component->Modify();
				Component->SetMaterialByName(Entry.SlotName, Previous);

				const FString After = BoundAt(Component, Index);
				if (After != Entry.MaterialBefore)
				{
					Row.Status = EORBRowStatus::VerifyFailed;
					Row.Detail = FString::Printf(TEXT("restored %s and read back \"%s\""),
						Entry.MaterialBefore.IsEmpty() ? TEXT("nothing") : *Entry.MaterialBefore,
						After.IsEmpty() ? TEXT("nothing") : *After);
					Result.bRolledBack = true;
					Result.Rows.Add(MoveTemp(Row));
					continue;
				}

				if (ActorPackage != nullptr)
				{
					PackagesToSave.AddUnique(ActorPackage);
				}
				Row.Status = EORBRowStatus::Reverted;
				Result.Rows.Add(MoveTemp(Row));
			}
		}

		if (PackagesToSave.Num() > 0)
		{
			if (UEditorLoadingAndSavingUtils::SavePackages(PackagesToSave, /*bOnlyDirty*/ false))
			{
				Result.Counters.PackagesSaved = PackagesToSave.Num();
			}
			else
			{
				Result.Problems.Add(TEXT("the editor reported that at least one package could not be saved."));
			}
		}

		UE_LOG(LogORBRebind, Display,
			TEXT("revert: %d entry(s), %d restored, %d already at their previous value, %d package(s) saved"),
			Entries.Num(), Result.CountRows(EORBRowStatus::Reverted),
			Result.CountRows(EORBRowStatus::AlreadyAtPreviousValue), Result.Counters.PackagesSaved);

		return true;
	}
}
