// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

#include "OverrideRebinderModule.h"

#include "HAL/IConsoleManager.h"
#include "Modules/ModuleManager.h"
#include "ORBRun.h"

#define LOCTEXT_NAMESPACE "FOverrideRebinderModule"

namespace
{
	/**
	 * The editor console entry point.
	 *
	 * It takes the SAME switch strings as the commandlet and hands them to the SAME ORBRun::Execute,
	 * so there is exactly one implementation of what this product does. The console arrives with the
	 * arguments already split, and the leading '-' is optional there because typing it into a console
	 * is easy to get wrong and a silently-ignored switch is how a run scans half of what was asked.
	 */
	void RunFromConsole(const TArray<FString>& RawArgs)
	{
		TArray<FString> Switches;
		Switches.Reserve(RawArgs.Num());
		for (const FString& Arg : RawArgs)
		{
			Switches.Add(Arg.StartsWith(TEXT("-"), ESearchCase::CaseSensitive) ? Arg.RightChop(1) : Arg);
		}

		const EORBExit Exit = ORBRun::Execute(Switches);
		UE_LOG(LogTemp, Display, TEXT("OverrideRebinder.Run finished with exit code %d."),
			static_cast<int32>(Exit));
	}

	FAutoConsoleCommand GRunCommand(
		TEXT("OverrideRebinder.Run"),
		TEXT("Override Rebinder. Snapshot: OverrideRebinder.Run -Snapshot -Paths=/Game/Maps. ")
		TEXT("Rebind: OverrideRebinder.Run -Rebind [-Apply]. Undo: OverrideRebinder.Run -Revert=<journal.json>. ")
		TEXT("Writes an HTML sheet under Saved/OverrideRebinder and nothing else unless -Apply is given."),
		FConsoleCommandWithArgsDelegate::CreateStatic(&RunFromConsole));
}

void FOverrideRebinderModule::StartupModule()
{
}

void FOverrideRebinderModule::ShutdownModule()
{
}

#undef LOCTEXT_NAMESPACE

// THIS LINE IS THE ONE THE GATE CANNOT CHECK FOR YOU. Without it the module compiles, links and
// packages cleanly and then fails to load in the buyer's editor.
IMPLEMENT_MODULE(FOverrideRebinderModule, OverrideRebinder)
