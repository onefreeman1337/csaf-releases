// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

#include "ORBSnapshot.h"

#include "AssetRegistry/AssetData.h"
#include "Components/MeshComponent.h"
#include "Engine/World.h"
#include "GameFramework/Actor.h"
#include "Materials/MaterialInterface.h"
#include "ORBManifest.h"
#include "ORBScan.h"
#include "UObject/Package.h"

DEFINE_LOG_CATEGORY_STATIC(LogORBSnapshot, Log, All);

namespace ORBSnapshot
{
	bool Run(const FORBArgs& Args, FORBRunResult& Result, TArray<FORBOverrideRecord>& OutRecords, FString& OutError)
	{
		if (!ORBScan::PrepareRegistry(Args.Paths, OutError))
		{
			Result.bScanFailed = true;
			return false;
		}

		TArray<FAssetData> Worlds;
		ORBScan::FindWorlds(Args.Paths, Worlds);
		Result.Counters.WorldsOffered = Worlds.Num();

		for (const FAssetData& WorldAsset : Worlds)
		{
			UWorld* World = Cast<UWorld>(WorldAsset.GetAsset());
			if (World == nullptr)
			{
				Result.Problems.Add(FString::Printf(
					TEXT("%s is registered as a level but could not be opened, so nothing in it was read."),
					*WorldAsset.PackageName.ToString()));
				continue;
			}
			++Result.Counters.WorldsOpened;

			const FString WorldPackage = World->GetPackage() != nullptr
				? World->GetPackage()->GetName()
				: WorldAsset.PackageName.ToString();

			TArray<AActor*> Actors;
			ORBScan::CollectActors(World, Actors, Result.Counters);

			for (AActor* Actor : Actors)
			{
				TArray<UMeshComponent*> Components;
				Actor->GetComponents(Components);

				for (UMeshComponent* Component : Components)
				{
					if (!IsValid(Component))
					{
						continue;
					}
					++Result.Counters.MeshComponentsSeen;

					if (Component->OverrideMaterials.Num() == 0)
					{
						continue;
					}
					++Result.Counters.ComponentsWithOverrides;

					FString MeshPackage;
					if (!ORBScan::GetMeshPackage(Component, MeshPackage))
					{
						/*
						 * Not a static or skinned mesh component. Its overrides are real, but the mesh
						 * asset they are keyed against is reached by a route this version has not
						 * tested - so it is named in the report rather than written through blind.
						 */
						++Result.Counters.UnsupportedComponents;
						Result.Counters.UnsupportedComponentClasses.AddUnique(Component->GetClass()->GetName());
						continue;
					}

					const TArray<FName> SlotNames = Component->GetMaterialSlotNames();

					for (int32 Index = 0; Index < Component->OverrideMaterials.Num(); ++Index)
					{
						const UMaterialInterface* Override = Component->OverrideMaterials[Index];
						if (Override == nullptr)
						{
							// An empty entry is a slot the artist did not override, not a lost one.
							++Result.Counters.NullOverridesSkipped;
							continue;
						}

						if (!SlotNames.IsValidIndex(Index) || SlotNames[Index].IsNone())
						{
							/*
							 * There is an override at this index and the mesh has no NAME for the slot,
							 * so there is no durable key to record. Guessing one would produce a
							 * snapshot row that can only be put back by index - which is the engine
							 * behaviour this product exists to replace.
							 */
							++Result.Counters.UnnamedSlotsSkipped;
							continue;
						}

						FORBOverrideRecord Record;
						Record.WorldPackage = WorldPackage;
						Record.ActorPackage = Actor->GetPackage() != nullptr
							? Actor->GetPackage()->GetName()
							: WorldPackage;
						Record.ActorPath = Actor->GetPathName();
						Record.ComponentName = Component->GetName();
						Record.MeshPackage = MeshPackage;
						Record.SlotName = SlotNames[Index];
						Record.SlotIndexAtSnapshot = Index;
						Record.OverrideMaterialPackage = Override->GetPathName();
						OutRecords.Add(MoveTemp(Record));
					}
				}
			}
		}

		Result.SnapshotRowsWritten = OutRecords.Num();

		/*
		 * ⛔ A SCAN THAT SAW NO ACTOR AT ALL DID NOT HAPPEN. REFUSE RATHER THAN REPORT A CLEAN PROJECT.
		 *
		 * MEASURED 2026-09-01: a defect in the actor walk (see ORBScan.cpp, the PersistentLevel note)
		 * made this report "2 level(s) opened, 0 actor(s), 0 row(s) written" over two maps carrying
		 * eight overrides - and then RETURN SUCCESS, writing no manifest, because zero rows is a
		 * legitimate outcome for a project that genuinely has no overrides. The next command failed
		 * on a missing file, which points at the wrong thing entirely.
		 *
		 * ⚠️ The test below is deliberately structural rather than a heuristic. Zero OVERRIDES is a
		 * perfectly good answer and must stay silent. Zero ACTORS, having successfully opened at
		 * least one level, is not an answer at all: every ULevel carries an AWorldSettings, so a map
		 * with no actors in it does not exist. That makes this a statement about the scan, never
		 * about the project, and it cannot fire on a legitimately clean map.
		 */
		if (Result.Counters.WorldsOpened > 0 && Result.Counters.ActorsSeen == 0)
		{
			/*
			 * bScanFailed, so ORBRun::Execute maps this to EORBExit::NothingScanned (2) rather than
			 * RunFailed (6). The listing and the Readme both document 2 as "nothing was scanned - a
			 * failure, never a pass", and a scan that saw no actors is precisely that. Returning
			 * false without this flag would have shipped an exit code that contradicts the table we
			 * sell the product on.
			 */
			Result.bScanFailed = true;
			OutError = FString::Printf(
				TEXT("opened %d level(s) and saw no actors at all. Every level contains at least a ")
				TEXT("WorldSettings actor, so this is a scan that did not happen rather than a project ")
				TEXT("with nothing in it, and no snapshot has been written."),
				Result.Counters.WorldsOpened);
			return false;
		}

		if (OutRecords.Num() > 0)
		{
			FString WriteError;
			if (!ORBManifest::SaveSnapshot(Args.ManifestPath, OutRecords, WriteError))
			{
				OutError = WriteError;
				return false;
			}
			Result.ManifestPath = Args.ManifestPath;
		}

		UE_LOG(LogORBSnapshot, Display,
			TEXT("snapshot: %d level(s) offered, %d opened, %d actor(s), %d mesh component(s), %d with overrides, %d row(s) written"),
			Result.Counters.WorldsOffered, Result.Counters.WorldsOpened, Result.Counters.ActorsSeen,
			Result.Counters.MeshComponentsSeen, Result.Counters.ComponentsWithOverrides, OutRecords.Num());

		return true;
	}
}
