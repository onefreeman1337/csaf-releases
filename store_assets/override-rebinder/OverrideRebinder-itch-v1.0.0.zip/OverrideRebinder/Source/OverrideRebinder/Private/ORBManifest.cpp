// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

#include "ORBManifest.h"

#include "Dom/JsonObject.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonWriter.h"

namespace
{
	// The field names, once. Every reader and writer below goes through these.
	const TCHAR* FWorldPackage   = TEXT("worldPackage");
	const TCHAR* FActorPackage   = TEXT("actorPackage");
	const TCHAR* FActorPath      = TEXT("actorPath");
	const TCHAR* FComponentName  = TEXT("componentName");
	const TCHAR* FMeshPackage    = TEXT("meshPackage");
	const TCHAR* FSlotName       = TEXT("slotName");
	const TCHAR* FSlotIndex      = TEXT("slotIndexAtSnapshot");
	const TCHAR* FOverrideMat    = TEXT("overrideMaterial");
	const TCHAR* FTargetIndex    = TEXT("targetIndex");
	const TCHAR* FMaterialBefore = TEXT("materialBefore");
	const TCHAR* FMaterialAfter  = TEXT("materialAfter");
	const TCHAR* FRows           = TEXT("rows");
	const TCHAR* FEntries        = TEXT("entries");

	/** One place that guarantees the directory exists, so a first run does not fail on a missing folder. */
	bool WriteTextFile(const FString& Path, const FString& Text, FString& OutError)
	{
		const FString Dir = FPaths::GetPath(Path);
		if (!Dir.IsEmpty() && !IFileManager::Get().DirectoryExists(*Dir))
		{
			IFileManager::Get().MakeDirectory(*Dir, /*Tree*/ true);
		}

		if (!FFileHelper::SaveStringToFile(Text, *Path))
		{
			OutError = FString::Printf(TEXT("could not write \"%s\""), *Path);
			return false;
		}
		return true;
	}

	bool ReadJsonObject(const FString& Path, TSharedPtr<FJsonObject>& OutRoot, FString& OutError)
	{
		FString Text;
		if (!FFileHelper::LoadFileToString(Text, *Path))
		{
			OutError = FString::Printf(TEXT("could not read \"%s\""), *Path);
			return false;
		}

		const TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(Text);
		if (!FJsonSerializer::Deserialize(Reader, OutRoot) || !OutRoot.IsValid())
		{
			OutError = FString::Printf(TEXT("\"%s\" is not valid JSON"), *Path);
			return false;
		}
		return true;
	}
}

namespace ORBManifest
{
	bool SaveSnapshot(const FString& Path, const TArray<FORBOverrideRecord>& Records, FString& OutError)
	{
		TArray<TSharedPtr<FJsonValue>> Rows;
		Rows.Reserve(Records.Num());

		for (const FORBOverrideRecord& Record : Records)
		{
			const TSharedRef<FJsonObject> Row = MakeShared<FJsonObject>();
			Row->SetStringField(FWorldPackage, Record.WorldPackage);
			Row->SetStringField(FActorPackage, Record.ActorPackage);
			Row->SetStringField(FActorPath, Record.ActorPath);
			Row->SetStringField(FComponentName, Record.ComponentName);
			Row->SetStringField(FMeshPackage, Record.MeshPackage);
			Row->SetStringField(FSlotName, Record.SlotName.ToString());
			Row->SetNumberField(FSlotIndex, Record.SlotIndexAtSnapshot);
			Row->SetStringField(FOverrideMat, Record.OverrideMaterialPackage);
			Rows.Add(MakeShared<FJsonValueObject>(Row));
		}

		const TSharedRef<FJsonObject> Root = MakeShared<FJsonObject>();
		Root->SetStringField(TEXT("tool"), TEXT("Override Rebinder"));
		Root->SetStringField(TEXT("format"), TEXT("orb-snapshot-1"));
		Root->SetStringField(TEXT("takenAt"), FDateTime::UtcNow().ToIso8601());
		Root->SetNumberField(TEXT("rowCount"), Records.Num());
		Root->SetArrayField(FRows, Rows);

		FString Text;
		const TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&Text);
		FJsonSerializer::Serialize(Root, Writer);

		return WriteTextFile(Path, Text, OutError);
	}

	bool LoadSnapshot(const FString& Path, TArray<FORBOverrideRecord>& OutRecords, FString& OutError)
	{
		TSharedPtr<FJsonObject> Root;
		if (!ReadJsonObject(Path, Root, OutError))
		{
			return false;
		}

		const TArray<TSharedPtr<FJsonValue>>* Rows = nullptr;
		if (!Root->TryGetArrayField(FRows, Rows) || Rows == nullptr)
		{
			OutError = FString::Printf(TEXT("\"%s\" has no \"%s\" array - it is not an Override Rebinder snapshot"),
				*Path, FRows);
			return false;
		}

		for (const TSharedPtr<FJsonValue>& Value : *Rows)
		{
			const TSharedPtr<FJsonObject>* Row = nullptr;
			if (!Value.IsValid() || !Value->TryGetObject(Row) || Row == nullptr)
			{
				continue;
			}

			FORBOverrideRecord Record;
			Record.WorldPackage = (*Row)->GetStringField(FWorldPackage);
			Record.ActorPackage = (*Row)->GetStringField(FActorPackage);
			Record.ActorPath = (*Row)->GetStringField(FActorPath);
			Record.ComponentName = (*Row)->GetStringField(FComponentName);
			Record.MeshPackage = (*Row)->GetStringField(FMeshPackage);
			Record.SlotName = FName(*(*Row)->GetStringField(FSlotName));
			Record.SlotIndexAtSnapshot = static_cast<int32>((*Row)->GetNumberField(FSlotIndex));
			Record.OverrideMaterialPackage = (*Row)->GetStringField(FOverrideMat);
			OutRecords.Add(MoveTemp(Record));
		}

		return true;
	}

	bool SaveJournal(const FString& Path, const TArray<FORBJournalEntry>& Entries, FString& OutError)
	{
		TArray<TSharedPtr<FJsonValue>> Rows;
		Rows.Reserve(Entries.Num());

		for (const FORBJournalEntry& Entry : Entries)
		{
			const TSharedRef<FJsonObject> Row = MakeShared<FJsonObject>();
			Row->SetStringField(FWorldPackage, Entry.WorldPackage);
			Row->SetStringField(FActorPackage, Entry.ActorPackage);
			Row->SetStringField(FActorPath, Entry.ActorPath);
			Row->SetStringField(FComponentName, Entry.ComponentName);
			Row->SetStringField(FSlotName, Entry.SlotName.ToString());
			Row->SetNumberField(FTargetIndex, Entry.TargetIndex);
			Row->SetStringField(FMaterialBefore, Entry.MaterialBefore);
			Row->SetStringField(FMaterialAfter, Entry.MaterialAfter);
			Rows.Add(MakeShared<FJsonValueObject>(Row));
		}

		const TSharedRef<FJsonObject> Root = MakeShared<FJsonObject>();
		Root->SetStringField(TEXT("tool"), TEXT("Override Rebinder"));
		Root->SetStringField(TEXT("format"), TEXT("orb-journal-1"));
		Root->SetStringField(TEXT("writtenAt"), FDateTime::UtcNow().ToIso8601());
		Root->SetNumberField(TEXT("entryCount"), Entries.Num());
		Root->SetArrayField(FEntries, Rows);

		FString Text;
		const TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&Text);
		FJsonSerializer::Serialize(Root, Writer);

		return WriteTextFile(Path, Text, OutError);
	}

	bool LoadJournal(const FString& Path, TArray<FORBJournalEntry>& OutEntries, FString& OutError)
	{
		TSharedPtr<FJsonObject> Root;
		if (!ReadJsonObject(Path, Root, OutError))
		{
			return false;
		}

		const TArray<TSharedPtr<FJsonValue>>* Rows = nullptr;
		if (!Root->TryGetArrayField(FEntries, Rows) || Rows == nullptr)
		{
			OutError = FString::Printf(TEXT("\"%s\" has no \"%s\" array - it is not an Override Rebinder journal"),
				*Path, FEntries);
			return false;
		}

		for (const TSharedPtr<FJsonValue>& Value : *Rows)
		{
			const TSharedPtr<FJsonObject>* Row = nullptr;
			if (!Value.IsValid() || !Value->TryGetObject(Row) || Row == nullptr)
			{
				continue;
			}

			FORBJournalEntry Entry;
			Entry.WorldPackage = (*Row)->GetStringField(FWorldPackage);
			Entry.ActorPackage = (*Row)->GetStringField(FActorPackage);
			Entry.ActorPath = (*Row)->GetStringField(FActorPath);
			Entry.ComponentName = (*Row)->GetStringField(FComponentName);
			Entry.SlotName = FName(*(*Row)->GetStringField(FSlotName));
			Entry.TargetIndex = static_cast<int32>((*Row)->GetNumberField(FTargetIndex));
			Entry.MaterialBefore = (*Row)->GetStringField(FMaterialBefore);
			Entry.MaterialAfter = (*Row)->GetStringField(FMaterialAfter);
			OutEntries.Add(MoveTemp(Entry));
		}

		return true;
	}
}
