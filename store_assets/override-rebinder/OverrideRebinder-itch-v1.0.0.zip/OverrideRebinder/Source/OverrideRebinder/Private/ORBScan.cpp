// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

#include "ORBScan.h"

#include "AssetRegistry/ARFilter.h"
#include "AssetRegistry/AssetData.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "AssetRegistry/IAssetRegistry.h"
#include "Components/MeshComponent.h"
#include "Components/SkinnedMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/Level.h"
#include "Engine/SkinnedAsset.h"
#include "Engine/StaticMesh.h"
#include "Engine/World.h"
#include "GameFramework/Actor.h"
#include "Materials/MaterialInterface.h"

#if WITH_EDITOR
#include "WorldPartition/WorldPartition.h"
#include "WorldPartition/WorldPartitionActorDescInstance.h"
#include "WorldPartition/WorldPartitionHelpers.h"
#endif

namespace
{
	IAssetRegistry& Registry()
	{
		FAssetRegistryModule& Module =
			FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
		return Module.Get();
	}
}

namespace ORBScan
{
	bool PrepareRegistry(const TArray<FString>& Paths, FString& OutError)
	{
		IAssetRegistry& AssetRegistry = Registry();

		if (Paths.Num() > 0)
		{
			// CAUSE the scan, then wait for it. Waiting alone does not index a root nobody asked for.
			AssetRegistry.ScanPathsSynchronous(Paths, /*bForceRescan*/ false);
		}
		AssetRegistry.WaitForCompletion();

		// An empty registry is a scan that never happened, never a project with nothing in it.
		TArray<FAssetData> Any;
		FARFilter Probe;
		Probe.bRecursivePaths = true;
		Probe.bRecursiveClasses = true;
		if (Paths.Num() > 0)
		{
			for (const FString& Path : Paths)
			{
				Probe.PackagePaths.Add(FName(*Path));
			}
		}
		else
		{
			Probe.PackagePaths.Add(FName(TEXT("/Game")));
		}
		AssetRegistry.GetAssets(Probe, Any);

		if (Any.Num() == 0)
		{
			// The caller turns this into the "nothing scanned" exit code, which is a FAILURE and never
			// a clean bill of health. An audit tool that reports an unscanned root as "no problems"
			// is the one answer this wing refuses to ship.
			OutError = FString::Printf(
				TEXT("The asset registry returned no assets at all under %s. That is a scan that never ")
				TEXT("happened, not a project with no problems - check the path spelling and that the ")
				TEXT("mount point exists."),
				Paths.Num() > 0 ? *FString::Join(Paths, TEXT(", ")) : TEXT("/Game"));
			return false;
		}

		return true;
	}

	void FindWorlds(const TArray<FString>& Paths, TArray<FAssetData>& OutWorlds)
	{
		FARFilter Filter;
		Filter.bRecursivePaths = true;
		Filter.bRecursiveClasses = true;
		Filter.ClassPaths.Add(UWorld::StaticClass()->GetClassPathName());

		for (const FString& Path : Paths)
		{
			Filter.PackagePaths.Add(FName(*Path));
		}

		Registry().GetAssets(Filter, OutWorlds);
	}

	void CollectActors(UWorld* World, TArray<AActor*>& OutActors, FORBCounters& Counters)
	{
		if (World == nullptr)
		{
			return;
		}

		// A set, because a partitioned world can reach the same actor from both routes below and an
		// actor counted twice would inflate every figure the report prints.
		TSet<AActor*> Seen;

		auto Take = [&Seen, &OutActors](AActor* Actor)
		{
			if (IsValid(Actor))
			{
				bool bAlready = false;
				Seen.Add(Actor, &bAlready);
				if (!bAlready)
				{
					OutActors.Add(Actor);
				}
			}
		};

#if WITH_EDITOR
		if (UWorldPartition* Partition = World->GetWorldPartition())
		{
			++Counters.PartitionedWorlds;

			if (Partition->IsInitialized())
			{
				/*
				 * The external-actor case, handled by the engine's own loader rather than by opening
				 * packages by hand. Under World Partition each actor is its own package, so there is
				 * no level array to walk - and this is also why the rebind's referencer shortlist
				 * needs no special partition mode.
				 */
				FWorldPartitionHelpers::ForEachActorWithLoading(Partition,
					[&Take](const FWorldPartitionActorDescInstance* Desc)
					{
						if (Desc != nullptr)
						{
							Take(Desc->GetActor());
						}
						return true;
					});
			}
			else
			{
				/*
				 * Its actors are in packages this process has not opened. Whatever IS loaded is still
				 * read below, but the run must not imply it saw the whole map - so this is counted and
				 * printed rather than passed over.
				 */
				++Counters.PartitionedNotInitialised;
			}
		}
#endif

		/*
		 * ⛔ THE PERSISTENT LEVEL, EXPLICITLY - AND IT IS NOT BELT AND BRACES. MEASURED 2026-09-01.
		 *
		 * A world we reach through the asset registry is LOADED, not INITIALIZED: nothing here calls
		 * UWorld::InitWorld, and UWorld::Levels is filled in ONLY there -
		 *
		 *     World.cpp:2512-2513   Levels.Empty(1);
		 *                           Levels.Add( PersistentLevel );     // inside UWorld::InitWorld
		 *
		 * so GetLevels() returns an EMPTY array on a commandlet-loaded map, while PersistentLevel is
		 * serialized in and holds every actor. Walking only GetLevels() therefore reported
		 * "2 levels opened, 0 actors seen" over two maps holding eight overrides between them.
		 *
		 * ⚠️ The direction of that failure is why it is a shipping blocker rather than a rough edge:
		 * an empty scan is indistinguishable from a clean project. The snapshot wrote a manifest of
		 * zero rows, and every later run - preview, apply, strict, revert - then correctly did
		 * nothing at all and said so calmly. The tool would have told a buyer their project was fine
		 * on the ordinary, non-partitioned path, which is the ONLY path most projects have.
		 *
		 * The TSet above makes this safe next to the World Partition branch and the GetLevels() walk:
		 * a partitioned world reaches its actors through the loader, an initialized world reaches the
		 * persistent level through both, and an actor taken twice is added once.
		 */
		if (World->PersistentLevel != nullptr)
		{
			for (AActor* Actor : World->PersistentLevel->Actors)
			{
				Take(Actor);
			}
		}

		for (ULevel* Level : World->GetLevels())
		{
			if (Level == nullptr)
			{
				continue;
			}
			for (AActor* Actor : Level->Actors)
			{
				Take(Actor);
			}
		}

		Counters.ActorsSeen += OutActors.Num();
	}

	bool GetMeshPackage(const UMeshComponent* Component, FString& OutMeshPackage)
	{
		if (const UStaticMeshComponent* StaticComponent = Cast<UStaticMeshComponent>(Component))
		{
			const UStaticMesh* Mesh = StaticComponent->GetStaticMesh();
			OutMeshPackage = Mesh != nullptr ? Mesh->GetPathName() : FString();
			return true;
		}

		if (const USkinnedMeshComponent* SkinnedComponent = Cast<USkinnedMeshComponent>(Component))
		{
			const USkinnedAsset* Asset = SkinnedComponent->GetSkinnedAsset();
			OutMeshPackage = Asset != nullptr ? Asset->GetPathName() : FString();
			return true;
		}

		OutMeshPackage.Empty();
		return false;
	}

	void ReadCurrentBindings(const UMeshComponent* Component, FORBRebindQuery& OutQuery)
	{
		if (Component == nullptr)
		{
			return;
		}

		OutQuery.CurrentSlotNames = Component->GetMaterialSlotNames();

		/*
		 * READ OverrideMaterials, never write it. MeshComponent.h:29 states that setting it directly
		 * can race garbage collection against the rendering thread; every write in this product goes
		 * through SetMaterialByName, which is that array's own sanctioned door.
		 */
		OutQuery.CurrentOverrideAtIndex.Reset();
		OutQuery.CurrentOverrideAtIndex.Reserve(OutQuery.CurrentSlotNames.Num());
		for (int32 Index = 0; Index < OutQuery.CurrentSlotNames.Num(); ++Index)
		{
			const UMaterialInterface* Override = Component->OverrideMaterials.IsValidIndex(Index)
				? Component->OverrideMaterials[Index]
				: nullptr;
			OutQuery.CurrentOverrideAtIndex.Add(Override != nullptr ? Override->GetPathName() : FString());
		}
	}
}
