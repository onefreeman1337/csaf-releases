// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

#include "ORBRun.h"

#include "Misc/CommandLine.h"
#include "Misc/Parse.h"
#include "Misc/Paths.h"
#include "ORBArgs.h"
#include "ORBRebind.h"
#include "ORBReport.h"
#include "ORBSnapshot.h"
#include "ORBTypes.h"

DEFINE_LOG_CATEGORY_STATIC(LogOverrideRebinder, Log, All);

namespace
{
	/** Derive the exit code from what the run MEASURED. Nothing here asserts an outcome. */
	EORBExit DeriveExit(const FORBArgs& Args, const FORBRunResult& Result)
	{
		if (Result.bRolledBack)
		{
			return EORBExit::RolledBack;
		}

		const int32 Refusals = Result.CountRefusals();

		switch (Args.Mode)
		{
		case EORBMode::Snapshot:
			/*
			 * An empty scan is a failure, not a clean project. "Opened no levels" and "saw no mesh
			 * components at all" both mean the tool answered a question it never actually asked -
			 * whereas levels full of mesh components with no overrides IS a real, clean answer.
			 */
			if (Result.Counters.WorldsOpened == 0 || Result.Counters.MeshComponentsSeen == 0)
			{
				return EORBExit::NothingScanned;
			}
			return EORBExit::Clean;

		case EORBMode::Rebind:
			if (Result.Rows.Num() == 0)
			{
				return EORBExit::NothingScanned;
			}
			if (Args.bApply)
			{
				/*
				 * CountNeedsAttention, not CountRefusals. A displaced override this run reported and
				 * deliberately did not clear leaves an actor rendering the wrong material, so exit 0
				 * would be a clean bill of health over a visibly broken level. -Strict clears them
				 * and the same expression then returns 0 honestly.
				 */
				return Result.CountNeedsAttention() > 0 ? EORBExit::AppliedWithRefusals : EORBExit::Clean;
			}
			// A preview reports WORK, and a refusal is work - it is a row a human has to look at.
			return (Result.CountRows(EORBRowStatus::WouldRebind) > 0 || Result.CountNeedsAttention() > 0)
				? EORBExit::RebindsFound
				: EORBExit::Clean;

		case EORBMode::Revert:
			if (Result.Rows.Num() == 0)
			{
				return EORBExit::NothingScanned;
			}
			return Refusals > 0 ? EORBExit::AppliedWithRefusals : EORBExit::Clean;

		default:
			return EORBExit::BadArgs;
		}
	}

	void LogSummary(const FORBArgs& Args, const FORBRunResult& Result, EORBExit Exit)
	{
		UE_LOG(LogOverrideRebinder, Display, TEXT("Override Rebinder - %s, %s"),
			Args.ModeName(),
			Args.Mode == EORBMode::Snapshot || Args.Mode == EORBMode::Revert
				? TEXT("wrote what it found")
				: (Args.bApply ? TEXT("APPLIED") : TEXT("preview, nothing written")));

		if (Args.Mode == EORBMode::Snapshot)
		{
			UE_LOG(LogOverrideRebinder, Display,
				TEXT("  levels %d/%d opened - %d actors - %d mesh components - %d with overrides - %d rows recorded"),
				Result.Counters.WorldsOpened, Result.Counters.WorldsOffered, Result.Counters.ActorsSeen,
				Result.Counters.MeshComponentsSeen, Result.Counters.ComponentsWithOverrides,
				Result.SnapshotRowsWritten);
		}
		else
		{
			UE_LOG(LogOverrideRebinder, Display,
				TEXT("  maps %d/%d opened - %d rows - %d rebound - %d would rebind - %d already correct - %d refused"),
				Result.Counters.WorldsOpened, Result.Counters.WorldsOffered, Result.Rows.Num(),
				Result.CountRows(EORBRowStatus::Rebound),
				Result.CountRows(EORBRowStatus::WouldRebind),
				Result.CountRows(EORBRowStatus::AlreadyCorrect),
				Result.CountRefusals());
		}

		for (const FString& Problem : Result.Problems)
		{
			UE_LOG(LogOverrideRebinder, Warning, TEXT("  %s"), *Problem);
		}

		UE_LOG(LogOverrideRebinder, Display, TEXT("  report: %s"), *Result.ReportPath);
		UE_LOG(LogOverrideRebinder, Display, TEXT("  exit %d"), static_cast<int32>(Exit));
	}
}

namespace ORBRun
{
	void TokeniseSwitches(const FString& Params, TArray<FString>& OutSwitches)
	{
		TArray<FString> Tokens;
		FString Token;
		const TCHAR* Cursor = *Params;
		while (FParse::Token(Cursor, Token, /*UseEscape*/ false))
		{
			Tokens.Add(Token);
		}

		for (FString& Candidate : Tokens)
		{
			Candidate.TrimStartAndEndInline();
			if (Candidate.StartsWith(TEXT("-"), ESearchCase::CaseSensitive))
			{
				OutSwitches.Add(Candidate.RightChop(1));
			}
		}
	}

	EORBExit Execute(const TArray<FString>& Switches)
	{
		const FORBArgs Args = ORBParseArgs(Switches, FPaths::ProjectSavedDir());

		if (!Args.IsValid())
		{
			for (const FString& Error : Args.Errors)
			{
				UE_LOG(LogOverrideRebinder, Error, TEXT("%s"), *Error);
			}
			UE_LOG(LogOverrideRebinder, Display,
				TEXT("Usage: -run=OverrideRebinder -Snapshot -Paths=/Game/Maps[,/Game/More] [-Manifest=<file>]"));
			UE_LOG(LogOverrideRebinder, Display,
				TEXT("       -run=OverrideRebinder -Rebind [-Paths=...] [-Manifest=<file>] [-Apply]"));
			UE_LOG(LogOverrideRebinder, Display,
				TEXT("       -run=OverrideRebinder -Revert=<journal.json>"));
			return EORBExit::BadArgs;
		}

		FORBRunResult Result;
		Result.ModeName = Args.ModeName();
		Result.bApply = Args.bApply;
		Result.ReportPath = Args.ReportPath;

		FString Error;
		bool bOk = false;

		switch (Args.Mode)
		{
		case EORBMode::Snapshot:
		{
			TArray<FORBOverrideRecord> Records;
			bOk = ORBSnapshot::Run(Args, Result, Records, Error);
			break;
		}
		case EORBMode::Rebind:
			bOk = ORBRebind::Run(Args, Result, Error);
			break;
		case EORBMode::Revert:
			bOk = ORBRebind::Revert(Args, Result, Error);
			break;
		default:
			break;
		}

		if (!bOk)
		{
			Result.Problems.Add(Error);
			UE_LOG(LogOverrideRebinder, Error, TEXT("%s"), *Error);
		}

		/*
		 * The sheet is written even on a failed run. A run that could not finish is exactly the run
		 * whose reasons somebody needs in front of them, and a tool that writes nothing when it fails
		 * makes the person diagnosing it read a log instead.
		 */
		FString ReportError;
		if (!ORBReport::Write(Result, Args.ReportPath, ReportError))
		{
			UE_LOG(LogOverrideRebinder, Warning, TEXT("%s"), *ReportError);
		}

		if (!bOk)
		{
			const EORBExit FailureExit = Result.bScanFailed ? EORBExit::NothingScanned : EORBExit::RunFailed;
			LogSummary(Args, Result, FailureExit);
			return FailureExit;
		}

		const EORBExit Exit = DeriveExit(Args, Result);
		LogSummary(Args, Result, Exit);
		return Exit;
	}
}
