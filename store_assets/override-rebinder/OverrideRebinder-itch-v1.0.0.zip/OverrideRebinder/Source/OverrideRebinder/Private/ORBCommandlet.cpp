// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

#include "ORBCommandlet.h"

UOverrideRebinderCommandlet::UOverrideRebinderCommandlet()
{
	IsClient = false;
	IsServer = false;
	IsEditor = true;
	LogToConsole = true;
}

int32 UOverrideRebinderCommandlet::Main(const FString& Params)
{
	/*
	 * The commandlet is a THIN shell on purpose. Everything it does, the editor console command does
	 * too, by calling the same ORBRun::Execute - so the two entry points cannot answer differently.
	 * A sibling product in this wing advertised two entry points and only ever ran one of them.
	 */
	TArray<FString> Switches;
	ORBRun::TokeniseSwitches(Params, Switches);

	return static_cast<int32>(ORBRun::Execute(Switches));
}
