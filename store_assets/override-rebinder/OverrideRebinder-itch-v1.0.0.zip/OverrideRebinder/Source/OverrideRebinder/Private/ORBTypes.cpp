// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

#include "ORBTypes.h"

FORBRebindOutcome ORBDecideRebind(const FORBOverrideRecord& Record, const FORBRebindQuery& Query)
{
	FORBRebindOutcome Outcome;

	/*
	 * Resolve BY NAME. Count every match first rather than stopping at the first one - an early
	 * return on match cannot tell "found it" apart from "found the first of two", and the
	 * two-of-two case is precisely the one that must refuse.
	 */
	int32 FoundIndex = INDEX_NONE;
	int32 MatchCount = 0;
	for (int32 Index = 0; Index < Query.CurrentSlotNames.Num(); ++Index)
	{
		if (Query.CurrentSlotNames[Index] == Record.SlotName)
		{
			if (MatchCount == 0)
			{
				FoundIndex = Index;
			}
			++MatchCount;
		}
	}

	if (MatchCount == 0)
	{
		// The slot genuinely vanished from source. Report it; do not reach for a nearby index.
		Outcome.Decision = EORBDecision::RefusedSlotMissing;
		return Outcome;
	}

	if (MatchCount > 1)
	{
		// "By name" no longer identifies one target. Refusing is the product's core promise.
		Outcome.Decision = EORBDecision::RefusedAmbiguous;
		return Outcome;
	}

	Outcome.TargetIndex = FoundIndex;
	Outcome.bIndexMoved = (FoundIndex != Record.SlotIndexAtSnapshot);

	/*
	 * Already correct? Then write nothing.
	 *
	 * This is not an optimisation. UMeshComponent::SetMaterial already early-outs on an identical
	 * material, but a no-op that still marks the package dirty would check out and re-save every
	 * package in the project on a run that changed nothing - turning a repair tool into a
	 * source-control incident. Deciding it here keeps the write count equal to the change count.
	 */
	const bool bHasCurrent = Query.CurrentOverrideAtIndex.IsValidIndex(FoundIndex);
	const FString CurrentAtTarget = bHasCurrent ? Query.CurrentOverrideAtIndex[FoundIndex] : FString();
	if (CurrentAtTarget == Record.OverrideMaterialPackage)
	{
		Outcome.Decision = EORBDecision::AlreadyCorrect;
		return Outcome;
	}

	Outcome.Decision = EORBDecision::Rebind;
	return Outcome;
}

namespace ORBTypes
{
	FString EscapeHtml(const FString& In)
	{
		FString Out = In;
		// & FIRST, or the ampersands introduced by the later replacements are escaped a second time.
		Out.ReplaceInline(TEXT("&"), TEXT("&amp;"), ESearchCase::CaseSensitive);
		Out.ReplaceInline(TEXT("<"), TEXT("&lt;"), ESearchCase::CaseSensitive);
		Out.ReplaceInline(TEXT(">"), TEXT("&gt;"), ESearchCase::CaseSensitive);
		Out.ReplaceInline(TEXT("\""), TEXT("&quot;"), ESearchCase::CaseSensitive);
		return Out;
	}

	const TCHAR* StatusLabel(EORBRowStatus Status)
	{
		switch (Status)
		{
		case EORBRowStatus::Rebound:              return TEXT("rebound");
		case EORBRowStatus::WouldRebind:          return TEXT("would be rebound");
		case EORBRowStatus::AlreadyCorrect:       return TEXT("already correct");
		case EORBRowStatus::Reverted:             return TEXT("reverted");
		case EORBRowStatus::AlreadyAtPreviousValue: return TEXT("already at its previous value");
		case EORBRowStatus::RefusedSlotMissing:   return TEXT("refused - slot name is gone");
		case EORBRowStatus::RefusedAmbiguous:     return TEXT("refused - slot name is ambiguous");
		case EORBRowStatus::TargetMissing:        return TEXT("target not found");
		case EORBRowStatus::MaterialMissing:      return TEXT("override material not found");
		case EORBRowStatus::UnsupportedComponent: return TEXT("component type not written by this version");
		case EORBRowStatus::UnrecordedOverrideReported: return TEXT("not in the snapshot - reported, left alone");
		case EORBRowStatus::UnrecordedOverrideCleared:  return TEXT("not in the snapshot - cleared by -Strict");
		case EORBRowStatus::VerifyFailed:         return TEXT("write did not verify - rolled back");
		default:                                  return TEXT("unknown");
		}
	}
}
