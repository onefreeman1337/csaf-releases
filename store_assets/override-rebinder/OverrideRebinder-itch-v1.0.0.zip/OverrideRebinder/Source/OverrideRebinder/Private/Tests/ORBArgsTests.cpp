// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

#include "ORBArgs.h"

#include "Misc/AutomationTest.h"

#if WITH_DEV_AUTOMATION_TESTS

/*
 * THE TWO-PATH CASE IS THE REASON THIS FILE EXISTS.
 *
 * A sibling product in this wing shipped a defect where `-Paths=/Game/A,/Game/B` silently scanned
 * only `/Game/A`, because FParse::Value stops at a comma. Nothing about that failure is visible: the
 * run completes, the report looks correct, and it is a report about half the project. It was caught
 * by an automation test rather than by review, which is why the parser here is a pure function over
 * an array of strings - the case can be asserted without an engine, a project or a world.
 *
 * The packaging gate COMPILES these and never RUNS them. They must be executed:
 *   UnrealEditor-Cmd.exe <Project>.uproject -ExecCmds="Automation RunTests CSAF.OverrideRebinder"
 *     -NullRHI -unattended
 */

namespace
{
	const FString TestDir = TEXT("D:/Fixture/Saved");
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FORBArgsTwoPathsBothSurvive,
	"CSAF.OverrideRebinder.Args.TwoPathsBothSurvive",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FORBArgsTwoPathsBothSurvive::RunTest(const FString&)
{
	const FORBArgs Args = ORBParseArgs({ TEXT("Snapshot"), TEXT("Paths=/Game/A,/Game/B") }, TestDir);

	TestTrue(TEXT("parses"), Args.IsValid());
	TestEqual(TEXT("BOTH paths survive the comma"), Args.Paths.Num(), 2);
	if (Args.Paths.Num() == 2)
	{
		TestEqual(TEXT("first"), Args.Paths[0], FString(TEXT("/Game/A")));
		TestEqual(TEXT("second"), Args.Paths[1], FString(TEXT("/Game/B")));
	}
	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FORBArgsPlusSeparatorAlsoWorks,
	"CSAF.OverrideRebinder.Args.PlusSeparatorAlsoWorks",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FORBArgsPlusSeparatorAlsoWorks::RunTest(const FString&)
{
	// Engine command lines commonly use '+'. A user who types the separator the tool does not accept
	// gets a silent half-scan, which is the exact failure this whole file exists to prevent.
	const FORBArgs Args = ORBParseArgs({ TEXT("Snapshot"), TEXT("Paths=/Game/A+/Game/B+/Game/C") }, TestDir);

	TestTrue(TEXT("parses"), Args.IsValid());
	TestEqual(TEXT("all three survive"), Args.Paths.Num(), 3);
	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FORBArgsTrailingSlashDoesNotDuplicateAPath,
	"CSAF.OverrideRebinder.Args.TrailingSlashDoesNotDuplicateAPath",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FORBArgsTrailingSlashDoesNotDuplicateAPath::RunTest(const FString&)
{
	// Two spellings of one path would scan it twice and double every count on the report.
	const FORBArgs Args = ORBParseArgs({ TEXT("Snapshot"), TEXT("Paths=/Game/Maps/,/Game/Maps") }, TestDir);

	TestEqual(TEXT("one path, not two"), Args.Paths.Num(), 1);
	if (Args.Paths.Num() == 1)
	{
		TestEqual(TEXT("normalised"), Args.Paths[0], FString(TEXT("/Game/Maps")));
	}
	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FORBArgsApplyIsOffByDefault,
	"CSAF.OverrideRebinder.Args.ApplyIsOffByDefault",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FORBArgsApplyIsOffByDefault::RunTest(const FString&)
{
	/*
	 * The single most consequential default in the product. A tool that writes to every level in the
	 * project the first time somebody runs it to see what it does is not defensible at any price.
	 */
	const FORBArgs Preview = ORBParseArgs({ TEXT("Rebind") }, TestDir);
	TestFalse(TEXT("preview by default"), Preview.bApply);

	const FORBArgs Applied = ORBParseArgs({ TEXT("Rebind"), TEXT("Apply") }, TestDir);
	TestTrue(TEXT("-Apply turns it on"), Applied.bApply);
	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FORBArgsStrictIsOffByDefaultAndRebindOnly,
	"CSAF.OverrideRebinder.Args.StrictIsOffByDefaultAndRebindOnly",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FORBArgsStrictIsOffByDefaultAndRebindOnly::RunTest(const FString&)
{
	// -Strict is the only switch here that DELETES something, so both halves matter.
	const FORBArgs Plain = ORBParseArgs({ TEXT("Rebind"), TEXT("Apply") }, TestDir);
	TestFalse(TEXT("off by default"), Plain.bStrict);

	const FORBArgs Strict = ORBParseArgs({ TEXT("Rebind"), TEXT("Apply"), TEXT("Strict") }, TestDir);
	TestTrue(TEXT("-Strict turns it on"), Strict.bStrict);
	TestTrue(TEXT("and the run is still valid"), Strict.IsValid());

	/*
	 * Refused, not ignored. A silently-dropped -Strict is a user who believes a clean-up happened
	 * and never looks again - and being wrong in that direction is the expensive one.
	 */
	const FORBArgs Wrong = ORBParseArgs({ TEXT("Snapshot"), TEXT("Paths=/Game"), TEXT("Strict") }, TestDir);
	TestFalse(TEXT("-Strict on a snapshot is refused, never quietly dropped"), Wrong.IsValid());
	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FORBArgsTwoModesIsRefused,
	"CSAF.OverrideRebinder.Args.TwoModesIsRefused",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FORBArgsTwoModesIsRefused::RunTest(const FString&)
{
	/*
	 * SABOTAGE ARM. `-Snapshot -Rebind -Apply` is refused rather than resolved by precedence: a
	 * precedence rule would quietly write to the project when the user asked for two things and can
	 * only have meant one.
	 */
	const FORBArgs Args = ORBParseArgs(
		{ TEXT("Snapshot"), TEXT("Rebind"), TEXT("Apply"), TEXT("Paths=/Game") }, TestDir);

	TestFalse(TEXT("refuses to run"), Args.IsValid());
	TestTrue(TEXT("says why"), Args.Errors.Num() > 0);
	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FORBArgsNoModeIsRefused,
	"CSAF.OverrideRebinder.Args.NoModeIsRefused",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FORBArgsNoModeIsRefused::RunTest(const FString&)
{
	// Guessing which half of a snapshot/rebind pair the user meant is not a decision this tool gets.
	const FORBArgs Args = ORBParseArgs({ TEXT("Paths=/Game"), TEXT("Apply") }, TestDir);

	TestFalse(TEXT("refuses to run"), Args.IsValid());
	TestEqual(TEXT("no mode"), (int32)Args.Mode, (int32)EORBMode::None);
	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FORBArgsSnapshotWithoutPathsIsRefused,
	"CSAF.OverrideRebinder.Args.SnapshotWithoutPathsIsRefused",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FORBArgsSnapshotWithoutPathsIsRefused::RunTest(const FString&)
{
	// A snapshot cannot use the referencer shortlist a rebind uses, because at snapshot time nobody
	// knows which mesh is about to be redelivered. So it needs to be told what to read.
	const FORBArgs Args = ORBParseArgs({ TEXT("Snapshot") }, TestDir);

	TestFalse(TEXT("refuses to run"), Args.IsValid());
	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FORBArgsRevertNeedsItsJournal,
	"CSAF.OverrideRebinder.Args.RevertNeedsItsJournal",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FORBArgsRevertNeedsItsJournal::RunTest(const FString&)
{
	const FORBArgs Bare = ORBParseArgs({ TEXT("Revert") }, TestDir);
	TestFalse(TEXT("bare -Revert is refused"), Bare.IsValid());

	const FORBArgs Named = ORBParseArgs({ TEXT("Revert=D:/Runs/journal.json") }, TestDir);
	TestTrue(TEXT("-Revert=<file> parses"), Named.IsValid());
	TestEqual(TEXT("names that journal"), Named.JournalPath, FString(TEXT("D:/Runs/journal.json")));
	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FORBArgsRelativePathIsRefused,
	"CSAF.OverrideRebinder.Args.RelativePathIsRefused",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FORBArgsRelativePathIsRefused::RunTest(const FString&)
{
	/*
	 * "Maps" is not a content path, and the asset registry answers ZERO for it rather than erroring -
	 * which is the shape of a scan that never happened being reported as a clean project.
	 */
	const FORBArgs Args = ORBParseArgs({ TEXT("Snapshot"), TEXT("Paths=Maps") }, TestDir);

	TestFalse(TEXT("refuses to run"), Args.IsValid());
	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FORBArgsDefaultsAreDerivedFromTheGivenDirectory,
	"CSAF.OverrideRebinder.Args.DefaultsAreDerivedFromTheGivenDirectory",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FORBArgsDefaultsAreDerivedFromTheGivenDirectory::RunTest(const FString&)
{
	const FORBArgs Args = ORBParseArgs({ TEXT("Rebind") }, TestDir);

	TestEqual(TEXT("manifest default"), Args.ManifestPath,
		FString(TEXT("D:/Fixture/Saved/OverrideRebinder/snapshot.json")));
	TestEqual(TEXT("journal default"), Args.JournalPath,
		FString(TEXT("D:/Fixture/Saved/OverrideRebinder/journal.json")));
	TestTrue(TEXT("report default names the mode"),
		Args.ReportPath.EndsWith(TEXT("OverrideRebinder_rebind.html")));
	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FORBArgsExplicitManifestBeatsTheDefault,
	"CSAF.OverrideRebinder.Args.ExplicitManifestBeatsTheDefault",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FORBArgsExplicitManifestBeatsTheDefault::RunTest(const FString&)
{
	// Both spellings reach the same field, so a delivery script and a hand-typed run agree.
	const FORBArgs Suffixed = ORBParseArgs({ TEXT("Rebind=D:/Runs/a.json") }, TestDir);
	TestEqual(TEXT("-Rebind=<file>"), Suffixed.ManifestPath, FString(TEXT("D:/Runs/a.json")));

	const FORBArgs Explicit = ORBParseArgs({ TEXT("Rebind"), TEXT("Manifest=D:/Runs/b.json") }, TestDir);
	TestEqual(TEXT("-Manifest=<file>"), Explicit.ManifestPath, FString(TEXT("D:/Runs/b.json")));
	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FORBArgsEngineSwitchesAreIgnoredNotRejected,
	"CSAF.OverrideRebinder.Args.EngineSwitchesAreIgnoredNotRejected",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FORBArgsEngineSwitchesAreIgnoredNotRejected::RunTest(const FString&)
{
	// Every real invocation carries engine switches. Complaining about them would make the tool
	// unusable from a build agent, which is the buyer this product is priced for.
	const FORBArgs Args = ORBParseArgs(
		{ TEXT("Unattended"), TEXT("Snapshot"), TEXT("NoSplash"), TEXT("Paths=/Game"), TEXT("stdout") },
		TestDir);

	TestTrue(TEXT("still parses"), Args.IsValid());
	TestEqual(TEXT("mode survives"), (int32)Args.Mode, (int32)EORBMode::Snapshot);
	TestEqual(TEXT("path survives"), Args.Paths.Num(), 1);
	return true;
}

#endif // WITH_DEV_AUTOMATION_TESTS
