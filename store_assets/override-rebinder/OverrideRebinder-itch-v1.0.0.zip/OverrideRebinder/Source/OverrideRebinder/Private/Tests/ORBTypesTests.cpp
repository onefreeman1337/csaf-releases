// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

#include "ORBTypes.h"

#include "Misc/AutomationTest.h"

#if WITH_DEV_AUTOMATION_TESTS

/*
 * ⛔ THESE TESTS EXIST BECAUSE THIS RULE IS WHERE THE PRODUCT CAN CORRUPT A PROJECT.
 *
 * Everything else here is traversal and I/O. ORBDecideRebind is the one place a wrong answer writes
 * the wrong material onto actors across every level — the exact failure the tool is sold to cure.
 * The sabotage cases below are not padding: they assert the tool REFUSES, and a refusal is the only
 * behaviour a buyer cannot verify for themselves before trusting it.
 *
 * ⚠️ The packaging gate COMPILES automation tests and never RUNS them (wing CLAUDE.md). A green
 * gate says nothing about these. They must be executed:
 *   UnrealEditor-Cmd.exe <Project>.uproject -ExecCmds="Automation RunTests CSAF.OverrideRebinder"
 *     -NullRHI -unattended
 * and the run's own "tests performed" count compared against the number of tests below.
 */

namespace
{
	FORBOverrideRecord MakeRecord(FName SlotName, int32 IndexAtSnapshot, const FString& Material)
	{
		FORBOverrideRecord R;
		R.WorldPackage = TEXT("/Game/Maps/Test");
		R.ActorPackage = TEXT("/Game/Maps/Test");
		R.ActorPath = TEXT("/Game/Maps/Test.Test:PersistentLevel.Actor_0");
		R.ComponentName = TEXT("StaticMeshComponent0");
		R.MeshPackage = TEXT("/Game/Meshes/SM_Crate");
		R.SlotName = SlotName;
		R.SlotIndexAtSnapshot = IndexAtSnapshot;
		R.OverrideMaterialPackage = Material;
		return R;
	}

	FORBRebindQuery MakeQuery(const TArray<FName>& Names, const TArray<FString>& Current)
	{
		FORBRebindQuery Q;
		Q.CurrentSlotNames = Names;
		Q.CurrentOverrideAtIndex = Current;
		return Q;
	}
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FORBReorderIsRebound,
	"CSAF.OverrideRebinder.ReorderIsRebound",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FORBReorderIsRebound::RunTest(const FString&)
{
	/*
	 * ⭐ THE PRODUCT'S WHOLE REASON TO EXIST, as a test.
	 * Two slots swap order. The count does NOT change, so the engine's CleanUpOverrideMaterials
	 * removes nothing and logs nothing, and the override silently renders the wrong material.
	 * The rule must notice the name moved from index 0 to index 1 and target the NEW index.
	 */
	const FORBOverrideRecord Record = MakeRecord(TEXT("Trim"), 0, TEXT("/Game/M/M_Gold"));
	const FORBRebindQuery Query = MakeQuery(
		{ TEXT("Body"), TEXT("Trim") },
		{ TEXT(""), TEXT("") });

	const FORBRebindOutcome Out = ORBDecideRebind(Record, Query);

	TestEqual(TEXT("decision"), (int32)Out.Decision, (int32)EORBDecision::Rebind);
	TestEqual(TEXT("targets the NEW index, resolved by name"), Out.TargetIndex, 1);
	TestTrue(TEXT("reports that the index moved"), Out.bIndexMoved);
	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FORBMissingSlotIsRefused,
	"CSAF.OverrideRebinder.MissingSlotIsRefused",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FORBMissingSlotIsRefused::RunTest(const FString&)
{
	// SABOTAGE ARM: the slot the artist overrode is gone from the redelivered mesh.
	// A tool that "helpfully" wrote to index 0 here would put the wrong material on the actor.
	const FORBOverrideRecord Record = MakeRecord(TEXT("Trim"), 1, TEXT("/Game/M/M_Gold"));
	const FORBRebindQuery Query = MakeQuery({ TEXT("Body") }, { TEXT("") });

	const FORBRebindOutcome Out = ORBDecideRebind(Record, Query);

	TestEqual(TEXT("refuses"), (int32)Out.Decision, (int32)EORBDecision::RefusedSlotMissing);
	TestEqual(TEXT("names no target"), Out.TargetIndex, (int32)INDEX_NONE);
	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FORBAmbiguousSlotIsRefused,
	"CSAF.OverrideRebinder.AmbiguousSlotIsRefused",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FORBAmbiguousSlotIsRefused::RunTest(const FString&)
{
	/*
	 * SABOTAGE ARM, and the one an early-return implementation gets WRONG. Two slots share a name,
	 * so "by name" identifies two targets. A loop that stopped at the first match would return
	 * Rebind on index 0 and look perfectly correct in every other test.
	 */
	const FORBOverrideRecord Record = MakeRecord(TEXT("Trim"), 0, TEXT("/Game/M/M_Gold"));
	const FORBRebindQuery Query = MakeQuery(
		{ TEXT("Trim"), TEXT("Body"), TEXT("Trim") },
		{ TEXT(""), TEXT(""), TEXT("") });

	const FORBRebindOutcome Out = ORBDecideRebind(Record, Query);

	TestEqual(TEXT("refuses rather than picking the first match"),
		(int32)Out.Decision, (int32)EORBDecision::RefusedAmbiguous);
	TestEqual(TEXT("names no target"), Out.TargetIndex, (int32)INDEX_NONE);
	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FORBAlreadyCorrectWritesNothing,
	"CSAF.OverrideRebinder.AlreadyCorrectWritesNothing",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FORBAlreadyCorrectWritesNothing::RunTest(const FString&)
{
	// Nothing moved and the right material is already bound. Writing would dirty and re-save every
	// package in the project on a run that changed nothing.
	const FORBOverrideRecord Record = MakeRecord(TEXT("Trim"), 1, TEXT("/Game/M/M_Gold"));
	const FORBRebindQuery Query = MakeQuery(
		{ TEXT("Body"), TEXT("Trim") },
		{ TEXT(""), TEXT("/Game/M/M_Gold") });

	const FORBRebindOutcome Out = ORBDecideRebind(Record, Query);

	TestEqual(TEXT("no write"), (int32)Out.Decision, (int32)EORBDecision::AlreadyCorrect);
	TestFalse(TEXT("index did not move"), Out.bIndexMoved);
	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FORBSameIndexDifferentMaterialIsRebound,
	"CSAF.OverrideRebinder.SameIndexDifferentMaterialIsRebound",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FORBSameIndexDifferentMaterialIsRebound::RunTest(const FString&)
{
	// The name still resolves to the same index, but the engine's truncate-and-shuffle left a
	// different material there. Still a rebind, and bIndexMoved must NOT claim churn that
	// did not happen — the report distinguishes the two causes for the buyer.
	const FORBOverrideRecord Record = MakeRecord(TEXT("Trim"), 1, TEXT("/Game/M/M_Gold"));
	const FORBRebindQuery Query = MakeQuery(
		{ TEXT("Body"), TEXT("Trim") },
		{ TEXT(""), TEXT("/Game/M/M_Rust") });

	const FORBRebindOutcome Out = ORBDecideRebind(Record, Query);

	TestEqual(TEXT("rebinds"), (int32)Out.Decision, (int32)EORBDecision::Rebind);
	TestEqual(TEXT("same index"), Out.TargetIndex, 1);
	TestFalse(TEXT("does not report churn that did not happen"), Out.bIndexMoved);
	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FORBShorterMeshRefusesRatherThanClamping,
	"CSAF.OverrideRebinder.ShorterMeshRefusesRatherThanClamping",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)
bool FORBShorterMeshRefusesRatherThanClamping::RunTest(const FString&)
{
	/*
	 * The engine's own destructive case, from the other side: the mesh lost slots, so the override
	 * the artist set at index 2 was truncated away entirely. Its NAME is also gone, so the honest
	 * answer is a refusal with a report — never a clamp to the last valid index, which is exactly
	 * the "helpful" behaviour that would silently repaint the model.
	 */
	const FORBOverrideRecord Record = MakeRecord(TEXT("Decal"), 2, TEXT("/Game/M/M_Logo"));
	const FORBRebindQuery Query = MakeQuery(
		{ TEXT("Body"), TEXT("Trim") },
		{ TEXT(""), TEXT("") });

	const FORBRebindOutcome Out = ORBDecideRebind(Record, Query);

	TestEqual(TEXT("refuses"), (int32)Out.Decision, (int32)EORBDecision::RefusedSlotMissing);
	TestEqual(TEXT("does not clamp to a valid index"), Out.TargetIndex, (int32)INDEX_NONE);
	return true;
}

#endif // WITH_DEV_AUTOMATION_TESTS
