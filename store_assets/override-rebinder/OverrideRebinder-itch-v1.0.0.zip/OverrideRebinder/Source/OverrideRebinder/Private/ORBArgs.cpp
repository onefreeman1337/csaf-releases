// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

#include "ORBArgs.h"

namespace
{
	/**
	 * Split a switch token into its key and its value at the FIRST '='.
	 *
	 * The first, not the last: a Windows path can contain '=' in principle, and a value that
	 * contains one is the value's business, not the parser's.
	 */
	void SplitSwitch(const FString& Token, FString& OutKey, FString& OutValue, bool& bOutHasValue)
	{
		int32 Equals = INDEX_NONE;
		bOutHasValue = Token.FindChar(TEXT('='), Equals);
		if (bOutHasValue)
		{
			OutKey = Token.Left(Equals);
			OutValue = Token.Mid(Equals + 1);
		}
		else
		{
			OutKey = Token;
			OutValue.Empty();
		}

		// A quoted value arrives with its quotes on some invocation paths and without them on others.
		OutValue.TrimStartAndEndInline();
		OutValue.RemoveFromStart(TEXT("\""));
		OutValue.RemoveFromEnd(TEXT("\""));
	}

	/**
	 * THE COMMA CASE, WRITTEN OUT RATHER THAN DELEGATED.
	 *
	 * '+' is accepted as well as ',' because engine command lines commonly use it and a user who
	 * types the one this tool does not accept gets a silent half-scan, which is the failure mode
	 * this whole file exists to prevent.
	 */
	void AppendSplitPaths(const FString& Value, TArray<FString>& Out)
	{
		TArray<FString> Parts;
		Value.ParseIntoArray(Parts, TEXT(","), /*InCullEmpty*/ true);

		for (const FString& Part : Parts)
		{
			TArray<FString> SubParts;
			Part.ParseIntoArray(SubParts, TEXT("+"), /*InCullEmpty*/ true);
			for (FString Sub : SubParts)
			{
				Sub.TrimStartAndEndInline();
				if (Sub.IsEmpty())
				{
					continue;
				}
				// Trailing slashes make two spellings of one path, which then both get scanned.
				while (Sub.Len() > 1 && Sub.EndsWith(TEXT("/"), ESearchCase::CaseSensitive))
				{
					Sub.LeftChopInline(1);
				}
				Out.AddUnique(Sub);
			}
		}
	}

	FString JoinPath(const FString& Dir, const FString& Leaf)
	{
		FString Out = Dir;
		if (!Out.IsEmpty() && !Out.EndsWith(TEXT("/"), ESearchCase::CaseSensitive))
		{
			Out += TEXT("/");
		}
		return Out + Leaf;
	}
}

FORBArgs ORBParseArgs(const TArray<FString>& Switches, const FString& DefaultDir)
{
	FORBArgs Args;

	int32 ModesGiven = 0;
	FString RevertJournal;

	for (const FString& Token : Switches)
	{
		FString Key;
		FString Value;
		bool bHasValue = false;
		SplitSwitch(Token, Key, Value, bHasValue);

		if (Key.Equals(TEXT("Snapshot"), ESearchCase::IgnoreCase))
		{
			Args.Mode = EORBMode::Snapshot;
			++ModesGiven;
			if (bHasValue && !Value.IsEmpty())
			{
				Args.ManifestPath = Value;
			}
		}
		else if (Key.Equals(TEXT("Rebind"), ESearchCase::IgnoreCase))
		{
			Args.Mode = EORBMode::Rebind;
			++ModesGiven;
			if (bHasValue && !Value.IsEmpty())
			{
				Args.ManifestPath = Value;
			}
		}
		else if (Key.Equals(TEXT("Revert"), ESearchCase::IgnoreCase))
		{
			Args.Mode = EORBMode::Revert;
			++ModesGiven;
			RevertJournal = Value;
		}
		else if (Key.Equals(TEXT("Paths"), ESearchCase::IgnoreCase))
		{
			if (!bHasValue || Value.IsEmpty())
			{
				Args.Errors.Add(TEXT("-Paths was given with no value."));
			}
			else
			{
				AppendSplitPaths(Value, Args.Paths);
			}
		}
		else if (Key.Equals(TEXT("Manifest"), ESearchCase::IgnoreCase))
		{
			if (!bHasValue || Value.IsEmpty())
			{
				Args.Errors.Add(TEXT("-Manifest was given with no value."));
			}
			else
			{
				Args.ManifestPath = Value;
			}
		}
		else if (Key.Equals(TEXT("Journal"), ESearchCase::IgnoreCase))
		{
			if (!bHasValue || Value.IsEmpty())
			{
				Args.Errors.Add(TEXT("-Journal was given with no value."));
			}
			else
			{
				Args.JournalPath = Value;
			}
		}
		else if (Key.Equals(TEXT("Report"), ESearchCase::IgnoreCase))
		{
			if (!bHasValue || Value.IsEmpty())
			{
				Args.Errors.Add(TEXT("-Report was given with no value."));
			}
			else
			{
				Args.ReportPath = Value;
			}
		}
		else if (Key.Equals(TEXT("Apply"), ESearchCase::IgnoreCase))
		{
			Args.bApply = true;
		}
		else if (Key.Equals(TEXT("Strict"), ESearchCase::IgnoreCase))
		{
			Args.bStrict = true;
		}
		// Any other switch belongs to the engine (-NoSplash, -Unattended, -stdout and friends).
		// Silently ignoring them is correct; complaining about them would make the tool unusable.
	}

	if (ModesGiven == 0)
	{
		Args.Errors.Add(TEXT("No mode was given. Use exactly one of -Snapshot, -Rebind or -Revert=<journal>."));
	}
	else if (ModesGiven > 1)
	{
		/*
		 * Two modes is refused rather than resolved by precedence. A precedence rule here would mean
		 * that `-Snapshot -Rebind -Apply` quietly writes to the project when the user asked for two
		 * things and can only have meant one.
		 */
		Args.Errors.Add(TEXT("More than one mode was given. Use exactly one of -Snapshot, -Rebind or -Revert=<journal>."));
	}

	if (Args.Mode == EORBMode::Snapshot && Args.Paths.Num() == 0)
	{
		Args.Errors.Add(TEXT("-Snapshot needs -Paths=/Game/... . A snapshot cannot use the referencer "
			"shortlist a rebind uses, because at snapshot time nobody knows which mesh is about to be redelivered."));
	}

	if (Args.bStrict && Args.Mode != EORBMode::Rebind && Args.Mode != EORBMode::None)
	{
		/*
		 * Refused rather than ignored. A switch that is silently dropped is a user who believes a
		 * clean-up happened and never checks - and -Strict is the one switch here that DELETES
		 * something, so being wrong about whether it ran is the expensive direction.
		 */
		Args.Errors.Add(TEXT("-Strict only applies to -Rebind. A snapshot and a revert have nothing to clear."));
	}

	if (Args.Mode == EORBMode::Revert)
	{
		if (RevertJournal.IsEmpty())
		{
			Args.Errors.Add(TEXT("-Revert needs the journal to replay: -Revert=<path to journal .json>."));
		}
		else
		{
			Args.JournalPath = RevertJournal;
		}
	}

	for (const FString& Path : Args.Paths)
	{
		if (!Path.StartsWith(TEXT("/"), ESearchCase::CaseSensitive))
		{
			Args.Errors.Add(FString::Printf(
				TEXT("-Paths entry \"%s\" is not a content path. Content paths start with a mount point, e.g. /Game/Maps."),
				*Path));
		}
	}

	// Defaults last, so an explicit switch always wins and the defaults are visible in one place.
	const FString Dir = JoinPath(DefaultDir, TEXT("OverrideRebinder"));
	if (Args.ManifestPath.IsEmpty())
	{
		Args.ManifestPath = JoinPath(Dir, TEXT("snapshot.json"));
	}
	if (Args.JournalPath.IsEmpty())
	{
		Args.JournalPath = JoinPath(Dir, TEXT("journal.json"));
	}
	if (Args.ReportPath.IsEmpty())
	{
		Args.ReportPath = JoinPath(Dir, FString::Printf(TEXT("OverrideRebinder_%s.html"), Args.ModeName()));
	}

	return Args;
}
