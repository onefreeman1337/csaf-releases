// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

#include "ORBReport.h"

#include "Misc/DateTime.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"

namespace
{
	using ORBTypes::EscapeHtml;

	/** Shorten a filesystem path to something relative to the project, so nobody's home directory ships. */
	FString ProjectRelative(const FString& InPath)
	{
		if (InPath.IsEmpty())
		{
			return FString();
		}

		FString Full = InPath;
		FPaths::NormalizeFilename(Full);

		FString ProjectDir = FPaths::ConvertRelativePathToFull(FPaths::ProjectDir());
		FPaths::NormalizeDirectoryName(ProjectDir);

		FString Absolute = FPaths::ConvertRelativePathToFull(Full);
		if (!ProjectDir.IsEmpty() && Absolute.StartsWith(ProjectDir, ESearchCase::IgnoreCase))
		{
			return Absolute.RightChop(ProjectDir.Len() + 1);
		}

		// Outside the project: the file NAME is enough for the sheet and carries nobody's username.
		return FPaths::GetCleanFilename(Full);
	}

	/** The CSS class that carries a status's colour, so the stylesheet holds the palette and the code does not. */
	const TCHAR* StatusClass(EORBRowStatus Status)
	{
		switch (Status)
		{
		case EORBRowStatus::Rebound:
		case EORBRowStatus::Reverted:
		case EORBRowStatus::UnrecordedOverrideCleared:
			return TEXT("ok");
		case EORBRowStatus::WouldRebind:
			return TEXT("pending");
		case EORBRowStatus::AlreadyCorrect:
		case EORBRowStatus::AlreadyAtPreviousValue:
			return TEXT("quiet");
		case EORBRowStatus::RefusedSlotMissing:
		case EORBRowStatus::RefusedAmbiguous:
		case EORBRowStatus::UnrecordedOverrideReported:
			return TEXT("held");
		default:
			return TEXT("bad");
		}
	}

	FString Stylesheet()
	{
		return FString(
			TEXT("<style>\n")
			TEXT(":root{--bg:#11131a;--panel:#171a22;--panel2:#1d212b;--line:#2a3040;--ink:#e6e9f0;\n")
			TEXT("      --dim:#8d96ab;--accent:#7aa2f7;--ok:#9ece6a;--pending:#7aa2f7;--held:#e0af68;\n")
			TEXT("      --bad:#f7768e;--quiet:#6b7488}\n")
			TEXT("*{box-sizing:border-box}\n")
			TEXT("body{margin:0;background:var(--bg);color:var(--ink);\n")
			TEXT("     font:14px/1.55 'Segoe UI',system-ui,-apple-system,sans-serif}\n")
			TEXT(".wrap{max-width:1320px;margin:0 auto;padding:48px 40px}\n")
			TEXT("header{border-bottom:1px solid var(--line);padding-bottom:24px;margin-bottom:30px}\n")
			TEXT("h1{margin:0 0 6px;font-size:26px;font-weight:650;letter-spacing:-.015em}\n")
			TEXT(".sub{color:var(--dim);font-size:13px}\n")
			TEXT(".mode{display:inline-block;margin-left:10px;padding:3px 10px;border-radius:999px;\n")
			TEXT("      font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase}\n")
			TEXT(".mode.preview{background:rgba(122,162,247,.14);color:var(--pending);border:1px solid rgba(122,162,247,.38)}\n")
			TEXT(".mode.applied{background:rgba(158,206,106,.14);color:var(--ok);border:1px solid rgba(158,206,106,.38)}\n")
			TEXT(".mode.rolled{background:rgba(247,118,142,.14);color:var(--bad);border:1px solid rgba(247,118,142,.4)}\n")
			TEXT(".strip{display:grid;grid-template-columns:repeat(auto-fit,minmax(148px,1fr));gap:1px;\n")
			TEXT("       background:var(--line);border:1px solid var(--line);border-radius:10px;overflow:hidden;margin-bottom:14px}\n")
			TEXT(".stat{background:var(--panel);padding:16px 18px}\n")
			TEXT(".stat .n{font-size:25px;font-weight:650;letter-spacing:-.02em;font-variant-numeric:tabular-nums}\n")
			TEXT(".stat .k{color:var(--dim);font-size:11px;text-transform:uppercase;letter-spacing:.07em;margin-top:3px}\n")
			TEXT(".stat.ok .n{color:var(--ok)}.stat.pending .n{color:var(--pending)}\n")
			TEXT(".stat.held .n{color:var(--held)}.stat.bad .n{color:var(--bad)}\n")
			TEXT(".rests{color:var(--dim);font-size:12px;margin:0 0 30px;padding:12px 16px;\n")
			TEXT("       background:var(--panel);border:1px solid var(--line);border-radius:10px}\n")
			TEXT(".rests b{color:var(--ink);font-weight:600;font-variant-numeric:tabular-nums}\n")
			TEXT(".legend{display:flex;flex-wrap:wrap;gap:20px;margin:0 0 26px;font-size:12px;color:var(--dim)}\n")
			TEXT(".legend b{color:var(--ink);font-weight:600}\n")
			TEXT(".sw{display:inline-block;width:11px;height:11px;border-radius:3px;margin-right:7px;\n")
			TEXT("    vertical-align:-1px;border:1px solid rgba(255,255,255,.18)}\n")
			TEXT(".sw.ok{background:var(--ok)}.sw.pending{background:var(--pending)}\n")
			TEXT(".sw.held{background:var(--held)}.sw.bad{background:var(--bad)}.sw.quiet{background:var(--quiet)}\n")
			TEXT(".card{background:var(--panel);border:1px solid var(--line);border-radius:10px;\n")
			TEXT("      margin-bottom:20px;overflow:hidden}\n")
			TEXT(".card>.head{padding:15px 20px;border-bottom:1px solid var(--line);display:flex;\n")
			TEXT("            align-items:baseline;gap:14px;flex-wrap:wrap}\n")
			TEXT(".card>.head h2{margin:0;font-size:14px;font-weight:650;letter-spacing:.01em}\n")
			TEXT(".count{color:var(--dim);font-size:12px;font-variant-numeric:tabular-nums}\n")
			TEXT("table{width:100%;border-collapse:collapse;font-size:13px}\n")
			TEXT("th{text-align:left;padding:9px 20px;color:var(--dim);font-size:10.5px;font-weight:650;\n")
			TEXT("   letter-spacing:.08em;text-transform:uppercase;border-bottom:1px solid var(--line)}\n")
			TEXT("td{padding:10px 20px;border-bottom:1px solid rgba(42,48,64,.55);vertical-align:top}\n")
			TEXT("tr:last-child td{border-bottom:none}\n")
			TEXT(".path{font-family:'Cascadia Mono',Consolas,monospace;font-size:12px;word-break:break-all;color:var(--dim)}\n")
			TEXT(".slot{font-family:'Cascadia Mono',Consolas,monospace;font-size:13px;color:var(--ink);font-weight:600}\n")
			TEXT(".idx{font-variant-numeric:tabular-nums;color:var(--dim);white-space:nowrap}\n")
			TEXT(".idx .moved{color:var(--pending);font-weight:650}\n")
			TEXT(".st{font-weight:650}\n")
			TEXT(".st.ok{color:var(--ok)}.st.pending{color:var(--pending)}.st.held{color:var(--held)}\n")
			TEXT(".st.bad{color:var(--bad)}.st.quiet{color:var(--quiet)}\n")
			TEXT(".why{color:var(--dim);font-size:12px;margin-top:4px}\n")
			TEXT(".note{background:rgba(224,175,104,.07);border:1px solid rgba(224,175,104,.3);\n")
			TEXT("      border-radius:10px;padding:15px 20px;margin-bottom:26px}\n")
			TEXT(".note h2{margin:0 0 8px;font-size:12px;color:var(--held);letter-spacing:.06em;text-transform:uppercase}\n")
			TEXT(".note li{color:var(--dim);font-size:12.5px;margin:4px 0}\n")
			TEXT(".note ul{margin:0;padding-left:18px}\n")
			TEXT(".empty{padding:44px 20px;text-align:center;color:var(--dim)}\n")
			TEXT("footer{margin-top:36px;padding-top:20px;border-top:1px solid var(--line);\n")
			TEXT("       color:var(--dim);font-size:11.5px;line-height:1.75}\n")
			TEXT("footer b{color:var(--ink);font-weight:600}\n")
			TEXT("</style>\n"));
	}

	void AppendStat(FString& Html, const TCHAR* Class, int32 Number, const TCHAR* Label)
	{
		Html += FString::Printf(
			TEXT("<div class=\"stat %s\"><div class=\"n\">%d</div><div class=\"k\">%s</div></div>\n"),
			Class, Number, Label);
	}

	void AppendLegendKey(FString& Html, const TCHAR* Class, const TCHAR* Term, const TCHAR* Meaning)
	{
		Html += FString::Printf(
			TEXT("<span><span class=\"sw %s\"></span><b>%s</b> - %s</span>\n"), Class, Term, Meaning);
	}

	/** One row of the outcome table. */
	void AppendRow(FString& Html, const FORBRowResult& Row)
	{
		const TCHAR* Class = StatusClass(Row.Status);

		FString Index;
		if (Row.TargetIndex == INDEX_NONE)
		{
			Index = FString::Printf(TEXT("%d &rarr; <span class=\"held\">none</span>"),
				Row.Record.SlotIndexAtSnapshot);
		}
		else if (Row.bIndexMoved)
		{
			Index = FString::Printf(TEXT("%d &rarr; <span class=\"moved\">%d</span>"),
				Row.Record.SlotIndexAtSnapshot, Row.TargetIndex);
		}
		else
		{
			Index = FString::Printf(TEXT("%d"), Row.TargetIndex);
		}

		FString Detail;
		if (!Row.Detail.IsEmpty())
		{
			Detail = FString::Printf(TEXT("<div class=\"why\">%s</div>"), *EscapeHtml(Row.Detail));
		}

		Html += FString::Printf(
			TEXT("<tr>")
			TEXT("<td><span class=\"slot\">%s</span><div class=\"path\">%s</div></td>")
			TEXT("<td class=\"idx\">%s</td>")
			TEXT("<td class=\"path\">%s</td>")
			TEXT("<td><span class=\"st %s\">%s</span>%s</td>")
			TEXT("</tr>\n"),
			*EscapeHtml(Row.Record.SlotName.ToString()),
			*EscapeHtml(FString::Printf(TEXT("%s . %s"), *Row.Record.ActorPath, *Row.Record.ComponentName)),
			*Index,
			*EscapeHtml(Row.Record.OverrideMaterialPackage),
			Class,
			ORBTypes::StatusLabel(Row.Status),
			*Detail);
	}
}

namespace ORBReport
{
	FString Render(const FORBRunResult& Result)
	{
		const bool bSnapshot = Result.ModeName == TEXT("snapshot");
		const bool bRevert = Result.ModeName == TEXT("revert");

		FString Html;
		Html += TEXT("<!doctype html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n");
		Html += TEXT("<title>Override Rebinder</title>\n");
		Html += Stylesheet();
		Html += TEXT("</head>\n<body>\n<div class=\"wrap\">\n");

		// ---- header ------------------------------------------------------------------------------
		const TCHAR* ModeClass = TEXT("preview");
		const TCHAR* ModeText = TEXT("preview - nothing written");
		if (Result.bRolledBack)
		{
			ModeClass = TEXT("rolled");
			ModeText = TEXT("rolled back");
		}
		else if (bSnapshot)
		{
			ModeClass = TEXT("applied");
			ModeText = TEXT("snapshot taken");
		}
		else if (bRevert)
		{
			ModeClass = TEXT("applied");
			ModeText = TEXT("reverted");
		}
		else if (Result.bApply)
		{
			ModeClass = TEXT("applied");
			ModeText = TEXT("applied");
		}

		Html += TEXT("<header>\n<h1>Override Rebinder");
		Html += FString::Printf(TEXT("<span class=\"mode %s\">%s</span></h1>\n"), ModeClass, ModeText);
		Html += FString::Printf(TEXT("<div class=\"sub\">%s &middot; %s UTC</div>\n"),
			bSnapshot
				? TEXT("Per-actor material overrides, recorded against the slot NAME they were set on")
				: (bRevert
					? TEXT("Replaying the undo journal of a previous run")
					: TEXT("Putting per-actor material overrides back on the slot NAME they were set on")),
			*FDateTime::UtcNow().ToString(TEXT("%Y-%m-%d %H:%M")));
		Html += TEXT("</header>\n");

		// ---- the numbers -------------------------------------------------------------------------
		Html += TEXT("<div class=\"strip\">\n");
		if (bSnapshot)
		{
			AppendStat(Html, TEXT(""), Result.Counters.WorldsOpened, TEXT("levels opened"));
			AppendStat(Html, TEXT(""), Result.Counters.ActorsSeen, TEXT("actors seen"));
			AppendStat(Html, TEXT(""), Result.Counters.MeshComponentsSeen, TEXT("mesh components"));
			AppendStat(Html, TEXT("pending"), Result.Counters.ComponentsWithOverrides, TEXT("carry overrides"));
			AppendStat(Html, TEXT("ok"), Result.SnapshotRowsWritten, TEXT("rows recorded"));
			AppendStat(Html, Result.Counters.UnnamedSlotsSkipped > 0 ? TEXT("held") : TEXT(""),
				Result.Counters.UnnamedSlotsSkipped, TEXT("unnamed slots"));
		}
		else if (bRevert)
		{
			AppendStat(Html, TEXT(""), Result.Rows.Num(), TEXT("journal entries"));
			AppendStat(Html, TEXT("ok"), Result.CountRows(EORBRowStatus::Reverted), TEXT("restored"));
			AppendStat(Html, TEXT("quiet"), Result.CountRows(EORBRowStatus::AlreadyAtPreviousValue),
				TEXT("already back"));
			AppendStat(Html, Result.CountRefusals() > 0 ? TEXT("held") : TEXT(""),
				Result.CountRefusals(), TEXT("not restorable"));
			AppendStat(Html, TEXT(""), Result.Counters.PackagesSaved, TEXT("packages saved"));
		}
		else
		{
			const int32 Written = Result.CountRows(EORBRowStatus::Rebound);
			const int32 Pending = Result.CountRows(EORBRowStatus::WouldRebind);
			const int32 Unrecorded = Result.CountRows(EORBRowStatus::UnrecordedOverrideReported);
			const int32 Cleared = Result.CountRows(EORBRowStatus::UnrecordedOverrideCleared);
			AppendStat(Html, TEXT(""), Result.Rows.Num(), TEXT("rows in scope"));
			AppendStat(Html, TEXT("ok"), Written, TEXT("rebound"));
			AppendStat(Html, TEXT("pending"), Pending, TEXT("would rebind"));
			AppendStat(Html, TEXT("quiet"), Result.CountRows(EORBRowStatus::AlreadyCorrect),
				TEXT("already correct"));
			AppendStat(Html, Result.CountRefusals() > 0 ? TEXT("held") : TEXT(""),
				Result.CountRefusals(), TEXT("refused"));
			// Displaced overrides get their own number rather than being folded into "refused" -
			// they are the half of a reorder that a name-only rebind cannot reach, and a buyer
			// deciding whether to run -Strict needs to see how many there are.
			AppendStat(Html, Unrecorded > 0 ? TEXT("held") : TEXT("ok"),
				Cleared > 0 ? Cleared : Unrecorded,
				Cleared > 0 ? TEXT("displaced, cleared") : TEXT("displaced, left alone"));
			AppendStat(Html, TEXT(""), Result.Counters.PackagesSaved, TEXT("packages saved"));
		}
		Html += TEXT("</div>\n");

		// ---- what the numbers rest on ------------------------------------------------------------
		{
			FString Rests;
			if (bRevert)
			{
				/*
				 * A revert never scans, so it prints NO scan counters. Zeros here would describe work
				 * that was never attempted, and a reader cannot tell that kind of zero from a finding.
				 */
				Rests = FString::Printf(
					TEXT("This run replayed a journal and scanned nothing, so there are no scan counts to report. ")
					TEXT("It opened <b>%d</b> of the <b>%d</b> map(s) the journal names."),
					Result.Counters.WorldsOpened, Result.Counters.WorldsOffered);
			}
			else if (bSnapshot)
			{
				Rests = FString::Printf(
					TEXT("Opened <b>%d</b> of <b>%d</b> level(s) offered by the asset registry under the paths given. ")
					TEXT("Of <b>%d</b> mesh component(s), <b>%d</b> carried at least one override; ")
					TEXT("<b>%d</b> empty override entries were skipped as slots nobody overrode."),
					Result.Counters.WorldsOpened, Result.Counters.WorldsOffered,
					Result.Counters.MeshComponentsSeen, Result.Counters.ComponentsWithOverrides,
					Result.Counters.NullOverridesSkipped);
			}
			else
			{
				Rests = FString::Printf(
					TEXT("Opened <b>%d</b> of <b>%d</b> map(s) named by the snapshot. ")
					TEXT("The asset registry reports <b>%d</b> package(s) referencing the meshes in this snapshot, ")
					TEXT("and the snapshot has rows for <b>%d</b> of them - anything in the difference was placed ")
					TEXT("after the snapshot was taken and cannot be put back by it."),
					Result.Counters.WorldsOpened, Result.Counters.WorldsOffered,
					Result.Counters.ReferencingPackagesFound, Result.Counters.ReferencingPackagesCovered);
			}

			if (Result.Counters.PartitionedWorlds > 0)
			{
				Rests += FString::Printf(
					TEXT(" <b>%d</b> of these are World Partition maps, whose actors live in their own packages."),
					Result.Counters.PartitionedWorlds);
			}
			if (Result.Counters.PartitionedNotInitialised > 0)
			{
				Rests += FString::Printf(
					TEXT(" <b>%d</b> partitioned map(s) had no initialised partition in this process, so only the ")
					TEXT("actors already loaded were read - this run does not claim to have seen every actor in them."),
					Result.Counters.PartitionedNotInitialised);
			}
			Html += FString::Printf(TEXT("<p class=\"rests\">%s</p>\n"), *Rests);
		}

		// ---- anything that went wrong, before the detail ------------------------------------------
		if (Result.Problems.Num() > 0 || Result.Counters.UnsupportedComponents > 0)
		{
			Html += TEXT("<div class=\"note\">\n<h2>Worth reading before you trust the numbers</h2>\n<ul>\n");
			for (const FString& Problem : Result.Problems)
			{
				Html += FString::Printf(TEXT("<li>%s</li>\n"), *EscapeHtml(Problem));
			}
			if (Result.Counters.UnsupportedComponents > 0)
			{
				Html += FString::Printf(
					TEXT("<li>%d component(s) carry overrides on a component type this version does not write ")
					TEXT("through (%s). They were reported and left alone rather than written to by an untested route.</li>\n"),
					Result.Counters.UnsupportedComponents,
					*EscapeHtml(FString::Join(Result.Counters.UnsupportedComponentClasses, TEXT(", "))));
			}
			Html += TEXT("</ul>\n</div>\n");
		}

		// ---- legend ------------------------------------------------------------------------------
		if (!bSnapshot)
		{
			Html += TEXT("<div class=\"legend\">\n");
			if (bRevert)
			{
				AppendLegendKey(Html, TEXT("ok"), TEXT("restored"), TEXT("put back to the value the journal recorded"));
				AppendLegendKey(Html, TEXT("quiet"), TEXT("already back"), TEXT("nothing to undo, which is a success"));
			}
			else
			{
				AppendLegendKey(Html, TEXT("ok"), TEXT("rebound"),
					TEXT("written by name, read back, and saved"));
				AppendLegendKey(Html, TEXT("pending"), TEXT("would rebind"),
					TEXT("the rule says rebind and this run wrote nothing"));
				AppendLegendKey(Html, TEXT("quiet"), TEXT("already correct"),
					TEXT("the right material is already on the right slot"));
				AppendLegendKey(Html, TEXT("held"), TEXT("displaced"),
					TEXT("a slot the snapshot recorded as empty is carrying a material now; -Strict clears it"));
			}
			AppendLegendKey(Html, TEXT("held"), TEXT("refused"),
				TEXT("the name is gone or ambiguous, so the row was left exactly as it was"));
			AppendLegendKey(Html, TEXT("bad"), TEXT("failed"),
				TEXT("the target or the material was not there, or a write did not verify"));
			Html += TEXT("</div>\n");
		}

		// ---- the rows, grouped by the map they live in --------------------------------------------
		if (bSnapshot)
		{
			Html += TEXT("<div class=\"card\">\n<div class=\"head\"><h2>What was recorded</h2>");
			Html += FString::Printf(TEXT("<span class=\"count\">%d row(s)</span></div>\n"),
				Result.SnapshotRowsWritten);
			Html += FString::Printf(
				TEXT("<div class=\"empty\">Every row is keyed by the slot NAME the override was set on, not by its ")
				TEXT("index. Run <span class=\"slot\">-Rebind</span> after the mesh changes to put them back.<br><br>")
				TEXT("Snapshot: <span class=\"path\">%s</span></div>\n"),
				*EscapeHtml(ProjectRelative(Result.ManifestPath)));
			Html += TEXT("</div>\n");
		}
		else if (Result.Rows.Num() == 0)
		{
			Html += TEXT("<div class=\"card\"><div class=\"empty\">No rows were in scope for this run.</div></div>\n");
		}
		else
		{
			TArray<FString> Order;
			TMap<FString, TArray<const FORBRowResult*>> ByMap;
			for (const FORBRowResult& Row : Result.Rows)
			{
				if (!ByMap.Contains(Row.Record.WorldPackage))
				{
					Order.Add(Row.Record.WorldPackage);
				}
				ByMap.FindOrAdd(Row.Record.WorldPackage).Add(&Row);
			}

			for (const FString& MapName : Order)
			{
				const TArray<const FORBRowResult*>& Rows = ByMap[MapName];
				Html += TEXT("<div class=\"card\">\n<div class=\"head\">");
				Html += FString::Printf(TEXT("<h2>%s</h2>"), *EscapeHtml(MapName));
				Html += FString::Printf(TEXT("<span class=\"count\">%d row(s)</span></div>\n"), Rows.Num());
				Html += TEXT("<table>\n<tr><th>Slot and component</th><th>Index then &rarr; now</th>")
					TEXT("<th>Override material</th><th>Outcome</th></tr>\n");
				for (const FORBRowResult* Row : Rows)
				{
					AppendRow(Html, *Row);
				}
				Html += TEXT("</table>\n</div>\n");
			}
		}

		// ---- footer ------------------------------------------------------------------------------
		Html += TEXT("<footer>\n");
		Html += TEXT("<b>How this tool decides.</b> A slot name that resolves to exactly one index on the mesh as ")
			TEXT("it is now is rebound at that index. A name that is gone, or that names two slots, is reported and ")
			TEXT("left exactly as it was - a wrong re-bind is the same corruption this tool exists to cure, arriving ")
			TEXT("by a different route.<br>\n");
		Html += TEXT("<b>How it writes.</b> Through the engine's own SetMaterialByName, never by assigning ")
			TEXT("OverrideMaterials, because the engine's own header states that assigning that array directly can ")
			TEXT("race garbage collection against the rendering thread. Every write is read back before anything is ")
			TEXT("saved, and a map whose read-back disagrees is rolled back whole.<br>\n");
		if (!Result.JournalPath.IsEmpty())
		{
			Html += FString::Printf(
				TEXT("<b>Undo.</b> The journal was written before the first package was saved: ")
				TEXT("<span class=\"path\">%s</span> - replay it with <span class=\"slot\">-Revert</span>.<br>\n"),
				*EscapeHtml(ProjectRelative(Result.JournalPath)));
		}
		Html += TEXT("Override Rebinder for Unreal Engine 5.8 &middot; Core Systems Asset Factory\n");
		Html += TEXT("</footer>\n");

		Html += TEXT("</div>\n</body>\n</html>\n");
		return Html;
	}

	bool Write(const FORBRunResult& Result, const FString& Path, FString& OutError)
	{
		const FString Dir = FPaths::GetPath(Path);
		if (!Dir.IsEmpty() && !IFileManager::Get().DirectoryExists(*Dir))
		{
			IFileManager::Get().MakeDirectory(*Dir, /*Tree*/ true);
		}

		if (!FFileHelper::SaveStringToFile(Render(Result), *Path))
		{
			OutError = FString::Printf(TEXT("could not write the report to \"%s\""), *Path);
			return false;
		}
		return true;
	}
}
