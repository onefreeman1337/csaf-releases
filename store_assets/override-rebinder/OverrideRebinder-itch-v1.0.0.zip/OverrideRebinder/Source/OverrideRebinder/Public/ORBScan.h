// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "ORBTypes.h"

class AActor;
class UMeshComponent;
class UWorld;
struct FAssetData;

/*
 * TRAVERSAL - the part that decides WHICH packages are opened at all.
 *
 * Shared by snapshot and rebind so that "how a world's actors are reached" has one definition. The
 * two commands scope themselves differently (snapshot by -Paths, rebind by the manifest plus the
 * asset registry's referencer graph) but once a world is in hand, the way its actors are walked and
 * the way a component's mesh is identified must not be able to drift apart.
 */

namespace ORBScan
{
	/**
	 * Make the asset registry ready to be asked a question, and prove it was.
	 *
	 * WaitForCompletion() waits for a scan; it does not CAUSE one. A root the registry never indexed
	 * (a plugin's content, /Engine, a mounted path) answers zero from a fully-completed registry,
	 * which reads exactly like a clean project. ScanPathsSynchronous is a no-op for paths already
	 * scanned, so the ordinary /Game case pays nothing for this.
	 *
	 * @return false with OutError set when the registry reports no assets at all, which is a scan
	 *         that never happened rather than an empty project.
	 */
	bool PrepareRegistry(const TArray<FString>& Paths, FString& OutError);

	/** Every UWorld asset under the given content paths, recursively. */
	void FindWorlds(const TArray<FString>& Paths, TArray<FAssetData>& OutWorlds);

	/**
	 * Every actor of a world that this process can actually see, counted honestly.
	 *
	 * Under World Partition the actors live in external packages and are not loaded with the map, so
	 * an initialised partition is walked through the engine's own ForEachActorWithLoading. A
	 * partitioned world whose partition is NOT initialised in this process is counted separately and
	 * reported: its loaded actors are still read, but the run must not claim to have seen them all.
	 */
	void CollectActors(UWorld* World, TArray<AActor*>& OutActors, FORBCounters& Counters);

	/**
	 * The package path of the mesh asset a component is pointing at.
	 *
	 * Handles static and skinned meshes, which is the surface this version writes through. Anything
	 * else returns false and is REPORTED as unsupported rather than being written to through a path
	 * that was never tested - the known-limit discipline this wing ships.
	 */
	bool GetMeshPackage(const UMeshComponent* Component, FString& OutMeshPackage);

	/** Read the component's current per-index override bindings as plain strings, for the pure rule. */
	void ReadCurrentBindings(const UMeshComponent* Component, FORBRebindQuery& OutQuery);
}
