// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleInterface.h"

/*
 * ⛔ A MODULE WITH NO IMPLEMENT_MODULE GATES PERFECTLY AND CANNOT LOAD (wing CLAUDE.md).
 * The packaging gate compiles and links a module that never registers itself, so the failure does
 * not appear until a buyer enables the plugin. The IMPLEMENT_MODULE lives in the .cpp beside this
 * and is the reason this class exists at all.
 */
class FOverrideRebinderModule : public IModuleInterface
{
public:
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
};
