// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

#pragma once

#include "CoreMinimal.h"

/*
 * Exit codes are a selling feature: a build agent gates on them, so they are part of the product's
 * contract and are documented on the store page. Every one of them is derived from what the run
 * MEASURED, never asserted by the code that prints the summary.
 */
enum class EORBExit : int32
{
	/** Clean: nothing needed rebinding, or an apply run rebound every row it found. */
	Clean = 0,

	/** Bad arguments. The message names the switch. */
	BadArgs = 1,

	/**
	 * NOTHING WAS SCANNED. This is a FAILURE, never a pass - an empty result is the one answer an
	 * audit tool must not report as good news. Covers an unscanned or empty asset registry, a
	 * snapshot that opened no levels or saw no mesh components, and a rebind whose manifest holds no
	 * rows in scope.
	 */
	NothingScanned = 2,

	/** Preview found work: rows that need rebinding, or rows that had to be refused. */
	RebindsFound = 3,

	/** Applied, but some rows were REFUSED as ambiguous, missing or unsupported. Partial, per row. */
	AppliedWithRefusals = 4,

	/** A write failed verification and its map was rolled back whole. Nothing from it was saved. */
	RolledBack = 5,

	/**
	 * The run could not be completed at all - an unreadable manifest, an unwritable journal.
	 * Kept apart from NothingScanned so a build agent can tell "I examined nothing" from
	 * "I could not start", which want different responses.
	 */
	RunFailed = 6,
};

namespace ORBRun
{
	/**
	 * The whole product, from switches to exit code. Both entry points call exactly this, so the
	 * commandlet and the console command cannot drift apart in behaviour.
	 *
	 * @param Switches  Tokens with the leading '-' removed, as UCommandlet::ParseCommandLine produces.
	 */
	EORBExit Execute(const TArray<FString>& Switches);

	/** Split a raw parameter string into the switch tokens Execute expects. */
	void TokeniseSwitches(const FString& Params, TArray<FString>& OutSwitches);
}
