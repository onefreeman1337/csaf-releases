// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "ORBTypes.h"

/*
 * THE SHEET. This is the product's visible surface, so it is designed rather than dumped.
 *
 * Two rules it holds to, both learned the hard way in this wing:
 *
 *  - EVERY SWATCH IS DRAWN, NEVER TYPED. A legend key made from a Unicode box character depends on
 *    the reader's font coverage, and a shipped sheet in this wing rendered a missing-glyph box next
 *    to one of its labels because the black rectangle had a glyph and the white one did not. A span
 *    with a background and a border is the thing it labels and cannot fail to render.
 *
 *  - A PATH IS PRINTED RELATIVE TO THE PROJECT. Absolute paths put whoever ran the tool on the
 *    sheet, and every product in this wing prints file paths for a living.
 */
namespace ORBReport
{
	/** Render the run as a standalone HTML document. */
	FString Render(const FORBRunResult& Result);

	/** Render and write it. Returns false with OutError set on an I/O failure. */
	bool Write(const FORBRunResult& Result, const FString& Path, FString& OutError);
}
