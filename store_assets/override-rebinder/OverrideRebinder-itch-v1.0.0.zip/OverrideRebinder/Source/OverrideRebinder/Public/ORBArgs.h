// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

#pragma once

#include "CoreMinimal.h"

/*
 * ARGUMENT PARSING, AS A PURE FUNCTION OVER ALREADY-TOKENISED SWITCHES.
 *
 * WHY IT DOES NOT USE FParse::Value. FParse::Value stops at a comma by default, so
 * `-Paths=/Game/A,/Game/B` yields `/Game/A` and the second path is silently dropped. A sibling
 * product in this wing shipped exactly that bug, and it was caught by an automation test rather than
 * by review - which is why this layer is a pure function taking an array of strings: the two-path
 * case can be asserted in 200 microseconds without an engine, a project or a world.
 */

enum class EORBMode : uint8
{
	/** No mode switch was given. That is an error, not a default - guessing which half of a
	 *  snapshot/rebind pair the user meant is not a decision this tool gets to make. */
	None,

	/** Read the levels under -Paths and write the name-keyed manifest. */
	Snapshot,

	/** Read the manifest and put the overrides back by name. */
	Rebind,

	/** Replay a journal, undoing a previous -Apply run. */
	Revert,
};

struct FORBArgs
{
	EORBMode Mode = EORBMode::None;

	/** Content paths to read. Required for Snapshot; narrows the work for Rebind. */
	TArray<FString> Paths;

	/** Where the name-keyed manifest is written (Snapshot) or read from (Rebind). */
	FString ManifestPath;

	/** Where the undo journal is written. Written BEFORE the first package is saved. */
	FString JournalPath;

	/** Where the HTML sheet is written. */
	FString ReportPath;

	/**
	 * Nothing is written without this. Preview is the default because the alternative - a tool that
	 * writes to every level in the project the first time someone runs it to see what it does - is
	 * not a defensible default at any price.
	 */
	bool bApply = false;

	/**
	 * Also CLEAR an override that is sitting on a slot the snapshot recorded as having none.
	 *
	 * ⛔ OFF BY DEFAULT, AND NOT TO MAKE THE EXIT CODE PRETTIER. Re-binding by name is only half the
	 * repair: when slots are reordered, the displaced override is still sitting on the slot that now
	 * occupies the old index, and the actor still renders the wrong material there. The snapshot
	 * PROVES that slot had no override - so clearing it is justified, not guessed.
	 *
	 * But it cannot be distinguished from an override a human added after the snapshot was taken,
	 * and destroying somebody's work unasked is a worse failure than leaving wreckage behind and
	 * naming it. So the default reports those slots and a plain -Apply returns exit 4 rather than
	 * claiming to be clean over an actor that still looks wrong.
	 */
	bool bStrict = false;

	/** Populated on any parse failure. Non-empty means the run must not start. */
	TArray<FString> Errors;

	bool IsValid() const { return Errors.Num() == 0 && Mode != EORBMode::None; }

	const TCHAR* ModeName() const
	{
		switch (Mode)
		{
		case EORBMode::Snapshot: return TEXT("snapshot");
		case EORBMode::Rebind:   return TEXT("rebind");
		case EORBMode::Revert:   return TEXT("revert");
		default:                 return TEXT("none");
		}
	}
};

/**
 * Parse the switches of a commandlet or console invocation.
 *
 * @param Switches    Tokens with the leading '-' already removed, exactly as UCommandlet::ParseCommandLine
 *                    produces them, e.g. "Paths=/Game/A,/Game/B" or "Apply".
 * @param DefaultDir  Directory used to build the default manifest/journal/report paths. In the
 *                    product this is the project's Saved directory; in a test it is anything, which
 *                    is the point of passing it rather than reading FPaths inside.
 */
FORBArgs ORBParseArgs(const TArray<FString>& Switches, const FString& DefaultDir);
