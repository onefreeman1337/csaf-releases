// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "ORBTypes.h"

/*
 * THE MANIFEST AND THE JOURNAL, WITH THEIR FIELD NAMES DECLARED EXACTLY ONCE.
 *
 * Two commands read these files and one writes them. Master CLAUDE.md's shared-fact rule is the
 * reason they are not serialised inline at each call site: a field name typed in two places is a
 * place the product can move without anyone editing it, and the failure would be a rebind that
 * silently reads no rows - which looks identical to a clean project.
 */

/** One reversible write, recorded BEFORE the package that holds it is saved. */
struct FORBJournalEntry
{
	FString WorldPackage;
	FString ActorPackage;
	FString ActorPath;
	FString ComponentName;
	FName SlotName;

	/** The index the NAME resolved to at the time of the write. Recorded for the report, never replayed. */
	int32 TargetIndex = INDEX_NONE;

	/** What was bound before. EMPTY MEANS THERE WAS NO OVERRIDE, and a revert must clear the slot. */
	FString MaterialBefore;

	/** What this run bound. A revert asserts this is still what is there before undoing it. */
	FString MaterialAfter;
};

namespace ORBManifest
{
	/** Write the name-keyed snapshot. Returns false and fills OutError on any I/O failure. */
	bool SaveSnapshot(const FString& Path, const TArray<FORBOverrideRecord>& Records, FString& OutError);

	/**
	 * Read the name-keyed snapshot.
	 *
	 * A file that parses to ZERO rows is returned as success with an empty array; the CALLER decides
	 * that zero is a failure. That split is deliberate - the reader's job is to say what the file
	 * contains, and "an empty result is never a clean bill of health" is a policy the run owns.
	 */
	bool LoadSnapshot(const FString& Path, TArray<FORBOverrideRecord>& OutRecords, FString& OutError);

	bool SaveJournal(const FString& Path, const TArray<FORBJournalEntry>& Entries, FString& OutError);
	bool LoadJournal(const FString& Path, TArray<FORBJournalEntry>& OutEntries, FString& OutError);
}
