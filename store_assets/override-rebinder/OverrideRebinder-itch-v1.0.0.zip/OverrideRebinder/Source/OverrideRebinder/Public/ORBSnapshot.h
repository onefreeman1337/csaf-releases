// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "ORBArgs.h"
#include "ORBTypes.h"

/*
 * PHASE ONE. Read the levels under -Paths and write down what every per-actor material override is
 * bound to, KEYED BY SLOT NAME.
 *
 * This phase is the slow one and it is honest about why: a per-component material override is not an
 * asset registry tag, so there is no way to answer the question without opening the level packages.
 * It runs once per art delivery cycle rather than per edit, which is what makes that acceptable. The
 * report prints levels offered against levels opened so the cost and the coverage are both visible.
 */
namespace ORBSnapshot
{
	/**
	 * Take the snapshot. Fills Result's counters and writes the manifest when bApply is irrelevant -
	 * a snapshot writes only its own manifest file and never touches a project package, so it is safe
	 * in both preview and apply.
	 *
	 * @return false with OutError set only when the run could not be attempted at all (an unscanned
	 *         registry, an unwritable manifest path). A snapshot that finds nothing is a SUCCESSFUL
	 *         run reporting zero rows, and the caller turns that into the NothingScanned exit code.
	 */
	bool Run(const FORBArgs& Args, FORBRunResult& Result, TArray<FORBOverrideRecord>& OutRecords, FString& OutError);
}
