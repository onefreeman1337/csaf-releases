// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Commandlets/Commandlet.h"
#include "ORBRun.h"
#include "ORBCommandlet.generated.h"

/*
 * THE CLASS NAME IS THE CONTRACT. `-run=<X>` resolves to the class named `<X>Commandlet`
 * (LaunchEngineLoop.cpp:2334 appends "Commandlet" to the token and :3939 looks up exactly that one
 * name), so the documented switch `-run=OverrideRebinder` requires exactly
 * `UOverrideRebinderCommandlet`. A sibling product in this wing shipped documenting
 * `-run=NiagaraBoundsSolver` against a class called `UNBSCommandlet`, which cannot resolve - the
 * plugin was fine and the advertised command did nothing. The FILE may be abbreviated
 * (ORBCommandlet.h); the CLASS may not.
 */
UCLASS()
class UOverrideRebinderCommandlet : public UCommandlet
{
	GENERATED_BODY()

public:
	UOverrideRebinderCommandlet();

	//~ Begin UCommandlet interface
	virtual int32 Main(const FString& Params) override;
	//~ End UCommandlet interface
};
