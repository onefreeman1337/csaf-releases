// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

#pragma once

#include "CoreMinimal.h"

/*
 * The snapshot record and the rebind DECISION RULE.
 *
 * NOTHING IN THIS HEADER TOUCHES AN ENGINE TYPE, AND THAT IS DELIBERATE. The two places this
 * product can be wrong in a way that matters are (1) which slot a saved override belongs to and
 * (2) when to refuse rather than guess. Both live here, in plain data, so they can be exercised by
 * automation tests without a world, a mesh or a component. The sibling product in this wing found
 * a real shipped bug in exactly this layer because it was testable; the layer that needed a loaded
 * level would not have been.
 */

/** What a snapshot row is bound to. Slot NAME is the durable key; the index is kept only to detect churn. */
struct FORBOverrideRecord
{
	/**
	 * The MAP that has to be opened to reach this actor again.
	 *
	 * Kept separately from ActorPackage because under World Partition they are different packages:
	 * the actor lives in its own external package, but it is still only reachable by opening the
	 * world that owns it.
	 */
	FString WorldPackage;

	/**
	 * The package that actually holds the actor, and therefore the package that must be checked out
	 * and saved. Equal to WorldPackage on an ordinary level; the external actor package under
	 * World Partition or One File Per Actor.
	 */
	FString ActorPackage;

	/** Stable path to the actor, so the row can be found again after a reload. */
	FString ActorPath;

	/** Component name within the actor - an actor may carry several mesh components. */
	FString ComponentName;

	/** The mesh asset the component pointed at WHEN THE SNAPSHOT WAS TAKEN. */
	FString MeshPackage;

	/** THE DURABLE KEY. Read from GetMaterialSlotNames()[Index] at snapshot time. */
	FName SlotName;

	/** The slot index at snapshot time. Kept ONLY to report order churn - never used to re-bind. */
	int32 SlotIndexAtSnapshot = INDEX_NONE;

	/** The override material the artist chose. This is put back; its VALUE is never inspected or altered. */
	FString OverrideMaterialPackage;
};

/** What the rule decided for one row. */
enum class EORBDecision : uint8
{
	/** The slot name resolves to exactly one index and the bound material differs. Re-bind it. */
	Rebind,

	/** Already correct - the name resolves and the right material is already there. Touch nothing. */
	AlreadyCorrect,

	/**
	 * The slot name is GONE from the new mesh. Report and leave alone.
	 * This is the honest half of "a slot genuinely vanished from source" - it is information for the
	 * artist, not a problem for the tool to solve by picking a neighbouring index.
	 */
	RefusedSlotMissing,

	/**
	 * The slot name appears MORE THAN ONCE on the new mesh, so "by name" does not identify a
	 * single target. Report and leave alone. Guessing here is the corruption this tool exists to
	 * cure, arriving by a different route.
	 */
	RefusedAmbiguous,
};

/** The inputs the rule needs, already extracted from the engine by the caller. */
struct FORBRebindQuery
{
	/** The slot names of the mesh AS IT IS NOW, in index order (from GetMaterialSlotNames()). */
	TArray<FName> CurrentSlotNames;

	/** The material currently bound at each index, or empty where nothing is overridden. */
	TArray<FString> CurrentOverrideAtIndex;
};

struct FORBRebindOutcome
{
	EORBDecision Decision = EORBDecision::RefusedSlotMissing;

	/** Where the row should be written, resolved BY NAME. Only meaningful for Rebind. */
	int32 TargetIndex = INDEX_NONE;

	/** True when the name resolved to a different index than it held at snapshot time. */
	bool bIndexMoved = false;
};

/*
 * The whole decision, in one pure function.
 *
 * It resolves by NAME and never by SlotIndexAtSnapshot. The engine's own failure is that it keeps
 * the index and loses the name; reusing the index here would reproduce the defect faithfully.
 */
FORBRebindOutcome ORBDecideRebind(
	const FORBOverrideRecord& Record,
	const FORBRebindQuery& Query);

// -------------------------------------------------------------------------------------------------
// Everything below is the RESULT of a run: what the report prints and what the exit code is derived
// from. It is plain data for the same reason the rule above is - so the report can be built and
// reasoned about without a world.
// -------------------------------------------------------------------------------------------------

/** Why a row was not written. Distinct from EORBDecision because two reasons are not the RULE's. */
enum class EORBRowStatus : uint8
{
	/** Written, read back, verified, and the package saved. Only ever produced by an -Apply run. */
	Rebound,

	/**
	 * The rule says rebind and NOTHING WAS WRITTEN, because this was a preview.
	 *
	 * A separate status rather than a flag on Rebound. A sibling product in this wing printed
	 * "preview (nothing written)" over a run that had saved 49 packages; the inverse - a preview
	 * whose rows read as though they had been applied - is the same defect facing the other way.
	 * The status itself says which happened, so no reader has to combine two fields correctly.
	 */
	WouldRebind,

	/** Nothing to do - already bound to the recorded material at the name-resolved index. */
	AlreadyCorrect,

	/** Revert only: the slot was put back to what the journal says it held before the run. */
	Reverted,

	/**
	 * Revert only: the slot ALREADY holds its pre-run value, so there was nothing to undo.
	 *
	 * Counted apart from a failure on purpose. A sibling product in this wing reported exactly this
	 * situation as six warnings and turned a correct, fully-verified revert into a CI failure.
	 */
	AlreadyAtPreviousValue,

	/** The rule refused: the slot name is gone from the mesh as it is now. */
	RefusedSlotMissing,

	/** The rule refused: the slot name resolves to more than one index. */
	RefusedAmbiguous,

	/** The world, actor or component named by the row could not be found any more. */
	TargetMissing,

	/** The override material asset the row names could not be loaded, so there is nothing to put back. */
	MaterialMissing,

	/** The component class is outside the surface this version writes through. Reported, never guessed at. */
	UnsupportedComponent,

	/**
	 * A slot the snapshot recorded as having NO override is carrying one now, and it was LEFT ALONE.
	 *
	 * This is the other half of a reorder. When slots swap, the displaced override is still sitting
	 * at the old index, which is now a different slot - so re-binding by name fixes the slot that
	 * moved and leaves the wrong material on the slot that took its place. The snapshot proves that
	 * slot had nothing, so clearing it is justified; it is still not distinguishable from something
	 * a human added afterwards, so the default reports it and -Strict clears it.
	 */
	UnrecordedOverrideReported,

	/** The same slot, cleared, because -Strict was given. Its previous value is in the journal. */
	UnrecordedOverrideCleared,

	/** The write was made and the read-back did not agree. The group was rolled back. */
	VerifyFailed,
};

/** One row of the sheet: the snapshot row, what happened to it, and why. */
struct FORBRowResult
{
	FORBOverrideRecord Record;

	EORBRowStatus Status = EORBRowStatus::TargetMissing;

	/** The index the NAME resolved to in the mesh as it is now. INDEX_NONE when it did not resolve. */
	int32 TargetIndex = INDEX_NONE;

	/** True when the name resolved to a different index than the snapshot recorded. */
	bool bIndexMoved = false;

	/** What was bound at the resolved index BEFORE this run touched it. Empty means nothing was. */
	FString MaterialBefore;

	/** Free-text detail for the sheet. Never a substitute for Status - it explains, it does not decide. */
	FString Detail;
};

/**
 * Counts, and always in OFFERED / OPENED pairs.
 *
 * The wing rule this satisfies: report what was offered against what was opened, so a buyer can see
 * what the numbers rest on rather than being handed a bare verdict. A scan that opened 3 of 240
 * levels and a scan that opened 240 of 240 can both print "0 problems", and they do not mean the
 * same thing.
 */
struct FORBCounters
{
	int32 WorldsOffered = 0;
	int32 WorldsOpened = 0;

	/** Worlds that ARE partitioned and whose partition was initialised, so their actors were streamed in. */
	int32 PartitionedWorlds = 0;

	/**
	 * Partitioned worlds whose partition was NOT initialised in this process. Their loaded actors were
	 * still read, but the scan cannot claim to have seen every actor in them - so it says so instead.
	 */
	int32 PartitionedNotInitialised = 0;

	int32 ActorsSeen = 0;
	int32 MeshComponentsSeen = 0;
	int32 ComponentsWithOverrides = 0;

	/** Override entries that were null, i.e. a slot the artist did not actually override. */
	int32 NullOverridesSkipped = 0;

	/** Override entries whose slot has no name at all on the mesh - unkeyable, so reported not guessed. */
	int32 UnnamedSlotsSkipped = 0;

	/** Components whose mesh asset this version does not read (neither static nor skinned). */
	int32 UnsupportedComponents = 0;

	/** Distinct component classes behind UnsupportedComponents, so the report names them. */
	TArray<FString> UnsupportedComponentClasses;

	/** Rebind only: packages the registry says reference a snapshot mesh. */
	int32 ReferencingPackagesFound = 0;

	/** Rebind only: how many of those the snapshot actually has rows for. The delta is the honest gap. */
	int32 ReferencingPackagesCovered = 0;

	int32 PackagesSaved = 0;
	int32 PackagesCheckedOut = 0;
};

/** The whole run, ready to be rendered and to have an exit code derived from it. */
struct FORBRunResult
{
	/** "snapshot", "rebind" or "revert" - printed on the sheet, never inferred by the reader. */
	FString ModeName;

	/** True when the run was allowed to write. Preview is the default and the sheet says which. */
	bool bApply = false;

	FORBCounters Counters;

	TArray<FORBRowResult> Rows;

	/** Rows the snapshot phase produced. Only populated in snapshot mode. */
	int32 SnapshotRowsWritten = 0;

	FString ManifestPath;
	FString JournalPath;
	FString ReportPath;

	/** Things that went wrong but did not stop the run. Printed prominently rather than buried in a log. */
	TArray<FString> Problems;

	/** True when a verification failure forced a rollback. Drives the RolledBack exit code. */
	bool bRolledBack = false;

	/**
	 * True when the failure was "the registry answered nothing", as opposed to any other failure.
	 *
	 * It exists so the exit code can tell an EMPTY SCAN apart from a broken run. Both are non-zero,
	 * but a build agent gating on "nothing was examined" wants a different answer from one gating on
	 * "the tool could not start", and collapsing them would hand it the wrong one.
	 */
	bool bScanFailed = false;

	int32 CountRows(EORBRowStatus Status) const
	{
		int32 N = 0;
		for (const FORBRowResult& Row : Rows)
		{
			if (Row.Status == Status)
			{
				++N;
			}
		}
		return N;
	}

	int32 CountRefusals() const
	{
		return CountRows(EORBRowStatus::RefusedSlotMissing)
			+ CountRows(EORBRowStatus::RefusedAmbiguous)
			+ CountRows(EORBRowStatus::TargetMissing)
			+ CountRows(EORBRowStatus::MaterialMissing)
			+ CountRows(EORBRowStatus::UnsupportedComponent);
	}

	/**
	 * Everything a human still has to look at after this run.
	 *
	 * A reported-but-not-cleared override belongs here even though nothing refused it, because the
	 * project is still not back to what the snapshot recorded - and an exit code that reads "clean"
	 * over an actor rendering the wrong material is the exact green lie this wing keeps paying for.
	 */
	int32 CountNeedsAttention() const
	{
		return CountRefusals() + CountRows(EORBRowStatus::UnrecordedOverrideReported);
	}
};

namespace ORBTypes
{
	/** The four characters that can break an HTML document, escaped once, in one place. */
	FString EscapeHtml(const FString& In);

	/** Stable, human-readable label for a row status. Used by the sheet and by the log. */
	const TCHAR* StatusLabel(EORBRowStatus Status);
}
