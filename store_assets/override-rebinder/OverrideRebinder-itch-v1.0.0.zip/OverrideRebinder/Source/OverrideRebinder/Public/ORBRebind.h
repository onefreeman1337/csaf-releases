// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "ORBArgs.h"
#include "ORBTypes.h"

/*
 * PHASE TWO. Put the overrides back BY NAME, and the undo that makes phase two safe to run.
 *
 * This is the command that runs under time pressure - art has redelivered, the map looks wrong, and
 * somebody wants it fixed before the playtest. Everything in it is arranged so that the fast path is
 * also the safe one:
 *
 *   - it opens only the maps the manifest names, not the project;
 *   - it decides every row through ORBDecideRebind, which refuses rather than guesses;
 *   - it writes through SetMaterialByName, never by assigning OverrideMaterials;
 *   - it reads every write back before saving anything, and rolls the map back if one disagrees;
 *   - it writes the journal BEFORE the first package is saved, so -Revert works even on a run that
 *     was killed halfway through saving.
 */
namespace ORBRebind
{
	/** Re-bind by name. Writes nothing unless Args.bApply. */
	bool Run(const FORBArgs& Args, FORBRunResult& Result, FString& OutError);

	/**
	 * Replay a journal, undoing an -Apply run.
	 *
	 * A revert performs no scan, so the report it produces prints what was RESTORED and deliberately
	 * prints no scan counters at all - a run that never attempted to examine anything must not print
	 * "0 examined", which reads as a finding rather than as an absence of one.
	 */
	bool Revert(const FORBArgs& Args, FORBRunResult& Result, FString& OutError);
}
