/**
 * content.js — THE LESSON AND THE SHAFTS, free edition.
 *
 * ⛔⛔ §1-DEMO. PAID CONTENT IS A FILE THE FREE BUILD DOES NOT LOAD, NEVER A BRANCH IT DOES NOT
 *     TAKE. A previous title in this wing shipped every paid boss name and its winning ending
 *     inside a demo that differed by ONE NUMBER, and served the full game at a guessable URL.
 *     So: this file holds the SIX marks the free edition teaches and the FOUR shafts it descends,
 *     and nothing else. `content_full.js` — which only the paid build's index.html has a <script>
 *     tag for — adds the other six marks' terms, shafts five to twelve, and the ending.
 *
 * ⛔ THE MARK TABLE IS THE PRODUCT. It is constant across every run and printed on no screen: the
 *    player learns it by choosing which four marks to carry and feeling the difference. That is
 *    family (C) LEARNED MAPPING (wing §6b-62) — "what carries between runs is not a stat or an
 *    unlock, it is knowing what a shape means". The screen that passed this design measured 12
 *    rules, 20,736 pictures (1728x), 0.0% of the rule set understood by the end of run 1, and 11
 *    runs to 90% understood.
 *
 * ⭐ THE PAIRS ARE DELIBERATE AND THEY ARE THE GAME: COIL and TWIN are opposite in `curl`,
 *    CRESCENT and COMB opposite in `gravity`, EYE and STAR opposite in `radial`. Carrying both of
 *    a pair CANCELS that axis, which is how a player designs a carry-set that isolates one term
 *    from the compound. The evidence is evidence the player's own action creates.
 */
(function (root) {
  'use strict';

  /* The harness with nothing in it is still a body falling down a hole. */
  var BASE = {
    thrust: 0.055,   // acceleration along the held direction
    drag: 0.955,     // per-frame velocity multiplier (LOWER = more friction)
    gravity: 0.020,  // constant downward acceleration
    curl: 0,         // radians the velocity rotates each frame
    bounce: 0.35,    // restitution against rock
    grip: 0,         // extra damping while touching rock
    pulse: 0,        // impulse along the held direction, every PULSE_PERIOD frames
    radial: 0,       // acceleration toward the shaft's centre line (negative pushes out)
  };

  /* ⛔ Every axis is clamped after summing. Four marks can otherwise take `drag` above 1, which
   *  is not friction at all but an exponential runaway, and a game that cannot be played is not a
   *  lesson. The clamps are part of the design, not a safety net bolted on. */
  var CLAMP = {
    thrust: [0.015, 0.220], drag: [0.860, 0.995], gravity: [-0.060, 0.100],
    curl: [-0.100, 0.100], bounce: [0, 0.950], grip: [0, 0.900],
    pulse: [0, 2.000], radial: [-0.080, 0.080],
  };

  /* The six the free edition teaches. Chosen to span the axes in BOTH directions so the free
   * lesson is a real lesson and not a teaser: thrust up and down, drag up and down, gravity up
   * and down, and one curl. */
  var MARKS = {
    keel:     { drag: -0.030, thrust: +0.010 },
    fork:     { thrust: +0.040, drag: +0.010 },
    ring:     { drag: +0.025, bounce: +0.12 },
    coil:     { curl: +0.030, thrust: +0.008 },
    crescent: { gravity: +0.030, drag: +0.006 },
    comb:     { gravity: -0.032, thrust: +0.006 },
  };

  /* A shaft is a snaking corridor of rock. `note` is carved on the harness before you descend —
   * it states the shaft's CHARACTER, never which marks to carry. */
  /* ⛔ THE SHAFTS ARE SPREAD ON TWO AXES ON PURPOSE, AND THE SECOND ONE WAS ADDED AFTER A
   * MEASUREMENT. Revision 1 varied only WIDTH and TURN, which is one axis wearing three names:
   * every shaft wanted the same handling and ADAPTIVE MINUS BEST-FIXED came out 0 over twelve
   * shafts and 495 carry-sets. `pull` is the second axis — a shaft that hauls you down wants a
   * light, high-drag carry, and a shaft that pushes you UP wants a heavy one, and no single set
   * is good at both. `depth` against the lamp's time burn is the third: a long shaft punishes
   * caution the way a narrow one punishes speed. */
  /* ⛔ EVERY NOTE IS ONE LINE OF 26 CHARACTERS OR FEWER. The harness band has exactly three rows
   * and the third is the control hint, which a reviewer found existed NOWHERE else in the game.
   * A note that wraps steals that row, so the length is part of the content, not a style choice,
   * and verify_notes_fit.js re-derives the cap from the font rather than trusting this comment. */
  var SHAFTS = [
    { id: 1, name: 'THE COLLAR',   note: 'WIDE. FEEL WHAT YOU CARRY.',
      depth: 900,  seed: 1841, amp: 8,  freq: 0.020, halfW: 46, wob: 6,  wobFreq: 0.013, toothEvery: 0,   toothLen: 0, pull: 0 },
    { id: 2, name: 'THE GULLET',   note: 'IT NARROWS. ARRIVE SLOWLY.',
      depth: 1100, seed: 2297, amp: 14, freq: 0.022, halfW: 28, wob: 8,  wobFreq: 0.019, toothEvery: 0,   toothLen: 0, pull: 0 },
    { id: 3, name: 'THE WINDING',  note: 'IT TURNS AND KEEPS TURNING',
      depth: 1300, seed: 3719, amp: 30, freq: 0.018, halfW: 34, wob: 7,  wobFreq: 0.017, toothEvery: 0,   toothLen: 0, pull: 0 },
    { id: 4, name: 'THE LONGDROP', note: 'DEEP AND OPEN. GO FAST.',
      depth: 2300, seed: 4523, amp: 8,  freq: 0.012, halfW: 44, wob: 6,  wobFreq: 0.011, toothEvery: 0,   toothLen: 0, pull: 0 },
  ];

  root.CONTENT = {
    edition: 'free',
    BASE: BASE,
    CLAMP: CLAMP,
    marks: MARKS,
    shafts: SHAFTS,
    ending: null,
    /** The ending screen's heading. ⛔ It lives HERE and not in game.js, which ships in both
     *  editions — a literal there put the last shaft's name in the free download. */
    endingTitle: 'THE FREE SHAFTS END HERE',
    /** Shown when the free edition runs out of shafts. The paid build overwrites it with a real
     *  ending; it is never a "buy now" interruption mid-descent.
     *  ⛔ It used to name a shaft that does not exist in either edition, and it never said a full
     *     game existed, never named it and pointed nowhere — the ONLY conversion surface in the
     *     free build, converting nothing. It now makes the offer plainly and once. */
    demoEnd: [
      'THE SHAFT GOES ON BELOW THIS.',
      'EIGHT MORE, AND SIX MARKS YOU HAVE NOT HELD.',
      '',
      'THE FULL LODESTONE IS ON THE PAGE YOU CAME FROM.',
      'TWELVE SHAFTS, ALL TWELVE MARKS, AND IT ENDS.',
    ].join('\n'),
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.CONTENT;
}(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this)));
