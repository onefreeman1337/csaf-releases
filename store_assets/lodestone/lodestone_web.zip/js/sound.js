/**
 * sound.js — LODESTONE's audio.
 *
 * ⛔⛔ TWO WING LAWS SET THE WHOLE SHAPE OF THIS FILE, AND BOTH WERE PAID FOR BY SHIPPED DEFECTS:
 *
 *  §2a — "USE AN <audio> ELEMENT" IS NECESSARY AND NOT SUFFICIENT. The paid desktop build loads
 *        from file://, where fetch and XHR are both blocked outright. Music therefore plays from
 *        a BARE <audio> element with its own `volume`, OUT of the WebAudio graph. ⛔ NEVER set
 *        crossOrigin and NEVER feed the element to createMediaElementSource — on file:// both
 *        give silence in the paid download, which is the worst possible place for it.
 *
 *  §8a-4 — A CUE GATED ON THE MUSIC'S READINESS IS SWALLOWED. A `ready` flag meaning "the tracks
 *        decoded" drops every sound the player makes until the audio files land, INCLUDING THE
 *        FIRST PRESS, ALWAYS. So every SFX cue is gated on its own requirement and nothing else:
 *        an AudioContext in state 'running'. The SFX are synthesised from oscillators at cue
 *        time, so there is no buffer to wait for at all.
 *
 * ⚠ Procedural synthesis is NOT generative AI (wing §0-ART): no Sounds tag on the listing. The
 *   music loops are rendered by Kernel/capture/make_audio.js from a note spec we wrote — our own
 *   IP, no licence, no model.
 */
(function (root) {
  'use strict';

  var ctx = null, muted = false, music = null, wantMusic = false;

  function ac() {
    if (ctx) return ctx;
    var AC = root.AudioContext || root.webkitAudioContext;
    if (!AC) return null;
    try { ctx = new AC(); } catch (e) { ctx = null; }
    return ctx;
  }

  /** ⛔ No autoplay. The first real input starts the context; called from every input path. */
  function unlock() {
    var c = ac();
    if (c && c.state === 'suspended') c.resume();
    if (music && wantMusic && music.paused && !muted) {
      var p = music.play();
      if (p && p.catch) p.catch(function () { /* autoplay refused: the next press tries again */ });
    }
  }

  /* One voice: an oscillator or noise through a gain envelope. Nothing is pre-decoded, so a cue
   * is never waiting on a file. */
  function voice(o) {
    var c = ac();
    if (!c || c.state !== 'running' || muted) return false;   // ⛔ its OWN requirement, nothing else
    var t = c.currentTime;
    var g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, o.gain), t + (o.attack || 0.005));
    g.gain.exponentialRampToValueAtTime(0.0001, t + o.dur);
    g.connect(c.destination);

    var src;
    if (o.noise) {
      var n = Math.max(1, Math.floor(c.sampleRate * o.dur));
      var buf = c.createBuffer(1, n, c.sampleRate);
      var d = buf.getChannelData(0);
      var last = 0;
      for (var i = 0; i < n; i++) {
        var w = Math.random() * 2 - 1;
        last = last * 0.86 + w * 0.14;                 // a low-passed rumble, not white hiss
        d[i] = o.bright ? w : last * 3;
      }
      src = c.createBufferSource(); src.buffer = buf;
      if (o.filter) {
        var f = c.createBiquadFilter();
        f.type = 'bandpass'; f.frequency.value = o.filter; f.Q.value = 1.2;
        src.connect(f); f.connect(g);
      } else src.connect(g);
    } else {
      src = c.createOscillator();
      src.type = o.type || 'square';
      src.frequency.setValueAtTime(o.f0, t);
      if (o.f1 && o.f1 !== o.f0) src.frequency.exponentialRampToValueAtTime(Math.max(1, o.f1), t + o.dur);
      src.connect(g);
    }
    src.start(t);
    src.stop(t + o.dur + 0.02);
    return true;
  }

  var CUES = {
    move:    function () { voice({ type: 'square', f0: 420, f1: 520, dur: 0.045, gain: 0.05 }); },
    set:     function () { voice({ type: 'square', f0: 260, f1: 390, dur: 0.09, gain: 0.07 }); },
    ok:      function () { voice({ type: 'triangle', f0: 330, f1: 660, dur: 0.12, gain: 0.08 }); },
    descend: function () {
      voice({ type: 'triangle', f0: 300, f1: 90, dur: 0.42, gain: 0.10 });
      voice({ noise: true, filter: 260, dur: 0.5, gain: 0.05 });
    },
    scrape:  function () { voice({ noise: true, filter: 900, dur: 0.10, gain: 0.045 }); },
    pulse:   function () { voice({ type: 'square', f0: 160, f1: 300, dur: 0.07, gain: 0.055 }); },
    cleared: function () {
      voice({ type: 'triangle', f0: 392, f1: 392, dur: 0.16, gain: 0.09 });
      setTimeout(function () { voice({ type: 'triangle', f0: 523, f1: 523, dur: 0.16, gain: 0.09 }); }, 130);
      setTimeout(function () { voice({ type: 'triangle', f0: 659, f1: 784, dur: 0.34, gain: 0.09 }); }, 260);
    },
    dark:    function () {
      voice({ type: 'sawtooth', f0: 210, f1: 60, dur: 0.6, gain: 0.08 });
      voice({ noise: true, filter: 180, dur: 0.7, gain: 0.05 });
    },
  };

  /** ⛔ Counted, never silent: an unknown cue id is a defect, not a no-op. */
  var unknown = {};
  function cue(id) {
    var f = CUES[id];
    if (!f) { unknown[id] = (unknown[id] || 0) + 1; return false; }
    f();
    return true;
  }

  /** ⛔ §2a: a BARE element, its own volume, never in the WebAudio graph, no crossOrigin. */
  function attachMusic(el) {
    music = el;
    if (!music) return;
    music.loop = true;
    music.volume = muted ? 0 : 0.42;
    wantMusic = true;
  }

  /** ⛔ Mute drives el.volume EXPLICITLY, in the same edit that sets the flag. */
  function setMuted(m) {
    muted = !!m;
    if (music) {
      music.volume = muted ? 0 : 0.42;
      if (muted) music.pause();
      else if (wantMusic) { var p = music.play(); if (p && p.catch) p.catch(function () {}); }
    }
    try { root.localStorage.setItem('LODESTONE_MUTE', muted ? '1' : '0'); } catch (e) { /* private mode */ }
  }

  function restoreMuted() {
    try { return root.localStorage.getItem('LODESTONE_MUTE') === '1'; } catch (e) { return false; }
  }

  root.LSOUND = {
    cue: cue, unlock: unlock, setMuted: setMuted, restoreMuted: restoreMuted,
    attachMusic: attachMusic, unknown: unknown,
    state: function () { return { ctx: ctx ? ctx.state : 'none', muted: muted, music: !!music }; },
    CUES: CUES,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.LSOUND;
}(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this)));
