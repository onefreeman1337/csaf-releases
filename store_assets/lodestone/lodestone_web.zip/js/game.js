/**
 * game.js — LODESTONE. The dungeon does what the stones you carry add up to.
 *
 * ONE SENTENCE OF DESIGN: you descend carrying four engraved marks, your movement is the SUM of
 * their terms, no single mark is ever shown to you, and the only way to learn what one means is
 * to choose a carry-set that isolates it and feel the difference.
 *
 * ⛔ THE PRIMARY INPUT IS A HOLD (wing §0a-2, the flow directive): you hold a direction and your
 *    momentum integrates the carried sum continuously. Choosing marks happens BETWEEN descents
 *    and is not the moment-to-moment loop, which is what separates this from "select an option
 *    and press go".
 *
 * ⛔ §1a — THE AUTOMATION TAB IS HIDDEN AND rAF IS THROTTLED TO ZERO THERE. Every wrapper in this
 *    wing exposes a SYNCHRONOUS stepper so a harness can drive the real game without a frame
 *    clock, and before diagnosing "the build does not draw" you print visibilityState and the
 *    frame counter: 0 is a stalled loop, not a broken game. Here that is
 *    `window.LODESTONE.step(n)` plus `window.LODESTONE.frames`.
 */
(function (root) {
  'use strict';

  var ART = root.ART, FONT = root.DW_FONT, C = root.CONTENT, SND = root.LSOUND;
  var W = ART.SCREEN_W, H = ART.SCREEN_H;
  var LIT = ART.LIT, FACE = ART.FACE, MID = ART.MID, SHADOW = ART.SHADOW;
  var DMG = ['#9bbc0f', '#8bac0f', '#306230', '#0f380f'];

  /* ------------------------------------------------------------------------------ state */

  var S = {
    screen: 'title',
    frames: 0,
    shaftIx: 0,
    sockets: [0, 1, 2, 3],   // indices into POOL
    cursor: 0,
    lamp: 100,
    run: null,
    result: null,
    held: { x: 0, y: 0 },
    learned: {},             // mark id -> descents carried, purely a player-facing tally
    muted: false,
    paused: false,
    endPage: 0,
    markPage: 0,
    best: {},                // shaft id -> best lamp remaining on a clear. PERSISTED.
  };

  /* ⛔⛔ THE MARGIN THE WHOLE DESIGN RESTS ON WAS INVISIBLE TO THE PLAYER. An independent review
   * measured it: on the binary cleared/failed channel a single fixed carry-set clears all twelve
   * shafts, so GAP = 0 — and the channel where choosing REALLY pays (lamp remaining: GAP 167.7,
   * 30.8%, nine distinct best sets, the best fixed set optimal on 0 of 12) was printed once on a
   * result card and then thrown away. A game whose premise is "knowing the marks matters" has to
   * SHOW that it matters, or the premise is true only in a log file. So the best lamp per shaft
   * is kept, shown on the harness before you descend, and beaten. */
  var BEST_KEY = 'LODESTONE_BEST_' + (C.edition === 'full' ? 'full' : 'free');
  function loadBest() {
    try {
      var raw = root.localStorage.getItem(BEST_KEY);
      S.best = raw ? JSON.parse(raw) : {};
    } catch (e) { S.best = {}; }
    if (!S.best || typeof S.best !== 'object') S.best = {};
  }
  function saveBest() {
    try { root.localStorage.setItem(BEST_KEY, JSON.stringify(S.best)); } catch (e) { /* private mode */ }
  }
  function bestFor(id) { var v = S.best[String(id)]; return typeof v === 'number' ? v : null; }
  function clearedCount() {
    var n = 0;
    for (var i = 0; i < C.shafts.length; i++) if (bestFor(C.shafts[i].id) !== null) n++;
    return n;
  }
  loadBest();

  /** The marks this EDITION has terms for. ⛔ Mirror error loud (§1-DEMO rule 3): the pool is
   *  derived from the content file's own table, never from a hard-coded count, and a mismatch
   *  THROWS rather than wrapping with a modulo. */
  var POOL = ART.MARKS.map(function (m, i) { return { i: i, id: m.id, name: m.name }; })
    .filter(function (m) { return Object.prototype.hasOwnProperty.call(C.marks, m.id); });
  if (POOL.length < 4) {
    throw new Error('content: only ' + POOL.length + ' marks have terms; a harness has four sockets');
  }
  if (!C.shafts.length) throw new Error('content: no shafts');

  /* ------------------------------------------------------------------------------ physics */

  var PULSE_PERIOD = 36;

  /** Sum the four carried marks onto the base, then clamp every axis. */
  function terms(sockets) {
    var t = {}, k;
    for (k in C.BASE) t[k] = C.BASE[k];
    for (var i = 0; i < sockets.length; i++) {
      var d = C.marks[POOL[sockets[i]].id];
      if (!d) throw new Error('no terms for mark ' + POOL[sockets[i]].id);
      for (k in d) t[k] = (t[k] || 0) + d[k];
    }
    for (k in C.CLAMP) {
      if (t[k] === undefined) continue;
      t[k] = Math.max(C.CLAMP[k][0], Math.min(C.CLAMP[k][1], t[k]));
    }
    return t;
  }

  /* --------------------------------------------------------------------------- the shaft */

  function hash2(x, y) {
    var n = (x | 0) * 374761393 + (y | 0) * 668265263;
    n = Math.imul(n ^ (n >>> 13), 1274126177);
    return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
  }

  /** The corridor's open span at world depth y. Never narrower than a body can pass. */
  function corridor(sh, y) {
    var cx = 80
      + sh.amp * Math.sin(y * sh.freq + sh.p0)
      + sh.amp * 0.4 * Math.sin(y * sh.freq * 2.3 + sh.p1);
    var hw = sh.halfW + sh.wob * Math.sin(y * sh.wobFreq + sh.p2);
    var left = cx - hw, right = cx + hw;
    if (sh.toothEvery > 0) {
      var t = y % sh.toothEvery;
      var side = Math.floor(y / sh.toothEvery) % 2;
      var bite = Math.max(0, 1 - Math.abs(t - sh.toothEvery / 2) / 16) * sh.toothLen;
      if (side === 0) left += bite; else right -= bite;
    }
    if (left < 2) left = 2;
    if (right > W - 3) right = W - 3;
    // ⛔ A shaft you cannot pass is not difficulty, it is a broken generator. The floor is
    //    measured against the body (r=3) with room to steer, and verify_shaft.js re-derives it.
    if (right - left < 15) {
      var m = (left + right) / 2;
      left = m - 7.5; right = m + 7.5;
    }
    return { left: left, right: right };
  }

  function beginDescent() {
    var sh = C.shafts[S.shaftIx];
    var r = sh.seed;
    sh.p0 = (r % 97) / 97 * 6.283;
    sh.p1 = (r % 61) / 61 * 6.283;
    sh.p2 = (r % 43) / 43 * 6.283;
    var c0 = corridor(sh, 0);
    S.run = {
      sh: sh, t: terms(S.sockets),
      /* ⛔ y STARTS BELOW THE HUD. At y=6 the camera does not scroll yet, so the carrier was
       * drawn at screen row 6 and then PAINTED OVER by the HUD band — the player's own character
       * was invisible for the first second of every single descent, and the store GIF's opening
       * frame had no player in it at all. The HUD is 11 rows plus a rule; 24 clears it. */
      x: (c0.left + c0.right) / 2, y: 24, vx: 0, vy: 0,
      tick: 0, hits: 0, touching: false, done: null,
    };
    S.lamp = 100;
    S.screen = 'descent';
    for (var i = 0; i < 4; i++) {
      var id = POOL[S.sockets[i]].id;
      S.learned[id] = (S.learned[id] || 0) + 1;
    }
    if (SND) SND.cue('descend');
  }

  function stepDescent() {
    var r = S.run, t = r.t, sh = r.sh;
    r.tick++;

    /* ⛔ `sh.pull` IS THE SHAFT'S OWN DEMAND, AND IT EXISTS BECAUSE THE FIRST TUNED BUILD HAD
     * ADAPTIVE MINUS BEST-FIXED = 0 ON TWELVE SHAFTS. Every shaft was a snaking corridor, so they
     * differed in DIFFICULTY and not in KIND, and one carry-set (KEEL+FORK+CHEVRON+LATTICE)
     * cleared every shaft that was clearable at all. A negative pull is an updraught: it fights
     * your descent, the lamp burns by time, and the only answer is to carry MORE weight —
     * the exact opposite of what a long heavy drop wants. Opposite demands are what a
     * per-shaft choice can be better at than any fixed one. */
    var ax = S.held.x * t.thrust;
    var ay = S.held.y * t.thrust + t.gravity + (sh.pull || 0);
    if (t.pulse > 0 && r.tick % PULSE_PERIOD === 0 && (S.held.x || S.held.y)) {
      var m = Math.hypot(S.held.x, S.held.y) || 1;
      ax += S.held.x / m * t.pulse * 0.25;
      ay += S.held.y / m * t.pulse * 0.25;
      if (SND) SND.cue('pulse');
    }
    if (t.radial !== 0) {
      var c = corridor(sh, r.y);
      var mid = (c.left + c.right) / 2;
      ax += (mid - r.x > 0 ? 1 : -1) * t.radial * Math.min(1, Math.abs(mid - r.x) / 24);
    }

    r.vx += ax; r.vy += ay;

    if (t.curl !== 0) {                       // the velocity itself rotates: you veer
      var cs = Math.cos(t.curl), sn = Math.sin(t.curl);
      var nvx = r.vx * cs - r.vy * sn, nvy = r.vx * sn + r.vy * cs;
      r.vx = nvx; r.vy = nvy;
    }

    r.vx *= t.drag; r.vy *= t.drag;

    var sp = Math.hypot(r.vx, r.vy), CAP = 4.2;
    if (sp > CAP) { r.vx = r.vx / sp * CAP; r.vy = r.vy / sp * CAP; }

    r.x += r.vx; r.y += r.vy;
    if (r.y < 2) { r.y = 2; if (r.vy < 0) r.vy = 0; }

    /* ⛔⛔ THE PRESSURE IS TWO-SIDED, AND REVISION 1 HAD NO PRESSURE AT ALL. Measured by
     * play_through.js --balance on the first build: three of four shafts were cleared by EVERY
     * carry-set and ADAPTIVE MINUS BEST-FIXED was 0 — the twelve marks were decoration. That is
     * §6b-2 rule 4 verbatim: a fail state whose remedy is FREE AND INFINITELY REPEATABLE is not
     * one. A flat 0.55 lamp cost per touch meant a body could bounce down the whole shaft.
     *
     * So the cost of meeting rock is now the IMPACT, and it is superlinear: a graze is nearly
     * free and a collision at speed is most of the lamp. With the lamp also burning with TIME,
     * the player is squeezed from both ends — too fast smashes, too slow goes dark — and WHERE a
     * carry-set sits on that axis is the whole game. GRIP buys a cheaper graze, which is what
     * makes LATTICE worth a socket in a tight shaft and worthless in an open one. */
    var impact = Math.hypot(r.vx, r.vy);
    var co = corridor(sh, r.y);
    r.touching = false;
    if (r.x - 3 < co.left) {
      r.x = co.left + 3;
      if (r.vx < 0) r.vx = -r.vx * t.bounce;
      r.touching = true;
    } else if (r.x + 3 > co.right) {
      r.x = co.right - 3;
      if (r.vx > 0) r.vx = -r.vx * t.bounce;
      r.touching = true;
    }
    if (r.touching) {
      r.hits++;
      r.vy *= (1 - t.grip * 0.5);
      r.vx *= (1 - t.grip * 0.5);
      var cost = (0.22 + 1.45 * Math.pow(impact, 1.6)) * (1 - t.grip * 0.70);
      S.lamp -= cost;
      r.worst = Math.max(r.worst || 0, cost);
      if (r.hits % 6 === 1 && SND) SND.cue('scrape');
    }
    S.lamp -= 0.062;

    if (r.y >= sh.depth) {
      r.done = 'cleared';
      var lamp = Math.max(0, S.lamp);
      var prev = bestFor(sh.id);
      var isBest = prev === null || lamp > prev;
      if (isBest) { S.best[String(sh.id)] = lamp; saveBest(); }
      S.result = { ok: true, shaft: sh, hits: r.hits, lamp: lamp, ticks: r.tick,
        best: isBest ? lamp : prev, newBest: isBest, hadBest: prev !== null };
      S.screen = 'result';
      if (SND) SND.cue('cleared');
      return;
    }
    if (S.lamp <= 0) {
      S.lamp = 0;
      r.done = 'dark';
      S.result = { ok: false, shaft: sh, hits: r.hits, lamp: 0, ticks: r.tick, depth: Math.round(r.y) };
      S.screen = 'result';
      if (SND) SND.cue('dark');
    }
  }

  /* ----------------------------------------------------------------------------- drawing */

  var plane = new ART.Plane(W, H, MID);
  var harnessCache = { key: '', plane: null };

  /* ⛔ THE LINE LENGTH IS DERIVED FROM THE FACE, NEVER TYPED. The first build wrapped at a
   * remembered 26 in one place and a guessed 30 in another; the font's clip counter then found
   * SEVEN strings running off the screen across four different cards, none of which I had looked
   * at. A number copied into a checker is the same defect as one copied into a listing. */
  var MAXCH = Math.floor(W / FONT.FACES.body.adv);
  /* ⛔ A LINE LENGTH IS DERIVED AGAINST ITS OWN CONTAINER, NOT AGAINST THE SCREEN. MAXCH is
   * right for text on the open board and WRONG inside a card: `card()` draws a plate from x=6 to
   * x=153, so a 26-character line inked past both plate edges and sat on the striped ground
   * outside it. The comment that used to live here boasted the number was derived and never
   * typed — it was derived against the wrong box, which is the same defect wearing a compliment. */
  var CARD_X = 6, CARD_PAD = 4;
  var CARDCH = Math.floor((W - CARD_X * 2 - CARD_PAD * 2) / FONT.FACES.body.adv);

  function wrap(str, max) {
    max = max || MAXCH;
    var words = String(str).split(' '), lines = [], cur = '';
    for (var i = 0; i < words.length; i++) {
      var next = cur ? cur + ' ' + words[i] : words[i];
      if (next.length > max && cur) { lines.push(cur); cur = words[i]; }
      else cur = next;
    }
    if (cur) lines.push(cur);
    return lines;
  }

  function drawHarness() {
    var live = [true, true, true, true];
    var key = S.sockets.join(',');
    if (harnessCache.key !== key) {
      harnessCache.plane = ART.harnessScreen(S.sockets.map(function (s) { return POOL[s].i; }), { live: live });
      harnessCache.key = key;
    }
    plane.px.set(harnessCache.plane.px);

    var sh = C.shafts[S.shaftIx];
    // The shaft's note, carved across the bottom of the board on its own dark band.
    plane.rect(0, H - 26, W, 26, SHADOW);
    plane.hline(0, W - 1, H - 27, LIT);
    // ⛔ H - 7 is the LAST y a 7-row face fits at. H - 6 clipped the bottom row of every
    //    two-line note, silently, on every shaft with a long one.
    var best = bestFor(sh.id);
    FONT.textPlane(plane, sh.id + '  ' + sh.name, W / 2, H - 24, { align: 'center', shade: LIT });
    // Every shaft note is authored to fit one line, which frees the third row for the controls —
    // ⛔ a reviewer found that NOTHING anywhere in the game says how to work the harness, and the
    //    only place it existed was a div outside the canvas that a short viewport hides.
    FONT.textPlane(plane, wrap(sh.note)[0], W / 2, H - 16, { align: 'center', shade: FACE });
    // ⛔ 26 characters. The clip guard caught a 31-char version of this line the moment it was
    //    written, which is the guard doing exactly what it was added for.
    FONT.textPlane(plane, best === null ? 'ARROWS PICK YOUR FOUR'
      : 'BEST LAMP HERE ' + Math.round(best) + '%', W / 2, H - 8,
      // shade 1 on the shade-3 band is 105.2 luma; shade 2 there would be 38.3, which is the
      // same too-dim pairing this build has already been caught on twice.
      { align: 'center', shade: best === null ? FACE : LIT });

    // The selected socket, ringed. Shade 0 on the plate's own shade-3 outline where it can.
    var s = ART.SOCKETS[S.cursor];
    for (var a = 0; a < 64; a++) {
      var an = a / 64 * 6.283;
      var px = Math.round(s.x + Math.cos(an) * (ART.SOCKET_R + 5));
      var py = Math.round(s.y + Math.sin(an) * (ART.SOCKET_R + 5));
      plane.set(px, py, (S.frames >> 3) % 2 ? LIT : SHADOW);
    }
    /* ⛔ S.learned WAS A DEAD WRITER — incremented on every descent and read by nothing, which is
     * §0z-1c from the other side. It is the one number that tracks the actual subject of the game
     * ("how many times have I walked with this mark"), so it is shown beside the mark's name. */
    var selId = POOL[S.sockets[S.cursor]].id;
    var carried = S.learned[selId] || 0;
    FONT.textPlane(plane, POOL[S.sockets[S.cursor]].name + (carried ? ' x' + carried : ''),
      4, 4, { shade: SHADOW, halo: LIT });
    FONT.textPlane(plane, 'Z DESCEND', W - 4, 4, { align: 'right', shade: SHADOW, halo: LIT });
    FONT.textPlane(plane, 'X MARKS  ' + clearedCount() + '/' + C.shafts.length, W - 4, 13,
      { align: 'right', shade: SHADOW, halo: LIT });
  }

  function drawDescent() {
    var r = S.run, sh = r.sh;
    var scroll = Math.max(0, Math.min(sh.depth, r.y - 58));
    var lampR = 26 + S.lamp * 0.44;               // how far up the walls the lamp still reaches
    var lampR2 = lampR * lampR;
    var GLOW2 = 15 * 15;                          // the small bright pool right around the carrier

    /* ⛔⛔ REVISION 2, AND THE DEFECT WAS MY OWN MEASURED LAW BROKEN BY MY OWN CODE. Revision 1
     * put the lit rim in shade 0 directly against lamp-lit AIR in shade 1 — 14.2 luma, i.e.
     * invisible — and the whole descent rendered as one flat light blob with hard edges. The rim
     * now sits ONE PIXEL INSIDE the rock, so it is flanked by shade 3 on both sides and lands on
     * the 119.3-luma edge. That is exactly the arrangement the harness plate already uses, and
     * the lesson is that a law is only applied where you remember to apply it.
     *
     * ⛔ The rock's texture is horizontal STRATA, not speckle. §0-ART-b: a speck is isotropic and
     *    rock bedding is DIRECTIONAL, and scattered single pixels read as dirt on the lens. The
     *    strata are chosen by a hash of the WORLD ROW only, so each one is a continuous line
     *    across the whole rock face, and a hash rather than a modulus so it never lattices. */
    for (var sy = 0; sy < H; sy++) {
      var wy = scroll + sy;
      var co = corridor(sh, wy);
      var coNext = corridor(sh, wy + 1);
      var dy = wy - r.y;
      var strata = hash2(7, wy) < 0.085;
      for (var sx = 0; sx < W; sx++) {
        var rock = sx < co.left || sx > co.right;
        var dx = sx - r.x;
        var d2 = dx * dx + dy * dy;
        var v;
        /* ⛔ THE SHAFT IS THE VOID AND THE ROCK IS THE SURFACE, and revision 2 had it the other
         * way round. With the air in shade 2 and the rock in shade 3 the two were 38.3 luma
         * apart, so the whole descent read as one murky mass with a stencil disc cut in it, and
         * the strata stopped dead on the lamp's circular boundary like speed lines. Now the air
         * is the darkest tone (it IS empty — §0-ART-b's "a dark field reads as empty" is a
         * DEFECT for a bench and the TRUTH for a hole), the rock is the mid tone carrying dark
         * bedding across its whole face, and shade 0 is spent only on wall edges the lamp
         * actually reaches: 119.3 luma against the void and 81.1 against the rock, strong both
         * ways. The glow falls off in TWO steps so the pool is not a cut-out. */
        if (rock) {
          var edge = (sx + 1 >= co.left && sx + 1 <= co.right) ||
                     (sx - 1 >= co.left && sx - 1 <= co.right) ||
                     (sx >= coNext.left && sx <= coNext.right);
          if (edge && d2 < lampR2) v = LIT;
          /* LODE. ⛔ A reviewer put it plainly: across six descent captures there was not one
           * object, marker or feature inside the shaft — every frame was the same picture with
           * the ribbon bent differently, and the descent is 100% of the playtime. These are
           * grains of ore in the rock that catch the lamp and go dark as it burns down. They are
           * PURELY VISUAL and touch no physics, so the whole measured balance above still holds
           * exactly — which is why this was the right thing to add at this stage and a hazard
           * was not. Placed by a hash of world coordinates, so they never lattice (§0-ART-b r2). */
          else if (d2 < lampR2 * 0.55 && hash2(sx * 3, wy * 5) < 0.010) v = LIT;
          else if (strata) v = SHADOW;
          else v = MID;
        } else {
          v = d2 < GLOW2 ? FACE : (d2 < GLOW2 * 2.6 ? MID : SHADOW);
        }
        plane.px[sy * W + sx] = v;
      }
    }

    drawCarrier(Math.round(r.x), Math.round(r.y - scroll));

    /* HUD. ⛔ The gauge's TROUGH used to be shade 2 inside a shade 3 band — 38.3 luma, so you
     * could see how much lamp you had left and not how much you had LOST, on the game's only
     * resource, on every frame. It is now outlined in shade 0 against the shade 3 band (119.3
     * luma) and labelled, so the empty part of the bar is as readable as the full part. */
    plane.rect(0, 0, W, 11, SHADOW);
    plane.hline(0, W - 1, 11, MID);
    FONT.textPlane(plane, 'LAMP', 4, 2, { shade: LIT });
    var gx = 30, gw = 60;
    plane.rect(gx, 2, gw, 7, SHADOW);
    for (var e = 0; e < gw; e++) { plane.set(gx + e, 2, LIT); plane.set(gx + e, 8, LIT); }
    for (var e2 = 2; e2 <= 8; e2++) { plane.set(gx, e2, LIT); plane.set(gx + gw - 1, e2, LIT); }
    var fill = Math.max(0, Math.round((gw - 4) * S.lamp / 100));
    if (fill > 0) plane.rect(gx + 2, 4, fill, 3, LIT);
    var d = Math.round(r.y), tot = sh.depth;
    FONT.textPlane(plane, d + '/' + tot, W - 4, 2, { align: 'right', shade: LIT });
    if (S.paused) {
      // ⛔ The plate is sized to its longest line, measured, not guessed: the old 104px plate
      //    held a 120px string, which inked 8px off one edge and 7px off the other onto live art.
      var pl = ['P RESUME', 'X GIVE UP'];
      var pw = Math.max(70, Math.max(pl[0].length, pl[1].length) * FONT.FACES.body.adv + 20);
      var px = Math.round((W - pw) / 2);
      plane.rect(px, 54, pw, 38, SHADOW);
      plane.hline(px, px + pw - 1, 54, LIT);
      plane.hline(px, px + pw - 1, 91, MID);
      FONT.textPlane(plane, 'HELD', W / 2, 60, { align: 'center', shade: LIT });
      FONT.textPlane(plane, pl[0], W / 2, 72, { align: 'center', shade: FACE });
      FONT.textPlane(plane, pl[1], W / 2, 81, { align: 'center', shade: FACE });
    }
  }

  /* A small carved figure with a lamp. Authored, not generated: it is 7x9 and a generator has
   * nothing to say at that size. '#' body, 'o' the lamp, '.' nothing. */
  var CARRIER = [
    '..###..',
    '.#####.',
    '.#####.',
    '..###..',
    '.#####o',
    '.#####o',
    '..###..',
    '..#.#..',
    '.##.##.',
  ];
  function drawCarrier(cx, cy) {
    var x0 = cx - 3, y0 = cy - 4;
    for (var y = 0; y < CARRIER.length; y++) {
      for (var x = 0; x < CARRIER[y].length; x++) {
        var ch = CARRIER[y][x];
        if (ch === '#') {
          var topLeft = (y === 0) || (x === 0) || CARRIER[y - 1][x] === '.' || CARRIER[y][x - 1] === '.';
          plane.set(x0 + x, y0 + y, topLeft ? SHADOW : MID);
        } else if (ch === 'o') {
          plane.set(x0 + x, y0 + y, LIT);
        }
      }
    }
    // the lamp's own glimmer, and the only place shade 0 sits in open air
    plane.set(x0 + 7, y0 + 4, LIT);
    plane.set(x0 + 6, y0 + 3, S.frames % 24 < 12 ? LIT : FACE);
  }

  /* The four marks you were carrying, as small plates. ⛔ The result card was a dark rectangle
   * with text on it — mostly empty space, the weakest image in the gallery, and on a screen the
   * player sees after every single descent. Showing the carry-set here is both the missing art
   * and the missing information: the whole game is "which four did I take", so the card that
   * tells you how it went should tell you what you took. */
  function carriedStrip(y) {
    var PLATE = 26, GAP = 6;
    var total = 4 * PLATE + 3 * GAP;
    var x0 = Math.round((W - total) / 2);
    for (var i = 0; i < 4; i++) {
      var x = x0 + i * (PLATE + GAP);
      plane.rect(x, y, PLATE, PLATE, FACE);
      for (var e = 0; e < PLATE; e++) {
        plane.set(x + e, y, LIT); plane.set(x, y + e, LIT);
        plane.set(x + e, y + PLATE - 1, SHADOW); plane.set(x + PLATE - 1, y + e, SHADOW);
      }
      plane.blit(ART.markRelief(POOL[S.sockets[i]].i, ART.NONE), x + (PLATE - ART.MARK) / 2, y + (PLATE - ART.MARK) / 2);
    }
  }

  function card(title, lines, footer, showCarried) {
    plane.px.fill(MID);
    for (var i = 0; i < 10; i++) plane.hline(0, W - 1, 7 + i * 15, SHADOW);
    plane.rect(6, 14, W - 12, H - 34, SHADOW);
    plane.hline(6, W - 7, 14, LIT);
    FONT.textPlane(plane, title, W / 2, 22, { align: 'center', face: 'body', shade: LIT });
    plane.hline(30, W - 31, 32, MID);
    if (showCarried) carriedStrip(H - 50);
    var flat = [];
    for (var j = 0; j < lines.length; j++) {
      if (!lines[j]) { flat.push(''); continue; }
      wrap(lines[j], CARDCH).forEach(function (l) { flat.push(l); });
    }
    for (var k = 0; k < flat.length && 40 + k * 9 <= H - 20; k++) {
      FONT.textPlane(plane, flat[k], W / 2, 40 + k * 9, { align: 'center', shade: FACE });
    }
    if (footer) FONT.textPlane(plane, footer, W / 2, H - 12, { align: 'center', shade: SHADOW, halo: LIT });
  }

  function drawTitle() {
    plane.px.fill(MID);
    for (var i = 0; i < 9; i++) plane.hline(0, W - 1, 9 + i * 16, SHADOW);
    // The title is set in the DISPLAY face, on its own cut band — a custom title screen, not a
    // default. Shade 0 lettering on a shade 3 band is the 119.3-luma edge again.
    plane.rect(0, 34, W, 26, SHADOW);
    plane.hline(0, W - 1, 33, LIT);
    plane.hline(0, W - 1, 60, MID);
    FONT.textPlane(plane, 'LODESTONE', W / 2, 38, { align: 'center', face: 'display', shade: LIT });
    /* ⛔ THE BODY FACE ADVANCES 6 px, SO 160 px IS 26 CHARACTERS AND NOT ONE MORE. Revision 1 set
     * a 32-character line and it ran off BOTH edges of the screen — "THE DUNGEON DOES WHAT THE
     * STON". Nothing warned: textPlane clips silently at the plane's bounds. Both lines below are
     * 25 and 26 characters, and title_fits.js re-derives that from the FACE rather than trusting
     * this comment. */
    // ⛔ Shade 0 on the shade-2 ground is 81.1 luma. Revision 1 set this in shade 3, which is
    //    38.3 luma off the same ground and read as a smudge behind the grain lines.
    FONT.textPlane(plane, 'THE DUNGEON DOES WHAT THE', W / 2, 70, { align: 'center', shade: LIT });
    FONT.textPlane(plane, 'STONES YOU CARRY ADD UP TO', W / 2, 79, { align: 'center', shade: LIT });
    // ⛔ On PLATES. Revision 1 blitted the marks straight onto the ground, where a cut with no
    //    surface around it reads as a floating outline rather than as something carved.
    for (var mi = 0; mi < 3; mi++) {
      var px0 = 14 + mi * 48, py0 = 94;
      plane.rect(px0, py0, 32, 32, FACE);
      for (var e = 0; e < 32; e++) {
        plane.set(px0 + e, py0, LIT); plane.set(px0, py0 + e, LIT);
        plane.set(px0 + e, py0 + 31, SHADOW); plane.set(px0 + 31, py0 + e, SHADOW);
      }
      plane.blit(ART.markRelief(((S.frames / 44 | 0) + mi * 4) % ART.MARKS.length, ART.NONE), px0 + 4, py0 + 4);
    }
    if (S.frames % 48 < 32) {
      FONT.textPlane(plane, 'PRESS Z', W / 2, H - 10, { align: 'center', shade: SHADOW, halo: LIT });
    }
    /* ⛔ THIS LABEL HAS NOW BEEN WRONG TWICE and both times for the same reason. Revision 1 drew
     * it shade 2 ON shade 2 (zero contrast). Revision 2 "fixed" it to shade 3 on the shade-2
     * ground — 38.3 luma, the palette's second-weakest edge — and a full-width strata rule runs
     * straight through its rows, so a reviewer measured ZERO lit pixels there and read it as a
     * row of dashes. It now gets its own cleared band and the 119.3-luma pairing, like every
     * other piece of type in this game that anybody is meant to read. */
    if (C.edition !== 'full') {
      plane.rect(0, 17, W, 11, SHADOW);
      FONT.textPlane(plane, 'FREE EDITION', W / 2, 19, { align: 'center', shade: LIT });
    }
  }

  function drawResult() {
    var R = S.result;
    if (R.ok) {
      // ⛔ The lamp margin is the channel where the carry-set actually pays, so the card says
      //    what it was AND what the best was, and whether this beat it.
      /* ⛔ A NUMBER IS ONLY PRINTED WHEN IT IS A NUMBER. A staged capture reached this card with
       * no `best` on the result and it photographed "YOUR BEST HERE IS NAN%". In play that field
       * is always set — which is exactly why a defensive branch is worth having: the one path
       * that forgets it is the one nobody was thinking about. */
      var bestLine = R.newBest ? (R.hadBest ? 'A NEW BEST FOR THIS SHAFT' : 'YOUR FIRST WAY DOWN')
        : (typeof R.best === 'number' && isFinite(R.best))
          ? 'YOUR BEST HERE IS ' + Math.round(R.best) + '%' : '';
      card(R.shaft.name + ' CLEARED', [
        'LAMP LEFT ' + Math.round(R.lamp) + '%',
        bestLine,
        'ROCK TOUCHED ' + R.hits + ' TIMES',
        '',
        'YOU CARRIED',
      ], 'Z CONTINUE', true);
    } else {
      card('THE LAMP IS OUT', [
        'YOU REACHED ' + R.depth + ' OF ' + R.shaft.depth,
        'ROCK TOUCHED ' + R.hits + ' TIMES',
        '',
        'YOU CARRIED',
      ], 'Z CHANGE WHAT YOU CARRY', true);
    }
  }

  /* ⛔ THE HEADING COMES FROM THE CONTENT FILE, NOT FROM HERE. It used to be a ternary here
   * whose paid branch spelled the last shaft's name out, and verify_demo_split.js caught it:
   * game.js ships in BOTH editions, so that name was sitting in the free download. A branch
   * the free build does not take still carries its strings (§1-DEMO).
   * ⚠ And the first attempt to fix it failed the SAME check, because this comment quoted the
   *   string it had just removed — master §2b: prose quoting the code defeats the rule. The
   *   checker scans RAW BYTES, comments included, and it is right to: a curious buyer reads
   *   comments too. So the name is not written here in any form.
   *
   * ⛔⛔ AND THE ENDING USED TO BE SILENTLY TRUNCATED — the paid edition's entire payoff. This
   * wrapped the text and then did `if (y > H - 20) break;`, so the last two lines were never
   * drawn and the last sentence a buyer reads ended mid-clause. NOTHING caught it: the font's
   * clip counter only counts glyphs drawn OUTSIDE the plane, and these were never drawn at all,
   * so the suite's "NO CLIPPED TEXT" guard stayed green over a broken ending. A fresh reviewer
   * found it by opening the PNG (§0z-1g: the review category is not a formality).
   * ⇒ It now PAGINATES, and `endingPages()` is a pure function the suite checks: a line that does
   *   not fit moves to the next page. Dropping one is no longer expressible. */
  var LINES_PER_PAGE = 8;
  function endingPages() {
    var raw = C.ending || [C.demoEnd || ''];
    var src = [];
    // a content line may itself carry newlines; they are paragraph breaks, not characters
    for (var s = 0; s < raw.length; s++) String(raw[s] || '').split('\n').forEach(function (l) { src.push(l); });
    var flat = [];
    for (var i = 0; i < src.length; i++) {
      if ((src[i] || '') === '') { flat.push(''); continue; }
      wrap(src[i], CARDCH).forEach(function (l) { flat.push(l); });
    }
    while (flat.length && flat[flat.length - 1] === '') flat.pop();
    var pages = [];
    for (var j = 0; j < flat.length; j += LINES_PER_PAGE) pages.push(flat.slice(j, j + LINES_PER_PAGE));
    return pages.length ? pages : [['']];
  }

  function drawEnding() {
    var pages = endingPages();
    var page = Math.max(0, Math.min(S.endPage, pages.length - 1));
    plane.px.fill(MID);
    for (var i = 0; i < 10; i++) plane.hline(0, W - 1, 7 + i * 15, SHADOW);
    plane.rect(6, 14, W - 12, H - 34, SHADOW);
    plane.hline(6, W - 7, 14, LIT);
    FONT.textPlane(plane, C.endingTitle, W / 2, 22, { align: 'center', shade: LIT });
    plane.hline(30, W - 31, 32, MID);
    var y = 44;
    for (var k = 0; k < pages[page].length; k++) {
      FONT.textPlane(plane, pages[page][k], W / 2, y, { align: 'center', shade: FACE });
      y += 9;
    }
    var more = page < pages.length - 1;
    FONT.textPlane(plane, more ? 'Z MORE  ' + (page + 1) + '/' + pages.length : 'Z CREDITS',
      W / 2, H - 12, { align: 'center', shade: SHADOW, halo: LIT });
  }

  /* ⛔⛔ THE THREE DISCLOSURE SURFACES MUST AGREE, AND THEY DID NOT. This card used to read
   * "CODE, ART AND SOUND MADE WITH AI ASSISTANCE" and then, two lines later, "SOUND IS
   * SYNTHESISED, NOT GENERATED FROM A MODEL" — contradicting itself, and contradicting both
   * Readme_for_Users.md and LICENSE.txt, which put sound OUTSIDE the AI claim. CLAUDE.md §4.1:
   * a mislabelled disclosure risks the seller account, so this is not a wording nit. All three
   * surfaces now say the same thing, and verify_disclosure.js re-derives that they do. */
  /* THE MARKS REFERENCE — the alphabet, never the answers. ⛔ This screen is drawn from a REAL
   * SHIPPED ART FILE, art/marks_reference.png, baked out of this same js/art.js by
   * Internal_Ops/build_art.js. It is composited with drawImage OVER the painted plane and its
   * pixels are never read back, which is the only way a shipped PNG can be used on the paid
   * build's file:// origin (see build_art.js for the measurement). If the image has not loaded,
   * the plane underneath still says so rather than showing an empty box. */
  var MARK_PAGES = 2;
  var sheets = [], sheetState = 'none';
  function loadSheet() {
    if (sheetState !== 'none' || !root.Image) return;
    sheetState = 'loading';
    var done = 0, failed = false;
    for (var i = 0; i < MARK_PAGES; i++) {
      (function (ix) {
        var im = new root.Image();
        im.onload = function () {
          sheets[ix] = im;
          if (++done === MARK_PAGES && !failed) sheetState = 'ready';
        };
        im.onerror = function () { failed = true; sheetState = 'failed'; };
        im.src = 'art/marks_reference_' + (ix + 1) + '.png';
      }(i));
    }
  }

  function drawMarksRef() {
    plane.px.fill(SHADOW);
    if (sheetState !== 'ready') {
      FONT.textPlane(plane, sheetState === 'failed' ? 'THE SHEET DID NOT LOAD' : 'THE TWELVE MARKS',
        W / 2, 60, { align: 'center', shade: LIT });
      FONT.textPlane(plane, 'X BACK', W / 2, H - 12, { align: 'center', shade: FACE });
    }
  }

  function drawCredits() {
    card('LODESTONE', [
      'CORE SYSTEMS ASSET FACTORY',
      '',
      'CODE, ART AND TEXT MADE',
      'WITH AI ASSISTANCE.',
      'MUSIC AND SOUND ARE',
      'SYNTHESISED FROM NOTE DATA.',
    ], 'X BACK');
  }

  /* ------------------------------------------------------------------------------- paint */

  var cv, ctx, img, data;
  function paint() {
    for (var i = 0, p = 0; i < plane.px.length; i++, p += 4) {
      var c = PAL[plane.px[i]];
      data[p] = c[0]; data[p + 1] = c[1]; data[p + 2] = c[2]; data[p + 3] = 255;
    }
    ctx.putImageData(img, 0, 0);
    // the one shipped art file, composited over the plane; no pixel is ever read back
    if (S.screen === 'marks' && sheetState === 'ready' && sheets[S.markPage]) {
      ctx.drawImage(sheets[S.markPage], 0, 0, W, H);
    }
  }
  var PAL = DMG.map(function (h) {
    return [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
  });

  /* ------------------------------------------------------------------------------- input */

  function press(k) {
    if (SND) SND.unlock();
    if (k === 'mute') { S.muted = !S.muted; if (SND) SND.setMuted(S.muted); return; }
    if (S.screen === 'title') { if (k === 'ok') { S.screen = 'harness'; if (SND) SND.cue('ok'); } return; }
    if (S.screen === 'harness') {
      if (k === 'left') { S.cursor = (S.cursor + 3) % 4; if (SND) SND.cue('move'); }
      else if (k === 'right') { S.cursor = (S.cursor + 1) % 4; if (SND) SND.cue('move'); }
      else if (k === 'up' || k === 'down') {
        var d = k === 'up' ? -1 : 1;
        var next = S.sockets.slice();
        for (var n = 1; n <= POOL.length; n++) {
          var cand = (S.sockets[S.cursor] + d * n + POOL.length * 4) % POOL.length;
          if (next.indexOf(cand) === -1) { next[S.cursor] = cand; break; }
        }
        S.sockets = next;
        if (SND) SND.cue('set');
      } else if (k === 'ok') { beginDescent(); }
      else if (k === 'back') { S.screen = 'marks'; loadSheet(); if (SND) SND.cue('ok'); }
      return;
    }
    if (S.screen === 'marks') {
      if (k === 'ok') { S.markPage = (S.markPage + 1) % MARK_PAGES; if (SND) SND.cue('move'); }
      else if (k === 'back') { S.screen = 'harness'; if (SND) SND.cue('ok'); }
      return;
    }
    if (S.screen === 'descent') {
      if (k === 'pause') { S.paused = !S.paused; if (SND) SND.cue('ok'); }
      else if (k === 'back' && S.paused) {
        S.paused = false;
        S.result = { ok: false, shaft: S.run.sh, hits: S.run.hits, lamp: 0, ticks: S.run.tick, depth: Math.round(S.run.y) };
        S.screen = 'result';
      }
      return;
    }
    if (S.screen === 'result') {
      if (k === 'ok') {
        if (S.result.ok) {
          S.shaftIx++;
          if (S.shaftIx >= C.shafts.length) { S.screen = 'ending'; S.endScroll = 0; S.shaftIx = C.shafts.length - 1; }
          else S.screen = 'harness';
        } else S.screen = 'harness';
        if (SND) SND.cue('ok');
      }
      return;
    }
    if (S.screen === 'ending') {
      if (k === 'ok') {
        if (S.endPage < endingPages().length - 1) { S.endPage++; if (SND) SND.cue('move'); }
        else { S.screen = 'credits'; if (SND) SND.cue('ok'); }
      }
      return;
    }
    if (S.screen === 'credits') { if (k === 'back' || k === 'ok') S.screen = 'title'; return; }
  }

  var HELD = {};
  function refreshHeld() {
    S.held.x = (HELD.right ? 1 : 0) - (HELD.left ? 1 : 0);
    S.held.y = (HELD.down ? 1 : 0) - (HELD.up ? 1 : 0);
  }
  var KEYMAP = {
    ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down',
    a: 'left', d: 'right', w: 'up', s: 'down',
    A: 'left', D: 'right', W: 'up', S: 'down',
    z: 'ok', Z: 'ok', Enter: 'ok', ' ': 'ok',
    x: 'back', X: 'back', Escape: 'back', Backspace: 'back',
    p: 'pause', P: 'pause', m: 'mute', M: 'mute',
  };

  /* -------------------------------------------------------------------------------- loop */

  /* ⛔ `draw` exists ONLY so a balance sweep of thousands of descents is not paying to rasterise
   *    23,040 pixels per tick. It never changes the SIMULATION, and the `screens` category draws
   *    every screen for real — so turning it off cannot hide a rendering defect from the suite,
   *    it can only make the physics arms affordable. */
  var draw = true;

  function step(n) {
    n = n === undefined ? 1 : n;
    for (var i = 0; i < n; i++) {
      S.frames++;
      if (S.screen === 'descent' && !S.paused) stepDescent();
      if (S.screen === 'ending') S.endScroll = Math.min(0, S.endScroll);
    }
    if (!draw) return;
    if (S.screen === 'title') drawTitle();
    else if (S.screen === 'harness') drawHarness();
    else if (S.screen === 'descent') drawDescent();
    else if (S.screen === 'marks') drawMarksRef();
    else if (S.screen === 'result') drawResult();
    else if (S.screen === 'ending') drawEnding();
    else if (S.screen === 'credits') drawCredits();
    if (ctx) paint();
  }

  function frame() { step(1); root.requestAnimationFrame(frame); }

  function boot() {
    cv = root.document.getElementById('screen');
    ctx = cv.getContext('2d');
    ctx.imageSmoothingEnabled = false;
    img = ctx.createImageData(W, H);
    data = img.data;
    root.addEventListener('keydown', function (e) {
      var k = KEYMAP[e.key];
      if (!k) return;
      e.preventDefault();
      if (k === 'left' || k === 'right' || k === 'up' || k === 'down') {
        if (!HELD[k]) { HELD[k] = true; refreshHeld(); if (S.screen !== 'descent') press(k); }
        else { HELD[k] = true; refreshHeld(); }
      } else if (!e.repeat) press(k);
    });
    root.addEventListener('keyup', function (e) {
      var k = KEYMAP[e.key];
      if (!k) return;
      if (HELD[k]) { HELD[k] = false; refreshHeld(); }
    });
    root.addEventListener('blur', function () { HELD = {}; refreshHeld(); });
    // Touch: drag anywhere to hold a direction, tap to confirm. The itch embed is played on
    // phones and a keyboard-only game there is a black screen with a story.
    var touchOrigin = null;
    cv.addEventListener('touchstart', function (e) {
      e.preventDefault();
      touchOrigin = { x: e.touches[0].clientX, y: e.touches[0].clientY, t: Date.now() };
      if (SND) SND.unlock();
    }, { passive: false });
    cv.addEventListener('touchmove', function (e) {
      e.preventDefault();
      if (!touchOrigin) return;
      var dx = e.touches[0].clientX - touchOrigin.x, dy = e.touches[0].clientY - touchOrigin.y;
      var dead = 12;
      HELD.left = dx < -dead; HELD.right = dx > dead;
      HELD.up = dy < -dead; HELD.down = dy > dead;
      refreshHeld();
      if (S.screen !== 'descent') {
        if (HELD.left) press('left'); else if (HELD.right) press('right');
        else if (HELD.up) press('up'); else if (HELD.down) press('down');
        HELD = {}; refreshHeld(); touchOrigin = { x: e.touches[0].clientX, y: e.touches[0].clientY, t: Date.now() };
      }
    }, { passive: false });
    cv.addEventListener('touchend', function (e) {
      e.preventDefault();
      var quick = touchOrigin && Date.now() - touchOrigin.t < 250 && !S.held.x && !S.held.y;
      HELD = {}; refreshHeld(); touchOrigin = null;
      if (quick) press('ok');
    }, { passive: false });

    /* ⛔ §1a — IN A HIDDEN AUTOMATION TAB rAF IS THROTTLED TO ZERO, so a harness that waits for
     * frames waits forever and the game looks broken when it is merely unscheduled. With
     * ?harness=1 the rAF loop never starts and the HARNESS OWNS THE CLOCK through __lsTick.
     * Without it, nothing about the player's build changes. */
    root.__lsTick = function (n) { step(n || 1); };
    root.__lsVisibility = function () { return root.document.visibilityState; };
    if (/[?&]harness=1\b/.test(root.location.search)) { step(1); return; }
    frame();
  }

  root.LODESTONE = {
    step: step,
    setDraw: function (v) { draw = !!v; },
    press: press,
    hold: function (x, y) { S.held.x = x; S.held.y = y; },
    state: S,
    pool: POOL,
    terms: terms,
    corridor: corridor,
    plane: plane,
    beginDescent: beginDescent,
    endingPages: endingPages,
    best: function () { return S.best; },
    sheetState: function () { return sheetState; },
    sheetsLoaded: function () { return sheets.filter(Boolean).length; },
    get frames() { return S.frames; },
    version: '1.0.0',
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = root.LODESTONE;
  else if (root.document) {
    if (root.document.readyState === 'loading') root.addEventListener('DOMContentLoaded', boot);
    else boot();
  }
}(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this)));
