/**
 * art.js — LODESTONE's art, and THE SINGLE SOURCE OF TRUTH for it.
 *
 * ⛔ WHY THIS FILE LIVES IN Product_Release AND NOT IN Internal_Ops (wing §1-BUILD-b): a fix that
 *    lives only in a generated tree is reverted by the next build, and a fix that lives only in a
 *    tool is never in the game. The twelve marks and the harness are authored HERE, the game
 *    loads this file with a <script> tag, and Internal_Ops/art/*.js are thin shims that require
 *    it — so the contact sheet that PASSED the §0-ART-f gate and the picture a player sees are
 *    the same pixels by construction, not by a promise.
 *
 * ⛔⛔ THE PALETTE LAW, MEASURED 2026-09-22 (Internal_Ops/_probe_palette.js, reading the palette
 *     out of the renderer rather than remembering it):
 *
 *        shade 0 vs 1 .... 14.2 luma      shade 2 vs 3 .... 38.3 luma
 *        shade 1 vs 2 .... 66.9 luma      shade 0 vs 2 .... 81.1 luma
 *        shade 1 vs 3 ... 105.2 luma      shade 0 vs 3 ... 119.3 luma
 *
 *     The DMG has TWO LIGHT TONES 14.2 APART and TWO DARK TONES 38.3 APART. So:
 *     SHADE 0 IS PLACED ADJACENT TO SHADE 3, NEVER ADJACENT TO SHADE 1. Revision 1 of the relief
 *     model put every groove's lit wall in shade 0 on a shade-1 face — physically correct, worth
 *     14.2 luma, and the marks read as ragged ink with a textbook-correct groove histogram
 *     (LIT 20.4% / FLOOR 48.0% / SHADOW 31.5%, _probe_relief.js). The lit half of a correct model
 *     was invisible. Everything below spends shade 0 as a hairline hard against shade 3.
 *
 * Runs in the browser (window.ART) and under Node (module.exports), from one text.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.ART = api;
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* Shades. 0 lightest .. 3 darkest. 255 = leave alone. */
  const LIT = 0, FACE = 1, MID = 2, SHADOW = 3, NONE = 255;
  const MARK = 24;
  const SCREEN_W = 160, SCREEN_H = 144;

  /* ------------------------------------------------------------------------------ Mask */

  function Mask(w, h) {
    this.w = w || MARK; this.h = h || MARK;
    this.m = new Uint8Array(this.w * this.h);
  }
  Mask.prototype.set = function (x, y) {
    x = Math.round(x); y = Math.round(y);
    if (x < 0 || y < 0 || x >= this.w || y >= this.h) return;
    this.m[y * this.w + x] = 1;
  };
  Mask.prototype.get = function (x, y) {
    if (x < 0 || y < 0 || x >= this.w || y >= this.h) return 0;
    return this.m[y * this.w + x];
  };
  Mask.prototype.count = function () {
    let n = 0; for (let i = 0; i < this.m.length; i++) n += this.m[i]; return n;
  };
  Mask.prototype.disc = function (cx, cy, r) {
    const r2 = r * r;
    for (let y = Math.floor(cy - r); y <= Math.ceil(cy + r); y++) {
      for (let x = Math.floor(cx - r); x <= Math.ceil(cx + r); x++) {
        const dx = x - cx, dy = y - cy;
        if (dx * dx + dy * dy <= r2) this.set(x, y);
      }
    }
  };
  Mask.prototype.ring = function (cx, cy, r, w) {
    const outer = (r + w / 2) * (r + w / 2), inner = (r - w / 2) * (r - w / 2);
    for (let y = Math.floor(cy - r - w); y <= Math.ceil(cy + r + w); y++) {
      for (let x = Math.floor(cx - r - w); x <= Math.ceil(cx + r + w); x++) {
        const d = (x - cx) * (x - cx) + (y - cy) * (y - cy);
        if (d <= outer && d >= inner) this.set(x, y);
      }
    }
  };
  /** A TAPERED arc. ⛔ The width is never constant by accident — TAILRACE: a constant-width
   *  stroke reads as wire whatever it is a picture of. */
  Mask.prototype.arc = function (cx, cy, r, a0, a1, w0, w1) {
    const steps = Math.max(24, Math.ceil(Math.abs(a1 - a0) * r * 2));
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      this.disc(cx + Math.cos(a0 + (a1 - a0) * t) * r,
                cy + Math.sin(a0 + (a1 - a0) * t) * r, (w0 + (w1 - w0) * t) / 2);
    }
  };
  /** A TAPERED polyline. Width is carried by ARC LENGTH, so a long segment does not taper
   *  faster than a short one. */
  Mask.prototype.stroke = function (pts, w0, w1) {
    let total = 0;
    for (let i = 1; i < pts.length; i++) {
      total += Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]);
    }
    if (total === 0) { this.disc(pts[0][0], pts[0][1], w0 / 2); return; }
    let run = 0;
    for (let i = 1; i < pts.length; i++) {
      const x0 = pts[i - 1][0], y0 = pts[i - 1][1], x1 = pts[i][0], y1 = pts[i][1];
      const len = Math.hypot(x1 - x0, y1 - y0);
      const steps = Math.max(2, Math.ceil(len * 2));
      for (let s = 0; s <= steps; s++) {
        const t = s / steps, g = (run + len * t) / total;
        this.disc(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, (w0 + (w1 - w0) * g) / 2);
      }
      run += len;
    }
  };

  /* --------------------------------------------------------------------------- Shadeplane */

  function Plane(w, h, fill) {
    this.w = w; this.h = h;
    this.px = new Uint8Array(w * h).fill(fill === undefined ? NONE : fill);
  }
  Plane.prototype.set = function (x, y, s) {
    if (s === NONE) return;
    x = Math.round(x); y = Math.round(y);
    if (x < 0 || y < 0 || x >= this.w || y >= this.h) return;
    this.px[y * this.w + x] = s;
  };
  Plane.prototype.get = function (x, y) {
    if (x < 0 || y < 0 || x >= this.w || y >= this.h) return NONE;
    return this.px[y * this.w + x];
  };
  Plane.prototype.rect = function (x, y, w, h, s) {
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) this.set(x + i, y + j, s);
  };
  Plane.prototype.hline = function (x0, x1, y, s) {
    for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x++) this.set(x, y, s);
  };
  Plane.prototype.blit = function (src, ox, oy) {
    for (let y = 0; y < src.h; y++) {
      for (let x = 0; x < src.w; x++) {
        const s = src.px[y * src.w + x];
        if (s !== NONE) this.set(ox + x, oy + y, s);
      }
    }
  };

  /* ------------------------------------------------------------------------------ relief
   * Across a groove, left to right, light from the top-left:
   *   [ face 1 ][ lip 0 ][ near wall 3 ][ floor 3 ][ far wall 2 ][ face 1 ]
   * opts.glow inverts it: framed in 3 on both sides, lit 0 in the middle. Same strongest edge
   * spent the other way round, and it is how a LIVE channel reads from across a room.
   * ================================================================================= */
  function relief(mask, face, opts) {
    opts = opts || {};
    const r = new Plane(mask.w, mask.h, face === undefined ? FACE : face);
    for (let y = 0; y < mask.h; y++) {
      for (let x = 0; x < mask.w; x++) {
        if (mask.get(x, y)) {
          const near = !mask.get(x - 1, y) || !mask.get(x, y - 1);
          const far = !mask.get(x + 1, y) || !mask.get(x, y + 1);
          if (opts.glow) { r.set(x, y, near || far ? SHADOW : LIT); continue; }
          if (near) r.set(x, y, SHADOW);
          else if (far) r.set(x, y, MID);
          else r.set(x, y, SHADOW);
        } else if (mask.get(x + 1, y) || mask.get(x, y + 1) || mask.get(x + 1, y + 1)) {
          r.set(x, y, LIT);                       // the lip's catch-light, 0 hard against 3
        }
      }
    }
    return r;
  }

  /** How many steps in from a mask's boundary a pixel is, capped, and which way is OUT. */
  function shell(mask, x, y, cap) {
    cap = cap || 3;
    let depth = cap, sx = 0, sy = 0, found = false;
    for (let d = 1; d <= cap; d++) {
      for (let j = -d; j <= d; j++) {
        for (let i = -d; i <= d; i++) {
          if (Math.max(Math.abs(i), Math.abs(j)) !== d) continue;
          if (mask.get(x + i, y + j)) continue;
          if (!found) { depth = d - 1; found = true; }
          if (d <= depth + 2) { sx += i; sy += j; }
        }
      }
      if (found && d >= depth + 2) break;
    }
    return { depth: depth, topLeft: (sx + sy) < 0 };
  }

  /* ================================================================== the twelve marks
   * Chosen for TOPOLOGY, never for outline: bar, tree, annulus, coil, nested repeat, grid, arc,
   * comb, lens-with-island, polyline, two-annulus, radial. §0-ART-f killed BELLFOUNDER (a vessel
   * is one profile curve) and ESCAPEMENT (a gear train is a chain of discs, one parameter each);
   * twelve different SHAPES OF CONNECTION is the axis a 24x24 field in four shades can spend
   * pixels on, and the contact sheet is what proved it rather than this comment.
   * ============================================================================== */
  const C = MARK / 2;

  const MARKS = [
    { id: 'keel', name: 'KEEL', cut: function (m) {
      m.stroke([[C, 3], [C, 17]], 7, 3); m.stroke([[C - 6, 19], [C + 6, 19]], 4, 4); m.disc(C, 20, 2); } },
    { id: 'fork', name: 'FORK', cut: function (m) {
      m.stroke([[C, 21], [C, 12]], 5, 4); m.stroke([[C, 12], [C - 7, 4]], 4, 2); m.stroke([[C, 12], [C + 7, 4]], 4, 2); } },
    { id: 'ring', name: 'RING', cut: function (m) { m.ring(C, C, 7.5, 4); } },
    { id: 'coil', name: 'COIL', cut: function (m) {
      const pts = [];
      for (let i = 0; i <= 60; i++) {
        const t = i / 60, a = t * Math.PI * 3.4 - Math.PI / 2, rr = 2 + t * 8.5;
        pts.push([C + Math.cos(a) * rr, C + Math.sin(a) * rr]);
      }
      m.stroke(pts, 2.4, 4.6); } },
    { id: 'chevron', name: 'CHEVRON', cut: function (m) {
      for (let i = 0; i < 3; i++) {
        const y = 6 + i * 5, s = 8 - i * 0.5;
        m.stroke([[C - s, y], [C, y + 5], [C + s, y]], 3.4 - i * 0.5, 3.4 - i * 0.5);
      } } },
    { id: 'lattice', name: 'LATTICE', cut: function (m) {
      for (let i = 0; i < 3; i++) m.stroke([[5 + i * 7, 4], [5 + i * 7, 20]], 2.6, 2.6);
      for (let i = 0; i < 3; i++) m.stroke([[4, 5 + i * 7], [20, 5 + i * 7]], 2.6, 2.6); } },
    { id: 'crescent', name: 'CRESCENT', cut: function (m) {
      m.arc(C + 2, C, 8, Math.PI * 0.55, Math.PI * 1.45, 6.5, 2); } },
    { id: 'comb', name: 'COMB', cut: function (m) {
      m.stroke([[3, 7], [21, 7]], 4.5, 3);
      for (let i = 0; i < 4; i++) m.stroke([[4.5 + i * 5, 8], [4.5 + i * 5, 19]], 3.2, 1.8); } },
    // ⚠ EYE revision 2: at r=9.5 the arcs met almost flat and it rendered as a small capsule —
    // the weakest of the twelve on the first sheet. The geometry is solved, not guessed: an arc
    // through (±10, 0) and (0, -7) has r = (100+49)/14 = 10.64, centred 3.64 off the axis.
    { id: 'eye', name: 'EYE', cut: function (m) {
      m.arc(C, C + 3.64, 10.64, 3.49, 5.934, 3, 3);
      m.arc(C, C - 3.64, 10.64, 0.349, 2.793, 3, 3);
      m.disc(C, C, 3.2); } },
    { id: 'bolt', name: 'BOLT', cut: function (m) {
      m.stroke([[6, 3], [16, 8], [7, 13], [17, 18], [9, 21]], 4.6, 2.2); } },
    // ⚠ TWIN revision 2: at r=5.5 the annuli were too small for their own holes to read.
    { id: 'twin', name: 'TWIN', cut: function (m) {
      m.ring(C - 4, C - 2, 6.5, 3); m.ring(C + 4, C + 2, 6.5, 3); } },
    { id: 'star', name: 'STAR', cut: function (m) {
      m.disc(C, C, 3.4);
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2 - Math.PI / 2;
        m.stroke([[C + Math.cos(a) * 3, C + Math.sin(a) * 3],
                  [C + Math.cos(a) * 10, C + Math.sin(a) * 10]], 3.6, 1.8);
      } } },
  ];

  function markMask(i) { const m = new Mask(MARK, MARK); MARKS[i].cut(m); return m; }
  function markRelief(i, face) { return relief(markMask(i), face === undefined ? NONE : face); }

  /* =============================================================================== harness */

  /* ⛔ THE DIAMOND IS SIZED SO THE BOTTOM SOCKET CLEARS THE SHAFT-NOTE BAND. The first layout put
   * the bottom socket at y=114 with a 15 px radius, and the note band starts at y=118 — so the
   * band cut the bottom socket in half and HID ONE OF THE FOUR MARKS THE PLAYER IS CARRYING, on
   * the screen whose entire job is showing what you are carrying. Nothing mechanical saw it: the
   * four-shade check passed, dedupe called the image distinct, and it was found by opening the
   * gallery PNG. Bottom lobe now ends at 92 + 24 = 116, clear of 118. */
  const SOCKETS = [{ x: 80, y: 26 }, { x: 42, y: 62 }, { x: 118, y: 62 }, { x: 80, y: 92 }];
  const HUB = { x: 80, y: 62 };
  const SOCKET_R = 14;
  const GRAIN_ROWS = [7, 19, 26, 45, 58, 83, 97, 104, 126, 137];   // NON-PERIODIC (§0-ART-b r2)

  function bodyMask() {
    const m = new Mask(SCREEN_W, SCREEN_H);
    m.disc(HUB.x, HUB.y, 26);
    for (let i = 0; i < SOCKETS.length; i++) {
      m.disc(SOCKETS[i].x, SOCKETS[i].y, SOCKET_R + 10);
      m.stroke([[HUB.x, HUB.y], [SOCKETS[i].x, SOCKETS[i].y]], 23, 18);
    }
    m.stroke([[44, 50], [28, 34], [32, 18]], 15, 10);
    m.stroke([[116, 50], [132, 34], [128, 18]], 15, 10);
    return m;
  }

  function channelMask(liveOnly, live) {
    const m = new Mask(SCREEN_W, SCREEN_H);
    for (let i = 0; i < SOCKETS.length; i++) {
      const isLive = !!(live && live[i]);
      if (liveOnly !== null && isLive !== liveOnly) continue;
      const s = SOCKETS[i];
      const dx = s.x - HUB.x, dy = s.y - HUB.y, len = Math.hypot(dx, dy);
      const ux = dx / len, uy = dy / len;
      m.stroke([[HUB.x + ux * 9, HUB.y + uy * 9],
                [s.x - ux * (SOCKET_R + 3), s.y - uy * (SOCKET_R + 3)]], 7, 5);
    }
    if (liveOnly !== true) m.ring(HUB.x, HUB.y, 6.5, 3.5);
    return m;
  }

  let BODY = null;   // the body mask never changes; building it is the expensive part

  /**
   * Draw the harness screen.
   * @param {number[]} carried four mark indices
   * @param {object} opts { live: boolean[4] }
   * @returns {Plane} a 160x144 plane of shades
   */
  function harnessScreen(carried, opts) {
    opts = opts || {};
    if (!Array.isArray(carried) || carried.length !== 4) {
      throw new Error('harnessScreen: carried must be 4 mark indices');
    }
    for (let i = 0; i < 4; i++) {
      if (!(carried[i] >= 0 && carried[i] < MARKS.length)) {
        throw new Error('harnessScreen: ' + carried[i] + ' is not a mark index');
      }
    }
    if (!BODY) BODY = bodyMask();
    const body = BODY;
    const r = new Plane(SCREEN_W, SCREEN_H, MID);

    for (let i = 0; i < GRAIN_ROWS.length; i++) r.hline(0, SCREEN_W - 1, GRAIN_ROWS[i], SHADOW);

    for (let y = 0; y < SCREEN_H; y++) {
      for (let x = 0; x < SCREEN_W; x++) if (body.get(x, y)) r.set(x + 3, y + 3, SHADOW);
    }
    for (let y = 0; y < SCREEN_H; y++) {
      for (let x = 0; x < SCREEN_W; x++) {
        if (!body.get(x, y)) continue;
        const sh = shell(body, x, y, 3);
        if (sh.depth === 0) r.set(x, y, SHADOW);
        else if (sh.depth <= 2) r.set(x, y, sh.topLeft ? LIT : MID);
        else r.set(x, y, FACE);
      }
    }

    r.blit(relief(channelMask(false, opts.live), NONE), 0, 0);
    if (opts.live && opts.live.some(Boolean)) {
      r.blit(relief(channelMask(true, opts.live), NONE, { glow: true }), 0, 0);
    }

    for (let i = 0; i < SOCKETS.length; i++) {
      const s = SOCKETS[i];
      const recess = new Mask(SCREEN_W, SCREEN_H);
      recess.disc(s.x, s.y, SOCKET_R);
      const R2 = SOCKET_R + 3;
      for (let y = s.y - R2; y <= s.y + R2; y++) {
        for (let x = s.x - R2; x <= s.x + R2; x++) {
          if (recess.get(x, y)) {
            const sh = shell(recess, x, y, 3);
            if (sh.depth <= 1) r.set(x, y, sh.topLeft ? SHADOW : MID);
            else r.set(x, y, FACE);
          } else if (body.get(x, y)) {
            if (recess.get(x + 1, y) || recess.get(x, y + 1) || recess.get(x + 1, y + 1)) {
              r.set(x, y, LIT);
            }
          }
        }
      }
      r.blit(relief(markMask(carried[i]), NONE), s.x - MARK / 2, s.y - MARK / 2);
    }
    return r;
  }

  return {
    LIT: LIT, FACE: FACE, MID: MID, SHADOW: SHADOW, NONE: NONE,
    MARK: MARK, SCREEN_W: SCREEN_W, SCREEN_H: SCREEN_H,
    Mask: Mask, Plane: Plane, relief: relief, shell: shell,
    MARKS: MARKS, markMask: markMask, markRelief: markRelief,
    harnessScreen: harnessScreen, SOCKETS: SOCKETS, HUB: HUB, SOCKET_R: SOCKET_R,
  };
}));
