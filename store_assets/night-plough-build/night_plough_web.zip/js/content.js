/**
 * content.js — NIGHT PLOUGH, the FREE EDITION's content: the first ten villages.
 * ⛔ wing §1-DEMO: the other thirty village SPECS and the ending live in content_full.js, which the free
 *    index.html has no <script> tag for and the free package does not contain.
 * A spec is { seed, style, name }; village.js turns it into streets. `seed` is the screened village
 * index, so every number in the candidate screen describes exactly these villages.
 */
(function (root) {
  'use strict';
  root.CONTENT = {
    edition: 'free',
    villages: [
      { id: 1,  seed: 0,  style: 'GRID',  name: 'HOLLOWMERE' },
      { id: 2,  seed: 1,  style: 'CROSS', name: 'ASHBY CROSS' },
      { id: 3,  seed: 2,  style: 'LANES', name: 'LITTLE WENDLE' },
      { id: 4,  seed: 3,  style: 'RIVER', name: 'COLDBROOK' },
      { id: 5,  seed: 4,  style: 'GRID',  name: 'FENWICK' },
      { id: 6,  seed: 5,  style: 'CROSS', name: 'MARKET THORNE' },
      { id: 7,  seed: 6,  style: 'LANES', name: 'SLEETHWAITE' },
      { id: 8,  seed: 7,  style: 'RIVER', name: 'TWO BRIDGES' },
      { id: 9,  seed: 8,  style: 'GRID',  name: 'EASTFOLD' },
      { id: 10, seed: 9,  style: 'CROSS', name: 'KIRKBY HOLM' },
    ],
    endingTitle: 'FIRST LIGHT',
    ending: null,
    // REVIEW DEFECTS 9, 15: this oversold (the free player has already seen rivers and market squares, and no
    // lane doubles back) and wrapped to 9 lines, orphaning the call to action. Two short true paragraphs now.
    demoEnd: ['TEN VILLAGES CLEARED BEFORE DAWN.', 'THIRTY MORE ARE UNDER THE SNOW, KNOTTIER AS THEY GO, AND THE LAST ONE ENDS THE STORY. THE FULL GAME IS THE PAID DOWNLOAD ON THIS PAGE.'],
  };
}(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this)));
