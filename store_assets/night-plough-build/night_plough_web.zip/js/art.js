/**
 * art.js — NIGHT PLOUGH. The village picture, drawn from village.js's graph, and THE SINGLE SOURCE OF
 * TRUTH for it (the contact sheet, the store captures and the game all require this file).
 *
 * ⛔ TAILRACE (§0-ART-f): a street plan drawn as constant-width lines on right angles reads as a DIAGRAM
 *    whatever it depicts. So the streets are the LEAST of the picture: what reads is the village — snowed
 *    roofs with dark eaves and lit windows, conifers, a frozen river with its bridges, the depot shed —
 *    placed in the blocks the streets leave, and every village's blocks are different because its
 *    streets are.
 * ⛔ PALETTE LAW (§0-ART-g): shade 0 next to shade 3. Snow is 0, cleared asphalt is 3 — the 119.3-luma
 *    edge IS the progress the player makes. A snowed street is 0 between shade-2 kerbs (81 luma), never
 *    1 on 0 (14 luma, invisible).
 */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.ART = api;
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const LIT = 0, FACE = 1, MID = 2, SHADOW = 3, NONE = 255;
  const W = 160, H = 144, HUD_H = 12, ROAD = 3;   // road half-width in px

  function Plane(w, h, fill) { this.w = w; this.h = h; this.px = new Uint8Array(w * h).fill(fill === undefined ? NONE : fill); }
  Plane.prototype.set = function (x, y, s) { if (s === NONE) return; x = Math.round(x); y = Math.round(y); if (x < 0 || y < 0 || x >= this.w || y >= this.h) return; this.px[y * this.w + x] = s; };
  Plane.prototype.get = function (x, y) { return (x < 0 || y < 0 || x >= this.w || y >= this.h) ? NONE : this.px[y * this.w + x]; };
  Plane.prototype.rect = function (x, y, w, h, s) { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) this.set(x + i, y + j, s); };
  Plane.prototype.hline = function (x0, x1, y, s) { for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x++) this.set(x, y, s); };

  function hash2(x, y) { let n = (x | 0) * 374761393 + (y | 0) * 668265263; n = Math.imul(n ^ (n >>> 13), 1274126177); return ((n ^ (n >>> 16)) >>> 0) / 4294967296; }

  /** Distance from point to segment, and the parameter along it. */
  function segDist(px, py, ax, ay, bx, by) {
    const dx = bx - ax, dy = by - ay, L2 = dx * dx + dy * dy || 1;
    let t = ((px - ax) * dx + (py - ay) * dy) / L2; t = Math.max(0, Math.min(1, t));
    const qx = ax + dx * t, qy = ay + dy * t;
    return { d: Math.hypot(px - qx, py - qy), t: t };
  }

  /** Which street (edge index) owns each road pixel, or -1. Precomputed once per village. */
  function roadMap(v) {
    if (v._road) return v._road;
    const own = new Int16Array(W * H).fill(-1), dist = new Float32Array(W * H).fill(99), along = new Float32Array(W * H);
    v.edges.forEach((e, k) => {
      const a = v.nodes[e.a], b = v.nodes[e.b];
      const x0 = Math.floor(Math.min(a.x, b.x) - ROAD - 1), x1 = Math.ceil(Math.max(a.x, b.x) + ROAD + 1);
      const y0 = Math.floor(Math.min(a.y, b.y) - ROAD - 1), y1 = Math.ceil(Math.max(a.y, b.y) + ROAD + 1);
      for (let y = Math.max(0, y0); y <= Math.min(H - 1, y1); y++) for (let x = Math.max(0, x0); x <= Math.min(W - 1, x1); x++) {
        const s = segDist(x, y, a.x, a.y, b.x, b.y);
        if (s.d <= ROAD + 0.5 && s.d < dist[y * W + x]) { dist[y * W + x] = s.d; own[y * W + x] = k; along[y * W + x] = s.t * e.len; }
      }
    });
    // every road pixel, once, for the per-frame "which of these is ploughed" pass
    const list = [];
    for (let i = 0; i < own.length; i++) if (own[i] >= 0) list.push(i);
    v._road = { own: own, dist: dist, along: along, list: list };
    return v._road;
  }

  /* ------------------------------------------------------------------ the village furniture */
  /* ⛔ REVISION 2 — the first look (Capture/full/_sheet_2x.png) read every house as a DARK BRICK: the
   * snowed roof was shade 0 on shade-0 snow with no outline, so only the walls showed. A snowed roof is
   * a WHITE GABLE WITH A DARK OUTLINE (0 inside 3 — the palette law's strongest edge), sitting on dark
   * walls with lit windows. */
  function house(p, x, y, w, h, seed) {
    const roofH = Math.max(4, Math.round(h * 0.55));
    const mid = x + (w - 1) / 2;
    for (let j = 0; j < roofH; j++) {
      const half = Math.round((j + 1) / roofH * (w / 2 + 1));
      const x0 = Math.round(mid - half), x1 = Math.round(mid + half);
      p.hline(x0, x1, y + j, LIT);
      p.set(x0 - 1, y + j, SHADOW); p.set(x1 + 1, y + j, SHADOW);
    }
    p.set(Math.round(mid), y - 1, SHADOW);
    p.hline(x - 2, x + w + 1, y + roofH, SHADOW);
    p.rect(x, y + roofH + 1, w, h - roofH - 1, SHADOW);
    for (let k = 0; k < Math.floor((w - 1) / 3); k++) if (hash2(seed + k, 3) < 0.75) p.set(x + 1 + k * 3, y + roofH + 2, LIT);
    if (hash2(seed, 9) < 0.5) { const cx = Math.round(mid + w * 0.25); p.set(cx, y + 1, SHADOW); p.set(cx, y, SHADOW); p.set(cx + 1, y, SHADOW); }
  }
  /* ⛔ REVISION 2 — the first look read the trees as "≡" glyphs (alternating rows). A conifer is a SOLID
   * dark triangle in tiers; the snow sits as short white shelves INSIDE it (0 inside 3). */
  function tree(p, x, y, h) {
    for (let j = 0; j < h; j++) {
      const tier = j % 3, hw = Math.min(4, 1 + Math.floor(j / 2)) - (tier === 0 && j > 0 ? 1 : 0);
      p.hline(x - hw, x + hw, y + j, SHADOW);
      if (tier === 1 && j > 1) p.hline(x - hw + 1, x - 1, y + j, LIT);
    }
    p.set(x, y + h, SHADOW); p.set(x, y + h + 1, SHADOW);
  }
  function church(p, x, y) {
    p.rect(x, y + 6, 10, 8, SHADOW);
    for (let j = 0; j < 4; j++) p.hline(x - 1 + j, x + 10 - j, y + 2 + j, LIT);
    p.rect(x + 7, y - 4, 3, 10, SHADOW);
    p.set(x + 8, y - 6, SHADOW); p.set(x + 8, y - 5, SHADOW); p.set(x + 7, y - 5, SHADOW); p.set(x + 9, y - 5, SHADOW);
    p.set(x + 3, y + 9, LIT); p.set(x + 3, y + 10, LIT);
  }

  /** The snowfield, streets (cleared or not), and the village furniture in the blocks.
   *  `cleared` = Set/array of edge indices already ploughed (drawn as asphalt, shade 3). */
  function villagePlane(v, cleared) {
    const p = new Plane(W, H, LIT);
    const rm = roadMap(v);
    const isClear = (k) => cleared && (cleared.has ? cleared.has(k) : cleared[k]);
    // snowfield: moonlit drifts as long continuous shade-1 ripples (never isolated specks)
    for (let y = HUD_H; y < H; y++) for (let x = 0; x < W; x++) {
      const drift = Math.sin(x * 0.11 + y * 0.35 + hash2(0, y >> 3) * 6) > 0.93;
      p.set(x, y, drift ? FACE : LIT);
    }
    // river
    if (v.river) {
      for (let y = HUD_H; y < H; y++) {
        const cx = v.river.x + Math.sin(y * 0.09) * 3;
        for (let x = Math.floor(cx - 5); x <= Math.ceil(cx + 5); x++) {
          const edge = Math.abs(x - cx) > 4;
          p.set(x, y, edge ? SHADOW : (hash2(x, y >> 1) < 0.08 ? LIT : MID));
        }
      }
    }
    // furniture in the blocks: sample block cells away from any road
    const occupied = new Uint8Array(W * H);
    const free = (x, y, w, h) => {
      for (let j = -2; j < h + 2; j++) for (let i = -2; i < w + 2; i++) {
        const X = x + i, Y = y + j;
        if (X < 2 || Y < HUD_H + 2 || X >= W - 2 || Y >= H - 2) return false;
        const k = Y * W + X;
        if (rm.own[k] >= 0 || occupied[k]) return false;
        if (v.river && Math.abs(X - v.river.x) < 8) return false;
      }
      return true;
    };
    const mark = (x, y, w, h) => { for (let j = -1; j < h + 1; j++) for (let i = -1; i < w + 1; i++) { const X = x + i, Y = y + j; if (X >= 0 && Y >= 0 && X < W && Y < H) occupied[Y * W + X] = 1; } };
    let seed = v.i * 131 + 7, placedChurch = false;
    for (let y = HUD_H + 3; y < H - 10; y += 3) for (let x = 3; x < W - 12; x += 3) {
      const h = hash2(seed++, x * 7 + y);
      if (!placedChurch && h < 0.02 && free(x, y, 12, 16)) { church(p, x, y + 4); mark(x, y, 12, 16); placedChurch = true; continue; }
      const hw = 9 + Math.floor(hash2(x, y * 3) * 4), hh = 9 + Math.floor(hash2(y, x * 5) * 3);
      if (h < 0.22 && free(x - 2, y - 1, hw + 4, hh + 1)) { house(p, x, y, hw, hh, seed); mark(x - 2, y - 1, hw + 4, hh + 1); }
      else if (h < 0.36 && free(x - 3, y, 9, 11)) { tree(p, x + 1, y, 9); mark(x - 3, y, 9, 11); }
    }
    // streets
    for (let y = HUD_H; y < H; y++) for (let x = 0; x < W; x++) {
      const k = rm.own[y * W + x]; if (k < 0) continue;
      const d = rm.dist[y * W + x];
      const e = v.edges[k];
      if (isClear(k)) p.set(x, y, d > ROAD - 0.6 ? MID : (hash2(x, y) < 0.04 ? MID : SHADOW));
      else p.set(x, y, d > ROAD - 0.6 ? MID : (e.bridge ? LIT : LIT));
      if (e.bridge && d > ROAD - 0.6) p.set(x, y, SHADOW);
    }
    // depot shed at the depot junction
    const dp = v.nodes[v.depot];
    // REVIEW DEFECT 5: the shed was drawn below the depot and fell off the bottom edge; it now sits above
    // the junction whenever below would not fit on the 144-row screen.
    const sx = Math.round(dp.x) - 6, sy = Math.round(dp.y) + 4 + 7 <= H - 1 ? Math.round(dp.y) + 4 : Math.round(dp.y) - 11;
    p.rect(sx, sy, 12, 6, SHADOW); p.hline(sx - 1, sx + 12, sy - 1, LIT); p.rect(sx + 4, sy + 2, 4, 4, MID);
    return p;
  }

  /* ============================================================================ THE TITLE ART
   * Baked to art/title.png by Internal_Ops/build_art.js (a REAL shipped art file, drawn by the game
   * with drawImage — never read back, so it works on the paid build's file:// origin). Night sky (3),
   * a moon (0) with shade-2 craters, the village's roofline — white gables outlined in 3, dark walls,
   * lit windows — and the plough's own black road curving out of the snow with white banks thrown up.
   * `font` is DW_FONT (passed in, so the lettering is the game's own face). */
  function titlePlane(font) {
    const p = new Plane(W, H, SHADOW);
    for (let y = 0; y < 70; y++) for (let x = 0; x < W; x++) if (hash2(x * 3, y * 7) < 0.012) p.set(x, y, hash2(x, y) < 0.5 ? LIT : FACE);
    /* REVISION 2 (looked at art/title_4x.png): the lettering band sat over the road and the plough — the
     * one thing the title should show — and the type was off-centre. The band now lives in the SKY and
     * the scene below it is the village, the road and the plough, uncovered. */
    for (let y = -9; y <= 9; y++) for (let x = -9; x <= 9; x++) if (x * x + y * y <= 85) p.set(134 + x, 12 + y, LIT);
    [[-3, -3, 2.2], [3, 2, 1.8], [-1, 5, 1.4], [4, -4, 1.2]].forEach((c) => { for (let y = -3; y <= 3; y++) for (let x = -3; x <= 3; x++) if (x * x + y * y <= c[2] * c[2]) p.set(134 + c[0] + x, 12 + c[1] + y, MID); });
    // far hills
    for (let x = 0; x < W; x++) { const hy = 74 + Math.round(Math.sin(x * 0.045) * 4 + Math.sin(x * 0.13) * 2); for (let y = hy; y < 88; y++) p.set(x, y, MID); p.set(x, hy, FACE); }
    // snowfield
    for (let y = 88; y < H; y++) for (let x = 0; x < W; x++) p.set(x, y, Math.sin(x * 0.11 + y * 0.35) > 0.93 ? FACE : LIT);
    // the roofline: a row of cottages and a church
    let x = 2, seed = 11;
    while (x < W - 6) {
      const w = 11 + Math.floor(hash2(seed, 1) * 7), h = 12 + Math.floor(hash2(seed, 2) * 6);
      const base = 92, top = base - h;
      if (hash2(seed, 3) < 0.13 && x > 20 && x < 120) {
        p.rect(x, base - 14, 12, 14, SHADOW); p.rect(x + 8, base - 30, 4, 16, SHADOW);
        for (let j = 0; j < 6; j++) p.hline(x + 10 - Math.floor(j / 2), x + 10 + Math.floor(j / 2), base - 36 + j, SHADOW);
        p.set(x + 10, base - 38, SHADOW); p.set(x + 10, base - 37, SHADOW);
        for (let j = 0; j < 5; j++) p.hline(x - 1 + j, x + 8 - j, base - 19 + j, LIT);
        p.set(x + 4, base - 9, LIT); p.set(x + 4, base - 8, LIT); p.set(x + 10, base - 24, LIT);
        x += 16; seed++; continue;
      }
      const roofH = Math.round(h * 0.5), mid = x + (w - 1) / 2;
      for (let j = 0; j < roofH; j++) { const half = Math.round((j + 1) / roofH * (w / 2 + 1)); p.hline(Math.round(mid - half), Math.round(mid + half), top + j, LIT); p.set(Math.round(mid - half) - 1, top + j, SHADOW); p.set(Math.round(mid + half) + 1, top + j, SHADOW); }
      p.set(Math.round(mid), top - 1, SHADOW);
      p.hline(x - 2, x + w + 1, top + roofH, SHADOW);
      p.rect(x, top + roofH + 1, w, h - roofH - 1, SHADOW);
      for (let k = 0; k < Math.floor((w - 2) / 3); k++) if (hash2(seed + k, 5) < 0.8) { p.set(x + 2 + k * 3, top + roofH + 3, LIT); p.set(x + 2 + k * 3, top + roofH + 4, LIT); }
      x += w + 3 + Math.floor(hash2(seed, 4) * 4); seed++;
    }
    // the ploughed road, curving from bottom-left toward the village, banks thrown white on both sides
    for (let t = 0; t <= 1; t += 0.002) {
      const cx = 4 + t * 118 + Math.sin(t * 3.2) * 12, cy = 146 - t * 50, half = 8 - t * 5.5;
      for (let d = -half - 2; d <= half + 2; d++) { const px = Math.round(cx + d * 0.5), py = Math.round(cy + d * 0.45); if (py >= 90) p.set(px, py, Math.abs(d) > half ? LIT : SHADOW); }
    }
    // the plough on the road, cab lit, blade white, facing up the road
    const px = 52, py = 124;
    p.rect(px - 6, py - 5, 13, 10, SHADOW); p.rect(px - 5, py - 4, 11, 8, FACE); p.rect(px - 2, py - 9, 6, 5, SHADOW); p.rect(px - 1, py - 8, 4, 3, FACE);
    for (let j = -7; j <= 5; j++) { p.set(px + 9, py + j - 2, SHADOW); p.set(px + 8, py + j - 2, LIT); }
    p.set(px + 1, py - 10, LIT); p.set(px + 2, py - 10, LIT); p.set(px - 4, py + 5, SHADOW); p.set(px + 4, py + 5, SHADOW);
    if (font) {
      p.rect(0, 30, W, 30, SHADOW); p.hline(0, W - 1, 29, LIT); p.hline(0, W - 1, 60, LIT);
      font.textPlane(p, 'NIGHT', W / 2, 32, { align: 'center', face: 'display', shade: LIT });
      font.textPlane(p, 'PLOUGH', W / 2, 45, { align: 'center', face: 'display', shade: LIT });
    }
    return p;
  }

  return { LIT, FACE, MID, SHADOW, NONE, W, H, HUD_H, ROAD, Plane, hash2, roadMap, villagePlane, segDist, titlePlane };
}));
