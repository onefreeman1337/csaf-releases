/**
 * game.js — NIGHT PLOUGH. Clear every street before dawn and bring the plough home.
 *
 * ONE SENTENCE OF DESIGN: every street must be ploughed and you must end at the depot, and every
 * street you drive twice burns fuel — the proved-cheapest route (village.js optimum()) is the par.
 *
 * ⛔ THE PRIMARY INPUT IS A HOLD (wing §0a-2): hold a direction and the plough drives; at a junction it
 *    takes the street that best matches the held direction. Nothing is picked from a menu.
 * ⛔ §1a: the automation tab is hidden and rAF is throttled to zero there, so every harness drives the
 *    game through the synchronous `window.PLOUGH.step(n)` and reads `window.PLOUGH.frames`.
 */
(function (root) {
  'use strict';

  var ART = root.ART, FONT = root.DW_FONT, C = root.CONTENT, SND = root.PSOUND, V = root.VILLAGE;
  var W = ART.W, H = ART.H, LIT = ART.LIT, FACE = ART.FACE, MID = ART.MID, SHADOW = ART.SHADOW;
  var DMG = ['#9bbc0f', '#8bac0f', '#306230', '#0f380f'];
  var SPEED = 1.0, SEG = 2, FUEL_SLACK = 1.30, TURN_COS = 0.35;

  if (!C || !C.villages || !C.villages.length) throw new Error('content: no villages');

  var S = {
    screen: 'title', frames: 0, vi: 0, run: null, result: null,
    held: { x: 0, y: 0 }, muted: false, paused: false, endPage: 0, reveal: false,
    best: {},
  };

  /* ⛔ The best route per village is PERSISTED and shown before every job — the margin to par is the
   *    whole game, so it must be on screen, not in a log (LODESTONE's review, wing Devlog 09-22). */
  var BEST_KEY = 'NIGHTPLOUGH_BEST_' + (C.edition === 'full' ? 'full' : 'free');
  try { S.best = JSON.parse(root.localStorage.getItem(BEST_KEY) || '{}') || {}; } catch (e) { S.best = {}; }
  function saveBest() { try { root.localStorage.setItem(BEST_KEY, JSON.stringify(S.best)); } catch (e) { /* private mode */ } }
  /* REVIEW DEFECT 25: the selected village is remembered, so a reload does not mean 29 presses of RIGHT. */
  var VI_KEY = 'NIGHTPLOUGH_VI_' + (C.edition === 'full' ? 'full' : 'free');
  function saveVi() { try { root.localStorage.setItem(VI_KEY, String(S.vi)); } catch (e) { /* private mode */ } }
  function bestFor(id) { var b = S.best[String(id)]; return typeof b === 'number' ? b : null; }
  function unlocked(ix) { return ix === 0 || bestFor(C.villages[ix - 1].id) !== null || bestFor(C.villages[ix].id) !== null; }

  function village(ix) { return V.generate(C.villages[ix]); }
  (function restoreVi() {
    var v = 0;
    try { v = parseInt(root.localStorage.getItem(VI_KEY) || '0', 10) || 0; } catch (e) { v = 0; }
    v = Math.max(0, Math.min(C.villages.length - 1, v));
    while (v > 0 && !unlocked(v)) v--;
    S.vi = v;
  }());

  var MEDALS = [
    // REVIEW DEFECT 14: "THE BEST ROUTE THERE IS" sat above a route 0.5% longer than it. Gold is AS GOOD AS.
    { name: 'GOLD', max: 1.005, line: 'AS GOOD AS THE BEST ROUTE' },
    { name: 'SILVER', max: 1.06, line: 'A SKILLED NIGHT' },
    { name: 'BRONZE', max: 1.15, line: 'THE JOB IS DONE' },
    { name: 'CLEARED', max: Infinity, line: 'CLEAR, BUT THIRSTY' },
  ];
  function medalFor(ratio) { for (var i = 0; i < MEDALS.length; i++) if (ratio <= MEDALS[i].max) return MEDALS[i]; return MEDALS[3]; }

  /* ------------------------------------------------------------------------ the drive */

  function beginRun() {
    var v = village(S.vi), opt = V.optimum(v);
    var cover = v.edges.map(function (e) { return new Uint8Array(Math.max(1, Math.ceil(e.len / SEG))); });
    S.run = {
      v: v, opt: opt, node: v.depot, edge: -1, from: -1, to: -1, s: 0, dirSign: 1, moveSign: 1, bumped: false,
      fuel: opt.total * FUEL_SLACK, fuelMax: opt.total * FUEL_SLACK, driven: 0,
      cover: cover, clearedEdges: 0, done: new Uint8Array(v.edges.length), tick: 0, heading: [1, 0],
    };
    S.screen = 'plough'; S.paused = false; S.reveal = false;
    if (SND) SND.cue('start');
  }

  function incident(v, u) {
    if (!v._inc) { v._inc = v.nodes.map(function () { return []; }); v.edges.forEach(function (e, k) { v._inc[e.a].push(k); v._inc[e.b].push(k); }); }
    return v._inc[u];
  }
  function otherEnd(e, u) { return e.a === u ? e.b : e.a; }
  function pos(r) {
    if (r.edge < 0) return { x: r.v.nodes[r.node].x, y: r.v.nodes[r.node].y };
    var a = r.v.nodes[r.from], b = r.v.nodes[r.to], len = r.v.edges[r.edge].len, t = r.s / len;
    return { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t };
  }

  /** Mark the stretch of street the blade passed over, in the street's OWN coordinates (from node a).
   *  ⛔ REVIEW DEFECT 14: the end segments used to be marked as soon as the blade TOUCHED them, so reversing
   *  ~2 px short of a dead end "cleared" it and a careful player could post a route below the proved best.
   *  The first and last segments now need the blade to reach the street's actual end. */
  function plough(r, s0, s1) {
    var e = r.v.edges[r.edge], len = e.len, cov = r.cover[r.edge];
    var lo = Math.min(s0, s1), hi = Math.max(s0, s1);
    if (r.from !== e.a) { var t = len - hi; hi = len - lo; lo = t; }
    var last = cov.length - 1;
    for (var g = Math.max(0, Math.floor(lo / SEG)); g <= Math.min(last, Math.floor(hi / SEG)); g++) {
      if (g === 0 && lo > 0.01) continue;
      if (g === last && hi < len - 0.01) continue;
      cov[g] = 1;
    }
    if (!r.done[r.edge]) {
      var all = true; for (var i = 0; i < cov.length; i++) if (!cov[i]) { all = false; break; }
      if (all) { r.done[r.edge] = 1; r.clearedEdges++; if (SND) SND.cue('street'); }
    }
  }

  function stepPlough() {
    var r = S.run, v = r.v;
    r.tick++;
    var hx = S.held.x, hy = S.held.y;
    if (r.edge < 0) {
      if (!hx && !hy) { r.bumped = false; return; }
      // at a junction: take the street that best matches the held direction.
      /* ⛔ REVIEW DEFECT 1 (BLOCKING): with four-way input a diagonal street could lose to a straight
       * neighbour for EVERY direction at both ends and never be driven — a softlock at free village 2 on a
       * phone. Touch is now analog (any angle), and among streets within 0.15 of the best match an UNCLEARED
       * one is preferred, so a four-way d-pad can still reach every street it needs.
       * Internal_Ops/verify_reach.js proves every street reachable with 4-way, 8-way and analog input. */
      var m = Math.hypot(hx, hy), inc = incident(v, r.node), cand = [];
      for (var i = 0; i < inc.length; i++) {
        var e = v.edges[inc[i]], w = otherEnd(e, r.node);
        var dx = v.nodes[w].x - v.nodes[r.node].x, dy = v.nodes[w].y - v.nodes[r.node].y, L = Math.hypot(dx, dy) || 1;
        var c = (dx * hx + dy * hy) / (L * m);
        if (c > TURN_COS) cand.push({ k: inc[i], c: c, open: !r.done[inc[i]] });
      }
      if (!cand.length) {
        // REVIEW DEFECT 20: no street that way — say so once, rather than stopping in silence
        if (!r.bumped && SND) SND.cue('bump');
        r.bumped = true;
        return;
      }
      var top = Math.max.apply(null, cand.map(function (q) { return q.c; }));
      cand.sort(function (p, q) {
        var pn = p.open && p.c >= top - 0.15, qn = q.open && q.c >= top - 0.15;
        if (pn !== qn) return pn ? -1 : 1;
        return q.c - p.c;
      });
      var best = cand[0].k;
      r.bumped = false;
      r.edge = best; r.from = r.node; r.to = otherEnd(v.edges[best], r.node); r.s = 0; r.node = -1; r.moveSign = 1;
      if (SND) SND.cue('turn');
    }
    // on a street: the opposite of your CURRENT motion reverses; along it drives on; a sideways hold keeps
    // going the way you are already going. ⛔ REVIEW DEFECT 3: this used to measure against the street's
    // from->to direction, so after a reversal a sideways press U-turned the plough back the way it came.
    var a = v.nodes[r.from], b = v.nodes[r.to], len = v.edges[r.edge].len;
    var ux = (b.x - a.x) / len, uy = (b.y - a.y) / len;
    var dot = hx * ux + hy * uy, mag = Math.hypot(hx, hy);
    if (!mag) return;
    var along = dot / mag;
    var dir = along < -0.3 ? -1 : (along > 0.3 ? 1 : r.moveSign);
    r.moveSign = dir;
    r.heading = [ux * dir, uy * dir];
    var s0 = r.s, step = Math.min(SPEED, r.fuel);
    r.s = Math.max(0, Math.min(len, r.s + dir * step));
    var moved = Math.abs(r.s - s0);
    r.fuel -= moved; r.driven += moved;
    plough(r, s0, r.s);
    if (r.s >= len - 1e-9) { r.node = r.to; r.edge = -1; }
    else if (r.s <= 1e-9) { r.node = r.from; r.edge = -1; }
    if (r.edge < 0) arrive(r);
    else if (r.fuel <= 1e-6) finish(false);
  }

  function arrive(r) {
    if (r.clearedEdges === r.v.edges.length && r.node === r.v.depot) finish(true);
    else if (r.fuel <= 1e-6) finish(false);
  }

  function finish(ok) {
    var r = S.run, c = C.villages[S.vi];
    if (ok) {
      var ratio = r.driven / r.opt.total, prev = bestFor(c.id);
      var isBest = prev === null || r.driven < prev - 0.01;
      if (isBest) { S.best[String(c.id)] = r.driven; saveBest(); }
      S.result = { ok: true, driven: r.driven, opt: r.opt.total, ratio: ratio, medal: medalFor(ratio), newBest: isBest, hadBest: prev !== null, prev: prev };
      if (SND) SND.cue('done');
    } else {
      S.result = { ok: false, cleared: r.clearedEdges, streets: r.v.edges.length };
      if (SND) SND.cue('dry');
    }
    S.screen = 'result';
  }

  /* ----------------------------------------------------------------------------- drawing */

  var plane = new ART.Plane(W, H, LIT);
  var baseCache = { key: '', plane: null };
  var MAXCH = Math.floor(W / FONT.FACES.body.adv);
  var CARDCH = Math.floor((W - 12 - 8) / FONT.FACES.body.adv);
  function wrap(str, max) {
    max = max || MAXCH; var words = String(str).split(' '), lines = [], cur = '';
    for (var i = 0; i < words.length; i++) { var nx = cur ? cur + ' ' + words[i] : words[i]; if (nx.length > max && cur) { lines.push(cur); cur = words[i]; } else cur = nx; }
    if (cur) lines.push(cur); return lines;
  }

  function baseFor(v) {
    var key = v.name + v.edges.length;
    if (baseCache.key !== key) { baseCache.plane = ART.villagePlane(v, null); baseCache.key = key; }
    plane.px.set(baseCache.plane.px);
  }

  /** Overlay the ploughed stretches: asphalt (3) inside the kerbs, banked snow (0) thrown to the sides. */
  function drawCover(r) {
    var rm = ART.roadMap(r.v);
    for (var n = 0; n < rm.list.length; n++) {
      var i = rm.list[n], k = rm.own[i], g = Math.floor(rm.along[i] / SEG), cov = r.cover[k];
      if (!cov[Math.min(cov.length - 1, g)]) continue;
      plane.px[i] = rm.dist[i] > ART.ROAD - 0.6 ? LIT : (ART.hash2(i, 5) < 0.05 ? MID : SHADOW);
    }
  }

  /* ⛔ REVISION 2 — the first mid-drive capture could not FIND the plough: a dark body on dark asphalt.
   * It is now a LIGHT cab (1) inside a dark outline (3), with a white blade (0) outlined in 3 across the
   * front and a blinking roof lamp — readable on snow (0) AND on ploughed road (3), because it carries
   * its own outline both ways. */
  function drawPlough(px, py, heading) {
    var hx = heading[0], hy = heading[1], nx = -hy, ny = hx;
    for (var y = -3; y <= 3; y++) for (var x = -3; x <= 3; x++) plane.set(px + x, py + y, SHADOW);
    for (var y2 = -2; y2 <= 2; y2++) for (var x2 = -2; x2 <= 2; x2++) plane.set(px + x2, py + y2, FACE);
    for (var t0 = -4; t0 <= 4; t0++) plane.set(Math.round(px + hx * 5 + nx * t0), Math.round(py + hy * 5 + ny * t0), SHADOW);
    for (var t = -3; t <= 3; t++) plane.set(Math.round(px + hx * 4 + nx * t), Math.round(py + hy * 4 + ny * t), LIT);
    plane.set(px, py, (S.frames >> 3) % 2 ? LIT : SHADOW);
    plane.set(Math.round(px - hx * 2), Math.round(py - hy * 2), SHADOW);
  }

  function hud(r, v) {
    plane.rect(0, 0, W, ART.HUD_H, SHADOW);
    FONT.textPlane(plane, 'FUEL', 3, 3, { shade: LIT });
    var gx = 29, gw = 50;
    for (var e = 0; e < gw; e++) { plane.set(gx + e, 2, LIT); plane.set(gx + e, 9, LIT); }
    for (var e2 = 2; e2 <= 9; e2++) { plane.set(gx, e2, LIT); plane.set(gx + gw - 1, e2, LIT); }
    var fill = Math.max(0, Math.round((gw - 4) * r.fuel / r.fuelMax));
    if (fill > 0) plane.rect(gx + 2, 4, fill, 4, LIT);
    // the par mark: where the gauge will stand if you drive the proved-best route
    // REVIEW DEFECT 19: the par mark was two single pixels outside the frame. It is now a notch cut through
    // the whole gauge — dark where the fill is lit, lit where the trough is dark — so it reads at 1x.
    var parX = gx + 2 + Math.round((gw - 4) * (r.fuelMax - r.opt.total) / r.fuelMax);
    for (var py = 1; py <= 10; py++) plane.set(parX, py, (py >= 4 && py <= 7 && parX < gx + 2 + fill) ? SHADOW : LIT);
    var all = r.clearedEdges === v.edges.length;
    FONT.textPlane(plane, all ? 'GO HOME' : r.clearedEdges + '/' + v.edges.length, W - 3, 3, { align: 'right', shade: LIT });
  }

  function drawPloughScreen() {
    var r = S.run, v = r.v;
    baseFor(v);
    drawCover(r);
    var p = pos(r);
    drawPlough(Math.round(p.x), Math.round(p.y), r.heading);
    if (r.clearedEdges === v.edges.length && (S.frames >> 4) % 2) {
      var d = v.nodes[v.depot];
      for (var a = 0; a < 24; a++) { var t = a / 24 * 6.283; plane.set(Math.round(d.x + Math.cos(t) * 7), Math.round(d.y + Math.sin(t) * 7), SHADOW); }
    }
    hud(r, v);
    if (S.paused) {
      plane.rect(30, 54, 100, 38, SHADOW); plane.hline(30, 129, 54, LIT);
      FONT.textPlane(plane, 'PAUSED', W / 2, 60, { align: 'center', shade: LIT });
      FONT.textPlane(plane, 'P RESUME', W / 2, 72, { align: 'center', shade: FACE });
      FONT.textPlane(plane, 'X GIVE UP', W / 2, 81, { align: 'center', shade: FACE });
    }
  }

  function card(title, lines, footer) {
    plane.px.fill(MID);
    for (var i = 0; i < 10; i++) plane.hline(0, W - 1, 7 + i * 15, SHADOW);
    plane.rect(6, 14, W - 12, H - 34, SHADOW);
    plane.hline(6, W - 7, 14, LIT);
    FONT.textPlane(plane, title, W / 2, 22, { align: 'center', shade: LIT });
    plane.hline(30, W - 31, 32, MID);
    var flat = [];
    for (var j = 0; j < lines.length; j++) { if (!lines[j]) { flat.push(''); continue; } wrap(lines[j], CARDCH).forEach(function (l) { flat.push(l); }); }
    for (var k = 0; k < flat.length && 40 + k * 9 <= H - 22; k++) FONT.textPlane(plane, flat[k], W / 2, 40 + k * 9, { align: 'center', shade: FACE });
    if (footer) FONT.textPlane(plane, footer, W / 2, H - 12, { align: 'center', shade: SHADOW, halo: LIT });
  }

  /* THE TITLE ART is a real shipped file, art/title.png, baked from ART.titlePlane() by
   * Internal_Ops/build_art.js and composited with drawImage in paint() — never read back, so it works on
   * the paid build's file:// origin. The plane underneath holds the SAME picture drawn from code, so a
   * failed load still shows the title rather than a hole, and verify_web.js asserts the file really
   * loads in a browser (an asset nothing blits is a dead reader, wing §0z-1c). The two live bands
   * (FREE EDITION, the blinking PRESS Z) are re-put over the image as dirty rectangles. */
  var titleBase = null, titleImg = null, titleState = 'none';
  var FREE_BAND = { x: 0, y: 62, w: W, h: 11 }, PRESS_BAND = { x: 40, y: H - 14, w: 80, h: 11 };
  function loadTitle() {
    if (titleState !== 'none' || !root.Image) return;
    titleState = 'loading';
    titleImg = new root.Image();
    titleImg.onload = function () { titleState = 'ready'; };
    titleImg.onerror = function () { titleState = 'failed'; };
    titleImg.src = 'art/title.png';
  }
  function drawTitle() {
    if (!titleBase) titleBase = ART.titlePlane(FONT);
    plane.px.set(titleBase.px);
    if (C.edition !== 'full') { plane.rect(FREE_BAND.x, FREE_BAND.y, FREE_BAND.w, FREE_BAND.h, SHADOW); FONT.textPlane(plane, 'FREE EDITION', W / 2, FREE_BAND.y + 2, { align: 'center', shade: LIT }); }
    if (S.frames % 48 < 32) { plane.rect(PRESS_BAND.x, PRESS_BAND.y, PRESS_BAND.w, PRESS_BAND.h, SHADOW); FONT.textPlane(plane, 'Z OR TAP', W / 2, PRESS_BAND.y + 2, { align: 'center', shade: LIT }); }
  }

  function drawYard() {
    var v = village(S.vi), c = C.villages[S.vi], opt = V.optimum(v);
    baseFor(v);
    var d = v.nodes[v.depot];
    for (var a = 0; a < 24; a++) { var t = a / 24 * 6.283; plane.set(Math.round(d.x + Math.cos(t) * 7), Math.round(d.y + Math.sin(t) * 7), SHADOW); }
    /* ⛔ REVIEW DEFECT 6: a 22-row header and a 12-row footer hid the top and bottom streets and the depot on
     * the one screen built for planning. One 12-row band now, the same height as the drive HUD, which the
     * village bounds already keep clear of (village.js SAFE). Controls live on the page's buttons and hint. */
    plane.rect(0, 0, W, 12, SHADOW);
    var b = bestFor(c.id);
    FONT.textPlane(plane, (S.vi + 1) + '. ' + c.name, 3, 3, { shade: LIT });
    FONT.textPlane(plane, b === null ? String(v.edges.length) + ' ST' : medalFor(b / opt.total).name, W - 3, 3, { align: 'right', shade: LIT });
  }

  function drawResult() {
    var R = S.result;
    if (R.ok) {
      card(R.medal.name, [
        R.medal.line,
        '',
        'YOUR ROUTE ' + Math.round(R.driven),
        'BEST THERE IS ' + Math.round(R.opt),
        R.newBest ? (R.hadBest ? 'A NEW BEST HERE' : 'FIRST CLEAR HERE') : 'YOUR BEST ' + Math.round(R.prev),
      ], 'Z NEXT  X BEST ROUTE');
    } else {
      // REVIEW DEFECTS 12, 13: giving up is not running dry, and doubling back is unavoidable — the card
      // says what happened and what the job actually rewards.
      card(R.gaveUp ? 'JOB ABANDONED' : 'THE TANK IS DRY', [
        'STREETS CLEARED ' + R.cleared + ' OF ' + R.streets,
        '',
        'EVERY STREET YOU DRIVE TWICE BURNS FUEL. THE BEST ROUTE WASTES THE LEAST.',
      ], 'Z RETRY  X YARD');
    }
  }

  /** THE LESSON, shown on request after a job: where the proved-best route has to double back. Every
   *  odd junction is ringed and each doubled stretch is drawn — the thing the player can learn to see. */
  function drawReveal() {
    var v = village(S.vi), opt = V.optimum(v);
    baseFor(v);
    v.deg.forEach(function (dg, k) {
      if (dg % 2) { var n = v.nodes[k]; for (var a = 0; a < 20; a++) { var t = a / 20 * 6.283; plane.set(Math.round(n.x + Math.cos(t) * 5), Math.round(n.y + Math.sin(t) * 5), SHADOW); } }
    });
    opt.pairs.forEach(function (pr) {
      var u = pr[0], w = pr[1], guard = 0;
      while (u !== w && guard++ < 200) {
        var nx = opt.P.NX[u][w], A = v.nodes[u], B = v.nodes[nx], L = Math.hypot(B.x - A.x, B.y - A.y);
        for (var s = 0; s <= L; s += 1) if ((Math.floor(s / 3) + (S.frames >> 3)) % 2) plane.set(Math.round(A.x + (B.x - A.x) * s / L), Math.round(A.y + (B.y - A.y) * s / L), SHADOW);
        u = nx;
      }
    });
    // ⛔ 26 characters is the whole screen (160 / 6). ⛔ "=" is not in the face (DW_FONT.missing counted it).
    // ⛔ REVIEW DEFECT 6: the bottom bar hid the depot row and the doubled route running into it — one band.
    plane.rect(0, 0, W, 12, SHADOW);
    FONT.textPlane(plane, 'O: ODD JUNCTION  X BACK', W / 2, 3, { align: 'center', shade: LIT });
  }

  /* REVIEW DEFECT 15: pages used to cut every 8 lines, splitting the punchline across a page turn and
   * orphaning the demo's call to action. Pages now break BETWEEN PARAGRAPHS; a paragraph longer than a
   * page is the only thing ever split. */
  var LINES_PER_PAGE = 8;
  function endingPages() {
    var raw = C.ending || [].concat(C.demoEnd || ''), paras = [];
    for (var i = 0; i < raw.length; i++) if (raw[i]) paras.push(wrap(raw[i], CARDCH));
    var pages = [], cur = [];
    paras.forEach(function (p) {
      var need = (cur.length ? 1 : 0) + p.length;
      if (cur.length && cur.length + need > LINES_PER_PAGE) { pages.push(cur); cur = []; }
      if (cur.length) cur.push('');
      for (var k = 0; k < p.length; k++) { if (cur.length >= LINES_PER_PAGE) { pages.push(cur); cur = []; } cur.push(p[k]); }
    });
    if (cur.length) pages.push(cur);
    return pages.length ? pages : [['']];
  }
  function drawEnding() {
    var pages = endingPages(), page = Math.max(0, Math.min(S.endPage, pages.length - 1));
    plane.px.fill(MID);
    for (var i = 0; i < 10; i++) plane.hline(0, W - 1, 7 + i * 15, SHADOW);
    plane.rect(6, 14, W - 12, H - 34, SHADOW); plane.hline(6, W - 7, 14, LIT);
    // REVIEW DEFECT 16: the 26-char free title was wider than its 23-char card
    FONT.textPlane(plane, C.ending ? C.endingTitle : 'END OF THE FREE EDITION', W / 2, 22, { align: 'center', shade: LIT });
    for (var k = 0; k < pages[page].length; k++) FONT.textPlane(plane, pages[page][k], W / 2, 40 + k * 9, { align: 'center', shade: FACE });
    var more = page < pages.length - 1;
    FONT.textPlane(plane, more ? 'Z MORE ' + (page + 1) + '/' + pages.length : 'Z CREDITS', W / 2, H - 12, { align: 'center', shade: SHADOW, halo: LIT });
  }
  function drawCredits() {
    // REVIEW DEFECT 17: the studio name wrapped mid-name and "DATA." was orphaned — lines authored to fit 23
    card('NIGHT PLOUGH', ['CORE SYSTEMS', 'ASSET FACTORY', '', 'CODE, ART AND TEXT MADE', 'WITH AI ASSISTANCE.', 'MUSIC AND SOUND ARE', 'SYNTHESISED FROM NOTES.'], 'X BACK');
  }

  /* ------------------------------------------------------------------------------ paint */
  var cv, ctx, img, data;
  var PAL = DMG.map(function (h) { return [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)]; });
  function paint() {
    for (var i = 0, p = 0; i < plane.px.length; i++, p += 4) { var c = PAL[plane.px[i]] || PAL[0]; data[p] = c[0]; data[p + 1] = c[1]; data[p + 2] = c[2]; data[p + 3] = 255; }
    ctx.putImageData(img, 0, 0);
    if (S.screen === 'title' && titleState === 'ready') {
      ctx.drawImage(titleImg, 0, 0, W, H);
      if (C.edition !== 'full') ctx.putImageData(img, 0, 0, FREE_BAND.x, FREE_BAND.y, FREE_BAND.w, FREE_BAND.h);
      ctx.putImageData(img, 0, 0, PRESS_BAND.x, PRESS_BAND.y, PRESS_BAND.w, PRESS_BAND.h);
    }
  }

  /* ------------------------------------------------------------------------------ input */
  function press(k) {
    if (SND) SND.unlock();
    if (k === 'mute') { S.muted = !S.muted; if (SND) SND.setMuted(S.muted); return; }
    if (S.screen === 'title') { if (k === 'ok') { S.screen = 'yard'; if (SND) SND.cue('ok'); } else if (k === 'back') S.screen = 'credits'; return; }
    if (S.screen === 'yard') {
      if (k === 'left' && S.vi > 0) { S.vi--; saveVi(); if (SND) SND.cue('move'); }
      else if (k === 'right' && S.vi < C.villages.length - 1 && unlocked(S.vi + 1)) { S.vi++; saveVi(); if (SND) SND.cue('move'); }
      else if (k === 'right' && S.vi < C.villages.length - 1) { if (SND) SND.cue('bump'); }   // DEFECT 20: locked, say so
      else if (k === 'ok') beginRun();
      else if (k === 'back') S.screen = 'title';
      return;
    }
    if (S.screen === 'plough') {
      // X from a running drive pauses first (so a touch player's X button is never a one-tap loss)
      if (k === 'pause' || (k === 'back' && !S.paused)) { S.paused = !S.paused; if (SND) SND.cue('ok'); }
      else if (k === 'back' && S.paused) { S.paused = false; S.result = { ok: false, gaveUp: true, cleared: S.run.clearedEdges, streets: S.run.v.edges.length }; S.screen = 'result'; }
      else if (k === 'ok' && S.paused) { S.paused = false; }
      return;
    }
    if (S.screen === 'result') {
      if (k === 'back' && !S.result.ok) { S.screen = 'yard'; if (SND) SND.cue('ok'); return; }
      if (k === 'back') { S.screen = 'reveal'; if (SND) SND.cue('ok'); return; }
      if (k === 'ok') {
        if (S.result.ok) {
          if (S.vi >= C.villages.length - 1) { S.screen = 'ending'; S.endPage = 0; }
          else { S.vi++; saveVi(); S.screen = 'yard'; }
        } else { beginRun(); return; }   // REVIEW DEFECT 13: "Z RETRY" now retries, not a trip to the yard
        if (SND) SND.cue('ok');
      }
      return;
    }
    if (S.screen === 'reveal') { if (k === 'back' || k === 'ok') { S.screen = 'result'; if (SND) SND.cue('ok'); } return; }
    if (S.screen === 'ending') {
      if (k === 'ok') { if (S.endPage < endingPages().length - 1) { S.endPage++; if (SND) SND.cue('move'); } else S.screen = 'credits'; }
      return;
    }
    if (S.screen === 'credits') { if (k === 'back' || k === 'ok') S.screen = 'title'; }
  }

  var HELD = {};
  function refreshHeld() { S.held.x = (HELD.right ? 1 : 0) - (HELD.left ? 1 : 0); S.held.y = (HELD.down ? 1 : 0) - (HELD.up ? 1 : 0); }
  var KEYMAP = {
    ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down',
    a: 'left', d: 'right', w: 'up', s: 'down', A: 'left', D: 'right', W: 'up', S: 'down',
    z: 'ok', Z: 'ok', Enter: 'ok', ' ': 'ok', x: 'back', X: 'back', Escape: 'back', Backspace: 'back',
    p: 'pause', P: 'pause', m: 'mute', M: 'mute',
  };

  /* ------------------------------------------------------------------------------- loop */
  var draw = true;
  function step(n) {
    n = n === undefined ? 1 : n;
    for (var i = 0; i < n; i++) {
      S.frames++;
      if (S.screen === 'plough' && !S.paused) stepPlough();
    }
    if (!draw) return;
    if (S.screen === 'title') drawTitle();
    else if (S.screen === 'yard') drawYard();
    else if (S.screen === 'plough') drawPloughScreen();
    else if (S.screen === 'result') drawResult();
    else if (S.screen === 'reveal') drawReveal();
    else if (S.screen === 'ending') drawEnding();
    else if (S.screen === 'credits') drawCredits();
    if (ctx) paint();
  }
  /* ⛔ REVIEW DEFECT 4: this was step(1) per animation frame, so a 120/144 Hz screen drove the plough 2-2.4x
   * faster. The simulation now runs on a fixed 60 Hz clock, stepped as many times as real time asks
   * (capped, so a tab returning from the background does not fast-forward a whole job). */
  var STEP_MS = 1000 / 60, acc = 0, lastT = null;
  function frame(t) {
    if (lastT === null) lastT = t;
    acc += Math.min(250, t - lastT); lastT = t;
    var n = 0;
    while (acc >= STEP_MS && n < 4) { acc -= STEP_MS; n++; }
    if (n) step(n);
    root.requestAnimationFrame(frame);
  }

  function boot() {
    cv = root.document.getElementById('screen');
    ctx = cv.getContext('2d'); ctx.imageSmoothingEnabled = false;
    img = ctx.createImageData(W, H); data = img.data;
    loadTitle();
    root.addEventListener('keydown', function (e) {
      var k = KEYMAP[e.key]; if (!k) return;
      if (e.key === 'Tab') return;
      e.preventDefault();
      if (k === 'left' || k === 'right' || k === 'up' || k === 'down') {
        var was = HELD[k]; HELD[k] = true; refreshHeld();
        if (!was && S.screen !== 'plough') press(k);
      } else if (!e.repeat) press(k);
    });
    root.addEventListener('keyup', function (e) { var k = KEYMAP[e.key]; if (k && HELD[k]) { HELD[k] = false; refreshHeld(); } });
    root.addEventListener('blur', function () { HELD = {}; refreshHeld(); });
    // touch: drag from where you put your finger down to hold a direction; a quick tap confirms
    var origin = null;
    cv.addEventListener('touchstart', function (e) { e.preventDefault(); origin = { x: e.touches[0].clientX, y: e.touches[0].clientY, t: Date.now() }; if (SND) SND.unlock(); }, { passive: false });
    /* ⛔ REVIEW DEFECTS 1 (BLOCKING) + 2: touch used to hold exactly one of four directions, which left some
     * diagonal streets undrivable on a phone, and its origin never moved, so a turn needed a drag longer than
     * the last one. It is now an ANALOG stick on a LEASH: the held vector is the drag direction itself, and
     * the origin trails the finger at a fixed radius, so a short flick in any direction turns. */
    var LEASH = 28, DEAD = 10;
    cv.addEventListener('touchmove', function (e) {
      e.preventDefault(); if (!origin) return;
      var cx = e.touches[0].clientX, cy = e.touches[0].clientY;
      var dx = cx - origin.x, dy = cy - origin.y, len = Math.hypot(dx, dy);
      if (len > LEASH) { origin.x = cx - dx / len * LEASH; origin.y = cy - dy / len * LEASH; origin.moved = true; }
      if (len < DEAD) return;
      origin.moved = true;
      if (S.screen === 'plough') { S.held.x = dx / len; S.held.y = dy / len; return; }
      var k = Math.abs(dx) > Math.abs(dy) ? (dx < 0 ? 'left' : 'right') : (dy < 0 ? 'up' : 'down');
      press(k); origin = { x: cx, y: cy, t: Date.now(), moved: true };
    }, { passive: false });
    cv.addEventListener('touchend', function (e) {
      e.preventDefault();
      var quick = origin && !origin.moved && Date.now() - origin.t < 300;
      HELD = {}; refreshHeld(); origin = null; if (quick) press('ok');
    }, { passive: false });
    // the page's own buttons (Z / X / P / M) — the touch player's way to pause, give up, mute and see the lesson
    root.__npPress = function (k) { press(k); };
    root.__npTick = function (n) { step(n || 1); };
    if (/[?&]harness=1\b/.test(root.location.search)) { step(1); return; }
    step(1);
    root.requestAnimationFrame(frame);
  }

  root.PLOUGH = {
    step: step, setDraw: function (v) { draw = !!v; }, press: press,
    hold: function (x, y) { S.held.x = x; S.held.y = y; },
    state: S, plane: plane, beginRun: beginRun, village: village, endingPages: endingPages, medalFor: medalFor,
    titleState: function () { return titleState; },
    get frames() { return S.frames; }, version: '1.0.0',
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.PLOUGH;
  else if (root.document) { if (root.document.readyState === 'loading') root.addEventListener('DOMContentLoaded', boot); else boot(); }
}(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this)));
