/**
 * village.js — NIGHT PLOUGH. The villages (street graphs) and the proved-cheapest ploughing route.
 * Pure: no drawing, no input. The game, the store copy's numbers and every bot use THIS file.
 *
 * A village is a connected graph of junctions (nodes, screen coordinates) and streets (edges, with a
 * length). The plough must drive EVERY street at least once and end at the depot. The cheapest such
 * route = total street length + a MINIMUM-WEIGHT PERFECT MATCHING of the odd junctions over
 * shortest-path distances (route inspection / Chinese Postman). That extra is the unavoidable
 * "deadhead"; anything above it is the player's own waste.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.VILLAGE = api;
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  function rng(seed) { let s = (seed >>> 0) || 1; return function () { s ^= s << 13; s >>>= 0; s ^= s >> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; }; }

  /* ⛔ REVIEW DEFECT 5 (2026-09-22): the old AREA (10..150 x 22..136) plus ±7 jitter and the LANES shear put
   * junctions, kerbs and the depot shed off the bottom and side of the 160x144 screen — the finish line was
   * half off-screen in every capture. The area is now inset and every junction is CLAMPED into SAFE, so a
   * road (half-width 3) plus its kerb, and the shed drawn above the depot, always stay on screen and clear
   * of the 12-row HUD band. */
  const AREA = { x0: 16, x1: 144, y0: 26, y1: 124 };
  const SAFE = { x0: 8, x1: 151, y0: 19, y1: 128 };
  const MAX_ODD = 16;

  function connected(n, edges) {
    if (!n) return true;
    const adj = Array.from({ length: n }, () => []);
    for (const e of edges) { adj[e.a].push(e.b); adj[e.b].push(e.a); }
    const seen = new Uint8Array(n); const st = [0]; seen[0] = 1; let c = 1;
    while (st.length) { const u = st.pop(); for (const v of adj[u]) if (!seen[v]) { seen[v] = 1; c++; st.push(v); } }
    return c === n;
  }

  /** A village from its SPEC ({ seed, style } — the content files carry the specs, so the paid
   *  villages are data the free build does not load, wing §1-DEMO). A bare number n means the
   *  screened default spec { seed: n, style: STYLES[n % 4] }, which is what the candidate screen ran. */
  const STYLES = ['GRID', 'CROSS', 'LANES', 'RIVER'];
  const cache = {};
  function generate(spec) {
    if (typeof spec === 'number') spec = { seed: spec, style: STYLES[spec % 4] };
    const key = spec.seed + ':' + spec.style;
    if (cache[key]) return cache[key];
    const v = build(spec.seed, spec.style);
    v.name = spec.name || ('VILLAGE ' + (spec.seed + 1));
    v.id = spec.id;
    cache[key] = v;
    return v;
  }
  function build(i, style) {
    const r = rng(0x9e110000 + i * 7919 + 1);
    const cols = 4 + Math.floor(r() * 3), rows = 3 + Math.floor(r() * 2);
    const nodes = [];
    const gx = (AREA.x1 - AREA.x0) / (cols - 1), gy = (AREA.y1 - AREA.y0) / (rows - 1);
    const shear = style === 'LANES' ? (r() - 0.5) * 0.5 : 0;
    for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) {
      const jit = style === 'GRID' ? 3 : 7;
      nodes.push({ x: AREA.x0 + x * gx + (r() - 0.5) * jit * 2 + shear * (y - rows / 2) * gy, y: AREA.y0 + y * gy + (r() - 0.5) * jit * 2 + (style === 'LANES' ? Math.sin(x * 1.3 + i) * 5 : 0), gx: x, gy: y });
    }
    for (const n of nodes) { n.x = Math.max(SAFE.x0, Math.min(SAFE.x1, n.x)); n.y = Math.max(SAFE.y0, Math.min(SAFE.y1, n.y)); }
    const id = (x, y) => y * cols + x;
    let edges = [];
    for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) {
      if (x + 1 < cols) edges.push({ a: id(x, y), b: id(x + 1, y) });
      if (y + 1 < rows) edges.push({ a: id(x, y), b: id(x, y + 1) });
    }
    // diagonals: CROSS villages have a market square with lanes cutting across
    if (style === 'CROSS') {
      const nd = 2 + Math.floor(r() * 3);
      for (let k = 0; k < nd; k++) {
        const x = Math.floor(r() * (cols - 1)), y = Math.floor(r() * (rows - 1));
        const e = r() < 0.5 ? { a: id(x, y), b: id(x + 1, y + 1) } : { a: id(x + 1, y), b: id(x, y + 1) };
        const cell = x + ',' + y;
        if (!edges.some((q) => q.cell === cell)) { e.cell = cell; edges.push(e); }
      }
    }
    // RIVER: a river runs down one column gap; only a few bridges cross it
    let river = null;
    if (style === 'RIVER') {
      const gc = 1 + Math.floor(r() * (cols - 2));
      river = { between: gc, x: (nodes[id(gc - 1, 0)].x + nodes[id(gc, 0)].x) / 2 };
      const crossing = edges.filter((e) => Math.min(nodes[e.a].gx, nodes[e.b].gx) === gc - 1 && Math.max(nodes[e.a].gx, nodes[e.b].gx) === gc && nodes[e.a].gy === nodes[e.b].gy);
      const keep = new Set();
      while (keep.size < 2) keep.add(Math.floor(r() * crossing.length));
      edges = edges.filter((e) => !crossing.includes(e) || keep.has(crossing.indexOf(e)));
      for (const k of keep) crossing[k].bridge = true;
    }
    // close some streets (a churchyard, a green, a farmyard), never disconnecting the village
    const target = Math.floor(edges.length * (0.12 + r() * 0.18));
    let removed = 0;
    for (let tries = 0; tries < 200 && removed < target; tries++) {
      const k = Math.floor(r() * edges.length);
      if (edges[k].bridge) continue;
      const trial = edges.slice(0, k).concat(edges.slice(k + 1));
      if (connected(nodes.length, trial)) { edges = trial; removed++; }
    }
    for (const e of edges) e.len = Math.hypot(nodes[e.a].x - nodes[e.b].x, nodes[e.a].y - nodes[e.b].y);
    const deg = new Array(nodes.length).fill(0);
    for (const e of edges) { deg[e.a]++; deg[e.b]++; }
    // the depot: the bottom-left junction
    const depot = id(0, rows - 1);
    return { i: i, style: style, nodes: nodes, edges: edges, deg: deg, depot: depot, river: river, cols: cols, rows: rows };
  }

  /** All-pairs shortest path (Floyd–Warshall; villages are small). */
  function apsp(v) {
    const n = v.nodes.length, D = [], NX = [];
    for (let a = 0; a < n; a++) { D.push(new Float64Array(n).fill(Infinity)); NX.push(new Int32Array(n).fill(-1)); D[a][a] = 0; NX[a][a] = a; }
    for (const e of v.edges) { if (e.len < D[e.a][e.b]) { D[e.a][e.b] = D[e.b][e.a] = e.len; NX[e.a][e.b] = e.b; NX[e.b][e.a] = e.a; } }
    for (let k = 0; k < n; k++) for (let a = 0; a < n; a++) { const dak = D[a][k]; if (dak === Infinity) continue; for (let b = 0; b < n; b++) { const nd = dak + D[k][b]; if (nd < D[a][b]) { D[a][b] = nd; NX[a][b] = NX[a][k]; } } }
    return { D: D, NX: NX };
  }

  /** The proved-cheapest closed route: { total, streets, deadhead, odd, pairs }. */
  function optimum(v) {
    if (v._opt) return v._opt;
    const P = apsp(v);
    const odd = [];
    v.deg.forEach((d, k) => { if (d % 2) odd.push(k); });
    if (odd.length > MAX_ODD) throw new Error('village ' + v.i + ': ' + odd.length + ' odd junctions > ' + MAX_ODD);
    const m = odd.length, FULL = (1 << m) - 1;
    const dp = new Float64Array(1 << m).fill(Infinity), pick = new Int32Array(1 << m).fill(-1);
    dp[0] = 0;
    for (let mask = 0; mask < (1 << m); mask++) {
      if (dp[mask] === Infinity) continue;
      let a = 0; while (a < m && (mask & (1 << a))) a++;
      if (a >= m) continue;
      for (let b = a + 1; b < m; b++) if (!(mask & (1 << b))) {
        const nm = mask | (1 << a) | (1 << b), c = dp[mask] + P.D[odd[a]][odd[b]];
        if (c < dp[nm]) { dp[nm] = c; pick[nm] = (a << 8) | b; }
      }
    }
    const pairs = []; let mask = FULL;
    while (mask) { const p = pick[mask]; const a = p >> 8, b = p & 255; pairs.push([odd[a], odd[b]]); mask &= ~((1 << a) | (1 << b)); }
    const streets = v.edges.reduce((s, e) => s + e.len, 0);
    v._opt = { total: streets + dp[FULL], streets: streets, deadhead: dp[FULL], odd: m, pairs: pairs, P: P };
    return v._opt;
  }

  return { AREA: AREA, SAFE: SAFE, STYLES: STYLES, generate: generate, optimum: optimum, apsp: apsp, connected: connected, COUNT: 40 };
}));
