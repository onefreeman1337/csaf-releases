# MAKE YOUR NUMBER

**A deduction game whose every case is generated, and then proven, before you ever see it.** Free,
in your browser, no account, no install.

You keep a lighthouse on a bad coast. Six vessels pass in the dark and each one is hiding what she
is. You learn what you learn from **where you point the lamp**, because the beam lights one arc at a
time and the haar takes the rest.

*Make your number* is what a ship does when she identifies herself by hoisting her code letters.
Your job is to make theirs.

---

## The loop, in full

A night is a set of berths — first through sixth — and a set of categories: **rig**, **cargo**,
**home port**, and the two flag **number** she flies. Every category is a permutation across the
berths, so exactly one vessel is the barque, exactly one is carrying salt, exactly one is out of
Whitby.

You have a fixed number of **sweeps**. Train the lamp on a bearing, sweep it, and whatever is out
there on that bearing writes you one line in the log: *"the one carrying lime was the ketch"*,
*"there were three vessels between the Appledore boat and the vessel flying QH."*

The bearing board under the water tells you **which** bearings are holding something. It never tells
you what. Point the lamp at an empty bearing and you have spent a sweep for nothing.

When the sweeps are gone you name every berth and hand the log in.

## What the game promises you, and how it is enforced

Three things, and every one of them is proved by machine before a night is dealt:

1. **Exactly one answer.** The generator draws a solution, builds the full clue pool, and refuses
   the night unless the solver reads back exactly one reading. There is never a second answer that
   also fits.
2. **No guessing, ever.** A night must be closable by **elimination alone** — pure constraint
   propagation, no case splitting. Anything that would need you to assume something and check it
   later is rejected outright.
3. **Every clue is load bearing.** After the night qualifies, clues are stripped away one at a time
   for as long as it still qualifies. Nothing you are given is decoration.

The store page's third image is not a claim about this. It is the output of it: the generator and
the solver are re-run while that picture is being built, and the numbers printed on it are whatever
came back.

## The second system: the lamp decides which evidence you get

Difficulty here is not a timer and it is not a bigger grid. **It is how much evidence has been
withheld, and where the lamp lets you go looking for it.** The generator minimises a night until it
sits on the edge of solvable; the lamp then decides which of that minimal set you actually collect.
A hard night is one where pointing the lamp wrong costs you the only observation that could have
closed the case.

The **haar** can take an observation before you read it. It never destroys one — it moves it to
another bearing, and it is still out there.

## The lantern room

Five fittings, bought with what the Board pays you, and every one changes **which** evidence is
reachable rather than how fast you can act:

| fitting | what it does |
| --- | --- |
| A catadioptric lens | the beam lights the sector either side of the one you train it on |
| A mercury bath | one more sweep every night |
| A fog signal | the first observation of a night can never be taken by the haar |
| A tide table | one vessel's berth is known before the first sweep |
| A better glass | every bearing shows how many observations it is holding |

## Losing, and never starting over

A wrong name costs you **the night, never the run.** You keep what the Board paid you and every
fitting in the lantern room, and a fresh night takes its place.

Close the tab whenever you like. A night is rebuilt from its seed, which is pure, and your
observations are replayed onto it — so nothing is lost and nothing has to be repeated.

## Controls

- **Click a bearing**, or **left / right arrow**, to train the lamp.
- **Sweep** to spend one sweep on the bearing you are trained on.
- **The log** (or **L**, or **Tab**) to open the grid. **Click a cell** to rule it out,
  **right click** to pin one.
- **Call it** when you are ready to name the berths.
- **M** mutes.

## What the log actually is

The grid you rule cells out in is **the same grid the solver uses**. That is deliberate, and it is
why the two promises above are honest: if a night needed a technique the grid cannot express, the
game would be asking you to do something it has given you no tool for, so such nights are refused
rather than balanced around.

---

Made by **Core Systems Asset Factory**. Free, and free to stream. See LICENSE.txt for the full
terms and for a complete statement of what is in the package.
