/* MAKE YOUR NUMBER — game.js : the watch, the log, and the lantern room.
 *
 * The two systems the complexity floor asked for are already built and proven headless
 * (`case.js` + `gen.js` = the generator and its uniqueness proof, `sim.js` = the lamp). This file
 * is the part the player touches, and it holds exactly one design rule of its own:
 *
 * ⛔ THE PICTURE MAY NEVER SAY SOMETHING THE EVIDENCE DOES NOT. A deduction game whose art implies
 *    a fact the log cannot justify is unfair in the one way a player can never argue with. So a
 *    sector holding an unseen observation shows an INDISTINCT shape — a smudge on the water — and
 *    when the beam takes it, the vessel is drawn with its true rig ONLY when the observation is
 *    actually about a rig. Otherwise it stays a dark hull. The identifiable silhouettes live in the
 *    LOG, next to their row, where "this is what a barque looks like" is information rather than a
 *    claim about tonight.
 *    ⚠️ B7 INPUT WELCOME (recorded in the devlog): the alternative was to draw a random identifiable
 *    rig for atmosphere. It looks better and it lies, so it was refused.
 *
 * ⛔ SAVE ON EVERY ACTION (ledger B4). A night you fail is a night, never the run: the lantern room
 *    keeps every upgrade and the next night is a fresh case. Closing the tab costs nothing.
 */
(function (root) {
  'use strict';

  var SIM = root.MYNSIM, CASE = root.MYNCASE, WORDS = root.MYNWORDS, A = root.ART;
  var W = 960, H = 640;
  var SAVE_KEY = 'myn.save.v1';

  /* the seaward arc the lamp can be trained across */
  var BEARINGS = ['SW', 'WSW', 'W', 'WNW', 'NW', 'NNW', 'N', 'NNE'];
  var ARC = 150 * Math.PI / 180;                 // total span of the eight sectors
  var LAMP = { x: W / 2, y: 396 };
  var COAST = { x: 0, y: 62, w: W, h: 334 };
  var HORIZON = COAST.y + 168;

  var S = {
    screen: 'title',
    keeper: null,
    night: null,
    words: null,
    beam: 0,                 // the angle the lamp is actually pointing, animated
    target: 0,               // the angle it is turning toward
    bearing: 0,              // the sector currently selected
    flash: 0,                // brightness kick when a sweep fires
    slips: [],               // the observations of the last sweep, for the watch screen
    logScroll: 0,
    message: '',
    t: 0,
    seed: 0
  };

  /* ------------------------------------------------------------------ persistence */

  function save() {
    try {
      var d = {
        keeper: S.keeper,
        index: S.night ? S.night.index : 0,
        seed: S.seed,
        /* the grid is the player's reasoning and must survive a closed tab */
        grid: S.night && S.night.phase !== 'won' && S.night.phase !== 'lost' ? S.night.grid : null,
        obs: S.night ? S.night.obs.map(function (o) { return { id: o.id, sector: o.sector, seen: o.seen, fogged: o.fogged }; }) : null,
        sweepsLeft: S.night ? S.night.sweepsLeft : 0,
        phase: S.night ? S.night.phase : null
      };
      localStorage.setItem(SAVE_KEY, JSON.stringify(d));
    } catch (e) { /* a blocked localStorage must never break the game */ }
  }
  function loadSave() {
    try {
      var raw = localStorage.getItem(SAVE_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e) { return null; }
  }
  function clearSave() { try { localStorage.removeItem(SAVE_KEY); } catch (e) {} }

  /* ------------------------------------------------------------------ starting things */

  function beginNight(index, seed) {
    S.seed = seed === undefined ? ((Date.now() ^ (index * 7919)) >>> 0) : seed;
    S.night = SIM.startNight(S.keeper, index, S.seed);
    S.words = WORDS.service(S.night.spec);
    S.bearing = 0;
    S.target = angleOf(0);
    S.beam = S.target;
    S.slips = [];
    S.logScroll = 0;
    S.message = '';
    S.screen = 'watch';
    save();
  }

  function newRun() {
    S.keeper = SIM.newKeeper();
    clearSave();
    beginNight(0);
  }

  function resume(d) {
    S.keeper = d.keeper;
    S.night = SIM.startNight(S.keeper, d.index, d.seed);
    S.seed = d.seed;
    S.words = WORDS.service(S.night.spec);
    /* ⛔ REPLAY THE SAVED OBSERVATION STATE ONTO A FRESHLY GENERATED NIGHT. The night is a pure
     * function of (index, seed), so it regenerates identically; what cannot be regenerated is what
     * the player saw and what the fog moved, so that is what is stored. */
    if (d.obs) {
      for (var i = 0; i < d.obs.length; i++) {
        var src = d.obs[i];
        for (var j = 0; j < S.night.obs.length; j++) {
          if (S.night.obs[j].id === src.id) {
            S.night.obs[j].sector = src.sector;
            S.night.obs[j].seen = src.seen;
            S.night.obs[j].fogged = src.fogged;
          }
        }
      }
      S.night.log = S.night.obs.filter(function (o) { return o.seen; });
    }
    if (d.grid) S.night.grid = d.grid;
    if (typeof d.sweepsLeft === 'number') S.night.sweepsLeft = d.sweepsLeft;
    if (d.phase === 'naming') S.night.phase = 'naming';
    S.bearing = 0; S.target = angleOf(0); S.beam = S.target;
    S.slips = []; S.screen = 'watch'; S.message = '';
  }

  function angleOf(sector) { return -ARC / 2 + (sector + 0.5) * (ARC / SIM.SECTORS); }

  /* ------------------------------------------------------------------ actions */

  function doSweep() {
    var g = S.night;
    if (!g || g.phase !== 'watching') return;
    var r = SIM.sweep(g, S.bearing);
    if (!r.ok) { S.message = r.why; return; }
    S.flash = 1;
    S.slips = r.got.slice();
    S.message = r.got.length
      ? (r.got.length === 1 ? 'One thing in the beam.' : r.got.length + ' things in the beam.')
      : (r.fogged.length ? 'The haar took it. It is still out there.' : 'Nothing on that bearing.');
    if (r.fogged.length && r.got.length) S.message += ' The haar took ' + r.fogged.length + '.';
    play(r.got.length ? 'sight' : 'sweep');
    save();
  }

  function doName() {
    var g = S.night;
    if (!g) return;
    if (g.phase === 'watching') SIM.callIt(g);
    var res = SIM.name(g);
    if (res) {
      S.screen = 'result';
      play(res.perfect ? 'kept' : 'lost');
      save();
    }
  }

  function nextNight() {
    var g = S.night;
    var idx = g.result && g.result.perfect ? g.index + 1 : g.index;
    S.pendingIndex = idx;
    S.screen = 'room';
    save();
  }

  /* ------------------------------------------------------------------ audio
   * Procedural audio generated by `Kernel/capture/make_audio.js` — our own IP, no Gen-AI tag.
   * Rendered as WAV, shipped as OGG (Internal_Ops/to_ogg.js): 3.89 MB -> 0.39 MB, which matters
   * a great deal to a browser player on a phone.
   * ⚠️ Audio must never be able to break the game: every call is guarded.
   */
  var sounds = {}, muted = false;
  function loadAudio() {
    ['sweep', 'sight', 'mark', 'kept', 'lost', 'buy'].forEach(function (k) {
      try {
        var a = new Audio('audio/sfx_' + k + '.ogg');
        a.preload = 'auto'; a.volume = 0.5;
        sounds[k] = a;
      } catch (e) {}
    });
    try {
      var m = new Audio('audio/theme.ogg');
      m.loop = true; m.volume = 0.28;
      sounds.theme = m;
    } catch (e) {}
  }
  function play(k) {
    if (muted || !sounds[k]) return;
    try { sounds[k].currentTime = 0; var p = sounds[k].play(); if (p && p.catch) p.catch(function () {}); } catch (e) {}
  }
  function toggleMute() {
    muted = !muted;
    if (sounds.theme) { try { muted ? sounds.theme.pause() : sounds.theme.play().catch(function () {}); } catch (e) {} }
  }

  /* ================================================================== drawing */

  function frame(dt) {
    S.t += dt;
    /* the lamp turns; it does not teleport */
    var d = S.target - S.beam;
    S.beam += d * Math.min(1, dt * 7);
    S.flash = Math.max(0, S.flash - dt * 2.2);
    A.beginFrame();
    var c = A.ctx();
    c.clearRect(0, 0, W, H);
    if (S.screen === 'title') drawTitle();
    else if (S.screen === 'watch') drawWatch();
    else if (S.screen === 'log') drawLog();
    else if (S.screen === 'result') drawResult();
    else if (S.screen === 'room') drawRoom();
    else if (S.screen === 'help') drawHelp();
  }

  /* ------------------------------------------------------------------ the coast */

  function drawCoast(dim) {
    var c = A.ctx();
    c.save();
    c.beginPath(); c.rect(COAST.x, COAST.y, COAST.w, COAST.h); c.clip();

    A.plate('sky', COAST.x, COAST.y, COAST.w, HORIZON - COAST.y);
    A.plate('sea', COAST.x, HORIZON, COAST.w, COAST.y + COAST.h - HORIZON);
    /* the sea sinks into the dark as it comes toward the tower */
    A.wash(COAST.x, HORIZON, COAST.w, COAST.h - (HORIZON - COAST.y), 'rgba(4,7,13,0)', 'rgba(4,7,13,0.92)');
    /* the haar sits on the horizon and is the only pale thing out there */
    c.save();
    c.globalAlpha = 0.30 + 0.05 * Math.sin(S.t * 0.4);
    var g = c.createLinearGradient(0, HORIZON - 34, 0, HORIZON + 26);
    g.addColorStop(0, 'rgba(60,69,80,0)');
    g.addColorStop(0.45, 'rgba(105,115,127,1)');
    g.addColorStop(1, 'rgba(60,69,80,0)');
    c.globalCompositeOperation = 'source-over';
    c.fillStyle = g; c.fillRect(0, HORIZON - 34, W, 60);
    c.restore();
    A.plate('haar', 0, HORIZON - 30, W, 52, 0.16);
    A.line(0, HORIZON, W, HORIZON, 'rgba(105,115,127,0.35)', 1);

    if (!dim) drawBeam();
    drawSectorShapes();

    c.restore();
    /* the tower's own stonework frames the view */
    A.plate('granite', 0, 0, W, COAST.y);
    A.wash(0, 0, W, COAST.y, 'rgba(0,0,0,0.55)', 'rgba(0,0,0,0.15)');
    A.line(0, COAST.y - 1, W, COAST.y - 1, 'rgba(0,0,0,0.7)', 2);
  }

  /**
   * The beam. A warm wedge from the lamp, plus a soft bloom where it meets the water.
   *
   * ⛔ THE BEAM AND THE THINGS IT LIGHTS MUST USE ONE PROJECTION, AND FOR A LONG TIME THEY DID NOT.
   * `drawSectorShapes` puts a sector at `(sin θ · R, −cos θ · R · FLATTEN)` — the sea is seen at a
   * shallow angle, so bearings to the side land far out across the frame while staying near the
   * horizon. The wedge was drawn with a plain `arc()`, which is that same sweep with NO flattening.
   * Straight ahead the two agree, so it looked right; at SW they diverge badly, and the capture
   * showed a lit vessel sitting in open darkness under the caption "3 things in the beam". Nothing
   * could catch it — every number is correct, the lit set is correct, and the sector really was in
   * the beam. It is only wrong as a PICTURE, which is why §3c-10 says open the frame and look.
   *
   * The fix is not to nudge the wedge: it is to scale the canvas vertically about the lamp by the
   * same FLATTEN the shapes use, so one projection serves both and they cannot drift again.
   */
  var FLATTEN = 0.52;         // ⚠️ shared with drawSectorShapes — one constant, two consumers

  function drawBeam() {
    var c = A.ctx();
    var lit = SIM.sectorsLit(S.night, S.bearing);
    var half = (ARC / SIM.SECTORS) / 2;
    var spread = S.night.keeper.owned.lens ? half * 3 : half;
    var R = 620;
    var k = 0.55 + 0.45 * S.flash;

    c.save();
    c.globalCompositeOperation = 'lighter';
    /* project: everything below is drawn in the unflattened circle, then squashed onto the sea */
    c.translate(LAMP.x, LAMP.y);
    c.scale(1, FLATTEN);
    c.translate(-LAMP.x, -LAMP.y);
    var grad = c.createRadialGradient(LAMP.x, LAMP.y, 8, LAMP.x, LAMP.y, R);
    grad.addColorStop(0, 'rgba(244,220,166,' + (0.42 * k) + ')');
    grad.addColorStop(0.42, 'rgba(244,220,166,' + (0.17 * k) + ')');
    grad.addColorStop(1, 'rgba(244,220,166,0)');
    c.fillStyle = grad;
    c.beginPath();
    c.moveTo(LAMP.x, LAMP.y);
    /* the wedge is built as an arc so its far edge follows the horizon rather than cutting it */
    c.arc(LAMP.x, LAMP.y, R, -Math.PI / 2 + S.beam - spread, -Math.PI / 2 + S.beam + spread);
    c.closePath();
    c.fill();
    c.restore();
    return lit;
  }

  /**
   * What is out there. ⛔ An unseen observation is a SMUDGE — never an identifiable vessel, because
   * the picture may not claim a fact the log cannot justify. Once the beam has taken it, the shape
   * is drawn with its real rig only when the observation is actually about a rig.
   */
  function drawSectorShapes() {
    var g = S.night;
    if (!g) return;
    var c = A.ctx();
    var lit = SIM.sectorsLit(g, S.bearing);
    for (var s = 0; s < SIM.SECTORS; s++) {
      var n = SIM.holding(g, s);
      var seenHere = g.log.filter(function (o) { return o.sector === s; });
      if (!n && !seenHere.length) continue;
      var ang = angleOf(s);
      var R = 232;
      var x = LAMP.x + Math.sin(ang) * R;
      /* ⚠️ THE SAME FLATTEN THE BEAM USES. Two copies of this number is how the beam and the things
         it lights drifted apart in the first place — one declaration, two consumers. */
      var y = LAMP.y - Math.cos(ang) * R * FLATTEN;
      var inBeam = lit.indexOf(s) >= 0;

      if (n) {
        /* something out there, and deliberately unreadable */
        c.save();
        c.globalAlpha = inBeam ? 0.55 : 0.30;
        c.fillStyle = inBeam ? '#59636f' : '#2f3741';
        c.beginPath();
        c.ellipse(x, y, 26 + n * 3, 7, 0, 0, Math.PI * 2);
        c.fill();
        c.globalAlpha = inBeam ? 0.42 : 0.20;
        c.fillRect(x - 2, y - 16, 3, 16);
        c.restore();
      } else if (seenHere.length) {
        /* already read — the rig is drawn only when the evidence was about a rig */
        var rig = rigOf(seenHere[0]);
        c.save();
        c.globalAlpha = 0.55;
        if (rig) A.vessel(rig, x - 34, y - 40, 68, inBeam);
        else {
          c.fillStyle = '#232a33';
          c.beginPath(); c.ellipse(x, y, 24, 6, 0, 0, Math.PI * 2); c.fill();
        }
        c.restore();
      }
    }
  }

  /** The rig an observation genuinely names, or null. */
  /* ⚠️ `spec.cats` HOLDS CATEGORY OBJECTS, NOT IDS, and its `values` are already sliced to tonight's
   * berth count — so both halves of this read the spec rather than the global category table. The
   * id-comparison version silently returned null for every clue (never a crash, just no vessel ever
   * drawn), which is the quietest possible way for this to be wrong. */
  function rigOf(o) {
    var k = o.clue, cats = S.night.spec.cats;
    var sides = [k.a, k.b].filter(function (z) { return z && typeof z === 'object' && typeof z.c === 'number'; });
    for (var i = 0; i < sides.length; i++) {
      var cat = cats[sides[i].c];
      if (cat && cat.id === 'rig') return cat.values[sides[i].v] || null;
    }
    return null;
  }

  /* ------------------------------------------------------------------ THE WATCH */

  function drawWatch() {
    var g = S.night;
    drawCoast(false);

    /* header */
    A.text(g.title, 22, 40, { size: 21, fill: A.INK.lamp, track: 2.4 });
    A.text('NIGHT ' + (g.index + 1), W - 22, 26, { size: 12, align: 'right', fill: A.INK.cold, track: 2 });
    A.text(g.sweepsLeft + (g.sweepsLeft === 1 ? ' SWEEP LEFT' : ' SWEEPS LEFT'), W - 22, 46,
      { size: 15, align: 'right', fill: g.sweepsLeft <= 2 ? '#c98b6a' : A.INK.lamp, track: 1.6 });

    drawCompass();

    /* the slips: what the last sweep gave you */
    var y = 486;
    A.plate('leaf', 0, 466, W, H - 466);
    A.wash(0, 466, W, H - 466, 'rgba(36,26,17,0.30)', 'rgba(36,26,17,0.05)');
    A.line(0, 466, W, 466, 'rgba(0,0,0,0.5)', 2);

    if (S.message) A.text(S.message, 24, y, { size: 15, fill: A.INK.inkSoft });
    y += 22;
    if (S.slips.length) {
      for (var i = 0; i < Math.min(2, S.slips.length); i++) {
        y += A.paragraph('"' + WORDS.clueText(S.slips[i].clue, S.words) + '"', 24, y, W - 300, { size: 16 }) + 4;
      }
    } else if (!S.message) {
      A.text('Train the lamp on a bearing, then sweep it.', 24, y, { size: 15, fill: A.INK.inkFaint });
    }

    /* controls */
    var bw = 132, bh = 40, by = H - 54;
    A.button('SWEEP', 24, by, bw, bh, { id: 'sweep', enabled: g.phase === 'watching' && g.sweepsLeft > 0 });
    A.button('THE LOG', 24 + bw + 12, by, bw, bh, { id: 'log' });
    A.button(g.phase === 'watching' ? 'CALL IT' : 'NAME THEM', 24 + (bw + 12) * 2, by, bw + 20, bh,
      { id: 'name', plateName: 'brass' });
    A.button(muted ? 'SOUND OFF' : 'SOUND ON', W - 24 - 118, by, 118, bh, { id: 'mute', size: 12 });

    /* how many observations are still out there — never which */
    var out = g.obs.filter(function (o) { return !o.seen; }).length;
    /* ⚠️ inkFaint on the mottled leaf plate was effectively unreadable in the capture — the two
       live numbers a keeper actually plans with, drawn at the contrast of a watermark. */
    A.text(out + ' still out there  ·  ' + g.log.length + ' in the log', W - 24, by - 16,
      { size: 13, align: 'right', fill: A.INK.inkSoft });
  }

  /** The eight bearings, with whether each is holding anything. */
  function drawCompass() {
    var g = S.night;
    var c2 = A.ctx();
    var y = COAST.y + COAST.h + 4, h = 62;
    A.plate('brass', 0, y, W, h, 0.9);
    A.wash(0, y, W, h, 'rgba(0,0,0,0.45)', 'rgba(0,0,0,0.15)');
    var cw = W / SIM.SECTORS;
    var lit = SIM.sectorsLit(g, S.bearing);
    for (var s = 0; s < SIM.SECTORS; s++) {
      var x = s * cw;
      var on = s === S.bearing, inBeam = lit.indexOf(s) >= 0;
      if (inBeam) { A.rect(x, y, cw, h, on ? 'rgba(244,220,166,0.22)' : 'rgba(244,220,166,0.10)'); }
      A.line(x, y, x, y + h, 'rgba(0,0,0,0.45)', 1);
      A.text(BEARINGS[s], x + cw / 2, y + 24, {
        size: 16, align: 'center', track: 2,
        fill: on ? A.INK.lampHot : (inBeam ? A.INK.lamp : 'rgba(244,220,166,0.55)')
      });
      /* ⛔ THIS ROW USED TO SPELL THE WORD "something" UNDER EVERY BEARING THAT HELD ANYTHING —
       * six or seven times across the width of the main screen, which read as placeholder text on
       * the one picture most players will ever see of this game. The INFORMATION was right and is
       * unchanged; the typography was the defect. A bearing board is marked, not captioned, so a
       * sector holding evidence now carries LAMPS: one when all you know is that something is out
       * there, and one per sighting once A BETTER GLASS is bought. That makes the fitting's value
       * legible at a glance instead of describing it — the same reason the reveal screen draws the
       * ships rather than naming them. */
      var n = SIM.holding(g, s);
      var swept = g.log.some(function (o) { return o.sector === s; });
      var cx = x + cw / 2, my = y + 42;
      if (!n) {
        A.text(swept ? 'read' : '—', cx, y + 45,
          { size: 12, align: 'center', fill: 'rgba(244,220,166,0.30)' });
      } else {
        var glass = g.keeper.owned.glass;
        var marks = glass ? Math.min(5, n) : 1;
        var r = 3.2, span = marks * r * 2 + (marks - 1) * 4;
        var mx = cx - span / 2 + r;
        c2.save();
        for (var mI = 0; mI < marks; mI++) {
          c2.beginPath(); c2.arc(mx, my, r, 0, Math.PI * 2);
          c2.fillStyle = inBeam ? A.INK.lampHot : A.INK.lamp;
          c2.fill();
          if (inBeam) {
            c2.beginPath(); c2.arc(mx, my, r + 2.4, 0, Math.PI * 2);
            c2.strokeStyle = 'rgba(244,220,166,0.35)'; c2.lineWidth = 1; c2.stroke();
          }
          mx += r * 2 + 4;
        }
        c2.restore();
        A._artRect('holding:' + s, cx - span / 2, my - r, span, r * 2);
        /* the glass can see more than five; say so rather than lie by omission */
        if (glass && n > 5) {
          A.text('+' + (n - 5), cx + span / 2 + 9, my + 4,
            { size: 11, align: 'center', fill: A.INK.lamp });
        }
      }
      A.zone('bearing', x, y, cw, h, s);
    }
  }

  /* ------------------------------------------------------------------ THE LOG */

  function drawLog() {
    var g = S.night;
    A.plate('leaf', 0, 0, W, H);
    A.wash(0, 0, W, H, 'rgba(36,26,17,0.22)', 'rgba(36,26,17,0.06)');

    A.text('THE LOG', 24, 38, { size: 20, track: 3, fill: A.INK.ink });
    A.text(g.title, W - 24, 38, { size: 15, align: 'right', fill: A.INK.inkSoft, track: 1.2 });
    A.line(24, 50, W - 24, 50, A.INK.rule, 1);

    var gridX = 24, gridW = 604;
    var obsX = gridX + gridW + 24;
    drawGrid(gridX, 64, gridW, H - 64 - 62);
    drawObservations(obsX, 64, W - obsX - 24, H - 64 - 62);

    var bw = 150, bh = 40, by = H - 50;
    A.button('THE WATCH', 24, by, bw, bh, { id: 'watch', plateName: 'brass' });
    A.button('NAME THEM', 24 + bw + 12, by, bw, bh, { id: 'name', plateName: 'brass' });
    A.text('Click a cell to rule it out. Right-click to pin it.', 24 + (bw + 12) * 2 + 10, by + 25,
      { size: 13, fill: A.INK.inkFaint });
  }

  /**
   * ⛔ EVERY DIMENSION HERE IS DERIVED. A night is 4, 5 or 6 berths across 2, 3 or 4 categories, so
   * a typed row height is correct for exactly one of the eight nights.
   */
  function drawGrid(x, y, w, h) {
    var g = S.night, n = g.spec.n, cats = g.spec.cats;
    var labelW = Math.round(w * 0.32);
    var colW = (w - labelW) / n;
    var rows = cats.length * (n + 1);
    var rowH = Math.max(13, Math.min(30, Math.floor((h - 26) / rows)));
    var fs = Math.max(10, Math.min(15, Math.round(rowH * 0.66)));

    /* berth headings */
    for (var b = 0; b < n; b++) {
      A.text(S.words.ordinal(b).toUpperCase(), x + labelW + colW * (b + 0.5), y + 14,
        { size: Math.min(12, fs), align: 'center', fill: A.INK.inkSoft, track: 1 });
    }
    A.line(x, y + 20, x + labelW + colW * n, y + 20, A.INK.rule, 1);

    var cy = y + 24;
    for (var c = 0; c < cats.length; c++) {
      A.text(S.words.catLabel(c), x + 2, cy + rowH * 0.72, { size: fs, track: 1.6, fill: A.INK.ink });
      cy += rowH;
      for (var v = 0; v < n; v++) {
        drawGridRow(c, v, x, cy, labelW, colW, rowH, fs, n);
        cy += rowH;
      }
      A.line(x, cy - 1, x + labelW + colW * n, cy - 1, 'rgba(156,135,99,0.55)', 1);
    }
  }

  function drawGridRow(c, v, x, cy, labelW, colW, rowH, fs, n) {
    var g = S.night;
    var id = S.words.catId(c);
    var tx = x + 4;

    /* ⭐ THE ROW LABELS ARE THE ART, AND HERE IT IS INFORMATION RATHER THAN A CLAIM: a rig row shows
     * what that rig looks like, and a NUMBER row shows the actual two-flag hoist it is named for —
     * which is what "make your number" means. */
    if (id === 'rig') {
      /* ⛔ SIZE THE SILHOUETTE FROM THE ROW, NOT FROM THE COLUMN. This took its width from the label
       * column and let `vessel()` derive the height from the sheet's aspect — so on the six-berth
       * night, where rows are 17px, every vessel was drawn 34px tall and the eight of them piled
       * into one unreadable black mass that also swallowed the CARGO heading underneath. The row is
       * the binding dimension; the width follows from it. Every string still fitted perfectly, so
       * the layout gate was clean — it records TEXT and this is art. */
      var vh = Math.max(6, rowH - 3);
      var vw = Math.min(labelW * 0.42, vh * (112 / 84));
      A.vessel(g.spec.cats[c].values[v], tx, cy + 1, vw, false);
      tx += vw + 6;
    } else if (id === 'number') {
      var hh = Math.max(7, rowH - 6);
      tx += A.hoist(S.words.hoist(c, v), tx, cy + 3, hh, 2) + 6;
    }
    A.text(S.words.short(c, v), tx, cy + rowH * 0.74, { size: fs, fill: A.INK.inkSoft });

    for (var b = 0; b < n; b++) {
      var bx = x + labelW + colW * b, by = cy;
      A.line(bx, by, bx, by + rowH, 'rgba(156,135,99,0.40)', 1);
      var possible = g.grid[c][v][b];
      var only = possible && CASE.berthsFor(g.grid, c, v).length === 1;
      drawMark(bx + colW / 2, by + rowH / 2, Math.min(rowH, colW) * 0.34, possible, only);
      A.zone('cell', bx, by, colW, rowH, { c: c, v: v, b: b });
    }
    A.line(x + labelW + colW * n, cy, x + labelW + colW * n, cy + rowH, 'rgba(156,135,99,0.40)', 1);
  }

  function drawMark(cx, cy, r, possible, only) {
    var c = A.ctx();
    if (only) {
      c.save();
      c.strokeStyle = A.INK.pinned; c.lineWidth = Math.max(1.6, r * 0.34); c.lineCap = 'round';
      c.beginPath();
      c.moveTo(cx - r, cy); c.lineTo(cx - r * 0.25, cy + r * 0.7); c.lineTo(cx + r, cy - r * 0.8);
      c.stroke(); c.restore();
    } else if (!possible) {
      c.save();
      c.strokeStyle = A.INK.struck; c.lineWidth = Math.max(1.2, r * 0.28); c.lineCap = 'round';
      c.beginPath();
      c.moveTo(cx - r * 0.72, cy - r * 0.72); c.lineTo(cx + r * 0.72, cy + r * 0.72);
      c.moveTo(cx + r * 0.72, cy - r * 0.72); c.lineTo(cx - r * 0.72, cy + r * 0.72);
      c.stroke(); c.restore();
    }
  }

  function drawObservations(x, y, w, h) {
    var g = S.night;
    A.text('WHAT YOU HAVE', x, y + 14, { size: 13, track: 2, fill: A.INK.ink });
    A.line(x, y + 20, x + w, y + 20, A.INK.rule, 1);
    var cy = y + 42;
    if (!g.log.length) {
      A.paragraph('Nothing yet. The lamp is the only way to get anything, and you have a limited number of turns of it.',
        x, cy, w, { size: 14, fill: A.INK.inkFaint });
      return;
    }
    /* ⛔ MEASURE THE ENTRY BEFORE STARTING IT, NOT AFTER. Checking only whether the CURSOR is still
     * in the box lets a three-line observation begin one line from the bottom and finish two lines
     * past it — which is how "…Whitby boat." came to be printed straight through the "+ 6 more"
     * marker. A wrapped block's height is knowable in advance, so ask. */
    var opts = { size: 14, fill: A.INK.inkSoft };
    var maxY = y + h - 8, moreH = 18;
    for (var i = S.logScroll; i < g.log.length; i++) {
      var t = (g.log[i].free ? '(the tide table)  ' : '') + WORDS.clueText(g.log[i].clue, S.words);
      var need = A.paragraphHeight(t, w, opts);
      var last = i === g.log.length - 1;
      if (cy + need > maxY - (last ? 0 : moreH)) {
        A.text('+ ' + (g.log.length - i) + ' more — scroll', x, maxY, { size: 12, fill: A.INK.inkFaint });
        break;
      }
      cy += A.paragraph(t, x, cy, w, opts) + 9;
    }
    A.zone('obsscroll', x, y, w, h);
  }

  /* ------------------------------------------------------------------ THE RESULT */

  function drawResult() {
    var g = S.night, r = g.result;
    drawCoast(true);
    A.plate('leaf', 0, 200, W, H - 200);
    A.wash(0, 200, W, H - 200, 'rgba(36,26,17,0.34)', 'rgba(36,26,17,0.05)');
    A.line(0, 200, W, 200, 'rgba(0,0,0,0.55)', 2);

    A.text(r.perfect ? 'THE WATCH IS KEPT' : 'THE LOG IS WRONG', W / 2, 130,
      { size: 32, align: 'center', track: 5, fill: r.perfect ? A.INK.lampHot : '#c98b6a' });
    A.text(g.title, W / 2, 162, { size: 15, align: 'center', track: 2, fill: A.INK.cold });

    var y = 250;
    A.text(r.right + ' right   ·   ' + r.wrong + ' wrong   ·   ' + r.blank + ' left open', W / 2, y,
      { size: 18, align: 'center', fill: A.INK.ink });
    y += 34;
    A.text('THE BOARD PAYS YOU ' + r.earned, W / 2, y, { size: 16, align: 'center', track: 2, fill: A.INK.inkSoft });
    y += 40;

    A.paragraph(r.perfect
      ? 'Every berth named correctly. The lantern room is open to you, and there is another night after this one.'
      : 'A keeper who names a vessel wrong has done worse than name none. You keep what the Board paid you, and you keep everything in the lantern room. The night itself is gone, and a fresh one takes its place.',
      W / 2 - 330, y, 660, { size: 15, fill: A.INK.inkSoft, align: 'center' });
    y += 74;

    /* ------------------------------------------------------------------ what it actually was
     * ⛔ THIS BLOCK WAS TEXT ONLY, ON THE ONE SCREEN THE PLAYER REACHES AT THE END OF EVERY NIGHT,
     * and the bottom third of the page was blank paper. A whole night is spent telling a barque
     * from a brig and one hoist of flags from another, and the reveal named them in words and
     * showed neither. So the art the deduction was ABOUT now appears at the moment it is resolved:
     * the silhouette that passed, lit, over the number she was flying, over what she was and where
     * she was from. Found by opening the capture and looking — every gate was clean, because a
     * screen can be 40% empty and still pass a density floor and a text-overlap check.
     *
     * ⚠️ Sized from the SPACE LEFT, not typed. A six-berth night has six columns and four rows in
     * the same box a four-berth night uses, and §3e-3's lesson is that clamping the container does
     * not make the contents fit — the row height and the silhouette both come out of the budget. */
    A.text('WHAT PASSED', W / 2, y, { size: 13, align: 'center', track: 2, fill: A.INK.ink });
    y += 18;

    var n = g.spec.n, colW = Math.min(126, 760 / n), x0 = W / 2 - (colW * n) / 2;
    var cats = g.spec.cats;
    /* the berth of each value, resolved once: sol[c][valueIndex] = berth */
    var at = function (c, b) {
      for (var vv = 0; vv < n; vv++) if (g.sol[c][vv] === b) return vv;
      return -1;
    };
    var iRig = -1, iNum = -1;
    for (var ci = 0; ci < cats.length; ci++) {
      if (cats[ci].id === 'rig') iRig = ci;
      if (cats[ci].id === 'number') iNum = ci;
    }
    var wordCats = [];
    for (var cj = 0; cj < cats.length; cj++) if (cj !== iNum) wordCats.push(cj);

    var budget = (H - 62) - y;                       // everything down to the button
    var artH = Math.round(Math.min(46, budget * 0.34));
    var rowH = Math.max(13, Math.min(18, Math.floor((budget - artH - 26) / Math.max(1, wordCats.length))));

    for (var b = 0; b < n; b++) {
      var cxb = x0 + colW * (b + 0.5);
      A.text(S.words.ordinal(b).toUpperCase(), cxb, y, { size: 11, align: 'center', track: 1, fill: A.INK.inkSoft });
      var ty = y + 12;

      /* ⚠️ THE UNLIT ROW, NOT THE LIT ONE. The lit silhouettes are drawn cold — they are what the
         beam picks out of a black sea — and four of them on warm paper read as blue stickers on a
         logbook. This page is the BOOK, so the ships belong to it as ink. Caught by looking; both
         rows pass every check identically. */
      if (iRig >= 0) {
        var vr = at(iRig, b);
        if (vr >= 0) {
          var vw = Math.min(colW - 14, artH * (112 / 84));
          A.vessel(cats[iRig].values[vr], cxb - vw / 2, ty, vw, false);
        }
      }
      ty += artH + 4;

      /* her number, flown as the two-flag hoist the title is named for */
      if (iNum >= 0) {
        var vn = at(iNum, b);
        if (vn >= 0) {
          var hh = Math.max(9, Math.min(16, Math.round(artH * 0.34)));
          var letters = S.words.hoist(iNum, vn);
          /* centred on the width hoist() will ACTUALLY draw, re-derived from the sheet metadata
             rather than a typed aspect (A.hoistWidth) */
          A.hoist(letters, cxb - A.hoistWidth(letters, hh, 2) / 2, ty, hh, 2);
          ty += hh + 6;
        }
      }

      /* and what she was, in words */
      for (var wi = 0; wi < wordCats.length; wi++) {
        var cw2 = wordCats[wi], vw2 = at(cw2, b);
        if (vw2 >= 0) {
          A.text(S.words.short(cw2, vw2), cxb, ty + rowH * 0.76,
            { size: Math.min(13, rowH - 3), align: 'center', fill: A.INK.inkSoft });
        }
        ty += rowH;
      }
    }

    A.button('THE LANTERN ROOM', W / 2 - 110, H - 52, 220, 40, { id: 'room', plateName: 'brass' });
  }

  /* ------------------------------------------------------------------ THE LANTERN ROOM */

  function drawRoom() {
    A.plate('granite', 0, 0, W, H);
    A.wash(0, 0, W, H, 'rgba(0,0,0,0.55)', 'rgba(0,0,0,0.25)');
    /* the lamp itself, glowing, at the top */
    var c = A.ctx();
    c.save();
    c.globalCompositeOperation = 'lighter';
    var gr = c.createRadialGradient(W / 2, 96, 6, W / 2, 96, 190);
    gr.addColorStop(0, 'rgba(244,220,166,0.5)');
    gr.addColorStop(1, 'rgba(244,220,166,0)');
    c.fillStyle = gr; c.fillRect(0, 0, W, 300);
    c.restore();
    drawLens(W / 2, 96, 156, 118);

    A.text('THE LANTERN ROOM', W / 2, 176, { size: 24, align: 'center', track: 5, fill: A.INK.lampHot });
    A.text('You keep everything bought here, whatever the night does to you.',
      W / 2, 200, { size: 14, align: 'center', fill: A.INK.cold });
    A.text('THE BOARD OWES YOU ' + S.keeper.banked, W / 2, 228,
      { size: 16, align: 'center', track: 2, fill: A.INK.lamp });

    /* ⛔ THE CARD HEIGHT IS DERIVED FROM WHAT IS LEFT, NOT TYPED. Five offers at a typed 66+8 ran
     * the last card to y=624 and straight through the OUT TO THE GALLERY button at y=590 — §3e-3's
     * lesson exactly: clamping a container does not make its contents fit, and a shared budget has
     * to be spent explicitly. The room holds five fittings today and would hold six tomorrow. */
    var offers = SIM.offers(S.keeper);
    var y = 254, gap = 8, bottom = H - 62;
    var cardH = offers.length
      ? Math.max(44, Math.min(66, Math.floor((bottom - y - gap * (offers.length - 1)) / offers.length)))
      : 66;
    if (!offers.length) {
      A.text('Every fitting in the room is yours.', W / 2, y + 40, { size: 16, align: 'center', fill: A.INK.lamp });
    }
    for (var i = 0; i < offers.length; i++) {
      var o = offers[i];
      var yy = y + i * (cardH + gap);
      var afford = S.keeper.banked >= o.cost;
      A.plate('brass', 40, yy, W - 80, cardH, afford ? 0.62 : 0.30);
      A.rect(40, yy, W - 80, cardH, afford ? 'rgba(0,0,0,0.34)' : 'rgba(0,0,0,0.58)');
      c.save(); c.strokeStyle = afford ? 'rgba(244,220,166,0.45)' : 'rgba(244,220,166,0.15)';
      c.lineWidth = 1; c.strokeRect(40.5, yy + 0.5, W - 81, cardH - 1); c.restore();
      A.text(o.name, 58, yy + cardH * 0.40, { size: Math.min(16, cardH * 0.30), track: 1.8, fill: afford ? A.INK.lampHot : 'rgba(244,220,166,0.45)' });
      A.paragraph(o.desc, 58, yy + cardH * 0.72, W - 300, { size: Math.min(13, cardH * 0.26), fill: afford ? A.INK.cold : 'rgba(105,115,127,0.6)' });
      A.button(o.cost + '', W - 176, yy + (cardH - 34) / 2, 116, 34, { id: 'buy', arg: o.id, enabled: afford, size: 15 });
    }

    A.button('OUT TO THE GALLERY', W / 2 - 118, H - 50, 236, 40, { id: 'next', plateName: 'brass' });
  }

  /**
   * ⛔ THE LANTERN ROOM'S FOCAL POINT WAS A BLANK BRASS RECTANGLE UNDER A GLOW. It was captioned in
   * the source as "the lamp itself, glowing" and nothing was ever drawn inside it, so the screen
   * whose first purchasable fitting is literally A CATADIOPTRIC LENS opened on an empty box that
   * read as a missing asset. Found by opening the capture and looking; no gate can see it, because
   * a filled plate has plenty of colour and plenty of density.
   *
   * A Fresnel lens is recognisable for one reason: it is not a lens shape, it is a STACK. A central
   * refracting belt of concentric rings — the bullseye, which is the bit that throws the beam — with
   * angled catadioptric prism rings above and below it that catch the light that would otherwise go
   * to the roof and the floor, all held in a brass birdcage of vertical standards and horizontal
   * rings. Draw those three bands in that order and it is a lighthouse lens; draw a smooth oval and
   * it is a jar.
   */
  function drawLens(cx, cy, w, h) {
    var c = A.ctx();
    var x0 = cx - w / 2, y0 = cy - h / 2;
    var frame = 6;                       // brass standard / ring thickness
    var ix0 = x0 + frame, iw = w - frame * 2;
    var beltH = h * 0.30;                // the refracting belt
    var beltY0 = cy - beltH / 2;
    var capH = beltY0 - (y0 + frame);    // the catadioptric section above (and below, mirrored)

    c.save();

    /* the glass behind everything: cold at the edges, hot at the middle */
    var back = c.createLinearGradient(0, y0, 0, y0 + h);
    back.addColorStop(0, 'rgba(18,22,28,0.92)');
    back.addColorStop(0.5, 'rgba(58,48,30,0.92)');
    back.addColorStop(1, 'rgba(18,22,28,0.92)');
    c.fillStyle = back; c.fillRect(x0, y0, w, h);

    /* --- the catadioptric prism rings, top and bottom.
       Each ring is a band with a bright top edge and a dark underside, and they get SHALLOWER
       toward the belt, which is what makes the stack read as angled glass rather than as stripes. */
    var rings = 5;
    for (var side = 0; side < 2; side++) {
      for (var r = 0; r < rings; r++) {
        var t = r / rings, t2 = (r + 1) / rings;
        var ya = side === 0 ? (y0 + frame) + t * capH : (h + y0 - frame) - t * capH;
        var yb = side === 0 ? (y0 + frame) + t2 * capH : (h + y0 - frame) - t2 * capH;
        var top = Math.min(ya, yb), band = Math.abs(yb - ya);
        /* inset the ends slightly with distance from the belt: the barrel is round */
        var inset = (1 - t) * iw * 0.06;
        c.fillStyle = 'rgba(120,98,58,' + (0.30 + t * 0.34).toFixed(3) + ')';
        c.fillRect(ix0 + inset, top, iw - inset * 2, band);
        c.fillStyle = 'rgba(255,246,221,' + (0.16 + t * 0.30).toFixed(3) + ')';
        c.fillRect(ix0 + inset, side === 0 ? top + band - 1.6 : top, iw - inset * 2, 1.6);
        c.fillStyle = 'rgba(0,0,0,0.34)';
        c.fillRect(ix0 + inset, side === 0 ? top : top + band - 1, iw - inset * 2, 1);
      }
    }

    /* --- the refracting belt: concentric rings around the bullseye, drawn as ellipses so the
       barrel keeps its curve, then the hot core the beam actually comes out of. */
    c.save();
    c.beginPath(); c.rect(ix0, beltY0, iw, beltH); c.clip();
    c.fillStyle = 'rgba(74,60,34,0.95)'; c.fillRect(ix0, beltY0, iw, beltH);
    for (var b = 5; b >= 1; b--) {
      var rx = (iw / 2) * (b / 5), ry = (beltH / 2) * (b / 5) * 1.9;
      c.beginPath(); c.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
      c.strokeStyle = 'rgba(255,246,221,' + (0.10 + (5 - b) * 0.075).toFixed(3) + ')';
      c.lineWidth = 2; c.stroke();
      c.beginPath(); c.ellipse(cx, cy, rx - 2, ry - 2, 0, 0, Math.PI * 2);
      c.strokeStyle = 'rgba(0,0,0,0.28)'; c.lineWidth = 1; c.stroke();
    }
    c.globalCompositeOperation = 'lighter';
    var core = c.createRadialGradient(cx, cy, 1, cx, cy, iw * 0.34);
    core.addColorStop(0, 'rgba(255,250,235,0.95)');
    core.addColorStop(0.45, 'rgba(244,220,166,0.42)');
    core.addColorStop(1, 'rgba(244,220,166,0)');
    c.fillStyle = core; c.fillRect(ix0, beltY0, iw, beltH);
    c.restore();

    /* --- the brass birdcage: two standards, three rings, and the astragals across the belt */
    A.plate('brass', x0, y0, w, frame, 0.95);
    A.plate('brass', x0, y0 + h - frame, w, frame, 0.95);
    A.plate('brass', x0, y0, frame, h, 0.95);
    A.plate('brass', x0 + w - frame, y0, frame, h, 0.95);
    A.plate('brass', x0, beltY0 - 3, w, 3, 0.9);
    A.plate('brass', x0, beltY0 + beltH, w, 3, 0.9);
    for (var a = 1; a < 4; a++) {
      var ax = Math.round(x0 + (w / 4) * a);
      c.fillStyle = 'rgba(150,124,74,0.55)'; c.fillRect(ax - 1, beltY0, 2, beltH);
    }
    c.strokeStyle = 'rgba(0,0,0,0.55)'; c.lineWidth = 2; c.strokeRect(x0 + 1, y0 + 1, w - 2, h - 2);
    c.restore();

    /* the gate is blind to anything that is not a string unless it is told (§3e-3, one layer along) */
    A._artRect('lens', x0, y0, w, h);
  }

  /* ------------------------------------------------------------------ title + help */

  /**
   * ⛔ THE TOWER IS THE ONE THING ON THE TITLE SCREEN AND THE FIRST VERSION WAS A BLACK TRAPEZOID
   * WITH A BLOB ON TOP. It read as a chess pawn, it had no light in it, and it was the focal point
   * of the most-seen image the product has — §0-ART's "a hand-coded Canvas path is the FALLBACK,
   * never the plan", failing in exactly the way that rule was written for.
   *
   * A lighthouse is not a cone. What makes one legible at a glance is the ORDER of its parts: a
   * battered stone shaft with visible courses, a corbelled GALLERY that oversails the shaft, a
   * railing you can see through, a GLAZED lantern room with vertical astragals, a domed cap and a
   * finial. And the light has to be IN it — a dark lantern room is a disused tower.
   * The shaft is filled with the game's own granite plate rather than flat black, so it is lit stone
   * at night instead of a silhouette.
   */
  function drawTower(cx, baseY, hgt) {
    var c = A.ctx();
    var wBase = hgt * 0.30, wNeck = hgt * 0.17;
    var shaftTop = baseY - hgt * 0.74;
    var galleryY = shaftTop;
    var galW = wNeck * 1.62;
    var lanternH = hgt * 0.17, lanternW = wNeck * 1.16;
    var lanternY = galleryY - lanternH;

    /* ── the shaft, battered (curving in as it rises), filled with real stone ── */
    c.save();
    c.beginPath();
    c.moveTo(cx - wBase / 2, baseY);
    c.quadraticCurveTo(cx - wNeck / 2 - hgt * 0.02, baseY - hgt * 0.42, cx - wNeck / 2, shaftTop);
    c.lineTo(cx + wNeck / 2, shaftTop);
    c.quadraticCurveTo(cx + wNeck / 2 + hgt * 0.02, baseY - hgt * 0.42, cx + wBase / 2, baseY);
    c.closePath();
    c.save(); c.clip();
    A.plate('granite', cx - wBase, shaftTop - 4, wBase * 2, baseY - shaftTop + 8);
    /* night: the seaward side keeps a little of the lamp, the rest goes to black */
    var lg = c.createLinearGradient(cx - wBase / 2, 0, cx + wBase / 2, 0);
    lg.addColorStop(0, 'rgba(4,6,11,0.62)');
    lg.addColorStop(0.34, 'rgba(4,6,11,0.30)');
    lg.addColorStop(1, 'rgba(4,6,11,0.86)');
    c.fillStyle = lg; c.fillRect(cx - wBase, shaftTop - 4, wBase * 2, baseY - shaftTop + 8);
    /* courses — few enough to count, which is what makes it read as masonry and not as a cone */
    c.strokeStyle = 'rgba(0,0,0,0.45)'; c.lineWidth = 1;
    for (var yy = baseY - 7; yy > shaftTop; yy -= hgt * 0.072) {
      c.beginPath(); c.moveTo(cx - wBase, yy); c.lineTo(cx + wBase, yy); c.stroke();
    }
    c.restore();
    c.strokeStyle = 'rgba(0,0,0,0.75)'; c.lineWidth = 1.5; c.stroke();
    c.restore();

    /* ── the gallery: a corbel course that oversails the shaft, then the deck ── */
    c.save();
    c.fillStyle = '#0b0e15';
    c.beginPath();
    c.moveTo(cx - wNeck / 2 - 1, galleryY + 7);
    c.lineTo(cx - galW / 2, galleryY + 1);
    c.lineTo(cx + galW / 2, galleryY + 1);
    c.lineTo(cx + wNeck / 2 + 1, galleryY + 7);
    c.closePath(); c.fill();
    c.fillStyle = '#141a25';
    c.fillRect(cx - galW / 2, galleryY - 2, galW, 4);
    c.restore();

    /* the railing — you can see through it, which is most of why it reads as a lighthouse */
    c.save();
    c.strokeStyle = 'rgba(180,160,120,0.5)'; c.lineWidth = 1;
    var railH = hgt * 0.052;
    c.beginPath(); c.moveTo(cx - galW / 2, galleryY - railH); c.lineTo(cx + galW / 2, galleryY - railH); c.stroke();
    for (var bx = cx - galW / 2; bx <= cx + galW / 2 + 0.1; bx += galW / 7) {
      c.beginPath(); c.moveTo(bx, galleryY - railH); c.lineTo(bx, galleryY - 2); c.stroke();
    }
    c.restore();

    /* ── the lantern room, and it is LIT ── */
    c.save();
    c.globalCompositeOperation = 'lighter';
    var glow = c.createRadialGradient(cx, lanternY + lanternH / 2, 2, cx, lanternY + lanternH / 2, hgt * 0.62);
    glow.addColorStop(0, 'rgba(255,246,221,0.62)');
    glow.addColorStop(0.30, 'rgba(244,220,166,0.24)');
    glow.addColorStop(1, 'rgba(244,220,166,0)');
    c.fillStyle = glow;
    c.fillRect(cx - hgt, lanternY - hgt * 0.5, hgt * 2, hgt * 1.4);
    c.restore();

    c.save();
    c.fillStyle = 'rgba(255,246,221,0.90)';
    c.fillRect(cx - lanternW / 2, lanternY, lanternW, lanternH);
    /* astragals: the glazing bars, which are the lantern's signature */
    c.strokeStyle = 'rgba(28,22,12,0.72)'; c.lineWidth = 1.4;
    for (var ax = cx - lanternW / 2; ax <= cx + lanternW / 2 + 0.1; ax += lanternW / 5) {
      c.beginPath(); c.moveTo(ax, lanternY); c.lineTo(ax, lanternY + lanternH); c.stroke();
    }
    c.beginPath();
    c.moveTo(cx - lanternW / 2, lanternY + lanternH * 0.5);
    c.lineTo(cx + lanternW / 2, lanternY + lanternH * 0.5);
    c.stroke();
    c.strokeRect(cx - lanternW / 2, lanternY, lanternW, lanternH);
    c.restore();

    /* ── the cap: a shallow dome, a collar and a finial ── */
    c.save();
    c.fillStyle = '#10141c';
    c.beginPath();
    c.moveTo(cx - lanternW / 2 - 3, lanternY);
    c.quadraticCurveTo(cx, lanternY - hgt * 0.085, cx + lanternW / 2 + 3, lanternY);
    c.closePath(); c.fill();
    c.strokeStyle = 'rgba(0,0,0,0.8)'; c.lineWidth = 1; c.stroke();
    c.fillStyle = '#0b0e15';
    c.fillRect(cx - 1, lanternY - hgt * 0.128, 2, hgt * 0.05);
    c.beginPath(); c.arc(cx, lanternY - hgt * 0.132, 2.4, 0, Math.PI * 2); c.fill();
    c.restore();

    /* ── the beams, thrown out to seaward on both sides ── */
    c.save();
    c.globalCompositeOperation = 'lighter';
    var ly = lanternY + lanternH / 2;
    for (var s = -1; s <= 1; s += 2) {
      var bg = c.createLinearGradient(cx, ly, cx + s * hgt * 3.6, ly - hgt * 0.5);
      bg.addColorStop(0, 'rgba(244,220,166,0.26)');
      bg.addColorStop(1, 'rgba(244,220,166,0)');
      c.fillStyle = bg;
      c.beginPath();
      c.moveTo(cx, ly);
      c.lineTo(cx + s * hgt * 3.6, ly - hgt * 0.80);
      c.lineTo(cx + s * hgt * 3.6, ly + hgt * 0.30);
      c.closePath(); c.fill();
    }
    c.restore();
  }

  function drawTitle() {
    A.plate('sky', 0, 0, W, H);
    A.plate('sea', 0, 430, W, H - 430);
    A.wash(0, 430, W, H - 430, 'rgba(4,7,13,0)', 'rgba(4,7,13,0.95)');
    A.plate('haar', 0, 404, W, 60, 0.16);

    /* the tower, in silhouette, with the light on */
    var c = A.ctx();
    c.save();
    c.globalCompositeOperation = 'lighter';
    var gr = c.createRadialGradient(W / 2, 300, 4, W / 2, 300, 340);
    gr.addColorStop(0, 'rgba(244,220,166,0.42)');
    gr.addColorStop(1, 'rgba(244,220,166,0)');
    c.fillStyle = gr; c.fillRect(0, 0, W, H);
    c.restore();
    drawTower(W / 2, 442, 172);

    A.text('MAKE YOUR NUMBER', W / 2, 150, { size: 44, align: 'center', track: 8, fill: A.INK.lampHot });
    A.text('Six ships in the dark, one lamp, and a night that can only be read once.',
      W / 2, 186, { size: 16, align: 'center', fill: A.INK.cold });

    var saved = loadSave();
    var bw = 210, bh = 44, bx = W / 2 - bw / 2;
    var y = 486;
    if (saved && saved.keeper) {
      A.button('KEEP THE WATCH', bx, y, bw, bh, { id: 'continue' });
      A.text('night ' + ((saved.index || 0) + 1) + ' of eight', W / 2, y + 62, { size: 13, align: 'center', fill: A.INK.cold });
      A.button('A NEW KEEPER', bx, y + 76, bw, 34, { id: 'new', size: 12 });
    } else {
      A.button('TAKE THE WATCH', bx, y, bw, bh, { id: 'new' });
    }
    A.button('HOW IT WORKS', bx, y + (saved && saved.keeper ? 118 : 56), bw, 34, { id: 'help', size: 12 });
  }

  function drawHelp() {
    A.plate('leaf', 0, 0, W, H);
    A.wash(0, 0, W, H, 'rgba(36,26,17,0.24)', 'rgba(36,26,17,0.06)');
    A.text('HOW IT WORKS', 44, 52, { size: 22, track: 4, fill: A.INK.ink });
    A.line(44, 64, W - 44, 64, A.INK.rule, 1);

    var y = 96, colW = (W - 128) / 2, x2 = 44 + colW + 40;
    y += A.paragraph('Vessels pass your light in the dark, one after another. You cannot see them. What you can do is train the lamp on one bearing at a time and sweep it, and whatever is out there on that bearing writes you one line in the log.',
      44, y, colW, { size: 15, fill: A.INK.inkSoft }) + 14;
    y += A.paragraph('You have a fixed number of sweeps. Every bearing tells you whether it is holding anything, so pointing the lamp is a decision and not a guess. The haar can take an observation before you read it, but it never destroys one: it moves it to another bearing, and it is still out there.',
      44, y, colW, { size: 15, fill: A.INK.inkSoft }) + 14;
    A.paragraph('When the sweeps are gone, you name every berth in the log and hand it in.',
      44, y, colW, { size: 15, fill: A.INK.inkSoft });

    var y2 = 96;
    A.text('THE LOG', x2, y2, { size: 15, track: 2, fill: A.INK.ink }); y2 += 22;
    y2 += A.paragraph('Click a cell to rule it out. Right-click to pin one. The grid is the same grid the solver uses, so anything you can prove, you can mark.',
      x2, y2, colW, { size: 15, fill: A.INK.inkSoft }) + 16;
    A.text('THE PROMISE', x2, y2, { size: 15, track: 2, fill: A.INK.ink }); y2 += 22;
    y2 += A.paragraph('Every night is generated and then PROVEN to have exactly one answer, reachable by elimination alone. You will never need to guess, and there is never a second reading that also fits.',
      x2, y2, colW, { size: 15, fill: A.INK.inkSoft }) + 16;
    A.text('LOSING A NIGHT', x2, y2, { size: 15, track: 2, fill: A.INK.ink }); y2 += 22;
    A.paragraph('A wrong log costs you the night, never the run. You keep what you were paid and everything in the lantern room, and a fresh night takes its place.',
      x2, y2, colW, { size: 15, fill: A.INK.inkSoft });

    A.button('BACK', 44, H - 56, 150, 40, { id: 'back', plateName: 'brass' });
  }

  /* ------------------------------------------------------------------ input */

  function click(mx, my, right) {
    var hitZone = A.hitTest(mx, my);
    if (!hitZone) return;
    var id = hitZone.id;

    if (id === 'cell') {
      var a = hitZone.arg;
      if (right) SIM.pin(S.night, a.c, a.v, a.b);
      else SIM.strike(S.night, a.c, a.v, a.b);
      play('mark');
      save();
      return;
    }
    if (right) return;

    if (id === 'bearing') { S.bearing = hitZone.arg; S.target = angleOf(S.bearing); return; }
    if (id === 'sweep') return doSweep();
    if (id === 'log') { S.screen = 'log'; return; }
    if (id === 'watch') { S.screen = 'watch'; return; }
    if (id === 'name') return doName();
    if (id === 'room') return nextNight();
    if (id === 'buy') { if (SIM.buy(S.keeper, hitZone.arg)) { play('buy'); save(); } return; }
    if (id === 'next') { beginNight(S.pendingIndex === undefined ? 0 : S.pendingIndex); return; }
    if (id === 'new') { newRun(); return; }
    if (id === 'continue') { var d = loadSave(); if (d) resume(d); return; }
    if (id === 'help') { S.helpFrom = S.screen; S.screen = 'help'; return; }
    if (id === 'back') { S.screen = S.helpFrom || 'title'; return; }
    if (id === 'mute') { toggleMute(); return; }
  }

  function key(k) {
    if (S.screen === 'watch') {
      var n = parseInt(k, 10);
      if (n >= 1 && n <= SIM.SECTORS) { S.bearing = n - 1; S.target = angleOf(S.bearing); return; }
      if (k === ' ' || k === 'Enter') return doSweep();
      if (k === 'Tab' || k === 'l' || k === 'L') { S.screen = 'log'; return; }
      if (k === 'ArrowLeft') { S.bearing = Math.max(0, S.bearing - 1); S.target = angleOf(S.bearing); return; }
      if (k === 'ArrowRight') { S.bearing = Math.min(SIM.SECTORS - 1, S.bearing + 1); S.target = angleOf(S.bearing); return; }
    } else if (S.screen === 'log') {
      if (k === 'Tab' || k === 'l' || k === 'L' || k === 'Escape') { S.screen = 'watch'; return; }
    } else if (S.screen === 'help') {
      if (k === 'Escape') { S.screen = S.helpFrom || 'title'; return; }
    }
    if (k === 'm' || k === 'M') toggleMute();
  }

  function scroll(dy) {
    if (S.screen !== 'log' || !S.night) return;
    S.logScroll = Math.max(0, Math.min(Math.max(0, S.night.log.length - 3), S.logScroll + (dy > 0 ? 1 : -1)));
  }

  var API = {
    S: S, W: W, H: H,
    frame: frame, click: click, key: key, scroll: scroll,
    newRun: newRun, beginNight: beginNight, resume: resume, loadSave: loadSave, loadAudio: loadAudio,
    /* the layout gate drives these directly */
    screens: ['title', 'watch', 'log', 'result', 'room', 'help'],
    /* ⚠️ THE STORE COVER IS COMPOSED FROM THE PRODUCT'S OWN ART, NOT CROPPED FROM A SCREEN
       (master §4.2c: a screenshot is never a cover). `cover.js` draws a fresh 630x500 canvas and
       needs the two pieces of furniture the game draws by hand — the tower and the lens — so they
       are exported rather than copied. A second copy of the tower is a second tower to keep true. */
    art: { tower: drawTower, lens: drawLens, flatten: function () { return FLATTEN; } },
    setScreen: function (s) { S.screen = s; },
    draw: function () { frame(0); }
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  else root.MYN = API;
})(typeof window !== 'undefined' ? window : globalThis);
