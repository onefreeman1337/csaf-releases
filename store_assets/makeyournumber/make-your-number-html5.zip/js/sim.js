/* MAKE YOUR NUMBER — sim.js : the lamp, and the night it is pointed into.
 *
 * `case.js` is the solver and `gen.js` guarantees the night has one answer. This file is the SECOND
 * SYSTEM the complexity floor demands, and the reason the two are the same system is the whole
 * design (ledger B5):
 *
 *   The generator MINIMISES the clue set until every clue is load bearing. Those clues are not
 *   handed over. They are OBSERVATIONS scattered around a compass of sectors, and the beam only
 *   lights one sector at a time. So the difficulty of a night is HOW MUCH EVIDENCE IS WITHHELD —
 *   and which part of that minimal set you actually receive is chosen by you, one sweep at a time,
 *   with the fog taking whatever you did not look at.
 *
 * ⛔ THE HARD GUARANTEE THIS FILE MUST NOT BREAK: a night must stay winnable. The generator proved
 *    the FULL minimal set pins one answer; if the lamp can permanently deny a clue, the player can
 *    be handed a case that is unsolvable through no error of their own. So an observation is never
 *    destroyed — the fog DEFERS it (it moves to another sector) rather than deleting it, and the
 *    sweep budget is checked against the number of sectors that still hold evidence. `winnable()`
 *    states that property and the suite sweeps it.
 *
 * No DOM, no canvas, no timers: a pure state machine, so thousands of nights can be played
 * headless.
 */
(function (root) {
  'use strict';

  var C = (typeof require !== 'undefined' && typeof module !== 'undefined') ? require('./case.js') : root.MYNCASE;
  var G = (typeof require !== 'undefined' && typeof module !== 'undefined') ? require('./gen.js') : root.MYNGEN;

  var SECTORS = 8;                       // the compass the light can be trained on

  /* ------------------------------------------------------------- the nights
   * Authored rather than computed, so the curve is a design decision that can be read in one
   * screen. `keep` is the difficulty dial and it is literally "how much evidence is withheld".
   */
  /* ⛔ `keep` IS THE WHOLE DIFFICULTY CURVE AND IT IS NOT A NUMBER I LIKED. It is the fraction of
   * the clue pool the generator stops minimising at, i.e. how much REDUNDANCY the night carries. A
   * night at keep 0.5 can be closed without seeing every observation, because several of them say
   * overlapping things; a night at keep 0 has been minimised until every single clue is load
   * bearing, so losing one to the fog costs the case. That is the interaction the complexity floor
   * asked for, expressed as one number per night rather than as a timer.
   *
   * ⚠️ `sweeps` is a MINIMUM, not the budget — `startNight` derives the real budget from how many
   * sectors actually hold evidence and how thick the fog is, because a budget typed in a table is
   * a guess about a scatter that has not happened yet. First cut typed 9 and three of the eight
   * nights became unwinnable by a perfect bot; measured, not reasoned.
   */
  /* ⛔ `slack` IS THE DIFFICULTY DIAL AND IT EXISTS BECAUSE THE FIRST BUDGET FORMULA MADE THE GAME
   * FRICTIONLESS. MEASURED by `balance.js` over 5 seeds x 8 nights: a bot pointing the lamp AT
   * RANDOM kept 39 of 40 nights, a stock keeper matched a fully-kitted one 40-40, and the bot saw
   * 1737 of 1737 observations — on night eight it needed 6 of its 13 sweeps.
   *
   * That is the OPPOSITE over-correction to the one this table already carries a warning about. The
   * original budget was TYPED and left three nights unwinnable; the derived replacement added a flat
   * `+3` on top of a `1/(1-fog)` allowance on top of an 8-sweep floor, and three safety margins
   * stacked on one number is not a safety margin, it is the absence of a constraint. With nothing
   * scarce, the lamp is decoration and the lantern room is a formality — i.e. BOTH halves of the
   * complexity floor stop existing, while every unit test stays green because each one is true.
   *
   * The budget is now exactly what a perfect lamp needs, plus a slack that shrinks across the
   * campaign. Winnability is unchanged and still swept: the fog DEFERS rather than destroys, and
   * `reachable()` still reports whether the remaining sweeps can cover the remaining sectors. */
  var NIGHTS = [
    { title: 'THE FIRST WATCH',   n: 4, cats: ['rig', 'cargo'],                     keep: 0.55, slack: 4, fog: 0.00 },
    { title: 'A CLEAR NIGHT',     n: 4, cats: ['rig', 'cargo', 'port'],             keep: 0.45, slack: 3, fog: 0.00 },
    { title: 'HAAR OFF THE BANK', n: 4, cats: ['rig', 'cargo', 'port'],             keep: 0.35, slack: 3, fog: 0.16 },
    { title: 'THE SPRING TIDE',   n: 5, cats: ['rig', 'cargo', 'port'],             keep: 0.30, slack: 2, fog: 0.16 },
    { title: 'COLLIER WEATHER',   n: 5, cats: ['rig', 'cargo', 'port', 'number'],   keep: 0.22, slack: 2, fog: 0.22 },
    { title: 'THE LONG DARK',     n: 5, cats: ['rig', 'cargo', 'port', 'number'],   keep: 0.12, slack: 1, fog: 0.22 },
    { title: 'A GALE FROM THE NE',n: 6, cats: ['rig', 'cargo', 'port', 'number'],   keep: 0.06, slack: 1, fog: 0.28 },
    /* ⚠️ THIS ONE TOOK TWO CORRECTIONS AND BOTH WERE FOUND BY A SUITE, NOT BY REASONING. At slack 0
     * the equinoctial scored NOTHING on 2 of 14 seeds even with the whole lantern room built — a
     * budget set at the EXPECTATION loses to variance, and a keeper who plays perfectly and is
     * beaten by the weather is being treated exactly as unfairly as one handed a case with two
     * answers. At slack 1 it still came away with zero determined on 2 seeds with a stock lamp,
     * which is the same wall reached through the economy: a keeper who earns nothing cannot buy the
     * fitting that would have helped. Slack 2 clears both at 14/14. It is still the hardest night
     * in the book by every other dial — the thickest fog, the largest grid, and `keep: 0` means
     * every single clue is load bearing. */
    { title: 'THE EQUINOCTIAL',   n: 6, cats: ['rig', 'cargo', 'port', 'number'],   keep: 0.00, slack: 2, fog: 0.30 }
  ];

  /* ----------------------------------------------------------- the lantern room
   * Every upgrade changes WHICH EVIDENCE IS REACHABLE. None of them is a timer or a score
   * multiplier, because this game has neither.
   */
  var UPGRADES = {
    lens:    { name: 'A CATADIOPTRIC LENS', cost: 30, desc: 'The beam lights the sector either side of the one you train it on.' },
    mercury: { name: 'A MERCURY BATH',      cost: 34, desc: 'One more sweep every night. The lamp turns more easily than it did.' },
    signal:  { name: 'A FOG SIGNAL',        cost: 40, desc: 'The first observation of a night can never be taken by the fog.' },
    tide:    { name: 'A TIDE TABLE',        cost: 26, desc: 'One vessel\'s berth is known before the first sweep.' },
    glass:   { name: 'A BETTER GLASS',      cost: 44, desc: 'Every sector shows you how many observations it is holding.', repeat: false }
  };

  function newKeeper() {
    return { owned: {}, banked: 0, nightsKept: 0, reached: 0 };
  }

  /* ------------------------------------------------------------- starting a night */

  function startNight(keeper, index, seed) {
    var s = NIGHTS[Math.min(index, NIGHTS.length - 1)];
    var over = index >= NIGHTS.length ? (index - NIGHTS.length + 1) : 0;
    var spec = G.makeSpec(Math.min(8, s.n + Math.floor(over / 2)), s.cats);
    var night = G.generate(spec, (seed || (index * 7919 + 11)) >>> 0, { keep: Math.max(0, s.keep - over * 0.05) });
    if (night.failed) throw new Error('generator failed on night ' + index + ': ' + night.failed);

    var rnd = G.rng(((seed || index * 7919 + 11) ^ 0x5bf03635) >>> 0);
    /* scatter the minimal clue set around the compass. Every sector may hold several. */
    var obs = night.clues.map(function (k, i) {
      return { id: i + 1, clue: k, sector: Math.floor(rnd() * SECTORS) % SECTORS, seen: false, fogged: false };
    });

    /* ⛔ THE SWEEP BUDGET IS DERIVED FROM THE SCATTER THAT ACTUALLY HAPPENED, not typed in the
       table. It must cover every sector holding evidence at least once, plus an allowance for the
       observations the fog will defer — otherwise a perfect keeper loses to the weather, which is
       the same unfairness as a non-unique case wearing different clothes. MEASURED: with a typed
       budget of 9, three of the eight authored nights were unwinnable by a bot that pointed the
       lamp optimally. */
    var occupied = {};
    for (var oi = 0; oi < obs.length; oi++) occupied[obs[oi].sector] = true;
    var nSectors = Object.keys(occupied).length;
    /* ⚠️ THE FOG ALLOWANCE IS 1/(1-fog), NOT (1 + fog). An observation that is fogged can be fogged
       AGAIN next time it is lit, so the expected number of lightings per observation is a geometric
       series, not one extra pass. The first formula used (1 + fog*1.6) and left a night short by two
       sweeps on a 6-sector scatter in thick weather — measured, not reasoned (_probe_equinoctial). */
    var budget = Math.ceil(nSectors / Math.max(0.4, 1 - s.fog)) + (s.slack === undefined ? 2 : s.slack);

    var g = {
      keeper: keeper,
      index: index,
      title: over ? 'ANOTHER WATCH ' + over : s.title,
      spec: spec,
      sol: night.sol,
      obs: obs,
      grid: C.newGrid(spec),
      bearing: 0,
      sweepsLeft: budget + (keeper.owned.mercury ? 1 : 0) + Math.floor(over / 3),
      sweepBudget: budget,
      fog: s.fog,
      rnd: rnd,
      log: [],                       // the observations actually received, in order
      phase: 'watching',             // watching -> naming -> won | lost
      flash: null,
      firstSweepDone: false,
      stats: { minimalClues: night.clues.length, poolSize: night.stats.poolSize }
    };

    /* A TIDE TABLE hands one berth over before the first sweep — a free, real deduction step. */
    if (keeper.owned.tide) {
      var c = Math.floor(rnd() * spec.cats.length) % spec.cats.length;
      var v = Math.floor(rnd() * spec.n) % spec.n;
      var free = { id: 0, clue: { kind: 'berth', a: { c: c, v: v }, b: night.sol[c][v] }, sector: -1, seen: true, fogged: false, free: true };
      g.obs.unshift(free);
      g.log.push(free);
      C.propagate(g.grid, [free.clue]);
    }
    return g;
  }

  /* ------------------------------------------------------------------ the lamp */

  function sectorsLit(g, bearing) {
    var out = [bearing % SECTORS];
    if (g.keeper.owned.lens) {
      out.push((bearing + SECTORS - 1) % SECTORS);
      out.push((bearing + 1) % SECTORS);
    }
    return out;
  }

  /** How many unseen observations a sector is holding. The exact number is A BETTER GLASS's job. */
  function holding(g, sector) {
    var n = 0;
    for (var i = 0; i < g.obs.length; i++) if (!g.obs[i].seen && g.obs[i].sector === sector) n++;
    return n;
  }

  /**
   * ⛔ WHETHER A SECTOR HOLDS ANYTHING AT ALL IS ALWAYS VISIBLE, AND THAT IS A DESIGN DECISION, not
   * a convenience. The first cut hid it, and pointing the lamp was then a blind guess between eight
   * arcs — which is a lottery, not a deduction game, and it showed up immediately as a bot that
   * swept optimally and still lost. A keeper on a real light can SEE that there is something out
   * there; what they cannot see is what it is, or how much of it. A BETTER GLASS upgrades
   * "something" to "how many", which is a real improvement rather than the difference between
   * playing and guessing.
   */
  function sighted(g, sector) { return holding(g, sector) > 0; }

  /**
   * Train the lamp on a bearing and take what the beam shows.
   *
   * ⛔ THE FOG DEFERS, IT DOES NOT DELETE. A fogged observation is moved to another sector and can
   * still be found — because the generator proved the night unique on the FULL minimal set, and a
   * clue that can be permanently destroyed is a night that can become unsolvable through no fault
   * of the player's.
   */
  function sweep(g, bearing) {
    if (g.phase !== 'watching') return { ok: false, why: 'the watch is over' };
    if (g.sweepsLeft <= 0) return { ok: false, why: 'no sweeps left' };
    g.bearing = ((bearing % SECTORS) + SECTORS) % SECTORS;
    g.sweepsLeft--;
    var lit = sectorsLit(g, g.bearing);
    var got = [], fogged = [];
    var protectFirst = g.keeper.owned.signal && !g.firstSweepDone;

    for (var i = 0; i < g.obs.length; i++) {
      var o = g.obs[i];
      if (o.seen || lit.indexOf(o.sector) < 0) continue;
      var takes = g.fog > 0 && g.rnd() < g.fog && !(protectFirst && got.length === 0);
      if (takes) {
        o.fogged = true;
        o.sector = (o.sector + 1 + Math.floor(g.rnd() * (SECTORS - 1))) % SECTORS;
        fogged.push(o);
        continue;
      }
      o.seen = true;
      g.log.push(o);
      got.push(o);
    }
    g.firstSweepDone = true;
    if (got.length) C.propagate(g.grid, g.log.map(function (o) { return o.clue; }));
    g.flash = { kind: 'sweep', bearing: g.bearing, got: got.length, fogged: fogged.length };
    if (g.sweepsLeft <= 0) g.phase = 'naming';
    return { ok: true, got: got, fogged: fogged };
  }

  /** Give up the rest of the watch and go to the log. */
  function callIt(g) {
    if (g.phase !== 'watching') return false;
    g.phase = 'naming';
    return true;
  }

  /* --------------------------------------------------------------- the log
   * The player's grid IS the solver's grid, which is what makes the two systems one system. These
   * are the two moves a keeper can make in the log book.
   */
  function strike(g, c, v, b) {
    if (!g.grid[c] || !g.grid[c][v] || g.grid[c][v][b] === undefined) return false;
    g.grid[c][v][b] = !g.grid[c][v][b];
    return true;
  }
  function pin(g, c, v, b) {
    if (!g.grid[c] || !g.grid[c][v] || g.grid[c][v][b] === undefined) return false;
    if (!g.grid[c][v][b]) return false;
    C.assign(g.grid, c, v, b);
    return true;
  }

  /** What the player has committed to, where a category/value has exactly one berth left. */
  function reading(g) {
    var out = [];
    for (var c = 0; c < g.grid.length; c++) {
      var row = [];
      for (var v = 0; v < g.grid[c].length; v++) {
        var bs = C.berthsFor(g.grid, c, v);
        row.push(bs.length === 1 ? bs[0] : -1);
      }
      out.push(row);
    }
    return out;
  }

  /** Submit the log. Scores per correct pin, and the whole night if it is exactly right. */
  function name(g) {
    if (g.phase !== 'naming') return null;
    var r = reading(g);
    var right = 0, wrong = 0, blank = 0;
    for (var c = 0; c < r.length; c++) for (var v = 0; v < r[c].length; v++) {
      if (r[c][v] < 0) blank++;
      else if (r[c][v] === g.sol[c][v]) right++;
      else wrong++;
    }
    var total = right + wrong + blank;
    var perfect = right === total;
    /* ⛔ THE RATION, RE-SCALED. MEASURED: at `right*2 + 20 + n*4` a keeper ended a campaign with 412
     * banked against a 174 lantern room, and EVERY fitting was affordable from night two — so the
     * room was a shopping list rather than a sequence of choices, and "which fitting first" (the
     * only decision it offers) never came up. The room should take most of a campaign to fill. */
    /* ⛔ AND NO SUBTRACTION FOR WRONG BERTHS. With the ration re-scaled, `- wrong * 2` could drive a
     * bad night to ZERO — measured on 2 of 14 seeds on the equinoctial with a stock lamp. A keeper
     * who earns nothing cannot buy the fitting that would have helped, which is §3f's "wall with a
     * date on it" arriving through the economy instead of through the map. It is also redundant:
     * a single wrong berth already forfeits the perfect bonus, which is the largest term here, so
     * the penalty for guessing is severe without being able to leave a player with no way forward. */
    var earned = right * 1 + (perfect ? 8 + g.spec.n * 2 : 0);
    if (earned < 0) earned = 0;
    g.phase = perfect ? 'won' : 'lost';
    g.result = { right: right, wrong: wrong, blank: blank, total: total, perfect: perfect, earned: earned };
    g.keeper.banked += earned;
    g.keeper.reached = Math.max(g.keeper.reached, g.index + (perfect ? 1 : 0));
    if (perfect) g.keeper.nightsKept = Math.max(g.keeper.nightsKept, g.index + 1);
    return g.result;
  }

  /**
   * ⛔ THE WINNABILITY PROPERTY, STATED SO IT CAN BE SWEPT. A night is winnable if the observations
   * still reachable — everything not yet seen, plus everything already in the log — pin exactly one
   * answer. Since the fog only ever MOVES an observation, this is true at the start of every night
   * and stays true however the lamp is pointed; the suite asserts both halves.
   */
  function winnable(g) {
    var clues = g.obs.map(function (o) { return o.clue; });
    return C.solve(g.spec, clues).count === 1;
  }

  /** Enough sweeps left to reach every remaining observation, if you point the lamp perfectly? */
  function reachable(g) {
    var need = {};
    for (var i = 0; i < g.obs.length; i++) if (!g.obs[i].seen) need[g.obs[i].sector] = true;
    var sectors = Object.keys(need).length;
    var per = g.keeper.owned.lens ? 3 : 1;
    return { sectors: sectors, sweepsLeft: g.sweepsLeft, enough: g.sweepsLeft * per >= sectors };
  }

  function offers(keeper) {
    var out = [];
    for (var k in UPGRADES) {
      if (!Object.prototype.hasOwnProperty.call(UPGRADES, k)) continue;
      if (keeper.owned[k]) continue;
      out.push({ id: k, name: UPGRADES[k].name, desc: UPGRADES[k].desc, cost: UPGRADES[k].cost });
    }
    return out;
  }
  function buy(keeper, id) {
    var u = UPGRADES[id];
    if (!u || keeper.owned[id] || keeper.banked < u.cost) return false;
    keeper.banked -= u.cost;
    keeper.owned[id] = true;
    return true;
  }

  var API = {
    SECTORS: SECTORS, NIGHTS: NIGHTS, UPGRADES: UPGRADES,
    newKeeper: newKeeper, startNight: startNight, sweep: sweep, callIt: callIt,
    strike: strike, pin: pin, reading: reading, name: name,
    winnable: winnable, reachable: reachable, holding: holding, sighted: sighted, sectorsLit: sectorsLit,
    offers: offers, buy: buy
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  else root.MYNSIM = API;
})(typeof window !== 'undefined' ? window : globalThis);
