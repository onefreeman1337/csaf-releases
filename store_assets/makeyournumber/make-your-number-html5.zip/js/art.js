/* MAKE YOUR NUMBER — art.js : every mark this game makes on the canvas.
 *
 * ⛔ EVERY STRING GOES THROUGH `API.text`. NOT `text`. Wing §3e-1 records the exact defect this
 *    prevents: FLOODMARK's layout gate reported "help — 12 strings" for a screen drawing thirty,
 *    because `paragraph` called the closure-local `text` and the recorder had replaced only the
 *    exported one. It was blind to precisely the lines most likely to overflow. So `paragraph`,
 *    `button` and everything else in this file route through the exported object, and
 *    `test_layout.js` asserts a FLOOR on how many strings it saw per screen so the blindness
 *    cannot come back quietly.
 *
 * ⛔ AND NO LAYOUT NUMBER IS EVER TYPED. This game ships a system serif stack, so the same string
 *    is a different width on a Mac, on Windows, in Linux and in headless capture. Every wrap and
 *    every column is derived from `ctx.measureText` AT DRAW TIME.
 *
 * THE TWO SURFACES. The whole look is one contrast: the coast is cold, nearly black and almost
 * featureless — it is what a keeper cannot see, drawn honestly — and the log book is warm, close
 * and full of detail. Nothing on the coast is warm except the beam.
 */
(function (root) {
  'use strict';

  /* iron gall ink on aged paper, and the lamp. Everything else comes out of the plates. */
  var INK = {
    ink:      '#241a11',
    inkSoft:  '#4a3a28',
    inkFaint: '#7d6a4e',
    rule:     '#9c8763',
    struck:   '#7d2f22',
    pinned:   '#1d4a33',
    lamp:     '#f4dca6',
    lampHot:  '#fff6dd',
    lampDim:  'rgba(244,220,166,0.16)',
    cold:     '#69737f',
    coldDim:  '#3c4550',
    night:    '#04070d'
  };

  var FONT = "'Iowan Old Style', 'Palatino Linotype', Palatino, Georgia, serif";
  var SANS = "'Iowan Old Style', 'Palatino Linotype', Palatino, Georgia, serif";

  var ctx = null, W = 0, H = 0;
  var plates = {};          // name -> { img, pattern }
  var sheets = {};          // 'flags' | 'vessels' -> { img, meta }
  var loaded = false;

  /* ------------------------------------------------------------------ loading
   * ⛔ A CAPTURE SCRIPT MUST BE ABLE TO WAIT FOR THIS (wing §3d rule 3). `xLoaded()` is the only
   * proof the assets actually DECODED — an <img> whose src is set is not an <img> that is ready,
   * and a capture taken between the two produces a store screenshot of an empty screen.
   */
  function loadImage(src) {
    return new Promise(function (res, rej) {
      var i = new Image();
      i.onload = function () { res(i); };
      i.onerror = function () { rej(new Error('could not load ' + src)); };
      i.src = src;
    });
  }

  function init(canvas, w, h) {
    ctx = canvas.getContext('2d');
    W = w; H = h;
    ctx.imageSmoothingEnabled = false;
    ctx.textBaseline = 'alphabetic';
    return ctx;
  }

  function loadAll(base) {
    var b = base || 'art/';
    var names = ['sea', 'sky', 'haar', 'leaf', 'granite', 'brass'];
    var jobs = names.map(function (n) {
      return loadImage(b + 'plate_' + n + '.png').then(function (img) {
        plates[n] = { img: img, pattern: ctx.createPattern(img, 'repeat') };
      });
    });
    jobs.push(fetch(b + 'flags.json').then(function (r) { return r.json(); }).then(function (meta) {
      return loadImage(b + meta.file).then(function (img) { sheets.flags = { img: img, meta: meta }; });
    }));
    jobs.push(fetch(b + 'vessels.json').then(function (r) { return r.json(); }).then(function (meta) {
      return loadImage(b + meta.file).then(function (img) { sheets.vessels = { img: img, meta: meta }; });
    }));
    return Promise.all(jobs).then(function () { loaded = true; return true; });
  }
  function isLoaded() { return loaded; }

  /* ------------------------------------------------------------------ surfaces */

  /** Tile a plate. ⚠️ Drawn at 1:1 — the engine's ordered dither reads as fine grain at 1:1 and as
   *  chunky pixel art the moment it is scaled, and this game is not pixel art. */
  function plate(name, x, y, w, h, alpha) {
    if (!plates[name]) return;
    ctx.save();
    if (alpha !== undefined) ctx.globalAlpha = alpha;
    ctx.fillStyle = plates[name].pattern;
    ctx.translate(x, y);
    ctx.fillRect(0, 0, w, h);
    ctx.restore();
  }

  function rect(x, y, w, h, fill) { ctx.fillStyle = fill; ctx.fillRect(x, y, w, h); }
  function line(x0, y0, x1, y1, stroke, width) {
    ctx.save(); ctx.strokeStyle = stroke; ctx.lineWidth = width || 1;
    ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); ctx.restore();
  }

  /** A vertical wash — used for the horizon, for fog banks and to sink the sea into the dark. */
  function wash(x, y, w, h, top, bottom) {
    var g = ctx.createLinearGradient(0, y, 0, y + h);
    g.addColorStop(0, top); g.addColorStop(1, bottom);
    ctx.fillStyle = g; ctx.fillRect(x, y, w, h);
  }

  /* ------------------------------------------------------------------ type
   * ⛔ `API.text` IS THE ONLY PLACE A STRING REACHES THE CANVAS. Everything below calls it through
   * the exported object so the layout recorder can see every last one.
   */
  function text(str, x, y, o) {
    o = o || {};
    var size = o.size || 15;
    var weight = o.weight || '';
    ctx.save();
    ctx.font = (weight ? weight + ' ' : '') + size + 'px ' + (o.sans ? SANS : FONT);
    ctx.fillStyle = o.fill || INK.ink;
    if (o.alpha !== undefined) ctx.globalAlpha = o.alpha;
    ctx.textAlign = o.align || 'left';
    if (o.track) {
      /* letter-spaced small caps for headings — measured per glyph, never assumed */
      var total = 0, i;
      for (i = 0; i < str.length; i++) total += ctx.measureText(str[i]).width + o.track;
      total -= o.track;
      var cx = o.align === 'center' ? x - total / 2 : (o.align === 'right' ? x - total : x);
      ctx.textAlign = 'left';
      for (i = 0; i < str.length; i++) {
        ctx.fillText(str[i], cx, y);
        cx += ctx.measureText(str[i]).width + o.track;
      }
      ctx.restore();
      return total;
    }
    ctx.fillText(str, x, y);
    var w = ctx.measureText(str).width;
    ctx.restore();
    return w;
  }

  function measure(str, o) {
    o = o || {};
    ctx.save();
    ctx.font = ((o.weight ? o.weight + ' ' : '')) + (o.size || 15) + 'px ' + (o.sans ? SANS : FONT);
    var w = ctx.measureText(str).width;
    ctx.restore();
    return w;
  }

  /** ⛔ CANVAS TEXT DOES NOT WRAP, DOES NOT REFLOW AND DOES NOT CLIP. Before this pair existed in
   *  FLOODMARK there was no way to wrap a string anywhere in that codebase, which is the whole
   *  reason four body lines ran to 1035px on a 960px canvas with every check green. */
  function wrap(str, maxWidth, o) {
    var words = String(str).split(/\s+/);
    var lines = [], cur = '';
    for (var i = 0; i < words.length; i++) {
      var probe = cur ? cur + ' ' + words[i] : words[i];
      if (cur && measure(probe, o) > maxWidth) { lines.push(cur); cur = words[i]; }
      else cur = probe;
    }
    if (cur) lines.push(cur);
    return lines;
  }

  /**
   * ⛔ `paragraph` MUST RESOLVE ALIGNMENT ITSELF, NOT PASS IT THROUGH. Handing `align:'center'`
   * straight to `text` centres every line on the paragraph's LEFT EDGE, so a centred block sits half
   * a column to the left of where it was asked for — measured at x = -167 on a 960px canvas, i.e.
   * a whole sentence off the side of the screen, with no error anywhere. `x` is the left edge of the
   * text BOX and the alignment happens inside it.
   */
  function paragraph(str, x, y, maxWidth, o) {
    o = o || {};
    var lh = o.lineHeight || Math.round((o.size || 15) * 1.42);
    var lines = wrap(str, maxWidth, o);
    var align = o.align || 'left';
    var ax = align === 'center' ? x + maxWidth / 2 : (align === 'right' ? x + maxWidth : x);
    for (var i = 0; i < lines.length; i++) API.text(lines[i], ax, y + i * lh, o);
    return lines.length * lh;
  }
  /** How tall a paragraph WILL be, without drawing it — so a caller can refuse to start one that
   *  will not fit rather than discovering it afterwards. */
  function paragraphHeight(str, maxWidth, o) {
    o = o || {};
    return wrap(str, maxWidth, o).length * (o.lineHeight || Math.round((o.size || 15) * 1.42));
  }

  /* ------------------------------------------------------------------ controls
   * ⛔ A BUTTON IS RECORDED AS A RECT **AND** A LABEL. §3e-3: the layout gate was green on a screen
   * whose controls line had orphaned the word "mutes" onto the BACK button's top border, because
   * nothing in the gate modelled controls at all.
   */
  var hot = [];
  function beginFrame() { hot.length = 0; }
  function button(label, x, y, w, h, o) {
    o = o || {};
    var enabled = o.enabled !== false;
    var on = o.on;
    ctx.save();
    ctx.globalAlpha = enabled ? 1 : 0.38;
    if (o.plate !== false) plate(o.plateName || 'brass', x, y, w, h, enabled ? 1 : 0.7);
    else { ctx.fillStyle = o.fill || 'rgba(0,0,0,0.35)'; ctx.fillRect(x, y, w, h); }
    ctx.strokeStyle = on ? INK.lamp : (o.border || 'rgba(0,0,0,0.55)');
    ctx.lineWidth = on ? 2 : 1;
    ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
    ctx.restore();
    API.text(label, x + w / 2, y + h / 2 + (o.size || 14) * 0.36, {
      size: o.size || 14, align: 'center', fill: o.ink || (on ? INK.lampHot : INK.lamp),
      track: o.track === undefined ? 1.4 : o.track, alpha: enabled ? 1 : 0.45, isButtonLabel: true
    });
    if (enabled && o.id) hot.push({ id: o.id, x: x, y: y, w: w, h: h, arg: o.arg });
    API._buttonRect(label, x, y, w, h);
    return { x: x, y: y, w: w, h: h };
  }
  function hitTest(mx, my) {
    for (var i = hot.length - 1; i >= 0; i--) {
      var b = hot[i];
      if (mx >= b.x && mx <= b.x + b.w && my >= b.y && my <= b.y + b.h) return b;
    }
    return null;
  }
  function zone(id, x, y, w, h, arg) { hot.push({ id: id, x: x, y: y, w: w, h: h, arg: arg }); }

  /* ------------------------------------------------------------------ the art itself */

  /** One signal flag, drawn from the generated sheet. Height drives the size; the sheet's own cell
   *  aspect drives the width, so a pennant stays a pennant. */
  function flag(key, x, y, h) {
    var s = sheets.flags;
    if (!s) return 0;
    var i = s.meta.order.indexOf(key);
    if (i < 0) return 0;
    var cw = s.meta.cw, ch = s.meta.ch;
    var w = Math.round(h * (cw / ch));
    ctx.drawImage(s.img, i * cw, 0, cw, ch, Math.round(x), Math.round(y), w, h);
    API._artRect('flag:' + key, x, y, w, h);
    return w;
  }

  /** A two-flag hoist — a vessel's NUMBER, which is what the title means. */
  function hoist(letters, x, y, h, gap) {
    var g = gap === undefined ? 3 : gap;
    var cx = x;
    for (var i = 0; i < letters.length; i++) cx += flag(letters[i], cx, y, h) + g;
    return cx - x - g;
  }

  /**
   * How wide `hoist` WILL be, without drawing it — so a caller can centre one.
   * ⛔ DERIVED FROM THE SAME SHEET METADATA `flag()` USES, never from a typed aspect ratio. A
   * caller that centres on a guessed 2:3 is holding a copy of a measurement, which master §2b
   * records as the defect that shipped a listing claiming half the pack it was selling: an assert
   * (or a layout) must RE-DERIVE, never restate. If the flag sheet is regenerated at a different
   * cell aspect this follows it and a hard-coded guess silently goes off-centre.
   */
  function hoistWidth(letters, h, gap) {
    var s = sheets.flags;
    if (!s) return 0;
    var g = gap === undefined ? 3 : gap;
    var per = Math.round(h * (s.meta.cw / s.meta.ch));
    var drawn = 0;
    for (var i = 0; i < letters.length; i++) {
      if (s.meta.order.indexOf(letters[i]) >= 0) drawn++;
    }
    return drawn ? drawn * per + (drawn - 1) * g : 0;
  }

  /** A vessel silhouette. `lit` picks the "in the beam" row; otherwise the shadow row. */
  function vessel(key, x, y, w, lit) {
    var s = sheets.vessels;
    if (!s) return 0;
    var i = s.meta.order.indexOf(key);
    if (i < 0) return 0;
    var cw = s.meta.cw, ch = s.meta.ch;
    var h = Math.round(w * (ch / cw));
    ctx.drawImage(s.img, i * cw, (lit ? 1 : 0) * ch, cw, ch, Math.round(x), Math.round(y), w, h);
    API._artRect('vessel:' + key, x, y, w, h);
    return h;
  }
  function vesselWaterline() { return sheets.vessels ? sheets.vessels.meta.waterline : 0.78; }

  /**
   * The metadata a sheet was loaded with — its cell size, its waterline, and the ORDER its cells
   * are in. Read-only for callers that need to enumerate a sheet rather than draw one thing from
   * it (the store's "every flag and every rig" plate).
   * ⚠️ Returns the LIVE object, so a caller must not mutate it — but a copy would be a second
   * truth, and this file's whole argument is that there is one.
   */
  function sheetMeta(name) { return sheets[name] ? sheets[name].meta : null; }

  var API = {
    INK: INK, FONT: FONT,
    init: init, loadAll: loadAll, isLoaded: isLoaded,
    plate: plate, rect: rect, line: line, wash: wash,
    text: text, measure: measure, wrap: wrap, paragraph: paragraph, paragraphHeight: paragraphHeight,
    button: button, hitTest: hitTest, zone: zone, beginFrame: beginFrame,
    flag: flag, hoist: hoist, hoistWidth: hoistWidth, vessel: vessel, vesselWaterline: vesselWaterline,
    sheetMeta: sheetMeta,
    ctx: function () { return ctx; }, size: function () { return { w: W, h: H }; },
    /* hooks the layout gate replaces; no-ops in the shipped game.
     * ⛔ `_artRect` exists because the gate was BLIND TO ART and stayed clean over eight vessel
     * silhouettes piled into one unreadable mass — §3e-3's "blind to controls" defect, one layer
     * along. A gate that only records strings can only find string bugs. */
    _buttonRect: function () {},
    _artRect: function () {}
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  else root.ART = API;
})(typeof window !== 'undefined' ? window : globalThis);
