/* MAKE YOUR NUMBER — words.js : how the night says what it knows.
 *
 * ⛔ THIS FILE IS A MISSING INTERFACE, NOT A DECORATION. Every clue kind in `case.js` renders itself
 *    through a naming service it calls `S`:
 *
 *        text: function (k, S) { return S.name(k.a.c, k.a.v) + ' passed ' + S.ordinal(k.b) + '.'; }
 *
 *    and nothing in the project implemented `S`. The solver, the generator and the whole headless
 *    suite never needed it — they compare ids — so 104 green assertions sat on top of six `text`
 *    functions that had never once been called. This is that interface, plus the vocabulary it
 *    needs, and it has its own suite because a clue the player cannot read is a clue that does not
 *    exist however provably load bearing it is.
 *
 * THE VOICE. A keeper writes in a log book, in the past tense, plainly. "The barque carried salt."
 * Not "Vessel 1 (rig=barque) has cargo=salt". The prose IS the evidence, so it has to read like a
 * sentence somebody wrote at three in the morning with cold hands.
 *
 * ⚠️ AND ONE GENUINE VOCABULARY TRAP, which is why `cargo` does not simply take "the coal ship":
 *    COLLIER IS BOTH A RIG AND A COAL CARRIER. "The collier carried coal" is either a tautology or
 *    a contradiction depending on which sense you read, and a deduction game cannot afford either.
 *    Cargoes are therefore named by their goods and never by the trade ("the coal boat"), and the
 *    suite asserts that no two categories can ever produce the same noun phrase.
 *
 *   node Wings/GamesLite/Projects/MakeYourNumber/Product_Release/js/words.js --self-test
 */
(function (root) {
  'use strict';

  var C = (typeof require !== 'undefined' && typeof module !== 'undefined') ? require('./case.js') : root.MYNCASE;

  /* ------------------------------------------------------------------ the vocabulary
   * One entry per value of every category in `case.js`. `the` is the noun phrase a clue uses; the
   * short form is what fits in a grid header at reading size.
   */
  var RIG = {
    barque:   { the: 'the barque',   short: 'BARQUE' },
    brig:     { the: 'the brig',     short: 'BRIG' },
    schooner: { the: 'the schooner', short: 'SCHOONER' },
    ketch:    { the: 'the ketch',    short: 'KETCH' },
    collier:  { the: 'the collier',  short: 'COLLIER' },
    steamer:  { the: 'the steamer',  short: 'STEAMER' },
    lugger:   { the: 'the lugger',   short: 'LUGGER' },
    smack:    { the: 'the smack',    short: 'SMACK' }
  };
  /* ⛔ A CARGO NEEDS TWO FORMS, AND THAT IS THE COLLIER TRAP'S ACTUAL SOLUTION.
   * As an OBJECT a cargo is bare goods — "was carrying coal". As a SUBJECT it needs a noun phrase,
   * and the obvious one is poisoned: "the coal ship" is what a COLLIER is, so a player who knows
   * the word would read a rig clue and a cargo clue as the same statement. Every "<goods> ship /
   * boat / carrier" form has the same disease. "The one carrying coal" has no rig sense at all,
   * cannot be confused with anything in the rig column, and is how a keeper would actually have
   * written it. The suite asserts no cargo subject collides with any rig phrase. */
  var CARGO = {
    coal:   { the: 'the one carrying coal',   object: 'coal',   short: 'COAL' },
    timber: { the: 'the one carrying timber', object: 'timber', short: 'TIMBER' },
    salt:   { the: 'the one carrying salt',   object: 'salt',   short: 'SALT' },
    grain:  { the: 'the one carrying grain',  object: 'grain',  short: 'GRAIN' },
    hides:  { the: 'the one carrying hides',  object: 'hides',  short: 'HIDES' },
    lime:   { the: 'the one carrying lime',   object: 'lime',   short: 'LIME' },
    iron:   { the: 'the one carrying iron',   object: 'iron',   short: 'IRON' },
    wool:   { the: 'the one carrying wool',   object: 'wool',   short: 'WOOL' }
  };
  var PORT = {
    whitby:    { the: 'the Whitby boat',    short: 'WHITBY' },
    brixham:   { the: 'the Brixham boat',   short: 'BRIXHAM' },
    peterhead: { the: 'the Peterhead boat', short: 'PETERHEAD' },
    appledore: { the: 'the Appledore boat', short: 'APPLEDORE' },
    maldon:    { the: 'the Maldon boat',    short: 'MALDON' },
    girvan:    { the: 'the Girvan boat',    short: 'GIRVAN' },
    padstow:   { the: 'the Padstow boat',   short: 'PADSTOW' },
    wick:      { the: 'the Wick boat',      short: 'WICK' }
  };
  /* A vessel's NUMBER is the two-flag hoist it flies, which is where the title comes from: to
   * "make your number" is to identify yourself to a station by hoisting your signal letters. */
  var NUMBER = {
    NF: { short: 'NF' }, QH: { short: 'QH' }, RJ: { short: 'RJ' }, TB: { short: 'TB' },
    VD: { short: 'VD' }, WK: { short: 'WK' }, XM: { short: 'XM' }, ZP: { short: 'ZP' }
  };

  var BOOK = { rig: RIG, cargo: CARGO, port: PORT, number: NUMBER };

  var ORDINALS = ['first', 'second', 'third', 'fourth', 'fifth', 'sixth', 'seventh', 'eighth'];

  /* ------------------------------------------------------------------ the service
   * `spec` carries `cats` — the category ids in play tonight — so the service has to map a night's
   * LOCAL category index onto the global vocabulary. Getting that wrong silently renames every
   * vessel on a three-category night, which is exactly the sort of defect that reads as a bad
   * generator rather than a bad lookup.
   */
  /* ⛔ `spec.cats` IS AN ARRAY OF CATEGORY OBJECTS, NOT OF IDS — and this function assumed ids and
   * threw `words.js knows no category "[object Object]"` the first time it was handed a real spec.
   * It passed its own suite because the SUITE BUILT THE SPEC BY HAND as `{cats:['rig','cargo']}`.
   * That is the fixture lying about the system it stands in for, so the suite now takes its specs
   * from `gen.makeSpec` like the game does, and this accepts either shape.
   * ⚠️ And it must read the values off the SPEC, not off `C.CATEGORIES`: makeSpec slices each
   * category to the night's berth count, so the global list is longer than tonight's. */
  function service(spec) {
    var cats = spec.cats.map(function (c) {
      if (c && typeof c === 'object' && c.values) return c;
      for (var i = 0; i < C.CATEGORIES.length; i++) if (C.CATEGORIES[i].id === c) return C.CATEGORIES[i];
      throw new Error('words.js knows no category "' + c + '"');
    });
    function entry(c, v) {
      var cat = cats[c];
      if (!cat) throw new Error('no category at index ' + c + ' on a night of ' + cats.length);
      var key = cat.values[v];
      if (key === undefined) throw new Error('no value at index ' + v + ' of ' + cat.id);
      var e = BOOK[cat.id][key];
      if (!e) throw new Error('words.js has no word for ' + cat.id + '.' + key);
      return { cat: cat, key: key, e: e };
    }
    return {
      cats: cats,
      /* the noun phrase a clue uses */
      name: function (c, v) {
        var x = entry(c, v);
        return x.cat.id === 'number' ? 'the vessel flying ' + x.e.short : x.e.the;
      },
      /* the grid label */
      short: function (c, v) { return entry(c, v).e.short; },
      /* the category's own heading */
      catLabel: function (c) { return cats[c].label; },
      catId: function (c) { return cats[c].id; },
      ordinal: function (b) { return ORDINALS[b] || (b + 1) + 'th'; },
      /* ⛔ THE PAIRING SENTENCE. `same`/`notSame` say two attributes belong to one vessel, and the
       * generator will pair any two categories — so the sentence has to be built from what the two
       * sides ARE, not from an assumption about which column the object came from. A cargo is
       * CARRIED; everything else simply IS. */
      carries: function (a, b, negated) {
        var subj = this.name(a.c, a.v);
        var objE = entry(b.c, b.v);
        if (objE.cat.id === 'cargo') {
          return subj + (negated ? ' was not carrying ' : ' was carrying ') + objE.e.object + '.';
        }
        /* a cargo on the LEFT is fine — "the one carrying salt was the Whitby boat" */
        return subj + (negated ? ' was not ' : ' was ') + this.name(b.c, b.v) + '.';
      },
      /* the two signal flags a NUMBER is flown as — this is what ties the flag art to the game */
      hoist: function (c, v) {
        var x = entry(c, v);
        return x.cat.id === 'number' ? x.e.short.split('') : null;
      }
    };
  }

  /**
   * Render one clue as the sentence a keeper would have written.
   *
   * ⚠️ CAPITALISATION BELONGS HERE, NOT IN THE VOCABULARY. Every noun phrase is lower case because
   * most of them appear mid-sentence ("...passed before the ketch"), so the one that happens to
   * land first is capitalised by the SENTENCE builder. Storing "The barque" in the table would have
   * put a capital in the middle of five of the six clue shapes.
   */
  function clueText(clue, S) {
    var kind = C.CLUE[clue.kind];
    if (!kind) throw new Error('no such clue kind: ' + clue.kind);
    var t = kind.text(clue, S);
    if (typeof t !== 'string' || !t.length) throw new Error('clue kind ' + clue.kind + ' rendered nothing');
    return t.charAt(0).toUpperCase() + t.slice(1);
  }

  /* ------------------------------------------------------------------------- suite */
  function selfTest() {
    var pass = 0, fail = 0;
    var ok = function (n, c, e) { if (c) { pass++; console.log('  ok   ' + n); } else { fail++; console.log('  FAIL ' + n + (e ? '  — ' + e : '')); } };
    console.log('MAKE YOUR NUMBER — words\n');

    /* ⛔ EVERY value of EVERY category must have a word, or a night that happens to use it renders
     * as `undefined` in the middle of the evidence — the failure this factory has shipped to a live
     * store page twice (master §2b). Checked against case.js rather than against a hand list. */
    var missing = [];
    for (var i = 0; i < C.CATEGORIES.length; i++) {
      var cat = C.CATEGORIES[i];
      if (!BOOK[cat.id]) { missing.push('whole category ' + cat.id); continue; }
      for (var j = 0; j < cat.values.length; j++) {
        if (!BOOK[cat.id][cat.values[j]]) missing.push(cat.id + '.' + cat.values[j]);
      }
    }
    ok('⛔ every value of every category in case.js has a word', missing.length === 0, missing.join(', '));
    ok('...and that check was not vacuous', C.CATEGORIES.length === 4 &&
      C.CATEGORIES.reduce(function (a, c) { return a + c.values.length; }, 0) === 32);

    /* ⛔ and no extras — a word for a value that no longer exists is a table drifting away from
     * the code it describes, which is the same defect pointing the other way */
    var orphans = [];
    for (var id in BOOK) {
      var real = null;
      for (var q = 0; q < C.CATEGORIES.length; q++) if (C.CATEGORIES[q].id === id) real = C.CATEGORIES[q];
      if (!real) { orphans.push('category ' + id); continue; }
      for (var k in BOOK[id]) if (real.values.indexOf(k) < 0) orphans.push(id + '.' + k);
    }
    ok('...and no orphan words for values case.js no longer has', orphans.length === 0, orphans.join(', '));

    /* ⛔ TAKE THE SPEC FROM THE GENERATOR, THE WAY THE GAME DOES. A hand-built `{cats:['rig',...]}`
     * is not the object this service is given at runtime, and building one here is what let a
     * type error reach the browser with 17 assertions green. */
    var G = (typeof require !== 'undefined' && typeof module !== 'undefined') ? require('./gen.js') : root.MYNGEN;
    var S = service(G.makeSpec(6, ['rig', 'cargo', 'port', 'number']));
    ok('⛔ the suite drives a REAL spec from gen.makeSpec, not a hand-built one',
      typeof G.makeSpec(4, ['rig', 'port']).cats[0] === 'object');
    ok('...and a legacy id-array spec still works, so nothing that passed one is broken',
      service({ n: 4, cats: ['rig', 'port'] }).catId(1) === 'port');

    /* ⛔ THE COLLIER TRAP. No two categories may produce the same noun phrase, or a clue becomes
     * ambiguous in a game whose entire content is unambiguous clues. */
    /* ⚠️ A NIGHT'S SPEC IS SLICED TO ITS BERTH COUNT, so the 6-berth service above can only see 6
     * of the 8 values per category. The vocabulary collision test must cover ALL of them, so it
     * takes a full-size spec of its own — otherwise two colliding phrases in the 7th or 8th value
     * would never be compared. */
    var SFull = service(G.makeSpec(8, ['rig', 'cargo', 'port', 'number']));
    var seen = {}, clash = [];
    for (var c = 0; c < 4; c++) for (var v = 0; v < 8; v++) {
      var nm = SFull.name(c, v);
      if (seen[nm]) clash.push(nm + ' is both ' + seen[nm] + ' and ' + SFull.catId(c));
      seen[nm] = SFull.catId(c);
    }
    ok('⛔ no two categories produce the same noun phrase (the collier/coal trap)',
      clash.length === 0, clash.join(' · '));
    ok('...and it compared a real set', Object.keys(seen).length === 32);

    /* every clue kind must render, with no undefined anywhere in the sentence */
    var kinds = Object.keys(C.CLUE);
    var samples = {
      same:    { kind: 'same',    a: { c: 0, v: 0 }, b: { c: 1, v: 2 } },
      notSame: { kind: 'notSame', a: { c: 0, v: 4 }, b: { c: 1, v: 0 } },
      berth:   { kind: 'berth',   a: { c: 0, v: 2 }, b: 2 },
      before:  { kind: 'before',  a: { c: 1, v: 3 }, b: { c: 0, v: 3 } },
      nextTo:  { kind: 'nextTo',  a: { c: 3, v: 0 }, b: { c: 2, v: 1 } },
      /* ⚠️ every index here must be inside the 6-berth spec above — `v: 7` threw, correctly, and
       * that is the same class of mistake as the hand-built spec: a fixture describing a night the
       * generator would never produce */
      gap:     { kind: 'gap',     a: { c: 1, v: 2 }, b: { c: 2, v: 5 }, d: 2 }
    };
    var bad = [];
    ok('the suite has a sample for every clue kind case.js defines — no kind goes unrendered',
      kinds.every(function (k) { return !!samples[k]; }), kinds.join(','));

    /* ⛔ `same`/`notSame` MUST READ FOR EVERY PAIRING THE GENERATOR CAN PRODUCE, not just the
     * rig/cargo one the original sentence was written for. This is the assertion that would have
     * caught "the Whitby boat carried the vessel flying NF". */
    var pairBad = [];
    for (var pa = 0; pa < 4; pa++) for (var pb = 0; pb < 4; pb++) {
      if (pa === pb) continue;
      for (var neg = 0; neg < 2; neg++) {
        var sent = clueText({ kind: neg ? 'notSame' : 'same', a: { c: pa, v: 1 }, b: { c: pb, v: 3 } }, S);
        /* ⚠️ MATCH THE VERB, NOT THE WORD. A bare /carrying/ test is a false red: the cargo SUBJECT
         * phrase is "the one carrying timber", so every clue with a cargo on the LEFT contains the
         * word legitimately. What must track the object's column is the predicate " was carrying ". */
        var carried = / was (?:not )?carrying /.test(sent);
        if (carried && S.catId(pb) !== 'cargo') pairBad.push(S.catId(pa) + '->' + S.catId(pb) + ': ' + sent);
        if (!carried && S.catId(pb) === 'cargo') pairBad.push('cargo not carried: ' + sent);
        if (/undefined/.test(sent)) pairBad.push(sent);
      }
    }
    ok('⛔ `same`/`notSame` read correctly for ALL 12 category pairings, both signs',
      pairBad.length === 0, pairBad.slice(0, 3).join(' · '));

    /* ⛔ and the cargo SUBJECT must not collide with any rig phrase — the collier trap proper */
    var rigPhrases = {};
    for (var rv = 0; rv < 8; rv++) rigPhrases[SFull.name(0, rv)] = true;
    var collide = [];
    for (var cv = 0; cv < 8; cv++) if (rigPhrases[SFull.name(1, cv)]) collide.push(SFull.name(1, cv));
    ok('⛔ no cargo subject phrase is also a rig phrase (the collier/coal-ship trap)',
      collide.length === 0, collide.join(', '));
    ok('...and no cargo subject contains a rig word at all, so none can be MISREAD as one',
      !Object.keys(BOOK.cargo).some(function (k) {
        return Object.keys(BOOK.rig).some(function (r) { return BOOK.cargo[k].the.indexOf(r) >= 0; });
      }), Object.keys(BOOK.cargo).map(function (k) { return BOOK.cargo[k].the; }).join(' | '));
    for (var ki = 0; ki < kinds.length; ki++) {
      var t;
      try { t = clueText(samples[kinds[ki]], S); } catch (err) { bad.push(kinds[ki] + ' threw: ' + err.message); continue; }
      if (/undefined|NaN|\[object/.test(t)) bad.push(kinds[ki] + ' -> ' + t);
      if (!/^[A-Z]/.test(t)) bad.push(kinds[ki] + ' does not start with a capital: ' + t);
      if (!/\.$/.test(t)) bad.push(kinds[ki] + ' does not end in a full stop: ' + t);
      if (t.length < 18) bad.push(kinds[ki] + ' is suspiciously short: ' + t);
    }
    ok('⛔ every clue kind renders a real sentence — no undefined, capitalised, stopped',
      bad.length === 0, bad.join(' · '));

    /* ...and the renderer must be able to FAIL. A check that has only ever gone green is a line of
     * output, not a gate (wing §3e-3). */
    ok('...and a clue naming a value that does not exist is REFUSED, not rendered as undefined',
      (function () {
        try { clueText({ kind: 'berth', a: { c: 0, v: 99 }, b: 1 }, S); return false; }
        catch (e) { return true; }
      })());
    ok('...and an unknown clue kind is REFUSED', (function () {
      try { clueText({ kind: 'nonsense', a: { c: 0, v: 0 }, b: 0 }, S); return false; } catch (e) { return true; }
    })());

    /* ⛔ a night that does not use all four categories must still name things correctly — the local
     * index must be mapped through spec.cats, not assumed equal to the global one */
    var S3 = service(G.makeSpec(4, ['rig', 'port']));
    ok('⛔ on a night with a subset of categories, index 1 is that night\'s SECOND category',
      S3.name(1, 0) === 'the Whitby boat' && S3.catId(1) === 'port',
      S3.name(1, 0) + ' / ' + S3.catId(1));
    ok('...and the four-category service still reads index 1 as cargo (so the mapping is real)',
      S.catId(1) === 'cargo' && S.name(1, 0) === 'the one carrying coal',
      S.catId(1) + ' / ' + S.name(1, 0));

    ok('ordinals cover the largest night the sim can build (8 berths)',
      ORDINALS.length >= 8 && S.ordinal(7) === 'eighth');
    ok('a NUMBER names its two signal flags, and they are real flag keys',
      (function () {
        var h = S.hoist(3, 0);
        return h && h.length === 2 && h[0] === 'N' && h[1] === 'F';
      })());
    ok('...and a non-number category has no hoist', S.hoist(0, 0) === null);

    /* the sentences a player actually reads, printed so a human can judge the voice */
    console.log('\n  the six clue shapes, as a keeper would have written them:');
    for (var z = 0; z < kinds.length; z++) console.log('    ' + clueText(samples[kinds[z]], S));

    console.log('\n  ' + pass + ' passed, ' + fail + ' failed  (' + (pass + fail) + ' assertions)');
    return fail === 0 ? 0 : 1;
  }

  var API = { BOOK: BOOK, ORDINALS: ORDINALS, service: service, clueText: clueText, selfTest: selfTest };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  else root.MYNWORDS = API;
  if (typeof require !== 'undefined' && typeof module !== 'undefined' && require.main === module) process.exitCode = selfTest();
})(typeof window !== 'undefined' ? window : globalThis);
