/* MAKE YOUR NUMBER — gen.js : generating a night that has exactly one answer.
 *
 * ⛔ THE WHOLE PRODUCT RESTS ON ONE GUARANTEE: the case handed to the player has ONE solution, and
 *    the evidence given is enough to reach it by reasoning alone. Everything here exists to make
 *    that true by CONSTRUCTION rather than by hope:
 *
 *      1. Draw a solution first — a random permutation per category. It is by definition consistent.
 *      2. Build a large pool of clues that are TRUE OF THAT SOLUTION. Nothing false can enter, so
 *         the case is satisfiable before any pruning starts.
 *      3. Confirm the full pool pins it to exactly one answer. (It always should; asserting it
 *         anyway is what catches a clue whose `apply` disagrees with its own `holds`.)
 *      4. MINIMISE: walk the pool in a shuffled order and drop each clue only while the solver
 *         still reports exactly ONE solution. What is left is a set where every clue is load
 *         bearing — remove any one and the night becomes ambiguous.
 *
 * ⭐ STEP 4 IS ALSO THE DIFFICULTY DIAL, and that is the point the candidate record made: difficulty
 *    is HOW MUCH EVIDENCE IS WITHHELD, not a timer and not a bigger grid. Stopping the minimiser
 *    early leaves a generous night; running it to the end leaves one where every single observation
 *    matters and losing one to the fog costs the case.
 *
 * ⚠️ A minimal set is not necessarily the SMALLEST set — that is NP-hard and not worth it. It is a
 *    set with no removable member, which is the property the game actually needs.
 */
(function (root) {
  'use strict';

  var C = (typeof require !== 'undefined' && typeof module !== 'undefined') ? require('./case.js') : root.MYNCASE;

  function rng(seed) {
    var s = (seed >>> 0) || 1;
    return function () { s ^= s << 13; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
  }
  function shuffle(a, rnd) {
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rnd() * (i + 1)) % (i + 1); var t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }

  /** A night's shape: how many berths, and which categories are in play. */
  function makeSpec(n, catIds) {
    var cats = C.CATEGORIES.filter(function (c) { return catIds.indexOf(c.id) >= 0; })
      .map(function (c) { return { id: c.id, label: c.label, values: c.values.slice(0, n) }; });
    if (cats.length !== catIds.length) throw new Error('makeSpec: unknown category in ' + catIds.join(','));
    if (n < 3) throw new Error('makeSpec: a night needs at least three berths');
    return { n: n, cats: cats };
  }

  /** sol[c][v] = the berth value v of category c occupies. */
  function drawSolution(spec, rnd) {
    var sol = [];
    for (var c = 0; c < spec.cats.length; c++) {
      var berths = [];
      for (var b = 0; b < spec.n; b++) berths.push(b);
      sol.push(shuffle(berths, rnd));
    }
    return sol;
  }

  /**
   * Every clue in the pool is TRUE OF `sol` by construction — it is read OFF the solution rather
   * than proposed and tested. A pool built the other way round is how a generator ends up
   * occasionally emitting an unsatisfiable case.
   */
  function buildPool(spec, sol, rnd) {
    var pool = [], n = spec.n, nc = spec.cats.length;
    var push = function (k) { pool.push(k); };

    for (var c1 = 0; c1 < nc; c1++) {
      for (var v1 = 0; v1 < n; v1++) {
        var b1 = sol[c1][v1];
        push({ kind: 'berth', a: { c: c1, v: v1 }, b: b1 });
        for (var c2 = 0; c2 < nc; c2++) {
          if (c2 === c1) continue;
          for (var v2 = 0; v2 < n; v2++) {
            var b2 = sol[c2][v2];
            if (b1 === b2) { push({ kind: 'same', a: { c: c1, v: v1 }, b: { c: c2, v: v2 } }); continue; }
            /* a negative is cheap and there are n^2 of them per pair of categories, so only a
               sample rides in the pool — otherwise the minimiser spends all its time on clues that
               almost never pin anything */
            if (rnd() < 0.22) push({ kind: 'notSame', a: { c: c1, v: v1 }, b: { c: c2, v: v2 } });
            if (b1 < b2 && rnd() < 0.55) push({ kind: 'before', a: { c: c1, v: v1 }, b: { c: c2, v: v2 } });
            if (b1 === b2 + 1) push({ kind: 'nextTo', a: { c: c1, v: v1 }, b: { c: c2, v: v2 } });
            var d = Math.abs(b1 - b2);
            if (d >= 2 && rnd() < 0.5) push({ kind: 'gap', a: { c: c1, v: v1 }, b: { c: c2, v: v2 }, d: d });
          }
        }
      }
    }
    /* same-category orderings read naturally and are the ones a keeper would actually log */
    for (var c = 0; c < nc; c++) {
      for (var x = 0; x < n; x++) for (var y = 0; y < n; y++) {
        if (x === y) continue;
        if (sol[c][x] === sol[c][y] + 1) push({ kind: 'nextTo', a: { c: c, v: x }, b: { c: c, v: y } });
        else if (sol[c][x] < sol[c][y] && rnd() < 0.35) push({ kind: 'before', a: { c: c, v: x }, b: { c: c, v: y } });
      }
    }
    return shuffle(pool, rnd);
  }

  /**
   * ⭐ NO GUESSING. Is this clue set closable by ELIMINATION ALONE — no case-splitting, no "assume
   * it is the brig and see what breaks"?
   *
   * ⛔ THIS IS A FAIRNESS PROPERTY AND IT WAS FOUND BY MEASURING, NOT BY TASTE. A probe over the
   * hardest authored night showed nights whose collected evidence pinned exactly ONE answer while
   * pure propagation determined NOTHING AT ALL — 0 of 24 cells (`_probe_equinoctial.js`, seed 4).
   * Those cases are uniquely solvable and they are only solvable by branching in your head, which
   * for a puzzle player is the definition of an unfair puzzle: you cannot get there by reasoning
   * from the grid, you get there by trying things. The player's log IS the propagation view
   * (`sim.js` narrows the same grid `case.js` does), so a night that needs branching is a night the
   * game gives you no tool for.
   *
   * ⇒ The minimiser therefore only removes a clue while the remainder is BOTH uniquely solvable AND
   * closable by propagation. That leaves more clues than a pure minimiser would, and that is the
   * right trade: "every night can be reasoned out without guessing" is a promise worth more than a
   * smaller clue count.
   */
  function propagable(spec, clues) {
    var g = C.newGrid(spec);
    if (!C.propagate(g, clues)) return false;
    return C.isSolved(g);
  }

  /* ⚠️ THE TWO CHECKS ARE CALLED THROUGH THE EXPORTED OBJECT, DELIBERATELY. A suite proves a guard
     is load bearing by breaking it and requiring the breakage to show — and replacing a module's
     EXPORT does not replace an internal binding, so a sabotage arm aimed at `propagable` went green
     while the real function carried on guarding. That is master §2b's "find the READER" wearing a
     test's clothing: the sabotage was measuring nothing and said so only because the arm was
     required to fire. One level of indirection makes both guarantees provably necessary. */
  function accepts(spec, clues, noGuessing) {
    if (C.solve(spec, clues).count !== 1) return false;
    if (noGuessing && !API.propagable(spec, clues)) return false;
    return true;
  }

  /**
   * Generate a night.
   *   opts.keep — 0..1. 0 minimises fully (the hardest, most brittle night); 0.5 stops the
   *               minimiser half way and leaves a generous one. This IS the difficulty dial.
   * Returns { spec, sol, clues, stats } or null if the seed produced nothing usable.
   */
  function generate(spec, seed, opts) {
    var o = opts || {};
    var rnd = rng(seed);
    var sol = drawSolution(spec, rnd);
    var pool = buildPool(spec, sol, rnd);

    /* ⛔ ASSERT THE POOL ITSELF PINS THE ANSWER before removing anything. If it does not, a clue's
       `apply` disagrees with its own `holds` and every night this generator makes is suspect —
       that is a defect to surface, never to retry past. */
    var full = C.solve(spec, pool);
    if (full.count !== 1) return { failed: 'the full clue pool admits ' + full.count + ' solutions', spec: spec, sol: sol };

    var keep = o.keep === undefined ? 0 : o.keep;
    var noGuessing = o.noGuessing === undefined ? true : !!o.noGuessing;
    var stopAt = Math.floor(pool.length * keep);
    var clues = pool.slice();
    var tried = 0, removed = 0;
    for (var i = 0; i < pool.length && clues.length > stopAt; i++) {
      var candidate = pool[i];
      var idx = clues.indexOf(candidate);
      if (idx < 0) continue;
      var without = clues.slice(0, idx).concat(clues.slice(idx + 1));
      tried++;
      if (accepts(spec, without, noGuessing)) { clues = without; removed++; }
    }

    return {
      spec: spec, sol: sol, clues: clues, noGuessing: noGuessing,
      propagable: propagable(spec, clues),
      stats: { poolSize: pool.length, tried: tried, removed: removed, kept: clues.length, nodes: full.nodes }
    };
  }

  /** Is every clue in this set load bearing under the SAME acceptance test the minimiser used? */
  function everyClueLoadBearing(spec, clues, noGuessing) {
    var ng = noGuessing === undefined ? true : !!noGuessing;
    for (var i = 0; i < clues.length; i++) {
      var without = clues.slice(0, i).concat(clues.slice(i + 1));
      if (accepts(spec, without, ng)) return { ok: false, redundant: i };
    }
    return { ok: true };
  }

  var API = { rng: rng, shuffle: shuffle, makeSpec: makeSpec, drawSolution: drawSolution, buildPool: buildPool, generate: generate, everyClueLoadBearing: everyClueLoadBearing, propagable: propagable, accepts: accepts };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  else root.MYNGEN = API;
})(typeof window !== 'undefined' ? window : globalThis);
