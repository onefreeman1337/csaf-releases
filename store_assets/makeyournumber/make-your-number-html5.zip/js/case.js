/* MAKE YOUR NUMBER — case.js : the night, the solver, and the proof that it has one answer.
 *
 * ⛔ THIS FILE IS THE RISK, AND IT IS BEING WRITTEN BEFORE A SINGLE PIXEL OF ART, on purpose.
 *    A generated deduction case that is SOLVABLE but not UNIQUELY solvable ships a game that is
 *    unfair in a way players cannot articulate: they reason correctly, reach a defensible answer,
 *    and are told they are wrong. So the order here is solver first, uniqueness proof second, clue
 *    minimiser third, and everything else afterwards.
 *
 * THE SHAPE. A night is an assignment problem: N BERTHS (the order vessels pass the light, 1..N)
 * against several CATEGORIES (rig, cargo, home port, the number they fly). Every category is a
 * permutation of N distinct values across the N berths, so the whole night is a Latin-style
 * assignment and "solving it" means pinning every value to exactly one berth.
 *
 * THE SOLVER is constraint propagation over a possibility GRID — for each category, an N x N
 * boolean matrix of "value v could be at berth b" — plus a bounded search for the cases
 * propagation alone cannot close. It is the SAME structure the player is given, which is what
 * makes the game's Gate 4 second system honest: the log you rule cells out of IS the solver's grid,
 * so a difficulty setting is not a timer, it is how much evidence is withheld.
 *
 * ⛔ AND THE SOLVER MUST COUNT SOLUTIONS, NOT FIND ONE. Everything downstream depends on the
 *    difference: `solve()` returns 0, 1 or 2+ (it stops at two, because "more than one" is all the
 *    generator ever needs to know), and the generator only ever removes a clue while the count
 *    stays exactly 1.
 */
(function (root) {
  'use strict';

  /* ------------------------------------------------------------- the world
   * Categories are data so the same engine serves a three-category night and a five-category one.
   * Values are ids; the art layer decides what a `barque` or a `NF` hoist looks like.
   */
  var CATEGORIES = [
    { id: 'rig',    label: 'RIG',        values: ['barque', 'brig', 'schooner', 'ketch', 'collier', 'steamer', 'lugger', 'smack'] },
    { id: 'cargo',  label: 'CARGO',      values: ['coal', 'timber', 'salt', 'grain', 'hides', 'lime', 'iron', 'wool'] },
    { id: 'port',   label: 'HOME PORT',  values: ['whitby', 'brixham', 'peterhead', 'appledore', 'maldon', 'girvan', 'padstow', 'wick'] },
    { id: 'number', label: 'NUMBER',     values: ['NF', 'QH', 'RJ', 'TB', 'VD', 'WK', 'XM', 'ZP'] }
  ];

  /* --------------------------------------------------------------- the grid
   * grid[catIndex][valueIndex][berth] = true if that value may still be at that berth.
   */
  function newGrid(spec) {
    var g = [];
    for (var c = 0; c < spec.cats.length; c++) {
      var m = [];
      for (var v = 0; v < spec.n; v++) {
        var row = [];
        for (var b = 0; b < spec.n; b++) row.push(true);
        m.push(row);
      }
      g.push(m);
    }
    return g;
  }

  function cloneGrid(g) {
    var out = [];
    for (var c = 0; c < g.length; c++) {
      var m = [];
      for (var v = 0; v < g[c].length; v++) m.push(g[c][v].slice());
      out.push(m);
    }
    return out;
  }

  /** Where can value v of category c still be? Returns the list of berths. */
  function berthsFor(g, c, v) {
    var out = [];
    for (var b = 0; b < g[c][v].length; b++) if (g[c][v][b]) out.push(b);
    return out;
  }
  /** What values of category c can still sit at berth b? */
  function valuesAt(g, c, b) {
    var out = [];
    for (var v = 0; v < g[c].length; v++) if (g[c][v][b]) out.push(v);
    return out;
  }

  function eliminate(g, c, v, b) {
    if (!g[c][v][b]) return false;
    g[c][v][b] = false;
    return true;
  }
  /** Pin value v of category c to berth b: it is there, and nothing else is. */
  function assign(g, c, v, b) {
    var moved = false;
    for (var bb = 0; bb < g[c][v].length; bb++) if (bb !== b) moved = eliminate(g, c, v, bb) || moved;
    for (var vv = 0; vv < g[c].length; vv++) if (vv !== v) moved = eliminate(g, c, vv, b) || moved;
    return moved;
  }

  /* ------------------------------------------------------------ the clues
   * Six kinds, and every one of them is something a lighthouse keeper could actually have seen.
   * Each clue exposes `apply(grid, spec)` which narrows the grid, and `holds(sol)` which says
   * whether it is true of a candidate solution — the two must agree, and the suite checks that
   * they do by running every clue against the solution it was generated from.
   */
  var CLUE = {
    /* "The barque was carrying salt." / "The barque was the Whitby boat."
     *
     * ⛔ THIS SENTENCE USED TO BE `name(a) + ' carried ' + name(b)` AND WAS WRONG FOR MOST OF THE
     * PAIRINGS IT IS ACTUALLY GIVEN. A `same` clue says two attributes belong to one vessel, and the
     * generator pairs ANY two categories — so on a port/number pairing it read "the Whitby boat
     * carried the vessel flying NF", which is not a sentence. It survived because nothing
     * implemented `S`, so no `text` function in this file had ever been called: the 104 headless
     * assertions all compare ids. `S.carries` branches on whether the object is a CARGO, which is
     * the only category that is carried rather than described. */
    same: {
      text: function (k, S) { return S.carries(k.a, k.b, false); },
      holds: function (k, sol) { return sol[k.a.c][k.a.v] === sol[k.b.c][k.b.v]; },
      apply: function (k, g) {
        var moved = false;
        var A = berthsFor(g, k.a.c, k.a.v), B = berthsFor(g, k.b.c, k.b.v);
        for (var i = 0; i < A.length; i++) if (B.indexOf(A[i]) < 0) moved = eliminate(g, k.a.c, k.a.v, A[i]) || moved;
        for (var j = 0; j < B.length; j++) if (A.indexOf(B[j]) < 0) moved = eliminate(g, k.b.c, k.b.v, B[j]) || moved;
        return moved;
      }
    },
    /* "The collier was not carrying coal." / "The barque was not the Whitby boat." */
    notSame: {
      text: function (k, S) { return S.carries(k.a, k.b, true); },
      holds: function (k, sol) { return sol[k.a.c][k.a.v] !== sol[k.b.c][k.b.v]; },
      apply: function (k, g) {
        var moved = false;
        var A = berthsFor(g, k.a.c, k.a.v), B = berthsFor(g, k.b.c, k.b.v);
        if (A.length === 1) moved = eliminate(g, k.b.c, k.b.v, A[0]) || moved;
        if (B.length === 1) moved = eliminate(g, k.a.c, k.a.v, B[0]) || moved;
        return moved;
      }
    },
    /* "the schooner passed third" */
    berth: {
      text: function (k, S) { return S.name(k.a.c, k.a.v) + ' passed ' + S.ordinal(k.b) + '.'; },
      holds: function (k, sol) { return sol[k.a.c][k.a.v] === k.b; },
      apply: function (k, g) { return assign(g, k.a.c, k.a.v, k.b); }
    },
    /* "the grain ship passed before the ketch" */
    before: {
      text: function (k, S) { return S.name(k.a.c, k.a.v) + ' passed before ' + S.name(k.b.c, k.b.v) + '.'; },
      holds: function (k, sol) { return sol[k.a.c][k.a.v] < sol[k.b.c][k.b.v]; },
      apply: function (k, g) {
        var moved = false;
        var A = berthsFor(g, k.a.c, k.a.v), B = berthsFor(g, k.b.c, k.b.v);
        if (!A.length || !B.length) return false;
        var maxB = B[B.length - 1], minA = A[0];
        for (var i = 0; i < A.length; i++) if (A[i] >= maxB) moved = eliminate(g, k.a.c, k.a.v, A[i]) || moved;
        for (var j = 0; j < B.length; j++) if (B[j] <= minA) moved = eliminate(g, k.b.c, k.b.v, B[j]) || moved;
        return moved;
      }
    },
    /* "the timber ship passed immediately after the lugger" */
    nextTo: {
      text: function (k, S) { return S.name(k.a.c, k.a.v) + ' passed immediately after ' + S.name(k.b.c, k.b.v) + '.'; },
      holds: function (k, sol) { return sol[k.a.c][k.a.v] === sol[k.b.c][k.b.v] + 1; },
      apply: function (k, g) {
        var moved = false;
        var A = berthsFor(g, k.a.c, k.a.v), B = berthsFor(g, k.b.c, k.b.v);
        for (var i = 0; i < A.length; i++) if (B.indexOf(A[i] - 1) < 0) moved = eliminate(g, k.a.c, k.a.v, A[i]) || moved;
        for (var j = 0; j < B.length; j++) if (A.indexOf(B[j] + 1) < 0) moved = eliminate(g, k.b.c, k.b.v, B[j]) || moved;
        return moved;
      }
    },
    /* "there was exactly one vessel between the salt ship and Wick's" */
    gap: {
      text: function (k, S) {
        return 'There ' + (k.d === 2 ? 'was one vessel' : 'were ' + (k.d - 1) + ' vessels') + ' between '
          + S.name(k.a.c, k.a.v) + ' and ' + S.name(k.b.c, k.b.v) + '.';
      },
      holds: function (k, sol) { return Math.abs(sol[k.a.c][k.a.v] - sol[k.b.c][k.b.v]) === k.d; },
      apply: function (k, g) {
        var moved = false;
        var A = berthsFor(g, k.a.c, k.a.v), B = berthsFor(g, k.b.c, k.b.v);
        for (var i = 0; i < A.length; i++) {
          if (B.indexOf(A[i] - k.d) < 0 && B.indexOf(A[i] + k.d) < 0) moved = eliminate(g, k.a.c, k.a.v, A[i]) || moved;
        }
        for (var j = 0; j < B.length; j++) {
          if (A.indexOf(B[j] - k.d) < 0 && A.indexOf(B[j] + k.d) < 0) moved = eliminate(g, k.b.c, k.b.v, B[j]) || moved;
        }
        return moved;
      }
    }
  };

  /* --------------------------------------------------------- propagation
   * Run every clue to fixpoint, plus the two structural rules that make this an assignment problem
   * at all: a value with one remaining berth OWNS it, and a berth with one remaining candidate in a
   * category is PINNED to it.
   */
  function propagate(g, clues) {
    var guard = 0;
    for (;;) {
      var moved = false;
      for (var i = 0; i < clues.length; i++) {
        var k = clues[i];
        if (CLUE[k.kind].apply(k, g)) moved = true;
      }
      for (var c = 0; c < g.length; c++) {
        for (var v = 0; v < g[c].length; v++) {
          var bs = berthsFor(g, c, v);
          if (bs.length === 0) return false;                 // contradiction
          if (bs.length === 1 && assign(g, c, v, bs[0])) moved = true;
        }
        for (var b = 0; b < g[c].length; b++) {
          var vs = valuesAt(g, c, b);
          if (vs.length === 0) return false;                 // contradiction
          if (vs.length === 1 && assign(g, c, vs[0], b)) moved = true;
        }
      }
      if (!moved) return true;
      if (++guard > 400) return true;                        // cannot loop forever on a fixpoint
    }
  }

  function isSolved(g) {
    for (var c = 0; c < g.length; c++) for (var v = 0; v < g[c].length; v++) {
      if (berthsFor(g, c, v).length !== 1) return false;
    }
    return true;
  }

  function readSolution(g) {
    var sol = [];
    for (var c = 0; c < g.length; c++) {
      var row = [];
      for (var v = 0; v < g[c].length; v++) row.push(berthsFor(g, c, v)[0]);
      sol.push(row);
    }
    return sol;
  }

  /**
   * ⛔ COUNT SOLUTIONS, DO NOT FIND ONE. Returns { count, solution } with count capped at 2 —
   * "more than one" is all the generator ever needs, and stopping at two keeps the search cheap.
   * Propagation first, then branch on the most constrained open cell.
   */
  function solve(spec, clues, capIn) {
    var cap = capIn || 2;
    var found = [];
    var nodes = 0;

    function search(g) {
      if (found.length >= cap) return;
      if (++nodes > 200000) return;                          // a runaway search is a defect, not a wait
      if (!propagate(g, clues)) return;
      if (isSolved(g)) { found.push(readSolution(g)); return; }
      /* branch on the value with the fewest remaining berths — standard MRV, and it is what keeps
         an eight-berth four-category night inside a browser frame */
      var bc = -1, bv = -1, best = 1e9;
      for (var c = 0; c < g.length; c++) for (var v = 0; v < g[c].length; v++) {
        var n = berthsFor(g, c, v).length;
        if (n > 1 && n < best) { best = n; bc = c; bv = v; }
      }
      if (bc < 0) return;
      var opts = berthsFor(g, bc, bv);
      for (var i = 0; i < opts.length && found.length < cap; i++) {
        var h = cloneGrid(g);
        assign(h, bc, bv, opts[i]);
        search(h);
      }
    }

    search(newGrid(spec));
    return { count: found.length, solution: found[0] || null, nodes: nodes };
  }

  /** Does a clue hold of a solution? The generator and the suite both lean on this. */
  function holds(k, sol) { return CLUE[k.kind].holds(k, sol); }

  var API = {
    CATEGORIES: CATEGORIES, CLUE: CLUE,
    newGrid: newGrid, cloneGrid: cloneGrid, berthsFor: berthsFor, valuesAt: valuesAt,
    eliminate: eliminate, assign: assign, propagate: propagate, isSolved: isSolved,
    readSolution: readSolution, solve: solve, holds: holds
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  else root.MYNCASE = API;
})(typeof window !== 'undefined' ? window : globalThis);
