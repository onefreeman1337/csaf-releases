// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

using UnrealBuildTool;

/// <summary>
/// Niagara Bounds Solver: asset discovery, the headless lifetime simulation, the union solver,
/// the batch write with its undo journal, the HTML report, and both entry points.
///
/// EVERY MODULE NAME BELOW WAS READ OUT OF THE INSTALLED UE 5.8 TREE RATHER THAN GUESSED, with
/// the file and line that justifies it. This wing has measured a packaging cycle parking for over
/// two hours without reaching a compile action, so one wrong string costs a session.
/// </summary>
public class NiagaraBoundsSolver : ModuleRules
{
	public NiagaraBoundsSolver(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

		// The zero-warning policy is enforced by the packaging build rather than by a flag here:
		// `RunUAT BuildPlugin -Rocket` compiles against a clean installed engine, which is what a
		// Fab reviewer effectively reproduces.

		PublicDependencyModuleNames.AddRange(new string[]
		{
			"Core",
			"CoreUObject",

			// UWorld / spawning the component that carries the simulation, and FBox itself.
			"Engine",
		});

		PrivateDependencyModuleNames.AddRange(new string[]
		{
			// THE SUBJECT OF THE PRODUCT. Plugins/FX/Niagara/Source/Niagara, declared "Runtime" in
			// Niagara.uplugin, so it is linkable from an Editor module. The exact surface used:
			//   Public/NiagaraComponent.h:661   AdvanceSimulation(int32, float), NIAGARA_API.
			//                                   Stepping ONE tick at a time is what makes a union
			//                                   possible; the engine's own path samples one frame.
			//   Public/NiagaraComponent.h:408   GetSystemInstanceController() - NOT the deprecated
			//                                   GetSystemInstance() at :406, which is
			//                                   UE_DEPRECATED(5.0) and is exactly the shape of
			//                                   silent no-op this wing has already paid for once.
			//   Public/NiagaraSystemInstanceController.h:148/133/129
			//                                   GetLocalBounds / IsComplete / GetAge shims.
			//   Classes/NiagaraSystem.h:825     SetFixedBounds(const FBox&), plus bFixedBounds.
			//   Classes/NiagaraEmitter.h:350/357 FVersionedNiagaraEmitterData::CalculateBoundsMode
			//                                   and ::FixedBounds - the LIVE properties.
			//                                   ⛔ NOT UNiagaraEmitter::FixedBounds_DEPRECATED
			//                                   (NiagaraEmitter.h:878), which still compiles and
			//                                   would write a field nothing reads.
			"Niagara",

			// Enumerating which assets are Niagara systems is an asset-registry TAG read, never a
			// blanket load. Only systems actually being solved are loaded, one at a time, and the
			// report prints the count it loaded against the count it found.
			"AssetRegistry",

			// The commandlet host, and UEditorLoadingAndSavingUtils::SavePackages
			// (Editor/UnrealEd/Public/FileHelpers.h).
			"UnrealEd",

			// The undo journal is JSON: written before any package is saved, read back by -Revert.
			"Json",
			"JsonUtilities",

			// The EXPLICIT half of the checkout. SavePackages already checks out, but a tool that
			// promises "it checks out before it writes" has to be able to REPORT what it checked
			// out. Developer/SourceControl/Public/SourceControlHelpers.h
			"SourceControl",
		});
	}
}
