// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

/**
 * The union accumulator - the actual idea of the product, kept in one small unit with no engine
 * world in it so it can be tested for real rather than only compiled.
 *
 * ⭐ WHY THIS EXISTS AT ALL. The engine's own "Set Fixed Bounds" reads the bounds of whatever
 * frame is on screen when you press it (NiagaraSystemViewModel.cpp:3398,
 * SetFixedBounds(SystemInstance->GetLocalBounds())). For any effect that moves, expands or
 * arcs - which is most of them - one frame is not the shape of the effect. The union across the
 * whole lifetime is.
 *
 * ⛔ AND IT MUST REFUSE EMPTY FRAMES RATHER THAN ABSORB THEM. A Niagara instance reports a valid
 * but zero-extent box on ticks where no particle is alive - before the first spawn, and after a
 * burst has died. FBox::operator+ would happily union that with the real box and drag a corner to
 * the system origin, silently producing a bound that is bigger than the effect and centred wrong.
 * Both halves of that are wrong and neither would ever throw. So a sample is only counted when it
 * is valid AND has non-zero extent, and the count of accepted samples is reported next to the
 * count of attempts - the difference is the honesty margin (CSAF §2b: count the work).
 */
class NIAGARABOUNDSSOLVER_API FNBSBoundsAccumulator
{
public:
	/**
	 * Offer one tick's local bounds.
	 * @return true when the sample was ACCEPTED into the union.
	 */
	bool Add(const FBox& Sample);

	/** Ticks offered. */
	int32 NumOffered() const { return Offered; }

	/** Ticks actually folded into the union. Zero here means "do not write anything". */
	int32 NumAccepted() const { return Accepted; }

	/** True when at least one real sample was folded in. */
	bool HasResult() const { return Accepted > 0 && Union.IsValid; }

	/** The union of every accepted sample. Only meaningful when HasResult(). */
	const FBox& GetUnion() const { return Union; }

	/**
	 * The union grown by a fraction of its own extent on every side.
	 * A pad of 0 returns the union unchanged. Negative pads are clamped to 0 - shrinking a
	 * measured bound is the one thing this tool must never do.
	 */
	FBox GetPadded(float Pad) const;

	/**
	 * How many times bigger New is than Old, by volume. Returns 0 when either box is unusable.
	 *
	 * ⚠️ A degenerate old box - a plane or a line, volume 0 - is the common case for a hand-typed
	 * bound, and dividing by it would give +inf and print as garbage. That returns 0 instead, and
	 * callers treat 0 as "not comparable" rather than as "no growth".
	 */
	static double GrowthFactor(const FBox& Old, const FBox& New);

	/** True when the box is usable as a bound: valid, finite, and with real extent. */
	static bool IsUsable(const FBox& Box);

private:
	FBox Union = FBox(ForceInit);
	int32 Offered = 0;
	int32 Accepted = 0;
};
