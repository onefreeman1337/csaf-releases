// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "NBSTypes.h"

/**
 * The HTML sheet.
 *
 * This is the product's visible surface, so it is a designed document rather than a log dump: the
 * thing a buyer looks at is a to-scale drawing of the box the asset carried against the box the
 * simulation measured, because "your bounds were 8x too small" is only convincing when you can see
 * it.
 */
namespace NBSReport
{
	/** @return false when the file could not be written; OutError says why. */
	NIAGARABOUNDSSOLVER_API bool Write(
		const FString& Path,
		const FNBSRunOptions& Options,
		const FNBSRunSummary& Summary,
		const TArray<FNBSSystemResult>& Results,
		FString& OutError);

	/**
	 * The two-projection SVG for one system, exposed so a test can assert it is drawn to scale
	 * rather than only that it is non-empty.
	 */
	NIAGARABOUNDSSOLVER_API FString BuildBoxSvg(const FBox& Old, const FBox& Measured);
}
