// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "NBSTypes.h"

/** The one orchestration path, shared by the commandlet and the editor console command. */
namespace NBSRun
{
	/** @return the process exit code. */
	NIAGARABOUNDSSOLVER_API int32 Execute(const FNBSRunOptions& Options, FNBSRunSummary& OutSummary);
}
