// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "NBSTypes.h"

/** Switch parsing, shared by the commandlet and the in-editor console command so they cannot drift. */
namespace NBSArgs
{
	/**
	 * @param Params  the raw switch string.
	 * @param OutOptions  filled on success.
	 * @param OutError  a sentence naming the offending switch on failure.
	 * @return false when the arguments are unusable. The caller must NOT run.
	 */
	NIAGARABOUNDSSOLVER_API bool Parse(const FString& Params, FNBSRunOptions& OutOptions, FString& OutError);

	/** The -Help text. */
	NIAGARABOUNDSSOLVER_API FString Usage();

	/** Default report path for a run started at this time, under the project's Saved folder. */
	NIAGARABOUNDSSOLVER_API FString DefaultReportPath();

	/** Default journal path. */
	NIAGARABOUNDSSOLVER_API FString DefaultJournalPath();
}
