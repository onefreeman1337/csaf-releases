// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "AssetRegistry/AssetData.h"

/**
 * Finding the Niagara systems.
 *
 * ⛔ THIS IS A TAG READ, NOT A LOAD. CSAF §4: never blanket-load assets to read a property.
 * Loading every system in a project to ask whether it has fixed bounds is a twenty-minute editor
 * hang instead of a two-second scan, and a project with a few thousand effects would simply run
 * out of memory. The asset registry already carries what the scan needs to DECIDE, and only the
 * systems that survive the filter are loaded - one at a time, by the solver.
 */
namespace NBSScan
{
	/** Everything the registry can tell us without loading the asset. */
	struct FNBSCandidate
	{
		FAssetData Asset;

		/**
		 * True when the registry tag says the system already carries fixed bounds.
		 *
		 * ⚠️ This is a HINT, not the truth, and the solver re-reads the real value after loading.
		 * The tag can be stale on an asset saved by an older engine version, and acting on a stale
		 * tag would mean skipping a system that actually needs fixing.
		 */
		bool bTagSaysFixedBounds = false;

		/** True when the tag was absent, so the hint above carries no information either way. */
		bool bTagMissing = true;
	};

	/**
	 * @param ScanPath  content path root, e.g. /Game.
	 * @param OutCandidates  every UNiagaraSystem under that path.
	 * @return false only when the asset registry itself could not be queried.
	 */
	NIAGARABOUNDSSOLVER_API bool FindSystems(const FString& ScanPath, TArray<FNBSCandidate>& OutCandidates);

	/** The registry tag name the scan reads. Exposed so a test can assert we are reading the real one. */
	NIAGARABOUNDSSOLVER_API FName FixedBoundsTagName();
}
