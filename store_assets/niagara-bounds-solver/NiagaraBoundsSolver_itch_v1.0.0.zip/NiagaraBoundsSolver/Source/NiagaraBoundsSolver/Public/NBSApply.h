// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "NBSTypes.h"

class UNiagaraSystem;

/**
 * The write pass, kept strictly separate from measurement so that a preview run provably cannot
 * touch an asset: NBSSolve has no write path at all, and this file is never entered without -Apply.
 */
namespace NBSApply
{
	/**
	 * Write the measured bounds onto one already-measured system.
	 *
	 * Sets the SYSTEM's bFixedBounds and box - which is what actually takes effect, since the
	 * engine's own validator notes the system's bounds override the emitters'
	 * (NiagaraValidationRules.cpp:451) - and additionally pins any GPU emitter that was left on
	 * Dynamic, because the engine states outright that GPU emitters do not support dynamic bounds
	 * (:470) and leaving them would keep the asset failing its own validation.
	 *
	 * @return true when the asset was modified. Does not save; the caller batches saves.
	 */
	NIAGARABOUNDSSOLVER_API bool WriteSystem(UNiagaraSystem* System, FNBSSystemResult& Result);

	/** Append one system's previous state to the in-memory journal. */
	NIAGARABOUNDSSOLVER_API void RecordJournalEntry(const FNBSSystemResult& Result);

	/**
	 * Flush the journal to disk.
	 *
	 * ⛔ CALLED BEFORE ANY PACKAGE IS SAVED, never after. A run that dies part way through must
	 * still be reversible, and a journal written at the end is a journal that does not exist for
	 * exactly the runs that needed it.
	 */
	NIAGARABOUNDSSOLVER_API bool FlushJournal(const FString& JournalPath, FString& OutError);

	/** Drop anything accumulated. */
	NIAGARABOUNDSSOLVER_API void ResetJournal();

	/** Number of entries currently held. */
	NIAGARABOUNDSSOLVER_API int32 JournalNum();

	/**
	 * Restore every system named in the journal to the bounds it had before the run that wrote it.
	 * @return the number of systems restored, or INDEX_NONE when the journal could not be read.
	 */
	NIAGARABOUNDSSOLVER_API int32 RevertFromJournal(const FString& JournalPath, TArray<FString>& OutProblems);

	/** Check out and save the packages of every system modified so far. */
	NIAGARABOUNDSSOLVER_API bool SaveModified(TArray<FString>& OutProblems, int32& OutSaved, int32& OutFailed);
}
