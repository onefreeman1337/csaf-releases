// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "NBSTypes.h"

class UNiagaraSystem;
class UWorld;

/**
 * The measurement pass: play one system headlessly and union its bounds over its lifetime.
 *
 * This is the half of the product the engine does not have. Epic can set a fixed bound from the
 * frame currently on screen (NiagaraSystemViewModel.cpp:3398) and it can TELL you a system has
 * none (NiagaraValidationRules.cpp:449, and the NiagaraSystemAuditCommandlet in batch) - but
 * nothing in the engine simulates a system forward and takes the union, because validation is
 * static and this is not.
 */
namespace NBSSolve
{
	/**
	 * Simulate one system and fill in the measured half of Result.
	 *
	 * Never writes to the asset - that is NBSApply's job, and keeping measurement and mutation in
	 * separate passes is what makes a preview run trustworthy.
	 *
	 * @param World    a world to host the component. Must be non-null and ticking-capable.
	 * @param System   the loaded system.
	 * @param Options  tick delta, time cap, pad.
	 * @param Result   filled with measured bounds, tick counts and any skip reason.
	 * @return true when a usable bound was measured. False means Result.Skip says why, and the
	 *         caller must leave the asset alone.
	 */
	NIAGARABOUNDSSOLVER_API bool MeasureSystem(
		UWorld* World,
		UNiagaraSystem* System,
		const FNBSRunOptions& Options,
		FNBSSystemResult& Result);

	/**
	 * Create the throwaway world the measurement runs in, or null on failure.
	 * The caller owns it and must pass it to DestroyWorld.
	 */
	NIAGARABOUNDSSOLVER_API UWorld* CreateMeasurementWorld();

	/** Tear down a world made by CreateMeasurementWorld. Safe with null. */
	NIAGARABOUNDSSOLVER_API void DestroyMeasurementWorld(UWorld* World);
}
