// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Commandlets/Commandlet.h"
#include "NBSCommandlet.generated.h"

/**
 * The CI entry point.
 *
 *   UnrealEditor-Cmd.exe Project.uproject -run=NiagaraBoundsSolver -Path=/Game/Effects -Apply
 *
 * ⚠️ CPU systems only, and it says so rather than pretending. GPU emitters need an RHI to read
 * their particle counts back through, so under -nullrhi they are reported as skipped with
 * "gpu-needs-editor-run" instead of being silently measured as empty. Run the console command in a
 * headless editor session when the project has GPU effects.
 */
UCLASS()
class UNBSCommandlet : public UCommandlet
{
	GENERATED_BODY()

public:
	UNBSCommandlet();

	virtual int32 Main(const FString& Params) override;
};
