// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

/**
 * Process exit codes. A commandlet that returns 0 for "I scanned nothing" is a CI gate that can
 * never fail, so an empty scan is an ERROR here, not a pass (CSAF §2b: count the work, not the
 * verdict).
 */
enum class ENBSExit : uint8
{
	/** Everything asked for was measured, and applied if -Apply was passed. */
	Ok = 0,
	/** Bad or missing arguments; nothing was scanned. */
	BadArguments = 1,
	/** No Niagara system found under the paths given - an empty scan is an error, not a pass. */
	NothingFound = 2,
	/** One or more systems were refused, with a reason, and left untouched. */
	Refused = 3,
	/** An asset could not be checked out or saved. */
	WriteFailed = 4,
};

/** Why a system or emitter was left alone. The product never guesses a bound, so this is a first-class result. */
enum class ENBSSkip : uint8
{
	/** Not skipped. */
	None = 0,
	/** The simulation never produced a single particle at any sampled tick, so there is nothing to measure. */
	NoParticlesEverSpawned,
	/** The system instance could not be created or refused to activate. */
	InstanceUnavailable,
	/** The system was still alive at the time cap, so the sampled window is not the whole lifetime. */
	LifetimeExceededCap,
	/** The measured union was empty or not finite. */
	DegenerateBounds,
	/** The user asked for preview only. */
	NotApplied,
	/** The system already carried fixed bounds and -OnlyDynamic was set. */
	AlreadyFixed,
	/**
	 * The system has GPU emitters and this run has no RHI to read them back with.
	 *
	 * MEASURED FROM ENGINE SOURCE: NiagaraEmitterInstanceImpl.cpp:890-901 reads GPU particle counts
	 * through FScopedNiagaraDataSetGPUReadback, which needs a real compute dispatch interface. A
	 * commandlet started with -nullrhi does not have one, so a GPU emitter's particle count reads
	 * zero there for reasons that have nothing to do with the effect. Reporting that as
	 * "no particles" would be a lie, so it gets its own reason and its own advice: run it in the
	 * editor instead.
	 */
	GpuRequiresEditorRun,
	/**
	 * The system contains a STATELESS (Lightweight) emitter, which this version cannot honestly
	 * measure.
	 *
	 * ⛔ MEASURED 2026-08-31, AND IT WAS SILENTLY REPORTING A NUMBER IT HAD NOT MEASURED.
	 *
	 * UE 5.5 added stateless emitters, and FNiagaraEmitterHandle carries them in a SEPARATE field
	 * (NiagaraEmitterHandle.h:91 GetStatelessEmitter) from the versioned UNiagaraEmitter. For a
	 * stateless handle GetEmitterData() returns nullptr, so the emitter-collection loop skipped it
	 * and the per-system measurement fell through to the engine's DEFAULT 200cm cube.
	 *
	 * The tell: five fixture systems derived from THREE different Lightweight templates all
	 * reported a measured union of exactly 200, 200, 200 - i.e. a growth factor of exactly 1.331x
	 * over the 200 default, for a fountain and a burst and an ambient drift alike. A fountain and a
	 * burst do not occupy the same box, so that was a constant, not a measurement.
	 *
	 * Reporting the default as a measured union is precisely the failure this product exists to
	 * prevent - a confident wrong bound that validates clean - so a system with any enabled
	 * stateless emitter is now REFUSED and left untouched. A mixed system is refused too: measuring
	 * only its versioned emitters would produce a union that omits the stateless ones, which is an
	 * under-bound, which is the original bug wearing this tool's badge.
	 */
	StatelessEmitterUnsupported,
};

NIAGARABOUNDSSOLVER_API const TCHAR* LexToString(ENBSSkip Skip);

/** A human sentence for a skip reason, used in the log and in the report. */
NIAGARABOUNDSSOLVER_API FString NBSSkipReasonText(ENBSSkip Skip);

/** Per-emitter outcome inside one system. */
struct FNBSEmitterResult
{
	FString EmitterName;

	/** What the asset said before the run. */
	bool bOldModeFixed = false;
	FBox OldBounds = FBox(ForceInit);

	/** What we measured. Only meaningful when bMeasured is true. */
	bool bMeasured = false;
	FBox NewBounds = FBox(ForceInit);

	/** True when the emitter simulates on the GPU - the only case the engine's own validator checks. */
	bool bGpu = false;

	/** True once the asset was actually modified. */
	bool bWritten = false;

	ENBSSkip Skip = ENBSSkip::None;
};

/** Per-system outcome. */
struct FNBSSystemResult
{
	FString AssetPath;
	FString AssetName;

	/** System-level state before the run. */
	bool bOldFixedBounds = false;
	FBox OldBounds = FBox(ForceInit);

	/** The union across every sampled tick, before padding. */
	FBox MeasuredBounds = FBox(ForceInit);
	/** What was written, i.e. MeasuredBounds after any -Pad. */
	FBox WrittenBounds = FBox(ForceInit);

	int32 TicksSimulated = 0;
	/** Ticks whose bounds were valid AND non-degenerate. The difference from TicksSimulated is the honesty margin. */
	int32 TicksWithParticles = 0;
	float SimulatedSeconds = 0.0f;

	/**
	 * How much bigger the measured box is than the old one, by volume. Only meaningful when the
	 * system already had fixed bounds; this is the number that shows a shipped effect was being
	 * culled. A value > 1 means the old box was too small.
	 */
	double GrowthFactor = 0.0;

	bool bWritten = false;
	ENBSSkip Skip = ENBSSkip::None;

	TArray<FNBSEmitterResult> Emitters;

	/** True when this system's measured box is bigger than what the asset carried - i.e. it was culling. */
	bool WasUnderBounded() const
	{
		return bOldFixedBounds && MeasuredBounds.IsValid && OldBounds.IsValid && GrowthFactor > 1.0;
	}
};

/** Everything the run was asked to do. */
struct FNBSRunOptions
{
	/** Content path to scan under, e.g. /Game/Effects. Defaults to /Game. */
	FString ScanPath = TEXT("/Game");

	/** Nothing is written unless this is true. */
	bool bApply = false;

	/** Simulation step. 1/30 by default: coarse enough to be quick, fine enough not to step over a burst. */
	float TickDelta = 1.0f / 30.0f;

	/** Hard cap on simulated time per system, so a looping system cannot hang the run. */
	float MaxSeconds = 10.0f;

	/** Fraction added to each side of the measured box. 0.05 = 5%. */
	float Pad = 0.05f;

	/** Skip systems that already carry fixed bounds. */
	bool bOnlyDynamic = false;

	/** Where the HTML sheet goes. */
	FString ReportPath;

	/** Where the undo journal goes. */
	FString JournalPath;

	/** Restore bounds from the journal instead of solving. */
	bool bRevert = false;
};

/** What the run did, for the log line and for state. */
struct FNBSRunSummary
{
	bool bApplied = false;
	int32 SystemsFound = 0;
	int32 SystemsLoaded = 0;
	int32 SystemsSolved = 0;
	int32 SystemsSkipped = 0;
	int32 SystemsUnderBounded = 0;
	int32 EmittersWritten = 0;
	int32 PackagesSaved = 0;
	int32 PackagesFailed = 0;
	int32 TotalTicksSimulated = 0;
	float Seconds = 0.0f;
	TArray<FString> Problems;
};
