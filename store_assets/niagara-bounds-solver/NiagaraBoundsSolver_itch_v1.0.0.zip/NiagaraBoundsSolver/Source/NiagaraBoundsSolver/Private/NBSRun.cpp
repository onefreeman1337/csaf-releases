// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "NBSRun.h"

#include "Engine/World.h"
#include "HAL/PlatformTime.h"
#include "Misc/Paths.h"
#include "NBSApply.h"
#include "NBSReport.h"
#include "NBSScan.h"
#include "NBSSolve.h"
#include "NiagaraSystem.h"
#include "UObject/UObjectGlobals.h"

DEFINE_LOG_CATEGORY_STATIC(LogNBSRun, Log, All);

int32 NBSRun::Execute(const FNBSRunOptions& Options, FNBSRunSummary& OutSummary)
{
	const double Started = FPlatformTime::Seconds();
	OutSummary = FNBSRunSummary();
	OutSummary.bApplied = Options.bApply;

	NBSApply::ResetJournal();

	if (Options.bRevert)
	{
		const int32 Restored = NBSApply::RevertFromJournal(Options.JournalPath, OutSummary.Problems);
		if (Restored == INDEX_NONE)
		{
			OutSummary.Seconds = static_cast<float>(FPlatformTime::Seconds() - Started);
			return static_cast<int32>(ENBSExit::NothingFound);
		}

		NBSApply::SaveModified(OutSummary.Problems, OutSummary.PackagesSaved, OutSummary.PackagesFailed);
		OutSummary.SystemsSolved = Restored;
		OutSummary.Seconds = static_cast<float>(FPlatformTime::Seconds() - Started);
		return OutSummary.PackagesFailed > 0
			? static_cast<int32>(ENBSExit::WriteFailed)
			: static_cast<int32>(ENBSExit::Ok);
	}

	TArray<NBSScan::FNBSCandidate> Candidates;
	if (!NBSScan::FindSystems(Options.ScanPath, Candidates))
	{
		OutSummary.Problems.Add(TEXT("The asset registry could not be queried."));
		OutSummary.Seconds = static_cast<float>(FPlatformTime::Seconds() - Started);
		return static_cast<int32>(ENBSExit::NothingFound);
	}

	OutSummary.SystemsFound = Candidates.Num();
	if (Candidates.Num() == 0)
	{
		// ⛔ An empty scan is an ERROR, not a pass. A CI gate that returns 0 because it looked at
		// nothing is a gate that can never fail, which is the whole point of CSAF §2b.
		OutSummary.Problems.Add(FString::Printf(
			TEXT("No Niagara system found under '%s'. An empty scan is reported as a failure so a CI step ")
			TEXT("cannot pass by looking at nothing."), *Options.ScanPath));
		OutSummary.Seconds = static_cast<float>(FPlatformTime::Seconds() - Started);
		return static_cast<int32>(ENBSExit::NothingFound);
	}

	UWorld* World = NBSSolve::CreateMeasurementWorld();
	if (World == nullptr)
	{
		OutSummary.Problems.Add(TEXT("A measurement world could not be created, so nothing was simulated."));
		OutSummary.Seconds = static_cast<float>(FPlatformTime::Seconds() - Started);
		return static_cast<int32>(ENBSExit::Refused);
	}

	TArray<FNBSSystemResult> Results;
	Results.Reserve(Candidates.Num());

	// Index into Results, paired with the asset path to re-resolve in the write pass.
	//
	// ⚠️ Deliberately NOT a parallel array of raw UNiagaraSystem* matched up by position later.
	// That is two ways to be wrong at once: a raw UObject* held across the measurement loop is
	// unrooted and a GC between systems may collect it, and position-matching two arrays that are
	// filtered by different conditions is exactly how a write lands on the wrong asset. An explicit
	// index removes the second, and re-resolving the path removes the first.
	TArray<TPair<int32, FSoftObjectPath>> ToWrite;
	ToWrite.Reserve(Candidates.Num());

	for (const NBSScan::FNBSCandidate& Candidate : Candidates)
	{
		FNBSSystemResult Result;
		Result.AssetPath = Candidate.Asset.GetObjectPathString();
		Result.AssetName = Candidate.Asset.AssetName.ToString();

		// The registry tag is only a hint and the solver re-reads the truth after loading, but when
		// -OnlyDynamic is set the hint is enough to avoid the load entirely - which is the point of
		// reading tags in the first place.
		if (Options.bOnlyDynamic && !Candidate.bTagMissing && Candidate.bTagSaysFixedBounds)
		{
			Result.Skip = ENBSSkip::AlreadyFixed;
			++OutSummary.SystemsSkipped;
			Results.Add(MoveTemp(Result));
			continue;
		}

		UNiagaraSystem* System = Cast<UNiagaraSystem>(Candidate.Asset.GetAsset());
		if (System == nullptr)
		{
			Result.Skip = ENBSSkip::InstanceUnavailable;
			++OutSummary.SystemsSkipped;
			Results.Add(MoveTemp(Result));
			continue;
		}
		++OutSummary.SystemsLoaded;

		const bool bMeasured = NBSSolve::MeasureSystem(World, System, Options, Result);
		OutSummary.TotalTicksSimulated += Result.TicksSimulated;

		if (!bMeasured)
		{
			++OutSummary.SystemsSkipped;
			Results.Add(MoveTemp(Result));
			continue;
		}

		++OutSummary.SystemsSolved;
		if (Result.WasUnderBounded())
		{
			++OutSummary.SystemsUnderBounded;
		}

		if (Options.bApply)
		{
			NBSApply::RecordJournalEntry(Result);
			ToWrite.Emplace(Results.Num(), Candidate.Asset.ToSoftObjectPath());
		}
		else
		{
			Result.Skip = ENBSSkip::NotApplied;
		}

		Results.Add(MoveTemp(Result));
	}

	NBSSolve::DestroyMeasurementWorld(World);

	if (Options.bApply && ToWrite.Num() > 0)
	{
		// The journal goes to disk BEFORE the first asset is touched. A run that dies half way
		// through has to still be reversible, and a journal written afterwards does not exist for
		// exactly the runs that needed one.
		FString JournalError;
		if (!NBSApply::FlushJournal(Options.JournalPath, JournalError))
		{
			OutSummary.Problems.Add(JournalError);
			OutSummary.Seconds = static_cast<float>(FPlatformTime::Seconds() - Started);
			return static_cast<int32>(ENBSExit::WriteFailed);
		}

		for (const TPair<int32, FSoftObjectPath>& Pair : ToWrite)
		{
			FNBSSystemResult& Result = Results[Pair.Key];

			UNiagaraSystem* System = Cast<UNiagaraSystem>(Pair.Value.ResolveObject());
			if (System == nullptr)
			{
				OutSummary.Problems.Add(FString::Printf(
					TEXT("'%s' was measured but could no longer be resolved when it came time to write it; ")
					TEXT("it was left unchanged."), *Result.AssetPath));
				++OutSummary.PackagesFailed;
				continue;
			}

			if (NBSApply::WriteSystem(System, Result))
			{
				for (const FNBSEmitterResult& Emitter : Result.Emitters)
				{
					if (Emitter.bWritten)
					{
						++OutSummary.EmittersWritten;
					}
				}
			}
		}

		NBSApply::SaveModified(OutSummary.Problems, OutSummary.PackagesSaved, OutSummary.PackagesFailed);
	}

	FString ReportError;
	if (!NBSReport::Write(Options.ReportPath, Options, OutSummary, Results, ReportError))
	{
		OutSummary.Problems.Add(ReportError);
	}

	OutSummary.Seconds = static_cast<float>(FPlatformTime::Seconds() - Started);

	if (OutSummary.PackagesFailed > 0)
	{
		return static_cast<int32>(ENBSExit::WriteFailed);
	}

	// A skipped system is a refusal, and a refusal is visible in the exit code so a CI step can
	// decide what to do about it rather than discovering it in a log nobody reads.
	if (OutSummary.SystemsSkipped > 0 && !Options.bApply)
	{
		return static_cast<int32>(ENBSExit::Ok);
	}
	return OutSummary.SystemsSkipped > 0
		? static_cast<int32>(ENBSExit::Refused)
		: static_cast<int32>(ENBSExit::Ok);
}
