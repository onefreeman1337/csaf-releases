// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "NBSUnion.h"

namespace
{
	/**
	 * Below this, an axis counts as having no extent.
	 *
	 * A Niagara instance with no live particles reports a valid box whose min and max are the same
	 * point, and single-particle frames can legitimately report an extremely thin box. 1e-4 cm is
	 * far under anything that matters visually and far over float noise around a large coordinate.
	 */
	constexpr double MinMeaningfulExtent = 1.0e-4;
}

bool FNBSBoundsAccumulator::IsUsable(const FBox& Box)
{
	if (!Box.IsValid)
	{
		return false;
	}

	const FVector Size = Box.GetSize();

	// ⛔ Finite check first, and on every component. A data interface that reads an uninitialised
	// buffer can hand back a NaN, and NaN silently poisons every comparison after it: NaN > x is
	// false, so a plain size test would ACCEPT it and the union would become NaN for the rest of
	// the run, writing a corrupt bound to a real asset.
	if (!FMath::IsFinite(Size.X) || !FMath::IsFinite(Size.Y) || !FMath::IsFinite(Size.Z))
	{
		return false;
	}
	if (!FMath::IsFinite(Box.Min.X) || !FMath::IsFinite(Box.Min.Y) || !FMath::IsFinite(Box.Min.Z) ||
		!FMath::IsFinite(Box.Max.X) || !FMath::IsFinite(Box.Max.Y) || !FMath::IsFinite(Box.Max.Z))
	{
		return false;
	}

	// An effect can legitimately be flat in one axis - a ground decal ring, a sheet of sparks - so
	// requiring extent on ALL THREE would refuse real effects. Requiring it on at least one
	// separates "a shape" from "a point", which is the distinction that matters.
	return Size.X > MinMeaningfulExtent || Size.Y > MinMeaningfulExtent || Size.Z > MinMeaningfulExtent;
}

bool FNBSBoundsAccumulator::Add(const FBox& Sample)
{
	++Offered;

	if (!IsUsable(Sample))
	{
		return false;
	}

	if (Accepted == 0)
	{
		Union = Sample;
	}
	else
	{
		Union += Sample;
	}

	++Accepted;
	return true;
}

FBox FNBSBoundsAccumulator::GetPadded(float Pad) const
{
	if (!HasResult())
	{
		return FBox(ForceInit);
	}

	// Shrinking a measured bound would re-introduce the exact defect this product exists to fix,
	// so a negative pad is clamped rather than honoured.
	const double SafePad = FMath::Max(0.0, static_cast<double>(Pad));
	if (SafePad <= 0.0)
	{
		return Union;
	}

	return Union.ExpandBy(Union.GetSize() * SafePad);
}

double FNBSBoundsAccumulator::GrowthFactor(const FBox& Old, const FBox& New)
{
	if (!IsUsable(Old) || !IsUsable(New))
	{
		return 0.0;
	}

	const FVector OldSize = Old.GetSize();
	const FVector NewSize = New.GetSize();

	// A flat effect has a zero axis, and a straight volume ratio would be 0/0. Comparing on the
	// axes that actually have extent keeps a ground ring comparable while still refusing a box
	// that is a point.
	const double OldVolume = FMath::Max(OldSize.X, MinMeaningfulExtent)
		* FMath::Max(OldSize.Y, MinMeaningfulExtent)
		* FMath::Max(OldSize.Z, MinMeaningfulExtent);
	const double NewVolume = FMath::Max(NewSize.X, MinMeaningfulExtent)
		* FMath::Max(NewSize.Y, MinMeaningfulExtent)
		* FMath::Max(NewSize.Z, MinMeaningfulExtent);

	if (OldVolume <= 0.0)
	{
		return 0.0;
	}

	return NewVolume / OldVolume;
}
