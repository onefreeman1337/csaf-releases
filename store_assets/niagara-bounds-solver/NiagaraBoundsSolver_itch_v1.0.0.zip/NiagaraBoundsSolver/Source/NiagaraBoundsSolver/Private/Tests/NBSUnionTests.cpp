// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "Misc/AutomationTest.h"
#include "NBSUnion.h"

#if WITH_DEV_AUTOMATION_TESTS

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FNBSUnionAcceptsRealSamples,
	"CSAF.NiagaraBoundsSolver.Union.AcceptsRealSamples",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FNBSUnionAcceptsRealSamples::RunTest(const FString&)
{
	FNBSBoundsAccumulator Acc;

	TestTrue(TEXT("a real box is accepted"), Acc.Add(FBox(FVector(-10), FVector(10))));
	TestTrue(TEXT("a second real box is accepted"), Acc.Add(FBox(FVector(0), FVector(50))));

	TestTrue(TEXT("has a result"), Acc.HasResult());
	TestEqual(TEXT("two offered"), Acc.NumOffered(), 2);
	TestEqual(TEXT("two accepted"), Acc.NumAccepted(), 2);

	// The union, not the last sample - which is the entire difference from the engine's own
	// one-frame path.
	const FBox Union = Acc.GetUnion();
	TestEqual(TEXT("union min X"), Union.Min.X, -10.0);
	TestEqual(TEXT("union max X"), Union.Max.X, 50.0);

	return true;
}

/**
 * ⛔ THE TEST THAT PROTECTS THE PRODUCT'S ONE PROMISE.
 *
 * A Niagara instance with no live particles reports a VALID box of zero extent
 * (NiagaraSystemInstance.cpp:155 and :1056 both assign FBox(ZeroVector, ZeroVector)). Unioning
 * that with a real box drags a corner to the origin, producing a bound that is both too big and
 * centred wrong - and nothing would ever throw.
 */
IMPLEMENT_SIMPLE_AUTOMATION_TEST(FNBSUnionRejectsEmptyFrames,
	"CSAF.NiagaraBoundsSolver.Union.RejectsEmptyFrames",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FNBSUnionRejectsEmptyFrames::RunTest(const FString&)
{
	FNBSBoundsAccumulator Acc;

	// Exactly what the engine hands back before the first spawn.
	const FBox EngineEmpty(FVector::ZeroVector, FVector::ZeroVector);
	TestFalse(TEXT("a zero-extent box is refused"), Acc.Add(EngineEmpty));
	TestFalse(TEXT("and it does not create a result"), Acc.HasResult());

	// A real burst, far from the origin.
	TestTrue(TEXT("the real sample is accepted"), Acc.Add(FBox(FVector(1000), FVector(1100))));

	// The burst dies; the engine goes back to reporting a point at the origin.
	TestFalse(TEXT("the trailing empty frame is refused too"), Acc.Add(EngineEmpty));

	TestEqual(TEXT("three offered"), Acc.NumOffered(), 3);
	TestEqual(TEXT("one accepted"), Acc.NumAccepted(), 1);

	// If an empty frame had been folded in, Min would have been dragged to 0.
	TestEqual(TEXT("union was not dragged to the origin"), Acc.GetUnion().Min.X, 1000.0);

	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FNBSUnionRejectsNaN,
	"CSAF.NiagaraBoundsSolver.Union.RejectsNaN",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FNBSUnionRejectsNaN::RunTest(const FString&)
{
	FNBSBoundsAccumulator Acc;
	TestTrue(TEXT("a real box first"), Acc.Add(FBox(FVector(-5), FVector(5))));

	// NaN fails every comparison, so a naive size test would ACCEPT this and poison the union for
	// the rest of the run.
	FBox Poison(FVector(0), FVector(1));
	Poison.Max.Y = FMath::Sqrt(-1.0);
	TestFalse(TEXT("a NaN box is refused"), Acc.Add(Poison));

	TestEqual(TEXT("still one accepted"), Acc.NumAccepted(), 1);
	TestTrue(TEXT("union is still finite"), FMath::IsFinite(Acc.GetUnion().Max.Y));

	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FNBSUnionPadNeverShrinks,
	"CSAF.NiagaraBoundsSolver.Union.PadNeverShrinks",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FNBSUnionPadNeverShrinks::RunTest(const FString&)
{
	FNBSBoundsAccumulator Acc;
	Acc.Add(FBox(FVector(-100), FVector(100)));

	const FBox NoPad = Acc.GetPadded(0.0f);
	TestEqual(TEXT("zero pad is the union"), NoPad.Max.X, 100.0);

	const FBox Padded = Acc.GetPadded(0.1f);
	TestTrue(TEXT("a positive pad grows the box"), Padded.Max.X > 100.0);

	// Shrinking a measured bound would re-create the exact defect this product removes.
	const FBox Negative = Acc.GetPadded(-0.5f);
	TestEqual(TEXT("a negative pad is clamped, not honoured"), Negative.Max.X, 100.0);

	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FNBSUnionGrowthFactor,
	"CSAF.NiagaraBoundsSolver.Union.GrowthFactor",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FNBSUnionGrowthFactor::RunTest(const FString&)
{
	const FBox Small(FVector(-1), FVector(1));   // 2x2x2 = 8
	const FBox Big(FVector(-2), FVector(2));     // 4x4x4 = 64

	TestEqual(TEXT("8x growth"), FNBSBoundsAccumulator::GrowthFactor(Small, Big), 8.0);

	// A degenerate old box must not produce an infinity that prints as garbage.
	const FBox Point(FVector::ZeroVector, FVector::ZeroVector);
	TestEqual(TEXT("a point old box is not comparable"),
		FNBSBoundsAccumulator::GrowthFactor(Point, Big), 0.0);

	const FBox Invalid(ForceInit);
	TestEqual(TEXT("an invalid box is not comparable"),
		FNBSBoundsAccumulator::GrowthFactor(Invalid, Big), 0.0);

	return true;
}

/**
 * ⚠️ THIS TEST ASSERTS A LIMITATION RATHER THAN A FEATURE, DELIBERATELY.
 *
 * When a tick produces no bounds at all the engine substitutes FBox(-1,-1,-1)..(1,1,1)
 * (NiagaraSystemInstance.cpp:2802-2807) - a valid, non-degenerate 2cm cube. The accumulator CANNOT
 * tell that apart from a genuinely tiny effect, and pretending otherwise would be the lie. That is
 * exactly why NBSSolve gates every sample on a live particle count instead of trusting the box, and
 * this test pins the reason down so nobody later "fixes" the accumulator into silently dropping
 * small real effects.
 */
IMPLEMENT_SIMPLE_AUTOMATION_TEST(FNBSUnionCannotDetectEngineDefaultBox,
	"CSAF.NiagaraBoundsSolver.Union.CannotDetectEngineDefaultBox",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FNBSUnionCannotDetectEngineDefaultBox::RunTest(const FString&)
{
	FNBSBoundsAccumulator Acc;
	const FBox EngineFallback(-FVector::OneVector, FVector::OneVector);

	TestTrue(TEXT("the engine's 2cm fallback is indistinguishable from a real tiny effect"),
		Acc.Add(EngineFallback));

	return true;
}

#endif // WITH_DEV_AUTOMATION_TESTS
