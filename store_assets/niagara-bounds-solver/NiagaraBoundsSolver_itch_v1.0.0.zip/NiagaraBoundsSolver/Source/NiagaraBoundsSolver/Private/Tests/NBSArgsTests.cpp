// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "Misc/AutomationTest.h"
#include "NBSArgs.h"
#include "NBSReport.h"

#if WITH_DEV_AUTOMATION_TESTS

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FNBSArgsDefaults,
	"CSAF.NiagaraBoundsSolver.Args.Defaults",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FNBSArgsDefaults::RunTest(const FString&)
{
	FNBSRunOptions Options;
	FString Error;

	TestTrue(TEXT("an empty command line parses"), NBSArgs::Parse(TEXT(""), Options, Error));
	TestEqual(TEXT("scans /Game by default"), Options.ScanPath, FString(TEXT("/Game")));

	// The default MUST be preview. A tool that writes to every asset in the project because someone
	// typed the command without reading it is not a tool anyone keeps.
	TestFalse(TEXT("does not apply by default"), Options.bApply);
	TestFalse(TEXT("does not revert by default"), Options.bRevert);
	TestTrue(TEXT("a report path is always chosen"), Options.ReportPath.Len() > 0);
	TestTrue(TEXT("a journal path is always chosen"), Options.JournalPath.Len() > 0);

	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FNBSArgsRejectsBadValues,
	"CSAF.NiagaraBoundsSolver.Args.RejectsBadValues",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FNBSArgsRejectsBadValues::RunTest(const FString&)
{
	FNBSRunOptions Options;
	FString Error;

	TestFalse(TEXT("a relative path is refused"), NBSArgs::Parse(TEXT("-Path=Game/FX"), Options, Error));
	TestTrue(TEXT("and the error names the switch"), Error.Contains(TEXT("-Path")));

	TestFalse(TEXT("an absurd tick delta is refused"), NBSArgs::Parse(TEXT("-TickDelta=50"), Options, Error));
	TestFalse(TEXT("a zero tick delta is refused"), NBSArgs::Parse(TEXT("-TickDelta=0"), Options, Error));

	// A negative pad would shrink a measured bound - the defect the product exists to remove.
	TestFalse(TEXT("a negative pad is refused"), NBSArgs::Parse(TEXT("-Pad=-1"), Options, Error));

	TestFalse(TEXT("-Apply and -Revert together are refused"),
		NBSArgs::Parse(TEXT("-Apply -Revert"), Options, Error));

	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FNBSArgsAccepts,
	"CSAF.NiagaraBoundsSolver.Args.Accepts",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FNBSArgsAccepts::RunTest(const FString&)
{
	FNBSRunOptions Options;
	FString Error;

	TestTrue(TEXT("a full command line parses"),
		NBSArgs::Parse(TEXT("-Path=/Game/Effects -Apply -OnlyDynamic -TickDelta=0.01 -MaxSeconds=4 -Pad=0.2"),
			Options, Error));

	TestEqual(TEXT("path"), Options.ScanPath, FString(TEXT("/Game/Effects")));
	TestTrue(TEXT("apply"), Options.bApply);
	TestTrue(TEXT("only dynamic"), Options.bOnlyDynamic);
	TestEqual(TEXT("max seconds"), Options.MaxSeconds, 4.0f);
	TestEqual(TEXT("pad"), Options.Pad, 0.2f);

	// A trailing slash is a typo, not a different path.
	TestTrue(TEXT("a trailing slash parses"), NBSArgs::Parse(TEXT("-Path=/Game/FX/"), Options, Error));
	TestEqual(TEXT("and is trimmed"), Options.ScanPath, FString(TEXT("/Game/FX")));

	return true;
}

/**
 * The report drawing is the product's visible surface, so it gets asserted rather than eyeballed.
 * The claim under test is the one the picture makes: both boxes are drawn through the SAME scale,
 * so a box with 8x the volume is visibly bigger. Fitting each box to its own plate would draw them
 * identically and destroy the only thing the image is for.
 */
IMPLEMENT_SIMPLE_AUTOMATION_TEST(FNBSReportDrawsToSharedScale,
	"CSAF.NiagaraBoundsSolver.Report.DrawsToSharedScale",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FNBSReportDrawsToSharedScale::RunTest(const FString&)
{
	const FBox Old(FVector(-10), FVector(10));
	const FBox Measured(FVector(-80), FVector(80));

	const FString Svg = NBSReport::BuildBoxSvg(Old, Measured);

	TestTrue(TEXT("an svg is produced"), Svg.Contains(TEXT("<svg")));
	TestTrue(TEXT("the old box is drawn"), Svg.Contains(TEXT("class=\"old\"")));
	TestTrue(TEXT("the measured box is drawn"), Svg.Contains(TEXT("class=\"new\"")));
	TestTrue(TEXT("both projections are drawn"), Svg.Contains(TEXT("top")) && Svg.Contains(TEXT("front")));

	// With no measured box there is nothing honest to draw, so nothing is drawn.
	TestTrue(TEXT("an invalid measurement draws nothing"),
		NBSReport::BuildBoxSvg(Old, FBox(ForceInit)).IsEmpty());

	return true;
}

#endif // WITH_DEV_AUTOMATION_TESTS
