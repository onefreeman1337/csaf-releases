// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "NBSTypes.h"

#define LOCTEXT_NAMESPACE "NiagaraBoundsSolver"

const TCHAR* LexToString(ENBSSkip Skip)
{
	switch (Skip)
	{
	case ENBSSkip::None:                   return TEXT("none");
	case ENBSSkip::NoParticlesEverSpawned: return TEXT("no-particles");
	case ENBSSkip::InstanceUnavailable:    return TEXT("instance-unavailable");
	case ENBSSkip::LifetimeExceededCap:    return TEXT("lifetime-exceeded-cap");
	case ENBSSkip::DegenerateBounds:       return TEXT("degenerate-bounds");
	case ENBSSkip::NotApplied:             return TEXT("preview-only");
	case ENBSSkip::AlreadyFixed:           return TEXT("already-fixed");
	case ENBSSkip::GpuRequiresEditorRun:   return TEXT("gpu-needs-editor-run");
	case ENBSSkip::StatelessEmitterUnsupported: return TEXT("stateless-emitter-unsupported");
	}

	// No default: above, so adding a value to the enum is a compile warning rather than a silent
	// "unknown" at runtime. This line is only reachable through a cast of a bad integer.
	return TEXT("unknown");
}

FString NBSSkipReasonText(ENBSSkip Skip)
{
	switch (Skip)
	{
	case ENBSSkip::None:
		return FString();
	case ENBSSkip::NoParticlesEverSpawned:
		return TEXT("No particle was alive at any sampled tick, so there was nothing to measure. ")
			TEXT("Left untouched: a bound invented from an empty simulation would be wrong and would ")
			TEXT("still validate clean.");
	case ENBSSkip::InstanceUnavailable:
		return TEXT("The system instance could not be created or refused to activate, so it was never ")
			TEXT("simulated. Left untouched.");
	case ENBSSkip::LifetimeExceededCap:
		return TEXT("The system was still running when the time cap was reached, so the sampled window ")
			TEXT("is not its whole lifetime. Measured bounds are shown but NOT written - raise -MaxSeconds ")
			TEXT("to cover it, or leave a looping system on dynamic bounds deliberately.");
	case ENBSSkip::DegenerateBounds:
		return TEXT("Every sample was empty, infinite or not a number, so no usable box came out of the ")
			TEXT("run. Left untouched.");
	case ENBSSkip::NotApplied:
		return TEXT("Preview run. Pass -Apply to write.");
	case ENBSSkip::AlreadyFixed:
		return TEXT("Already carried fixed bounds and -OnlyDynamic was set.");
	case ENBSSkip::GpuRequiresEditorRun:
		return TEXT("This system simulates on the GPU and this run has no RHI to read the particle counts ")
			TEXT("back with, so it was not measured and NOT written. Run the same command inside the editor ")
			TEXT("(UnrealEditor-Cmd with -ExecCmds) instead of as a -nullrhi commandlet.");

	case ENBSSkip::StatelessEmitterUnsupported:
		return TEXT("This system uses a stateless (Lightweight) emitter, which this version cannot measure ")
			TEXT("through the same path as a standard emitter, so it was NOT measured and NOT written. ")
			TEXT("Its bounds are unchanged. Set this system's bounds by hand, or keep the emitter standard ")
			TEXT("if a measured bound matters more than the stateless emitter's cost.");
	}

	return TEXT("Unrecognised skip reason.");
}

#undef LOCTEXT_NAMESPACE
