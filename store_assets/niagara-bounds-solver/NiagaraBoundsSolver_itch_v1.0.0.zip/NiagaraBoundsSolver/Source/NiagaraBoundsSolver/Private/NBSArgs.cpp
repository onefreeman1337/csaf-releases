// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "NBSArgs.h"

#include "Misc/Parse.h"
#include "Misc/Paths.h"
#include "Misc/DateTime.h"

namespace
{
	/** Guard rails chosen so a typo cannot turn into an hour-long run or a useless one. */
	constexpr float MinTickDelta = 1.0f / 480.0f;
	constexpr float MaxTickDelta = 1.0f / 5.0f;
	constexpr float MinMaxSeconds = 0.1f;
	constexpr float MaxMaxSeconds = 600.0f;
	constexpr float MaxPad = 10.0f;

	FString TimeStamp()
	{
		return FDateTime::Now().ToString(TEXT("%Y%m%d-%H%M%S"));
	}
}

FString NBSArgs::DefaultReportPath()
{
	return FPaths::Combine(FPaths::ProjectSavedDir(), TEXT("NiagaraBoundsSolver"),
		FString::Printf(TEXT("BoundsReport-%s.html"), *TimeStamp()));
}

FString NBSArgs::DefaultJournalPath()
{
	// ⚠️ The journal deliberately does NOT carry a timestamp. -Revert has to be able to find the
	// last run without being told which file it was, and a session that has to paste a filename to
	// undo something is a session that will not undo it.
	return FPaths::Combine(FPaths::ProjectSavedDir(), TEXT("NiagaraBoundsSolver"),
		TEXT("BoundsJournal.json"));
}

bool NBSArgs::Parse(const FString& Params, FNBSRunOptions& OutOptions, FString& OutError)
{
	OutError.Reset();
	OutOptions = FNBSRunOptions();

	OutOptions.bApply = FParse::Param(*Params, TEXT("Apply"));
	OutOptions.bRevert = FParse::Param(*Params, TEXT("Revert"));
	OutOptions.bOnlyDynamic = FParse::Param(*Params, TEXT("OnlyDynamic"));

	if (OutOptions.bApply && OutOptions.bRevert)
	{
		OutError = TEXT("-Apply and -Revert are mutually exclusive: one writes measured bounds, the other restores the previous ones.");
		return false;
	}

	FString Path;
	if (FParse::Value(*Params, TEXT("Path="), Path))
	{
		Path.TrimStartAndEndInline();
		Path.RemoveFromEnd(TEXT("/"));
		if (!Path.StartsWith(TEXT("/")))
		{
			OutError = FString::Printf(
				TEXT("-Path must be a content path beginning with a slash, for example /Game/Effects. Got '%s'."), *Path);
			return false;
		}
		OutOptions.ScanPath = Path;
	}

	float Value = 0.0f;

	if (FParse::Value(*Params, TEXT("TickDelta="), Value))
	{
		if (!(Value >= MinTickDelta && Value <= MaxTickDelta))
		{
			// Written as a positive range test rather than `Value < Min || Value > Max` so that a
			// NaN - which fails every comparison - is REJECTED rather than sliding through.
			OutError = FString::Printf(
				TEXT("-TickDelta must be between %.5f and %.3f seconds (about 480fps to 5fps). Got %f."),
				MinTickDelta, MaxTickDelta, Value);
			return false;
		}
		OutOptions.TickDelta = Value;
	}

	if (FParse::Value(*Params, TEXT("MaxSeconds="), Value))
	{
		if (!(Value >= MinMaxSeconds && Value <= MaxMaxSeconds))
		{
			OutError = FString::Printf(
				TEXT("-MaxSeconds must be between %.1f and %.0f. Got %f."), MinMaxSeconds, MaxMaxSeconds, Value);
			return false;
		}
		OutOptions.MaxSeconds = Value;
	}

	if (FParse::Value(*Params, TEXT("Pad="), Value))
	{
		if (!(Value >= 0.0f && Value <= MaxPad))
		{
			OutError = FString::Printf(
				TEXT("-Pad is a fraction of the measured size and must be between 0 and %.0f. Got %f. ")
				TEXT("A negative pad would shrink a measured bound, which is the defect this tool exists to remove."),
				MaxPad, Value);
			return false;
		}
		OutOptions.Pad = Value;
	}

	FString ReportPath;
	OutOptions.ReportPath = FParse::Value(*Params, TEXT("Report="), ReportPath)
		? ReportPath
		: DefaultReportPath();

	FString JournalPath;
	OutOptions.JournalPath = FParse::Value(*Params, TEXT("Journal="), JournalPath)
		? JournalPath
		: DefaultJournalPath();

	return true;
}

FString NBSArgs::Usage()
{
	return TEXT(
		"Niagara Bounds Solver\n"
		"\n"
		"  Plays every Niagara system headlessly, one tick at a time, unions the local bounds across\n"
		"  the whole lifetime, and writes that union as FixedBounds. Systems it cannot honestly\n"
		"  simulate are reported as skipped and left exactly as they were.\n"
		"\n"
		"  -Path=/Game/Effects   Content path to scan. Default /Game.\n"
		"  -Apply                Write the measured bounds. Without it, nothing is written.\n"
		"  -Revert               Restore the bounds recorded in the journal by the last -Apply run.\n"
		"  -OnlyDynamic          Skip systems that already carry fixed bounds.\n"
		"  -TickDelta=0.0333     Simulation step in seconds. Default 1/30.\n"
		"  -MaxSeconds=10        Cap on simulated time per system. Default 10.\n"
		"  -Pad=0.05             Fraction of the measured size added on every side. Default 0.05.\n"
		"  -Report=<file.html>   Where the HTML sheet goes.\n"
		"  -Journal=<file.json>  Where the undo journal goes.\n"
		"  -Help                 This text.\n"
		"\n"
		"  Exit codes: 0 ok, 1 bad arguments, 2 nothing found, 3 one or more systems refused,\n"
		"              4 an asset could not be written.\n");
}
