// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "NBSScan.h"

#include "AssetRegistry/ARFilter.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "AssetRegistry/IAssetRegistry.h"
#include "Modules/ModuleManager.h"
#include "NiagaraSystem.h"

namespace
{
	/**
	 * The tag UNiagaraSystem publishes for its fixed-bounds state.
	 *
	 * READ OUT OF THE ENGINE, NOT GUESSED: NiagaraSystem.cpp:98 declares
	 * `static const FName NAME_FixedBoundsSize("FixedBoundsSize")` and :1845 writes it as
	 *
	 *     bFixedBounds ? FString::Printf(TEXT("%.2f"), BoundsSize) : FString(TEXT("None"))
	 *
	 * so the literal string "None" - not an empty value, and not an absent tag - is how the engine
	 * says "this system has no fixed bounds". A scan that tested for an empty string would classify
	 * every unfixed system as fixed and skip the entire population it was written to find.
	 */
	const FName TagFixedBoundsSize(TEXT("FixedBoundsSize"));
	const FString TagValueNone(TEXT("None"));
}

FName NBSScan::FixedBoundsTagName()
{
	return TagFixedBoundsSize;
}

bool NBSScan::FindSystems(const FString& ScanPath, TArray<FNBSCandidate>& OutCandidates)
{
	OutCandidates.Reset();

	FAssetRegistryModule& RegistryModule =
		FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
	IAssetRegistry& Registry = RegistryModule.Get();

	// ⚠️ A commandlet starts before the registry has finished its initial scan, and querying it
	// early returns a partial answer that looks exactly like a small project. This wing has
	// already shipped one defect of that shape, so the wait is not optional.
	Registry.WaitForCompletion();

	FARFilter Filter;
	Filter.bRecursivePaths = true;
	Filter.bRecursiveClasses = true;
	Filter.PackagePaths.Add(FName(*ScanPath));
	Filter.ClassPaths.Add(UNiagaraSystem::StaticClass()->GetClassPathName());

	TArray<FAssetData> Found;
	if (!Registry.GetAssets(Filter, Found))
	{
		return false;
	}

	OutCandidates.Reserve(Found.Num());
	for (const FAssetData& Asset : Found)
	{
		FNBSCandidate Candidate;
		Candidate.Asset = Asset;

		const FAssetDataTagMapSharedView::FFindTagResult TagResult = Asset.TagsAndValues.FindTag(TagFixedBoundsSize);
		if (TagResult.IsSet())
		{
			Candidate.bTagMissing = false;
			Candidate.bTagSaysFixedBounds = !TagResult.GetValue().Equals(TagValueNone, ESearchCase::IgnoreCase);
		}

		OutCandidates.Add(MoveTemp(Candidate));
	}

	return true;
}
