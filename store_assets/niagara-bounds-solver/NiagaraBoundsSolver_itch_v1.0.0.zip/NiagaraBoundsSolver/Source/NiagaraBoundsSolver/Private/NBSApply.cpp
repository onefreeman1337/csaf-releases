// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "NBSApply.h"

#include "Dom/JsonObject.h"
#include "FileHelpers.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "NiagaraEmitter.h"
#include "NiagaraEmitterHandle.h"
#include "NiagaraSystem.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonWriter.h"
#include "SourceControlHelpers.h"
#include "UObject/Package.h"
#include "UObject/UObjectGlobals.h"

DEFINE_LOG_CATEGORY_STATIC(LogNBSApply, Log, All);

namespace
{
	/** One system's previous state, enough to put it back exactly. */
	struct FNBSJournalEntry
	{
		FString AssetPath;
		bool bOldFixedBounds = false;
		FBox OldBounds = FBox(ForceInit);
		/** Emitter name -> whether its mode was Fixed, and its stored box. */
		TArray<TTuple<FString, bool, FBox>> Emitters;
	};

	TArray<FNBSJournalEntry> GJournal;
	TSet<UPackage*> GModifiedPackages;

	TSharedPtr<FJsonObject> BoxToJson(const FBox& Box)
	{
		TSharedPtr<FJsonObject> Obj = MakeShared<FJsonObject>();
		Obj->SetBoolField(TEXT("valid"), Box.IsValid != 0);
		Obj->SetNumberField(TEXT("minX"), Box.Min.X);
		Obj->SetNumberField(TEXT("minY"), Box.Min.Y);
		Obj->SetNumberField(TEXT("minZ"), Box.Min.Z);
		Obj->SetNumberField(TEXT("maxX"), Box.Max.X);
		Obj->SetNumberField(TEXT("maxY"), Box.Max.Y);
		Obj->SetNumberField(TEXT("maxZ"), Box.Max.Z);
		return Obj;
	}

	FBox BoxFromJson(const TSharedPtr<FJsonObject>& Obj)
	{
		if (!Obj.IsValid() || !Obj->GetBoolField(TEXT("valid")))
		{
			return FBox(ForceInit);
		}

		FBox Box(ForceInit);
		Box.Min = FVector(Obj->GetNumberField(TEXT("minX")), Obj->GetNumberField(TEXT("minY")), Obj->GetNumberField(TEXT("minZ")));
		Box.Max = FVector(Obj->GetNumberField(TEXT("maxX")), Obj->GetNumberField(TEXT("maxY")), Obj->GetNumberField(TEXT("maxZ")));
		Box.IsValid = 1;
		return Box;
	}
}

void NBSApply::ResetJournal()
{
	GJournal.Reset();
	GModifiedPackages.Reset();
}

int32 NBSApply::JournalNum()
{
	return GJournal.Num();
}

void NBSApply::RecordJournalEntry(const FNBSSystemResult& Result)
{
	FNBSJournalEntry Entry;
	Entry.AssetPath = Result.AssetPath;
	Entry.bOldFixedBounds = Result.bOldFixedBounds;
	Entry.OldBounds = Result.OldBounds;
	for (const FNBSEmitterResult& Emitter : Result.Emitters)
	{
		Entry.Emitters.Emplace(Emitter.EmitterName, Emitter.bOldModeFixed, Emitter.OldBounds);
	}
	GJournal.Add(MoveTemp(Entry));
}

bool NBSApply::FlushJournal(const FString& JournalPath, FString& OutError)
{
	OutError.Reset();

	TArray<TSharedPtr<FJsonValue>> Entries;
	Entries.Reserve(GJournal.Num());

	for (const FNBSJournalEntry& Entry : GJournal)
	{
		TSharedPtr<FJsonObject> Obj = MakeShared<FJsonObject>();
		Obj->SetStringField(TEXT("asset"), Entry.AssetPath);
		Obj->SetBoolField(TEXT("bFixedBounds"), Entry.bOldFixedBounds);
		Obj->SetObjectField(TEXT("fixedBounds"), BoxToJson(Entry.OldBounds));

		TArray<TSharedPtr<FJsonValue>> EmitterValues;
		for (const TTuple<FString, bool, FBox>& Emitter : Entry.Emitters)
		{
			TSharedPtr<FJsonObject> EmitterObj = MakeShared<FJsonObject>();
			EmitterObj->SetStringField(TEXT("name"), Emitter.Get<0>());
			EmitterObj->SetBoolField(TEXT("modeFixed"), Emitter.Get<1>());
			EmitterObj->SetObjectField(TEXT("fixedBounds"), BoxToJson(Emitter.Get<2>()));
			EmitterValues.Add(MakeShared<FJsonValueObject>(EmitterObj));
		}
		Obj->SetArrayField(TEXT("emitters"), EmitterValues);

		Entries.Add(MakeShared<FJsonValueObject>(Obj));
	}

	TSharedPtr<FJsonObject> Root = MakeShared<FJsonObject>();
	Root->SetStringField(TEXT("tool"), TEXT("NiagaraBoundsSolver"));
	Root->SetStringField(TEXT("writtenAt"), FDateTime::UtcNow().ToIso8601());
	Root->SetArrayField(TEXT("systems"), Entries);

	FString Json;
	TSharedRef<TJsonWriter<TCHAR, TPrettyJsonPrintPolicy<TCHAR>>> Writer =
		TJsonWriterFactory<TCHAR, TPrettyJsonPrintPolicy<TCHAR>>::Create(&Json);
	if (!FJsonSerializer::Serialize(Root.ToSharedRef(), Writer))
	{
		OutError = TEXT("The undo journal could not be serialised, so nothing was written.");
		return false;
	}

	if (!FFileHelper::SaveStringToFile(Json, *JournalPath))
	{
		OutError = FString::Printf(
			TEXT("The undo journal could not be written to '%s', so nothing was applied. ")
			TEXT("A run that cannot be undone is not a run this tool will start."), *JournalPath);
		return false;
	}

	return true;
}

bool NBSApply::WriteSystem(UNiagaraSystem* System, FNBSSystemResult& Result)
{
	if (System == nullptr || !Result.WrittenBounds.IsValid)
	{
		return false;
	}

	System->Modify();

	System->bFixedBounds = true;
	System->SetFixedBounds(Result.WrittenBounds);

	for (FNiagaraEmitterHandle& Handle : System->GetEmitterHandles())
	{
		FVersionedNiagaraEmitterData* Data = Handle.GetEmitterData();
		if (Data == nullptr || !Handle.GetIsEnabled())
		{
			continue;
		}

		// Only GPU emitters left on Dynamic are pinned. The engine states outright that GPU
		// emitters do not support dynamic bounds (NiagaraValidationRules.cpp:467-470), so leaving
		// one would keep the asset failing the engine's OWN validation even after we fixed the
		// system. A CPU emitter on Dynamic is legitimate once the system carries fixed bounds, and
		// pinning it would be changing something the user did not ask us to change.
		if (Data->SimTarget != ENiagaraSimTarget::GPUComputeSim ||
			Data->CalculateBoundsMode != ENiagaraEmitterCalculateBoundMode::Dynamic)
		{
			continue;
		}

		if (UNiagaraEmitter* Emitter = Handle.GetInstance().Emitter)
		{
			Emitter->Modify();
		}

		Data->CalculateBoundsMode = ENiagaraEmitterCalculateBoundMode::Fixed;

		// ⛔ Data->FixedBounds, the live property on FVersionedNiagaraEmitterData
		// (NiagaraEmitter.h:357). NOT UNiagaraEmitter::FixedBounds_DEPRECATED (:878), which is
		// still a compilable UPROPERTY whose own comment says "Use property in struct returned from
		// GetEmitterData() instead". Writing that one would compile clean, save clean, and change
		// nothing a buyer could see.
		Data->FixedBounds = Result.WrittenBounds;

		const FString EmitterName = Handle.GetName().ToString();
		for (FNBSEmitterResult& EmitterResult : Result.Emitters)
		{
			if (EmitterResult.EmitterName == EmitterName)
			{
				EmitterResult.NewBounds = Result.WrittenBounds;
				EmitterResult.bMeasured = true;
				EmitterResult.bWritten = true;
				break;
			}
		}
	}

	if (UPackage* Package = System->GetOutermost())
	{
		Package->SetDirtyFlag(true);
		GModifiedPackages.Add(Package);
	}

	Result.bWritten = true;
	return true;
}

bool NBSApply::SaveModified(TArray<FString>& OutProblems, int32& OutSaved, int32& OutFailed)
{
	OutSaved = 0;
	OutFailed = 0;

	if (GModifiedPackages.Num() == 0)
	{
		return true;
	}

	TArray<UPackage*> Packages = GModifiedPackages.Array();

	// The explicit half of the promise. SavePackages checks out too, but a tool that says it checks
	// out before it writes has to be able to name what it checked out.
	TArray<FString> Filenames;
	Filenames.Reserve(Packages.Num());
	for (const UPackage* Package : Packages)
	{
		FString Filename;
		if (FPackageName::TryConvertLongPackageNameToFilename(Package->GetName(), Filename, FPackageName::GetAssetPackageExtension()))
		{
			Filenames.Add(Filename);
		}
	}

	if (Filenames.Num() > 0 && USourceControlHelpers::IsAvailable())
	{
		if (!USourceControlHelpers::CheckOutOrAddFiles(Filenames))
		{
			OutProblems.Add(FString::Printf(
				TEXT("Source control refused to check out one or more of the %d files; the save below may fail for those."),
				Filenames.Num()));
		}
	}

	const bool bSaved = UEditorLoadingAndSavingUtils::SavePackages(Packages, /*bOnlyDirty*/ false);
	if (bSaved)
	{
		OutSaved = Packages.Num();
	}
	else
	{
		OutFailed = Packages.Num();
		OutProblems.Add(FString::Printf(
			TEXT("%d package(s) could not be saved. The in-memory bounds are correct but nothing reached disk; ")
			TEXT("check the files are writable and re-run."), Packages.Num()));
	}

	GModifiedPackages.Reset();
	return bSaved;
}

int32 NBSApply::RevertFromJournal(const FString& JournalPath, TArray<FString>& OutProblems)
{
	FString Json;
	if (!FFileHelper::LoadFileToString(Json, *JournalPath))
	{
		OutProblems.Add(FString::Printf(TEXT("No undo journal at '%s'."), *JournalPath));
		return INDEX_NONE;
	}

	TSharedPtr<FJsonObject> Root;
	const TSharedRef<TJsonReader<TCHAR>> Reader = TJsonReaderFactory<TCHAR>::Create(Json);
	if (!FJsonSerializer::Deserialize(Reader, Root) || !Root.IsValid())
	{
		OutProblems.Add(FString::Printf(TEXT("The undo journal at '%s' is not readable JSON."), *JournalPath));
		return INDEX_NONE;
	}

	const TArray<TSharedPtr<FJsonValue>>* Systems = nullptr;
	if (!Root->TryGetArrayField(TEXT("systems"), Systems) || Systems == nullptr)
	{
		OutProblems.Add(TEXT("The undo journal has no 'systems' array."));
		return INDEX_NONE;
	}

	int32 Restored = 0;
	for (const TSharedPtr<FJsonValue>& Value : *Systems)
	{
		const TSharedPtr<FJsonObject>& Obj = Value->AsObject();
		if (!Obj.IsValid())
		{
			continue;
		}

		const FString AssetPath = Obj->GetStringField(TEXT("asset"));
		UNiagaraSystem* System = LoadObject<UNiagaraSystem>(nullptr, *AssetPath);
		if (System == nullptr)
		{
			OutProblems.Add(FString::Printf(TEXT("Could not load '%s' to revert it."), *AssetPath));
			continue;
		}

		System->Modify();
		System->bFixedBounds = Obj->GetBoolField(TEXT("bFixedBounds"));
		System->SetFixedBounds(BoxFromJson(Obj->GetObjectField(TEXT("fixedBounds"))));

		const TArray<TSharedPtr<FJsonValue>>* Emitters = nullptr;
		if (Obj->TryGetArrayField(TEXT("emitters"), Emitters) && Emitters != nullptr)
		{
			for (const TSharedPtr<FJsonValue>& EmitterValue : *Emitters)
			{
				const TSharedPtr<FJsonObject>& EmitterObj = EmitterValue->AsObject();
				if (!EmitterObj.IsValid())
				{
					continue;
				}

				const FString Name = EmitterObj->GetStringField(TEXT("name"));
				for (FNiagaraEmitterHandle& Handle : System->GetEmitterHandles())
				{
					if (Handle.GetName().ToString() != Name)
					{
						continue;
					}
					if (FVersionedNiagaraEmitterData* Data = Handle.GetEmitterData())
					{
						if (UNiagaraEmitter* Emitter = Handle.GetInstance().Emitter)
						{
							Emitter->Modify();
						}
						Data->CalculateBoundsMode = EmitterObj->GetBoolField(TEXT("modeFixed"))
							? ENiagaraEmitterCalculateBoundMode::Fixed
							: ENiagaraEmitterCalculateBoundMode::Dynamic;
						Data->FixedBounds = BoxFromJson(EmitterObj->GetObjectField(TEXT("fixedBounds")));
					}
					break;
				}
			}
		}

		if (UPackage* Package = System->GetOutermost())
		{
			Package->SetDirtyFlag(true);
			GModifiedPackages.Add(Package);
		}
		++Restored;
	}

	return Restored;
}
