// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "NBSSolve.h"

#include "Engine/Engine.h"
#include "Engine/World.h"
#include "Misc/App.h"
// ON_SCOPE_EXIT (used below for the forced-dynamic-bounds restore). This compiled without the
// include because the shared PCH happens to provide it - which is a build-configuration accident,
// not a guarantee, and it breaks the moment this file is compiled outside that PCH.
#include "Misc/ScopeExit.h"
#include "NBSUnion.h"
#include "NiagaraComponent.h"
#include "NiagaraEmitter.h"
#include "NiagaraEmitterHandle.h"
#include "NiagaraEmitterInstance.h"
#include "NiagaraSystem.h"
#include "NiagaraSystemInstance.h"
#include "NiagaraSystemInstanceController.h"

DEFINE_LOG_CATEGORY_STATIC(LogNBSSolve, Log, All);

namespace
{
	/**
	 * ⛔ THE TRAP THAT DEFINES THIS WHOLE FILE, and it is not obvious from the API.
	 *
	 * FNiagaraSystemInstance::TickInstanceParameters_Concurrent (NiagaraSystemInstance.cpp:2755-2763)
	 * computes LocalBounds like this:
	 *
	 *     if (FixedBounds_CNC.IsValid)   LocalBounds = FixedBounds_CNC;
	 *     else if (System->bFixedBounds) LocalBounds = System->GetFixedBounds();
	 *     else                           <union of the emitters' live bounds>
	 *
	 * So on a system that ALREADY has fixed bounds, GetLocalBounds() hands back the stored box
	 * every single tick, no matter what the particles are doing. Measuring such a system without
	 * this guard would "measure" its existing, possibly far too small, bounds and then confirm them
	 * as correct - a green result produced by work that never happened, and precisely the shipped
	 * bug this product is sold to fix.
	 *
	 * The same applies per emitter: FVersionedNiagaraEmitterData::CalculateBoundsMode == Fixed makes
	 * FNiagaraEmitterInstance::AreBoundsDynamic() false, and the instance then contributes the
	 * emitter's stored box instead of its live one.
	 *
	 * So measurement temporarily forces the whole system to dynamic, and this scope guard puts every
	 * value back exactly as it was. It deliberately does NOT call Modify() - measuring must never
	 * dirty a package, or a preview run would leave the project changed.
	 */
	class FScopedForceDynamicBounds
	{
	public:
		explicit FScopedForceDynamicBounds(UNiagaraSystem* InSystem)
			: System(InSystem)
		{
			if (System == nullptr)
			{
				return;
			}

			bSavedFixedBounds = System->bFixedBounds;
			System->bFixedBounds = false;

			for (FNiagaraEmitterHandle& Handle : System->GetEmitterHandles())
			{
				if (FVersionedNiagaraEmitterData* Data = Handle.GetEmitterData())
				{
					SavedModes.Add(Data, Data->CalculateBoundsMode);
					Data->CalculateBoundsMode = ENiagaraEmitterCalculateBoundMode::Dynamic;
				}
			}
		}

		~FScopedForceDynamicBounds()
		{
			if (System == nullptr)
			{
				return;
			}

			System->bFixedBounds = bSavedFixedBounds;
			for (const TPair<FVersionedNiagaraEmitterData*, ENiagaraEmitterCalculateBoundMode>& Pair : SavedModes)
			{
				Pair.Key->CalculateBoundsMode = Pair.Value;
			}
		}

		FScopedForceDynamicBounds(const FScopedForceDynamicBounds&) = delete;
		FScopedForceDynamicBounds& operator=(const FScopedForceDynamicBounds&) = delete;

	private:
		UNiagaraSystem* System = nullptr;
		bool bSavedFixedBounds = false;
		TMap<FVersionedNiagaraEmitterData*, ENiagaraEmitterCalculateBoundMode> SavedModes;
	};

	/** True when any enabled emitter on the asset simulates on the GPU. */
	bool SystemHasGpuEmitter(const UNiagaraSystem* System)
	{
		for (const FNiagaraEmitterHandle& Handle : System->GetEmitterHandles())
		{
			if (!Handle.GetIsEnabled())
			{
				continue;
			}
			if (const FVersionedNiagaraEmitterData* Data = Handle.GetEmitterData())
			{
				if (Data->SimTarget == ENiagaraSimTarget::GPUComputeSim)
				{
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Total live particles across every emitter of a solo instance.
	 *
	 * ⭐ THIS IS THE HONESTY GATE, and it exists because the bounds alone cannot provide one.
	 * NiagaraSystemInstance.cpp:2802-2807: when a tick produces no bounds at all the engine does not
	 * leave the box empty, it substitutes FBox(-1,-1,-1)..(1,1,1) - a VALID, non-degenerate two
	 * centimetre cube - with its own comment explaining that a zero volume causes culling problems.
	 * That default would sail through any "is this box usable" test and be unioned in as though it
	 * were measured. So a sample is only trusted when a particle was actually alive to produce it.
	 */
	int32 CountLiveParticles(FNiagaraSystemInstance* Instance)
	{
		int32 Total = 0;
		for (const FNiagaraEmitterInstanceRef& Emitter : Instance->GetEmitters())
		{
			Total += FMath::Max(0, Emitter->GetNumParticles());
		}
		return Total;
	}
}

UWorld* NBSSolve::CreateMeasurementWorld()
{
	// A throwaway EditorPreview world: no level, no actors, nothing persisted. FNiagaraSystemInstance
	// only requires that World is non-null and not tearing down (NiagaraSystemInstance.cpp:1015).
	UWorld* World = UWorld::CreateWorld(EWorldType::EditorPreview, /*bInformEngineOfWorld*/ false);
	if (World == nullptr)
	{
		return nullptr;
	}

	World->AddToRoot();
	return World;
}

void NBSSolve::DestroyMeasurementWorld(UWorld* World)
{
	if (World == nullptr)
	{
		return;
	}

	World->RemoveFromRoot();
	World->DestroyWorld(/*bInformEngineOfWorld*/ false);
}

bool NBSSolve::MeasureSystem(
	UWorld* World,
	UNiagaraSystem* System,
	const FNBSRunOptions& Options,
	FNBSSystemResult& Result)
{
	if (World == nullptr || System == nullptr)
	{
		Result.Skip = ENBSSkip::InstanceUnavailable;
		return false;
	}

	// Record what the asset said BEFORE anything is forced, so the report can show the real before.
	Result.bOldFixedBounds = System->bFixedBounds;
	Result.OldBounds = System->GetFixedBounds();

	/*
	 * ⛔ REFUSE A SYSTEM WITH ANY ENABLED STATELESS EMITTER, BEFORE MEASURING ANYTHING.
	 *
	 * UE 5.5+ stateless (Lightweight) emitters live in a separate field of the handle
	 * (NiagaraEmitterHandle.h:91) and their GetEmitterData() is null, so the loop below skipped
	 * them entirely and the system-level measurement quietly fell through to the engine's default
	 * 200cm cube - which was then reported as a MEASURED UNION with a growth factor.
	 *
	 * Measured 2026-08-31: five fixture systems from three different Lightweight templates all
	 * "measured" exactly 200,200,200. A fountain and a burst do not share a bounding box, so that
	 * was a constant wearing a measurement's clothes. Refusing is the only honest answer available
	 * here, and it is the rule this product is sold on.
	 */
	int32 StatelessCount = 0;
	for (const FNiagaraEmitterHandle& Handle : System->GetEmitterHandles())
	{
		if (Handle.GetIsEnabled() && Handle.GetStatelessEmitter() != nullptr)
		{
			++StatelessCount;
		}
	}
	if (StatelessCount > 0)
	{
		// A MIXED system is refused too. Measuring only its versioned emitters would produce a union
		// that omits the stateless ones - an under-bound, i.e. the exact bug this tool exists to fix.
		Result.Skip = ENBSSkip::StatelessEmitterUnsupported;
		return false;
	}

	Result.Emitters.Reset();
	for (const FNiagaraEmitterHandle& Handle : System->GetEmitterHandles())
	{
		const FVersionedNiagaraEmitterData* Data = Handle.GetEmitterData();
		if (Data == nullptr || !Handle.GetIsEnabled())
		{
			continue;
		}

		FNBSEmitterResult EmitterResult;
		EmitterResult.EmitterName = Handle.GetName().ToString();
		EmitterResult.bOldModeFixed = Data->CalculateBoundsMode == ENiagaraEmitterCalculateBoundMode::Fixed;
		EmitterResult.OldBounds = Data->FixedBounds;
		EmitterResult.bGpu = Data->SimTarget == ENiagaraSimTarget::GPUComputeSim;
		Result.Emitters.Add(MoveTemp(EmitterResult));
	}

	// A GPU system cannot be honestly measured without an RHI to read its counts back through, and
	// saying so is better than reporting a confident zero (NiagaraEmitterInstanceImpl.cpp:890-901).
	//
	// ⚠️ FApp::CanEverRender(), not GIsRHIInitialized. The first attempt used the latter and the
	// gate caught it as LNK2019 on GRHIGlobals: that symbol lives in the RHI module, so reading it
	// would have meant adding RHI to Build.cs purely to ask a yes/no question. CanEverRender() is
	// in Core, needs no new dependency, and is the more precise test anyway - it is false for
	// exactly the -nullrhi and commandlet cases where a GPU readback cannot work.
	if (SystemHasGpuEmitter(System) && !FApp::CanEverRender())
	{
		Result.Skip = ENBSSkip::GpuRequiresEditorRun;
		return false;
	}

	const FScopedForceDynamicBounds ForceDynamic(System);

	UNiagaraComponent* Component = NewObject<UNiagaraComponent>(World);
	if (Component == nullptr)
	{
		Result.Skip = ENBSSkip::InstanceUnavailable;
		return false;
	}

	// Kept alive explicitly for the duration of the measurement: nothing else references this
	// component, and a GC between ticks would otherwise be free to collect it mid-simulation.
	Component->AddToRoot();

	ON_SCOPE_EXIT
	{
		Component->DeactivateImmediate();
		Component->UnregisterComponent();
		Component->RemoveFromRoot();
	};

	Component->SetAsset(System);
	Component->SetAutoActivate(false);

	// Solo for two reasons, both load-bearing. It makes the simulation deterministic and ticked on
	// this thread, and it is the documented precondition for GetSoloSystemInstance()
	// (NiagaraSystemInstanceController.h:87) - the only NON-deprecated way to reach the emitters.
	Component->SetForceSolo(true);
	Component->SetRelativeTransform(FTransform::Identity);
	Component->RegisterComponentWithWorld(World);
	Component->Activate(true);

	FNiagaraSystemInstanceControllerPtr Controller = Component->GetSystemInstanceController();
	if (!Controller.IsValid())
	{
		Result.Skip = ENBSSkip::InstanceUnavailable;
		return false;
	}

	FNiagaraSystemInstance* Instance = Controller->GetSoloSystemInstance();
	if (Instance == nullptr)
	{
		Result.Skip = ENBSSkip::InstanceUnavailable;
		return false;
	}

	const int32 MaxTicks = FMath::Max(1, FMath::CeilToInt(Options.MaxSeconds / Options.TickDelta));

	FNBSBoundsAccumulator Accumulator;
	bool bStillRunningAtCap = true;

	for (int32 Tick = 0; Tick < MaxTicks; ++Tick)
	{
		// ⚠️ ONE tick per call, deliberately. AdvanceSimulation(N, dt) would run N ticks internally
		// (NiagaraSystemInstance.cpp:1002-1007) and only the FINAL state would be observable - which
		// is the single-frame sample this product exists to replace. The union needs every frame.
		Component->AdvanceSimulation(1, Options.TickDelta);
		++Result.TicksSimulated;

		if (Controller->IsComplete())
		{
			bStillRunningAtCap = false;
			break;
		}

		if (CountLiveParticles(Instance) > 0)
		{
			if (Accumulator.Add(Controller->GetLocalBounds()))
			{
				++Result.TicksWithParticles;
			}
		}
	}

	Result.SimulatedSeconds = Result.TicksSimulated * Options.TickDelta;

	if (!Accumulator.HasResult())
	{
		Result.Skip = Result.TicksWithParticles == 0
			? ENBSSkip::NoParticlesEverSpawned
			: ENBSSkip::DegenerateBounds;
		return false;
	}

	Result.MeasuredBounds = Accumulator.GetUnion();
	Result.WrittenBounds = Accumulator.GetPadded(Options.Pad);
	Result.GrowthFactor = FNBSBoundsAccumulator::GrowthFactor(Result.OldBounds, Result.WrittenBounds);

	// A system that never finished inside the cap has only been partly observed, and a union over a
	// truncated window is not the lifetime union this product promises. Report the measurement and
	// refuse to write it.
	if (bStillRunningAtCap)
	{
		Result.Skip = ENBSSkip::LifetimeExceededCap;
		return false;
	}

	return true;
}
