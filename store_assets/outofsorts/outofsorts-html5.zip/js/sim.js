/* OUT OF SORTS — sim.js : the round.
 *
 * The case (case.js) is system TWO. This file is system ONE — setting the line — and the whole
 * design of the game is in how the two touch (ledger B5, the complexity floor):
 *
 *   · A word can only be LOCKED if the case can actually set it. So the case does not merely
 *     score your typing, it decides what is on the board at all. Run your E down and half the
 *     copy in front of you goes grey and stops being an option.
 *   · Spending is ATOMIC on completion, never per keystroke, so a half-typed word costs nothing
 *     and the sim has exactly one place where sorts leave the drawer.
 *   · A MISTYPE does not cost time, it PIES a sort — one piece of metal on the floor and into the
 *     hell box, where distribution cannot reach it. Accuracy is therefore an economic pressure
 *     rather than a score multiplier, which is the only way it stays interesting in a game whose
 *     resource is letters.
 *   · DISTRIBUTION is the pressure valve and it is not free: two and a bit seconds during which
 *     you cannot set anything and the galley keeps coming.
 *   · The fail state is not a health bar reaching zero. It is being OUT OF SORTS: nothing on the
 *     board is settable AND distributing would not change that. That is a real dead end and the
 *     sim proves it is one before declaring it.
 *
 * No DOM, no canvas, no timers: this file is a pure state machine so it can be tested in node
 * against thousands of frames. Rendering reads it and never writes to it.
 */
(function (root) {
  'use strict';

  var CASE = (typeof require !== 'undefined' && typeof module !== 'undefined') ? require('./case.js') : root.CASE;
  var WORDS = (typeof require !== 'undefined' && typeof module !== 'undefined') ? require('./words.js') : root.WORDS;

  var TRACK = { right: 952, stick: 178 };     // the galley: threats walk right -> left
  var LANES = 4;

  /* --------------------------------------------------------------- the copy
   * Five kinds of trouble, and every one of them is a real printing fault, because the fantasy is
   * that the shop's own errors have got up and started walking.
   */
  var KINDS = {
    pie:    { speed: 15.5, bands: [1, 2, 3], score: 1.0, label: 'pied type' },
    orphan: { speed: 27.0, bands: [1],       score: 0.8, label: 'an orphan' },
    monk:   { speed: 9.0,  bands: [2, 3],    score: 2.1, label: 'a monk',  doubles: true },
    devil:  { speed: 24.0, bands: [1, 2],    score: 1.4, label: 'a devil', pies: 3 },
    quad:   { speed: 8.0,  bands: [3, 4],    score: 2.6, label: 'a quad',  words: 2 }
  };

  /* Deterministic PRNG. A run has to be reproducible or the suite below proves nothing. */
  function rng(seed) {
    var s = seed >>> 0 || 1;
    return function () { s ^= s << 13; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
  }

  /* -------------------------------------------------------------- the formes
   * A book of ten formes. Each names its threat mix and its length; the ramp is authored rather
   * than computed so the difficulty curve is a design decision that can be read in one screen.
   */
  var FORMES = [
    { title: 'A HANDBILL',            n: 8,  kinds: ['pie', 'orphan'],                              rate: 3.4, spoils: 3 },
    { title: 'A TRADE CARD',          n: 10, kinds: ['pie', 'orphan', 'pie'],                       rate: 3.1, spoils: 3 },
    { title: 'AN AUCTION BILL',       n: 12, kinds: ['pie', 'orphan', 'monk'],                      rate: 2.9, spoils: 3 },
    { title: 'A BROADSIDE',           n: 13, kinds: ['pie', 'monk', 'devil'],                       rate: 2.7, spoils: 3 },
    { title: 'THE PARISH NOTICES',    n: 15, kinds: ['pie', 'orphan', 'devil', 'monk'],             rate: 2.5, spoils: 3 },
    { title: 'A BOOK OF HOURS',       n: 16, kinds: ['pie', 'monk', 'quad'],                        rate: 2.4, spoils: 3 },
    { title: 'THE HARBOUR TIMETABLE', n: 18, kinds: ['pie', 'orphan', 'devil', 'quad'],             rate: 2.2, spoils: 4 },
    { title: 'AN ALMANAC',            n: 20, kinds: ['pie', 'monk', 'devil', 'quad', 'orphan'],     rate: 2.0, spoils: 4 },
    { title: 'THE SUBSCRIPTION LIST', n: 22, kinds: ['pie', 'monk', 'devil', 'quad'],               rate: 1.9, spoils: 4 },
    { title: 'THE EDITION',           n: 26, kinds: ['pie', 'orphan', 'monk', 'devil', 'quad'],     rate: 1.7, spoils: 4 }
  ];

  /* --------------------------------------------------------------- upgrades
   * Every one of these changes WHICH WORDS ARE AFFORDABLE. Not one of them is a damage number,
   * because there are no damage numbers in this game — the only currency is letters.
   */
  var LIGATURES = ['th', 'in', 'er', 'on', 'an', 'ing'];
  var UPGRADES = {
    swift:    { name: 'A SWIFTER STICK',  cost: 26, desc: 'Distribution takes 1.2 seconds instead of 2.4.' },
    alloy:    { name: 'HARD METAL',       cost: 34, desc: 'A word set with no mistakes returns its rarest sort to the case.' },
    imposing: { name: 'THE IMPOSING STONE', cost: 30, desc: 'Every second word set lifts one sort back out of the hell box.' },
    redink:   { name: 'THE SECOND COLOUR', cost: 40, desc: 'Every fourth line you set this forme is worth double.' },
    deeper:   { name: 'A DEEPER DRAWER',  cost: 48, desc: 'One more of EVERY sort, permanently. Can be bought again.', repeat: true }
  };

  /* ------------------------------------------------------------ the foundry
   * The persistent half. A lost forme costs the forme; it never costs anything in here.
   */
  function newFoundry() {
    return { cast: {}, ligatures: [], owned: {}, deeper: 0, banked: 0, formeReached: 0, formesWon: 0 };
  }

  function caseFor(foundry) {
    var over = {};
    for (var k in CASE.STANDARD_LAY) {
      if (!Object.prototype.hasOwnProperty.call(CASE.STANDARD_LAY, k)) continue;
      over[k] = CASE.STANDARD_LAY[k] + (foundry.cast[k] || 0) + (foundry.deeper || 0);
    }
    var cs = CASE.createCase(over, []);
    for (var i = 0; i < foundry.ligatures.length; i++) CASE.addLigature(cs, foundry.ligatures[i]);
    return cs;
  }

  /* ------------------------------------------------------------- the round */

  function startForme(foundry, index, seed) {
    var spec = FORMES[Math.min(index, FORMES.length - 1)];
    /* past the last authored forme the shop just keeps printing — the night shift */
    var over = index >= FORMES.length ? (index - FORMES.length + 1) : 0;
    var cs = caseFor(foundry);
    var pool = WORDS.WORDS.filter(function (e) { return CASE.settableFromLay(cs, e.w); });
    return {
      foundry: foundry,
      index: index,
      title: over ? 'THE NIGHT SHIFT ' + over : spec.title,
      cs: cs,
      pool: pool,
      rand: rng(seed || (index * 7919 + 13)),
      threats: [],
      nextId: 1,
      toSpawn: spec.n + over * 3,
      spawned: 0,
      spawnIn: 1.1,
      rate: Math.max(1.1, spec.rate - over * 0.06),
      spoils: 0,
      maxSpoils: spec.spoils,
      kinds: spec.kinds,
      entry: '',
      lock: 0,
      distributing: 0,
      distributeTime: foundry.owned.swift ? 1.2 : 2.4,
      impressions: 0,
      lines: [],                 // what has been printed on the page, in order
      cleanRun: true,            // has this word been typed without a mistake
      setCount: 0,
      mistakes: 0,
      pied: 0,
      t: 0,
      phase: 'setting',
      flash: null,
      deadReason: ''
    };
  }

  /**
   * ⛔ THE MULTIPLIER IS PART OF THE FILTER, AND LEAVING IT OUT SHIPPED AN UNWINNABLE FORME.
   * The pool is built once from `settableFromLay`, which asks "can a full drawer set this word".
   * A MONK doubles every sort it needs — so a monk carrying QUOIN needs TWO q against a lay of
   * one, and no amount of distributing, buying or perfect typing can ever set it. The round then
   * ended in an instant, unavoidable "out of sorts" with an EMPTY hell box, which is the tell:
   * the loss condition was firing correctly on a board that should never have existed.
   * Master §2b, the recurring shape — the check was real and correct, and ran on the wrong inputs.
   */
  function pickWord(g, band, mult) {
    var m = mult || 1;
    var cand = g.pool.filter(function (e) {
      if (!(e.band === band || (band > 1 && e.band === 0 && e.w.length >= 4))) return false;
      if (m === 1) return true;
      var need = CASE.costOf(g.cs, e.w);
      for (var k in need) {
        if (!Object.prototype.hasOwnProperty.call(need, k)) continue;
        if ((g.cs.lay[k] || 0) < need[k] * m) return false;
      }
      return true;
    });
    if (cand.length === 0) cand = g.pool.filter(function (e) {
      if (m === 1) return true;
      var need = CASE.costOf(g.cs, e.w);
      for (var k in need) {
        if (!Object.prototype.hasOwnProperty.call(need, k)) continue;
        if ((g.cs.lay[k] || 0) < need[k] * m) return false;
      }
      return true;
    });
    /* never offer a word that is already on the board — two identical slips is a UI bug the
       player experiences as unfairness */
    for (var tries = 0; tries < 24; tries++) {
      var e = cand[Math.floor(g.rand() * cand.length) % cand.length];
      var clash = false;
      for (var i = 0; i < g.threats.length; i++) if (g.threats[i].words.indexOf(e.w) >= 0) clash = true;
      if (!clash) return e;
    }
    return cand[0];
  }

  function spawn(g) {
    var kind = g.kinds[Math.floor(g.rand() * g.kinds.length) % g.kinds.length];
    var K = KINDS[kind];
    var words = [];
    var count = K.words || 1;
    var mult = K.doubles ? 2 : 1;
    for (var i = 0; i < count; i++) {
      var band = K.bands[Math.floor(g.rand() * K.bands.length) % K.bands.length];
      words.push(pickWord(g, band, mult).w);
    }
    /* ⛔ LANE SPACING IS A LEGIBILITY RULE, NOT A NICETY. Picking a lane at random let two slugs
       spawn on top of each other, and their paper slips then overprinted into an unreadable
       jumble — "lante jetsam" — which in a game where you type what you read is not a cosmetic
       problem, it is an unplayable board. Caught by looking at a frame of the demo GIF, not by any
       assertion. Prefer the lane whose last arrival is furthest along; only stack if every lane is
       genuinely busy, which is a real late-forme state rather than a random accident. */
    var lane = 0, bestGap = -1e9;
    for (var L = 0; L < LANES; L++) {
      var right = -1e9;
      for (var q = 0; q < g.threats.length; q++) if (g.threats[q].lane === L) right = Math.max(right, g.threats[q].x);
      var gap = right === -1e9 ? 1e9 : TRACK.right - right;
      /* a small deterministic jitter so a quiet board does not always fill lanes in the same order */
      gap += g.rand() * 40;
      if (gap > bestGap) { bestGap = gap; lane = L; }
    }
    var th = {
      id: g.nextId++, kind: kind, lane: lane, x: TRACK.right + Math.floor(g.rand() * 40),
      words: words, step: 0, speed: K.speed * (0.9 + g.rand() * 0.25), seed: Math.floor(g.rand() * 65536)
    };
    g.threats.push(th);
    g.spawned++;
  }

  function target(th) { return th.words[th.step]; }

  /** What a threat's current word costs, doubled for a monk (over-inked: it takes twice the metal). */
  function costFor(g, th) {
    var base = CASE.costOf(g.cs, target(th));
    if (!KINDS[th.kind].doubles) return base;
    var out = {};
    for (var k in base) if (Object.prototype.hasOwnProperty.call(base, k)) out[k] = base[k] * 2;
    return out;
  }

  /** Can the case set this threat's word right now? Returns {ok} or {ok:false, short:{...}}. */
  function affordable(g, th) {
    var need = costFor(g, th), short = null;
    for (var k in need) {
      if (!Object.prototype.hasOwnProperty.call(need, k)) continue;
      var have = g.cs.sorts[k] === undefined ? 0 : g.cs.sorts[k];
      if (have < need[k]) { short = short || {}; short[k] = need[k] - have; }
    }
    return short ? { ok: false, short: short } : { ok: true };
  }

  /** Spend a threat's word. Atomic: either every sort leaves the case or none does. */
  function spend(g, th) {
    var need = costFor(g, th);
    for (var k in need) {
      if (!Object.prototype.hasOwnProperty.call(need, k)) continue;
      g.cs.sorts[k] -= need[k];
      g.cs.spent[k] = (g.cs.spent[k] || 0) + need[k];
    }
    g.cs.inForme.push(target(th));
  }

  /* ---------------------------------------------------------------- typing */

  function candidates(g) {
    if (g.distributing > 0) return [];
    var out = [];
    for (var i = 0; i < g.threats.length; i++) {
      var th = g.threats[i];
      if (!affordable(g, th).ok) continue;                       // grey slips cannot be locked
      if (g.entry && target(th).indexOf(g.entry) !== 0) continue;
      if (g.lock && th.id !== g.lock) continue;
      out.push(th);
    }
    return out;
  }

  /** One typed letter. Returns 'set' | 'progress' | 'miss'. */
  function type(g, ch) {
    if (g.phase !== 'setting' || g.distributing > 0) return 'miss';
    ch = String(ch).toLowerCase();
    if (!/^[a-z]$/.test(ch)) return 'miss';
    var want = g.entry + ch;
    var hits = [];
    for (var i = 0; i < g.threats.length; i++) {
      var th = g.threats[i];
      if (g.lock && th.id !== g.lock) continue;
      if (!affordable(g, th).ok) continue;
      if (target(th).indexOf(want) === 0) hits.push(th);
    }
    if (hits.length === 0) {
      /* ⛔ A MISTAKE PUTS METAL ON THE FLOOR. This is the line that makes accuracy part of the
         economy instead of part of the score. */
      g.mistakes++;
      g.cleanRun = false;
      g.pied += CASE.pie(g.cs, ch, 1);
      g.entry = '';
      g.lock = 0;
      g.flash = { kind: 'miss', ch: ch, t: g.t };
      return 'miss';
    }
    g.entry = want;
    /* lock onto the nearest matching slip so a shared prefix does not wander */
    var best = hits[0];
    for (var j = 1; j < hits.length; j++) if (hits[j].x < best.x) best = hits[j];
    g.lock = best.id;

    var done = null;
    for (var m = 0; m < hits.length; m++) if (target(hits[m]) === want) { done = hits[m]; break; }
    if (!done) return 'progress';

    complete(g, done);
    return 'set';
  }

  function complete(g, th) {
    spend(g, th);
    var word = target(th);
    var K = KINDS[th.kind];
    g.setCount++;

    /* impressions: length, plus a premium for the sorts nobody has many of */
    var need = costFor(g, th), rare = 0, rarest = null, rarestScore = -1;
    for (var k in need) {
      if (!Object.prototype.hasOwnProperty.call(need, k)) continue;
      var depth = g.cs.lay[k] || 1;
      var sc = 12 / depth;
      rare += sc * need[k];
      if (sc > rarestScore) { rarestScore = sc; rarest = k; }
    }
    var gain = Math.round((word.length + rare) * K.score);
    if (g.foundry.owned.redink && g.setCount % 4 === 0) gain *= 2;
    g.impressions += gain;
    g.lines.push({ word: word, kind: th.kind, gain: gain, doubled: !!(g.foundry.owned.redink && g.setCount % 4 === 0) });

    /* HARD METAL: a clean line gives its rarest sort straight back to the case. */
    if (g.foundry.owned.alloy && g.cleanRun && rarest && rarest.length === 1) {
      g.cs.sorts[rarest] = (g.cs.sorts[rarest] || 0) + 1;
    }
    /* THE IMPOSING STONE: every second line lifts one sort out of the hell box. */
    if (g.foundry.owned.imposing && g.setCount % 2 === 0) {
      for (var h in g.cs.hell) {
        if (!Object.prototype.hasOwnProperty.call(g.cs.hell, h) || g.cs.hell[h] <= 0) continue;
        g.cs.hell[h]--; g.cs.sorts[h] = (g.cs.sorts[h] || 0) + 1; break;
      }
    }

    g.entry = '';
    g.lock = 0;
    g.cleanRun = true;
    g.flash = { kind: 'set', word: word, gain: gain, t: g.t };

    th.step++;
    if (th.step >= th.words.length) {
      g.threats.splice(g.threats.indexOf(th), 1);
    }
  }

  function beginDistribution(g) {
    if (g.phase !== 'setting' || g.distributing > 0) return false;
    if (g.cs.inForme.length === 0) { g.flash = { kind: 'nothing', t: g.t }; return false; }
    g.distributing = g.distributeTime;
    g.entry = '';
    g.lock = 0;
    return true;
  }

  /* ------------------------------------------------------------------ frame */

  /**
   * ⛔ THE DEAD END, STATED PRECISELY. "Out of sorts" is not "the case looks empty" — it is:
   * nothing on the board can be set, AND breaking the forme up would not change that. The second
   * half is checked by SIMULATING the distribution rather than guessing, because a player told
   * they are dead while one keystroke would have saved them is a player who is right to be angry.
   */
  function deadEnd(g) {
    if (g.threats.length === 0) return false;
    for (var i = 0; i < g.threats.length; i++) if (affordable(g, g.threats[i]).ok) return false;
    if (g.distributing > 0) return false;
    /* what would the drawer look like after a distribution? */
    var after = {};
    for (var k in g.cs.lay) {
      if (!Object.prototype.hasOwnProperty.call(g.cs.lay, k)) continue;
      after[k] = Math.max(0, g.cs.lay[k] - (g.cs.hell[k] || 0));
    }
    for (var j = 0; j < g.threats.length; j++) {
      var need = costFor(g, g.threats[j]), ok = true;
      for (var n in need) {
        if (!Object.prototype.hasOwnProperty.call(need, n)) continue;
        if ((after[n] || 0) < need[n]) { ok = false; break; }
      }
      if (ok) return false;
    }
    return true;
  }

  /**
   * ⛔ NOTHING OVERTAKES INSIDE A LANE. Spacing them at SPAWN was not enough and the assertion said
   * so: a fast orphan behind a slow monk simply catches it up and walks through it, and their two
   * paper slips then overprint into a jumble — in a game where you type what you READ, that is an
   * unplayable board, not a cosmetic blemish. So the galley is a QUEUE: a slug that catches the one
   * in front of it slows to its pace and sits behind it.
   *
   * ⭐ And it is better DESIGN than the bug it fixes, which is why it went in the sim rather than
   * the renderer: a slow, expensive monk now physically holds up the fast things behind it, so
   * "leave the monk for later" has a consequence you can see coming down the track.
   *
   * MIN_GAP is derived from the widest slip the renderer can draw, not chosen: the longest word in
   * the pool at the slip's scale, plus its border and its offset from the slug.
   */
  var MIN_GAP = 178;

  function queueLanes(g) {
    var lanes = {};
    for (var i = 0; i < g.threats.length; i++) {
      var t = g.threats[i];
      (lanes[t.lane] = lanes[t.lane] || []).push(t);
    }
    for (var L in lanes) {
      if (!Object.prototype.hasOwnProperty.call(lanes, L)) continue;
      var row = lanes[L].sort(function (a, b) { return a.x - b.x; });
      for (var j = 1; j < row.length; j++) {
        if (row[j].x < row[j - 1].x + MIN_GAP) row[j].x = row[j - 1].x + MIN_GAP;
      }
    }
  }

  function step(g, dt) {
    if (g.phase !== 'setting') return g;
    if (dt > 0.25) dt = 0.25;                     // a backgrounded tab must not teleport the wave
    g.t += dt;

    if (g.distributing > 0) {
      g.distributing -= dt;
      if (g.distributing <= 0) {
        g.distributing = 0;
        var r = CASE.distribute(g.cs);
        g.flash = { kind: 'distributed', n: r.returned, t: g.t };
      }
    }

    if (g.spawned < g.toSpawn) {
      g.spawnIn -= dt;
      if (g.spawnIn <= 0) { spawn(g); g.spawnIn = g.rate * (0.75 + g.rand() * 0.5); }
    }

    for (var i = g.threats.length - 1; i >= 0; i--) {
      g.threats[i].x -= g.threats[i].speed * dt;
    }
    queueLanes(g);
    for (var i = g.threats.length - 1; i >= 0; i--) {
      var th = g.threats[i];
      if (th.x <= TRACK.stick) {
        arrive(g, th);
        g.threats.splice(i, 1);
        if (g.lock === th.id) { g.lock = 0; g.entry = ''; }
      }
    }

    if (g.spoils >= g.maxSpoils) { g.phase = 'lost'; g.deadReason = 'spoiled'; return g; }
    if (deadEnd(g)) { g.phase = 'lost'; g.deadReason = 'outofsorts'; return g; }
    if (g.spawned >= g.toSpawn && g.threats.length === 0) { g.phase = 'won'; }
    return g;
  }

  function arrive(g, th) {
    var K = KINDS[th.kind];
    if (K.pies) {
      /* A DEVIL DOES NOT SPOIL THE SHEET, IT ROBS THE CASE — and it steals from the deepest bin
         it can find, because a devil is not stupid. */
      var order = Object.keys(g.cs.sorts).sort(function (a, b) { return (g.cs.sorts[b] || 0) - (g.cs.sorts[a] || 0); });
      var left = K.pies;
      for (var i = 0; i < order.length && left > 0; i++) left -= CASE.pie(g.cs, order[i], Math.min(left, 2));
      g.pied += K.pies - left;
      g.flash = { kind: 'robbed', n: K.pies - left, t: g.t };
    } else {
      g.spoils++;
      g.flash = { kind: 'spoiled', word: target(th), t: g.t };
    }
  }

  /* ----------------------------------------------------------- the foundry */

  /** What the foundry offers RIGHT NOW. Casting offers follow what you actually ran out of. */
  function offers(g_or_foundry, spentTally) {
    var f = g_or_foundry.foundry || g_or_foundry;
    var out = [];
    var spent = spentTally || {};
    var letters = Object.keys(CASE.STANDARD_LAY).sort(function (a, b) {
      var da = (spent[a] || 0) / (CASE.STANDARD_LAY[a] + (f.cast[a] || 0) + f.deeper);
      var db = (spent[b] || 0) / (CASE.STANDARD_LAY[b] + (f.cast[b] || 0) + f.deeper);
      return db - da;
    });
    for (var i = 0; i < 3; i++) {
      var l = letters[i];
      var have = CASE.STANDARD_LAY[l] + (f.cast[l] || 0) + f.deeper;
      out.push({
        id: 'cast:' + l, kind: 'cast', letter: l,
        name: 'CAST TWO MORE ' + l.toUpperCase(),
        desc: 'The bin holds ' + have + '. You spent ' + (spent[l] || 0) + ' of them tonight.',
        cost: 12 + have * 2
      });
    }
    for (var j = 0; j < LIGATURES.length; j++) {
      var g2 = LIGATURES[j];
      if (f.ligatures.indexOf(g2) >= 0) continue;
      out.push({
        id: 'lig:' + g2, kind: 'lig', lig: g2,
        name: 'A ' + g2.toUpperCase() + ' LIGATURE',
        desc: 'One sort that prints "' + g2 + '". Spends no separate ' + g2.split('').join(' or ') + '.',
        cost: 18 + g2.length * 8
      });
      break;                                       // one ligature on offer at a time, in order
    }
    for (var key in UPGRADES) {
      if (!Object.prototype.hasOwnProperty.call(UPGRADES, key)) continue;
      var u = UPGRADES[key];
      if (f.owned[key] && !u.repeat) continue;
      out.push({
        id: 'up:' + key, kind: 'up', up: key,
        name: u.name + (u.repeat && f.deeper ? ' (x' + (f.deeper + 1) + ')' : ''),
        desc: u.desc,
        cost: u.repeat ? u.cost + f.deeper * 22 : u.cost
      });
    }
    return out;
  }

  function buy(foundry, offer) {
    if (foundry.banked < offer.cost) return false;
    foundry.banked -= offer.cost;
    if (offer.kind === 'cast') foundry.cast[offer.letter] = (foundry.cast[offer.letter] || 0) + 2;
    else if (offer.kind === 'lig') foundry.ligatures.push(offer.lig);
    else if (offer.up === 'deeper') { foundry.deeper++; foundry.owned.deeper = true; }
    else foundry.owned[offer.up] = true;
    return true;
  }

  var API = {
    TRACK: TRACK, LANES: LANES, KINDS: KINDS, FORMES: FORMES, UPGRADES: UPGRADES, LIGATURES: LIGATURES,
    newFoundry: newFoundry, caseFor: caseFor, startForme: startForme, step: step, type: type,
    beginDistribution: beginDistribution, affordable: affordable, costFor: costFor, candidates: candidates,
    deadEnd: deadEnd, offers: offers, buy: buy, target: target, rng: rng
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  else root.SIM = API;
})(typeof window !== 'undefined' ? window : globalThis);
