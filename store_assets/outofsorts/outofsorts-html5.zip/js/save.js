/* OUT OF SORTS — save.js
 *
 * The standing design rule for this whole track (ledger B4): DEATH RETURNS THE PLAYER TO A
 * MEANINGFUL CHECKPOINT WITH PROGRESS KEPT, never to a full restart. Here that is two separate
 * things, and keeping them separate is the whole rule:
 *
 *   THE FOUNDRY survives everything. Sorts you have cast stay cast, ligatures stay bought, the
 *   book remembers how far you got. Losing a forme costs the forme.
 *   THE FORME is a snapshot of the round in progress, so closing the tab mid-sentence costs
 *   nothing either. It is deleted the moment the round ends, in either direction.
 *
 * ⚠️ NOTHING DERIVED IS STORED. The pool, the offers, the case's `spent` tally and the threat
 *    positions after a reload are all recomputed. Storing a derived value that can go stale is
 *    the defect master §2b records six times over.
 */
'use strict';

var OOS_SAVE = (function () {
  var KEY = 'outofsorts.v1';

  function read() {
    try {
      var raw = localStorage.getItem(KEY);
      if (!raw) return null;
      var j = JSON.parse(raw);
      return (j && typeof j === 'object') ? j : null;
    } catch (e) { return null; }
  }
  function write(obj) {
    try { localStorage.setItem(KEY, JSON.stringify(obj)); return true; } catch (e) { return false; }
  }

  function loadFoundry() {
    var j = read();
    if (!j || !j.foundry) return null;
    var f = j.foundry;
    /* defend against a hand-edited or half-written record: a missing field must not crash the
       shop, it must fall back to a stock one */
    return {
      cast: f.cast && typeof f.cast === 'object' ? f.cast : {},
      ligatures: Array.isArray(f.ligatures) ? f.ligatures : [],
      owned: f.owned && typeof f.owned === 'object' ? f.owned : {},
      deeper: f.deeper | 0,
      banked: f.banked | 0,
      formeReached: f.formeReached | 0,
      formesWon: f.formesWon | 0
    };
  }
  function saveFoundry(f) {
    var j = read() || {};
    j.foundry = {
      cast: f.cast, ligatures: f.ligatures, owned: f.owned, deeper: f.deeper,
      banked: f.banked, formeReached: f.formeReached, formesWon: f.formesWon
    };
    return write(j);
  }

  function saveForme(g) {
    var j = read() || {};
    j.forme = {
      index: g.index, seed: g.seed,
      sorts: g.cs.sorts, hell: g.cs.hell, inForme: g.cs.inForme, spent: g.cs.spent,
      threats: g.threats.map(function (t) {
        return { id: t.id, kind: t.kind, lane: t.lane, x: t.x, words: t.words, step: t.step, speed: t.speed, seed: t.seed };
      }),
      nextId: g.nextId, spawned: g.spawned, spawnIn: g.spawnIn, spoils: g.spoils,
      impressions: g.impressions, lines: g.lines, setCount: g.setCount,
      mistakes: g.mistakes, pied: g.pied, t: g.t
    };
    return write(j);
  }
  function loadForme() { var j = read(); return (j && j.forme) ? j.forme : null; }
  function clearForme() { var j = read() || {}; delete j.forme; return write(j); }
  function wipeAll() { try { localStorage.removeItem(KEY); return true; } catch (e) { return false; } }

  return {
    loadFoundry: loadFoundry, saveFoundry: saveFoundry,
    saveForme: saveForme, loadForme: loadForme, clearForme: clearForme,
    wipeAll: wipeAll, KEY: KEY
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = OOS_SAVE;
