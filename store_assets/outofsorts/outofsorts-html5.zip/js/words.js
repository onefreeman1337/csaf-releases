/* OUT OF SORTS — words.js : the copy the shop is asked to set.
 *
 * ⛔ EVERY WORD BELOW WAS HAND-CHOSEN FOR THIS GAME. No word list was downloaded, scraped or
 *    lifted. That is not fussiness: a word list is a compilation and its SELECTION is the part
 *    somebody owns, so the same reasoning that bars us from shipping an engine's runtime
 *    (master §8.5) bars us from shipping somebody's dictionary. The individual words are English
 *    and belong to nobody; this arrangement of them is ours.
 *
 * ⭐ THE SELECTION IS ALSO A GAME MECHANIC, WHICH IS WHY A GENERIC LIST WOULD NOT DO. The whole
 *    game is that the alphabet is finite, so what matters about a word is not that it exists but
 *    WHAT IT COSTS: how many E it eats, whether it is the only place a Q can go, whether two of
 *    them in a row leave you unable to set a third. Words are therefore banded by length and
 *    sorted into families the round can draw from deliberately:
 *
 *      VOWEL-HEAVY  eat the common bins and are cheap to type — they are the trap.
 *      CONSONANT    spare the vowels and are the way out of a drained case.
 *      RARE         carry j q x z v k and are worth the most in impressions.
 *      TRADE        the shop's own vocabulary. A game about letterpress should ask you to set
 *                   QUOIN and GALLEY and HELLBOX, and every one of these is a real printing term.
 */
(function (root) {
  'use strict';

  var S = function (s) { return s.split(/\s+/).filter(Boolean); };

  /* ---- band 1: 3 to 4 sorts. The change in your pocket. ------------------ */
  var B1 = S(`
    ash bed bid bit cap cog cut dab dim dot dry ear eve fed fig fit fog gap gum gut hem hew hid
    hue hum ink jab jar jot key kin lap led lid lip lot mad map mat nib nip nod oak oil pad pan
    pen pin pit ply pot rag ram raw rib rim rip rod rub rug run sap saw set sew sit ski sly sum
    tab tap tar tin tip tow tub tug urn vat vex vow wad wax web wed wet wig wit yew zip
    acid ache aged ajar bail bark bend bind bolt bone book brim cage calm cart chip clip coal
    coil cold comb cord cove crop damp dark dial dine dive dose down drag drum dusk edge fade
    fair fern file firm flax flee foam fold fork frost gale gaze gild glow gnaw grid grim hail
    half hark haul heat hive hold honk horn husk idle iron jade jolt keel kiln knot lace lamp
    lath leaf lens limb lime loom lure mash mend mild mine mist moss moth nail neat nest node
    numb oath oust oven pace pale peat pile pine plot pond pore pull pyre quay raft rake rasp
    reed rein rest rift roam rope rust sage salt sand seam shed silk sink slab slot snow soak
    soot spar spin stab stem stir sway tale tame teal tide tile tone trim tusk vane vast veil
    vine void wane warp wave weld wick wild wind wing wolf wood wren yarn yolk zeal zinc
  `);

  /* ---- band 2: 5 to 6 sorts. A working line. ----------------------------- */
  var B2 = S(`
    amber anvil ashen aside baste beast birch blade blaze bleak blend bloom blunt brace braid
    brass bream briar brick brine broth cabin candle carve chalk charm chase chill chime cinder
    clasp cleft climb cloak coast crane crate creak crest crown crust cubit curve damson dapple
    delve depth ditch dodge drift drown dwell ember empty enact ether fable facet fetch field
    flint flock flood flour flume forge frame frost gable gauge ghost glade glaze gleam glide
    gloom grain grasp grave graze grime grove gruff guild gully harsh haven heath hedge hinge
    hoard hound humid inlet ivory jetty joist kernel kettle knead kneel label ladle lance larch
    latch ledge lever light linen loath lodge lunar lurch madder marsh medal melon merit mirth
    moult mould mount mourn nadir nectar niche noble notch novel oaken ochre onset orbit order
    otter ounce paint parch parlour pearl pedal perch pilot pinch pitch plaid plait plane plank
    pleat plumb porch pouch prime privet prong proof prowl purge quail quart quell quilt quire
    quoin raven realm reign resin ridge rinse rival roast rouse rowan rubble rustic saddle satin
    scald scale scarf scent scrap scrub sedge seize shale shard shawl shear shelf shine shore
    shrub siege silver siren slate sleet slide slope smelt smoke snare solid solve spade spark
    spear spice spine spire spite spool spray spurn stack staff stain stalk stamp stand steam
    steel stern stick stoke stone stork storm stove strap straw strew strip stump surge swamp
    swarm swell swift table talon tally tamper tarry tempo tenon thorn thread thrive throng
    thumb tidal timber tinder toast token tonic torch trace track trade trail trawl tread trice
    trout truce trunk tulip tumble tunic twine ulcer umber uncle unfit unlit unrig urban usage
    valve vapour vault velvet venom verge verse vigil vinyl vixen vocal wafer wager wagon wharf
    wheat wheel whelk whisk widow wince winch wispy witch woven wreck wrist yield zenith
  `);

  /* ---- band 3: 7 to 8 sorts. This is where the case starts to hurt. ------ */
  var B3 = S(`
    acetate acrobat admiral aground alkaline almanac amethyst anchored antimony aperture apricot
    arbitrate archives armature ashtrees assemble astonish attended awkward bailiff balanced
    ballast bandage banister barnacle basalt beckon bedrock beeswax bewitch billhook blanket
    blister bluebell bombard bracken brambles brawling brazier breadth brigade brimstone bristle
    brocade buckwheat buttress cabinet calamine calfskin campfire canvassed capstan caravan
    cardinal carnival cartouche cascade catchword cavalier ceiling cellars chamber chandler
    chapters charcoal chariot chestnut chimney cinnamon cistern clanking clatter clemency clinker
    coalpit cobbler cochineal collated colophon compass conduit cornice cottage courtyard cowslip
    crackle cranberry credible crevice crimson crossbar crucible cupboard curator cutwater
    daffodil damaged dampener darkened daybreak deadline decanted deckled defiant delayed
    dentist derelict dewdrop diagram diamond dilated dispatch distaff dogwood doldrums doorway
    doubled dovecote drapery drawing driftwood drought drummer duckweed dustpan earthen eastward
    eclipse elderly elegant elmwood embargo embosser emerald enamel enclave endless engrave
    entwine envelope epigram epitaph errands escaped estuary evening exactly exhaust exposed
    eyebolt fairway falcons fanlight farrier fathoms feathers ferment fiddler filbert firebox
    firmly fitting flagpole flanked flatbed flaxen fleeting flitting flotsam flutter foghorn
    foliage footman foreman forsook founder foxglove fracture fragment frankly freckled friction
    frontage frowned furlong furnace gadfly gallant gambling gangway gantry garland garnish
    gasping gateway gathered gauntlet gearbox gestures gimbals glimmer glisten glorious glowing
    goldleaf gondola goodwill goshawk gossamer granite grapnel gravity greeting griffin grinding
    gristle grommet grumble gunwale gutters hairline halyard hammered handcart hanging harbour
    harness harvest hatchet haulage hawthorn haywire hazards headland hearing heather hemlock
    heraldry herring hillside hinterland hoarding hobbled hogshead holdfast homeward honeybee
    hornbeam horsemen hosiery hostler however howling humbled hundred hurdles husband hydrant
    icebound imagine impress inboard incense inflame ingrain inkhorn inkling inkwell inshore
    instant iodine ironwork isolate jackdaw jangling jasmine javelin jawbone jetsam jettison
    jointer journal jubilee juniper justice kestrel keyhole kindled kingdom kitchen knapsack
    knobbled knuckle labelled lacquer ladders lampoon landfall lantern lapwing larkspur lattice
    laundry lawsuit leaflet leaning leather lectern leftward legible leopard leverage lifeboat
    limestone linings linseed lodging longboat lookout loosely lozenge lumbered luminous lynchpin
  `);

  /* ---- band 4: 9 sorts and up. One of these can empty a bin on its own. -- */
  var B4 = S(`
    apothecary arrowheads bellringer bindweed blackberry blacksmith blockhouse bluebottle
    boilerplate bookbinder bottomland breadboard breakwater brickworks brightness broadsheet
    candlewick carpenters cartwright chandelier chimneypot clapboard clockmaker coachhouse
    coalscuttle cobblestone coldwelded collarbone commonplace copperplate cornerstone
    cottonwood countryside craftsmanship crossbeams cuttlefish daybreaking deadweight
    dovetailed downstream draughtsman dressmaker driftwoods drypointing earthenware embroidery
    engravings escapement everlasting eyewitness featherbed fieldstone fingerpost fireplace
    fishermans flagstones floorboard flourishes flywheeled foreshadow forgemaster fortnight
    freightage frostbitten furnishings gatehouse gemstone glassblower goldbeater grasshopper
    greenhouse grindstone gunpowder hammerhead handiwork handwriting harbourside harvestman
    headwaters hearthstone hedgerows herringbone hobnailed horseshoes hourglass ironmonger
    jackhammer journeyman keelhauled kettledrum kingfisher lamplighter lampblack lanternlight
    latticework leatherwork letterpress lighthouse limekilns linotypist lockkeeper longshore
    machinists marbleised masonwork masterwork meadowlark millstone moorlands mortarboard
    nightshade northerly notebooks obligation ochreous offcutting outstretch overprinted
    paperweight parchments patternbook pewterware pinewoods plasterwork ploughshare printworks
    quicksilver quillwork rainwater ratcheting reservoir ribbonwork rivetted rooflines
    ropewalker sailcloth sandstone scaffolds scrapbook shipwright shopkeeper shorthand
    silverware slateroof smithcraft snowmelt springtide stationers steelworks stonemason
    storehouse strongbox sunlighted tablecloth tallowlamp thumbprint timberyard tinderbox
    toolmaker townhouse tradesman treadmill turnbuckle typefounder underscore upholstery
    varnishing wainscot warehouse watercourse watermark waterwheel weathercock wheelwright
    whetstone windowpane winterbourne woodcutter woolgather workbenches wrightwork
  `);

  /* ---- the trade. The shop's own words, and the reason the theme sings. --- */
  var TRADE = S(`
    sort case lay nick quad em en pica point body slug forme chase quoin galley stick composing
    justify leading ligature kern serif matrix punch mould foundry cast dress dissing pied
    hellbox furniture reglet coffin tympan frisket platen roller ink beater devil monk friar
    widow orphan recto verso folio quire ream octavo duodecimo colophon imprint impose signature
    catchword bodkin makeready overlay underlay pull proof revise gutter margin bleed register
  `);

  /* Vowel weight is what decides whether a word drains the common bins or the rare ones, so it
     is MEASURED per word rather than guessed, and the round asks for a shape, not a word. */
  function vowelRatio(w) {
    var v = 0;
    for (var i = 0; i < w.length; i++) if ('aeiou'.indexOf(w[i]) >= 0) v++;
    return v / w.length;
  }
  var RARE = 'jqxzvkwy';
  function rarity(w) {
    var r = 0;
    for (var i = 0; i < w.length; i++) { var p = RARE.indexOf(w[i]); if (p >= 0) r += (8 - p); }
    return r;
  }

  var ALL = [];
  function add(list, band) {
    for (var i = 0; i < list.length; i++) {
      var w = String(list[i]).toLowerCase().replace(/[^a-z]/g, '');
      if (w.length < 2) continue;
      ALL.push({ w: w, band: band, v: vowelRatio(w), r: rarity(w), trade: band === 0 });
    }
  }
  add(TRADE, 0); add(B1, 1); add(B2, 2); add(B3, 3); add(B4, 4);

  /* de-duplicate: a word that appears in the trade list and a band list is ONE sort of word */
  var seen = {}, WORDS = [];
  for (var i = 0; i < ALL.length; i++) {
    if (seen[ALL[i].w]) continue;
    seen[ALL[i].w] = 1;
    WORDS.push(ALL[i]);
  }

  function byBand(b) { return WORDS.filter(function (e) { return e.band === b; }); }

  var API = {
    WORDS: WORDS,
    byBand: byBand,
    count: WORDS.length,
    vowelRatio: vowelRatio,
    rarity: rarity,
    bands: [0, 1, 2, 3, 4].map(function (b) { return byBand(b).length; })
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  else root.WORDS = API;
})(typeof window !== 'undefined' ? window : globalThis);
