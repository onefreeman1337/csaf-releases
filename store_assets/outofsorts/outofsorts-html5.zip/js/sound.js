/* OUT OF SORTS — sound.js
 *
 * ⭐ THE SHOP MAKES THE MUSIC. Every sound in this game is a thing happening to metal: a sort
 *    lifted out of the case, a line locked up, a piece dropped on the floor, the platen coming
 *    down. Typing therefore has a RHYTHM, and a good run sounds like a compositor working.
 *
 * ⚠️ POLYPHONY IS CAPPED. Fast typing is many voices per second and an uncapped mixer turns a
 *    good run into a wall of noise — and an expensive one. The cap keeps the newest voices; a
 *    click that would be the Nth voice is simply not played, because the visual is the truth and
 *    the audio is the flavour.
 */
'use strict';

var OOS_SOUND = (function () {

  var ctx = null, master = null, musicGain = null, sfxGain = null;
  var buffers = {};
  var ready = false, enabled = true, failed = false;
  var live = [];
  var MAX_VOICES = 6;
  var musicNode = null;

  var FILES = ['sfx_lift', 'sfx_set', 'sfx_miss', 'sfx_diss', 'sfx_spoil',
    'sfx_rob', 'sfx_press', 'sfx_cast', 'sfx_deny', 'shop_theme'];

  function init() {
    if (ctx || failed) return;
    try {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) { failed = true; return; }
      ctx = new AC();
      master = ctx.createGain(); master.gain.value = 0.85; master.connect(ctx.destination);
      musicGain = ctx.createGain(); musicGain.gain.value = 0.42; musicGain.connect(master);
      sfxGain = ctx.createGain(); sfxGain.gain.value = 0.9; sfxGain.connect(master);
      var got = 0;
      FILES.forEach(function (n) {
        fetch('audio/' + n + '.ogg')
          .then(function (r) { return r.arrayBuffer(); })
          .then(function (ab) { return ctx.decodeAudioData(ab); })
          .then(function (buf) { buffers[n] = buf; got++; if (got >= FILES.length - 1) ready = true; })
          .catch(function () { got++; if (got >= FILES.length - 1) ready = true; });
      });
    } catch (e) { failed = true; }
  }

  /* Browsers refuse audio until a gesture. Called from the first key or click. */
  function unlock() {
    init();
    if (ctx && ctx.state === 'suspended') ctx.resume();
  }

  function play(name, gain, rate) {
    if (!enabled || !ctx || !buffers[name]) return;
    var now = ctx.currentTime;
    live = live.filter(function (v) { return v.until > now; });
    if (live.length >= MAX_VOICES) return;
    try {
      var src = ctx.createBufferSource();
      src.buffer = buffers[name];
      src.playbackRate.value = rate || 1;
      var g = ctx.createGain();
      g.gain.value = gain === undefined ? 1 : gain;
      src.connect(g); g.connect(sfxGain);
      src.start();
      live.push({ until: now + buffers[name].duration / (rate || 1) });
    } catch (e) { /* a dead context must never take the game down with it */ }
  }

  /* Each sort is a slightly different piece of metal, so each click is pitched a little
     differently — deterministically, from the letter, so the same word always sounds the same. */
  function lift(ch) {
    var n = String(ch).charCodeAt(0) || 97;
    play('sfx_lift', 0.34, 0.90 + ((n * 37) % 23) / 100);
  }

  function startMusic() {
    if (!ctx || !buffers.shop_theme || musicNode) return;
    try {
      musicNode = ctx.createBufferSource();
      musicNode.buffer = buffers.shop_theme;
      musicNode.loop = true;
      musicNode.connect(musicGain);
      musicNode.start();
    } catch (e) { musicNode = null; }
  }
  function stopMusic() { if (musicNode) { try { musicNode.stop(); } catch (e) {} musicNode = null; } }

  function setEnabled(on) {
    enabled = !!on;
    if (master) master.gain.value = enabled ? 0.85 : 0;
    if (enabled) startMusic();
  }

  return {
    init: init, unlock: unlock, play: play, lift: lift,
    startMusic: startMusic, stopMusic: stopMusic, setEnabled: setEnabled,
    isEnabled: function () { return enabled; },
    isReady: function () { return ready; },
    loadedCount: function () { return Object.keys(buffers).length; }
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = OOS_SOUND;
