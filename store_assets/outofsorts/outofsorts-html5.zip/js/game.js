/* OUT OF SORTS — game.js : the shop, drawn, and the hands on the keyboard.
 *
 * This file owns exactly three things: the frame loop, the input, and the picture. Every rule
 * lives in sim.js and case.js and is only READ from here — so a rendering change can never alter
 * what the game does, and the suites that prove the rules do not need a browser.
 *
 * ⛔ THE INTERFACE IS THE SHOP'S OWN FURNITURE. There is no HUD floating over a scene: the header
 *    is the press bed, the panels are oak and brass, the score is a stack of printed sheets, and
 *    every word anywhere on screen is composed sort by sort out of the generated sheets. The one
 *    exception is small numerals and labels, which use a system serif because a 9px bitmap face
 *    is unreadable and unreadable is not a style.
 */
'use strict';

(function () {

  var W = 960, H = 540;
  var LAY = {
    header: { y: 0, h: 38 },
    galley: { y: 38, h: 248, lanes: 4 },
    stick: { y: 286, h: 58 },
    caseBox: { x: 0, y: 344, w: 700, h: 196 },
    page: { x: 700, y: 344, w: 260, h: 196 }
  };

  var cv = document.getElementById('cv');
  var ctx = cv.getContext('2d', { alpha: false });
  var A = OOS_ART, S = SIM, C = CASE, SV = OOS_SAVE, SND = OOS_SOUND;

  var foundry = SV.loadFoundry() || S.newFoundry();
  var g = null;                    // the live forme, or null
  var screen = 'title';
  var last = 0;
  var shakeUntil = 0, shakeMag = 0;
  var motes = [];                  // dropped sorts, purely decorative
  var ready = false;

  /* ------------------------------------------------------------- the drawer
   * Three rows, alphabetical, and every box is as WIDE as its bin is DEEP — which is how a real
   * case is laid out and also the single most useful thing the screen can tell you at a glance.
   */
  var ROWS = [
    'abcdefghi'.split(''),
    'jklmnopqr'.split(''),
    'stuvwxyz'.split('').concat(['hell'])
  ];
  var boxes = null;

  function layoutCase() {
    var cb = LAY.caseBox;
    var pad = 8, gap = 4;
    var out = [];
    var rowH = Math.floor((cb.h - pad * 2 - gap * 2) / 3);
    for (var r = 0; r < ROWS.length; r++) {
      var row = ROWS[r];
      var usable = cb.w - pad * 2 - gap * (row.length - 1);
      var minW = 40;
      var depths = row.map(function (k) { return k === 'hell' ? 6 : (g ? g.cs.lay[k] || 1 : C.STANDARD_LAY[k] || 1); });
      var total = depths.reduce(function (a, b) { return a + b; }, 0);
      var extra = usable - minW * row.length;
      var x = cb.x + pad;
      for (var i = 0; i < row.length; i++) {
        var w = Math.floor(minW + extra * (depths[i] / total));
        out.push({ k: row[i], x: x, y: cb.y + pad + r * (rowH + gap), w: w, h: rowH });
        x += w + gap;
      }
    }
    boxes = out;
  }

  /* ------------------------------------------------------------------ frame */

  function frame(now) {
    requestAnimationFrame(frame);
    if (!last) last = now;
    var dt = Math.min(0.25, (now - last) / 1000);
    last = now;

    if (!ready) { ready = A.assetsLoaded(); }

    if (screen === 'play' && g && g.phase === 'setting') {
      S.step(g, dt);
      stepMotes(dt);
      if (g.phase === 'won') finishForme(true);
      else if (g.phase === 'lost') finishForme(false);
    } else if (g) {
      stepMotes(dt);
    }
    draw();
  }

  function stepMotes(dt) {
    for (var i = motes.length - 1; i >= 0; i--) {
      var m = motes[i];
      m.vy += 900 * dt; m.x += m.vx * dt; m.y += m.vy * dt; m.rot += m.spin * dt; m.life -= dt;
      if (m.life <= 0 || m.y > H + 40) motes.splice(i, 1);
    }
  }
  function dropSorts(ch, n, x, y) {
    for (var i = 0; i < n; i++) {
      motes.push({ ch: ch, x: x, y: y, vx: (Math.random() - 0.5) * 220, vy: -180 - Math.random() * 120,
        rot: 0, spin: (Math.random() - 0.5) * 9, life: 1.6 });
    }
  }

  /* ------------------------------------------------------------------- draw */

  function draw() {
    ctx.save();
    if (performance.now() < shakeUntil) {
      ctx.translate((Math.random() - 0.5) * shakeMag, (Math.random() - 0.5) * shakeMag);
    }
    A.fillPlate(ctx, 'plate_felt', -6, -6, W + 12, H + 12);

    if (!g) { drawIdleBoard(); ctx.restore(); return; }

    drawGalley();
    drawStickBand();
    drawCase();
    drawPage();
    drawHeader();
    drawMotes();
    ctx.restore();
  }

  function drawIdleBoard() {
    A.fillPlate(ctx, 'plate_iron', 0, 0, W, LAY.stick.y);
    A.fillPlate(ctx, 'plate_oak', LAY.caseBox.x, LAY.caseBox.y, LAY.caseBox.w, LAY.caseBox.h);
    A.fillPlate(ctx, 'plate_paper', LAY.page.x, LAY.page.y, LAY.page.w, LAY.page.h);
    A.rule(ctx, 0, LAY.stick.y - 3, W);
  }

  /* -------------------------------------------------------------- the header */
  function drawHeader() {
    var h = LAY.header;
    A.fillPlate(ctx, 'plate_iron', 0, h.y, W, h.h);
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fillRect(0, h.y, W, h.h);
    A.rule(ctx, 0, h.y + h.h - 3, W);

    A.text(ctx, g.title, 14, 25, { size: 17, fill: '#e6c274', weight: '600' });

    /* SHEETS SPOILED — drawn as sheets, because a number would be a HUD and this is a shop */
    var sx = 300;
    A.text(ctx, 'SPOILED', sx, 24, { size: 11, fill: '#8f8778' });
    for (var i = 0; i < g.maxSpoils; i++) {
      var x = sx + 56 + i * 13;
      ctx.fillStyle = i < g.spoils ? '#a02c22' : '#5f5d6e';
      ctx.fillRect(x, 12, 9, 13);
      ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.fillRect(x, 12, 9, 2);
    }

    /* THE HELL BOX — the number that decides whether you are actually in trouble */
    var hell = C.hellCount(g.cs);
    A.text(ctx, 'HELL BOX', 470, 24, { size: 11, fill: hell ? '#c9563a' : '#8f8778' });
    A.text(ctx, String(hell), 538, 25, { size: 15, fill: hell ? '#c9563a' : '#807d90', weight: '600' });

    A.text(ctx, 'IMPRESSIONS', 600, 24, { size: 11, fill: '#8f8778' });
    A.text(ctx, String(g.impressions + foundry.banked), 690, 25, { size: 15, fill: '#e6c274', weight: '600' });

    A.text(ctx, 'SPACE distributes  ·  ESC', W - 14, 24, { size: 11, fill: '#6f6a63', align: 'right' });
  }

  /* -------------------------------------------------------------- the galley */
  function drawGalley() {
    var gl = LAY.galley;
    A.fillPlate(ctx, 'plate_iron', 0, gl.y, W, gl.h);
    var laneH = gl.h / gl.lanes;
    ctx.strokeStyle = 'rgba(0,0,0,0.45)'; ctx.lineWidth = 1;
    for (var i = 1; i < gl.lanes; i++) {
      ctx.beginPath(); ctx.moveTo(0, gl.y + i * laneH + 0.5); ctx.lineTo(W, gl.y + i * laneH + 0.5); ctx.stroke();
    }

    /* THE CHASE — the left of the galley is not dead space, it is where the FORME piles up.
     * Every line you set is a real slug of metal standing in the chase, and distribution is
     * literally emptying it. Showing it here is what makes SPACE legible: the player can see the
     * thing they are about to break up, and how much metal is locked in it. */
    var sx = S.TRACK.stick;
    ctx.fillStyle = 'rgba(0,0,0,0.55)'; ctx.fillRect(0, gl.y, sx - 10, gl.h);
    A.text(ctx, 'THE FORME', 8, gl.y + 15, { size: 10, fill: '#6b6258' });
    var inF = g.cs.inForme.slice(-9);
    for (var q = 0; q < inF.length; q++) {
      var wy = gl.y + 34 + q * 23;
      ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.fillRect(6, wy - 15, sx - 22, 21);
      A.drawSorts(ctx, inF[q].slice(0, 12), 8, wy, { scale: 0.42, worn: true });
    }
    if (inF.length === 0) A.text(ctx, 'empty', 8, gl.y + 36, { size: 11, fill: '#3f3a44' });
    if (g.cs.inForme.length > 9) A.text(ctx, '+' + (g.cs.inForme.length - 9) + ' more', 8, gl.y + 34 + 9 * 23 + 4, { size: 10, fill: '#6b6258' });

    ctx.fillStyle = '#6b4a1c'; ctx.fillRect(sx - 10, gl.y, 10, gl.h);
    ctx.fillStyle = '#c69a45'; ctx.fillRect(sx - 10, gl.y, 2, gl.h);
    ctx.fillStyle = '#3d2a10'; ctx.fillRect(sx - 2, gl.y, 2, gl.h);

    for (var t = 0; t < g.threats.length; t++) drawThreat(g.threats[t], laneH);

    if (g.distributing > 0) {
      ctx.fillStyle = 'rgba(10,8,8,0.62)';
      ctx.fillRect(0, gl.y, W, gl.h);
      var frac = 1 - g.distributing / g.distributeTime;
      A.text(ctx, 'DISTRIBUTING THE FORME', W / 2, gl.y + gl.h / 2 - 12, { size: 20, fill: '#e6c274', align: 'center' });
      A.text(ctx, 'every sort back in its box', W / 2, gl.y + gl.h / 2 + 10, { size: 13, fill: '#9a8f79', align: 'center' });
      ctx.fillStyle = '#3d2a10'; ctx.fillRect(W / 2 - 130, gl.y + gl.h / 2 + 28, 260, 6);
      ctx.fillStyle = '#c69a45'; ctx.fillRect(W / 2 - 130, gl.y + gl.h / 2 + 28, 260 * frac, 6);
    }
  }

  var KIND_TINT = { pie: null, orphan: null, monk: '#0a0808', devil: '#a02c22', quad: null };

  function drawThreat(th, laneH) {
    var gl = LAY.galley;
    var cy = gl.y + th.lane * laneH + laneH / 2;
    var word = S.target(th);
    var aff = S.affordable(g, th);
    var locked = g.lock === th.id;

    ctx.save();
    ctx.globalAlpha = aff.ok ? 1 : 0.5;

    /* THE SLUG — a heap of pied type. Every enemy in this game is made of the game's own art. */
    ctx.save();
    ctx.translate(th.x, cy);
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    ctx.beginPath(); ctx.ellipse(2, 22, 26, 6, 0, 0, Math.PI * 2); ctx.fill();
    if (th.kind === 'monk') {
      ctx.fillStyle = 'rgba(10,8,8,0.88)';
      ctx.beginPath(); ctx.ellipse(0, 4, 34, 24, 0, 0, Math.PI * 2); ctx.fill();
    }
    if (th.kind === 'quad') {
      ctx.fillStyle = '#3f3e4b'; ctx.fillRect(-21, -21, 42, 42);
      ctx.fillStyle = '#a09cb0'; ctx.fillRect(-21, -21, 42, 2); ctx.fillRect(-21, -21, 2, 42);
      ctx.fillStyle = '#171820'; ctx.fillRect(-21, 19, 42, 2); ctx.fillRect(19, -21, 2, 42);
      ctx.fillStyle = '#24242f'; ctx.fillRect(-15, 9, 30, 3);
      ctx.fillStyle = '#807d90'; ctx.fillRect(-15, 12, 30, 1);
    } else {
      var n = th.kind === 'orphan' ? 1 : (th.kind === 'devil' ? 2 : 4);
      for (var i = 0; i < n; i++) {
        var s = (th.seed + i * 71) % 997;
        ctx.save();
        ctx.translate(((s % 17) - 8) * 1.6, ((s >> 4) % 15 - 7) * 1.4);
        ctx.rotate((((s >> 8) % 21) - 10) * 0.07);
        A.drawSort(ctx, word[i % word.length], -11, -15, 0.64, true);
        ctx.restore();
      }
    }
    if (th.kind === 'devil') {
      ctx.fillStyle = '#c9563a';
      ctx.fillRect(-7, -3, 3, 3); ctx.fillRect(3, -3, 3, 3);
      ctx.fillStyle = '#6d1b18';
      ctx.fillRect(-12, -14, 3, 5); ctx.fillRect(9, -14, 3, 5);
    }
    ctx.restore();

    /* THE SLIP — the copy it is carrying, pulled on a scrap of paper */
    var wlen = A.measureInk(word, 0.5);
    var pw = wlen + 14, ph = 30;
    /* ⚠️ CLAMP THE SLIP INSIDE THE CANVAS. A slug spawning at the right edge pushed its slip — and
       the caption under it — off screen, so the one piece of information the player needs about a
       monk ("costs twice") was legible only after it had walked a third of the way in. */
    var px = Math.min(th.x + 30, W - pw - 8), py = cy - 15;
    ctx.save();
    ctx.beginPath(); ctx.rect(px, py, pw, ph); ctx.clip();
    A.fillPlate(ctx, 'plate_paper', px, py, pw, ph);
    ctx.restore();
    ctx.strokeStyle = locked ? '#e6c274' : 'rgba(0,0,0,0.4)';
    ctx.lineWidth = locked ? 2 : 1;
    ctx.strokeRect(px + 0.5, py + 0.5, pw - 1, ph - 1);

    if (locked && g.entry) {
      var tw = A.measureInk(g.entry, 0.5);
      ctx.fillStyle = 'rgba(198,154,69,0.55)';
      ctx.fillRect(px + 7, py + 4, tw, ph - 8);
    }
    A.drawInk(ctx, word, px + 7, py + 21, { scale: 0.5, starved: !aff.ok });

    /* ⚠️ THE CAPTION IS MEASURED AND CLAMPED, not placed at a fixed offset. "DOUBLE INKED — costs
       twice" is wider than the slip it hangs under, so a monk near the right edge lost the end of
       the one sentence that explains it. Canvas text does not wrap, does not reflow and does not
       clip — it just runs off, silently. */
    var cap = null, capFill = '#9a8f79', capSize = 10;
    if (!aff.ok) {
      var parts = [];
      for (var k in aff.short) if (Object.prototype.hasOwnProperty.call(aff.short, k)) parts.push(aff.short[k] + ' ' + k.toUpperCase());
      cap = parts.join(', ') + ' SHORT'; capFill = '#c9563a'; capSize = 11;
      ctx.globalAlpha = 1;
    } else if (th.kind === 'monk') cap = 'DOUBLE INKED — costs twice';
    else if (th.kind === 'devil') { cap = 'will rob the case'; capFill = '#c9563a'; }
    else if (th.kind === 'quad' && th.words.length > 1) cap = 'then: ' + th.words[1];
    if (cap) {
      ctx.font = capSize + 'px ' + A.FONT;
      var cw = ctx.measureText(cap).width;
      A.text(ctx, cap, Math.max(6, Math.min(px + 7, W - cw - 8)), py + ph + 13,
        { size: capSize, fill: capFill, weight: capSize > 10 ? '600' : undefined });
    }
    ctx.restore();
  }

  /* --------------------------------------------------------- the composing stick */
  function drawStickBand() {
    var b = LAY.stick;
    A.fillPlate(ctx, 'plate_felt', 0, b.y, W, b.h);
    ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.fillRect(0, b.y, W, b.h);
    /* the stick itself: a brass channel the line is set into */
    ctx.fillStyle = '#3d2a10'; ctx.fillRect(150, b.y + 6, W - 300, b.h - 12);
    ctx.fillStyle = '#6b4a1c'; ctx.fillRect(150, b.y + 6, W - 300, 3);
    ctx.fillStyle = '#9a6f2c'; ctx.fillRect(150, b.y + b.h - 9, W - 300, 3);
    A.rule(ctx, 0, b.y, W);

    var msg = null, msgCol = '#9a8f79';
    if (g.flash && g.t - g.flash.t < 1.5) {
      var f = g.flash;
      if (f.kind === 'miss') { msg = 'DROPPED A ' + String(f.ch).toUpperCase() + ' — it is in the hell box now'; msgCol = '#c9563a'; }
      else if (f.kind === 'spoiled') { msg = 'A SHEET SPOILED'; msgCol = '#c9563a'; }
      else if (f.kind === 'robbed') { msg = 'THE DEVIL TOOK ' + f.n + ' SORTS'; msgCol = '#c9563a'; }
      else if (f.kind === 'distributed') { msg = f.n + ' SORTS BACK IN THE CASE'; msgCol = '#4d8b77'; }
      else if (f.kind === 'nothing') { msg = 'NOTHING IN THE FORME TO DISTRIBUTE'; msgCol = '#9a8f79'; }
      else if (f.kind === 'set') { msg = '+' + f.gain + (f.gain > 30 ? ' — a good line' : ''); msgCol = '#e6c274'; }
    }

    /* ⚠️ The set line is drawn to the STICK's baseline, derived from the sheet's own baseline so a
       descender cannot hang out of the brass channel. The first version hard-coded the baseline
       and the p's and g's were sliced off by the channel's lower lip. */
    var cell = A.sortCell();
    var lineBase = b.y + 6 + Math.round((b.h - 12) * 0.72);
    if (g.entry) {
      A.drawSorts(ctx, g.entry, 164, lineBase, { scale: 0.70 });
    } else if (!msg) {
      A.text(ctx, 'type a word off the galley to set it', 164, b.y + 36, { size: 13, fill: '#5a5460' });
    }
    if (msg) A.text(ctx, msg, W - 164, b.y + 36, { size: 13, fill: msgCol, align: 'right' });
  }

  /* ---------------------------------------------------------------- the case */
  function drawCase() {
    var cb = LAY.caseBox;
    A.fillPlate(ctx, 'plate_oak', cb.x, cb.y, cb.w, cb.h);
    ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(cb.x, cb.y, cb.w, cb.h);
    if (!boxes) layoutCase();

    /* which letters is the locked word short of? those bins glow red */
    var shortOf = {};
    if (g.lock) {
      for (var i = 0; i < g.threats.length; i++) if (g.threats[i].id === g.lock) {
        var a = S.affordable(g, g.threats[i]);
        if (!a.ok) shortOf = a.short;
      }
    }

    for (var b = 0; b < boxes.length; b++) {
      var bx = boxes[b];
      var isHell = bx.k === 'hell';
      ctx.fillStyle = isHell ? 'rgba(14,16,19,0.85)' : 'rgba(0,0,0,0.30)';
      ctx.fillRect(bx.x, bx.y, bx.w, bx.h);
      A.bevel(ctx, bx.x, bx.y, bx.w, bx.h, 'rgba(0,0,0,0.5)', 'rgba(255,236,200,0.10)');

      if (isHell) {
        A.text(ctx, 'HELL BOX', bx.x + 5, bx.y + 14, { size: 9, fill: '#8f5a4a' });
        var hc = C.hellCount(g.cs);
        drawSlivers(bx, hc, 12, '#3c3438', '#544a4d');
        A.text(ctx, String(hc), bx.x + bx.w - 5, bx.y + 14, { size: 12, fill: hc ? '#c9563a' : '#4a4550', align: 'right' });
        continue;
      }

      var have = g.cs.sorts[bx.k] || 0;
      var full = g.cs.lay[bx.k] || 1;
      var lack = shortOf[bx.k];

      if (lack) { ctx.fillStyle = 'rgba(160,44,34,0.30)'; ctx.fillRect(bx.x, bx.y, bx.w, bx.h); }

      /* ⛔ THE BIN LABEL IS A SORT, NOT INK. The first version printed the letter from the INK
         sheet — a near-black glyph at half alpha, on dark oak, which was invisible in the very
         first screenshot of the real board. A metal sort is bright, it is legible on wood, and it
         is also the honest label: what is in this box is that piece of type. */
      A.drawSort(ctx, bx.k, bx.x + 3, bx.y + 1, 0.40);
      A.text(ctx, String(have), bx.x + bx.w - 5, bx.y + 15, {
        size: 12, fill: have === 0 ? '#a02c22' : (have < full / 3 ? '#c69a45' : '#8a8074'), align: 'right', weight: '600'
      });
      drawSlivers(bx, have, full, '#5f5d6e', '#a09cb0', 24);
      if (lack) A.text(ctx, '-' + lack, bx.x + bx.w / 2, bx.y + 15, { size: 11, fill: '#e0736a', align: 'center', weight: '600' });
    }

    /* ligature bins, if the foundry has cast any — they live along the drawer's front rail */
    if (g.cs.ligatures.length) {
      var lx = cb.x + 8, ly = cb.y + cb.h - 3;
      A.text(ctx, 'LIGATURES', lx, ly - 2, { size: 9, fill: '#6d543f' });
    }
  }

  /** A bin, drawn as what is actually in it: the ends of the sorts, standing on edge. */
  function drawSlivers(bx, have, full, base, lit, topPad) {
    if (full <= 0) return;
    var innerX = bx.x + 5, innerW = bx.w - 10;
    var top = bx.y + (topPad || 22), hgt = bx.h - (topPad || 22) - 6;
    var pitch = Math.max(3, Math.min(7, Math.floor(innerW / Math.max(full, 1))));
    var wdt = Math.max(2, pitch - 1);
    for (var i = 0; i < full; i++) {
      var x = innerX + i * pitch;
      if (x + wdt > innerX + innerW) break;
      if (i < have) {
        ctx.fillStyle = base; ctx.fillRect(x, top, wdt, hgt);
        ctx.fillStyle = lit; ctx.fillRect(x, top, wdt, 2);
        ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.fillRect(x + wdt - 1, top, 1, hgt);
      } else {
        ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fillRect(x, top, wdt, hgt);
      }
    }
  }

  /* ---------------------------------------------------------------- the page */
  function drawPage() {
    var p = LAY.page;
    A.fillPlate(ctx, 'plate_paper', p.x, p.y, p.w, p.h);
    ctx.fillStyle = 'rgba(0,0,0,0.12)'; ctx.fillRect(p.x, p.y, 3, p.h);
    /* the page's head: a printed rule between two rosettes, set from our own ornament case */
    A.drawOrnament(ctx, 'rosette', p.x + 26, p.y + 18, 0.42, 0.9);
    A.drawOrnament(ctx, 'rosette', p.x + p.w - 26, p.y + 18, 0.42, 0.9);
    ctx.fillStyle = 'rgba(30,26,28,0.75)'; ctx.fillRect(p.x + 44, p.y + 17, p.w - 88, 1);
    ctx.fillStyle = 'rgba(30,26,28,0.45)'; ctx.fillRect(p.x + 52, p.y + 21, p.w - 104, 1);

    var lines = g.lines.slice(-8);
    var y = p.y + 46;
    for (var i = 0; i < lines.length; i++) {
      var ln = lines[i];
      var scale = 0.42;
      var wpx = A.measureInk(ln.word, scale);
      var x = p.x + Math.max(10, (p.w - wpx) / 2);
      A.drawInk(ctx, ln.word, x, y, { scale: scale, starved: ln.kind === 'monk' ? false : false });
      if (ln.doubled) A.text(ctx, '·', x - 8, y - 3, { size: 16, fill: '#a02c22' });
      y += 19;
    }
    if (g.lines.length === 0) {
      A.text(ctx, 'the sheet is blank', p.x + p.w / 2, p.y + 56, { size: 12, fill: '#8a7f6b', align: 'center' });
    }
    A.drawOrnament(ctx, 'fleuron', p.x + p.w / 2, p.y + p.h - 18, 0.5, 0.7);
  }

  function drawMotes() {
    for (var i = 0; i < motes.length; i++) {
      var m = motes[i];
      ctx.save();
      ctx.translate(m.x, m.y); ctx.rotate(m.rot);
      ctx.globalAlpha = Math.min(1, m.life);
      A.drawSort(ctx, m.ch, -9, -12, 0.5, true);
      ctx.restore();
    }
  }

  /* ------------------------------------------------------------------ rounds */

  function startForme(index) {
    g = S.startForme(foundry, index, index * 7919 + 13);
    g.seed = index * 7919 + 13;
    layoutCase();
    screen = 'play';
    hideAll();
    SND.startMusic();
    SV.saveForme(g);
  }

  function resumeForme(snap) {
    g = S.startForme(foundry, snap.index, snap.seed);
    g.seed = snap.seed;
    g.cs.sorts = snap.sorts; g.cs.hell = snap.hell || {}; g.cs.inForme = snap.inForme || []; g.cs.spent = snap.spent || {};
    g.threats = snap.threats || []; g.nextId = snap.nextId || 1; g.spawned = snap.spawned || 0;
    g.spawnIn = snap.spawnIn || 1; g.spoils = snap.spoils || 0; g.impressions = snap.impressions || 0;
    g.lines = snap.lines || []; g.setCount = snap.setCount || 0; g.mistakes = snap.mistakes || 0;
    g.pied = snap.pied || 0; g.t = snap.t || 0;
    layoutCase();
    screen = 'play';
    hideAll();
    SND.startMusic();
  }

  function finishForme(won) {
    SV.clearForme();
    if (won) {
      foundry.banked += g.impressions;
      foundry.formesWon = Math.max(foundry.formesWon, g.index + 1);
      foundry.formeReached = Math.max(foundry.formeReached, g.index + 1);
      SND.play('sfx_press', 0.9);
    } else {
      /* ⛔ LEDGER B4. A lost forme costs the forme and NOTHING ELSE. Half the impressions still
         bank, the foundry is untouched, and you restart this page — never the book. */
      foundry.banked += Math.floor(g.impressions / 2);
      SND.play('sfx_spoil', 0.9);
      shake(340, 7);
    }
    /* ⛔ SNAPSHOT THE SPEND TALLY BEFORE THE WASH. The foundry's casting offers are supposed to
       follow what you actually ran out of — "the bin holds 12, you spent 34 of them tonight" — and
       `wash()` clears cs.spent, so reading it afterwards reported ZERO for every letter and the
       menu quietly stopped adapting. Every check still passed: the offers existed, they had costs,
       they could be bought. The defect was only visible by READING THE WORDS on the screenshot. */
    var spentTonight = JSON.parse(JSON.stringify(g.cs.spent));
    C.wash(g.cs);
    SV.saveFoundry(foundry);
    screen = 'foundry';
    showFoundry(won, spentTonight);
  }

  function shake(ms, mag) { shakeUntil = performance.now() + ms; shakeMag = mag; }

  /* ------------------------------------------------------------------- input */

  window.addEventListener('keydown', function (e) {
    SND.unlock();
    if (e.key === 'Escape') {
      if (screen === 'play') { openHelp(); e.preventDefault(); return; }
      if (!document.getElementById('help').hidden) { closeHelp(); e.preventDefault(); return; }
    }
    if (screen !== 'play' || !g) return;
    if (e.ctrlKey || e.metaKey || e.altKey) return;

    if (e.key === ' ') {
      e.preventDefault();
      if (S.beginDistribution(g)) SND.play('sfx_diss', 0.8);
      else SND.play('sfx_deny', 0.5);
      SV.saveForme(g);
      return;
    }
    if (e.key === 'Backspace') { e.preventDefault(); g.entry = ''; g.lock = 0; return; }
    if (!/^[a-zA-Z]$/.test(e.key)) return;
    e.preventDefault();

    var before = g.cs.inForme.length;
    var r = S.type(g, e.key);
    if (r === 'progress') SND.lift(e.key.toLowerCase());
    else if (r === 'set') {
      SND.play('sfx_set', 0.7);
      SV.saveForme(g);
    } else {
      SND.play('sfx_miss', 0.75);
      shake(160, 4);
      dropSorts(e.key.toLowerCase(), 1, 200 + Math.random() * 500, LAY.stick.y + 20);
    }
    if (before !== g.cs.inForme.length) layoutCase();
  });

  /* ---------------------------------------------------------------- overlays */

  function el(id) { return document.getElementById(id); }
  function hideAll() { ['title', 'help', 'foundry', 'end'].forEach(function (i) { el(i).hidden = true; }); }
  function openHelp() { el('help').hidden = false; }
  function closeHelp() { el('help').hidden = true; }

  /* ------------------------------------------------------- the mark on an offer card
   * Wing CLAUDE.md 3e: the upgrade screen is where this wing loses Gate 1, and the fix is NOT a
   * stock icon set - it is a mark composed by the GAME'S OWN renderer at the REAL offer data, so
   * it cannot drift from the game. Every offer already carries what it is about (kind + letter /
   * lig / up), so nothing here is a second copy of the offer table that could go stale: a new
   * ligature or a renamed letter needs no edit in this function.
   *
   * The sorts sheet already draws the whole piece of metal - body, face and nick - so a cast offer
   * is literally the sort you are buying, and a ligature is set through the game's own compositor
   * (drawSorts), which is what makes two abutted bodies read as the one wider body it really is. */
  /* 1:1 with the sort cell (38x50) and with the CSS box, exactly as `canvas#cv` is 960x540 in both
   * — so a cast sort resamples NOT AT ALL. A ligature is wider than one body and must scale down to
   * fit; smoothing is left ON for that, because a nearest-neighbour DOWNSCALE drops whole pixel rows
   * out of a letterform while a bilinear one just softens it. */
  var MARK_W = 38, MARK_H = 50;
  var UP_ORNAMENT = {
    swift:    'manicule',   // the pointing hand - distribution, and the direction of the stick
    alloy:    'lozenge',    // hard metal, cut hard
    imposing: 'cornerTL',   // locking the forme up in the chase
    redink:   'rosette',    // the classic ornament pulled in the second colour
    deeper:   'acorn'       // one more of every sort: the drawer that keeps growing
  };

  /** Width the string actually PAINTS: advances, plus the last cell's overhang past its advance. */
  function paintedSortsWidth(str, s) {
    var cell = A.sortCell();
    return A.measureSorts(str, s) - A.sortAdvance(str[str.length - 1], s) + cell.cw * s;
  }

  function drawOfferMark(cv2, o) {
    if (!cv2 || !A.assetsLoaded()) return false;   // no sheets -> leave the card as plain type
    var c2 = cv2.getContext('2d');
    c2.clearRect(0, 0, MARK_W, MARK_H);
    var cell = A.sortCell();

    if (o.kind === 'cast') {
      var s = Math.min(Math.floor(MARK_W / cell.cw), Math.floor(MARK_H / cell.ch)) || 1;
      A.drawSort(c2, o.letter, (MARK_W - cell.cw * s) / 2, (MARK_H - cell.ch * s) / 2, s, false);
      return true;
    }
    if (o.kind === 'lig') {
      var fit = Math.min(MARK_W / paintedSortsWidth(o.lig, 1), MARK_H / cell.ch);
      var w = paintedSortsWidth(o.lig, fit);
      A.drawSorts(c2, o.lig, (MARK_W - w) / 2, (MARK_H - cell.ch * fit) / 2 + cell.baseline * fit,
        { scale: fit });
      return true;
    }
    var orn = UP_ORNAMENT[o.up];
    if (!orn) return false;
    var oc = (A.sheets() && A.sheets().orn) ? A.sheets().orn : { cw: 44, ch: 44 };
    A.drawOrnament(c2, orn, MARK_W / 2, MARK_H / 2, Math.min(MARK_W / oc.cw, MARK_H / oc.ch));
    return true;
  }

  function showFoundry(won, spentTonight) {
    var box = el('foundry');
    var spent = spentTonight || (g ? g.cs.spent : {});
    var offs = S.offers(foundry, spent);
    var next = won ? foundry.formesWon : (g ? g.index : 0);
    var beaten = next >= S.FORMES.length;

    var head = won
      ? '<h2>THE FORME IS PRINTED</h2><p class="sub">' + (g ? g.title : '') + ' came off the press. '
        + (g ? g.impressions : 0) + ' impressions banked'
        + (g && g.mistakes === 0 ? ', and not one sort dropped all night.' : '.') + '</p>'
      : '<h2>' + (g && g.deadReason === 'outofsorts' ? 'OUT OF SORTS' : 'THE PAGE IS SPOILED') + '</h2>'
        + '<p class="sub">' + (g && g.deadReason === 'outofsorts'
          ? 'You could not set a single word on the galley, and breaking the forme up would not have helped. That is what the phrase means.'
          : 'Too many sheets ruined. The forme is broken up and reset.')
        + ' You keep half the impressions and every last thing in the foundry.</p>';

    var rows = offs.map(function (o) {
      var afford = foundry.banked >= o.cost;
      return '<button class="offer' + (afford ? '' : ' poor') + '" data-id="' + o.id + '"'
        + (afford ? '' : ' disabled') + '>'
        + '<canvas class="osort" width="' + MARK_W + '" height="' + MARK_H + '" aria-hidden="true"></canvas>'
        + '<span class="oname">' + o.name + '</span>'
        + '<span class="ocost">' + o.cost + '</span>'
        + '<span class="odesc">' + o.desc + '</span></button>';
    }).join('');

    box.innerHTML = '<div class="sheet">' + head
      + '<div class="bank">THE FOUNDRY &nbsp;·&nbsp; <b>' + foundry.banked + '</b> impressions in hand</div>'
      + '<div class="offers">' + rows + '</div>'
      + '<div class="btns">'
      + '<button id="go" class="go">' + (beaten ? 'PRINT ANOTHER (the night shift)' : (won ? 'SET THE NEXT FORME' : 'SET IT AGAIN')) + '</button>'
      + '<button id="wipe2" class="ghost">Melt everything down and start over</button>'
      + '</div></div>';
    box.hidden = false;

    box.querySelectorAll('.offer').forEach(function (b) {
      var mine = offs.filter(function (x) { return x.id === b.dataset.id; })[0];
      if (mine) drawOfferMark(b.querySelector('.osort'), mine);
      b.addEventListener('click', function () {
        var o = offs.filter(function (x) { return x.id === b.dataset.id; })[0];
        if (o && S.buy(foundry, o)) { SND.play('sfx_cast', 0.8); SV.saveFoundry(foundry); showFoundry(won, spent); }
        else SND.play('sfx_deny', 0.6);
      });
    });
    el('go').addEventListener('click', function () {
      SND.unlock();
      startForme(won ? Math.min(foundry.formesWon, 9999) : (g ? g.index : 0));
    });
    el('wipe2').addEventListener('click', function () {
      SV.wipeAll(); foundry = S.newFoundry(); g = null; screen = 'title';
      hideAll(); el('title').hidden = false;
    });
  }

  /* ------------------------------------------------------------------- boot */

  el('begin').addEventListener('click', function () {
    SND.unlock();
    var snap = SV.loadForme();
    if (snap) resumeForme(snap); else startForme(foundry.formesWon || 0);
  });
  el('wipe').addEventListener('click', function () {
    SV.wipeAll(); foundry = S.newFoundry();
    el('begin').textContent = 'Take up the stick';
    el('resume-note').textContent = '';
  });
  el('howto').addEventListener('click', openHelp);
  document.querySelectorAll('[data-close]').forEach(function (b) {
    b.addEventListener('click', function () { closeHelp(); });
  });

  (function boot() {
    var snap = SV.loadForme();
    var note = el('resume-note');
    if (snap) {
      note.textContent = 'A forme is still standing on the stone — ' + (S.FORMES[Math.min(snap.index, S.FORMES.length - 1)].title)
        + ', ' + (snap.lines ? snap.lines.length : 0) + ' lines set. It will carry on where you left it.';
      el('begin').textContent = 'Back to the frame';
    } else if (foundry.formesWon) {
      note.textContent = 'The foundry remembers you: ' + foundry.formesWon + ' formes printed, '
        + foundry.banked + ' impressions in hand.';
    }
    A.load(function () { ready = A.assetsLoaded(); });
    requestAnimationFrame(frame);
  })();

  /* the capture harness and the smoke test both need an honest handle on the real thing */
  window.OOS = {
    state: function () { return g; },
    foundry: function () { return foundry; },
    art: A, sim: S, caseApi: C,
    start: startForme,
    ready: function () { return A.assetsLoaded(); },
    setScreen: function (s) { screen = s; },
    hideAll: hideAll
  };
})();
