/* OUT OF SORTS — art.js : asset loading and every drawing primitive.
 *
 * Nothing in here knows the rules of the game. It knows how to set a line of type, how to pull a
 * proof of it, and how to draw the furniture of a print shop.
 *
 * ⛔ THE GAME'S OWN TYPE IS DRAWN FROM THE SHEETS, NOT FROM ctx.fillText. Every word on the board,
 *    on the page and in the case is composed sort by sort out of `sheet_sorts.png` and
 *    `sheet_ink.png`, at the advance widths the generator recorded in sheets.json — which is
 *    literally what a compositor does. A system font is used ONLY for interface chrome (numbers,
 *    labels, the help sheet) where a bitmap face would be unreadable.
 *
 * ⛔ TEXT IS MEASURED, NEVER GUESSED for that chrome. Canvas text does not wrap, does not reflow
 *    and does not clip, and this game ships a system font stack, so the same string is a different
 *    width on every machine. `wrap` and `paragraph` derive layout from ctx.measureText at DRAW
 *    time, and every internal caller goes through the exported API.text so the layout gate can see
 *    it — a helper calling a closure-local text() is invisible to the recorder, which is exactly
 *    how FLOODMARK shipped a paragraph running off the canvas past 133 green assertions.
 */
'use strict';

var OOS_ART = (function () {

  var FONT = "'Iowan Old Style', 'Palatino Linotype', Palatino, Georgia, 'Times New Roman', serif";
  var IMAGES = {};
  var SHEETS = null;
  var loaded = false;
  var NEED = ['sheet_sorts', 'sheet_ink', 'sheet_orn', 'plate_oak', 'plate_paper', 'plate_iron', 'plate_felt'];

  function load(onDone) {
    var got = 0;
    var finish = function () { got++; if (got === NEED.length) { loaded = true; onDone(); } };
    fetch('art/sheets.json').then(function (r) { return r.json(); }).then(function (j) {
      SHEETS = j;
      NEED.forEach(function (n) {
        var im = new Image();
        im.onload = finish; im.onerror = finish;
        im.src = 'art/' + n + '.png';
        IMAGES[n] = im;
      });
    }).catch(function () { loaded = true; onDone(); });
  }

  /** The only honest proof an asset DECODED, which a capture harness must wait on. */
  function assetsLoaded() {
    if (!loaded || !SHEETS) return false;
    for (var k in IMAGES) if (IMAGES[k].naturalWidth === 0) return false;
    return true;
  }

  var patterns = {};
  function pattern(ctx, name) {
    if (!patterns[name]) {
      if (!IMAGES[name] || IMAGES[name].naturalWidth === 0) return '#241a12';
      patterns[name] = ctx.createPattern(IMAGES[name], 'repeat');
    }
    return patterns[name];
  }

  var API = {};

  /* ------------------------------------------------------------ setting type */

  function col(sheet, ch) {
    var i = sheet.order.indexOf(ch);
    return i < 0 ? -1 : i;
  }

  /** How wide a word will be when it is SET — measured off the generator's own advances. */
  API.measureSorts = function (str, scale) {
    var sh = SHEETS && SHEETS.sorts;
    if (!sh) return String(str).length * 10 * (scale || 1);
    var s = scale === undefined ? 1 : scale, w = 0;
    for (var i = 0; i < str.length; i++) {
      var c = str[i];
      if (c === ' ') { w += 10 * s; continue; }
      var j = col(sh, c);
      w += (j < 0 ? 10 : sh.adv[c]) * s;
    }
    return w;
  };
  API.measureInk = function (str, scale) {
    var sh = SHEETS && SHEETS.ink;
    if (!sh) return String(str).length * 10 * (scale || 1);
    var s = scale === undefined ? 1 : scale, w = 0;
    for (var i = 0; i < str.length; i++) {
      var c = str[i];
      if (c === ' ') { w += 10 * s; continue; }
      var j = col(sh, c);
      w += (j < 0 ? 10 : sh.adv[c]) * s;
    }
    return w;
  };

  /**
   * Set a word out of the case, sort by sort. `worn` picks the second row.
   * x,y is the LEFT BASELINE, exactly as a compositor would place it against the stick.
   */
  API.drawSorts = function (ctx, str, x, y, opts) {
    opts = opts || {};
    var sh = SHEETS && SHEETS.sorts, im = IMAGES.sheet_sorts;
    var s = opts.scale === undefined ? 1 : opts.scale;
    if (!sh || !im || im.naturalWidth === 0) { API.text(ctx, str, x, y, { size: 18 * s }); return x; }
    var row = opts.worn ? 1 : 0;
    var cx = x;
    for (var i = 0; i < str.length; i++) {
      var c = str[i];
      if (c === ' ') { cx += 10 * s; continue; }
      var j = col(sh, c);
      if (j < 0) { cx += 10 * s; continue; }
      var w = sh.cw * s, h = sh.ch * s;
      ctx.drawImage(im, j * sh.cw, row * sh.ch, sh.cw, sh.ch,
        Math.round(cx), Math.round(y - sh.baseline * s), Math.round(w), Math.round(h));
      cx += sh.adv[c] * s;
    }
    return cx;
  };

  /** Pull a proof: the same letters as printed impressions on paper. */
  API.drawInk = function (ctx, str, x, y, opts) {
    opts = opts || {};
    var sh = SHEETS && SHEETS.ink, im = IMAGES.sheet_ink;
    var s = opts.scale === undefined ? 1 : opts.scale;
    if (!sh || !im || im.naturalWidth === 0) { API.text(ctx, str, x, y, { size: 18 * s, fill: '#1e1a1c' }); return x; }
    var row = opts.starved ? 1 : 0;
    var cx = x;
    if (opts.alpha !== undefined) { ctx.save(); ctx.globalAlpha = opts.alpha; }
    for (var i = 0; i < str.length; i++) {
      var c = str[i];
      if (c === ' ') { cx += 10 * s; continue; }
      var j = col(sh, c);
      if (j < 0) { cx += 10 * s; continue; }
      ctx.drawImage(im, j * sh.cw, row * sh.ch, sh.cw, sh.ch,
        Math.round(cx), Math.round(y - sh.baseline * s), Math.round(sh.cw * s), Math.round(sh.ch * s));
      cx += sh.adv[c] * s;
    }
    if (opts.alpha !== undefined) ctx.restore();
    return cx;
  };

  API.drawOrnament = function (ctx, name, x, y, scale, alpha) {
    var sh = SHEETS && SHEETS.orn, im = IMAGES.sheet_orn;
    if (!sh || !im || im.naturalWidth === 0) return;
    var j = sh.order.indexOf(name);
    if (j < 0) return;
    var s = scale === undefined ? 1 : scale;
    if (alpha !== undefined) { ctx.save(); ctx.globalAlpha = alpha; }
    ctx.drawImage(im, j * sh.cw, 0, sh.cw, sh.ch,
      Math.round(x - sh.cw * s / 2), Math.round(y - sh.ch * s / 2), Math.round(sh.cw * s), Math.round(sh.ch * s));
    if (alpha !== undefined) ctx.restore();
  };

  /** One sort, drawn on its own — the unit the case is full of. */
  API.drawSort = function (ctx, ch, x, y, scale, worn) {
    var sh = SHEETS && SHEETS.sorts, im = IMAGES.sheet_sorts;
    if (!sh || !im || im.naturalWidth === 0) return 0;
    var j = col(sh, ch);
    if (j < 0) return 0;
    var s = scale === undefined ? 1 : scale;
    ctx.drawImage(im, j * sh.cw, (worn ? 1 : 0) * sh.ch, sh.cw, sh.ch,
      Math.round(x), Math.round(y), Math.round(sh.cw * s), Math.round(sh.ch * s));
    return sh.adv[ch] * s;
  };

  API.sortAdvance = function (ch, scale) {
    var sh = SHEETS && SHEETS.sorts;
    if (!sh) return 10 * (scale || 1);
    return (sh.adv[ch] || 10) * (scale === undefined ? 1 : scale);
  };
  API.sortCell = function () { return (SHEETS && SHEETS.sorts) ? SHEETS.sorts : { cw: 38, ch: 50, baseline: 34 }; };

  /* --------------------------------------------------------------- chrome text */

  function setFont(ctx, px, weight) { ctx.font = (weight ? weight + ' ' : '') + px + 'px ' + FONT; }

  API.text = function (ctx, str, x, y, opts) {
    opts = opts || {};
    setFont(ctx, opts.size || 14, opts.weight);
    ctx.textAlign = opts.align || 'left';
    ctx.textBaseline = opts.baseline || 'alphabetic';
    if (opts.shadow) { ctx.fillStyle = 'rgba(0,0,0,0.7)'; ctx.fillText(str, x + 1, y + 1); }
    ctx.fillStyle = opts.fill || '#c9bda6';
    ctx.fillText(str, x, y);
  };

  API.wrap = function (ctx, str, maxW, size, weight) {
    setFont(ctx, size || 14, weight);
    var words = String(str).split(/\s+/), lines = [], cur = '';
    for (var i = 0; i < words.length; i++) {
      var t = cur ? cur + ' ' + words[i] : words[i];
      if (ctx.measureText(t).width > maxW && cur) { lines.push(cur); cur = words[i]; }
      else cur = t;
    }
    if (cur) lines.push(cur);
    return lines;
  };

  /* ⚠️ Routes through API.text on purpose — a helper calling a closure-local text() is invisible
     to test_layout's recorder, which is the documented way a gate goes green over the lines most
     likely to overflow. */
  API.paragraph = function (ctx, str, x, y, maxW, opts) {
    opts = opts || {};
    var size = opts.size || 14;
    var lines = API.wrap(ctx, str, maxW, size, opts.weight);
    var lh = opts.lineHeight || Math.round(size * 1.45);
    for (var i = 0; i < lines.length; i++) API.text(ctx, lines[i], x, y + i * lh, opts);
    return y + lines.length * lh;
  };

  /* ------------------------------------------------------------- the furniture */

  API.fillPlate = function (ctx, name, x, y, w, h) {
    ctx.save();
    ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
    ctx.fillStyle = pattern(ctx, name);
    ctx.fillRect(x, y, w, h);
    ctx.restore();
  };

  /** A bevelled edge in the shop's own materials — used for every panel, so the UI is furniture. */
  API.bevel = function (ctx, x, y, w, h, light, dark) {
    ctx.strokeStyle = light || 'rgba(255,236,200,0.16)';
    ctx.beginPath(); ctx.moveTo(x + 0.5, y + h - 0.5); ctx.lineTo(x + 0.5, y + 0.5); ctx.lineTo(x + w - 0.5, y + 0.5); ctx.stroke();
    ctx.strokeStyle = dark || 'rgba(0,0,0,0.55)';
    ctx.beginPath(); ctx.moveTo(x + w - 0.5, y + 0.5); ctx.lineTo(x + w - 0.5, y + h - 0.5); ctx.lineTo(x + 0.5, y + h - 0.5); ctx.stroke();
  };

  /** A brass rule — the shop's divider, and the only bright line on the screen. */
  API.rule = function (ctx, x, y, w) {
    ctx.fillStyle = '#6b4a1c'; ctx.fillRect(x, y, w, 3);
    ctx.fillStyle = '#c69a45'; ctx.fillRect(x, y, w, 1);
  };

  API.FONT = FONT;
  API.images = IMAGES;
  API.sheets = function () { return SHEETS; };
  API.load = load;
  API.assetsLoaded = assetsLoaded;
  return API;
})();

if (typeof module !== 'undefined' && module.exports) module.exports = OOS_ART;
