/* OUT OF SORTS — the type case.
 *
 * The whole game is here. A compositor does not have "letters", they have SORTS: individual
 * pieces of metal type, a finite number of each, living in a partitioned drawer called a case.
 * Setting a word lifts those sorts out of the case; they do not come back until the forme is
 * broken up and the type is DISTRIBUTED (the real trade word — "dissing") back into its boxes.
 *
 * "Out of sorts" is a printer's phrase before it was a mood: it means the compositor has run
 * out of a letter and cannot set the line. That is this game's fail state, and it is the reason
 * the title is the mechanic.
 *
 * ⛔ DESIGN LAW, ledger B5 (complexity floor): the case is the SECOND system and it must
 * genuinely feed back into the first. Setting words is system one; the case is system two; the
 * interaction is that your vocabulary shrinks IN A SHAPE YOU CHOSE. Spend three E on MEMENTO
 * and DEFENCE stops being settable. Nothing in this file may be "simplified" into a single
 * ammo counter without destroying the game.
 *
 * No dependencies, no build step, raw and readable on purpose (master §3).
 */
(function (root) {
  'use strict';

  /* The lay of the case. These proportions are the real ones — a printer's font scheme carries
   * roughly 12,000 e against 400 z — scaled down to a playable drawer. Keeping the real ratios
   * is what makes the letter economy feel like a craft constraint rather than a designer's dial:
   * E is abundant and Q is precious for the same reason it is in English. */
  var STANDARD_LAY = {
    e: 12, t: 9, a: 8, o: 8, i: 7, n: 7, s: 7, h: 6, r: 6,
    d: 4, l: 4, u: 3, c: 3, m: 3,
    w: 2, f: 2, g: 2, y: 2, p: 2, b: 2,
    v: 1, k: 1, j: 1, x: 1, q: 1, z: 1
  };

  /* Ligatures are single sorts that print more than one letter — a real thing in metal type
   * (fi, fl, ffi). They are the clearest expression of the upgrade layer: buying one does not
   * add damage, it changes WHICH WORDS ARE AFFORDABLE, which is an upgrade to system one
   * delivered through system two. A ligature is spent as ONE sort. */
  var DEFAULT_LIGATURES = [];   // earned in the foundry, e.g. ['th', 'fi', 'ing']

  function assertLetters(obj, where) {
    for (var k in obj) {
      if (!Object.prototype.hasOwnProperty.call(obj, k)) continue;
      if (!/^[a-z]$/.test(k)) throw new Error(where + ': bad sort key "' + k + '"');
      if (typeof obj[k] !== 'number' || obj[k] < 0 || obj[k] !== Math.floor(obj[k])) {
        throw new Error(where + ': sort "' + k + '" must be a non-negative integer, got ' + obj[k]);
      }
    }
  }

  function createCase(overrides, ligatures) {
    var c = {};
    for (var k in STANDARD_LAY) {
      if (Object.prototype.hasOwnProperty.call(STANDARD_LAY, k)) c[k] = STANDARD_LAY[k];
    }
    if (overrides) { assertLetters(overrides, 'createCase'); for (var o in overrides) {
      if (Object.prototype.hasOwnProperty.call(overrides, o)) c[o] = overrides[o]; } }
    return {
      sorts: c,                                   // what is IN the drawer right now
      lay: JSON.parse(JSON.stringify(c)),         // what a full drawer looks like, for distribute()
      ligatures: (ligatures || DEFAULT_LIGATURES).slice(),
      inForme: [],                                // words currently set, awaiting distribution
      spent: {},                                  // running tally, for the UI's emptying drawer
      hell: {}                                    // the HELL BOX — see pie() below
    };
  }

  /* Normalise a word to the sorts it would actually consume.
   * Ligatures are applied longest-first and greedily: owning 'th' means THE costs th + e, i.e.
   * TWO sorts rather than three, and critically spends no separate t or h. */
  function decompose(cs, word) {
    var w = String(word || '').toLowerCase().replace(/[^a-z]/g, '');
    if (!w) return [];
    var ligs = cs.ligatures.slice().sort(function (a, b) { return b.length - a.length; });
    var out = [], i = 0;
    outer: while (i < w.length) {
      for (var L = 0; L < ligs.length; L++) {
        var g = ligs[L];
        if (g.length && w.substr(i, g.length) === g) { out.push(g); i += g.length; continue outer; }
      }
      out.push(w[i]); i += 1;
    }
    return out;
  }

  /* What this word would cost, as a map of sort -> count. */
  function costOf(cs, word) {
    var need = {}, parts = decompose(cs, word);
    for (var i = 0; i < parts.length; i++) need[parts[i]] = (need[parts[i]] || 0) + 1;
    return need;
  }

  /* Can the case set this word RIGHT NOW?
   * Returns {ok:true} or {ok:false, short:{letter:count}} — the shortfall is returned rather
   * than a bare false, because the UI has to be able to say "you are two E short", which is the
   * single most important piece of feedback in the game. */
  function canSet(cs, word) {
    var need = costOf(cs, word);
    if (Object.keys(need).length === 0) return { ok: false, short: {}, empty: true };
    var short = null;
    for (var k in need) {
      if (!Object.prototype.hasOwnProperty.call(need, k)) continue;
      var have = cs.sorts[k];
      if (have === undefined) have = 0;           // a ligature we do not own, or an absent sort
      if (have < need[k]) { short = short || {}; short[k] = need[k] - have; }
    }
    return short ? { ok: false, short: short } : { ok: true };
  }

  /* Lift the sorts out of the case and put the word in the forme. */
  function setWord(cs, word) {
    var check = canSet(cs, word);
    if (!check.ok) return check;                  // caller must handle; never spend on failure
    var need = costOf(cs, word);
    for (var k in need) {
      if (!Object.prototype.hasOwnProperty.call(need, k)) continue;
      cs.sorts[k] -= need[k];
      cs.spent[k] = (cs.spent[k] || 0) + need[k];
    }
    cs.inForme.push(String(word).toLowerCase().replace(/[^a-z]/g, ''));
    return { ok: true, cost: need };
  }

  /* DISTRIBUTION — break the forme up and return every sort to its box.
   * This is the round boundary and the game's only reset. It restores the case to `lay`, which
   * means a foundry upgrade that deepens the E bin is permanent across distributions: progress
   * lives in the LAY, never in the current drawer. That is what keeps B4 true (losing a round
   * costs the round, never the foundry). */
  function distribute(cs) {
    var returned = 0;
    for (var k in cs.lay) {
      if (!Object.prototype.hasOwnProperty.call(cs.lay, k)) continue;
      /* ⛔ THE HELL BOX IS WHY DISTRIBUTION IS NOT A FREE UNDO. Sorts that were PIED — dropped on
         the floor, or knocked out of the case by a devil — are not in the forme, so breaking the
         forme up cannot bring them back. They are recovered only at the end-of-round wash. That
         one subtraction is what makes "out of sorts" a real losing condition rather than a pause:
         without it, every empty case could be refilled by pressing one key. */
      var lost = cs.hell[k] || 0;
      var full = Math.max(0, cs.lay[k] - lost);
      returned += Math.max(0, full - cs.sorts[k]);
      cs.sorts[k] = full;
    }
    cs.inForme = [];
    cs.spent = {};
    return { returned: returned };
  }

  /* PIE (verb): to drop type and jumble it. Moves sorts out of the drawer and into the hell box,
   * where distribution cannot reach them. Returns how many actually fell — an empty bin cannot
   * be pied, which is why a drained case is oddly safe from devils and dangerous from everything
   * else. */
  function pie(cs, letter, n) {
    var l = String(letter).toLowerCase();
    var have = cs.sorts[l] || 0;
    var take = Math.max(0, Math.min(have, n));
    if (take === 0) return 0;
    cs.sorts[l] = have - take;
    cs.hell[l] = (cs.hell[l] || 0) + take;
    return take;
  }

  /* THE WASH — the end of a round. The press is washed down, the hell box is re-melted and every
   * sort in the shop is back in its box. This is the ONLY thing that empties the hell box, and it
   * is why a lost round costs the round and never the foundry (ledger B4). */
  function wash(cs) {
    cs.hell = {};
    return distribute(cs);
  }

  function hellCount(cs) {
    var n = 0;
    for (var k in cs.hell) if (Object.prototype.hasOwnProperty.call(cs.hell, k)) n += cs.hell[k];
    return n;
  }

  /* Could this word EVER be set with the drawer as it is currently cast — ignoring what is
   * presently spent? Used to decide what the shop is even asked to set: a word needing two V is
   * not a hard word, it is an impossible one, until the foundry casts a second V. */
  function settableFromLay(cs, word) {
    var need = costOf(cs, word);
    for (var k in need) {
      if (!Object.prototype.hasOwnProperty.call(need, k)) continue;
      if ((cs.lay[k] || 0) < need[k]) return false;
    }
    return Object.keys(need).length > 0;
  }

  /* Permanently deepen a bin — the foundry casting more of a letter. Changes the LAY, so it
   * survives distribution and survives a lost run. */
  function castSorts(cs, letter, n) {
    var l = String(letter).toLowerCase();
    if (!/^[a-z]$/.test(l)) throw new Error('castSorts: not a letter: ' + letter);
    if (!(n > 0)) throw new Error('castSorts: n must be positive');
    cs.lay[l] = (cs.lay[l] || 0) + n;
    cs.sorts[l] = (cs.sorts[l] || 0) + n;
    return cs.lay[l];
  }

  function addLigature(cs, g) {
    var s = String(g).toLowerCase();
    if (!/^[a-z]{2,4}$/.test(s)) throw new Error('addLigature: bad ligature "' + g + '"');
    if (cs.ligatures.indexOf(s) === -1) {
      cs.ligatures.push(s);
      /* A ligature is a sort in its own right and needs its own box. One to start with; the
       * foundry can cast more. */
      if (cs.lay[s] === undefined) { cs.lay[s] = 1; cs.sorts[s] = 1; }
    }
    return cs.ligatures.slice();
  }

  /* ⛔ THE FAIL STATE. Not death, not a timer: the compositor cannot set ANY of the words on
   * offer, and is therefore literally out of sorts. Returns the settable subset so the caller
   * can both act and explain. */
  function settable(cs, words) {
    var ok = [];
    for (var i = 0; i < words.length; i++) if (canSet(cs, words[i]).ok) ok.push(words[i]);
    return ok;
  }
  function isOutOfSorts(cs, words) { return settable(cs, words).length === 0; }

  /* How full the drawer is, 0..1 — the number the emptying-case visual is driven from. */
  function fullness(cs) {
    var have = 0, max = 0;
    for (var k in cs.lay) {
      if (!Object.prototype.hasOwnProperty.call(cs.lay, k)) continue;
      max += cs.lay[k]; have += cs.sorts[k];
    }
    return max === 0 ? 0 : have / max;
  }

  var API = {
    STANDARD_LAY: STANDARD_LAY,
    createCase: createCase, decompose: decompose, costOf: costOf, canSet: canSet,
    setWord: setWord, distribute: distribute, castSorts: castSorts, addLigature: addLigature,
    settable: settable, isOutOfSorts: isOutOfSorts, fullness: fullness,
    pie: pie, wash: wash, hellCount: hellCount, settableFromLay: settableFromLay
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  else root.CASE = API;
})(typeof window !== 'undefined' ? window : globalThis);
