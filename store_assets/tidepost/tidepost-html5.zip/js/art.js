/* TIDEPOST — art.js : every mark this game makes on the canvas.
 *
 * ⛔ EVERY STRING GOES THROUGH `API.text`. NOT the closure-local `text`. Wing §3e-1 records the
 *    exact defect this prevents: a layout gate reported "help — 12 strings" for a screen drawing
 *    thirty, because `paragraph` called the local function and the recorder had replaced only the
 *    exported one — blind to precisely the lines most likely to overflow. So `paragraph`, `button`
 *    and everything else here routes through the exported object, and `test_layout.js` asserts a
 *    FLOOR on how many strings the recorder saw per screen so the blindness cannot come back quietly.
 *
 * ⛔ AND NO LAYOUT NUMBER IS EVER TYPED. This game ships a system serif stack, so the same string is
 *    a different width on a Mac, on Windows, on Linux and in headless capture. Every wrap and every
 *    column is derived from `ctx.measureText` AT DRAW TIME.
 *
 * THE LOOK: a working chart, with the instruments laid on it. The sea is the cold half and the paper
 * is the warm half, and the only saturated colour in the game is the track you are about to sail.
 */
(function (root) {
  'use strict';

  /* The inks. These are the marks a navigator makes, not the materials — the materials are the
   * generated plates. Kept in one place so nothing hard-codes a colour at a call site. */
  var INK = {
    ink:      '#241a11',   // iron gall on paper
    inkSoft:  '#4a3a28',
    inkFaint: '#7d6a4e',
    rule:     '#9c8763',
    paper:    '#dbc9ab',
    paperLit: '#efe1c6',
    track:    '#9c3b24',   // the leg you are about to sail: the one saturated thing in the game
    trackLit: '#d5643f',
    lamp:     '#f0c86a',   // a lit window, a beacon, goodwill
    lampHot:  '#ffe9a8',
    sea:      '#14384a',
    seaLit:   '#3a7995',
    stream:   'rgba(169,222,219,0.50)',
    streamHi: 'rgba(220,245,242,0.85)',
    good:     '#5e7546',   // supplied
    want:     '#9c3b24'    // wanting
  };

  var FONT = "'Iowan Old Style', 'Palatino Linotype', Palatino, Georgia, serif";

  var ctx = null, W = 0, H = 0;
  var plates = {};          // name -> { img, pattern }
  var sheets = {};          // 'islands' | 'marks' | 'boat' -> { img, meta }
  var loaded = false;

  /* ------------------------------------------------------------------ loading
   * ⛔ A CAPTURE SCRIPT MUST BE ABLE TO WAIT FOR THIS (wing §3d rule 3). `isLoaded()` is the only
   * proof the assets actually DECODED — an <img> whose src is set is not an <img> that is ready,
   * and a capture taken between the two is a store screenshot of an empty screen.
   */
  function loadImage(src) {
    return new Promise(function (res, rej) {
      var i = new Image();
      i.onload = function () { res(i); };
      i.onerror = function () { rej(new Error('could not load ' + src)); };
      i.src = src;
    });
  }

  function init(canvas, w, h) {
    ctx = canvas.getContext('2d');
    W = w; H = h;
    ctx.imageSmoothingEnabled = false;
    ctx.textBaseline = 'alphabetic';
    return ctx;
  }

  var PLATE_NAMES = ['sea', 'shoal', 'chart', 'rock', 'turf', 'brass'];

  function loadAll(base) {
    var b = base || 'art/';
    var jobs = PLATE_NAMES.map(function (n) {
      return loadImage(b + 'plate_' + n + '.png').then(function (img) {
        plates[n] = { img: img, pattern: ctx.createPattern(img, 'repeat') };
      });
    });
    jobs.push(fetch(b + 'sheets.json').then(function (r) { return r.json(); }).then(function (meta) {
      var subs = Object.keys(meta).map(function (k) {
        return loadImage(b + meta[k].file).then(function (img) { sheets[k] = { img: img, meta: meta[k] }; });
      });
      return Promise.all(subs);
    }));
    return Promise.all(jobs).then(function () { loaded = true; return true; });
  }
  function isLoaded() { return loaded; }

  /* ------------------------------------------------------------------ surfaces */

  /** Tile a plate. ⚠️ Drawn at 1:1 — the engine's ordered dither reads as fine grain at 1:1 and as
   *  chunky mush the moment it is scaled. */
  function plate(name, x, y, w, h, alpha) {
    if (!plates[name]) return;
    ctx.save();
    if (alpha !== undefined) ctx.globalAlpha = alpha;
    ctx.fillStyle = plates[name].pattern;
    ctx.translate(x, y);
    ctx.fillRect(0, 0, w, h);
    ctx.restore();
  }

  /**
   * A BANK, not a disc.
   * ⛔ THE FIRST VERSION CLIPPED THE SHOAL PLATE TO `ctx.arc` AND THE RESULT WAS FOUR PERFECT PALE
   * CIRCLES SITTING ON THE SEA. On the title screen two of them read as rendering artefacts — pale
   * bubbles with a hard edge and no explanation — and on the chart they were larger than the islands
   * and dominated the picture. Nothing mechanical could see it; it was found by opening the
   * screenshot.
   *
   * A sand bank has an irregular outline and no edge at all: it shoals gradually. So the shape is a
   * two-harmonic radial wobble (the same idea as the coastlines, one octave lower), and it is drawn
   * as TWO rings — a broad soft one and a brighter core — with a dotted bound in chart ink, which is
   * how a chart actually marks drying ground.
   */
  function shoalPatch(cx, cy, r, seed) {
    if (!plates.shoal) return;
    var pts = [], i, n = 72;
    for (i = 0; i < n; i++) {
      var th = i / n * Math.PI * 2;
      var rr = r * (1 + 0.17 * Math.sin(3 * th + seed) + 0.11 * Math.sin(5 * th + seed * 1.7)
                      + 0.06 * Math.sin(8 * th + seed * 2.3));
      pts.push([cx + Math.cos(th) * rr, cy + Math.sin(th) * rr]);
    }
    var pathOf = function (scale) {
      ctx.beginPath();
      for (var k = 0; k < pts.length; k++) {
        var px2 = cx + (pts[k][0] - cx) * scale, py2 = cy + (pts[k][1] - cy) * scale;
        if (k === 0) ctx.moveTo(px2, py2); else ctx.lineTo(px2, py2);
      }
      ctx.closePath();
    };
    /* the outer, barely-there fringe */
    ctx.save(); pathOf(1); ctx.clip(); ctx.globalAlpha = 0.30;
    ctx.fillStyle = plates.shoal.pattern;
    ctx.translate(cx - r * 1.3, cy - r * 1.3); ctx.fillRect(0, 0, r * 2.6, r * 2.6);
    ctx.restore();
    /* the bank proper */
    ctx.save(); pathOf(0.72); ctx.clip(); ctx.globalAlpha = 0.52;
    ctx.fillStyle = plates.shoal.pattern;
    ctx.translate(cx - r * 1.3, cy - r * 1.3); ctx.fillRect(0, 0, r * 2.6, r * 2.6);
    ctx.restore();
    /* the drying head */
    ctx.save(); pathOf(0.40); ctx.clip(); ctx.globalAlpha = 0.72;
    ctx.fillStyle = plates.shoal.pattern;
    ctx.translate(cx - r * 1.3, cy - r * 1.3); ctx.fillRect(0, 0, r * 2.6, r * 2.6);
    ctx.restore();
    /* the chart's own dotted bound */
    ctx.save();
    ctx.strokeStyle = 'rgba(36,26,17,0.42)'; ctx.lineWidth = 1; ctx.setLineDash([2, 5]);
    pathOf(0.86); ctx.stroke();
    ctx.restore();
  }

  function rect(x, y, w, h, fill) { ctx.fillStyle = fill; ctx.fillRect(x, y, w, h); }
  function strokeRect(x, y, w, h, stroke, width) {
    ctx.save(); ctx.strokeStyle = stroke; ctx.lineWidth = width || 1;
    ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1); ctx.restore();
  }
  function line(x0, y0, x1, y1, stroke, width, dash, dashOffset) {
    ctx.save(); ctx.strokeStyle = stroke; ctx.lineWidth = width || 1;
    if (dash) { ctx.setLineDash(dash); ctx.lineDashOffset = dashOffset || 0; }
    ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); ctx.restore();
  }
  /** A polyline through world-space points already converted to screen. */
  function poly(pts, stroke, width, dash, dashOffset, alpha) {
    if (pts.length < 2) return;
    ctx.save();
    if (alpha !== undefined) ctx.globalAlpha = alpha;
    ctx.strokeStyle = stroke; ctx.lineWidth = width || 1;
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    if (dash) { ctx.setLineDash(dash); ctx.lineDashOffset = dashOffset || 0; }
    ctx.beginPath();
    ctx.moveTo(pts[0].x, pts[0].y);
    for (var i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
    ctx.stroke();
    ctx.restore();
  }
  function wash(x, y, w, h, top, bottom) {
    var g = ctx.createLinearGradient(0, y, 0, y + h);
    g.addColorStop(0, top); g.addColorStop(1, bottom);
    ctx.fillStyle = g; ctx.fillRect(x, y, w, h);
  }
  function glow(cx, cy, r, colour, alpha) {
    var g = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
    g.addColorStop(0, colour); g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.save(); if (alpha !== undefined) ctx.globalAlpha = alpha;
    ctx.fillStyle = g; ctx.fillRect(cx - r, cy - r, r * 2, r * 2); ctx.restore();
  }

  /**
   * A sheet of chart paper with a torn deckle edge — the panel every non-chart screen sits on.
   * ⚠️ The deckle is derived from a hash of the y position so it is stable frame to frame; a
   * randomised edge shimmers and reads as a rendering fault.
   */
  function sheet(x, y, w, h) {
    ctx.save();
    ctx.beginPath();
    var i;
    for (i = 0; i <= h; i += 4) {
      var d = ((Math.sin(i * 0.31) + Math.sin(i * 0.13 + 1.7)) * 1.6);
      if (i === 0) ctx.moveTo(x + d, y + i); else ctx.lineTo(x + d, y + i);
    }
    for (i = 0; i <= w; i += 4) ctx.lineTo(x + i, y + h + (Math.sin(i * 0.27 + 0.5) * 1.6));
    for (i = h; i >= 0; i -= 4) ctx.lineTo(x + w + (Math.sin(i * 0.21 + 2.3) * 1.6), y + i);
    for (i = w; i >= 0; i -= 4) ctx.lineTo(x + i, y + (Math.sin(i * 0.19 + 4.1) * 1.6));
    ctx.closePath();
    ctx.save(); ctx.clip();
    plate('chart', x - 8, y - 8, w + 16, h + 16);
    ctx.restore();
    ctx.strokeStyle = 'rgba(36,26,17,0.45)'; ctx.lineWidth = 1; ctx.stroke();
    ctx.restore();
  }

  /* ------------------------------------------------------------------ type
   * ⛔ `API.text` IS THE ONLY PLACE A STRING REACHES THE CANVAS.
   */
  function text(str, x, y, o) {
    o = o || {};
    var size = o.size || 15;
    var weight = o.weight || '';
    ctx.save();
    ctx.font = (weight ? weight + ' ' : '') + size + 'px ' + FONT;
    ctx.fillStyle = o.fill || INK.ink;
    if (o.alpha !== undefined) ctx.globalAlpha = o.alpha;
    ctx.textAlign = o.align || 'left';
    if (o.track) {
      var total = 0, i;
      for (i = 0; i < str.length; i++) total += ctx.measureText(str[i]).width + o.track;
      total -= o.track;
      var cx = o.align === 'center' ? x - total / 2 : (o.align === 'right' ? x - total : x);
      ctx.textAlign = 'left';
      for (i = 0; i < str.length; i++) {
        ctx.fillText(str[i], cx, y);
        cx += ctx.measureText(str[i]).width + o.track;
      }
      ctx.restore();
      return total;
    }
    ctx.fillText(str, x, y);
    var w = ctx.measureText(str).width;
    ctx.restore();
    return w;
  }

  function measure(str, o) {
    o = o || {};
    ctx.save();
    ctx.font = ((o.weight ? o.weight + ' ' : '')) + (o.size || 15) + 'px ' + FONT;
    var w = ctx.measureText(str).width;
    if (o.track) w += o.track * Math.max(0, String(str).length - 1);
    ctx.restore();
    return w;
  }

  /** ⛔ CANVAS TEXT DOES NOT WRAP, DOES NOT REFLOW AND DOES NOT CLIP (wing §3e-1). */
  function wrap(str, maxWidth, o) {
    var words = String(str).split(/\s+/);
    var lines = [], cur = '';
    for (var i = 0; i < words.length; i++) {
      var probe = cur ? cur + ' ' + words[i] : words[i];
      if (cur && measure(probe, o) > maxWidth) { lines.push(cur); cur = words[i]; }
      else cur = probe;
    }
    if (cur) lines.push(cur);
    return lines;
  }

  /**
   * ⛔ `paragraph` RESOLVES ALIGNMENT ITSELF rather than passing it through. Handing `align:'center'`
   * straight to `text` centres every line on the paragraph's LEFT EDGE, which puts a centred block
   * half a column to the left of where it was asked for, with no error anywhere. `x` is the LEFT
   * EDGE of the text box and the alignment happens inside it.
   */
  function paragraph(str, x, y, maxWidth, o) {
    o = o || {};
    var lh = o.lineHeight || Math.round((o.size || 15) * 1.45);
    var lines = wrap(str, maxWidth, o);
    var align = o.align || 'left';
    var ax = align === 'center' ? x + maxWidth / 2 : (align === 'right' ? x + maxWidth : x);
    for (var i = 0; i < lines.length; i++) API.text(lines[i], ax, y + i * lh, o);
    return lines.length * lh;
  }
  function paragraphHeight(str, maxWidth, o) {
    o = o || {};
    return wrap(str, maxWidth, o).length * (o.lineHeight || Math.round((o.size || 15) * 1.45));
  }

  /* ------------------------------------------------------------------ controls
   * ⛔ A BUTTON IS RECORDED AS A RECT **AND** A LABEL (wing §3e-3): the layout gate was green on a
   * screen whose controls line had orphaned a word onto a button's top border, because nothing in
   * the gate modelled controls at all.
   */
  var hot = [];
  function beginFrame() { hot.length = 0; }
  function button(label, x, y, w, h, o) {
    o = o || {};
    var enabled = o.enabled !== false;
    ctx.save();
    ctx.globalAlpha = enabled ? 1 : 0.40;
    ctx.beginPath(); ctx.rect(x, y, w, h); ctx.save(); ctx.clip();
    plate('brass', x - 3, y - 3, w + 6, h + 6);
    ctx.restore();
    ctx.strokeStyle = o.on ? INK.lampHot : 'rgba(36,26,17,0.75)';
    ctx.lineWidth = o.on ? 2 : 1;
    ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
    ctx.restore();
    /* ⛔ A LABEL MUST FIT ITS BUTTON, AND IT DID NOT. "BACK TO THE CHART" was drawn centred in a
     * 150px control and overhung it on both sides, printing onto the paper beside it — and the
     * layout gate could not see it, because a button LABEL is exempt from the string-inside-a-control
     * rule (or every control would fail forever). So the check belongs HERE, where the label and its
     * box are both in hand: give up the letter-spacing first, then the point size, and never draw a
     * label wider than the thing it names. */
    var lsize = o.size || 14;
    var ltrack = o.track === undefined ? 1.4 : o.track;
    var room = w - 14;
    while (ltrack > 0 && measure(label, { size: lsize, track: ltrack }) > room) ltrack = Math.max(0, ltrack - 0.35);
    while (lsize > 9 && measure(label, { size: lsize, track: ltrack }) > room) lsize -= 1;
    API.text(label, x + w / 2, y + h / 2 + lsize * 0.36, {
      size: lsize, align: 'center',
      fill: o.ink || (o.on ? INK.lampHot : INK.paperLit),
      track: ltrack,
      alpha: enabled ? 1 : 0.5, isButtonLabel: true
    });
    if (enabled && o.id) hot.push({ id: o.id, x: x, y: y, w: w, h: h, arg: o.arg });
    API._buttonRect(label, x, y, w, h);
    return { x: x, y: y, w: w, h: h };
  }
  function hitTest(mx, my) {
    for (var i = hot.length - 1; i >= 0; i--) {
      var b = hot[i];
      if (mx >= b.x && mx <= b.x + b.w && my >= b.y && my <= b.y + b.h) return b;
    }
    return null;
  }
  function zone(id, x, y, w, h, arg) { hot.push({ id: id, x: x, y: y, w: w, h: h, arg: arg }); }

  /* ------------------------------------------------------------------ the generated art */

  /** One island, from the sheet, at 1:1. `x`/`y` are its CENTRE. */
  function island(idx, supplied, cx, cy) {
    var s = sheets.islands;
    if (!s) return 0;
    var cw = s.meta.cw, ch = s.meta.ch;
    var sx = idx * cw, sy = supplied ? ch : 0;
    var dx = Math.round(cx - cw / 2), dy = Math.round(cy - ch / 2);
    ctx.drawImage(s.img, sx, sy, cw, ch, dx, dy, cw, ch);
    API._artRect('island:' + idx + (supplied ? ':supplied' : ':wanting'), dx, dy, cw, ch);
    return cw;
  }
  function islandCell() { return sheets.islands ? sheets.islands.meta.cw : 0; }

  /** A chart mark, scaled from its 32px cell. `size` is the drawn height. */
  function mark(id, x, y, size, alpha) {
    var s = sheets.marks;
    if (!s) return 0;
    var i = s.meta.order.indexOf(id);
    if (i < 0) return 0;
    var cw = s.meta.cw, ch = s.meta.ch;
    var w = Math.round(size * (cw / ch));
    ctx.save();
    if (alpha !== undefined) ctx.globalAlpha = alpha;
    ctx.drawImage(s.img, i * cw, 0, cw, ch, Math.round(x), Math.round(y), w, Math.round(size));
    ctx.restore();
    API._artRect('mark:' + id, x, y, w, size);
    return w;
  }
  function markIds() { return sheets.marks ? sheets.marks.meta.order.slice() : []; }

  /** The boat, on one of eight headings. `k` is 0..7 with 0 = north. */
  function boat(k, cx, cy) {
    var s = sheets.boat;
    if (!s) return 0;
    var cw = s.meta.cw, ch = s.meta.ch;
    var i = ((k % 8) + 8) % 8;
    var dx = Math.round(cx - cw / 2), dy = Math.round(cy - ch / 2);
    ctx.drawImage(s.img, i * cw, 0, cw, ch, dx, dy, cw, ch);
    API._artRect('boat:' + i, dx, dy, cw, ch);
    return cw;
  }
  /** Which of the eight cells a heading vector wants. 0 = north, clockwise. */
  function headingCell(dx, dy) {
    var a = Math.atan2(dx, -dy);                 // 0 = north, +clockwise
    return Math.round(a / (Math.PI / 4) + 8) % 8;
  }

  function sheetMeta(name) { return sheets[name] ? sheets[name].meta : null; }

  var API = {
    INK: INK, FONT: FONT, PLATE_NAMES: PLATE_NAMES,
    init: init, loadAll: loadAll, isLoaded: isLoaded,
    plate: plate, shoalPatch: shoalPatch, rect: rect, strokeRect: strokeRect,
    line: line, poly: poly, wash: wash, glow: glow, sheet: sheet,
    text: text, measure: measure, wrap: wrap, paragraph: paragraph, paragraphHeight: paragraphHeight,
    button: button, hitTest: hitTest, zone: zone, beginFrame: beginFrame,
    island: island, islandCell: islandCell, mark: mark, markIds: markIds,
    boat: boat, headingCell: headingCell, sheetMeta: sheetMeta,
    ctx: function () { return ctx; }, size: function () { return { w: W, h: H }; },
    /* hooks the layout gate replaces; no-ops in the shipped game.
     * ⛔ `_artRect` exists because a gate that only records strings can only find string bugs — one
     * wing shipped eight silhouettes piled into an unreadable mass under a clean layout gate. */
    _buttonRect: function () {},
    _artRect: function () {}
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  else root.ART = API;
})(typeof window !== 'undefined' ? window : globalThis);
