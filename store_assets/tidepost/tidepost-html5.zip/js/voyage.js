/**
 * voyage.js — TIDEPOST's second, third and fourth systems: the islands, what they need,
 * what they give back, and how far a boat can go before it runs out of bread.
 *
 * THE INTERLOCK, which is the whole of Gate 4 (wing CLAUDE.md §2, ledger B5):
 *
 *     the CURRENT decides which islands you can reach and at what cost
 *     the ISLANDS you keep supplied refill your STORES, so the network you build IS your range
 *     the GOODS each island wants decide the ORDER you visit them in
 *     the GEAR you earn changes which currents you can use and which SHOALS you can cross
 *
 * Four systems, and every one of them reads the other three. Progress MOVES THE MAP rather than
 * raising a number: there is no damage stat, no combat, and the only resource that matters is the
 * watch.
 *
 * ⛔ NOTHING IS EVER LOST. There is no failure state, no cargo is destroyed, and an island's supply
 * decays toward "wanting" but never toward "ruined" — once you have made an island whole its floor
 * is permanently higher than an island you never visited. Running your stores out does not end a
 * voyage; it puts the crew on short commons and the rest of that leg takes twice as long. Wing
 * CLAUDE.md's standing rule is save/resume rather than restart; this game is stronger than the rule
 * because there is nothing to resume FROM. That is also the jam's own design brief ("uplifting")
 * answered structurally rather than by tone.
 *
 * Deterministic given a seed. Runs unchanged in node (the headless probes) and in the browser.
 */
'use strict';

(function (root, factory) {
  const api = factory(typeof module === 'object' && module.exports
    ? require('./current.js')
    : root.CURRENT);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.VOYAGE = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (C) {

  /* ── the goods ──────────────────────────────────────────────────────────────────────────────
   * Six trade goods plus the mail. The mail is carried everywhere and always welcome; a good is
   * welcome only where it is WANTED, which is what makes the archipelago a route problem rather
   * than a list of destinations.
   */
  const GOODS = {
    LETTERS: { id: 'LETTERS', name: 'letters',  short: 'LTR' },
    SEED:    { id: 'SEED',    name: 'seed corn', short: 'SED' },
    OIL:     { id: 'OIL',     name: 'lamp oil',  short: 'OIL' },
    PHYSIC:  { id: 'PHYSIC',  name: 'physic',    short: 'PHY' },
    TIMBER:  { id: 'TIMBER',  name: 'timber',    short: 'TMB' },
    SALT:    { id: 'SALT',    name: 'salt',      short: 'SLT' },
    IRON:    { id: 'IRON',    name: 'iron',      short: 'IRN' }
  };
  const GOOD_ORDER = ['LETTERS', 'SEED', 'OIL', 'PHYSIC', 'TIMBER', 'SALT', 'IRON'];

  /**
   * The nine. `produces` is what you may take on here; `wants` is what lifts this island most.
   * The graph is deliberately NOT a ring — two islands want iron and two produce oil — so there
   * are several good routes rather than one correct one.
   */
  const ISLANDS = [
    { id: 'HOLM',       x: 12, y: 12, home: true, produces: 'LETTERS', wants: null,
      blurb: 'The post. Every sack starts here and the harbourmaster never sleeps.' },
    { id: 'SCARP',      x: 44, y: 8,  produces: 'IRON',   wants: 'SEED',
      blurb: 'A quarry town on a north-facing cliff. Iron enough, soil for nothing.' },
    { id: 'THE NEEDLE', x: 80, y: 16, produces: 'SALT',   wants: 'TIMBER',
      blurb: 'Salt pans and no trees at all. Everything here is propped with driftwood.' },
    { id: 'COLDHAVEN',  x: 24, y: 34, produces: 'TIMBER', wants: 'PHYSIC',
      blurb: 'Pine to the waterline. Damp gets into the children every winter.' },
    { id: 'MARROW',     x: 58, y: 32, produces: 'PHYSIC', wants: 'OIL',
      blurb: 'An old infirmary island. They can cure anything and cannot see after four.' },
    { id: 'LOW SKERRY', x: 88, y: 38, produces: 'OIL',    wants: 'IRON',
      blurb: 'Oil rendered on the rocks. Their tools are worn down to handles.' },
    { id: 'BELL ROCK',  x: 18, y: 54, produces: 'SEED',   wants: 'SALT',
      blurb: 'Good ground, a bell that fogs, and nothing to keep a catch in.' },
    { id: 'TERN',       x: 52, y: 56, produces: 'SEED',   wants: 'IRON',
      blurb: 'Terraces and thin walls. They break a blade a week on the terrace stone.' },
    { id: 'THE SOUND',  x: 82, y: 58, produces: 'OIL',    wants: 'TIMBER',
      blurb: 'A drowned village rebuilding itself one rafter at a time.' }
  ];

  /**
   * SHOALS — banks of shallow, broken water. They are the third thing the sea does to you: a shoal
   * costs SHOAL_PENALTY times as long to cross, so the fair current running straight through one is
   * a trap, and a pilot who knows the bank turns the same water into the short way home.
   *
   * ⚠️ These are placed ON the fast water between island pairs on purpose. A hazard nobody would
   * ever have sailed through is not a hazard, it is scenery.
   */
  const SHOALS = [
    { id: 'THE GRINDSTONE', x: 33, y: 20, r: 8 },
    { id: 'WRACK BANK',     x: 68, y: 24, r: 9 },
    { id: 'THE PARLOUR',    x: 40, y: 44, r: 7 },
    { id: 'SEVEN FEET',     x: 74, y: 47, r: 8 }
  ];
  const SHOAL_PENALTY = 2.4;      // times as long, without a pilot's eye
  const PILOT_PENALTY = 1.15;     // with one: still shallow, no longer a wall

  /**
   * Gear. Each entry changes HOW THE WATER IS USED, never a damage number.
   *   own    — speed through the water
   *   grip   — how much of an adverse current the boat refuses
   *   stores — watches of provisions the boat can carry
   *   hold   — parcels carried at once
   *   pilot  — knows the banks: shoals stop being walls
   * `cost` is in goodwill, which is what supplied islands give back.
   */
  const GEAR = [
    { id: 'deep-keel',       name: 'A deeper keel',       cost: 3,  own: 0.10, grip: 0.10, stores: 0,  hold: 0, pilot: false,
      note: 'Holds a line the water is trying to take away from you.' },
    { id: 'new-suit',        name: 'A new suit of sails', cost: 5,  own: 0.25, grip: 0.00, stores: 0,  hold: 0, pilot: false,
      note: 'Plain speed. Never the wrong answer, never the clever one.' },
    { id: 'deck-stores',     name: 'Deck stores',         cost: 8,  own: 0.00, grip: 0.00, stores: 34, hold: 1, pilot: false,
      note: 'Bread and water for longer legs, and one more parcel under the tarpaulin.' },
    { id: 'gaff-cut',        name: 'A gaff cut',          cost: 12, own: 0.10, grip: 0.22, stores: 0,  hold: 0, pilot: false,
      note: 'Bites into water that is trying to set you down to leeward.' },
    /* ⚠️ RENAMED from "Long stowage" after the campaign probe read the table back: there was no
     * cargo system at all when it was written, so a piece of gear called stowage promised the
     * player something the code did not do. There IS a hold now — and this item still does not
     * touch it, so the name stays honest about speed and stores. */
    { id: 'trimmed-ballast', name: 'Ballast trimmed',     cost: 16, own: 0.18, grip: 0.10, stores: 18, hold: 0, pilot: false,
      note: 'She sits lower and carries her way through the slack.' },
    { id: 'pilot-eye',       name: "A pilot's eye",       cost: 22, own: 0.05, grip: 0.30, stores: 0,  hold: 1, pilot: true,
      note: 'The banks stop being walls. Every shoal on the chart becomes a short cut.' }
  ];

  const BASE_SPEED         = 1.0;
  const BASE_STORES        = 62;    // watches of provisions
  const BASE_HOLD          = 2;     // parcels
  const WATCHES_PER_SEASON = 150;
  const SEASONS_IN_VOYAGE  = 8;     // two years
  const SUPPLIED_AT        = 0.75;
  const SHORT_COMMONS      = 2.0;   // out of stores: the rest of the leg takes this much longer

  /* ── state ──────────────────────────────────────────────────────────────────────────────── */

  function newState(seed) {
    return {
      v: 1,
      seed: (seed >>> 0) || 1,
      watch: 0,
      season: 0,
      at: 0,                                  // index into ISLANDS; start at home
      goodwill: 0,
      owned: [],
      /* ⛔ THE MAIL IS NOT IN THE HOLD, AND THAT IS A DESIGN CORRECTION THE CAMPAIGN PROBE FORCED.
       * When letters were a parcel you loaded at HOLM, a competent policy sailed 69 legs and landed
       * something on only a handful of them: the hold was empty for most of the voyage and a
       * landfall did nothing at all. A leg that lands nothing is a wasted leg, and a game whose
       * ordinary move is wasted is not a game. You are the post boat — the sack is inexhaustible,
       * letters are always aboard and always welcome, and they are the FLOOR of the game. The hold
       * carries trade goods only, which is where the routing decision actually lives. */
      hold: [],
      stores: BASE_STORES,
      /* supply[i] in [0,1]. Everyone starts wanting. */
      supply: ISLANDS.map((i) => (i.home ? 0.7 : 0.15)),
      supplied: [],                           // islands that have crossed the threshold at least once
      beacons: [],                            // islands that keep themselves now
      mailLanded: false,                      // the sack for THIS landfall
      shortCommons: 0,                        // watches spent on short commons, all voyage
      landfalls: 0,
      delivered: 0,                           // wanted goods landed where they were wanted
      log: []
    };
  }

  const gearOf = (id) => GEAR.find((g) => g.id === id);
  function sum(st, key) {
    let v = 0;
    for (const g of GEAR) if (st.owned.indexOf(g.id) >= 0) v += g[key];
    return v;
  }

  function ownSpeed(st)  { return BASE_SPEED + sum(st, 'own'); }
  function storesMax(st) { return BASE_STORES + sum(st, 'stores'); }
  function holdMax(st)   { return BASE_HOLD + sum(st, 'hold'); }
  function hasPilot(st)  { return st.owned.indexOf('pilot-eye') >= 0; }

  /**
   * `grip` is how much of an adverse current the boat can refuse — a keel and a pilot's eye both
   * mean the water pushes you off your line less. It is applied by softening the NEGATIVE part of
   * the along-track current ONLY, so gear can never make a fair current worse.
   */
  function grip(st) { return Math.min(0.85, sum(st, 'grip')); }

  /** Is this point inside a shoal? Returns the shoal or null. */
  function shoalAt(x, y) {
    for (const s of SHOALS) {
      const dx = x - s.x, dy = y - s.y;
      if (dx * dx + dy * dy <= s.r * s.r) return s;
    }
    return null;
  }
  function shoalFactor(st, x, y) {
    if (!shoalAt(x, y)) return 1;
    return hasPilot(st) ? PILOT_PENALTY : SHOAL_PENALTY;
  }

  /** Speed made good along a unit heading, after gear, before the shoal penalty. */
  function madeGood(st, x, y, dx, dy) {
    const c = C.at(x, y, st.season);
    let along = c.u * dx + c.v * dy;
    if (along < 0) along *= (1 - grip(st));
    return Math.max(0.06, ownSpeed(st) + along);
  }

  const NB = [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];

  /* A binary heap. Written out rather than sorted because this runs 9 times a season in the game
   * and about 3,000 times in the campaign probe. */
  function makeHeap() {
    const h = [];
    return {
      size: () => h.length,
      push(d, i) {
        h.push([d, i]); let c = h.length - 1;
        while (c > 0) { const p = (c - 1) >> 1; if (h[p][0] <= h[c][0]) break;
          const t = h[p]; h[p] = h[c]; h[c] = t; c = p; }
      },
      pop() {
        const top = h[0], last = h.pop();
        if (h.length) {
          h[0] = last; let p = 0;
          for (;;) {
            const l = 2 * p + 1, r = l + 1; let m = p;
            if (l < h.length && h[l][0] < h[m][0]) m = l;
            if (r < h.length && h[r][0] < h[m][0]) m = r;
            if (m === p) break;
            const t = h[m]; h[m] = h[p]; h[p] = t; p = m;
          }
        }
        return top;
      }
    };
  }

  /**
   * ONE Dijkstra from an island gives the time to EVERY other island, and the path to each.
   *
   * ⚠️ It is one search, not nine. The first version of this ran a separate search per destination,
   * which is the same answer at nine times the cost and would have made the chart unusable on a
   * phone. The predecessor array is kept because the drawn route — the line that visibly BENDS
   * around a foul gyre — is the clearest statement the game makes about what the sea is doing.
   */
  function solveFrom(st, fromIdx) {
    const W = C.WORLD.w, H = C.WORLD.h, N = W * H;
    const dist = new Float64Array(N).fill(Infinity);
    const prev = new Int32Array(N).fill(-1);
    const done = new Uint8Array(N);
    const heap = makeHeap();
    const from = ISLANDS[fromIdx];
    const s = from.y * W + from.x;
    dist[s] = 0; heap.push(0, s);

    while (heap.size()) {
      const [d, i] = heap.pop();
      if (done[i]) continue;
      done[i] = 1;
      const x = i % W, y = (i / W) | 0;
      for (let k = 0; k < NB.length; k++) {
        const ox = NB[k][0], oy = NB[k][1];
        const nx = x + ox, ny = y + oy;
        if (!C.inBounds(nx, ny)) continue;
        const j = ny * W + nx;
        if (done[j]) continue;
        const len = ox && oy ? Math.SQRT2 : 1;
        const mx = x + ox / 2, my = y + oy / 2;
        const v = madeGood(st, mx, my, ox / len, oy / len);
        const nd = d + (len / v) * shoalFactor(st, mx, my);
        if (nd < dist[j]) { dist[j] = nd; prev[j] = i; heap.push(nd, j); }
      }
    }

    const costs = ISLANDS.map((isl) => dist[isl.y * W + isl.x]);
    return { dist, prev, costs, W, H };
  }

  /** The least-time track between two islands, as world points, from a solved field. */
  function pathFrom(sol, toIdx) {
    const to = ISLANDS[toIdx];
    const W = sol.W;
    const out = [];
    let i = to.y * W + to.x;
    let guard = 0;
    while (i >= 0 && guard++ < 100000) {
      out.push({ x: i % W, y: (i / W) | 0 });
      i = sol.prev[i];
    }
    out.reverse();
    return out;
  }

  /** Watches to sail from one island to another. Kept for the probes and for one-off questions. */
  function crossing(st, fromIdx, toIdx) {
    return solveFrom(st, fromIdx).costs[toIdx];
  }

  /**
   * What a leg will actually cost, INCLUDING short commons. This is the number the chart shows,
   * because a number that hides the penalty is a number that lies to the player at exactly the
   * moment the decision is made.
   */
  function legCost(st, sailTime) {
    if (!isFinite(sailTime)) return { watches: Infinity, onStores: 0, short: 0 };
    const onStores = Math.min(sailTime, st.stores);
    const beyond = Math.max(0, sailTime - st.stores);
    return { watches: onStores + beyond * SHORT_COMMONS, onStores, short: beyond };
  }

  /* ── the acts ───────────────────────────────────────────────────────────────────────────── */

  /** Take on this island's produce, if there is room. Letters are never a parcel. */
  function load(st, goodId) {
    const isl = ISLANDS[st.at];
    if (goodId === 'LETTERS' || goodId !== isl.produces) return false;
    if (st.hold.length >= holdMax(st)) return false;
    st.hold.push(goodId);
    st.log.push({ w: Math.round(st.watch), t: `took on ${GOODS[goodId].name} at ${isl.id}` });
    return true;
  }

  /** Put a parcel back ashore without landing it as a delivery — always allowed, never punished. */
  function unload(st, goodId) {
    const i = st.hold.indexOf(goodId);
    if (i < 0) return false;
    st.hold.splice(i, 1);
    return true;
  }

  /**
   * Land what this island wants. Returns what happened, so the game can say it out loud.
   * ⚠️ Letters always land. That is the floor of the game: a leg is never wasted.
   */
  function deliver(st, goodId) {
    const idx = st.at;
    const isl = ISLANDS[idx];
    const isMail = goodId === 'LETTERS';
    const i = st.hold.indexOf(goodId);
    if (!isMail && i < 0) return null;
    const wanted = isl.wants === goodId;
    if (!wanted && !isMail) return null;

    /* ⛔ ONE SACK PER LANDFALL, AND NO GOODWILL FOR LANDING MAIL SOMEWHERE THAT NEEDS NOTHING.
     * Without both of these, "letters are always aboard" is an infinite goodwill tap: land the
     * mail, land it again, buy the whole gear tree without leaving the quay. The watch is the only
     * real currency in this game and an exploit that does not spend it is not a strategy. */
    if (isMail) {
      if (st.mailLanded) return null;
      st.mailLanded = true;
    }

    if (!isMail) st.hold.splice(i, 1);
    const before = st.supply[idx];
    const lift = wanted ? 0.55 : 0.30;
    st.supply[idx] = Math.min(1, before + lift);

    let gained = wanted ? 3 : (before < SUPPLIED_AT ? 1 : 0);
    let firstTime = false;
    if (before < SUPPLIED_AT && st.supply[idx] >= SUPPLIED_AT && st.supplied.indexOf(idx) < 0) {
      st.supplied.push(idx);
      gained += 4;
      firstTime = true;
    }
    st.goodwill += gained;
    if (wanted) st.delivered++;
    st.log.push({
      w: Math.round(st.watch),
      t: `${isl.id}: ${GOODS[goodId].name} landed${firstTime ? ' — supplied' : ''} (+${gained})`
    });
    return { wanted, firstTime, gained, lift };
  }

  /**
   * Sail. Returns a record of the leg.
   * ⛔ The season is turned INSIDE this call, after the watches are spent, so a leg begun in high
   * summer is costed in high summer — the sea a player looked at is the sea they get.
   */
  function sailTo(st, toIdx, precomputedTime) {
    if (toIdx === st.at) return null;
    const t = precomputedTime === undefined ? crossing(st, st.at, toIdx) : precomputedTime;
    if (!isFinite(t)) return null;

    const leg = legCost(st, t);
    st.watch += leg.watches;
    st.shortCommons += leg.short * SHORT_COMMONS;
    st.stores = Math.max(0, st.stores - t);
    st.at = toIdx;
    st.landfalls++;
    st.mailLanded = false;

    /* Landfall: take on water and bread. A well-supplied island can fill you; a wanting one
     * gives what it can spare. THIS is the interlock — the network you build is your range. */
    const isl = ISLANDS[toIdx];
    const offered = (0.30 + 0.70 * st.supply[toIdx]) * storesMax(st);
    st.stores = Math.min(storesMax(st), Math.max(st.stores, offered));

    const turned = turnSeasonIfDue(st);
    st.log.push({
      w: Math.round(st.watch),
      t: `made ${isl.id} in ${Math.round(leg.watches)} watches` + (leg.short > 0 ? ' — short commons' : '')
    });
    return { watches: leg.watches, short: leg.short, turned, sail: t };
  }

  /**
   * The floor an island can never fall below. Three tiers, and each one is something the player
   * did: never reached · made whole once · given a beacon.
   * ⛔ THE BEACON FLOOR IS DELIBERATELY ABOVE `SUPPLIED_AT`. A beacon island stays supplied for the
   * rest of the voyage with no further visits — it is the permanent good you leave behind, and it
   * is the only thing in the game that removes work rather than adding it.
   */
  function floorOf(st, i) {
    if (st.beacons.indexOf(i) >= 0) return 0.78;
    if (st.supplied.indexOf(i) >= 0) return 0.40;
    return 0.10;
  }

  const DECAY = 0.45;   // each season, supply falls this fraction of the way to its floor

  function turnSeasonIfDue(st) {
    const shouldBe = Math.min(SEASONS_IN_VOYAGE, Math.floor(st.watch / WATCHES_PER_SEASON));
    if (shouldBe === st.season) return false;
    const from = st.season;
    st.season = Math.min(SEASONS_IN_VOYAGE - 1, shouldBe);
    /* ⛔ DECAY IS MULTIPLICATIVE TOWARD THE FLOOR, AND THE CAMPAIGN PROBE IS WHY. With a flat
     * -0.26 a season against a +0.30 sack of letters, an island visited every single season
     * converged to about 0.74 and NEVER crossed the 0.75 threshold: the game asymptotically
     * approached its own goal and could not reach it, so a voyage that supplied all nine islands
     * ended reporting ZERO standing. That is §3f's "wall with a date on it" in miniature and it
     * was invisible to every unit test.
     *
     * Multiplicative decay makes a well-kept island cheap to keep and a neglected one fall fast,
     * which is both the right feeling and a real gradient: visit every season and it stays near
     * full; every other season and it just holds; every third and it slips below. */
    const turns = Math.max(1, shouldBe - from);
    for (let i = 0; i < st.supply.length; i++) {
      const floor = floorOf(st, i);
      st.supply[i] = Math.max(floor, floor + (st.supply[i] - floor) * Math.pow(DECAY, turns));
    }
    return true;
  }

  /* ── beacons ────────────────────────────────────────────────────────────────────────────────
   * The goodwill sink for the back half. Without one, a competent voyage finished with 81 unspent
   * goodwill and nothing to want — §3f-1's warning that a player who never reaches the deepest
   * thing you built has played a smaller game, arriving as a currency with no shop.
   */
  const BEACON_BASE = 10, BEACON_STEP = 6;
  function beaconCost(st) { return BEACON_BASE + BEACON_STEP * st.beacons.length; }
  function canRaiseBeacon(st, i) {
    return st.beacons.indexOf(i) < 0
      && st.supply[i] >= SUPPLIED_AT
      && st.goodwill >= beaconCost(st);
  }
  function raiseBeacon(st, i) {
    if (!canRaiseBeacon(st, i)) return false;
    st.goodwill -= beaconCost(st);
    st.beacons.push(i);
    st.supply[i] = Math.max(st.supply[i], 0.85);
    st.log.push({ w: Math.round(st.watch), t: `a beacon lit on ${ISLANDS[i].id} — it keeps itself now` });
    return true;
  }

  function buyable(st) {
    return GEAR.filter((g) => st.owned.indexOf(g.id) < 0 && g.cost <= st.goodwill);
  }
  function affordable(st, id) {
    const g = gearOf(id);
    return !!g && st.owned.indexOf(id) < 0 && g.cost <= st.goodwill;
  }
  function buy(st, id) {
    const g = gearOf(id);
    if (!g || st.owned.indexOf(id) >= 0 || g.cost > st.goodwill) return false;
    st.goodwill -= g.cost;
    st.owned.push(id);
    /* New stores capacity is immediately useful, otherwise the purchase feels like nothing. */
    if (g.stores) st.stores = Math.min(storesMax(st), st.stores + g.stores);
    st.log.push({ w: Math.round(st.watch), t: `bought ${g.name}` });
    return true;
  }

  const done = (st) => st.watch >= WATCHES_PER_SEASON * SEASONS_IN_VOYAGE;

  /**
   * The ending. ⛔ EVERY RANK IS A GOOD ONE. The jam brief is "uplifting" and this wing's answer to
   * it is structural: the voyage cannot be failed, so the ending measures how much of the
   * archipelago is standing rather than whether you won. The worst honest outcome is a coast where
   * a few islands were kept, and that is still a coast that was kept.
   */
  const RANKS = [
    { at: 0,  title: 'THE FIRST ROUND', line: 'You learned the water, and the water is not a small thing to learn. The islands remember a boat that came at all.' },
    { at: 22, title: 'A KNOWN SAIL',    line: 'They watch for you now. There is bread on this coast because somebody kept turning up.' },
    { at: 44, title: 'THE POST ROAD',   line: 'A route exists where there was open water. Others will sail it, and they will not know they are following you.' },
    /* ⛔ THE TOP RANK USED TO SAY "nine islands standing" AND THE PROBE ENDED ON FOUR. A rank line
     * is a sentence the game makes about the run it just watched, and §3f-2's rule binds it exactly
     * as hard as a store page: it must describe what was actually measured. The ending screen
     * prints the real standing and beacon counts beside it. */
    { at: 66, title: 'THE LIT COAST',   line: 'Two years of weather, and this coast is better than you found it. There are lights burning out there that you put up.' }
  ];
  function score(st) {
    const standing = st.supply.filter((s) => s >= SUPPLIED_AT).length;
    const everSupplied = st.supplied.length;
    const points = standing * 3 + everSupplied * 2 + st.delivered + st.beacons.length * 3;
    let rank = RANKS[0];
    for (const r of RANKS) if (points >= r.at) rank = r;
    return { standing, everSupplied, delivered: st.delivered, landfalls: st.landfalls,
             goodwill: st.goodwill, gear: st.owned.length, beacons: st.beacons.length,
             points, rank };
  }

  return {
    GOODS, GOOD_ORDER, ISLANDS, SHOALS, GEAR, RANKS,
    BASE_SPEED, BASE_STORES, BASE_HOLD, WATCHES_PER_SEASON, SEASONS_IN_VOYAGE, SUPPLIED_AT,
    SHOAL_PENALTY, PILOT_PENALTY, SHORT_COMMONS,
    newState, ownSpeed, storesMax, holdMax, hasPilot, grip,
    shoalAt, shoalFactor, madeGood, solveFrom, pathFrom, crossing, legCost,
    load, unload, deliver, sailTo, turnSeasonIfDue, floorOf,
    beaconCost, canRaiseBeacon, raiseBeacon, BEACON_BASE, BEACON_STEP, DECAY,
    buyable, affordable, buy, done, score
  };
});
