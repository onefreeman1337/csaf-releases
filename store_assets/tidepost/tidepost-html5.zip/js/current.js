/**
 * current.js — TIDEPOST's ocean.
 *
 * THE ONE IDEA: the sea is a STREAM FUNCTION, not a pile of arrows.
 *
 * A scalar field psi(x, y, season) is defined over the world, and the current is its
 * perpendicular gradient:
 *
 *     u =  d(psi)/dy        v = -d(psi)/dx
 *
 * That is not decoration, it buys three things a hand-drawn vector field cannot:
 *
 *   1. IT IS DIVERGENCE FREE BY CONSTRUCTION. No cell is a source or a sink, so water
 *      never appears or vanishes and a drifting boat can never be sucked into a hole.
 *      Getting that right by hand-tuning arrows is impossible; here it is free.
 *   2. THE STREAMLINES ARE THE LEVEL SETS OF psi. A boat with no way on follows a contour
 *      of psi exactly. So the thing the player must learn to read IS a contour map, and the
 *      renderer can draw the true streamlines rather than an artist's impression of them
 *      (wing CLAUDE.md §0-ART: structure must be explicit, never noise thresholded into blobs).
 *   3. SEASONS ARE ONE NUMBER. Move the gyres and change their strengths and the whole field
 *      re-solves consistently, so "the same two islands are a different journey in a different
 *      season" is a property of the mathematics rather than a special case someone wrote.
 *
 * Deterministic: same seed and season give the same ocean, on any machine, forever. No RNG is
 * consulted at sample time.
 *
 * Runs unchanged in node (the headless probe) and in the browser (the game).
 */
'use strict';

(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.CURRENT = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {

  /* World is measured in leagues; one cell of the sample grid is one league. */
  const WORLD = { w: 96, h: 64 };

  /* Four seasons. Each names its own weather, and each moves the gyres. The names are the
   * calendar the player actually plays against, so they live with the physics. */
  const SEASONS = ['EARLY SUMMER', 'HIGH SUMMER', 'THE TURN', 'WINTER'];

  /* A gyre is a rotating cell of water: a gaussian bump in the stream function.
   * sign +1 turns one way, -1 the other. `drift` is how far it walks across the year,
   * `swell` how much its strength changes. Hand-authored, because a sea has a character
   * and noise does not have one. */
  const GYRES = [
    { x: 20, y: 18, r: 15, s: 1.00, sign: +1, drift: [7, 3], swell: 0.55 },
    { x: 62, y: 14, r: 17, s: 0.85, sign: -1, drift: [-5, 6], swell: 0.80 },
    { x: 34, y: 46, r: 19, s: 0.95, sign: -1, drift: [9, -4], swell: 0.40 },
    { x: 76, y: 45, r: 14, s: 0.70, sign: +1, drift: [-8, -5], swell: 1.15 },
    { x: 50, y: 30, r: 11, s: 0.45, sign: +1, drift: [3, 8], swell: 1.40 }
  ];

  /* The prevailing drift: a linear term in psi, so a constant broad current. Its BEARING
   * swings across the year, which is what makes a whole coast lee or weather in season. */
  const PREVAIL = { strength: 0.42, bearingAt: (t) => (Math.PI * 0.35) + t * Math.PI * 1.5 };

  const TAU = Math.PI * 2;

  /** Season phase in [0,1). Accepts an index 0..3 or a continuous value. */
  function phase(season) {
    const n = SEASONS.length;
    return ((season % n) + n) % n / n;
  }

  /** Where a gyre sits, and how strong it is, at this point in the year. */
  function gyreAt(g, t) {
    const a = t * TAU;
    return {
      x: g.x + g.drift[0] * Math.sin(a),
      y: g.y + g.drift[1] * Math.sin(a + 1.1),
      r: g.r,
      /* Strength never crosses zero: a gyre weakens and freshens, it does not reverse.
       * A reversing gyre reads as a bug to a player, not as weather. */
      s: g.s * (1 + g.swell * 0.5 * Math.sin(a + 0.7)) * g.sign
    };
  }

  /**
   * The stream function at a point.
   * psi = prevailing linear term + sum of gaussian gyres.
   */
  function psi(x, y, season) {
    const t = phase(season);
    const b = PREVAIL.bearingAt(t);
    /* A linear psi gives a uniform current perpendicular to its gradient. */
    let v = PREVAIL.strength * (x * Math.sin(b) - y * Math.cos(b));
    for (const raw of GYRES) {
      const g = gyreAt(raw, t);
      const dx = x - g.x, dy = y - g.y;
      const d2 = (dx * dx + dy * dy) / (g.r * g.r);
      v += g.s * g.r * 0.5 * Math.exp(-d2);
    }
    return v;
  }

  /**
   * The current vector at a point, as the perpendicular gradient of psi.
   * Central differences: cheap, and exact enough that the divergence stays at round-off.
   */
  function at(x, y, season) {
    const h = 0.35;
    const u = (psi(x, y + h, season) - psi(x, y - h, season)) / (2 * h);
    const v = -(psi(x + h, y, season) - psi(x - h, y, season)) / (2 * h);
    return { u, v };
  }

  /** Speed of the water at a point, in leagues per watch. */
  function speed(x, y, season) {
    const c = at(x, y, season);
    return Math.hypot(c.u, c.v);
  }

  /**
   * Effective speed made good when steering along a unit heading (dx, dy) from a point.
   *
   * The boat's own speed through the water plus the component of the current along the
   * heading. Clamped to a small positive floor: a boat pinned by a foul current does not
   * travel backwards along its intended leg, it simply takes a long time, and an
   * unclamped value here would make a route cost negative or infinite and quietly break
   * every search that uses it.
   */
  function madeGood(x, y, season, dx, dy, ownSpeed) {
    const c = at(x, y, season);
    return Math.max(0.06, ownSpeed + (c.u * dx + c.v * dy));
  }

  function inBounds(x, y) {
    return x >= 0 && y >= 0 && x < WORLD.w && y < WORLD.h;
  }

  return { WORLD, SEASONS, GYRES, psi, at, speed, madeGood, inBounds, phase, gyreAt };
});
