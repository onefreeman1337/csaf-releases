/**
 * TIDEPOST — game.js : the chart, the screens, and everything the player touches.
 *
 * ⛔ THE RULES OF THE HOUSE, all of them paid for by earlier titles in this wing:
 *   · every string on the canvas goes through `ART.text` (§3e-1) and every layout number is
 *     derived from `measureText` at draw time, never typed;
 *   · every button is drawn by `ART.button` so the layout gate can see its rect AND its label (§3e-3);
 *   · nothing is positioned against the bottom of the page (§3d) — the canvas is the whole product;
 *   · the game exposes `setPaused()` so a capture harness and the rAF loop are not two drivers on
 *     one clock (§3c-7);
 *   · save and resume, never restart (wing §2). There is no death here to resume from, but a closed
 *     tab is still a lost voyage, so the state is written to localStorage after every act.
 *
 * SCREENS: title · chart · landfall · chandlery · log · help · ending.
 */
(function (root) {
  'use strict';

  var C = root.CURRENT, V = root.VOYAGE, A = root.ART;

  var W = 960, H = 640;

  /* ── chart geometry ───────────────────────────────────────────────────────────────────────────
   * ⚠️ THE SCALE IS NOT FREE. `sheets.js` generates island sprites at the size they are blitted, so
   * SCALE and that file's `ISLE` move together: 8.0 px per league with an 80px island cell puts an
   * island at about four leagues' radius, drawn 1:1. Change one and change the other.
   *
   * ⛔ AND THE MESSAGE STRIP IS A PERMANENT BAND, NOT AN OVERLAY, BECAUSE THE OVERLAY COVERED AN
   * ISLAND. The first build floated the event message on a paper panel over the top of the chart,
   * and SCARP — which sits eight leagues from the top edge — was underneath it every time anything
   * happened. Nothing mechanical could catch that: the panel and the island are both perfectly
   * drawn, they are just in the same place. A chart has a title block for exactly this reason, so
   * the message now has a band of its own and the sea starts below it. */
  var TOP_H = 40;                       // the HUD
  var MSG_Y = TOP_H, MSG_H = 48;        // the message band
  var SCALE = 8.0;
  var CHART_W = C.WORLD.w * SCALE, CHART_H = C.WORLD.h * SCALE;
  var OX = Math.round((W - CHART_W) / 2), OY = MSG_Y + MSG_H;
  var BOT_Y = OY + CHART_H, BOT_H = H - BOT_Y;

  function sx(wx) { return OX + wx * SCALE; }
  function sy(wy) { return OY + wy * SCALE; }

  /* ── state ──────────────────────────────────────────────────────────────────────────────────── */

  var SAVE_KEY = 'tidepost.voyage.v1';        // ⚠️ namespaced: a shared origin has other games on it
  var MUTE_KEY = 'tidepost.mute.v1';

  var st = null;              // the voyage
  var screen = 'title';
  var sel = null;             // selected destination index
  var hover = null;           // hovered island index
  var sol = null, solKey = '';
  var streams = null, streamSeason = -1;
  var anim = null;            // { path, t, dur, dest, sailTime }
  var toast = null;           // { lines: [], t }
  var clock = 0;
  var paused = false;
  var logScroll = 0;
  var lastLanding = null;     // what happened at the last landfall, shown on the landfall screen

  /* ── audio ──────────────────────────────────────────────────────────────────────────────────
   * ⛔ Every cue is wrapped, because a browser that refuses autoplay must not take the game with
   * it — but §3c-12 records that this silence is BY DESIGN and therefore invisible, so
   * `verify_assets.js` drives the real build and asserts every file is actually requested.
   */
  var SFX_IDS = ['sail', 'land', 'deliver', 'buy', 'beacon', 'season', 'click', 'end'];
  var sfx = {}, music = null, muted = false;

  function loadAudio() {
    try { muted = localStorage.getItem(MUTE_KEY) === '1'; } catch (e) { muted = false; }
    for (var i = 0; i < SFX_IDS.length; i++) {
      var a = new Audio('audio/sfx_' + SFX_IDS[i] + '.ogg');
      a.preload = 'auto'; a.volume = 0.55;
      sfx[SFX_IDS[i]] = a;
    }
    music = new Audio('audio/theme.ogg');
    music.loop = true; music.volume = 0.34; music.preload = 'auto';
  }
  function play(id) {
    if (muted || !sfx[id]) return;
    try { sfx[id].currentTime = 0; var p = sfx[id].play(); if (p && p.catch) p.catch(function () {}); }
    catch (e) { /* a refused cue is never allowed to stop the game */ }
  }
  function musicOn() {
    if (muted || !music) return;
    try { var p = music.play(); if (p && p.catch) p.catch(function () {}); } catch (e) {}
  }
  function toggleMute() {
    muted = !muted;
    try { localStorage.setItem(MUTE_KEY, muted ? '1' : '0'); } catch (e) {}
    if (muted && music) { try { music.pause(); } catch (e) {} } else musicOn();
  }

  /* ── save / resume ──────────────────────────────────────────────────────────────────────────── */

  function save() {
    if (!st) return;
    try { localStorage.setItem(SAVE_KEY, JSON.stringify(st)); } catch (e) {}
  }
  function loadSave() {
    try {
      var raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return null;
      var o = JSON.parse(raw);
      /* ⛔ A SAVE FROM AN OLDER BUILD IS NOT A CRASH, IT IS A NEW VOYAGE. Refusing to parse it and
       * throwing would strand a returning player on a black screen — the one failure state this
       * game is not allowed to have. */
      if (!o || o.v !== 1 || !Array.isArray(o.supply) || o.supply.length !== V.ISLANDS.length) return null;
      if (!Array.isArray(o.beacons)) o.beacons = [];
      if (!Array.isArray(o.hold)) o.hold = [];
      if (!Array.isArray(o.log)) o.log = [];
      return o;
    } catch (e) { return null; }
  }
  function hasSave() { return !!loadSave(); }
  function clearSave() { try { localStorage.removeItem(SAVE_KEY); } catch (e) {} }

  /* ── the solved field ───────────────────────────────────────────────────────────────────────── */

  function ensureSolved() {
    var key = st.at + '|' + st.season + '|' + st.owned.slice().sort().join(',');
    if (key === solKey && sol) return sol;
    sol = V.solveFrom(st, st.at);
    solKey = key;
    return sol;
  }

  /**
   * The streamlines: the TRUE level sets of the stream function, traced by integrating the current.
   * ⛔ This is the one thing in the game that must not be an artist's impression. `current.js` makes
   * the field divergence free, so these lines close on themselves and never converge into a sink —
   * which is exactly what makes the water readable rather than decorative.
   */
  function buildStreams(season) {
    var out = [];
    var stepLen = 0.85, steps = 74;
    for (var gy = 0; gy < 11; gy++) {
      for (var gx = 0; gx < 15; gx++) {
        var x = 2 + gx * 6.4 + ((gy % 2) ? 3.2 : 0) + (((gx * 7 + gy * 13) % 5) - 2) * 0.7;
        var y = 2 + gy * 5.6 + (((gx * 11 + gy * 5) % 5) - 2) * 0.6;
        if (!C.inBounds(x, y)) continue;
        var pts = [], speeds = [], ok = true;
        for (var k = 0; k < steps; k++) {
          if (!C.inBounds(x, y)) { ok = false; break; }
          var c = C.at(x, y, season);
          var m = Math.hypot(c.u, c.v);
          pts.push({ x: sx(x), y: sy(y) });
          speeds.push(m);
          if (m < 1e-4) break;
          x += (c.u / m) * stepLen;
          y += (c.v / m) * stepLen;
        }
        if (pts.length < 8) continue;
        var mean = speeds.reduce(function (a, b) { return a + b; }, 0) / speeds.length;
        out.push({ pts: pts, speed: mean, ok: ok });
      }
    }
    return out;
  }
  /**
   * ⛔ THIS TAKES A SEASON RATHER THAN READING `st`, AND THE FIRST BUILD CRASHED THE TITLE SCREEN
   * BECAUSE IT DID NOT. The title draws living water behind its panel — before any voyage exists —
   * so `st.season` was a read of null on the very first frame a new player ever sees. Every asset
   * had loaded and `tideLoaded()` was true, so the boot overlay had already been hidden: the player
   * would have got a black rectangle. Caught by the layout gate on its first run, which is what a
   * gate that DRAWS EVERY SCREEN is for.
   */
  function ensureStreams(season) {
    if (streamSeason === season && streams) return streams;
    streams = buildStreams(season);
    streamSeason = season;
    return streams;
  }

  /* ── acts ───────────────────────────────────────────────────────────────────────────────────── */

  function newVoyage() {
    st = V.newState(Math.floor(Date.now() % 100000) || 7);
    sel = null; sol = null; solKey = ''; streams = null; streamSeason = -1;
    anim = null; lastLanding = null; logScroll = 0;
    setToast(['THE MAIL IS ABOARD.', 'Nine islands. Two years. Keep them supplied.']);
    save();
  }

  function setToast(lines) { toast = { lines: lines, t: 0 }; }

  function beginLeg(to) {
    if (anim || to === st.at) return;
    var s = ensureSolved();
    var t = s.costs[to];
    if (!isFinite(t)) return;
    var path = V.pathFrom(s, to);
    /* ⚠️ The animation length is a fixed span of REAL seconds, not a function of the leg's watches:
     * a 100-watch crossing should read as long, but not as ten seconds of waiting. */
    anim = { path: path, t: 0, dur: 1.15, dest: to, sailTime: t, i: 0 };
    play('sail');
  }

  function finishLeg() {
    var to = anim.dest, t = anim.sailTime;
    anim = null;
    var before = { season: st.season, supplied: st.supplied.length };
    var res = V.sailTo(st, to, t);
    sel = null;
    var isl = V.ISLANDS[to];
    var lines = ['MADE ' + isl.id + ' IN ' + Math.round(res.watches) + ' WATCHES.'];
    if (res.short > 0) lines.push('The last of it on short commons — twice as long, and everybody knew it.');
    if (res.turned) lines.push('The season turned to ' + C.SEASONS[st.season % C.SEASONS.length] + '. The water has moved.');
    lastLanding = { lines: lines };
    setToast(lines);
    if (res.turned) play('season'); else play('land');
    screen = 'landfall';
    save();
    if (V.done(st)) { screen = 'ending'; play('end'); }
  }

  function doDeliver(good) {
    var r = V.deliver(st, good);
    if (!r) return;
    play('deliver');
    var isl = V.ISLANDS[st.at];
    var l = [];
    if (r.firstTime) l.push(isl.id + ' IS SUPPLIED. They have what they need, and they will remember it.');
    else if (r.wanted) l.push('The ' + V.GOODS[good].name + ' is landed. That is what they were short of.');
    else l.push('The mail is landed. Small, and it is never nothing.');
    l.push('+' + r.gained + ' goodwill.');
    setToast(l);
    save();
  }
  function doLoad(good) { if (V.load(st, good)) { play('click'); save(); } }
  function doUnload(good) { if (V.unload(st, good)) { play('click'); save(); } }
  function doBuy(id) {
    if (V.buy(st, id)) {
      play('buy'); solKey = '';
      var g = V.GEAR.filter(function (x) { return x.id === id; })[0];
      setToast([g.name.toUpperCase() + '.', g.note]);
      save();
    }
  }
  function doBeacon() {
    var i = st.at;
    if (V.raiseBeacon(st, i)) {
      play('beacon');
      setToast(['A BEACON ON ' + V.ISLANDS[i].id + '.',
                'It keeps itself now. Whatever else happens out here, that light stays on.']);
      save();
    }
  }

  /* ── drawing: the chart ─────────────────────────────────────────────────────────────────────── */

  function drawSea(x, y, w, h) {
    var bx = x === undefined ? OX : x, by = y === undefined ? OY : y;
    var bw = w === undefined ? CHART_W : w, bh = h === undefined ? CHART_H : h;
    A.plate('sea', bx, by, bw, bh);
    for (var i = 0; i < V.SHOALS.length; i++) {
      var s = V.SHOALS[i];
      A.shoalPatch(sx(s.x), sy(s.y), s.r * SCALE, i * 1.7 + 0.6);
    }
  }

  function drawStreams(season) {
    var lines = ensureStreams(season === undefined ? (st ? st.season : 0) : season);
    for (var i = 0; i < lines.length; i++) {
      var l = lines[i];
      /* ⚠️ THESE WERE ALMOST INVISIBLE IN THE FIRST BUILD, which is the worst possible thing to do
       * to the one system the store page is about. Two passes: a soft continuous line so the shape
       * of the water reads even when still, and a bright moving dash on top so its DIRECTION reads. */
      var a = 0.20 + Math.min(0.45, l.speed * 0.34);
      A.poly(l.pts, A.INK.stream, 1, null, 0, a * 0.55);
      A.poly(l.pts, A.INK.streamHi, 1.2, [6, 12], -clock * (14 + l.speed * 30), a);
    }
  }

  function drawShoalMarks() {
    var pilot = st ? V.hasPilot(st) : false;
    for (var i = 0; i < V.SHOALS.length; i++) {
      var s = V.SHOALS[i];
      A.mark('shoal', sx(s.x) - 11, sy(s.y) - 11, 22, pilot ? 0.40 : 0.80);
      /* ⚠️ DARK INK. A pale label on the palest water on the chart is a label nobody reads —
       * §0-ART-E's rule, which is to pick an ink by what it SITS ON rather than by habit. */
      A.text(s.id, sx(s.x), sy(s.y) + 24, {
        size: 10, align: 'center', track: 1.6,
        fill: A.INK.ink, alpha: pilot ? 0.42 : 0.72
      });
    }
  }

  function drawRoute() {
    if (sel === null && !anim) return;
    var s = ensureSolved();
    var to = anim ? anim.dest : sel;
    if (to === st.at) return;
    var path = anim ? anim.path : V.pathFrom(s, to);
    var pts = [];
    for (var i = 0; i < path.length; i += 2) pts.push({ x: sx(path[i].x), y: sy(path[i].y) });
    if (path.length) pts.push({ x: sx(path[path.length - 1].x), y: sy(path[path.length - 1].y) });
    A.poly(pts, A.INK.track, 3, null, 0, 0.35);
    A.poly(pts, A.INK.trackLit, 1.5, [9, 7], -clock * 34, 0.95);
  }

  function drawIslands() {
    for (var i = 0; i < V.ISLANDS.length; i++) {
      var isl = V.ISLANDS[i];
      var supplied = st.supply[i] >= V.SUPPLIED_AT;
      var px = sx(isl.x), py = sy(isl.y);
      if (st.beacons.indexOf(i) >= 0) A.glow(px, py, 54, A.INK.lamp, 0.22);
      if (i === hover || i === sel) A.glow(px, py, 50, '#ffffff', 0.12);
      A.island(i, supplied, px, py);
      if (st.beacons.indexOf(i) >= 0) A.mark('beacon-lit', px + 16, py - 40, 22);

      /* the label: name over a supply bar, both derived from measureText */
      var lbl = isl.id;
      var lw = A.measure(lbl, { size: 12, track: 1.8 });
      var bx = Math.round(px - lw / 2 - 6), by = Math.round(py + 30);
      A.rect(bx, by, lw + 12, 17, 'rgba(20,32,42,0.62)');
      A.text(lbl, px, by + 12, { size: 12, align: 'center', track: 1.8, fill: A.INK.paperLit });
      /* supply pips: five, so a glance says how it is doing without reading a number */
      var pips = 5, pw = 6, gapw = 2, tot = pips * pw + (pips - 1) * gapw;
      var pxs = Math.round(px - tot / 2), pys = by + 20;
      for (var k = 0; k < pips; k++) {
        var full = st.supply[i] >= (k + 1) / pips - 0.001;
        A.rect(pxs + k * (pw + gapw), pys, pw, 4, full ? (supplied ? A.INK.good : A.INK.lamp) : 'rgba(0,0,0,0.45)');
      }
      A.zone('island', px - 34, py - 34, 68, 68, i);
    }
  }

  function drawBoat() {
    var px, py, k = 0;
    if (anim) {
      var n = anim.path.length - 1;
      var f = Math.min(1, anim.t / anim.dur);
      /* ease so the boat leaves and arrives gently rather than snapping */
      var e = f < 0.5 ? 2 * f * f : 1 - Math.pow(-2 * f + 2, 2) / 2;
      var i = Math.max(0, Math.min(n, Math.round(e * n)));
      var p = anim.path[i], q = anim.path[Math.min(n, i + 3)];
      px = sx(p.x); py = sy(p.y);
      k = A.headingCell(q.x - p.x, q.y - p.y);
    } else {
      /* ⚠️ ABOVE-RIGHT, not below-right. The boat was moored at +26,+24 — exactly where the island's
       * name plate is drawn — so on the chart it was invisible under its own label. */
      var isl = V.ISLANDS[st.at];
      px = sx(isl.x) + 28; py = sy(isl.y) - 26;
      var c = C.at(isl.x, isl.y, st.season);
      k = A.headingCell(c.u, c.v);
    }
    /* a soft wake so a 24px sprite reads against textured water */
    A.glow(px, py, 20, '#a9dedb', 0.22);
    A.boat(k, px, py);
    /* ⚠️ A capture harness has to be able to prove the SUBJECT of a store GIF is actually IN the
     * loop (wing §3c-9: a GIF once shipped twice with nobody in it, at 72 frames and every check
     * green). Publishing where the boat was drawn is one line and it is the only honest way to
     * assert it from outside. Harmless in play. */
    if (typeof root !== 'undefined') root.__lastBoat = { x: px, y: py, k: k, sailing: !!anim };
  }

  /* ── drawing: the bars ──────────────────────────────────────────────────────────────────────── */

  function bar(x, y, w, h, frac, fill, back) {
    A.rect(x, y, w, h, back || 'rgba(36,26,17,0.35)');
    A.rect(x, y, Math.round(w * Math.max(0, Math.min(1, frac))), h, fill);
    A.strokeRect(x, y, w, h, 'rgba(36,26,17,0.55)', 1);
  }

  function drawTopBar() {
    A.plate('chart', 0, 0, W, TOP_H);
    A.rect(0, TOP_H - 2, W, 2, 'rgba(36,26,17,0.5)');

    var season = C.SEASONS[st.season % C.SEASONS.length];
    var year = Math.floor(st.season / C.SEASONS.length) + 1;
    var x = 14;
    x += A.text('YEAR ' + year, x, 26, { size: 14, track: 2, fill: A.INK.inkSoft }) + 12;
    x += A.text(season, x, 26, { size: 16, track: 2.4, fill: A.INK.ink }) + 20;

    var left = V.WATCHES_PER_SEASON * V.SEASONS_IN_VOYAGE - st.watch;
    x += A.text(Math.max(0, Math.round(left)) + ' WATCHES LEFT', x, 26, { size: 13, track: 1.4, fill: A.INK.inkSoft }) + 22;

    /* stores: the number that decides how far you may go, so it gets a bar and not a digit */
    A.text('STORES', x, 26, { size: 12, track: 1.4, fill: A.INK.inkSoft });
    var sbx = x + A.measure('STORES', { size: 12, track: 1.4 }) + 8;
    bar(sbx, 14, 96, 12, st.stores / V.storesMax(st), st.stores < 20 ? A.INK.want : A.INK.good);
    A.text(Math.round(st.stores) + '/' + V.storesMax(st), sbx + 104, 25, { size: 12, fill: A.INK.inkSoft });
    x = sbx + 104 + A.measure(Math.round(st.stores) + '/' + V.storesMax(st), { size: 12 }) + 20;

    /* the hold */
    A.text('HOLD', x, 26, { size: 12, track: 1.4, fill: A.INK.inkSoft });
    var hx = x + A.measure('HOLD', { size: 12, track: 1.4 }) + 8;
    for (var i = 0; i < V.holdMax(st); i++) {
      A.strokeRect(hx + i * 26, 9, 22, 22, 'rgba(36,26,17,0.5)', 1);
      if (st.hold[i]) A.mark(st.hold[i], hx + i * 26 + 2, 11, 18);
    }

    /* goodwill, right-aligned so it never collides with the hold however many slots there are */
    var gw = String(st.goodwill) + ' GOODWILL';
    A.text(gw, W - 14, 26, { size: 14, track: 1.6, align: 'right', fill: A.INK.ink });
    A.mark('rose', W - 18 - A.measure(gw, { size: 14, track: 1.6 }) - 26, 8, 24, 0.8);
  }

  /**
   * ⛔ THE BOTTOM BAR IS 38 PIXELS TALL AND THEREFORE HOLDS EXACTLY ONE LINE. The first build
   * wrapped its status sentence into the available WIDTH, which is the right instinct on the wrong
   * axis: a three-clause message wrapped to two lines and the second was drawn at y=641 on a 640px
   * canvas — off the bottom of the world, invisible to everything except the layout gate. It also
   * ran straight under the SAIL button.
   *
   * A shared budget has to be spent EXPLICITLY (§3e-3). The message is built from clauses in
   * priority order and clauses are DROPPED from the end until the whole thing measures inside the
   * room the buttons leave. The destination and its cost can never be dropped; the cargo note can.
   */
  function drawBottomBar() {
    A.plate('chart', 0, BOT_Y, W, BOT_H);
    A.rect(0, BOT_Y, W, 2, 'rgba(36,26,17,0.5)');
    var y = BOT_Y + Math.round(BOT_H * 0.66);
    var bw = 128, bh = 26, by = BOT_Y + Math.round((BOT_H - bh) / 2);

    var logX = W - 14 - bw;
    var muteX = logX - 10 - bw;
    var sailX = muteX - 14 - bw;
    var textX = 14, textLimit = sailX - 14 - textX;

    A.button('LOG', logX, by, bw, bh, { id: 'log' });
    A.button(muted ? 'SOUND OFF' : 'SOUND ON', muteX, by, bw, bh, { id: 'mute' });

    var o = { size: 14, track: 1.0, fill: A.INK.ink };
    if (anim) {
      A.text(fit('UNDER WAY FOR ' + V.ISLANDS[anim.dest].id + '…', textLimit, o), textX, y, o);
      return;
    }
    if (sel === null) {
      o.fill = A.INK.inkSoft;
      A.text(fit('CLICK AN ISLAND TO LAY OFF A COURSE.  CLICK YOUR OWN TO GO ASHORE.', textLimit, o), textX, y, o);
      return;
    }
    var s = ensureSolved();
    var t = s.costs[sel];
    var leg = V.legCost(st, t);
    var isl = V.ISLANDS[sel];
    var clauses = ['TO ' + isl.id + ': ' + Math.round(leg.watches) + ' WATCHES'];
    clauses.push(leg.short > 0
      ? Math.round(leg.short) + ' OF THEM ON SHORT COMMONS'
      : Math.round(st.stores - t) + ' STORES LEFT ON ARRIVAL');
    if (isl.wants && st.hold.indexOf(isl.wants) >= 0) {
      clauses.push('YOU HAVE THEIR ' + V.GOODS[isl.wants].name.toUpperCase());
    }
    o.fill = leg.short > 0 ? A.INK.want : A.INK.ink;
    var msg = clauses.join('  ·  ');
    while (clauses.length > 1 && A.measure(msg, o) > textLimit) {
      clauses.pop();
      msg = clauses.join('  ·  ');
    }
    A.text(fit(msg, textLimit, o), textX, y, o);
    A.button('SAIL', sailX, by, bw, bh, { id: 'sail', on: true });
  }

  /** Last-resort truncation, so a single unbreakable clause can never leave the bar either. */
  function fit(str, limit, o) {
    if (A.measure(str, o) <= limit) return str;
    var s2 = str;
    while (s2.length > 4 && A.measure(s2 + '…', o) > limit) s2 = s2.slice(0, -1);
    return s2 + '…';
  }

  /**
   * THE MESSAGE BAND. A permanent strip between the HUD and the chart: one heading and one line of
   * detail, both measured into the room available, and it fades to the standing hint when nothing
   * has happened for a while. It can never cover an island because it is not over the chart.
   */
  function drawMessage() {
    A.plate('chart', 0, MSG_Y, W, MSG_H);
    A.rect(0, MSG_Y + MSG_H - 2, W, 2, 'rgba(36,26,17,0.5)');
    A.line(18, MSG_Y + 6, W - 18, MSG_Y + 6, A.INK.rule, 1);

    var head, body;
    if (toast && toast.t < 9) {
      head = toast.lines[0];
      body = toast.lines.slice(1).join('  ');
    } else if (anim) {
      head = 'UNDER WAY FOR ' + V.ISLANDS[anim.dest].id;
      body = 'Watching the water go by.';
    } else {
      var isl = V.ISLANDS[st.at];
      head = 'AT ' + isl.id;
      body = isl.wants
        ? 'They are short of ' + V.GOODS[isl.wants].name + '. Click ' + isl.id + ' to go ashore.'
        : isl.blurb;
    }
    var o1 = { size: 16, track: 2.2, fill: A.INK.ink };
    var o2 = { size: 12, fill: A.INK.inkSoft };
    var hw = A.measure(head, o1);
    A.text(fit(head, W - 40, o1), 20, MSG_Y + 28, o1);
    if (body) {
      var bx = 20 + hw + 22;
      A.text(fit(body, W - 20 - bx, o2), bx, MSG_Y + 27, o2);
    }
  }

  function drawHoverCard() {
    if (hover === null || hover === sel || anim) return;
    var isl = V.ISLANDS[hover];
    var s = ensureSolved();
    var t = s.costs[hover];
    var rows = [];
    rows.push(['SUPPLY', Math.round(st.supply[hover] * 100) + '%']);
    if (isl.wants) rows.push(['WANTS', V.GOODS[isl.wants].name]);
    rows.push(['MAKES', V.GOODS[isl.produces].name]);
    if (hover !== st.at && isFinite(t)) rows.push(['PASSAGE', Math.round(V.legCost(st, t).watches) + ' watches']);
    if (st.beacons.indexOf(hover) >= 0) rows.push(['BEACON', 'lit']);

    var wCol = 0, i;
    for (i = 0; i < rows.length; i++) wCol = Math.max(wCol, A.measure(rows[i][0], { size: 11, track: 1.2 }));
    var wVal = 0;
    for (i = 0; i < rows.length; i++) wVal = Math.max(wVal, A.measure(rows[i][1], { size: 12 }));
    var wTitle = A.measure(isl.id, { size: 14, track: 1.8 });
    var pad = 12, gap = 14;
    var cw = Math.max(wTitle, wCol + gap + wVal) + pad * 2;
    var ch = pad * 2 + 20 + rows.length * 16;

    /* place it beside the island, and FLIP IT rather than let it run off the chart */
    var px = sx(isl.x) + 42, py = sy(isl.y) - ch / 2;
    if (px + cw > W - 10) px = sx(isl.x) - 42 - cw;
    py = Math.max(TOP_H + 6, Math.min(BOT_Y - ch - 6, py));

    A.sheet(px, py, cw, ch);
    A.text(isl.id, px + pad, py + pad + 12, { size: 14, track: 1.8, fill: A.INK.ink });
    for (i = 0; i < rows.length; i++) {
      var ry = py + pad + 20 + 16 * (i + 1);
      A.text(rows[i][0], px + pad, ry, { size: 11, track: 1.2, fill: A.INK.inkFaint });
      A.text(rows[i][1], px + cw - pad, ry, { size: 12, align: 'right', fill: A.INK.ink });
    }
  }

  function drawChart() {
    drawSea();
    drawStreams();
    drawShoalMarks();
    drawRoute();
    drawIslands();
    drawBoat();
    /* the chart's own border, drawn last so nothing overlaps it */
    A.strokeRect(OX - 1, OY - 1, CHART_W + 2, CHART_H + 2, 'rgba(36,26,17,0.75)', 2);
    drawTopBar();
    drawMessage();
    drawBottomBar();
    drawHoverCard();
  }

  /* ── drawing: the paper screens ─────────────────────────────────────────────────────────────── */

  /**
   * A graticule and edge ticks, drawn very faintly on a paper panel. ⚠️ Without it the panels read
   * as blank parchment; with it they read as a working chart, which is what the whole game is. It
   * is drawn UNDER everything and at low alpha, so it can never compete with a word.
   */
  function chartRule(x, y, w, h) {
    var step = 64, i;
    A.ctx().save();
    A.ctx().globalAlpha = 0.16;
    for (i = step; i < w; i += step) A.line(x + i, y + 8, x + i, y + h - 8, A.INK.rule, 1);
    for (i = step; i < h; i += step) A.line(x + 8, y + i, x + w - 8, y + i, A.INK.rule, 1);
    A.ctx().restore();
    A.ctx().save();
    A.ctx().globalAlpha = 0.42;
    for (i = 16; i < w; i += 16) {
      var big = (i % step) === 0;
      A.line(x + i, y + 2, x + i, y + (big ? 12 : 7), A.INK.rule, 1);
      A.line(x + i, y + h - 2, x + i, y + h - (big ? 12 : 7), A.INK.rule, 1);
    }
    for (i = 16; i < h; i += 16) {
      var big2 = (i % step) === 0;
      A.line(x + 2, y + i, x + (big2 ? 12 : 7), y + i, A.INK.rule, 1);
      A.line(x + w - 2, y + i, x + w - (big2 ? 12 : 7), y + i, A.INK.rule, 1);
    }
    A.ctx().restore();
  }

  function pageFrame(title, subtitle) {
    drawSea();
    A.ctx().save(); A.ctx().globalAlpha = 0.55; A.rect(0, 0, W, H, '#0e2a38'); A.ctx().restore();
    var m = 40;
    A.sheet(m, m, W - m * 2, H - m * 2);
    chartRule(m, m, W - m * 2, H - m * 2);
    A.text(title, W / 2, m + 44, { size: 26, align: 'center', track: 5, fill: A.INK.ink });
    if (subtitle) {
      A.paragraph(subtitle, m + 48, m + 70, W - m * 2 - 96,
        { size: 13, align: 'center', fill: A.INK.inkSoft });
    }
    A.line(m + 60, m + 84, W - m - 60, m + 84, A.INK.rule, 1);
    return { x: m, y: m, w: W - m * 2, h: H - m * 2, top: m + 104 };
  }

  function drawTitle() {
    /* ⚠️ THE WHOLE CANVAS, not the chart rectangle. The first build drew the sea only inside the
     * chart bounds and left a dark unfinished border round three sides of the title screen. */
    drawSea(0, 0, W, H);
    drawStreams();
    A.ctx().save(); A.ctx().globalAlpha = 0.40; A.rect(0, 0, W, H, '#0e2a38'); A.ctx().restore();

    var pw = 600, ph = 360;
    var px = Math.round((W - pw) / 2), py = 118;
    A.sheet(px, py, pw, ph);
    chartRule(px, py, pw, ph);
    A.mark('rose', W / 2 - 28, py + 22, 56, 0.9);
    A.text('TIDEPOST', W / 2, py + 124, { size: 48, align: 'center', track: 12, fill: A.INK.ink });
    A.paragraph('Carry the mail between nine islands, in a sea that is a real current field and moves with the season.',
      px + 46, py + 158, pw - 92, { size: 14, align: 'center', fill: A.INK.inkSoft });
    A.paragraph('Nothing here can be lost. Every island you keep supplied stays a place you can reach.',
      px + 46, py + 208, pw - 92, { size: 14, align: 'center', fill: A.INK.inkSoft });

    var bw = 232, bh = 36, by = py + ph - 92;
    if (hasSave()) {
      A.button('CONTINUE THE VOYAGE', W / 2 - bw - 10, by, bw, bh, { id: 'continue', on: true });
      A.button('A NEW VOYAGE', W / 2 + 10, by, bw, bh, { id: 'new' });
    } else {
      A.button('BEGIN THE VOYAGE', W / 2 - bw / 2, by, bw, bh, { id: 'new', on: true });
    }
    A.button('HOW IT WORKS', W / 2 - 116, by + 46, 232, 30, { id: 'help', size: 13 });

    A.text('Core Systems Asset Factory', W / 2, H - 30, { size: 12, align: 'center', track: 2, fill: A.INK.paperLit, alpha: 0.7 });
  }

  /**
   * ⛔ REBUILT AFTER LOOKING AT IT. The first landfall page put an 80px island alone in the top-left
   * of a 880x520 sheet, the hold in the bottom-left corner two hundred pixels from anything that
   * referred to it, and the two navigation buttons hard against the right deckle edge with labels
   * wider than their own boxes. It measured perfectly and it was an empty room with the furniture
   * pushed against the walls.
   *
   * ⚠️ THE ISLAND IS DRAWN AT 2x AND THAT IS DELIBERATE. Wing doctrine is that scaled pixel art is
   * mush — but an INTEGER doubling is not resampling, it is a magnifier, and this is the one place
   * the player is meant to study the island rather than glance at it. Every other draw stays 1:1.
   */
  function drawLandfall() {
    var isl = V.ISLANDS[st.at];
    var f = pageFrame(isl.id, isl.blurb);
    var supplied = st.supply[st.at] >= V.SUPPLIED_AT;
    var ctxr = A.ctx();
    var cell = A.islandCell();

    /* the left column: the island, magnified, in a ruled inset */
    var colW = 260;
    var lx = f.x + 44;
    var insetW = colW, insetH = cell * 2 + 20;
    var iy = f.top + 6;
    A.rect(lx, iy, insetW, insetH, 'rgba(36,26,17,0.06)');
    A.strokeRect(lx, iy, insetW, insetH, A.INK.rule, 1);
    var icx = lx + insetW / 2, icy = iy + insetH / 2;
    ctxr.save();
    ctxr.translate(icx, icy); ctxr.scale(2, 2); ctxr.translate(-icx, -icy);
    A.island(st.at, supplied, icx, icy);
    ctxr.restore();
    if (st.beacons.indexOf(st.at) >= 0) A.mark('beacon-lit', lx + insetW - 40, iy + 10, 28);

    /* the supply reading, directly under the picture it describes */
    var sy2 = iy + insetH + 26;
    A.text('SUPPLY', lx, sy2, { size: 12, track: 1.4, fill: A.INK.inkFaint });
    A.text(supplied ? 'SUPPLIED' : 'WANTING', lx + colW, sy2,
      { size: 13, align: 'right', track: 1.8, fill: supplied ? A.INK.good : A.INK.want });
    bar(lx, sy2 + 8, colW, 12, st.supply[st.at], supplied ? A.INK.good : A.INK.want);
    A.text('falls back each season to ' + Math.round(V.floorOf(st, st.at) * 100) + '%', lx, sy2 + 38,
      { size: 11, fill: A.INK.inkFaint });

    /* the hold, in the same column and close enough to read as one idea with it */
    var hy = sy2 + 68;
    A.text('IN THE HOLD', lx, hy, { size: 12, track: 1.4, fill: A.INK.inkFaint });
    A.text('click a parcel to set it ashore', lx + colW, hy,
      { size: 10, align: 'right', fill: A.INK.inkFaint });
    for (var j = 0; j < V.holdMax(st); j++) {
      var hx = lx + j * 36;
      A.strokeRect(hx, hy + 10, 30, 30, 'rgba(36,26,17,0.45)', 1);
      if (st.hold[j]) {
        A.mark(st.hold[j], hx + 4, hy + 14, 22);
        A.zone('drop', hx, hy + 10, 30, 30, st.hold[j]);
      }
    }

    /* ⚠️ THE BOTTOM HALF OF THIS PAGE WAS EMPTY PAPER, and the player was being asked to choose a
     * destination on the NEXT screen with nothing in front of them. The passages from here are the
     * one thing they actually need ashore, so they go here — derived from the same solver the chart
     * uses, never from a second copy of the arithmetic. */
    var fy = hy + 62;
    A.text('PASSAGES FROM HERE', lx, fy, { size: 12, track: 1.4, fill: A.INK.inkFaint });
    var solv = ensureSolved();
    var legs = [];
    for (var q2 = 0; q2 < V.ISLANDS.length; q2++) {
      if (q2 === st.at || !isFinite(solv.costs[q2])) continue;
      legs.push({ i: q2, w: V.legCost(st, solv.costs[q2]).watches });
    }
    legs.sort(function (a, b) { return a.w - b.w; });
    for (var q3 = 0; q3 < Math.min(4, legs.length); q3++) {
      var ry = fy + 20 + q3 * 19;
      var li = V.ISLANDS[legs[q3].i];
      var lit = st.supply[legs[q3].i] >= V.SUPPLIED_AT;
      A.text(li.id, lx, ry, { size: 12, fill: lit ? A.INK.good : A.INK.inkSoft });
      A.text(Math.round(legs[q3].w) + ' watches', lx + colW, ry,
        { size: 12, align: 'right', fill: A.INK.inkSoft });
    }

    /* the right column: what they need, what happened, what you can do */
    var cx2 = f.x + 44 + colW + 56, cw = f.x + f.w - 44 - cx2;
    var y = f.top + 18;
    if (isl.wants) {
      A.mark(isl.wants, cx2, y - 17, 24);
      A.text('THEY ARE SHORT OF ' + V.GOODS[isl.wants].name.toUpperCase(), cx2 + 34, y,
        { size: 15, track: 1.4, fill: A.INK.ink });
    } else {
      A.text('THIS IS THE POST. NOTHING IS WANTED HERE.', cx2, y, { size: 15, track: 1.4, fill: A.INK.inkSoft });
    }
    y += 30;
    A.mark(isl.produces, cx2, y - 17, 24);
    A.text('THEY CAN SPARE ' + V.GOODS[isl.produces].name.toUpperCase(), cx2 + 34, y,
      { size: 15, track: 1.4, fill: A.INK.inkSoft });
    y += 30;

    if (lastLanding) {
      A.line(cx2, y - 6, cx2 + cw, y - 6, A.INK.rule, 1);
      y += 12;
      for (var i = 0; i < lastLanding.lines.length; i++) {
        y += A.paragraph(lastLanding.lines[i], cx2, y, cw, { size: 12, fill: A.INK.inkFaint }) + 2;
      }
      y += 12;
    }

    var bw2 = Math.min(320, cw), bh = 32, gap = 10;
    var acts = [];
    if (!st.mailLanded) acts.push({ id: 'mail', label: 'LAND THE MAIL', on: true });
    if (isl.wants && st.hold.indexOf(isl.wants) >= 0) {
      acts.push({ id: 'give', label: 'LAND THE ' + V.GOODS[isl.wants].name.toUpperCase(), arg: isl.wants, on: true });
    }
    if (isl.produces !== 'LETTERS' && st.hold.length < V.holdMax(st)) {
      acts.push({ id: 'take', label: 'TAKE ON ' + V.GOODS[isl.produces].name.toUpperCase(), arg: isl.produces });
    }
    if (st.beacons.indexOf(st.at) < 0) {
      acts.push({
        id: 'beacon', label: 'RAISE A BEACON — ' + V.beaconCost(st) + ' GOODWILL',
        enabled: V.canRaiseBeacon(st, st.at)
      });
    }
    for (var k = 0; k < acts.length; k++) A.button(acts[k].label, cx2, y + k * (bh + gap), bw2, bh, acts[k]);
    var ay = y + acts.length * (bh + gap);
    if (st.beacons.indexOf(st.at) < 0 && !V.canRaiseBeacon(st, st.at)) {
      A.paragraph(st.supply[st.at] < V.SUPPLIED_AT
        ? 'A beacon needs a supplied island under it. Land what they are short of first.'
        : 'A beacon costs ' + V.beaconCost(st) + ' goodwill and you have ' + st.goodwill + '.',
        cx2, ay + 16, bw2, { size: 11, fill: A.INK.inkFaint });
    }

    /* ⛔ THE NAVIGATION BUTTONS ARE SIZED FROM THEIR OWN LABELS. "BACK TO THE CHART" in a 150px box
     * overhung its brass on both sides and printed onto the paper beside it. `ART.button` now shrinks
     * a label that will not fit, and sizing the box from the label means it never has to. */
    var nbh = 30, ny = f.y + f.h - 52;
    var l1 = 'THE CHANDLERY', l2 = 'BACK TO THE CHART';
    var w1 = A.measure(l1, { size: 13, track: 1.4 }) + 34;
    var w2 = A.measure(l2, { size: 13, track: 1.4 }) + 34;
    A.button(l2, f.x + f.w - 44 - w2, ny, w2, nbh, { id: 'chart', on: true, size: 13 });
    A.button(l1, f.x + f.w - 44 - w2 - 14 - w1, ny, w1, nbh, { id: 'chandlery', size: 13 });
  }

  /**
   * ⚠️ THE LIST NOW SAYS WHAT EACH THING DOES, IN NUMBERS, and that is not decoration: a player
   * choosing between "A gaff cut" and "Ballast trimmed" on prose alone is choosing blind, and the
   * first version left the bottom third of the page empty while withholding exactly the information
   * the screen exists to give. The chips are DERIVED from the gear table, so they cannot drift from
   * what the item really does.
   */
  function gearChips(g) {
    var out = [];
    if (g.own) out.push('speed +' + g.own.toFixed(2));
    if (g.grip) out.push('grip +' + g.grip.toFixed(2));
    if (g.stores) out.push('stores +' + g.stores);
    if (g.hold) out.push('hold +' + g.hold);
    if (g.pilot) out.push('knows the banks');
    return out.join('   ·   ');
  }

  function drawChandlery() {
    var f = pageFrame('THE CHANDLERY',
      'Nothing here makes you stronger. Everything here changes which water you can use.');
    var colW = f.w - 96;
    /* ⚠️ THE ROW PITCH HAS TO LEAVE ROOM FOR THE FOOTER, NOT JUST FOR THE ROWS. At (f.h - 150) / 6
     * the sixth item's note landed on the GOODWILL IN HAND line — the rows fitted the page and the
     * page had something else at the bottom of it. Budget the footer explicitly. */
    var rowH = Math.floor((f.h - 190) / V.GEAR.length);
    var y = f.top + 12;
    for (var i = 0; i < V.GEAR.length; i++) {
      var g = V.GEAR[i];
      var owned = st.owned.indexOf(g.id) >= 0;
      var can = V.affordable(st, g.id);
      if (i % 2 === 0) A.rect(f.x + 40, y - 18, colW + 16, rowH, 'rgba(36,26,17,0.055)');
      A.text(g.name, f.x + 48, y, { size: 16, track: 1.2, fill: owned ? A.INK.inkFaint : A.INK.ink });
      A.text(gearChips(g), f.x + 48, y + 19, { size: 11, track: 0.6, fill: owned ? A.INK.inkFaint : A.INK.inkSoft });
      A.paragraph(g.note, f.x + 48, y + 37, colW - 210, { size: 11, fill: A.INK.inkFaint });
      if (owned) {
        A.text('ABOARD', f.x + f.w - 48, y, { size: 13, align: 'right', track: 1.6, fill: A.INK.good });
      } else {
        A.button(g.cost + ' GOODWILL', f.x + f.w - 178, y - 20, 130, 30,
          { id: 'buy', arg: g.id, enabled: can, on: can, size: 12 });
      }
      y += rowH;
    }
    A.text(st.goodwill + ' GOODWILL IN HAND', f.x + 48, f.y + f.h - 50, { size: 16, track: 1.6, fill: A.INK.ink });
    A.button('BACK', f.x + f.w - 174, f.y + f.h - 70, 130, 30, { id: 'landfall', on: true });
  }

  /**
   * ⚠️ THE ROSTER WAS ADDED AFTER LOOKING AT THIS PAGE: the stats and the entries filled the top
   * third and the bottom two thirds were empty paper. It is not filler — it is the one view of the
   * whole archipelago the game did not have, and a player deciding where to go next wants exactly
   * this: who is standing, who is slipping, who wants what, and where the lights are.
   */
  function drawLog() {
    var f = pageFrame('THE LOG', 'What has happened, and what is standing.');
    var sc = V.score(st);
    var rows = [
      ['landfalls made', String(sc.landfalls)],
      ['islands ever supplied', sc.everSupplied + ' of ' + V.ISLANDS.length],
      ['standing right now', String(sc.standing)],
      ['beacons lit', String(sc.beacons)],
      ['wanted cargo landed', String(sc.delivered)],
      ['gear aboard', sc.gear + ' of ' + V.GEAR.length]
    ];
    var y = f.top + 6;
    for (var i = 0; i < rows.length; i++) {
      A.text(rows[i][0], f.x + 48, y, { size: 13, fill: A.INK.inkFaint });
      A.text(rows[i][1], f.x + 300, y, { size: 14, align: 'right', fill: A.INK.ink });
      y += 22;
    }

    A.line(f.x + 340, f.top - 4, f.x + 340, f.top + 158, A.INK.rule, 1);
    var lx = f.x + 366, lw = f.w - 412;
    A.text('THE VOYAGE SO FAR', lx, f.top + 6, { size: 13, track: 1.6, fill: A.INK.inkFaint });
    /* ⛔ THE LIST STOPS WHERE THE PAGE STOPS, MEASURED. Slicing a fixed COUNT off the log is a guess
     * about how tall each entry is — a beacon entry is two lines and a landfall is one — so ask each
     * one how tall it WILL be and stop when the next would not fit. */
    var floorY = f.top + 160;
    var entries = st.log.slice(-24);
    var ly = f.top + 30, drawn = 0;
    for (var k = 0; k < entries.length; k++) {
      var e = entries[k];
      var eh = A.paragraphHeight(e.t, lw - 44, { size: 12 });
      if (ly + eh > floorY) break;
      A.text('w' + String(e.w), lx, ly, { size: 11, fill: A.INK.inkFaint });
      ly += A.paragraph(e.t, lx + 44, ly, lw - 44, { size: 12, fill: A.INK.inkSoft }) + 2;
      drawn++;
    }
    if (drawn < st.log.length) {
      A.text('…and ' + (st.log.length - drawn) + ' earlier entries', lx, ly + 4,
        { size: 11, fill: A.INK.inkFaint });
    }
    if (!entries.length) A.text('Nothing yet. The mail is aboard.', lx, ly, { size: 12, fill: A.INK.inkFaint });

    /* ── the roster ────────────────────────────────────────────────────────────────────────── */
    /* ⚠️ THE ROSTER'S LAST ROW MUST CLEAR THE BUTTONS, and on its first build it did not — the
     * "wants"/"makes" captions of the bottom row printed inside HOW IT WORKS. The row pitch and the
     * band origin are budgeted against the footer rather than against the space that looked free. */
    var ry0 = f.top + 186;
    A.line(f.x + 44, ry0 - 16, f.x + f.w - 44, ry0 - 16, A.INK.rule, 1);
    A.text('THE NINE', f.x + 48, ry0, { size: 13, track: 1.6, fill: A.INK.inkFaint });
    A.text('supply · what they want · what they make', f.x + f.w - 48, ry0,
      { size: 11, align: 'right', fill: A.INK.inkFaint });

    var cols = 3, cw = Math.floor((f.w - 96) / cols), rh = 62;
    for (var q = 0; q < V.ISLANDS.length; q++) {
      var isl = V.ISLANDS[q];
      var cx2 = f.x + 48 + (q % cols) * cw;
      var cy2 = ry0 + 28 + Math.floor(q / cols) * rh;
      var supplied = st.supply[q] >= V.SUPPLIED_AT;
      A.text(isl.id, cx2, cy2, { size: 13, track: 1.2, fill: supplied ? A.INK.good : A.INK.ink });
      if (st.beacons.indexOf(q) >= 0) A.mark('beacon-lit', cx2 + cw - 68, cy2 - 14, 18);
      if (q === st.at) {
        A.text('you are here', cx2 + cw - 46, cy2, { size: 10, align: 'right', fill: A.INK.inkFaint });
      }
      bar(cx2, cy2 + 8, cw - 46, 9, st.supply[q], supplied ? A.INK.good : A.INK.want);
      var mx2 = cx2;
      if (isl.wants) {
        A.mark(isl.wants, mx2, cy2 + 24, 18);
        A.text('wants', mx2 + 22, cy2 + 37, { size: 10, fill: A.INK.inkFaint });
        mx2 += 22 + A.measure('wants', { size: 10 }) + 14;
      }
      A.mark(isl.produces, mx2, cy2 + 24, 18);
      A.text('makes', mx2 + 22, cy2 + 37, { size: 10, fill: A.INK.inkFaint });
    }

    var wA = A.measure('HOW IT WORKS', { size: 13, track: 1.4 }) + 34;
    A.button('BACK', f.x + f.w - 174, f.y + f.h - 52, 130, 30, { id: 'back', on: true, size: 13 });
    A.button('HOW IT WORKS', f.x + f.w - 174 - 14 - wA, f.y + f.h - 52, wA, 30, { id: 'help', size: 13 });
  }

  /**
   * ⚠️ REBUILT AFTER LOOKING AT IT. The first version was four paragraphs and a full third of the
   * sheet left blank underneath them — a wall of prose explaining a game whose whole argument is
   * VISUAL. Every item now carries the chart mark it is about, drawn from the same sheet the game
   * draws, so the page teaches the symbols at the same time as the rules.
   */
  function drawHelp() {
    var items = [
      ['rose', 'THE SEA', 'The water is a real current field, not a picture of one. The pale lines are its true streamlines: sail along them and a crossing is cheap, sail across them and it is dear. Every season moves them, so the same two islands are a different journey in spring and in winter.'],
      ['LETTERS', 'THE MAIL', 'You always carry letters and they are always welcome, one sack per landfall. Each island also wants one particular thing that another island makes, and landing THAT is worth far more. The hold decides how much of the route you can chain together.'],
      ['SEED', 'THE STORES', 'Sailing eats provisions. A well supplied island fills you up; a wanting one gives what it can spare. So the network you keep supplied IS the range you have, and running dry only means the rest of that leg takes twice as long. Nothing is ever lost.'],
      ['shoal', 'THE BANKS', 'Four shoals lie on the fast water. They cost more than twice as long to cross until you buy a pilot\'s eye, and then every one of them becomes a short cut.'],
      ['beacon-lit', 'THE LIGHTS', 'Once an island is supplied you can raise a beacon on it, and a beacon island keeps itself for the rest of the voyage. It is the only thing in the game that removes work rather than adding it, and it is the only thing you leave behind.'],
      ['anchor', 'THE VOYAGE', 'Eight seasons, then an ending that counts how much of the coast is standing. Your voyage saves itself after every act, so you can close the tab and come back. There is no death and no restart.']
    ];
    /* ⛔ THE COUNT IS COUNTED. This subtitle read "Four things" over SIX items the moment two were
     * added — the same wrong-caption defect §3c-10 records on a store plate, arriving inside the
     * game. A number in a sentence that describes a list must come FROM the list. */
    var WORDS = ['no', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight'];
    var f = pageFrame('HOW IT WORKS',
      (WORDS[items.length] || String(items.length)) + ' things, and they all read each other.');
    var colW = (f.w - 150) / 2;
    var lx = f.x + 52, rx = f.x + 52 + colW + 46;
    var rowH = Math.floor((f.h - 190) / 3);
    for (var i = 0; i < items.length; i++) {
      var x = i % 2 ? rx : lx;
      var yy = f.top + 22 + Math.floor(i / 2) * rowH;
      A.mark(items[i][0], x, yy - 20, 26);
      A.text(items[i][1], x + 36, yy, { size: 16, track: 2.2, fill: A.INK.ink });
      A.line(x, yy + 10, x + colW, yy + 10, A.INK.rule, 1);
      A.paragraph(items[i][2], x, yy + 30, colW, { size: 12, fill: A.INK.inkSoft });
    }
    A.paragraph('There is no way to lose. You do not fight the sea and you cannot beat it — you read it, and you learn to spend it.',
      lx, f.y + f.h - 74, f.w - 104, { size: 13, align: 'center', fill: A.INK.ink });
    A.button('BACK', f.x + f.w - 174, f.y + f.h - 54, 130, 30, { id: 'back', on: true, size: 13 });
  }

  /**
   * ⛔ THE ISLANDS ARE DRAWN 1:1 AND THE GRID IS CENTRED IN THE SHEET. The first ending drew them at
   * 0.62 — resampled pixel art, mushy, in a crowded band across the top of a page that was then two
   * thirds empty. At full size nine islands fill the space they were always meant to fill, and the
   * column pitch comes from the WIDEST LABEL rather than the sprite, because spacing by the picture
   * put "THE NEEDLE" over "COLDHAVEN".
   */
  function drawEnding() {
    var sc = V.score(st);
    var f = pageFrame(sc.rank.title, sc.rank.line);
    var cell = A.islandCell();
    var cols = 5, gap = 14, labelH = 26;
    var widest = 0, q;
    for (q = 0; q < V.ISLANDS.length; q++) {
      widest = Math.max(widest, A.measure(V.ISLANDS[q].id, { size: 11, track: 1.2 }));
    }
    var pitch = Math.max(cell, widest) + gap;
    var rows = Math.ceil(V.ISLANDS.length / cols);
    var gridW = cols * pitch - gap, gridH = rows * (cell + labelH);
    var startX = Math.round(f.x + (f.w - gridW) / 2 + pitch / 2);
    var startY = Math.round(f.top + 18 + cell / 2);

    for (var i = 0; i < V.ISLANDS.length; i++) {
      var col = i % cols, row = Math.floor(i / cols);
      var cx2 = startX + col * pitch;
      var cy2 = startY + row * (cell + labelH);
      var supplied = st.supply[i] >= V.SUPPLIED_AT;
      var ctxr = A.ctx();
      ctxr.save();
      ctxr.globalAlpha = supplied ? 1 : 0.46;
      A.island(i, supplied, cx2, cy2);
      ctxr.restore();
      if (st.beacons.indexOf(i) >= 0) A.mark('beacon-lit', cx2 + cell / 2 - 24, cy2 - cell / 2 + 6, 22);
      A.text(V.ISLANDS[i].id, cx2, cy2 + cell / 2 + 15,
        { size: 11, align: 'center', track: 1.2, fill: supplied ? A.INK.good : A.INK.inkFaint });
    }

    var line = sc.standing + ' of ' + V.ISLANDS.length + ' standing   ·   ' + sc.beacons + ' beacons lit   ·   '
      + sc.delivered + ' cargoes landed   ·   ' + sc.landfalls + ' landfalls';
    A.text(line, W / 2, f.y + f.h - 92, { size: 14, align: 'center', track: 0.8, fill: A.INK.ink });
    /* the one sentence that says what the player actually left behind */
    var lit = st.beacons.map(function (i) { return V.ISLANDS[i].id; });
    A.paragraph(lit.length
      ? 'There are lights on ' + lit.slice(0, -1).join(', ') + (lit.length > 1 ? ' and ' : '') + lit[lit.length - 1]
        + ' that were not there when you started.'
      : 'No beacons this time. The islands still ate because a boat kept turning up.',
      f.x + 90, f.y + f.h - 70, f.w - 180, { size: 12, align: 'center', fill: A.INK.inkSoft });
    A.button('SAIL AGAIN', W / 2 - 84, f.y + f.h - 46, 168, 30, { id: 'again', on: true });
  }

  /* ── the frame ──────────────────────────────────────────────────────────────────────────────── */

  var SCREENS = { title: drawTitle, chart: drawChart, landfall: drawLandfall,
                  chandlery: drawChandlery, log: drawLog, help: drawHelp, ending: drawEnding };

  function draw() {
    A.beginFrame();
    /* ⛔ CLEARED EVERY FRAME. `__lastBoat` is published for capture harnesses, and left standing it
     * is a CACHE WITH NO INVALIDATION: a frame that draws no boat at all — the landfall page — kept
     * reporting the previous frame's position, so a GIF harness counted 57 of 60 frames "under way"
     * while frame 30 of the shipped file was a still sheet of paper. A global is not state. */
    if (typeof root !== 'undefined') root.__lastBoat = null;
    A.rect(0, 0, W, H, '#0e2a38');
    if (!st) { drawTitle(); return; }
    (SCREENS[screen] || drawChart)();
  }

  function frame(dt) {
    /* ⛔ PAUSED MEANS THE FRAME LOOP STOPS DRAWING, NOT JUST STOPS SIMULATING, and getting that
     * wrong produced a store image of the wrong screen. `setPaused(true)` used to keep calling
     * draw() every frame — so a capture harness that paused the game, drew a special plate with the
     * art layer, and then took a screenshot got whatever the LOOP had painted a millisecond later.
     * The plate was drawn perfectly and photographed nothing. That is wing §3c-7's two-drivers-on-
     * one-clock defect arriving at the RENDERER instead of the simulation. A paused game is a still
     * canvas; whoever paused it owns what is on it. */
    if (paused) return;
    clock += dt;
    if (toast) toast.t += dt;
    if (anim) {
      anim.t += dt;
      if (anim.t >= anim.dur) finishLeg();
    }
    draw();
  }

  /* ── input ──────────────────────────────────────────────────────────────────────────────────── */

  function click(x, y) {
    var b = A.hitTest(x, y);
    if (!b) { if (screen === 'chart') { sel = null; } return; }
    switch (b.id) {
      case 'new':       newVoyage(); screen = 'chart'; musicOn(); break;
      case 'continue':  st = loadSave() || V.newState(7); screen = 'chart'; solKey = ''; streamSeason = -1; musicOn(); break;
      case 'help':      screen = 'help'; play('click'); break;
      case 'log':       screen = 'log'; play('click'); break;
      case 'back':      screen = st ? 'chart' : 'title'; play('click'); break;
      case 'chart':     screen = 'chart'; play('click'); break;
      case 'landfall':  screen = 'landfall'; play('click'); break;
      case 'chandlery': screen = 'chandlery'; play('click'); break;
      case 'mute':      toggleMute(); break;
      case 'sail':      if (sel !== null) beginLeg(sel); break;
      case 'buy':       doBuy(b.arg); break;
      case 'mail':      doDeliver('LETTERS'); break;
      case 'give':      doDeliver(b.arg); break;
      case 'take':      doLoad(b.arg); break;
      case 'drop':      doUnload(b.arg); break;
      case 'beacon':    doBeacon(); break;
      case 'again':     clearSave(); newVoyage(); screen = 'chart'; break;
      case 'island':
        if (anim) break;
        if (b.arg === st.at) { lastLanding = null; screen = 'landfall'; play('click'); }
        else if (sel === b.arg) beginLeg(b.arg);
        else { sel = b.arg; play('click'); }
        break;
    }
  }

  function move(x, y) {
    hover = null;
    if (screen !== 'chart' || anim) return;
    var b = A.hitTest(x, y);
    if (b && b.id === 'island') hover = b.arg;
  }

  function key(k) {
    if (k === 'Escape') { if (screen !== 'chart' && screen !== 'title') screen = st ? 'chart' : 'title'; return; }
    if (k === 'm' || k === 'M') { toggleMute(); return; }
    if (k === '?' || k === 'h' || k === 'H') { screen = screen === 'help' ? (st ? 'chart' : 'title') : 'help'; return; }
    if (!st) return;
    if (k === 'l' || k === 'L') { screen = screen === 'log' ? 'chart' : 'log'; return; }
    if (k === 'Enter' || k === ' ') {
      if (screen === 'chart' && sel !== null) beginLeg(sel);
      else if (screen === 'chart') { lastLanding = null; screen = 'landfall'; }
      return;
    }
    if (screen === 'chart' && (k === 'Tab' || k === 'ArrowRight' || k === 'ArrowLeft')) {
      /* keyboard-only play: cycle the selection through the islands you are not standing on */
      var order = [];
      for (var i = 0; i < V.ISLANDS.length; i++) if (i !== st.at) order.push(i);
      var at = order.indexOf(sel);
      var d = k === 'ArrowLeft' ? -1 : 1;
      sel = order[(at + d + order.length) % order.length];
    }
  }

  function scroll(dy) { logScroll = Math.max(0, logScroll + (dy > 0 ? 1 : -1)); }

  /* ── the exported surface ───────────────────────────────────────────────────────────────────── */

  var TIDE = {
    W: W, H: H,
    SCALE: SCALE, OX: OX, OY: OY,
    frame: frame, draw: draw, click: click, move: move, key: key, scroll: scroll,
    loadAudio: loadAudio,
    /* ⛔ a capture harness and the game's own rAF loop are two drivers on one clock (§3c-7).
     * `setPaused(true)` stops the loop entirely — simulation AND render — and `step(dt)` is then the
     * only thing that moves time, by an exact amount, painting exactly one frame. */
    setPaused: function (b) { paused = !!b; },
    isPaused: function () { return paused; },
    step: function (dt) {
      var d = Math.max(0, Math.min(0.25, dt || 0));
      clock += d;
      if (toast) toast.t += d;
      if (anim) { anim.t += d; if (anim.t >= anim.dur) finishLeg(); }
      draw();
    },
    /* the harness surface: enough to drive every screen without touching internals by name */
    setScreen: function (s) { screen = s; },
    getScreen: function () { return screen; },
    state: function () { return st; },
    setState: function (s) { st = s; solKey = ''; streamSeason = -1; sel = null; anim = null; },
    startNew: function () { newVoyage(); screen = 'chart'; },
    select: function (i) { sel = i; },
    setHover: function (i) { hover = i; },
    setToast: function (lines) { setToast(lines); },
    sailTo: function (i) { beginLeg(i); },
    settle: function () { if (anim) { anim.t = anim.dur; finishLeg(); } },
    SFX_IDS: SFX_IDS,
    hasSave: hasSave, clearSave: clearSave
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = TIDE;
  else root.TIDE = TIDE;
})(typeof window !== 'undefined' ? window : globalThis);
