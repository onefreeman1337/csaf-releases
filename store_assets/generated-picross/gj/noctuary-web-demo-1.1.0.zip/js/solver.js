/* ══════════════════════════════════════════════════════════════════════════════════
 * NOCTUARY — THE LINE SOLVER
 *
 * A picross is only a PRODUCT if its puzzles are solvable by logic alone. A generator
 * that emits a pretty picture and derives clues from it emits, roughly half the time,
 * a puzzle that cannot be finished without guessing — and a picross that requires
 * guessing is not a puzzle game. No amount of art repairs that.
 *
 * So this file is not a convenience. It is the gate the generator runs BEFORE a
 * specimen is ever offered to a player, and it ships in Product_Release for three
 * reasons, all of which the game needs at runtime:
 *
 *   1. GENERATION FILTER — reject-and-reroll any specimen that is not line-solvable.
 *   2. HINT — "one cell is deducible right now" is exactly one propagation step.
 *   3. DIFFICULTY — how many passes the propagation needs, and how deep the hardest
 *      deduction is, is a real measured grading rather than a guess at grid size.
 *
 * ⛔ THE ONE THING TO UNDERSTAND BEFORE EDITING: line propagation NEVER guesses. It
 * only ever writes a cell whose value is identical in EVERY placement consistent with
 * that line's clue and what is already known. So if it fills the grid, the solution it
 * found is the ONLY solution — uniqueness is a free corollary of completion, and does
 * not need a separate search. The converse is NOT true: a puzzle can have exactly one
 * solution and still be unreachable by line logic. That puzzle is unfair, and this file
 * exists to throw it away.
 * ════════════════════════════════════════════════════════════════════════════════ */

'use strict';

const UNKNOWN = -1;
const EMPTY = 0;
const FILLED = 1;

/* ══════════════════════════════════════════════════════════════════════════════════
 * lineForce — the whole engine, in one function.
 *
 * Given one line's clue and what is currently known about that line, enumerate every
 * placement of the runs that is consistent with the known cells, and report the cells
 * that take the SAME value in all of them. Those are deductions. Everything else stays
 * unknown.
 *
 * Returns null when NO placement is consistent — a contradiction, which means either a
 * malformed puzzle or (during a uniqueness search) a bad branch.
 *
 * Cost: the number of placements is C(n - sum + gaps, k). At n=20 the worst case over
 * all clue shapes is ~5,005 (six runs of one), which is nothing. Measured on the real
 * corpus in Internal_Ops/check_solvable.js rather than assumed.
 * ════════════════════════════════════════════════════════════════════════════════ */
function lineForce(clue, known) {
  const n = known.length;
  const runs = (clue.length === 1 && clue[0] === 0) ? [] : clue;
  const k = runs.length;

  // suffix minimum lengths: runs[i..] plus one gap between each
  const need = new Array(k + 1).fill(0);
  for (let i = k - 1; i >= 0; i--) need[i] = need[i + 1] + runs[i] + (i < k - 1 ? 1 : 0);

  const cnt = new Array(n).fill(0);   // in how many placements is cell i FILLED
  const line = new Array(n).fill(0);
  let total = 0;

  function place(ri, start) {
    if (ri === k) {
      // every remaining cell is empty; a known-FILLED cell there kills this placement
      for (let i = start; i < n; i++) if (known[i] === FILLED) return;
      total++;
      for (let i = 0; i < n; i++) if (line[i]) cnt[i]++;
      return;
    }
    const len = runs[ri];
    for (let s = start; s + need[ri] <= n; s++) {
      // cells [start, s) are being left empty. The moment we skip a known-FILLED cell
      // no larger s can work either, so stop rather than continue.
      if (s > start && known[s - 1] === FILLED) break;

      let ok = true;
      for (let i = s; i < s + len; i++) if (known[i] === EMPTY) { ok = false; break; }
      if (ok && s + len < n && known[s + len] === FILLED) ok = false;   // run would not terminate
      if (!ok) continue;

      for (let i = s; i < s + len; i++) line[i] = 1;
      place(ri + 1, s + len + 1);
      for (let i = s; i < s + len; i++) line[i] = 0;
    }
  }
  place(0, 0);

  if (total === 0) return null;                       // contradiction
  const out = new Array(n);
  for (let i = 0; i < n; i++) {
    out[i] = (cnt[i] === total) ? FILLED : (cnt[i] === 0 ? EMPTY : UNKNOWN);
  }
  out.placements = total;
  return out;
}

/* ══════════════════════════════════════════════════════════════════════════════════
 * solve — propagate lines until nothing more is deducible.
 *
 * `budgetPasses` guards against a pathological input rather than against a real puzzle;
 * on the real corpus the worst case measured is far below it (see check_solvable.js).
 * ════════════════════════════════════════════════════════════════════════════════ */
function solve(clueSet, opts) {
  opts = opts || {};
  const n = clueSet.rows.length;
  const budgetPasses = opts.budgetPasses || 200;

  const g = [];
  for (let r = 0; r < n; r++) g.push(new Array(n).fill(UNKNOWN));

  let passes = 0;
  let deducedThisPass = 0;
  let contradiction = false;

  /*
   * ⛔ `hardest` counts placements ONLY on a line that actually produced a deduction.
   *
   * The first version of this counted every line it evaluated, and the comment above it
   * claimed it counted winning deductions. That is a doc/code disagreement, and the code
   * was the wrong half: a 20-cell line with a wide-open clue has thousands of placements
   * on pass 1 whether or not it teaches you anything, so the metric was dominated by the
   * EMPTIEST line on the board and was really a statistic about clue shape. It measured
   * ~3,003 on the corpus and would have graded almost every 20x20 "exacting" for a reason
   * no player could feel. Counted properly it is what it says: how far ahead you had to
   * look on the one line that actually gave something up.
   */
  let hardest = 0;

  // width[] — how many cells were deducible from the board state at the START of each
  // pass. This is the player's actual experience: "how many moves do I have right now".
  // The MINIMUM of it is the bottleneck, and it is the honest difficulty signal.
  const widths = [];

  for (;;) {
    if (passes >= budgetPasses) break;
    passes++;
    deducedThisPass = 0;
    let widthThisPass = 0;

    for (let r = 0; r < n; r++) {
      const res = lineForce(clueSet.rows[r], g[r]);
      if (res === null) { contradiction = true; break; }
      let got = 0;
      for (let c = 0; c < n; c++) {
        if (g[r][c] === UNKNOWN && res[c] !== UNKNOWN) { g[r][c] = res[c]; deducedThisPass++; got++; }
      }
      if (got) { widthThisPass += got; if (res.placements > hardest) hardest = res.placements; }
    }
    if (contradiction) break;

    for (let c = 0; c < n; c++) {
      const col = new Array(n);
      for (let r = 0; r < n; r++) col[r] = g[r][c];
      const res = lineForce(clueSet.cols[c], col);
      if (res === null) { contradiction = true; break; }
      let got = 0;
      for (let r = 0; r < n; r++) {
        if (g[r][c] === UNKNOWN && res[r] !== UNKNOWN) { g[r][c] = res[r]; deducedThisPass++; got++; }
      }
      if (got) { widthThisPass += got; if (res.placements > hardest) hardest = res.placements; }
    }
    if (contradiction) break;
    if (deducedThisPass === 0) break;
    widths.push(widthThisPass);
  }

  let unknown = 0;
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (g[r][c] === UNKNOWN) unknown++;

  // The last pass is excluded from the bottleneck: it is the mopping-up sweep and is
  // small by construction on EVERY puzzle, so including it would make every grade the
  // same number and measure nothing.
  const body = widths.slice(0, Math.max(1, widths.length - 1));

  return {
    solved: !contradiction && unknown === 0,
    contradiction: contradiction,
    unknown: unknown,
    cells: n * n,
    passes: passes,
    hardestLine: hardest,
    widths: widths,
    bottleneck: body.length ? Math.min.apply(null, body) : 0,
    grid: g
  };
}

/* ══════════════════════════════════════════════════════════════════════════════════
 * lineSolvable — the generator's gate. One boolean, no excuses.
 * ════════════════════════════════════════════════════════════════════════════════ */
function lineSolvable(clueSet) {
  return solve(clueSet).solved;
}

/* ══════════════════════════════════════════════════════════════════════════════════
 * countSolutions — ONLY for diagnosis, never for the shipped generator.
 *
 * Propagate, then branch on the most-constrained unknown cell. Stops at `cap` (default
 * 2), because the only question worth asking is "is it unique?" — an exact count of a
 * hugely ambiguous grid is expensive and tells you nothing you can act on.
 *
 * This exists so the measurement can distinguish the two ways a specimen can fail:
 *   AMBIGUOUS      — genuinely more than one picture fits the clues. Unfixable.
 *   NEEDS-GUESSING — exactly one picture fits, but no chain of line deductions reaches
 *                    it. Still unfair, still rejected, but a different fact.
 * ════════════════════════════════════════════════════════════════════════════════ */
function countSolutions(clueSet, cap, _grid) {
  cap = cap || 2;
  const n = clueSet.rows.length;
  const start = _grid || null;

  function rec(seed) {
    const res = solveFrom(clueSet, seed);
    if (res.contradiction) return 0;
    if (res.unknown === 0) return 1;
    // branch on the first unknown cell
    let br = -1, bc = -1;
    outer: for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) {
      if (res.grid[r][c] === UNKNOWN) { br = r; bc = c; break outer; }
    }
    let found = 0;
    for (const v of [FILLED, EMPTY]) {
      const next = res.grid.map((row) => row.slice());
      next[br][bc] = v;
      found += rec(next);
      if (found >= cap) return found;
    }
    return found;
  }
  return rec(start);
}

function solveFrom(clueSet, seedGrid) {
  const n = clueSet.rows.length;
  const g = seedGrid ? seedGrid.map((r) => r.slice())
                     : Array.from({ length: n }, () => new Array(n).fill(UNKNOWN));
  let contradiction = false;
  for (;;) {
    let changed = 0;
    for (let r = 0; r < n; r++) {
      const res = lineForce(clueSet.rows[r], g[r]);
      if (res === null) { contradiction = true; break; }
      for (let c = 0; c < n; c++) if (g[r][c] === UNKNOWN && res[c] !== UNKNOWN) { g[r][c] = res[c]; changed++; }
    }
    if (contradiction) break;
    for (let c = 0; c < n; c++) {
      const col = new Array(n);
      for (let r = 0; r < n; r++) col[r] = g[r][c];
      const res = lineForce(clueSet.cols[c], col);
      if (res === null) { contradiction = true; break; }
      for (let r = 0; r < n; r++) if (g[r][c] === UNKNOWN && res[r] !== UNKNOWN) { g[r][c] = res[r]; changed++; }
    }
    if (contradiction) break;
    if (!changed) break;
  }
  let unknown = 0;
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (g[r][c] === UNKNOWN) unknown++;
  return { grid: g, unknown: unknown, contradiction: contradiction };
}

/* ══════════════════════════════════════════════════════════════════════════════════
 * nextDeduction — the HINT.
 *
 * Returns the single cell the player could deduce right now with the least work, plus
 * the line that proves it. Never a cell picked from the answer key: the hint is a real
 * deduction from the player's OWN board, so it is impossible for it to reveal something
 * the board does not already imply.
 *
 * `board` uses the same vocabulary as the solver: -1 unknown, 0 empty, 1 filled.
 * ════════════════════════════════════════════════════════════════════════════════ */
function nextDeduction(clueSet, board) {
  const n = clueSet.rows.length;
  let best = null;

  const consider = (kind, index, res, readCell, writeCell) => {
    if (res === null) return;
    for (let i = 0; i < n; i++) {
      if (readCell(i) !== UNKNOWN || res[i] === UNKNOWN) continue;
      if (!best || res.placements < best.placements) {
        best = Object.assign({ kind: kind, index: index, value: res[i], placements: res.placements },
                             writeCell(i));
      }
    }
  };

  for (let r = 0; r < n; r++) {
    consider('row', r, lineForce(clueSet.rows[r], board[r]),
             (i) => board[r][i], (i) => ({ row: r, col: i }));
  }
  for (let c = 0; c < n; c++) {
    const col = new Array(n);
    for (let r = 0; r < n; r++) col[r] = board[r][c];
    consider('col', c, lineForce(clueSet.cols[c], col),
             (i) => board[i][c], (i) => ({ row: i, col: c }));
  }
  return best;
}

/* ══════════════════════════════════════════════════════════════════════════════════
 * difficulty — a MEASURED grade, not a grid-size proxy.
 *
 * Three numbers a player actually feels:
 *   passes      — how many times you must sweep the whole board before it closes. A
 *                 puzzle that falls out in 3 passes feels generous; 8 feels grindy.
 *   hardestLine — how far ahead you had to look on the one line that gave something up.
 *   bottleneck  — the FEWEST cells that were deducible anywhere on the board at the
 *                 start of a pass, as a fraction of the board. This is the moment where
 *                 the player stares at the grid and cannot see a move. It is the single
 *                 best predictor of a puzzle feeling hard rather than long.
 *
 * ⛔ THE THRESHOLDS BELOW ARE MEASURED CONSTANTS, NOT TASTE. Every one is a percentile
 * of the real corpus, n=800 seeds per size, printed by Internal_Ops/check_solvable.js
 * on 2026-08-21:
 *
 *          hardestLine placements          bottleneck (cells deducible)
 *   size   p50   p75   p90   p99   max     p10   p25   p50   p90
 *   10x10    5     5     6    10    10      30    72    80    86
 *   15x15    7    15    35    35    36      22    52    68   167
 *   20x20   20    35    84   147   166      16    38   108   158
 *
 * The first version of this function used 120 and 900 as its bands, taken from a
 * hardestLine that was inflated ~18x because it counted lines that deduced NOTHING.
 * At the real scale, 120 would have graded almost nothing and 900 literally nothing —
 * a difficulty system that always returns the same answer, which is no system at all.
 *
 * A small grid grading as gentle almost every time is CORRECT, not a defect: a 10x10
 * moth genuinely is easy, and the progression through grid sizes is the game's spine.
 * ════════════════════════════════════════════════════════════════════════════════ */
function difficulty(clueSet) {
  const s = solve(clueSet);
  const n = clueSet.rows.length;
  if (!s.solved) {
    return { grade: null, solved: false, passes: s.passes, hardestLine: s.hardestLine, bottleneck: s.bottleneck };
  }
  const frac = s.bottleneck / (n * n);

  let score = 0;
  if (s.passes >= 5) score++;            // above the corpus mean at every size
  if (s.passes >= 7) score++;
  if (s.hardestLine >= 35) score++;      // p75 at 20x20
  if (s.hardestLine >= 84) score++;      // p90 at 20x20
  if (frac <= 0.10) score++;             // ~p10 at 20x20 — a genuinely thin moment
  if (frac <= 0.05) score++;

  const grade = score <= 1 ? 'gentle' : (score <= 3 ? 'measured' : 'exacting');
  return {
    grade: grade, score: score, solved: true,
    passes: s.passes, hardestLine: s.hardestLine,
    bottleneck: s.bottleneck, bottleneckFrac: frac
  };
}

/*
 * ⛔ THE BROWSER EXPORT WAS MISSING AND NOTHING CAUGHT IT UNTIL THE GAME WAS ASSEMBLED.
 *
 * Every check in Internal_Ops requires this file through Node, where `module.exports` is
 * the only path that matters, so all four of them passed with the whole game unable to
 * load it. Node gives each file its own module scope; a plain <script> tag does not. That
 * difference also collided `const SPEC` between puzzle.js and reveal.js, killing both.
 * Internal_Ops/playtest.js exists because it is the only thing that loads index.html.
 */
const _api = {
  UNKNOWN, EMPTY, FILLED,
  lineForce, solve, lineSolvable, countSolutions, nextDeduction, difficulty
};
if (typeof module !== 'undefined' && module.exports) module.exports = _api;
if (typeof window !== 'undefined') window.NoctuarySolver = _api;
