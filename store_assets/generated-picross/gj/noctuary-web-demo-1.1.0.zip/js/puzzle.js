/* ══════════════════════════════════════════════════════════════════════════════════
 * NOCTUARY — THE PLATE FACTORY
 *
 * Turns a plate NUMBER into a finished, fair puzzle. This is where the solver stops
 * being a diagnostic and becomes the generator's gate.
 *
 * MEASURED 2026-08-21, Internal_Ops/check_solvable.js, 800 seeds per size:
 * only 71.9% of specimens at 20x20 produce a picross solvable by logic alone (96.1% at
 * 10x10, 87.4% at 15x15). The remaining 28.1% split roughly evenly between genuinely
 * AMBIGUOUS pictures (more than one grid fits the clues) and unique-but-unreachable
 * ones. Both are unfair. Both are thrown away here, before a player ever sees them.
 *
 * ⛔ THE REROLL MUST NOT WALK. The obvious implementation — "count solvable seeds from
 * 1 until you reach plate n" — makes plate 300 cost 300 solves, and the cost grows with
 * the player's progress, which is exactly backwards. Instead the plate NUMBER is hashed
 * into a seed and the ATTEMPT INDEX is mixed in, so every plate costs ~1.4 solves no
 * matter how deep in the collection it is, and plate 7 is always the same moth forever.
 *
 * Cost, measured: 2.21 ms per solve at 20x20 => ~3 ms per accepted plate. The player
 * never sees it.
 * ════════════════════════════════════════════════════════════════════════════════ */

'use strict';

const _PS = (typeof require !== 'undefined' && typeof module !== 'undefined')
  ? require('./specimens.js') : null;
const _PV = (typeof require !== 'undefined' && typeof module !== 'undefined')
  ? require('./solver.js') : null;

// In the browser these arrive as globals from the script tags; in Node from require.
const PSPEC = _PS || (typeof window !== 'undefined' ? window.NoctuarySpecimens : null);
const PSOLV = _PV || (typeof window !== 'undefined' ? window.NoctuarySolver : null);

/* A 32-bit mix. Not cryptographic and does not need to be — it needs to scatter small
 * consecutive integers, which sequential seeds emphatically do not do on their own. */
function mix(a, b) {
  let h = (a | 0) ^ Math.imul(b | 0, 0x9e3779b9);
  h = Math.imul(h ^ (h >>> 16), 0x21f0aaad);
  h = Math.imul(h ^ (h >>> 15), 0x735a2d97);
  return (h ^ (h >>> 15)) >>> 0;
}

/*
 * MAX_ATTEMPTS = 48.
 *
 * At the measured worst acceptance rate (71.9% at 20x20) the chance of 48 consecutive
 * rejections is 0.281^48, about 1e-26. At a hypothetical 50% it is 3.6e-15. The cap is
 * a guard against a future change that breaks generation — NOT against normal variance —
 * and it THROWS rather than returning a lower-quality puzzle, because silently serving
 * an unsolvable plate is the failure this entire file exists to prevent.
 */
const MAX_ATTEMPTS = 48;

/* ══════════════════════════════════════════════════════════════════════════════════
 * plate — the whole public API.
 *
 *   plate(7, 20)                        -> the 7th plate at 20x20, fair, forever
 *   plate(7, 20, { grade: 'exacting' }) -> ...and rerolled until it grades exacting
 *
 * Returns { number, size, seed, attempts, genotype, grid, clues, difficulty }.
 * ════════════════════════════════════════════════════════════════════════════════ */
function plate(number, size, opts) {
  opts = opts || {};
  size = size || 20;
  const wantGrade = opts.grade || null;
  const base = mix(number | 0, size | 0);

  let firstFair = null;

  for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
    const seed = mix(base, attempt + 1);
    const g = PSPEC.genotype(seed);
    const grid = PSPEC.rasterise(g, size, 4);
    const cs = PSPEC.clues(grid);
    const d = PSOLV.difficulty(cs);
    if (!d.solved) continue;

    const built = {
      number: number, size: size, seed: seed, attempts: attempt + 1,
      genotype: g, grid: grid, clues: cs, difficulty: d
    };
    if (!wantGrade) return built;

    // Remember the first FAIR plate so a grade request can never fail outright — a
    // slightly-wrong difficulty is a design miss, an unsolvable plate is a broken game.
    if (!firstFair) firstFair = built;
    if (d.grade === wantGrade) return built;
  }

  if (firstFair) {
    firstFair.gradeFallback = true;   // the caller can see it did not get what it asked
    return firstFair;
  }
  throw new Error('NOCTUARY: no fair plate for number=' + number + ' size=' + size +
                  ' in ' + MAX_ATTEMPTS + ' attempts. Generation is broken, not unlucky.');
}

/* ══════════════════════════════════════════════════════════════════════════════════
 * THE PROGRESSION.
 *
 * The spine of the game is grid SIZE, because that is what the measurement says
 * actually controls difficulty: 10x10 grades gentle 100% of the time, 15x15 is 89%
 * gentle, and only at 20x20 does a real spread appear (64/29/8). Asking for an
 * "exacting" 10x10 is asking for something the corpus does not contain, so the
 * progression asks for grades only where they exist.
 * ════════════════════════════════════════════════════════════════════════════════ */
const DRAWERS = [
  { id: 'first',   label: 'First Drawer',   size: 10, count: 12, grade: null },
  { id: 'second',  label: 'Second Drawer',  size: 15, count: 12, grade: null },
  { id: 'third',   label: 'Third Drawer',   size: 15, count: 10, grade: 'measured' },
  { id: 'fourth',  label: 'Fourth Drawer',  size: 20, count: 12, grade: null },
  { id: 'fifth',   label: 'Fifth Drawer',   size: 20, count: 10, grade: 'measured' },
  { id: 'sixth',   label: 'The Night Case', size: 20, count: 10, grade: 'exacting' }
];

/*
 * ⛔ A DRAWER IS CURATED, NOT SAMPLED — and this was a REAL DEFECT, not a precaution.
 *
 * The first version of drawerPlate() just hashed (drawer, index) into plate() and
 * returned whatever came out. check_plates.js measured the result and found two of the
 * 66 shipped plates differing by TWO CELLS OF 400 — visually the same moth, twice, in a
 * collection whose entire selling point is that every specimen is different.
 *
 * check_corpus.js had measured the closest pair across 24,090 corpus pairs at 8 cells
 * and passed. It could not see this, because the corpus is not what ships: asking for a
 * GRADE reroll (the 'measured' and 'exacting' drawers) filters toward a narrow region of
 * genotype space, which concentrates the sample and makes collisions far MORE likely in
 * the shipped 66 than in 220 random draws. The bias was introduced by the difficulty
 * targeting — i.e. by a feature — and only a check on the shipped set could find it.
 *
 * So the drawer is built as a SET with a minimum-distance constraint, not drawn plate by
 * plate. It is still fully deterministic: same drawer definition, same six plates,
 * forever. Memoised because the whole set is computed at once.
 */
let _collection = null;

function minDelta(size) {
  // 5% of the board, floored at 8 cells. At 20x20 that is 20 cells; at 10x10, 8.
  return Math.max(8, Math.round(0.05 * size * size));
}

function gridDelta(a, b) {
  let d = 0;
  for (let r = 0; r < a.length; r++)
    for (let c = 0; c < a.length; c++)
      if (a[r][c] !== b[r][c]) d++;
  return d;
}

/*
 * ⛔ THE CONSTRAINT IS ACROSS THE WHOLE COLLECTION, NOT WITHIN A DRAWER.
 *
 * The first fix for the near-duplicate defect enforced minimum distance per drawer, and
 * check_plates.js went green at "closest pair 8 cells". It was still wrong, and the
 * measurement that found it was one line of extra reporting: the closest 15x15 pair was
 * `second#7 vs third#6` at 10 cells (floor 11) and the closest 20x20 pair was
 * `fourth#0 vs fifth#8` at 16 (floor 20) — both BELOW their floors, both invisible
 * because they straddle a drawer boundary.
 *
 * The player does not experience a drawer. They experience a cabinet of 66 specimens,
 * and two near-identical moths look no better for being filed in different drawers. So
 * the collection is built as one set, in DRAWERS order, with every candidate checked
 * against every same-size plate already accepted anywhere.
 *
 * The lesson generalises past this file: a scope-limited constraint passes a
 * scope-limited check and tells you nothing about the artefact.
 */
function buildCollection() {
  if (_collection) return _collection;
  const bySize = {};
  const out = {};

  for (const d of DRAWERS) {
    const need = minDelta(d.size);
    bySize[d.size] = bySize[d.size] || [];
    const chosen = [];
    const base = hashString(d.id);

    for (let k = 0; k < d.count * 120 && chosen.length < d.count; k++) {
      const p = plate(mix(base, k) % 1000000, d.size, d.grade ? { grade: d.grade } : {});
      if (d.grade && p.difficulty.grade !== d.grade) continue;   // never ship a fallback grade
      let ok = true;
      for (const q of bySize[d.size]) {
        if (gridDelta(p.grid, q.grid) < need) { ok = false; break; }
      }
      if (!ok) continue;
      p.drawer = d.id;
      p.indexInDrawer = chosen.length;
      chosen.push(p);
      bySize[d.size].push(p);
    }

    if (chosen.length < d.count) {
      throw new Error('NOCTUARY: drawer "' + d.id + '" could only fill ' + chosen.length +
                      ' of ' + d.count + ' plates at min-distance ' + need +
                      '. The corpus is too narrow for this cabinet, which is a DESIGN problem — ' +
                      'widen the vocabulary, do not lower the distance to make it pass.');
    }
    out[d.id] = chosen;
  }
  _collection = out;
  return out;
}

function buildDrawer(drawerId) {
  const c = buildCollection();
  if (!c[drawerId]) throw new Error('NOCTUARY: no drawer "' + drawerId + '"');
  return c[drawerId];
}

function drawerPlate(drawerId, indexInDrawer) {
  return buildDrawer(drawerId)[indexInDrawer];
}

function hashString(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

function totalPlates() { return DRAWERS.reduce((a, d) => a + d.count, 0); }

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { plate, drawerPlate, buildDrawer, minDelta, DRAWERS, totalPlates, mix };
}
if (typeof window !== 'undefined') {
  window.NoctuaryPuzzle = { plate, drawerPlate, buildDrawer, minDelta, DRAWERS, totalPlates, mix };
}
