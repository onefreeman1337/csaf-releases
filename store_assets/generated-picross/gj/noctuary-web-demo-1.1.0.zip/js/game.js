/* ══════════════════════════════════════════════════════════════════════════════════
 * NOCTUARY — THE GAME
 *
 * Three screens: the CABINET (your collection), the PLATE (one puzzle), and the REVEAL
 * (the specimen developing). One canvas, one loop, one save.
 *
 * ⛔ NO FAIL STATE, NO TIMER, NO PENALTY, AND THAT IS A DESIGN POSITION.
 *
 * Nintendo-lineage picross punishes a wrong mark with time. That works when the game is a
 * test. This one is a cabinet you fill at your own pace on a wet evening, and a penalty
 * would fight the entire premise — including the music, which is written to be ignorable
 * for twenty minutes precisely because nothing here is hurrying you.
 *
 * What replaces the penalty is that a wrong grid simply never completes, plus two tools
 * that both cost nothing: the READING (one real deduction) and the EXAMINE (marks the
 * cells you have filled that the answer does not contain). Both are honest — see below.
 * ════════════════════════════════════════════════════════════════════════════════ */

'use strict';

(function () {

  const SPEC = window.NoctuarySpecimens;
  const SOLV = window.NoctuarySolver;
  const PUZ = window.NoctuaryPuzzle;
  const BOARD = window.NoctuaryBoard;
  const REVEAL = window.NoctuaryReveal;
  const NAMES = window.NoctuaryNames;
  const AUDIO = window.NoctuaryAudio;

  const W = 1280, H = 800;
  const FONTS = {
    serif: '"Iowan Old Style", "Palatino Linotype", Palatino, Georgia, serif',
    mono: '"Iosevka", "Consolas", "SF Mono", Menlo, monospace'
  };

  const canvas = document.getElementById('stage');
  const ctx = canvas.getContext('2d');

  /* ── fit + HiDPI (1.1.0) ──────────────────────────────────────────────────────────
   * Everything is authored in 1280x800 LOGICAL pixels. The canvas is sized to the largest
   * 16:10 box its frame allows, and its backing store to that box times devicePixelRatio,
   * and every frame starts with that scale. So text and hairlines are drawn at the screen's
   * own resolution (Windows 125-150%, a 4K laptop) instead of being upscaled from 1280x800,
   * and a 1920x1080 window is filled instead of showing a bordered island. Input is mapped
   * back to logical pixels by pos(), which already divides by the CSS box. */
  let SX = 1, SY = 1;
  function fitCanvas() {
    const fr = canvas.parentElement ? canvas.parentElement.getBoundingClientRect() : null;
    const s = fr && fr.width > 0 && fr.height > 0 ? Math.min(fr.width / W, fr.height / H) : 1;
    const cssW = Math.max(1, Math.floor(W * s)), cssH = Math.max(1, Math.floor(H * s));
    const dpr = Math.min(3, Math.max(1, window.devicePixelRatio || 1));
    const bw = Math.max(1, Math.round(cssW * dpr)), bh = Math.max(1, Math.round(cssH * dpr));
    if (canvas.style.width !== cssW + 'px') canvas.style.width = cssW + 'px';
    if (canvas.style.height !== cssH + 'px') canvas.style.height = cssH + 'px';
    if (canvas.width !== bw) canvas.width = bw;
    if (canvas.height !== bh) canvas.height = bh;
    SX = bw / W; SY = bh / H;
  }
  fitCanvas();
  // pre-rendered specimen images are made at the backing resolution (capped at 2x) so they stay sharp too
  const imgScale = () => Math.max(1, Math.min(2, Math.round(SX * 4) / 4));

  /* ── save ─────────────────────────────────────────────────────────────────────── */
  const SAVE_KEY = 'noctuary.save.v1';
  let save = { solved: {}, marks: {} };
  // a save of the wrong shape (null, an array, missing solved/marks) is treated as no save, never thrown on
  // 1.1.0 review D-5: an ARRAY is an object too, and JSON.stringify drops string keys on arrays, so {"solved":[],"marks":[]} used to
  // be accepted and then lose every mark. solved and marks must be plain objects; a single bad plate entry is handled in openPlate.
  const plainObj = (o) => !!o && typeof o === 'object' && !Array.isArray(o);
  const saveShapeOk = (s) => plainObj(s) && plainObj(s.solved) && plainObj(s.marks);
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (raw) { const parsed = JSON.parse(raw); if (saveShapeOk(parsed)) save = parsed; }
  } catch (e) { /* private mode: play unsaved rather than refusing to start */ }
  let saveTimer = null;
  function writeSave() {
    clearTimeout(saveTimer); saveTimer = null;
    try { localStorage.setItem(SAVE_KEY, JSON.stringify(save)); } catch (e) { /* ignore */ }
  }
  function persist() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(writeSave, 300);
  }
  // the 300 ms debounce must not lose the last marks when the page goes away: write at once on pagehide / hidden.
  // Only a PENDING write is flushed: a page with nothing unsaved writes nothing, so closing an old second tab
  // cannot overwrite progress another tab has saved since.
  function flushSave() { if (saveTimer !== null) writeSave(); }
  window.addEventListener('pagehide', flushSave);
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') flushSave(); });

  /* ── state ────────────────────────────────────────────────────────────────────── */
  let screen = 'cabinet';
  let plate = null, board = null, L = null, pal = null, label = null;
  let hover = null, drag = null, dragValue = 0, dragAxis = null, dragOrigin = null;
  let hint = null, hintAlpha = 0;
  let develop = 0, revealT = 0;
  let wrongCells = null, wrongAlpha = 0;
  let toast = '', toastAlpha = 0;
  let thumbCache = {};

  /* ══════════════════════════════════════════════════════════════════════════════════
   * THE DEMO SPLIT.
   *
   * itch CANNOT SELL A BROWSER-PLAYABLE GAME — its own docs are explicit that all HTML5
   * games take payments as donations only. So the shape that makes a paid product possible
   * on this storefront is a free web demo and a paid desktop download on ONE listing page,
   * and this is where that split lives.
   *
   * The demo is the first TWO drawers: 24 plates, 10x10 and 15x15, both sizes, the full
   * loop, the reveal, the cabinet and the naming system. Wing §1 requires "a real vertical
   * slice, not a teaser — it ends where the buying decision is honestly made", and a demo
   * that stops before the game becomes interesting converts curiosity into a no. 24 of 66
   * is generous on purpose: what is behind the wall is MORE and HARDER, not the good part.
   * ════════════════════════════════════════════════════════════════════════════════ */
  const EDITION = (typeof window !== 'undefined' && window.NOCTUARY_EDITION) || 'full';
  const IS_DEMO = EDITION === 'demo';
  const DEMO_DRAWERS = 2;

  const drawerFlat = [];
  for (const d of PUZ.DRAWERS) {
    for (let i = 0; i < d.count; i++) drawerFlat.push({ drawer: d.id, index: i, def: d });
  }
  const keyOf = (e) => e.drawer + ':' + e.index;
  const drawerLocked = (di) => IS_DEMO && di >= DEMO_DRAWERS;

  /* ══════════════════════════════════════════════════════════════════════════════════
   * THE CABINET — ONE DRAWER AT A TIME.
   *
   * ⛔ The first version tiled all 66 mounts on one screen at 11 columns, and looking at
   * the render killed it on three counts at once. Drawer boundaries fell MID-ROW, so
   * "SECOND DRAWER 15×15" printed on top of the cards next to it. Six rows of 118px
   * overflowed an 800px canvas, so The Night Case was cut off the bottom edge. And 66
   * identical dark empty mounts at 100px is simply not a thing anyone wants to look at.
   *
   * One drawer at a time fixes all three and is what you actually DO with a specimen
   * cabinet: you pull out a drawer. It also more than doubles the thumbnail size, which
   * matters more than the layout does — the specimens are the product, and at 72px they
   * were postage stamps.
   * ════════════════════════════════════════════════════════════════════════════════ */
  const CAB = { cols: 6, x: 94, y: 292, cw: 182, ch: 210, cardw: 168, cardh: 196 };
  let openDrawer = 0;
  const TABS = [];

  function drawerEntries(di) {
    const d = PUZ.DRAWERS[di];
    return drawerFlat.filter((e) => e.drawer === d.id);
  }

  function cabinetHit(mx, my) {
    if (drawerLocked(openDrawer)) return null;   // nothing is drawn there, so nothing is clickable
    const ents = drawerEntries(openDrawer);
    for (let i = 0; i < ents.length; i++) {
      const cx = CAB.x + (i % CAB.cols) * CAB.cw;
      const cy = CAB.y + Math.floor(i / CAB.cols) * CAB.ch;
      if (mx >= cx && mx < cx + CAB.cardw && my >= cy && my < cy + CAB.cardh) return ents[i];
    }
    return null;
  }

  function tabHit(mx, my) {
    for (const t of TABS) {
      if (mx >= t.x && mx <= t.x + t.w && my >= t.y && my <= t.y + t.h) return t.i;
    }
    return -1;
  }

  /* Thumbnails are rendered ONCE per specimen and cached. 66 continuous renders every
   * frame would be a slideshow; 66 renders once is imperceptible. */
  function thumbFor(entry) {
    const sc = imgScale();
    const k = keyOf(entry) + '@' + sc;
    if (thumbCache[k]) return thumbCache[k];
    const p = PUZ.drawerPlate(entry.drawer, entry.index);
    const off = document.createElement('canvas');
    off.width = Math.round(140 * sc); off.height = Math.round(130 * sc);
    const o = off.getContext('2d');
    o.putImageData(REVEAL.renderSpecimen(o, p.genotype, off.width, off.height, { ss: 2 }), 0, 0);
    thumbCache[k] = off;
    return off;
  }

  function drawCabinet() {
    ctx.fillStyle = '#15130f';
    ctx.fillRect(0, 0, W, H);

    // a faint vignette so the cards read as lit rather than pasted on
    const vg = ctx.createRadialGradient(W / 2, H / 2, 200, W / 2, H / 2, 780);
    vg.addColorStop(0, 'rgba(255,240,210,0.055)');
    vg.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, W, H);

    // In the demo, count the plates the player can actually reach. Showing "0 of 66" in a
    // build that contains 24 makes the demo look broken rather than partial.
    const reachable = drawerFlat.filter((e) => !drawerLocked(PUZ.DRAWERS.findIndex((d) => d.id === e.drawer)));
    const total = reachable.length;
    let done = 0;
    for (const e of reachable) if (save.solved[keyOf(e)]) done++;

    ctx.textAlign = 'left';
    ctx.fillStyle = '#e8dcc4';
    ctx.font = '300 46px ' + FONTS.serif;
    ctx.fillText('NOCTUARY', 60, 78);
    ctx.font = 'italic 300 18px ' + FONTS.serif;
    ctx.fillStyle = 'rgba(232,220,196,0.52)';
    ctx.fillText('a record of what happens in the night', 60, 106);
    // the finale (1.1.0): a full cabinet says so, and a finished demo says what is left
    if (total > 0 && done === total) {
      ctx.font = 'italic 300 16px ' + FONTS.serif;
      ctx.fillStyle = '#c8a86a';
      ctx.fillText(IS_DEMO
        ? 'Both demo drawers are full. Forty-two more specimens wait in the full cabinet.'
        : 'The cabinet is complete. Sixty-six specimens, every one drawn by your hand.', 60, 140);
    }

    ctx.textAlign = 'right';
    ctx.font = '300 16px ' + FONTS.mono;
    ctx.fillStyle = 'rgba(232,220,196,0.75)';
    ctx.fillText(done + ' of ' + total + ' specimens mounted' + (IS_DEMO ? '  ·  DEMO' : ''), W - 60, 78);
    ctx.fillStyle = 'rgba(232,220,196,0.40)';
    ctx.font = '300 13px ' + FONTS.mono;
    ctx.fillText(AUDIO.isMuted() ? 'sound off  (M)' : 'sound on  (M)', W - 60, 104);

    /* ── drawer tabs ── */
    TABS.length = 0;
    let tx = 60;
    for (let i = 0; i < PUZ.DRAWERS.length; i++) {
      const d = PUZ.DRAWERS[i];
      const ents = drawerEntries(i);
      let dn = 0;
      for (const e of ents) if (save.solved[keyOf(e)]) dn++;

      ctx.font = '300 13px ' + FONTS.mono;
      const tw = ctx.measureText(d.label).width + 40;
      const isOpen = i === openDrawer;
      const hot = hover && hover.tab === i;
      TABS.push({ i, x: tx, y: 168, w: tw, h: 46 });

      const locked = drawerLocked(i);
      ctx.fillStyle = isOpen ? 'rgba(232,220,196,0.115)' : (hot ? 'rgba(232,220,196,0.06)' : 'rgba(232,220,196,0.025)');
      BOARD.roundRect(ctx, tx, 168, tw, 46, 2);
      ctx.fill();
      if (isOpen) {
        ctx.fillStyle = '#c8a86a';
        ctx.fillRect(tx, 168, tw, 2);
      }
      ctx.textAlign = 'center';
      ctx.font = '300 13px ' + FONTS.mono;
      ctx.fillStyle = locked ? 'rgba(232,220,196,0.26)'
                             : (isOpen ? 'rgba(240,232,214,0.95)' : 'rgba(232,220,196,0.48)');
      ctx.fillText(d.label, tx + tw / 2, 191);
      ctx.font = '300 10px ' + FONTS.mono;
      if (locked) {
        ctx.fillStyle = 'rgba(232,220,196,0.24)';
        ctx.fillText('FULL CABINET   ' + d.size + '×' + d.size, tx + tw / 2, 206);
      } else {
        ctx.fillStyle = dn === ents.length ? '#c8a86a' : 'rgba(232,220,196,0.34)';
        ctx.fillText(dn + '/' + ents.length + '   ' + d.size + '×' + d.size, tx + tw / 2, 206);
      }
      tx += tw + 8;
    }

    /* ── a locked drawer shows what is behind the wall, honestly ── */
    if (drawerLocked(openDrawer)) {
      const d = PUZ.DRAWERS[openDrawer];
      ctx.textAlign = 'center';
      ctx.font = '300 34px ' + FONTS.serif;
      ctx.fillStyle = 'rgba(240,232,214,0.90)';
      ctx.fillText('This drawer is in the full cabinet.', W / 2, 400);
      ctx.font = 'italic 300 19px ' + FONTS.serif;
      ctx.fillStyle = 'rgba(232,220,196,0.52)';
      wrapText(ctx,
        'The demo holds the first two drawers — twenty-four plates at 10×10 and 15×15, the ' +
        'whole loop and every part of the system. The full cabinet adds forty-two more, at ' +
        '15×15 and 20×20, including the ten exacting plates of The Night Case.',
        W / 2 - 380, 448, 760, 30, true);
      ctx.font = '300 14px ' + FONTS.mono;
      ctx.fillStyle = '#c8a86a';
      ctx.fillText(d.label.toUpperCase() + '   ·   ' + d.count + ' PLATES   ·   ' + d.size + '×' + d.size,
                   W / 2, 566);
      ctx.font = '300 13px ' + FONTS.mono;
      ctx.fillStyle = 'rgba(232,220,196,0.34)';
      ctx.fillText('the full cabinet is a download on this game’s page', W / 2, 604);
      ctx.textAlign = 'center';
      ctx.font = '300 13px ' + FONTS.mono;
      ctx.fillStyle = 'rgba(232,220,196,0.30)';
      // this screen has no mounts; Esc and H do nothing here, the tabs above are the only thing to click
      ctx.fillText('the First and Second Drawers above are open in the demo', W / 2, H - 34);
      drawCreditsLink();
      return;
    }

    /* ── the open drawer's mounts ── */
    const ents = drawerEntries(openDrawer);
    for (let i = 0; i < ents.length; i++) {
      const e = ents[i];
      const cx = CAB.x + (i % CAB.cols) * CAB.cw;
      const cy = CAB.y + Math.floor(i / CAB.cols) * CAB.ch;
      const solved = !!save.solved[keyOf(e)];
      const hot = hover && hover.mount && keyOf(hover.mount) === keyOf(e);

      ctx.save();
      if (hot) ctx.translate(0, -4);

      const p = solved ? PUZ.drawerPlate(e.drawer, e.index) : null;
      const cardPal = p ? REVEAL.paletteOf(p.genotype.palette) : { wash: '#292620', ink: '#15130f', accent: '#6b5e46' };

      ctx.shadowColor = 'rgba(0,0,0,0.55)';
      // shadow blur and offset are in DEVICE pixels (the transform does not scale them)
      ctx.shadowBlur = (hot ? 22 : 10) * SX;
      ctx.shadowOffsetY = (hot ? 8 : 4) * SY;
      ctx.fillStyle = cardPal.wash;
      BOARD.roundRect(ctx, cx, cy, CAB.cardw, CAB.cardh, 3);
      ctx.fill();
      ctx.shadowColor = 'transparent'; ctx.shadowBlur = 0; ctx.shadowOffsetY = 0;

      // inset hairline, on every card, solved or not — it is what makes them read as
      // printed mounts rather than as rounded rectangles
      ctx.strokeStyle = solved ? 'rgba(0,0,0,0.17)' : 'rgba(232,220,196,0.07)';
      ctx.lineWidth = 1;
      BOARD.roundRect(ctx, cx + 7.5, cy + 7.5, CAB.cardw - 15, CAB.cardh - 15, 2);
      ctx.stroke();

      if (solved) {
        ctx.drawImage(thumbFor(e), cx + 14, cy + 12, 140, 130);
        const lab = NAMES.label(p.genotype);
        ctx.textAlign = 'center';
        ctx.strokeStyle = 'rgba(0,0,0,0.18)';
        ctx.beginPath();
        ctx.moveTo(cx + 24, cy + 150); ctx.lineTo(cx + CAB.cardw - 24, cy + 150);
        ctx.stroke();
        ctx.font = 'italic 600 11px ' + FONTS.serif;
        ctx.fillStyle = 'rgba(0,0,0,0.74)';
        ctx.fillText(fit(ctx, lab.binomial, CAB.cardw - 26), cx + CAB.cardw / 2, cy + 166);
        ctx.font = '9px ' + FONTS.mono;
        ctx.fillStyle = cardPal.accent;
        ctx.fillText(lab.catalogue, cx + CAB.cardw / 2, cy + 181);
      } else {
        // an empty mount: the pin is there and the specimen is not
        const mx = cx + CAB.cardw / 2, my = cy + 78;
        ctx.strokeStyle = 'rgba(232,220,196,0.17)';
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(mx, my - 34); ctx.lineTo(mx, my + 6); ctx.stroke();
        ctx.beginPath(); ctx.arc(mx, my - 38, 5, 0, Math.PI * 2); ctx.stroke();
        ctx.beginPath(); ctx.arc(mx, my, 26, 0, Math.PI * 2);
        ctx.setLineDash([2, 5]);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.textAlign = 'center';
        ctx.font = '300 10px ' + FONTS.mono;
        ctx.fillStyle = 'rgba(232,220,196,0.26)';
        ctx.fillText('UNMOUNTED', mx, cy + 166);
        ctx.fillText(e.def.size + ' × ' + e.def.size, mx, cy + 181);
      }

      if (hot) {
        ctx.strokeStyle = solved ? cardPal.accent : 'rgba(232,220,196,0.55)';
        ctx.lineWidth = 2;
        BOARD.roundRect(ctx, cx - 1, cy - 1, CAB.cardw + 2, CAB.cardh + 2, 3);
        ctx.stroke();
      }
      ctx.restore();
    }

    ctx.textAlign = 'center';
    ctx.font = '300 13px ' + FONTS.mono;
    ctx.fillStyle = 'rgba(232,220,196,0.30)';
    ctx.fillText('click a mount to work its plate', W / 2, H - 34);
    drawCreditsLink();
  }

  /* ── credits (1.1.0) ─────────────────────────────────────────────────────────────
   * The AI disclosure belongs inside the game, not only in a file beside it: the free demo's
   * player never sees CREDITS.md. C (or the link) opens it from the cabinet; C, Esc or a click
   * closes it. */
  const VERSION = '1.1.0';
  let showCredits = false;
  let creditsHit = null;
  function drawCreditsLink() {
    ctx.textAlign = 'right';
    ctx.font = '300 13px ' + FONTS.mono;
    const t = 'credits  (C)';
    const tw = ctx.measureText(t).width;
    const hot = hover && hover.credits;
    ctx.fillStyle = hot ? 'rgba(232,220,196,0.70)' : 'rgba(232,220,196,0.36)';
    ctx.fillText(t, W - 60, H - 34);
    creditsHit = { x: W - 60 - tw - 8, y: H - 34 - 14, w: tw + 16, h: 24 };
  }
  const CREDIT_LINES = [
    ['Made by', 'Core Systems Asset Factory'],
    // 1.1.0 review D-2: these say what LICENSE.txt and CREDITS.md say. Every line of code and every note of the score was written by an AI.
    ['Code', 'written by an AI'],
    ['Specimens', 'drawn at runtime by the game’s own code, not from image files'],
    ['Names + journal', 'generated from a vocabulary written as data by an AI'],
    ['Music + sound', 'composed as note data by an AI; oscillators, no samples'],
    ['Third-party', 'none in the game; the Windows build runs in Electron (MIT)']
  ];
  function drawCredits() {
    ctx.fillStyle = 'rgba(10,9,7,0.78)';
    ctx.fillRect(0, 0, W, H);
    const cw = 760, ch = 470, cx = (W - cw) / 2, cy = (H - ch) / 2;
    ctx.shadowColor = 'rgba(0,0,0,0.6)'; ctx.shadowBlur = 30 * SX; ctx.shadowOffsetY = 10 * SY;
    ctx.fillStyle = '#1d1a15';
    BOARD.roundRect(ctx, cx, cy, cw, ch, 4);
    ctx.fill();
    ctx.shadowColor = 'transparent'; ctx.shadowBlur = 0; ctx.shadowOffsetY = 0;
    ctx.strokeStyle = 'rgba(200,168,106,0.35)';
    ctx.lineWidth = 1;
    BOARD.roundRect(ctx, cx + 10.5, cy + 10.5, cw - 21, ch - 21, 2);
    ctx.stroke();

    ctx.textAlign = 'center';
    ctx.font = '300 34px ' + FONTS.serif;
    ctx.fillStyle = '#e8dcc4';
    ctx.fillText('NOCTUARY', W / 2, cy + 70);
    ctx.font = '300 12px ' + FONTS.mono;
    ctx.fillStyle = '#c8a86a';
    ctx.fillText('CREDITS   ·   VERSION ' + VERSION + (IS_DEMO ? '   ·   FREE DEMO' : ''), W / 2, cy + 98);

    let y = cy + 150;
    for (const [k, v] of CREDIT_LINES) {
      ctx.textAlign = 'right';
      ctx.font = '300 12px ' + FONTS.mono;
      ctx.fillStyle = 'rgba(232,220,196,0.42)';
      ctx.fillText(k.toUpperCase(), cx + 230, y);
      ctx.textAlign = 'left';
      ctx.font = 'italic 300 17px ' + FONTS.serif;
      ctx.fillStyle = 'rgba(232,220,196,0.88)';
      ctx.fillText(v, cx + 250, y);
      y += 40;
    }
    ctx.textAlign = 'center';
    ctx.font = '300 12px ' + FONTS.mono;
    ctx.fillStyle = 'rgba(232,220,196,0.40)';
    // 1.1.0 review D-8: the itch-embedded demo cannot open a file, so its card says where the notes are
    ctx.fillText('Copyright (c) 2026 Core Systems Asset Factory  ·  full notes: CREDITS.md' + (IS_DEMO ? ' in the paid download' : ''), W / 2, cy + ch - 62);
    ctx.fillStyle = 'rgba(232,220,196,0.30)';
    ctx.fillText('C, Esc or a click closes this', W / 2, cy + ch - 34);
  }

  /* Truncate to fit rather than overflow the card. A binomial that runs off the mount is
   * the same defect as a clue that runs off the gutter. */
  function fit(c, text, maxW) {
    if (c.measureText(text).width <= maxW) return text;
    let s = text;
    while (s.length > 4 && c.measureText(s + '.').width > maxW) s = s.slice(0, -1);
    return s + '.';
  }

  /* ── plate ────────────────────────────────────────────────────────────────────── */
  function openPlate(entry) {
    plate = PUZ.drawerPlate(entry.drawer, entry.index);
    plate.entry = entry;
    pal = REVEAL.paletteOf(plate.genotype.palette);
    label = NAMES.label(plate.genotype);
    const k = keyOf(entry);
    const saved = save.marks[k];
    // 1.1.0 review D-5: a saved entry is used only if it is a size x size grid of arrays; a string of the right length used to reach
    // .map and throw, so that plate could never be opened. Anything else starts the plate clean.
    const savedOk = Array.isArray(saved) && saved.length === plate.size &&
      saved.every((row) => Array.isArray(row) && row.length === plate.size);
    board = savedOk ? saved.map((row) => row.slice()) : BOARD.makeBoard(plate.size);
    L = BOARD.layout(plate.clues, { x: 290, y: 84, w: 940, h: 672 });
    hint = null; hintAlpha = 0; wrongCells = null; wrongAlpha = 0;
    toast = ''; toastAlpha = 0;          // a message from the previous plate must not show on this one
    screen = 'plate';
    AUDIO.playMusic('plate');
    AUDIO.play('open');
  }

  function drawPlate() {
    ctx.fillStyle = '#15130f';
    ctx.fillRect(0, 0, W, H);
    const vg = ctx.createRadialGradient(660, 400, 160, 660, 400, 720);
    vg.addColorStop(0, 'rgba(255,240,210,0.06)');
    vg.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, W, H);

    BOARD.draw(ctx, L, plate.clues, board, pal, FONTS,
               { hover: hover && hover.r != null ? hover : null, hint: hint, hintAlpha: hintAlpha });

    // wrong-cell overlay from EXAMINE
    if (wrongCells && wrongAlpha > 0) {
      ctx.save();
      ctx.globalAlpha = wrongAlpha;
      ctx.strokeStyle = '#b5462c';
      ctx.lineWidth = 2;
      for (const c of wrongCells) {
        ctx.strokeRect(L.gx + c.c * L.cell + 1, L.gy + c.r * L.cell + 1, L.cell - 2, L.cell - 2);
      }
      ctx.restore();
    }

    // side panel
    ctx.textAlign = 'left';
    ctx.fillStyle = 'rgba(232,220,196,0.92)';
    ctx.font = '300 26px ' + FONTS.serif;
    ctx.fillText(plate.entry.def.label, 60, 120);
    ctx.font = '300 13px ' + FONTS.mono;
    ctx.fillStyle = 'rgba(232,220,196,0.44)';
    ctx.fillText('PLATE ' + (plate.entry.index + 1) + '  ·  ' + plate.size + '×' + plate.size, 60, 146);
    ctx.fillText(plate.difficulty.grade.toUpperCase(), 60, 166);

    ctx.fillStyle = 'rgba(232,220,196,0.30)';
    ctx.font = 'italic 300 14px ' + FONTS.serif;
    wrapText(ctx, 'The plate is unlabelled. It is identified once it is drawn.', 60, 210, 190, 20);

    const filled = countFilled();
    const need = countNeeded();
    ctx.font = '300 13px ' + FONTS.mono;
    ctx.fillStyle = 'rgba(232,220,196,0.55)';
    ctx.fillText(filled + ' / ' + need + ' marked', 60, 300);

    button(60, 620, 190, 40, 'THE READING', 'one real deduction');
    button(60, 672, 190, 40, 'EXAMINE', 'find wrong marks');
    button(60, 724, 190, 40, 'BACK  (Esc)', '');

    ctx.textAlign = 'center';
    ctx.font = '300 12px ' + FONTS.mono;
    ctx.fillStyle = 'rgba(232,220,196,0.28)';
    ctx.fillText('left drag fills  ·  right drag crosses  ·  ' +
                 (AUDIO.isMuted() ? 'sound off  (M)' : 'sound on  (M)'), 660, H - 22);

    if (toastAlpha > 0) {
      ctx.globalAlpha = toastAlpha;
      ctx.font = '300 15px ' + FONTS.mono;
      ctx.fillStyle = pal.accent;
      ctx.fillText(toast, 660, 66);
      ctx.globalAlpha = 1;
    }
  }

  const BUTTONS = [];
  function button(x, y, w, h, text, sub) {
    BUTTONS.push({ x, y, w, h, text });
    const hot = hover && hover.btn === text;
    ctx.fillStyle = hot ? 'rgba(232,220,196,0.13)' : 'rgba(232,220,196,0.05)';
    BOARD.roundRect(ctx, x, y, w, h, 2);
    ctx.fill();
    ctx.strokeStyle = hot ? 'rgba(232,220,196,0.45)' : 'rgba(232,220,196,0.16)';
    ctx.lineWidth = 1;
    BOARD.roundRect(ctx, x + 0.5, y + 0.5, w - 1, h - 1, 2);
    ctx.stroke();
    ctx.textAlign = 'left';
    ctx.font = '300 13px ' + FONTS.mono;
    ctx.fillStyle = 'rgba(232,220,196,0.85)';
    ctx.fillText(text, x + 14, y + (sub ? 18 : 25));
    if (sub) {
      ctx.font = '300 10px ' + FONTS.mono;
      ctx.fillStyle = 'rgba(232,220,196,0.35)';
      ctx.fillText(sub, x + 14, y + 32);
    }
  }

  function countFilled() {
    let n = 0;
    for (const row of board) for (const v of row) if (v === BOARD.FILLED) n++;
    return n;
  }
  function countNeeded() {
    let n = 0;
    for (const row of plate.grid) for (const v of row) if (v) n++;
    return n;
  }

  /* ── the two tools, and why each is honest ────────────────────────────────────── */

  /*
   * THE READING — a hint that is a real deduction from the player's OWN board, computed by
   * the same line solver that guaranteed the puzzle was fair in the first place. It is
   * never read off the answer key. That matters: it means the hint can only ever tell you
   * something your board already implies, so taking one is not cheating, it is being
   * shown the step you missed.
   */
  function takeReading() {
    const d = SOLV.nextDeduction(plate.clues, board);
    if (!d) { flash('nothing further is deducible'); return; }
    board[d.row][d.col] = d.value;
    hint = d; hintAlpha = 1;
    AUDIO.play('hint');
    flash(d.value === BOARD.FILLED ? 'a mark, on the ' + d.kind : 'a blank, on the ' + d.kind);
    afterChange();
  }

  /*
   * EXAMINE — marks cells you have FILLED that the specimen does not contain. It reads the
   * answer, and it only ever removes information the player added wrongly; it never adds
   * information they had not earned. A tool that filled in correct cells would be a
   * different game.
   */
  function examine() {
    const bad = [];
    for (let r = 0; r < plate.size; r++) {
      for (let c = 0; c < plate.size; c++) {
        if (board[r][c] === BOARD.FILLED && !plate.grid[r][c]) bad.push({ r, c });
      }
    }
    wrongCells = bad; wrongAlpha = 1;
    flash(bad.length === 0 ? 'every mark so far is sound' :
          bad.length + ' mark' + (bad.length === 1 ? '' : 's') + ' cannot be right');
    AUDIO.play(bad.length ? 'erase' : 'line');
  }

  function flash(t) { toast = t; toastAlpha = 1; }

  function afterChange() {
    save.marks[keyOf(plate.entry)] = board.map((r) => r.slice());
    persist();
    if (BOARD.isComplete(board, plate.grid)) {
      save.solved[keyOf(plate.entry)] = true;
      delete save.marks[keyOf(plate.entry)];
      persist();
      screen = 'reveal';
      develop = 0; revealT = 0;
      AUDIO.play('reveal');
    }
  }

  /* ── reveal ───────────────────────────────────────────────────────────────────── */
  function drawReveal(dt) {
    revealT += dt;
    develop = Math.min(1, Math.max(0, (revealT - 0.35) / 1.9));

    ctx.fillStyle = '#15130f';
    ctx.fillRect(0, 0, W, H);
    const vg = ctx.createRadialGradient(W / 2, 360, 120, W / 2, 360, 620);
    vg.addColorStop(0, 'rgba(255,240,210,0.09)');
    vg.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, W, H);

    REVEAL.drawMountedPlate(ctx, plate.genotype, plate.grid, label,
                            { x: W / 2 - 220, y: 62, w: 440, h: 592 }, develop, FONTS);

    /*
     * ⛔ THE FLANKING COLUMNS ARE NOT DECORATION — they fix a real Gate 1 defect and add
     * a real mechanic at the same time.
     *
     * The reveal originally showed a card centred on a 1280x800 black field and nothing
     * else. It measured the lowest ink density of any store image in the set (0.248), and
     * ~60% of the frame carried nothing — the remediation doc calls >20% empty a Gate 1
     * failure outright. The lazy fix is to crop the store image tighter, which leaves the
     * actual screen just as empty for the player.
     *
     * The right column lists THIS specimen's six organs by name. That is the payoff for
     * the naming system: the binomial is derived from the forewing, antenna and pattern,
     * so seeing "falcate / ocellus / plumose" beside "Plumfalcaria ocellata" is the moment
     * a player realises the labels are readable rather than decorative. It is the cheapest
     * depth in the product and it was sitting unused in the genotype.
     */
    if (develop > 0.78) {
      const a = Math.min(1, (develop - 0.78) / 0.22);
      ctx.globalAlpha = a;

      const LX = 150, RX = W - 150;

      ctx.textAlign = 'left';
      ctx.font = '300 12px ' + FONTS.mono;
      ctx.fillStyle = pal.accent;
      ctx.fillText('MOUNTED', LX, 140);
      ctx.fillStyle = 'rgba(232,220,196,0.85)';
      ctx.font = '300 26px ' + FONTS.serif;
      ctx.fillText(plate.entry.def.label, LX, 174);
      ctx.font = '300 12px ' + FONTS.mono;
      ctx.fillStyle = 'rgba(232,220,196,0.42)';
      ctx.fillText('PLATE ' + (plate.entry.index + 1) + '  ·  ' + plate.size + '×' + plate.size, LX, 200);
      ctx.fillText(plate.difficulty.grade.toUpperCase(), LX, 220);

      const reach = drawerFlat.filter((e) => !drawerLocked(PUZ.DRAWERS.findIndex((d) => d.id === e.drawer)));
      let done = 0;
      for (const e of reach) if (save.solved[keyOf(e)]) done++;
      ctx.fillStyle = 'rgba(232,220,196,0.30)';
      ctx.fillText('THE CABINET', LX, 296);
      ctx.font = '300 40px ' + FONTS.serif;
      ctx.fillStyle = '#e8dcc4';
      ctx.fillText(done + ' / ' + reach.length, LX, 342);
      // a slim progress rule, because a fraction is a number and a bar is a shape
      ctx.fillStyle = 'rgba(232,220,196,0.14)';
      ctx.fillRect(LX, 362, 190, 3);
      ctx.fillStyle = pal.accent;
      ctx.fillRect(LX, 362, 190 * (done / reach.length), 3);

      ctx.textAlign = 'right';
      ctx.font = '300 12px ' + FONTS.mono;
      ctx.fillStyle = pal.accent;
      ctx.fillText('MORPHOLOGY', RX, 140);
      const g = plate.genotype;
      const organs = [
        ['forewing', g.forewing], ['hindwing', g.hindwing], ['pattern', g.pattern],
        ['antenna', g.antenna], ['body', g.body], ['margin', g.margin]
      ];
      let oy = 174;
      for (const [k, v] of organs) {
        ctx.font = '300 11px ' + FONTS.mono;
        ctx.fillStyle = 'rgba(232,220,196,0.30)';
        ctx.fillText(k.toUpperCase(), RX, oy);
        ctx.font = 'italic 300 19px ' + FONTS.serif;
        ctx.fillStyle = 'rgba(232,220,196,0.86)';
        ctx.fillText(String(v).replace(/_/g, ' '), RX, oy + 22);
        oy += 50;
      }
      ctx.font = '300 11px ' + FONTS.mono;
      ctx.fillStyle = 'rgba(232,220,196,0.26)';
      ctx.fillText('SIX ORGANS OF FIFTY-SIX MARKS', RX, oy + 8);

      ctx.textAlign = 'center';
      ctx.font = 'italic 300 16px ' + FONTS.serif;
      ctx.fillStyle = 'rgba(232,220,196,0.62)';
      wrapText(ctx, label.journal, W / 2 - 330, 700, 660, 24, true);
      ctx.font = '300 13px ' + FONTS.mono;
      ctx.fillStyle = 'rgba(232,220,196,0.32)';
      ctx.fillText('click to return to the cabinet', W / 2, H - 34);
      ctx.globalAlpha = 1;
    }
  }

  function wrapText(c, text, x, y, maxW, lh, centred) {
    const words = String(text).split(' ');
    let line = '', yy = y;
    for (const w of words) {
      const test = line ? line + ' ' + w : w;
      if (c.measureText(test).width > maxW && line) {
        c.fillText(line, centred ? x + maxW / 2 : x, yy);
        line = w; yy += lh;
      } else line = test;
    }
    if (line) c.fillText(line, centred ? x + maxW / 2 : x, yy);
  }

  /* ── input ────────────────────────────────────────────────────────────────────── */
  function pos(ev) {
    const r = canvas.getBoundingClientRect();
    return { x: (ev.clientX - r.left) * (W / r.width), y: (ev.clientY - r.top) * (H / r.height) };
  }

  canvas.addEventListener('contextmenu', (e) => e.preventDefault());

  canvas.addEventListener('mousemove', function (ev) {
    const p = pos(ev);
    if (screen === 'cabinet') {
      if (showCredits) { hover = null; return; }
      const t = tabHit(p.x, p.y);
      const m = cabinetHit(p.x, p.y);
      const cr = creditsHit && p.x >= creditsHit.x && p.x <= creditsHit.x + creditsHit.w &&
                 p.y >= creditsHit.y && p.y <= creditsHit.y + creditsHit.h;
      hover = t >= 0 ? { tab: t } : (m ? { mount: m } : (cr ? { credits: true } : null));
      return;
    }
    if (screen !== 'plate') { hover = null; return; }
    const cell = BOARD.cellAt(L, p.x, p.y);
    let btn = null;
    for (const b of BUTTONS) {
      if (p.x >= b.x && p.x <= b.x + b.w && p.y >= b.y && p.y <= b.y + b.h) btn = b.text;
    }
    hover = cell ? { r: cell.r, c: cell.c } : (btn ? { btn } : null);
    if (drag && cell) paintDrag(cell);
  });

  canvas.addEventListener('mouseleave', function () { hover = null; drag = null; });

  canvas.addEventListener('mousedown', function (ev) {
    AUDIO.start();
    const p = pos(ev);

    if (screen === 'cabinet') {
      if (showCredits) { showCredits = false; hover = null; AUDIO.play('back'); return; }
      if (creditsHit && p.x >= creditsHit.x && p.x <= creditsHit.x + creditsHit.w &&
          p.y >= creditsHit.y && p.y <= creditsHit.y + creditsHit.h) {
        showCredits = true; hover = null; AUDIO.play('open'); return;
      }
      const t = tabHit(p.x, p.y);
      if (t >= 0) { openDrawer = t; hover = null; AUDIO.play('open'); return; }
      const m = cabinetHit(p.x, p.y);
      if (m) { openPlate(m); fade = 1; }
      return;
    }
    if (screen === 'reveal') {
      if (develop > 0.85) { screen = 'cabinet'; hover = null; fade = 1; AUDIO.playMusic('cabinet'); AUDIO.play('back'); }
      return;
    }

    for (const b of BUTTONS) {
      if (p.x >= b.x && p.x <= b.x + b.w && p.y >= b.y && p.y <= b.y + b.h) {
        if (b.text === 'THE READING') takeReading();
        else if (b.text === 'EXAMINE') examine();
        else { screen = 'cabinet'; hover = null; fade = 1; AUDIO.playMusic('cabinet'); AUDIO.play('back'); }
        return;
      }
    }

    const cell = BOARD.cellAt(L, p.x, p.y);
    if (!cell) return;
    const cur = board[cell.r][cell.c];
    const want = ev.button === 2 ? BOARD.CROSSED : BOARD.FILLED;
    // clicking a cell that already holds the value you are applying ERASES it
    dragValue = (cur === want) ? BOARD.UNKNOWN : want;
    drag = true; dragAxis = null; dragOrigin = cell;
    applyCell(cell.r, cell.c);
  });

  window.addEventListener('mouseup', function () { drag = null; dragAxis = null; });

  /*
   * Drag locks to a row or a column after the second cell. Without the lock a diagonal
   * wobble fills a staircase of cells the player did not mean, and on a 20x20 that is the
   * single most common source of a wrong grid.
   */
  function paintDrag(cell) {
    if (!dragOrigin) return;
    if (!dragAxis && (cell.r !== dragOrigin.r || cell.c !== dragOrigin.c)) {
      dragAxis = (cell.r === dragOrigin.r) ? 'row' : (cell.c === dragOrigin.c ? 'col' : null);
      if (!dragAxis) return;
    }
    if (dragAxis === 'row' && cell.r !== dragOrigin.r) return;
    if (dragAxis === 'col' && cell.c !== dragOrigin.c) return;
    applyCell(cell.r, cell.c);
  }

  function applyCell(r, c) {
    if (board[r][c] === dragValue) return;
    const before = board[r][c];
    board[r][c] = dragValue;
    if (dragValue === BOARD.FILLED) AUDIO.play('fill');
    else if (dragValue === BOARD.CROSSED) AUDIO.play('cross');
    else AUDIO.play('erase');
    if (wrongCells) { wrongCells = null; wrongAlpha = 0; }

    // a small confirmation when a line's clue becomes satisfied
    if (before !== BOARD.FILLED && dragValue === BOARD.FILLED) {
      const col = [];
      for (let i = 0; i < plate.size; i++) col.push(board[i][c]);
      if (BOARD.clueSatisfied(plate.clues.rows[r], board[r]) ||
          BOARD.clueSatisfied(plate.clues.cols[c], col)) AUDIO.play('line');
    }
    afterChange();
  }

  window.addEventListener('keydown', function (ev) {
    AUDIO.start();
    if (ev.key === 'm' || ev.key === 'M') { AUDIO.setMuted(!AUDIO.isMuted()); return; }
    if ((ev.key === 'c' || ev.key === 'C') && screen === 'cabinet') {
      showCredits = !showCredits; hover = null; AUDIO.play(showCredits ? 'open' : 'back'); return;
    }
    if (ev.key === 'Escape' && screen === 'cabinet' && showCredits) { showCredits = false; AUDIO.play('back'); return; }
    if (ev.key === 'Escape' && screen === 'plate') { screen = 'cabinet'; hover = null; fade = 1; AUDIO.playMusic('cabinet'); AUDIO.play('back'); }
    // 1.1.0 review D-9: the Readme says Esc goes back to the cabinet; on the reveal it did nothing. Same condition as the click.
    if (ev.key === 'Escape' && screen === 'reveal' && develop > 0.85) { screen = 'cabinet'; hover = null; fade = 1; AUDIO.playMusic('cabinet'); AUDIO.play('back'); }
    if ((ev.key === 'h' || ev.key === 'H') && screen === 'plate') takeReading();
  });

  /* ── loop ─────────────────────────────────────────────────────────────────────── */
  let last = 0;
  // a short fade in from the ground colour on a player's screen change (cabinet <-> plate, reveal -> cabinet)
  let fade = 0;
  function frame(t) {
    const dt = Math.min(0.05, (t - last) / 1000 || 0);
    last = t;
    BUTTONS.length = 0;
    fitCanvas();
    ctx.setTransform(SX, 0, 0, SY, 0, 0);
    // 1.1.0 review D-6: board.js sets textBaseline 'middle' for the clues and nothing reset it, so after the first plate every cabinet,
    // reveal and credits string drew ~0.3 em lower than on a fresh load. Those screens now start from the canvas default every frame.
    // The plate screen is left as it has always drawn in steady state (board.js's 'middle' carried from the previous frame), so the
    // plate layout every harness and store shot measured does not move.
    if (screen !== 'plate') ctx.textBaseline = 'alphabetic';

    if (screen === 'cabinet') { drawCabinet(); if (showCredits) drawCredits(); }
    else if (screen === 'plate') drawPlate();
    else drawReveal(dt);

    if (fade > 0) {
      ctx.fillStyle = 'rgba(21,19,15,' + fade.toFixed(3) + ')';
      ctx.fillRect(0, 0, W, H);
      fade = Math.max(0, fade - dt / 0.15);
    }

    hintAlpha = Math.max(0, hintAlpha - dt * 0.7);
    wrongAlpha = Math.max(0, wrongAlpha - dt * 0.20);
    toastAlpha = Math.max(0, toastAlpha - dt * 0.45);
    requestAnimationFrame(frame);
  }

  /* ══════════════════════════════════════════════════════════════════════════════════
   * TEST SURFACE — used by Internal_Ops/playtest.js.
   *
   * ⛔ SHIPPED ON PURPOSE. The alternative is to playtest a COPY of the game, which is the
   * one thing that guarantees the test cannot catch an assembly failure — script order,
   * a global that never publishes, a click that lands on the wrong cell. Those survive a
   * green unit suite precisely because unit tests never load index.html.
   *
   * It exposes nothing a determined player could not get from the console anyway, and this
   * is a single-player cosy puzzle game with no leaderboard, so there is nothing to
   * protect. Kept small and marked so it is never mistaken for game logic.
   * ════════════════════════════════════════════════════════════════════════════════ */
  window.__noct = () => ({
    screen, develop, fade, credits: showCredits,
    solved: Object.keys(save.solved).length,
    size: plate ? plate.size : null,
    grade: plate ? plate.difficulty.grade : null
  });
  window.__noctCellXY = (r, c) => {
    const rect = canvas.getBoundingClientRect();
    return {
      x: rect.left + (L.gx + c * L.cell + L.cell / 2) * (rect.width / W),
      y: rect.top + (L.gy + r * L.cell + L.cell / 2) * (rect.height / H)
    };
  };
  /*
   * The test asks the GAME where the first mount is rather than hardcoding a coordinate.
   * The first version of playtest.js clicked (100,200); adding drawer tabs moved the
   * mounts down and that click started landing on a tab, so the test reported "clicking a
   * mount did not open a plate" when clicking a mount worked perfectly. A test that
   * hardcodes layout measures the layout, not the behaviour.
   */
  window.__noctFirstMountXY = () => {
    const rect = canvas.getBoundingClientRect();
    return {
      x: rect.left + (CAB.x + CAB.cardw / 2) * (rect.width / W),
      y: rect.top + (CAB.y + CAB.cardh / 2) * (rect.height / H)
    };
  };
  window.__noctCell = (r, c) => board[r][c];
  window.__noctTruth = (r, c) => plate.grid[r][c];
  window.__noctBoardCopy = () => board.map((x) => x.slice());
  window.__noctDiffFrom = (b) => {
    let n = 0;
    for (let r = 0; r < board.length; r++)
      for (let c = 0; c < board.length; c++) if (board[r][c] !== b[r][c]) n++;
    return n;
  };
  /*
   * Drive the reveal transition to an exact point, for deterministic capture.
   *
   * ⛔ Needed because `develop` advances by FRAME COUNT (dt is clamped), and every
   * Playwright screenshot stalls requestAnimationFrame. Capturing the transition in real
   * time therefore produced NINE frames spanning the whole animation — a GIF that jumps
   * rather than develops. Stepping it explicitly is the same principle the factory's MZ
   * capture pipeline uses: step the engine, never wait on rAF.
   *
   * `revealT` is set rather than `develop`, so the frame loop's own arithmetic still owns
   * the value and the capture cannot drift from what a player sees.
   */
  window.__noctSetDevelop = (v) => { revealT = 0.35 + Math.max(0, Math.min(1, v)) * 1.9; };
  window.__noctOpenDrawer = () => openDrawer;
  window.__noctTabXY = (i) => {
    const t = TABS[i];
    const rect = canvas.getBoundingClientRect();
    return { x: rect.left + (t.x + t.w / 2) * (rect.width / W),
             y: rect.top + (t.y + t.h / 2) * (rect.height / H) };
  };
  window.__noctOpenAt = (di, idx) => openPlate(drawerEntries(di)[idx]);
  /* Fill a given FRACTION of the correct cells and cross a proportional share of the
   * blanks, so a capture shows a board mid-solve rather than empty or finished. Uses the
   * answer key deliberately: this is a capture hook, not a game mechanic. */
  window.__noctPartSolve = (frac) => {
    const fills = [], blanks = [];
    for (let r = 0; r < plate.size; r++)
      for (let c = 0; c < plate.size; c++) (plate.grid[r][c] ? fills : blanks).push([r, c]);
    const nf = Math.floor(fills.length * frac);
    const nb = Math.floor(blanks.length * frac * 0.8);
    for (let i = 0; i < nf; i++) board[fills[i][0]][fills[i][1]] = BOARD.FILLED;
    for (let i = 0; i < nb; i++) board[blanks[i][0]][blanks[i][1]] = BOARD.CROSSED;
    save.marks[keyOf(plate.entry)] = board.map((x) => x.slice());
    persist();
  };
  window.__noctReading = () => takeReading();
  window.__noctLastHint = () => hint;
  window.__noctSolveAllButOne = () => {
    let skipped = false;
    for (let r = 0; r < plate.size; r++) {
      for (let c = 0; c < plate.size; c++) {
        if (plate.grid[r][c]) {
          if (!skipped) { skipped = true; board[r][c] = BOARD.UNKNOWN; continue; }
          board[r][c] = BOARD.FILLED;
        } else board[r][c] = BOARD.CROSSED;
      }
    }
    afterChange();
  };
  window.__noctFinishLastCell = () => {
    for (let r = 0; r < plate.size; r++)
      for (let c = 0; c < plate.size; c++)
        if (plate.grid[r][c] && board[r][c] !== BOARD.FILLED) { board[r][c] = BOARD.FILLED; afterChange(); return; }
  };

  AUDIO.register('cabinet', 'audio/mus_cabinet.ogg', 0.5);
  AUDIO.register('plate', 'audio/mus_plate.ogg', 0.42);
  AUDIO.playMusic('cabinet');
  requestAnimationFrame(frame);

})();
