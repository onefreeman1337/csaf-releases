/* ══════════════════════════════════════════════════════════════════════════════════
 * NOCTUARY — THE REVEAL
 *
 * The puzzle is 400 black squares. The REWARD is this: the same animal, drawn from the
 * same genotype, at continuous resolution and in colour, pinned to a card with its
 * label. Solving does not just complete a grid — it DEVELOPS the specimen.
 *
 * That transition is the answer to wing CLAUDE.md §3's third test ("would someone who
 * played this for ninety seconds tell someone else about it?"). A picross that ends with
 * a slightly larger version of the pixels you just filled in has no answer to it.
 *
 * ⛔ THE PICTURE IS NOT AN ASSET AND NOT AN UPSCALE. It resamples the SAME geometry the
 * puzzle grid was rasterised from, at whatever resolution it is asked for, using
 * specimens.tissueAt() — the one function, shared, so the mounted moth cannot drift from
 * the moth you solved. There is no PNG of any specimen anywhere in this product.
 * ════════════════════════════════════════════════════════════════════════════════ */

'use strict';

const _RSP = (typeof require !== 'undefined' && typeof module !== 'undefined')
  ? require('./specimens.js') : null;
const RSPEC = _RSP || (typeof window !== 'undefined' ? window.NoctuarySpecimens : null);

function hexToRgb(h) {
  const n = parseInt(h.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
function mixRgb(a, b, t) {
  return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
}
function paletteOf(id) {
  return RSPEC.PALETTES.find((p) => p.id === id) || RSPEC.PALETTES[0];
}

/* Cheap deterministic value noise, used for scale dust. Keyed on pixel AND seed so two
 * specimens do not share a speckle pattern. */
function dust(x, y, seed) {
  let h = (x * 374761393 + y * 668265263 + seed * 2246822519) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

/* ══════════════════════════════════════════════════════════════════════════════════
 * THE FIT, EXPORTED — so anything drawing the same animal a second way lands on top.
 *
 * ⛔ This exists because the cover got it wrong. The cover composes ONE specimen split
 * down its axis of symmetry: the puzzle grid on the left, the resolved specimen on the
 * right. That only works if both halves use the SAME mapping from the genotype's
 * coordinate space into pixels. The first two attempts each rolled their own — one used
 * a different box width, the next mapped the grid as `n cells across the box` while
 * renderSpecimen maps the ANIMAL'S EXTENT across the box — and the two halves came out
 * 22% different in width, so the seam did not line up and the composition failed at the
 * one thing it exists to do.
 *
 * gridCellRect() puts a puzzle cell exactly where renderSpecimen would put that piece of
 * the animal. It is the inverse of the mapping in the sampling loop, written once.
 * ════════════════════════════════════════════════════════════════════════════════ */
const FIT = { XSPAN: 0.82, YSPAN: 0.93, MARGIN: 0.03 };

function gridCellRect(n, row, col, w, h) {
  const inner = 1 - FIT.MARGIN * 2;
  // cell edges in genotype space
  const x0 = (col / n) * 2 - 1, x1 = ((col + 1) / n) * 2 - 1;
  const y0 = row / n, y1 = (row + 1) / n;
  const fx = (x) => (FIT.MARGIN + inner * ((x / FIT.XSPAN + 1) / 2)) * w;
  const fy = (y) => (FIT.MARGIN + inner * (y / FIT.YSPAN)) * h;
  return { x: fx(x0), y: fy(y0), w: fx(x1) - fx(x0), h: fy(y1) - fy(y0) };
}

/* ══════════════════════════════════════════════════════════════════════════════════
 * tissueColour — the palette decision, in ONE place.
 *
 * Kept free of canvas so the headless contact-sheet renderer in Internal_Ops calls the
 * SAME function the game does. The alternative — re-deriving the colour mapping in the
 * review tool — means reviewing a picture the player will never see, which is worse than
 * not reviewing at all.
 *
 * Returns null for background so the caller decides what shows through.
 * ════════════════════════════════════════════════════════════════════════════════ */
function tissueColour(t, x, pal, T) {
  const ink = hexToRgb(pal.ink);
  const wash = hexToRgb(pal.wash);
  const accent = hexToRgb(pal.accent);
  const edge = Math.min(1, Math.abs(x));

  if (t === T.NONE) return null;
  if (t === T.BODY) return ink;                                  // darkest — the core
  if (t === T.ANTENNA) return mixRgb(ink, wash, 0.14);
  // the forewing pales very slightly toward its outer edge, as scales thin
  if (t === T.FOREWING) return mixRgb(ink, wash, 0.06 + 0.16 * edge);
  if (t === T.HINDWING) return mixRgb(ink, wash, 0.22 + 0.14 * edge);
  /*
   * PATTERN — the marks the puzzle could only imply. In the 20x20 grid these are simply
   * absent cells; here they are the accent colour, which is the single biggest reason
   * the revealed animal reads as an illustration rather than an enlargement of the thing
   * you just solved.
   */
  return mixRgb(wash, accent, 0.62);
}

/* ══════════════════════════════════════════════════════════════════════════════════
 * renderSpecimen — genotype -> an ImageData of the animal, transparent background.
 *
 * `ss` is the supersample factor. 2 is enough at display size and keeps a full-page
 * reveal comfortably inside one frame; the cabinet thumbnails use 1.
 * ════════════════════════════════════════════════════════════════════════════════ */
function renderSpecimen(ctx, g, w, h, opts) {
  opts = opts || {};
  const ss = opts.ss || 2;
  const pal = paletteOf(opts.palette || g.palette);
  const img = ctx.createImageData(w, h);
  const d = img.data;
  const T = RSPEC.TISSUE;

  /*
   * ⛔ FIT THE ANIMAL, NOT ITS COORDINATE SPACE.
   *
   * The genotype is defined over x in [-1,1] and y in [0,1], but no specimen ever USES
   * that box: the edge clamp in specimens.js caps every wing at |x| <= 0.79, and the
   * abdomen terminates inside the hindwing, so nothing reaches y = 1 either. Mapping the
   * full coordinate space into the frame therefore reserved a permanent empty border of
   * about 20% on each side, which on the reveal card read as a small moth adrift on a big
   * piece of paper — and the remediation doc calls a composite that is >20% empty a Gate 1
   * failure outright.
   *
   * These are the animal's real extents, taken from the clamp, not guessed.
   */
  const XSPAN = FIT.XSPAN, YSPAN = FIT.YSPAN, MARGIN = FIT.MARGIN;
  const inner = 1 - MARGIN * 2;

  for (let py = 0; py < h; py++) {
    for (let px = 0; px < w; px++) {
      let r = 0, gg = 0, b = 0, a = 0;

      for (let sy = 0; sy < ss; sy++) {
        for (let sx = 0; sx < ss; sx++) {
          const fx = (px + (sx + 0.5) / ss) / w;
          const fy = (py + (sy + 0.5) / ss) / h;
          const x = (((fx - MARGIN) / inner) * 2 - 1) * XSPAN;
          const y = ((fy - MARGIN) / inner) * YSPAN;
          if (y < 0 || y > 1 || x < -1 || x > 1) continue;

          const t = RSPEC.tissueAt(g, x, y);
          const col = tissueColour(t, x, pal, T);
          if (!col) continue;

          // scale dust: a faint per-pixel grain so flat ink does not look like vector fill
          const n = dust(px, py, g.seed);
          const grain = 0.93 + n * 0.14;
          r += col[0] * grain; gg += col[1] * grain; b += col[2] * grain; a += 255;
        }
      }

      const n2 = ss * ss;
      const i = (py * w + px) * 4;
      if (a > 0) {
        const cover = a / (255 * n2);
        d[i] = Math.min(255, r / n2 / cover);
        d[i + 1] = Math.min(255, gg / n2 / cover);
        d[i + 2] = Math.min(255, b / n2 / cover);
        d[i + 3] = Math.round(255 * cover);
      }
    }
  }
  return img;
}

/* ══════════════════════════════════════════════════════════════════════════════════
 * drawMountedPlate — the whole reward screen for one specimen.
 *
 * Card, shadow, specimen, pin, and the label. `develop` in [0,1] drives the transition
 * from the solved grid to the finished animal.
 * ════════════════════════════════════════════════════════════════════════════════ */
function drawMountedPlate(ctx, g, grid, label, box, develop, fonts) {
  const pal = paletteOf(g.palette);
  const { x, y, w, h } = box;
  develop = Math.max(0, Math.min(1, develop));

  ctx.save();
  // the context's own scale (1.1.0 HiDPI): shadows are in device pixels and the specimen image is
  // rendered at this scale (capped at 2x) so it stays sharp; an unscaled context renders exactly as before
  const tf = ctx.getTransform ? ctx.getTransform() : null;
  const dev = tf ? Math.abs(tf.a) || 1 : 1;
  const imgK = Math.max(1, Math.min(2, Math.round(dev * 4) / 4));

  // --- card ---
  ctx.shadowColor = 'rgba(0,0,0,0.45)';
  ctx.shadowBlur = 26 * dev;
  ctx.shadowOffsetY = 10 * dev;
  ctx.fillStyle = pal.wash;
  roundRect(ctx, x, y, w, h, 4);
  ctx.fill();
  ctx.shadowColor = 'transparent';
  ctx.shadowBlur = 0;
  ctx.shadowOffsetY = 0;

  // a hairline rule inset from the card edge — the single cheapest "printed" cue
  ctx.strokeStyle = 'rgba(0,0,0,0.16)';
  ctx.lineWidth = 1;
  roundRect(ctx, x + 10.5, y + 10.5, w - 21, h - 21, 2);
  ctx.stroke();

  /*
   * Card proportions. The label block used to sit at a fixed 0.70 of the height with the
   * specimen ending at 0.62, which left a dead band across the middle and another below
   * the catalogue line — about a third of the card carrying nothing. These fractions put
   * the specimen across the top two thirds and the label immediately under its rule.
   */
  const specW = Math.floor(w - 36);
  const specH = Math.floor(h * 0.67);
  const specX = x + 18;
  const specY = y + 18;

  /*
   * THE DEVELOP TRANSITION. Below ~0.5 the coarse solved grid is still what you see;
   * above it the continuous render fades in over the top. Both are drawn from the same
   * genotype, so the animal never moves — only its resolution changes. That is the whole
   * effect and it is why it reads as DEVELOPING rather than as a scene change.
   */
  if (develop < 1) {
    const n = grid.length;
    const cell = Math.min(specW / n, specH / n);
    const gx = specX + (specW - cell * n) / 2;
    const gy = specY + (specH - cell * n) / 2;
    ctx.globalAlpha = 1 - develop * 0.9;
    ctx.fillStyle = pal.ink;
    for (let r = 0; r < n; r++) {
      for (let c = 0; c < n; c++) {
        if (!grid[r][c]) continue;
        // cells shrink very slightly as the fine image takes over
        const inset = develop * cell * 0.18;
        ctx.fillRect(gx + c * cell + inset, gy + r * cell + inset,
                     cell - inset * 2, cell - inset * 2);
      }
    }
    ctx.globalAlpha = 1;
  }

  if (develop > 0) {
    const key = g.seed + ':' + specW + 'x' + specH + '@' + imgK;
    if (!drawMountedPlate._cache || drawMountedPlate._cacheKey !== key) {
      const off = document.createElement('canvas');
      off.width = Math.round(specW * imgK); off.height = Math.round(specH * imgK);
      const octx = off.getContext('2d');
      octx.putImageData(renderSpecimen(octx, g, off.width, off.height, { ss: 2 }), 0, 0);
      drawMountedPlate._cache = off;
      drawMountedPlate._cacheKey = key;
    }
    ctx.globalAlpha = develop;
    ctx.drawImage(drawMountedPlate._cache, specX, specY, specW, specH);
    ctx.globalAlpha = 1;
  }

  // --- the pin ---
  if (develop > 0.55) {
    const pa = (develop - 0.55) / 0.45;
    ctx.globalAlpha = pa;
    const pinX = x + w / 2;
    const pinTop = specY - 6;
    const pinBot = specY + specH * 0.30;
    ctx.strokeStyle = 'rgba(40,40,46,0.75)';
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(pinX, pinTop); ctx.lineTo(pinX, pinBot); ctx.stroke();
    const head = ctx.createRadialGradient(pinX - 2, pinTop - 4, 1, pinX, pinTop - 2, 7);
    head.addColorStop(0, '#f4f0e6');
    head.addColorStop(1, pal.accent);
    ctx.fillStyle = head;
    ctx.beginPath(); ctx.arc(pinX, pinTop - 2, 6, 0, Math.PI * 2); ctx.fill();
    ctx.globalAlpha = 1;
  }

  // --- the label ---
  if (develop > 0.7 && label) {
    const la = (develop - 0.7) / 0.3;
    ctx.globalAlpha = la;
    const ly = y + h * 0.735;

    ctx.strokeStyle = 'rgba(0,0,0,0.20)';
    ctx.beginPath();
    ctx.moveTo(x + 26, ly - 16); ctx.lineTo(x + w - 26, ly - 16);
    ctx.stroke();

    ctx.textAlign = 'center';
    ctx.fillStyle = pal.ink;
    ctx.font = 'italic 600 ' + Math.round(h * 0.048) + 'px ' + (fonts ? fonts.serif : 'Georgia, serif');
    ctx.fillText(label.binomial, x + w / 2, ly + 12);

    ctx.font = Math.round(h * 0.036) + 'px ' + (fonts ? fonts.serif : 'Georgia, serif');
    ctx.fillStyle = 'rgba(0,0,0,0.62)';
    ctx.fillText(label.common, x + w / 2, ly + 40);

    ctx.font = Math.round(h * 0.026) + 'px ' + (fonts ? fonts.mono : 'monospace');
    ctx.fillStyle = pal.accent;
    ctx.fillText(label.catalogue + '   ·   ' + label.wingspan, x + w / 2, ly + 64);
    ctx.globalAlpha = 1;
  }

  ctx.restore();
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { renderSpecimen, drawMountedPlate, paletteOf, roundRect, tissueColour, hexToRgb, mixRgb, dust, FIT, gridCellRect };
}
if (typeof window !== 'undefined') {
  window.NoctuaryReveal = { renderSpecimen, drawMountedPlate, paletteOf, roundRect, tissueColour, hexToRgb, mixRgb, dust, FIT, gridCellRect };
}
