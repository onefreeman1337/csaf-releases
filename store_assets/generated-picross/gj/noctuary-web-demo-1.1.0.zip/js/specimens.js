/*
 * NOCTUARY — the specimen corpus.
 *
 * (noctuary, n.: a record of what happens in the night. Also Noctuidae, the largest
 *  family of moths. The game is a picross drawer that fills with generated specimens.)
 *
 * ─────────────────────────────────────────────────────────────────────────────────────
 * WHY THIS FILE IS THE PRODUCT, AND WHY IT IS THE FIRST THING BUILT
 *
 * CLAUDE.md §1.1 asks three questions of a candidate and this wing answers them here:
 *
 *   Q1  Do the player's eyes meet something beautiful the product created?
 *       The resolving picture IS the game. A nonogram's whole reward is the reveal.
 *
 *   Q2  Does the PRODUCT generate that beauty, rather than ship or decorate it?
 *       There is no PNG anywhere in this product. Every specimen is drawn from a trait
 *       genotype into a coverage field and thresholded to a grid. Change one trait and
 *       the silhouette changes, because the silhouette was never a picture.
 *
 *   Q3  Is there VOLUME — 40+ distinct generated visual entities?
 *       The vocabulary below (written as data by an AI) is **56 marks** across six organs —
 *       forewing 10, hindwing 8, pattern 18, antenna 7, body 6, margin 7 — and that
 *       figure is MEASURED by Internal_Ops/check_corpus.js on every run rather than
 *       asserted here. (This comment read "60" while the corpus held 56, for exactly as
 *       long as it took to run the counter. A round number in a comment is a claim.)
 *       §1.1 is explicit that this volume is the moat and "the first thing throughput
 *       pressure destroys", which is why it is built before the puzzle generator.
 *
 * ⛔ AND WHY IT IS MOTHS RATHER THAN ANYTHING ELSE. CLAUDE.md §1.1a (corrected
 *    2026-08-18) measures this factory's weakest point as "handdrawn landscapes, models,
 *    and sprites". A nonogram grid needs NONE of those: it needs bold, bilaterally
 *    symmetric silhouettes that read at 20x20, which is exactly what a specimen plate is
 *    and exactly what geometry is good at. The low resolution is the medium here, not a
 *    limitation being worked around.
 *
 * ─────────────────────────────────────────────────────────────────────────────────────
 * COORDINATE CONTRACT — read this before adding a motif.
 *
 * Everything is authored in a normalised RIGHT-HALF space and mirrored, because real
 * lepidoptera are bilaterally symmetric and a symmetric nonogram is both prettier to
 * reveal and kinder to solve.
 *
 *      u  = 0 at the body midline, 1 at the outermost wingtip
 *      v  = 0 at the head, 1 at the tip of the abdomen
 *
 * A motif is a pure function of (u, v, p) returning coverage in [0, 1], where p is the
 * specimen's own parameter bag. Pure, so a seed always renders the same specimen — the
 * determinism the capture pipeline depends on.
 */
'use strict';

/* ══════════════════════════════════════════════════════════════════════════════════
 * 1. FOREWING — 10 marks. The dominant silhouette; this is what you recognise first.
 *    Each returns the wing's half-width at position t along its span, t in [0,1].
 * ════════════════════════════════════════════════════════════════════════════════ */
const FOREWING = {
  falcate:     { name: 'falcate',     span: [0.14, 0.56], w: (t) => 0.30 + 0.72 * Math.sin(Math.PI * Math.pow(t, 0.62)) - 0.30 * Math.pow(t, 5) },
  deltoid:     { name: 'deltoid',     span: [0.16, 0.54], w: (t) => 1.00 - 0.86 * Math.pow(t, 1.25) },
  rounded:     { name: 'rounded',     span: [0.15, 0.58], w: (t) => Math.sqrt(Math.max(0, 1 - t * t)) * 0.98 },
  elongate:    { name: 'elongate',    span: [0.12, 0.62], w: (t) => 0.62 * Math.pow(1 - t, 0.45) + 0.16 },
  hooked:      { name: 'hooked',      span: [0.13, 0.55], w: (t) => 0.34 + 0.66 * Math.sin(Math.PI * t) + 0.30 * Math.pow(t, 8) },
  broad:       { name: 'broad',       span: [0.17, 0.57], w: (t) => 0.55 + 0.45 * Math.cos(Math.PI * t * 0.5) },
  sickle:      { name: 'sickle',      span: [0.11, 0.53], w: (t) => 0.24 + 0.80 * Math.pow(Math.sin(Math.PI * t), 0.75) },
  truncate:    { name: 'truncate',    span: [0.18, 0.52], w: (t) => (t < 0.82 ? 0.94 - 0.22 * t : 0.94 - 0.22 * t - 2.6 * (t - 0.82)) },
  lanceolate:  { name: 'lanceolate',  span: [0.10, 0.60], w: (t) => 0.86 * Math.pow(Math.sin(Math.PI * Math.pow(t, 0.8)), 1.4) + 0.10 },
  scalloped:   { name: 'scalloped',   span: [0.15, 0.56], w: (t) => (0.52 + 0.48 * Math.cos(Math.PI * t * 0.5)) * (1 + 0.09 * Math.sin(t * Math.PI * 5)) }
};

/* ══════════════════════════════════════════════════════════════════════════════════
 * 2. HINDWING — 8 marks. Sits under the forewing; sets the creature's "weight".
 * ════════════════════════════════════════════════════════════════════════════════ */
const HINDWING = {
  fanned:      { name: 'fanned',      span: [0.46, 0.84], w: (t) => 0.80 * Math.sin(Math.PI * Math.pow(t, 0.7)) + 0.14 },
  lobed:       { name: 'lobed',       span: [0.47, 0.80], w: (t) => 0.72 * Math.sqrt(Math.max(0, 1 - Math.pow(t, 2.4))) + 0.10 },
  tailed:      { name: 'tailed',      span: [0.45, 0.94], w: (t) => (t < 0.66 ? 0.78 * Math.sin(Math.PI * t / 0.66 * 0.9) + 0.12 : 0.19 - 0.10 * (t - 0.66)) },
  vestigial:   { name: 'vestigial',   span: [0.50, 0.70], w: (t) => 0.44 * Math.sin(Math.PI * t) + 0.07 },
  ample:       { name: 'ample',       span: [0.44, 0.86], w: (t) => 0.92 * Math.pow(Math.sin(Math.PI * t), 0.62) + 0.10 },
  angular:     { name: 'angular',     span: [0.46, 0.82], w: (t) => 0.84 * (1 - Math.abs(2 * t - 1)) + 0.14 },
  crescent:    { name: 'crescent',    span: [0.48, 0.83], w: (t) => 0.70 * Math.sin(Math.PI * t) * (0.65 + 0.35 * t) + 0.10 },
  plumed:      { name: 'plumed',      span: [0.45, 0.88], w: (t) => (0.66 * Math.sin(Math.PI * t) + 0.14) * (1 + 0.16 * Math.sin(t * Math.PI * 7)) }
};

/* ══════════════════════════════════════════════════════════════════════════════════
 * 3. PATTERN — 18 marks, the largest organ and the one that carries identity.
 *    A pattern SUBTRACTS from or ADDS to wing coverage, so it can cut a hole or lay a
 *    band. It receives normalised wing-local coordinates.
 * ════════════════════════════════════════════════════════════════════════════════ */
const PATTERN = {
  /*
   * ⛔ WAS `plain: () => 0` AND THAT WAS A REAL DEFECT, caught by looking at the second
   * contact sheet. A pattern that subtracts nothing leaves a broad forewing as a SOLID
   * FILLED BLOCK — simultaneously the ugliest plate on the sheet and the worst possible
   * nonogram, because a line with one run of 14 carries no deductive information. Every
   * specimen must have some internal negative space. Kept as the SUBTLEST mark rather
   * than deleted, because a near-unmarked wing is a real morphology and the corpus wants
   * a quiet end of the range.
   */
  veined:      { name: 'veined',      f: (u, v, p) => (Math.abs(((v - p.span0) * 9.0 % 1) - 0.5) < 0.10 && u > 0.34 ? -0.7 : 0) },
  medial_band: { name: 'medial band', f: (u, v, p) => band(v, p.bandAt, p.bandW) * -0.9 },
  ocellus:     { name: 'ocellus',     f: (u, v, p) => ring(u, v, p.eyeU, p.eyeV, p.eyeR, 0.34) * -1.0 },
  twin_ocelli: { name: 'twin ocelli', f: (u, v, p) => Math.max(ring(u, v, p.eyeU, p.eyeV, p.eyeR * 0.8, 0.3), ring(u, v, p.eyeU * 0.55, p.eyeV + 0.16, p.eyeR * 0.55, 0.3)) * -1.0 },
  reniform:    { name: 'reniform',    f: (u, v, p) => blob(u, v, p.eyeU, p.eyeV, p.eyeR * 1.15, 0.55) * -0.95 },
  chevrons:    { name: 'chevrons',    f: (u, v) => (Math.abs(((u * 3.1 + v * 5.2) % 1) - 0.5) < 0.17 ? -0.75 : 0) },
  marbled:     { name: 'marbled',     f: (u, v) => (Math.sin(u * 11.3) * Math.cos(v * 9.7) > 0.42 ? -0.7 : 0) },
  striate:     { name: 'striate',     f: (u, v, p) => (Math.abs(((v * p.striae) % 1) - 0.5) < 0.20 ? -0.8 : 0) },
  costal_dash: { name: 'costal dash', f: (u, v, p) => (v < p.span0 + 0.10 && u > 0.42 && u < 0.86 ? -0.85 : 0) },
  hem_spots:   { name: 'hem spots',   f: (u, v) => (u > 0.74 && Math.abs(((v * 7) % 1) - 0.5) < 0.24 ? -0.8 : 0) },
  discal_spot: { name: 'discal spot', f: (u, v, p) => blob(u, v, p.eyeU * 0.7, p.eyeV, p.eyeR * 0.55, 1.0) * -1.0 },
  fascia_pair: { name: 'fascia pair', f: (u, v, p) => Math.max(band(v, p.bandAt - 0.07, p.bandW * 0.55), band(v, p.bandAt + 0.09, p.bandW * 0.55)) * -0.85 },
  net_veins:   { name: 'net veins',   f: (u, v) => ((Math.abs(((u * 6.0) % 1) - 0.5) < 0.11 || Math.abs(((v * 8.0) % 1) - 0.5) < 0.09) ? -0.55 : 0) },
  clouded:     { name: 'clouded',     f: (u, v) => (u * 0.7 + Math.sin(v * 6.1) * 0.22 > 0.62 ? -0.6 : 0) },
  arrowhead:   { name: 'arrowhead',   f: (u, v, p) => (Math.abs(u - (v - p.span0) * 1.6) < 0.13 ? -0.8 : 0) },
  lunule:      { name: 'lunule',      f: (u, v, p) => (ring(u, v, p.eyeU, p.eyeV, p.eyeR, 0.3) && u > p.eyeU ? -0.95 : 0) },
  peppered:    { name: 'peppered',    f: (u, v) => (((Math.sin(u * 27.1) + Math.sin(v * 31.7)) > 1.15) ? -0.7 : 0) },
  hyaline:     { name: 'hyaline',     f: (u, v, p) => blob(u, v, 0.52, p.bandAt, 0.30, 0.8) * -1.1 }
};

/* ══════════════════════════════════════════════════════════════════════════════════
 * 4. ANTENNA — 7 marks. Small on the grid and the strongest species cue a viewer has.
 * ════════════════════════════════════════════════════════════════════════════════ */
const ANTENNA = {
  filiform:    { name: 'filiform',    reach: 0.34, spread: 0.16, feather: 0.00 },
  pectinate:   { name: 'pectinate',   reach: 0.30, spread: 0.30, feather: 0.55 },
  bipectinate: { name: 'bipectinate', reach: 0.33, spread: 0.38, feather: 0.85 },
  clavate:     { name: 'clavate',     reach: 0.31, spread: 0.20, feather: 0.00, club: 0.55 },
  setaceous:   { name: 'setaceous',   reach: 0.40, spread: 0.11, feather: 0.00 },
  lamellate:   { name: 'lamellate',   reach: 0.24, spread: 0.34, feather: 0.40, club: 0.30 },
  plumose:     { name: 'plumose',     reach: 0.28, spread: 0.44, feather: 1.00 }
};

/* ══════════════════════════════════════════════════════════════════════════════════
 * 5. BODY — 6 marks. Thorax + abdomen profile.
 * ════════════════════════════════════════════════════════════════════════════════ */
/*
 * v is 0 at the head end of the thorax and 1 at the abdomen tip. A moth is THICK at the
 * thorax (where the flight muscles are) and tapers back — that shoulder is the single
 * strongest "this is an insect, not a leaf" cue available at this resolution, so every
 * mark below carries it and they differ in how they taper.
 */
const THORAX = (v) => 1.55 * Math.exp(-Math.pow((v - 0.16) * 3.2, 2)) + 0.55;
const BODY = {
  stout:       { name: 'stout',       w: (v) => 0.115 * THORAX(v) * (1 - 0.35 * v) },
  slender:     { name: 'slender',     w: (v) => 0.072 * THORAX(v) * (1 - 0.42 * v) },
  tufted:      { name: 'tufted',      w: (v) => 0.098 * THORAX(v) * (1 - 0.30 * v) * (1 + 0.30 * Math.sin(v * Math.PI * 5)) },
  tapered:     { name: 'tapered',     w: (v) => 0.120 * THORAX(v) * Math.pow(1 - v, 0.75) + 0.020 },
  crested:     { name: 'crested',     w: (v) => (v < 0.30 ? 0.135 : 0.082) * THORAX(v) * (1 - 0.22 * v) },
  cylindric:   { name: 'cylindric',   w: (v) => 0.088 * THORAX(v) }
};

/* ══════════════════════════════════════════════════════════════════════════════════
 * 6. MARGIN — 7 marks. The wing edge. Cheap to author, and it is what stops every
 *    specimen reading as the same cut-out at grid resolution.
 * ════════════════════════════════════════════════════════════════════════════════ */
const MARGIN = {
  entire:      { name: 'entire',      f: () => 1.00 },
  dentate:     { name: 'dentate',     f: (t) => 1.00 + 0.10 * Math.sign(Math.sin(t * Math.PI * 9)) },
  crenulate:   { name: 'crenulate',   f: (t) => 1.00 + 0.075 * Math.sin(t * Math.PI * 11) },
  erose:       { name: 'erose',       f: (t) => 1.00 + 0.085 * Math.sin(t * 23.3) * Math.cos(t * 11.1) },
  fringed:     { name: 'fringed',     f: (t) => 1.00 + 0.055 * Math.sin(t * Math.PI * 17) },
  excavate:    { name: 'excavate',    f: (t) => 1.00 - 0.16 * Math.exp(-Math.pow((t - 0.62) * 5.5, 2)) },
  produced:    { name: 'produced',    f: (t) => 1.00 + 0.17 * Math.exp(-Math.pow((t - 0.80) * 6.0, 2)) }
};

/* ══════════════════════════════════════════════════════════════════════════════════
 * 7. PALETTES — 8 colourways. Not part of the 60-mark silhouette vocabulary; the grid
 *    is binary. These dress the SOLVED plate, which is the reward screen.
 * ════════════════════════════════════════════════════════════════════════════════ */
const PALETTES = [
  { id: 'foxing',    ink: '#2b2118', wash: '#e8dcc4', accent: '#8c4a2f', label: 'foxing'    },
  { id: 'verdigris', ink: '#152521', wash: '#dfe7dc', accent: '#3f7d6d', label: 'verdigris' },
  { id: 'ironwash',  ink: '#1b1e26', wash: '#dcdfe6', accent: '#4a5a7a', label: 'ironwash'  },
  { id: 'tallow',    ink: '#2a2416', wash: '#f0e6c8', accent: '#a8862c', label: 'tallow'    },
  { id: 'murex',     ink: '#241726', wash: '#e6dae8', accent: '#7a3d78', label: 'murex'     },
  { id: 'peat',      ink: '#1e1a15', wash: '#d8cdba', accent: '#6b4a22', label: 'peat'      },
  { id: 'frost',     ink: '#20262b', wash: '#e9eff2', accent: '#5b7f8c', label: 'frost'     },
  { id: 'cinnabar',  ink: '#291712', wash: '#eeddd2', accent: '#9c3a1e', label: 'cinnabar'  }
];

/* ── helpers used by the pattern marks ─────────────────────────────────────────── */
function band(v, at, w) { return Math.abs(v - at) < w ? 1 : 0; }
function blob(u, v, cu, cv, r, squash) {
  const dx = (u - cu), dy = (v - cv) / (squash || 1);
  return (dx * dx + dy * dy) < r * r ? 1 : 0;
}
function ring(u, v, cu, cv, r, thick) {
  const d = Math.hypot(u - cu, (v - cv) / 0.85);
  return (d < r && d > r * (1 - thick)) ? 1 : 0;
}

/* ── deterministic PRNG: same seed, same specimen, forever ─────────────────────── */
function rng(seed) {
  let s = seed >>> 0;
  return function () {
    s ^= s << 13; s >>>= 0;
    s ^= s >> 17;
    s ^= s << 5;  s >>>= 0;
    return s / 4294967296;
  };
}
const keys = (o) => Object.keys(o);
function pick(r, obj) { const k = keys(obj); return k[Math.floor(r() * k.length) % k.length]; }

/* ══════════════════════════════════════════════════════════════════════════════════
 * THE GENOTYPE. Six organs + a palette. This is the whole specimen.
 * ════════════════════════════════════════════════════════════════════════════════ */
function genotype(seed) {
  const r = rng(seed * 2654435761 + 12345);
  const g = {
    seed: seed,
    forewing: pick(r, FOREWING),
    hindwing: pick(r, HINDWING),
    pattern:  pick(r, PATTERN),
    antenna:  pick(r, ANTENNA),
    body:     pick(r, BODY),
    margin:   pick(r, MARGIN),
    palette:  PALETTES[Math.floor(r() * PALETTES.length) % PALETTES.length].id,
    // continuous parameters the marks read.
    // ⛔ reach is CAPPED BELOW 1.0 on purpose. At 1.0 the widest wings touch both grid
    // edges, which produces a row run spanning the whole grid — a nonogram line with a
    // single full-width run carries ZERO deductive information, and the plate reads as
    // cropped at the card edge. Measured: an uncapped 0.74+0.26 gave a 20-of-20 run.
    reach:   0.66 + r() * 0.24,
    bandAt:  0.26 + r() * 0.22,
    bandW:   0.035 + r() * 0.055,
    eyeU:    0.42 + r() * 0.26,
    eyeV:    0.24 + r() * 0.16,
    eyeR:    0.10 + r() * 0.09,
    striae:  4 + Math.floor(r() * 6)
  };
  return g;
}

/* ══════════════════════════════════════════════════════════════════════════════════
 * RASTERISE — genotype -> binary grid. This is the picross puzzle's picture.
 *
 * Supersampled (SS x SS per cell) so a cell that is half covered is decided by area
 * rather than by whether its exact centre happened to land inside a wing. At 20x20
 * that difference is the whole legibility of the silhouette.
 * ════════════════════════════════════════════════════════════════════════════════ */
/*
 * ⛔ ANATOMY CONSTANTS — added after the first contact sheet, which FAILED.
 *
 * The first render produced 48 attractive, coherent, genuinely distinct plates that were
 * NOT MOTHS. They read as leaves, fir trees and heraldic shields. Two causes, both
 * visible the moment the sheet was actually looked at rather than measured:
 *
 *   1. the abdomen ran to y=1.0, PAST the hindwing, so every specimen had a long
 *      vertical stalk below it — which is precisely what a plant stem looks like;
 *   2. the antennae were ~6 cells of a 400-cell grid (check_corpus measured exactly
 *      that and I let it pass a threshold of 3), so the one unmistakable moth cue was
 *      invisible and the "stalk" reading had nothing to argue with.
 *
 * The fix is anatomical, not cosmetic: the abdomen must TERMINATE INSIDE the hindwing's
 * span, and the antennae must be bold enough to read at 20x20. Numbers live here as
 * named constants so the next person changing them can see what they are trading.
 */
const ANAT = {
  headTop:    0.085,   // where the antennae stop and the thorax starts
  bodyTop:    0.085,
  bodyBot:    0.760,   // ⛔ MUST stay < hindwing span end, or the stem comes back
  antTop:     0.000,
  antBot:     0.150
};

/*
 * TISSUE — which part of the animal covers a point.
 *
 * ⛔ WHY THIS EXISTS, AND WHY coverageAt() NOW DELEGATES TO IT RATHER THAN DUPLICATING IT.
 *
 * The 20x20 puzzle grid only needs a boolean: is this cell inked? But the REVEAL — the
 * moment the solved plate develops into a mounted specimen at full resolution — needs to
 * know that a hole in a wing is a PATTERN and not background, so it can be tinted with
 * the palette's accent instead of dropped to the page colour. That is the difference
 * between a silhouette and an illustration, and it is the game's entire reward screen.
 *
 * The tempting shortcut is a second function in the reveal that re-implements this
 * geometry. Do not: the two would drift, and the drift would be invisible because the
 * puzzle and the picture are checked by different files. One source, two readings.
 *
 * coverageAt() is now exactly `tissueAt() is solid ink`, so every corpus assertion — fill
 * ratios, run lengths, pair distances — is unchanged by construction. Verified by
 * re-running check_corpus.js and check_plates.js after the refactor and getting the same
 * numbers to the cell.
 */
const TISSUE = { NONE: 0, BODY: 1, ANTENNA: 2, FOREWING: 3, HINDWING: 4, PATTERN: 5 };

/*
 * ⛔ THREE ANATOMY FIXES, ALL FOUND BY RENDERING THE REVEAL AND LOOKING AT IT.
 *
 * The 20x20 puzzle grid hid all three, because at that resolution the picture IS blocky
 * and every defect below reads as pixelation. Blown up to the continuous reveal — which
 * is the REWARD, the thing the whole product exists to deliver — the geometry's
 * weaknesses were plain within a second of opening the contact sheet:
 *
 *   1. TERRACED SILHOUETTES. The forewing and hindwing are separate spans whose widths
 *      did not agree where they meet, so the outline stepped. Wings like `broad`
 *      (w = 0.55 + 0.45cos, still 0.55 wide at its own span end) ended in a sheer cliff.
 *      Half the sheet read as layered cake-stands and pagodas rather than moths.
 *   2. ABDOMEN STALKS. bodyBot was a CONSTANT 0.76, chosen to sit inside a typical
 *      hindwing. A `vestigial` hindwing ends at 0.70, so the abdomen projected below it
 *      as a bare spike — the exact "plant stem" reading the previous session thought it
 *      had killed. A constant cannot terminate inside a variable.
 *   3. ANTENNAE AS STRIPED FLAGS. The barb stripes were a hard modulo at constant width,
 *      so a plumose antenna read as a checkered pennant floating above the head.
 *
 * ⚠️ This changes every grid, so EVERY corpus, solvability and plate number below is
 * re-measured after it — not assumed to survive.
 */

/* Smooth 0->1. Used to taper a wing to nothing at its own span ends. */
function smoothstep(e0, e1, v) {
  const t = Math.max(0, Math.min(1, (v - e0) / (e1 - e0)));
  return t * t * (3 - 2 * t);
}

function tissueAt(g, x, y) {
  // x in [-1,1] across the body, y in [0,1] head to abdomen. Work on |x|.
  const u = Math.abs(x);

  const HIND = HINDWING[g.hindwing];

  /*
   * --- body: thorax + abdomen, terminating INSIDE THE ACTUAL HINDWING ---
   * Fix 2. The end of the abdomen is now derived from THIS specimen's hindwing span
   * rather than from a constant that happened to suit an average one.
   */
  const bodyBot = Math.min(ANAT.bodyBot, HIND.span[1] - 0.055);
  if (y >= ANAT.bodyTop && y <= bodyBot) {
    const bv = (y - ANAT.bodyTop) / (bodyBot - ANAT.bodyTop);   // 0..1 along the body
    if (u <= BODY[g.body].w(bv)) return TISSUE.BODY;
  }

  // --- antennae: swept up and OUT from the head ---
  const A = ANTENNA[g.antenna];
  if (y >= ANAT.antTop && y <= ANAT.antBot) {
    const t = (ANAT.antBot - y) / (ANAT.antBot - ANAT.antTop);   // 0 at head, 1 at tip
    const axis = 0.075 + A.spread * Math.pow(t, 0.75);           // sweeps outward as it rises
    /*
     * Fix 3. The shaft tapers toward the tip instead of holding one width, and the barbs
     * both TAPER and thin out along their length, so a feathered antenna reads as a comb
     * on a stem rather than as a striped banner. The stripe frequency rises with t so the
     * comb looks finer at the tip, which is what a real pectinate antenna does.
     */
    const taper = 1 - 0.45 * t;
    const shaftW = (0.026 + (A.club || 0) * 0.075 * Math.pow(t, 2.5)) * taper;
    const shaft = Math.abs(u - axis) < shaftW;
    const barbReach = A.feather * 0.075 * (0.35 + 0.65 * Math.sin(Math.PI * Math.min(1, t * 1.15)));
    const barbs = A.feather > 0 &&
                  Math.abs(u - axis) < shaftW + barbReach &&
                  Math.abs(((y * (26 + 14 * t)) % 1) - 0.5) < 0.30;
    if (shaft || barbs) return TISSUE.ANTENNA;
  }

  /*
   * --- wings: ONE CONTINUOUS OUTLINE, NOT TWO STACKED SHAPES ---
   *
   * ⛔ Fix 1, and the FIRST attempt at it was wrong in an instructive way.
   *
   * The wings terraced because the forewing and hindwing were independent spans whose
   * widths did not agree where they meet: a wing still 0.55 wide at its span end simply
   * stopped, and the outline stepped by half its width in a single row.
   *
   * My first fix faired BOTH wings to zero at BOTH their span ends. That looked right on
   * paper and made it WORSE in a way only the render showed: the spans overlap around
   * 0.46-0.55, so inside the overlap both wings were near their tapered ends and both
   * were narrow. Wide, then narrow, then wide — a WAIST. I replaced a step with an
   * hourglass and would have called it fixed if I had trusted the reasoning instead of
   * re-rendering.
   *
   * What actually works is to stop treating them as two shapes to union and treat the
   * outline as ONE function of y that CROSSFADES from the forewing's edge to the
   * hindwing's across the overlap band. No step, because the two edges are blended; no
   * waist, because neither is tapered toward the other. The forewing keeps a short fairing
   * at the shoulder only (where a real forewing does meet the thorax abruptly) and the
   * hindwing keeps one at its trailing edge only (where it genuinely ends).
   *
   * ⛔ CLAMP THE FINAL EDGE, NOT THE INPUT — unchanged and still load-bearing. Capping
   * `g.reach` alone did NOT stop plates touching the grid edge, because MARGIN multiplies
   * AFTERWARDS by up to 1.17 (`produced`): 0.90 x 1.17 = 1.05, past the outermost cell
   * centre at 0.95. And 0.79 rather than 0.84 because a 20-cell grid puts subsample
   * centres for the second column at |x| >= 0.8125 — the supersampler was filling it, the
   * wings never were.
   */
  const FW = FOREWING[g.forewing];
  const [f0, f1] = FW.span;
  const [h0, h1] = HIND.span;
  const M = MARGIN[g.margin];

  const foreEdgeAt = (yy) => {
    const t = (yy - f0) / (f1 - f0);
    return FW.w(t) * smoothstep(0, 0.05, t) * g.reach * M.f(t);
  };
  /*
   * ⚠️ A FIX THAT WAS TRIED HERE AND DID NOT PAY, recorded so it is not tried again.
   *
   * Hypothesis: the last few "stacked" plates were pairings where the hindwing is WIDER
   * than the forewing at the junction — narrow top over broad bottom, which should read
   * as two objects rather than one animal, since a moth at rest holds its forewings over
   * its hindwings. I capped the hindwing at 1.06x the forewing's width at the junction,
   * re-rendered, and compared: ONE plate of 24 changed perceptibly and the stacked
   * readings remained. The hypothesis was wrong.
   *
   * Removed rather than kept, because it cost two extra width evaluations on a path that
   * runs ~350k times per reveal, and it constrained all 80 forewing/hindwing pairings for
   * no measured benefit. A constraint that cannot show its work is how a generator
   * quietly loses variety.
   *
   * The residual stacking is most likely the crossfade band being narrow (the spans only
   * overlap by ~0.09 of the height) interacting with full-width pattern bands. Widening
   * the spans themselves is the next thing to try, and it is a corpus-wide change.
   */
  const hindEdgeAt = (yy) => {
    const t = (yy - h0) / (h1 - h0);
    return HIND.w(t) * smoothstep(0, 0.14, 1 - t) * g.reach * M.f(t);
  };

  let edge = -1, kind = TISSUE.FOREWING, span0 = f0;
  const olo = Math.max(f0, h0), ohi = Math.min(f1, h1);

  if (y >= f0 && y < olo) {
    edge = foreEdgeAt(y);
  } else if (y >= olo && y <= ohi) {
    // the crossfade band — this is the fix
    const s = ohi > olo ? smoothstep(olo, ohi, y) : 1;
    edge = foreEdgeAt(y) * (1 - s) + hindEdgeAt(y) * s;
    if (s >= 0.5) { kind = TISSUE.HINDWING; span0 = h0; }
  } else if (y > ohi && y <= h1) {
    edge = hindEdgeAt(y);
    kind = TISSUE.HINDWING; span0 = h0;
  } else if (y > ohi && y <= f1) {
    // only reachable if the hindwing ends before the forewing does; guarded, not assumed
    edge = foreEdgeAt(y);
  }

  if (edge < 0) return TISSUE.NONE;
  edge = Math.min(edge, 0.79);
  if (u > edge) return TISSUE.NONE;

  let c = 1;
  // pattern works in wing-local coords: uu across the wing, y along it
  const uu = edge > 0 ? u / edge : 0;
  const P = PATTERN[g.pattern];

  /*
   * ⛔ THE MARGINAL RIM — the pattern is never allowed to reach the wing's outer edge.
   *
   * Found by looking at the third reveal sheet, and it is a subtle failure that no count
   * could produce. A pattern that spans the FULL width of the wing — medial_band,
   * striate, fascia_pair — renders in a pale accent-tinted colour that sits close to the
   * card behind it. The eye then reads that band as the SILHOUETTE narrowing, so a moth
   * with a bold cross-band looked like a moth with a pinched waist, and several plates
   * appeared to terrace long after the outline had been fixed. I spent a whole pass
   * chasing the outline for a defect that was in the fill.
   *
   * A rim of solid ink at the wing margin closes the shape, and it is what real moth
   * wings do: the marginal band is almost always the darkest part of the wing. So this is
   * anatomy paying for a rendering fix rather than a hack.
   *
   * 0.88: at 20x20 the rim must survive rasterisation, so it cannot be thinner than
   * roughly one cell of the widest wing.
   */
  const RIM = 0.88;
  if (uu <= RIM) {
    c += P.f(uu, y, Object.assign({ span0: span0 }, g));
  }
  return c > 0.5 ? kind : TISSUE.PATTERN;
}

/*
 * The puzzle's boolean. PATTERN is a hole, so it is NOT ink — which is exactly what the
 * original implementation did, since a patterned-out wing point simply failed the
 * `c > 0.5` test and left `cov` alone.
 */
function coverageAt(g, x, y) {
  const t = tissueAt(g, x, y);
  return (t === TISSUE.NONE || t === TISSUE.PATTERN) ? 0 : 1;
}

function rasterise(g, size, SS) {
  size = size || 20;
  SS = SS || 4;
  const grid = [];
  for (let row = 0; row < size; row++) {
    const line = [];
    for (let col = 0; col < size; col++) {
      let hits = 0;
      for (let sy = 0; sy < SS; sy++) {
        for (let sx = 0; sx < SS; sx++) {
          const x = ((col + (sx + 0.5) / SS) / size) * 2 - 1;   // -1..1
          const y = (row + (sy + 0.5) / SS) / size;             //  0..1
          hits += coverageAt(g, x, y);
        }
      }
      line.push(hits / (SS * SS) >= 0.5 ? 1 : 0);
    }
    grid.push(line);
  }
  return grid;
}

/* Nonogram clues, derived from the picture — never authored. */
function clues(grid) {
  const n = grid.length;
  const runs = (arr) => {
    const out = []; let c = 0;
    for (const v of arr) { if (v) c++; else if (c) { out.push(c); c = 0; } }
    if (c) out.push(c);
    return out.length ? out : [0];
  };
  return {
    rows: grid.map(runs),
    cols: Array.from({ length: n }, (_, c) => runs(grid.map((r) => r[c])))
  };
}

const VOCABULARY = { FOREWING, HINDWING, PATTERN, ANTENNA, BODY, MARGIN };

function vocabularyCount() {
  return keys(FOREWING).length + keys(HINDWING).length + keys(PATTERN).length +
         keys(ANTENNA).length + keys(BODY).length + keys(MARGIN).length;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { genotype, rasterise, clues, coverageAt, tissueAt, TISSUE,
                     VOCABULARY, PALETTES, vocabularyCount };
}
if (typeof window !== 'undefined') {
  window.NoctuarySpecimens = { genotype, rasterise, clues, coverageAt, tissueAt, TISSUE,
                               VOCABULARY, PALETTES, vocabularyCount };
}
