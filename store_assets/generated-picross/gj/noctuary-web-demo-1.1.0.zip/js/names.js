/* ══════════════════════════════════════════════════════════════════════════════════
 * NOCTUARY — THE LABEL
 *
 * Every mounted specimen carries a handwritten label: a Latin binomial, a common name,
 * a catalogue number and a line from the collector's journal. It is the cheapest depth
 * in the whole product and it does real work — a cabinet of 66 unnamed silhouettes is a
 * puzzle list, and a cabinet of 66 NAMED specimens is a collection.
 *
 * ⛔ THE NAME IS DERIVED FROM THE ANIMAL, NOT FROM THE SEED.
 *
 * The lazy version hashes the seed into a random genus and a random epithet. This one
 * reads the genotype: the genus follows the wing and antenna, the epithet follows the
 * pattern, the common name follows the palette. So `Falcaria ocellata` genuinely has
 * falcate wings and an eyespot, and a player working through the cabinet slowly begins
 * to READ the labels — they can guess what a plate will look like before they solve it.
 * That is a mechanic hiding inside a cosmetic, and it costs nothing.
 *
 * Volume: 10 forewing genera x 7 antenna prefixes x 18 pattern epithets, before the
 * common-name and journal layers. Every specimen in the cabinet gets a distinct label.
 * ════════════════════════════════════════════════════════════════════════════════ */

'use strict';

/* Genus stem follows the FOREWING — the silhouette's dominant feature. */
const GENUS_STEM = {
  falcate: 'Falcaria', deltoid: 'Deltina', rounded: 'Orbina', elongate: 'Longara',
  hooked: 'Uncaria', broad: 'Latessa', sickle: 'Drepana', truncate: 'Trunculla',
  lanceolate: 'Lancena', scalloped: 'Crenula'
};

/* A prefix from the ANTENNA distinguishes species sharing a wing. */
const ANTENNA_PREFIX = {
  filiform: '', pectinate: 'Cteno', bipectinate: 'Bipect', clavate: 'Clav',
  setaceous: 'Set', lamellate: 'Lamell', plumose: 'Plum'
};

/* Species epithet follows the PATTERN — the thing you actually look at. */
const EPITHET = {
  veined: 'venosa', medial_band: 'fasciata', ocellus: 'ocellata', twin_ocelli: 'bioculata',
  reniform: 'reniformis', chevrons: 'chevronata', marbled: 'marmorea', striate: 'striata',
  costal_dash: 'costalis', hem_spots: 'punctaria', discal_spot: 'discalis',
  fascia_pair: 'bifasciata', net_veins: 'reticulata', clouded: 'nubila',
  arrowhead: 'sagittata', lunule: 'lunularis', peppered: 'pulveraria', hyaline: 'hyalina'
};

/* Common-name colour follows the PALETTE — the reveal's colourway. */
const PALETTE_WORD = {
  foxing: 'Foxed', verdigris: 'Verdigris', ironwash: 'Iron', tallow: 'Tallow',
  murex: 'Murex', peat: 'Peat', frost: 'Frost', cinnabar: 'Cinnabar'
};

/* Common-name noun follows the HINDWING. */
const HIND_NOUN = {
  fanned: 'Fan', lobed: 'Lobe', tailed: 'Swallowtail', vestigial: 'Ember',
  ample: 'Mantle', angular: 'Kite', crescent: 'Crescent', plumed: 'Plume'
};

/* Body gives the honorific. */
const BODY_WORD = {
  stout: 'Stout', slender: 'Slender', tufted: 'Tufted', tapered: 'Taper',
  crested: 'Crested', cylindric: 'Drum'
};

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June',
                'July', 'August', 'September', 'October', 'November', 'December'];

const PLACES = [
  'the orchard wall', 'a lit window', 'the lime avenue', 'the old kiln',
  'the sunken lane', 'a lantern on the quay', 'the churchyard yew', 'the mill leat',
  'the heath above the tarn', 'a gap in the hedge', 'the glasshouse vent',
  'the cattle trough', 'the beacon field', 'a stand of birch', 'the harbour steps'
];

const WEATHER = [
  'in a warm drizzle', 'under a full moon', 'in still, close air', 'after thunder',
  'in the first frost', 'on a night of no wind', 'in sea fog', 'under cloud',
  'in a rising gale', 'on the turn of the tide'
];

const HABITS = [
  'came readily to light', 'would not settle', 'rested with wings flat',
  'held the antennae folded back', 'took sugar from the ropes', 'flew high and late',
  'was found already still', 'left scales on the glass', 'answered a second lamp',
  'sat out the rain entire'
];

/* Deterministic per-specimen stream, independent of the genotype's own PRNG so adding a
 * journal line can never shift the animal. */
function stream(seed) {
  let s = (seed ^ 0x5bf03635) >>> 0;
  return function () {
    s ^= s << 13; s >>>= 0;
    s ^= s >> 17;
    s ^= s << 5;  s >>>= 0;
    return s / 4294967296;
  };
}
const from = (r, arr) => arr[Math.floor(r() * arr.length) % arr.length];

/* ══════════════════════════════════════════════════════════════════════════════════
 * label(genotype) -> the whole card.
 * ════════════════════════════════════════════════════════════════════════════════ */
function label(g) {
  const r = stream(g.seed);

  const prefix = ANTENNA_PREFIX[g.antenna] || '';
  // the join never leaves three identical letters in a row ("Lamell" + "longara" -> "Lamellongara", not "Lamelllongara")
  const genus = (prefix ? prefix + GENUS_STEM[g.forewing].toLowerCase() : GENUS_STEM[g.forewing])
    .replace(/([a-z])\1{2,}/gi, function (m, ch) { return ch + ch; });
  const species = EPITHET[g.pattern];

  const paletteWord = PALETTE_WORD[g.palette];
  const noun = HIND_NOUN[g.hindwing];
  const bodyWord = BODY_WORD[g.body];

  // Two shapes so the cabinet does not read as one template repeated 66 times.
  const common = r() < 0.5
    ? 'The ' + paletteWord + ' ' + noun
    : 'The ' + bodyWord + ' ' + paletteWord + ' ' + noun;

  /*
   * ⛔ EVERY NUMBER IN GENERATED PROSE IS FORMATTED AT THE POINT IT IS MADE.
   * A sibling title shipped the line "burns for 1.5323386839372457" past 117 assertions,
   * because every test checked the number was RIGHT and none read the sentence. There is
   * no raw float anywhere below, and check_names.js asserts that no label contains one.
   */
  const day = 1 + Math.floor(r() * 28);
  const month = from(r, MONTHS);
  const wingspanMm = Math.round((18 + r() * 44) * 10) / 10;   // one decimal, always

  const journal = 'Taken at ' + from(r, PLACES) + ', ' + ordinal(day) + ' ' + month +
                  ', ' + from(r, WEATHER) + '. ' + capitalise(from(r, HABITS)) + '.';

  return {
    genus: genus,
    species: species,
    binomial: genus + ' ' + species,
    common: common,
    wingspan: wingspanMm.toFixed(1) + ' mm',
    journal: journal,
    catalogue: catalogueNumber(g.seed)
  };
}

function catalogueNumber(seed) {
  /*
   * Looks like a museum accession: two letters, four digits. Stable per specimen.
   *
   * ⛔ `>>>` NOT `>>`. The first version used `(h >> 5) % A.length` with h an UNSIGNED
   * 32-bit seed. `>>` is the SIGNED shift, so every seed with the high bit set — about
   * half of them — produced a negative index, and `A[negative]` is `undefined` rather
   * than an error. The label rendered as "Rundefined-8744" on 36 of the 66 cabinet
   * cards. It is a one-character bug that prints a whole broken word onto the reward
   * screen, and only a check that read the STRING could see it.
   */
  const A = 'ABCDEFGHJKLMNPRSTVWXYZ';
  const h = (seed >>> 0);
  return A[h % A.length] + A[(h >>> 5) % A.length] + '-' +
         String(1000 + (h % 9000)).slice(0, 4);
}

function ordinal(n) {
  const s = ['th', 'st', 'nd', 'rd'];
  const v = n % 100;
  return n + (s[(v - 20) % 10] || s[v] || s[0]);
}
function capitalise(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { label, GENUS_STEM, EPITHET, PALETTE_WORD, HIND_NOUN, BODY_WORD };
}
if (typeof window !== 'undefined') {
  window.NoctuaryNames = { label };
}
