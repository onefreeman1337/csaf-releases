/* ══════════════════════════════════════════════════════════════════════════════════
 * NOCTUARY — AUDIO
 *
 * Two layers, deliberately different technologies, for reasons the wing has already paid
 * for once (Wings/Games/CLAUDE.md §8a trap 2):
 *
 *   MUSIC — plain <audio> elements. ⛔ NOT fetch + decodeAudioData.
 *     The paid desktop build loads from `file://`, where XMLHttpRequest and fetch are BOTH
 *     blocked, while the free web demo is served over http by itch. A buffer-based player
 *     works perfectly in the demo and leaves the PAID build silent — exactly backwards, and
 *     invisible to an iframe probe, which correctly tests over http. A media element works
 *     on both origins. That is measured, on this machine, in a previous title.
 *
 *   SFX — WebAudio oscillators, synthesised at runtime, no files at all.
 *     Bespoke, our own IP, zero bytes, and blessed by Art_and_Audio_Doctrine §4. Swapping
 *     this for generic presets to make a FILE COUNT go up would be a downgrade.
 *
 * The audio context is created on the first user gesture, never before: browsers block it
 * otherwise, and the itch iframe is where that bites.
 * ════════════════════════════════════════════════════════════════════════════════ */

'use strict';

(function (root) {

  let ctx = null;
  let muted = false;
  let started = false;
  const tracks = {};
  let current = null;

  try { muted = localStorage.getItem('noctuary.muted') === '1'; } catch (e) { /* private mode */ }

  function isMuted() { return muted; }

  function setMuted(v) {
    muted = !!v;
    try { localStorage.setItem('noctuary.muted', muted ? '1' : '0'); } catch (e) { /* ignore */ }
    for (const k in tracks) tracks[k].volume = muted ? 0 : tracks[k]._target;
    return muted;
  }

  /* Called from the first click/keypress. Everything before this is a no-op by design. */
  function start() {
    if (started) return;
    started = true;
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (AC) ctx = new AC();
    } catch (e) { ctx = null; }
    if (current) playMusic(current);
  }

  function register(name, src, volume) {
    const a = new Audio(src);
    a.loop = true;
    a.preload = 'auto';
    a._target = volume == null ? 0.55 : volume;
    a.volume = muted ? 0 : a._target;
    tracks[name] = a;
  }

  function playMusic(name) {
    if (current === name && tracks[name] && !tracks[name].paused) return;
    for (const k in tracks) {
      if (k !== name && !tracks[k].paused) { tracks[k].pause(); tracks[k].currentTime = 0; }
    }
    current = name;
    if (!started) return;                    // will start on the first gesture
    const a = tracks[name];
    if (!a) return;
    const p = a.play();
    // A rejected play() is normal before a gesture and must not throw into the game loop.
    if (p && p.catch) p.catch(function () { /* blocked until a gesture; ignore */ });
  }

  /* ── SFX. Each one is a designed shape, not a preset. ─────────────────────────── */
  function tone(opts) {
    if (!ctx || muted) return;
    const t0 = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const filt = ctx.createBiquadFilter();
    filt.type = 'lowpass';
    filt.frequency.value = opts.cutoff || 4000;
    osc.type = opts.wave || 'sine';
    osc.frequency.setValueAtTime(opts.from, t0);
    if (opts.to && opts.to !== opts.from) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(20, opts.to), t0 + opts.dur);
    }
    gain.gain.setValueAtTime(0, t0);
    gain.gain.linearRampToValueAtTime(opts.gain || 0.12, t0 + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.0005, t0 + opts.dur);
    osc.connect(filt); filt.connect(gain); gain.connect(ctx.destination);
    osc.start(t0);
    osc.stop(t0 + opts.dur + 0.02);
  }

  const SFX = {
    /* a soft graphite tap — the sound of marking a cell */
    fill:    () => tone({ wave: 'triangle', from: 320, to: 220, dur: 0.055, gain: 0.10, cutoff: 2200 }),
    /* crossing out is drier and higher, so the two are distinguishable without looking */
    cross:   () => tone({ wave: 'sine', from: 900, to: 700, dur: 0.040, gain: 0.055, cutoff: 3200 }),
    erase:   () => tone({ wave: 'sine', from: 240, to: 190, dur: 0.045, gain: 0.05, cutoff: 1600 }),
    /* a line completing — a small rising confirmation, easy to miss and pleasant to catch */
    line:    () => { tone({ wave: 'sine', from: 523, to: 659, dur: 0.16, gain: 0.075, cutoff: 5000 }); },
    hint:    () => { tone({ wave: 'sine', from: 784, to: 1047, dur: 0.20, gain: 0.07, cutoff: 6000 }); },
    open:    () => tone({ wave: 'triangle', from: 180, to: 300, dur: 0.18, gain: 0.09, cutoff: 2400 }),
    back:    () => tone({ wave: 'triangle', from: 300, to: 180, dur: 0.16, gain: 0.08, cutoff: 2400 }),
    /* the reveal: an arpeggio up the natural minor triad, the one moment allowed to sing */
    reveal:  () => {
      if (!ctx || muted) return;
      [440, 523, 659, 880].forEach((f, i) => {
        setTimeout(() => tone({ wave: 'sine', from: f, to: f, dur: 0.9, gain: 0.085, cutoff: 6000 }), i * 130);
      });
    }
  };

  function play(name) { const f = SFX[name]; if (f) f(); }

  const api = { start, register, playMusic, play, setMuted, isMuted,
                get started() { return started; } };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.NoctuaryAudio = api;

})(typeof window !== 'undefined' ? window : null);
