/* ══════════════════════════════════════════════════════════════════════════════════
 * NOCTUARY — THE BOARD
 *
 * The picross grid, its clue gutters, and the input model. Rendering and interaction
 * only; it owns no game state beyond the player's marks on one plate.
 *
 * CELL VALUES use the solver's vocabulary exactly (-1 unknown, 0 crossed, 1 filled) so a
 * board can be handed straight to solver.nextDeduction() with no translation. A
 * translation layer between "what the player sees" and "what the solver reasons about" is
 * how a hint ends up disagreeing with the board.
 * ════════════════════════════════════════════════════════════════════════════════ */

'use strict';

(function (root) {

  const UNKNOWN = -1, CROSSED = 0, FILLED = 1;

  function makeBoard(n) {
    const g = [];
    for (let r = 0; r < n; r++) g.push(new Array(n).fill(UNKNOWN));
    return g;
  }

  /* Clue gutter sizing: the longest clue in any line decides how much room the gutter
   * needs. Computed rather than guessed, because a 20x20 plate can have a 7-number row
   * and a fixed gutter either clips it or wastes a third of the screen on a 10x10. */
  function gutterFor(clues) {
    let maxRow = 1, maxCol = 1;
    // 1.2.0 (review D-13): a two-digit number is one digit wider than the step allows for, about 0.48 of a step, so the gutter
    // reserves half a step more for each one in the row (draw() now advances by measured width).
    for (const c of clues.rows) maxRow = Math.max(maxRow, c.length + 0.5 * c.filter((v) => v >= 10).length);
    for (const c of clues.cols) maxCol = Math.max(maxCol, c.length);
    return { rows: maxRow, cols: maxCol };
  }

  /*
   * ⛔ THE GUTTER IS SIZED FROM THE TEXT, NOT FROM THE CELL — and getting that wrong was
   * visible the moment the plate was rendered and looked at.
   *
   * The first version reserved `clueCount * cell` for the row gutter. On a 10x10 with a
   * three-number row that is 3 x 51 = 153px, while the clues are drawn at font size
   * 0.52*cell with 1.25 spacing and actually occupy 3 x 26 = 78px. The result was a 75px
   * strip of blank paper down the left of every plate that looked exactly like a
   * rendering bug, because it was one.
   *
   * The numbers below are the SAME constants draw() uses (0.52 font, 1.25 and 1.3
   * spacing), expressed once. If either changes, both change together.
   */
  const FONT_OF_CELL = 0.52;
  const ROW_STEP = FONT_OF_CELL * 1.25;   // horizontal advance per row-clue number
  const COL_STEP = FONT_OF_CELL * 1.30;   // vertical advance per column-clue number
  // The last column clue clears the grid by the same 7px a row clue does, measured from the digit's
  // edge (half a digit is ~0.36 of the font size), not from its centre: a fixed 10px from the centre
  // left a 10x10 plate's large digits sitting on the grid's top rule (1.1.0 review).
  const COL_GAP_PX = 7, HALF_DIGIT = 0.36;

  function layout(clues, box) {
    const n = clues.rows.length;
    const gut = gutterFor(clues);

    // Solve for the largest cell that fits grid + text gutter in both axes.
    const cell = Math.floor(Math.min(
      (box.w - 22) / (n + gut.rows * ROW_STEP),
      (box.h - 26) / (n + gut.cols * COL_STEP)
    ));
    const gridW = cell * n;
    const padX = Math.ceil(gut.rows * ROW_STEP * cell) + 10;
    const padY = Math.ceil(gut.cols * COL_STEP * cell + HALF_DIGIT * FONT_OF_CELL * cell) + COL_GAP_PX + 2;

    // Centre the WHOLE plate — paper plus gutters — in the box, not just the grid.
    const plateW = gridW + padX, plateH = gridW + padY;
    const gx = box.x + Math.floor((box.w - plateW) / 2) + padX;
    const gy = box.y + Math.floor((box.h - plateH) / 2) + padY;
    return { n, cell, gx, gy, gut, gridW, padX, padY };
  }

  function cellAt(L, px, py) {
    const c = Math.floor((px - L.gx) / L.cell);
    const r = Math.floor((py - L.gy) / L.cell);
    if (r < 0 || c < 0 || r >= L.n || c >= L.n) return null;
    return { r, c };
  }

  /* A line's clue is SATISFIED when the player's filled runs match it exactly. Dimming
   * satisfied clues is the single largest quality-of-life feature in a picross and it is
   * derived, never stored — so it cannot go stale. */
  function runsOf(arr) {
    const out = []; let k = 0;
    for (const v of arr) { if (v === FILLED) k++; else if (k) { out.push(k); k = 0; } }
    if (k) out.push(k);
    return out.length ? out : [0];
  }
  function clueSatisfied(clue, line) {
    const r = runsOf(line);
    if (r.length !== clue.length) return false;
    for (let i = 0; i < r.length; i++) if (r[i] !== clue[i]) return false;
    return true;
  }

  function isComplete(board, grid) {
    const n = grid.length;
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) {
      const want = grid[r][c] === 1;
      const got = board[r][c] === FILLED;
      if (want !== got) return false;
    }
    return true;
  }

  /* ════════════════════════════════════════════════════════════════════════════════
   * draw — the plate as a sheet of ruled paper with the clues printed in the margins.
   *
   * Gate 1 note: a picross is a grid of squares, which is the easiest thing in games to
   * render as a default-looking template and the hardest to make beautiful. What carries
   * it here is the specimen palette (every plate is drawn in its OWN colourway, so the
   * board already looks different plate to plate), the 5-cell rules, and typography.
   * ════════════════════════════════════════════════════════════════════════════════ */
  function draw(ctx, L, clues, board, pal, fonts, opts) {
    opts = opts || {};
    const { n, cell, gx, gy } = L;
    const ink = pal.ink, wash = pal.wash, accent = pal.accent;

    // paper under the whole plate including the gutters
    ctx.fillStyle = wash;
    const padX = L.padX, padY = L.padY;
    roundRect(ctx, gx - padX, gy - padY, L.gridW + padX + 14, L.gridW + padY + 14, 3);
    ctx.fill();

    // cells
    for (let r = 0; r < n; r++) {
      for (let c = 0; c < n; c++) {
        const x = gx + c * cell, y = gy + r * cell;
        const v = board[r][c];
        if (v === FILLED) {
          ctx.fillStyle = ink;
          ctx.fillRect(x + 1, y + 1, cell - 1, cell - 1);
        } else {
          // very faint alternating tint per 5x5 block so the eye can count without rules
          const blk = (Math.floor(r / 5) + Math.floor(c / 5)) % 2;
          ctx.fillStyle = blk ? 'rgba(0,0,0,0.035)' : 'rgba(0,0,0,0.012)';
          ctx.fillRect(x + 1, y + 1, cell - 1, cell - 1);
          if (v === CROSSED) {
            /*
             * ⛔ SMALL AND FAINT, DELIBERATELY. The first version drew a heavy X at 30%
             * inset in 30% black, and a nearly-solved plate rendered as a WALL OF CROSSES
             * that completely drowned the picture emerging inside it. Looking at a
             * near-complete board made it obvious: the crosses were the loudest thing on
             * screen and they are the one mark that carries no information about the
             * specimen. A cross means "not here" — it is scaffolding, and scaffolding
             * should recede. The filled cells are the drawing.
             */
            ctx.strokeStyle = 'rgba(0,0,0,0.17)';
            ctx.lineWidth = Math.max(1, cell * 0.045);
            const m = cell * 0.38;
            ctx.beginPath();
            ctx.moveTo(x + m, y + m); ctx.lineTo(x + cell - m, y + cell - m);
            ctx.moveTo(x + cell - m, y + m); ctx.lineTo(x + m, y + cell - m);
            ctx.stroke();
          }
        }
      }
    }

    // rules: hairline every cell, heavier every 5
    ctx.strokeStyle = 'rgba(0,0,0,0.14)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let i = 0; i <= n; i++) {
      if (i % 5 === 0) continue;
      const p = 0.5 + Math.round(gx + i * cell);
      ctx.moveTo(p, gy); ctx.lineTo(p, gy + L.gridW);
      const q = 0.5 + Math.round(gy + i * cell);
      ctx.moveTo(gx, q); ctx.lineTo(gx + L.gridW, q);
    }
    ctx.stroke();

    ctx.strokeStyle = 'rgba(0,0,0,0.42)';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    for (let i = 0; i <= n; i += 5) {
      const p = 0.5 + Math.round(gx + i * cell);
      ctx.moveTo(p, gy - 4); ctx.lineTo(p, gy + L.gridW + 4);
      const q = 0.5 + Math.round(gy + i * cell);
      ctx.moveTo(gx - 4, q); ctx.lineTo(gx + L.gridW + 4, q);
    }
    ctx.stroke();

    // clues
    const fs = Math.max(9, Math.floor(cell * 0.52));
    ctx.font = '600 ' + fs + 'px ' + fonts.mono;
    ctx.textBaseline = 'middle';

    // 1.2.0 (review D-13): row clues advance by each number's MEASURED width plus a constant gap. Through 1.1.0 every number sat
    // on a fixed 1.25-font step, so a two-digit number after another number nearly touched it ([1 10 1] read "110 1", gap
    // 0.7-2.1 px on 7 paid plates). The gap is chosen so a single-digit row lands on exactly the pixels it did before.
    const digitW = ctx.measureText('0').width;
    const rowGap = fs * 1.25 - digitW;
    for (let r = 0; r < n; r++) {
      const done = clueSatisfied(clues.rows[r], board[r]);
      ctx.textAlign = 'right';
      const cl = clues.rows[r];
      // an empty line's clue is [0] and prints "0", dimmed like any satisfied clue while the line has no fills
      let x = gx - 7;
      for (let i = cl.length - 1; i >= 0; i--) {
        const s = String(cl[i]);
        ctx.fillStyle = done ? 'rgba(0,0,0,0.22)' : ink;
        ctx.fillText(s, x, gy + r * cell + cell / 2);
        x -= ctx.measureText(s).width + rowGap;
      }
    }
    for (let c = 0; c < n; c++) {
      const col = new Array(n);
      for (let r = 0; r < n; r++) col[r] = board[r][c];
      const done = clueSatisfied(clues.cols[c], col);
      ctx.textAlign = 'center';
      const cl = clues.cols[c];
      for (let i = 0; i < cl.length; i++) {
        ctx.fillStyle = done ? 'rgba(0,0,0,0.22)' : ink;
        ctx.fillText(String(cl[i]),
                     gx + c * cell + cell / 2,
                     gy - COL_GAP_PX - fs * HALF_DIGIT - (cl.length - 1 - i) * (fs * 1.3));
      }
    }

    // hover crosshair — costs nothing and removes almost all mis-clicks on a 20x20
    if (opts.hover) {
      const { r, c } = opts.hover;
      ctx.fillStyle = 'rgba(0,0,0,0.055)';
      ctx.fillRect(gx, gy + r * cell, L.gridW, cell);
      ctx.fillRect(gx + c * cell, gy, cell, L.gridW);
      ctx.strokeStyle = accent;
      ctx.lineWidth = 2;
      ctx.strokeRect(gx + c * cell + 0.5, gy + r * cell + 0.5, cell - 1, cell - 1);
    }

    // hint flash
    if (opts.hint && opts.hintAlpha > 0) {
      ctx.save();
      ctx.globalAlpha = opts.hintAlpha;
      ctx.strokeStyle = accent;
      ctx.lineWidth = 3;
      ctx.strokeRect(gx + opts.hint.col * cell - 1.5, gy + opts.hint.row * cell - 1.5, cell + 3, cell + 3);
      ctx.restore();
    }
  }

  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  const api = { UNKNOWN, CROSSED, FILLED, makeBoard, layout, cellAt, draw,
                isComplete, clueSatisfied, runsOf, roundRect };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.NoctuaryBoard = api;

})(typeof window !== 'undefined' ? window : null);
