# NOCTUARY — credits, licences and provenance

Copyright (c) 2026 Core Systems Asset Factory.

**Everything in this game is original.** There is no third-party asset of any kind in it —
no art pack, no sound pack, no font file, no sample, no soundfont, no engine and no
library. That means there is nothing here you are obliged to attribute, and nothing that
can be taken down by someone else.

This file exists anyway, because "we did not use anything" is a claim that should be
written down and checkable rather than assumed.

**The one exception is the wrapper, not the game.** The Windows download runs these same files
inside **Electron**, an open-source runtime (MIT licence). Its licence and Chromium's ship packed
inside `NOCTUARY.exe` as `LICENSE.electron.txt` and `LICENSES.chromium.html`. The free browser
demo has no wrapper at all.

---

## Art

**No image files ship with this game, apart from the favicon** — and that favicon is itself
a specimen, rendered at build time by the same code that draws every moth in the cabinet
(`Internal_Ops/make_favicon.js`).

Every specimen is generated at runtime from `js/specimens.js`, which contains a
vocabulary of **56 morphological marks** across six organs, written as data by an AI:

| Organ | Marks |
| --- | --- |
| Forewing | 10 — falcate, deltoid, rounded, elongate, hooked, broad, sickle, truncate, lanceolate, scalloped |
| Hindwing | 8 — fanned, lobed, tailed, vestigial, ample, angular, crescent, plumed |
| Wing pattern | 18 — veined, medial band, ocellus, twin ocelli, reniform, chevrons, marbled, striate, costal dash, hem spots, discal spot, fascia pair, net veins, clouded, arrowhead, lunule, peppered, hyaline |
| Antenna | 7 — filiform, pectinate, bipectinate, clavate, setaceous, lamellate, plumose |
| Body | 6 — stout, slender, tufted, tapered, crested, cylindric |
| Wing margin | 7 — entire, dentate, crenulate, erose, fringed, excavate, produced |

plus eight colourways (foxing, verdigris, ironwash, tallow, murex, peat, frost, cinnabar)
and a set of continuous proportions.

Both the coarse puzzle grid and the fully-resolved specimen are drawn from the **same**
geometry function, at different resolutions. That is why the moth does not shift as it
develops.

## Typography

No font files ship. The game asks for a serif and a monospace face from those already
installed on your system, with the usual fallbacks:

- Serif: `Iowan Old Style`, `Palatino Linotype`, `Palatino`, `Georgia`, generic `serif`
- Mono: `Iosevka`, `Consolas`, `SF Mono`, `Menlo`, generic `monospace`

## Music

Two tracks — *The Cabinet* and *The Plate* — composed for this game as note data in
`Internal_Ops/Audio/compose.js` and rendered to `.ogg` by oscillator synthesis through the
factory's own renderer.

**No sample, no soundfont, no instrument library, no AI music service.** The oscillators
*are* the instruments. Both tracks are checked mechanically before they ship: every pitch
must be a member of the track's declared scale, and every voice must fill the bar grid
exactly, so a mistyped accidental or a voice that would drift out of phase on each loop
cannot get through.

Because the music is self-contained procedural synthesis rather than generative AI, it
carries no AI-audio tag. See the disclosure note below.

## Sound effects

Synthesised live in `js/audio.js` from WebAudio oscillators and a filter. There are no
sound files. Each effect is shaped for its job — the fill mark is a soft graphite tap, the
cross is drier and higher so the two are distinguishable without looking.

## Code

All original, written for this game. No framework, no engine, no bundler, no npm
dependency, no analytics, no network access. Eight plain JavaScript files, readable in
order, and a ninth in the paid download only (`content_full.js`, the four paid drawers):

| File | What it is |
| --- | --- |
| `specimens.js` | the morphology — genotype, rasteriser, clue derivation |
| `solver.js` | the line solver, which is what makes every plate fair |
| `content_full.js` | paid download only: the plate numbers of the Third, Fourth and Fifth Drawers and The Night Case |
| `puzzle.js` | the plate factory and the cabinet |
| `names.js` | binomials, common names, journal lines |
| `reveal.js` | the full-resolution specimen and its mount |
| `board.js` | the grid, the clue gutters, the input model |
| `audio.js` | music playback and the synthesised effects |
| `game.js` | screens, save, and the loop |

---

## AI disclosure

Declared truthfully on the store listing, per itch's classification requirements:

- **Code — yes.** Every line was written by an AI.
- **Graphics — yes.** Generated programmatically. There is no image asset, but the visuals
  are machine-produced and that is what the question asks.
- **Text & Dialog — yes.** The specimen names and journal lines are generated at runtime
  from a vocabulary written as data by an AI.
- **Sounds — no.** Both music tracks and every sound effect are self-contained procedural
  synthesis. itch's own quality guidelines state that self-contained algorithmic audio
  ("dynamic music, etc.") is not considered generative AI and does not need tagging. The
  AI-written *code* that produces the sound is covered by "Code — yes".

---

Made by **Core Systems Asset Factory**.
