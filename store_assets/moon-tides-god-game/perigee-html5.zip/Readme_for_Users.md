# PERIGEE

**Your only lever is the moon.**

A settlement stands on a shelving coast. It wants water in some places and never in others, and it
will not listen to you. You are not its god of harvests, only of tides: you set the orbit, and
everything the sea does follows from where the moon is.

Free, plays in the browser, about fifteen minutes for a full run of ten seasons. Your progress is
saved in your own browser after every season.

---

## The controls

| | |
| --- | --- |
| **W / S**, or the **arrow keys** | set the orbit |
| **mouse wheel** over the map | set the orbit |
| **drag** up or down on the map | set the orbit |
| **space** | pause |
| **F** | run faster |
| **M** | mute |
| **H** | how it works |

That is the whole control scheme, and it is the whole game. You never place a building, dig a
channel, bless a field or smite anything. You move the moon.

## What the settlement wants, and why it cannot have it

| | wants |
| --- | --- |
| **tide mill** | water just over its sill, and moving. A drowned wheel stops as surely as a dry one. |
| **salt farm** | never to be flooded. Salt in a field is not gradual. |
| **cistern** | one rare high tide over its lip. It then holds for days. |
| **dock** | depth over the bar, and it does not care how much. |

They disagree. The tide that turns the mill drowns the low field. The cistern can only be filled by
a tide that would ruin both — so you dive to it deliberately, take the damage, and climb back out.

**Salt in the fields throttles everything the settlement produces.** That is what stops "go to
perigee and stay there" from being the answer, and it is why the game has a decision in it rather
than a slider.

## Three things worth knowing before you start

**The moon has weight.** It answers slowly. A dive to perigee has to be *started* several hours
before the hour that needs it, and you will still be low when the water reaches the fields.

**High water travels along the shore.** It does not arrive everywhere at once, so the far end of
the coast floods later than the near end. Where a structure stands decides which hour is its hour.

**The coast remembers.** Every tide cuts at the waterline and lays the spoil seaward. At the end of
a season the ground has moved, so the sills move with it — and a field whose bank has eroded below
the neap tide will flood on tides that used to be safe. Raising a bank costs offerings, and it
competes directly with the sky.

## What you spend on

Nothing in the tree improves the settlement. The settlement is not yours; the sky is.

**TIDE TABLE** a forecast, so a dive can be started on purpose instead of in hope ·
**SLIP** the moon answers faster · **MASS** every tide grows, including the one that takes the field
· **ECCENTRICITY** the orbit breathes across the month on its own · **APSIDAL CONTROL** you choose
*when* in the month perigee falls · **THE SECOND MOON** two tidal waves add and interfere ·
**RESONANCE** lock them to a 3:2 ratio so the pattern repeats and can be planned around.

## If a season goes badly

The settlement loses one point of standing. At zero it stops looking up — and you begin that same
season again, from the checkpoint written when it opened, with the coast, the settlement and every
upgrade kept. **There is no full restart in this game except the one you ask for by name.**

---

## Honest notes

- The tidal law is real. Tide-raising force falls off as the cube of distance, so perigee is not a
  tuned power-up: measured across the legal orbital range that is 0.13 m of amplitude at apogee
  against 1.47 m at perigee, out of one equation.
- Nothing is downloaded. No font file, no library, no framework. The typeface is whichever of
  Iowan Old Style, Palatino, Georgia or your system serif you already have.
- **AI disclosure:** the code is AI-written and the store cover is AI-generated. The sound and music
  are not — they are procedurally synthesised from oscillators and noise by our own tool, which itch
  is explicit is not generative AI. `CREDITS.txt` lists every file that ships and where it came from.

---

**More free browser games from Core Systems Asset Factory:** <https://csaf.itch.io>

Copyright (c) 2026 Core Systems Asset Factory. See `LICENSE.txt`.
