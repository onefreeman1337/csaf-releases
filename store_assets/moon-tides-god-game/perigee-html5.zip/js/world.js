/**
 * world.js — PERIGEE's coast, its settlement, and the memory the sea leaves in both.
 *
 * Pure and deterministic: no canvas, no DOM, no timers, no Math.random. Everything here is a
 * function of a seed and of what the player has already done, which is what makes the season
 * checkpoint in `game.js` a real save rather than a screenshot of one.
 *
 * ⭐ WHY THE TERRAIN LIVES HERE AND NOT IN A BAKED ASSET. The coast is not scenery — it is the
 * board. Erosion moves it every season, so a shipped heightmap would be stale after season one, and
 * a second implementation of the same shape (one to bake, one to erode) is exactly the drift master
 * CLAUDE.md §2b keeps charging us for. One generator, one array, mutated in place.
 *
 * ⚠️ THE GENERATOR IS DELIBERATELY THE SAME SHAPE THE PROBE PROVED: a seaward GRADIENT with noise
 * riding on it, never thresholded noise. Thresholded noise gives islands and lagoons everywhere,
 * which is §0-ART's camouflage failure wearing a map. `Internal_Ops/_probe/tide_probe.js` renders
 * this field and it was passed by eye on the fourth pass.
 *
 * Copyright (c) 2026 Core Systems Asset Factory.
 */
'use strict';

(function (root) {
  /* ── deterministic noise ──────────────────────────────────────────────────────────────────────
   * pixel_forge's fbm is Node-only, and this module has to run in the browser. Rather than ship a
   * baked field and keep two coasts in sync, the same WRAPPING value-noise fbm runs in both places
   * and the probe renders it. Wrapping is not decoration: it is the seam guarantee, and it is why
   * every frequency must divide the field size. */

  /**
   * Integer hash to a float in 0..1. Deterministic across platforms (all ops stay in int32).
   * @param {number} x Grid x.
   * @param {number} y Grid y.
   * @param {number} seed Seed.
   * @returns {number} 0..1
   */
  function hash2(x, y, seed) {
    let h = (x * 374761393 + y * 668265263 + seed * 1442695040) | 0;
    h = (h ^ (h >>> 13)) * 1274126177 | 0;
    h = h ^ (h >>> 16);
    return (h >>> 0) / 4294967296;
  }

  /** Smoothstep, the interpolant that keeps value noise from showing its lattice. */
  const smooth = (t) => t * t * (3 - 2 * t);

  /**
   * One octave of wrapping value noise over a square field.
   * @param {number} size Field size.
   * @param {number} freq Cells per side at this octave. MUST divide size.
   * @param {number} seed Seed.
   * @returns {Float64Array} size*size samples.
   */
  function octave(size, freq, seed) {
    if (size % freq !== 0) throw new Error('freq ' + freq + ' does not divide field ' + size);
    const out = new Float64Array(size * size);
    const cell = size / freq;
    for (let y = 0; y < size; y++) {
      const gy = Math.floor(y / cell), fy = smooth((y % cell) / cell);
      const gy1 = (gy + 1) % freq;
      for (let x = 0; x < size; x++) {
        const gx = Math.floor(x / cell), fx = smooth((x % cell) / cell);
        const gx1 = (gx + 1) % freq;
        const a = hash2(gx, gy, seed), b = hash2(gx1, gy, seed);
        const c = hash2(gx, gy1, seed), d = hash2(gx1, gy1, seed);
        out[y * size + x] = (a + (b - a) * fx) * (1 - fy) + (c + (d - c) * fx) * fy;
      }
    }
    return out;
  }

  /**
   * Fractal sum of wrapping octaves, amplitude halving per octave.
   * @param {number} size Field size.
   * @param {number[]} freqs Frequencies, each dividing size.
   * @param {number} seed Seed.
   * @returns {Float64Array} Field (NOT normalised — see equalise).
   */
  function fbm(size, freqs, seed) {
    const out = new Float64Array(size * size);
    let amp = 1, norm = 0;
    for (let i = 0; i < freqs.length; i++) {
      const o = octave(size, freqs[i], seed + i * 7919);
      for (let j = 0; j < out.length; j++) out[j] += o[j] * amp;
      norm += amp;
      amp *= 0.5;
    }
    for (let j = 0; j < out.length; j++) out[j] /= norm;
    return out;
  }

  /**
   * Rank-normalise a field to 0..1.
   * ⛔ §0-ART, paid for once already: an fbm field does NOT reach its nominal range, so a
   * `mask > 0.55` can select NOTHING while every check stays green. Equalise before any threshold.
   * @param {Float64Array} f Field.
   * @returns {Float64Array} Rank-normalised copy.
   */
  function equalise(f) {
    const idx = Array.from(f.keys()).sort((a, b) => f[a] - f[b]);
    const out = new Float64Array(f.length);
    for (let r = 0; r < idx.length; r++) out[idx[r]] = r / (idx.length - 1);
    return out;
  }

  /* ── the coast ────────────────────────────────────────────────────────────────────────────── */

  const FIELD = 256;              // fbm is square-only and every freq must divide this
  /** Metres of relief the coast spans, top to bottom. Tuned so a spring range is ~38% of it. */
  const RELIEF = 2.2;

  /**
   * @typedef {object} Coast
   * @property {number} W Cells across (the along-shore axis; u = x / W).
   * @property {number} H Cells down (inland at y=0, open sea at y=H-1).
   * @property {number} seed Seed.
   * @property {Float64Array} height Metres above chart datum, per cell.
   * @property {Float64Array} bedrock The height the sea cannot cut below, per cell.
   */

  /**
   * Build a coast.
   * @param {number} W Cells across.
   * @param {number} H Cells down.
   * @param {number} seed Seed.
   * @returns {Coast} A fresh, unweathered coast.
   */
  function makeCoast(W, H, seed) {
    const cN = equalise(fbm(FIELD, [4, 8], seed));
    const fN = equalise(fbm(FIELD, [16, 32], seed + 4242));
    const height = new Float64Array(W * H);
    const bedrock = new Float64Array(W * H);
    for (let y = 0; y < H; y++) {
      const shelf = 1 - y / (H - 1);                 // land high inland, low seaward
      for (let x = 0; x < W; x++) {
        const i = (y % FIELD) * FIELD + (x % FIELD);
        const n = cN[i] * 0.62 + fN[i] * 0.38;
        /* ⚠️ THE OFFSET IS A COMPOSITION DECISION AND IT COST NOTHING TO GET RIGHT, so it is written
         * down. It sets WHERE ON THE SCREEN the shoreline falls; it does not change the relief span
         * at all (the range moves, the width does not), so every threshold, the level gate and the
         * balance curve are untouched by it. At -1.15 the shore sat at about 52% down and the
         * bottom third of the frame was open sea with nothing happening in it. At -0.95 it sits
         * nearer 60%, which gives the intertidal band — the part of the map the whole game is
         * about — more of the picture. */
        const h = (shelf * 2.4 - 0.95) + (n - 0.5) * 1.30;
        height[y * W + x] = h * RELIEF;
        // ⚠️ Bedrock is not flavour. Without a floor, erosion is a one-way ratchet that eventually
        // drowns every coast identically, and a world that always ends the same way is not a world.
        bedrock[y * W + x] = h * RELIEF - 0.55 - cN[i] * 0.9;
      }
    }
    return { W, H, seed, height, bedrock };
  }

  /**
   * Height in metres at a cell, clamped to the map.
   * @param {Coast} c Coast.
   * @param {number} x Cell x.
   * @param {number} y Cell y.
   * @returns {number} Metres above datum.
   */
  function heightAt(c, x, y) {
    const cx = x < 0 ? 0 : x >= c.W ? c.W - 1 : x;
    const cy = y < 0 ? 0 : y >= c.H ? c.H - 1 : y;
    return c.height[cy * c.W + cx];
  }

  /**
   * Relief span of the live coast, for any threshold that has to mean something.
   * ⛔ Printed rather than assumed — the probe's third failure was reasoning about a threshold
   * without ever printing the number it depended on.
   * @param {Coast} c Coast.
   * @returns {{min:number, max:number, span:number}} Metres.
   */
  function relief(c) {
    let min = Infinity, max = -Infinity;
    for (let i = 0; i < c.height.length; i++) {
      if (c.height[i] < min) min = c.height[i];
      if (c.height[i] > max) max = c.height[i];
    }
    return { min, max, span: max - min };
  }

  /* ── erosion: the world remembers ─────────────────────────────────────────────────────────── */

  /**
   * Accumulate one instant of wave exposure. Only cells NEAR the waterline take work — the surf
   * zone does the cutting, not the deep water and not the dry land.
   *
   * @param {Coast} c Coast.
   * @param {Float32Array} exposure Accumulator, one per cell, mutated.
   * @param {function(number):number} levelOf Water level in metres for a cell x.
   * @param {number} dt Hours of exposure this instant represents.
   * @param {number} energy Tidal energy multiplier (bigger tides cut harder).
   */
  function accumulateExposure(c, exposure, levelOf, dt, energy) {
    const BAND = 0.22;                                // metres either side of the waterline
    for (let x = 0; x < c.W; x++) {
      const L = levelOf(x);
      for (let y = 0; y < c.H; y++) {
        const d = Math.abs(c.height[y * c.W + x] - L);
        if (d < BAND) exposure[y * c.W + x] += dt * energy * (1 - d / BAND);
      }
    }
  }

  /**
   * Apply a season's accumulated exposure to the coast.
   *
   * ⭐ The rule that makes this a SYSTEM rather than a decay: the sea cuts where it works and the
   * spoil has to go somewhere, so what a cell loses its seaward neighbour gains. A coast that only
   * ever lowers is a timer; a coast that lowers here and shoals there is a place with a history.
   *
   * @param {Coast} c Coast, mutated.
   * @param {Float32Array} exposure Season accumulator.
   * @param {number} rate Metres cut per unit of exposure.
   * @returns {{cut:number, laid:number, deepest:number, cells:number}} Season erosion ledger.
   */
  function applyErosion(c, exposure, rate) {
    let cut = 0, laid = 0, deepest = 0, cells = 0;
    const delta = new Float64Array(c.height.length);
    for (let y = 0; y < c.H; y++) {
      for (let x = 0; x < c.W; x++) {
        const i = y * c.W + x;
        const e = exposure[i];
        if (e <= 0) continue;
        const room = c.height[i] - c.bedrock[i];
        if (room <= 0) continue;
        const d = Math.min(room, e * rate);
        delta[i] -= d;
        cut += d;
        if (d > deepest) deepest = d;
        if (d > 0.005) cells++;
        const j = (Math.min(c.H - 1, y + 1)) * c.W + x;   // spoil moves seaward
        delta[j] += d * 0.62;
        laid += d * 0.62;
      }
    }
    for (let i = 0; i < c.height.length; i++) c.height[i] += delta[i];
    // ⚠️ `cut` is a SUM ACROSS CELLS and is meaningless to a player — an early ledger printed
    // "847 m of shore cut" for an average of four centimetres. The number the player can check
    // against the map is the DEEPEST single cut and how much of the shore moved at all.
    return { cut, laid, deepest, cells };
  }

  /* ── the settlement ───────────────────────────────────────────────────────────────────────── */

  /**
   * @typedef {object} Site
   * @property {string} kind mill | farm | cistern | dock
   * @property {number} x Cell x.
   * @property {number} y Cell y.
   * @property {number} u Along-shore position, 0..1 (derived from x).
   * @property {number} sill The height that matters, metres (derived from terrain, then fixed).
   * @property {number} damage 0..1; at 1 the structure is ruined for the season.
   * @property {boolean} ruined Set when damage reaches 1.
   * @property {number} bornSeason The season it appeared.
   */

  /**
   * The sill height each kind wants, relative to chart datum. These are the numbers the level gate
   * accepted (`Internal_Ops/solve.js`): a settlement is only a LEVEL if the best orbit is interior
   * and still has an hour that hurts.
   */
  const SILL_TARGET = { cistern: 1.05, farm: 0.38, mill: 0.10, dock: -0.30 };
  /** How far a real cell may sit from the ideal sill before it is not that kind of site. */
  const SILL_TOL = 0.09;

  /**
   * Find a cell on the coast whose height is close to a target sill, near a wanted u.
   * ⚠️ Searches OUTWARD from the wanted position rather than scanning the map, so a settlement
   * spreads along the shore instead of clustering wherever the noise happens to be obliging.
   * @param {Coast} c Coast.
   * @param {number} target Wanted sill height, metres.
   * @param {number} wantU Wanted along-shore position, 0..1.
   * @param {Site[]} taken Existing sites, to keep clear of.
   * @returns {?{x:number,y:number,h:number}} A cell, or null if the coast has no such place.
   */
  function findSite(c, target, wantU, taken) {
    const wx = Math.round(wantU * (c.W - 1));
    let best = null, bestCost = Infinity;
    for (let dx = 0; dx < c.W; dx++) {
      for (const s of [1, -1]) {
        const x = wx + dx * s;
        if (x < 3 || x >= c.W - 3) continue;
        for (let y = 2; y < c.H - 2; y++) {
          const h = c.height[y * c.W + x];
          const err = Math.abs(h - target);
          if (err > SILL_TOL) continue;
          let clear = true;
          for (const t of taken) {
            if (Math.abs(t.x - x) < 9 && Math.abs(t.y - y) < 7) { clear = false; break; }
          }
          if (!clear) continue;
          const cost = dx + err * 40;
          if (cost < bestCost) { bestCost = cost; best = { x, y, h }; }
        }
        if (dx === 0) break;
      }
      if (best && dx > bestCost) break;               // nothing further out can win
    }
    return best;
  }

  /**
   * Place a new structure of a kind, or return null if the coast offers nowhere for it.
   * @param {Coast} c Coast.
   * @param {string} kind Structure kind.
   * @param {number} wantU Wanted along-shore position.
   * @param {Site[]} taken Existing sites.
   * @param {number} season Season number.
   * @returns {?Site} The new site.
   */
  function placeSite(c, kind, wantU, taken, season) {
    const cell = findSite(c, SILL_TARGET[kind], wantU, taken);
    if (!cell) return null;
    return {
      kind, x: cell.x, y: cell.y, u: cell.x / c.W,
      sill: Math.round(cell.h * 100) / 100,
      damage: 0, ruined: false, bornSeason: season,
    };
  }

  /**
   * The founding settlement: the exact five the level gate accepted, in the order it accepted them.
   * @param {Coast} c Coast.
   * @returns {Site[]} Sites.
   */
  function foundSettlement(c) {
    const want = [['mill', 0.22], ['farm', 0.44], ['dock', 0.70], ['farm', 0.58], ['cistern', 0.34]];
    const out = [];
    for (const [kind, u] of want) {
      const s = placeSite(c, kind, u, out, 1);
      if (s) out.push(s);
    }
    return out;
  }

  /**
   * What the settlement asks for next, given what it already has.
   *
   * ⭐ THE PLAYER NEVER CHOOSES THIS, AND THAT IS THE DESIGN. You do not build; you are the moon.
   * A settlement that prospers grows, and it grows toward whatever it is short of — so your own
   * success writes the next problem. A coast full of farms is a coast that punishes the perigee dive
   * you needed last season.
   *
   * @param {Site[]} sites Existing sites.
   * @param {number} season Season number.
   * @returns {string} The kind wanted next.
   */
  function wantsNext(sites, season) {
    const n = { mill: 0, farm: 0, cistern: 0, dock: 0 };
    for (const s of sites) n[s.kind]++;
    // Bread first, then power, then water, then trade — and always the scarcest of those.
    const order = ['farm', 'mill', 'cistern', 'dock'];
    const ideal = { farm: 0.42, mill: 0.22, cistern: 0.18, dock: 0.18 };
    // ⛔ INTEGER ARITHMETIC, AND THE EPSILON IS NOT PEDANTRY. The first version compared
    // `ideal - have` directly and 0.42-0.40 came out 0.020000000000000018 while 0.22-0.20 came out
    // 0.020000000000000004, so floating-point noise — not design — decided what the settlement built
    // next. A tie must be broken by the stated priority order, visibly, not by the last bit of a
    // double. Scaled to thousandths and rounded, ties are ties and `order` resolves them.
    let want = 'farm', worst = -Infinity;
    for (const k of order) {
      const have = sites.length ? n[k] / sites.length : 0;
      const gap = Math.round((ideal[k] - have) * 1000);
      if (gap > worst) { worst = gap; want = k; }
    }
    if (season >= 4 && n.cistern < 2 && worst < 0.06) want = 'cistern';
    return want;
  }

  const API = {
    FIELD, RELIEF, SILL_TARGET, SILL_TOL,
    hash2, octave, fbm, equalise,
    makeCoast, heightAt, relief,
    accumulateExposure, applyErosion,
    findSite, placeSite, foundSettlement, wantsNext,
  };

  if (typeof module === 'object' && module.exports) module.exports = API;
  else root.WORLD = API;
}(typeof globalThis !== 'undefined' ? globalThis : this));
