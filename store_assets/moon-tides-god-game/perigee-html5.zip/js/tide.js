/**
 * tide.js — PERIGEE's rules model. Pure, deterministic, no canvas, no DOM, no timers.
 *
 * ⭐ WHY THIS FILE IS SEPARATE FROM THE GAME LOOP. ANNEAL proved the shape: a pure integer/real
 * model with an exhaustive test beside it, and a real-time layer that resolves THROUGH the model
 * rather than beside it. When the sim and the rules are the same code, "what the player saw" and
 * "what the rules said" cannot drift.
 *
 * THE ONE LEVER. The player sets an ORBIT — radius and phase — and nothing else. Everything the
 * world does is a consequence of where the moon is.
 *
 * ⚠️ THE PHYSICS IS REAL AND THAT IS DELIBERATE (Gate 2). Tidal force scales as M / r^3, so
 * perigee is not a tuned power-up: the inverse cube does the work. Measured across the legal
 * orbital range that is 0.13 m at apogee against 1.47 m at perigee from one equation.
 *
 * Copyright (c) 2026 Core Systems Asset Factory.
 */
'use strict';

(function (root) {
  /** Orbital radius bounds, in mean-distance units. */
  const R_MIN = 0.62, R_MAX = 1.38;

  /** Base tidal amplitude at mean distance, metres. Tuned so spring range is ~38% of coast relief. */
  const K = 0.35;

  /**
   * How far the tidal wave lags along the coast, in cycles across the full map width.
   * ⭐ This is what makes WHERE matter as well as WHEN: at 0.25 the far end of the coast is a
   * quarter-cycle behind the near end, so a single orbit floods the map in a sweep rather than all
   * at once — and a settlement's hour depends on where it stands.
   */
  const SWEEP = 0.25;

  /**
   * Tidal amplitude for an orbital radius.
   * @param {number} r Orbital radius in mean-distance units.
   * @returns {number} Half-range of the tide, metres.
   */
  function amplitude(r) {
    return K / (r * r * r);
  }

  /**
   * Water level at a normalised position along the coast.
   * @param {number} u Position across the coast, 0..1.
   * @param {number} r Orbital radius.
   * @param {number} phase Orbital phase, 0..1, wrapping.
   * @returns {number} Water level in metres relative to chart datum.
   */
  function levelAt(u, r, phase) {
    return amplitude(r) * Math.cos(2 * Math.PI * (phase - u * SWEEP));
  }

  /**
   * The phase at which a given position sees its own high water.
   * ⚠️ Derived, never guessed: cos peaks when its argument is 0, so phase = u * SWEEP.
   * @param {number} u Position across the coast, 0..1.
   * @returns {number} Phase of local high water, 0..1.
   */
  function highWaterPhase(u) {
    return ((u * SWEEP) % 1 + 1) % 1;
  }

  /* ── consumers ────────────────────────────────────────────────────────────────────────────────
   * Each structure wants water, and they want DIFFERENT water. This is the whole design: one lever,
   * several consumers whose needs conflict, so you sequence rather than satisfy. */

  /**
   * @typedef {object} Structure
   * @property {string} kind   mill | farm | cistern | dock
   * @property {number} u      position across the coast, 0..1
   * @property {number} sill   the height that matters for this structure, metres
   */

  /** Structure behaviour. Each returns a score in -1..1 for a given water level. */
  const KINDS = {
    /**
     * A tide mill wants water ABOVE its sill but not by much — it runs on the head of water
     * crossing the wheel, and a drowned wheel stops turning as surely as a dry one.
     */
    mill: {
      label: 'tide mill',
      wants: 'water just over the sill, and moving',
      /**
       * @param {number} level Water level, metres.
       * @param {number} sill Structure sill height, metres.
       * @returns {number} -1..1
       */
      score(level, sill) {
        const head = level - sill;
        if (head <= 0) return -0.15;               // idle, not damaged
        if (head > 1.2) return -0.6;               // drowned wheel
        return Math.min(1, head / 0.5);
      },
    },
    /**
     * A farm wants to stay dry. Salt water on a field is the loss, and it is not gradual.
     *
     * ⛔ A DRY FARM SCORES ZERO, NOT A BONUS, AND THAT IS A CORRECTION. The first version paid
     * +0.5 for every unflooded farm, which meant a settlement with two farms collected a free +1.0
     * every hour it was not actively drowning. MEASURED consequence: the level gate's "the best
     * orbit still has a bad hour" could not go negative — it sat at exactly +0.60 for every orbit
     * from r=1.04 outward, because two idle farms were paying for the mill's and dock's bad hours.
     * A settlement could look healthy while three of its five structures were frozen.
     * ⭐ You do not GAIN from a field not drowning; you LOSE when it does. Farms are pure downside
     * risk, which is both the honest model and the one that makes the arithmetic mean something.
     */
    farm: {
      label: 'salt farm',
      wants: 'never to be flooded',
      score(level, sill) {
        const over = level - sill;
        if (over <= 0) return 0;                   // dry is the baseline, not a reward
        return -Math.min(1, 0.4 + over);           // any flooding hurts, deep flooding ruins
      },
    },
    /** A cistern fills only on a spring high — it is the reason to visit perigee at all. */
    cistern: {
      label: 'cistern',
      wants: 'a rare high tide over its lip',
      score(level, sill) {
        return level >= sill ? 1 : -0.05;          // cheap to leave empty, valuable to fill
      },
    },
    /** A dock needs depth over its bar to float a hull, and does not care how much. */
    dock: {
      label: 'dock',
      wants: 'depth over the bar',
      score(level, sill) {
        return level - sill >= 0.4 ? 1 : -0.2;
      },
    },
  };

  /**
   * Score one structure at one orbital state.
   * @param {Structure} st Structure.
   * @param {number} r Orbital radius.
   * @param {number} phase Orbital phase.
   * @returns {number} -1..1
   */
  function scoreStructure(st, r, phase) {
    const k = KINDS[st.kind];
    if (!k) throw new Error('unknown structure kind: ' + st.kind);
    return k.score(levelAt(st.u, r, phase), st.sill);
  }

  /**
   * Score a whole settlement at one instant.
   * @param {Structure[]} structures Structures.
   * @param {number} r Orbital radius.
   * @param {number} phase Orbital phase.
   * @returns {{total:number, each:number[]}} Total and per-structure scores.
   */
  function scoreSettlement(structures, r, phase) {
    const each = structures.map((s) => scoreStructure(s, r, phase));
    return { total: each.reduce((a, b) => a + b, 0), each };
  }

  /**
   * Integrate a settlement's score across one full orbital cycle.
   *
   * ⭐ THIS is the function the game is actually about. A single instant is not the question — the
   * moon keeps moving, so the player is choosing a whole CYCLE, and a radius that is wonderful at
   * one phase may be ruinous three hours later.
   *
   * @param {Structure[]} structures Structures.
   * @param {number} r Orbital radius.
   * @param {number} [steps] Samples across the cycle.
   * @returns {{mean:number, worst:number, worstPhase:number}} Cycle summary.
   */
  function scoreCycle(structures, r, steps) {
    const n = steps || 64;
    let sum = 0, worst = Infinity, worstPhase = 0;
    for (let i = 0; i < n; i++) {
      const p = i / n;
      const t = scoreSettlement(structures, r, p).total;
      sum += t;
      if (t < worst) { worst = t; worstPhase = p; }
    }
    return { mean: sum / n, worst, worstPhase };
  }

  const API = {
    R_MIN, R_MAX, K, SWEEP, KINDS,
    amplitude, levelAt, highWaterPhase,
    scoreStructure, scoreSettlement, scoreCycle,
  };

  if (typeof module === 'object' && module.exports) module.exports = API;
  else root.TIDE = API;
}(typeof globalThis !== 'undefined' ? globalThis : this));
