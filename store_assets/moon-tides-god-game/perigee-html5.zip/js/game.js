/**
 * game.js — PERIGEE. Screens, input, the real-time layer, and the save.
 *
 * ⭐ THE REAL-TIME LAYER RESOLVES THROUGH THE MODEL, NEVER BESIDE IT. This file owns the clock, the
 * canvas and the player's hands; `tide.js`, `orbit.js`, `world.js`, `season.js` and `upgrades.js`
 * own every rule. Nothing here decides whether a mill is turning or a field is drowning — it asks.
 * That is why the level gate's verdict is a statement about the game the player actually plays.
 *
 * ⛔ SAVE AND RESUME IS A STANDING WING RULE, NOT A FEATURE (ledger B4). A failed season returns you
 * to the START OF THAT SEASON with the settlement, the coast and every unlock kept. There is no
 * full restart in this game except the one the player asks for by name.
 *
 * Copyright (c) 2026 Core Systems Asset Factory.
 */
'use strict';

(function () {
  const W = 960, H = 660, MAP_H = 540;
  const SAVE_KEY = 'csaf.perigee.v1';
  /** In-game hours per real second. A tidal cycle is six hours, so one cycle is five seconds. */
  const HOURS_PER_SECOND = 1.2;
  const FAST = 3;

  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');

  const G = {
    screen: 'loading',
    save: null,
    coast: null,
    cache: null,
    run: null,
    hit: [],
    mouse: { x: -1, y: -1, down: false },
    paused: false,
    fast: false,
    banner: 0,
    bannerText: '',
    ledger: null,
    lastLevels: null,
    toast: [],
    hoverSite: -1,
    err: null,
  };

  /* ── the save ────────────────────────────────────────────────────────────────────────────── */

  /**
   * Pack a coast's heights as base64 Int16 centimetres.
   * ⚠️ The coast is 20,736 cells and erosion has moved them, so it cannot be regenerated from the
   * seed alone — a saved game that regenerated the coast would hand the player back a world that had
   * forgotten what they did to it, which is the one thing this design promises it will not do.
   * Centimetre precision is well below anything the player can see or the rules can distinguish.
   * @param {Float64Array} h Heights in metres.
   * @returns {string} base64.
   */
  function packHeights(h) {
    const a = new Int16Array(h.length);
    for (let i = 0; i < h.length; i++) a[i] = Math.max(-32768, Math.min(32767, Math.round(h[i] * 100)));
    const b = new Uint8Array(a.buffer);
    let s = '';
    for (let i = 0; i < b.length; i += 4096) s += String.fromCharCode.apply(null, b.subarray(i, i + 4096));
    return btoa(s);
  }

  /**
   * Unpack heights written by packHeights.
   * @param {string} s base64.
   * @param {number} n Expected cell count.
   * @returns {?Float64Array} Heights, or null if the string is the wrong size.
   */
  function unpackHeights(s, n) {
    const bin = atob(s);
    if (bin.length !== n * 2) return null;
    const b = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) b[i] = bin.charCodeAt(i);
    const a = new Int16Array(b.buffer);
    const h = new Float64Array(n);
    for (let i = 0; i < n; i++) h[i] = a[i] / 100;
    return h;
  }

  /** Write the season checkpoint. Called at the START of a season, so a failure returns here. */
  function writeSave() {
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify({
        v: 1,
        seed: G.save.seed,
        season: G.save.season,
        offerings: G.save.offerings,
        standing: G.save.standing,
        unlocks: G.save.unlocks,
        best: G.save.best,
        sites: G.save.sites,
        heights: packHeights(G.coast.height),
      }));
      return true;
    } catch (e) { return false; }
  }

  /** @returns {?object} The stored save, or null. */
  function readSave() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return null;
      const s = JSON.parse(raw);
      return (s && s.v === 1 && Array.isArray(s.sites)) ? s : null;
    } catch (e) { return null; }
  }

  /* ── starting and continuing ─────────────────────────────────────────────────────────────── */

  /**
   * Begin a brand new world.
   * @param {number} [seed] Seed; a fresh one is derived from the clock if omitted.
   */
  function newGame(seed) {
    const s = seed === undefined ? (Date.now() % 100000) : seed;
    G.coast = WORLD.makeCoast(ART.MAP_W, ART.MAP_H, s);
    G.save = {
      seed: s, season: 1, offerings: 0, standing: 3, unlocks: {}, best: 0,
      sites: WORLD.foundSettlement(G.coast),
    };
    beginSeason();
  }

  /**
   * Resume the stored season checkpoint.
   * @param {object} s The save.
   */
  function continueGame(s) {
    G.coast = WORLD.makeCoast(ART.MAP_W, ART.MAP_H, s.seed);
    const h = unpackHeights(s.heights, G.coast.height.length);
    // ⚠️ A save whose height blob is the wrong length is a save from another map size. Refuse it
    // rather than silently playing on a coast the structures do not sit on.
    if (!h) { newGame(); return; }
    G.coast.height = h;
    G.save = {
      seed: s.seed, season: s.season, offerings: s.offerings, standing: s.standing,
      unlocks: s.unlocks || {}, best: s.best || 0, sites: s.sites,
    };
    beginSeason();
  }

  /** Start the season named by the save, and check-point it. */
  function beginSeason() {
    for (const st of G.save.sites) { st.damage = st.ruined ? 1 : 0; st.water = 0; }
    G.run = SEASON.begin(G.save.season, G.coast, G.save.sites, G.save.unlocks);
    G.cache = ART.terrainCache(G.coast, ORBIT.maxLevel(G.run.orbit));
    G.lastLevels = new Float32Array(ART.BUF_W);
    G.screen = 'play';
    G.paused = false;
    G.banner = 2.6;
    G.bannerText = 'SEASON ' + G.save.season;
    G.toast = [];
    G.prevScore = G.run.sites.map(() => 0);
    writeSave();
  }

  /**
   * Push a short message onto the on-map log.
   * @param {string} msg Message.
   * @param {string} [colour] Colour.
   */
  function toast(msg, colour) {
    // ⚠️ A CISTERN REFILLS EVERY TIME THE TIDE CROSSES ITS LIP, so a season at perigee stacked the
    // same sentence three deep and read as a bug rather than as three fillings. Repeating the line
    // adds no information; refreshing the one already there does.
    if (G.toast.length && G.toast[0].msg === msg) { G.toast[0].life = 6; return; }
    G.toast.unshift({ msg, colour: colour || ART.INK, life: 6 });
    if (G.toast.length > 4) G.toast.length = 4;
  }

  /* ── the clock ───────────────────────────────────────────────────────────────────────────── */

  let last = 0;

  /**
   * One animation frame.
   * @param {number} now Milliseconds from rAF.
   */
  function frame(now) {
    const dt = Math.min(0.1, (now - last) / 1000 || 0);
    last = now;
    try {
      if (G.screen === 'play' && !G.paused) advance(dt * HOURS_PER_SECOND * (G.fast ? FAST : 1));
      if (G.banner > 0) G.banner -= dt;
      for (const t of G.toast) t.life -= dt;
      G.toast = G.toast.filter((t) => t.life > 0);
      draw();
    } catch (e) {
      // ⛔ A THROW INSIDE rAF KILLS THE LOOP AND THE PAGE LOOKS FROZEN WITH NO ERROR ANYWHERE THE
      // PLAYER CAN SEE. Catch it, put it on the canvas, and stop pretending the game is running.
      G.err = (e && e.message) ? e.message : String(e);
      G.screen = 'error';
      try { draw(); } catch (e2) { /* nothing left to do */ }
      return;
    }
    requestAnimationFrame(frame);
  }

  /**
   * Advance the simulation by `hours`, in the model's own fixed steps.
   * ⚠️ FIXED STEPS, ACCUMULATED — never `step(dt)`. A variable step would make the tide, the damage
   * and the erosion depend on the player's frame rate, and the level gate's verdict would then be
   * about a game nobody has.
   * @param {number} hours In-game hours to advance.
   */
  function advance(hours) {
    G.acc = (G.acc || 0) + hours;
    while (G.acc >= SEASON.STEP_HOURS) {
      G.acc -= SEASON.STEP_HOURS;
      const before = G.run.sites.map((s) => ({ r: s.ruined, w: s.water || 0, d: s.damage }));
      const alive = SEASON.step(G.run);
      for (let i = 0; i < G.run.sites.length; i++) {
        const s = G.run.sites[i], b = before[i];
        if (s.ruined && !b.r) { toast(SEASON.ruinLine(s.kind), ART.WARN); SOUND.play('ruin', 0.6); }
        else if (s.kind === 'cistern' && (s.water || 0) >= 1 && b.w < 1) {
          toast('The cistern has taken the tide. It will hold for days.', ART.GOLD);
          SOUND.play('fill', 0.5);
        } else if (s.kind === 'farm' && s.damage > b.d && b.d === 0) {
          toast('Salt water is over the ' + (s.sill < 0.36 ? 'low field.' : 'field.'), ART.WARN);
          SOUND.play('warn', 0.35);
        } else if (s.kind === 'mill' && G.run.score[i] > 0 && G.prevScore[i] <= 0) {
          SOUND.play('high', 0.28);
        }
      }
      G.prevScore = G.run.score.slice();
      if (!alive) { closeSeason(); return; }
    }
  }

  /** End the season, bank it, and decide what screen the player lands on. */
  function closeSeason() {
    G.ledger = SEASON.close(G.run, G.save);
    if (G.ledger.yield > G.save.best) G.save.best = G.ledger.yield;
    G.save.season += 1;
    G.cache = ART.terrainCache(G.coast, ORBIT.maxLevel(G.run.orbit));
    SOUND.play('season', 0.5);
    G.screen = G.ledger.failed ? 'failed' : (G.ledger.won ? 'won' : 'ledger');
    if (!G.ledger.failed) writeSave();
  }

  /* ── drawing ─────────────────────────────────────────────────────────────────────────────── */

  /** Recompute the per-column water level for this instant. 320 calls, not 57,600. */
  function levelsNow() {
    const L = G.lastLevels;
    for (let x = 0; x < ART.BUF_W; x++) L[x] = ORBIT.levelAt(x / ART.BUF_W, G.run.orbit);
    return L;
  }

  /** Clear the hit list; every clickable is registered by the code that DREW it. */
  function beginHits() { G.hit = []; }

  /**
   * Register a clickable region.
   * @param {object} r Rect from ART.button.
   * @param {function():void} fn Action.
   */
  function hit(r, fn) { G.hit.push({ r, fn }); }

  /**
   * True when the pointer is inside a rect.
   * @param {object} r Rect.
   * @returns {boolean} Hovering.
   */
  function hot(r) {
    return G.mouse.x >= r.x && G.mouse.x <= r.x + r.w && G.mouse.y >= r.y && G.mouse.y <= r.y + r.h;
  }

  /** Paint the whole frame for whatever screen is current. */
  function draw() {
    beginHits();
    ctx.fillStyle = '#080a10';
    ctx.fillRect(0, 0, W, H);
    if (G.screen === 'loading') return drawLoading();
    if (G.screen === 'error') return drawError();
    if (G.screen === 'title') return drawTitle();
    if (G.screen === 'help') return drawHelp();
    /* ⛔ WHEN A FULL-SCREEN PANEL IS UP, THE WORLD DRAWS ITS PICTURE AND NONE OF ITS WORDS.
     * The layout gate reported six overprints on the ledger — every one of them a HUD or dial label
     * sitting UNDERNEATH the panel that covers it. ANNEAL settled this exact argument and the answer
     * was not to teach the gate about opacity: a string drawn under another string IS an overprint
     * to anything that can measure it, and visibility is not in the recorder's reach. Text nobody is
     * meant to read is not information, it is noise, so it is simply not drawn. The map, the
     * structures and the moon stay — they are the backdrop, and they carry no words. */
    const overlay = (G.screen === 'ledger' || G.screen === 'sky' || G.screen === 'failed'
      || G.screen === 'won');
    drawWorld(overlay);
    if (G.screen === 'ledger') drawLedger();
    else if (G.screen === 'sky') drawSky();
    else if (G.screen === 'failed') drawFailed();
    else if (G.screen === 'won') drawWon();
    return undefined;
  }

  /** The loading screen, which is also the proof that the assets are still arriving. */
  function drawLoading() {
    ART.text(ctx, 'PERIGEE', W / 2, H / 2 - 10, { align: 'center', size: 44, colour: ART.GOLD });
    ART.text(ctx, 'reading the sky', W / 2, H / 2 + 24, { align: 'center', size: 15, colour: ART.DIM });
  }

  /** An honest error screen. A frozen canvas with a silent console is worse than a red box. */
  function drawError() {
    ART.panel(ctx, 80, 200, W - 160, 220);
    ART.text(ctx, 'THE SIMULATION STOPPED', W / 2, 250, { align: 'center', size: 24, colour: ART.WARN });
    ART.paragraph(ctx, String(G.err), 110, 292, W - 220, { size: 14, colour: ART.INK });
    ART.text(ctx, 'Nothing you have built is lost.', 110, 352, { size: 15, colour: ART.INK });
    ART.paragraph(ctx, 'The checkpoint written when this season opened is still in your browser. '
      + 'Reload the page and press CONTINUE to start the season again.',
      110, 378, W - 220, { size: 14, colour: ART.DIM });
  }

  /**
   * The title screen's backdrop: a real coast, at a real tide, generated by the real generator.
   *
   * ⭐ §1.1 — THE PRODUCT GENERATES THE PICTURE. The first title screen was a flat gradient, which is
   * a perfectly tidy way of showing a buyer nothing. This is the same `makeCoast`, the same plates
   * and the same tide model the game runs on, so the title cannot drift from the product: change the
   * terrain and the title changes with it. It costs one coast at load, once.
   */
  let titleWorld = null;
  function titleBackdrop() {
    if (!titleWorld) {
      const coast = WORLD.makeCoast(ART.MAP_W, ART.MAP_H, 20260829);
      const orbit = ORBIT.fresh({});
      orbit.r = orbit.rTarget = 0.74;
      orbit.t = 2.1;
      const levels = new Float32Array(ART.BUF_W);
      for (let x = 0; x < ART.BUF_W; x++) levels[x] = ORBIT.levelAt(x / ART.BUF_W, orbit);
      titleWorld = { cache: ART.terrainCache(coast, ORBIT.maxLevel(orbit)), levels, max: ORBIT.maxLevel(orbit) };
    }
    ART.drawMap(ctx, titleWorld.cache, titleWorld.levels, titleWorld.max, 0, 170);
    // fade the top of the coast into the night sky so the type has quiet ground to sit on
    const f = ctx.createLinearGradient(0, 170, 0, 560);
    f.addColorStop(0, 'rgba(11,18,32,1)');
    f.addColorStop(0.45, 'rgba(11,18,32,0.86)');
    f.addColorStop(1, 'rgba(11,18,32,0.30)');
    ctx.fillStyle = f;
    ctx.fillRect(0, 170, W, H - 170);
    /* ⚠️ AND A SCRIM DOWN THE LEFT, because the first version of this backdrop put pale surf and
     * bright shoal directly under the buttons and the disclosure line — the coast looked good and
     * the words became unreadable, which is a worse title screen than the flat gradient it replaced.
     * Every string on this screen lives in the left 560px; the moon and the open coast keep the
     * right. Composition, rather than turning the picture down until it stops competing. */
    const s = ctx.createLinearGradient(0, 0, 620, 0);
    s.addColorStop(0, 'rgba(7,12,22,0.93)');
    s.addColorStop(0.62, 'rgba(7,12,22,0.80)');
    s.addColorStop(1, 'rgba(7,12,22,0)');
    ctx.fillStyle = s;
    ctx.fillRect(0, 0, 620, H);
  }

  function drawTitle() {
    const saved = readSave();
    ctx.save();
    const g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#070c16'); g.addColorStop(1, '#0b1220');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    ctx.restore();
    titleBackdrop();
    ART.drawMoon(ctx, 745, 190, 250);
    ART.text(ctx, 'PERIGEE', 90, 210, { size: 76, colour: ART.GOLD });
    ART.text(ctx, 'Your only lever is the moon.', 94, 250, { size: 20, colour: ART.INK });
    ART.paragraph(ctx,
      'A settlement stands on a shelving coast. It wants water in some places and never in others, '
      + 'and it will not listen to you. You are not its god of harvests, only of tides: you set the '
      + 'orbit, and everything the sea does follows from where the moon is.',
      94, 300, 560, { size: 16, colour: ART.DIM, lead: 25 });

    let y = 430;
    if (saved) {
      hit(ART.button(ctx, 'CONTINUE — season ' + saved.season, 94, y, 300, 44,
        { hot: hot({ x: 94, y, w: 300, h: 44 }), size: 17 }), () => { SOUND.unlock(); continueGame(saved); });
      y += 58;
    }
    const r2 = { x: 94, y, w: 300, h: 44 };
    hit(ART.button(ctx, saved ? 'NEW COAST' : 'BEGIN', 94, y, 300, 44, { hot: hot(r2), size: 17 }),
      () => {
        SOUND.unlock();
        if (saved && !confirmNew()) return;
        newGame();
      });
    y += 58;
    const r3 = { x: 94, y, w: 300, h: 44 };
    hit(ART.button(ctx, 'HOW IT WORKS', 94, y, 300, 44, { hot: hot(r3), size: 17 }),
      () => { SOUND.unlock(); G.screen = 'help'; });

    ART.text(ctx, 'Free, from Core Systems Asset Factory. AI assisted: code, graphics, text. '
      + 'Sound and music are procedural synthesis, not generated audio.',
      94, H - 40, { size: 12.5, colour: 'rgba(178,174,158,0.95)' });
  }

  /**
   * ⛔ NEVER `window.confirm` — a native dialog freezes the extension that drives this factory's
   * browser automation, which is a documented, repeatedly-paid-for trap (§3c trap 3, and again at
   * js13k). A second click on the same button is the confirmation.
   * @returns {boolean} True once the player has clicked twice.
   */
  let armNew = 0;
  function confirmNew() {
    const now = performance.now();
    if (now - armNew < 4000) { armNew = 0; return true; }
    armNew = now;
    toast('A new coast abandons the saved settlement. Click again to confirm.', ART.WARN);
    return false;
  }

  function drawHelp() {
    ctx.fillStyle = '#070c16'; ctx.fillRect(0, 0, W, H);
    /* ⚠️ THE SCREEN THAT EXPLAINS THE COAST SHOULD SHOW THE COAST. This was a flat fill and the
     * density gate read it at 197 colours — a fair reading of a page of prose on a rectangle. The
     * backdrop is the same generated coast the title uses, held well back so two columns of body
     * text stay comfortable: context, not decoration. */
    ctx.save();
    ctx.globalAlpha = 0.5;
    titleBackdrop();
    ctx.restore();
    ctx.fillStyle = 'rgba(7,12,22,0.55)'; ctx.fillRect(0, 0, W, H);
    ART.text(ctx, 'HOW IT WORKS', 70, 78, { size: 34, colour: ART.GOLD });
    const colW = 380;
    let y = 130;
    y = ART.paragraph(ctx, 'THE LEVER', 70, y, colW, { size: 17, colour: ART.GOLD });
    y = ART.paragraph(ctx,
      'You set the moon\'s orbital radius and nothing else. Tidal force falls off as the cube of '
      + 'distance, so bringing the moon close does not raise the tide a little — it raises it '
      + 'enormously. The moon has weight: it answers slowly, so a dive has to be started before the '
      + 'hour that needs it.',
      70, y + 6, colW, { size: 14, colour: ART.INK, lead: 21 });
    y = ART.paragraph(ctx, 'THE COAST ANSWERS IN ORDER', 70, y + 14, colW, { size: 17, colour: ART.GOLD });
    y = ART.paragraph(ctx,
      'High water travels ALONG the shore rather than arriving everywhere at once, so the far end of '
      + 'the coast floods later than the near end. Where a structure stands decides which hour is its '
      + 'hour.',
      70, y + 6, colW, { size: 14, colour: ART.INK, lead: 21 });
    y = ART.paragraph(ctx, 'THE COAST REMEMBERS', 70, y + 14, colW, { size: 17, colour: ART.GOLD });
    ART.paragraph(ctx,
      'Every tide cuts at the waterline and lays the spoil seaward. At the end of a season the ground '
      + 'has moved, so the sills move with it and last season\'s safe orbit is not this season\'s.',
      70, y + 6, colW, { size: 14, colour: ART.INK, lead: 21 });

    let y2 = 130;
    y2 = ART.paragraph(ctx, 'WHAT THE SETTLEMENT WANTS', 510, y2, colW, { size: 17, colour: ART.GOLD });
    y2 += 10;
    for (const k of ['mill', 'farm', 'cistern', 'dock']) {
      ART.drawSprite(ctx, k, 'idle', 0, 0, 541, y2 + 13);
      ART.text(ctx, TIDE.KINDS[k].label.toUpperCase(), 578, y2 + 8, { size: 15, colour: ART.INK });
      ART.paragraph(ctx, TIDE.KINDS[k].wants, 578, y2 + 28, colW - 70, { size: 13, colour: ART.DIM });
      y2 += 62;
    }
    y2 = ART.paragraph(ctx, 'AND THEY DISAGREE', 510, y2 + 12, colW, { size: 17, colour: ART.GOLD });
    ART.paragraph(ctx,
      'The tide that turns the mill drowns the low field, and the cistern can only be filled by a '
      + 'tide that would ruin both. You cannot satisfy them at once, so you sequence them. Salt in '
      + 'the fields throttles everything the settlement produces, which is what stops "dive and stay '
      + 'there" from being the answer.',
      510, y2 + 6, colW, { size: 14, colour: ART.INK, lead: 21 });

    // ⚠️ ONE LINE, DELIBERATELY. The longer version wrapped and orphaned the word 'mutes' onto a
    // second row that sat on the BACK button's top border. The layout gate did NOT flag it and was
    // right not to - the two TEXT boxes do not intersect - which is why the gate now also records
    // button rectangles and asserts no stray string lands inside one.
    ART.paragraph(ctx, 'CONTROLS   —   W / S or arrows set the orbit  ·  wheel or drag on the map  ·  '
      + 'SPACE pauses  ·  F faster  ·  M mutes',
      70, H - 92, W - 140, { size: 14, colour: ART.DIM });
    const r = { x: 70, y: H - 56, w: 160, h: 36 };
    hit(ART.button(ctx, 'BACK', r.x, r.y, r.w, r.h, { hot: hot(r) }),
      () => { G.screen = G.run ? 'play' : 'title'; });
  }

  /**
   * The map, the sky dial, the HUD — everything on screen while a season runs.
   * @param {boolean} [backdropOnly] Draw the picture and none of the words (a panel is over it).
   */
  function drawWorld(backdropOnly) {
    const levels = levelsNow();
    ART.drawMap(ctx, G.cache, levels, ORBIT.maxLevel(G.run.orbit), 0, 0);

    // structures, then their state badges
    G.hoverSite = -1;
    for (let i = 0; i < G.run.sites.length; i++) {
      const s = G.run.sites[i];
      const st = s.ruined ? 'ruin' : (G.run.score[i] > 0 ? 'work' : 'idle');
      const r = ART.drawSprite(ctx, s.kind, st, s.x, s.y, 0, 0);
      if (hot(r) && G.mouse.y < MAP_H) G.hoverSite = i;
      if (!s.ruined && s.damage > 0) {
        ctx.fillStyle = 'rgba(0,0,0,0.55)';
        ctx.fillRect(r.x + 6, r.y + r.h - 8, r.w - 12, 5);
        ctx.fillStyle = s.damage > 0.66 ? '#c8735a' : '#d6c08a';
        ctx.fillRect(r.x + 6, r.y + r.h - 8, (r.w - 12) * s.damage, 5);
      }
    }

    if (backdropOnly) {
      /* ⚠️ The map is 540 tall and the canvas is 660, so a backdrop with no HUD left a HARD BLACK
       * BAND across the bottom fifth of every overlay screen — it read as the picture being cut
       * off rather than as a vignette. The coast now fades out into the dark instead of stopping. */
      const g = ctx.createLinearGradient(0, MAP_H - 90, 0, MAP_H + 30);
      g.addColorStop(0, 'rgba(8,10,16,0)');
      g.addColorStop(1, 'rgba(8,10,16,1)');
      ctx.fillStyle = g;
      ctx.fillRect(0, MAP_H - 90, W, 120);
      ctx.fillStyle = '#08090f';
      ctx.fillRect(0, MAP_H + 30, W, H - MAP_H - 30);
      return;
    }

    drawDial();
    drawHud();

    // the on-map log
    let ty = MAP_H - 22;
    for (const t of G.toast) {
      ctx.save();
      ctx.globalAlpha = Math.min(1, t.life / 1.4);
      // ⚠️ A DROP SHADOW, because this text lands on whatever the coast happens to be doing.
      // Orange on wet mud is legible and orange on sunlit turf is not, and which one you get
      // depends on the tide - i.e. on the one thing the player is changing.
      ctx.save();
      ctx.globalAlpha *= 0.75;
      ART.text(ctx, t.msg, 19, ty + 1, { size: 15, colour: '#05070c' });
      ctx.restore();
      ART.text(ctx, t.msg, 18, ty, { size: 15, colour: t.colour });
      ctx.restore();
      ty -= 24;
    }

    if (G.hoverSite >= 0) drawSiteTip(G.run.sites[G.hoverSite], G.run.score[G.hoverSite]);

    if (G.banner > 0 && G.screen === 'play') {
      ctx.save();
      ctx.globalAlpha = Math.min(1, G.banner / 1.2);
      ART.text(ctx, G.bannerText, W / 2, 170, { align: 'center', size: 54, colour: ART.GOLD });
      ART.text(ctx, 'bring ' + G.run.quota + ' in yield, and keep the fields',
        W / 2, 204, { align: 'center', size: 17, colour: ART.INK });
      ctx.restore();
    }
    // ⛔ THE CAPTURE HARNESS PAUSES THE GAME SO IT IS THE ONLY DRIVER OF THE CLOCK (§3c-7), which
    // meant every store screenshot had PAUSED stamped across the middle of it. The flag is set only
    // by the harness and is never reachable from play.
    if (G.paused && G.screen === 'play' && !G.captureMode) {
      ART.text(ctx, 'PAUSED', W / 2, MAP_H / 2, { align: 'center', size: 40, colour: ART.GOLD });
      ART.text(ctx, 'space to go on', W / 2, MAP_H / 2 + 28, { align: 'center', size: 15, colour: ART.DIM });
    }
  }

  /** A tooltip for the structure under the pointer. */
  function drawSiteTip(s, score) {
    const lines = [
      TIDE.KINDS[s.kind].label.toUpperCase(),
      'wants ' + TIDE.KINDS[s.kind].wants,
      'sill ' + s.sill.toFixed(2) + ' m · water ' + ORBIT.levelAt(s.u, G.run.orbit).toFixed(2) + ' m',
      s.ruined ? 'RUINED — repair it between seasons'
        : (score > 0 ? 'working' : (s.damage > 0 ? 'taking damage' : 'idle')),
    ];
    const w = 320;
    let hgt = 20;
    for (const l of lines) hgt += ART.wrap(ctx, l, w - 28, 14).length * 20;
    const x = Math.min(W - w - 12, G.mouse.x + 18);
    const y = Math.min(MAP_H - hgt - 12, G.mouse.y + 14);
    ART.panel(ctx, x, y, w, hgt);
    let ly = y + 26;
    ART.text(ctx, lines[0], x + 14, ly, { size: 15, colour: ART.GOLD });
    ly += 22;
    for (let i = 1; i < lines.length; i++) {
      ly = ART.paragraph(ctx, lines[i], x + 14, ly, w - 28,
        { size: 13, colour: i === 3 && s.ruined ? ART.WARN : ART.DIM, lead: 19 });
    }
  }

  /**
   * The orbit dial: the only control in the game, drawn in the sky where it belongs.
   *
   * ⭐ The GHOST ring is the whole reason this reads rather than confuses. The player sets a TARGET
   * and the moon takes hours to get there, so the interface has to show both — where the moon is,
   * and where it has been told to go — or the rate limit feels like unresponsiveness instead of
   * mass.
   */
  function drawDial() {
    const cx = W - 152, cy = 158, R0 = 38, R1 = 104;
    const o = G.run.orbit;
    /**
     * Map an orbital radius to a pixel radius on the dial.
     * @param {number} r Orbital radius.
     * @returns {number} Pixel radius.
     */
    const px = (r) => R0 + (r - TIDE.R_MIN) / (TIDE.R_MAX - TIDE.R_MIN) * (R1 - R0);

    ctx.save();
    // ⚠️ 0.62 LET THE MAP GHOST THROUGH THE ONE CONTROL IN THE GAME. A cistern sitting under the
    // dial read as a third orbital body next to two real ones, which is a confusing thing to do to
    // the only instrument the player has. Still translucent - the sky is over the world, not
    // instead of it - but opaque enough that nothing on the coast reads as being IN the sky.
    ctx.fillStyle = 'rgba(6,8,14,0.84)';
    ctx.beginPath(); ctx.arc(cx, cy, R1 + 48, 0, Math.PI * 2); ctx.fill();

    for (const [r, lab] of [[TIDE.R_MIN, 'perigee'], [TIDE.R_MAX, 'apogee']]) {
      ctx.beginPath(); ctx.arc(cx, cy, px(r), 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(214,192,138,0.16)'; ctx.lineWidth = 1; ctx.stroke();
      void lab;
    }
    // the target ring — where the moon has been TOLD to go
    ctx.beginPath(); ctx.arc(cx, cy, px(o.rTarget), 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(214,192,138,0.40)'; ctx.setLineDash([4, 5]); ctx.lineWidth = 1; ctx.stroke();
    ctx.setLineDash([]);
    // the real ring — where it is
    const rr = ORBIT.radius(o);
    ctx.beginPath(); ctx.arc(cx, cy, px(rr), 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(232,228,216,0.75)'; ctx.lineWidth = 1.5; ctx.stroke();
    ctx.restore();

    // the world at the centre
    ctx.save();
    ctx.fillStyle = '#2a4967';
    ctx.beginPath(); ctx.arc(cx, cy, 13, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#43643a';
    ctx.beginPath(); ctx.arc(cx - 3, cy + 2, 8, 0, Math.PI * 2); ctx.fill();
    ctx.restore();

    const a = ORBIT.tidePhase(o) * Math.PI * 2 - Math.PI / 2;
    ART.drawMoon(ctx, cx + Math.cos(a) * px(rr), cy + Math.sin(a) * px(rr), 34);
    if (o.twin) {
      const a2 = ORBIT.twinPhaseNow(o) * Math.PI * 2 - Math.PI / 2;
      ART.drawMoon(ctx, cx + Math.cos(a2) * (R1 + 18), cy + Math.sin(a2) * (R1 + 18), 18, true);
    }

    ART.text(ctx, 'r ' + rr.toFixed(3), cx, cy + R1 + 22, { align: 'center', size: 16, colour: ART.INK });
    const drift = Math.abs(o.rTarget - o.r);
    ART.text(ctx, drift > 0.004 ? (o.rTarget < o.r ? 'falling toward ' : 'climbing to ') + o.rTarget.toFixed(3)
      : 'holding', cx, cy + R1 + 40, { align: 'center', size: 13, colour: drift > 0.004 ? ART.GOLD : ART.DIM });
  }

  /** The bottom strip: what the season is asking for, and what the settlement is doing about it. */
  function drawHud() {
    ctx.fillStyle = 'rgba(8,10,16,0.96)';
    ctx.fillRect(0, MAP_H, W, H - MAP_H);
    ctx.strokeStyle = ART.RULE;
    ctx.beginPath(); ctx.moveTo(0, MAP_H + 0.5); ctx.lineTo(W, MAP_H + 0.5); ctx.stroke();

    const y0 = MAP_H + 26;
    ART.text(ctx, 'SEASON ' + G.save.season, 20, y0, { size: 19, colour: ART.GOLD });
    const hoursLeft = Math.max(0, SEASON.SEASON_HOURS - G.run.hours);
    ART.text(ctx, hoursLeft.toFixed(0) + ' hours left'
      + (G.save.season === SEASON.FINAL_SEASON ? '  ·  the last season' : ''),
      20, y0 + 22, { size: 14, colour: ART.DIM });

    // quota bar — the one number the season is actually about
    const bx = 20, by = y0 + 42, bw = 250, bh = 12;
    ctx.fillStyle = 'rgba(255,255,255,0.07)'; ctx.fillRect(bx, by, bw, bh);
    const frac = Math.min(1.4, G.run.yield / G.run.quota);
    ctx.fillStyle = frac >= 1 ? '#7aa86a' : ART.GOLD;
    ctx.fillRect(bx, by, Math.min(bw, bw * frac), bh);
    ctx.strokeStyle = ART.RULE; ctx.strokeRect(bx + 0.5, by + 0.5, bw - 1, bh - 1);
    ART.text(ctx, Math.round(G.run.yield) + ' / ' + G.run.quota + ' yield', bx, by + 30,
      { size: 14, colour: frac >= 1 ? '#9fc78e' : ART.INK });

    ART.text(ctx, 'offerings ' + G.save.offerings, 300, y0, { size: 16, colour: ART.INK });
    ART.text(ctx, 'standing ' + '◆'.repeat(Math.max(0, G.save.standing)), 300, y0 + 24,
      { size: 16, colour: G.save.standing <= 1 ? ART.WARN : ART.INK });
    const food = Math.round(SEASON.food(G.run.sites) * 100);
    ART.text(ctx, 'fields ' + food + '%', 300, y0 + 48,
      { size: 16, colour: food < 60 ? ART.WARN : ART.DIM });
    /* ⚠️ THE SKY LINE MOVED LEFT AND DOWN because at x=300 it grew into the forecast strip once
     * every upgrade was owned — "moon x1.75 · elliptical · twin 3:2" is a third longer than the
     * season-one version, and the HUD was laid out against the season-one version. The layout gate
     * caught it only because the gate fattens the save before measuring. */
    ART.text(ctx, UPGRADES.skyLine(G.save.unlocks), 20, MAP_H + 112, { size: 13, colour: ART.DIM });

    if (UPGRADES.level(G.save.unlocks, 'chart')) drawForecast();
    else {
      ART.text(ctx, 'no forecast — buy the TIDE TABLE between seasons', 470, MAP_H + 50,
        { size: 13, colour: 'rgba(154,150,134,0.7)' });
    }

    /* Per-structure chips. ⚠️ SIZED FOR THE BIGGEST SETTLEMENT THE RULES ALLOW (nine), not for the
     * five it starts with — a HUD that is correct at the start and overflows at season eight is a
     * layout defect that only appears to players who are doing well. */
    const ABBR = { mill: 'MILL', farm: 'FIELD', cistern: 'CIST', dock: 'DOCK' };
    const chipW = 44;
    for (let i = 0; i < G.run.sites.length; i++) {
      const s = G.run.sites[i], v = G.run.score[i];
      const col = s.ruined ? '#6a5450' : (v > 0.05 ? '#9fc78e' : (v < -0.05 ? ART.WARN : ART.DIM));
      const cxp = 470 + i * chipW;
      ctx.fillStyle = col;
      ctx.fillRect(cxp, MAP_H + 104, 9, 9);
      ART.text(ctx, ABBR[s.kind], cxp, MAP_H + 100, { size: 10.5, colour: col });
    }

    /* ⚠️ THE TWO BUTTONS MOVED OUT OF THE CHIP LANE. Four chips cleared them and nine did not — the
     * bottom-right corner is where a 5-structure settlement has empty space and a 9-structure one
     * does not. Sized for the biggest settlement the rules allow, not the one the game starts with. */
    const pr = { x: W - 82, y: MAP_H + 12, w: 66, h: 22 };
    hit(ART.button(ctx, SOUND.enabled() ? 'SOUND' : 'MUTED', pr.x, pr.y, pr.w, pr.h,
      { hot: hot(pr), size: 11 }), () => { SOUND.toggle(); SOUND.music(SOUND.enabled()); });
    const hr = { x: W - 82, y: MAP_H + 42, w: 66, h: 22 };
    hit(ART.button(ctx, 'HELP', hr.x, hr.y, hr.w, hr.h, { hot: hot(hr), size: 11 }),
      () => { G.screen = 'help'; });
  }

  /**
   * The TIDE TABLE upgrade, drawn.
   * ⭐ It is an INFORMATION upgrade and it changes the game more than any numeric one: without it
   * you are reading the sea, with it you are reading a forecast, and a dive can be started on
   * purpose instead of in hope.
   */
  function drawForecast() {
    const x0 = 470, y1 = MAP_H + 12, wF = 384, hF = 60;
    const AHEAD = 12;
    ctx.save();
    ctx.fillStyle = 'rgba(255,255,255,0.04)';
    ctx.fillRect(x0, y1, wF, hF);
    ctx.strokeStyle = ART.RULE; ctx.strokeRect(x0 + 0.5, y1 + 0.5, wF - 1, hF - 1);
    const span = Math.max(0.4, ORBIT.maxLevel(G.run.orbit)) * 1.15;
    /**
     * Map a level in metres to a y on the forecast strip.
     * @param {number} m Metres.
     * @returns {number} Pixel y.
     */
    const yOf = (m) => y1 + hF / 2 - (m / span) * (hF / 2 - 4);
    ctx.strokeStyle = 'rgba(255,255,255,0.10)';
    ctx.beginPath(); ctx.moveTo(x0, yOf(0)); ctx.lineTo(x0 + wF, yOf(0)); ctx.stroke();

    for (let i = 0; i < G.run.sites.length; i++) {
      const s = G.run.sites[i];
      if (s.ruined) continue;
      ctx.beginPath();
      for (let k = 0; k <= 60; k++) {
        const ah = k / 60 * AHEAD;
        const xx = x0 + (k / 60) * wF;
        const yy = yOf(ORBIT.predict(s.u, G.run.orbit, ah));
        if (k === 0) ctx.moveTo(xx, yy); else ctx.lineTo(xx, yy);
      }
      ctx.strokeStyle = s.kind === 'farm' ? 'rgba(200,115,90,0.85)'
        : s.kind === 'cistern' ? 'rgba(214,192,138,0.9)' : 'rgba(140,190,200,0.7)';
      ctx.lineWidth = 1.4;
      ctx.stroke();
      // its sill, so the crossing is visible rather than inferred
      ctx.beginPath();
      ctx.moveTo(x0, yOf(s.sill)); ctx.lineTo(x0 + wF, yOf(s.sill));
      ctx.setLineDash([2, 4]);
      ctx.strokeStyle = s.kind === 'farm' ? 'rgba(200,115,90,0.35)'
        : s.kind === 'cistern' ? 'rgba(214,192,138,0.35)' : 'rgba(140,190,200,0.25)';
      ctx.lineWidth = 1; ctx.stroke(); ctx.setLineDash([]);
    }
    ctx.restore();
    ART.text(ctx, 'next ' + AHEAD + ' hours, at your current orbit', x0, y1 + hF + 16,
      { size: 12, colour: ART.DIM });
  }

  /* ── between seasons ─────────────────────────────────────────────────────────────────────── */

  function drawLedger() {
    const L = G.ledger;
    // ⚠️ THE SCRIM IS DELIBERATELY THIN. At 0.82 it erased the coast behind it and the density gate
    // read the ledger at 238 colours, THIN - which was a fair reading of a screen that had become a
    // dark rectangle with words on it. The panel itself is opaque, so nothing legible depends on the
    // scrim; all it was doing was throwing away the one picture the player wants to see while they
    // read what the sea did to it.
    ctx.fillStyle = 'rgba(6,8,12,0.55)'; ctx.fillRect(0, 0, W, H);
    const x = 150, y = 66, w = W - 300;
    ART.panel(ctx, x, y, w, 510);
    ART.text(ctx, 'SEASON ' + (G.save.season - 1) + ' CLOSED', x + 30, y + 48, { size: 30, colour: ART.GOLD });
    ART.text(ctx, L.met ? 'The settlement is satisfied.' : 'The settlement is not satisfied.',
      x + 30, y + 76, { size: 16, colour: L.met ? '#9fc78e' : ART.WARN });

    let ly = y + 118;
    const rows = [
      ['yield', L.yield + ' against a quota of ' + L.quota],
      ['offerings', '+' + L.banked + '  (you now hold ' + G.save.offerings + ')'],
      ['fields', L.food + '% of the settlement\'s ground still bears'],
      ['ruined', L.ruined === 0 ? 'nothing lost'
        : L.ruined + (L.ruined === 1 ? ' structure lost' : ' structures lost')],
      ['the shore', L.cells + ' cells cut, deepest ' + L.deepest.toFixed(2) + ' m'],
      ['standing', '◆'.repeat(Math.max(0, L.standing)) + (L.met ? '' : '   (one lost)')],
    ];
    for (const [k, v] of rows) {
      ART.text(ctx, k, x + 30, ly, { size: 14, colour: ART.DIM });
      ART.text(ctx, v, x + 150, ly, { size: 15, colour: ART.INK });
      ly += 28;
    }

    ly += 8;
    if (L.drifted.length) {
      ART.text(ctx, 'THE GROUND MOVED UNDER THEM', x + 30, ly, { size: 15, colour: ART.GOLD });
      ly += 24;
      for (const d of L.drifted.slice(0, 4)) {
        ART.text(ctx, TIDE.KINDS[d.kind].label + '  sill ' + d.from.toFixed(2) + ' m -> ' + d.to.toFixed(2) + ' m',
          x + 30, ly, { size: 13, colour: d.to < d.from ? ART.WARN : ART.DIM });
        ly += 20;
      }
    }
    if (L.grew) {
      ly += 8;
      ART.paragraph(ctx, 'The settlement prospered and built a ' + TIDE.KINDS[L.grew.kind].label
        + '. Nobody asked you. It wants ' + TIDE.KINDS[L.grew.kind].wants + '.',
        x + 30, ly, w - 60, { size: 14, colour: ART.GOLD, lead: 20 });
    }

    const r = { x: x + 30, y: y + 440, w: 220, h: 42 };
    hit(ART.button(ctx, 'THE SKY', r.x, r.y, r.w, r.h, { hot: hot(r), size: 17 }),
      () => { SOUND.play('click', 0.3); G.screen = 'sky'; });
  }

  function drawSky() {
    ctx.fillStyle = 'rgba(6,8,12,0.58)'; ctx.fillRect(0, 0, W, H);
    const x = 90, w = W - 180;
    /* ⚠️ THE PANEL IS SIZED TO ITS CONTENTS. A fixed 564px box left a third of itself empty
     * whenever the tree had four offers instead of five, and dead space inside a bordered panel
     * reads as a missing element rather than as breathing room. */
    /* ⛔ THE ROW BUDGET IS SHARED, AND THE FIRST VERSION JUST CLAMPED THE PANEL. Two rebuild offers
     * plus five upgrades is 742px of content in a 660px canvas, so the panel hit its ceiling and the
     * last blurb ran straight through the BEGIN SEASON button. Clamping the CONTAINER does not make
     * the CONTENTS fit — it only hides where they went. Rebuilds are the more urgent thing, so they
     * take their rows off the top of the budget and the sky shows fewer offers that season. */
    const nNeedy = Math.min(2, G.save.sites.filter((s) => s.ruined || SEASON.drift(s) >= 0.10).length);
    const maxOffers = Math.max(3, 5 - nNeedy);
    const nOffers = Math.min(maxOffers, UPGRADES.available(G.save.unlocks, G.save.season).length);
    const panelH = 106 + nNeedy * 48 + Math.max(1, nOffers) * 80 + 110;
    const y = Math.round((H - panelH) / 2);
    ART.panel(ctx, x, y, w, panelH);
    ART.text(ctx, 'THE SKY', x + 30, y + 46, { size: 30, colour: ART.GOLD });
    ART.text(ctx, 'you hold ' + G.save.offerings + ' offerings', x + 160, y + 46, { size: 17, colour: ART.INK });
    ART.paragraph(ctx, 'Nothing here improves the settlement. The settlement is not yours.',
      x + 30, y + 74, w - 60, { size: 14, colour: ART.DIM });

    let ly = y + 106;
    /* ⭐ REBUILDING IS THE ANSWER TO EROSION AND IT IS OFFERED BEFORE THE SKY IS, because a player
     * whose fields have sunk below the neap tide has no other move — and `balance.js` measured
     * exactly that death spiral before this existed. Ruined structures come first, then the ones
     * that have sunk furthest, because a farm that is still standing on ground half a metre lower
     * than it was built on is next season's ruin. */
    const needy = G.save.sites
      .map((s, i) => ({ s, i, d: SEASON.drift(s) }))
      .filter((e) => e.s.ruined || e.d >= 0.10)
      .sort((a, b) => (b.s.ruined ? 1 : 0) - (a.s.ruined ? 1 : 0) || b.d - a.d)
      .slice(0, 2);
    for (const e of needy) {
      const cost = SEASON.repairCost(G.save.season, e.s.rebuilt);
      const rr = { x: x + 30, y: ly, w: w - 60, h: 40 };
      const can = G.save.offerings >= cost;
      const label = (e.s.ruined ? 'REBUILD THE ' : 'RAISE THE BANK OF THE ')
        + TIDE.KINDS[e.s.kind].label.toUpperCase()
        + '  —  sill ' + e.s.sill.toFixed(2) + ' back to ' + WORLD.SILL_TARGET[e.s.kind].toFixed(2)
        + ' m  —  ' + cost;
      hit(ART.button(ctx, label, rr.x, rr.y, rr.w, rr.h,
        { hot: hot(rr), enabled: can, size: 14 }), () => {
        if (!can) return;
        G.save.offerings -= cost;
        SEASON.rebuild(e.s);
        SOUND.play('buy', 0.45);
        writeSave();
      });
      ly += 48;
    }

    const offers = UPGRADES.available(G.save.unlocks, G.save.season);
    for (const o of offers.slice(0, maxOffers)) {
      const can = G.save.offerings >= o.cost;
      const rr = { x: x + 30, y: ly, w: w - 60, h: 70 };
      ctx.save();
      ctx.fillStyle = hot(rr) && can ? 'rgba(214,192,138,0.10)' : 'rgba(255,255,255,0.03)';
      ctx.fillRect(rr.x, rr.y, rr.w, rr.h);
      ctx.strokeStyle = can ? ART.RULE : 'rgba(154,150,134,0.2)';
      ctx.strokeRect(rr.x + 0.5, rr.y + 0.5, rr.w - 1, rr.h - 1);
      ctx.restore();
      ART.text(ctx, o.up.name + (o.up.costs.length > 1 ? '  ' + o.level + '/' + o.up.costs.length : ''),
        rr.x + 14, rr.y + 24, { size: 16, colour: can ? ART.GOLD : 'rgba(214,192,138,0.45)' });
      ART.text(ctx, o.cost + ' offerings', rr.x + rr.w - 14, rr.y + 24,
        { size: 15, align: 'right', colour: can ? ART.INK : ART.WARN });
      ART.paragraph(ctx, o.up.blurb, rr.x + 14, rr.y + 44, rr.w - 28,
        { size: 12.5, colour: can ? ART.DIM : 'rgba(154,150,134,0.5)', lead: 16 });
      hit(rr, () => {
        if (UPGRADES.buy(G.save, o.up.id, G.save.season)) { SOUND.play('buy', 0.45); writeSave(); }
      });
      ly += 80;
    }
    if (!offers.length) {
      ART.paragraph(ctx, 'The sky holds nothing else you can reach yet. Later seasons open more.',
        x + 30, ly + 10, w - 60, { size: 15, colour: ART.DIM });
    }

    const r = { x: x + 30, y: y + panelH - 62, w: 260, h: 44 };
    hit(ART.button(ctx, 'BEGIN SEASON ' + G.save.season, r.x, r.y, r.w, r.h, { hot: hot(r), size: 17 }),
      () => { SOUND.play('click', 0.3); beginSeason(); });
  }

  /**
   * The ending.
   * ⭐ IT SAYS WHAT THE PLAYER DID TO THE COAST, not "you win". The coast is the only thing in this
   * game that keeps a permanent record of the player's decisions, so the closing screen reads it
   * back: how much shore they cut, how many fields survived, what the settlement became.
   */
  function drawWon() {
    ctx.fillStyle = 'rgba(6,8,12,0.70)'; ctx.fillRect(0, 0, W, H);
    const x = 170, y = 110, w = W - 340;
    ART.panel(ctx, x, y, w, 430);
    ART.drawMoon(ctx, x + w - 92, y + 96, 108);
    ART.text(ctx, 'TEN SEASONS', x + 34, y + 62, { size: 34, colour: ART.GOLD });
    ART.paragraph(ctx,
      'The settlement is still standing, and it still looks up. Nobody down there knows what you '
      + 'did — only that the water came when it was needed and went when it was not.',
      x + 34, y + 100, w - 190, { size: 15, colour: ART.INK, lead: 23 });

    const farms = G.save.sites.filter((s) => s.kind === 'farm');
    const alive = farms.filter((s) => !s.ruined).length;
    let ly = y + 190;
    const rows = [
      ['the settlement', G.save.sites.length + ' structures, ' + alive + ' of ' + farms.length + ' fields still bearing'],
      ['final season', G.ledger.yield + ' yield against a quota of ' + G.ledger.quota],
      ['standing', '◆'.repeat(Math.max(0, G.save.standing))],
      ['the sky you built', UPGRADES.skyLine(G.save.unlocks)],
    ];
    for (const [k, v] of rows) {
      ART.text(ctx, k, x + 34, ly, { size: 14, colour: ART.DIM });
      ART.text(ctx, v, x + 190, ly, { size: 15, colour: ART.INK });
      ly += 30;
    }
    ART.paragraph(ctx, 'The coast is not the shape you found it. It never will be again.',
      x + 34, ly + 16, w - 68, { size: 15, colour: ART.GOLD, lead: 22 });

    const r = { x: x + 34, y: y + 356, w: 260, h: 44 };
    hit(ART.button(ctx, 'A NEW COAST', r.x, r.y, r.w, r.h, { hot: hot(r), size: 17 }),
      () => { SOUND.play('click', 0.3); newGame(); });
    const r2 = { x: x + 310, y: y + 356, w: 200, h: 44 };
    hit(ART.button(ctx, 'THE TITLE', r2.x, r2.y, r2.w, r2.h, { hot: hot(r2), size: 17 }),
      () => { SOUND.play('click', 0.3); G.screen = 'title'; });
  }

  function drawFailed() {
    ctx.fillStyle = 'rgba(6,8,12,0.72)'; ctx.fillRect(0, 0, W, H);
    const x = 190, y = 150, w = W - 380;
    ART.panel(ctx, x, y, w, 320);
    ART.text(ctx, 'THEY HAVE STOPPED LOOKING UP', x + 30, y + 52, { size: 27, colour: ART.WARN });
    ART.paragraph(ctx,
      'The settlement has lost its faith in the moon. Season ' + (G.save.season - 1)
      + ' returned ' + G.ledger.yield + ' against a quota of ' + G.ledger.quota + '.',
      x + 30, y + 90, w - 60, { size: 15, colour: ART.INK, lead: 22 });
    ART.paragraph(ctx,
      'Nothing is lost but the season. The coast, the settlement and everything you have done to '
      + 'the sky are kept — you begin season ' + (G.save.season - 1) + ' again, from the checkpoint '
      + 'written when it opened.',
      x + 30, y + 150, w - 60, { size: 14, colour: ART.DIM, lead: 21 });

    const r = { x: x + 30, y: y + 230, w: 280, h: 44 };
    hit(ART.button(ctx, 'BEGIN THE SEASON AGAIN', r.x, r.y, r.w, r.h, { hot: hot(r), size: 16 }),
      () => {
        const s = readSave();
        SOUND.play('click', 0.3);
        if (s) continueGame(s); else newGame(G.save.seed);
      });
  }

  /* ── input ───────────────────────────────────────────────────────────────────────────────── */

  /**
   * Nudge the orbital target.
   * @param {number} d Delta in orbital units.
   */
  function nudge(d) {
    if (!G.run) return;
    G.run.orbit.rTarget = Math.max(TIDE.R_MIN, Math.min(TIDE.R_MAX, G.run.orbit.rTarget + d));
  }

  /**
   * Convert a pointer event to canvas coordinates.
   * ⚠️ THE CANVAS IS SCALED BY CSS TO FIT THE FRAME, so clientX is not a canvas coordinate. Reading
   * it as one puts every click a few percent off and reads exactly like a dead button.
   * @param {MouseEvent|Touch} e Event.
   * @returns {{x:number, y:number}} Canvas coordinates.
   */
  function toCanvas(e) {
    const r = canvas.getBoundingClientRect();
    return { x: (e.clientX - r.left) * (W / r.width), y: (e.clientY - r.top) * (H / r.height) };
  }

  canvas.addEventListener('mousemove', (e) => {
    const p = toCanvas(e);
    G.mouse.x = p.x; G.mouse.y = p.y;
    if (G.mouse.down && G.screen === 'play' && G.dragFrom !== null) {
      nudge((p.y - G.dragFrom) * 0.0016);
      G.dragFrom = p.y;
    }
  });
  canvas.addEventListener('mouseleave', () => { G.mouse.x = -1; G.mouse.y = -1; G.mouse.down = false; });
  canvas.addEventListener('mousedown', (e) => {
    const p = toCanvas(e);
    G.mouse.x = p.x; G.mouse.y = p.y; G.mouse.down = true;
    G.dragFrom = (G.screen === 'play' && p.y < MAP_H) ? p.y : null;
    SOUND.unlock();
  });
  canvas.addEventListener('mouseup', (e) => {
    const p = toCanvas(e);
    G.mouse.x = p.x; G.mouse.y = p.y; G.mouse.down = false;
    G.dragFrom = null;
    // ⚠️ Hit-test against the list the DRAW pass built, so the box tested is the box drawn.
    for (const h of G.hit) {
      if (p.x >= h.r.x && p.x <= h.r.x + h.r.w && p.y >= h.r.y && p.y <= h.r.y + h.r.h) { h.fn(); return; }
    }
  });
  canvas.addEventListener('wheel', (e) => {
    if (G.screen !== 'play') return;
    e.preventDefault();
    nudge(Math.sign(e.deltaY) * 0.02);
  }, { passive: false });

  window.addEventListener('keydown', (e) => {
    const k = e.key.toLowerCase();
    if (k === 'arrowup' || k === 'w') { nudge(-0.012); e.preventDefault(); }
    else if (k === 'arrowdown' || k === 's') { nudge(0.012); e.preventDefault(); }
    else if (k === ' ') { if (G.screen === 'play') G.paused = !G.paused; e.preventDefault(); }
    else if (k === 'f') G.fast = !G.fast;
    else if (k === 'm') { SOUND.toggle(); SOUND.music(SOUND.enabled()); }
    else if (k === 'h') G.screen = G.screen === 'help' ? (G.run ? 'play' : 'title') : 'help';
  });

  /* ── boot ────────────────────────────────────────────────────────────────────────────────── */

  canvas.width = W; canvas.height = H;
  requestAnimationFrame(frame);
  ART.load().then(() => {
    SOUND.load('audio/', () => { SOUND.music(true); });
    G.screen = 'title';
  }).catch((e) => {
    G.err = 'Art failed to load: ' + e.message;
    G.screen = 'error';
  });

  // Exposed for the capture harness and the layout gate ONLY — never called by the game itself.
  window.PERIGEE = {
    state: G,
    setPaused: (p) => { G.paused = !!p; G.captureMode = !!p; },
    goto: (s) => { G.screen = s; },
    newGame, continueGame, beginSeason,
    advance: (h) => advance(h),
    draw,
    loaded: () => ART.ready(),
  };
}());
