/**
 * season.js — the economy the tide feeds, and the ledger it leaves behind.
 *
 * Pure model. It advances a season by fixed steps, scores every structure THROUGH tide.js's own
 * consumer rules, banks what the settlement earned, records what the sea broke, and hands the coast
 * the exposure map that erosion will spend at the end of the season.
 *
 * ⭐ WHY IT RESOLVES THROUGH tide.js RATHER THAN BESIDE IT. ANNEAL proved this shape and this wing
 * has paid for the alternative more than once: if the real-time layer carries its own copy of the
 * scoring, then "what the player saw" and "what the rules said" are two programs nothing asserts
 * agree. There is one scoring function and it lives in tide.js. This file owns TIME and MONEY.
 *
 * Copyright (c) 2026 Core Systems Asset Factory.
 */
'use strict';

(function (root) {
  const isNode = (typeof module === 'object' && module.exports);
  const TIDE = isNode ? require('./tide.js') : root.TIDE;
  const ORBIT = isNode ? require('./orbit.js') : root.ORBIT;
  const WORLD = isNode ? require('./world.js') : root.WORLD;

  /** In-game hours in a season — three anomalistic months, so three passes at perigee. */
  const SEASON_HOURS = 90;
  /** Simulation step. Small enough that a structure cannot miss its own high water between ticks. */
  const STEP_HOURS = 0.25;
  /** How fast a bad hour turns into a broken structure. 1 / this = hours of the worst score to ruin. */
  const DAMAGE_RATE = 0.055;
  /** How quickly a structure knits itself back together during hours it is not being hurt. */
  const MEND_RATE = 0.012;
  /** Offerings per unit of banked yield. */
  const OFFERINGS_PER_YIELD = 1.0;
  /** What the settlement can still produce with every field salted. Never zero: they do not die. */
  const FOOD_FLOOR = 0.2;

  /* ── the cistern is a RESERVOIR, and that is what makes this a game ───────────────────────────
   *
   * ⛔ THE LEVEL GATE REFUSED THE FIRST DESIGN AND IT WAS RIGHT. Measured: the best TIMED plan beat
   * the best PARKED orbit by only 5.6%, and 5.0% of that survived DELETING THE CISTERN ENTIRELY —
   * so the one consumer that exists to make you dive was contributing about half a percent. The
   * whole Gate 2 claim rests on the player sequencing a dive to perigee, and the numbers said
   * nobody had a reason to.
   *
   * ⭐ THE FIX IS STRUCTURAL, NOT A BIGGER NUMBER. As an instantaneous consumer a cistern is just a
   * dock with a higher bar: it pays while the water is over its lip and the water is over its lip
   * for a few hours either way. But a cistern is not a mill. IT IS A RESERVOIR — you fill it once
   * and it feeds the settlement for days. That turns the lip from a state to hold into an EVENT to
   * hit, and hitting it is a ten-hour commitment: five hours of diving before the cistern's own
   * high water arrives, and five climbing back out while the sea is still over the low fields.
   *
   * ⚠️ tide.js REMAINS THE ONLY PLACE THAT KNOWS WHETHER THE LIP IS CROSSED. Its cistern rule
   * answers exactly that instantaneous question and this file layers the reservoir on top of the
   * answer. There is still one implementation of "is the water over the lip". */

  /** Hours one filling supplies the settlement before the cistern is dry again. */
  const CISTERN_HOURS = 20;
  /** Score per hour while it holds water. */
  const CISTERN_PAY = 0.8;
  /** Score per hour while it is dry — the settlement is thirsty, and eventually the lining cracks. */
  const CISTERN_DRY = -0.2;
  /** Metres of rock cut per unit of accumulated wave exposure. */
  const EROSION_RATE = 0.0042;

  /**
   * The last season. Reaching the end of it with any standing left is the ending.
   *
   * ⭐ THIS GAME IS FINITE ON PURPOSE. An endless rising quota against a settlement that stops
   * growing at nine structures is not a difficulty curve, it is a wall with a date on it: the
   * player would be returned to the same unwinnable season by the checkpoint rule forever, which is
   * the worst possible use of a save system whose whole point is that you never lose progress.
   * Ten seasons is about fifteen minutes and has a shape.
   */
  const FINAL_SEASON = 10;

  /**
   * The yield a season must return for the settlement to hold its confidence.
   *
   * ⛔ IT IS DRIVEN BY THE SETTLEMENT, NOT BY THE CALENDAR, AND THAT IS A CORRECTION MEASURED BY
   * `balance.js`. The first formula added a flat 15 per season on top of a size multiplier, so the
   * bar climbed forever while yield plateaued the moment the settlement hit its nine-structure cap.
   * A competent search met the quota for five seasons and then lost, unavoidably, at season eight —
   * the last third of the game was a formality that no amount of skill could change.
   *
   * ⭐ The settlement expects more because it HAS more. Size carries the curve; the season term is
   * a gentle 5.5% that keeps the last seasons tight. What makes season nine harder than season four
   * is then EROSION — the fields have drifted lower and flood on tides that used to be safe — which
   * is a difficulty made of the simulation instead of arithmetic.
   *
   * @param {number} season Season number, 1-based.
   * @param {number} sites How many structures stand.
   * @returns {number} Yield required.
   */
  function quota(season, sites) {
    return Math.round(14 * sites * (1 + 0.055 * (season - 1)));
  }

  /**
   * How much of the settlement's work its fields can still support, 0.2..1.
   *
   * ⛔ THIS FUNCTION EXISTS BECAUSE THE FIRST SEASON MODEL HAD NO DECISION IN IT, and the measurement
   * is worth keeping: sweeping a fixed orbit across a whole season gave yield 76.1 at r=0.70 against
   * 23.8 at r=1.35, monotonically. Perigee was simply the answer. The reason is that tide.js scores a
   * dry farm at ZERO — correctly, for the instantaneous model — so drowning a farm cost nothing at
   * all and the mill, dock and cistern all preferred deep water. RUINING YOUR OWN FIELDS WAS FREE.
   *
   * ⭐ The fix is not a bigger farm penalty, which would only move the number. It is that the fields
   * FEED the settlement: salt in the ground throttles everything else the settlement does, at once
   * and visibly. Now perigee still raises the mill, the dock and the cistern — and chokes the
   * multiplier that pays for them. That is an interior optimum made of the design rather than of a
   * tuned constant, and the level gate can go looking for it.
   *
   * @param {Array} sites Structures.
   * @returns {number} Multiplier on everything the settlement earns.
   */
  function food(sites) {
    let n = 0, health = 0;
    for (const s of sites) {
      if (s.kind !== 'farm') continue;
      n++;
      health += s.ruined ? 0 : (1 - s.damage);
    }
    if (n === 0) return 1;
    return FOOD_FLOOR + (1 - FOOD_FLOOR) * (health / n);
  }

  /**
   * @typedef {object} Run
   * @property {number} season Season number.
   * @property {object} orbit Orbit state.
   * @property {object} coast Coast (mutated only at season end).
   * @property {Array} sites Structures.
   * @property {number} yield Banked yield so far.
   * @property {number} hours Elapsed hours.
   * @property {Float32Array} exposure Wave exposure accumulator.
   * @property {number[]} score Instantaneous per-site score, for the HUD.
   * @property {object[]} events Things worth telling the player about.
   */

  /**
   * Start a season.
   * @param {number} season Season number.
   * @param {object} coast Coast.
   * @param {Array} sites Structures (carried across seasons, damage and all).
   * @param {object} unlocks Persistent upgrades.
   * @param {object} [opts] `trackErosion` false skips the exposure accumulator (solver only).
   * @returns {Run} A fresh run.
   */
  function begin(season, coast, sites, unlocks, opts) {
    return {
      // ⚠️ THE ONE OPTIONAL CODE PATH IN THIS MODEL, AND IT IS FENCED. The exposure accumulator is
      // O(cells) every step and dominates a headless search — the level gate needs thousands of
      // seasons and erosion cannot affect a season's own yield, only the next one's coast. So the
      // solver turns it off. ⛔ Two code paths is exactly the shape master §2b keeps charging for,
      // so `test_season.js` asserts the two produce a BYTE-IDENTICAL yield; the game never passes
      // the flag, and if the equivalence ever breaks the suite says so rather than the frame rate.
      trackErosion: !opts || opts.trackErosion !== false,
      season,
      orbit: ORBIT.fresh(unlocks),
      coast,
      sites,
      yield: 0,
      hours: 0,
      exposure: new Float32Array(coast.W * coast.H),
      score: sites.map(() => 0),
      events: [],
      food: food(sites),
      quota: quota(season, sites.length),
    };
  }

  /**
   * Advance a run by one fixed step. Everything that happens in PERIGEE happens here.
   * @param {Run} run Run, mutated.
   * @returns {boolean} True while the season is still running.
   */
  function step(run) {
    if (run.hours >= SEASON_HOURS) return false;
    const dt = STEP_HOURS;
    ORBIT.advance(run.orbit, dt);
    run.hours += dt;

    run.food = food(run.sites);
    for (let i = 0; i < run.sites.length; i++) {
      const s = run.sites[i];
      const level = ORBIT.levelAt(s.u, run.orbit);
      if (s.ruined) { run.score[i] = 0; continue; }
      let v = TIDE.KINDS[s.kind].score(level, s.sill);
      if (s.kind === 'cistern') {
        if (v > 0) s.water = 1;                              // the lip is crossed: it fills
        else s.water = Math.max(0, (s.water || 0) - dt / CISTERN_HOURS);
        v = s.water > 0 ? CISTERN_PAY : CISTERN_DRY;
      }
      run.score[i] = v;
      if (v > 0) {
        run.yield += v * dt * run.food;
        s.damage = Math.max(0, s.damage - MEND_RATE * dt);
      } else if (v < 0) {
        s.damage += -v * DAMAGE_RATE * dt;
        if (s.damage >= 1) {
          s.damage = 1;
          s.ruined = true;
          run.events.push({ at: run.hours, kind: 'ruined', site: i, text: ruinLine(s.kind) });
        }
      } else {
        s.damage = Math.max(0, s.damage - MEND_RATE * dt);
      }
    }

    if (run.trackErosion) {
      WORLD.accumulateExposure(
        run.coast, run.exposure,
        (x) => ORBIT.levelAt(x / run.coast.W, run.orbit),
        dt, ORBIT.energy(run.orbit),
      );
    }
    return run.hours < SEASON_HOURS;
  }

  /**
   * The line the settlement says when a structure goes. Written per kind because "structure ruined"
   * tells the player nothing about which of their competing needs they just lost.
   * @param {string} kind Structure kind.
   * @returns {string} One sentence.
   */
  function ruinLine(kind) {
    return {
      mill: 'The mill wheel is under water. It will not turn again this season.',
      farm: 'Salt has taken the field. Nothing will grow in it now.',
      cistern: 'The cistern has cracked dry and split. It holds nothing.',
      dock: 'The dock has silted up. No hull can float over the bar.',
    }[kind] || 'A structure is lost.';
  }

  /**
   * Close a season: bank the offerings, cut the coast, and decide whether the settlement grew,
   * held, or lost faith.
   *
   * @param {Run} run The finished run.
   * @param {object} save Persistent save, mutated: offerings, standing, seasons.
   * @returns {object} A ledger the end-of-season screen reads straight off.
   */
  function close(run, save) {
    const banked = Math.round(run.yield * OFFERINGS_PER_YIELD);
    const met = run.yield >= run.quota;
    const ero = WORLD.applyErosion(run.coast, run.exposure, EROSION_RATE);

    // ⚠️ Sills are the ground the structure stands on, so erosion MOVES them. This is the whole
    // reason the same orbit does not work twice: last season's safe farm is this season's low farm.
    const drifted = [];
    for (const s of run.sites) {
      const now = Math.round(WORLD.heightAt(run.coast, s.x, s.y) * 100) / 100;
      if (Math.abs(now - s.sill) >= 0.02) drifted.push({ kind: s.kind, from: s.sill, to: now });
      s.sill = now;
    }

    save.offerings += banked;
    if (!met) save.standing -= 1;
    const ruined = run.sites.filter((s) => s.ruined).length;

    let grew = null;
    if (met && ruined === 0 && run.sites.length < 9) {
      const kind = WORLD.wantsNext(run.sites, run.season + 1);
      const u = ((run.season * 0.37) % 0.82) + 0.09;
      const site = WORLD.placeSite(run.coast, kind, u, run.sites, run.season + 1);
      if (site) { run.sites.push(site); grew = site; }
    }

    return {
      banked, met, quota: run.quota, yield: Math.round(run.yield * 10) / 10,
      ruined, food: Math.round(food(run.sites) * 100),
      deepest: Math.round(ero.deepest * 100) / 100, cells: ero.cells,
      drifted, grew,
      standing: save.standing,
      failed: save.standing <= 0,
      // The ending: you reached the far side of the campaign with the settlement still looking up.
      won: save.standing > 0 && run.season >= FINAL_SEASON,
    };
  }

  /**
   * The cost of rebuilding a structure and raising its bank back to where it was built.
   *
   * ⛔ THE SILL RESTORATION IS THE POINT, AND IT EXISTS BECAUSE `balance.js` FOUND A DEATH SPIRAL.
   * MEASURED across ten seasons: from about season seven the fields sat at 20% and never recovered,
   * because erosion lowers a farm's sill permanently and a sill below the neap tide floods on EVERY
   * cycle no matter what orbit you choose. Repair cleared the damage and the farm drowned again the
   * same afternoon. That is not difficulty — it is a one-way ratchet with no counterplay, and a
   * player being returned to it by the checkpoint rule forever is the worst outcome this design can
   * produce.
   *
   * ⭐ So rebuilding means what it says: they raise the bank back to the height they first built it
   * at. The coast still remembers — the ground around it is lower, every band on the map has moved,
   * and the other structures are still drifting — but the player now has an ANSWER, and it is an
   * economic one, competing directly with the sky. Doing it repeatedly to the same structure costs
   * more each time, so it is a decision rather than a chore.
   *
   * @param {number} season Season number.
   * @param {number} [times] How often this structure has already been rebuilt.
   * @returns {number} Offerings.
   */
  const repairCost = (season, times) => 25 + 10 * (season - 1) + 18 * (times || 0);

  /**
   * Rebuild a structure: clear the damage and raise its bank back to its designed height.
   * @param {object} site Site, mutated.
   * @returns {object} The site.
   */
  function rebuild(site) {
    site.ruined = false;
    site.damage = 0;
    site.water = 0;
    site.sill = WORLD.SILL_TARGET[site.kind];
    site.rebuilt = (site.rebuilt || 0) + 1;
    return site;
  }

  /**
   * How far a structure has sunk below the height it was built at.
   * @param {object} site Site.
   * @returns {number} Metres of drift, 0 or more.
   */
  const drift = (site) => Math.max(0, WORLD.SILL_TARGET[site.kind] - site.sill);

  const API = {
    SEASON_HOURS, STEP_HOURS, DAMAGE_RATE, MEND_RATE, EROSION_RATE, OFFERINGS_PER_YIELD, FOOD_FLOOR,
    FINAL_SEASON,
    CISTERN_HOURS, CISTERN_PAY, CISTERN_DRY,
    quota, food, begin, step, close, repairCost, rebuild, drift, ruinLine,
  };

  if (isNode) module.exports = API;
  else root.SEASON = API;
}(typeof globalThis !== 'undefined' ? globalThis : this));
