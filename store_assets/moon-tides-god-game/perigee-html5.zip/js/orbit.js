/**
 * orbit.js — the only thing the player actually touches.
 *
 * ⭐ THE WHOLE GAME IS IN THIS FILE'S INTERFACE. You do not place a building, dig a channel, bless a
 * field or smite a raider. You set an orbit. Everything the world does is downstream of where the
 * moon is, which is why the upgrades in here are the upgrade tree: mass, eccentricity, a second
 * moon, resonance. A direct power would instantly become the answer to every problem and make the
 * moon decorative (recorded as an operator-input decision on his idea — ledger B7).
 *
 * ⚠️ TIDE MATHS COMES FROM tide.js AND IS NEVER RE-IMPLEMENTED HERE. tide.js owns the inverse-cube
 * law and the along-shore sweep and has 22 tests on it; this file owns TIME — how the moon moves,
 * how fast the player may change it, and how two moons add. Master §2b keeps charging the factory
 * for two implementations of one rule; there is one, and it is next door.
 *
 * Copyright (c) 2026 Core Systems Asset Factory.
 */
'use strict';

(function (root) {
  const TIDE = (typeof module === 'object' && module.exports)
    ? require('./tide.js')
    : root.TIDE;

  /** Hours in one tidal cycle — the fast rhythm, one high and one low. */
  const TIDE_HOURS = 6;
  /** Hours in one anomalistic month — the slow rhythm that carries the moon to perigee and back. */
  const MONTH_HOURS = 30;

  /**
   * How fast the player may drag the mean radius, in units per hour, before upgrades.
   * ⭐ THIS NUMBER IS THE GAME. With an instant slider the answer to every situation is "be at the
   * right radius now", and the moon becomes a menu. With a rate limit you must ANTICIPATE: the dive
   * to perigee that fills the cistern has to start hours before the cistern's own high water, and
   * you will still be low when the farm's high water arrives. Sequencing, not selection.
   */
  const SLEW_BASE = 0.055;

  /**
   * @typedef {object} Orbit
   * @property {number} r Mean orbital radius, the player's lever.
   * @property {number} rTarget Where the player is dragging it to.
   * @property {number} t Elapsed hours this season.
   * @property {number} mass Moon mass multiplier (upgrade).
   * @property {number} ecc Eccentricity 0..0.30 (upgrade); modulates r over the month.
   * @property {number} argp Where in the month perigee falls, 0..1 (upgrade).
   * @property {number} slew Units per hour the radius may change (upgrade).
   * @property {boolean} twin Second moon present (upgrade).
   * @property {number} twinMass Second moon mass multiplier.
   * @property {number} twinRatio Second moon's tidal period as a multiple of the first's.
   * @property {number} twinPhase Second moon's phase offset at season start, 0..1.
   */

  /**
   * A fresh orbit for a new season.
   * @param {object} [unlocks] Persistent upgrade levels.
   * @returns {Orbit} Orbit state.
   */
  function fresh(unlocks) {
    const u = unlocks || {};
    return {
      r: 1.0, rTarget: 1.0, t: 0,
      mass: 1 + 0.25 * (u.mass || 0),
      ecc: u.ecc ? 0.12 : 0,
      argp: 0,
      slew: SLEW_BASE * (1 + 0.5 * (u.slew || 0)),
      twin: !!u.twin,
      // ⚠️ RAISED FROM 0.34 ON A MEASUREMENT, NOT A FEELING. At 0.34 the twin moved the combined
      // cycle peak between 0.264 m and 0.466 m — real interference, but a third of the main tide,
      // which is not what "the deepest upgrade in the tree" should buy. At 0.45 the swing is roughly
      // 0.19 m to 0.51 m, and the interaction that matters appears: with the two moons aligned the
      // cistern's 1.05 m lip is reachable from a SHALLOWER dive than the moon could manage alone,
      // so the upgrade changes which orbits are available rather than only how big the numbers are.
      twinMass: 0.45 + 0.13 * (u.twinMass || 0),
      twinRatio: u.resonance ? 1.5 : 1.37,
      twinPhase: 0.5,
    };
  }

  /**
   * The instantaneous radius: the player's mean radius, modulated by eccentricity over the month.
   *
   * ⚠️ This is a real phenomenon and not a flourish — a perigean spring tide is exactly what happens
   * when the tidal high and the monthly perigee coincide. Unlocking `argp` is unlocking the ability
   * to CHOOSE when in the month that coincidence falls, i.e. to author your own spring tides.
   *
   * @param {Orbit} o Orbit.
   * @returns {number} Instantaneous radius, clamped to the legal range.
   */
  function radius(o) {
    const month = (o.t / MONTH_HOURS) - o.argp;
    const r = o.r * (1 + o.ecc * Math.cos(2 * Math.PI * month));
    return Math.max(TIDE.R_MIN, Math.min(TIDE.R_MAX, r));
  }

  /** The fast tidal phase, 0..1. */
  const tidePhase = (o) => ((o.t / TIDE_HOURS) % 1 + 1) % 1;

  /** The second moon's tidal phase, 0..1 — a different clock, which is where interference comes from. */
  const twinPhaseNow = (o) => ((o.t / (TIDE_HOURS * o.twinRatio) + o.twinPhase) % 1 + 1) % 1;

  /**
   * Water level in metres at an along-shore position, right now.
   *
   * ⭐ TWO MOONS ADD. That is all interference is, and it is why the second moon is the deepest
   * upgrade rather than just a bigger one: when the two waves agree you get a tide neither could
   * raise alone, and when they disagree the sea barely moves. With `resonance` the ratio is a simple
   * fraction so the pattern repeats and can be planned; without it the two clocks drift and every
   * cycle is slightly different.
   *
   * @param {number} u Along-shore position, 0..1.
   * @param {Orbit} o Orbit.
   * @returns {number} Level in metres relative to chart datum.
   */
  function levelAt(u, o) {
    let L = TIDE.levelAt(u, radius(o), tidePhase(o)) * o.mass;
    if (o.twin) L += TIDE.levelAt(u, 1.0, twinPhaseNow(o)) * o.twinMass;
    return L;
  }

  /**
   * Advance the orbit by dt hours, moving the radius toward the player's target at the slew limit.
   * @param {Orbit} o Orbit, mutated.
   * @param {number} dt Hours.
   */
  function advance(o, dt) {
    o.t += dt;
    const d = o.rTarget - o.r;
    const step = o.slew * dt;
    o.r += Math.abs(d) <= step ? d : Math.sign(d) * step;
    o.r = Math.max(TIDE.R_MIN, Math.min(TIDE.R_MAX, o.r));
  }

  /**
   * Peak tidal energy right now, used to drive erosion. Bigger tides do more work on the coast.
   * @param {Orbit} o Orbit.
   * @returns {number} Energy, roughly 0.1..3.
   */
  function energy(o) {
    let a = TIDE.amplitude(radius(o)) * o.mass;
    if (o.twin) a += TIDE.amplitude(1.0) * o.twinMass;
    return a / TIDE.K;
  }

  /**
   * Predict the level at a position a given number of hours ahead, without mutating anything.
   * ⭐ This is the CHART upgrade's whole implementation, and it deserves to be an upgrade: without
   * it you are reading the sea, with it you are reading a forecast, and the difference in how the
   * game feels is larger than any numeric buff in the tree.
   * @param {number} u Along-shore position.
   * @param {Orbit} o Orbit.
   * @param {number} ahead Hours ahead.
   * @returns {number} Predicted level, metres.
   */
  function predict(u, o, ahead) {
    const d = o.rTarget - o.r;
    const step = o.slew * ahead;
    const rNow = o.r + (Math.abs(d) <= step ? d : Math.sign(d) * step);
    const probe = { ...o, t: o.t + ahead, r: rNow };
    return levelAt(u, probe);
  }

  /**
   * The highest water this sky could ever raise, at any radius and any phase.
   *
   * ⭐ THE RENDERER NEEDS THIS AND SO DOES THE PLAYER. Every band on the map — tidal flat,
   * saltmarsh, reedbed, safe turf — is defined RELATIVE to it, because the only question that
   * matters when you look at a piece of ground is "can the sea get here?". Buying MASS or a SECOND
   * MOON therefore redraws the coast: land that was safe turf becomes marsh the moment the sky can
   * reach it, without a single height changing. That is the upgrade tree writing on the map.
   *
   * @param {Orbit} o Orbit.
   * @returns {number} Metres above datum.
   */
  function maxLevel(o) {
    return TIDE.amplitude(TIDE.R_MIN) * o.mass + (o.twin ? TIDE.amplitude(1.0) * o.twinMass : 0);
  }

  const API = {
    TIDE_HOURS, MONTH_HOURS, SLEW_BASE,
    fresh, radius, tidePhase, twinPhaseNow, levelAt, advance, energy, predict, maxLevel,
  };

  if (typeof module === 'object' && module.exports) module.exports = API;
  else root.ORBIT = API;
}(typeof globalThis !== 'undefined' ? globalThis : this));
