/**
 * art.js — PERIGEE's renderer, and the text contract every screen must go through.
 *
 * ⛔ THE TEXT RULES ARE NOT STYLE, THEY ARE A GATE (§3e-1, measured on FLOODMARK). Canvas text does
 * not wrap, does not reflow and does not clip: FLOODMARK passed 133 assertions across four suites
 * while its HOW IT WORKS screen drew four body lines to 1035px on a 960px canvas, mid-word, with
 * three labels overprinting their own body text. The density gate was green too, because a wall of
 * overflowing text is still dense.
 *
 * ⛔ AND "MEASURE ONCE, HARD-CODE THE X" IS WRONG BY CONSTRUCTION. This game ships a system font
 * stack, so the same string is a different width on a Mac, on Windows, on Linux and in headless
 * capture. Layout is derived from `ctx.measureText` AT DRAW TIME, on the player's machine.
 *
 * ⛔⛔ AND EVERY INTERNAL CALLER GOES THROUGH `API.text`, NEVER A CLOSURE-LOCAL COPY. FLOODMARK's
 * `paragraph` called the local `text`, so the layout recorder never saw a single line of the
 * paragraphs — it reported "12 strings" for a screen drawing thirty and was blind to exactly the
 * lines most likely to overflow. `test_layout.js` asserts a FLOOR on strings-seen-per-screen so
 * that blindness cannot come back quietly.
 *
 * Copyright (c) 2026 Core Systems Asset Factory.
 */
'use strict';

(function (root) {
  const TIDE = root.TIDE, ORBIT = root.ORBIT;

  /** Map grid, and the buffer the map is painted into before it is scaled up. */
  const MAP_W = 192, MAP_H = 108;
  const BUF_W = 320, BUF_H = 180;
  const ZOOM = 3;                                   // 320x180 -> 960x540, integer, never smoothed

  const PLATES = ['abyss', 'sea', 'shoal', 'surf', 'flat', 'marsh', 'reed', 'turf', 'scarp'];
  const SPRITE = 24;
  const KIND_COL = { mill: 0, farm: 1, cistern: 2, dock: 3 };
  const STATE_ROW = { work: 0, idle: 1, ruin: 2 };

  const FONT = "'Iowan Old Style', 'Palatino Linotype', Palatino, Georgia, serif";
  const INK = '#e8e4d8';
  const DIM = '#9a9686';
  const GOLD = '#d6c08a';
  const WARN = '#c8735a';
  const PANEL = 'rgba(12,14,20,0.90)';
  const RULE = 'rgba(214,192,138,0.35)';

  const assets = { plates: {}, sprites: null, moon: null, moon2: null, ready: false };

  /* ── loading ─────────────────────────────────────────────────────────────────────────────── */

  /**
   * Load one image.
   * @param {string} src URL.
   * @returns {Promise<HTMLImageElement>} The image.
   */
  function loadImage(src) {
    return new Promise((res, rej) => {
      const i = new Image();
      i.onload = () => res(i);
      i.onerror = () => rej(new Error('failed to load ' + src));
      i.src = src;
    });
  }

  /**
   * Read an image's pixels into a flat array so the map painter can sample it per pixel.
   * @param {HTMLImageElement} img Image.
   * @returns {{w:number, h:number, d:Uint8ClampedArray}} Pixels.
   */
  function pixelsOf(img) {
    const c = document.createElement('canvas');
    c.width = img.width; c.height = img.height;
    const x = c.getContext('2d', { willReadFrequently: true });
    x.drawImage(img, 0, 0);
    return { w: img.width, h: img.height, d: x.getImageData(0, 0, img.width, img.height).data };
  }

  /**
   * Load every asset the game draws.
   * ⚠️ The capture harness waits on `ART.ready()` — §3d rule 3: a capture script that does not wait
   * for async art photographs a game that has not finished loading, and the only honest proof the
   * asset DECODED is an accessor the harness can poll.
   * @returns {Promise<void>} Resolves when everything is decoded.
   */
  async function load() {
    const imgs = await Promise.all([
      ...PLATES.map((p) => loadImage('art/plate_' + p + '.png')),
      loadImage('art/structures.png'),
      loadImage('art/moon.png'),
      loadImage('art/moon2.png'),
    ]);
    PLATES.forEach((p, i) => { assets.plates[p] = pixelsOf(imgs[i]); });
    assets.sprites = imgs[PLATES.length];
    assets.moon = imgs[PLATES.length + 1];
    assets.moon2 = imgs[PLATES.length + 2];
    assets.ready = true;
  }

  /** @returns {boolean} True once every asset has decoded. The capture harness polls this. */
  const ready = () => assets.ready;

  /* ── text ────────────────────────────────────────────────────────────────────────────────── */

  /**
   * Draw one string. EVERY string in this game goes through here.
   * @param {CanvasRenderingContext2D} ctx Context.
   * @param {string} str The string.
   * @param {number} x X.
   * @param {number} y Baseline y.
   * @param {object} [o] size, colour, align, weight, alpha.
   * @returns {number} The measured width, so callers can lay out from a measurement.
   */
  function text(ctx, str, x, y, o) {
    const p = o || {};
    const size = p.size || 15;
    ctx.save();
    ctx.font = (p.weight ? p.weight + ' ' : '') + size + 'px ' + FONT;
    ctx.fillStyle = p.colour || INK;
    ctx.textAlign = p.align || 'left';
    ctx.textBaseline = 'alphabetic';
    if (p.alpha !== undefined) ctx.globalAlpha = p.alpha;
    ctx.fillText(str, x, y);
    const w = ctx.measureText(str).width;
    ctx.restore();
    return w;
  }

  /**
   * Break a string into lines that fit a width, measured on THIS machine at THIS size.
   * @param {CanvasRenderingContext2D} ctx Context.
   * @param {string} str The string.
   * @param {number} maxW Maximum line width in px.
   * @param {number} size Font size.
   * @param {string} [weight] Font weight.
   * @returns {string[]} Lines.
   */
  function wrap(ctx, str, maxW, size, weight) {
    ctx.save();
    ctx.font = (weight ? weight + ' ' : '') + size + 'px ' + FONT;
    const words = String(str).split(/\s+/).filter(Boolean);
    const lines = [];
    let line = '';
    for (const w of words) {
      const test = line ? line + ' ' + w : w;
      if (line && ctx.measureText(test).width > maxW) { lines.push(line); line = w; }
      else line = test;
    }
    if (line) lines.push(line);
    ctx.restore();
    return lines;
  }

  /**
   * Draw a wrapped paragraph.
   * ⛔ CALLS `API.text`, NOT the closure-local `text`. See the header — a helper that calls the
   * local copy is INVISIBLE to the layout recorder, which is how a screen drawing thirty strings
   * reported twelve and went green over a paragraph running off the canvas.
   * @param {CanvasRenderingContext2D} ctx Context.
   * @param {string} str The string.
   * @param {number} x X.
   * @param {number} y First baseline.
   * @param {number} maxW Maximum width.
   * @param {object} [o] size, colour, lead, align, alpha.
   * @returns {number} The y after the last line.
   */
  function paragraph(ctx, str, x, y, maxW, o) {
    const p = o || {};
    const size = p.size || 15;
    const lead = p.lead || Math.round(size * 1.45);
    let yy = y;
    for (const line of wrap(ctx, str, maxW, size, p.weight)) {
      API.text(ctx, line, x, yy, p);
      yy += lead;
    }
    return yy;
  }

  /* ── chrome ──────────────────────────────────────────────────────────────────────────────── */

  /**
   * A panel: the game's one container. Deliberately not a rounded default box — a hairline gold
   * rule on near-black is the whole visual identity of the interface.
   * @param {CanvasRenderingContext2D} ctx Context.
   * @param {number} x X.
   * @param {number} y Y.
   * @param {number} w Width.
   * @param {number} h Height.
   * @param {number} [alpha] Fill alpha override.
   */
  function panel(ctx, x, y, w, h, alpha) {
    ctx.save();
    ctx.fillStyle = alpha === undefined ? PANEL : 'rgba(12,14,20,' + alpha + ')';
    ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = RULE;
    ctx.lineWidth = 1;
    ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
    ctx.beginPath();
    ctx.moveTo(x + 10, y + 0.5); ctx.lineTo(x + w - 10, y + 0.5);
    ctx.strokeStyle = 'rgba(214,192,138,0.7)';
    ctx.stroke();
    ctx.restore();
  }

  /**
   * A button. Returns its rect so the caller can hit-test the SAME numbers it drew.
   * ⚠️ One source of truth for the rectangle: a hit box computed separately from the box that was
   * drawn is a dead button waiting to happen.
   * @param {CanvasRenderingContext2D} ctx Context.
   * @param {string} label Label.
   * @param {number} x X.
   * @param {number} y Y.
   * @param {number} w Width.
   * @param {number} h Height.
   * @param {object} [o] enabled, hot, size.
   * @returns {{x:number,y:number,w:number,h:number}} The rect.
   */
  function button(ctx, label, x, y, w, h, o) {
    const p = o || {};
    const on = p.enabled !== false;
    ctx.save();
    ctx.fillStyle = p.hot && on ? 'rgba(214,192,138,0.18)' : 'rgba(255,255,255,0.04)';
    ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = on ? (p.hot ? 'rgba(214,192,138,0.95)' : RULE) : 'rgba(154,150,134,0.25)';
    ctx.lineWidth = 1;
    ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
    ctx.restore();
    API.text(ctx, label, x + w / 2, y + h / 2 + (p.size || 15) * 0.35,
      { align: 'center', size: p.size || 15, colour: on ? (p.hot ? GOLD : INK) : 'rgba(154,150,134,0.5)' });
    return { x, y, w, h };
  }

  /* ── the map ─────────────────────────────────────────────────────────────────────────────── */

  /**
   * Precompute everything about the coast that does not change during a season.
   *
   * ⭐ HEIGHT IS SAMPLED ONCE PER SEASON, NOT ONCE PER FRAME. The coast only moves when erosion is
   * applied at a season boundary, so bilinear-sampling 57,600 buffer pixels every frame would be
   * 57,600 wasted interpolations sixty times a second to produce an identical array.
   *
   * @param {object} coast Coast from world.js.
   * @param {number} maxLevel The highest water this sky can raise, for the band definitions.
   * @returns {{h:Float32Array, contour:Uint8Array}} Cache.
   */
  function terrainCache(coast, maxLevel) {
    const h = new Float32Array(BUF_W * BUF_H);
    for (let y = 0; y < BUF_H; y++) {
      const fy = (y + 0.5) * MAP_H / BUF_H - 0.5;
      const y0 = Math.max(0, Math.min(MAP_H - 1, Math.floor(fy)));
      const y1 = Math.min(MAP_H - 1, y0 + 1);
      const ty = fy - y0;
      for (let x = 0; x < BUF_W; x++) {
        const fx = (x + 0.5) * MAP_W / BUF_W - 0.5;
        const x0 = Math.max(0, Math.min(MAP_W - 1, Math.floor(fx)));
        const x1 = Math.min(MAP_W - 1, x0 + 1);
        const tx = fx - x0;
        const a = coast.height[y0 * MAP_W + x0], b = coast.height[y0 * MAP_W + x1];
        const c = coast.height[y1 * MAP_W + x0], d = coast.height[y1 * MAP_W + x1];
        h[y * BUF_W + x] = (a + (b - a) * tx) * (1 - ty) + (c + (d - c) * tx) * ty;
      }
    }

    /* ⭐ CONTOURS ARE NOT DECORATION — A CONTOUR IS A FUTURE WATERLINE. On this map a line of
     * constant height is exactly where the sea will stand at some orbit, so the art is generated by
     * the simulation and the art IS the information.
     * ⛔ AND THEY ARE DRAWN ONLY INSIDE THE BAND THE SEA CAN REACH. The probe's second pass
     * contoured the whole map at 0.5 m and produced TEXTILE — brown corduroy on every slope, the
     * failure §0-ART rule 4 names. Above the highest possible tide a contour carries no meaning at
     * all, so it was pure noise. Inside the band each line is a place the water will actually
     * stand: sparse, countable, and worth reading. */
    const contour = new Uint8Array(BUF_W * BUF_H);
    const STEP = 0.35;
    const reach = maxLevel * 1.12;
    for (let y = 0; y < BUF_H - 1; y++) {
      for (let x = 0; x < BUF_W; x++) {
        const a = h[y * BUF_W + x];
        if (Math.abs(a) > reach) continue;
        const b = h[(y + 1) * BUF_W + x];
        if (Math.floor(a / STEP) !== Math.floor(b / STEP)) contour[y * BUF_W + x] = 1;
      }
    }
    return { h, contour };
  }

  /** Scratch buffers, allocated once. A per-frame allocation of 230 KB is a stutter with a cause. */
  let mapCanvas = null, mapCtx = null, mapImage = null;

  /**
   * Paint the coast for one instant.
   *
   * @param {CanvasRenderingContext2D} ctx Destination context.
   * @param {object} cache Terrain cache.
   * @param {Float32Array} levels Water level per buffer column, in metres.
   * @param {number} maxLevel The highest water this sky can raise.
   * @param {number} ox Destination x.
   * @param {number} oy Destination y.
   */
  function drawMap(ctx, cache, levels, maxLevel, ox, oy) {
    if (!mapCanvas) {
      mapCanvas = document.createElement('canvas');
      mapCanvas.width = BUF_W; mapCanvas.height = BUF_H;
      mapCtx = mapCanvas.getContext('2d');
      mapImage = mapCtx.createImageData(BUF_W, BUF_H);
    }
    const out = mapImage.data;
    const P = assets.plates;
    const band = [P.abyss, P.sea, P.shoal, P.surf, P.flat, P.marsh, P.reed, P.turf, P.scarp];

    for (let y = 0; y < BUF_H; y++) {
      const py = y & 63;
      for (let x = 0; x < BUF_W; x++) {
        const i = y * BUF_W + x;
        const d = levels[x] - cache.h[i];
        let b, shade = 1;
        /* ⚠️ THE SURF BAND WAS TWICE THIS WIDE AND THE FIRST GALLERY SHOWED WHY IT MATTERS. On a
         * gently shelving coast a depth band of 0.30 m covers an enormous horizontal area, so at a
         * mid tide the brightest plate in the game filled a third of the map and read as snow. Surf
         * is a LINE, not a zone: 0.18 m of water and 4 cm of wet ground either side of the
         * waterline. Narrowed on the picture, not on a preference. */
        if (d > 0) {
          if (d > 2.2) { b = 0; shade = Math.max(0.62, 1 - (d - 2.2) * 0.10); }
          else if (d > 1.1) b = 1;
          else if (d > 0.18) b = 2;
          else b = 3;
        } else {
          const dry = -d;
          if (dry < 0.04) b = 3;
          else if (dry < maxLevel * 0.42) b = 4;
          else if (dry < maxLevel) b = 5;
          else if (dry < maxLevel + 0.85) b = 6;
          else if (dry < maxLevel + 2.4) b = 7;
          else b = 8;
        }
        const pl = band[b];
        const s = ((y % pl.h) * pl.w + (x % pl.w)) * 4;
        const o = i * 4;
        if (cache.contour[i] && b >= 4) {
          // a tinted step rather than bone-white: legible without shouting over the ground
          out[o] = Math.min(255, pl.d[s] + 26);
          out[o + 1] = Math.min(255, pl.d[s + 1] + 24);
          out[o + 2] = Math.min(255, pl.d[s + 2] + 14);
        } else if (shade < 1) {
          out[o] = pl.d[s] * shade;
          out[o + 1] = pl.d[s + 1] * shade;
          out[o + 2] = pl.d[s + 2] * shade;
        } else {
          out[o] = pl.d[s]; out[o + 1] = pl.d[s + 1]; out[o + 2] = pl.d[s + 2];
        }
        out[o + 3] = 255;
        void py;
      }
    }
    mapCtx.putImageData(mapImage, 0, 0);
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(mapCanvas, ox, oy, BUF_W * ZOOM, BUF_H * ZOOM);
    ctx.restore();
  }

  /**
   * Draw a structure sprite, centred on a map cell.
   * @param {CanvasRenderingContext2D} ctx Context.
   * @param {string} kind Structure kind.
   * @param {string} state work | idle | ruin.
   * @param {number} cx Map cell x.
   * @param {number} cy Map cell y.
   * @param {number} ox Map origin x on the canvas.
   * @param {number} oy Map origin y on the canvas.
   * @returns {{x:number,y:number,w:number,h:number}} The rect it occupies on the canvas.
   */
  function drawSprite(ctx, kind, state, cx, cy, ox, oy) {
    const scale = 2.6;
    const w = SPRITE * scale;
    const x = Math.round(ox + (cx / MAP_W) * BUF_W * ZOOM - w / 2);
    const y = Math.round(oy + (cy / MAP_H) * BUF_H * ZOOM - w / 2);
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(assets.sprites,
      KIND_COL[kind] * SPRITE, STATE_ROW[state] * SPRITE, SPRITE, SPRITE, x, y, w, w);
    ctx.restore();
    return { x, y, w, h: w };
  }

  /**
   * Draw a moon.
   * @param {CanvasRenderingContext2D} ctx Context.
   * @param {number} x Centre x.
   * @param {number} y Centre y.
   * @param {number} size Diameter.
   * @param {boolean} [second] Draw the smaller second moon.
   */
  function drawMoon(ctx, x, y, size, second) {
    const img = second ? assets.moon2 : assets.moon;
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(img, Math.round(x - size / 2), Math.round(y - size / 2), size, size);
    ctx.restore();
  }

  const API = {
    MAP_W, MAP_H, BUF_W, BUF_H, ZOOM, SPRITE,
    FONT, INK, DIM, GOLD, WARN, PANEL, RULE,
    load, ready, assets,
    text, wrap, paragraph, panel, button,
    terrainCache, drawMap, drawSprite, drawMoon,
  };
  root.ART = API;
  void TIDE; void ORBIT;
}(typeof globalThis !== 'undefined' ? globalThis : this));
