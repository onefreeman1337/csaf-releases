/**
 * upgrades.js — the tree, and every branch of it is the moon.
 *
 * ⭐ NOTHING IN HERE IMPROVES THE SETTLEMENT. There is no better plough, no sea wall, no granary.
 * The settlement is not yours; the sky is. That constraint is what keeps the Gate 2 claim honest all
 * the way through the game rather than only in the first five minutes, and it is why the deepest
 * upgrade is a SECOND MOON rather than a bigger number.
 *
 * ⚠️ MASS IS DELIBERATELY DOUBLE-EDGED and the copy says so. It raises every tide, including the one
 * that drowns the low farm, so a player who buys it early is buying a harder game with a higher
 * ceiling. An upgrade that is purely good is a toll booth, not a decision.
 *
 * Copyright (c) 2026 Core Systems Asset Factory.
 */
'use strict';

(function (root) {
  /**
   * @typedef {object} Upgrade
   * @property {string} id Key in the unlocks object.
   * @property {string} name Display name.
   * @property {number[]} costs Cost of each successive level, in offerings.
   * @property {string} blurb What it does, in the player's terms.
   * @property {string} [needs] Another upgrade that must be owned first.
   * @property {number} [season] Earliest season it can appear, so the tree paces itself.
   */

  /** The tree, in the order it is offered. */
  const TREE = [
    {
      id: 'chart', name: 'TIDE TABLE', costs: [16],
      blurb: 'Read the sea six hours ahead. A forecast line appears over every structure, so a dive '
        + 'to perigee can be started before the hour that needs it rather than during it.',
    },
    {
      id: 'slew', name: 'SLIP', costs: [26, 52],
      blurb: 'The moon answers faster. Each level raises how quickly you may change the orbit, which '
        + 'is the difference between arriving at perigee on the hour you wanted and an hour late.',
    },
    {
      id: 'mass', name: 'MASS', costs: [34, 66, 108],
      blurb: 'Feed the moon. Every tide grows by a quarter — the one that turns the mill and the one '
        + 'that takes the field. A higher ceiling and a smaller margin, bought together.',
    },
    {
      id: 'ecc', name: 'ECCENTRICITY', costs: [58], season: 3,
      blurb: 'Bend the orbit into an ellipse. The radius now breathes on its own across the month, '
        + 'carrying the moon to perigee and back without you touching it.',
    },
    {
      id: 'argp', name: 'APSIDAL CONTROL', costs: [76], needs: 'ecc',
      blurb: 'Turn the ellipse. You choose where in the month perigee falls, which means you choose '
        + 'which of the settlement\'s hours gets the spring tide. This is authorship, not tuning.',
    },
    {
      id: 'twin', name: 'THE SECOND MOON', costs: [126], season: 5,
      blurb: 'A smaller moon on a clock of its own. Two tidal waves add: when they agree the sea '
        + 'rises higher than either could lift it, and when they argue it barely moves at all.',
    },
    {
      id: 'twinMass', name: 'THE SECOND MOON GROWS', costs: [84, 138], needs: 'twin',
      blurb: 'Feed the smaller one. Deeper constructive highs, and deeper dead water when the two '
        + 'moons are opposed.',
    },
    {
      id: 'resonance', name: 'RESONANCE', costs: [160], needs: 'twin',
      blurb: 'Lock the second moon to three turns for every two of the first. The interference stops '
        + 'drifting and starts repeating, so the pattern becomes something you can plan around.',
    },
  ];

  /**
   * How many levels of an upgrade are owned.
   * @param {object} unlocks Unlocks.
   * @param {string} id Upgrade id.
   * @returns {number} Levels owned.
   */
  const level = (unlocks, id) => unlocks[id] || 0;

  /**
   * The next purchasable level of an upgrade, or null if maxed, locked or not yet offered.
   * @param {Upgrade} up Upgrade.
   * @param {object} unlocks Unlocks.
   * @param {number} season Current season.
   * @returns {?{cost:number, level:number}} The offer.
   */
  function offer(up, unlocks, season) {
    const have = level(unlocks, up.id);
    if (have >= up.costs.length) return null;
    if (up.needs && !level(unlocks, up.needs)) return null;
    if (up.season && season < up.season) return null;
    return { cost: up.costs[have], level: have + 1 };
  }

  /**
   * Everything on offer right now.
   * @param {object} unlocks Unlocks.
   * @param {number} season Current season.
   * @returns {Array<{up:Upgrade, cost:number, level:number}>} Offers.
   */
  function available(unlocks, season) {
    const out = [];
    for (const up of TREE) {
      const o = offer(up, unlocks, season);
      if (o) out.push({ up, cost: o.cost, level: o.level });
    }
    return out;
  }

  /**
   * Buy one level. Refuses rather than going into debt.
   * @param {object} save Save, mutated.
   * @param {string} id Upgrade id.
   * @param {number} season Current season.
   * @returns {boolean} True if bought.
   */
  function buy(save, id, season) {
    const up = TREE.find((u) => u.id === id);
    if (!up) return false;
    const o = offer(up, save.unlocks, season);
    if (!o || save.offerings < o.cost) return false;
    save.offerings -= o.cost;
    save.unlocks[id] = o.level;
    return true;
  }

  /**
   * A one-line summary of what the sky currently is, for the HUD.
   * @param {object} unlocks Unlocks.
   * @returns {string} Summary.
   */
  function skyLine(unlocks) {
    const bits = [];
    bits.push('moon x' + (1 + 0.25 * level(unlocks, 'mass')).toFixed(2));
    if (level(unlocks, 'ecc')) bits.push('elliptical');
    if (level(unlocks, 'twin')) bits.push(level(unlocks, 'resonance') ? 'twin 3:2' : 'twin drifting');
    return bits.join(' · ');
  }

  const API = { TREE, level, offer, available, buy, skyLine };

  if (typeof module === 'object' && module.exports) module.exports = API;
  else root.UPGRADES = API;
}(typeof globalThis !== 'undefined' ? globalThis : this));
