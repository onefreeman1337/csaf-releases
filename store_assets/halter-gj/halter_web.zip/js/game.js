/**
 * game.js — HALTER. The beasts in the byre stand in the wrong stalls. Lead one on a halter into another's stall and the
 * two trade places; a trade costs BOTH their weights. Put the whole byre home for the least effort there is.
 *
 * ONE SENTENCE OF DESIGN: the obvious hand sends the cheapest beast home first, because its trades are cheapest — and
 * then every heavy beast has to be traded home on its own heavy weight. The proved least (yard.js optimum: per loop,
 * S + min((k-2)m, m + (k+1)g)) keeps the lightest beast of each loop on the halter and walks it from stall to stall,
 * sending one beast home per trade; it goes home LAST. In the late byres a loop holds only heavy beasts, and the least
 * effort BORROWS the byre's hen to carry them. The game never prints that until a pass.
 *
 * ⛔ THE PRIMARY INPUT IS A HOLD (wing §0a-2): hold a direction and the hand walks the aisle; a led beast follows on the
 *    rope, and a heavy one PLODS (the hand slows with the weight on the halter, so the insight is also the quick way).
 *    Z at a door takes that beast's halter, or, while leading, leads her in and the two trade. Holding INTO a door does
 *    the same. On touch a finger on a stall walks the hand there and acts; a tap on the hand lets go.
 * ⛔ THE ONE NUMBER: EFFORT = the sum over trades of both weights (yard.js play() recomputes it from the trade log at the
 *    end and the game throws if they disagree). Walking is free: the puzzle is which trades, never the route.
 * ⛔ §1a: the automation tab is hidden and rAF is throttled to zero there, so every harness drives the game through the
 *    synchronous `window.HALTER.step(n)`.
 * ⛔ §6b-64: every device the listing claims is driven with its own vocabulary by the harness — keyboard holds (8-way),
 *    pointer points under a finger — never a vector no device produces.
 * ⛔ §0z-1c: every refusal names its reason (run.refusals).
 */
(function (root) {
  'use strict';

  var ART = root.ART, FONT = root.DW_FONT, C = root.CONTENT, SND = root.PSOUND, YARD = root.YARD, B = root.BEASTS;
  var W = ART.W, H = ART.H, LIT = ART.LIT, FACE = ART.FACE, MID = ART.MID, SHADOW = ART.SHADOW;
  var DMG = ['#9bbc0f', '#8bac0f', '#306230', '#0f380f'];
  var TRADE_FRAMES = 44, DONE_FRAMES = 100, PUSH_FRAMES = 9, SETTLE_FRAMES = 18;
  // where the hand's feet may stand. ⛔ REVIEW 2026-10-03 #16: AY0 was AISLE_Y + 12, which put the hand's lit halo on the
  // top door cards' last glyph row, the one row that tells E from F. One pixel lower clears it.
  var AX0 = 2, AX1 = W - 11, AY0 = ART.AISLE_Y + 13, AY1 = ART.AISLE_Y + ART.AISLE_H - 2;

  if (!C || !C.yards || !C.yards.length) throw new Error('content: no yards');

  var S = {
    screen: 'title', frames: 0, yi: 0, run: null, result: null,
    dirOrder: [], muted: false, paused: false, endPage: 0, ledgerPage: 0, toast: null, best: {},
  };
  var ED = C.edition === 'full' ? 'full' : 'free';
  var BEST_KEY = 'HALTER_BEST_' + ED, YI_KEY = 'HALTER_YARD_' + ED;
  try { S.best = JSON.parse(root.localStorage.getItem(BEST_KEY) || '{}') || {}; } catch (e) { S.best = {}; }
  function saveBest() { try { root.localStorage.setItem(BEST_KEY, JSON.stringify(S.best)); } catch (e) { /* private mode */ } }
  function saveYi() { try { root.localStorage.setItem(YI_KEY, String(S.yi)); } catch (e) { /* private mode */ } }
  function bestFor(id) { var b = S.best[String(id)]; return typeof b === 'number' ? b : null; }

  var cache = {};
  function yard(ix) { var c = C.yards[ix], k = c.size + ':' + c.seed; if (!cache[k]) { var G = YARD.generate(c.seed, c.size); G.herd = B.herd(c.seed, G.w); G.L = YARD.optimum(G); cache[k] = G; } return cache[k]; }
  function par(ix) { return yard(ix).L; }

  /* ⛔ THE MEDAL LINES (SELECTION_2026-10-03.md, fixed before the yards were chosen): GOLD = the least; SILVER within 5%;
   * BRONZE within 10%; beyond that the hand is WORN OUT (the loss: retry, or look at a clue). MEASURED on the shipped 40
   * (select_yards.js): the obvious play (cheapest trade that sends a beast home) misses BRONZE on 40/40, and so do
   * reading order and heaviest-first; the least plan is GOLD on 40/40. */
  var MEDALS = [
    { name: 'GOLD', line: 'THE LEAST THERE IS' },
    { name: 'SILVER', line: 'WITHIN A TWENTIETH OF THE LEAST' },
    { name: 'BRONZE', line: 'EVERY BEAST IS HOME' },
    { name: 'WORN OUT', line: 'HOME, BUT THE HAND IS WORN OUT' },
  ];
  function silverLine(L) { return Math.floor(1.05 * L); }
  function bronzeLine(L) { return Math.floor(1.10 * L); }
  function medalFor(e, L) { return e <= L ? MEDALS[0] : e <= silverLine(L) ? MEDALS[1] : e <= bronzeLine(L) ? MEDALS[2] : MEDALS[3]; }
  function passed(ix) { var b = bestFor(C.yards[ix].id); return b !== null && medalFor(b, par(ix)).name !== 'WORN OUT'; }
  function unlocked(ix) { return ix === 0 || passed(ix - 1) || bestFor(C.yards[ix].id) !== null; }
  function beastsHome() { var n = 0; for (var i = 0; i < C.yards.length; i++) if (passed(i)) n += yard(i).n; return n; }
  function beastsAll() { var n = 0; for (var i = 0; i < C.yards.length; i++) n += yard(i).n; return n; }
  (function restoreYi() {
    var v = 0;
    try { v = parseInt(root.localStorage.getItem(YI_KEY) || '0', 10) || 0; } catch (e) { v = 0; }
    v = Math.max(0, Math.min(C.yards.length - 1, v));
    while (v > 0 && !unlocked(v)) v--;
    S.yi = v;
  }());

  /* ------------------------------------------------------------------------ the byre */
  function beginRun() {
    var G = yard(S.yi), L = ART.layout(G.n);
    S.run = {
      G: G, Lay: L, at: G.at.slice(), led: -1, ledStall: -1, inStall: false,
      hx: Math.round(W / 2 - 4), hy: Math.round((AY0 + AY1) / 2), face: 1, walk: 0, moved: 0,
      bx: 0, by: 0, bface: 1,
      effort: 0, trades: [], tweens: [], pops: [], done: 0, steps: 0, push: 0, pushDir: null, pushSpent: false, pushArmed: false, tradeAt: -999, tradeQ: -1,
      refusals: {}, target: null, lastRefusal: null, lastRefusalAt: 0,
    };
    S.screen = 'play'; S.paused = false; S.toast = null; S.pressDy = 0;   // a key pressed on a card never arms a push
    if (SND) SND.cue('start');
  }
  function homeCount(r) { var n = 0; for (var p = 0; p < r.at.length; p++) if (r.at[p] === p) n++; return n; }
  function tweenOf(r, b) { for (var i = 0; i < r.tweens.length; i++) if (r.tweens[i].b === b) return r.tweens[i]; return null; }
  function stallOf(r, b) { return r.at.indexOf(b); }
  function toast(msg) { S.toast = { msg: msg, until: S.frames + 70 }; }
  function refuse(r, why, msg) {
    r.refusals[why] = (r.refusals[why] || 0) + 1;
    if (r.lastRefusal !== why || S.frames - r.lastRefusalAt > 20) { if (SND) SND.cue('bump'); if (msg) toast(msg); }
    r.lastRefusal = why; r.lastRefusalAt = S.frames;
    return false;
  }
  function handCX(r) { return r.hx + 4; }
  /** The stall whose door the hand is at, or -1. Top row when her feet are near the top of the aisle, bottom near the
   *  bottom; the stall is the one her middle stands in front of. */
  function facing(r) {
    var row = r.hy <= AY0 + 6 ? 'top' : r.hy >= AY1 - 4 ? 'bot' : null;
    if (!row) return -1;
    var cx = handCX(r);
    for (var i = 0; i < r.Lay.length; i++) { var s = r.Lay[i]; if (s.top === (row === 'top') && cx >= s.x + 1 && cx <= s.x + s.w - 2) return i; }
    return -1;
  }
  function speed(r) { return r.led >= 0 ? 1.25 / (1 + 0.11 * r.G.w[r.led]) : 1.25; }

  /** Z, or holding into a door: take the beast at the door; or, leading, lead her in (a trade); or let go. */
  function act(q) {
    var r = S.run;
    if (q === undefined) q = facing(r);
    if (r.led < 0) {
      if (q < 0) return refuse(r, 'nodoor', 'STAND AT A DOOR');
      // ⛔ ROUND-2 REVIEW #7: the trade that sends the carrier HOME also releases the halter, so a bounced second Z re-took
      //    the beast that had just gone home. The same settle window covers it (counted, silent).
      if (q === r.tradeQ && S.frames - r.tradeAt < SETTLE_FRAMES) { r.refusals.settle = (r.refusals.settle || 0) + 1; return false; }
      var b = r.at[q];
      if (tweenOf(r, b)) return refuse(r, 'busy', 'STILL WALKING');
      r.led = b; r.ledStall = q; r.inStall = true; r.bface = r.Lay[q].top ? 1 : -1;
      if (SND) SND.cue('hitch');
      return true;
    }
    // leading
    // ⛔ REVIEW 2026-10-03 #17: a second Z right after a trade (a bounced key, a habitual double press) let go of the
    //    beast the whole strategy depends on. A let-go at the door you just traded at waits SETTLE_FRAMES; it is
    //    counted, silently (it is not a mistake worth a bump).
    if (q >= 0 && q === r.ledStall && S.frames - r.tradeAt < SETTLE_FRAMES) { r.refusals.settle = (r.refusals.settle || 0) + 1; return false; }
    if (q < 0 || q === r.ledStall) { letGo(); return true; }
    var o = r.at[q];
    if (tweenOf(r, o)) return refuse(r, 'busy', 'STILL WALKING');
    var p = r.ledStall, led = r.led, cost = r.G.w[led] + r.G.w[o];
    r.effort += cost; r.trades.push([p, q]); r.tradeAt = S.frames; r.tradeQ = q;
    r.at[p] = o; r.at[q] = led;
    var from = beastXY(r, q, o);
    r.tweens.push({ b: o, x0: from.x, y0: from.y, to: p, t: 0 });
    r.pops.push({ text: '+' + cost, x: r.Lay[q].cx, y: r.Lay[q].top ? ART.AISLE_Y + 2 : ART.AISLE_Y + ART.AISLE_H - 12, t: 0 });
    r.ledStall = q; r.inStall = true;
    if (SND) SND.cue('trade');
    if (led === q) { r.led = -1; r.ledStall = -1; r.inStall = false; if (SND) SND.cue('home'); }
    checkDone(r);
    return true;
  }
  function letGo() {
    var r = S.run; if (r.led < 0) return;
    if (!r.inStall) r.tweens.push({ b: r.led, x0: r.bx, y0: r.by, to: r.ledStall, t: 0 });
    r.led = -1; r.ledStall = -1; r.inStall = false;
    if (SND) SND.cue('letgo');
  }
  function checkDone(r) {
    if (homeCount(r) === r.G.n && r.done === 0) { r.done = DONE_FRAMES; r.led = -1; r.ledStall = -1; if (SND) SND.cue('allhome'); }
  }

  /** Where beast b stands when she is in stall q (feet point). */
  function beastXY(r, q, b) {
    var s = r.Lay[q], sz = B.size(r.G.herd[b]);
    return { x: s.cx - Math.floor(sz.w / 2), y: s.feetY };
  }
  /** The aisle point outside stall q's door (for walking beasts). */
  function doorPoint(r, q, b) { var s = r.Lay[q], sz = B.size(r.G.herd[b]); return { x: s.cx - Math.floor(sz.w / 2), y: s.top ? ART.AISLE_Y + 18 : ART.AISLE_Y + ART.AISLE_H - 6 }; }

  function heldDirs() { var d = { x: 0, y: 0 }; S.dirOrder.forEach(function (k) { if (k === 'left') d.x = -1; if (k === 'right') d.x = 1; if (k === 'up') d.y = -1; if (k === 'down') d.y = 1; }); return d; }

  function stepPlay() {
    var r = S.run;
    // walking beasts (trades and let-go) and score pops
    for (var i = r.tweens.length - 1; i >= 0; i--) { var T = r.tweens[i]; T.t++; if (T.t >= TRADE_FRAMES) { r.tweens.splice(i, 1); if (r.at[T.to] === T.b && T.b === T.to && SND) SND.cue('home'); } }
    for (var k = r.pops.length - 1; k >= 0; k--) { r.pops[k].t++; if (r.pops[k].t > 50) r.pops.splice(k, 1); }
    if (r.done > 0) { r.done--; if (r.done === 0) finish(); return; }
    var d = heldDirs(), sp = speed(r), mx = 0, my = 0;
    if (!d.y) r.pushSpent = false;   // the push latch re-arms only when the up/down key is let go
    // ⛔ ROUND-2 REVIEW #1 (MAJOR): walking STRAIGHT into a door acted 150 ms after the hand arrived, so a crossing held a
    //    beat too long traded with the beast opposite (35 of 50 such strays made bronze unreachable). A push is ARMED only
    //    when up/down is pressed FRESH while the hand already stands at that wall — a deliberate bump, never the tail of a
    //    walk. Releasing the key disarms it.
    //    The fresh press is an EVENT (holdKey records it on key-down), never a per-frame sample, so a release and a press
    //    inside one frame still count as a new press.
    var atTop = r.hy <= AY0 + 0.01, atBot = r.hy >= AY1 - 0.01;
    if (S.pressDy) { if ((S.pressDy < 0 && atTop) || (S.pressDy > 0 && atBot)) r.pushArmed = true; S.pressDy = 0; }
    if (!d.y) r.pushArmed = false;
    if (d.x || d.y) { r.target = null; mx = d.x; my = d.y; }
    else if (r.target) {
      var dx = r.target.x - r.hx, dy = r.target.y - r.hy;
      if (Math.abs(dx) <= sp && Math.abs(dy) <= sp) {
        r.hx = r.target.x; r.hy = r.target.y; var a = r.target.act; r.target = null;
        if (a !== undefined && a >= 0) act(a);
      } else { var len = Math.hypot(dx, dy); mx = dx / len; my = dy / len; }
    }
    if (mx || my) {
      var n = Math.hypot(mx, my); mx /= n; my /= n;
      var nx = Math.max(AX0, Math.min(AX1, r.hx + mx * sp)), ny = Math.max(AY0, Math.min(AY1, r.hy + my * sp));
      // holding INTO a door: at the aisle's edge, pushing STRAIGHT toward a stall, for PUSH_FRAMES = Z.
      // ⛔ REVIEW 2026-10-03 #1 (MAJOR): with a diagonal held (Up+Right toward a corner stall) the hand slid along the
      //    wall and the push fired again at EVERY door it passed — takes and trades nobody pressed Z for. A push now
      //    needs the up/down key ALONE (no left/right held), and it fires ONCE per press of that key (pushSpent).
      var into = d.x !== 0 ? null : (d.y < 0 && r.hy <= AY0 + 0.01) ? 'up' : (d.y > 0 && r.hy >= AY1 - 0.01) ? 'down' : null;
      if (into && r.pushArmed && !r.pushSpent && facing(r) >= 0) {
        if (r.pushDir === into) r.push++; else { r.pushDir = into; r.push = 1; }
        if (r.push === PUSH_FRAMES) { r.pushSpent = true; act(); }
      } else { r.push = 0; r.pushDir = null; }
      if (nx !== r.hx || ny !== r.hy) { r.moved += Math.hypot(nx - r.hx, ny - r.hy); r.hx = nx; r.hy = ny; r.steps++; if (mx) r.face = mx < 0 ? -1 : 1; if (Math.floor(r.moved / 6) !== Math.floor((r.moved - sp) / 6) && SND) SND.cue('step'); }
      r.walk = 1 + (Math.floor(r.moved / 4) % 2);
    } else { r.walk = 0; r.push = 0; r.pushDir = null; }
    // the led beast: stays in her stall while the hand is at that door; once the hand walks off, she follows on the rope
    if (r.led >= 0) {
      if (r.inStall && facing(r) !== r.ledStall) {
        r.inStall = false; var dp = doorPoint(r, r.ledStall, r.led); r.bx = dp.x; r.by = dp.y;
      }
      if (!r.inStall) {
        var sz = B.size(r.G.herd[r.led]), tx = r.hx + (r.face > 0 ? -sz.w - 2 : 11), ty = r.hy;
        var ddx = tx - r.bx, ddy = ty - r.by, dist = Math.hypot(ddx, ddy);
        if (dist > 1) { var st = Math.min(dist, sp * 1.15); r.bx += ddx / dist * st; r.by += ddy / dist * st; if (Math.abs(ddx) > 0.3) r.bface = ddx < 0 ? -1 : 1; }
      }
    }
  }

  function finish() {
    var r = S.run, c = C.yards[S.yi], played = YARD.play(r.G, r.trades), prev = bestFor(c.id);
    if (played.cost !== r.effort) throw new Error('the log ' + r.effort + ' disagrees with the trades ' + played.cost);
    if (!played.sorted) throw new Error('finish() with a beast out of place');
    var isBest = prev === null || r.effort < prev;
    if (isBest) { S.best[String(c.id)] = r.effort; saveBest(); }
    var m = medalFor(r.effort, r.G.L);
    S.result = { ok: true, effort: r.effort, par: r.G.L, medal: m, late: m.name === 'WORN OUT', newBest: isBest, hadBest: prev !== null, prev: prev, trades: r.trades.length };
    if (SND) SND.cue(S.result.late ? 'late' : 'done');
    S.screen = 'result';
  }

  /* ----------------------------------------------------------------------------- drawing */
  var plane = new ART.Plane(W, H, LIT);
  var baseCache = { key: '', plane: null };
  var CARDCH = Math.floor((W - 12 - 8) / FONT.FACES.body.adv);
  function wrap(str, max) {
    var words = String(str).split(' '), lines = [], cur = '';
    for (var i = 0; i < words.length; i++) { var nx = cur ? cur + ' ' + words[i] : words[i]; if (nx.length > max && cur) { lines.push(cur); cur = words[i]; } else cur = nx; }
    if (cur) lines.push(cur); return lines;
  }
  function baseFor(G) {
    var key = G.size + ':' + G.seed;
    if (baseCache.key !== key) { var b = ART.byrePlane(G.n, G.seed); ART.hudBand(b); baseCache.plane = b; baseCache.key = key; }
    plane.px.set(baseCache.plane.px);
  }
  function text(str, x, y, o) { o = o || {}; FONT.textPlane(plane, str, x, y, o); }

  /** The stalls' contents for a run's state: sign letters, beasts at home or out of place, door cards and weights. */
  function drawStalls(r, opts) {
    opts = opts || {};
    var G = r.G, blink = (S.frames >> 3) % 2 === 0, ledHome = r.led >= 0 ? r.led : -1;
    for (var q = 0; q < r.Lay.length; q++) {
      var s = r.Lay[q], b = r.at[q];
      // the sign: the stall's letter, lit on dark; the led beast's home sign blinks
      var signShade = (q === ledHome && blink) ? MID : SHADOW;
      plane.rect(s.cx - 5, s.signY, 11, 9, signShade);
      text(s.letter, s.cx + 1, s.signY + 1, { align: 'center', shade: LIT });
      var present = !(b === r.led && !r.inStall) && !tweenOf(r, b);
      if (!present) continue;
      var hb = G.herd[b], sz = B.size(hb), atHome = b === q;
      var ring = opts.ring && opts.ring.indexOf(b) >= 0;
      B.drawBeast(plane, s.cx - Math.floor(sz.w / 2), s.feetY, hb, s.top ? 1 : -1, 0, ring && (S.frames >> 4) % 2 === 1);
      if (ring) drawBrackets(s.cx - Math.floor(sz.w / 2) - 2, s.feetY - sz.h - 1, sz.w + 3, sz.h + 3);
      // the arrow sits in the straw between the sign (top row) or the door (bottom row) and the beast's back
      if (opts.arrow && opts.arrow.indexOf(b) >= 0) arrowMark(s.cx, Math.max(s.top ? s.signY + 10 : s.doorY + 10, s.feetY - sz.h - 3));
      // the door: home = a lit horseshoe; out of place = the CARD (where she belongs) and the WEIGHT badge
      var dy = s.top ? s.doorY : s.doorY;
      if (atHome) { horseshoe(s.cx - 3, dy + 1); continue; }
      // ⛔ REVIEW 2026-10-03 #2 (MAJOR): the card's dark bottom rule sat directly under the glyph, so E's bar and the
      //    rule made a 2 px base and F's one pixel plus the rule read as E — two "E" cards on most byres. The card is
      //    10 rows now with a LIT row between the glyph and the rule. #7: the card and the badge sat 1 px apart and read
      //    as one code ("H8"); they are 2 px apart, and the rules card names the badge as the weight.
      var cw = 7, gap = 2, x0 = s.cx - cw - 1;
      plane.rect(x0, dy, cw, 10, LIT); plane.hline(x0, x0 + cw - 1, dy + 9, SHADOW);
      text(ART.LETTERS[b], x0 + 4, dy + 1, { align: 'center', shade: SHADOW });
      plane.rect(x0 + cw + gap, dy, cw, 10, SHADOW);
      text(String(G.w[b]), x0 + cw + gap + 4, dy + 1, { align: 'center', shade: LIT });
    }
  }
  /** HOME: a lit tick on a dark badge. ⛔ SCREENS ROUND 1 (LOOKED AT 08 at 3x): a lit horseshoe on the door read as the
   *  LETTER U — on a door whose other job is to show a letter. A tick on a badge is no letter. */
  function horseshoe(x, y) {
    var R = ['......0', '.....00', '0...00.', '00.00..', '.000...', '..0....'];
    plane.rect(x - 1, y - 1, 9, 9, SHADOW);
    for (var j = 0; j < R.length; j++) for (var i = 0; i < 7; i++) if (R[j][i] === '0') plane.set(x + i, y + j + 1, LIT);
  }
  /** A small dark down-arrow over a beast (the group a light beast is lent to), drawn on the stall's lit straw. */
  function arrowMark(cx, y) {
    var A = ['#####', '.###.', '..#..'];
    for (var jj = 0; jj < A.length; jj++) for (var ii = 0; ii < 5; ii++) if (A[jj][ii] === '#') plane.set(cx - 2 + ii, y + jj, SHADOW);
  }
  function drawBrackets(x, y, w, h) {
    var sh = (S.frames >> 3) % 2 ? MID : SHADOW, X0 = x, X1 = x + w, Y0 = Math.max(ART.HUD_H, y), Y1 = y + h;
    [[X0, Y0, 1, 1], [X1, Y0, -1, 1], [X0, Y1, 1, -1], [X1, Y1, -1, -1]].forEach(function (c) { for (var k = 0; k < 3; k++) { plane.set(c[0] + c[2] * k, c[1], sh); plane.set(c[0], c[1] + c[3] * k, sh); } });
  }
  /** Everything in the aisle, drawn back to front by feet y: walking beasts, the led beast, the hand. */
  function drawAisle(r, opts) {
    opts = opts || {};
    var items = [];
    r.tweens.forEach(function (T) {
      var hb = r.G.herd[T.b], t = Math.min(1, T.t / TRADE_FRAMES), to = beastXY(r, T.to, T.b), mid = doorPoint(r, T.to, T.b), x, y;
      // out through the door, along the aisle, in at the other door
      var a = { x: T.x0, y: T.y0 };
      if (t < 0.25) { var u = t / 0.25; x = a.x; y = a.y + ((r.Lay[stallOrTo(r, T)].top ? ART.AISLE_Y + 18 : ART.AISLE_Y + ART.AISLE_H - 6) - a.y) * u; }
      else if (t < 0.75) { var u2 = (t - 0.25) / 0.5, sy = r.Lay[stallOrTo(r, T)].top ? ART.AISLE_Y + 18 : ART.AISLE_Y + ART.AISLE_H - 6; x = a.x + (mid.x - a.x) * u2; y = sy + (mid.y - sy) * u2; }
      else { var u3 = (t - 0.75) / 0.25; x = mid.x; y = mid.y + (to.y - mid.y) * u3; }
      items.push({ y: y, draw: function () { B.drawBeast(plane, x, y, hb, mid.x < a.x ? -1 : 1, ((T.t >> 3) % 2) + 1, false); } });
    });
    if (r.led >= 0 && !r.inStall) {
      var hb2 = r.G.herd[r.led], bx = r.bx, by = r.by, wk = r.walk ? ((Math.floor(r.moved / 5) % 2) + 1) : 0, sz = B.size(hb2);
      items.push({ y: by, draw: function () {
        B.drawBeast(plane, bx, by, hb2, r.bface, wk, false);
        var headX = r.bface > 0 ? bx + sz.w - 2 : bx + 1, handX = r.face > 0 ? r.hx + 1 : r.hx + 7;
        ART.drawRope(plane, handX, r.hy - 5, headX, by - sz.h + 3);
      } });
    }
    items.sort(function (a, b) { return a.y - b.y; }).forEach(function (it) { it.draw(); });
    // ⛔ REVIEW #15 (open in both rounds): sorted by feet, a beast leaving the door the hand stands at was drawn OVER the
    //    hand and the two merged into one dark blob on the very frame that shows a trade. The hand (LIT-haloed) is drawn
    //    LAST, so the walker passes behind a figure that stays readable.
    if (!opts.noHand) ART.drawHand(plane, r.hx, r.hy, r.face, r.walk);
    // ⛔ SCREENS ROUND 1 (LOOKED AT 09_trade_mid_walk at 3x): a "+6" plate in the aisle sat on top of the beast walking
    // to her new stall — the one thing a trade animates. The trade's cost is shown in the HUD beside EFFORT instead.
  }
  function stallOrTo(r, T) { // which row the walker LEAVES from: the stall she was in before the trade
    for (var q = 0; q < r.Lay.length; q++) { var s = r.Lay[q]; if (Math.abs(s.cx - (T.x0 + 4)) < s.w && ((s.top && T.y0 < ART.AISLE_Y) || (!s.top && T.y0 > ART.AISLE_Y + ART.AISLE_H))) return q; }
    return T.to;
  }

  function hud(r) {
    var pop = r.pops.length ? r.pops[r.pops.length - 1] : null;
    text('EFFORT ' + r.effort + (pop && (pop.t < 30 || (pop.t >> 2) % 2) ? ' ' + pop.text : ''), 3, 3, { shade: LIT });
    text('LEAST ' + r.G.L, W - 3, 3, { align: 'right', shade: LIT });
    var line, q = facing(r);
    if (r.led >= 0) { var hb = r.G.herd[r.led]; line = 'HALTER: ' + hb.word + ' ' + hb.w + ' > ' + ART.LETTERS[r.led]; }
    else if (q >= 0) { var b = r.at[q], hb2 = r.G.herd[b]; line = b === q ? hb2.name + ' IS HOME' : hb2.name + ' ' + hb2.word + ' ' + hb2.w + ' > ' + ART.LETTERS[b]; }
    else line = 'HOME ' + homeCount(r) + '/' + r.G.n;
    text(line, 3, 13, { shade: LIT });
  }

  function drawPlayScreen() {
    var r = S.run;
    baseFor(r.G);
    drawStalls(r);
    drawAisle(r);
    hud(r);
    if (S.toast && S.frames < S.toast.until) {
      var w = S.toast.msg.length * 6 + 8, x = Math.round((W - w) / 2), ty = ART.AISLE_Y + 16;
      plane.rect(x, ty, w, 11, SHADOW); plane.hline(x, x + w - 1, ty - 1, LIT);
      text(S.toast.msg, W / 2 + 1, ty + 2, { align: 'center', shade: LIT });
    }
    if (S.paused) {
      plane.rect(29, 53, 102, 40, LIT); plane.rect(30, 54, 100, 38, SHADOW);
      text('PAUSED', W / 2, 60, { align: 'center', shade: LIT });
      text('P RESUME', W / 2, 72, { align: 'center', shade: FACE });
      text('X GIVE UP', W / 2, 81, { align: 'center', shade: FACE });
    }
  }

  function cardFrame(title) {
    plane.px.fill(MID);
    for (var i = 0; i < 10; i++) plane.hline(0, W - 1, 7 + i * 15, SHADOW);
    plane.rect(6, 14, W - 12, H - 34, SHADOW);
    plane.hline(6, W - 7, 14, LIT);
    text(title, W / 2, 20, { align: 'center', shade: LIT });
    plane.hline(30, W - 31, 30, MID);
  }
  var FOOT = { align: 'center', shade: LIT, halo: SHADOW };
  function card(title, lines, footer) {
    cardFrame(title);
    var flat = [];
    for (var j = 0; j < lines.length; j++) { if (!lines[j]) { flat.push(''); continue; } wrap(lines[j], CARDCH).forEach(function (l) { flat.push(l); }); }
    for (var k = 0; k < flat.length && 36 + k * 9 <= H - 22; k++) text(flat[k], W / 2, 36 + k * 9, { align: 'center', shade: FACE });
    if (footer) text(footer, W / 2, H - 12, FOOT);
  }

  var titleBase = null, titleImg = null, titleState = 'none';
  var FREE_BAND = { x: 36, y: H - 26, w: 88, h: 11 }, PRESS_BAND = { x: 44, y: H - 13, w: 72, h: 11 };
  function loadTitle() {
    if (titleState !== 'none' || !root.Image) return;
    titleState = 'loading';
    titleImg = new root.Image();
    titleImg.onload = function () { titleState = 'ready'; };
    titleImg.onerror = function () { titleState = 'failed'; };
    titleImg.src = 'art/title.png';
  }
  function drawTitle() {
    if (!titleBase) titleBase = ART.titlePlane(FONT, B);
    plane.px.set(titleBase.px);
    if (C.edition !== 'full') { plane.rect(FREE_BAND.x, FREE_BAND.y, FREE_BAND.w, FREE_BAND.h, SHADOW); text('FREE EDITION', W / 2, FREE_BAND.y + 2, { align: 'center', shade: LIT }); }
    if (S.frames % 48 < 32) { plane.rect(PRESS_BAND.x, PRESS_BAND.y, PRESS_BAND.w, PRESS_BAND.h, SHADOW); text('Z OR TAP', W / 2, PRESS_BAND.y + 2, { align: 'center', shade: LIT }); }
  }

  /** A run-shaped state for drawing a byre at its start (the yard screen, the lesson). */
  function startState(G) { return { G: G, Lay: ART.layout(G.n), at: G.at.slice(), led: -1, ledStall: -1, inStall: false, tweens: [], pops: [], hx: W / 2 - 4, hy: AY1, face: 1, walk: 0, effort: 0 }; }
  function drawYard() {
    var G = yard(S.yi), c = C.yards[S.yi], b = bestFor(c.id);
    baseFor(G);
    var st = startState(G); drawStalls(st);
    text(c.name, 3, 3, { shade: LIT });
    text('Z START', W - 3, 3, { align: 'right', shade: LIT });
    text((S.yi + 1) + '/' + C.yards.length, 3, 13, { shade: LIT });
    var hints = [b === null ? G.n + ' BEASTS' : medalFor(b, par(S.yi)).name, 'UP HERD BOOK', 'DOWN RULES', 'LEFT RIGHT BYRES'];
    text(hints[((S.frames / 72) | 0) % hints.length], W - 3, 13, { align: 'right', shade: LIT });
    if (S.toast && S.frames < S.toast.until) {
      var w = S.toast.msg.length * 6 + 8, x = Math.round((W - w) / 2), ty = ART.AISLE_Y + 16;
      plane.rect(x, ty, w, 11, SHADOW); plane.hline(x, x + w - 1, ty - 1, LIT);
      text(S.toast.msg, W / 2 + 1, ty + 2, { align: 'center', shade: LIT });
    }
  }

  function drawResult() {
    var R = S.result, c = C.yards[S.yi], G = S.run.G;
    cardFrame(R.medal.name);
    // the heaviest beast of the byre, large on a lit plate
    var hv = 0; for (var i = 1; i < G.n; i++) if (G.w[i] > G.w[hv]) hv = i;
    plane.rect(10, 36, 52, 52, LIT);
    for (var y = 36; y < 88; y++) for (var x = 10; x < 62; x++) plane.set(x, y, ART.strawPixel(x, y));
    plane.rect(10, 36, 52, 1, SHADOW); plane.rect(10, 87, 52, 1, SHADOW); plane.vline(10, 36, 87, SHADOW); plane.vline(61, 36, 87, SHADOW);
    // ⛔ SCREENS ROUND 1 (LOOKED AT 12_result_gold at 3x): a 1x beast on a 52 px plate read as an EMPTY plate. 2x now.
    var sz = B.size(G.herd[hv]); B.drawBeast(plane, 36 - sz.w, 82, G.herd[hv], 1, 0, false, 2);
    var tx = 113;
    text(c.name.length > 13 ? c.name.split(' ')[0] : c.name, tx, 34, { align: 'center', shade: LIT });
    text('YOUR EFFORT', tx, 48, { align: 'center', shade: FACE });
    text(String(R.effort), tx, 57, { align: 'center', shade: LIT });
    text('THE LEAST', tx, 70, { align: 'center', shade: FACE });
    text(String(R.par), tx, 79, { align: 'center', shade: LIT });
    var note = R.newBest ? (R.hadBest ? 'A NEW BEST' : (R.late ? 'NO MEDAL YET' : 'FIRST MEDAL')) : 'YOUR BEST ' + R.prev;
    text(note, tx, 92, { align: 'center', shade: FACE });
    var held = R.late && passed(S.yi), last = S.yi >= C.yards.length - 1;
    // round-2 review #11: the title already says WORN OUT; the line says what it means
    var line = !R.late ? R.medal.line : held ? 'YOUR MEDAL HERE STANDS.' : last ? 'BRONZE ENDS THE NIGHT.' : 'BRONZE OPENS THE NEXT BYRE.';
    wrap(line, 24).slice(0, 2).forEach(function (l, i) { text(l, W / 2, 106 + i * 8, { align: 'center', shade: FACE }); });
    text(R.late ? 'Z RETRY  X A CLUE' : 'Z NEXT  X THE LEAST', W / 2, H - 12, FOOT);
  }

  /** ALL IN — after a pass, every beast of the byre with its name (the herd book's page). */
  function drawHomeCard() {
    var G = S.run.G, c = C.yards[S.yi];
    plane.px.fill(MID);
    plane.rect(0, 0, W, 12, SHADOW);
    // ⛔ REVIEW 2026-10-03 #11/#12: "ALL IN TONIGHT" left 11 characters for the name, so a 12-letter byre name overlapped
    //    it and long names were cut to a first word that read like a sentence ("ALL IN TONIGHT  COLD"). The title is
    //    "ALL IN" and the name is always whole (the longest byre name is 13 characters; 18 fit).
    text('ALL IN', 3, 3, { shade: LIT });
    text(c.name, W - 3, 3, { align: 'right', shade: FACE });
    // ⛔ ROUND-2 REVIEW #3 (MAJOR): four rows of 32 px from y 14 end at y 142 and the footer's halo starts at y 134, so on
    //    every 14-16 beast byre "Z NEXT BYRE" was printed over the last row's names. The row pitch is DERIVED from the room
    //    above the footer (H - 12 - 14 = 118 px): 32 px for up to three rows, 29 px for four; the name strip keeps its 9 px.
    var cols = 4, sw = 39, rows = Math.ceil(G.n / cols), sh = Math.min(32, Math.floor((H - 12 - 14) / rows));
    var y0 = 14 + Math.max(0, Math.floor((4 - rows) * sh / 2)), ph = sh - 2, nameDy = ph - 9;
    for (var i = 0; i < G.n; i++) {
      var x = 2 + (i % cols) * sw, y = y0 + Math.floor(i / cols) * sh;
      plane.rect(x, y, sw - 2, ph, FACE);
      for (var yy = y + 1; yy < y + nameDy - 1; yy++) for (var xx = x + 1; xx < x + sw - 3; xx++) plane.set(xx, yy, ART.strawPixel(xx, yy));
      var hb = G.herd[i], sz = B.size(hb);
      B.drawBeast(plane, x + Math.floor((sw - 2 - sz.w) / 2), y + nameDy - 3, hb, 1, 0, false);
      plane.rect(x, y + nameDy, sw - 2, 9, LIT);
      text(hb.name, x + (sw - 2) / 2, y + nameDy + 1, { align: 'center', shade: SHADOW });   // review #13: was +1 (0 px right margin)
    }
    text('Z NEXT BYRE', W / 2, H - 9, FOOT);
  }

  /** THE LESSON after a PASS (the carrier of every loop ringed, borrowed ones named), or ONE CLUE after a loss (one loop
   *  ringed, its carrier NOT named — MILLWRIGHT review defect 10, carried: lose, look, retry = GOLD is no game). */
  function revealIsClue() { return !!(S.result && S.result.late); }
  // ⛔ ROUND-2 REVIEW #2 (MAJOR): on every lend byre the lesson ringed the lent beast once and marked NOTHING of the group
  //    it is lent to (0 of 12), so the twist was invisible, store shot 2 included. `lentTo` is that group; the lesson draws
  //    an arrow over each of its beasts and says in the aisle who is lent to whom.
  function carriers(G) {
    var g = Math.min.apply(null, G.w), gObj = G.w.indexOf(g), out = [], borrowed = false, lentTo = [];
    YARD.cycles(G).forEach(function (c) {
      var k = c.length, S2 = 0, m = 99, mObj = -1;
      c.forEach(function (o) { S2 += G.w[o]; if (G.w[o] < m) { m = G.w[o]; mObj = o; } });
      if (!c.includes(gObj) && m + (k + 1) * g < (k - 2) * m) { borrowed = true; if (out.indexOf(gObj) < 0) out.push(gObj); c.forEach(function (o) { lentTo.push(o); }); }
      else out.push(mObj);
    });
    return { list: out, borrowed: borrowed, lentTo: lentTo, lent: borrowed ? gObj : -1 };
  }
  /** Two lines of explanation on a dark plate in the middle of the aisle (empty on the reveal screens). */
  function aislePlate(lines) {
    var y = ART.AISLE_Y + 13, w = 0; lines.forEach(function (l) { w = Math.max(w, l.length * 6); });
    var x = Math.round((W - w) / 2) - 4;
    plane.rect(x, y, w + 8, lines.length * 9 + 5, SHADOW); plane.hline(x, x + w + 7, y - 1, LIT); plane.hline(x, x + w + 7, y + lines.length * 9 + 5, LIT);
    lines.forEach(function (l, i) { text(l, W / 2 + 1, y + 3 + i * 9, { align: 'center', shade: LIT }); });
  }
  function drawReveal() {
    var r = S.run, G = r.G, clue = revealIsClue(), foot = (S.frames % 192) < 96;
    baseFor(G);
    var st = startState(G);
    // ⛔ REVIEW 2026-10-03 #4/#5: line 2 used to alternate between the explanation and the key help, so every capture
    //    (and any player glancing at the wrong moment) saw bracketed beasts with nothing explained; and it used "loop"
    //    and "carry", words the game never teaches. The EXPLANATION is line 2 and never alternates; only line 1 does.
    if (clue) {
      // ⛔ ROUND-2 REVIEW #4: the clue reads the PLAY (yard.js clue(G, trades)): the group the player's own trades over-spent
      var cl = YARD.clue(G, r.trades);
      drawStalls(st, { ring: cl.loop });
      text(foot ? 'A CLUE' : 'Z BACK  X BYRES', 3, 3, { shade: LIT });
      text(cl.borrowed ? 'LEND THEM A LIGHT BEAST' : 'ONE RINGED BEAST LEADS ALL', 3, 13, { shade: LIT });
      aislePlate(cl.borrowed ? ['NONE OF THE RINGED IS', 'LIGHT ENOUGH TO LEAD'] : ['YOUR TRADES WASTED MOST', 'IN THE RINGED GROUP']);
      return;
    }
    var cr = carriers(G);
    drawStalls(st, { ring: cr.list, arrow: cr.lentTo });
    if (foot) { text('LEAST ' + G.L, 3, 3, { shade: LIT }); text('YOURS ' + S.result.effort, W - 3, 3, { align: 'right', shade: LIT }); }
    else text('Z BACK  X BYRES', 3, 3, { shade: LIT });
    text(cr.list.length > 1 ? 'RINGED: THE LEADERS' : 'RINGED: THE LEADER', 3, 13, { shade: LIT });
    aislePlate(cr.borrowed
      ? ['THE ' + G.herd[cr.lent].word + ' IS LENT TO THE', 'BEASTS UNDER THE ARROWS']
      : ['A LEADER WALKS ITS GROUP', 'HOME AND GOES IN LAST']);
  }

  /** THE HERD BOOK: every byre, ten to a page, its heaviest beast and medal, and the count of beasts home. */
  function drawLedger() {
    plane.px.fill(MID);
    plane.rect(0, 0, W, 12, SHADOW);
    var pages = Math.ceil(C.yards.length / 10), pg = Math.max(0, Math.min(S.ledgerPage, pages - 1));
    text('BEASTS HOME ' + beastsHome() + '/' + beastsAll(), 3, 3, { shade: LIT });   // review #18: "HERD BOOK 10/100" read as byres
    text((pg + 1) + '/' + pages, W - 3, 3, { align: 'right', shade: LIT });
    for (var i = 0; i < 10; i++) {
      var ix = pg * 10 + i; if (ix >= C.yards.length) break;
      var c = C.yards[ix], cx = 3 + (i % 5) * 31, cy = 16 + Math.floor(i / 5) * 58;
      plane.rect(cx, cy, 29, 54, SHADOW);
      var b = bestFor(c.id);
      if (unlocked(ix) || b !== null) {
        var G = yard(ix), hv = 0; for (var k = 1; k < G.n; k++) if (G.w[k] > G.w[hv]) hv = k;
        for (var yy = cy + 2; yy < cy + 22; yy++) for (var xx = cx + 2; xx < cx + 27; xx++) plane.set(xx, yy, ART.strawPixel(xx, yy));
        var hb = G.herd[hv], sz = B.size(hb);
        B.drawBeast(plane, cx + 14 - Math.floor(sz.w / 2), cy + 20, hb, 1, 0, false);   // round-2 #10: a dotted ghost read as noise
      }
      if (b !== null) { var med = medalFor(b, par(ix)).name; text(med === 'WORN OUT' ? '-' : med.charAt(0), cx + 15, cy + 28, { align: 'center', shade: LIT }); }
      else text('?', cx + 15, cy + 28, { align: 'center', shade: MID });
      text(String(ix + 1), cx + 15, cy + 42, { align: 'center', shade: b !== null ? FACE : MID });
    }
    text(pages > 1 ? 'LEFT RIGHT: PAGE  X BACK' : 'X BACK', W / 2, H - 9, FOOT);
  }

  var LINES_PER_PAGE = 9;
  function endingPages() {
    var raw = C.ending || [].concat(C.demoEnd || ''), paras = [];
    for (var i = 0; i < raw.length; i++) if (raw[i]) paras.push(wrap(raw[i], CARDCH));
    var pages = [], cur = [];
    paras.forEach(function (p) {
      if (cur.length && (LINES_PER_PAGE - cur.length < 3 || (cur.length + 1 + p.length > LINES_PER_PAGE && p.length <= LINES_PER_PAGE))) { pages.push(cur); cur = []; }
      if (cur.length) cur.push('');
      for (var k = 0; k < p.length; k++) { if (cur.length >= LINES_PER_PAGE) { pages.push(cur); cur = []; } cur.push(p[k]); }
    });
    if (cur.length) pages.push(cur);
    return pages.length ? pages : [['']];
  }
  function drawEnding() {
    var pages = endingPages(), page = Math.max(0, Math.min(S.endPage, pages.length - 1));
    cardFrame(C.ending ? C.endingTitle : 'END OF THE FREE EDITION');
    for (var k = 0; k < pages[page].length; k++) text(pages[page][k], W / 2, 38 + k * 9, { align: 'center', shade: FACE });
    var more = page < pages.length - 1;
    text(more ? 'Z MORE ' + (page + 1) + '/' + pages.length : 'Z CREDITS', W / 2, H - 12, FOOT);
  }
  // each rule one line of at most 23 characters, grouped: the hands, the trade, the numbers.
  // ⛔ REVIEW 2026-10-03 #4: the carrier rule (you KEEP the halter after a trade) was taught nowhere; #7: nothing said the
  //    dark badge is the weight; #21: "her" for every beast, including the ox. LOOKED AT: a tenth line sat flush on the
  //    panel's bottom edge, so the medal line went (the result card says what bronze does). Nine lines.
  // ⛔ ROUND-2 REVIEW #5: the card never said what winning is, and "HOLD A WAY TO WALK" read oddly. The goal leads now.
  var RULES = ['PUT EVERY BEAST HOME', 'FOR THE LEAST EFFORT.', 'HOLD AN ARROW TO WALK.', 'Z AT A DOOR: TAKE ONE.',
    'AT ANOTHER DOOR: TRADE,', 'AND YOU KEEP YOURS.', 'A TRADE COSTS BOTH', 'WEIGHTS (DARK BADGES).', 'CARD: WHERE IT LIVES.'];
  var RULES_KEY = 'HALTER_RULES_SEEN', rulesSeen = false;
  try { rulesSeen = root.localStorage.getItem(RULES_KEY) === '1'; } catch (e) { rulesSeen = false; }
  function markRulesSeen() { rulesSeen = true; try { root.localStorage.setItem(RULES_KEY, '1'); } catch (e) { /* private mode */ } }
  function drawRules() { card('THE BYRE', RULES, S.rulesThenRun ? 'Z START  X BACK' : 'Z OR X BACK'); }
  function drawCredits() {
    card('HALTER', ['CORE SYSTEMS', 'ASSET FACTORY', '', 'CODE, ART AND TEXT MADE', 'WITH AI ASSISTANCE.', 'MUSIC AND SOUND ARE', 'SYNTHESISED FROM NOTES.'], 'X BACK');
  }
  function drawGaveUp() { card('LEFT FOR THE NIGHT', ['THE BEASTS WAIT IN THE WRONG STALLS.', '', 'THE CHEAPEST TRADE IS NOT ALWAYS THE BEST ONE.'], 'Z RETRY  X BYRES'); }

  /* ------------------------------------------------------------------------------ paint */
  var cv, ctx, img, data;
  var PAL = DMG.map(function (h) { return [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)]; });
  function paint() {
    for (var i = 0, p = 0; i < plane.px.length; i++, p += 4) { var c = PAL[plane.px[i]] || PAL[0]; data[p] = c[0]; data[p + 1] = c[1]; data[p + 2] = c[2]; data[p + 3] = 255; }
    ctx.putImageData(img, 0, 0);
    if (S.screen === 'title' && titleState === 'ready') {
      ctx.drawImage(titleImg, 0, 0, W, H);
      if (C.edition !== 'full') ctx.putImageData(img, 0, 0, FREE_BAND.x, FREE_BAND.y, FREE_BAND.w, FREE_BAND.h);
      ctx.putImageData(img, 0, 0, PRESS_BAND.x, PRESS_BAND.y, PRESS_BAND.w, PRESS_BAND.h);
    }
  }

  /* ------------------------------------------------------------------------------ input */
  function press(k) {
    if (SND) SND.unlock();
    if (k === 'mute') { S.muted = !S.muted; if (SND) SND.setMuted(S.muted); return; }
    if (S.screen === 'title') { if (k === 'ok') { S.screen = 'yard'; if (SND) SND.cue('ok'); } else if (k === 'back') S.screen = 'credits'; return; }
    if (S.screen === 'yard') {
      if (k === 'left' && S.yi > 0) { S.yi--; saveYi(); if (SND) SND.cue('page'); }
      else if (k === 'right' && S.yi < C.yards.length - 1 && unlocked(S.yi + 1)) { S.yi++; saveYi(); if (SND) SND.cue('page'); }
      else if (k === 'right' && S.yi < C.yards.length - 1) { if (SND) SND.cue('bump'); toast('BRONZE HERE OPENS IT'); }   // review #12
      else if (k === 'up') { S.screen = 'ledger'; S.ledgerPage = Math.floor(S.yi / 10); if (SND) SND.cue('ok'); }
      else if (k === 'down') { S.screen = 'rules'; S.rulesThenRun = false; if (SND) SND.cue('ok'); }
      else if (k === 'ok' && !rulesSeen) { S.screen = 'rules'; S.rulesThenRun = true; if (SND) SND.cue('ok'); }
      else if (k === 'ok') beginRun();
      else if (k === 'back') S.screen = 'title';
      return;
    }
    if (S.screen === 'rules') {
      if (k === 'ok' && S.rulesThenRun) { markRulesSeen(); beginRun(); }
      else if (k === 'ok' || k === 'back') { markRulesSeen(); S.screen = 'yard'; if (SND) SND.cue('ok'); }
      return;
    }
    if (S.screen === 'ledger') {
      var pages = Math.ceil(C.yards.length / 10);
      if (k === 'left' && S.ledgerPage > 0) { S.ledgerPage--; if (SND) SND.cue('page'); }
      else if (k === 'right' && S.ledgerPage < pages - 1) { S.ledgerPage++; if (SND) SND.cue('page'); }
      else if (k === 'back' || k === 'ok' || k === 'down') { S.screen = 'yard'; if (SND) SND.cue('ok'); }
      return;
    }
    if (S.screen === 'play') {
      var r = S.run;
      if (r.done > 0) return;
      if (k === 'pause' || (k === 'back' && !S.paused)) { S.paused = !S.paused; if (SND) SND.cue('ok'); }
      else if (k === 'back' && S.paused) { S.paused = false; S.result = { ok: false, gaveUp: true, home: homeCount(r) }; S.screen = 'gaveup'; }
      else if (k === 'ok' && S.paused) { S.paused = false; }
      else if (k === 'ok') { r.target = null; act(); }
      return;
    }
    if (S.screen === 'gaveup') { if (k === 'ok') beginRun(); else if (k === 'back') { S.screen = 'yard'; if (SND) SND.cue('ok'); } return; }
    if (S.screen === 'result') {
      if (k === 'back') { S.screen = 'reveal'; if (SND) SND.cue('ok'); return; }
      if (k === 'ok') { if (S.result.late) { beginRun(); return; } S.screen = 'homecard'; if (SND) SND.cue('ok'); }
      return;
    }
    if (S.screen === 'homecard') {
      if (k === 'ok' || k === 'back') {
        if (S.yi >= C.yards.length - 1) { S.screen = 'ending'; S.endPage = 0; }
        else { S.yi++; saveYi(); S.screen = 'yard'; }
        if (SND) SND.cue('ok');
      }
      return;
    }
    if (S.screen === 'reveal') { if (k === 'ok') { S.screen = 'result'; if (SND) SND.cue('ok'); } else if (k === 'back') { S.screen = 'yard'; if (SND) SND.cue('ok'); } return; }
    if (S.screen === 'ending') {
      if (k === 'ok') { if (S.endPage < endingPages().length - 1) { S.endPage++; if (SND) SND.cue('page'); } else S.screen = 'credits'; }
      // review #19: X must do something; round-2 #12: going straight to the credits skipped the page with the store
      // address, so X turns the page like Z does
      else if (k === 'back') { if (S.endPage < endingPages().length - 1) { S.endPage++; if (SND) SND.cue('page'); } else { S.screen = 'credits'; if (SND) SND.cue('ok'); } }
      return;
    }
    if (S.screen === 'credits') { if (k === 'back' || k === 'ok') S.screen = 'title'; }
  }

  var HELD = {};
  function holdKey(k, down) {
    if (down && !HELD[k] && (k === 'up' || k === 'down')) S.pressDy = k === 'up' ? -1 : 1;   // a fresh press (the push arm)
    HELD[k] = down;
    S.dirOrder = S.dirOrder.filter(function (d) { return d !== k; });
    if (down) S.dirOrder.push(k);
  }
  var KEYMAP = {
    ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down',
    a: 'left', d: 'right', w: 'up', s: 'down', A: 'left', D: 'right', W: 'up', S: 'down',
    z: 'ok', Z: 'ok', Enter: 'ok', ' ': 'ok', x: 'back', X: 'back', Escape: 'back', Backspace: 'back',
    p: 'pause', P: 'pause', m: 'mute', M: 'mute',
  };

  /** The pointer vocabulary, shared by the page's real events and the harness (§6b-64: the harness sends the same GAME
   *  POINTS a finger lands on). A finger on a stall walks the hand to that door and acts there (take, or trade); a
   *  finger in the aisle walks her there; a tap on the hand is Z (let go). */
  function stallAt(r, x, y) {
    // ⛔ ROUND-2 REVIEW #8: a leading `y >= s.y0` defeated the bottom row's 4 px extension into the aisle; both rows reach
    // 4 px into the aisle now.
    for (var i = 0; i < r.Lay.length; i++) { var s = r.Lay[i]; if (x >= s.x && x < s.x + s.w && y >= s.y0 - (s.top ? 0 : 4) && y <= s.y1 + (s.top ? 4 : 0)) return i; }
    return -1;
  }
  function pointerDown(x, y) {
    var r = S.run;
    if (S.screen !== 'play' || !r || S.paused || r.done > 0) return;
    if (x >= r.hx - 2 && x <= r.hx + 10 && y >= r.hy - 14 && y <= r.hy + 1) { r.target = null; act(); return; }   // a tap on the hand = Z
    var q = stallAt(r, x, y);
    if (q >= 0) { var s = r.Lay[q]; r.target = { x: Math.max(AX0, Math.min(AX1, s.cx - 4)), y: s.top ? AY0 : AY1, act: q }; return; }
    r.target = { x: Math.max(AX0, Math.min(AX1, x - 4)), y: Math.max(AY0, Math.min(AY1, y)) };
  }

  /* ------------------------------------------------------------------------------- loop */
  var draw = true;
  function step(n) {
    n = n === undefined ? 1 : n;
    for (var i = 0; i < n; i++) {
      S.frames++;
      if (S.screen === 'play' && !S.paused) stepPlay();
    }
    if (!draw) return;
    if (S.screen === 'title') drawTitle();
    else if (S.screen === 'yard') drawYard();
    else if (S.screen === 'play') drawPlayScreen();
    else if (S.screen === 'result') drawResult();
    else if (S.screen === 'homecard') drawHomeCard();
    else if (S.screen === 'reveal') drawReveal();
    else if (S.screen === 'ledger') drawLedger();
    else if (S.screen === 'ending') drawEnding();
    else if (S.screen === 'credits') drawCredits();
    else if (S.screen === 'rules') drawRules();
    else if (S.screen === 'gaveup') drawGaveUp();
    if (ctx) paint();
  }
  var STEP_MS = 1000 / 60, acc = 0, lastT = null;
  function frame(t) {
    if (lastT === null) lastT = t;
    acc += Math.min(250, t - lastT); lastT = t;
    var n = 0;
    while (acc >= STEP_MS && n < 4) { acc -= STEP_MS; n++; }
    if (n) step(n);
    root.requestAnimationFrame(frame);
  }

  function boot() {
    cv = root.document.getElementById('screen');
    ctx = cv.getContext('2d'); ctx.imageSmoothingEnabled = false;
    img = ctx.createImageData(W, H); data = img.data;
    loadTitle();
    root.addEventListener('keydown', function (e) {
      var k = KEYMAP[e.key]; if (!k) return;
      e.preventDefault();
      if (k === 'left' || k === 'right' || k === 'up' || k === 'down') {
        var was = HELD[k]; holdKey(k, true);
        if (!was && S.screen !== 'play') press(k);
      } else if (!e.repeat) press(k);
    });
    root.addEventListener('keyup', function (e) { var k = KEYMAP[e.key]; if (k && HELD[k]) holdKey(k, false); });
    root.addEventListener('blur', function () { HELD = {}; S.dirOrder = []; });
    function gamePt(e) { var b = cv.getBoundingClientRect(); return { x: (e.clientX - b.left) * W / b.width, y: (e.clientY - b.top) * H / b.height }; }
    var swipe = null;
    cv.addEventListener('pointerdown', function (e) {
      e.preventDefault(); if (SND) SND.unlock();
      try { cv.setPointerCapture(e.pointerId); } catch (err) { /* not capturable */ }
      var g = gamePt(e);
      swipe = { x: g.x, y: g.y, t: Date.now(), moved: false };
      if (S.screen === 'play') pointerDown(g.x, g.y);
    });
    cv.addEventListener('pointermove', function (e) {
      if (!swipe || S.screen === 'play') return;
      var g = gamePt(e);
      // ⛔ PILOTAGE (found by its swipe arm): one long swipe fired several presses; one gesture is one press.
      if (swipe.fired) return;
      var dx = g.x - swipe.x, dy = g.y - swipe.y;
      if (Math.hypot(dx, dy) < 10) return;
      swipe.moved = true; swipe.fired = true;
      press(Math.abs(dx) > Math.abs(dy) ? (dx < 0 ? 'left' : 'right') : (dy < 0 ? 'up' : 'down'));
    });
    function up() {
      if (!swipe) return;
      var quick = !swipe.moved && Date.now() - swipe.t < 300, wasPlay = S.screen === 'play';
      swipe = null;
      if (quick && !wasPlay) press('ok');
    }
    cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
    root.__hPress = function (k) { press(k); };
    if (/[?&]harness=1\b/.test(root.location.search)) { step(1); return; }
    step(1);
    root.requestAnimationFrame(frame);
  }

  root.HALTER = {
    step: step, setDraw: function (v) { draw = !!v; }, press: press,
    hold: function (dir, down) { holdKey(dir, down !== false); },
    releaseAll: function () { HELD = {}; S.dirOrder = []; },
    pointerDown: pointerDown, facing: function () { return S.run ? facing(S.run) : -1; },
    state: S, plane: plane, beginRun: beginRun, yard: yard, par: par, endingPages: endingPages, medalFor: medalFor, unlocked: unlocked,
    revealIsClue: revealIsClue, carriers: carriers, beastsHome: beastsHome, beastsAll: beastsAll, act: function (q) { return act(q); },
    titleState: function () { return titleState; }, AISLE: { AX0: AX0, AX1: AX1, AY0: AY0, AY1: AY1 },
    get frames() { return S.frames; }, version: '1.0.0',
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.HALTER;
  else if (root.document) { if (root.document.readyState === 'loading') root.addEventListener('DOMContentLoaded', boot); else boot(); }
}(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this)));
