/**
 * yard.js — HALTER. The byre: n beasts stand in n stalls, every one in the wrong stall. One move is a TRADE: lead a
 * beast on the halter into another beast's stall and the two change places. A trade costs the weight of BOTH beasts.
 * The least total effort to put every beast home is PROVED (the cycle formula below), and that is the par.
 *
 * ⛔ THE GENERATOR IS THE SCREEN'S, VERBATIM: csaf-auxiliary pass 260, Wings/Auxiliary/Research/games_pass260/screen.js
 *    generate() (base variant: n 10..12, weights 1..9, a uniform permutation, never the identity), plus that file's
 *    'n14-16' size draw for the late paid yards. Internal_Ops/verify_yard.js reproduces the screen's rows from this file
 *    and fails on any difference, so the bars the screen measured are the bars of the shipped yards.
 * ⛔ THE OPTIMUM is the known result for sorting by weighted transpositions: per loop of k >= 2 beasts with weight sum S,
 *    lightest m, and the lightest beast in the whole byre g: S + min((k - 2)·m, m + (k + 1)·g). verify_yard.js checks it
 *    against an exhaustive Dijkstra search over every arrangement for n <= 7, with a sabotage arm that must go red.
 *
 * Conventions: w[o] = weight of beast o; at[p] = the beast standing in stall p; beast o belongs in stall o.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.YARD = api;
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  function rng(seed) { let a = (seed + 0x9e3779b9) >>> 0; return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

  /** The screen's generate(seed) with VARIANT 'base' (size 10..12) or 'n14-16' (size 14..16). */
  function generate(seed, size) {
    const r = rng(seed * 2654435761 % 4294967291 + 41), ri = (lo, hi) => lo + Math.floor(r() * (hi - lo + 1));
    const n = size === 'n14-16' ? ri(14, 16) : ri(10, 12);
    const w = Array.from({ length: n }, () => ri(1, 9));
    let at;
    do { at = [...Array(n).keys()]; for (let i = n - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [at[i], at[j]] = [at[j], at[i]]; } }
    while (at.every((o, p) => o === p));
    return { seed, size: size || 'base', n, w, at };
  }

  /** Loops of length >= 2, each as the list of beasts in it (the screen's cycles()). */
  function cycles(G, at) {
    at = at || G.at;
    const seen = new Array(G.n).fill(false), out = [];
    for (let p = 0; p < G.n; p++) { if (seen[p] || at[p] === p) continue; const c = []; let q = p; while (!seen[q]) { seen[q] = true; c.push(at[q]); q = at[q]; } out.push(c); }
    return out;
  }

  /** The proved least effort from arrangement `at` (default: the yard's start). */
  function optimum(G, at) {
    at = at || G.at;
    const g = Math.min(...G.w); let total = 0;
    for (const c of cycles(G, at)) {
      const k = c.length, S = c.reduce((s, o) => s + G.w[o], 0), m = Math.min(...c.map((o) => G.w[o]));
      total += S + Math.min((k - 2) * m, m + (k + 1) * g);
    }
    return total;
  }

  /** Does any loop of this arrangement need the byre's lightest beast BORROWED in (strictly cheaper)? */
  function borrowPays(G, at) {
    at = at || G.at;
    const g = Math.min(...G.w);
    return cycles(G, at).some((c) => { const k = c.length, m = Math.min(...c.map((o) => G.w[o])); return m + (k + 1) * g < (k - 2) * m; });
  }

  /** Play a list of trades [p, q] (stall indices) from `at`; returns { cost, at, sorted }. */
  function play(G, trades, at) {
    at = (at || G.at).slice(); let cost = 0;
    for (const [p, q] of trades) { cost += G.w[at[p]] + G.w[at[q]]; [at[p], at[q]] = [at[q], at[p]]; }
    return { cost, at, sorted: at.every((o, p) => o === p) };
  }

  /** A least plan (the screen's insight(): each loop carried by its lightest, or by the borrowed byre-lightest when that
   *  is cheaper). Used ONLY for the lesson after a pass, never shown before. */
  function leastPlan(G) {
    const at = G.at.slice(), trades = [], g = Math.min(...G.w);
    const sw = (p, q) => { trades.push([p, q]); [at[p], at[q]] = [at[q], at[p]]; };
    const carry = (carrier) => { for (;;) { const p = at.indexOf(carrier); if (p === carrier) return; sw(p, at.indexOf(p)); } };
    const cyc = cycles(G).sort((a, b) => Math.min(...a.map((o) => G.w[o])) - Math.min(...b.map((o) => G.w[o])));
    const gObj = G.w.indexOf(g);
    for (const c of cyc) {
      const k = c.length, m = Math.min(...c.map((o) => G.w[o])), mObj = c.find((o) => G.w[o] === m);
      if (c.includes(gObj) || (k - 2) * m <= m + (k + 1) * g || at[gObj] !== gObj) { carry(mObj); continue; }
      sw(gObj, at.indexOf(mObj));
      carry(gObj);
    }
    return trades;
  }

  /** The obvious play (the screen's HAND): the cheapest trade that puts at least one beast home. */
  function handPlan(G) {
    const at = G.at.slice(), trades = [];
    while (!at.every((o, p) => o === p)) {
      let best = null;
      for (let p = 0; p < G.n; p++) for (let q = p + 1; q < G.n; q++) {
        const homeP = at[p] === q, homeQ = at[q] === p; if (!homeP && !homeQ) continue;
        const c = G.w[at[p]] + G.w[at[q]], both = homeP && homeQ;
        if (!best || c < best.c || (c === best.c && both && !best.both)) best = { p, q, c, both };
      }
      trades.push([best.p, best.q]); [at[best.p], at[best.q]] = [at[best.q], at[best.p]];
    }
    return trades;
  }

  /** ONE CLUE after a loss (never the plan): the loop the player's own play handled worst, ringed, with the beast that
   *  should have carried it. Returns { loop: [beasts], carrier, borrowed: bool, excess } from the START arrangement.
   *  ⛔ ROUND-2 REVIEW #4: this used to IGNORE the play and rank any borrow loop first (+1000), so on every lend byre the
   *  clue pointed at the lend although the lend is never what loses a byre (the no-lend least sits within BRONZE on all
   *  twelve). With `trades` it now READS the play: every trade's cost is split by beast (each pays its own weight) and
   *  credited to that beast's START loop, against the loop's least share (members: S + (k-2)m carried by their own
   *  lightest, S + m when the byre's lightest is lent in; the lent beast's (k+1)g extra trips are credited to ITS loop).
   *  The ringed loop is the one with the largest excess over its share. Without trades: the structural trap score. */
  function clue(G, trades) {
    const g = Math.min(...G.w), gObj = G.w.indexOf(g), cs = cycles(G), info = [];
    for (const c of cs) {
      const k = c.length, S = c.reduce((s, o) => s + G.w[o], 0), m = Math.min(...c.map((o) => G.w[o]));
      const own = S + (k - 2) * m, bor = S + m + (k + 1) * g, borrowed = bor < own && !c.includes(gObj);
      info.push({ c, k, S, m, borrowed, share: borrowed ? S + m : own, lentTrips: borrowed ? (k + 1) * g : 0, trap: (k - 2) * (S / k - m) });
    }
    // beasts already home belong to no loop: a pseudo-loop holds their trades (and the lent trips when the lightest is lent
    // from home); it is never the one ringed
    const home = { c: [], share: 0, lentTrips: 0, trap: -1 };
    const lent = info.reduce((t, x) => t + x.lentTrips, 0);
    (info.find((x) => x.c.includes(gObj)) || home).share += lent;
    let worst = null;
    if (Array.isArray(trades) && trades.length) {
      const all = info.concat([home]), loopOf = new Array(G.n).fill(all.length - 1);
      info.forEach((x, i) => x.c.forEach((o) => { loopOf[o] = i; }));
      const spent = all.map(() => 0), at = G.at.slice();
      for (const [p, q] of trades) { const a = at[p], b = at[q]; spent[loopOf[a]] += G.w[a]; spent[loopOf[b]] += G.w[b]; at[p] = b; at[q] = a; }
      info.forEach((x, i) => { const excess = spent[i] - x.share; if (!worst || excess > worst.excess) worst = { x, excess }; });
    } else {
      info.forEach((x) => { if (!worst || x.trap > worst.x.trap) worst = { x, excess: null }; });
    }
    const x = worst.x;
    return { loop: x.c.slice(), carrier: x.borrowed ? gObj : x.c.find((o) => G.w[o] === x.m), borrowed: x.borrowed, cost: x.share, excess: worst.excess };
  }

  return { rng, generate, cycles, optimum, borrowPays, play, leastPlan, handPlan, clue };
}));
