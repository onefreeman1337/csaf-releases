/**
 * art.js — HALTER. The byre (two rows of stalls facing a straw aisle), the stall signs and door cards, the stable hand,
 * the HUD band and the title art — THE SINGLE SOURCE OF TRUTH for them (the contact sheets, the store captures and the
 * game all require this file). The beasts live in beasts.js; the rules in yard.js.
 *
 * ⛔ PALETTE LAW (wing §0-ART-g): DMG luma is 158 / 144 / 77 / 39 — shade 0 next to shade 3 is the only strong edge.
 *    The straw the beasts stand on is shade 0 with shade-1 texture; everything the player must READ is dark on it or lit
 *    on dark: stall LETTERS are lit on a dark sign, the door CARD (where the beast belongs) is a dark letter on a lit card,
 *    the WEIGHT is a lit digit on a dark badge.
 * ⛔ §0-ART-b: nothing tiles on a fixed period — straw and plank grain are hashed per pixel.
 *
 * Geometry: HUD y 0..23 · top stalls y 24..61 · aisle y 62..105 · bottom stalls y 106..143. Stall i < top sits in the
 * top row left to right, the rest in the bottom row; stall letters run A, B, C... in that order.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.ART = api;
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const LIT = 0, FACE = 1, MID = 2, SHADOW = 3, NONE = 255;
  const W = 160, H = 144, HUD_H = 24;
  const TOP_Y = 24, STALL_H = 38, AISLE_Y = 62, AISLE_H = 44, BOT_Y = 106;
  const LETTERS = 'ABCDEFGHIJKLMNOP';

  function Plane(w, h, fill) { this.w = w; this.h = h; this.px = new Uint8Array(w * h).fill(fill === undefined ? NONE : fill); }
  Plane.prototype.set = function (x, y, s) { if (s === NONE) return; x = Math.round(x); y = Math.round(y); if (x < 0 || y < 0 || x >= this.w || y >= this.h) return; this.px[y * this.w + x] = s; };
  Plane.prototype.get = function (x, y) { return (x < 0 || y < 0 || x >= this.w || y >= this.h) ? NONE : this.px[y * this.w + x]; };
  Plane.prototype.rect = function (x, y, w, h, s) { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) this.set(x + i, y + j, s); };
  Plane.prototype.hline = function (x0, x1, y, s) { for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x++) this.set(x, y, s); };
  Plane.prototype.vline = function (x, y0, y1, s) { for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++) this.set(x, y, s); };

  function hash2(x, y) { let n = (x | 0) * 374761393 + (y | 0) * 668265263; n = Math.imul(n ^ (n >>> 13), 1274126177); return ((n ^ (n >>> 16)) >>> 0) / 4294967296; }

  /** Stall rectangles for a byre of n stalls: [{ i, x, w, top, y0, y1, doorY, signY, feetY, letter }]. */
  function layout(n) {
    const top = Math.ceil(n / 2), bot = n - top, out = [];
    const per = Math.max(top, bot), sw = Math.floor(156 / per), x0 = Math.floor((W - sw * per) / 2);
    for (let i = 0; i < n; i++) {
      const isTop = i < top, k = isTop ? i : i - top, cnt = isTop ? top : bot;
      const rowX0 = x0 + Math.floor((per - cnt) * sw / 2), x = rowX0 + k * sw;
      const y0 = isTop ? TOP_Y : BOT_Y, y1 = y0 + STALL_H - 1;
      out.push({
        i, x, w: sw, top: isTop, y0, y1, letter: LETTERS[i],
        signY: isTop ? y0 + 1 : y1 - 8,              // a 9-row sign against the back wall
        doorY: isTop ? y1 - 7 : y0,                  // an 8-row half door on the aisle side
        feetY: isTop ? y1 - 9 : y1 - 10,             // where the beast's hooves stand
        cx: x + Math.floor(sw / 2),
        doorAisleY: isTop ? AISLE_Y + 3 : AISLE_Y + AISLE_H - 4,   // where the hand stands to reach this door
      });
    }
    return out;
  }

  /* ------------------------------------------------------------------ the straw and the boards */
  function strawPixel(px, py) {
    const h = hash2(px, py * 3 + 5);
    if (h < 0.10) return FACE;                                              // loose stalks
    if ((px + py * 2) % 9 === 0 && hash2(px >> 1, py) < 0.4) return FACE;   // a laid stalk direction
    return LIT;
  }
  function plank(px, py, seed) {                                            // vertical boards with seams, hashed grain
    const seam = (px + (seed & 3)) % 5 === 0;
    if (seam) return SHADOW;
    return hash2(px, py + seed) < 0.10 ? SHADOW : MID;
  }

  /** The static picture of a byre (stalls empty: signs, straw, boards, the aisle). */
  function byrePlane(n, seed) {
    const p = new Plane(W, H, LIT);
    // the aisle: straw on a cobbled floor, two lantern posts
    for (let y = AISLE_Y; y < AISLE_Y + AISLE_H; y++) for (let x = 0; x < W; x++) {
      const cob = ((x + ((y >> 2) % 2) * 3) % 6 === 0 || y % 4 === 0) && hash2(x, y) < 0.5;
      p.set(x, y, cob ? FACE : strawPixel(x + 300, y));
    }
    // the stall rows' outer frame: boards behind the stalls
    for (const y0 of [TOP_Y, BOT_Y]) for (let y = y0; y < y0 + STALL_H; y++) for (let x = 0; x < W; x++) p.set(x, y, plank(x, y, seed));
    for (const s of layout(n)) {
      // straw floor inside the stall
      const fy0 = s.top ? s.y0 + 10 : s.y0 + 8, fy1 = s.top ? s.y1 - 8 : s.y1 - 9;
      for (let y = fy0; y <= fy1; y++) for (let x = s.x + 2; x < s.x + s.w - 1; x++) p.set(x, y, strawPixel(x, y));
      // partition posts
      p.vline(s.x, s.y0, s.y1, SHADOW); p.vline(s.x + 1, s.y0, s.y1, MID); p.vline(s.x + s.w - 1, s.y0, s.y1, SHADOW);
      // the half door: lit top rail, boards, dark bottom edge
      for (let y = s.doorY; y < s.doorY + 8; y++) for (let x = s.x + 1; x < s.x + s.w - 1; x++) p.set(x, y, plank(x, y, seed + 7) === SHADOW ? SHADOW : MID);
      const rail = s.top ? s.doorY : s.doorY + 7;
      p.hline(s.x + 1, s.x + s.w - 2, rail, LIT); p.hline(s.x + 1, s.x + s.w - 2, s.top ? s.doorY + 7 : s.doorY, SHADOW);
      // the sign on the back wall: dark plaque with the stall's letter (drawn by the game with the font)
      p.rect(s.cx - 5, s.signY, 11, 9, SHADOW); p.hline(s.cx - 5, s.cx + 5, s.top ? s.signY + 9 : s.signY - 1, MID);
    }
    // the far ends of the aisle: open doors to the night yard
    for (const ex of [0, W - 3]) { p.rect(ex, AISLE_Y + 8, 3, AISLE_H - 16, SHADOW); }
    return p;
  }

  /* ------------------------------------------------------------------ the stable hand */
  // 9 wide x 13 tall, faces RIGHT: a flat cap, lit face, dark coat, a rope coiled at the hip.
  // 3 dark · 0 lit · 2 mid · 1 face · . nothing
  const HAND = [
    '..3333...',
    '.333333..',
    '..3333333',
    '..3000...',
    '..3003...',
    '...33....',
    '..3333...',
    '.333333..',
    '.3333320.',
    '.3.333.2.',
    '...333...',
    '..33.33..',
    '..3...3..',
  ];
  const HAND_STEP = ['..33.3...', '..3..33..'];
  /** Draw the hand with feet at (X, Yfeet) (X = left edge). face +1 right / -1 left; `walk` 0/1/2 frame; a LIT halo
   *  so the dark coat reads on the shade-1 cobbles. */
  function drawHand(p, X, Yf, face, walk) {
    X = Math.round(X); const Y = Math.round(Yf) - HAND.length + 1, f = face < 0 ? -1 : 1, WW = HAND[0].length;
    const rows = HAND.slice(); if (walk) { rows[11] = HAND_STEP[walk - 1]; rows[12] = '.........'; }
    const col = (i) => f > 0 ? X + i : X + WW - 1 - i;
    for (let j = 0; j < rows.length; j++) for (let i = 0; i < WW; i++) if (rows[j][i] !== '.') for (const [dx, dy] of [[1, 0], [-1, 0], [0, -1], [0, 1]]) {
      const ni = i + dx, nj = j + dy; if (ni < 0 || nj < 0 || ni >= WW || nj >= rows.length || rows[nj][ni] === '.') p.set(col(ni), Y + nj, LIT);
    }
    for (let j = 0; j < rows.length; j++) for (let i = 0; i < WW; i++) {
      const ch = rows[j][i]; if (ch === '.') continue;
      p.set(col(i), Y + j, ch === '3' ? SHADOW : ch === '0' ? LIT : ch === '1' ? FACE : MID);
    }
  }

  /** A rope from the hand's hip to the led beast's head: a sagging dotted line in shade 2. */
  function drawRope(p, x0, y0, x1, y1) {
    const n = Math.max(2, Math.ceil(Math.hypot(x1 - x0, y1 - y0)));
    for (let k = 0; k <= n; k++) { const t = k / n, sag = Math.sin(t * Math.PI) * Math.min(5, n / 6); p.set(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t + sag, MID); }
  }

  /** The HUD band: dark rafters with a lit rule under it. */
  function hudBand(p) {
    p.rect(0, 0, W, HUD_H, SHADOW);
    // ⛔ REVIEW 2026-10-03 #14: full-height rafter lines every 20 px cut HUD words ("EFF|ORT"). Rafter ENDS only now:
    //    two-pixel stubs above the first text row and below the second, where no glyph ever lands.
    for (let x = 0; x < W; x += 20) { p.vline(x, 0, 1, MID); p.vline(x, HUD_H - 4, HUD_H - 3, MID); }
    p.hline(0, W - 1, HUD_H - 2, MID); p.hline(0, W - 1, HUD_H - 1, LIT);
  }

  /* ============================================================================ THE TITLE ART
   * Baked to art/title.png by Internal_Ops/build_art.js and drawn with drawImage (never read back, so it works on the
   * paid build's file:// origin). A barn at night under a big moon, its doors open and lantern-lit, a hand in the
   * doorway leading a hen, an ox and a horse looking out over their half doors, the title in a dark band at the top. */
  function titlePlane(font, B) {
    const p = new Plane(W, H, MID);
    // night sky with stars and a moon
    for (let s = 0; s < 26; s++) { const sx = Math.floor(hash2(s, 77) * W), sy = 26 + Math.floor(hash2(77, s) * 40); p.set(sx, sy, LIT); if (s % 6 === 0) { p.set(sx - 1, sy, FACE); p.set(sx + 1, sy, FACE); } }
    const mx = 128, my = 44, mr = 15;
    for (let j = -mr; j <= mr; j++) for (let i = -mr; i <= mr; i++) if (i * i + j * j <= mr * mr) p.set(mx + i, my + j, LIT);
    for (const [cx, cy, r] of [[-5, -4, 3], [4, 4, 4], [-2, 8, 2]]) for (let j = -r; j <= r; j++) for (let i = -r; i <= r; i++) if (i * i + j * j <= r * r) p.set(mx + cx + i, my + cy + j, FACE);
    // the ground: a lit yard of straw from y 112 down
    for (let y = 112; y < H; y++) for (let x = 0; x < W; x++) p.set(x, y, strawPixel(x, y));
    // the barn: a gambrel roof and plank walls from x 20 to 140
    const bx0 = 18, bx1 = 141, wallTop = 70, ground = 112;
    for (let y = wallTop; y < ground; y++) for (let x = bx0; x <= bx1; x++) p.set(x, y, plank(x, y, 3) === SHADOW ? SHADOW : MID);
    for (let y = 40; y < wallTop; y++) {
      const t = (y - 40) / (wallTop - 40), half = y < 54 ? 22 + (y - 40) * 2.4 : 55 + (y - 54) * 0.5;
      // ⛔ TITLE ROUND 1 (LOOKED AT 01_title at 3x): lit specks hashed over the whole roof read as TV STATIC. The roof is
      // shingle courses now: a dark line every third row, staggered dark joints, no lit pixel anywhere on it.
      for (let x = Math.round(80 - half); x <= Math.round(80 + half); x++) { const edge = x === Math.round(80 - half) || x === Math.round(80 + half); const joint = (x + ((Math.floor(y / 3) % 2) * 3)) % 6 === 0 && y % 3 !== 0; p.set(x, y, edge || y % 3 === 0 || joint ? SHADOW : MID); }
      void t;
    }
    p.hline(bx0 - 3, bx1 + 3, wallTop, SHADOW); p.hline(bx0 - 3, bx1 + 3, wallTop + 1, LIT);
    // the hay loft door, lit from inside
    p.rect(72, 50, 17, 14, SHADOW); p.rect(74, 52, 13, 11, FACE); for (let i = 0; i < 6; i++) p.set(75 + i * 2, 61 - (i % 2), MID);
    // the big doors: open, lantern light spilling out
    p.rect(62, 80, 37, 32, SHADOW);
    for (let y = 82; y < 112; y++) for (let x = 64; x < 97; x++) p.set(x, y, (y > 100 || hash2(x, y) < 0.08) ? FACE : LIT);
    p.vline(61, 80, 111, LIT); p.vline(99, 80, 111, LIT);
    // the lantern on its hook
    p.rect(78, 83, 5, 6, SHADOW); p.rect(79, 84, 3, 4, LIT); p.vline(80, 81, 82, SHADOW);
    // half doors either side with beasts looking out
    // ⛔ TITLE ROUND 1: a beast with a dark outline over a DARK opening read as a pale lump. The stall behind each half
    // door is lantern-lit (shade 1) so the outline reads (§0-ART-g: 3 next to 1 is a strong edge).
    const halfDoor = (x, w) => { p.rect(x, 86, w, 26, SHADOW); p.rect(x + 2, 88, w - 4, 11, FACE); for (let y = 99; y < 112; y++) for (let xx = x + 1; xx < x + w - 1; xx++) p.set(xx, y, plank(xx, y, 9) === SHADOW ? SHADOW : MID); p.hline(x + 1, x + w - 2, 99, LIT); };
    halfDoor(24, 30); halfDoor(106, 30);
    if (B) {
      const ox = { w: 9, species: 'ox', word: 'OX', coat: 'pale', mark: 'blaze', name: '', horn: 1, patchSeed: 5, tail: true };
      const horse = { w: 8, species: 'horse', word: 'HORSE', coat: 'white', mark: 'socks', name: '', horn: 1, patchSeed: 9, tail: true };
      const hen = { w: 1, species: 'hen', word: 'HEN', coat: 'white', mark: 'plain', name: '', horn: 1, patchSeed: 2, tail: true };
      B.drawBeast(p, 30, 103, ox, 1, 0, false);
      B.drawBeast(p, 113, 103, horse, -1, 0, false);
      // the hand in the doorway with a hen on a rope beside her
      drawHand(p, 70, 110, 1, 0);
      B.drawBeast(p, 85, 110, hen, 1, 0, false);
      drawRope(p, 77, 103, 87, 103);
    }
    if (font) {
      p.rect(0, 2, W, 20, SHADOW); p.hline(0, W - 1, 1, MID); p.hline(0, W - 1, 22, MID);
      font.textPlane(p, 'HALTER', W / 2, 6, { align: 'center', face: 'display', shade: LIT });
    }
    return p;
  }

  return { LIT, FACE, MID, SHADOW, NONE, W, H, HUD_H, TOP_Y, STALL_H, AISLE_Y, AISLE_H, BOT_Y, LETTERS, Plane, hash2, layout, strawPixel, plank, byrePlane, drawHand, drawRope, hudBand, titlePlane };
}));
