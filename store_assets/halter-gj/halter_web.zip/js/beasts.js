/**
 * beasts.js — HALTER. Every beast in a byre is GENERATED: a species from the WEIGHT LADDER (the bigger the beast, the
 * heavier the trade), a coat, markings, horns or ears, and a name. THE SINGLE SOURCE OF TRUTH for the sprite the game
 * draws, the contact sheet and the store captures.
 *
 * ⛔ wing §0-ART-f: the volume must be a property of the ENTITY and live in what the player READS. Here the player reads
 *    WEIGHT off the picture: a hen is a small thing at the bottom of the ladder, an ox fills the stall. Within a species
 *    every beast is its own animal (coat x marking x horns/ears x name), forced distinct within a byre.
 * ⛔ PALETTE LAW (§0-ART-g): shade 0 next to shade 1 is worth nothing. The stall straw is shade 0/1, so every beast
 *    carries a dark (shade 3) outline; a dark-coated beast reads by its outline plus a lit eye and lit highlights.
 *
 * Species templates face RIGHT, drawn on a box `w x h`, feet on the bottom row:
 *   '#' outline (always dark) · ':' coat · 'e' eye · 'h' horn/beak (lit) · 'm' mane/comb/wattle (dark) · '.' nothing
 */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.BEASTS = api;
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const LIT = 0, FACE = 1, MID = 2, SHADOW = 3, NONE = 255;
  function hash2(x, y) { let n = (x | 0) * 374761393 + (y | 0) * 668265263; n = Math.imul(n ^ (n >>> 13), 1274126177); return ((n ^ (n >>> 16)) >>> 0) / 4294967296; }

  // the ladder: weight 1..9
  const SPECIES = [
    null,
    // ⛔ ART ROUND 1 (LOOKED AT art/ladder_6x.png): a round body with a dot of comb read as an EGG ON LEGS. Now: a cocked
    // tail fan at the back, a comb and wattle, a beak past the face, and the head up off the body.
    { id: 'hen', word: 'HEN', rows: [
      '.....mm..',
      '....#mm#.',
      '....#e:#h',
      '#...#::#m',
      '##..#::#.',
      '#:###::#.',
      '#::::::#.',
      '.#::::#..',
      '..####...',
      '...#.#...',
    ] },
    { id: 'goose', word: 'GOOSE', rows: [
      '.......##.',
      '......#:e#h',
      '......#::#.',
      '......#:#..',
      '.....#::#..',
      '.#####::#..',
      '#:::::::#..',
      '#::::::#...',
      '.######....',
      '...#.#.....',
      '..##.##....',
    ] },
    // ART ROUND 1: lit horns on lit straw were invisible (§0-ART-g). Horns are a dark arc swept back over the head now,
    // a beard under the chin, and a short tail cocked up.
    { id: 'goat', word: 'GOAT', rows: [
      '.......##...',
      '......#..#..',
      '.......##:#.',
      '.#.....#:e:#',
      '#:######::#.',
      '#::::::::#m.',
      '#::::::::#m.',
      '#::::::::#..',
      '.########...',
      '.#.#..#.#...',
      '.#.#..#.#...',
      '.#.#..#.#...',
    ] },
    { id: 'sheep', word: 'SHEEP', rows: [
      '..##.##.##...',
      '.#::#::#::#..',
      '#:::::::::##.',
      '#::::::::#:e#',
      '#::::::::#::#',
      '#::::::::##.#',
      '.#::::::::#..',
      '..##.##.##...',
      '...#.#.#.#...',
      '...#.#.#.#...',
      '...#.#.#.#...',
    ] },
    { id: 'pig', word: 'PIG', rows: [
      '.........##...',
      '..#####.#:#...',
      '.#:::::##:##..',
      '#::::::::::e#.',
      '#:::::::::::##',
      '#:::::::::::h#',
      '#:::::::::::##',
      '.#:::::::::#..',
      '..##########..',
      '..##.#..#.##..',
    ] },
    { id: 'donkey', word: 'DONKEY', rows: [
      '..........#.#.',
      '..........#:#:',
      '.........#:::#',
      '........#::e:#',
      '.......#m:::::#',
      '.......#m#:::##',
      '.#######m#.##..',
      '#:::::::::#....',
      '#:::::::::#....',
      '#:::::::::#....',
      '.#########.....',
      '.#.#...#.#.....',
      '.#.#...#.#.....',
      '.##.#..##.#....',
    ] },
    // ⛔ REVIEW 2026-10-03 #9: curled horns over a small head read as a RAM. A cow is told by level ears either side of
    // the poll (and the udder under the belly), so the head carries ears now, not horns.
    { id: 'cow', word: 'COW', rows: [
      '................',
      '.........hh#::#h',
      '..........#::#..',
      '..........#:e:##',
      '.##########::::#',
      '#::::::::::#::##',
      '#::::::::::###..',
      '#:::::::::::#...',
      '#:::::::::::#...',
      '.#####m#####....',
      '..#.#...#.#.....',
      '..#.#...#.#.....',
      '..##.#..##.#....',
    ] },
    { id: 'horse', word: 'HORSE', rows: [
      '...........#.#..',
      '..........#:#:..',
      '.........#m:::#.',
      '........#m::e:#.',
      '.......#m::::::#',
      '.......#m:###::#',
      '.#######m:#..##.',
      '#:::::::::#.....',
      '#:::::::::#.....',
      '#:::::::::#.....',
      'm#########......',
      'm.#.#..#.#......',
      '..#.#..#.#......',
      '..#.#..#.#......',
      '..##.#.##.#.....',
    ] },
    // ART ROUND 1: the ox read as a BOX with lit horns nobody could see. Now: a shoulder hump, and long horns drawn as a
    // dark-outlined sweep forward and up past the face.
    // ⛔ REVIEW 2026-10-03 #9: a dark-outlined horn blob on top of the head read as a ROOSTER'S COMB; the one thin spike
    // that replaced it read as a UNICORN or a rhino (round 2). An ox carries a PAIR: two dark horns rising in a V off the
    // poll of a big head that hangs at the front below the hump.
    { id: 'ox', word: 'OX', rows: [
      '.................',
      '.........#...#...',
      '..........#.#....',
      '...##.....###....',
      '..#::#####:::#...',
      '.#::::::::#:::#..',
      '#:::::::::#::e:#.',
      '#:::::::::#:::::#',
      '#::::::::::#:::##',
      '#:::::::::::###..',
      '.###########m....',
      '.##.#....##.#....',
      '.##.#....##.#....',
      '.###.#...###.#...',
    ] },
  ];
  const WORD = SPECIES.map((s) => s && s.word);

  const COATS = ['white', 'pale', 'brown', 'dark'];
  const COAT_SHADE = { white: LIT, pale: FACE, brown: MID, dark: SHADOW };
  const MARKS = ['plain', 'patched', 'belted', 'blaze', 'socks', 'speckled'];
  // hen, sheep. A lit head, lit patches or lit socks on a dark 9 px hen vanished into the lit straw and left a
  // hook-shaped body (LOOKED AT, rounds 2 and 3), so a hen wears a whole coat or a fine speckle only.
  // A speckled fleece on legs read as a small TREE at 1x (herds_4x, round 3), so a sheep wears no speckle either.
  const MARKS_FOR = { 1: ['plain', 'speckled'], 4: ['plain', 'blaze', 'socks'] };

  const NAMES = ('BRAMBLE CLOVER DAISY HAZEL MAPLE BARLEY TANSY SORREL PIP NUTMEG BUTTER BISCUIT MOSS FERN ROWAN ' +
    'BRACKEN THISTLE NETTLE DOCK SEDGE HEATHER BRACKET TEASEL MALLOW CAMPION BETONY YARROW RUSH REED WILLOW ' +
    'ALDER ASPEN ELM ASH OAK HOLLY IVY HOPS MEADOW BRAN OATS RYE SPELT MALT WHEY CURD CREAM SCONE CRUMPET ' +
    'DUMPLING PUDDING TOFFEE TREACLE HONEY BEE WREN ROBIN FINCH LARK OWL BADGER OTTER STOAT HARE BOBBIN ' +
    'BUTTON THIMBLE TWIG ACORN CONKER PEBBLE FLINT CHALK CLAY SLATE SOOT EMBER CINDER SMUDGE DOT PATCH ' +
    'SOCKS BOOTS BELLE BETTY MABEL MAUD NELL PEG POLLY ROSIE SAL TESS VI WINNIE ALF BERT CLEM DUKE ED ' +
    'FRED GUS HAL JED KIP LEN MONTY NED OTTO PERCY RUFUS SID TOBY WAL BRUNO BARNABY BLOSSOM PRIMROSE SNOWDROP ' +
    'BLUEBELL BUTTERCUP COWSLIP DANDELION FOXGLOVE HONESTY LUPIN POPPY ROSEMARY SAGE THYME BASIL MINT')
    .split(/\s+/).filter((n) => n && n.length <= 6);   // <= 6 letters: a name fits a 37 px herd-book slot at 6 px a glyph

  /** The herd of one byre: `w` = weights (1..9), `seed` the yard's seed. Deterministic, its own hash. */
  function herd(seed, w) {
    const looks = new Set(), names = new Set(), out = [];
    for (let i = 0; i < w.length; i++) {
      const h = (n) => hash2(seed * 911 + i * 37 + n * 13, seed * 17 + n * 131 + i * 3);
      // ⛔ REVIEW 2026-10-03 #9: a SPLIT coat (belted, or big patches) on a round fleece read as a BUTTERFLY, and a belted
      //    hen as a hook glyph. Those species draw only from the marks that keep their silhouette whole.
      const MK = MARKS_FOR[w[i]] || MARKS;
      let coat = Math.floor(h(1) * COATS.length), mi = Math.floor(h(2) * MK.length), guard = 0;
      // ⛔ distinct within a byre on (species, coat, mark): two goats never look the same
      while (looks.has(w[i] + ':' + coat + ':' + MK[mi]) && guard++ < 40) { mi = (mi + 1) % MK.length; if (guard % MK.length === 0) coat = (coat + 1) % COATS.length; }
      const mark = MARKS.indexOf(MK[mi]);
      looks.add(w[i] + ':' + coat + ':' + MK[mi]);
      let ni = Math.floor(h(3) * NAMES.length), g2 = 0;
      while (names.has(NAMES[ni]) && g2++ < NAMES.length) ni = (ni + 1) % NAMES.length;
      names.add(NAMES[ni]);
      out.push({ w: w[i], species: SPECIES[w[i]].id, word: WORD[w[i]], coat: COATS[coat], mark: MARKS[mark], name: NAMES[ni],
        horn: h(4) < 0.5 ? 0 : 1, patchSeed: Math.floor(h(5) * 1e6), tail: h(6) < 0.5 });
    }
    return out;
  }

  function size(b) { const R = SPECIES[b.w].rows; return { w: R[0].length, h: R.length }; }

  /** The coat at template pixel (i, j) of a w x h box: base shade plus a marking — each a SHAPE, never a texture. */
  function coatAt(b, i, j, W, H) {
    const base = COAT_SHADE[b.coat];
    const alt = b.coat === 'white' || b.coat === 'pale' ? (b.coat === 'white' ? MID : SHADOW) : (b.coat === 'dark' ? LIT : LIT);
    switch (b.mark) {
      case 'patched': { // two or three soft blobs placed by the beast's own seed
        for (let k = 0; k < 3; k++) {
          const px = Math.floor(hash2(b.patchSeed, k) * W), py = Math.floor(hash2(k, b.patchSeed) * H * 0.6), r = 1.6 + hash2(b.patchSeed + k, 9) * 1.6;
          if ((i - px) * (i - px) + (j - py) * (j - py) <= r * r) return alt;
        }
        return base;
      }
      case 'belted': { const mid = Math.floor(W * 0.42); return (i >= mid && i <= mid + 2) ? alt : base; }
      // a pale or dark head. ⛔ REVIEW 2026-10-03 #9: W - 6 covered half a 9-13 px hen or sheep and split it in two;
      // the marking is scaled to the beast so it stays on the head.
      case 'blaze': return (i >= W - Math.max(4, Math.round(W * 0.3)) && j <= H * 0.5) ? alt : base;
      case 'socks': return (j >= H - 5) ? alt : base;                          // the legs and belly line
      case 'speckled': return ((i * 3 + j * 5 + (b.patchSeed & 7)) % 7 === 0) ? alt : base;
      default: return base;
    }
  }

  /** Draw beast `b` with its box's bottom-left at (X, Ybottom). face +1 right / -1 left. `step` lifts alternate legs
   *  (walking); `ghost` draws a dotted outline only (the lesson). */
  function drawBeast(p, X, Yb, b, face, step, ghost, sc) {
    sc = sc || 1;
    if (sc > 1) {   // drawn at sc x sc per pixel (the result card's plate): render 1x into a buffer, then blow it up
      const sz = size(b), buf = { px: new Uint8Array((sz.w + 2) * (sz.h + 2)).fill(NONE), set(x, y, s) { if (s === NONE || x < 0 || y < 0 || x >= sz.w + 2 || y >= sz.h + 2) return; this.px[y * (sz.w + 2) + x] = s; } };
      drawBeast(buf, 1, sz.h, b, face, step, ghost, 1);
      for (let j = 0; j < sz.h + 2; j++) for (let i = 0; i < sz.w + 2; i++) { const s = buf.px[j * (sz.w + 2) + i]; if (s !== NONE) for (let a = 0; a < sc; a++) for (let c = 0; c < sc; c++) p.set(Math.round(X) + (i - 1) * sc + c, Math.round(Yb) - (sz.h - j) * sc + a + 1 - sc + sc, s); }
      return;
    }
    const R = SPECIES[b.w].rows, W = R[0].length, H = R.length, Y = Math.round(Yb) - H + 1;
    X = Math.round(X);
    const col = (i) => face < 0 ? X + W - 1 - i : X + i;
    const dark = b.coat === 'dark' || b.coat === 'brown';
    for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
      const c = R[j][i]; if (c === '.') continue;
      let y = Y + j;
      // walking: lift every other leg column by 1 px on the bottom two rows
      if (step && j >= H - 2 && (i % 4 < 2) === (step === 1)) y -= 1;
      const x = col(i);
      if (ghost) { if (c === '#' && (x + y) % 2 === 0) p.set(x, y, SHADOW); continue; }
      if (c === '#') { p.set(x, y, SHADOW); continue; }
      if (c === 'e') { p.set(x, y, dark ? LIT : SHADOW); continue; }
      // ⛔ ART ROUND 1: horn/beak was LIT and vanished on the lit straw (§0-ART-g); it is shade 2 on every beast now
      if (c === 'h') { if (b.species === 'cow' && b.horn === 0 && j === 0) continue; p.set(x, y, MID); continue; }
      if (c === 'm') { p.set(x, y, dark ? FACE : SHADOW); continue; }
      p.set(x, y, coatAt(b, i, j, W, H));
    }
  }

  /** A small portrait for the herd book: the beast centred in a box of `bw` x `bh` on background `bg`. */
  function drawInBox(p, X, Y, bw, bh, b, bg) {
    if (bg !== undefined) for (let j = 0; j < bh; j++) for (let i = 0; i < bw; i++) p.set(X + i, Y + j, bg);
    const s = size(b);
    drawBeast(p, X + Math.floor((bw - s.w) / 2), Y + bh - 2, b, 1, 0, false);
  }

  return { SPECIES, WORD, COATS, MARKS, MARKS_FOR, NAMES, herd, size, drawBeast, drawInBox, hash2 };
}));
