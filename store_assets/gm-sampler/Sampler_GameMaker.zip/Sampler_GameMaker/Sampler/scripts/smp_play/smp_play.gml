/// smp_play.gml - the Sampler screen: the player fills a chart from its number clues, stitch by stitch; when it is right
/// the threads go in from the centre out and the finished sampler is set in its hoop with an engraved plaque.
///
/// Sampler - Picross Stitched Into an Embroidery Hoop, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// PUBLIC
///   smp_play_create([opts])            -> a screen. opts {seed, size, form, palette, title, work, done, number}
///                                          work/done: what smp_play_save returned last time (the stitches are kept)
///   smp_play_step(screen, [input])      -> the mode: "play", "reveal", "done" (finished, showing the hoop) or "left"
///   smp_play_draw(screen, x, y, w, h)   -> draw the screen fitted into a rectangle (letterboxed, 816 x 624 inside)
///   smp_play_input()                    -> this frame's keyboard and mouse as an input struct (mouse in GUI space)
///   smp_play_save(screen)               -> {done, work}: store it with your save file, pass it back to smp_play_create
///   smp_play_free(screen)               -> free its surfaces (call it in Clean Up)
/// Controls: arrows move the needle, Enter/Space stitch or unpick, Shift marks a cell empty, Escape leaves (the work is
/// kept). Mouse: click to stitch, drag to stitch a line, right-click marks empty (right-click outside the chart leaves).
/// ⛔ Every layer is cached on its own surface and repainted only when it changes; surfaces are volatile, so each is
/// re-created and repainted when GameMaker drops it.

#macro SMP_PW 816
#macro SMP_PH 624

/// @function smp_k_font_px(font)
/// @description The pixel size a font resource was rasterised at (its "H" height for a font this file does not know).
function smp_k_font_px(_font) {
    if (_font == fnt_sampler_display) return 120;
    if (_font == fnt_sampler_title) return 56;
    if (_font == fnt_sampler) return 26;
    if (_font == fnt_sampler_ui) return 17;
    var _prev = draw_get_font();
    draw_set_font(_font);
    var _h = string_height("H");
    draw_set_font(_prev);
    return max(1, _h);
}

/// @function smp_k_text(x, y, string, px, colour, [halign], [valign], [font], [alpha])
/// @description Draw type `px` pixels tall (large serif from the bigger atlas). Returns the drawn width. Texture filtering
/// is on for the draw and restored after: a scaled atlas with point sampling drops one-pixel strokes.
function smp_k_text(_x, _y, _s, _px, _col, _ha = fa_left, _va = fa_top, _font = fnt_sampler, _alpha = 1) {
    _s = string(_s);
    if (_font == fnt_sampler && _px > 38) _font = fnt_sampler_title;
    var _pf = draw_get_font(), _ph = draw_get_halign(), _pv = draw_get_valign(), _pa = draw_get_alpha(), _pc = draw_get_colour(), _pt = gpu_get_texfilter();
    draw_set_font(_font);
    var _sc = _px / smp_k_font_px(_font), _w = string_width(_s) * _sc;
    draw_set_halign(_ha); draw_set_valign(_va); draw_set_colour(_col); draw_set_alpha(_alpha * _pa);
    gpu_set_texfilter(true);
    draw_text_transformed(_x, _y, _s, _sc, _sc, 0);
    gpu_set_texfilter(_pt);
    draw_set_font(_pf); draw_set_halign(_ph); draw_set_valign(_pv); draw_set_alpha(_pa); draw_set_colour(_pc);
    return _w;
}

/// @function smp_k_text_w(string, px, [font])
function smp_k_text_w(_s, _px, _font = fnt_sampler) {
    if (_font == fnt_sampler && _px > 38) _font = fnt_sampler_title;
    var _pf = draw_get_font();
    draw_set_font(_font);
    var _w = string_width(string(_s)) * _px / smp_k_font_px(_font);
    draw_set_font(_pf);
    return _w;
}

/// @function smp__rrect(x, y, w, h, r, colour_top, colour_bottom)
/// @description A filled rounded rectangle shaded top to bottom. Internal.
function smp__rrect(_x, _y, _w, _h, _r, _c0, _c1) {
    _r = max(0, min(_r, _w / 2, _h / 2));
    draw_rectangle_colour(_x + _r, _y, _x + _w - _r, _y + _h, _c0, _c0, _c1, _c1, false);
    draw_rectangle_colour(_x, _y + _r, _x + _r, _y + _h - _r, merge_colour(_c0, _c1, _r / _h), merge_colour(_c0, _c1, _r / _h), merge_colour(_c0, _c1, 1 - _r / _h), merge_colour(_c0, _c1, 1 - _r / _h), false);
    draw_rectangle_colour(_x + _w - _r, _y + _r, _x + _w, _y + _h - _r, merge_colour(_c0, _c1, _r / _h), merge_colour(_c0, _c1, _r / _h), merge_colour(_c0, _c1, 1 - _r / _h), merge_colour(_c0, _c1, 1 - _r / _h), false);
    var _ct = merge_colour(_c0, _c1, _r / _h), _cb = merge_colour(_c0, _c1, 1 - _r / _h);
    draw_circle_colour(_x + _r, _y + _r, _r, _ct, _ct, false); draw_circle_colour(_x + _w - _r, _y + _r, _r, _ct, _ct, false);
    draw_circle_colour(_x + _r, _y + _h - _r, _r, _cb, _cb, false); draw_circle_colour(_x + _w - _r, _y + _h - _r, _r, _cb, _cb, false);
}

/// @function smp_draw_spool(x, y, hex, scale)
/// @description A thread spool seen from the side: a shadow, two wooden flanges and the wound thread, lit across.
function smp_draw_spool(_x, _y, _hex, _k) {
    if (!smp__nums([_x, _y, _k]) || _k <= 0) return;
    smp__over_begin();
    var _a0 = draw_get_alpha();
    draw_set_alpha(0.35 * _a0); draw_set_colour(c_black);
    draw_ellipse(_x + (3 - 24) * _k, _y + (30 - 6) * _k, _x + (3 + 24) * _k, _y + (30 + 6) * _k, false);
    draw_set_alpha(_a0);
    var _wood = smp_hex("#a8804a");
    smp__rrect(_x - 22 * _k, _y - 30 * _k, 44 * _k, 8 * _k, 3 * _k, merge_colour(_wood, c_white, 0.15), _wood);
    smp__rrect(_x - 22 * _k, _y + 22 * _k, 44 * _k, 8 * _k, 3 * _k, merge_colour(_wood, c_white, 0.15), _wood);
    var _c0 = smp_shade(_hex, -0.35), _c1 = smp_shade(_hex, 0.25), _c2 = smp_shade(_hex, -0.45);
    draw_rectangle_colour(_x - 18 * _k, _y - 22 * _k, _x + (-18 + 36 * 0.45) * _k, _y + 22 * _k, _c0, _c1, _c1, _c0, false);
    draw_rectangle_colour(_x + (-18 + 36 * 0.45) * _k, _y - 22 * _k, _x + 18 * _k, _y + 22 * _k, _c1, _c2, _c2, _c1, false);
    var _wl = smp_shade(_hex, -0.25);
    for (var _q = -20; _q < 22; _q += 3) draw_line_width_colour(_x - 18 * _k, _y + _q * _k, _x + 18 * _k, _y + (_q + 1.5) * _k, 0.8 * _k, _wl, _wl);
    smp__over_end();
}

/// @function smp_play_create([opts])
/// @description A Sampler screen for one puzzle (see the file header for opts). Build it in Create; step it in Step.
function smp_play_create(_o = undefined) {
    var _g = function(_s, _k, _d) { return (is_struct(_s) && variable_struct_exists(_s, _k) && !is_undefined(_s[$ _k])) ? _s[$ _k] : _d; };
    // a text seed (a place name, a quest id) is hashed, so the same text is always the same puzzle
    var _sd = _g(_o, "seed", 1);
    if (is_string(_sd)) _sd = smp_hash(_sd);
    var _p = smp_generate({ seed: _sd, size: _g(_o, "size", 10), form: _g(_o, "form", undefined), palette: _g(_o, "palette", undefined) });
    var _nb = _g(_o, "number", 1);
    var _pal = smp_palette(_p.palette), _n = _p.n, _i;
    static _names = { star: "Star", medallion: "Medallion", lattice: "Lattice", diamond: "Diamond" };
    var _title = _g(_o, "title", "");
    if (!is_string(_title) || _title == "") _title = "The " + _pal.name + " " + _names[$ _p.form];
    var _st = { p: _p, pal: _pal, work: smp_work_threads(_pal.threads), title: _title, number: is_numeric(_nb) ? max(1, floor(_nb)) : 1,
        grid: array_create(_n * _n, 0), locked: array_create(_n * _n, false), cx: floor(_n / 2), cy: floor(_n / 2),
        mode: "play", frame: 0, drag: undefined, rowDone: array_create(_n, false), colDone: array_create(_n, false), linesDone: 0,
        revealOrder: [], revealAt: 0, revealFrames: 0, status: "Stitch each row to its numbers.", L: undefined,
        surf: { board: -1, clues: -1, stitches: -1, card: -1, finished: -1, frame: -1 }, dirty: { board: true, clues: true, stitches: true, card: true, finished: true },
        rect: [0, 0, SMP_PW, SMP_PH], result: "", done: false };
    for (_i = 0; _i < array_length(_p.givens); _i++) { var _gv = _p.givens[_i]; _st.grid[_gv.i] = _gv.v ? 1 : 2; _st.locked[_gv.i] = true; }
    var _w = _g(_o, "work", "");
    if (is_string(_w) && string_length(_w) == _n * _n) for (_i = 0; _i < _n * _n; _i++) {
        if (_st.locked[_i]) continue;
        var _ch = string_char_at(_w, _i + 1);
        _st.grid[_i] = (_ch == "1") ? 1 : ((_ch == "2") ? 2 : 0);
    }
    smp__play_layout(_st);
    smp__play_lines(_st);
    if (_g(_o, "done", false) == true) { _st.done = true; for (_i = 0; _i < _n * _n; _i++) _st.grid[_i] = _p.cells[_i]; smp__play_lines(_st); _st.mode = "done"; _st.status = "The sampler is finished."; }
    return _st;
}

/// @function smp__play_layout(screen)
/// @description Cell size and clue margins from the chart size and the longest clue lists (the MZ scene's layout). Internal.
function smp__play_layout(_st) {
    var _p = _st.p, _n = _p.n, _ax = 24, _ay = 24, _aw = 520, _ah = 576, _mr = 0, _mc = 0;
    for (var _i = 0; _i < _n; _i++) { _mr = max(_mr, array_length(_p.clues.rows[_i])); _mc = max(_mc, array_length(_p.clues.cols[_i])); }
    var _s = floor(min((_aw - 30) / (_n + _mr * 0.95 + 0.6), (_ah - 30) / (_n + _mc * 0.8 + 0.6)));
    _s = max(16, min(56, _s));
    var _fs = max(10, min(18, floor(_s * 0.58)));
    var _left = ceil(_mr * (_fs * 0.95 + 4) + 22), _top = ceil(_mc * (_fs + 3) + 18);
    var _gw = _left + _n * _s, _gh = _top + _n * _s;
    _st.L = { s: _s, n: _n, fs: _fs, left: _left, top: _top, x: _ax + floor((_aw - _gw) / 2) + _left, y: _ay + floor((_ah - _gh) / 2) + _top };
}

/// @function smp__play_line(screen, is_row, k)
function smp__play_line(_st, _row, _k) { var _n = _st.p.n, _o = array_create(_n); for (var _i = 0; _i < _n; _i++) _o[_i] = _st.grid[_row ? _k * _n + _i : _i * _n + _k]; return _o; }

/// @function smp__play_lines(screen)
/// @description Tick off rows and columns whose stitches match their clue; mark the clue and card layers dirty on change.
function smp__play_lines(_st) {
    var _p = _st.p, _d = 0, _ch = false;
    for (var _k = 0; _k < _p.n; _k++) {
        var _r = smp_line_done(_p.clues.rows[_k], smp__play_line(_st, true, _k));
        var _c = smp_line_done(_p.clues.cols[_k], smp__play_line(_st, false, _k));
        if (_r != _st.rowDone[_k] || _c != _st.colDone[_k]) _ch = true;
        _st.rowDone[_k] = _r; _st.colDone[_k] = _c; _d += (_r ? 1 : 0) + (_c ? 1 : 0);
    }
    if (_d != _st.linesDone) _ch = true;
    _st.linesDone = _d;
    if (_ch) { _st.dirty.clues = true; _st.dirty.card = true; }
}

/// @function smp_play_input()
/// @description This frame's keyboard and mouse (GUI coordinates) as the input struct smp_play_step reads.
function smp_play_input() {
    return { left: keyboard_check_pressed(vk_left), right: keyboard_check_pressed(vk_right), up: keyboard_check_pressed(vk_up), down: keyboard_check_pressed(vk_down),
        ok: keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space), mark: keyboard_check_pressed(vk_shift), cancel: keyboard_check_pressed(vk_escape),
        mx: device_mouse_x_to_gui(0), my: device_mouse_y_to_gui(0), press: mouse_check_button_pressed(mb_left), held: mouse_check_button(mb_left), rpress: mouse_check_button_pressed(mb_right) };
}

/// @function smp__play_cell_at(screen, gx, gy)
/// @description The chart cell under a GUI point (mapped through the last draw rectangle), or -1. Internal.
function smp__play_cell_at(_st, _gx, _gy) {
    var _r = _st.rect, _k = min(_r[2] / SMP_PW, _r[3] / SMP_PH), _ox = _r[0] + (_r[2] - SMP_PW * _k) / 2, _oy = _r[1] + (_r[3] - SMP_PH * _k) / 2;
    var _fx = (_gx - _ox) / _k, _fy = (_gy - _oy) / _k, _L = _st.L;
    var _cx = floor((_fx - _L.x) / _L.s), _cy = floor((_fy - _L.y) / _L.s);
    return (_cx >= 0 && _cy >= 0 && _cx < _L.n && _cy < _L.n) ? _cy * _L.n + _cx : -1;
}

/// @function smp__play_set(screen, i, v)
function smp__play_set(_st, _i, _v) { if (_st.locked[_i] || _st.grid[_i] == _v) return false; _st.grid[_i] = _v; _st.dirty.stitches = true; return true; }

/// @function smp__play_after(screen)
function smp__play_after(_st) { smp__play_lines(_st); if (smp_is_solved(_st.p, _st.grid)) smp__play_finish(_st); }

/// @function smp__play_finish(screen)
/// @description The chart is right: clear the marks and stitch the colours in from the centre out. Internal.
function smp__play_finish(_st) {
    var _p = _st.p, _n = _p.n, _c = (_n - 1) / 2, _order = [], _key = [], _i;
    _st.done = true;
    for (_i = 0; _i < _n * _n; _i++) { if (_st.grid[_i] == 2) _st.grid[_i] = 0; if (_p.cells[_i] != 0) array_push(_order, _i); }
    for (_i = 0; _i < array_length(_order); _i++) { var _q = _order[_i]; _key[_q] = abs((_q mod _n) - _c) + abs(floor(_q / _n) - _c); }
    array_sort(_order, method({ key: _key }, function(_a, _b) { if (key[_a] != key[_b]) return (key[_a] < key[_b]) ? -1 : 1; return (_a < _b) ? -1 : ((_a > _b) ? 1 : 0); }));
    _st.revealOrder = _order; _st.revealAt = 0; _st.revealFrames = 0; _st.mode = "reveal";
    _st.status = "The chart is right. Taking the threads...";
    _st.dirty.stitches = true; _st.dirty.card = true;
}

/// @function smp_play_step(screen, [input])
/// @description Advance one frame; returns the mode ("play", "reveal", "done", "left").
function smp_play_step(_st, _in = undefined) {
    if (!is_struct(_st) || !variable_struct_exists(_st, "mode")) return "left";
    if (!is_struct(_in)) _in = smp_play_input();
    var _gi = function(_s, _k) { return variable_struct_exists(_s, _k) ? _s[$ _k] : false; };
    _st.frame++;
    var _n = _st.p.n;
    if (_st.mode == "play") {
        if (_gi(_in, "left")) _st.cx = (_st.cx + _n - 1) mod _n;
        else if (_gi(_in, "right")) _st.cx = (_st.cx + 1) mod _n;
        else if (_gi(_in, "up")) _st.cy = (_st.cy + _n - 1) mod _n;
        else if (_gi(_in, "down")) _st.cy = (_st.cy + 1) mod _n;
        var _i = _st.cy * _n + _st.cx;
        if (_gi(_in, "ok")) { if (smp__play_set(_st, _i, (_st.grid[_i] == 1) ? 0 : 1)) smp__play_after(_st); return _st.mode; }
        if (_gi(_in, "mark")) { if (smp__play_set(_st, _i, (_st.grid[_i] == 2) ? 0 : 2)) smp__play_after(_st); return _st.mode; }
        if (_gi(_in, "cancel")) { _st.mode = "left"; _st.result = "left"; return _st.mode; }
        var _mx = variable_struct_exists(_in, "mx") ? _in.mx : -1, _my = variable_struct_exists(_in, "my") ? _in.my : -1;
        if (_gi(_in, "rpress")) {
            var _ci = smp__play_cell_at(_st, _mx, _my);
            if (_ci < 0) { _st.mode = "left"; _st.result = "left"; return _st.mode; }
            _st.cx = _ci mod _n; _st.cy = _ci div _n;
            if (smp__play_set(_st, _ci, (_st.grid[_ci] == 2) ? 0 : 2)) smp__play_after(_st);
            return _st.mode;
        }
        if (_gi(_in, "press")) {
            var _t = smp__play_cell_at(_st, _mx, _my);
            if (_t >= 0) {
                _st.cx = _t mod _n; _st.cy = _t div _n; _st.drag = { v: (_st.grid[_t] == 1) ? 0 : 1, last: _t };
                if (smp__play_set(_st, _t, _st.drag.v)) { smp__play_after(_st); if (_st.mode != "play") { _st.drag = undefined; return _st.mode; } }
            }
        }
        if (!is_undefined(_st.drag)) {
            if (!_gi(_in, "held") && !_gi(_in, "press")) _st.drag = undefined;
            else {
                var _c = smp__play_cell_at(_st, _mx, _my);
                if (_c >= 0 && _c != _st.drag.last) { _st.drag.last = _c; _st.cx = _c mod _n; _st.cy = _c div _n; if (smp__play_set(_st, _c, _st.drag.v)) smp__play_after(_st); }
            }
        }
    } else if (_st.mode == "reveal") {
        var _per = max(1, ceil(array_length(_st.revealOrder) / 45));
        if (_st.revealAt < array_length(_st.revealOrder)) { _st.revealAt = min(array_length(_st.revealOrder), _st.revealAt + _per); _st.dirty.stitches = true; }
        else { _st.revealFrames += 1; }
        if (_st.revealAt >= array_length(_st.revealOrder) && _st.revealFrames > 40) { _st.mode = "done"; _st.status = "The sampler is finished."; _st.dirty.finished = true; _st.dirty.card = true; }
    } else if (_st.mode == "done") {
        if (_gi(_in, "ok") || _gi(_in, "cancel") || _gi(_in, "press") || _gi(_in, "rpress")) { _st.mode = "left"; _st.result = "finished"; }
    }
    return _st.mode;
}

/// @function smp_play_save(screen)
/// @description {done, work}: store it and pass it back to smp_play_create to keep the player's stitches.
function smp_play_save(_st) {
    if (!is_struct(_st) || !variable_struct_exists(_st, "grid")) return { done: false, work: "" };
    if (_st.done) return { done: true, work: "" };
    var _w = "";
    for (var _i = 0; _i < array_length(_st.grid); _i++) _w += _st.locked[_i] ? "0" : string(_st.grid[_i]);
    return { done: false, work: _w };
}

/// @function smp__play_surface(screen, name, w, h)
/// @description The named layer's surface, (re)created if GameMaker dropped it (and then marked dirty). Internal.
function smp__play_surface(_st, _name, _w, _h) {
    var _s = _st.surf[$ _name];
    if (!surface_exists(_s)) { _s = surface_create(_w, _h); _st.surf[$ _name] = _s; if (variable_struct_exists(_st.dirty, _name)) _st.dirty[$ _name] = true; }
    return _s;
}

/// @function smp__play_paint(screen)
/// @description Repaint every dirty layer. Internal.
function smp__play_paint(_st) {
    smp__over_begin();
    var _p = _st.p, _L = _st.L, _P = _st.pal.threads, _i, _s;
    _s = smp__play_surface(_st, "board", SMP_PW, SMP_PH);
    if (_st.dirty.board) {
        surface_set_target(_s); draw_clear_alpha(c_black, 0);
        smp_draw_table(SMP_PW, SMP_PH);
        smp_draw_spool(612, 530, _P[0], 1.1); smp_draw_spool(680, 548, _P[1], 1.0); smp_draw_spool(748, 526, _P[2], 0.95);
        draw_set_alpha(0.45); draw_set_colour(c_black);
        draw_rectangle(_L.x - 10 + 4, _L.y - 10 + 6, _L.x - 10 + 4 + _L.n * _L.s + 20, _L.y - 10 + 6 + _L.n * _L.s + 20, false);
        draw_set_alpha(1);
        smp_draw_linen(_L.x - 10, _L.y - 10, _L.n * _L.s + 20, _L.n * _L.s + 20, _p.seed);
        smp_draw_grid(_L.x, _L.y, _L.n, _L.s);
        // the hints, under the card
        var _hints = ["arrows  move the needle", "Enter  stitch or unpick", "Shift  mark a cell empty", "click, drag  stitch    right-click  mark", "Esc  leave (the work is kept)"];
        for (_i = 0; _i < 5; _i++) smp_k_text(680, 250 + _i * 22, _hints[_i], 14, smp_hex("#c9a878"), fa_center, fa_middle);
        surface_reset_target(); _st.dirty.board = false; draw_set_colour(c_white);
    }
    _s = smp__play_surface(_st, "clues", SMP_PW, SMP_PH);
    if (_st.dirty.clues) {
        surface_set_target(_s); draw_clear_alpha(c_black, 0);
        smp__rrect(_L.x, _L.y - _L.top, _L.n * _L.s, _L.top - 4, 3, smp_hex("#faf4e6"), smp_hex("#f2e9d4"));
        smp__rrect(_L.x - _L.left, _L.y, _L.left - 4, _L.n * _L.s, 3, smp_hex("#faf4e6"), smp_hex("#f2e9d4"));
        var _fs = _L.fs, _ink = smp_hex(SMP_INK), _dim = make_colour_rgb(60, 45, 30), _band = make_colour_rgb(180, 150, 110);
        for (_i = 0; _i < _L.n; _i++) {
            var _col = _p.clues.cols[_i], _row = _p.clues.rows[_i], _cxp = _L.x + (_i + 0.5) * _L.s, _cyp = _L.y + (_i + 0.5) * _L.s, _j;
            if (_i mod 2) { draw_set_alpha(0.12); draw_set_colour(_band); draw_rectangle(_L.x + _i * _L.s, _L.y - _L.top, _L.x + (_i + 1) * _L.s, _L.y - 4, false); draw_rectangle(_L.x - _L.left, _L.y + _i * _L.s, _L.x - 4, _L.y + (_i + 1) * _L.s, false); draw_set_alpha(1); }
            for (_j = 0; _j < array_length(_col); _j++) smp_k_text(_cxp, _L.y - 10 - (array_length(_col) - 1 - _j) * (_fs + 3), _col[_j], _fs, _st.colDone[_i] ? _dim : _ink, fa_center, fa_middle, fnt_sampler_ui, _st.colDone[_i] ? 0.3 : 1);
            for (_j = 0; _j < array_length(_row); _j++) smp_k_text(_L.x - 14 - (array_length(_row) - 1 - _j) * (_fs * 0.95 + 4), _cyp + 1, _row[_j], _fs, _st.rowDone[_i] ? _dim : _ink, fa_center, fa_middle, fnt_sampler_ui, _st.rowDone[_i] ? 0.3 : 1);
        }
        surface_reset_target(); _st.dirty.clues = false; draw_set_colour(c_white);
    }
    _s = smp__play_surface(_st, "stitches", SMP_PW, SMP_PH);
    if (_st.dirty.stitches) {
        surface_set_target(_s); draw_clear_alpha(c_black, 0);
        var _shown = array_create(_L.n * _L.n, false);
        for (_i = 0; _i < _st.revealAt; _i++) _shown[_st.revealOrder[_i]] = true;
        for (_i = 0; _i < _L.n * _L.n; _i++) {
            var _x = _L.x + (_i mod _L.n) * _L.s, _y = _L.y + floor(_i / _L.n) * _L.s;
            if (_shown[_i] || (_st.mode == "done" && _p.cells[_i] != 0)) smp_draw_stitch(_x, _y, _L.s, _P[_p.thread[_i] mod array_length(_P)]);
            else if (_st.grid[_i] == 1) smp_draw_stitch(_x, _y, _L.s, _st.locked[_i] ? _st.work.given : _st.work.work);
            else if (_st.grid[_i] == 2) smp_draw_mark(_x, _y, _L.s);
        }
        surface_reset_target(); _st.dirty.stitches = false;
    }
    _s = smp__play_surface(_st, "card", 240, 196);
    if (_st.dirty.card) {
        surface_set_target(_s); draw_clear_alpha(c_black, 0);
        var _w = 240, _h = 196, _red = smp_hex("#8a2f3f"), _brown = smp_hex("#5a4430");
        draw_set_alpha(0.45); smp__rrect(4, 6, _w - 8, _h - 8, 6, c_black, c_black); draw_set_alpha(1);
        smp__rrect(0, 0, _w - 8, _h - 10, 6, smp_hex("#fbf5e6"), smp_hex("#eee2c6"));
        draw_set_colour(_red);
        for (var _e = 0; _e < 2; _e++) draw_rectangle(6 + _e * 0.5, 6 + _e * 0.5, _w - 14 - _e * 0.5, _h - 16 - _e * 0.5, true);
        smp_k_text((_w - 8) / 2, 24, "PATTERN CARD", 12, _red, fa_center, fa_middle);
        var _tpx = 20; while (_tpx > 12 && smp_k_text_w(_st.title, _tpx) > _w - 36) _tpx--;
        smp_k_text((_w - 8) / 2, 50, _st.title, _tpx, smp_hex(SMP_INK), fa_center, fa_middle);
        // ⛔ found by looking (2026-09-28): the serif face has OLD-STYLE figures, so "15" read as "Iſ" and every clue "1" as
        // an "I". Numbers are set in the lining figures of the shipped sans; words stay in the serif.
        smp_k_text((_w - 8) / 2, 72, string(_p.n) + " x " + string(_p.n) + " chart", 12, _brown, fa_center, fa_middle, fnt_sampler_ui);
        var _sw = min(40, (_w - 50) / array_length(_P));
        for (_i = 0; _i < array_length(_P); _i++) {
            var _sx = (_w - 8) / 2 - (array_length(_P) * _sw) / 2 + _i * _sw + _sw / 2, _tc = smp_hex(_P[_i]), _px2 = _sx - 12, _py2 = 100;
            for (var _t = 1; _t <= 8; _t++) { var _u = _t / 8, _qx = sqr(1 - _u) * (_sx - 12) + 2 * (1 - _u) * _u * _sx + sqr(_u) * (_sx + 12), _qy = sqr(1 - _u) * 100 + 2 * (1 - _u) * _u * 88 + sqr(_u) * 100; smp__line(_px2, _py2, _qx, _qy, 5, _tc, _tc); _px2 = _qx; _py2 = _qy; }
        }
        smp_k_text((_w - 8) / 2, 118, _st.pal.name + " threads", 12, _brown, fa_center, fa_middle);
        smp_k_text((_w - 8) / 2, 146, _st.done ? "every line matches" : string(_st.linesDone) + " of " + string(_p.n * 2) + " lines match", 14, smp_hex(SMP_INK), fa_center, fa_middle, fnt_sampler_ui);
        var _gn = array_length(_p.givens);
        smp_k_text((_w - 8) / 2, 166, (_gn > 0) ? string(_gn) + " stitch" + ((_gn > 1) ? "es" : "") + " given" : "no stitches given", 11, _brown, fa_center, fa_middle, fnt_sampler_ui);
        surface_reset_target(); _st.dirty.card = false; draw_set_colour(c_white);
    }
    if (_st.mode == "done") {
        _s = smp__play_surface(_st, "finished", SMP_PW, SMP_PH);
        if (_st.dirty.finished) {
            surface_set_target(_s); draw_clear_alpha(c_black, 0);
            draw_set_alpha(0.72); draw_set_colour(make_colour_rgb(12, 7, 4)); draw_rectangle(0, 0, SMP_PW, SMP_PH, false); draw_set_alpha(1);
            smp_draw_sampler(SMP_PW / 2, SMP_PH / 2 - 24, 214, _p);
            smp__play_plaque(SMP_PW / 2, SMP_PH / 2 + 238, 360, _st.title, "Sampler No. " + string(_st.number) + "  -  " + string(_p.n) + " x " + string(_p.n) + "  -  " + _st.pal.name + " threads");
            surface_reset_target(); _st.dirty.finished = false; draw_set_colour(c_white);
        }
    }
    smp__over_end();
}

/// @function smp__play_plaque(cx, cy, w, title, sub)
/// @description A small engraved brass plaque with a title and a subtitle. Internal.
function smp__play_plaque(_cx, _cy, _w, _title, _sub) {
    var _h = 52, _x = _cx - _w / 2, _y = _cy - _h / 2;
    draw_set_alpha(0.45); smp__rrect(_x + 3, _y + 4, _w, _h, 6, c_black, c_black); draw_set_alpha(1);
    smp__rrect(_x, _y, _w, _h / 2, 6, smp_hex("#f6dc94"), smp_hex("#c99a42"));
    smp__rrect(_x, _y + _h / 2 - 1, _w, _h / 2 + 1, 6, smp_hex("#c99a42"), smp_hex("#8a6120"));
    draw_set_colour(make_colour_rgb(60, 40, 10)); draw_set_alpha(0.7); draw_rectangle(_x + 3, _y + 3, _x + _w - 3, _y + _h - 3, true); draw_set_alpha(1);
    var _px = 18; while (_px > 11 && smp_k_text_w(_title, _px) > _w - 20) _px--;
    smp_k_text(_cx, _cy - 9 + 1, _title, _px, make_colour_rgb(255, 245, 210), fa_center, fa_middle, fnt_sampler, 0.6);
    smp_k_text(_cx, _cy - 9, _title, _px, smp_hex("#3a2408"), fa_center, fa_middle);
    smp_k_text(_cx, _cy + 13, _sub, 11, smp_hex("#4a3010"), fa_center, fa_middle, fnt_sampler_ui);
    draw_set_colour(c_white);
}

/// @function smp_play_draw(screen, x, y, w, h)
/// @description Draw the screen fitted into a rectangle (816 x 624 inside, letterboxed). Call from a Draw GUI event.
function smp_play_draw(_st, _x, _y, _w, _h) {
    if (!is_struct(_st) || !variable_struct_exists(_st, "surf") || !is_numeric(_w) || !is_numeric(_h) || _w < 8 || _h < 8) return;
    _st.rect = [_x, _y, _w, _h];
    smp__play_paint(_st);
    var _L = _st.L, _f = smp__play_surface(_st, "frame", SMP_PW, SMP_PH);
    smp__over_begin();
    surface_set_target(_f); draw_clear_alpha(c_black, 1);
    draw_surface(_st.surf.board, 0, 0);
    draw_surface(_st.surf.clues, 0, 0);
    draw_surface(_st.surf.stitches, 0, 0);
    if (_st.mode == "play") {
        // the needle-frame cursor: a gilt square with a pearl at each corner
        var _cxp = _L.x + _st.cx * _L.s, _cyp = _L.y + _st.cy * _L.s, _gold = smp_hex("#e8b64a");
        draw_set_alpha(0.45); draw_set_colour(c_black); draw_rectangle(_cxp + 0.5, _cyp + 1.5, _cxp + _L.s + 0.5, _cyp + _L.s + 1.5, true); draw_set_alpha(1);
        for (var _e = -1; _e <= 1; _e++) { draw_set_colour(_gold); draw_rectangle(_cxp - 1 + _e * 0.5, _cyp - 1 + _e * 0.5, _cxp + _L.s + 1 - _e * 0.5, _cyp + _L.s + 1 - _e * 0.5, true); }
        var _pearl = smp_hex("#fff2c4");
        draw_circle_colour(_cxp - 1, _cyp - 1, 2.2, _pearl, _pearl, false); draw_circle_colour(_cxp + _L.s + 1, _cyp - 1, 2.2, _pearl, _pearl, false);
        draw_circle_colour(_cxp - 1, _cyp + _L.s + 1, 2.2, _pearl, _pearl, false); draw_circle_colour(_cxp + _L.s + 1, _cyp + _L.s + 1, 2.2, _pearl, _pearl, false);
    }
    draw_surface(_st.surf.card, 560, 24);
    // ⛔ found by looking (2026-09-28): the longest built-in status ended 5 px from the frame's edge and overhung the card's
    // column on both sides, so a longer (or translated) line would clip. The line is fitted to the column (232 px).
    var _spx = 17;
    while (_spx > 11 && smp_k_text_w(_st.status, _spx) > 232) _spx -= 0.5;
    smp_k_text(680 + 1, 392 + 1, _st.status, _spx, c_black, fa_center, fa_middle, fnt_sampler, 0.6);
    smp_k_text(680, 392, _st.status, _spx, smp_hex("#f1dfb4"), fa_center, fa_middle);
    if (_st.mode == "done" && surface_exists(_st.surf.finished)) draw_surface(_st.surf.finished, 0, 0);
    surface_reset_target();
    smp__over_end();
    draw_set_colour(c_white);
    var _k = min(_w / SMP_PW, _h / SMP_PH), _ox = _x + (_w - SMP_PW * _k) / 2, _oy = _y + (_h - SMP_PH * _k) / 2, _pt = gpu_get_texfilter();
    gpu_set_texfilter(true);
    draw_surface_ext(_f, _ox, _oy, _k, _k, 0, c_white, 1);
    gpu_set_texfilter(_pt);
}

/// @function smp_play_free(screen)
/// @description Free the screen's surfaces. Call it in Clean Up (and before dropping the struct).
function smp_play_free(_st) {
    if (!is_struct(_st) || !variable_struct_exists(_st, "surf")) return;
    var _names = variable_struct_get_names(_st.surf);
    for (var _i = 0; _i < array_length(_names); _i++) { var _s = _st.surf[$ _names[_i]]; if (surface_exists(_s)) surface_free(_s); _st.surf[$ _names[_i]] = -1; }
}
