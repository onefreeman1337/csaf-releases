/// smp_draw.gml - Sampler's pictures: woven linen, cross-stitches, the chart grid, the embroidery hoop, the stitched wreath
/// and the finished sampler, all drawn in code (no image file is loaded). Call the smp_draw_* functions from a Draw event.
///
/// Sampler - Picross Stitched Into an Embroidery Hoop, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// PUBLIC
///   smp_draw_sampler(cx, cy, R, puzzle)   -> a finished sampler: linen disc, wreath, the motif in its threads, the hoop
///   smp_draw_hoop(cx, cy, R)              -> the beech hoop and brass clamp round a circle of radius R
///   smp_draw_linen(x, y, w, h, seed)      -> woven linen (warp, weft and slubs) in a rectangle
///   smp_draw_stitch(x, y, s, hex)         -> one cross-stitch filling a cell of size s, in a "#rrggbb" thread
///   smp_draw_mark(x, y, s) / smp_draw_grid(x, y, n, s) / smp_draw_table(w, h)
///   smp_shade(hex, k) / smp_luma(hex) / smp_work_threads(threads) / smp_wreath_for(seed) / smp_wreath_cells(...)
/// ⛔ The wreath's placement (which cells, which thread) is PURE and proven against the RPG Maker MZ SamplerDraw.js for the
/// same puzzles (smp_oracle, stage 80 of the suite); the rest is a picture and is judged by looking at it.

#macro SMP_TAU (pi * 2)
#macro SMP_TACK "#4a4038"
#macro SMP_INK "#2c2218"

/// @function smp__nums(array)
/// @description Is every entry a number? The drawing functions refuse (draw nothing) rather than throw inside the
/// buyer's Draw event when handed undefined or text. Internal, pure.
function smp__nums(_a) { for (var _i = 0; _i < array_length(_a); _i++) if (!is_numeric(_a[_i])) return false; return true; }

/// @function smp__over_begin()
/// @description Push the GPU state and blend colour normally but ALPHA as "over" (src + dest * (1 - src)). ⛔ Found by
/// looking (2026-09-28): under the default blend a translucent line drawn onto an opaque surface LOWERS its alpha, so
/// every linen thread punched a hole and the finished hoop showed the chart through it. Pair with smp__over_end. Internal.
function smp__over_begin() { gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha); }

/// @function smp__over_end()
function smp__over_end() { gpu_pop_state(); }

/// @function smp_hex_rgb(hex)
/// @description [r, g, b] of a "#rrggbb" string; anything unparseable reads as mid-grey [128, 128, 128]. Pure.
function smp_hex_rgb(_h) {
    if (!is_string(_h) || string_length(_h) != 7 || string_char_at(_h, 1) != "#") return [128, 128, 128];
    var _v = 0;
    for (var _i = 2; _i <= 7; _i++) {
        var _c = ord(string_upper(string_char_at(_h, _i))), _d = -1;
        if (_c >= 48 && _c <= 57) _d = _c - 48; else if (_c >= 65 && _c <= 70) _d = _c - 55;
        if (_d < 0) return [128, 128, 128];
        _v = _v * 16 + _d;
    }
    return [(_v >> 16) & 255, (_v >> 8) & 255, _v & 255];
}

/// @function smp_hex(hex)
/// @description The GameMaker colour of a "#rrggbb" string (mid-grey if unparseable). Pure.
function smp_hex(_h) { var _c = smp_hex_rgb(_h); return make_colour_rgb(_c[0], _c[1], _c[2]); }

/// @function smp_shade_rgb(hex, k)
/// @description [r, g, b] lightened toward white (k > 0) or darkened toward black (k < 0) by |k|. Pure.
function smp_shade_rgb(_h, _k) {
    var _c = smp_hex_rgb(_h), _o = [0, 0, 0];
    if (!is_numeric(_k)) _k = 0;
    for (var _i = 0; _i < 3; _i++) _o[_i] = clamp(floor(((_k >= 0) ? _c[_i] + (255 - _c[_i]) * _k : _c[_i] * (1 + _k)) + 0.5), 0, 255);
    return _o;
}

/// @function smp_shade(hex, k)
/// @description smp_shade_rgb as a GameMaker colour. Pure.
function smp_shade(_h, _k) { var _c = smp_shade_rgb(_h, _k); return make_colour_rgb(_c[0], _c[1], _c[2]); }

/// @function smp_luma(hex)
/// @description Relative luminance (0-255) of a "#rrggbb" thread; an unparseable colour reads as mid-grey. Pure.
function smp_luma(_h) {
    if (!is_string(_h) || string_length(_h) != 7) return 128;
    var _c = smp_hex_rgb(_h);
    return 0.2126 * _c[0] + 0.7152 * _c[1] + 0.0722 * _c[2];
}

/// @function smp_work_threads(threads)
/// @description {work, given}: the grey tacking thread the player's stitches are worked in, and the palette thread
/// farthest from it in colour for the given (locked) stitches, so a given always stands out. Pure.
function smp_work_threads(_t) {
    if (!is_array(_t) || array_length(_t) == 0) return { work: SMP_TACK, given: SMP_INK };
    var _a = smp_hex_rgb(SMP_TACK), _g = 0, _best = -1;
    for (var _i = 0; _i < array_length(_t); _i++) {
        var _b = smp_hex_rgb(_t[_i]), _d = sqr(_a[0] - _b[0]) + sqr(_a[1] - _b[1]) + sqr(_a[2] - _b[2]);
        if (_d > _best) { _best = _d; _g = _i; }
    }
    return { work: SMP_TACK, given: _t[_g] };
}

/// @function smp_wreath_for(seed)
/// @description The wreath style a finished sampler is bordered with, from its seed: beads, garland, rope or twin. Pure.
function smp_wreath_for(_seed) {
    static _w = ["beads", "garland", "rope", "twin"];
    var _s = is_numeric(_seed) ? (floor(_seed) & $FFFFFFFF) : 0;
    var _r = smp_rng((_s ^ $B0D) & $FFFFFFFF);
    return _w[floor(smp_rnd(_r) * 4) mod 4];
}

/// @function smp__bead_at(u, r, ws, spacing)
/// @description The bead index if angle u (0..1) is within half a stitch of a bead centre on a ring of radius r, else -1.
/// The bead count is a multiple of 8, so the beads keep the four-fold symmetry. Internal, pure.
function smp__bead_at(_u, _r, _ws, _sp) {
    var _arc = SMP_TAU * _r, _m = 8 * max(1, smp__round(_arc / (_ws * _sp * 8))), _bv = _u * _m + 0.5, _bk = floor(_bv);
    return (abs(_bv - _bk - 0.5) * _arc / _m < 0.5 * _ws) ? _bk : -1;
}

/// @function smp_wreath_cells(puzzle, cx, cy, R, s, gx, gy, style)
/// @description Where the stitched wreath goes: a flat array [i, j, thread, ...] of stitches of size ws on a grid centred
/// on the hoop (stitch at cx + i * ws, cy + j * ws; thread 0 or 3 of the palette). A stitch that would touch a stitched
/// motif cell is left out, so the wreath wraps round the motif. Pure (the MZ drawWreath's placement, exactly).
function smp_wreath_cells(_p, _cx, _cy, _R, _s, _gx, _gy, _style) {
    var _out = [];
    if (!is_struct(_p) || !variable_struct_exists(_p, "cells") || !variable_struct_exists(_p, "n") || !smp__nums([_cx, _cy, _R, _s, _gx, _gy]) || _R <= 0 || _s <= 0) return _out;
    var _e = smp__eps0();
    var _ws = max(3, min(_s, smp__round(_R * 0.08))), _K = ceil(_R / _ws) + 1, _n = _p.n;
    var _N = 8 * max(1, smp__round((SMP_TAU * _R) / (_ws * 5 * 8)));
    for (var _j = -_K; _j < _K; _j++) for (var _i = -_K; _i < _K; _i++) {
        var _ccx = (_i + 0.5) * _ws, _ccy = (_j + 0.5) * _ws, _d = sqrt(_ccx * _ccx + _ccy * _ccy), _band = (_R - _d) / _ws;
        if (_band < 0.75 || _band > 3.75) continue;
        var _ring = (_band < 1.75) ? 1 : ((_band < 2.75) ? 2 : 3);
        var _mx = floor((_cx + _ccx - _gx) / _s), _my = floor((_cy + _ccy - _gy) / _s), _near = false;
        for (var _yy = _my - 1; _yy <= _my + 1 && !_near; _yy++) for (var _xx = _mx - 1; _xx <= _mx + 1; _xx++) {
            if (_xx >= 0 && _yy >= 0 && _xx < _n && _yy < _n && _p.cells[_yy * _n + _xx] != 0) { _near = true; break; }
        }
        if (_near) continue;
        var _u = (arctan2(_ccy, _ccx) + pi) / SMP_TAU, _v = _u * _N, _col = -1;
        if (_style == "beads") {
            if (_ring == 1) { var _bk = smp__bead_at(_u, _R - 1.25 * _ws, _ws, 2.2); if (_bk >= 0) _col = (_bk mod 2) ? 0 : 3; }
            else if (_ring == 3) _col = 0;
        } else if (_style == "garland") {
            if (_ring == 1) _col = 0; else if (_ring == 2 && smp__bead_at(_u, _R - 2.25 * _ws, _ws, 3.2) >= 0) _col = 3;
        } else if (_style == "rope") {
            if (_ring == 1) _col = (floor(_v * 2 + 0.5) mod 2) ? 0 : 3;
        } else if (_ring == 1) _col = 0; else if (_ring == 3) _col = 3;
        if (_col >= 0) array_push(_out, _i, _j, _col);
    }
    math_set_epsilon(_e);
    return _out;
}

/// @function smp__line(x1, y1, x2, y2, w, c1, c2)
/// @description A stroke of width w from c1 to c2 with round caps. Internal.
function smp__line(_x1, _y1, _x2, _y2, _w, _c1, _c2) {
    draw_line_width_colour(_x1, _y1, _x2, _y2, _w, _c1, _c2);
    draw_circle_colour(_x1, _y1, _w * 0.5, _c1, _c1, false);
    draw_circle_colour(_x2, _y2, _w * 0.5, _c2, _c2, false);
}

/// @function smp__stroke3(x1, y1, x2, y2, w, c0, t, c1, c2)
/// @description A round-capped stroke with a three-stop gradient (c0 at 0, c1 at t, c2 at 1). Internal.
function smp__stroke3(_x1, _y1, _x2, _y2, _w, _c0, _t, _c1, _c2) {
    var _mx = lerp(_x1, _x2, _t), _my = lerp(_y1, _y2, _t);
    draw_line_width_colour(_x1, _y1, _mx, _my, _w, _c0, _c1);
    draw_line_width_colour(_mx, _my, _x2, _y2, _w, _c1, _c2);
    draw_circle_colour(_x1, _y1, _w * 0.5, _c0, _c0, false);
    draw_circle_colour(_x2, _y2, _w * 0.5, _c2, _c2, false);
}

/// @function smp_draw_stitch(x, y, s, hex)
/// @description One cross-stitch filling the cell at (x, y) of size s: a shadow on the linen, the under thread, then
/// the top thread crossing over it, each lit along its length, and a glint on larger stitches.
function smp_draw_stitch(_x, _y, _s, _hex) {
    if (!smp__nums([_x, _y, _s]) || _s <= 0) return;
    smp__over_begin();
    var _p = _s * 0.16, _w = max(1.6, _s * 0.2);
    var _ax = _x + _p, _ay = _y + _p, _bx = _x + _s - _p, _by = _y + _s - _p, _cx = _x + _s - _p, _cy = _y + _p, _dx = _x + _p, _dy = _y + _s - _p;
    var _a0 = draw_get_alpha(), _sh = make_colour_rgb(40, 28, 15);
    draw_set_alpha(0.28);
    smp__line(_ax + 1, _ay + 1.2, _bx + 1, _by + 1.2, _w + 1, _sh, _sh);
    smp__line(_cx + 1, _cy + 1.2, _dx + 1, _dy + 1.2, _w + 1, _sh, _sh);
    draw_set_alpha(_a0);
    smp__stroke3(_cx, _cy, _dx, _dy, _w, smp_shade(_hex, -0.2), 0.5, smp_shade(_hex, 0.05), smp_shade(_hex, -0.3));
    smp__stroke3(_ax, _ay, _bx, _by, _w, smp_shade(_hex, 0.05), 0.45, smp_shade(_hex, 0.32), smp_shade(_hex, -0.15));
    if (_s >= 14) {
        draw_set_alpha(0.35 * _a0);
        draw_line_width_colour(_ax + _w * 0.2, _ay - _w * 0.1, _bx - _s * 0.3, _by - _s * 0.34, max(0.6, _w * 0.22), c_white, c_white);
        draw_set_alpha(_a0);
    }
    smp__over_end();
}

/// @function smp_draw_mark(x, y, s)
/// @description A cell the player has marked empty: a small faint pencil cross.
function smp_draw_mark(_x, _y, _s) {
    if (!smp__nums([_x, _y, _s]) || _s <= 0) return;
    smp__over_begin();
    var _p = _s * 0.36, _w = max(1, _s * 0.07), _c = make_colour_rgb(120, 90, 60), _a0 = draw_get_alpha();
    draw_set_alpha(0.55 * _a0);
    smp__line(_x + _p, _y + _p, _x + _s - _p, _y + _s - _p, _w, _c, _c);
    smp__line(_x + _s - _p, _y + _p, _x + _p, _y + _s - _p, _w, _c, _c);
    draw_set_alpha(_a0);
    smp__over_end();
}

/// @function smp_draw_grid(x, y, n, s)
/// @description The chart grid over the linen: fine lines per cell, heavier every fifth, as a printed chart.
function smp_draw_grid(_x, _y, _n, _s) {
    if (!smp__nums([_x, _y, _n, _s]) || _n < 1 || _n > 64 || _s <= 0) return;
    smp__over_begin();
    var _a0 = draw_get_alpha();
    for (var _i = 0; _i <= _n; _i++) {
        var _heavy = (_i mod 5) == 0, _c = _heavy ? make_colour_rgb(90, 64, 40) : make_colour_rgb(120, 95, 65), _w = _heavy ? 1.4 : 0.8;
        draw_set_alpha((_heavy ? 0.55 : 0.25) * _a0);
        draw_line_width_colour(_x + _i * _s, _y, _x + _i * _s, _y + _n * _s, _w, _c, _c);
        draw_line_width_colour(_x, _y + _i * _s, _x + _n * _s, _y + _i * _s, _w, _c, _c);
    }
    draw_set_alpha(_a0);
    smp__over_end();
}

/// @function smp_draw_linen(x, y, w, h, seed)
/// @description Woven linen in a rectangle: a warm ground, warp and weft threads every 3 px, and slubs from the seed.
function smp_draw_linen(_x, _y, _w, _h, _seed) {
    if (!smp__nums([_x, _y, _w, _h]) || _w <= 0 || _h <= 0) return;
    smp__over_begin();
    smp__linen(_x, _y, _w, _h, _seed, -1, 0, 0);
    smp__over_end();
}

/// @function smp__linen(x, y, w, h, seed, R, cx, cy)
/// @description The linen, optionally confined to a disc of radius R about (cx, cy) (R < 0 = the whole rectangle): each
/// thread is cut to its chord and each slub kept only inside, so no clip surface is needed. Internal.
function smp__linen(_x, _y, _w, _h, _seed, _R, _ccx, _ccy) {
    var _a0 = draw_get_alpha(), _i, _l0 = smp_hex("#efe6d2"), _l1 = smp_hex("#e3d7bd"), _th = smp_hex("#b8a47e");
    if (_R > 0) smp__disc(_ccx, _ccy, _R, _l0, _l1, _y, _y + _h);
    else draw_rectangle_colour(_x, _y, _x + _w, _y + _h, _l0, _l0, _l1, _l1, false);
    draw_set_alpha(0.18 * _a0);
    for (_i = _x + 1; _i < _x + _w; _i += 3) {
        var _y0 = _y, _y1 = _y + _h;
        if (_R > 0) { var _dx = _i + 0.5 - _ccx; if (abs(_dx) >= _R) continue; var _hc = sqrt(_R * _R - _dx * _dx); _y0 = _ccy - _hc; _y1 = _ccy + _hc; }
        draw_line_width_colour(_i + 0.5, _y0, _i + 0.5, _y1, 1, _th, _th);
    }
    draw_set_alpha(0.12 * _a0);
    for (_i = _y + 1; _i < _y + _h; _i += 3) {
        var _x0 = _x, _x1 = _x + _w;
        if (_R > 0) { var _dy = _i + 0.5 - _ccy; if (abs(_dy) >= _R) continue; var _wc = sqrt(_R * _R - _dy * _dy); _x0 = _ccx - _wc; _x1 = _ccx + _wc; }
        draw_line_width_colour(_x0, _i + 0.5, _x1, _i + 0.5, 1, _th, _th);
    }
    var _r = smp_rng(is_numeric(_seed) ? (floor(_seed) & $FFFFFFFF) : 0), _hi = make_colour_rgb(255, 255, 255), _lo = make_colour_rgb(120, 95, 60);
    var _count = floor(_w * _h / 160);
    for (_i = 0; _i < _count; _i++) {
        var _light = smp_rnd(_r) < 0.5;
        var _sx = _x + smp_rnd(_r) * _w;
        var _sy = _y + smp_rnd(_r) * _h;
        var _sw = 1 + smp_rnd(_r) * 2;
        if (_R > 0 && sqr(_sx - _ccx) + sqr(_sy - _ccy) > _R * _R) continue;
        draw_set_alpha((_light ? 0.25 : 0.12) * _a0);
        draw_rectangle_colour(_sx, _sy, _sx + _sw, _sy + 1, _light ? _hi : _lo, _light ? _hi : _lo, _light ? _hi : _lo, _light ? _hi : _lo, false);
    }
    draw_set_alpha(_a0);
}

/// @function smp__disc(cx, cy, R, ctop, cbottom, ytop, ybottom)
/// @description A filled disc shaded top to bottom between ytop and ybottom. Internal.
function smp__disc(_cx, _cy, _R, _c0, _c1, _yt, _yb) {
    var _seg = max(24, min(96, floor(_R / 2)));
    draw_primitive_begin(pr_trianglelist);
    for (var _k = 0; _k < _seg; _k++) {
        var _a1 = _k / _seg * SMP_TAU, _a2 = (_k + 1) / _seg * SMP_TAU;
        var _x1 = _cx + cos(_a1) * _R, _y1 = _cy + sin(_a1) * _R, _x2 = _cx + cos(_a2) * _R, _y2 = _cy + sin(_a2) * _R;
        draw_vertex_colour(_cx, _cy, merge_colour(_c0, _c1, clamp((_cy - _yt) / max(1, _yb - _yt), 0, 1)), draw_get_alpha());
        draw_vertex_colour(_x1, _y1, merge_colour(_c0, _c1, clamp((_y1 - _yt) / max(1, _yb - _yt), 0, 1)), draw_get_alpha());
        draw_vertex_colour(_x2, _y2, merge_colour(_c0, _c1, clamp((_y2 - _yt) / max(1, _yb - _yt), 0, 1)), draw_get_alpha());
    }
    draw_primitive_end();
}

/// @function smp__ring(cx, cy, r0, r1, c_in, c_out, fx, fy, f0, f1, alpha)
/// @description An annulus r0..r1 whose colour runs c_in -> c_out with distance from a focus (fx, fy) between f0 and f1
/// (a canvas radial gradient's look: lit from the focus side). Internal.
function smp__ring(_cx, _cy, _r0, _r1, _cin, _cout, _fx, _fy, _f0, _f1, _al) {
    var _seg = max(48, min(160, floor(_r1 / 1.5)));
    draw_primitive_begin(pr_trianglestrip);
    for (var _k = 0; _k <= _seg; _k++) {
        var _a = _k / _seg * SMP_TAU, _ca = cos(_a), _sa = sin(_a);
        var _ox = _cx + _ca * _r1, _oy = _cy + _sa * _r1, _ix = _cx + _ca * _r0, _iy = _cy + _sa * _r0;
        var _to = clamp((point_distance(_fx, _fy, _ox, _oy) - _f0) / max(1, _f1 - _f0), 0, 1), _ti = clamp((point_distance(_fx, _fy, _ix, _iy) - _f0) / max(1, _f1 - _f0), 0, 1);
        draw_vertex_colour(_ox, _oy, merge_colour(_cin, _cout, _to), _al);
        draw_vertex_colour(_ix, _iy, merge_colour(_cin, _cout, _ti), _al);
    }
    draw_primitive_end();
}

/// @function smp__arc(cx, cy, r, a0, a1, w, col)
/// @description A stroked arc from angle a0 to a1 (radians, canvas direction: y down). Internal.
function smp__arc(_cx, _cy, _r, _a0, _a1, _w, _col) {
    var _seg = max(3, ceil(abs(_a1 - _a0) * _r / 4)), _px = _cx + cos(_a0) * _r, _py = _cy + sin(_a0) * _r;
    for (var _k = 1; _k <= _seg; _k++) {
        var _a = lerp(_a0, _a1, _k / _seg), _nx = _cx + cos(_a) * _r, _ny = _cy + sin(_a) * _r;
        draw_line_width_colour(_px, _py, _nx, _ny, _w, _col, _col);
        _px = _nx; _py = _ny;
    }
}

/// @function smp_draw_hoop(cx, cy, R)
/// @description The embroidery hoop round a circle of radius R centred at (cx, cy): a cast shadow, an outer and an inner
/// beech ring with grain and a highlight, and a brass screw clamp at the top.
function smp_draw_hoop(_cx, _cy, _R) {
    if (!smp__nums([_cx, _cy, _R]) || _R <= 0) return;
    smp__over_begin();
    var _a0 = draw_get_alpha();
    smp__ring(_cx + 4, _cy + 6, _R - 2, _R + 16, c_black, c_black, _cx, _cy, 0, 1, 0.4 * _a0);
    for (var _k = 0; _k < 2; _k++) {
        var _r0 = _R + (_k ? 1 : 7), _r1 = _R + (_k ? 7 : 15);
        smp__ring(_cx, _cy, _r0, _r1, smp_hex(_k ? "#e8c88e" : "#d9b27a"), smp_hex(_k ? "#a07640" : "#8a6030"), _cx - _R * 0.3, _cy - _R * 0.3, _R * 0.5, _r1 + _R * 0.42, _a0);
        draw_set_alpha(0.35 * _a0);
        for (var _t = 0; _t < 26; _t++) { var _g0 = _t / 26 * SMP_TAU; smp__arc(_cx, _cy, (_r0 + _r1) / 2 + sin(_t * 2.3) * 1.5, _g0, _g0 + 0.18, 0.8, make_colour_rgb(90, 55, 20)); }
        draw_set_alpha(0.5 * _a0);
        smp__arc(_cx, _cy, _r1 - 1, pi * 1.05, pi * 1.6, 1, make_colour_rgb(255, 240, 210));
        draw_set_alpha(_a0);
    }
    // the brass clamp: a block, a screw post and a wing nut, lit across
    var _bx = _cx, _by = _cy - _R - 16, _d = smp_hex("#8a6120"), _l = smp_hex("#f4d88a"), _dk = smp_hex("#7a5418");
    draw_rectangle_colour(_bx - 12, _by - 8, _bx, _by + 10, _d, _l, _l, _d, false);
    draw_rectangle_colour(_bx, _by - 8, _bx + 12, _by + 10, _l, _dk, _dk, _l, false);
    draw_rectangle_colour(_bx - 4, _by - 26, _bx, _by - 4, _d, _l, _l, _d, false);
    draw_rectangle_colour(_bx, _by - 26, _bx + 4, _by - 4, _l, _dk, _dk, _l, false);
    draw_set_colour(merge_colour(_l, _d, 0.35));
    draw_ellipse(_bx - 11, _by - 34, _bx + 11, _by - 22, false);
    draw_set_alpha(0.6 * _a0);
    for (var _q = -8; _q <= 8; _q += 4) draw_line_width_colour(_bx + _q, _by - 32, _bx + _q, _by - 24, 1, make_colour_rgb(60, 40, 10), make_colour_rgb(60, 40, 10));
    draw_set_alpha(_a0);
    draw_set_colour(c_white);
    smp__over_end();
}

/// @function smp_sampler_layout(puzzle, R)
/// @description How a finished sampler of radius R is laid out, relative to its centre: {s (motif cell), ws (wreath
/// stitch), style, cells (smp_wreath_cells), full (the wreath's stitch count round an empty motif), shrunk}. The MZ
/// original scales every motif to 1.2 R, and a motif that fills its square then covers the wreath's rings and leaves a
/// few stranded stitches (8 of a possible 100+, found by looking at the sheet). So when the wreath would keep fewer than
/// half its stitches the motif cell shrinks, one pixel at a time and never below 60%, until the wreath is whole enough;
/// every other sampler is laid out exactly as the MZ hoop lays it out. Pure.
function smp_sampler_layout(_p, _R) {
    if (!is_struct(_p) || !variable_struct_exists(_p, "cells") || !variable_struct_exists(_p, "n") || !is_numeric(_R) || _R <= 4) return undefined;
    var _n = _p.n, _s0 = max(3, floor((_R * 1.2) / _n)), _seed = variable_struct_exists(_p, "seed") ? _p.seed : 0, _style = smp_wreath_for(_seed);
    // every candidate stitch round an EMPTY motif; the wreath stitch size is derived from the ORIGINAL cell, so shrinking
    // the motif never shrinks its border. At the original cell the filter below IS smp_wreath_cells (same order, same test).
    var _all = smp_wreath_cells({ n: _n, cells: array_create(_n * _n, 0) }, 0, 0, _R, _s0, -_n * _s0 / 2, -_n * _s0 / 2, _style);
    var _ws = max(3, min(_s0, smp__round(_R * 0.08))), _full = array_length(_all) div 3, _floor = max(3, ceil(_s0 * 0.6));
    var _s = _s0, _cells = smp__wreath_keep(_p, _all, _ws, _s);
    while (array_length(_cells) div 3 < _full div 2 && _s > _floor) { _s -= 1; _cells = smp__wreath_keep(_p, _all, _ws, _s); }
    return { s: _s, ws: _ws, style: _style, cells: _cells, full: _full, shrunk: _s != _s0 };
}

/// @function smp__wreath_keep(puzzle, all, ws, s)
/// @description The candidate wreath stitches `all` ([i, j, thread, ...]) that do not touch a stitched motif cell when the
/// motif is laid at cell size s, centred. Internal, pure.
function smp__wreath_keep(_p, _all, _ws, _s) {
    var _keep = [], _n = _p.n;
    for (var _k = 0; _k < array_length(_all); _k += 3) {
        var _mx = floor(((_all[_k] + 0.5) * _ws + _n * _s / 2) / _s), _my = floor(((_all[_k + 1] + 0.5) * _ws + _n * _s / 2) / _s), _near = false;
        for (var _yy = _my - 1; _yy <= _my + 1 && !_near; _yy++) for (var _xx = _mx - 1; _xx <= _mx + 1; _xx++) {
            if (_xx >= 0 && _yy >= 0 && _xx < _n && _yy < _n && _p.cells[_yy * _n + _xx] != 0) { _near = true; break; }
        }
        if (!_near) array_push(_keep, _all[_k], _all[_k + 1], _all[_k + 2]);
    }
    return _keep;
}

/// @function smp_draw_sampler(cx, cy, R, puzzle)
/// @description A finished sampler: a linen disc in a hoop with the motif stitched in its threads inside a generated
/// stitched wreath (its style from the puzzle's seed), a soft vignette, then the hoop. Returns the wreath stitch count.
function smp_draw_sampler(_cx, _cy, _R, _p) {
    if (!smp__nums([_cx, _cy])) return 0;
    var _L = smp_sampler_layout(_p, _R);
    if (is_undefined(_L)) return 0;
    smp__over_begin();
    var _n = _p.n, _P = smp_palette(_p.palette).threads, _s = _L.s, _gx = _cx - _n * _s / 2, _gy = _cy - _n * _s / 2;
    var _seed = variable_struct_exists(_p, "seed") ? _p.seed : 0;
    smp__linen(_cx - _R, _cy - _R, _R * 2, _R * 2, (floor(_seed) & $FFFFFFFF) ^ $11, _R, _cx, _cy);
    var _wc = _L.cells, _ws = _L.ws;
    for (var _k = 0; _k < array_length(_wc); _k += 3) smp_draw_stitch(_cx + _wc[_k] * _ws, _cy + _wc[_k + 1] * _ws, _ws, _P[_wc[_k + 2] mod array_length(_P)]);
    for (var _i = 0; _i < _n * _n; _i++) if (_p.cells[_i] != 0) smp_draw_stitch(_gx + (_i mod _n) * _s, _gy + floor(_i / _n) * _s, _s, _P[_p.thread[_i] mod array_length(_P)]);
    // the vignette: transparent at 0.6 R to 22% umber at the rim (alpha, not colour, carries the gradient)
    var _seg = 96, _vc = make_colour_rgb(60, 40, 20), _a0 = draw_get_alpha();
    draw_primitive_begin(pr_trianglestrip);
    for (var _q = 0; _q <= _seg; _q++) {
        var _a = _q / _seg * SMP_TAU;
        draw_vertex_colour(_cx + cos(_a) * _R, _cy + sin(_a) * _R, _vc, 0.22 * _a0);
        draw_vertex_colour(_cx + cos(_a) * _R * 0.6, _cy + sin(_a) * _R * 0.6, _vc, 0);
    }
    draw_primitive_end();
    smp_draw_hoop(_cx, _cy, _R);
    smp__over_end();
    return array_length(_wc) div 3;
}

/// @function smp_draw_table(w, h)
/// @description The sewing table under everything: dark walnut with a wavy grain, filling (0, 0, w, h).
function smp_draw_table(_w, _h) {
    if (!smp__nums([_w, _h]) || _w <= 0 || _h <= 0) return;
    smp__over_begin();
    var _c0 = smp_hex("#3b271a"), _c1 = smp_hex("#1d120b"), _a0 = draw_get_alpha();
    draw_rectangle_colour(0, 0, _w, _h, _c0, merge_colour(_c0, _c1, 0.5), _c1, merge_colour(_c0, _c1, 0.5), false);
    // ⛔ found by looking (2026-09-28): the MZ grain's even 3 px pitch read as scanlines at 1:1, and a 2-6 px pitch let a
    // run of light lines pool into a pale stripe right across the table. The pitch is 2-4 px, light lines are fainter
    // than dark ones, and the top is laid in planks whose seams are drawn, so any band reads as a board edge.
    var _r = smp_rng($5E3), _warm = make_colour_rgb(255, 215, 170), _y = 0;
    while (_y < _h) {
        var _light = smp_rnd(_r) < 0.4;
        var _lw = 1 + smp_rnd(_r) * 1.5;
        var _step = 2 + floor(smp_rnd(_r) * 3);
        draw_set_alpha((_light ? 0.025 : 0.08) * _a0);
        var _px = 0, _py = _y + sin(_y / 37) * 2;
        for (var _x = 40; _x < _w + 40; _x += 40) {
            var _ny = _y + sin(_x / 110 + _y / 37) * 2;
            draw_line_width_colour(_px, _py, _x, _ny, _lw, _light ? _warm : c_black, _light ? _warm : c_black);
            _px = _x; _py = _ny;
        }
        _y += _step;
    }
    // plank seams: a dark joint with a faint lit lip below it, every 180 px
    for (var _sy = 180; _sy < _h; _sy += 180) {
        draw_set_alpha(0.45 * _a0);
        draw_line_width_colour(0, _sy, _w, _sy, 2, c_black, c_black);
        draw_set_alpha(0.07 * _a0);
        draw_line_width_colour(0, _sy + 2, _w, _sy + 2, 1, _warm, _warm);
    }
    draw_set_alpha(_a0);
    smp__over_end();
}
