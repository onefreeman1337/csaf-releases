{
  "$GMScript": "v1",
  "%Name": "smp_oracle",
  "name": "smp_oracle",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}