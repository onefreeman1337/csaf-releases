/// @description The chart, fitted to the window.
if (is_undefined(screen)) exit;
smp_play_draw(screen, 0, 0, display_get_gui_width(), display_get_gui_height());
