/// @description Sampler demo: a generated picross chart you stitch, and the headless -selftest entry.
/// ⛔ The crash handler is installed FIRST, and every variable a later event reads is declared ABOVE the early exits:
/// Clean Up always runs, even when Create leaves early.
exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("smp_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.smp_stage) + ": " + string(_ex.message) + " | " + string(_ex.stacktrace));
    file_text_close(_f);
    game_end();
});
global.smp_stage = 0;
screen = undefined;
seed = 2026;
finished = 0;
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";
if (string_pos("-selftest", _args) > 0) { global.smp_stage = 1; smp_selftest_write(smp_selftest_run()); game_end(); exit; }

// One chart: a generated four-fold motif, its clues, and the given stitches that make it solvable by logic alone.
// Save smp_play_save(screen) with your game and pass it back as {work, done} to keep the player's stitches.
screen = smp_play_create({ seed: seed, size: 10, number: finished + 1 });
