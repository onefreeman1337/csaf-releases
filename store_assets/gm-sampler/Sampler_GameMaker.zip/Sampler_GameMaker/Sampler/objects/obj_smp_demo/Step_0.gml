/// @description Step the chart; when the player leaves, the demo deals the next one.
if (is_undefined(screen)) exit;
if (smp_play_step(screen) == "left") {
    if (screen.result == "finished") finished += 1;
    smp_play_free(screen);
    seed += 1;
    screen = smp_play_create({ seed: seed, size: choose(5, 10, 15), number: finished + 1 });
}
