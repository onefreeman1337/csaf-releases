/// @description Free the chart's surfaces.
if (variable_instance_exists(id, "screen") && !is_undefined(screen)) smp_play_free(screen);
screen = undefined;
