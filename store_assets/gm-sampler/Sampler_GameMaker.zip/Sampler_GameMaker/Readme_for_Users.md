# Sampler - Picross Stitched Into an Embroidery Hoop, for GameMaker

**GameMaker 2024.14 or newer · pure GML · no sprites, no shaders, no extensions**
Core Systems Asset Factory · <https://csaf.itch.io>

Picross (nonograms) for your game. The player fills a chart from the number clues along its rows and columns:
each number is a run of stitches, in order. When the chart is right, the stitches take their thread colours from
the centre out, and the finished piece is set in an embroidery hoop as a cross-stitch sampler, inside a stitched
wreath, with an engraved plaque.

Every puzzle is GENERATED from a seed: the motif (a star, medallion, lattice or diamond ornament, four-fold
symmetric like real sampler work), its thread colours and the chart size (5, 10 or 15 stitches).
**Nothing here is an image file.**

**Every puzzle is proven fair.** Before the player sees it, a line-logic solver works it from the clues alone.
Where the clues leave cells undecided, a few stitches are given (sewn in from the start, and locked) until the
solver completes the whole chart. So every puzzle has exactly one answer and never needs a guess.

---

## Quick start

1. **Tools > Import Local Package**, choose `Sampler.yymps`, import everything.
2. Open `rm_smp_demo` and press Play. Stitch the chart; leave with Escape and the demo deals the next one.
3. In your own game, one screen per puzzle:

```gml
// when the player sits down at the embroidery frame
my_chart = smp_play_create({ seed: "Hollow Oak cottage", size: 10, work: my_saved.work, done: my_saved.done });

// Step
if (is_struct(my_chart) && smp_play_step(my_chart) == "left") {
    my_saved = smp_play_save(my_chart);        // {done, work}: save it with your game
    if (my_chart.result == "finished") my_samplers += 1;
    smp_play_free(my_chart);
    my_chart = undefined;
}

// Draw GUI
if (is_struct(my_chart)) smp_play_draw(my_chart, 0, 0, display_get_gui_width(), display_get_gui_height());

// Clean Up
if (is_struct(my_chart)) smp_play_free(my_chart);
```

The screen draws its own 816 x 624 frame and fits it, uniformly scaled and centred, into the rectangle you give
`smp_play_draw`. Mouse clicks are mapped back through the same fit.

A text seed (a place name, a quest id) is hashed, so the same text is always the same puzzle. Pass back what
`smp_play_save` returned and the player's stitches are where they left them.

---

## What the player sees

| Screen | What is on it |
| --- | --- |
| The chart | Woven linen on a walnut sewing table, the chart grid (heavier every fifth line), the column clues on a paper tape above and the row clues to the left (a line that matches its clue dims), the gilt needle-frame cursor, the player's stitches in grey tacking thread, given stitches in a contrasting thread, empty-marks as faint pencil crosses, three thread spools |
| The pattern card | The pattern's name, the chart size, the four threads as skeins, how many of the lines match, how many stitches were given |
| The reveal | The chart is right: the colours go in from the centre out, stitch by stitch |
| The finished sampler | The motif in its threads on a linen disc, inside a stitched wreath (beads, garland, rope or twin rings, chosen by the seed), in a beech hoop with a brass clamp, and a brass plaque naming it |

Controls: **arrows** move the needle, **Enter** (or Space) stitches or unpicks, **Shift** marks a cell empty,
**Escape** leaves (the work is kept). Mouse: click to stitch, drag to stitch a line, right-click marks a cell
empty (right-click outside the chart leaves). On the finished sampler, any of them closes the screen.

---

## The screen

| Function | Returns | What it does |
| --- | --- | --- |
| `smp_play_create([opts])` | screen | `opts`: `seed` (number or text), `size` (5, 10, 15), `form` (`"star"`, `"medallion"`, `"lattice"`, `"diamond"`), `palette` (`"scarlet"`, `"indigo"`, `"forest"`, `"rose"`, `"harvest"`, `"midnight"`), `title` (blank = named after the motif), `work` and `done` (from `smp_play_save`), `number` (the plaque's "Sampler No.") |
| `smp_play_step(screen, [input])` | mode | Advances one frame: `"play"`, `"reveal"`, `"done"` (the finished hoop is showing) or `"left"`. When it is `"left"`, `screen.result` is `"finished"` or `"left"` |
| `smp_play_draw(screen, x, y, w, h)` | - | Draws the screen fitted into the rectangle |
| `smp_play_input()` | input | This frame's keyboard and mouse as the struct `smp_play_step` reads: `left right up down ok mark cancel` (pressed this frame), `mx my` (GUI position), `press held rpress` (mouse). Build your own struct to drive it from a gamepad or a replay |
| `smp_play_save(screen)` | `{done, work}` | What to save; pass both back to `smp_play_create` |
| `smp_play_free(screen)` | - | Frees the screen's surfaces |

---

## The puzzle core (pure logic, nothing drawn)

| Function | Returns |
| --- | --- |
| `smp_generate([opts])` | A puzzle `{n, form, palette, cells, thread, clues, givens, solvable, sweeps, fill}`. `opts`: `seed`, `size`, `form`, `palette`. A motif is redrawn from the same stream while it fills less than 30% or more than 72% of the chart, or needs more than 8% of it given |
| `smp_motif(seed, n, [form])` | A four-fold symmetric motif `{n, form, cells, thread}` (`cells[i]` is 1 where stitched, `thread[i]` is 0 to 3) |
| `smp_clues(motif)` | `{rows, cols}`: each an array of run-length lists (`[0]` for an empty line) |
| `smp_runs(line)` | The run lengths of one line of 0s and 1s |
| `smp_solve_line(clue, known)` | What every arrangement of `clue` over `known` agrees on (-1 unknown, 0 empty, 1 stitched), or `undefined` if none fits |
| `smp_line_solve(n, clues, [givens])` | `{grid, solved, sweeps, contradiction}`: line logic run to a standstill |
| `smp_is_solved(puzzle, grid)` | Does a grid (1 = stitched) equal the answer? |
| `smp_line_done(clue, line)` | Does one line match its clue? |
| `smp_forms()` · `smp_sizes()` · `smp_palette_ids()` · `smp_palette(id)` | The four forms, the three sizes, the six palette ids, and a palette `{name, threads}` (four `"#rrggbb"` threads) |
| `smp_hash(text)` · `smp_rng(seed)` · `smp_rnd(state)` | The string hash and the seeded generator everything is drawn from |

## The drawing (call from a Draw or Draw GUI event, or inside a surface)

| Function | Draws |
| --- | --- |
| `smp_draw_sampler(cx, cy, R, puzzle)` | A finished sampler of radius `R`: linen disc, wreath, the motif in its threads, a vignette, the hoop. Returns the wreath's stitch count |
| `smp_sampler_layout(puzzle, R)` | How that sampler is laid out: `{s, ws, style, cells, full, shrunk}` |
| `smp_draw_hoop(cx, cy, R)` | The beech hoop and brass clamp round a circle of radius `R` |
| `smp_draw_linen(x, y, w, h, seed)` | Woven linen in a rectangle |
| `smp_draw_stitch(x, y, s, hex)` | One cross-stitch filling a cell of size `s` |
| `smp_draw_mark(x, y, s)` | A pencil cross (a cell marked empty) |
| `smp_draw_grid(x, y, n, s)` | The chart grid |
| `smp_draw_table(w, h)` | The walnut sewing table, filling (0, 0, w, h) |
| `smp_draw_spool(x, y, hex, scale)` | A thread spool |
| `smp_wreath_for(seed)` · `smp_wreath_cells(puzzle, cx, cy, R, s, gx, gy, style)` | The wreath style for a seed, and where its stitches go |
| `smp_shade(hex, k)` · `smp_shade_rgb(hex, k)` · `smp_hex(hex)` · `smp_hex_rgb(hex)` · `smp_luma(hex)` · `smp_work_threads(threads)` | Colour helpers |

Each drawing function blends its own alpha as "over", so it can draw into a surface without punching holes in it.

---

## How it was tested

GML cannot be unit-tested outside the engine, so the tests run inside it: `Sampler.exe -selftest` (the demo
object's `-selftest` branch) writes `smp_selftest.json`.

* **The puzzle core is a port of this studio's RPG Maker MZ Sampler core, proven exact against it.** The MZ
  JavaScript was run in Node for the same seeds and its answers compiled into the suite (`smp_oracle`): the hash,
  the generator's draws, thirty motifs cell for cell and thread for thread, the clues, eight line-solver cases
  (two of them contradictions) and twelve whole puzzles field for field. The wreath placement is proven the same
  way against the MZ drawing, stitch for stitch.
* Every generated puzzle is solved again from its clues and givens, and must come out as exactly its motif.
* The screen is driven through its own input struct: a wrong stitch, unpick, mark, save and resume, the chart
  finishing on its last right stitch and not before, the reveal, the finished hoop, Escape, and a mouse drag.
* Hostile input (text where numbers go, sizes that do not exist, `undefined`) is refused or defaulted, never
  thrown.

## Notes

* The given stitches are locked: the player cannot unpick them.
* `smp_play_save` stores the player's stitches as one character per cell, so a 15 x 15 chart is 225 characters.
* How many different charts there are (measured in engine): over seeds 1 to 40 of each form, 117 different
  15 x 15 charts and 71 different 10 x 10 charts. A 5 x 5 chart has room for very few four-fold shapes: over seeds
  1 to 200 there were 11 in all (star 4, lattice 3, medallion 2, diamond 2), so use 5 as a tutorial size. Nearby
  seeds can deal the same chart; if your game must never repeat one, keep the charts it has dealt and skip a repeat.
* Built and tested against the GameMaker runtime 2024.14.4.268 (VM). Not yet tested on GMRT.
* The fonts are IM Fell DW Pica (SIL OFL 1.1, as "Sampler Plate Serif") and Open Sans (Apache 2.0); both licences
  and the notices are in `Sampler/fonts/`.
* This package was written with AI assistance.
