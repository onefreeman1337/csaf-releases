/**
 * grid.js — the board and the simulation. Headless: it knows nothing about canvas, DOM or input,
 * which is what lets `Internal_Ops/test_sim.js` and `test_balance.js` drive it directly.
 *
 * THE TWO SYSTEMS THAT FIGHT (wing Gate 4), in one paragraph so the intent survives edits:
 * SPREAD wants you far from home — new cells are new nutrient. DECAY punishes exactly that, because
 * moisture falls off with distance from a spring or a fruiting body, and a cell below its moisture
 * need loses density every tick until it dies back to bare substrate. Neither "expand" nor "sit
 * still" is a strategy on its own: expand past your water and the frontier rots off behind you;
 * sit still and the cells you own run their nutrient down to nothing and the mould moves in.
 *
 * ⛔ NOTHING HERE EVER DELETES PROGRESS WHOLESALE. There is no run, no reset and no death screen —
 * ledger B5 as the core loop rather than a bolted-on checkpoint. A cell can die back to bare
 * substrate; spores, upgrades, fruiting bodies and the substrate you have opened are permanent.
 */
(function (root) {
  'use strict';

  const D = (typeof module === 'object' && module.exports) ? require('./bands.js') : root.BANDS_DATA;

  const COLS = 16;
  const ROWS = 11;

  function idx(x, y) { return y * COLS + x; }
  function inBounds(x, y) { return x >= 0 && y >= 0 && x < COLS && y < ROWS; }

  const NEIGHBOURS = [[1, 0], [-1, 0], [0, 1], [0, -1]];

  function makeCell(x, y) {
    const band = D.bandForRow(y);
    return {
      x, y,
      bandId: band.id,
      nutrient: band.nutrient,
      density: 0,          // 0 = bare substrate, up to densityCap()
      mould: 0,            // 0..1 rival colony
      fruit: null,         // { form, palette } once fruited — permanent
      spring: false,       // a permanent water source
    };
  }

  function createState() {
    const cells = [];
    for (let y = 0; y < ROWS; y++) for (let x = 0; x < COLS; x++) cells.push(makeCell(x, y));

    /* Two springs in the litter band, placed apart so the opening board already poses the
     * question the whole game is about: which way do you grow? A single central spring would
     * make the first ten minutes a symmetric blob. */
    cells[idx(3, 1)].spring = true;
    cells[idx(12, 2)].spring = true;

    const s = {
      cells,
      biomass: 12,
      spores: 0,
      totalSpores: 0,
      fruitings: 0,
      spore: {},          // upgrade id -> level
      bio: {},            // upgrade id -> level
      unlocked: { litter: true, deadwood: false, bone: false, stone: false },
      elapsed: 0,
      lastSeen: Date.now(),
      peakColonised: 0,
      lost: 0,           // cells that dried out and died back, counted over the whole game
      sporeBank: 0,      // fractional spores from fruiting bodies, so a slow trickle cannot round to 0
      moisture: new Float64Array(COLS * ROWS),
    };
    for (const u of D.SPORE_UPGRADES) s.spore[u.id] = 0;
    for (const u of D.BIOMASS_UPGRADES) s.bio[u.id] = 0;

    // the founding cell: one colonised square beside the first spring
    cells[idx(3, 1)].density = 0.30;
    recomputeMoisture(s);
    return s;
  }

  /**
   * Moisture field. Recomputed whenever the sources change (springs, fruiting bodies) rather than
   * every tick — with 176 cells and a handful of sources this is cheap, and making it explicit
   * means the renderer and the simulation can never disagree about it.
   *
   * ⚠️ Each cell also gets its band's own `wetness` as a floor-independent multiplier: BONE is dry
   * *as a material*, so even standing on a spring it is harder to hold than litter. That is what
   * makes the bone band a different problem rather than a bigger number.
   */
  function recomputeMoisture(s) {
    const m = s.moisture;
    const reach = D.anchorRadius(s.spore.reach || 0);
    for (let i = 0; i < m.length; i++) m[i] = 0;
    for (const c of s.cells) {
      if (!c.spring && !c.fruit) continue;
      /* ⚠️ THESE TWO NUMBERS WERE MEASURED, TWICE. At strength 0.72 / spring radius 3.4 the
       * campaign probe stalled at TWENTY cells for six hours and never opened a single band: the
       * effective wet radius works out at about 2.6 cells (moisture falls linearly and then gets
       * multiplied by the band's own wetness before meeting MOISTURE_NEED), so the two springs
       * between them could support roughly the area the game started with. The board was
       * moisture-capped below the size needed to earn the first unlock. */
      const strength = c.spring ? 1.0 : 0.92;
      const radius = c.spring ? 5.6 + (s.spore.retention || 0) * 0.45 : reach;
      for (let y = 0; y < ROWS; y++) {
        for (let x = 0; x < COLS; x++) {
          const d = Math.hypot(x - c.x, y - c.y);
          if (d > radius) continue;
          const v = strength * (1 - d / radius);
          const i = idx(x, y);
          if (v > m[i]) m[i] = v;
        }
      }
    }
    return m;
  }

  /** Effective moisture at a cell: the field, scaled by how well that material holds water. */
  function moistureAt(s, c) {
    return s.moisture[idx(c.x, c.y)] * D.BAND_BY_ID[c.bandId].wetness;
  }

  const MOISTURE_NEED = 0.20;
  /* What exhausted ground still pays — see the note in step(). ⚠️ 0.06 removed the soft-lock but
   * left the late board earning too little to fund the fruitings the spore tree needs, so the
   * probe reached bone and then crawled. 0.12 is a floor you can build on rather than merely
   * survive on; fresh ground still pays more than eight times as much. */
  const RESIDUAL = 0.12;
  /* Below a quarter of the moisture need the ground is simply too dry to hold hyphae at all, so
   * there IS still a hard frontier beyond the gradient. Without this floor nothing on the board
   * ever died and the probe reported "decay actually bites" as false — a decay system that never
   * takes anything is decoration, and Gate 4 asks for two systems that FIGHT. */
  const MOISTURE_FLOOR = 0.25;

  function isColonised(c) { return c.density > 0.001; }

  function colonisedCount(s) {
    let n = 0;
    for (const c of s.cells) if (isColonised(c)) n++;
    return n;
  }

  /** Chebyshev distance to the nearest anchor (a spring or a fruiting body). Drives spread cost. */
  function distToAnchor(s, x, y) {
    let best = 99;
    for (const c of s.cells) {
      if (!c.spring && !c.fruit) continue;
      const d = Math.max(Math.abs(c.x - x), Math.abs(c.y - y));
      if (d < best) best = d;
    }
    return best;
  }

  function bandUnlocked(s, bandId) { return !!s.unlocked[bandId]; }

  /** Can the player colonise this cell right now, and if not, exactly why. */
  function spreadInfo(s, x, y) {
    if (!inBounds(x, y)) return { ok: false, why: 'off the board' };
    const c = s.cells[idx(x, y)];
    if (isColonised(c)) return { ok: false, why: 'already yours' };
    if (!bandUnlocked(s, c.bandId)) return { ok: false, why: `${D.BAND_BY_ID[c.bandId].name} needs an enzyme` };
    let adjacent = false;
    for (const [dx, dy] of NEIGHBOURS) {
      if (!inBounds(x + dx, y + dy)) continue;
      if (isColonised(s.cells[idx(x + dx, y + dy)])) { adjacent = true; break; }
    }
    if (!adjacent) return { ok: false, why: 'not touching your network' };
    /* Mould makes ground expensive to take rather than impossible — the second half of giving the
     * mould teeth. Before this it grew, spread, and did absolutely nothing to the player, which is
     * a system in name only and would have failed Gate 4 on inspection. */
    const base = D.spreadCost(D.BAND_BY_ID[c.bandId], distToAnchor(s, x, y), s.spore.cords || 0);
    const cost = Math.ceil(base * (1 + 1.2 * c.mould));
    if (s.biomass < cost) return { ok: false, why: `needs ${cost} biomass`, cost, mould: c.mould };
    return { ok: true, cost, mould: c.mould };
  }

  function spread(s, x, y) {
    const info = spreadInfo(s, x, y);
    if (!info.ok) return info;
    s.biomass -= info.cost;
    s.cells[idx(x, y)].density = 0.12;
    return { ok: true, cost: info.cost };
  }

  function fruitInfo(s, x, y) {
    if (!inBounds(x, y)) return { ok: false, why: 'off the board' };
    const c = s.cells[idx(x, y)];
    if (c.fruit) return { ok: false, why: 'already fruited' };
    if (c.density < D.FRUIT_DENSITY) return { ok: false, why: `needs density ${D.FRUIT_DENSITY.toFixed(2)}` };
    /* ⛔ SPACING. The campaign probe ended with 108 fruiting bodies on a 176-cell board — 61% of
     * the world was mushrooms. Every verdict passed and the picture was nonsense: a fruiting body
     * is meant to be a LANDMARK, it carries one of the 48 generated forms, and it anchors the
     * moisture field. Crowding them made each one worthless and the board unreadable.
     * ⭐ It also fixes a design hole. This game's Gate 2 claim is that it is SPATIAL — that where
     * you act is the decision — and without spacing the answer to "where should I fruit?" was
     * "everywhere, eventually". Now a fruiting body claims a territory. */
    for (const o of s.cells) {
      if (!o.fruit) continue;
      if (Math.max(Math.abs(o.x - x), Math.abs(o.y - y)) < D.FRUIT_SPACING) {
        return { ok: false, why: `too close to the ${D.BAND_BY_ID[o.fruit.bandId].name} fruiting body at ${o.x + 1},${o.y + 1}` };
      }
    }
    const cost = D.fruitCost(s.fruitings);
    if (s.biomass < cost) return { ok: false, why: `needs ${cost} biomass`, cost };
    return { ok: true, cost, spores: D.sporeYield(c.density, D.BAND_BY_ID[c.bandId]) };
  }

  /**
   * FRUITING — the prestige action, and the one that never wipes the board.
   *
   * It costs biomass and it drains density from the cell and its ring, so it is a real sacrifice
   * rather than a free button. What it buys is permanent: spores, and an ANCHOR that both wets the
   * ground around it and makes spreading nearby cheaper. The board only ever grows.
   */
  function fruit(s, x, y) {
    const info = fruitInfo(s, x, y);
    if (!info.ok) return info;
    const c = s.cells[idx(x, y)];
    s.biomass -= info.cost;
    const gained = info.spores;
    s.spores += gained;
    s.totalSpores += gained;
    s.fruitings += 1;
    // 48 distinct forms: 6 cap families x 8 palettes, chosen from the cell so it is stable forever
    const h = ((x * 73856093) ^ (y * 19349663) ^ (s.fruitings * 83492791)) >>> 0;
    c.fruit = { form: h % 6, palette: (h >>> 8) % 8, bandId: c.bandId };
    c.density = Math.max(0.08, c.density - D.FRUIT_DRAIN);
    for (const [dx, dy] of NEIGHBOURS) {
      if (!inBounds(x + dx, y + dy)) continue;
      const n = s.cells[idx(x + dx, y + dy)];
      if (isColonised(n)) n.density = Math.max(0.05, n.density - D.FRUIT_DRAIN * 0.5);
    }
    recomputeMoisture(s);
    return { ok: true, spores: gained };
  }

  function buySpore(s, id) {
    const u = D.SPORE_UPGRADES.find((x) => x.id === id);
    if (!u) return { ok: false, why: 'no such upgrade' };
    const lvl = s.spore[id] || 0;
    if (lvl >= u.max) return { ok: false, why: 'maxed' };
    const cost = u.cost(lvl);
    if (s.spores < cost) return { ok: false, why: `needs ${cost} spores`, cost };
    s.spores -= cost;
    s.spore[id] = lvl + 1;
    if (u.unlocks) s.unlocked[u.unlocks] = true;
    recomputeMoisture(s);
    return { ok: true, cost };
  }

  function buyBio(s, id) {
    const u = D.BIOMASS_UPGRADES.find((x) => x.id === id);
    if (!u) return { ok: false, why: 'no such upgrade' };
    const lvl = s.bio[id] || 0;
    const cost = D.biomassCost(u, lvl);
    if (s.biomass < cost) return { ok: false, why: `needs ${cost} biomass`, cost };
    if (id === 'seep') {
      const target = driestOwnedCell(s);
      if (!target) return { ok: false, why: 'no colonised cell to open a spring on' };
      s.biomass -= cost;
      target.spring = true;
      s.bio[id] = lvl + 1;
      recomputeMoisture(s);
      return { ok: true, cost, at: { x: target.x, y: target.y } };
    }
    s.biomass -= cost;
    s.bio[id] = lvl + 1;
    return { ok: true, cost };
  }

  /** The colonised cell with the least moisture — where a new spring does the most good. */
  function driestOwnedCell(s) {
    let best = null, bestM = Infinity;
    for (const c of s.cells) {
      if (!isColonised(c) || c.spring) continue;
      const m = moistureAt(s, c);
      if (m < bestM) { bestM = m; best = c; }
    }
    return best;
  }

  function digestMultiplier(s) {
    const potency = D.BIOMASS_UPGRADES.find((u) => u.id === 'potency');
    return Math.pow(1 + potency.step, s.bio.potency || 0) * (1 + 0.16 * (s.spore.appetite || 0));
  }

  function growthMultiplier(s) {
    const turgor = D.BIOMASS_UPGRADES.find((u) => u.id === 'turgor');
    return Math.pow(1 + turgor.step, s.bio.turgor || 0);
  }

  /**
   * One simulation step. `dt` is seconds. Returns a small summary the HUD reads, so the renderer
   * never has to walk the board to answer "how am I doing".
   *
   * ⚠️ Called both at frame rate and, with a large dt, by the offline catch-up. Everything here is
   * therefore rate-based and dt-linear, EXCEPT the mould spread roll, which is probability per
   * second and is applied as an expected value so that one 8-hour step and 28,800 one-second steps
   * do not produce wildly different worlds.
   */
  function step(s, dt) {
    if (!(dt > 0)) return { gained: 0, colonised: 0, drying: 0 };
    const cap = D.densityCap(s.spore.density || 0);
    const dry = D.dryRate(s.spore.retention || 0);
    const digest = digestMultiplier(s);
    const grow = growthMultiplier(s);
    let gained = 0, colonised = 0, drying = 0, spent = 0;

    for (const c of s.cells) {
      const band = D.BAND_BY_ID[c.bandId];
      if (isColonised(c)) {
        colonised++;
        const m = moistureAt(s, c);

        // 1. DIGESTION — finite nutrient, so a cell is a diminishing asset and you must move on.
        //    Mould in the cell steals part of the yield: that is what gives it teeth.
        const rate = c.density * band.yield * digest * (1 - 0.55 * c.mould);
        if (c.nutrient > 0) {
          const take = Math.min(c.nutrient === Infinity ? Infinity : c.nutrient, rate * dt);
          if (c.nutrient !== Infinity) c.nutrient -= take;
          gained += take;
        } else {
          spent++;
          /* ⛔ RESIDUAL YIELD, AND IT EXISTS TO KILL A SOFT-LOCK THE CAMPAIGN PROBE FOUND.
           * With exhaustion total, a board that had eaten everything produced exactly ZERO income
           * — and the only route forward (fruit -> spores -> next band) costs more with every
           * fruiting, so the probe ended holding 983 biomass needing 1,190, permanently, with no
           * action available. That is §3f's "wall with a date on it": a permanent penalty with no
           * answer the player can reach.
           * Litterfall never stops, so spent ground still pays a thin 6%. Expanding remains
           * enormously better — the trickle is a floor, not a strategy. */
          gained += rate * dt * RESIDUAL;
        }

        /* 2. DENSITY — ⛔ REDESIGNED, AND THIS IS A DESIGN FIX RATHER THAN A DIAL.
         *
         * Version 1 was a CLIFF: at or above MOISTURE_NEED a cell grew to the cap, below it the
         * cell drained to zero and died. The campaign probe showed what that produces — a hard
         * boundary a couple of cells from each spring, no gradient, no marginal ground, and a
         * board permanently capped at about twenty cells. "Spread versus decay" was not a tension
         * at all; it was a fence.
         *
         * Now moisture sets a TARGET density and the cell moves toward it. Dry ground is still
         * punished — it just holds a thin, low-yield network instead of nothing — so the frontier
         * is a gradient the player can read and push, and reaching water is what makes ground
         * good rather than what makes it legal. Only genuinely bone-dry ground kills.
         */
        const wetness = Math.min(1, m / MOISTURE_NEED);
        const target = wetness < MOISTURE_FLOOR ? 0 : cap * wetness;
        if (c.density < target) {
          c.density = Math.min(target, c.density + D.DENSITY_GROWTH * grow * dt * (0.4 + 0.6 * (c.nutrient > 0 ? 1 : 0.25)));
        } else if (c.density > target) {
          drying++;
          c.density = Math.max(target, c.density - dry * (1 - wetness) * dt);
          if (target <= 0.001 && c.density < 0.02) { c.density = 0; c.mould = Math.max(c.mould, 0.2); s.lost++; }
        }

        // 3. MOULD is pushed back by a dense neighbour — being strong nearby is the answer to it.
        if (c.mould > 0) c.mould = Math.max(0, c.mould - 0.05 * c.density * dt);
      } else if (c.mould > 0) {
        c.mould = Math.min(1, c.mould + 0.012 * dt);
      }
    }

    // 4. MOULD SPREAD — expected-value form so a long offline step behaves like many short ones.
    const spreadChance = 1 - Math.exp(-0.02 * dt);
    for (const c of s.cells) {
      if (c.mould < 0.35) continue;
      for (const [dx, dy] of NEIGHBOURS) {
        if (!inBounds(c.x + dx, c.y + dy)) continue;
        const n = s.cells[idx(c.x + dx, c.y + dy)];
        if (n.fruit) continue;                       // a fruiting body holds its ground permanently
        if (n.density > 0.25) continue;              // dense hyphae are not invaded
        n.mould = Math.min(1, n.mould + spreadChance * 0.5);
      }
    }

    /* 5. FRUITING BODIES KEEP RELEASING SPORES. Once spacing capped the count, one-shot fruitings
     *    could no longer fund the upgrade tree — so a fruiting body is now a permanent, slow spore
     *    source rather than a single payout. That is both better economics and a better fiction:
     *    a mushroom sheds for as long as it stands. It also makes the placement decision matter
     *    twice, since a body in a rich band keeps paying a rich band's rate forever.
     *    ⚠️ Fractional spores accumulate in `sporeBank` so a long offline step cannot round to
     *    zero on every body and silently pay nothing. */
    let trickle = 0;
    for (const c of s.cells) {
      if (!c.fruit) continue;
      const band = D.BAND_BY_ID[c.fruit.bandId];
      trickle += D.SPORE_TRICKLE * (0.5 + band.yield * 0.35) * (0.4 + 0.6 * c.density) * dt;
    }
    s.sporeBank += trickle;
    if (s.sporeBank >= 1) {
      const whole = Math.floor(s.sporeBank);
      s.sporeBank -= whole;
      s.spores += whole;
      s.totalSpores += whole;
    }

    s.biomass += gained;
    s.elapsed += dt;
    if (colonised > s.peakColonised) s.peakColonised = colonised;
    return { gained, colonised, drying, spent };
  }

  /**
   * Offline catch-up. Capped, and run as a handful of coarse steps rather than one giant one so
   * that density growth and drying still interleave in roughly the right order.
   *
   * ⚠️ Returns what it did so the UI can TELL the player. An idle game that silently hands you a
   * pile of currency reads as a bug; the same event narrated reads as a reward.
   */
  function catchUp(s, seconds) {
    const capped = Math.max(0, Math.min(seconds, D.OFFLINE_CAP_HOURS * 3600));
    if (capped < 1) return { seconds: 0, gained: 0, capped: false };
    const before = s.biomass;
    const chunks = 24;
    for (let i = 0; i < chunks; i++) step(s, capped / chunks);
    return { seconds: capped, gained: s.biomass - before, capped: seconds > capped };
  }

  const API = {
    COLS, ROWS, idx, inBounds, NEIGHBOURS, MOISTURE_NEED,
    createState, recomputeMoisture, moistureAt, isColonised, colonisedCount,
    distToAnchor, spreadInfo, spread, fruitInfo, fruit,
    buySpore, buyBio, driestOwnedCell, digestMultiplier, growthMultiplier,
    step, catchUp, bandUnlocked,
  };

  if (typeof module === 'object' && module.exports) module.exports = API;
  else root.GRID = API;
})(typeof self !== 'undefined' ? self : this);
