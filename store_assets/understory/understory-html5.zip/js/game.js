/**
 * game.js — wiring: the frame loop, the renderer, input, and the screens.
 *
 * LAYOUT, and it is fixed on purpose (wing §3d: TEST AT THE SIZE THE PLAYER ACTUALLY GETS).
 * Canvas is 960x620 and the itch embed is declared at 960x680, so there is real page below the
 * canvas and nothing of ours can sit on the game's own footer.
 *
 *   board      16 x 11 cells of 40px  -> 640 x 440 at (18, 96)
 *   header     y 0..88
 *   panel      x 676..944, the upgrade and inspector column
 *   footer     y 552..612, the readouts
 */
(function () {
  'use strict';

  const D = window.BANDS_DATA;
  const G = window.GRID;
  const A = window.ART;
  const F = window.FUNGUS;
  const S = window.SAVE;
  const SFX = window.SOUND;

  const W = 960, H = 620;
  const CELL = 40;
  const BX = 18, BY = 96;
  const PX = 676, PW = 268;

  const canvas = document.getElementById('c');
  const ctx = canvas.getContext('2d', { alpha: false });

  let state = G.createState();
  let hover = null;          // {x,y}
  let selected = null;       // {x,y} inspected cell
  let mode = 'play';         // play | help | welcome
  let toast = null;          // { text, until }
  let clock = 0;
  let lastFrame = 0;
  let offlineReport = null;
  let panelTab = 'spores';   // spores | biomass

  /* ── boot: load, catch up, and TELL the player what happened while they were away ─────────── */
  function boot() {
    const loaded = S.load(state);
    G.recomputeMoisture(state);
    if (loaded.ok) {
      const away = Math.max(0, (Date.now() - loaded.savedAt) / 1000);
      const r = G.catchUp(state, away);
      if (r.seconds > 60) offlineReport = r;
      mode = 'play';
    } else {
      mode = 'welcome';
    }
  }

  /* ── helpers ──────────────────────────────────────────────────────────────────────────────── */

  const cellAt = (mx, my) => {
    const x = Math.floor((mx - BX) / CELL), y = Math.floor((my - BY) / CELL);
    return G.inBounds(x, y) ? { x, y } : null;
  };

  function fmt(n) {
    if (n < 1000) return n.toFixed(n < 10 ? 1 : 0);
    if (n < 1e6) return (n / 1000).toFixed(2) + 'k';
    if (n < 1e9) return (n / 1e6).toFixed(2) + 'M';
    return (n / 1e9).toFixed(2) + 'B';
  }

  function say(text) { toast = { text, until: clock + 2.8 }; }

  function duration(sec) {
    const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60);
    if (h > 0) return `${h}h ${m}m`;
    if (m > 0) return `${m}m`;
    return `${Math.floor(sec)}s`;
  }

  /* ── input ────────────────────────────────────────────────────────────────────────────────── */

  canvas.addEventListener('mousemove', (e) => {
    const r = canvas.getBoundingClientRect();
    const mx = (e.clientX - r.left) * (W / r.width);
    const my = (e.clientY - r.top) * (H / r.height);
    hover = cellAt(mx, my);
    window.__mx = mx; window.__my = my;
  });
  canvas.addEventListener('mouseleave', () => { hover = null; });

  canvas.addEventListener('click', (e) => {
    SFX.unlock();
    const r = canvas.getBoundingClientRect();
    const mx = (e.clientX - r.left) * (W / r.width);
    const my = (e.clientY - r.top) * (H / r.height);

    if (mode === 'welcome' || mode === 'help') { mode = 'play'; offlineReport = null; return; }

    // panel tabs
    if (my > 96 && my < 122 && mx > PX && mx < PX + PW) {
      panelTab = mx < PX + PW / 2 ? 'spores' : 'biomass';
      return;
    }
    // panel rows
    if (mx > PX && mx < PX + PW && my > 126 && my < 546) {
      const list = panelTab === 'spores' ? D.SPORE_UPGRADES : D.BIOMASS_UPGRADES;
      const i = Math.floor((my - 130) / 50);
      if (i >= 0 && i < list.length) {
        const u = list[i];
        const res = panelTab === 'spores' ? G.buySpore(state, u.id) : G.buyBio(state, u.id);
        if (res.ok) {
          if (u.unlocks) { SFX.unlockBand(); say(`${D.BAND_BY_ID[u.unlocks].name} is open`); }
          else { SFX.buy(); say(`${u.name} bought`); }
          S.save(state);
        } else { SFX.deny(); say(res.why || 'cannot buy that'); }
      }
      return;
    }
    // help button
    if (mx > W - 96 && mx < W - 18 && my > 18 && my < 46) { mode = 'help'; return; }

    const c = cellAt(mx, my);
    if (!c) return;
    selected = c;
    const cell = state.cells[G.idx(c.x, c.y)];

    if (G.isColonised(cell)) {
      const fi = G.fruitInfo(state, c.x, c.y);
      if (fi.ok) {
        const r2 = G.fruit(state, c.x, c.y);
        SFX.fruit();
        say(`fruited — ${r2.spores} spores`);
        S.save(state);
      } else { SFX.deny(); say(fi.why); }
    } else {
      const si = G.spreadInfo(state, c.x, c.y);
      if (si.ok) { G.spread(state, c.x, c.y); SFX.spread(); S.save(state); }
      else { SFX.deny(); say(si.why); }
    }
  });

  window.addEventListener('keydown', (e) => {
    if (e.key === '?' || e.key === 'h' || e.key === 'H') mode = mode === 'help' ? 'play' : 'help';
    if (e.key === 'Escape') { mode = 'play'; offlineReport = null; }
    if (e.key === 'm' || e.key === 'M') { SFX.setEnabled(!SFX.isEnabled()); say(SFX.isEnabled() ? 'sound on' : 'sound off'); }
  });

  /* ── render ───────────────────────────────────────────────────────────────────────────────── */

  function drawBoard() {
    for (const c of state.cells) {
      const x = BX + c.x * CELL, y = BY + c.y * CELL;
      const band = D.BAND_BY_ID[c.bandId];
      A.substrate(ctx, band.plate, x, y, CELL, CELL);

      /* ⚠️ EVERY WASH ON THIS BOARD IS DELIBERATELY WEAK NOW. The first version stacked a 0.66
       * locked overlay, a moisture tint and a 0.34 exhaustion overlay on top of the plates, and the
       * captured frame showed the result: five carefully built substrates rendered as five
       * identical dark grey squares. Litter, deadwood and bone were not tellable apart. The plate
       * IS the art (§0-ART); anything drawn over it has to earn its opacity. */
      if (!state.unlocked[c.bandId]) {
        ctx.fillStyle = 'rgba(6,10,8,0.46)';
        ctx.fillRect(x, y, CELL, CELL);
      } else {
        const m = Math.min(1, G.moistureAt(state, c) / G.MOISTURE_NEED);
        if (m > 0.02) {
          ctx.fillStyle = `rgba(96,160,182,${0.03 + m * 0.09})`;
          ctx.fillRect(x, y, CELL, CELL);
        }
        // exhausted ground goes ashen — readable at a glance, but the substrate still shows
        if (c.nutrient !== Infinity && c.nutrient <= 0) {
          ctx.fillStyle = 'rgba(24,26,20,0.20)';
          ctx.fillRect(x, y, CELL, CELL);
        }
      }

      /* ⚠️ Mould is not drawn on ground the player cannot touch. A locked band rendered its mould
       * anyway, so the whole STONE row captured as a field of blue-green static — noise reporting
       * a system the player has no way to act on yet. */
      if (state.unlocked[c.bandId]) A.mould(ctx, x, y, CELL, CELL, c.mould, (c.x * 31 + c.y * 17) >>> 0);
      if (c.spring) A.spring(ctx, x, y, CELL, CELL, clock);
      // link mask: which orthogonal neighbours are also ours, so the network draws as connected
      let links = 0;
      for (let i = 0; i < G.NEIGHBOURS.length; i++) {
        const [dx, dy] = G.NEIGHBOURS[i];
        if (G.inBounds(c.x + dx, c.y + dy) && G.isColonised(state.cells[G.idx(c.x + dx, c.y + dy)])) links |= (1 << i);
      }
      A.hyphae(ctx, x, y, CELL, CELL, c.density, (c.x * 73856093 ^ c.y * 19349663) >>> 0, clock, links, c.x, c.y);
      if (c.fruit) F.draw(ctx, c.fruit.form, c.fruit.palette, x + CELL / 2, y + CELL / 2 - 2, CELL * 0.92, clock);

      /* Nutrient remaining, as a hairline along the bottom edge.
       *
       * ⛔ THIS WAS A 3px BRIGHT GREEN BAR IN EVERY COLONISED CELL and it was rejected on sight in
       * the board detail plate: a hundred saturated green bars on a 40px grid read as a
       * SPREADSHEET, and they fought the mycelium for attention on a board whose whole subject is
       * the mycelium. The full-screen shots hid it — at that size the bars are small. The detail
       * crop is what made it obvious, which is the argument for having one in the gallery.
       *
       * Two changes: it is quiet, and IT ONLY APPEARS ONCE IT MEANS SOMETHING. Above 85% the cell
       * is effectively untouched and the bar would be pure noise, so it is not drawn at all — the
       * indicator arrives exactly when the ground starts running out, which is when the player has
       * a decision to make about it. */
      if (state.unlocked[c.bandId] && c.nutrient !== Infinity && G.isColonised(c)) {
        const frac = Math.max(0, Math.min(1, c.nutrient / band.nutrient));
        if (frac > 0.004 && frac < 0.85) {
          ctx.save();
          ctx.globalAlpha = 0.62;
          ctx.fillStyle = 'rgba(0,0,0,0.5)';
          ctx.fillRect(x + 5, y + CELL - 4, CELL - 10, 2);
          ctx.fillStyle = frac > 0.35 ? '#8aa860' : '#b8913f';
          ctx.fillRect(x + 5, y + CELL - 4, (CELL - 10) * frac, 2);
          ctx.restore();
        }
      }

      /* A hairline, not a grid. At 0.30 the board read as a spreadsheet and the cell edges competed
       * with the network for attention; the cells are legible from the substrate seams anyway. */
      ctx.strokeStyle = 'rgba(0,0,0,0.13)';
      ctx.lineWidth = 1;
      ctx.strokeRect(x + 0.5, y + 0.5, CELL - 1, CELL - 1);
    }

    // band labels down the left edge of the board area
    for (const b of D.BANDS) {
      const y0 = BY + b.rows[0] * CELL, y1 = BY + (b.rows[1] + 1) * CELL;
      ctx.save();
      ctx.translate(BX - 6, (y0 + y1) / 2);
      ctx.rotate(-Math.PI / 2);
      A.text(ctx, b.name.toUpperCase(), 0, 0, {
        size: 10, align: 'center', baseline: 'middle', sans: true,
        colour: state.unlocked[b.id] ? 'rgba(206,214,190,0.75)' : 'rgba(150,150,140,0.35)',
      });
      ctx.restore();
    }

    // hover affordance
    if (hover && mode === 'play') {
      const x = BX + hover.x * CELL, y = BY + hover.y * CELL;
      const cell = state.cells[G.idx(hover.x, hover.y)];
      const info = G.isColonised(cell) ? G.fruitInfo(state, hover.x, hover.y) : G.spreadInfo(state, hover.x, hover.y);
      ctx.strokeStyle = info.ok ? 'rgba(232,226,200,0.92)' : 'rgba(210,120,100,0.75)';
      ctx.lineWidth = 2;
      ctx.strokeRect(x + 1, y + 1, CELL - 2, CELL - 2);
    }
  }

  function drawHeader() {
    A.panel(ctx, 0, 0, W, 88, 0.55);
    A.text(ctx, 'UNDERSTORY', 18, 40, { size: 30, weight: 600, colour: '#e9e2cd', shadow: true });
    A.text(ctx, 'the forest floor eats everything. you are what does the eating.', 18, 62,
      { size: 12, colour: 'rgba(200,206,184,0.72)' });

    const stats = [
      ['BIOMASS', fmt(state.biomass)],
      ['SPORES', String(state.spores)],
      ['NETWORK', `${G.colonisedCount(state)}/${state.cells.length}`],
      ['FRUITINGS', String(state.fruitings)],
    ];
    let x = 470;
    for (const [label, value] of stats) {
      A.text(ctx, label, x, 34, { size: 10, sans: true, colour: 'rgba(184,196,170,0.72)' });
      A.text(ctx, value, x, 58, { size: 20, weight: 600, colour: '#f0e8d2' });
      x += 100;
    }

    A.panel(ctx, W - 96, 18, 78, 28, 0.3);
    A.text(ctx, 'HELP  ?', W - 57, 37, { size: 12, align: 'center', sans: true, colour: '#dfe4d2' });
  }

  function drawPanel() {
    A.panel(ctx, PX, 96, PW, 450, 0.5);

    // tabs
    const tabs = [['spores', `SPORES  ${state.spores}`], ['biomass', `BIOMASS  ${fmt(state.biomass)}`]];
    tabs.forEach(([id, label], i) => {
      const tx = PX + i * (PW / 2);
      if (panelTab === id) { ctx.fillStyle = 'rgba(120,150,110,0.22)'; ctx.fillRect(tx, 96, PW / 2, 26); }
      A.text(ctx, label, tx + PW / 4, 114, {
        size: 11, align: 'center', sans: true, weight: panelTab === id ? 600 : 400,
        colour: panelTab === id ? '#eef2e0' : 'rgba(190,198,176,0.6)',
      });
    });
    ctx.strokeStyle = 'rgba(150,168,140,0.20)';
    ctx.beginPath(); ctx.moveTo(PX, 122.5); ctx.lineTo(PX + PW, 122.5); ctx.stroke();

    const list = panelTab === 'spores' ? D.SPORE_UPGRADES : D.BIOMASS_UPGRADES;
    for (let i = 0; i < list.length; i++) {
      const u = list[i];
      const y = 130 + i * 50;
      const isSpore = panelTab === 'spores';
      const lvl = isSpore ? (state.spore[u.id] || 0) : (state.bio[u.id] || 0);
      const maxed = isSpore && lvl >= u.max;
      const cost = maxed ? 0 : (isSpore ? u.cost(lvl) : D.biomassCost(u, lvl));
      const afford = maxed ? false : (isSpore ? state.spores >= cost : state.biomass >= cost);

      const rowHover = window.__mx > PX && window.__mx < PX + PW && window.__my > y && window.__my < y + 46;
      if (rowHover && !maxed) { ctx.fillStyle = 'rgba(160,190,140,0.10)'; ctx.fillRect(PX + 2, y, PW - 4, 46); }

      const nameColour = maxed ? 'rgba(150,170,140,0.5)' : (afford ? '#f0f2e0' : 'rgba(206,210,190,0.55)');
      A.text(ctx, u.name, PX + 10, y + 15, { size: 13, weight: 600, colour: nameColour });

      const badge = isSpore ? (maxed ? 'MAX' : `${lvl}/${u.max}`) : `Lv ${lvl}`;
      A.text(ctx, badge, PX + PW - 10, y + 15, { size: 11, align: 'right', sans: true, colour: 'rgba(190,200,176,0.7)' });

      /* ⛔ THE COST LABEL'S WIDTH IS MEASURED, AND THE DESCRIPTION COLUMN IS DERIVED FROM IT.
       * The layout gate caught "24119932307 biomass" running into "Opens a permanent spring on
       * the" by 8px: a geometric cost reaches eleven digits late in a real game, and a description
       * column hard-coded at PW-96 cannot know that. Two fixes, both needed — fmt() so the number
       * is readable at all, and a column width that is whatever is actually left over. */
      let costW = 0;
      if (!maxed) {
        const costLabel = isSpore ? `${cost} spores` : `${fmt(cost)} biomass`;
        costW = A.width(ctx, costLabel, { size: 11, sans: true, weight: 600 });
        A.text(ctx, costLabel, PX + PW - 10, y + 33,
          { size: 11, align: 'right', sans: true, weight: 600, colour: afford ? '#a8d07a' : 'rgba(200,130,110,0.85)' });
      }
      A.paragraph(ctx, u.desc, PX + 10, y + 30, Math.max(60, PW - 26 - costW),
        { size: 10, lineHeight: 12, colour: 'rgba(186,194,170,0.66)' });
    }

    // inspector
    A.panel(ctx, PX, 552, PW, 60, 0.5);
    if (selected) {
      const c = state.cells[G.idx(selected.x, selected.y)];
      const band = D.BAND_BY_ID[c.bandId];
      A.text(ctx, `${band.name}  ${selected.x + 1},${selected.y + 1}`, PX + 10, 570,
        { size: 12, weight: 600, colour: '#e8ecd8' });
      const m = G.moistureAt(state, c);
      const bits = [
        `density ${c.density.toFixed(2)}`,
        `moisture ${(m / G.MOISTURE_NEED * 100).toFixed(0)}%`,
        c.nutrient === Infinity ? 'inexhaustible' : `food ${Math.max(0, c.nutrient).toFixed(0)}`,
      ];
      if (c.mould > 0.05) bits.push(`mould ${(c.mould * 100).toFixed(0)}%`);
      A.paragraph(ctx, bits.join('   ·   '), PX + 10, 588, PW - 20,
        { size: 10, lineHeight: 12, sans: true, colour: 'rgba(190,200,176,0.75)' });
    } else {
      A.paragraph(ctx, 'Click bare ground beside your network to spread. Click a dense cell to fruit.',
        PX + 10, 570, PW - 20, { size: 11, lineHeight: 14, colour: 'rgba(190,200,176,0.7)' });
    }
  }

  function drawFooter() {
    A.panel(ctx, 0, 552, 658, 60, 0.5);
    const c = hover ? state.cells[G.idx(hover.x, hover.y)] : null;
    if (c) {
      const band = D.BAND_BY_ID[c.bandId];
      let line;
      if (!state.unlocked[c.bandId]) line = `${band.name} — locked. ${band.blurb}`;
      else if (G.isColonised(c)) {
        const fi = G.fruitInfo(state, hover.x, hover.y);
        line = fi.ok ? `Fruit here: ${fi.cost} biomass for about ${fi.spores} spores, and a permanent anchor.`
          : `Yours. Cannot fruit yet — ${fi.why}.`;
      } else {
        const si = G.spreadInfo(state, hover.x, hover.y);
        line = si.ok ? `Spread here for ${si.cost} biomass.` : `Cannot spread — ${si.why}.`;
      }
      A.paragraph(ctx, line, 14, 574, 630, { size: 13, lineHeight: 17, colour: '#dfe4d0' });
    } else {
      A.paragraph(ctx, `${duration(state.elapsed)} of growth   ·   ${state.totalSpores} spores earned   ·   ` +
        `${state.cells.filter((q) => q.fruit).length} fruiting bodies standing   ·   press H for help, M for sound`,
        14, 574, 630, { size: 12, lineHeight: 16, colour: 'rgba(190,200,176,0.72)' });
    }
  }

  /**
   * ⛔ THE BACKDROP IS FULL-BLEED, AND THAT WAS A GATE 1 CORRECTION.
   * Version 1 laid an 0.86 scrim over the whole canvas and let the BOARD show through — but the
   * board is 640x440 in a 960x620 frame, so the right third and the bottom strip were pure black.
   * Opened for the Gate 1 review, the welcome screen was a text box floating on nothing, and the
   * honest answer to "is more than ~20% of this empty" was yes.
   * Now the game's own substrate plates cover the frame edge to edge with a row of its own
   * fruiting bodies along the foot: the screen is made of the product rather than of a scrim.
   */
  function drawOverlay(title, body, footer) {
    const p = A.pattern(ctx, 'litter');
    if (p) { ctx.fillStyle = p; ctx.fillRect(0, 0, W, H); }
    else { ctx.fillStyle = '#2a2018'; ctx.fillRect(0, 0, W, H); }
    // a band of deadwood along the foot, so the backdrop has structure rather than one flat tone
    A.substrate(ctx, 'deadwood', 0, H - 96, W, 96);
    ctx.fillStyle = 'rgba(7,10,8,0.70)';
    ctx.fillRect(0, 0, W, H);

    for (let i = 0; i < 11; i++) F.draw(ctx, (i * 5) % 6, (i * 3) % 8, 46 + i * 87, H - 42, 62, clock);

    const boxW = 660, boxX = (W - boxW) / 2;
    A.panel(ctx, boxX, 54, boxW, 452, 0.44);
    A.text(ctx, title, W / 2, 104, { size: 30, weight: 600, align: 'center', colour: '#eee7d2', shadow: true });
    let y = 148;
    for (const para of body) {
      y += A.paragraph(ctx, para, boxX + 34, y, boxW - 68, { size: 14, lineHeight: 21, colour: '#dae0ca' }) + 12;
    }
    A.text(ctx, footer, W / 2, 484, { size: 12, align: 'center', sans: true, colour: 'rgba(196,206,180,0.78)' });
  }

  function draw() {
    ctx.fillStyle = '#0b0d0c';
    ctx.fillRect(0, 0, W, H);

    if (!A.artLoaded()) {
      A.text(ctx, `loading the forest floor… ${A.loadedCount()}/${A.PLATES.length}`, W / 2, H / 2,
        { size: 16, align: 'center', colour: '#c8cfb8' });
      return;
    }

    /* ⛔ THE CHROME IS NOT DRAWN BEHIND A FULL-SCREEN OVERLAY, and that is a layout decision the
     * gate forced. It reported the welcome copy overprinting the upgrade panel's descriptions by
     * 65px — true, and invisible to the eye because an 0.86 scrim sits between them. §3c-6 settled
     * how to answer that: "a string drawn under another string IS an overprint to anything that can
     * measure it — visibility is not in the recorder's reach and should not be", and the honest fix
     * is not to teach the gate about opacity but to stop drawing text nobody is meant to read.
     * The BOARD still shows through, which is the part that was doing the work anyway. */
    const overlay = mode === 'welcome' || mode === 'help';
    if (!overlay) {
      drawBoard();
      drawHeader();
      drawPanel();
      drawFooter();
    }

    if (!overlay && toast && clock < toast.until) {
      const w = A.width(ctx, toast.text, { size: 14 }) + 34;
      A.panel(ctx, (658 - w) / 2, 508, w, 32, 0.24);
      A.text(ctx, toast.text, 329, 529, { size: 14, align: 'center', colour: '#f0ecd8' });
    }

    if (mode === 'welcome') {
      drawOverlay('UNDERSTORY', [
        'You are the mycelium under a forest floor. Spread through the litter, digest what you reach, and fruit when you can afford to.',
        'SPREAD costs biomass and only works next to ground you already hold. DECAY is the other half: moisture falls away from springs and fruiting bodies, and dry ground holds only a thin network. Push too far from water and the frontier thins out behind you.',
        'FRUITING is how you make spores, and it never wipes your board. It spends biomass and thins the ground around it, and in return you get a permanent fruiting body that waters and anchors everything near it — and keeps shedding spores for as long as it stands.',
        'Spores buy the enzymes that open deadwood, bone and bare stone. Nothing here is ever lost; close the tab and the network keeps growing.',
      ], 'click anywhere to begin');
    } else if (mode === 'help') {
      drawOverlay('HOW IT WORKS', [
        'CLICK bare ground touching your network to spread onto it. Harder substrate costs more, and so does ground far from a spring or fruiting body — Rhizomorph Cords reduce that distance penalty.',
        'CLICK a cell you already hold to FRUIT it, once it is dense enough. Fruiting bodies must stand at least three cells apart, so where you put them is the real decision.',
        'MOISTURE sets how dense a cell can get, and density multiplies everything: yield, and the spores a fruiting pays. The blue wash on the board is the moisture field.',
        'Ground you have eaten out goes ashen and keeps paying a small trickle for ever. Rival MOULD creeps into thin and spent ground, stealing yield and making that ground expensive to retake — grow dense beside it to push it back.',
        'H toggles this screen. M toggles sound. The game saves itself, and keeps growing for up to eight hours while you are away.',
      ], 'click anywhere to close');
    }

    if (offlineReport && mode === 'play') {
      const r = offlineReport;
      ctx.fillStyle = 'rgba(6,9,7,0.72)';
      ctx.fillRect(0, 0, W, H);
      A.panel(ctx, 220, 210, 520, 200, 0.45);
      A.text(ctx, 'WHILE YOU WERE AWAY', W / 2, 258, { size: 22, weight: 600, align: 'center', colour: '#eee7d2' });
      A.paragraph(ctx, `The network kept growing for ${duration(r.seconds)}` +
        (r.capped ? ' — the most it carries on its own is eight hours.' : '.') +
        ` It digested ${fmt(r.gained)} biomass while you were gone.`,
        256, 296, 448, { size: 14, lineHeight: 21, align: 'left', colour: '#d6dcc6' });
      A.text(ctx, 'click to carry on', W / 2, 384, { size: 12, align: 'center', sans: true, colour: 'rgba(190,200,176,0.72)' });
    }
  }

  /* ── loop ─────────────────────────────────────────────────────────────────────────────────── */

  let saveTimer = 0;
  /* ⛔ RENDER PAUSE, and it exists for exactly one reason (wing §3c-7): "A CAPTURE HARNESS AND THE
   * GAME'S OWN rAF LOOP ARE TWO DRIVERS ON ONE CLOCK." The layout gate clears its buffer, calls
   * draw() once and reads on the next frame — but this loop also draws in between, so every string
   * was recorded TWICE and the gate reported every line overprinting its own copy at 100%. That is
   * §3e-1's documented trap arriving through a different door: it is not enough to record one
   * frame, the game must not be drawing frames of its own while you do it. */
  let renderPaused = false;

  function frame(ts) {
    const dt = lastFrame ? Math.min(0.25, (ts - lastFrame) / 1000) : 0;
    lastFrame = ts;
    clock += dt;

    if (mode === 'play' && !offlineReport && !renderPaused && A.artLoaded()) {
      G.step(state, dt);
      saveTimer += dt;
      if (saveTimer > 5) { saveTimer = 0; S.save(state); }
    }
    if (!renderPaused) draw();
    requestAnimationFrame(frame);
  }

  /* Exported for the capture harness and the layout gate — never called by the game itself.
   * §3c-7: a capture harness and the game's own rAF loop are two drivers on one clock, so the
   * harness needs a way to stop this one before it steps the simulation by hand. */
  window.UNDERSTORY = {
    state: () => state,
    setState: (s) => { state = s; },
    setMode: (m) => { mode = m; },
    setPaused: (p) => { mode = p ? 'paused' : 'play'; },
    /* Stops this module's own rAF from stepping OR drawing, so a harness owns the clock outright. */
    setRenderPaused: (p) => { renderPaused = !!p; },
    clearOffline: () => { offlineReport = null; },
    draw,
    artLoaded: () => A.artLoaded(),
    step: (dt) => G.step(state, dt),
    W, H, CELL, BX, BY,
  };

  A.load(() => { boot(); });
  requestAnimationFrame(frame);
})();
