/**
 * fungus.js — the fruiting bodies. SIX cap families x EIGHT palettes = 48 distinct forms, drawn at
 * runtime on the canvas, no raster asset.
 *
 * WHY VOLUME AND NOT ONE GOOD MUSHROOM (master §1.1, and it is the only shape in this factory that
 * has ever sold): Meridian generated 60 motifs x 8 palettes = 480 marks and is the one product that
 * sold twice; the wing's own STARCHART generates 48 star-forms the same way. "An LLM writes the
 * rules in an afternoon; it does not cheaply produce sixty motifs that cohere." The volume is the
 * moat, and it is the first thing speed destroys.
 *
 * ⛔ WHAT THIS FILE MAY NOT DO: draw a generic dome and recolour it eight times. The six families
 * differ in SILHOUETTE — the thing you recognise across a board at 40px — not in decoration.
 * ⭐ AND THE LESSON THE PLATES RE-TAUGHT THIS SESSION APPLIES HERE TOO: every form leads with a
 * LARGE FILLED SHAPE. Thin strokes vanish at cell size; they read as scratches, which is exactly
 * what happened to the first leaf motif on the litter plate.
 */
(function (root) {
  'use strict';

  /**
   * Eight palettes. Each is [stipe, capDark, capMid, capLight, gill].
   * Hue-shifted rather than lightness-scaled, the same rule the plate ramps follow.
   */
  const PALETTES = [
    ['#c8b89a', '#5a2018', '#8e3220', '#c25a2e', '#f0dcc0'],   // 0 fly agaric red
    ['#d8cfb4', '#3d2a12', '#6b4a1e', '#a2762f', '#efe2c2'],   // 1 honey / chanterelle
    ['#b9c0c4', '#1e2a30', '#334750', '#527079', '#dfe7e8'],   // 2 slate oyster
    ['#cdbfae', '#402038', '#653154', '#96507e', '#e8d6e2'],   // 3 amethyst deceiver
    ['#c6c2a8', '#23331c', '#3e5730', '#647f47', '#e2e8cf'],   // 4 verdigris / green-gill
    ['#e0d6c2', '#4a3a22', '#7a6034', '#ab8b4c', '#f5ecd8'],   // 5 pale bolete
    ['#b0aab4', '#241a2c', '#3e2d4a', '#5f486c', '#d9d2df'],   // 6 inkcap dusk
    ['#d4c2a0', '#5c2f0e', '#8a4d18', '#bd7526', '#f2e0c4'],   // 7 rust cap
  ];

  const FAMILY_NAMES = ['Bonnet', 'Bracket', 'Coral', 'Puffball', 'Inkcap', 'Trumpet'];

  /** Deterministic per-body jitter, so one body always looks like itself but no two match. */
  function wobble(form, palette, n) {
    let h = ((form * 374761393) ^ (palette * 668265263) ^ (n * 1442695040)) >>> 0;
    h = Math.imul(h ^ (h >>> 13), 1274126177) >>> 0;
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  }

  /**
   * Draw one fruiting body centred on (cx, cy) with a footprint of roughly `s` pixels.
   * `t` is a seconds clock used only for a very slight sway, so a board of them is alive.
   */
  function draw(ctx, form, palette, cx, cy, s, t) {
    const P = PALETTES[palette % PALETTES.length];
    const f = form % 6;
    const w = (n) => wobble(f, palette, n);
    const sway = Math.sin((t || 0) * 0.6 + w(9) * 6.28) * s * 0.012;

    ctx.save();
    ctx.translate(cx + sway, cy);

    // contact shadow: every body sits ON the substrate rather than floating over it
    ctx.fillStyle = 'rgba(0,0,0,0.34)';
    ctx.beginPath();
    ctx.ellipse(0, s * 0.36, s * 0.34, s * 0.10, 0, 0, Math.PI * 2);
    ctx.fill();

    const stipe = (topY, halfW, lean) => {
      ctx.fillStyle = P[0];
      ctx.beginPath();
      ctx.moveTo(-halfW, s * 0.34);
      ctx.quadraticCurveTo(-halfW * 0.7 + lean, topY + s * 0.1, -halfW * 0.55 + lean, topY);
      ctx.lineTo(halfW * 0.55 + lean, topY);
      ctx.quadraticCurveTo(halfW * 0.7 + lean, topY + s * 0.1, halfW, s * 0.34);
      ctx.closePath();
      ctx.fill();
    };

    if (f === 0) {
      /* BONNET — the archetype: a tall stipe under a domed cap. Reads instantly, so it is the
       * family a new player meets first on the litter band. */
      stipe(-s * 0.06, s * 0.075, 0);
      ctx.fillStyle = P[2];
      ctx.beginPath();
      ctx.ellipse(0, -s * 0.10, s * 0.30, s * 0.245, 0, Math.PI, 0);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = P[3];
      ctx.beginPath();
      ctx.ellipse(-s * 0.07, -s * 0.16, s * 0.16, s * 0.11, -0.3, Math.PI, 0);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = P[1];
      ctx.fillRect(-s * 0.30, -s * 0.115, s * 0.60, s * 0.035);
      // spots: the one decorative flourish, and only on this family
      ctx.fillStyle = P[4];
      for (let i = 0; i < 3; i++) {
        const a = -0.5 - i * 0.7 + w(i) * 0.4;
        ctx.beginPath();
        ctx.arc(Math.cos(a) * s * 0.17, -s * 0.16 + Math.sin(a) * s * 0.07, s * 0.032 + w(i + 4) * s * 0.016, 0, 6.29);
        ctx.fill();
      }
    } else if (f === 1) {
      /* BRACKET — no stipe at all. A stack of shelves off an implied trunk: the silhouette is
       * horizontal where every other family is vertical, which is what makes it readable. */
      for (let i = 0; i < 3; i++) {
        const yy = s * 0.20 - i * s * 0.19;
        const ww = s * (0.34 - i * 0.045);
        ctx.fillStyle = i === 1 ? P[2] : P[1];
        ctx.beginPath();
        ctx.moveTo(-s * 0.06, yy);
        ctx.quadraticCurveTo(-ww, yy - s * 0.10, -ww * 0.55, yy - s * 0.15);
        ctx.quadraticCurveTo(0, yy - s * 0.20, ww * 0.9, yy - s * 0.07);
        ctx.quadraticCurveTo(ww * 0.5, yy + s * 0.03, -s * 0.06, yy);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = P[3];
        ctx.beginPath();
        ctx.moveTo(-s * 0.02, yy - s * 0.05);
        ctx.quadraticCurveTo(ww * 0.5, yy - s * 0.15, ww * 0.82, yy - s * 0.08);
        ctx.quadraticCurveTo(ww * 0.45, yy - s * 0.04, -s * 0.02, yy - s * 0.05);
        ctx.closePath();
        ctx.fill();
      }
    } else if (f === 2) {
      /* CORAL — many branching fingers. Deliberately the busiest silhouette; it is the one that
       * says "this ground is thriving" from across the board. */
      ctx.strokeStyle = P[2];
      ctx.lineCap = 'round';
      for (let i = 0; i < 7; i++) {
        const a = -Math.PI / 2 + (i - 3) * 0.30 + (w(i) - 0.5) * 0.16;
        const len = s * (0.30 + w(i + 7) * 0.18);
        ctx.lineWidth = s * 0.075;
        ctx.beginPath();
        ctx.moveTo(0, s * 0.30);
        ctx.quadraticCurveTo(Math.cos(a) * len * 0.5, s * 0.30 + Math.sin(a) * len * 0.6,
          Math.cos(a) * len, s * 0.30 + Math.sin(a) * len);
        ctx.stroke();
        ctx.strokeStyle = i % 2 ? P[3] : P[2];
      }
      ctx.fillStyle = P[4];
      for (let i = 0; i < 7; i++) {
        const a = -Math.PI / 2 + (i - 3) * 0.30 + (w(i) - 0.5) * 0.16;
        const len = s * (0.30 + w(i + 7) * 0.18);
        ctx.beginPath();
        ctx.arc(Math.cos(a) * len, s * 0.30 + Math.sin(a) * len, s * 0.042, 0, 6.29);
        ctx.fill();
      }
    } else if (f === 3) {
      /* PUFFBALL — one big sphere on the ground. The simplest silhouette by design: a board needs
       * quiet forms as well as loud ones or every cell competes for the eye. */
      ctx.fillStyle = P[2];
      ctx.beginPath();
      ctx.ellipse(0, s * 0.07, s * 0.29, s * 0.27, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = P[3];
      ctx.beginPath();
      ctx.ellipse(-s * 0.08, -s * 0.02, s * 0.15, s * 0.13, -0.4, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = P[1];
      for (let i = 0; i < 5; i++) {
        const a = w(i) * 6.28, r = s * 0.20 * w(i + 3);
        ctx.beginPath();
        ctx.arc(Math.cos(a) * r, s * 0.07 + Math.sin(a) * r * 0.9, s * 0.022, 0, 6.29);
        ctx.fill();
      }
    } else if (f === 4) {
      /* INKCAP — a tall narrow bell, deliquescing at the rim. Vertical and thin where BONNET is
       * vertical and wide, which is enough to tell them apart in silhouette. */
      stipe(-s * 0.12, s * 0.05, 0);
      ctx.fillStyle = P[2];
      ctx.beginPath();
      ctx.moveTo(-s * 0.17, -s * 0.04);
      ctx.quadraticCurveTo(-s * 0.19, -s * 0.40, 0, -s * 0.42);
      ctx.quadraticCurveTo(s * 0.19, -s * 0.40, s * 0.17, -s * 0.04);
      ctx.quadraticCurveTo(0, -s * 0.10, -s * 0.17, -s * 0.04);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = P[3];
      ctx.beginPath();
      ctx.moveTo(-s * 0.06, -s * 0.10);
      ctx.quadraticCurveTo(-s * 0.11, -s * 0.36, 0, -s * 0.40);
      ctx.quadraticCurveTo(s * 0.04, -s * 0.30, s * 0.02, -s * 0.10);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = P[1];              // the ink, running off the rim
      for (let i = 0; i < 4; i++) {
        const x = -s * 0.14 + i * s * 0.09 + (w(i) - 0.5) * s * 0.03;
        ctx.fillRect(x, -s * 0.05, s * 0.022, s * (0.05 + w(i + 2) * 0.10));
      }
    } else {
      /* TRUMPET — a funnel, wide open at the top and hollow. The only family with a concave
       * silhouette, which is why it survives being drawn small. */
      ctx.fillStyle = P[2];
      ctx.beginPath();
      ctx.moveTo(-s * 0.06, s * 0.32);
      ctx.quadraticCurveTo(-s * 0.10, -s * 0.05, -s * 0.28, -s * 0.24);
      ctx.lineTo(s * 0.28, -s * 0.24);
      ctx.quadraticCurveTo(s * 0.10, -s * 0.05, s * 0.06, s * 0.32);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = P[1];              // the hollow interior
      ctx.beginPath();
      ctx.ellipse(0, -s * 0.24, s * 0.28, s * 0.085, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = P[3];
      ctx.beginPath();
      ctx.ellipse(0, -s * 0.245, s * 0.20, s * 0.055, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = P[3];
      ctx.lineWidth = Math.max(1, s * 0.018);
      for (let i = 0; i < 3; i++) {
        const x = (i - 1) * s * 0.11;
        ctx.beginPath();
        ctx.moveTo(x * 0.25, s * 0.28);
        ctx.quadraticCurveTo(x * 0.7, s * 0.02, x, -s * 0.20);
        ctx.stroke();
      }
    }

    ctx.restore();
  }

  const API = { PALETTES, FAMILY_NAMES, draw, FORMS: 6, COUNT: 6 * PALETTES.length };

  if (typeof module === 'object' && module.exports) module.exports = API;
  else root.FUNGUS = API;
})(typeof self !== 'undefined' ? self : this);
