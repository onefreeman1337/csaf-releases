/**
 * bands.js — UNDERSTORY's substrate bands and upgrade trees. Pure data plus pure functions.
 *
 * Kept separate from the simulation deliberately: every number a designer would want to turn lives
 * here, and `Internal_Ops/test_balance.js` imports this file directly to assert the progression is
 * actually a progression rather than a list of numbers that happen to be different.
 *
 * ⛔ THE DESIGN RULE THIS FILE ENFORCES (wing Gate 4): a new band must be a NEW PROBLEM, not a
 * bigger number. So each one differs on at least two axes — yield AND moisture, or nutrient AND
 * hardness — and `BANDS_DIFFER_ON_TWO_AXES` in the test suite fails if a future edit makes one of
 * them a pure multiplier of its predecessor.
 */
(function (root) {
  'use strict';

  /**
   * A band's `nutrient` is PER CELL and finite — that finiteness is the whole reason spreading
   * matters. STONE is the exception and its `nutrient: Infinity` is the point of the band: a
   * trickle that never runs out, which changes the strategy from "expand" to "hold".
   */
  const BANDS = [
    {
      id: 'litter', name: 'Leaf Litter', plate: 'litter', rows: [0, 3],
      nutrient: 55, yield: 1.0, hardness: 1.0, wetness: 0.95,
      blurb: 'Fallen leaves, one season deep. Poor, but it gives itself up easily and it holds water.',
    },
    {
      id: 'deadwood', name: 'Deadwood', plate: 'deadwood', rows: [4, 6],
      nutrient: 210, yield: 2.7, hardness: 3.2, wetness: 0.62,
      blurb: 'Fallen limbs going soft. Four times the food of litter and it takes lignin to open.',
    },
    {
      id: 'bone', name: 'Bone', plate: 'bone', rows: [7, 8],
      nutrient: 520, yield: 6.2, hardness: 7.5, wetness: 0.20,
      blurb: 'What the wood did not take. Enormously rich and desperately dry — moisture is the puzzle here.',
    },
    {
      id: 'stone', name: 'Stone', plate: 'stone', rows: [9, 10],
      nutrient: Infinity, yield: 1.35, hardness: 13.0, wetness: 0.42,
      blurb: 'Bare rock. Almost nothing, forever. A lichen never has to move on.',
    },
  ];

  const BAND_BY_ID = {};
  for (const b of BANDS) BAND_BY_ID[b.id] = b;

  function bandForRow(row) {
    for (const b of BANDS) if (row >= b.rows[0] && row <= b.rows[1]) return b;
    return BANDS[BANDS.length - 1];
  }

  /**
   * SPORE UPGRADES — the permanent tree. Bought with spores, which only fruiting produces.
   * `max` is the level cap; `cost(level)` is the price of the NEXT level.
   *
   * ⚠️ The three `unlock` rows are gates rather than multipliers, and they are what make a run feel
   * like it is going somewhere. Everything else is a dial.
   */
  /*
   * ⛔ THESE NUMBERS ARE THE SECOND SET. THE FIRST SET WAS MEASURED, NOT GUESSED WRONG.
   * `Internal_Ops/balance.js` played the first version and finished the ENTIRE game — all four
   * bands, every upgrade maxed — in FIVE SIMULATED MINUTES, then sat in a dead stall for 5h53m.
   * A cell matured in 8 seconds, fruiting cost a flat 45 biomass forever, and the whole spore tree
   * cost ~279 spores, so the optimal play was to carpet the board with 112 fruiting bodies inside
   * the first five minutes. Wing §3f is exactly right that only a campaign probe can see this: all
   * 50 unit assertions passed on that version and every single rule "worked".
   */
  const SPORE_UPGRADES = [
    {
      id: 'lignin', name: 'Lignin Enzyme', max: 1, cost: () => 9, unlocks: 'deadwood',
      desc: 'Opens DEADWOOD. Without it, wood is just a wall you cannot eat.',
    },
    {
      id: 'collagenase', name: 'Collagenase', max: 1, cost: () => 55, unlocks: 'bone',
      desc: 'Opens BONE. Rich, and drier than anything you have grown on.',
    },
    {
      id: 'symbiosis', name: 'Lichen Symbiosis', max: 1, cost: () => 140, unlocks: 'stone',
      desc: 'Opens STONE. A trickle that never depletes.',
    },
    {
      id: 'density', name: 'Hyphal Density', max: 4, cost: (l) => 7 + l * 13,
      desc: 'Raises the density every cell can reach, and density multiplies everything.',
    },
    {
      id: 'retention', name: 'Moisture Retention', max: 4, cost: (l) => 9 + l * 15,
      desc: 'Your network holds water longer, so the frontier dries more slowly.',
    },
    {
      id: 'cords', name: 'Rhizomorph Cords', max: 4, cost: (l) => 7 + l * 14,
      desc: 'Thick transport strands. Spreading costs less the further you get from an anchor.',
    },
    {
      id: 'reach', name: 'Spore Reach', max: 3, cost: (l) => 16 + l * 20,
      desc: 'A fruiting body wets and anchors a wider ring around itself.',
    },
    {
      id: 'appetite', name: 'Appetite', max: 5, cost: (l) => 11 + l * 14,
      desc: 'Every colonised cell digests faster. Flat, honest, and always useful.',
    },
  ];

  /**
   * BIOMASS UPGRADES — bought in-session with biomass, unbounded, geometric cost. These exist so
   * that biomass always has somewhere to go once the board is full, which is the failure mode an
   * incremental hits when its only sink is the next tile.
   */
  const BIOMASS_UPGRADES = [
    { id: 'potency', name: 'Enzyme Potency', base: 40, growth: 1.55, step: 0.09, desc: '+9% digestion rate, compounding.' },
    { id: 'turgor', name: 'Turgor', base: 30, growth: 1.5, step: 0.11, desc: '+11% density growth rate, compounding.' },
    { id: 'seep', name: 'Seep', base: 250, growth: 2.4, step: 0, desc: 'Opens a permanent spring on the wettest dry cell you own.' },
  ];

  function biomassCost(u, level) { return Math.floor(u.base * Math.pow(u.growth, level)); }

  /** Spread cost for a cell, given band hardness, distance to the nearest anchor, and cord level. */
  function spreadCost(band, distToAnchor, cordLevel) {
    const cordFactor = 1 - 0.15 * cordLevel;              // 4 levels -> 40% off the distance term
    const far = 1 + distToAnchor * 0.34 * cordFactor;
    return Math.ceil(6 * band.hardness * far);
  }

  /** Density ceiling. Base 0.55 so that early cells are visibly unfinished and upgrades read. */
  function densityCap(densityLevel) { return 0.55 + 0.1125 * densityLevel; }

  /** How fast a dry cell loses density. Retention makes the frontier survivable, never immortal. */
  function dryRate(retentionLevel) { return 0.085 * (1 - 0.16 * retentionLevel); }

  /** Radius, in cells, over which a fruiting body anchors and wets. */
  /* ⚠️ Base was 1.6 and the campaign probe proved it useless: at strength 0.92 a radius of 1.6
   * wets only the four cells touching the fruiting body, so the anchor the whole prestige loop
   * pays for changed nothing about where you could grow. 3.2 makes a fruiting body a genuine new
   * centre of operations, which is what the design says it is. */
  function anchorRadius(reachLevel) { return 3.2 + reachLevel * 1.1; }

  /**
   * Spores paid for one fruiting. Deliberately superlinear in the cell's density so that fruiting a
   * mature cell is worth waiting for — otherwise the optimal play is to spam fruit at the threshold
   * and the density system stops mattering.
   */
  /**
   * Spores paid for one fruiting. Superlinear in density so that fruiting a mature cell is worth
   * waiting for, and steeply scaled by the BAND so that going deeper is the way to get spores.
   * ⚠️ Rebalanced with the tree above: litter fruits pay ~2, bone fruits pay ~22, which is what
   * makes "open the next band" the answer rather than "fruit more litter".
   */
  function sporeYield(density, band) {
    return Math.max(1, Math.round(Math.pow(density, 1.7) * 6 * (0.6 + band.yield * 0.5)));
  }

  /**
   * ⛔ FRUITING COST RISES WITH EVERY FRUITING YOU HAVE EVER MADE, and that is the single change
   * that turned this from a five-minute game into a campaign. A flat cost meant the board ended up
   * carpeted with 112 fruiting bodies — which is also nonsense as a picture, since a fruiting body
   * is supposed to be a landmark. Geometric growth makes each one a decision about WHERE.
   */
  /* ⚠️ 1.14 was too steep to fund a whole tree: by the 27th fruiting the price was 1,549 biomass,
   * and the probe could manage only 27 in six hours — so the last third of the upgrade tree was
   * unreachable in practice. 1.10 keeps every fruiting a real decision about WHERE without making
   * the fortieth one a wall. */
  function fruitCost(fruitings) { return Math.floor(45 * Math.pow(1.10, fruitings)); }

  const API = {
    BANDS, BAND_BY_ID, bandForRow, SPORE_UPGRADES, BIOMASS_UPGRADES,
    biomassCost, spreadCost, densityCap, dryRate, anchorRadius, sporeYield, fruitCost,
    FRUIT_DENSITY: 0.5,          // minimum density before a cell can fruit
    FRUIT_DRAIN: 0.42,           // density removed from the fruiting cell and its ring
    FRUIT_SPACING: 3,            // Chebyshev cells between fruiting bodies — see grid.js fruitInfo
    SPORE_TRICKLE: 0.0021,       // spores/sec per fruiting body, before band and density scaling
    /* ⚠️ 0.055/s matured a cell in EIGHT SECONDS, which is why the probe could complete the game
     * before a real player finished reading the help screen. At 0.0075 a cell takes about a
     * minute, and `turgor` then reads as a meaningful purchase instead of a rounding error. */
    DENSITY_GROWTH: 0.0075,
    OFFLINE_CAP_HOURS: 8,
  };

  if (typeof module === 'object' && module.exports) module.exports = API;
  else root.BANDS_DATA = API;
})(typeof self !== 'undefined' ? self : this);
