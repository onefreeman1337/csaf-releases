/**
 * sound.js — self-contained procedural audio. No samples, no files, no licence.
 *
 * ⚠️ THIS IS WHY THE LISTING'S AI DISCLOSURE READS "Sounds: no" (master §4.1, Playbook_itch §15f):
 * itch's own guidance is explicit that self-contained procedural synthesis is not generative AI.
 * The AI-written CODE is covered by "Code: yes". ⛔ If a single rendered sample or a generative
 * audio model is ever added to this game, that checkbox flips the same day — the carve-out is
 * about the METHOD, not about how the result sounds.
 *
 * Everything is synthesised from oscillators and filtered noise in the WebAudio graph, built lazily
 * because browsers refuse to start an AudioContext before a user gesture.
 */
(function (root) {
  'use strict';

  let ctx = null;
  let master = null;
  let enabled = true;
  let started = false;

  function ensure() {
    if (ctx) return ctx;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = 0.30;
    master.connect(ctx.destination);
    return ctx;
  }

  /**
   * The theme. An <audio> element rather than a decoded buffer, deliberately: it is 67 seconds and
   * ~730 KB, and streaming it means the game is playable before the music has finished arriving.
   * ⚠️ It is OUR OWN IP — rendered by Kernel/capture/make_audio.js from Internal_Ops/theme.json,
   * oscillators only, no soundfont and no sample bank, so there is no licence and no AI-audio tag.
   */
  let music = null;
  function ensureMusic() {
    if (music) return music;
    music = new Audio('audio/understory_theme.ogg');
    music.loop = true;
    music.volume = 0.42;
    music.addEventListener('error', () => console.warn('[UNDERSTORY] theme failed to load'));
    return music;
  }

  /** Call from a real input handler. Browsers suspend contexts created without a gesture. */
  function unlock() {
    const c = ensure();
    if (c && c.state === 'suspended') c.resume();
    started = true;
    if (enabled) { const m = ensureMusic(); if (m.paused) m.play().catch(() => { /* autoplay refused; the toggle still works */ }); }
  }

  function noiseBuffer(seconds) {
    const n = Math.floor(ctx.sampleRate * seconds);
    const buf = ctx.createBuffer(1, n, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    return buf;
  }

  function blip(freq, dur, type, gain, sweepTo) {
    if (!enabled || !started) return;
    const c = ensure();
    if (!c) return;
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(freq, c.currentTime);
    if (sweepTo) o.frequency.exponentialRampToValueAtTime(sweepTo, c.currentTime + dur);
    g.gain.setValueAtTime(0.0001, c.currentTime);
    g.gain.exponentialRampToValueAtTime(gain || 0.20, c.currentTime + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + dur);
    o.connect(g); g.connect(master);
    o.start();
    o.stop(c.currentTime + dur + 0.02);
  }

  function rustle(dur, cutoff, gain) {
    if (!enabled || !started) return;
    const c = ensure();
    if (!c) return;
    const src = c.createBufferSource();
    src.buffer = noiseBuffer(dur);
    const f = c.createBiquadFilter();
    f.type = 'bandpass';
    f.frequency.value = cutoff;
    f.Q.value = 0.8;
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, c.currentTime);
    g.gain.exponentialRampToValueAtTime(gain || 0.14, c.currentTime + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + dur);
    src.connect(f); f.connect(g); g.connect(master);
    src.start();
    src.stop(c.currentTime + dur + 0.02);
  }

  const API = {
    unlock,
    setEnabled(v) {
      enabled = !!v;
      const m = ensureMusic();
      if (enabled) { if (started) m.play().catch(() => {}); } else { m.pause(); }
    },
    isEnabled() { return enabled; },
    /* Each cue is a different GESTURE, not a different pitch of the same beep — spreading is a soft
     * organic rustle, fruiting is a rising chord, a refusal is a short dull thud. */
    spread() { rustle(0.20, 900 + Math.random() * 500, 0.11); blip(180 + Math.random() * 40, 0.10, 'sine', 0.07); },
    fruit() {
      blip(196, 0.42, 'triangle', 0.13);
      setTimeout(() => blip(294, 0.40, 'triangle', 0.11), 70);
      setTimeout(() => blip(392, 0.46, 'sine', 0.10), 150);
      rustle(0.30, 1800, 0.07);
    },
    buy() { blip(330, 0.13, 'triangle', 0.12); setTimeout(() => blip(494, 0.16, 'triangle', 0.10), 60); },
    unlockBand() {
      [262, 330, 392, 523].forEach((f, i) => setTimeout(() => blip(f, 0.55, 'triangle', 0.12), i * 110));
      rustle(0.7, 700, 0.06);
    },
    deny() { blip(110, 0.11, 'sawtooth', 0.06, 80); },
    tick() { rustle(0.06, 2600, 0.03); },
  };

  if (typeof module === 'object' && module.exports) module.exports = API;
  else root.SOUND = API;
})(typeof self !== 'undefined' ? self : this);
