/**
 * art.js — plate loading, text layout, and the board's own drawing vocabulary.
 *
 * ⛔ EVERY STRING THIS GAME DRAWS GOES THROUGH `API.text`, AND THAT IS A GATE REQUIREMENT, NOT A
 * STYLE PREFERENCE (wing §3e-1, measured on FLOODMARK):
 *
 *   "Canvas text does not wrap, does not reflow and does not clip. FLOODMARK passed 133 assertions
 *    across four suites while HOW IT WORKS drew four body lines to 1035px on a 960px canvas."
 *
 * And the trap that made that gate lie the first time, which is why `paragraph` and `wrap` below
 * call `API.text` rather than a closure-local helper: "A HELPER THAT CALLS THE CLOSURE-LOCAL `text`
 * IS INVISIBLE TO THE RECORDER" — the layout gate replaces `API.text` with a recorder, so an
 * internal caller that bypasses it is exactly the line most likely to overflow and least likely to
 * be measured.
 *
 * ⛔ AND LAYOUT IS DERIVED FROM `measureText` AT DRAW TIME, NEVER HARD-CODED. This game ships a
 * system font stack, so the same string is a different width on Windows, on a Mac and in headless
 * capture. "Measure once, hard-code the x" is wrong by construction.
 */
(function (root) {
  'use strict';

  const FONT = "'Iowan Old Style', 'Palatino Linotype', Palatino, Georgia, serif";
  const SANS = "'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif";

  const PLATES = ['litter', 'deadwood', 'bone', 'stone', 'duff'];
  const images = {};
  const patterns = {};
  let loaded = 0;

  /** ⭐ The only honest proof an asset DECODED, exported because the capture harness must wait on
   *  it (wing §3d rule 3). A capture that starts before the art lands photographs an empty game. */
  function artLoaded() { return loaded === PLATES.length; }
  function loadedCount() { return loaded; }

  function load(onDone) {
    for (const name of PLATES) {
      const img = new Image();
      img.onload = () => {
        images[name] = img;
        loaded++;
        if (loaded === PLATES.length && onDone) onDone();
      };
      img.onerror = () => {
        /* ⚠️ A missing plate must be loud. The wing has shipped a build whose art 404'd while every
         * check stayed green (§3b-2a), so this refuses to pretend by counting the failure as a load
         * and leaving `artLoaded()` false forever — the game then renders flat colour and says so. */
        console.error('[UNDERSTORY] plate failed to load: art/plate_' + name + '.png');
        images[name] = null;
      };
      img.src = 'art/plate_' + name + '.png';
    }
  }

  function pattern(ctx, name) {
    if (patterns[name]) return patterns[name];
    if (!images[name]) return null;
    patterns[name] = ctx.createPattern(images[name], 'repeat');   // 1:1, never resampled (§3g)
    return patterns[name];
  }

  /* ── text ─────────────────────────────────────────────────────────────────────────────────── */

  const API = {};

  /** THE single text entry point. The layout gate swaps this out to record every string drawn. */
  API.text = function (ctx, str, x, y, opts) {
    const o = opts || {};
    ctx.save();
    ctx.font = `${o.weight || 400} ${o.size || 14}px ${o.sans ? SANS : FONT}`;
    ctx.textAlign = o.align || 'left';
    ctx.textBaseline = o.baseline || 'alphabetic';
    if (o.shadow) {
      ctx.fillStyle = 'rgba(0,0,0,0.75)';
      ctx.fillText(str, x + 1, y + 1);
    }
    ctx.fillStyle = o.colour || '#e8e2d2';
    if (o.alpha !== undefined) ctx.globalAlpha = o.alpha;
    ctx.fillText(str, x, y);
    ctx.restore();
    return ctx.measureText(str).width;
  };

  /** Measure a string under the same font rules `text` will use. */
  API.width = function (ctx, str, opts) {
    const o = opts || {};
    ctx.save();
    ctx.font = `${o.weight || 400} ${o.size || 14}px ${o.sans ? SANS : FONT}`;
    const w = ctx.measureText(str).width;
    ctx.restore();
    return w;
  };

  /** Break `str` into lines that each fit `maxW`. Derived at draw time, on the player's machine. */
  API.wrap = function (ctx, str, maxW, opts) {
    const words = String(str).split(/\s+/).filter(Boolean);
    const lines = [];
    let line = '';
    for (const word of words) {
      const candidate = line ? line + ' ' + word : word;
      if (API.width(ctx, candidate, opts) <= maxW || !line) line = candidate;
      else { lines.push(line); line = word; }
    }
    if (line) lines.push(line);
    return lines;
  };

  /** Draw wrapped text. ⛔ Routes through API.text so the layout recorder can see every line. */
  API.paragraph = function (ctx, str, x, y, maxW, opts) {
    const o = opts || {};
    const lh = o.lineHeight || (o.size || 14) * 1.42;
    const lines = API.wrap(ctx, str, maxW, o);
    for (let i = 0; i < lines.length; i++) API.text(ctx, lines[i], x, y + i * lh, o);
    return lines.length * lh;
  };

  /* ── board vocabulary ─────────────────────────────────────────────────────────────────────── */

  /** A panel: duff plate, darkened, with a hairline edge. Chrome that stays quiet (§3e). */
  API.panel = function (ctx, x, y, w, h, alpha) {
    const p = pattern(ctx, 'duff');
    ctx.save();
    ctx.beginPath();
    ctx.rect(x, y, w, h);
    ctx.clip();
    if (p) { ctx.fillStyle = p; ctx.fillRect(x, y, w, h); }
    else { ctx.fillStyle = '#191d1a'; ctx.fillRect(x, y, w, h); }
    ctx.fillStyle = `rgba(6,9,7,${alpha === undefined ? 0.42 : alpha})`;
    ctx.fillRect(x, y, w, h);
    ctx.restore();
    ctx.strokeStyle = 'rgba(150,168,140,0.20)';
    ctx.lineWidth = 1;
    ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
  };

  /** A substrate cell, drawn from its band's plate at 1:1 with no scaling (§3g). */
  API.substrate = function (ctx, plateName, x, y, w, h) {
    const p = pattern(ctx, plateName);
    ctx.save();
    ctx.beginPath();
    ctx.rect(x, y, w, h);
    ctx.clip();
    if (p) { ctx.fillStyle = p; ctx.fillRect(x, y, w, h); }
    else { ctx.fillStyle = '#2a2620'; ctx.fillRect(x, y, w, h); }
    ctx.restore();
  };

  /**
   * The mycelium itself: a mat of hyphal threads whose count and reach follow `density`.
   * Drawn rather than tiled, because it has to differ per cell and per moment — and because a
   * network you can SEE thickening is the whole readout of the density system.
   */
  /**
   * ⛔ VERSION 1 WAS REJECTED ON SIGHT, and the failure is worth keeping because it is the exact
   * shape §1.1 warns about. It drew 4 + density*16 threads radiating from each cell's centre, so a
   * mid-game board rendered as 144 IDENTICAL WHITE ASTERISKS in a grid — a repeated stamp, not a
   * network — and at that opacity it completely buried the five substrate plates underneath. Litter,
   * deadwood and bone were indistinguishable. All of the plate work was invisible in the product.
   *
   * ⭐ TWO CHANGES, both structural rather than cosmetic:
   *   1. THE NETWORK CONNECTS. `links` is a 4-bit mask of colonised neighbours, and the main
   *      strands run OUT ACROSS THE CELL EDGE toward them, so what you see is one organism
   *      spreading rather than 176 independent decorations. That is also the thing the game is
   *      actually about, so the picture now agrees with the mechanic.
   *   2. THE SUBSTRATE STAYS VISIBLE. A quiet mat instead of an opaque starburst: fewer strands,
   *      thinner, warm rather than white, and alpha that scales with density so early ground reads
   *      as barely held.
   */
  /** Deterministic hash of a board EDGE. Both cells sharing it get the same number, by construction. */
  function edgeHash(ex, ey, orient) {
    let v = ((ex + 1) * 374761393 ^ (ey + 1) * 668265263 ^ (orient + 1) * 2246822519) >>> 0;
    v = Math.imul(v ^ (v >>> 13), 1274126177) >>> 0;
    return ((v ^ (v >>> 16)) >>> 0) / 4294967296;
  }

  API.hyphae = function (ctx, x, y, w, h, density, seed, t, links, gx, gy) {
    if (density <= 0.001) return;
    const cx = x + w / 2, cy = y + h / 2;
    let s = seed >>> 0;
    const rnd = () => { s = (Math.imul(s ^ (s >>> 15), s | 1) + 0x6d2b79f5) >>> 0; return (s >>> 8) / 16777216; };
    const d = Math.min(1, density);

    ctx.save();
    ctx.lineCap = 'round';

    // 1. the mat: a soft warm bloom that gives the cell body without drawing a single line
    const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, w * 0.52);
    g.addColorStop(0, `rgba(226,214,182,${0.16 + d * 0.30})`);
    g.addColorStop(0.6, `rgba(214,200,166,${0.05 + d * 0.13})`);
    g.addColorStop(1, 'rgba(200,188,158,0)');
    ctx.fillStyle = g;
    ctx.fillRect(x, y, w, h);

    /* 2. STRANDS TO COLONISED NEIGHBOURS.
     *
     * ⛔ VERSION 2 WAS ALSO REJECTED ON SIGHT, for the opposite reason to version 1. Connecting
     * every neighbour with a strand that leaves at the cell-edge MIDPOINT made all the strands line
     * up across the board, and a fully colonised board rendered as a rigid white FISHNET — a
     * chain-link fence, not an organism. Fixing the "repeated stamp" had produced a "perfect grid".
     *
     * ⭐ The offset and the presence of each strand are hashed ON THE EDGE, not on the cell, so the
     * two cells sharing an edge compute the SAME answer and their strands still meet exactly — but
     * neighbouring edges disagree, so nothing lines up. About a quarter of links are dropped for
     * the same reason: a real mycelium is not 4-regular.
     */
    const DIRS = [[1, 0], [-1, 0], [0, 1], [0, -1]];
    ctx.strokeStyle = `rgba(236,226,198,${0.28 + d * 0.42})`;
    for (let i = 0; i < 4; i++) {
      if (!(links & (1 << i))) continue;
      const [dx, dy] = DIRS[i];
      const ex = Math.min(gx, gx + dx), ey = Math.min(gy, gy + dy);
      const eh = edgeHash(ex, ey, dx === 0 ? 1 : 0);
      if (eh > 0.76) continue;                       // an irregular network, not a lattice
      const off = (eh * 2.63 % 1 - 0.5) * w * 0.62;  // where this edge is crossed, agreed by both cells
      ctx.lineWidth = 0.6 + d * 1.2;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.quadraticCurveTo(
        cx + dx * w * 0.22 + (dy ? off * 0.5 : 0), cy + dy * h * 0.22 + (dx ? off * 0.5 : 0),
        cx + dx * w * 0.54 + (dy ? off : 0), cy + dy * h * 0.54 + (dx ? off : 0));
      ctx.stroke();
    }

    // 3. a few short tendrils, count driven by density so growth is legible as thickening
    const n = Math.round(2 + d * 5);
    ctx.strokeStyle = `rgba(230,220,192,${0.22 + d * 0.34})`;
    ctx.lineWidth = 0.6 + d * 0.7;
    for (let i = 0; i < n; i++) {
      const a = rnd() * Math.PI * 2;
      const len = w * (0.14 + rnd() * 0.22) * (0.5 + d * 0.6);
      const drift = Math.sin((t || 0) * 0.5 + i + (seed & 7)) * 0.5;
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(a) * w * 0.06, cy + Math.sin(a) * h * 0.06);
      ctx.quadraticCurveTo(
        cx + Math.cos(a + 0.5) * len * 0.6, cy + Math.sin(a + 0.5) * len * 0.6 + drift,
        cx + Math.cos(a) * len, cy + Math.sin(a) * len);
      ctx.stroke();
    }

    // 4. the node: small, so a thin cell still reads as OWNED without shouting
    ctx.globalAlpha = 0.45 + d * 0.45;
    ctx.fillStyle = '#f0e6cc';
    ctx.beginPath();
    ctx.arc(cx, cy, 1.0 + d * 1.8, 0, 6.29);
    ctx.fill();
    ctx.restore();
  };

  /** Rival mould: a cold blue-green stipple, deliberately unlike the warm hyphae. */
  API.mould = function (ctx, x, y, w, h, amount, seed) {
    if (amount <= 0.02) return;
    let s = (seed ^ 0x9e3779b9) >>> 0;
    const rnd = () => { s = (Math.imul(s ^ (s >>> 15), s | 1) + 0x6d2b79f5) >>> 0; return (s >>> 8) / 16777216; };
    ctx.save();
    ctx.globalAlpha = Math.min(0.85, amount * 0.9);
    for (let i = 0; i < Math.round(amount * 26); i++) {
      ctx.fillStyle = i % 3 === 0 ? '#7fa08a' : '#4d6b5c';
      const px = x + rnd() * w, py = y + rnd() * h;
      const r = 0.8 + rnd() * 1.9;
      ctx.beginPath();
      ctx.arc(px, py, r, 0, 6.29);
      ctx.fill();
    }
    ctx.restore();
  };

  /** A spring: water welling up. Animated, because it is the thing the player plans around. */
  API.spring = function (ctx, x, y, w, h, t) {
    const cx = x + w / 2, cy = y + h / 2;
    ctx.save();
    for (let i = 0; i < 3; i++) {
      const phase = ((t || 0) * 0.55 + i / 3) % 1;
      ctx.globalAlpha = (1 - phase) * 0.55;
      ctx.strokeStyle = '#8fc4d8';
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.ellipse(cx, cy, 3 + phase * (w * 0.42), (3 + phase * (w * 0.42)) * 0.5, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
    ctx.fillStyle = '#bfe2ef';
    ctx.beginPath();
    ctx.ellipse(cx, cy, 3.4, 2.2, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  };

  API.FONT = FONT;
  API.SANS = SANS;
  API.load = load;
  API.artLoaded = artLoaded;
  API.loadedCount = loadedCount;
  API.pattern = pattern;
  API.PLATES = PLATES;

  if (typeof module === 'object' && module.exports) module.exports = API;
  else root.ART = API;
})(typeof self !== 'undefined' ? self : this);
