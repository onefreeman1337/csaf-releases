/**
 * save.js — localStorage persistence and the offline catch-up handshake.
 *
 * ⛔ THE STANDING WING RULE (ledger B4/B5): save and resume, NEVER a full restart. UNDERSTORY has
 * no run and no death, so this file's whole job is that closing the tab costs you nothing and
 * reopening it tells you honestly what happened while you were away.
 *
 * ⚠️ SERIALISATION IS EXPLICIT, FIELD BY FIELD, ON PURPOSE. A blind JSON round-trip would silently
 * drop the `Float64Array` moisture field into an object and hand the simulation something that
 * still "works" while behaving differently — and it would resurrect stale fields whenever the
 * schema changed. The moisture field is DERIVED, so it is never saved; it is recomputed on load.
 */
(function (root) {
  'use strict';

  const KEY = 'understory.save.v1';

  function serialise(s) {
    return {
      v: 1,
      biomass: s.biomass,
      spores: s.spores,
      totalSpores: s.totalSpores,
      sporeBank: s.sporeBank,
      fruitings: s.fruitings,
      spore: s.spore,
      bio: s.bio,
      unlocked: s.unlocked,
      elapsed: s.elapsed,
      lost: s.lost,
      peakColonised: s.peakColonised,
      savedAt: Date.now(),
      // cells: only the fields that are not derivable from position
      cells: s.cells.map((c) => [
        Math.round(c.density * 1000) / 1000,
        c.nutrient === Infinity ? -1 : Math.round(c.nutrient * 100) / 100,
        Math.round(c.mould * 1000) / 1000,
        c.spring ? 1 : 0,
        c.fruit ? c.fruit.form : -1,
        c.fruit ? c.fruit.palette : -1,
        c.fruit ? c.fruit.bandId : 0,
      ]),
    };
  }

  function apply(s, data) {
    if (!data || data.v !== 1 || !Array.isArray(data.cells) || data.cells.length !== s.cells.length) {
      return { ok: false, why: 'save is missing, from another version, or the wrong board size' };
    }
    s.biomass = data.biomass || 0;
    s.spores = data.spores || 0;
    s.totalSpores = data.totalSpores || 0;
    s.sporeBank = data.sporeBank || 0;
    s.fruitings = data.fruitings || 0;
    s.elapsed = data.elapsed || 0;
    s.lost = data.lost || 0;
    s.peakColonised = data.peakColonised || 0;
    /* Merge rather than replace, so a save written before a new upgrade existed still loads and
     * simply reads level 0 for it — an old save must never be rejected for being old. */
    for (const k of Object.keys(s.spore)) if (data.spore && data.spore[k] !== undefined) s.spore[k] = data.spore[k];
    for (const k of Object.keys(s.bio)) if (data.bio && data.bio[k] !== undefined) s.bio[k] = data.bio[k];
    for (const k of Object.keys(s.unlocked)) if (data.unlocked && data.unlocked[k] !== undefined) s.unlocked[k] = data.unlocked[k];

    for (let i = 0; i < s.cells.length; i++) {
      const c = s.cells[i], d = data.cells[i];
      c.density = d[0] || 0;
      c.nutrient = d[1] === -1 ? Infinity : d[1];
      c.mould = d[2] || 0;
      c.spring = !!d[3];
      c.fruit = d[4] >= 0 ? { form: d[4], palette: d[5], bandId: d[6] || c.bandId } : null;
    }
    return { ok: true, savedAt: data.savedAt || Date.now() };
  }

  function save(s) {
    try {
      localStorage.setItem(KEY, JSON.stringify(serialise(s)));
      return true;
    } catch (e) {
      /* Private browsing and full quotas both throw here. Losing a save is bad; crashing the game
       * over it is worse, and a silent catch would be worse still — so it is reported once. */
      console.warn('[UNDERSTORY] could not save:', e && e.message);
      return false;
    }
  }

  function load(s) {
    let raw = null;
    try { raw = localStorage.getItem(KEY); } catch (e) { return { ok: false, why: 'storage unavailable' }; }
    if (!raw) return { ok: false, why: 'no save yet' };
    let data;
    try { data = JSON.parse(raw); } catch (e) { return { ok: false, why: 'save is corrupt' }; }
    return apply(s, data);
  }

  function clear() {
    try { localStorage.removeItem(KEY); return true; } catch (e) { return false; }
  }

  const API = { KEY, save, load, clear, serialise, apply };

  if (typeof module === 'object' && module.exports) module.exports = API;
  else root.SAVE = API;
})(typeof self !== 'undefined' ? self : this);
