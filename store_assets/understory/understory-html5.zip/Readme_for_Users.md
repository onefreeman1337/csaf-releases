# UNDERSTORY

*The forest floor eats everything. You are what does the eating.*

A free incremental about a fungal network spreading through the litter layer of a forest floor.
It plays in the browser, it saves itself, and it keeps growing while you are away.

**There is no run, no reset and no death screen.** Ground can dry out and die back, but spores,
upgrades, fruiting bodies and the substrate you have opened are permanent. You never start over.

---

## How to play

**Click bare ground next to your network to SPREAD onto it.** It costs biomass. Harder substrate
costs more, and so does ground far from a spring or a fruiting body.

**Click a cell you already hold to FRUIT it**, once it is dense enough. Fruiting spends biomass and
thins the ground around it, and in return you get a permanent fruiting body that waters and anchors
everything near it — and keeps shedding spores for as long as it stands. Fruiting bodies must be at
least three cells apart, so *where* you put them is the decision.

**Spores buy enzymes.** Lignin opens deadwood, collagenase opens bone, and lichen symbiosis opens
bare stone.

- `H` — how it works
- `M` — sound on/off
- `Esc` — close a panel

## The two things that fight

**SPREAD** wants you far from home, because new ground is new food.

**DECAY** punishes exactly that. Moisture falls off with distance from a spring or a fruiting body,
and a cell can only get as dense as its moisture allows — density multiplies your yield *and* the
spores a fruiting pays. Push past your water and the frontier thins out behind you. Sit still and
you eat your ground down to nothing and the mould moves in.

Neither "expand" nor "hold" is a strategy on its own. That is the game.

## The four substrates

| | food | yield | moisture | |
| --- | --- | --- | --- | --- |
| **Leaf litter** | 55 | 1.0 | 95% | poor, easy, and it holds water |
| **Deadwood** | 210 | 2.7 | 62% | four times the food, and it takes lignin to open |
| **Bone** | 520 | 6.2 | 20% | enormously rich and desperately dry |
| **Stone** | never depletes | 1.35 | 42% | almost nothing, forever |

A new band is a new problem, not a bigger number.

## Saving

The game saves to your browser's local storage every few seconds and whenever you do something
that matters. Closing the tab costs you nothing: when you come back it simulates up to eight hours
of growth and tells you what happened.

Clearing your browser data for this site will delete the save. There is no cloud save.

## Credits and disclosure

Made by **Core Systems Asset Factory**.

This game is AI-written and the listing says so. The art is not from an image model: the five
substrate plates are procedurally generated from a hand-authored palette by the factory's own
pixel-art engine, all forty-eight fruiting bodies are drawn by the game at run time from
hand-authored shapes, and the music and sound are procedurally synthesised — no samples, no
soundfont, no generative-audio model. See `CREDITS.txt`.

Everything in this package is original work. No third-party art, audio or code is included.
