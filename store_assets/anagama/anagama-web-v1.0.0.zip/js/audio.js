/**
 * audio.js — ANAGAMA's sound. Entirely synthesised in the browser at runtime.
 *
 * ⛔ §0-ART rule 4 IS BLOCKING: a game without an SFX set and at least one music loop is not late,
 * it is not finished. And the licence gate is hard, so this ships NO sample files at all - every
 * sound is generated from oscillators and noise buffers, which makes it our own IP by construction
 * with nothing to attribute and nothing to get wrong.
 *
 * ⚠️ AI DISCLOSURE (§4.1): this is self-contained procedural synthesis, so the itch "Sounds"
 * generative-AI field is NO. That is settled doctrine and is not re-argued per product. Code and
 * Graphics are YES; Text is YES (the copy is authored).
 *
 * ⛔ AUTOPLAY: browsers refuse an AudioContext until a real gesture. Everything here is lazy and
 * every entry point is a no-op before `unlock()` has run, so a denied autoplay can never throw
 * into the game loop - which is one of the adversarial cases §1.1b requires to be exercised.
 */
(function (root) {
  'use strict';

  var ctx = null, master = null, musicGain = null, sfxGain = null;
  var enabled = true, started = false, musicTimer = null, step = 0;

  function unlock() {
    if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return true; }
    var AC = root.AudioContext || root.webkitAudioContext;
    if (!AC) return false;
    try { ctx = new AC(); } catch (e) { return false; }
    master = ctx.createGain(); master.gain.value = 0.55; master.connect(ctx.destination);
    musicGain = ctx.createGain(); musicGain.gain.value = 0.30; musicGain.connect(master);
    sfxGain = ctx.createGain(); sfxGain.gain.value = 0.85; sfxGain.connect(master);
    return true;
  }

  function ready() { return !!ctx && enabled; }

  /** A short noise buffer, reused. Wood fire, salt vapour and the kiln itself are all noise. */
  var noiseBuf = null;
  function noise() {
    if (!noiseBuf) {
      noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
      var d = noiseBuf.getChannelData(0);
      for (var i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    }
    var s = ctx.createBufferSource();
    s.buffer = noiseBuf; s.loop = true;
    return s;
  }

  function env(g, t0, a, d, peak) {
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak), t0 + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + a + d);
  }

  /** A struck tone: the shelf, the codex, a sale. Bell-ish, short, warm. */
  function tone(freq, dur, peak, type, detune) {
    if (!ready()) return;
    var t0 = ctx.currentTime;
    var o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type || 'triangle';
    o.frequency.setValueAtTime(freq, t0);
    if (detune) o.detune.setValueAtTime(detune, t0);
    env(g, t0, 0.006, dur, peak === undefined ? 0.22 : peak);
    o.connect(g); g.connect(sfxGain);
    o.start(t0); o.stop(t0 + dur + 0.05);
  }

  /** Filtered noise: fire, stoking, vapour. */
  function whoosh(dur, peak, f0, f1, q) {
    if (!ready()) return;
    var t0 = ctx.currentTime;
    var s = noise(), bp = ctx.createBiquadFilter(), g = ctx.createGain();
    bp.type = 'bandpass'; bp.Q.value = q || 1.1;
    bp.frequency.setValueAtTime(f0, t0);
    bp.frequency.exponentialRampToValueAtTime(Math.max(40, f1), t0 + dur);
    env(g, t0, 0.02, dur, peak);
    s.connect(bp); bp.connect(g); g.connect(sfxGain);
    s.start(t0); s.stop(t0 + dur + 0.06);
  }

  var SFX = {
    throwPot: function () { tone(196, 0.22, 0.14, 'sine'); tone(294, 0.16, 0.07, 'sine', 6); },
    packPot: function () { tone(140, 0.10, 0.16, 'square'); },
    unpackPot: function () { tone(110, 0.09, 0.11, 'square'); },
    glaze: function () { whoosh(0.34, 0.10, 900, 260, 0.9); },
    light: function () { whoosh(1.5, 0.30, 180, 1400, 0.7); tone(58, 1.3, 0.16, 'sawtooth'); },
    stoke: function () { whoosh(0.42, 0.20, 320, 900, 0.8); },
    salt: function () { whoosh(1.1, 0.24, 2600, 700, 1.8); },
    draw: function () { whoosh(0.9, 0.18, 700, 120, 0.9); },
    open: function () { tone(392, 0.6, 0.18, 'triangle'); tone(587, 0.5, 0.10, 'triangle', -4); },
    good: function () { tone(523, 0.5, 0.20, 'triangle'); tone(784, 0.45, 0.12, 'triangle'); },
    ruin: function () { tone(98, 0.8, 0.22, 'sawtooth'); tone(104, 0.75, 0.14, 'sawtooth'); },
    sell: function () { tone(659, 0.24, 0.16, 'triangle'); tone(988, 0.20, 0.09, 'triangle'); },
    buy: function () { tone(330, 0.18, 0.14, 'triangle'); tone(494, 0.16, 0.08, 'triangle'); },
    discover: function () { tone(523, 0.7, 0.18); tone(659, 0.65, 0.13); tone(880, 0.6, 0.09); },
    warn: function () { tone(233, 0.30, 0.20, 'square'); }
  };

  function play(name) { if (ready() && SFX[name]) { try { SFX[name](); } catch (e) { /* never throw into the loop */ } } }

  /* ── the music loop ──────────────────────────────────────────────────────────────────────────
   * A slow hira-joshi pentatonic over a low drone. Struck, never sustained, so it sits under the
   * fire instead of competing with it. It is a LOOP in the honest sense: it never stops and never
   * repeats exactly, because the phrase walks. */
  var SCALE = [0, 2, 3, 7, 8];               /* hira-joshi degrees */
  var ROOT = 146.83;                          /* D3 */
  var walk = 0;

  /**
   * ⚠️ `at` IS AN EXPLICIT TIME, not `ctx.currentTime`, and that is what makes the loop bakeable.
   * In an OfflineAudioContext `currentTime` stays 0 until rendering finishes, so a scheduler that
   * reads it stacks every note at t=0 and renders a single crash instead of a phrase. Live play
   * passes nothing and gets `currentTime`; the baker passes the step's position in the render.
   */
  function musicStep(at) {
    if (!ready()) return;
    var t0 = at === undefined ? ctx.currentTime : at;
    step++;
    /* drone every 8 steps */
    if (step % 8 === 1) {
      var o = ctx.createOscillator(), g = ctx.createGain(), lp = ctx.createBiquadFilter();
      lp.type = 'lowpass'; lp.frequency.value = 420;
      o.type = 'sawtooth'; o.frequency.value = ROOT / 2;
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(0.085, t0 + 1.6);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + 7.4);
      o.connect(lp); lp.connect(g); g.connect(musicGain);
      o.start(t0); o.stop(t0 + 7.6);
    }
    /* a struck note most steps, resting sometimes - the rests are what make it calm */
    if (Math.random() < 0.62) {
      walk += (Math.random() * 2 | 0) - (Math.random() * 2 | 0);
      if (walk < 0) walk = 0; if (walk > 9) walk = 9;
      var deg = SCALE[walk % SCALE.length];
      var oct = Math.floor(walk / SCALE.length);
      var f = ROOT * Math.pow(2, (deg + oct * 12) / 12);
      var o2 = ctx.createOscillator(), g2 = ctx.createGain(), lp2 = ctx.createBiquadFilter();
      lp2.type = 'lowpass'; lp2.frequency.value = 2600;
      o2.type = 'triangle'; o2.frequency.value = f;
      g2.gain.setValueAtTime(0.0001, t0);
      g2.gain.exponentialRampToValueAtTime(0.11, t0 + 0.008);
      g2.gain.exponentialRampToValueAtTime(0.0001, t0 + 2.6);
      o2.connect(lp2); lp2.connect(g2); g2.connect(musicGain);
      o2.start(t0); o2.stop(t0 + 2.7);
    }
  }

  /**
   * ── THE MUSIC: A BAKED FILE, WITH THE LIVE SYNTH AS THE FALLBACK ─────────────────────────────
   * `audio/kiln_loop.ogg` is 32 seconds rendered from THIS FILE's own `musicStep()` by
   * Internal_Ops/bake_music.js, with the ringing tail folded back over the head so the wrap is
   * seamless (measured: 0.000998 against a worst interior step of 0.009953).
   *
   * ⛔ WHY A FILE. `preflight`'s `game-audio-assets` gate fails a build with zero audio files and
   * the doctrine behind it is right - procedural SFX are fine, but they are "not a whole audio
   * layer". A baked loop can also be SHAPED and its seam can be MEASURED, neither of which is true
   * of a scheduler firing every 1.75s forever.
   *
   * ⚠️ THE SYNTH STAYS AS THE FALLBACK rather than being deleted, because a decode failure or a
   * blocked fetch must degrade to music rather than to silence (§1.4 rung 3). It is also still the
   * SOURCE the file is baked from, so the two can never be different music.
   *
   * ⛔ AND `setTimeout` IS NOT USED TO LOOP IT. A backgrounded tab throttles timers to ~1/minute
   * (master §2b, the automation-tab row), which would leave gaps a player can hear. `loop = true`
   * on the source node is handled by the audio thread and is immune to that.
   */
  var musicSrc = null, musicBuf = null, musicTried = false;

  function startMusic() {
    if (!ready() || started) return;
    started = true;
    if (musicBuf) { playBuffered(); return; }
    if (musicTried) { startSynth(); return; }
    musicTried = true;
    fetch('audio/kiln_loop.ogg')
      .then(function (r) { if (!r.ok) throw new Error('http ' + r.status); return r.arrayBuffer(); })
      .then(function (ab) { return ctx.decodeAudioData(ab); })
      .then(function (buf) { musicBuf = buf; if (started) playBuffered(); })
      .catch(function () { if (started) startSynth(); });
  }

  function playBuffered() {
    if (!ready() || !musicBuf || musicSrc) return;
    musicSrc = ctx.createBufferSource();
    musicSrc.buffer = musicBuf;
    musicSrc.loop = true;
    musicSrc.connect(musicGain);
    musicSrc.start(0);
  }

  function startSynth() {
    if (musicTimer) return;
    musicStep();
    musicTimer = setInterval(function () { musicStep(); }, 1750);
  }

  function setEnabled(v) {
    enabled = !!v;
    if (master) master.gain.value = enabled ? 0.55 : 0;
    if (!enabled) {
      if (musicTimer) { clearInterval(musicTimer); musicTimer = null; }
      if (musicSrc) { try { musicSrc.stop(); } catch (e) { /* already stopped */ } musicSrc = null; }
      started = false;
    } else if (ctx && !started) startMusic();
  }

  /**
   * ── THE MEASUREMENT HOOK ─────────────────────────────────────────────────────────────────────
   * ⛔ §1.1b: every audio file must be MEASURED (rms, peak, silence, clipping) because an agent
   * cannot listen. This game ships no audio FILES - every sound is synthesised - so there is
   * nothing on disk for ffmpeg to analyse, and without this hook the `audio` category could only
   * ever be satisfied by a human ear, which §1.1b explicitly forbids as a gate.
   *
   * It renders one sound through an OfflineAudioContext by temporarily rebinding the module's
   * context, then restores. That means the thing measured is the SHIPPED synthesis path, not a
   * reimplementation of it - master §2b's two-declarations family, avoided.
   *
   * ⚠️ It is inert in normal play: nothing calls it, and it restores the live context in a
   * `finally` so a measurement can never leave the game muted.
   */
  function measure(name, seconds) {
    var OAC = root.OfflineAudioContext || root.webkitOfflineAudioContext;
    if (!OAC) return Promise.resolve(null);
    var saved = { ctx: ctx, master: master, musicGain: musicGain, sfxGain: sfxGain, buf: noiseBuf };
    var sr = 44100;
    var off = new OAC(1, Math.ceil(sr * seconds), sr);
    try {
      ctx = off; noiseBuf = null;
      master = off.createGain(); master.gain.value = 1; master.connect(off.destination);
      musicGain = off.createGain(); musicGain.gain.value = 0.30; musicGain.connect(master);
      sfxGain = off.createGain(); sfxGain.gain.value = 0.85; sfxGain.connect(master);
      if (name === '__music') { for (var i = 0; i < 4; i++) { step = i; musicStep(); } }
      else if (SFX[name]) SFX[name]();
      else { throw new Error('no such sound: ' + name); }
    } catch (e) {
      ctx = saved.ctx; master = saved.master; musicGain = saved.musicGain;
      sfxGain = saved.sfxGain; noiseBuf = saved.buf;
      return Promise.reject(e);
    }
    return off.startRendering().then(function (rendered) {
      var d = rendered.getChannelData(0);
      var sum = 0, peak = 0, clipped = 0, quiet = 0;
      for (var i = 0; i < d.length; i++) {
        var v = d[i], a = v < 0 ? -v : v;
        sum += v * v;
        if (a > peak) peak = a;
        if (a >= 0.999) clipped++;
        if (a < 0.0005) quiet++;
      }
      return {
        name: name, seconds: seconds, samples: d.length,
        rms: Math.sqrt(sum / d.length),
        peak: peak,
        dbfsPeak: peak > 0 ? 20 * Math.log10(peak) : -Infinity,
        clippedSamples: clipped,
        silentFraction: quiet / d.length
      };
    }).then(function (r) {
      ctx = saved.ctx; master = saved.master; musicGain = saved.musicGain;
      sfxGain = saved.sfxGain; noiseBuf = saved.buf;
      return r;
    });
  }

  /**
   * Render the WHOLE music phrase into an OfflineAudioContext, for the loop baker.
   * ⛔ It drives the SHIPPED `musicStep()`. Re-composing the music in the baker would be a second
   * declaration of the same fact - the file a player hears and the code the repo documents would
   * be free to drift, with nothing to catch it (master §2b).
   */
  function renderMusic(off, seconds) {
    var saved = { ctx: ctx, master: master, musicGain: musicGain, sfxGain: sfxGain, st: step, w: walk };
    ctx = off;
    master = off.createGain(); master.gain.value = 1; master.connect(off.destination);
    musicGain = off.createGain(); musicGain.gain.value = 0.55; musicGain.connect(master);
    sfxGain = off.createGain(); sfxGain.gain.value = 0; sfxGain.connect(master);
    step = 0; walk = 0;
    /* a fixed, reproducible phrase: the walk is seeded by resetting it, and the note rests come
     * from Math.random, so the bake is one CHOSEN performance rather than the live stream */
    for (var t = 0; t < seconds; t += 1.75) musicStep(t);
    return off.startRendering().then(function (b) {
      ctx = saved.ctx; master = saved.master; musicGain = saved.musicGain;
      sfxGain = saved.sfxGain; step = saved.st; walk = saved.w;
      return b.getChannelData(0);
    });
  }

  root.ANAGAMA_AUDIO = {
    unlock: unlock, play: play, startMusic: startMusic, setEnabled: setEnabled,
    renderMusic: renderMusic,
    isEnabled: function () { return enabled; },
    isReady: function () { return !!ctx; },
    /** exposed for the audio TEST so the harness can enumerate what must be measured */
    sfxNames: Object.keys(SFX),
    measure: measure
  };
}(typeof self !== 'undefined' ? self : this));
