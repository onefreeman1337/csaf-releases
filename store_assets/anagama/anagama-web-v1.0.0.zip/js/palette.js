/**
 * palette.js — ANAGAMA's colour truth. ONE declaration, read by BOTH sides.
 *
 * ⛔ WHY IT LIVES HERE AND NOT IN THE BAKER. This game generates its vessels TWICE: once in Node
 * (pixel_forge, to bake the store plates and the Gate 1 contact sheet) and once in the browser
 * (at runtime, because every firing must produce pots that have never existed). Master §2b's
 * longest-running family is "two fields that mean the same thing", and a palette copied into a
 * baker and a renderer is exactly that shape - the sheet the Gate 1 review signs off would stop
 * being a picture of what the player sees, and NOTHING would go red. So the table is declared
 * once, here, in Product_Release (it ships - the player's browser loads this very file), and the
 * Node baker REQUIRES it and registers it into pixel_forge's palette at runtime.
 *
 * ⛔ NEVER edit Kernel/tilesets/pixel_forge.js's own PALETTE (§0-ART). Registration is in-process
 * and REFUSES on a duplicate hex, because pixel_forge's keyAt() is a reverse colour lookup and two
 * keys sharing a hex make every proof downstream meaningless.
 *
 * ── THE COLOURS ARE A REAL MATERIAL, NOT A MOOD BOARD ────────────────────────────────────────
 * Wood firing has a small, famous and very legible palette, and it is legible because each family
 * is what a specific CHEMICAL EVENT looks like. That matters for §0-ART's legibility rule (two
 * things that MEAN different things must not sit close in hue), because in this game the surface
 * IS the information: a collector asking for a reduction jar is asking for celadon green, and if
 * amber and celadon sit a shade apart the player cannot read their own shelf.
 *
 *   body    fired iron-bearing stoneware, the clay itself. Seen at the foot and through a thin rim.
 *   flash   clay licked directly by flame. Persimmon orange. NOT a glaze - bare clay that blushed.
 *   cel     natural ash glaze in REDUCTION. Iron pulls to green. Glassy, pooling, celadon.
 *   amb     the SAME ash glaze in OXIDATION. The same iron pulls to honey amber. (See below.)
 *   iro     applied iron glaze, tenmoku. Near-black where thick, rust where it breaks over an edge.
 *   shi     shino. Milky white, orange scorch, carbon pinholes.
 *   sal     salt/soda vapour. Grey-blue, orange-peel texture.
 *   car     carbon trap. Where reduction was so heavy the carbon stayed in the glaze.
 *
 * ⭐ cel and amb are deliberately FAR APART despite being one glaze, because that pair is the
 * game's central decision (the damper) and the player must be able to see which one they got from
 * across the shelf. That is legibility outranking realism, §0-ART, stated on purpose.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.ANAGAMA_PAL = factory();
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* Every value is #rrggbb lowercase. The table validates itself in check() below, because a
   * table of 60 literals is precisely where a typo hides and a typo here is a silent wrong pixel. */
  var PALETTE = {
    /* ── fired stoneware body ─────────────────────────────────────────────────────── */
    body0: '#241a14', body1: '#3d2b1e', body2: '#5c4130',
    body3: '#7d5b41', body4: '#a07a56', body5: '#c6a077',

    /* ── flashed clay (flame-licked, bare) ────────────────────────────────────────── */
    flash0: '#5e2a15', flash1: '#8c3f1c', flash2: '#b45a22',
    flash3: '#d47c33', flash4: '#e8a558', flash5: '#f6c98d',

    /* ── ash glaze, REDUCTION: celadon ────────────────────────────────────────────── */
    cel0: '#16241f', cel1: '#24382c', cel2: '#38553d',
    cel3: '#52774f', cel4: '#7a9c69', cel5: '#a8c188',

    /* ── ash glaze, OXIDATION: amber ──────────────────────────────────────────────── */
    amb0: '#241505', amb1: '#4a2a0a', amb2: '#764513',
    amb3: '#a26a21', amb4: '#c9933c', amb5: '#e6bc70',

    /* ── iron glaze, tenmoku ──────────────────────────────────────────────────────── */
    iro0: '#100c0a', iro1: '#221713', iro2: '#3c241a',
    iro3: '#6b3a22', iro4: '#9c5a2e', iro5: '#c98a4a',

    /* ── shino ────────────────────────────────────────────────────────────────────── */
    shi0: '#4a3a2e', shi1: '#7d6a55', shi2: '#a89178',
    shi3: '#cdb89b', shi4: '#e6d7bd', shi5: '#f5ecdc',

    /* ── salt / soda vapour ───────────────────────────────────────────────────────── */
    sal0: '#232a2e', sal1: '#3a444a', sal2: '#566269',
    sal3: '#7b868b', sal4: '#a5aeb1', sal5: '#cfd4d4',

    /* ── carbon trap ──────────────────────────────────────────────────────────────── */
    car0: '#0b0c0e', car1: '#17191d', car2: '#262a30', car3: '#3a4048',

    /* ── incidental marks ─────────────────────────────────────────────────────────── */
    wad: '#b9b2a2',          /* wadding scar: where the pot stood on a shell in the kiln */
    grit: '#2e2118'          /* iron speck in the clay, 1px, high octave (§0-ART rule 5) */
  };

  /* Ramps are DARK -> LIGHT and are the only legal way to pick a body colour, so a shading term
   * can never wander off its material. */
  var ANCHORS = {
    body:  ['body0', 'body1', 'body2', 'body3', 'body4', 'body5'],
    flash: ['flash0', 'flash1', 'flash2', 'flash3', 'flash4', 'flash5'],
    cel:   ['cel0', 'cel1', 'cel2', 'cel3', 'cel4', 'cel5'],
    amb:   ['amb0', 'amb1', 'amb2', 'amb3', 'amb4', 'amb5'],
    iro:   ['iro0', 'iro1', 'iro2', 'iro3', 'iro4', 'iro5'],
    shi:   ['shi0', 'shi1', 'shi2', 'shi3', 'shi4', 'shi5'],
    sal:   ['sal0', 'sal1', 'sal2', 'sal3', 'sal4', 'sal5'],
    car:   ['car0', 'car1', 'car2', 'car3']
  };

  /* ── ramp subdivision ────────────────────────────────────────────────────────────────────────
   * ⛔⭐ THIS EXISTS BECAUSE OF §0-ART RULE 6, MEASURED AGAIN HERE ON A CURVED SURFACE RATHER
   * THAN ON A GROUND TILE, AND IT IS THE SAME LESSON: ONE DIAL, BOTH FAILURES, AT ITS TWO ENDS.
   *   bake 2, dither 1.00 -> the low-contrast families (shino, salt) read as HALFTONE NEWSPRINT:
   *                          a regular 4x4 checker across a whole belly.
   *   bake 3, dither 0.62 -> the checker went and a HARD HORIZONTAL BAND appeared across the
   *                          middle of those same pots, because the ramp step boundary in the
   *                          vertical gradient stopped being blended.
   * §0-ART rule 6's own conclusion is that the fix is NEVER a better dither value, and it is not
   * here either. The CAUSE is that six steps is too coarse to carry a full spherical sweep plus a
   * vertical gradient: each step spans enough luma to be visible as either a checker (when
   * dithered) or a border (when not). So the anchors stay hand-authored - the hue drift in each
   * family is the art - and the CURVE BETWEEN THEM IS SUBDIVIDED. Smaller steps are neither
   * checkerable nor bandable, and no dial had to be guessed.
   *
   * ⚠️ This subdivides an authored curve; it does not invent one. Interpolating BETWEEN two
   * adjacent anchors preserves the hue shift the anchors encode, which lightness-scaling a single
   * colour would destroy (§0-ART: ramps are hue-shifted, never lightness-scaled).
   */
  var SUBDIV = 2;

  function lerpHex(a, b, t) {
    var out = '#';
    for (var i = 1; i < 7; i += 2) {
      var ca = parseInt(a.substr(i, 2), 16), cb = parseInt(b.substr(i, 2), 16);
      var v = Math.round(ca + (cb - ca) * t);
      out += (v < 16 ? '0' : '') + v.toString(16);
    }
    return out;
  }

  /** Anchors -> a fine ramp, registering every generated step into PALETTE under a derived name. */
  function expand(name, anchors) {
    var fine = [];
    for (var i = 0; i < anchors.length - 1; i++) {
      fine.push(anchors[i]);
      for (var s = 1; s <= SUBDIV; s++) {
        var key = name + '_' + i + '_' + s;
        PALETTE[key] = lerpHex(PALETTE[anchors[i]], PALETTE[anchors[i + 1]], s / (SUBDIV + 1));
        fine.push(key);
      }
    }
    fine.push(anchors[anchors.length - 1]);
    return fine;
  }

  /** #rrggbb -> [r,g,b,255]. */
  function rgba(hex) {
    return [parseInt(hex.slice(1, 3), 16), parseInt(hex.slice(3, 5), 16),
      parseInt(hex.slice(5, 7), 16), 255];
  }

  /**
   * Validate the table. Returns { ok, errors[] }.
   * ⛔ This is not decoration: it is the guard that makes the Node/browser split safe. It refuses
   * on a malformed literal AND on a duplicate hex, because a duplicate makes pixel_forge's
   * reverse lookup ambiguous and every numeric proof taken on a baked plate silently wrong.
   */
  function check() {
    var errors = [];
    var seen = {};
    for (var k in PALETTE) {
      if (!Object.prototype.hasOwnProperty.call(PALETTE, k)) continue;
      var v = PALETTE[k];
      if (typeof v !== 'string' || !/^#[0-9a-f]{6}$/.test(v)) {
        errors.push('BAD VALUE: ' + k + ' = ' + JSON.stringify(v) + ' is not #rrggbb lowercase');
        continue;
      }
      if (seen[v]) errors.push('DUPLICATE HEX: ' + k + ' equals ' + seen[v] + ' (' + v + ')');
      else seen[v] = k;
    }
    for (var r in RAMPS) {
      if (!Object.prototype.hasOwnProperty.call(RAMPS, r)) continue;
      for (var i = 0; i < RAMPS[r].length; i++) {
        if (!(RAMPS[r][i] in PALETTE)) errors.push('RAMP ' + r + ' names missing key ' + RAMPS[r][i]);
      }
    }
    return { ok: errors.length === 0, errors: errors };
  }

  /* Build the fine ramps. This MUTATES PALETTE with the interpolated steps, so it must run before
   * check() and before anything registers the table into pixel_forge. */
  var RAMPS = {};
  for (var _f in ANCHORS) {
    if (Object.prototype.hasOwnProperty.call(ANCHORS, _f)) RAMPS[_f] = expand(_f, ANCHORS[_f]);
  }

  /* ── carbonised tiers ────────────────────────────────────────────────────────────────────────
   * ⛔ THE SECOND HALFTONE, AND IT HAS A DIFFERENT CAUSE FROM THE FIRST, WHICH IS THE WHOLE POINT.
   * Bake 4 subdivided every ramp and cured the checker on celadon, amber and tenmoku - and shino
   * and salt still dotted. Subdividing a ramp fixes a blend WITHIN it; carbon trap is a blend
   * BETWEEN shino (#cdb89b, nearly white) and carbon (#17191d, nearly black), and ordered-dithering
   * two colours that far apart is a high-contrast checkerboard no matter how fine either ramp is.
   * ⇒ The transition colours are MIXED IN THE PALETTE instead of on the screen: two carbonised
   * tiers per family, so the dither only ever runs between neighbours that are already close.
   * ⭐ Generalisable, and worth the wing remembering: ordered dither is a tool for crossing a SMALL
   * gap. Any time it is asked to cross a large one it stops being shading and becomes a pattern. */
  var CARBON_TIERS = [0.38, 0.72];
  function carbonise(fam) {
    var base = RAMPS[fam], car = RAMPS.car;
    for (var ti = 0; ti < CARBON_TIERS.length; ti++) {
      var mix = CARBON_TIERS[ti], out = [];
      for (var i = 0; i < base.length; i++) {
        /* map onto the carbon ramp by RELATIVE position so a light step darkens to a light
         * carbon and a dark step to a dark one - a flat mix would crush the whole sweep. */
        var ci = Math.min(car.length - 1, Math.round(i / (base.length - 1) * (car.length - 1)));
        var key = fam + 'C' + ti + '_' + i;
        PALETTE[key] = lerpHex(PALETTE[base[i]], PALETTE[car[ci]], mix);
        out.push(key);
      }
      RAMPS[fam + 'C' + ti] = out;
    }
  }
  ['cel', 'amb', 'iro', 'shi', 'sal'].forEach(carbonise);

  return {
    PALETTE: PALETTE, RAMPS: RAMPS, ANCHORS: ANCHORS, SUBDIV: SUBDIV,
    rgba: rgba, check: check, lerpHex: lerpHex, PREFIX: 'an_'
  };
}));
