/**
 * main.js — ANAGAMA's screens, loop and input.
 *
 * ⛔ THIS FILE OWNS NO RULES. Every decision about what a firing does lives in sim.js, which is
 * pure and headless-testable; every decision about what a pot looks like lives in glaze.js. This
 * is the layer that turns those into screens, and it is deliberately the DUMBEST file in the
 * project - because it is the only one a harness cannot easily play.
 *
 * ⚠️ §3c-6: TWO SCREENS WITH ONE LAYOUT ARE ONE PICTURE. The workshop is a grid of slots, the
 * kiln is a wide dark cross-section, the shelf is a warm gallery. They are built to look
 * different from each other, not merely to hold different text.
 */
(function () {
  'use strict';

  var SIM = window.ANAGAMA_SIM, GLZ = window.ANAGAMA_GLAZE, P = window.ANAGAMA_PAINT;
  var AUD = window.ANAGAMA_AUDIO;

  var S = null;                 /* the game state */
  var screen = 'workshop';
  var selectedGreen = null;     /* which greenware piece is selected for packing/glazing */
  var selectedShelf = null;
  var lastTick = 0, acc = 0;

  var $bar = document.getElementById('bar');
  var $nav = document.getElementById('nav');
  var $screen = document.getElementById('screen');
  var $log = document.getElementById('log');
  var $foot = document.getElementById('foot');
  var $toast = document.getElementById('toast');

  var toastTimer = null;
  function toast(msg) {
    $toast.textContent = msg;
    $toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { $toast.classList.remove('show'); }, 2100);
  }

  /* ── save / resume ──────────────────────────────────────────────────────────────────────────
   * ⛔ Wrapped: localStorage THROWS in a sandboxed iframe with storage disabled, and an itch embed
   * is an iframe. An unwrapped write would take the whole game down on exactly the platform this
   * wing ships to. A player with storage off simply gets no persistence, which is a degraded
   * experience rather than a dead one (§1.4 rung 3: downgrade and ship). */
  function save() {
    try { localStorage.setItem(SIM.SAVE_KEY, SIM.serialize(S)); } catch (e) { /* no storage */ }
  }
  function load() {
    try {
      var t = localStorage.getItem(SIM.SAVE_KEY);
      return t ? SIM.deserialize(t) : null;
    } catch (e) { return null; }
  }

  /* ── header ─────────────────────────────────────────────────────────────────────────────── */
  /**
   * ⛔ BUILT FROM NODES, NOT FROM AN innerHTML STRING, AND THE REASON IS NOT THEORETICAL: `S` is
   * rehydrated from localStorage, which is a surface the player can edit by hand. Interpolating
   * state into innerHTML would let a crafted save execute script on the game's own origin - a
   * self-XSS, but on a page that also carries our storefront links, and free to avoid.
   * Numbers are coerced with Math.floor/String at the boundary so nothing but text can arrive.
   */
  function drawBar() {
    var w = S.wood || {};
    $bar.textContent = '';
    var pairs = [
      ['day', S.day], ['coin', S.money], ['clay', S.clay],
      ['pine', Math.floor(w.pine || 0)], ['oak', Math.floor(w.oak || 0)]
    ];
    if ((S.unlocked.woods || []).indexOf('bamboo') >= 0) pairs.push(['bamboo', Math.floor(w.bamboo || 0)]);
    pairs.push(['salt', S.salt], ['shelf', S.shelf.length]);
    pairs.forEach(function (p) {
      $bar.appendChild(el('span', null, p[0]));
      $bar.appendChild(document.createTextNode(' '));
      $bar.appendChild(el('b', null, String(Number(p[1]) || 0)));
    });
  }

  var TABS = [
    ['workshop', 'Workshop'], ['kiln', 'Kiln'], ['shelf', 'Shelf'], ['shop', 'Wood yard'],
    ['about', 'About']
  ];
  function drawNav() {
    $nav.innerHTML = '';
    TABS.forEach(function (t) {
      var b = document.createElement('button');
      b.textContent = t[1];
      if (screen === t[0]) b.className = 'on';
      b.onclick = function () { screen = t[0]; render(); };
      $nav.appendChild(b);
    });
    var m = document.createElement('button');
    m.textContent = AUD.isEnabled() ? 'Sound on' : 'Sound off';
    m.onclick = function () { AUD.setEnabled(!AUD.isEnabled()); drawNav(); };
    $nav.appendChild(m);
  }

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  }

  function panel(title) {
    var p = el('div', 'panel');
    if (title) p.appendChild(el('h2', null, title));
    return p;
  }

  function btn(label, on, disabled) {
    var b = el('button', null, label);
    if (disabled) b.disabled = true; else b.onclick = on;
    return b;
  }

  /* ── WORKSHOP: throw, glaze, pack ───────────────────────────────────────────────────────── */
  function screenWorkshop() {
    var out = document.createDocumentFragment();

    var t = panel('Throw');
    var r = el('div', 'row');
    S.unlocked.forms.forEach(function (f) {
      var cost = SIM.CLAY_COST[f];
      var why = SIM.canThrow(S, f);
      r.appendChild(btn(GLZ.FORMS[f].label + '  ·  ' + cost, function () {
        var res = SIM.throwPot(S, f);
        if (res.ok) { AUD.play('throwPot'); selectedGreen = res.piece.id; save(); render(); }
        else toast(res.why);
      }, !!why));
    });
    t.appendChild(r);
    t.appendChild(el('p', 'tiny', 'Clay is the cheap part. What it costs you is a place in the kiln.'));
    out.appendChild(t);

    var g = panel('Greenware  ·  ' + S.greenware.length + ' waiting');
    if (!S.greenware.length) {
      g.appendChild(el('p', 'muted', 'Nothing thrown yet.'));
    } else {
      var gal = el('div', 'gal');
      S.greenware.forEach(function (p) {
        var d = el('div', 'piece' + (selectedGreen === p.id ? ' sel' : ''));
        d.appendChild(P.greenCanvas(p, 64));
        var nm = el('div', 'nm', GLZ.FORMS[p.form].label
          + (p.applied !== 'none' ? ' · ' + SIM.GLAZES[p.applied].label : ''));
        d.appendChild(nm);
        d.onclick = function () { selectedGreen = p.id; render(); };
        gal.appendChild(d);
      });
      g.appendChild(gal);

      if (selectedGreen != null && S.greenware.some(function (q) { return q.id === selectedGreen; })) {
        var gr = el('div', 'row');
        gr.style.marginTop = '9px';
        S.unlocked.glazes.forEach(function (gz) {
          gr.appendChild(btn(SIM.GLAZES[gz].label + (SIM.GLAZES[gz].cost ? '  ·  ' + SIM.GLAZES[gz].cost : ''),
            function () {
              var res = SIM.applyGlaze(S, selectedGreen, gz);
              if (res.ok) { AUD.play('glaze'); save(); render(); } else toast(res.why);
            }, S.money < SIM.GLAZES[gz].cost));
        });
        g.appendChild(gr);
        g.appendChild(el('p', 'tiny', 'A glaze is the only thing you decide before the fire has a say.'));
      }
    }
    out.appendChild(g);

    /* the kiln packing grid */
    var k = panel('Pack the kiln  ·  ' + S.packed.length + ' loaded');
    if (S.firing) {
      k.appendChild(el('p', 'muted', 'The kiln is lit. Nothing goes in or out now.'));
    } else {
      var wrap = el('div', 'chambers');
      for (var c = 0; c < S.kiln.chambers; c++) {
        (function (ci) {
          var prof = SIM.chamberProfile(ci, S.kiln.chambers);
          var box = el('div', 'chamber');
          var hd = el('div', 'hd');
          hd.appendChild(el('span', null, 'Chamber ' + (ci + 1)
            + (ci === 0 ? '  (firebox end — most ash, most risk)' : '')));
          hd.appendChild(el('span', null, 'ceiling ' + Math.round(prof.heatCap) + '°'));
          box.appendChild(hd);
          var slots = el('div', 'slots');
          for (var s = 0; s < SIM.C.SLOTS_PER_CHAMBER; s++) {
            (function (si) {
              var occ = S.packed.filter(function (p) { return p.chamber === ci && p.slot === si; })[0];
              var cell = el('div', 'slot' + (occ ? ' full' : ''));
              if (occ) {
                cell.appendChild(P.greenCanvas(occ.piece, 48));
                cell.title = GLZ.FORMS[occ.piece.form].label + ' — click to take out';
                cell.onclick = function () {
                  SIM.unpack(S, occ.piece.id); AUD.play('unpackPot'); save(); render();
                };
              } else {
                cell.title = 'empty slot — the front of the chamber faces the flame';
                cell.onclick = function () {
                  if (selectedGreen == null) { toast('Choose a piece first'); return; }
                  var res = SIM.pack(S, selectedGreen, ci, si);
                  if (res.ok) { AUD.play('packPot'); selectedGreen = null; save(); render(); }
                  else toast(res.why);
                };
              }
              slots.appendChild(cell);
            }(s));
          }
          box.appendChild(slots);
          wrap.appendChild(box);
        }(c));
      }
      k.appendChild(wrap);
      k.appendChild(el('p', 'tiny',
        'Slot 1 is the front of the chamber and faces the flame: most ash, most flashing. '
        + 'Ash and heat both fall off as the fire climbs, so the top chambers are the safe ones.'));
      var lr = el('div', 'row');
      lr.style.marginTop = '9px';
      var lb = btn('Light the kiln', function () {
        var res = SIM.light(S);
        if (!res.ok) { toast(res.why); return; }
        AUD.unlock(); AUD.startMusic(); AUD.play('light');
        screen = 'kiln'; save(); render();
      }, !S.packed.length);
      lb.className = 'go';
      lr.appendChild(lb);
      k.appendChild(lr);
    }
    out.appendChild(k);
    return out;
  }

  /* ── KILN: the firing ───────────────────────────────────────────────────────────────────── */
  var kilnCanvas = null;

  function screenKiln() {
    var out = document.createDocumentFragment();

    var wrap = el('div');
    wrap.id = 'kilnwrap';
    kilnCanvas = document.createElement('canvas');
    kilnCanvas.id = 'kiln';
    kilnCanvas.width = 960; kilnCanvas.height = 380;
    wrap.appendChild(kilnCanvas);
    out.appendChild(wrap);

    var f = S.firing;
    var p = panel(f ? 'The firing' : 'The kiln is cold');

    if (!f) {
      p.appendChild(el('p', 'muted',
        S.packed.length ? 'Loaded and ready. Light it from the workshop.'
          : 'Pack some greenware in the workshop, then light it.'));
      out.appendChild(p);
      return out;
    }

    /* readouts, one per chamber - the numbers behind the colour */
    var readout = el('div');
    for (var i = 0; i < f.chambers.length; i++) {
      var c = f.chambers[i];
      var line = el('div', 'ctl');
      line.appendChild(el('label', null, 'chamber ' + (i + 1)));
      var st = el('span', 'muted');
      var state = c.temp >= SIM.C.OVERFIRE_T ? 'SLUMPING'
        : c.temp >= SIM.C.RUN_T ? 'the ash is running'
          : c.temp >= SIM.C.REACTIVE_T ? 'glaze molten'
            : c.temp >= SIM.C.VITRIFY_T ? 'maturing'
              : c.temp >= 700 ? 'warming' : 'cold';
      st.textContent = state + (c.molten > 0 ? '  ·  molten ' + Math.round(c.molten) + 's' : '');
      st.style.flex = '1';
      line.appendChild(st);
      var tb = el('b', null, Math.round(c.temp) + '°');
      if (c.temp >= SIM.C.OVERFIRE_T) tb.style.color = 'var(--warn)';
      else if (c.temp >= SIM.C.REACTIVE_T) tb.style.color = 'var(--hot)';
      line.appendChild(tb);
      readout.appendChild(line);
    }
    p.appendChild(readout);

    /* the three live controls */
    var sr = el('div', 'ctl');
    sr.appendChild(el('label', null, 'stoke'));
    var si = document.createElement('input');
    si.type = 'range'; si.min = 0; si.max = 100; si.value = Math.round(f.stoke * 100);
    si.oninput = function () { SIM.setStoke(S, si.value / 100); sv.textContent = si.value + '%'; };
    si.onchange = function () { AUD.play('stoke'); };
    sr.appendChild(si);
    var sv = el('b', null, Math.round(f.stoke * 100) + '%');
    sr.appendChild(sv);
    p.appendChild(sr);

    var dr = el('div', 'ctl');
    dr.appendChild(el('label', null, 'damper'));
    var di = document.createElement('input');
    di.type = 'range'; di.min = 0; di.max = 100; di.value = Math.round(f.damper * 100);
    di.oninput = function () {
      SIM.setDamper(S, di.value / 100);
      dv.textContent = di.value > 55 ? 'reducing' : (di.value > 25 ? 'neutral' : 'oxidising');
    };
    dr.appendChild(di);
    var dv = el('b', null, f.damper > 0.55 ? 'reducing' : (f.damper > 0.25 ? 'neutral' : 'oxidising'));
    dv.style.minWidth = '68px';
    dr.appendChild(dv);
    p.appendChild(dr);

    var wr = el('div', 'row');
    S.unlocked.woods.forEach(function (w) {
      var b = btn(SIM.WOODS[w].label + '  ·  ' + Math.floor(S.wood[w]),
        function () { SIM.setWood(S, w); render(); }, S.wood[w] < 1);
      if (f.wood === w) b.className = 'on';
      wr.appendChild(b);
    });
    if (S.salt > 0) {
      wr.appendChild(btn('throw salt  ·  ' + S.salt, function () {
        var res = SIM.throwSalt(S);
        if (res.ok) { AUD.play('salt'); save(); render(); } else toast(res.why);
      }));
    }
    p.appendChild(wr);
    p.appendChild(el('p', 'tiny',
      'Pine burns hot and drops the most ash. Oak is steady and clean. Closing the damper starves '
      + 'the fire of air: it reduces the glaze to green, and it costs you heat, so you must stoke '
      + 'harder to hold it. Reducing a cold kiln does nothing at all.'));

    var ar = el('div', 'row');
    ar.style.marginTop = '9px';
    var db = btn('Draw the fire and open the kiln', function () {
      AUD.play('draw');
      SIM.drawFire(S);
      var res = SIM.unload(S);
      selectedGreen = null;
      var slumped = res.results.filter(function (r) { return r.outcome === 'slumped'; }).length;
      var raw = res.results.filter(function (r) { return r.outcome === 'raw'; }).length;
      var fired = res.results.filter(function (r) { return r.outcome === 'fired'; }).length;
      AUD.play(slumped > fired ? 'ruin' : 'open');
      toast(fired + ' drawn' + (raw ? ', ' + raw + ' raw' : '') + (slumped ? ', ' + slumped + ' slumped' : ''));
      screen = 'shelf';
      save(); render();
    });
    db.className = 'go';
    ar.appendChild(db);
    p.appendChild(ar);
    out.appendChild(p);
    return out;
  }

  /* ── SHELF: the gallery, and the collectors ─────────────────────────────────────────────── */
  function screenShelf() {
    var out = document.createDocumentFragment();

    var g = panel('The shelf  ·  ' + S.shelf.length + ' kept');
    if (!S.shelf.length) {
      g.appendChild(el('p', 'muted', 'Nothing fired yet. Everything you draw from the kiln stays here forever.'));
    } else {
      var gal = el('div', 'gal');
      S.shelf.slice().reverse().forEach(function (spec) {
        var d = el('div', 'piece' + (selectedShelf === spec.id ? ' sel' : ''));
        d.appendChild(P.potCanvas(spec, 96));
        d.appendChild(el('div', 'nm', SIM.descriptorFor(spec) + ' ' + GLZ.FAMILY_LABEL[spec.family]
          + ' ' + GLZ.FORMS[spec.form].label + '  ·  ' + Math.round(spec.quality * 100)));
        d.onclick = function () { selectedShelf = spec.id; render(); };
        gal.appendChild(d);
      });
      g.appendChild(gal);
      g.appendChild(el('p', 'tiny',
        'Every piece was made once, by a fire that will not happen again. Nothing here is ever lost.'));
    }
    out.appendChild(g);

    var c = panel('Collectors');
    if (!S.collectors.length) {
      c.appendChild(el('p', 'muted', 'Nobody is asking for anything today.'));
    } else {
      S.collectors.forEach(function (w) {
        var row = el('div', 'shopitem');
        var left = el('div');
        left.appendChild(el('div', null, 'Wants ' + SIM.wantText(w)));
        var have = S.shelf.filter(function (s) { return SIM.matches(s, w); });
        left.appendChild(el('div', 'tiny', have.length
          ? have.length + ' on the shelf would satisfy this'
          : 'nothing on the shelf matches'));
        row.appendChild(left);
        row.appendChild(btn('sell  ·  ~' + w.pays, function () {
          var m = S.shelf.filter(function (s) { return SIM.matches(s, w); })[0];
          if (!m) { toast('Nothing on the shelf matches'); return; }
          var res = SIM.sell(S, m.id, w.id);
          if (res.ok) { AUD.play('sell'); toast('Sold for ' + res.price); save(); render(); }
          else toast(res.why);
        }, !have.length));
        c.appendChild(row);
      });
    }
    out.appendChild(c);

    if (selectedShelf != null) {
      var sel = S.shelf.filter(function (s) { return s.id === selectedShelf; })[0];
      if (sel) {
        var d2 = panel('This piece');
        d2.appendChild(el('p', 'muted',
          GLZ.FAMILY_LABEL[sel.family] + ' on a ' + GLZ.FORMS[sel.form].label
          + '. Chamber ' + (sel.chamber + 1) + ', peaked ' + sel.peak + '°, '
          + (sel.atmos === 'red' ? 'reduction' : 'oxidation') + '. '
          + 'Ash ' + Math.round(sel.ash * 100) + ', flashing ' + Math.round(sel.flash * 100)
          + (sel.salt > 0.1 ? ', salt ' + Math.round(sel.salt * 100) : '')
          + (sel.carbon > 0.1 ? ', carbon ' + Math.round(sel.carbon * 100) : '') + '.'));
        var sr2 = el('div', 'row');
        sr2.appendChild(btn('sell to nobody in particular  ·  ' + SIM.basePrice(sel), function () {
          var res = SIM.sell(S, sel.id, null);
          if (res.ok) { AUD.play('sell'); toast('Sold for ' + res.price); selectedShelf = null; save(); render(); }
        }));
        d2.appendChild(sr2);
        out.appendChild(d2);
      }
    }
    return out;
  }

  /* ── SHOP ───────────────────────────────────────────────────────────────────────────────── */
  function screenShop() {
    var out = document.createDocumentFragment();
    var p = panel('The wood yard');
    SIM.SHOP.forEach(function (item) {
      if (item.once && SIM.bought(S, item.id)) return;
      var row = el('div', 'shopitem');
      var left = el('div');
      left.appendChild(el('div', null, item.label));
      if (item.id === 'chamber') {
        left.appendChild(el('div', 'tiny',
          'A longer kiln draws harder. Every chamber you already have gets hotter and cleaner. '
          + 'Currently ' + S.kiln.chambers + ' chambers, draft ' + SIM.draftOf(S).toFixed(2) + '.'));
      }
      row.appendChild(left);
      row.appendChild(btn(String(item.cost), function () {
        var res = SIM.buy(S, item.id);
        if (res.ok) { AUD.play('buy'); save(); render(); } else toast(res.why);
      }, S.money < item.cost));
      p.appendChild(row);
    });
    out.appendChild(p);

    var cd = panel('What the fire has shown you');
    var fams = Object.keys(S.codex);
    if (!fams.length) cd.appendChild(el('p', 'muted', 'Nothing yet. Fire something.'));
    else {
      var list = el('div', 'row');
      fams.forEach(function (f) { list.appendChild(el('div', 'muted', GLZ.FAMILY_LABEL[f])); });
      cd.appendChild(list);
      cd.appendChild(el('p', 'tiny', fams.length + ' of 5 surfaces found.'));
    }
    out.appendChild(cd);
    return out;
  }

  /* ── ABOUT ──────────────────────────────────────────────────────────────────────────────────
   * ⛔ THE AI DISCLOSURE LIVED ONLY IN CREDITS.txt AND LICENSE.txt, i.e. in two files INSIDE the
   * archive that a player in an itch iframe can never open. The wing's §4c polish checklist
   * requires the disclosure in the CREDITS SCREEN, and this game had no credits screen at all -
   * so the product satisfied the letter of §4.1 on the storefront's own disclosure fields while
   * the running game said nothing. Found by grepping the shipped js for "disclosure" and getting
   * zero hits outside the .txt files.
   * ⚠️ It is a plain panel in the page flow, NOT an overlay: wing §3e-4 records an overlay with
   * `align-items:center` clipping both ends of anything taller than the iframe, which is exactly
   * what a credits list is. */
  function screenAbout() {
    var out = document.createDocumentFragment();

    var a = panel('About this kiln');
    a.appendChild(el('p', null,
      'ANAGAMA is a free browser game about a wood-fired kiln cut into a hillside. Throw pots, pack '
      + 'them up the slope, then light the fire and stay with it. Where a pot stood and what the '
      + 'flame did while it was in there is the whole of what comes out.'));
    a.appendChild(el('p', 'tiny',
      'Your shelf and your money are saved in this browser. A ruined firing costs that load and '
      + 'never the shelf.'));
    out.appendChild(a);

    var m = panel('How it is made');
    m.appendChild(el('p', null,
      'Every pot you see is drawn at the moment you look at it, from the firing that produced it. '
      + 'There is no pot picture anywhere in this game. The four surface textures are generated by '
      + 'code, the music is synthesised from oscillators into a seamless loop, and every sound '
      + 'effect is made in your browser as it plays. No third-party art, audio, font or stock pack '
      + 'is used, so there is nothing here to attribute.'));
    out.appendChild(m);

    var d = panel('AI disclosure');
    d.appendChild(el('p', 'tiny',
      'Declared the same way on every storefront that asks:'));
    [
      ['Code', 'YES — written with AI assistance.'],
      ['Graphics', 'YES — generated by code written with AI assistance.'],
      ['Sounds', 'NO — self-contained procedural synthesis from oscillators and noise. No generative-audio model was used at any point.'],
      ['Text & Dialog', 'YES — the copy in this game was authored with AI assistance.']
    ].forEach(function (r) {
      var row = el('div', 'shopitem');
      row.appendChild(el('div', null, r[0]));
      row.appendChild(el('div', 'tiny', r[1]));
      d.appendChild(row);
    });
    out.appendChild(d);

    var c = panel('Credits');
    c.appendChild(el('p', null, 'Core Systems Asset Factory'));
    c.appendChild(el('p', 'tiny', 'Copyright © 2026 Core Systems Asset Factory. Free to play.'));
    out.appendChild(c);

    return out;
  }

  /* ── render ─────────────────────────────────────────────────────────────────────────────── */
  function render() {
    drawBar(); drawNav();
    $screen.innerHTML = '';
    var frag = screen === 'workshop' ? screenWorkshop()
      : screen === 'kiln' ? screenKiln()
        : screen === 'shelf' ? screenShelf()
          : screen === 'about' ? screenAbout() : screenShop();
    $screen.appendChild(frag);

    $log.innerHTML = '';
    S.log.slice(-14).reverse().forEach(function (l) {
      $log.appendChild(el('div', null, 'day ' + l.day + ' — ' + l.text));
    });

    $foot.textContent = 'Made by Core Systems Asset Factory. ' + S.stats.fired + ' pots fired, '
      + S.stats.lost + ' lost to the fire, ' + S.stats.sold + ' sold. Progress saves itself.';
    if (screen === 'kiln' && kilnCanvas) paintKiln();
  }

  function paintKiln() {
    if (!kilnCanvas) return;
    var ctx = kilnCanvas.getContext('2d');
    P.drawKiln(ctx, S, kilnCanvas.width, kilnCanvas.height);
  }

  /* ── the loop ───────────────────────────────────────────────────────────────────────────── */
  /**
   * ⚠️ FIXED-STEP, and it matters: sim.js is stepped at exactly SIM.C.TICK whatever the frame rate,
   * so the balance measured headlessly by sim_probe.js is the balance the player gets. A
   * variable-dt loop would mean a fast machine fires a different game from a slow one.
   * ⛔ The accumulator is CLAMPED. A backgrounded tab (or a phone waking up) hands you a delta of
   * minutes, and without the clamp the kiln would silently run a whole firing - and over-fire the
   * load - while nobody was looking. That is the tab-away case §1.1b requires to be exercised.
   */
  function loop(now) {
    requestAnimationFrame(loop);
    if (!lastTick) lastTick = now;
    var dt = (now - lastTick) / 1000;
    lastTick = now;
    if (dt > 0.5) dt = 0.5;

    if (S.firing && !S.firing.ended) {
      acc += dt;
      var did = false;
      while (acc >= SIM.C.TICK) {
        var wasOver = S.firing.over;
        SIM.step(S, SIM.C.TICK);
        acc -= SIM.C.TICK;
        simSeconds += SIM.C.TICK;
        did = true;
        if (!wasOver && S.firing.over) AUD.play('warn');
        if (S.firing.ended) break;
      }
      if (did && screen === 'kiln') {
        paintKiln();
        refreshKilnNumbers();
      }
      saveThrottled();
    } else if (screen === 'kiln') {
      paintKiln();
    }
  }

  /* update only the numbers, not the whole DOM: rebuilding the panel every frame would fight the
   * player's finger on the sliders (§3e-4, a DOM UI failure mode a canvas game cannot have) */
  var numberEls = null;
  function refreshKilnNumbers() {
    var bs = $screen.querySelectorAll('.ctl b');
    if (!bs.length || !S.firing) return;
    for (var i = 0; i < S.firing.chambers.length && i < bs.length; i++) {
      var c = S.firing.chambers[i];
      bs[i].textContent = Math.round(c.temp) + '°';
      bs[i].style.color = c.temp >= SIM.C.OVERFIRE_T ? 'var(--warn)'
        : (c.temp >= SIM.C.REACTIVE_T ? 'var(--hot)' : '');
    }
    var spans = $screen.querySelectorAll('.ctl .muted');
    for (var j = 0; j < S.firing.chambers.length && j < spans.length; j++) {
      var cc = S.firing.chambers[j];
      spans[j].textContent = (cc.temp >= SIM.C.OVERFIRE_T ? 'SLUMPING'
        : cc.temp >= SIM.C.RUN_T ? 'the ash is running'
          : cc.temp >= SIM.C.REACTIVE_T ? 'glaze molten'
            : cc.temp >= SIM.C.VITRIFY_T ? 'maturing'
              : cc.temp >= 700 ? 'warming' : 'cold')
        + (cc.molten > 0 ? '  ·  molten ' + Math.round(cc.molten) + 's' : '');
    }
  }

  var saveAt = 0;
  function saveThrottled() {
    var t = Date.now();
    if (t - saveAt > 2500) { saveAt = t; save(); }
  }

  /* ── boot ───────────────────────────────────────────────────────────────────────────────── */
  function boot() {
    S = load() || SIM.newGame();
    if (!S.log.length) {
      S.log.push({ day: 1, text: 'The kiln is cold and the hill is quiet. Throw something.' });
      SIM.refreshCollectors(S);
    }
    P.loadPlates(['firebrick', 'earth', 'ash', 'timber'], function () { render(); });
    render();
    requestAnimationFrame(loop);

    /* a real gesture is the only thing that can start audio */
    var once = function () {
      AUD.unlock(); AUD.startMusic();
      window.removeEventListener('pointerdown', once);
      window.removeEventListener('keydown', once);
    };
    window.addEventListener('pointerdown', once);
    window.addEventListener('keydown', once);

    window.addEventListener('beforeunload', save);
    /* a phone backgrounding the tab is the commonest way a run is lost - save on the way out */
    document.addEventListener('visibilitychange', function () { if (document.hidden) save(); });
  }

  /* ── KEYBOARD CONTROL ────────────────────────────────────────────────────────────────────────
   * The two live controls of a firing are a stoke and a damper, and a slider is a poor thing to
   * ask for on a keyboard. Arrow keys drive both, so the firing - the part of the game that is
   * actually real-time - is playable without a pointer at all.
   * ⚠️ It also gives `html5_gate.js` REAL EVENT WIRING to prove: the gate dispatches genuine DOM
   * events on `window` rather than calling the game's own methods, because what breaks inside an
   * itch iframe is the wiring, not the function.
   */
  var inputsHandled = 0;
  function onKey(e) {
    if (!S || !S.firing || S.firing.ended) return;
    var f = S.firing, hit = true;
    if (e.key === 'ArrowUp') SIM.setStoke(S, f.stoke + 0.08);
    else if (e.key === 'ArrowDown') SIM.setStoke(S, f.stoke - 0.08);
    else if (e.key === 'ArrowRight') SIM.setDamper(S, f.damper + 0.10);
    else if (e.key === 'ArrowLeft') SIM.setDamper(S, f.damper - 0.10);
    else hit = false;
    if (hit) {
      inputsHandled++;
      e.preventDefault();
      if (screen === 'kiln') render();
    }
  }
  window.addEventListener('keydown', onKey);

  /* ── THE ENGINE GATE'S TEST SURFACE (Kernel/engines/html5_gate.js) ───────────────────────────
   * The contract is declared BY THE GAME and the gate stays dumb - that file records a FALSE RED
   * from the days when it hard-coded one product's global, and §2b prices a false red exactly as
   * expensively as a false green.
   *   elapsed  — simulated seconds. The gate reads it TWICE: a game whose loop never ticks still
   *              renders a first frame and reports no errors, and only a second reading of the
   *              clock tells them apart.
   *   begin()  — start a real run, so there is a clock to advance at all.
   *   inputProbe — real DOM events, and a counter only the real handler can move.
   */
  var simSeconds = 0;
  window.__game = {
    get elapsed() { return simSeconds; },
    begin: function () {
      S = SIM.newGame(7);
      for (var i = 0; i < 2; i++) {
        var t = SIM.throwPot(S, 'chawan');
        if (t.ok) SIM.pack(S, t.piece.id, 0, i);
      }
      SIM.light(S);
      screen = 'kiln';
      render();
    },
    inputProbe: {
      events: [
        { type: 'keydown', init: { key: 'ArrowUp', bubbles: true } },
        { type: 'keydown', init: { key: 'ArrowUp', bubbles: true } },
        { type: 'keydown', init: { key: 'ArrowRight', bubbles: true } }
      ],
      read: function () { return inputsHandled; },
      settleMs: 220
    }
  };

  /* exposed ONLY for the test harness, which drives the real game rather than a copy of it */
  window.ANAGAMA_DEBUG = {
    state: function () { return S; },
    go: function (s) { screen = s; render(); },
    render: render,
    reset: function () { S = SIM.newGame(1); save(); render(); },
    /* used by store_assets.js to photograph a REPRESENTATIVE session rather than a degenerate
     * one - the first shelf capture showed six identical bowls because the harness had thrown six
     * of one form, which is a true screenshot of an unrepresentative game */
    load: function (st) { S = st; render(); }
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
}());
