/**
 * sim.js — ANAGAMA's simulation. NO DOM, NO CANVAS, NO TIMERS.
 *
 * ⛔ IT IS PURE ON PURPOSE, AND THAT IS A TESTABILITY DECISION BEFORE IT IS AN ARCHITECTURE ONE.
 * §1.1b says there is no human tester, so a harness has to be able to PLAY this game from title to
 * a real ending, thousands of times, in Node. A simulation entangled with rAF and the DOM can only
 * be tested by a browser and a person. Everything here advances by `step(state, dt)` and every
 * player action is a function from state to state, so the harness and the game drive the SAME
 * code - master §2b's "a capture harness and the game are two input drivers" defect cannot happen
 * because there is only one driver.
 *
 * ── GATE 4 (ledger B5, the complexity floor), IMPLEMENTED, NOT PROMISED ──────────────────────
 * Four systems, and each one CHANGES WHAT ANOTHER ONE DOES:
 *
 *  1. KILN GEOMETRY. Chambers climb a slope. Heat, ash and atmosphere all arrive from below, so
 *     position IS the variable. ⭐ Adding a chamber lengthens the kiln, which increases DRAFT,
 *     which makes every chamber you already had hotter and cleaner - the upgrade reaches
 *     BACKWARDS into the pots you already know how to make. That is the anti-"+10% button".
 *
 *  2. FIRING DYNAMICS. Heat propagates UP the slope with a lag, so a chamber four along is
 *     responding to a decision you made a minute ago. You are always firing the past.
 *
 *  3. GLAZE CHEMISTRY. Ash, atmosphere and peak temperature combine into a surface. ⭐ The
 *     atmosphere only COUNTS while the glaze is molten (above REACTIVE_T): reducing a cold kiln
 *     does nothing at all, which is the single most important thing a real potter knows and the
 *     thing that makes the damper a skill rather than a switch.
 *
 *  4. DEMAND. Collectors want SURFACES ("a reduction jar with heavy ash on one shoulder"), not
 *     pots. So what is worth firing decides what is worth packing, and where.
 *
 * SAVE/RESUME (wing §2, standing rule): everything is one JSON-able object, and a ruined firing
 * costs the LOAD, never the shelf.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./glaze.js'));
  else root.ANAGAMA_SIM = factory(root.ANAGAMA_GLAZE);
}(typeof self !== 'undefined' ? self : this, function (GLZ) {
  'use strict';

  /* ── constants. Named, because a bare number in a balance expression is unreviewable. ─────── */
  var C = {
    VITRIFY_T: 1150,      /* below this the clay never matures: the piece comes out raw       */
    REACTIVE_T: 1240,     /* above this the glaze is MOLTEN - only now does atmosphere matter */
    RUN_T: 1285,          /* above this melted ash actually RUNS and can drip                 */
    OVERFIRE_T: 1355,     /* above this pieces slump. The load is lost, the shelf is not.     */
    AMBIENT_T: 20,
    TICK: 0.25,           /* seconds of sim per step. The UI may render faster; sim is fixed. */
    STOKE_COST: 1,        /* wood per stoke unit per second                                   */
    /* Sized so that full-stoke pine OVERSHOOTS the chamber ceiling (over-firing must be a real
     * risk a player can walk into) while a steady ~0.75 lands in the ash-melting band. Derived,
     * not guessed: see sim_probe.js, which asserts both failure states are REACHABLE. */
    HEAT_PER_WOOD: 1500,
    /* ⛔ SIZED AGAINST THE MEASURED MOLTEN WINDOW, NOT GUESSED. The atmosphere memory decides the
     * surface family, so its time constant has to be short relative to how long a glaze is
     * actually molten - and the first value (35 s) was picked before anyone had measured that.
     * Traced across a played game the molten window runs 20-45 s, so a 35 s memory could never
     * converge inside a single firing: a hard reduction held for the WHOLE molten period topped
     * out at atmosMem 0.389 against a 0.5 threshold, and the playthrough discovered exactly one
     * surface family in fourteen firings. At 15 s the same firing reaches ~0.69. The constant is
     * "roughly the last third of a firing", which is also what it means physically. */
    ATMOS_TAU: 15,
    BASE_DRAFT: 1.0,
    DRAFT_PER_CHAMBER: 0.085,
    SLOTS_PER_CHAMBER: 6,
    /* ⛔⛔ THE KILN'S SHAPE IS A SPAN ACROSS THE WHOLE TUNNEL, NEVER A PER-CHAMBER STEP.
     * Every field below used to be `base - i * step`, which makes the kiln's TOTAL spread grow
     * without bound as a player buys chambers - and `SHOP.chamber` is uncapped. Measured on the
     * shipped build (`_probe_heat_ladder.js`): at the absolute ceiling (bamboo, stoke 1.0, damper
     * fully open) chamber index 2 equilibrated at 1076-1080 deg against VITRIFY_T 1150 for EVERY
     * kiln size, so 24 of 36 chamber slots could never fire a pot at any setting a player can
     * reach, while the shop went on selling chambers and the workshop went on letting you pack
     * them. A span keeps the tunnel's ends fixed and makes a longer kiln MORE EVEN, which is both
     * the real reason climbing kilns were built long and a genuine reward for the upgrade. */
    KILN_RETENTION: 0.87, /* the TOP chamber's share of the firebox chamber's drive, any kiln size */
    CAP_BASE: 1450,       /* ceiling at the firebox chamber - above OVERFIRE_T, so slumping is real */
    CAP_SPAN: 120,        /* how much lower the TOP chamber's ceiling is, across the whole tunnel   */
    ASH_BASE: 1.45,       /* ash delivered at the firebox chamber                                   */
    ASH_SPAN: 1.15,       /* how much less the top chamber gets. < ASH_BASE, so it can never go < 0 */
    EVEN_BASE: 0.42,      /* the firebox chamber is a lottery                                       */
    EVEN_SPAN: 0.50,      /* the top chamber is a safe pair of hands. BASE+SPAN < 1 by construction */
    LAG_REF: 1.5          /* the firebox chamber's own response constant - see step()               */
  };

  /* Wood species: the second lever on the fire, and they genuinely trade off. */
  var WOODS = {
    pine: { label: 'pine', heat: 1.30, ash: 1.55, burn: 1.45, cost: 3 },
    oak: { label: 'oak', heat: 1.00, ash: 0.55, burn: 0.70, cost: 4 },
    bamboo: { label: 'bamboo', heat: 1.62, ash: 0.95, burn: 2.10, cost: 6 }
  };

  /* Applied glazes. `none` is free and is the classic anagama surface: ash alone. */
  var GLAZES = {
    none: { label: 'bare (natural ash)', cost: 0 },
    iron: { label: 'iron slip', cost: 6 },
    shino: { label: 'shino', cost: 9 }
  };

  /* ── chamber profile ────────────────────────────────────────────────────────────────────────
   * Up the slope: cooler, cleaner, calmer. The firebox chamber is a lottery and the top chamber
   * is a safe pair of hands, which is the whole packing decision in one line. */
  function chamberProfile(i, n) {
    var draft = C.BASE_DRAFT + C.DRAFT_PER_CHAMBER * Math.max(0, n - 2);
    /* WHERE UP THE SLOPE THIS CHAMBER SITS: 0 at the firebox, 1 at the top, whatever `n` is.
     * ⛔ This single number is the fix for the ship-blocker described at C.KILN_RETENTION. Every
     * field derived from it has both ends PINNED, so no kiln size can push one out of range. */
    var up = n > 1 ? i / (n - 1) : 0;
    return {
      index: i,
      /* the share of the firebox's drive that still reaches here. Geometric, so adjacent chambers
       * differ by a constant RATIO and the tunnel's two ends stay put as the kiln grows. */
      heatShare: Math.pow(C.KILN_RETENTION, up),
      /* the firebox chamber runs hottest and the ceiling falls as you climb - but DRAFT lifts
       * every one of them, which is how a new chamber changes the old ones.
       * ⛔ THE BASE WAS 1395 AND OVER-FIRING WAS THEREFORE UNREACHABLE. A chamber equilibrates a
       * little BELOW its ceiling (heat in against continuous cooling: measured 1339° against a
       * 1395° cap), so a ceiling only 40° above OVERFIRE_T can never actually cross it and the
       * game's headline risk did not exist. The ceiling now sits far enough above the danger line
       * that a sustained full stoke really does slump the load - which is what makes the stoke
       * lever a decision instead of a slider you leave at maximum. */
      heatCap: (C.CAP_BASE - C.CAP_SPAN * up) * (0.90 + 0.10 * draft),
      ashFactor: (C.ASH_BASE - C.ASH_SPAN * up) * draft, /* ash falls out of the flame as it climbs */
      evenness: C.EVEN_BASE + C.EVEN_SPAN * up,          /* the top chambers are predictable         */
      lag: 1.0 + i * 1.55                        /* seconds before the firebox reaches here  */
    };
  }

  function draftOf(state) {
    return C.BASE_DRAFT + C.DRAFT_PER_CHAMBER * Math.max(0, state.kiln.chambers - 2);
  }

  /* ── new game ───────────────────────────────────────────────────────────────────────────── */
  function newGame(seed) {
    return {
      v: 1,
      seed: (seed === undefined ? (Date.now() & 0x7fffffff) : seed) | 0,
      nextId: 1,
      day: 1,
      money: 40,
      clay: 12,
      wood: { pine: 90, oak: 40, bamboo: 0 },
      salt: 0,
      kiln: { chambers: 2 },
      greenware: [],     /* thrown, unglazed, waiting                */
      packed: [],        /* in the kiln, awaiting a firing           */
      shelf: [],         /* fired and KEPT. Never lost.              */
      firing: null,
      collectors: [],
      codex: {},         /* surfaces discovered, family -> true      */
      unlocked: { forms: ['chawan', 'yunomi', 'guinomi'], glazes: ['none'], woods: ['pine', 'oak'] },
      stats: { fired: 0, made: 0, lost: 0, sold: 0, earned: 0, firings: 0 },
      log: []
    };
  }

  function rngFor(state, salt) {
    return GLZ.mulberry32((state.seed | 0) + (salt | 0) * 7919 + state.nextId * 31);
  }

  function note(state, text) {
    state.log.push({ day: state.day, text: text });
    if (state.log.length > 60) state.log.shift();
  }

  /* ── 1. THROWING ────────────────────────────────────────────────────────────────────────── */
  var CLAY_COST = { chawan: 2, yunomi: 2, guinomi: 1, tokkuri: 3, tsubo: 4, hanaire: 3, sara: 3, kame: 5, mizusashi: 4, henko: 3 };

  function canThrow(state, form) {
    if (state.unlocked.forms.indexOf(form) < 0) return 'not learned';
    if (state.clay < CLAY_COST[form]) return 'not enough clay';
    return null;
  }

  function throwPot(state, form) {
    var why = canThrow(state, form);
    if (why) return { ok: false, why: why };
    state.clay -= CLAY_COST[form];
    var p = {
      id: state.nextId++, form: form, applied: 'none',
      seed: (rngFor(state, 1)() * 1e9) | 0
    };
    state.greenware.push(p);
    state.stats.made++;
    return { ok: true, piece: p };
  }

  /** Applying a glaze costs money and is the ONE decision made before the fire has any say. */
  function applyGlaze(state, pieceId, glaze) {
    if (state.unlocked.glazes.indexOf(glaze) < 0) return { ok: false, why: 'not learned' };
    var p = state.greenware.filter(function (q) { return q.id === pieceId; })[0];
    if (!p) return { ok: false, why: 'no such piece' };
    var cost = GLAZES[glaze].cost;
    if (state.money < cost) return { ok: false, why: 'not enough money' };
    state.money -= cost;
    p.applied = glaze;
    return { ok: true, piece: p };
  }

  /* ── 2. PACKING ─────────────────────────────────────────────────────────────────────────── */
  /**
   * A slot is (chamber, position). Position 0 is the flame-facing front of the chamber and takes
   * the most ash and the most flashing; the back is quieter. That is the second axis of the
   * packing decision, under the chamber choice.
   */
  function pack(state, pieceId, chamber, slot) {
    if (state.firing) return { ok: false, why: 'the kiln is lit' };
    if (chamber < 0 || chamber >= state.kiln.chambers) return { ok: false, why: 'no such chamber' };
    if (slot < 0 || slot >= C.SLOTS_PER_CHAMBER) return { ok: false, why: 'no such slot' };
    if (state.packed.some(function (q) { return q.chamber === chamber && q.slot === slot; })) {
      return { ok: false, why: 'slot taken' };
    }
    var i = -1;
    for (var k = 0; k < state.greenware.length; k++) if (state.greenware[k].id === pieceId) i = k;
    if (i < 0) return { ok: false, why: 'no such piece' };
    var p = state.greenware.splice(i, 1)[0];
    state.packed.push({ piece: p, chamber: chamber, slot: slot });
    return { ok: true };
  }

  function unpack(state, pieceId) {
    if (state.firing) return { ok: false, why: 'the kiln is lit' };
    for (var k = 0; k < state.packed.length; k++) {
      if (state.packed[k].piece.id === pieceId) {
        state.greenware.push(state.packed.splice(k, 1)[0].piece);
        return { ok: true };
      }
    }
    return { ok: false, why: 'not packed' };
  }

  /* ── 3. THE FIRING ──────────────────────────────────────────────────────────────────────── */
  /**
   * Light the kiln. From here the player has three live controls and no way to undo: stoke rate,
   * damper and wood. Everything else is consequence.
   */
  function light(state) {
    if (state.firing) return { ok: false, why: 'already lit' };
    if (!state.packed.length) return { ok: false, why: 'nothing packed' };
    var n = state.kiln.chambers;
    var ch = [];
    for (var i = 0; i < n; i++) {
      var prof = chamberProfile(i, n);
      ch.push({
        prof: prof, temp: C.AMBIENT_T, o2: 1.0,
        /* accumulators - the HISTORY that becomes the glaze */
        ash: 0, reduction: 0, carbon: 0, peak: C.AMBIENT_T, molten: 0, salt: 0, atmosMem: 0
      });
    }
    state.firing = {
      t: 0, chambers: ch, stoke: 0.5, damper: 0.15, wood: 'pine',
      fireboxHeat: 0, over: false, ended: false, saltThrown: 0,
      history: []
    };
    state.stats.firings++;
    note(state, 'The kiln is lit.');
    return { ok: true };
  }

  function setStoke(state, v) { if (state.firing) state.firing.stoke = Math.max(0, Math.min(1, v)); }
  function setDamper(state, v) { if (state.firing) state.firing.damper = Math.max(0, Math.min(1, v)); }
  function setWood(state, w) {
    if (state.firing && WOODS[w] && state.unlocked.woods.indexOf(w) >= 0) state.firing.wood = w;
  }
  /** Salt is a one-shot vapour event and it glazes EVERY chamber at once - it cannot be aimed. */
  function throwSalt(state) {
    var f = state.firing;
    if (!f) return { ok: false, why: 'not lit' };
    if (state.salt < 1) return { ok: false, why: 'no salt' };
    if (f.chambers[0].temp < C.REACTIVE_T) return { ok: false, why: 'too cold for vapour' };
    state.salt--; f.saltThrown++;
    /* ⛔ 0.55 PER THROW WAS EXACTLY THE THRESHOLD `familyFor` USES, so a single throw landed on
     * 0.55 and the strict `> 0.55` comparison meant salt NEVER produced a salt surface anywhere.
     * A lever that misses its own trigger by a floating-point hair is indistinguishable from an
     * unwired one. 0.70 puts ONE throw over the line in the firebox chamber and leaves the
     * chambers above it needing a second - which is the gradient the mechanic wants anyway. */
    for (var i = 0; i < f.chambers.length; i++) {
      f.chambers[i].salt += 0.70 / (1 + i * 0.35);
    }
    note(state, 'Salt into the firebox. The whole kiln will wear it.');
    return { ok: true };
  }

  /**
   * ONE simulation step. `dt` is seconds.
   * ⚠️ Called with a FIXED dt by both the harness and the game loop. A variable-dt sim would make
   * a playthrough non-reproducible, which would make every balance measurement noise.
   */
  function step(state, dt) {
    var f = state.firing;
    if (!f || f.ended) return;
    f.t += dt;
    var wood = WOODS[f.wood];
    var draft = draftOf(state);

    /* ── fuel burn. Out of wood is a real, losable failure state.
     * ⛔ `rate` IS PER SECOND AND `got` IS PER STEP, AND CONFLATING THEM MADE THE KILN A CANDLE.
     * The first draft fed the PER-STEP wood figure into the heat expression, so the whole
     * simulation's temperature scaled with the timestep and the kiln peaked at 63° at full stoke
     * against a 1150° vitrification point. It was caught by this probe's own self-test control -
     * "fire() responds to stoke" - which is exactly why that control exists: every connectivity
     * arm below would otherwise have been comparing two firings that were both stone cold. */
    var rate = f.stoke * wood.burn * C.STOKE_COST;          /* wood per SECOND               */
    var want = rate * dt;                                    /* wood this step                */
    var have = state.wood[f.wood] || 0;
    var got = Math.min(have, want);
    state.wood[f.wood] = have - got;
    var starved = got < want - 1e-9;
    var actualRate = dt > 0 ? got / dt : 0;                  /* what the fire really got, /s  */

    /* THE FIREBOX. The damper trades oxygen for heat exactly as a real one does: choke the air
     * and you get reduction and you also get LESS heat, which is the tension the whole game sits
     * on - the surface you want and the temperature you need pull against each other. */
    /* ⛔ THE PENALTY WAS 0.55 + 0.45*airflow AND IT MADE HEAVY REDUCTION STRUCTURALLY IMPOSSIBLE,
     * not merely hard: at damper 0.92 the firebox lost ~30% of its heat, so chamber 0 topped out
     * at 1123° against a 1150° vitrification point AT FULL STOKE. Every reduction firing came out
     * raw, which means the celadon half of the game - one of the two surfaces the damper exists to
     * choose between - was unreachable at every point in the parameter space. That is a structural
     * finding rather than a tuning miss (master §2b: when a target is unreachable EVERYWHERE, stop
     * tuning and look at the rule). Softened so reduction is EXPENSIVE - you must stoke harder and
     * burn more wood - instead of forbidden. ⭐ It also makes the kiln-extension upgrade matter
     * more than its own arm claims: more draft means more air, so a longer kiln is what lets you
     * reduce hard and still get hot. */
    var airflow = (0.25 + 0.75 * (1 - f.damper)) * draft;
    var heatIn = actualRate * wood.heat * C.HEAT_PER_WOOD * (0.72 + 0.28 * airflow);
    f.fireboxHeat += (heatIn - f.fireboxHeat) * Math.min(1, dt * 1.5);

    for (var i = 0; i < f.chambers.length; i++) {
      var c = f.chambers[i];
      var p = c.prof;

      /* ── heat, arriving from the fire with a lag that grows up the slope.
       * ⛔⛔ THIS USED TO CHAIN — `upstream = chambers[i-1].temp` — AND THAT IS THE SHIP-BLOCKER
       * MECHANISM, NOT THE CEILINGS. Two rates modelled one chamber and only ONE of them was
       * scaled by its lag: the heating coupling was `dt / (lag*0.9+0.6)`, which weakens as you
       * climb, while cooling was a flat per-second drain that did not. So each chamber settled at
       * a LOWER fraction of its target than the one below it, and the chain MULTIPLIED those
       * fractions together. Measured on the shipped build at the absolute ceiling: T/heatCap fell
       * 0.95 -> 0.89 -> 0.78 -> 0.67 -> 0.53 -> 0.42, i.e. the ceilings were never the binding
       * constraint at all and no ceiling change could have fixed it.
       * The fire is now read ONCE and each chamber takes its own share of it, so a deficit cannot
       * compound; `lag` is left to do the one job it is named for, which is WHEN the heat arrives.
       * ⚠️ Ordering is still guaranteed (heatShare and heatCap both fall monotonically up the
       * slope), except during cool-down, where the top chambers correctly hold their heat longest. */
      var flame = f.fireboxHeat * 0.55 + C.AMBIENT_T;
      var target = Math.min(p.heatCap, C.AMBIENT_T + (flame - C.AMBIENT_T) * p.heatShare);
      var lagConst = p.lag * 0.9 + 0.6;
      c.temp += (target - c.temp) * Math.min(1, dt / lagConst);
      /* Cooling is always on, and it is why you cannot simply stop stoking. ⛔ It is scaled by the
       * SAME lag constant as the heating above: a drain that ignores the chamber's response time
       * is exactly what produced the compounding deficit, so the two must move together or the
       * equilibrium silently depends on how far up the slope you are. */
      c.temp -= (c.temp - C.AMBIENT_T) * dt * 0.028 * (0.6 + 0.4 * airflow) * (C.LAG_REF / lagConst);
      if (c.temp > c.peak) c.peak = c.temp;

      /* ── atmosphere, also lagged. Closing the damper starves the whole kiln of oxygen. */
      var o2target = 0.12 + 0.88 * (1 - f.damper);
      c.o2 += (o2target - c.o2) * Math.min(1, dt / (p.lag * 0.5 + 0.4));

      /* ── ash. Only pine-grade ash in quantity, only while the fire is actually driving, and
       * decreasing as it climbs. This is a CONTINUOUS accumulation, not an event. */
      c.ash += got * wood.ash * p.ashFactor * 0.055 * dt * (c.temp > 900 ? 1 : 0.15);

      /* ⭐ REDUCTION ONLY COUNTS WHILE THE GLAZE IS MOLTEN. A cold reduction does nothing, which
       * is the fact that makes the damper a skill. */
      if (c.temp >= C.REACTIVE_T) {
        c.molten += dt;
        c.reduction += (1 - c.o2) * dt;
        /* ⛔⭐ THE FAMILY IS DECIDED BY THE ATMOSPHERE THE GLAZE *FINISHED* IN, NOT BY A FLAT
         * AVERAGE OVER THE WHOLE MOLTEN TIME - and that is a design fix a measurement forced.
         * With a flat average the probe measured redFrac 0.49 for a firing that oxidised up and
         * then reduced hard for the last 60%, against a hard `> 0.5` cut. So a player doing the
         * textbook thing landed a hair on the wrong side of a CLIFF and lost the entire surface
         * to a rounding margin - an all-or-nothing rule over a continuous input, which master
         * §2b names as the shape that makes a difficulty curve impossible.
         * An exponential memory (~35 s) is both kinder and MORE truthful: in a real kiln a late
         * re-oxidation genuinely does bleach a reduced glaze back, so "hold it to the end" is the
         * skill, and letting the damper drift open at the finish really should cost you the
         * celadon. The cliff became a decision. */
        c.atmosMem += ((1 - c.o2) - c.atmosMem) * Math.min(1, dt / C.ATMOS_TAU);
        /* carbon trapping is a NARROW window: hard reduction while the glaze is only just molten */
        if (c.temp < C.REACTIVE_T + 55 && c.o2 < 0.35) c.carbon += dt * (0.35 - c.o2) * 2.4;
      }

      if (c.temp > C.OVERFIRE_T) f.over = true;
    }

    if (starved && f.chambers[0].temp < C.VITRIFY_T) {
      f.starved = true;
    }

    /* a compact trace for the UI's temperature graph and for the harness to assert on */
    if (f.history.length === 0 || f.t - f.history[f.history.length - 1].t >= 1) {
      f.history.push({
        t: f.t, temps: f.chambers.map(function (c) { return Math.round(c.temp); }),
        o2: Math.round(f.chambers[0].o2 * 100) / 100
      });
      if (f.history.length > 400) f.history.shift();
    }

    /* The firing ends when the potter draws the fire, or when there is no wood anywhere. */
    var anyWood = Object.keys(state.wood).some(function (w) { return state.wood[w] > 0.5; });
    if (!anyWood && f.chambers[0].temp < C.VITRIFY_T * 0.8) {
      f.ended = true;
      f.reason = 'the wood ran out';
    }
  }

  /* ── 4. UNLOADING — where the history becomes a surface ─────────────────────────────────── */
  /**
   * Draw the fire and open the kiln. Every packed piece is resolved from the ACTUAL history its
   * own chamber lived through, so two identical bowls a chamber apart are different objects.
   */
  function unload(state) {
    var f = state.firing;
    if (!f) return { ok: false, why: 'not lit' };
    var results = [];
    for (var k = 0; k < state.packed.length; k++) {
      var slotRec = state.packed[k];
      var c = f.chambers[Math.min(slotRec.chamber, f.chambers.length - 1)];
      var p = slotRec.piece;
      /* position within the chamber: the front faces the flame */
      var front = 1 - (slotRec.slot / (C.SLOTS_PER_CHAMBER - 1));
      var rnd = GLZ.mulberry32(p.seed ^ (f.t * 1000 | 0));

      if (f.over && c.peak > C.OVERFIRE_T) {
        results.push({ piece: p, outcome: 'slumped', why: 'over-fired at ' + Math.round(c.peak) + '°' });
        state.stats.lost++;
        continue;
      }
      if (c.peak < C.VITRIFY_T) {
        results.push({ piece: p, outcome: 'raw', why: 'never reached ' + C.VITRIFY_T + '°' });
        state.stats.lost++;
        continue;
      }

      /* ── ash actually STUCK to this piece: chamber ash x how much flame it faced x a little luck.
       * ⛔⛔ THIS WAS `clamp01(raw / 9)` AND THE HARD CLAMP DESTROYED THE GAME'S OWN PREMISE.
       * In a decent firing chamber 0 accumulates well past 9, so EVERY slot in it clamped to
       * exactly 1.000 - the front-to-back variation that makes "two identical bowls packed a metre
       * apart come out different" simply did not exist, and a shelf of six pots from one chamber
       * came out six times the same. It is the saturation failure master §2b names ("a
       * connectivity test run at a floor cannot detect connection"), except here it was in the
       * PRODUCT rather than in a probe, and it was invisible until six pots were rendered side by
       * side and LOOKED AT.
       * A soft saturation preserves the ORDERING at every input level: it approaches 1 and never
       * reaches it, so a front pot is always ashier than a back pot however long you fire. */
      /* ⛔⛔ `evenness` WAS DEAD CODE. `chamberProfile` has always returned it with the comment
       * "the top chambers are predictable", and the header of that function sells the whole
       * packing decision as "the firebox chamber is a lottery and the top chamber is a safe pair
       * of hands" - but NOTHING in the shipped game ever read the field. Every chamber drew from
       * the same flat +/-20% band, so the lottery and the safe hands were the same gamble and the
       * design claim was a comment rather than a mechanic. Found by grepping for the field's
       * consumers while fixing the heat ladder: the only readers were two probes.
       * ⚠️ It mattered little while chambers above index 1 could never fire at all; with the
       * ladder fixed, the upper chambers are somewhere a player will actually pack, so the axis
       * that makes them WORTH packing has to exist. Half-width is 0.45 at the firebox end and
       * 0.04 at the top, so a top-chamber pot comes out close to what you aimed at and a firebox
       * pot is the gamble that occasionally produces the best thing on the shelf. */
      /* ⚠️ `p` is the PIECE here, not the profile - the profile hangs off the chamber as `c.prof`.
       * Reading `p.evenness` returns undefined and quietly poisons every spread to NaN. */
      var spread = 0.45 * (1 - c.prof.evenness);
      var rawAsh = c.ash * (0.30 + 0.70 * front) * (1 - spread + rnd() * 2 * spread) / 5.5;
      var ash = 1 - Math.exp(-rawAsh);
      /* the glaze only ran if it got hot enough to run */
      if (c.peak < C.RUN_T) ash *= 0.45;
      /* atmosphere, averaged over the MOLTEN time only */
      /* the atmosphere it FINISHED in (exponential memory), not a flat average - see step() */
      var redFrac = c.molten > 0 ? clamp01(c.atmosMem) : 0;
      var atmos = redFrac > 0.5 ? 'red' : 'ox';
      var carbon = clamp01(c.carbon / 12) * (p.applied === 'shino' ? 1.35 : 0.55);
      var salt = clamp01(c.salt * (0.5 + 0.5 * front));
      var flash = clamp01((0.35 + 0.65 * front) * (c.peak - C.VITRIFY_T) / 190);

      var spec = {
        form: p.form, applied: p.applied, atmos: atmos,
        ash: ash, salt: salt, carbon: carbon, flash: flash,
        flame: slotRec.slot % 2 === 0 ? -1 : 1,
        seed: p.seed
      };
      spec.family = GLZ.familyFor(spec);
      spec.peak = Math.round(c.peak);
      spec.chamber = slotRec.chamber;
      spec.quality = quality(spec, c);
      spec.id = p.id;
      spec.day = state.day;

      if (!state.codex[spec.family]) {
        state.codex[spec.family] = true;
        note(state, 'A surface you have never seen before: ' + GLZ.FAMILY_LABEL[spec.family] + '.');
      }
      results.push({ piece: p, outcome: 'fired', spec: spec });
      state.shelf.push(spec);
      state.stats.fired++;
    }

    state.packed = [];
    state.firing = null;
    state.day++;
    refreshCollectors(state);
    return { ok: true, results: results };
  }

  /** Draw the fire early. Legal, and often correct - the risk is an under-fired load. */
  function drawFire(state) {
    if (!state.firing) return { ok: false, why: 'not lit' };
    state.firing.ended = true;
    state.firing.reason = 'you drew the fire';
    return { ok: true };
  }

  function clamp01(v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }

  /**
   * A piece's quality in [0,1]. Deliberately NOT "bigger numbers are better": a surface is good
   * when it is DEFINITE - a heavily ashed pot and a clean quiet one are both good, and the
   * mediocre middle is what a careless firing produces.
   */
  function quality(spec, c) {
    var definite = Math.max(spec.ash, 1 - spec.ash * 1.4, spec.carbon, spec.salt);
    var heat = clamp01((c.peak - C.VITRIFY_T) / (C.RUN_T - C.VITRIFY_T));
    var melted = clamp01(c.molten / 25);
    return clamp01(0.20 + 0.42 * definite + 0.22 * heat + 0.16 * melted);
  }

  /* ── DEMAND ─────────────────────────────────────────────────────────────────────────────── */
  var WANT_TEXT = {
    cel: 'a green ash celadon', amb: 'an amber ash surface', iro: 'a black tenmoku',
    shi: 'a milky shino', sal: 'a salt-vapour surface'
  };

  /**
   * ⛔ WANTS ARE DEDUPED. Without it, three collectors drawn from 5 families x 3 starting forms
   * routinely asked for the SAME THING three times over - measured on the first real playthrough,
   * where every collector on screen wanted an amber ash tea bowl. Three identical asks is not a
   * market, it is one ask rendered three times, and it makes the whole demand system look broken
   * at exactly the moment a new player first reads it.
   */
  function refreshCollectors(state) {
    var rnd = GLZ.mulberry32(state.seed + state.day * 104729);
    var guard = 0;
    while (state.collectors.length < 3 && guard++ < 60) {
      var fams = Object.keys(WANT_TEXT);
      var fam = fams[(rnd() * fams.length) | 0];
      var forms = state.unlocked.forms;
      var form = forms[(rnd() * forms.length) | 0];
      var heavy = rnd() < 0.45;
      var dup = state.collectors.some(function (w) {
        return w.family === fam && w.form === form;
      });
      if (dup) continue;
      state.collectors.push({
        id: state.nextId++,
        family: fam, form: form, heavyAsh: heavy,
        pays: Math.round(18 + rnd() * 26 + (heavy ? 10 : 0)),
        patience: 3 + ((rnd() * 3) | 0)
      });
    }
    for (var i = state.collectors.length - 1; i >= 0; i--) {
      if (--state.collectors[i].patience <= 0) state.collectors.splice(i, 1);
    }
  }

  function wantText(w) {
    return WANT_TEXT[w.family] + ' ' + GLZ.FORMS[w.form].label + (w.heavyAsh ? ', heavily ashed' : '');
  }

  /**
   * A short descriptor of what the FIRE did to this piece.
   * ⛔ ADDED AFTER SIX SIBLING POTS WERE RENDERED SIDE BY SIDE AND EVERY LABEL READ THE SAME.
   * The pieces really did differ (ash 0.92 down to 0.52 front-to-back) but at 96px that reads as
   * a shade, and the label said "amber ash tea bowl" six times - so the game had just earned its
   * central variation and then hid it. The name is where a shelf becomes legible.
   */
  function descriptorFor(spec) {
    /* ⛔ THIS USED TO OPEN `if (spec.salt > 0.55) return 'vapour-worn';` — THE IDENTICAL PREDICATE
     * `familyFor()` USES TO RETURN 'sal' / "salt vapour". So the two were perfectly correlated and
     * EVERY salt piece was named "vapour-worn salt vapour <form>", always, with no other
     * combination reachable: a guaranteed word stutter, three of them visible in one store plate.
     * ⭐ The deeper fault is that a descriptor whose condition is the family's own condition
     * carries ZERO information — it is this function's whole purpose to say what varies WITHIN a
     * family, and on 'sal' it said only what the family name already said. Removing the branch
     * lets salt pieces fall through to ash / carbon / flash, which genuinely do vary across them,
     * so the shelf reads "heavily ashed salt vapour tokkuri" beside "quiet salt vapour tea bowl".
     * Found by the §4c independent review reading three labels off 02_the_shelf.png. */
    /* ⛔ THE ASH DESCRIPTORS USED TO READ 'ash-drowned' / 'heavily ashed' / 'ash-flecked', AND THE
     * COMMONEST FAMILY IN THE GAME IS CALLED "amber ash" — so the single most frequent label the
     * shelf can produce was "ash-drowned amber ash tea bowl". MEASURED by _probe_labels.js over
     * 420 pots fired by the real sim: 310 of them stuttered on the word "ash". The review found
     * this class on the salt family (3 labels in one plate); the gate written for it found the
     * dominant case, which is the argument for mechanising a defect rather than fixing the
     * instance. The degree words below name the SURFACE, not the material, so they can no longer
     * collide with a family name that already says what the material is. */
    if (spec.carbon > 0.45) return 'carbon-trapped';
    if (spec.ash > 0.80) return 'drowned';
    if (spec.ash > 0.60) return 'encrusted';
    if (spec.ash > 0.38) return 'flecked';
    if (spec.flash > 0.55) return 'flame-flashed';
    return 'quiet';
  }

  /** Base price with no collector: quality alone. Collectors are the premium, not the market. */
  function basePrice(spec) { return Math.round(4 + spec.quality * 22); }

  function matches(spec, want) {
    return spec.family === want.family && spec.form === want.form
      && (!want.heavyAsh || spec.ash > 0.55);
  }

  function sell(state, specId, collectorId) {
    var i = -1;
    for (var k = 0; k < state.shelf.length; k++) if (state.shelf[k].id === specId) i = k;
    if (i < 0) return { ok: false, why: 'not on the shelf' };
    var spec = state.shelf[i];
    var price = basePrice(spec);
    var ci = -1;
    if (collectorId != null) {
      for (var j = 0; j < state.collectors.length; j++) if (state.collectors[j].id === collectorId) ci = j;
      if (ci < 0) return { ok: false, why: 'no such collector' };
      if (!matches(spec, state.collectors[ci])) return { ok: false, why: 'not what they asked for' };
      price += Math.round(state.collectors[ci].pays * (0.55 + 0.75 * spec.quality));
      state.collectors.splice(ci, 1);
    }
    state.shelf.splice(i, 1);
    state.money += price;
    state.stats.sold++;
    state.stats.earned += price;
    return { ok: true, price: price };
  }

  /* ── SHOP / UNLOCKS ─────────────────────────────────────────────────────────────────────── */
  var SHOP = [
    { id: 'clay10', label: '10 clay', cost: 14, apply: function (s) { s.clay += 10; } },
    { id: 'pine60', label: '60 pine', cost: 16, apply: function (s) { s.wood.pine += 60; } },
    { id: 'oak40', label: '40 oak', cost: 20, apply: function (s) { s.wood.oak += 40; } },
    { id: 'salt3', label: '3 salt', cost: 22, apply: function (s) { s.salt += 3; } },
    { id: 'bamboo', label: 'learn bamboo firing', cost: 55, once: true, apply: function (s) { s.unlocked.woods.push('bamboo'); s.wood.bamboo += 40; } },
    { id: 'g_iron', label: 'iron slip recipe', cost: 48, once: true, apply: function (s) { s.unlocked.glazes.push('iron'); } },
    { id: 'g_shino', label: 'shino recipe', cost: 70, once: true, apply: function (s) { s.unlocked.glazes.push('shino'); } },
    { id: 'f_tokkuri', label: 'throw flasks', cost: 34, once: true, apply: function (s) { s.unlocked.forms.push('tokkuri'); } },
    { id: 'f_tsubo', label: 'throw jars', cost: 46, once: true, apply: function (s) { s.unlocked.forms.push('tsubo'); } },
    { id: 'f_sara', label: 'throw plates', cost: 40, once: true, apply: function (s) { s.unlocked.forms.push('sara'); } },
    { id: 'f_hanaire', label: 'throw vases', cost: 58, once: true, apply: function (s) { s.unlocked.forms.push('hanaire'); } },
    { id: 'f_mizusashi', label: 'throw water jars', cost: 62, once: true, apply: function (s) { s.unlocked.forms.push('mizusashi'); } },
    { id: 'f_henko', label: 'build slab bottles', cost: 76, once: true, apply: function (s) { s.unlocked.forms.push('henko'); } },
    { id: 'f_kame', label: 'throw urns', cost: 92, once: true, apply: function (s) { s.unlocked.forms.push('kame'); } },
    {
      id: 'chamber', label: 'extend the kiln by a chamber', cost: 120, repeat: true,
      /* ⭐ the retroactive upgrade: a longer kiln draws harder, so EVERY existing chamber gets
       * hotter and cleaner. The Gate 4 claim, in one line of code. */
      apply: function (s) { s.kiln.chambers++; }
    }
  ];

  function buy(state, id) {
    var item = null;
    for (var i = 0; i < SHOP.length; i++) if (SHOP[i].id === id) item = SHOP[i];
    if (!item) return { ok: false, why: 'no such item' };
    if (item.once && bought(state, id)) return { ok: false, why: 'already owned' };
    if (item.id === 'chamber' && state.kiln.chambers >= 6) return { ok: false, why: 'the hill ends' };
    if (state.money < item.cost) return { ok: false, why: 'not enough money' };
    state.money -= item.cost;
    item.apply(state);
    state.owned = state.owned || {};
    state.owned[id] = (state.owned[id] || 0) + 1;
    return { ok: true };
  }

  function bought(state, id) { return !!(state.owned && state.owned[id]); }

  /* ── SAVE / RESUME ──────────────────────────────────────────────────────────────────────── */
  var SAVE_KEY = 'anagama.save.v1';

  function serialize(state) { return JSON.stringify(state); }
  function deserialize(text) {
    var s = JSON.parse(text);
    if (!s || s.v !== 1) return null;
    /* a firing in progress survives a reload: the chambers carry their own accumulators, so the
     * only thing that needs rebuilding is the non-JSONable profile object */
    if (s.firing) {
      for (var i = 0; i < s.firing.chambers.length; i++) {
        s.firing.chambers[i].prof = chamberProfile(i, s.firing.chambers.length);
      }
    }
    return s;
  }

  return {
    C: C, WOODS: WOODS, GLAZES: GLAZES, SHOP: SHOP, CLAY_COST: CLAY_COST, SAVE_KEY: SAVE_KEY,
    newGame: newGame, chamberProfile: chamberProfile, draftOf: draftOf,
    canThrow: canThrow, throwPot: throwPot, applyGlaze: applyGlaze,
    pack: pack, unpack: unpack,
    light: light, step: step, setStoke: setStoke, setDamper: setDamper, setWood: setWood,
    throwSalt: throwSalt, drawFire: drawFire, unload: unload,
    quality: quality, basePrice: basePrice, matches: matches, sell: sell,
    descriptorFor: descriptorFor,
    refreshCollectors: refreshCollectors, wantText: wantText,
    buy: buy, bought: bought,
    serialize: serialize, deserialize: deserialize
  };
}));
