/**
 * paint.js — ANAGAMA's rendering. The browser half of the isomorphic art layer.
 *
 * ⛔ THE POTS ARE RENDERED BY glaze.js, NOT BY THIS FILE. All this does is provide a `setPx`
 * TARGET backed by ImageData, so the browser and the Node baker put the same pixels on screen.
 * Master §2b's longest family is two declarations of one fact, and a second pot renderer here
 * would make the Gate 1 contact sheet a picture of something the player never sees.
 *
 * ⛔ THE KILN SCENE IS BUILT FROM BAKED PLATES (§0-ART: a hand-coded canvas path is the FALLBACK,
 * never the plan). Only the GLOW is drawn at runtime, because the glow is the thing that has to
 * move with the simulation.
 */
(function (root, factory) {
  root.ANAGAMA_PAINT = factory(root.ANAGAMA_PAL, root.ANAGAMA_GLAZE, root.ANAGAMA_SIM);
}(typeof self !== 'undefined' ? self : this, function (PAL, GLZ, SIM) {
  'use strict';

  /* palette key -> [r,g,b,a], built once. The keys carry the an_ prefix at the call site. */
  var RGBA = {};
  (function () {
    for (var k in PAL.PALETTE) {
      if (Object.prototype.hasOwnProperty.call(PAL.PALETTE, k)) {
        RGBA[PAL.PREFIX + k] = PAL.rgba(PAL.PALETTE[k]);
      }
    }
  }());

  /**
   * A setPx target over an ImageData buffer.
   * ⛔ It THROWS on an unknown key, deliberately, mirroring pixel_forge's palette lock. Without
   * that, a key that exists in Node and not in the browser would render as a silent hole and the
   * two halves of the "one declaration" claim could drift apart without anything going red.
   */
  function ImgTarget(img, w) {
    this.d = img.data; this.w = w; this.h = img.height;
  }
  ImgTarget.prototype.setPx = function (x, y, key) {
    x |= 0; y |= 0;
    if (x < 0 || y < 0 || x >= this.w || y >= this.h) return;
    var c = RGBA[key];
    if (!c) throw new Error('PALETTE LOCK: "' + key + '" is not a declared ANAGAMA colour');
    var i = (y * this.w + x) * 4;
    this.d[i] = c[0]; this.d[i + 1] = c[1]; this.d[i + 2] = c[2]; this.d[i + 3] = c[3];
  };

  var potCache = {};

  /** Render a fired piece to its own canvas element, cached by spec identity + size. */
  function potCanvas(spec, size) {
    var key = spec.id + ':' + size + ':' + spec.family + ':' + spec.form;
    if (potCache[key]) return potCache[key];
    var cv = document.createElement('canvas');
    cv.width = size; cv.height = size;
    var ctx = cv.getContext('2d');
    var img = ctx.createImageData(size, size);
    GLZ.renderVessel(new ImgTarget(img, size), spec, size, { shadow: false });
    ctx.putImageData(img, 0, 0);
    potCache[key] = cv;
    return cv;
  }

  /** Unfired greenware: the same form, in raw clay, so the player can see WHAT they threw. */
  function greenCanvas(piece, size) {
    var key = 'g' + piece.id + ':' + size + ':' + piece.applied;
    if (potCache[key]) return potCache[key];
    var cv = document.createElement('canvas');
    cv.width = size; cv.height = size;
    var ctx = cv.getContext('2d');
    var img = ctx.createImageData(size, size);
    /* raw clay: no ash, no atmosphere, no heat. The generator handles it as a bare, unfired
     * surface - which is exactly what greenware looks like. */
    GLZ.renderVessel(new ImgTarget(img, size), {
      form: piece.form, applied: piece.applied, atmos: 'ox',
      ash: 0, salt: 0, carbon: 0, flash: 0, flame: -1, seed: piece.seed
    }, size, { shadow: false });
    ctx.putImageData(img, 0, 0);
    potCache[key] = cv;
    return cv;
  }

  /* ── the plates ─────────────────────────────────────────────────────────────────────────── */
  var plates = {}, patterns = {}, platesReady = false;

  function loadPlates(names, done) {
    var left = names.length;
    names.forEach(function (n) {
      var im = new Image();
      im.onload = function () { plates[n] = im; if (--left === 0) { platesReady = true; done(); } };
      im.onerror = function () { if (--left === 0) { platesReady = true; done(); } };
      im.src = 'art/plate_' + n + '.png';
    });
  }

  function pat(ctx, name) {
    if (!plates[name]) return null;
    if (!patterns[name]) patterns[name] = ctx.createPattern(plates[name], 'repeat');
    return patterns[name];
  }

  /**
   * Glow colour for a temperature. This is the player's PRIMARY instrument - they read the kiln
   * by its colour before they read any number - so the stops are the ones a potter actually uses.
   */
  /**
   * ⛔ ALPHAS CUT HARD AFTER THE FIRST CAPTURE. The glow was painted at 0.74-0.97 alpha over the
   * brick, which meant the firebrick plate underneath was INVISIBLE - every chamber rendered as a
   * flat coloured slab and the whole §0-ART "real asset files are the primary visual layer"
   * argument was thrown away at the last step. It also made white heat read as a blank cream
   * doorway rather than as something frightening. The glow now sits UNDER 0.55 and is composited
   * with `lighter`, so the brick reads through it at every temperature.
   */
  function heatColour(t) {
    if (t < 420) return 'rgba(0,0,0,0)';
    if (t < 700) return 'rgba(150,32,10,' + ((t - 420) / 280 * 0.30).toFixed(3) + ')';
    if (t < 900) return 'rgba(186,52,14,0.34)';
    if (t < SIM.C.VITRIFY_T) return 'rgba(214,84,18,0.40)';
    if (t < SIM.C.REACTIVE_T) return 'rgba(236,120,26,0.45)';
    if (t < SIM.C.RUN_T) return 'rgba(248,158,44,0.50)';
    if (t < SIM.C.OVERFIRE_T) return 'rgba(255,192,80,0.54)';
    return 'rgba(255,226,150,0.60)';                       /* white heat: you are losing the load */
  }

  /**
   * Where each chamber sits, in canvas space. Shared by the renderer AND the click hit-test, so
   * the two can never disagree about where a chamber is.
   * ⛔ CHAMBERS ARE NOW ADJACENT AND STEPPED, sharing edges. The first version spread them across
   * the canvas with gaps and a smooth y-slope, and at the starting TWO chambers it read as two
   * disconnected boxes on a hill rather than as one kiln - which is the whole subject. A climbing
   * kiln is a stepped tunnel, so it is drawn as one: each chamber begins where the last ended and
   * sits one step higher, with a brick divider and a flame port between them.
   */
  function kilnLayout(n, W, H) {
    var out = [];
    var x0 = W * 0.175, x1 = W * 0.885;
    var span = (x1 - x0) / n;
    var rise = Math.min(H * 0.085, (H * 0.34) / Math.max(1, n - 1));
    var baseY = H * 0.70;
    for (var i = 0; i < n; i++) {
      out.push({
        i: i,
        x: x0 + span * i,
        w: span,
        y: baseY - rise * i - H * 0.20,
        h: H * 0.20
      });
    }
    return out;
  }

  /**
   * Draw the kiln in cross-section: a tunnel climbing a hillside, glowing from the firebox up.
   * ⭐ THE WHOLE SIMULATION IS LEGIBLE IN THIS PICTURE - heat really does climb the slope with a
   * lag, so the player watches their decision travel.
   */
  function drawKiln(ctx, state, W, H) {
    var f = state.firing;
    var n = state.kiln.chambers;
    ctx.clearRect(0, 0, W, H);

    /* night sky, graded rather than flat black - a flat field reads as a missing asset */
    var sky = ctx.createLinearGradient(0, 0, 0, H);
    sky.addColorStop(0, '#0a0b0f');
    sky.addColorStop(0.62, '#14110e');
    sky.addColorStop(1, '#1b1510');
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, W, H);

    /* the hillside: earth plate under a sloping ground line, cut so the kiln sits INSIDE it */
    var ground = pat(ctx, 'earth');
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(0, H);
    ctx.lineTo(0, H * 0.88);
    ctx.lineTo(W * 0.14, H * 0.82);
    ctx.lineTo(W * 0.55, H * 0.46);
    ctx.lineTo(W, H * 0.13);
    ctx.lineTo(W, H);
    ctx.closePath();
    ctx.fillStyle = ground || '#2f2921';
    ctx.fill();
    /* a rim of light along the cut, so the hill has an edge instead of ending */
    ctx.strokeStyle = 'rgba(160,140,110,0.20)';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.restore();

    /* The ash bed raked out below the firebox.
     * ⛔ IT WAS A BRIGHT GREY ELLIPSE AND IT READ AS A CONCRETE SLAB DROPPED ON THE HILL - the
     * plate is pale by design (it is wood ash) and nothing was knocking it back into the night.
     * Now: a low irregular drift, darkened hard, with the firebox light falling across the near
     * edge, so it belongs to the scene instead of sitting on top of it. */
    var ash = pat(ctx, 'ash');
    ctx.save();
    ctx.beginPath();
    var ax = W * 0.075, ay = H * 0.885, aw = W * 0.115, ah = H * 0.042;
    ctx.moveTo(ax - aw, ay + ah);
    ctx.quadraticCurveTo(ax - aw * 0.7, ay - ah * 0.9, ax - aw * 0.1, ay - ah * 0.5);
    ctx.quadraticCurveTo(ax + aw * 0.55, ay - ah * 1.1, ax + aw, ay + ah * 0.2);
    ctx.lineTo(ax + aw * 1.05, ay + ah);
    ctx.closePath();
    ctx.fillStyle = ash || '#65635d';
    ctx.fill();
    ctx.fillStyle = 'rgba(10,9,8,0.62)';
    ctx.fill();
    /* firelight catching the near lip of the drift */
    if (f && f.chambers[0].temp > 500) {
      ctx.globalCompositeOperation = 'lighter';
      var ag = ctx.createRadialGradient(ax + aw * 0.6, ay - ah, 1, ax + aw * 0.6, ay - ah, aw * 1.5);
      ag.addColorStop(0, 'rgba(216,110,32,0.30)');
      ag.addColorStop(1, 'rgba(120,40,10,0)');
      ctx.fillStyle = ag;
      ctx.fill();
    }
    ctx.restore();

    var brick = pat(ctx, 'firebrick');
    var lay = kilnLayout(n, W, H);

    /* ── the firebox: butted against chamber 1, not floating beside it ──────────────────────── */
    var fbT = f ? Math.min(f.chambers[0].temp * 1.05, SIM.C.OVERFIRE_T + 30) : SIM.C.AMBIENT_T;
    var first = lay[0];
    var fw = W * 0.115, fh = H * 0.175;
    var fx = first.x - fw, fy = first.y + first.h - fh;
    drawVault(ctx, fx, fy, fw, fh, brick, fbT, '#0b0808');

    /* the firebox mouth: the one place you see the fire ITSELF rather than its light */
    if (fbT > 500) {
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      var mg = ctx.createRadialGradient(fx + fw * 0.5, fy + fh * 0.72, 2,
        fx + fw * 0.5, fy + fh * 0.72, fw * 0.62);
      var a = Math.min(0.85, (fbT - 500) / 900);
      mg.addColorStop(0, 'rgba(255,228,168,' + (a * 0.95).toFixed(3) + ')');
      mg.addColorStop(0.45, 'rgba(240,132,32,' + (a * 0.55).toFixed(3) + ')');
      mg.addColorStop(1, 'rgba(160,40,10,0)');
      ctx.fillStyle = mg;
      ctx.fillRect(fx - fw * 0.4, fy - fh * 0.3, fw * 1.8, fh * 1.6);
      ctx.restore();
    }

    /* ── the chambers: one stepped tunnel, sharing edges ────────────────────────────────────── */
    for (var i = 0; i < n; i++) {
      var L = lay[i];
      var temp = f ? f.chambers[i].temp : SIM.C.AMBIENT_T;
      drawVault(ctx, L.x, L.y, L.w, L.h, brick, temp, '#0b0808');

      /* the pots, as silhouettes against the glow. Small, but they are WHY you are looking. */
      ctx.save();
      ctx.beginPath();
      vaultPath(ctx, L.x + 4, L.y + 4, L.w - 8, L.h - 6);
      ctx.clip();
      var here = state.packed.filter(function (p) { return p.chamber === i; });
      var slotW = (L.w - 14) / SIM.C.SLOTS_PER_CHAMBER;
      for (var k = 0; k < here.length; k++) {
        var s = here[k].slot;
        var px = L.x + 7 + slotW * s + slotW * 0.5;
        var py = L.y + L.h - 6;
        var ph = Math.min(L.h * 0.66, slotW * 1.7);
        ctx.fillStyle = temp > 900 ? 'rgba(26,10,5,0.86)' : 'rgba(158,148,134,0.80)';
        potSilhouette(ctx, here[k].piece.form, px, py, ph);
      }
      ctx.restore();

      /* the divider between chambers, with the flame port the fire climbs through */
      if (i > 0) {
        ctx.fillStyle = '#1a1512';
        ctx.fillRect(L.x - 3, L.y, 6, L.h);
        ctx.fillStyle = heatColour(temp);
        ctx.fillRect(L.x - 3, L.y + L.h * 0.62, 6, L.h * 0.34);
      }

      /* chamber number, so the packing screen and this screen speak the same language */
      ctx.fillStyle = 'rgba(214,204,186,0.72)';
      ctx.font = '600 11px ui-monospace, Menlo, Consolas, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(String(i + 1), L.x + L.w / 2, L.y - 7);
    }

    /* ── the chimney and its damper, kept fully inside the canvas ───────────────────────────── */
    var last = lay[n - 1];
    var cw = W * 0.042, cx = Math.min(W - cw - 4, last.x + last.w + W * 0.005);
    var ch = H * 0.30, cy = Math.max(4, last.y - ch + H * 0.03);
    ctx.fillStyle = brick || '#4d3931';
    ctx.fillRect(cx, cy, cw, ch);
    ctx.strokeStyle = 'rgba(0,0,0,0.6)'; ctx.lineWidth = 2;
    ctx.strokeRect(cx, cy, cw, ch);
    /* the damper plate slides across the flue - drawn where it actually is */
    var d = f ? f.damper : 0.2;
    ctx.fillStyle = '#0f0d0c';
    ctx.fillRect(cx - 3, cy + ch * 0.34, (cw + 6) * (0.12 + 0.88 * d), 7);
    ctx.strokeStyle = 'rgba(190,170,140,0.35)';
    ctx.lineWidth = 1;
    ctx.strokeRect(cx - 3, cy + ch * 0.34, (cw + 6) * (0.12 + 0.88 * d), 7);

    /* smoke, thicker in reduction, because reduction is literally incomplete combustion */
    if (f && f.chambers[0].temp > 400) {
      var smoke = 0.10 + 0.55 * d;
      for (var s2 = 0; s2 < 7; s2++) {
        var t2 = (Date.now() / 900 + s2 * 0.63) % 1;
        ctx.fillStyle = 'rgba(150,148,142,' + (smoke * (1 - t2) * 0.5).toFixed(3) + ')';
        ctx.beginPath();
        ctx.arc(cx + cw / 2 + Math.sin(t2 * 5 + s2) * 12, cy - t2 * H * 0.16, 5 + t2 * 13, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }

  function vaultPath(ctx, x, y, w, h) {
    var r = Math.min(w / 2, h * 0.55);
    ctx.moveTo(x, y + h);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h);
    ctx.closePath();
  }

  /**
   * One vault: brick surround, brick INTERIOR, then the glow composited on top with `lighter`.
   * ⛔ THE ORDER AND THE COMPOSITE ARE THE WHOLE POINT. The first version filled the interior with
   * near-black and then painted an opaque glow over it, which produced a flat coloured slab and
   * hid the firebrick plate completely - i.e. it spent a baked asset and then covered it up.
   * Drawing the plate and ADDING light to it is what makes a hot chamber look like hot brick.
   */
  function drawVault(ctx, x, y, w, h, brickPat, temp, dark) {
    ctx.save();
    ctx.beginPath();
    vaultPath(ctx, x - 6, y - 6, w + 12, h + 9);
    ctx.fillStyle = brickPat || '#4d3931';
    ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,0.66)';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.restore();

    ctx.save();
    ctx.beginPath();
    vaultPath(ctx, x + 4, y + 4, w - 8, h - 6);
    ctx.clip();
    /* the interior is brick too, darkened - you are looking INTO a brick tunnel */
    ctx.fillStyle = brickPat || '#3a2b23';
    ctx.fillRect(x, y, w, h);
    ctx.fillStyle = 'rgba(6,5,5,0.72)';
    ctx.fillRect(x, y, w, h);
    /* the glow: brightest at the firebox end (left) and falling away up the tunnel */
    var g = ctx.createLinearGradient(x, 0, x + w, 0);
    g.addColorStop(0, heatColour(temp));
    g.addColorStop(1, heatColour(temp * 0.94));
    ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = g;
    ctx.fillRect(x, y, w, h);
    ctx.restore();
  }

  function roundedVault(ctx, x, y, w, h, fill) {
    ctx.save();
    ctx.beginPath();
    vaultPath(ctx, x - 5, y - 5, w + 10, h + 8);
    ctx.fillStyle = fill;
    ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,0.6)';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.restore();
  }

  /** A tiny pot silhouette from the SAME profile the generator uses, so the shape in the kiln is
   *  the shape that comes out of it. */
  function potSilhouette(ctx, formId, cx, baseY, h) {
    var form = GLZ.FORMS[formId];
    if (!form) return;
    var w = h / form.ratio;
    ctx.beginPath();
    var steps = 14;
    for (var i = 0; i <= steps; i++) {
      var t = i / steps;
      var hw = GLZ.profileAt(form, t) * (w / 2);
      var y = baseY - t * h;
      if (i === 0) ctx.moveTo(cx - hw, y); else ctx.lineTo(cx - hw, y);
    }
    for (var j = steps; j >= 0; j--) {
      var t2 = j / steps;
      var hw2 = GLZ.profileAt(form, t2) * (w / 2);
      ctx.lineTo(cx + hw2, baseY - t2 * h);
    }
    ctx.closePath();
    ctx.fill();
  }

  return {
    ImgTarget: ImgTarget, potCanvas: potCanvas, greenCanvas: greenCanvas,
    loadPlates: loadPlates, drawKiln: drawKiln, kilnLayout: kilnLayout,
    heatColour: heatColour, potSilhouette: potSilhouette,
    platesReady: function () { return platesReady; }
  };
}));
