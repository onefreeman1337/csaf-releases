/**
 * glaze.js — ANAGAMA's vessel generator. THIS FILE IS THE PRODUCT.
 *
 * Master §1.1's three questions, answered here or nowhere:
 *   1. will the player see something beautiful?      a shelf of wood-fired pots
 *   2. does the PRODUCT generate it?                 yes - there is no pot PNG anywhere
 *   3. is there VOLUME (40+ distinct entities)?      10 forms x 5 surface families x 2 atmospheres
 *                                                    x a continuous ash/salt/carbon/flame state
 *                                                    x a per-piece seed. Proven, not asserted, by
 *                                                    Internal_Ops/bake_sheet.js.
 *
 * ⛔ ISOMORPHIC ON PURPOSE. Node bakes the store plates and the Gate 1 contact sheet through
 * pixel_forge; the browser generates a new pot every firing. Both call THIS function. Master §2b
 * has eight incidents in the "two declarations of one fact" family, and a baker that drew pots
 * slightly differently from the game would make the Gate 1 review a picture of something the
 * player never sees, with nothing going red.
 *
 * ⛔ THE TARGET IS AN INTERFACE, NOT A CANVAS: `target.setPx(x, y, paletteKey)`. In Node that is
 * a pixel_forge Canvas, whose PALETTE LOCK then proves this file cannot invent a colour. In the
 * browser it is a tiny ImageData shim. The lock is the reason the Node path is worth keeping.
 *
 * ── §0-ART COMPLIANCE, STATED BEFORE THE CODE SO IT CAN BE CHECKED AGAINST IT ────────────────
 * The wing has paid for these rules five times and every one of them applies to a curved,
 * shaded object as much as to a ground tile:
 *
 *  rule 1 (broad tone is CONTINUOUS, mix never cut) - the revolve shading, the ash weight and
 *      the carbon field are all continuous fields MIXED into the surface value. Nothing here
 *      thresholds a smooth field, which is what makes camouflage blobs.
 *  rule 2/4 (structure is an explicit lattice or a 1px line) - the structure on a pot is not a
 *      lattice, it is the DRIPS, the rim line, the foot line, the wadding scars and the crazing.
 *      Every one is authored geometry drawn explicitly, not noise cut with a threshold.
 *  rule 5 (only threshold a field whose features are 1-2px) - the ONLY thresholded field in this
 *      file is `grit` (iron specks) and the salt orange-peel, both at 1-2px by construction.
 *  rule 7 (when a tonal floor fails, add STRUCTURE, never widen the bed) - if a surface reads
 *      flat, the legal fixes are more drips, more crazing, more speckle. Widening the shading
 *      range is how you get band borders back.
 *
 * ── WHY A DRIP IS THE WHOLE PRODUCT ──────────────────────────────────────────────────────────
 * Ash melts on the flame-facing shoulder and RUNS. Where it stops it beads. That single behaviour
 * is what makes a wood-fired pot look wood-fired rather than dipped, and it is the one thing a
 * gradient cannot fake. Drips here are angular (stored as an angle around the pot, not as a
 * screen offset) so they foreshorten correctly toward the silhouette - a drip near the edge of
 * the pot is thin because you are seeing it side-on, which is what sells the round form.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(require('./palette.js'));
  } else {
    root.ANAGAMA_GLAZE = factory(root.ANAGAMA_PAL);
  }
}(typeof self !== 'undefined' ? self : this, function (PAL) {
  'use strict';

  var RAMPS = PAL.RAMPS;

  /* ── deterministic noise ────────────────────────────────────────────────────────────────────
   * A seeded PRNG, not Math.random: a pot must re-render identically from its saved seed, or a
   * reload silently replaces the player's shelf with different pots. */
  function mulberry32(a) {
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /** 2D value hash in [0,1). Used only for 1-2px grain (§0-ART rule 5). */
  function hash2(x, y, s) {
    var h = Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263) ^ Math.imul(s | 0, 2246822519);
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  }

  /** Smooth 2D value noise, ~`cell` px features. CONTINUOUS - for mixing, never for cutting. */
  function vnoise(x, y, cell, s) {
    var fx = x / cell, fy = y / cell;
    var ix = Math.floor(fx), iy = Math.floor(fy);
    var tx = fx - ix, ty = fy - iy;
    var sx = tx * tx * (3 - 2 * tx), sy = ty * ty * (3 - 2 * ty);
    var a = hash2(ix, iy, s), b = hash2(ix + 1, iy, s);
    var c = hash2(ix, iy + 1, s), d = hash2(ix + 1, iy + 1, s);
    return (a * (1 - sx) + b * sx) * (1 - sy) + (c * (1 - sx) + d * sx) * sy;
  }

  var BAYER = [
    [0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]
  ];

  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
  function smoothstep(a, b, v) { var t = clamp((v - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); }

  /**
   * Pick a key from a ramp for a value in [0,1], ordered-dithered.
   * ⚠️ §0-ART rule 6: the dither amount IS a soft threshold. It stays at 1 here because the field
   * being quantised is the revolve shading - a genuinely smooth gradient, which is the one thing
   * ordered dithering exists for, and because bake 3 MEASURED what lowering it does (hard
   * horizontal bands). The step size was reduced instead, by subdividing the ramps.
   *
   * ⛔ THE `jitter` TERM IS NOT DECORATION - WITHOUT IT A LARGE VESSEL IS A HALFTONE PRINT.
   * MEASURED on the 240px hero at bake 5: on a big pot the tonal gradient per pixel is tiny, so
   * huge regions sit at the SAME fractional position between two ramp steps and the 4x4 Bayer
   * stops being a blend and becomes a visible dot GRID. (The 96px sheet hid it, which is §3g's
   * "judge at the size the player sees" arriving from the other direction - this game shows a pot
   * at 240px on the inspect view, so 240px is a size that must be judged.)
   * ⛔ AND THE FIRST FIX - A SMALL HASH JITTER ALONGSIDE THE BAYER - DID NOT WORK, WHICH IS THE
   * part worth keeping. Bake 6 looked unchanged, so the patch was MEASURED instead of eyeballed
   * (Internal_Ops/bake_sheet.js `periodicity`): in a 40x40 patch the same-key fraction at lag 2
   * was 0.455 against 0.369 at lag 1 - a PERIOD-2 signal, i.e. a checkerboard. That is the Bayer
   * matrix itself: its rows run low-high-low-high (0,8,2,10), so a 4x4 ordered dither's dominant
   * frequency is 2px, not 4px. A +-0.31-step jitter cannot hide a +-0.5-step ordered pattern.
   * ⇒ the blend is now NOISE-LED and the ordered term is a minority partner. With ramps this fine
   * the grain is sub-visible, and there is no lattice left to see.
   * ⭐ The general lesson, and it is the one this wing keeps re-learning in new clothes: when a
   * fix "looks the same", measure the defect rather than trying a second fix.
   */
  function rampPick(ramp, v, x, y, dither, seed) {
    var d = dither === undefined ? 1 : dither;
    var jitter = (hash2(x, y, (seed || 0) + 777) - 0.5) * 1.05 * d;
    var ord = ((BAYER[y & 3][x & 3] + 0.5) / 16 - 0.5) * 0.34 * d;
    var i = Math.round(clamp(v, 0, 1) * (ramp.length - 1) + jitter + ord);
    return ramp[clamp(i, 0, ramp.length - 1)];
  }

  /**
   * Blend BETWEEN two ramps by ordered dither.
   * ⛔ THIS EXISTS BECAUSE THE FIRST BAKE PUT A BLACK HOLE IN EVERY SHINO POT. Carbon trap was
   * written as `if (carbon > 0.5) use the carbon ramp`, i.e. a HARD THRESHOLD OF A SMOOTH FIELD -
   * the exact camouflage failure §0-ART rule 5 names, and the file header claimed the opposite was
   * happening. A dithered blend has no border to harden, so a continuous field stays continuous
   * all the way into the pixels, which is what rule 1 actually asks for.
   */
  /* ⛔ AND THE SELECTION NEEDED THE SAME TREATMENT, WHICH THE LATTICE GATE DID NOT CATCH.
   * After rampPick went noise-led the 240px hero STILL showed a dot grid, and the gate passed
   * (lag1 0.483 > lag2 0.455 > lag3 0.368, a clean decay). The residue was here: this function
   * chose BETWEEN two ramps on the raw 4x4 Bayer, so at a carbon mix of 0.235 exactly 23.5% of
   * pixels flipped to the carbonised ramp IN A FIXED ORDER - a period-4 dot lattice made of the
   * ramp CHOICE rather than of the tone inside it. Same cure: noise-led with a minority ordered
   * term, so the choice is grain rather than a grid.
   * ⚠️ WORTH RECORDING ABOUT THE GATE, NOT JUST THE BUG: `periodicity` is NECESSARY AND NOT
   * SUFFICIENT. It watches key-identity collisions, and this defect lived in the correlation
   * between two nearly-equal ramps, which barely moves that statistic. The eye caught it; the
   * instrument did not. Keep opening the file.
   */
  function rampMix(rampA, rampB, mix, v, x, y, dither, seed) {
    var d = hash2(x, y, (seed || 0) + 1319) * 0.76
      + ((BAYER[y & 3][x & 3] + 0.5) / 16) * 0.24;
    return rampPick(mix > d ? rampB : rampA, v, x, y, dither, seed);
  }

  /* ── the forms ──────────────────────────────────────────────────────────────────────────────
   * A pot is a solid of revolution, so a form is just its PROFILE: half-width as a fraction of
   * the widest point, from foot (t=0) to rim (t=1). `ratio` is height/width, which is what makes
   * a plate a plate and a vase a vase.
   *
   * These are real Japanese vessel types because the game is about a real kiln, and because a
   * named family of shapes gives the collectors something to actually ask for.
   */
  var FORMS = {
    chawan: {
      label: 'tea bowl', ratio: 0.66, footT: 0.10, rimT: 0.030,
      pts: [[0, 0.30], [0.07, 0.33], [0.12, 0.44], [0.30, 0.68], [0.58, 0.89], [0.86, 1.00], [1, 0.97]]
    },
    yunomi: {
      label: 'tall cup', ratio: 1.30, footT: 0.07, rimT: 0.022,
      pts: [[0, 0.60], [0.06, 0.64], [0.35, 0.75], [0.70, 0.83], [0.95, 0.88], [1, 0.88]]
    },
    guinomi: {
      label: 'sake cup', ratio: 0.92, footT: 0.13, rimT: 0.035,
      pts: [[0, 0.42], [0.09, 0.47], [0.16, 0.60], [0.45, 0.78], [0.80, 0.90], [1, 0.93]]
    },
    tokkuri: {
      label: 'sake flask', ratio: 1.55, footT: 0.06, rimT: 0.020,
      pts: [[0, 0.44], [0.05, 0.50], [0.16, 0.78], [0.30, 0.96], [0.44, 1.00], [0.56, 0.90],
        [0.68, 0.60], [0.80, 0.34], [0.90, 0.29], [0.96, 0.30], [1, 0.40]]
    },
    tsubo: {
      label: 'jar', ratio: 1.12, footT: 0.06, rimT: 0.024,
      pts: [[0, 0.40], [0.05, 0.46], [0.22, 0.79], [0.40, 0.96], [0.55, 1.00], [0.72, 0.90],
        [0.86, 0.68], [0.95, 0.53], [1, 0.58]]
    },
    hanaire: {
      label: 'flower vase', ratio: 2.05, footT: 0.05, rimT: 0.018,
      pts: [[0, 0.38], [0.05, 0.44], [0.18, 0.62], [0.36, 0.66], [0.55, 0.54], [0.74, 0.55],
        [0.90, 0.66], [1, 0.72]]
    },
    sara: {
      /* rimT was 0.055 and on a form this shallow that is most of the visible top - the thin-glaze
       * rim became a big orange lip rather than a line. A rim is a line at every scale. */
      label: 'plate', ratio: 0.34, footT: 0.22, rimT: 0.028,
      pts: [[0, 0.32], [0.14, 0.38], [0.28, 0.55], [0.55, 0.80], [0.82, 0.96], [1, 1.00]]
    },
    kame: {
      label: 'urn', ratio: 1.34, footT: 0.05, rimT: 0.020,
      pts: [[0, 0.46], [0.04, 0.53], [0.20, 0.82], [0.36, 0.96], [0.50, 1.00], [0.66, 0.94],
        [0.80, 0.79], [0.92, 0.64], [1, 0.68]]
    },
    mizusashi: {
      label: 'water jar', ratio: 1.00, footT: 0.05, rimT: 0.022,
      pts: [[0, 0.88], [0.04, 0.93], [0.30, 0.95], [0.62, 0.94], [0.86, 0.91], [0.94, 0.96], [1, 0.96]]
    },
    henko: {
      /* `facets` makes this the one form that is NOT a solid of revolution: its tonal sweep is
       * quantised into flat panels. Bake 1 shipped it without the flag and it was shape-identical
       * to tokkuri on the contact sheet, i.e. a duplicate wearing a different name. */
      label: 'slab bottle', ratio: 1.45, footT: 0.05, rimT: 0.020, facets: true,
      pts: [[0, 0.62], [0.04, 0.86], [0.10, 0.92], [0.52, 0.94], [0.66, 0.90], [0.73, 0.66],
        [0.78, 0.34], [0.88, 0.27], [0.96, 0.28], [1, 0.36]]
    }
  };

  var FORM_IDS = Object.keys(FORMS);

  /** Half-width fraction at height t, smoothstepped between control points (no overshoot). */
  function profileAt(form, t) {
    var p = form.pts;
    if (t <= p[0][0]) return p[0][1];
    for (var i = 1; i < p.length; i++) {
      if (t <= p[i][0]) {
        var a = p[i - 1], b = p[i];
        var lt = (t - a[0]) / (b[0] - a[0]);
        var s = lt * lt * (3 - 2 * lt);
        return a[1] + (b[1] - a[1]) * s;
      }
    }
    return p[p.length - 1][1];
  }

  /* ── surfaces ───────────────────────────────────────────────────────────────────────────────
   * The FAMILY is derived from what the potter applied and what the FIRE did, which is the whole
   * point of the game: the same glaze in the two atmospheres is two different objects.
   */
  var APPLIED = ['none', 'iron', 'shino'];

  /**
   * ONE declaration of "what does this firing produce". The game's economy, the collector wants
   * and the renderer all read it, so a rule change cannot land in one and not the others.
   *   applied 'none'  + reduction -> celadon   |  + oxidation -> amber   (natural ash glaze)
   *   applied 'iron'              -> tenmoku, darker in reduction
   *   applied 'shino'             -> shino, orange scorch in reduction
   *   heavy salt overrides toward the vapour surface.
   */
  function familyFor(spec) {
    if (spec.salt > 0.55) return 'sal';
    if (spec.applied === 'iron') return 'iro';
    if (spec.applied === 'shino') return 'shi';
    return spec.atmos === 'red' ? 'cel' : 'amb';
  }

  /** Human name for a finished surface - used by the shelf, the collectors and the store copy. */
  var FAMILY_LABEL = {
    cel: 'ash celadon', amb: 'amber ash', iro: 'tenmoku',
    shi: 'shino', sal: 'salt vapour', car: 'carbon trap'
  };

  /** Gloss per family: how tight the specular band is. Shino is matte, ash glaze is glass. */
  /* Bake 8 read MATTE across the board once the dot lattice was gone - the pattern had been doing
   * the job of contrast. A melted ash glaze is GLASS, so the families that are glass got their
   * specular back honestly. Shino stays low: shino really is matte, and flattening that difference
   * would cost the shelf its legibility (§0-ART: two things that MEAN differently must look it). */
  var GLOSS = { cel: 0.80, amb: 0.72, iro: 0.86, shi: 0.16, sal: 0.38, car: 0.22 };
  /** How much crazing each family shows (1px authored lines, §0-ART rule 2). */
  var CRAZE = { cel: 0.9, amb: 0.6, iro: 0.15, shi: 1.0, sal: 0.25, car: 0.2 };

  /**
   * Lay out the vessel inside a box of S px.
   * Returns { w, h, cx, baseY }. Kept separate so the game can hit-test and place shadows
   * without re-rendering.
   */
  function layout(form, S, fill) {
    var f = fill === undefined ? 0.88 : fill;
    var h = S * f;
    var w = h / form.ratio;
    if (w > S * f) { w = S * f; h = w * form.ratio; }
    return { w: w, h: h, cx: S / 2, baseY: (S + h) / 2 - Math.max(1, S * 0.02) };
  }

  /**
   * Build the drip set for a piece. Angular, not screen-space, so they foreshorten (see header).
   * ⚠️ Drips must STOP above the foot. In a real kiln a run that reaches the shelf welds the pot
   * to it and the piece is destroyed - the game uses that as a real failure mode, so the renderer
   * must never draw a legal pot with a drip touching the base.
   */
  function makeDrips(spec, form) {
    var rnd = mulberry32((spec.seed | 0) * 2654435761 + 17);
    /* ⛔ WAS `1 + ash*8 + rnd()*2` AND IT READ AS CORDUROY, not as runs (§0-ART rule 4: a dense
     * 1D lattice is textile). Nine wide vertical bands down a pot is a FACETED SURFACE. A real
     * ash run is rare and narrow, and rarity is what makes it read as an event. */
    var n = Math.round(1 + spec.ash * 3.4 + rnd() * 1.6);
    var drips = [];
    /* the flame side gets the ash, so drips cluster there: phi 0 is dead centre, +-1.45 is the
     * silhouette edge, and `spec.flame` is which way the firebox is. */
    var bias = spec.flame < 0 ? -0.55 : 0.55;
    for (var i = 0; i < n; i++) {
      var phi = clamp(bias + (rnd() - 0.5) * 2.1, -1.42, 1.42);
      /* start in the upper half, where an upward-facing surface can actually collect ash */
      var t0 = 0.52 + rnd() * 0.40;
      var len = (0.10 + rnd() * 0.34) * (0.45 + spec.ash);
      var t1 = Math.max(form.footT + 0.045, t0 - len);
      if (t0 - t1 < 0.035) continue;
      drips.push({
        phi: phi,
        t0: t0, t1: t1,
        wid: 0.030 + rnd() * 0.048 + spec.ash * 0.022,
        strength: 0.45 + rnd() * 0.55
      });
    }
    return drips;
  }

  /**
   * Render one vessel into `target` (needs setPx(x, y, key)) inside an S x S box.
   * `spec` = { form, applied, atmos, ash, salt, carbon, flame, seed }
   * Returns a small record the game stores with the piece.
   */
  function renderVessel(target, spec, S, opts) {
    opts = opts || {};
    var form = FORMS[spec.form];
    if (!form) throw new Error('renderVessel: unknown form "' + spec.form + '"');
    var fam = familyFor(spec);
    var g = layout(form, S, opts.fill);
    var drips = makeDrips(spec, form);
    var seed = spec.seed | 0;
    var gloss = GLOSS[fam], craze = CRAZE[fam];

    var glazeRamp = RAMPS[fam];
    var bodyRamp = RAMPS.body;
    var flashRamp = RAMPS.flash;
    var carRamp = RAMPS.car;
    var K = PAL.PREFIX;

    var painted = 0;
    var top = Math.floor(g.baseY - g.h), bot = Math.ceil(g.baseY);

    /* under the pot, before the pot: a shadow drawn after could eat the foot ring */
    if (opts.shadow !== false) drawContact(target, form, g, S);

    for (var y = top; y <= bot; y++) {
      var t = (g.baseY - y) / g.h;
      if (t < 0 || t > 1) continue;
      var hw = profileAt(form, t) * (g.w / 2);
      if (hw < 0.5) continue;

      /* upward-facing-ness: how fast the radius shrinks as you climb. This is where ash lands. */
      var dt = 0.02;
      var hwUp = profileAt(form, Math.min(1, t + dt)) * (g.w / 2);
      var up = clamp((hw - hwUp) / (g.h * dt) * 0.85, 0, 1);

      /* vertical: a pot is darker in its own shadow near the foot, and the shoulder catches sky */
      var vert = 0.87 + 0.13 * t;
      if (t < 0.16) vert *= 0.70 + 0.30 * (t / 0.16);

      var x0 = Math.floor(g.cx - hw), x1 = Math.ceil(g.cx + hw);
      for (var x = x0; x <= x1; x++) {
        var u = (x - g.cx) / hw;
        if (u < -1 || u > 1) continue;

        /* ── the revolve. This is the single most important line in the file: a pot is round,
         * and the horizontal position across it IS the surface angle. Everything else is paint. */
        var theta = Math.asin(clamp(u, -1, 1));
        var LA = -0.62;                                  /* light from the upper left */
        var lit = clamp(Math.cos(theta - LA), 0, 1);
        var rim = u > 0.78 ? Math.pow((u - 0.78) / 0.22, 2) * 0.42 : 0;   /* back-light on the far edge */
        /* ⛔ THE FIRST BAKE PRODUCED FLAT SILHOUETTES and the cause was arithmetic, not art: the
         * old expression topped out near 0.86, was then multiplied by `vert` and again by
         * (1 - 0.46*thick), so on an ash-heavy pot every pixel landed in the bottom half of a
         * SIX-STEP ramp - two or three keys for a whole vessel. A pot is round and the only thing
         * that says so is the tonal sweep across it, so the sweep gets the full ramp. */
        var shade = clamp(0.05 + 0.95 * (lit * 0.82 + rim * 0.55 + 0.12 * up), 0, 1) * vert;
        if (form.facets) {
          /* a slab bottle is not a solid of revolution: it has flat faces, so the sweep is
           * QUANTISED into panels. This is the only form that gets it, and it is what makes
           * henko read as a different object rather than as a narrow tokkuri. */
          var pan = Math.round(u * 2.2) / 2.2;
          shade = clamp(0.05 + 0.95 * (clamp(Math.cos(Math.asin(clamp(pan, -1, 1)) - LA), 0, 1) * 0.82
            + rim * 0.55 + 0.12 * up), 0, 1) * vert;
        }

        /* ── ash: falls from the firebox side, settles on what faces up. CONTINUOUS (rule 1). */
        var facing = clamp(0.5 + 0.5 * (u * spec.flame), 0, 1);
        var an = vnoise(x, y, Math.max(3, S * 0.22), seed + 3);
        var ashHere = clamp(spec.ash * (0.22 + 0.78 * facing) * (0.26 + 0.74 * up)
          * (0.55 + 0.9 * an), 0, 1);

        /* ── drips: authored geometry (rule 2), angular so they foreshorten. */
        var drip = 0, dripEdge = 0;
        for (var di = 0; di < drips.length; di++) {
          var d = drips[di];
          if (t > d.t0 || t < d.t1) continue;
          /* a bead where the run stopped */
          var bead = t < d.t1 + 0.030 ? 1.55 : 1.0;
          /* runs widen slightly as they descend */
          var wgrow = 1 + 0.35 * (d.t0 - t) / Math.max(0.001, d.t0 - d.t1);
          var w = d.wid * bead * wgrow;
          var dd = theta - d.phi;
          var a = 1 - smoothstep(w * 0.45, w, Math.abs(dd));
          if (a <= 0) continue;
          drip = Math.max(drip, a * d.strength);
          /* ⛔ THE SPECULAR WAS HALF THE RUN WIDE AND THE RUN CAME OUT LIGHTER THAN THE POT, so
           * bake 5's drips read as pale creases in cloth. A pooled ash run is DARKER and more
           * saturated than the glaze around it, carrying one thin bright line where the glass
           * turns to the light. Narrowed to a sliver on the lit shoulder. */
          if (dd < 0 && dd > -w * 0.55) {
            dripEdge = Math.max(dripEdge, a * (1 - Math.abs(dd + w * 0.30) / (w * 0.28)));
          }
        }
        var thick = clamp(ashHere * 0.75 + drip * 0.85, 0, 1);

        /* ── carbon trap: a continuous field on the flame-SHADOWED lower body. Deliberately
         * mixed, never thresholded - a cut here is the camouflage failure §0-ART rule 5 names. */
        var carbon = clamp(spec.carbon * (1 - facing) * (1 - smoothstep(0.15, 0.72, t))
          * (0.4 + 0.9 * vnoise(x, y, Math.max(4, S * 0.30), seed + 9)), 0, 1);

        var key = null;
        var inFoot = t < form.footT;
        var inRim = t > 1 - form.rimT;

        if (inFoot) {
          /* Bare clay: the foot is wiped clean so the pot does not weld to the shelf. It FLASHES
           * on the side that faced the fire - bare clay is where flashing is visible at all.
           * ⛔ THE FIRST BAKE DREW A BRIGHT ORANGE STRIPE ACROSS EVERY POT that read as a plinth
           * or a sticker. Two causes, both here: the flash/body choice was a HARD gate on
           * `fl > 0.42` so the whole ring flipped at once, and the flash ramp was driven to its
           * top steps. Now it is a dithered blend by how much of the fire that side actually saw,
           * and it is held to the ramp's middle - unglazed clay is dull, not neon. */
          /* ⛔ BAKE 2 STILL DREW A PLINTH. The dithered blend fixed the hard flip but not the two
           * things that made it shout: the flash ramp was driven to steps 3-4 (#d47c33/#e8a558,
           * near-neon) and the blend covered most of the ring. Flashing is a BLUSH on the side
           * that saw the fire, over clay that is otherwise dark and in the pot's own shadow. */
          var fl = clamp(facing * spec.flash, 0, 1);
          var fv = clamp(shade * 0.62, 0, 1);
          key = rampMix(bodyRamp, flashRamp, fl * 0.45, fv, x, y, 0.7, seed);
          /* the foot ring's own shadow line, 1px, authored */
          if (t > form.footT - 0.012) key = rampPick(bodyRamp, fv * 0.40, x, y, 0.4, seed);
        } else if (inRim) {
          /* Glaze runs THIN on a rim and the CLAY burns through. This one detail is most of what
           * makes a rendered pot read as fired rather than as a coloured shape.
           * ⛔ It burns through to CLAY - brown - and the first bake burned it through to bright
           * orange flash on every pot including ones that never faced the fire. */
          var m = (t - (1 - form.rimT)) / form.rimT;
          var rv = clamp(shade * (1 - 0.18 * thick), 0, 1);
          key = m > 0.45
            ? rampMix(bodyRamp, flashRamp, facing * spec.flash * 0.55,
              clamp(rv * 0.80 + 0.06, 0, 1), x, y, 1, seed)
            : rampPick(glazeRamp, clamp(rv * (1 - 0.40 * thick), 0, 1), x, y, 1, seed);
        } else {
          /* a pooled run is DARKER than the glaze it runs over - the drip term is separated from
           * the ash term so it can carry its own, stronger, darkening */
          var v = clamp(shade * (1 - 0.22 * ashHere * 0.75 - 0.52 * drip), 0, 1);
          /* specular: tight for glass, broad and weak for shino */
          var hi = Math.pow(clamp(Math.cos(theta - LA), 0, 1), 7) * gloss * (0.55 + 0.7 * thick);
          v = clamp(v + hi * 0.42 + dripEdge * 0.60 * gloss, 0, 1);
          /* ── carbon trap. CONTINUOUS, as the header always claimed and the first bake did not:
           * a dithered ramp blend, so heavy reduction darkens INTO the surface instead of
           * punching a flat black hole through it. */
          /* ⚠️ DITHER 0.62, NOT 1.0, AND THE REASON IS MEASURED RATHER THAN TASTE. Bake 2 read as
           * HALFTONE NEWSPRINT on the two low-contrast families (shino, salt) - a regular 4x4
           * checker over a whole belly - and `detail` reported 0.45-0.64 against a shipped band of
           * 0.14-0.38. §0-ART rule 6 warns that lowering dither IS a soft threshold and can bring
           * back hard band borders - and bake 3 proved that warning literally: the checker went and
           * a hard horizontal band arrived. ⇒ THE DIAL WENT BACK TO 1.0 AND THE RAMPS WERE
           * SUBDIVIDED INSTEAD (palette.js SUBDIV). Full dither over small steps is neither
           * checkerable nor bandable, and no value had to be guessed. */
          /* Carbon by PRE-MIXED TIER, so the dither only ever crosses a small gap (palette.js
           * carbonise()). tier is continuous and the two ramps it lands between are neighbours. */
          if (carbon > 0.015) {
            var tf = clamp(carbon * 2.35, 0, 2);
            var lo = Math.floor(tf), hi = Math.min(2, lo + 1);
            var loR = lo === 0 ? glazeRamp : RAMPS[fam + 'C' + (lo - 1)];
            var hiR = hi === 0 ? glazeRamp : RAMPS[fam + 'C' + (hi - 1)];
            key = rampMix(loR, hiR, tf - lo, clamp(v * (1 - 0.12 * carbon), 0, 1), x, y, 1, seed);
          } else {
            key = rampPick(glazeRamp, v, x, y, 1, seed);
          }
          /* Salt orange-peel: a 2px dimple. Thresholded, and legal, because it IS 2px (rule 5).
           * ⛔ Density and lift both cut after bake 4 - at 30% coverage and +0.13 it stopped being
           * a texture on a glaze and became granite. Orange peel is a subtle pucker you notice
           * when the light catches it, not a speckled stone. */
          if (spec.salt > 0.15 && hash2(x >> 1, y >> 1, seed + 21) < spec.salt * 0.16) {
            key = rampPick(glazeRamp, clamp(v + 0.06, 0, 1), x, y, 0, seed);
          }
          /* Iron speck, 1px, high octave (rule 5). ⛔ `grit` is a dark BROWN and on a green or
           * cream pot a scatter of dark brown dots reads as flies, not as iron in the clay - so
           * on a glazed surface the speck stays inside the material. Rate cut twice
           * (0.014 -> 0.006 -> 0.0035) across bakes 1, 3 and 5.
           * ⛔ AND `glazeRamp[0]` WAS STILL WRONG ON A PALE FAMILY: the ramp's bottom step against
           * cream shino is the highest contrast on the pot, so bake 8's shino read as PEPPER. A
           * speck is a fixed distance BELOW THE LOCAL TONE, not a fixed colour. */
          if (hash2(x, y, seed + 41) < 0.0035 * (1 - thick)) {
            key = rampPick(glazeRamp, clamp(v - 0.22, 0, 1), x, y, 0, seed);
          }
        }

        /* ⛔ every branch above yields a BARE palette name; the prefix is applied exactly once,
         * here. An earlier draft prefixed in some branches and not others and "normalised" with a
         * replace() - which would have silently mangled any key containing the prefix string. */
        target.setPx(x, y, K + key);
        painted++;
      }
    }

    /* ── authored 1px structure, drawn AFTER the surface so it is never dithered away ───────── */
    drawCrazing(target, spec, form, g, craze, S, seed);
    drawWadding(target, form, g, S, seed);

    return {
      family: fam, familyLabel: FAMILY_LABEL[fam], form: spec.form,
      formLabel: form.label, drips: drips.length, pixels: painted,
      box: { w: Math.round(g.w), h: Math.round(g.h), cx: g.cx, baseY: g.baseY }
    };
  }

  /**
   * Crazing: a fine crackle net in the glaze. Short 1px polylines, explicitly authored.
   * ⛔ BAKE 1 DREW THIS AS LONG NEAR-BLACK SQUIGGLES and it was the most damaging mark on the
   * sheet - the pots read as cracked or as having hairs stuck to them. Three causes, all fixed
   * here: the strokes ran up to 14% of the pot's height (real crazing is a tight net, not a
   * fracture), they were drawn in ramp[0] which is the darkest colour the surface owns, and they
   * were drawn at every size including the 56px shelf where a 1px black line is enormous.
   * ⚠️ At pixel-art scale crazing is a LIABILITY: it only earns its place on the inspect view.
   */
  function drawCrazing(target, spec, form, g, amount, S, seed) {
    if (amount <= 0.05 || S < 72) return;
    var rnd = mulberry32(seed * 40503 + 7);
    var n = Math.round(amount * (2 + S * 0.045));
    var fam = familyFor(spec);
    var ramp = RAMPS[fam];
    for (var i = 0; i < n; i++) {
      var t = form.footT + 0.06 + rnd() * (1 - form.footT - form.rimT - 0.10);
      var phi = (rnd() - 0.5) * 2.3;
      var len = 2 + rnd() * (S * 0.045);
      var dir = rnd() * Math.PI * 2;
      var y = g.baseY - t * g.h;
      var hw = profileAt(form, t) * (g.w / 2);
      var x = g.cx + Math.sin(phi) * hw;
      for (var s = 0; s < len; s++) {
        var px = Math.round(x + Math.cos(dir) * s);
        var py = Math.round(y + Math.sin(dir) * s * 0.7);
        var tt = (g.baseY - py) / g.h;
        if (tt < form.footT + 0.02 || tt > 1 - form.rimT) break;
        var hh = profileAt(form, tt) * (g.w / 2);
        if (Math.abs(px - g.cx) > hh - 1) break;
        /* ramp[1], never ramp[0]: a crack line one step off the surface reads as crazing, and the
         * darkest key the surface owns reads as a fracture. */
        target.setPx(px, py, PAL.PREFIX + ramp[1]);
        dir += (rnd() - 0.5) * 0.5;
      }
    }
  }

  /**
   * Wadding scars: the pale marks where the pot stood on seashells so it would not weld to the
   * shelf. A real, tiny, beloved detail.
   * ⛔ BAKE 1 DREW THREE WHITE BLOBS BELOW THE POT and they read as little wheels. Causes: the
   * near-white `wad` key against a dark pot is the highest contrast in the whole palette, the
   * radius was ~2px at 96, and they sat at the very bottom edge so they looked detached rather
   * than ON the foot. Now: 1px, pale CLAY rather than white, and up on the foot ring.
   */
  function drawWadding(target, form, g, S, seed) {
    if (S < 44) return;
    var rnd = mulberry32(seed * 97 + 3);
    var t = form.footT * 0.55;
    var y = Math.round(g.baseY - t * g.h);
    var hw = profileAt(form, t) * (g.w / 2);
    var n = 3;
    for (var i = 0; i < n; i++) {
      var phi = -0.85 + (i / (n - 1)) * 1.70 + (rnd() - 0.5) * 0.25;
      var x = Math.round(g.cx + Math.sin(phi) * hw * 0.80);
      target.setPx(x, y, PAL.PREFIX + 'wad');
      if (S >= 140) target.setPx(x + 1, y, PAL.PREFIX + RAMPS.body[4]);
    }
  }

  /**
   * The contact shadow. Without it a pot FLOATS, which bake 1 did on every one of 60 pieces.
   * Drawn UNDER the vessel before the vessel itself, so it can never eat the foot.
   */
  function drawContact(target, form, g, S) {
    var rw = profileAt(form, 0.02) * (g.w / 2) * 1.55;
    var rh = Math.max(1.2, S * 0.020);
    var cy = g.baseY + rh * 0.35;
    for (var y = Math.floor(cy - rh); y <= Math.ceil(cy + rh); y++) {
      for (var x = Math.floor(g.cx - rw); x <= Math.ceil(g.cx + rw); x++) {
        var dx = (x - g.cx) / rw, dy = (y - cy) / rh;
        var d = dx * dx + dy * dy;
        if (d > 1) continue;
        target.setPx(x, y, PAL.PREFIX + (d < 0.42 ? 'car0' : 'car1'));
      }
    }
  }

  return {
    FORMS: FORMS, FORM_IDS: FORM_IDS, APPLIED: APPLIED,
    FAMILY_LABEL: FAMILY_LABEL, GLOSS: GLOSS, CRAZE: CRAZE,
    familyFor: familyFor, layout: layout, profileAt: profileAt,
    renderVessel: renderVessel, mulberry32: mulberry32, rampPick: rampPick,
    hash2: hash2, vnoise: vnoise
  };
}));
