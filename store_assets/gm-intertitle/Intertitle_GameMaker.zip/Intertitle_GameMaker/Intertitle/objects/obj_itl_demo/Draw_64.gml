/// @description The scene, the card (itl_banner_draw is the same call your game makes), then the keys and what the
/// last card was built from.
if (!is_struct(demo)) exit;
var _w = display_get_gui_width(), _h = display_get_gui_height();
if (!is_undefined(demo.bg) && sprite_exists(demo.bg)) draw_sprite_stretched(demo.bg, 0, 0, 0, _w, _h);
itl_demo_dust(_w, _h, demo.tick);
itl_banner_draw(demo.banner, _w, _h);
itl_demo_help(_w, _h, [demo.facts, "N next place    B next boss    R return to the last place    D raise its danger    Space skip"]);
