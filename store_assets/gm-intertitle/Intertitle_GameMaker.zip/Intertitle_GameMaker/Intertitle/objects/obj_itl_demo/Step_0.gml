/// @description N (or Right) walks to the next place, B meets the next boss, R returns to the place you just left
/// (a plainer card), D raises the current place's danger, Space skips the card.
if (!is_struct(demo)) exit;
demo.tick++;
// the scene is baked into a sprite here, in Step, and re-baked when the GUI size changes
var _gw = display_get_gui_width(), _gh = display_get_gui_height();
if (is_undefined(demo.bg) || demo.bg_w != _gw || demo.bg_h != _gh) {
    if (!is_undefined(demo.bg) && sprite_exists(demo.bg)) sprite_delete(demo.bg);
    demo.bg = itl_demo_scene_sprite(_gw, _gh); demo.bg_w = _gw; demo.bg_h = _gh;
}
itl_banner_step(demo.banner);
if (keyboard_check_pressed(ord("N")) || keyboard_check_pressed(vk_right)) itl_demo_next_place(demo);
if (keyboard_check_pressed(ord("B"))) itl_demo_next_boss(demo);
if (keyboard_check_pressed(ord("R"))) itl_demo_return(demo);
if (keyboard_check_pressed(ord("D"))) itl_demo_danger(demo);
if (keyboard_check_pressed(vk_space)) itl_banner_skip(demo.banner);
