/// @description Free the banner's sprite and the baked scene.
if (variable_instance_exists(id, "demo") && is_struct(demo)) {
    itl_banner_free(demo.banner);
    if (!is_undefined(demo.bg) && sprite_exists(demo.bg)) sprite_delete(demo.bg);
}
demo = undefined;
