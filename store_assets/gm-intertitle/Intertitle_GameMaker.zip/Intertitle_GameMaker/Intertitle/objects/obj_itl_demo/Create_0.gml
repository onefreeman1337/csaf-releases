/// @description Intertitle demo - walk a sample world and meet its bosses; every card is derived from the facts in
/// itl_demo.gml - and the headless entry points (-selftest, -bake).
/// ⛔ The crash handler is installed FIRST, and every variable a later event reads is declared ABOVE the early exits:
/// Clean Up always runs, even when Create leaves early.
exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("itl_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.itl_stage) + ": " + string(_ex.message) + " | " + string(_ex.stacktrace));
    file_text_close(_f);
    game_end();
});
global.itl_stage = 0;
demo = itl_demo_state();
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";
if (string_pos("-selftest", _args) > 0) { global.itl_stage = 1; itl_selftest_write(itl_selftest_run()); game_end(); exit; }
if (string_pos("-bake", _args) > 0) { global.itl_stage = 2; itl_bake_run(); game_end(); exit; }
if (string_pos("-gif", _args) > 0) { global.itl_stage = 3; itl_bake_gif(); game_end(); exit; }

// the demo opens by arriving at the first place
itl_demo_next_place(demo);
