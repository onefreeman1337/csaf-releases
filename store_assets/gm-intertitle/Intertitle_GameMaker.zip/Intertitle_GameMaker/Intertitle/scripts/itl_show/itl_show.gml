/// itl_show.gml - the runtime. A banner object you keep in one controller: show it a place's or a boss's card and it
/// rises, holds and fades on the GUI layer, one card at a time. A BOSS card jumps the queue, sits in the centre, and
/// reports itself busy while it shows, so your battle can wait for the foe to be named.
///
/// Intertitle - Title Cards for Every Place and Every Boss, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// PUBLIC
///   itl_banner_create([opts])        -> a banner. opts: {hold (frames, default 150), boss_hold (default 180),
///                                       rise (default 24), fade (default 30), width (fraction of the GUI, default 0.62)}
///   itl_banner_show(banner, profile) -> queue a card (a profile from itl_place_card / itl_boss_card); false if refused
///   itl_banner_step(banner)          -> call once per Step
///   itl_banner_draw(banner, gui_w, gui_h) -> call from Draw GUI
///   itl_banner_busy(banner)          -> true while a BOSS card is showing
///   itl_banner_skip(banner)          -> end the current card now (a key press)
///   itl_banner_free(banner)          -> free its sprites (Clean Up)
/// Each card is baked once into a sprite at the size it is shown; a frame is one sprite draw.
/// The bake happens in itl_banner_STEP, never in Draw, and a sprite is deleted only in Step or Clean Up - never in the
/// frame's Draw right after it was drawn. Draw only ever draws a sprite that already exists. (This product's first
/// store bake drew every card as a solid WHITE box; see itl_bake.gml for what was measured about why.)

/// @function itl_banner_create([opts])
/// @description A new banner. See the file header for opts. Pure but for the struct it returns.
function itl_banner_create(_o = undefined) {
    var _num = function(_s, _k, _d, _lo, _hi) { if (!is_struct(_s) || !variable_struct_exists(_s, _k) || !is_numeric(_s[$ _k])) return _d; return clamp(_s[$ _k], _lo, _hi); };
    return {
        queue: [], cur: undefined, spr: undefined, spr_w: 0, spr_h: 0, t: 0,
        hold: _num(_o, "hold", 150, 1, 3600), boss_hold: _num(_o, "boss_hold", 180, 1, 3600),
        rise: _num(_o, "rise", 24, 1, 600), fade: _num(_o, "fade", 30, 1, 600), width: _num(_o, "width", 0.62, 0.2, 1),
        shown: 0, gw: 0, gh: 0
    };
}

/// @function itl__banner_ok(banner)
/// @description True when `banner` is a banner struct. Internal.
function itl__banner_ok(_b) { return is_struct(_b) && variable_struct_exists(_b, "queue") && is_array(_b.queue); }

/// @function itl_banner_show(banner, profile)
/// @description Queue a card. A boss card goes to the FRONT (and replaces a place card mid-show). Returns false for a
/// bad banner or a profile that is not a card.
function itl_banner_show(_b, _p) {
    if (!itl__banner_ok(_b) || !is_struct(_p) || !variable_struct_exists(_p, "kind") || !variable_struct_exists(_p, "name")) return false;
    if (_p.kind == "boss") {
        if (is_struct(_b.cur) && _b.cur.kind != "boss") { array_insert(_b.queue, 0, _b.cur); itl__banner_drop(_b); }
        array_insert(_b.queue, 0, _p);
    } else array_push(_b.queue, _p);
    return true;
}

/// @function itl__banner_drop(banner)
/// @description Forget the current card and free its sprite. Internal.
function itl__banner_drop(_b) {
    if (!is_undefined(_b.spr) && sprite_exists(_b.spr)) sprite_delete(_b.spr);
    _b.spr = undefined; _b.cur = undefined; _b.t = 0;
}

/// @function itl__banner_len(banner)
/// @description Frames the current card lasts, rise + hold + fade. Internal.
function itl__banner_len(_b) { return _b.rise + ((is_struct(_b.cur) && _b.cur.kind == "boss") ? _b.boss_hold : _b.hold) + _b.fade; }

/// @function itl_banner_step(banner)
/// @description Advance the current card one frame; start the next when it ends.
function itl_banner_step(_b) {
    if (!itl__banner_ok(_b)) return;
    if (is_struct(_b.cur)) { _b.t++; if (_b.t >= itl__banner_len(_b)) itl__banner_drop(_b); }
    if (!is_struct(_b.cur) && array_length(_b.queue) > 0) { _b.cur = _b.queue[0]; array_delete(_b.queue, 0, 1); _b.t = 0; _b.shown++; }
    if (!is_struct(_b.cur)) return;
    // bake (or re-bake at a new GUI size) HERE, with no draw target set
    var _sz = itl__banner_size(_b, (_b.gw > 0) ? _b.gw : display_get_gui_width());
    if (is_undefined(_b.spr) || _b.spr_w != _sz[0] || _b.spr_h != _sz[1]) {
        if (!is_undefined(_b.spr) && sprite_exists(_b.spr)) sprite_delete(_b.spr);
        _b.spr = itl_card_sprite(_b.cur, _sz[0], _sz[1], 2); _b.spr_w = _sz[0]; _b.spr_h = _sz[1];
    }
}

/// @function itl__banner_size(banner, gui_w)
/// @description [w, h] the current card is shown at for a GUI this wide. Internal.
function itl__banner_size(_b, _gw) {
    var _w = round(min(max(64, _gw) * _b.width, 1100));
    return [_w, round(_w / ((is_struct(_b.cur) && _b.cur.kind == "boss") ? 4.4 : 5.2))];
}

/// @function itl_banner_busy(banner)
/// @description True while a BOSS card is showing - hold your battle's first turn on it.
function itl_banner_busy(_b) { return itl__banner_ok(_b) && is_struct(_b.cur) && _b.cur.kind == "boss"; }

/// @function itl_banner_skip(banner)
/// @description End the current card now (it still fades out over a few frames).
function itl_banner_skip(_b) {
    if (!itl__banner_ok(_b) || !is_struct(_b.cur)) return;
    _b.t = max(_b.t, itl__banner_len(_b) - min(_b.fade, 8));
}

/// @function itl_banner_draw(banner, gui_w, gui_h)
/// @description Draw the current card, if any. A place card slides down from the top edge and fades; a boss card
/// grows in at the centre over a dimmed screen. Draws only a sprite itl_banner_step has already baked; when the GUI
/// size changes it draws the old one scaled for the one frame before the next Step re-bakes it.
function itl_banner_draw(_b, _gw, _gh) {
    if (!itl__banner_ok(_b) || !is_struct(_b.cur) || !is_numeric(_gw) || !is_numeric(_gh) || _gw < 64 || _gh < 64) return;
    _b.gw = _gw; _b.gh = _gh;
    if (is_undefined(_b.spr) || !sprite_exists(_b.spr)) return;
    var _boss = (_b.cur.kind == "boss");
    var _sz = itl__banner_size(_b, _gw), _w = _sz[0], _h = _sz[1], _sc = _w / max(1, _b.spr_w);
    var _len = itl__banner_len(_b), _t = _b.t;
    var _in = clamp(_t / _b.rise, 0, 1), _out = clamp((_len - _t) / _b.fade, 0, 1);
    var _e = 1 - power(1 - _in, 3), _a = min(_e, _out);   // ease out on the way in
    var _x = (_gw - _w) / 2;
    if (_boss) {
        draw_set_alpha(0.45 * _a); draw_set_colour(c_black); draw_rectangle(0, 0, _gw, _gh, false); draw_set_alpha(1);
        var _k = 0.92 + 0.08 * _e;
        draw_sprite_ext(_b.spr, 0, _gw / 2 - _w * _k / 2, _gh / 2 - _h * _k / 2, _k * _sc, _k * _sc, 0, c_white, _a);
    } else {
        var _y = _gh * 0.06 - (1 - _e) * _h * 0.6;
        draw_sprite_ext(_b.spr, 0, _x, _y, _sc, _sc, 0, c_white, _a);
    }
}

/// @function itl_banner_free(banner)
/// @description Free the banner's sprite and empty its queue. Call from Clean Up.
function itl_banner_free(_b) {
    if (!itl__banner_ok(_b)) return;
    itl__banner_drop(_b);
    _b.queue = [];
}
