/// itl_card.gml - the painter. Draws a card from a profile (itl_place_card / itl_boss_card): five constructions and a
/// seal, a device, the name set to fit, the line beneath it, and the marks for danger, depth, return and rank.
///
/// Intertitle - Title Cards for Every Place and Every Boss, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// PUBLIC
///   itl_card_draw(profile, x, y, w, h)          draw a card now, into whatever target is set; returns what was drawn
///   itl_card_sprite(profile, w, h, [supersample]) the same card baked into a sprite (drawn at 2x, filtered down)
///   itl_draw_charge(id, cx, cy, size, colour, [alpha]) one device on its own
///
/// The five constructions differ in how the card is BUILT, not in colour:
///   cartouche  an inked map cartouche with rolled ends and a double rule
///   woodcut    a board cut in relief, hatched, with a carved bevel
///   lacquer    a lacquered panel inside a gilt frame with corner ornaments
///   stone      a lintel of dressed stone with a chiselled bevel, joints and a crack in the margin
///   plate      a riveted plate with a stamped border
/// and the boss card is a SEAL: a medallion carrying the device, rays for rank, a fault line for its weakness.
/// Danger changes the rule's colour AND its shape (pointed caps from band 2, a doubled rule and a red roundel at 3):
/// a difference carried only by hue is a difference a colour-blind player cannot see.

/// @function itl__look(treatment)
/// @description Ground, ink, accent and edge per construction, as [r, g, b]. Roles, not decoration. Internal.
function itl__look(_t) {
    switch (_t) {
        case "cartouche": return { ground: [233, 220, 184], dark: [205, 185, 138], ink: [59, 42, 26], accent: [138, 59, 34], edge: [107, 84, 51] };
        case "lacquer": return { ground: [74, 20, 20], dark: [42, 10, 10], ink: [232, 200, 96], accent: [184, 147, 46], edge: [232, 200, 96] };
        case "stone": return { ground: [143, 138, 128], dark: [102, 97, 90], ink: [44, 42, 39], accent: [201, 195, 182], edge: [77, 73, 67] };
        case "plate": return { ground: [111, 122, 130], dark: [75, 84, 91], ink: [20, 26, 31], accent: [199, 208, 214], edge: [45, 53, 59] };
        case "seal": return { ground: [29, 26, 36], dark: [15, 13, 20], ink: [239, 230, 210], accent: [184, 147, 46], edge: [232, 200, 96] };
    }
    return { ground: [216, 195, 154], dark: [168, 137, 88], ink: [36, 23, 12], accent: [90, 58, 28], edge: [74, 47, 22] };
}

/// @function itl__danger(band)
/// @description The rule's colour for a danger band 0 (calm) .. 3 (lethal), as [r, g, b]. Internal.
function itl__danger(_d) {
    switch (clamp(floor(_d), 0, 3)) { case 1: return [160, 138, 58]; case 2: return [176, 96, 46]; case 3: return [158, 43, 37]; }
    return [107, 125, 90];
}

// ---------------------------------------------------------------------------------------------------------------
// Unit-box geometry for the devices: x and y in [-1, 1], y down.
// ---------------------------------------------------------------------------------------------------------------

/// @function itl__u(pts, cx, cy, s)
/// @description Unit-box points placed at (cx, cy) at scale s. Internal, pure.
function itl__u(_pts, _cx, _cy, _s) {
    var _n = array_length(_pts), _o = array_create(_n);
    for (var _i = 0; _i < _n; _i++) _o[_i] = [_cx + _pts[_i][0] * _s, _cy + _pts[_i][1] * _s];
    return _o;
}

/// @function itl__bez(out, p0, p1, p2, p3, n)
/// @description Append n points of a cubic Bezier from p0 (exclusive) to p3 (inclusive) to `out`. Internal, pure.
function itl__bez(_out, _p0, _p1, _p2, _p3, _n) {
    for (var _i = 1; _i <= _n; _i++) {
        var _t = _i / _n, _u = 1 - _t;
        var _a = _u * _u * _u, _b = 3 * _u * _u * _t, _c = 3 * _u * _t * _t, _d = _t * _t * _t;
        array_push(_out, [_a * _p0[0] + _b * _p1[0] + _c * _p2[0] + _d * _p3[0], _a * _p0[1] + _b * _p1[1] + _c * _p2[1] + _d * _p3[1]]);
    }
    return _out;
}

/// @function itl__arc(out, cx, cy, r, a0, a1, n)
/// @description Append n+1 points of a circular arc from angle a0 to a1 (radians, either direction). Internal, pure.
function itl__arc(_out, _cx, _cy, _r, _a0, _a1, _n) {
    for (var _i = 0; _i <= _n; _i++) { var _a = _a0 + (_a1 - _a0) * _i / _n; array_push(_out, [_cx + cos(_a) * _r, _cy + sin(_a) * _r]); }
    return _out;
}

/// @function itl__poly(pts, cx, cy, s, col, alpha)
/// @description Fill one unit-box polygon (any shape: scanline, non-zero). Internal.
function itl__poly(_pts, _cx, _cy, _s, _col, _alpha) { itl_fill_rings([itl__u(_pts, _cx, _cy, _s)], _col, _alpha, undefined, ITL_FILL_NONZERO); }

/// @function itl__line(pts, w, cx, cy, s, col, alpha, [closed])
/// @description Stroke a unit-box polyline `w` units wide with round joins. Internal.
function itl__line(_pts, _w, _cx, _cy, _s, _col, _alpha, _closed = false) {
    var _p = itl__u(_pts, _cx, _cy, _s);
    itl_polyline(_p, _w * _s, _col, _alpha, _closed);
    // round caps, so a stroked device does not end in a square notch
    if (!_closed && _w * _s >= 2) { itl_ellipse(_p[0][0], _p[0][1], _w * _s * 0.5, _w * _s * 0.5, 0, _col, _alpha); var _l = _p[array_length(_p) - 1]; itl_ellipse(_l[0], _l[1], _w * _s * 0.5, _w * _s * 0.5, 0, _col, _alpha); }
}

/// @function itl_draw_charge(id, cx, cy, size, colour, [alpha])
/// @description Draw one device, `size` px from centre to edge, in a GameMaker colour. An unknown id draws a plain disc.
/// Every device is a silhouette read from the part that breaks its outline (the arch's keystone, the key's bit).
function itl_draw_charge(_id, _cx, _cy, _s, _col, _alpha = 1) {
    if (!is_numeric(_cx) || !is_numeric(_cy) || !is_numeric(_s) || !(_s > 0) || _s > 4096) return false;
    var _p, _i, _a;
    switch (_id) {
        case "flame":
            _p = [[0.05, -0.95]];
            itl__bez(_p, [0.05, -0.95], [0.7, -0.3], [0.75, 0.3], [0.35, 0.85], 10);
            itl__bez(_p, [0.35, 0.85], [0.2, 0.95], [-0.35, 0.95], [-0.5, 0.7], 8);
            itl__bez(_p, [-0.5, 0.7], [-0.8, 0.2], [-0.3, -0.1], [-0.2, -0.45], 8);
            itl__bez(_p, [-0.2, -0.45], [-0.1, -0.2], [0.05, -0.5], [0.05, -0.95], 6);
            itl__poly(_p, _cx, _cy, _s, _col, _alpha); break;
        case "crystal":
            itl__poly([[0, -0.95], [0.45, -0.3], [0.3, 0.9], [-0.3, 0.9], [-0.45, -0.3]], _cx, _cy, _s, _col, _alpha);
            itl__poly([[0.55, -0.55], [0.8, -0.1], [0.62, 0.5], [0.45, 0.1]], _cx, _cy, _s, _col, _alpha); break;
        case "bolt":
            itl__poly([[0.25, -0.95], [-0.45, 0.1], [-0.02, 0.1], [-0.3, 0.95], [0.5, -0.15], [0.05, -0.15], [0.35, -0.95]], _cx, _cy, _s, _col, _alpha); break;
        case "wave":
            for (_i = 0; _i < 3; _i++) {
                var _y = -0.5 + _i * 0.5;
                _p = [[-0.9, _y]];
                itl__bez(_p, [-0.9, _y], [-0.5, _y - 0.35], [-0.3, _y + 0.35], [0, _y], 8);
                itl__bez(_p, [0, _y], [0.3, _y - 0.35], [0.5, _y + 0.35], [0.9, _y - 0.05], 8);
                itl__line(_p, 0.2, _cx, _cy, _s, _col, _alpha);
            }
            break;
        case "stone":
            // A CAIRN: three stones stacked, smallest on top (one irregular polygon read as a shapeless rock)
            itl_fill_rings([itl_ellipse_ring(_cx, _cy + 0.62 * _s, 0.86 * _s, 0.32 * _s, 0)], _col, _alpha, undefined, ITL_FILL_NONZERO);
            itl_fill_rings([itl_ellipse_ring(_cx - 0.06 * _s, _cy + 0.02 * _s, 0.6 * _s, 0.26 * _s, -0.08)], _col, _alpha, undefined, ITL_FILL_NONZERO);
            itl_fill_rings([itl_ellipse_ring(_cx + 0.04 * _s, _cy - 0.5 * _s, 0.36 * _s, 0.22 * _s, 0.1)], _col, _alpha, undefined, ITL_FILL_NONZERO); break;
        case "gust":
            _p = [[-0.9, -0.3], [0.3, -0.3]]; itl__arc(_p, 0.3, -0.55, 0.25, pi / 2, -pi * 0.6, 10);
            itl__line(_p, 0.18, _cx, _cy, _s, _col, _alpha);
            _p = [[-0.7, 0.25], [0.55, 0.25]]; itl__arc(_p, 0.55, 0.5, 0.25, -pi / 2, pi * 0.6, 10);
            itl__line(_p, 0.18, _cx, _cy, _s, _col, _alpha); break;
        case "sun":
            itl_fill_rings([itl_ellipse_ring(_cx, _cy, 0.42 * _s, 0.42 * _s, 0)], _col, _alpha, undefined, ITL_FILL_NONZERO);
            for (_i = 0; _i < 12; _i++) { _a = _i / 12 * 2 * pi; itl__poly([[cos(_a - 0.12) * 0.5, sin(_a - 0.12) * 0.5], [cos(_a) * 0.95, sin(_a) * 0.95], [cos(_a + 0.12) * 0.5, sin(_a + 0.12) * 0.5]], _cx, _cy, _s, _col, _alpha); }
            break;
        case "moon":
            itl_fill_rings([itl_ellipse_ring(_cx, _cy, 0.85 * _s, 0.85 * _s, 0, 64), itl_ellipse_ring(_cx + 0.35 * _s, _cy - 0.2 * _s, 0.7 * _s, 0.7 * _s, 0, 64)], _col, _alpha, undefined, ITL_FILL_EVENODD); break;
        case "compass":
            itl__poly([[0, -0.95], [0.18, -0.18], [0.95, 0], [0.18, 0.18], [0, 0.95], [-0.18, 0.18], [-0.95, 0], [-0.18, -0.18]], _cx, _cy, _s, _col, _alpha);
            itl__line(itl__arc([], 0, 0, 0.62, 0, 2 * pi, 48), 0.08, _cx, _cy, _s, _col, _alpha, true); break;
        case "tree":
            itl__poly([[0, -0.95], [0.55, -0.15], [0.25, -0.15], [0.7, 0.45], [0.12, 0.45], [0.12, 0.95], [-0.12, 0.95], [-0.12, 0.45], [-0.7, 0.45], [-0.25, -0.15], [-0.55, -0.15]], _cx, _cy, _s, _col, _alpha); break;
        case "key":
            itl_fill_rings([itl_ellipse_ring(_cx - 0.45 * _s, _cy - 0.45 * _s, 0.43 * _s, 0.43 * _s, 0), itl_ellipse_ring(_cx - 0.45 * _s, _cy - 0.45 * _s, 0.21 * _s, 0.21 * _s, 0)], _col, _alpha, undefined, ITL_FILL_EVENODD);
            itl__poly([[-0.26, -0.2], [0.8, 0.86], [0.66, 1.0], [-0.4, -0.06]], _cx, _cy, _s, _col, _alpha);
            itl__poly([[0.35, 0.42], [0.55, 0.22], [0.7, 0.37], [0.5, 0.57]], _cx, _cy, _s, _col, _alpha); break;
        case "arch":
            // Masonry reads from its KEYSTONE, its plinths and its step: a bare ring read as a horseshoe magnet.
            _p = [[-0.72, 0.72], [-0.72, -0.05]]; itl__arc(_p, 0, -0.05, 0.72, pi, 2 * pi, 18);
            array_push(_p, [0.72, 0.72], [0.4, 0.72], [0.4, -0.05]); itl__arc(_p, 0, -0.05, 0.4, 2 * pi, pi, 14); array_push(_p, [-0.4, 0.72]);
            itl__poly(_p, _cx, _cy, _s, _col, _alpha);
            itl__poly([[-0.2, -0.95], [0.2, -0.95], [0.13, -0.42], [-0.13, -0.42]], _cx, _cy, _s, _col, _alpha);
            itl__poly([[-0.86, 0.66], [-0.26, 0.66], [-0.26, 0.8], [-0.86, 0.8]], _cx, _cy, _s, _col, _alpha);
            itl__poly([[0.26, 0.66], [0.86, 0.66], [0.86, 0.8], [0.26, 0.8]], _cx, _cy, _s, _col, _alpha);
            itl__poly([[-0.98, 0.86], [0.98, 0.86], [0.98, 0.97], [-0.98, 0.97]], _cx, _cy, _s, _col, _alpha); break;
        case "cog":
            _p = [];
            for (_i = 0; _i < 10; _i++) {
                var _a0 = _i / 10 * 2 * pi, _a1 = _a0 + pi / 10;
                array_push(_p, [cos(_a0) * 0.95, sin(_a0) * 0.95], [cos(_a0 + 0.12) * 0.95, sin(_a0 + 0.12) * 0.95], [cos(_a1) * 0.7, sin(_a1) * 0.7], [cos(_a1 + 0.19) * 0.7, sin(_a1 + 0.19) * 0.7]);
            }
            itl_fill_rings([itl__u(_p, _cx, _cy, _s), itl_ellipse_ring(_cx, _cy, 0.3 * _s, 0.3 * _s, 0)], _col, _alpha, undefined, ITL_FILL_EVENODD); break;
        case "blade":
            itl__poly([[0.9, -0.9], [0.62, -0.3], [-0.35, 0.62], [-0.55, 0.42], [0.35, -0.6]], _cx, _cy, _s, _col, _alpha);
            itl__poly([[-0.2, 0.3], [-0.05, 0.45], [-0.62, 0.95], [-0.72, 0.85]], _cx, _cy, _s, _col, _alpha);
            itl__poly([[-0.55, 0.12], [-0.12, 0.55], [-0.2, 0.62], [-0.62, 0.2]], _cx, _cy, _s, _col, _alpha); break;
        case "rune":
            itl__line([[-0.3, -0.9], [-0.3, 0.9]], 0.2, _cx, _cy, _s, _col, _alpha);
            itl__line([[-0.3, -0.5], [0.45, -0.1], [-0.3, 0.3]], 0.2, _cx, _cy, _s, _col, _alpha);
            itl__line([[0.45, 0.4], [0.45, 0.9]], 0.2, _cx, _cy, _s, _col, _alpha); break;
        default:
            itl_fill_rings([itl_ellipse_ring(_cx, _cy, 0.6 * _s, 0.6 * _s, 0)], _col, _alpha, undefined, ITL_FILL_NONZERO);
            return false;
    }
    return true;
}

// ---------------------------------------------------------------------------------------------------------------
// Constructions. Each draws the card body in the box and returns the room left for the lettering {left, right, top,
// bottom}. `_u` is the card's own unit (h / 150): every fixed measure scales with the card, so a 2x bake is the same
// picture at twice the size.
// ---------------------------------------------------------------------------------------------------------------

/// @function itl__cartouche(x, y, w, h, L, rng)
function itl__cartouche(_x, _y, _w, _h, _L, _r) {
    var _u = _h / 150, _roll = _h * 0.22, _sy = _y + _h * 0.08, _sh = _h * 0.84;
    itl_rect_grad(_x + _roll, _sy, _w - _roll * 2, _sh, 0, _y, 0, _y + _h, itl_stops2(itl_col(_L.ground), itl_col(_L.dark)));
    for (var _s = 0; _s < 2; _s++) {   // rolled ends: a cylinder each side, lit on its left face
        var _cx = (_s == 0) ? _x + _roll * 0.9 : _x + _w - _roll * 0.9;
        itl_ellipse_grad(_cx, _y + _h / 2, _roll * 0.6, _h * 0.5, 0, _cx - _roll * 0.6, 0, _cx + _roll * 0.6, 0,
            [[0, itl_col(_L.dark), 1], [0.45, itl_col(_L.ground), 1], [1, itl_col(_L.edge), 1]]);
        itl_polyline(itl_ellipse_ring(_cx, _y + _h / 2, _roll * 0.6, _h * 0.5, 0, 48), 1.5 * _u, itl_col(_L.edge), 1, true);
        itl_polyline(itl_ellipse_ring(_cx, _y + _h / 2, _roll * 0.22, _h * 0.18, 0, 32), 1.2 * _u, itl_col(_L.ink), 1, true);
    }
    itl_rect_stroke(_x + _roll + 10 * _u, _sy + 8 * _u, _w - _roll * 2 - 20 * _u, _sh - 16 * _u, 2 * _u, itl_col(_L.ink));
    itl_rect_stroke(_x + _roll + 15 * _u, _sy + 13 * _u, _w - _roll * 2 - 30 * _u, _sh - 26 * _u, 0.8 * _u, itl_col(_L.ink));
    for (var _i = 0; _i < 18; _i++) {   // foxing
        var _fx = _x + _roll + itl_rng_next(_r) * (_w - _roll * 2), _fy = _y + _h * 0.1 + itl_rng_next(_r) * _h * 0.8, _fr = (2 + itl_rng_next(_r) * 7) * _u;
        itl_ellipse(_fx, _fy, _fr, _fr, 0, make_colour_rgb(120, 90, 40), 0.05 + itl_rng_next(_r) * 0.08);
    }
    return { left: _x + _roll + 22 * _u, right: _x + _w - _roll - 22 * _u, top: _sy + 16 * _u, bottom: _y + _h * 0.92 - 16 * _u };
}

/// @function itl__woodcut(x, y, w, h, L, rng)
function itl__woodcut(_x, _y, _w, _h, _L, _r) {
    var _u = _h / 150, _bev = max(6 * _u, _h * 0.07);
    itl_rect(_x, _y, _w, _h, itl_col(_L.edge));
    itl_rect(_x + _bev * 0.5, _y + _bev * 0.5, _w - _bev, _h - _bev, itl_col(_L.dark));
    itl_rect(_x + _bev, _y + _bev, _w - _bev * 2, _h - _bev * 2, itl_col(_L.ground));
    // relief hatching: horizontal cuts that ramp out toward the ends and leave the middle clear for the name
    for (var _yy = _y + _bev + 5 * _u; _yy < _y + _h - _bev - 3 * _u; _yy += 5 * _u) {
        var _t = abs((_yy - (_y + _h / 2)) / (_h / 2 - _bev));
        var _len = (_w - _bev * 2) * max(0, _t - 0.35) * 0.9;
        if (_len < 6 * _u) continue;
        var _lw = (1 + _t * 0.8) * _u, _j = itl_rng_next(_r) * 1.2 * _u;
        itl_seg(_x + _bev + 4 * _u, _yy, _x + _bev + 4 * _u + _len * 0.5, _yy + _j, _lw, itl_col(_L.accent));
        itl_seg(_x + _w - _bev - 4 * _u, _yy, _x + _w - _bev - 4 * _u - _len * 0.5, _yy + _j, _lw, itl_col(_L.accent));
    }
    // the carved bevel: lit on the upper left, shadowed on the lower right
    itl_polyline([[_x + _bev, _y + _h - _bev], [_x + _bev, _y + _bev], [_x + _w - _bev, _y + _bev]], 2 * _u, make_colour_rgb(255, 240, 210), 0.55);
    itl_polyline([[_x + _w - _bev, _y + _bev], [_x + _w - _bev, _y + _h - _bev], [_x + _bev, _y + _h - _bev]], 2 * _u, make_colour_rgb(40, 20, 5), 0.6);
    return { left: _x + _bev + 16 * _u, right: _x + _w - _bev - 16 * _u, top: _y + _bev + 8 * _u, bottom: _y + _h - _bev - 8 * _u };
}

/// @function itl__lacquer(x, y, w, h, L, rng)
function itl__lacquer(_x, _y, _w, _h, _L, _r) {
    var _u = _h / 150, _fr = max(6 * _u, _h * 0.065);
    // antique gilt, not new brass
    itl_rect_grad(_x, _y, _w, _h, 0, _y, 0, _y + _h, [[0, make_colour_rgb(214, 179, 90), 1], [0.5, make_colour_rgb(156, 122, 42), 1], [1, make_colour_rgb(94, 71, 18), 1]]);
    itl_rect(_x + _fr, _y + _fr, _w - _fr * 2, _h - _fr * 2, itl_col(_L.dark));
    itl_radial_rect(_x + _fr, _y + _fr, _w - _fr * 2, _h - _fr * 2, _x + _w * 0.35, _y + _h * 0.3, 10 * _u, _w * 0.6, itl_col(itl_mix(_L.ground, [255, 255, 255], 0.12)), 1, 0);
    var _in = _fr + 6 * _u;
    itl_rect_stroke(_x + _in, _y + _in, _w - _in * 2, _h - _in * 2, 1.4 * _u, itl_col(_L.edge));
    var _cs = _h * 0.18, _corners = [[_x + _in, _y + _in, 1, 1], [_x + _w - _in, _y + _in, -1, 1], [_x + _in, _y + _h - _in, 1, -1], [_x + _w - _in, _y + _h - _in, -1, -1]];
    for (var _i = 0; _i < 4; _i++) {   // corner ornaments: a quarter-round spandrel
        var _c = _corners[_i], _p = [[_c[0], _c[1]], [_c[0] + _cs * _c[2], _c[1]]];
        for (var _k = 1; _k <= 8; _k++) {   // quadratic toward the corner's inner point
            var _t = _k / 8, _q0 = [_c[0] + _cs * _c[2], _c[1]], _q1 = [_c[0] + _cs * 0.35 * _c[2], _c[1] + _cs * 0.35 * _c[3]], _q2 = [_c[0], _c[1] + _cs * _c[3]];
            array_push(_p, [(1 - _t) * (1 - _t) * _q0[0] + 2 * (1 - _t) * _t * _q1[0] + _t * _t * _q2[0], (1 - _t) * (1 - _t) * _q0[1] + 2 * (1 - _t) * _t * _q1[1] + _t * _t * _q2[1]]);
        }
        itl_fill_rings([_p], itl_col(_L.edge), 1, undefined, ITL_FILL_NONZERO);
    }
    // the lacquer's gloss streak
    itl_fill_rings([[[_x + _w * 0.1, _y + _fr], [_x + _w * 0.28, _y + _fr], [_x + _w * 0.16, _y + _h - _fr], [_x + _w * 0.02 + _fr, _y + _h - _fr]]], c_white, 0.06, undefined, ITL_FILL_NONZERO);
    return { left: _x + _fr + 26 * _u, right: _x + _w - _fr - 26 * _u, top: _y + _fr + 10 * _u, bottom: _y + _h - _fr - 10 * _u };
}

/// @function itl__stone(x, y, w, h, L, rng)
function itl__stone(_x, _y, _w, _h, _L, _r) {
    var _u = _h / 150, _bev = max(8 * _u, _h * 0.1), _i;
    itl_rect(_x, _y, _w, _h, itl_col(_L.dark));
    itl_rect(_x + _bev, _y + _bev, _w - _bev * 2, _h - _bev * 2, itl_col(_L.ground));
    itl_fill_rings([[[_x, _y], [_x + _w, _y], [_x + _w - _bev, _y + _bev], [_x + _bev, _y + _bev], [_x + _bev, _y + _h - _bev], [_x, _y + _h]]], itl_col(itl_mix(_L.ground, [255, 255, 255], 0.25)), 1, undefined, ITL_FILL_NONZERO);
    itl_fill_rings([[[_x + _w, _y], [_x + _w, _y + _h], [_x, _y + _h], [_x + _bev, _y + _h - _bev], [_x + _w - _bev, _y + _h - _bev], [_x + _w - _bev, _y + _bev]]], itl_col(itl_mix(_L.dark, [0, 0, 0], 0.25)), 1, undefined, ITL_FILL_NONZERO);
    itl_batch_begin();   // dressed-stone speckle
    for (_i = 0; _i < 260; _i++) {
        var _dark = itl_rng_next(_r) < 0.5;
        itl_batch_rect(_x + _bev + itl_rng_next(_r) * (_w - _bev * 2), _y + _bev + itl_rng_next(_r) * (_h - _bev * 2), 2 * _u, 2 * _u, _dark ? c_black : c_white, _dark ? 0.07 : 0.06);
    }
    itl_batch_end();
    // joints near the ENDS and a crack in the right-hand margin: through the middle they ran through the carved name
    var _j1 = _x + _w * (0.035 + itl_rng_next(_r) * 0.02), _j2 = _x + _w * (0.945 + itl_rng_next(_r) * 0.02);
    itl_seg(_j1, _y + _bev, _j1, _y + _h - _bev, 1.5 * _u, make_colour_rgb(30, 28, 25), 0.55);
    itl_seg(_j2, _y + _bev, _j2, _y + _h - _bev, 1.5 * _u, make_colour_rgb(30, 28, 25), 0.55);
    var _px = _x + _w * (0.90 + itl_rng_next(_r) * 0.03), _py = _y + _bev, _crack = [[_px, _py]];
    for (_i = 0; _i < 5; _i++) { _px += (itl_rng_next(_r) - 0.5) * 14 * _u; _py += _h * 0.06; array_push(_crack, [_px, _py]); }
    itl_polyline(_crack, 1 * _u, make_colour_rgb(25, 22, 20), 0.7);
    return { left: _x + _bev + 22 * _u, right: _x + _w - _bev - 22 * _u, top: _y + _bev + 6 * _u, bottom: _y + _h - _bev - 6 * _u };
}

/// @function itl__plate(x, y, w, h, L, rng)
function itl__plate(_x, _y, _w, _h, _L, _r) {
    var _u = _h / 150;
    itl_rect_grad(_x, _y, _w, _h, 0, _y, 0, _y + _h, [[0, itl_col(itl_mix(_L.ground, [255, 255, 255], 0.18)), 1], [0.5, itl_col(_L.ground), 1], [1, itl_col(_L.dark), 1]]);
    itl_batch_begin();   // brushed grain
    for (var _yy = _y + 2 * _u; _yy < _y + _h - 2 * _u; _yy += 2 * _u) itl_batch_rect(_x + 2 * _u, _yy, _w - 4 * _u, max(1, _u), c_white, 0.02 + itl_rng_next(_r) * 0.04);
    itl_batch_end();
    itl_rect_stroke(_x + 10 * _u, _y + 10 * _u, _w - 20 * _u, _h - 20 * _u, 3 * _u, itl_col(_L.edge));
    itl_rect_stroke(_x + 12 * _u, _y + 12 * _u, _w - 24 * _u, _h - 24 * _u, 1 * _u, c_white, 0.35);
    // rivets: the PITCH is derived and the count follows from the run
    var _rr = max(3 * _u, _h * 0.035), _pitch = _rr * 9, _n = max(2, floor((_w - 40 * _u) / _pitch) + 1), _step = (_w - 40 * _u) / (_n - 1);
    for (var _i = 0; _i < _n; _i++) {
        var _rx = _x + 20 * _u + _i * _step;
        for (var _k = 0; _k < 2; _k++) {
            var _ry = (_k == 0) ? _y + 20 * _u : _y + _h - 20 * _u;
            itl_ellipse(_rx + _rr * 0.2, _ry + _rr * 0.25, _rr, _rr, 0, itl_col(_L.edge));
            itl_ellipse(_rx, _ry, _rr, _rr, 0, itl_col(_L.accent));
            itl_ellipse(_rx - _rr * 0.35, _ry - _rr * 0.35, _rr * 0.3, _rr * 0.3, 0, c_white);
        }
    }
    // the lettering keeps clear of both rivet rows (the first bake ran "aboard Orbital Ring" through the bottom row)
    var _clear = 20 * _u + _rr + 6 * _u;
    return { left: _x + 30 * _u, right: _x + _w - 30 * _u, top: _y + _clear, bottom: _y + _h - _clear };
}

/// @function itl__seal(x, y, w, h, L, rng, profile)
function itl__seal(_x, _y, _w, _h, _L, _r, _p) {
    var _u = _h / 150, _bh = _h * 0.62, _by = _y + (_h - _bh) / 2;
    // the medallion is inset by its ray reach, and sized so the reach fits the card: the rays were clipped once
    var _mr = _h * 0.40, _reach = _mr * 1.22, _mx = _x + _reach + 2 * _u, _my = _y + _h / 2;
    var _band = [[_mx, _by], [_x + _w - 18 * _u, _by], [_x + _w, _by + _bh / 2], [_x + _w - 18 * _u, _by + _bh], [_mx, _by + _bh]];
    itl_fill_rings([_band], c_white, 1, { x0: 0, y0: _by, x1: 0, y1: _by + _bh, stops: itl_stops2(itl_col(itl_mix(_L.ground, [255, 255, 255], 0.08)), itl_col(_L.dark)) }, ITL_FILL_NONZERO);
    itl_polyline(_band, 2 * _u, itl_col(_L.edge), 1, true);
    var _tier = is_struct(_p) ? itl__int(itl__field(_p, "tier", 0), 0, 3) : 0;
    var _ray_counts = [0, 8, 12, 16];
    var _rays = _ray_counts[_tier];
    for (var _i = 0; _i < _rays; _i++) {   // rank: rays behind the medallion
        var _a = _i / _rays * 2 * pi;
        itl_fill_rings([[[_mx + cos(_a - 0.08) * _mr, _my + sin(_a - 0.08) * _mr], [_mx + cos(_a) * _reach, _my + sin(_a) * _reach], [_mx + cos(_a + 0.08) * _mr, _my + sin(_a + 0.08) * _mr]]], itl_col(_L.accent), 1, undefined, ITL_FILL_NONZERO);
    }
    itl_fill_rings([itl_ellipse_ring(_mx, _my, _mr, _mr, 0, 72)], c_white, 1, { x0: _mx - _mr, y0: _my - _mr, x1: _mx + _mr * 0.6, y1: _my + _mr * 0.6, stops: itl_stops2(make_colour_rgb(243, 220, 138), make_colour_rgb(122, 94, 23)) }, ITL_FILL_NONZERO);
    itl_fill_rings([itl_ellipse_ring(_mx, _my, _mr * 0.8, _mr * 0.8, 0, 72)], itl_col(_L.dark), 1, undefined, ITL_FILL_NONZERO);
    return { left: _mx + _reach + 18 * _u, right: _x + _w - 30 * _u, top: _by + 6 * _u, bottom: _by + _bh - 6 * _u, mx: _mx, my: _my, mr: _mr * 0.8 };
}

/// @function itl__fault(mx, my, mr, u)
/// @description A boss's weakness: a jagged fault line across the medallion, drawn OVER the device. Internal.
function itl__fault(_mx, _my, _mr, _u) {
    var _fx = _mx - _mr * 0.75, _fy = _my + _mr * 0.2, _p = [[_fx, _fy]];
    for (var _k = 1; _k <= 5; _k++) { _fx += _mr * 0.3; _fy += ((_k mod 2) ? -1 : 1) * _mr * 0.12; array_push(_p, [_fx, _fy]); }
    itl_polyline(_p, 2 * _u, make_colour_rgb(201, 65, 46), 1);
}

// ---------------------------------------------------------------------------------------------------------------
// Lettering. The name is set in small capitals: capitals at full height, the rest of each word in capitals 78% as
// tall, sitting on one baseline - the form an engraved title uses. The fitter SAYS whether it fits.
// ---------------------------------------------------------------------------------------------------------------

/// @function itl__minor_word(word)
/// @description True for the short words an engraved title keeps small unless they come first ("Chapel of the Dawn",
/// "Mother of Rime"): giving them a large initial read as "Chapel Of The Dawn" on the first bake. Internal, pure.
function itl__minor_word(_w) {
    static _minor = ["of", "the", "and", "a", "an", "in", "on", "at", "to", "for", "by", "de", "du", "la", "le", "von", "van", "or", "from", "under"];
    return array_get_index(_minor, string_lower(_w)) >= 0;
}

/// @function itl__sc_runs(text)
/// @description The small-capital runs of a string: [[text, big?], ...]. The first letter of every word is big, except
/// a minor word that is not the first. Internal, pure.
function itl__sc_runs(_s) {
    var _out = [], _cur = "", _big = false, _start = true, _first = true;
    for (var _i = 1; _i <= string_length(_s); _i++) {
        var _ch = string_char_at(_s, _i), _isb = _start && _ch != " ";
        if (_isb) {   // a word starts here: read it to decide whether its initial is large
            var _j = _i, _word = "";
            while (_j <= string_length(_s) && string_char_at(_s, _j) != " ") { _word += string_char_at(_s, _j); _j++; }
            if (!_first && itl__minor_word(_word)) _isb = false;
            _first = false;
        }
        if (_ch == " ") _start = true; else _start = false;
        if (_i == 1) { _big = _isb; _cur = _ch; continue; }
        if (_isb != _big) { array_push(_out, [_cur, _big]); _cur = _ch; _big = _isb; } else _cur += _ch;
    }
    if (_cur != "") array_push(_out, [_cur, _big]);
    return _out;
}

/// @function itl__sc_width(text, px, track)
/// @description Width of a small-capital line at cap height px. Internal.
function itl__sc_width(_s, _px, _track) {
    var _runs = itl__sc_runs(_s), _w = 0;
    for (var _i = 0; _i < array_length(_runs); _i++) _w += itl_tracked_w(string_upper(_runs[_i][0]), _runs[_i][1] ? _px : _px * 0.78, _track) + ((_i < array_length(_runs) - 1) ? _track : 0);
    return _w;
}

/// @function itl__sc_draw(cx, baseline, text, px, track, colour, alpha)
/// @description Draw a small-capital line centred on cx with its BASELINE at `baseline`. Returns the width. Internal.
function itl__sc_draw(_cx, _base, _s, _px, _track, _col, _alpha) {
    var _w = itl__sc_width(_s, _px, _track), _x = _cx - _w / 2, _runs = itl__sc_runs(_s);
    for (var _i = 0; _i < array_length(_runs); _i++) {
        var _rp = _runs[_i][1] ? _px : _px * 0.78, _t = string_upper(_runs[_i][0]);
        // a cap sits on the baseline: its top is one cap height (~0.74 of the font's px) above it, plus the atlas's own
        // top bearing (~0.16)
        _x += itl_tracked(_x, _base - _rp * 0.90, _t, _rp, _track, _col, fnt_intertitle_display, _alpha) + _track;
    }
    return _w;
}

/// @function itl__fit_name(text, maxw, maxpx, minpx)
/// @description {px, track, width, fits} for a small-capital name: tracking shrinks first, then size. Internal.
function itl__fit_name(_s, _maxw, _px, _minpx) {
    var _track = _px * 0.04, _w = itl__sc_width(_s, _px, _track);
    while (_w > _maxw && _track > 0) { _track = max(0, _track - _px * 0.01); _w = itl__sc_width(_s, _px, _track); }
    while (_w > _maxw && _px > _minpx) { _px = max(_minpx, _px - max(0.5, _px * 0.05)); _w = itl__sc_width(_s, _px, _track); }
    return { px: _px, track: _track, width: _w, fits: _w <= _maxw + 0.5 };
}

/// @function itl_card_draw(profile, x, y, w, h)
/// @description Draw one card into the current target, in the box (x, y, w, h); a landscape box around 5:1 reads best.
/// Returns what was drawn: {treatment, charge, name_px, name_fits, epithet_fits}, or undefined for a bad profile or box
/// (a refusal, never a crash inside your Draw event).
function itl_card_draw(_p, _x, _y, _w, _h) {
    if (!is_struct(_p) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w) || !is_numeric(_h) || !(_w >= 40) || !(_h >= 16) || _w > 8192 || _h > 8192) return undefined;
    var _t = itl__field(_p, "treatment", "woodcut");
    if (_t != "seal" && array_get_index(itl_treatments(), _t) < 0) _t = "woodcut";
    var _L = itl__look(_t), _u = _h / 150, _r = itl_rng(itl_hash(string(itl__field(_p, "key", "x"))));
    var _box;
    switch (_t) {
        case "cartouche": _box = itl__cartouche(_x, _y, _w, _h, _L, _r); break;
        case "lacquer": _box = itl__lacquer(_x, _y, _w, _h, _L, _r); break;
        case "stone": _box = itl__stone(_x, _y, _w, _h, _L, _r); break;
        case "plate": _box = itl__plate(_x, _y, _w, _h, _L, _r); break;
        case "seal": _box = itl__seal(_x, _y, _w, _h, _L, _r, _p); break;
        default: _box = itl__woodcut(_x, _y, _w, _h, _L, _r); break;
    }
    var _gilt = (_t == "lacquer" || _t == "seal");
    var _ink = itl_col(_gilt ? _L.edge : _L.ink);
    var _kind = itl__field(_p, "kind", "place"), _danger = itl__int(itl__field(_p, "danger", 0), 0, 3);
    var _charge = itl__field(_p, "charge", "compass");
    if (_t == "seal") {
        itl_draw_charge(_charge, _box.mx, _box.my, _box.mr * 0.72, _ink);
        if (!is_undefined(itl__field(_p, "weakness", undefined))) itl__fault(_box.mx, _box.my, _box.mr, _u);
    } else {
        var _cr = (_box.bottom - _box.top) * 0.42, _ccx = _box.left + _cr, _ccy = (_box.top + _box.bottom) / 2;
        var _lethal = (_kind == "place" && _danger >= 3);   // the roundel turns red on a lethal place
        itl_polyline(itl_ellipse_ring(_ccx, _ccy, _cr, _cr, 0, 64), (_lethal ? 3 : 1.5) * _u, _lethal ? itl_col(itl__danger(3)) : _ink, 1, true);
        itl_draw_charge(_charge, _ccx, _ccy, _cr * 0.72, _ink);
        _box.left = _ccx + _cr + 18 * _u;
    }
    var _room = _box.right - _box.left, _cx = (_box.left + _box.right) / 2, _bh = _box.bottom - _box.top;
    // A RETURN is shorter and plainer: no epithet, no sub-place marks, a smaller name set lower. (A first cut changed
    // only the rule's weight, and first and return visits were the same picture.)
    var _returning = (_kind == "place" && !itl__field(_p, "first_visit", true));
    var _name = string(itl__field(_p, "name", "")), _ep = string(itl__field(_p, "epithet", ""));
    var _has_ep = (_ep != "") && !_returning;
    var _maxpx = round(_bh * (_returning ? 0.40 : (_has_ep ? 0.52 : 0.66)));
    var _nf = itl__fit_name(_name, _room, _maxpx, 10 * _u);
    // the name, its rule and the line beneath are ONE block, centred in the lettering box: placed from the top, the
    // line beneath ran into the plate's bottom rivet row
    var _block = _nf.px * 1.2 + (_has_ep ? 5 * _u + _nf.px * 0.42 * 1.2 : 0);
    var _base = _box.top + (_returning ? _bh * 0.2 : max(0, (_bh - _block) / 2)) + _nf.px;
    if (_t == "stone") itl__sc_draw(_cx + 1 * _u, _base + 1 * _u, _name, _nf.px, _nf.track, c_white, 0.35);   // the carved edge catches light
    itl__sc_draw(_cx, _base, _name, _nf.px, _nf.track, _ink, 1);
    var _ry = _base + _nf.px * 0.2;
    if (_kind == "place") {
        var _dc = itl_col(itl__danger(_danger)), _rw = min(_room, _nf.width * 1.1);
        itl_seg(_cx - _rw / 2, _ry, _cx + _rw / 2, _ry, (itl__field(_p, "first_visit", true) ? 2.5 : 1.2) * _u, _dc);
        if (_danger >= 2) for (var _sd = -1; _sd <= 1; _sd += 2) {   // pointed caps from band 2: danger in SHAPE, not only hue
            var _ex = _cx + _sd * _rw / 2;
            itl_fill_rings([[[_ex + _sd * 9 * _u, _ry], [_ex, _ry - 4.5 * _u], [_ex, _ry + 4.5 * _u]]], _dc, 1, undefined, ITL_FILL_NONZERO);
        }
        if (_danger >= 3 && !_returning) itl_seg(_cx - _rw * 0.42, _ry + 4 * _u, _cx + _rw * 0.42, _ry + 4 * _u, 1.2 * _u, _dc);
        var _cm = _returning ? 0 : itl__int(itl__field(_p, "count_mark", 0), 0, 5);
        for (var _i = 0; _i < _cm; _i++) {   // how many places sit inside it, as lozenges on the rule
            var _lx = _cx - (_cm - 1) * 7 * _u + _i * 14 * _u;
            itl_fill_rings([[[_lx, _ry - 4 * _u], [_lx + 4 * _u, _ry], [_lx, _ry + 4 * _u], [_lx - 4 * _u, _ry]]], _dc, 1, undefined, ITL_FILL_NONZERO);
        }
    }
    var _ef = { fits: true };
    if (_has_ep) {
        var _epx = max(9 * _u, _nf.px * 0.42);
        _ef = itl_fit_tracked(_ep, _room * 0.9, _epx, _epx * 0.03, 8 * _u, fnt_intertitle_title);
        var _ecol = _gilt ? itl_col(itl_mix(_L.edge, _L.ground, 0.25)) : itl_col(_L.accent);
        var _ey = _ry + ((_kind == "place" && _danger >= 3) ? 9 : 5) * _u;
        if (_ef.fits) itl_tracked(_cx - _ef.width / 2, _ey, _ep, _ef.px, _ef.track, _ecol, fnt_intertitle_title);
    }
    return { treatment: _t, charge: _charge, name_px: _nf.px, name_fits: _nf.fits, epithet_fits: _ef.fits };
}

/// @function itl_card_sprite(profile, w, h, [supersample])
/// @description The card baked into a new sprite w x h px (drawn at `supersample`x, default 2, and filtered down, so its
/// edges are smooth). The sprite is YOURS: sprite_delete() it when done. undefined for a bad profile or size.
/// ⛔ Keep the sprite alive until the frame that draws it has been presented: sprite_delete() straight after
/// draw_sprite() leaves the queued draw without its texture - a solid white box (MEASURED: 100.0% white, against 0.0%
/// for the same sprite kept alive). Bake in Create or Step, draw in Draw, delete in Step or Clean Up.
function itl_card_sprite(_p, _w, _h, _ss = 2) {
    if (!is_struct(_p) || !is_numeric(_w) || !is_numeric(_h) || !(_w >= 40) || !(_h >= 16) || _w > 4096 || _h > 4096) return undefined;
    _ss = is_numeric(_ss) ? clamp(round(_ss), 1, 4) : 2;
    var _W = ceil(_w), _H = ceil(_h);
    var _big = surface_create(_W * _ss, _H * _ss);
    surface_set_target(_big);
    draw_clear_alpha(c_black, 0);
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    var _res = itl_card_draw(_p, 0, 0, _W * _ss, _H * _ss);
    gpu_set_blendmode(bm_normal);
    surface_reset_target();
    var _small = surface_create(_W, _H);
    surface_set_target(_small);
    draw_clear_alpha(c_black, 0);
    gpu_set_blendenable(false);
    var _tf = gpu_get_texfilter();
    gpu_set_texfilter(true);
    draw_surface_ext(_big, 0, 0, 1 / _ss, 1 / _ss, 0, c_white, 1);
    gpu_set_texfilter(_tf);
    gpu_set_blendenable(true);
    surface_reset_target();
    var _spr = sprite_create_from_surface(_small, 0, 0, _W, _H, false, false, 0, 0);
    surface_free(_big); surface_free(_small);
    if (is_undefined(_res)) { sprite_delete(_spr); return undefined; }
    return _spr;
}
