/// itl_bake.gml - `Intertitle.exe -bake` renders the store sheets from the shipped code into the game's save area
/// (itl_sheet_*.png) and writes itl_bake.json. Not needed at runtime: delete it with the demo object's -bake branch.
///
/// Intertitle - Title Cards for Every Place and Every Boss, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
/// ⛔ Every card on a sheet is a sprite from itl_card_sprite - the path a game uses. The first bake built each one
/// INSIDE the sheet's surface target, drew it, and deleted it on the next line: all twelve came out as solid WHITE
/// boxes. MEASURED in the suite, both arms: a sprite built inside a surface target reads 0.0% white, and a sprite drawn
/// then deleted before the target flushes reads 100.0% white. GameMaker QUEUES a draw; deleting the sprite first leaves
/// the queued draw without its texture. Sheets now build every sprite first, draw, save, and only then delete.

/// @function itl_bake_sheet(name, w, h, fn, data)
/// @description Draw fn(w, h, data) onto a w x h surface over the page colour, save it as itl_sheet_<name>.png.
function itl_bake_sheet(_name, _w, _h, _fn, _data) {
    var _sf = surface_create(_w, _h);
    surface_set_target(_sf);
    draw_clear(make_colour_rgb(16, 15, 20));
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    _fn(_w, _h, _data);
    gpu_set_blendmode(bm_normal);
    surface_reset_target();
    surface_save(_sf, "itl_sheet_" + _name + ".png");
    surface_free(_sf);
    return _name;
}

/// @function itl_bake_sprites(profiles, w, h)
/// @description One card sprite per profile, built with NO target set. Free with itl_bake_free.
function itl_bake_sprites(_ps, _w, _h) {
    var _o = [];
    for (var _i = 0; _i < array_length(_ps); _i++) array_push(_o, itl_card_sprite(_ps[_i], _w, _h, 2));
    return _o;
}

/// @function itl_bake_free(sprites)
function itl_bake_free(_s) { for (var _i = 0; _i < array_length(_s); _i++) if (!is_undefined(_s[_i]) && sprite_exists(_s[_i])) sprite_delete(_s[_i]); }

/// @function itl_bake_head(w, title, sub)
function itl_bake_head(_w, _title, _sub) {
    itl_text(_w / 2, 26, _title, 44, make_colour_rgb(238, 226, 200), fa_center, fa_top, fnt_intertitle_title);
    itl_text(_w / 2, 80, _sub, 21, make_colour_rgb(190, 180, 160), fa_center, fa_top, fnt_intertitle);
}

/// @function itl_bake_places(w, h, sprites)
function itl_bake_places(_w, _h, _spr) {
    itl_bake_head(_w, "TWELVE PLACES, TWELVE CARDS", "The construction comes from the place's setting, the device from what its foes strike with, the line beneath from where it sits.");
    var _cw = 760, _ch = 146, _gx = 24, _gy = 18, _x0 = (_w - _cw * 2 - _gx) / 2, _y0 = 128;
    for (var _i = 0; _i < array_length(_spr); _i++) if (!is_undefined(_spr[_i])) draw_sprite(_spr[_i], 0, _x0 + (_i mod 2) * (_cw + _gx), _y0 + (_i div 2) * (_ch + _gy));
}

/// @function itl_bake_bosses(w, h, sprites)
function itl_bake_bosses(_w, _h, _spr) {
    itl_bake_head(_w, "THE FIGHT WAITS FOR THE FOE TO BE NAMED", "A seal from its element, a fault line for its weakness, rays for how high it stands among your foes.");
    var _cw = 1100, _ch = 250, _x0 = (_w - _cw) / 2;
    for (var _i = 0; _i < array_length(_spr); _i++) if (!is_undefined(_spr[_i])) draw_sprite(_spr[_i], 0, _x0, 140 + _i * (_ch + 24));
}

/// @function itl_bake_devices(w, h, data)
function itl_bake_devices(_w, _h, _data) {
    itl_bake_head(_w, "FIFTEEN DEVICES", "Eight from an element's name, five from a place's construction, two from how a foe fights.");
    var _ids = itl_charges(), _cell = 180, _cols = 5, _x0 = (_w - _cols * _cell) / 2, _y0 = 140;
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _cx = _x0 + (_i mod _cols) * _cell + _cell / 2, _cy = _y0 + (_i div _cols) * (_cell + 40) + _cell / 2;
        itl_ellipse(_cx, _cy, _cell * 0.42, _cell * 0.42, 0, make_colour_rgb(233, 220, 184));
        itl_polyline(itl_ellipse_ring(_cx, _cy, _cell * 0.42, _cell * 0.42, 0, 72), 3, make_colour_rgb(59, 42, 26), 1, true);
        itl_draw_charge(_ids[_i], _cx, _cy, _cell * 0.3, make_colour_rgb(59, 42, 26));
        itl_text(_cx, _cy + _cell * 0.5 + 4, _ids[_i], 22, make_colour_rgb(210, 198, 176), fa_center, fa_top, fnt_intertitle);
    }
}

/// @function itl_bake_hero(w, h, data)
/// @description The demo backdrop with one card where the banner puts it. data = {spr, boss, cw, ch}.
function itl_bake_hero(_w, _h, _d) {
    itl_demo_backdrop(_w, _h, 0);
    if (_d.boss) { itl_rect(0, 0, _w, _h, c_black, 0.45); draw_sprite(_d.spr, 0, (_w - _d.cw) / 2, (_h - _d.ch) / 2); }
    else draw_sprite(_d.spr, 0, (_w - _d.cw) / 2, _h * 0.06);
}

/// @function itl_bake_run()
/// @description Every sheet, then itl_bake.json listing what was written and how white each card sprite is (a white
/// card is a sprite with no texture: the defect this file was restructured for).
function itl_bake_run() {
    var _done = [], _white = [], _i;
    var _pl = itl_demo_places(), _bs = itl_demo_bosses(), _pp = [], _bp = [];
    for (_i = 0; _i < array_length(_pl); _i++) array_push(_pp, itl_place_card(_pl[_i]));
    for (_i = 0; _i < array_length(_bs); _i++) array_push(_bp, itl_boss_card(_bs[_i]));
    var _sp = itl_bake_sprites(_pp, 760, 146), _sb = itl_bake_sprites(_bp, 1100, 250);
    for (_i = 0; _i < array_length(_sp); _i++) array_push(_white, itl_bake_white(_sp[_i]));
    array_push(_done, itl_bake_sheet("places", 1600, 1130, itl_bake_places, _sp));
    array_push(_done, itl_bake_sheet("bosses", 1600, 960, itl_bake_bosses, _sb));
    array_push(_done, itl_bake_sheet("devices", 1600, 820, itl_bake_devices, undefined));
    var _hp = itl_card_sprite(_pp[3], 992, 191, 2), _hb = itl_card_sprite(_bp[0], 992, 225, 2);
    array_push(_done, itl_bake_sheet("hero_place", 1600, 900, itl_bake_hero, { spr: _hp, boss: false, cw: 992, ch: 191 }));
    array_push(_done, itl_bake_sheet("hero_boss", 1600, 900, itl_bake_hero, { spr: _hb, boss: true, cw: 992, ch: 225 }));
    // one place at danger 0..3, then its return; one name in all five constructions
    var _src = variable_clone(_pl[3]), _states = [];
    for (_i = 0; _i < 4; _i++) { _src.danger = _i; array_push(_states, itl_place_card(_src)); }
    _src.first_visit = false; array_push(_states, itl_place_card(_src));
    var _five = [], _tr = itl_treatments();
    for (_i = 0; _i < 5; _i++) array_push(_five, itl_place_card({ name: "The Sunken Stair", parent: "Saltmarsh Wharf", treatment: _tr[_i], elements: { Water: 4 }, sub_places: 2, danger: 1 }));
    var _ss = itl_bake_sprites(_states, 1000, 160), _sf5 = itl_bake_sprites(_five, 1000, 160);
    array_push(_done, itl_bake_sheet("states", 1600, 1000, itl_bake_states, _ss));
    array_push(_done, itl_bake_sheet("five", 1600, 1000, itl_bake_five, _sf5));
    array_push(_done, itl_bake_cover());
    itl_bake_free(_sp); itl_bake_free(_sb); itl_bake_free([_hp, _hb]); itl_bake_free(_ss); itl_bake_free(_sf5);
    var _f = file_text_open_write("itl_bake.json");
    file_text_write_string(_f, json_stringify({ stage: 99, sheets: _done, white_fraction_per_place_card: _white }));
    file_text_close(_f);
}

/// @function itl_bake_white(sprite)
/// @description The fraction of a sprite's pixels that are pure opaque white.
function itl_bake_white(_spr) {
    if (is_undefined(_spr) || !sprite_exists(_spr)) return -1;
    var _w = sprite_get_width(_spr), _h = sprite_get_height(_spr), _sf = surface_create(_w, _h);
    surface_set_target(_sf); draw_clear_alpha(c_black, 0); gpu_set_blendenable(false); draw_sprite(_spr, 0, 0, 0); gpu_set_blendenable(true); surface_reset_target();
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1), _n = 0, _t = _w * _h;
    buffer_get_surface(_b, _sf, 0);
    surface_free(_sf);
    for (var _o = 0; _o < _t * 4; _o += 4) if (buffer_peek(_b, _o, buffer_u8) > 250 && buffer_peek(_b, _o + 1, buffer_u8) > 250 && buffer_peek(_b, _o + 2, buffer_u8) > 250 && buffer_peek(_b, _o + 3, buffer_u8) > 250) _n++;
    buffer_delete(_b);
    return _n / max(1, _t);
}

/// @function itl_bake_states(w, h, sprites)
/// @description One place at every danger band, then the same place on a return - five cards, five pictures.
function itl_bake_states(_w, _h, _spr) {
    itl_bake_head(_w, "DANGER YOU CAN SEE, AND A RETURN THAT IS NOT A FIRST VISIT", "The rule changes colour AND shape: pointed caps when it is dangerous, a doubled rule and a red roundel when it is lethal. Walking back in gets a plainer card.");
    // words, not figures: this face's old-style "1" read as a capital I on the first bake
    var _labels = ["calm", "uneasy", "dangerous - pointed caps", "lethal - doubled rule, red roundel", "a return - no epithet, no marks, a smaller name"];
    var _cw = 1000, _ch = 160, _x0 = 80;
    for (var _i = 0; _i < array_length(_spr); _i++) {
        var _y = 130 + _i * (_ch + 12);
        if (!is_undefined(_spr[_i])) draw_sprite(_spr[_i], 0, _x0, _y);
        itl_text(_x0 + _cw + 30, _y + _ch / 2 - 14, _labels[_i], 24, make_colour_rgb(214, 204, 182), fa_left, fa_top, fnt_intertitle);
    }
}

/// @function itl_bake_cover_draw(w, h, d)
/// @description The store COVER, 630 x 500, drawn by the product: its own scene, a place card at the top as a game shows
/// it, the product's name set as a card of its own, and a boss seal below. d = {top, name, seal} sprites.
function itl_bake_cover_draw(_w, _h, _d) {
    itl_demo_backdrop(_w, _h, 0);
    draw_sprite(_d.top, 0, (_w - sprite_get_width(_d.top)) / 2, 18);
    draw_sprite(_d.name, 0, (_w - sprite_get_width(_d.name)) / 2, 150);
    itl_rect(0, 318, _w, _h - 318, c_black, 0.35);
    draw_sprite(_d.seal, 0, (_w - sprite_get_width(_d.seal)) / 2, 330);
    itl_text(_w / 2, 462, "FOR GAMEMAKER  -  every card drawn in pure GML", 17, make_colour_rgb(232, 214, 170), fa_center, fa_top, fnt_intertitle);
}

/// @function itl_bake_cover()
function itl_bake_cover() {
    var _pl = itl_demo_places();
    var _top = itl_card_sprite(itl_place_card(_pl[3]), 560, 108, 2);
    var _name = itl_card_sprite(itl_place_card({ name: "Intertitle", treatment: "lacquer", charge: "key", epithet: "a card for every place and every boss", sub_places: 3, danger: 1 }), 600, 150, 2);
    var _seal = itl_card_sprite(itl_boss_card(itl_demo_bosses()[1]), 560, 124, 2);
    itl_bake_sheet("cover", 630, 500, itl_bake_cover_draw, { top: _top, name: _name, seal: _seal });
    itl_bake_free([_top, _name, _seal]);
    return "cover";
}

/// @function itl_bake_gif()
/// @description `-gif`: 800 x 450 frames of the demo scene with the banner running - a place card rising in and
/// holding, then a boss seal growing in over the dimmed scene - saved as itl_gif_0000.png ... for the store GIF. Every
/// sprite is baked by itl_banner_step, as in a game, never inside the frame's target.
function itl_bake_gif() {
    var _w = 800, _h = 450, _bn = itl_banner_create({ hold: 50, boss_hold: 60, rise: 18, fade: 14 });
    var _pl = itl_demo_places(), _bs = itl_demo_bosses(), _n = 0;
    itl_banner_show(_bn, itl_place_card(_pl[2]));
    itl_banner_show(_bn, itl_place_card(_pl[4]));
    var _boss_at = 150;
    _bn.gw = _w; _bn.gh = _h;
    for (var _f = 0; _f < 250; _f++) {
        if (_f == _boss_at) itl_banner_show(_bn, itl_boss_card(_bs[0]));
        itl_banner_step(_bn);
        if (_f mod 2 == 1) continue;   // 125 frames at 25 fps: every other step
        var _sf = surface_create(_w, _h);
        surface_set_target(_sf);
        draw_clear(c_black);
        // ⛔ separate alpha, as every sheet does: under the default blend the boss's dimming wash (and every fading
        // card) also LOWERED the frame's own alpha, and the saved frame came out washed pale instead of dimmed
        gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
        itl_demo_backdrop(_w, _h, _f);
        itl_banner_draw(_bn, _w, _h);
        gpu_set_blendmode(bm_normal);
        surface_reset_target();
        surface_save(_sf, "itl_gif_" + itl_bake_pad4(_n) + ".png");
        surface_free(_sf);
        _n++;
    }
    itl_banner_free(_bn);
    var _j = file_text_open_write("itl_gif.json");
    file_text_write_string(_j, json_stringify({ stage: 99, frames: _n }));
    file_text_close(_j);
}

/// @function itl_bake_pad4(n)
/// @description n as four digits, by arithmetic (never by replacing spaces in a formatted string).
function itl_bake_pad4(_n) { return string(_n div 1000) + string((_n div 100) mod 10) + string((_n div 10) mod 10) + string(_n mod 10); }

/// @function itl_bake_five(w, h, sprites)
/// @description One name in all five constructions: the construction is STRUCTURE, not colour.
function itl_bake_five(_w, _h, _spr) {
    itl_bake_head(_w, "ONE NAME, FIVE CONSTRUCTIONS", "The words that describe a place choose how its card is built: a map cartouche, a woodcut board, a gilt lacquer panel, a stone lintel, a riveted plate.");
    var _labels = ["cartouche - overworld, realm, kingdom", "woodcut - field, forest, town, road", "lacquer - inside, castle, inn, chapel", "stone - dungeon, cave, crypt, mine", "plate - sci-fi, station, ship, lab"];
    var _cw = 1000, _ch = 160, _x0 = 80;
    for (var _i = 0; _i < array_length(_spr); _i++) {
        var _y = 130 + _i * (_ch + 12);
        if (!is_undefined(_spr[_i])) draw_sprite(_spr[_i], 0, _x0, _y);
        itl_text(_x0 + _cw + 30, _y + _ch / 2 - 14, _labels[_i], 24, make_colour_rgb(214, 204, 182), fa_left, fa_top, fnt_intertitle);
    }
}
