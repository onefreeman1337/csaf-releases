/// itl_demo.gml - the demo room's sample world: twelve places and three bosses described the way your own game would
/// describe them, and the demo's own backdrop and key help. Not needed at runtime: delete it with the demo object.
///
/// Intertitle - Title Cards for Every Place and Every Boss, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function itl_demo_places()
/// @description Twelve place structs, as a game would pass them to itl_place_card(). Every card below is DERIVED from
/// these facts: nothing names a construction or a device.
function itl_demo_places() {
    return [
        { name: "The Western Reach", setting: "Overworld", depth: 0, sub_places: 4, elements: { Wind: 5 }, danger: 1 },
        { name: "Greyfell", setting: "Forest Road", parent: "The Western Reach", depth: 1, sub_places: 2, danger: 0 },
        { name: "The Old Mine", setting: "Dungeon", parent: "Greyfell", depth: 2, sub_places: 1, elements: { Earth: 4, Physical: 9 }, danger: 2 },
        { name: "Ashen Crypt", setting: "Dungeon", parent: "The Old Mine", depth: 3, elements: { Darkness: 6 }, danger: 3 },
        { name: "The Gilded Tankard", setting: "Inside", parent: "Greyfell", depth: 2, danger: 0 },
        { name: "Frostmere", setting: "Field", parent: "The Western Reach", depth: 1, sub_places: 1, elements: { Ice: 7 }, danger: 1 },
        { name: "Chapel of the Dawn", setting: "Temple", parent: "Frostmere", depth: 2, elements: { Holy: 3 }, danger: 0 },
        { name: "Saltmarsh Wharf", setting: "Coast", parent: "The Western Reach", depth: 1, sub_places: 1, elements: { Water: 5 }, danger: 1 },
        { name: "The Sunken Stair", setting: "Cave", parent: "Saltmarsh Wharf", depth: 2, elements: { Water: 4, Thunder: 1 }, danger: 2 },
        { name: "Orbital Ring", setting: "SF Outside", depth: 0, sub_places: 1, elements: { Light: 2 }, danger: 1 },
        { name: "Relay Station Kestrel", setting: "SF Inside", parent: "Orbital Ring", depth: 1, elements: { Lightning: 6 }, danger: 3 },
        { name: "Emberfold Pass", setting: "Mountain Pass", parent: "The Western Reach", depth: 1, elements: { Hellfire: 8 }, danger: 3 }
    ];
}

/// @function itl_demo_bosses()
/// @description Three boss structs, as a battle system would pass them to itl_boss_card().
function itl_demo_bosses() {
    var _hp = [120, 180, 260, 400, 650, 900, 1400, 2200, 3600, 5200];
    return [
        { name: "The Ember Warden", attack: ["Physical", "Fire"], resist: { Fire: 0.2, Water: 2 }, hp: 5200, all_hp: _hp },
        { name: "Mother of Rime", skills: ["Ice", "Ice", "Wind"], resist: { Ice: 0, Fire: 1.5 }, hp: 3600, all_hp: _hp },
        { name: "The_Pale_Abbot", attack: ["Physical"], skills: ["Darkness", "Darkness", "Holy"], resist: { Holy: 2 }, hp: 900, all_hp: _hp }
    ];
}

/// @function itl_demo_state()
/// @description The demo's state: the banner, the sample world, where the walk has reached, and the last card's facts.
function itl_demo_state() {
    return { banner: itl_banner_create(), places: itl_demo_places(), bosses: itl_demo_bosses(), place_index: -1, boss_index: -1,
        visited: {}, last: undefined, facts: "", tick: 0, bg: undefined, bg_w: 0, bg_h: 0 };
}

/// @function itl_demo_facts(profile)
/// @description One line saying what a card was built from - the demo's own caption.
function itl_demo_facts(_p) {
    if (!is_struct(_p)) return "";
    if (_p.kind == "boss") return _p.name + ": seal, device " + _p.charge + ", weakness " + (is_undefined(_p.weakness) ? "none" : _p.weakness) + ", rank tier " + string(_p.tier);
    return _p.name + ": " + _p.treatment + ", device " + _p.charge + ", danger " + string(_p.danger) + (_p.first_visit ? ", first visit" : ", a return");
}

/// @function itl_demo_arrive(demo, place_struct)
/// @description Arrive at a place: build its card (a RETURN when it has been visited before) and show it.
function itl_demo_arrive(_d, _src) {
    var _first = !variable_struct_exists(_d.visited, _src.name);
    _d.visited[$ _src.name] = true;
    var _q = variable_clone(_src);
    _q.first_visit = _first;
    var _p = itl_place_card(_q);
    if (is_undefined(_p)) return;
    _d.last = _src;
    itl_banner_show(_d.banner, _p);
    _d.facts = itl_demo_facts(_p);
}

/// @function itl_demo_next_place(demo)
function itl_demo_next_place(_d) { _d.place_index = (_d.place_index + 1) mod array_length(_d.places); itl_demo_arrive(_d, _d.places[_d.place_index]); }

/// @function itl_demo_return(demo)
/// @description Go back to the place just left - it has been visited, so its card is the plainer return.
function itl_demo_return(_d) { if (is_struct(_d.last)) itl_demo_arrive(_d, _d.last); }

/// @function itl_demo_danger(demo)
/// @description Raise the current place's danger one band (wrapping) and show its card again.
function itl_demo_danger(_d) {
    if (!is_struct(_d.last)) return;
    _d.last.danger = ((variable_struct_exists(_d.last, "danger") ? _d.last.danger : 0) + 1) mod 4;
    variable_struct_remove(_d.visited, _d.last.name);
    itl_demo_arrive(_d, _d.last);
}

/// @function itl_demo_next_boss(demo)
function itl_demo_next_boss(_d) {
    _d.boss_index = (_d.boss_index + 1) mod array_length(_d.bosses);
    var _p = itl_boss_card(_d.bosses[_d.boss_index]);
    if (is_undefined(_p)) return;
    itl_banner_show(_d.banner, _p);
    _d.facts = itl_demo_facts(_p);
}

/// @function itl_demo_backdrop(w, h, t)
/// @description The demo room's scene, standing in for YOUR game's screen: a dusk sky, a low moon, five ridges of hills
/// fading into haze, a road winding toward them, and a slow drift of dust. Drawn from noise, the same every time.
function itl_demo_backdrop(_w, _h, _t) {
    itl_rect_grad(0, 0, _w, _h, 0, 0, 0, _h, [[0, make_colour_rgb(22, 28, 46), 1], [0.55, make_colour_rgb(64, 60, 78), 1], [1, make_colour_rgb(24, 22, 28), 1]]);
    itl_radial_rect(0, 0, _w, _h * 0.7, _w * 0.72, _h * 0.42, _h * 0.02, _h * 0.55, make_colour_rgb(236, 200, 150), 0.30, 0);
    itl_ellipse(_w * 0.72, _h * 0.36, _h * 0.05, _h * 0.05, 0, make_colour_rgb(240, 226, 196), 0.95);
    var _cols = [[92, 88, 108], [70, 66, 86], [52, 48, 64], [36, 33, 44], [22, 20, 26]];
    for (var _l = 0; _l < 5; _l++) {
        var _base = _h * (0.52 + _l * 0.085), _amp = _h * (0.10 - _l * 0.012), _ring = [[0, _h]], _step = max(4, _w / 160);
        for (var _x = 0; _x <= _w + _step; _x += _step) array_push(_ring, [min(_x, _w), _base - _amp * itl_fbm(_x / (_w * (0.22 - _l * 0.025)), _l * 3.1, 41 + _l, 4)]);
        array_push(_ring, [_w, _h]);
        itl_fill_rings([_ring], itl_col(_cols[_l]), 1, undefined, ITL_FILL_NONZERO);
    }
    var _road = [];   // a road winding from the foreground toward the hills
    for (var _k = 0; _k <= 24; _k++) {
        var _s = _k / 24, _ry = _h * (1.02 - _s * 0.36), _rx = _w * (0.40 + 0.10 * sin(_s * 5.2) * (1 - _s * 0.6)), _hw = _w * 0.06 * (1 - _s) + 1;
        array_push(_road, [_rx - _hw, _ry]);
        array_insert(_road, 0, [_rx + _hw, _ry]);
    }
    itl_fill_rings([_road], make_colour_rgb(58, 52, 60), 1, undefined, ITL_FILL_NONZERO);
    itl_radial_rect(0, 0, _w, _h, _w / 2, _h * 0.45, _h * 0.35, _h * 0.95, c_black, 0, 0.5);
    if (is_numeric(_t)) itl_demo_dust(_w, _h, _t);
}

/// @function itl_demo_scene_sprite(w, h)
/// @description The scene without its dust, baked once into a sprite (call from Step or Create; it is yours to delete).
function itl_demo_scene_sprite(_w, _h) {
    var _sf = surface_create(_w, _h);
    surface_set_target(_sf); draw_clear(c_black); itl_demo_backdrop(_w, _h, undefined); surface_reset_target();
    var _s = sprite_create_from_surface(_sf, 0, 0, _w, _h, false, false, 0, 0);
    surface_free(_sf);
    return _s;
}

/// @function itl_demo_dust(w, h, t)
/// @description A slow drift of dust over the scene - the only part of the backdrop that moves.
function itl_demo_dust(_w, _h, _t) {
    for (var _i = 0; _i < 40; _i++) {
        var _r = itl_rng(_i * 7919 + 17), _dx = itl_rng_next(_r) * _w, _dy = (itl_rng_next(_r) * _h + _t * (0.1 + itl_rng_next(_r) * 0.2)) mod _h;
        itl_ellipse(_dx, _dy, 1.2, 1.2, 0, make_colour_rgb(200, 190, 160), 0.12 + itl_rng_next(_r) * 0.15);
    }
}

/// @function itl_demo_help(w, h, lines)
/// @description The demo's key help and the last card's facts, bottom left.
function itl_demo_help(_w, _h, _lines) {
    var _y = _h - 24 - array_length(_lines) * 22;
    for (var _i = 0; _i < array_length(_lines); _i++) itl_text(24, _y + _i * 22, _lines[_i], 17, make_colour_rgb(205, 196, 176), fa_left, fa_top, fnt_intertitle_ui, 0.9);
}
