/// itl_read.gml - the reader. Turns a PLACE or a BOSS, described by the plain facts your game already keeps, into the
/// card it announces itself with: which construction, which device, what the line beneath the name says, and the
/// marks for danger, depth and rank. Nothing here draws and nothing here is random: every field is DERIVED from what
/// you pass, and every derivation can be overruled by a field of your own.
///
/// Intertitle - Title Cards for Every Place and Every Boss, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// PUBLIC
///   itl_place_card(place)            -> a place profile, or undefined when there is no name to announce
///   itl_boss_card(boss)              -> a boss profile (a seal)
///   itl_treatment_for(setting)       -> one of the five constructions, from the words that describe a place
///   itl_charge_for_element(name)     -> a device id from an element's NAME, or undefined
///   itl_dominant_charge(counts)      -> the device for the element a place's foes strike with most
///   itl_boss_rank(hp, all_hp)        -> 0..1, where a foe stands among ALL of your foes by max HP
///   itl_treatments() / itl_charges() -> the ids, in a stable order
///
/// Words are matched as whole WORDS, case-blind. A word written "*fire" also matches any word ENDING in fire
/// ("Hellfire", "Wildfire"); "burn*" matches any word STARTING with burn. ⛔ Only long stems take a wildcard: "*ice"
/// would read "Malice" and "Justice" as frost (the suite pins that phantom).

/// @function itl_treatments()
/// @description The five card constructions, in a stable order. They differ in how the card is BUILT, not in colour.
function itl_treatments() { static _t = ["cartouche", "woodcut", "lacquer", "stone", "plate"]; return _t; }

/// @function itl_charges()
/// @description Every device the painter draws, in a stable order. An override outside this list is IGNORED.
function itl_charges() {
    static _c = ["flame", "crystal", "bolt", "wave", "stone", "gust", "sun", "moon", "compass", "tree", "key", "arch", "cog", "blade", "rune"];
    return _c;
}

/// @function itl__words(text)
/// @description The lower-case words of a string (letters and digits; a hyphen JOINS, so "Sci-Fi" is "scifi"). Internal.
function itl__words(_text) {
    var _s = string_lower(string(_text)), _out = [], _cur = "";
    for (var _i = 1; _i <= string_length(_s); _i++) {
        var _ch = string_char_at(_s, _i);
        if (_ch == "-") continue;
        var _o = ord(_ch);
        if ((_o >= 97 && _o <= 122) || (_o >= 48 && _o <= 57)) _cur += _ch;
        else if (_cur != "") { array_push(_out, _cur); _cur = ""; }
    }
    if (_cur != "") array_push(_out, _cur);
    return _out;
}

/// @function itl__word_hits(words, pattern)
/// @description True when any word matches one pattern: "x" exact, "*x" ends with x, "x*" starts with x. Internal.
function itl__word_hits(_words, _pat) {
    var _n = string_length(_pat), _pre = (string_char_at(_pat, 1) == "*"), _post = (string_char_at(_pat, _n) == "*");
    var _core = string_copy(_pat, _pre ? 2 : 1, _n - (_pre ? 1 : 0) - (_post ? 1 : 0));
    var _cl = string_length(_core);
    for (var _i = 0; _i < array_length(_words); _i++) {
        var _w = _words[_i], _wl = string_length(_w);
        if (_pre && _post) { if (string_pos(_core, _w) > 0) return true; }
        else if (_pre) { if (_wl >= _cl && string_copy(_w, _wl - _cl + 1, _cl) == _core) return true; }
        else if (_post) { if (_wl >= _cl && string_copy(_w, 1, _cl) == _core) return true; }
        else if (_w == _core) return true;
    }
    return false;
}

/// @function itl__any(words, patterns)
/// @description True when any pattern hits any word. Internal.
function itl__any(_words, _pats) {
    for (var _i = 0; _i < array_length(_pats); _i++) if (itl__word_hits(_words, _pats[_i])) return true;
    return false;
}

/// @function itl__treatment_words()
/// @description The construction a place's words choose, tested IN THIS ORDER: "SF" is a plate before "Inside" is a
/// lacquer panel. Internal.
function itl__treatment_words() {
    static _t = [
        ["plate", ["sf", "scifi", "space", "station", "starship", "ship", "lab", "laboratory", "reactor", "tech", "orbital", "spaceship"]],
        ["stone", ["dungeon", "cave", "cavern", "crypt", "tomb", "mine", "ruin", "ruins", "catacomb", "catacombs", "sewer", "sewers", "vault", "depths", "underground", "labyrinth"]],
        ["lacquer", ["inside", "interior", "indoor", "indoors", "house", "home", "castle", "palace", "shop", "inn", "tavern", "temple", "church", "hall", "manor", "chapel", "keep"]],
        ["cartouche", ["overworld", "world", "worldmap", "continent", "realm", "atlas", "kingdom"]],
        ["woodcut", ["outside", "outdoor", "outdoors", "field", "forest", "town", "village", "road", "plain", "plains", "coast", "mountain", "swamp", "desert", "wood", "woods", "harbour", "harbor", "pass"]]
    ];
    return _t;
}

/// @function itl__element_words()
/// @description Element-name words per device. Keyed on the NAME you gave the element, never an index. Internal.
function itl__element_words() {
    static _e = [
        ["flame", ["*fire", "*flame", "*blaze", "burn*", "heat", "inferno", "magma", "lava", "ember", "embers"]],
        ["crystal", ["ice", "frost", "cold", "snow", "freez*", "glacier", "*frost", "rime"]],
        ["bolt", ["thunder*", "lightning", "electric*", "shock", "volt", "*storm"]],
        ["wave", ["water", "aqua", "sea", "tide", "ocean", "rain", "hydro"]],
        ["stone", ["earth", "stone", "rock", "ground", "terra", "quake", "sand"]],
        ["gust", ["wind", "air", "gale", "sky", "aero"]],
        ["sun", ["light", "holy", "sun", "radian*", "divine", "sacred"]],
        ["moon", ["dark*", "void", "curse", "night", "umbra", "death", "*shadow"]]
    ];
    return _e;
}

/// @function itl_treatment_for(setting)
/// @description One of itl_treatments() for the words that describe a place ("dungeon", "SF Inside", "Forest Road").
/// Nothing recognised -> "woodcut" (an outdoor board). Pure.
function itl_treatment_for(_setting) {
    var _w = itl__words(_setting), _t = itl__treatment_words();
    for (var _i = 0; _i < array_length(_t); _i++) if (itl__any(_w, _t[_i][1])) return _t[_i][0];
    return "woodcut";
}

/// @function itl_charge_for_element(name)
/// @description The device an element's NAME calls for ("Hellfire" -> "flame"), or undefined for a name that carries
/// none ("Physical", "Malice"). Pure.
function itl_charge_for_element(_name) {
    if (!is_string(_name)) return undefined;
    var _w = itl__words(_name), _e = itl__element_words();
    for (var _i = 0; _i < array_length(_e); _i++) if (itl__any(_w, _e[_i][1])) return _e[_i][0];
    return undefined;
}

/// @function itl_dominant_charge(counts)
/// @description The device for the element a place's foes strike with MOST. `counts` is a struct {element name:
/// count}; names that carry no device are ignored; ties go to the name first in alphabetical order. undefined when
/// nothing qualifies. Pure.
function itl_dominant_charge(_counts) {
    if (!is_struct(_counts)) return undefined;
    var _names = variable_struct_get_names(_counts);
    array_sort(_names, true);
    var _best = undefined, _bn = 0;
    for (var _i = 0; _i < array_length(_names); _i++) {
        var _ch = itl_charge_for_element(_names[_i]), _v = _counts[$ _names[_i]];
        var _n = is_numeric(_v) ? _v : 0;
        if (!is_undefined(_ch) && _n > _bn) { _best = _ch; _bn = _n; }
    }
    return _best;
}

/// @function itl__field(struct, name, default)
/// @description struct.name when it exists and is not undefined, else the default. Internal.
function itl__field(_s, _k, _d) {
    if (!is_struct(_s) || !variable_struct_exists(_s, _k)) return _d;
    var _v = _s[$ _k];
    return is_undefined(_v) ? _d : _v;
}

/// @function itl__int(value, lo, hi)
/// @description A whole number clamped to lo..hi; anything that is not a number is lo. Internal.
function itl__int(_v, _lo, _hi) {
    if (!is_numeric(_v) || is_nan(_v) || is_infinity(_v)) return _lo;
    return clamp(floor(_v), _lo, _hi);
}

/// @function itl__valid_charge(value)
/// @description `value` when it names a device, else undefined. Internal.
function itl__valid_charge(_v) {
    if (!is_string(_v)) return undefined;
    var _l = string_lower(_v);
    return (array_get_index(itl_charges(), _l) >= 0) ? _l : undefined;
}

/// @function itl__treatment_charge(t)
/// @description Each construction's own device, for a place whose foes carry no element. Internal.
function itl__treatment_charge(_t) {
    switch (_t) { case "cartouche": return "compass"; case "lacquer": return "key"; case "stone": return "arch"; case "plate": return "cog"; }
    return "tree";
}

/// @function itl__preposition(t)
/// @description How a place hangs from its parent, per construction - the epithet's first word. Internal.
function itl__preposition(_t) {
    switch (_t) { case "cartouche": return "of"; case "lacquer": return "in"; case "stone": return "beneath"; case "plate": return "aboard"; }
    return "near";
}

/// @function itl_place_card(place)
/// @description A place's card profile. `place` is a struct of what your game already knows:
///   name        string, REQUIRED - no name, no card (undefined), exactly as a map with no display name gets none
///   setting     words describing it - "dungeon", "town", "SF Inside" - chooses the construction
///   parent      the place it sits in - "beneath Greyfell" (the word depends on the construction)
///   elements    {element name: count} for what its foes strike with - chooses the device
///   depth       0 a region, 1 a place in it, 2+ deeper
///   sub_places  how many places sit inside it (0..5 lozenges on the rule)
///   first_visit true the first time (full card), false on a return (a plainer, shorter card)
///   danger      0 calm .. 3 lethal - the rule's colour AND shape, and a red roundel at 3
/// Overrides, any of which wins: treatment, charge, epithet ("" for none).
/// Returns {kind: "place", name, epithet, treatment, charge, division, count_mark, first_visit, danger, key}. Pure.
function itl_place_card(_p) {
    if (!is_struct(_p)) return undefined;
    var _name = itl__field(_p, "name", "");
    if (!is_string(_name)) _name = string(_name);
    _name = string_trim(_name);
    if (_name == "") return undefined;
    var _tr = itl__field(_p, "treatment", undefined);
    var _t = (is_string(_tr) && array_get_index(itl_treatments(), string_lower(_tr)) >= 0) ? string_lower(_tr) : itl_treatment_for(itl__field(_p, "setting", ""));
    var _ch = itl__valid_charge(itl__field(_p, "charge", undefined));
    if (is_undefined(_ch)) _ch = itl_dominant_charge(itl__field(_p, "elements", undefined));
    if (is_undefined(_ch)) _ch = itl__treatment_charge(_t);
    var _parent = itl__field(_p, "parent", "");
    _parent = is_string(_parent) ? string_trim(_parent) : "";
    var _eo = itl__field(_p, "epithet", undefined);
    var _ep = is_string(_eo) ? _eo : ((_parent != "" && _parent != _name) ? itl__preposition(_t) + " " + _parent : "");
    var _depth = itl__int(itl__field(_p, "depth", 0), 0, 9);
    var _fv = itl__field(_p, "first_visit", true);
    var _prof = {
        kind: "place", name: _name, epithet: _ep, treatment: _t, charge: _ch,
        division: (_depth == 0) ? "plain" : ((_depth == 1) ? "party" : "quarter"),
        count_mark: itl__int(itl__field(_p, "sub_places", 0), 0, 5),
        first_visit: !(is_bool(_fv) && !_fv) && !(is_numeric(_fv) && _fv == 0),
        danger: itl__int(itl__field(_p, "danger", 0), 0, 3),
        tier: 0, weakness: undefined
    };
    _prof.key = "place:" + _t + ":" + _ch + ":" + _prof.division + ":" + string(_prof.count_mark) + ":" + (_prof.first_visit ? "1" : "0")
        + ":" + string(_prof.danger) + ":" + string(itl_hash(_name + "|" + _ep));
    return _prof;
}

/// @function itl_boss_rank(hp, all_hp)
/// @description Where a foe stands among ALL of your foes by max HP, 0 (the weakest) .. 1 (the strongest). Measured
/// against your own list, never a shipped table. A missing list or a list of one returns 1. Pure.
function itl_boss_rank(_hp, _all) {
    if (!is_numeric(_hp) || !is_array(_all)) return 1;
    var _n = 0, _below = 0;
    for (var _i = 0; _i < array_length(_all); _i++) {
        if (!is_numeric(_all[_i])) continue;
        _n++;
        if (_all[_i] < _hp) _below++;
    }
    return (_n > 1) ? _below / (_n - 1) : 1;
}

/// @function itl__boss_epithet(charge)
/// @description A boss's line beneath its name, from its device. Internal.
function itl__boss_epithet(_c) {
    switch (_c) {
        case "flame": return "Who Burns"; case "crystal": return "Who Does Not Thaw"; case "bolt": return "Of the Storm";
        case "wave": return "From the Deep"; case "stone": return "Of the Old Stone"; case "gust": return "On the Wind";
        case "sun": return "Of the High Light"; case "moon": return "Of the Long Night"; case "blade": return "Of the Blade";
        case "rune": return "Of the Spoken Word";
    }
    return "";
}

/// @function itl_boss_card(boss)
/// @description A boss's card: a SEAL. `boss` is a struct of what your battle system already knows:
///   name      string, REQUIRED ("The_Ember_Warden" reads as "The Ember Warden")
///   attack    array of element NAMES it strikes with (the first that carries a device wins)
///   skills    array of element NAMES its skills use (the most used wins, when attack gives none)
///   resist    {element name: damage rate} - its strongest resistance (rate below 1) is the next voice, and its
///             greatest WEAKNESS (rate above 1) is drawn as a fault line across the seal
///   rank      0..1 where it stands among your foes (itl_boss_rank), or hp + all_hp to have it measured here
///   atk, mat  with no element anywhere: the blade if it leans on attack, the rune if on magic
/// Overrides: charge, epithet. Returns {kind: "boss", name, epithet, treatment: "seal", charge, weakness, tier, key}. Pure.
function itl_boss_card(_b) {
    if (!is_struct(_b)) return undefined;
    var _name = itl__field(_b, "name", "");
    if (!is_string(_name)) _name = string(_name);
    _name = string_trim(string_replace_all(_name, "_", " "));
    if (_name == "") return undefined;
    var _ch = itl__valid_charge(itl__field(_b, "charge", undefined)), _i;
    var _att = itl__field(_b, "attack", []);
    if (is_array(_att)) for (_i = 0; is_undefined(_ch) && _i < array_length(_att); _i++) _ch = itl_charge_for_element(_att[_i]);
    var _sk = itl__field(_b, "skills", []);
    if (is_undefined(_ch) && is_array(_sk)) {
        var _tally = {};
        for (_i = 0; _i < array_length(_sk); _i++) {
            var _c = itl_charge_for_element(_sk[_i]);
            if (!is_undefined(_c)) _tally[$ _c] = (variable_struct_exists(_tally, _c) ? _tally[$ _c] : 0) + 1;
        }
        var _keys = variable_struct_get_names(_tally), _bn = 0;
        array_sort(_keys, true);
        for (_i = 0; _i < array_length(_keys); _i++) if (_tally[$ _keys[_i]] > _bn) { _bn = _tally[$ _keys[_i]]; _ch = _keys[_i]; }
    }
    var _res = itl__field(_b, "resist", undefined), _weak = undefined;
    if (is_struct(_res)) {
        var _rn = variable_struct_get_names(_res), _low = 1, _wr = 1;
        array_sort(_rn, true);
        for (_i = 0; _i < array_length(_rn); _i++) {
            var _rate = _res[$ _rn[_i]], _rc = itl_charge_for_element(_rn[_i]);
            if (!is_numeric(_rate) || is_undefined(_rc)) continue;
            if (is_undefined(_ch) && _rate < _low) { _low = _rate; _ch = _rc; }
            if (_rate > _wr) { _wr = _rate; _weak = _rc; }
        }
    }
    if (is_undefined(_ch)) {
        var _atk = itl__field(_b, "atk", 0), _mat = itl__field(_b, "mat", 0);
        _ch = (is_numeric(_mat) && is_numeric(_atk) && _mat > _atk) ? "rune" : "blade";
    }
    var _rank = itl__field(_b, "rank", undefined);
    if (!is_numeric(_rank)) _rank = itl_boss_rank(itl__field(_b, "hp", undefined), itl__field(_b, "all_hp", undefined));
    _rank = clamp(_rank, 0, 1);
    var _eo = itl__field(_b, "epithet", undefined);
    var _prof = {
        kind: "boss", name: _name, epithet: is_string(_eo) ? _eo : itl__boss_epithet(_ch), treatment: "seal", charge: _ch,
        weakness: _weak, tier: (_rank >= 0.9) ? 3 : ((_rank >= 0.66) ? 2 : ((_rank >= 0.33) ? 1 : 0)),
        division: "plain", count_mark: 0, first_visit: true, danger: 0
    };
    _prof.key = "boss:" + _ch + ":" + (is_undefined(_weak) ? "-" : _weak) + ":" + string(_prof.tier) + ":" + string(itl_hash(_name));
    return _prof;
}
