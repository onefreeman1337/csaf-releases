/// itl_selftest.gml - the in-engine suite (`Intertitle.exe -selftest` writes itl_selftest.json). Stage 99 = the suite
/// reached its end. Not needed at runtime: delete it with the -selftest branch of the demo object's Create event.
///
/// Intertitle - Title Cards for Every Place and Every Boss, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
/// ⛔ Every picture claim is asserted as INK - pixels counted on a rendered surface - never as "a sprite exists": a
/// function handed the wrong type returns a live, correctly sized, EMPTY sprite. Every ink assertion has a control.

function itl_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 80) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
function itl_st_stage(_st, _n) { _st.stage = _n; global.itl_stage = _n; }
function itl_st_note(_st, _s) { array_push(_st.notes, _s); }

/// @function itl_test_grab_sprite(sprite)
/// @description A sprite's pixels in a buffer {b, w, h} (BGRA), drawn with blending OFF so alpha is not applied twice.
function itl_test_grab_sprite(_spr) {
    var _w = sprite_get_width(_spr), _h = sprite_get_height(_spr);
    var _sf = surface_create(_w, _h);
    surface_set_target(_sf); draw_clear_alpha(c_black, 0); gpu_set_blendenable(false); draw_sprite(_spr, 0, 0, 0); gpu_set_blendenable(true); surface_reset_target();
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    surface_free(_sf);
    return { b: _b, w: _w, h: _h };
}

/// @function itl_test_draw(w, h, fn)
/// @description Draw fn() onto a fresh w x h surface cleared to magenta (255, 0, 255) and grab it: {b, w, h, res}.
function itl_test_draw(_w, _h, _fn) {
    var _sf = surface_create(_w, _h);
    surface_set_target(_sf); draw_clear(make_colour_rgb(255, 0, 255));
    var _res = _fn();
    surface_reset_target();
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    surface_free(_sf);
    return { b: _b, w: _w, h: _h, res: _res };
}

/// @function itl_test_count(grab, fn_px)
/// @description How many pixels satisfy fn_px(b, g, r, a).
function itl_test_count(_g, _pred) {
    var _n = 0;
    for (var _o = 0; _o < _g.w * _g.h * 4; _o += 4) if (_pred(buffer_peek(_g.b, _o, buffer_u8), buffer_peek(_g.b, _o + 1, buffer_u8), buffer_peek(_g.b, _o + 2, buffer_u8), buffer_peek(_g.b, _o + 3, buffer_u8))) _n++;
    return _n;
}

/// @function itl_test_diff(a, b, [tol])
/// @description Pixels differing between two grabs of one size by more than tol on ANY channel.
function itl_test_diff(_a, _b, _tol = 24) {
    var _n = 0;
    for (var _o = 0; _o < _a.w * _a.h * 4; _o += 4) {
        if (abs(buffer_peek(_a.b, _o, buffer_u8) - buffer_peek(_b.b, _o, buffer_u8)) > _tol || abs(buffer_peek(_a.b, _o + 1, buffer_u8) - buffer_peek(_b.b, _o + 1, buffer_u8)) > _tol
            || abs(buffer_peek(_a.b, _o + 2, buffer_u8) - buffer_peek(_b.b, _o + 2, buffer_u8)) > _tol) _n++;
    }
    return _n;
}

/// @function itl_selftest_run()
/// @description Run every stage; returns {total, pass, fail, stage, notes, failures}.
function itl_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, stage: 0, notes: [], failures: [] }, _i, _j;
    // "ink" = anything that is not the magenta test ground: no card or device is drawn in magenta (a grey ground hid
    // the stone lintel's own grey face from this count)
    var _grey = function(_b, _g, _r, _a) { return abs(_b - 255) > 30 || _g > 30 || abs(_r - 255) > 30; };

    // ---- 10: the reader - pure facts, including the phantom a short wildcard would create ----
    itl_st_stage(_st, 10);
    itl_st_assert(_st, itl_treatment_for("Overworld") == "cartouche", "Overworld -> cartouche");
    itl_st_assert(_st, itl_treatment_for("SF Inside") == "plate", "SF Inside is a PLATE before it is an interior");
    itl_st_assert(_st, itl_treatment_for("Inside") == "lacquer", "Inside -> lacquer");
    itl_st_assert(_st, itl_treatment_for("Dungeon") == "stone", "Dungeon -> stone");
    itl_st_assert(_st, itl_treatment_for("Sci-Fi Station") == "plate", "a hyphen joins: Sci-Fi -> scifi -> plate");
    itl_st_assert(_st, itl_treatment_for("") == "woodcut" && itl_treatment_for(undefined) == "woodcut", "nothing recognised -> woodcut");
    itl_st_assert(_st, itl_charge_for_element("Hellfire") == "flame", "a long stem takes a prefix: Hellfire -> flame");
    itl_st_assert(_st, is_undefined(itl_charge_for_element("Malice")) && is_undefined(itl_charge_for_element("Justice")), "PHANTOM PINNED: Malice and Justice are not frost");
    itl_st_assert(_st, itl_charge_for_element("Thunderstorm") == "bolt" && itl_charge_for_element("Darkness") == "moon", "Thunderstorm -> bolt, Darkness -> moon");
    itl_st_assert(_st, is_undefined(itl_charge_for_element("Physical")) && is_undefined(itl_charge_for_element(12)), "Physical and a number carry no device");
    itl_st_assert(_st, itl_dominant_charge({ Physical: 9, Earth: 4 }) == "stone", "Physical is skipped, not counted: Earth wins");
    itl_st_assert(_st, is_undefined(itl_place_card({ setting: "town" })) && is_undefined(itl_place_card({ name: "   " })), "no name, no card");
    var _p = itl_place_card({ name: "The Old Mine", setting: "Dungeon", parent: "Greyfell", depth: 2 });
    itl_st_assert(_st, is_struct(_p) && _p.treatment == "stone" && _p.charge == "arch" && _p.epithet == "beneath Greyfell" && _p.division == "quarter", "dungeon card: stone, arch, 'beneath Greyfell', quarter");
    _p = itl_place_card({ name: "Greyfell", charge: "dragon", epithet: "", danger: 7, first_visit: false });
    itl_st_assert(_st, _p.charge == "tree" && _p.epithet == "" && _p.danger == 3 && !_p.first_visit, "an unknown device is ignored, an empty epithet stands, danger clamps to 3, a return is a return");
    var _bs = itl_demo_bosses(), _b0 = itl_boss_card(_bs[0]), _b1 = itl_boss_card(_bs[1]), _b2 = itl_boss_card(_bs[2]);
    itl_st_assert(_st, _b0.charge == "flame" && _b0.weakness == "wave" && _b0.tier == 3, "Ember Warden: strikes with Fire past Physical, weak to Water, top rank");
    itl_st_assert(_st, _b1.charge == "crystal" && _b1.weakness == "flame" && _b1.tier == 2, "Mother of Rime: its SKILLS name the device, weak to Fire, tier 2");
    itl_st_assert(_st, _b2.name == "The Pale Abbot" && _b2.charge == "moon" && _b2.weakness == "sun" && _b2.tier == 1, "The_Pale_Abbot reads as a name; moon; weak to Holy; tier 1");
    var _plain = itl_boss_card({ name: "Brute", atk: 90, mat: 10 }), _mage = itl_boss_card({ name: "Magus", atk: 10, mat: 90 });
    itl_st_assert(_st, _plain.charge == "blade" && _mage.charge == "rune", "no element: the blade leans on attack, the rune on magic");
    itl_st_assert(_st, abs(itl_boss_rank(900, [120, 900, 5200]) - 0.5) < 0.0001 && itl_boss_rank(5, undefined) == 1, "rank is measured against the list");
    var _bigs = function(_s) { var _r = itl__sc_runs(_s), _n = 0, _t = ""; for (var _k = 0; _k < array_length(_r); _k++) if (_r[_k][1]) { _n++; _t += _r[_k][0]; } return _t; };
    itl_st_assert(_st, _bigs("Chapel of the Dawn") == "CD" && _bigs("Mother of Rime") == "MR", "small capitals: 'of' and 'the' keep a small initial inside a name");
    itl_st_assert(_st, _bigs("Of Mice and Men") == "OMM" && _bigs("The Old Mine") == "TOM", "a minor word that comes FIRST keeps its large initial");
    var _pl = itl_demo_places(), _tr = {}, _ch = {}, _keys = {};
    for (_i = 0; _i < array_length(_pl); _i++) { var _c = itl_place_card(_pl[_i]); _tr[$ _c.treatment] = 1; _ch[$ _c.charge] = 1; _keys[$ _c.key] = 1; }
    var _nt = variable_struct_names_count(_tr), _nc = variable_struct_names_count(_ch), _nk = variable_struct_names_count(_keys);
    itl_st_assert(_st, _nt == 5 && _nc >= 10 && _nk == 12, "the twelve sample places use all 5 constructions, >= 10 devices, 12 distinct cards (" + string(_nt) + "/" + string(_nc) + "/" + string(_nk) + ")");
    itl_st_note(_st, "sample world: " + string(_nt) + " constructions, " + string(_nc) + " devices, " + string(_nk) + " distinct cards");

    // ---- 20: every device puts INK down and no two are the same picture ----
    itl_st_stage(_st, 20);
    var _ids = itl_charges(), _grabs = [];
    for (_i = 0; _i < array_length(_ids); _i++) {
        var _id = _ids[_i];
        var _g = itl_test_draw(64, 64, method({ cid: _id }, function() { return itl_draw_charge(cid, 32, 32, 28, c_black); }));
        var _ink = itl_test_count(_g, _grey);
        itl_st_assert(_st, _g.res == true && _ink > 300, "device " + _id + " draws ink (" + string(_ink) + " px of 4096)");
        array_push(_grabs, _g);
    }
    var _closest = 100000, _pair = "";
    for (_i = 0; _i < array_length(_grabs); _i++) for (_j = _i + 1; _j < array_length(_grabs); _j++) {
        var _d = itl_test_diff(_grabs[_i], _grabs[_j]);
        if (_d < _closest) { _closest = _d; _pair = _ids[_i] + "/" + _ids[_j]; }
    }
    var _gs = itl_test_draw(64, 64, function() { itl_draw_charge("sun", 32, 32, 28, c_black); return true; });
    var _gn = itl_test_draw(64, 64, function() { itl_draw_charge("sun", 33, 32, 28, c_black); return true; });
    var _nudge = itl_test_diff(_gs, _gn);
    itl_st_assert(_st, _closest > _nudge, "no two devices closer than a one-pixel nudge (closest " + _pair + " " + string(_closest) + " vs nudge " + string(_nudge) + ")");
    itl_st_note(_st, "devices: closest pair " + _pair + " differs in " + string(_closest) + " px; a one-pixel nudge of the sun " + string(_nudge));
    var _gu = itl_test_draw(64, 64, function() { return itl_draw_charge("dragon", 32, 32, 28, c_black); });
    itl_st_assert(_st, _gu.res == false && itl_test_count(_gu, _grey) > 300, "CONTROL: an unknown device draws a plain disc and SAYS so (false)");
    for (_i = 0; _i < array_length(_grabs); _i++) buffer_delete(_grabs[_i].b);
    buffer_delete(_gs.b); buffer_delete(_gn.b); buffer_delete(_gu.b);

    // ---- 30: every card fills its box, its name fits, and danger / return change the PICTURE ----
    itl_st_stage(_st, 30);
    var _cards = [];
    for (_i = 0; _i < array_length(_pl); _i++) array_push(_cards, itl_place_card(_pl[_i]));
    for (_i = 0; _i < array_length(_bs); _i++) array_push(_cards, itl_boss_card(_bs[_i]));
    for (_i = 0; _i < array_length(_cards); _i++) {
        var _cp = _cards[_i];
        var _gc = itl_test_draw(780, 150, method({ p: _cp }, function() { return itl_card_draw(p, 0, 0, 780, 150); }));
        var _cover = itl_test_count(_gc, _grey);
        itl_st_assert(_st, is_struct(_gc.res) && _gc.res.name_fits && _gc.res.epithet_fits, _cp.name + ": the name and its epithet FIT");
        itl_st_assert(_st, _cover > 780 * 150 * ((_cp.kind == "boss") ? 0.35 : 0.8), _cp.name + ": the card covers its box (" + string(_cover) + " px)");
        buffer_delete(_gc.b);
    }
    var _src = { name: "Ashen Crypt", setting: "Dungeon", parent: "The Old Mine", depth: 3, elements: { Darkness: 6 }, danger: 0 };
    var _g0 = itl_test_draw(780, 150, method({ s: _src }, function() { return itl_card_draw(itl_place_card(s), 0, 0, 780, 150); }));
    _src.danger = 3;
    var _g3 = itl_test_draw(780, 150, method({ s: _src }, function() { return itl_card_draw(itl_place_card(s), 0, 0, 780, 150); }));
    _src.first_visit = false;
    var _gr = itl_test_draw(780, 150, method({ s: _src }, function() { return itl_card_draw(itl_place_card(s), 0, 0, 780, 150); }));
    var _g3b = itl_test_draw(780, 150, method({ s: { name: "Ashen Crypt", setting: "Dungeon", parent: "The Old Mine", depth: 3, elements: { Darkness: 6 }, danger: 3 } }, function() { return itl_card_draw(itl_place_card(s), 0, 0, 780, 150); }));
    var _dd = itl_test_diff(_g0, _g3), _dr = itl_test_diff(_g3, _gr), _same = itl_test_diff(_g3, _g3b);
    itl_st_assert(_st, _same == 0, "CONTROL: the same card drawn twice is the same picture (" + string(_same) + " px)");
    itl_st_assert(_st, _dd > 200, "calm and lethal are different pictures (" + string(_dd) + " px)");
    itl_st_assert(_st, _dr > 2000, "a first visit and a return are different pictures (" + string(_dr) + " px)");
    itl_st_note(_st, "danger 0 vs 3: " + string(_dd) + " px; first vs return: " + string(_dr) + " px; same card twice: " + string(_same));
    buffer_delete(_g0.b); buffer_delete(_g3.b); buffer_delete(_gr.b); buffer_delete(_g3b.b);
    var _spr = itl_card_sprite(_cards[0], 390, 75);
    var _gsp = itl_test_grab_sprite(_spr);
    var _alpha = itl_test_count(_gsp, function(_b, _g, _r, _a) { return _a > 200; });
    itl_st_assert(_st, sprite_get_width(_spr) == 390 && _alpha > 390 * 75 * 0.6, "the baked sprite carries the card, not an empty frame (" + string(_alpha) + " opaque px)");
    // ⛔ OPAQUE IS NOT PAINTED: the first store bake shipped twelve solid WHITE cards past the line above. White is the
    // signature of a sprite with no texture, so count it.
    var _wht = itl_bake_white(_spr);
    itl_st_assert(_st, _wht >= 0 && _wht < 0.05, "the baked sprite is PAINTED, not a white box (" + string_format(_wht * 100, 1, 1) + "% white)");
    buffer_delete(_gsp.b); sprite_delete(_spr);
    // the defect itself, reproduced, so the detector above is known to see it: a sprite built INSIDE a surface target
    var _host = surface_create(64, 64);
    surface_set_target(_host);
    var _bad = itl_card_sprite(_cards[0], 390, 75);
    surface_reset_target();
    surface_free(_host);
    var _bw = itl_bake_white(_bad);
    itl_st_note(_st, "a card sprite built inside another surface target reads " + string_format(_bw * 100, 1, 1) + "% white (built correctly: " + string_format(_wht * 100, 1, 1) + "%)");
    if (!is_undefined(_bad) && sprite_exists(_bad)) sprite_delete(_bad);
    // the first bake's other shape: draw a sprite, delete it on the next line, then let the target flush
    var _dd_host = surface_create(390, 75), _tmp = itl_card_sprite(_cards[0], 390, 75);
    surface_set_target(_dd_host); draw_clear_alpha(c_black, 0); draw_sprite(_tmp, 0, 0, 0); sprite_delete(_tmp); surface_reset_target();
    var _ddb = buffer_create(390 * 75 * 4, buffer_fixed, 1), _ddw = 0;
    buffer_get_surface(_ddb, _dd_host, 0);
    for (var _o = 0; _o < 390 * 75 * 4; _o += 4) if (buffer_peek(_ddb, _o, buffer_u8) > 250 && buffer_peek(_ddb, _o + 1, buffer_u8) > 250 && buffer_peek(_ddb, _o + 2, buffer_u8) > 250) _ddw++;
    buffer_delete(_ddb); surface_free(_dd_host);
    itl_st_note(_st, "draw a card sprite then delete it before the target flushes: " + string_format(_ddw / (390 * 75) * 100, 1, 1) + "% white");

    // ---- 40: the banner - queue, boss first, busy while a boss shows ----
    itl_st_stage(_st, 40);
    var _bn = itl_banner_create({ hold: 10, boss_hold: 12, rise: 4, fade: 4 });
    itl_banner_show(_bn, _cards[0]); itl_banner_show(_bn, _cards[1]);
    itl_banner_step(_bn);
    itl_st_assert(_st, _bn.cur.name == _cards[0].name && !itl_banner_busy(_bn), "the first place card shows first and is not busy");
    itl_banner_show(_bn, _cards[12]);
    itl_banner_step(_bn);
    itl_st_assert(_st, _bn.cur.kind == "boss" && itl_banner_busy(_bn), "a boss card jumps the queue and holds the battle");
    itl_st_assert(_st, array_length(_bn.queue) == 2 && _bn.queue[0].name == _cards[0].name, "the interrupted place card goes back to the FRONT of the queue");
    for (_i = 0; _i < 30; _i++) itl_banner_step(_bn);
    itl_st_assert(_st, !itl_banner_busy(_bn) && _bn.cur.kind == "place", "after the seal's time the battle is free and the place card resumes");
    itl_banner_skip(_bn); for (_i = 0; _i < 10; _i++) itl_banner_step(_bn);
    itl_st_assert(_st, _bn.shown == 4, "every queued card was shown (" + string(_bn.shown) + ")");
    itl_banner_free(_bn);

    // ---- 50: refusals are values, never crashes ----
    itl_st_stage(_st, 50);
    itl_st_assert(_st, is_undefined(itl_card_draw(undefined, 0, 0, 100, 40)) && is_undefined(itl_card_draw(_cards[0], 0, 0, -5, 40)) && is_undefined(itl_card_draw(_cards[0], "x", 0, 400, 80)), "itl_card_draw refuses a bad profile or box");
    itl_st_assert(_st, is_undefined(itl_card_sprite(_cards[0], 10, 10)) && is_undefined(itl_card_sprite("x", 400, 80)), "itl_card_sprite refuses a bad size or profile");
    itl_st_assert(_st, !itl_banner_show(undefined, _cards[0]) && !itl_banner_show(itl_banner_create(), { name: "no kind" }), "itl_banner_show refuses a bad banner or a non-card");
    itl_st_assert(_st, is_undefined(itl_boss_card(undefined)) && is_undefined(itl_place_card(42)), "a card built from nothing is undefined");
    itl_st_stage(_st, 99);
    return _st;
}

/// @function itl_selftest_write(st)
/// @description Write the suite's result to itl_selftest.json in the game's save area.
function itl_selftest_write(_st) {
    var _f = file_text_open_write("itl_selftest.json");
    file_text_write_string(_f, json_stringify(_st));
    file_text_close(_f);
}
