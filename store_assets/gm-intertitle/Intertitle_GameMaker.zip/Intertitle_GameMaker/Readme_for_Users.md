# Intertitle - Title Cards for Every Place and Every Boss, for GameMaker

**GameMaker 2024.14 or newer · pure GML · no sprites, no shaders, no extensions**
Core Systems Asset Factory · <https://csaf.itch.io>

When the player walks into a place, Intertitle puts up a composed title card instead of a bare name: the
place's name in engraved small capitals, a line beneath it saying where it sits, a rule that shows how
dangerous it is, and a device drawn from what its foes strike with. When a boss fight starts, the boss is
named on a seal: a medallion carrying its element, rays for how high it stands among your foes, and a
fault line for its weakness. Every card is drawn in code at run time from facts your game already keeps.
**Nothing here is an image file.**

---

## Quick start

1. **Tools > Import Local Package**, choose `Intertitle.yymps`, import everything.
2. Open `rm_itl_demo` and press Play: **N** walks to the next place, **B** meets the next boss, **R**
   returns to the place you just left, **D** raises its danger, **Space** skips a card.
3. In your own game, keep one banner in a controller object:

```gml
// Create
my_banner = itl_banner_create();

// when the player arrives somewhere
var my_card = itl_place_card({
    name: "The Old Mine", setting: "Dungeon", parent: "Greyfell",
    elements: { Earth: 4 }, danger: 2, first_visit: true
});
itl_banner_show(my_banner, my_card);

// Step
itl_banner_step(my_banner);

// Draw GUI
itl_banner_draw(my_banner, display_get_gui_width(), display_get_gui_height());

// Clean Up
itl_banner_free(my_banner);
```

For a boss, build its seal and hold the fight while it shows:

```gml
itl_banner_show(my_banner, itl_boss_card({ name: "The Ember Warden", attack: ["Fire"], resist: { Water: 2 }, rank: 0.95 }));
// in your battle's Step: if (itl_banner_busy(my_banner)) exit;
```

---

## What a place card reads

| Field | Meaning |
| --- | --- |
| `name` | **Required.** No name, no card - `itl_place_card` returns `undefined`. |
| `setting` | Words describing the place ("Dungeon", "Forest Road", "SF Inside"). They choose the construction. |
| `parent` | The place it sits in. The line beneath the name reads "beneath Greyfell", "in Frostmere", "aboard Orbital Ring"... |
| `elements` | `{ element name: count }` for what its foes strike with. The most used element with a device chooses the device. |
| `depth` | 0 a region, 1 a place in it, 2 or more deeper. |
| `sub_places` | How many places sit inside it: 0 to 5 lozenges on the rule. |
| `first_visit` | `true` the first time; `false` for a return, which gets a plainer, shorter card. |
| `danger` | 0 calm to 3 lethal. The rule's colour AND shape change; at 3 the roundel turns red. |

Any of these wins over what is derived: `treatment` (one of the five constructions), `charge` (one of the
fifteen devices), `epithet` (`""` for no line beneath). An unknown `charge` is ignored and the derived one stands.

### The five constructions

| Construction | Chosen by words like | Built as |
| --- | --- | --- |
| `cartouche` | overworld, world, continent, realm, kingdom | an inked map cartouche with rolled ends and a double rule |
| `woodcut` | outside, field, forest, town, road, coast, mountain | a board cut in relief, hatched, with a carved bevel |
| `lacquer` | inside, interior, house, castle, inn, temple, chapel | a lacquered panel in a gilt frame with corner ornaments |
| `stone` | dungeon, cave, crypt, tomb, mine, ruins, vault | a lintel of dressed stone with a chiselled bevel and joints |
| `plate` | sf, sci-fi, space, station, ship, lab, reactor | a riveted steel plate with a stamped border |

Nothing recognised gives a `woodcut`. Words are matched as whole words, whatever their case.

### The fifteen devices

`flame`, `crystal`, `bolt`, `wave`, `stone`, `gust`, `sun`, `moon` come from an element's NAME (so a
renamed element still works: "Hellfire" is a flame, "Thunderstorm" a bolt). `compass`, `tree`, `key`,
`arch`, `cog` are each construction's own device, for a place whose foes carry no element. `blade` and
`rune` are for a boss with no element at all: the blade if it leans on attack, the rune if on magic.

---

## What a boss card reads

| Field | Meaning |
| --- | --- |
| `name` | **Required.** Underscores read as spaces ("The_Pale_Abbot"). |
| `attack` | Element names it strikes with. The first that carries a device wins. |
| `skills` | Element names its skills use. The most used wins when `attack` gives none. |
| `resist` | `{ element name: damage rate }`. Its strongest resistance (below 1) is the next voice; its greatest weakness (above 1) is drawn as a fault line. |
| `rank` | 0 to 1, where it stands among your foes. Or pass `hp` and `all_hp` (every foe's max HP) and it is measured for you with `itl_boss_rank`. 0.33, 0.66 and 0.9 are the thresholds for 8, 12 and 16 rays. |
| `atk`, `mat` | With no element anywhere: `blade` if it leans on attack, `rune` if on magic. |

Overrides: `charge`, `epithet`.

---

## Functions

| Function | Returns |
| --- | --- |
| `itl_place_card(place)` | a place profile, or `undefined` with no name |
| `itl_boss_card(boss)` | a boss profile (a seal), or `undefined` with no name |
| `itl_treatment_for(setting)` | one of the five constructions |
| `itl_charge_for_element(name)` | a device, or `undefined` for a name that carries none ("Physical") |
| `itl_dominant_charge(counts)` | the device for the most used element in `{ name: count }` |
| `itl_boss_rank(hp, all_hp)` | 0 to 1 |
| `itl_treatments()` | the five construction ids, in a stable order |
| `itl_charges()` | the fifteen device ids, in a stable order |
| `itl_card_draw(profile, x, y, w, h)` | draws a card now into the current target; returns `{treatment, charge, name_px, name_fits, epithet_fits}` or `undefined` for a bad profile or box |
| `itl_card_sprite(profile, w, h, [supersample])` | the card baked into a new sprite (yours to `sprite_delete`) |
| `itl_draw_charge(id, cx, cy, size, colour, [alpha])` | draws one device; `false` for an unknown id (a plain disc is drawn) |
| `itl_banner_create([opts])` | a banner. `opts`: `hold`, `boss_hold`, `rise`, `fade` (frames), `width` (fraction of the GUI) |
| `itl_banner_show(banner, profile)` | queues a card; a boss card jumps the queue. `false` if refused |
| `itl_banner_step(banner)` | call in Step; it also bakes the current card's sprite (never in Draw) |
| `itl_banner_draw(banner, gui_w, gui_h)` | call in Draw GUI |
| `itl_banner_busy(banner)` | `true` while a boss card shows |
| `itl_banner_skip(banner)` | end the current card now |
| `itl_banner_free(banner)` | free its sprite and empty its queue (Clean Up) |

A bad argument is a refusal (`undefined` or `false`), never a crash inside your Draw event.

---

## Fonts and licences

The names and the lines beneath them are set in IM Fell DW Pica (SIL Open Font License 1.1), bundled as
three font resources under the name "Intertitle Plate Serif"; the demo's help line is Open Sans (Apache
2.0). Both licence texts and the notices ship in `Intertitle/fonts/`. See `LICENSE.txt` for the package
licence.

This package was written with AI assistance, disclosed on every store listing.
