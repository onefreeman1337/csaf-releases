# Puzzlework - for GameMaker

**Zelda-style dungeon puzzles without scripting each block: push-blocks, ice, pits, water, boulders, pressure plates, and light beams bent by mirrors - and every room draws itself.**

Puzzlework is the object layer of a dungeon puzzle room, in pure GML. You describe a room in a few strings,
the player walks and shoves, and one rule book decides what every shove does: a block moves one square and
keeps sliding on ice, a boulder rolls until something stops it and breaks against a wall, anything that
falls into a pit or water becomes a crossing, plates press under weight, and light travels from emitters
across mirrors to receivers. One call draws the whole room as a lit three-quarter view of worked stone,
with six block materials, three boulder stones, and every mechanism a physical object with a shadow.
None of it is an image file.

---

## What it does

- **One rule book, in one place.** `pzw_push` is the only place the interaction matrix lives, so it
  cannot disagree with itself. `pzw_preview_push` answers "what would happen if I shoved this?" by running
  the real push and putting it back, so the preview can never disagree with the push.
- **Pits and water that stay filled.** A block that falls into a pit becomes a bridge by *derivation*: the
  map is never changed, the fallen block is remembered, and the crossing is read from it. Save and load
  record only the objects, and the bridge comes back with them.
- **Light that cannot hang your game.** A beam's whole state is (cell, direction), so a beam that never
  ends must repeat one - and the tracer stops the moment it does, reporting `"looped"`. A ring of four
  mirrors is detected, not timed out. A beam crossing its own path at a right angle is legal.
- **The player's move in one call.** `pzw_try_move` walks into a free square, or shoves what stands there
  and follows it in.
- **Room reset that tells you when it pulls the floor away.** `pzw_reset` puts every object home; if the
  player was standing on a bridge that is a pit again, it says so, so you can send them to the entrance.
- **Rooms that draw themselves.** `pzw_room_draw` draws flagstone floors (varied per square), raised walls,
  pits with depth, water with ripples, ice with cracks, blocks in stone, wood, iron, ice, gold and crystal,
  boulders in granite, basalt and sandstone, plates that press, receivers that light, emitters, mirrors,
  and the light itself. 45 distinct things in all, each drawn by the package.

## Requirements

GameMaker 2024.14 or later. Built and tested with the **runtime 2024.14.4.268** on Windows (the VM runtime).
Pure GML: no extension, no DLL, no shader, no sprites.

## Install

1. **Tools > Import Local Package**, choose `Puzzlework.yymps`, and import everything.
2. Press Play. `rm_pzw_demo` opens a puzzle room: walk with the arrow keys, shove what is in the way, and
   press R to put the room back.

If you only want the library, import the `pzw_*` scripts and the four `fnt_puzzlework*` fonts;
`obj_pzw_demo`, `rm_pzw_demo` and `pzw_demo` are the demo, and `pzw_bake` only renders the store images.

## Quickstart

Put this in an object's events.

```gml
// Create
my_room = pzw_room_from_strings([
    "#########",
    "#@..BO..#",
    "#.......#",
    "#>.....\\#",
    "#....P..#",
    "#......T#",
    "#########"]);
my_px = my_room.start_x;
my_py = my_room.start_y;
my_beams = pzw_beams(my_room);

// Step
var my_dir = -1;
if (keyboard_check_pressed(vk_right)) my_dir = 0;
if (keyboard_check_pressed(vk_up)) my_dir = 90;
if (keyboard_check_pressed(vk_left)) my_dir = 180;
if (keyboard_check_pressed(vk_down)) my_dir = 270;
if (my_dir >= 0) {
    var my_move = pzw_try_move(my_room, my_px, my_py, my_dir);
    my_px = my_move.x;
    my_py = my_move.y;
    my_beams = pzw_beams(my_room);        // re-trace only when the room changes
}

// Draw GUI
pzw_room_draw(my_room, 40, 40, 48, { beams: my_beams, player_x: my_px, player_y: my_py, time: current_time / 1000 });
```

In a backslash mirror inside a GML string, write it twice (`"\\"`): that is one backslash character.

### The room characters

| Character | Is |
| --- | --- |
| `#` | wall |
| `.` | floor |
| `O` | pit |
| `~` | water |
| `:` | ice |
| `B` | stone block |
| `C` | wooden crate (a block) |
| `R` | boulder |
| `/` and `\` | mirrors |
| `P` | pressure plate |
| `T` | receiver (the target a beam must reach) |
| `>` `<` `^` `v` | emitter facing right, left, up, down |
| `@` | the player's start (floor) |

Other materials and anything the characters cannot say: `pzw_add(my_room, "block", 3, 2, { material: "gold" })`.

### Directions

Puzzlework uses GameMaker's own directions: `0` right, `90` up, `180` left, `270` down.

### Is the room solved?

```gml
var my_goal = pzw_solved(my_room);   // {plates_pressed, plates, receivers_lit, receivers, solved}
if (my_goal.solved) show_debug_message("The door opens.");
```

### Saving

```gml
my_saved = pzw_save(my_room);                                  // a string for your save file
var my_fresh = pzw_room_from_strings(my_room_strings);         // rebuild the room as authored...
pzw_load(my_fresh, my_saved);                                  // ...then put back what play changed
```

A damaged string, an unknown object id or a cell outside the room changes nothing.

## The API

| Function | What it does |
| --- | --- |
| `pzw_room(width, height)` | An empty room of floor. |
| `pzw_room_from_strings(rows)` | A room from strings, one character per square (the table above). |
| `pzw_is_room(value)` | True for a room. |
| `pzw_kinds()` | The vocabularies: terrain, object kinds, outcomes, beam ends, block and boulder materials. |
| `pzw_add(room, kind, x, y, [props])` | Author an object; props may carry `material` and `facing`. |
| `pzw_object_at(room, x, y)` | The object standing on a square, or `undefined`. |
| `pzw_objects(room, [kind])` | Every object, or every one of a kind. |
| `pzw_terrain(room, x, y)` | The authored terrain; outside the room reads as wall. |
| `pzw_set_terrain(room, x, y, terrain)` | Author a square's terrain. |
| `pzw_effective_terrain(room, x, y)` | Terrain as it behaves now: a filled pit reads as floor. |
| `pzw_is_bridged(room, x, y)` | Has this pit or water been filled? |
| `pzw_is_passable(room, x, y)` | May the player stand here? |
| `pzw_is_fixture(object)` | Plates and receivers: flush with the floor, travelled onto, lit over. |
| `pzw_push(room, x, y, dir)` | Shove an object; returns `{outcome, object, from_x, from_y, to_x, to_y, tiles}`. |
| `pzw_preview_push(room, x, y, dir)` | What the shove would do, changing nothing. |
| `pzw_try_move(room, px, py, dir)` | The player steps or shoves and follows; returns `{moved, x, y, push}`. |
| `pzw_plate_pressed(room, x, y)` | Is this plate pressed? |
| `pzw_plates_pressed(room)` | `{pressed, total}`. |
| `pzw_reflect(facing, dir)` | The direction light leaves a mirror. |
| `pzw_trace_beam(room, x, y, dir, [max_bounces])` | Trace light: `{outcome, cells, bounces, receiver_id}`. |
| `pzw_beams(room)` | Every emitter's beam, traced. |
| `pzw_receiver_lit(room, id)` | Is this receiver lit? |
| `pzw_solved(room)` | Every plate pressed and every receiver lit? |
| `pzw_reset(room, [px], [py])` | Put every object home; `{stranded}` if the player's square fell away. |
| `pzw_save(room)` | What play changed, as a string. |
| `pzw_load(room, string)` | Put it back onto a freshly authored room; returns how many objects. |
| `pzw_room_draw(room, x, y, cell, [opts])` | Draw the whole room. `opts`: `{beams, player_x, player_y, time}`. |
| `pzw_room_extent(room, cell)` | The room's drawn size in pixels. |
| `pzw_draw_object(object, x, y, cell, [lit], [time])` | Draw one object in a square. |
| `pzw_draw_terrain(kind, x, y, cell, [seed], [time])` | Draw one square of terrain. |
| `pzw_draw_sunk(object, terrain, x, y, cell, [time])` | Draw a fallen object as the crossing it made. |
| `pzw_draw_rubble(material, x, y, cell, [seed])` | Draw what a broken boulder leaves. |
| `pzw_draw_beam(trace, x, y, cell, [time])` | Draw one traced beam as light. |
| `pzw_draw_wisp(x, y, cell, [time])` | The demo's player marker. |
| `pzw_block_palette(material)` | A block material's colours. |
| `pzw_boulder_palette(material)` | A boulder material's colours. |

Every function checks what it is handed. A wrong type, `undefined`, an unknown direction or an
out-of-range square returns a refusal value (`undefined`, `false`, `0`, `""`, an empty array, or a push
result with outcome `"blocked"`) instead of throwing inside your game.

## Sizes and performance

A room draws `width * cell` across and `height * cell + 0.44 * cell` down (walls rise above the first row).
`pzw_beams` and `pzw_solved` allocate: call them when the room changes and keep the result, as the
quickstart does. `pzw_room_draw` draws every square every call; a 15 x 8 room is a few thousand primitives.

## Namespacing

Every script, function and macro is prefixed `pzw_` or `PZW_`; the resources are `obj_pzw_demo`,
`rm_pzw_demo` and the four `fnt_puzzlework` fonts. Nothing collides with your project.

## Fonts

Three fonts are rasterised from IM Fell DW Pica (SIL Open Font License 1.1) and one is Open Sans (Apache
License 2.0). Only the demo and the store images use them; the room itself draws no text. Their licences
and notices are in `Puzzlework/fonts/`, with `THIRD-PARTY-NOTICES.txt`.

## Licence and disclosure

One commercial licence per developer, unlimited games. Everything the package draws in your game is yours
to ship. See `LICENSE.txt`.

This package's code and its store images were produced with AI assistance.

Copyright (c) 2026 Core Systems Asset Factory.

*The RPG Maker MZ edition, Cogwheel: <https://csaf.itch.io/cogwheel>. More GameMaker systems from Core
Systems Asset Factory: <https://csaf.itch.io>*
