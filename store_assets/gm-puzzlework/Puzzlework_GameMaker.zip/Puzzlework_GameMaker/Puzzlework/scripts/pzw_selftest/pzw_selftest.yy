{
  "$GMScript": "v1",
  "%Name": "pzw_selftest",
  "name": "pzw_selftest",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}