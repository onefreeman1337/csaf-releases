/// pzw_selftest.gml - the in-engine suite (`Puzzlework.exe -selftest` writes pzw_selftest.json).
///
/// Puzzlework - Dungeon Puzzles Without Scripting Each Block, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Stage 99 = the suite reached its end.
/// The interaction matrix is asserted CELL BY CELL, because a rule implemented once and tested only in aggregate is
/// a rule that can be wrong in one corner (the MZ original's plate-that-could-never-be-pressed was found that way).

function pzw_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 60) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
function pzw_st_stage(_st, _n) { _st.stage = _n; global.pzw_stage = _n; }
function pzw_st_note(_st, _s) { array_push(_st.notes, _s); }

function pzw_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, failures: [], stage: 0, notes: [] }, _r, _p, _o, _i;

    pzw_st_stage(_st, 1);    // building a room
    _r = pzw_room_from_strings(["#######", "#@.B.O#", "#:::..#", "#~.P.T#", "#######"]);
    pzw_st_assert(_st, pzw_is_room(_r) && _r.width == 7 && _r.height == 5, "a room of 7 x 5 from strings");
    pzw_st_assert(_st, pzw_terrain(_r, 0, 0) == "wall" && pzw_terrain(_r, 5, 1) == "hole" && pzw_terrain(_r, 1, 2) == "ice" && pzw_terrain(_r, 1, 3) == "water" && pzw_terrain(_r, 2, 1) == "floor", "every terrain character reads as authored");
    pzw_st_assert(_st, _r.start_x == 1 && _r.start_y == 1, "the player start is read from @");
    pzw_st_assert(_st, array_length(pzw_objects(_r)) == 3 && pzw_object_at(_r, 3, 1).kind == "block" && pzw_object_at(_r, 3, 3).kind == "plate" && pzw_object_at(_r, 5, 3).kind == "receiver", "objects are placed where the strings put them");
    pzw_st_assert(_st, pzw_terrain(_r, -1, 0) == "wall" && pzw_terrain(_r, 99, 0) == "wall" && !pzw_is_passable(_r, -1, 1), "outside the room reads as wall");

    pzw_st_stage(_st, 2);    // the push matrix, cell by cell
    _r = pzw_room_from_strings(["#########", "#.B.....#", "#########"]);
    _p = pzw_push(_r, 2, 1, 0);
    pzw_st_assert(_st, _p.outcome == "moved" && _p.tiles == 1 && _p.to_x == 3 && pzw_object_at(_r, 3, 1) != undefined, "a block on floor moves exactly one cell");
    _r = pzw_room_from_strings(["####", "#B.#", "####"]);
    _p = pzw_push(_r, 1, 1, 180);
    pzw_st_assert(_st, _p.outcome == "blocked" && _p.tiles == 0 && pzw_object_at(_r, 1, 1) != undefined, "a block against a wall does not move");
    _r = pzw_room_from_strings(["#########", "#B.....##", "#########"]);
    for (_i = 2; _i <= 5; _i++) pzw_set_terrain(_r, _i, 1, "ice");
    _p = pzw_push(_r, 1, 1, 0);
    pzw_st_assert(_st, _p.outcome == "slid" && _p.to_x == 6 && _p.tiles == 5, "a block slides across ice and stops on the first floor after it (" + string(_p.to_x) + ", " + string(_p.tiles) + " cells)");
    _r = pzw_room_from_strings(["#######", "#B:::##", "#######"]);
    _p = pzw_push(_r, 1, 1, 0);
    pzw_st_assert(_st, _p.outcome == "slid" && _p.to_x == 4, "a block on ice stops against a wall (" + string(_p.to_x) + ")");
    _r = pzw_room_from_strings(["#######", "#.BO..#", "#######"]);
    _p = pzw_push(_r, 2, 1, 0);
    pzw_st_assert(_st, _p.outcome == "fell_in_hole" && _p.object.consumed && pzw_is_bridged(_r, 3, 1) && pzw_effective_terrain(_r, 3, 1) == "floor" && pzw_terrain(_r, 3, 1) == "hole", "a block falls into a hole, which becomes a crossing WITHOUT the authored terrain changing");
    pzw_st_assert(_st, pzw_is_passable(_r, 3, 1) && pzw_object_at(_r, 3, 1) == undefined, "the filled hole is walkable and holds no obstruction");
    pzw_add(_r, "block", 2, 1);
    _p = pzw_push(_r, 2, 1, 0);
    pzw_st_assert(_st, _p.outcome == "moved" && _p.to_x == 3 && !_p.object.consumed, "a second block travels ONTO a filled hole instead of falling into it again");
    _r = pzw_room_from_strings(["######", "#B~..#", "######"]);
    _p = pzw_push(_r, 1, 1, 0);
    pzw_st_assert(_st, _p.outcome == "sank" && pzw_is_bridged(_r, 2, 1) && pzw_is_passable(_r, 2, 1), "a block sinks in water and makes a ford");
    _r = pzw_room_from_strings(["########", "#R.....#", "########"]);
    _p = pzw_push(_r, 1, 1, 0);
    pzw_st_assert(_st, _p.outcome == "broke" && _p.to_x == 6 && _p.object.consumed && pzw_object_at(_r, 6, 1) == undefined, "a boulder rolls to the wall and breaks against it (" + _p.outcome + ")");
    _r = pzw_room_from_strings(["########", "#R...B.#", "########"]);
    _p = pzw_push(_r, 1, 1, 0);
    pzw_st_assert(_st, _p.outcome == "slid" && _p.to_x == 4 && !_p.object.consumed, "a boulder stopped by a block does not break (" + _p.outcome + ", " + string(_p.to_x) + ")");
    _r = pzw_room_from_strings(["#######", "#R..O.#", "#######"]);
    _p = pzw_push(_r, 1, 1, 0);
    pzw_st_assert(_st, _p.outcome == "fell_in_hole" && _p.to_x == 4 && pzw_is_bridged(_r, 4, 1), "a rolling boulder falls into the first hole on its path");
    _r = pzw_room_from_strings(["######", "#BP..#", "######"]);
    _p = pzw_push(_r, 1, 1, 0);
    pzw_st_assert(_st, _p.outcome == "moved" && _p.to_x == 2 && pzw_plate_pressed(_r, 2, 1), "a block is pushed ONTO a plate (a fixture) and presses it");
    _r = pzw_room_from_strings(["######", "#BB..#", "######"]);
    _p = pzw_push(_r, 1, 1, 0);
    pzw_st_assert(_st, _p.outcome == "blocked", "a block does not push a second block (no chained pushes)");
    _r = pzw_room_from_strings(["#####", "#P>T#", "#####"]);
    pzw_st_assert(_st, pzw_push(_r, 1, 1, 0).outcome == "blocked" && pzw_push(_r, 2, 1, 0).outcome == "blocked" && pzw_push(_r, 3, 1, 180).outcome == "blocked", "plates, emitters and receivers are bolted down");
    _r = pzw_room_from_strings(["######", "#./..#", "######"]);
    _p = pzw_push(_r, 2, 1, 0);
    pzw_st_assert(_st, _p.outcome == "moved" && pzw_object_at(_r, 3, 1).kind == "mirror", "a mirror is pushable, so aiming a beam is a pushing puzzle");

    pzw_st_stage(_st, 3);    // the preview IS the push
    _r = pzw_room_from_strings(["##########", "#.B:::O..#", "#R......##", "##########"]);
    var _before = pzw_save(_r), _agree = true, _dirs = [0, 90, 180, 270], _cells = [[2, 1], [1, 2]];
    for (_i = 0; _i < 2; _i++) for (var _k = 0; _k < 4; _k++) {
        var _pv = pzw_preview_push(_r, _cells[_i][0], _cells[_i][1], _dirs[_k]);
        if (pzw_save(_r) != _before) _agree = false;
        var _copy = pzw_room_from_strings(["##########", "#.B:::O..#", "#R......##", "##########"]);
        var _real = pzw_push(_copy, _cells[_i][0], _cells[_i][1], _dirs[_k]);
        if (_real.outcome != _pv.outcome || _real.to_x != _pv.to_x || _real.to_y != _pv.to_y || _real.tiles != _pv.tiles) _agree = false;
    }
    pzw_st_assert(_st, _agree, "for 2 objects x 4 directions the preview matches the push exactly and leaves the room unchanged");

    pzw_st_stage(_st, 4);    // light
    _r = pzw_room_from_strings(["#######", "#>..\\.#", "#.....#", "#...T.#", "#######"]);
    var _b = pzw_beams(_r);
    pzw_st_assert(_st, array_length(_b) == 1 && _b[0].trace.outcome == "receiver" && _b[0].trace.bounces == 1, "emitter -> mirror -> receiver: lit after one bounce (" + _b[0].trace.outcome + ")");
    pzw_st_assert(_st, pzw_receiver_lit(_r, pzw_object_at(_r, 4, 3).id) && pzw_solved(_r).solved, "the receiver reports lit and the room reports solved");
    pzw_add(_r, "block", 4, 2);
    pzw_st_assert(_st, pzw_beams(_r)[0].trace.outcome == "blocked" && !pzw_solved(_r).solved, "a block in the path casts a shadow");
    _r = pzw_room_from_strings(["#######", "#>PO~T#", "#######"]);
    pzw_st_assert(_st, pzw_beams(_r)[0].trace.outcome == "receiver", "light passes over a plate, a hole and water");
    _r = pzw_room_from_strings(["......", "......"]);
    var _tr = pzw_trace_beam(_r, 0, 0, 0);
    pzw_st_assert(_st, _tr.outcome == "escaped" && array_length(_tr.cells) == 6, "light leaving the room escapes (6 cells lit)");
    // a beam crossing its own path at right angles is LEGAL - keyed on (cell, direction), not on cell
    _r = pzw_room(8, 6);
    pzw_add(_r, "mirror", 4, 2, { facing: "\\" }); pzw_add(_r, "mirror", 4, 4, { facing: "/" }); pzw_add(_r, "mirror", 2, 4, { facing: "\\" });
    _tr = pzw_trace_beam(_r, 0, 2, 0);
    var _cross = 0;
    for (_i = 0; _i < array_length(_tr.cells); _i++) if (_tr.cells[_i].x == 2 && _tr.cells[_i].y == 2) _cross++;
    pzw_st_assert(_st, _tr.outcome == "escaped" && _tr.bounces == 3 && _cross == 2, "a beam may cross its own path at right angles (" + _tr.outcome + ", bounces " + string(_tr.bounces) + ", cell visited " + string(_cross) + "x)");
    // a RING of four mirrors traps light forever unless the tracer detects the repeat
    _r = pzw_room(8, 6);
    pzw_add(_r, "mirror", 2, 1, { facing: "/" }); pzw_add(_r, "mirror", 5, 1, { facing: "\\" }); pzw_add(_r, "mirror", 5, 3, { facing: "/" }); pzw_add(_r, "mirror", 2, 3, { facing: "\\" });
    _tr = pzw_trace_beam(_r, 3, 1, 0);
    pzw_st_assert(_st, _tr.outcome == "looped" && _tr.bounces == 4, "a ring of four mirrors is reported as a LOOP after 4 bounces, and the trace ends (" + _tr.outcome + ", " + string(_tr.bounces) + ")");
    _tr = pzw_trace_beam(_r, 3, 1, 0, 2);
    pzw_st_assert(_st, _tr.outcome == "capped" && _tr.bounces == 2, "a lowered bounce cap is honoured as a backstop");
    pzw_st_assert(_st, pzw_reflect("/", 0) == 90 && pzw_reflect("/", 90) == 0 && pzw_reflect("/", 180) == 270 && pzw_reflect("/", 270) == 180
        && pzw_reflect("\\", 0) == 270 && pzw_reflect("\\", 270) == 0 && pzw_reflect("\\", 180) == 90 && pzw_reflect("\\", 90) == 180 && pzw_reflect("?", 0) == -1,
        "the reflection table: every mirror turns light 90 degrees and never reverses it");

    pzw_st_stage(_st, 5);    // reset, and the floor pulled from under the player
    _r = pzw_room_from_strings(["#######", "#.BO..#", "#R....#", "#######"]);
    pzw_push(_r, 2, 1, 0); pzw_push(_r, 1, 2, 0);
    var _rs = pzw_reset(_r, 3, 1);
    pzw_st_assert(_st, _rs.stranded, "a player standing on a filled hole is reported STRANDED by the reset that re-opens it");
    pzw_st_assert(_st, pzw_object_at(_r, 2, 1) != undefined && pzw_object_at(_r, 1, 2) != undefined && !pzw_is_bridged(_r, 3, 1) && !pzw_objects(_r)[1].consumed, "reset puts every object home and un-consumes the broken boulder");
    pzw_push(_r, 2, 1, 0);
    pzw_st_assert(_st, !pzw_reset(_r, 5, 1).stranded, "a player on plain floor is not stranded");

    pzw_st_stage(_st, 6);    // save and load: only what play changed
    var _rows = ["########", "#.B.O..#", "#.C.~R.#", "########"];
    _r = pzw_room_from_strings(_rows);
    pzw_push(_r, 2, 1, 0); pzw_push(_r, 3, 1, 0); pzw_push(_r, 2, 2, 0); pzw_push(_r, 3, 2, 0);
    var _txt = pzw_save(_r), _fresh = pzw_room_from_strings(_rows);
    var _n = pzw_load(_fresh, _txt);
    pzw_st_assert(_st, _n == 3 && pzw_is_bridged(_fresh, 4, 1) && pzw_is_bridged(_fresh, 4, 2) && pzw_save(_fresh) == _txt, "a save restores onto the freshly authored room: both crossings survive (" + string(_n) + " objects)");
    var _junk = pzw_room_from_strings(_rows), _js = pzw_save(_junk);
    pzw_st_assert(_st, pzw_load(_junk, "not json {") == 0 && pzw_load(_junk, "") == 0 && pzw_load(_junk, "{\"o\":[[99,1,1,0],[1,500,1,0]]}") == 0 && pzw_save(_junk) == _js, "a damaged save, an unknown id and an off-room cell change nothing");

    pzw_st_stage(_st, 7);    // the player's move: walk, push and follow
    _r = pzw_room_from_strings(["#######", "#@B.O.#", "#.....#", "#######"]);
    var _m = pzw_try_move(_r, 1, 1, 0);
    pzw_st_assert(_st, _m.moved && _m.x == 2 && is_struct(_m.push) && _m.push.outcome == "moved", "the player pushes a block and follows it in");
    _m = pzw_try_move(_r, 2, 1, 0);
    pzw_st_assert(_st, _m.moved && _m.x == 3 && _m.push.outcome == "fell_in_hole", "a second shove drops the block into the hole");
    _m = pzw_try_move(_r, 3, 1, 0);
    pzw_st_assert(_st, _m.moved && _m.x == 4 && is_undefined(_m.push), "the player walks across the filled hole");
    _r = pzw_room_from_strings(["#####", "#@O.#", "#####"]);
    pzw_st_assert(_st, !pzw_try_move(_r, 1, 1, 0).moved && !pzw_try_move(_r, 1, 1, 90).moved, "the player cannot walk into a hole or a wall");

    pzw_st_stage(_st, 8);    // a whole room, solved by play
    _r = pzw_room_from_strings(["#########", "#@..B...#", "#.......#", "#>..../.#", "#.....P.#", "#..T....#", "#########"]);
    var _s0 = pzw_solved(_r);
    pzw_st_assert(_st, !_s0.solved && _s0.plates == 1 && _s0.receivers == 1, "the demo room starts unsolved (1 plate, 1 receiver)");
    // shove the block right twice, then down onto... the plate sits at (6,4): walk round and push the block down
    var _px = 1, _py = 1, _moves = [0, 0, 0, 270, 0, 90, 270, 270, 180];
    for (_i = 0; _i < array_length(_moves); _i++) { _m = pzw_try_move(_r, _px, _py, _moves[_i]); _px = _m.x; _py = _m.y; }
    var _s1 = pzw_solved(_r);
    pzw_st_note(_st, "scripted run ends at player " + string(_px) + "," + string(_py) + "; plates " + string(_s1.plates_pressed) + "/" + string(_s1.plates) + ", receivers " + string(_s1.receivers_lit) + "/" + string(_s1.receivers));

    pzw_st_stage(_st, 9);    // refusals: every public function hands back a refusal value, never an exception
    pzw_st_assert(_st, is_undefined(pzw_room(0, 5)) && is_undefined(pzw_room("a", 5)) && is_undefined(pzw_room(300, 5)) && is_undefined(pzw_room_from_strings("x")) && is_undefined(pzw_room_from_strings([5])), "refusals: bad sizes and bad string arrays");
    pzw_st_assert(_st, pzw_push(undefined, 1, 1, 0).outcome == "blocked" && pzw_push(_r, 1, 1, 45).outcome == "blocked" && pzw_trace_beam(_r, 1, 1, 45).outcome == "blocked" && !pzw_try_move(_r, 1, 1, 7).moved, "refusals: no room, a diagonal or unknown direction");
    pzw_st_assert(_st, is_undefined(pzw_add(_r, "dragon", 1, 1)) && is_undefined(pzw_add(_r, "block", -1, 1)) && !pzw_set_terrain(_r, 1, 1, "lava") && pzw_save(undefined) == "" && pzw_load(undefined, "x") == 0, "refusals: unknown kinds and terrains, off-room cells, a non-room save");

    pzw_st_stage(_st, 10);   // VOLUME, measured on the pixels: every entry of the atlas draws, and no two are alike
    var _E = pzw_atlas_entries(), _ne = array_length(_E), _sf = surface_create(96, 144), _lums = [], _inked = 0;
    // ⚠️ COLOUR, not luminance: the first version compared luminance and read "granite in a pit" and "sandstone in a
    // pit" as IDENTICAL (0 samples apart) - grey and tan stone of nearly equal brightness. A buyer sees hue.
    for (_i = 0; _i < _ne; _i++) {
        surface_set_target(_sf); draw_clear(c_black); pzw_bake_entry(_E[_i], 16, 60, 64); surface_reset_target();
        var _lb = pzw_st_rgb(_sf, 96, 144);
        array_push(_lums, _lb);
        if (pzw_st_lit(_lb, 48 * 72) > 400) _inked++;
    }
    surface_set_target(_sf); draw_clear(c_black); pzw_bake_entry(_E[0], 17, 60, 64); surface_reset_target();
    var _nudge = pzw_st_rgb(_sf, 96, 144), _noise = pzw_st_pixdiff(_lums[0], _nudge, 48 * 72), _pmin = 999999, _ppair = "", _under = 0, _ulist = "";
    for (_i = 0; _i < _ne; _i++) for (var _q = _i + 1; _q < _ne; _q++) {
        var _pd = pzw_st_pixdiff(_lums[_i], _lums[_q], 48 * 72);
        if (_pd < _pmin) { _pmin = _pd; _ppair = _E[_i][0] + " / " + _E[_q][0]; }
        if (_pd <= _noise) { _under++; if (string_length(_ulist) < 400) _ulist += _E[_i][0] + "/" + _E[_q][0] + "=" + string(_pd) + "; "; }
    }
    if (_under > 0) pzw_st_note(_st, "pairs at or under the nudge: " + _ulist);
    for (_i = 0; _i < _ne; _i++) buffer_delete(_lums[_i]);
    buffer_delete(_nudge);
    surface_free(_sf);
    pzw_st_note(_st, string(_ne) + " atlas entries; closest pair " + _ppair + " at " + string(_pmin) + " of 3456 samples; one-pixel nudge " + string(_noise));
    pzw_st_assert(_st, _ne >= 40, "the atlas lists at least 40 distinct things (" + string(_ne) + ")");
    pzw_st_assert(_st, _inked == _ne, "every atlas entry puts ink down (" + string(_inked) + " of " + string(_ne) + ")");
    pzw_st_assert(_st, _under == 0, "every two entries differ, pixel for pixel, by more than one entry nudged a pixel (closest " + string(_pmin) + " vs " + string(_noise) + ", " + string(_under) + " pairs under)");

    pzw_st_stage(_st, 11);   // the room: drawn, its beams counted, nothing drawn above or left of its extent
    _r = pzw_bake_solved_room();
    var _ext = pzw_room_extent(_r, 24), _rs2 = surface_create(_ext.w + 60, _ext.h + 60);
    surface_set_target(_rs2); draw_clear_alpha(c_black, 0); var _drew = pzw_room_draw(_r, 20, 20, 24, { time: 0.5 }); surface_reset_target();
    var _box = pzw_st_inkbox(_rs2, _ext.w + 60, _ext.h + 60);
    surface_free(_rs2);
    var _sol = pzw_solved(_r);
    pzw_st_note(_st, "hero room: " + string(_drew.cells) + " cells, " + string(_drew.objects) + " objects, " + string(_drew.beams) + " beams; ink " + string(_box.x0) + "," + string(_box.y0) + " .. " + string(_box.x1) + "," + string(_box.y1) + " for extent " + string(_ext.w) + "x" + string(_ext.h) + " at 20,20");
    pzw_st_assert(_st, _sol.solved && _sol.plates_pressed == 1 && _sol.receivers_lit == 1, "the hero room's scripted solve really solves it (the store image shows a solved room)");
    pzw_st_assert(_st, is_struct(_drew) && _drew.cells == _r.width * _r.height && _drew.beams == 1, "the room draws every cell and its one beam");
    pzw_st_assert(_st, _box.x0 >= 19 && _box.y0 >= 19, "nothing is drawn above or left of the room's extent");
    pzw_st_assert(_st, is_undefined(pzw_room_draw(undefined, 0, 0, 24)) && is_undefined(pzw_room_draw(_r, 0, 0, 2)) && !pzw_draw_object("x", 0, 0, 24), "refusals: a non-room, a cell under 4 px, a non-object");

    pzw_st_stage(_st, 12);   // the GIF's solve is real play: the moves, through pzw_try_move, solve the room
    _r = pzw_room_from_strings(pzw_gif_rows());
    var _gx = _r.start_x, _gy = _r.start_y, _GM = pzw_gif_moves(), _allm = true;
    pzw_st_assert(_st, !pzw_solved(_r).solved && pzw_beams(_r)[0].trace.outcome == "blocked", "the GIF room starts unsolved with its beam blocked");
    for (_i = 0; _i < array_length(_GM); _i++) { _m = pzw_try_move(_r, _gx, _gy, _GM[_i]); if (!_m.moved) _allm = false; _gx = _m.x; _gy = _m.y; }
    pzw_st_assert(_st, _allm && pzw_solved(_r).solved && pzw_is_bridged(_r, 4, 3), "four moves solve it: the block bridges the pit, the beam reaches the receiver, the crate presses the plate");

    pzw_st_stage(_st, 99);
    return _st;
}

/// @function pzw_st_lum(surface, w, h)
/// @description A half-resolution luminance buffer of a surface (every second pixel both ways).
function pzw_st_lum(_sf, _w, _h) {
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    var _hw = _w div 2, _hh = _h div 2, _out = buffer_create(_hw * _hh, buffer_fixed, 1);
    for (var _y = 0; _y < _hh; _y++) for (var _x = 0; _x < _hw; _x++) {
        var _o = ((_y * 2) * _w + _x * 2) * 4;
        buffer_poke(_out, _y * _hw + _x, buffer_u8, floor((buffer_peek(_b, _o, buffer_u8) + buffer_peek(_b, _o + 1, buffer_u8) + buffer_peek(_b, _o + 2, buffer_u8)) / 3));
    }
    buffer_delete(_b);
    return _out;
}

/// @function pzw_st_rgb(surface, w, h)
/// @description A half-resolution RGB buffer of a surface (3 bytes per sample, every second pixel both ways).
function pzw_st_rgb(_sf, _w, _h) {
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    var _hw = _w div 2, _hh = _h div 2, _out = buffer_create(_hw * _hh * 3, buffer_fixed, 1);
    for (var _y = 0; _y < _hh; _y++) for (var _x = 0; _x < _hw; _x++) {
        var _o = ((_y * 2) * _w + _x * 2) * 4, _d = (_y * _hw + _x) * 3;
        buffer_poke(_out, _d, buffer_u8, buffer_peek(_b, _o, buffer_u8));
        buffer_poke(_out, _d + 1, buffer_u8, buffer_peek(_b, _o + 1, buffer_u8));
        buffer_poke(_out, _d + 2, buffer_u8, buffer_peek(_b, _o + 2, buffer_u8));
    }
    buffer_delete(_b);
    return _out;
}

/// @function pzw_st_pixdiff(a, b, n)
/// @description How many of n RGB samples differ by more than 40 levels in ANY channel.
function pzw_st_pixdiff(_a, _b, _n) {
    var _d = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _o = _i * 3;
        if (abs(buffer_peek(_a, _o, buffer_u8) - buffer_peek(_b, _o, buffer_u8)) > 40 || abs(buffer_peek(_a, _o + 1, buffer_u8) - buffer_peek(_b, _o + 1, buffer_u8)) > 40
            || abs(buffer_peek(_a, _o + 2, buffer_u8) - buffer_peek(_b, _o + 2, buffer_u8)) > 40) _d++;
    }
    return _d;
}

/// @function pzw_st_lit(a, n)
/// @description How many of n RGB samples have any channel brighter than 12.
function pzw_st_lit(_a, _n) {
    var _d = 0;
    for (var _i = 0; _i < _n; _i++) if (buffer_peek(_a, _i * 3, buffer_u8) > 12 || buffer_peek(_a, _i * 3 + 1, buffer_u8) > 12 || buffer_peek(_a, _i * 3 + 2, buffer_u8) > 12) _d++;
    return _d;
}

/// @function pzw_st_inkbox(surface, w, h)
/// @description Bounding box and count of pixels with coverage (alpha > 8) on a surface cleared to transparent.
function pzw_st_inkbox(_sf, _w, _h) {
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    var _x0 = _w, _y0 = _h, _x1 = -1, _y1 = -1, _n = 0;
    for (var _y = 0; _y < _h; _y++) for (var _x = 0; _x < _w; _x++) {
        if (buffer_peek(_b, (_y * _w + _x) * 4 + 3, buffer_u8) > 8) { _n++; if (_x < _x0) _x0 = _x; if (_x > _x1) _x1 = _x; if (_y < _y0) _y0 = _y; if (_y > _y1) _y1 = _y; }
    }
    buffer_delete(_b);
    return { x0: _x0, y0: _y0, x1: _x1, y1: _y1, px: _n };
}

function pzw_selftest_write(_st) {
    var _f = file_text_open_write("pzw_selftest.json");
    file_text_write_string(_f, "{\"total\":" + string(_st.total) + ",\"pass\":" + string(_st.pass) + ",\"fail\":" + string(_st.fail) + ",\"stage\":" + string(_st.stage) + ",\"notes\":[");
    for (var _i = 0; _i < array_length(_st.notes); _i++) { if (_i > 0) file_text_write_string(_f, ","); file_text_write_string(_f, "\"" + string_replace_all(_st.notes[_i], "\"", "'") + "\""); }
    file_text_write_string(_f, "],\"failures\":[");
    for (var _i = 0; _i < array_length(_st.failures); _i++) { if (_i > 0) file_text_write_string(_f, ","); file_text_write_string(_f, "\"" + string_replace_all(_st.failures[_i], "\"", "'") + "\""); }
    file_text_write_string(_f, "]}");
    file_text_close(_f);
}
