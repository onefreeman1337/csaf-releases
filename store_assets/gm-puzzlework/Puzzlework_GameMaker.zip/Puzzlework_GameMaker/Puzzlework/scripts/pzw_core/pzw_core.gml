/// pzw_core.gml - the dungeon-object engine. PURE GML: no drawing, no instances, no globals.
///
/// Puzzlework - Dungeon Puzzles Without Scripting Each Block, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// The OBJECT layer of a Zelda-style puzzle room: push-blocks that slide on ice and fill holes, boulders that roll
/// until something stops them and break against a wall, pressure plates, light beams that reflect off mirrors to
/// receivers, and a room reset. Ported from Core Systems Asset Factory's RPG Maker MZ plugin Cogwheel; the rules are
/// the same, and so are the three decisions that make them safe:
///   1. A FILLED HOLE IS DERIVED, NEVER WRITTEN. A block that falls into a hole is marked consumed and stays at that
///      cell; the hole reads as floor because a consumed object rests in it. The authored terrain is never changed,
///      so a save that records only the objects restores the bridge with them (the MZ plugin shipped the other way
///      first, and a saved-and-reloaded player was stranded).
///   2. A BEAM CANNOT HANG YOUR GAME, and not because of a retry limit: a beam's whole state is (cell, direction), so
///      a beam that never ends must repeat one, and the tracer stops the moment it does (reported as "looped").
///   3. THE PREVIEW IS THE PUSH. pzw_preview_push runs pzw_push and puts back the three fields it changes, so the
///      two can never disagree.
///
/// DIRECTIONS are GameMaker's own: 0 right, 90 up, 180 left, 270 down (as `direction` and lengthdir_* use them).
///
/// PUBLIC API (each function's header says more):
///   pzw_room(width, height)                 pzw_room_from_strings(rows)       pzw_is_room(value)
///   pzw_add(room, kind, x, y, [props])      pzw_object_at(room, x, y)         pzw_objects(room, [kind])
///   pzw_terrain(room, x, y)                 pzw_set_terrain(room, x, y, t)    pzw_effective_terrain(room, x, y)
///   pzw_is_bridged(room, x, y)              pzw_is_passable(room, x, y)       pzw_is_fixture(object)
///   pzw_push(room, x, y, dir)               pzw_preview_push(room, x, y, dir) pzw_try_move(room, px, py, dir)
///   pzw_plate_pressed(room, x, y)           pzw_plates_pressed(room)
///   pzw_trace_beam(room, x, y, dir, [cap])  pzw_beams(room)                   pzw_receiver_lit(room, id)
///   pzw_reset(room, [px], [py])             pzw_save(room)                    pzw_load(room, string)
///   pzw_solved(room)

#macro PZW_VERSION "0.1.0"
#macro PZW_SCHEMA 1

/// @function pzw_kinds()
/// @description The vocabularies, as one struct of arrays: terrain, objects, outcomes, beam ends, block materials,
/// boulder materials. Pure.
function pzw_kinds() {
    static _k = {
        terrain: ["floor", "hole", "ice", "water", "wall"],
        objects: ["block", "boulder", "mirror", "plate", "receiver", "emitter"],
        outcomes: ["moved", "blocked", "fell_in_hole", "sank", "slid", "broke"],
        beam: ["receiver", "blocked", "escaped", "looped", "capped"],
        block_materials: ["stone", "wood", "iron", "ice", "gold", "crystal"],
        boulder_materials: ["granite", "basalt", "sandstone"]
    };
    return _k;
}

/// @function pzw_dir_dx(dir)
/// @description The column step of a direction (0 right, 90 up, 180 left, 270 down), or 0. Pure.
function pzw_dir_dx(_d) { switch (_d) { case 0: return 1; case 180: return -1; default: return 0; } }
/// @function pzw_dir_dy(dir)
/// @description The row step of a direction (screen rows grow downward, so up is -1), or 0. Pure.
function pzw_dir_dy(_d) { switch (_d) { case 90: return -1; case 270: return 1; default: return 0; } }
/// @function pzw_dir_ok(dir)
/// @description Is this one of the four directions? Pure.
function pzw_dir_ok(_d) { return is_numeric(_d) && (_d == 0 || _d == 90 || _d == 180 || _d == 270); }

/// @function pzw_room(width, height)
/// @description An empty room of floor. Returns the room struct, or undefined for a size under 1 or over 256. Pure.
function pzw_room(_w, _h) {
    if (!is_numeric(_w) || !is_numeric(_h)) return undefined;
    _w = floor(_w); _h = floor(_h);
    if (_w < 1 || _h < 1 || _w > 256 || _h > 256) return undefined;
    var _rows = array_create(_h);
    for (var _y = 0; _y < _h; _y++) _rows[_y] = array_create(_w, "floor");
    return { pzw_kind: "room", version: PZW_SCHEMA, width: _w, height: _h, terrain: _rows, objects: [], next_id: 1, start_x: 0, start_y: 0 };
}

/// @function pzw_room_from_strings(rows)
/// @description A room from an array of equal-length strings, one character per cell:
///   # wall   . floor   O hole   ~ water   : ice
///   B block (stone)   C crate (wood block)   R boulder   / \ mirrors   P plate   T receiver (target)
///   > < ^ v emitter facing right/left/up/down   @ player start (floor)
/// Objects stand on floor. Unknown characters are floor. Returns the room, or undefined. Pure.
function pzw_room_from_strings(_rows) {
    if (!is_array(_rows) || array_length(_rows) < 1) return undefined;
    var _h = array_length(_rows), _w = 0, _x, _y;
    for (_y = 0; _y < _h; _y++) { if (!is_string(_rows[_y])) return undefined; _w = max(_w, string_length(_rows[_y])); }
    var _r = pzw_room(_w, _h);
    if (is_undefined(_r)) return undefined;
    for (_y = 0; _y < _h; _y++) for (_x = 0; _x < _w; _x++) {
        var _c = (_x < string_length(_rows[_y])) ? string_char_at(_rows[_y], _x + 1) : ".";
        switch (_c) {
            case "#": _r.terrain[_y][_x] = "wall"; break;
            case "O": _r.terrain[_y][_x] = "hole"; break;
            case "~": _r.terrain[_y][_x] = "water"; break;
            case ":": _r.terrain[_y][_x] = "ice"; break;
            case "B": pzw_add(_r, "block", _x, _y, { material: "stone" }); break;
            case "C": pzw_add(_r, "block", _x, _y, { material: "wood" }); break;
            case "R": pzw_add(_r, "boulder", _x, _y, { material: "granite" }); break;
            case "/": pzw_add(_r, "mirror", _x, _y, { facing: "/" }); break;
            case "\\": pzw_add(_r, "mirror", _x, _y, { facing: "\\" }); break;
            case "P": pzw_add(_r, "plate", _x, _y); break;
            case "T": pzw_add(_r, "receiver", _x, _y); break;
            case ">": pzw_add(_r, "emitter", _x, _y, { facing: 0 }); break;
            case "^": pzw_add(_r, "emitter", _x, _y, { facing: 90 }); break;
            case "<": pzw_add(_r, "emitter", _x, _y, { facing: 180 }); break;
            case "v": pzw_add(_r, "emitter", _x, _y, { facing: 270 }); break;
            case "@": _r.start_x = _x; _r.start_y = _y; break;
        }
    }
    return _r;
}

/// @function pzw_is_room(value)
/// @description True for a room struct. Pure.
function pzw_is_room(_v) {
    return is_struct(_v) && variable_struct_exists(_v, "pzw_kind") && _v.pzw_kind == "room" && is_array(_v.terrain) && is_array(_v.objects);
}

/// @function pzw_in(room, x, y)
/// @description Is (x, y) inside the room? Pure.
function pzw_in(_r, _x, _y) { return is_numeric(_x) && is_numeric(_y) && _x >= 0 && _y >= 0 && _x < _r.width && _y < _r.height; }

/// @function pzw_terrain(room, x, y)
/// @description The AUTHORED terrain of a cell. Outside the room reads as "wall", so edges need no special case.
function pzw_terrain(_r, _x, _y) {
    if (!pzw_is_room(_r) || !pzw_in(_r, _x, _y)) return "wall";
    return _r.terrain[floor(_y)][floor(_x)];
}

/// @function pzw_set_terrain(room, x, y, terrain)
/// @description Author a cell's terrain (one of pzw_kinds().terrain). Returns true if set.
function pzw_set_terrain(_r, _x, _y, _t) {
    if (!pzw_is_room(_r) || !pzw_in(_r, _x, _y) || !is_string(_t)) return false;
    var _ok = false, _T = pzw_kinds().terrain;
    for (var _i = 0; _i < array_length(_T); _i++) if (_T[_i] == _t) _ok = true;
    if (!_ok) return false;
    _r.terrain[floor(_y)][floor(_x)] = _t;
    return true;
}

/// @function pzw_add(room, kind, x, y, [props])
/// @description Author an object: kind is one of pzw_kinds().objects. props may carry `material` (blocks,
/// boulders), `facing` ("/" or "\" for a mirror, a direction for an emitter). The object remembers its authored
/// cell as its HOME, which is what makes pzw_reset exact. Returns the object, or undefined.
function pzw_add(_r, _kind, _x, _y, _props = undefined) {
    if (!pzw_is_room(_r) || !is_string(_kind) || !pzw_in(_r, _x, _y)) return undefined;
    var _ok = false, _K = pzw_kinds().objects;
    for (var _i = 0; _i < array_length(_K); _i++) if (_K[_i] == _kind) _ok = true;
    if (!_ok) return undefined;
    var _o = { id: _r.next_id, kind: _kind, x: floor(_x), y: floor(_y), consumed: false, home_x: floor(_x), home_y: floor(_y), material: "", facing: 0 };
    if (_kind == "block") _o.material = "stone";
    if (_kind == "boulder") _o.material = "granite";
    if (_kind == "mirror") _o.facing = "/";
    if (is_struct(_props)) {
        var _names = variable_struct_get_names(_props);
        for (var _j = 0; _j < array_length(_names); _j++) {
            var _n = _names[_j];
            if (_n == "id" || _n == "kind" || _n == "x" || _n == "y" || _n == "consumed" || _n == "home_x" || _n == "home_y") continue;
            _o[$ _n] = _props[$ _n];
        }
    }
    _r.next_id += 1;
    array_push(_r.objects, _o);
    return _o;
}

/// @function pzw_object_at(room, x, y)
/// @description The object standing on a cell (consumed objects are part of the floor now, so they are skipped),
/// or undefined. Pure.
function pzw_object_at(_r, _x, _y) {
    if (!pzw_is_room(_r)) return undefined;
    for (var _i = 0; _i < array_length(_r.objects); _i++) {
        var _o = _r.objects[_i];
        if (_o.x == _x && _o.y == _y && !_o.consumed) return _o;
    }
    return undefined;
}

/// @function pzw_objects(room, [kind])
/// @description Every object (or every one of a kind), consumed ones included, in authoring order. Pure.
function pzw_objects(_r, _kind = undefined) {
    var _out = [];
    if (!pzw_is_room(_r)) return _out;
    for (var _i = 0; _i < array_length(_r.objects); _i++) if (is_undefined(_kind) || _r.objects[_i].kind == _kind) array_push(_out, _r.objects[_i]);
    return _out;
}

/// @function pzw_bridge_at(room, x, y)
/// @description The consumed object resting in a cell - the thing that filled a hole or water - or undefined. Pure.
function pzw_bridge_at(_r, _x, _y) {
    if (!pzw_is_room(_r)) return undefined;
    for (var _i = 0; _i < array_length(_r.objects); _i++) {
        var _o = _r.objects[_i];
        if (_o.consumed && _o.x == _x && _o.y == _y) return _o;
    }
    return undefined;
}

/// @function pzw_is_bridged(room, x, y)
/// @description Has a hole or water at this cell been filled? DERIVED from the consumed object that filled it,
/// never stored (see the file header, decision 1). Pure.
function pzw_is_bridged(_r, _x, _y) {
    var _t = pzw_terrain(_r, _x, _y);
    if (_t != "hole" && _t != "water") return false;
    return !is_undefined(pzw_bridge_at(_r, _x, _y));
}

/// @function pzw_effective_terrain(room, x, y)
/// @description Terrain as it BEHAVES now: a filled hole or water reads as "floor". Pure.
function pzw_effective_terrain(_r, _x, _y) {
    var _t = pzw_terrain(_r, _x, _y);
    if ((_t == "hole" || _t == "water") && !is_undefined(pzw_bridge_at(_r, _x, _y))) return "floor";
    return _t;
}

/// @function pzw_is_fixture(object)
/// @description Is this object flush with the floor (a plate or a receiver)? A pushed object travels ONTO a fixture
/// and a beam passes over it. One rule, used everywhere, so it cannot disagree with itself. Pure.
function pzw_is_fixture(_o) { return is_struct(_o) && variable_struct_exists(_o, "kind") && (_o.kind == "plate" || _o.kind == "receiver"); }

/// @function pzw_is_pushable(object)
/// @description Blocks, boulders and mirrors can be pushed; fixtures and emitters are bolted down. Pure.
function pzw_is_pushable(_o) { return is_struct(_o) && variable_struct_exists(_o, "kind") && (_o.kind == "block" || _o.kind == "boulder" || _o.kind == "mirror"); }

/// @function pzw_is_passable(room, x, y)
/// @description May the player stand on this cell? Floor or ice (or a filled hazard), and nothing solid on it. Pure.
function pzw_is_passable(_r, _x, _y) {
    if (!pzw_is_room(_r) || !pzw_in(_r, _x, _y)) return false;
    var _t = pzw_effective_terrain(_r, _x, _y);
    if (_t != "floor" && _t != "ice") return false;
    var _o = pzw_object_at(_r, _x, _y);
    return is_undefined(_o) || pzw_is_fixture(_o);
}

/// @function pzw_push(room, x, y, dir)
/// @description Push the object at (x, y) one step in `dir` and resolve where it ends up. THE INTERACTION MATRIX,
/// in exactly one place:
///   a block moves one cell, and keeps sliding while it lands on ice;
///   a boulder rolls until stopped, and BREAKS against a wall (consumed, leaving rubble);
///   anything entering a hole falls in, entering water sinks - consumed, and the cell becomes a crossing;
///   another solid object stops travel; a fixture (plate, receiver) is travelled onto.
/// Returns {outcome, object, from_x, from_y, to_x, to_y, tiles}; outcome is one of pzw_kinds().outcomes.
/// Mutates the room only when something moves.
function pzw_push(_r, _x, _y, _dir) {
    var _res = { outcome: "blocked", object: undefined, from_x: _x, from_y: _y, to_x: _x, to_y: _y, tiles: 0 };
    if (!pzw_is_room(_r) || !pzw_dir_ok(_dir)) return _res;
    var _o = pzw_object_at(_r, _x, _y);
    if (is_undefined(_o) || !pzw_is_pushable(_o)) return _res;
    _res.object = _o;
    var _dx = pzw_dir_dx(_dir), _dy = pzw_dir_dy(_dir);
    var _cx = _o.x, _cy = _o.y, _moved = 0, _rolling = (_o.kind == "boulder");
    // at most one step per cell of the room: a travel loop that cannot run away even if a rule is wrong
    for (var _guard = 0; _guard <= _r.width * _r.height; _guard++) {
        var _nx = _cx + _dx, _ny = _cy + _dy;
        // EFFECTIVE terrain: a hazard someone already filled is floor to travel over (reading the authored
        // terrain here would drop a second block into a full hole)
        var _t = pzw_effective_terrain(_r, _nx, _ny);
        var _b = pzw_object_at(_r, _nx, _ny);
        if (_t == "wall") {
            if (_rolling && _moved > 0) {
                _o.x = _cx; _o.y = _cy; _o.consumed = true;
                _res.outcome = "broke"; _res.to_x = _cx; _res.to_y = _cy; _res.tiles = _moved;
                return _res;
            }
            break;
        }
        if (!is_undefined(_b) && !pzw_is_fixture(_b)) break;
        _cx = _nx; _cy = _ny; _moved += 1;
        if (_t == "hole" || _t == "water") {
            // the authored terrain is deliberately NOT changed - the crossing is derived from this consumed object
            _o.x = _cx; _o.y = _cy; _o.consumed = true;
            _res.outcome = (_t == "hole") ? "fell_in_hole" : "sank"; _res.to_x = _cx; _res.to_y = _cy; _res.tiles = _moved;
            return _res;
        }
        if (!_rolling && _t != "ice") break;
    }
    if (_moved == 0) return _res;
    _o.x = _cx; _o.y = _cy;
    _res.outcome = (_moved > 1) ? "slid" : "moved"; _res.to_x = _cx; _res.to_y = _cy; _res.tiles = _moved;
    return _res;
}

/// @function pzw_preview_push(room, x, y, dir)
/// @description What pzw_push WOULD do, changing nothing: it calls pzw_push and restores the three fields a push
/// changes (x, y, consumed) on the one object it can change. The preview cannot disagree with the push because it
/// is the push.
function pzw_preview_push(_r, _x, _y, _dir) {
    var _o = pzw_object_at(_r, _x, _y);
    if (is_undefined(_o)) return pzw_push(undefined, _x, _y, _dir);
    var _sx = _o.x, _sy = _o.y, _sc = _o.consumed;
    var _res = pzw_push(_r, _x, _y, _dir);
    _o.x = _sx; _o.y = _sy; _o.consumed = _sc;
    return _res;
}

/// @function pzw_try_move(room, px, py, dir)
/// @description The player at (px, py) tries to step in `dir`: into a free cell, or by pushing what stands there
/// and following it in if the push freed the cell. Returns {moved, x, y, push} where push is the pzw_push result
/// (or undefined when nothing was pushed). The player does not slide on ice.
function pzw_try_move(_r, _px, _py, _dir) {
    var _res = { moved: false, x: _px, y: _py, push: undefined };
    if (!pzw_is_room(_r) || !pzw_dir_ok(_dir) || !is_numeric(_px) || !is_numeric(_py)) return _res;
    var _nx = _px + pzw_dir_dx(_dir), _ny = _py + pzw_dir_dy(_dir);
    var _o = pzw_object_at(_r, _nx, _ny);
    if (!is_undefined(_o) && pzw_is_pushable(_o)) {
        _res.push = pzw_push(_r, _nx, _ny, _dir);
        if (_res.push.outcome == "blocked") return _res;
    }
    if (pzw_is_passable(_r, _nx, _ny)) { _res.moved = true; _res.x = _nx; _res.y = _ny; }
    return _res;
}

/// @function pzw_plate_pressed(room, x, y)
/// @description Is the plate at (x, y) pressed? A standing block or boulder on it presses it. Derived, never
/// stored. (The player standing on it is yours to add: `pzw_plate_pressed(...) || (px == x && py == y)`.) Pure.
function pzw_plate_pressed(_r, _x, _y) {
    if (!pzw_is_room(_r)) return false;
    for (var _i = 0; _i < array_length(_r.objects); _i++) {
        var _o = _r.objects[_i];
        if (_o.consumed || _o.x != _x || _o.y != _y) continue;
        if (_o.kind == "block" || _o.kind == "boulder") return true;
    }
    return false;
}

/// @function pzw_plates_pressed(room)
/// @description How many of the room's plates are pressed, as {pressed, total}. Pure.
function pzw_plates_pressed(_r) {
    var _out = { pressed: 0, total: 0 };
    if (!pzw_is_room(_r)) return _out;
    var _P = pzw_objects(_r, "plate");
    for (var _i = 0; _i < array_length(_P); _i++) { _out.total += 1; if (pzw_plate_pressed(_r, _P[_i].x, _P[_i].y)) _out.pressed += 1; }
    return _out;
}

/// @function pzw_reflect(facing, dir)
/// @description The direction a beam leaves a mirror. A mirror turns a beam 90 degrees and never reverses it.
/// "/" : right->up, up->right, left->down, down->left.  "\" : right->down, down->right, left->up, up->left.
/// Returns -1 for an unknown facing. Pure.
function pzw_reflect(_f, _d) {
    if (_f == "/") { switch (_d) { case 0: return 90; case 90: return 0; case 180: return 270; case 270: return 180; } }
    if (_f == "\\") { switch (_d) { case 0: return 270; case 270: return 0; case 180: return 90; case 90: return 180; } }
    return -1;
}

/// @function pzw_trace_beam(room, x, y, dir, [max_bounces])
/// @description Trace light from (x, y) travelling `dir`, through mirrors, to whatever stops it. Returns
/// {outcome, cells:[{x, y, dir}], bounces, receiver_id}; outcome is one of pzw_kinds().beam. The path starts at
/// the origin cell and has one entry per cell the light occupies. Blocks, boulders and emitters stop light;
/// plates, holes, water and ice do not.
/// TERMINATION IS GUARANTEED BY CONSTRUCTION: the beam's whole state is (cell, direction), every state visited is
/// recorded, and the first repeat ends the trace as "looped" - keyed on DIRECTION too, because a beam crossing its
/// own path at right angles is legal. The bounce cap is only a backstop (default: one per cell, at least 64).
/// ⚠️ Allocates; call it when the room CHANGES and cache the result for drawing, not every frame.
function pzw_trace_beam(_r, _x, _y, _dir, _cap = -1) {
    var _res = { outcome: "blocked", cells: [], bounces: 0, receiver_id: -1 };
    if (!pzw_is_room(_r) || !pzw_dir_ok(_dir) || !pzw_in(_r, _x, _y)) return _res;
    if (pzw_terrain(_r, _x, _y) == "wall") return _res;
    var _max = (is_numeric(_cap) && _cap >= 1) ? floor(_cap) : max(64, _r.width * _r.height);
    var _seen = {}, _cx = _x, _cy = _y, _cd = _dir;
    array_push(_res.cells, { x: _x, y: _y, dir: _dir });
    _seen[$ string(_x) + "," + string(_y) + "," + string(_dir)] = 1;
    for (var _guard = 0; _guard <= _r.width * _r.height * 4 + 4; _guard++) {
        var _nx = _cx + pzw_dir_dx(_cd), _ny = _cy + pzw_dir_dy(_cd);
        // bounds BEFORE terrain: pzw_terrain reads outside as wall and would report an escaping beam as blocked
        if (!pzw_in(_r, _nx, _ny)) { _res.outcome = "escaped"; return _res; }
        if (pzw_terrain(_r, _nx, _ny) == "wall") { _res.outcome = "blocked"; return _res; }
        var _key = string(_nx) + "," + string(_ny) + "," + string(_cd);
        var _o = pzw_object_at(_r, _nx, _ny);
        if (!is_undefined(_o)) {
            if (_o.kind == "receiver") {
                array_push(_res.cells, { x: _nx, y: _ny, dir: _cd });
                _res.outcome = "receiver"; _res.receiver_id = _o.id;
                return _res;
            }
            if (_o.kind == "mirror") {
                var _nd = pzw_reflect(_o.facing, _cd);
                if (_nd < 0) { _res.outcome = "blocked"; return _res; }   // a mirror with no usable facing stops light, visibly
                if (variable_struct_exists(_seen, _key)) { _res.outcome = "looped"; return _res; }
                _seen[$ _key] = 1;
                array_push(_res.cells, { x: _nx, y: _ny, dir: _cd });
                _res.bounces += 1;
                if (_res.bounces > _max) { _res.outcome = "capped"; _res.bounces = _max; return _res; }
                _cx = _nx; _cy = _ny; _cd = _nd;
                continue;
            }
            if (!pzw_is_fixture(_o)) { _res.outcome = "blocked"; return _res; }
        }
        if (variable_struct_exists(_seen, _key)) { _res.outcome = "looped"; return _res; }
        _seen[$ _key] = 1;
        array_push(_res.cells, { x: _nx, y: _ny, dir: _cd });
        _cx = _nx; _cy = _ny;
    }
    _res.outcome = "capped";
    return _res;
}

/// @function pzw_beams(room)
/// @description Trace every emitter's beam (starting in the emitter's own cell, travelling its facing). Returns an
/// array of {emitter_id, trace} in authoring order. ⚠️ Allocates; call it when the room changes.
function pzw_beams(_r) {
    var _out = [];
    if (!pzw_is_room(_r)) return _out;
    var _E = pzw_objects(_r, "emitter");
    for (var _i = 0; _i < array_length(_E); _i++) {
        var _e = _E[_i];
        if (_e.consumed) continue;
        // the beam leaves the emitter's cell; the emitter itself does not block its own light
        var _nx = _e.x + pzw_dir_dx(_e.facing), _ny = _e.y + pzw_dir_dy(_e.facing), _tr;
        if (!pzw_dir_ok(_e.facing)) _tr = { outcome: "blocked", cells: [], bounces: 0, receiver_id: -1 };
        else if (!pzw_in(_r, _nx, _ny)) _tr = { outcome: "escaped", cells: [{ x: _e.x, y: _e.y, dir: _e.facing }], bounces: 0, receiver_id: -1 };
        else {
            _tr = pzw_trace_beam(_r, _e.x, _e.y, _e.facing);
        }
        array_push(_out, { emitter_id: _e.id, trace: _tr });
    }
    return _out;
}

/// @function pzw_receiver_lit(room, id)
/// @description Is the receiver with this id lit by any emitter's beam? Pure (allocates; cache it with the beams).
function pzw_receiver_lit(_r, _id) {
    var _B = pzw_beams(_r);
    for (var _i = 0; _i < array_length(_B); _i++) if (_B[_i].trace.outcome == "receiver" && _B[_i].trace.receiver_id == _id) return true;
    return false;
}

/// @function pzw_solved(room)
/// @description The room's goals, counted: {plates_pressed, plates, receivers_lit, receivers, solved}. A room is
/// solved when every plate is pressed and every receiver is lit (a room with neither is never "solved"). Pure.
function pzw_solved(_r) {
    var _out = { plates_pressed: 0, plates: 0, receivers_lit: 0, receivers: 0, solved: false };
    if (!pzw_is_room(_r)) return _out;
    var _pp = pzw_plates_pressed(_r);
    _out.plates_pressed = _pp.pressed; _out.plates = _pp.total;
    var _R = pzw_objects(_r, "receiver"), _B = pzw_beams(_r);
    for (var _i = 0; _i < array_length(_R); _i++) {
        _out.receivers += 1;
        for (var _j = 0; _j < array_length(_B); _j++) if (_B[_j].trace.outcome == "receiver" && _B[_j].trace.receiver_id == _R[_i].id) { _out.receivers_lit += 1; break; }
    }
    _out.solved = (_out.plates + _out.receivers > 0) && _out.plates_pressed == _out.plates && _out.receivers_lit == _out.receivers;
    return _out;
}

/// @function pzw_reset(room, [px], [py])
/// @description Put every object back where it was authored and un-consume it - the room exactly as built, because
/// the filled holes were derived and there is no terrain to restore. If you pass the player's cell, the result
/// says whether the reset pulled the floor out from under them (they stood on a crossing that is a hole again),
/// so you can send them to the room's entrance. Returns {stranded}.
function pzw_reset(_r, _px = undefined, _py = undefined) {
    var _res = { stranded: false };
    if (!pzw_is_room(_r)) return _res;
    var _test = is_numeric(_px) && is_numeric(_py);
    var _was = _test ? pzw_is_passable(_r, _px, _py) : false;
    for (var _i = 0; _i < array_length(_r.objects); _i++) {
        var _o = _r.objects[_i];
        _o.x = _o.home_x; _o.y = _o.home_y; _o.consumed = false;
    }
    if (_test) _res.stranded = _was && !pzw_is_passable(_r, _px, _py);
    return _res;
}

/// @function pzw_save(room)
/// @description ONLY what play changed - each object's id, cell and consumed flag - as a string for your save file.
/// The authored layout is not saved, so a save can never contradict the room it was made in. "" for a non-room.
function pzw_save(_r) {
    if (!pzw_is_room(_r)) return "";
    var _o = [];
    for (var _i = 0; _i < array_length(_r.objects); _i++) {
        var _b = _r.objects[_i];
        array_push(_o, [_b.id, _b.x, _b.y, _b.consumed ? 1 : 0]);
    }
    return json_stringify({ v: PZW_SCHEMA, o: _o });
}

/// @function pzw_load(room, string)
/// @description Apply a pzw_save string onto the freshly authored room. Records for ids the room does not have, and
/// cells outside it, are skipped; anything unreadable changes nothing. Returns how many objects were restored.
function pzw_load(_r, _s) {
    if (!pzw_is_room(_r) || !is_string(_s) || _s == "") return 0;
    var _raw = undefined;
    try { _raw = json_parse(_s); } catch (_e) { _raw = undefined; }
    if (!is_struct(_raw) || !variable_struct_exists(_raw, "o") || !is_array(_raw.o)) return 0;
    var _n = 0;
    for (var _i = 0; _i < array_length(_raw.o); _i++) {
        var _rec = _raw.o[_i];
        if (!is_array(_rec) || array_length(_rec) < 4 || !is_numeric(_rec[0]) || !pzw_in(_r, _rec[1], _rec[2])) continue;
        for (var _j = 0; _j < array_length(_r.objects); _j++) {
            var _b = _r.objects[_j];
            if (_b.id == _rec[0]) { _b.x = _rec[1]; _b.y = _rec[2]; _b.consumed = (_rec[3] == 1); _n += 1; break; }
        }
    }
    return _n;
}
