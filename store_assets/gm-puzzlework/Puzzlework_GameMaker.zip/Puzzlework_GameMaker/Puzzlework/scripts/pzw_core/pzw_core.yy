{
  "$GMScript": "v1",
  "%Name": "pzw_core",
  "name": "pzw_core",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}