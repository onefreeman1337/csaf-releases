/// pzw_demo.gml - the demo room's screen as one function, so the demo object and the store bake draw the SAME screen
/// (the bake photographs it; nothing else can see the demo room).
///
/// Puzzlework - Dungeon Puzzles Without Scripting Each Block, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
/// Not needed by the library: delete it with obj_pzw_demo and rm_pzw_demo.

/// @function pzw_demo_draw(room, beams, px, py, message, time, w, h)
/// @description The room sized to the screen, the goals and the last thing that happened beneath it.
function pzw_demo_draw(_r, _beams, _px, _py, _msg, _t, _gw, _gh) {
    pzw_rect_fill(0, 0, _gw, _gh, make_colour_rgb(20, 18, 20));
    var _ext = pzw_room_extent(_r, 1);
    var _c = floor(min((_gw - 40) / _ext.w, (_gh - 110) / _ext.h));
    pzw_room_draw(_r, (_gw - _ext.w * _c) * 0.5, 20, _c, { beams: _beams, player_x: _px, player_y: _py, time: _t });
    var _s = pzw_solved(_r);
    pzw_text(_gw * 0.5, _gh - 76, _msg, 20, make_colour_rgb(236, 226, 206), fa_center, fa_top, fnt_puzzlework, 1, _gw - 40);
    pzw_text(_gw * 0.5, _gh - 44, "plates " + string(_s.plates_pressed) + "/" + string(_s.plates) + "     light " + string(_s.receivers_lit) + "/" + string(_s.receivers)
        + "        [arrows] walk and push     [R] reset the room", 15, make_colour_rgb(170, 158, 140), fa_center, fa_top, fnt_puzzlework_ui, 1, _gw - 40);
}
