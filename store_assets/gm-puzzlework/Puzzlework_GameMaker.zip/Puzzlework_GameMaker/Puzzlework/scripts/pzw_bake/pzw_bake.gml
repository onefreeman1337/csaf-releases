/// pzw_bake.gml - renders the store sheets THROUGH THE PRODUCT'S OWN DRAW CODE (`Puzzlework.exe -bake`, `-gif`), so
/// the listing can truthfully say every image on the page was drawn by the thing being sold. Not needed at runtime:
/// a buyer may delete this script with the -bake/-gif branches of the demo object's Create event.
///
/// Puzzlework - Dungeon Puzzles Without Scripting Each Block, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
/// ⛔ NOTHING IN THIS FILE CAN SEE A PICTURE. The ink box catches a CLIPPED or EMPTY sheet and nothing else.

/// @function pzw_bake_ground()
function pzw_bake_ground() { return make_colour_rgb(20, 18, 20); }

/// @function pzw_bake_opaque(w, h)
function pzw_bake_opaque(_w, _h) {
    gpu_set_colorwriteenable(false, false, false, true);
    pzw_rect_fill(0, 0, _w, _h, c_white, 1);
    gpu_set_colorwriteenable(true, true, true, true);
}

/// @function pzw_bake_ink(surface, w, h, ground)
/// @description The ink bounding box and sample count of a finished sheet: every row, every second column.
function pzw_bake_ink(_sf, _w, _h, _ground) {
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    var _x0 = _w, _y0 = _h, _x1 = -1, _y1 = -1, _n = 0;
    var _gr = colour_get_red(_ground), _gg = colour_get_green(_ground), _gb = colour_get_blue(_ground);
    for (var _y = 0; _y < _h; _y++) for (var _x = 0; _x < _w; _x += 2) {
        var _o = (_y * _w + _x) * 4;
        if (abs(buffer_peek(_b, _o, buffer_u8) - _gr) > 10 || abs(buffer_peek(_b, _o + 1, buffer_u8) - _gg) > 10 || abs(buffer_peek(_b, _o + 2, buffer_u8) - _gb) > 10) {
            _n++; if (_x < _x0) _x0 = _x; if (_x > _x1) _x1 = _x; if (_y < _y0) _y0 = _y; if (_y > _y1) _y1 = _y;
        }
    }
    buffer_delete(_b);
    return { x0: _x0, y0: _y0, x1: _x1, y1: _y1, px: _n };
}

/// @function pzw_bake_sheet(name, w, h, fn)
/// @description Render a sheet at 2x, filter it down, measure its ink, save it, log it.
function pzw_bake_sheet(_name, _w, _h, _fn) {
    var _big = surface_create(_w * 2, _h * 2);
    surface_set_target(_big); draw_clear(pzw_bake_ground()); _fn(_w * 2, _h * 2); pzw_bake_opaque(_w * 2, _h * 2); surface_reset_target();
    var _sf = surface_create(_w, _h);
    surface_set_target(_sf); draw_clear(pzw_bake_ground());
    var _prev = gpu_get_texfilter(); gpu_set_texfilter(true); draw_surface_ext(_big, 0, 0, 0.5, 0.5, 0, c_white, 1); gpu_set_texfilter(_prev);
    pzw_bake_opaque(_w, _h); surface_reset_target();
    surface_free(_big);
    var _ink = pzw_bake_ink(_sf, _w, _h, pzw_bake_ground());
    surface_save(_sf, "pzw_sheet_" + _name + ".png");
    surface_free(_sf);
    array_push(global.pzw_bake_log, { sheet: _name, w: _w, h: _h, px: _ink.px, x0: _ink.x0, y0: _ink.y0, x1: _ink.x1, y1: _ink.y1 });
}

/// @function pzw_bake_head(w, title, sub, k)
function pzw_bake_head(_w, _title, _sub, _k) {
    pzw_text(_w * 0.5, 22 * _k, _title, 44 * _k, make_colour_rgb(236, 226, 206), fa_center, fa_top, fnt_puzzlework_title, 1, _w * 0.9);
    pzw_text(_w * 0.5, 74 * _k, _sub, 20 * _k, make_colour_rgb(176, 164, 146), fa_center, fa_top, fnt_puzzlework, 1, _w * 0.9);
}

/// @function pzw_atlas_entries()
/// @description Every distinct thing the renderer draws, as [label, kind, arg1, arg2]: the volume claim, listed.
/// kind: "block" (material), "boulder" (material), "sunk" (material, terrain), "rubble" (material), "terrain"
/// (terrain), "object" (object kind, variant). Pure.
function pzw_atlas_entries() {
    var _e = [], _i, _K = pzw_kinds();
    for (_i = 0; _i < array_length(_K.block_materials); _i++) array_push(_e, [_K.block_materials[_i] + " block", "block", _K.block_materials[_i], ""]);
    for (_i = 0; _i < array_length(_K.boulder_materials); _i++) array_push(_e, [_K.boulder_materials[_i] + " boulder", "boulder", _K.boulder_materials[_i], ""]);
    array_push(_e, ["mirror /", "object", "mirror", "/"], ["mirror \\", "object", "mirror", "\\"]);
    array_push(_e, ["plate", "object", "plate", "up"], ["plate, pressed", "object", "plate", "down"]);
    array_push(_e, ["receiver", "object", "receiver", "dark"], ["receiver, lit", "object", "receiver", "lit"]);
    array_push(_e, ["emitter east", "object", "emitter", 0], ["emitter north", "object", "emitter", 90], ["emitter west", "object", "emitter", 180], ["emitter south", "object", "emitter", 270]);
    array_push(_e, ["floor", "terrain", "floor", ""], ["wall", "terrain", "wall", ""], ["pit", "terrain", "hole", ""], ["water", "terrain", "water", ""], ["ice", "terrain", "ice", ""]);
    for (_i = 0; _i < array_length(_K.block_materials); _i++) array_push(_e, [_K.block_materials[_i] + " bridge", "sunk", _K.block_materials[_i], "hole"]);
    for (_i = 0; _i < array_length(_K.block_materials); _i++) array_push(_e, [_K.block_materials[_i] + " ford", "sunk", _K.block_materials[_i], "water"]);
    for (_i = 0; _i < array_length(_K.boulder_materials); _i++) array_push(_e, [_K.boulder_materials[_i] + " in a pit", "sunkb", _K.boulder_materials[_i], "hole"]);
    for (_i = 0; _i < array_length(_K.boulder_materials); _i++) array_push(_e, [_K.boulder_materials[_i] + " in water", "sunkb", _K.boulder_materials[_i], "water"]);
    for (_i = 0; _i < array_length(_K.boulder_materials); _i++) array_push(_e, [_K.boulder_materials[_i] + " rubble", "rubble", _K.boulder_materials[_i], ""]);
    return _e;
}

/// @function pzw_bake_entry(entry, x, y, c)
/// @description Draw one atlas entry on its own floor cell (top-left x, y) - through the same functions the room uses.
function pzw_bake_entry(_e, _x, _y, _c) {
    switch (_e[1]) {
        case "terrain":
            if (_e[2] == "wall") {
                pzw_draw_terrain("floor", _x, _y, _c, 0.1);
                var _wr = pzw_room_from_strings(["#"]);
                pzw_room_draw(_wr, _x, _y - _c * PZW_H_WALL, _c, { beams: [] });
            } else pzw_draw_terrain(_e[2], _x, _y, _c, 0.6, 0.4);
            break;
        case "block": pzw_draw_terrain("floor", _x, _y, _c, 0.3); pzw_draw_object({ id: 1, kind: "block", material: _e[2], consumed: false }, _x, _y, _c); break;
        case "boulder": pzw_draw_terrain("floor", _x, _y, _c, 0.3); pzw_draw_object({ id: 7, kind: "boulder", material: _e[2], consumed: false }, _x, _y, _c); break;
        case "sunk": pzw_draw_terrain(_e[3], _x, _y, _c, 0.5, 0.4); pzw_draw_sunk({ id: 1, kind: "block", material: _e[2], consumed: true }, _e[3], _x, _y, _c, 0.4); break;
        case "sunkb": pzw_draw_terrain(_e[3], _x, _y, _c, 0.5, 0.4); pzw_draw_sunk({ id: 7, kind: "boulder", material: _e[2], consumed: true }, _e[3], _x, _y, _c, 0.4); break;
        case "rubble": pzw_draw_terrain("floor", _x, _y, _c, 0.3); pzw_draw_rubble(_e[2], _x, _y, _c, 3); break;
        default:
            pzw_draw_terrain("floor", _x, _y, _c, 0.3);
            var _o = { id: 3, kind: _e[2], consumed: false, facing: _e[3], material: "" };
            if (_e[2] == "emitter") _o.facing = _e[3];
            pzw_draw_object(_o, _x, _y, _c, (_e[3] == "down" || _e[3] == "lit"), 0.3);
            break;
    }
}

/// @function pzw_bake_atlas(w, h)
function pzw_bake_atlas(_w, _h) {
    var _k = 2, _E = pzw_atlas_entries(), _n = array_length(_E);
    pzw_bake_head(_w, string(_n) + " THINGS, EVERY ONE DRAWN BY THE PACKAGE", "Six block materials, three boulders, the machines, the ground, and what a block or boulder becomes when it falls in.", _k);
    var _cols = 9, _rows = ceil(_n / _cols), _top = 124 * _k, _pad = 30 * _k;
    var _cw = (_w - _pad * 2) / _cols, _ch = (_h - _top - _pad) / _rows;
    var _c = min(_cw * 0.62, (_ch - 26 * _k) / (1 + PZW_H_WALL) * 0.95);
    for (var _i = 0; _i < _n; _i++) {
        var _cx = _pad + (_i mod _cols) * _cw + (_cw - _c) * 0.5, _cy = _top + (_i div _cols) * _ch + _c * PZW_H_WALL;
        pzw_bake_entry(_E[_i], _cx, _cy, _c);
        pzw_text(_cx + _c * 0.5, _cy + _c + 6 * _k, string_upper(_E[_i][0]), 11 * _k, make_colour_rgb(196, 184, 164), fa_center, fa_top, fnt_puzzlework, 1, _cw * 0.95);
    }
}

/// @function pzw_bake_room_rows()
/// @description The hero room: a beam to bend, a plate to press, a pit to bridge, ice to slide on, water to ford. Pure.
function pzw_bake_room_rows() {
    static _a = ["###############",
                 "#>....\\..~~~..#",
                 "#.....:::.~~..#",
                 "#.B...:::...R.#",
                 "#....O........#",
                 "#..PC......../#",
                 "#.....\\.T.....#",
                 "###############"];
    return _a;
}

/// @function pzw_bake_solved_room()
/// @description The hero room mid-solve: the stone block shoved three times and dropped into the pit (a bridge), the
/// crate shoved onto the plate, the beam bent twice onto the receiver. Pure.
function pzw_bake_solved_room() {
    var _r = pzw_room_from_strings(pzw_bake_room_rows());
    pzw_push(_r, 2, 3, 0); pzw_push(_r, 3, 3, 0); pzw_push(_r, 4, 3, 0); pzw_push(_r, 5, 3, 270);
    pzw_push(_r, 4, 5, 180);
    return _r;
}

/// @function pzw_bake_room(w, h)
function pzw_bake_room(_w, _h) {
    var _k = 2, _r = pzw_bake_solved_room();
    var _ext = pzw_room_extent(_r, 1), _c = min((_w - 60 * _k) / _ext.w, (_h - 150 * _k) / _ext.h);
    var _rx = (_w - _ext.w * _c) * 0.5, _ry = 128 * _k;
    pzw_bake_head(_w, "PUZZLE ROOMS THAT DRAW THEMSELVES", "A beam bent by a mirror, a pit bridged by a block, ice, water, a boulder waiting to roll. No image files.", _k);
    pzw_room_draw(_r, _rx, _ry, _c, { time: 0.8, player_x: 7, player_y: 4 });
}

/// @function pzw_bake_arrow(x1, y1, x2, y2, w, colour)
/// @description A drawn arrow from (x1, y1) to (x2, y2).
function pzw_bake_arrow(_x1, _y1, _x2, _y2, _w, _col) {
    var _dx = _x2 - _x1, _dy = _y2 - _y1, _l = max(0.001, sqrt(_dx * _dx + _dy * _dy)), _ux = _dx / _l, _uy = _dy / _l;
    pzw_seg(_x1, _y1, _x2 - _ux * _w * 2.2, _y2 - _uy * _w * 2.2, _w, _col, 0.95);
    pzw_fill_convex([_x2, _y2, _x2 - _ux * _w * 3 - _uy * _w * 1.6, _y2 - _uy * _w * 3 + _ux * _w * 1.6, _x2 - _ux * _w * 3 + _uy * _w * 1.6, _y2 - _uy * _w * 3 - _ux * _w * 1.6], _col, 0.95);
}

/// @function pzw_bake_rules(w, h)
/// @description ONE RULE BOOK FOR EVERY SHOVE: six small rooms, each shown AFTER one push, with an arrow from where the
/// object started - every outcome computed by pzw_push, every caption the outcome it returned.
function pzw_bake_rules(_w, _h) {
    var _k = 2;
    pzw_bake_head(_w, "EVERY SHOVE, RESOLVED IN ONE PLACE", "Six rooms, one push each. The arrow is where the thing went; the caption is what pzw_push returned.", _k);
    var _cases = [
        [["#######", "#.B...#", "......."], 2, 1, "A BLOCK MOVES ONE SQUARE"],
        [["#######", "#B:::.#", "......."], 1, 1, "ON ICE IT SLIDES"],
        [["#######", "#..BO.#", "......."], 3, 1, "INTO A PIT: A BRIDGE"],
        [["#######", "#.C.~.#", "......."], 2, 1, "INTO WATER: A FORD"],
        [["#######", "#R....#", "......."], 1, 1, "A BOULDER ROLLS AND BREAKS"],
        [["#######", "#..BP.#", "......."], 3, 1, "ONTO A PLATE"]];
    var _cols = 3, _top = 128 * _k, _cw = (_w - 60 * _k) / _cols, _chh = (_h - _top - 20 * _k) / 2;
    var _c = min((_cw - 30 * _k) / 7, (_chh - 70 * _k) / (3 + PZW_H_WALL));
    for (var _i = 0; _i < 6; _i++) {
        var _cs = _cases[_i], _r = pzw_room_from_strings(_cs[0]);
        if (_i == 3) pzw_push(_r, 2, 1, 0);   // the crate first walks one square to the water's edge
        var _sx = (_i == 3) ? 3 : _cs[1], _p = pzw_push(_r, _sx, _cs[2], 0);
        var _rx = 30 * _k + (_i mod _cols) * _cw + (_cw - 7 * _c) * 0.5, _ry = _top + (_i div _cols) * _chh;
        pzw_room_draw(_r, _rx, _ry, _c, { time: 0.4, beams: [] });
        var _oy = _ry + _c * PZW_H_WALL, _ay = _oy + _c * 1.5 - _c * 0.62;
        pzw_bake_arrow(_rx + (_sx + 0.5) * _c, _ay, _rx + (_p.to_x + 0.5) * _c, _ay, max(2, _c * 0.07), make_colour_rgb(255, 214, 120));
        pzw_text(_rx + 3.5 * _c, _oy + _c * 3 + 12 * _k, _cs[3], 17 * _k, make_colour_rgb(236, 226, 206), fa_center, fa_top, fnt_puzzlework_title, 1, _cw * 0.95);
        pzw_text(_rx + 3.5 * _c, _oy + _c * 3 + 38 * _k, "\"" + _p.outcome + "\", " + string(_p.tiles) + ((_p.tiles == 1) ? " square" : " squares"), 13 * _k, make_colour_rgb(176, 164, 146), fa_center, fa_top, fnt_puzzlework_ui, 1, _cw * 0.95);
    }
}

/// @function pzw_bake_light(w, h)
/// @description HOW LIGHT BEHAVES: a mirror maze solved; light stopped by a block; and a ring of four mirrors that would
/// trap a naive tracer forever, reported as a loop after four bounces.
function pzw_bake_light(_w, _h) {
    var _k = 2;
    pzw_bake_head(_w, "LIGHT THAT CANNOT HANG YOUR GAME", "Beams bend on mirrors, pass over plates, pits and water, stop at blocks, and a mirror loop is detected, not timed out.", _k);
    // ⚠️ ONE LARGE ROOM, NOT A ROW OF SMALL ONES: three framed rooms side by side hashed d=8 against the rules sheet
    // (also a row of framed rooms) - the same picture twice in a buyer's thumbnail strip. Composition, never threshold.
    var _big = pzw_room_from_strings(["###########", "#>..\\.....#", "#T.......<#", "#...O.....#", "#T../..B..#", "#......~~.#", "###########"]);
    var _loop = pzw_room_from_strings(["#########", "#.......#", "#./..\\..#", "#.......#", "#.\\../..#", "#########"]);
    var _top = 124 * _k, _lw = _w * 0.60, _bc = min((_lw - 40 * _k) / 11, (_h - _top - 30 * _k) / (7 + PZW_H_WALL));
    var _B = pzw_beams(_big);
    pzw_room_draw(_big, 30 * _k, _top, _bc, { time: 0.4, beams: _B });
    var _lit = 0, _bn = 0;
    for (var _i = 0; _i < array_length(_B); _i++) { if (_B[_i].trace.outcome == "receiver") _lit++; _bn += _B[_i].trace.bounces; }
    var _rx0 = 30 * _k + _lw, _rw = _w - _rx0 - 30 * _k, _mid = _rx0 + _rw * 0.5;
    pzw_text(_mid, _top + 6 * _k, "TWO BEAMS CROSS, BOTH ARRIVE", 19 * _k, make_colour_rgb(236, 226, 206), fa_center, fa_top, fnt_puzzlework_title, 1, _rw);
    pzw_text(_mid, _top + 36 * _k, string(_lit) + " of " + string(array_length(_B)) + " receivers lit, " + string(_bn) + ((_bn == 1) ? " bounce" : " bounces") + "; one crosses a pit", 14 * _k, make_colour_rgb(176, 164, 146), fa_center, fa_top, fnt_puzzlework_ui, 1, _rw);
    var _tr = pzw_trace_beam(_loop, 3, 2, 0), _lc = min((_rw - 20 * _k) / 9, (_h - _top - 170 * _k) / (6 + PZW_H_WALL));
    var _lx = _mid - 4.5 * _lc, _ly = _top + 80 * _k;
    pzw_room_draw(_loop, _lx, _ly, _lc, { time: 0.4, beams: [{ emitter_id: 0, trace: _tr }] });
    var _by = _ly + _lc * (6 + PZW_H_WALL) + 14 * _k;
    pzw_text(_mid, _by, "FOUR MIRRORS: A LOOP", 19 * _k, make_colour_rgb(236, 226, 206), fa_center, fa_top, fnt_puzzlework_title, 1, _rw);
    pzw_text(_mid, _by + 30 * _k, "\"" + _tr.outcome + "\" after " + string(_tr.bounces) + " bounces, and the trace ends", 14 * _k, make_colour_rgb(176, 164, 146), fa_center, fa_top, fnt_puzzlework_ui, 1, _rw);
}

/// @function pzw_bake_materials(w, h)
/// @description THE SIX BLOCKS, CLOSE: each block redrawn at a cell of ~200 px - a real redraw, never a scaled bitmap.
function pzw_bake_materials(_w, _h) {
    var _k = 2, _K = pzw_kinds().block_materials;
    pzw_bake_head(_w, "SIX MATERIALS, DRAWN AT ANY SIZE", "Stone, wood, iron, ice, gold and crystal: each one's carving, planks, rivets, facets or glow drawn by the package.", _k);
    var _cw = (_w - 40 * _k) / 6, _c = min(_cw * 0.72, (_h - 128 * _k - 80 * _k) / (1 + PZW_H_BLOCK + 0.3));
    for (var _i = 0; _i < 6; _i++) {
        var _x = 20 * _k + _i * _cw + (_cw - _c) * 0.5, _y = 128 * _k + _c * PZW_H_BLOCK + 30 * _k;
        pzw_draw_terrain("floor", _x, _y, _c, pzw_hash2(_i, 0, "mat"));
        pzw_draw_object({ id: _i + 1, kind: "block", material: _K[_i], consumed: false }, _x, _y, _c);
        pzw_text(_x + _c * 0.5, _y + _c * 1.2 + 14 * _k, string_upper(_K[_i]), 22 * _k, make_colour_rgb(236, 226, 206), fa_center, fa_top, fnt_puzzlework_title, 1, _cw * 0.95);
    }
}

/// @function pzw_bake_demo(w, h)
/// @description THE DEMO ROOM, photographed at 1280x720 after two moves - a verification image, not a store image.
function pzw_bake_demo(_w, _h) {
    var _r = pzw_room_from_strings(pzw_bake_room_rows()), _px = 3, _py = 3;
    var _m = pzw_try_move(_r, _px, _py, 180); _px = _m.x; _py = _m.y;
    matrix_set(matrix_world, matrix_build(0, 0, 0, 0, 0, 0, 2, 2, 1));
    pzw_demo_draw(_r, pzw_beams(_r), _px, _py, "Shoved one square.", 0.6, _w / 2, _h / 2);
    matrix_set(matrix_world, matrix_build_identity());
}

/// @function pzw_gif_rows()
/// @description The GIF's room: a block shadowing the beam over a pit, a crate beside a plate. Pure.
function pzw_gif_rows() {
    static _a = ["##########",
                 "#...@....#",
                 "#>..B..\\.#",
                 "#...O....#",
                 "#....CP..#",
                 "#......T.#",
                 "##########"];
    return _a;
}

/// @function pzw_gif_moves()
/// @description The solve, as player moves: shove the block down into the pit (the beam is free), walk across the
/// new bridge, shove the crate onto the plate. Pure.
function pzw_gif_moves() { static _m = [270, 270, 270, 0]; return _m; }

/// @function pzw_bake_pad4(n)
function pzw_bake_pad4(_n) {
    _n = clamp(floor(is_real(_n) ? _n : 0), 0, 9999);
    var _s = string(_n);
    while (string_length(_s) < 4) _s = "0" + _s;
    return _s;
}

/// @function pzw_bake_gif_frame(room, px, py, big, sf, n, t, note)
function pzw_bake_gif_frame(_r, _px, _py, _big, _sf, _n, _t, _note) {
    var _k = 2, _W = 640, _H = 400;
    surface_set_target(_big); draw_clear(pzw_bake_ground());
    var _ext = pzw_room_extent(_r, 1), _c = min(480 * _k / _ext.w, (_H - 30) * _k / _ext.h);
    pzw_room_draw(_r, 16 * _k, 15 * _k, _c, { time: _t, player_x: _px, player_y: _py });
    var _s = pzw_solved(_r), _rx = 16 * _k + _ext.w * _c + 10 * _k, _rw = _W * _k - _rx - 12 * _k, _mid = _rx + _rw * 0.5;
    pzw_text(_mid, 40 * _k, "PLATES", 13 * _k, make_colour_rgb(176, 164, 146), fa_center, fa_top, fnt_puzzlework, 1, _rw);
    pzw_text(_mid, 60 * _k, string(_s.plates_pressed) + " / " + string(_s.plates), 34 * _k, (_s.plates_pressed == _s.plates) ? make_colour_rgb(150, 255, 180) : make_colour_rgb(236, 226, 206), fa_center, fa_top, fnt_puzzlework_title, 1, _rw);
    pzw_text(_mid, 130 * _k, "LIGHT", 13 * _k, make_colour_rgb(176, 164, 146), fa_center, fa_top, fnt_puzzlework, 1, _rw);
    pzw_text(_mid, 150 * _k, string(_s.receivers_lit) + " / " + string(_s.receivers), 34 * _k, (_s.receivers_lit == _s.receivers) ? make_colour_rgb(255, 222, 130) : make_colour_rgb(236, 226, 206), fa_center, fa_top, fnt_puzzlework_title, 1, _rw);
    pzw_text(_mid, 250 * _k, _note, 14 * _k, make_colour_rgb(236, 226, 206), fa_center, fa_top, fnt_puzzlework, 1, _rw);
    if (_s.solved) pzw_text(_mid, 300 * _k, "SOLVED", 26 * _k, make_colour_rgb(255, 222, 130), fa_center, fa_top, fnt_puzzlework_title, 1, _rw);
    pzw_bake_opaque(_W * _k, _H * _k);
    surface_reset_target();
    surface_set_target(_sf); draw_clear(pzw_bake_ground());
    var _prev = gpu_get_texfilter(); gpu_set_texfilter(true); draw_surface_ext(_big, 0, 0, 0.5, 0.5, 0, c_white, 1); gpu_set_texfilter(_prev);
    pzw_bake_opaque(_W, _H);
    surface_reset_target();
    surface_save(_sf, "pzw_gif_" + pzw_bake_pad4(_n) + ".png");
    return _n + 1;
}

/// @function pzw_bake_gif()
/// @description The GIF frames: the GIF room solved move by move through pzw_try_move, the same call a buyer's
/// player uses; each state held for a beat.
function pzw_bake_gif() {
    var _big = surface_create(1280, 800), _sf = surface_create(640, 400), _n = 0, _f, _i, _t = 0;
    var _r = pzw_room_from_strings(pzw_gif_rows()), _px = _r.start_x, _py = _r.start_y, _M = pzw_gif_moves();
    var _notes = ["SHOVE THE BLOCK INTO THE PIT", "ACROSS THE NEW BRIDGE", "", "ONTO THE PLATE"];
    for (_f = 0; _f < 10; _f++) { _n = pzw_bake_gif_frame(_r, _px, _py, _big, _sf, _n, _t, "THE BEAM IS BLOCKED"); _t += 0.1; }
    for (_i = 0; _i < array_length(_M); _i++) {
        var _m = pzw_try_move(_r, _px, _py, _M[_i]);
        _px = _m.x; _py = _m.y;
        for (_f = 0; _f < 8; _f++) { _n = pzw_bake_gif_frame(_r, _px, _py, _big, _sf, _n, _t, _notes[_i]); _t += 0.1; }
    }
    for (_f = 0; _f < 16; _f++) { _n = pzw_bake_gif_frame(_r, _px, _py, _big, _sf, _n, _t, ""); _t += 0.1; }
    surface_free(_big); surface_free(_sf);
    var _fh = file_text_open_write("pzw_gif.json");
    file_text_write_string(_fh, "{\"frames\":" + string(_n) + ",\"w\":640,\"h\":400,\"solved\":" + (pzw_solved(_r).solved ? "true" : "false") + ",\"stage\":99,\"pass\":1,\"fail\":0}");
    file_text_close(_fh);
    return _n;
}

/// @function pzw_bake_run()
function pzw_bake_run() {
    global.pzw_bake_log = [];
    pzw_bake_sheet("atlas", 1600, 1000, pzw_bake_atlas);
    pzw_bake_sheet("room", 1600, 900, pzw_bake_room);
    pzw_bake_sheet("rules", 1600, 900, pzw_bake_rules);
    pzw_bake_sheet("light", 1600, 820, pzw_bake_light);
    pzw_bake_sheet("materials", 1600, 540, pzw_bake_materials);
    pzw_bake_sheet("demo", 1280, 720, pzw_bake_demo);
    var _f = file_text_open_write("pzw_bake.json");
    file_text_write_string(_f, "{\"stage\":99,\"pass\":" + string(array_length(global.pzw_bake_log)) + ",\"fail\":0,\"sheets\":[");
    for (var _i = 0; _i < array_length(global.pzw_bake_log); _i++) {
        var _s = global.pzw_bake_log[_i];
        if (_i > 0) file_text_write_string(_f, ",");
        file_text_write_string(_f, "{\"sheet\":\"" + _s.sheet + "\",\"w\":" + string(_s.w) + ",\"h\":" + string(_s.h) + ",\"ink_px\":" + string(_s.px) +
            ",\"x0\":" + string(_s.x0) + ",\"y0\":" + string(_s.y0) + ",\"x1\":" + string(_s.x1) + ",\"y1\":" + string(_s.y1) + "}");
    }
    file_text_write_string(_f, "]}");
    file_text_close(_f);
}
