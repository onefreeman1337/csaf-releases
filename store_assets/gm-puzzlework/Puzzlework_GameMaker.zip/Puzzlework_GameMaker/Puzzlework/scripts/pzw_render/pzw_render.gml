/// pzw_render.gml - draws a Puzzlework room: a lit three-quarter view of worked stone, every mechanism a physical
/// object with a top face, a front face and a cast shadow, one lamp at the upper left.
///
/// Puzzlework - Dungeon Puzzles Without Scripting Each Block, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// GEOMETRY. A cell is `cell` pixels square. Anything raised (walls, blocks, plinths) draws its top face lifted by its
/// height and its front face in the lower part of its own cell, so it overlaps the row behind it. The room is drawn
/// terrain first, then row by row from the back, which is what makes that overlap correct. A room occupies
/// width * cell across and height * cell + the wall height down (pzw_room_extent).
/// ⛔ NOTHING HERE IS AN IMAGE FILE. Every stone, plank, rivet, crack, ripple and glint is drawn from the room's data
/// and the cell's own hash, so the same room always draws the same way and a room nobody has built yet still has a
/// look. Nothing mechanical can see these pictures: every store image is opened and looked at.
///
/// PUBLIC API:
///   pzw_room_draw(room, x, y, cell, [opts])     draw the whole room; opts {beams, player_x, player_y, time}
///   pzw_room_extent(room, cell)                 {w, h} in pixels
///   pzw_draw_object(object, x, y, cell, [lit], [time])   one object in the cell at (x, y) (lit: plate pressed / receiver lit)
///   pzw_draw_terrain(kind, x, y, cell, [seed], [time])   one cell of terrain
///   pzw_draw_sunk(object, terrain, x, y, cell, [time])   a consumed object as the crossing it made (hole or water)
///   pzw_draw_rubble(material, x, y, cell, [seed])       what a broken boulder leaves
///   pzw_draw_beam(trace, x, y, cell, [time])            one traced beam as light (additive)
///   pzw_draw_wisp(x, y, cell, [time])                   the demo's lantern wisp (a player marker)
///   pzw_block_palette(material) / pzw_boulder_palette(material)   the colours (pure)

#macro PZW_H_WALL 0.44
#macro PZW_H_BLOCK 0.34

/// @function pzw_hash2(x, y, salt)
/// @description A 0..1 value for a cell, stable forever (FNV-1a of "x,y,salt"). Pure.
function pzw_hash2(_x, _y, _salt) {
    var _s = string(_x) + "," + string(_y) + "," + string(_salt);
    var _h = int64(2166136261);
    for (var _i = 1; _i <= string_length(_s); _i++) _h = ((_h ^ int64(ord(string_char_at(_s, _i)))) * int64(16777619)) & int64(4294967295);
    return real(_h & int64(65535)) / 65535;
}

/// @function pzw_block_palette(material)
/// @description {top, front, accent, name} for a block material (unknown -> stone). Pure.
function pzw_block_palette(_m) {
    switch (_m) {
        case "wood":    return { name: "wood",    top: make_colour_rgb(150, 100, 56),  front: make_colour_rgb(108, 68, 36),  accent: make_colour_rgb(58, 56, 62) };
        // blued steel, not grey: an iron block the grey of the stone one measured as the same ford under water
        case "iron":    return { name: "iron",    top: make_colour_rgb(70, 84, 112),   front: make_colour_rgb(44, 54, 76),   accent: make_colour_rgb(176, 190, 214) };
        case "ice":     return { name: "ice",     top: make_colour_rgb(176, 220, 240), front: make_colour_rgb(118, 170, 206), accent: make_colour_rgb(248, 252, 255) };
        case "gold":    return { name: "gold",    top: make_colour_rgb(218, 170, 60),  front: make_colour_rgb(160, 114, 32), accent: make_colour_rgb(255, 232, 150) };
        case "crystal": return { name: "crystal", top: make_colour_rgb(138, 90, 198),  front: make_colour_rgb(94, 56, 150),  accent: make_colour_rgb(226, 184, 255) };
        default:        return { name: "stone",   top: make_colour_rgb(126, 132, 142), front: make_colour_rgb(86, 90, 100),  accent: make_colour_rgb(160, 166, 176) };
    }
}

/// @function pzw_boulder_palette(material)
/// @description {base, light, dark, fleck, name} for a boulder material (unknown -> granite). Pure.
function pzw_boulder_palette(_m) {
    switch (_m) {
        case "basalt":    return { name: "basalt",    base: make_colour_rgb(70, 70, 80),    light: make_colour_rgb(128, 128, 140), dark: make_colour_rgb(30, 30, 36),  fleck: make_colour_rgb(190, 80, 60) };
        case "sandstone": return { name: "sandstone", base: make_colour_rgb(190, 146, 96),  light: make_colour_rgb(236, 204, 150), dark: make_colour_rgb(120, 84, 48), fleck: make_colour_rgb(150, 104, 60) };
        default:          return { name: "granite",   base: make_colour_rgb(136, 132, 128), light: make_colour_rgb(200, 198, 194), dark: make_colour_rgb(70, 68, 66),  fleck: make_colour_rgb(40, 38, 40) };
    }
}

/// @function pzw_bevel_rect(x, y, w, h, b, base, light, dark)
/// @description A rectangle with a relief rim `b` wide: four trapezoids, each shaded by how squarely its edge faces
/// the lamp (upper left: the top and left edges catch it, the right and bottom fall away).
function pzw_bevel_rect(_x, _y, _w, _h, _b, _base, _light, _dark) {
    pzw_rect_fill(_x, _y, _w, _h, _base);
    if (_b <= 0) return;
    _b = min(_b, _w * 0.45, _h * 0.45);
    pzw_fill_convex([_x, _y, _x + _w, _y, _x + _w - _b, _y + _b, _x + _b, _y + _b], merge_colour(_base, _light, 0.75));
    pzw_fill_convex([_x, _y, _x + _b, _y + _b, _x + _b, _y + _h - _b, _x, _y + _h], merge_colour(_base, _light, 0.45));
    pzw_fill_convex([_x + _w, _y, _x + _w, _y + _h, _x + _w - _b, _y + _h - _b, _x + _w - _b, _y + _b], merge_colour(_base, _dark, 0.45));
    pzw_fill_convex([_x, _y + _h, _x + _b, _y + _h - _b, _x + _w - _b, _y + _h - _b, _x + _w, _y + _h], merge_colour(_base, _dark, 0.7));
}

/// @function pzw_cast_shadow(x, y, w, h, lift, alpha)
/// @description The shadow a raised thing of footprint (x, y, w, h) and height `lift` throws down and to the right.
function pzw_cast_shadow(_x, _y, _w, _h, _lift, _alpha) {
    var _s = _w * 0.26 + _lift * 0.35;
    pzw_fill_convex([_x + _w, _y - _lift * 0.5, _x + _w + _s, _y - _lift * 0.5 + _s * 0.55, _x + _w + _s, _y + _h + _s * 0.4, _x + _s * 0.5, _y + _h + _s * 0.4, _x, _y + _h], c_black, _alpha);
}

/// @function pzw_prism(x, y, w, h, lift, top, front, bevel)
/// @description A raised box standing on the footprint (x, y, w, h): its top face lifted by `lift`, its front face
/// filling the bottom `lift` of the footprint. Returns the top face's rect as [x, y, w, h] for detail work.
function pzw_prism(_x, _y, _w, _h, _lift, _top, _front, _bevel) {
    var _ty = _y - _lift;
    // the front face: darker, with ambient occlusion at the foot and a lit lip under the top face
    pzw_rect_fill(_x, _y + _h - _lift, _w, _lift, _front);
    pzw_rect_fill(_x, _y + _h - max(1, _lift * 0.14), _w, max(1, _lift * 0.14), merge_colour(_front, c_black, 0.45));
    pzw_rect_fill(_x + _w - max(1, _w * 0.06), _y + _h - _lift, max(1, _w * 0.06), _lift, merge_colour(_front, c_black, 0.3));
    pzw_bevel_rect(_x, _ty, _w, _h, _bevel, _top, merge_colour(_top, c_white, 0.5), merge_colour(_top, c_black, 0.5));
    pzw_rect_fill(_x, _ty + _h - max(1, _bevel * 0.5), _w, max(1, _bevel * 0.5), merge_colour(_front, c_white, 0.25));
    return [_x, _ty, _w, _h];
}

/// @function pzw_room_extent(room, cell)
/// @description The room's drawn size in pixels, {w, h}: the walls rise above the first row. Pure.
function pzw_room_extent(_r, _c) {
    if (!pzw_is_room(_r) || !is_numeric(_c)) return { w: 0, h: 0 };
    return { w: _r.width * _c, h: _r.height * _c + _c * PZW_H_WALL };
}

/// @function pzw_draw_terrain(kind, x, y, cell, [seed], [time])
/// @description One cell of terrain with its top-left corner at (x, y). `seed` varies the flagstones (use the
/// cell's own coordinates packed into a number, as pzw_room_draw does). Walls are drawn by pzw_room_draw in the
/// object pass; here "wall" draws its footprint only.
function pzw_draw_terrain(_k, _x, _y, _c, _seed = 0, _t = 0) {
    if (!is_numeric(_x) || !is_numeric(_y) || !is_numeric(_c) || _c < 4) return;
    if (!is_numeric(_seed)) _seed = 0;
    if (!is_numeric(_t)) _t = 0;
    _seed = frac(abs(_seed));
    var _gap = max(1, _c * 0.035), _i;
    switch (_k) {
        case "hole":
            pzw_rect_fill(_x, _y, _c, _c, make_colour_rgb(8, 7, 9));
            // the far wall of the pit, lit from above and falling into the dark
            for (_i = 0; _i < 6; _i++) pzw_rect_fill(_x, _y + _c * _i * 0.08, _c, _c * 0.08 + 1, merge_colour(make_colour_rgb(72, 66, 64), make_colour_rgb(8, 7, 9), _i / 6));
            pzw_rect_fill(_x, _y, _c, max(1, _c * 0.05), make_colour_rgb(120, 114, 108));
            pzw_rect_fill(_x, _y, max(1, _c * 0.05), _c, make_colour_rgb(30, 28, 30), 0.7);
            break;
        case "water":
            pzw_rect_fill(_x, _y, _c, _c, make_colour_rgb(22, 74, 92));
            pzw_rect_fill(_x, _y, _c, _c * 0.16, make_colour_rgb(12, 40, 52));
            for (_i = 0; _i < 3; _i++) {
                var _wy = _y + _c * (0.34 + _i * 0.22), _ph = _t * 1.6 + _i * 2.1 + _seed * 6.28;
                var _wx = _x + _c * (0.18 + 0.12 * sin(_ph));
                pzw_seg(_wx, _wy, _wx + _c * 0.32, _wy - _c * 0.02, max(1, _c * 0.03), make_colour_rgb(120, 200, 214), 0.55);
                pzw_seg(_wx + _c * 0.4, _wy + _c * 0.05, _wx + _c * 0.58, _wy + _c * 0.04, max(1, _c * 0.025), make_colour_rgb(120, 200, 214), 0.35);
            }
            break;
        case "ice":
            pzw_rect_fill(_x, _y, _c, _c, make_colour_rgb(150, 196, 222));
            pzw_rect_fill(_x + _gap, _y + _gap, _c - _gap * 2, _c - _gap * 2, make_colour_rgb(184, 222, 240));
            var _a = _seed * 6.28;
            pzw_seg(_x + _c * (0.2 + 0.2 * _seed), _y + _c * 0.15, _x + _c * 0.55, _y + _c * 0.6, max(1, _c * 0.02), c_white, 0.6);
            pzw_seg(_x + _c * 0.55, _y + _c * 0.6, _x + _c * (0.8 - 0.1 * sin(_a)), _y + _c * 0.72, max(1, _c * 0.02), c_white, 0.5);
            pzw_seg(_x + _c * 0.55, _y + _c * 0.6, _x + _c * 0.42, _y + _c * 0.88, max(1, _c * 0.015), c_white, 0.4);
            pzw_seg(_x + _c * 0.14, _y + _c * 0.24, _x + _c * 0.32, _y + _c * 0.12, max(1, _c * 0.04), c_white, 0.7);
            break;
        case "wall":
            pzw_rect_fill(_x, _y, _c, _c, make_colour_rgb(40, 38, 42));
            break;
        default:   // floor: flagstones laid in one of four patterns, each stone its own shade
            pzw_rect_fill(_x, _y, _c, _c, make_colour_rgb(46, 42, 42));
            var _pat = floor(_seed * 4), _stones;
            switch (_pat) {
                case 0: _stones = [[0, 0, 1, 1]]; break;
                case 1: _stones = [[0, 0, 0.5, 1], [0.5, 0, 0.5, 1]]; break;
                case 2: _stones = [[0, 0, 1, 0.5], [0, 0.5, 1, 0.5]]; break;
                default: _stones = [[0, 0, 0.62, 0.5], [0.62, 0, 0.38, 0.5], [0, 0.5, 0.4, 0.5], [0.4, 0.5, 0.6, 0.5]]; break;
            }
            for (_i = 0; _i < array_length(_stones); _i++) {
                var _st = _stones[_i], _v = frac(_seed * 13.37 + _i * 0.31), _w2 = frac(_seed * 7.13 + _i * 0.57);
                // warm worn sandstone, each stone its own shade; the walls are cooler and darker, so the floor the
                // puzzle happens on is the lightest, warmest surface in the room
                var _base = merge_colour(make_colour_rgb(112, 96, 80), make_colour_rgb(142, 124, 102), _v);
                var _sx = _x + _st[0] * _c + _gap, _sy = _y + _st[1] * _c + _gap, _sw = _st[2] * _c - _gap * 2, _sh = _st[3] * _c - _gap * 2;
                pzw_bevel_rect(_sx, _sy, _sw, _sh, max(1, _c * 0.035), _base, make_colour_rgb(196, 178, 150), make_colour_rgb(46, 38, 32));
                if (_w2 < 0.18) pzw_polyline([_sx + _sw * 0.2, _sy + _sh * 0.3, _sx + _sw * 0.45, _sy + _sh * 0.5, _sx + _sw * 0.4, _sy + _sh * 0.8], max(1, _c * 0.018), make_colour_rgb(58, 48, 40), 0.8);
                else if (_w2 > 0.86) pzw_spot(_sx + _sw * 0.25, _sy + _sh * 0.8, _c * 0.16, make_colour_rgb(70, 96, 52), 0.55);
            }
            break;
    }
}

/// @function pzw_draw_block_face(pal, material, tx, ty, w, h, c)
/// @description The material's own detail on a block's top face (rect tx, ty, w, h).
function pzw_draw_block_face(_p, _m, _tx, _ty, _w, _h, _c) {
    var _cx = _tx + _w * 0.5, _cy = _ty + _h * 0.5, _lw = max(1, _c * 0.03), _i;
    switch (_m) {
        case "wood":
            for (_i = 1; _i < 3; _i++) pzw_seg(_tx + _w * 0.08, _ty + _h * _i / 3, _tx + _w * 0.92, _ty + _h * _i / 3, _lw, merge_colour(_p.top, c_black, 0.45));
            for (_i = 0; _i < 3; _i++) pzw_seg(_tx + _w * 0.12, _ty + _h * (_i + 0.5) / 3, _tx + _w * 0.3, _ty + _h * (_i + 0.5) / 3 + _lw, max(1, _lw * 0.6), merge_colour(_p.top, c_black, 0.25));
            var _k = _w * 0.2;
            pzw_fill_convex([_tx, _ty, _tx + _k, _ty, _tx, _ty + _k], _p.accent);
            pzw_fill_convex([_tx + _w, _ty, _tx + _w, _ty + _k, _tx + _w - _k, _ty], _p.accent);
            pzw_fill_convex([_tx, _ty + _h, _tx, _ty + _h - _k, _tx + _k, _ty + _h], _p.accent);
            pzw_fill_convex([_tx + _w, _ty + _h, _tx + _w - _k, _ty + _h, _tx + _w, _ty + _h - _k], _p.accent);
            break;
        case "iron":
            pzw_seg(_tx + _w * 0.12, _ty + _h * 0.12, _tx + _w * 0.88, _ty + _h * 0.88, _lw * 2.2, merge_colour(_p.top, c_black, 0.35));
            pzw_seg(_tx + _w * 0.88, _ty + _h * 0.12, _tx + _w * 0.12, _ty + _h * 0.88, _lw * 2.2, merge_colour(_p.top, c_black, 0.35));
            var _R = [[0.14, 0.14], [0.86, 0.14], [0.14, 0.86], [0.86, 0.86], [0.5, 0.14], [0.5, 0.86], [0.14, 0.5], [0.86, 0.5]];
            for (_i = 0; _i < array_length(_R); _i++) { var _rx = _tx + _w * _R[_i][0], _ry = _ty + _h * _R[_i][1]; pzw_disc(_rx + _lw * 0.4, _ry + _lw * 0.5, _c * 0.035, c_black, 0.4); pzw_disc(_rx, _ry, _c * 0.035, _p.accent); }
            pzw_seg(_tx + _w * 0.2, _ty + _h * 0.3, _tx + _w * 0.45, _ty + _h * 0.1, _lw * 1.4, c_white, 0.35);
            break;
        case "ice":
            pzw_fill_convex([_cx, _ty + _h * 0.12, _tx + _w * 0.88, _cy, _cx, _ty + _h * 0.88, _tx + _w * 0.12, _cy], merge_colour(_p.top, c_white, 0.35), 0.8);
            pzw_seg(_cx, _ty + _h * 0.12, _cx, _ty + _h * 0.88, _lw, _p.front, 0.6);
            pzw_seg(_tx + _w * 0.12, _cy, _tx + _w * 0.88, _cy, _lw, _p.front, 0.5);
            pzw_seg(_tx + _w * 0.16, _ty + _h * 0.3, _tx + _w * 0.4, _ty + _h * 0.12, _lw * 1.6, c_white, 0.85);
            break;
        case "gold":
            pzw_disc(_cx + _lw, _cy + _lw, _w * 0.26, merge_colour(_p.top, c_black, 0.4));
            pzw_disc(_cx, _cy, _w * 0.26, merge_colour(_p.top, c_white, 0.25));
            for (_i = 0; _i < 12; _i++) { var _a = _i / 12 * 2 * pi; pzw_seg(_cx + cos(_a) * _w * 0.29, _cy + sin(_a) * _h * 0.29, _cx + cos(_a) * _w * 0.4, _cy + sin(_a) * _h * 0.4, _lw * 1.3, (_i mod 2 == 0) ? _p.accent : merge_colour(_p.top, c_black, 0.3)); }
            pzw_disc(_cx, _cy, _w * 0.12, _p.accent);
            pzw_spot(_cx - _w * 0.1, _cy - _h * 0.12, _w * 0.3, c_white, 0.5);
            break;
        case "crystal":
            var _pts = [];
            for (_i = 0; _i < 6; _i++) { var _b = _i / 6 * 2 * pi - pi / 2; array_push(_pts, _cx + cos(_b) * _w * 0.3, _cy + sin(_b) * _h * 0.3); }
            pzw_spot(_cx, _cy, _w * 0.5, _p.accent, 0.35);
            pzw_fill_convex(_pts, merge_colour(_p.top, _p.accent, 0.35));
            pzw_polyline(_pts, _lw * 1.2, _p.accent, 0.9, true);
            pzw_seg(_cx, _cy - _h * 0.3, _cx, _cy + _h * 0.3, _lw, _p.accent, 0.7);
            pzw_disc(_cx, _cy, _w * 0.06, c_white);
            break;
        default:   // stone: a carved inset square with a rune groove and a chipped corner
            pzw_bevel_rect(_tx + _w * 0.2, _ty + _h * 0.2, _w * 0.6, _h * 0.6, max(1, _c * 0.03), merge_colour(_p.top, c_black, 0.12), merge_colour(_p.top, c_black, 0.45), merge_colour(_p.top, c_white, 0.35));
            pzw_seg(_cx, _ty + _h * 0.32, _cx, _ty + _h * 0.68, _lw * 1.2, merge_colour(_p.top, c_black, 0.4));
            pzw_seg(_tx + _w * 0.36, _cy, _tx + _w * 0.64, _cy, _lw * 1.2, merge_colour(_p.top, c_black, 0.4));
            pzw_seg(_tx + _w * 0.7, _ty + _h * 0.06, _tx + _w * 0.8, _ty + _h * 0.16, _lw, merge_colour(_p.top, c_black, 0.35));
            break;
    }
}

/// @function pzw_draw_object(object, x, y, cell, [lit], [time])
/// @description Draw one object standing in the cell whose top-left is (x, y). `lit` = the plate is pressed or the
/// receiver is lit. Consumed objects draw nothing here (see pzw_draw_sunk / pzw_draw_rubble). Returns true if drawn.
function pzw_draw_object(_o, _x, _y, _c, _lit = false, _t = 0) {
    if (!is_struct(_o) || !variable_struct_exists(_o, "kind") || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_c) || _c < 4) return false;
    if (variable_struct_exists(_o, "consumed") && _o.consumed) return false;
    if (!is_numeric(_t)) _t = 0;
    _lit = (is_bool(_lit) || is_numeric(_lit)) ? (_lit == true) : false;
    var _lw = max(1, _c * 0.03), _cx = _x + _c * 0.5, _cy = _y + _c * 0.5, _i;
    switch (_o.kind) {
        case "block":
            var _p = pzw_block_palette(variable_struct_exists(_o, "material") ? _o.material : "stone");
            var _in = _c * 0.04, _lift = _c * PZW_H_BLOCK;
            pzw_cast_shadow(_x + _in, _y + _in, _c - _in * 2, _c - _in * 2, _lift, 0.38);
            var _tf = pzw_prism(_x + _in, _y + _in, _c - _in * 2, _c - _in * 2, _lift, _p.top, _p.front, _c * 0.07);
            pzw_draw_block_face(_p, _p.name, _tf[0] + _c * 0.07, _tf[1] + _c * 0.07, _tf[2] - _c * 0.14, _tf[3] - _c * 0.14, _c);
            if (_p.name == "ice") pzw_rect_fill(_x + _in, _y + _c - _in - _lift, _c - _in * 2, _lift * 0.35, c_white, 0.25);
            return true;
        case "boulder":
            var _b = pzw_boulder_palette(variable_struct_exists(_o, "material") ? _o.material : "granite");
            var _r = _c * 0.42, _bx = _cx, _by = _cy - _c * 0.1, _bid = variable_struct_exists(_o, "id") ? _o.id : 0;
            pzw_fill_convex(pzw_ellipse_pts(_cx + _c * 0.12, _y + _c * 0.84, _r * 1.05, _r * 0.42, 0, 24), c_black, 0.4);
            pzw_disc(_bx, _by, _r, _b.dark);
            pzw_disc(_bx - _r * 0.07, _by - _r * 0.08, _r * 0.9, _b.base);
            pzw_disc(_bx - _r * 0.22, _by - _r * 0.25, _r * 0.55, merge_colour(_b.base, _b.light, 0.45), 0.7);
            for (_i = 0; _i < 9; _i++) {
                var _fa = pzw_hash2(_bid, _i, "fa") * 2 * pi, _fd = sqrt(pzw_hash2(_bid, _i, "fd")) * _r * 0.8;
                pzw_disc(_bx + cos(_fa) * _fd, _by + sin(_fa) * _fd, max(1, _c * 0.022), _b.fleck, 0.7);
            }
            pzw_polyline([_bx + _r * 0.1, _by - _r * 0.6, _bx + _r * 0.25, _by - _r * 0.2, _bx + _r * 0.05, _by + _r * 0.2, _bx + _r * 0.3, _by + _r * 0.5], _lw, _b.dark, 0.8);
            pzw_spot(_bx - _r * 0.35, _by - _r * 0.4, _r * 0.4, c_white, 0.55);
            return true;
        case "plate":
            var _pi = _c * 0.16, _pw = _c - _pi * 2;
            var _brass = make_colour_rgb(176, 134, 60);
            pzw_bevel_rect(_x + _pi, _y + _pi, _pw, _pw, _c * 0.06, _lit ? merge_colour(_brass, c_black, 0.25) : _brass, make_colour_rgb(246, 214, 140), make_colour_rgb(74, 50, 18));
            pzw_bevel_rect(_x + _pi + _c * 0.1, _y + _pi + _c * 0.1, _pw - _c * 0.2, _pw - _c * 0.2, _c * 0.03, make_colour_rgb(70, 64, 60), _lit ? make_colour_rgb(20, 18, 18) : make_colour_rgb(140, 132, 120), _lit ? make_colour_rgb(140, 132, 120) : make_colour_rgb(20, 18, 18));
            var _gem = [_cx, _cy - _c * 0.12, _cx + _c * 0.12, _cy, _cx, _cy + _c * 0.12, _cx - _c * 0.12, _cy];
            if (_lit) { pzw_spot(_cx, _cy, _c * 0.4, make_colour_rgb(120, 255, 170), 0.55); pzw_fill_convex(_gem, make_colour_rgb(140, 255, 180)); }
            else pzw_fill_convex(_gem, make_colour_rgb(58, 90, 72));
            pzw_polyline(_gem, _lw, make_colour_rgb(30, 40, 34), 0.9, true);
            return true;
        case "receiver":
            var _ri = _c * 0.14, _rl = _c * 0.2;
            pzw_cast_shadow(_x + _ri, _y + _ri, _c - _ri * 2, _c - _ri * 2, _rl, 0.35);
            var _rt = pzw_prism(_x + _ri, _y + _ri, _c - _ri * 2, _c - _ri * 2, _rl, make_colour_rgb(104, 100, 108), make_colour_rgb(70, 66, 74), _c * 0.05);
            var _gx = _rt[0] + _rt[2] * 0.5, _gy = _rt[1] + _rt[3] * 0.5, _gr = _c * 0.2;
            var _hex = [];
            for (_i = 0; _i < 6; _i++) { var _ha = _i / 6 * 2 * pi; array_push(_hex, _gx + cos(_ha) * _gr, _gy + sin(_ha) * _gr * 0.9); }
            if (_lit) {
                var _pulse = 0.75 + 0.25 * sin(_t * 5);
                pzw_spot(_gx, _gy, _c * 0.75, make_colour_rgb(255, 214, 120), 0.6 * _pulse);
                pzw_fill_convex(_hex, make_colour_rgb(255, 222, 130));
                pzw_disc(_gx, _gy, _gr * 0.45, c_white);
            } else {
                pzw_fill_convex(_hex, make_colour_rgb(84, 80, 110));
                pzw_disc(_gx - _gr * 0.25, _gy - _gr * 0.25, _gr * 0.3, make_colour_rgb(150, 146, 180), 0.8);
            }
            pzw_polyline(_hex, _lw, make_colour_rgb(40, 36, 44), 0.9, true);
            return true;
        case "emitter":
            var _ei = _c * 0.14, _el = _c * 0.24;
            pzw_cast_shadow(_x + _ei, _y + _ei, _c - _ei * 2, _c - _ei * 2, _el, 0.35);
            var _et = pzw_prism(_x + _ei, _y + _ei, _c - _ei * 2, _c - _ei * 2, _el, make_colour_rgb(98, 94, 102), make_colour_rgb(66, 62, 70), _c * 0.05);
            var _ex = _et[0] + _et[2] * 0.5, _ey = _et[1] + _et[3] * 0.5, _f = variable_struct_exists(_o, "facing") ? _o.facing : 0;
            var _dx = pzw_dir_dx(_f), _dy = pzw_dir_dy(_f), _len = _c * 0.34, _bw = _c * 0.13;
            var _brass2 = make_colour_rgb(190, 146, 68);
            pzw_disc(_ex, _ey, _c * 0.2, merge_colour(_brass2, c_black, 0.35));
            pzw_disc(_ex - _c * 0.02, _ey - _c * 0.02, _c * 0.17, _brass2);
            pzw_seg(_ex, _ey, _ex + _dx * _len, _ey + _dy * _len, _bw * 2, merge_colour(_brass2, c_black, 0.25));
            pzw_seg(_ex - _dy * _bw * 0.4, _ey - _dx * _bw * 0.4, _ex + _dx * _len - _dy * _bw * 0.4, _ey + _dy * _len - _dx * _bw * 0.4, _bw * 0.5, make_colour_rgb(246, 214, 140));
            pzw_spot(_ex + _dx * _len, _ey + _dy * _len, _c * 0.3, make_colour_rgb(255, 230, 150), 0.8);
            pzw_disc(_ex + _dx * _len, _ey + _dy * _len, _bw * 0.7, make_colour_rgb(255, 244, 200));
            return true;
        case "mirror":
            var _f2 = variable_struct_exists(_o, "facing") ? _o.facing : "/";
            pzw_fill_convex(pzw_ellipse_pts(_cx + _c * 0.06, _cy + _c * 0.2, _c * 0.38, _c * 0.16, 0, 20), c_black, 0.35);
            pzw_fill_convex(pzw_ellipse_pts(_cx, _cy + _c * 0.16, _c * 0.34, _c * 0.14, 0, 20), make_colour_rgb(92, 88, 94));
            pzw_fill_convex(pzw_ellipse_pts(_cx, _cy + _c * 0.12, _c * 0.3, _c * 0.11, 0, 20), make_colour_rgb(128, 122, 130));
            var _x1, _y1, _x2, _y2, _up = _c * 0.42;
            if (_f2 == "\\") { _x1 = _x + _c * 0.2; _y1 = _y + _c * 0.28; _x2 = _x + _c * 0.8; _y2 = _y + _c * 0.62; }
            else { _x1 = _x + _c * 0.2; _y1 = _y + _c * 0.62; _x2 = _x + _c * 0.8; _y2 = _y + _c * 0.28; }
            var _panel = [_x1, _y1, _x2, _y2, _x2, _y2 - _up, _x1, _y1 - _up];
            pzw_fill_convex(_panel, make_colour_rgb(150, 170, 186));
            pzw_fill_convex([_x1, _y1 - _up, _x2, _y2 - _up, _x2 + (_x1 - _x2) * 0.35, _y2 - _up + (_y1 - _y2) * 0.35 + _up * 0.3, _x1, _y1 - _up + _up * 0.35], make_colour_rgb(222, 236, 246), 0.8);
            pzw_polyline(_panel, _lw * 1.6, make_colour_rgb(176, 134, 60), 1, true);
            pzw_seg(_x1 + (_x2 - _x1) * 0.2, _y1 + (_y2 - _y1) * 0.2 - _up * 0.8, _x1 + (_x2 - _x1) * 0.45, _y1 + (_y2 - _y1) * 0.45 - _up * 0.35, _lw * 1.3, c_white, 0.8);
            return true;
    }
    return false;
}

/// @function pzw_draw_sunk(object, terrain, x, y, cell, [time])
/// @description A consumed block or boulder as the crossing it made: its top flush with the floor inside a pit, or
/// drowned under the surface of water. Draw it over the terrain it fills.
function pzw_draw_sunk(_o, _terr, _x, _y, _c, _t = 0) {
    if (!is_struct(_o) || !variable_struct_exists(_o, "kind") || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_c) || _c < 4) return;
    if (!is_numeric(_t)) _t = 0;
    if (!variable_struct_exists(_o, "material")) _o.material = "";
    var _i = _c * 0.1, _cx = _x + _c * 0.5, _cy = _y + _c * 0.5, _water = make_colour_rgb(22, 74, 92);
    if (_o.kind == "boulder") {
        // a boulder settles as a DOME: its crown shows above the pit floor or breaks the water's surface
        var _b = pzw_boulder_palette(_o.material), _r = _c * 0.36;
        if (_terr == "water") {
            // ⚠️ the crown stands ABOVE the surface, so it keeps its own colour: tinted 0.35 toward the water, granite
            // and sandstone measured IDENTICAL (0 differing samples)
            pzw_disc(_cx, _cy, _r, merge_colour(_b.dark, _water, 0.3));
            pzw_disc(_cx - _r * 0.12, _cy - _r * 0.14, _r * 0.8, merge_colour(_b.base, _water, 0.1));
            for (var _f = 0; _f < 6; _f++) pzw_disc(_cx + cos(_f * 1.9) * _r * 0.45, _cy + sin(_f * 1.9) * _r * 0.4, max(1, _c * 0.022), _b.fleck, 0.7);
            pzw_spot(_cx - _r * 0.3, _cy - _r * 0.35, _r * 0.4, c_white, 0.45);
            pzw_arc(_cx, _cy, _r * 1.12, 0, 2 * pi, max(1, _c * 0.03), make_colour_rgb(150, 220, 230), 0.55 + 0.2 * sin(_t * 2));
        } else {
            pzw_disc(_cx, _cy + _r * 0.1, _r, _b.dark);
            pzw_disc(_cx - _r * 0.08, _cy, _r * 0.88, merge_colour(_b.base, c_black, 0.2));
            pzw_disc(_cx - _r * 0.25, _cy - _r * 0.2, _r * 0.45, merge_colour(_b.base, _b.light, 0.35), 0.7);
            pzw_rect_fill(_x, _y, _c, _c * 0.2, c_black, 0.35);
        }
        return;
    }
    var _p = pzw_block_palette(_o.material);
    if (_terr == "water") {
        // a DROWNED block: its own face, seen through the water - so a gold ford and an iron ford read as different
        // things, not as two tints of one square
        // ⚠️ a light veil, not a wash: at 0.42 the stone, wood and iron fords measured as one teal square
        pzw_rect_fill(_x + _i, _y + _i, _c - _i * 2, _c - _i * 2, merge_colour(_p.top, _water, 0.15));
        pzw_draw_block_face(_p, _p.name, _x + _c * 0.18, _y + _c * 0.18, _c * 0.64, _c * 0.64, _c);
        pzw_rect_fill(_x + _i, _y + _i, _c - _i * 2, _c - _i * 2, _water, 0.22);
        pzw_rect_line(_x + _i, _y + _i, _c - _i * 2, _c - _i * 2, max(1, _c * 0.03), merge_colour(_p.front, _water, 0.5));
        var _ph = _t * 2;
        pzw_arc(_cx, _cy, _c * (0.44 + 0.02 * sin(_ph)), pi * 1.05, pi * 1.7, max(1, _c * 0.025), make_colour_rgb(150, 220, 230), 0.6);
        pzw_arc(_cx, _cy, _c * (0.44 + 0.02 * sin(_ph)), pi * 0.05, pi * 0.6, max(1, _c * 0.025), make_colour_rgb(150, 220, 230), 0.4);
    } else {
        // a block FALLEN INTO A PIT: its top flush with the floor, a dark gap all round it, the pit rim's shadow over it
        pzw_bevel_rect(_x + _i, _y + _i, _c - _i * 2, _c - _i * 2, _c * 0.05, merge_colour(_p.top, c_black, 0.18), merge_colour(_p.top, c_black, 0.5), merge_colour(_p.top, c_white, 0.2));
        pzw_draw_block_face(_p, _p.name, _x + _c * 0.17, _y + _c * 0.17, _c * 0.66, _c * 0.66, _c);
        pzw_rect_fill(_x + _i, _y + _i, _c - _i * 2, _c * 0.14, c_black, 0.4);
    }
}

/// @function pzw_draw_rubble(material, x, y, cell, [seed])
/// @description What a boulder leaves when it breaks against a wall: shaded fragments on the floor.
function pzw_draw_rubble(_m, _x, _y, _c, _seed = 0) {
    if (!is_numeric(_x) || !is_numeric(_y) || !is_numeric(_c) || _c < 4) return;
    if (!is_numeric(_seed)) _seed = 0;
    var _b = pzw_boulder_palette(_m);
    // ⚠️ fragments big enough to carry their stone's colour: at 0.06..0.16 of a cell three rubbles measured alike
    for (var _i = 0; _i < 8; _i++) {
        var _px = _x + _c * (0.2 + 0.6 * pzw_hash2(_seed, _i, "rx")), _py = _y + _c * (0.28 + 0.52 * pzw_hash2(_seed, _i, "ry"));
        var _s = _c * (0.1 + 0.12 * pzw_hash2(_seed, _i, "rs")), _rot = pzw_hash2(_seed, _i, "rr") * 6.28;
        var _pts = [];
        for (var _k = 0; _k < 5; _k++) { var _a = _rot + _k / 5 * 2 * pi; var _rr = _s * (0.7 + 0.3 * pzw_hash2(_i, _k, _seed)); array_push(_pts, _px + cos(_a) * _rr, _py + sin(_a) * _rr * 0.8); }
        pzw_fill_convex(pzw_scale_pts(_pts, _px, _py, 1, _s * 0.3, _s * 0.35), c_black, 0.35);
        pzw_fill_convex(_pts, _b.base);
        pzw_fill_convex(pzw_scale_pts(_pts, _px, _py, 0.55, -_s * 0.15, -_s * 0.18), merge_colour(_b.base, _b.light, 0.5));
    }
}

/// @function pzw_draw_beam(trace, x, y, cell, [time])
/// @description One traced beam (a pzw_trace_beam result, or pzw_beams(room)[i].trace) drawn as light over a room
/// whose top-left is (x, y). Additive: the blend mode is restored afterwards.
function pzw_draw_beam(_tr, _x, _y, _c, _t = 0) {
    if (!is_struct(_tr) || !variable_struct_exists(_tr, "cells") || !is_array(_tr.cells) || array_length(_tr.cells) < 1 || !is_numeric(_c) || !is_numeric(_x) || !is_numeric(_y) || _c < 4) return;
    if (!is_numeric(_t)) _t = 0;
    if (!variable_struct_exists(_tr, "outcome")) return;
    for (var _v = 0; _v < array_length(_tr.cells); _v++) { var _cl = _tr.cells[_v]; if (!is_struct(_cl) || !variable_struct_exists(_cl, "x") || !variable_struct_exists(_cl, "y") || !variable_struct_exists(_cl, "dir")) return; }
    var _n = array_length(_tr.cells), _lift = _c * 0.2, _i;
    var _pts = [];
    for (_i = 0; _i < _n; _i++) array_push(_pts, _x + (_tr.cells[_i].x + 0.5) * _c, _y + (_tr.cells[_i].y + 0.5) * _c - _lift);
    // a beam stopped by something solid ends at the edge of its last cell, not in the middle of it
    if (_tr.outcome == "blocked" || _tr.outcome == "escaped") {
        var _last = _tr.cells[_n - 1];
        array_push(_pts, _pts[_n * 2 - 2] + pzw_dir_dx(_last.dir) * _c * 0.5, _pts[_n * 2 - 1] + pzw_dir_dy(_last.dir) * _c * 0.5);
    }
    var _pulse = 0.85 + 0.15 * sin(_t * 6), _warm = make_colour_rgb(255, 196, 90), _core = make_colour_rgb(255, 246, 214);
    var _prev = gpu_get_blendmode();
    gpu_set_blendmode(bm_add);
    pzw_polyline(_pts, _c * 0.46, _warm, 0.10 * _pulse);
    pzw_polyline(_pts, _c * 0.22, _warm, 0.28 * _pulse);
    pzw_polyline(_pts, max(1, _c * 0.07), _core, 0.95);
    for (_i = 0; _i < array_length(_pts) div 2; _i++) pzw_disc(_pts[_i * 2], _pts[_i * 2 + 1], _c * 0.035, _core, 0.9);
    if (_tr.outcome == "receiver") pzw_spot(_pts[array_length(_pts) - 2], _pts[array_length(_pts) - 1], _c * 0.9, _warm, 0.55 * _pulse);
    else pzw_spot(_pts[array_length(_pts) - 2], _pts[array_length(_pts) - 1], _c * 0.35, _warm, 0.45 * _pulse);
    gpu_set_blendmode(_prev);
}

/// @function pzw_draw_wisp(x, y, cell, [time])
/// @description The demo's player marker: a lantern wisp hovering over the cell whose top-left is (x, y).
function pzw_draw_wisp(_x, _y, _c, _t = 0) {
    if (!is_numeric(_x) || !is_numeric(_y) || !is_numeric(_c) || _c < 4) return;
    if (!is_numeric(_t)) _t = 0;
    var _cx = _x + _c * 0.5, _cy = _y + _c * 0.36 + sin(_t * 3) * _c * 0.04;
    pzw_fill_convex(pzw_ellipse_pts(_x + _c * 0.52, _y + _c * 0.82, _c * 0.24, _c * 0.09, 0, 18), c_black, 0.35);
    var _prev = gpu_get_blendmode();
    gpu_set_blendmode(bm_add);
    pzw_spot(_cx, _cy, _c * 0.7, make_colour_rgb(120, 200, 255), 0.35);
    pzw_spot(_cx, _cy, _c * 0.32, make_colour_rgb(170, 230, 255), 0.7);
    gpu_set_blendmode(_prev);
    pzw_disc(_cx, _cy, _c * 0.13, make_colour_rgb(210, 244, 255));
    pzw_disc(_cx - _c * 0.04, _cy - _c * 0.04, _c * 0.05, c_white);
}

/// @function pzw_room_draw(room, x, y, cell, [opts])
/// @description Draw the whole room with its top-left at (x, y). opts (all optional): { beams: pzw_beams(room)
/// cached by you, player_x, player_y (a wisp is drawn there), time (seconds, for ripples and glow) }. Without
/// `beams` the room traces them itself (allocates - cache them when the room changes). Returns
/// {cells, objects, beams} counted as drawn, or undefined for a bad room or a cell under 4 px.
function pzw_room_draw(_r, _x, _y, _c, _opts = undefined) {
    if (!pzw_is_room(_r) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_c) || _c < 4) return undefined;
    var _t = 0, _beams = undefined, _pxp = -1, _pyp = -1, _i, _gx, _gy;
    if (is_struct(_opts)) {
        if (variable_struct_exists(_opts, "time") && is_numeric(_opts.time)) _t = _opts.time;
        if (variable_struct_exists(_opts, "beams") && is_array(_opts.beams)) _beams = _opts.beams;
        if (variable_struct_exists(_opts, "player_x") && is_numeric(_opts.player_x)) _pxp = _opts.player_x;
        if (variable_struct_exists(_opts, "player_y") && is_numeric(_opts.player_y)) _pyp = _opts.player_y;
    }
    if (is_undefined(_beams)) _beams = pzw_beams(_r);
    var _oy = _y + _c * PZW_H_WALL, _res = { cells: 0, objects: 0, beams: 0 };
    // which receivers are lit, from the beams (so the renderer and the rules cannot disagree)
    var _litR = {};
    for (_i = 0; _i < array_length(_beams); _i++) if (_beams[_i].trace.outcome == "receiver") _litR[$ string(_beams[_i].trace.receiver_id)] = 1;
    // 1. terrain, everywhere
    for (_gy = 0; _gy < _r.height; _gy++) for (_gx = 0; _gx < _r.width; _gx++) {
        pzw_draw_terrain(_r.terrain[_gy][_gx], _x + _gx * _c, _oy + _gy * _c, _c, pzw_hash2(_gx, _gy, "floor"), _t);
        _res.cells += 1;
    }
    // 2. what is flush with the floor: sunk objects, rubble, plates
    for (_i = 0; _i < array_length(_r.objects); _i++) {
        var _o = _r.objects[_i], _ox = _x + _o.x * _c, _oyy = _oy + _o.y * _c;
        if (_o.consumed) {
            var _tt = pzw_terrain(_r, _o.x, _o.y);
            if (_tt == "hole" || _tt == "water") pzw_draw_sunk(_o, _tt, _ox, _oyy, _c, _t);
            else if (_o.kind == "boulder") pzw_draw_rubble(_o.material, _ox, _oyy, _c, _o.id);
        } else if (_o.kind == "plate") { pzw_draw_object(_o, _ox, _oyy, _c, pzw_plate_pressed(_r, _o.x, _o.y) || (_o.x == _pxp && _o.y == _pyp), _t); _res.objects += 1; }
    }
    // 3. raised things, row by row from the back, so each overlaps the row behind it
    for (_gy = 0; _gy < _r.height; _gy++) {
        for (_gx = 0; _gx < _r.width; _gx++) {
            if (_r.terrain[_gy][_gx] != "wall") continue;
            var _wx = _x + _gx * _c, _wy = _oy + _gy * _c;
            pzw_cast_shadow(_wx, _wy, _c, _c, _c * PZW_H_WALL, 0.3);
        }
        for (_gx = 0; _gx < _r.width; _gx++) {
            if (_r.terrain[_gy][_gx] != "wall") continue;
            var _vx = _x + _gx * _c, _vy = _oy + _gy * _c, _v = pzw_hash2(_gx, _gy, "wall");
            // ⚠️ cool and DARK on purpose: the first bake drew wall tops as the lightest slabs in the room and they
            // pulled the eye off the puzzle
            var _wtop = merge_colour(make_colour_rgb(62, 62, 72), make_colour_rgb(76, 76, 86), _v);
            var _wt = pzw_prism(_vx, _vy, _c, _c, _c * PZW_H_WALL, _wtop, make_colour_rgb(44, 42, 50), _c * 0.05);
            // the coping: two dressed stones per cell, the joint alternating course by course
            var _j = (((_gx + _gy) mod 2) == 0) ? 0.42 : 0.58;
            pzw_seg(_wt[0] + _wt[2] * _j, _wt[1] + _c * 0.08, _wt[0] + _wt[2] * _j, _wt[1] + _wt[3] - _c * 0.08, max(1, _c * 0.03), make_colour_rgb(30, 30, 36), 0.85);
            pzw_seg(_wt[0] + _wt[2] * _j + max(1, _c * 0.03), _wt[1] + _c * 0.1, _wt[0] + _wt[2] * _j + max(1, _c * 0.03), _wt[1] + _wt[3] - _c * 0.1, max(1, _c * 0.015), make_colour_rgb(110, 110, 124), 0.5);
            if (_v > 0.7) pzw_polyline([_wt[0] + _wt[2] * 0.12, _wt[1] + _wt[3] * 0.3, _wt[0] + _wt[2] * 0.28, _wt[1] + _wt[3] * 0.44], max(1, _c * 0.018), make_colour_rgb(34, 34, 40), 0.7);
            // courses of brick on the front face
            var _fy = _vy + _c - _c * PZW_H_WALL, _fh = _c * PZW_H_WALL;
            pzw_seg(_vx, _fy + _fh * 0.5, _vx + _c, _fy + _fh * 0.5, max(1, _c * 0.025), make_colour_rgb(34, 32, 36), 0.8);
            var _off = ((_gx mod 2) == 0) ? 0.5 : 0.25;
            pzw_seg(_vx + _c * _off, _fy + _fh * 0.08, _vx + _c * _off, _fy + _fh * 0.5, max(1, _c * 0.025), make_colour_rgb(34, 32, 36), 0.8);
            pzw_seg(_vx + _c * (_off + 0.25), _fy + _fh * 0.5, _vx + _c * (_off + 0.25), _fy + _fh * 0.92, max(1, _c * 0.025), make_colour_rgb(34, 32, 36), 0.8);
        }
        for (_i = 0; _i < array_length(_r.objects); _i++) {
            var _q = _r.objects[_i];
            if (_q.consumed || _q.y != _gy || _q.kind == "plate") continue;
            pzw_draw_object(_q, _x + _q.x * _c, _oy + _q.y * _c, _c, (_q.kind == "receiver") && variable_struct_exists(_litR, string(_q.id)), _t);
            _res.objects += 1;
        }
        if (_pyp == _gy && _pxp >= 0) pzw_draw_wisp(_x + _pxp * _c, _oy + _pyp * _c, _c, _t);
    }
    // 4. light, over everything
    for (_i = 0; _i < array_length(_beams); _i++) { pzw_draw_beam(_beams[_i].trace, _x, _oy, _c, _t); _res.beams += 1; }
    return _res;
}
