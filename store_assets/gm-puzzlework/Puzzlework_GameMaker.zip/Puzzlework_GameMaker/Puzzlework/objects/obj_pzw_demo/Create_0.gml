/// @description Puzzlework demo - a puzzle room you can play - and the headless entry points (-selftest, -bake, -gif).
/// ⛔ The crash handler is installed FIRST, and every variable a later event reads is declared ABOVE the early exits:
/// Clean Up always runs, even when Create leaves early.
exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("pzw_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.pzw_stage) + ": " + string(_ex.message) + " | " + string(_ex.stacktrace));
    file_text_close(_f);
    game_end();
});
global.pzw_stage = 0;
room_data = undefined;
player_x = 0;
player_y = 0;
beams = [];
message = "";
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";
if (string_pos("-selftest", _args) > 0) { global.pzw_stage = 1; pzw_selftest_write(pzw_selftest_run()); game_end(); exit; }
if (string_pos("-bake", _args) > 0) { global.pzw_stage = 2; pzw_bake_run(); game_end(); exit; }
if (string_pos("-gif", _args) > 0) { global.pzw_stage = 3; pzw_bake_gif(); game_end(); exit; }

// the demo room: the hero room from the store page, unsolved - bridge the pit, press the plate, light the receiver
room_data = pzw_room_from_strings(pzw_bake_room_rows());
player_x = 3;
player_y = 3;
beams = pzw_beams(room_data);   // traced when the room CHANGES, drawn every frame
message = "Arrow keys walk and push. R puts the room back as it was built.";
