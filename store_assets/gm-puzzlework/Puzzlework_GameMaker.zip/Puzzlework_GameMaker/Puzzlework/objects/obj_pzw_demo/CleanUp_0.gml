/// @description Nothing to free: the room is a plain struct.
room_data = undefined;
