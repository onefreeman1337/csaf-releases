/// @description The room, drawn by the package and sized to the GUI (pzw_demo_draw: the same function the store bake
/// photographs).
if (!pzw_is_room(room_data)) exit;
pzw_demo_draw(room_data, beams, player_x, player_y, message, current_time / 1000, display_get_gui_width(), display_get_gui_height());
