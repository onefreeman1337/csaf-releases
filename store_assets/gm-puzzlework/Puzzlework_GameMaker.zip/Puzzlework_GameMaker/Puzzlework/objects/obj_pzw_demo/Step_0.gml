/// @description Arrow keys walk the player and push what is in the way; R resets the room. The beams are re-traced
/// only when the room changes (pzw_beams allocates), and drawn from the cache every frame.
if (!pzw_is_room(room_data)) exit;
var _dir = -1;
if (keyboard_check_pressed(vk_right)) _dir = 0;
if (keyboard_check_pressed(vk_up)) _dir = 90;
if (keyboard_check_pressed(vk_left)) _dir = 180;
if (keyboard_check_pressed(vk_down)) _dir = 270;
if (_dir >= 0) {
    var _m = pzw_try_move(room_data, player_x, player_y, _dir);
    player_x = _m.x; player_y = _m.y;
    if (is_struct(_m.push)) {
        switch (_m.push.outcome) {
            case "moved": message = "Shoved one square."; break;
            case "slid": message = "It slid " + string(_m.push.tiles) + " squares across the ice."; break;
            case "fell_in_hole": message = "It fell into the pit. The pit can be crossed now."; break;
            case "sank": message = "It sank. The water can be crossed now."; break;
            case "broke": message = "The boulder rolled into the wall and broke."; break;
            default: message = "It will not move."; break;
        }
    }
    beams = pzw_beams(room_data);
    if (pzw_solved(room_data).solved) message = "Solved: every plate pressed, every receiver lit. R to build it again.";
}
if (keyboard_check_pressed(ord("R"))) {
    var _rs = pzw_reset(room_data, player_x, player_y);
    if (_rs.stranded) { player_x = 3; player_y = 3; }
    beams = pzw_beams(room_data);
    message = "The room is as it was built.";
}
