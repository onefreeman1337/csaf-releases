/*
 * REVERSE RPG — audio.js
 * THE RUNTIME AUDIO. Music from files, SFX from oscillators.
 *
 * ⛔ WHY THE SPLIT. `preflight -> game-audio-assets` counts FILES, and its own text says
 *    procedural synthesis "is fine for SFX and needs no AI tag, but it is not a whole audio
 *    layer". So the MUSIC ships as .ogg composed in Internal_Ops/Audio/compose.js and the SFX
 *    are synthesised here: bespoke, our own IP, zero bytes, and impossible to get a licence
 *    wrong. Neither carries itch's Gen-AI audio tag (master §4.1).
 *
 * ⭐ THE POINT OF THIS FILE IS THE STEM MIXER, AND IT IS THE PREMISE MADE AUDIBLE.
 *    DESIGN.md §5: "the battle theme LOSES A VOICE every time you sacrifice a power". The fight
 *    music is not one file, it is SIX — spine, pulse, lead, choir, pad, bell — started on one
 *    clock and summed live. When the run gives a power away, that layer's gain ramps to zero and
 *    never comes back. Nothing on screen says so. By the last warden the player is fighting to a
 *    bass line and a drum.
 *
 * ⛔ SAMPLE-LOCK, NOT SYNC CODE. Every stem is exactly the same number of samples (compose.js
 *    asserts it and refuses otherwise), and all six are `start(t0)`-ed at one AudioContext time
 *    with identical `loopEnd`. Web Audio drives them off one hardware clock, so they cannot
 *    drift and there is nothing to re-sync. Any "sync" logic here would be a bug generator.
 *
 * ⛔ EVERY ENTRY POINT IS A NO-OP WITHOUT AudioContext. `ui_smoke.js` runs the front end in a
 *    Node sandbox with no Web Audio at all, and a browser blocks audio until a user gesture.
 *    Neither may break the game: audio is an enhancement and a silent game must still be a
 *    playable one. Every function below returns false rather than throwing.
 *
 * ⛔ NOTHING IS FETCHED UNTIL IT IS NEEDED. The six battle stems are 1.2 MB of the 2.0 MB score.
 *    Loading them on the title screen would put a megabyte between the player and the first
 *    thing they see, on a store where the whole advantage is that the game plays in the browser.
 *    `playMusic` fetches on demand and `prefetch()` warms the next cue during a text scene.
 */
(function (root, factory) {
  'use strict';
  var mod = factory(root,
    typeof module === 'object' && module && module.exports ? require('./paths.js') : root.RR_PATHS);
  if (typeof module === 'object' && module && module.exports) module.exports = mod;
  else root.RR_AUDIO = mod;
/* ⛔ `self` FIRST, THEN `globalThis`, AND `this` ONLY AS A LAST RESORT — and that ordering is a
 * fix, not a style choice. In a CommonJS module `this` is `module.exports`, i.e. `{}`, so the
 * original `self : this` made `root` an empty object under Node. In the browser that is invisible
 * (`self` is `window`), but it meant this module could never see an injected AudioContext and was
 * therefore UNTESTABLE headless — `ui_smoke.js` built a whole fake Web Audio graph and audio.js
 * read `state=none` from it. A module that cannot find the global cannot be tested against one,
 * and §0z says the harness is the only tester there is. */
})(typeof self !== 'undefined' ? self : (typeof globalThis !== 'undefined' ? globalThis : this), function (root, P) {
  'use strict';

  var BASE = (P && P.audio) || '../../Product_Release/assets/audio/';
  var AC = root && (root.AudioContext || root.webkitAudioContext);

  var ctx = null, master = null, musicBus = null, sfxBus = null;
  var manifest = null;
  var buffers = {};          // name -> AudioBuffer
  var pending = {};          // name -> Promise, so two callers never fetch twice
  var current = null;        // { name, sources:[], gains:{stem:GainNode}, bus:GainNode, startedAt }
  var muted = false;
  var failed = [];
  var given = 0;             // how many powers the run has given away — drives the stem mask

  /* ⛔ THE GENERATION TOKEN, AND IT IS A REAL BUG FIX RATHER THAN A PRECAUTION.
   * `playMusic` awaits a fetch and a decode, so several calls can be in flight at once — a
   * player walking prologue -> descent -> battle faster than a 1.2 MB stem set decodes queues
   * three of them. `stopMusic` only stops `current`, and `current` is assigned at the END of the
   * async chain, so every earlier call still reached `src.start()` and left sources running that
   * nothing would ever stop: two cues playing over each other, permanently.
   * MEASURED by ui_smoke.js, which drives a whole run synchronously and then awaits once: 50
   * sources came up on a call that should have started 6, with four different loopEnds among
   * them. Each call takes a turn number; if a newer call has started by the time this one is
   * ready to touch the graph, it does nothing. */
  var playSeq = 0;

  function ready() { return !!ctx && !!master; }

  /* ─── GRAPH ──────────────────────────────────────────────────────────────────────────────
   * MUST be built from a user gesture, or the context starts suspended and every later start()
   * is silent with no error anywhere — the commonest way browser audio "works" in development
   * and ships mute.
   */
  function init() {
    if (ctx || !AC) return ready();
    try {
      ctx = new AC();
      master = ctx.createGain();
      master.gain.value = muted ? 0 : 0.85;
      master.connect(ctx.destination);

      musicBus = ctx.createGain();
      musicBus.gain.value = 0.62;
      musicBus.connect(master);

      /* SFX do NOT pass through the music bus's ducking. A UI sound is the player's own hand and
       * must stay legible at the exact moment the mix is thinnest and the screen is busiest. */
      sfxBus = ctx.createGain();
      sfxBus.gain.value = 0.65;
      sfxBus.connect(master);
      return true;
    } catch (e) {
      failed.push('AudioContext: ' + e.message);
      ctx = null;
      return false;
    }
  }

  function resume() {
    if (!ctx) init();
    if (ctx && ctx.state === 'suspended' && ctx.resume) ctx.resume().catch(function () {});
    return ready();
  }

  function loadManifest() {
    if (manifest) return Promise.resolve(manifest);
    if (typeof root.fetch !== 'function') { manifest = { tracks: [] }; return Promise.resolve(manifest); }
    return root.fetch(BASE + 'tracks.json').then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    }).then(function (j) { manifest = j; return j; })
      .catch(function (e) { failed.push('tracks.json: ' + e.message); manifest = { tracks: [] }; return manifest; });
  }

  function load(name) {
    if (buffers[name]) return Promise.resolve(buffers[name]);
    if (pending[name]) return pending[name];
    if (!ready() || typeof root.fetch !== 'function') return Promise.resolve(null);
    pending[name] = root.fetch(BASE + name + '.ogg').then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.arrayBuffer();
    }).then(function (bytes) {
      return new Promise(function (res, rej) {
        // callback form: Safari still does not return a promise from decodeAudioData
        var p = ctx.decodeAudioData(bytes, res, rej);
        if (p && p.then) p.then(res, rej);
      });
    }).then(function (buf) {
      buffers[name] = buf; delete pending[name]; return buf;
    }).catch(function (e) {
      failed.push(name + '.ogg: ' + e.message); delete pending[name]; return null;
    });
    return pending[name];
  }

  /** Which files does this cue actually consist of? One, or six if it is the stem track. */
  function filesFor(name) {
    var meta = trackMeta(name);
    if (meta && meta.stems && meta.stems.length) {
      return meta.stems.map(function (s) { return name + '_' + s; });
    }
    return [name];
  }

  function trackMeta(name) {
    var list = (manifest && manifest.tracks) || [];
    for (var i = 0; i < list.length; i++) if (list[i].name === name) return list[i];
    return null;
  }

  /* ─── THE STEM MASK ──────────────────────────────────────────────────────────────────────
   * The whole mechanic, in two functions. `dropAt` and the tier table come from tracks.json,
   * which compose.js wrote from MEASURED loudness — nothing about the arc is typed twice.
   */
  function liveStems(g) {
    var b = manifest && manifest.battle;
    if (!b) return null;
    return b.allStems.filter(function (s) {
      return b.dropAt[s] === undefined || g < b.dropAt[s];
    });
  }

  function tierFor(g) {
    var b = manifest && manifest.battle;
    if (!b || !b.tiers || !b.tiers.length) return null;
    var pick = b.tiers[0];
    for (var i = 0; i < b.tiers.length; i++) if (b.tiers[i].given <= g) pick = b.tiers[i];
    return pick;
  }

  /**
   * Set how many powers the run has given away. Ramps any newly-lost stem to silence over
   * `fade` seconds and applies the tier's measured makeup gain to the music bus.
   * ⛔ It is a SET, not an increment: the caller is the scene machine's own `given` count, so a
   * reload, a resume or a harness jumping straight to depth 7 all land on the right mix. An
   * incrementing counter here would be a second copy of the run's state and would drift.
   */
  function setGiven(n, fade) {
    given = Math.max(0, Number(n) || 0);
    if (!ready() || !current || !current.gains) return given;
    var live = liveStems(given);
    if (!live) return given;
    var now = ctx.currentTime, f = fade == null ? 1.2 : fade;
    Object.keys(current.gains).forEach(function (stem) {
      var g = current.gains[stem];
      var want = live.indexOf(stem) === -1 ? 0.0001 : 1;
      g.gain.cancelScheduledValues(now);
      g.gain.setValueAtTime(Math.max(0.0001, g.gain.value), now);
      g.gain.linearRampToValueAtTime(want, now + f);
    });
    /* ⛔ THE TIER MAKEUP BELONGS TO THE STEM TRACK AND NOTHING ELSE. `given` changes on the
     * SACRIFICE screen, where mus_giving is playing — applying the battle tier's gain to that
     * cue would quietly re-level a cue the tier was never measured on. Guard on the thing that
     * actually identifies the stem track: it is the only cue with per-stem gains. */
    var tier = Object.keys(current.gains).length ? tierFor(given) : null;
    if (tier && current.bus) {
      var lin = Math.pow(10, (tier.makeupDb || 0) / 20);
      current.bus.gain.cancelScheduledValues(now);
      current.bus.gain.setValueAtTime(current.bus.gain.value, now);
      current.bus.gain.linearRampToValueAtTime(lin, now + f);
    }
    return given;
  }

  function stopMusic(fade) {
    if (!ready() || !current) return false;
    var now = ctx.currentTime, f = fade == null ? 0.5 : fade;
    var old = current;
    current = null;
    old.bus.gain.cancelScheduledValues(now);
    old.bus.gain.setValueAtTime(Math.max(0.0001, old.bus.gain.value), now);
    old.bus.gain.linearRampToValueAtTime(0.0001, now + f);
    old.sources.forEach(function (s) { try { s.stop(now + f + 0.1); } catch (e) { /* already stopped */ } });
    return true;
  }

  /**
   * Loop a cue, crossfading out whatever is playing. For the stem track this starts SIX sources
   * on one timestamp.
   *
   * ⛔ THE LOOP POINT COMES FROM THE MANIFEST, NEVER A CONSTANT HERE. The renderer appends a
   *    release-and-reverb tail; compose.js bakes it into the head and writes the resulting
   *    `loopEnd`. A duration typed into this file could not notice if synth.js retuned its
   *    reverb (master §2b: an assert must re-derive, never restate).
   */
  function playMusic(name, opts) {
    opts = opts || {};
    if (!ready()) return Promise.resolve(false);
    if (current && current.name === name && !opts.restart) return Promise.resolve(true);
    var myTurn = ++playSeq;
    return loadManifest().then(function () {
      var files = filesFor(name);
      return Promise.all(files.map(load)).then(function (bufs) {
        // ⛔ EVERYTHING BELOW TOUCHES THE GRAPH, SO THE STALENESS CHECK GOES HERE — after the
        //    last await and before the first side effect. A newer call has already taken over.
        if (myTurn !== playSeq) return false;
        if (bufs.some(function (b) { return !b; })) return false;
        var meta = trackMeta(name);
        var loop = meta ? meta.loops !== false : true;
        if (opts.loop === false) loop = false;

        stopMusic(0.6);

        var now = ctx.currentTime;
        var t0 = now + 0.06;                    // one timestamp for every stem: the sample lock
        var bus = ctx.createGain();
        var tier = meta && meta.stems ? tierFor(given) : null;
        var busTarget = tier ? Math.pow(10, (tier.makeupDb || 0) / 20) : 1;
        bus.gain.setValueAtTime(0.0001, now);
        bus.gain.linearRampToValueAtTime(busTarget, now + (opts.fadeIn == null ? 0.8 : opts.fadeIn));
        bus.connect(musicBus);

        var live = meta && meta.stems ? liveStems(given) : null;
        var sources = [], gains = {};
        files.forEach(function (f, i) {
          var stem = meta && meta.stems ? meta.stems[i] : null;
          var g = ctx.createGain();
          g.gain.value = (stem && live && live.indexOf(stem) === -1) ? 0.0001 : 1;
          g.connect(bus);
          var src = ctx.createBufferSource();
          src.buffer = bufs[i];
          if (loop) {
            src.loop = true;
            src.loopStart = 0;
            src.loopEnd = (meta && meta.loopEnd > 0) ? meta.loopEnd : bufs[i].duration;
          }
          src.connect(g);
          src.start(t0);
          sources.push(src);
          if (stem) gains[stem] = g;
        });
        current = { name: name, sources: sources, gains: gains, bus: bus, startedAt: t0, loop: loop };
        return true;
      });
    });
  }

  /** A one-shot over the top, ducking whatever is playing. Used for the ending and the defeat. */
  function sting(name) {
    if (!ready()) return Promise.resolve(false);
    return loadManifest().then(function () { return load(name); }).then(function (buf) {
      if (!buf) return false;
      var now = ctx.currentTime;
      if (current) {
        current.bus.gain.cancelScheduledValues(now);
        current.bus.gain.setValueAtTime(Math.max(0.0001, current.bus.gain.value), now);
        current.bus.gain.linearRampToValueAtTime(0.10, now + 0.3);
      }
      var g = ctx.createGain();
      g.gain.value = 1.05;
      g.connect(musicBus);
      var src = ctx.createBufferSource();
      src.buffer = buf; src.connect(g); src.start(now);
      return true;
    });
  }

  /** Warm a cue's files without playing it. Called during text scenes so the fight starts clean. */
  function prefetch(name) {
    if (!ready()) return Promise.resolve(false);
    return loadManifest().then(function () {
      return Promise.all(filesFor(name).map(load)).then(function (b) {
        return b.every(function (x) { return !!x; });
      });
    });
  }

  /* ─── SFX ────────────────────────────────────────────────────────────────────────────────
   * Synthesised per fire from oscillators and filtered noise. Each is designed against
   * something the player can SEE, so the ear and the eye describe the same event.
   */
  function noiseBuffer(seconds) {
    var n = Math.floor(ctx.sampleRate * seconds);
    var b = ctx.createBuffer(1, n, ctx.sampleRate);
    var d = b.getChannelData(0);
    for (var i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    return b;
  }

  function tone(o) {
    var t0 = ctx.currentTime + (o.delay || 0);
    var osc = ctx.createOscillator();
    osc.type = o.wave || 'square';
    osc.frequency.setValueAtTime(o.from, t0);
    if (o.to && o.to !== o.from) osc.frequency.exponentialRampToValueAtTime(Math.max(1, o.to), t0 + o.dur);
    var g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(o.gain || 0.2, t0 + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + o.dur);
    osc.connect(g); g.connect(sfxBus);
    osc.start(t0); osc.stop(t0 + o.dur + 0.02);
  }

  function hiss(o) {
    var t0 = ctx.currentTime + (o.delay || 0);
    var src = ctx.createBufferSource();
    src.buffer = noiseBuffer(o.dur + 0.02);
    var f = ctx.createBiquadFilter();
    f.type = o.type || 'bandpass';
    f.frequency.setValueAtTime(o.from, t0);
    if (o.to && o.to !== o.from) f.frequency.exponentialRampToValueAtTime(Math.max(1, o.to), t0 + o.dur);
    f.Q.value = o.q == null ? 1.2 : o.q;
    var g = ctx.createGain();
    g.gain.setValueAtTime(o.gain || 0.15, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + o.dur);
    src.connect(f); f.connect(g); g.connect(sfxBus);
    src.start(t0); src.stop(t0 + o.dur + 0.02);
  }

  var SFX = {
    /* moving the cursor: quiet, high, no pitch movement — it must never compete with the music */
    move: function () { tone({ wave: 'square', from: 740, dur: 0.045, gain: 0.075 }); },
    /* committing to a power: the same gesture as `move`, a fifth up and twice as long */
    select: function () { tone({ wave: 'square', from: 660, to: 990, dur: 0.07, gain: 0.115 }); },

    /* ⭐ THE FOUR TYPES ARE FOUR TIMBRES, AND THE PLAYER LEARNS THEM. The wards in this game are
     * BY TYPE, so hearing which type you just spent is the same information the screen shows —
     * which matters most in the late game, when the party's remaining arsenal is small enough
     * that a wrong type is a lost fight. */
    physical: function () { hiss({ from: 2200, to: 260, dur: 0.13, gain: 0.20, q: 0.9 });
      tone({ wave: 'triangle', from: 200, to: 70, dur: 0.15, gain: 0.19 }); },
    fire: function () { hiss({ from: 500, to: 2600, dur: 0.26, gain: 0.15, q: 0.5 });
      tone({ wave: 'sawtooth', from: 180, to: 420, dur: 0.24, gain: 0.11 }); },
    ice: function () { tone({ wave: 'sine', from: 1900, to: 2900, dur: 0.16, gain: 0.10 });
      tone({ wave: 'sine', from: 2700, to: 1500, dur: 0.20, gain: 0.07, delay: 0.05 });
      hiss({ from: 5200, to: 7200, dur: 0.20, gain: 0.055, q: 2.4 }); },
    arcane: function () { tone({ wave: 'triangle', from: 300, to: 1200, dur: 0.28, gain: 0.10 });
      tone({ wave: 'triangle', from: 452, to: 1808, dur: 0.28, gain: 0.07, delay: 0.02 }); },
    holy: function () { tone({ wave: 'sine', from: 880, dur: 0.34, gain: 0.11 });
      tone({ wave: 'sine', from: 1320, dur: 0.30, gain: 0.075, delay: 0.04 });
      tone({ wave: 'sine', from: 1760, dur: 0.26, gain: 0.05, delay: 0.08 }); },
    ward: function () { tone({ wave: 'triangle', from: 330, to: 494, dur: 0.22, gain: 0.13 });
      hiss({ from: 900, to: 400, dur: 0.18, gain: 0.06, q: 1.6 }); },
    heal: function () { tone({ wave: 'triangle', from: 523, dur: 0.16, gain: 0.10 });
      tone({ wave: 'triangle', from: 784, dur: 0.22, gain: 0.10, delay: 0.10 }); },

    /* the boss hitting you. `heavy` is the telegraphed one and is the only SFX with a real thump */
    hit: function () { tone({ wave: 'sawtooth', from: 150, to: 96, dur: 0.24, gain: 0.17 });
      hiss({ from: 700, to: 210, dur: 0.20, gain: 0.12, q: 0.7 }); },
    heavy: function () { tone({ wave: 'sawtooth', from: 120, to: 58, dur: 0.42, gain: 0.24 });
      hiss({ from: 1400, to: 160, dur: 0.36, gain: 0.17, q: 0.6 });
      tone({ wave: 'square', from: 78, to: 46, dur: 0.40, gain: 0.10, delay: 0.03 }); },
    /* the attack turned aside — the same event as `hit`, cut short and up a register */
    warded: function () { hiss({ from: 1500, to: 900, dur: 0.10, gain: 0.11, q: 2.0 });
      tone({ wave: 'square', from: 494, dur: 0.08, gain: 0.09 }); },

    /* a ward breaking: the only rising consonant interval in the whole set, so it reads as GOOD
     * at a moment when everything else on screen is going down */
    wardBroken: function () { tone({ wave: 'triangle', from: 587, dur: 0.13, gain: 0.14 });
      tone({ wave: 'triangle', from: 880, dur: 0.22, gain: 0.14, delay: 0.09 });
      tone({ wave: 'sine', from: 1175, dur: 0.26, gain: 0.08, delay: 0.17 }); },
    bossDown: function () { tone({ wave: 'triangle', from: 392, dur: 0.16, gain: 0.15 });
      tone({ wave: 'triangle', from: 587, dur: 0.16, gain: 0.15, delay: 0.13 });
      tone({ wave: 'triangle', from: 784, dur: 0.44, gain: 0.16, delay: 0.26 }); },

    /* ⭐ GIVING A POWER UP. The one SFX in the set that FALLS all the way to nothing and does not
     * resolve — it is the sound of the thing leaving, and it plays over a score that is about to
     * be one voice smaller. */
    give: function () { tone({ wave: 'sine', from: 660, to: 82, dur: 0.85, gain: 0.15 });
      hiss({ from: 3000, to: 200, dur: 0.75, gain: 0.09, q: 0.7 });
      tone({ wave: 'triangle', from: 330, to: 62, dur: 0.90, gain: 0.09, delay: 0.06 }); },
    down: function () { tone({ wave: 'sawtooth', from: 300, to: 60, dur: 0.50, gain: 0.16 }); }
  };

  function sfx(name) {
    if (!ready() || muted) return false;
    var f = SFX[name];
    if (!f) return false;
    try { f(); return true; } catch (e) { return false; }
  }

  function setMuted(v) {
    muted = !!v;
    if (ready()) master.gain.setTargetAtTime(muted ? 0 : 0.85, ctx.currentTime, 0.05);
    return muted;
  }

  var API = {
    init: init, resume: resume, playMusic: playMusic, stopMusic: stopMusic, sting: sting,
    prefetch: prefetch, setGiven: setGiven, sfx: sfx, setMuted: setMuted,
    toggleMute: function () { return setMuted(!muted); },
    /* read-only views, for the harness and for ui_smoke */
    get muted() { return muted; },
    get available() { return !!AC; },
    get ready() { return ready(); },
    get state() { return ctx ? ctx.state : 'none'; },
    get failed() { return failed.slice(); },
    get playing() { return current ? current.name : null; },
    get given() { return given; },
    get liveStems() { return liveStems(given); },
    /* ⭐ THE GRAPH ITSELF, READ BACK. `liveStems` is what the mask INTENDS; this is what the
     * mixer was actually told, straight off the GainNodes. Asserting only the first is §2b's
     * "verifying against the field you wrote" — a correct list over a mixer that never applies
     * it looks identical from the outside. Read-only, and the only reason it exists is that
     * §0z makes the harness the only tester there is. */
    get stemGain() {
      var out = {};
      if (current && current.gains) {
        Object.keys(current.gains).forEach(function (s) { out[s] = current.gains[s].gain.value; });
      }
      return out;
    },
    get manifest() { return manifest; },
    SFX_NAMES: Object.keys(SFX),
    /* ⚠️ exposed so the SOURCE SWEEP in the audio gate can read the cue names this file plays
     * without parsing call sites out of a string — but the gate ALSO greps the call sites, and
     * disagreement between the two is the finding. */
    CUES: ['mus_cairn', 'mus_battle', 'mus_giving', 'mus_ending', 'mus_defeat']
  };
  return API;
});
