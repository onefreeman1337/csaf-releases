/*
 * REVERSE RPG — ui.js
 * The renderer and the input layer. Draws the scene machine; owns no rules.
 *
 * ⛔⛔ `tick()` IS THE ONE PLACE A FRAME HAPPENS, AND requestAnimationFrame IS MERELY ONE CALLER
 *     OF IT. wing §6b-18, measured on AUGUR and it cost most of a session to recognise: Chrome
 *     does not fire rAF at all in a background tab, and an unattended session never has a
 *     foreground one — so a rAF-owned loop cannot be driven by any harness. It fails wearing
 *     the costume of a working game: the screenshot shows a correctly rendered title screen
 *     (a screenshot paints on demand, so it proves the page is alive and NOTHING about the
 *     loop), the console is empty, and a frame counter reads zero forever.
 *     ⛔ Do NOT "fix" that by foregrounding the tab — that makes every future playthrough
 *     depend on window state no unattended session controls.
 *     ✅ `window.__RR.tick(n)` and `window.__RR.key(k)` drive the SHIPPED product, not a double.
 */
(function (root, factory) {
  'use strict';
  var mod = factory(root,
    typeof module === 'object' && module && module.exports ? require('./rules.js')   : root.RR_RULES,
    typeof module === 'object' && module && module.exports ? require('./content.js') : root.RR_CONTENT,
    typeof module === 'object' && module && module.exports ? require('./run.js')     : root.RR_RUN,
    typeof module === 'object' && module && module.exports ? require('./art.js')     : root.RR_ART,
    typeof module === 'object' && module && module.exports ? require('./paths.js')   : root.RR_PATHS,
    typeof module === 'object' && module && module.exports ? require('./audio.js')   : root.RR_AUDIO,
    typeof module === 'object' && module && module.exports ? require('./backdrop.js'): root.RR_BACKDROP
  );
  if (typeof module === 'object' && module && module.exports) module.exports = mod;
  else root.RR_UI = mod;
/* `self` first, then `globalThis` — see the note at the head of audio.js. `this` in a CommonJS
 * module is `module.exports`, so the old fallback handed this factory an empty object as its
 * global and silently disabled `root.localStorage` (the mute/best-depth store) under any headless
 * test. Browser behaviour is unchanged: `self` is defined there and is picked first. */
})(typeof self !== 'undefined' ? self : (typeof globalThis !== 'undefined' ? globalThis : this), function (root, R, C, RUN, A, P, SND, BD) {
  'use strict';

  var L = A.LAYOUT, PAL = A.PAL, F = A.FONT;

  // ─── STORAGE ────────────────────────────────────────────────────────────────────────
  // ⛔ EVERY KEY READ HERE IS WRITTEN HERE. wing §0z: Lanternbound's entire second half was
  //    unreachable because a storage key was READ by one page and WRITTEN BY NOTHING — a dead
  //    reader is an untested code path, not a missing feature. The pairs are declared so a
  //    static check can assert it rather than a reader trusting this comment.
  var STORE_KEYS = ['rr_mute', 'rr_best'];

  // How many damage numbers may be in flight at once. Published on the instance so the UI test
  // asserts the product's own bound rather than a copy of it.
  var FLOAT_CAP = 6;
  function store(k, v) {
    try {
      if (v === undefined) return root.localStorage ? root.localStorage.getItem(k) : null;
      if (root.localStorage) root.localStorage.setItem(k, v);
      return v;
    } catch (e) { return null; }   // private mode, sandboxed iframe: never let this break a run
  }

  function create(canvas, opts) {
    opts = opts || {};
    var ctx = canvas.getContext('2d');
    var seed = opts.seed !== undefined ? opts.seed : ((Date.now() >>> 0) % 100000);
    var g = RUN.create(seed, (P && P.build) || 'full');
    var loader = A.createLoader(opts.imageFactory || function () { return new root.Image(); });

    var S = {
      g: g, ctx: ctx, canvas: canvas,
      frames: 0, timeMs: 0,
      anim: { shake: 0, flash: 0, floats: [], fx: null, fxT: 0 },
      cursor: 0,
      muted: store('rr_mute') === '1',
      best: parseInt(store('rr_best') || '0', 10) || 0,
      ready: false, loadError: null,
      lastKey: null,
      log: []
    };
    store('rr_mute', S.muted ? '1' : '0');   // the reader above has a writer, always
    store('rr_best', String(S.best));

    loader.load(function (err) { S.ready = true; S.loadError = err || null; });

    // ─── SOUND ────────────────────────────────────────────────────────────────────────
    // ⛔ ONE PLACE DECIDES WHAT IS PLAYING, and it is driven off the scene machine's own state
    //    rather than sprinkled through the input handler. A cue started from a key handler is a
    //    cue that does not start when the harness drives the same transition, and wing §0z now
    //    makes the harness the only tester there is.
    // ⛔ EVERY CALL IS GUARDED. `SND` is absent in a Node sandbox with no Web Audio (ui_smoke),
    //    and silent until the browser has seen a gesture. A silent game must still be playable.
    var AU = { scene: null, given: -1, mutedAt: null };

    function musicFor(scene) {
      if (scene === 'battle') return 'mus_battle';
      // the aftermath leads straight into the sacrifice, so they share a cue: the giving theme
      // starts the moment the boss goes down, before the player is asked what it cost.
      if (scene === 'aftermath' || scene === 'sacrifice') return 'mus_giving';
      if (scene === 'ending' || scene === 'defeat') return null;   // stings, see below
      return 'mus_cairn';                                          // title, prologue, descent, demowall
    }

    function snd(name) { if (SND && SND.ready) SND.sfx(name); }

    // ⛔ TRANSIENT COMBAT STATE BELONGS TO THE FIGHT AND MUST NOT SURVIVE IT.
    //    FOUND BY LOOKING at the real page (wing §0z), not by the suite: the sacrifice screen was
    //    rendering leftover damage floats from the fight that had just ended — "-75" across the
    //    heading and "-5" printed through THE SHIELD WALL's card title. A float lives 900ms and
    //    the scene changes well inside that, so they carried over onto a screen with no combat on
    //    it. The shake, the flash and the element FX are the same class of state.
    // ⛔ IT IS ITS OWN WATCHER, NOT PART OF syncAudio, AND THAT MATTERS. syncAudio returns early
    //    when there is no AudioContext — a silent game, a Node sandbox, or a browser before the
    //    first gesture — so putting this there would have made a PICTURE defect depend on whether
    //    SOUND was available. Two unrelated things sharing one early return is how a fix ends up
    //    working only on the machine it was written on.
    // ⚠️ ui_smoke could not see the defect because its text-collision rule EXCLUDES floats by
    //    shape, an exclusion that is right on the battle screen and hid a real defect everywhere
    //    else. It now carries the honest assertion instead: a float may only exist in a fight.
    //    Scoping a rule to kill a false red can hide a true one; the answer is a sharper rule.
    var lastScene = null;
    function syncScene() {
      if (S.g.scene === lastScene) return;
      lastScene = S.g.scene;
      S.anim.floats.length = 0;
      S.anim.shake = 0; S.anim.flash = 0; S.anim.fx = null; S.anim.fxT = 0;
    }

    function syncAudio() {
      if (!SND || !SND.ready) return;
      var g2 = S.g;
      if (S.muted !== AU.mutedAt) { SND.setMuted(S.muted); AU.mutedAt = S.muted; }

      // ⭐ THE MECHANIC. `given` is READ from the run, never counted here — a second counter is a
      //    second thing to drift, and a reload or a harness jumping straight to depth 7 must land
      //    on the right mix. setGiven ramps the lost stems to silence; it does not restart music.
      var gv = g2.run ? g2.run.sacrificed.length : 0;
      if (gv !== AU.given) { AU.given = gv; SND.setGiven(gv); }

      if (g2.scene === AU.scene) return;
      AU.scene = g2.scene;
      if (g2.scene === 'ending') { SND.stopMusic(1.4); SND.sting('mus_ending'); return; }
      if (g2.scene === 'defeat') { SND.stopMusic(0.9); SND.sting('mus_defeat'); return; }
      var want = musicFor(g2.scene);
      if (want) SND.playMusic(want);
      // warm the NEXT cue during a scene the player reads rather than plays, so a 1.2 MB stem
      // set is never fetched at the moment a fight is supposed to start
      if (g2.scene === 'descent' || g2.scene === 'prologue') SND.prefetch('mus_battle');
      if (g2.scene === 'battle') SND.prefetch('mus_giving');
    }

    // ─── INPUT ────────────────────────────────────────────────────────────────────────
    // Every key a player can press routes through here, so the harness pressing 'x' and a
    // person pressing 'x' take the identical path.
    function key(k) {
      S.lastKey = k;
      var g = S.g;
      // ⛔ A BROWSER STARTS ITS AudioContext SUSPENDED AND ONLY A USER GESTURE MAY RESUME IT.
      //    This is the gesture. Doing it here rather than on one "press start" button means the
      //    context is live whatever the player touches first, and a player who never presses a
      //    key never hears anything, which is correct: no autoplay (wing §1b).
      if (SND && SND.available) SND.resume();
      if (k === 'm') {
        S.muted = !S.muted; store('rr_mute', S.muted ? '1' : '0');
        if (SND && SND.ready) { SND.setMuted(S.muted); AU.mutedAt = S.muted; }
        return { ok: true, muted: S.muted };
      }

      if (g.scene === 'battle') {
        var ready = R.readyPowers(g.fight, g.run.powers);
        if (k === 'ArrowLeft' || k === 'a') { S.cursor = (S.cursor - 1 + Math.max(1, ready.length)) % Math.max(1, ready.length); snd('move'); return { ok: true }; }
        if (k === 'ArrowRight' || k === 'd') { S.cursor = (S.cursor + 1) % Math.max(1, ready.length); snd('move'); return { ok: true }; }
        if (k === 'Enter' || k === ' ' || k === 'x') {
          if (!ready.length) return applyResult(RUN.pass(g));
          var pick = ready[Math.min(S.cursor, ready.length - 1)];
          return applyResult(RUN.spend(g, pick.id), pick);
        }
        var n = parseInt(k, 10);
        if (!isNaN(n) && n >= 1 && n <= ready.length) return applyResult(RUN.spend(g, ready[n - 1].id), ready[n - 1]);
        return { ok: false, reason: 'no-binding-for-' + k };
      }

      if (g.scene === 'sacrifice') {
        var opts2 = RUN.options(g);
        if (k === 'ArrowLeft' || k === 'a') { S.cursor = (S.cursor - 1 + opts2.length) % opts2.length; snd('move'); return { ok: true }; }
        if (k === 'ArrowRight' || k === 'd') { S.cursor = (S.cursor + 1) % opts2.length; snd('move'); return { ok: true }; }
        if (k === 'Enter' || k === ' ' || k === 'x') {
          var o = opts2[Math.min(S.cursor, opts2.length - 1)];
          var res = RUN.give(g, o.power.id);
          // the one sound in the set that falls all the way to nothing and does not resolve
          if (res.ok) { S.cursor = 0; S.log.push('given: ' + o.power.name); snd('give'); }
          return res;
        }
        return { ok: false, reason: 'no-binding-for-' + k };
      }

      // Text scenes: any of the advance keys.
      if (k === 'Enter' || k === ' ' || k === 'x') {
        var before = g.scene;
        var r = RUN.advance(g);
        if (r.ok) {
          S.cursor = 0;
          if (g.depth > S.best) { S.best = g.depth; store('rr_best', String(S.best)); }
          if (before !== g.scene) S.anim.flash = 0;
          snd('select');
        }
        return r;
      }
      return { ok: false, reason: 'no-binding-for-' + k };
    }

    function applyResult(res, power) {
      if (!res.ok) return res;
      S.cursor = 0;
      // ⭐ THE FOUR ELEMENT SOUNDS ARE INFORMATION, NOT DECORATION. Boss wards are BY TYPE, so
      //    hearing which type just left the party is the same fact the screen shows — and it is
      //    the fact that decides late fights, when the arsenal is small enough that one wrong
      //    type loses the rung. Fired before the events so the cause is heard before the effect.
      if (power && power.type) snd(power.type);
      // ⚠️ ONE PASS OVER THE EVENTS. The picture and the sound for a given event are decided
      //    beside each other, so an event that grows a float and no sound (or the reverse) is
      //    visible in the source rather than being two lists that drift apart.
      // `fan` is how many RECENT floats are already in flight in this lane — see floats(). Only
      // the recent ones count: an older one has already risen clear on its own, and counting it
      // would push a new number needlessly far up the screen. The hard cap keeps the oldest from
      // being flung off the top under input spam, which is a `breakit` case, not a hypothetical.
      var fanAt = function (x) {
        var n = 0;
        for (var q = 0; q < S.anim.floats.length; q++) {
          if (Math.abs(S.anim.floats[q].x - x) < 60 && S.anim.floats[q].t < 260) n++;
        }
        return Math.min(n, 3);
      };
      for (var i = 0; i < (res.events || []).length; i++) {
        var e = res.events[i];
        if (e.t === 'player-damage') {
          S.anim.floats.push({ x: L.stage.x + L.stage.w * 0.68, y: L.stage.y + 110, v: '-' + e.amount, c: e.warded ? PAL.inkDim : PAL.warm, t: 0, fan: fanAt(L.stage.x + L.stage.w * 0.68) });
          S.anim.fx = power && power.type ? power.type : 'physical'; S.anim.fxT = 0;
          S.anim.shake = e.warded ? 2 : 6;
          // the boss resisting is the single most consequential thing the player can be told
          if (e.warded) snd('warded');
        } else if (e.t === 'player-heal') {
          S.anim.floats.push({ x: L.cols.left.x + 100, y: 280, v: '+' + e.amount, c: PAL.heal, t: 0, fan: fanAt(L.cols.left.x + 100) });
          snd('heal');
        } else if (e.t === 'player-shield') {
          S.anim.floats.push({ x: L.cols.left.x + 100, y: 280, v: '+' + e.amount, c: PAL.ward, t: 0, fan: fanAt(L.cols.left.x + 100) });
          snd('ward');
        } else if (e.t === 'boss-attack') {
          S.anim.floats.push({ x: L.cols.left.x + 100, y: 250, v: '-' + e.through, c: e.heavy ? PAL.bad : PAL.inkDim, t: 0, fan: fanAt(L.cols.left.x + 100) });
          if (e.heavy) S.anim.shake = 10;
          S.anim.flash = e.through > 0 ? 1 : 0;
          snd(e.heavy ? 'heavy' : (e.through > 0 ? 'hit' : 'warded'));
        }
      }
      // ⛔ TRIM AFTER PUSHING, NOT BEFORE. Trimming first left the cap plus this turn's new
      //    floats on screen, so the real ceiling was CAP + 2 and the number no test could state
      //    without recomputing it. Trimming here makes FLOAT_CAP a true invariant that ui_smoke
      //    can assert by reading the constant instead of guessing a bound (§2b: an assert must
      //    re-derive, never restate — and a bar chosen to fit the day's data is not a bar).
      while (S.anim.floats.length > FLOAT_CAP) S.anim.floats.shift();
      // the rung falling: the only ascending triad in the set
      if (S.g.scene === 'aftermath') snd('bossDown');
      else if (S.g.scene === 'defeat') snd('down');
      if (S.g.depth > S.best) { S.best = S.g.depth; store('rr_best', String(S.best)); }
      return res;
    }

    // ─── THE FRAME ────────────────────────────────────────────────────────────────────
    function tick(dtMs) {
      var dt = Math.max(0, Math.min(100, dtMs === undefined ? 16 : dtMs));
      S.frames++; S.timeMs += dt;
      if (S.anim.shake > 0) S.anim.shake = Math.max(0, S.anim.shake - dt * 0.03);
      if (S.anim.flash > 0) S.anim.flash = Math.max(0, S.anim.flash - dt * 0.004);
      if (S.anim.fx !== null) { S.anim.fxT += dt; if (S.anim.fxT > 360) { S.anim.fx = null; S.anim.fxT = 0; } }
      for (var i = S.anim.floats.length - 1; i >= 0; i--) {
        S.anim.floats[i].t += dt;
        if (S.anim.floats[i].t > 900) S.anim.floats.splice(i, 1);
      }
      // ⛔ IN THE FRAME, NOT IN THE KEY HANDLER. Scene changes also happen from RUN.advance
      //    called by the harness, and from a transition the player did not press a key for, so
      //    music started from `key()` would be music that never starts under test — and under
      //    §0z the harness is the only tester there is.
      syncScene();          // always — it is a picture question, not a sound one
      syncAudio();
      draw();
      return S.frames;
    }

    // ─── DRAW ─────────────────────────────────────────────────────────────────────────
    function draw() {
      var g = S.g;
      ctx.save();
      var sh = S.anim.shake;
      if (sh > 0) ctx.translate(Math.round((Math.random() - 0.5) * sh), Math.round((Math.random() - 0.5) * sh));
      backdrop();
      switch (g.scene) {
        case 'title':     drawTitle(); break;
        /* Every prose screen gets the chamber it is standing in — see textChamber(). */
        case 'prologue':  textChamber(); drawText(C.STORY.opening.slice(0, g.page + 1), 'THE DESCENT'); break;
        case 'descent':   textChamber(); drawDescent(); break;
        case 'battle':    drawBattle(); break;
        case 'aftermath': textChamber(); drawAftermath(); break;
        case 'sacrifice': textChamber(); drawSacrifice(); break;
        case 'ending':    textChamber(); drawText(C.STORY.endingWin, 'THE BOTTOM OF THE CAIRN'); break;
        case 'defeat':    textChamber(); drawText(C.STORY.endingLoss, 'YOU DID NOT COME BACK UP'); break;
        case 'demowall':  textChamber(); drawText(C.STORY.demoEnd, 'THE STAIR KEEPS GOING'); break;
        default:
          // ⛔ An unhandled scene must SAY SO on screen. A blank canvas is the one failure a
          //    player cannot report and a screenshot cannot diagnose.
          A.text(ctx, 'UNHANDLED SCENE: ' + g.scene, 40, 60, { font: F.display(22), colour: PAL.bad });
      }
      if (S.anim.flash > 0) { ctx.fillStyle = 'rgba(201,69,90,' + (0.22 * S.anim.flash).toFixed(3) + ')'; ctx.fillRect(0, 0, A.W, A.H); }
      floats();
      ctx.restore();
      hud();
    }

    function backdrop() {
      var grd = ctx.createLinearGradient(0, 0, 0, A.H);
      grd.addColorStop(0, PAL.bg0); grd.addColorStop(0.55, PAL.bg1); grd.addColorStop(1, PAL.bg2);
      ctx.fillStyle = grd; ctx.fillRect(0, 0, A.W, A.H);
      // a soft warm pool at the top of the stage: the only light down here
      var r = ctx.createRadialGradient(A.W * 0.5, 40, 10, A.W * 0.5, 40, 420);
      r.addColorStop(0, 'rgba(240,179,87,0.13)'); r.addColorStop(1, 'rgba(240,179,87,0)');
      ctx.fillStyle = r; ctx.fillRect(0, 0, A.W, A.H);
      // vignette
      var v = ctx.createRadialGradient(A.W / 2, A.H / 2, A.H * 0.35, A.W / 2, A.H / 2, A.H * 0.95);
      v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(0,0,0,0.55)');
      ctx.fillStyle = v; ctx.fillRect(0, 0, A.W, A.H);
    }

    // ⛔ TWO NUMBERS THAT ARRIVE TOGETHER MUST NOT PRINT ON TOP OF EACH OTHER. A float lives
    //    900ms and a spamming player can act several times inside that, so damage numbers stack:
    //    ui_smoke caught "-72" drawn through "-30" at one y with 36px of overlap.
    // ⚠️ THE FIRST FIX FOR THIS WAS WORSE THAN THE DEFECT and the gate said so on the next run.
    //    It fanned the extra numbers SIDEWAYS by 40px each, which walked them straight out of the
    //    left column and into the gutter — trading a collision nobody would see often for a
    //    layout break on every multi-hit turn. Floats now separate only in Y, where there is
    //    nothing to collide with, and they rise fast enough (70px, not 34) that two a third of a
    //    second apart are already clear of each other.
    function floats() {
      for (var i = 0; i < S.anim.floats.length; i++) {
        var f = S.anim.floats[i];
        var k = f.t / 900;
        ctx.globalAlpha = Math.max(0, 1 - k);
        A.text(ctx, f.v, f.x, f.y - k * 70 - (f.fan || 0) * 24,
          { font: F.num(20), colour: f.c, align: 'center' });
        ctx.globalAlpha = 1;
      }
    }

    function hud() {
      A.text(ctx, S.muted ? 'SOUND OFF  (M)' : 'SOUND ON  (M)', A.W - 16, A.H - 12,
        { font: F.body(11), colour: PAL.inkFaint, align: 'right' });
      if (S.best > 0) A.text(ctx, 'DEEPEST  ' + S.best, 16, A.H - 12, { font: F.body(11), colour: PAL.inkFaint });
      if (!S.ready) A.text(ctx, 'loading…', A.W / 2, A.H - 12, { font: F.body(11), colour: PAL.inkFaint, align: 'center' });
      if (S.loadError) A.text(ctx, 'art unavailable — the game is still playable', A.W / 2, A.H - 12,
        { font: F.body(11), colour: PAL.bad, align: 'center' });
    }

    // ─── SCENES ───────────────────────────────────────────────────────────────────────
    /* ⛔⛔ THE TITLE SCREEN IS THE THUMBNAIL, AND IT USED TO BE TYPE ON A GRADIENT.
     * §0 measures the binding constraint as ARRIVAL and names the browse tile (315x250) as where
     * the click is earned; §3 says a default-engine look is dismissed in the two seconds a
     * thumbnail gets. This screen had NO ART AT ALL — the one screen most likely to be the tile.
     *
     * ⭐ It is built from the product's OWN generated chamber (backdrop.js, the same generator the
     * fights use) and the first-party Wildmark party sprites, so it satisfies §1.1's "the product
     * GENERATES the beauty" rather than decorating a stock template — and it is the premise as a
     * PICTURE: four people at full strength standing at the mouth of a stair that goes down.
     *
     * ⚠️ EVERYTHING IS PLACED AGAINST MEASURED NUMBERS, NOT GUESSED ONES. Figures are anchored by
     * the FEET (§6b-31 rule 2: a Wildmark figure's feet are at row 61 of its 64px cell and it is
     * 14-20px of opaque art, so anchoring by the cell floats it three rows up and clips its head).
     * `FOOT_Y` and `HEAD_Y` are derived from the scale, and the prose above must clear HEAD_Y —
     * ui_smoke asserts nothing leaves the canvas and no string crosses a gutter. */
    var TITLE_SCALE = 3;
    var TITLE_FOOT_Y = 486;

    /* ⛔⛔ THE TEXT SCENES USED TO BE A GRADIENT AND NOTHING ELSE, AND THEY ARE MOST OF THE GAME.
     * `backdrop()` below draws a vertical wash plus a vignette — which is what "no backdrop" looks
     * like with a colour on it (backdrop.js's own header says exactly that about flat fills). The
     * aftermath screen measured ~75% empty canvas and the descent screen ~55%, and between them
     * they are shown TEN TIMES A RUN, once after every rung. §10b's density floor exists for
     * precisely this, and the fix costs nothing because the chamber generator is already here and
     * already cached: the same wall the fight happens in, pushed back under a heavy wash so the
     * prose still reads.
     * ⭐ It is drawn at the CURRENT depth, so the stone cools and darkens as the player descends —
     * `paletteFor(depth)` was already doing that work for the battle screen alone. */
    var chamberCacheByKey = {};
    function cachedChamber(depth, faction, seed) {
      var key = depth + '|' + faction + '|' + seed;
      var make = opts.canvasFactory
        || (typeof root.document !== 'undefined' && root.document.createElement
          ? function () { return root.document.createElement('canvas'); } : null);
      var cfg = { depth: depth, nDepths: 10, faction: faction, seed: seed };
      /* No canvas factory (a bare Node smoke run): draw straight to ctx and skip the cache.
       * ⛔⛔ IT DECLARES ITSELF AS THE BACKDROP LAYER, AND THAT IS NOT A TEST WORKAROUND.
       * `backdrop.js` lays COURSED STONEWORK: a wall is built of whole blocks and the ones at the
       * right-hand edge necessarily run past it, exactly as a real wall's courses do. The browser
       * clips them and the picture is correct. But ui_smoke's bounds check — which exists because
       * this game once drew a legal action off the bottom edge where the player could press it and
       * not see it (§6b-3 rule 4) — cannot tell a clipped background tile from a lost button.
       * ⚠️ The wrong fix is to widen the SLACK until the wall fits: that is "never raise the
       * threshold to pass", and it would blind the check to a real UI element 15px off screen.
       * ⇒ The product DECLARES which layer it is drawing and the gate reads that declaration
       * (§0z: geometry published by the UI and read by the test, so it cannot drift). A real
       * CanvasRenderingContext2D ignores an unknown property, so this costs the shipped game
       * nothing; ui_smoke asserts that ONLY this layer is exempt and that an untagged off-canvas
       * rect still goes RED. */
      ctx.__layer = 'backdrop';
      if (!make) { BD.draw(ctx, 0, 0, A.W, A.H, cfg); ctx.__layer = null; return; }
      if (!chamberCacheByKey[key]) {
        var off = make();
        off.width = A.W; off.height = A.H;
        BD.draw(off.getContext('2d'), 0, 0, A.W, A.H, cfg);
        chamberCacheByKey[key] = off;
      }
      ctx.drawImage(chamberCacheByKey[key], 0, 0);
      ctx.__layer = null;
    }

    /* The chamber a TEXT screen sits in, plus the wash that keeps the type legible. Kept separate
     * from the title's, which uses a lighter wash because it has figures to show. */
    function textChamber() {
      var g = S.g;
      var depth = 0, faction = 'THE RESTLESS DEAD';
      /* ⚠️ `run` does not exist on the title, and `ladder[index]` is past the end once the run is
       * over — both are normal, so this reads defensively rather than assuming a live fight. */
      if (g && g.run && g.run.ladder && g.run.ladder.length) {
        var i = Math.min(g.run.index || 0, g.run.ladder.length - 1);
        depth = i;
        faction = g.run.ladder[i].faction || faction;
      }
      cachedChamber(depth, faction, (g && g.seed) || 7);
      ctx.fillStyle = 'rgba(10,12,16,0.74)';
      ctx.fillRect(0, 0, A.W, A.H);
      /* A soft warm pool from above, so the frame still has a light source and a direction. */
      var r = ctx.createRadialGradient(A.W * 0.5, 20, 10, A.W * 0.5, 20, 460);
      r.addColorStop(0, 'rgba(240,179,87,0.10)'); r.addColorStop(1, 'rgba(240,179,87,0)');
      ctx.fillStyle = r; ctx.fillRect(0, 0, A.W, A.H);
    }

    function drawTitle() {
      cachedChamber(0, 'THE RESTLESS DEAD', 7);

      /* Two washes, and they do different jobs. The first sinks the top of the wall so the display
       * type has something to sit on; the second is the dark the party is about to walk into, and
       * it is what makes the floor read as an edge rather than as more wall. */
      var top = ctx.createLinearGradient(0, 0, 0, 300);
      top.addColorStop(0, 'rgba(10,12,16,0.90)'); top.addColorStop(1, 'rgba(10,12,16,0.18)');
      ctx.fillStyle = top; ctx.fillRect(0, 0, A.W, 300);
      /* ⚠️ The bottom wash stops SHORT of black. Taken to 0.92 the floor crushed out entirely and
       * the frame ended in a dead band — about a tenth of the browse tile spent on nothing. */
      var bot = ctx.createLinearGradient(0, A.H - 110, 0, A.H);
      bot.addColorStop(0, 'rgba(10,12,16,0)'); bot.addColorStop(1, 'rgba(10,12,16,0.80)');
      ctx.fillStyle = bot; ctx.fillRect(0, A.H - 110, A.W, 110);

      /* THE PARTY, at full strength — the only time in the game all four are whole. They stand in
       * the order the roster lists them so the screen and the sheet agree about who is who.
       * ⚠️ THE SPACING IS DELIBERATELY IRREGULAR AND ONE FIGURE IS TURNED. Evenly spaced, all
       * facing the same way, four figures read as a CHARACTER SELECT ROW rather than as a party
       * standing at a threshold — and at browse-tile size (315x250, where §0 says the click is
       * earned) the even rhythm is the first thing that survives scaling down. The offsets below
       * group them 2+2 with a wider centre gap, so the arch mouth stays readable between them. */
      var XS = [-152, -58, 44, 146];
      var YS = [0, 6, -4, 3];
      var FLIP = [false, false, false, true];
      for (var i = 0; i < C.COMPANIONS.length; i++) {
        var cx = Math.round(A.W / 2 + XS[i]);
        var fy = TITLE_FOOT_Y + YS[i];
        var bob = Math.sin((S.timeMs / 900) + i * 1.7) * 2;
        A.shadow(ctx, cx, fy + 2, 46);
        var img = imgFor('wildmark01/' + C.COMPANIONS[i].sprite + '_idle_east_0');
        if (!A.sprite(ctx, img, cx, fy + bob, TITLE_SCALE, { flip: FLIP[i] })) {
          /* ⚠️ The art is fetched, so it can legitimately be absent for a frame or two. A blank
           * screen would read as a broken game; a plain figure reads as loading. */
          ctx.fillStyle = PAL.inkFaint;
          ctx.fillRect(cx - 12, Math.round(fy - 96 + bob), 24, 96);
        }
      }

      A.text(ctx, C.STORY.title, A.W / 2, 132, { font: F.display(58), colour: PAL.ink, align: 'center' });
      A.text(ctx, C.STORY.subtitle.toUpperCase(), A.W / 2, 160, { font: F.body(13), colour: PAL.warm, align: 'center' });
      var lines = A.wrap(ctx, C.STORY.hook, 560, F.body(16));
      for (var j = 0; j < lines.length; j++)
        A.text(ctx, lines[j], A.W / 2, 200 + j * 24, { font: F.body(16), colour: PAL.inkDim, align: 'center' });
      A.text(ctx, 'ENTER  to go down', A.W / 2, 272, { font: F.body(15), colour: PAL.ink, align: 'center' });
      /* ⚠️ At A.H-34 this line landed BETWEEN THE PARTY'S FEET and read as a caption stuck to
       * them. It belongs on the frame's own bottom edge, clear of the figures. */
      A.text(ctx, 'Core Systems Asset Factory', A.W / 2, A.H - 14, { font: F.body(11), colour: PAL.inkFaint, align: 'center' });

      /* The demo badge is a corner plate rather than another centred line: it is a fact about the
       * BUILD, not part of the pitch, and centring it put it in the party's headroom. */
      if (S.g.build === 'demo') {
        A.plate(ctx, A.W - 246, 22, 224, 30, { fill: PAL.bg1 });
        A.text(ctx, 'FREE DEMO — THE FIRST THREE WARDS', A.W - 134, 42,
          { font: F.body(11), colour: PAL.warm, align: 'center', maxW: 210 });
      }
    }

    function drawText(lines, heading) {
      A.text(ctx, heading, A.W / 2, 120, { font: F.display(26), colour: PAL.warm, align: 'center' });
      var y = 190;
      for (var i = 0; i < lines.length; i++) {
        var wrapped = A.wrap(ctx, lines[i], 620, F.body(17));
        for (var j = 0; j < wrapped.length; j++) { A.text(ctx, wrapped[j], A.W / 2, y, { font: F.body(17), colour: PAL.ink, align: 'center' }); y += 26; }
        if (!lines[i]) y += 10;
      }
      A.text(ctx, 'ENTER', A.W / 2, A.H - 60, { font: F.body(14), colour: PAL.inkDim, align: 'center' });
    }

    // ⛔ THIS SCREEN IS NOT CENTRED ON THE CANVAS, AND THAT IS THE FIX RATHER THAN THE BUG.
    //    It draws the horizon strip in the RIGHT column (x 692) and used to centre its prose on
    //    the whole canvas at a 620px wrap — so every line ran from x170 to x790, straight through
    //    the strip. ui_smoke measured 71px of overlap on "Anhold, the third day..." x "NEXT THE
    //    PATIENT WEAVER". Centring on the space that is actually free composes the screen the way
    //    it was always meant to read: what you gave up on the left, what is coming on the right.
    //    `cx` and the wrap width are DERIVED from LAYOUT, so moving the right column moves them.
    function drawDescent() {
      var cx = Math.round((L.cols.right.x - L.gutter) / 2);
      var wrapW = L.cols.right.x - L.gutter - 60;
      /* ⚠️ THE VERTICAL RHYTHM IS SPREAD ON PURPOSE. Composed against the top of the frame this
       * screen ended its last line at y=320 and then showed 160px — nearly a THIRD of the canvas —
       * carrying one word. §10b's dead-space question is a product question, not a capture one:
       * this screen is shown after every rung, so a hole in it is a hole a player sees ten times.
       * The horizon strip on the right runs to y~300, so the prose is spread to finish near it and
       * the chamber floor below becomes framing rather than emptiness. */
      A.text(ctx, 'YOU GO DOWN', cx, 130, { font: F.display(24), colour: PAL.warm, align: 'center' });
      if (S.g.lastSacrifice) {
        var s = S.g.lastSacrifice;
        A.text(ctx, 'YOU SET DOWN  ' + s.power.name, cx, 196, { font: F.display(20), colour: PAL.ink, align: 'center', maxW: wrapW });
        var l2 = A.wrap(ctx, s.power.line, wrapW, F.body(15));
        for (var i = 0; i < l2.length; i++) A.text(ctx, l2[i], cx, 232 + i * 22, { font: F.body(15), colour: PAL.inkDim, align: 'center' });
        if (s.stolen) {
          // ⛔ THE MECHANIC MUST BE SAID. A rule the screen never mentions is not a rule the
          //    player can learn, and M4 is the whole of LAW 2 (wing §6b-12 rule 4).
          var b = S.g.run.ladder[s.stolen.bossIndex];
          A.text(ctx, C.STORY.inheritNote, cx, 312, { font: F.body(13), colour: PAL.inkFaint, align: 'center', maxW: wrapW });
          A.text(ctx, b.name + '  NOW WARDS  ' + s.stolen.type.toUpperCase(),
            cx, 348, { font: F.display(19), colour: A.typeColour(s.stolen.type), align: 'center', maxW: wrapW });
          A.text(ctx, 'two wards below you', cx, 376, { font: F.body(12), colour: PAL.inkFaint, align: 'center' });
        } else {
          A.text(ctx, 'The cairn took it and had no use for it.', cx, 330, { font: F.body(13), colour: PAL.inkFaint, align: 'center' });
        }
      }
      horizonStrip(L.cols.right.x, 96);
      A.text(ctx, 'ENTER', cx, A.H - 60, { font: F.body(14), colour: PAL.inkDim, align: 'center' });
    }

    function drawAftermath() {
      var b = RUN.currentBoss(S.g);
      /* Spread for the same reason as drawDescent above — this screen carried four lines in its top
       * third and nothing below them. */
      A.text(ctx, 'THE WARD BREAKS', A.W / 2, 176, { font: F.display(30), colour: PAL.warm, align: 'center' });
      A.text(ctx, b ? b.name : '', A.W / 2, 222, { font: F.display(22), colour: PAL.ink, align: 'center' });
      A.text(ctx, 'RUNG ' + (S.g.depth) + ' OF ' + S.g.nBosses, A.W / 2, 260, { font: F.num(15), colour: PAL.inkDim, align: 'center' });
      A.text(ctx, C.STORY.sacrificePrompt, A.W / 2, 356, { font: F.display(20), colour: PAL.bad, align: 'center' });
      A.text(ctx, 'ENTER', A.W / 2, A.H - 60, { font: F.body(14), colour: PAL.inkDim, align: 'center' });
    }

    function drawBattle() {
      var g = S.g, f = g.fight, boss = f.boss;
      // ── boss plate + health + wards
      // ⛔ THE FACTION IS A KICKER ABOVE THE PLATE, NOT A LABEL BESIDE THE NAME.
      //    Both used to share the baseline at y45 — name left, faction right — with the name
      //    bounded at `mid.w - 120`. That bound was never enough: "THE RESTLESS DEAD" at 11px is
      //    ~145px, so a long name like THE THING UNDER CAIRNMOUTH ran straight through it (ui_smoke
      //    measured 23px of overlap on WHAT WAITS AT THE STAIR). Bounding the name tighter would
      //    have "fixed" it by truncating the boss's name, which is the headline of the screen —
      //    so the two facts are stacked instead, and the name gets the whole plate width.
      A.text(ctx, boss.faction, L.cols.mid.x + L.cols.mid.w, 18, { font: F.body(11), colour: PAL.inkFaint, align: 'right' });
      A.plate(ctx, L.cols.mid.x, 24, L.cols.mid.w, 30);
      A.text(ctx, boss.name, L.cols.mid.x + 10, 45, { font: F.display(18), colour: PAL.ink, maxW: L.cols.mid.w - 20 });
      A.bar(ctx, L.bossBar.x, L.bossBar.y, L.bossBar.w, L.bossBar.h, f.bossHp / f.bossMaxHp, PAL.bad);
      // Drawn twice: a dark pass then a light one. A number laid straight onto a saturated red
      // bar is unreadable at exactly the moment it matters most, which is what the first look
      // showed.
      A.text(ctx, f.bossHp + ' / ' + f.bossMaxHp, L.bossBar.x + L.bossBar.w - 5, L.bossBar.y + 14,
        { font: F.num(11), colour: 'rgba(0,0,0,0.75)', align: 'right' });
      A.text(ctx, f.bossHp + ' / ' + f.bossMaxHp, L.bossBar.x + L.bossBar.w - 6, L.bossBar.y + 13,
        { font: F.num(11), colour: '#ffffff', align: 'right' });

      // ⛔ THE WARD ROW GROWS RIGHTWARD AND THE BOSS IS DRAWN IN THE MIDDLE OF THIS COLUMN, so
      //    fixed-width chips starting from the left WILL run under the art the moment M4 adds a
      //    third ward — a collision that only appears several rungs into a run, i.e. exactly
      //    where a quick look never goes. Laid out from the RIGHT EDGE and measured, it cannot.
      var wards = R.allWards(boss);
      var wRight = L.cols.mid.x + L.cols.mid.w;
      ctx.font = F.body(10);
      var parts = [];
      for (var i = 0; i < wards.length; i++) {
        var inherited = boss.inherited.indexOf(wards[i]) >= 0;
        parts.push({ t: wards[i].toUpperCase() + (inherited ? ' ↑' : ''), c: A.typeColour(wards[i]), inh: inherited });
      }
      var totalW = 0;
      for (var q = 0; q < parts.length; q++) totalW += ctx.measureText(parts[q].t).width + 14;
      var wx = wRight - totalW;
      A.text(ctx, 'WARDS', wx - 46, 94, { font: F.body(10), colour: PAL.inkFaint });
      for (var m = 0; m < parts.length; m++) {
        var pw = ctx.measureText(parts[m].t).width;
        A.text(ctx, parts[m].t, wx, 94, { font: F.body(10), colour: parts[m].c });
        wx += pw + 14;
      }

      // ── the stage
      drawStage(f, boss);

      // ── the roster and the party's health
      drawRoster();
      A.bar(ctx, L.partyBar.x, L.partyBar.y, L.partyBar.w, L.partyBar.h, f.partyHp / f.partyMaxHp, PAL.good);
      A.text(ctx, f.partyHp + ' / ' + f.partyMaxHp, L.partyBar.x + L.partyBar.w - 6, L.partyBar.y + 12,
        { font: F.num(10), colour: PAL.ink, align: 'right' });
      A.text(ctx, 'ROUND ' + f.round, L.partyBar.x, L.partyBar.y + 30, { font: F.num(12), colour: PAL.inkDim });
      if (f.shield > 0) {
        A.text(ctx, 'SHIELD ' + f.shield, L.partyBar.x + L.partyBar.w, L.partyBar.y + 30,
          { font: F.num(12), colour: PAL.ward, align: 'right' });
      }

      // ⭐ THE TELEGRAPH. It says WHERE, WHEN and HOW SOON, and it is drawn as a threat rather
      //    than as a label — wing §6b-19: a warning that photographs as a UI panel is a threat
      //    nobody moves out of. It appears on the round it lands, so it is always actionable.
      if (f.telegraph) {
        var tw = L.cols.mid.w, tx = L.cols.mid.x, ty = L.stage.y + L.stage.h + 6;
        var puls = 0.55 + 0.45 * Math.sin(S.timeMs / 140);
        ctx.fillStyle = 'rgba(201,69,90,' + (0.16 + 0.22 * puls).toFixed(3) + ')';
        ctx.fillRect(tx, ty, tw, 26);
        ctx.fillStyle = PAL.bad; ctx.fillRect(tx, ty, tw, 2); ctx.fillRect(tx, ty + 24, tw, 2);
        A.text(ctx, 'IT IS WINDING UP  —  THIS BLOW LANDS HEAVY', tx + tw / 2, ty + 18,
          { font: F.display(14), colour: '#ffd9df', align: 'center', maxW: tw - 16 });
      }

      horizonStrip(L.cols.right.x, 24);
      drawSheet(f);
    }

    // ⭐ THE ROSTER. Four companions, each with the powers they still hold shown as coloured
    //    pips. When the last one goes the face goes dark and the row is struck through — the
    //    only place in the game where the premise is a PICTURE rather than a number.
    function drawRoster() {
      var r = L.roster, powers = S.g.run.powers;
      A.text(ctx, 'THE PARTY', r.x, r.y - 8, { font: F.body(11), colour: PAL.inkFaint });
      for (var i = 0; i < C.COMPANIONS.length; i++) {
        var comp = C.COMPANIONS[i];
        var mine = powers.filter(function (p) { return p.who === comp.id; });
        var lost = C.POWERS.filter(function (p) { return p.who === comp.id; }).length - mine.length;
        var alive = mine.length > 0;
        var ry = r.y + i * r.rowH;
        A.plate(ctx, r.x, ry, r.w, r.plateH, { fill: alive ? PAL.stone : PAL.bg1 });
        var bob = alive ? Math.sin((S.timeMs / 620) + i * 1.3) * 1.5 : 0;
        var img = imgFor('wildmark01/' + comp.sprite + '_idle_east_0');
        // Feet on the plate's floor. `sprite()` anchors by the figure's feet, so the head lands
        // at the plate's top edge instead of over the heading above it.
        A.shadow(ctx, r.x + 34, ry + r.plateH - 3, 22);
        if (!A.sprite(ctx, img, r.x + 34, ry + r.plateH - 2 + bob, 1, { alpha: alive ? 1 : 0.20 })) {
          ctx.fillStyle = alive ? PAL.inkDim : PAL.inkFaint;
          ctx.fillRect(r.x + 26, ry + 12, 16, 42);
        }
        A.text(ctx, comp.name, r.x + 70, ry + 20,
          { font: F.display(14), colour: alive ? PAL.ink : PAL.inkFaint, maxW: r.w - 80 });
        if (!alive) {
          // struck through: they are still walking with you, and they have nothing left to give
          ctx.fillStyle = PAL.inkFaint;
          ctx.fillRect(r.x + 70, ry + 15, Math.min(r.w - 80, ctx.measureText(comp.name).width), 1);
          A.text(ctx, 'nothing left to give', r.x + 70, ry + 40, { font: F.body(10), colour: PAL.inkFaint, maxW: r.w - 80 });
        } else {
          for (var j = 0; j < mine.length; j++) {
            ctx.fillStyle = A.typeColour(mine[j].type);
            ctx.fillRect(r.x + 70 + j * 13, ry + 28, 10, 10);
          }
          for (var k = 0; k < lost; k++) {
            ctx.fillStyle = PAL.stoneDark;
            ctx.fillRect(r.x + 70 + (mine.length + k) * 13, ry + 28, 10, 10);
          }
          A.text(ctx, comp.epithet, r.x + 70, ry + 52, { font: F.body(9), colour: PAL.inkFaint, maxW: r.w - 80 });
        }
      }
    }

    // ⭐ THE CHAMBER IS CACHED PER RUNG, NOT REDRAWN PER FRAME.
    //    backdrop.js is deterministic, so the same rung is the same picture every frame — which
    //    means it can be rendered once into an offscreen canvas and blitted. That matters twice:
    //    it keeps ~400 draw calls out of every frame, and it stops the moss and the bone scatter
    //    from crawling, which is what a re-seeded random scatter does and it reads as noise.
    // ⚠️ The offscreen path is OPTIONAL. `ui_smoke` runs in a Node sandbox with no `document`, so
    //    a missing canvas factory falls through to drawing straight onto the real context — the
    //    gate then still exercises every line of the generator rather than skipping it.
    var chamberCache = { key: null, canvas: null };
    function chamber(st, boss) {
      var depth = S.g.run ? S.g.run.index : 0;
      var key = depth + '|' + boss.faction + '|' + S.g.seed;
      if (chamberCache.key === key && chamberCache.canvas) {
        ctx.drawImage(chamberCache.canvas, st.x, st.y);
        return;
      }
      var make = opts.canvasFactory
        || (typeof root.document !== 'undefined' && root.document.createElement
          ? function () { return root.document.createElement('canvas'); } : null);
      var args = [st.x, st.y, st.w, st.h,
        { depth: depth, nDepths: S.g.nBosses, faction: boss.faction, seed: S.g.seed }];
      if (!make) { BD.draw.apply(null, [ctx].concat(args)); return; }
      var off = make();
      off.width = st.w; off.height = st.h;
      var octx = off.getContext('2d');
      BD.draw(octx, 0, 0, st.w, st.h,
        { depth: depth, nDepths: S.g.nBosses, faction: boss.faction, seed: S.g.seed });
      chamberCache = { key: key, canvas: off };
      ctx.drawImage(off, st.x, st.y);
    }

    function drawStage(f, boss) {
      var st = L.stage;
      chamber(st, boss);

      // The floor edge: a soft pool rather than a rectangle with a hard edge, drawn OVER the
      // chamber so the figure's ground plane sits in front of the generated floor.
      var fl = ctx.createLinearGradient(0, st.y + st.h - 46, 0, st.y + st.h);
      fl.addColorStop(0, 'rgba(0,0,0,0)'); fl.addColorStop(1, 'rgba(0,0,0,0.45)');
      ctx.fillStyle = fl; ctx.fillRect(st.x - 20, st.y + st.h - 46, st.w + 40, 46);
      var lip = ctx.createLinearGradient(st.x - 20, 0, st.x + st.w + 20, 0);
      lip.addColorStop(0, 'rgba(61,70,88,0)'); lip.addColorStop(0.5, 'rgba(61,70,88,0.9)'); lip.addColorStop(1, 'rgba(61,70,88,0)');
      ctx.fillStyle = lip; ctx.fillRect(st.x - 20, st.y + st.h - 22, st.w + 40, 1);

      var footY = st.y + st.h - 14;
      // boss, centred on the stage now that the party has its own column, and BIG
      var bx = st.x + st.w / 2;
      var bBob = Math.sin(S.timeMs / 700) * 3;
      A.shadow(ctx, bx, footY + 2, 110);
      var bimg = imgFor((boss.pack || packOf(boss.id)) + '/' + boss.id + '_walk_west_' + (Math.floor(S.timeMs / 260) % 3));
      if (!A.sprite(ctx, bimg, bx, footY + bBob, 4, {})) {
        ctx.fillStyle = PAL.bad; ctx.fillRect(Math.round(bx - 42), Math.round(footY - 170 + bBob), 84, 170);
      }
      // the strike effect, drawn AFTER the figures so it reads as light rather than as a decal
      if (S.anim.fx) {
        var frame = Math.min(5, Math.floor(S.anim.fxT / 60));
        var eff = { fire: 'flame_puff', ice: 'shock_ring', holy: 'crit_star', arcane: 'heat_ring', physical: 'slash_arc' }[S.anim.fx] || 'impact_burst';
        var e = imgFor('emberwrit01/' + eff + '_play_fx_' + frame);
        if (e) A.sprite(ctx, e, bx, footY - 40 + bBob, 3, { alpha: 0.95 });
      }
    }

    function packOf(id) {
      for (var i = 0; i < C.BOSSES.length; i++) if (C.BOSSES[i].id === id) return C.BOSSES[i].pack;
      return 'mourncrest01';
    }
    function imgFor(key) { return loader.has(key) ? loader.get(key) : null; }

    // ⭐ THE HORIZON — the M3 requirement made visible. Without this the sacrifice is a coin
    //    flip, and the 33.5-point informed-play gap is unreachable by a human being.
    function horizonStrip(x, y) {
      var w = L.cols.right.w;
      A.text(ctx, 'WHAT IS BELOW', x, y + 12, { font: F.body(11), colour: PAL.inkFaint });
      var hz = RUN.horizon(S.g);
      for (var i = 0; i < hz.length; i++) {
        var h = hz[i], py = y + 22 + i * 62;
        A.plate(ctx, x, py, w, 56, { fill: i === 0 ? PAL.stone : PAL.bg2 });
        // 'NOW / NEXT / AFTER' rather than 'NOW / −1 / −2'. The minus signs read as negative
        //  numbers attached to the boss, which is the opposite of what they mean.
        A.text(ctx, (i === 0 ? 'NOW  ' : i === 1 ? 'NEXT  ' : 'AFTER  ') + h.name, x + 8, py + 17,
          { font: F.display(13), colour: i === 0 ? PAL.ink : PAL.inkDim, maxW: w - 16 });
        // Wards are laid out by MEASURED width, not on a fixed 52px stride: a fixed stride puts
        // the inherit arrow 40px from the start of a word that may be 20px long, so it floats
        // away from the thing it marks and reads as a separate symbol.
        var cx = x + 8;
        ctx.font = F.body(9);
        for (var j = 0; j < h.wards.length && j < 4; j++) {
          var isInh = h.inherited.indexOf(h.wards[j]) >= 0;
          var lbl = h.wards[j].toUpperCase() + (isInh ? ' ↑' : '');
          A.text(ctx, lbl, cx, py + 34, { font: F.body(9), colour: isInh ? PAL.warm : A.typeColour(h.wards[j]) });
          cx += ctx.measureText(lbl).width + 10;
        }
        if (h.isInheritor) A.text(ctx, 'INHERITS WHAT YOU GIVE UP NOW', x + 8, py + 49,
          { font: F.body(9), colour: PAL.warm, maxW: w - 16 });
        else A.text(ctx, h.hp + ' hp   ' + h.dmg + ' dmg', x + 8, py + 49, { font: F.num(9), colour: PAL.inkFaint });
      }
    }

    // ⭐⭐ THE CHARACTER SHEET — Gate 1's "shrinking, designed, legible artefact". It is the
    //    hero image of this game: a full sheet at the start and a nearly empty one at the end
    //    are the same picture twice, and that pair IS the pitch.
    function drawSheet(f) {
      var s = L.sheet;
      A.plate(ctx, s.x, s.y, s.w, s.h, { fill: PAL.bg2, recess: true });
      var powers = S.g.run.powers;
      var ready = f ? R.readyPowers(f, powers) : powers;
      A.text(ctx, 'WHAT YOU STILL HAVE', s.x + 10, s.y + 18, { font: F.body(11), colour: PAL.inkFaint });
      A.text(ctx, powers.length + ' OF 14', s.x + s.w - 10, s.y + 18, { font: F.num(12), colour: PAL.inkDim, align: 'right' });

      var cw = 126, ch = 56, gap = 6, perRow = 7;
      for (var i = 0; i < powers.length; i++) {
        var p = powers[i];
        var col = i % perRow, row = Math.floor(i / perRow);
        var px = s.x + 10 + col * (cw + gap), py = s.y + 28 + row * (ch + gap);
        var usable = f ? R.isReady(f, p) : true;
        var isCursor = f && ready.length && ready[Math.min(S.cursor, ready.length - 1)] === p;
        A.plate(ctx, px, py, cw, ch, { fill: usable ? PAL.stone : PAL.stoneDark });
        // type stripe: the information channel a player reads before any word
        ctx.fillStyle = A.typeColour(p.type); ctx.globalAlpha = usable ? 1 : 0.35;
        ctx.fillRect(px + 1, py + 1, 3, ch - 2); ctx.globalAlpha = 1;
        // ⚠️ THE CARD USES `short`, NOT `name`. Five of fourteen full names truncated to an
        //    ellipsis here in the first build — measured by looking at the screen. The poetic
        //    full name still appears on the sacrifice screen, where there is room for it and
        //    where it is doing emotional work rather than being a label you scan.
        A.text(ctx, p.short, px + 10, py + 16, { font: F.display(11), colour: usable ? PAL.ink : PAL.inkFaint, maxW: cw - 18 });
        // ⛔ THE KIND LABEL IS BOUNDED, AND THE BOUND IS NOT COSMETIC. It shares a baseline with
        //    the right-aligned preview, whose widest form is "WARDED 123" at 12px monospace = 72px
        //    of the card's 126. Unbounded, this label only clears it because Segoe UI happens to
        //    be narrow — and a browser without Segoe UI falls back to something wider (DejaVu
        //    Sans on most Linux), where "MEMORY" runs into "SHIELD 35". A layout that is correct
        //    only on the font the developer has installed is a layout that is broken for some
        //    fraction of players nobody will ever hear from. ui_smoke's deliberately WIDE text
        //    model is what surfaced it; the fix is the bound, not a narrower model.
        A.text(ctx, p.kind.toUpperCase(), px + 10, py + 30, { font: F.body(9), colour: PAL.inkFaint, maxW: cw - 84 });
        var pv = f ? R.preview(f, p) : null;
        if (pv) {
          var lbl = pv.kind === 'damage' ? (pv.warded ? 'WARDED ' + pv.amount : String(pv.amount))
                  : pv.kind === 'shield' ? 'SHIELD ' + pv.amount : 'MEND ' + pv.amount;
          A.text(ctx, lbl, px + cw - 10, py + 30, { font: F.num(12), align: 'right', maxW: cw - 60,
            colour: pv.kind === 'damage' ? (pv.warded ? PAL.inkFaint : A.typeColour(p.type)) : A.typeColour(p.type) });
        }
        // uses as pips — redundancy in the primary information channel beats tidiness
        var left = f ? R.usesLeft(f, p) : p.uses;
        for (var u = 0; u < Math.min(left, 8); u++) {
          ctx.fillStyle = usable ? A.typeColour(p.type) : PAL.inkFaint;
          ctx.fillRect(px + 10 + u * 7, py + ch - 12, 5, 5);
        }
        if (left === 0) A.text(ctx, 'SPENT', px + 10, py + ch - 7, { font: F.body(9), colour: PAL.inkFaint });
        if (isCursor) { ctx.strokeStyle = PAL.warm; ctx.lineWidth = 2; ctx.strokeRect(px - 1, py - 1, cw + 2, ch + 2); }
        var idx = ready.indexOf(p);
        if (idx >= 0 && idx < 9) A.text(ctx, String(idx + 1), px + cw - 8, py + ch - 6,
          { font: F.num(10), colour: PAL.inkFaint, align: 'right' });
      }
      if (f && !R.canAct(f, powers)) {
        A.text(ctx, 'NOTHING LEFT TO SPEND  —  ENTER to stand there', s.x + s.w / 2, s.y + s.h - 8,
          { font: F.display(13), colour: PAL.bad, align: 'center' });
      }
    }

    function drawSacrifice() {
      A.text(ctx, C.STORY.sacrificePrompt, A.W / 2, 52, { font: F.display(24), colour: PAL.bad, align: 'center' });
      A.text(ctx, C.STORY.inheritNote, A.W / 2, 76, { font: F.body(12), colour: PAL.inkFaint, align: 'center' });
      // ⛔ THE GEOMETRY IS DERIVED FROM THE NUMBER OF CARDS, NOT TYPED. With fourteen options at
      //    five per row the grid is THREE rows deep, and the first build drew the flavour line at
      //    a fixed y=350 — straight through the third row. A text-over-text collision, found by
      //    looking at the screen, which is the only instrument that sees this class (wing §0z).
      var opts2 = RUN.options(S.g);
      var cw = 176, ch = 92, gap = 8, perRow = 5;
      var rows = Math.ceil(opts2.length / perRow);
      var gridTop = 100;
      var gridBottom = gridTop + rows * ch + (rows - 1) * gap;
      var totalW = Math.min(opts2.length, perRow) * (cw + gap) - gap;
      var x0 = Math.round((A.W - totalW) / 2);
      for (var i = 0; i < opts2.length; i++) {
        var o = opts2[i], p = o.power;
        var col = i % perRow, row = Math.floor(i / perRow);
        var px = x0 + col * (cw + gap), py = gridTop + row * (ch + gap);
        var sel = i === Math.min(S.cursor, opts2.length - 1);
        A.plate(ctx, px, py, cw, ch, { fill: sel ? PAL.stoneLit : PAL.stone });
        ctx.fillStyle = A.typeColour(p.type); ctx.fillRect(px + 1, py + 1, 3, ch - 2);
        // display(11), not 12: the longest full name is 22 characters and truncated at 12.
        A.text(ctx, p.name, px + 10, py + 17, { font: F.display(11), colour: PAL.ink, maxW: cw - 18 });
        A.text(ctx, p.kind.toUpperCase() + ' · ' + p.type.toUpperCase(), px + 10, py + 31,
          { font: F.body(9), colour: A.typeColour(p.type), maxW: cw - 18 });
        A.text(ctx, 'power ' + p.mag + '   ×' + p.uses, px + 10, py + 45, { font: F.num(10), colour: PAL.inkDim });
        // ⛔ THE CONSEQUENCE, ON EVERY CARD. This is M3, and it is not flavour: it is the
        //    information the decision is made of.
        if (o.inheritor && !o.already) {
          A.text(ctx, 'GIVES ' + p.type.toUpperCase(), px + 10, py + 64, { font: F.body(10), colour: PAL.warm, maxW: cw - 18 });
          A.text(ctx, 'TO ' + o.inheritor.name, px + 10, py + 78, { font: F.body(10), colour: PAL.warm, maxW: cw - 18 });
        } else {
          A.text(ctx, o.inheritor ? 'it already wards this' : 'nothing below can use it',
            px + 10, py + 71, { font: F.body(10), colour: PAL.inkFaint, maxW: cw - 18 });
        }
        if (sel) { ctx.strokeStyle = PAL.warm; ctx.lineWidth = 2; ctx.strokeRect(px - 1, py - 1, cw + 2, ch + 2); }
      }
      // Everything below is placed RELATIVE TO THE GRID'S MEASURED BOTTOM, so a fourth row of
      // cards can never appear underneath it.
      var sel2 = opts2[Math.min(S.cursor, opts2.length - 1)];
      if (sel2) {
        var lines = A.wrap(ctx, sel2.power.line, 700, F.body(14));
        for (var j = 0; j < lines.length; j++)
          A.text(ctx, lines[j], A.W / 2, gridBottom + 28 + j * 22, { font: F.body(14), colour: PAL.inkDim, align: 'center' });
      }
      A.text(ctx, '← →  choose      ENTER  give it up', A.W / 2, Math.min(A.H - 30, gridBottom + 86),
        { font: F.body(14), colour: PAL.ink, align: 'center' });
    }

    // ─── THE HARNESS SURFACE ──────────────────────────────────────────────────────────
    var api = {
      // Two callers, ONE implementation. `tickMs` is what requestAnimationFrame drives with a
      // real delta; `tick(n)` is what a harness in a background tab steps deliberately. Neither
      // is a special path — they are the same function with a different clock.
      tickMs: function (dt) { return tick(dt); },
      tick: function (n) { var f = 0; for (var i = 0; i < (n || 1); i++) f = tick(16); return f; },
      key: key,
      state: function () { return RUN.snapshot(S.g); },
      frames: function () { return S.frames; },
      scene: function () { return S.g.scene; },
      FLOAT_CAP: FLOAT_CAP,
      STORE_KEYS: STORE_KEYS.slice(),
      ready: function () { return S.ready; },
      loadError: function () { return S.loadError; },
      storeKeys: STORE_KEYS,
      _internal: S
    };
    return api;
  }

  return { create: create, STORE_KEYS: STORE_KEYS };
});
