/*
 * REVERSE RPG (The Long Defeat) — rules.js
 * THE SHIPPED RULE MODULE. wing-games, 2026-09-05.
 *
 * ⛔ THIS FILE IS THE ONE FACTORY FOR THE OBJECT UNDER TEST (wing §6b-6 rule 2).
 *    The canvas game imports it. Every balance gate imports it. There is no second copy of
 *    any rule anywhere, so a "the shipped rules drifted from the model" failure — which
 *    DESIGN.md §7 item 4 names as the failure mode this design dies of — is UNREACHABLE
 *    rather than merely detected.
 *
 * ⛔ DUAL-MODE by construction (wing §6b-5 rule 1): a bare `require` at the top of a file a
 *    <script> tag also loads is a fatal ReferenceError whose only symptom is a blank canvas.
 * ⛔ IIFE-WRAPPED (wing §6b-5 rule 2): plain <script> tags share ONE global scope and every
 *    top-level `const` collides with an identically-named one in a sibling file, aborting the
 *    WHOLE file. Renaming is whack-a-mole; the wrapper fixes the class.
 */
(function (root, factory) {
  'use strict';
  var mod = factory();
  if (typeof module === 'object' && module && module.exports) module.exports = mod;
  else root.RR_RULES = mod;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  // ─── TAXONOMY ───────────────────────────────────────────────────────────────────────
  // Five offensive types and two defensive ones, exactly as the candidate model measured.
  // The MATCH between a power's type and a boss's wards is where informed play lives
  // (candidate TEST 4: the gap collapses only when powers are interchangeable), so the type
  // system is load-bearing and not decoration.
  var OFF_TYPES = ['fire', 'ice', 'holy', 'physical', 'arcane'];
  var DEF_TYPES = ['ward', 'heal'];

  // ─── TUNABLES ───────────────────────────────────────────────────────────────────────
  // ⚠️ Every one of these is CALIBRATED by proto/calibrate.js, never typed from taste, and
  // the calibration chooses on a CONTROL arm rather than on the treatment's contrast
  // (DESIGN.md §0 — choosing a range from the treatment would be fitting an answer).
  var K = {
    HP_MAX: 260,          // the party's shared health pool. Does not grow: you never get stronger.
    HP_BASE: 210,         // boss 0 health
    HP_RAMP: 0.15,        // boss hp scales (1 + i*HP_RAMP)
    DMG_BASE: 12,         // boss 0 damage per ordinary blow
    DMG_RAMP: 0.15,       // boss damage scales (1 + i*DMG_RAMP)
    DMG_SCALE: 3.0,       // an offensive power's magnitude -> damage
    RESIST_MULT: 0.20,    // GRADED, never zero: a step function admits no difficulty curve
    WARD_SCALE: 1.6,      // a ward's magnitude -> absorbing shield
    HEAL_SCALE: 2.2,      // a heal's magnitude -> health restored
    HEAVY_MULT: 2.6,      // the telegraphed blow
    ROUND_CAP: 60,        // a fight that reaches this is a TIMEOUT, a third outcome, never a loss
    M4_HORIZON: 2,        // the boss that inherits a sacrifice sits this many bosses ahead
    USE_GRANT: 5          // every N sacrifices, every surviving power gains one use. 0 = off.
  };
  // ⭐ USE_GRANT — "WHAT YOU SET DOWN, THE REST OF YOU TAKES UP" — AND WHY IT IS THE ONLY
  //    HONEST KNOB FOR THIS PROBLEM. MEASURED before it was written: across 36 reconnaissance
  //    cells spanning both ramps, the expert FINISHED the ten-boss ladder in 0% of runs in 34
  //    of them, because after nine sacrifices the player holds five powers against a boss with
  //    1.9x the health of the first. That is arithmetic, not difficulty: no setting of HP_BASE,
  //    DMG_BASE or either ramp can make the last two rungs reachable while the middle stays a
  //    game, so tuning them further would have produced "unwinnable everywhere" and read as a
  //    finding about the DESIGN (wing §6b-12 rule 1's shape, arrived at honestly and then
  //    diagnosed instead of believed).
  //    ⛔⛔ RETRACTION, IN PLACE. This comment first read: "it is deliberately
  //    information-free, so it moves DIFFICULTY without moving the LAW 2 gap". That was
  //    written BEFORE the run that tested it, and the run FALSIFIED it. MEASURED at
  //    210/0.10/10/0.20, n=30, sweeping the grant alone:
  //        grant 0 -> expert  80.0%  heuristic 63.0%  gap 17.0   finishes   0%
  //        grant 2 -> expert 100.0%  heuristic 100.0% gap  0.0   finishes 100%
  //        grant 3 -> expert 100.0%  heuristic 100.0% gap  0.0   finishes 100%
  //        grant 6 -> expert 100.0%  heuristic  87.3% gap 12.7   finishes 100%
  //    ⇒ the grant is a POWERFUL difficulty knob, and at these other constants any value that
  //    makes the ladder finishable also makes it trivial. The gap readings of 0.0 are NOT
  //    evidence that the grant destroys depth — the expert is pinned at the 100% ceiling, and
  //    a metric at a ceiling detects nothing (wing §6b-15's connectivity rule). They are
  //    evidence that the cell is saturated, which is precisely what acceptance bar A2 in
  //    calibrate.js exists to refuse.
  //    ⇒ THE OPERATIONAL RULE: USE_GRANT MUST BE CO-TUNED WITH THE BOSS CONSTANTS, never set
  //    alone. A higher grant demands tougher bosses to pay for it. That is why calibrate.js
  //    sweeps all five axes jointly instead of fixing four and sliding one.
  //    ⚠️ Whether the grant is information-free in the sense that matters — does it change what
  //    the player must KNOW — is still UNMEASURED and must be read off an UNSATURATED cell.
  //    ⚠️ It does NOT undo the decline: total throughput still falls, just less steeply, and
  //    it reads on screen as the surviving powers being spent over and over — which is the
  //    death spiral made legible rather than described.
  // ⛔ HP AND DAMAGE RAMP SEPARATELY, AND THAT IS A MEASURED DECISION, NOT A CONVENIENCE.
  //    With ONE ramp the two curves are welded together, and the arithmetic then demands that
  //    a player whose action budget has fallen ~4.6x still out-damage a boss with ~5x the
  //    health — which no constant can satisfy, so the search returns "unwinnable everywhere"
  //    and reads as a structural finding about the DESIGN when it is a finding about the
  //    parameterisation (wing §6b-13). Split, the squeeze can come from the side that actually
  //    dramatises the premise: later bosses hit terrifyingly hard rather than being sponges.

  // ─── DETERMINISTIC PRNG ─────────────────────────────────────────────────────────────
  // Every figure this project quotes must be reproducible from a seed, or it is not a figure.
  function rng(seed) {
    var s = seed >>> 0;
    return function () { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
  }
  function pick(r, arr) { return arr[Math.floor(r() * arr.length)]; }

  // ─── THE BOSS LADDER ────────────────────────────────────────────────────────────────
  // Boss IDENTITY is authored (name, faction, art, telegraph rhythm, the lines it speaks).
  // Boss WARDS are drawn per run, and that is a deliberate design decision recorded in
  // DESIGN.md §4a: a fixed ladder has one solved sacrifice sequence, so the decision the game
  // is named after would be solved once and shared. Drawing the wards per run makes every run
  // a different puzzle over the same dramatic arc — and it is also what the candidate model
  // measured, so the numbers transfer instead of being re-derived on a different game.
  //
  // ⚠️ It only works because the player can SEE what is coming: DESIGN.md's M3 survives as a
  // UI REQUIREMENT (the next two bosses' wards are always on screen). A hidden ward would make
  // the sacrifice a coin flip rather than a decision.
  function makeLadder(seed, roster, n) {
    /* ⛔⛔ REFUSE A ROSTER SHORTER THAN THE LADDER, RATHER THAN WRAPPING IT.
     * The `i % roster.length` below is a silent fallback, and wing §6b-9 rule 1 is explicit that
     * the fallback branch of a guard encodes a design decision nobody made. Since content_full.js
     * was split out (the paid rungs are a FILE the free build does not have), a paid build that
     * shipped without it would ask for ten rungs from a roster of three and quietly sell a game
     * that fights THE FIRST RUNG three times over — no error, no crash, a plausible wrong game.
     * That is exactly the shape wing §6d-4 calls unrecoverable, facing the other way.
     * ⚠️ Nothing in this project has ever relied on the wrap: the demo asks for 3 from 3 and the
     * paid build asks for 10 from 10, so this refusal changes no shipped behaviour. It exists so
     * that a packaging mistake is LOUD on the first fight instead of invisible forever. */
    if (!roster || roster.length < n) {
      throw new Error('makeLadder: asked for ' + n + ' rungs from a roster of '
        + (roster ? roster.length : 0) + '. The paid content (content_full.js) is missing from this '
        + 'build — refusing to repeat bosses to fill the ladder.');
    }
    var r = rng(seed);
    var out = [];
    for (var i = 0; i < n; i++) {
      var spec = roster[i % roster.length];
      var wards = [pick(r, OFF_TYPES), pick(r, OFF_TYPES)];
      var hpScale = 1 + i * K.HP_RAMP, dmgScale = 1 + i * K.DMG_RAMP;
      out.push({
        i: i,
        id: spec.id,
        name: spec.name,
        faction: spec.faction,
        title: spec.title,
        line: spec.line,
        heavyEvery: spec.heavyEvery,
        wards: uniq(wards),
        inherited: [],                 // wards taken from the player by M4, kept separate so the UI can say WHY
        hp: Math.round(K.HP_BASE * hpScale),
        maxHp: Math.round(K.HP_BASE * hpScale),
        dmg: Math.round(K.DMG_BASE * dmgScale)
      });
    }
    return out;
  }
  function uniq(a) { var s = {}, o = []; for (var i = 0; i < a.length; i++) if (!s[a[i]]) { s[a[i]] = 1; o.push(a[i]); } return o; }

  function allWards(boss) { return uniq(boss.wards.concat(boss.inherited)); }
  function resists(boss, type) { return allWards(boss).indexOf(type) >= 0; }

  // ─── M4 — THE BOSS KEEPS WHAT YOU SACRIFICE ─────────────────────────────────────────
  // Give up a power and the boss two ahead is warded against its TYPE.
  //
  // ⭐ This is the mechanic LAW 2 is met by, and it is load-bearing. MEASURED at candidate
  // stage (n=300/arm): it widened the informed-vs-heuristic gap 6.2 -> 9.4 points, and the
  // SHAPE of the move is why it is the right one — informed play moved -0.1 (flat, inside its
  // own CI) while the "drop your weakest" heuristic fell -3.4. It widens by REMOVING AN
  // AUTOPILOT, not by making the game harder.
  //
  // ⚠️ Chosen deliberately over "the boss gains the sacrificed power's magnitude", which would
  // re-reward dropping your weakest and reinforce the very heuristic LAW 2 exists to break.
  function applyM4(ladder, i, power) {
    var t = i + K.M4_HORIZON;
    if (t >= ladder.length) return null;
    if (OFF_TYPES.indexOf(power.type) < 0) return null;      // only an offensive type can be worn as a ward
    if (resists(ladder[t], power.type)) return null;         // already warded; nothing to inherit
    ladder[t].inherited = ladder[t].inherited.concat([power.type]);
    return { bossIndex: t, type: power.type };
  }

  // ─── A FIGHT ────────────────────────────────────────────────────────────────────────
  // Turn based. Each round the player SPENDS one power, then the boss acts. A power carries a
  // number of USES PER FIGHT, not a cooldown.
  //
  // ⛔⛔ THIS IS THE LOAD-BEARING RULE AND IT REPLACED COOLDOWNS AFTER A MEASUREMENT.
  //    Built with cooldowns first, the expert reached depth EXACTLY 6 in 60 of 60 seeds and so
  //    did the "drop your weakest" heuristic — identical to the decimal, zero variance, the
  //    whole sacrifice decision worth 0.0 points. The cause was arithmetic: under cooldowns
  //    only the BEST AVAILABLE power fires in a round, so losing one major of five changed
  //    throughput by nothing at all, and the premise — you get weaker as you give things up —
  //    was simply not implemented until the moment it became instantly fatal. Offset step
  //    functions, exactly the shape wing §6b-13 item 9 records.
  //    With per-fight USES, the arsenal IS the action budget: total damage available in a
  //    fight is the sum over what you still hold, which is the candidate model's `off` term,
  //    so the measured balance evidence transfers instead of describing a different game.
  //    It is also the better GAME: when the uses run out you stand there and are hit, which is
  //    the death spiral made diegetic rather than described.
  // ⛔ `sacrificedCount` HAS NO DEFAULT AND newFight THROWS WITHOUT IT. Two call sites want
  //    different values (the game passes the run's real count; a single-fight probe passes 0),
  //    which is exactly when a default is most tempting and most dangerous — wing §6b-29c
  //    records a mechanic silently inert underneath a comment saying it was fixed, because a
  //    parameter was added with a default of 0 and the one call site that needed a real value
  //    passed nothing.
  function grantFor(sacrificedCount) {
    return K.USE_GRANT > 0 ? Math.floor(sacrificedCount / K.USE_GRANT) : 0;
  }
  function newFight(powers, boss, sacrificedCount) {
    if (typeof sacrificedCount !== 'number' || !isFinite(sacrificedCount) || sacrificedCount < 0) {
      throw new Error('newFight: sacrificedCount is required and must be a non-negative number (got ' + sacrificedCount + ')');
    }
    var grant = grantFor(sacrificedCount);
    var uses = {};
    for (var i = 0; i < powers.length; i++) uses[powers[i].id] = powers[i].uses + grant;
    return {
      grant: grant,
      boss: boss,
      bossHp: boss.hp,
      bossMaxHp: boss.maxHp,
      partyHp: K.HP_MAX,
      partyMaxHp: K.HP_MAX,
      shield: 0,
      round: 1,
      uses: uses,         // remaining uses THIS FIGHT, keyed by power id
      // ⚠️ `telegraph` means: THE BLOW THAT LANDS AT THE END OF THIS ROUND IS HEAVY. The
      // player therefore gets exactly one action of notice, which is the decision — spend it
      // on a ward, or push damage and eat it. wing §6b-19: a warning must be legible AS a
      // warning, so this is first-class fight state the UI reads, never a log line nobody
      // renders. It is deliberately NOT "heavy next round": a notice you cannot act on in
      // the same breath is scenery.
      telegraph: boss.heavyEvery > 0 && 1 % boss.heavyEvery === 0,
      outcome: 'ongoing',
      events: [],
      log: []
    };
  }

  function isReady(fight, power) { return (fight.uses[power.id] || 0) > 0; }
  function usesLeft(fight, power) { return fight.uses[power.id] || 0; }
  function readyPowers(fight, powers) {
    var out = [];
    for (var i = 0; i < powers.length; i++) if (isReady(fight, powers[i])) out.push(powers[i]);
    return out;
  }

  // What a power would DO right now, given the boss in front of you. The UI prints this and
  // every bot reads the same function, so a bot can never be judging a different game.
  function preview(fight, power) {
    if (OFF_TYPES.indexOf(power.type) >= 0) {
      var warded = resists(fight.boss, power.type);
      return { kind: 'damage', amount: Math.round(power.mag * K.DMG_SCALE * (warded ? K.RESIST_MULT : 1)), warded: warded };
    }
    if (power.type === 'ward') return { kind: 'shield', amount: Math.round(power.mag * K.WARD_SCALE), warded: false };
    return { kind: 'heal', amount: Math.round(power.mag * K.HEAL_SCALE), warded: false };
  }

  function heavyThisRound(fight) {
    return fight.boss.heavyEvery > 0 && fight.round % fight.boss.heavyEvery === 0;
  }
  function heavyNextRound(fight) {
    return fight.boss.heavyEvery > 0 && (fight.round + 1) % fight.boss.heavyEvery === 0;
  }

  // Resolve one full round: the player's channel, then the boss's answer.
  // Returns the list of events so the renderer and the harness see the same story.
  function act(fight, powers, powerId) {
    if (fight.outcome !== 'ongoing') return { ok: false, reason: 'fight-over' };
    var power = null;
    for (var i = 0; i < powers.length; i++) if (powers[i].id === powerId) power = powers[i];
    // ⚠️ Every refusal names its reason (wing §0z): a bare null makes a hostile input, a
    // version skew and a defect in this function indistinguishable.
    if (!power) return { ok: false, reason: 'no-such-power' };
    if (!isReady(fight, power)) return { ok: false, reason: 'spent' };

    var ev = [];
    var pv = preview(fight, power);
    if (pv.kind === 'damage') {
      fight.bossHp = Math.max(0, fight.bossHp - pv.amount);
      ev.push({ t: 'player-damage', power: power.id, amount: pv.amount, warded: pv.warded });
    } else if (pv.kind === 'shield') {
      fight.shield = fight.shield + pv.amount;
      ev.push({ t: 'player-shield', power: power.id, amount: pv.amount });
    } else {
      var before = fight.partyHp;
      fight.partyHp = Math.min(fight.partyMaxHp, fight.partyHp + pv.amount);
      ev.push({ t: 'player-heal', power: power.id, amount: fight.partyHp - before });
    }
    fight.uses[power.id] = fight.uses[power.id] - 1;

    if (fight.bossHp <= 0) {
      fight.outcome = 'win';
      fight.events = ev;
      return { ok: true, events: ev, outcome: 'win' };
    }

    return bossTurn(fight, ev);
  }

  // ⛔ "I HAVE NOTHING LEFT TO SPEND" IS A FIRST-CLASS ACTION, NOT A HARNESS WORKAROUND.
  //    It is the state the whole game is pointed at — you stand in front of the thing with an
  //    empty arsenal and it hits you — so the model must be able to express it, the UI must be
  //    able to draw it, and a bot must reach it by the same code path a player does. The first
  //    version of the harness faked this by appending a zero-magnitude power, which is a test
  //    double standing in for a shipped state (wing §6b-18: the harness must drive the shipped
  //    product, not a stunt version of it).
  function canAct(fight, powers) { return readyPowers(fight, powers).length > 0; }
  function pass(fight, powers) {
    if (fight.outcome !== 'ongoing') return { ok: false, reason: 'fight-over' };
    if (canAct(fight, powers)) return { ok: false, reason: 'you-still-have-something-to-spend' };
    return bossTurn(fight, [{ t: 'player-empty' }]);
  }

  function bossTurn(fight, ev) {
    var heavy = heavyThisRound(fight);
    var raw = Math.round(fight.boss.dmg * (heavy ? K.HEAVY_MULT : 1));
    var absorbed = Math.min(fight.shield, raw);
    fight.shield -= absorbed;
    var through = raw - absorbed;
    fight.partyHp = Math.max(0, fight.partyHp - through);
    ev.push({ t: 'boss-attack', raw: raw, absorbed: absorbed, through: through, heavy: heavy });

    if (fight.partyHp <= 0) { fight.outcome = 'loss'; fight.events = ev; return { ok: true, events: ev, outcome: 'loss' }; }

    fight.round += 1;
    fight.telegraph = heavyThisRound(fight);   // see newFight: "the blow at the END of THIS round"
    // ⛔ TIMEOUT IS A REAL THIRD OUTCOME, NOT A LOSS. Master §2b records a harness exposing
    // `won` and `lost = !won` certifying an INVULNERABLE boss as a difficulty result. Anything
    // that judges this game must count the outcome it is claiming, never its complement.
    if (fight.round > K.ROUND_CAP) { fight.outcome = 'timeout'; fight.events = ev; return { ok: true, events: ev, outcome: 'timeout' }; }

    fight.events = ev;
    return { ok: true, events: ev, outcome: 'ongoing' };
  }

  // ─── A RUN ──────────────────────────────────────────────────────────────────────────
  // beat a boss -> sacrifice a power -> the boss two ahead inherits its type -> repeat.
  // `depth` is how many bosses you beat, and it is the only score this game keeps.
  function newRun(seed, roster, powers, nBosses) {
    return {
      seed: seed,
      ladder: makeLadder(seed, roster, nBosses),
      powers: powers.slice(),
      index: 0,
      depth: 0,
      sacrificed: [],       // {bossIndex, powerId, inheritedBy}
      over: false,
      ending: null
    };
  }

  // The sacrifice. Returns what the world did with it, so the UI can SAY it — a mechanic the
  // screen never mentions is not a mechanic (wing §6b-12 rule 4).
  function sacrifice(run, powerId) {
    var idx = -1;
    for (var i = 0; i < run.powers.length; i++) if (run.powers[i].id === powerId) idx = i;
    if (idx < 0) return { ok: false, reason: 'no-such-power' };
    var power = run.powers[idx];
    var stolen = applyM4(run.ladder, run.index, power);
    run.powers = run.powers.slice(0, idx).concat(run.powers.slice(idx + 1));
    run.sacrificed.push({ bossIndex: run.index, powerId: powerId, type: power.type, inheritedBy: stolen ? stolen.bossIndex : null });
    run.index += 1;
    if (run.index >= run.ladder.length) { run.over = true; run.ending = 'finished'; }
    return { ok: true, power: power, stolen: stolen };
  }

  // What the sacrifice screen must show for each option, so the player can make the decision
  // the game is about. DESIGN.md M3: revealing the consequence is a UI REQUIREMENT.
  function sacrificeConsequence(run, powerId) {
    var power = null;
    for (var i = 0; i < run.powers.length; i++) if (run.powers[i].id === powerId) power = run.powers[i];
    if (!power) return null;
    var t = run.index + K.M4_HORIZON;
    if (t >= run.ladder.length) return { power: power, boss: null, already: false };
    var b = run.ladder[t];
    return { power: power, boss: b, already: OFF_TYPES.indexOf(power.type) < 0 || resists(b, power.type) };
  }

  return {
    OFF_TYPES: OFF_TYPES, DEF_TYPES: DEF_TYPES, K: K,
    rng: rng, pick: pick, uniq: uniq,
    makeLadder: makeLadder, allWards: allWards, resists: resists, applyM4: applyM4,
    newFight: newFight, grantFor: grantFor, isReady: isReady, usesLeft: usesLeft, readyPowers: readyPowers, preview: preview,
    heavyThisRound: heavyThisRound, heavyNextRound: heavyNextRound,
    act: act, pass: pass, canAct: canAct,
    newRun: newRun, sacrifice: sacrifice, sacrificeConsequence: sacrificeConsequence
  };
});
