/*
 * REVERSE RPG (The Long Defeat) — content.js
 * THE AUTHORED CONTENT: four companions, fourteen powers, ten bosses, the story beats.
 *
 * ⚠️ Every sprite id below was READ OFF THE PACK'S OWN pack.json on 2026-09-05, never
 * remembered (§0-ART-d item 4: a game and an asset pack agree on cell size, projection and
 * body height or the pack cannot be used). Measured inventory:
 *   Wildmark01_TheParty      cell 128, variants [128,64], chars: elf warrior mage rogue
 *   Mourncrest01_RestlessDead cell 64,  variants [64,128], chars: skeleton wraith ghoul wight gravebound boneHound
 *   Mourncrest02_PaleChoir    cell 64,  variants [64,128], chars: cultist acolyte censer-bearer hierophant thrall
 *   Mourncrest03_BarrowBeasts cell 64,  variants [64,128], chars: direBat carrionCrow tombSpider ossuaryOoze barrowWyrm
 *   Mourncrest04_IronWardens  cell 64,  variants [64,128], chars: knight templar inquisitor
 *   Emberwrit01               64 and 128, 10 effects x 6 frames
 * ⛔ boneHound is drawn in SIDE VIEW in all four rows (the pack's own boneHoundViewNote) —
 *    it is the one character whose row semantics differ, so it must not be picked by row.
 */
(function (root, factory) {
  'use strict';
  var mod = factory(root);
  if (typeof module === 'object' && module && module.exports) module.exports = mod;
  else root.RR_CONTENT = mod;
})(typeof self !== 'undefined' ? self : this, function (root) {
  'use strict';

  // ─── THE COMPANIONS ─────────────────────────────────────────────────────────────────
  // ⛔ THE GROUPING IS PURELY PRESENTATIONAL AND MUST STAY THAT WAY. A companion confers NO
  //    mechanical bonus for still being in the party. This is a design LAW, not an omission:
  //    LAW 2 exists because "drop your weakest" was half the decision, and any rule of the
  //    form "keep a companion alive" is a second information-free heuristic — exactly the
  //    shape M1 and M2 were MEASURED to fail on (they changed present-state value without
  //    changing what the player must KNOW, and the simple policy exploited them harder).
  //    What the grouping buys is that losing your last Ivor power puts a face in the portrait
  //    row out, which is the thing a player tells someone about.
  var COMPANIONS = [
    { id: 'kesh', name: 'KESH',  sprite: 'warrior', epithet: 'the shield of Anhold' },
    { id: 'ivor', name: 'IVOR',  sprite: 'mage',    epithet: 'who reads the unmaking' },
    { id: 'sela', name: 'SELA',  sprite: 'elf',     epithet: 'of the green water' },
    { id: 'wren', name: 'WREN',  sprite: 'rogue',   epithet: 'who came back once already' }
  ];

  // ─── THE FOURTEEN ───────────────────────────────────────────────────────────────────
  // KIND maps onto the premise's own words — you sacrifice "a skill, a weapon or a memory":
  //   weapon = physical, fire   (things you carry)
  //   skill  = arcane, ice, holy (things you learned)
  //   memory = ward, heal        (things you ARE; protection and mending come from who you were)
  // MAGNITUDES sit inside the ranges the candidate model measured — majors 18-27, minors 7-12
  // — so the balance evidence transfers rather than describing a different game.
  var POWERS = [
    // KESH — the wall
    { id: 'greatsword', short: "GREATSWORD", name: 'GREATSWORD OATH',        who: 'kesh', kind: 'weapon', type: 'physical', mag: 24, uses: 1, line: 'The oath she swore at the muster, with the blade across her palms.' },
    { id: 'riposte', short: "RIPOSTE",    name: 'RIPOSTE',                who: 'kesh', kind: 'weapon', type: 'physical', mag: 10, uses: 3, line: 'A small mean answer, learned from a sergeant who is dead.' },
    { id: 'shieldwall', short: "SHIELD WALL", name: 'THE SHIELD WALL',        who: 'kesh', kind: 'memory', type: 'ward',     mag: 22, uses: 2, line: 'Anhold, the third day. Nobody moved. She has not stopped standing there since.' },
    // IVOR — the fire and the unmaking
    { id: 'emberbrand', short: "EMBERBRAND", name: 'EMBERBRAND',             who: 'ivor', kind: 'weapon', type: 'fire',     mag: 23, uses: 1, line: 'He set it alight the year he was accepted and has never let it out.' },
    { id: 'cinderstep', short: "CINDERSTEP", name: 'CINDERSTEP',             who: 'ivor', kind: 'weapon', type: 'fire',     mag: 9,  uses: 3, line: 'Enough flame to cross a room in a hurry.' },
    { id: 'unmaking', short: "THE UNMAKING",   name: 'THE UNMAKING',           who: 'ivor', kind: 'skill',  type: 'arcane',   mag: 25, uses: 1, line: 'Nine words. He is the last person alive who has all nine in order.' },
    { id: 'sigilsnap', short: "SIGIL SNAP",  name: 'SIGIL SNAP',             who: 'ivor', kind: 'skill',  type: 'arcane',   mag: 11, uses: 3, line: 'A cantrip for breaking other people’s work.' },
    // SELA — cold and green
    { id: 'killfrost', short: "KILLING FROST",  name: 'KILLING FROST',          who: 'sela', kind: 'skill',  type: 'ice',      mag: 22, uses: 1, line: 'The winter that took her village, kept and pointed.' },
    { id: 'rimewalk', short: "RIMEWALK",   name: 'RIMEWALK',               who: 'sela', kind: 'skill',  type: 'ice',      mag: 9,  uses: 3, line: 'Frost thin enough to walk on. Briefly.' },
    { id: 'greenmend', short: "MOTHER'S SONG",  name: 'HER MOTHER’S SONG', who: 'sela', kind: 'memory', type: 'heal',     mag: 21, uses: 2, line: 'Six lines. She does not know what the fourth one means and sings it anyway.' },
    // WREN — the one who has done this before
    { id: 'judgement', short: "JUDGEMENT",  name: 'JUDGEMENT',              who: 'wren', kind: 'skill',  type: 'holy',     mag: 24, uses: 1, line: 'Not hers. She took it off someone at the bottom of this stair.' },
    { id: 'ashenrite', short: "ASHEN RITE",  name: 'ASHEN RITE',             who: 'wren', kind: 'skill',  type: 'holy',     mag: 10, uses: 3, line: 'Four words and a handful of grave dirt.' },
    { id: 'cairnroad', short: "THE WAY OUT",  name: 'THE CAIRNMOUTH ROAD', who: 'wren', kind: 'memory', type: 'ward',     mag: 8,  uses: 3, line: 'She remembers the way out. That is the whole of it, and it is worth a great deal.' },
    { id: 'draught', short: "FIELD DRAUGHT",    name: 'A FIELD DRAUGHT',        who: 'wren', kind: 'memory', type: 'heal',     mag: 9,  uses: 3, line: 'Her father’s recipe. Bitter. Works.' }
  ];

  // ─── THE LADDER ─────────────────────────────────────────────────────────────────────
  // Boss IDENTITY is authored; boss WARDS are drawn per run (rules.js makeLadder, and the
  // reason is recorded there). heavyEvery is the telegraph rhythm and is the fight's pulse.
  //
  // ⛔ ONLY THE THREE DEMO RUNGS LIVE HERE. Rungs four to ten are in content_full.js, which the
  //    free page does not load — see that file's header for why a runtime flag was not enough
  //    (it can withhold a branch; it cannot withhold DATA, so the free build was shipping every
  //    boss's name and the winning ending as readable source).
  var BOSSES = [
    { id: 'skeleton',      pack: 'mourncrest01', faction: 'THE RESTLESS DEAD', name: 'THE FIRST RUNG',            title: 'a sentry who forgot the war ended', heavyEvery: 4, line: 'It has been standing here so long the stone has taken the shape of its feet.' },
    { id: 'boneHound',     pack: 'mourncrest01', faction: 'THE RESTLESS DEAD', name: 'WHAT WAITS AT THE STAIR',   title: 'the kennel of the long barrow',     heavyEvery: 3, line: 'Something below is very pleased to hear you coming.' },
    { id: 'ghoul',         pack: 'mourncrest01', faction: 'THE RESTLESS DEAD', name: 'THE GLUTTON OF ANHOLD',     title: 'it ate the garrison',               heavyEvery: 4, line: 'Kesh knows this one. Kesh does not say how.' }
  ];

  // ⭐ THE MERGE. content_full.js is loaded BEFORE this file (build_web.js owns that order and
  //    asserts it). Under Node it is required directly, because every suite in this project
  //    measures the FULL game and a harness silently judging a three-boss ladder would be the
  //    green lie this split is supposed to prevent.
  //    ⚠️ In the browser its ABSENCE is legitimate and is what makes the free build the free
  //    build — so this is a real fork, not a fallback that hides a missing file. What makes the
  //    missing-file case loud is rules.js makeLadder, which REFUSES a roster shorter than the
  //    ladder it is asked for instead of repeating bosses modulo.
  var FULL = null;
  if (typeof module === 'object' && module && module.exports) FULL = require('./content_full.js');
  else if (root && root.RR_CONTENT_FULL) FULL = root.RR_CONTENT_FULL;
  if (FULL) BOSSES = BOSSES.concat(FULL.BOSSES);

  // ─── SHAPE OF THE PRODUCT ───────────────────────────────────────────────────────────
  // ⚠️ AMENDS DESIGN.md §6, WITH THE REASON. The design doc said "slice = 4 bosses"; the
  // build ships TEN, because every measured figure in that document — the 12.2-point dominance
  // gap, the 9.4-point M4 gap, the calibrated ramp — was taken at NBOSS = 10. Shipping four
  // would retire the entire balance evidence base and require re-deriving it on a different
  // game (§6b-30b: a constraint measured on one fixture is a claim about that fixture). Ten
  // bosses cost AUTHORING, not engineering: a boss here is a stat block, a sprite, a telegraph
  // rhythm and two lines.
  var SHAPE = {
    nBosses: 10,
    demoBosses: 3,   // the free web demo ends after the THIRD fight, i.e. after the SECOND
                     // sacrifice — DESIGN.md §6: the demo must end where the buying decision
                     // is honestly made, and the second sacrifice is the first time M4's
                     // consequence has actually landed on a boss you then have to fight.
    price: 14.99
  };

  var STORY = {
    title: 'THE LONG DEFEAT',
    subtitle: 'a reverse RPG',
    opening: [
      'You go down the cairn at full strength. Everyone does.',
      'The stair only opens for someone who has something to set down.',
      'Every ward you break, the cairn takes a piece of you in payment —',
      'and gives it to whatever is waiting two floors below.'
    ],
    // The one sentence that is the ninety-second test (§3): a player repeats THIS.
    hook: 'You start at level 99 and the game takes it away. Every boss you beat, you choose what to lose.',
    sacrificePrompt: 'THE CAIRN TAKES ONE. CHOOSE.',
    inheritNote: 'What you set down does not stay set down.',
    demoEnd: [
      'The stair keeps going.',
      'Seven more wards, and you have eleven things left to pay with.',
      '',
      'The full descent — ten bosses, one ending, and the arithmetic of',
      'getting to the bottom with almost nothing — is the paid build.'
    ],
    // ⛔ PAID. Supplied by content_full.js and absent from the free build by design — the demo
    //    cannot reach the `ending` scene at all (scene_reach.js proves that by PLAYING), so the
    //    payoff of the whole descent must not be readable in the free download's source.
    //    ⚠️ `endingLoss` below is NOT paid content and must stay here: a party can wipe on rung
    //    one, so the free build reaches `defeat` legitimately and would otherwise draw nothing.
    endingWin: FULL ? FULL.ENDING_WIN : null,
    endingLoss: [
      'You gave away the wrong thing.',
      'Not the weakest thing — the wrong thing.',
      '',
      'The cairn is patient. It kept what you paid,',
      'and it will be here when someone else comes down.'
    ]
  };

  return { COMPANIONS: COMPANIONS, POWERS: POWERS, BOSSES: BOSSES, SHAPE: SHAPE, STORY: STORY };
});
