/*
 * REVERSE RPG — run.js
 * THE SCENE MACHINE. Pure: no DOM, no canvas, no timers.
 *
 * ⛔ IT IS PURE SO THAT THE HARNESS DRIVES THE SHIPPED PRODUCT RATHER THAN A DOUBLE. Every
 *    transition a player can cause is a function here, ui.js only renders and forwards input,
 *    and the playthrough harness calls the SAME functions. wing §6b-18: a game whose loop is
 *    owned by requestAnimationFrame cannot be driven in a background tab, and the fix is
 *    structural — one place a step happens, with rAF merely one caller.
 *
 * ⛔ EVERY REFUSAL NAMES ITS REASON (wing §0z). A bare null makes a hostile input, a version
 *    skew and a defect in this function indistinguishable — and a unit mismatch into a guard
 *    fails CLOSED and imitates exactly the condition the guard exists for.
 */
(function (root, factory) {
  'use strict';
  var mod = factory(
    typeof module === 'object' && module && module.exports ? require('./rules.js')   : root.RR_RULES,
    typeof module === 'object' && module && module.exports ? require('./content.js') : root.RR_CONTENT,
    typeof module === 'object' && module && module.exports ? require('./paths.js')   : root.RR_PATHS
  );
  if (typeof module === 'object' && module && module.exports) module.exports = mod;
  else root.RR_RUN = mod;
})(typeof self !== 'undefined' ? self : this, function (R, C, P) {
  'use strict';

  // The scenes a player can be in. Kept as a declared list so ui.js and the harness can assert
  // they handle all of them — an unhandled scene is a blank screen with no error.
  var SCENES = ['title', 'prologue', 'descent', 'battle', 'aftermath', 'sacrifice', 'ending', 'defeat', 'demowall'];

  function bossCount(build) {
    // ⛔ The demo is the same code with fewer rungs. There is no second codebase to drift, and
    //    the paid build is NOT "the demo plus content" — it is this number.
    return build === 'demo' ? C.SHAPE.demoBosses : C.SHAPE.nBosses;
  }

  function create(seed, build) {
    var b = build || (P && P.build) || 'full';
    var g = {
      seed: seed,
      build: b,
      nBosses: bossCount(b),
      scene: 'title',
      run: null,
      fight: null,
      // presentation state the renderer reads; the machine owns it so a harness sees it too
      banner: '',
      lastEvents: [],
      lastSacrifice: null,
      page: 0,          // for multi-page text scenes
      depth: 0
    };
    return g;
  }

  function begin(g) {
    if (g.scene !== 'title') return { ok: false, reason: 'begin-is-only-legal-on-the-title-screen' };
    g.run = R.newRun(g.seed, C.BOSSES, C.POWERS, g.nBosses);
    g.scene = 'prologue';
    g.page = 0;
    return { ok: true };
  }

  function currentBoss(g) { return g.run ? g.run.ladder[g.run.index] : null; }

  // ⭐ THE M3 REQUIREMENT, AS A FUNCTION RATHER THAN A PROMISE IN A DOC. DESIGN.md kept M3 as a
  //    UI requirement: the player must be able to SEE what is coming, or the sacrifice is a coin
  //    flip rather than a decision, and the whole 33.5-point informed-play gap is unreachable by
  //    a human. The renderer calls this; the harness asserts it is non-empty on the sacrifice
  //    screen. Note it deliberately reports the boss that will INHERIT, at M4_HORIZON.
  function horizon(g) {
    if (!g.run) return [];
    var out = [];
    for (var k = 0; k < 3; k++) {
      var i = g.run.index + k;
      if (i >= g.run.ladder.length) break;
      var b = g.run.ladder[i];
      out.push({
        index: i, name: b.name, id: b.id, faction: b.faction,
        wards: R.allWards(b),
        inherited: b.inherited.slice(),
        isInheritor: k === R.K.M4_HORIZON,
        hp: b.hp, dmg: b.dmg
      });
    }
    return out;
  }

  function openBattle(g) {
    if (g.scene !== 'prologue' && g.scene !== 'descent') return { ok: false, reason: 'battle-opens-from-prologue-or-descent' };
    var boss = currentBoss(g);
    if (!boss) return { ok: false, reason: 'no-boss-at-this-rung' };
    g.fight = R.newFight(g.run.powers, boss, g.run.sacrificed.length);
    g.scene = 'battle';
    g.banner = boss.line;
    g.lastEvents = [];
    return { ok: true };
  }

  // The one action a player takes in a fight.
  function spend(g, powerId) {
    if (g.scene !== 'battle') return { ok: false, reason: 'not-in-a-fight' };
    var res = R.act(g.fight, g.run.powers, powerId);
    if (!res.ok) return res;
    g.lastEvents = res.events;
    return afterTurn(g, res);
  }

  // "I have nothing left to spend." A first-class action, not a stuck state.
  function pass(g) {
    if (g.scene !== 'battle') return { ok: false, reason: 'not-in-a-fight' };
    var res = R.pass(g.fight, g.run.powers);
    if (!res.ok) return res;
    g.lastEvents = res.events;
    return afterTurn(g, res);
  }

  function afterTurn(g, res) {
    if (res.outcome === 'win') {
      g.run.depth++;
      g.depth = g.run.depth;
      g.scene = 'aftermath';
    } else if (res.outcome === 'loss' || res.outcome === 'timeout') {
      g.scene = 'defeat';
      g.run.over = true;
      g.run.ending = res.outcome === 'timeout' ? 'stalled' : 'defeat';
    }
    return { ok: true, outcome: res.outcome, events: res.events };
  }

  // From the victory beat to the choice.
  function toSacrifice(g) {
    if (g.scene !== 'aftermath') return { ok: false, reason: 'sacrifice-follows-a-victory' };
    // The last rung has no sacrifice after it — you are done paying.
    if (g.run.index >= g.run.ladder.length - 1) return finish(g);
    if (!g.run.powers.length) return finish(g);
    g.scene = 'sacrifice';
    return { ok: true };
  }

  // What the sacrifice screen must show for EVERY option. The consequence is not flavour text;
  // it is the information the decision is made of.
  function options(g) {
    if (!g.run) return [];
    var out = [];
    for (var i = 0; i < g.run.powers.length; i++) {
      var p = g.run.powers[i];
      var c = R.sacrificeConsequence(g.run, p.id);
      out.push({
        power: p,
        inheritor: c && c.boss ? { index: c.boss.i, name: c.boss.name, id: c.boss.id } : null,
        // `already` means the sacrifice teaches that boss nothing new — either the power is
        // defensive (nothing to wear) or the boss already wards that type.
        already: c ? c.already : true
      });
    }
    return out;
  }

  function give(g, powerId) {
    if (g.scene !== 'sacrifice') return { ok: false, reason: 'not-at-the-sacrifice' };
    var res = R.sacrifice(g.run, powerId);
    if (!res.ok) return res;
    g.lastSacrifice = { power: res.power, stolen: res.stolen };
    if (g.run.index >= g.run.ladder.length) return finish(g);
    g.scene = 'descent';
    return { ok: true, sacrifice: g.lastSacrifice };
  }

  function finish(g) {
    g.run.over = true;
    // ⚠️ The DEMO ends where the buying decision is honestly made, and it is NOT a teaser cut:
    //    it stops after the third rung, i.e. after the SECOND sacrifice, which is the first
    //    time M4's consequence has actually landed on a boss the player then has to fight.
    //    Ending before that would sell curiosity a version of the game that has not started.
    g.scene = (g.build === 'demo') ? 'demowall' : 'ending';
    g.run.ending = 'finished';
    return { ok: true, ending: g.scene };
  }

  // Advance a text scene, or leave it. ONE entry point so the harness cannot reach a scene by
  // a route a player has no button for.
  function advance(g) {
    switch (g.scene) {
      case 'title':     return begin(g);
      case 'prologue':
        g.page++;
        if (g.page >= C.STORY.opening.length) return openBattle(g);
        return { ok: true };
      case 'descent':   return openBattle(g);
      case 'aftermath': return toSacrifice(g);
      case 'ending':
      case 'defeat':
      case 'demowall':
        // Back to the title. A run is a run; there is no meta-progression to carry (LAW 1).
        g.scene = 'title'; g.run = null; g.fight = null; g.page = 0; g.lastSacrifice = null;
        return { ok: true, restarted: true };
      default: return { ok: false, reason: 'advance-is-not-a-legal-input-in-scene-' + g.scene };
    }
  }

  // A compact snapshot for the renderer AND the harness, so both read the same picture.
  function snapshot(g) {
    return {
      scene: g.scene, build: g.build, nBosses: g.nBosses, depth: g.depth, seed: g.seed,
      powers: g.run ? g.run.powers.map(function (p) { return p.id; }) : [],
      sacrificed: g.run ? g.run.sacrificed.slice() : [],
      boss: g.fight ? { id: g.fight.boss.id, name: g.fight.boss.name, hp: g.fight.bossHp, maxHp: g.fight.bossMaxHp, wards: R.allWards(g.fight.boss) } : null,
      partyHp: g.fight ? g.fight.partyHp : null,
      shield: g.fight ? g.fight.shield : null,
      round: g.fight ? g.fight.round : null,
      telegraph: g.fight ? g.fight.telegraph : null,
      grant: g.fight ? g.fight.grant : null,
      uses: g.fight ? JSON.parse(JSON.stringify(g.fight.uses)) : null,
      outcome: g.fight ? g.fight.outcome : null
    };
  }

  return {
    SCENES: SCENES, create: create, begin: begin, advance: advance,
    openBattle: openBattle, spend: spend, pass: pass,
    toSacrifice: toSacrifice, give: give, finish: finish,
    options: options, horizon: horizon, currentBoss: currentBoss, snapshot: snapshot,
    bossCount: bossCount
  };
});
