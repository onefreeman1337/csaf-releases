/*
 * REVERSE RPG — backdrop.js
 * THE CHAMBER BEHIND THE BOSS. Ten of them, generated, one per rung of the cairn.
 *
 * ⛔ WHY THIS EXISTS. The battle screen is this product's Gate 1 hero image and its stage was a
 *    near-black rectangle with a small figure floating in it — measured by LOOKING at the real
 *    page (wing §0z), against a Gate 1 promise that reads "a SNES-era JRPG battle screen". A
 *    screenshot indistinguishable from an empty canvas is dismissed in the two seconds someone
 *    spends on a thumbnail (§3), and master §10b's dead-space rule fails a composite that is more
 *    than 20% empty. That stage was most of the frame.
 *
 * ⭐ IT IS GENERATED, NOT PAINTED, AND THAT IS THE POINT RATHER THAN A SHORTCUT.
 *    Master §1.1's actual bar is "does the product GENERATE that beauty rather than ship it", with
 *    volume as the moat: Meridian's 60 motifs x 8 palettes is the shape that has ever sold here.
 *    So this is a chamber GENERATOR — coursed stonework, pillars, a stair mouth, roots, standing
 *    stones, water — seeded per rung, with a palette that walks from damp mossy grey at the cairn
 *    mouth to cold blue-black at the bottom. Ten rungs x four faction dressings is forty distinct
 *    chambers out of one system, and none of them is a PNG.
 *
 * ⛔ AND IT INHERITS THE ONE RULE THIS WING PAID FOR TWICE (§0z, the prop-contrast row):
 *    CONTRAST IS A RELATION, NOT A PROPERTY. A chamber is only good if the BOSS still reads
 *    against it. Every value here is derived from the depth palette and then explicitly held
 *    DARKER and LOWER-CONTRAST than the figure that stands in front of it, and `backdrop_gate.js`
 *    measures that rather than trusting this comment.
 */
(function (root, factory) {
  'use strict';
  var mod = factory(
    typeof module === 'object' && module && module.exports ? require('./rules.js') : root.RR_RULES);
  if (typeof module === 'object' && module && module.exports) module.exports = mod;
  else root.RR_BACKDROP = mod;
})(typeof self !== 'undefined' ? self : (typeof globalThis !== 'undefined' ? globalThis : this), function (R) {
  'use strict';

  // ─── THE DEPTH PALETTE ──────────────────────────────────────────────────────────────
  // ⭐ ONE WALK, TEN STOPS. The cairn mouth is damp and green and still has daylight in it; the
  //    bottom is blue-black and lit only by whatever you brought. Interpolating a single pair of
  //    endpoints keeps the ten chambers a SERIES rather than ten unrelated rooms — the thing that
  //    makes a set of generated images read as authored.
  var TOP = { wall: [58, 62, 52], mortar: [38, 42, 36], floor: [44, 46, 40], moss: [72, 92, 58], glow: [196, 150, 92] };
  var BOTTOM = { wall: [34, 38, 52], mortar: [20, 23, 33], floor: [24, 27, 38], moss: [44, 62, 78], glow: [96, 128, 176] };

  function lerp(a, b, t) { return a + (b - a) * t; }
  function mix(c1, c2, t) { return [lerp(c1[0], c2[0], t), lerp(c1[1], c2[1], t), lerp(c1[2], c2[2], t)]; }
  function rgb(c, a) {
    return 'rgba(' + Math.round(c[0]) + ',' + Math.round(c[1]) + ',' + Math.round(c[2]) + ',' + (a === undefined ? 1 : a) + ')';
  }
  function shade(c, k) { return [c[0] * k, c[1] * k, c[2] * k]; }

  /** The palette for a rung. `t` is 0 at the cairn mouth and 1 at the last warden. */
  function paletteFor(depth, nDepths) {
    var t = nDepths > 1 ? Math.max(0, Math.min(1, depth / (nDepths - 1))) : 0;
    return {
      t: t,
      wall: mix(TOP.wall, BOTTOM.wall, t),
      mortar: mix(TOP.mortar, BOTTOM.mortar, t),
      floor: mix(TOP.floor, BOTTOM.floor, t),
      moss: mix(TOP.moss, BOTTOM.moss, t),
      glow: mix(TOP.glow, BOTTOM.glow, t)
    };
  }

  // ─── FACTION DRESSING ───────────────────────────────────────────────────────────────
  // Each faction leaves the chamber marked in its own way. This is what stops rung 3 and rung 7
  // reading as the same room at a different brightness.
  var DRESS = {
    'THE RESTLESS DEAD': { niches: true, bones: true, roots: false, banners: false, water: false },
    'THE PALE CHOIR': { niches: true, bones: false, roots: false, banners: true, water: false },
    'THE BARROW BEASTS': { niches: false, bones: true, roots: true, banners: false, water: true },
    'THE IRON WARDENS': { niches: false, bones: false, roots: false, banners: true, water: false }
  };
  function dressFor(faction) { return DRESS[faction] || DRESS['THE RESTLESS DEAD']; }

  /**
   * Draw the chamber into `ctx` over the rectangle (x, y, w, h).
   * Deterministic: the same (depth, faction, seed) always draws the same chamber, which is what
   * lets a gate photograph it and what stops the wall crawling every frame.
   */
  function draw(ctx, x, y, w, h, opts) {
    opts = opts || {};
    var depth = opts.depth || 0;
    var nDepths = opts.nDepths || 10;
    var P = paletteFor(depth, nDepths);
    var D = dressFor(opts.faction);
    var rnd = R.rng((opts.seed || 1) * 7919 + depth * 104729 + 13);

    var horizon = y + Math.round(h * 0.66);      // where the back wall meets the floor

    // ── 1. the back wall, as a value gradient rather than a flat fill. A flat rectangle is what
    //       "no backdrop" looks like with a colour on it.
    var g = ctx.createLinearGradient(0, y, 0, horizon);
    g.addColorStop(0, rgb(shade(P.wall, 0.55)));
    g.addColorStop(0.65, rgb(P.wall));
    g.addColorStop(1, rgb(shade(P.wall, 0.78)));
    ctx.fillStyle = g;
    ctx.fillRect(x, y, w, horizon - y);

    // ── 2. COURSED STONEWORK. Rows of blocks with a half-block offset per course, each block
    //       jittered in value so the wall has grain. This is the bulk of the chamber and it is
    //       the difference between "a wall" and "a rectangle".
    var courseH = 18;
    var rows = Math.ceil((horizon - y) / courseH);
    for (var r0 = 0; r0 < rows; r0++) {
      var by = y + r0 * courseH;
      var bh = Math.min(courseH, horizon - by);
      if (bh <= 2) continue;
      // rows further up are further away: darker and lower contrast
      var far = 1 - (by - y) / Math.max(1, horizon - y);
      var offset = (r0 % 2) * 26;
      for (var bx = x - offset; bx < x + w; bx += 52) {
        var jitter = 0.86 + rnd() * 0.28;
        var bw = 52 - 2;
        var cx0 = Math.max(x, bx);
        var cw = Math.min(bx + bw, x + w) - cx0;
        if (cw <= 0) continue;
        ctx.fillStyle = rgb(shade(P.wall, jitter * (0.72 + 0.28 * (1 - far))));
        ctx.fillRect(cx0, by, cw, bh - 2);
        // a lit top edge and a shadowed underside: a block is a solid, not a swatch
        ctx.fillStyle = rgb(shade(P.wall, jitter * 1.24), 0.55);
        ctx.fillRect(cx0, by, cw, 1);
        ctx.fillStyle = rgb(P.mortar, 0.85);
        ctx.fillRect(cx0, by + bh - 2, cw, 2);
      }
    }

    // ── 3. THE STAIR MOUTH. A dark arch behind the boss — the way further down, which is the
    //       whole direction of this game and the one piece of narrative the backdrop can carry.
    var ax = x + w / 2, aw = Math.round(w * 0.30), ah = Math.round((horizon - y) * 0.78);
    var ay = horizon - ah;
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(ax - aw / 2, horizon);
    ctx.lineTo(ax - aw / 2, ay + aw / 2);
    ctx.quadraticCurveTo(ax, ay - aw * 0.18, ax + aw / 2, ay + aw / 2);
    ctx.lineTo(ax + aw / 2, horizon);
    ctx.closePath();
    ctx.clip();
    var ag = ctx.createLinearGradient(0, ay, 0, horizon);
    ag.addColorStop(0, rgb(shade(P.wall, 0.10)));
    ag.addColorStop(1, rgb(shade(P.wall, 0.28)));
    ctx.fillStyle = ag; ctx.fillRect(ax - aw, ay - 40, aw * 2, ah + 60);
    // steps receding into it, each one dimmer — depth without perspective maths
    for (var s0 = 0; s0 < 6; s0++) {
      var sy = horizon - 6 - s0 * 9;
      var sw = aw * (1 - s0 * 0.12);
      ctx.fillStyle = rgb(shade(P.wall, 0.34 - s0 * 0.04), 0.9);
      ctx.fillRect(ax - sw / 2, sy, sw, 4);
    }
    ctx.restore();
    // the arch ring itself, so the opening reads as built rather than as a hole
    ctx.strokeStyle = rgb(shade(P.wall, 1.18), 0.75);
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(ax - aw / 2 - 1, horizon);
    ctx.lineTo(ax - aw / 2 - 1, ay + aw / 2);
    ctx.quadraticCurveTo(ax, ay - aw * 0.18 - 3, ax + aw / 2 + 1, ay + aw / 2);
    ctx.lineTo(ax + aw / 2 + 1, horizon);
    ctx.stroke();

    // ── 4. PILLARS at the edges. They frame the figure and give the eye a near/far reference.
    var pw = Math.round(w * 0.085);
    [x + pw * 0.35, x + w - pw * 1.35].forEach(function (px) {
      var pg = ctx.createLinearGradient(px, 0, px + pw, 0);
      pg.addColorStop(0, rgb(shade(P.wall, 0.55)));
      pg.addColorStop(0.35, rgb(shade(P.wall, 1.10)));
      pg.addColorStop(1, rgb(shade(P.wall, 0.42)));
      ctx.fillStyle = pg;
      ctx.fillRect(px, y, pw, horizon - y + 10);
      // capital and base
      ctx.fillStyle = rgb(shade(P.wall, 1.2), 0.9);
      ctx.fillRect(px - 4, y + 8, pw + 8, 7);
      ctx.fillRect(px - 5, horizon - 4, pw + 10, 8);
      ctx.fillStyle = rgb(P.mortar, 0.7);
      ctx.fillRect(px - 4, y + 15, pw + 8, 2);
    });

    // ── 5. FACTION DRESSING ──────────────────────────────────────────────────────────
    if (D.niches) {
      // burial niches cut into the wall, each with something pale in it
      for (var n0 = 0; n0 < 4; n0++) {
        var nx = x + w * (0.20 + n0 * 0.20) + (rnd() - 0.5) * 10;
        var ny = y + 26 + rnd() * 18;
        if (Math.abs(nx - ax) < aw * 0.62) continue;          // never over the arch
        // ⚠️ A RECESS IS NOT A DARK RECTANGLE. The first version drew a flat dark box with a pale
        //    blob in it and photographed as a wall-mounted crate — §0z's own rule, that a recess
        //    is the INVERSE bevel of a raised plate with the same floor shade, was written down in
        //    art.js and not applied here. Lit along the BOTTOM lip and shadowed along the top is
        //    what says "cut into this" rather than "lying on this".
        var ng = ctx.createLinearGradient(0, ny, 0, ny + 34);
        ng.addColorStop(0, rgb(shade(P.wall, 0.14)));
        ng.addColorStop(1, rgb(shade(P.wall, 0.34)));
        ctx.fillStyle = ng;
        ctx.fillRect(nx - 13, ny, 26, 34);
        ctx.fillStyle = rgb(shade(P.wall, 0.30), 0.9);         // shadow under the top edge
        ctx.fillRect(nx - 13, ny, 26, 3);
        ctx.fillStyle = rgb(shade(P.wall, 1.25), 0.75);        // the sill catches the light
        ctx.fillRect(nx - 15, ny + 33, 30, 3);
        ctx.fillStyle = rgb(shade(P.wall, 1.05), 0.35);
        ctx.fillRect(nx - 15, ny + 36, 30, 1);
        // what is in it: a skull, read as a dome over a jaw with two sockets
        var bone = rgb(mix(P.moss, [214, 208, 192], 0.78), 0.62);
        ctx.fillStyle = bone;
        ctx.fillRect(nx - 6, ny + 15, 12, 9);
        ctx.fillRect(nx - 4, ny + 24, 8, 4);
        ctx.fillStyle = rgb(shade(P.wall, 0.08), 0.85);        // eye sockets
        ctx.fillRect(nx - 4, ny + 18, 3, 3);
        ctx.fillRect(nx + 1, ny + 18, 3, 3);
      }
    }
    if (D.banners) {
      // hanging cloth: two long rectangles with a torn hem
      for (var b0 = 0; b0 < 2; b0++) {
        var vx = x + w * (b0 ? 0.74 : 0.26);
        var vh = 60 + rnd() * 40;
        ctx.fillStyle = rgb(mix(P.mortar, P.glow, 0.18), 0.75);
        ctx.fillRect(vx - 11, y + 6, 22, vh);
        ctx.fillStyle = rgb(mix(P.mortar, P.glow, 0.32), 0.6);
        ctx.fillRect(vx - 11, y + 6, 3, vh);
        for (var tq = 0; tq < 4; tq++) {
          ctx.fillRect(vx - 11 + tq * 6, y + 6 + vh, 4, 3 + rnd() * 5);
        }
      }
    }
    if (D.roots) {
      // ⚠️ SEVEN THIN STROKES READ AS ONE FAINT SCRATCH AT THIS SIZE — rung 4 photographed as the
      //    plainest of the four chambers despite being the one the hill is reclaiming. More of
      //    them, longer, with side branches and a lit edge so they sit ON the wall.
      for (var q0 = 0; q0 < 14; q0++) {
        var rx = x + rnd() * w, spread = (rnd() - 0.5) * 90, len = 70 + rnd() * 110;
        ctx.lineWidth = 1 + rnd() * 3;
        ctx.strokeStyle = rgb(shade(P.moss, 0.55), 0.5 + rnd() * 0.3);
        ctx.beginPath(); ctx.moveTo(rx, y);
        ctx.quadraticCurveTo(rx + spread * 0.5, y + len * 0.5, rx + spread, y + len);
        ctx.stroke();
        // a highlight down one side gives the root a round surface
        ctx.lineWidth = 1;
        ctx.strokeStyle = rgb(mix(P.moss, P.glow, 0.35), 0.22);
        ctx.beginPath(); ctx.moveTo(rx + 1, y);
        ctx.quadraticCurveTo(rx + 1 + spread * 0.5, y + len * 0.5, rx + 1 + spread, y + len);
        ctx.stroke();
        if (rnd() < 0.5) {                                   // a side branch
          ctx.lineWidth = 1;
          ctx.strokeStyle = rgb(shade(P.moss, 0.5), 0.4);
          var mx0 = rx + spread * 0.5, my0 = y + len * 0.5;
          ctx.beginPath(); ctx.moveTo(mx0, my0);
          ctx.quadraticCurveTo(mx0 + (rnd() - 0.5) * 40, my0 + 20, mx0 + (rnd() - 0.5) * 60, my0 + 44);
          ctx.stroke();
        }
      }
    }
    if (D.bones) {
      // ⚠️ A ROW OF EQUAL DASHES AT ONE HEIGHT IS NOT A SCATTER, IT IS A SEAM. The first version
      //    photographed as a dashed line ruled along the base of the wall. Bones vary in length,
      //    sit at different depths, and some of them are round.
      var boneC = mix(P.moss, [206, 200, 184], 0.75);
      for (var k0 = 0; k0 < 11; k0++) {
        var kx = x + 16 + rnd() * (w - 32);
        var ky = horizon - 10 + rnd() * rnd() * 26;            // clustered near the wall, not on a line
        if (Math.abs(kx - ax) < aw * 0.4) continue;
        var a0 = 0.28 + rnd() * 0.26;
        if (rnd() < 0.3) {
          ctx.fillStyle = rgb(boneC, a0);                       // a skull: a small dome
          ctx.fillRect(kx, ky, 7, 5); ctx.fillRect(kx + 1, ky + 5, 5, 2);
        } else {
          // a long bone, tilted, with knuckled ends
          var bl = 9 + rnd() * 16, th = rnd() < 0.5 ? 2 : 3;
          ctx.fillStyle = rgb(boneC, a0);
          ctx.fillRect(kx, ky, bl, th);
          ctx.fillRect(kx - 1, ky - 1, 3, th + 2);
          ctx.fillRect(kx + bl - 2, ky - 1, 3, th + 2);
        }
      }
    }

    // ── 6. MOSS AND DAMP, thickest at the bottom of the wall and thinning upward. It is the one
    //       thing that keeps the stonework from reading as a tidy brick texture.
    for (var m0 = 0; m0 < 60; m0++) {
      var mx = x + rnd() * w;
      var my = horizon - rnd() * rnd() * (horizon - y);
      ctx.fillStyle = rgb(P.moss, 0.05 + rnd() * 0.13);
      ctx.fillRect(mx, my, 3 + rnd() * 9, 2 + rnd() * 4);
    }
    if (D.water) {
      // a wet sheen down one course, and a pool line at the foot
      ctx.fillStyle = rgb(mix(P.moss, P.glow, 0.3), 0.13);
      ctx.fillRect(x + w * 0.62, y, 16, horizon - y);
      ctx.fillStyle = rgb(mix(P.moss, P.glow, 0.4), 0.18);
      ctx.fillRect(x + w * 0.55, horizon - 3, w * 0.2, 3);
    }

    // ── 7. THE FLOOR — and it is FLAGSTONES, not a gradient with lines on it.
    // ⛔ THE FIRST VERSION OF THIS WAS THE DEFECT IT WAS MEANT TO FIX. It laid a smooth gradient
    //    and drew 1px joints at 0.32-0.5 alpha over it; baked and LOOKED at across four rungs, the
    //    bottom third of every chamber was a flat empty band with no readable joint at all. The
    //    floor is the single largest area of the stage, so an empty floor is the same dead-space
    //    problem the whole backdrop exists to remove, just moved down the frame.
    // ✅ Each course is now drawn as actual STONES with per-stone value jitter, exactly like the
    //    wall — the treatment that was already working two hundred pixels higher up. Courses grow
    //    deeper toward the viewer, which is the foreshortening, and each course is offset half a
    //    stone so the joints never line up into a grid.
    var fg = ctx.createLinearGradient(0, horizon, 0, y + h);
    fg.addColorStop(0, rgb(shade(P.floor, 0.62)));
    fg.addColorStop(1, rgb(shade(P.floor, 1.18)));
    ctx.fillStyle = fg; ctx.fillRect(x, horizon, w, y + h - horizon);

    var fy = horizon, band = 7, course = 0;
    while (fy < y + h) {
      var near = (fy - horizon) / Math.max(1, y + h - horizon);   // 0 at the wall, 1 at the front
      var stoneW = 30 + near * 46;
      var off = (course % 2) * (stoneW / 2);
      for (var sx = x - off; sx < x + w; sx += stoneW) {
        var sx0 = Math.max(x, sx);
        var sw2 = Math.min(sx + stoneW - 2, x + w) - sx0;
        if (sw2 <= 0) continue;
        var jit = 0.84 + rnd() * 0.32;
        ctx.fillStyle = rgb(shade(P.floor, jit * (0.66 + 0.5 * near)));
        ctx.fillRect(sx0, Math.round(fy), sw2, Math.round(band) - 1);
        // the near edge of a flagstone catches the light; the joint behind it is in shadow
        ctx.fillStyle = rgb(shade(P.floor, jit * 1.35), 0.45 + 0.3 * near);
        ctx.fillRect(sx0, Math.round(fy + band) - 2, sw2, 1);
        ctx.fillStyle = rgb(P.mortar, 0.55);
        ctx.fillRect(Math.round(sx0 + sw2), Math.round(fy), 1, Math.round(band) - 1);
      }
      ctx.fillStyle = rgb(P.mortar, 0.45);
      ctx.fillRect(x, Math.round(fy), w, 1);
      fy += band; band += 3.4; course++;
    }
    // damp gathering in the joints nearest the wall, where a floor always stains first
    for (var wd = 0; wd < 26; wd++) {
      var dx = x + rnd() * w, dy = horizon + rnd() * rnd() * 26;
      ctx.fillStyle = rgb(P.moss, 0.05 + rnd() * 0.10);
      ctx.fillRect(dx, dy, 5 + rnd() * 14, 2 + rnd() * 3);
    }

    // ── 8. THE LIGHT. One pool from above-front, which is where the party's own light would be,
    //       and it is what puts the boss in a lit space rather than on a backdrop.
    var lg = ctx.createRadialGradient(ax, horizon - 10, 10, ax, horizon - 10, w * 0.55);
    lg.addColorStop(0, rgb(P.glow, 0.16));
    lg.addColorStop(0.5, rgb(P.glow, 0.05));
    lg.addColorStop(1, rgb(P.glow, 0));
    ctx.fillStyle = lg; ctx.fillRect(x, y, w, h);

    // ── 9. VIGNETTE. The corners go down so the eye lands on the figure. Deeper rungs are
    //       darker, so the last chamber is nearly a tunnel.
    var vg = ctx.createRadialGradient(ax, horizon - 20, h * 0.30, ax, horizon - 20, h * 1.15);
    vg.addColorStop(0, 'rgba(0,0,0,0)');
    vg.addColorStop(1, 'rgba(0,0,0,' + (0.55 + 0.30 * P.t).toFixed(2) + ')');
    ctx.fillStyle = vg; ctx.fillRect(x, y, w, h);

    return { horizon: horizon, palette: P, dress: D };
  }

  return {
    draw: draw,
    paletteFor: paletteFor,
    dressFor: dressFor,
    DRESS: DRESS,
    /* published so a gate can assert the series is a series, rather than restating the endpoints */
    ENDPOINTS: { TOP: TOP, BOTTOM: BOTTOM }
  };
});
