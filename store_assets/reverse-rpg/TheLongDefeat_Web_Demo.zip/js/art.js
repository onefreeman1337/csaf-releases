/*
 * REVERSE RPG — art.js
 * Palette, layout geometry, drawing primitives, and the sprite atlas loader.
 *
 * ⛔ THE LAYOUT IS PUBLISHED ON `LAYOUT` AND READ BY THE UI TEST, NEVER RESTATED THERE.
 *    wing §0z: a checker holding the same numbers as the thing it checks certifies whatever
 *    those numbers later become. The gutter test reads these columns, so the layout and the
 *    assertion cannot drift apart.
 *
 * ⛔ ONE PIXEL DENSITY, INTEGER SCALES ONLY. Every sprite is the 64 grid and is drawn at 2x or
 *    3x with smoothing OFF. Wildmark01 is 128-native and Mourncrest 64-native and both ship
 *    both variants, so drawing "everything at 128" would pair native art with 2x-blown-up art —
 *    mixed density, which is the amateur tell §0-ART-b exists to prevent. A non-integer scale
 *    shimmers, which is the other one.
 *
 * ⚠️ FONTS ARE SYSTEM STACKS ON PURPOSE. Bundling a display face would buy identity and cost a
 *    licence review plus payload on a game whose whole distribution advantage is loading fast
 *    in an itch iframe. Identity here comes from the palette, the plate geometry and the
 *    first-party art. Recorded as a decision rather than an oversight.
 */
(function (root, factory) {
  'use strict';
  var mod = factory(
    typeof module === 'object' && module && module.exports ? require('./paths.js') : root.RR_PATHS
  );
  if (typeof module === 'object' && module && module.exports) module.exports = mod;
  else root.RR_ART = mod;
})(typeof self !== 'undefined' ? self : this, function (P) {
  'use strict';

  var W = 960, H = 540;

  // ─── PALETTE ────────────────────────────────────────────────────────────────────────
  // Cold stone, one warm light. The type colours are the game's whole information channel —
  // a player reads "can I hurt this thing" off colour before they read any word — so they are
  // chosen for separation at small size, not for prettiness.
  var PAL = {
    bg0: '#0d0f14', bg1: '#161a22', bg2: '#1e2430',
    stone: '#2a3140', stoneLit: '#3d4658', stoneDark: '#141821',
    ink: '#e8e4da', inkDim: '#9aa0ac', inkFaint: '#5d6675',
    warm: '#f0b357', warmDark: '#7a5320',
    bad: '#c9455a', good: '#6fbf73',
    fire: '#f0703c', ice: '#63c6e0', holy: '#f2d47a', physical: '#b9c2cf', arcane: '#b07be0',
    ward: '#7f93b8', heal: '#7fc98d'
  };
  function typeColour(t) { return PAL[t] || PAL.ink; }

  // ─── LAYOUT ─────────────────────────────────────────────────────────────────────────
  // Three columns with real gutters. The UI test asserts no string crosses a gutter, reading
  // these numbers rather than holding a copy of them.
  var LAYOUT = {
    W: W, H: H,
    gutter: 14,
    cols: {
      left:  { x: 18,  w: 214 },   // the party and their health
      mid:   { x: 246, w: 432 },   // the stage: boss, effects, banner
      right: { x: 692, w: 250 }    // the descent: what is coming, and what you have given up
    },
    sheet: { x: 18, y: 356, w: 924, h: 166 },   // the character sheet — the shrinking artefact
    stage: { x: 246, y: 96, w: 432, h: 244 },
    bossBar: { x: 246, y: 60, w: 432, h: 18 },
    // ⭐ THE ROSTER, and it exists because of a LOOK. The first build put all four companions
    //    into the stage at 34px spacing and left this whole column empty — ~230px of dead black
    //    beside a crowded huddle. MEASURED in the browser off the real staged frames: a Wildmark
    //    figure is only 14-20px of opaque art inside its 64px cell (9.6-19.7% opaque), so the
    //    cell size was never the right number to lay out from. Moving the party here gives the
    //    boss the whole stage, fills the column, and puts the moment Gate 1 is built around —
    //    a companion going dark as their last power is given up — where it can be seen.
    roster: { x: 18, y: 60, w: 214, rowH: 62, plateH: 58, rows: 4 },
    partyBar: { x: 18, y: 316, w: 214, h: 16 }
  };
  // ⭐ MEASURED, NOT ASSUMED: every Wildmark and Mourncrest frame draws its figure with the FEET
  //    at row 61 of the 64px cell and the head no higher than row 2 (read in-browser off the real
  //    staged PNGs: warrior y 3..61, mage 3..61, elf 9..61, rogue 3..61, skeleton 2..61,
  //    barrowWyrm 4..61, inquisitor 3..61). Anchoring by the CELL puts three transparent rows
  //    below the feet and clips the head against whatever is above — which is exactly what the
  //    first roster did, cutting every portrait and colliding with the column heading.
  //    Anchor by the CONTENT and the figure lands where it is drawn.
  var FOOT_ROW = 61;
  LAYOUT.footOffset = 64 - FOOT_ROW - 1;   // pixels of empty cell BELOW the feet, at 1x
  LAYOUT.gutters = [
    { x: LAYOUT.cols.left.x + LAYOUT.cols.left.w, w: LAYOUT.cols.mid.x - (LAYOUT.cols.left.x + LAYOUT.cols.left.w) },
    { x: LAYOUT.cols.mid.x + LAYOUT.cols.mid.w, w: LAYOUT.cols.right.x - (LAYOUT.cols.mid.x + LAYOUT.cols.mid.w) }
  ];

  var FONT = {
    display: function (px) { return '600 ' + px + 'px Georgia, "Times New Roman", serif'; },
    body:    function (px) { return px + 'px "Segoe UI", Roboto, Helvetica, Arial, sans-serif'; },
    num:     function (px) { return '600 ' + px + 'px ui-monospace, "SF Mono", Menlo, Consolas, monospace'; }
  };

  // ─── PRIMITIVES ─────────────────────────────────────────────────────────────────────
  // ⭐ A RAISED PLATE IS LIT TOP-LEFT AND SHADOWED BOTTOM-RIGHT; A RECESS IS THE INVERSE, WITH
  //    THE SAME FLOOR SHADE AS THE SURFACE AROUND IT (wing §6d-18 rule 2). Changing the value
  //    says "a different object lying there"; changing the bevel says "a slot cut into this".
  function plate(ctx, x, y, w, h, opts) {
    opts = opts || {};
    ctx.fillStyle = opts.fill || PAL.stone;
    ctx.fillRect(x, y, w, h);
    ctx.fillStyle = opts.recess ? PAL.stoneDark : PAL.stoneLit;
    ctx.fillRect(x, y, w, 1);
    ctx.fillRect(x, y, 1, h);
    ctx.fillStyle = opts.recess ? PAL.stoneLit : PAL.stoneDark;
    ctx.fillRect(x, y + h - 1, w, 1);
    ctx.fillRect(x + w - 1, y, 1, h);
  }

  function bar(ctx, x, y, w, h, frac, colour, opts) {
    opts = opts || {};
    plate(ctx, x, y, w, h, { fill: PAL.stoneDark, recess: true });
    var f = Math.max(0, Math.min(1, frac));
    if (f > 0) {
      ctx.fillStyle = colour;
      ctx.fillRect(x + 1, y + 1, Math.max(1, Math.round((w - 2) * f)), h - 2);
      // one lit pixel row so the bar reads as a filled solid, not a coloured rectangle
      ctx.fillStyle = 'rgba(255,255,255,0.16)';
      ctx.fillRect(x + 1, y + 1, Math.max(1, Math.round((w - 2) * f)), 1);
    }
    if (opts.ghost > f) {   // the damage that was just dealt, draining behind the bar
      ctx.fillStyle = 'rgba(255,255,255,0.20)';
      var g0 = x + 1 + Math.round((w - 2) * f);
      ctx.fillRect(g0, y + 1, Math.max(1, Math.round((w - 2) * (opts.ghost - f))), h - 2);
    }
  }

  // Text with an explicit maximum width. ⛔ It TRUNCATES VISIBLY with an ellipsis rather than
  // overflowing: a string that runs past its column is the defect the gutter test exists for,
  // and silently clipping it makes the test pass over a screen a player cannot read.
  function text(ctx, s, x, y, opts) {
    opts = opts || {};
    ctx.font = opts.font || FONT.body(14);
    ctx.fillStyle = opts.colour || PAL.ink;
    ctx.textAlign = opts.align || 'left';
    ctx.textBaseline = opts.baseline || 'alphabetic';
    var str = String(s);
    if (opts.maxW) {
      while (str.length > 1 && ctx.measureText(str).width > opts.maxW) str = str.slice(0, -1);
      if (str.length < String(s).length) str = str.slice(0, -1) + '…';
    }
    ctx.fillText(str, x, y);
    return ctx.measureText(str).width;
  }

  // Wrap into lines that fit `maxW`. Returns the lines so a caller can measure the block.
  function wrap(ctx, s, maxW, font) {
    ctx.font = font || FONT.body(14);
    var words = String(s).split(/\s+/), lines = [], cur = '';
    for (var i = 0; i < words.length; i++) {
      var t = cur ? cur + ' ' + words[i] : words[i];
      if (ctx.measureText(t).width > maxW && cur) { lines.push(cur); cur = words[i]; }
      else cur = t;
    }
    if (cur) lines.push(cur);
    return lines;
  }

  // ─── SPRITES ────────────────────────────────────────────────────────────────────────
  // The atlas keys are `<packId>/<frame>` and the pack id is part of the key BY DESIGN, so two
  // packs shipping a frame of the same name cannot collide (see stage_art.js).
  function createLoader(imageFactory) {
    var images = {}, atlas = null, state = 'idle', error = null, wanted = 0, got = 0;
    function load(onDone) {
      state = 'loading';
      var base = P.assets;
      fetch(base + 'sprites/atlas.json').then(function (r) {
        if (!r.ok) throw new Error('atlas ' + r.status);
        return r.json();
      }).then(function (a) {
        atlas = a;
        var keys = Object.keys(a.frames);
        wanted = keys.length;
        if (!wanted) { state = 'ready'; onDone && onDone(null); return; }
        keys.forEach(function (k) {
          var img = imageFactory();
          img.onload = function () { got++; if (got === wanted) { state = 'ready'; onDone && onDone(null); } };
          // ⚠️ A FAILED IMAGE COUNTS TOO, or one 404 leaves the game permanently "loading" with
          //    no error — the silent-refusal shape §0z warns about, in a loader.
          img.onerror = function () { got++; if (got === wanted) { state = 'ready'; onDone && onDone(null); } };
          img.src = base + a.frames[k];
          images[k] = img;
        });
      }).catch(function (e) {
        state = 'error'; error = e && e.message ? e.message : String(e);
        onDone && onDone(error);
      });
    }
    return {
      load: load,
      get: function (k) { return images[k] || null; },
      has: function (k) { return !!images[k]; },
      keys: function () { return atlas ? Object.keys(atlas.frames) : []; },
      status: function () { return { state: state, error: error, wanted: wanted, got: got }; }
    };
  }

  // Draw a 64px cell at an INTEGER scale, anchored at its FEET so a character stands on a line
  // rather than floating in a box.
  // `footY` is where the FIGURE'S FEET go, not where the cell's bottom edge goes — the cell
  // carries empty rows below the feet and anchoring by it floats every figure (see FOOT_ROW).
  function sprite(ctx, img, cx, footY, scale, opts) {
    if (!img || !img.width) return false;
    opts = opts || {};
    var s = Math.max(1, Math.round(scale));
    var w = 64 * s, h = 64 * s;
    footY = footY + LAYOUT.footOffset * s;
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    if (opts.alpha !== undefined) ctx.globalAlpha = opts.alpha;
    if (opts.flip) { ctx.translate(Math.round(cx), 0); ctx.scale(-1, 1); ctx.translate(-Math.round(cx), 0); }
    ctx.drawImage(img, 0, 0, 64, 64, Math.round(cx - w / 2), Math.round(footY - h), w, h);
    ctx.restore();
    return true;
  }

  // A contact shadow. ⭐ Without one a figure reads as a sticker ON the ground rather than
  // standing IN it — the same defect §0-ART-b rule 1 records for prop tiles.
  function shadow(ctx, cx, y, w) {
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.38)';
    ctx.beginPath();
    ctx.ellipse(Math.round(cx), Math.round(y), Math.round(w / 2), Math.max(3, Math.round(w / 7)), 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  return {
    W: W, H: H, PAL: PAL, LAYOUT: LAYOUT, FONT: FONT,
    typeColour: typeColour, plate: plate, bar: bar, text: text, wrap: wrap,
    createLoader: createLoader, sprite: sprite, shadow: shadow
  };
});
