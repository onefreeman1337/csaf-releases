/*
 * REVERSE RPG — paths.js
 * THE LAYOUT IS DECLARED ONCE, HERE.
 *
 * ⛔ WHY (wing §1-BUILD, measured on Lanternbound, which had 508 green assertions and no
 *    artefact): a web build changes exactly three things against the prototype tree — the asset
 *    base, the audio base, and which HTML file is the ENTRY — and ALL THREE FAIL SILENTLY. A
 *    wrong asset base makes `loadAll` report not-ready and the scene draws its flat-colour
 *    fallback with no error; a wrong page name is a navigation to a 404 that the player reads
 *    as the game ending.
 *
 * ⛔ AND DO NOT SOLVE IT WITH A PACKAGER THAT REWRITES SOURCE. That makes the bytes a buyer
 *    downloads bytes no gate ever ran against (master §2b, "a LOCAL fix is not a PUBLISHED
 *    fix"), and Product_Release ships raw and human-auditable anyway. Instead: this file holds
 *    the PROTOTYPE default, the generated page overrides it with ONE inline <script>, and
 *    build_web.js proves every shipped module is byte-identical to its source by sha256.
 *
 * ⚠️ RR_BUILD is the demo/paid switch and it lives here for the same reason. The free web demo
 *    and the paid build are the SAME CODE with a different boss count; nothing else differs, so
 *    there is no second codebase to drift.
 */
(function (root, factory) {
  'use strict';
  var mod = factory(root);
  if (typeof module === 'object' && module && module.exports) module.exports = mod;
  else root.RR_PATHS = mod;
})(typeof self !== 'undefined' ? self : this, function (root) {
  'use strict';
  var override = (root && root.RR_PATHS_OVERRIDE) || {};
  return {
    // Prototype default: proto/ sits one level under Internal_Ops, assets live in the sibling
    // Product_Release. The shipped page overrides both to plain relative paths.
    assets: override.assets || '../../Product_Release/assets/',
    audio:  override.audio  || '../../Product_Release/assets/audio/',
    // 'demo' = the free browser build (content.SHAPE.demoBosses rungs). 'full' = the paid build.
    build:  override.build  || (root && root.RR_BUILD) || 'full'
  };
});
