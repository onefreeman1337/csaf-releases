# Tray - Generated Packing Puzzles in Wood, for GameMaker

A packing puzzle for your game. A shaped tray sits on the table and its pieces wait in a box beside it, turned every
which way. The player picks them up, turns and flips them, and fits every one back into the tray. Nothing is an image
file: the workbench, the case, the baize and every piece of inlaid wood are drawn by the package.

- **Every puzzle is generated, and every one can be solved.** The tray - a rectangle, a cross, a diamond, a round, a
  notched or an arch - is cut into pieces of three to six squares, all different even turned over, so the pieces always
  go back. A solver grades each puzzle by how many DIFFERENT ways the tray can be filled (a turn or flip of the tray
  counted once): easy trays of 4 or 5 pieces fill at most 4 ways, normal trays of 6 or 7 at most 12, hard trays of 8 to
  10 at most 40.
- **Every piece is marquetry.** Each piece is cut from its own wood - walnut, maple, cherry, oak, ebony, ash, rosewood,
  yew, olive, holly, each with its own colour and figure (cathedral arches, maple's fiddleback, oak's silver flecks,
  rosewood's streaks, the knots of olive and yew) - and carries an inlaid motif (star, lozenge, rosette, bars, chevron,
  dot, ring, cross, leaf, wave) in brass, mother-of-pearl, holly or ebony, with a line of stringing run inside its edge.
  The grain and the inlay turn and flip with the piece; the light does not.
- **The whole table is designed.** An ebonised case with corner fans and a brass fillet, the tray's shape sunk into it
  and lined with baize, scored in squares; a parts box; a brass title plate; a tally card; brass plaques; a dashed ghost
  showing where a carried piece would land (gold if it fits, red if not); and when the tray is full, a band of polish runs
  across it and the finished panel is shown framed, with the woods listed.
- **Hints come from the solver.** A hint places one piece of a solution that keeps every piece already down, or, if no
  solution keeps them, takes out the piece that has to come out.

Ported from our RPG Maker MZ plugin Tray and held to it: the in-engine suite runs the generator, the solver and every
drawn thing through both and checks they agree (see Verification).

## Install

1. In GameMaker, **Tools > Import Local Package**, choose `Tray.yymps`, and import everything.
2. Run the project with `rm_tra_demo` first in the room order: Up/Down choose a tray shape, Left/Right the difficulty,
   Enter deals a tray. At the table: Left/Right choose a piece, Enter lifts it, the arrows move it over the tray, Q and W
   turn it, Shift flips it, Enter puts it down, Escape puts it back; Tab asks for a hint; Escape leaves. Or drag a piece
   with the mouse - the right button or the wheel turns it while you hold it - and click the plaques.

Requires GameMaker 2024.14 or later. Built and tested on runtime 2024.14.4.268 (the VM, Windows). Pure GML, no extension;
nothing here depends on GMRT.

## Quickstart

```gml
// Create - when the player opens the puzzle box
my_puzzle = tra_puzzle_for("chest in the old mill", "normal");
my_table = tra_scene_create(my_puzzle, { hints: 3 });

// Step
tra_scene_step(my_table);
if (tra_scene_done(my_table)) {
    var _r = tra_scene_result(my_table);   // undefined if the player left without filling the tray
    if (is_struct(_r)) {
        // open the chest; _r.moves and _r.hints say how it went
    }
    tra_scene_free(my_table);
}

// Draw GUI
tra_scene_draw(my_table, 0, 0, display_get_gui_width(), display_get_gui_height());
```

`tra_scene_step` reads the keyboard and the mouse itself (the mouse in GUI coordinates, so draw the scene in Draw GUI).
To use your own bindings, pass an input each step: `tra_scene_step(my_table, tra_input(left, right, up, down, ok, cancel,
turn_back, turn_on, flip, hint, mouse_x, mouse_y, held, click, right_click, wheel))` - the four directions are repeating
presses, the next six single presses, then the mouse in the coordinates you draw the scene in: `held` is the left button
down, `click` its press this step, `wheel` +1 down, -1 up.

One step is one 1/60 s frame, the original's timing (the polish, the reveal and the fades are counted in frames). At
another game speed, call `tra_scene_step` as many times as a 60 fps frame would have run.

`my_table.events` lists what happened during the last step - `"select"`, `"pick"`, `"drop"`, `"box"` (back in the box),
`"turn"`, `"refuse"` (it does not fit, or a plaque that is off), `"hint"`, `"solve"`, `"leave"` - so your game can play
its own sounds. Tray ships no audio.

## Puzzles

`tra_puzzle_for(seed, [difficulty], [shape])` takes a graded puzzle from the BOOK the package carries: 626 trays, graded by the original's own generate-and-test and stored with their layouts - 40 for each shape at easy, 33 to 40 at normal, 14 to 40 at hard (fewer where the generator rarely finds a tray tight enough). An index past the end wraps to the start, so the same shape and difficulty repeat after that many deals.
A seed can be any number or any string (a string is hashed), so "the chest in the old mill" always deals the same tray;
`shape` "auto" (the default) lets the seed choose the shape. It is instant - nothing is searched at play time.

A tray from any seed at all, graded fresh, comes from the generator itself: `tra_generate({seed, difficulty, shape})`
runs to the end (a hard tray can take SECONDS on the VM - MEASURED below), and `tra_generate_begin(options)` with
`tra_generate_step(job, max_ms)` spreads the same job over frames (read `job.result` when a step returns true). Given the
seed, difficulty and shape a book puzzle carries (`puzzle.seed`), both rebuild exactly that tray: the book was graded by
the same generator.

| field of a puzzle | meaning |
| --- | --- |
| `w`, `h`, `mask` | the tray's box of squares, and which squares are in the tray (1) |
| `pieces` | `{id, cells, wood, inlay}` each - cells as `[x, y]` squares |
| `solution` | one way to fill it: `{piece, x, y, cells}` each |
| `ways`, `graded` | how many different ways the tray fills, and whether the count is exact |
| `difficulty`, `shape`, `seed` | what made it |

## The result

`tra_scene_result(scene)` returns, once the tray is full:

| field | meaning |
| --- | --- |
| `solved` | true |
| `moves` | pieces put down by the player (a hint's piece is not counted) |
| `hints` | hints used |
| `difficulty`, `shape`, `pieces` | the tray's |
| `ways` | the different ways this tray fills, or -1 when it fills more ways than its difficulty allows |

## Functions

| function | what it does |
| --- | --- |
| `tra_puzzle_for(seed, [difficulty], [shape])` | a graded puzzle from the book, instantly |
| `tra_book_puzzle(difficulty, shape, index)`, `tra_book_count(difficulty, shape)` | the book by number |
| `tra_generate(options)`, `tra_generate_begin(options)`, `tra_generate_step(job, max_ms)` | a tray graded fresh from any seed (`{seed, difficulty, shape, raw}`) |
| `tra_scene_create(puzzle, [options])` | a table: `{title (the brass plate), hints (0-99, default 3), quality (internal scale 1-3), fade (false skips the 24-frame fade from black)}` |
| `tra_scene_step(scene, [input])` | one frame of the table; returns its mode |
| `tra_scene_draw(scene, x, y, w, h)` | draw the table fitted into a rectangle at 816 x 624 proportions |
| `tra_scene_done(scene)`, `tra_scene_result(scene)` | over yet, and the result |
| `tra_scene_prepare(scene)` | bake everything the table shows now (a loading screen) |
| `tra_scene_free(scene)` | free the table's surfaces |
| `tra_input(...)` | an input struct from your own bindings (see Quickstart) |
| `tra_room_prepare([quality])`, `tra_room_free()` | bake (or free) the workbench and parts box every table shares |

The rules can be driven without the screen - for a puzzle UI of your own, or a test: `tra_new_game(puzzle)`,
`tra_fits(puzzle, game, piece, cells, x, y)`, `tra_place(puzzle, game, piece, cells, x, y)`, `tra_lift(puzzle, game,
piece)`, `tra_solved(puzzle, game)`, `tra_hint(puzzle, game)` (or the same search spread over frames: `tra_hint_begin(puzzle,
game)`, then `tra_hint_step(job, max_ms)` until it returns true, then `job.result`), `tra_turn(cells, rot, flip)` (a piece
turned: `{cells, w, h}`), `tra_solve(mask, w, h, pieces, [options])` (the exact-cover counter).

And the drawing on its own, into any surface through the canvas kit: `tra_draw_piece(ctx, piece, x, y, square, [{rot, flip,
shadow, glow}])` (or, to keep a piece and its shadow in separate surfaces so a lift re-bakes only the shadow,
`tra_draw_piece_shadow(ctx, piece, x, y, square, [{rot, flip, shadow}])` and then `tra_draw_piece` with `shadow: 0`),
`tra_draw_case(ctx, cx, cy, puzzle, square)`, `tra_draw_grain(ctx, wood, seed, w, h)`,
`tra_draw_motif(ctx, motif, size, material)`, `tra_draw_verdict(ctx, w, h, puzzle, placed, info)` and the rest of
`tra_draw.gml`, each with `ctx = tra_cx_create(scale)` inside `tra_bake(surface, w, h, scale, painter)`.

## Performance

Everything is baked once into surfaces and drawn scaled every frame. Measured in the suite on a shared Windows machine at
the default quality: the workbench and parts box every table shares bake in 0.9 s the first time a table opens (call `tra_room_prepare()` on a loading screen to move that cost there); a table's first frame - the case, its title and the cards, on the black of its fade-in - costs 1.2 s on the first table of a game, and its pieces are baked a few a frame during the fade (worst fade frame 38 to 47 ms). Without the fade, a table bakes everything on its first frame (594 to 640 ms measured for seven pieces) - use `tra_scene_prepare()` before showing it. In play, a frame that re-bakes nothing costs at most 0.25 to 0.29 ms; lifting or putting down a piece re-bakes only its shadow (17.8 to 24.7 ms for that frame), and a turn or flip re-bakes the piece (46 ms). A hint is searched in 4 ms slices (worst slice 4.1 to 4.6 ms). A hard tray graded fresh by the generator takes 38 to 41 s spread over frames; the book's trays build in under 0.6 ms. Surfaces are volatile in GameMaker, so a lost surface is simply re-baked from the
table's state.

**The surfaces are premultiplied.** `tra_scene_draw` blends them correctly; to draw one of them yourself, use
`tra_draw_pm_surface(surface, x, y, [xscale], [yscale], [alpha])` (or `gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha)`).

## Removing the demo

Delete `obj_tra_demo`, `rm_tra_demo`, `tra_demo`, `tra_selftest`, `tra_oracle` and `tra_oracle_draw`. Nothing else refers
to them. Keep `tra_book`: it is the graded book `tra_puzzle_for` reads.

## Namespacing

Every function and macro is prefixed `tra_` / `TRA_`; the only globals are `global.__tra_book`, `global.__tra_sizes`,
`global.__tra_room` (caches) and `global.tra_stage` (the demo's crash reporter). The fonts are `fnt_tray_bold`,
`fnt_tray_display`, `fnt_tray_italic` and `fnt_tray_text`. Nothing here touches your rooms, layers or objects.

## Fonts

All four faces are Libre Baskerville under the SIL Open Font License 1.1, rasterised into GameMaker atlases under the
names "Tray Serif", "Tray Serif Bold", "Tray Serif Display" and "Tray Serif Italic" (the font's Reserved Font Name stays
with the font). The licence text and notices are in `Tray/fonts/`. You may use them in your game freely.

## Verification

The in-engine suite (43 assertions, all passing on the shipped source in two runs) holds this port to the original RPG Maker MZ plugin, run in Node: its generator's draws, 36 tray masks, the turns of 12 polyominoes, 144 raw carvings (box, pieces, woods, inlays and solution identical), the solver on 48 trays to the NODE (23373 nodes), 9 graded puzzles, the resumable search and the sliced generator node for node (a hard tray included), all 626 rows of the book replayed from their seeds (and 119 re-graded in full), the play rules and hints on 8 trays, and the drawing: the ten woods and four materials, 96 turns with their outlines, insets and poses, 36 tray outlines, and 106 drawn things - every wood, every inlay in every material, 21 pieces turned, flipped, lifted and glowing, the six cases, the parts box, the table, the plates, cards and plaques, and two finished panels - with exactly the original's paths, fills, strokes and rectangles (86581 drawing operations). It renders a sheet of every wood with every inlay (each piece inked against a blank control), the six trays, the room and the finished panel for looking, and drives whole trays through tra_scene_step: by the keyboard, by mouse drags, by hints alone on a hard tray, a hint after a misplaced piece, and leaving early. A fresh import into a blank project runs this Readme's own code (34 checks, all passing), and an adversarial pass makes 140 bad calls into the 35 documented functions with 0 crashes. Two departures from the original are deliberate and keep every compared count: an inlay's cut is offset down and right as its code intended (on a canvas it lands exactly under the inlay), and the finished panel lists the woods with commas (the middle dot is not in the ASCII atlas). The canvas shadows (four of them) are drawn as a gaussian of the canvas's own blur; GameMaker has no shadow.

## AI disclosure

This package was written with AI assistance: the code and the generated graphics. It contains no AI-generated audio.

Core Systems Asset Factory - https://csaf.itch.io
