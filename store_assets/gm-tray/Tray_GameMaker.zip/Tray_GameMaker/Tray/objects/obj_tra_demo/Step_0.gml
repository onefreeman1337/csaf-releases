/// @description The menu, or the table in play (tra_demo_step steps the scene once a frame).
tra_demo_step(demo);
