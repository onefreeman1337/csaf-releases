/// @description Draw GUI: the menu, or the table fitted to the window (the scene reads the mouse in GUI coordinates).
tra_demo_draw(demo);
