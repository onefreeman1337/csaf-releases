/// @description Tray demo - choose a tray shape and a difficulty, deal a puzzle and fit it - and the headless entry point
/// (-selftest).
/// ⛔ The crash handler is installed FIRST, and every variable a later event reads is declared ABOVE the early exits:
/// Clean Up always runs, even when Create leaves early.
exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("tra_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.tra_stage) + ": " + string(_ex.message) + " | " + string(_ex.stacktrace));
    file_text_close(_f);
    game_end();
});
global.tra_stage = 0;
demo = tra_demo_state();
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";
if (string_pos("-selftest", _args) > 0) { global.tra_stage = 1; tra_selftest_write(tra_selftest_run(string_pos("-quick", _args) > 0)); game_end(); exit; }
