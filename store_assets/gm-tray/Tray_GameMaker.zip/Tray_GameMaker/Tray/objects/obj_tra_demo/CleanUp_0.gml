/// @description Free the table's surfaces and the menu's (declared in Create above its early exit, so always present).
if (variable_instance_exists(id, "demo") && is_struct(demo)) tra_demo_free(demo);
