/// tra_bookplay.gml - a graded puzzle at once, from the book (tra_book.gml): the original graded these trays offline with
/// its own generate-and-test and the book stores each accepted tray's layout, so play never re-runs the search (MEASURED at
/// ~44 s for a hard tray on the GameMaker VM) nor the carvings (up to ~1.2 s). tra_book_replay() rebuilds a row the slow
/// way, from its seed, and the suite proves every stored layout is exactly what the replay produces.
///
/// Tray - Generated Packing Puzzles in Wood, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function tra__book_cached(difficulty, shape)
/// @description The book's rows for a pair, built ONCE per game and kept (tra_book_rows returns a fresh literal of every
/// row on each call: MEASURED, rebuilding it per puzzle made the worst build ~48 ms). Internal.
function tra__book_cached(_d, _s) {
    if (!variable_global_exists("__tra_book") || !is_struct(global.__tra_book)) global.__tra_book = {};
    var _k = string(_d) + "_" + string(_s);
    if (!variable_struct_exists(global.__tra_book, _k)) variable_struct_set(global.__tra_book, _k, tra_book_rows(_d, _s));
    return variable_struct_get(global.__tra_book, _k);
}

/// @function tra_book_count(difficulty, shape)
/// @description How many graded puzzles the book holds for a difficulty and shape (0 for an unknown pair).
function tra_book_count(_d, _s) { return array_length(tra__book_cached(_d, _s)); }

/// @function tra__book_row(difficulty, shape, index)
/// @description [row, wrapped index] or undefined. Internal.
function tra__book_row(_d, _s, _i) {
    var _rows = tra__book_cached(_d, _s), _n = array_length(_rows);
    if (_n == 0 || !is_numeric(_i)) return undefined;
    var _k = floor(_i) mod _n;
    if (_k < 0) _k += _n;
    return [_rows[_k], _k];
}

/// @function tra_book_puzzle(difficulty, shape, index)
/// @description Graded puzzle number `index` (wrapped into the book's range) for a difficulty ("easy", "normal", "hard")
/// and shape ("rect", "cross", "diamond", "round", "notched", "arch"): exactly the tray tra_generate({seed, difficulty,
/// shape}) grades and returns - the same struct, with ways, graded and tries from the original's grading - built from the
/// stored layout without any search (the suite records the worst build time). Returns undefined for an unknown pair or a
/// non-numeric index.
function tra_book_puzzle(_d, _s, _i) {
    var _rk = tra__book_row(_d, _s, _i);
    if (is_undefined(_rk)) return undefined;
    var _row = _rk[0], _w = _row[4], _h = _row[5], _m = tra_mask(_s, _w, _h), _pieces = [], _solution = [];
    for (var _j = 0; _j < array_length(_row[7]); _j++) {
        var _L = _row[7][_j], _cells = [];
        for (var _c = 0; _c < array_length(_L[0]); _c++) array_push(_cells, [_L[0][_c][0], _L[0][_c][1]]);
        array_push(_pieces, { id: _j, cells: _cells, wood: _L[1], inlay: _L[2] });
        array_push(_solution, { piece: _j, x: _L[3], y: _L[4], cells: _cells });
    }
    return { v: 1, seed: _row[0], difficulty: _d, shape: _s, w: _w, h: _h, mask: _m, cells: tra_count(_m), pieces: _pieces, solution: _solution,
        ways: _row[2], graded: (_row[3] == 1), tries: _row[1], book: _rk[1] };
}

/// @function tra_book_replay(difficulty, shape, index)
/// @description The same puzzle rebuilt the slow way - the seed's carvings replayed up to the accepted one (tra_generate
/// with a valid difficulty and shape takes no picks before its first carving). For the suite and for anyone who wants
/// to check the book; can take a second on the VM.
function tra_book_replay(_d, _s, _i) {
    var _rk = tra__book_row(_d, _s, _i);
    if (is_undefined(_rk)) return undefined;
    var _row = _rk[0], _seed = _row[0], _tries = _row[1];
    var _r = tra_rng(_seed ^ $7A4), _p = undefined;
    for (var _t = 0; _t < _tries; _t++) _p = tra_candidate(_r, _seed, _d, _s);
    if (is_undefined(_p)) return undefined;
    _p.ways = _row[2]; _p.graded = (_row[3] == 1); _p.tries = _tries; _p.book = _rk[1];
    return _p;
}
