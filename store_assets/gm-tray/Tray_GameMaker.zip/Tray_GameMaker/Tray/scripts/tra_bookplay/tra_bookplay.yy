{
  "$GMScript": "v1",
  "%Name": "tra_bookplay",
  "name": "tra_bookplay",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}