/// tra_puzzle.gml - the generator, the solver and the play rules: a tray of a generated shape carved into polyomino pieces
/// of three to six squares, every piece a different shape allowing for turns and flips, every piece its own wood and
/// inlay; an exact-cover solver that counts the DIFFERENT solutions (a turn or flip of the tray counted once) to grade it;
/// hints; the play state. Pure logic: nothing here draws and nothing uses random().
///
/// Tray - Generated Packing Puzzles in Wood, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⛔ A PORT HELD TO ITS ORIGINAL (the published RPG Maker MZ Tray, TrayCore.js 1.0.0); the suite checks it against values
/// the original computed (tra_oracle.gml). Every random draw is taken in its own statement in JavaScript's order (GML
/// evaluates one expression's calls right to left); every sort has a total order and its comparator returns a SIGN;
/// every entry point runs with the comparison epsilon at ZERO and restores the caller's.

#macro TRA_GRADE_NODES 150000

/// @function tra_shapes()
/// @description The six tray shapes, in the original's order. Pure.
function tra_shapes() { return ["rect", "cross", "diamond", "round", "notched", "arch"]; }
/// @function tra_woods()
function tra_woods() { return ["walnut", "maple", "cherry", "oak", "ebony", "ash", "rosewood", "yew", "olive", "holly"]; }
/// @function tra_inlays()
function tra_inlays() { return ["star", "lozenge", "rosette", "bars", "chevron", "dot", "ring", "cross", "leaf", "wave"]; }
/// @function tra_difficulty_names()
function tra_difficulty_names() { return ["easy", "normal", "hard"]; }

/// @function tra_difficulty(name)
/// @description {name, pieces [lo, hi], area [lo, hi] squares a piece, ways (the most different solutions allowed),
/// tries (carvings generate-and-test looks at)}, or undefined for an unknown name. Set in the original from its grade
/// probe, never guessed. Pure.
function tra_difficulty(_d) {
    if (_d == "easy") return { name: "easy", pieces: [4, 5], area: [3.9, 5.6], ways: 4, tries: 4 };
    if (_d == "normal") return { name: "normal", pieces: [6, 7], area: [4.2, 5.3], ways: 12, tries: 5 };
    if (_d == "hard") return { name: "hard", pieces: [8, 10], area: [4.5, 5.5], ways: 40, tries: 6 };
    return undefined;
}

// ---------------------------------------------------------------------------------------------------------------
// The original's generator (mulberry32), bit for bit
// ---------------------------------------------------------------------------------------------------------------

/// @function tra_rng(seed)
function tra_rng(_seed) { return { a: tra_u32(_seed) }; }
/// @function tra_rnd(rng)
/// @description The next draw in [0, 1) - mulberry32, exactly as the original computes it.
function tra_rnd(_g) {
    _g.a = (_g.a + $6D2B79F5) & $FFFFFFFF;
    var _t = _g.a;
    _t = tra_mul32(_t ^ (_t >> 15), _t | 1);
    var _s = (_t + tra_mul32(_t ^ (_t >> 7), _t | 61)) & $FFFFFFFF;
    _t = (_t ^ _s) & $FFFFFFFF;
    return ((_t ^ (_t >> 14)) & $FFFFFFFF) / 4294967296;
}
/// @function tra_pick(rng, array)
function tra_pick(_g, _a) { var _n = array_length(_a); var _k = floor(tra_rnd(_g) * _n) mod _n; return _a[_k]; }

// ---------------------------------------------------------------------------------------------------------------
// Shapes and pieces
// ---------------------------------------------------------------------------------------------------------------

/// @function tra_mask(shape, w, h)
/// @description The tray's cells as a mask (1 = part of the tray), row-major w x h, for a shape family. Pure.
function tra_mask(_shape, _w, _h) {
    var _eps = math_get_epsilon(); math_set_epsilon(0);
    var _m = array_create(_w * _h, 0), _cx = (_w - 1) / 2, _cy = (_h - 1) / 2;
    for (var _y = 0; _y < _h; _y++) for (var _x = 0; _x < _w; _x++) {
        var _dx = abs(_x - _cx) / (_w / 2), _dy = abs(_y - _cy) / (_h / 2), _v = 1;
        if (_shape == "cross") _v = (_dx < 0.45 || _dy < 0.45) ? 1 : 0;
        else if (_shape == "diamond") _v = (_dx + _dy <= 1.05) ? 1 : 0;
        else if (_shape == "round") _v = (_dx * _dx + _dy * _dy <= 1.05) ? 1 : 0;
        else if (_shape == "notched") _v = ((_x == 0 || _x == _w - 1) && (_y == 0 || _y == _h - 1)) ? 0 : 1;
        else if (_shape == "arch") _v = (_y < _h / 2 && _dx * _dx + (_cy - _y) * (_cy - _y) / (_h * _h / 4) > 1.0) ? 0 : 1;
        _m[_y * _w + _x] = _v;
    }
    math_set_epsilon(_eps);
    return _m;
}
/// @function tra_count(mask)
function tra_count(_m) { var _n = 0; for (var _i = 0; _i < array_length(_m); _i++) _n += _m[_i]; return _n; }

/// @function tra__cmp_yx(a, b)
/// @description Row then column, as a SIGN. Internal.
function tra__cmp_yx(_a, _b) { if (_a[1] != _b[1]) return (_a[1] < _b[1]) ? -1 : 1; if (_a[0] != _b[0]) return (_a[0] < _b[0]) ? -1 : 1; return 0; }

/// @function tra__key(cells)
/// @description "x,y;x,y;..." of a normalised cell list. Internal.
function tra__key(_pts) {
    var _s = "";
    for (var _k = 0; _k < array_length(_pts); _k++) _s += ((_k > 0) ? ";" : "") + string(round(_pts[_k][0])) + "," + string(round(_pts[_k][1]));
    return _s;
}

/// @function tra_orientations(cells)
/// @description The distinct turns and flips of a polyomino ([[x, y], ...]), each normalised to its top-left and sorted
/// by row then column, in the original's order (first seen kept). Pure.
function tra_orientations(_cells) {
    var _out = [], _seen = {};
    for (var _t = 0; _t < 8; _t++) {
        var _pts = [], _k;
        for (_k = 0; _k < array_length(_cells); _k++) {
            var _x = _cells[_k][0], _y = _cells[_k][1], _nx, _ny;
            switch (_t & 3) { case 0: _nx = _x; _ny = _y; break; case 1: _nx = -_y; _ny = _x; break; case 2: _nx = -_x; _ny = -_y; break; default: _nx = _y; _ny = -_x; }
            if ((_t & 4) != 0) _nx = -_nx;
            array_push(_pts, [_nx, _ny]);
        }
        var _mx = 1000000, _my = 1000000;
        for (_k = 0; _k < array_length(_pts); _k++) { _mx = min(_mx, _pts[_k][0]); _my = min(_my, _pts[_k][1]); }
        for (_k = 0; _k < array_length(_pts); _k++) _pts[_k] = [_pts[_k][0] - _mx + 0, _pts[_k][1] - _my + 0];
        array_sort(_pts, tra__cmp_yx);
        var _key = tra__key(_pts);
        if (!variable_struct_exists(_seen, _key)) { variable_struct_set(_seen, _key, 1); array_push(_out, _pts); }
    }
    return _out;
}

/// @function tra_canon(cells)
/// @description A shape's canonical key: one spelling chosen from its orientations (the same key means the same piece,
/// turned or flipped). ⚠️ The original takes the smallest JavaScript string; only EQUALITY of keys is ever used, so the
/// alphabetically first by GameMaker's own sort gives identical carvings. Pure.
function tra_canon(_cells) {
    var _o = tra_orientations(_cells), _keys = [];
    for (var _i = 0; _i < array_length(_o); _i++) array_push(_keys, tra__key(_o[_i]));
    array_sort(_keys, true);
    return _keys[0];
}

/// @function tra_carve(mask, w, h, k, rng)
/// @description Carve the mask into k connected pieces of 3..6 cells, all different shapes: seeds spread farthest-first,
/// then the smallest region that can grow takes one random free neighbour, until the tray is full. Returns an array of
/// cell-index lists, or undefined on failure. Advances the generator exactly as the original does.
function tra_carve(_m, _w, _h, _k, _r) {
    var _n = array_length(_m), _owner = array_create(_n, -2), _cells = [], _i;
    for (_i = 0; _i < _n; _i++) { _owner[_i] = (_m[_i] != 0) ? -1 : -2; if (_m[_i] != 0) array_push(_cells, _i); }
    var _total = array_length(_cells);
    if (_total < _k * 3 || _total > _k * 6) return undefined;
    var _seeds = [tra_pick(_r, _cells)];
    while (array_length(_seeds) < _k) {
        var _bestI = -1, _bestD = -1;
        for (_i = 0; _i < array_length(_cells); _i++) {
            var _c = _cells[_i], _dmin = 1000000000;
            for (var _s = 0; _s < array_length(_seeds); _s++) {
                var _d = abs((_c mod _w) - (_seeds[_s] mod _w)) + abs(floor(_c / _w) - floor(_seeds[_s] / _w));
                if (_d < _dmin) _dmin = _d;
            }
            _dmin += tra_rnd(_r) * 0.5;
            if (_dmin > _bestD) { _bestD = _dmin; _bestI = _c; }
        }
        array_push(_seeds, _bestI);
    }
    var _regions = [];
    for (var _j0 = 0; _j0 < array_length(_seeds); _j0++) { _owner[_seeds[_j0]] = _j0; array_push(_regions, [_seeds[_j0]]); }
    var _left = _total - _k, _guard = 0, _dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]];
    while (_left > 0 && _guard < 10000) {
        _guard++;
        // one draw per region, taken BEFORE sorting (the original's fix: a draw inside a comparator depends on the engine)
        var _tie = array_create(array_length(_regions), 0);
        for (var _tj = 0; _tj < array_length(_regions); _tj++) _tie[_tj] = tra_rnd(_r);
        var _order = [];
        for (var _oj = 0; _oj < array_length(_regions); _oj++) array_push(_order, [_oj, array_length(_regions[_oj]), _tie[_oj]]);
        array_sort(_order, function(_a, _b) { if (_a[1] != _b[1]) return (_a[1] < _b[1]) ? -1 : 1; if (_a[2] != _b[2]) return (_a[2] < _b[2]) ? -1 : 1; return 0; });
        var _grew = false;
        for (var _oi = 0; _oi < array_length(_order) && !_grew; _oi++) {
            var _jj = _order[_oi][0];
            if (array_length(_regions[_jj]) >= 6) continue;
            var _front = [];
            for (var _q = 0; _q < array_length(_regions[_jj]); _q++) {
                var _cc = _regions[_jj][_q], _x = _cc mod _w, _y = floor(_cc / _w);
                for (var _dd = 0; _dd < 4; _dd++) {
                    var _nx = _x + _dirs[_dd][0], _ny = _y + _dirs[_dd][1];
                    if (_nx >= 0 && _ny >= 0 && _nx < _w && _ny < _h) {
                        var _idx = _ny * _w + _nx;
                        if (_owner[_idx] == -1 && !tra__in(_front, _idx)) array_push(_front, _idx);
                    }
                }
            }
            if (array_length(_front) > 0) {
                var _pc = tra_pick(_r, _front);
                _owner[_pc] = _jj;
                var _reg = _regions[_jj]; array_push(_reg, _pc); _regions[_jj] = _reg;
                _left--; _grew = true;
            }
        }
        if (!_grew) return undefined;
    }
    if (_left > 0) return undefined;
    var _keys = {};
    for (_i = 0; _i < array_length(_regions); _i++) {
        var _rg = _regions[_i];
        if (array_length(_rg) < 3 || array_length(_rg) > 6) return undefined;
        var _pts = [];
        for (var _p = 0; _p < array_length(_rg); _p++) array_push(_pts, [_rg[_p] mod _w, floor(_rg[_p] / _w)]);
        var _key = tra_canon(_pts);
        if (variable_struct_exists(_keys, _key)) return undefined;
        variable_struct_set(_keys, _key, 1);
    }
    return _regions;
}

/// @function tra__in(array, value)
function tra__in(_a, _v) { for (var _i = 0; _i < array_length(_a); _i++) if (_a[_i] == _v) return true; return false; }

/// @function tra_symmetries(mask, w, h)
/// @description Every turn or flip of the w x h box that maps the mask onto itself, each a cell permutation (perm[i] =
/// where cell i goes); always contains the identity. Quarter turns need a square box. Pure.
function tra_symmetries(_m, _w, _h) {
    var _out = [];
    for (var _t = 0; _t < 8; _t++) {
        if ((_t == 1 || _t == 3 || _t == 5 || _t == 7) && _w != _h) continue;
        var _perm = array_create(array_length(_m), 0), _ok = true;
        for (var _i = 0; _i < array_length(_m) && _ok; _i++) {
            var _x = _i mod _w, _y = floor(_i / _w), _nx, _ny;
            switch (_t & 3) { case 0: _nx = _x; _ny = _y; break; case 1: _nx = _w - 1 - _y; _ny = _x; break; case 2: _nx = _w - 1 - _x; _ny = _h - 1 - _y; break; default: _nx = _y; _ny = _h - 1 - _x; }
            if ((_t & 4) != 0) _nx = _w - 1 - _nx;
            var _j = _ny * _w + _nx;
            if (_m[_j] != _m[_i]) _ok = false;
            _perm[_i] = _j;
        }
        if (_ok) array_push(_out, _perm);
    }
    return _out;
}

// ---------------------------------------------------------------------------------------------------------------
// The solver
// ---------------------------------------------------------------------------------------------------------------

/// @function tra_solve(mask, w, h, pieces, [options])
/// @description Exact cover by backtracking on the first empty cell, counting DIFFERENT solutions (two fillings that are
/// the same picture turned or flipped count once). options {cap (stop after this many, default 50), nodeCap (search
/// budget, default 400000), fixed (a grid: -1 empty, -2 outside, >= 0 a placed piece, kept), keep (collect the first
/// solution's placements)}. Returns {solutions, raw, complete, nodes, first, symmetries}. Runs to the end in one call:
/// for a hard tray that can be SECONDS on the VM (MEASURED ~54 us a node) - use tra_solve_begin / tra_solve_step to spread
/// it over frames. Both are ONE search (this calls them), so they cannot disagree.
function tra_solve(_m, _w, _h, _pieces, _o = undefined) {
    if (!is_array(_m) || !is_numeric(_w) || !is_numeric(_h) || !is_array(_pieces) || _w < 1 || _h < 1 || array_length(_m) != _w * _h) return { solutions: 0, raw: 0, complete: false, nodes: 0, first: undefined, symmetries: 0 };
    var S = tra_solve_begin(_m, _w, _h, _pieces, _o);
    while (!tra_solve_step(S, 1000000000, 1000000000)) { }
    return tra_solve_result(S);
}

/// @function tra_solve_begin(mask, w, h, pieces, [options])
/// @description A resumable search (the same options as tra_solve). Advance it with tra_solve_step; read it with
/// tra_solve_result once a step returns true.
function tra_solve_begin(_m, _w, _h, _pieces, _o = undefined) {
    if (!is_struct(_o)) _o = {};
    var _gv = function(_s, _k, _d) { return variable_struct_exists(_s, _k) ? variable_struct_get(_s, _k) : _d; };
    var _n = array_length(_m), _fixed = _gv(_o, "fixed", undefined);
    var S = { n: _n, w: _w, h: _h, cap: _gv(_o, "cap", 50), nodeCap: _gv(_o, "nodeCap", 400000), keep: _gv(_o, "keep", false) == true,
        grid: array_create(_n, 0), who: array_create(_n, -2), used: array_create(array_length(_pieces), false),
        syms: tra_symmetries(_m, _w, _h), seen: {}, sols: 0, raw: 0, nodes: 0, stop: false, stack: [], first: undefined, orients: [], np: array_length(_pieces),
        frames: [], mode: 0, done: false, slices: 0 };
    if (!is_numeric(S.cap) || !(S.cap > 0)) S.cap = 50;
    if (!is_numeric(S.nodeCap) || !(S.nodeCap > 0)) S.nodeCap = 400000;
    for (var _i = 0; _i < _n; _i++) {
        var _f0 = is_array(_fixed) ? _fixed[_i] : ((_m[_i] != 0) ? -1 : -2);
        S.grid[_i] = (_f0 == -1) ? 0 : 1; S.who[_i] = _f0;
    }
    if (is_array(_fixed)) for (var _u = 0; _u < _n; _u++) if (_fixed[_u] >= 0 && _fixed[_u] < S.np) S.used[_fixed[_u]] = true;
    for (var _p = 0; _p < array_length(_pieces); _p++) array_push(S.orients, tra_orientations(_pieces[_p].cells));
    return S;
}

/// @function tra_solve_result(search)
/// @description {solutions, raw, complete, nodes, first, symmetries} of a search (final once tra_solve_step returned true).
function tra_solve_result(S) {
    return { solutions: S.sols, raw: S.raw, complete: (!S.stop) || (S.sols >= S.cap), nodes: S.nodes, first: S.first, symmetries: array_length(S.syms) };
}

/// @function tra_solve_step(search, max_nodes, max_ms)
/// @description Advance a search by at most max_nodes search nodes or max_ms milliseconds (checked after each node), in
/// exactly the order of the original's recursive search - an explicit stack of frames instead of the call stack, so it
/// can stop between any two nodes and resume. Returns true when the search is finished.
function tra_solve_step(S, _maxNodes, _maxMs) {
    if (S.done) return true;
    var _eps = math_get_epsilon(); math_set_epsilon(0);
    var _t0 = get_timer(), _budget = S.nodes + max(1, _maxNodes), _lim = max(0.001, _maxMs) * 1000;
    var _w = S.w, _h = S.h, _n = S.n;
    S.slices++;
    while (!S.done) {
        if (S.mode == 0) {   // ENTER a node (the original's rec())
            if (S.stop) { S.mode = 2; continue; }
            S.nodes++;
            if (S.nodes > S.nodeCap) { S.stop = true; S.mode = 2; continue; }
            var _f = -1;
            for (var _q = 0; _q < _n; _q++) if (S.grid[_q] == 0) { _f = _q; break; }
            if (_f < 0) { tra__solve_leaf(S); S.mode = 2; }
            else { array_push(S.frames, { fx: _f mod _w, fy: floor(_f / _w), pi: 0, oi: -1, placed: false, ax: 0, ay: 0, cells: undefined }); S.mode = 1; }
            if (S.nodes >= _budget || get_timer() - _t0 >= _lim) break;
            continue;
        }
        if (S.mode == 1) {   // ADVANCE the top frame to its next placement
            var _fr = S.frames[array_length(S.frames) - 1];
            if (_fr.placed) {
                array_pop(S.stack);
                S.used[_fr.pi] = false;
                for (var _c0 = 0; _c0 < array_length(_fr.cells); _c0++) { var _cj = (_fr.ay + _fr.cells[_c0][1]) * _w + _fr.ax + _fr.cells[_c0][0]; S.grid[_cj] = 0; S.who[_cj] = -1; }
                _fr.placed = false;
                if (S.stop) { array_pop(S.frames); S.mode = 2; continue; }
            }
            var _pi = _fr.pi, _oi = _fr.oi + 1, _found = false, _ax = 0, _ay = 0, _or = undefined;
            while (_pi < S.np && !_found) {
                if (S.used[_pi]) { _pi++; _oi = 0; continue; }
                var _os = S.orients[_pi];
                while (_oi < array_length(_os)) {
                    _or = _os[_oi]; _ax = _fr.fx - _or[0][0]; _ay = _fr.fy - _or[0][1];
                    var _ok = true;
                    for (var _c = 0; _c < array_length(_or) && _ok; _c++) {
                        var _x = _ax + _or[_c][0], _y = _ay + _or[_c][1];
                        if (_x < 0 || _y < 0 || _x >= _w || _y >= _h || S.grid[_y * _w + _x] != 0) _ok = false;
                    }
                    if (_ok) { _found = true; break; }
                    _oi++;
                }
                if (!_found) { _pi++; _oi = 0; }
            }
            if (!_found) { array_pop(S.frames); S.mode = 2; continue; }
            for (var _c1 = 0; _c1 < array_length(_or); _c1++) { var _ci = (_ay + _or[_c1][1]) * _w + _ax + _or[_c1][0]; S.grid[_ci] = 1; S.who[_ci] = _pi; }
            S.used[_pi] = true;
            array_push(S.stack, { piece: _pi, x: _ax, y: _ay, cells: _or });
            _fr.pi = _pi; _fr.oi = _oi; _fr.ax = _ax; _fr.ay = _ay; _fr.cells = _or; _fr.placed = true;
            S.mode = 0;
            continue;
        }
        // RETURN to the parent frame
        if (array_length(S.frames) == 0) { S.done = true; break; }
        S.mode = 1;
    }
    math_set_epsilon(_eps);
    return S.done;
}

/// @function tra__solve_leaf(S)
/// @description A full tray: count it once per symmetry class, keep the first solution's placements if asked. Internal.
function tra__solve_leaf(S) {
    S.raw++;
    var _key = tra__solve_key(S);
    if (variable_struct_exists(S.seen, _key)) return;
    variable_struct_set(S.seen, _key, 1);
    S.sols++;
    if (S.keep && is_undefined(S.first)) {
        var _fs = [];
        for (var _a = 0; _a < array_length(S.stack); _a++) { var _st = S.stack[_a], _cc = []; for (var _b = 0; _b < array_length(_st.cells); _b++) array_push(_cc, [_st.cells[_b][0], _st.cells[_b][1]]); array_push(_fs, { piece: _st.piece, x: _st.x, y: _st.y, cells: _cc }); }
        S.first = _fs;
    }
    if (S.sols >= S.cap) S.stop = true;
}

/// @function tra__solve_key(S)
/// @description The filled grid spelled under every symmetry; the alphabetically first (only equality is used). Internal.
function tra__solve_key(S) {
    var _keys = [];
    for (var _s = 0; _s < array_length(S.syms); _s++) {
        var _arr = array_create(S.n, 0), _sy = S.syms[_s];
        for (var _q = 0; _q < S.n; _q++) _arr[_sy[_q]] = S.who[_q];
        var _k = "";
        for (var _z = 0; _z < S.n; _z++) _k += ((_z > 0) ? "," : "") + string(_arr[_z]);
        array_push(_keys, _k);
    }
    array_sort(_keys, true);
    return _keys[0];
}

// ---------------------------------------------------------------------------------------------------------------
// The generator
// ---------------------------------------------------------------------------------------------------------------

/// @function tra_sizes_for(shape, lo, hi)
/// @description Box sizes [w, h, cells] (4 <= w <= 10, 3 <= h <= min(w, 7), w <= 1.8 h) whose tray of this shape holds
/// between lo and hi cells. Cached per shape. Pure.
function tra_sizes_for(_shape, _lo, _hi) {
    if (!variable_global_exists("__tra_sizes") || !is_struct(global.__tra_sizes)) global.__tra_sizes = {};
    var _t;
    if (variable_struct_exists(global.__tra_sizes, _shape)) _t = variable_struct_get(global.__tra_sizes, _shape);
    else {
        _t = [];
        var _eps = math_get_epsilon(); math_set_epsilon(0);
        for (var _w = 4; _w <= 10; _w++) for (var _h = 3; _h <= min(_w, 7); _h++) if (_w <= _h * 1.8) array_push(_t, [_w, _h, tra_count(tra_mask(_shape, _w, _h))]);
        math_set_epsilon(_eps);
        variable_struct_set(global.__tra_sizes, _shape, _t);
    }
    var _out = [];
    for (var _i = 0; _i < array_length(_t); _i++) if (_t[_i][2] >= _lo && _t[_i][2] <= _hi) array_push(_out, _t[_i]);
    return _out;
}

/// @function tra_candidate(rng, seed, difficulty, shape)
/// @description One carved tray, ungraded, or undefined if 400 carvings all failed: {v, seed, difficulty, shape, w, h,
/// mask, cells, pieces [{id, cells, wood, inlay}], solution [{piece, x, y, cells}], ways -1, graded false}.
function tra_candidate(_r, _seed, _diff, _shape) {
    var _D = tra_difficulty(_diff), _attempt = 0;
    var _eps = math_get_epsilon(); math_set_epsilon(0);
    while (_attempt < 400) {
        _attempt++;
        var _k = _D.pieces[0] + floor(tra_rnd(_r) * (_D.pieces[1] - _D.pieces[0] + 1));
        var _fit = tra_sizes_for(_shape, ceil(_k * _D.area[0]), floor(_k * _D.area[1]));
        if (array_length(_fit) == 0) continue;
        var _sz = tra_pick(_r, _fit), _w = _sz[0], _h = _sz[1], _m = tra_mask(_shape, _w, _h);
        math_set_epsilon(0);
        var _regions = tra_carve(_m, _w, _h, _k, _r);
        if (is_undefined(_regions)) continue;
        var _woods = tra_woods(), _inlays = tra_inlays(), _pieces = [], _solution = [], _W0 = tra_woods(), _I0 = tra_inlays();
        for (var _i = 0; _i < array_length(_regions); _i++) {
            var _pts = [], _mx = 1000000, _my = 1000000;
            for (var _q = 0; _q < array_length(_regions[_i]); _q++) { var _c = _regions[_i][_q]; array_push(_pts, [_c mod _w, floor(_c / _w)]); }
            for (var _q2 = 0; _q2 < array_length(_pts); _q2++) { _mx = min(_mx, _pts[_q2][0]); _my = min(_my, _pts[_q2][1]); }
            var _norm = [];
            for (var _q3 = 0; _q3 < array_length(_pts); _q3++) array_push(_norm, [_pts[_q3][0] - _mx, _pts[_q3][1] - _my]);
            array_sort(_norm, tra__cmp_yx);
            var _wi = floor(tra_rnd(_r) * array_length(_woods)) mod array_length(_woods);
            var _ii = floor(tra_rnd(_r) * array_length(_inlays)) mod array_length(_inlays);
            var _wood = _woods[_wi]; array_delete(_woods, _wi, 1);
            var _inl = _inlays[_ii]; array_delete(_inlays, _ii, 1);
            if (is_undefined(_wood)) _wood = _W0[_i mod 10];
            if (is_undefined(_inl)) _inl = _I0[_i mod 10];
            array_push(_pieces, { id: _i, cells: _norm, wood: _wood, inlay: _inl });
            array_push(_solution, { piece: _i, x: _mx, y: _my, cells: _norm });
        }
        math_set_epsilon(_eps);
        return { v: 1, seed: _seed, difficulty: _diff, shape: _shape, w: _w, h: _h, mask: _m, cells: tra_count(_m), pieces: _pieces, solution: _solution, ways: -1, graded: false, tries: 0 };
    }
    math_set_epsilon(_eps);
    return undefined;
}

/// @function tra_generate(options)
/// @description A packing puzzle from {seed, [difficulty], [shape], [raw]}, graded by generate-and-test: carve up to the
/// difficulty's tries and keep the first whose different solutions are at most its ways (or, if none is, the tightest
/// proven one). raw: the first carving, ungraded. The same options give the same tray forever. Returns the puzzle struct
/// (see tra_candidate; ways and graded filled in), or undefined if no carving succeeded.
function tra_generate(_opt) {
    if (!is_struct(_opt)) return undefined;
    var _job = tra_generate_begin(_opt);
    while (!tra_generate_step(_job, 1000000000)) { }
    return _job.result;
}

/// @function tra_generate_begin(options)
/// @description A resumable tra_generate (the same options): the carvings and the grading spread over frames with
/// tra_generate_step, so a hard tray never freezes the game (MEASURED: one hard carving's grade ~3.7 s on the VM). The
/// same options give exactly the tray tra_generate gives - it is the same job. Read job.result when a step returns true.
function tra_generate_begin(_opt) {
    if (!is_struct(_opt)) return { done: true, result: undefined, steps: 0, worstMs: 0 };
    if (!is_struct(_opt)) _opt = {};
    var _gv = function(_s, _k, _d) { return variable_struct_exists(_s, _k) ? variable_struct_get(_s, _k) : _d; };
    var _sv = _gv(_opt, "seed", 0);
    var _seed = tra_u32(is_numeric(_sv) ? _sv : 0);
    var _r = tra_rng(_seed ^ $7A4);
    var _dIn = _gv(_opt, "difficulty", undefined);
    var _diff = (is_string(_dIn) && !is_undefined(tra_difficulty(_dIn))) ? _dIn : tra_pick(_r, tra_difficulty_names());
    var _sIn = _gv(_opt, "shape", undefined), _shapes = tra_shapes(), _valid = false;
    for (var _z = 0; _z < 6; _z++) if (is_string(_sIn) && _shapes[_z] == _sIn) _valid = true;
    var _shape = _valid ? _sIn : tra_pick(_r, _shapes);
    return { r: _r, seed: _seed, diff: _diff, D: tra_difficulty(_diff), shape: _shape, raw: (_gv(_opt, "raw", false) == true),
        t: 0, best: undefined, p: undefined, search: undefined, done: false, result: undefined, steps: 0, worstMs: 0 };
}

/// @function tra_generate_step(job, max_ms)
/// @description Advance a generation job for about max_ms milliseconds (one carving is the smallest indivisible step; the
/// grading search stops between any two nodes). Returns true when job.result is final (undefined only if every carving
/// failed). Records the job's longest step in job.worstMs.
function tra_generate_step(_job, _maxMs) {
    if (!is_struct(_job)) return true;
    if (_job.done) return true;
    var _t0 = get_timer(), _lim = max(0.001, is_numeric(_maxMs) ? _maxMs : 4) * 1000;
    _job.steps++;
    while (!_job.done) {
        if (is_undefined(_job.search)) {
            if (_job.t >= (_job.raw ? 1 : _job.D.tries)) {
                if (!is_undefined(_job.best)) _job.best.tries = _job.D.tries;
                _job.result = _job.best; _job.done = true; break;
            }
            var _p = tra_candidate(_job.r, _job.seed, _job.diff, _job.shape);
            if (is_undefined(_p)) { _job.t++; continue; }
            if (_job.raw) { _job.result = _p; _job.done = true; break; }
            _job.p = _p;
            _job.search = tra_solve_begin(_p.mask, _p.w, _p.h, _p.pieces, { cap: _job.D.ways + 1, nodeCap: TRA_GRADE_NODES });
        } else {
            var _left = _lim - (get_timer() - _t0);
            if (_left <= 0) break;
            if (!tra_solve_step(_job.search, 1000000000, _left / 1000)) break;
            var _g = tra_solve_result(_job.search), _q = _job.p;
            _q.ways = _g.solutions; _q.graded = _g.complete; _q.tries = _job.t + 1;
            _job.search = undefined; _job.p = undefined;
            if (_g.complete && _g.solutions <= _job.D.ways) { _job.result = _q; _job.done = true; break; }
            if (is_undefined(_job.best) || (_q.graded && (!_job.best.graded || _q.ways < _job.best.ways))) _job.best = _q;
            _job.t++;
        }
        if (get_timer() - _t0 >= _lim) break;
    }
    _job.worstMs = max(_job.worstMs, (get_timer() - _t0) / 1000);
    return _job.done;
}
