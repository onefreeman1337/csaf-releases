/// tra_demo.gml - the runnable demo: choose a tray shape and a difficulty, deal a puzzle and fit it, and see the trays you
/// have filled listed with their moves and hints. Each deal is a new puzzle from the book. Delete this file and the demo
/// object/room when you wire Tray into your own game; nothing else depends on it.
///
/// Tray - Generated Packing Puzzles in Wood, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function tra_demo_state()
/// @description The demo's state: the shape and difficulty chosen, the deal counter, the table in play, the record.
function tra_demo_state() {
    return { shape: 0, diff: 0, deal: 0, scene: undefined, record: [], bg: undefined, preview: undefined, previewKey: "", hover: -1 };
}

/// @function tra_demo_free(demo)
function tra_demo_free(_d) {
    if (is_struct(_d.scene)) tra_scene_free(_d.scene);
    if (!is_undefined(_d.bg) && surface_exists(_d.bg)) surface_free(_d.bg);
    if (!is_undefined(_d.preview) && surface_exists(_d.preview)) surface_free(_d.preview);
}

/// @function tra_demo_a(word)
/// @description "A word" or "An word" (a vowel sound by its first letter).
function tra_demo_a(_w) { return ((string_pos(string_lower(string_char_at(_w, 1)), "aeiou") > 0) ? "An " : "A ") + _w; }

/// @function tra_demo_layout()
function tra_demo_layout() {
    var _W = display_get_gui_width(), _H = display_get_gui_height();
    return { W: _W, H: _H, listX: 64, listY: 170, listW: 300, rowH: 46, goX: _W - 400, goY: _H - 190 };
}

/// @function tra_demo_step(demo)
function tra_demo_step(_d) {
    if (is_struct(_d.scene)) {
        tra_scene_step(_d.scene);
        if (tra_scene_done(_d.scene)) {
            var _r = tra_scene_result(_d.scene);
            if (is_struct(_r)) {
                array_insert(_d.record, 0, _r);
                if (array_length(_d.record) > 6) array_delete(_d.record, 6, 1);
            }
            tra_scene_free(_d.scene);
            _d.scene = undefined;
        }
        return;
    }
    var _shapes = tra_shapes(), _diffs = tra_difficulty_names(), _L = tra_demo_layout();
    if (keyboard_check_pressed(vk_up)) _d.shape = (_d.shape + 5) mod 6;
    if (keyboard_check_pressed(vk_down)) _d.shape = (_d.shape + 1) mod 6;
    if (keyboard_check_pressed(vk_left)) _d.diff = max(0, _d.diff - 1);
    if (keyboard_check_pressed(vk_right)) _d.diff = min(2, _d.diff + 1);
    var _mx = device_mouse_x_to_gui(0), _my = device_mouse_y_to_gui(0), _row = floor((_my - _L.listY) / _L.rowH);
    if (mouse_check_button_pressed(mb_left) && _mx >= _L.listX && _mx < _L.listX + _L.listW && _row >= 0 && _row < 6) _d.shape = _row;
    var _go = mouse_check_button_pressed(mb_left) && _mx > _L.goX && _mx < _L.goX + 320 && _my > _L.goY && _my < _L.goY + 60;
    if (keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space) || _go) {
        var _p = tra_puzzle_for(1000 + _d.deal * 7 + _d.shape * 101 + _d.diff * 1009, _diffs[_d.diff], _shapes[_d.shape]);
        _d.deal++;
        if (is_struct(_p)) _d.scene = tra_scene_create(_p, { hints: 3 });
    }
}

/// @function tra_demo_draw(demo)
function tra_demo_draw(_d) {
    var _L = tra_demo_layout();
    if (is_struct(_d.scene)) { draw_clear(c_black); tra_scene_draw(_d.scene, 0, 0, _L.W, _L.H); return; }
    var _shapes = tra_shapes(), _diffs = tra_difficulty_names();
    // the workbench behind the menu, dimmed
    if (is_undefined(_d.bg) || !surface_exists(_d.bg)) _d.bg = tra_bake(_d.bg, 816, 624, 1, function(_c) { tra_draw_table(_c, 816, 624); });
    var _k = max(_L.W / 816, _L.H / 624);
    draw_clear(c_black);
    tra_draw_pm_surface(_d.bg, (_L.W - 816 * _k) / 2, (_L.H - 624 * _k) / 2, _k, _k, 1);
    var _a0 = draw_get_alpha();
    draw_set_alpha(0.55); draw_set_colour(c_black); draw_rectangle(0, 0, _L.W, _L.H, false); draw_set_alpha(_a0); draw_set_colour(c_white);
    var _cream = make_colour_rgb(241, 223, 180), _dim = make_colour_rgb(190, 170, 140), _gold = make_colour_rgb(232, 184, 80);
    tra_text(64, 40, "TRAY", 72, _cream, fa_left, fa_top, fnt_tray_display);
    tra_text(68, 120, "Generated packing puzzles in inlaid wood. Every tray can be filled.", 24, _dim, fa_left, fa_top, fnt_tray_italic);
    for (var _i = 0; _i < 6; _i++) {
        var _y = _L.listY + _i * _L.rowH, _on = (_i == _d.shape);
        if (_on) { draw_set_alpha(0.35); draw_set_colour(_gold); draw_rectangle(_L.listX - 12, _y, _L.listX + _L.listW, _y + _L.rowH - 6, false); draw_set_alpha(_a0); draw_set_colour(c_white); }
        tra_text(_L.listX, _y + _L.rowH / 2 - 3, tra_demo_a(_shapes[_i]) + " tray", 28, _on ? _cream : _dim, fa_left, fa_middle, fnt_tray_bold);
    }
    // the chosen shape, as an empty case (baked when the choice changes)
    var _key = _shapes[_d.shape] + "|" + _diffs[_d.diff];
    if (_key != _d.previewKey || is_undefined(_d.preview) || !surface_exists(_d.preview)) {
        _d.previewKey = _key;
        var _p = tra_puzzle_for(1000 + _d.deal * 7 + _d.shape * 101 + _d.diff * 1009, _diffs[_d.diff], _shapes[_d.shape]);
        _d.preview = tra_bake(_d.preview, 420, 330, 2, method({ p: _p }, function(_c) { var _s = min(floor(360 / (p.w + 1.3)), floor(270 / (p.h + 1.3)), 46); tra_draw_case(_c, 210, 165, p, _s); }));
    }
    var _px = (_L.listX + _L.listW + _L.W) / 2;
    tra_draw_pm_surface(_d.preview, _px - 210, 150, 0.5, 0.5, 1);
    tra_text(_px, _L.goY - 40, "<  " + _diffs[_d.diff] + "  >", 28, _cream, fa_center, fa_middle, fnt_tray_italic);
    draw_set_colour(_gold); draw_roundrect(_L.goX, _L.goY, _L.goX + 320, _L.goY + 60, false); draw_set_colour(c_white);
    tra_text(_L.goX + 160, _L.goY + 30, "Deal a tray", 32, make_colour_rgb(58, 36, 8), fa_center, fa_middle, fnt_tray_bold);
    // the record
    var _ry = _L.listY + 6 * _L.rowH + 30;
    tra_text(_L.listX, _ry, (array_length(_d.record) > 0) ? "Trays you have filled" : "The trays you fill are listed here.", 24, _dim, fa_left, fa_top, fnt_tray_italic);
    for (var _r = 0; _r < array_length(_d.record); _r++) {
        var _e = _d.record[_r];
        var _line = tra_demo_a(_e.difficulty) + " " + _e.shape + " tray of " + string(_e.pieces) + ": " + string(_e.moves) + " moves, " + string(_e.hints) + " hints" + ((_e.ways >= 1) ? " (it fills " + string(_e.ways) + ((_e.ways == 1) ? " way)" : " ways)") : "");
        tra_text(_L.listX, _ry + 38 + _r * 32, _line, 22, _cream, fa_left, fa_top, fnt_tray_text);
    }
    tra_text(64, _L.H - 34, "Up/Down: shape - Left/Right: difficulty - Enter: deal. At the table: Left/Right choose, Enter lifts, arrows move, Q/W turn, Shift flips, Tab hints, Esc leaves; or drag with the mouse.", 18, _dim, fa_left, fa_middle, fnt_tray_italic);
}
