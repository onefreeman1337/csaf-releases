/// tra_bake.gml - the bakes: every Tray picture is drawn ONCE into a surface (supersampled, premultiplied alpha) and then
/// drawn scaled: the room (table, case, parts box, title) when a puzzle opens, each piece when it is turned or flipped,
/// the cards when what they show changes.
///
/// Tray - Generated Packing Puzzles in Wood, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⛔ Four GameMaker facts decide this file (Doctrine_Craft s13-s19, all MEASURED in sibling products):
///   1. a translucent mark drawn onto a surface lowers its ALPHA under the default blend, so every bake blends alpha as
///      "over" (src + dest x (1 - src)); a surface baked that way holds PREMULTIPLIED colour and is drawn out with
///      bm_one, bm_inv_src_alpha (tra_draw_pm);
///   2. a bake inside the buyer's draw inherits their world matrix: every bake runs under IDENTITY and hands the
///      caller's matrix back;
///   3. surface_set_target resets the scissor; nothing here leaves a scissor set;
///   4. surfaces are VOLATILE (lost on a window resize or a device reset): every surface is checked before it is drawn
///      and re-baked from the model, which is the source of truth.

#macro TRA_SS 2

/// @function tra__bake_begin(surface)
/// @description Make a surface the target, cleared to transparent, under identity, blending alpha as "over". Returns the
/// caller's world matrix (hand it to tra__bake_end). Internal.
function tra__bake_begin(_sf) {
    var _m = matrix_get(matrix_world);
    surface_set_target(_sf);
    draw_clear_alpha(c_black, 0);
    gpu_push_state();
    matrix_set(matrix_world, matrix_build_identity());
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false);
    gpu_set_alphatestenable(false);
    return _m;
}

/// @function tra__bake_end(matrix)
/// @description Undo tra__bake_begin. Internal.
function tra__bake_end(_m) {
    gpu_pop_state();
    surface_reset_target();
    matrix_set(matrix_world, _m);
}

/// @function tra__surface(old, w, h)
/// @description A surface of exactly w x h: the old one if it still exists at that size, else a new one (the old freed).
/// Internal.
function tra__surface(_old, _w, _h) {
    _w = max(1, ceil(_w)); _h = max(1, ceil(_h));
    if (is_string(_old) || is_struct(_old) || is_array(_old) || is_bool(_old)) _old = undefined;
    if (!is_undefined(_old) && surface_exists(_old)) {
        if (surface_get_width(_old) == _w && surface_get_height(_old) == _h) return _old;
        surface_free(_old);
    }
    return surface_create(_w, _h);
}

/// @function tra_bake(surface, w, h, ss, painter)
/// @description Bake a design-space w x h picture at internal scale ss into a surface (created or reused; returned) via
/// painter(ctx), where ctx is a fresh tra_cx context whose base transform is ss. Returns the surface. Draw it with
/// tra_draw_pm_surface at 1/ss. Refuses (returns `surface` untouched) a painter that is not a function, a size that is
/// not positive, or a bake larger than 8192 pixels a side; ss is held to 0.25-4.
function tra_bake(_sf, _w, _h, _ss, _painter) {
    if (!is_callable(_painter) || !is_numeric(_w) || !is_numeric(_h) || !(_w > 0) || !(_h > 0)) return _sf;
    _ss = is_numeric(_ss) ? clamp(_ss, 0.25, 4) : TRA_SS;
    if (_w * _ss > 8192 || _h * _ss > 8192) return _sf;
    _sf = tra__surface(_sf, _w * _ss, _h * _ss);
    var _m = tra__bake_begin(_sf);
    _painter(tra_cx_create(_ss));
    tra__bake_end(_m);
    return _sf;
}

/// @function tra_room_prepare([quality])
/// @description Bake the room every table shares - the workbench and the parts box - at internal scale `quality` (1-3,
/// default 2) and keep it for the game. The first table opened does this for you; call it on a loading screen to move
/// the cost there (MEASURED in the suite - see the Readme). Returns the surface.
function tra_room_prepare(_ss = TRA_SS) {
    _ss = is_numeric(_ss) ? clamp(round(_ss), 1, 3) : TRA_SS;
    if (!variable_global_exists("__tra_room") || !is_struct(global.__tra_room)) global.__tra_room = { ss: 0, sf: undefined };
    var _R = global.__tra_room;
    if (_R.ss == _ss && !is_undefined(_R.sf) && surface_exists(_R.sf)) return _R.sf;
    _R.sf = tra_bake(_R.sf, 816, 624, _ss, function(_c) {
        var _PA = tra__scene_layout().PARTS;
        tra_draw_table(_c, 816, 624);
        tra_draw_parts_box(_c, _PA.x, _PA.y, _PA.w, _PA.h);
    });
    _R.ss = _ss;
    return _R.sf;
}

/// @function tra_room_free()
/// @description Free the shared room (rebuilt on demand).
function tra_room_free() {
    if (!variable_global_exists("__tra_room") || !is_struct(global.__tra_room)) return;
    if (!is_undefined(global.__tra_room.sf) && surface_exists(global.__tra_room.sf)) surface_free(global.__tra_room.sf);
    global.__tra_room = { ss: 0, sf: undefined };
}

/// @function tra_draw_pm_surface(surface, x, y, [xscale], [yscale], [alpha])
/// @description Draw a baked (premultiplied) surface: blend bm_one / bm_inv_src_alpha, filtered, colour scaled by alpha
/// so a fade stays premultiplied. The caller's blend and filter are restored. Nothing for a lost surface.
function tra_draw_pm_surface(_sf, _x, _y, _xs = 1, _ys = 1, _a = 1) {
    if (is_undefined(_sf) || is_string(_sf) || is_struct(_sf) || is_array(_sf) || !surface_exists(_sf)) return;
    gpu_push_state();
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    gpu_set_texfilter(true);
    draw_surface_ext(_sf, _x, _y, _xs, _ys, 0, merge_colour(c_black, c_white, clamp(_a, 0, 1)), _a);
    gpu_pop_state();
}

/// @function tra_draw_pm(sprite, x, y, [xscale], [yscale], [angle], [colour], [alpha])
/// @description Draw one of Tray's PREMULTIPLIED sprites correctly over anything: blend one / inv_src_alpha, filtered,
/// the colour scaled by the alpha. Restores the caller's blend mode and filter.
function tra_draw_pm(_spr, _x, _y, _xs = 1, _ys = 1, _ang = 0, _col = c_white, _a = 1) {
    if (is_undefined(_spr) || is_string(_spr) || is_struct(_spr) || is_array(_spr) || !sprite_exists(_spr)) return;
    if (!is_numeric(_x) || !is_numeric(_y)) return;
    if (!is_numeric(_xs)) _xs = 1;
    if (!is_numeric(_ys)) _ys = 1;
    if (!is_numeric(_ang)) _ang = 0;
    if (!is_numeric(_col)) _col = c_white;
    if (!is_numeric(_a)) _a = 1;
    gpu_push_state();
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    gpu_set_texfilter(true);
    draw_sprite_ext(_spr, 0, _x, _y, _xs, _ys, _ang, merge_colour(c_black, _col, clamp(_a, 0, 1)), _a);
    gpu_pop_state();
}
