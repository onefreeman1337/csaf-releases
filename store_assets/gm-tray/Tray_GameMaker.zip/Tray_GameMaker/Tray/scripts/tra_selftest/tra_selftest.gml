/// tra_selftest.gml - the in-engine suite (`Tray.exe -selftest` writes tra_selftest.json). Stage 99 = the suite reached its
/// end. Not needed at runtime: delete it with the -selftest branch of the demo object.
///
/// Tray - Generated Packing Puzzles in Wood, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// FIRST CUT (2026-10-04): the core held to the published MZ TrayCore (tra_oracle.gml) - the generator's draws, 36 masks,
/// 12 polyominoes' orientations, box-size queries, 144 raw carvings (box, pieces, woods, inlays, solution), the solver on
/// the 48 easy carvings (solutions, raw, completeness, NODES, symmetries) and 9 graded puzzles; plus the VM cost of one
/// hard grade's budget, which decides how the scene must grade (PORT_PLAN.md).

function tra_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 80) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
function tra_st_stage(_st, _n) { _st.stage = _n; global.tra_stage = _n; }

/// @function tra_st_cells_eq(a, b)
function tra_st_cells_eq(_a, _b) {
    if (array_length(_a) != array_length(_b)) return false;
    for (var _i = 0; _i < array_length(_a); _i++) if (_a[_i][0] != _b[_i][0] || _a[_i][1] != _b[_i][1]) return false;
    return true;
}

/// @function tra_selftest_run([quick])
/// @description The whole suite; quick = true skips the core arms 1-10 (minutes of solver and book replay) to iterate on
/// the drawing and the scene. A quick run is never the run of record: it says so in its own result (metrics.quick).
function tra_selftest_run(_quick = false) {
    var _st = { total: 0, pass: 0, fail: 0, stage: 0, notes: [], failures: [], metrics: { quick: _quick } };
    if (_quick) { tra_selftest_tail(_st); return _st; }
    // ---- 1: the generator's draws ----
    tra_st_stage(_st, 1);
    var _od = tra_oracle_draws(), _g = tra_rng($7A4 ^ 12345), _bad = 0;
    for (var _i = 0; _i < array_length(_od); _i++) if (tra_rnd(_g) != _od[_i]) _bad++;
    tra_st_assert(_st, _bad == 0, string(_bad) + " generator draws differ");
    // ---- 2: masks, orientations, sizes ----
    tra_st_stage(_st, 2);
    var _om = tra_oracle_masks(); _bad = 0;
    for (var _m = 0; _m < array_length(_om); _m++) {
        var _mk = tra_mask(_om[_m][0], _om[_m][1], _om[_m][2]), _want = _om[_m][3];
        var _same = (array_length(_mk) == array_length(_want));
        for (var _q = 0; _q < array_length(_mk) && _same; _q++) if (_mk[_q] != _want[_q]) _same = false;
        if (!_same) { _bad++; array_push(_st.notes, "mask " + _om[_m][0] + " " + string(_om[_m][1]) + "x" + string(_om[_m][2])); }
    }
    tra_st_assert(_st, _bad == 0, string(_bad) + " of " + string(array_length(_om)) + " masks differ");
    var _op = tra_oracle_polys(), _oo = tra_oracle_orients(); _bad = 0;
    for (var _p = 0; _p < array_length(_op); _p++) {
        var _o = tra_orientations(_op[_p]), _ok = (array_length(_o) == _oo[_p][0]);
        for (var _k = 0; _k < array_length(_o) && _ok; _k++) if (tra__key(_o[_k]) != _oo[_p][1][_k]) _ok = false;
        if (!_ok) { _bad++; array_push(_st.notes, "orientations of polyomino " + string(_p) + ": " + string(array_length(_o)) + " vs " + string(_oo[_p][0])); }
    }
    tra_st_assert(_st, _bad == 0, string(_bad) + " of 12 polyominoes' orientations differ (count, order or cells)");
    var _os = tra_oracle_sizes(); _bad = 0;
    for (var _z = 0; _z < array_length(_os); _z++) {
        var _sz = tra_sizes_for(_os[_z][0], _os[_z][1], _os[_z][2]), _wz = _os[_z][3], _okz = (array_length(_sz) == array_length(_wz));
        for (var _y = 0; _y < array_length(_sz) && _okz; _y++) if (_sz[_y][0] != _wz[_y][0] || _sz[_y][1] != _wz[_y][1] || _sz[_y][2] != _wz[_y][2]) _okz = false;
        if (!_okz) _bad++;
    }
    tra_st_assert(_st, _bad == 0, string(_bad) + " box-size queries differ");
    // ---- 3: 144 raw carvings ----
    tra_st_stage(_st, 3);
    var _or = tra_oracle_raws(), _rb = 0, _woodsSeen = {}, _inlaysSeen = {}, _formsSeen = {};
    for (var _r = 0; _r < array_length(_or); _r++) {
        var _R = _or[_r], _pz = tra_generate({ seed: _R[0], difficulty: _R[1], shape: _R[2], raw: true });
        if (is_undefined(_pz)) { _rb++; continue; }
        var _okr = (_pz.w == _R[3] && _pz.h == _R[4] && _pz.cells == _R[5] && array_length(_pz.pieces) == array_length(_R[6]));
        for (var _pi = 0; _pi < array_length(_pz.pieces) && _okr; _pi++) {
            var _pc = _pz.pieces[_pi], _wp = _R[6][_pi];
            if (!tra_st_cells_eq(_pc.cells, _wp[0]) || _pc.wood != _wp[1] || _pc.inlay != _wp[2]) _okr = false;
            var _sl = _pz.solution[_pi], _ws = _R[7][_pi];
            if (_sl.piece != _ws[0] || _sl.x != _ws[1] || _sl.y != _ws[2]) _okr = false;
            variable_struct_set(_woodsSeen, _pc.wood, 1); variable_struct_set(_inlaysSeen, _pc.inlay, 1); variable_struct_set(_formsSeen, tra_canon(_pc.cells), 1);
        }
        if (!_okr) { _rb++; if (_rb <= 4) array_push(_st.notes, "raw " + string(_R[0]) + " " + _R[1] + " " + _R[2] + ": gml " + string(_pz.w) + "x" + string(_pz.h) + " vs " + string(_R[3]) + "x" + string(_R[4])); }
    }
    tra_st_assert(_st, _rb == 0, string(_rb) + " of " + string(array_length(_or)) + " raw carvings differ (box, pieces, woods, inlays or solution)");
    _st.metrics.rawCarvings = array_length(_or);
    _st.metrics.distinct = { woods: array_length(variable_struct_get_names(_woodsSeen)), inlays: array_length(variable_struct_get_names(_inlaysSeen)), pieceForms: array_length(variable_struct_get_names(_formsSeen)) };
    // ---- 4: the solver on the 48 easy carvings ----
    tra_st_stage(_st, 4);
    var _sv = tra_oracle_solves(), _sb = 0, _ti = get_timer(), _nodes = 0;
    for (var _s = 0; _s < array_length(_sv); _s++) {
        var _S = _sv[_s], _pz2 = tra_generate({ seed: _S[0], difficulty: "easy", shape: _S[1], raw: true });
        var _res = tra_solve(_pz2.mask, _pz2.w, _pz2.h, _pz2.pieces, { cap: 50, nodeCap: 400000 });
        _nodes += _res.nodes;
        if (_res.solutions != _S[2] || _res.raw != _S[3] || _res.complete != _S[4] || _res.nodes != _S[5] || _res.symmetries != _S[6]) { _sb++; if (_sb <= 4) array_push(_st.notes, "solve " + string(_S[0]) + " " + _S[1] + ": gml " + string(_res.solutions) + "/" + string(_res.raw) + "/" + string(_res.nodes) + " vs " + string(_S[2]) + "/" + string(_S[3]) + "/" + string(_S[5])); }
    }
    var _solveMs = (get_timer() - _ti) / 1000;
    tra_st_assert(_st, _sb == 0, string(_sb) + " of " + string(array_length(_sv)) + " solves differ (solutions, raw, complete, nodes or symmetries)");
    _st.metrics.solve = { cases: array_length(_sv), nodes: _nodes, ms: _solveMs, usPerNode: (_nodes > 0) ? _solveMs * 1000 / _nodes : 0 };
    // ---- 5: graded puzzles (generate-and-test) ----
    tra_st_stage(_st, 5);
    var _gr = tra_oracle_graded(), _gb = 0, _tg = get_timer();
    for (var _j = 0; _j < array_length(_gr); _j++) {
        var _G = _gr[_j], _gp = tra_generate({ seed: _G[0], difficulty: _G[1] });
        if (is_undefined(_gp) || _gp.shape != _G[2] || _gp.w != _G[3] || _gp.h != _G[4] || _gp.ways != _G[5] || _gp.graded != _G[6] || _gp.tries != _G[7] || array_length(_gp.pieces) != _G[8]) { _gb++; array_push(_st.notes, "graded " + string(_G[0]) + " " + _G[1]); }
    }
    tra_st_assert(_st, _gb == 0, string(_gb) + " of " + string(array_length(_gr)) + " graded puzzles differ");
    _st.metrics.gradedMs = (get_timer() - _tg) / 1000;
    // ---- 6: the VM cost of ONE hard grade's budget (decides how the scene grades) ----
    tra_st_stage(_st, 6);
    var _hp = tra_generate({ seed: 31, difficulty: "hard", raw: true }), _th = get_timer();
    var _hr = tra_solve(_hp.mask, _hp.w, _hp.h, _hp.pieces, { cap: 41, nodeCap: TRA_GRADE_NODES });
    _st.metrics.hardOneCarving = { ms: (get_timer() - _th) / 1000, nodes: _hr.nodes, solutions: _hr.solutions, complete: _hr.complete, pieces: array_length(_hp.pieces), box: string(_hp.w) + "x" + string(_hp.h) };
    tra_st_assert(_st, _hr.nodes > 0, "the hard timing probe searched nothing");
    // ---- 7: the RESUMABLE search, stepped 97 nodes at a time (a stride deliberately NOT a divisor of anything) ----
    tra_st_stage(_st, 7);
    var _sb2 = 0, _multi = 0;
    for (var _s2 = 0; _s2 < array_length(_sv); _s2++) {
        var _S2 = _sv[_s2], _pz3 = tra_generate({ seed: _S2[0], difficulty: "easy", shape: _S2[1], raw: true });
        var _job = tra_solve_begin(_pz3.mask, _pz3.w, _pz3.h, _pz3.pieces, { cap: 50, nodeCap: 400000 });
        while (!tra_solve_step(_job, 97, 1000000)) { }
        var _r2 = tra_solve_result(_job);
        if (_job.slices > 1) _multi++;
        if (_r2.solutions != _S2[2] || _r2.raw != _S2[3] || _r2.complete != _S2[4] || _r2.nodes != _S2[5] || _r2.symmetries != _S2[6]) _sb2++;
    }
    tra_st_assert(_st, _sb2 == 0, string(_sb2) + " of 48 sliced searches differ from the original");
    tra_st_assert(_st, _multi >= 10, "only " + string(_multi) + " sliced searches actually spanned more than one step (the arm would be vacuous)");
    // ---- 8: generation jobs in 4 ms slices: the 9 graded puzzles and one HARD one, identical to the original ----
    tra_st_stage(_st, 8);
    var _gb2 = 0, _worst = 0, _stepsMax = 0;
    for (var _j2 = 0; _j2 < array_length(_gr); _j2++) {
        var _G2 = _gr[_j2], _gj = tra_generate_begin({ seed: _G2[0], difficulty: _G2[1] });
        while (!tra_generate_step(_gj, 4)) { }
        var _gp2 = _gj.result;
        _worst = max(_worst, _gj.worstMs); _stepsMax = max(_stepsMax, _gj.steps);
        if (is_undefined(_gp2) || _gp2.shape != _G2[2] || _gp2.w != _G2[3] || _gp2.h != _G2[4] || _gp2.ways != _G2[5] || _gp2.graded != _G2[6] || _gp2.tries != _G2[7]) _gb2++;
    }
    tra_st_assert(_st, _gb2 == 0, string(_gb2) + " of 9 sliced generations differ from the original");
    var _H = tra_oracle_hard(), _hj = tra_generate_begin({ seed: _H[0], difficulty: "hard" }), _th2 = get_timer();
    while (!tra_generate_step(_hj, 4)) { }
    var _hp2 = _hj.result;
    tra_st_assert(_st, !is_undefined(_hp2) && _hp2.shape == _H[1] && _hp2.w == _H[2] && _hp2.h == _H[3] && _hp2.ways == _H[4] && _hp2.graded == _H[5] && _hp2.tries == _H[6] && array_length(_hp2.pieces) == _H[7], "the sliced HARD generation differs from the original (gml ways " + (is_undefined(_hp2) ? "none" : string(_hp2.ways)) + " vs " + string(_H[4]) + ")");
    _st.metrics.slicedHard = { totalMs: (get_timer() - _th2) / 1000, steps: _hj.steps, worstStepMs: _hj.worstMs, budgetMs: 4 };
    _st.metrics.slicedGraded = { worstStepMs: _worst, mostSteps: _stepsMax, budgetMs: 4 };
    // ---- 9: the BOOK - every row replays to the size and piece count the original recorded, fast; easy and normal rows
    // re-graded here in full must give the original's count (hard rows are re-graded for ONE row: ~44 s each on the VM) ----
    tra_st_stage(_st, 9);
    var _diffs = tra_difficulty_names(), _shp = tra_shapes(), _rows = 0, _bb = 0, _regraded = 0, _rg = 0, _tb = get_timer(), _worstBook = 0;
    for (var _d9 = 0; _d9 < 3; _d9++) for (var _s9 = 0; _s9 < 6; _s9++) {
        var _rw = tra_book_rows(_diffs[_d9], _shp[_s9]);
        for (var _i9 = 0; _i9 < array_length(_rw); _i9++) {
            var _t9 = get_timer(), _bp = tra_book_puzzle(_diffs[_d9], _shp[_s9], _i9);
            _worstBook = max(_worstBook, (get_timer() - _t9) / 1000);
            _rows++;
            // the stored layout must be EXACTLY what the seed's carvings produce
            var _rp = tra_book_replay(_diffs[_d9], _shp[_s9], _i9);
            var _same9 = !is_undefined(_bp) && !is_undefined(_rp) && _bp.w == _rp.w && _bp.h == _rp.h && _bp.cells == _rp.cells && array_length(_bp.pieces) == array_length(_rp.pieces) && array_length(_bp.pieces) == _rw[_i9][6];
            for (var _pq = 0; _same9 && _pq < array_length(_bp.pieces); _pq++) {
                if (!tra_st_cells_eq(_bp.pieces[_pq].cells, _rp.pieces[_pq].cells) || _bp.pieces[_pq].wood != _rp.pieces[_pq].wood || _bp.pieces[_pq].inlay != _rp.pieces[_pq].inlay || _bp.solution[_pq].x != _rp.solution[_pq].x || _bp.solution[_pq].y != _rp.solution[_pq].y) _same9 = false;
            }
            if (!_same9) { _bb++; continue; }
            if (_d9 < 2 && (_i9 mod 4) == 0) {
                var _full = tra_generate({ seed: _rw[_i9][0], difficulty: _diffs[_d9], shape: _shp[_s9] });
                _regraded++;
                if (_full.ways != _bp.ways || _full.tries != _bp.tries || _full.w != _bp.w || !tra_st_cells_eq(_full.pieces[0].cells, _bp.pieces[0].cells)) _rg++;
            }
        }
    }
    tra_st_assert(_st, _rows >= 500 && _bb == 0, string(_bb) + " of " + string(_rows) + " book rows replay to a different tray");
    tra_st_assert(_st, _regraded >= 30 && _rg == 0, string(_rg) + " of " + string(_regraded) + " re-graded book rows disagree with the original's grade");
    _st.metrics.book = { rows: _rows, regraded: _regraded, worstBuildMs: _worstBook, totalMs: (get_timer() - _tb) / 1000 };
    // the build time once the book is warm (the first call per pair builds the cache): 50 builds, worst kept
    var _warm = 0;
    for (var _wb = 0; _wb < 50; _wb++) { var _tw = get_timer(); tra_book_puzzle("hard", "diamond", _wb); _warm = max(_warm, (get_timer() - _tw) / 1000); }
    _st.metrics.book.warmWorstMs = _warm;
    // ---- 10: the play rules and hints, against the original on 8 easy trays ----
    tra_st_stage(_st, 10);
    var _oh = tra_oracle_hints(), _hb = 0, _th3 = get_timer();
    var _enc = function(_h) { if (variable_struct_exists(_h, "place")) return ["place", _h.place.piece, _h.place.x, _h.place.y]; if (variable_struct_exists(_h, "lift")) return ["lift", _h.lift, -1, -1]; return ["none", -1, -1, -1]; };
    for (var _e = 0; _e < array_length(_oh); _e++) {
        var _E = _oh[_e], _pp = tra_generate({ seed: _E[0], difficulty: "easy", shape: _E[1], raw: true }), _gm = tra_new_game(_pp);
        for (var _pl = 0; _pl < _E[2]; _pl++) { var _so = _pp.solution[_pl]; tra_place(_pp, _gm, _so.piece, _so.cells, _so.x, _so.y); }
        var _h1 = _enc(tra_hint(_pp, _gm));
        if (_E[4][0] >= 0) tra_place(_pp, _gm, 0, _pp.solution[0].cells, _E[4][0], _E[4][1]);
        var _h2 = _enc(tra_hint(_pp, _gm));
        var _okh = (_h1[0] == _E[3][0] && _h1[1] == _E[3][1] && _h1[2] == _E[3][2] && _h1[3] == _E[3][3] && _h2[0] == _E[5][0] && _h2[1] == _E[5][1] && _h2[2] == _E[5][2] && _h2[3] == _E[5][3] && _gm.moves == _E[6] && tra_solved(_pp, _gm) == _E[7]);
        if (!_okh) { _hb++; if (_hb <= 3) array_push(_st.notes, "hint " + string(_E[0]) + ": gml " + _h1[0] + string(_h1[1]) + "/" + _h2[0] + string(_h2[1]) + " vs " + _E[3][0] + string(_E[3][1]) + "/" + _E[5][0] + string(_E[5][1])); }
    }
    tra_st_assert(_st, _hb == 0, string(_hb) + " of " + string(array_length(_oh)) + " play/hint sequences differ from the original");
    _st.metrics.hintsMs = (get_timer() - _th3) / 1000;
    tra_selftest_tail(_st);
    return _st;
}

/// @function tra_selftest_tail(st)
/// @description Arms 11-14 (the drawing and the scene), then stage 99.
function tra_selftest_tail(_st) {
    // ---- 11: the drawing's tables and pure geometry, against the original (TrayDraw.js) ----
    tra_st_stage(_st, 11);
    tra_selftest_geometry(_st);
    // ---- 12: every drawn thing, op for op ----
    tra_st_stage(_st, 12);
    tra_selftest_draws(_st);
    // ---- 13: renders for LOOKING (contact sheet of 10 woods x 10 inlays, six trays, the room, the finished panel) ----
    tra_st_stage(_st, 13);
    tra_selftest_renders(_st);
    // ---- 14: whole puzzles driven through the scene (keyboard, mouse, hints, a misplaced piece, leaving), timed ----
    tra_st_stage(_st, 14);
    tra_selftest_scene(_st);
    tra_st_stage(_st, 99);
}

/// @function tra_st_key(name)
/// @description An input with one press ("left", "right", "up", "down", "ok", "cancel", "turnBack", "turnOn", "flip",
/// "hint") and the mouse far away.
function tra_st_key(_k) {
    return tra_input(_k == "left", _k == "right", _k == "up", _k == "down", _k == "ok", _k == "cancel", _k == "turnBack", _k == "turnOn", _k == "flip", _k == "hint");
}

/// @function tra_st_mouse(x, y, held, click, rclick)
function tra_st_mouse(_x, _y, _held, _click, _rclick) { return tra_input(false, false, false, false, false, false, false, false, false, false, _x, _y, _held, _click, _rclick, 0); }

/// @function tra_st_frame(scene, surface, [name])
/// @description Draw the scene into an 816 x 624 surface at 1:1 (so mouse coordinates are design coordinates); save it
/// when a name is given. Returns the draw time in ms.
function tra_st_frame(_S, _sf, _name = "") {
    var _t = get_timer();
    surface_set_target(_sf);
    draw_clear(c_black);
    tra_scene_draw(_S, 0, 0, surface_get_width(_sf), surface_get_height(_sf));
    surface_reset_target();
    var _ms = (get_timer() - _t) / 1000;
    if (_name != "") surface_save(_sf, _name);
    return _ms;
}

/// @function tra_st_has(events_log, name)
function tra_st_has(_log, _n) { for (var _i = 0; _i < array_length(_log); _i++) if (_log[_i] == _n) return true; return false; }

/// @function tra_st_run(scene, input, log)
/// @description One step, its events appended to log. Returns the mode.
function tra_st_run(_S, _in, _log) { var _m = tra_scene_step(_S, _in); for (var _i = 0; _i < array_length(_S.events); _i++) array_push(_log, _S.events[_i]); return _m; }

/// @function tra_selftest_scene(st)
function tra_selftest_scene(_st) {
    var _sf = surface_create(816, 624), _log = [], _i, _k;
    // A. the keyboard, piece by piece in the solution's order, on an easy rect tray from the book
    var _p = tra_book_puzzle("easy", "rect", 3), S = tra_scene_create(_p, { fade: false, hints: 0 });
    tra_st_assert(_st, is_struct(S) && S.mode == "pick", "the scene did not open on an easy book tray");
    var _geoBake = tra_case_geo(12 + 504 / 2, 64 + 444 / 2, _p, S.s);
    tra_st_assert(_st, _geoBake.x == S.geo.x && _geoBake.y == S.geo.y && S.geo.board.w == _p.w * S.s + tra_jsround(S.s * 0.62) * 2, "the scene's case geometry disagrees with tra_case_geo");
    tra_st_frame(S, _sf, "tra_render_scene_start.png");
    var _bad = 0, _n = array_length(_p.pieces), _turnsUsed = 0, _savedCarry = false;
    for (_k = 0; _k < _n; _k++) {
        var _sol = _p.solution[_k], _pi = _sol.piece, _g = 0;
        while (S.sel != _pi && _g < 20) { tra_st_run(S, tra_st_key("right"), _log); _g++; }
        tra_st_run(S, tra_st_key("ok"), _log);
        if (S.mode != "carry" || S.carry != _pi) { _bad++; continue; }
        var _want = tra__cells_key(_sol.cells), _t = 0;
        while (tra__cells_key(S.T[_pi].cells) != _want && _t < 9) { tra_st_run(S, tra_st_key((_t == 4) ? "flip" : "turnOn"), _log); _t++; }
        _turnsUsed += _t;
        var _g2 = 0;
        while ((S.cx != _sol.x || S.cy != _sol.y) && _g2 < 40) {
            var _dir = (S.cx < _sol.x) ? "right" : ((S.cx > _sol.x) ? "left" : ((S.cy < _sol.y) ? "down" : "up"));
            tra_st_run(S, tra_st_key(_dir), _log); _g2++;
        }
        if (_k == _n - 1 && !_savedCarry) { tra_st_frame(S, _sf, "tra_render_scene_carry.png"); _savedCarry = true; }
        tra_st_run(S, tra_st_key("ok"), _log);
        if (is_undefined(S.game.placed[_pi])) _bad++;
    }
    tra_st_assert(_st, _bad == 0, "keyboard: " + string(_bad) + " of " + string(_n) + " pieces could not be carried home");
    tra_st_assert(_st, S.mode == "polish", "keyboard: the filled tray did not start the polish (mode " + S.mode + ")");
    for (_i = 0; _i < 20; _i++) tra_st_run(S, tra_st_key(""), _log);
    tra_st_frame(S, _sf, "tra_render_scene_polish.png");
    for (_i = 0; _i < 20; _i++) tra_st_run(S, tra_st_key(""), _log);
    tra_st_assert(_st, S.mode == "reveal", "keyboard: the polish did not end in the reveal after 40 frames (mode " + S.mode + ")");
    for (_i = 0; _i < 24; _i++) tra_st_run(S, tra_st_key(""), _log);
    tra_st_frame(S, _sf, "tra_render_scene_verdict.png");
    tra_st_assert(_st, S.mode == "done", "keyboard: the reveal did not finish in 24 frames");
    tra_st_run(S, tra_st_key("ok"), _log);
    for (_i = 0; _i < TRA_FADE; _i++) tra_st_run(S, tra_st_key(""), _log);
    var _R = tra_scene_result(S);
    tra_st_assert(_st, tra_scene_done(S) && is_struct(_R) && _R.solved && _R.moves == _n && _R.hints == 0 && _R.pieces == _n && _R.ways == _p.ways, "keyboard: the result is wrong (" + (is_struct(_R) ? string(_R.moves) + " moves, ways " + string(_R.ways) : "none") + ")");
    tra_st_assert(_st, tra_st_has(_log, "pick") && tra_st_has(_log, "drop") && tra_st_has(_log, "solve") && tra_st_has(_log, "leave") && (_turnsUsed == 0 || tra_st_has(_log, "turn")), "keyboard: an expected event never fired");
    _st.metrics.sceneKeyboard = { pieces: _n, turns: _turnsUsed, events: array_length(_log) };
    tra_scene_free(S);
    // B. the mouse: grab each piece in the box, turn it with the right button (flip with Shift), drop it where it goes
    _p = tra_book_puzzle("normal", "cross", 5); S = tra_scene_create(_p, { fade: false }); _log = [];
    tra_st_frame(S, _sf);
    _bad = 0; _n = array_length(_p.pieces);
    for (_k = 0; _k < _n; _k++) {
        var _so = _p.solution[_k], _q = _so.piece, _b = tra__scene_piece_box(S, _q), _c0 = S.T[_q].cells[0];
        var _mx = _b.x + (_c0[0] + 0.5) * S.s * _b.sc, _my = _b.y + (_c0[1] + 0.5) * S.s * _b.sc;
        tra_st_run(S, tra_st_mouse(_mx, _my, true, true, false), _log);
        if (S.mode != "drag" || S.carry != _q) { _bad++; if (_bad <= 3) array_push(_st.notes, "mouse: piece " + string(_q) + " not grabbed (mode " + S.mode + ")"); continue; }
        var _w2 = tra__cells_key(_so.cells), _t2 = 0;
        while (tra__cells_key(S.T[_q].cells) != _w2 && _t2 < 9) { if (_t2 == 4) tra_st_run(S, tra_st_key("flip"), _log); else tra_st_run(S, tra_st_mouse(_mx, _my, true, false, true), _log); _t2++; }
        var _tx = S.geo.x + _so.x * S.s + S.gx, _ty = S.geo.y + _so.y * S.s + S.gy;
        tra_st_run(S, tra_st_mouse(_tx, _ty, true, false, false), _log);
        if (!(S.snap.on && S.snap.fits && S.snap.x == _so.x && S.snap.y == _so.y)) { _bad++; if (_bad <= 3) array_push(_st.notes, "mouse: piece " + string(_q) + " snapped to " + string(S.snap.x) + "," + string(S.snap.y) + " fits " + string(S.snap.fits) + " want " + string(_so.x) + "," + string(_so.y)); }
        tra_st_run(S, tra_st_mouse(_tx, _ty, false, false, false), _log);
        if (is_undefined(S.game.placed[_q])) _bad++;
    }
    tra_st_assert(_st, _bad == 0 && S.mode == "polish", "mouse: " + string(_bad) + " of " + string(_n) + " pieces failed to drag home (mode " + S.mode + ")");
    for (_i = 0; _i < 40; _i++) tra_st_run(S, tra_st_key(""), _log);
    _R = tra_scene_result(S);
    tra_st_assert(_st, is_struct(_R) && _R.moves == _n && _R.hints == 0, "mouse: the result is wrong");
    tra_scene_free(S);
    // C. hints only, on a HARD tray: every hint places a piece; the search is spread over frames (worst frame recorded)
    _p = tra_book_puzzle("hard", "rect", 2); S = tra_scene_create(_p, { fade: false, hints: 99 }); _log = [];
    _n = array_length(_p.pieces);
    var _worstStep = 0, _steps = 0;
    while (S.mode == "pick" || S.mode == "think") {
        var _ts = get_timer();
        tra_st_run(S, tra_st_key((S.mode == "pick") ? "hint" : ""), _log);
        _worstStep = max(_worstStep, (get_timer() - _ts) / 1000); _steps++;
        if (_steps > 20000) break;
    }
    var _hints = 0;
    for (_i = 0; _i < array_length(_log); _i++) if (_log[_i] == "hint") _hints++;
    tra_st_assert(_st, S.mode == "polish" && _hints == _n && S.game.hints == _n && S.game.moves == 0, "hints: " + string(_hints) + " hints for " + string(_n) + " pieces, mode " + S.mode + ", moves " + string(S.game.moves));
    _st.metrics.sceneHints = { pieces: _n, steps: _steps, worstStepMs: _worstStep };
    tra_scene_free(S);
    // D. a piece put down in a wrong place, then a hint: it must answer (place or lift), never stall, and keep the grid honest
    _p = tra_book_puzzle("easy", "round", 1); S = tra_scene_create(_p, { fade: false, hints: 3 }); _log = [];
    var _s0 = _p.solution[0], _moved = false;
    tra_st_run(S, tra_st_key("ok"), _log);   // lift piece 0 (selected at the start)
    var _T0 = S.T[0];
    for (var _yy = 0; _yy < _p.h && !_moved; _yy++) for (var _xx = 0; _xx < _p.w && !_moved; _xx++) {
        if (tra__cells_key(_T0.cells) == tra__cells_key(_s0.cells) && _xx == _s0.x && _yy == _s0.y) continue;
        if (tra_fits(_p, S.game, 0, _T0.cells, _xx, _yy)) { S.cx = _xx; S.cy = _yy; tra__scene_carry_moved(S); tra_st_run(S, tra_st_key("ok"), _log); _moved = !is_undefined(S.game.placed[0]); }
    }
    var _before = S.game.hints, _hs = 0;
    tra_st_run(S, tra_st_key("hint"), _log);
    while (S.mode == "think" && _hs < 2000) { tra_st_run(S, tra_st_key(""), _log); _hs++; }
    var _covered = 0;
    for (_i = 0; _i < array_length(S.game.grid); _i++) if (S.game.grid[_i] >= 0) _covered++;
    var _sumCells = 0;
    for (_i = 0; _i < array_length(S.game.placed); _i++) if (!is_undefined(S.game.placed[_i])) _sumCells += array_length(S.game.placed[_i].cells);
    tra_st_assert(_st, _moved && S.game.hints == _before + 1 && S.mode != "think" && _covered == _sumCells, "misplaced + hint: moved " + string(_moved) + ", hints " + string(S.game.hints) + ", mode " + S.mode + ", grid " + string(_covered) + " vs " + string(_sumCells));
    _st.metrics.sceneMisplacedHint = string(S.status);
    tra_scene_free(S);
    // E. leaving early: no result, the leave event, gone after the fade
    _p = tra_book_puzzle("normal", "arch", 0); S = tra_scene_create(_p, { fade: false }); _log = [];
    tra_st_run(S, tra_st_key("cancel"), _log);
    for (_i = 0; _i < TRA_FADE; _i++) tra_st_run(S, tra_st_key(""), _log);
    tra_st_assert(_st, tra_scene_done(S) && is_undefined(tra_scene_result(S)) && tra_st_has(_log, "leave"), "leaving early: not gone, or a result was reported");
    tra_scene_free(S);
    // F. the cost of opening a table: the room (first table only), the case, and the pieces spread over the fade-in
    tra_room_free();
    _p = tra_book_puzzle("hard", "diamond", 4); S = tra_scene_create(_p, { hints: 3 });
    var _first = tra_st_frame(S, _sf), _worstFade = 0, _frames = 1, _allBaked = false;
    var _firstParts = { room: S.bakeMs.room, board: S.bakeMs.board, pieces: S.bakeMs.pieces, ui: S.bakeMs.ui };
    while (S.fade > 0 && _frames < 60) {
        tra_st_run(S, tra_st_key(""), []);
        _worstFade = max(_worstFade, tra_st_frame(S, _sf)); _frames++;
        var _missing = 0;
        for (_i = 0; _i < array_length(S.surf.pieces); _i++) if (is_undefined(S.surf.pieces[_i]) || !surface_exists(S.surf.pieces[_i])) _missing++;
        if (_missing == 0 && !_allBaked) { _allBaked = true; _st.metrics.piecesBakedByFrame = _frames; }
    }
    tra_scene_free(S);
    S = tra_scene_create(tra_book_puzzle("normal", "notched", 2), { fade: false });
    var _second = tra_st_frame(S, _sf);
    var _secondParts = { room: S.bakeMs.room, board: S.bakeMs.board, pieces: S.bakeMs.pieces, ui: S.bakeMs.ui, pieceCount: array_length(S.p.pieces) };
    tra_scene_free(S);
    tra_st_assert(_st, _allBaked, "the pieces were not all baked before the fade-in ended");
    _st.metrics.sceneOpenMs = { firstTableFirstFrame: _first, firstParts: _firstParts, worstFadeFrame: _worstFade, secondTableNoFade: _second, secondParts: _secondParts };
    // the steady state: a frame of the table in play, nothing to re-bake (100 draws, worst and mean)
    S = tra_scene_create(tra_book_puzzle("normal", "round", 1), { fade: false });
    tra_st_frame(S, _sf);
    var _worstPlay = 0, _sumPlay = 0;
    for (_i = 0; _i < 100; _i++) { tra_st_run(S, tra_st_key(""), []); var _fm = tra_st_frame(S, _sf); _worstPlay = max(_worstPlay, _fm); _sumPlay += _fm; }
    _st.metrics.scenePlayFrameMs = { worst: _worstPlay, mean: _sumPlay / 100 };
    // a turn re-bakes one piece: the cost the player feels on Q / W / Shift
    tra_st_run(S, tra_st_key("turnOn"), []);
    var _turnMs = tra_st_frame(S, _sf);
    _st.metrics.sceneTurnFrameMs = _turnMs;
    // a lift (and a drop) re-bakes only the piece's shadow, never the piece
    tra_st_run(S, tra_st_key("ok"), []);
    var _liftMs = tra_st_frame(S, _sf);
    tra_st_run(S, tra_st_key("cancel"), []);
    var _dropMs = tra_st_frame(S, _sf);
    _st.metrics.sceneLiftFrameMs = { lift: _liftMs, putBack: _dropMs };
    tra_st_assert(_st, S.mode == "pick" && _liftMs < _turnMs, "a lift re-baked more than a turn (" + string(_liftMs) + " vs " + string(_turnMs) + " ms): the shadow is not kept apart");
    tra_scene_free(S);
    // H. where a piece bake's milliseconds go (5 runs each, mean): the whole bake at three lifts, then its parts
    var _pq = tra_book_puzzle("normal", "round", 1).pieces[2], _bench = {}, _parts = ["lift0", "lift25", "lift90", "grain", "motif", "shadow", "surface", "layerClip"];
    for (var _bi = 0; _bi < array_length(_parts); _bi++) {
        var _tot = 0;
        for (var _rr = 0; _rr < 5; _rr++) {
            var _ps = surface_create(400, 400), _bm = tra__bake_begin(_ps), _bc = tra_cx_create(2), _tq = get_timer(), _nm = _parts[_bi];
            if (_nm == "lift0") tra_draw_piece(_bc, _pq, 20, 20, 50, { shadow: 0 });
            else if (_nm == "lift25") tra_draw_piece(_bc, _pq, 20, 20, 50, { shadow: 0.25 });
            else if (_nm == "lift90") tra_draw_piece(_bc, _pq, 20, 20, 50, { shadow: 0.9 });
            else if (_nm == "grain") tra_draw_grain(_bc, _pq.wood, 77, 150, 100);
            else if (_nm == "motif") tra_draw_motif(_bc, _pq.inlay, 36, "pearl");
            else if (_nm == "shadow") { tra_cx_begin(_bc); tra_cx_rect(_bc, 20, 20, 150, 100); tra_cx_shadow(_bc, [0, 0, 0], 0.6, 18.4, 9, 13); }
            else if (_nm == "surface") { var _x2 = surface_create(400, 400); surface_free(_x2); }
            else if (_nm == "layerClip") { tra_cx_save(_bc); tra_cx_begin(_bc); tra_loop_path(_bc, tra_outline(_pq.cells)[0], 50, 20, 20, 5); tra_cx_clip(_bc); tra_cx_restore(_bc); }
            _tot += (get_timer() - _tq) / 1000;
            tra__bake_end(_bm); surface_free(_ps);
        }
        variable_struct_set(_bench, _parts[_bi], _tot / 5);
    }
    _st.metrics.pieceBakeBenchMs = _bench;
    // G. bad input does not crash
    tra_st_assert(_st, is_undefined(tra_scene_create(undefined)) && is_undefined(tra_scene_create({ w: 3 })) && tra_scene_step(undefined) == "gone", "bad input to the scene was accepted or crashed");
    tra_scene_draw(undefined, 0, 0, 10, 10);
    surface_free(_sf);
}

/// @function tra_st_pts_eq(a, b)
/// @description Two point lists equal exactly.
function tra_st_pts_eq(_a, _b) {
    if (!is_array(_a) || !is_array(_b) || array_length(_a) != array_length(_b)) return false;
    for (var _i = 0; _i < array_length(_a); _i++) if (_a[_i][0] != _b[_i][0] || _a[_i][1] != _b[_i][1]) return false;
    return true;
}

/// @function tra_st_loops_eq(a, b)
/// @description Two loop lists equal exactly (same loops, same order, same points).
function tra_st_loops_eq(_a, _b) {
    if (!is_array(_a) || !is_array(_b) || array_length(_a) != array_length(_b)) return false;
    for (var _i = 0; _i < array_length(_a); _i++) if (!tra_st_pts_eq(_a[_i], _b[_i])) return false;
    return true;
}

/// @function tra_st_rgb_eq(a, b)
function tra_st_rgb_eq(_a, _b) { return is_array(_a) && is_array(_b) && _a[0] == _b[0] && _a[1] == _b[1] && _a[2] == _b[2]; }

/// @function tra_selftest_geometry(st)
/// @description The ten woods and four materials (parsed from the original's hex), the material picks, 96 turns with
/// their outlines, insets and poses, 12 heart cells, 36 tray outlines and their fillets.
function tra_selftest_geometry(_st) {
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _ow = tra_oracle_woods(), _bad = 0;
    for (var _i = 0; _i < array_length(_ow); _i++) {
        var _O = _ow[_i], _W = tra_wood(_O[0]);
        if (_W.name != _O[1] || !tra_st_rgb_eq(_W.base, _O[2]) || !tra_st_rgb_eq(_W.light, _O[3]) || !tra_st_rgb_eq(_W.dark, _O[4]) || !tra_st_rgb_eq(_W.streak, _O[5]) || _W.figure != _O[6] || _W.pores != _O[7] || _W.lum != _O[8]) { _bad++; array_push(_st.notes, "wood " + _O[0]); }
    }
    tra_st_assert(_st, _bad == 0 && array_length(_ow) == 10, string(_bad) + " of " + string(array_length(_ow)) + " woods differ from the original's table");
    var _om = tra_oracle_materials(); _bad = 0;
    for (var _m = 0; _m < array_length(_om); _m++) {
        var _M = tra_material(_om[_m][0]), _ok = (_M.name == _om[_m][1] && array_length(_M.stops) == array_length(_om[_m][2]) && tra_st_rgb_eq(_M.edge, _om[_m][3]) && _M.lum == _om[_m][4]);
        for (var _q = 0; _ok && _q < array_length(_M.stops); _q++) if (!tra_st_rgb_eq(_M.stops[_q], _om[_m][2][_q])) _ok = false;
        if (!_ok) { _bad++; array_push(_st.notes, "material " + _om[_m][0]); }
    }
    tra_st_assert(_st, _bad == 0 && array_length(_om) == 4, string(_bad) + " of 4 materials differ from the original's table");
    var _of = tra_oracle_material_for(); _bad = 0;
    for (var _f = 0; _f < array_length(_of); _f++) if (tra_material_for(_of[_f][0], _of[_f][1]) != _of[_f][2]) _bad++;
    tra_st_assert(_st, _bad == 0, string(_bad) + " of " + string(array_length(_of)) + " material picks differ");
    // turns, outlines, insets, poses
    var _polys = tra_oracle_polys2(), _ot = tra_oracle_turns(), _tb = 0, _ob = 0, _ib = 0, _pb = 0;
    for (var _t = 0; _t < array_length(_ot); _t++) {
        var _R = _ot[_t], _T = tra_turn(_polys[_R[0]], _R[1], _R[2]);
        var _okm = true;
        for (var _k = 0; _k < 6; _k++) if (_T.m[_k] != _R[4][_k]) _okm = false;
        if (!tra_st_cells_eq(_T.cells, _R[3]) || !_okm || _T.w != _R[5] || _T.h != _R[6]) { _tb++; if (_tb <= 3) array_push(_st.notes, "turn " + string(_R[0]) + "/" + string(_R[1]) + "/" + string(_R[2])); }
        var _L = tra_outline(_T.cells);
        if (!tra_st_loops_eq(_L, _R[7])) { _ob++; if (_ob <= 3) array_push(_st.notes, "outline of turn " + string(_t) + ": " + string(array_length(_L)) + " loops vs " + string(array_length(_R[7]))); }
        else {
            for (var _l = 0; _l < array_length(_L); _l++) if (!tra_st_pts_eq(tra_inset(_L[_l], 0.14), _R[8][_l]) || !tra_st_pts_eq(tra_inset(_L[_l], 0.14 + 0.05), _R[9][_l])) _ib++;
        }
        var _P = tra_pose_of(_polys[_R[0]], _T.cells);
        if (is_undefined(_P) || _P.rot != _R[10].rot || _P.flip != _R[10].flip) _pb++;
    }
    tra_st_assert(_st, _tb == 0, string(_tb) + " of " + string(array_length(_ot)) + " turns differ (cells, matrix, size)");
    tra_st_assert(_st, _ob == 0, string(_ob) + " of " + string(array_length(_ot)) + " piece outlines differ");
    tra_st_assert(_st, _ib == 0, string(_ib) + " stringing insets differ");
    tra_st_assert(_st, _pb == 0, string(_pb) + " of " + string(array_length(_ot)) + " poses differ");
    var _oh = tra_oracle_hearts(); _bad = 0;
    for (var _h = 0; _h < array_length(_oh); _h++) { var _hc = tra_heart_cell(_polys[_h]); if (_hc[0] != _oh[_h][0] || _hc[1] != _oh[_h][1]) _bad++; }
    tra_st_assert(_st, _bad == 0, string(_bad) + " of 12 heart cells differ");
    var _ml = tra_oracle_mask_loops(), _mb = 0, _loopsSeen = 0;
    for (var _z = 0; _z < array_length(_ml); _z++) {
        var _Z = _ml[_z], _mk = tra_mask(_Z[0], _Z[1], _Z[2]), _cells = [];
        for (var _c = 0; _c < array_length(_mk); _c++) if (_mk[_c]) array_push(_cells, [_c mod _Z[1], floor(_c / _Z[1])]);
        var _lp = tra_outline(_cells), _okz = tra_st_loops_eq(_lp, _Z[3]);
        for (var _y = 0; _okz && _y < array_length(_lp); _y++) if (!tra_st_pts_eq(tra_inset(_lp[_y], -0.07), _Z[4][_y])) _okz = false;
        _loopsSeen += array_length(_lp);
        if (!_okz) { _mb++; if (_mb <= 3) array_push(_st.notes, "tray outline " + _Z[0] + " " + string(_Z[1]) + "x" + string(_Z[2])); }
    }
    tra_st_assert(_st, _mb == 0 && _loopsSeen >= 36, string(_mb) + " of " + string(array_length(_ml)) + " tray outlines differ (" + string(_loopsSeen) + " loops)");
    math_set_epsilon(_eps);
}

/// @function tra_st_count(painter, w, h)
/// @description Run a painter on a fresh context over a w x h surface (layer clips need a target); returns its counts.
function tra_st_count(_painter, _w, _h) {
    var _sf = surface_create(_w, _h);
    var _m = tra__bake_begin(_sf);
    var _c = tra_cx_create(1);
    _painter(_c);
    tra__bake_end(_m);
    surface_free(_sf);
    return _c.counts;
}

/// @function tra_selftest_draws(st)
/// @description Every drawn thing the oracle recorded, drawn by the port on a counting context: beginPath, fill, stroke
/// and fillRect must all agree with the original.
function tra_selftest_draws(_st) {
    var _od = tra_oracle_draws2(), _hard = tra_oracle_hard_tray(), _trays = tra_oracle_trays(), _cases = tra_oracle_piece_cases(), _bad = 0, _t0 = get_timer();
    var _woods = tra_woods();
    for (var _d = 0; _d < array_length(_od); _d++) {
        var _D = _od[_d];
        var _data = { nm: _D.name, hard: _hard, trays: _trays, cases: _cases, woods: _woods };
        var _cnt = tra_st_count(method(_data, function(_c) {
            if (nm == "table") { tra_draw_table(_c, 816, 624); return; }
            for (var _w = 0; _w < 10; _w++) {
                if (nm == "grain_" + woods[_w]) { tra_draw_grain(_c, woods[_w], 1000 + _w * 37, 160, 80); return; }
                if (nm == "grain_tall_" + woods[_w]) { tra_draw_grain(_c, woods[_w], 5000 + _w * 11, 63.5, 211.7); return; }
            }
            if (string_pos("motif_", nm) == 1) {
                var _rest = string_delete(nm, 1, 6), _cut = string_last_pos("_", _rest);
                tra_draw_motif(_c, string_copy(_rest, 1, _cut - 1), 30, string_delete(_rest, 1, _cut));
                return;
            }
            if (nm == "piece_default") { tra_draw_piece(_c, hard.pieces[0], 50, 60, 40); return; }
            if (string_pos("piece_", nm) == 1) {
                var _k = real(string_delete(nm, 1, 6)), _pc = cases[_k];
                var _o = { rot: _pc.rot, flip: _pc.flip, shadow: _pc.shadow };
                if (is_array(_pc.glow)) _o.glow = _pc.glow;
                tra_draw_piece(_c, hard.pieces[_pc.i], 100, 100, _pc.s, _o);
                return;
            }
            for (var _t = 0; _t < array_length(trays); _t++) if (nm == "case_" + trays[_t][0]) { tra_draw_case(_c, 408, 300, trays[_t][1], 36); return; }
            if (nm == "parts_box") { tra_draw_parts_box(_c, 24, 400, 768, 200); return; }
            if (nm == "title_sub") { tra_draw_title(_c, 250, 12, 316, 50, "Tray", "easy, a rect tray"); return; }
            if (nm == "title_plain") { tra_draw_title(_c, 250, 12, 316, 50, "Tray"); return; }
            if (nm == "card_limit") { tra_draw_card(_c, 200, 90, { placed: 3, total: 7, moves: 12, hints: 1, hintsLeft: 2 }); return; }
            if (nm == "card_free") { tra_draw_card(_c, 200, 90, { placed: 7, total: 7, moves: 30, hints: 4, hintsLeft: -1 }); return; }
            if (nm == "plaques") { tra_draw_plaque(_c, 6, 6, 130, 32, "Turn", "idle"); tra_draw_plaque(_c, 148, 6, 130, 32, "Hint", "on"); tra_draw_plaque(_c, 290, 6, 130, 32, "Flip", "off"); return; }
            if (nm == "status_text") { tra_draw_status(_c, 400, 30, "Pick a piece."); return; }
            if (nm == "status_empty") { tra_draw_status(_c, 400, 30, ""); return; }
            if (nm == "ghost_fit") { tra_draw_ghost(_c, hard.pieces[1].cells, 2, 2, 36, true); return; }
            if (nm == "ghost_bad") { tra_draw_ghost(_c, hard.pieces[2].cells, 2, 2, 36, false); return; }
            if (nm == "pointer") { tra_draw_pointer(_c, 26, 30); return; }
            if (nm == "sheen") { tra_draw_sheen(_c, 140, 300); return; }
            if (nm == "verdict_hard") { tra_draw_verdict(_c, 816, 624, hard, hard.placed, { title: "Solved", sub: "in 12 moves", foot: "Press OK." }); return; }
            if (nm == "verdict_round") { var _tr = trays[3][1]; tra_draw_verdict(_c, 816, 624, _tr, _tr.placed, { title: "Solved", sub: "in 12 moves", foot: "Press OK." }); return; }
            _c.counts.path = -1000000;   // a name the dispatcher does not know: a guaranteed mismatch, never a silent skip
        }), 816, 624);
        var _same = (_cnt.path == _D.path) && (_cnt.fill == _D.fill) && (_cnt.stroke == _D.stroke) && (_cnt.rect == _D.rect);
        if (!_same) { _bad++; if (_bad <= 12) array_push(_st.notes, "ops " + _D.name + ": gml p" + string(_cnt.path) + " f" + string(_cnt.fill) + " s" + string(_cnt.stroke) + " r" + string(_cnt.rect) + " vs p" + string(_D.path) + " f" + string(_D.fill) + " s" + string(_D.stroke) + " r" + string(_D.rect)); }
    }
    tra_st_assert(_st, _bad == 0 && array_length(_od) >= 100, string(_bad) + " of " + string(array_length(_od)) + " drawn things differ from the original op for op");
    _st.metrics.drawsCompared = array_length(_od);
    _st.metrics.drawsMs = (get_timer() - _t0) / 1000;
}

/// @function tra_st_grab(surface)
/// @description The surface's bytes (R, G, B, A per pixel - Doctrine_Craft s13). Free the buffer with buffer_delete.
function tra_st_grab(_sf) {
    var _w = surface_get_width(_sf), _h = surface_get_height(_sf);
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    return { w: _w, h: _h, b: _b };
}

/// @function tra_st_ink(grab, x0, y0, x1, y1, ground)
/// @description Pixels in a rect (every row, every second column) differing from the ground [r, g, b, a] by more than
/// 30 summed over the four bytes.
function tra_st_ink(_g, _x0, _y0, _x1, _y1, _gr) {
    var _n = 0;
    for (var _y = max(0, floor(_y0)); _y < min(_g.h, _y1); _y++) for (var _x = max(0, floor(_x0)); _x < min(_g.w, _x1); _x += 2) {
        var _o = (_y * _g.w + _x) * 4;
        if (abs(buffer_peek(_g.b, _o, buffer_u8) - _gr[0]) + abs(buffer_peek(_g.b, _o + 1, buffer_u8) - _gr[1]) + abs(buffer_peek(_g.b, _o + 2, buffer_u8) - _gr[2]) + abs(buffer_peek(_g.b, _o + 3, buffer_u8) - _gr[3]) > 30) _n++;
    }
    return _n;
}

/// @function tra_st_sheet(w, h, ss, ground_rgb, painter)
/// @description Render a design-space sheet at scale ss onto an opaque ground; returns the surface (free it).
function tra_st_sheet(_w, _h, _ss, _ground, _painter) {
    var _sf = surface_create(ceil(_w * _ss), ceil(_h * _ss));
    var _m = tra__bake_begin(_sf);
    draw_clear(tra_col(_ground));
    var _c = tra_cx_create(_ss);
    _painter(_c);
    tra__bake_end(_m);
    return _sf;
}

/// @function tra_selftest_renders(st)
/// @description The pictures a buyer sees, saved as PNGs for LOOKING (tra_render_*.png beside the result file): the 100
/// wood x inlay pieces (every one inked, against a blank control), the six trays filled, the room, the finished panel.
/// Bake costs are timed part by part.
function tra_selftest_renders(_st) {
    var _woods = tra_woods(), _inlays = tra_inlays(), _ground = [38, 27, 20];
    // the blank control: the ground's own bytes, read off a surface (never assumed)
    var _bs = tra_st_sheet(100, 100, 1, _ground, function(_c) { });
    var _bg = tra_st_grab(_bs), _gr = [buffer_peek(_bg.b, 0, buffer_u8), buffer_peek(_bg.b, 1, buffer_u8), buffer_peek(_bg.b, 2, buffer_u8), buffer_peek(_bg.b, 3, buffer_u8)];
    var _blankInk = tra_st_ink(_bg, 0, 0, 100, 100, _gr);
    buffer_delete(_bg.b); surface_free(_bs);
    tra_st_assert(_st, _blankInk == 0, "the blank control read " + string(_blankInk) + " ink pixels");
    _st.metrics.groundBytes = _gr;
    // 1. the contact sheet: ten woods (rows) x ten inlays (columns), one P-pentomino each, the id choosing the material
    var _CW = 98, _CH = 106, _S = 26, _SS = 1.6, _t1 = get_timer();
    var _data = { woods: _woods, inlays: _inlays, CW: _CW, CH: _CH, S: _S };
    var _sf = tra_st_sheet(_CW * 10 + 40, _CH * 10 + 30, _SS, _ground, method(_data, function(_c) {
        for (var _r = 0; _r < 10; _r++) for (var _k = 0; _k < 10; _k++) {
            var _pc = { id: _k, cells: [[0, 0], [1, 0], [0, 1], [1, 1], [0, 2]], wood: woods[_r], inlay: inlays[_k] };
            tra_draw_piece(_c, _pc, 30 + _k * CW + (CW - 2 * S) / 2 - 6, 22 + _r * CH + (CH - 3 * S) / 2 - 8, S, { shadow: 0.25 });
        }
    }));
    _st.metrics.contactSheetMs = (get_timer() - _t1) / 1000;
    var _g = tra_st_grab(_sf), _empty = 0, _minInk = 1000000;
    for (var _r2 = 0; _r2 < 10; _r2++) for (var _k2 = 0; _k2 < 10; _k2++) {
        var _x0 = (30 + _k2 * _CW) * _SS, _y0 = (22 + _r2 * _CH) * _SS, _ink = tra_st_ink(_g, _x0, _y0, _x0 + _CW * _SS * 0.9, _y0 + _CH * _SS * 0.9, _gr);
        _minInk = min(_minInk, _ink);
        if (_ink < 400) _empty++;
    }
    buffer_delete(_g.b);
    tra_st_assert(_st, _empty == 0, string(_empty) + " of 100 wood x inlay cells carry under 400 ink pixels (min " + string(_minInk) + ")");
    _st.metrics.contactMinInk = _minInk;
    surface_save(_sf, "tra_render_woods.png"); surface_free(_sf);
    // 2. six trays, every piece home
    var _trays = tra_oracle_trays(), _t2 = get_timer();
    _sf = tra_st_sheet(1560, 840, 1.2, _ground, method({ trays: _trays }, function(_c) {
        for (var _i = 0; _i < 6; _i++) {
            var _tr = trays[_i][1], _s = min(floor(400 / _tr.w), floor(300 / _tr.h), 46);
            var _geo = tra_draw_case(_c, 260 + (_i mod 3) * 520, 210 + floor(_i / 3) * 420, _tr, _s);
            for (var _p = 0; _p < array_length(_tr.pieces); _p++) {
                var _pl = _tr.placed[_p], _pose = tra_pose_of(_tr.pieces[_p].cells, _pl.cells);
                tra_draw_piece(_c, _tr.pieces[_p], _geo.x + _pl.x * _s, _geo.y + _pl.y * _s, _s, { rot: _pose.rot, flip: _pose.flip, shadow: 0 });
            }
        }
    }));
    _st.metrics.sixTraysMs = (get_timer() - _t2) / 1000;
    surface_save(_sf, "tra_render_trays.png"); surface_free(_sf);
    // 3. the room at 2x, part by part: table, case (hard tray, half the pieces home), parts box, the loose pieces, title
    var _hard = tra_oracle_hard_tray(), _parts = {}, _t3 = get_timer();
    _sf = surface_create(1632, 1248);
    var _m = tra__bake_begin(_sf), _c3 = tra_cx_create(2), _tp = get_timer();
    tra_draw_table(_c3, 816, 624); _parts.table = (get_timer() - _tp) / 1000; _tp = get_timer();
    var _geo3 = tra_draw_case(_c3, 300, 250, _hard, 40); _parts.caseBoard = (get_timer() - _tp) / 1000; _tp = get_timer();
    tra_draw_parts_box(_c3, 560, 120, 236, 440); _parts.partsBox = (get_timer() - _tp) / 1000; _tp = get_timer();
    var _loose = 0;
    for (var _q = 0; _q < array_length(_hard.pieces); _q++) {
        var _pl3 = _hard.placed[_q];
        if (_q mod 2 == 0) { var _ps = tra_pose_of(_hard.pieces[_q].cells, _pl3.cells); tra_draw_piece(_c3, _hard.pieces[_q], _geo3.x + _pl3.x * 40, _geo3.y + _pl3.y * 40, 40, { rot: _ps.rot, flip: _ps.flip, shadow: 0 }); }
        else { tra_draw_piece(_c3, _hard.pieces[_q], 585 + (_loose mod 2) * 100, 150 + floor(_loose / 2) * 140, 30, { rot: _q mod 4, flip: false, shadow: (_q == 3) ? 1 : 0.25, glow: (_q == 3) ? [255, 230, 140, 0.9] : undefined }); _loose++; }
    }
    _parts.pieces = (get_timer() - _tp) / 1000; _tp = get_timer();
    tra_draw_title(_c3, 150, 14, 300, 50, "A Hard Tray", "ten pieces, a rect tray");
    tra_draw_ghost(_c3, [[0, 0], [1, 0], [1, 1]], _geo3.x + 40 * 1, _geo3.y + 40 * 2, 40, true);
    tra_cx_save(_c3); tra_cx_translate(_c3, 672, 112); tra_draw_pointer(_c3, 26, 30); tra_cx_restore(_c3);
    tra__bake_end(_m);
    _parts.total = (get_timer() - _t3) / 1000;
    _st.metrics.roomBakeMs = _parts;
    surface_save(_sf, "tra_render_room.png"); surface_free(_sf);
    // 4. the finished panel
    var _t4 = get_timer();
    _sf = tra_st_sheet(816, 624, 2, [0, 0, 0], method({ hard: _hard }, function(_c) { tra_draw_verdict(_c, 816, 624, hard, hard.placed, { title: "Solved in 24 moves", sub: "a hard tray of ten pieces, no hints", foot: "Press OK to continue." }); }));
    _st.metrics.verdictMs = (get_timer() - _t4) / 1000;
    surface_save(_sf, "tra_render_verdict.png"); surface_free(_sf);
    // 5. cards, plaques, status, pointer on one strip
    _sf = tra_st_sheet(820, 220, 2, _ground, function(_c) {
        tra_cx_save(_c); tra_cx_translate(_c, 10, 10); tra_draw_card(_c, 200, 90, { placed: 3, total: 7, moves: 12, hints: 1, hintsLeft: 2 }); tra_cx_restore(_c);
        tra_draw_plaque(_c, 230, 20, 130, 32, "Turn", "idle"); tra_draw_plaque(_c, 372, 20, 130, 32, "Hint", "on"); tra_draw_plaque(_c, 514, 20, 130, 32, "Flip", "off");
        tra_cx_save(_c); tra_cx_translate(_c, 230, 70); tra_draw_status(_c, 400, 30, "Pick a piece, then a square for it."); tra_cx_restore(_c);
        tra_cx_save(_c); tra_cx_translate(_c, 700, 20); tra_draw_pointer(_c, 26, 30); tra_cx_restore(_c);
        tra_draw_title(_c, 230, 120, 316, 50, "Tray", "easy, a rect tray");
    });
    surface_save(_sf, "tra_render_cards.png"); surface_free(_sf);
}

/// @function tra_selftest_write(st)
function tra_selftest_write(_st) {
    var _f = file_text_open_write("tra_selftest.json");
    file_text_write_string(_f, json_stringify(_st));
    file_text_close(_f);
}
