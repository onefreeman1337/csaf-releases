/// tra_draw.gml - the marquetry, drawn in code onto the canvas kit (tra_canvas): ten woods with their own grain and
/// figure, ten inlaid motifs in brass, mother-of-pearl, holly or ebony, the stringing run inside every piece's edge, the
/// bevels and varnish, the ebonised case with the tray's shape sunk into it and lined with baize, the parts box, the
/// workbench, the brass title plate and plaques, the tally card, the ghost a carried piece casts, the pointer, and the
/// finished panel. No image file is loaded anywhere.
///
/// Tray - Generated Packing Puzzles in Wood, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⛔ A PORT HELD TO ITS ORIGINAL (TrayDraw.js 1.0.0, the published RPG Maker MZ Tray): every beginPath / fill / stroke /
/// fillRect of the original is made here in the same order, every random draw in its own statement in JavaScript's
/// order (GML evaluates an expression's calls right to left), and the suite compares the counts per drawn thing and the
/// pure geometry (turns, outlines, insets, poses, heart cells) with values the original computed (tra_oracle_draw.gml).
/// Every public draw function runs with the comparison epsilon at ZERO and restores the caller's (a loop bound the
/// original decides exactly can flip under GML's default 0.00001). Coordinates are the original's design pixels; a
/// context's base transform scales them (a bake runs at 2x and is filtered down).
/// Three DELIBERATE departures, each keeping every compared count:
///   1. an inlay's "cut" (`translate(0.8, 1); fill()` in the original) lands exactly UNDER the inlay on a canvas, because
///      a canvas transforms a path when it is BUILT, not when it is filled - here it is offset down and right as the code
///      intended, so every inlay sits in a visible cut (tra__fill_offset);
///   2. the canvas shadowBlur (four sites: a lifted piece, the recess walls, the parts box walls, the pointer) is drawn by
///      tra_cx_shadow, a gaussian of the canvas's own sigma - GameMaker has no shadow;
///   3. type is Libre Baskerville from shipped ASCII atlases (the original asks the system for Palatino), so the finished
///      panel's list of woods is joined with ", " - the original's middle dot is not in the atlas and would draw nothing.

// ---------------------------------------------------------------------------------------------------------------
// Tables
// ---------------------------------------------------------------------------------------------------------------

/// @function tra_wood(name)
/// @description The wood a piece is cut from: {name, base, light, dark, streak (the grain lines), figure (the pattern
/// the species is known for: "cathedral", "curl", "ray", "streak", "wild", "fine"), pores (0..1), lum (how light it
/// reads)}; colours are [r, g, b]. One of tra_woods(); anything else reads as oak. Pure.
function tra_wood(_w) {
    switch (_w) {
        case "walnut": return { name: "Walnut", base: [90, 58, 34], light: [122, 83, 52], dark: [53, 32, 15], streak: [36, 20, 10], figure: "cathedral", pores: 0.8, lum: 0.28 };
        case "maple": return { name: "Maple", base: [227, 204, 156], light: [242, 226, 187], dark: [201, 173, 120], streak: [184, 149, 92], figure: "curl", pores: 0.1, lum: 0.82 };
        case "cherry": return { name: "Cherry", base: [168, 88, 58], light: [196, 114, 77], dark: [126, 60, 36], streak: [94, 42, 22], figure: "cathedral", pores: 0.25, lum: 0.45 };
        case "ebony": return { name: "Ebony", base: [36, 28, 24], light: [58, 46, 38], dark: [18, 12, 10], streak: [74, 60, 48], figure: "fine", pores: 0.05, lum: 0.1 };
        case "ash": return { name: "Ash", base: [214, 192, 154], light: [232, 214, 178], dark: [179, 154, 112], streak: [138, 112, 72], figure: "cathedral", pores: 0.9, lum: 0.75 };
        case "rosewood": return { name: "Rosewood", base: [92, 42, 38], light: [122, 60, 52], dark: [54, 20, 18], streak: [28, 8, 6], figure: "streak", pores: 0.5, lum: 0.22 };
        case "yew": return { name: "Yew", base: [196, 122, 68], light: [220, 154, 98], dark: [154, 84, 40], streak: [122, 60, 24], figure: "wild", pores: 0.1, lum: 0.55 };
        case "olive": return { name: "Olive", base: [184, 160, 104], light: [210, 188, 132], dark: [138, 116, 64], streak: [62, 48, 20], figure: "wild", pores: 0.2, lum: 0.62 };
        case "holly": return { name: "Holly", base: [237, 228, 208], light: [248, 242, 228], dark: [214, 204, 180], streak: [191, 178, 152], figure: "fine", pores: 0.05, lum: 0.92 };
    }
    return { name: "Oak", base: [181, 140, 88], light: [205, 166, 118], dark: [142, 106, 60], streak: [106, 74, 36], figure: "ray", pores: 1, lum: 0.6 };
}

/// @function tra_material(name)
/// @description An inlay material: {name, stops (gradient colours), edge, lum} - "brass", "pearl" (mother-of-pearl),
/// "holly", "ebony"; anything else reads as brass. Pure.
function tra_material(_m) {
    switch (_m) {
        case "pearl": return { name: "mother-of-pearl", stops: [[251, 250, 246], [223, 234, 242], [243, 223, 233], [232, 226, 204]], edge: [122, 116, 104], lum: 0.92 };
        case "holly": return { name: "holly", stops: [[251, 246, 234], [236, 226, 200]], edge: [138, 122, 90], lum: 0.9 };
        case "ebony": return { name: "ebony", stops: [[58, 48, 42], [18, 12, 10]], edge: [0, 0, 0], lum: 0.08 };
    }
    return { name: "brass", stops: [[251, 231, 164], [217, 170, 74], [154, 106, 28]], edge: [90, 58, 8], lum: 0.7 };
}

/// @function tra_material_for(wood, id)
/// @description The inlay material that shows best against a wood: pale materials on dark woods, ebony on pale ones,
/// brass in the middle; the piece's id chooses among them. Pure.
function tra_material_for(_wood, _id) {
    var _L = tra_wood(_wood).lum, _k = is_numeric(_id) ? floor(abs(_id)) : 0;
    if (_L < 0.35) { var _dark = ["brass", "pearl", "holly"]; return _dark[_k mod 3]; }
    if (_L > 0.72) { var _pale = ["ebony", "brass"]; return _pale[_k mod 2]; }
    var _mid = ["brass", "ebony", "holly"];
    return _mid[_k mod 3];
}

// ---------------------------------------------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------------------------------------------

/// @function tra__is_ctx(ctx)
/// @description A drawing context made by tra_cx_create. Internal, pure.
function tra__is_ctx(_c) { return is_struct(_c) && variable_struct_exists(_c, "m") && variable_struct_exists(_c, "counts") && variable_struct_exists(_c, "clips"); }

/// @function tra__is_piece(piece)
/// @description A piece the drawing can draw: {cells: [[x, y], ...]} with at least one square (wood, inlay and id default).
/// Internal, pure.
function tra__is_piece(_q) {
    if (!is_struct(_q) || !variable_struct_exists(_q, "cells") || !is_array(_q.cells) || array_length(_q.cells) == 0) return false;
    for (var _i = 0; _i < array_length(_q.cells); _i++) { var _c = _q.cells[_i]; if (!is_array(_c) || array_length(_c) < 2 || !is_numeric(_c[0]) || !is_numeric(_c[1])) return false; }
    return true;
}

/// @function tra__is_tray(puzzle)
/// @description A tray the case can draw: {w, h, mask (w x h)}. Internal, pure.
function tra__is_tray(_p) {
    return is_struct(_p) && variable_struct_exists(_p, "w") && variable_struct_exists(_p, "h") && variable_struct_exists(_p, "mask")
        && is_numeric(_p.w) && is_numeric(_p.h) && _p.w >= 1 && _p.h >= 1 && is_array(_p.mask) && array_length(_p.mask) == _p.w * _p.h;
}

/// @function tra__eps0()
/// @description Set the comparison epsilon to zero; returns the caller's (restore it with math_set_epsilon). Internal.
function tra__eps0() { var _e = math_get_epsilon(); math_set_epsilon(0); return _e; }

/// @function tra_rr(ctx, x, y, w, h, r)
/// @description The original's rounded rectangle: a new path, four arcTo corners, closed.
function tra_rr(_c, _x, _y, _w, _h, _r) {
    if (!tra__is_ctx(_c) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w) || !is_numeric(_h) || !is_numeric(_r)) return;
    tra_cx_begin(_c);
    tra_cx_move(_c, _x + _r, _y);
    tra_cx_arc_to(_c, _x + _w, _y, _x + _w, _y + _h, _r);
    tra_cx_arc_to(_c, _x + _w, _y + _h, _x, _y + _h, _r);
    tra_cx_arc_to(_c, _x, _y + _h, _x, _y, _r);
    tra_cx_arc_to(_c, _x, _y, _x + _w, _y, _r);
    tra_cx_close(_c);
}

/// @function tra__solid(ctx, rgb, [a])
/// @description Set the fill to a flat colour. Internal.
function tra__solid(_c, _rgb, _a = 1) { _c.fill = tra_cx_solid(_rgb, _a); }

/// @function tra__pen(ctx, rgb, [a], [width])
/// @description Set the stroke to a flat colour (and the line width when given). Internal.
function tra__pen(_c, _rgb, _a = 1, _w = undefined) { _c.stroke = tra_cx_solid(_rgb, _a); if (!is_undefined(_w)) _c.lw = _w; }

/// @function tra__lin(ctx, x0, y0, x1, y1, stops)
/// @description A linear gradient with stops [[t, rgb, a], ...]. Internal.
function tra__lin(_c, _x0, _y0, _x1, _y1, _stops) {
    var _g = tra_cx_linear(_c, _x0, _y0, _x1, _y1);
    for (var _i = 0; _i < array_length(_stops); _i++) tra_cx_stop(_g, _stops[_i][0], _stops[_i][1], (array_length(_stops[_i]) > 2) ? _stops[_i][2] : 1);
    return _g;
}

/// @function tra__rad(ctx, x0, y0, r0, x1, y1, r1, stops)
/// @description A radial gradient with stops [[t, rgb, a], ...]. Internal.
function tra__rad(_c, _x0, _y0, _r0, _x1, _y1, _r1, _stops) {
    var _g = tra_cx_radial(_c, _x0, _y0, _r0, _x1, _y1, _r1);
    for (var _i = 0; _i < array_length(_stops); _i++) tra_cx_stop(_g, _stops[_i][0], _stops[_i][1], (array_length(_stops[_i]) > 2) ? _stops[_i][2] : 1);
    return _g;
}

/// @function tra__fill_offset(ctx, dx, dy, rule)
/// @description Fill the current path shifted by (dx, dy) canvas pixels down and right ON THE SCREEN (the base scale
/// applies, the current transform does not), counted as ONE fill. The inlay's cut (see the header). Internal.
function tra__fill_offset(_c, _dx, _dy, _rule) {
    _c.counts.fill++;
    var _ox = _dx * _c.ss, _oy = _dy * _c.ss, _src = tra_cx__rings(_c), _rings = [];
    for (var _r = 0; _r < array_length(_src); _r++) {
        var _ring = _src[_r], _cp = array_create(array_length(_ring));
        for (var _i = 0; _i < array_length(_ring); _i++) _cp[_i] = [_ring[_i][0] + _ox, _ring[_i][1] + _oy];
        array_push(_rings, _cp);
    }
    tra_cx__fill(_c, _rings, _c.fill, _c.alpha, _rule);
}

/// @function tra_dtext(ctx, string, x, y, px, style, rgb, [alpha], [halign])
/// @description Type `px` design pixels tall at a design point under the context's transform, vertically centred (the
/// original's textBaseline "middle"). style: "bold", "italic" or "" (regular). Returns the drawn width in device px.
function tra_dtext(_c, _s, _x, _y, _px, _style, _rgb, _a = 1, _ha = fa_center) {
    if (!tra__is_ctx(_c) || !is_numeric(_x) || !is_numeric(_y) || !(is_numeric(_px) && _px > 0)) return 0;
    var _p = tra_cx__pt(_c, _x, _y), _k = tra_cx__scale(_c), _dpx = _px * _k;
    return tra_text(_p[0], _p[1], _s, _dpx, tra_col(_rgb), _ha, fa_middle, tra_font_for(_dpx, _style), _a * _c.alpha);
}

/// @function tra_fit_text(string, max_w, size, [style])
/// @description The original's fitText: the largest size (down to 9) at which the string fits max_w design pixels,
/// measured in the atlas a 2x bake draws it from. Pure.
function tra_fit_text(_s, _maxW, _size, _style = "bold") {
    while (_size > 9 && tra_text_w(_s, _size, tra_font_for(_size * 2, _style)) > _maxW) _size--;
    return _size;
}

// ---------------------------------------------------------------------------------------------------------------
// Geometry (pure)
// ---------------------------------------------------------------------------------------------------------------

/// @function tra_turn(cells, rot, flip)
/// @description Turn (quarter turns clockwise) and flip (mirror left-right, first) a piece's cells. Returns {cells (the
/// turned cells, sorted by row then column), m (the matrix [a, b, c, d, e, f] carrying the piece's own frame, in cell
/// units, into the turned one), w, h}. Pure.
function tra_turn(_cells, _rot, _flip) {
    if (!tra__is_piece({ cells: _cells })) return { cells: [], m: [1, 0, 0, 1, 0, 0], w: 0, h: 0 };
    var _bw = 0, _bh = 0, _k, _n = array_length(_cells);
    for (_k = 0; _k < _n; _k++) { if (_cells[_k][0] + 1 > _bw) _bw = _cells[_k][0] + 1; if (_cells[_k][1] + 1 > _bh) _bh = _cells[_k][1] + 1; }
    var _a = 1, _b = 0, _cc = 0, _d = 1;
    if (_flip) _a = -1;
    var _turns = (is_numeric(_rot) ? floor(_rot) : 0) & 3;
    for (_k = 0; _k < _turns; _k++) { var _na = -_b, _nb = _a, _nc = -_d, _nd = _cc; _a = _na; _b = _nb; _cc = _nc; _d = _nd; }   // (x, y) -> (-y, x) on screen
    var _e = -min(0, _bw * _a, _bh * _cc, _bw * _a + _bh * _cc), _f = -min(0, _bw * _b, _bh * _d, _bw * _b + _bh * _d);
    var _out = array_create(_n);
    for (_k = 0; _k < _n; _k++) { var _cx = _cells[_k][0] + 0.5, _cy = _cells[_k][1] + 0.5; _out[_k] = [floor(_a * _cx + _cc * _cy + _e), floor(_b * _cx + _d * _cy + _f)]; }
    array_sort(_out, function(_p, _q) { if (_p[1] != _q[1]) return (_p[1] < _q[1]) ? -1 : 1; if (_p[0] != _q[0]) return (_p[0] < _q[0]) ? -1 : 1; return 0; });
    return { cells: _out, m: [_a, _b, _cc, _d, _e, _f], w: (_turns & 1) ? _bh : _bw, h: (_turns & 1) ? _bw : _bh };
}

/// @function tra__cells_key(cells)
/// @description A cell list's spelling, sorted (the original's poseOf key). Internal, pure.
function tra__cells_key(_cs) {
    var _s = array_create(array_length(_cs));
    for (var _i = 0; _i < array_length(_cs); _i++) _s[_i] = [_cs[_i][0], _cs[_i][1]];
    array_sort(_s, function(_p, _q) { if (_p[1] != _q[1]) return (_p[1] < _q[1]) ? -1 : 1; if (_p[0] != _q[0]) return (_p[0] < _q[0]) ? -1 : 1; return 0; });
    var _o = "";
    for (var _j = 0; _j < array_length(_s); _j++) _o += ((_j > 0) ? ";" : "") + string(_s[_j][0]) + "," + string(_s[_j][1]);
    return _o;
}

/// @function tra_pose_of(cells, target)
/// @description The {rot, flip} that turns `cells` into `target` (both cell lists), or undefined. Pure.
function tra_pose_of(_cells, _target) {
    var _want = tra__cells_key(_target);
    for (var _f = 0; _f < 2; _f++) for (var _r = 0; _r < 4; _r++) if (tra__cells_key(tra_turn(_cells, _r, _f == 1).cells) == _want) return { rot: _r, flip: (_f == 1) };
    return undefined;
}

/// @function tra__ol_add(state, x1, y1, x2, y2)
/// @description Add a directed cell edge to the outline's edge set, or cancel it against its reverse (a shared edge
/// between two cells). Keeps the original's INSERTION ORDER (a JavaScript object's key order decides where each loop
/// starts). Internal.
function tra__ol_add(_S, _x1, _y1, _x2, _y2) {
    var _r = string(_x2) + "," + string(_y2) + ">" + string(_x1) + "," + string(_y1);
    if (variable_struct_exists(_S.at, _r)) { var _i = _S.at[$ _r]; _S.alive[_i] = false; variable_struct_remove(_S.at, _r); return; }
    var _f = string(_x1) + "," + string(_y1) + ">" + string(_x2) + "," + string(_y2);
    _S.at[$ _f] = array_length(_S.vals);
    array_push(_S.vals, [_x1, _y1, _x2, _y2]);
    array_push(_S.alive, true);
}

/// @function tra_outline(cells)
/// @description The outline of a set of cells: closed loops of corner points (cell units), clockwise on screen, with
/// the points in the middle of a straight run dropped. At a pinch (two cells meeting at a corner) the walk takes the
/// right-most turn so each loop stays simple. Pure.
function tra_outline(_cells) {
    var _S = { at: {}, vals: [], alive: [] }, _k;
    for (_k = 0; _k < array_length(_cells); _k++) {
        var _x = _cells[_k][0], _y = _cells[_k][1];
        tra__ol_add(_S, _x, _y, _x + 1, _y); tra__ol_add(_S, _x + 1, _y, _x + 1, _y + 1); tra__ol_add(_S, _x + 1, _y + 1, _x, _y + 1); tra__ol_add(_S, _x, _y + 1, _x, _y);
    }
    // edges by start point, the start points in first-seen order
    var _fk = [], _fl = {}, _left = 0;
    for (var _i = 0; _i < array_length(_S.vals); _i++) {
        if (!_S.alive[_i]) continue;
        var _e = _S.vals[_i], _s = string(_e[0]) + "," + string(_e[1]);
        if (!variable_struct_exists(_fl, _s)) { _fl[$ _s] = []; array_push(_fk, _s); }
        var _l0 = _fl[$ _s], _l1 = array_create(array_length(_l0) + 1);
        for (var _q = 0; _q < array_length(_l0); _q++) _l1[_q] = _l0[_q];
        _l1[array_length(_l0)] = _i;
        _fl[$ _s] = _l1;
        _left++;
    }
    var _loops = [];
    while (_left > 0) {
        var _start = -1;
        for (var _z = 0; _z < array_length(_fk); _z++) { var _lz = _fl[$ _fk[_z]]; if (array_length(_lz) > 0) { _start = _lz[0]; break; } }
        if (_start < 0) break;
        var _loop = [], _cur = _start, _guard = 0;
        while (_cur >= 0 && _guard < 4000) {
            _guard++;
            var _ce = _S.vals[_cur], _ks = string(_ce[0]) + "," + string(_ce[1]), _list = _fl[$ _ks], _rest = [];
            for (var _u = 0; _u < array_length(_list); _u++) if (_list[_u] != _cur) array_push(_rest, _list[_u]);
            _fl[$ _ks] = _rest;
            _left--;
            array_push(_loop, [_ce[0], _ce[1]]);
            var _ke = string(_ce[2]) + "," + string(_ce[3]);
            if (!variable_struct_exists(_fl, _ke)) break;
            var _nx = _fl[$ _ke];
            if (array_length(_nx) == 0) break;
            var _dx = _ce[2] - _ce[0], _dy = _ce[3] - _ce[1], _pick = _nx[0];
            if (array_length(_nx) > 1) for (var _w = 0; _w < array_length(_nx); _w++) { var _xe = _S.vals[_nx[_w]], _ex = _xe[2] - _xe[0], _ey = _xe[3] - _xe[1]; if (_dx * _ey - _dy * _ex > 0) _pick = _nx[_w]; }
            _cur = _pick;
            if (_cur == _start) break;
        }
        // drop the points in the middle of a straight run
        var _clean = [], _n = array_length(_loop);
        for (_k = 0; _k < _n; _k++) {
            var _p = _loop[(_k + _n - 1) mod _n], _c = _loop[_k], _nn = _loop[(_k + 1) mod _n];
            if ((_c[0] - _p[0]) * (_nn[1] - _c[1]) - (_c[1] - _p[1]) * (_nn[0] - _c[0]) != 0) array_push(_clean, _c);
        }
        if (array_length(_clean) >= 4) array_push(_loops, _clean);
    }
    return _loops;
}

/// @function tra_inset(loop, d)
/// @description Move every edge of a clockwise right-angled loop inward by d (exact for right angles, convex and
/// reflex; a negative d moves it outward). Pure.
function tra_inset(_loop, _d) {
    var _n = array_length(_loop), _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _loop[(_i + _n - 1) mod _n], _c = _loop[_i], _q = _loop[(_i + 1) mod _n];
        var _d1x = sign(_c[0] - _p[0]), _d1y = sign(_c[1] - _p[1]), _d2x = sign(_q[0] - _c[0]), _d2y = sign(_q[1] - _c[1]);
        _out[_i] = [_c[0] + _d * (-_d1y + -_d2y), _c[1] + _d * (_d1x + _d2x)];
    }
    return _out;
}

/// @function tra_loop_path(ctx, loop, s, ox, oy, r)
/// @description Add a loop (cell units) to the current path at square size s with its top-left at (ox, oy): straight
/// corners when r is 0, otherwise every corner rounded with arcTo through the edges' midpoints.
function tra_loop_path(_c, _loop, _s, _ox, _oy, _r) {
    if (!tra__is_ctx(_c) || !is_array(_loop) || !is_numeric(_s) || !is_numeric(_ox) || !is_numeric(_oy)) return;
    var _n = array_length(_loop);
    if (_n == 0) return;
    if (!is_numeric(_r) || _r == 0) {
        tra_cx_move(_c, _ox + _loop[0][0] * _s, _oy + _loop[0][1] * _s);
        for (var _i = 1; _i < _n; _i++) tra_cx_line(_c, _ox + _loop[_i][0] * _s, _oy + _loop[_i][1] * _s);
        tra_cx_close(_c);
        return;
    }
    var _m0x = (_loop[_n - 1][0] + _loop[0][0]) / 2, _m0y = (_loop[_n - 1][1] + _loop[0][1]) / 2;
    tra_cx_move(_c, _ox + _m0x * _s, _oy + _m0y * _s);
    for (var _j = 0; _j < _n; _j++) {
        var _cc = _loop[_j], _nx = _loop[(_j + 1) mod _n], _mx = (_cc[0] + _nx[0]) / 2, _my = (_cc[1] + _nx[1]) / 2;
        tra_cx_arc_to(_c, _ox + _cc[0] * _s, _oy + _cc[1] * _s, _ox + _mx * _s, _oy + _my * _s, _r);
    }
    tra_cx_close(_c);
}

/// @function tra_heart_cell(cells)
/// @description The cell nearest the piece's centre of mass: where its inlay sits. Pure.
function tra_heart_cell(_cells) {
    var _sx = 0, _sy = 0, _k, _best = 0, _bd = infinity, _n = array_length(_cells);
    for (_k = 0; _k < _n; _k++) { _sx += _cells[_k][0] + 0.5; _sy += _cells[_k][1] + 0.5; }
    _sx /= _n; _sy /= _n;
    for (_k = 0; _k < _n; _k++) {
        var _dx = _cells[_k][0] + 0.5 - _sx, _dy = _cells[_k][1] + 0.5 - _sy, _d = _dx * _dx + _dy * _dy;
        if (_d < _bd - 0.000000001) { _bd = _d; _best = _k; }
    }
    return _cells[_best];
}

// ---------------------------------------------------------------------------------------------------------------
// The wood
// ---------------------------------------------------------------------------------------------------------------

/// @function tra_draw_grain(ctx, wood, seed, W, H)
/// @description A board of `wood` W x H in the board's own frame, the grain running along x: the colour ramp and its
/// drifts, grain lines that run side by side (ONE shared warp, a small jitter each), the species figure - cathedral
/// arches (flat-sawn), curl (maple's fiddleback), ray (oak's flecks), streak (rosewood), wild (olive and yew: knots and
/// swirls), fine - and the pores. Deterministic per seed.
function tra_draw_grain(_c, _wood, _seed, _W, _H) {
    if (!tra__is_ctx(_c) || !(is_numeric(_W) && _W > 0) || !(is_numeric(_H) && _H > 0)) return;
    var _eps = tra__eps0();
    var WD = tra_wood(_wood), _r = tra_rng(_seed), _i, _x, _y;
    var _g = tra_cx_linear(_c, 0, 0, 0, _H);
    tra_cx_stop(_g, 0, WD.light);
    var _mid = 0.45 + tra_rnd(_r) * 0.2;
    tra_cx_stop(_g, _mid, WD.base);
    tra_cx_stop(_g, 1, WD.dark);
    _c.fill = _g; tra_cx_fill_rect(_c, 0, 0, _W, _H);
    // broad colour drifts across the board
    for (_i = 0; _i < 4; _i++) {
        var _by = tra_rnd(_r) * _H;
        var _bh = _H * (0.15 + tra_rnd(_r) * 0.3);
        var _lightDrift = tra_rnd(_r) < 0.5;
        var _ba = 0.18 + tra_rnd(_r) * 0.18;
        tra__solid(_c, _lightDrift ? WD.light : WD.dark, _ba);
        tra_cx_fill_rect(_c, 0, _by - _bh / 2, _W, _bh);
    }
    // ⛔ (the original, 2026-09-28) grain lines in a board run side by side: they share ONE warp (phase varying slowly
    // with height) and differ only by a small jitter - lines with their own phases cross each other.
    var _lines = max(10, tra_jsround(_H / 3.2)), _wild = (WD.figure == "wild"), _amp = _wild ? _H * 0.12 : _H * 0.035, _freq = (_wild ? 1.1 : 1.6) / _W;
    var _P1 = tra_rnd(_r) * 6.28;
    var _P2 = tra_rnd(_r) * 6.28;
    var _k1 = (tra_rnd(_r) - 0.5) * 0.05;
    var _k2 = (tra_rnd(_r) - 0.5) * 0.08;
    _c.cap = 1;
    for (_i = 0; _i < _lines; _i++) {
        var _y0 = (_i + tra_rnd(_r) * 0.8) * _H / _lines;
        var _phj = tra_rnd(_r) * 6.28;
        var _aj = _amp * 0.1;
        var _lw = 0.5 + tra_rnd(_r) * ((WD.figure == "streak") ? 2.6 : 1.4);
        var _la = (WD.figure == "fine") ? 0.12 + tra_rnd(_r) * 0.12 : 0.14 + tra_rnd(_r) * 0.3;
        tra__pen(_c, WD.streak, _la, _lw);
        tra_cx_begin(_c);
        for (_x = -6; _x <= _W + 6; _x += 6) {
            _y = _y0 + _amp * sin(_x * _freq * 6.28 + _P1 + _y0 * _k1) + _amp * 0.35 * sin(_x * _freq * 14 + _P2 + _y0 * _k2) + _aj * sin(_x * _freq * 31 + _phj);
            if (_x == -6) tra_cx_move(_c, _x, _y); else tra_cx_line(_c, _x, _y);
        }
        tra_cx_stroke(_c);
    }
    if (WD.figure == "cathedral") {
        // nested arches: the flat-sawn heart of the board
        var _cx = _W * (0.25 + tra_rnd(_r) * 0.5);
        var _cy = _H * (0.3 + tra_rnd(_r) * 0.4);
        var _rings = 5 + floor(tra_rnd(_r) * 4);
        for (_i = 0; _i < _rings; _i++) {
            var _rw = _W * (0.1 + _i * 0.09), _rh = _H * (0.06 + _i * 0.05);
            tra__pen(_c, (_i mod 2 != 0) ? WD.dark : WD.streak, 0.28, 1 + (_i mod 2));
            tra_cx_begin(_c); tra_cx_move(_c, -10, _cy - _rh);
            tra_cx_bezier(_c, _cx - _rw, _cy - _rh, _cx - _rw * 0.6, _cy + _rh * 0.2, _cx, _cy + _rh * 0.25);
            tra_cx_bezier(_c, _cx + _rw * 0.6, _cy + _rh * 0.2, _cx + _rw, _cy - _rh, _W + 10, _cy - _rh);
            tra_cx_stroke(_c);
        }
    } else if (WD.figure == "curl") {
        // fiddleback: bands across the grain that catch the light
        _x = tra_rnd(_r) * 10;
        while (_x < _W) {
            var _gb = tra_cx_linear(_c, _x, 0, _x + 5, 0);
            tra_cx_stop(_gb, 0, WD.light, 0);
            var _lightBand = tra_rnd(_r) < 0.5;
            tra_cx_stop(_gb, 0.5, _lightBand ? WD.light : WD.dark, 0.35);
            tra_cx_stop(_gb, 1, WD.light, 0);
            _c.fill = _gb; tra_cx_fill_rect(_c, _x, 0, 5, _H);
            _x += 5 + tra_rnd(_r) * 7;
        }
    } else if (WD.figure == "ray") {
        // oak's silver flecks, long with the grain
        for (_i = 0; _i < _W * _H / 260; _i++) {
            var _fx = tra_rnd(_r) * _W;
            var _fy = tra_rnd(_r) * _H;
            var _fl = 3 + tra_rnd(_r) * 9;
            var _fa = 0.22 + tra_rnd(_r) * 0.25;
            tra__solid(_c, [244, 220, 176], _fa);
            tra_cx_begin(_c);
            var _fry = 0.8 + tra_rnd(_r) * 1.2;
            var _frot = (tra_rnd(_r) - 0.5) * 0.2;
            tra_cx_ellipse(_c, _fx, _fy, _fl, _fry, _frot, 0, 6.2832);
            tra_cx_fill(_c);
        }
    } else if (WD.figure == "wild") {
        // knots and swirls
        var _knots = 1 + floor(tra_rnd(_r) * 2);
        for (_i = 0; _i < _knots; _i++) {
            var _kx = tra_rnd(_r) * _W;
            var _ky = tra_rnd(_r) * _H;
            for (var _j = 0; _j < 6; _j++) { tra__pen(_c, WD.streak, 0.35 - _j * 0.04, 1.2); tra_cx_begin(_c); tra_cx_ellipse(_c, _kx, _ky, 2 + _j * 3.2, 1 + _j * 1.6, 0, 0, 6.2832); tra_cx_stroke(_c); }
            tra__solid(_c, WD.streak, 0.6); tra_cx_begin(_c); tra_cx_ellipse(_c, _kx, _ky, 2, 1.2, 0, 0, 6.2832); tra_cx_fill(_c);
        }
    }
    // pores: short dark ticks along the grain (one batch; each counted as the original's fillRect)
    var _pores = tra_jsround(_W * _H / 30 * WD.pores), _pc = tra_col(WD.streak), _list = array_create(max(0, _pores));
    for (_i = 0; _i < _pores; _i++) {
        var _px = tra_rnd(_r) * _W;
        var _py = tra_rnd(_r) * _H;
        var _pw = 1 + tra_rnd(_r) * 2.5;
        _list[_i] = [_px, _py, _pw, 0.8, _pc, 0.35];
    }
    tra_cx_fill_rects(_c, _list);
    math_set_epsilon(_eps);
}

// ---------------------------------------------------------------------------------------------------------------
// Inlay motifs
// ---------------------------------------------------------------------------------------------------------------

/// @function tra_draw_motif(ctx, motif, s, material)
/// @description One inlaid motif of size s centred on (0, 0) in a material: "star", "lozenge", "rosette", "bars",
/// "chevron", "dot", "ring", "cross", "leaf" or "wave" (anything else draws the wave), set into a cut, filled even-odd
/// with the material's gradient, edged, a leaf veined, mother-of-pearl given its sheen.
function tra_draw_motif(_c, _motif, _s, _matName) {
    if (!tra__is_ctx(_c) || !(is_numeric(_s) && _s > 0)) return;
    var _eps = tra__eps0();
    var M = tra_material(_matName), _i, _a, _ns = array_length(M.stops);
    var _g = tra_cx_linear(_c, -_s / 2, -_s / 2, _s / 2, _s / 2);
    for (_i = 0; _i < _ns; _i++) tra_cx_stop(_g, _i / (_ns - 1), M.stops[_i]);
    tra_cx_begin(_c);
    var _h = _s / 2;
    if (_motif == "star") {
        for (_i = 0; _i < 16; _i++) {
            _a = _i * pi / 8 - pi / 2;
            var _rad = (_i mod 2 != 0) ? _h * ((_i mod 4 == 1) ? 0.3 : 0.42) : ((_i mod 4 == 0) ? _h : _h * 0.62);
            tra_cx_line(_c, cos(_a) * _rad, sin(_a) * _rad);
        }
        tra_cx_close(_c);
    } else if (_motif == "lozenge") {
        tra_cx_move(_c, 0, -_h); tra_cx_line(_c, _h * 0.62, 0); tra_cx_line(_c, 0, _h); tra_cx_line(_c, -_h * 0.62, 0); tra_cx_close(_c);
        tra_cx_move(_c, 0, -_h * 0.45); tra_cx_line(_c, -_h * 0.26, 0); tra_cx_line(_c, 0, _h * 0.45); tra_cx_line(_c, _h * 0.26, 0); tra_cx_close(_c);
    } else if (_motif == "rosette") {
        for (_i = 0; _i < 6; _i++) { _a = _i * pi / 3; tra_cx_move(_c, 0, 0); tra_cx_ellipse(_c, cos(_a) * _h * 0.52, sin(_a) * _h * 0.52, _h * 0.46, _h * 0.2, _a, 0, 6.2832); }
        tra_cx_move(_c, _h * 0.2, 0); tra_cx_arc(_c, 0, 0, _h * 0.2, 0, 6.2832);
    } else if (_motif == "bars") {
        for (_i = -1; _i <= 1; _i++) tra_cx_rect(_c, -_h * 0.8, _i * _h * 0.5 - _h * 0.13, _h * 1.6, _h * 0.26);
    } else if (_motif == "chevron") {
        for (_i = 0; _i < 2; _i++) {
            var _y0 = -_h * 0.55 + _i * _h * 0.7;
            tra_cx_move(_c, -_h * 0.85, _y0); tra_cx_line(_c, 0, _y0 + _h * 0.5); tra_cx_line(_c, _h * 0.85, _y0); tra_cx_line(_c, _h * 0.85, _y0 + _h * 0.3); tra_cx_line(_c, 0, _y0 + _h * 0.8); tra_cx_line(_c, -_h * 0.85, _y0 + _h * 0.3); tra_cx_close(_c);
        }
    } else if (_motif == "dot") {
        tra_cx_arc(_c, 0, 0, _h * 0.34, 0, 6.2832);
        for (_i = 0; _i < 8; _i++) { _a = _i * pi / 4; tra_cx_move(_c, cos(_a) * _h * 0.78 + _h * 0.1, sin(_a) * _h * 0.78); tra_cx_arc(_c, cos(_a) * _h * 0.78, sin(_a) * _h * 0.78, _h * 0.1, 0, 6.2832); }
    } else if (_motif == "ring") {
        tra_cx_arc(_c, 0, 0, _h * 0.86, 0, 6.2832);
        tra_cx_move(_c, _h * 0.58, 0); tra_cx_arc(_c, 0, 0, _h * 0.58, 0, 6.2832, true);
        tra_cx_move(_c, _h * 0.22, 0); tra_cx_arc(_c, 0, 0, _h * 0.22, 0, 6.2832);
    } else if (_motif == "cross") {
        for (_i = 0; _i < 4; _i++) {
            _a = _i * pi / 2;
            var _co = cos(_a), _sn = sin(_a);
            tra_cx_move(_c, _co * _h * 0.15, _sn * _h * 0.15); tra_cx_line(_c, _co * _h * 0.9 - _sn * _h * 0.42, _sn * _h * 0.9 + _co * _h * 0.42);
            tra_cx_line(_c, _co * _h * 0.72, _sn * _h * 0.72); tra_cx_line(_c, _co * _h * 0.9 + _sn * _h * 0.42, _sn * _h * 0.9 - _co * _h * 0.42); tra_cx_close(_c);
        }
    } else if (_motif == "leaf") {
        tra_cx_move(_c, 0, -_h * 0.95);
        tra_cx_bezier(_c, _h * 0.75, -_h * 0.4, _h * 0.6, _h * 0.5, 0, _h * 0.8);
        tra_cx_bezier(_c, -_h * 0.6, _h * 0.5, -_h * 0.75, -_h * 0.4, 0, -_h * 0.95);
        tra_cx_close(_c);
    } else {
        tra_cx_move(_c, -_h * 0.9, -_h * 0.1);
        for (_i = 0; _i <= 12; _i++) { var _xx = -_h * 0.9 + _i * _h * 0.15; tra_cx_line(_c, _xx, -_h * 0.1 + sin(_i * 0.9) * _h * 0.3 - _h * 0.12); }
        for (_i = 12; _i >= 0; _i--) { var _x2 = -_h * 0.9 + _i * _h * 0.15; tra_cx_line(_c, _x2, -_h * 0.1 + sin(_i * 0.9) * _h * 0.3 + _h * 0.2); }
        tra_cx_close(_c);
    }
    // the cut the inlay sits in (offset on the screen: header, departure 1)
    tra__solid(_c, [0, 0, 0], 0.35);
    tra__fill_offset(_c, 0.8, 1, TRA_FILL_EVENODD);
    _c.fill = _g; tra_cx_fill_rule(_c, TRA_FILL_EVENODD);
    tra__pen(_c, M.edge, 0.85, max(0.7, _s / 44)); tra_cx_stroke(_c);
    if (_motif == "leaf") {
        tra_cx_begin(_c); tra_cx_move(_c, 0, -_h * 0.8); tra_cx_line(_c, 0, _h * 0.75);
        for (_i = 0; _i < 3; _i++) { var _vy = -_h * 0.35 + _i * _h * 0.35; tra_cx_move(_c, 0, _vy + _h * 0.15); tra_cx_line(_c, _h * 0.32, _vy - _h * 0.05); tra_cx_move(_c, 0, _vy + _h * 0.15); tra_cx_line(_c, -_h * 0.32, _vy - _h * 0.05); }
        tra_cx_stroke(_c);
    }
    if (_matName == "pearl") {
        _c.fill = tra__rad(_c, -_h * 0.3, -_h * 0.3, 0, 0, 0, _h, [[0, [255, 255, 255], 0.5], [0.5, [180, 220, 255], 0.12], [1, [255, 190, 230], 0.1]]);
        tra_cx_fill_rule(_c, TRA_FILL_EVENODD);
    }
    math_set_epsilon(_eps);
}

// ---------------------------------------------------------------------------------------------------------------
// A piece
// ---------------------------------------------------------------------------------------------------------------

/// @function tra_draw_piece(ctx, piece, ox, oy, s, [opt])
/// @description One marquetry piece: its wood with the grain running along its own length, a line of stringing inset
/// from its edge, its inlay on its heart cell, a varnish sheen, bevelled edges lit from the top left, the kerf. Grain
/// and inlay turn and flip with the piece; the light does not. Draws with the turned piece's top-left at (ox, oy),
/// squares of size s. piece = {id, cells, wood, inlay, [seed]}; opt = {rot, flip, shadow: 0..1 (how far off the table;
/// default 0.25), glow: [r, g, b, a] or undefined}. Returns {w, h, cells} (the turned piece, in squares).
function tra_draw_piece(_c, _piece, _ox, _oy, _s, _opt = undefined) {
    if (!tra__is_ctx(_c) || !tra__is_piece(_piece) || !(is_numeric(_s) && _s > 0) || !is_numeric(_ox) || !is_numeric(_oy)) return undefined;
    var _eps = tra__eps0();
    if (!is_struct(_opt)) _opt = {};
    var _rot = variable_struct_exists(_opt, "rot") ? _opt.rot : 0, _flip = variable_struct_exists(_opt, "flip") ? (_opt.flip == true) : false;
    var T = tra_turn(_piece.cells, _rot, _flip), _loops = tra_outline(T.cells), _loop = _loops[0], _rad = max(1.5, _s * 0.1);
    var _pid = (variable_struct_exists(_piece, "id") && is_numeric(_piece.id)) ? _piece.id : 0, _pseed = (variable_struct_exists(_piece, "seed") && is_numeric(_piece.seed)) ? _piece.seed : 0;
    var _wood = variable_struct_exists(_piece, "wood") ? _piece.wood : "oak", _inlay = variable_struct_exists(_piece, "inlay") ? _piece.inlay : "star";
    var _mat = tra_material_for(_wood, _pid), _seed = (_pid + 1) * 7919 + _pseed;
    tra_cx_save(_c);
    // shadow on the table: soft, further when lifted (its own function, so a screen can keep it apart from the piece)
    tra__piece_shadow(_c, _loop, _ox, _oy, _s, _rad, _opt);
    tra_cx_save(_c); tra_cx_begin(_c); tra_loop_path(_c, _loop, _s, _ox, _oy, _rad); tra_cx_clip(_c);
    // the grain in the piece's own frame: long axis of the ORIGINAL piece
    var _bw = 0, _bh = 0, _k;
    for (_k = 0; _k < array_length(_piece.cells); _k++) { _bw = max(_bw, _piece.cells[_k][0] + 1); _bh = max(_bh, _piece.cells[_k][1] + 1); }
    var _m = T.m;
    tra_cx_save(_c); tra_cx_translate(_c, _ox, _oy); tra_cx_transform(_c, _m[0], _m[1], _m[2], _m[3], _m[4] * _s, _m[5] * _s);
    if (_bh > _bw) { tra_cx_translate(_c, _bw * _s, 0); tra_cx_rotate(_c, pi / 2); tra_draw_grain(_c, _wood, _seed, _bh * _s, _bw * _s); tra_cx_rotate(_c, -pi / 2); tra_cx_translate(_c, -_bw * _s, 0); }
    else tra_draw_grain(_c, _wood, _seed, _bw * _s, _bh * _s);
    tra_cx_restore(_c);
    // stringing: a fine line of contrasting wood run inside the edge
    var WD = tra_wood(_wood), _inner = tra_inset(_loop, 0.14), _line = (WD.lum < 0.5) ? [239, 226, 194] : [42, 26, 16];
    tra_cx_begin(_c); tra_loop_path(_c, _inner, _s, _ox, _oy, _rad * 0.6); tra__pen(_c, _line, 0.75, max(1, _s * 0.035)); tra_cx_stroke(_c);
    tra_cx_begin(_c); tra_loop_path(_c, tra_inset(_loop, 0.14 + 0.05), _s, _ox, _oy, _rad * 0.5); tra__pen(_c, (WD.lum < 0.5) ? [0, 0, 0] : [255, 255, 255], 0.18, 1); tra_cx_stroke(_c);
    // the inlay, on the heart cell, turned with the piece
    var _hc = tra_heart_cell(_piece.cells);
    tra_cx_save(_c); tra_cx_translate(_c, _ox, _oy); tra_cx_transform(_c, _m[0], _m[1], _m[2], _m[3], _m[4] * _s, _m[5] * _s); tra_cx_translate(_c, (_hc[0] + 0.5) * _s, (_hc[1] + 0.5) * _s);
    tra_draw_motif(_c, _inlay, _s * 0.72, _mat);
    tra_cx_restore(_c);
    // varnish: a broad soft sheen
    _c.fill = tra__lin(_c, _ox, _oy, _ox + T.w * _s, _oy + T.h * _s, [[0, [255, 248, 230], 0.16], [0.4, [255, 248, 230], 0], [0.75, [255, 248, 230], 0.05], [1, [0, 0, 0], 0.12]]);
    tra_cx_fill_rect(_c, _ox, _oy, T.w * _s, T.h * _s);
    // bevels: the edges that face the light (top, left) catch it, the others fall into shade
    var _n = array_length(_loop), _bwid = max(1.2, _s * 0.07);
    _c.lw = _bwid * 2; _c.cap = 0;
    for (_k = 0; _k < _n; _k++) {
        var _p0 = _loop[_k], _p1 = _loop[(_k + 1) mod _n], _dx = sign(_p1[0] - _p0[0]), _dy = sign(_p1[1] - _p0[1]);
        var _lit = (_dx > 0 || _dy < 0);   // top edges run right, left edges run up (clockwise)
        _c.stroke = _lit ? tra_cx_solid([255, 244, 220], 0.42) : tra_cx_solid([10, 5, 0], 0.42);
        tra_cx_begin(_c); tra_cx_move(_c, _ox + _p0[0] * _s, _oy + _p0[1] * _s); tra_cx_line(_c, _ox + _p1[0] * _s, _oy + _p1[1] * _s); tra_cx_stroke(_c);
    }
    tra_cx_restore(_c);
    // the kerf: a dark hairline round the cut
    tra_cx_begin(_c); tra_loop_path(_c, _loop, _s, _ox, _oy, _rad); tra__pen(_c, [18, 8, 2], 0.85, max(1, _s * 0.03)); tra_cx_stroke(_c);
    if (variable_struct_exists(_opt, "glow") && is_array(_opt.glow)) {
        var _gw = _opt.glow;
        tra_cx_begin(_c); tra_loop_path(_c, _loop, _s, _ox, _oy, _rad);
        tra__pen(_c, [_gw[0], _gw[1], _gw[2]], (array_length(_gw) > 3) ? _gw[3] : 1, max(2, _s * 0.06)); tra_cx_stroke(_c);
    }
    tra_cx_restore(_c);
    math_set_epsilon(_eps);
    return { w: T.w, h: T.h, cells: T.cells };
}

/// @function tra__piece_shadow(ctx, loop, ox, oy, s, rad, opt)
/// @description The lift block of the original's drawPiece: the piece's silhouette filled black with a soft shadow,
/// offset and blurred by the lift (opt.shadow, default 0.25; 0 draws nothing). Internal.
function tra__piece_shadow(_c, _loop, _ox, _oy, _s, _rad, _opt) {
    var _lift = (variable_struct_exists(_opt, "shadow") && is_numeric(_opt.shadow)) ? _opt.shadow : 0.25;
    if (!(_lift > 0)) return;
    tra_cx_save(_c);
    tra__solid(_c, [0, 0, 0]);
    tra_cx_begin(_c); tra_loop_path(_c, _loop, _s, _ox, _oy, _rad);
    tra_cx_shadow(_c, [0, 0, 0], 0.45 + _lift * 0.2, 4 + _lift * 16, 2 + _lift * 8, 3 + _lift * 11);
    tra_cx_fill(_c);
    tra_cx_restore(_c);
}

/// @function tra_draw_piece_shadow(ctx, piece, ox, oy, s, [opt])
/// @description Only what tra_draw_piece draws FIRST: the soft shadow a piece casts at its lift (opt.shadow, default
/// 0.25; 0 draws nothing) and the black of its silhouette under where the piece goes. Draw it, then tra_draw_piece with
/// shadow: 0 at the same place - together they are tra_draw_piece. For a screen that bakes a piece and its shadow apart,
/// so lifting a piece re-bakes only the shadow (MEASURED: ~0.6 ms, against ~50 ms for the whole piece).
function tra_draw_piece_shadow(_c, _piece, _ox, _oy, _s, _opt = undefined) {
    if (!tra__is_ctx(_c) || !tra__is_piece(_piece) || !(is_numeric(_s) && _s > 0) || !is_numeric(_ox) || !is_numeric(_oy)) return;
    var _eps = tra__eps0();
    if (!is_struct(_opt)) _opt = {};
    var _rot = variable_struct_exists(_opt, "rot") ? _opt.rot : 0, _flip = variable_struct_exists(_opt, "flip") ? (_opt.flip == true) : false;
    var T = tra_turn(_piece.cells, _rot, _flip), _loops = tra_outline(T.cells);
    if (array_length(_loops) > 0) tra__piece_shadow(_c, _loops[0], _ox, _oy, _s, max(1.5, _s * 0.1), _opt);
    math_set_epsilon(_eps);
}

// ---------------------------------------------------------------------------------------------------------------
// The room
// ---------------------------------------------------------------------------------------------------------------

/// @function tra_draw_table(ctx, W, H)
/// @description The workbench: five dark walnut planks with their own grain, lit from above, a vignette.
function tra_draw_table(_c, _W, _H) {
    if (!tra__is_ctx(_c) || !(is_numeric(_W) && _W > 0) || !(is_numeric(_H) && _H > 0)) return;
    var _eps = tra__eps0();
    var _planks = 5, _ph = _H / _planks;
    for (var _i = 0; _i < _planks; _i++) {
        tra_cx_save(_c); tra_cx_translate(_c, 0, _i * _ph); tra_cx_begin(_c); tra_cx_rect(_c, 0, 0, _W, _ph); tra_cx_clip(_c);
        tra_draw_grain(_c, "walnut", 4021 + _i * 97, _W, _ph);
        tra__solid(_c, [12, 6, 2], 0.42 + (_i mod 2) * 0.08); tra_cx_fill_rect(_c, 0, 0, _W, _ph);
        tra__solid(_c, [0, 0, 0], 0.55); tra_cx_fill_rect(_c, 0, 0, _W, 2);
        tra__solid(_c, [255, 220, 170], 0.08); tra_cx_fill_rect(_c, 0, 2, _W, 1);
        tra_cx_restore(_c);
    }
    _c.fill = tra__rad(_c, _W * 0.45, _H * 0.42, _H * 0.2, _W * 0.5, _H * 0.5, _W * 0.75, [[0, [255, 214, 150], 0.10], [1, [0, 0, 0], 0.6]]);
    tra_cx_fill_rect(_c, 0, 0, _W, _H);
    math_set_epsilon(_eps);
}

/// @function tra_draw_banding(ctx, x, y, w, h, inset)
/// @description Stringing and corner fans on a board: the cabinetmaker's border.
function tra_draw_banding(_c, _x, _y, _w, _h, _i0) {
    if (!tra__is_ctx(_c) || !is_numeric(_x) || !is_numeric(_y) || !(is_numeric(_w) && _w > 0) || !(is_numeric(_h) && _h > 0) || !is_numeric(_i0)) return;
    var _eps = tra__eps0();
    tra__pen(_c, [240, 226, 190], 0.7, 1.4); tra_cx_stroke_rect(_c, _x + _i0, _y + _i0, _w - _i0 * 2, _h - _i0 * 2);
    tra__pen(_c, [20, 10, 4], 0.6, 1); tra_cx_stroke_rect(_c, _x + _i0 + 3, _y + _i0 + 3, _w - _i0 * 2 - 6, _h - _i0 * 2 - 6);
    // quarter-fan paterae in the corners
    var _cs = [[_x + _i0, _y + _i0, 0], [_x + _w - _i0, _y + _i0, 1], [_x + _w - _i0, _y + _h - _i0, 2], [_x + _i0, _y + _h - _i0, 3]];
    for (var _i = 0; _i < 4; _i++) {
        var _cx = _cs[_i][0], _cy = _cs[_i][1], _a0 = _cs[_i][2] * pi / 2, _R = _i0 * 1.6;
        for (var _k = 0; _k < 5; _k++) {
            var _a1 = _a0 + _k * pi / 10, _a2 = _a0 + (_k + 1) * pi / 10;
            tra__solid(_c, (_k mod 2 != 0) ? [230, 208, 160] : [120, 70, 30], 0.85);
            tra_cx_begin(_c); tra_cx_move(_c, _cx, _cy); tra_cx_arc(_c, _cx, _cy, _R, _a1, _a2); tra_cx_close(_c); tra_cx_fill(_c);
        }
        tra__pen(_c, [20, 10, 4], 0.7, 0.8); tra_cx_begin(_c); tra_cx_arc(_c, _cx, _cy, _R, _a0, _a0 + pi / 2); tra_cx_stroke(_c);
    }
    math_set_epsilon(_eps);
}

/// @function tra_draw_baize(ctx, x, y, w, h, seed)
/// @description Baize: the green cloth a recess is lined with, its nap a scatter of light and dark specks.
function tra_draw_baize(_c, _x, _y, _w, _h, _seed) {
    if (!tra__is_ctx(_c) || !is_numeric(_x) || !is_numeric(_y) || !(is_numeric(_w) && _w > 0) || !(is_numeric(_h) && _h > 0)) return;
    var _eps = tra__eps0();
    _c.fill = tra__lin(_c, _x, _y, _x, _y + _h, [[0, [29, 74, 54]], [1, [18, 52, 36]]]); tra_cx_fill_rect(_c, _x, _y, _w, _h);
    var _r = tra_rng(_seed), _lc = tra_col([80, 140, 100]), _dc = tra_col([0, 20, 10]), _list = [];
    for (var _i = 0; _i < _w * _h / 14; _i++) {
        var _light = tra_rnd(_r) < 0.5;
        var _sx = _x + tra_rnd(_r) * _w;
        var _sy = _y + tra_rnd(_r) * _h;
        array_push(_list, [_sx, _sy, 1, 1, _light ? _lc : _dc, _light ? 0.16 : 0.2]);
    }
    tra_cx_fill_rects(_c, _list);
    math_set_epsilon(_eps);
}

/// @function tra_case_geo(cx, cy, puzzle, s)
/// @description Where tra_draw_case puts things, without drawing: {x, y, s, board: {x, y, w, h}} - (x, y) is the
/// top-left of the tray's box of squares. Pure (the suite holds it to what tra_draw_case returns).
function tra_case_geo(_cx, _cy, _p, _s) {
    var _rim = tra_jsround(_s * 0.62), _bw = _p.w * _s + _rim * 2, _bh = _p.h * _s + _rim * 2, _x = tra_jsround(_cx - _bw / 2), _y = tra_jsround(_cy - _bh / 2);
    return { x: _x + _rim, y: _y + _rim, s: _s, board: { x: _x, y: _y, w: _bw, h: _bh } };
}

/// @function tra_draw_case(ctx, cx, cy, puzzle, s)
/// @description The case: an ebonised board (japanned blue-black over a faint grain, so all ten woods stand off it)
/// with stringing and corner fans, the tray's shape sunk into it and lined with baize, scored in squares, the recess
/// walls throwing a shadow onto the cloth from the top left, a brass fillet round the recess and a lit lip. Centred on
/// (cx, cy) at square size s; puzzle = {w, h, mask, cells}. Returns {x, y, s, board: {x, y, w, h}} - (x, y) is the top-left
/// of the tray's box of squares.
function tra_draw_case(_c, _cx, _cy, _p, _s) {
    if (!tra__is_ctx(_c) || !tra__is_tray(_p) || !(is_numeric(_s) && _s > 0) || !is_numeric(_cx) || !is_numeric(_cy)) return undefined;
    var _eps = tra__eps0();
    var _rim = tra_jsround(_s * 0.62), _bw = _p.w * _s + _rim * 2, _bh = _p.h * _s + _rim * 2, _x = tra_jsround(_cx - _bw / 2), _y = tra_jsround(_cy - _bh / 2), _ox = _x + _rim, _oy = _y + _rim;
    tra_cx_save(_c);
    tra__solid(_c, [0, 0, 0], 0.55); tra_rr(_c, _x + 6, _y + 9, _bw, _bh, 10); tra_cx_fill(_c);
    // ⛔ (the original, 2026-09-28) a rosewood board swallowed the rosewood and cherry pieces lying against its rim: the
    // case is ebonised (black lacquer over a faint grain) so all ten woods stand off it, with a brass fillet round the
    // recess.
    tra_cx_save(_c); tra_rr(_c, _x, _y, _bw, _bh, 10); tra_cx_clip(_c);
    tra_cx_translate(_c, _x, _y); tra_draw_grain(_c, "ebony", 777 + _p.w * 31 + _p.h, _bw, _bh); tra_cx_translate(_c, -_x, -_y);
    // japanned: a blue-black lacquer, so the (warm) ebony piece still stands off the (cool) case
    tra__solid(_c, [14, 20, 38], 0.62); tra_cx_fill_rect(_c, _x, _y, _bw, _bh);
    _c.fill = tra__lin(_c, _x, _y, _x + _bw, _y + _bh, [[0, [255, 230, 200], 0.14], [0.5, [255, 230, 200], 0.02], [1, [0, 0, 0], 0.3]]); tra_cx_fill_rect(_c, _x, _y, _bw, _bh);
    tra_cx_restore(_c);
    tra__pen(_c, [255, 230, 190], 0.35, 2); tra_rr(_c, _x + 1, _y + 1, _bw - 2, _bh - 2, 9); tra_cx_stroke(_c);
    tra__pen(_c, [0, 0, 0], 0.6, 1); tra_rr(_c, _x + 0.5, _y + 0.5, _bw - 1, _bh - 1, 10); tra_cx_stroke(_c);
    tra_draw_banding(_c, _x, _y, _bw, _bh, max(6, _rim * 0.34));
    // the recess
    var _cells = [];
    for (var _i = 0; _i < array_length(_p.mask); _i++) if (_p.mask[_i]) array_push(_cells, [_i mod _p.w, floor(_i / _p.w)]);
    var _loops = tra_outline(_cells), _L;
    tra_cx_save(_c); tra_cx_begin(_c); for (_L = 0; _L < array_length(_loops); _L++) tra_loop_path(_c, _loops[_L], _s, _ox, _oy, _s * 0.08); tra_cx_clip(_c);
    tra_draw_baize(_c, _ox, _oy, _p.w * _s, _p.h * _s, 91 + ((variable_struct_exists(_p, "cells") && is_numeric(_p.cells)) ? _p.cells : tra_count(_p.mask)));
    // scoring: faint lines where the squares meet
    tra__pen(_c, [0, 0, 0], 0.22, 1); tra_cx_set_dash(_c, [2, 3]);
    for (var _gx = 1; _gx < _p.w; _gx++) { tra_cx_begin(_c); tra_cx_move(_c, _ox + _gx * _s, _oy); tra_cx_line(_c, _ox + _gx * _s, _oy + _p.h * _s); tra_cx_stroke(_c); }
    for (var _gy = 1; _gy < _p.h; _gy++) { tra_cx_begin(_c); tra_cx_move(_c, _ox, _oy + _gy * _s); tra_cx_line(_c, _ox + _p.w * _s, _oy + _gy * _s); tra_cx_stroke(_c); }
    tra_cx_set_dash(_c, []);
    // the wall's shadow, cast down and right onto the cloth
    for (_L = 0; _L < array_length(_loops); _L++) {
        tra_cx_save(_c);
        tra_cx_begin(_c); tra_cx_rect(_c, _ox - _s * 3, _oy - _s * 3, _p.w * _s + _s * 6, _p.h * _s + _s * 6); tra_loop_path(_c, _loops[_L], _s, _ox, _oy, _s * 0.08);
        tra__solid(_c, [0, 0, 0]);
        tra_cx_shadow(_c, [0, 0, 0], 0.75, _s * 0.28, _s * 0.08, _s * 0.12, TRA_FILL_EVENODD);
        tra_cx_fill_rule(_c, TRA_FILL_EVENODD);
        tra_cx_restore(_c);
    }
    tra_cx_restore(_c);
    // the brass fillet round the recess, then the lip: lit on the far (bottom/right) walls, dark on the near ones
    tra_cx_save(_c); tra_cx_begin(_c); for (_L = 0; _L < array_length(_loops); _L++) tra_loop_path(_c, tra_inset(_loops[_L], -0.07), _s, _ox, _oy, _s * 0.12);
    tra__pen(_c, [201, 154, 66], 1, max(2, _s * 0.06)); tra_cx_stroke(_c); tra__pen(_c, [255, 240, 190], 0.5, 1); tra_cx_stroke(_c); tra_cx_restore(_c);
    for (_L = 0; _L < array_length(_loops); _L++) {
        var _lp = _loops[_L], _n = array_length(_lp);
        _c.lw = 2;
        for (var _k = 0; _k < _n; _k++) {
            var _a = _lp[_k], _b = _lp[(_k + 1) mod _n], _dx = sign(_b[0] - _a[0]), _dy = sign(_b[1] - _a[1]);
            _c.stroke = (_dx < 0 || _dy > 0) ? tra_cx_solid([255, 226, 180], 0.45) : tra_cx_solid([0, 0, 0], 0.7);
            tra_cx_begin(_c); tra_cx_move(_c, _ox + _a[0] * _s, _oy + _a[1] * _s); tra_cx_line(_c, _ox + _b[0] * _s, _oy + _b[1] * _s); tra_cx_stroke(_c);
        }
    }
    tra_cx_restore(_c);
    math_set_epsilon(_eps);
    return { x: _ox, y: _oy, s: _s, board: { x: _x, y: _y, w: _bw, h: _bh } };
}

/// @function tra_draw_parts_box(ctx, x, y, w, h)
/// @description The parts box: a shallow open box of pale oak lined with baize, where the loose pieces wait.
function tra_draw_parts_box(_c, _x, _y, _w, _h) {
    if (!tra__is_ctx(_c) || !is_numeric(_x) || !is_numeric(_y) || !(is_numeric(_w) && _w > 0) || !(is_numeric(_h) && _h > 0)) return;
    var _eps = tra__eps0();
    tra_cx_save(_c);
    tra__solid(_c, [0, 0, 0], 0.5); tra_rr(_c, _x + 5, _y + 8, _w, _h, 8); tra_cx_fill(_c);
    tra_cx_save(_c); tra_rr(_c, _x, _y, _w, _h, 8); tra_cx_clip(_c);
    tra_cx_translate(_c, _x, _y); tra_draw_grain(_c, "oak", 1203, _w, _h); tra_cx_translate(_c, -_x, -_y);
    tra__solid(_c, [40, 20, 5], 0.25); tra_cx_fill_rect(_c, _x, _y, _w, _h);
    tra_cx_restore(_c);
    var _b = 12;
    tra_draw_baize(_c, _x + _b, _y + _b, _w - _b * 2, _h - _b * 2, 57);
    // the box wall's shadow on the cloth (clip to the cloth, fill everything outside it, keep only the shadow)
    tra_cx_save(_c); tra_cx_begin(_c); tra_cx_rect(_c, _x + _b, _y + _b, _w - _b * 2, _h - _b * 2); tra_cx_clip(_c);
    tra_cx_begin(_c); tra_cx_rect(_c, _x - 60, _y - 60, _w + 120, _h + 120); tra_cx_rect(_c, _x + _b, _y + _b, _w - _b * 2, _h - _b * 2);
    tra__solid(_c, [0, 0, 0]);
    tra_cx_shadow(_c, [0, 0, 0], 0.7, 10, 3, 5, TRA_FILL_EVENODD);
    tra_cx_fill_rule(_c, TRA_FILL_EVENODD);
    tra_cx_restore(_c);
    tra__pen(_c, [0, 0, 0], 0.65, 2); tra_cx_stroke_rect(_c, _x + _b, _y + _b, _w - _b * 2, _h - _b * 2);
    tra__pen(_c, [255, 236, 200], 0.35, 1.5); tra_rr(_c, _x + 1, _y + 1, _w - 2, _h - 2, 7); tra_cx_stroke(_c);
    tra_cx_restore(_c);
    math_set_epsilon(_eps);
}

/// @function tra_draw_title(ctx, x, y, w, h, title, [sub])
/// @description The brass title plate: two screws, the title struck in, an optional italic line under it.
function tra_draw_title(_c, _x, _y, _w, _h, _title, _sub = "") {
    if (!tra__is_ctx(_c) || !is_numeric(_x) || !is_numeric(_y) || !(is_numeric(_w) && _w > 0) || !(is_numeric(_h) && _h > 0)) return;
    if (!is_string(_title)) _title = is_undefined(_title) ? "" : string(_title);
    var _eps = tra__eps0();
    var _hasSub = is_string(_sub) && string_length(_sub) > 0;
    tra_cx_save(_c);
    tra__solid(_c, [0, 0, 0], 0.5); tra_rr(_c, _x + 3, _y + 4, _w, _h, 6); tra_cx_fill(_c);
    _c.fill = tra__lin(_c, 0, _y, 0, _y + _h, [[0, [246, 220, 148]], [0.45, [201, 154, 66]], [1, [138, 97, 32]]]); tra_rr(_c, _x, _y, _w, _h, 6); tra_cx_fill(_c);
    tra__pen(_c, [60, 40, 10], 0.7, 1); tra_rr(_c, _x + 4, _y + 4, _w - 8, _h - 8, 4); tra_cx_stroke(_c);
    tra__solid(_c, [106, 72, 22]);
    for (var _i = 0; _i < 2; _i++) {
        var _sx = (_i != 0) ? _x + _w - 12 : _x + 12;
        tra_cx_begin(_c); tra_cx_arc(_c, _sx, _y + _h / 2, 3.2, 0, 6.2832); tra_cx_fill(_c);
        tra__pen(_c, [255, 240, 200], 0.6); tra_cx_begin(_c); tra_cx_move(_c, _sx - 2.2, _y + _h / 2); tra_cx_line(_c, _sx + 2.2, _y + _h / 2); tra_cx_stroke(_c);
    }
    var _ty = _y + (_hasSub ? _h * 0.38 : _h / 2), _sz = tra_fit_text(_title, _w - 44, _hasSub ? 19 : 22);
    tra_dtext(_c, _title, _x + _w / 2 + 0.8, _ty + 1.6, _sz, "bold", [255, 245, 210], 0.6);
    tra_dtext(_c, _title, _x + _w / 2, _ty + 0.8, _sz, "bold", [58, 36, 8]);
    if (_hasSub) { var _ss = tra_fit_text(_sub, _w - 44, 12, "italic"); tra_dtext(_c, _sub, _x + _w / 2, _y + _h * 0.74, _ss, "italic", [74, 48, 16]); }
    tra_cx_restore(_c);
    math_set_epsilon(_eps);
}

/// @function tra_draw_card(ctx, w, h, info)
/// @description The tally card (cleared first): pieces in, moves, hints, on a small ivory card. info = {placed, total,
/// moves, hints, hintsLeft (-1 for no limit)}.
function tra_draw_card(_c, _w, _h, _info) {
    if (!tra__is_ctx(_c) || !(is_numeric(_w) && _w > 0) || !(is_numeric(_h) && _h > 0) || !is_struct(_info)) return;
    var _eps = tra__eps0();
    tra_cx_clear_rect(_c, 0, 0, _w, _h);
    tra__solid(_c, [0, 0, 0], 0.45); tra_rr(_c, 4, 5, _w - 6, _h - 7, 5); tra_cx_fill(_c);
    _c.fill = tra__lin(_c, 0, 0, 0, _h, [[0, [244, 234, 210]], [1, [224, 208, 170]]]); tra_rr(_c, 1, 1, _w - 6, _h - 7, 5); tra_cx_fill(_c);
    tra__pen(_c, [120, 80, 30], 0.6, 1); tra_rr(_c, 5, 5, _w - 14, _h - 15, 3); tra_cx_stroke(_c);
    var _hl = _info.hintsLeft;
    var _rows = [["Pieces in", string(_info.placed) + " of " + string(_info.total)], ["Moves", string(_info.moves)], ["Hints", (_hl < 0) ? string(_info.hints) : string(_info.hints) + " (" + string(_hl) + " left)"]];
    for (var _i = 0; _i < array_length(_rows); _i++) {
        var _y = 22 + _i * 22;
        tra_dtext(_c, _rows[_i][0], 14, _y, 13, "italic", [106, 74, 40], 1, fa_left);
        tra_dtext(_c, _rows[_i][1], _w - 18, _y, 14, "bold", [42, 26, 8], 1, fa_right);
        tra__solid(_c, [120, 80, 30], 0.25); tra_cx_fill_rect(_c, 12, _y + 10, _w - 30, 1);
    }
    math_set_epsilon(_eps);
}

/// @function tra_draw_plaque(ctx, x, y, w, h, text, state)
/// @description A brass plaque button. state: "on" (bright), "idle", "off" (dark, greyed text).
function tra_draw_plaque(_c, _x, _y, _w, _h, _text, _state) {
    if (!tra__is_ctx(_c) || !is_numeric(_x) || !is_numeric(_y) || !(is_numeric(_w) && _w > 0) || !(is_numeric(_h) && _h > 0)) return;
    if (!is_string(_text)) _text = is_undefined(_text) ? "" : string(_text);
    var _eps = tra__eps0();
    tra_cx_save(_c);
    tra__solid(_c, [0, 0, 0], 0.45); tra_rr(_c, _x + 3, _y + 4, _w, _h, 6); tra_cx_fill(_c);
    var _st;
    if (_state == "off") _st = [[0, [106, 90, 68]], [1, [58, 46, 32]]];
    else if (_state == "on") _st = [[0, [255, 240, 176]], [0.5, [232, 184, 80]], [1, [154, 106, 30]]];
    else _st = [[0, [242, 216, 144]], [0.5, [201, 154, 66]], [1, [138, 97, 32]]];
    _c.fill = tra__lin(_c, 0, _y, 0, _y + _h, _st); tra_rr(_c, _x, _y, _w, _h, 6); tra_cx_fill(_c);
    tra__pen(_c, [60, 40, 10], 0.75, 1); tra_rr(_c, _x + 3, _y + 3, _w - 6, _h - 6, 4); tra_cx_stroke(_c);
    var _sz = tra_fit_text(_text, _w - 20, 15), _off = (_state == "off");
    tra_dtext(_c, _text, _x + _w / 2 + 0.8, _y + _h / 2 + 1.8, _sz, "bold", _off ? [200, 180, 150] : [255, 245, 210], _off ? 0.45 : 0.6);
    tra_dtext(_c, _text, _x + _w / 2, _y + _h / 2 + 1, _sz, "bold", _off ? [30, 20, 10] : [58, 36, 8], _off ? 0.8 : 1);
    tra_cx_restore(_c);
    math_set_epsilon(_eps);
}

/// @function tra_draw_status(ctx, W, H, text)
/// @description The status line (cleared first): italic light type with a dark drop, centred; nothing for "".
function tra_draw_status(_c, _W, _H, _text) {
    if (!tra__is_ctx(_c) || !(is_numeric(_W) && _W > 0) || !(is_numeric(_H) && _H > 0)) return;
    var _eps = tra__eps0();
    tra_cx_clear_rect(_c, 0, 0, _W, _H);
    if (is_string(_text) && string_length(_text) > 0) {
        var _sz = tra_fit_text(_text, _W - 10, 16, "italic");
        tra_dtext(_c, _text, _W / 2 + 1, _H / 2 + 1, _sz, "italic", [0, 0, 0], 0.75);
        tra_dtext(_c, _text, _W / 2, _H / 2, _sz, "italic", [241, 223, 180]);
    }
    math_set_epsilon(_eps);
}

/// @function tra_draw_ghost(ctx, cells, ox, oy, s, fits)
/// @description Where a carried piece would land: its squares outlined on the cloth, dashed, gold if it fits, red if not.
function tra_draw_ghost(_c, _cells, _ox, _oy, _s, _fits) {
    if (!tra__is_ctx(_c) || !is_array(_cells) || !(is_numeric(_s) && _s > 0) || !is_numeric(_ox) || !is_numeric(_oy)) return;
    var _eps = tra__eps0();
    var _loops = tra_outline(_cells);
    tra_cx_save(_c); tra_cx_begin(_c); for (var _L = 0; _L < array_length(_loops); _L++) tra_loop_path(_c, _loops[_L], _s, _ox, _oy, _s * 0.1);
    _c.fill = _fits ? tra_cx_solid([236, 210, 120], 0.22) : tra_cx_solid([200, 40, 30], 0.25); tra_cx_fill(_c);
    tra_cx_set_dash(_c, [5, 4]); tra__pen(_c, _fits ? [255, 232, 150] : [255, 110, 90], 0.9, 2); tra_cx_stroke(_c);
    tra_cx_restore(_c);
    math_set_epsilon(_eps);
}

/// @function tra_draw_pointer(ctx, w, h)
/// @description A small brass pointer (a hand-cut arrow pointing down) that marks the chosen piece, w x h, cleared first.
function tra_draw_pointer(_c, _w, _h) {
    if (!tra__is_ctx(_c) || !(is_numeric(_w) && _w > 0) || !(is_numeric(_h) && _h > 0)) return;
    var _eps = tra__eps0();
    tra_cx_clear_rect(_c, 0, 0, _w, _h);
    tra_cx_save(_c); tra_cx_translate(_c, _w / 2, _h - 2);
    tra_cx_begin(_c); tra_cx_move(_c, 0, 0); tra_cx_line(_c, -_w * 0.4, -_h * 0.5); tra_cx_line(_c, -_w * 0.16, -_h * 0.5); tra_cx_line(_c, -_w * 0.16, -_h + 3);
    tra_cx_line(_c, _w * 0.16, -_h + 3); tra_cx_line(_c, _w * 0.16, -_h * 0.5); tra_cx_line(_c, _w * 0.4, -_h * 0.5); tra_cx_close(_c);
    tra_cx_shadow(_c, [0, 0, 0], 0.6, 4, 0, 2);
    _c.fill = tra__lin(_c, -_w / 2, 0, _w / 2, 0, [[0, [251, 231, 164]], [0.5, [217, 170, 74]], [1, [138, 90, 20]]]); tra_cx_fill(_c);
    tra__pen(_c, [74, 46, 6], 1, 1); tra_cx_stroke(_c);
    tra_cx_restore(_c);
    math_set_epsilon(_eps);
}

/// @function tra_draw_sheen(ctx, w, h)
/// @description A soft vertical band of light, for the polish that runs across a finished panel.
function tra_draw_sheen(_c, _w, _h) {
    if (!tra__is_ctx(_c) || !(is_numeric(_w) && _w > 0) || !(is_numeric(_h) && _h > 0)) return;
    var _eps = tra__eps0();
    _c.fill = tra__lin(_c, 0, 0, _w, 0, [[0, [255, 250, 235], 0], [0.5, [255, 250, 235], 0.55], [1, [255, 250, 235], 0]]); tra_cx_fill_rect(_c, 0, 0, _w, _h);
    math_set_epsilon(_eps);
}

/// @function tra_draw_verdict(ctx, W, H, puzzle, placed, info)
/// @description The finished panel, framed (cleared first): every piece home in the case under a lamp, a brass plaque
/// with the result, the woods listed underneath. placed[i] = {x, y, cells} or undefined (tra_place's record); info =
/// {title, sub, foot}.
function tra_draw_verdict(_c, _W, _H, _p, _placed, _info) {
    if (!tra__is_ctx(_c) || !(is_numeric(_W) && _W > 0) || !(is_numeric(_H) && _H > 0) || !tra__is_tray(_p) || !is_array(_placed) || !is_struct(_info)) return;
    if (!variable_struct_exists(_p, "pieces") || !is_array(_p.pieces)) return;
    _info = { title: variable_struct_exists(_info, "title") ? string(_info.title) : "", sub: variable_struct_exists(_info, "sub") ? string(_info.sub) : "", foot: variable_struct_exists(_info, "foot") ? string(_info.foot) : "" };
    var _eps = tra__eps0();
    // ⛔ (the original) at 0.78 the tally card showed through beside the plate; the finished panel stands alone
    tra_cx_clear_rect(_c, 0, 0, _W, _H); tra__solid(_c, [8, 4, 2], 0.96); tra_cx_fill_rect(_c, 0, 0, _W, _H);
    _c.fill = tra__rad(_c, _W / 2, 250, 40, _W / 2, 250, _W * 0.6, [[0, [255, 214, 150], 0.12], [1, [255, 214, 150], 0]]); tra_cx_fill_rect(_c, 0, 0, _W, _H);
    var _s = min(floor(520 / _p.w), floor(300 / _p.h), 60), _geo = tra_draw_case(_c, _W / 2, 238, _p, _s);
    for (var _i = 0; _i < array_length(_p.pieces); _i++) {
        var _pl = (_i < array_length(_placed)) ? _placed[_i] : undefined;
        if (!is_struct(_pl) || !tra__is_piece(_p.pieces[_i]) || !tra__is_piece(_pl) || !variable_struct_exists(_pl, "x") || !variable_struct_exists(_pl, "y")) continue;
        var _pose = tra_pose_of(_p.pieces[_i].cells, _pl.cells);
        if (is_undefined(_pose)) _pose = { rot: 0, flip: false };
        tra_draw_piece(_c, _p.pieces[_i], _geo.x + _pl.x * _s, _geo.y + _pl.y * _s, _s, { rot: _pose.rot, flip: _pose.flip, shadow: 0 });
    }
    var _bd = _geo.board;
    _c.fill = tra__lin(_c, _bd.x, _bd.y, _bd.x + _bd.w, _bd.y + _bd.h, [[0, [255, 245, 220], 0.14], [0.5, [255, 245, 220], 0], [1, [0, 0, 0], 0.1]]); tra_cx_fill_rect(_c, _bd.x, _bd.y, _bd.w, _bd.h);
    var _x = _W / 2 - 230, _y = min(_H - 120, _bd.y + _bd.h + 22), _w = 460, _h = 60;
    tra__solid(_c, [0, 0, 0], 0.45); tra_rr(_c, _x + 3, _y + 4, _w, _h, 6); tra_cx_fill(_c);
    _c.fill = tra__lin(_c, 0, _y, 0, _y + _h, [[0, [246, 220, 148]], [0.5, [201, 154, 66]], [1, [138, 97, 32]]]);
    tra_rr(_c, _x, _y, _w, _h, 6); tra_cx_fill(_c); tra__pen(_c, [60, 40, 10], 0.7, 1); tra_rr(_c, _x + 3, _y + 3, _w - 6, _h - 6, 4); tra_cx_stroke(_c);
    var _ts = tra_fit_text(_info.title, _w - 24, 20);
    tra_dtext(_c, _info.title, _W / 2, _y + 21, _ts, "bold", [255, 245, 210], 0.6);
    tra_dtext(_c, _info.title, _W / 2, _y + 20, _ts, "bold", [58, 36, 8]);
    var _us = tra_fit_text(_info.sub, _w - 24, 13, "italic");
    tra_dtext(_c, _info.sub, _W / 2, _y + 43, _us, "italic", [74, 48, 16]);
    var _woods = "";
    for (var _j = 0; _j < array_length(_p.pieces); _j++) { var _qj = _p.pieces[_j]; _woods += ((_j > 0) ? ", " : "") + tra_wood((is_struct(_qj) && variable_struct_exists(_qj, "wood")) ? _qj.wood : "oak").name; }
    var _wsz = tra_fit_text(_woods, _W - 80, 13, "italic");
    tra_dtext(_c, _woods, _W / 2, _y + _h + 22, _wsz, "italic", [216, 196, 154]);
    tra_dtext(_c, _info.foot, _W / 2, min(_H - 16, _y + _h + 48), 14, "italic", [232, 212, 168]);
    math_set_epsilon(_eps);
}
