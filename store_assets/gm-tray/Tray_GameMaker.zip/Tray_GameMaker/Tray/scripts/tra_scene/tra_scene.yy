{
  "$GMScript": "v1",
  "%Name": "tra_scene",
  "name": "tra_scene",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}