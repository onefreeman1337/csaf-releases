/// tra_scene.gml - the table as a screen: a struct you create from a puzzle, STEP once per game frame and DRAW into any
/// rectangle. The tray sits in its case, the pieces wait in the box beside it turned every which way; the player picks
/// them up, turns and flips them and fits every one back. A ghost shows where a carried piece would land, hints come from
/// the solver, and a filled tray is polished and shown as a finished panel. When it is over, read the result.
///
/// Tray - Generated Packing Puzzles in Wood, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// THE LOOP (ported from the MZ Scene_Tray, frame for frame - every count of frames below is the original's):
///   pick     choose a piece (left/right), OK lifts it, Q/W turn and Shift flips a loose one, Tab asks for a hint; or drag
///            a piece with the mouse; click the plaques (Turn, Flip, Hint, Leave); Escape or a right click leaves.
///   carry    the arrows move the lifted piece over the tray square by square, Q/W/Shift turn and flip it, OK puts it down
///            (it stays in hand if it does not fit), Escape puts it back where it came from.
///   drag     the piece follows the mouse; the right button, the wheel, Q/W and Shift turn it; releasing over the tray
///            drops it where the ghost shows, anywhere else returns it to the box.
///   think    a hint being searched for (spread over frames: on a hard tray it can take a few hundred milliseconds).
///   polish   a band of light runs across the filled panel (40 frames).
///   reveal   the finished panel fades in over 24 frames; then any key or click leaves.
/// ⛔ A step is one 1/60 s frame (the original's timing). At another game speed call tra_scene_step that many times.
///
/// INPUT. tra_scene_step(scene) reads the keyboard and the mouse itself (see tra_input for the keys), with the mouse read
/// in GUI coordinates - draw the scene in a Draw GUI event - or pass your own tra_input(...) from your game's bindings.
///
/// EVENTS. scene.events lists what happened THIS step ("select", "pick", "drop", "box", "turn", "refuse", "hint", "solve",
/// "leave")
/// so your game can play its own sounds; Tray ships no audio.

#macro TRA_FADE 24

/// @function tra_puzzle_for(seed, [difficulty], [shape])
/// @description A graded puzzle from the book (instant - see tra_book_puzzle) for a seed (a number, or any string, e.g.
/// "map 3 chest 7", which is hashed): difficulty "easy" (4-5 pieces), "normal" (6-7), "hard" (8-10), default "normal";
/// shape "rect", "cross", "diamond", "round", "notched", "arch" or "auto" (default: the seed chooses). The same arguments
/// give the same puzzle forever. Returns the puzzle struct, or undefined for a difficulty or shape that is not one.
function tra_puzzle_for(_seed, _diff = "normal", _shape = "auto") {
    var _s = is_numeric(_seed) ? tra_u32(floor(abs(_seed))) : tra_hash(is_undefined(_seed) ? "" : string(_seed));
    if (is_undefined(_diff)) _diff = "normal";
    if (!is_string(_diff) || is_undefined(tra_difficulty(_diff))) return undefined;
    var _shapes = tra_shapes(), _valid = false;
    for (var _i = 0; _i < 6; _i++) if (is_string(_shape) && _shapes[_i] == _shape) _valid = true;
    if (is_undefined(_shape) || _shape == "auto") { _shape = _shapes[_s mod 6]; _s = floor(_s / 6); _valid = true; }
    if (!_valid) return undefined;
    return tra_book_puzzle(_diff, _shape, _s);
}

/// @function tra_input(left, right, up, down, ok, cancel, turn_back, turn_on, flip, hint, [mouse_x], [mouse_y], [held], [click], [right_click], [wheel])
/// @description An input struct for tra_scene_step from your own bindings. left/right/up/down are REPEATING presses (true
/// on the step the selection or the piece should move); ok, cancel, turn_back, turn_on, flip and hint are single presses;
/// the mouse is in the coordinates you draw the scene in: held (left button down), click (left button pressed this step),
/// right_click, wheel (+1 down / -1 up / 0). The built-in reader uses: arrows; Enter, Space or Z = OK; Escape, X or
/// Backspace = cancel; Q or Page Up = turn back; W or Page Down = turn on; Shift = flip; Tab or H = hint.
function tra_input(_l, _r, _u, _d, _ok, _cancel, _tb, _to, _flip, _hint, _mx = -100000, _my = -100000, _held = false, _click = false, _rclick = false, _wheel = 0) {
    return { left: _l == true, right: _r == true, up: _u == true, down: _d == true, ok: _ok == true, cancel: _cancel == true,
        turnBack: _tb == true, turnOn: _to == true, flip: _flip == true, hint: _hint == true,
        mx: is_numeric(_mx) ? _mx : -100000, my: is_numeric(_my) ? _my : -100000, held: _held == true, click: _click == true, rclick: _rclick == true,
        wheel: is_numeric(_wheel) ? sign(_wheel) : 0 };
}

/// @function tra_scene_create(puzzle, [options])
/// @description A table for a puzzle (tra_puzzle_for, tra_book_puzzle or tra_generate). options (all optional): {title:
/// the brass plate (default "The Cabinetmaker's Tray"), hints: how many the player may ask for (0-99, default 3),
/// quality: internal scale 1-3 (default 2; higher is sharper on a large screen and costs more to bake), fade: false to skip
/// the fade in from black (and out)}. Returns the scene struct, or undefined for something that is not a puzzle.
function tra_scene_create(_p, _opt = undefined) {
    if (!tra__is_puzzle(_p)) return undefined;
    if (!is_struct(_opt)) _opt = {};
    var _g = function(_o, _k, _d) { return variable_struct_exists(_o, _k) ? variable_struct_get(_o, _k) : _d; };
    var _ss = _g(_opt, "quality", TRA_SS);
    _ss = is_numeric(_ss) ? clamp(round(_ss), 1, 3) : TRA_SS;
    var _title = _g(_opt, "title", undefined);
    if (!is_string(_title) || _title == "") _title = "The Cabinetmaker's Tray";
    var _hints = _g(_opt, "hints", 3);
    _hints = is_numeric(_hints) ? clamp(floor(_hints), 0, 99) : 3;
    var _eps = tra__eps0();
    var _L = tra__scene_layout(), _CA = _L.CASE, _n = array_length(_p.pieces);
    var _s = min(floor(_CA.w / (_p.w + 1.3)), floor(_CA.h / (_p.h + 1.3)), 58);
    var S = {
        v: 1, p: _p, game: tra_new_game(_p), title: _title, ss: _ss, s: _s, mode: "pick", anim: 0, frame: 0, sel: 0, hover: -1,
        status: "", hintsLeft: _hints, carry: -1, from: undefined, cx: 0, cy: 0, gx: 0, gy: 0, snap: { x: 0, y: 0, on: false, fits: false },
        lastTx: -100000, lastTy: -100000, pose: [], T: [], geo: tra_case_geo(_CA.x + _CA.w / 2, _CA.y + _CA.h / 2, _p, _s), ls: 1, slots: [],
        pad: ceil(_s * 0.55), sp: [], order: [], pointer: { visible: false, x: 0, baseY: 0 }, sheen: { visible: false, x: 0 },
        verdictAlpha: 0, verdictInfo: undefined, result: undefined, events: [], fade: 0, think: undefined, bakeMs: { room: 0, board: 0, pieces: 0, ui: 0 },
        surf: { board: undefined, ghost: undefined, pointer: undefined, card: undefined, status: undefined, plaques: undefined, sheen: undefined, verdict: undefined, pieces: array_create(_n, undefined), shadows: array_create(_n, undefined) },
        dirty: { board: true, ghost: true, card: true, status: true, plaques: true, verdict: false, pieces: array_create(_n, true), shadows: array_create(_n, true) },
        cardKey: "", plaqueKey: "", ghostKey: "", rep: { left: 0, right: 0, up: 0, down: 0 }, lastDraw: { x: 0, y: 0, k: 1 }
    };
    // the pieces start in the box turned every which way (seeded, so the same puzzle deals the same way)
    var _r = tra_rng(_p.seed ^ $51ED);
    for (var _i = 0; _i < _n; _i++) {
        var _rot = floor(tra_rnd(_r) * 4) & 3;
        var _flip = tra_rnd(_r) < 0.5;
        array_push(S.pose, { rot: _rot, flip: _flip });
        array_push(S.T, tra_turn(_p.pieces[_i].cells, _rot, _flip));
        array_push(S.sp, { x: 0, y: 0, scale: 1, lift: 0.25 });
        array_push(S.order, _i);
    }
    tra__scene_layout_parts(S);
    for (_i = 0; _i < _n; _i++) tra__scene_place_sprite(S, _i);
    tra__scene_card_check(S); tra__scene_plaque_check(S); tra__scene_place_pointer(S);
    tra__scene_set_status(S, "Fit every piece into the tray. OK picks one up; drag it with the mouse.");
    S.fade = (_g(_opt, "fade", true) == false) ? 0 : TRA_FADE;
    math_set_epsilon(_eps);
    return S;
}

/// @function tra_scene_done(scene)
/// @description True once the player has left the table (after the finished panel, or without filling the tray).
function tra_scene_done(_s) { return is_struct(_s) && _s.mode == "gone"; }

/// @function tra_scene_result(scene)
/// @description Once the tray is filled: {solved: true, moves, hints, difficulty, shape, pieces, ways (the different ways
/// this tray fills, or -1 when it fills more ways than its difficulty allows)}; undefined while playing or if the player
/// left without filling it.
function tra_scene_result(_s) { return is_struct(_s) ? _s.result : undefined; }

/// @function tra_scene_free(scene)
/// @description Free the scene's surfaces.
function tra_scene_free(_s) {
    if (!is_struct(_s)) return;
    var _names = variable_struct_get_names(_s.surf);
    for (var _i = 0; _i < array_length(_names); _i++) {
        var _v = variable_struct_get(_s.surf, _names[_i]);
        if (is_array(_v)) { for (var _j = 0; _j < array_length(_v); _j++) { if (!is_undefined(_v[_j]) && surface_exists(_v[_j])) surface_free(_v[_j]); _v[_j] = undefined; } continue; }
        if (!is_undefined(_v) && surface_exists(_v)) surface_free(_v);
        variable_struct_set(_s.surf, _names[_i], undefined);
    }
    _s.surf.pieces = array_create(array_length(_s.p.pieces), undefined);
    _s.surf.shadows = array_create(array_length(_s.p.pieces), undefined);
}

// ---------------------------------------------------------------------------------------------------------------
// Internals: the original's helpers
// ---------------------------------------------------------------------------------------------------------------

/// @function tra__is_puzzle(p)
/// @description A puzzle struct this scene can play. Internal.
function tra__is_puzzle(_p) {
    if (!is_struct(_p)) return false;
    var _need = ["w", "h", "mask", "pieces", "seed"];
    for (var _i = 0; _i < 5; _i++) if (!variable_struct_exists(_p, _need[_i])) return false;
    if (!is_numeric(_p.w) || !is_numeric(_p.h) || !is_array(_p.mask) || !is_array(_p.pieces) || array_length(_p.pieces) == 0) return false;
    if (array_length(_p.mask) != _p.w * _p.h) return false;
    for (var _j = 0; _j < array_length(_p.pieces); _j++) { var _q = _p.pieces[_j]; if (!is_struct(_q) || !variable_struct_exists(_q, "cells") || !is_array(_q.cells) || array_length(_q.cells) == 0) return false; }
    return true;
}

/// @function tra__scene_layout()
/// @description The original's screen regions in its 816 x 624 design space. Pure.
function tra__scene_layout() {
    return { CASE: { x: 12, y: 64, w: 504, h: 444 }, PARTS: { x: 528, y: 64, w: 276, h: 444 }, TITLE: { x: 208, y: 8, w: 400, h: 48 },
        CARD: { x: 12, y: 516, w: 188, h: 96 }, STATUS: { x: 210, y: 514, w: 596, h: 38 }, PLAQUES: { x: 222, y: 562, w: 136, h: 36, gap: 146 } };
}

/// @function tra__scene_layout_parts(scene)
/// @description The box: every piece gets a slot the size of the way it was dealt, packed in rows at the largest shared
/// scale that fits. ⛔ (the original, 2026-09-28) square slots sized for ANY turn left the box two thirds empty with the
/// pieces at 0.4. Internal.
function tra__scene_layout_parts(S) {
    var PA = tra__scene_layout().PARTS, _s = S.s, _pad = 16, _n = array_length(S.p.pieces), _ls, _rows = [], _innerW = PA.w - 28, _innerH = PA.h - 28;
    for (_ls = 1; _ls >= 0.3; _ls -= 0.02) {
        _rows = [];
        var _row = [], _rw = 0, _rh = 0, _total = 0;
        for (var _i = 0; _i < _n; _i++) {
            var _sw = S.T[_i].w * _s * _ls + _pad, _sh = S.T[_i].h * _s * _ls + _pad;
            if (_rw + _sw > _innerW && array_length(_row) > 0) { array_push(_rows, { items: _row, h: _rh, w: _rw }); _total += _rh; _row = []; _rw = 0; _rh = 0; }
            array_push(_row, { i: _i, sw: _sw, sh: _sh }); _rw += _sw; _rh = max(_rh, _sh);
        }
        if (array_length(_row) > 0) { array_push(_rows, { items: _row, h: _rh, w: _rw }); _total += _rh; }
        var _fitsW = true;
        for (var _k = 0; _k < array_length(_rows); _k++) if (_rows[_k].w > _innerW) _fitsW = false;
        if (_total <= _innerH && _fitsW) break;
    }
    S.ls = _ls; S.slots = array_create(_n, undefined);
    var _used = 0;
    for (var _u = 0; _u < array_length(_rows); _u++) _used += _rows[_u].h;
    var _gapY = max(0, (_innerH - _used) / (array_length(_rows) + 1)), _y = PA.y + 14 + _gapY;
    for (var _r = 0; _r < array_length(_rows); _r++) {
        var _R = _rows[_r], _gapX = max(0, (_innerW - _R.w) / (array_length(_R.items) + 1)), _x = PA.x + 14 + _gapX;
        for (var _j = 0; _j < array_length(_R.items); _j++) { var _it = _R.items[_j]; S.slots[_it.i] = { cx: _x + _it.sw / 2, cy: _y + _R.h / 2, sw: _it.sw, sh: _it.sh }; _x += _it.sw + _gapX; }
        _y += _R.h + _gapY;
    }
}

/// @function tra__scene_paint(scene, i, lift)
/// @description Set piece i's lift (how far off the table: its shadow). Only the SHADOW is re-baked (~0.6 ms MEASURED);
/// the piece itself is re-baked only when its pose changes (tra__scene_repose). Internal.
function tra__scene_paint(S, _i, _lift) { if (S.sp[_i].lift != _lift) { S.sp[_i].lift = _lift; S.dirty.shadows[_i] = true; } }

/// @function tra__scene_repose(scene, i)
/// @description Piece i turned or flipped: re-bake the piece and its shadow. Internal.
function tra__scene_repose(S, _i) { S.dirty.pieces[_i] = true; S.dirty.shadows[_i] = true; }

/// @function tra__scene_place_sprite(scene, i)
/// @description Put a resting piece where it belongs: in the tray at full size, or in its slot in the box at the box's
/// scale. Internal.
function tra__scene_place_sprite(S, _i) {
    if (_i == S.carry) return;
    var _sp = S.sp[_i], _pl = S.game.placed[_i], _s = S.s, T = S.T[_i], _pad = S.pad;
    if (!is_undefined(_pl)) { _sp.scale = 1; _sp.x = S.geo.x + _pl.x * _s - _pad; _sp.y = S.geo.y + _pl.y * _s - _pad; }
    else {
        var _sl = S.slots[_i], _sc = min(S.ls, (_sl.sw - 8) / (T.w * _s), (_sl.sh - 8) / (T.h * _s));
        _sp.scale = _sc; _sp.x = _sl.cx - (T.w * _s / 2 + _pad) * _sc; _sp.y = _sl.cy - (T.h * _s / 2 + _pad) * _sc;
    }
}

/// @function tra__scene_piece_box(scene, i)
/// @description Screen box of a resting piece's turned squares: {x, y, sc}. Internal.
function tra__scene_piece_box(S, _i) { var _sp = S.sp[_i]; return { x: _sp.x + S.pad * _sp.scale, y: _sp.y + S.pad * _sp.scale, sc: _sp.scale }; }

/// @function tra__scene_place_pointer(scene)
function tra__scene_place_pointer(S) {
    var _show = (S.mode == "pick" && S.sel >= 0);
    S.pointer.visible = _show;
    if (!_show) return;
    var _b = tra__scene_piece_box(S, S.sel), T = S.T[S.sel];
    S.pointer.x = _b.x + T.w * S.s * _b.sc / 2; S.pointer.baseY = _b.y - 4;
}

/// @function tra__scene_placed_count(scene)
function tra__scene_placed_count(S) { var _n = 0; for (var _i = 0; _i < array_length(S.game.placed); _i++) if (!is_undefined(S.game.placed[_i])) _n++; return _n; }

/// @function tra__scene_card_check(scene)
function tra__scene_card_check(S) {
    var _g = S.game, _key = string(tra__scene_placed_count(S)) + "|" + string(_g.moves) + "|" + string(_g.hints) + "|" + string(S.hintsLeft);
    if (_key != S.cardKey) { S.cardKey = _key; S.dirty.card = true; }
}

/// @function tra__scene_plaque_states(scene)
function tra__scene_plaque_states(S) {
    var _m = S.mode, _holding = (_m == "carry" || _m == "drag"), _loose = (_m == "pick" && S.sel >= 0 && is_undefined(S.game.placed[S.sel])), _live = (_m == "pick" || _holding);
    return [(_holding || _loose) ? "idle" : "off", (_holding || _loose) ? "idle" : "off", (_m == "pick" && S.hintsLeft > 0) ? "idle" : "off", _live ? "idle" : "off"];
}

/// @function tra__scene_plaque_check(scene)
function tra__scene_plaque_check(S) {
    var _st = tra__scene_plaque_states(S), _key = _st[0] + "|" + _st[1] + "|" + _st[2] + "|" + _st[3] + "|" + string(S.hover);
    if (_key != S.plaqueKey) { S.plaqueKey = _key; S.dirty.plaques = true; }
}

/// @function tra__scene_set_status(scene, text)
function tra__scene_set_status(S, _t) { if (_t == S.status) return; S.status = _t; S.dirty.status = true; }

/// @function tra__scene_ghost_check(scene)
/// @description Show where the held piece would land (only when the square it snaps to, its turn or the verdict changes).
function tra__scene_ghost_check(S) {
    var _sn = S.snap, _i = S.carry, _key = "";
    if (_sn.on && _i >= 0) { var _po = S.pose[_i]; _key = string(_i) + "," + string(_sn.x) + "," + string(_sn.y) + "," + string(_po.rot) + "," + string(_po.flip) + "," + string(_sn.fits); }
    if (_key != S.ghostKey) { S.ghostKey = _key; S.dirty.ghost = true; }
}

/// @function tra__scene_set_snap(scene, x, y)
/// @description Over the tray = at least half the piece's squares over the box (one row grazing the rim is still the
/// table); fits = the rules allow it there. Internal.
function tra__scene_set_snap(S, _x, _y) {
    var T = S.T[S.carry], _p = S.p, _cs = T.cells, _inside = 0;
    for (var _k = 0; _k < array_length(_cs); _k++) { var _cx = _x + _cs[_k][0], _cy = _y + _cs[_k][1]; if (_cx >= 0 && _cy >= 0 && _cx < _p.w && _cy < _p.h) _inside++; }
    var _on = (_inside * 2 >= array_length(_cs));
    S.snap.x = _x; S.snap.y = _y; S.snap.on = _on; S.snap.fits = _on && tra_fits(_p, S.game, S.carry, T.cells, _x, _y);
    tra__scene_ghost_check(S);
}

/// @function tra__scene_wood_name(scene, i)
function tra__scene_wood_name(S, _i) { return string_lower(tra_wood(S.p.pieces[_i].wood).name); }

/// @function tra__scene_to_front(scene, i)
/// @description Draw piece i after every other resting piece (the original re-adds a settled sprite to its layer). Internal.
function tra__scene_to_front(S, _i) {
    var _o = [];
    for (var _k = 0; _k < array_length(S.order); _k++) if (S.order[_k] != _i) array_push(_o, S.order[_k]);
    array_push(_o, _i);
    S.order = _o;
}

// ---------------------------------------------------------------------------------------------------------------
// Turning, carrying, dropping
// ---------------------------------------------------------------------------------------------------------------

/// @function tra__scene_turn(scene, i, dir, flip)
/// @description Turn (dir +1 clockwise, -1 back) or flip a piece; a held piece keeps its place over the tray. Internal.
function tra__scene_turn(S, _i, _dir, _flip) {
    var _po = S.pose[_i];
    if (_flip) _po.flip = !_po.flip; else _po.rot = (_po.rot + _dir + 4) & 3;
    S.T[_i] = tra_turn(S.p.pieces[_i].cells, _po.rot, _po.flip);
    tra__scene_repose(S, _i);
    tra__scene_paint(S, _i, (_i == S.carry) ? 0.9 : 0.25);
    array_push(S.events, "turn");
    if (_i == S.carry) {
        var T = S.T[_i];
        if (S.mode == "carry") { S.cx = max(0, min(S.p.w - T.w, S.cx)); S.cy = max(0, min(S.p.h - T.h, S.cy)); tra__scene_carry_moved(S); }
        else { S.gx = T.w * S.s / 2; S.gy = T.h * S.s / 2; tra__scene_drag_moved(S, true, S.lastTx, S.lastTy); }
    } else { tra__scene_place_sprite(S, _i); tra__scene_place_pointer(S); }
}

/// @function tra__scene_begin_carry(scene, i)
/// @description Keyboard: lift a piece and hold it over the tray. Internal.
function tra__scene_begin_carry(S, _i) {
    var _pl = S.game.placed[_i], T = S.T[_i], _p = S.p;
    S.from = is_undefined(_pl) ? undefined : { x: _pl.x, y: _pl.y };
    if (!is_undefined(_pl)) tra_lift(_p, S.game, _i);
    S.carry = _i; S.mode = "carry";
    S.cx = is_undefined(_pl) ? max(0, floor((_p.w - T.w) / 2)) : _pl.x; S.cy = is_undefined(_pl) ? max(0, floor((_p.h - T.h) / 2)) : _pl.y;
    tra__scene_paint(S, _i, 0.9); array_push(S.events, "pick");
    tra__scene_carry_moved(S); tra__scene_place_pointer(S); tra__scene_plaque_check(S); tra__scene_card_check(S);
    tra__scene_set_status(S, "Arrows move it, Q and W turn it, Shift flips it. OK puts it down.");
}

/// @function tra__scene_carry_moved(scene)
function tra__scene_carry_moved(S) {
    var _sp = S.sp[S.carry];
    _sp.scale = 1; _sp.x = S.geo.x + S.cx * S.s - S.pad; _sp.y = S.geo.y + S.cy * S.s - S.pad - 6;
    tra__scene_set_snap(S, S.cx, S.cy);
}

/// @function tra__scene_begin_drag(scene, i, x, y)
/// @description Mouse and touch: pick a piece up where it was grabbed and let it follow the pointer. Internal.
function tra__scene_begin_drag(S, _i, _x, _y) {
    var _b = tra__scene_piece_box(S, _i), _pl = S.game.placed[_i];
    S.gx = (_x - _b.x) / _b.sc; S.gy = (_y - _b.y) / _b.sc;
    S.from = is_undefined(_pl) ? undefined : { x: _pl.x, y: _pl.y };
    if (!is_undefined(_pl)) tra_lift(S.p, S.game, _i);
    S.carry = _i; S.sel = _i; S.mode = "drag";
    tra__scene_paint(S, _i, 0.9); array_push(S.events, "pick");
    tra__scene_drag_moved(S, true, _x, _y); tra__scene_place_pointer(S); tra__scene_plaque_check(S); tra__scene_card_check(S);
    tra__scene_set_status(S, "Drop it on the tray. Right button or wheel turns it.");
}

/// @function tra__scene_drag_moved(scene, force, tx, ty)
function tra__scene_drag_moved(S, _force, _tx, _ty) {
    var _sp = S.sp[S.carry], _s = S.s;
    if (!_force && _tx == S.lastTx && _ty == S.lastTy) return;
    S.lastTx = _tx; S.lastTy = _ty;
    _sp.scale = 1; _sp.x = _tx - S.gx - S.pad; _sp.y = _ty - S.gy - S.pad;
    tra__scene_set_snap(S, tra_jsround((_tx - S.gx - S.geo.x) / _s), tra_jsround((_ty - S.gy - S.geo.y) / _s));
}

/// @function tra__scene_drop(scene, x, y)
/// @description Put the held piece down at (x, y) if it fits; otherwise say so and keep holding it (keyboard) or box it
/// (mouse). Internal.
function tra__scene_drop(S, _x, _y) {
    var _i = S.carry, T = S.T[_i];
    if (!tra_place(S.p, S.game, _i, T.cells, _x, _y)) {
        array_push(S.events, "refuse"); tra__scene_set_status(S, "It does not fit there.");
        if (S.mode == "drag") tra__scene_to_box(S, "It does not fit there: back in the box.");
        return false;
    }
    tra__scene_settle(S, _i); array_push(S.events, "drop");
    if (S.game.done) { tra__scene_begin_polish(S); return true; }
    tra__scene_set_status(S, "Fit every piece into the tray.");
    return true;
}

/// @function tra__scene_put_back(scene)
/// @description The held piece goes back where it came from (keyboard cancel). Internal.
function tra__scene_put_back(S) {
    var _i = S.carry, _f = S.from;
    if (!is_undefined(_f)) { tra_place(S.p, S.game, _i, S.T[_i].cells, _f.x, _f.y); S.game.moves--; }
    tra__scene_settle(S, _i); tra__scene_set_status(S, is_undefined(_f) ? "Back in the box." : "Put back where it was.");
}

/// @function tra__scene_to_box(scene, message)
function tra__scene_to_box(S, _msg) { var _i = S.carry; tra__scene_settle(S, _i); array_push(S.events, "box"); tra__scene_set_status(S, _msg); }

/// @function tra__scene_settle(scene, i)
/// @description End a hold: the piece rests (in the tray or its slot), the ghost clears, back to choosing. Internal.
function tra__scene_settle(S, _i) {
    S.carry = -1; S.from = undefined; S.snap.on = false; S.mode = "pick"; S.sel = _i;
    tra__scene_to_front(S, _i);
    tra__scene_paint(S, _i, is_undefined(S.game.placed[_i]) ? 0.25 : 0); tra__scene_place_sprite(S, _i);
    tra__scene_ghost_check(S); tra__scene_place_pointer(S); tra__scene_plaque_check(S); tra__scene_card_check(S);
}

/// @function tra__scene_hint(scene)
/// @description A hint: a piece of a solution that keeps what the player has placed, or the placed piece that has to come
/// out. The search runs in "think" (spread over frames); tra__scene_hint_apply finishes it. Internal.
function tra__scene_hint(S) {
    if (S.mode != "pick") return;
    if (S.hintsLeft <= 0) { array_push(S.events, "refuse"); tra__scene_set_status(S, "No hints left."); return; }
    S.think = tra_hint_begin(S.p, S.game); S.mode = "think"; S.anim = 0;
    tra__scene_place_pointer(S); tra__scene_plaque_check(S);
}

/// @function tra__scene_hint_apply(scene, hint)
function tra__scene_hint_apply(S, _h) {
    var _p = S.p, _g = S.game;
    S.mode = "pick"; S.think = undefined;
    if (variable_struct_exists(_h, "place")) {
        var _i = _h.place.piece, _po = tra_pose_of(_p.pieces[_i].cells, _h.place.cells);
        if (is_undefined(_po)) _po = { rot: 0, flip: false };
        S.pose[_i] = _po; S.T[_i] = tra_turn(_p.pieces[_i].cells, _po.rot, _po.flip); tra__scene_repose(S, _i);
        tra_place(_p, _g, _i, S.T[_i].cells, _h.place.x, _h.place.y); _g.moves--;
        tra__scene_settle(S, _i); tra__scene_set_status(S, "Hint: the " + tra__scene_wood_name(S, _i) + " piece goes here.");
    } else if (variable_struct_exists(_h, "lift") && _h.lift >= 0) {
        var _j = _h.lift;
        tra_lift(_p, _g, _j); tra__scene_settle(S, _j); tra__scene_set_status(S, "The " + tra__scene_wood_name(S, _j) + " piece cannot stay where it was: it is back in the box.");
    } else { tra__scene_set_status(S, "No hint found."); tra__scene_place_pointer(S); tra__scene_plaque_check(S); return; }
    _g.hints++; S.hintsLeft--; array_push(S.events, "hint"); tra__scene_card_check(S); tra__scene_plaque_check(S);
    if (_g.done) tra__scene_begin_polish(S);
}

/// @function tra__scene_begin_polish(scene)
function tra__scene_begin_polish(S) {
    S.mode = "polish"; S.anim = 0; S.pointer.visible = false; array_push(S.events, "solve"); tra__scene_plaque_check(S);
    tra__scene_set_status(S, "The tray is full."); S.sheen.visible = true; S.sheen.x = S.geo.board.x - 140;
}

/// @function tra__scene_finish(scene)
function tra__scene_finish(S) {
    var _g = S.game, _p = S.p, D = tra_difficulty(_p.difficulty);
    var _limit = is_struct(D) ? D.ways : 40;
    var _graded = variable_struct_exists(_p, "graded") && _p.graded == true, _ways = variable_struct_exists(_p, "ways") ? _p.ways : -1;
    var _exact = _graded && _ways >= 1 && _ways <= _limit;
    S.result = { solved: true, moves: _g.moves, hints: _g.hints, difficulty: _p.difficulty, shape: _p.shape, pieces: array_length(_p.pieces), ways: _exact ? _ways : -1 };
    var _waysText = _exact ? ((_ways == 1) ? "This tray fills only one way." : "This tray fills " + string(_ways) + " different ways.") : "This tray fills more than " + string(_limit) + " different ways.";
    var _title = "Solved in " + string(_g.moves) + ((_g.moves == 1) ? " move" : " moves") + ((_g.hints != 0) ? ", " + string(_g.hints) + ((_g.hints == 1) ? " hint" : " hints") : ", no hints");
    S.verdictInfo = { title: _title, sub: _waysText, foot: "Press a key or click to leave the table." };
    S.dirty.verdict = true; S.verdictAlpha = 0; S.anim = 0; S.mode = "reveal";
    tra__scene_set_status(S, "");
}

/// @function tra__scene_leave(scene)
function tra__scene_leave(S) {
    if (S.mode == "leaving" || S.mode == "gone") return;
    S.mode = "leaving"; S.pointer.visible = false; S.fade = 0; array_push(S.events, "leave");
}

// ---------------------------------------------------------------------------------------------------------------
// The step
// ---------------------------------------------------------------------------------------------------------------

/// @function tra__scene_rep(scene, key, down)
/// @description The original's key repeat: true on the first frame, then every 6 frames after 24. Internal.
function tra__scene_rep(S, _k, _down) {
    var _n = variable_struct_get(S.rep, _k);
    if (!_down) { variable_struct_set(S.rep, _k, 0); return false; }
    _n++; variable_struct_set(S.rep, _k, _n);
    return (_n == 1) || (_n > 24 && ((_n - 24) mod 6) == 0);
}

/// @function tra__scene_input_default(scene)
/// @description The keyboard and the mouse (GUI coordinates) as an input struct (see tra_input for the keys). Internal.
function tra__scene_input_default(S) {
    var _l = tra__scene_rep(S, "left", keyboard_check(vk_left)), _r = tra__scene_rep(S, "right", keyboard_check(vk_right));
    var _u = tra__scene_rep(S, "up", keyboard_check(vk_up)), _d = tra__scene_rep(S, "down", keyboard_check(vk_down));
    var _wh = mouse_wheel_down() ? 1 : (mouse_wheel_up() ? -1 : 0);
    return tra_input(_l, _r, _u, _d,
        keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("Z")),
        keyboard_check_pressed(vk_escape) || keyboard_check_pressed(ord("X")) || keyboard_check_pressed(vk_backspace),
        keyboard_check_pressed(ord("Q")) || keyboard_check_pressed(vk_pageup),
        keyboard_check_pressed(ord("W")) || keyboard_check_pressed(vk_pagedown),
        keyboard_check_pressed(vk_shift),
        keyboard_check_pressed(vk_tab) || keyboard_check_pressed(ord("H")),
        device_mouse_x_to_gui(0), device_mouse_y_to_gui(0), mouse_check_button(mb_left), mouse_check_button_pressed(mb_left), mouse_check_button_pressed(mb_right), _wh);
}

/// @function tra_scene_step(scene, [input])
/// @description Advance the table one frame. Without an input struct the scene reads the keyboard and the mouse (GUI
/// coordinates) itself; pass tra_input(...) to use your own bindings. Returns the scene's mode.
function tra_scene_step(S, _in = undefined) {
    if (!is_struct(S) || S.mode == "gone") return is_struct(S) ? S.mode : "gone";
    var _eps = tra__eps0();
    S.events = [];
    S.frame++;
    if (!is_struct(_in)) _in = tra__scene_input_default(S);
    else if (!variable_struct_exists(_in, "wheel")) {
        // a hand-made struct: read what it says, default the rest (tra_input builds a complete one)
        var _gi = function(_o, _k, _d) { return variable_struct_exists(_o, _k) ? variable_struct_get(_o, _k) : _d; };
        _in = tra_input(_gi(_in, "left", false), _gi(_in, "right", false), _gi(_in, "up", false), _gi(_in, "down", false), _gi(_in, "ok", false), _gi(_in, "cancel", false),
            _gi(_in, "turnBack", false), _gi(_in, "turnOn", false), _gi(_in, "flip", false), _gi(_in, "hint", false), _gi(_in, "mx", -100000), _gi(_in, "my", -100000),
            _gi(_in, "held", false), _gi(_in, "click", false), _gi(_in, "rclick", false), _gi(_in, "wheel", 0));
    }
    // the mouse in design coordinates, through the last draw's placement
    var _k = max(0.0001, S.lastDraw.k), _tx = (_in.mx - S.lastDraw.x) / _k, _ty = (_in.my - S.lastDraw.y) / _k;
    if (S.fade > 0 && S.mode != "leaving") S.fade--;
    var _m = S.mode;
    if (_m == "pick") tra__scene_pick(S, _in, _tx, _ty);
    else if (_m == "carry") tra__scene_carry(S, _in, _tx, _ty);
    else if (_m == "drag") tra__scene_drag(S, _in, _tx, _ty);
    else if (_m == "think") {
        S.anim++;
        if (tra_hint_step(S.think, 4)) tra__scene_hint_apply(S, S.think.result);
        else if (S.anim == 8) tra__scene_set_status(S, "Looking for a hint...");
    }
    else if (_m == "polish") { var _a = ++S.anim, _bd = S.geo.board; S.sheen.x = _bd.x - 140 + (_bd.w + 140) * min(1, _a / 40); if (_a >= 40) { S.sheen.visible = false; tra__scene_finish(S); } }
    else if (_m == "reveal") { S.anim++; S.verdictAlpha = min(1, S.anim * 11 / 255); if (S.anim >= 24) S.mode = "done"; }
    else if (_m == "done") { if (_in.ok || _in.cancel || _in.click || _in.rclick) tra__scene_leave(S); }
    else if (_m == "leaving") { S.fade++; if (S.fade >= TRA_FADE) S.mode = "gone"; }
    math_set_epsilon(_eps);
    return S.mode;
}

/// @function tra__scene_plaque_at(x, y)
function tra__scene_plaque_at(_x, _y) {
    var P = tra__scene_layout().PLAQUES;
    if (_y < P.y || _y >= P.y + P.h) return -1;
    for (var _k = 0; _k < 4; _k++) if (_x >= P.x + _k * P.gap && _x < P.x + _k * P.gap + P.w) return _k;
    return -1;
}

/// @function tra__scene_piece_at(scene, x, y)
/// @description The resting piece under a design point (the highest index first, as the original tests), or -1. Tests the
/// piece's own squares, not its box. Internal.
function tra__scene_piece_at(S, _x, _y) {
    var _s = S.s;
    for (var _i = array_length(S.p.pieces) - 1; _i >= 0; _i--) {
        if (_i == S.carry) continue;
        var _b = tra__scene_piece_box(S, _i), _cs = S.T[_i].cells, _lx = floor((_x - _b.x) / (_s * _b.sc)), _ly = floor((_y - _b.y) / (_s * _b.sc));
        for (var _k = 0; _k < array_length(_cs); _k++) if (_cs[_k][0] == _lx && _cs[_k][1] == _ly) return _i;
    }
    return -1;
}

/// @function tra__scene_press_plaque(scene, k)
function tra__scene_press_plaque(S, _k) {
    var _st = tra__scene_plaque_states(S);
    if (_st[_k] == "off") { array_push(S.events, "refuse"); return; }
    var _i = (S.carry >= 0) ? S.carry : S.sel;
    if (_k == 0) tra__scene_turn(S, _i, 1, false); else if (_k == 1) tra__scene_turn(S, _i, 0, true); else if (_k == 2) tra__scene_hint(S); else tra__scene_leave(S);
}

/// @function tra__scene_pick(scene, input, tx, ty)
function tra__scene_pick(S, _in, _tx, _ty) {
    var _n = array_length(S.p.pieces);
    if (_in.left || _in.up) { S.sel = (S.sel + _n - 1) mod _n; tra__scene_place_pointer(S); tra__scene_plaque_check(S); array_push(S.events, "select"); }
    else if (_in.right || _in.down) { S.sel = (S.sel + 1) mod _n; tra__scene_place_pointer(S); tra__scene_plaque_check(S); array_push(S.events, "select"); }
    if (_in.ok) { tra__scene_begin_carry(S, S.sel); return; }
    if (_in.turnBack || _in.turnOn || _in.flip) {
        if (!is_undefined(S.game.placed[S.sel])) { tra__scene_set_status(S, "Pick it up first (OK), then turn it."); return; }
        tra__scene_turn(S, S.sel, _in.turnBack ? -1 : 1, _in.flip); return;
    }
    if (_in.hint) { tra__scene_hint(S); return; }
    if (_in.cancel || _in.rclick) { tra__scene_leave(S); return; }
    var _hover = tra__scene_plaque_at(_tx, _ty);
    if (_hover != S.hover) { S.hover = _hover; tra__scene_plaque_check(S); }
    if (_in.click) {
        if (_hover >= 0) { tra__scene_press_plaque(S, _hover); return; }
        var _i = tra__scene_piece_at(S, _tx, _ty);
        if (_i >= 0) tra__scene_begin_drag(S, _i, _tx, _ty);
    }
}

/// @function tra__scene_carry(scene, input, tx, ty)
function tra__scene_carry(S, _in, _tx, _ty) {
    var T = S.T[S.carry], _p = S.p, _moved = false;
    if (_in.left && S.cx > 0) { S.cx--; _moved = true; }
    else if (_in.right && S.cx < _p.w - T.w) { S.cx++; _moved = true; }
    if (_in.up && S.cy > 0) { S.cy--; _moved = true; }
    else if (_in.down && S.cy < _p.h - T.h) { S.cy++; _moved = true; }
    if (_moved) tra__scene_carry_moved(S);
    if (_in.turnBack) { tra__scene_turn(S, S.carry, -1, false); return; }
    if (_in.turnOn) { tra__scene_turn(S, S.carry, 1, false); return; }
    if (_in.flip) { tra__scene_turn(S, S.carry, 0, true); return; }
    if (_in.ok) { tra__scene_drop(S, S.cx, S.cy); return; }
    if (_in.cancel || _in.rclick) { tra__scene_put_back(S); return; }
    var _hover = tra__scene_plaque_at(_tx, _ty);
    if (_hover != S.hover) { S.hover = _hover; tra__scene_plaque_check(S); }
    if (_in.click && _hover >= 0) tra__scene_press_plaque(S, _hover);
}

/// @function tra__scene_drag(scene, input, tx, ty)
function tra__scene_drag(S, _in, _tx, _ty) {
    if (_in.rclick || _in.turnOn) { tra__scene_turn(S, S.carry, 1, false); return; }
    if (_in.turnBack) { tra__scene_turn(S, S.carry, -1, false); return; }
    if (_in.flip) { tra__scene_turn(S, S.carry, 0, true); return; }
    if (_in.wheel != 0) { tra__scene_turn(S, S.carry, (_in.wheel > 0) ? 1 : -1, false); return; }
    if (_in.held) { tra__scene_drag_moved(S, false, _tx, _ty); return; }
    // released
    if (S.snap.on && S.snap.fits) tra__scene_drop(S, S.snap.x, S.snap.y);
    else tra__scene_to_box(S, S.snap.on ? "It does not fit there: back in the box." : "Back in the box.");
}

// ---------------------------------------------------------------------------------------------------------------
// The draw
// ---------------------------------------------------------------------------------------------------------------

/// @function tra__scene_bake(scene)
/// @description Re-bake whatever changed or was lost (surfaces are volatile). Internal.
function tra__scene_bake(S) {
    var _ss = S.ss, _sf = S.surf, _d = S.dirty, L = tra__scene_layout(), _p = S.p, _t0 = get_timer();
    tra_room_prepare(_ss);   // the workbench and the parts box, shared by every table in the game
    var _tb = get_timer();
    S.bakeMs = { room: (_tb - _t0) / 1000, board: 0, pieces: 0, ui: 0 };
    // ⛔ a GML anonymous function does not capture the enclosing locals: every painter is a METHOD bound to its data
    if (_d.board || is_undefined(_sf.board) || !surface_exists(_sf.board)) {
        var _words = ["", "", "", "three", "four", "five", "six", "seven", "eight", "nine", "ten"], _np = array_length(_p.pieces);
        var _sub = string(_p.difficulty) + ", " + ((_np < array_length(_words)) ? _words[_np] : string(_np)) + " pieces, " + ((string_pos(string_char_at(_p.shape, 1), "aeiou") > 0) ? "an " : "a ") + string(_p.shape) + " tray";
        _sf.board = tra_bake(_sf.board, 816, 624, _ss, method({ p: _p, s: S.s, L: L, title: S.title, sub: _sub }, function(_c) {
            tra_draw_case(_c, L.CASE.x + L.CASE.w / 2, L.CASE.y + L.CASE.h / 2, p, s);
            tra_draw_title(_c, L.TITLE.x, L.TITLE.y, L.TITLE.w, L.TITLE.h, title, sub);
        }));
        _d.board = false;
    }
    var _tp = get_timer();
    S.bakeMs.board = (_tp - _tb) / 1000;
    // while the screen is still dark from the fade-in, the pieces are baked a few at a time (each ~20-30 ms at 2x), so
    // opening a table does not stall one frame for all of them; once it is light, everything owed is baked at once
    var _spread = (S.fade > 6 && S.mode != "leaving");
    for (var _i = 0; _i < array_length(_p.pieces); _i++) {
        if (!_d.pieces[_i] && !is_undefined(_sf.pieces[_i]) && surface_exists(_sf.pieces[_i])) continue;
        if (_spread && get_timer() - _t0 > 12000) break;
        var _bw = 0, _bh = 0, _cs = _p.pieces[_i].cells;
        for (var _k = 0; _k < array_length(_cs); _k++) { _bw = max(_bw, _cs[_k][0] + 1); _bh = max(_bh, _cs[_k][1] + 1); }
        var _side = ceil(max(_bw, _bh) * S.s + S.pad * 2);
        // the piece WITHOUT its shadow: the shadow is its own surface (below), so a lift re-bakes only that
        _sf.pieces[_i] = tra_bake(_sf.pieces[_i], _side, _side, _ss, method({ q: _p.pieces[_i], pad: S.pad, s: S.s, po: S.pose[_i] }, function(_c) {
            tra_draw_piece(_c, q, pad, pad, s, { rot: po.rot, flip: po.flip, shadow: 0 });
        }));
        _d.pieces[_i] = false;
    }
    for (var _j = 0; _j < array_length(_p.pieces); _j++) {
        if (!_d.shadows[_j] && (S.sp[_j].lift <= 0 || (!is_undefined(_sf.shadows[_j]) && surface_exists(_sf.shadows[_j])))) continue;
        if (S.sp[_j].lift <= 0) { _d.shadows[_j] = false; continue; }
        var _bw2 = 0, _bh2 = 0, _cs2 = _p.pieces[_j].cells;
        for (var _k2 = 0; _k2 < array_length(_cs2); _k2++) { _bw2 = max(_bw2, _cs2[_k2][0] + 1); _bh2 = max(_bh2, _cs2[_k2][1] + 1); }
        var _side2 = ceil(max(_bw2, _bh2) * S.s + S.pad * 2);
        _sf.shadows[_j] = tra_bake(_sf.shadows[_j], _side2, _side2, _ss, method({ q: _p.pieces[_j], pad: S.pad, s: S.s, po: S.pose[_j], lift: S.sp[_j].lift }, function(_c) {
            tra_draw_piece_shadow(_c, q, pad, pad, s, { rot: po.rot, flip: po.flip, shadow: lift });
        }));
        _d.shadows[_j] = false;
    }
    var _tu = get_timer();
    S.bakeMs.pieces = (_tu - _tp) / 1000;
    if (_d.ghost || is_undefined(_sf.ghost) || !surface_exists(_sf.ghost)) {
        var _gi = S.carry, _gd = { on: (S.snap.on && _gi >= 0), cells: (_gi >= 0) ? S.T[_gi].cells : [], x: S.snap.x, y: S.snap.y, s: S.s, fits: S.snap.fits };
        _sf.ghost = tra_bake(_sf.ghost, _p.w * S.s + 4, _p.h * S.s + 4, _ss, method(_gd, function(_c) { if (on) tra_draw_ghost(_c, cells, 2 + x * s, 2 + y * s, s, fits); }));
        _d.ghost = false;
    }
    if (is_undefined(_sf.pointer) || !surface_exists(_sf.pointer)) _sf.pointer = tra_bake(_sf.pointer, 26, 30, _ss, function(_c) { tra_draw_pointer(_c, 26, 30); });
    if (is_undefined(_sf.sheen) || !surface_exists(_sf.sheen)) _sf.sheen = tra_bake(_sf.sheen, 140, S.geo.board.h, _ss, method({ h: S.geo.board.h }, function(_c) { tra_draw_sheen(_c, 140, h); }));
    if (_d.card || is_undefined(_sf.card) || !surface_exists(_sf.card)) {
        var _g = S.game;
        _sf.card = tra_bake(_sf.card, L.CARD.w, L.CARD.h, _ss, method({ w: L.CARD.w, h: L.CARD.h, info: { placed: tra__scene_placed_count(S), total: array_length(_p.pieces), moves: _g.moves, hints: _g.hints, hintsLeft: S.hintsLeft } }, function(_c) { tra_draw_card(_c, w, h, info); }));
        _d.card = false;
    }
    if (_d.status || is_undefined(_sf.status) || !surface_exists(_sf.status)) {
        _sf.status = tra_bake(_sf.status, L.STATUS.w, L.STATUS.h, _ss, method({ w: L.STATUS.w, h: L.STATUS.h, text: S.status }, function(_c) { tra_draw_status(_c, w, h, text); }));
        _d.status = false;
    }
    if (_d.plaques || is_undefined(_sf.plaques) || !surface_exists(_sf.plaques)) {
        var P = L.PLAQUES;
        _sf.plaques = tra_bake(_sf.plaques, P.gap * 3 + P.w + 12, P.h + 12, _ss, method({ P: P, st: tra__scene_plaque_states(S), hover: S.hover }, function(_c) {
            var _labels = ["Turn", "Flip", "Hint", "Leave"];
            for (var _q = 0; _q < 4; _q++) tra_draw_plaque(_c, 6 + _q * P.gap, 6, P.w, P.h, _labels[_q], (st[_q] == "idle" && hover == _q) ? "on" : st[_q]);
        }));
        _d.plaques = false;
    }
    if (is_struct(S.verdictInfo) && (_d.verdict || is_undefined(_sf.verdict) || !surface_exists(_sf.verdict))) {
        _sf.verdict = tra_bake(_sf.verdict, 816, 624, _ss, method({ p: _p, placed: S.game.placed, info: S.verdictInfo }, function(_c) { tra_draw_verdict(_c, 816, 624, p, placed, info); }));
        _d.verdict = false;
    }
    S.bakeMs.ui = (get_timer() - _tu) / 1000;
}

/// @function tra_scene_prepare(scene)
/// @description Bake everything the table shows NOW (the shared room on the first table of a game, the case, every piece,
/// the cards) instead of spreading the pieces over the fade-in. For a loading screen, or before showing a table with
/// fade: false. MEASURED cost: see the Readme.
function tra_scene_prepare(S) {
    if (!is_struct(S)) return;
    var _f = S.fade;
    S.fade = 0;
    var _eps = tra__eps0();
    tra__scene_bake(S);
    math_set_epsilon(_eps);
    S.fade = _f;
}

/// @function tra__pm(surface, x, y, scale, alpha)
/// @description Draw a premultiplied surface at a screen position (the state set by tra_scene_draw). Internal.
function tra__pm(_sf, _x, _y, _sc, _a) {
    if (is_undefined(_sf) || !surface_exists(_sf) || _a <= 0) return;
    draw_surface_ext(_sf, _x, _y, _sc, _sc, 0, merge_colour(c_black, c_white, clamp(_a, 0, 1)), _a);
}

/// @function tra_scene_draw(scene, x, y, w, h)
/// @description Draw the table fitted into the rectangle (x, y, w, h) at the original's 816 x 624 proportions, centred
/// (letterboxed by the caller's own background). Bakes whatever changed first. Restores the caller's blend, filter and
/// matrix state. Call it from Draw GUI to use the built-in mouse input.
function tra_scene_draw(S, _x, _y, _w, _h) {
    if (!is_struct(S) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w) || !is_numeric(_h) || _w <= 0 || _h <= 0) return;
    var _eps = tra__eps0();
    tra__scene_bake(S);
    var _ss = S.ss, _k = min(_w / 816, _h / 624), _ox = _x + (_w - 816 * _k) / 2, _oy = _y + (_h - 624 * _k) / 2, L = tra__scene_layout();
    S.lastDraw = { x: _ox, y: _oy, k: _k };
    var _u = _k / _ss;   // a baked pixel on screen
    gpu_push_state();
    gpu_set_texfilter(true);
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    gpu_set_ztestenable(false);
    tra__pm(global.__tra_room.sf, _ox, _oy, _u, 1);
    tra__pm(S.surf.board, _ox, _oy, _u, 1);
    tra__pm(S.surf.ghost, _ox + (S.geo.x - 2) * _k, _oy + (S.geo.y - 2) * _k, _u, 1);
    for (var _o = 0; _o < array_length(S.order); _o++) {
        var _i = S.order[_o];
        if (_i == S.carry) continue;
        var _sp = S.sp[_i];
        if (_sp.lift > 0) tra__pm(S.surf.shadows[_i], _ox + _sp.x * _k, _oy + _sp.y * _k, _u * _sp.scale, 1);
        tra__pm(S.surf.pieces[_i], _ox + _sp.x * _k, _oy + _sp.y * _k, _u * _sp.scale, 1);
    }
    if (S.carry >= 0) {
        var _cp = S.sp[S.carry];
        if (_cp.lift > 0) tra__pm(S.surf.shadows[S.carry], _ox + _cp.x * _k, _oy + _cp.y * _k, _u * _cp.scale, 1);
        tra__pm(S.surf.pieces[S.carry], _ox + _cp.x * _k, _oy + _cp.y * _k, _u * _cp.scale, 1);
    }
    if (S.pointer.visible) {
        var _py = S.pointer.baseY + sin(S.frame * 0.12) * 3;
        tra__pm(S.surf.pointer, _ox + (S.pointer.x - 13) * _k, _oy + (_py - 30) * _k, _u, 1);
    }
    tra__pm(S.surf.card, _ox + L.CARD.x * _k, _oy + L.CARD.y * _k, _u, 1);
    tra__pm(S.surf.status, _ox + L.STATUS.x * _k, _oy + L.STATUS.y * _k, _u, 1);
    tra__pm(S.surf.plaques, _ox + (L.PLAQUES.x - 6) * _k, _oy + (L.PLAQUES.y - 6) * _k, _u, 1);
    if (S.sheen.visible) {
        gpu_set_blendmode_ext(bm_one, bm_one);   // the original's ADD
        tra__pm(S.surf.sheen, _ox + S.sheen.x * _k, _oy + S.geo.board.y * _k, _u, 1);
        gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    }
    if (S.verdictAlpha > 0 && (S.mode == "reveal" || S.mode == "done" || S.mode == "leaving" || S.mode == "gone")) tra__pm(S.surf.verdict, _ox, _oy, _u, S.verdictAlpha);
    // fade in / out
    if (S.fade > 0) {
        var _fa = clamp(S.fade / TRA_FADE, 0, 1), _a0 = draw_get_alpha(), _c0 = draw_get_colour();
        // alpha as "over": on a buyer's surface a translucent veil must not LOWER the surface's alpha
        gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
        draw_set_alpha(_fa); draw_set_colour(c_black);
        draw_rectangle(_ox, _oy, _ox + 816 * _k, _oy + 624 * _k, false);
        draw_set_alpha(_a0); draw_set_colour(_c0);
    }
    gpu_pop_state();
    math_set_epsilon(_eps);
}
