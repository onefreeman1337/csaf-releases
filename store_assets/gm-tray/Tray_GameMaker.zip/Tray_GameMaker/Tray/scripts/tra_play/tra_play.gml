/// tra_play.gml - the play rules: a fresh state with every piece in the box, whether a piece fits, placing, lifting, the
/// solved test, and a hint from the solver that keeps every piece already placed. Pure logic, ported from the original's
/// TrayCore.js (newGame, fits, place, lift, solved, hint).
///
/// Tray - Generated Packing Puzzles in Wood, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function tra_new_game(puzzle)
/// @description A fresh play state: {grid (-1 empty, -2 outside, >= 0 the piece covering it), placed [one per piece:
/// undefined or {x, y, cells, at}], moves, seq, hints, done}. Every piece starts in the box.
function tra_new_game(_p) {
    if (!(tra__is_tray(_p) && variable_struct_exists(_p, "pieces") && is_array(_p.pieces))) return undefined;
    var _g = array_create(array_length(_p.mask), -2);
    for (var _i = 0; _i < array_length(_p.mask); _i++) _g[_i] = (_p.mask[_i] != 0) ? -1 : -2;
    return { grid: _g, placed: array_create(array_length(_p.pieces), undefined), moves: 0, seq: 0, hints: 0, done: false };
}

/// @function tra_fits(puzzle, game, piece, cells, x, y)
/// @description Can the piece, in the orientation `cells` ([[x, y], ...]), go with its top-left at (x, y)? Its own
/// squares count as free, so a piece can be moved onto itself. Pure.
function tra_fits(_p, _game, _pi, _cells, _x, _y) {
    if (!(tra__is_tray(_p) && variable_struct_exists(_p, "pieces") && is_array(_p.pieces)) || !(is_struct(_game) && variable_struct_exists(_game, "grid") && is_array(_game.grid) && variable_struct_exists(_game, "placed") && is_array(_game.placed)) || !is_array(_cells) || !is_numeric(_x) || !is_numeric(_y) || array_length(_game.grid) != array_length(_p.mask)) return false;
    for (var _k = 0; _k < array_length(_cells); _k++) {
        var _cx = _x + _cells[_k][0], _cy = _y + _cells[_k][1];
        if (_cx < 0 || _cy < 0 || _cx >= _p.w || _cy >= _p.h) return false;
        var _v = _game.grid[_cy * _p.w + _cx];
        if (_v != -1 && _v != _pi) return false;
    }
    return true;
}

/// @function tra_lift(puzzle, game, piece)
/// @description Take a piece back out of the tray. Returns false if it was not in the tray.
function tra_lift(_p, _game, _pi) {
    if (!(tra__is_tray(_p) && variable_struct_exists(_p, "pieces") && is_array(_p.pieces)) || !(is_struct(_game) && variable_struct_exists(_game, "grid") && is_array(_game.grid) && variable_struct_exists(_game, "placed") && is_array(_game.placed)) || !is_numeric(_pi)) return false;
    if (_pi < 0 || _pi >= array_length(_game.placed) || is_undefined(_game.placed[_pi])) return false;
    for (var _i = 0; _i < array_length(_game.grid); _i++) if (_game.grid[_i] == _pi) _game.grid[_i] = -1;
    _game.placed[_pi] = undefined;
    return true;
}

/// @function tra_solved(puzzle, game)
/// @description Every tray square covered. Pure.
function tra_solved(_p, _game) {
    if (!is_struct(_game) || !variable_struct_exists(_game, "grid") || !is_array(_game.grid)) return false;
    for (var _i = 0; _i < array_length(_game.grid); _i++) if (_game.grid[_i] == -1) return false;
    return true;
}

/// @function tra_place(puzzle, game, piece, cells, x, y)
/// @description Place (or move) a piece. Returns false, changing nothing, if the game is done, the piece is unknown or it
/// does not fit; otherwise places it, counts the move and sets game.done when the tray is full.
function tra_place(_p, _game, _pi, _cells, _x, _y) {
    if (!(tra__is_tray(_p) && variable_struct_exists(_p, "pieces") && is_array(_p.pieces)) || !(is_struct(_game) && variable_struct_exists(_game, "grid") && is_array(_game.grid) && variable_struct_exists(_game, "placed") && is_array(_game.placed)) || !is_array(_cells) || !is_numeric(_x) || !is_numeric(_y) || array_length(_game.grid) != array_length(_p.mask)) return false;
    if (_game.done || !is_numeric(_pi) || _pi < 0 || _pi >= array_length(_p.pieces) || !tra_fits(_p, _game, _pi, _cells, _x, _y)) return false;
    tra_lift(_p, _game, _pi);
    var _copy = [];
    for (var _k = 0; _k < array_length(_cells); _k++) { _game.grid[(_y + _cells[_k][1]) * _p.w + _x + _cells[_k][0]] = _pi; array_push(_copy, [_cells[_k][0], _cells[_k][1]]); }
    _game.seq++;
    _game.placed[_pi] = { x: _x, y: _y, cells: _copy, at: _game.seq };
    _game.moves++;
    _game.done = tra_solved(_p, _game);
    return true;
}

/// @function tra_hint(puzzle, game)
/// @description A hint: one piece of a solution that keeps every piece already placed ({place: {piece, x, y, cells}}), or,
/// if no solution keeps them, the piece most recently put down, to lift ({lift: piece}), or {none: true} if the search ran
/// out of budget. Synchronous: with pieces fixed the search is small, but it is the original's 300,000-node budget.
function tra_hint(_p, _game) {
    if (!(tra__is_tray(_p) && variable_struct_exists(_p, "pieces") && is_array(_p.pieces)) || !(is_struct(_game) && variable_struct_exists(_game, "grid") && is_array(_game.grid) && variable_struct_exists(_game, "placed") && is_array(_game.placed))) return { none: true };
    var _job = tra_hint_begin(_p, _game);
    while (!tra_hint_step(_job, 1000000000)) { }
    return _job.result;
}

/// @function tra_hint_begin(puzzle, game)
/// @description A resumable tra_hint: the same search spread over frames with tra_hint_step (a hint on a hard tray with
/// the wrong pieces down must EXHAUST the search before it can say which piece to lift - up to the original's 300,000
/// nodes, seconds on the VM). It is the same job tra_hint runs, so the two cannot disagree. Read job.result when a step
/// returns true.
function tra_hint_begin(_p, _game) {
    if (!(tra__is_tray(_p) && variable_struct_exists(_p, "pieces") && is_array(_p.pieces)) || !(is_struct(_game) && variable_struct_exists(_game, "grid") && is_array(_game.grid) && variable_struct_exists(_game, "placed") && is_array(_game.placed))) return { search: undefined, last: -1, done: true, result: { none: true }, steps: 0, worstMs: 0 };
    var _grid = array_create(array_length(_game.grid));
    for (var _i = 0; _i < array_length(_grid); _i++) _grid[_i] = _game.grid[_i];
    var _last = -1, _at = -1;
    for (var _j = 0; _j < array_length(_game.placed); _j++) if (!is_undefined(_game.placed[_j]) && _game.placed[_j].at > _at) { _at = _game.placed[_j].at; _last = _j; }
    return { search: tra_solve_begin(_p.mask, _p.w, _p.h, _p.pieces, { cap: 1, nodeCap: 300000, fixed: _grid, keep: true }), last: _last, done: false, result: undefined, steps: 0, worstMs: 0 };
}

/// @function tra_hint_step(job, max_ms)
/// @description Advance a hint job for about max_ms milliseconds. Returns true when job.result is final: {place: {piece, x,
/// y, cells}}, {lift: piece} or {none: true} (tra_hint). Records the longest step in job.worstMs.
function tra_hint_step(_job, _maxMs) {
    if (!is_struct(_job) || _job.done) return true;
    var _t0 = get_timer();
    _job.steps++;
    var _fin = tra_solve_step(_job.search, 1000000000, is_numeric(_maxMs) ? max(0.001, _maxMs) : 4);
    _job.worstMs = max(_job.worstMs, (get_timer() - _t0) / 1000);
    if (!_fin) return false;
    var _g = tra_solve_result(_job.search);
    if (is_array(_g.first) && array_length(_g.first) > 0) { var _s = _g.first[0]; _job.result = { place: { piece: _s.piece, x: _s.x, y: _s.y, cells: _s.cells } }; }
    else if (!_g.complete) _job.result = { none: true };
    else _job.result = (_job.last >= 0) ? { lift: _job.last } : { none: true };
    _job.done = true;
    return true;
}
