/**
 * world.js — FLOODMARK's valley and its hydrology. No rendering, no DOM, no
 * globals beyond WORLD, so Internal_Ops/test_world.js can run the whole thing
 * in Node and the proofs below are real proofs rather than screenshots.
 *
 * ⭐ THE ONE IDEA THIS FILE EXISTS TO SERVE. In a Township-like the loop is
 *    gated by real time: you wait, or you pay, and neither is a decision. Here
 *    the gate is the river. Silt carried by floodwater is the ONLY source of
 *    field fertility and dry farmland exhausts itself every year, while
 *    reedbeds and clay pits yield nothing at all unless they are under water.
 *    So a perfectly walled town starves and an unwalled one drowns, and the
 *    player's real job is deciding WHO GETS FLOODED. That decision only exists
 *    if the flood is a system rather than a dice roll, which is what this file
 *    is.
 *
 * ⛔ THE FLOOD MUST BE PREDICTABLE OR THE GAME IS A LOTTERY. Given a crest
 *    height, `floodAt()` is pure and deterministic: same valley, same walls,
 *    same crest, same water, every time. Uncertainty enters in exactly ONE
 *    place — the forecast RANGE for next spring — and the player can always
 *    compute the worst case inside that range and build against it. The UI
 *    then draws that worst case for them (game.js `previewCrest`), because a
 *    system the player cannot see is indistinguishable from randomness.
 *
 * ⚠️ WHY WATER SPREADS BY CONNECTIVITY AND NOT BY ELEVATION ALONE. "Every tile
 *    below the crest floods" needs no BFS and is much simpler — and it makes
 *    dykes pointless, because a wall around a low tile would not stop water
 *    that simply appears there. Water here has to REACH a tile from the river
 *    channel, so a ring of dykes genuinely protects the ground inside it, and
 *    a single missing segment genuinely lets the river in. That is the whole
 *    game, and it costs one flood-fill.
 */
'use strict';

var WORLD = (function () {

  var COLS = 15, ROWS = 11, N = COLS * ROWS;
  var MAX_ELEV = 5;       // the valley rim
  var MAX_CREST = 6;      // a crest of 6 overtops even the rim — rare, and it should be

  function idx(c, r) { return r * COLS + c; }
  function colOf(i) { return i % COLS; }
  function rowOf(i) { return (i / COLS) | 0; }
  function inBounds(c, r) { return c >= 0 && r >= 0 && c < COLS && r < ROWS; }

  /* ------------------------------------------------------------------ prng
   * mulberry32 — 32-bit, seedable, and the same sequence in Node and in the
   * browser. Determinism is not a nicety here: a saved game stores its SEED
   * and rebuilds the valley from it, so a generator that drifted between
   * platforms would silently hand a player a different valley on resume.
   */
  function rng(seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /* --------------------------------------------------------------- terrain */

  /**
   * Carve a river from the top edge to the bottom edge as a biased random
   * walk, then set elevation from distance to water.
   *
   * ⚠️ The walk is biased back toward the centre column. Without that bias it
   * regularly pinned itself to an edge for the whole map, which produces a
   * valley with one bank and no interesting routing — measured by generating
   * 500 seeds and counting how many had river tiles in fewer than 4 distinct
   * columns (see test_world.js proof 2, which still asserts it).
   */
  function carveRiver(w, rand) {
    var c = 5 + ((rand() * 5) | 0);          // start somewhere near the middle
    var river = [];
    for (var r = 0; r < ROWS; r++) {
      river.push(idx(c, r));
      if (rand() < 0.42) river.push(idx(Math.min(COLS - 1, c + 1), r));   // a wider reach
      var pull = (7 - c) * 0.09;             // centre-seeking
      var step = rand() + pull;
      if (step < 0.34) c--; else if (step > 0.72) c++;
      c = Math.max(1, Math.min(COLS - 2, c));
    }
    for (var k = 0; k < river.length; k++) w.river[river[k]] = 1;
  }

  /** Chebyshev-ish distance from the nearest river tile, by BFS. */
  function distanceToRiver(w) {
    var dist = new Int16Array(N).fill(-1);
    var q = [];
    for (var i = 0; i < N; i++) if (w.river[i]) { dist[i] = 0; q.push(i); }
    var head = 0;
    while (head < q.length) {
      var t = q[head++], c = colOf(t), r = rowOf(t);
      for (var dc = -1; dc <= 1; dc++) for (var dr = -1; dr <= 1; dr++) {
        if (!dc && !dr) continue;
        var nc = c + dc, nr = r + dr;
        if (!inBounds(nc, nr)) continue;
        var j = idx(nc, nr);
        if (dist[j] === -1) { dist[j] = dist[t] + 1; q.push(j); }
      }
    }
    return dist;
  }

  /**
   * A valley is only interesting if it has all three bands: low ground that
   * floods most years, mid ground that floods sometimes, and high ground that
   * is safe. `newValley` REJECTS and re-seeds until it gets them rather than
   * shipping a flat map, and `valleyProfile` is what both it and the tests
   * measure — the same function, so a test cannot pass against a rule the
   * generator does not actually apply.
   */
  function valleyProfile(w) {
    var band = [0, 0, 0, 0, 0, 0];
    for (var i = 0; i < N; i++) if (!w.river[i]) band[w.elev[i]]++;
    var riverCols = {};
    for (var j = 0; j < N; j++) if (w.river[j]) riverCols[colOf(j)] = 1;
    return {
      band: band,
      low: band[1],                                   // floods at crest 2
      mid: band[2] + band[3],
      high: band[4] + band[5],
      riverTiles: w.river.reduce(function (a, b) { return a + b; }, 0),
      riverCols: Object.keys(riverCols).length,
    };
  }

  function shapeElevation(w, rand) {
    var dist = distanceToRiver(w);
    for (var i = 0; i < N; i++) {
      if (w.river[i]) { w.elev[i] = 0; continue; }
      // a gentle rise away from the channel, plus per-tile roughness, plus a
      // slow lengthwise tilt so the two ends of the valley are not identical
      var tilt = (rowOf(i) / (ROWS - 1)) * 0.9;
      var rough = rand() * 1.5;
      var e = Math.round(dist[i] * 0.85 + rough + tilt - 0.6);
      w.elev[i] = Math.max(1, Math.min(MAX_ELEV, e));
    }
  }

  function blankValley(seed) {
    return {
      seed: seed >>> 0,
      cols: COLS, rows: ROWS,
      river: new Uint8Array(N),
      elev: new Uint8Array(N),
      raise: new Uint8Array(N),     // causeway tiers — permanent ground gain
      wall: new Uint8Array(N),      // dyke tier 0..3
      sluice: new Uint8Array(N),    // 1 = a sluice exists on this dyke
      open: new Uint8Array(N),      // 1 = that sluice is OPEN this year (wall ignored)
      fert: new Uint8Array(N),      // silt-borne fertility 0..cap
      flooded: new Uint8Array(N),   // set by applyFlood
      depth: new Uint8Array(N),
    };
  }

  /**
   * Build a valley that passes `valleyProfile`. Deterministic in `seed`: it
   * retries hashed variations until one qualifies, so the SAME requested seed
   * always yields the same accepted valley.
   *
   * ⛔ THE RETRY MUST NOT WALK `seed + 1`, AND A TEST CAUGHT IT DOING SO. With a
   *    linear walk, a seed rejected on its first attempt produces the SAME
   *    accepted valley as the next seed up — measured: newValley(4242) and
   *    newValley(4243) returned identical terrain, 0 differing tiles of 165.
   *    That is invisible in play and fatal to "a different seed is a different
   *    valley", which is the entire replay proposition. The attempt is now
   *    HASHED into the seed instead, so attempt N of seed S collides with
   *    nothing.
   */
  function newValley(seed) {
    for (var attempt = 0; attempt < 400; attempt++) {
      var s = (Math.imul((seed ^ 0x9E3779B1) >>> 0, 0x85EBCA6B) ^
               Math.imul(attempt + 1, 0xC2B2AE35)) >>> 0;
      var w = blankValley(s);
      var rand = rng(s);
      carveRiver(w, rand);
      shapeElevation(w, rand);
      var p = valleyProfile(w);
      if (p.low >= 14 && p.mid >= 30 && p.high >= 12 && p.riverCols >= 4 && p.riverTiles >= ROWS) {
        w.requestedSeed = seed >>> 0;
        return w;
      }
    }
    throw new Error('newValley: no valley met the profile in 400 attempts from seed ' + seed);
  }

  /* ------------------------------------------------------------- hydrology */

  /** Permanent height of the ground: bedrock plus any causeway built on it. */
  function ground(w, i) { return w.elev[i] + w.raise[i]; }

  /**
   * How high water must rise to enter this tile. A dyke adds its tier — unless
   * a sluice on that dyke is OPEN, which is the player deliberately inviting
   * the river in. That inversion is the point of the whole building: a sluice
   * is not a safety feature, it is an irrigation valve.
   */
  function barrier(w, i) {
    var wall = w.wall[i];
    if (wall && w.sluice[i] && w.open[i]) wall = 0;
    return ground(w, i) + wall;
  }

  /**
   * PURE. Returns { flooded, depth, count } for a crest without touching the
   * valley — this is what the build-phase preview calls, and it is what makes
   * the flood something a player can aim instead of endure.
   */
  function floodAt(w, crest) {
    var flooded = new Uint8Array(N), depth = new Uint8Array(N);
    var q = [], head = 0, count = 0;
    for (var i = 0; i < N; i++) {
      if (!w.river[i]) continue;
      flooded[i] = 1; count++;
      depth[i] = Math.max(1, crest - ground(w, i));
      q.push(i);
    }
    while (head < q.length) {
      var t = q[head++], c = colOf(t), r = rowOf(t);
      for (var k = 0; k < 4; k++) {
        var nc = c + (k === 0 ? -1 : k === 1 ? 1 : 0);
        var nr = r + (k === 2 ? -1 : k === 3 ? 1 : 0);
        if (!inBounds(nc, nr)) continue;
        var j = idx(nc, nr);
        if (flooded[j]) continue;
        if (barrier(w, j) >= crest) continue;          // the wall holds
        flooded[j] = 1; count++;
        depth[j] = crest - ground(w, j);               // > 0, since barrier >= ground
        q.push(j);
      }
    }
    return { flooded: flooded, depth: depth, count: count };
  }

  /** Commit a flood to the valley: writes flooded/depth. Silt is econ's job. */
  function applyFlood(w, crest) {
    var f = floodAt(w, crest);
    w.flooded = f.flooded;
    w.depth = f.depth;
    w.lastCrest = crest;
    return f;
  }

  /* ------------------------------------------------------------- forecast
   * The crest climbs slowly with the years. That is deliberate pacing in both
   * directions at once and it is the nicest thing in the design: a bigger
   * river is a bigger THREAT to the town you have now built, and simultaneously
   * a bigger silt DELIVERY, because depth is what fertility is made of. The
   * late game is not "the same game but harder", it is a richer valley you
   * have to work much harder to hold.
   *
   * ⚠️ CAPPED AT 5, AND THE CAP IS LOAD-BEARING. The first draft rose to 6 by
   *    year 16, and 6 is above the valley rim — measured by test_world proof 8,
   *    which printed "36 -> 165 tiles", i.e. TOTAL inundation of every tile on
   *    the map as a scheduled certainty. A guaranteed unsurvivable year is not
   *    difficulty, it is an expiry date. Base tops out at 5 and only the jitter
   *    can reach 6, so a total flood stays a rare disaster the player can hear
   *    coming in the forecast rather than a date on the calendar.
   */
  function crestBase(year) { return Math.min(5, 2 + Math.floor(year / 5)); }

  /**
   * Next spring's forecast. `spread` is 1 normally (a two-wide range) and 0
   * once the Rivergauge advance is taken — an upgrade that buys INFORMATION
   * rather than a number, which is the kind this genre almost never sells.
   */
  function forecast(year, seed, spread) {
    var rand = rng((seed ^ (year * 0x9E3779B1)) >>> 0);
    var base = crestBase(year);
    var jitter = rand() < 0.28 ? 1 : 0;
    var actual = Math.max(1, Math.min(MAX_CREST, base + jitter));
    var lo = Math.max(1, actual - (spread ? 1 : 0));
    var hi = Math.min(MAX_CREST, actual + (spread ? 1 : 0));
    return { actual: actual, lo: lo, hi: hi };
  }

  /* -------------------------------------------------------------- helpers */

  function neighbours4(i) {
    var c = colOf(i), r = rowOf(i), out = [];
    if (c > 0) out.push(idx(c - 1, r));
    if (c < COLS - 1) out.push(idx(c + 1, r));
    if (r > 0) out.push(idx(c, r - 1));
    if (r < ROWS - 1) out.push(idx(c, r + 1));
    return out;
  }

  /** Serialise only what cannot be recomputed. The valley rebuilds from seed. */
  function pack(w) {
    return {
      seed: w.requestedSeed !== undefined ? w.requestedSeed : w.seed,
      raise: Array.prototype.slice.call(w.raise),
      wall: Array.prototype.slice.call(w.wall),
      sluice: Array.prototype.slice.call(w.sluice),
      open: Array.prototype.slice.call(w.open),
      fert: Array.prototype.slice.call(w.fert),
    };
  }

  function unpack(p) {
    var w = newValley(p.seed);
    var fields = ['raise', 'wall', 'sluice', 'open', 'fert'];
    for (var k = 0; k < fields.length; k++) {
      var name = fields[k], src = p[name];
      if (!src) continue;
      for (var i = 0; i < N && i < src.length; i++) w[name][i] = src[i];
    }
    return w;
  }

  return {
    COLS: COLS, ROWS: ROWS, N: N, MAX_ELEV: MAX_ELEV, MAX_CREST: MAX_CREST,
    idx: idx, colOf: colOf, rowOf: rowOf, inBounds: inBounds, neighbours4: neighbours4,
    rng: rng,
    newValley: newValley, valleyProfile: valleyProfile, distanceToRiver: distanceToRiver,
    ground: ground, barrier: barrier, floodAt: floodAt, applyFlood: applyFlood,
    crestBase: crestBase, forecast: forecast,
    pack: pack, unpack: unpack,
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = WORLD;
