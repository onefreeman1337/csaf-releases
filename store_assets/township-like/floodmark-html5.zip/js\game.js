/**
 * game.js — FLOODMARK. The loop, the board, the input, the screens.
 *
 * ⛔ EVERY PIXEL OF CHROME IS DRAWN INSIDE THE CANVAS. Not one absolutely
 *    positioned HTML element sits over the play area, and that is a rule this
 *    wing paid for in public: §3d records THE LAST FLOCK shipping a
 *    `bottom:0` footer that landed on top of its own console, live, across two
 *    published versions, because itch serves an HTML5 game at the embed size
 *    the listing declares and when that equals the canvas there is NO page
 *    area below the field. No mechanical gate could see it. Here the bug is
 *    impossible by construction.
 *
 * ⭐ THE FORECAST PREVIEW IS THE MOST IMPORTANT THING ON THE SCREEN. The game
 *    asks the player to AIM a flood. A system the player cannot see is
 *    indistinguishable from randomness, so the board draws, live, exactly
 *    where the water will reach at the top of the forecast range — recomputed
 *    from `WORLD.floodAt` itself, never from a separate estimate that could
 *    drift from the real thing.
 *
 * ⭐ UNDO EXISTS BECAUSE THE INCUMBENT SURVEY SAID SO. Measured on the nearest
 *    structural competitor's own comment thread (Six-Sided Streets, 4.6 / 609
 *    ratings): undo and reset are its two most-repeated unmet requests. The
 *    reference game's most-upvoted spending complaints are misclicks. A
 *    builder without undo is picking a fight with its own players.
 */
'use strict';

(function () {

  var cv = document.getElementById('cv');
  var ctx = cv.getContext('2d', { alpha: false });
  var W = WORLD, E = ECON, A = ART;

  var CW = 960, CH = 600;
  var TILE = 48;
  var BX = 10, BY = 58;                       // board origin
  var BW = W.COLS * TILE, BH = W.ROWS * TILE; // 720 x 528
  var PX = BX + BW + 10, PY = BY, PW = CW - PX - 10, PH = BH;

  var SAVE_KEY = 'csaf.floodmark.v1';         // ⚠️ namespaced — never a bare key

  /* ------------------------------------------------------------------ state */
  var G = {
    screen: 'title',        // title | play | rise | report | council | end | help
    town: null, world: null,
    forecast: null,
    tool: null,
    hover: -1,
    undo: [],
    riseAnim: null,
    report: null,
    council: null,
    toast: null, toastT: 0,
    t: 0,
    milling: 0,
    hasSave: false,
    seed: 1,
  };

  function now() { return performance.now() / 1000; }

  /* ------------------------------------------------------------ save/resume
   * ⛔ THE YEAR BOUNDARY IS THE CHECKPOINT AND THERE IS NO OTHER SAVE POINT.
   *    Ledger B4: death returns the player to a meaningful checkpoint with
   *    progress kept — never a full restart. FLOODMARK goes further and has no
   *    death at all (population floors at two), so the save exists to survive
   *    a closed tab, which for a browser game is the real failure mode.
   */
  function save() {
    try {
      var blob = E.pack(G.town, G.world);
      blob.savedAt = Date.now();
      localStorage.setItem(SAVE_KEY, JSON.stringify(blob));
      G.hasSave = true;
    } catch (e) { /* private mode, quota — never fatal, and never silent in dev */ }
  }
  function loadSave() {
    try {
      var raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return null;
      var p = JSON.parse(raw);
      if (!p || p.v !== 1) return null;
      return E.unpack(p);
    } catch (e) { return null; }
  }
  function hasSave() {
    try { return !!localStorage.getItem(SAVE_KEY); } catch (e) { return false; }
  }
  function clearSave() {
    try { localStorage.removeItem(SAVE_KEY); } catch (e) {}
    G.hasSave = false;
  }

  /* ------------------------------------------------------------------ start */
  function newRun(seed) {
    G.seed = seed >>> 0;
    G.world = W.newValley(G.seed);
    G.town = E.seedTown(E.newTown(G.seed), G.world);
    G.undo = [];
    refreshForecast();
    G.screen = 'play';
    save();
    toast('The valley is yours. The river comes in spring.');
  }

  function resume() {
    var s = loadSave();
    if (!s) { newRun(Date.now() & 0x7fffffff); return; }
    G.world = s.world; G.town = s.town; G.seed = s.town.seed;
    G.undo = [];
    refreshForecast();
    G.screen = G.town.done ? 'end' : 'play';
    toast('Year ' + (G.town.year + 1) + '. The valley remembers.');
  }

  function refreshForecast() {
    G.forecast = W.forecast(G.town.year, G.town.seed, E.has(G.town, 'gauge') ? 0 : 1);
  }

  function toast(msg) { G.toast = msg; G.toastT = now(); }

  /* ------------------------------------------------------------- the phases */

  function beginRise() {
    // ⚠️ SNAPSHOT-FREE POINT OF NO RETURN. Undo is a BUILD-phase affordance
    // only; once the river is called the year is committed, or the forecast
    // would be a free lookahead and every decision in the game would evaporate.
    G.undo = [];
    var crest = G.forecast.actual;
    var pre = W.floodAt(G.world, crest);

    // order the reveal by distance from the channel, so the animation shows
    // the water ARRIVING rather than appearing
    var dist = new Int16Array(W.N).fill(-1), q = [], head = 0;
    for (var i = 0; i < W.N; i++) if (G.world.river[i] && pre.flooded[i]) { dist[i] = 0; q.push(i); }
    while (head < q.length) {
      var t = q[head++];
      var nb = W.neighbours4(t);
      for (var k = 0; k < nb.length; k++) {
        if (!pre.flooded[nb[k]] || dist[nb[k]] >= 0) continue;
        dist[nb[k]] = dist[t] + 1; q.push(nb[k]);
      }
    }
    var maxd = 0;
    for (var j = 0; j < W.N; j++) if (dist[j] > maxd) maxd = dist[j];

    G.report = E.resolveRise(G.town, G.world, crest);
    G.riseAnim = { t0: now(), dist: dist, maxd: maxd, dur: 1.5, crest: crest, done: false };
    G.screen = 'rise';
    if (typeof SOUND !== 'undefined') SOUND.rise(crest);
  }

  function finishRise() {
    var h = E.resolveHarvest(G.town, G.world);
    G.report.harvest = h;
    G.milling = h.flour > 0 ? 1 : 0;
    var c = E.resolveCouncil(G.town, G.world);
    G.report.council = c;
    G.screen = 'report';
    if (typeof SOUND !== 'undefined') {
      if (c.starved) SOUND.hunger(); else SOUND.harvest();
    }
  }

  function toCouncil() {
    if (G.town.markStage >= E.MARK_STAGES.length) { G.town.done = true; G.screen = 'end'; save(); return; }
    var offered = E.offerAdvances(G.town);
    if (!offered.length) { afterCouncil(); return; }
    G.council = offered;
    G.screen = 'council';
  }

  function afterCouncil() {
    refreshForecast();
    G.screen = 'play';
    G.undo = [];
    save();
  }

  /* -------------------------------------------------------------- the board */

  function tileAt(mx, my) {
    if (mx < BX || my < BY || mx >= BX + BW || my >= BY + BH) return -1;
    return W.idx(((mx - BX) / TILE) | 0, ((my - BY) / TILE) | 0);
  }

  /** Which plate a tile shows, given everything true about it right now. */
  function plateFor(i, floodedNow) {
    var b = G.town.build[i];
    if (G.world.river[i] || floodedNow) {
      if (b && b.id === 'reedbed') return 'reed';
      return 'water';
    }
    if (b) {
      if (b.id === 'reedbed') return 'reed';
      if (b.id === 'claypit') return 'clay';
      if (b.id === 'field') return G.world.fert[i] > 0 ? 'grain' : 'field';
    }
    if (G.world.fert[i] >= 3) return 'silt';
    if (W.ground(G.world, i) <= 1) return 'silt';
    if (W.ground(G.world, i) >= 4) return 'dry';
    return 'field';
  }

  /** Elevation shading — the player must be able to READ height off the board. */
  function shadeFor(i) {
    var g = W.ground(G.world, i);
    return (g - 2) * 0.055;                    // -0.11 .. +0.22
  }

  function drawBoard() {
    var t = G.t;
    var risen = G.screen === 'rise' ? G.riseAnim : null;
    var previewCrest = G.forecast ? G.forecast.hi : 0;
    var preview = (G.screen === 'play') ? W.floodAt(G.world, previewCrest) : null;

    for (var i = 0; i < W.N; i++) {
      var c = W.colOf(i), r = W.rowOf(i);
      var x = BX + c * TILE, y = BY + r * TILE;

      var floodedNow = false;
      if (risen) {
        var d = risen.dist[i];
        floodedNow = d >= 0 && (now() - risen.t0) / risen.dur * (risen.maxd + 1) >= d;
      } else {
        floodedNow = !!G.world.flooded[i] && G.screen !== 'play';
      }
      if (G.world.river[i]) floodedNow = true;

      // 1. the plate
      ctx.save();
      ctx.beginPath(); ctx.rect(x, y, TILE, TILE); ctx.clip();
      var name = plateFor(i, floodedNow);
      // ⚠️ offset by tile index so neighbouring tiles do not show the same
      // 48px window of a 256px plate — otherwise the board reads as a grid of
      // identical stamps, which is the tiling artefact this wing keeps meeting
      var ox = ((c * 37) % 200), oy = ((r * 53) % 200);
      if (!A.fillPlate(ctx, name, x - ox, y - oy)) {
        ctx.fillStyle = A.PAL.fld[2]; ctx.fillRect(x, y, TILE, TILE);
      }
      // 2. height shading
      var sh = shadeFor(i);
      ctx.fillStyle = sh >= 0 ? A.rgba('#ffffff', sh) : A.rgba('#000000', -sh);
      ctx.fillRect(x, y, TILE, TILE);
      ctx.restore();

      // 3. contour: a line wherever the ground steps up to the north or west
      ctx.strokeStyle = A.rgba('#000000', 0.30);
      ctx.lineWidth = 1;
      if (c > 0 && W.ground(G.world, i - 1) !== W.ground(G.world, i)) {
        ctx.beginPath(); ctx.moveTo(x + 0.5, y); ctx.lineTo(x + 0.5, y + TILE); ctx.stroke();
      }
      if (r > 0 && W.ground(G.world, i - W.COLS) !== W.ground(G.world, i)) {
        ctx.beginPath(); ctx.moveTo(x, y + 0.5); ctx.lineTo(x + TILE, y + 0.5); ctx.stroke();
      }
    }

    // 4. forecast preview — the single most important overlay in the game
    if (preview) {
      ctx.save();
      for (var p = 0; p < W.N; p++) {
        if (!preview.flooded[p] || G.world.river[p]) continue;
        var pc = W.colOf(p), pr = W.rowOf(p);
        var px2 = BX + pc * TILE, py2 = BY + pr * TILE;
        var pulse = 0.10 + 0.05 * Math.sin(t * 2.0 + pc * 0.4 + pr * 0.3);
        ctx.fillStyle = A.rgba(A.PAL.wat[4], pulse);
        ctx.fillRect(px2, py2, TILE, TILE);
        // hatch the boundary so the EDGE of the forecast is unmistakable
        var nb = W.neighbours4(p);
        ctx.strokeStyle = A.rgba(A.PAL.wat[5], 0.55); ctx.lineWidth = 2;
        for (var n = 0; n < nb.length; n++) {
          if (preview.flooded[nb[n]]) continue;
          var dc = W.colOf(nb[n]) - pc, dr = W.rowOf(nb[n]) - pr;
          ctx.beginPath();
          if (dc === 1) { ctx.moveTo(px2 + TILE - 1, py2); ctx.lineTo(px2 + TILE - 1, py2 + TILE); }
          else if (dc === -1) { ctx.moveTo(px2 + 1, py2); ctx.lineTo(px2 + 1, py2 + TILE); }
          else if (dr === 1) { ctx.moveTo(px2, py2 + TILE - 1); ctx.lineTo(px2 + TILE, py2 + TILE - 1); }
          else { ctx.moveTo(px2, py2 + 1); ctx.lineTo(px2 + TILE, py2 + 1); }
          ctx.stroke();
        }
      }
      ctx.restore();
    }

    // 5. earthworks, then buildings, then life — back to front
    for (var e = 0; e < W.N; e++) {
      var ec = W.colOf(e), er = W.rowOf(e);
      var ex = BX + ec * TILE, ey = BY + er * TILE;
      if (G.world.raise[e]) A.drawCauseway(ctx, ex, ey, TILE, G.world.raise[e]);
      if (G.world.wall[e]) A.drawDyke(ctx, ex, ey, TILE, G.world.wall[e], !!G.world.sluice[e], !!G.world.open[e]);
    }

    for (var k in G.town.build) {
      var ti = +k, b = G.town.build[k];
      var tc = W.colOf(ti), tr = W.rowOf(ti);
      var tx = BX + tc * TILE, ty = BY + tr * TILE;
      var wet = !!G.world.flooded[ti];
      var silt = !!b.silted;
      if (b.id === 'field') A.drawFieldMark(ctx, tx, ty, TILE, G.world.fert[ti], E.fertCap(G.town));
      else if (b.id === 'reedbed') A.drawReeds(ctx, tx, ty, TILE, wet);
      else if (b.id === 'claypit') A.drawClayPit(ctx, tx, ty, TILE, wet);
      else if (b.id === 'house') A.drawHouse(ctx, tx, ty, TILE, silt);
      else if (b.id === 'granary') A.drawGranary(ctx, tx, ty, TILE, silt);
      else if (b.id === 'mill') A.drawMill(ctx, tx, ty, TILE, silt, G.milling ? t * 1.4 : 0);
      else if (b.id === 'bakery') A.drawWorkshop(ctx, tx, ty, TILE, 'bakery', silt, silt ? undefined : (t * 0.35) % 1);
      else if (b.id === 'kiln') A.drawWorkshop(ctx, tx, ty, TILE, 'kiln', silt, silt ? undefined : (t * 0.28) % 1);
      else if (b.id === 'mark') A.drawMark(ctx, tx, ty, TILE, G.town.markStage, silt);
    }

    // 6. the living valley
    for (var L = 0; L < W.N; L++) {
      var lc = W.colOf(L), lr = W.rowOf(L);
      var lx = BX + lc * TILE, ly = BY + lr * TILE;
      var isWater = G.world.river[L] || (G.world.flooded[L] && G.screen !== 'play');
      if (isWater && A.h1(L, 21) > 0.86) A.drawHeron(ctx, lx, ly, TILE, t + L);
      else if (G.world.river[L] && A.h1(L, 31) > 0.72) A.drawDuck(ctx, lx, ly, TILE, t, L);
      var bb = G.town.build[L];
      if (bb && bb.id === 'house' && !bb.silted && A.h1(L, 41) > 0.35) A.drawFolk(ctx, lx, ly, TILE, t, L);
    }

    // 7. hover + placement legality
    if (G.screen === 'play' && G.hover >= 0) {
      var hc = W.colOf(G.hover), hr = W.rowOf(G.hover);
      var hx = BX + hc * TILE, hy = BY + hr * TILE;
      var okp = G.tool ? E.canPlace(G.town, G.world, G.tool, G.hover) : true;
      ctx.strokeStyle = G.tool ? (okp ? A.GOLD : A.BLOOD) : A.PAPER;
      ctx.lineWidth = 2;
      ctx.strokeRect(hx + 1, hy + 1, TILE - 2, TILE - 2);
      if (G.tool && okp) {
        ctx.fillStyle = A.rgba(A.GOLD, 0.14);
        ctx.fillRect(hx, hy, TILE, TILE);
      }
    }

    // board frame
    ctx.strokeStyle = A.rgba('#000000', 0.7); ctx.lineWidth = 2;
    ctx.strokeRect(BX - 1, BY - 1, BW + 2, BH + 2);
  }

  /* ---------------------------------------------------------------- the bar */

  var RES = [
    { k: 'grain', label: 'Grain' }, { k: 'flour', label: 'Flour' }, { k: 'bread', label: 'Bread' },
    { k: 'reed', label: 'Reed' }, { k: 'clay', label: 'Clay' }, { k: 'brick', label: 'Brick' },
  ];

  function drawBar() {
    ctx.fillStyle = '#14110c';
    ctx.fillRect(0, 0, CW, BY - 4);
    ctx.fillStyle = A.rgba(A.GOLD, 0.18);
    ctx.fillRect(0, BY - 5, CW, 1);

    /* ⛔ THE FIRST LAYOUT COLLIDED AND ONLY A SCREENSHOT SHOWED IT. "FLOODMARK"
     * at 19px is ~150px wide and the resource block started at x=132, so the
     * title ran straight through the word "Grain" — invisible to every check
     * in this repo and instantly obvious in the capture. §2b rule 3: look at
     * rendered output before shipping. Every x below is now derived from a
     * measured start rather than guessed. */
    A.text(ctx, 'FLOODMARK', 14, 24, 18, A.GOLD);
    A.text(ctx, 'Year ' + (G.town.year + 1), 14, 44, 13, A.PAPER_DIM);

    var x = 192;
    for (var i = 0; i < RES.length; i++) {
      var r = RES[i], v = G.town.store[r.k] || 0;
      A.text(ctx, r.label, x, 20, 11, A.PAPER_DIM);
      A.text(ctx, String(v), x, 40, 17, v === 0 ? A.PAPER_DIM : A.PAPER);
      x += 56;
    }

    // the barn gauge — deliberately prominent, because storage is the second
    // tension and the reference research says this exact readout is where the
    // genre's best and worst moments both live
    var held = E.stored(G.town), cap = E.storeCap(G.town);
    var gx = 534, gw = 108;
    var frac = Math.min(1, held / cap);
    var hot = frac > 0.92 ? A.BLOOD : frac > 0.75 ? '#c08a2e' : A.PAL.grn[3];
    A.text(ctx, 'Store  ' + held + ' / ' + cap, gx, 20, 11, frac > 0.92 ? A.BLOOD : A.PAPER_DIM);
    ctx.fillStyle = '#241d15'; ctx.fillRect(gx, 27, gw, 13);
    ctx.fillStyle = hot;
    ctx.fillRect(gx, 27, gw * frac, 13);
    ctx.strokeStyle = A.rgba(A.PAPER, 0.35); ctx.lineWidth = 1;
    ctx.strokeRect(gx + 0.5, 27.5, gw - 1, 12);

    A.text(ctx, 'People', 668, 20, 11, A.PAPER_DIM);
    A.text(ctx, G.town.pop + ' / ' + E.popCap(G.town), 668, 40, 17, A.PAPER);
    A.text(ctx, 'Hands', 754, 20, 11, A.PAPER_DIM);
    A.text(ctx, String(G.town.labour), 754, 40, 17, G.town.labour ? A.GOLD : A.PAPER_DIM);

    // the forecast, which is the whole game
    var f = G.forecast;
    A.text(ctx, 'Spring crest', 832, 20, 11, A.PAPER_DIM);
    var fs = f ? (f.lo === f.hi ? String(f.lo) : f.lo + '–' + f.hi) : '?';
    A.text(ctx, fs, 832, 40, 17, A.SKY);
  }

  /* -------------------------------------------------------------- the panel */

  var panelHit = [];

  function drawPanel() {
    panelHit = [];
    ctx.fillStyle = '#14110c';
    ctx.fillRect(PX, PY, PW, PH);
    ctx.strokeStyle = A.rgba(A.GOLD, 0.22); ctx.lineWidth = 1;
    ctx.strokeRect(PX + 0.5, PY + 0.5, PW - 1, PH - 1);

    /* ⛔ THE PANEL OVERFLOWED ITS OWN BOX, AND ONLY A SCREENSHOT SHOWED IT.
     * Twelve build rows at 34px plus a Floodmark block plus a seal grid came
     * to more than the 528px the panel has, so the "THE FLOODMARK" heading
     * printed straight through "COUNCIL" and the seals ran under the CALL THE
     * RIVER button. Nothing mechanical can see that — canvas text does not
     * reflow or clip, it just draws on top of whatever is there. The section
     * heights below are now BUDGETED against PH and the seal row is capped,
     * so the panel cannot overrun however long the deck gets. */
    var ROW_H = 26;
    var BTN_H = 44, UNDO_H = 22;
    var footTop = PY + PH - 12 - BTN_H - 6 - UNDO_H;   // everything must end above this

    var y = PY + 22;
    A.text(ctx, 'BUILD', PX + 12, y, 13, A.GOLD); y += 8;

    for (var i = 0; i < E.ORDER.length; i++) {
      var id = E.ORDER[i], b = E.B[id];
      var c = E.costOf(G.town, G.world, id, G.hover >= 0 ? G.hover : 0);
      var rowH = ROW_H;
      var sel = G.tool === id;
      var affordable = c && G.town.labour >= c.lab && Object.keys(c.cost).every(function (k) {
        return (G.town.store[k] || 0) >= c.cost[k];
      });

      ctx.fillStyle = sel ? A.rgba(A.GOLD, 0.20) : A.rgba('#ffffff', 0.03);
      ctx.fillRect(PX + 8, y, PW - 16, rowH - 3);
      if (sel) { ctx.strokeStyle = A.GOLD; ctx.lineWidth = 1; ctx.strokeRect(PX + 8.5, y + 0.5, PW - 17, rowH - 4); }

      A.text(ctx, b.name, PX + 15, y + 12, 12.5, affordable ? A.PAPER : A.PAPER_DIM);
      var costStr = c ? (c.lab + 'h' + Object.keys(c.cost).map(function (k) { return '  ' + c.cost[k] + ' ' + k; }).join('')) : '—';
      A.text(ctx, costStr, PX + 15, y + 22, 10.5, affordable ? A.PAPER_DIM : A.BLOOD);

      panelHit.push({ x: PX + 8, y: y, w: PW - 16, h: rowH - 3, id: id });
      y += rowH;
    }

    y += 8;
    // the Floodmark's progress, always visible: the goal must never be off-screen
    A.text(ctx, 'THE FLOODMARK', PX + 12, y + 8, 12, A.GOLD);
    for (var s = 0; s < E.MARK_STAGES.length; s++) {
      var bx = PX + 12 + s * 30;
      ctx.fillStyle = s < G.town.markStage ? A.GOLD : A.rgba(A.PAPER, 0.14);
      ctx.fillRect(bx, y + 15, 24, 9);
      ctx.strokeStyle = A.rgba(A.PAPER, 0.3); ctx.lineWidth = 1;
      ctx.strokeRect(bx + 0.5, y + 15.5, 23, 8);
    }
    y += 36;
    if (G.town.markStage < E.MARK_STAGES.length) {
      var ms = E.MARK_STAGES[G.town.markStage];
      var brickNeed = E.has(G.town, 'law') ? Math.ceil(ms.brick * 0.8) : ms.brick;
      A.text(ctx, 'Stage ' + (G.town.markStage + 1) + ': ' + brickNeed + ' brick, ' + ms.bread + ' bread',
        PX + 12, y, 11, A.PAPER_DIM);
    } else {
      A.text(ctx, 'Finished. Call the river.', PX + 12, y, 11, A.GOLD);
    }

    /* Advances taken, as SEALS — the run's history, not a list. §3e: the menu
     * screens are where this wing loses Gate 1, and the fix is composing the
     * mark from the game's own renderer at the real data. Capped to ONE row so
     * the panel budget above cannot be blown by a long deck; the full set is
     * the Council screen's business. */
    y += 12;
    if (G.town.advances.length && y + 30 < footTop) {
      A.text(ctx, 'LEARNED', PX + 12, y, 11, A.GOLD);
      var maxSeals = Math.floor((PW - 24) / 29);
      var shown = Math.min(G.town.advances.length, maxSeals);
      for (var a = 0; a < shown; a++) {
        var adv = E.advanceById(G.town.advances[a]);
        if (!adv) continue;
        A.seal(ctx, adv, PX + 26 + a * 29, y + 22, 24, false);
      }
      if (G.town.advances.length > shown) {
        A.text(ctx, '+' + (G.town.advances.length - shown), PX + 26 + shown * 29 - 4, y + 26, 11, A.PAPER_DIM);
      }
    }

    // the action button, pinned to the bottom of the panel
    var bh = BTN_H, by = PY + PH - bh - 12;
    var label = 'CALL THE RIVER';
    ctx.fillStyle = A.rgba(A.PAL.wat[3], 0.85);
    ctx.fillRect(PX + 10, by, PW - 20, bh);
    ctx.strokeStyle = A.PAL.wat[5]; ctx.lineWidth = 2;
    ctx.strokeRect(PX + 10.5, by + 0.5, PW - 21, bh - 1);
    A.text(ctx, label, PX + PW / 2, by + 21, 15, A.PAPER, 'center');
    A.text(ctx, 'crest ' + (G.forecast.lo === G.forecast.hi ? G.forecast.lo : G.forecast.lo + '–' + G.forecast.hi),
      PX + PW / 2, by + 37, 11, A.SKY, 'center');
    panelHit.push({ x: PX + 10, y: by, w: PW - 20, h: bh, id: '@rise' });

    // undo
    var uy = by - 30;
    var canUndo = G.undo.length > 0;
    ctx.fillStyle = A.rgba('#ffffff', canUndo ? 0.08 : 0.03);
    ctx.fillRect(PX + 10, uy, PW - 20, 24);
    A.text(ctx, canUndo ? 'UNDO  (' + G.undo.length + ')' : 'UNDO', PX + PW / 2, uy + 16, 12,
      canUndo ? A.PAPER : A.PAPER_DIM, 'center');
    panelHit.push({ x: PX + 10, y: uy, w: PW - 20, h: 24, id: '@undo' });
  }

  /* ------------------------------------------------------------- the tooltip
   * Drawn INSIDE the canvas, clamped to it, and it explains a refusal rather
   * than just refusing.
   */
  function drawTip() {
    if (G.screen !== 'play' || G.hover < 0) return;
    var i = G.hover;
    var lines = [];
    var b = G.town.build[i];
    var g = W.ground(G.world, i);
    lines.push({ s: G.world.river[i] ? 'The channel' : (b ? E.B[b.id].name : 'Open ground'), c: A.GOLD, sz: 13 });
    lines.push({ s: 'Ground ' + g + (G.world.wall[i] ? '  ·  dyke ' + G.world.wall[i] : '') +
      (G.world.sluice[i] ? (G.world.open[i] ? '  ·  sluice OPEN' : '  ·  sluice shut') : ''), c: A.PAPER_DIM, sz: 11 });
    if (!G.world.river[i]) {
      var pf = W.floodAt(G.world, G.forecast.hi);
      lines.push({
        s: pf.flooded[i] ? ('Floods at crest ' + G.forecast.hi + ', depth ' + pf.depth[i]) : 'Dry at crest ' + G.forecast.hi,
        c: pf.flooded[i] ? A.SKY : A.PAPER_DIM, sz: 11,
      });
      if (b && b.id === 'field') lines.push({ s: 'Fertility ' + G.world.fert[i] + ' / ' + E.fertCap(G.town) + '  →  ' + G.world.fert[i] + ' grain', c: A.PAL.grn[4], sz: 11 });
    }
    if (b && b.silted) lines.push({ s: 'Silted — yields nothing this year', c: A.BLOOD, sz: 11 });
    if (G.tool) {
      var err = E.placementError(G.town, G.world, G.tool, i);
      lines.push({ s: err || ('Place ' + E.B[G.tool].name), c: err ? A.BLOOD : A.GOLD, sz: 11 });
    }

    var wmax = 0;
    for (var L = 0; L < lines.length; L++) wmax = Math.max(wmax, A.measure(ctx, lines[L].s, lines[L].sz));
    var tw = wmax + 20, th = lines.length * 17 + 12;
    var mx = BX + W.colOf(i) * TILE + TILE + 8, my = BY + W.rowOf(i) * TILE;
    if (mx + tw > BX + BW) mx = BX + W.colOf(i) * TILE - tw - 8;
    if (my + th > BY + BH) my = BY + BH - th;
    if (mx < BX) mx = BX + 4;

    ctx.fillStyle = 'rgba(12,14,11,0.93)';
    A.roundRect(ctx, mx, my, tw, th, 4); ctx.fill();
    ctx.strokeStyle = A.rgba(A.GOLD, 0.35); ctx.lineWidth = 1;
    A.roundRect(ctx, mx + 0.5, my + 0.5, tw - 1, th - 1, 4); ctx.stroke();
    for (var m = 0; m < lines.length; m++) A.text(ctx, lines[m].s, mx + 10, my + 18 + m * 17, lines[m].sz, lines[m].c);
  }

  /* ------------------------------------------------------------- the screens */

  function drawTitle() {
    ctx.fillStyle = '#0c0f0c'; ctx.fillRect(0, 0, CW, CH);
    // a band of every plate, so the title screen is made of the game's own art
    for (var i = 0; i < A.PLATE_NAMES.length; i++) {
      var y = 78 + i * 42;
      ctx.save();
      ctx.beginPath(); ctx.rect(0, y, CW, 40); ctx.clip();
      if (!A.fillPlate(ctx, A.PLATE_NAMES[i], -i * 40, y)) { ctx.fillStyle = '#222'; ctx.fillRect(0, y, CW, 40); }
      ctx.fillStyle = A.rgba('#0c0f0c', 0.55); ctx.fillRect(0, y, CW, 40);
      ctx.restore();
    }
    ctx.fillStyle = 'rgba(10,13,11,0.72)'; ctx.fillRect(0, 150, CW, 300);

    A.text(ctx, 'FLOODMARK', CW / 2, 236, 66, A.GOLD, 'center');
    A.text(ctx, 'The flood is not the disaster. The flood is the harvest.', CW / 2, 268, 17, A.PAPER, 'center');
    A.text(ctx, 'Silt is the only fertility your fields will ever get, and the river brings it once a year.',
      CW / 2, 300, 13, A.PAPER_DIM, 'center');
    A.text(ctx, 'Dykes decide who receives it. Wall everything and the town starves.',
      CW / 2, 320, 13, A.PAPER_DIM, 'center');

    var bs = [
      { id: '@resume', label: hasSave() ? 'CONTINUE' : 'CONTINUE (no saved valley)', on: hasSave() },
      { id: '@new', label: 'A NEW VALLEY', on: true },
      { id: '@help', label: 'HOW IT WORKS', on: true },
    ];
    panelHit = [];
    for (var b = 0; b < bs.length; b++) {
      var bx = CW / 2 - 150, by = 352 + b * 44;
      ctx.fillStyle = bs[b].on ? A.rgba(A.PAL.wat[3], 0.8) : A.rgba('#ffffff', 0.04);
      ctx.fillRect(bx, by, 300, 36);
      ctx.strokeStyle = bs[b].on ? A.PAL.wat[5] : A.rgba(A.PAPER, 0.15); ctx.lineWidth = 1;
      ctx.strokeRect(bx + 0.5, by + 0.5, 299, 35);
      A.text(ctx, bs[b].label, CW / 2, by + 24, 15, bs[b].on ? A.PAPER : A.PAPER_DIM, 'center');
      if (bs[b].on) panelHit.push({ x: bx, y: by, w: 300, h: 36, id: bs[b].id });
    }
    A.text(ctx, 'Core Systems Asset Factory  ·  free, and free to keep', CW / 2, 566, 11, A.PAPER_DIM, 'center');
  }

  /* ⛔ THIS SCREEN WAS THE WORST THING IN THE GAME AND TWO SEPARATE CHECKS
   * MISSED IT. It was a nine-row table drawn as unwrapped single lines: four
   * of them ran off the right edge of the canvas mid-word, and three of the
   * gold labels printed straight through their own body text. smoke.js was
   * green, test_world/test_econ/playtest were green, and the density gate was
   * green because a wall of overflowing text is still dense. Only opening the
   * PNG showed it (master §2b rule 3), and Internal_Ops/test_layout.js now
   * measures it every run.
   *
   * The rebuild is not just a wrap. Wing §3e: THE MENU SCREENS ARE WHERE THIS
   * WING LOSES GATE 1, AND THE FIX IS FREE — so the nine rules are now nine
   * cards in two columns, each led by one of the sixteen glyphs the game
   * already generates for Council seals. Every mark on this screen is drawn by
   * the product from the rule it stands for; there is no image behind any of
   * it. Same information, and it now looks like something.
   */
  var HELP_RULES = [
    ['gauge', 'THE YEAR', 'Build, then call the river, then count the harvest, then the Council meets. Four steps, no clocks anywhere.'],
    ['furrow', 'SILT IS FERTILITY', 'A flooded field gains silt and yields that much grain the same year. A field the water misses loses a point every year to exhaustion.'],
    ['weave', 'REED AND CLAY NEED IT', 'A reedbed or clay pit yields NOTHING in a year the river does not reach it. Reed is the fuel for every workshop you own.'],
    ['roof', 'THE TOWN HATES IT', 'Houses, granaries, mills, bakeries and kilns are silted for a year if the river reaches them, and lost entirely in deep water.'],
    ['wall', 'SO AIM IT', 'Dykes hold the water out of a tile. Sluices let it back in on purpose. Causeways raise the ground and cut the depth.'],
    ['cog', 'THE MILL WANTS A NEIGHBOUR', 'A mill only grinds if a tile NEXT to it flooded this year. Close to the water, never in it.'],
    ['store', 'THE BARN BITES', 'Everything shares one store. Anything over the cap at harvest is lost to the river. Granaries are the answer.'],
    ['sheaf', 'NOBODY DIES', 'A starving year costs population and your final rank. It never costs the run, and two families always stay.'],
    ['layers', 'THE FLOODMARK', 'Five stages of stone. Finish it and the run ends with a rank: fewer years, more people, fewer hard winters.'],
  ];

  function drawHelp() {
    ctx.fillStyle = '#0c0f0c'; ctx.fillRect(0, 0, CW, CH);

    /* A faint band of the game's own water plate runs down the gutter, so the
     * page is a place in the valley rather than a black sheet.
     * ⚠️ fillPlate(ctx,name,ox,oy) fills the CURRENT PATH — it does not take a
     * rect. Passing one silently fills whatever path happened to be open. */
    ctx.save();
    ctx.globalAlpha = 0.13;
    ctx.beginPath(); ctx.rect(CW / 2 - 7, 88, 14, CH - 130);
    A.fillPlate(ctx, 'water', 0, 0);
    ctx.restore();

    A.text(ctx, 'HOW IT WORKS', CW / 2, 52, 26, A.GOLD, 'center');
    A.text(ctx, 'Nine rules. The river obeys all of them and so must you.', CW / 2, 74, 12, A.PAPER_DIM, 'center');

    var M = 34, GUT = 26;
    var colW = (CW - M * 2 - GUT) / 2;          // 420 at 960
    var textX = 46;                              // inside the card, past the mark
    var bodyW = colW - textX - 14;
    var rows = Math.ceil(HELP_RULES.length / 2);
    var top = 96, cardH = 78, vGap = 6;

    for (var i = 0; i < HELP_RULES.length; i++) {
      var r = HELP_RULES[i];
      var col = i % 2, row = (i / 2) | 0;
      var x = M + col * (colW + GUT), y = top + row * (cardH + vGap);

      ctx.fillStyle = 'rgba(22,27,23,0.72)';
      A.roundRect(ctx, x, y, colW, cardH, 5); ctx.fill();
      ctx.strokeStyle = A.rgba(A.GOLD, 0.14); ctx.lineWidth = 1;
      A.roundRect(ctx, x + 0.5, y + 0.5, colW - 1, cardH - 1, 5); ctx.stroke();

      // the generated mark — the same glyph functions the Council seals use
      var g = A.GLYPHS[r[0]] || A.GLYPHS.seal;
      ctx.save();
      ctx.translate(x + 26, y + cardH / 2);
      g(ctx, 30, { dark: A.PAL.grn[1], mid: A.PAL.grn[3], light: A.PAL.grn[5] });
      ctx.restore();

      A.text(ctx, r[1], x + textX, y + 24, 13, A.GOLD);
      A.paragraph(ctx, r[2], x + textX, y + 42, 12, A.PAPER, bodyW, 16);
    }

    var by = top + rows * (cardH + vGap) + 16;
    panelHit = [{ x: CW / 2 - 110, y: by, w: 220, h: 32, id: '@back' }];
    ctx.fillStyle = A.rgba(A.PAL.wat[3], 0.85);
    A.roundRect(ctx, CW / 2 - 110, by, 220, 32, 4); ctx.fill();
    A.text(ctx, 'BACK', CW / 2, by + 21, 14, A.PAPER, 'center');
  }

  function drawRise() {
    drawBar(); drawBoard();
    var el = (now() - G.riseAnim.t0) / G.riseAnim.dur;
    ctx.fillStyle = 'rgba(10,13,11,0.78)';
    ctx.fillRect(PX, PY, PW, PH);
    A.text(ctx, 'THE RIVER RISES', PX + PW / 2, PY + 60, 17, A.SKY, 'center');
    A.text(ctx, 'Crest ' + G.riseAnim.crest, PX + PW / 2, PY + 92, 34, A.PAPER, 'center');
    if (el >= 1) {
      A.text(ctx, 'click to see the year', PX + PW / 2, PY + 140, 12, A.PAPER_DIM, 'center');
      panelHit = [{ x: 0, y: 0, w: CW, h: CH, id: '@afterRise' }];
    } else panelHit = [];
  }

  function drawReport() {
    drawBar(); drawBoard();
    var w = 470, h = 400, x = (CW - w) / 2, y = (CH - h) / 2 + 12;
    ctx.fillStyle = 'rgba(11,14,11,0.95)';
    A.roundRect(ctx, x, y, w, h, 6); ctx.fill();
    ctx.strokeStyle = A.rgba(A.GOLD, 0.4); ctx.lineWidth = 1;
    A.roundRect(ctx, x + 0.5, y + 0.5, w - 1, h - 1, 6); ctx.stroke();

    var r = G.report, hv = r.harvest, cn = r.council;
    A.text(ctx, 'YEAR ' + G.town.year, x + w / 2, y + 34, 22, A.GOLD, 'center');
    A.text(ctx, 'The river reached ' + r.floodedTiles + ' tiles at crest ' + r.crest + '.',
      x + w / 2, y + 58, 12, A.SKY, 'center');

    var ly = y + 92;
    function row(label, val, colour) {
      A.text(ctx, label, x + 30, ly, 13, A.PAPER_DIM);
      A.text(ctx, val, x + w - 30, ly, 13, colour || A.PAPER, 'right');
      ly += 24;
    }
    row('Silt laid on', r.siltedTiles + ' tiles', A.PAL.slt[5]);
    row('Reed cut', '+' + r.gained.reed, r.gained.reed ? A.PAL.red[5] : A.PAPER_DIM);
    row('Clay dug', '+' + r.gained.clay, r.gained.clay ? A.PAL.cly[5] : A.PAPER_DIM);
    row('Grain in', '+' + hv.grain, hv.grain ? A.PAL.grn[4] : A.PAPER_DIM);
    row('Bread baked', '+' + hv.bread, hv.bread ? A.PAL.grn[5] : A.BLOOD);
    row('Brick fired', '+' + hv.brick, hv.brick ? A.PAL.brk[5] : A.PAPER_DIM);
    ly += 6;
    if (r.silted.length) row('Silted up', r.silted.length + ' building' + (r.silted.length > 1 ? 's' : ''), A.BLOOD);
    if (r.ruined.length) row('Lost to the river', r.ruined.length + ' building' + (r.ruined.length > 1 ? 's' : ''), A.BLOOD);
    if (hv.idleMills) row('Mills with no water', String(hv.idleMills), A.BLOOD);
    if (Object.keys(hv.overflow).length) {
      var lost = 0;
      for (var k in hv.overflow) lost += hv.overflow[k];
      row('Over the barn, lost', String(lost), A.BLOOD);
    }
    if (Object.keys(r.storeLost).length) {
      var sl = 0;
      for (var k2 in r.storeLost) sl += r.storeLost[k2];
      row('Washed out of the granary', String(sl), A.BLOOD);
    }
    ly += 4;
    row('Eaten', String(cn.ate), A.PAPER);
    if (cn.starved) row('Went hungry', String(cn.starved), A.BLOOD);
    if (cn.left) row('Left the valley', String(cn.left), A.BLOOD);
    if (cn.born) row('Born', '+' + cn.born, A.PAL.grn[4]);

    var by = y + h - 46;
    ctx.fillStyle = A.rgba(A.PAL.wat[3], 0.85);
    ctx.fillRect(x + 30, by, w - 60, 34);
    A.text(ctx, 'THE COUNCIL MEETS', x + w / 2, by + 23, 14, A.PAPER, 'center');
    panelHit = [{ x: x + 30, y: by, w: w - 60, h: 34, id: '@council' }];
  }

  function drawCouncil() {
    drawBar(); drawBoard();
    ctx.fillStyle = 'rgba(9,12,10,0.90)'; ctx.fillRect(0, 0, CW, CH);
    A.text(ctx, 'THE COUNCIL', CW / 2, 92, 30, A.GOLD, 'center');
    A.text(ctx, 'One thing the valley learns this year.', CW / 2, 120, 13, A.PAPER_DIM, 'center');

    panelHit = [];
    var n = G.council.length, cw = 250, gap = 26;
    var total = n * cw + (n - 1) * gap, x0 = (CW - total) / 2;
    for (var i = 0; i < n; i++) {
      var adv = G.council[i];
      var x = x0 + i * (cw + gap), y = 168, h = 288;
      var hot = G.hover === -1000 - i;
      ctx.fillStyle = hot ? A.rgba(A.GOLD, 0.10) : A.rgba('#ffffff', 0.045);
      A.roundRect(ctx, x, y, cw, h, 6); ctx.fill();
      ctx.strokeStyle = hot ? A.GOLD : A.rgba(A.PAPER, 0.22); ctx.lineWidth = hot ? 2 : 1;
      A.roundRect(ctx, x + 0.5, y + 0.5, cw - 1, h - 1, 6); ctx.stroke();

      A.seal(ctx, adv, x + cw / 2, y + 92, 118, false);
      A.text(ctx, adv.name, x + cw / 2, y + 190, 17, A.GOLD, 'center');

      // wrap the description by hand — no DOM text nodes anywhere in this game
      var words = adv.text.split(' '), line = '', ly = y + 218;
      for (var wi = 0; wi < words.length; wi++) {
        var test = line ? line + ' ' + words[wi] : words[wi];
        if (A.measure(ctx, test, 12) > cw - 32 && line) {
          A.text(ctx, line, x + cw / 2, ly, 12, A.PAPER, 'center');
          line = words[wi]; ly += 17;
        } else line = test;
      }
      if (line) A.text(ctx, line, x + cw / 2, ly, 12, A.PAPER, 'center');

      panelHit.push({ x: x, y: y, w: cw, h: h, id: '@take:' + adv.id, hoverId: -1000 - i });
    }
    A.text(ctx, 'Nothing is ever offered twice.', CW / 2, 496, 12, A.PAPER_DIM, 'center');
  }

  function drawEnd() {
    ctx.fillStyle = '#0c0f0c'; ctx.fillRect(0, 0, CW, CH);
    drawBoard();
    ctx.fillStyle = 'rgba(9,12,10,0.88)'; ctx.fillRect(0, 0, CW, CH);
    var sc = E.score(G.town), rk = E.rank(G.town);
    A.text(ctx, 'THE FLOODMARK STANDS', CW / 2, 132, 38, A.GOLD, 'center');
    A.text(ctx, 'Five stages of stone, and a river that will outlast them.', CW / 2, 162, 14, A.PAPER_DIM, 'center');

    A.text(ctx, rk, CW / 2, 288, 120, A.GOLD, 'center');
    A.text(ctx, String(sc) + ' points', CW / 2, 322, 18, A.PAPER, 'center');

    var stats = [
      ['Years', String(G.town.year)],
      ['People', String(G.town.pop)],
      ['Advances', G.town.advances.length + ' of ' + E.ADVANCES.length],
      ['Hard years', String(G.town.hardYears)],
      ['Lost over the barn', String(G.town.lostToOverflow)],
    ];
    var sx = CW / 2 - 250;
    for (var i = 0; i < stats.length; i++) {
      A.text(ctx, stats[i][0], sx, 372 + i * 24, 13, A.PAPER_DIM);
      A.text(ctx, stats[i][1], sx + 500, 372 + i * 24, 13, A.PAPER, 'right');
    }
    panelHit = [{ x: CW / 2 - 150, y: 508, w: 300, h: 38, id: '@new' }];
    ctx.fillStyle = A.rgba(A.PAL.wat[3], 0.85); ctx.fillRect(CW / 2 - 150, 508, 300, 38);
    A.text(ctx, 'ANOTHER VALLEY', CW / 2, 533, 15, A.PAPER, 'center');
  }

  function drawToast() {
    if (!G.toast) return;
    var age = now() - G.toastT;
    if (age > 4.5) { G.toast = null; return; }
    var a = age > 3.5 ? 1 - (age - 3.5) : 1;
    var w = A.measure(ctx, G.toast, 13) + 28;
    var x = BX + (BW - w) / 2, y = BY + BH - 46;
    ctx.globalAlpha = a;
    ctx.fillStyle = 'rgba(10,13,11,0.9)';
    A.roundRect(ctx, x, y, w, 30, 4); ctx.fill();
    ctx.strokeStyle = A.rgba(A.GOLD, 0.35); ctx.lineWidth = 1;
    A.roundRect(ctx, x + 0.5, y + 0.5, w - 1, 29, 4); ctx.stroke();
    A.text(ctx, G.toast, x + w / 2, y + 20, 13, A.PAPER, 'center');
    ctx.globalAlpha = 1;
  }

  /* ------------------------------------------------------------------ input */

  function hit(mx, my) {
    for (var i = panelHit.length - 1; i >= 0; i--) {
      var h = panelHit[i];
      if (mx >= h.x && my >= h.y && mx < h.x + h.w && my < h.y + h.h) return h;
    }
    return null;
  }

  function onMove(mx, my) {
    if (G.screen === 'council') {
      var h = hit(mx, my);
      G.hover = h && h.hoverId !== undefined ? h.hoverId : -1;
      return;
    }
    if (G.screen !== 'play') { G.hover = -1; return; }
    G.hover = tileAt(mx, my);
  }

  function onClick(mx, my) {
    if (typeof SOUND !== 'undefined') SOUND.unlock();
    var h = hit(mx, my);

    if (G.screen === 'title') {
      if (!h) return;
      if (h.id === '@resume') resume();
      else if (h.id === '@new') newRun((Date.now() ^ (Math.floor(mx * 7919) + my)) & 0x7fffffff);
      else if (h.id === '@help') G.screen = 'help';
      return;
    }
    if (G.screen === 'help') { if (h && h.id === '@back') G.screen = 'title'; return; }
    if (G.screen === 'rise') { if (h && h.id === '@afterRise') finishRise(); return; }
    if (G.screen === 'report') { if (h && h.id === '@council') toCouncil(); return; }
    if (G.screen === 'council') {
      if (h && h.id.indexOf('@take:') === 0) {
        if (E.takeAdvance(G.town, h.id.slice(6))) {
          if (typeof SOUND !== 'undefined') SOUND.advance();
          afterCouncil();
        }
      }
      return;
    }
    if (G.screen === 'end') { if (h && h.id === '@new') newRun((Date.now() ^ 0x5bf03635) & 0x7fffffff); return; }

    /* --- play --- */
    if (h) {
      if (h.id === '@rise') { beginRise(); return; }
      if (h.id === '@undo') { doUndo(); return; }
      if (h.id.charAt(0) !== '@') { G.tool = (G.tool === h.id) ? null : h.id; return; }
      return;
    }
    var i = tileAt(mx, my);
    if (i < 0) return;

    // no tool: a click on a sluice toggles it, free and reversible
    if (!G.tool) {
      if (G.world.sluice[i]) {
        E.toggleSluice(G.world, i);
        if (typeof SOUND !== 'undefined') SOUND.click();
        toast(G.world.open[i] ? 'Sluice opened — the river is invited in.' : 'Sluice shut.');
      }
      return;
    }

    var err = E.placementError(G.town, G.world, G.tool, i);
    if (err) { toast(err); if (typeof SOUND !== 'undefined') SOUND.deny(); return; }
    G.undo.push(E.snapshot(G.town, G.world));
    if (G.undo.length > 40) G.undo.shift();
    E.place(G.town, G.world, G.tool, i);
    if (typeof SOUND !== 'undefined') SOUND.place(G.tool);
    if (G.town.labour <= 0) G.tool = null;
    save();
  }

  function doUndo() {
    if (!G.undo.length) return;
    var s = G.undo.pop();
    var back = E.restore(s);
    G.town = back.town; G.world = back.world;
    if (typeof SOUND !== 'undefined') SOUND.click();
    save();
  }

  cv.addEventListener('mousemove', function (ev) {
    var r = cv.getBoundingClientRect();
    onMove((ev.clientX - r.left) * (CW / r.width), (ev.clientY - r.top) * (CH / r.height));
  });
  cv.addEventListener('mouseleave', function () { G.hover = -1; });
  cv.addEventListener('click', function (ev) {
    var r = cv.getBoundingClientRect();
    onClick((ev.clientX - r.left) * (CW / r.width), (ev.clientY - r.top) * (CH / r.height));
  });
  cv.addEventListener('contextmenu', function (ev) { ev.preventDefault(); G.tool = null; });
  window.addEventListener('keydown', function (ev) {
    if (ev.key === 'Escape') { G.tool = null; }
    else if (ev.key === 'z' || ev.key === 'Z') { if (G.screen === 'play') doUndo(); }
    else if (ev.key === 'm' || ev.key === 'M') { if (typeof SOUND !== 'undefined') toast(SOUND.toggleMute() ? 'Muted.' : 'Sound on.'); }
    else if (ev.key === ' ') { if (G.screen === 'play') { ev.preventDefault(); beginRise(); } }
  });

  /* ------------------------------------------------------------------- loop */

  /* ⛔ THE CAPTURE RACE THAT SHIPPED TWO DUPLICATE GALLERY SLOTS. shot_8 (the
   * Council deck) and shot_9 (the nine materials) are composed plates: the
   * harness draws them straight onto the canvas with ctx, then screenshots. But
   * frame() runs on requestAnimationFrame and repaints the whole canvas ~16ms
   * later, so BOTH plates were wiped and both files came back as a third copy
   * of the Council screen. dedupe.js caught it — "8 images -> 3 visually
   * distinct" — but only after a full capture cycle had been spent.
   *
   * A harness cannot fix this from outside; the loop always wins. So the loop
   * yields: freeze() stops it, and it is the ONLY thing that does. */
  var frozen = false;

  function frame() {
    if (frozen) { requestAnimationFrame(frame); return; }
    G.t = now();
    ctx.fillStyle = '#0c0f0c'; ctx.fillRect(0, 0, CW, CH);

    if (G.screen === 'title') drawTitle();
    else if (G.screen === 'help') drawHelp();
    else if (G.screen === 'rise') drawRise();
    else if (G.screen === 'report') drawReport();
    else if (G.screen === 'council') drawCouncil();
    else if (G.screen === 'end') drawEnd();
    else { drawBar(); drawBoard(); drawPanel(); drawTip(); drawToast(); }

    if (typeof SOUND !== 'undefined' && G.town) {
      SOUND.setMood(G.screen === 'rise' ? 1 : 0, G.town.store.bread / Math.max(1, G.town.pop));
    }
    requestAnimationFrame(frame);
  }

  /* ------------------------------------------------------------------ boot */
  G.hasSave = hasSave();
  A.load(function () {
    /* ⚠️ The game starts whether or not every plate decoded. A missing plate
     * degrades to a flat ramp fill rather than a blank screen — but
     * `ART.loaded()` still reports false, so the capture harness refuses to
     * shoot and nobody ships a screenshot of the fallback. */
    frame();
  });

  // exposed ONLY for the capture harness and the playtest page.
  window.FLOODMARK = {
    state: G,
    newRun: newRun,
    artLoaded: function () { return A.loaded(); },
    missingArt: function () { return A.missing(); },
    setScreen: function (s) { G.screen = s; },
    place: function (id, tile) { return E.place(G.town, G.world, id, tile); },
    rise: beginRise, finishRise: finishRise, toCouncil: toCouncil,
    /* freeze(true) parks the render loop so a harness can compose a plate onto
     * the canvas and screenshot it without the next frame erasing it. It is
     * never called by the game itself and nothing in the UI can reach it. */
    freeze: function (v) { frozen = v !== false; return frozen; },
  };
})();
