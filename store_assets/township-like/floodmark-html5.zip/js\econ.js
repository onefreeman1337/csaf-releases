/**
 * econ.js — FLOODMARK's town: buildings, the production chain, population,
 * the Council deck, and the year resolution. No rendering, no DOM.
 *
 * ⭐ THE YEAR RUNS BUILD -> RISE -> HARVEST -> COUNCIL, AND THAT ORDER IS THE
 *    DESIGN. The player builds BEFORE the river comes, knowing only the
 *    forecast range. If the flood resolved first, dykes would be a reaction
 *    rather than a bet, and "aim the flood" would collapse into "clean up after
 *    it". Everything interesting in this game lives in the gap between the
 *    forecast and the crest.
 *
 * ⭐ FLOODING A FIELD IS GOOD. FLOODING A BUILDING IS BAD. That single
 *    asymmetry is the whole spatial puzzle, and it is real hydrology rather
 *    than a designed gotcha: flood-recession agriculture is how the Nile and
 *    the Mekong have been farmed for millennia. Silt lands in spring, the crop
 *    grows in the drained field, and the harvest comes in the same year. So
 *    fields WANT the water, reedbeds and clay pits REQUIRE it, and the mill,
 *    bakery, kiln, houses and granaries all want to be somewhere it cannot
 *    reach. The town wants to be high; the fields want to be low; the labour
 *    to walk between them is what you are actually spending.
 *
 * ⭐ WHY STORAGE IS THE SECOND TENSION AND NOT AN AFTERTHOUGHT — this is the
 *    one thing the reference research changed about the design. Measured on
 *    r/TownshipGame: the "barn is full" popup is the single most hated UI
 *    moment in Township (three separate 200+ point threads), and the single
 *    most loved moment in the entire game is the one immediately after a barn
 *    upgrade, dumping the whole backlog at once. Same mechanic, both poles.
 *    In Township that constraint exists to be sold back to you. Here it is
 *    free, it is central, and it is WELDED TO THE FLOOD: a granary the river
 *    reaches loses what it was holding, so where you keep your surplus is a
 *    hydrology decision like everything else.
 *
 * ⚠️ NOTHING IN THIS FILE READS A CLOCK. There is no timer, no energy, no
 *    check-in. Measured on the reference: real-time gating is the top
 *    complaint by a distance ("dragged out, sometimes for hours"), and idle
 *    pacing is explicitly designed around DECAYING engagement, which is the
 *    opposite of a ten-minute browser session. The finite resource here is
 *    labour-per-year, in the ISLANDERS sense: the run limits itself.
 */
'use strict';

var ECON = (function () {

  var W = (typeof WORLD !== 'undefined') ? WORLD : require('./world.js');

  var FERT_CAP = 6;
  var BASE_STORE = 20;
  var POP_FLOOR = 2;          // the valley is never fully abandoned — see `resolveCouncil`
  var START_POP = 4;

  /* ------------------------------------------------------------- buildings
   * `wet` classifies a building's relationship with the river, and it is the
   * only field that really matters:
   *   'loves'    — flooding is its yield (reedbed, clay pit): dry means NOTHING.
   *   'tolerates'— flooding feeds it (field): silt is fertility, harvest is same-year.
   *   'hates'    — flooding silts it for the year, and drowns it outright deep.
   *   'immune'   — earthworks. Water is what they are for.
   */
  var B = {
    field:    { id: 'field',    name: 'Field',      lab: 1, cost: {},                      wet: 'tolerates', desc: 'Grain, and only as much as the silt allows. Dry years exhaust it.' },
    reedbed:  { id: 'reedbed',  name: 'Reedbed',    lab: 1, cost: {},                      wet: 'loves',     desc: 'Reed: thatch, basketry, and the fuel every workshop burns. Yields NOTHING in a dry year.' },
    claypit:  { id: 'claypit',  name: 'Clay Pit',   lab: 1, cost: { reed: 2 },             wet: 'loves',     desc: 'River clay, dug from the drained bed. Yields NOTHING in a dry year.' },
    granary:  { id: 'granary',  name: 'Granary',    lab: 2, cost: { reed: 4 },             wet: 'hates',     desc: 'Storage for the whole town. If the river reaches it, half of what it held goes with the water.' },
    mill:     { id: 'mill',     name: 'Mill',       lab: 2, cost: { brick: 4 },            wet: 'hates',     desc: 'Grain to flour — but only if the water came CLOSE. Needs a neighbouring tile that flooded this year.' },
    bakery:   { id: 'bakery',   name: 'Bakery',     lab: 2, cost: { brick: 4, reed: 2 },   wet: 'hates',     desc: 'One flour and one reed become three bread, four times a year. Bread is the only thing people eat.' },
    kiln:     { id: 'kiln',     name: 'Kiln',       lab: 2, cost: { clay: 4 },             wet: 'hates',     desc: 'Two clay and one reed become three brick, three times a year. Everything permanent is made of brick.' },
    house:    { id: 'house',    name: 'House',      lab: 2, cost: { reed: 3, brick: 2 },   wet: 'hates',     desc: 'Room for three more. People are labour, and labour is the only thing you truly spend.' },
    dyke:     { id: 'dyke',     name: 'Dyke',       lab: 2, cost: { clay: 2 },             wet: 'immune',    desc: 'Holds the river out of this tile. Raise it again for another height.' },
    causeway: { id: 'causeway', name: 'Causeway',   lab: 2, cost: { clay: 3 },             wet: 'immune',    desc: 'Raises the ground itself. Lowers flood depth before it stops the water entirely.' },
    sluice:   { id: 'sluice',   name: 'Sluice',     lab: 1, cost: { brick: 2 },            wet: 'immune',    desc: 'A gate in a dyke. Open it and you invite the river through on purpose.' },
    mark:     { id: 'mark',     name: 'The Floodmark', lab: 2, cost: { brick: 6, bread: 4 }, wet: 'hates',  desc: 'The stone that outlasts the valley. Five stages, and the run ends when it is finished.' },
  };

  var ORDER = ['field', 'reedbed', 'claypit', 'granary', 'mill', 'bakery', 'kiln', 'house', 'dyke', 'causeway', 'sluice', 'mark'];

  /** Upgrade tiers for the two earthworks. Index 0 is the first build. */
  var DYKE_TIERS     = [{ lab: 2, cost: { clay: 2 } },  { lab: 2, cost: { brick: 3 } }, { lab: 3, cost: { brick: 5 } }];
  var CAUSEWAY_TIERS = [{ lab: 2, cost: { clay: 3 } },  { lab: 3, cost: { brick: 4 } }];

  /** The Floodmark's five stages. This is the run's terminal state. */
  var MARK_STAGES = [
    { brick: 6,  bread: 4  },
    { brick: 10, bread: 8  },
    { brick: 16, bread: 12 },
    { brick: 24, bread: 18 },
    { brick: 34, bread: 26 },
  ];

  /* -------------------------------------------------------------- advances
   * One chosen from three offered at each Council, from a deck of sixteen. A
   * run takes ten or so, so no two runs unlock in the same order — that is the
   * unlock pacing Gate 4 asks for, and it is also the replay reason the
   * nearest incumbent's comment thread keeps asking for.
   *
   * ⭐ `gauge` buys INFORMATION rather than a number, and it is deliberately in
   *    the deck early: an upgrade that makes the world more legible is rare in
   *    this genre and it is the one that most changes how the game is played.
   */
  var ADVANCES = [
    { id: 'gauge',   name: 'Rivergauge',    glyph: 'gauge',  text: 'The forecast becomes exact. No more range, no more hedging.' },
    { id: 'siltbed', name: 'Silt Beds',     glyph: 'layers', text: 'Fields hold fertility up to 9 instead of 6.' },
    { id: 'plough',  name: 'Deep Ploughing',glyph: 'furrow', text: 'A dry field loses fertility only every SECOND year.' },
    { id: 'withy',   name: 'Withy Weaving', glyph: 'weave',  text: 'Every reedbed yields 2 more reed.' },
    { id: 'levee',   name: 'Levee Corps',   glyph: 'wall',   text: 'Dykes and causeways cost one less labour.' },
    { id: 'twin',    name: 'Twin Sluices',  glyph: 'gate',   text: 'A sluice drains its tile after the flood: no silting on a sluice tile.' },
    { id: 'gearing', name: 'Mill Gearing',  glyph: 'cog',    text: 'Each mill grinds 9 grain a year instead of 6.' },
    { id: 'ovens',   name: 'Stone Ovens',   glyph: 'oven',   text: 'Each bakery bakes 6 batches a year instead of 4.' },
    { id: 'works',   name: 'Brickworks',    glyph: 'kiln',   text: 'Each kiln fires 5 batches a year instead of 3.' },
    { id: 'long',    name: 'Longhouses',    glyph: 'roof',   text: 'Every house holds five instead of three.' },
    { id: 'ware',    name: 'Warehousing',   glyph: 'store',  text: 'Every granary holds 22 instead of 14.' },
    { id: 'marl',    name: 'Marl Spreading',glyph: 'spread', text: 'A worked clay pit gives +1 fertility to each neighbouring field.' },
    { id: 'home',    name: 'Harvest Home',  glyph: 'sheaf',  text: 'Two more labour every year, whatever the population.' },
    { id: 'rush',    name: 'Rush Lights',   glyph: 'flame',  text: 'In a shortfall, three reed feed one person in place of bread.' },
    { id: 'law',     name: 'Floodplain Law',glyph: 'seal',   text: 'Every stage of the Floodmark costs a fifth less brick.' },
    { id: 'ferry',   name: 'Ferrymen',      glyph: 'boat',   text: 'A flooded building is silted, never ruined, however deep the water.' },
  ];

  function has(t, id) { return t.advances.indexOf(id) >= 0; }

  /* -------------------------------------------------------------- the town */

  /**
   * ⛔ THE CHAIN RATES ARE NOT TASTE — THEY WERE SET BY THE SOLVER, AND THE
   *    FIRST SET WAS WRONG IN A WAY ONLY THE SOLVER COULD SEE. First pass:
   *    mill 3, bakery 3 batches at 2 bread, kiln 3 batches at 2 brick.
   *    Internal_Ops/playtest.js over 160 valleys x 4 strategies measured
   *    seventeen HARD YEARS out of thirty and a 3% completion rate — a town
   *    that starves almost every year of its life. Two causes, both invisible
   *    by eye: the tiers were mismatched (a field pays ~4 grain into a mill
   *    that could only take 3), and brick arrived so slowly that a 90-brick
   *    monument was a fifteen-year programme before any dyke was paid for.
   *    Rates below are matched tier to tier: one field feeds part of one mill,
   *    one mill feeds most of one bakery, one bakery feeds about a dozen
   *    people. Re-run the solver after touching ANY of them.
   */
  var MILL_RATE = 6, MILL_RATE_UP = 9;
  var BAKE_BATCHES = 4, BAKE_BATCHES_UP = 6, BREAD_PER_BATCH = 3;
  var KILN_BATCHES = 3, KILN_BATCHES_UP = 5, BRICK_PER_BATCH = 3;

  function newTown(seed) {
    var t = {
      seed: seed >>> 0,
      year: 0,
      pop: START_POP,
      labour: 0,
      store: { grain: 6, reed: 8, clay: 6, flour: 2, bread: 10, brick: 0 },
      build: {},              // tileIndex -> { id, silted, tier }
      markStage: 0,
      advances: [],
      offered: [],
      log: [],
      hardYears: 0,
      lostToOverflow: 0,
      siltDelivered: 0,
      done: false,
    };
    t.labour = labourFor(t);
    return t;
  }

  function labourFor(t) { return 2 + Math.floor(t.pop / 2) + (has(t, 'home') ? 2 : 0); }

  /**
   * ⛔ YOU INHERIT A VILLAGE, YOU DO NOT FOUND ONE — AND THE SOLVER IS WHY.
   *    On an empty map the opening was unrecoverable and the numbers were
   *    stark: bread is the only food, the only source of bread is a bakery,
   *    a bakery costs brick, brick needs a kiln, a kiln needs clay, and clay
   *    only comes out of a flooded pit. That is a five-link bootstrap standing
   *    between the player and their first loaf, while four people eat every
   *    single year. Measured: seventeen hard years out of thirty.
   *
   *    Handing the player a working hamlet is also the RIGHT answer rather
   *    than merely the convenient one — it is what the reference does (you
   *    arrive to a farm already running), it puts a legible example of every
   *    tier on the board where a new player can read it, and it means the
   *    first decision of the game is "where does the water go" instead of
   *    "why is everything greyed out".
   *
   * ⚠️ Placement is by MEASURED ground height, not by fixed coordinates: the
   *    valley is procedural, so a hard-coded tile would sit in the river on
   *    some seeds.
   */
  function seedTown(t, w) {
    var land = [];
    for (var i = 0; i < W.N; i++) if (!w.river[i]) land.push(i);
    var high = land.slice().sort(function (a, b) { return W.ground(w, b) - W.ground(w, a); });
    var low = land.slice().sort(function (a, b) { return W.ground(w, a) - W.ground(w, b); });
    var bank = low.filter(function (i) {
      return W.neighbours4(i).some(function (j) { return w.river[j]; });
    });

    function put(id, tile) { if (tile !== undefined && !t.build[tile]) t.build[tile] = { id: id, silted: 0 }; }

    // the town, on the safest ground the valley has
    put('house', high[0]);
    put('granary', high[1]);
    put('bakery', high[2]);
    // the mill wants to be near water without being in it — the first hint
    // that adjacency is load-bearing
    var millSite = land.filter(function (i) {
      return !t.build[i] && W.ground(w, i) >= 2 &&
        W.neighbours4(i).some(function (j) { return W.ground(w, j) <= 1; });
    }).sort(function (a, b) { return W.ground(w, a) - W.ground(w, b); })[0];
    put('mill', millSite !== undefined ? millSite : high[3]);
    // and the working ground, on the floodplain
    put('field', low.filter(function (i) { return !t.build[i]; })[0]);
    put('reedbed', bank.filter(function (i) { return !t.build[i]; })[0]);

    // a field with no silt in it yields nothing, so the inherited one has some
    for (var k in t.build) if (t.build[k].id === 'field') w.fert[+k] = 3;
    return t;
  }

  function storeCap(t) {
    var per = has(t, 'ware') ? 22 : 14;
    var n = 0;
    for (var k in t.build) if (t.build[k].id === 'granary') n++;
    return BASE_STORE + n * per;
  }

  function stored(t) {
    var s = 0;
    for (var k in t.store) s += t.store[k];
    return s;
  }

  function fertCap(t) { return has(t, 'siltbed') ? 9 : FERT_CAP; }

  /* ------------------------------------------------------------- placement */

  function costOf(t, w, id, tile) {
    var b = B[id];
    if (!b) return null;
    var lab = b.lab, cost = {};
    for (var k in b.cost) cost[k] = b.cost[k];

    if (id === 'dyke') {
      var dt = w.wall[tile];
      if (dt >= DYKE_TIERS.length) return null;
      lab = DYKE_TIERS[dt].lab; cost = {};
      for (var k2 in DYKE_TIERS[dt].cost) cost[k2] = DYKE_TIERS[dt].cost[k2];
    } else if (id === 'causeway') {
      var ct = w.raise[tile];
      if (ct >= CAUSEWAY_TIERS.length) return null;
      lab = CAUSEWAY_TIERS[ct].lab; cost = {};
      for (var k3 in CAUSEWAY_TIERS[ct].cost) cost[k3] = CAUSEWAY_TIERS[ct].cost[k3];
    } else if (id === 'mark') {
      var st = MARK_STAGES[t.markStage];
      if (!st) return null;
      cost = { brick: st.brick, bread: st.bread };
      if (has(t, 'law')) cost.brick = Math.ceil(cost.brick * 0.8);
      lab = 2;
    }
    if ((id === 'dyke' || id === 'causeway') && has(t, 'levee')) lab = Math.max(1, lab - 1);
    return { lab: lab, cost: cost };
  }

  /**
   * Why a placement is illegal, as a STRING the UI can show. Returning a reason
   * rather than a boolean is not politeness — a builder whose rules are opaque
   * is a builder the player fights, and the reference's most-upvoted UX
   * complaints are all about being told "no" without being told why.
   */
  function placementError(t, w, id, tile) {
    var b = B[id];
    if (!b) return 'no such building';
    if (w.river[tile]) return 'That is the river channel. Nothing stands in it.';

    var ex = t.build[tile];
    if (id === 'dyke') {
      if (ex) return 'A dyke needs open ground — ' + B[ex.id].name.toLowerCase() + ' is here.';
      if (w.wall[tile] >= DYKE_TIERS.length) return 'This dyke is already at its full height.';
    } else if (id === 'causeway') {
      if (w.raise[tile] >= CAUSEWAY_TIERS.length) return 'The ground here is raised as far as it will go.';
    } else if (id === 'sluice') {
      if (!w.wall[tile]) return 'A sluice is a gate in a dyke. Build the dyke first.';
      if (w.sluice[tile]) return 'This dyke already has a sluice.';
    } else if (id === 'mark') {
      if (t.markStage >= MARK_STAGES.length) return 'The Floodmark is finished.';
      var at = markTile(t);
      if (at >= 0 && at !== tile) return 'The Floodmark is already rising elsewhere in the valley.';
      if (ex && ex.id !== 'mark') return 'Something already stands here.';
    } else {
      if (ex) return 'Something already stands here.';
      if (w.wall[tile]) return 'A dyke runs through this tile.';
    }

    var c = costOf(t, w, id, tile);
    if (!c) return 'Nothing more can be built here.';
    if (t.labour < c.lab) return 'Not enough hands this year (needs ' + c.lab + ', ' + t.labour + ' left).';
    for (var k in c.cost) {
      if ((t.store[k] || 0) < c.cost[k]) {
        return 'Not enough ' + k + ' (needs ' + c.cost[k] + ', have ' + (t.store[k] || 0) + ').';
      }
    }
    return null;
  }

  function canPlace(t, w, id, tile) { return placementError(t, w, id, tile) === null; }

  function markTile(t) {
    for (var k in t.build) if (t.build[k].id === 'mark') return +k;
    return -1;
  }

  /** Commit a placement. Returns null on success, or the reason it failed. */
  function place(t, w, id, tile) {
    var err = placementError(t, w, id, tile);
    if (err) return err;
    var c = costOf(t, w, id, tile);
    t.labour -= c.lab;
    for (var k in c.cost) t.store[k] -= c.cost[k];

    if (id === 'dyke') w.wall[tile]++;
    else if (id === 'causeway') w.raise[tile]++;
    else if (id === 'sluice') { w.sluice[tile] = 1; w.open[tile] = 0; }
    else if (id === 'mark') { t.markStage++; t.build[tile] = { id: 'mark', silted: 0 }; }
    else t.build[tile] = { id: id, silted: 0 };
    return null;
  }

  /** Toggling a sluice is FREE and reversible — it is a decision, not a purchase. */
  function toggleSluice(w, tile) {
    if (!w.sluice[tile]) return false;
    w.open[tile] = w.open[tile] ? 0 : 1;
    return true;
  }

  /* --------------------------------------------------------------- the RISE
   * Everything the flood does, in one place, so the preview and the real thing
   * cannot drift apart: game.js renders `resolveRise` on a CLONE for the
   * forecast preview and on the real town for the event.
   */
  function resolveRise(t, w, crest) {
    var f = W.applyFlood(w, crest);
    var out = {
      crest: crest, floodedTiles: f.count,
      silted: [], ruined: [], gained: { reed: 0, clay: 0 }, siltedTiles: 0, storeLost: {},
      granaryHit: 0,
    };

    /* 1. silt, and the exhaustion of anything the water missed */
    var cap = fertCap(t);
    for (var i = 0; i < W.N; i++) {
      if (w.river[i]) continue;
      if (f.flooded[i]) {
        var add = Math.min(2, f.depth[i]);
        var before = w.fert[i];
        w.fert[i] = Math.min(cap, w.fert[i] + add);
        out.siltedTiles++;
        t.siltDelivered += (w.fert[i] - before);
      } else if (w.fert[i] > 0) {
        // dry ground gives its fertility back to the wind
        var skip = has(t, 'plough') && (t.year % 2 === 1);
        if (!skip) w.fert[i]--;
      }
    }

    /* 2. what the water did to what you built */
    var granCapTotal = 0, granCapDrowned = 0;
    var perGran = has(t, 'ware') ? 22 : 14;
    for (var key in t.build) {
      var tile = +key, b = t.build[key], def = B[b.id];
      if (b.id === 'granary') granCapTotal += perGran;
      b.silted = 0;
      if (!f.flooded[tile]) continue;
      var depth = f.depth[tile];

      if (def.wet === 'loves') {
        var yield_ = 1 + depth + (b.id === 'reedbed' && has(t, 'withy') ? 2 : 0);
        if (b.id === 'reedbed') out.gained.reed += yield_;
        else out.gained.clay += yield_;
        continue;
      }
      if (def.wet === 'tolerates' || def.wet === 'immune') continue;

      // 'hates' — a sluice on the tile drains it if the Twin Sluices advance is in
      if (w.sluice[tile] && has(t, 'twin')) continue;

      if (depth >= 3 && !has(t, 'ferry')) {
        out.ruined.push({ tile: tile, id: b.id, depth: depth });
      } else {
        b.silted = 1;
        out.silted.push({ tile: tile, id: b.id, depth: depth });
        if (b.id === 'granary') { granCapDrowned += perGran; out.granaryHit++; }
      }
    }

    /* 3. ruins are removed and give back half their brick — never nothing,
     *    because a total loss with no residue is the "it feels like a chore"
     *    failure the reference research names verbatim. */
    for (var r = 0; r < out.ruined.length; r++) {
      var rr = out.ruined[r];
      var back = Math.floor(((B[rr.id].cost.brick || 0)) / 2);
      if (back > 0) t.store.brick += back;
      rr.salvage = back;
      if (rr.id === 'granary') { granCapDrowned += perGran; out.granaryHit++; }
      if (rr.id === 'mark') { t.markStage = Math.max(0, t.markStage - 1); }
      delete t.build[rr.tile];
    }

    /* 4. a drowned granary loses half of the share it was holding */
    if (out.granaryHit > 0 && granCapTotal > 0) {
      var frac = 0.5 * (granCapDrowned / (BASE_STORE + granCapTotal));
      for (var g in t.store) {
        var lost = Math.floor(t.store[g] * frac);
        if (lost > 0) { t.store[g] -= lost; out.storeLost[g] = lost; }
      }
    }

    /* 5. the aquatic harvest */
    t.store.reed += out.gained.reed;
    t.store.clay += out.gained.clay;
    return out;
  }

  /* ------------------------------------------------------------- the HARVEST */

  function neighboursFlooded(w, tile) {
    var nb = W.neighbours4(tile);
    for (var i = 0; i < nb.length; i++) if (w.flooded[nb[i]]) return true;
    return false;
  }

  function resolveHarvest(t, w) {
    var out = { grain: 0, flour: 0, bread: 0, brick: 0, idleMills: 0, overflow: {}, marl: 0 };

    /* Marl Spreading resolves BEFORE the fields are read, or the advance would
     * only take effect the following year and read as broken. */
    if (has(t, 'marl')) {
      var cap = fertCap(t);
      for (var key0 in t.build) {
        if (t.build[key0].id !== 'claypit') continue;
        if (!w.flooded[+key0]) continue;
        var nb0 = W.neighbours4(+key0);
        for (var n0 = 0; n0 < nb0.length; n0++) {
          var b0 = t.build[nb0[n0]];
          if (b0 && b0.id === 'field' && w.fert[nb0[n0]] < cap) { w.fert[nb0[n0]]++; out.marl++; }
        }
      }
    }

    for (var key in t.build) {
      var tile = +key, b = t.build[key];
      if (b.id === 'field' && !b.silted) out.grain += w.fert[tile];
    }
    t.store.grain += out.grain;

    var millRate = has(t, 'gearing') ? MILL_RATE_UP : MILL_RATE;
    for (var k2 in t.build) {
      var b2 = t.build[k2];
      if (b2.id !== 'mill' || b2.silted) continue;
      if (!neighboursFlooded(w, +k2)) { out.idleMills++; continue; }
      var g = Math.min(millRate, t.store.grain);
      t.store.grain -= g; t.store.flour += g; out.flour += g;
    }

    var bakeRate = has(t, 'ovens') ? BAKE_BATCHES_UP : BAKE_BATCHES;
    for (var k3 in t.build) {
      var b3 = t.build[k3];
      if (b3.id !== 'bakery' || b3.silted) continue;
      var batches = Math.min(bakeRate, t.store.flour, t.store.reed);
      t.store.flour -= batches; t.store.reed -= batches;
      t.store.bread += batches * BREAD_PER_BATCH; out.bread += batches * BREAD_PER_BATCH;
    }

    var kilnRate = has(t, 'works') ? KILN_BATCHES_UP : KILN_BATCHES;
    for (var k4 in t.build) {
      var b4 = t.build[k4];
      if (b4.id !== 'kiln' || b4.silted) continue;
      var fire = Math.min(kilnRate, Math.floor(t.store.clay / 2), t.store.reed);
      t.store.clay -= fire * 2; t.store.reed -= fire;
      t.store.brick += fire * BRICK_PER_BATCH; out.brick += fire * BRICK_PER_BATCH;
    }

    /* ⭐ THE BARN. Overflow is lost, and it is announced rather than silently
     * trimmed — the constraint only creates the release if the player can feel
     * it biting. Bread and brick are spared LAST, so what you lose is what you
     * had most of, which is also what you were least short of. */
    var capNow = storeCap(t), have = stored(t);
    if (have > capNow) {
      var over = have - capNow;
      var order = ['grain', 'clay', 'reed', 'flour', 'brick', 'bread'];
      for (var o = 0; o < order.length && over > 0; o++) {
        var take = Math.min(over, t.store[order[o]]);
        if (take > 0) { t.store[order[o]] -= take; out.overflow[order[o]] = take; over -= take; t.lostToOverflow += take; }
      }
    }
    return out;
  }

  /* ------------------------------------------------------------- the COUNCIL */

  /**
   * ⛔ NOBODY DIES AND NOTHING IS ERASED. Ledger B4's standing rule for this
   *    wing is that death returns the player to a meaningful checkpoint with
   *    progress kept. FLOODMARK goes further and has no death state at all:
   *    population floors at two — a couple of families always stay — and a
   *    starving year is recorded as a HARD YEAR that caps the final rank. The
   *    cost is real and it is entirely in the score, never in the save.
   */
  function resolveCouncil(t, w) {
    var out = { ate: 0, starved: 0, born: 0, left: 0, rushUsed: 0 };
    var need = t.pop;
    var eat = Math.min(need, t.store.bread);
    t.store.bread -= eat; out.ate = eat;
    var short = need - eat;

    if (short > 0 && has(t, 'rush')) {
      var fed = Math.min(short, Math.floor(t.store.reed / 3));
      t.store.reed -= fed * 3; short -= fed; out.rushUsed = fed;
    }

    if (short > 0) {
      var lost = Math.min(short, t.pop - POP_FLOOR);
      if (lost > 0) { t.pop -= lost; out.left = lost; }
      out.starved = short;
      t.hardYears++;
    } else {
      // ⚠️ ONE a year, not two. At two the population outran the bread supply
      // it was itself supposed to be enabling, and every strategy oscillated
      // between growth and famine — visible in the solver as a high hard-year
      // count next to a healthy final population.
      var cap = popCap(t);
      if (t.pop < cap) { t.pop += 1; out.born = 1; }
    }

    t.year++;
    t.labour = labourFor(t);
    for (var k in t.build) t.build[k].silted = 0;
    return out;
  }

  function popCap(t) {
    var per = has(t, 'long') ? 5 : 3, n = 0;
    for (var k in t.build) if (t.build[k].id === 'house') n++;
    return 4 + n * per;
  }

  /** Three advances offered, drawn deterministically so a reload cannot reroll. */
  function offerAdvances(t) {
    var pool = ADVANCES.filter(function (a) { return t.advances.indexOf(a.id) < 0; });
    var rand = W.rng((t.seed ^ (t.year * 0x85EBCA6B)) >>> 0);
    var out = [];
    while (out.length < 3 && pool.length) out.push(pool.splice((rand() * pool.length) | 0, 1)[0]);
    t.offered = out.map(function (a) { return a.id; });
    return out;
  }

  function takeAdvance(t, id) {
    if (t.offered.indexOf(id) < 0) return false;
    if (t.advances.indexOf(id) >= 0) return false;
    t.advances.push(id);
    t.offered = [];
    t.labour = labourFor(t);
    return true;
  }

  function advanceById(id) {
    for (var i = 0; i < ADVANCES.length; i++) if (ADVANCES[i].id === id) return ADVANCES[i];
    return null;
  }

  /* ----------------------------------------------------------------- score */

  /**
   * ⛔ THE MONUMENT HAS TO DOMINATE THE SCORE, AND THE FIRST WEIGHTING DID NOT.
   *    Measured by the solver: a "greedy" control that never even started the
   *    Floodmark out-scored every considered strategy, because population was
   *    worth 14 a head and the monument only 40 a stage. A score that rewards
   *    ignoring the goal is not a score, it is a second game played by
   *    accident. Stages are now 120 each, so finishing is worth 600 and no
   *    amount of idle population can buy it.
   */
  function score(t) {
    var s = t.markStage * 120
      + Math.max(0, 30 - t.year) * 14
      + t.pop * 6
      + t.advances.length * 8
      - t.hardYears * 25
      - Math.floor(t.lostToOverflow / 6);
    return Math.max(0, s);
  }

  function rank(t) {
    var s = score(t);
    if (s >= 900) return 'S';
    if (s >= 760) return 'A';
    if (s >= 620) return 'B';
    if (s >= 480) return 'C';
    return 'D';
  }

  /* ------------------------------------------------------------ save/resume */

  function pack(t, w) {
    return {
      v: 1, town: {
        seed: t.seed, year: t.year, pop: t.pop, labour: t.labour, store: t.store,
        build: t.build, markStage: t.markStage, advances: t.advances, offered: t.offered,
        hardYears: t.hardYears, lostToOverflow: t.lostToOverflow, siltDelivered: t.siltDelivered,
        done: t.done,
      }, world: W.pack(w),
    };
  }

  function unpack(p) {
    var w = W.unpack(p.world);
    var t = newTown(p.town.seed);
    for (var k in p.town) t[k] = p.town[k];
    if (!t.store) t.store = { grain: 0, reed: 0, clay: 0, flour: 0, bread: 0, brick: 0 };
    if (!t.build) t.build = {};
    if (!t.advances) t.advances = [];
    return { town: t, world: w };
  }

  /** A deep clone, used by the build-phase UNDO and by the flood preview. */
  function snapshot(t, w) { return JSON.parse(JSON.stringify(pack(t, w))); }
  function restore(snap) { return unpack(snap); }

  return {
    B: B, ORDER: ORDER, ADVANCES: ADVANCES, MARK_STAGES: MARK_STAGES,
    DYKE_TIERS: DYKE_TIERS, CAUSEWAY_TIERS: CAUSEWAY_TIERS,
    FERT_CAP: FERT_CAP, BASE_STORE: BASE_STORE, POP_FLOOR: POP_FLOOR,
    newTown: newTown, seedTown: seedTown, has: has, labourFor: labourFor, storeCap: storeCap, stored: stored,
    fertCap: fertCap, popCap: popCap,
    costOf: costOf, placementError: placementError, canPlace: canPlace, place: place,
    toggleSluice: toggleSluice, markTile: markTile,
    resolveRise: resolveRise, resolveHarvest: resolveHarvest, resolveCouncil: resolveCouncil,
    neighboursFlooded: neighboursFlooded,
    offerAdvances: offerAdvances, takeAdvance: takeAdvance, advanceById: advanceById,
    score: score, rank: rank,
    pack: pack, unpack: unpack, snapshot: snapshot, restore: restore,
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = ECON;
