/**
 * sound.js — FLOODMARK's audio. Synthesised live in WebAudio, plus one
 * composed theme rendered offline by our own tool.
 *
 * ⛔ WHY SYNTHESIS AND COMPOSITION, AND NOT A LIBRARY TRACK — this is a licence
 *    argument before it is an aesthetic one. Wing §0-ART: "Music we COMPOSE
 *    programmatically is our own IP. It needs NO AI disclosure tag, cannot be
 *    taken down, costs nothing per track." itch states plainly that
 *    self-contained procedural synthesis is NOT generative AI, which is what
 *    lets this listing declare **Sounds = NO** honestly. Every sample here is
 *    computed from an oscillator or a noise buffer, and the theme comes out of
 *    `Kernel/capture/make_audio.js` from a JSON score we wrote.
 *
 * ⭐ THE RIVER IS THE ROOM TONE AND IT DOES UI WORK. The ambient bed is moving
 *    water whose brightness and level track the actual state of the town: it
 *    swells and opens up as the crest arrives, and it thins to almost nothing
 *    when the bread runs short. A player learns to hear a hungry valley before
 *    they read the number, which is the only kind of sound design worth
 *    writing.
 *
 * ⚠️ Audio may not start before a gesture. Everything is lazy, `unlock()` is
 *    called from the first click, and before that every entry point is a no-op
 *    rather than an exception.
 */
'use strict';

var SOUND = (function () {

  var ctx = null, master = null, ready = false, muted = false;
  var riverGain = null, riverFilt = null, riverSrc = null;
  var mood = 0, plenty = 1;

  function init() {
    if (ctx) return true;
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return false;
    try { ctx = new AC(); } catch (e) { return false; }
    master = ctx.createGain();
    master.gain.value = muted ? 0 : 0.5;
    master.connect(ctx.destination);
    startRiver();
    ready = true;
    return true;
  }

  function unlock() {
    if (!init()) return;
    if (ctx.state === 'suspended') ctx.resume();
    startMusic();
  }

  /* ------------------------------------------------------------------ music
   * "Low Water" — audio/floodmark_theme.ogg, composed in
   * Internal_Ops/theme.json and rendered by Kernel/capture/make_audio.js.
   *
   * ⚠️ An <audio> element rather than a decoded buffer, deliberately: it
   *    streams, so the file does not delay the first frame, and it loops
   *    natively without a scheduler that could drift.
   */
  var music = null;
  function startMusic() {
    if (music) { if (music.paused && !muted) music.play().catch(function () {}); return; }
    try {
      music = new Audio('audio/floodmark_theme.ogg');
      music.loop = true;
      music.volume = muted ? 0 : 0.30;
      music.play().catch(function () { /* autoplay policy — retried next gesture */ });
    } catch (e) { music = null; }
  }

  /* ------------------------------------------------------------- the river
   * Filtered pink-ish noise: a two-second looping buffer through a lowpass,
   * with a slow LFO on the cutoff so it breathes instead of hissing.
   */
  function startRiver() {
    var len = Math.floor(ctx.sampleRate * 2);
    var buf = ctx.createBuffer(1, len, ctx.sampleRate);
    var d = buf.getChannelData(0);
    var b0 = 0, b1 = 0, b2 = 0;
    for (var i = 0; i < len; i++) {
      var white = Math.random() * 2 - 1;
      // a cheap pink filter — white noise alone reads as static, not water
      b0 = 0.99765 * b0 + white * 0.0990460;
      b1 = 0.96300 * b1 + white * 0.2965164;
      b2 = 0.57000 * b2 + white * 1.0526913;
      d[i] = (b0 + b1 + b2 + white * 0.1848) * 0.16;
    }
    // ⚠️ cross-fade the tail into the head so the two-second loop has no click
    var fade = Math.floor(ctx.sampleRate * 0.15);
    for (var f = 0; f < fade; f++) {
      var a = f / fade;
      d[f] = d[f] * a + d[len - fade + f] * (1 - a);
    }
    riverSrc = ctx.createBufferSource();
    riverSrc.buffer = buf; riverSrc.loop = true;
    riverFilt = ctx.createBiquadFilter();
    riverFilt.type = 'lowpass'; riverFilt.frequency.value = 620; riverFilt.Q.value = 0.7;
    riverGain = ctx.createGain(); riverGain.gain.value = 0.16;
    riverSrc.connect(riverFilt); riverFilt.connect(riverGain); riverGain.connect(master);
    riverSrc.start();

    var lfo = ctx.createOscillator(); lfo.frequency.value = 0.07;
    var lfoG = ctx.createGain(); lfoG.gain.value = 130;
    lfo.connect(lfoG); lfoG.connect(riverFilt.frequency); lfo.start();
  }

  function now() { return ctx ? ctx.currentTime : 0; }

  function blip(freq, dur, type, vol, glideTo) {
    if (!ready || muted) return;
    var o = ctx.createOscillator(); o.type = type || 'triangle';
    var t = now();
    o.frequency.setValueAtTime(freq, t);
    if (glideTo) o.frequency.exponentialRampToValueAtTime(glideTo, t + dur);
    var g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol || 0.16, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(master);
    o.start(t); o.stop(t + dur + 0.02);
  }

  function thud(vol, colour) {
    if (!ready || muted) return;
    var n = 0.10;
    var buf = ctx.createBuffer(1, Math.ceil(ctx.sampleRate * n), ctx.sampleRate);
    var d = buf.getChannelData(0);
    for (var i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / d.length, 4);
    var s = ctx.createBufferSource(); s.buffer = buf;
    var f = ctx.createBiquadFilter();
    f.type = 'lowpass'; f.frequency.value = colour || 420;
    var g = ctx.createGain(); g.gain.value = vol || 0.35;
    s.connect(f); f.connect(g); g.connect(master); s.start();
  }

  /* ------------------------------------------------------------------ events */

  function click() { blip(560, 0.05, 'square', 0.07); }
  function deny() { blip(200, 0.13, 'sawtooth', 0.10, 130); }

  /** Placing something sounds like the MATERIAL it is made of. */
  function place(id) {
    if (id === 'dyke' || id === 'causeway' || id === 'mark') { thud(0.40, 320); blip(150, 0.09, 'triangle', 0.10); }
    else if (id === 'field' || id === 'reedbed' || id === 'claypit') { thud(0.26, 800); }
    else { thud(0.30, 520); blip(392, 0.08, 'triangle', 0.10); setTimeout(function () { blip(523, 0.10, 'triangle', 0.09); }, 65); }
  }

  /** The crest arriving — a swell whose size is the crest itself. */
  function rise(crest) {
    if (!ready || muted) return;
    var t = now(), dur = 1.6;
    if (riverGain) {
      riverGain.gain.cancelScheduledValues(t);
      riverGain.gain.setValueAtTime(riverGain.gain.value, t);
      riverGain.gain.linearRampToValueAtTime(0.16 + crest * 0.055, t + dur * 0.7);
      riverGain.gain.linearRampToValueAtTime(0.20, t + dur + 2.4);
    }
    if (riverFilt) {
      riverFilt.frequency.cancelScheduledValues(t);
      riverFilt.frequency.setValueAtTime(riverFilt.frequency.value, t);
      riverFilt.frequency.linearRampToValueAtTime(500 + crest * 320, t + dur * 0.7);
    }
    // a low horn under it, one note per crest step, so you can HEAR how big it is
    for (var i = 0; i < crest; i++) {
      (function (k) {
        setTimeout(function () { blip(87 * Math.pow(2, k / 12), 0.55, 'sawtooth', 0.09); }, k * 130);
      })(i);
    }
  }

  function harvest() {
    blip(392, 0.16, 'triangle', 0.13);
    setTimeout(function () { blip(523, 0.16, 'triangle', 0.12); }, 110);
    setTimeout(function () { blip(659, 0.26, 'triangle', 0.11); }, 220);
  }

  function hunger() {
    blip(311, 0.34, 'sine', 0.13, 233);
    setTimeout(function () { blip(233, 0.5, 'sine', 0.11, 175); }, 240);
  }

  function advance() {
    blip(523, 0.14, 'triangle', 0.12);
    setTimeout(function () { blip(784, 0.14, 'triangle', 0.11); }, 90);
    setTimeout(function () { blip(1047, 0.34, 'triangle', 0.10); }, 190);
  }

  /**
   * `plenty` is bread per head. Below 1 the valley is hungry and the room tone
   * closes down — the sound is a readout, not a bed.
   */
  function setMood(rising, breadPerHead) {
    mood = rising; plenty = breadPerHead;
    if (!ready || !riverGain || rising) return;
    var want = 0.16 * Math.max(0.35, Math.min(1.15, breadPerHead));
    riverGain.gain.value += (want - riverGain.gain.value) * 0.02;
    if (riverFilt) {
      var wf = 420 + Math.max(0, Math.min(1, breadPerHead)) * 420;
      riverFilt.frequency.value += (wf - riverFilt.frequency.value) * 0.02;
    }
  }

  function toggleMute() {
    muted = !muted;
    if (master) master.gain.value = muted ? 0 : 0.5;
    /* the music is an <audio> element OUTSIDE the WebAudio graph, so muting the
     * master gain does not touch it — a mute that silences the effects and
     * leaves the track playing is the kind of half-fix a player notices at once */
    if (music) music.volume = muted ? 0 : 0.30;
    return muted;
  }

  return {
    unlock: unlock, click: click, deny: deny, place: place,
    rise: rise, harvest: harvest, hunger: hunger, advance: advance,
    setMood: setMood, toggleMute: toggleMute,
    muted: function () { return muted; }, isReady: function () { return ready; },
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = SOUND;
