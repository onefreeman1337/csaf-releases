/* CARILLON — art.js
 * Asset loading and every drawing primitive. Nothing in here knows the rules of the game.
 *
 * ⛔ TEXT IS MEASURED, NEVER GUESSED. Wing §3e-1: canvas text does not wrap, does not reflow and
 *    does not clip, and this game ships a system font stack, so the same string is a different
 *    width on every machine. `wrap` and `paragraph` derive layout from ctx.measureText at DRAW
 *    time, and every internal caller goes through the exported API.text so the layout gate can see
 *    it - a helper calling a closure-local text() is invisible to the recorder, which is exactly
 *    how FLOODMARK shipped a paragraph running off the canvas past 133 green assertions.
 */
'use strict';

var CARILLON_ART = (function () {

  var FONT = "'Iowan Old Style', 'Palatino Linotype', Palatino, Georgia, serif";
  var IMAGES = {};
  var loaded = false;

  var SHEETS = null;   // filled from art/sheets.json

  function load(onDone) {
    var need = ['plate_turf', 'plate_road', 'plate_scree', 'plate_stone', 'sheet_bells', 'sheet_figures'];
    var got = 0;
    fetch('art/sheets.json').then(function (r) { return r.json(); }).then(function (j) {
      SHEETS = j;
      need.forEach(function (n) {
        var im = new Image();
        im.onload = function () { got++; if (got === need.length) { loaded = true; onDone(); } };
        im.onerror = function () { got++; if (got === need.length) { loaded = true; onDone(); } };
        im.src = 'art/' + n + '.png';
        IMAGES[n] = im;
      });
    }).catch(function () { loaded = true; onDone(); });
  }

  /** The only honest proof an asset DECODED, which a capture harness must wait on (§3d rule 3). */
  function assetsLoaded() {
    if (!loaded) return false;
    for (var k in IMAGES) if (IMAGES[k].naturalWidth === 0) return false;
    return true;
  }

  var patterns = {};
  function pattern(ctx, name) {
    if (!patterns[name]) {
      if (!IMAGES[name] || IMAGES[name].naturalWidth === 0) return '#243026';
      patterns[name] = ctx.createPattern(IMAGES[name], 'repeat');
    }
    return patterns[name];
  }

  /* --------------------------------------------------------------- text */

  function setFont(ctx, px, weight) {
    ctx.font = (weight ? weight + ' ' : '') + px + 'px ' + FONT;
  }

  var API = {};

  API.text = function (ctx, str, x, y, opts) {
    opts = opts || {};
    setFont(ctx, opts.size || 14, opts.weight);
    ctx.textAlign = opts.align || 'left';
    ctx.textBaseline = opts.baseline || 'alphabetic';
    ctx.fillStyle = opts.fill || '#d8d2c4';
    if (opts.shadow) {
      ctx.fillStyle = 'rgba(0,0,0,0.72)';
      ctx.fillText(str, x + 1, y + 1);
      ctx.fillStyle = opts.fill || '#d8d2c4';
    }
    ctx.fillText(str, x, y);
  };

  /** Split a string to a pixel width using the ACTUAL font on the ACTUAL machine. */
  API.wrap = function (ctx, str, maxW, size, weight) {
    setFont(ctx, size || 14, weight);
    var words = String(str).split(/\s+/);
    var lines = [], cur = '';
    for (var i = 0; i < words.length; i++) {
      var t = cur ? cur + ' ' + words[i] : words[i];
      if (ctx.measureText(t).width > maxW && cur) { lines.push(cur); cur = words[i]; }
      else cur = t;
    }
    if (cur) lines.push(cur);
    return lines;
  };

  /* ⚠️ Routes through API.text on purpose. A helper that called a closure-local text() would be
     invisible to test_layout's recorder, which is the documented way a gate goes green over the
     lines most likely to overflow. */
  API.paragraph = function (ctx, str, x, y, maxW, opts) {
    opts = opts || {};
    var size = opts.size || 14;
    var lines = API.wrap(ctx, str, maxW, size, opts.weight);
    var lh = opts.lineHeight || Math.round(size * 1.45);
    for (var i = 0; i < lines.length; i++) API.text(ctx, lines[i], x, y + i * lh, opts);
    return y + lines.length * lh;
  };

  /* --------------------------------------------------------------- terrain */

  API.drawGround = function (ctx, W, H, road, clearance) {
    ctx.fillStyle = pattern(ctx, 'plate_turf');
    ctx.fillRect(0, 0, W, H);

    /* a scree band along the top ridge, masked with a soft edge so it is a LANDSCAPE and not a
       stripe - the horizon is the only place the eye reads depth on a flat board */
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(0, 0); ctx.lineTo(W, 0); ctx.lineTo(W, 74);
    for (var x = W; x >= 0; x -= 40) ctx.lineTo(x, 58 + Math.sin(x * 0.011) * 16 + Math.sin(x * 0.031) * 7);
    ctx.closePath();
    ctx.clip();
    ctx.fillStyle = pattern(ctx, 'plate_scree');
    ctx.fillRect(0, 0, W, 110);
    ctx.restore();

    /* the road, stroked as one thick path so it has real width and a shoulder */
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(road[0][0], road[0][1]);
    for (var i = 1; i < road.length; i++) ctx.lineTo(road[i][0], road[i][1]);
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    ctx.lineWidth = clearance * 2 + 8;
    ctx.strokeStyle = 'rgba(12,16,13,0.55)';        // the shoulder, in shadow
    ctx.stroke();
    ctx.lineWidth = clearance * 2 - 4;
    ctx.strokeStyle = pattern(ctx, 'plate_road');
    ctx.stroke();
    ctx.restore();
  };

  API.drawGate = function (ctx, gate) {
    ctx.save();
    ctx.translate(gate[0], gate[1]);
    ctx.fillStyle = pattern(ctx, 'plate_stone');
    ctx.fillRect(-8, -46, 16, 92);
    ctx.fillRect(30, -46, 16, 92);
    ctx.fillRect(-8, -52, 54, 12);
    ctx.strokeStyle = 'rgba(0,0,0,0.6)'; ctx.lineWidth = 2;
    ctx.strokeRect(-8, -46, 16, 92); ctx.strokeRect(30, -46, 16, 92); ctx.strokeRect(-8, -52, 54, 12);
    ctx.restore();
  };

  /* --------------------------------------------------------------- bells */

  var METAL_ROW = { bronze: 0, iron: 1, silver: 2, lead: 3 };
  var GLOW = { bronze: '#e0b370', iron: '#868d98', silver: '#dde6f0', lead: '#a495b8' };

  API.metalGlow = function (m) { return GLOW[m] || '#e0b370'; };

  API.drawBell = function (ctx, x, y, metal, ringing, scale) {
    var sh = SHEETS && SHEETS.bells;
    var im = IMAGES.sheet_bells;
    scale = scale || 0.72;
    if (!sh || !im || im.naturalWidth === 0) {
      ctx.fillStyle = GLOW[metal] || '#c08a43';
      ctx.beginPath(); ctx.arc(x, y, 9, 0, Math.PI * 2); ctx.fill();
      return;
    }
    var col = METAL_ROW[metal] || 0;
    var row = ringing ? 1 : 0;
    var w = sh.cw * scale, h = sh.ch * scale;
    ctx.drawImage(im, col * sh.cw, row * sh.ch, sh.cw, sh.ch, Math.round(x - w / 2), Math.round(y - h * 0.78), Math.round(w), Math.round(h));
  };

  var FIG_COL = { walker: 0, runner: 1, shell: 2, damper: 3, warden: 4 };

  API.drawFigure = function (ctx, x, y, kind, frame, scale) {
    var sh = SHEETS && SHEETS.figures;
    var im = IMAGES.sheet_figures;
    scale = scale || 0.85;
    if (!sh || !im || im.naturalWidth === 0) {
      ctx.fillStyle = '#4a4059';
      ctx.beginPath(); ctx.arc(x, y, 6, 0, Math.PI * 2); ctx.fill();
      return;
    }
    var col = FIG_COL[kind] || 0;
    var w = sh.cw * scale, h = sh.ch * scale;
    ctx.drawImage(im, col * sh.cw, (frame ? 1 : 0) * sh.ch, sh.cw, sh.ch, Math.round(x - w / 2), Math.round(y - h * 0.82), Math.round(w), Math.round(h));
  };

  /* --------------------------------------------------------------- the weapon
   * Everything below is the part of the game that is GENERATED rather than drawn: a ring, a chord
   * and a spark are computed from the board every frame and cannot drift from what the simulation
   * is actually doing, because they are handed the simulation's own numbers.
   */

  API.drawRing = function (ctx, x, y, r, metal, life) {
    if (r <= 0.5) return;
    var a = Math.max(0, 1 - life) * 0.5;
    ctx.strokeStyle = GLOW[metal] || '#e0b370';
    ctx.globalAlpha = a * 0.55;
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.stroke();
    ctx.globalAlpha = a;
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.stroke();
    ctx.globalAlpha = 1;
  };

  /** The faint standing line a bonded pair will fire along. THE thing that makes the game plannable. */
  /* ⚠️ The first pass drew these at alpha 0.10 and they were invisible in a capture of the real
     board. The chord IS the game: a player who cannot see where a pair will fire is playing a
     tower defence with no range indicators. Found by looking at a screenshot, not by any check. */
  API.drawChord = function (ctx, pts, strength) {
    if (!pts || pts.length < 2) return;
    ctx.strokeStyle = 'rgba(255,208,128,' + (0.20 + 0.42 * strength) + ')';
    ctx.lineWidth = strength > 0.5 ? 1.6 : 1;
    ctx.beginPath();
    ctx.moveTo(pts[0][0], pts[0][1]);
    for (var i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
    ctx.stroke();
  };

  API.drawSpark = function (ctx, x, y, power, lead) {
    var r = 6 + Math.min(7, power * 0.06);
    var g = ctx.createRadialGradient(x, y, 0, x, y, r);
    if (lead) { g.addColorStop(0, 'rgba(220,235,255,0.95)'); g.addColorStop(0.4, 'rgba(150,180,235,0.55)'); g.addColorStop(1, 'rgba(90,120,190,0)'); }
    else { g.addColorStop(0, 'rgba(255,246,214,0.98)'); g.addColorStop(0.35, 'rgba(255,196,92,0.60)'); g.addColorStop(1, 'rgba(255,150,40,0)'); }
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = lead ? '#eaf2ff' : '#fff6d6';
    ctx.fillRect(Math.round(x) - 1, Math.round(y) - 1, 2, 2);
  };

  /** A bell that is off the beat wears its error, so the player can see WHICH one to tune. */
  API.drawDriftMark = function (ctx, x, y, frac) {
    if (frac < 0.04) return;
    var r = 15;
    ctx.strokeStyle = 'rgba(255,120,90,' + (0.30 + 0.55 * frac) + ')';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(x, y - 26, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * Math.min(1, frac));
    ctx.stroke();
  };

  API.healthBar = function (ctx, x, y, w, frac, warm) {
    ctx.fillStyle = 'rgba(0,0,0,0.62)';
    ctx.fillRect(x - w / 2 - 1, y - 1, w + 2, 5);
    ctx.fillStyle = warm ? '#c9663f' : '#7fa86a';
    ctx.fillRect(x - w / 2, y, Math.max(0, w * frac), 3);
  };

  API.FONT = FONT;
  API.images = IMAGES;
  API.load = load;
  API.assetsLoaded = assetsLoaded;
  return API;
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CARILLON_ART;
