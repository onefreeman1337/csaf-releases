/* CARILLON — save.js
 *
 * The standing design rule for this whole track (ledger B4): DEATH RETURNS THE PLAYER TO A
 * MEANINGFUL CHECKPOINT WITH PROGRESS KEPT, never to a full restart. Here that means two separate
 * things are stored: the FOUNDRY, which survives a breach, and the SIEGE, which does not but is
 * resumed exactly where a closed tab left it.
 */
'use strict';

var CARILLON_SAVE = (function () {
  var KEY = 'carillon.v1';

  function read() {
    try {
      var raw = localStorage.getItem(KEY);
      if (!raw) return null;
      var j = JSON.parse(raw);
      if (!j || typeof j !== 'object') return null;
      return j;
    } catch (e) { return null; }
  }

  function write(obj) {
    try { localStorage.setItem(KEY, JSON.stringify(obj)); return true; }
    catch (e) { return false; }
  }

  function loadFoundry() {
    var j = read();
    return (j && j.foundry) ? { foundry: j.foundry.foundry || {}, bloom: j.foundry.bloom || 0 } : { foundry: {}, bloom: 0 };
  }

  function saveFoundry(save) {
    var j = read() || {};
    j.foundry = { foundry: save.foundry || {}, bloom: save.bloom || 0 };
    return write(j);
  }

  /* The siege snapshot keeps only what cannot be recomputed. Rings are deliberately NOT stored:
     they are a function of the clock and the metronome, so they rebuild themselves within a beat,
     and storing them would be storing a derived value that can go stale (§2b, six times over). */
  function saveSiege(g) {
    var j = read() || {};
    j.siege = {
      t: g.t, wave: g.wave, phase: g.phase === 'wave' ? 'build' : g.phase,
      tithe: g.tithe, resolve: g.resolve, bloomEarned: g.bloomEarned,
      nextBellId: g.nextBellId,
      bells: g.bells.map(function (b) {
        return { x: b.x, y: b.y, metal: b.metal, rope: b.rope, yoke: b.yoke, drift: b.drift, id: b.id };
      })
    };
    return write(j);
  }

  function loadSiege() {
    var j = read();
    return (j && j.siege) ? j.siege : null;
  }

  function clearSiege() {
    var j = read() || {};
    delete j.siege;
    return write(j);
  }

  function wipeAll() {
    try { localStorage.removeItem(KEY); return true; } catch (e) { return false; }
  }

  return {
    loadFoundry: loadFoundry, saveFoundry: saveFoundry,
    saveSiege: saveSiege, loadSiege: loadSiege, clearSiege: clearSiege,
    wipeAll: wipeAll, KEY: KEY
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CARILLON_SAVE;
