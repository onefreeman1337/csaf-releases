/* CARILLON — game.js
 * Input, rendering order, the DOM panel and the save hooks. Every rule lives in sim.js; this file
 * is allowed to know how things LOOK and never what they mean.
 *
 * ⛔ THE THREE DOM-UI FAILURE MODES (wing §3e-4), all of which shipped in another title's first
 *    build and are guarded here:
 *    1. A panel rebuilt every frame EATS CLICKS - a row detached between mousedown and mouseup
 *       lands on nothing. The panel here rebuilds only when its SIGNATURE changes, and never while
 *       the pointer is inside it.
 *    2. `display:flex` on an element using the `hidden` attribute BEATS `[hidden]{display:none}`.
 *       The stylesheet sets `#id[hidden]{display:none}` explicitly and the smoke test reads
 *       getComputedStyle, never el.hidden.
 *    3. `align-items:center` on a scrolling overlay CLIPS BOTH ENDS. Overlays start at flex-start.
 */
'use strict';

(function () {
  var D = window.CARILLON_DATA;
  var S = window.CARILLON_SIM;
  var A = window.CARILLON_ART;
  var SV = window.CARILLON_SAVE;
  var SND = window.CARILLON_SOUND;

  var cv = document.getElementById('cv');
  var ctx = cv.getContext('2d');
  var panel = document.getElementById('panel');
  var overlayTitle = document.getElementById('title');
  var overlayHelp = document.getElementById('help');
  var overlayEnd = document.getElementById('end');

  var g = null;
  var mouse = { x: -999, y: -999, over: false, inPanel: false };
  var placing = null;        // a metal id while the player is siting a bell
  var armed = null;          // an intervention id while the player is picking a target
  var selected = null;       // the bell whose card is open
  var flash = [];            // transient on-board messages
  var lastBeatSeen = -1;
  var running = false;
  var panelSig = '';

  /* ---------------------------------------------------------------- helpers */

  function say(msg, warm) {
    flash.push({ msg: msg, at: performance.now(), warm: !!warm });
    if (flash.length > 4) flash.shift();
  }

  function toCanvas(ev) {
    var r = cv.getBoundingClientRect();
    return { x: (ev.clientX - r.left) * (cv.width / r.width), y: (ev.clientY - r.top) * (cv.height / r.height) };
  }

  function bellAt(x, y, rad) {
    var best = null, bd = (rad || 20) * (rad || 20);
    for (var i = 0; i < g.bells.length; i++) {
      var b = g.bells[i];
      var d = (b.x - x) * (b.x - x) + (b.y - y) * (b.y - y);
      if (d < bd) { bd = d; best = b; }
    }
    return best;
  }

  function unlockedMetals() {
    return D.METAL_ORDER.filter(function (m) { return g.wave >= D.METALS[m].unlockWave; });
  }
  function unlockedInterventions() {
    return Object.keys(D.INTERVENTIONS).filter(function (k) { return g.wave >= D.INTERVENTIONS[k].unlockWave; });
  }

  /* ---------------------------------------------------------------- the panel
   * Rebuilt ONLY on a signature change, and never while the pointer is inside it.
   */
  function panelSignature() {
    return [g.phase, g.wave, g.tithe, g.resolve, g.charges, g.bells.length, g.bonds.length,
      placing, armed, selected ? (selected.id + ':' + selected.rope + ':' + selected.yoke) : '-',
      unlockedMetals().join(''), unlockedInterventions().join('')].join('|');
  }

  function buildPanel() {
    var sig = panelSignature();
    if (sig === panelSig) return;
    if (mouse.inPanel && panel.childElementCount) return;   // never rebuild under the pointer
    panelSig = sig;

    var h = [];
    var w = D.WAVES[Math.min(g.wave, D.WAVES.length - 1)];
    h.push('<div class="row stats">'
      + '<span class="stat"><b>' + (g.phase === 'won' ? 'siege held' : 'wave ' + (g.wave + 1) + '/' + D.WAVES.length) + '</b></span>'
      + '<span class="stat">tithe <b>' + Math.floor(g.tithe) + '</b></span>'
      + '<span class="stat">resolve <b class="' + (g.resolve <= 3 ? 'bad' : '') + '">' + g.resolve + '</b></span>'
      + '<span class="stat">charges <b>' + g.charges + '</b></span>'
      + '<span class="stat dim">' + g.bells.length + ' bells, ' + g.bonds.length + ' chords</span>'
      + '</div>');

    h.push('<div class="row">');
    if (g.phase === 'build') {
      h.push('<button class="go" data-act="start">Ring in wave ' + (g.wave + 1) + '</button>');
    } else if (g.phase === 'wave') {
      h.push('<span class="running">the wave is walking</span>');
    }
    unlockedMetals().forEach(function (m) {
      var M = D.METALS[m];
      var can = g.tithe >= M.cost;
      h.push('<button class="metal ' + m + (placing === m ? ' on' : '') + (can ? '' : ' no') + '" data-act="metal" data-m="' + m + '">'
        + M.name + ' <i>' + M.cost + '</i></button>');
    });
    unlockedInterventions().forEach(function (k) {
      var I = D.INTERVENTIONS[k];
      h.push('<button class="act' + (armed === k ? ' on' : '') + (g.charges > 0 ? '' : ' no') + '" data-act="int" data-i="' + k + '">'
        + I.name + '</button>');
    });
    h.push('<button class="ghost" data-act="help">How it works</button>');
    h.push('<button class="ghost" data-act="sound">Sound: ' + (SND.isEnabled() ? 'on' : 'off') + '</button>');
    h.push('</div>');

    if (selected) {
      var M2 = D.METALS[selected.metal];
      h.push('<div class="row card">');
      h.push('<span class="cardname ' + selected.metal + '">' + M2.name + ' bell</span>');
      h.push('<span class="dim">rings every ' + M2.period + ' beat' + (M2.period > 1 ? 's' : '')
        + ', reach ' + Math.round(S.bellReach(selected, g.save)) + 'px</span>');
      ['rope', 'yoke'].forEach(function (k) {
        var U = D.UPGRADES[k];
        if (selected[k] >= U.max) { h.push('<span class="maxed">' + U.name + ' ' + U.max + '/' + U.max + '</span>'); return; }
        var c = S.upgradeCost(k, selected[k]);
        h.push('<button class="up' + (g.tithe >= c ? '' : ' no') + '" data-act="up" data-k="' + k + '">'
          + U.name + ' ' + selected[k] + '&rarr;' + (selected[k] + 1) + ' <i>' + c + '</i></button>');
      });
      h.push('<button class="ghost" data-act="sell">Take down <i>+' + Math.round(M2.cost * 0.6) + '</i></button>');
      h.push('<button class="ghost" data-act="close">Close</button>');
      h.push('</div>');
    }

    panel.innerHTML = h.join('');
  }

  panel.addEventListener('mouseenter', function () { mouse.inPanel = true; });
  panel.addEventListener('mouseleave', function () { mouse.inPanel = false; });

  panel.addEventListener('click', function (ev) {
    var b = ev.target.closest('button');
    if (!b) return;
    SND.unlock();
    var act = b.getAttribute('data-act');
    if (act === 'start') {
      var r = S.startWave(g);
      if (r.ok) { SND.play('sfx_wave', 0.7); say('wave ' + g.wave + ' walks'); SV.saveSiege(g); }
      else say(r.why, true);
    } else if (act === 'metal') {
      var m = b.getAttribute('data-m');
      placing = (placing === m) ? null : m;
      armed = null; selected = null;
    } else if (act === 'int') {
      var i = b.getAttribute('data-i');
      armed = (armed === i) ? null : i;
      placing = null;
    } else if (act === 'up') {
      var k = b.getAttribute('data-k');
      var ur = S.upgradeBell(g, selected, k);
      if (ur.ok) { SND.play('sfx_hang', 0.6); say(D.UPGRADES[k].name + ' raised'); SV.saveSiege(g); }
      else { SND.play('sfx_deny', 0.5); say(ur.why, true); }
    } else if (act === 'sell') {
      var sr = S.sellBell(g, selected);
      if (sr.ok) { selected = null; SND.play('sfx_hang', 0.5); say('bell taken down, +' + sr.refund); SV.saveSiege(g); }
    } else if (act === 'close') {
      selected = null;
    } else if (act === 'help') {
      showOverlay(overlayHelp);
    } else if (act === 'sound') {
      SND.setEnabled(!SND.isEnabled());
      panelSig = '';
    }
    panelSig = '';
    buildPanel();
  });

  /* ---------------------------------------------------------------- board input */

  cv.addEventListener('mousemove', function (ev) {
    var p = toCanvas(ev);
    mouse.x = p.x; mouse.y = p.y; mouse.over = true;
  });
  cv.addEventListener('mouseleave', function () { mouse.over = false; });

  cv.addEventListener('click', function (ev) {
    SND.unlock();
    var p = toCanvas(ev);

    if (armed) {
      var target = bellAt(p.x, p.y, 26);
      if (!target) { say('pick a bell for ' + D.INTERVENTIONS[armed].name.toLowerCase(), true); return; }
      var r = S.intervene(g, armed, target);
      if (r.ok) {
        SND.play('sfx_' + armed, 0.8);
        say(D.INTERVENTIONS[armed].name + 'ed the ' + D.METALS[target.metal].name.toLowerCase() + ' bell');
        armed = null; SV.saveSiege(g);
      } else { SND.play('sfx_deny', 0.5); say(r.why, true); }
      panelSig = ''; return;
    }

    if (placing) {
      var pr = S.placeBell(g, Math.round(p.x), Math.round(p.y), placing);
      if (pr.ok) {
        SND.play('sfx_hang', 0.8);
        SND.ringBell(placing);
        say(D.METALS[placing].name + ' bell hung');
        if (g.tithe < D.METALS[placing].cost) placing = null;
        SV.saveSiege(g);
      } else { SND.play('sfx_deny', 0.5); say(pr.why, true); }
      panelSig = ''; return;
    }

    var b = bellAt(p.x, p.y, 26);
    selected = (selected === b) ? null : b;
    panelSig = '';
  });

  window.addEventListener('keydown', function (ev) {
    if (ev.key === 'Escape') { placing = null; armed = null; selected = null; hideOverlays(); panelSig = ''; return; }
    var ints = unlockedInterventions();
    for (var i = 0; i < ints.length; i++) {
      if (ev.key === D.INTERVENTIONS[ints[i]].key) { armed = ints[i]; placing = null; panelSig = ''; return; }
    }
    if (ev.key === ' ' && g.phase === 'build') { ev.preventDefault(); S.startWave(g); panelSig = ''; }
  });

  /* ---------------------------------------------------------------- overlays */

  function showOverlay(el) { el.hidden = false; el.scrollTop = 0; }
  function hideOverlays() {
    overlayTitle.hidden = true; overlayHelp.hidden = true; overlayEnd.hidden = true;
  }
  document.querySelectorAll('[data-close]').forEach(function (el) {
    el.addEventListener('click', function () { hideOverlays(); });
  });

  /* ---------------------------------------------------------------- render */

  function render(now) {
    var W = D.W, H = D.H;
    A.drawGround(ctx, W, H, D.ROAD, D.ROAD_CLEARANCE);
    A.drawGate(ctx, D.GATE);

    /* 1. the chords, faint and standing: the thing that makes the board plannable */
    for (var k = 0; k < g.bonds.length; k++) {
      var loci = S.chordLocus(g, g.bonds[k], 22);
      var hot = selected && (g.bells[g.bonds[k].a] === selected || g.bells[g.bonds[k].b] === selected);
      A.drawChord(ctx, loci[0], hot ? 1 : 0);
      A.drawChord(ctx, loci[1], hot ? 1 : 0);
    }

    /* 2. the rings */
    var v = S.ringSpeed(g.save);
    for (var i = 0; i < g.bells.length; i++) {
      var b = g.bells[i];
      var reach = S.bellReach(b, g.save);
      for (var r = 0; r < b.rings.length; r++) {
        var rad = v * (g.t - b.rings[r].t0) / 1000;
        if (rad > 0) A.drawRing(ctx, b.x, b.y, rad, b.metal, rad / reach);
      }
    }

    /* 3. the procession */
    for (var e = 0; e < g.enemies.length; e++) {
      var en = g.enemies[e];
      var def = D.ENEMIES[en.type];
      var frame = Math.floor(g.t / 260) % 2;
      ctx.globalAlpha = en.slowUntil > g.t ? 0.75 : 1;
      A.drawFigure(ctx, en.x, en.y, en.type, frame, def.radius > 9 ? 0.95 : 0.8);
      ctx.globalAlpha = 1;
      if (en.hp < en.maxHp) A.healthBar(ctx, en.x, en.y + 6, 22, en.hp / en.maxHp, def.drift ? true : false);
    }

    /* 4. the sparks, over everything, because they are the only thing that does anything */
    ctx.globalCompositeOperation = 'lighter';
    for (var s = 0; s < g.sparks.length; s++) A.drawSpark(ctx, g.sparks[s].x, g.sparks[s].y, g.sparks[s].power, g.sparks[s].lead);
    ctx.globalCompositeOperation = 'source-over';

    /* 5. the bells */
    for (var j = 0; j < g.bells.length; j++) {
      var bl = g.bells[j];
      var ringing = bl.rings.some(function (rg) { return g.t - rg.t0 < 220; });
      if (selected === bl) {
        ctx.strokeStyle = 'rgba(255,214,140,0.55)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.arc(bl.x, bl.y, S.bellReach(bl, g.save), 0, Math.PI * 2); ctx.stroke();
      }
      A.drawBell(ctx, bl.x, bl.y, bl.metal, ringing);
      A.drawDriftMark(ctx, bl.x, bl.y, Math.abs(bl.drift) / (D.BEAT_MS * 0.5));
    }

    /* 6. the siting ghost */
    if (placing && mouse.over) {
      var okHere = S.canBuildAt(mouse.x, mouse.y, g.bells, 30) && g.tithe >= D.METALS[placing].cost;
      ctx.globalAlpha = 0.55;
      A.drawBell(ctx, mouse.x, mouse.y, placing, false);
      ctx.globalAlpha = 1;
      ctx.strokeStyle = okHere ? 'rgba(160,220,150,0.55)' : 'rgba(230,110,90,0.65)';
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(mouse.x, mouse.y, D.METALS[placing].reach + S.foundryBonus(g.save, 'ear'), 0, Math.PI * 2); ctx.stroke();
      /* preview every chord this placement would create - the actual decision the player is making */
      var probe = { x: mouse.x, y: mouse.y, metal: placing, rope: 0, yoke: 0, drift: 0, rings: [], id: -1 };
      g.bells.push(probe);
      var idx = g.bells.length - 1;
      for (var q = 0; q < idx; q++) {
        var dd = Math.hypot(g.bells[q].x - mouse.x, g.bells[q].y - mouse.y);
        if (dd > 2 * Math.min(S.bellReach(probe, g.save), S.bellReach(g.bells[q], g.save))) continue;
        var pl = S.chordLocus(g, { a: q, b: idx }, 18);
        A.drawChord(ctx, pl[0], 1); A.drawChord(ctx, pl[1], 1);
      }
      g.bells.pop();
    }
    if (armed && mouse.over) {
      var t = bellAt(mouse.x, mouse.y, 26);
      if (t) {
        ctx.strokeStyle = 'rgba(255,214,140,0.8)'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(t.x, t.y - 6, 22, 0, Math.PI * 2); ctx.stroke();
      }
    }

    /* 7. the HUD strip, drawn last */
    ctx.fillStyle = 'rgba(10,13,11,0.62)';
    ctx.fillRect(0, 0, W, 26);
    A.text(ctx, 'CARILLON', 12, 18, { size: 15, weight: '600', fill: '#e9d9ae' });
    var beatPos = (g.t % D.BEAT_MS) / D.BEAT_MS;
    for (var pip = 0; pip < 4; pip++) {
      var on = Math.floor(g.t / D.BEAT_MS) % 4 === pip;
      ctx.fillStyle = on ? 'rgba(255,214,140,' + (1 - beatPos * 0.7) + ')' : 'rgba(255,214,140,0.18)';
      ctx.fillRect(112 + pip * 13, 9, 8, 8);
    }
    var right = 'wave ' + Math.min(g.wave + 1, D.WAVES.length) + '   resolve ' + g.resolve + '   tithe ' + Math.floor(g.tithe);
    A.text(ctx, right, W - 12, 18, { size: 13, align: 'right', fill: '#c7c0ae' });

    if (armed) A.text(ctx, 'pick a bell to ' + D.INTERVENTIONS[armed].name.toLowerCase(), W / 2, 18, { size: 13, align: 'center', fill: '#ffd68c' });
    else if (placing) A.text(ctx, 'click open ground to hang the ' + D.METALS[placing].name.toLowerCase() + ' bell', W / 2, 18, { size: 13, align: 'center', fill: '#ffd68c' });

    /* transient messages */
    var ny = H - 14;
    for (var f = flash.length - 1; f >= 0; f--) {
      var age = (now - flash[f].at) / 1000;
      if (age > 3.4) { flash.splice(f, 1); continue; }
      ctx.globalAlpha = Math.max(0, 1 - age / 3.4);
      A.text(ctx, flash[f].msg, 12, ny, { size: 13, fill: flash[f].warm ? '#e88a70' : '#cfe0c4', shadow: true });
      ctx.globalAlpha = 1;
      ny -= 18;
    }
  }

  /* ---------------------------------------------------------------- loop */

  var last = 0;
  function frame(now) {
    if (!last) last = now;
    var dt = Math.min(64, now - last);   // a backgrounded tab must never fast-forward the siege
    last = now;

    if (running && g.phase === 'wave') {
      var before = { killed: g.stats.killed, leaked: g.stats.leaked, phase: g.phase };
      S.step(g, dt);
      if (g.stats.killed > before.killed) SND.play('sfx_kill', 0.35);
      if (g.stats.leaked > before.leaked) { SND.play('sfx_breach', 0.9); say('the gate is breached', true); }
      if (g.phase === 'build' && before.phase === 'wave') {
        SND.play('sfx_clear', 0.7); say('wave held, +' + D.WAVES[g.wave - 1].bounty + ' tithe');
        SV.saveSiege(g);
      }
      if (g.phase === 'lost') endSiege(false);
      if (g.phase === 'won') endSiege(true);
    } else if (running) {
      S.step(g, dt);          // the metronome keeps running in the build phase: the bells still ring
    }

    /* sound the bells on the beat */
    var beatNow = Math.floor(g.t / D.BEAT_MS);
    if (beatNow !== lastBeatSeen) {
      lastBeatSeen = beatNow;
      var sounded = {};
      for (var i = 0; i < g.bells.length; i++) {
        var b = g.bells[i];
        if (beatNow % D.METALS[b.metal].period !== 0) continue;
        if (sounded[b.metal]) continue;        // one voice per metal per beat: a rank is one sound
        sounded[b.metal] = 1;
        SND.ringBell(b.metal);
      }
    }

    render(now);
    buildPanel();
    requestAnimationFrame(frame);
  }

  /* ---------------------------------------------------------------- lifecycle */

  function endSiege(won) {
    running = false;
    var bloom = S.bankBloom(g);
    SV.saveFoundry(g.save);
    SV.clearSiege();
    document.getElementById('endtitle').textContent = won ? 'The siege is held.' : 'The gate is down.';
    document.getElementById('endbody').innerHTML = buildEndBody(won, bloom);
    showOverlay(overlayEnd);
    wireFoundry();
  }

  function buildEndBody(won, bloom) {
    var h = [];
    h.push('<p>' + (won
      ? 'Twelve waves, and the valley is quiet. The bells are still hanging where you left them.'
      : 'You reached wave ' + (g.wave + 1) + ' of ' + D.WAVES.length + '. The foundry is untouched: nothing you built into the metal is lost.') + '</p>');
    h.push('<p class="bloom">Bloom in hand: <b>' + bloom + '</b></p>');
    h.push('<div class="foundry">');
    D.FOUNDRY.forEach(function (f) {
      var lvl = S.foundryLevel(g.save, f.id);
      var done = lvl >= f.max;
      var cost = done ? 0 : f.cost[lvl];
      h.push('<div class="fitem">'
        + '<b>' + f.name + '</b> <span class="lvl">' + lvl + '/' + f.max + '</span>'
        + '<span class="fblurb">' + f.blurb + '</span>'
        + (done ? '<span class="maxed">finished</span>'
          : '<button class="up' + (bloom >= cost ? '' : ' no') + '" data-f="' + f.id + '">spend ' + cost + '</button>')
        + '</div>');
    });
    h.push('</div>');
    h.push('<button class="go" id="again">Hang a new peal</button>');
    return h.join('');
  }

  function wireFoundry() {
    overlayEnd.querySelectorAll('button[data-f]').forEach(function (b) {
      b.addEventListener('click', function () {
        var r = S.buyFoundry(g.save, b.getAttribute('data-f'));
        if (r.ok) {
          SND.play('sfx_tune', 0.7);
          SV.saveFoundry(g.save);
          document.getElementById('endbody').innerHTML = buildEndBody(g.phase === 'won', g.save.bloom);
          wireFoundry();
        } else SND.play('sfx_deny', 0.5);
      });
    });
    var again = document.getElementById('again');
    if (again) again.addEventListener('click', function () { hideOverlays(); newSiege(); });
  }

  function newSiege() {
    var save = SV.loadFoundry();
    g = S.newGame(save);
    placing = null; armed = null; selected = null; panelSig = ''; flash = [];
    running = true;
    SND.startMusic();
    say('hang two bells so their rings can meet');
  }

  function resumeOrNew() {
    var save = SV.loadFoundry();
    var snap = SV.loadSiege();
    g = S.newGame(save);
    if (snap && snap.bells && snap.bells.length) {
      g.wave = snap.wave || 0;
      g.tithe = snap.tithe;
      g.resolve = snap.resolve;
      g.bloomEarned = snap.bloomEarned || 0;
      g.nextBellId = snap.nextBellId || (snap.bells.length + 1);
      g.bells = snap.bells.map(function (b) {
        return { x: b.x, y: b.y, metal: b.metal, rope: b.rope || 0, yoke: b.yoke || 0,
          drift: b.drift || 0, rings: [], lastBeat: -1, id: b.id };
      });
      S.rebuildBonds(g);
      g.phase = 'build';
      say('the peal is where you left it, wave ' + (g.wave + 1));
    }
    running = true;
    placing = null; armed = null; selected = null; panelSig = '';
  }

  /* ---------------------------------------------------------------- boot */

  document.getElementById('begin').addEventListener('click', function () {
    SND.unlock();
    hideOverlays();
    SND.startMusic();
  });
  document.getElementById('wipe').addEventListener('click', function () {
    SV.wipeAll();
    hideOverlays();
    newSiege();
  });

  A.load(function () {
    resumeOrNew();
    SND.init();
    requestAnimationFrame(frame);
  });

  /* a handle for the capture harness and the smoke test: the only honest proof art DECODED */
  window.CARILLON = {
    artLoaded: function () { return A.assetsLoaded(); },
    state: function () { return g; },
    sim: S,
    setPlacing: function (m) { placing = m; panelSig = ''; },
    select: function (i) { selected = g.bells[i] || null; panelSig = ''; },
    setRunning: function (v) { running = v; },
    newSiege: newSiege,
    /* exposed so the gallery capture drives the REAL end screen rather than showing an empty
       overlay it populated by hand - the first attempt did the latter and correctly refused to
       ship the blank picture it produced */
    endSiege: endSiege,
    showOverlay: showOverlay,
    hideOverlays: hideOverlays,
    overlays: { title: overlayTitle, help: overlayHelp, end: overlayEnd },
    renderOnce: function () { render(performance.now()); }
  };
})();
