/* CARILLON — sound.js
 *
 * ⭐ THE DEFENCE PLAYS A CARILLON BECAUSE THE DEFENCE *IS* A CARILLON. Every bell on the board
 *    sounds its own metal's note when it rings, on the metronome, so the music a player hears is
 *    literally the state of their battery. Nothing here composes anything: it plays the note the
 *    simulation just said to play.
 *
 * ⚠️ POLYPHONY HAS TO BE CAPPED OR A LATE BATTERY IS A WALL OF NOISE. Eighteen bells on the same
 *    beat is eighteen simultaneous voices, which is unpleasant and also expensive. The cap keeps
 *    the newest voices and lets the oldest go, and a bell that would be the Nth voice on a beat is
 *    simply not sounded - the visual is the truth, the audio is the flavour.
 */
'use strict';

var CARILLON_SOUND = (function () {

  var ctx = null, master = null, musicGain = null, sfxGain = null;
  var buffers = {};
  var ready = false, enabled = true, failed = false;
  var live = [];
  var MAX_VOICES = 7;
  var musicNode = null;

  var FILES = ['bell_bronze', 'bell_iron', 'bell_silver', 'bell_lead',
    'sfx_hang', 'sfx_deny', 'sfx_tune', 'sfx_toll', 'sfx_shift',
    'sfx_kill', 'sfx_breach', 'sfx_wave', 'sfx_clear', 'carillon_theme'];

  function init() {
    if (ctx || failed) return;
    try {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) { failed = true; return; }
      ctx = new AC();
      master = ctx.createGain(); master.gain.value = 0.85; master.connect(ctx.destination);
      musicGain = ctx.createGain(); musicGain.gain.value = 0.5; musicGain.connect(master);
      sfxGain = ctx.createGain(); sfxGain.gain.value = 0.9; sfxGain.connect(master);
      var got = 0;
      FILES.forEach(function (n) {
        fetch('audio/' + n + '.ogg')
          .then(function (r) { return r.arrayBuffer(); })
          .then(function (ab) { return ctx.decodeAudioData(ab); })
          .then(function (buf) { buffers[n] = buf; got++; if (got >= FILES.length - 1) ready = true; })
          .catch(function () { got++; if (got >= FILES.length - 1) ready = true; });
      });
    } catch (e) { failed = true; }
  }

  /* Browsers refuse audio until a gesture. Called from the first click. */
  function unlock() {
    init();
    if (ctx && ctx.state === 'suspended') ctx.resume();
  }

  function play(name, gain, rate) {
    if (!enabled || !ctx || !buffers[name]) return;
    var now = ctx.currentTime;
    live = live.filter(function (v) { return v.until > now; });
    if (live.length >= MAX_VOICES) return;
    try {
      var src = ctx.createBufferSource();
      src.buffer = buffers[name];
      src.playbackRate.value = rate || 1;
      var g = ctx.createGain();
      g.gain.value = gain === undefined ? 1 : gain;
      src.connect(g); g.connect(sfxGain);
      src.start();
      live.push({ until: now + buffers[name].duration / (rate || 1) });
    } catch (e) { /* a dead context must never take the game down with it */ }
  }

  function ringBell(metal) {
    /* a small fixed detune per metal keeps a rank of the same metal from sounding like one voice */
    play('bell_' + metal, 0.55, 1);
  }

  function startMusic() {
    if (!ctx || !buffers.carillon_theme || musicNode) return;
    try {
      musicNode = ctx.createBufferSource();
      musicNode.buffer = buffers.carillon_theme;
      musicNode.loop = true;
      musicNode.connect(musicGain);
      musicNode.start();
    } catch (e) { musicNode = null; }
  }

  function stopMusic() {
    if (musicNode) { try { musicNode.stop(); } catch (e) {} musicNode = null; }
  }

  function setEnabled(on) {
    enabled = !!on;
    if (master) master.gain.value = enabled ? 0.85 : 0;
    if (enabled) startMusic();
  }

  return {
    init: init, unlock: unlock, play: play, ringBell: ringBell,
    startMusic: startMusic, stopMusic: stopMusic, setEnabled: setEnabled,
    isEnabled: function () { return enabled; },
    isReady: function () { return ready; },
    loadedCount: function () { return Object.keys(buffers).length; }
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CARILLON_SOUND;
