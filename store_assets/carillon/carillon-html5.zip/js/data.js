/* CARILLON — data.js
 * Every tunable number in the game, in one file, with the reasoning kept beside it.
 * Loaded in the browser as a plain script and require()d by the headless probes, so it must stay
 * free of DOM and of module syntax.
 *
 * Core Systems Asset Factory. Free to play, source shipped raw and readable on purpose.
 */
'use strict';

var CARILLON_DATA = (function () {

  /* ---------------------------------------------------------------- the world */

  var W = 960, H = 540;

  /* The valley road. The procession walks this polyline from the west edge to the gate.
     Deliberately NOT a straight line and NOT axis-aligned: the whole game is about whether a
     chord (a straight line between two bells) crosses the road at a useful angle, and a straight
     road would make every good answer the same answer. */
  var ROAD = [
    [-30, 132], [126, 138], [214, 186], [252, 272], [318, 336],
    [430, 352], [520, 300], [606, 258], [700, 286], [762, 366],
    [828, 424], [986, 438]
  ];

  /* Ground the player may not build on: the road corridor itself, plus the gate yard. */
  var ROAD_CLEARANCE = 26;   // px either side of the road centre line
  var GATE = [900, 432];

  /* ---------------------------------------------------------------- the metronome */

  var BEAT_MS = 1000;        // one beat of the carillon
  /* px per second a ring expands. THIS IS THE MOST LOAD-BEARING NUMBER IN THE GAME and it moves
     three things at once, which is why it was got wrong first: it sets how long a ring lives
     (reach / speed), therefore what fraction of each beat a chord is firing at all, AND how fast a
     spark sweeps, therefore how long it dwells inside a body. Faster rings mean a sparser, weaker
     game. 132 gave a 17% duty cycle and a siege lost at wave 1; 88 gives a chord that is audibly
     and visibly a PULSE rather than a flicker. */
  var RING_SPEED = 88;

  /* ---------------------------------------------------------------- bell metals
   * period  : beats between this bell's rings
   * reach   : px the ring travels before it dies. TWO BELLS BOND WHEN d <= 2*min(reach), because
   *           that is exactly the condition for their rings to ever touch. The bond rule is not a
   *           separate number - it falls out of the physics, which is the point of the game.
   * power   : damage per second a spark from this pair applies (a pair averages its two bells)
   * unlockWave : the siege wave at which it becomes purchasable (unlock pacing, ledger B5)
   */
  /* ⚠️ POWER IS A RATE, NOT A HIT. A spark is a moving point, so what an enemy actually takes is
     power x the fraction of a second the spark spends inside it - about 0.15s for a typical
     crossing. The first draft of these numbers was calibrated as though power were a hit and the
     probe measured the whole siege lost at wave 1 with ZERO kills. They are calibrated against
     DWELL now, and probe.js re-measures it every run. */
  var METALS = {
    bronze: {
      id: 'bronze', name: 'Bronze', period: 2, reach: 104, power: 52, cost: 95,
      unlockWave: 0, hue: 'bronze',
      blurb: 'The founder\'s metal. Middling in every direction, which is why every battery starts with a pair of them.'
    },
    iron: {
      id: 'iron', name: 'Iron', period: 1, reach: 72, power: 32, cost: 130,
      unlockWave: 3, hue: 'iron',
      blurb: 'Rings on every beat and dies close to home. Short chords, but twice as many of them as bronze.'
    },
    silver: {
      id: 'silver', name: 'Silver', period: 3, reach: 164, power: 95, cost: 240,
      unlockWave: 6, hue: 'silver',
      blurb: 'Slow, enormous, and heavy enough to open a shell. It bonds with things half the valley away.'
    },
    lead: {
      id: 'lead', name: 'Lead', period: 4, reach: 124, power: 18, cost: 175,
      unlockWave: 9, hue: 'lead',
      blurb: 'Barely hurts anything. What it does is HOLD: everything a lead spark touches walks at two thirds speed for a moment.'
    }
  };
  var METAL_ORDER = ['bronze', 'iron', 'silver', 'lead'];

  /* Lead's contribution. Kept here rather than in sim.js so a balance pass is one file. */
  var LEAD_SLOW = 0.66;      // multiplier on walk speed
  var LEAD_SLOW_MS = 900;    // how long the hold lasts after the last touch

  /* ---------------------------------------------------------------- per-bell upgrades */

  var UPGRADES = {
    rope: {
      id: 'rope', name: 'Rope', max: 3, step: 22, baseCost: 70, costMul: 1.75,
      blurb: 'Lets the ring travel further before it dies. More reach means more bonds, and a bond you did not plan is the usual reason a battery suddenly works.'
    },
    yoke: {
      id: 'yoke', name: 'Yoke', max: 3, step: 0.28, baseCost: 85, costMul: 1.8,
      blurb: 'A heavier clapper. Every spark this bell is part of bites harder.'
    }
  };

  /* ---------------------------------------------------------------- the foundry
   * Persistent across sieges. This is the "you keep something" half of the save/resume rule:
   * a breach costs you the siege, never the foundry.
   */
  var FOUNDRY = [
    { id: 'ear', name: 'The Founder\'s Ear', max: 4, cost: [3, 6, 11, 18], step: 9,
      blurb: '+9px reach on every bell you ever hang.' },
    { id: 'beat', name: 'A Truer Beat', max: 4, cost: [3, 6, 11, 18], step: 0.18,
      blurb: 'Bells drift off the metronome 18% more slowly per level.' },
    { id: 'clapper', name: 'Heavier Clappers', max: 4, cost: [4, 8, 14, 22], step: 0.10,
      blurb: '+10% spark power per level.' },
    { id: 'purse', name: 'A Deep Purse', max: 3, cost: [3, 7, 13], step: 45,
      blurb: '+45 tithe in hand at the start of every siege.' },
    { id: 'hand', name: 'A Third Hand', max: 2, cost: [8, 16], step: 1,
      blurb: '+1 intervention charge per wave.' },
    { id: 'quick', name: 'Quick Rings', max: 3, cost: [5, 10, 17], step: 8,
      blurb: '+8px/s ring speed. Rings reach the far side of a long chord sooner.' }
  ];

  /* ---------------------------------------------------------------- interventions
   * Scarce and decisive, per the Gate 4 note. All three act on PHASE or on the ring, because
   * phase and geometry are the only two things in this game.
   */
  var INTERVENTIONS = {
    toll: { id: 'toll', name: 'Toll', key: '1', unlockWave: 0,
      blurb: 'Sound one bell right now, off the beat. Its ring meets every neighbour\'s ring somewhere new, and the sparks sweep clean across whatever is standing there.' },
    tune: { id: 'tune', name: 'Tune', key: '2', unlockWave: 2,
      blurb: 'Pull one bell back onto the metronome. Every chord it owns snaps straight again.' },
    shift: { id: 'shift', name: 'Shift', key: '3', unlockWave: 5,
      blurb: 'Push one bell a half beat OFF the metronome, on purpose. Its chords bow away from the bell - which is what you want when the road does not run down the middle.' }
  };

  /* ---------------------------------------------------------------- the procession */

  var ENEMIES = {
    walker: { id: 'walker', name: 'Walker', hp: 46, speed: 34, armour: 0, tithe: 5, radius: 8,
      blurb: 'Pilgrims. They do not fight and they do not stop.' },
    runner: { id: 'runner', name: 'Runner', hp: 30, speed: 68, armour: 0, tithe: 6, radius: 7,
      blurb: 'Through the sparks before the sparks have finished arriving.' },
    shell: { id: 'shell', name: 'Shell', hp: 130, speed: 26, armour: 26, tithe: 14, radius: 10,
      blurb: 'Plated. One bronze chord scratches it. Stand it where three chords cross and it comes apart.' },
    damper: { id: 'damper', name: 'Damper', hp: 150, speed: 30, armour: 22, tithe: 16, radius: 9,
      drift: 95,
      blurb: 'Carries wet felt. Every bell it walks past slides off the beat, and every chord that bell owns bows away from the road.' },
    warden: { id: 'warden', name: 'Warden', hp: 460, speed: 22, armour: 58, tithe: 48, radius: 12,
      drift: 170,
      blurb: 'A damper that can take a beating. If one of these gets halfway down the valley your geometry is already gone.' }
  };

  /* Damper reach: how close a damper must pass to knock a bell off the beat.
     ⭐ SMALL ON PURPOSE, and the reason is the sharpest thing the campaign probe found: UNIFORM
     DRIFT IS HARMLESS. Two bells that are both a half beat late still have equal radii, so their
     chord is as straight as it ever was. Only DIFFERENTIAL drift bends anything. At a radius of
     112 a damper knocked most of the battery off the beat together, the chords stayed straight,
     and tuning could not possibly matter - the probe measured a battery that never tuned scoring
     BETTER than one that did. The attack has to be LOCAL to be an attack at all. */
  var DAMP_RADIUS = 150;

  /* ---------------------------------------------------------------- the siege
   * 12 waves. Composition is authored rather than generated, because the whole design rests on
   * introducing the phase attack (damper) only after the player has learned to read a straight
   * chord - a random generator would sometimes open with one.
   */
  /* hpMul rises faster than a battery can grow on purpose. A tower defence whose difficulty curve
     is flatter than its economy curve is the ONE-WAY RATCHET wing CLAUDE.md 3f is about: it feels
     like a game for four waves and like a screensaver for the other eight, and only a campaign
     probe can see it. probe.js asserts BOTH directions - the intended play must win, and a thin
     battery that ignores its phase must lose. */
  var WAVES = [
    { n: 1,  bounty: 68,  hpMul: 1.00, groups: [['walker', 6, 900]] },
    { n: 2,  bounty: 76,  hpMul: 1.10, groups: [['walker', 10, 700]] },
    { n: 3,  bounty: 88,  hpMul: 1.25, groups: [['walker', 8, 640], ['runner', 5, 460]] },
    { n: 4,  bounty: 102,  hpMul: 1.42, groups: [['runner', 11, 380], ['walker', 8, 640]] },
    { n: 5,  bounty: 118,  hpMul: 1.62, groups: [['walker', 10, 560], ['shell', 3, 1500]] },
    { n: 6,  bounty: 136,  hpMul: 1.85, groups: [['shell', 5, 1250], ['runner', 10, 360]] },
    { n: 7,  bounty: 156,  hpMul: 2.10, groups: [['damper', 3, 1400], ['walker', 12, 480]] },
    { n: 8,  bounty: 178, hpMul: 2.40, groups: [['damper', 4, 1100], ['shell', 4, 1200], ['runner', 8, 380]] },
    { n: 9,  bounty: 204, hpMul: 2.70, groups: [['runner', 16, 270], ['damper', 4, 1000]] },
    { n: 10, bounty: 232, hpMul: 3.00, groups: [['shell', 7, 950], ['damper', 5, 820]] },
    { n: 11, bounty: 266, hpMul: 3.35, groups: [['warden', 1, 1], ['damper', 5, 800], ['runner', 14, 280]] },
    { n: 12, bounty: 340, hpMul: 3.75, groups: [['warden', 2, 4000], ['shell', 8, 820], ['damper', 6, 740], ['runner', 12, 280]] }
  ];

  var START_TITHE = 300;
  var START_RESOLVE = 12;
  var BASE_CHARGES = 2;
  var SPARK_RADIUS = 11;     // px. A spark is a point; this is how close it must pass.
  var DRIFT_DECAY = 0.978;   // per second, drift creeps back toward the beat on its own (slowly)

  /* Bloom awarded at the end of a siege, spent in the foundry. Named so it is not "money" twice. */
  var BLOOM_PER_WAVE = 1;
  var BLOOM_CLEAR_BONUS = 6;

  return {
    W: W, H: H, ROAD: ROAD, ROAD_CLEARANCE: ROAD_CLEARANCE, GATE: GATE,
    BEAT_MS: BEAT_MS, RING_SPEED: RING_SPEED,
    METALS: METALS, METAL_ORDER: METAL_ORDER, LEAD_SLOW: LEAD_SLOW, LEAD_SLOW_MS: LEAD_SLOW_MS,
    UPGRADES: UPGRADES, FOUNDRY: FOUNDRY, INTERVENTIONS: INTERVENTIONS,
    ENEMIES: ENEMIES, DAMP_RADIUS: DAMP_RADIUS, WAVES: WAVES,
    START_TITHE: START_TITHE, START_RESOLVE: START_RESOLVE, BASE_CHARGES: BASE_CHARGES,
    SPARK_RADIUS: SPARK_RADIUS, DRIFT_DECAY: DRIFT_DECAY,
    BLOOM_PER_WAVE: BLOOM_PER_WAVE, BLOOM_CLEAR_BONUS: BLOOM_CLEAR_BONUS
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CARILLON_DATA;
