/* CARILLON — sim.js
 *
 * THE WHOLE GAME IS IN HERE AND IT HAS NO DOM IN IT, deliberately: wing CLAUDE.md 3f-1 measured
 * two titles that passed every unit assertion and were unplayable, so the simulation has to be
 * runnable headless by a campaign probe before a single pixel is drawn.
 *
 * THE ONE IDEA. A bell does not shoot. It sounds a ring, and the ring expands. For any two bells
 * whose rings can reach the midpoint between them, the LIVE INTERSECTION POINTS of their rings are
 * sparks, and sparks are the only thing in this game that does damage. Two bells that ring together
 * have equal radii, so their sparks sit on the perpendicular bisector - a straight line you can
 * plan against. Two bells that ring a beat apart have radii differing by a constant, so their
 * sparks sit on a hyperbola bowing toward whichever rang first. Nothing here computes a hyperbola;
 * it falls out of circle-circle intersection for free, which is why the whole game is one function.
 *
 * Core Systems Asset Factory.
 */
'use strict';

(function (root, factory) {
  var D = (typeof require === 'function' && typeof module !== 'undefined')
    ? require('./data.js') : root.CARILLON_DATA;
  var api = factory(D);
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.CARILLON_SIM = api;
}(typeof self !== 'undefined' ? self : this, function (D) {

  /* ================================================================= the road */

  function buildRoad(pts) {
    var segs = [], total = 0;
    for (var i = 0; i < pts.length - 1; i++) {
      var a = pts[i], b = pts[i + 1];
      var dx = b[0] - a[0], dy = b[1] - a[1];
      var len = Math.sqrt(dx * dx + dy * dy);
      segs.push({ ax: a[0], ay: a[1], dx: dx / len, dy: dy / len, len: len, at: total });
      total += len;
    }
    return { segs: segs, total: total };
  }
  var ROAD = buildRoad(D.ROAD);

  function roadPoint(dist) {
    if (dist <= 0) return { x: ROAD.segs[0].ax, y: ROAD.segs[0].ay };
    for (var i = 0; i < ROAD.segs.length; i++) {
      var s = ROAD.segs[i];
      if (dist <= s.at + s.len) {
        var u = dist - s.at;
        return { x: s.ax + s.dx * u, y: s.ay + s.dy * u };
      }
    }
    var last = ROAD.segs[ROAD.segs.length - 1];
    return { x: last.ax + last.dx * last.len, y: last.ay + last.dy * last.len };
  }

  /* Distance from a point to the road polyline. Used for the build mask and by the art layer. */
  function distToRoad(x, y) {
    var best = 1e9;
    for (var i = 0; i < ROAD.segs.length; i++) {
      var s = ROAD.segs[i];
      var vx = x - s.ax, vy = y - s.ay;
      var t = vx * s.dx + vy * s.dy;
      if (t < 0) t = 0; else if (t > s.len) t = s.len;
      var px = s.ax + s.dx * t - x, py = s.ay + s.dy * t - y;
      var d = Math.sqrt(px * px + py * py);
      if (d < best) best = d;
    }
    return best;
  }

  function canBuildAt(x, y, bells, minGap) {
    if (x < 22 || x > D.W - 22 || y < 22 || y > D.H - 22) return false;
    if (distToRoad(x, y) < D.ROAD_CLEARANCE) return false;
    for (var i = 0; i < bells.length; i++) {
      var dx = bells[i].x - x, dy = bells[i].y - y;
      if (dx * dx + dy * dy < minGap * minGap) return false;
    }
    return true;
  }

  /* ================================================================= geometry */

  /* The entire weapon. Returns [] , or [[x,y],[x,y]] - the two points where circle A meets B.
     Tangency returns the single point twice, which is correct and costs nothing. */
  function ringMeet(ax, ay, ra, bx, by, rb) {
    var dx = bx - ax, dy = by - ay;
    var d2 = dx * dx + dy * dy;
    if (d2 === 0) return null;
    var d = Math.sqrt(d2);
    if (d > ra + rb) return null;            // rings have not met yet, or have passed each other
    if (d < Math.abs(ra - rb)) return null;  // one ring is entirely inside the other
    var a = (ra * ra - rb * rb + d2) / (2 * d);
    var h2 = ra * ra - a * a;
    if (h2 < 0) return null;
    var h = Math.sqrt(h2);
    var mx = ax + a * dx / d, my = ay + a * dy / d;
    var ox = -dy / d * h, oy = dx / d * h;
    return [[mx + ox, my + oy], [mx - ox, my - oy]];
  }

  /* ================================================================= state */

  /* Every bell has ONE sour note it goes to when it is damped, fixed for the life of the bell and
     derived from its id, so the game stays deterministic and a probe run is reproducible. Range is
     +/- half a beat, which is the furthest two bells can be from each other in phase. */
  function detuneTarget(bell) {
    var h = Math.sin(bell.id * 12.9898 + 4.1414) * 43758.5453;
    h = h - Math.floor(h);
    var v = (h - 0.5) * D.BEAT_MS;
    /* never hand back a target so close to the beat that damping this bell does nothing */
    if (Math.abs(v) < D.BEAT_MS * 0.18) v = (v < 0 ? -1 : 1) * D.BEAT_MS * 0.18;
    return v;
  }

  function foundryLevel(save, id) { return (save && save.foundry && save.foundry[id]) || 0; }

  function foundryBonus(save, id) {
    var def = null;
    for (var i = 0; i < D.FOUNDRY.length; i++) if (D.FOUNDRY[i].id === id) def = D.FOUNDRY[i];
    return def ? foundryLevel(save, id) * def.step : 0;
  }

  function newBell(x, y, metalId, save) {
    return {
      x: x, y: y, metal: metalId,
      rope: 0, yoke: 0,
      drift: 0,          // ms off the metronome. THE second system.
      rings: [],         // {t0} - emission time in ms of game clock
      lastBeat: -1,
      id: 0
    };
  }

  function bellReach(b, save) {
    return D.METALS[b.metal].reach
      + b.rope * D.UPGRADES.rope.step
      + foundryBonus(save, 'ear');
  }
  function bellPower(b, save) {
    return D.METALS[b.metal].power
      * (1 + b.yoke * D.UPGRADES.yoke.step)
      * (1 + foundryBonus(save, 'clapper'));
  }
  function ringSpeed(save) { return D.RING_SPEED + foundryBonus(save, 'quick'); }
  function driftDecay(save) {
    // "A Truer Beat" makes drift decay FASTER (each level removes 18% more of what is left).
    var base = 1 - D.DRIFT_DECAY;                    // fraction lost per second at level 0
    return 1 - base * (1 + foundryBonus(save, 'beat'));
  }

  function newGame(save) {
    save = save || { foundry: {}, bloom: 0 };
    return {
      save: save,
      t: 0,                 // ms of game clock, advanced only by step()
      beat: -1,
      wave: 0,              // index into D.WAVES; 0 means "wave 1 has not started"
      phase: 'build',       // build | wave | won | lost
      tithe: D.START_TITHE + foundryBonus(save, 'purse'),
      resolve: D.START_RESOLVE,
      charges: D.BASE_CHARGES + foundryBonus(save, 'hand'),
      bells: [],
      enemies: [],
      sparks: [],           // rebuilt every step; {x,y,power,lead}
      bonds: [],            // rebuilt when the battery changes; {a,b,d}
      spawnQueue: [],
      nextBellId: 1,
      log: [],
      stats: { killed: 0, leaked: 0, damageDealt: 0, sparkFrames: 0, beats: 0 },
      bloomEarned: 0
    };
  }

  /* ================================================================= the battery */

  function rebuildBonds(g) {
    g.bonds = [];
    for (var i = 0; i < g.bells.length; i++) {
      for (var j = i + 1; j < g.bells.length; j++) {
        var A = g.bells[i], B = g.bells[j];
        var dx = B.x - A.x, dy = B.y - A.y;
        var d = Math.sqrt(dx * dx + dy * dy);
        /* THE BOND RULE, and it is not a separate number: two bells bond exactly when each ring
           can still be alive at the midpoint, because that is the first place the rings can touch. */
        var rmin = Math.min(bellReach(A, g.save), bellReach(B, g.save));
        if (d <= 2 * rmin) g.bonds.push({ a: i, b: j, d: d });
      }
    }
  }

  function placeBell(g, x, y, metalId) {
    var m = D.METALS[metalId];
    if (!m) return { ok: false, why: 'no such metal' };
    if (g.wave < m.unlockWave) return { ok: false, why: m.name + ' is not cast until wave ' + (m.unlockWave + 1) };
    if (g.tithe < m.cost) return { ok: false, why: 'not enough tithe' };
    if (!canBuildAt(x, y, g.bells, 30)) return { ok: false, why: 'nothing can hang there' };
    var b = newBell(x, y, metalId, g.save);
    b.id = g.nextBellId++;
    g.bells.push(b);
    g.tithe -= m.cost;
    rebuildBonds(g);
    return { ok: true, bell: b };
  }

  function upgradeCost(kind, level) {
    var u = D.UPGRADES[kind];
    return Math.round(u.baseCost * Math.pow(u.costMul, level));
  }

  function upgradeBell(g, bell, kind) {
    var u = D.UPGRADES[kind];
    if (!u) return { ok: false, why: 'no such upgrade' };
    if (bell[kind] >= u.max) return { ok: false, why: u.name + ' is already at its limit' };
    var c = upgradeCost(kind, bell[kind]);
    if (g.tithe < c) return { ok: false, why: 'not enough tithe' };
    g.tithe -= c;
    bell[kind]++;
    if (kind === 'rope') rebuildBonds(g);
    return { ok: true, cost: c };
  }

  function sellBell(g, bell) {
    var i = g.bells.indexOf(bell);
    if (i < 0) return { ok: false, why: 'not a bell' };
    var refund = Math.round(D.METALS[bell.metal].cost * 0.6);
    g.bells.splice(i, 1);
    g.tithe += refund;
    rebuildBonds(g);
    return { ok: true, refund: refund };
  }

  /* ================================================================= interventions */

  function intervene(g, kind, bell) {
    var def = D.INTERVENTIONS[kind];
    if (!def) return { ok: false, why: 'no such intervention' };
    if (g.wave < def.unlockWave) return { ok: false, why: def.name + ' is not learned yet' };
    if (g.charges <= 0) return { ok: false, why: 'no charges left this wave' };
    if (!bell) return { ok: false, why: 'pick a bell' };
    if (kind === 'toll') {
      bell.rings.push({ t0: g.t });
    } else if (kind === 'tune') {
      bell.drift = 0;
    } else if (kind === 'shift') {
      bell.drift = (bell.drift > D.BEAT_MS * 0.25) ? 0 : D.BEAT_MS * 0.5;
    }
    g.charges--;
    return { ok: true };
  }

  /* ================================================================= waves */

  function startWave(g) {
    if (g.phase !== 'build') return { ok: false, why: 'a wave is already running' };
    if (g.wave >= D.WAVES.length) return { ok: false, why: 'the siege is over' };
    var w = D.WAVES[g.wave];
    g.phase = 'wave';
    g.charges = D.BASE_CHARGES + foundryBonus(g.save, 'hand');
    g.spawnQueue = [];
    for (var i = 0; i < w.groups.length; i++) {
      var grp = w.groups[i], type = grp[0], n = grp[1], gap = grp[2];
      for (var k = 0; k < n; k++) g.spawnQueue.push({ at: g.t + 600 + k * gap + i * 250, type: type });
    }
    g.spawnQueue.sort(function (p, q) { return p.at - q.at; });
    return { ok: true, wave: w };
  }

  function spawn(g, type) {
    var e = D.ENEMIES[type];
    var mul = (D.WAVES[g.wave] && D.WAVES[g.wave].hpMul) || 1;
    var hp = e.hp * mul;
    g.enemies.push({
      type: type, hp: hp, maxHp: hp, dist: 0,
      slowUntil: -1, x: 0, y: 0
    });
  }

  /* ================================================================= the step
   * dt in MILLISECONDS. Fixed-step from the probe, real-time from the browser. Every rate in here
   * is per second and multiplied by dt/1000, so the two agree.
   */
  function step(g, dt) {
    if (g.phase === 'won' || g.phase === 'lost') return;
    var sec = dt / 1000;
    g.t += dt;

    /* -- the metronome. Rings are emitted on beats, offset by each bell's own drift. -- */
    var beatNow = Math.floor(g.t / D.BEAT_MS);
    if (beatNow !== g.beat) {
      for (var nb = g.beat + 1; nb <= beatNow; nb++) {
        g.stats.beats++;
        for (var i = 0; i < g.bells.length; i++) {
          var b = g.bells[i];
          if (nb % D.METALS[b.metal].period === 0) b.rings.push({ t0: nb * D.BEAT_MS + b.drift });
        }
      }
      g.beat = beatNow;
    }

    /* -- rings age out. A ring dies when it has travelled its bell's reach. -- */
    var v = ringSpeed(g.save);
    for (var i2 = 0; i2 < g.bells.length; i2++) {
      var bb = g.bells[i2];
      var reach = bellReach(bb, g.save);
      var keep = [];
      for (var r = 0; r < bb.rings.length; r++) {
        var rad = v * (g.t - bb.rings[r].t0) / 1000;
        if (rad <= reach) keep.push(bb.rings[r]);
      }
      bb.rings = keep;
      /* drift creeps back toward the beat on its own, slowly. TUNE is the fast way. */
      if (bb.drift !== 0) {
        bb.drift *= Math.pow(driftDecay(g.save), sec);
        if (Math.abs(bb.drift) < 0.5) bb.drift = 0;
      }
    }

    /* -- SPARKS. Every live ring pair on every bond. This is the whole weapon. -- */
    g.sparks.length = 0;
    for (var k = 0; k < g.bonds.length; k++) {
      var bond = g.bonds[k];
      var A = g.bells[bond.a], B = g.bells[bond.b];
      if (!A || !B) continue;
      var pw = (bellPower(A, g.save) + bellPower(B, g.save)) / 2;
      var lead = (A.metal === 'lead' || B.metal === 'lead');
      for (var ra = 0; ra < A.rings.length; ra++) {
        var radA = v * (g.t - A.rings[ra].t0) / 1000;
        if (radA <= 0) continue;
        for (var rb = 0; rb < B.rings.length; rb++) {
          var radB = v * (g.t - B.rings[rb].t0) / 1000;
          if (radB <= 0) continue;
          var pts = ringMeet(A.x, A.y, radA, B.x, B.y, radB);
          if (!pts) continue;
          g.sparks.push({ x: pts[0][0], y: pts[0][1], power: pw, lead: lead });
          g.sparks.push({ x: pts[1][0], y: pts[1][1], power: pw, lead: lead });
        }
      }
    }
    if (g.sparks.length) g.stats.sparkFrames++;

    /* -- spawn -- */
    while (g.spawnQueue.length && g.spawnQueue[0].at <= g.t) spawn(g, g.spawnQueue.shift().type);

    /* -- the procession -- */
    var sr = D.SPARK_RADIUS;
    for (var e = g.enemies.length - 1; e >= 0; e--) {
      var en = g.enemies[e], def = D.ENEMIES[en.type];
      var p = roadPoint(en.dist);
      en.x = p.x; en.y = p.y;

      /* damage: every spark inside reach of this body, each reduced by its armour */
      var hitR = sr + def.radius, hitR2 = hitR * hitR;
      var took = 0, leaded = false;
      for (var s = 0; s < g.sparks.length; s++) {
        var sp = g.sparks[s];
        var ddx = sp.x - en.x, ddy = sp.y - en.y;
        if (ddx * ddx + ddy * ddy <= hitR2) {
          var net = sp.power - def.armour;
          if (net > 0) took += net;
          if (sp.lead) leaded = true;
        }
      }
      if (took > 0) { en.hp -= took * sec; g.stats.damageDealt += took * sec; }
      if (leaded) en.slowUntil = g.t + D.LEAD_SLOW_MS;

      if (en.hp <= 0) {
        g.tithe += def.tithe;
        g.stats.killed++;
        g.enemies.splice(e, 1);
        continue;
      }

      /* THE DAMPER'S ATTACK IS ON PHASE, NOT ON HIT POINTS - and it FALLS OFF WITH DISTANCE, which
         is the difference between an attack and a no-op. Only the SPREAD of drift across a battery
         bends any chord; two bells equally late still have equal radii and a dead straight chord
         between them. A flat radius drifted the whole battery together, kept every chord straight,
         and made TUNE actively harmful - the probe measured a battery that never tuned dealing
         3,465 MORE damage than one that did, because tuning one bell to zero inside a uniformly
         late battery is what CREATES the variance. With falloff, the bells the damper walks nearest
         go furthest off the beat, the rest stay near it, and pulling an outlier back is correct. */
      if (def.drift) {
        for (var bi = 0; bi < g.bells.length; bi++) {
          var tb = g.bells[bi];
          var tdx = tb.x - en.x, tdy = tb.y - en.y;
          var dd2 = tdx * tdx + tdy * tdy;
          if (dd2 <= D.DAMP_RADIUS * D.DAMP_RADIUS) {
            var falloff = 1 - Math.sqrt(dd2) / D.DAMP_RADIUS;
            /* ⭐ THE DAMPER PUSHES EACH BELL TOWARD ITS OWN SOUR NOTE, NOT ALL OF THEM UP.
               Two earlier versions added a common amount and clamped it. Both saturated: every
               bell pinned to the same ceiling is a battery back IN PHASE with itself, so the
               probe watched spread rise to 156ms in wave 7 and COLLAPSE to 17ms by wave 12 while
               the mean sat at the cap - the attack cancelling itself exactly when it should have
               been worst. Each bell now has a fixed detune of its own, so a fully damped battery
               is maximally SCATTERED rather than uniformly late, and zero stays the one phase
               every bell agrees on - which is what makes TUNE a real verb. */
            var target = detuneTarget(tb);
            var stepMs = def.drift * falloff * falloff * sec;
            if (tb.drift < target) tb.drift = Math.min(target, tb.drift + stepMs);
            else if (tb.drift > target) tb.drift = Math.max(target, tb.drift - stepMs);
          }
        }
      }

      var spd = def.speed * (en.slowUntil > g.t ? D.LEAD_SLOW : 1);
      en.dist += spd * sec;
      if (en.dist >= ROAD.total) {
        g.enemies.splice(e, 1);
        g.resolve--;
        g.stats.leaked++;
        if (g.resolve <= 0) { g.phase = 'lost'; return; }
      }
    }

    /* -- end of wave -- */
    if (g.phase === 'wave' && g.spawnQueue.length === 0 && g.enemies.length === 0) {
      var w = D.WAVES[g.wave];
      g.tithe += w.bounty;
      g.bloomEarned += D.BLOOM_PER_WAVE;
      g.wave++;
      if (g.wave >= D.WAVES.length) {
        g.phase = 'won';
        g.bloomEarned += D.BLOOM_CLEAR_BONUS;
      } else {
        g.phase = 'build';
      }
    }
  }

  /* ================================================================= the chord preview
   * The player cannot plan against a locus they cannot see, so the game draws it. This walks the
   * pair's rings forward through one full cycle and collects where they WOULD meet - the same
   * ringMeet() the damage uses, so the drawn line can never disagree with the weapon.
   */
  function chordLocus(g, bond, samples) {
    samples = samples || 26;
    var A = g.bells[bond.a], B = g.bells[bond.b];
    if (!A || !B) return [[], []];
    var v = ringSpeed(g.save);
    var pa = D.METALS[A.metal].period, pb = D.METALS[B.metal].period;
    /* One full cycle of the pair. lcm of the two periods, in beats. */
    var lcm = (pa * pb) / gcd(pa, pb);
    var span = lcm * D.BEAT_MS;
    var reachA = bellReach(A, g.save), reachB = bellReach(B, g.save);
    var left = [], right = [];
    for (var i = 0; i <= samples; i++) {
      var t = i / samples * span;
      /* the most recent ring each bell would have alive at time t */
      var ta = lastRingAt(t, pa, A.drift), tb = lastRingAt(t, pb, B.drift);
      if (ta === null || tb === null) continue;
      var ra = v * (t - ta) / 1000, rbb = v * (t - tb) / 1000;
      if (ra <= 0 || rbb <= 0 || ra > reachA || rbb > reachB) continue;
      var pts = ringMeet(A.x, A.y, ra, B.x, B.y, rbb);
      if (!pts) continue;
      left.push(pts[0]); right.push(pts[1]);
    }
    return [left, right];
  }

  function lastRingAt(t, period, drift) {
    var beat = Math.floor(t / D.BEAT_MS);
    for (var b = beat; b >= beat - period * 2 && b >= 0; b--) {
      if (b % period === 0) {
        var t0 = b * D.BEAT_MS + drift;
        if (t0 <= t) return t0;
      }
    }
    return null;
  }

  function gcd(a, b) { while (b) { var t = a % b; a = b; b = t; } return a; }

  /* ================================================================= siege lifecycle */

  function bankBloom(g) {
    g.save.bloom = (g.save.bloom || 0) + g.bloomEarned;
    g.bloomEarned = 0;
    return g.save.bloom;
  }

  function buyFoundry(save, id) {
    var def = null;
    for (var i = 0; i < D.FOUNDRY.length; i++) if (D.FOUNDRY[i].id === id) def = D.FOUNDRY[i];
    if (!def) return { ok: false, why: 'no such work' };
    save.foundry = save.foundry || {};
    var lvl = save.foundry[id] || 0;
    if (lvl >= def.max) return { ok: false, why: 'already finished' };
    var cost = def.cost[lvl];
    if ((save.bloom || 0) < cost) return { ok: false, why: 'not enough bloom' };
    save.bloom -= cost;
    save.foundry[id] = lvl + 1;
    return { ok: true, cost: cost, level: lvl + 1 };
  }

  return {
    D: D, ROAD: ROAD,
    roadPoint: roadPoint, distToRoad: distToRoad, canBuildAt: canBuildAt,
    ringMeet: ringMeet, chordLocus: chordLocus,
    newGame: newGame, placeBell: placeBell, upgradeBell: upgradeBell, upgradeCost: upgradeCost,
    sellBell: sellBell, intervene: intervene, startWave: startWave, step: step,
    rebuildBonds: rebuildBonds,
    bellReach: bellReach, bellPower: bellPower, ringSpeed: ringSpeed,
    foundryLevel: foundryLevel, foundryBonus: foundryBonus,
    bankBloom: bankBloom, buyFoundry: buyFoundry
  };
}));
