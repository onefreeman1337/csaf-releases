# CARILLON

**A tower defence whose towers never shoot.** Free, in your browser, no account, no install.

You do not place guns. You hang **bells**. Every bell sounds a ring on the metronome and the ring
spreads across the valley. **Where two rings touch, a spark is born, and the spark is the only thing
in this game that does damage.**

---

## The one rule, in full

A bell rings, and the ring expands at a fixed speed until it has travelled its rope's length and
dies. Two bells are **bonded** when each one's ring can still reach the midpoint between them —
which is simply the first place two rings can possibly touch. Wherever two live rings cross, a spark
burns, and sparks are the whole of your firepower.

There is no targeting in this game. There is no range check, no cooldown, and no projectile. Nothing
on the board has a "damage per second" stat attached to it. What you are actually building is a
**geometric figure**, and the procession dies where the figure crosses the road.

## Why placement is the whole game

Two bells that ring **together** have rings of equal size, so their crossing points sit on the
straight line halfway between them. That is the faint gold line the board draws for every bond. Hang
your bells so those lines cross the road, and the procession walks through them.

Two bells that ring **a beat apart** have rings of different sizes, so their line **bows** into a
curve instead. That is not a bug to be avoided. A bowed chord reaches places a straight one cannot,
and there is an intervention whose entire purpose is to bow one deliberately.

Sparks are born at the midpoint of a chord and race outward, slowing as they go. So the ends of a
long chord are worked harder than its middle, and a point crossed by three chords is struck three
times a beat instead of once. That is how you open a Shell.

## The second system, and the one thing that surprises people

A **Damper** carries wet felt, and every bell it walks close to slides off the beat. A bell off the
beat has its chords bow away from where you aimed them, and it wears a mark showing how far it has
gone. **Tune** pulls one back onto the metronome and every chord it owns snaps straight again.

Here is the part that is not obvious, and the game is built on it: **if every bell drifts by the same
amount, nothing bends at all.** Two bells that are both a half beat late still have equal-sized rings
and a perfectly straight chord between them. Only the **difference** between two bells matters. That
is why the felt hurts most when it catches one bell of a pair and misses the other, and it is why
tuning a single bell inside a battery that has *all* drifted can make things worse rather than better.

## The metals

| | rings | reach | character |
| --- | --- | --- | --- |
| **Bronze** | every 2 beats | middling | The founder's metal. Everything a first battery is made of. |
| **Iron** | every beat | short | Twice as many chords as bronze, all of them close to home. |
| **Silver** | every 3 beats | long | Slow, enormous, and heavy enough to open a Shell. |
| **Lead** | every 4 beats | middling | Barely hurts anything. Everything its sparks touch walks slower. |

Metals with different periods only coincide on the beats their periods share, so a bronze and a
silver bell make a straight chord once every six beats and a bowed one the rest of the time. You do
not have to plan around that. You will notice it, and then you will start planning around it.

## Your three interventions

A small number per wave, and each one visibly re-shapes the board.

- **Toll** — sound one bell right now, off the beat. Its ring meets every neighbour somewhere new.
- **Tune** — put a bell back on the metronome.
- **Shift** — push one a half beat off *on purpose*, to bow its chords where you want them.

## Losing, and what losing costs you

Walkers that reach the gate cost you resolve. At zero the siege ends. **You keep every bloom you
earned and you spend it in the foundry**, which makes every future siege easier — longer ropes,
heavier clappers, a truer beat, one more intervention. You never start from nothing twice, and the
game autosaves after every single action, so closing the tab costs you nothing at all.

## Controls

**Mouse only.** Click a metal in the panel, then click open ground to hang a bell. Click a bell to
open its card. Click an intervention, then click the bell to use it on. Keys `1`, `2` and `3` arm
the interventions, `Esc` cancels anything, and `Space` rings in the next wave.

## What it runs on

Any current browser. It is one HTML file, six small scripts, six PNGs and fourteen OGGs — about
half a megabyte in total, most of which is the art. No install, no account, no network after load.

---

**Core Systems Asset Factory** · free to play, free to stream, free to write about.
Made with AI assistance and disclosed as such on the store page; the audio is procedural synthesis
rather than a generative model, which is a distinction itch.io draws itself. Full provenance for
every file is in `CREDITS.txt`.
