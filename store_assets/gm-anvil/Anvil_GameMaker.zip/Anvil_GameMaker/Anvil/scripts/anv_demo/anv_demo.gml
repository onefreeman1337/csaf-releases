/// anv_demo.gml - the runnable demo: a stock armoury of twelve weapons (pick one, pick a difficulty, forge it), and a rack
/// of the pieces you have forged, each drawn finished exactly as you shaped it with its grade. Delete this file and the
/// demo object/room when you wire Anvil into your own crafting; nothing else depends on it.
///
/// Anvil - A Forging Minigame Drawn in Code, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function anv_demo_state()
/// @description The demo's state: the armoury, the selection, the forge in progress, the rack.
function anv_demo_state() {
    var _arm = [["Short Sword", "Sword", 10, ""], ["Mithril Sword", "Sword", 40, ""], ["Dragon Blade", "Sword", 48, "Quenched in dragon fire."], ["Knife", "Dagger", 6, ""],
        ["Mithril Dagger", "Dagger", 30, ""], ["Hand Axe", "Axe", 12, ""], ["Mithril Axe", "Axe", 44, ""], ["Short Spear", "Spear", 11, ""],
        ["Mithril Spear", "Spear", 42, ""], ["Stone Flail", "Flail", 16, "A crude club of bound stone."], ["Dark Mace", "Mace", 36, ""], ["Mithril Claw", "Claw", 38, ""]];
    var _w = [];
    for (var _i = 0; _i < array_length(_arm); _i++) array_push(_w, { name: _arm[_i][0], type: _arm[_i][1], atk: _arm[_i][2], desc: _arm[_i][3], target: anv_weapon(_arm[_i][0], _arm[_i][1], _arm[_i][2], _arm[_i][3]), preview: -1 });
    return { weapons: _w, sel: 0, diff: 1, scene: undefined, rack: [], panel: undefined, panelKey: "" };
}

/// @function anv_demo_free(demo)
function anv_demo_free(_d) {
    if (is_struct(_d.scene)) anv_scene_free(_d.scene);
    for (var _i = 0; _i < array_length(_d.weapons); _i++) if (sprite_exists(_d.weapons[_i].preview)) sprite_delete(_d.weapons[_i].preview);
    for (var _j = 0; _j < array_length(_d.rack); _j++) if (sprite_exists(_d.rack[_j].sprite)) sprite_delete(_d.rack[_j].sprite);
    if (!is_undefined(_d.panel) && surface_exists(_d.panel)) surface_free(_d.panel);
    anv_cache_free();
}

/// @function anv_demo_step(demo)
function anv_demo_step(_d) {
    if (is_struct(_d.scene)) {
        anv_scene_step(_d.scene);
        if (anv_scene_done(_d.scene)) {
            var _r = anv_scene_result(_d.scene), _w = _d.weapons[_d.sel];
            if (is_struct(_r)) {
                array_insert(_d.rack, 0, { name: _w.name, grade: _r.gradeName, quality: _r.quality, sprite: anv_blade_sprite(_w.target, _d.scene.forge, 300, 96) });
                if (array_length(_d.rack) > 4) { if (sprite_exists(_d.rack[4].sprite)) sprite_delete(_d.rack[4].sprite); array_delete(_d.rack, 4, 1); }
            }
            anv_scene_free(_d.scene);
            _d.scene = undefined;
        }
        return;
    }
    var _n = array_length(_d.weapons);
    if (keyboard_check_pressed(vk_up)) _d.sel = (_d.sel + _n - 1) mod _n;
    if (keyboard_check_pressed(vk_down)) _d.sel = (_d.sel + 1) mod _n;
    if (keyboard_check_pressed(vk_left)) _d.diff = max(0, _d.diff - 1);
    if (keyboard_check_pressed(vk_right)) _d.diff = min(2, _d.diff + 1);
    var _mx = device_mouse_x_to_gui(0), _my = device_mouse_y_to_gui(0), _L = anv_demo_layout();
    var _row = floor((_my - _L.listY) / _L.rowH);
    if (mouse_check_button_pressed(mb_left) && _mx >= _L.listX && _mx < _L.listX + _L.listW && _row >= 0 && _row < _n) _d.sel = _row;
    if (keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space) || (mouse_check_button_pressed(mb_left) && _mx > _L.goX && _mx < _L.goX + 300 && _my > _L.goY && _my < _L.goY + 56)) {
        var _diffs = ["easy", "normal", "hard"], _sw = _d.weapons[_d.sel];
        _d.scene = anv_scene_create(_sw.target, { difficulty: _diffs[_d.diff], title: _sw.name, min_quality: 65, give: true });
    }
}

/// @function anv_demo_layout()
function anv_demo_layout() {
    var _W = display_get_gui_width(), _H = display_get_gui_height();
    return { W: _W, H: _H, listX: 56, listY: 150, listW: 330, rowH: 40, goX: _W - 380, goY: 430 };
}

/// @function anv_demo_draw(demo)
function anv_demo_draw(_d) {
    var _L = anv_demo_layout();
    if (is_struct(_d.scene)) { draw_clear(c_black); anv_scene_draw(_d.scene, 0, 0, _L.W, _L.H); return; }
    var _K = anv_cache_build(2);
    // the smithy behind the menu, dimmed
    gpu_push_state();
    gpu_set_texfilter(true);
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    var _k = max(_L.W / 816, _L.H / 624);
    draw_sprite_ext(_K.board, 0, (_L.W - 816 * _k) / 2, (_L.H - 624 * _k) / 2, _k / 2, _k / 2, 0, c_white, 1);
    gpu_set_blendmode(bm_normal);
    draw_set_alpha(0.62); draw_set_colour(c_black); draw_rectangle(0, 0, _L.W, _L.H, false); draw_set_alpha(1);
    gpu_pop_state();
    var _cream = make_colour_rgb(241, 223, 180), _dim = make_colour_rgb(184, 164, 138), _gold = make_colour_rgb(232, 184, 80);
    anv_text(56, 44, "ANVIL", 64, _cream, fa_left, fa_top, fnt_anvil_display);
    anv_text(60, 112, "Choose a weapon and forge it. Every weapon forges to its own pattern.", 22, _dim, fa_left, fa_top, fnt_anvil_italic);
    // the armoury list
    for (var _i = 0; _i < array_length(_d.weapons); _i++) {
        var _y = _L.listY + _i * _L.rowH, _w = _d.weapons[_i], _on = (_i == _d.sel);
        if (_on) { draw_set_alpha(0.35); draw_set_colour(_gold); draw_rectangle(_L.listX - 10, _y, _L.listX + _L.listW, _y + _L.rowH - 4, false); draw_set_alpha(1); }
        anv_text(_L.listX, _y + _L.rowH / 2 - 2, _w.name, 24, _on ? _cream : _dim, fa_left, fa_middle, fnt_anvil_bold);
        anv_text(_L.listX + _L.listW - 6, _y + _L.rowH / 2 - 2, _w.target.family, 20, _dim, fa_right, fa_middle, fnt_anvil_italic);
    }
    // the selected weapon's pattern, as the perfect piece it could be
    var _sw = _d.weapons[_d.sel];
    if (!sprite_exists(_sw.preview)) _sw.preview = anv_blade_sprite(_sw.target, undefined, 640, 200);
    var _px = (_L.listX + _L.listW + _L.W) / 2;
    anv_text(_px, 160, _sw.name, 40, _cream, fa_center, fa_top, fnt_anvil_bold);
    anv_text(_px, 206, ((string_pos(string_char_at(_sw.target.family, 1), "aeiou") > 0) ? "an " : "a ") + _sw.target.family + ", in " + _sw.target.metal + " - the pattern to forge toward", 22, _dim, fa_center, fa_top, fnt_anvil_italic);
    anv_draw_pm(_sw.preview, _px, 340);
    var _diffs = ["easy", "normal", "hard"];
    anv_text(_px, _L.goY - 30, "<  difficulty: " + _diffs[_d.diff] + "  >", 22, _dim, fa_center, fa_middle, fnt_anvil_italic);
    draw_set_colour(_gold); draw_roundrect(_L.goX, _L.goY, _L.goX + 300, _L.goY + 56, false);
    anv_text(_L.goX + 150, _L.goY + 28, "Forge it", 30, make_colour_rgb(58, 36, 8), fa_center, fa_middle, fnt_anvil_bold);
    draw_set_colour(c_white);
    // the rack of finished pieces
    anv_text(_px, 520, (array_length(_d.rack) > 0) ? "Your forged pieces" : "Your forged pieces will hang here.", 22, _dim, fa_center, fa_middle, fnt_anvil_italic);
    for (var _r = 0; _r < array_length(_d.rack); _r++) {
        var _e = _d.rack[_r], _rx = _L.listX + _L.listW + 60 + (_r mod 2) * 400, _ry = 570 + floor(_r / 2) * 76;
        anv_draw_pm(_e.sprite, _rx + 120, _ry, 0.8, 0.8);
        anv_text(_rx + 250, _ry - 12, _e.name, 20, _cream, fa_left, fa_middle, fnt_anvil_bold);
        anv_text(_rx + 250, _ry + 14, _e.grade + " - " + string(_e.quality), 20, _gold, fa_left, fa_middle, fnt_anvil_italic);
    }
    anv_text(56, _L.H - 30, "Up/Down choose - Left/Right difficulty - Enter forges. In the forge: Left/Right move, Enter strikes, Shift reheats, Q quenches, Esc leaves.", 18, _dim, fa_left, fa_middle, fnt_anvil_italic);
}
