{
  "$GMScript": "v1",
  "%Name": "anv_forge",
  "name": "anv_forge",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}