/// anv_forge.gml - the forging model: a PATTERN generated from a weapon (the half-width profile the blade should take),
/// the hot metal (shaped by each hammer blow, cooling while you work, cracking when struck too cold, reheated a limited
/// number of times), the QUENCH (the colour at that moment decides it) and the SCORE. Pure logic: nothing here draws,
/// nothing reads input, nothing uses random().
///
/// Anvil - A Forging Minigame Drawn in Code, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⛔ THIS FILE IS A PORT HELD TO ITS ORIGINAL (the published RPG Maker MZ Anvil, AnvilCore.js 1.0.0). The in-engine suite
/// checks it against values the original computed (anv_oracle.gml):
///   - every random draw is taken in its own statement, in JavaScript's left-to-right order (GML evaluates one
///     expression's calls right to left), and draws the original takes only on one side of a condition stay there;
///   - 32-bit arithmetic goes through anv_mul32; JavaScript's Math.round is floor(x + 0.5) (anv_jsround);
///   - every entry point runs with the comparison epsilon at ZERO and restores the caller's (GML's default 0.00001
///     flips a boundary the original decides exactly).
///
/// THE TARGET. Every weapon becomes a silhouette to forge toward: the family (sword, dagger, axe, spear, mace, claw) is
/// read from the weapon type's name first and the weapon's own name second, the metal from its name and description,
/// and the seed, name and attack pick its proportions (blade width, taper, point, ricasso, tang, beard, flanges).
/// THE METAL. A blow moves hot metal a fixed step toward the pattern, more at white heat, finer when cooler; struck where
/// it is already right it overshoots. Below ANV_COLD a blow cracks the bar instead. The hearth reheats it a limited
/// number of times. Quenching fixes the result, and the colour at that moment decides it (cherry is true).

#macro ANV_N 64
#macro ANV_STOCK 0.34
#macro ANV_COLD 0.22
#macro ANV_R 3
#macro ANV_MARKS_MAX 240

/// @function anv_families()
/// @description The six forging families, in the original's order. Pure.
function anv_families() { return ["sword", "dagger", "axe", "spear", "mace", "claw"]; }

/// @function anv_metals()
/// @description The five metals, in the original's order. Pure.
function anv_metals() { return ["steel", "iron", "bronze", "mithril", "blacksteel"]; }

/// @function anv_difficulty(name)
/// @description {heats, cool} for "easy", "normal" or "hard" (anything else reads as "normal"). Tuned in the original
/// against a balance probe of a skilled smith who keeps the last heat for the quench. Pure.
function anv_difficulty(_d) {
    if (_d == "easy") return { name: "easy", heats: 6, cool: 1 / 900 };
    if (_d == "hard") return { name: "hard", heats: 4, cool: 1 / 560 };
    return { name: "normal", heats: 5, cool: 1 / 720 };
}

/// @function anv_bands()
/// @description The smith's colour chart: [heat floor, name] from black to white. Pure.
function anv_bands() {
    return [[0, "black"], [0.2, "faint red"], [0.32, "blood red"], [0.42, "cherry"], [0.56, "bright cherry"], [0.66, "orange"], [0.78, "yellow"], [0.9, "white"]];
}

/// @function anv_quench_band()
/// @description [low, high]: cherry to bright cherry, the colour to quench at. Pure.
function anv_quench_band() { return [0.42, 0.66]; }

/// @function anv_grades()
/// @description [quality floor, name] for the four grades (1 Crude, 2 Serviceable, 3 Fine, 4 Masterwork). Pure.
function anv_grades() { return [[0, "Crude"], [40, "Serviceable"], [65, "Fine"], [85, "Masterwork"]]; }

// ---------------------------------------------------------------------------------------------------------------
// The original's generator (mulberry32), bit for bit
// ---------------------------------------------------------------------------------------------------------------

/// @function anv_rng(seed)
/// @description A generator struct seeded with a 32-bit number; draw with anv_rnd(). Pure.
function anv_rng(_seed) { return { a: anv_u32(_seed) }; }

/// @function anv_rnd(rng)
/// @description The next draw in [0, 1) - mulberry32, exactly as the original computes it. Advances the generator.
function anv_rnd(_g) {
    _g.a = (_g.a + $6D2B79F5) & $FFFFFFFF;
    var _t = _g.a;
    _t = anv_mul32(_t ^ (_t >> 15), _t | 1);
    var _s = (_t + anv_mul32(_t ^ (_t >> 7), _t | 61)) & $FFFFFFFF;
    _t = (_t ^ _s) & $FFFFFFFF;
    return ((_t ^ (_t >> 14)) & $FFFFFFFF) / 4294967296;
}

/// @function anv_pick(rng, array)
/// @description One element of an array by one draw (the original's pick). Advances the generator.
function anv_pick(_g, _a) {
    var _n = array_length(_a);
    var _k = floor(anv_rnd(_g) * _n) mod _n;
    return _a[_k];
}

/// @function anv__has_any(text, words)
/// @description True when the lower-case text contains any of the words (the original's case-insensitive regex
/// alternations are plain substrings, no word boundaries). Internal.
function anv__has_any(_s, _words) {
    for (var _i = 0; _i < array_length(_words); _i++) if (string_pos(_words[_i], _s) > 0) return true;
    return false;
}

/// @function anv_family_of(type_name, name)
/// @description The family a weapon forges as, read from its weapon-type name first and its own name second: dagger,
/// axe, spear, mace (a rod with a worked head: maces, flails, hammers, staves, wands), claw, else sword. Pure.
function anv_family_of(_type, _name) {
    var _s = string_lower(string(is_undefined(_type) ? "" : _type) + " " + string(is_undefined(_name) ? "" : _name));
    if (anv__has_any(_s, ["dagger", "knife", "dirk", "stiletto", "kunai", "tanto"])) return "dagger";
    if (anv__has_any(_s, ["axe", "hatchet", "halberd", "cleaver"])) return "axe";
    if (anv__has_any(_s, ["spear", "lance", "pike", "glaive", "trident", "javelin", "naginata"])) return "spear";
    if (anv__has_any(_s, ["mace", "flail", "hammer", "club", "maul", "morningstar", "morning star", "staff", "rod", "wand", "sceptre", "scepter"])) return "mace";
    if (anv__has_any(_s, ["claw", "talon", "katar", "glove", "knuckle"])) return "claw";
    return "sword";
}

/// @function anv_metal_of(name, description)
/// @description The metal a weapon is worked in, read from its name and description: mithril (mithril, silver, elven,
/// moon), bronze (bronze, brass, copper), blacksteel (dark, black, obsidian, shadow, demon), iron (iron, rusty, crude,
/// old), else steel. Pure.
function anv_metal_of(_name, _desc) {
    var _s = string_lower(string(is_undefined(_name) ? "" : _name) + " " + string(is_undefined(_desc) ? "" : _desc));
    if (anv__has_any(_s, ["mithril", "silver", "elven", "moon"])) return "mithril";
    if (anv__has_any(_s, ["bronze", "brass", "copper"])) return "bronze";
    if (anv__has_any(_s, ["dark", "black", "obsidian", "shadow", "demon"])) return "blacksteel";
    if (anv__has_any(_s, ["iron", "rusty", "crude", "old"])) return "iron";
    return "steel";
}

/// @function anv__index_of(array, value)
/// @description The index of a value in an array, or -1. Internal.
function anv__index_of(_a, _v) {
    for (var _i = 0; _i < array_length(_a); _i++) if (_a[_i] == _v) return _i;
    return -1;
}

/// @function anv_target(spec)
/// @description A forging target from a spec struct {seed, [family], [atk], [metal], [name]}: the half-width profile
/// the blade should take (ANV_N samples, tang end first, 0.06..0.95) and what the drawing needs (`meta`: family,
/// point, fuller, beard, flanges, tang, eye). The same spec gives the same target forever. A missing or unknown family
/// is drawn from the seed; a missing attack reads as 10. Pure.
function anv_target(_spec) {
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    if (!is_struct(_spec)) _spec = {};
    var _seed = anv_u32(variable_struct_exists(_spec, "seed") && is_numeric(_spec.seed) ? _spec.seed : 0);
    var _r = anv_rng(_seed ^ $A7F1);
    var _fams = anv_families();
    var _famIn = variable_struct_exists(_spec, "family") ? _spec.family : undefined;
    var _fam = (is_string(_famIn) && anv__index_of(_fams, _famIn) >= 0) ? _famIn : anv_pick(_r, _fams);
    var _atkIn = variable_struct_exists(_spec, "atk") && is_numeric(_spec.atk) ? _spec.atk : 0;
    var _atk = clamp((_atkIn != 0) ? _atkIn : 10, 1, 200);
    var _heft = clamp(_atk / 60, 0.1, 1);
    var _w = array_create(ANV_N, 0), _i;
    var _meta = { family: _fam, point: "spear", fuller: false, beard: 0, flanges: 0, tang: 0.18, eye: 0 };
    var _tang = 0.14 + anv_rnd(_r) * 0.08;
    var _tangW = 0.14 + anv_rnd(_r) * 0.06;
    if (_fam == "sword" || _fam == "dagger" || _fam == "claw") {
        if (_fam == "dagger") _tang = 0.26 + anv_rnd(_r) * 0.08;
        if (_fam == "claw") _tang = 0.34 + anv_rnd(_r) * 0.06;
        var _base = 0.48 + _heft * 0.22 + anv_rnd(_r) * 0.18 - ((_fam == "claw") ? 0.08 : 0);
        var _taper = 0.15 + anv_rnd(_r) * 0.45;
        var _pt = 0.1 + anv_rnd(_r) * 0.14;
        var _ric = 0;
        if (anv_rnd(_r) < 0.4) _ric = 0.04 + anv_rnd(_r) * 0.05;
        _meta.point = (_fam == "claw") ? "hook" : anv_pick(_r, ["spear", "spear", "clip", "round", "leaf"]);
        _meta.fuller = (_fam == "sword") ? (anv_rnd(_r) < 0.7) : false;
        _meta.tang = _tang;
        for (_i = 0; _i < ANV_N; _i++) {
            var _x = _i / (ANV_N - 1), _v;
            if (_x < _tang) _v = _tangW;
            else {
                var _u = (_x - _tang) / (1 - _tang);
                _v = (_u < _ric) ? _base * 0.92 : _base * (1 - _taper * _u);
                if (_meta.point == "leaf") _v *= 0.86 + 0.28 * sin(pi * min(1, _u * 1.2));
                var _pu = (_u - (1 - _pt)) / _pt;
                if (_pu > 0) {
                    if (_meta.point == "round") _v *= sqrt(max(0, 1 - _pu * _pu));
                    else if (_meta.point == "clip") _v *= (_pu < 0.5) ? 1 - _pu * 0.5 : max(0, 1.5 - _pu * 1.5) * 1;
                    else if (_meta.point == "hook") _v *= max(0, 1 - power(_pu, 0.7));
                    else _v *= max(0, 1 - _pu);
                }
            }
            _w[_i] = _v;
        }
    } else if (_fam == "axe") {
        // the bar is the HEAD, poll to bit; the haft crosses it at the eye (found by looking in the original: a wedge
        // continuing its haft read as a chisel)
        var _poll = 0.1 + anv_rnd(_r) * 0.08;
        var _eyeW = 0.26 + anv_rnd(_r) * 0.06;
        var _cheek = 0.16 + anv_rnd(_r) * 0.06;
        var _bit = 0.7 + _heft * 0.16 + anv_rnd(_r) * 0.1;
        var _k = 1.1 + anv_rnd(_r) * 1.4;
        var _e0 = _poll, _e1 = _poll + 0.16;
        var _c1 = _e1 + 0.1 + anv_rnd(_r) * 0.08;
        _meta.eye = (_e0 + _e1) / 2; _meta.tang = 0; _meta.point = "bit";
        _meta.beard = (anv_rnd(_r) < 0.5) ? 1 : 0;
        for (_i = 0; _i < ANV_N; _i++) {
            var _xa = _i / (ANV_N - 1);
            _w[_i] = (_xa < _e0) ? _eyeW * 0.9 : ((_xa < _e1) ? _eyeW : ((_xa < _c1) ? _cheek : _cheek + (_bit - _cheek) * power((_xa - _c1) / (1 - _c1), 1 / _k)));
        }
    } else if (_fam == "spear") {
        var _sock = 0.38 + anv_rnd(_r) * 0.1;
        var _hw = 0.5 + _heft * 0.18 + anv_rnd(_r) * 0.16;
        var _q = 0.6 + anv_rnd(_r) * 0.9;
        _meta.tang = _sock; _meta.point = "leaf";
        for (_i = 0; _i < ANV_N; _i++) {
            var _xs = _i / (ANV_N - 1);
            if (_xs < _sock) _w[_i] = _tangW * 1.2;
            else {
                var _us = (_xs - _sock) / (1 - _sock);
                _w[_i] = max(_tangW * 0.6, _hw * power(sin(pi * min(0.999, _us * 0.92 + 0.04)), _q) * (1 - _us * 0.25));
            }
        }
    } else {
        // mace: a haft, then a head with flanges
        var _neck = 0.5 + anv_rnd(_r) * 0.1;
        var _head = 0.7 + _heft * 0.14 + anv_rnd(_r) * 0.1;
        var _fl = 3 + floor(anv_rnd(_r) * 4);
        _meta.flanges = _fl; _meta.tang = _neck; _meta.point = "head";
        for (_i = 0; _i < ANV_N; _i++) {
            var _xm = _i / (ANV_N - 1);
            if (_xm < _neck) _w[_i] = _tangW * 1.1;
            else {
                var _um = (_xm - _neck) / (1 - _neck);
                _w[_i] = _head * (0.62 + 0.38 * power(abs(sin(pi * _fl * _um)), 0.5)) * ((_um > 0.92) ? 0.8 : 1);
            }
        }
    }
    for (_i = 0; _i < ANV_N; _i++) _w[_i] = clamp(anv_jsround(_w[_i] * 1000) / 1000, 0.06, 0.95);
    var _metalIn = variable_struct_exists(_spec, "metal") ? _spec.metal : undefined;
    var _metal = (is_string(_metalIn) && anv__index_of(anv_metals(), _metalIn) >= 0) ? _metalIn : "steel";
    var _nm = variable_struct_exists(_spec, "name") && !is_undefined(_spec.name) ? string(_spec.name) : "";
    math_set_epsilon(_eps);
    return { v: 1, seed: _seed, family: _fam, metal: _metal, name: _nm, profile: _w, meta: _meta };
}

/// @function anv__is_target(t)
/// @description True for a target struct this package made (a profile of ANV_N numbers and a meta). Internal.
function anv__is_target(_t) {
    return is_struct(_t) && variable_struct_exists(_t, "profile") && is_array(_t.profile) && array_length(_t.profile) == ANV_N && variable_struct_exists(_t, "seed") && is_numeric(_t.seed) && variable_struct_exists(_t, "meta") && is_struct(_t.meta);
}

/// @function anv__is_forge(f)
/// @description True for a forge struct this package made. Internal.
function anv__is_forge(_f) {
    return is_struct(_f) && variable_struct_exists(_f, "work") && is_array(_f.work) && array_length(_f.work) == ANV_N && variable_struct_exists(_f, "heat") && is_numeric(_f.heat) && variable_struct_exists(_f, "quenched");
}

/// @function anv_new_forge(target, difficulty)
/// @description A fresh forge: the bar of stock at white heat, nothing struck. `difficulty` is "easy", "normal" or
/// "hard". Pure.
function anv_new_forge(_t, _difficulty) {
    var _d = anv_difficulty(_difficulty);
    return { v: 1, difficulty: _d.name, maxHeats: _d.heats, cool: _d.cool, heat: 1, heats: 1, strikes: 0,
        work: array_create(ANV_N, ANV_STOCK), marks: [], flaws: [], quenched: false, quench: undefined };
}

/// @function anv_strike(target, forge, pos)
/// @description One hammer blow at sample `pos` (0..ANV_N-1). Hot metal moves a fixed step toward the target, most
/// under the hammer face's centre (it covers 2 x ANV_R + 1 samples); metal below ANV_COLD does not move and CRACKS.
/// Every blow costs heat. Returns {moved, cracked}, or undefined once the piece is quenched.
function anv_strike(_t, _f, _pos) {
    if (!anv__is_target(_t) || !anv__is_forge(_f)) return undefined;
    if (_f.quenched) return undefined;
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    _pos = clamp(anv_jsround(is_numeric(_pos) ? _pos : 0), 0, ANV_N - 1);
    var _r = anv_rng(((_t.seed ^ $5171) + _f.strikes * 7919) & $FFFFFFFF);
    var _out = { moved: 0, cracked: false };
    _f.strikes++;
    if (_f.heat < ANV_COLD) {
        array_push(_f.flaws, _pos);
        _out.cracked = true;
        _f.heat = max(0, _f.heat - 0.02);
        math_set_epsilon(_eps);
        return _out;
    }
    // a blow moves the metal a fixed STEP toward the pattern, set by the heat: white heat roughs it out, a cooler bar
    // takes finer work; struck where it is already right, it overshoots. Skill is choosing where, and at what heat.
    var _eff = clamp((_f.heat - ANV_COLD) / 0.5, 0, 1);
    var _step = 0.012 + 0.07 * _eff;
    var _work = _f.work;
    for (var _i = max(0, _pos - ANV_R); _i <= min(ANV_N - 1, _pos + ANV_R); _i++) {
        var _fall = power(1 - abs(_i - _pos) / (ANV_R + 1), 1.2);
        var _before = _work[_i], _e = _t.profile[_i] - _work[_i];
        var _jit = (anv_rnd(_r) - 0.5) * 0.012 * (1 - _eff);
        // `work += A + B` in the original adds the SUM: (work + A) + B rounds differently
        var _nv = _work[_i] + (((_e >= 0) ? 1 : -1) * _step * _fall + _jit);
        _nv = clamp(_nv, 0.04, 0.98);
        _work[_i] = _nv;
        _out.moved += abs(_nv - _before);
    }
    _f.work = _work;
    if (array_length(_f.marks) < ANV_MARKS_MAX) array_push(_f.marks, { p: _pos, h: anv_jsround(_f.heat * 100) / 100 });
    _f.heat = max(0, _f.heat - 0.03);
    math_set_epsilon(_eps);
    return _out;
}

/// @function anv_cool(forge, frames)
/// @description Let the metal cool for `frames` frames (1 if not given). Returns the heat. Nothing happens once quenched.
function anv_cool(_f, _frames = 1) {
    if (!anv__is_forge(_f)) return 0;
    if (!_f.quenched) {
        var _k = (is_numeric(_frames) && _frames != 0) ? _frames : 1;
        _f.heat = max(0, _f.heat - _f.cool * _k);
    }
    return _f.heat;
}

/// @function anv_reheat(forge)
/// @description Back into the hearth: full heat, one more heat used. Refused (false) once the heats allowed are spent
/// or the piece is quenched.
function anv_reheat(_f) {
    if (!anv__is_forge(_f)) return false;
    if (_f.quenched || _f.heats >= _f.maxHeats) return false;
    _f.heats++;
    _f.heat = 1;
    return true;
}

/// @function anv_heat_name(heat)
/// @description The smith's name for a heat, from the colour chart ("black" .. "white"). Pure.
function anv_heat_name(_h) {
    if (!is_numeric(_h)) _h = 0;
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _b = anv_bands(), _n = _b[0][1];
    for (var _i = 0; _i < array_length(_b); _i++) if (_h >= _b[_i][0]) _n = _b[_i][1];
    math_set_epsilon(_eps);
    return _n;
}

/// @function anv_quench(forge)
/// @description Quench now, at whatever colour the metal is. Returns {heat, colour, score 0..1, note}: "true" in the
/// cherry band, "hot" or "warped" above it, "cool" or "soft" below. A second call returns the same verdict.
function anv_quench(_f) {
    if (!anv__is_forge(_f)) return undefined;
    if (_f.quenched) return _f.quench;
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _h = _f.heat, _q, _note, _band = anv_quench_band();
    if (_h >= _band[0] && _h <= _band[1]) { _q = 1; _note = "true"; }
    else if (_h > _band[1]) { _q = clamp(1 - (_h - _band[1]) * 2.4, 0.2, 1); _note = (_h > 0.82) ? "warped" : "hot"; }
    else { _q = clamp(1 - (_band[0] - _h) * 2.6, 0.3, 1); _note = (_h < 0.3) ? "soft" : "cool"; }
    _f.quenched = true;
    _f.quench = { heat: anv_jsround(_h * 100) / 100, colour: anv_heat_name(_h), score: anv_jsround(_q * 100) / 100, note: _note };
    math_set_epsilon(_eps);
    return _f.quench;
}

/// @function anv_shape(target, forge)
/// @description How close the work is to the target, 0..1 (1 = exact): one minus the summed error over the summed
/// profile, at a slope of 1.4 (the original measured that 2.2 clamped every raw bar to 0 and gave no feedback). Pure.
function anv_shape(_t, _f) {
    if (!anv__is_target(_t) || !anv__is_forge(_f)) return 0;
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _e = 0, _s = 0;
    for (var _i = 0; _i < ANV_N; _i++) { _e += abs(_f.work[_i] - _t.profile[_i]); _s += _t.profile[_i]; }
    var _out = clamp(1 - (_e / _s) * 1.4, 0, 1);
    math_set_epsilon(_eps);
    return _out;
}

/// @function anv_score(target, forge)
/// @description The forge's verdict: quality 0..100 from the shape (60%), the quench (25%) and the heats used (15%),
/// less 8 per crack, and the grade (1 Crude, 2 Serviceable, 3 Fine, 4 Masterwork). Returns {quality, grade, gradeName,
/// shape, quench, heats, strikes, flaws}. Pure.
function anv_score(_t, _f) {
    if (!anv__is_target(_t) || !anv__is_forge(_f)) return undefined;
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _sh = anv_shape(_t, _f);
    math_set_epsilon(0);
    var _qn = is_struct(_f.quench) ? _f.quench.score : 0;
    var _eff = clamp(1 - (_f.heats - 1) / max(1, _f.maxHeats) * 0.5, 0, 1);
    var _q = clamp(anv_jsround(100 * (0.6 * _sh + 0.25 * _qn + 0.15 * _eff) - 8 * array_length(_f.flaws)), 0, 100), _g = 1;
    var _gr = anv_grades();
    for (var _i = 0; _i < array_length(_gr); _i++) if (_q >= _gr[_i][0]) _g = _i + 1;
    math_set_epsilon(_eps);
    return { quality: _q, grade: _g, gradeName: _gr[_g - 1][1], shape: anv_jsround(_sh * 100), quench: anv_jsround(_qn * 100),
        heats: _f.heats, strikes: _f.strikes, flaws: array_length(_f.flaws) };
}

/// @function anv_worst(target, forge)
/// @description The sample the bar most needs struck next (the largest error under a hammer face), for hints. Pure.
function anv_worst(_t, _f) {
    if (!anv__is_target(_t) || !anv__is_forge(_f)) return 0;
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _b = 0, _bi = 0;
    for (var _i = 0; _i < ANV_N; _i++) {
        var _e = 0;
        for (var _j = max(0, _i - ANV_R); _j <= min(ANV_N - 1, _i + ANV_R); _j++) _e += abs(_t.profile[_j] - _f.work[_j]) * (1 - abs(_j - _i) / (ANV_R + 1));
        if (_e > _b) { _b = _e; _bi = _i; }
    }
    math_set_epsilon(_eps);
    return _bi;
}
