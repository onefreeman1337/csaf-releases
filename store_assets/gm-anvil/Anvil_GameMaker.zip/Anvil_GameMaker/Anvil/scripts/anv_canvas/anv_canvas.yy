{
  "$GMScript": "v1",
  "%Name": "anv_canvas",
  "name": "anv_canvas",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}