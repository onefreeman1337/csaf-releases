/// anv_bake.gml - the bakes: every Anvil picture is drawn ONCE into a surface (supersampled, premultiplied alpha) and
/// then drawn scaled every frame. The smithy and the small sprites (hammer, spark, steam, pointer) are baked once per
/// game and cached; a forge bakes its chalked pattern once and its bar on every blow; the cards when what they show
/// changes. Also the finished-blade sprite a buyer keeps (anv_blade_sprite).
///
/// Anvil - A Forging Minigame Drawn in Code, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⛔ Four GameMaker facts decide this file (Doctrine_Craft s13-s19, all MEASURED in sibling products):
///   1. a translucent mark drawn onto a surface lowers its ALPHA under the default blend, so every bake blends alpha as
///      "over" (src + dest x (1 - src)); a surface baked that way holds PREMULTIPLIED colour and is drawn out with
///      bm_one, bm_inv_src_alpha;
///   2. a bake inside the buyer's draw inherits their world matrix: every bake runs under IDENTITY and hands the
///      caller's matrix back;
///   3. surface_set_target resets the scissor; nothing here leaves a scissor set;
///   4. surfaces are VOLATILE (lost on a window resize or a device reset): every surface is checked each frame and
///      re-baked from the model, which is the source of truth.

#macro ANV_SS 2

/// @function anv__bake_begin(surface)
/// @description Make a surface the target, cleared to transparent, under identity, blending alpha as "over". Returns the
/// caller's world matrix (hand it to anv__bake_end). Internal.
function anv__bake_begin(_sf) {
    var _m = matrix_get(matrix_world);
    surface_set_target(_sf);
    draw_clear_alpha(c_black, 0);
    gpu_push_state();
    matrix_set(matrix_world, matrix_build_identity());
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false);
    gpu_set_alphatestenable(false);
    return _m;
}

/// @function anv__bake_end(matrix)
/// @description Undo anv__bake_begin. Internal.
function anv__bake_end(_m) {
    gpu_pop_state();
    surface_reset_target();
    matrix_set(matrix_world, _m);
}

/// @function anv__surface(old, w, h)
/// @description A surface of exactly w x h: the old one if it still exists at that size, else a new one (the old freed).
/// Internal.
function anv__surface(_old, _w, _h) {
    _w = max(1, ceil(_w)); _h = max(1, ceil(_h));
    if (!is_undefined(_old) && surface_exists(_old)) {
        if (surface_get_width(_old) == _w && surface_get_height(_old) == _h) return _old;
        surface_free(_old);
    }
    return surface_create(_w, _h);
}

/// @function anv__cache()
/// @description The shared sprite cache (one per game): {ss, board, chart, hammer, spark, puff, pointer}. Internal.
function anv__cache() {
    if (!variable_global_exists("__anv_cache") || !is_struct(global.__anv_cache)) global.__anv_cache = { ss: 0, board: -1, chart: undefined, hammer: -1, spark: -1, puff: -1, pointer: -1 };
    return global.__anv_cache;
}

/// @function anv__sprite_bake(w, h, ss, painter, [xorig], [yorig])
/// @description Bake a design-space w x h picture at scale ss into a new sprite via painter(ctx). Internal.
function anv__sprite_bake(_w, _h, _ss, _painter, _xo = 0, _yo = 0) {
    var _sf = surface_create(max(1, ceil(_w * _ss)), max(1, ceil(_h * _ss)));
    var _m = anv__bake_begin(_sf);
    var _c = anv_cx_create(_ss);
    _painter(_c);
    anv__bake_end(_m);
    var _spr = sprite_create_from_surface(_sf, 0, 0, surface_get_width(_sf), surface_get_height(_sf), false, false, _xo * _ss, _yo * _ss);
    surface_free(_sf);
    return _spr;
}

/// @function anv_cache_build([ss])
/// @description Bake the shared pictures (the smithy with its anvil and colour chart, the hammer, spark, steam and the
/// chart pointer) at internal scale ss (default 2). Called for you by the first forge; call it on a loading screen to
/// move the cost there (MEASURED in the suite - see the Readme). Returns the cache.
function anv_cache_build(_ss = ANV_SS) {
    _ss = (is_numeric(_ss) && _ss >= 1 && _ss <= 3) ? round(_ss) : ANV_SS;
    var _k = anv__cache();
    if (_k.ss == _ss && sprite_exists(_k.board) && sprite_exists(_k.hammer) && sprite_exists(_k.spark) && sprite_exists(_k.puff) && sprite_exists(_k.pointer)) return _k;
    anv_cache_free();
    _k = anv__cache();
    _k.ss = _ss;
    _k.board = anv__sprite_bake(816, 624, _ss, function(_c) {
        anv_draw_smithy(_c, 816, 624);
        anv_draw_anvil(_c);
        global.__anv_chart = anv_draw_temper_chart(_c, 250, 18, 316, 44);
    });
    _k.chart = global.__anv_chart;
    _k.hammer = anv__sprite_bake(140, 150, _ss, function(_c) { anv_draw_hammer(_c, 140, 150); }, 70, 63);
    _k.spark = anv__sprite_bake(12, 4, _ss, function(_c) { anv_draw_spark(_c); }, 12, 2);
    _k.puff = anv__sprite_bake(48, 48, _ss, function(_c) { anv_draw_puff(_c); }, 24, 24);
    _k.pointer = anv__sprite_bake(20, 22, _ss, function(_c) { anv_draw_pointer(_c); }, 0, 0);
    return _k;
}

/// @function anv_cache_free()
/// @description Free the shared pictures (they are rebuilt on demand).
function anv_cache_free() {
    var _k = anv__cache();
    if (sprite_exists(_k.board)) sprite_delete(_k.board);
    if (sprite_exists(_k.hammer)) sprite_delete(_k.hammer);
    if (sprite_exists(_k.spark)) sprite_delete(_k.spark);
    if (sprite_exists(_k.puff)) sprite_delete(_k.puff);
    if (sprite_exists(_k.pointer)) sprite_delete(_k.pointer);
    global.__anv_cache = { ss: 0, board: -1, chart: undefined, hammer: -1, spark: -1, puff: -1, pointer: -1 };
}

/// @function anv_region()
/// @description The design-space rectangle the bar's pictures cover {x, y, w, h} (the bar, its halo and the chalk). Pure.
function anv_region() { return { x: 180, y: 244, w: 512, h: 170 }; }

/// @function anv_bake_work(surface, forge, target, ss)
/// @description Bake the workpiece (white, shaded, clipped, outlined) for the forge's current shape into a region-sized
/// surface (created or reused; returned). Once per blow, never per frame.
function anv_bake_work(_sf, _f, _t, _ss) {
    var _R = anv_region();
    _sf = anv__surface(_sf, _R.w * _ss, _R.h * _ss);
    var _m = anv__bake_begin(_sf);
    var _c = anv_cx_create(_ss);
    anv_cx_translate(_c, -_R.x, -_R.y);
    anv_draw_work(_c, _f.work, _f.marks, _f.flaws, _t.seed, _f.strikes);
    anv__bake_end(_m);
    return _sf;
}

/// @function anv_bake_chalk(surface, target, ss)
/// @description Bake the chalked pattern (dashed) into a region-sized surface (created or reused; returned).
function anv_bake_chalk(_sf, _t, _ss) {
    var _R = anv_region();
    _sf = anv__surface(_sf, _R.w * _ss, _R.h * _ss);
    var _m = anv__bake_begin(_sf);
    var _c = anv_cx_create(_ss);
    anv_cx_translate(_c, -_R.x, -_R.y);
    anv_draw_target(_c, _t.profile);
    anv__bake_end(_m);
    return _sf;
}

/// @function anv_bake_glow(surface, forge, ss)
/// @description Bake the halo round the bar into a region-sized surface: the original's path, fill and stroke drawn at
/// a QUARTER of design scale, blurred there by a separable 9-tap gaussian (each tap one offset copy, summed additively -
/// premultiplied, so the weights add exactly), then magnified back with bilinear filtering. The original's CSS
/// blur(12px) has no GameMaker equivalent.
/// ⛔ FOUND BY LOOKING (2026-10-04): a plain down-and-up resample (1/8, then magnified) left a BLOCKY halo - square
/// steps along every edge at white heat - because bilinear magnification of a hard low-res mask has boxy contours.
/// Returns the surface.
function anv_bake_glow(_sf, _f, _ss) {
    var _R = anv_region();
    _sf = anv__surface(_sf, _R.w * _ss, _R.h * _ss);
    var _qw = ceil(_R.w / 4), _qh = ceil(_R.h / 4);
    var _q = surface_create(_qw, _qh), _p = surface_create(_qw, _qh);
    var _m = anv__bake_begin(_q);
    var _c = anv_cx_create(0.25);
    anv_cx_translate(_c, -_R.x, -_R.y);
    anv_draw_glow(_c, _f.work);
    anv__bake_end(_m);
    var _w = [0.028, 0.066, 0.124, 0.180, 0.204, 0.180, 0.124, 0.066, 0.028];   // a gaussian, sigma ~2 texels (8 design px)
    var _tf = gpu_get_texfilter();
    // horizontal: q -> p
    _m = anv__bake_begin(_p);
    gpu_set_blendmode_ext(bm_one, bm_one); gpu_set_texfilter(false);
    for (var _i = 0; _i < 9; _i++) draw_surface_ext(_q, _i - 4, 0, 1, 1, 0, merge_colour(c_black, c_white, _w[_i]), _w[_i]);
    anv__bake_end(_m);
    // vertical: p -> q
    _m = anv__bake_begin(_q);
    gpu_set_blendmode_ext(bm_one, bm_one); gpu_set_texfilter(false);
    for (var _j = 0; _j < 9; _j++) draw_surface_ext(_p, 0, _j - 4, 1, 1, 0, merge_colour(c_black, c_white, _w[_j]), _w[_j]);
    anv__bake_end(_m);
    // magnify into the region surface
    _m = anv__bake_begin(_sf);
    gpu_set_blendmode_ext(bm_one, bm_zero); gpu_set_texfilter(true);
    draw_surface_ext(_q, 0, 0, surface_get_width(_sf) / _qw, surface_get_height(_sf) / _qh, 0, c_white, 1);
    anv__bake_end(_m);
    gpu_set_texfilter(_tf);
    surface_free(_q); surface_free(_p);
    return _sf;
}

/// @function anv_bake_card(surface, w, h, ss, painter)
/// @description Bake a w x h design-space card via painter(ctx) into a surface (created or reused; returned).
function anv_bake_card(_sf, _w, _h, _ss, _painter) {
    _sf = anv__surface(_sf, _w * _ss, _h * _ss);
    var _m = anv__bake_begin(_sf);
    var _c = anv_cx_create(_ss);
    _painter(_c);
    anv__bake_end(_m);
    return _sf;
}

// ---------------------------------------------------------------------------------------------------------------
// The finished piece, as a sprite the buyer keeps
// ---------------------------------------------------------------------------------------------------------------

/// @function anv_blade_extent(target, profile)
/// @description The finished piece's box at the original's verdict geometry (drawn from (0, 0), length 500, half-width
/// scale 60): {x0, x1, y0, y1}, fittings and drop shadow included. The fittings are drawn at FIXED sizes (a grip is 104
/// px whatever the blade), so the piece is fitted by scaling this whole box, never by shortening the blade. Pure.
function anv_blade_extent(_t, _prof) {
    var _fam = _t.meta.family, _n = array_length(_prof), _mx = 0;
    for (var _i = 0; _i < _n; _i++) _mx = max(_mx, _prof[_i]);
    var _half = _mx * 60, _x0, _x1 = 500, _y0, _y1;
    if (_fam == "axe") {
        var _eye = (is_numeric(_t.meta.eye) && _t.meta.eye != 0) ? _t.meta.eye : 0.2;
        var _ex = 90 + anv_jsround(_eye * (_n - 1)) / (_n - 1) * 310;
        _x0 = min(90, _ex - 10); _x1 = 400; _y0 = min(-102, -_half); _y1 = max(150, _half);
    } else if (_fam == "spear" || _fam == "mace") {
        _x0 = -225; _y0 = -max(_half, 9); _y1 = max(_half, 9);
    } else {
        var _gl = (_fam == "dagger") ? 70 : ((_fam == "claw") ? 56 : 104), _gh = (_fam == "claw") ? 22 : 44;
        var _gx = floor(_t.meta.tang * (_n - 1)) / (_n - 1) * 500;
        _x0 = _gx - _gl - 20; _y0 = -max(_half, _gh + 6); _y1 = max(_half, _gh + 6);
    }
    return { x0: _x0 - 4, x1: _x1 + 9, y0: _y0 - 4, y1: _y1 + 11 };
}

/// @function anv_blade_sprite(target, forge, w, h, [ss])
/// @description The finished piece as a NEW sprite of w x h pixels (origin at its centre), the whole piece scaled
/// uniformly to fit: the forge's work profile, marks and flaws (pass undefined for the forge to draw the TARGET as a
/// perfect, unworked piece). The caller owns the sprite (sprite_delete it when done; see anv_draw_pm to draw it). Returns
/// -1 for an unusable target or a size outside 8..2048.
function anv_blade_sprite(_t, _f, _w, _h, _ss = ANV_SS) {
    if (!is_struct(_t) || !variable_struct_exists(_t, "profile") || !is_array(_t.profile) || array_length(_t.profile) < 2 || !variable_struct_exists(_t, "meta") || !is_struct(_t.meta)) return -1;
    if (!is_numeric(_w) || !is_numeric(_h)) return -1;
    _w = floor(_w); _h = floor(_h);
    if (_w < 8 || _h < 8 || _w > 2048 || _h > 2048) return -1;
    if (!is_numeric(_ss) || _ss < 1 || _ss > 4) _ss = ANV_SS;
    var _prof = _t.profile, _marks = [], _flaws = [];
    if (is_struct(_f) && variable_struct_exists(_f, "work") && is_array(_f.work) && array_length(_f.work) == array_length(_t.profile)) { _prof = _f.work; _marks = _f.marks; _flaws = _f.flaws; }
    var _e = anv_blade_extent(_t, _prof);
    var _s = min(_w / (_e.x1 - _e.x0), _h / (_e.y1 - _e.y0));
    var _ox = (_w / _s - (_e.x1 - _e.x0)) / 2 - _e.x0, _oy = (_h / _s - (_e.y1 - _e.y0)) / 2 - _e.y0;
    var _sf = surface_create(_w * _ss, _h * _ss);
    var _m = anv__bake_begin(_sf);
    var _c = anv_cx_create(_ss * _s);
    anv_cx_translate(_c, _ox, _oy);
    anv_draw_blade(_c, _prof, _t.meta, _t.metal, _marks, _flaws, 0, 0, 500, 60, _t.seed);
    anv__bake_end(_m);
    // filter down to the asked size (premultiplied copy)
    var _out = surface_create(_w, _h);
    _m = anv__bake_begin(_out);
    var _tf = gpu_get_texfilter();
    gpu_set_blendmode_ext(bm_one, bm_zero); gpu_set_texfilter(true);
    draw_surface_ext(_sf, 0, 0, 1 / _ss, 1 / _ss, 0, c_white, 1);
    gpu_set_texfilter(_tf);
    anv__bake_end(_m);
    var _spr = sprite_create_from_surface(_out, 0, 0, _w, _h, false, false, _w / 2, _h / 2);
    surface_free(_sf); surface_free(_out);
    return _spr;
}

/// @function anv_draw_pm(sprite, x, y, xscale, yscale, angle, colour, alpha)
/// @description Draw one of Anvil's PREMULTIPLIED sprites (anv_blade_sprite, the cache) correctly over anything:
/// blend one / inv_src_alpha, the colour scaled by the alpha. Restores the caller's blend mode.
function anv_draw_pm(_spr, _x, _y, _xs = 1, _ys = 1, _ang = 0, _col = c_white, _a = 1) {
    if (is_undefined(_spr) || is_string(_spr) || is_struct(_spr) || is_array(_spr) || !sprite_exists(_spr)) return;
    if (!is_numeric(_x) || !is_numeric(_y)) return;
    if (!is_numeric(_xs)) _xs = 1;
    if (!is_numeric(_ys)) _ys = 1;
    if (!is_numeric(_ang)) _ang = 0;
    if (!is_numeric(_col)) _col = c_white;
    if (!is_numeric(_a)) _a = 1;
    gpu_push_state();
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    draw_sprite_ext(_spr, 0, _x, _y, _xs, _ys, _ang, merge_colour(c_black, _col, clamp(_a, 0, 1)), _a);
    gpu_pop_state();
}
