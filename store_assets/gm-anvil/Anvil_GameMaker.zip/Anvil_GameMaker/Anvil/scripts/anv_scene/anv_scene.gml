/// anv_scene.gml - the forge as a screen: a struct you create from a target, STEP once per game frame and DRAW into any
/// rectangle. The player moves the hammer along the bar, strikes, puts the bar back in the hearth, quenches; the scene
/// cools the metal, animates the blow, the hearth slide, the quench and its steam, throws sparks, and reveals the
/// finished piece with its grade. When it is over, read the result.
///
/// Anvil - A Forging Minigame Drawn in Code, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// THE LOOP (ported from the MZ Scene_Anvil, frame for frame - every count of frames below is the original's):
///   play    left/right move the hammer, strike, reheat, quench, leave. The metal cools one frame per step.
///   strike  the hammer rises (frames 1-5) and falls; the metal moves on frame 8; back to play on frame 10.
///   reheat  the bar slides into the hearth (18 frames), takes the heat on frame 30, slides back by frame 60.
///   quench  the bar travels to the trough and shrinks (18 frames), steam rises, the piece is judged on frame 44.
///   reveal  the finished plate fades in over 24 frames; then any key or click leaves.
/// ⛔ A step is one 1/60 s frame (the original's timing). At another game speed call anv_scene_step that many times.
///
/// INPUT. anv_scene_step(scene) reads the keyboard and the mouse itself (arrows or A/D move, Enter/Space/Z strike,
/// Shift reheats, Q quenches, Escape/X/Backspace leaves; click the bar to strike there, click the plaques, right-click
/// leaves) with the mouse read in GUI coordinates - draw the scene in a Draw GUI event, or pass your own input struct
/// (anv_input(...)) built from whatever bindings your game uses.
///
/// EVENTS. scene.events lists what happened THIS step ("strike", "crack", "reheat", "quench", "finish", "leave") so your
/// game can play its own sounds; Anvil ships no audio.

#macro ANV_SPARKS 36
#macro ANV_PUFFS 14

/// @function anv_weapon(name, [type], [attack], [description], [seed])
/// @description A forging target generated from a weapon as your database describes it: the family from its type name
/// first and its own name second (anv_family_of), the metal from its name and description (anv_metal_of), the
/// proportions from the seed, name and attack. Without a seed, the name and type pick one, so the same weapon always
/// forges to the same pattern. Returns a target struct (see anv_target).
function anv_weapon(_name, _type = "", _atk = 20, _desc = "", _seed = undefined) {
    _name = is_undefined(_name) ? "" : string(_name);
    _type = is_undefined(_type) ? "" : string(_type);
    _desc = is_undefined(_desc) ? "" : string(_desc);
    var _s = is_numeric(_seed) ? anv_u32(_seed) : anv_hash(_name + "|" + _type);
    return anv_target({ seed: _s, family: anv_family_of(_type, _name), atk: is_numeric(_atk) ? _atk : 20, metal: anv_metal_of(_name, _desc), name: _name });
}

/// @function anv_input(left, right, strike, reheat, quench, leave, [mouse_x], [mouse_y], [click], [right_click])
/// @description An input struct for anv_scene_step from your own bindings. left/right are REPEATING presses (true on the
/// step the hammer should move), the rest are single presses; the mouse is in the coordinates you draw the scene in.
function anv_input(_l, _r, _strike, _reheat, _quench, _leave, _mx = -100000, _my = -100000, _click = false, _rclick = false) {
    return { left: _l == true, right: _r == true, strike: _strike == true, reheat: _reheat == true, quench: _quench == true, leave: _leave == true,
        mx: is_numeric(_mx) ? _mx : -100000, my: is_numeric(_my) ? _my : -100000, click: _click == true, rclick: _rclick == true };
}

/// @function anv_scene_create(target, [options])
/// @description A forge for a target (anv_weapon or anv_target). options (all optional): {difficulty: "easy" | "normal" |
/// "hard", title: the work order's heading (default the weapon's name), min_quality: 0-100 (result.cleared is quality >=
/// it; default 65), give: true to say on the plate whether the piece is good enough to keep, quality: internal scale 1-3
/// (default 2; higher is sharper on a large screen and costs more to bake), fade: false to skip the 16-frame fade in from
/// black (and out)}. Returns the scene struct, or undefined for a target that is not one.
function anv_scene_create(_t, _opt = undefined) {
    if (!anv__is_target(_t)) return undefined;
    if (!is_struct(_opt)) _opt = {};
    var _g = function(_o, _k, _d) { return variable_struct_exists(_o, _k) ? variable_struct_get(_o, _k) : _d; };
    var _ss = _g(_opt, "quality", ANV_SS);
    _ss = is_numeric(_ss) ? clamp(round(_ss), 1, 3) : ANV_SS;
    var _title = _g(_opt, "title", undefined);
    if (!is_string(_title) || _title == "") _title = (is_string(_t.name) && _t.name != "") ? _t.name : "A Plain Blade";
    var _minq = _g(_opt, "min_quality", 65);
    _minq = is_numeric(_minq) ? clamp(floor(_minq), 0, 100) : 65;
    var _B = anv_bar();
    var _s = {
        v: 1, target: _t, forge: anv_new_forge(_t, _g(_opt, "difficulty", "normal")), title: _title, min_quality: _minq, give: (_g(_opt, "give", false) == true),
        ss: _ss, pos: floor(ANV_N / 2), mode: "play", anim: 0, frame: 0, status: "", hover: -1, tallyKey: "", plaqueKey: "",
        home: { x: _B.x0 + _B.len / 2, y: _B.cy }, box: { x: _B.x0 + _B.len / 2, y: _B.cy, scale: 1, alpha: 1 },
        hammer: { x: 0, y: 0, scale: 1, visible: true }, sparks: [], puffs: [], fxSeed: 1,
        verdictAlpha: 0, verdictInfo: undefined, quenchVerdict: undefined, result: undefined, cleared: false, events: [], fade: 0,
        surf: { work: undefined, glow: undefined, chalk: undefined, order: undefined, tally: undefined, plaques: undefined, status: undefined, verdict: undefined },
        dirty: { work: true, chalk: true, order: true, tally: true, plaques: true, status: true, verdict: false },
        rep: { left: 0, right: 0 }, glowAlpha: 0, tint: c_white, pointerX: 0, lastDraw: { x: 0, y: 0, k: 1 }
    };
    for (var _i = 0; _i < ANV_SPARKS; _i++) array_push(_s.sparks, { life: 0, x: 0, y: 0, vx: 0, vy: 0, rot: 0, tint: c_white });
    for (var _j = 0; _j < ANV_PUFFS; _j++) array_push(_s.puffs, { life: 0, x: 0, y: 0, vx: 0, vy: 0, scale: 0.8, alpha: 0 });
    anv__scene_place_hammer(_s);
    anv__scene_apply_heat(_s);
    anv__scene_set_status(_s, "Strike while it glows. Shift reheats, Q quenches.");
    _s.fade = (_g(_opt, "fade", true) == false) ? 0 : 16;   // fade in from black over 16 frames, unless fade: false
    return _s;
}

/// @function anv_scene_done(scene)
/// @description True once the player has left the forge (after the verdict, or without quenching).
function anv_scene_done(_s) { return is_struct(_s) && _s.mode == "gone"; }

/// @function anv_scene_result(scene)
/// @description The verdict once the piece is quenched: {quality 0-100, grade 1-4, gradeName, shape %, quench %, heats,
/// strikes, flaws, colour, note, cleared}, or undefined while working or if the player left without quenching.
function anv_scene_result(_s) { return is_struct(_s) ? _s.result : undefined; }

/// @function anv_scene_free(scene)
/// @description Free the scene's surfaces (the shared smithy cache stays; anv_cache_free releases it).
function anv_scene_free(_s) {
    if (!is_struct(_s)) return;
    var _names = variable_struct_get_names(_s.surf);
    for (var _i = 0; _i < array_length(_names); _i++) {
        var _sf = variable_struct_get(_s.surf, _names[_i]);
        if (!is_undefined(_sf) && surface_exists(_sf)) surface_free(_sf);
        variable_struct_set(_s.surf, _names[_i], undefined);
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Internals: the original's helpers
// ---------------------------------------------------------------------------------------------------------------

/// @function anv__scene_bar_x(scene, pos)
function anv__scene_bar_x(_s, _p) { var _B = anv_bar(); return _B.x0 + (_p / (ANV_N - 1)) * _B.len; }
/// @function anv__scene_place_hammer(scene)
function anv__scene_place_hammer(_s) { _s.hammer.x = anv__scene_bar_x(_s, _s.pos); _s.hammer.y = anv_bar().cy - 30; }
/// @function anv__scene_apply_heat(scene)
/// @description The heat's tint on the bar and its halo, the halo's strength, the chart pointer. Scalars only (per step).
function anv__scene_apply_heat(_s) {
    var _h = _s.forge.heat;
    _s.tint = anv_heat_colour(clamp(anv_jsround(_h * 100), 0, 100) / 100);
    _s.glowAlpha = (_h < 0.22) ? 0 : min(0.95, (_h - 0.22) * 1.35);
    _s.pointerX = 262 + _h * 292 - 10;   // the chart's sx and sw (anv_draw_temper_chart at 250, 18, 316, 44)
}
/// @function anv__scene_set_status(scene, text)
function anv__scene_set_status(_s, _t) { if (_t == _s.status) return; _s.status = _t; _s.dirty.status = true; }
/// @function anv__scene_rand(scene)
/// @description The effects generator (the original's LCG): sparks and steam only, never the model.
function anv__scene_rand(_s) { _s.fxSeed = (anv_mul32(_s.fxSeed, 1103515245) + 12345) & $FFFFFFFF; return (_s.fxSeed >> 8) / 16777216; }
/// @function anv__scene_sparks(scene, x, y, n)
function anv__scene_sparks(_s, _x, _y, _n) {
    var _tint = anv_heat_colour(min(100, anv_jsround(max(0.6, _s.forge.heat) * 100)) / 100), _used = 0;
    for (var _i = 0; _i < array_length(_s.sparks) && _used < _n; _i++) {
        var _p = _s.sparks[_i];
        if (_p.life > 0) continue;
        var _ang = anv__scene_rand(_s) * pi * 2;
        var _sp = 3 + anv__scene_rand(_s) * 7;
        _p.x = _x; _p.y = _y; _p.vx = cos(_ang) * _sp; _p.vy = sin(_ang) * _sp - 2;
        _p.life = 14 + floor(anv__scene_rand(_s) * 14); _p.tint = _tint; _p.rot = _ang; _used++;
    }
}
/// @function anv__scene_puff(scene, x, y)
function anv__scene_puff(_s, _x, _y) {
    for (var _i = 0; _i < array_length(_s.puffs); _i++) {
        var _p = _s.puffs[_i];
        if (_p.life > 0) continue;
        _p.x = _x; _p.y = _y;
        _p.vx = (anv__scene_rand(_s) - 0.5) * 1.6;
        _p.vy = -1.4 - anv__scene_rand(_s) * 1.6;
        _p.life = 40; _p.scale = 0.8; _p.alpha = 0.9;
        return;
    }
}
/// @function anv__scene_fx(scene)
function anv__scene_fx(_s) {
    var _i, _p;
    for (_i = 0; _i < array_length(_s.sparks); _i++) { _p = _s.sparks[_i]; if (_p.life <= 0) continue; _p.life--; _p.x += _p.vx; _p.y += _p.vy; _p.vy += 0.35; _p.vx *= 0.96; _p.rot = arctan2(_p.vy, _p.vx); }
    for (_i = 0; _i < array_length(_s.puffs); _i++) { _p = _s.puffs[_i]; if (_p.life <= 0) continue; _p.life--; _p.x += _p.vx; _p.y += _p.vy; _p.scale += 0.035; _p.alpha = _p.life / 44; }
}
/// @function anv__scene_plaque_states(scene)
function anv__scene_plaque_states(_s) {
    var _f = _s.forge, _play = (_s.mode == "play");
    return [(_play && _f.heat >= 0) ? "idle" : "off", (_play && _f.heats < _f.maxHeats) ? "idle" : "off", _play ? "idle" : "off"];
}
/// @function anv__scene_tally_check(scene)
function anv__scene_tally_check(_s) {
    var _f = _s.forge, _key = string(_f.heats) + "|" + string(_f.strikes) + "|" + string(array_length(_f.flaws)) + "|" + string(anv_jsround(anv_shape(_s.target, _f) * 100)) + "|" + anv_heat_name(_f.heat);
    if (_key != _s.tallyKey) { _s.tallyKey = _key; _s.dirty.tally = true; }
}
/// @function anv__scene_plaque_check(scene)
function anv__scene_plaque_check(_s) {
    var _st = anv__scene_plaque_states(_s), _key = _st[0] + "|" + _st[1] + "|" + _st[2] + "|" + string(_s.hover);
    if (_key != _s.plaqueKey) { _s.plaqueKey = _key; _s.dirty.plaques = true; }
}

// ---------------------------------------------------------------------------------------------------------------
// The step
// ---------------------------------------------------------------------------------------------------------------

/// @function anv__scene_input_default(scene)
/// @description Read the keyboard and the mouse (GUI coordinates mapped back through the last draw) into an input
/// struct, with the original's key repeat (first press, then every 6 frames after 24). Internal.
function anv__scene_input_default(_s) {
    var _l = keyboard_check(vk_left) || keyboard_check(ord("A")), _r = keyboard_check(vk_right) || keyboard_check(ord("D"));
    var _lrep = false, _rrep = false;
    if (_l) { _s.rep.left++; _lrep = (_s.rep.left == 1) || (_s.rep.left > 24 && ((_s.rep.left - 24) mod 6) == 0); } else _s.rep.left = 0;
    if (_r) { _s.rep.right++; _rrep = (_s.rep.right == 1) || (_s.rep.right > 24 && ((_s.rep.right - 24) mod 6) == 0); } else _s.rep.right = 0;
    var _mx = device_mouse_x_to_gui(0), _my = device_mouse_y_to_gui(0);
    return anv_input(_lrep, _rrep, keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("Z")),
        keyboard_check_pressed(vk_shift), keyboard_check_pressed(ord("Q")),
        keyboard_check_pressed(vk_escape) || keyboard_check_pressed(ord("X")) || keyboard_check_pressed(vk_backspace),
        _mx, _my, mouse_check_button_pressed(mb_left), mouse_check_button_pressed(mb_right));
}

/// @function anv_scene_step(scene, [input])
/// @description Advance the forge one frame. Without an input struct the scene reads the keyboard and the mouse (GUI
/// coordinates) itself; pass anv_input(...) to use your own bindings. Returns the scene's mode.
function anv_scene_step(_s, _in = undefined) {
    if (!is_struct(_s) || _s.mode == "gone") return is_struct(_s) ? _s.mode : "gone";
    _s.events = [];
    _s.frame++;
    if (!is_struct(_in)) _in = anv__scene_input_default(_s);
    else if (!variable_struct_exists(_in, "mx")) {
        // a hand-made struct: read what it says, default the rest (anv_input builds a complete one)
        var _gi = function(_o, _k, _d) { return variable_struct_exists(_o, _k) ? variable_struct_get(_o, _k) : _d; };
        _in = anv_input(_gi(_in, "left", false), _gi(_in, "right", false), _gi(_in, "strike", false), _gi(_in, "reheat", false), _gi(_in, "quench", false), _gi(_in, "leave", false), _gi(_in, "mx", -100000), _gi(_in, "my", -100000), _gi(_in, "click", false), _gi(_in, "rclick", false));
    }
    // the mouse in design coordinates, through the last draw's placement
    var _k = max(0.0001, _s.lastDraw.k), _tx = (_in.mx - _s.lastDraw.x) / _k, _ty = (_in.my - _s.lastDraw.y) / _k;
    if (_s.fade > 0 && _s.mode != "leaving") _s.fade--;
    anv__scene_fx(_s);
    var _m = _s.mode, _f = _s.forge;
    if (_m == "play" || _m == "strike") { anv_cool(_f, 1); anv__scene_apply_heat(_s); if ((_s.frame & 7) == 0) anv__scene_tally_check(_s); }
    if (_m == "play") anv__scene_play(_s, _in, _tx, _ty);
    else if (_m == "strike") anv__scene_strike(_s);
    else if (_m == "reheat") anv__scene_reheat(_s);
    else if (_m == "quench") anv__scene_quench(_s);
    else if (_m == "reveal") { _s.anim++; _s.verdictAlpha = min(1, _s.anim * 11 / 255); if (_s.anim >= 24) _s.mode = "done"; }
    else if (_m == "done") { if (_in.strike || _in.leave || _in.click || _in.rclick || _in.reheat || _in.quench) anv__scene_leave(_s); }
    else if (_m == "leaving") { _s.fade++; if (_s.fade >= 16) _s.mode = "gone"; }
    return _s.mode;
}

/// @function anv__scene_play(scene, input, tx, ty)
function anv__scene_play(_s, _in, _tx, _ty) {
    var _P = { x: 200, y: 528, w: 130, h: 32, gap: 142 }, _B = anv_bar();
    if (_in.left) { _s.pos = max(0, _s.pos - 1); anv__scene_place_hammer(_s); }
    else if (_in.right) { _s.pos = min(ANV_N - 1, _s.pos + 1); anv__scene_place_hammer(_s); }
    if (_in.strike) { anv__scene_begin_strike(_s); return; }
    if (_in.reheat) { anv__scene_begin_reheat(_s); return; }
    if (_in.quench) { anv__scene_begin_quench(_s); return; }
    if (_in.leave || _in.rclick) { anv__scene_leave(_s); return; }
    var _hover = -1;
    if (_ty >= _P.y && _ty < _P.y + _P.h) for (var _k = 0; _k < 3; _k++) if (_tx >= _P.x + _k * _P.gap && _tx < _P.x + _k * _P.gap + _P.w) _hover = _k;
    if (_hover != _s.hover) { _s.hover = _hover; anv__scene_plaque_check(_s); }
    if (_in.click) {
        if (_hover == 0) anv__scene_begin_strike(_s);
        else if (_hover == 1) anv__scene_begin_reheat(_s);
        else if (_hover == 2) anv__scene_begin_quench(_s);
        else if (_tx >= _B.x0 - 10 && _tx <= _B.x0 + _B.len + 10 && abs(_ty - _B.cy) <= _B.hs + 16) {
            _s.pos = max(0, min(ANV_N - 1, anv_jsround((_tx - _B.x0) / _B.len * (ANV_N - 1))));
            anv__scene_place_hammer(_s); anv__scene_begin_strike(_s);
        }
    }
}

/// @function anv__scene_begin_strike(scene)
function anv__scene_begin_strike(_s) { _s.mode = "strike"; _s.anim = 0; anv__scene_plaque_check(_s); }

/// @function anv__scene_strike(scene)
/// @description The blow: the hammer rises (frames 1-5) and falls (6-9); the metal moves on the frame it lands (8).
function anv__scene_strike(_s) {
    var _a = ++_s.anim;
    _s.hammer.scale = (_a <= 5) ? 1 + _a * 0.05 : max(1, 1.25 - (_a - 5) * 0.08);
    if (_a == 8) {
        var _out = anv_strike(_s.target, _s.forge, _s.pos);
        var _cracked = is_struct(_out) && _out.cracked;
        _s.dirty.work = true; anv__scene_tally_check(_s);
        anv__scene_sparks(_s, anv__scene_bar_x(_s, _s.pos), anv_bar().cy, _cracked ? 6 : 10 + anv_jsround(_s.forge.heat * 18));
        array_push(_s.events, _cracked ? "crack" : "strike");
        if (_cracked) anv__scene_set_status(_s, "It cracked: too cold to work. Reheat it.");
        else if (_s.forge.heat < 0.3) anv__scene_set_status(_s, "The colour is going. Reheat soon.");
        else anv__scene_set_status(_s, "Strike while it glows. Shift reheats, Q quenches.");
    }
    if (_a >= 10) { _s.hammer.scale = 1; _s.mode = "play"; anv__scene_plaque_check(_s); }
}

/// @function anv__scene_begin_reheat(scene)
function anv__scene_begin_reheat(_s) {
    var _f = _s.forge;
    if (_f.heats >= _f.maxHeats) { anv__scene_set_status(_s, "No heats left. Quench it now."); return; }
    _s.mode = "reheat"; _s.anim = 0; array_push(_s.events, "reheat"); anv__scene_set_status(_s, "Into the fire..."); anv__scene_plaque_check(_s);
}

/// @function anv__scene_reheat(scene)
/// @description Back into the hearth: the bar slides left into the fire, takes the heat, and slides back.
function anv__scene_reheat(_s) {
    var _a = ++_s.anim;
    _s.box.x = _s.home.x + ((_a <= 18) ? -_a * 22 : ((_a <= 42) ? -396 : -396 + (_a - 42) * 22));
    _s.hammer.visible = false;
    if (_a == 30) { anv_reheat(_s.forge); anv__scene_apply_heat(_s); anv__scene_tally_check(_s); }
    if (_a >= 60) { _s.box.x = _s.home.x; _s.hammer.visible = true; _s.mode = "play"; anv__scene_plaque_check(_s); anv__scene_set_status(_s, "Back to white heat. Strike while it glows."); }
}

/// @function anv__scene_begin_quench(scene)
function anv__scene_begin_quench(_s) {
    _s.quenchVerdict = anv_quench(_s.forge); _s.mode = "quench"; _s.anim = 0; array_push(_s.events, "quench"); anv__scene_plaque_check(_s);
    anv__scene_set_status(_s, "Quenched at " + _s.quenchVerdict.colour + ".");
    _s.hammer.visible = false;
}

/// @function anv__scene_quench(scene)
/// @description The quench: the bar travels to the trough and shrinks as it is lowered in, steam rises where it goes
/// under, and the piece is judged at the colour it had.
function anv__scene_quench(_s) {
    var _a = ++_s.anim, _k = min(1, _a / 18), _TX = 720, _TY = 520;
    _s.box.x = _s.home.x + (_TX - _s.home.x) * _k; _s.box.y = _s.home.y + (_TY - _s.home.y) * _k;
    _s.box.scale = 1 - 0.72 * _k; _s.box.alpha = (_a <= 18) ? 1 : max(0, 1 - (_a - 18) / 10);
    if (_a >= 14 && _a <= 36 && (_a & 1) == 0) anv__scene_puff(_s, _TX - 50 + (_a * 13) mod 100, _TY - 10);
    if (_a >= 44) anv__scene_finish(_s);
}

/// @function anv__scene_finish(scene)
function anv__scene_finish(_s) {
    var _sc = anv_score(_s.target, _s.forge), _q = _s.quenchVerdict;
    _s.cleared = (_sc.quality >= _s.min_quality);
    _sc.colour = _q.colour; _sc.note = _q.note; _sc.cleared = _s.cleared;
    _s.result = _sc;
    var _foot = _s.give ? (_s.cleared ? "The " + _s.title + " is yours." : "Not good enough to keep: the bar is " + string(_s.min_quality) + ".") : "Press any key to leave the forge.";
    var _sub = "Quenched at " + _q.colour + " (" + _q.note + "). " + string(_sc.heats) + ((_sc.heats == 1) ? " heat, " : " heats, ") + string(_sc.strikes) + " blows, " + string(_sc.shape) + "% to the pattern" + ((_sc.flaws != 0) ? ", " + string(_sc.flaws) + ((_sc.flaws == 1) ? " crack." : " cracks.") : ".");
    _s.verdictInfo = { profile: _s.forge.work, meta: _s.target.meta, metal: _s.target.metal, marks: _s.forge.marks, flaws: _s.forge.flaws, seed: _s.target.seed, grade: _sc.grade,
        title: _sc.gradeName + " - quality " + string(_sc.quality), sub: _sub, foot: _foot };
    _s.dirty.verdict = true;
    _s.verdictAlpha = 0; _s.anim = 0; _s.mode = "reveal"; array_push(_s.events, "finish");
    anv__scene_set_status(_s, "");
}

/// @function anv__scene_leave(scene)
function anv__scene_leave(_s) {
    if (_s.mode == "leaving" || _s.mode == "gone") return;
    _s.mode = "leaving"; _s.fade = 0; array_push(_s.events, "leave");
}

// ---------------------------------------------------------------------------------------------------------------
// The draw
// ---------------------------------------------------------------------------------------------------------------

/// @function anv__scene_bake(scene)
/// @description Re-bake whatever changed or was lost (surfaces are volatile). Internal.
function anv__scene_bake(_s) {
    var _ss = _s.ss, _f = _s.forge, _t = _s.target, _sf = _s.surf, _d = _s.dirty;
    anv_cache_build(_ss);
    if (_d.chalk || is_undefined(_sf.chalk) || !surface_exists(_sf.chalk)) { _sf.chalk = anv_bake_chalk(_sf.chalk, _t, _ss); _d.chalk = false; }
    if (_d.work || is_undefined(_sf.work) || !surface_exists(_sf.work) || is_undefined(_sf.glow) || !surface_exists(_sf.glow)) {
        _sf.work = anv_bake_work(_sf.work, _f, _t, _ss); _sf.glow = anv_bake_glow(_sf.glow, _f, _ss); _d.work = false;
    }
    if (_d.order || is_undefined(_sf.order) || !surface_exists(_sf.order)) {
        var _fam = _t.family, _art = (string_pos(string_char_at(_fam, 1), "aeiou") > 0) ? "an " : "a ";
        // ⛔ a GML anonymous function does not capture the enclosing locals: every painter is a METHOD bound to its data
        var _info = { title: _s.title, sub: _art + _fam + ", in " + _t.metal, profile: _t.profile, task: "Work the bar to the chalked pattern.", task2: string(_f.maxHeats) + " heats allowed - quench at cherry red" };
        _sf.order = anv_bake_card(_sf.order, 226, 170, _ss, method({ info: _info }, function(_c) { anv_draw_order(_c, 226, 170, info); }));
        _d.order = false;
    }
    if (_d.tally || is_undefined(_sf.tally) || !surface_exists(_sf.tally)) {
        var _ti = { heats: _f.heats, maxHeats: _f.maxHeats, strikes: _f.strikes, flaws: array_length(_f.flaws), shape: anv_jsround(anv_shape(_t, _f) * 100), colour: anv_heat_name(_f.heat) };
        _sf.tally = anv_bake_card(_sf.tally, 226, 170, _ss, method({ info: _ti }, function(_c) { anv_draw_tally(_c, 226, 170, info); }));
        _d.tally = false;
    }
    if (_d.plaques || is_undefined(_sf.plaques) || !surface_exists(_sf.plaques)) {
        _sf.plaques = anv_bake_card(_sf.plaques, 142 * 2 + 130 + 16, 32 + 14, _ss, method({ st: anv__scene_plaque_states(_s), hover: _s.hover }, function(_c) {
            var _labels = ["Strike", "Reheat", "Quench"];
            for (var _k = 0; _k < 3; _k++) anv_draw_plaque(_c, 6 + _k * 142, 6, 130, 32, _labels[_k], (st[_k] == "idle" && hover == _k) ? "on" : st[_k]);
        }));
        _d.plaques = false;
    }
    if (_d.status || is_undefined(_sf.status) || !surface_exists(_sf.status)) {
        _sf.status = anv_bake_card(_sf.status, 496, 40, _ss, method({ text: _s.status }, function(_c) { if (text != "") anv_draw_status(_c, 496, 40, text); }));
        _d.status = false;
    }
    if (is_struct(_s.verdictInfo) && (_d.verdict || is_undefined(_sf.verdict) || !surface_exists(_sf.verdict))) {
        _sf.verdict = anv_bake_card(_sf.verdict, 816, 624, _ss, method({ info: _s.verdictInfo }, function(_c) { anv_draw_verdict(_c, 816, 624, info); }));
        _d.verdict = false;
    }
}

/// @function anv__pm(surface, x, y, scale, colour, alpha)
/// @description Draw a premultiplied surface at a design position through the current placement. Internal.
function anv__pm(_sf, _x, _y, _sc, _col, _a) {
    if (is_undefined(_sf) || !surface_exists(_sf) || _a <= 0) return;
    draw_surface_ext(_sf, _x, _y, _sc, _sc, 0, merge_colour(c_black, _col, clamp(_a, 0, 1)), _a);
}

/// @function anv_scene_draw(scene, x, y, w, h)
/// @description Draw the forge fitted into the rectangle (x, y, w, h) at the original's 816 x 624 proportions, centred
/// (letterboxed by the caller's own background). Bakes whatever changed first. Restores the caller's blend, filter and
/// matrix state. Call it from Draw GUI to use the built-in mouse input.
function anv_scene_draw(_s, _x, _y, _w, _h) {
    if (!is_struct(_s) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w) || !is_numeric(_h) || _w <= 0 || _h <= 0) return;
    anv__scene_bake(_s);
    var _K = anv__cache(), _ss = _s.ss;
    var _k = min(_w / 816, _h / 624), _ox = _x + (_w - 816 * _k) / 2, _oy = _y + (_h - 624 * _k) / 2;
    _s.lastDraw = { x: _ox, y: _oy, k: _k };
    var _u = _k / _ss;   // a baked pixel on screen
    gpu_push_state();
    gpu_set_texfilter(true);
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    gpu_set_ztestenable(false);
    var _R = anv_region();
    draw_sprite_ext(_K.board, 0, _ox, _oy, _u, _u, 0, c_white, 1);
    anv__pm(_s.surf.chalk, _ox + _R.x * _k, _oy + _R.y * _k, _u, c_white, 1);
    // the bar's box: pivots on the bar's centre, so the hearth can slide it and the quench lower it (move + shrink)
    var _bx = _s.box, _bsc = _bx.scale;
    var _wx = _ox + (_bx.x + (_R.x - _s.home.x) * _bsc) * _k, _wy = _oy + (_bx.y + (_R.y - _s.home.y) * _bsc) * _k;
    if (_bx.alpha > 0) {
        if (_s.glowAlpha > 0) {
            gpu_set_blendmode_ext(bm_one, bm_one);
            var _ga = _s.glowAlpha * _bx.alpha;
            draw_surface_ext(_s.surf.glow, _wx, _wy, _u * _bsc, _u * _bsc, 0, merge_colour(c_black, _s.tint, _ga), _ga);
            gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
        }
        draw_surface_ext(_s.surf.work, _wx, _wy, _u * _bsc, _u * _bsc, 0, merge_colour(c_black, _s.tint, _bx.alpha), _bx.alpha);
    }
    if (_s.hammer.visible && _s.mode != "reveal" && _s.mode != "done") {
        var _hs = _u * _s.hammer.scale;
        draw_sprite_ext(_K.hammer, 0, _ox + _s.hammer.x * _k, _oy + _s.hammer.y * _k, _hs, _hs, 0, c_white, 1);
    }
    // sparks (additive, tinted) and steam
    gpu_set_blendmode_ext(bm_one, bm_one);
    for (var _i = 0; _i < array_length(_s.sparks); _i++) {
        var _p = _s.sparks[_i];
        if (_p.life <= 0) continue;
        var _pa = min(1, _p.life / 8);
        draw_sprite_ext(_K.spark, 0, _ox + _p.x * _k, _oy + _p.y * _k, _u, _u, -radtodeg(_p.rot), merge_colour(c_black, _p.tint, _pa), _pa);
    }
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    for (var _j = 0; _j < array_length(_s.puffs); _j++) {
        var _q = _s.puffs[_j];
        if (_q.life <= 0) continue;
        draw_sprite_ext(_K.puff, 0, _ox + _q.x * _k, _oy + _q.y * _k, _u * _q.scale, _u * _q.scale, 0, merge_colour(c_black, c_white, _q.alpha), _q.alpha);
    }
    // the cards
    anv__pm(_s.surf.order, _ox + 12 * _k, _oy + 14 * _k, _u, c_white, 1);
    anv__pm(_s.surf.tally, _ox + 580 * _k, _oy + 14 * _k, _u, c_white, 1);
    var _py = (is_struct(_K.chart) && variable_struct_exists(_K.chart, "py")) ? _K.chart.py : 27;
    draw_sprite_ext(_K.pointer, 0, _ox + _s.pointerX * _k, _oy + _py * _k, _u, _u, 0, c_white, 1);
    anv__pm(_s.surf.status, _ox + 160 * _k, _oy + 470 * _k, _u, c_white, 1);
    anv__pm(_s.surf.plaques, _ox + (200 - 6) * _k, _oy + (528 - 6) * _k, _u, c_white, 1);
    if (_s.verdictAlpha > 0 && (_s.mode == "reveal" || _s.mode == "done" || _s.mode == "leaving" || _s.mode == "gone")) anv__pm(_s.surf.verdict, _ox, _oy, _u, c_white, _s.verdictAlpha);
    // fade in / out
    if (_s.fade > 0) {
        var _fa = clamp(_s.fade / 16, 0, 1), _a0 = draw_get_alpha(), _c0 = draw_get_colour();
        // alpha as "over": on a buyer's surface a translucent veil must not LOWER the surface's alpha (found by looking:
        // a fading frame saved from a surface came out washed grey)
        gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
        draw_set_alpha(_fa); draw_set_colour(c_black);
        draw_rectangle(_ox, _oy, _ox + 816 * _k, _oy + 624 * _k, false);
        draw_set_alpha(_a0); draw_set_colour(_c0);
    }
    gpu_pop_state();
}
