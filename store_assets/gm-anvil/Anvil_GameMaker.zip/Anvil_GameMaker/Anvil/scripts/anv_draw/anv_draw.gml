/// anv_draw.gml - every picture Anvil shows, drawn in code onto the canvas kit (anv_canvas): the smithy (stone wall,
/// timber floor, the hearth and its coals, the quench trough), the anvil seen from above, the temper colour chart, the
/// glowing bar (drawn white and shaded; the scene tints it by its heat), the chalked pattern, the hammer, sparks, steam,
/// and the FINISHED piece - the player's own profile, ground smooth, polished in its metal, with their hammer facets and
/// any cracks, and a hilt, haft or socket generated for its family. No image file is loaded anywhere.
///
/// Anvil - A Forging Minigame Drawn in Code, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⛔ A PORT HELD TO ITS ORIGINAL (AnvilDraw.js 1.0.0): every beginPath / fill / stroke / fillRect of the original is made
/// here in the same order, and the suite compares the counts per drawn thing (anv_oracle_draws). Coordinates are the
/// original's 816 x 624 design space; a context's base transform scales them (the scene bakes at 2x and filters down).
/// Three DELIBERATE departures, each keeping every compared count:
///   1. the original's drop shadows (`translate(5, 7); fill()`) were drawn UNDER the shape, because a canvas transforms a
///      path when it is BUILT, not when it is filled; here the shadow is offset as the code intended (anv__fill_offset);
///   2. the glow's CSS blur(12px) does not exist in GameMaker: the halo is drawn the same way and blurred by resampling
///      (anv_bake.gml), so the path, fill and stroke are the original's;
///   3. type is Libre Baskerville from shipped atlases (the original asks the system for Palatino); ASCII only.

/// @function anv_bar()
/// @description The bar's geometry in design space: {x0, len, cy, hs} - x0..x0+len along the anvil face, centred on cy,
/// half-width scale hs px. Pure.
function anv_bar() { return { x0: 200, len: 470, cy: 328, hs: 56 }; }

/// @function anv_anvil_box()
/// @description The anvil's box in design space {x, y, w, h}. Pure.
function anv_anvil_box() { return { x: 176, y: 262, w: 520, h: 132 }; }

/// @function anv_metal_ramp(metal)
/// @description The three polish stops [light, mid, dark] of a metal ("steel", "iron", "bronze", "mithril",
/// "blacksteel"; anything else reads as steel). Pure.
function anv_metal_ramp(_m) {
    switch (_m) {
        case "iron": return [[220, 220, 214], [143, 143, 136], [75, 74, 69]];
        case "bronze": return [[246, 212, 154], [192, 138, 68], [110, 74, 28]];
        case "mithril": return [[242, 251, 255], [185, 214, 230], [108, 143, 166]];
        case "blacksteel": return [[154, 160, 170], [74, 79, 88], [28, 31, 36]];
    }
    return [[238, 242, 245], [170, 180, 189], [92, 102, 111]];
}

/// @function anv_heat_rgb(heat)
/// @description The colour of metal at a heat 0..1 - a blackbody ramp from black iron to white heat - as [r, g, b]. Pure.
function anv_heat_rgb(_h) {
    var _ramp = [[0, [58, 52, 48]], [0.2, [96, 30, 18]], [0.32, [150, 26, 12]], [0.42, [196, 36, 14]], [0.56, [232, 76, 18]], [0.66, [255, 132, 30]], [0.78, [255, 196, 80]], [0.9, [255, 236, 170]], [1, [255, 250, 225]]];
    _h = max(0, min(1, is_numeric(_h) ? _h : 0));
    for (var _i = 1; _i < array_length(_ramp); _i++) {
        if (_h <= _ramp[_i][0]) {
            var _a = _ramp[_i - 1], _b = _ramp[_i], _k = (_h - _a[0]) / (_b[0] - _a[0]);
            return [anv_jsround(_a[1][0] + (_b[1][0] - _a[1][0]) * _k), anv_jsround(_a[1][1] + (_b[1][1] - _a[1][1]) * _k), anv_jsround(_a[1][2] + (_b[1][2] - _a[1][2]) * _k)];
        }
    }
    return [255, 250, 225];
}

/// @function anv_heat_colour(heat)
/// @description The heat colour as a GameMaker colour (for a tint). Pure.
function anv_heat_colour(_h) { return anv_col(anv_heat_rgb(_h)); }

// ---------------------------------------------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------------------------------------------

/// @function anv_rr(ctx, x, y, w, h, r)
/// @description The original's rounded rectangle: a new path with QUADRATIC corners (not arcs), closed.
function anv_rr(_c, _x, _y, _w, _h, _r) {
    _r = max(0, min(_r, _w / 2, _h / 2));
    anv_cx_begin(_c);
    anv_cx_move(_c, _x + _r, _y); anv_cx_line(_c, _x + _w - _r, _y); anv_cx_quad(_c, _x + _w, _y, _x + _w, _y + _r);
    anv_cx_line(_c, _x + _w, _y + _h - _r); anv_cx_quad(_c, _x + _w, _y + _h, _x + _w - _r, _y + _h);
    anv_cx_line(_c, _x + _r, _y + _h); anv_cx_quad(_c, _x, _y + _h, _x, _y + _h - _r);
    anv_cx_line(_c, _x, _y + _r); anv_cx_quad(_c, _x, _y, _x + _r, _y);
    anv_cx_close(_c);
}

/// @function anv__solid(ctx, rgb, a)
/// @description Set the fill to a flat colour. Internal.
function anv__solid(_c, _rgb, _a = 1) { _c.fill = anv_cx_solid(_rgb, _a); }

/// @function anv__pen(ctx, rgb, a, [width])
/// @description Set the stroke to a flat colour (and the line width when given). Internal.
function anv__pen(_c, _rgb, _a = 1, _w = undefined) { _c.stroke = anv_cx_solid(_rgb, _a); if (!is_undefined(_w)) _c.lw = _w; }

/// @function anv__lin(ctx, x0, y0, x1, y1, stops)
/// @description A linear gradient with stops [[t, rgb, a], ...]. Internal.
function anv__lin(_c, _x0, _y0, _x1, _y1, _stops) {
    var _g = anv_cx_linear(_c, _x0, _y0, _x1, _y1);
    for (var _i = 0; _i < array_length(_stops); _i++) anv_cx_stop(_g, _stops[_i][0], _stops[_i][1], (array_length(_stops[_i]) > 2) ? _stops[_i][2] : 1);
    return _g;
}

/// @function anv__rad(ctx, x0, y0, r0, x1, y1, r1, stops)
/// @description A radial gradient with stops [[t, rgb, a], ...]. Internal.
function anv__rad(_c, _x0, _y0, _r0, _x1, _y1, _r1, _stops) {
    var _g = anv_cx_radial(_c, _x0, _y0, _r0, _x1, _y1, _r1);
    for (var _i = 0; _i < array_length(_stops); _i++) anv_cx_stop(_g, _stops[_i][0], _stops[_i][1], (array_length(_stops[_i]) > 2) ? _stops[_i][2] : 1);
    return _g;
}

/// @function anv__fill_offset(ctx, dx, dy)
/// @description Fill the current path shifted by a user-space offset, counted as ONE fill (the original's intended drop
/// shadow; see the header). Internal.
function anv__fill_offset(_c, _dx, _dy) {
    _c.counts.fill++;
    var _m = _c.m, _ox = _m[0] * _dx + _m[2] * _dy, _oy = _m[1] * _dx + _m[3] * _dy;
    var _src = anv_cx__rings(_c), _rings = [];
    for (var _r = 0; _r < array_length(_src); _r++) {
        var _ring = _src[_r], _cp = array_create(array_length(_ring));
        for (var _i = 0; _i < array_length(_ring); _i++) _cp[_i] = [_ring[_i][0] + _ox, _ring[_i][1] + _oy];
        array_push(_rings, _cp);
    }
    if (array_length(_rings) == 1 && _c.fill.kind != 1 && anv_cx__rect_clips(_c) && anv_cx__convex(_rings[0])) { anv_cx__fan(_c, _rings[0], _c.fill, _c.alpha); return; }
    anv_cx__fill(_c, _rings, _c.fill, _c.alpha, ANV_FILL_NONZERO);
}

/// @function anv_dtext(ctx, string, x, y, px, style, rgb, [alpha], [halign])
/// @description Type `px` design pixels tall at a design point under the context's transform, vertically centred (the
/// original's textBaseline "middle"). style: "bold", "italic" or "" (regular). Returns the drawn width in device px.
function anv_dtext(_c, _s, _x, _y, _px, _style, _rgb, _a = 1, _ha = fa_center) {
    var _p = anv_cx__pt(_c, _x, _y), _k = anv_cx__scale(_c), _dpx = _px * _k;
    return anv_text(_p[0], _p[1], _s, _dpx, anv_col(_rgb), _ha, fa_middle, anv_font_for(_dpx, _style), _a * _c.alpha);
}

/// @function anv_fit_text(string, max_w, size, [style])
/// @description The original's fitText: the largest size (down to 9) at which the string fits max_w design pixels. Pure.
function anv_fit_text(_s, _maxW, _size, _style = "bold") {
    while (_size > 9 && anv_text_w(_s, _size, anv_font_for(_size * 2, _style)) > _maxW) _size--;
    return _size;
}

// ---------------------------------------------------------------------------------------------------------------
// The smithy
// ---------------------------------------------------------------------------------------------------------------

/// @function anv_draw_smithy(ctx, W, H)
/// @description Stone wall, the hearth on the left with its coals, a quench trough on the right, a timber floor under
/// the anvil, warm light from the fire and a vignette. Design space W x H (816 x 624).
function anv_draw_smithy(_c, _W, _H) {
    var _r = anv_rng($5A1);
    _c.fill = anv__lin(_c, 0, 0, 0, _H, [[0, [42, 33, 27]], [1, [18, 13, 10]]]); anv_cx_fill_rect(_c, 0, 0, _W, _H);
    // stone courses
    for (var _row = 0; _row * 34 < 212; _row++) {
        var _y = _row * 34, _off = (_row mod 2 != 0) ? 36 : 0;
        for (var _x = -_off; _x < _W + 72; _x += 72 + floor(anv_rnd(_r) * 10)) {
            var _sw = 66 + anv_rnd(_r) * 10;
            var _sh = 29 + anv_rnd(_r) * 3;
            var _v = 38 + floor(anv_rnd(_r) * 22);
            anv__solid(_c, [_v, _v - 6, _v - 12]); anv_rr(_c, _x + 2, _y + 2, _sw, _sh, 5); anv_cx_fill(_c);
            anv__solid(_c, [255, 220, 180], 0.05); anv_rr(_c, _x + 3, _y + 3, _sw - 2, 6, 3); anv_cx_fill(_c);
            anv__solid(_c, [0, 0, 0], 0.25); anv_rr(_c, _x + 2, _y + _sh - 4, _sw, 5, 3); anv_cx_fill(_c);
        }
    }
    // timber floor
    for (var _p = 0; _p < 9; _p++) {
        var _fy = 212 + _p * 46;
        _c.fill = anv__lin(_c, 0, _fy, 0, _fy + 46, [[0, [59, 38, 22]], [1, [36, 23, 13]]]); anv_cx_fill_rect(_c, 0, _fy, _W, 45);
        anv__solid(_c, [0, 0, 0], 0.5); anv_cx_fill_rect(_c, 0, _fy + 45, _W, 1);
        for (var _k = 0; _k < 14; _k++) {
            anv__pen(_c, [255, 200, 150], 0.04);
            anv_cx_begin(_c); anv_cx_move(_c, 0, _fy + 4 + _k * 3);
            var _j = anv_rnd(_r);
            anv_cx_bezier(_c, _W * 0.3, _fy + 4 + _k * 3 + _j * 3, _W * 0.7, _fy + 2 + _k * 3, _W + 4, _fy + 4 + _k * 3);
            anv_cx_stroke(_c);
        }
    }
    // hearth: a brick arch on the left with coals
    var _hx = -20, _hy = 214, _hw = 150, _hh = 210;
    anv__solid(_c, [74, 42, 28]); anv_rr(_c, _hx, _hy - 10, _hw + 30, _hh + 20, 18); anv_cx_fill(_c);
    for (var _b = 0; _b < 26; _b++) { anv__solid(_c, (_b mod 2 != 0) ? [106, 53, 34] : [90, 45, 29]); anv_rr(_c, _hx + 4 + (_b mod 3) * 56, _hy - 6 + floor(_b / 3) * 26, 52, 22, 3); anv_cx_fill(_c); }
    anv__solid(_c, [12, 7, 5]); anv_rr(_c, _hx + 14, _hy + 20, _hw - 6, _hh - 40, 60); anv_cx_fill(_c);
    _c.fill = anv__rad(_c, _hx + 80, _hy + _hh - 40, 4, _hx + 80, _hy + _hh - 60, 120, [[0, [255, 190, 80], 0.95], [0.35, [230, 90, 20], 0.7], [1, [120, 20, 5], 0]]);
    anv_cx_fill_rect(_c, _hx, _hy, _hw + 30, _hh);
    for (var _ci = 0; _ci < 70; _ci++) {
        var _cx = _hx + 26 + anv_rnd(_r) * (_hw - 30);
        var _cy = _hy + _hh - 34 - anv_rnd(_r) * 26;
        var _cr = 3 + anv_rnd(_r) * 6;
        var _hot = anv_rnd(_r);
        anv__solid(_c, (_hot > 0.6) ? [255, 210, 122] : ((_hot > 0.3) ? [240, 122, 34] : [138, 42, 16]));
        anv_cx_begin(_c); anv_cx_arc(_c, _cx, _cy, _cr, 0, 2 * pi); anv_cx_fill(_c);
    }
    // quench trough bottom right
    var _tx = 640, _ty = 470, _tw = 160, _th = 120;
    anv__solid(_c, [0, 0, 0], 0.45); anv_rr(_c, _tx + 6, _ty + 8, _tw, _th, 10); anv_cx_fill(_c);
    anv__solid(_c, [74, 47, 26]); anv_rr(_c, _tx, _ty, _tw, _th, 10); anv_cx_fill(_c);
    anv__pen(_c, [42, 26, 14], 1, 3);
    for (var _s = 1; _s < 4; _s++) { anv_cx_begin(_c); anv_cx_move(_c, _tx + 6, _ty + _s * 30); anv_cx_line(_c, _tx + _tw - 6, _ty + _s * 30); anv_cx_stroke(_c); }
    _c.fill = anv__lin(_c, 0, _ty + 14, 0, _ty + _th - 14, [[0, [29, 58, 68]], [1, [11, 26, 32]]]); anv_rr(_c, _tx + 12, _ty + 14, _tw - 24, _th - 28, 6); anv_cx_fill(_c);
    anv__pen(_c, [160, 220, 240], 0.18, 1);
    for (var _q = 0; _q < 6; _q++) { anv_cx_begin(_c); anv_cx_ellipse(_c, _tx + 40 + _q * 18, _ty + 40 + (_q mod 3) * 18, 14, 3, 0, 0, 2 * pi); anv_cx_stroke(_c); }
    // warm light from the hearth across the room, and a vignette
    _c.fill = anv__rad(_c, 60, 330, 20, 60, 330, 620, [[0, [255, 140, 50], 0.22], [1, [255, 140, 50], 0]]); anv_cx_fill_rect(_c, 0, 0, _W, _H);
    _c.fill = anv__rad(_c, _W / 2, _H / 2, _H * 0.3, _W / 2, _H / 2, _H * 0.9, [[0, [0, 0, 0], 0], [1, [0, 0, 0], 0.55]]); anv_cx_fill_rect(_c, 0, 0, _W, _H);
}

/// @function anv_draw_anvil(ctx)
/// @description The anvil seen from above: horn to the left, the polished face, the heel with the hardy and pritchel
/// holes, the feet splayed out beyond the face (what makes the shape read as an anvil), on a ringed stump.
function anv_draw_anvil(_c) {
    var _A = anv_anvil_box(), _cx = _A.x, _cy = _A.y + _A.h / 2;
    anv__solid(_c, [0, 0, 0], 0.5); anv_cx_begin(_c); anv_cx_ellipse(_c, _cx + _A.w / 2 + 10, _cy + 20, _A.w / 2 + 30, _A.h / 2 + 30, 0, 0, 2 * pi); anv_cx_fill(_c);
    // stump ring showing round the anvil's waist
    _c.fill = anv__rad(_c, _cx + _A.w / 2, _cy, 20, _cx + _A.w / 2, _cy, 160, [[0, [106, 68, 36]], [1, [58, 36, 18]]]);
    anv_cx_begin(_c); anv_cx_ellipse(_c, _cx + _A.w * 0.55, _cy + 6, 150, 96, 0, 0, 2 * pi); anv_cx_fill(_c);
    anv__pen(_c, [30, 15, 5], 0.6);
    for (var _ring = 30; _ring < 150; _ring += 14) { anv_cx_begin(_c); anv_cx_ellipse(_c, _cx + _A.w * 0.55, _cy + 6, _ring, _ring * 0.64, 0, 0, 2 * pi); anv_cx_stroke(_c); }
    // the feet: a rounded base plate with a waist, darker and lower, splayed beyond the face
    var _fx0 = _cx + 150, _fx1 = _cx + _A.w - 10, _ft = _cy - _A.h / 2 - 26, _fb = _cy + _A.h / 2 + 26;
    anv__solid(_c, [22, 24, 27]);
    anv_cx_begin(_c); anv_cx_move(_c, _fx0 + 20, _ft);
    anv_cx_quad(_c, (_fx0 + _fx1) / 2, _ft + 22, _fx1 - 20, _ft); anv_cx_quad(_c, _fx1 + 12, _ft, _fx1 + 12, _ft + 26);
    anv_cx_line(_c, _fx1 + 12, _fb - 26); anv_cx_quad(_c, _fx1 + 12, _fb, _fx1 - 20, _fb);
    anv_cx_quad(_c, (_fx0 + _fx1) / 2, _fb - 22, _fx0 + 20, _fb); anv_cx_quad(_c, _fx0 - 12, _fb, _fx0 - 12, _fb - 26);
    anv_cx_line(_c, _fx0 - 12, _ft + 26); anv_cx_quad(_c, _fx0 - 12, _ft, _fx0 + 20, _ft); anv_cx_close(_c); anv_cx_fill(_c);
    anv__pen(_c, [120, 130, 140], 0.35, 1.5); anv_cx_stroke(_c);
    // the body outline: horn (a cone to a point) + face + heel
    anv_cx_save(_c);
    anv_cx_begin(_c); anv_cx_move(_c, _cx - 40, _cy);
    anv_cx_quad(_c, _cx + 20, _cy - _A.h * 0.36, _cx + 110, _cy - _A.h / 2); anv_cx_line(_c, _cx + _A.w, _cy - _A.h / 2);
    anv_cx_line(_c, _cx + _A.w, _cy + _A.h / 2); anv_cx_line(_c, _cx + 110, _cy + _A.h / 2);
    anv_cx_quad(_c, _cx + 20, _cy + _A.h * 0.36, _cx - 40, _cy); anv_cx_close(_c);
    anv__solid(_c, [0, 0, 0], 0.6); anv__fill_offset(_c, 6, 8);
    _c.fill = anv__lin(_c, 0, _cy - _A.h / 2, 0, _cy + _A.h / 2, [[0, [124, 130, 136]], [0.18, [74, 79, 85]], [0.5, [46, 50, 55]], [0.85, [60, 65, 71]], [1, [28, 31, 34]]]);
    anv_cx_fill(_c);
    anv__pen(_c, [18, 20, 22], 1, 2); anv_cx_stroke(_c);
    // the horn is round: a highlight along its crown, fading to the point
    anv_cx_clip(_c);
    _c.stroke = anv__lin(_c, _cx - 40, 0, _cx + 116, 0, [[0, [210, 220, 230], 0], [1, [210, 220, 230], 0.45]]); _c.lw = 6;
    anv_cx_begin(_c); anv_cx_move(_c, _cx - 30, _cy - 2); anv_cx_quad(_c, _cx + 40, _cy - _A.h * 0.2, _cx + 116, _cy - _A.h * 0.26); anv_cx_stroke(_c);
    anv_cx_restore(_c);
    // the polished face (a lighter band) and the step to the horn
    _c.fill = anv__lin(_c, 0, _cy - _A.h / 2 + 10, 0, _cy + _A.h / 2 - 10, [[0, [142, 149, 156]], [0.5, [93, 100, 107]], [1, [61, 67, 73]]]);
    anv_rr(_c, _cx + 116, _cy - _A.h / 2 + 10, _A.w - 130, _A.h - 20, 6); anv_cx_fill(_c);
    var _r = anv_rng($A11);
    for (var _i = 0; _i < 260; _i++) {
        var _lite = anv_rnd(_r) < 0.5;
        if (_lite) anv__solid(_c, [255, 255, 255], 0.05); else anv__solid(_c, [0, 0, 0], 0.12);
        var _fx = _cx + 120 + anv_rnd(_r) * (_A.w - 140);
        var _fy = _cy - _A.h / 2 + 14 + anv_rnd(_r) * (_A.h - 28);
        var _fw = 1 + anv_rnd(_r) * 4;
        anv_cx_fill_rect(_c, _fx, _fy, _fw, 1);
    }
    anv__solid(_c, [16, 18, 20]); anv_rr(_c, _cx + _A.w - 52, _cy - 14, 22, 22, 2); anv_cx_fill(_c);
    anv_cx_begin(_c); anv_cx_arc(_c, _cx + _A.w - 86, _cy + 22, 7, 0, 2 * pi); anv_cx_fill(_c);
    anv__pen(_c, [210, 220, 230], 0.35, 1.2); anv_rr(_c, _cx + 116, _cy - _A.h / 2 + 10, _A.w - 130, _A.h - 20, 6); anv_cx_stroke(_c);
}

/// @function anv_draw_temper_chart(ctx, x, y, w, h)
/// @description The temper chart pinned to the wall: the colour ramp with the smith's names under it and the quench band
/// bracketed. Returns its geometry {sx, sw, sy, sh, py} (py = where the riding pointer's top sits).
/// ⛔ FOUND BY LOOKING (2026-10-04), a layout fix to the original's own sheet, every count unchanged: its pointer rode
/// across the chart's title (both sat in the 22 px above the ramp) and its colour names sat ON the inner rule. The paper
/// now starts 8 px higher and runs 28 px longer, the ramp drops 8 px, the names clear the rule and the quench label.
function anv_draw_temper_chart(_c, _x, _y, _w, _h) {
    var _paper0 = [243, 231, 204], _paper1 = [226, 209, 171], _ink = [42, 29, 18];
    var _pt = _y - 8, _ph = _h + 62;
    anv__solid(_c, [0, 0, 0], 0.5); anv_rr(_c, _x + 3, _pt + 5, _w, _ph, 5); anv_cx_fill(_c);
    _c.fill = anv__lin(_c, 0, _pt, 0, _pt + _ph, [[0, _paper0], [1, _paper1]]); anv_rr(_c, _x, _pt, _w, _ph, 5); anv_cx_fill(_c);
    anv__pen(_c, [106, 74, 34], 1, 1); anv_rr(_c, _x + 4, _pt + 4, _w - 8, _ph - 8, 3); anv_cx_stroke(_c);
    anv_dtext(_c, "THE COLOURS OF THE IRON", _x + _w / 2, _y + 3, 11, "bold", [106, 58, 24]);
    var _sx = _x + 12, _sw = _w - 24, _sy = _y + 30, _rh = _h - 16, _rb = _sy + _rh;
    for (var _i = 0; _i < _sw; _i++) { anv__solid(_c, anv_heat_rgb(_i / (_sw - 1))); anv_cx_fill_rect(_c, _sx + _i, _sy, 1, _rh); }
    anv__pen(_c, [40, 20, 5], 0.8); anv_cx_stroke_rect(_c, _sx + 0.5, _sy + 0.5, _sw - 1, _rh - 1);
    // the quench band bracketed
    var _qb = anv_quench_band(), _q0 = _sx + _qb[0] * _sw, _q1 = _sx + _qb[1] * _sw;
    anv__pen(_c, [30, 90, 106], 1, 2);
    anv_cx_begin(_c); anv_cx_move(_c, _q0, _rb + 4); anv_cx_line(_c, _q0, _rb + 8); anv_cx_line(_c, _q1, _rb + 8); anv_cx_line(_c, _q1, _rb + 4); anv_cx_stroke(_c);
    anv_dtext(_c, "quench", (_q0 + _q1) / 2, _rb + 15, 10, "italic", [30, 90, 106]);
    var _bands = anv_bands();
    for (var _b = 1; _b < array_length(_bands); _b++) { var _bx = _sx + _bands[_b][0] * _sw; anv__solid(_c, [40, 20, 5], 0.5); anv_cx_fill_rect(_c, _bx, _sy, 1, _rh); }
    // five names at band middles (the original found six crowded the hot end)
    var _names = [[0.1, "black"], [0.26, "blood"], [0.49, "cherry"], [0.72, "orange"], [0.94, "white"]];
    for (var _n = 0; _n < array_length(_names); _n++) anv_dtext(_c, _names[_n][1], _sx + _names[_n][0] * _sw, _rb + 27, 10, "", _ink);
    return { sx: _sx, sw: _sw, sy: _sy, sh: _rh, py: _sy - 21 };
}

/// @function anv_draw_pointer(ctx)
/// @description The small brass arrow that rides the temper chart, in a 20 x 22 box.
function anv_draw_pointer(_c) {
    anv__solid(_c, [0, 0, 0], 0.5); anv_cx_begin(_c); anv_cx_move(_c, 11, 21); anv_cx_line(_c, 2, 5); anv_cx_line(_c, 20, 5); anv_cx_fill(_c);
    _c.fill = anv__lin(_c, 0, 0, 18, 0, [[0, [138, 97, 32]], [0.5, [255, 230, 160]], [1, [138, 97, 32]]]);
    anv_cx_begin(_c); anv_cx_move(_c, 10, 19); anv_cx_line(_c, 1, 3); anv_cx_line(_c, 19, 3); anv_cx_close(_c); anv_cx_fill(_c);
    anv__pen(_c, [58, 36, 8], 1, 1); anv_cx_stroke(_c);
}

// ---------------------------------------------------------------------------------------------------------------
// The bar (drawn white and shaded; the scene tints it by heat)
// ---------------------------------------------------------------------------------------------------------------

/// @function anv_bar_path(ctx, profile, bar)
/// @description A new path round a profile along the bar: the top edge tang to tip, the bottom edge back, closed.
function anv_bar_path(_c, _prof, _L) {
    var _n = array_length(_prof), _i;
    anv_cx_begin(_c);
    for (_i = 0; _i < _n; _i++) {
        var _x = _L.x0 + (_i / (_n - 1)) * _L.len, _y = _L.cy - _prof[_i] * _L.hs;
        if (_i > 0) anv_cx_line(_c, _x, _y); else anv_cx_move(_c, _x, _y);
    }
    for (_i = _n - 1; _i >= 0; _i--) anv_cx_line(_c, _L.x0 + (_i / (_n - 1)) * _L.len, _L.cy + _prof[_i] * _L.hs);
    anv_cx_close(_c);
}

/// @function anv_draw_work(ctx, profile, marks, flaws, seed, strikes)
/// @description The workpiece: a white-to-grey body with a raised spine, facets where the hammer struck, fire scale the
/// blows knock off, and dark cracks where it was struck too cold - all CLIPPED to the bar (a concave layer clip), then
/// outlined. Drawn white so the scene can colour it by heat with a tint.
function anv_draw_work(_c, _prof, _marks, _flaws, _seed, _strikes) {
    var _L = anv_bar(), _n = array_length(_prof), _i;
    anv_cx_save(_c);
    anv_bar_path(_c, _prof, _L); anv_cx_clip(_c);
    _c.fill = anv__lin(_c, 0, _L.cy - _L.hs, 0, _L.cy + _L.hs, [[0, [154, 154, 154]], [0.35, [255, 255, 255]], [0.55, [232, 232, 232]], [1, [106, 106, 106]]]);
    anv_cx_fill_rect(_c, _L.x0 - 4, _L.cy - _L.hs - 4, _L.len + 8, _L.hs * 2 + 8);
    // a spine down the centre, and the edge bevels
    anv__pen(_c, [255, 255, 255], 0.8, 2); anv_cx_begin(_c); anv_cx_move(_c, _L.x0, _L.cy - 1); anv_cx_line(_c, _L.x0 + _L.len, _L.cy - 1); anv_cx_stroke(_c);
    anv__pen(_c, [0, 0, 0], 0.25, 1); anv_cx_begin(_c); anv_cx_move(_c, _L.x0, _L.cy + 2); anv_cx_line(_c, _L.x0 + _L.len, _L.cy + 2); anv_cx_stroke(_c);
    // hammer facets
    for (_i = 0; _i < array_length(_marks); _i++) {
        var _m = _marks[_i], _mp = _m.p, _mx = _L.x0 + (_mp / (_n - 1)) * _L.len, _mw = _prof[_mp] * _L.hs;
        var _rr2 = anv_rnd(anv_rng(_seed + _i * 31));
        if (_rr2 < 0.5) anv__solid(_c, [255, 255, 255], 0.12); else anv__solid(_c, [0, 0, 0], 0.09);
        anv_cx_begin(_c); anv_cx_ellipse(_c, _mx + (_rr2 - 0.5) * 6, _L.cy + (_rr2 - 0.5) * _mw * 0.7, 11, max(3, _mw * 0.32), 0, 0, 2 * pi); anv_cx_fill(_c);
    }
    // fire scale: dark flakes, fewer as blows knock them off (the original found 160 at 0.75 alpha read as chips)
    var _r = anv_rng(_seed ^ $5CA), _flakes = max(0, 56 - _strikes * 3);
    for (_i = 0; _i < _flakes; _i++) {
        var _fi = floor(anv_rnd(_r) * _n);
        var _fx = _L.x0 + (_fi / (_n - 1)) * _L.len + (anv_rnd(_r) - 0.5) * 8;
        var _fw = _prof[_fi] * _L.hs;
        anv__solid(_c, [40, 30, 24], 0.18 + anv_rnd(_r) * 0.22);
        var _ey = _L.cy + (anv_rnd(_r) * 2 - 1) * _fw * 0.8;
        var _erx = 1.5 + anv_rnd(_r) * 3;
        var _ery = 0.8 + anv_rnd(_r) * 1.5;
        var _erot = anv_rnd(_r) * 3;
        anv_cx_begin(_c); anv_cx_ellipse(_c, _fx, _ey, _erx, _ery, _erot, 0, 2 * pi); anv_cx_fill(_c);
    }
    // cracks
    for (_i = 0; _i < array_length(_flaws); _i++) {
        var _p = _flaws[_i], _cxp = _L.x0 + (_p / (_n - 1)) * _L.len, _cw = _prof[_p] * _L.hs, _cr = anv_rng(_seed + _p * 131 + _i);
        anv__pen(_c, [10, 6, 4], 0.95, 1.6);
        anv_cx_begin(_c);
        var _yy = _L.cy - _cw;
        anv_cx_move(_c, _cxp, _yy);
        for (var _s = 1; _s <= 6; _s++) { _yy += _cw * 0.3; anv_cx_line(_c, _cxp + (anv_rnd(_cr) - 0.5) * 8, _yy); }
        anv_cx_stroke(_c);
    }
    anv_cx_restore(_c);
    anv_bar_path(_c, _prof, _L); anv__pen(_c, [40, 40, 40], 0.9, 1.4); anv_cx_stroke(_c);
}

/// @function anv_draw_glow(ctx, profile)
/// @description The halo round the bar (white; the scene tints it and fades it with the heat). The original blurs it
/// with a CSS filter; the bake blurs it by resampling (anv_bake_glow).
function anv_draw_glow(_c, _prof) {
    anv_cx_save(_c);
    anv_bar_path(_c, _prof, anv_bar());
    anv__solid(_c, [255, 255, 255], 0.9); anv_cx_fill(_c);
    anv__pen(_c, [255, 255, 255], 0.6, 14); anv_cx_stroke(_c);
    anv_cx_restore(_c);
}

/// @function anv_draw_target(ctx, profile)
/// @description The target silhouette chalked on the anvil face, dashed.
function anv_draw_target(_c, _prof) {
    anv_cx_save(_c);
    anv_cx_set_dash(_c, [6, 4]); anv__pen(_c, [245, 240, 225], 0.75, 2);
    anv_bar_path(_c, _prof, anv_bar()); anv_cx_stroke(_c);
    anv_cx_set_dash(_c, []);
    anv_cx_restore(_c);
}

/// @function anv_draw_hammer(ctx, w, h)
/// @description The hammer from above, head down: a round striking face with a peen behind it and the haft running off,
/// in a w x h box (the scene's is 140 x 150, anchored at 0.5, 0.42).
function anv_draw_hammer(_c, _w, _h) {
    var _cx = _w / 2, _cy = _h * 0.42;
    anv__solid(_c, [0, 0, 0], 0.35); anv_cx_begin(_c); anv_cx_ellipse(_c, _cx + 8, _cy + 12, 30, 24, 0, 0, 2 * pi); anv_cx_fill(_c);
    _c.stroke = anv__lin(_c, _cx - 10, _cy, _cx + 90, _cy + 90, [[0, [154, 106, 58]], [1, [90, 58, 28]]]); _c.lw = 12; _c.cap = 1;
    anv_cx_begin(_c); anv_cx_move(_c, _cx + 6, _cy + 10); anv_cx_line(_c, _cx + 60, _cy + 98); anv_cx_stroke(_c); _c.cap = 0;
    _c.fill = anv__rad(_c, _cx - 8, _cy - 8, 2, _cx, _cy, 30, [[0, [201, 208, 214]], [0.6, [93, 100, 107]], [1, [38, 42, 46]]]);
    anv_rr(_c, _cx - 30, _cy - 18, 60, 36, 10); anv_cx_fill(_c);
    anv__solid(_c, [123, 131, 138]); anv_cx_begin(_c); anv_cx_arc(_c, _cx - 16, _cy, 15, 0, 2 * pi); anv_cx_fill(_c);
    anv__pen(_c, [26, 29, 32], 1, 1.5); anv_cx_stroke(_c);
    anv__solid(_c, [255, 255, 255], 0.35); anv_cx_begin(_c); anv_cx_arc(_c, _cx - 20, _cy - 4, 5, 0, 2 * pi); anv_cx_fill(_c);
}

/// @function anv_draw_spark(ctx)
/// @description A spark: a short white streak with a hot core, in a 12 x 4 box (tinted per spark by the scene).
function anv_draw_spark(_c) {
    _c.fill = anv__lin(_c, 0, 0, 12, 0, [[0, [255, 255, 255], 0], [0.7, [255, 255, 255], 0.9], [1, [255, 255, 255], 1]]);
    anv_rr(_c, 0, 0.5, 12, 3, 1.5); anv_cx_fill(_c);
}

/// @function anv_draw_puff(ctx)
/// @description A steam puff: a soft white cloud in a 48 x 48 box.
function anv_draw_puff(_c) {
    _c.fill = anv__rad(_c, 24, 24, 2, 24, 24, 24, [[0, [255, 255, 255], 0.8], [1, [255, 255, 255], 0]]); anv_cx_fill_rect(_c, 0, 0, 48, 48);
}

// ---------------------------------------------------------------------------------------------------------------
// The finished blade
// ---------------------------------------------------------------------------------------------------------------

/// @function anv_draw_blade(ctx, profile, meta, metal, marks, flaws, x, y, len, hs, seed)
/// @description The forged piece as quenched and finished: the player's own profile (ground smooth - a 5-tap average,
/// the SHAPE stays theirs), polished in its metal, with the bevel, a fuller on a sword, the hammer facets and any cracks,
/// and a grip, guard and pommel (sword, dagger, claw), a wooden haft and socket (spear, mace) or a haft through the eye
/// (axe, whose head is drawn at 62% of the length). Drawn horizontally from (x, y): length `len`, half-width scale `hs`.
function anv_draw_blade(_c, _raw, _meta, _metal, _marks, _flaws, _x, _y, _len, _hs, _seed) {
    var _n = array_length(_raw), _prof = array_create(_n, 0), _i, _k0;
    var _fam = _meta.family;
    if (_fam == "axe") { _x += _len * 0.18; _len *= 0.62; }
    for (_i = 0; _i < _n; _i++) { var _s0 = 0, _c0 = 0; for (_k0 = max(0, _i - 2); _k0 <= min(_n - 1, _i + 2); _k0++) { _s0 += _raw[_k0]; _c0++; } _prof[_i] = _s0 / _c0; }
    var _M = anv_metal_ramp(_metal), _tang = variable_struct_exists(_meta, "tang") ? _meta.tang : 0;
    var _tangAt = floor(((is_numeric(_tang) && _tang != 0) ? _tang : 0) * (_n - 1));
    var _eye = (variable_struct_exists(_meta, "eye") && is_numeric(_meta.eye) && _meta.eye != 0) ? _meta.eye : 0.2;
    var _gx = _x + (_tangAt / (_n - 1)) * _len, _r = anv_rng(_seed ^ $F1);
    // fittings first (under the blade)
    if (_fam == "axe") {
        var _ei = anv_jsround(_eye * (_n - 1)), _ex = _x + (_ei / (_n - 1)) * _len;
        anv__solid(_c, [0, 0, 0], 0.4); anv_rr(_c, _ex - 6, _y - _hs * 1.6, 20, _hs * 4.2, 8); anv_cx_fill(_c);
        _c.fill = anv__lin(_c, _ex - 10, 0, _ex + 10, 0, [[0, [90, 58, 28]], [0.5, [192, 138, 80]], [1, [90, 58, 28]]]);
        anv_rr(_c, _ex - 10, _y - _hs * 1.7, 20, _hs * 4.2, 8); anv_cx_fill(_c);
        anv__pen(_c, [60, 30, 10], 0.4);
        for (var _gk = 0; _gk < 6; _gk++) { anv_cx_begin(_c); anv_cx_move(_c, _ex - 7 + _gk * 2.6, _y - _hs * 1.6); anv_cx_line(_c, _ex - 6 + _gk * 2.6, _y + _hs * 2.4); anv_cx_stroke(_c); }
    } else if (_fam == "spear" || _fam == "mace") {
        _c.fill = anv__lin(_c, 0, _y - 8, 0, _y + 8, [[0, [154, 106, 58]], [0.5, [192, 138, 80]], [1, [90, 58, 28]]]);
        anv_rr(_c, _x - _len * 0.45, _y - 8, _len * 0.45 + (_gx - _x) + 4, 16, 6); anv_cx_fill(_c);
        anv__pen(_c, [60, 30, 10], 0.4);
        for (var _k = 0; _k < 8; _k++) { anv_cx_begin(_c); anv_cx_move(_c, _x - _len * 0.45 + 6, _y - 5 + _k * 1.5); anv_cx_bezier(_c, _x - _len * 0.2, _y - 6 + _k * 1.6, _x, _y - 4 + _k * 1.4, _gx, _y - 5 + _k * 1.5); anv_cx_stroke(_c); }
        anv__solid(_c, [58, 42, 26]);
        for (var _wr = 0; _wr < 3; _wr++) { anv_rr(_c, _gx - 18 - _wr * 9, _y - 9, 5, 18, 2); anv_cx_fill(_c); }
    } else {
        var _gl = (_fam == "dagger") ? 70 : ((_fam == "claw") ? 56 : 104);
        _c.fill = anv__lin(_c, 0, _y - 9, 0, _y + 9, [[0, [90, 42, 26]], [0.5, [138, 74, 42]], [1, [58, 26, 14]]]);
        anv_rr(_c, _gx - _gl, _y - 9, _gl, 18, 5); anv_cx_fill(_c);
        anv__pen(_c, [20, 8, 4], 0.6, 1.2);
        for (var _wv = _gx - _gl + 4; _wv < _gx - 4; _wv += 7) { anv_cx_begin(_c); anv_cx_move(_c, _wv, _y - 9); anv_cx_line(_c, _wv + 5, _y + 9); anv_cx_stroke(_c); }
        _c.fill = anv__lin(_c, 0, _y - 40, 0, _y + 40, [[0, [106, 74, 28]], [0.5, [240, 208, 138]], [1, [106, 74, 28]]]);
        var _gh = (_fam == "claw") ? 22 : 34 + floor(anv_rnd(_r) * 10);
        anv_rr(_c, _gx - 8, _y - _gh, 12, _gh * 2, 4); anv_cx_fill(_c);
        anv_cx_begin(_c); anv_cx_arc(_c, _gx - 2, _y - _gh, 6, 0, 2 * pi); anv_cx_arc(_c, _gx - 2, _y + _gh, 6, 0, 2 * pi); anv_cx_fill(_c);
        anv_cx_begin(_c); anv_cx_ellipse(_c, _gx - _gl - 8, _y, 12, 13, 0, 0, 2 * pi); anv_cx_fill(_c);
        anv__pen(_c, [58, 36, 8], 1, 1); anv_cx_stroke(_c);
    }
    // the blade: from the tang end to the tip, polished
    anv_cx_save(_c);
    anv_cx_begin(_c);
    for (_i = _tangAt; _i < _n; _i++) { var _yy = _y - _prof[_i] * _hs, _px = _x + (_i / (_n - 1)) * _len; if (_i == _tangAt) anv_cx_move(_c, _px, _yy); else anv_cx_line(_c, _px, _yy); }
    for (_i = _n - 1; _i >= _tangAt; _i--) anv_cx_line(_c, _x + (_i / (_n - 1)) * _len, _y + _prof[_i] * _hs);
    anv_cx_close(_c);
    anv__solid(_c, [0, 0, 0], 0.45); anv__fill_offset(_c, 5, 7);
    _c.fill = anv__lin(_c, 0, _y - _hs, 0, _y + _hs, [[0, _M[2]], [0.3, _M[0]], [0.5, _M[1]], [0.7, _M[0]], [1, _M[2]]]); anv_cx_fill(_c);
    anv_cx_clip(_c);
    // the ground edge bevels, a fuller, the facets and any cracks
    anv__pen(_c, [255, 255, 255], 0.55, 1.2); anv_cx_begin(_c);
    for (_i = _tangAt; _i < _n; _i++) { var _by = _y - _prof[_i] * _hs * 0.62, _bx = _x + (_i / (_n - 1)) * _len; if (_i == _tangAt) anv_cx_move(_c, _bx, _by); else anv_cx_line(_c, _bx, _by); }
    anv_cx_stroke(_c);
    anv__pen(_c, [0, 0, 0], 0.3); anv_cx_begin(_c);
    for (_i = _tangAt; _i < _n; _i++) { var _by2 = _y + _prof[_i] * _hs * 0.62, _bx2 = _x + (_i / (_n - 1)) * _len; if (_i == _tangAt) anv_cx_move(_c, _bx2, _by2); else anv_cx_line(_c, _bx2, _by2); }
    anv_cx_stroke(_c);
    var _ft = floor(_tangAt + (_n - _tangAt) * 0.7), _fx0 = _x + (_tangAt / (_n - 1)) * _len + 6, _fx1 = _x + (_ft / (_n - 1)) * _len;
    if (variable_struct_exists(_meta, "fuller") && _meta.fuller) {
        anv__pen(_c, [0, 0, 0], 0.35, 4); anv_cx_begin(_c); anv_cx_move(_c, _fx0, _y); anv_cx_line(_c, _fx1, _y); anv_cx_stroke(_c);
        anv__pen(_c, [255, 255, 255], 0.4, 1); anv_cx_begin(_c); anv_cx_move(_c, _fx0, _y - 2); anv_cx_line(_c, _fx1, _y - 2); anv_cx_stroke(_c);
    }
    if (_fam == "mace") {
        var _fls = (variable_struct_exists(_meta, "flanges") && is_numeric(_meta.flanges) && _meta.flanges != 0) ? _meta.flanges : 4;
        anv__pen(_c, [0, 0, 0], 0.45, 2);
        for (var _fl = 0; _fl < _fls * 2; _fl++) {
            var _fk = _tangAt + floor((_n - _tangAt) * (_fl + 0.5) / (_fls * 2)), _flx = _x + (_fk / (_n - 1)) * _len;
            anv_cx_begin(_c); anv_cx_move(_c, _flx, _y - _hs); anv_cx_line(_c, _flx, _y + _hs); anv_cx_stroke(_c);
        }
    }
    // facets: faint, long, thin (the original found round blots made every blade look spotted)
    for (_i = 0; _i < array_length(_marks); _i++) {
        var _mk = _marks[_i], _mp = _mk.p;
        if (_mp < _tangAt) continue;
        var _mr = anv_rnd(anv_rng(_seed + _i * 17));
        if (_mr < 0.5) anv__solid(_c, [255, 255, 255], 0.06); else anv__solid(_c, [0, 0, 0], 0.045);
        anv_cx_begin(_c); anv_cx_ellipse(_c, _x + (_mp / (_n - 1)) * _len + (_mr - 0.5) * 5, _y + (_mr - 0.5) * _prof[_mp] * _hs * 0.8, 12, max(2, _prof[_mp] * _hs * 0.22), 0, 0, 2 * pi); anv_cx_fill(_c);
    }
    if (_fam == "axe") {
        var _ei2 = anv_jsround(_eye * (_n - 1)), _ex2 = _x + (_ei2 / (_n - 1)) * _len;
        anv__solid(_c, [70, 40, 18], 0.9); anv_cx_begin(_c); anv_cx_ellipse(_c, _ex2, _y, 9, _prof[_ei2] * _hs * 0.55, 0, 0, 2 * pi); anv_cx_fill(_c);
        anv__pen(_c, [30, 15, 5], 0.6); anv_cx_stroke(_c);
    }
    for (_i = 0; _i < array_length(_flaws); _i++) {
        var _p = _flaws[_i], _cw = _prof[_p] * _hs, _cr = anv_rng(_seed + _p * 97 + _i), _pxp = _x + (_p / (_n - 1)) * _len;
        anv__pen(_c, [10, 6, 4], 0.9, 1.4); anv_cx_begin(_c);
        var _cy2 = _y - _cw;
        anv_cx_move(_c, _pxp, _cy2);
        for (var _s = 1; _s <= 5; _s++) { _cy2 += _cw * 0.36; anv_cx_line(_c, _pxp + (anv_rnd(_cr) - 0.5) * 7, _cy2); }
        anv_cx_stroke(_c);
    }
    _c.fill = anv__lin(_c, _x, 0, _x + _len, 0, [[0, [255, 255, 255], 0], [0.55, [255, 255, 255], 0.28], [0.62, [255, 255, 255], 0]]);
    anv_cx_fill_rect(_c, _x, _y - _hs, _len, _hs * 2);
    anv_cx_restore(_c);
    anv__pen(_c, [20, 24, 28], 0.8, 1); anv_cx_begin(_c);
    for (_i = _tangAt; _i < _n; _i++) { var _oy = _y - _prof[_i] * _hs, _ox = _x + (_i / (_n - 1)) * _len; if (_i == _tangAt) anv_cx_move(_c, _ox, _oy); else anv_cx_line(_c, _ox, _oy); }
    for (_i = _n - 1; _i >= _tangAt; _i--) anv_cx_line(_c, _x + (_i / (_n - 1)) * _len, _y + _prof[_i] * _hs);
    anv_cx_close(_c); anv_cx_stroke(_c);
}

// ---------------------------------------------------------------------------------------------------------------
// Cards, ledger, plaques, status, verdict
// ---------------------------------------------------------------------------------------------------------------

/// @function anv_draw_paper(ctx, x, y, w, h, seed)
/// @description A paper card: shadow, the cream ground, a fleck grain and a warm stain in one corner.
function anv_draw_paper(_c, _x, _y, _w, _h, _seed) {
    anv__solid(_c, [0, 0, 0], 0.5); anv_rr(_c, _x + 4, _y + 6, _w, _h, 5); anv_cx_fill(_c);
    _c.fill = anv__lin(_c, 0, _y, 0, _y + _h, [[0, [243, 231, 204]], [1, [226, 209, 171]]]); anv_rr(_c, _x, _y, _w, _h, 5); anv_cx_fill(_c);
    var _r = anv_rng(_seed);
    for (var _i = 0; _i < _w * _h / 70; _i++) {
        var _dk = anv_rnd(_r) < 0.5;
        if (_dk) anv__solid(_c, [140, 100, 50], 0.08); else anv__solid(_c, [255, 255, 255], 0.2);
        var _px = _x + anv_rnd(_r) * _w;
        var _py = _y + anv_rnd(_r) * _h;
        var _pw = 1 + anv_rnd(_r) * 2;
        anv_cx_fill_rect(_c, _px, _py, _pw, 1);
    }
    _c.fill = anv__rad(_c, _x + _w * 0.8, _y + _h * 0.9, 2, _x + _w * 0.8, _y + _h * 0.9, 40, [[0, [60, 30, 10], 0.18], [1, [60, 30, 10], 0]]);
    anv_cx_fill_rect(_c, _x, _y, _w, _h);
}

/// @function anv_draw_order(ctx, w, h, info)
/// @description The work order card: what is to be forged ({title, sub, profile, task, task2}), with a small drawing of
/// the pattern on it.
function anv_draw_order(_c, _w, _h, _info) {
    anv_draw_paper(_c, 0, 0, _w - 8, _h - 10, $0DE);
    var _cw = _w - 8, _ink = [42, 29, 18];
    anv__pen(_c, [122, 74, 26], 1, 1.2); anv_rr(_c, 6, 6, _cw - 12, _h - 22, 3); anv_cx_stroke(_c);
    anv_dtext(_c, "WORK ORDER", _cw / 2, 20, 11, "bold", [122, 58, 20]);
    var _ts = anv_fit_text(_info.title, _cw - 24, 18);
    anv_dtext(_c, _info.title, _cw / 2, 44, _ts, "bold", _ink);
    anv_dtext(_c, _info.sub, _cw / 2, 64, 12, "italic", [90, 64, 48]);
    if (is_array(_info.profile)) {
        anv_cx_save(_c);
        var _pr = _info.profile, _n = array_length(_pr), _sx = 20, _sl = _cw - 40, _sy = 96, _hh = 16, _i;
        anv_cx_begin(_c);
        for (_i = 0; _i < _n; _i++) { var _x = _sx + _i / (_n - 1) * _sl, _y = _sy - _pr[_i] * _hh; if (_i > 0) anv_cx_line(_c, _x, _y); else anv_cx_move(_c, _x, _y); }
        for (_i = _n - 1; _i >= 0; _i--) anv_cx_line(_c, _sx + _i / (_n - 1) * _sl, _sy + _pr[_i] * _hh);
        anv_cx_close(_c);
        anv__solid(_c, [60, 40, 20], 0.18); anv_cx_fill(_c);
        anv__pen(_c, [58, 36, 16], 1, 1.2); anv_cx_stroke(_c);
        anv_cx_restore(_c);
    }
    // fitted, as the title already is (Libre Baskerville sets wider than the original's Palatino: found by looking)
    anv_dtext(_c, _info.task, _cw / 2, 130, anv_fit_text(_info.task, _cw - 24, 12, ""), "", _ink);
    anv_dtext(_c, _info.task2, _cw / 2, 148, anv_fit_text(_info.task2, _cw - 24, 11, "italic"), "italic", [90, 64, 48]);
}

/// @function anv_draw_tally(ctx, w, h, info)
/// @description The tally board: heats, blows, cracks, how close to the pattern, and the colour now
/// ({heats, maxHeats, strikes, flaws, shape, colour}).
function anv_draw_tally(_c, _w, _h, _info) {
    var _cw = _w - 8;
    anv__solid(_c, [0, 0, 0], 0.5); anv_rr(_c, 4, 6, _cw, _h - 10, 6); anv_cx_fill(_c);
    _c.fill = anv__lin(_c, 0, 0, 0, _h, [[0, [42, 38, 34]], [1, [26, 23, 20]]]); anv_rr(_c, 0, 0, _cw, _h - 10, 6); anv_cx_fill(_c);
    anv__pen(_c, [138, 106, 58], 1, 1.5); anv_rr(_c, 5, 5, _cw - 10, _h - 20, 4); anv_cx_stroke(_c);
    anv_dtext(_c, "THE TALLY", _cw / 2, 18, 11, "bold", [201, 160, 106]);
    var _rows = [["Heats", string(_info.heats) + " of " + string(_info.maxHeats)], ["Blows", string(_info.strikes)], ["Cracks", string(_info.flaws)], ["To the pattern", string(_info.shape) + "%"], ["The iron is", _info.colour]];
    for (var _i = 0; _i < array_length(_rows); _i++) {
        var _y = 40 + _i * 24;
        anv_dtext(_c, _rows[_i][0], 16, _y, 13, "italic", [184, 164, 138], 1, fa_left);
        anv_dtext(_c, _rows[_i][1], _cw - 16, _y, 14, "bold", (_i == 2 && _info.flaws != 0) ? [255, 138, 106] : [241, 223, 180], 1, fa_right);
        anv__solid(_c, [200, 160, 100], 0.15); anv_cx_fill_rect(_c, 14, _y + 11, _cw - 28, 1);
    }
}

/// @function anv_draw_plaque(ctx, x, y, w, h, text, state)
/// @description A brass plaque button. state: "on" (hovered), "idle", "off" (unavailable).
function anv_draw_plaque(_c, _x, _y, _w, _h, _text, _state) {
    anv_cx_save(_c);
    anv__solid(_c, [0, 0, 0], 0.45); anv_rr(_c, _x + 3, _y + 4, _w, _h, 6); anv_cx_fill(_c);
    var _stops;
    if (_state == "off") _stops = [[0, [106, 90, 68]], [1, [58, 46, 32]]];
    else if (_state == "on") _stops = [[0, [255, 240, 176]], [0.5, [232, 184, 80]], [1, [154, 106, 30]]];
    else _stops = [[0, [242, 216, 144]], [0.5, [201, 154, 66]], [1, [138, 97, 32]]];
    _c.fill = anv__lin(_c, 0, _y, 0, _y + _h, _stops); anv_rr(_c, _x, _y, _w, _h, 6); anv_cx_fill(_c);
    anv__pen(_c, [60, 40, 10], 0.75, 1); anv_rr(_c, _x + 3, _y + 3, _w - 6, _h - 6, 4); anv_cx_stroke(_c);
    var _ts = anv_fit_text(_text, _w - 24, 15);
    var _off = (_state == "off");
    anv_dtext(_c, _text, _x + _w / 2 + 0.8, _y + _h / 2 + 1.8, _ts, "bold", _off ? [200, 180, 150] : [255, 245, 210], _off ? 0.45 : 0.6);
    anv_dtext(_c, _text, _x + _w / 2, _y + _h / 2 + 1, _ts, "bold", _off ? [30, 20, 10] : [58, 36, 8], _off ? 0.8 : 1);
    anv_cx_restore(_c);
}

/// @function anv_draw_status(ctx, W, H, text)
/// @description The status line under the anvil: italic, cream on a soft shadow, fitted to W.
function anv_draw_status(_c, _W, _H, _text) {
    var _ts = anv_fit_text(_text, _W - 10, 17, "italic");
    anv_dtext(_c, _text, _W / 2 + 1, _H / 2 + 1, _ts, "italic", [0, 0, 0], 0.7);
    anv_dtext(_c, _text, _W / 2, _H / 2, _ts, "italic", [241, 223, 180]);
}

/// @function anv_draw_verdict(ctx, W, H, info)
/// @description The finished plate: the forged piece large on a cloth, its grade struck on a plaque (gold from Fine up,
/// pewter below), the verdict lines under it ({profile, meta, metal, marks, flaws, seed, grade, title, sub, foot}).
function anv_draw_verdict(_c, _W, _H, _info) {
    anv__solid(_c, [10, 6, 3], 0.84); anv_cx_fill_rect(_c, 0, 0, _W, _H);
    var _cloth = anv__lin(_c, 0, 150, 0, 420, [[0, [58, 26, 20]], [1, [34, 16, 12]]]);
    anv__solid(_c, [0, 0, 0], 0.5); anv_rr(_c, 64, 160, _W - 120, 250, 10); anv_cx_fill(_c);
    _c.fill = _cloth; anv_rr(_c, 58, 152, _W - 120, 250, 10); anv_cx_fill(_c);
    anv__pen(_c, [200, 150, 90], 0.35); anv_cx_set_dash(_c, [4, 4]); anv_rr(_c, 70, 164, _W - 144, 226, 8); anv_cx_stroke(_c); anv_cx_set_dash(_c, []);
    _c.fill = anv__rad(_c, _W / 2, 276, 20, _W / 2, 276, 360, [[0, [255, 220, 160], 0.18], [1, [255, 220, 160], 0]]); anv_cx_fill_rect(_c, 0, 0, _W, _H);
    anv_draw_blade(_c, _info.profile, _info.meta, _info.metal, _info.marks, _info.flaws, 230, 276, 500, 60, _info.seed);
    var _good = (_info.grade >= 3);
    var _x = _W / 2 - 230, _y = 438, _w = 460, _h = 60;
    anv__solid(_c, [0, 0, 0], 0.45); anv_rr(_c, _x + 3, _y + 4, _w, _h, 6); anv_cx_fill(_c);
    var _stops = _good ? [[0, [246, 220, 148]], [0.5, [201, 154, 66]], [1, [138, 97, 32]]] : [[0, [216, 205, 189]], [0.5, [154, 142, 126]], [1, [94, 84, 72]]];
    _c.fill = anv__lin(_c, 0, _y, 0, _y + _h, _stops); anv_rr(_c, _x, _y, _w, _h, 6); anv_cx_fill(_c);
    anv__pen(_c, [60, 40, 10], 0.7); anv_rr(_c, _x + 3, _y + 3, _w - 6, _h - 6, 4); anv_cx_stroke(_c);
    var _ts = anv_fit_text(_info.title, _w - 24, 20);
    anv_dtext(_c, _info.title, _W / 2, _y + 20, _ts, "bold", [255, 245, 210], 0.6);
    anv_dtext(_c, _info.title, _W / 2, _y + 19, _ts, "bold", [58, 36, 8]);
    var _ss = anv_fit_text(_info.sub, _w - 24, 13, "italic");
    anv_dtext(_c, _info.sub, _W / 2, _y + 43, _ss, "italic", [74, 48, 16]);
    anv_dtext(_c, _info.foot, _W / 2, 530, 14, "italic", [232, 212, 168]);
}
