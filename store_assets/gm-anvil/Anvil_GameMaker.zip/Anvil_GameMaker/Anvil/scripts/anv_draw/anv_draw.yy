{
  "$GMScript": "v1",
  "%Name": "anv_draw",
  "name": "anv_draw",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}