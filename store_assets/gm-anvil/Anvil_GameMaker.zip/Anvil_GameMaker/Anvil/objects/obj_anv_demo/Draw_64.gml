/// @description The forge (or the armoury menu), drawn in GUI space so the built-in mouse input lines up.
anv_demo_draw(demo);
