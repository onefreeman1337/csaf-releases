/// @description Anvil demo - a stock armoury to forge from - and the headless entry point (-selftest).
/// ⛔ The crash handler is installed FIRST, and every variable a later event reads is declared ABOVE the early exits:
/// Clean Up always runs, even when Create leaves early.
exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("anv_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.anv_stage) + ": " + string(_ex.message) + " | " + string(_ex.stacktrace));
    file_text_close(_f);
    game_end();
});
global.anv_stage = 0;
demo = anv_demo_state();
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";
if (string_pos("-selftest", _args) > 0) { global.anv_stage = 1; anv_selftest_write(anv_selftest_run()); game_end(); exit; }
