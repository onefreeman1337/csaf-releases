/// @description One forge frame (or the armoury menu).
anv_demo_step(demo);
