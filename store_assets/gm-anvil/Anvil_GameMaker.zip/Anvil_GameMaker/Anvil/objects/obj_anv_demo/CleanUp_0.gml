/// @description Free the forge's surfaces, the previews, the rack and the shared cache.
if (variable_instance_exists(id, "demo") && is_struct(demo)) anv_demo_free(demo);
