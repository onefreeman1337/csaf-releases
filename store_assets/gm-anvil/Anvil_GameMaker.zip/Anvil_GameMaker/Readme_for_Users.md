# Anvil - A Forging Minigame Drawn in Code, for GameMaker

A hot-metal forging minigame that plugs into any crafting system. The player works a glowing bar on the anvil toward a
pattern chalked on its face, reads the heat by the colour of the metal, puts it back in the hearth a limited number of
times, and quenches it - best at cherry red. The piece is then shown FINISHED exactly as the player shaped it, and a
quality score and grade are handed back to your game. Nothing is an image file: the smithy, the anvil, the bar, the
sparks, the steam and every finished blade are drawn by the package.

- **The pattern is your weapon.** Name a weapon the way your database does and the pattern is generated from it: the
  weapon type picks the family (sword, dagger, axe, spear, mace, claw), its name picks the metal (steel, iron, bronze,
  mithril, blacksteel), and the name, seed and attack pick its proportions - blade width, taper, point (spear, clip,
  round, leaf, hook), ricasso, tang, a fuller on a sword, a beard on an axe, three to six flanges on a mace. Every weapon in
  your game forges to its own silhouette, the same one every time.
- **The metal behaves.** A blow moves hot metal a fixed step toward the pattern, more at white heat and finer as it cools;
  struck where it is already right, it overshoots. It cools while you work, and a blow on metal gone too cold cracks it.
  The colour chart on the wall names the heat (black, blood red, cherry, orange, white) and a brass pointer rides it.
- **The finished piece is the player's own.** Their profile, ground smooth and polished in its metal, with their hammer
  facets and any cracks, and a grip, guard and pommel (sword, dagger, claw), a haft and socket (spear, mace) or a haft
  through the eye (axe). Keep it: `anv_blade_sprite` hands it to your inventory as a sprite.
- **It plugs into your crafting.** Anvil does not replace a crafting system; it is the step where the player makes the
  thing. Open it when your crafting crafts, read the result (quality 0-100, grade 1 Crude, 2 Serviceable, 3 Fine,
  4 Masterwork), and decide what that means in your game.

Ported from our RPG Maker MZ plugin Anvil and held to it: the in-engine suite runs the forging model and every drawn thing
through both and checks they agree (see Verification).

## Install

1. In GameMaker, **Tools > Import Local Package**, choose `Anvil.yymps`, and import everything.
2. Run the project with `rm_anv_demo` first in the room order: a stock armoury of twelve weapons - Up/Down choose,
   Left/Right difficulty, Enter forges. In the forge: Left/Right move the hammer, Enter (or Space, or Z) strikes, Shift
   reheats, Q quenches, Escape leaves; or click the bar to strike there and click the plaques.

Requires GameMaker 2024.14 or later. Built and tested on runtime 2024.14.4.268 (the VM, Windows). Pure GML, no extension;
nothing here depends on GMRT.

## Quickstart

```gml
// Create - when the player starts crafting
my_target = anv_weapon("Mithril Sword", "Sword", 40, "Light as a feather");
my_forge = anv_scene_create(my_target, { difficulty: "normal", min_quality: 65 });

// Step
anv_scene_step(my_forge);
if (anv_scene_done(my_forge)) {
    var _r = anv_scene_result(my_forge);   // undefined if the player left without quenching
    if (is_struct(_r) && _r.cleared) {
        my_icon = anv_blade_sprite(my_target, my_forge.forge, 96, 32);   // the piece as they made it
        // give the item, set its stats from _r.quality, ...
    }
    anv_scene_free(my_forge);
}

// Draw GUI
anv_scene_draw(my_forge, 0, 0, display_get_gui_width(), display_get_gui_height());
```

`anv_scene_step` reads the keyboard and the mouse itself (the mouse in GUI coordinates, so draw the scene in Draw GUI).
To use your own bindings, pass an input each step: `anv_scene_step(my_forge, anv_input(left, right, strike, reheat,
quench, leave, mouse_x, mouse_y, click, right_click))` - `left` and `right` are repeating presses, the rest single
presses, the mouse in the coordinates you draw the scene in.

One step is one 1/60 s frame, the original's timing (the cooling, the hammer's fall, the hearth slide and the quench are
counted in frames). At another game speed, call `anv_scene_step` as many times as a 60 fps frame would have run.

`my_forge.events` lists what happened during the last step - `"strike"`, `"crack"`, `"reheat"`, `"quench"`, `"finish"`,
`"leave"` - so your game can play its own sounds. Anvil ships no audio.

## The result

`anv_scene_result(scene)` returns, once the piece is quenched and judged:

| field | meaning |
| --- | --- |
| `quality` | 0 to 100: the shape (60%), the quench (25%) and the heats used (15%), less 8 per crack |
| `grade`, `gradeName` | 1 Crude (0-39), 2 Serviceable (40-64), 3 Fine (65-84), 4 Masterwork (85-100) |
| `shape` | how close the work came to the pattern, in percent |
| `quench`, `colour`, `note` | the quench's score in percent, the colour it was done at, and `"true"` (cherry), `"hot"`, `"warped"`, `"cool"` or `"soft"` |
| `heats`, `strikes`, `flaws` | heats used, blows struck, cracks |
| `cleared` | `quality >= min_quality` |

## Functions

| function | what it does |
| --- | --- |
| `anv_weapon(name, [type], [attack], [description], [seed])` | a forging target from a weapon as your database describes it |
| `anv_target(spec)` | a target from `{seed, family, atk, metal, name}` (family and metal optional) |
| `anv_family_of(type, name)`, `anv_metal_of(name, description)` | the readings `anv_weapon` uses, on their own |
| `anv_scene_create(target, [options])` | a forge: `{difficulty ("easy", "normal", "hard"), title, min_quality, give, quality (internal scale 1-3), fade (false skips the 16-frame fade from black)}` |
| `anv_scene_step(scene, [input])` | one frame of the forge; returns its mode |
| `anv_scene_draw(scene, x, y, w, h)` | draw the forge fitted into a rectangle at 816 x 624 proportions |
| `anv_scene_done(scene)`, `anv_scene_result(scene)` | over yet, and the verdict |
| `anv_scene_free(scene)` | free the forge's surfaces |
| `anv_input(...)` | an input struct from your own bindings (see Quickstart) |
| `anv_blade_sprite(target, forge, w, h)` | the finished piece as a new sprite, the whole piece scaled to fit (pass `undefined` for the forge to draw the pattern as a perfect piece); you own it |
| `anv_draw_pm(sprite, x, y, [xscale], [yscale], [angle], [colour], [alpha])` | draw an Anvil sprite (they are premultiplied) correctly over anything |
| `anv_cache_build()`, `anv_cache_free()` | bake (or free) the shared smithy, hammer, spark and steam pictures |

The forging model can be driven without the screen, for a crafting system of your own design or a test:
`anv_new_forge(target, difficulty)`, `anv_strike(target, forge, pos)` (pos 0 to 63 along the bar), `anv_cool(forge,
frames)`, `anv_reheat(forge)`, `anv_quench(forge)`, `anv_score(target, forge)`, `anv_shape(target, forge)`,
`anv_heat_name(heat)`, `anv_worst(target, forge)` (the place the bar most needs a blow - for hints).

Difficulty sets the heats allowed and how fast the metal cools: easy 6 heats, normal 5, hard 4.

## Performance

Everything is baked once into surfaces and drawn scaled every frame. Measured in the suite on a shared Windows machine:
the shared smithy, hammer, spark and steam pictures bake in 0.6 to 0.9 s the first time a forge opens (call
`anv_cache_build()` on a loading screen to move that cost there); the bar and its glow re-bake on every blow in
16 to 22 ms. Surfaces are volatile in GameMaker, so a lost surface is simply re-baked from the forge's state.

**The sprites are premultiplied.** `anv_scene_draw` blends them correctly; to draw a sprite from `anv_blade_sprite`
yourself, use `anv_draw_pm` (or `gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha)`).

## Removing the demo

Delete `obj_anv_demo`, `rm_anv_demo`, `anv_demo`, `anv_selftest` and `anv_oracle`. Nothing else refers to them.

## Namespacing

Every function and macro is prefixed `anv_` / `ANV_`; the only globals are `global.__anv_cache`, `global.__anv_chart`
and `global.anv_stage` (the demo's crash reporter). The fonts are `fnt_anvil_bold`, `fnt_anvil_display`,
`fnt_anvil_italic` and `fnt_anvil_text`. Nothing here touches your rooms, layers or objects.

## Fonts

All four faces are Libre Baskerville under the SIL Open Font License 1.1, rasterised into GameMaker atlases under the
names "Anvil Serif", "Anvil Serif Bold", "Anvil Serif Display" and "Anvil Serif Italic" (the font's Reserved Font Name
stays with the font). The licence text and notices are in `Anvil/fonts/`. You may use them in your game freely.

## Verification

The in-engine suite (44 assertions, all passing on the shipped source in two runs) holds this port to the original RPG Maker MZ plugin, run in Node: its generator's draws and hash, 50 forging targets across all six families (3200 of 3200 profile samples identical), the family and metal readings, three forgings replayed blow by blow with every blow's movement, every hammer mark and crack, the quench and the score identical (skilled q92 Masterwork (42 blows, 0 cracks); careless q0 Crude (60 blows, 38 cracks); hard q0 Crude (30 blows, 20 cracks)), the quench verdicts and the heat ramp, and 29 drawn things - the smithy, the anvil, the colour chart, the bar in four states, the glow, every family's finished blade, the cards and the verdict - with exactly the original's paths, fills, strokes and rectangles (3584 drawing operations). It also renders the forge, the verdict and a rack of finished pieces and drives a whole forge through anv_scene_step to its result. A fresh import into a blank project runs this Readme's own code (29 checks, all passing), and an adversarial pass makes 96 bad calls into the 24 documented functions with 0 crashes. Three departures from the original are deliberate and keep every compared count: drop shadows offset as its code intended, the glow blurred by resampling (GameMaker has no CSS blur), and two layout fixes found by looking (the chart's pointer no longer rides over its title, the work order's lines fit the card).

## AI disclosure

This package was written with AI assistance: the code and the generated graphics. It contains no AI-generated audio.

Core Systems Asset Factory - https://csaf.itch.io
