# Frontispiece - for GameMaker

**The title screen, generated: your game's name CUT letter by letter into a worked material, framed, crowned with a device read from your game's own words, and a command menu built out of the same furniture. No image files, no sprites, no stock window.**

Frontispiece builds a whole title screen for your game, once, in pure GML. You give it your title and the words
your game uses for itself (its elements, classes, places); it chooses one of six **houses** - a ground, a border,
a cartouche, a hand of lettering, a cut, a device and a menu that belong together - and draws every part of it.
The title is never typed in a font: it is cut from an authored alphabet of 79 letterform skeletons through a
broad-nib pen simulation, in one of five hands and one of four cuts. Then it comes up on screen the way a title
card should - the letters cut in one by one, the device and the menu rising after them.

---

## What it does

- **A title that is cut, not typed.** 79 hand-authored letterform skeletons, drawn stroke by stroke, rendered
  through one broad-nib pen into **five hands**: Lapidary (Roman inscriptional capitals), Uncial (rounded
  majuscule), Textura (blackletter), Stave (straight chisel cuts only) and Grotesk (monoline). 245 glyphs.
- **Four cuts** for how a letter meets its material: **incised** (a V-groove, no ink - only the shadow the cut
  casts), **raised** (carved proud), **inlaid** (metal in a bed, graded) and **printed** (flat ink). Each one
  solves for an absolute luminance separation, so the same cut reads on pale vellum and on black lacquer.
- **Eight grounds worked as materials**: vellum, tooled leather, riven slate, planished bronze, black lacquer,
  woven linen, quartersawn oak and brushed steel - pores, cleavage, hammer facets, crazing, weave and grain.
- **Six borders, six cartouches, twelve fleurons, six device layouts, six menus.**
- **It reads your game.** Pass the words your game uses and `auto` chooses the house that fits them; pass none and
  it hashes your title, so two games never get the same screen by accident and one game always gets the same one.
- **A menu that is part of the screen**: sunk slots, plaques, rules, tabs, a ruled column or small cartouches.
  The chosen row lifts, deepens or runs out; a disabled row is drawn greyed and cannot be confirmed.
- **Cheap to show.** Everything is built once into sprites; a frame costs a handful of sprite draws.

## Requirements

GameMaker 2024.14 or later. Built and tested with the **runtime 2024.14.4.268** on Windows (the VM runtime).
Pure GML: no extension, no DLL, no shader, no sprites shipped.

## Install

1. **Tools > Import Local Package**, choose `Frontispiece.yymps`, and import everything.
2. Press Play. `rm_fsp_demo` builds a title screen for a sample game: Up/Down or the mouse to choose, Enter or a
   click to confirm, **H** for the next house, **T** for another sample game, **R** to cut the title in again.

If you only want the library, import the `fsp_*` scripts and the four `fnt_frontispiece*` fonts;
`obj_fsp_demo`, `rm_fsp_demo` and `fsp_demo` are the demo, and `fsp_bake` only renders the store images.

## Quickstart

Put this in your title room's object.

```gml
// Create
my_screen = fsp_screen_create("Thanehold", {
    subtitle: "A Tale of the Late Kingdom",
    words: ["Frost", "Axe", "Wolf", "North"],
    commands: ["New Game", "Continue", "Options", "Quit"],
    enabled: [true, file_exists("save.dat"), true, true]
});

// Step
fsp_screen_step(my_screen);
if (keyboard_check_pressed(vk_down)) fsp_screen_move(my_screen, 1);
if (keyboard_check_pressed(vk_up)) fsp_screen_move(my_screen, -1);
fsp_screen_hover(my_screen, device_mouse_x_to_gui(0), device_mouse_y_to_gui(0));
if (keyboard_check_pressed(vk_enter) || mouse_check_button_pressed(mb_left)) {
    var my_choice = fsp_screen_confirm(my_screen);   // -1 while the title is still being cut, or on a disabled row
    if (my_choice == 0) show_debug_message("New Game");
    if (my_choice == 3) game_end();
}

// Draw GUI
fsp_screen_draw(my_screen, 0, 0);

// Clean Up
fsp_screen_free(my_screen);
```

The first press while the title is still coming up finishes it instead of choosing a row.

### Choosing the look yourself

```gml
my_screen = fsp_screen_create("Saints of Ash", { house: "sanctum" });              // a whole house
my_screen = fsp_screen_create("Saints of Ash", { house: "sanctum", ground: "lacquer", hand: "uncial" });  // one axis swapped
fsp_screen_set_house(my_screen, "vigil", "Book the Second");                       // change it later (rebuilds)
```

An id that does not exist never crashes: the house's own choice is used and the mistake is listed in
`my_screen.warnings`. `my_screen.report` says what was built and why (`house_why` is `"vocabulary"`,
`"title-hash"` or `"parameter"`).

### The houses

| House | Ground | Border | Cartouche | Hand | Cut | Device | Menu |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `chancery` | vellum | fillet | scroll | uncial | printed | spray | rules |
| `sanctum` | slate | strapwork | pediment | lapidary | incised | lozenge | slots |
| `folio` | leather | dentil | tablet | textura | inlaid | wreath | plaques |
| `hall` | oak | rope | banderole | stave | raised | crest | tabs |
| `foundry` | steel | guilloche | lozenge | grotesk | incised | band | column |
| `vigil` | lacquer | corners | open | uncial | inlaid | rule | cartouches |

Every column can be overridden on its own: `ground` (`vellum` `leather` `slate` `bronze` `lacquer` `linen` `oak`
`steel`), `frame` (`fillet` `dentil` `guilloche` `strapwork` `rope` `corners`), `cartouche` (`tablet` `lozenge`
`scroll` `pediment` `banderole` `open`), `hand` (`lapidary` `uncial` `textura` `stave` `grotesk`), `cut`
(`incised` `raised` `inlaid` `printed`), `vignette` (`spray` `wreath` `lozenge` `band` `crest` `rule`) and `menu`
(`slots` `plaques` `rules` `tabs` `column` `cartouches`).

### Languages

The authored alphabet is **Latin capitals, digits and common punctuation**. When less than 60% of a title's
characters are in it, the title is lettered in the `fallback_font` you pass (default `fnt_frontispiece_title`)
with the same cut, relief and light. `fsp_alpha_coverage(title, hand)` tells you in advance, and names the
characters it cannot cut. A non-Latin title gets a well-lettered screen; it does not get a cut one.

## The API

| Function | What it does |
| --- | --- |
| `fsp_screen_create(title, [options])` | Build a screen. Options: `house`, `ground`, `frame`, `cartouche`, `hand`, `cut`, `vignette`, `menu`, `words`, `subtitle`, `imprint`, `commands`, `enabled`, `index`, `width`, `height`, `supersample`, `reveal`, `fallback_font`. |
| `fsp_screen_step(screen)` | Advance the reveal and the row crossfade by one frame. Call once per Step. |
| `fsp_screen_draw(screen, x, y)` | Draw it, top-left at (x, y). |
| `fsp_screen_move(screen, delta)` | Move the choice up (-1) or down (+1), skipping disabled rows. |
| `fsp_screen_select(screen, row)` | Choose a row directly. |
| `fsp_screen_hover(screen, x, y)` | Choose the row under the mouse (only when the pointer is on a row). |
| `fsp_screen_row_at(screen, x, y)` | The row under a point, or -1. |
| `fsp_screen_confirm(screen)` | The chosen row, or -1 during the reveal or on a disabled row. |
| `fsp_screen_index(screen)` | The chosen row. |
| `fsp_screen_revealed(screen)` | True once the whole screen is up. |
| `fsp_screen_skip(screen)` | Finish the reveal at once. |
| `fsp_screen_set_enabled(screen, row, enabled)` | Grey a row out or bring it back (rebuilds the menu). |
| `fsp_screen_set_house(screen, house, [subtitle])` | Change the whole look (rebuilds). |
| `fsp_screen_rebuild(screen)` | Rebuild every layer; returns the build time in ms. |
| `fsp_screen_free(screen)` | Delete the screen's sprites. |
| `fsp_compose(title, [options])` | The resolved look without drawing anything: house, why, every axis, the device's fleurons. |
| `fsp_alpha_draw_line(text, opts)` | Cut one line of text into whatever surface is the target: `{x, base_y, cap_h, hand, cut, ground, ink, delta}`. |
| `fsp_alpha_fit(text, hand, max_w, max_cap, min_cap)` | The cap height that fits a line into a width: `{cap_h, width, fits}`. |
| `fsp_alpha_measure(text, hand, cap_h)` | A line's width in pixels. |
| `fsp_alpha_coverage(text, hand)` | How much of a string the alphabet can cut: `{covered, total, ratio, missing}`. |
| `fsp_houses()` | The six houses, each `{id, label, ground, frame, cartouche, hand, cut, vignette, menu, ...}`. |
| `fsp_grounds()` | The eight grounds, each `{id, label, ...}`. |
| `fsp_frames()` | The six borders. |
| `fsp_cartouches()` | The six cartouches. |
| `fsp_vignettes()` | The six device layouts. |
| `fsp_menus()` | The six menu treatments. |
| `fsp_ornaments()` | The twelve fleurons a device is built from. |
| `fsp_alpha_hand_ids()` | The five hands. |
| `fsp_alpha_cut_ids()` | The four cuts. |

Every function checks what it is handed. A wrong type, `undefined` or an unknown id returns a refusal value
(`undefined`, `false`, `-1`, `0` or an empty result) or falls back to the house's own choice instead of throwing
inside your game.

## Sizes and performance

`fsp_screen_create` builds at the GUI size unless you pass `width` and `height`, drawing every mark at twice the
size and filtering it down (the renderer has no antialiasing of its own). That build is the whole cost, and it is
paid once: call it on a loading frame, not mid-game. Sprites survive a lost surface, so a display change needs no
rebuild. After that, a frame draws two or three sprites.

## Namespacing

Every script, function and macro is prefixed `fsp_` or `FSP_`; the resources are `obj_fsp_demo`, `rm_fsp_demo`
and the four `fnt_frontispiece` fonts. Nothing collides with your project.

## Fonts

Three fonts are rasterised from IM Fell DW Pica (SIL Open Font License 1.1) and one is Open Sans (Apache
License 2.0). They letter the menu, the subtitle, the imprint and a title the alphabet cannot cut; the title
itself is never set in them. Their licences and notices are in `Frontispiece/fonts/`, with
`THIRD-PARTY-NOTICES.txt`.

## Licence and disclosure

One commercial licence per developer, unlimited games. Everything the package draws in your game is yours
to ship, including on your store page and in your key art. See `LICENSE.txt`.

This package's code and its store images were produced with AI assistance.

Copyright (c) 2026 Core Systems Asset Factory.

*The RPG Maker MZ edition, Frontispiece: <https://csaf.itch.io/frontispiece>. More GameMaker systems from Core
Systems Asset Factory: <https://csaf.itch.io>*
