/// @description Up/Down or the mouse choose a row, Enter or a click confirms it; H changes the house, T the game, R replays
/// the cut-in, F1 shows the keys.
if (!is_struct(screen)) exit;
fsp_screen_step(screen);
if (message_t > 0) message_t--;
if (keyboard_check_pressed(vk_down)) fsp_screen_move(screen, 1);
if (keyboard_check_pressed(vk_up)) fsp_screen_move(screen, -1);
fsp_screen_hover(screen, device_mouse_x_to_gui(0), device_mouse_y_to_gui(0));
if (keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space) || (mouse_check_button_pressed(mb_left) && fsp_screen_row_at(screen, device_mouse_x_to_gui(0), device_mouse_y_to_gui(0)) >= 0)) {
    var _c = fsp_screen_confirm(screen);
    if (_c >= 0) { message = "Chosen: " + screen.commands[_c] + "   (row " + string(_c) + " - your game decides what it does)"; message_t = 240; }
}
if (keyboard_check_pressed(ord("H"))) {
    house_index = (house_index + 2) mod 7 - 1;   // -1 = auto, then the six houses in order
    fsp_screen_free(screen);
    screen = fsp_demo_build(titles[title_index], house_index);
    message = fsp_demo_caption(screen); message_t = 300;
}
if (keyboard_check_pressed(ord("T"))) {
    title_index = (title_index + 1) mod array_length(titles);
    fsp_screen_free(screen);
    screen = fsp_demo_build(titles[title_index], house_index);
    message = fsp_demo_caption(screen); message_t = 300;
}
if (keyboard_check_pressed(ord("R"))) screen.t = 0;
if (keyboard_check_pressed(vk_f1)) help = !help;
