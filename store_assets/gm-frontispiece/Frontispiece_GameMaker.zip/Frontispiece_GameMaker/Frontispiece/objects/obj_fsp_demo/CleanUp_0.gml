/// @description Free the screen's sprites.
if (is_struct(screen)) fsp_screen_free(screen);
screen = undefined;
