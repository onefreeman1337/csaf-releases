/// @description The title screen, then (briefly, or with F1) what was built and the keys - fsp_demo_draw is the same
/// function the store bake photographs.
if (!is_struct(screen)) exit;
fsp_demo_draw(screen, message, (message_t > 0 || help) ? min(1, max(message_t / 60, help ? 1 : 0)) : 0, help, display_get_gui_width(), display_get_gui_height());
