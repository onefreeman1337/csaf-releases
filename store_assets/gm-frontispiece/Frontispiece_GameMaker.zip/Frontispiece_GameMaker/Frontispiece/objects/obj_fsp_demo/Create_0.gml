/// @description Frontispiece demo - a title screen built for a game, cut in, with a menu you can drive - and the headless
/// entry points (-selftest, -bake, -gif).
/// ⛔ The crash handler is installed FIRST, and every variable a later event reads is declared ABOVE the early exits:
/// Clean Up always runs, even when Create leaves early.
exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("fsp_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.fsp_stage) + ": " + string(_ex.message) + " | " + string(_ex.stacktrace));
    file_text_close(_f);
    game_end();
});
global.fsp_stage = 0;
screen = undefined;
titles = fsp_demo_titles();
title_index = 0;
house_index = -1;
message = "";
message_t = 0;
help = false;
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";
if (string_pos("-selftest", _args) > 0) { global.fsp_stage = 1; fsp_selftest_write(fsp_selftest_run()); game_end(); exit; }
if (string_pos("-bake", _args) > 0) { global.fsp_stage = 2; fsp_bake_run(); game_end(); exit; }
if (string_pos("-gif", _args) > 0) { global.fsp_stage = 3; fsp_bake_gif(); game_end(); exit; }

// the demo: the first sample game's title screen, built at the GUI size and cut in
screen = fsp_demo_build(titles[title_index], house_index);
message = fsp_demo_caption(screen);
message_t = 360;
