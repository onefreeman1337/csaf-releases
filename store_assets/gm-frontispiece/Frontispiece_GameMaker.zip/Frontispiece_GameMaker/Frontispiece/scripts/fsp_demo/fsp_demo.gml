/// fsp_demo.gml - the demo room's sample games and its screen as one function, so the demo object and the store bake
/// draw the SAME screen (the bake photographs it; nothing else can see the demo room).
///
/// Frontispiece - The Title Screen, Generated, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
/// Not needed by the library: delete it with obj_fsp_demo and rm_fsp_demo.

/// @function fsp_demo_titles()
/// @description Seven sample games: a title, a subtitle, and the words each game uses for itself (its elements, classes
/// and places) - which is what "auto" reads to choose a house. The last passes no words, so its house comes from a hash
/// of its title. Pure.
function fsp_demo_titles() {
    static _T = [
        { title: "Thanehold", subtitle: "A Tale of the Late Kingdom", words: ["Frost", "Axe", "Wolf", "North", "Shield", "Thane"] },
        { title: "Saints of Ash", subtitle: "Book the First", words: ["Holy", "Stone", "Prayer", "Temple", "Shrine"] },
        { title: "The Umber Codex", subtitle: "", words: ["Curse", "Blood", "Witch", "Crypt", "Shadow"] },
        { title: "Cogspire", subtitle: "Engines of the Deep Quarter", words: ["Steam", "Gear", "Circuit", "Reactor", "Drone"] },
        { title: "Moonwake", subtitle: "", words: ["Star", "Dream", "Void", "Lunar", "Mist"] },
        { title: "Letters of Marque", subtitle: "Being a True Account", words: ["Scroll", "Oath", "Seal", "Ink", "Verse"] },
        { title: "Harrowmere", subtitle: "", words: [] }];
    return _T;
}

/// @function fsp_demo_build(record, house_index)
/// @description Build a screen for one sample game at the GUI size. house_index -1 = "auto", 0..5 = a named house.
function fsp_demo_build(_rec, _house_index) {
    var _ids = fsp_ids(fsp_houses());
    var _house = (_house_index >= 0 && _house_index < array_length(_ids)) ? _ids[_house_index] : "auto";
    return fsp_screen_create(_rec.title, { house: _house, words: _rec.words, subtitle: _rec.subtitle, imprint: "CORE SYSTEMS ASSET FACTORY",
        commands: ["New Game", "Continue", "Options", "Quit"], enabled: [true, false, true, true], width: display_get_gui_width(), height: display_get_gui_height() });
}

/// @function fsp_demo_caption(screen)
/// @description One line saying what was built and why. Pure.
function fsp_demo_caption(_s) {
    var _r = _s.report, _why = "";
    switch (_r.house_why) {
        case "vocabulary": _why = "chosen by the game's own words"; break;
        case "title-hash": _why = "chosen by a hash of the title (no words passed)"; break;
        case "parameter": _why = "set by parameter"; break;
        default: _why = _r.house_why; break;
    }
    return string_upper(_r.house) + " - " + _why + "   |   " + _r.ground + ", " + _r.frame + ", " + _r.cartouche + ", " + _r.hand + " hand, " + _r.cut + ", "
        + _r.vignette + " of " + _r.ornaments[0] + ", " + _r.menu + " menu   |   built in " + string(round(_s.build_ms)) + " ms";
}

/// @function fsp_demo_draw(screen, message, alpha, help, w, h)
/// @description The title screen, then a caption strip along the bottom edge while `alpha` > 0.
function fsp_demo_draw(_s, _msg, _alpha, _help, _gw, _gh) {
    fsp_screen_draw(_s, 0, 0);
    if (_alpha <= 0) return;
    var _lines = _help ? 2 : 1, _bh = 12 + _lines * 20;
    fsp_rect(0, _gh - _bh, _gw, _bh, make_colour_rgb(12, 10, 12), 0.78 * _alpha);
    fsp_text(_gw * 0.5, _gh - _bh + 8, _msg, 15, make_colour_rgb(236, 226, 206), fa_center, fa_top, fnt_frontispiece_ui, _alpha);
    if (_help) fsp_text(_gw * 0.5, _gh - _bh + 28, "[Up/Down or mouse] choose     [Enter/click] confirm     [H] next house     [T] another game     [R] cut it again     [F1] keys",
        15, make_colour_rgb(176, 164, 146), fa_center, fa_top, fnt_frontispiece_ui, _alpha);
}
