/// fsp_selftest.gml - the in-engine suite (`Frontispiece.exe -selftest` writes fsp_selftest.json). Stage 99 = the suite
/// reached its end. Not needed at runtime: delete it with the -selftest branch of the demo object's Create event.
///
/// Frontispiece - The Title Screen, Generated, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
/// ⛔ Every picture claim is asserted as INK - pixels counted on a rendered surface - never as "a sprite exists": a
/// function handed the wrong type returns a live, correctly sized, EMPTY sprite. Every ink assertion has a control.

function fsp_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 80) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
function fsp_st_stage(_st, _n) { _st.stage = _n; global.fsp_stage = _n; }
function fsp_st_note(_st, _s) { array_push(_st.notes, _s); }

/// @function fsp_test_grab(sprite)
/// @description A sprite's pixels in a buffer {b, w, h} (BGRA), drawn with blending OFF so its alpha is not applied twice.
function fsp_test_grab(_spr) {
    var _w = sprite_get_width(_spr), _h = sprite_get_height(_spr);
    var _sf = surface_create(_w, _h);
    surface_set_target(_sf);
    draw_clear_alpha(c_black, 0);
    gpu_set_blendenable(false);
    draw_sprite(_spr, 0, 0, 0);
    gpu_set_blendenable(true);
    surface_reset_target();
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    surface_free(_sf);
    return { b: _b, w: _w, h: _h };
}

/// @function fsp_test_grab_surface(surface)
function fsp_test_grab_surface(_sf) {
    var _w = surface_get_width(_sf), _h = surface_get_height(_sf);
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    return { b: _b, w: _w, h: _h };
}

/// @function fsp_test_diff(a, b, rect, [step], [tol])
/// @description How many sampled pixels inside rect {x, y, w, h} differ between two grabs of the same size by more than
/// `tol` on ANY channel (a luminance-only metric is colour-blind).
function fsp_test_diff(_a, _b, _r, _step = 1, _tol = 24) {
    var _n = 0, _x0 = max(0, floor(_r.x)), _y0 = max(0, floor(_r.y)), _x1 = min(_a.w, ceil(_r.x + _r.w)), _y1 = min(_a.h, ceil(_r.y + _r.h));
    for (var _y = _y0; _y < _y1; _y += _step) for (var _x = _x0; _x < _x1; _x += _step) {
        var _o = (_y * _a.w + _x) * 4;
        if (abs(buffer_peek(_a.b, _o, buffer_u8) - buffer_peek(_b.b, _o, buffer_u8)) > _tol || abs(buffer_peek(_a.b, _o + 1, buffer_u8) - buffer_peek(_b.b, _o + 1, buffer_u8)) > _tol
            || abs(buffer_peek(_a.b, _o + 2, buffer_u8) - buffer_peek(_b.b, _o + 2, buffer_u8)) > _tol) _n++;
    }
    return _n;
}

/// @function fsp_test_ink(grab, rect, ground_bgr, [tol])
/// @description {n, x0, y0, x1, y1}: pixels in rect differing from a flat ground colour ([b, g, r]) and their box.
function fsp_test_ink(_g, _r, _bgr, _tol = 30) {
    var _n = 0, _bx0 = 100000, _by0 = 100000, _bx1 = -1, _by1 = -1;
    var _x0 = max(0, floor(_r.x)), _y0 = max(0, floor(_r.y)), _x1 = min(_g.w, ceil(_r.x + _r.w)), _y1 = min(_g.h, ceil(_r.y + _r.h));
    for (var _y = _y0; _y < _y1; _y++) for (var _x = _x0; _x < _x1; _x++) {
        var _o = (_y * _g.w + _x) * 4;
        if (abs(buffer_peek(_g.b, _o, buffer_u8) - _bgr[0]) > _tol || abs(buffer_peek(_g.b, _o + 1, buffer_u8) - _bgr[1]) > _tol || abs(buffer_peek(_g.b, _o + 2, buffer_u8) - _bgr[2]) > _tol) {
            _n++; _bx0 = min(_bx0, _x); _by0 = min(_by0, _y); _bx1 = max(_bx1, _x); _by1 = max(_by1, _y);
        }
    }
    return { n: _n, x0: _bx0, y0: _by0, x1: _bx1, y1: _by1 };
}

function fsp_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, failures: [], stage: 0, notes: [] }, _i, _j, _k;

    fsp_st_stage(_st, 1);    // the maths reproduces the MZ original bit for bit (values from Internal_Ops/_js_reference.js)
    fsp_st_assert(_st, fsp_hash("") == 2166136261 && fsp_hash("a") == 3826002220 && fsp_hash("THANEHOLD") == 2011336272, "FNV-1a hash matches the JavaScript original on three strings (got " + string(fsp_hash("THANEHOLD")) + ")");
    fsp_st_assert(_st, fsp_hash("frontispiece-house:Thanehold") == 4255691298 && fsp_hash("frontispiece-house:Harrowmere") == 1266295849 && fsp_hash("frontispiece:Moonwake:vigil") == 3088744364, "the three seeds that choose a house match the original");
    var _g = fsp_rng(12345), _ref = [0.9797282677609473, 0.3067522644996643, 0.484205421525985, 0.817934412509203, 0.5094283693470061], _ok = true;
    for (_i = 0; _i < 5; _i++) { var _v = fsp_rng_next(_g); if (abs(_v - _ref[_i]) > 0.0001) _ok = false; }
    fsp_st_assert(_st, _ok, "mulberry32 from seed 12345 matches the original's first five draws");
    _g = fsp_rng(fsp_hash("frontispiece:Thanehold:hall") ^ $51ED);
    var _a0 = fsp_rng_next(_g), _a1 = fsp_rng_next(_g), _a2 = fsp_rng_next(_g);
    fsp_st_assert(_st, abs(_a0 - 0.3926667761988938) < 0.0001 && abs(_a1 - 0.9058428469579667) < 0.0001 && abs(_a2 - 0.6909712082706392) < 0.0001, "the ground generator for a real screen matches (" + string_format(_a0, 1, 6) + ")");
    fsp_st_assert(_st, abs(fsp_noise2(3, 7, 99) - 0.27876477781683207) < 0.0001 && abs(fsp_noise2(-5, 12, 41) - 0.056485025212168694) < 0.0001 && abs(fsp_noise2(1000.5, -2.25, 7919) - 0.4420176937710494) < 0.0001, "lattice noise matches, including negative and fractional coordinates");
    fsp_st_assert(_st, abs(fsp_snoise(2.5, 3.25, 99) - 0.2362325368594611) < 0.0001 && abs(fsp_fbm(1.7, 3.4, 41, 3) - 0.593232755658782) < 0.0001, "smoothed and fractal noise match");
    fsp_st_assert(_st, fsp_mul32($FFFFFFFF, $FFFFFFFF) == 1 && fsp_mul32(65536, 65536) == 0 && fsp_mul32(3, 5) == 15, "mul32 keeps exactly the low 32 bits (0xFFFFFFFF squared = 1)");

    fsp_st_stage(_st, 2);    // the corpus counts, COUNTED from the tables
    var _vol = fsp_alpha_volume();
    fsp_st_assert(_st, _vol.base == 49 && _vol.overrides == 30 && _vol.total == 79 && _vol.glyphs == 245, "the alphabet holds 49 base + 30 override skeletons = 79, 245 base glyphs (got " + string(_vol.base) + "/" + string(_vol.overrides) + "/" + string(_vol.total) + "/" + string(_vol.glyphs) + ")");
    var _cv = fsp_corpus_volume();
    fsp_st_assert(_st, _cv.grounds == 8 && _cv.frames == 6 && _cv.cartouches == 6 && _cv.ornaments == 12 && _cv.vignettes == 6 && _cv.menus == 6 && _cv.houses == 6, "8 grounds, 6 frames, 6 cartouches, 12 ornaments, 6 vignettes, 6 menus, 6 houses");
    fsp_st_assert(_st, array_length(fsp_alpha_hand_ids()) == 5 && array_length(fsp_alpha_cut_ids()) == 4, "5 hands and 4 cuts");
    // no two houses share more than two of their seven axes - a house is an argument, not a colour
    var _H = fsp_houses(), _axes = ["ground", "frame", "cartouche", "hand", "cut", "vignette", "menu"], _worst = 0, _wp = "";
    for (_i = 0; _i < array_length(_H); _i++) for (_j = _i + 1; _j < array_length(_H); _j++) {
        var _sh = 0;
        for (_k = 0; _k < 7; _k++) if (_H[_i][$ _axes[_k]] == _H[_j][$ _axes[_k]]) _sh++;
        if (_sh > _worst) { _worst = _sh; _wp = _H[_i].id + "/" + _H[_j].id; }
    }
    fsp_st_assert(_st, _worst <= 2, "no two houses share more than two axes (worst " + string(_worst) + ", " + _wp + ")");
    var _ids = [fsp_grounds(), fsp_frames(), fsp_cartouches(), fsp_vignettes(), fsp_menus()], _refs_ok = true;
    for (_i = 0; _i < array_length(_H); _i++) {
        if (!is_struct(fsp_find(fsp_grounds(), _H[_i].ground)) || !is_struct(fsp_find(fsp_frames(), _H[_i].frame)) || !is_struct(fsp_find(fsp_cartouches(), _H[_i].cartouche))
            || !is_struct(fsp_find(fsp_vignettes(), _H[_i].vignette)) || !is_struct(fsp_find(fsp_menus(), _H[_i].menu)) || !is_struct(fsp_alpha_hand(_H[_i].hand))) _refs_ok = false;
        for (_j = 0; _j < array_length(_H[_i].ornaments); _j++) if (!is_struct(fsp_find(fsp_ornaments(), _H[_i].ornaments[_j]))) _refs_ok = false;
    }
    fsp_st_assert(_st, _refs_ok, "every house names only ids that exist in the tables");

    fsp_st_stage(_st, 3);    // the reading
    var _cases = [[["Steam", "Gear", "Circuit", "Reactor"], "foundry"], [["Holy", "Stone", "Prayer", "Temple"], "sanctum"], [["Curse", "Blood", "Witch", "Crypt"], "folio"],
        [["Frost", "Axe", "Wolf", "North"], "hall"], [["Star", "Dream", "Void", "Lunar"], "vigil"], [["Scroll", "Oath", "Seal", "Ink"], "chancery"]];
    for (_i = 0; _i < array_length(_cases); _i++) {
        var _rh = fsp_read_house("Nameless", _cases[_i][0]);
        fsp_st_assert(_st, _rh.house == _cases[_i][1] && _rh.why == "vocabulary", "the words " + string(_cases[_i][0]) + " read as " + _cases[_i][1] + " (got " + _rh.house + ", " + _rh.why + ")");
    }
    var _one = fsp_read_house("Nameless", ["Steam"]);
    fsp_st_assert(_st, _one.why != "vocabulary", "ONE matching word is noise, not a reading (fell back to " + _one.why + ")");
    var _seen = {}, _nh = 0, _titles = ["Ashfall", "Brightwater", "Cinderlane", "Dunmoor", "Emberly", "Fenwick", "Glasshollow", "Hollowmere", "Ironvale", "Juniper Gate", "Kestrel", "Lanternfall",
        "Mirewood", "Northreach", "Oakhaven", "Pale Harbour", "Quillon", "Ravenmoor", "Saltmarsh", "Thornwall", "Umberlight", "Vesper", "Wildermoor", "Yarrow"];
    for (_i = 0; _i < array_length(_titles); _i++) {
        var _hh = fsp_read_house(_titles[_i], []).house;
        if (!variable_struct_exists(_seen, _hh)) { _seen[$ _hh] = 1; _nh++; }
    }
    fsp_st_assert(_st, _nh >= 5, "24 games that pass no words spread across " + string(_nh) + " of 6 houses (the title hash is what spreads a market of untouched projects)");
    fsp_st_assert(_st, fsp_read_house("Harrowmere", []).house == fsp_read_house("Harrowmere", []).house && fsp_compose("Harrowmere").seed == fsp_compose("Harrowmere").seed, "the same title always reads the same house and seed");
    var _orn = fsp_read_ornaments("Nameless", ["Fire", "Ember"], fsp_find(fsp_houses(), "sanctum"));
    fsp_st_assert(_st, _orn.ids[0] == "sunburst" && _orn.why == "word:sunburst", "a fire word puts the sunburst at the head of the device (" + _orn.ids[0] + ")");
    var _sp = fsp_compose("Test", { house: "nope", ground: "moss", hand: "copperplate", cut: "etched", menu: "slots" });
    fsp_st_assert(_st, array_length(_sp.warnings) == 4 && is_struct(fsp_find(fsp_houses(), _sp.house)) && _sp.menu == "slots", "four unknown ids are refused by name (" + string(array_length(_sp.warnings)) + " warnings) and a valid override still applies");
    _sp = fsp_compose("Test", { house: "folio", ground: "steel", hand: "grotesk" });
    fsp_st_assert(_st, _sp.house == "folio" && _sp.ground == "steel" && _sp.hand == "grotesk" && _sp.frame == "dentil" && _sp.house_why == "parameter", "overrides swap one axis and leave the rest of the house");
    _sp = fsp_compose(12345, undefined);
    fsp_st_assert(_st, _sp.title == "12345" && is_struct(fsp_find(fsp_houses(), _sp.house)), "a number for a title is taken as its string, never a crash");

    fsp_st_stage(_st, 4);    // colour: separation is ABSOLUTE
    var _G = fsp_grounds(), _bad = "";
    for (_i = 0; _i < array_length(_G); _i++) {
        var _b = _G[_i].base, _want = min(46, fsp_headroom(_b, -1)), _got = fsp_lum(_b) - fsp_lum(fsp_relief(_b, -1, 46));
        if (abs(_got - _want) > 1.5) _bad += _G[_i].id + " ";
        _want = min(34, fsp_headroom(_b, 1)); _got = fsp_lum(fsp_relief(_b, 1, 34)) - fsp_lum(_b);
        if (abs(_got - _want) > 1.5) _bad += _G[_i].id + "+ ";
    }
    fsp_st_assert(_st, _bad == "", "relief delivers the asked separation (or all the headroom there is) on all 8 grounds, both directions [" + _bad + "]");
    var _mid = fsp_relief([128, 128, 128], -1, 46);
    fsp_st_assert(_st, abs((128 - fsp_lum(_mid)) - 46) < 1.5, "control: mid-grey gets the FULL 46 levels, so 'as much as exists' cannot excuse a dead function");
    var _r1 = fsp_relief([222, 212, 188], -1, 46);
    fsp_st_assert(_st, abs(_r1[0] - 174) <= 1 && abs(_r1[1] - 166) <= 1 && abs(_r1[2] - 147) <= 1, "relief of vellum matches the original ([" + string(_r1[0]) + "," + string(_r1[1]) + "," + string(_r1[2]) + "] vs [174,166,147])");
    var _sep = fsp_separate([120, 110, 100], [128, 128, 128], 54);
    fsp_st_assert(_st, abs(fsp_lum(_sep) - 128) >= min(54, fsp_achievable([120, 110, 100], [128, 128, 128], 54)) - 1.5, "separate() moves a clashing ink until it clears the ground by what is achievable");
    fsp_st_assert(_st, fsp_rgb_ok(fsp_pick_contrast([20, 20, 20], [[30, 30, 30], [220, 220, 220]]), [220, 220, 220]) && fsp_rgb_ok(fsp_pick_contrast([10, 10, 10], []), [255, 255, 255]), "pick_contrast takes the far ink, and an empty list does not throw");

    fsp_st_stage(_st, 5);    // geometry laws
    var _ro = fsp_find(fsp_ornaments(), "rosette"), _su = fsp_find(fsp_ornaments(), "sunburst");
    var _cap6 = 1.05 * (_ro.lobe.len * 0.5) * sin(pi / 6);
    fsp_st_assert(_st, fsp_radial_width(_ro.lobe, 6) <= _cap6 + 0.0001 && fsp_radial_width(_ro.lobe, 6) < _ro.lobe.wid, "a six-lobe rosette's petals are narrowed below their authored width so they cannot fuse (" + string_format(fsp_radial_width(_ro.lobe, 6), 1, 3) + " < " + string(_ro.lobe.wid) + ")");
    fsp_st_assert(_st, fsp_radial_width({ kind: "spike", len: 1, wid: 5 }, 8) < 0.21 && fsp_radial_width({ kind: "spike", len: 1, wid: 0.05 }, 3) == 0.05, "the width law caps a wide lobe and leaves a narrow one alone");
    fsp_st_assert(_st, fsp_radial_width({ kind: "disc", len: 0.6, wid: 9 }, 4) == 0.3, "a disc has ONE radius - its authored width is ignored");
    var _fl = fsp_fit_lines(90, 4, 40);
    fsp_st_assert(_st, _fl.count == 13 && !_fl.fits, "40 marks 4 px wide on a 90 px run: 13 fit, and the fitter says it did not fit all (" + string(_fl.count) + ")");
    var _rp = fsp_repeats_for(700, 20, 2.1, 8);
    fsp_st_assert(_st, _rp.count == round(700 / 42) && abs(_rp.pitch * _rp.count - 700) < 0.01, "a repeat count is derived from the pitch and fills the run exactly (" + string(_rp.count) + ")");
    var _sm = fsp_smooth([[0, 0], [10, 0], [10, 10]], 6, false);
    fsp_st_assert(_st, array_length(_sm) == 13 && _sm[0][0] == 0 && _sm[12][0] == 10 && _sm[12][1] == 10, "Catmull-Rom passes through both ends and samples 6 per span");

    fsp_st_stage(_st, 6);    // every glyph in every hand yields sane rings
    var _hands = fsp_alpha_hand_ids(), _chars = variable_struct_get_names(fsp_alpha_base()), _nglyph = 0, _gbad = "";
    for (_i = 0; _i < array_length(_hands); _i++) for (_j = 0; _j < array_length(_chars); _j++) {
        var _gl = fsp_alpha_glyph(_chars[_j], _hands[_i], 100, 200, 60);
        if (!is_struct(_gl)) { _gbad += _hands[_i] + ":" + _chars[_j] + " "; continue; }
        _nglyph++;
        if (_chars[_j] == " ") continue;
        var _bb = fsp_bbox(_gl.rings);
        if (array_length(_gl.rings) == 0 || _bb.x0 < 100 - 36 || _bb.x1 > 100 + _gl.advance + 36 || _bb.y0 < 200 - 60 * 1.30 || _bb.y1 > 200 + 60 * 0.45) _gbad += _hands[_i] + ":" + _chars[_j] + " ";
        for (_k = 0; _k < array_length(_gl.rings); _k++) if (array_length(_gl.rings[_k]) < 3) _gbad += _hands[_i] + ":" + _chars[_j] + "(ring) ";
    }
    fsp_st_assert(_st, _nglyph == 245 && _gbad == "", "all 245 base glyphs build rings inside their design box [" + _gbad + "] (" + string(_nglyph) + ")");
    var _gO = fsp_alpha_glyph("O", "grotesk", 0, 100, 80), _gSO = fsp_alpha_glyph("O", "stave", 0, 100, 80);
    fsp_st_assert(_st, array_length(_gO.rings) == 2 && _gO.holes[1] && array_length(_gO.rings[0]) > 60 && array_length(_gSO.rings[0]) <= 8, "a grotesk O is a smoothed ring WITH a counter; a stave O is four straight facets (" + string(array_length(_gSO.rings[0])) + " points)");
    fsp_st_assert(_st, array_length(fsp_alpha_glyph(".", "lapidary", 0, 100, 80).rings[0]) == 8, "a full stop is the pen set down once (an eight-sided footprint), not a doughnut");
    var _cov = fsp_alpha_coverage("Thanehold!", "uncial"), _cov2 = fsp_alpha_coverage(chr($65E5) + chr($672C), "uncial");
    fsp_st_assert(_st, _cov.ratio == 1 && _cov2.ratio == 0 && array_length(_cov2.missing) == 2, "coverage: a Latin title is fully cuttable, a Japanese one is not (and says which characters)");
    var _fit = fsp_alpha_fit("THANEHOLD", "lapidary", 300, 200, 14);
    fsp_st_assert(_st, _fit.fits && abs(fsp_alpha_measure("THANEHOLD", "lapidary", _fit.cap_h) - 300) < 0.5, "the fitter solves the cap height that makes the line exactly the width asked");
    _fit = fsp_alpha_fit("THE LONGEST TITLE ANYONE COULD WRITE", "uncial", 100, 200, 14);
    fsp_st_assert(_st, !_fit.fits, "a line that cannot fit above the minimum size SAYS so");

    fsp_st_stage(_st, 7);    // the fill rule, measured in pixels
    var _sf = surface_create(64, 64);
    surface_set_target(_sf); draw_clear_alpha(c_black, 1);
    fsp_fill_rings([fsp_rect_ring(8, 8, 48, 48), fsp_rect_ring(20, 20, 24, 24)], c_white);
    fsp_fill_rings([fsp_rect_ring(2.5, 58, 3, 4)], c_white);
    surface_reset_target();
    var _gr = fsp_test_grab_surface(_sf);
    var _px_band = buffer_peek(_gr.b, (12 * 64 + 12) * 4, buffer_u8), _px_hole = buffer_peek(_gr.b, (32 * 64 + 32) * 4, buffer_u8), _px_out = buffer_peek(_gr.b, (4 * 64 + 4) * 4, buffer_u8);
    var _px_half = buffer_peek(_gr.b, (60 * 64 + 2) * 4, buffer_u8);
    fsp_st_assert(_st, _px_band > 240 && _px_hole < 16 && _px_out < 16, "even-odd: the band between two rings is filled and the counter is NOT (band " + string(_px_band) + ", hole " + string(_px_hole) + ")");
    fsp_st_assert(_st, _px_half > 90 && _px_half < 165, "a span that starts half way into a pixel gives it half coverage (" + string(_px_half) + " of 255)");
    buffer_delete(_gr.b);
    // NO STREAKS: a finely sampled disc (many edges whose tops differ by under a pixel) must be SOLID - every pixel whose
    // centre lies 1.5 px inside the rim painted. Rows with a missing crossing show as horizontal streaks through letters.
    surface_set_target(_sf); draw_clear_alpha(c_black, 1);
    fsp_fill_rings([fsp_ellipse_ring(32, 32, 22, 22, 0.37, 180)], c_white);
    surface_reset_target();
    _gr = fsp_test_grab_surface(_sf);
    var _holes = 0, _inside = 0;
    for (var _yy = 0; _yy < 64; _yy++) for (var _xx = 0; _xx < 64; _xx++) {
        if (point_distance(_xx + 0.5, _yy + 0.5, 32, 32) > 20.5) continue;
        _inside++;
        if (buffer_peek(_gr.b, (_yy * 64 + _xx) * 4, buffer_u8) < 200) _holes++;
    }
    fsp_st_assert(_st, _inside > 1200 && _holes == 0, "a 180-point disc fills solid: " + string(_holes) + " unpainted of " + string(_inside) + " interior pixels");
    buffer_delete(_gr.b);
    // THE STROKE RULE. A ring that runs round the same square twice is an OVERLAP of one outline with itself - what a pen
    // outline does at every sharp turn. Even-odd empties it (the control that the fixture exhibits the defect); the
    // stroke rule fills it; and a counter handed as ring 1 stays open under the stroke rule.
    var _twice = [[8, 8], [56, 8], [56, 56], [8, 56], [8, 8.01], [56, 8.01], [56, 56], [8, 56]];
    surface_set_target(_sf); draw_clear_alpha(c_black, 1);
    fsp_fill_rings([_twice], c_white, 1, undefined, FSP_FILL_EVENODD);
    surface_reset_target();
    _gr = fsp_test_grab_surface(_sf);
    var _eo_mid = buffer_peek(_gr.b, (32 * 64 + 32) * 4, buffer_u8);
    buffer_delete(_gr.b);
    surface_set_target(_sf); draw_clear_alpha(c_black, 1);
    fsp_fill_rings([_twice], c_white, 1, undefined, FSP_FILL_STROKE);
    surface_reset_target();
    _gr = fsp_test_grab_surface(_sf);
    var _st_mid = buffer_peek(_gr.b, (32 * 64 + 32) * 4, buffer_u8);
    buffer_delete(_gr.b);
    fsp_st_assert(_st, _eo_mid < 16 && _st_mid > 240, "an outline that overlaps itself: even-odd leaves a HOLE (" + string(_eo_mid) + ", the control) and the stroke rule fills it (" + string(_st_mid) + ")");
    surface_set_target(_sf); draw_clear_alpha(c_black, 1);
    fsp_fill_rings([fsp_rect_ring(8, 8, 48, 48), fsp_rect_ring(20, 20, 24, 24)], c_white, 1, undefined, FSP_FILL_STROKE);
    surface_reset_target();
    _gr = fsp_test_grab_surface(_sf);
    var _sb = buffer_peek(_gr.b, (12 * 64 + 12) * 4, buffer_u8), _sh = buffer_peek(_gr.b, (32 * 64 + 32) * 4, buffer_u8);
    buffer_delete(_gr.b);
    fsp_st_assert(_st, _sb > 240 && _sh < 16, "the stroke rule keeps a counter OPEN even when both rings wind the same way (band " + string(_sb) + ", counter " + string(_sh) + ")");
    // and on real letters. The CURVED strokes still fold where they turn tightly (they are never split at corners -
    // that is for straight zig-zags), so & 6 9 must GAIN ink under the stroke rule; W M N are split into legs and no
    // longer fold, so for them the rule must merely remove nothing. (First written against W M N alone, it went red on
    // the split: the fixture had stopped exhibiting the defect.)
    var _gain = "", _gmin = 1000000;
    var _jl = ["&", "6", "9", "W", "M", "N"];
    for (var _jj = 0; _jj < array_length(_jl); _jj++) {
        var _gw = fsp_alpha_glyph(_jl[_jj], "lapidary", 6, 58, 48);
        surface_set_target(_sf); draw_clear_alpha(c_black, 1);
        for (var _ri = 0; _ri < array_length(_gw.rings); _ri++) {
            if (_gw.holes[_ri]) continue;
            var _eset = [_gw.rings[_ri]];
            if (_ri + 1 < array_length(_gw.rings) && _gw.holes[_ri + 1]) array_push(_eset, _gw.rings[_ri + 1]);
            fsp_fill_rings(_eset, c_white, 1, undefined, FSP_FILL_EVENODD);
        }
        surface_reset_target();
        var _ge = fsp_test_grab_surface(_sf);
        surface_set_target(_sf); draw_clear_alpha(c_black, 1);
        fsp__fill_glyph(_gw, 0, 0, c_white);
        surface_reset_target();
        var _gs = fsp_test_grab_surface(_sf);
        var _more = 0, _less = 0;
        for (var _q = 0; _q < 64 * 64; _q++) {
            var _ve = buffer_peek(_ge.b, _q * 4, buffer_u8), _vs = buffer_peek(_gs.b, _q * 4, buffer_u8);
            if (_vs - _ve > 96) _more++;
            if (_ve - _vs > 96) _less++;
        }
        buffer_delete(_ge.b); buffer_delete(_gs.b);
        _gain += _jl[_jj] + " +" + string(_more) + "/-" + string(_less) + " ";
        if (_less > 0) _gmin = -1; else if (_jj < 3) _gmin = min(_gmin, _more);
    }
    fsp_st_assert(_st, _gmin > 0, "lapidary at a 48 px cap: the stroke rule fills the folds even-odd left empty in & 6 9, and removes nothing from any of & 6 9 W M N [" + _gain + "]");
    fsp_st_note(_st, "stroke rule vs even-odd at a 48 px cap: " + _gain);
    var _gOc = fsp_alpha_glyph("O", "lapidary", 8, 56, 44);
    surface_set_target(_sf); draw_clear_alpha(c_black, 1);
    fsp__fill_glyph(_gOc, 0, 0, c_white);
    surface_reset_target();
    _gr = fsp_test_grab_surface(_sf);
    var _ob = fsp_bbox(_gOc.rings), _ocx = floor((_ob.x0 + _ob.x1) * 0.5), _ocy = floor((_ob.y0 + _ob.y1) * 0.5);
    var _o_mid = buffer_peek(_gr.b, (_ocy * 64 + _ocx) * 4, buffer_u8);
    buffer_delete(_gr.b);
    fsp_st_assert(_st, _o_mid < 16, "a glyph's counter stays OPEN under the stroke rule (an O's centre reads " + string(_o_mid) + ")");
    // A ZIG-ZAG IS SPLIT AT ITS CORNERS. Drawn as one stroke, every leg of a W took its width across a tangent averaged
    // over the corner and came out a hairline (~1 px here) in the monoline hands. The first leg's horizontal ink run at
    // mid-height must be at least 0.8 of the hand's full stroke width.
    var _wrun = "", _wok = true, _mono = ["grotesk", "stave"];
    for (var _mh = 0; _mh < 2; _mh++) {
        var _gW = fsp_alpha_glyph("W", _mono[_mh], 4, 58, 48), _hw0 = fsp_alpha_hand(_mono[_mh]);
        surface_set_target(_sf); draw_clear_alpha(c_black, 1);
        fsp__fill_glyph(_gW, 0, 0, c_white);
        surface_reset_target();
        _gr = fsp_test_grab_surface(_sf);
        var _row = 58 - 24, _x0r = -1, _run = 0;
        for (var _xr = 0; _xr < 64; _xr++) {
            var _v = buffer_peek(_gr.b, (_row * 64 + _xr) * 4, buffer_u8);
            if (_v > 128) { if (_x0r < 0) _x0r = _xr; _run++; } else if (_x0r >= 0) break;
        }
        buffer_delete(_gr.b);
        var _want = 0.8 * _hw0.weight * 48;
        _wrun += _mono[_mh] + " run " + string(_run) + " px (joins " + string(_gW.joins) + ", want >= " + string_format(_want, 1, 1) + ") ";
        if (_run < _want || _gW.joins != 3) _wok = false;
    }
    fsp_st_assert(_st, _wok, "a W is four legs and three joins, and each leg is drawn at the hand's own weight [" + _wrun + "]");
    // and the same for real letters at a SMALL cap height, where edge tops crowd together
    surface_set_target(_sf); draw_clear_alpha(c_black, 1);
    var _gO2 = fsp_alpha_glyph("O", "uncial", 8, 54, 44);
    fsp__fill_glyph(_gO2, 0, 0, c_white);
    surface_reset_target();
    _gr = fsp_test_grab_surface(_sf);
    var _streak = 0;
    // walk the O's left stem at its widest: every row between 30% and 70% of the cap must be painted somewhere in x 8..20
    for (var _y2 = round(54 - 44 * 0.70); _y2 <= round(54 - 44 * 0.30); _y2++) {
        var _any = false;
        for (var _x2 = 8; _x2 <= 22; _x2++) if (buffer_peek(_gr.b, (_y2 * 64 + _x2) * 4, buffer_u8) > 200) { _any = true; break; }
        if (!_any) _streak++;
    }
    fsp_st_assert(_st, _streak == 0, "an uncial O at a 44 px cap has no empty rows through its stem (" + string(_streak) + " empty)");
    buffer_delete(_gr.b); surface_free(_sf);

    fsp_st_stage(_st, 8);    // every glyph leaves INK, in every hand and every cut
    fsp_selftest_glyph_ink(_st);

    fsp_st_stage(_st, 9);    // whole screens: six houses built, each with ink where each layer belongs
    fsp_selftest_screens(_st);

    fsp_st_stage(_st, 10);   // the reveal and the input
    fsp_selftest_input(_st);

    fsp_st_stage(_st, 99);
    return _st;
}

/// @function fsp_rgb_ok(a, b)
function fsp_rgb_ok(_a, _b) { return is_array(_a) && is_array(_b) && abs(_a[0] - _b[0]) < 0.5 && abs(_a[1] - _b[1]) < 0.5 && abs(_a[2] - _b[2]) < 0.5; }

/// @function fsp_selftest_glyph_ink(st)
/// @description Cut every base character in every hand into a grey ground and count its ink - a glyph that builds
/// rings but draws nothing is invisible to stage 6. Then the same WORD in five hands must be five different pictures.
function fsp_selftest_glyph_ink(_st) {
    var _hands = fsp_alpha_hand_ids(), _chars = variable_struct_get_names(fsp_alpha_base()), _i, _j, _low = "", _count = 0, _minink = 100000, _minwho = "";
    var _sf = surface_create(128, 128);
    for (_i = 0; _i < array_length(_hands); _i++) for (_j = 0; _j < array_length(_chars); _j++) {
        if (_chars[_j] == " ") continue;
        surface_set_target(_sf); draw_clear_alpha(make_colour_rgb(128, 128, 128), 1);
        fsp_alpha_draw_line(_chars[_j], { x: 30, base_y: 96, cap_h: 64, hand: _hands[_i], cut: "printed", ground: [128, 128, 128], ink: [20, 20, 20] });
        surface_reset_target();
        var _gr = fsp_test_grab_surface(_sf), _ink = fsp_test_ink(_gr, { x: 0, y: 0, w: 128, h: 128 }, [128, 128, 128]);
        buffer_delete(_gr.b);
        _count++;
        if (_ink.n < _minink) { _minink = _ink.n; _minwho = _hands[_i] + ":" + _chars[_j]; }
        if (_ink.n < 30 || _ink.x0 <= 0 || _ink.y0 <= 0 || _ink.x1 >= 127 || _ink.y1 >= 127) _low += _hands[_i] + ":" + _chars[_j] + "(" + string(_ink.n) + ") ";
    }
    fsp_st_assert(_st, _count == 240 && _low == "", "all 240 inked glyphs (48 characters x 5 hands) leave at least 30 px of ink inside the surface [" + _low + "] - least: " + _minwho + " " + string(_minink) + " px");
    // control: the ink counter sees NOTHING on an untouched ground
    surface_set_target(_sf); draw_clear_alpha(make_colour_rgb(128, 128, 128), 1); surface_reset_target();
    var _g0 = fsp_test_grab_surface(_sf), _i0 = fsp_test_ink(_g0, { x: 0, y: 0, w: 128, h: 128 }, [128, 128, 128]);
    buffer_delete(_g0.b);
    fsp_st_assert(_st, _i0.n == 0, "control: an untouched ground counts 0 ink (" + string(_i0.n) + ")");
    surface_free(_sf);
    // five hands, one word: pairwise different pictures
    var _big = surface_create(560, 110), _grabs = [];
    for (_i = 0; _i < 5; _i++) {
        surface_set_target(_big); draw_clear_alpha(make_colour_rgb(128, 128, 128), 1);
        var _w = fsp_alpha_measure("KINGDOM", _hands[_i], 70);
        fsp_alpha_draw_line("KINGDOM", { x: (560 - _w) * 0.5, base_y: 88, cap_h: 70, hand: _hands[_i], cut: "printed", ground: [128, 128, 128], ink: [20, 20, 20] });
        surface_reset_target();
        array_push(_grabs, fsp_test_grab_surface(_big));
    }
    var _worst = 1000000, _wp = "";
    for (_i = 0; _i < 5; _i++) for (_j = _i + 1; _j < 5; _j++) {
        var _d = fsp_test_diff(_grabs[_i], _grabs[_j], { x: 0, y: 0, w: 560, h: 110 }, 1, 60);
        if (_d < _worst) { _worst = _d; _wp = _hands[_i] + "/" + _hands[_j]; }
    }
    fsp_st_assert(_st, _worst > 2500, "KINGDOM in five hands is five different pictures: the closest pair (" + _wp + ") differs in " + string(_worst) + " px");
    fsp_st_note(_st, "hands: closest pair " + _wp + " differs in " + string(_worst) + " px of 61,600");
    for (_i = 0; _i < 5; _i++) buffer_delete(_grabs[_i].b);
    // the four cuts are four different pictures on the same ground
    var _cuts = fsp_alpha_cut_ids(), _cg = [];
    for (_i = 0; _i < 4; _i++) {
        surface_set_target(_big); draw_clear_alpha(make_colour_rgb(142, 106, 62), 1);
        var _w2 = fsp_alpha_measure("KINGDOM", "lapidary", 70);
        fsp_alpha_draw_line("KINGDOM", { x: (560 - _w2) * 0.5, base_y: 88, cap_h: 70, hand: "lapidary", cut: _cuts[_i], ground: [142, 106, 62], ink: [214, 176, 92], delta: 64 });
        surface_reset_target();
        array_push(_cg, fsp_test_grab_surface(_big));
    }
    _worst = 1000000;
    for (_i = 0; _i < 4; _i++) for (_j = _i + 1; _j < 4; _j++) { var _d2 = fsp_test_diff(_cg[_i], _cg[_j], { x: 0, y: 0, w: 560, h: 110 }, 1, 20); if (_d2 < _worst) { _worst = _d2; _wp = _cuts[_i] + "/" + _cuts[_j]; } }
    fsp_st_assert(_st, _worst > 1500, "the four cuts are four different pictures: closest pair " + _wp + " differs in " + string(_worst) + " px");
    for (_i = 0; _i < 4; _i++) buffer_delete(_cg[_i].b);
    surface_free(_big);
}

/// @function fsp_selftest_screens(st)
/// @description Build all six houses at 640 x 360, supersampled, and assert ink per layer: the letters change the title
/// columns, the device changes its box, the chosen row changes the menu, and the six are six different screens.
function fsp_selftest_screens(_st) {
    var _H = fsp_houses(), _grabs = [], _i, _j, _ms = 0, _bad = "";
    for (_i = 0; _i < array_length(_H); _i++) {
        var _s = fsp_screen_create("Thanehold", { house: _H[_i].id, subtitle: "A Tale of the Late Kingdom", imprint: "CORE SYSTEMS ASSET FACTORY", width: 640, height: 360, reveal: false });
        _ms += _s.build_ms;
        var _base = fsp_test_grab(_s.spr_base), _full = fsp_test_grab(_s.spr_full);
        var _letters = 0;
        for (_j = 0; _j < array_length(_s.columns); _j++) _letters += fsp_test_diff(_base, _full, _s.columns[_j], 1, 24);
        var _vig = fsp_test_diff(_base, _full, _s.vig_rect, 1, 24);
        var _elsewhere = fsp_test_diff(_base, _full, { x: 0, y: 0, w: 640, h: 30 }, 1, 24);
        var _m0 = fsp_test_grab(_s.spr_menu[0]), _m2 = fsp_test_grab(_s.spr_menu[2]);
        var _menu = fsp_test_diff(_m0, _m2, { x: 0, y: 0, w: _m0.w, h: _m0.h }, 1, 24);
        if (_s.report.glyphs != 9 || _letters < 1500 || _vig < 300 || _elsewhere != 0 || _menu < 150 || !_s.report.imprint || _s.report.fallback) {
            _bad += _H[_i].id + "(glyphs " + string(_s.report.glyphs) + " letters " + string(_letters) + " vig " + string(_vig) + " top " + string(_elsewhere) + " menu " + string(_menu) + ") ";
        }
        fsp_st_note(_st, _H[_i].id + ": letters " + string(_letters) + " px, device " + string(_vig) + " px (" + string(_s.report.vignette_units) + " units), menu change " + string(_menu) + " px, cap " + string_format(_s.report.cap_h, 1, 1) + " px, built " + string(round(_s.build_ms)) + " ms");
        buffer_delete(_base.b); buffer_delete(_m0.b); buffer_delete(_m2.b);
        array_push(_grabs, _full);
        var _held = [_s.spr_base, _s.spr_full, _s.spr_menu[0]];
        fsp_screen_free(_s);
        fsp_st_assert(_st, sprite_exists(_held[0]) == false && sprite_exists(_held[1]) == false && sprite_exists(_held[2]) == false, "free() deletes the sprites it made (" + _H[_i].id + ")");
    }
    fsp_st_assert(_st, _bad == "", "six houses: 9 glyphs cut, the letters and the device add ink where they belong and NOWHERE else, the chosen row visibly moves [" + _bad + "]");
    var _worst = 10000000, _wp = "";
    for (_i = 0; _i < 6; _i++) for (_j = _i + 1; _j < 6; _j++) {
        var _d = fsp_test_diff(_grabs[_i], _grabs[_j], { x: 0, y: 0, w: 640, h: 360 }, 3, 30);
        if (_d < _worst) { _worst = _d; _wp = _H[_i].id + "/" + _H[_j].id; }
    }
    fsp_st_assert(_st, _worst > 8000, "the six houses are six different screens: closest pair " + _wp + " differs in " + string(_worst) + " of 25,600 sampled px");
    fsp_st_note(_st, "houses: closest pair " + _wp + " " + string(_worst) + " sampled px; mean build " + string(round(_ms / 6)) + " ms at 640x360 x2");
    for (_i = 0; _i < 6; _i++) buffer_delete(_grabs[_i].b);
    // a title the corpus cannot cut still builds, lettered in the fallback font
    var _jp = fsp_screen_create(chr($6708) + chr($306E) + chr($5BAE), { house: "vigil", width: 480, height: 270, reveal: false });
    fsp_st_assert(_st, _jp.report.fallback && _jp.report.coverage == 0 && sprite_exists(_jp.spr_full), "a Japanese title falls back to the font path and still builds");
    fsp_screen_free(_jp);
}

/// @function fsp_selftest_input(st)
/// @description The reveal timeline and the menu's input contract.
function fsp_selftest_input(_st) {
    var _s = fsp_screen_create("Moonwake", { house: "vigil", width: 480, height: 270, commands: ["New Game", "Continue", "Options", "Quit"], enabled: [true, false, true, true] });
    var _tl = fsp__timeline(_s), _all0 = true, _i;
    for (_i = 0; _i < array_length(_tl.glyph); _i++) if (_tl.glyph[_i] != 0) _all0 = false;
    fsp_st_assert(_st, _all0 && _tl.vignette == 0 && _tl.rows[0] == 0 && !fsp_screen_revealed(_s), "at frame 0 nothing is cut yet");
    fsp_st_assert(_st, fsp_screen_confirm(_s) == -1 && fsp_screen_revealed(_s), "confirm during the reveal finishes it instead of choosing");
    _s.t = 0;
    var _prev = -1, _mono = true, _cut_order = true;
    for (var _t = 0; _t < fsp__reveal_end(_s) + 2; _t++) {
        _s.t = _t; _tl = fsp__timeline(_s);
        if (_tl.glyph[0] < _prev) _mono = false;
        _prev = _tl.glyph[0];
        for (_i = 1; _i < array_length(_tl.glyph); _i++) if (_tl.glyph[_i] > _tl.glyph[_i - 1] + 0.0001) _cut_order = false;
    }
    fsp_st_assert(_st, _mono && _cut_order && array_length(_tl.glyph) == 8, "the letters are cut in reading order, each finishing what it started (" + string(array_length(_tl.glyph)) + " columns)");
    fsp_st_assert(_st, fsp_screen_revealed(_s) && _tl.vignette == 1 && _tl.rows[3] == 1, "by the reveal's end frame everything is up");
    fsp_st_assert(_st, fsp_screen_index(_s) == 0 && fsp_screen_move(_s, 1) == 2, "moving down from New Game skips the disabled Continue");
    fsp_st_assert(_st, fsp_screen_move(_s, 1) == 3 && fsp_screen_move(_s, 1) == 0 && fsp_screen_move(_s, -1) == 3, "the choice wraps both ways");
    fsp_st_assert(_st, !fsp_screen_select(_s, 1) && fsp_screen_index(_s) == 3, "a disabled row cannot be selected");
    var _r2 = _s.rows[2];
    fsp_st_assert(_st, fsp_screen_hover(_s, _r2.x + _r2.w * 0.5, _r2.y + _r2.h * 0.5) == 2 && fsp_screen_index(_s) == 2 && _s.fade == 0, "the mouse over a row chooses it and starts the crossfade");
    fsp_st_assert(_st, fsp_screen_hover(_s, -50, -50) == -1 && fsp_screen_index(_s) == 2, "a mouse off the menu leaves the choice alone");
    for (_i = 0; _i < 12; _i++) fsp_screen_step(_s);
    fsp_st_assert(_st, _s.fade == 1, "the crossfade completes");
    fsp_st_assert(_st, fsp_screen_confirm(_s) == 2, "confirm returns the chosen row");
    fsp_st_assert(_st, !fsp_screen_set_house(_s, "palace") && fsp_screen_set_house(_s, "foundry", "Second Edition") && _s.spec.house == "foundry" && sprite_exists(_s.spr_full), "set_house refuses an unknown house and rebuilds for a real one");
    fsp_st_assert(_st, fsp_screen_set_enabled(_s, 1, true) && fsp_screen_select(_s, 1), "enabling a row makes it choosable");
    fsp_screen_free(_s);
    // wrong-typed input never throws
    fsp_screen_draw(undefined, 0, 0); fsp_screen_step(undefined);
    fsp_st_assert(_st, fsp_screen_confirm(undefined) == -1 && fsp_screen_move("x", 1) == -1 && fsp_screen_row_at(undefined, 0, 0) == -1, "undefined screens are refused, not crashed on");
}

/// @function fsp_selftest_write(st)
function fsp_selftest_write(_st) {
    var _f = file_text_open_write("fsp_selftest.json");
    file_text_write_string(_f, "{\"total\":" + string(_st.total) + ",\"pass\":" + string(_st.pass) + ",\"fail\":" + string(_st.fail) + ",\"stage\":" + string(_st.stage) + ",\"notes\":[");
    for (var _i = 0; _i < array_length(_st.notes); _i++) { if (_i > 0) file_text_write_string(_f, ","); file_text_write_string(_f, "\"" + string_replace_all(_st.notes[_i], "\"", "'") + "\""); }
    file_text_write_string(_f, "],\"failures\":[");
    for (var _j = 0; _j < array_length(_st.failures); _j++) { if (_j > 0) file_text_write_string(_f, ","); file_text_write_string(_f, "\"" + string_replace_all(_st.failures[_j], "\"", "'") + "\""); }
    file_text_write_string(_f, "]}");
    file_text_close(_f);
}
