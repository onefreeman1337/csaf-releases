/// fsp_corpus.gml - the corpus: eight grounds, six frames, six cartouches, twelve ornaments, six vignettes, six menu
/// treatments, six houses - and the reading that turns YOUR game's title and vocabulary into one screen. Tables and the
/// reading only; no drawing.
///
/// Frontispiece - The Title Screen, Generated, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// WHAT A HOUSE IS: a whole visual argument, not a colour scheme - a ground MATERIAL, a border CONSTRUCTION, a
/// cartouche FORM, a hand, a cut, an ornament vocabulary, a vignette CONSTRUCTION, a menu TREATMENT and a palette,
/// authored so that no two houses share more than two of those axes.
///
/// HOW A HOUSE IS CHOSEN: a parameter with six named choices, defaulting to "auto". "auto" scores the words you hand
/// it (your elements, classes, regions - whatever names your game uses) and, when they do not clearly point at one
/// house, falls back to a stable hash of the game's TITLE - the one field no two games share - so two games that pass
/// nothing still get different screens, and a given game gets the same screen every time.

/// @function fsp_grounds()
/// @description The eight ground materials. Each has its own TREATMENT (how the surface is worked), not only a colour:
/// a recolour would be the palette-is-not-a-composition failure across the whole frame. Pure.
function fsp_grounds() {
    static _G = [
        { id: "vellum", label: "Vellum", treatment: "mottle", base: [222, 212, 188], deep: [196, 182, 152], grain: 0.055, note: "prepared skin, faintly mottled, follicle specks" },
        { id: "leather", label: "Tooled leather", treatment: "pore", base: [78, 46, 38], deep: [44, 24, 20], grain: 0.16, note: "grained hide with a blind-tooled impression" },
        { id: "slate", label: "Riven slate", treatment: "cleave", base: [70, 74, 80], deep: [40, 44, 50], grain: 0.13, note: "split stone, cleavage bands, picked edges" },
        { id: "bronze", label: "Planished bronze", treatment: "hammer", base: [138, 108, 62], deep: [86, 64, 34], grain: 0.20, note: "hammer facets catching a fixed light, verdigris in the lows" },
        { id: "lacquer", label: "Black lacquer", treatment: "sheen", base: [24, 26, 34], deep: [8, 9, 13], grain: 0.05, note: "deep polish with a soft specular sweep and fine crazing" },
        { id: "linen", label: "Woven linen", treatment: "weave", base: [186, 178, 158], deep: [150, 142, 122], grain: 0.09, note: "warp and weft at a real pitch" },
        { id: "oak", label: "Quartersawn oak", treatment: "grain", base: [142, 106, 62], deep: [92, 64, 34], grain: 0.15, note: "straight grain with medullary rays" },
        { id: "steel", label: "Brushed steel", treatment: "brush", base: [116, 122, 130], deep: [72, 78, 86], grain: 0.10, note: "anisotropic brush, seam lines and countersunk fixings" }];
    return _G;
}

/// @function fsp_frames()
/// @description The six border constructions. Each declares a PITCH as a multiple of its band thickness, never a
/// COUNT: the right count changes with the size of the piece. Pure.
function fsp_frames() {
    static _F = [
        { id: "fillet", label: "Fillet", band: 0.030, pitch_mul: 0, corner: "none", note: "a broad rule with a fine inner line set off it" },
        { id: "dentil", label: "Dentil", band: 0.034, pitch_mul: 2.1, corner: "block", note: "a run of cut blocks under a rule" },
        { id: "guilloche", label: "Guilloche", band: 0.040, pitch_mul: 3.4, corner: "boss", note: "two interlaced ribbons on a single rule" },
        { id: "strapwork", label: "Strapwork", band: 0.046, pitch_mul: 0, corner: "boss", note: "a raised strap with a bead down its centre and corner bosses" },
        { id: "rope", label: "Cable", band: 0.036, pitch_mul: 1.35, corner: "knot", note: "a twisted cable laid along the edge" },
        { id: "corners", label: "Corner pieces", band: 0.030, pitch_mul: 0, corner: "spandrel", note: "no continuous border; four cut corner pieces only" }];
    return _F;
}

/// @function fsp_cartouches()
/// @description The six fields the wordmark is set in. Pure.
function fsp_cartouches() {
    static _C = [
        { id: "tablet", label: "Sunk tablet", pad: 0.085, head: 0.00, sunk: 1, note: "a rectangular panel sunk below the ground with a chamfered edge" },
        { id: "lozenge", label: "Lozenge", pad: 0.115, head: 0.00, sunk: 0, note: "a panel with its corners cut away to a diamond" },
        { id: "scroll", label: "Scroll", pad: 0.10, head: 0.00, sunk: 0, note: "a sheet with both ends rolled, shadowed under the curl" },
        { id: "pediment", label: "Pediment", pad: 0.09, head: 0.30, sunk: 1, note: "a sunk panel under a low triangular head" },
        { id: "banderole", label: "Banderole", pad: 0.075, head: 0.00, sunk: 0, note: "a ribbon with folded tails passing behind the frame" },
        { id: "open", label: "Open", pad: 0.05, head: 0.00, sunk: 0, note: "no panel at all; the wordmark is cut into the ground between rules" }];
    return _C;
}

/// @function fsp_ornaments()
/// @description The twelve fleurons. A printer's flower is not a blob: it is LOBES arranged on a STEM, or lobes
/// arranged RADIALLY, with a defined tip - and that structure is what survives at the twenty to thirty pixels an
/// ornament is seen at. Each declares its CONSTRUCTION; five lobe kinds (leaf, disc, curl, spike, bud) are drawn by one
/// function, so twelve ornaments share five shapes and cannot drift apart. Typographic ornament, deliberately NOT
/// heraldry. Pure.
function fsp_ornaments() {
    static _O = [
        { id: "leaf", label: "Leaf spray", weight: 1.00, radial: 0, stem: [[0.50, 1.00], [0.50, 0.62], [0.50, 0.24]],
          lobes: [{ t: 0.22, len: 0.44, wid: 0.30, tilt: 0.72, kind: "leaf", one: 0 }, { t: 0.58, len: 0.38, wid: 0.26, tilt: 0.52, kind: "leaf", one: 0 }],
          tip: { kind: "leaf", len: 0.42, wid: 0.26 } },
        // A ROUND nut over a flat collar: as a blunt bud it read as the same picture as `bud`.
        { id: "acorn", label: "Acorn", weight: 0.94, radial: 0, stem: [[0.50, 1.00], [0.50, 0.62]],
          lobes: [{ t: 0.86, len: 0.46, wid: 0.30, tilt: 1.50, kind: "leaf", one: 0 }], tip: { kind: "disc", len: 0.56, wid: 0.28 } },
        { id: "palmette", label: "Palmette", weight: 1.06, radial: 0, stem: [[0.50, 1.00], [0.50, 0.78]],
          lobes: [{ t: 0.60, len: 0.50, wid: 0.26, tilt: 1.28, kind: "spike", one: 0 }, { t: 0.75, len: 0.58, wid: 0.26, tilt: 0.86, kind: "spike", one: 0 }, { t: 0.90, len: 0.62, wid: 0.26, tilt: 0.42, kind: "spike", one: 0 }],
          tip: { kind: "spike", len: 0.62, wid: 0.28 } },
        // BLUNT petals: with leaf lobes it read as a six-pointed star, and `star` owns the radial point.
        { id: "rosette", label: "Rosette", weight: 1.00, radial: 6, phase: 0, lobe: { kind: "bud", len: 0.62, wid: 0.34 }, alt: undefined, centre: { kind: "disc", size: 0.32 } },
        { id: "trefoil", label: "Trefoil", weight: 1.00, radial: 3, phase: -1.5708, lobe: { kind: "disc", len: 0.66, wid: 0.33 }, alt: undefined, centre: { kind: "disc", size: 0.16 } },
        // Four lobes on the cardinals, NO boss: a plus, not a flower.
        { id: "quatrefoil", label: "Quatrefoil", weight: 1.00, radial: 4, phase: -0.7854, lobe: { kind: "disc", len: 0.58, wid: 0.29 }, alt: undefined, centre: undefined },
        { id: "vine", label: "Vine", weight: 1.05, radial: 0, stem: [[0.44, 1.00], [0.62, 0.72], [0.40, 0.44], [0.56, 0.20]],
          lobes: [{ t: 0.26, len: 0.34, wid: 0.24, tilt: 1.05, kind: "leaf", one: 1 }, { t: 0.62, len: 0.30, wid: 0.22, tilt: -1.05, kind: "leaf", one: 1 }],
          tip: { kind: "curl", len: 0.44, wid: 0.16 } },
        { id: "star", label: "Star", weight: 1.00, radial: 5, phase: -1.5708, lobe: { kind: "spike", len: 0.92, wid: 0.30 }, alt: undefined, centre: { kind: "disc", size: 0.18 } },
        { id: "sunburst", label: "Sunburst", weight: 1.00, radial: 8, phase: 0, lobe: { kind: "spike", len: 0.90, wid: 0.17 }, alt: { kind: "spike", len: 0.56, wid: 0.13 }, centre: { kind: "disc", size: 0.30 } },
        { id: "knot", label: "Knot", weight: 1.00, radial: 4, phase: -0.7854, lobe: { kind: "curl", len: 0.72, wid: 0.20 }, alt: undefined, centre: { kind: "disc", size: 0.18 } },
        { id: "wave", label: "Wave", weight: 1.04, radial: 0, stem: [[0.14, 0.66], [0.38, 0.40], [0.62, 0.68], [0.86, 0.40]],
          lobes: [{ t: 0.32, len: 0.26, wid: 0.18, tilt: 1.30, kind: "curl", one: 1 }, { t: 0.78, len: 0.26, wid: 0.18, tilt: -1.30, kind: "curl", one: 1 }],
          tip: undefined },
        { id: "bud", label: "Bud", weight: 0.96, radial: 0, stem: [[0.50, 1.00], [0.50, 0.60]],
          lobes: [{ t: 0.42, len: 0.40, wid: 0.24, tilt: 0.86, kind: "leaf", one: 0 }], tip: { kind: "bud", len: 0.48, wid: 0.34 } }];
    return _O;
}

/// @function fsp_vignettes()
/// @description How ornament units are arranged into the device. Pure.
function fsp_vignettes() {
    static _V = [
        { id: "spray", label: "Spray", note: "a mirrored pair springing from a centre unit" },
        { id: "wreath", label: "Wreath", note: "a ring of units about an open centre" },
        { id: "lozenge", label: "Lozenge", note: "four-fold, on the diagonals, in a cut diamond" },
        { id: "band", label: "Band", note: "a horizontal run between two terminals" },
        { id: "crest", label: "Crest", note: "stacked to a point above a base rule" },
        { id: "rule", label: "Tailpiece", note: "one unit centred on a long tapering rule" }];
    return _V;
}

/// @function fsp_menus()
/// @description The six command-list treatments - the house's own furniture, never a stock window. Pure.
function fsp_menus() {
    static _M = [
        { id: "slots", label: "Sunk slots", note: "each command in an incised slot; the chosen one deepens" },
        { id: "plaques", label: "Plaques", note: "raised bevelled plaques; the chosen one lifts and lights" },
        { id: "rules", label: "Rules", note: "no panel; a hairline under each, a full rule and flanking marks on the chosen one" },
        { id: "tabs", label: "Tabs", note: "angled tabs off a spine; the chosen one runs out" },
        { id: "column", label: "Column", note: "a ruled column with a cut chevron that travels" },
        { id: "cartouches", label: "Small cartouches", note: "each command in a miniature of the house's own cartouche" }];
    return _M;
}

/// @function fsp_houses()
/// @description The six houses. Pure.
function fsp_houses() {
    static _H = [
        { id: "chancery", label: "Chancery", ground: "vellum", frame: "fillet", cartouche: "scroll", hand: "uncial", cut: "printed", vignette: "spray", menu: "rules",
          ink: [86, 44, 30], accent: [148, 42, 38], ornaments: ["vine", "leaf", "bud"], note: "a chancery manuscript: ink on prepared skin, ruled and rubricated" },
        { id: "sanctum", label: "Sanctum", ground: "slate", frame: "strapwork", cartouche: "pediment", hand: "lapidary", cut: "incised", vignette: "lozenge", menu: "slots",
          ink: [206, 200, 186], accent: [186, 150, 82], ornaments: ["rosette", "palmette", "trefoil"], note: "an inscription cut into riven stone under a low pediment" },
        { id: "folio", label: "Folio", ground: "leather", frame: "dentil", cartouche: "tablet", hand: "textura", cut: "inlaid", vignette: "wreath", menu: "plaques",
          ink: [214, 176, 92], accent: [176, 62, 52], ornaments: ["quatrefoil", "acorn", "leaf"], note: "a bound folio: gold tooled into grained hide" },
        { id: "hall", label: "Hall", ground: "oak", frame: "rope", cartouche: "banderole", hand: "stave", cut: "raised", vignette: "crest", menu: "tabs",
          ink: [238, 224, 196], accent: [196, 152, 74], ornaments: ["knot", "star", "wave"], note: "a carved board over a hall door, proud of the oak" },
        { id: "foundry", label: "Foundry", ground: "steel", frame: "guilloche", cartouche: "lozenge", hand: "grotesk", cut: "incised", vignette: "band", menu: "column",
          ink: [226, 232, 240], accent: [226, 158, 62], ornaments: ["sunburst", "star", "wave"], note: "etched into a brushed steel plate, seamed and fixed" },
        { id: "vigil", label: "Vigil", ground: "lacquer", frame: "corners", cartouche: "open", hand: "uncial", cut: "inlaid", vignette: "rule", menu: "cartouches",
          ink: [196, 206, 222], accent: [132, 154, 196], ornaments: ["star", "trefoil", "wave"], note: "silver laid into black lacquer, nothing between the letters and the dark" }];
    return _H;
}

/// @function fsp_find(list, id)
/// @description The record with this id in a corpus list, or undefined. Pure.
function fsp_find(_list, _id) {
    if (!is_array(_list) || !is_string(_id)) return undefined;
    for (var _i = 0; _i < array_length(_list); _i++) if (_list[_i].id == _id) return _list[_i];
    return undefined;
}

/// @function fsp_ids(list)
/// @description The ids of a corpus list, in order. Pure.
function fsp_ids(_list) {
    var _o = array_create(array_length(_list));
    for (var _i = 0; _i < array_length(_list); _i++) _o[_i] = _list[_i].id;
    return _o;
}

/// @function fsp_corpus_volume()
/// @description What the corpus COULD make, counted from the tables (the tests check it against them, never against
/// a comment). Deliberately NOT the headline claim: a buyer sees what their own title resolves to. Pure.
function fsp_corpus_volume() {
    var _v = { grounds: array_length(fsp_grounds()), frames: array_length(fsp_frames()), cartouches: array_length(fsp_cartouches()),
        ornaments: array_length(fsp_ornaments()), vignettes: array_length(fsp_vignettes()), menus: array_length(fsp_menus()), houses: array_length(fsp_houses()) };
    _v.combinations = _v.grounds * _v.frames * _v.cartouches * _v.vignettes * _v.menus;
    return _v;
}

/// @function fsp_vocab()
/// @description The words that belong to each house. Matched as substrings of the words YOU pass, so a game whose
/// elements are "Void, Aether, Circuit" reads differently from one with "Fire, Ice, Thunder". Pure.
function fsp_vocab() {
    static _V = {
        chancery: ["scroll", "letter", "word", "lore", "seal", "oath", "rune", "ink", "song", "verse", "name", "tale", "chant", "scribe", "tome"],
        sanctum: ["holy", "light", "divine", "sacred", "temple", "saint", "prayer", "faith", "grace", "shrine", "altar", "stone", "earth", "clergy", "priest"],
        folio: ["dark", "blood", "curse", "shadow", "sin", "grimoire", "demon", "witch", "hex", "necro", "bane", "plague", "crypt", "wraith"],
        hall: ["axe", "shield", "hammer", "spear", "wolf", "frost", "ice", "snow", "north", "war", "oak", "horn", "boar", "thane", "ale"],
        foundry: ["machine", "gear", "steam", "circuit", "laser", "plasma", "tech", "cyber", "robot", "engine", "core", "reactor", "volt", "data", "drone", "nano", "mech", "alloy"],
        vigil: ["star", "moon", "night", "dream", "void", "astral", "sky", "cosmos", "silver", "mist", "ghost", "spirit", "aether", "lunar", "omen"] };
    return _V;
}

/// @function fsp_words_of(title, words)
/// @description The lower-case words a game uses to describe itself: its title split into words, plus every string in
/// `words`, split the same way. Words of two letters or fewer are dropped. Anything that is not a string is skipped
/// rather than guessed - a title screen that throws is the worst place for it. Pure.
function fsp_words_of(_title, _words) {
    var _out = [], _src = [];
    if (is_string(_title)) array_push(_src, _title);
    if (is_array(_words)) for (var _i = 0; _i < array_length(_words); _i++) if (is_string(_words[_i])) array_push(_src, _words[_i]);
    for (var _k = 0; _k < array_length(_src); _k++) {
        var _s = string_lower(_src[_k]), _cur = "";
        for (var _j = 1; _j <= string_length(_s) + 1; _j++) {
            var _c = (_j <= string_length(_s)) ? string_char_at(_s, _j) : " ";
            var _o = ord(_c);
            if (_o >= 97 && _o <= 122) _cur += _c;
            else { if (string_length(_cur) > 2) array_push(_out, _cur); _cur = ""; }
        }
    }
    return _out;
}

/// @function fsp_read_house(title, words)
/// @description Choose a house: {house, why, scores}. Stage 1 scores the words against each house's vocabulary and
/// needs a REAL margin (3+ words and 2 clear of the runner-up - one shared word is noise, and acting on noise gives a
/// CONFIDENT wrong answer). Stage 2, whenever stage 1 is not decisive, hashes the TITLE - the one field no two games
/// share - so games that pass nothing still spread across the six houses. Pure.
function fsp_read_house(_title, _words) {
    var _ws = fsp_words_of(_title, _words), _V = fsp_vocab(), _ids = fsp_ids(fsp_houses()), _scores = {}, _i, _k;
    for (_k = 0; _k < array_length(_ids); _k++) _scores[$ _ids[_k]] = 0;
    for (_i = 0; _i < array_length(_ws); _i++) {
        for (_k = 0; _k < array_length(_ids); _k++) {
            var _list = _V[$ _ids[_k]];
            for (var _j = 0; _j < array_length(_list); _j++) {
                if (string_pos(_list[_j], _ws[_i]) > 0) { _scores[$ _ids[_k]] += 1; break; }
            }
        }
    }
    var _best = "", _bn = -1, _second = 0;
    for (_k = 0; _k < array_length(_ids); _k++) {
        var _v = _scores[$ _ids[_k]];
        if (_v > _bn) { _second = max(_second, _bn); _bn = _v; _best = _ids[_k]; } else if (_v > _second) _second = _v;
    }
    if (_bn >= 3 && _bn >= _second + 2) return { house: _best, why: "vocabulary", scores: _scores };
    var _t = is_string(_title) ? _title : "";
    return { house: _ids[fsp_hash("frontispiece-house:" + _t) mod array_length(_ids)], why: (_t != "") ? "title-hash" : "default", scores: _scores };
}

/// @function fsp_read_ornaments(title, words, house)
/// @description Choose the device's ornament units: {ids, why}. The house supplies three; a word that names something
/// specific (fire, sea, frost, beast...) replaces the lead one, so two games in the same house still differ. With
/// nothing to read, the house's three are rotated by a stable hash of the title. Pure.
function fsp_read_ornaments(_title, _words, _house) {
    static _MAP = [
        ["sunburst", ["fire", "flame", "sun", "burn", "ember", "blaze", "solar"]],
        ["star", ["star", "astral", "light", "holy", "lunar", "moon", "sky"]],
        ["wave", ["water", "sea", "ocean", "tide", "river", "rain", "wind", "storm"]],
        ["leaf", ["earth", "wood", "forest", "nature", "grass", "leaf", "plant"]],
        ["knot", ["dark", "void", "shadow", "curse", "bind", "chain", "hex"]],
        ["quatrefoil", ["ice", "frost", "snow", "crystal", "glass"]],
        ["acorn", ["beast", "wild", "boar", "wolf", "hunt"]],
        ["vine", ["life", "heal", "grow", "bloom", "spring"]]];
    var _ws = fsp_words_of(_title, _words), _found = "";
    for (var _i = 0; _i < array_length(_MAP) && _found == ""; _i++) {
        var _keys = _MAP[_i][1];
        for (var _j = 0; _j < array_length(_keys) && _found == ""; _j++) {
            for (var _k = 0; _k < array_length(_ws); _k++) if (string_pos(_keys[_j], _ws[_k]) > 0) { _found = _MAP[_i][0]; break; }
        }
    }
    var _ids = [];
    array_copy(_ids, 0, _house.ornaments, 0, array_length(_house.ornaments));
    if (_found != "" && array_get_index(_ids, _found) < 0) { _ids[0] = _found; return { ids: _ids, why: "word:" + _found }; }
    var _t = is_string(_title) ? _title : "";
    var _r = fsp_hash("frontispiece-orn:" + _t) mod array_length(_ids), _rot = [];
    for (var _m = 0; _m < array_length(_ids); _m++) array_push(_rot, _ids[(_m + _r) mod array_length(_ids)]);
    return { ids: _rot, why: (_t != "") ? "title-rotation" : "house-default" };
}

/// @function fsp_compose(title, [options])
/// @description Everything one screen needs, resolved once. options (all optional): {house, ground, frame, cartouche,
/// hand, cut, vignette, menu} - each "auto" or an id from the tables - and {words}: an array of strings your game uses
/// (element, class, region, faction names) for the reading. An UNKNOWN id never crashes: it falls back to the house's
/// own choice and is listed in the returned `warnings`. Pure.
function fsp_compose(_title, _opt = undefined) {
    var _o = is_struct(_opt) ? _opt : {};
    var _t = is_string(_title) ? _title : string(_title);
    var _words = variable_struct_exists(_o, "words") ? _o.words : [];
    var _warn = [];
    var _read = fsp_read_house(_t, _words);
    var _hid = _read.house, _hwhy = _read.why;
    if (variable_struct_exists(_o, "house") && is_string(_o.house) && _o.house != "auto") {
        if (is_struct(fsp_find(fsp_houses(), _o.house))) { _hid = _o.house; _hwhy = "parameter"; } else array_push(_warn, "unknown house '" + _o.house + "'");
    }
    var _house = fsp_find(fsp_houses(), _hid);
    var _orn = fsp_read_ornaments(_t, _words, _house);
    var _axes = [["ground", fsp_grounds()], ["frame", fsp_frames()], ["cartouche", fsp_cartouches()], ["vignette", fsp_vignettes()], ["menu", fsp_menus()]];
    var _spec = { house: _hid, house_why: _hwhy, house_scores: _read.scores, title: _t, ornaments: _orn.ids, ornament_why: _orn.why,
        ink: _house.ink, accent: _house.accent, hand: _house.hand, cut: _house.cut, warnings: _warn };
    for (var _i = 0; _i < array_length(_axes); _i++) {
        var _name = _axes[_i][0], _v = _house[$ _name];
        if (variable_struct_exists(_o, _name) && is_string(_o[$ _name]) && _o[$ _name] != "auto") {
            if (is_struct(fsp_find(_axes[_i][1], _o[$ _name]))) _v = _o[$ _name]; else array_push(_warn, "unknown " + _name + " '" + _o[$ _name] + "'");
        }
        _spec[$ _name] = _v;
    }
    if (variable_struct_exists(_o, "hand") && is_string(_o.hand) && _o.hand != "auto") {
        if (is_struct(fsp_alpha_hand(_o.hand))) _spec.hand = _o.hand; else array_push(_warn, "unknown hand '" + _o.hand + "'");
    }
    if (variable_struct_exists(_o, "cut") && is_string(_o.cut) && _o.cut != "auto") {
        if (array_get_index(fsp_alpha_cut_ids(), _o.cut) >= 0) _spec.cut = _o.cut; else array_push(_warn, "unknown cut '" + _o.cut + "'");
    }
    _spec.seed = fsp_hash("frontispiece:" + _t + ":" + _hid);
    return _spec;
}
