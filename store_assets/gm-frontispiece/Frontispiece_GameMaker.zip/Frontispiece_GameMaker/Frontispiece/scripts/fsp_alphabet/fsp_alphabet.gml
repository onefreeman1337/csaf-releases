/// fsp_alphabet.gml - the authored letterform corpus. 79 hand-authored skeletons, five hands, one pen simulation, four
/// cuts. The wordmark is CUT, letter by letter, from these - never typed in a font.
///
/// Frontispiece - The Title Screen, Generated, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// WHAT IS IN HERE
///   SKELETONS  49 base skeletons - A-Z, 0-9 and the punctuation a title uses - each a set of strokes drawn in a unit
///              design box in the order a hand would draw them.
///   HANDS      5 hands. A hand is a TOOL (a broad nib at an angle, or a round pen), whether curves are SMOOTHED or
///              left as straight facets, a proportion, a terminal, and its own OVERRIDE skeletons for the letters that
///              really are built differently in its tradition.
///   OVERRIDES  30 further skeletons across uncial, textura and stave.
///   => 79 authored skeletons, 245 base glyphs (49 x 5). fsp_alpha_volume() COUNTS them; the suite asserts the count.
///
/// Design box: x runs 0..1 across the glyph's own advance, y runs 0 at the cap line to 1 at the baseline (descenders
/// pass 1). A stroke is {p: points, c: 1 to smooth as a curve, k: 1 to close the loop, d: 1 for a pen set down once}.
/// `w` is the advance in cap heights, and the widths are the Roman ones - E F L narrow, M W wide, O Q C G D broad.
///
/// COVERAGE, STATED HONESTLY: Latin capitals, digits and common punctuation. fsp_alpha_coverage() reports the fraction
/// of a title that can be cut; below 60% the screen letters the title in a FONT with the same cut instead.

/// @function fsp__st(points, [curve], [closed], [dot])
/// @description One skeleton stroke. Internal.
function fsp__st(_p, _c = 0, _k = 0, _d = 0) { return { p: _p, c: _c, k: _k, d: _d }; }

/// @function fsp__sk(w, strokes)
/// @description One skeleton: advance width (in cap heights) and strokes. Internal.
function fsp__sk(_w, _s) { return { w: _w, s: _s }; }

/// @function fsp_alpha_base()
/// @description The 49 base skeletons, keyed by character. Built once. Pure.
function fsp_alpha_base() {
    static _S = undefined;
    if (!is_undefined(_S)) return _S;
    _S = {};
    _S[$ "A"] = fsp__sk(0.70, [fsp__st([[0.03, 1.00], [0.50, 0.02]]), fsp__st([[0.50, 0.02], [0.97, 1.00]]), fsp__st([[0.19, 0.70], [0.81, 0.70]])]);
    _S[$ "B"] = fsp__sk(0.60, [fsp__st([[0.10, 0.02], [0.10, 0.98]]),
        fsp__st([[0.10, 0.03], [0.56, 0.05], [0.72, 0.26], [0.56, 0.47], [0.10, 0.50]], 1),
        fsp__st([[0.10, 0.50], [0.64, 0.53], [0.82, 0.74], [0.62, 0.95], [0.10, 0.97]], 1)]);
    _S[$ "C"] = fsp__sk(0.68, [fsp__st([[0.92, 0.24], [0.76, 0.06], [0.44, 0.01], [0.14, 0.20], [0.08, 0.52], [0.14, 0.82], [0.44, 0.99], [0.76, 0.94], [0.92, 0.76]], 1)]);
    _S[$ "D"] = fsp__sk(0.70, [fsp__st([[0.10, 0.02], [0.10, 0.98]]), fsp__st([[0.10, 0.02], [0.52, 0.04], [0.86, 0.30], [0.86, 0.70], [0.52, 0.96], [0.10, 0.98]], 1)]);
    _S[$ "E"] = fsp__sk(0.56, [fsp__st([[0.12, 0.02], [0.12, 0.98]]), fsp__st([[0.12, 0.03], [0.88, 0.03]]), fsp__st([[0.12, 0.50], [0.72, 0.50]]), fsp__st([[0.12, 0.97], [0.90, 0.97]])]);
    _S[$ "F"] = fsp__sk(0.54, [fsp__st([[0.12, 0.02], [0.12, 0.98]]), fsp__st([[0.12, 0.03], [0.88, 0.03]]), fsp__st([[0.12, 0.48], [0.72, 0.48]])]);
    _S[$ "G"] = fsp__sk(0.72, [fsp__st([[0.92, 0.24], [0.76, 0.06], [0.44, 0.01], [0.14, 0.20], [0.08, 0.52], [0.14, 0.82], [0.46, 0.99], [0.78, 0.92], [0.90, 0.72], [0.90, 0.57]], 1), fsp__st([[0.60, 0.57], [0.92, 0.57]])]);
    _S[$ "H"] = fsp__sk(0.70, [fsp__st([[0.10, 0.02], [0.10, 0.98]]), fsp__st([[0.90, 0.02], [0.90, 0.98]]), fsp__st([[0.10, 0.50], [0.90, 0.50]])]);
    _S[$ "I"] = fsp__sk(0.24, [fsp__st([[0.50, 0.02], [0.50, 0.98]])]);
    _S[$ "J"] = fsp__sk(0.46, [fsp__st([[0.74, 0.02], [0.74, 0.72], [0.62, 0.95], [0.34, 1.00], [0.10, 0.86]], 1)]);
    _S[$ "K"] = fsp__sk(0.64, [fsp__st([[0.10, 0.02], [0.10, 0.98]]), fsp__st([[0.94, 0.02], [0.14, 0.54]]), fsp__st([[0.34, 0.40], [0.96, 0.98]])]);
    _S[$ "L"] = fsp__sk(0.54, [fsp__st([[0.12, 0.02], [0.12, 0.97]]), fsp__st([[0.12, 0.97], [0.90, 0.97]])]);
    _S[$ "M"] = fsp__sk(0.86, [fsp__st([[0.05, 0.98], [0.05, 0.02], [0.50, 0.76], [0.95, 0.02], [0.95, 0.98]])]);
    _S[$ "N"] = fsp__sk(0.74, [fsp__st([[0.10, 0.98], [0.10, 0.02], [0.90, 0.96], [0.90, 0.02]])]);
    _S[$ "O"] = fsp__sk(0.74, [fsp__st([[0.50, 0.01], [0.80, 0.13], [0.93, 0.50], [0.80, 0.87], [0.50, 0.99], [0.20, 0.87], [0.07, 0.50], [0.20, 0.13]], 1, 1)]);
    _S[$ "P"] = fsp__sk(0.58, [fsp__st([[0.10, 0.02], [0.10, 0.98]]), fsp__st([[0.10, 0.03], [0.60, 0.06], [0.80, 0.28], [0.60, 0.51], [0.10, 0.54]], 1)]);
    _S[$ "Q"] = fsp__sk(0.74, [fsp__st([[0.50, 0.01], [0.80, 0.13], [0.93, 0.50], [0.80, 0.87], [0.50, 0.99], [0.20, 0.87], [0.07, 0.50], [0.20, 0.13]], 1, 1), fsp__st([[0.55, 0.72], [0.74, 0.92], [0.98, 1.12]], 1)]);
    _S[$ "R"] = fsp__sk(0.62, [fsp__st([[0.10, 0.02], [0.10, 0.98]]), fsp__st([[0.10, 0.03], [0.58, 0.06], [0.76, 0.27], [0.58, 0.50], [0.10, 0.53]], 1), fsp__st([[0.40, 0.53], [0.95, 0.98]])]);
    _S[$ "S"] = fsp__sk(0.56, [fsp__st([[0.88, 0.20], [0.70, 0.04], [0.36, 0.03], [0.16, 0.20], [0.28, 0.42], [0.62, 0.55], [0.82, 0.74], [0.70, 0.94], [0.34, 0.99], [0.12, 0.82]], 1)]);
    _S[$ "T"] = fsp__sk(0.62, [fsp__st([[0.03, 0.03], [0.97, 0.03]]), fsp__st([[0.50, 0.03], [0.50, 0.98]])]);
    _S[$ "U"] = fsp__sk(0.72, [fsp__st([[0.09, 0.02], [0.09, 0.66], [0.24, 0.93], [0.50, 0.99], [0.76, 0.93], [0.91, 0.66], [0.91, 0.02]], 1)]);
    _S[$ "V"] = fsp__sk(0.70, [fsp__st([[0.03, 0.02], [0.50, 0.98], [0.97, 0.02]])]);
    _S[$ "W"] = fsp__sk(0.98, [fsp__st([[0.02, 0.02], [0.25, 0.98], [0.50, 0.26], [0.75, 0.98], [0.98, 0.02]])]);
    _S[$ "X"] = fsp__sk(0.68, [fsp__st([[0.04, 0.02], [0.96, 0.98]]), fsp__st([[0.96, 0.02], [0.04, 0.98]])]);
    _S[$ "Y"] = fsp__sk(0.66, [fsp__st([[0.03, 0.02], [0.50, 0.50]]), fsp__st([[0.97, 0.02], [0.50, 0.50]]), fsp__st([[0.50, 0.50], [0.50, 0.98]])]);
    _S[$ "Z"] = fsp__sk(0.62, [fsp__st([[0.07, 0.03], [0.92, 0.03]]), fsp__st([[0.92, 0.03], [0.08, 0.97]]), fsp__st([[0.08, 0.97], [0.93, 0.97]])]);
    _S[$ "0"] = fsp__sk(0.62, [fsp__st([[0.50, 0.01], [0.80, 0.14], [0.92, 0.50], [0.80, 0.86], [0.50, 0.99], [0.20, 0.86], [0.08, 0.50], [0.20, 0.14]], 1, 1)]);
    _S[$ "1"] = fsp__sk(0.40, [fsp__st([[0.16, 0.20], [0.52, 0.02], [0.52, 0.97]]), fsp__st([[0.18, 0.97], [0.86, 0.97]])]);
    _S[$ "2"] = fsp__sk(0.58, [fsp__st([[0.10, 0.22], [0.28, 0.04], [0.62, 0.02], [0.84, 0.22], [0.70, 0.50], [0.12, 0.96], [0.90, 0.96]], 1)]);
    _S[$ "3"] = fsp__sk(0.58, [fsp__st([[0.10, 0.14], [0.36, 0.02], [0.72, 0.07], [0.78, 0.28], [0.46, 0.46], [0.80, 0.62], [0.74, 0.90], [0.38, 0.99], [0.10, 0.86]], 1)]);
    _S[$ "4"] = fsp__sk(0.62, [fsp__st([[0.72, 0.02], [0.06, 0.70], [0.94, 0.70]]), fsp__st([[0.72, 0.28], [0.72, 0.98]])]);
    _S[$ "5"] = fsp__sk(0.58, [fsp__st([[0.86, 0.03], [0.22, 0.03], [0.16, 0.42], [0.46, 0.34], [0.80, 0.48], [0.84, 0.76], [0.56, 0.98], [0.14, 0.90]], 1)]);
    _S[$ "6"] = fsp__sk(0.60, [fsp__st([[0.84, 0.06], [0.50, 0.01], [0.18, 0.26], [0.10, 0.64], [0.28, 0.94], [0.60, 0.98], [0.86, 0.78], [0.74, 0.54], [0.36, 0.50], [0.14, 0.66]], 1)]);
    _S[$ "7"] = fsp__sk(0.56, [fsp__st([[0.06, 0.03], [0.92, 0.03], [0.40, 0.98]])]);
    // TWO loops, not one self-crossing path: a figure-eight as one closed skeleton crosses its own offset rings at the
    // waist and renders as a filled blob in every hand.
    _S[$ "8"] = fsp__sk(0.60, [fsp__st([[0.50, 0.02], [0.76, 0.13], [0.74, 0.35], [0.50, 0.48], [0.26, 0.35], [0.24, 0.13]], 1, 1),
        fsp__st([[0.50, 0.48], [0.80, 0.62], [0.82, 0.86], [0.50, 0.98], [0.18, 0.86], [0.20, 0.62]], 1, 1)]);
    _S[$ "9"] = fsp__sk(0.60, [fsp__st([[0.16, 0.94], [0.50, 0.99], [0.82, 0.74], [0.90, 0.36], [0.72, 0.06], [0.40, 0.02], [0.14, 0.22], [0.26, 0.46], [0.64, 0.50], [0.86, 0.34]], 1)]);
    _S[$ " "] = fsp__sk(0.30, []);
    // A point is the pen SET DOWN once; authored as a tiny loop it became a doughnut.
    _S[$ "."] = fsp__sk(0.28, [fsp__st([[0.50, 0.94], [0.50, 0.95]], 0, 0, 1)]);
    _S[$ ","] = fsp__sk(0.28, [fsp__st([[0.58, 0.86], [0.50, 0.99], [0.34, 1.13]], 1)]);
    _S[$ ":"] = fsp__sk(0.28, [fsp__st([[0.50, 0.40], [0.50, 0.41]], 0, 0, 1), fsp__st([[0.50, 0.94], [0.50, 0.95]], 0, 0, 1)]);
    _S[$ "-"] = fsp__sk(0.46, [fsp__st([[0.10, 0.52], [0.90, 0.52]])]);
    _S[$ "!"] = fsp__sk(0.30, [fsp__st([[0.50, 0.02], [0.50, 0.64]]), fsp__st([[0.50, 0.94], [0.50, 0.95]], 0, 0, 1)]);
    _S[$ "?"] = fsp__sk(0.56, [fsp__st([[0.10, 0.22], [0.28, 0.03], [0.66, 0.04], [0.86, 0.24], [0.70, 0.46], [0.50, 0.56], [0.50, 0.66]], 1), fsp__st([[0.50, 0.94], [0.50, 0.95]], 0, 0, 1)]);
    _S[$ "'"] = fsp__sk(0.22, [fsp__st([[0.50, 0.02], [0.44, 0.24]])]);
    _S[$ "\""] = fsp__sk(0.38, [fsp__st([[0.34, 0.02], [0.28, 0.24]]), fsp__st([[0.70, 0.02], [0.64, 0.24]])]);
    // An et-ligature drawn as a scribe draws one: an S-curve up from the foot into a small closed bowl.
    _S[$ "&"] = fsp__sk(0.76, [fsp__st([[0.94, 0.96], [0.52, 0.56], [0.26, 0.32], [0.30, 0.10], [0.54, 0.04], [0.70, 0.18], [0.58, 0.40], [0.20, 0.68], [0.24, 0.92], [0.52, 0.98], [0.80, 0.80]], 1)]);
    _S[$ "("] = fsp__sk(0.34, [fsp__st([[0.74, 0.00], [0.34, 0.30], [0.34, 0.72], [0.74, 1.02]], 1)]);
    _S[$ ")"] = fsp__sk(0.34, [fsp__st([[0.26, 0.00], [0.66, 0.30], [0.66, 0.72], [0.26, 1.02]], 1)]);
    _S[$ "/"] = fsp__sk(0.50, [fsp__st([[0.06, 1.02], [0.94, 0.00]])]);
    return _S;
}

/// @function fsp_alpha_uncial()
/// @description Uncial overrides: the rounded forms that are UNAMBIGUOUS. The authentic uncial A, D and H were
/// authored, rendered, and read as "d", a reversed "c" and an "h" - a wordmark whose first letter reads as the wrong
/// letter is not a wordmark, so they were cut. A, L and R carry curved sides instead. Pure.
function fsp_alpha_uncial() {
    static _S = undefined;
    if (!is_undefined(_S)) return _S;
    _S = {};
    _S[$ "A"] = fsp__sk(0.76, [fsp__st([[0.05, 0.98], [0.16, 0.52], [0.42, 0.05]], 1), fsp__st([[0.42, 0.05], [0.72, 0.52], [0.95, 0.98]], 1), fsp__st([[0.20, 0.70], [0.84, 0.70]])]);
    _S[$ "L"] = fsp__sk(0.62, [fsp__st([[0.14, 0.02], [0.14, 0.70], [0.30, 0.92], [0.58, 0.98], [0.86, 0.86]], 1)]);
    _S[$ "R"] = fsp__sk(0.68, [fsp__st([[0.12, 0.02], [0.12, 0.98]]), fsp__st([[0.12, 0.04], [0.56, 0.06], [0.80, 0.28], [0.56, 0.50], [0.12, 0.53]], 1), fsp__st([[0.40, 0.53], [0.64, 0.72], [0.96, 0.94]], 1)]);
    _S[$ "E"] = fsp__sk(0.62, [fsp__st([[0.88, 0.22], [0.66, 0.03], [0.30, 0.06], [0.12, 0.32], [0.14, 0.62], [0.34, 0.94], [0.70, 0.98], [0.90, 0.82]], 1), fsp__st([[0.18, 0.48], [0.68, 0.48]])]);
    _S[$ "G"] = fsp__sk(0.66, [fsp__st([[0.86, 0.20], [0.62, 0.02], [0.28, 0.10], [0.12, 0.40], [0.28, 0.72], [0.62, 0.78], [0.82, 0.62]], 1), fsp__st([[0.82, 0.62], [0.78, 1.02], [0.46, 1.18], [0.16, 1.06]], 1)]);
    _S[$ "M"] = fsp__sk(0.94, [fsp__st([[0.06, 0.98], [0.06, 0.34], [0.24, 0.12], [0.46, 0.30], [0.46, 0.98]], 1), fsp__st([[0.46, 0.34], [0.66, 0.12], [0.90, 0.30], [0.94, 0.98]], 1)]);
    _S[$ "N"] = fsp__sk(0.76, [fsp__st([[0.10, 0.98], [0.10, 0.30], [0.36, 0.12], [0.72, 0.24], [0.86, 0.52], [0.86, 0.98]], 1)]);
    _S[$ "Q"] = fsp__sk(0.74, [fsp__st([[0.50, 0.01], [0.80, 0.13], [0.93, 0.50], [0.80, 0.87], [0.50, 0.99], [0.20, 0.87], [0.07, 0.50], [0.20, 0.13]], 1, 1), fsp__st([[0.36, 0.88], [0.30, 1.06], [0.36, 1.20]], 1)]);
    _S[$ "T"] = fsp__sk(0.62, [fsp__st([[0.06, 0.16], [0.34, 0.02], [0.66, 0.02], [0.94, 0.16]], 1), fsp__st([[0.44, 0.06], [0.44, 0.98]])]);
    _S[$ "U"] = fsp__sk(0.76, [fsp__st([[0.10, 0.02], [0.10, 0.62], [0.30, 0.94], [0.62, 0.96], [0.88, 0.74], [0.88, 0.02]], 1), fsp__st([[0.88, 0.02], [0.88, 0.98]])]);
    return _S;
}

/// @function fsp_alpha_textura()
/// @description Textura overrides: the blackletter letters that are not simply the base faceted. NO W override: one was
/// authored and read as a zigzag; the base W is already faceted in this hand because textura does not smooth. Pure.
function fsp_alpha_textura() {
    static _S = undefined;
    if (!is_undefined(_S)) return _S;
    _S = {};
    _S[$ "A"] = fsp__sk(0.66, [fsp__st([[0.12, 0.98], [0.12, 0.32], [0.46, 0.18], [0.86, 0.32], [0.86, 0.98]]), fsp__st([[0.86, 0.60], [0.12, 0.60]]), fsp__st([[0.12, 0.32], [0.46, 0.02], [0.86, 0.32]])]);
    _S[$ "C"] = fsp__sk(0.62, [fsp__st([[0.90, 0.16], [0.56, 0.02], [0.20, 0.14], [0.12, 0.50], [0.20, 0.86], [0.56, 0.98], [0.90, 0.84]])]);
    _S[$ "E"] = fsp__sk(0.62, [fsp__st([[0.90, 0.16], [0.56, 0.02], [0.20, 0.14], [0.12, 0.50], [0.20, 0.86], [0.56, 0.98], [0.90, 0.84]]), fsp__st([[0.20, 0.50], [0.72, 0.50]])]);
    _S[$ "G"] = fsp__sk(0.66, [fsp__st([[0.90, 0.16], [0.56, 0.02], [0.20, 0.14], [0.12, 0.50], [0.20, 0.86], [0.58, 0.98], [0.88, 0.84], [0.88, 0.58], [0.56, 0.58]])]);
    _S[$ "O"] = fsp__sk(0.68, [fsp__st([[0.50, 0.02], [0.90, 0.32], [0.90, 0.68], [0.50, 0.98], [0.10, 0.68], [0.10, 0.32]], 0, 1)]);
    _S[$ "S"] = fsp__sk(0.58, [fsp__st([[0.88, 0.18], [0.60, 0.02], [0.22, 0.10], [0.18, 0.34], [0.56, 0.50], [0.86, 0.64], [0.82, 0.88], [0.44, 0.98], [0.12, 0.86]])]);
    _S[$ "U"] = fsp__sk(0.72, [fsp__st([[0.10, 0.02], [0.10, 0.74], [0.34, 0.98], [0.66, 0.98], [0.90, 0.74], [0.90, 0.02]]), fsp__st([[0.90, 0.30], [0.90, 0.98]])]);
    return _S;
}

/// @function fsp_alpha_stave()
/// @description Stave overrides: carved with a chisel, so nothing curves - every round letter re-authored as straight
/// facets. The hand that proves the five are BUILT differently rather than tinted differently. Pure.
function fsp_alpha_stave() {
    static _S = undefined;
    if (!is_undefined(_S)) return _S;
    _S = {};
    _S[$ "B"] = fsp__sk(0.58, [fsp__st([[0.12, 0.02], [0.12, 0.98]]), fsp__st([[0.12, 0.03], [0.76, 0.26], [0.12, 0.50]]), fsp__st([[0.12, 0.50], [0.86, 0.74], [0.12, 0.97]])]);
    _S[$ "C"] = fsp__sk(0.62, [fsp__st([[0.90, 0.04], [0.16, 0.04], [0.16, 0.96], [0.90, 0.96]])]);
    _S[$ "D"] = fsp__sk(0.66, [fsp__st([[0.12, 0.02], [0.12, 0.98]]), fsp__st([[0.12, 0.02], [0.88, 0.50], [0.12, 0.98]])]);
    _S[$ "G"] = fsp__sk(0.68, [fsp__st([[0.90, 0.04], [0.16, 0.04], [0.16, 0.96], [0.90, 0.96], [0.90, 0.54]]), fsp__st([[0.58, 0.54], [0.92, 0.54]])]);
    _S[$ "J"] = fsp__sk(0.46, [fsp__st([[0.76, 0.02], [0.76, 0.80], [0.42, 1.00], [0.08, 0.84]])]);
    _S[$ "O"] = fsp__sk(0.70, [fsp__st([[0.50, 0.01], [0.95, 0.50], [0.50, 0.99], [0.05, 0.50]], 0, 1)]);
    _S[$ "P"] = fsp__sk(0.56, [fsp__st([[0.12, 0.02], [0.12, 0.98]]), fsp__st([[0.12, 0.03], [0.84, 0.28], [0.12, 0.54]])]);
    _S[$ "Q"] = fsp__sk(0.70, [fsp__st([[0.50, 0.01], [0.95, 0.50], [0.50, 0.99], [0.05, 0.50]], 0, 1), fsp__st([[0.58, 0.72], [0.98, 1.12]])]);
    _S[$ "R"] = fsp__sk(0.60, [fsp__st([[0.12, 0.02], [0.12, 0.98]]), fsp__st([[0.12, 0.03], [0.82, 0.27], [0.12, 0.52]]), fsp__st([[0.38, 0.52], [0.94, 0.98]])]);
    _S[$ "S"] = fsp__sk(0.56, [fsp__st([[0.90, 0.06], [0.18, 0.06], [0.18, 0.50], [0.84, 0.50], [0.84, 0.94], [0.10, 0.94]])]);
    _S[$ "U"] = fsp__sk(0.70, [fsp__st([[0.10, 0.02], [0.10, 0.72], [0.50, 0.98], [0.90, 0.72], [0.90, 0.02]])]);
    _S[$ "0"] = fsp__sk(0.58, [fsp__st([[0.50, 0.01], [0.94, 0.50], [0.50, 0.99], [0.06, 0.50]], 0, 1)]);
    _S[$ "8"] = fsp__sk(0.58, [fsp__st([[0.50, 0.02], [0.86, 0.24], [0.50, 0.48], [0.14, 0.24]], 0, 1), fsp__st([[0.50, 0.50], [0.90, 0.74], [0.50, 0.98], [0.10, 0.74]], 0, 1)]);
    return _S;
}

/// @function fsp_alpha_hand_ids()
/// @description The five hand ids, in a stable order. Pure.
function fsp_alpha_hand_ids() { static _ids = ["lapidary", "uncial", "textura", "stave", "grotesk"]; return _ids; }

/// @function fsp_alpha_cut_ids()
/// @description The four cut ids, in a stable order. Pure.
function fsp_alpha_cut_ids() { static _ids = ["incised", "raised", "inlaid", "printed"]; return _ids; }

/// @function fsp_alpha_hand(id)
/// @description A hand record, or undefined for an unknown id. A hand is a TOOL plus decisions about holding it:
///   nib      "broad" (a chisel nib at `angle`, thinning as it travels along its own edge) or "mono" (never changes)
///   angle    nib angle in degrees, clockwise from horizontal (y down)
///   thin     the hairline floor as a fraction of full weight, so a hairline still resolves at title size
///   smooth   samples per skeleton span; 0 leaves straight facets - a STRUCTURAL switch, not a style one
///   terminal "wedge" flared serif, "nib" the pen's angled cut, "flat" chisel cut, "round"
function fsp_alpha_hand(_id) {
    static _H = undefined;
    if (is_undefined(_H)) {
        _H = {
            lapidary: { id: "lapidary", label: "Lapidary", note: "Roman inscriptional capital, chisel-cut", nib: "broad", angle: 0, weight: 0.140, thin: 0.36, smooth: 9, terminal: "wedge", flare: 1.88, serif_len: 0.072, width_mul: 1.00, track: 0.120, alt: undefined },
            uncial: { id: "uncial", label: "Uncial", note: "rounded majuscule, broad pen at a shallow angle", nib: "broad", angle: 24, weight: 0.200, thin: 0.32, smooth: 11, terminal: "nib", flare: 1, serif_len: 0, width_mul: 1.20, track: 0.100, alt: fsp_alpha_uncial() },
            textura: { id: "textura", label: "Textura", note: "blackletter, broad pen at forty degrees, no curves", nib: "broad", angle: 40, weight: 0.205, thin: 0.22, smooth: 0, terminal: "nib", flare: 1, serif_len: 0, width_mul: 0.88, track: 0.110, alt: fsp_alpha_textura() },
            stave: { id: "stave", label: "Stave", note: "carved with a chisel, straight cuts only", nib: "mono", angle: 0, weight: 0.112, thin: 1, smooth: 0, terminal: "flat", flare: 1, serif_len: 0, width_mul: 0.90, track: 0.150, alt: fsp_alpha_stave() },
            grotesk: { id: "grotesk", label: "Grotesk", note: "geometric monoline, no serif, wide tracking", nib: "mono", angle: 0, weight: 0.104, thin: 1, smooth: 12, terminal: "round", flare: 1, serif_len: 0, width_mul: 1.02, track: 0.185, alt: undefined }
        };
    }
    if (!is_string(_id)) return undefined;
    return _H[$ _id];
}

/// @function fsp_alpha_volume()
/// @description How many authored skeletons the corpus contains, COUNTED: {base, overrides, total, glyphs}. Pure.
function fsp_alpha_volume() {
    var _base = variable_struct_names_count(fsp_alpha_base()), _over = 0, _ids = fsp_alpha_hand_ids();
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _alt = fsp_alpha_hand(_ids[_i]).alt;
        if (is_struct(_alt)) _over += variable_struct_names_count(_alt);
    }
    return { base: _base, overrides: _over, total: _base + _over, glyphs: _base * array_length(_ids) };
}

/// @function fsp_alpha_skeleton(ch, hand_id)
/// @description The skeleton a hand uses for a character (its override if it has one, else the base), or undefined
/// when the corpus has no such glyph. Pure.
function fsp_alpha_skeleton(_ch, _hand_id) {
    var _h = fsp_alpha_hand(_hand_id);
    if (!is_struct(_h) || !is_string(_ch)) return undefined;
    if (is_struct(_h.alt) && variable_struct_exists(_h.alt, _ch)) return _h.alt[$ _ch];
    var _b = fsp_alpha_base();
    return variable_struct_exists(_b, _ch) ? _b[$ _ch] : undefined;
}

/// @function fsp_alpha_coverage(text, hand_id)
/// @description The fraction of a string this corpus can cut: {covered, total, ratio, missing}. Pure.
function fsp_alpha_coverage(_text, _hand_id) {
    var _s = string_upper(string(_text)), _n = string_length(_s), _cov = 0, _miss = [];
    for (var _i = 1; _i <= _n; _i++) {
        var _c = string_char_at(_s, _i);
        if (!is_undefined(fsp_alpha_skeleton(_c, _hand_id))) _cov++;
        else if (array_get_index(_miss, _c) < 0) array_push(_miss, _c);
    }
    return { covered: _cov, total: _n, ratio: (_n > 0) ? _cov / _n : 1, missing: _miss };
}

/// @function fsp_alpha_half_width(tx, ty, hand, full)
/// @description Half-width of the stroke perpendicular to travel. A broad nib sweeps its full width travelling ACROSS
/// its own edge and collapses travelling ALONG it - the single line that makes a nib at 0 degrees give Roman capitals
/// and a nib at 40 give blackletter. `thin` is an absolute floor so a hairline still resolves. Pure.
function fsp_alpha_half_width(_tx, _ty, _h, _full) {
    if (_h.nib == "mono") return _full;
    var _a = degtorad(_h.angle);
    var _s = abs(_tx * sin(_a) - _ty * cos(_a));
    return _full * (_h.thin + (1 - _h.thin) * _s);
}

/// @function fsp__tangent(pts, i, closed)
/// @description Unit tangent at sample i, averaged across the joint so a corner does not spike. Internal, pure.
function fsp__tangent(_p, _i, _closed) {
    var _n = array_length(_p);
    var _a = _closed ? _p[(_i - 1 + _n) mod _n] : _p[max(0, _i - 1)];
    var _b = _closed ? _p[(_i + 1) mod _n] : _p[min(_n - 1, _i + 1)];
    var _dx = _b[0] - _a[0], _dy = _b[1] - _a[1], _m = sqrt(_dx * _dx + _dy * _dy);
    if (_m < 0.0001) return [1, 0];
    return [_dx / _m, _dy / _m];
}

/// @function fsp__sample(stroke, hand, x, base_y, adv, cap_h)
/// @description One skeleton stroke sampled into px points (smoothed where the hand smooths; densified linearly where
/// the hand cuts a wedge serif, because a two-point stem gives a serif nothing to be shaped on). Internal, pure.
function fsp__sample(_st, _h, _x, _by, _adv, _cap) {
    var _pts = [], _i;
    for (_i = 0; _i < array_length(_st.p); _i++) array_push(_pts, [_x + _st.p[_i][0] * _adv, _by - _cap + _st.p[_i][1] * _cap]);
    if (_st.c && _h.smooth > 0) _pts = fsp_smooth(_pts, _h.smooth, _st.k == 1);
    if (array_length(_pts) == 1) array_push(_pts, [_pts[0][0] + 0.01, _pts[0][1]]);
    if (_h.terminal == "wedge" && _h.serif_len > 0 && _cap > 0) {
        var _max_seg = max(1.5, _h.serif_len * _cap * 0.30), _dense = [_pts[0]];
        for (_i = 1; _i < array_length(_pts); _i++) {
            var _a = _pts[_i - 1], _b = _pts[_i];
            var _d = point_distance(_a[0], _a[1], _b[0], _b[1]);
            var _k = max(1, ceil(_d / _max_seg));
            for (var _j = 1; _j <= _k; _j++) array_push(_dense, [_a[0] + (_b[0] - _a[0]) * _j / _k, _a[1] + (_b[1] - _a[1]) * _j / _k]);
        }
        _pts = _dense;
    }
    return _pts;
}

/// @function fsp__is_junction(p, others, near)
/// @description True when another stroke of the same glyph passes within `near` px of an end point. A SERIF IS CUT
/// WHERE A STROKE ENDS FREE; flaring a junction turned every A, M, T and E into a blob. Derived from the geometry
/// rather than flagged per skeleton, so it cannot go stale. Internal, pure.
function fsp__is_junction(_p, _others, _near) {
    var _n2 = _near * _near;
    for (var _s = 0; _s < array_length(_others); _s++) {
        var _pts = _others[_s];
        for (var _i = 0; _i < array_length(_pts); _i++) {
            var _dx = _pts[_i][0] - _p[0], _dy = _pts[_i][1] - _p[1];
            if (_dx * _dx + _dy * _dy < _n2) return true;
        }
    }
    return false;
}

/// @function fsp__meets_end(p, others, near)
/// @description True when an end point p lies within `near` px of another stroke's own END - a CORNER, like the apex
/// where the two legs of an A meet. A corner keeps the nib's cut; an end that lands in the MIDDLE of another stroke
/// (an E's bar in its bowl, a K's arm on its stem) is left square, because a square end cutting the apex left a notch
/// in the A. Internal, pure.
function fsp__meets_end(_p, _others, _near) {
    var _n2 = _near * _near;
    for (var _s = 0; _s < array_length(_others); _s++) {
        var _pts = _others[_s], _m = array_length(_pts);
        if (_m == 0) continue;
        var _a = _pts[0], _b = _pts[_m - 1];
        if ((_a[0] - _p[0]) * (_a[0] - _p[0]) + (_a[1] - _p[1]) * (_a[1] - _p[1]) < _n2) return true;
        if ((_b[0] - _p[0]) * (_b[0] - _p[0]) + (_b[1] - _p[1]) * (_b[1] - _p[1]) < _n2) return true;
    }
    return false;
}

/// @function fsp__cut_dir(t, u)
/// @description The direction a broad nib cuts a stroke end travelling along unit tangent t: the nib's own edge u,
/// steepened just enough that it crosses the stroke at |sin| >= 0.35. A pen travelling almost along its own edge would
/// otherwise cut a wedge many widths long - the whiskers on the textura R, Q and S. Internal, pure.
function fsp__cut_dir(_t, _u) {
    var _nx = -_t[1], _ny = _t[0];
    var _d = _nx * _u[0] + _ny * _u[1];
    if (abs(_d) >= 0.35) return _u;
    var _sg = (_d < 0) ? -1 : 1, _c = ((_t[0] * _u[0] + _t[1] * _u[1]) < 0 ? -1 : 1) * sqrt(1 - 0.35 * 0.35);
    return [_t[0] * _c + _nx * _sg * 0.35, _t[1] * _c + _ny * _sg * 0.35];
}

/// @function fsp__trim_start(side, p, t, v, hw)
/// @description One side of a stroke outline (px points, starting at the end being cut), cut by the line through the
/// stroke's end point p along v, where t points INTO the stroke and the side starts hw from p. Where the cut meets the
/// side ahead of its first point, the side is TRIMMED there; where it meets the side's own line behind it, the side is
/// EXTENDED to it. ⛔ The cut used to be two corners appended to the ring - a bowtie, exact on a straight stroke and
/// wrong on a curved one: the corner sits on the TANGENT line, not on the curving edge, so part of the removed lobe
/// fell outside the stroke (a spur) and part of the stroke cancelled to winding 0 (a dark sliver through which the
/// inlay's bed showed - found at 1x on the hero's uncial E, 2026-09-27). A trimmed side never crosses itself. Internal, pure.
function fsp__trim_start(_s, _p, _t, _v, _hw) {
    var _n = array_length(_s);
    if (_n < 2 || !(_hw > 0)) return _s;
    var _sig = ((_v[0] * _t[1] - _v[1] * _t[0]) < 0) ? -1 : 1;
    var _a = _sig * (_v[0] * (_s[0][1] - _p[1]) - _v[1] * (_s[0][0] - _p[0]));
    var _out = [], _i;
    if (_a >= 0) {
        var _vm = (_v[0] * (_s[0][0] - _p[0]) + _v[1] * (_s[0][1] - _p[1])) / _hw;
        if (abs(_vm) < 0.0001) return _s;
        var _k = _hw / _vm;
        array_push(_out, [_p[0] + _v[0] * _k, _p[1] + _v[1] * _k]);
        for (_i = 0; _i < _n; _i++) array_push(_out, _s[_i]);
        return _out;
    }
    var _lim = max(2, ceil(_n / 2));
    for (_i = 1; _i < _lim; _i++) {
        var _b = _sig * (_v[0] * (_s[_i][1] - _p[1]) - _v[1] * (_s[_i][0] - _p[0]));
        if (_b > 0) {
            var _f = _a / (_a - _b);
            array_push(_out, [_s[_i - 1][0] + (_s[_i][0] - _s[_i - 1][0]) * _f, _s[_i - 1][1] + (_s[_i][1] - _s[_i - 1][1]) * _f]);
            for (var _j = _i; _j < _n; _j++) array_push(_out, _s[_j]);
            return _out;
        }
        _a = _b;
    }
    return _s;
}

/// @function fsp__reversed(arr)
/// @description A reversed copy of an array. Internal, pure.
function fsp__reversed(_a) {
    var _n = array_length(_a), _o = array_create(_n);
    for (var _i = 0; _i < _n; _i++) _o[_i] = _a[_n - 1 - _i];
    return _o;
}

/// @function fsp__stroke_rings(stroke, pts, hand, full, cap_h, others, [split0], [split1])
/// @description One sampled stroke as filled outline rings in px: one ring for an open stroke, [outer, counter] for a
/// closed loop big enough to survive the pen. Serifs are cut in ABSOLUTE units (against the cap height, never the
/// stroke length) and only at free ends; the flare is ADDITIVE against the full weight. A broad nib's angled cut is
/// made at a FREE end, at a split corner (split0/split1: that end is where one leg of a split stroke meets the next)
/// and where the end meets another stroke's end (fsp__meets_end), never at an end that lands in the middle of another
/// stroke - the pen never lifted there, and the cut notched the K's junction and pushed the A's crossbar out past its
/// leg. Internal, pure.
function fsp__stroke_rings(_st, _pts, _h, _full, _cap, _others, _split0 = false, _split1 = false) {
    var _closed = (_st.k == 1), _n = array_length(_pts), _left = [], _right = [], _total = [0], _acc = 0, _i, _hws = [];
    for (_i = 1; _i < _n; _i++) { _acc += point_distance(_pts[_i - 1][0], _pts[_i - 1][1], _pts[_i][0], _pts[_i][1]); array_push(_total, _acc); }
    var _len = max(0.0001, _acc);
    var _serif_px = _h.serif_len * _cap;
    var _wedge = !_closed && _h.terminal == "wedge" && _serif_px > 0;
    var _near = _full * 1.7;
    var _open0 = !fsp__is_junction(_pts[0], _others, _near);
    var _open1 = !fsp__is_junction(_pts[_n - 1], _others, _near);
    var _free0 = _wedge && _open0;
    var _free1 = _wedge && _open1;
    for (_i = 0; _i < _n; _i++) {
        var _t = fsp__tangent(_pts, _i, _closed);
        var _hw = fsp_alpha_half_width(_t[0], _t[1], _h, _full);
        if (_wedge && (_free0 || _free1)) {
            var _d0 = _free0 ? _total[_i] : 1000000, _d1 = _free1 ? _len - _total[_i] : 1000000;
            var _ramp = max(0, 1 - min(_d0, _d1) / _serif_px);
            _hw += _full * (_h.flare - 1) * _ramp * _ramp;
        }
        var _nx = -_t[1], _ny = _t[0];
        array_push(_hws, _hw);
        array_push(_left, [_pts[_i][0] + _nx * _hw, _pts[_i][1] + _ny * _hw]);
        array_push(_right, [_pts[_i][0] - _nx * _hw, _pts[_i][1] - _ny * _hw]);
    }
    if (_closed) {
        // Only a loop big enough to survive the pen has a counter; below that the inner ring inverts and even-odd
        // would punch a hole in a solid mark.
        var _oa = fsp_ring_area(_left), _ia = fsp_ring_area(_right);
        var _big = max(_oa, _ia), _small = min(_oa, _ia);
        if (!(_big > 0) || _small / _big < 0.10) return [(_oa >= _ia) ? _left : _right];
        return (_oa >= _ia) ? [_left, _right] : [_right, _left];
    }
    if (_h.terminal == "nib" && _h.nib == "broad") {
        var _u = [cos(degtorad(_h.angle)), sin(degtorad(_h.angle))];
        if (_split0 || _open0 || fsp__meets_end(_pts[0], _others, _near)) {
            var _t0 = fsp__tangent(_pts, 0, false), _v0 = fsp__cut_dir(_t0, _u);
            _left = fsp__trim_start(_left, _pts[0], _t0, _v0, _hws[0]);
            _right = fsp__trim_start(_right, _pts[0], _t0, _v0, _hws[0]);
        }
        if (_split1 || _open1 || fsp__meets_end(_pts[_n - 1], _others, _near)) {
            var _t1 = fsp__tangent(_pts, _n - 1, false), _ti = [-_t1[0], -_t1[1]], _v1 = fsp__cut_dir(_ti, _u);
            _left = fsp__reversed(fsp__trim_start(fsp__reversed(_left), _pts[_n - 1], _ti, _v1, _hws[_n - 1]));
            _right = fsp__reversed(fsp__trim_start(fsp__reversed(_right), _pts[_n - 1], _ti, _v1, _hws[_n - 1]));
        }
    }
    var _ring = [];
    for (_i = 0; _i < array_length(_left); _i++) array_push(_ring, _left[_i]);
    for (_i = array_length(_right) - 1; _i >= 0; _i--) array_push(_ring, _right[_i]);
    return [_ring];
}

/// @function fsp_alpha_glyph(ch, hand_id, x, base_y, cap_h)
/// @description Every ring of one glyph in px, positioned at (x, base_y): {rings, holes, advance}, or undefined when
/// the corpus has no glyph for `ch`. `holes[i]` is true when ring i is the counter of ring i-1. TWO PASSES: every stroke
/// is sampled before any is outlined, because whether an end is a free terminal or a junction is a fact about the
/// WHOLE glyph. Pure.
function fsp_alpha_glyph(_ch, _hand_id, _x, _by, _cap) {
    var _h = fsp_alpha_hand(_hand_id);
    var _sk = fsp_alpha_skeleton(_ch, _hand_id);
    if (!is_struct(_h) || is_undefined(_sk)) return undefined;
    var _adv = _sk.w * _h.width_mul * _cap, _full = _h.weight * _cap * 0.5, _live = [], _joins = [], _i, _j;
    for (_i = 0; _i < array_length(_sk.s); _i++) {
        var _st = _sk.s[_i];
        if (array_length(_st.p) == 0) continue;
        var _legs = fsp__split_corners(_st, _adv, _cap);
        for (_j = 0; _j < array_length(_legs); _j++) {
            if (_j > 0) array_push(_joins, { leg_in: array_length(_live) - 1, leg_out: array_length(_live) });
            array_push(_live, { st: _legs[_j], pts: fsp__sample(_legs[_j], _h, _x, _by, _adv, _cap), split0: _j > 0, split1: _j < array_length(_legs) - 1 });
        }
    }
    var _rings = [], _holes = [];
    for (_i = 0; _i < array_length(_live); _i++) {
        if (_live[_i].st.d) {
            // A point mark is the pen SET DOWN: an eight-sided footprint, the shape a cut nib leaves.
            var _p = _live[_i].pts[0], _dot = [], _r = _full * 1.15;
            for (_j = 0; _j < 8; _j++) { var _a = _j / 8 * 2 * pi + pi / 8; array_push(_dot, [_p[0] + cos(_a) * _r, _p[1] + sin(_a) * _r]); }
            array_push(_rings, _dot); array_push(_holes, false);
            continue;
        }
        var _others = [];
        for (_j = 0; _j < array_length(_live); _j++) if (_j != _i) array_push(_others, _live[_j].pts);
        var _out = fsp__stroke_rings(_live[_i].st, _live[_i].pts, _h, _full, _cap, _others, _live[_i].split0, _live[_i].split1);
        array_push(_rings, _out[0]); array_push(_holes, false);
        if (array_length(_out) > 1) { array_push(_rings, _out[1]); array_push(_holes, true); }
    }
    // the corner where two legs of one split stroke meet (a broad nib's own caps already make that corner)
    if (_h.terminal != "nib") for (_i = 0; _i < array_length(_joins); _i++) {
        var _jr = fsp__join_ring(_live[_joins[_i].leg_in].pts, _live[_joins[_i].leg_out].pts, _h, _full);
        if (is_array(_jr)) { array_push(_rings, _jr); array_push(_holes, false); }
    }
    return { rings: _rings, holes: _holes, advance: _adv, joins: array_length(_joins) };
}

/// @function fsp__split_corners(stroke, adv, cap)
/// @description An OPEN, uncurved skeleton stroke cut into one stroke per leg at every turn sharper than 40 degrees
/// (measured in PIXEL space, where the advance and the cap height differ). Anything else is returned whole.
/// ⛔ WHY: a pen outline takes each point's tangent averaged across the joint, so at a sharp corner the width is taken
/// along the wrong direction and every leg between two corners is pinched - a W, M, N or V drawn as one zig-zag came
/// out as HAIRLINES in textura, stave and grotesk (a steep leg at ~0.34 of its weight) while its neighbours stood at
/// full weight. A real pen lifts at a sharp corner, which is how the A was always authored. Internal, pure.
function fsp__split_corners(_st, _adv, _cap) {
    var _p = _st.p, _n = array_length(_p);
    if (_n < 3 || _st.c || _st.k || _st.d) return [_st];
    var _out = [], _cur = [_p[0]];
    for (var _i = 1; _i < _n; _i++) {
        array_push(_cur, _p[_i]);
        if (_i < _n - 1) {
            var _ax = (_p[_i][0] - _p[_i - 1][0]) * _adv, _ay = (_p[_i][1] - _p[_i - 1][1]) * _cap;
            var _bx = (_p[_i + 1][0] - _p[_i][0]) * _adv, _by = (_p[_i + 1][1] - _p[_i][1]) * _cap;
            var _la = sqrt(_ax * _ax + _ay * _ay), _lb = sqrt(_bx * _bx + _by * _by);
            if (_la > 0.0001 && _lb > 0.0001 && (_ax * _bx + _ay * _by) / (_la * _lb) < 0.766) {   // cos 40 degrees
                array_push(_out, fsp__st(_cur, 0, 0, 0));
                _cur = [_p[_i]];
            }
        }
    }
    array_push(_out, fsp__st(_cur, 0, 0, 0));
    return _out;
}

/// @function fsp__hull(points)
/// @description The convex hull of [x, y] points, counter-clockwise (monotone chain). Internal, pure.
function fsp__hull(_pts) {
    var _p = [];
    for (var _i = 0; _i < array_length(_pts); _i++) array_push(_p, _pts[_i]);
    array_sort(_p, function(_a, _b) { return (_a[0] < _b[0]) ? -1 : ((_a[0] > _b[0]) ? 1 : ((_a[1] < _b[1]) ? -1 : ((_a[1] > _b[1]) ? 1 : 0))); });
    var _n = array_length(_p);
    if (_n < 3) return _p;
    var _lo = [], _up = [];
    for (var _j = 0; _j < _n; _j++) {
        while (array_length(_lo) >= 2 && fsp__cross(_lo[array_length(_lo) - 2], _lo[array_length(_lo) - 1], _p[_j]) <= 0) array_pop(_lo);
        array_push(_lo, _p[_j]);
    }
    for (var _k = _n - 1; _k >= 0; _k--) {
        while (array_length(_up) >= 2 && fsp__cross(_up[array_length(_up) - 2], _up[array_length(_up) - 1], _p[_k]) <= 0) array_pop(_up);
        array_push(_up, _p[_k]);
    }
    array_pop(_lo); array_pop(_up);
    for (var _m = 0; _m < array_length(_up); _m++) array_push(_lo, _up[_m]);
    return _lo;
}

/// @function fsp__cross(o, a, b)
/// @description z of (a - o) x (b - o). Internal, pure.
function fsp__cross(_o, _a, _b) { return (_a[0] - _o[0]) * (_b[1] - _o[1]) - (_a[1] - _o[1]) * (_b[0] - _o[0]); }

/// @function fsp__join_ring(leg_in, leg_out, hand, full)
/// @description The piece that fills the outside of a corner where leg_in (sampled px points ending at the corner) meets
/// leg_out (starting there). A round pen leaves a disc; a chisel or a wedge hand leaves the hull of both legs' end
/// corners and a MITER tip, limited to 1.0 x the wider half-width (past that it is cut off square, as a chisel would).
/// ⛔ At 2.5 the tip of a lapidary N rose ~16% of the cap height above the cap line (found at 6x on the cuts sheet).
/// Returns a ring, or undefined when either leg is degenerate. Internal, pure.
function fsp__join_ring(_in, _out, _h, _full) {
    var _ni = array_length(_in), _no = array_length(_out);
    if (_ni < 2 || _no < 2) return undefined;
    var _P = _in[_ni - 1];
    if (_h.terminal == "round") return fsp_ellipse_ring(_P[0], _P[1], _full, _full, 0, 16);
    var _dx1 = _P[0] - _in[_ni - 2][0], _dy1 = _P[1] - _in[_ni - 2][1], _m1 = sqrt(_dx1 * _dx1 + _dy1 * _dy1);
    var _dx2 = _P[0] - _out[1][0], _dy2 = _P[1] - _out[1][1], _m2 = sqrt(_dx2 * _dx2 + _dy2 * _dy2);
    if (_m1 < 0.0001 || _m2 < 0.0001) return undefined;
    _dx1 /= _m1; _dy1 /= _m1; _dx2 /= _m2; _dy2 /= _m2;     // both point INTO the corner
    var _h1 = fsp_alpha_half_width(_dx1, _dy1, _h, _full), _h2 = fsp_alpha_half_width(_dx2, _dy2, _h, _full);
    var _pts = [_P, [_P[0] - _dy1 * _h1, _P[1] + _dx1 * _h1], [_P[0] + _dy1 * _h1, _P[1] - _dx1 * _h1],
                    [_P[0] - _dy2 * _h2, _P[1] + _dx2 * _h2], [_P[0] + _dy2 * _h2, _P[1] - _dx2 * _h2]];
    var _bx = _dx1 + _dx2, _bym = _dy1 + _dy2, _bm = sqrt(_bx * _bx + _bym * _bym);
    if (_bm > 0.0001) {
        var _sinh = max(0.05, sqrt(max(0, (1 - (_dx1 * _dx2 + _dy1 * _dy2)) * 0.5)));
        var _hw = max(_h1, _h2), _len = min(_hw / _sinh, 1.0 * _hw);
        array_push(_pts, [_P[0] + _bx / _bm * _len, _P[1] + _bym / _bm * _len]);
    }
    return fsp__hull(_pts);
}

/// @function fsp_alpha_measure(text, hand_id, cap_h)
/// @description Advance width of a string in px, including tracking; characters the corpus lacks take no space. Pure.
function fsp_alpha_measure(_text, _hand_id, _cap) {
    var _h = fsp_alpha_hand(_hand_id);
    if (!is_struct(_h) || !is_numeric(_cap) || is_nan(_cap)) return 0;
    var _s = string_upper(string(_text)), _w = 0, _drawn = 0;
    for (var _i = 1; _i <= string_length(_s); _i++) {
        var _sk = fsp_alpha_skeleton(string_char_at(_s, _i), _hand_id);
        if (is_undefined(_sk)) continue;
        _w += _sk.w * _h.width_mul * _cap;
        _drawn++;
    }
    if (_drawn > 1) _w += (_drawn - 1) * _h.track * _cap;
    return _w;
}

/// @function fsp_alpha_fit(text, hand_id, max_w, max_cap, min_cap)
/// @description Choose a cap height that fits a line into `max_w`: {cap_h, width, fits}. ⛔ A fitter that can fail to
/// fit SAYS so, and every caller reads `fits`. Pure.
function fsp_alpha_fit(_text, _hand_id, _max_w, _max_cap, _min_cap) {
    if (!is_numeric(_max_w) || !is_numeric(_max_cap) || !is_numeric(_min_cap) || is_nan(_max_w) || is_nan(_max_cap) || is_nan(_min_cap)) return { cap_h: 0, width: 0, fits: false };
    var _lo = max(4, _min_cap), _cap = max(_lo, _max_cap);
    var _at1 = fsp_alpha_measure(_text, _hand_id, 1);
    if (_at1 <= 0) return { cap_h: _cap, width: 0, fits: true };
    _cap = min(_cap, _max_w / _at1);
    return { cap_h: _cap, width: _at1 * _cap, fits: _cap >= _lo };
}

/// @function fsp_alpha_relief_offset(cap_h, hand_id)
/// @description How far the relief flanks sit from the face, px - derived from the THINNEST mark the hand can make,
/// not from the cap height (a thick-stemmed hand read as solid ink and a thin one as edge lighting when it was). Pure.
function fsp_alpha_relief_offset(_cap, _hand_id) {
    var _h = fsp_alpha_hand(_hand_id);
    if (!is_struct(_h)) return 1;
    var _thin_half = _h.weight * _cap * 0.5 * _h.thin;
    return max(1, min(_cap * 0.032, _thin_half * 0.9));
}

/// @function fsp__fill_glyph(g, dx, dy, colour, [grad])
/// @description Fill one glyph's rings, offset, one stroke at a time: the stroke's outline by WINDING, minus its counter
/// (FSP_FILL_STROKE). ⛔ Two separate strokes that overlap must never share one call, and a stroke must never be filled
/// EVEN-ODD: its outline folds wherever the pen turns sharply, and even-odd turned every fold into a light triangle at
/// the joins of M, N, V, W and & (found at 8x on the baked alphabet; 9,933 empty pixels at a 160 px cap). Internal.
function fsp__fill_glyph(_g, _dx, _dy, _col, _grad = undefined) {
    var _n = array_length(_g.rings);
    for (var _i = 0; _i < _n; _i++) {
        if (_g.holes[_i]) continue;
        var _set = [fsp_shift(_g.rings[_i], _dx, _dy)];
        if (_i + 1 < _n && _g.holes[_i + 1]) array_push(_set, fsp_shift(_g.rings[_i + 1], _dx, _dy));
        fsp_fill_rings(_set, _col, 1, _grad, FSP_FILL_STROKE);
    }
}

/// @function fsp__paint_glyph(g, cut, shadow, lit, floor_col, ink, off)
/// @description Paint one glyph in a cut, with ONE light from the upper left. Colours are [r, g, b]. Internal.
///   incised  a V-groove: the UPPER-LEFT flank in shadow - the opposite of a raised letter, and the whole difference
///            between carved-in and cast-on
///   raised   carved proud: the top-left edge catches the light, the bottom-right throws the shadow
///   inlaid   metal in a BED cut all the way round it, its face graded (a flat fill cannot read as metal)
///   printed  flat ink lying on a surface - no bed, no flank; the flatness is the difference from an inlay
function fsp__paint_glyph(_g, _cut, _shadow, _lit, _floor, _ink, _off) {
    switch (_cut) {
        case "raised":
            fsp__fill_glyph(_g, _off, _off, fsp_col(_shadow));
            fsp__fill_glyph(_g, -_off * 0.7, -_off * 0.7, fsp_col(_lit));
            fsp__fill_glyph(_g, 0, 0, fsp_col(fsp_mix(_lit, _floor, 0.45)));
            break;
        case "inlaid":
            for (var _k = 0; _k < 4; _k++) {
                var _a = pi / 4 + _k * pi / 2;
                fsp__fill_glyph(_g, cos(_a) * _off * 0.95, sin(_a) * _off * 0.95, fsp_col(_shadow));
            }
            var _b = fsp_bbox(_g.rings);
            fsp__fill_glyph(_g, 0, 0, c_white, { x0: _b.x0, y0: _b.y0, x1: _b.x0, y1: _b.y1,
                stops: [[0, fsp_col(fsp_relief(_ink, 1, 26)), 1], [0.55, fsp_col(_ink), 1], [1, fsp_col(fsp_relief(_ink, -1, 30)), 1]] });
            break;
        case "printed":
            fsp__fill_glyph(_g, 0, 0, fsp_col(_ink));
            break;
        default:   // incised
            fsp__fill_glyph(_g, -_off * 0.85, -_off * 0.85, fsp_col(_shadow));
            fsp__fill_glyph(_g, _off * 0.7, _off * 0.7, fsp_col(_lit));
            fsp__fill_glyph(_g, 0, 0, fsp_col(_floor));
            break;
    }
}

/// @function fsp_alpha_draw_line(text, opts)
/// @description CUT one line of text into a material. opts: {x, base_y, cap_h, hand, cut, ground: [r,g,b],
/// ink: [r,g,b], delta (luminance separation to solve for, default 46)}. Returns {width, glyphs, missing, boxes},
/// where boxes[i] = [x0, x1] is each cut glyph's advance span in px (what the reveal animation uncovers in order).
/// ⛔ Every cut states its separation ABSOLUTELY and solves for it: there is no ink in a carved inscription, only the
/// shadow the groove casts, and a multiplier would leave letters invisible on a dark ground with every check green.
function fsp_alpha_draw_line(_text, _o) {
    // ⛔ Checked before anything is read: a buyer's typo must be a refusal, never a crash inside their Draw event
    // (MEASURED: undefined, -1, 4096 and a string all threw here on the first adversarial pass).
    var _none = { width: 0, glyphs: 0, missing: [], boxes: [] };
    if (!is_struct(_o)) return _none;
    var _hid = variable_struct_exists(_o, "hand") ? _o.hand : undefined;
    var _h = fsp_alpha_hand(_hid);
    if (!is_struct(_h) || !fsp__num_field(_o, "x") || !fsp__num_field(_o, "base_y") || !fsp__num_field(_o, "cap_h")) return _none;
    var _s = string_upper(string(_text)), _cap = _o.cap_h;
    if (!(_cap > 0) || _cap > 4096) return _none;
    var _ground = fsp__rgb_or(variable_struct_exists(_o, "ground") ? _o.ground : undefined, [128, 128, 128]);
    var _delta = (variable_struct_exists(_o, "delta") && is_numeric(_o.delta)) ? clamp(_o.delta, 0, 255) : 46;
    var _ink = fsp__rgb_or(variable_struct_exists(_o, "ink") ? _o.ink : undefined, fsp_relief(_ground, -1, _delta));
    var _cut = (variable_struct_exists(_o, "cut") && is_string(_o.cut)) ? _o.cut : "incised";
    var _off = fsp_alpha_relief_offset(_cap, _hid);
    var _shadow = fsp_relief(_ground, -1, _delta), _lit = fsp_relief(_ground, 1, round(_delta * 0.72)), _floor = fsp_relief(_ground, -1, round(_delta * 0.42));
    var _x = _o.x, _drawn = 0, _miss = [], _boxes = [];
    for (var _i = 1; _i <= string_length(_s); _i++) {
        var _c = string_char_at(_s, _i);
        var _g = fsp_alpha_glyph(_c, _hid, _x, _o.base_y, _cap);
        if (is_undefined(_g)) { if (array_get_index(_miss, _c) < 0) array_push(_miss, _c); continue; }
        if (array_length(_g.rings) > 0) {
            fsp__paint_glyph(_g, _cut, _shadow, _lit, _floor, _ink, _off);
            array_push(_boxes, [_x, _x + _g.advance]);
        }
        _x += _g.advance + _h.track * _cap;
        _drawn++;
    }
    return { width: (_drawn > 0) ? _x - _o.x - _h.track * _cap : 0, glyphs: array_length(_boxes), missing: _miss, boxes: _boxes };
}

/// @function fsp__num_field(struct, name)
/// @description True when struct.name exists and is a finite number. Internal, pure.
function fsp__num_field(_o, _name) {
    if (!is_struct(_o) || !variable_struct_exists(_o, _name)) return false;
    var _v = _o[$ _name];
    return is_numeric(_v) && !is_nan(_v) && !is_infinity(_v);
}

/// @function fsp__rgb_or(value, fallback)
/// @description `value` when it is an [r, g, b] array of numbers, else `fallback`. Internal, pure.
function fsp__rgb_or(_v, _fb) {
    if (!is_array(_v) || array_length(_v) < 3) return _fb;
    for (var _i = 0; _i < 3; _i++) if (!is_numeric(_v[_i])) return _fb;
    return [clamp(_v[0], 0, 255), clamp(_v[1], 0, 255), clamp(_v[2], 0, 255)];
}

/// @function fsp_alpha_draw_line_font(text, opts)
/// @description The honest fallback for a title the Latin corpus cannot cut: the same cut model and separation, the
/// outline taken from a FONT (opts.font, default the shipped display serif - pass your own font for another script).
/// opts as fsp_alpha_draw_line, with x as the line's CENTRE. Returns {width, glyphs: 0, missing, boxes}.
function fsp_alpha_draw_line_font(_text, _o) {
    var _ground = variable_struct_exists(_o, "ground") ? _o.ground : [128, 128, 128];
    var _delta = variable_struct_exists(_o, "delta") ? _o.delta : 46;
    var _font = variable_struct_exists(_o, "font") ? _o.font : fnt_frontispiece_title;
    var _cap = _o.cap_h, _off = max(1, _cap * 0.030), _px = _cap * 1.45, _track = _cap * 0.10;
    var _shadow = fsp_relief(_ground, -1, _delta), _lit = fsp_relief(_ground, 1, round(_delta * 0.72)), _floor = fsp_relief(_ground, -1, round(_delta * 0.42));
    var _ink = variable_struct_exists(_o, "ink") ? _o.ink : _floor;
    var _w = fsp_tracked_w(_text, _px, _track, _font), _x = _o.x - _w * 0.5, _y = _o.base_y - _px * 0.92;
    var _face = (_o.cut == "inlaid" || _o.cut == "printed") ? _ink : _floor;
    if (_o.cut == "raised") {
        fsp_tracked(_x + _off, _y + _off, _text, _px, _track, fsp_col(_shadow), _font);
        fsp_tracked(_x - _off * 0.7, _y - _off * 0.7, _text, _px, _track, fsp_col(_lit), _font);
        fsp_tracked(_x, _y, _text, _px, _track, fsp_col(fsp_mix(_lit, _floor, 0.45)), _font);
    } else {
        if (_o.cut != "printed") {
            fsp_tracked(_x - _off * 0.85, _y - _off * 0.85, _text, _px, _track, fsp_col(_shadow), _font);
            fsp_tracked(_x + _off * 0.7, _y + _off * 0.7, _text, _px, _track, fsp_col(_lit), _font);
        }
        fsp_tracked(_x, _y, _text, _px, _track, fsp_col(_face), _font);
    }
    var _cov = fsp_alpha_coverage(_text, "lapidary");
    return { width: _w, glyphs: 0, missing: _cov.missing, boxes: [[_x, _x + _w]] };
}
