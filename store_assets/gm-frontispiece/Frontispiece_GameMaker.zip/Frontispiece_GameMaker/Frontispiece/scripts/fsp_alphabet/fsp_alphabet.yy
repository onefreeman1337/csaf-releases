{
  "$GMScript": "v1",
  "%Name": "fsp_alphabet",
  "name": "fsp_alphabet",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}