/// fsp_draw.gml - the drawing primitives every Frontispiece screen is built from: an EVEN-ODD scanline fill (letters
/// have counters), linear-gradient fills and strokes, rotated ellipses, a radial vignette, thick polylines with round
/// joins, and sized, letter-spaced type.
///
/// Frontispiece - The Title Screen, Generated, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⛔ FOUR FACTS ABOUT THIS RENDERER DECIDE EVERYTHING BELOW:
///   1. GameMaker's primitives have NO antialiasing. The scanline fill therefore gives every span end its exact
///      fractional COVERAGE as alpha, and a screen is built SUPERSAMPLED (drawn at 2x, filtered down).
///   2. `draw_vertex_colour` carries its own alpha and IGNORES draw_set_alpha, so every function here takes alpha as
///      an argument.
///   3. One draw_primitive_begin batch SILENTLY DROPS vertices past a limit (~1000), so every loop that emits into a
///      batch flushes every 900 vertices.
///   4. A triangle fan spans a concavity silently, so fans are only ever handed convex shapes; anything else goes
///      through the scanline fill.
/// Colours passed to these functions are GameMaker colours; gradients are arrays of stops [t, colour, alpha].

/// @function fsp_grad_at(stops, t)
/// @description The colour and alpha of a gradient at t (clamped to 0..1), as [colour, alpha]. Pure.
function fsp_grad_at(_stops, _t) {
    var _n = array_length(_stops);
    if (_n == 0) return [c_black, 0];
    _t = clamp(_t, 0, 1);
    if (_t <= _stops[0][0]) return [_stops[0][1], _stops[0][2]];
    for (var _i = 1; _i < _n; _i++) {
        if (_t <= _stops[_i][0]) {
            var _a = _stops[_i - 1], _b = _stops[_i];
            var _span = _b[0] - _a[0];
            var _k = (_span > 0.0001) ? (_t - _a[0]) / _span : 1;
            return [merge_colour(_a[1], _b[1], _k), _a[2] + (_b[2] - _a[2]) * _k];
        }
    }
    return [_stops[_n - 1][1], _stops[_n - 1][2]];
}

/// @function fsp_stops2(c0, c1, [a0], [a1])
/// @description A two-stop gradient. Pure.
function fsp_stops2(_c0, _c1, _a0 = 1, _a1 = 1) { return [[0, _c0, _a0], [1, _c1, _a1]]; }

#macro FSP_FILL_EVENODD 0
#macro FSP_FILL_NONZERO 1
#macro FSP_FILL_STROKE 2

/// @function fsp_fill_rings(rings, colour, [alpha], [grad], [rule])
/// @description Fill an array of rings by scanline. `rule`:
///   FSP_FILL_EVENODD (0, default)  a point inside an odd number of rings is filled, so a counter is a second ring.
///   FSP_FILL_NONZERO (1)           every point the rings wind around at all is filled.
///   FSP_FILL_STROKE  (2)           ring 0 by NONZERO winding, minus every later ring (each by nonzero winding): a
///                                  swept pen stroke and its counters. ⛔ A stroke outline FOLDS where the pen turns
///                                  sharply (M, N, W, &): even-odd punched a light triangle at every such join (MEASURED
///                                  on the donor geometry: 9,933 empty pixels across the alphabet at a 160 px cap), and
///                                  plain nonzero fills every counter solid. This rule does neither.
/// `grad` is optional: {x0, y0, x1, y1, stops} - a linear gradient whose colour replaces `colour`. `true` is accepted as
/// FSP_FILL_NONZERO. Every span end carries its fractional coverage as alpha.
function fsp_fill_rings(_rings, _col, _alpha = 1, _grad = undefined, _rule = FSP_FILL_EVENODD) {
    if (_rule == true) _rule = FSP_FILL_NONZERO;
    if (!is_real(_rule) && !is_bool(_rule)) _rule = FSP_FILL_EVENODD;
    if (!is_array(_rings)) return 0;
    // Build the edge table once: [ymin, ymax, x at ymin, dx/dy, winding (+1 down, -1 up), ring 0 or a later ring].
    var _edges = [], _y0 = 1000000, _y1 = -1000000;
    for (var _r = 0; _r < array_length(_rings); _r++) {
        var _ring = _rings[_r];
        if (!is_array(_ring)) continue;
        var _n = array_length(_ring);
        if (_n < 3) continue;
        for (var _i = 0; _i < _n; _i++) {
            var _a = _ring[_i], _b = _ring[(_i + 1) mod _n];
            if (abs(_a[1] - _b[1]) < 0.0001) continue;
            var _down = (_a[1] < _b[1]);
            var _top = _down ? _a : _b, _bot = _down ? _b : _a;
            array_push(_edges, [_top[1], _bot[1], _top[0], (_bot[0] - _top[0]) / (_bot[1] - _top[1]), _down ? 1 : -1, (_r == 0) ? 0 : 1]);
            _y0 = min(_y0, _top[1]); _y1 = max(_y1, _bot[1]);
        }
    }
    var _ne = array_length(_edges);
    if (_ne < 2) return 0;
    // ⛔ THE COMPARATOR RETURNS A SIGN, NEVER A DIFFERENCE. `_p[0] - _q[0]` is a fraction for two edges whose tops are
    // under a pixel apart, and the sort treated those as EQUAL: edges were admitted rows late, rows lost a crossing, and
    // every letter drew with horizontal streaks (MEASURED: a 180-point disc left 856 of 1,304 interior pixels unpainted).
    array_sort(_edges, function(_p, _q) { return (_p[0] < _q[0]) ? -1 : ((_p[0] > _q[0]) ? 1 : 0); });
    var _hasg = is_struct(_grad);
    var _gx = 0, _gy = 0, _gl2 = 1, _gstops = [];
    if (_hasg) {
        _gx = _grad.x1 - _grad.x0; _gy = _grad.y1 - _grad.y0; _gl2 = max(0.0001, _gx * _gx + _gy * _gy); _gstops = _grad.stops;
    }
    var _active = [], _next = 0, _verts = 0, _spans = 0;
    draw_primitive_begin(pr_trianglelist);
    for (var _y = floor(_y0) + 0.5; _y < _y1; _y += 1) {
        // admit edges that start at or above this row, drop edges that end at or above it
        while (_next < _ne && _edges[_next][0] <= _y) { array_push(_active, _edges[_next]); _next++; }
        var _xs = [], _keep = [];
        for (var _k = 0; _k < array_length(_active); _k++) {
            var _e = _active[_k];
            if (_e[1] <= _y) continue;
            array_push(_keep, _e);
            if (_e[0] <= _y) array_push(_xs, (_rule == FSP_FILL_EVENODD) ? _e[2] + (_y - _e[0]) * _e[3] : [_e[2] + (_y - _e[0]) * _e[3], _e[4], _e[5]]);
        }
        _active = _keep;
        var _nx = array_length(_xs);
        if (_nx < 2) continue;
        var _ya = _y - 0.5, _yb = _y + 0.5;
        if (_rule == FSP_FILL_EVENODD) {
            array_sort(_xs, true);
            for (var _s = 0; _s + 1 < _nx; _s += 2) {
                var _xa = _xs[_s], _xb = _xs[_s + 1];
                if (_xb - _xa < 0.001) continue;
                if (_verts >= 900) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); _verts = 0; }
                _verts += fsp__span(_xa, _xb, _ya, _yb, _y, _col, _alpha, _hasg, _grad, _gx, _gy, _gl2, _gstops);
                _spans++;
            }
            continue;
        }
        // winding rules: walk the crossings left to right keeping one winding count for ring 0 and one for the rest
        array_sort(_xs, function(_p, _q) { return (_p[0] < _q[0]) ? -1 : ((_p[0] > _q[0]) ? 1 : 0); });
        var _wo = 0, _wh = 0, _was = false, _from = 0;
        for (var _c = 0; _c < _nx; _c++) {
            if (_xs[_c][2] == 0) _wo += _xs[_c][1]; else _wh += _xs[_c][1];
            var _in = (_rule == FSP_FILL_STROKE) ? (_wo != 0 && _wh == 0) : (_wo + _wh != 0);
            if (_in && !_was) _from = _xs[_c][0];
            if (!_in && _was) {
                var _to = _xs[_c][0];
                if (_to - _from >= 0.001) {
                    if (_verts >= 900) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); _verts = 0; }
                    _verts += fsp__span(_from, _to, _ya, _yb, _y, _col, _alpha, _hasg, _grad, _gx, _gy, _gl2, _gstops);
                    _spans++;
                }
            }
            _was = _in;
        }
    }
    draw_primitive_end();
    return _spans;
}

/// @function fsp__span(xa, xb, ya, yb, yc, col, alpha, hasg, grad, gx, gy, gl2, stops)
/// @description One scanline span with coverage-alpha ends. Internal to fsp_fill_rings; returns vertices emitted.
function fsp__span(_xa, _xb, _ya, _yb, _yc, _col, _alpha, _hasg, _grad, _gx, _gy, _gl2, _stops) {
    var _L = floor(_xa), _R = floor(_xb), _v = 0;
    if (_L == _R) {
        fsp__quad(_L, _L + 1, _ya, _yb, _yc, _col, _alpha * (_xb - _xa), _hasg, _grad, _gx, _gy, _gl2, _stops);
        return 6;
    }
    fsp__quad(_L, _L + 1, _ya, _yb, _yc, _col, _alpha * (_L + 1 - _xa), _hasg, _grad, _gx, _gy, _gl2, _stops); _v += 6;
    if (_R > _L + 1) {
        if (_hasg) {
            // split the interior where the gradient crosses a stop, so a multi-stop gradient is exact along the row
            var _t0 = ((_L + 1 - _grad.x0) * _gx + (_yc - _grad.y0) * _gy) / _gl2;
            var _t1 = ((_R - _grad.x0) * _gx + (_yc - _grad.y0) * _gy) / _gl2;
            var _cuts = [_L + 1];
            if (abs(_t1 - _t0) > 0.0001) {
                for (var _i = 0; _i < array_length(_stops); _i++) {
                    var _ts = _stops[_i][0];
                    if ((_ts - _t0) * (_ts - _t1) < 0) array_push(_cuts, _L + 1 + (_R - _L - 1) * (_ts - _t0) / (_t1 - _t0));
                }
            }
            array_push(_cuts, _R);
            array_sort(_cuts, true);
            for (var _c = 0; _c + 1 < array_length(_cuts); _c++) {
                fsp__quad(_cuts[_c], _cuts[_c + 1], _ya, _yb, _yc, _col, _alpha, true, _grad, _gx, _gy, _gl2, _stops); _v += 6;
            }
        } else {
            fsp__quad(_L + 1, _R, _ya, _yb, _yc, _col, _alpha, false, _grad, _gx, _gy, _gl2, _stops); _v += 6;
        }
    }
    if (_xb - _R > 0.001) { fsp__quad(_R, _R + 1, _ya, _yb, _yc, _col, _alpha * (_xb - _R), _hasg, _grad, _gx, _gy, _gl2, _stops); _v += 6; }
    return _v;
}

/// @function fsp__quad(xa, xb, ya, yb, yc, col, alpha, hasg, grad, gx, gy, gl2, stops)
/// @description Two triangles of one span piece, coloured at each end by the gradient if there is one. Internal.
function fsp__quad(_xa, _xb, _ya, _yb, _yc, _col, _alpha, _hasg, _grad, _gx, _gy, _gl2, _stops) {
    var _ca = _col, _cb = _col, _aa = _alpha, _ab = _alpha;
    if (_hasg) {
        var _ga = fsp_grad_at(_stops, ((_xa - _grad.x0) * _gx + (_yc - _grad.y0) * _gy) / _gl2);
        var _gb = fsp_grad_at(_stops, ((_xb - _grad.x0) * _gx + (_yc - _grad.y0) * _gy) / _gl2);
        _ca = _ga[0]; _cb = _gb[0]; _aa = _alpha * _ga[1]; _ab = _alpha * _gb[1];
    }
    draw_vertex_colour(_xa, _ya, _ca, _aa); draw_vertex_colour(_xb, _ya, _cb, _ab); draw_vertex_colour(_xa, _yb, _ca, _aa);
    draw_vertex_colour(_xb, _ya, _cb, _ab); draw_vertex_colour(_xb, _yb, _cb, _ab); draw_vertex_colour(_xa, _yb, _ca, _aa);
}

/// @function fsp_rect_ring(x, y, w, h)
/// @description A rectangle as a ring. Pure.
function fsp_rect_ring(_x, _y, _w, _h) { return [[_x, _y], [_x + _w, _y], [_x + _w, _y + _h], [_x, _y + _h]]; }

/// @function fsp_rect(x, y, w, h, colour, [alpha])
/// @description A flat axis-aligned rectangle (two triangles; no scanline needed).
function fsp_rect(_x, _y, _w, _h, _col, _alpha = 1) {
    if (_w <= 0 || _h <= 0) return;
    draw_primitive_begin(pr_trianglestrip);
    draw_vertex_colour(_x, _y, _col, _alpha); draw_vertex_colour(_x + _w, _y, _col, _alpha);
    draw_vertex_colour(_x, _y + _h, _col, _alpha); draw_vertex_colour(_x + _w, _y + _h, _col, _alpha);
    draw_primitive_end();
}

/// @function fsp_rect_grad(x, y, w, h, x0, y0, x1, y1, stops, [alpha])
/// @description A rectangle filled with a linear gradient from (x0, y0) to (x1, y1), exact across every stop.
function fsp_rect_grad(_x, _y, _w, _h, _x0, _y0, _x1, _y1, _stops, _alpha = 1) {
    if (_w <= 0 || _h <= 0) return;
    fsp_fill_rings([fsp_rect_ring(_x, _y, _w, _h)], c_white, _alpha, { x0: _x0, y0: _y0, x1: _x1, y1: _y1, stops: _stops });
}

/// @function fsp_ellipse_ring(cx, cy, rx, ry, rot, [n])
/// @description A rotated ellipse as a ring. Pure.
function fsp_ellipse_ring(_cx, _cy, _rx, _ry, _rot, _n = -1) {
    if (_n < 0) _n = clamp(ceil(max(_rx, _ry) * 1.3), 10, 72);
    var _o = array_create(_n), _c = cos(_rot), _s = sin(_rot);
    for (var _i = 0; _i < _n; _i++) {
        var _t = _i / _n * 2 * pi, _ex = cos(_t) * _rx, _ey = sin(_t) * _ry;
        _o[_i] = [_cx + _ex * _c - _ey * _s, _cy + _ex * _s + _ey * _c];
    }
    return _o;
}

/// @function fsp_ellipse(cx, cy, rx, ry, rot, colour, [alpha])
/// @description A filled rotated ellipse, as a fan (an ellipse is convex).
function fsp_ellipse(_cx, _cy, _rx, _ry, _rot, _col, _alpha = 1) {
    if (_rx <= 0 || _ry <= 0) return;
    var _n = clamp(ceil(max(_rx, _ry) * 1.3), 8, 72), _c = cos(_rot), _s = sin(_rot);
    draw_primitive_begin(pr_trianglefan);
    draw_vertex_colour(_cx, _cy, _col, _alpha);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n * 2 * pi, _ex = cos(_t) * _rx, _ey = sin(_t) * _ry;
        draw_vertex_colour(_cx + _ex * _c - _ey * _s, _cy + _ex * _s + _ey * _c, _col, _alpha);
    }
    draw_primitive_end();
}

/// @function fsp_ellipse_grad(cx, cy, rx, ry, rot, x0, y0, x1, y1, stops, [alpha])
/// @description A rotated ellipse whose vertices take a linear gradient's colour (exact at the vertices, linear
/// between them - an ellipse's facets are small enough that a multi-stop gradient reads correctly).
function fsp_ellipse_grad(_cx, _cy, _rx, _ry, _rot, _x0, _y0, _x1, _y1, _stops, _alpha = 1) {
    if (_rx <= 0 || _ry <= 0) return;
    var _gx = _x1 - _x0, _gy = _y1 - _y0, _gl2 = max(0.0001, _gx * _gx + _gy * _gy);
    var _n = clamp(ceil(max(_rx, _ry) * 1.3), 10, 72), _c = cos(_rot), _s = sin(_rot);
    var _g = fsp_grad_at(_stops, ((_cx - _x0) * _gx + (_cy - _y0) * _gy) / _gl2);
    draw_primitive_begin(pr_trianglefan);
    draw_vertex_colour(_cx, _cy, _g[0], _alpha * _g[1]);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n * 2 * pi, _ex = cos(_t) * _rx, _ey = sin(_t) * _ry;
        var _px = _cx + _ex * _c - _ey * _s, _py = _cy + _ex * _s + _ey * _c;
        _g = fsp_grad_at(_stops, ((_px - _x0) * _gx + (_py - _y0) * _gy) / _gl2);
        draw_vertex_colour(_px, _py, _g[0], _alpha * _g[1]);
    }
    draw_primitive_end();
}

/// @function fsp_seg(x1, y1, x2, y2, w, colour, [alpha], [colour2], [alpha2])
/// @description A straight stroke `w` px wide; optionally shaded from colour/alpha at the first end to colour2/alpha2
/// at the second. Below one pixel it is drawn one pixel wide at a proportionally lower alpha.
function fsp_seg(_x1, _y1, _x2, _y2, _w, _col, _alpha = 1, _col2 = undefined, _alpha2 = undefined) {
    var _dx = _x2 - _x1, _dy = _y2 - _y1, _len = sqrt(_dx * _dx + _dy * _dy);
    if (_len <= 0.0001) return;
    if (is_undefined(_col2)) _col2 = _col;
    if (is_undefined(_alpha2)) _alpha2 = _alpha;
    var _k = 1, _ww = _w;
    if (_w < 1) { _k = max(0.15, _w); _ww = 1; }
    var _nx = -_dy / _len * _ww * 0.5, _ny = _dx / _len * _ww * 0.5;
    draw_primitive_begin(pr_trianglestrip);
    draw_vertex_colour(_x1 + _nx, _y1 + _ny, _col, _alpha * _k); draw_vertex_colour(_x1 - _nx, _y1 - _ny, _col, _alpha * _k);
    draw_vertex_colour(_x2 + _nx, _y2 + _ny, _col2, _alpha2 * _k); draw_vertex_colour(_x2 - _nx, _y2 - _ny, _col2, _alpha2 * _k);
    draw_primitive_end();
}

/// @function fsp_polyline(pts, w, colour, [alpha], [closed])
/// @description A stroke through an array of [x, y] points. Joins are filled with a disc of the stroke's radius:
/// butt-ended segments meeting at an angle leave a notch of bare ground on the outside of every turn.
function fsp_polyline(_pts, _w, _col, _alpha = 1, _closed = false) {
    var _n = array_length(_pts);
    if (_n < 2) return;
    for (var _i = 0; _i < _n - 1; _i++) fsp_seg(_pts[_i][0], _pts[_i][1], _pts[_i + 1][0], _pts[_i + 1][1], _w, _col, _alpha);
    if (_closed) fsp_seg(_pts[_n - 1][0], _pts[_n - 1][1], _pts[0][0], _pts[0][1], _w, _col, _alpha);
    if (_w >= 2 && _alpha >= 0.999) {
        var _from = _closed ? 0 : 1, _to = _closed ? _n : _n - 1;
        for (var _j = _from; _j < _to; _j++) fsp_ellipse(_pts[_j][0], _pts[_j][1], _w * 0.5, _w * 0.5, 0, _col, _alpha);
    }
}

/// @function fsp_stroke_grad(pts, w, closed, x0, y0, x1, y1, stops)
/// @description A stroke through points whose colour follows a linear gradient - what makes a moulding read as an
/// EDGE WITH THICKNESS (lit at the upper left, shadowed at the lower right) rather than as an outline.
function fsp_stroke_grad(_pts, _w, _closed, _x0, _y0, _x1, _y1, _stops) {
    var _n = array_length(_pts);
    if (_n < 2) return;
    var _gx = _x1 - _x0, _gy = _y1 - _y0, _gl2 = max(0.0001, _gx * _gx + _gy * _gy);
    var _m = _closed ? _n : _n - 1;
    for (var _i = 0; _i < _m; _i++) {
        var _a = _pts[_i], _b = _pts[(_i + 1) mod _n];
        var _ga = fsp_grad_at(_stops, ((_a[0] - _x0) * _gx + (_a[1] - _y0) * _gy) / _gl2);
        var _gb = fsp_grad_at(_stops, ((_b[0] - _x0) * _gx + (_b[1] - _y0) * _gy) / _gl2);
        // extend each segment by half the width so corners close without a notch
        var _dx = _b[0] - _a[0], _dy = _b[1] - _a[1], _l = max(0.0001, sqrt(_dx * _dx + _dy * _dy));
        var _ex = _dx / _l * _w * 0.5, _ey = _dy / _l * _w * 0.5;
        fsp_seg(_a[0] - _ex, _a[1] - _ey, _b[0] + _ex, _b[1] + _ey, _w, _ga[0], _ga[1], _gb[0], _gb[1]);
    }
}

/// @function fsp_rect_stroke(x, y, w, h, lw, colour, [alpha])
/// @description A rectangle outline `lw` wide, CENTRED on the rectangle's edge (as a canvas stroke is).
function fsp_rect_stroke(_x, _y, _w, _h, _lw, _col, _alpha = 1) {
    var _t = max(1, _lw), _a = (_lw < 1) ? _alpha * max(0.15, _lw) : _alpha, _hh = _t * 0.5;
    fsp_rect(_x - _hh, _y - _hh, _w + _t, _t, _col, _a);
    fsp_rect(_x - _hh, _y + _h - _hh, _w + _t, _t, _col, _a);
    fsp_rect(_x - _hh, _y + _hh, _t, _h - _t, _col, _a);
    fsp_rect(_x + _w - _hh, _y + _hh, _t, _h - _t, _col, _a);
}

/// @function fsp_rect_stroke_grad(x, y, w, h, lw, x0, y0, x1, y1, stops)
/// @description A rectangle outline whose colour follows a linear gradient (centred on the edge).
function fsp_rect_stroke_grad(_x, _y, _w, _h, _lw, _x0, _y0, _x1, _y1, _stops) {
    fsp_stroke_grad([[_x, _y], [_x + _w, _y], [_x + _w, _y + _h], [_x, _y + _h]], max(1, _lw), true, _x0, _y0, _x1, _y1, _stops);
}

/// @function fsp_radial_rect(x, y, w, h, cx, cy, r0, r1, colour, a0, a1)
/// @description A radial wash over a rectangle: alpha a0 inside r0 of (cx, cy) rising (or falling) to a1 at r1 and
/// beyond, as a vertex mesh (every vertex takes the alpha at its own distance).
function fsp_radial_rect(_x, _y, _w, _h, _cx, _cy, _r0, _r1, _col, _a0, _a1) {
    var _nx = 32, _ny = 20, _verts = 0, _span = max(0.0001, _r1 - _r0);
    draw_primitive_begin(pr_trianglelist);
    for (var _j = 0; _j < _ny; _j++) {
        for (var _i = 0; _i < _nx; _i++) {
            if (_verts >= 900) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); _verts = 0; }
            var _xa = _x + _w * _i / _nx, _xb = _x + _w * (_i + 1) / _nx, _ya = _y + _h * _j / _ny, _yb = _y + _h * (_j + 1) / _ny;
            var _aa = _a0 + (_a1 - _a0) * clamp((point_distance(_xa, _ya, _cx, _cy) - _r0) / _span, 0, 1);
            var _ba = _a0 + (_a1 - _a0) * clamp((point_distance(_xb, _ya, _cx, _cy) - _r0) / _span, 0, 1);
            var _ca = _a0 + (_a1 - _a0) * clamp((point_distance(_xa, _yb, _cx, _cy) - _r0) / _span, 0, 1);
            var _da = _a0 + (_a1 - _a0) * clamp((point_distance(_xb, _yb, _cx, _cy) - _r0) / _span, 0, 1);
            draw_vertex_colour(_xa, _ya, _col, _aa); draw_vertex_colour(_xb, _ya, _col, _ba); draw_vertex_colour(_xa, _yb, _col, _ca);
            draw_vertex_colour(_xb, _ya, _col, _ba); draw_vertex_colour(_xb, _yb, _col, _da); draw_vertex_colour(_xa, _yb, _col, _ca);
            _verts += 6;
        }
    }
    draw_primitive_end();
}

// ---------------------------------------------------------------------------------------------------------------
// Batches. A worked ground is thousands of small marks; one draw_primitive_begin per mark is thousands of batches.
// Between fsp_batch_begin() and fsp_batch_end() the batch_* functions all emit into ONE triangle list, flushed every
// 900 vertices. ⛔ Nothing else that draws may be called inside a batch.
// ---------------------------------------------------------------------------------------------------------------

/// @function fsp_batch_begin()
/// @description Open a triangle-list batch for the batch_* functions.
function fsp_batch_begin() { global.fsp__batch_verts = 0; draw_primitive_begin(pr_trianglelist); }

/// @function fsp_batch_end()
/// @description Close the batch opened by fsp_batch_begin().
function fsp_batch_end() { draw_primitive_end(); global.fsp__batch_verts = 0; }

/// @function fsp__batch_room(n)
/// @description Make room for n vertices, flushing the batch when it would pass 900. Internal.
function fsp__batch_room(_n) {
    if (global.fsp__batch_verts + _n > 900) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); global.fsp__batch_verts = 0; }
    global.fsp__batch_verts += _n;
}

/// @function fsp_batch_ellipse(cx, cy, rx, ry, rot, colour, alpha)
/// @description A small filled rotated ellipse, inside a batch.
function fsp_batch_ellipse(_cx, _cy, _rx, _ry, _rot, _col, _alpha) {
    if (_rx <= 0 || _ry <= 0) return;
    var _n = clamp(ceil(max(_rx, _ry) * 1.2), 6, 28), _c = cos(_rot), _s = sin(_rot);
    fsp__batch_room(_n * 3);
    var _px = _cx + _rx * _c, _py = _cy + _rx * _s;
    for (var _i = 1; _i <= _n; _i++) {
        var _t = _i / _n * 2 * pi, _ex = cos(_t) * _rx, _ey = sin(_t) * _ry;
        var _qx = _cx + _ex * _c - _ey * _s, _qy = _cy + _ex * _s + _ey * _c;
        draw_vertex_colour(_cx, _cy, _col, _alpha); draw_vertex_colour(_px, _py, _col, _alpha); draw_vertex_colour(_qx, _qy, _col, _alpha);
        _px = _qx; _py = _qy;
    }
}

/// @function fsp_batch_seg(x1, y1, x2, y2, w, colour, alpha)
/// @description A straight stroke inside a batch; below one pixel wide it is one pixel at a proportional alpha.
function fsp_batch_seg(_x1, _y1, _x2, _y2, _w, _col, _alpha) {
    var _dx = _x2 - _x1, _dy = _y2 - _y1, _len = sqrt(_dx * _dx + _dy * _dy);
    if (_len <= 0.0001) return;
    var _a = _alpha, _ww = _w;
    if (_w < 1) { _a = _alpha * max(0.15, _w); _ww = 1; }
    var _nx = -_dy / _len * _ww * 0.5, _ny = _dx / _len * _ww * 0.5;
    fsp__batch_room(6);
    draw_vertex_colour(_x1 + _nx, _y1 + _ny, _col, _a); draw_vertex_colour(_x1 - _nx, _y1 - _ny, _col, _a); draw_vertex_colour(_x2 + _nx, _y2 + _ny, _col, _a);
    draw_vertex_colour(_x1 - _nx, _y1 - _ny, _col, _a); draw_vertex_colour(_x2 - _nx, _y2 - _ny, _col, _a); draw_vertex_colour(_x2 + _nx, _y2 + _ny, _col, _a);
}

/// @function fsp_batch_convex(ring, colour, alpha)
/// @description A small CONVEX polygon (an array of [x, y] points) inside a batch.
function fsp_batch_convex(_ring, _col, _alpha) {
    var _n = array_length(_ring);
    if (_n < 3) return;
    fsp__batch_room((_n - 2) * 3);
    for (var _i = 1; _i < _n - 1; _i++) {
        draw_vertex_colour(_ring[0][0], _ring[0][1], _col, _alpha);
        draw_vertex_colour(_ring[_i][0], _ring[_i][1], _col, _alpha);
        draw_vertex_colour(_ring[_i + 1][0], _ring[_i + 1][1], _col, _alpha);
    }
}

/// @function fsp_batch_rect(x, y, w, h, colour, alpha)
/// @description An axis-aligned rectangle inside a batch.
function fsp_batch_rect(_x, _y, _w, _h, _col, _alpha) {
    if (_w <= 0 || _h <= 0) return;
    fsp__batch_room(6);
    draw_vertex_colour(_x, _y, _col, _alpha); draw_vertex_colour(_x + _w, _y, _col, _alpha); draw_vertex_colour(_x, _y + _h, _col, _alpha);
    draw_vertex_colour(_x + _w, _y, _col, _alpha); draw_vertex_colour(_x + _w, _y + _h, _col, _alpha); draw_vertex_colour(_x, _y + _h, _col, _alpha);
}

// ---------------------------------------------------------------------------------------------------------------
// Supporting type. The WORDMARK is never set in these: it is cut from the authored alphabet (fsp_alphabet). These
// letter the menu, the subtitle and the imprint - and a title the Latin corpus cannot cut.
// ---------------------------------------------------------------------------------------------------------------

/// @function fsp_font_px(font)
/// @description The pixel size a font resource was rasterised at, so type can be drawn at any size by scale. An
/// unknown font (a buyer's own) is measured once from its "H" height.
function fsp_font_px(_font) {
    if (_font == fnt_frontispiece_display) return 120;
    if (_font == fnt_frontispiece_title) return 56;
    if (_font == fnt_frontispiece) return 26;
    if (_font == fnt_frontispiece_ui) return 17;
    var _prev = draw_get_font();
    draw_set_font(_font);
    var _h = string_height("H");
    draw_set_font(_prev);
    return max(1, _h);
}

/// @function fsp_font_for(font, px)
/// @description The atlas to draw `px`-tall type from. ⛔ A bitmap font scaled UP goes soft, so large serif type comes
/// from the bigger atlas of the same face. Pure.
function fsp_font_for(_font, _px) {
    if ((_font == fnt_frontispiece || _font == fnt_frontispiece_title) && _px > 84) return fnt_frontispiece_display;
    if (_font == fnt_frontispiece && _px > 38) return fnt_frontispiece_title;
    return _font;
}

/// @function fsp_text(x, y, string, px, colour, [halign], [valign], [font], [alpha])
/// @description Draw type `px` pixels tall. Returns the drawn width. ⛔ Texture filtering is switched ON for the draw
/// and RESTORED after: a scaled atlas with point sampling drops one-pixel strokes (a "T" becomes an "I").
function fsp_text(_x, _y, _s, _px, _col, _ha = fa_left, _va = fa_top, _font = fnt_frontispiece, _alpha = 1) {
    _s = string(_s);
    _font = fsp_font_for(_font, _px);
    var _pf = draw_get_font(), _ph = draw_get_halign(), _pv = draw_get_valign(), _pa = draw_get_alpha(), _pc = draw_get_colour(), _pt = gpu_get_texfilter();
    draw_set_font(_font);
    var _sc = _px / fsp_font_px(_font);
    var _w = string_width(_s) * _sc;
    draw_set_halign(_ha); draw_set_valign(_va); draw_set_colour(_col); draw_set_alpha(_alpha);
    gpu_set_texfilter(true);
    draw_text_transformed(_x, _y, _s, _sc, _sc, 0);
    gpu_set_texfilter(_pt);
    draw_set_font(_pf); draw_set_halign(_ph); draw_set_valign(_pv); draw_set_alpha(_pa); draw_set_colour(_pc);
    return _w;
}

/// @function fsp_text_w(string, px, [font])
/// @description The width fsp_text would draw a string at. Pure but for the font it sets and restores.
function fsp_text_w(_s, _px, _font = fnt_frontispiece) {
    _font = fsp_font_for(_font, _px);
    var _pf = draw_get_font();
    draw_set_font(_font);
    var _w = string_width(string(_s)) * _px / fsp_font_px(_font);
    draw_set_font(_pf);
    return _w;
}

/// @function fsp_tracked_w(string, px, track, [font])
/// @description Width of a letter-spaced string (`track` px of extra space between letters).
function fsp_tracked_w(_s, _px, _track, _font = fnt_frontispiece) {
    _s = string(_s);
    var _n = string_length(_s), _w = 0;
    for (var _i = 1; _i <= _n; _i++) _w += fsp_text_w(string_char_at(_s, _i), _px, _font) + ((_i < _n) ? _track : 0);
    return _w;
}

/// @function fsp_tracked(x, y, string, px, track, colour, [font], [alpha])
/// @description Draw a letter-spaced string from its LEFT edge at x, top at y. Returns the drawn width.
function fsp_tracked(_x, _y, _s, _px, _track, _col, _font = fnt_frontispiece, _alpha = 1) {
    _s = string(_s);
    var _n = string_length(_s), _cx = _x;
    for (var _i = 1; _i <= _n; _i++) {
        var _ch = string_char_at(_s, _i);
        fsp_text(_cx, _y, _ch, _px, _col, fa_left, fa_top, _font, _alpha);
        _cx += fsp_text_w(_ch, _px, _font) + _track;
    }
    return _cx - _x - ((_n > 0) ? _track : 0);
}

/// @function fsp_fit_tracked(string, maxw, px, track, minpx, [font])
/// @description Shrink tracking, then size, until a string fits `maxw`: {px, track, width, fits}. ⛔ A fitter that can
/// fail to fit SAYS so, and every caller reads `fits` - a line that will not fit is dropped, never clipped.
function fsp_fit_tracked(_s, _maxw, _px, _track, _minpx, _font = fnt_frontispiece) {
    var _w = fsp_tracked_w(_s, _px, _track, _font);
    while (_w > _maxw && _track > 0) { _track = max(0, _track - 0.3 * max(1, _px / 20)); _w = fsp_tracked_w(_s, _px, _track, _font); }
    while (_w > _maxw && _px > _minpx) { _px = max(_minpx, _px - max(0.5, _px * 0.05)); _w = fsp_tracked_w(_s, _px, _track, _font); }
    return { px: _px, track: _track, width: _w, fits: _w <= _maxw };
}
