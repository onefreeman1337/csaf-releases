{
  "$GMScript": "v1",
  "%Name": "fsp_screen",
  "name": "fsp_screen",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}