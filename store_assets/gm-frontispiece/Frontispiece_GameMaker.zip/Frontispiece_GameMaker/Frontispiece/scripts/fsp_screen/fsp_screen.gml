/// fsp_screen.gml - the part you call. Builds a whole title screen for YOUR game once, into sprites, then draws it
/// every frame for the cost of a few sprite draws: the wordmark is CUT in letter by letter, the device and the menu come
/// up after it, and the chosen row moves with a short crossfade. Keyboard, gamepad and mouse are yours to read; this
/// file only needs to be told "up", "down", "here is the mouse" and "confirm".
///
/// Frontispiece - The Title Screen, Generated, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// QUICKSTART (a title object):
///     Create:   screen = fsp_screen_create("Thanehold", { subtitle: "A Tale of the Late Kingdom",
///                   commands: ["New Game", "Continue", "Options", "Quit"], enabled: [true, file_exists("save.dat"), true, true] });
///     Step:     fsp_screen_step(screen);
///               if (keyboard_check_pressed(vk_down)) fsp_screen_move(screen, 1);
///               if (keyboard_check_pressed(vk_up)) fsp_screen_move(screen, -1);
///               fsp_screen_hover(screen, device_mouse_x_to_gui(0), device_mouse_y_to_gui(0));
///               if (keyboard_check_pressed(vk_enter) || mouse_check_button_pressed(mb_left)) {
///                   var _choice = fsp_screen_confirm(screen);   // -1 while the reveal runs, or on a disabled row
///                   if (_choice == 0) room_goto(rm_game);
///               }
///     Draw GUI: fsp_screen_draw(screen, 0, 0);
///     Clean Up: fsp_screen_free(screen);
///
/// ⛔ BUILD COST IS PAID ONCE, IN fsp_screen_create: every mark is drawn at 2x into a surface and filtered down into
/// sprites (the renderer has no antialiasing). Sprites survive a lost surface, so there is nothing to rebuild on a
/// display change. Call it on a loading frame, not mid-game.

#macro FSP_GLYPH_FRAMES 9
#macro FSP_FADE_FRAMES 10

/// @function fsp_screen_create(title, [options])
/// @description Build a title screen for a game called `title`. options (all optional):
///   house, ground, frame, cartouche, hand, cut, vignette, menu   "auto" (default) or an id - see the Readme's tables
///   words        array of strings your game uses (elements, classes, regions) - read to choose the house and device
///   subtitle     a line under the title ("" for none)
///   imprint      the small line at the foot - a studio name, a version ("" for none)
///   commands     the menu rows (default ["New Game", "Continue", "Options", "Quit"])
///   enabled      one boolean per row; a disabled row is drawn greyed and cannot be confirmed
///   index        the row chosen at start (default: the first enabled row)
///   width, height  the size to build at (default: the GUI size)
///   supersample  1 or 2 (default 2) - 2 draws every mark at twice the size and filters it down
///   reveal       false to show the finished screen at once (default true: the title is cut in)
///   fallback_font  the font a title is lettered in when the Latin corpus cannot cut it
/// Returns the screen struct. Anything invalid falls back to a default and is listed in screen.warnings.
function fsp_screen_create(_title, _options = undefined) {
    var _o = is_struct(_options) ? _options : {};
    var _t = is_string(_title) ? _title : string(_title);
    var _spec = fsp_compose(_t, _o);
    var _w = variable_struct_exists(_o, "width") && is_real(_o.width) ? floor(_o.width) : display_get_gui_width();
    var _h = variable_struct_exists(_o, "height") && is_real(_o.height) ? floor(_o.height) : display_get_gui_height();
    var _warn = _spec.warnings;
    if (_w < 160 || _h < 120 || _w > 4096 || _h > 4096) { array_push(_warn, "size " + string(_w) + "x" + string(_h) + " out of range; built at 1280x720"); _w = 1280; _h = 720; }
    var _k = (variable_struct_exists(_o, "supersample") && is_real(_o.supersample) && _o.supersample < 1.5) ? 1 : 2;
    if (_w * _k > 8192 || _h * _k > 8192) _k = 1;
    var _cmds = ["New Game", "Continue", "Options", "Quit"];
    if (variable_struct_exists(_o, "commands") && is_array(_o.commands) && array_length(_o.commands) > 0) {
        _cmds = [];
        for (var _c = 0; _c < min(8, array_length(_o.commands)); _c++) array_push(_cmds, string(_o.commands[_c]));
        if (array_length(_o.commands) > 8) array_push(_warn, "more than 8 commands; the first 8 are used");
    }
    var _en = array_create(array_length(_cmds), true);
    if (variable_struct_exists(_o, "enabled") && is_array(_o.enabled)) for (var _e = 0; _e < min(array_length(_en), array_length(_o.enabled)); _e++) _en[_e] = (_o.enabled[_e] != false);
    var _s = {
        spec: _spec, options: _o, title: _t, w: _w, h: _h, k: _k, warnings: _warn,
        subtitle: (variable_struct_exists(_o, "subtitle") && is_string(_o.subtitle)) ? _o.subtitle : "",
        imprint: (variable_struct_exists(_o, "imprint") && is_string(_o.imprint)) ? _o.imprint : "",
        fallback_font: (variable_struct_exists(_o, "fallback_font") && fsp__font_ok(_o.fallback_font)) ? _o.fallback_font : fnt_frontispiece_title,
        commands: _cmds, enabled: _en, index: 0, prev: -1, fade: 1, t: 0,
        reveal: !(variable_struct_exists(_o, "reveal") && _o.reveal == false),
        spr_base: -1, spr_full: -1, spr_menu: [], menu_region: { x: 0, y: 0, w: 0, h: 0 }, rows: [], columns: [], sub_rect: undefined,
        vig_rect: { x: 0, y: 0, w: 0, h: 0 }, spark: c_white, report: undefined, build_ms: 0, last_hover: -1
    };
    var _start = (variable_struct_exists(_o, "index") && is_real(_o.index)) ? clamp(floor(_o.index), 0, array_length(_cmds) - 1) : 0;
    _s.index = fsp__first_enabled(_s, _start);
    fsp_screen_rebuild(_s);
    return _s;
}

/// @function fsp__font_ok(font)
/// @description True when `font` is a font resource that exists. Never throws on a wrong-typed value. Internal.
function fsp__font_ok(_f) {
    var _ok = false;
    try { _ok = font_exists(_f); } catch (_e) { _ok = false; }
    return _ok;
}

/// @function fsp__first_enabled(screen, from)
/// @description The first enabled row at or after `from` (wrapping); `from` itself when none is enabled. Internal.
function fsp__first_enabled(_s, _from) {
    var _n = array_length(_s.commands);
    for (var _i = 0; _i < _n; _i++) { var _j = (_from + _i) mod _n; if (_s.enabled[_j]) return _j; }
    return _from;
}

/// @function fsp__downsample(src, sx, sy, sw, sh, k)
/// @description A region of a supersampled surface filtered down by k into a NEW surface (caller frees it). At k = 2
/// bilinear sampling lands exactly between four texels, so this is a true 2x2 box filter. Internal.
function fsp__downsample(_src, _sx, _sy, _sw, _sh, _k) {
    var _dw = max(1, round(_sw / _k)), _dh = max(1, round(_sh / _k));
    var _dst = surface_create(_dw, _dh);
    surface_set_target(_dst);
    draw_clear_alpha(c_black, 1);
    var _pt = gpu_get_texfilter();
    gpu_set_texfilter(_k > 1);
    draw_surface_part_ext(_src, _sx, _sy, _sw, _sh, 0, 0, 1 / _k, 1 / _k, c_white, 1);
    gpu_set_texfilter(_pt);
    fsp__opaque(_dw, _dh);
    surface_reset_target();
    return _dst;
}

/// @function fsp__opaque(w, h)
/// @description Force the current target's alpha channel to 1 (text and translucent marks leave it below 1, and a
/// sprite made from it would be see-through). Internal.
function fsp__opaque(_w, _h) {
    gpu_set_colorwriteenable(false, false, false, true);
    fsp_rect(0, 0, _w, _h, c_white, 1);
    gpu_set_colorwriteenable(true, true, true, true);
}

/// @function fsp_screen_rebuild(screen)
/// @description (Re)draw every layer of a screen from its current options - after fsp_screen_set_house(), after
/// changing `enabled`, or to change size. Frees the old sprites first. Returns the build time in ms (MEASURED by
/// get_timer on the machine it runs on).
function fsp_screen_rebuild(_s) {
    // a value that is not a screen is refused (MEASURED: undefined, -1, 4096 and a string all threw here)
    if (!is_struct(_s) || !variable_struct_exists(_s, "spec") || !variable_struct_exists(_s, "commands") || !variable_struct_exists(_s, "spr_menu")) return 0;
    var _t0 = get_timer();
    fsp__free_sprites(_s);
    var _k = _s.k, _W = _s.w * _k, _H = _s.h * _k, _box = { x: 0, y: 0, w: _W, h: _H };
    var _st = { subtitle: _s.subtitle, imprint: _s.imprint, commands: _s.commands, enabled: _s.enabled, index: _s.index, fallback_font: _s.fallback_font };
    var _big = surface_create(_W, _H);
    // 1. the base: ground, frame, the empty cartouche and the imprint
    surface_set_target(_big);
    draw_clear_alpha(c_black, 1);
    var _rep = fsp_plate_draw(_s.spec, _box, _st, _k, { letters: false, vignette: false, menu: false });
    fsp__opaque(_W, _H);
    surface_reset_target();
    var _small = fsp__downsample(_big, 0, 0, _W, _H, _k);
    _s.spr_base = sprite_create_from_surface(_small, 0, 0, _s.w, _s.h, false, false, 0, 0);
    surface_free(_small);
    // 2. the finished static screen: + the cut wordmark, the subtitle, the device
    surface_set_target(_big);
    var _rep2 = fsp_plate_draw(_s.spec, _box, _st, _k, { ground: false, frame: false, panel: false, imprint: false, menu: false });
    fsp__opaque(_W, _H);
    surface_reset_target();
    _small = fsp__downsample(_big, 0, 0, _W, _H, _k);
    _s.spr_full = sprite_create_from_surface(_small, 0, 0, _s.w, _s.h, false, false, 0, 0);
    surface_free(_small);
    // 3. one menu sprite per chosen row, cut from a region padded for every treatment's overhang
    var _L = _rep.layout, _n = array_length(_s.commands);
    var _rects = fsp_plate_menu_rects(_L, _n, _k);
    var _mx = _L.menu.w * 0.20, _my = (_n > 0) ? _rects[0].h * 0.45 : 0;
    var _rx = clamp(floor((_L.menu.x - _mx) / _k) * _k, 0, _W), _ry = clamp(floor((_L.menu.y - _my) / _k) * _k, 0, _H);
    var _rw = clamp(ceil((_L.menu.w + 2 * _mx) / _k) * _k, _k, _W - _rx), _rh = clamp(ceil((_L.menu.h + 2 * _my) / _k) * _k, _k, _H - _ry);
    var _under = surface_create(_rw, _rh);
    surface_copy_part(_under, 0, 0, _big, _rx, _ry, _rw, _rh);
    _s.spr_menu = array_create(_n, -1);
    for (var _i = 0; _i < _n; _i++) {
        surface_set_target(_big);
        draw_surface(_under, _rx, _ry);
        fsp_plate_menu(_s.spec, _L, _s.commands, _s.enabled, _i, _k);
        fsp__opaque(_W, _H);
        surface_reset_target();
        _small = fsp__downsample(_big, _rx, _ry, _rw, _rh, _k);
        _s.spr_menu[_i] = sprite_create_from_surface(_small, 0, 0, _rw / _k, _rh / _k, false, false, 0, 0);
        surface_free(_small);
    }
    surface_free(_under);
    surface_free(_big);
    // 4. everything the frame-by-frame draw needs, in OUTPUT pixels
    _s.menu_region = { x: _rx / _k, y: _ry / _k, w: _rw / _k, h: _rh / _k };
    _s.rows = [];
    for (var _r = 0; _r < _n; _r++) array_push(_s.rows, { x: _rects[_r].x / _k, y: _rects[_r].y / _k, w: _rects[_r].w / _k, h: _rects[_r].h / _k });
    var _gm = _rep.geom, _pan = _gm.panel, _cols = [];
    var _t = _rep2.title, _boxes = is_struct(_t) ? _t.boxes : [];
    var _y0 = (_pan.y - _pan.h * 0.08) / _k, _y1 = (_pan.y + _pan.h * 1.08) / _k;
    if (is_struct(_t) && is_struct(_t[$ "sub_rect"])) _y1 = min(_y1, _t.sub_rect.y / _k);
    for (var _g = 0; _g < array_length(_boxes); _g++) {
        var _a = (_g == 0) ? (_pan.x - _pan.w * 0.02) / _k : _boxes[_g][0] / _k;
        var _b = (_g == array_length(_boxes) - 1) ? (_pan.x + _pan.w * 1.02) / _k : _boxes[_g + 1][0] / _k;
        array_push(_cols, { x: max(0, floor(_a)), y: max(0, floor(_y0)), w: max(1, ceil(_b) - max(0, floor(_a))), h: max(1, ceil(_y1) - max(0, floor(_y0))) });
    }
    _s.columns = _cols;
    _s.sub_rect = (is_struct(_t) && is_struct(_t[$ "sub_rect"])) ? { x: floor(_t.sub_rect.x / _k), y: floor(_t.sub_rect.y / _k), w: ceil(_t.sub_rect.w / _k) + 1, h: ceil(_t.sub_rect.h / _k) + 1 } : undefined;
    var _v = _L.vignette;
    _s.vig_rect = { x: floor(max(0, _v.x - _v.w * 0.10) / _k), y: floor(max(0, _v.y - _v.h * 0.05) / _k), w: ceil(_v.w * 1.20 / _k), h: ceil(_v.h * 1.10 / _k) };
    _s.spark = fsp_col(fsp_relief(_gm.face, 1, 110));
    _s.report = { house: _s.spec.house, house_why: _s.spec.house_why, ground: _s.spec.ground, frame: _s.spec.frame, cartouche: _s.spec.cartouche,
        hand: _s.spec.hand, cut: _s.spec.cut, vignette: _s.spec.vignette, menu: _s.spec.menu, ornaments: _s.spec.ornaments, ornament_why: _s.spec.ornament_why,
        cap_h: is_struct(_t) ? _t.cap_h / _k : 0, glyphs: is_struct(_t) ? _t.glyphs : 0, fallback: is_struct(_t) ? _t.fallback : false,
        coverage: is_struct(_t) ? _t.coverage : 0, missing: is_struct(_t) ? _t.missing : [], subtitle_fits: is_struct(_t) ? _t.subtitle_fits : true,
        vignette_units: _rep2.vignette_units, imprint: _rep.imprint, rows: _n };
    _s.t = _s.reveal ? 0 : fsp__reveal_end(_s);
    _s.prev = -1; _s.fade = 1;
    _s.build_ms = (get_timer() - _t0) / 1000;
    return _s.build_ms;
}

/// @function fsp__free_sprites(screen)
/// @description Delete every sprite a screen owns. Internal.
function fsp__free_sprites(_s) {
    if (sprite_exists(_s.spr_base)) sprite_delete(_s.spr_base);
    if (sprite_exists(_s.spr_full)) sprite_delete(_s.spr_full);
    for (var _i = 0; _i < array_length(_s.spr_menu); _i++) if (sprite_exists(_s.spr_menu[_i])) sprite_delete(_s.spr_menu[_i]);
    _s.spr_base = -1; _s.spr_full = -1; _s.spr_menu = [];
}

/// @function fsp__reveal_end(screen)
/// @description The frame on which the reveal is complete. Internal, pure.
function fsp__reveal_end(_s) {
    var _g = array_length(_s.columns);
    return 16 + max(1, _g) * FSP_GLYPH_FRAMES * 0.6 + FSP_GLYPH_FRAMES + 40 + array_length(_s.rows) * 6 + 16;
}

/// @function fsp__timeline(screen)
/// @description Where each part of the reveal is at frame t, 0..1: {glyph: [...], subtitle, vignette, rows: [...]}.
/// Pure - the draw reads it and the suite asserts it.
function fsp__timeline(_s) {
    var _t = _s.t, _ng = array_length(_s.columns), _gl = array_create(_ng, 1);
    var _tg = 16;
    for (var _i = 0; _i < _ng; _i++) _gl[_i] = clamp((_t - _tg - _i * FSP_GLYPH_FRAMES * 0.6) / FSP_GLYPH_FRAMES, 0, 1);
    var _tend = _tg + max(1, _ng) * FSP_GLYPH_FRAMES * 0.6 + FSP_GLYPH_FRAMES;
    var _rows = array_create(array_length(_s.rows), 1);
    for (var _r = 0; _r < array_length(_rows); _r++) _rows[_r] = clamp((_t - _tend - 14 - _r * 6) / 16, 0, 1);
    return { glyph: _gl, subtitle: clamp((_t - _tend) / 20, 0, 1), vignette: clamp((_t - _tend + 4) / 36, 0, 1), rows: _rows, base: clamp(_t / 16, 0, 1) };
}

/// @function fsp_screen_step(screen)
/// @description Advance the reveal and any row transition by one frame. Call once per Step.
function fsp_screen_step(_s) {
    if (!is_struct(_s)) return;
    _s.t += 1;
    if (_s.fade < 1) _s.fade = min(1, _s.fade + 1 / FSP_FADE_FRAMES);
}

/// @function fsp_screen_revealed(screen)
/// @description True once the whole screen has come up.
function fsp_screen_revealed(_s) { return is_struct(_s) && _s.t >= fsp__reveal_end(_s); }

/// @function fsp_screen_skip(screen)
/// @description Finish the reveal at once (for a player who presses a key while it runs).
function fsp_screen_skip(_s) { if (is_struct(_s)) _s.t = max(_s.t, fsp__reveal_end(_s)); }

/// @function fsp_screen_draw(screen, x, y)
/// @description Draw the screen with its top-left at (x, y). A handful of sprite draws a frame; nothing is redrawn.
function fsp_screen_draw(_s, _x, _y) {
    if (!is_struct(_s) || !variable_struct_exists(_s, "spr_base") || !sprite_exists(_s.spr_base) || !is_numeric(_x) || !is_numeric(_y)) return;
    var _pt = gpu_get_texfilter();
    gpu_set_texfilter(false);
    if (fsp_screen_revealed(_s)) {
        draw_sprite(_s.spr_full, 0, _x, _y);
        fsp__draw_menu(_s, _x, _y, undefined);
        gpu_set_texfilter(_pt);
        return;
    }
    var _tl = fsp__timeline(_s), _i;
    draw_sprite_ext(_s.spr_base, 0, _x, _y, 1, 1, 0, c_white, _tl.base);
    for (_i = 0; _i < array_length(_s.columns); _i++) {
        var _p = _tl.glyph[_i], _c = _s.columns[_i];
        if (_p <= 0) continue;
        var _pw = max(1, round(_c.w * _p));
        draw_sprite_part(_s.spr_full, 0, _c.x, _c.y, _pw, _c.h, _x + _c.x, _y + _c.y);
        if (_p < 1) {
            // the cutting edge: a short-lived light where the chisel is
            gpu_set_blendmode(bm_add);
            fsp_seg(_x + _c.x + _pw, _y + _c.y + _c.h * 0.12, _x + _c.x + _pw, _y + _c.y + _c.h * 0.88, 2, _s.spark, 0.55 * (1 - _p));
            gpu_set_blendmode(bm_normal);
        }
    }
    if (is_struct(_s.sub_rect) && _tl.subtitle > 0) draw_sprite_part_ext(_s.spr_full, 0, _s.sub_rect.x, _s.sub_rect.y, _s.sub_rect.w, _s.sub_rect.h, _x + _s.sub_rect.x, _y + _s.sub_rect.y, 1, 1, c_white, _tl.subtitle);
    if (_tl.vignette > 0) draw_sprite_part_ext(_s.spr_full, 0, _s.vig_rect.x, _s.vig_rect.y, _s.vig_rect.w, _s.vig_rect.h, _x + _s.vig_rect.x, _y + _s.vig_rect.y, 1, 1, c_white, _tl.vignette);
    fsp__draw_menu(_s, _x, _y, _tl.rows);
    gpu_set_texfilter(_pt);
}

/// @function fsp__draw_menu(screen, x, y, rows)
/// @description The menu: the chosen row's sprite, crossfaded from the previous one; during the reveal each row rises
/// in on its own. Internal.
function fsp__draw_menu(_s, _x, _y, _rows) {
    var _n = array_length(_s.spr_menu);
    if (_n == 0) return;
    var _m = _s.menu_region, _cur = _s.spr_menu[clamp(_s.index, 0, _n - 1)];
    if (is_array(_rows)) {
        for (var _r = 0; _r < array_length(_s.rows); _r++) {
            var _a = _rows[_r];
            if (_a <= 0) continue;
            var _rw = _s.rows[_r], _pad = _rw.h * 0.40;
            var _lx = max(0, _rw.x - _m.x - _m.w * 0.2), _ly = max(0, _rw.y - _m.y - _pad);
            var _lw = min(_m.w - _lx, _rw.w + _m.w * 0.4), _lh = min(_m.h - _ly, _rw.h + _pad * 2);
            draw_sprite_part_ext(_cur, 0, _lx, _ly, _lw, _lh, _x + _m.x + _lx, _y + _m.y + _ly + (1 - _a) * 10, 1, 1, c_white, _a);
        }
        return;
    }
    if (_s.fade < 1 && _s.prev >= 0 && _s.prev < _n) {
        draw_sprite(_s.spr_menu[_s.prev], 0, _x + _m.x, _y + _m.y);
        draw_sprite_ext(_cur, 0, _x + _m.x, _y + _m.y, 1, 1, 0, c_white, _s.fade);
    } else draw_sprite(_cur, 0, _x + _m.x, _y + _m.y);
}

/// @function fsp_screen_select(screen, row)
/// @description Choose row `row` (starting the crossfade). A disabled row cannot be chosen. Returns true when it moved.
function fsp_screen_select(_s, _row) {
    if (!is_struct(_s) || !is_real(_row)) return false;
    _row = floor(_row);
    if (_row < 0 || _row >= array_length(_s.commands) || _row == _s.index || !_s.enabled[_row]) return false;
    _s.prev = _s.index; _s.index = _row; _s.fade = 0;
    return true;
}

/// @function fsp_screen_move(screen, delta)
/// @description Move the choice up (-1) or down (+1), skipping disabled rows and wrapping. Returns the new index.
function fsp_screen_move(_s, _delta) {
    if (!is_struct(_s) || !is_real(_delta) || _delta == 0) return is_struct(_s) ? _s.index : -1;
    var _n = array_length(_s.commands), _d = sign(_delta), _j = _s.index;
    for (var _i = 0; _i < _n; _i++) {
        _j = ((_j + _d) mod _n + _n) mod _n;
        if (_s.enabled[_j]) { fsp_screen_select(_s, _j); break; }
    }
    return _s.index;
}

/// @function fsp_screen_row_at(screen, x, y)
/// @description The menu row under a point in screen coordinates (as passed to fsp_screen_draw at 0, 0), or -1. Pure.
function fsp_screen_row_at(_s, _px, _py) {
    if (!is_struct(_s) || !is_real(_px) || !is_real(_py)) return -1;
    for (var _i = 0; _i < array_length(_s.rows); _i++) {
        var _r = _s.rows[_i];
        if (_px >= _r.x && _px < _r.x + _r.w && _py >= _r.y && _py < _r.y + _r.h) return _i;
    }
    return -1;
}

/// @function fsp_screen_hover(screen, x, y)
/// @description Choose whichever enabled row the mouse is over (call every Step with the GUI mouse position). Only
/// ever moves the choice when the pointer is ON a row, so a player on the keyboard is never fought by a resting mouse.
/// Returns the row under the pointer or -1.
function fsp_screen_hover(_s, _px, _py) {
    var _r = fsp_screen_row_at(_s, _px, _py);
    if (!is_struct(_s)) return -1;
    if (_r >= 0 && (!variable_struct_exists(_s, "last_hover") || _s.last_hover != _r)) fsp_screen_select(_s, _r);
    _s.last_hover = _r;
    return _r;
}

/// @function fsp_screen_confirm(screen)
/// @description The chosen row's index - or -1 while the reveal is still running (the first press finishes it
/// instead) or when the chosen row is disabled.
function fsp_screen_confirm(_s) {
    if (!is_struct(_s)) return -1;
    if (!fsp_screen_revealed(_s)) { fsp_screen_skip(_s); return -1; }
    if (_s.index < 0 || _s.index >= array_length(_s.commands) || !_s.enabled[_s.index]) return -1;
    return _s.index;
}

/// @function fsp_screen_index(screen)
/// @description The chosen row. Pure.
function fsp_screen_index(_s) { return is_struct(_s) ? _s.index : -1; }

/// @function fsp_screen_set_enabled(screen, row, enabled)
/// @description Enable or disable one row and rebuild the menu (a disabled row is drawn greyed). If the chosen row is
/// disabled the choice moves to the next enabled one.
function fsp_screen_set_enabled(_s, _row, _on) {
    if (!is_struct(_s) || !is_real(_row) || _row < 0 || _row >= array_length(_s.commands)) return false;
    _s.enabled[floor(_row)] = (_on != false);
    _s.index = fsp__first_enabled(_s, _s.index);
    fsp_screen_rebuild(_s);
    return true;
}

/// @function fsp_screen_set_house(screen, house, [subtitle])
/// @description Change the whole look (e.g. after a chapter ends) and rebuild. `house` is an id or "auto". Returns
/// false for an unknown house (nothing changes).
function fsp_screen_set_house(_s, _house, _subtitle = undefined) {
    if (!is_struct(_s) || !is_string(_house)) return false;
    if (_house != "auto" && !is_struct(fsp_find(fsp_houses(), _house))) return false;
    _s.options.house = _house;
    if (is_string(_subtitle)) _s.subtitle = _subtitle;
    _s.spec = fsp_compose(_s.title, _s.options);
    fsp_screen_rebuild(_s);
    return true;
}

/// @function fsp_screen_free(screen)
/// @description Delete the screen's sprites. Call from Clean Up.
function fsp_screen_free(_s) { if (is_struct(_s)) fsp__free_sprites(_s); }
