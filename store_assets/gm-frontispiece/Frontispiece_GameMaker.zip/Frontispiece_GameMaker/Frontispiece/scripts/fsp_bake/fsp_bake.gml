/// fsp_bake.gml - renders the store sheets THROUGH THE PRODUCT'S OWN DRAW CODE (`Frontispiece.exe -bake`, `-gif`), so
/// the listing can truthfully say every image on the page was drawn by the thing being sold. Not needed at runtime: a
/// buyer may delete this script with the -bake/-gif branches of the demo object's Create event.
///
/// Frontispiece - The Title Screen, Generated, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
/// ⛔ NOTHING IN THIS FILE CAN SEE A PICTURE. The ink box catches a CLIPPED or EMPTY sheet and nothing else.

/// @function fsp_bake_page()
function fsp_bake_page() { return make_colour_rgb(18, 16, 19); }

/// @function fsp_bake_ink(surface, w, h, ground)
/// @description The ink bounding box and sample count of a finished sheet: every row, every second column.
function fsp_bake_ink(_sf, _w, _h, _ground) {
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    var _x0 = _w, _y0 = _h, _x1 = -1, _y1 = -1, _n = 0;
    var _gr = colour_get_red(_ground), _gg = colour_get_green(_ground), _gb = colour_get_blue(_ground);
    for (var _y = 0; _y < _h; _y++) for (var _x = 0; _x < _w; _x += 2) {
        var _o = (_y * _w + _x) * 4;
        if (abs(buffer_peek(_b, _o + 2, buffer_u8) - _gr) > 10 || abs(buffer_peek(_b, _o + 1, buffer_u8) - _gg) > 10 || abs(buffer_peek(_b, _o, buffer_u8) - _gb) > 10) {
            _n++; if (_x < _x0) _x0 = _x; if (_x > _x1) _x1 = _x; if (_y < _y0) _y0 = _y; if (_y > _y1) _y1 = _y;
        }
    }
    buffer_delete(_b);
    return { x0: _x0, y0: _y0, x1: _x1, y1: _y1, px: _n };
}

/// @function fsp_bake_sheet(name, w, h, fn)
/// @description Render a sheet at 2x (fn(w2, h2, k) draws into it), filter it down, measure its ink, save it, log it.
function fsp_bake_sheet(_name, _w, _h, _fn) {
    var _k = 2, _big = surface_create(_w * _k, _h * _k);
    surface_set_target(_big); draw_clear_alpha(fsp_bake_page(), 1); _fn(_w * _k, _h * _k, _k); fsp__opaque(_w * _k, _h * _k); surface_reset_target();
    var _sf = fsp__downsample(_big, 0, 0, _w * _k, _h * _k, _k);
    surface_free(_big);
    var _ink = fsp_bake_ink(_sf, _w, _h, fsp_bake_page());
    surface_save(_sf, "fsp_sheet_" + _name + ".png");
    surface_free(_sf);
    array_push(global.fsp_bake_log, { sheet: _name, w: _w, h: _h, px: _ink.px, x0: _ink.x0, y0: _ink.y0, x1: _ink.x1, y1: _ink.y1 });
}

/// @function fsp_bake_head(w, title, sub, k)
/// @description A sheet's heading and one line under it. Returns the y below them.
function fsp_bake_head(_w, _title, _sub, _k) {
    fsp_text(_w * 0.5, 20 * _k, _title, 44 * _k, make_colour_rgb(236, 226, 206), fa_center, fa_top, fnt_frontispiece_title);
    fsp_text(_w * 0.5, 72 * _k, _sub, 21 * _k, make_colour_rgb(176, 164, 146), fa_center, fa_top, fnt_frontispiece);
    return 112 * _k;
}

/// @function fsp_bake_label(x, y, text, px, k, [colour], [halign])
function fsp_bake_label(_x, _y, _s, _px, _k, _col = make_colour_rgb(210, 198, 176), _ha = fa_center) {
    return fsp_text(_x, _y, _s, _px * _k, _col, _ha, fa_top, fnt_frontispiece);
}

/// @function fsp_bake_wrap(text, px, maxw)
/// @description Break text into lines no wider than maxw at px (words are never split; a single over-long word gets a
/// line of its own). Returns an array of strings.
function fsp_bake_wrap(_s, _px, _maxw) {
    var _words = string_split(string(_s), " "), _out = [], _cur = "";
    for (var _i = 0; _i < array_length(_words); _i++) {
        var _try = (_cur == "") ? _words[_i] : _cur + " " + _words[_i];
        if (_cur != "" && fsp_text_w(_try, _px) > _maxw) { array_push(_out, _cur); _cur = _words[_i]; } else _cur = _try;
    }
    if (_cur != "") array_push(_out, _cur);
    return _out;
}

/// @function fsp_bake_game(house)
/// @description The sample game shown for each house. Pure.
function fsp_bake_game(_house) {
    var _T = fsp_demo_titles();
    switch (_house) {
        case "hall": return _T[0];
        case "sanctum": return _T[1];
        case "folio": return _T[2];
        case "foundry": return _T[3];
        case "vigil": return _T[4];
        default: return _T[5];
    }
}

/// @function fsp_bake_screen(house, w, h, [index])
/// @description A finished screen for a house's sample game at w x h, built by fsp_screen_create. Caller frees it.
function fsp_bake_screen(_house, _w, _h, _index = 0) {
    var _g = fsp_bake_game(_house);
    return fsp_screen_create(_g.title, { house: _house, words: _g.words, subtitle: _g.subtitle, imprint: "CORE SYSTEMS ASSET FACTORY",
        commands: ["New Game", "Continue", "Options", "Quit"], enabled: [true, false, true, true], index: _index, width: _w, height: _h, reveal: false });
}

/// @function fsp_bake_shot(screen)
/// @description The screen EXACTLY as a buyer's Draw GUI shows it - fsp_screen_draw at 1x into a surface of the
/// screen's own size - returned as a surface (caller frees it). ⛔ The store sheets used to draw the screen's sprites
/// straight into the 2x sheet surface, from a screen BUILT while that sheet was the render target: all six 1600 x 900
/// heroes came out with the menu as a solid WHITE box, while a size sweep of the buyer's own path (640 to 1920 wide)
/// measured 0% white. So every sheet is now a photograph of the buyer's path, built before any sheet target is set.
function fsp_bake_shot(_s) {
    var _sf = surface_create(_s.w, _s.h);
    surface_set_target(_sf); draw_clear_alpha(c_black, 1); fsp_screen_draw(_s, 0, 0); fsp__opaque(_s.w, _s.h); surface_reset_target();
    array_push(global.fsp_bake_diag, { house: _s.report.house, w: _s.w, h: _s.h, white: fsp_bake_white(_sf, _s.menu_region) });
    return _sf;
}

/// @function fsp_bake_draw_shot(surface, x, y, k)
/// @description Place a shot on a 2x sheet: every screen pixel becomes a k x k block, which the sheet's own filter-down
/// returns to exactly the screen's pixels.
function fsp_bake_draw_shot(_sf, _x, _y, _k) {
    var _pt = gpu_get_texfilter();
    gpu_set_texfilter(false);
    draw_surface_ext(_sf, _x, _y, _k, _k, 0, c_white, 1);
    gpu_set_texfilter(_pt);
}

/// @function fsp_bake_hero(house)
/// @description A sheet that is one whole screen, 1600 x 900, for one house - built and photographed FIRST.
function fsp_bake_hero(_house) {
    var _s = fsp_bake_screen(_house, 1600, 900, 0);
    var _shot = fsp_bake_shot(_s);
    fsp_screen_free(_s);
    fsp_bake_sheet("screen_" + _house, 1600, 900, method({ shot: _shot }, function(_w, _h, _k) { fsp_bake_draw_shot(shot, 0, 0, _k); }));
    surface_free(_shot);
}

/// @function fsp_bake_houses_cells(w, h, k)
/// @description Where the six screens sit on the houses sheet (sheet pixels at scale k): {top, cw, chh, cells}.
function fsp_bake_houses_cells(_w, _h, _k) {
    var _top = 112 * _k, _pad = 26 * _k, _cw = (_w - _pad * 4) / 3, _chh = _cw * 9 / 16, _cap = 44 * _k;
    var _y0 = _top + ((_h - _top) - 2 * (_chh + _cap) - _pad) * 0.5, _cells = [];
    for (var _i = 0; _i < 6; _i++) array_push(_cells, { x: _pad + (_i mod 3) * (_cw + _pad), y: _y0 + (_i div 3) * (_chh + _cap + _pad) });
    return { top: _top, cw: _cw, chh: _chh, cells: _cells };
}

/// @function fsp_bake_houses_sheet(w, h)
/// @description SIX HOUSES, SIX SCREENS: every house built for its own sample game and photographed through the
/// buyer's path BEFORE the sheet is opened, then captioned by what it is made of.
function fsp_bake_houses_sheet(_w, _h) {
    var _k = 2, _L = fsp_bake_houses_cells(_w * _k, _h * _k, _k), _H = fsp_houses(), _shots = [];
    for (var _i = 0; _i < 6; _i++) {
        var _s = fsp_bake_screen(_H[_i].id, round(_L.cw / _k), round(_L.chh / _k), 0);
        array_push(_shots, fsp_bake_shot(_s));
        fsp_screen_free(_s);
    }
    fsp_bake_sheet("houses", _w, _h, method({ shots: _shots }, function(_w2, _h2, _k2) {
        fsp_bake_head(_w2, "SIX HOUSES, SIX SCREENS", "Each house is a whole construction - ground, border, cartouche, hand, cut, device and menu - not a colour scheme.", _k2);
        var _L2 = fsp_bake_houses_cells(_w2, _h2, _k2), _H2 = fsp_houses();
        for (var _j = 0; _j < 6; _j++) {
            var _c = _L2.cells[_j];
            fsp_bake_draw_shot(shots[_j], _c.x, _c.y, _k2);
            fsp_bake_label(_c.x + _L2.cw * 0.5, _c.y + _L2.chh + 8 * _k2, string_upper(_H2[_j].label) + "  -  " + _H2[_j].ground + ", " + _H2[_j].cartouche + ", " + _H2[_j].hand + ", " + _H2[_j].cut, 17, _k2);
        }
    }));
    for (var _f = 0; _f < 6; _f++) surface_free(_shots[_f]);
}

/// @function fsp_bake_alphabet(w, h, k)
/// @description THE LETTERING: five hands, each cutting the whole alphabet and the figures from the same skeletons.
function fsp_bake_alphabet(_w, _h, _k) {
    var _vol = fsp_alpha_volume();
    var _top = fsp_bake_head(_w, string(_vol.total) + " SKELETONS, FIVE HANDS, ONE PEN",
        "Every letter is drawn stroke by stroke and CUT through a broad-nib simulation - " + string(_vol.glyphs) + " glyphs, no font file.", _k);
    var _ids = fsp_alpha_hand_ids(), _pad = 28 * _k, _rowh = (_h - _top - _pad) / 5;
    var _ground = [214, 204, 180], _ink = [48, 30, 24];
    for (var _i = 0; _i < 5; _i++) {
        var _h1 = fsp_alpha_hand(_ids[_i]), _y = _top + _i * _rowh;
        var _box = { x: _pad, y: _y + 6 * _k, w: _w - 2 * _pad, h: _rowh - 12 * _k };
        fsp_rect_grad(_box.x, _box.y, _box.w, _box.h, _box.x, _box.y, _box.x, _box.y + _box.h, fsp_stops2(fsp_col(_ground), fsp_col(fsp_mix(_ground, [180, 166, 138], 0.6))));
        fsp_text(_box.x + 22 * _k, _box.y + 14 * _k, string_upper(_h1.label), 24 * _k, fsp_col([110, 40, 32]), fa_left, fa_top, fnt_frontispiece);
        // the note WRAPS inside its column: set on one line it ran under the letter row and was overprinted by the A
        var _lines = fsp_bake_wrap(_h1.note, 16 * _k, 214 * _k);
        for (var _ln = 0; _ln < array_length(_lines); _ln++) fsp_text(_box.x + 22 * _k, _box.y + (46 + _ln * 20) * _k, _lines[_ln], 16 * _k, fsp_col([96, 80, 64]), fa_left, fa_top, fnt_frontispiece);
        var _lx = _box.x + 250 * _k, _lw = _box.w - 250 * _k - 24 * _k;
        var _line = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        var _f = fsp_alpha_fit(_line, _ids[_i], _lw, _box.h * 0.42, 8 * _k);
        fsp_alpha_draw_line(_line, { x: _lx, base_y: _box.y + _box.h * 0.52, cap_h: _f.cap_h, hand: _ids[_i], cut: "printed", ground: _ground, ink: _ink });
        var _l2 = "0123456789 & ! ? ( ) : - /";
        var _f2 = fsp_alpha_fit(_l2, _ids[_i], _lw * 0.62, _box.h * 0.26, 8 * _k);
        fsp_alpha_draw_line(_l2, { x: _lx, base_y: _box.y + _box.h * 0.90, cap_h: _f2.cap_h, hand: _ids[_i], cut: "printed", ground: _ground, ink: [110, 40, 32] });
    }
}

/// @function fsp_bake_cell_ground(ground_id, box, k, seed)
/// @description Work a ground material into any box (the same function the screen uses), framed by a thin shadow.
function fsp_bake_cell_ground(_gid, _box, _k, _seed) {
    fsp_plate_ground({ ground: _gid, seed: _seed }, _box, _k);
    fsp_rect_stroke(_box.x, _box.y, _box.w, _box.h, _k, c_black, 0.5);
}

/// @function fsp_bake_cuts(w, h, k)
/// @description FOUR CUTS: how a letter meets its material - on a dark ground and a light one.
function fsp_bake_cuts(_w, _h, _k) {
    var _top = fsp_bake_head(_w, "FOUR CUTS, SOLVED FOR THE GROUND", "Incised, raised, inlaid, printed - each solves an ABSOLUTE separation, so the same cut reads on slate and on vellum.", _k);
    var _cuts = fsp_alpha_cut_ids(), _grounds = ["slate", "vellum"], _inks = [[214, 176, 92], [120, 36, 30]];
    var _pad = 24 * _k, _cw = (_w - _pad * 5) / 4, _ch = (_h - _top - _pad * 3) / 2;
    for (var _r = 0; _r < 2; _r++) for (var _c = 0; _c < 4; _c++) {
        var _box = { x: _pad + _c * (_cw + _pad), y: _top + _pad * 0.5 + _r * (_ch + _pad), w: _cw, h: _ch };
        var _g = fsp_find(fsp_grounds(), _grounds[_r]);
        fsp_bake_cell_ground(_grounds[_r], _box, _k, 7 + _r * 13 + _c);
        var _word = "ARDEN";
        var _f = fsp_alpha_fit(_word, "lapidary", _box.w * 0.82, _box.h * 0.36, 8 * _k);
        var _ww = fsp_alpha_measure(_word, "lapidary", _f.cap_h);
        fsp_alpha_draw_line(_word, { x: _box.x + (_box.w - _ww) * 0.5, base_y: _box.y + _box.h * 0.56, cap_h: _f.cap_h, hand: "lapidary", cut: _cuts[_c], ground: _g.base, ink: _inks[_r], delta: 64 });
        var _lc = fsp_col(fsp_separate([236, 226, 206], _g.base, 90));
        fsp_text(_box.x + _box.w * 0.5, _box.y + _box.h * 0.74, string_upper(_cuts[_c]), 22 * _k, _lc, fa_center, fa_top, fnt_frontispiece);
        fsp_text(_box.x + _box.w * 0.5, _box.y + _box.h * 0.74 + 30 * _k, "on " + string_lower(_g.label), 16 * _k, _lc, fa_center, fa_top, fnt_frontispiece);
    }
}

/// @function fsp_bake_grounds(w, h, k)
/// @description EIGHT GROUNDS, WORKED AS MATERIALS: every surface a screen can be made of, its name cut into it.
function fsp_bake_grounds(_w, _h, _k) {
    var _top = fsp_bake_head(_w, "EIGHT GROUNDS, WORKED AS MATERIALS", "A title screen is mostly ground. Pores, cleavage, planishing, crazing, weave, grain and brush - every surface is worked.", _k);
    var _G = fsp_grounds(), _pad = 22 * _k, _cw = (_w - _pad * 3) / 2, _ch = (_h - _top - _pad * 4.5) / 4;
    for (var _i = 0; _i < 8; _i++) {
        var _box = { x: _pad + (_i mod 2) * (_cw + _pad), y: _top + _pad * 0.5 + (_i div 2) * (_ch + _pad), w: _cw, h: _ch };
        var _g = _G[_i];
        fsp_bake_cell_ground(_g.id, _box, _k, 31 + _i);
        var _name = string_upper(_g.label);
        var _f = fsp_alpha_fit(_name, "lapidary", _box.w * 0.86, _box.h * 0.40, 8 * _k);
        fsp_alpha_draw_line(_name, { x: _box.x + 26 * _k, base_y: _box.y + _box.h * 0.58, cap_h: _f.cap_h, hand: "lapidary", cut: "incised", ground: _g.base, delta: 64 });
        fsp_text(_box.x + 28 * _k, _box.y + _box.h * 0.70, _g.note, 16 * _k, fsp_col(fsp_separate([236, 226, 206], _g.base, 110)), fa_left, fa_top, fnt_frontispiece);
    }
}

/// @function fsp_bake_ornaments(w, h, k)
/// @description TWELVE FLEURONS AND SIX DEVICES: the units, then how a house arranges them.
function fsp_bake_ornaments(_w, _h, _k) {
    var _top = fsp_bake_head(_w, "TWELVE FLEURONS, SIX DEVICES", "Built from a CONSTRUCTION - lobes on a stem or about a centre - never a traced outline. Your game's words choose them.", _k);
    var _O = fsp_ornaments(), _pad = 22 * _k, _band = (_h - _top) * 0.40;
    var _g = fsp_find(fsp_grounds(), "leather"), _box = { x: _pad, y: _top, w: _w - 2 * _pad, h: _band };
    fsp_bake_cell_ground("leather", _box, _k, 5);
    var _lit = fsp_separate([214, 176, 92], _g.base, 54), _dark = fsp_relief(_g.base, -1, 46), _cw = _box.w / 6, _i;
    for (_i = 0; _i < 12; _i++) {
        var _cx = _box.x + ((_i mod 6) + 0.5) * _cw, _cy = _box.y + ((_i div 6) + 0.44) * (_box.h / 2);
        fsp_plate_ornament(_O[_i].id, _cx, _cy, _box.h * 0.17, 0, _lit, _dark, _k);
        fsp_text(_cx, _cy + _box.h * 0.20, string_upper(_O[_i].label), 14 * _k, fsp_col(fsp_separate([230, 214, 180], _g.base, 110)), fa_center, fa_top, fnt_frontispiece);
    }
    var _H = fsp_houses(), _vy = _top + _band + _pad, _vh = (_h - _vy - _pad * 2) / 2, _vw = (_w - _pad * 4) / 3;
    for (_i = 0; _i < 6; _i++) {
        var _vb = { x: _pad + (_i mod 3) * (_vw + _pad), y: _vy + (_i div 3) * (_vh + _pad), w: _vw, h: _vh };
        var _hs = _H[_i];
        fsp_bake_cell_ground(_hs.ground, _vb, _k, 71 + _i);
        var _spec = fsp_compose(fsp_bake_game(_hs.id).title, { house: _hs.id, words: fsp_bake_game(_hs.id).words });
        var _L = { vignette: { x: _vb.x + _vb.w * 0.08, y: _vb.y + _vb.h * 0.08, w: _vb.w * 0.84, h: _vb.h * 0.70 } };
        fsp_plate_vignette(_spec, _L, _k);
        var _gg = fsp_find(fsp_grounds(), _hs.ground);
        fsp_text(_vb.x + _vb.w * 0.5, _vb.y + _vb.h * 0.82, string_upper(fsp_find(fsp_vignettes(), _hs.vignette).label) + " OF " + string_upper(_spec.ornaments[0]), 15 * _k,
            fsp_col(fsp_separate([236, 226, 206], _gg.base, 110)), fa_center, fa_top, fnt_frontispiece);
    }
}

/// @function fsp_bake_menus(w, h, k)
/// @description SIX MENUS, NO STOCK WINDOW: every treatment with its chosen row and a disabled one.
function fsp_bake_menus(_w, _h, _k) {
    var _top = fsp_bake_head(_w, "SIX MENUS, NONE OF THEM A WINDOW", "The command list is the house's own furniture. The chosen row lifts, deepens or runs out; a row you disable is drawn greyed.", _k);
    // 2 x 3, the menu left and its name and behaviour right: as a 3 x 2 grid of centred menus this sheet hashed d=4
    // against the houses sheet (the same silhouette to a buyer scanning the gallery strip)
    var _H = fsp_houses(), _pad = 24 * _k, _cw = (_w - _pad * 3) / 2, _ch = (_h - _top - _pad * 3.5) / 3;
    for (var _i = 0; _i < 6; _i++) {
        var _box = { x: _pad + (_i mod 2) * (_cw + _pad), y: _top + _pad * 0.5 + (_i div 2) * (_ch + _pad), w: _cw, h: _ch };
        var _hs = _H[_i], _g = fsp_find(fsp_grounds(), _hs.ground), _mt = fsp_find(fsp_menus(), _hs.menu);
        fsp_bake_cell_ground(_hs.ground, _box, _k, 91 + _i);
        var _spec = fsp_compose("Menu", { house: _hs.id });
        var _L = { menu: { x: _box.x + _box.w * 0.07, y: _box.y + _box.h * 0.11, w: _box.w * 0.50, h: _box.h * 0.78 } };
        fsp_plate_menu(_spec, _L, ["New Game", "Continue", "Options", "Quit"], [true, false, true, true], 0, _k);
        var _lc = fsp_col(fsp_separate([236, 226, 206], _g.base, 110));
        var _tx = _box.x + _box.w * 0.795, _lines = fsp_bake_wrap(_mt.note, 15 * _k, _box.w * 0.34);
        var _ty = _box.y + _box.h * 0.5 - (30 + array_length(_lines) * 19) * _k * 0.5;
        fsp_text(_tx, _ty, string_upper(_mt.label), 21 * _k, _lc, fa_center, fa_top, fnt_frontispiece);
        for (var _ln = 0; _ln < array_length(_lines); _ln++) fsp_text(_tx, _ty + (30 + _ln * 19) * _k, _lines[_ln], 15 * _k, _lc, fa_center, fa_top, fnt_frontispiece);
    }
}

/// @function fsp_bake_cover()
/// @description The store COVER, 630 x 500: the product cutting its own name. A title PLATE, not a screen - no menu -
/// in the Folio house's leather and dentil border with the lapidary hand inlaid in gold, a device read from the words
/// "gold, star, craft", the subtitle in the cartouche, and two lines where a game's menu would stand.
function fsp_bake_cover() {
    fsp_bake_sheet("cover", 630, 500, function(_w, _h, _k) {
        var _box = { x: 0, y: 0, w: _w, h: _h };
        var _spec = fsp_compose("Frontispiece", { house: "folio", hand: "lapidary", cut: "inlaid", vignette: "band", words: ["gold", "star", "craft"] });
        // the device in GOLD, star and quatrefoil: the house's dark red with its small bud read as dull specks on the
        // leather at thumbnail size (first cover bake, looked at 2026-09-27)
        _spec.accent = [214, 176, 92];
        _spec.ornaments = ["star", "quatrefoil", "knot"];
        var _st = { subtitle: "The Title Screen, Generated" };
        var _L = fsp_plate_layout(_box, _spec, _st, _k);
        // the title takes the room a menu would: a taller cartouche, the device under it, two lines of type at the foot
        var _wk = _L.work;
        _L.title = { x: _wk.x, y: _wk.y + _wk.h * 0.04, w: _wk.w, h: _wk.h * 0.50 };
        _L.vignette = { x: _wk.x + _wk.w * 0.18, y: _wk.y + _wk.h * 0.57, w: _wk.w * 0.64, h: _wk.h * 0.16 };
        var _gm = fsp_plate_title_geom(_spec, _L, _st, _k);
        fsp_plate_ground(_spec, _box, _k);
        fsp_plate_frame(_spec, _L, _k);
        fsp_plate_panel(_spec, _gm, _k);
        fsp_plate_letters(_spec, _gm, _k, fnt_frontispiece_title);
        fsp_plate_vignette(_spec, _L, _k);
        var _g = fsp_find(fsp_grounds(), _spec.ground);
        var _gold = fsp_col(fsp_separate([214, 176, 92], _g.base, 96)), _pale = fsp_col(fsp_separate([236, 226, 206], _g.base, 110));
        fsp_text(_w * 0.5, _wk.y + _wk.h * 0.78, "FOR GAMEMAKER", 30 * _k, _gold, fa_center, fa_top, fnt_frontispiece_title);
        fsp_text(_w * 0.5, _wk.y + _wk.h * 0.90, "every mark drawn in pure GML  -  no image files", 15 * _k, _pale, fa_center, fa_top, fnt_frontispiece);
    });
}

/// @function fsp_bake_white(surface, rect)
/// @description How many pixels of `rect` on a surface are pure white - the signature of a sprite drawn with no texture.
function fsp_bake_white(_sf, _r) {
    var _w = surface_get_width(_sf), _h = surface_get_height(_sf), _b = buffer_create(_w * _h * 4, buffer_fixed, 1), _n = 0, _t = 0;
    buffer_get_surface(_b, _sf, 0);
    for (var _y = max(0, floor(_r.y)); _y < min(_h, ceil(_r.y + _r.h)); _y++) for (var _x = max(0, floor(_r.x)); _x < min(_w, ceil(_r.x + _r.w)); _x++) {
        var _o = (_y * _w + _x) * 4; _t++;
        if (buffer_peek(_b, _o, buffer_u8) > 250 && buffer_peek(_b, _o + 1, buffer_u8) > 250 && buffer_peek(_b, _o + 2, buffer_u8) > 250) _n++;
    }
    buffer_delete(_b);
    return _n / max(1, _t);
}

/// @function fsp_bake_size_sweep()
/// @description DIAGNOSTIC for the white-menu defect (every 1600 x 900 hero drew its menu as a white box while the
/// small screens on the houses sheet were right): build the same house at five sizes and draw it the way a BUYER does
/// (fsp_screen_draw at 1x into a surface of the screen's size), then count white in the menu region.
function fsp_bake_size_sweep() {
    var _ws = [640, 960, 1280, 1600, 1920], _out = [];
    for (var _i = 0; _i < array_length(_ws); _i++) {
        var _w = _ws[_i], _h = round(_w * 9 / 16);
        var _s = fsp_bake_screen("hall", _w, _h, 0);
        var _sf = surface_create(_w, _h);
        surface_set_target(_sf); draw_clear_alpha(c_black, 1); fsp_screen_draw(_s, 0, 0); surface_reset_target();
        var _wd = fsp_bake_white(_sf, _s.menu_region);
        surface_set_target(_sf); draw_clear_alpha(c_black, 1); draw_sprite(_s.spr_menu[0], 0, 0, 0); surface_reset_target();
        var _wp = fsp_bake_white(_sf, { x: 0, y: 0, w: sprite_get_width(_s.spr_menu[0]), h: sprite_get_height(_s.spr_menu[0]) });
        surface_set_target(_sf); draw_clear_alpha(c_black, 1); draw_sprite(_s.spr_full, 0, 0, 0); surface_reset_target();
        var _wf = fsp_bake_white(_sf, { x: 0, y: 0, w: _w, h: _h });
        array_push(_out, { w: _w, menu_w: sprite_get_width(_s.spr_menu[0]), menu_h: sprite_get_height(_s.spr_menu[0]), white_screen: _wd, white_plain: _wp, white_full: _wf, build_ms: _s.build_ms });
        surface_free(_sf);
        fsp_screen_free(_s);
    }
    return _out;
}

/// @function fsp_bake_run()
function fsp_bake_run() {
    global.fsp_bake_log = [];
    global.fsp_bake_diag = [];
    global.fsp_bake_sweep = fsp_bake_size_sweep();
    var _H = fsp_houses();
    for (var _i = 0; _i < array_length(_H); _i++) fsp_bake_hero(_H[_i].id);
    // 1600 x 830: at 1000 tall the two rows of 16:9 screens left ~20% of the sheet as bare page above and below
    fsp_bake_houses_sheet(1600, 830);
    fsp_bake_sheet("alphabet", 1600, 1000, fsp_bake_alphabet);
    fsp_bake_sheet("cuts", 1600, 900, fsp_bake_cuts);
    fsp_bake_sheet("grounds", 1600, 1000, fsp_bake_grounds);
    fsp_bake_sheet("ornaments", 1600, 1000, fsp_bake_ornaments);
    fsp_bake_sheet("menus", 1600, 1000, fsp_bake_menus);
    fsp_bake_cover();
    var _f = file_text_open_write("fsp_bake.json");
    file_text_write_string(_f, "{\"stage\":99,\"pass\":" + string(array_length(global.fsp_bake_log)) + ",\"fail\":0,\"sheets\":[");
    for (var _j = 0; _j < array_length(global.fsp_bake_log); _j++) {
        var _s = global.fsp_bake_log[_j];
        if (_j > 0) file_text_write_string(_f, ",");
        file_text_write_string(_f, "{\"sheet\":\"" + _s.sheet + "\",\"w\":" + string(_s.w) + ",\"h\":" + string(_s.h) + ",\"ink_px\":" + string(_s.px) +
            ",\"x0\":" + string(_s.x0) + ",\"y0\":" + string(_s.y0) + ",\"x1\":" + string(_s.x1) + ",\"y1\":" + string(_s.y1) + "}");
    }
    file_text_write_string(_f, "],\"diag\":[");
    for (var _d = 0; _d < array_length(global.fsp_bake_diag); _d++) {
        var _q = global.fsp_bake_diag[_d];
        if (_d > 0) file_text_write_string(_f, ",");
        file_text_write_string(_f, "{\"house\":\"" + _q.house + "\",\"w\":" + string(_q.w) + ",\"h\":" + string(_q.h) + ",\"white\":" + string(_q.white) + "}");
    }
    file_text_write_string(_f, "],\"sweep\":[");
    for (var _e = 0; _e < array_length(global.fsp_bake_sweep); _e++) {
        var _z = global.fsp_bake_sweep[_e];
        if (_e > 0) file_text_write_string(_f, ",");
        file_text_write_string(_f, "{\"w\":" + string(_z.w) + ",\"menu_w\":" + string(_z.menu_w) + ",\"menu_h\":" + string(_z.menu_h) + ",\"white_screen\":" + string(_z.white_screen) +
            ",\"white_plain\":" + string(_z.white_plain) + ",\"white_full\":" + string(_z.white_full) + ",\"build_ms\":" + string(_z.build_ms) + "}");
    }
    file_text_write_string(_f, "]}");
    file_text_close(_f);
}

/// @function fsp_bake_pad4(n)
/// @description A frame number as four digits - padded by ARITHMETIC (a formatted string with its spaces replaced once
/// turned "  0" into "0 0" and ffmpeg found no sequence). Pure.
function fsp_bake_pad4(_n) {
    _n = floor(_n);
    return string(_n div 1000) + string((_n div 100) mod 10) + string((_n div 10) mod 10) + string(_n mod 10);
}

/// @function fsp_bake_gif()
/// @description The GIF frames: a title cut in letter by letter, the device and menu rising after it, the choice
/// moving down and back up. Written as fsp_gif_NNNN.png at 800 x 450.
function fsp_bake_gif() {
    // Vigil, not Hall: raised oak on oak read muted at 800 x 450, and the GIF is the listing's first picture
    var _w = 800, _h = 450, _s = fsp_bake_screen("vigil", _w, _h, 0);
    _s.t = 0;
    var _sf = surface_create(_w, _h), _frame = 0, _end = fsp__reveal_end(_s);
    var _script = [];
    for (var _t = 0; _t < _end; _t += 2) array_push(_script, { t: _t, move: 0 });
    for (var _i = 0; _i < 24; _i++) array_push(_script, { t: -1, move: 0 });
    var _moves = [1, 1, -1, -1];
    for (var _m = 0; _m < array_length(_moves); _m++) {
        array_push(_script, { t: -1, move: _moves[_m] });
        for (var _j = 0; _j < 9; _j++) array_push(_script, { t: -1, move: 0 });
    }
    for (var _k = 0; _k < array_length(_script); _k++) {
        var _sc = _script[_k];
        if (_sc.t >= 0) _s.t = _sc.t; else { _s.t = _end + 2; if (_sc.move != 0) fsp_screen_move(_s, _sc.move); fsp_screen_step(_s); fsp_screen_step(_s); }
        surface_set_target(_sf);
        draw_clear_alpha(c_black, 1);
        fsp_screen_draw(_s, 0, 0);
        fsp__opaque(_w, _h);
        surface_reset_target();
        surface_save(_sf, "fsp_gif_" + fsp_bake_pad4(_frame) + ".png");
        _frame++;
    }
    surface_free(_sf);
    fsp_screen_free(_s);
    var _f = file_text_open_write("fsp_gif.json");
    file_text_write_string(_f, "{\"stage\":99,\"pass\":" + string(_frame) + ",\"fail\":0,\"frames\":" + string(_frame) + "}");
    file_text_close(_f);
}
