/// fsp_core.gml - the pure layer every Frontispiece picture is computed from: a seeded generator, a stable string
/// hash, colour maths with the absolute-separation relief rule, a Catmull-Rom resampler, deterministic surface noise,
/// and the two spacing laws (a pitch, never a count). NO drawing and no engine state in this file.
///
/// Frontispiece - The Title Screen, Generated, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// Colours in this layer are [r, g, b] arrays of 0-255 numbers, because the relief rules below do arithmetic on the
/// channels; fsp_col() turns one into a GameMaker colour at the moment it is drawn.
///
/// ⛔ ALL 32-BIT INTEGER ARITHMETIC GOES THROUGH fsp_mul32. A product of two 32-bit numbers needs 64 bits and a GML
/// real holds 53 exactly, so a plain `*` silently loses the low bits that a hash lives in. Splitting the multiply into
/// 16-bit halves keeps every intermediate below 2^49, where a real is exact.

/// @function fsp_mul32(a, b)
/// @description The low 32 bits of a * b for two unsigned 32-bit numbers (JavaScript's Math.imul, unsigned). Pure.
function fsp_mul32(_a, _b) {
    _a = _a & $FFFFFFFF;
    _b = _b & $FFFFFFFF;
    var _lo = (_a & $FFFF) * _b;
    var _hi = (((_a >> 16) & $FFFF) * _b) & $FFFF;
    return (_lo + (_hi << 16)) & $FFFFFFFF;
}

/// @function fsp_hash(text)
/// @description A stable 32-bit FNV-1a hash of a string, so a screen's seed comes from the game's own title and never
/// from anything positional. Pure. Anything that is not a string is hashed as its string form.
function fsp_hash(_s) {
    _s = string(_s);
    var _h = 2166136261;
    var _n = string_length(_s);
    for (var _i = 1; _i <= _n; _i++) {
        _h = (_h ^ (ord(string_char_at(_s, _i)) & $FFFF)) & $FFFFFFFF;
        _h = fsp_mul32(_h, 16777619);
    }
    return _h;
}

/// @function fsp_rng(seed)
/// @description A deterministic generator (mulberry32). Returns a small struct; draw from it with fsp_rng_next().
/// Never random(): a title screen must be the same screen every time the player boots the game. Pure.
function fsp_rng(_seed) {
    return { a: (is_real(_seed) || is_int64(_seed) || is_int32(_seed)) ? (floor(_seed) & $FFFFFFFF) : fsp_hash(_seed) };
}

/// @function fsp_rng_next(rng)
/// @description The next number in [0, 1) from an fsp_rng generator.
function fsp_rng_next(_r) {
    _r.a = (_r.a + $6D2B79F5) & $FFFFFFFF;
    var _t = fsp_mul32(_r.a ^ (_r.a >> 15), 1 | _r.a);
    _t = ((_t + fsp_mul32(_t ^ (_t >> 7), 61 | _t)) & $FFFFFFFF) ^ _t;
    return ((_t ^ (_t >> 14)) & $FFFFFFFF) / 4294967296;
}

// ---------------------------------------------------------------------------------------------------------------
// Colour
// ---------------------------------------------------------------------------------------------------------------

/// @function fsp_lum(c)
/// @description Rec. 601 luminance of an [r, g, b] colour, 0-255 - the scale every separation rule here is stated in.
function fsp_lum(_c) { return 0.299 * _c[0] + 0.587 * _c[1] + 0.114 * _c[2]; }

/// @function fsp_clamp255(v)
function fsp_clamp255(_v) { return clamp(round(_v), 0, 255); }

/// @function fsp_mix(a, b, t)
/// @description Mix two [r, g, b] colours; t = 0 returns a, 1 returns b. Pure.
function fsp_mix(_a, _b, _t) {
    return [fsp_clamp255(_a[0] + (_b[0] - _a[0]) * _t), fsp_clamp255(_a[1] + (_b[1] - _a[1]) * _t), fsp_clamp255(_a[2] + (_b[2] - _a[2]) * _t)];
}

/// @function fsp_col(c)
/// @description An [r, g, b] colour as a GameMaker colour.
function fsp_col(_c) { return make_colour_rgb(fsp_clamp255(_c[0]), fsp_clamp255(_c[1]), fsp_clamp255(_c[2])); }

/// @function fsp_headroom(c, dir)
/// @description Luminance levels available from a colour toward white (dir > 0) or black. Pure.
function fsp_headroom(_c, _dir) { var _l = fsp_lum(_c); return (_dir > 0) ? 255 - _l : _l; }

/// @function fsp_relief(base, dir, delta)
/// @description A colour separated from `base` by min(delta, headroom) luminance levels, lighter (dir > 0) or darker.
/// ⛔ THE RULE THIS PRODUCT LIVES BY: a tint whose job is to make something VISIBLE states its separation ABSOLUTELY
/// and solves for it. A multiplier moves a bright base far and a dark one barely, so a letter incised in pale vellum
/// and the same letter in black lacquer could not both read. An incised letter IS separation - there is no ink. Pure.
function fsp_relief(_base, _dir, _delta) {
    var _target = (_dir > 0) ? [255, 255, 255] : [0, 0, 0];
    var _want = min(_delta, fsp_headroom(_base, _dir));
    if (_want <= 0) return [_base[0], _base[1], _base[2]];
    var _lo = 0, _hi = 1, _l0 = fsp_lum(_base);
    for (var _i = 0; _i < 24; _i++) {
        var _mid = (_lo + _hi) * 0.5;
        var _got = abs(fsp_lum(fsp_mix(_base, _target, _mid)) - _l0);
        if (_got < _want) _lo = _mid; else _hi = _mid;
    }
    return fsp_mix(_base, _target, _hi);
}

/// @function fsp_pick_contrast(bg, candidates)
/// @description The candidate colour furthest from `bg` in luminance. Pure. An empty list returns the inverse of bg
/// by luminance rather than throwing.
function fsp_pick_contrast(_bg, _cands) {
    if (!is_array(_cands) || array_length(_cands) == 0) return (fsp_lum(_bg) > 127) ? [0, 0, 0] : [255, 255, 255];
    var _bl = fsp_lum(_bg), _best = _cands[0], _bd = -1;
    for (var _i = 0; _i < array_length(_cands); _i++) {
        var _d = abs(fsp_lum(_cands[_i]) - _bl);
        if (_d > _bd) { _bd = _d; _best = _cands[_i]; }
    }
    return _best;
}

/// @function fsp_separate(ink, ground, delta)
/// @description Keep an ink's own hue but move its luminance until it separates from `ground` by `delta` (or by as
/// much as exists). Gold stays gold. Pure.
function fsp_separate(_ink, _ground, _delta) {
    var _li = fsp_lum(_ink), _lg = fsp_lum(_ground);
    if (abs(_li - _lg) >= _delta) return [_ink[0], _ink[1], _ink[2]];
    // Move to whichever side of the GROUND has more room: deciding by the ink's own headroom picks the wrong side for
    // a mid ink on a near-white ground.
    var _dir = ((255 - _lg) >= _lg) ? 1 : -1;
    var _tl = (_dir > 0) ? min(255, _lg + _delta) : max(0, _lg - _delta);
    return fsp_relief(_ink, (_tl > _li) ? 1 : -1, abs(_tl - _li));
}

/// @function fsp_achievable(ink, ground, delta)
/// @description How much separation fsp_separate could POSSIBLY deliver for this pair, 0-255. A test asserts
/// min(delta, achievable) - and pairs it with a mid-grey control demanding the full delta, so "as much as exists"
/// cannot excuse a function that has stopped working. Pure.
function fsp_achievable(_ink, _ground, _delta) {
    var _li = fsp_lum(_ink), _lg = fsp_lum(_ground);
    if (abs(_li - _lg) >= _delta) return abs(_li - _lg);
    var _dir = ((255 - _lg) >= _lg) ? 1 : -1;
    var _tl = (_dir > 0) ? min(255, _lg + _delta) : max(0, _lg - _delta);
    var _md = (_tl > _li) ? 1 : -1;
    var _reach = min(abs(_tl - _li), fsp_headroom(_ink, _md));
    return abs((_li + _md * _reach) - _lg);
}

// ---------------------------------------------------------------------------------------------------------------
// Geometry. Points are [x, y] arrays; a ring or polyline is an array of points.
// ---------------------------------------------------------------------------------------------------------------

/// @function fsp_smooth(pts, per, closed)
/// @description Resample a polyline through a Catmull-Rom spline, `per` samples per span. THIS IS A STRUCTURAL SWITCH,
/// not a style one: an angular hand never calls it, so its O really is a lozenge of straight facets. Pure.
function fsp_smooth(_pts, _per, _closed) {
    var _n = array_length(_pts), _out = [], _i;
    if (_n < 3) {
        for (_i = 0; _i < _n; _i++) array_push(_out, [_pts[_i][0], _pts[_i][1]]);
        return _out;
    }
    var _steps = max(2, floor(_per));
    var _last = _closed ? _n : _n - 1;
    for (_i = 0; _i < _last; _i++) {
        var _p0 = _pts[_closed ? ((_i - 1 + _n) mod _n) : max(0, _i - 1)];
        var _p1 = _pts[_i mod _n];
        var _p2 = _pts[(_i + 1) mod _n];
        var _p3 = _pts[_closed ? ((_i + 2) mod _n) : min(_n - 1, _i + 2)];
        for (var _s = 0; _s < _steps; _s++) {
            var _t = _s / _steps, _t2 = _t * _t, _t3 = _t2 * _t;
            array_push(_out, [
                0.5 * ((2 * _p1[0]) + (-_p0[0] + _p2[0]) * _t + (2 * _p0[0] - 5 * _p1[0] + 4 * _p2[0] - _p3[0]) * _t2 + (-_p0[0] + 3 * _p1[0] - 3 * _p2[0] + _p3[0]) * _t3),
                0.5 * ((2 * _p1[1]) + (-_p0[1] + _p2[1]) * _t + (2 * _p0[1] - 5 * _p1[1] + 4 * _p2[1] - _p3[1]) * _t2 + (-_p0[1] + 3 * _p1[1] - 3 * _p2[1] + _p3[1]) * _t3)]);
        }
    }
    if (!_closed) array_push(_out, [_pts[_n - 1][0], _pts[_n - 1][1]]);
    return _out;
}

/// @function fsp_ring_area(ring)
/// @description Absolute area of a ring, px squared. Pure.
function fsp_ring_area(_ring) {
    var _a = 0, _n = array_length(_ring);
    for (var _i = 0; _i < _n; _i++) {
        var _j = (_i + _n - 1) mod _n;
        _a += _ring[_j][0] * _ring[_i][1] - _ring[_i][0] * _ring[_j][1];
    }
    return abs(_a) * 0.5;
}

/// @function fsp_shift(ring, dx, dy)
/// @description A shifted copy of a ring. Pure.
function fsp_shift(_ring, _dx, _dy) {
    var _n = array_length(_ring), _o = array_create(_n);
    for (var _i = 0; _i < _n; _i++) _o[_i] = [_ring[_i][0] + _dx, _ring[_i][1] + _dy];
    return _o;
}

/// @function fsp_bbox(rings)
/// @description {x0, y0, x1, y1} of every point in an array of rings. Pure. Empty input returns a zero box.
function fsp_bbox(_rings) {
    var _x0 = 1000000, _y0 = 1000000, _x1 = -1000000, _y1 = -1000000, _any = false;
    for (var _i = 0; _i < array_length(_rings); _i++) {
        var _r = _rings[_i];
        for (var _j = 0; _j < array_length(_r); _j++) {
            _any = true;
            _x0 = min(_x0, _r[_j][0]); _x1 = max(_x1, _r[_j][0]);
            _y0 = min(_y0, _r[_j][1]); _y1 = max(_y1, _r[_j][1]);
        }
    }
    if (!_any) return { x0: 0, y0: 0, x1: 0, y1: 0 };
    return { x0: _x0, y0: _y0, x1: _x1, y1: _y1 };
}

// ---------------------------------------------------------------------------------------------------------------
// Deterministic surface noise. A title screen is mostly GROUND, and a flat ground is the whole failure.
// ---------------------------------------------------------------------------------------------------------------

/// @function fsp_noise2(x, y, seed)
/// @description Hash-based lattice noise in [0, 1). No tables, no state. Pure.
function fsp_noise2(_x, _y, _seed) {
    var _h = (floor(_seed) & $FFFFFFFF) ^ $9E3779B9;
    _h = fsp_mul32(_h ^ (floor(_x) & $FFFFFFFF), $85EBCA6B);
    _h = (_h ^ (_h >> 13)) & $FFFFFFFF;
    _h = fsp_mul32(_h ^ (floor(_y) & $FFFFFFFF), $C2B2AE35);
    _h = (_h ^ (_h >> 16)) & $FFFFFFFF;
    return _h / 4294967296;
}

/// @function fsp_snoise(x, y, seed)
/// @description Smoothed value noise (bilinear over the lattice with a smoothstep), [0, 1]. Pure.
function fsp_snoise(_x, _y, _seed) {
    var _xi = floor(_x), _yi = floor(_y), _xf = _x - _xi, _yf = _y - _yi;
    var _u = _xf * _xf * (3 - 2 * _xf), _v = _yf * _yf * (3 - 2 * _yf);
    var _a = fsp_noise2(_xi, _yi, _seed), _b = fsp_noise2(_xi + 1, _yi, _seed);
    var _c = fsp_noise2(_xi, _yi + 1, _seed), _d = fsp_noise2(_xi + 1, _yi + 1, _seed);
    var _top = _a + (_b - _a) * _u, _bot = _c + (_d - _c) * _u;
    return _top + (_bot - _top) * _v;
}

/// @function fsp_fbm(x, y, seed, octaves)
/// @description A fractal sum of fsp_snoise, [0, 1]. Pure.
function fsp_fbm(_x, _y, _seed, _oct) {
    var _sum = 0, _amp = 1, _norm = 0, _f = 1;
    var _n = max(1, floor(_oct));
    for (var _i = 0; _i < _n; _i++) {
        _sum += _amp * fsp_snoise(_x * _f, _y * _f, _seed + _i * 7919);
        _norm += _amp; _amp *= 0.5; _f *= 2;
    }
    return _sum / _norm;
}

// ---------------------------------------------------------------------------------------------------------------
// The two spacing laws, in ABSOLUTE pixels, because the eye reads pixels and not proportions.
// ---------------------------------------------------------------------------------------------------------------

#macro FSP_PAPER_MIN 2.6

/// @function fsp_fit_lines(span, ink, want)
/// @description How many marks `ink` px wide fit in `span` px with at least FSP_PAPER_MIN px of paper between them:
/// {count, pitch, fits}. A border asking for 40 dentils on a 90 px run gets 13, and says so. Pure.
function fsp_fit_lines(_span, _ink, _want) {
    var _pitch = abs(_ink) + FSP_PAPER_MIN;
    if (!(_span > 0) || !(_pitch > 0)) return { count: 0, pitch: _pitch, fits: false };
    var _count = max(0, min(_want, floor(_span / _pitch)));
    return { count: _count, pitch: _pitch, fits: _count >= _want };
}

/// @function fsp_repeats_for(span, band, pitch_mul, ink)
/// @description Derive a repeat count from a PITCH (a multiple of the band thickness), never take one as a count:
/// {count, pitch, floored}. The right count changes with the size of the piece. Pure.
function fsp_repeats_for(_span, _band, _pitch_mul, _ink) {
    var _want = max(1, round(_span / max(0.001, _band * _pitch_mul)));
    var _fit = fsp_fit_lines(_span, _ink, _want);
    var _count = max(1, _fit.count);
    return { count: _count, pitch: _span / _count, floored: !_fit.fits };
}
