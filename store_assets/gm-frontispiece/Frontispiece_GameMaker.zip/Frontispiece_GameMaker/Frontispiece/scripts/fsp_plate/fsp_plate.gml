/// fsp_plate.gml - the drawing: grounds worked as materials, frames, cartouches, the wordmark, ornament, the device and
/// the menu furniture. ONE LIGHT, FROM THE UPPER LEFT, FOR EVERY MARK: a rim lit from one side beside a letter lit from
/// the other is the difference between a made object and a pile of layers.
///
/// Frontispiece - The Title Screen, Generated, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// TWO RULES SHAPE THE WHOLE FILE:
///   * Every repeated treatment declares a PITCH and DERIVES its count from the real run (fsp_repeats_for).
///   * Every tint whose job is to make something VISIBLE states its separation in ABSOLUTE luminance (fsp_relief):
///     a texture tuned on vellum and applied as a multiplier to lacquer would vanish while every counter reported work.
/// UNITS: every function takes `k`, the size of ONE OUTPUT PIXEL in the pixels being drawn (2 when the screen is built
/// supersampled at 2x). Hairlines, specks and paper gaps are physical and scale by k; bands, panels and type are
/// proportions of the screen; mark COUNTS scale with the output area, so a bigger screen is not a sparser one.
/// Coordinates are wherever the caller's target is (a surface, the GUI layer).

/// @function fsp_plate_layout(box, spec, [state], [k])
/// @description Divide a screen box {x, y, w, h} into its regions - solved, not typed, with a FOOT margin reserved (a
/// last rule a few pixels from the edge reads as a mistake even when nothing clips). Returns {frame_rect, band, inner,
/// work, title, head_h, vignette, menu, imprint_y}. Wide screens keep the menu and device at a readable width instead of
/// stretching them edge to edge. Pure.
function fsp_plate_layout(_box, _spec, _state = undefined, _k = 1) {
    var _cart = fsp_find(fsp_cartouches(), _spec.cartouche), _fr = fsp_find(fsp_frames(), _spec.frame);
    var _m = min(_box.w, _box.h), _inset = _m * 0.042, _band = _m * _fr.band;
    var _inner = { x: _box.x + _inset + _band, y: _box.y + _inset + _band, w: _box.w - 2 * (_inset + _band), h: _box.h - 2 * (_inset + _band) };
    var _pad = min(_inner.w, _inner.h * 1.36) * 0.045;
    var _work = { x: _inner.x + _pad, y: _inner.y + _pad, w: _inner.w - 2 * _pad, h: _inner.h - 2 * _pad };
    var _title_h = _work.h * 0.365;
    var _title = { x: _work.x, y: _work.y, w: _work.w, h: _title_h };
    var _menu_h = _work.h * 0.305, _imprint_h = _work.h * 0.110;
    var _mw = min(_work.w * 0.52, _work.h * 0.78);
    var _menu = { x: _work.x + (_work.w - _mw) * 0.5, y: _work.y + _work.h - _imprint_h - _menu_h, w: _mw, h: _menu_h };
    var _vw = min(_work.w * 0.58, _work.h * 1.10);
    var _vig = { x: _work.x + (_work.w - _vw) * 0.5, y: _title.y + _title.h + _work.h * 0.010, w: _vw, h: max(0, _menu.y - (_title.y + _title.h) - _work.h * 0.026) };
    return { frame_rect: { x: _box.x + _inset, y: _box.y + _inset, w: _box.w - 2 * _inset, h: _box.h - 2 * _inset }, band: _band, inner: _inner,
        work: _work, title: _title, head_h: _title_h * _cart.head, vignette: _vig, menu: _menu, imprint_y: _work.y + _work.h - _imprint_h * 0.25 };
}

/// @function fsp__tex(ground, dir, strength)
/// @description A texture mark's colour, separated from the ground ABSOLUTELY. Internal, pure.
function fsp__tex(_g, _dir, _s) { return fsp_relief(_g.base, _dir, max(3, round(46 * _g.grain * _s * 6))); }

// ---------------------------------------------------------------------------------------------------------------
// GROUNDS
// ---------------------------------------------------------------------------------------------------------------

/// @function fsp_plate_ground(spec, box, k)
/// @description Fill the whole screen with its worked material, then a closing vignette so the eye goes to the middle.
/// ⛔ CLIPPED TO THE BOX: the mottles, pores and hammer facets are scattered by centre, so a mark near the edge reached
/// past it - invisible on a full screen (the surface clips it) and pale blobs on the page around every smaller box.
function fsp_plate_ground(_spec, _box, _k) {
    var _g = fsp_find(fsp_grounds(), _spec.ground);
    var _rng = fsp_rng(_spec.seed ^ $51ED);
    var _ak = max(0.25, (_box.w * _box.h) / (_k * _k * 816 * 624));
    var _clip = gpu_get_scissor();
    gpu_set_scissor(max(_clip.x, floor(_box.x)), max(_clip.y, floor(_box.y)), max(1, min(_clip.x + _clip.w, ceil(_box.x + _box.w)) - max(_clip.x, floor(_box.x))),
        max(1, min(_clip.y + _clip.h, ceil(_box.y + _box.h)) - max(_clip.y, floor(_box.y))));
    fsp__plate_ground_body(_g, _box, _rng, _k, _ak);
    gpu_set_scissor(_clip.x, _clip.y, _clip.w, _clip.h);
}

/// @function fsp__plate_ground_body(g, box, rng, k, ak)
/// @description The ground's layers, drawn inside the scissor fsp_plate_ground sets. Internal.
function fsp__plate_ground_body(_g, _box, _rng, _k, _ak) {
    fsp_rect_grad(_box.x, _box.y, _box.w, _box.h, _box.x, _box.y, _box.x + _box.w * 0.35, _box.y + _box.h,
        fsp_stops2(fsp_col(fsp_mix(_g.base, _g.deep, 0.06)), fsp_col(fsp_mix(_g.base, _g.deep, 0.42))));
    switch (_g.treatment) {
        case "mottle": fsp__g_mottle(_g, _box, _rng, _k, _ak); break;
        case "pore": fsp__g_pore(_g, _box, _rng, _k, _ak); break;
        case "cleave": fsp__g_cleave(_g, _box, _rng, _k, _ak); break;
        case "hammer": fsp__g_hammer(_g, _box, _rng, _k, _ak); break;
        case "sheen": fsp__g_sheen(_g, _box, _rng, _k, _ak); break;
        case "weave": fsp__g_weave(_g, _box, _rng, _k, _ak); break;
        case "grain": fsp__g_grain(_g, _box, _rng, _k, _ak); break;
        case "brush": fsp__g_brush(_g, _box, _rng, _k, _ak); break;
    }
    fsp_radial_rect(_box.x, _box.y, _box.w, _box.h, _box.x + _box.w * 0.5, _box.y + _box.h * 0.44,
        min(_box.w, _box.h) * 0.30, max(_box.w, _box.h) * 0.78, fsp_col(_g.deep), 0, 0.46);
}

/// @function fsp__g_mottle(g, box, rng, k, ak)
/// @description Vellum: soft blotching plus follicle specks. Internal.
function fsp__g_mottle(_g, _b, _r, _k, _ak) {
    var _m = min(_b.w, _b.h), _i, _n = round(220 * _ak);
    fsp_batch_begin();
    for (_i = 0; _i < _n; _i++) {
        var _x = _b.x + fsp_rng_next(_r) * _b.w, _y = _b.y + fsp_rng_next(_r) * _b.h, _rad = _m * (0.03 + fsp_rng_next(_r) * 0.10);
        var _dir = (fsp_rng_next(_r) < 0.55) ? -1 : 1;
        var _rx = _rad * (0.7 + fsp_rng_next(_r) * 0.9), _ry = _rad * (0.5 + fsp_rng_next(_r) * 0.7), _rot = fsp_rng_next(_r) * 3.1;
        fsp_batch_ellipse(_x, _y, _rx, _ry, _rot, fsp_col(fsp__tex(_g, _dir, 0.9)), 0.05 + fsp_rng_next(_r) * 0.05);
    }
    _n = round(460 * _ak);
    var _speck = fsp_col(fsp__tex(_g, -1, 1.6));
    for (_i = 0; _i < _n; _i++) {
        var _sx = _b.x + fsp_rng_next(_r) * _b.w, _sy = _b.y + fsp_rng_next(_r) * _b.h;
        var _srx = (0.8 + fsp_rng_next(_r) * 1.1) * _k, _sry = (0.6 + fsp_rng_next(_r) * 0.9) * _k;
        fsp_batch_ellipse(_sx, _sy, _srx, _sry, 0, _speck, 0.10 + fsp_rng_next(_r) * 0.14);
    }
    fsp_batch_end();
}

/// @function fsp__g_pore(g, box, rng, k, ak)
/// @description Leather: pores over broad grain cells, each pore with a lit lip on the lamp side. Internal.
function fsp__g_pore(_g, _b, _r, _k, _ak) {
    var _m = min(_b.w, _b.h), _i, _n = round(150 * _ak);
    var _cell = fsp_col(fsp__tex(_g, 1, 0.7)), _pore = fsp_col(fsp__tex(_g, -1, 1.3)), _lip = fsp_col(fsp__tex(_g, 1, 1.0));
    fsp_batch_begin();
    for (_i = 0; _i < _n; _i++) {
        var _x = _b.x + fsp_rng_next(_r) * _b.w, _y = _b.y + fsp_rng_next(_r) * _b.h, _rad = _m * (0.02 + fsp_rng_next(_r) * 0.05);
        var _ry = _rad * (0.6 + fsp_rng_next(_r) * 0.6), _rot = fsp_rng_next(_r) * 3.1;
        fsp_batch_ellipse(_x, _y, _rad, _ry, _rot, _cell, 0.05 + fsp_rng_next(_r) * 0.05);
    }
    _n = round(2600 * _ak);
    for (_i = 0; _i < _n; _i++) {
        var _px = _b.x + fsp_rng_next(_r) * _b.w, _py = _b.y + fsp_rng_next(_r) * _b.h, _s = (0.7 + fsp_rng_next(_r) * 1.4) * _k;
        fsp_batch_ellipse(_px, _py, _s, _s * 0.8, 0, _pore, 0.10 + fsp_rng_next(_r) * 0.18);
        if (fsp_rng_next(_r) < 0.4) fsp_batch_ellipse(_px - _s * 0.7, _py - _s * 0.7, _s * 0.5, _s * 0.4, 0, _lip, 0.10);
    }
    fsp_batch_end();
}

/// @function fsp__g_cleave(g, box, rng, k, ak)
/// @description Slate: riven stone. Bands are PARTIAL, offset and interrupted - ninety full-width bands read as planks
/// beside the oak; stone splits in irregular blocks with stepped edges. Internal.
function fsp__g_cleave(_g, _b, _r, _k, _ak) {
    var _m = min(_b.w, _b.h), _i, _n = round(150 * _ak);
    fsp_batch_begin();
    for (_i = 0; _i < _n; _i++) {
        var _y = _b.y + fsp_rng_next(_r) * _b.h, _h = _b.h * (0.004 + fsp_rng_next(_r) * 0.030);
        var _x = _b.x + fsp_rng_next(_r) * _b.w * 0.7, _w = _b.w * (0.12 + fsp_rng_next(_r) * 0.55);
        var _dir = (fsp_rng_next(_r) < 0.5) ? -1 : 1;
        fsp_batch_rect(_x, _y, _w, _h, fsp_col(fsp__tex(_g, _dir, 0.9)), 0.06 + fsp_rng_next(_r) * 0.08);
    }
    _n = round(70 * _ak);
    for (_i = 0; _i < _n; _i++) {
        var _cx = _b.x + fsp_rng_next(_r) * _b.w, _cy = _b.y + fsp_rng_next(_r) * _b.h, _cw = _b.w * (0.02 + fsp_rng_next(_r) * 0.07), _ch = _b.h * (0.01 + fsp_rng_next(_r) * 0.05);
        var _cd = (fsp_rng_next(_r) < 0.6) ? -1 : 1;
        fsp_batch_convex([[_cx, _cy], [_cx + _cw, _cy - _ch * 0.3], [_cx + _cw * 0.8, _cy + _ch], [_cx + _cw * 0.2, _cy + _ch * 0.7]], fsp_col(fsp__tex(_g, _cd, 1.2)), 0.07 + fsp_rng_next(_r) * 0.09);
    }
    // Sharp cleaves: a few long, slightly wandering splits - dark in the split, a lit lip below it.
    var _dark = fsp_col(fsp__tex(_g, -1, 1.7)), _lit = fsp_col(fsp__tex(_g, 1, 1.2));
    for (_i = 0; _i < 9; _i++) {
        var _y0 = _b.y + fsp_rng_next(_r) * _b.h, _px = _b.x, _py = _y0;
        for (var _s = 1; _s <= 16; _s++) {
            var _qx = _b.x + _b.w * _s / 16, _qy = _y0 + (fsp_fbm(_s * 0.7, _i * 3.3, 99, 2) - 0.5) * _b.h * 0.05;
            fsp_batch_seg(_px, _py, _qx, _qy, 1.2 * _k, _dark, 0.30);
            fsp_batch_seg(_px, _py + 1.6 * _k, _qx, _qy + 1.6 * _k, 1.0 * _k, _lit, 0.20);
            _px = _qx; _py = _qy;
        }
    }
    _n = round(900 * _ak);
    for (_i = 0; _i < _n; _i++) {
        var _sx = _b.x + fsp_rng_next(_r) * _b.w, _sy = _b.y + fsp_rng_next(_r) * _b.h;
        var _srx = (0.7 + fsp_rng_next(_r) * 1.2) * _k, _sry = (0.6 + fsp_rng_next(_r)) * _k;
        var _sd = (fsp_rng_next(_r) < 0.5) ? -1 : 1;
        fsp_batch_ellipse(_sx, _sy, _srx, _sry, 0, fsp_col(fsp__tex(_g, _sd, 1.4)), 0.10 + fsp_rng_next(_r) * 0.14);
    }
    fsp_batch_end();
    return _m;
}

/// @function fsp__g_hammer(g, box, rng, k, ak)
/// @description Bronze: planished facets on a staggered grid, each lit from the upper left; verdigris in the lows.
/// Internal.
function fsp__g_hammer(_g, _b, _r, _k, _ak) {
    var _m = min(_b.w, _b.h), _step = _m * 0.048;
    var _cols = ceil(_b.w / _step) + 1, _rows = ceil(_b.h / _step) + 1;
    var _lit = fsp_col(fsp__tex(_g, 1, 1.1)), _base = fsp_col(_g.base), _dark = fsp_col(fsp__tex(_g, -1, 1.0));
    for (var _j = 0; _j < _rows; _j++) {
        for (var _i = 0; _i < _cols; _i++) {
            var _x = _b.x + _i * _step + ((_j mod 2) ? _step * 0.5 : 0) + (fsp_rng_next(_r) - 0.5) * _step * 0.25;
            var _y = _b.y + _j * _step + (fsp_rng_next(_r) - 0.5) * _step * 0.25;
            var _rad = _step * (0.52 + fsp_rng_next(_r) * 0.18);
            fsp_ellipse_grad(_x, _y, _rad, _rad * 0.92, 0, _x - _rad * 0.7, _y - _rad * 0.7, _x + _rad * 0.7, _y + _rad * 0.7,
                [[0, _lit, 0.22], [0.55, _base, 0], [1, _dark, 0.20]]);
        }
    }
    var _n = round(120 * _ak), _verd = make_colour_rgb(74, 118, 96);
    fsp_batch_begin();
    for (var _v = 0; _v < _n; _v++) {
        var _vx = _b.x + fsp_rng_next(_r) * _b.w, _vy = _b.y + fsp_rng_next(_r) * _b.h, _vr = _m * (0.01 + fsp_rng_next(_r) * 0.05);
        var _vry = _vr * (0.6 + fsp_rng_next(_r) * 0.7), _vrot = fsp_rng_next(_r) * 3.1;
        fsp_batch_ellipse(_vx, _vy, _vr, _vry, _vrot, _verd, 0.04 + fsp_rng_next(_r) * 0.06);
    }
    fsp_batch_end();
}

/// @function fsp__g_sheen(g, box, rng, k, ak)
/// @description Lacquer: one broad specular sweep and hairline crazing. Internal.
function fsp__g_sheen(_g, _b, _r, _k, _ak) {
    var _base = fsp_col(_g.base);
    fsp_rect_grad(_b.x, _b.y, _b.w, _b.h, _b.x, _b.y + _b.h, _b.x + _b.w, _b.y,
        [[0, _base, 0], [0.42, fsp_col(fsp_relief(_g.base, 1, 26)), 0.30], [0.58, fsp_col(fsp_relief(_g.base, 1, 14)), 0.14], [1, _base, 0]]);
    var _m = min(_b.w, _b.h), _i, _n = round(150 * _ak), _craze = fsp_col(fsp_relief(_g.base, 1, 22)), _fleck = fsp_col(fsp_relief(_g.base, 1, 30));
    fsp_batch_begin();
    for (_i = 0; _i < _n; _i++) {
        var _x = _b.x + fsp_rng_next(_r) * _b.w, _y = _b.y + fsp_rng_next(_r) * _b.h;
        var _len = _m * (0.01 + fsp_rng_next(_r) * 0.06), _a = fsp_rng_next(_r) * pi;
        fsp_batch_seg(_x, _y, _x + cos(_a) * _len, _y + sin(_a) * _len, 0.9 * _k, _craze, 0.10 + fsp_rng_next(_r) * 0.10);
    }
    _n = round(340 * _ak);
    for (_i = 0; _i < _n; _i++) {
        var _sx = _b.x + fsp_rng_next(_r) * _b.w, _sy = _b.y + fsp_rng_next(_r) * _b.h, _srx = (0.6 + fsp_rng_next(_r) * 0.8) * _k;
        fsp_batch_ellipse(_sx, _sy, _srx, 0.6 * _k, 0, _fleck, 0.06 + fsp_rng_next(_r) * 0.10);
    }
    fsp_batch_end();
}

/// @function fsp__g_weave(g, box, rng, k, ak)
/// @description Linen: warp and weft at a real pitch, with slubs. The pitch is DERIVED (fsp_fit_lines) in OUTPUT
/// pixels, so the threads never smear into a grey band. Internal.
function fsp__g_weave(_g, _b, _r, _k, _ak) {
    var _fx = fsp_fit_lines(_b.w / _k, 1.6, round(_b.w / _k / 5)), _fy = fsp_fit_lines(_b.h / _k, 1.6, round(_b.h / _k / 5));
    var _px = _fx.pitch * _k, _py = _fy.pitch * _k, _i;
    var _warp = fsp_col(fsp__tex(_g, -1, 0.9)), _weft = fsp_col(fsp__tex(_g, 1, 0.8)), _slub = fsp_col(fsp__tex(_g, -1, 1.2));
    fsp_batch_begin();
    for (_i = 0; _i < _fx.count; _i++) fsp_batch_rect(_b.x + _i * _px, _b.y, _px * 0.5, _b.h, _warp, 0.10 + fsp_rng_next(_r) * 0.05);
    for (_i = 0; _i < _fy.count; _i++) fsp_batch_rect(_b.x, _b.y + _i * _py, _b.w, _py * 0.5, _weft, 0.09 + fsp_rng_next(_r) * 0.05);
    var _n = round(90 * _ak), _m = min(_b.w, _b.h);
    for (_i = 0; _i < _n; _i++) {
        var _x = _b.x + fsp_rng_next(_r) * _b.w, _y = _b.y + fsp_rng_next(_r) * _b.h, _w = _m * (0.01 + fsp_rng_next(_r) * 0.05);
        fsp_batch_rect(_x, _y, _w, _py * 1.4, _slub, 0.10 + fsp_rng_next(_r) * 0.10);
    }
    fsp_batch_end();
}

/// @function fsp__g_grain(g, box, rng, k, ak)
/// @description Oak: straight grain lines that wander with the wood, plus short medullary rays. Internal.
function fsp__g_grain(_g, _b, _r, _k, _ak) {
    var _lines = max(24, round(62 * (_b.h / _k) / 624)), _dark = fsp_col(fsp__tex(_g, -1, 1.1)), _ray = fsp_col(fsp__tex(_g, 1, 1.0)), _i;
    fsp_batch_begin();
    for (_i = 0; _i < _lines; _i++) {
        var _y0 = _b.y + _b.h * _i / _lines + (fsp_rng_next(_r) - 0.5) * 4 * _k;
        var _a = 0.10 + fsp_rng_next(_r) * 0.16, _w = (0.9 + fsp_rng_next(_r) * 1.8) * _k;
        var _px = _b.x, _py = _y0 + (fsp_fbm(0, _i * 1.7, 41, 3) - 0.5) * _b.h * 0.030;
        for (var _s = 1; _s <= 22; _s++) {
            var _qx = _b.x + _b.w * _s / 22, _qy = _y0 + (fsp_fbm(_s * 0.35, _i * 1.7, 41, 3) - 0.5) * _b.h * 0.030;
            fsp_batch_seg(_px, _py, _qx, _qy, _w, _dark, _a);
            _px = _qx; _py = _qy;
        }
    }
    var _n = round(200 * _ak), _m = min(_b.w, _b.h);
    for (_i = 0; _i < _n; _i++) {
        var _x = _b.x + fsp_rng_next(_r) * _b.w, _y = _b.y + fsp_rng_next(_r) * _b.h, _len = _m * (0.008 + fsp_rng_next(_r) * 0.030);
        var _dx = (fsp_rng_next(_r) - 0.5) * 6 * _k;
        fsp_batch_seg(_x, _y, _x + _dx, _y + _len, 1.1 * _k, _ray, 0.10 + fsp_rng_next(_r) * 0.12);
    }
    fsp_batch_end();
}

/// @function fsp__g_brush(g, box, rng, k, ak)
/// @description Steel: an anisotropic brush, two seams and countersunk fixings at a derived pitch. Internal.
function fsp__g_brush(_g, _b, _r, _k, _ak) {
    var _n = round(1500 * _ak), _up = fsp_col(fsp__tex(_g, 1, 1.0)), _dn = fsp_col(fsp__tex(_g, -1, 1.0)), _i;
    fsp_batch_begin();
    for (_i = 0; _i < _n; _i++) {
        var _y = _b.y + fsp_rng_next(_r) * _b.h, _x = _b.x + fsp_rng_next(_r) * _b.w, _len = _b.w * (0.02 + fsp_rng_next(_r) * 0.20);
        var _c = (fsp_rng_next(_r) < 0.5) ? _up : _dn;
        fsp_batch_seg(_x, _y, min(_b.x + _b.w, _x + _len), _y, 0.8 * _k, _c, 0.05 + fsp_rng_next(_r) * 0.08);
    }
    fsp_batch_end();
    var _seams = [_b.y + _b.h * 0.19, _b.y + _b.h * 0.81];
    for (_i = 0; _i < 2; _i++) {
        fsp_seg(_b.x, _seams[_i], _b.x + _b.w, _seams[_i], 2.0 * _k, fsp_col(fsp_relief(_g.base, -1, 34)));
        fsp_seg(_b.x, _seams[_i] + 1.8 * _k, _b.x + _b.w, _seams[_i] + 1.8 * _k, 1.2 * _k, fsp_col(fsp_relief(_g.base, 1, 26)));
    }
    var _rad = min(_b.w, _b.h) * 0.011, _fit = fsp_repeats_for(_b.w, _rad * 2, 7.5, _rad * 2);
    var _cd = fsp_col(fsp_relief(_g.base, -1, 30)), _cl = fsp_col(fsp_relief(_g.base, 1, 22)), _hole = fsp_col(fsp_relief(_g.base, -1, 40));
    for (_i = 0; _i < 2; _i++) {
        for (var _j = 0; _j < _fit.count; _j++) {
            var _fx = _b.x + (_j + 0.5) * _fit.pitch;
            fsp_ellipse_grad(_fx, _seams[_i], _rad, _rad, 0, _fx - _rad, _seams[_i] - _rad, _fx + _rad, _seams[_i] + _rad, fsp_stops2(_cd, _cl));
            fsp_ellipse(_fx, _seams[_i], _rad * 0.45, _rad * 0.45, 0, _hole);
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------
// FRAMES
// ---------------------------------------------------------------------------------------------------------------

/// @function fsp_plate_frame(spec, L, k)
/// @description Draw the border as a MOULDING - the gradient across its thickness is what makes it read as raised.
function fsp_plate_frame(_spec, _L, _k) {
    var _g = fsp_find(fsp_grounds(), _spec.ground), _fr = fsp_find(fsp_frames(), _spec.frame);
    var _b = _L.band, _rc = _L.frame_rect;
    var _lit = fsp_relief(_g.base, 1, 34), _dark = fsp_relief(_g.base, -1, 40);
    if (_fr.id == "corners") { fsp__frame_corners(_spec, _L, _lit, _dark, _k); return; }
    fsp_fill_rings([fsp_rect_ring(_rc.x, _rc.y, _rc.w, _rc.h), fsp_rect_ring(_rc.x + _b, _rc.y + _b, _rc.w - 2 * _b, _rc.h - 2 * _b)], fsp_col(fsp_mix(_g.base, _lit, 0.30)));
    var _ew = max(_k, _b * 0.16);
    fsp_rect_stroke_grad(_rc.x + _ew * 0.5, _rc.y + _ew * 0.5, _rc.w - _ew, _rc.h - _ew, _ew, _rc.x, _rc.y, _rc.x + _rc.w, _rc.y + _rc.h, fsp_stops2(fsp_col(_lit), fsp_col(_dark)));
    fsp_rect_stroke_grad(_rc.x + _b, _rc.y + _b, _rc.w - 2 * _b, _rc.h - 2 * _b, _ew, _rc.x, _rc.y, _rc.x + _rc.w, _rc.y + _rc.h, fsp_stops2(fsp_col(_dark), fsp_col(_lit)));
    var _runs = [[_rc.x, _rc.y, _rc.w, 1, 0], [_rc.x, _rc.y + _rc.h - _b, _rc.w, 1, 0], [_rc.x, _rc.y, _rc.h, 0, 1], [_rc.x + _rc.w - _b, _rc.y, _rc.h, 0, 1]];
    var _i;
    switch (_fr.id) {
        case "fillet":
            var _in = _b * 1.9;
            fsp_rect_stroke(_rc.x + _in, _rc.y + _in, _rc.w - 2 * _in, _rc.h - 2 * _in, max(_k, _b * 0.14), fsp_col(_dark));
            var _in2 = _in + _b * 0.30;
            fsp_rect_stroke(_rc.x + _in2, _rc.y + _in2, _rc.w - 2 * _in2, _rc.h - 2 * _in2, max(_k, _b * 0.10), fsp_col(_lit));
            break;
        case "dentil": for (_i = 0; _i < 4; _i++) fsp__frame_dentils(_runs[_i], _b, _fr, _lit, _dark); break;
        case "guilloche": for (_i = 0; _i < 4; _i++) fsp__frame_guilloche(_runs[_i], _b, _fr, _lit, _dark, _k); break;
        case "rope": for (_i = 0; _i < 4; _i++) fsp__frame_cable(_runs[_i], _b, _fr, _lit, _dark); break;
        default: for (_i = 0; _i < 4; _i++) fsp__frame_strap(_runs[_i], _b, _lit, _dark, _k); break;
    }
    if (_fr.corner == "boss" || _fr.corner == "knot") {
        var _c = [[_rc.x + _b * 0.5, _rc.y + _b * 0.5], [_rc.x + _rc.w - _b * 0.5, _rc.y + _b * 0.5], [_rc.x + _b * 0.5, _rc.y + _rc.h - _b * 0.5], [_rc.x + _rc.w - _b * 0.5, _rc.y + _rc.h - _b * 0.5]];
        for (_i = 0; _i < 4; _i++) fsp__boss(_c[_i][0], _c[_i][1], _b * 0.62, _lit, _dark, _g.base);
    }
}

/// @function fsp__frame_dentils(run, b, frame, lit, dark)
/// @description A run of cut blocks at a derived pitch. run = [x, y, len, ax, ay]. Internal.
function fsp__frame_dentils(_run, _b, _fr, _lit, _dark) {
    var _fit = fsp_repeats_for(_run[2], _b, _fr.pitch_mul, _b * 0.42);
    for (var _i = 0; _i < _fit.count; _i++) {
        var _t = (_i + 0.22) * _fit.pitch;
        var _x = _run[0] + _run[3] * _t + (_run[3] ? 0 : _b * 0.22), _y = _run[1] + _run[4] * _t + (_run[4] ? 0 : _b * 0.22);
        var _w = _run[3] ? _fit.pitch * 0.56 : _b * 0.56, _h = _run[4] ? _fit.pitch * 0.56 : _b * 0.56;
        fsp_rect_grad(_x, _y, _w, _h, _x, _y, _x + _w, _y + _h, fsp_stops2(fsp_col(_lit), fsp_col(_dark)));
    }
}

/// @function fsp__frame_guilloche(run, b, frame, lit, dark, k)
/// @description Two interlaced ribbons along the band, at a derived pitch. Internal.
function fsp__frame_guilloche(_run, _b, _fr, _lit, _dark, _k) {
    var _ink = max(1.2 * _k, _b * 0.13), _fit = fsp_repeats_for(_run[2], _b, _fr.pitch_mul, _ink), _amp = _b * 0.28;
    var _steps = max(8, _fit.count * 8);
    for (var _ph = 0; _ph < 2; _ph++) {
        var _pts = [];
        for (var _s = 0; _s <= _steps; _s++) {
            var _t = _s / _steps * _run[2];
            var _off = sin(_t / max(1, _fit.pitch) * 2 * pi + _ph * pi) * _amp;
            array_push(_pts, [_run[0] + _run[3] * _t + (_run[3] ? 0 : _b * 0.5 + _off), _run[1] + _run[4] * _t + (_run[4] ? 0 : _b * 0.5 + _off)]);
        }
        fsp_polyline(_pts, _ink, fsp_col(_ph ? _dark : _lit));
    }
}

/// @function fsp__frame_cable(run, b, frame, lit, dark)
/// @description A twisted cable: one lit, tilted strand per derived pitch. Internal.
function fsp__frame_cable(_run, _b, _fr, _lit, _dark) {
    var _fit = fsp_repeats_for(_run[2], _b, _fr.pitch_mul, _b * 0.5);
    for (var _i = 0; _i < _fit.count; _i++) {
        var _t = _i * _fit.pitch;
        var _cx = _run[0] + _run[3] * _t + (_run[3] ? _fit.pitch * 0.5 : _b * 0.5), _cy = _run[1] + _run[4] * _t + (_run[4] ? _fit.pitch * 0.5 : _b * 0.5);
        var _rot = _run[3] ? -0.6 : 0.6 + pi / 2;
        fsp_ellipse_grad(_cx, _cy, _fit.pitch * 0.62, _b * 0.34, _rot, _cx - _b * 0.5, _cy - _b * 0.5, _cx + _b * 0.5, _cy + _b * 0.5, fsp_stops2(fsp_col(_lit), fsp_col(_dark)));
    }
}

/// @function fsp__frame_strap(run, b, lit, dark, k)
/// @description A plain strap with a bead down its centre. Internal.
function fsp__frame_strap(_run, _b, _lit, _dark, _k) {
    var _x0 = _run[0] + (_run[3] ? 0 : _b * 0.5), _y0 = _run[1] + (_run[4] ? 0 : _b * 0.5);
    var _x1 = _run[0] + _run[3] * _run[2] + (_run[3] ? 0 : _b * 0.5), _y1 = _run[1] + _run[4] * _run[2] + (_run[4] ? 0 : _b * 0.5);
    fsp_seg(_x0, _y0, _x1, _y1, max(1.2 * _k, _b * 0.16), fsp_col(_dark));
    fsp_seg(_x0 + 1.4 * _k, _y0 + 1.4 * _k, _x1 + 1.4 * _k, _y1 + 1.4 * _k, max(_k, _b * 0.10), fsp_col(_lit));
}

/// @function fsp__boss(x, y, rad, lit, dark, base)
/// @description A domed boss with a sunk centre, lit from the upper left. Internal.
function fsp__boss(_x, _y, _rad, _lit, _dark, _base) {
    fsp_ellipse_grad(_x, _y, _rad, _rad, 0, _x - _rad, _y - _rad, _x + _rad, _y + _rad, [[0, fsp_col(_lit), 1], [0.6, fsp_col(_base), 1], [1, fsp_col(_dark), 1]]);
    fsp_ellipse_grad(_x, _y, _rad * 0.42, _rad * 0.42, 0, _x - _rad * 0.4, _y - _rad * 0.4, _x + _rad * 0.4, _y + _rad * 0.4, fsp_stops2(fsp_col(_dark), fsp_col(_lit)));
}

/// @function fsp__frame_corners(spec, L, lit, dark, k)
/// @description No continuous border: four cut corner pieces, each an L with the lead ornament in its angle. Internal.
function fsp__frame_corners(_spec, _L, _lit, _dark, _k) {
    var _rc = _L.frame_rect, _b = _L.band, _arm = min(_rc.w, _rc.h) * 0.18;
    var _sets = [[1, 1], [-1, 1], [1, -1], [-1, -1]];
    for (var _i = 0; _i < 4; _i++) {
        var _sx = _sets[_i][0], _sy = _sets[_i][1];
        var _x = (_sx > 0) ? _rc.x : _rc.x + _rc.w, _y = (_sy > 0) ? _rc.y : _rc.y + _rc.h;
        var _pts = [[_x + _sx * _b * 0.4, _y + _sy * (_b * 0.4 + _arm)], [_x + _sx * _b * 0.4, _y + _sy * _b * 0.4], [_x + _sx * (_b * 0.4 + _arm), _y + _sy * _b * 0.4]];
        fsp_polyline(_pts, max(1.4 * _k, _b * 0.20), fsp_col(_dark));
        fsp_polyline(fsp_shift(_pts, 1.5 * _k, 1.5 * _k), max(_k, _b * 0.12), fsp_col(_lit));
        fsp_plate_ornament(_spec.ornaments[0], _x + _sx * (_b * 0.4 + _arm * 0.30), _y + _sy * (_b * 0.4 + _arm * 0.30), _arm * 0.30, arctan2(_sy, _sx) - pi / 2, _lit, _dark, _k);
    }
}

// ---------------------------------------------------------------------------------------------------------------
// ORNAMENT
// ---------------------------------------------------------------------------------------------------------------

/// @function fsp_lobe_ring(kind, len, wid)
/// @description One of the five lobe shapes every fleuron is built from, as a ring in a local space where the lobe
/// grows along +x from the origin. Pure.
///   disc   ONE radius (`wid` ignored: four "discs" with a separate half-width fused into a smudge)
///   spike  a straight taper to a real point - the only member with a point, so it cannot be mistaken for a lobe
///   curl   a spiral hook as a tapering band, so it reads as a scroll rather than a comma
///   bud    a blunt petal
///   leaf   a pointed leaf
function fsp_lobe_ring(_kind, _len, _wid) {
    var _o = [], _i;
    switch (_kind) {
        case "disc":
            var _rr = _len * 0.5;
            for (_i = 0; _i < 16; _i++) { var _a = _i / 16 * 2 * pi; array_push(_o, [_rr + cos(_a) * _rr, sin(_a) * _rr]); }
            return _o;
        case "spike":
            return [[0, -_wid * 0.55], [_len * 0.55, -_wid * 0.30], [_len, 0], [_len * 0.55, _wid * 0.30], [0, _wid * 0.55]];
        case "curl":
            var _inner = [], _outer = [];
            for (_i = 0; _i <= 22; _i++) {
                var _t = _i / 22, _ang = _t * 2 * pi * 1.35, _r2 = _len * (1 - 0.72 * _t), _th = _wid * (1 - 0.85 * _t);
                var _cx = _len * 0.55 + cos(_ang) * _r2 * 0.55, _cy = sin(_ang) * _r2 * 0.55;
                array_push(_inner, [_cx, _cy - _th * 0.5]); array_push(_outer, [_cx, _cy + _th * 0.5]);
            }
            for (_i = array_length(_outer) - 1; _i >= 0; _i--) array_push(_inner, _outer[_i]);
            return _inner;
        case "bud":
            return fsp_smooth([[0, 0], [_len * 0.30, -_wid * 0.86], [_len * 0.72, -_wid], [_len, 0], [_len * 0.72, _wid], [_len * 0.30, _wid * 0.86]], 6, true);
        default:   // leaf
            return fsp_smooth([[0, 0], [_len * 0.34, -_wid * 0.78], [_len * 0.74, -_wid * 0.52], [_len, 0], [_len * 0.74, _wid * 0.52], [_len * 0.34, _wid * 0.78]], 6, true);
    }
}

/// @function fsp_radial_width(lobe, n)
/// @description The widest a radial lobe may be and still READ as one of N lobes: adjacent lobes of length L are
/// separated at their widest by about L * sin(pi / N), so a half-width above that fuses the set into one lump.
/// DERIVED from the count, so changing a count cannot silently fuse the shape again. Pure.
function fsp_radial_width(_lobe, _n) {
    if (_lobe.kind == "disc") return _lobe.len * 0.5;
    return min(_lobe.wid, 1.05 * (_lobe.len * 0.5) * sin(pi / max(2, _n)));
}

/// @function fsp__place(ring, ox, oy, ang)
/// @description A local ring rotated by ang and moved to (ox, oy). Internal, pure.
function fsp__place(_ring, _ox, _oy, _ang) {
    var _c = cos(_ang), _s = sin(_ang), _n = array_length(_ring), _o = array_create(_n);
    for (var _i = 0; _i < _n; _i++) _o[_i] = [_ox + _ring[_i][0] * _c - _ring[_i][1] * _s, _oy + _ring[_i][0] * _s + _ring[_i][1] * _c];
    return _o;
}

/// @function fsp__relief_fill(ring, cx, cy, rad, off, lit, dark)
/// @description Fill one ring in relief: a dark copy offset down-right behind it, then a face graded from the lamp.
/// Internal.
function fsp__relief_fill(_ring, _cx, _cy, _rad, _off, _lit, _dark) {
    fsp_fill_rings([fsp_shift(_ring, _off, _off)], fsp_col(_dark));
    fsp_fill_rings([_ring], c_white, 1, { x0: _cx - _rad, y0: _cy - _rad, x1: _cx + _rad, y1: _cy + _rad,
        stops: fsp_stops2(fsp_col(_lit), fsp_col(fsp_mix(_lit, _dark, 0.66))) });
}

/// @function fsp_plate_ornament(id, cx, cy, rad, rot, lit, dark, k)
/// @description Draw one fleuron from its CONSTRUCTION (a stem with lobes at stations, or lobes arranged radially),
/// never from a traced outline. `lit` and `dark` are [r, g, b]. Returns the number of marks drawn (0 for an unknown id),
/// so a caller can prove it did something.
function fsp_plate_ornament(_id, _cx, _cy, _rad, _rot, _lit, _dark, _k) {
    var _o = fsp_find(fsp_ornaments(), _id);
    if (!is_struct(_o) || _rad <= 0) return 0;
    var _s = _rad * _o.weight, _off = max(_k, _rad * 0.075), _marks = 0, _i, _j;
    if (_o.radial > 0) {
        for (_i = 0; _i < _o.radial; _i++) {
            var _a = _o.phase + _i / _o.radial * 2 * pi;
            var _lb = (is_struct(_o.alt) && (_i mod 2) == 1) ? _o.alt : _o.lobe;
            var _ring = fsp_lobe_ring(_lb.kind, _lb.len * _s, fsp_radial_width(_lb, _o.radial) * _s);
            fsp__relief_fill(fsp__place(_ring, _cx, _cy, _a + _rot), _cx, _cy, _rad, _off, _lit, _dark);
            _marks++;
        }
        if (is_struct(_o.centre)) {
            var _cr = fsp_lobe_ring(_o.centre.kind, _o.centre.size * _s * 2, _o.centre.size * _s);
            fsp__relief_fill(fsp__place(_cr, _cx - _o.centre.size * _s, _cy, 0), _cx, _cy, _rad, _off, _lit, _dark);
            _marks++;
        }
        return _marks;
    }
    // Stem construction: the spine first, as a tapering band, so lobes grow OUT of it rather than sitting beside it.
    var _cr2 = cos(_rot), _sr2 = sin(_rot), _ctrl = [];
    for (_i = 0; _i < array_length(_o.stem); _i++) {
        var _u = (_o.stem[_i][0] - 0.5) * 2 * _s, _v = (_o.stem[_i][1] - 0.5) * 2 * _s;
        array_push(_ctrl, [_cx + _u * _cr2 - _v * _sr2, _cy + _u * _sr2 + _v * _cr2]);
    }
    var _pts = fsp_smooth(_ctrl, 9, false), _np = array_length(_pts);
    var _left = [], _right = [], _w0 = max(1.1 * _k, _s * 0.085);
    for (_i = 0; _i < _np; _i++) {
        var _t = _i / (_np - 1), _pa = _pts[max(0, _i - 1)], _pb = _pts[min(_np - 1, _i + 1)];
        var _dx = _pb[0] - _pa[0], _dy = _pb[1] - _pa[1], _m = max(0.0001, sqrt(_dx * _dx + _dy * _dy));
        var _hw = _w0 * (1 - 0.72 * _t) * 0.5;
        array_push(_left, [_pts[_i][0] - _dy / _m * _hw, _pts[_i][1] + _dx / _m * _hw]);
        array_push(_right, [_pts[_i][0] + _dy / _m * _hw, _pts[_i][1] - _dx / _m * _hw]);
    }
    for (_i = array_length(_right) - 1; _i >= 0; _i--) array_push(_left, _right[_i]);
    fsp__relief_fill(_left, _cx, _cy, _rad, _off, _lit, _dark);
    _marks++;
    for (_i = 0; _i < array_length(_o.lobes); _i++) {
        var _lo = _o.lobes[_i];
        var _idx = min(_np - 1, round(_lo.t * (_np - 1)));
        var _p = _pts[_idx], _q0 = _pts[max(0, _idx - 1)], _q1 = _pts[min(_np - 1, _idx + 1)];
        var _base = arctan2(_q1[1] - _q0[1], _q1[0] - _q0[0]);
        var _sides = (_lo.one == 1) ? [1] : [1, -1];
        for (_j = 0; _j < array_length(_sides); _j++) {
            var _lr = fsp_lobe_ring(_lo.kind, _lo.len * _s, _lo.wid * _s * 0.5);
            for (var _m2 = 0; _m2 < array_length(_lr); _m2++) _lr[_m2] = [_lr[_m2][0], _lr[_m2][1] * _sides[_j]];
            fsp__relief_fill(fsp__place(_lr, _p[0], _p[1], _base + _sides[_j] * _lo.tilt), _cx, _cy, _rad, _off, _lit, _dark);
            _marks++;
        }
    }
    if (is_struct(_o.tip)) {
        var _pe = _pts[_np - 1], _pd = _pts[max(0, _np - 2)];
        var _tr = fsp_lobe_ring(_o.tip.kind, _o.tip.len * _s, _o.tip.wid * _s * 0.5);
        fsp__relief_fill(fsp__place(_tr, _pe[0], _pe[1], arctan2(_pe[1] - _pd[1], _pe[0] - _pd[0])), _cx, _cy, _rad, _off, _lit, _dark);
        _marks++;
    }
    return _marks;
}

/// @function fsp__rule(x, y, w, lit, dark, k)
/// @description A plain two-tone rule. Internal.
function fsp__rule(_x, _y, _w, _lit, _dark, _k) {
    fsp_seg(_x, _y, _x + _w, _y, 1.6 * _k, fsp_col(_dark));
    fsp_seg(_x, _y + 1.4 * _k, _x + _w, _y + 1.4 * _k, 1.0 * _k, fsp_col(_lit));
}

/// @function fsp__taper_rule(x, y, len, dir, lit, dark, k)
/// @description A rule that tapers to nothing - a printer's tailpiece. Internal.
function fsp__taper_rule(_x, _y, _len, _dir, _lit, _dark, _k) {
    var _top = [], _bot = [];
    for (var _i = 0; _i <= 24; _i++) {
        var _t = _i / 24, _h = 2.6 * _k * (1 - _t) * (1 - _t);
        array_push(_top, [_x + _dir * _len * _t, _y - _h]); array_push(_bot, [_x + _dir * _len * _t, _y + _h]);
    }
    for (var _j = array_length(_bot) - 1; _j >= 0; _j--) array_push(_top, _bot[_j]);
    fsp_fill_rings([_top], c_white, 1, { x0: _x, y0: _y - 3 * _k, x1: _x, y1: _y + 3 * _k, stops: fsp_stops2(fsp_col(_lit), fsp_col(_dark)) });
}

/// @function fsp_plate_vignette(spec, L, k)
/// @description Draw the device composed from the game's own words. ⛔ SYMMETRY MEANS REPEATING ONE UNIT, NOT SHUFFLING
/// THREE: cycling three units through a four-fold lozenge read as scattered debris; real ornament repeats a unit and
/// puts a second shape at the CENTRE. Returns units drawn.
function fsp_plate_vignette(_spec, _L, _k) {
    var _g = fsp_find(fsp_grounds(), _spec.ground), _box = _L.vignette;
    if (_box.h < 12 * _k || _box.w < 24 * _k) return 0;
    var _lit = fsp_separate(_spec.accent, _g.base, 54), _dark = fsp_relief(_g.base, -1, 46);
    var _cx = _box.x + _box.w * 0.5, _cy = _box.y + _box.h * 0.52, _rad = min(_box.h * 0.50, _box.w * 0.20);
    var _ids = _spec.ornaments, _n = 0, _i, _id1 = (array_length(_ids) > 1) ? _ids[1] : _ids[0];
    switch (_spec.vignette) {
        case "wreath":
            // THE COUNT IS DERIVED FROM THE RING, NOT TYPED (a typed 12 made a dense tangle).
            var _rr = min(_box.h * 0.46, _box.w * 0.26), _unit = _rad * 0.40;
            var _count = clamp(floor(2 * pi * _rr / (_unit * 2.35)), 4, 14);
            for (_i = 0; _i < _count; _i++) {
                var _a = _i / _count * 2 * pi;
                fsp_plate_ornament(_ids[_i mod 2], _cx + cos(_a) * _rr, _cy + sin(_a) * _rr * 0.74, _unit, _a + pi / 2, _lit, _dark, _k);
                _n++;
            }
            break;
        case "lozenge":
            for (_i = 0; _i < 4; _i++) {
                var _la = pi / 4 + _i * pi / 2;
                fsp_plate_ornament(_id1, _cx + cos(_la) * _rad * 1.34, _cy + sin(_la) * _rad * 1.02, _rad * 0.78, _la + pi / 2, _lit, _dark, _k);
                _n++;
            }
            fsp_plate_ornament(_ids[0], _cx, _cy, _rad * 0.52, 0, _lit, _dark, _k);
            _n++;
            break;
        case "band":
            // ⛔ An ODD count, never fewer than three: a band alternates two charges, and an even count (star, wave) has no
            // centre - on a narrow box it drew one of each, off balance. The pitch is re-derived from the count.
            var _fit = fsp_repeats_for(_box.w * 0.86, _rad, 1.9, _rad * 0.5);
            var _bc = max(3, (_fit.count mod 2 == 0) ? _fit.count + 1 : _fit.count), _bp = _box.w * 0.86 / _bc, _ur = min(_rad * 0.62, _bp * 0.34);
            for (_i = 0; _i < _bc; _i++) {
                fsp_plate_ornament(_ids[_i mod 2], _box.x + _box.w * 0.07 + (_i + 0.5) * _bp, _cy, _ur, (_i mod 2) ? pi : 0, _lit, _dark, _k);
                _n++;
            }
            fsp__rule(_box.x + _box.w * 0.04, _cy + _rad * 0.72, _box.w * 0.92, _lit, _dark, _k);
            break;
        case "crest":
            // Solved against the BOX it lives in (built in units of `rad` it ran onto the menu): one charge repeated
            // and crowned, rows of three, two, one.
            var _rows = [3, 2, 1], _baseY = _box.y + _box.h * 0.92;
            var _pitch = min(_rad * 0.80, _box.h * 0.78 / 3), _u = min(_rad * 0.52, _pitch * 0.62, _box.w * 0.62 / 3 / 1.34);
            var _y = _baseY - _u;
            for (var _ri = 0; _ri < 3; _ri++) {
                var _kk = _rows[_ri], _apex = (_kk == 1);
                for (_i = 0; _i < _kk; _i++) {
                    fsp_plate_ornament(_apex ? _id1 : _ids[0], _cx + (_i - (_kk - 1) * 0.5) * _u * 2.45, _y, _apex ? _u * 1.30 : _u, 0, _lit, _dark, _k);
                    _n++;
                }
                _y -= _pitch;
            }
            fsp__rule(_box.x + _box.w * 0.12, _baseY + 2 * _k, _box.w * 0.76, _lit, _dark, _k);
            break;
        case "rule":
            fsp_plate_ornament(_ids[0], _cx, _cy, _rad * 0.95, 0, _lit, _dark, _k);
            _n++;
            fsp__taper_rule(_box.x + _box.w * 0.02, _cy, _box.w * 0.40, 1, _lit, _dark, _k);
            fsp__taper_rule(_box.x + _box.w * 0.98, _cy, _box.w * 0.40, -1, _lit, _dark, _k);
            break;
        default:   // spray
            fsp_plate_ornament(_ids[0], _cx, _cy, _rad, 0, _lit, _dark, _k);
            _n++;
            for (var _sd = -1; _sd <= 1; _sd += 2) {
                for (_i = 0; _i < 3; _i++) {
                    fsp_plate_ornament(_id1, _cx + _sd * _rad * (1.30 + _i * 1.15), _cy + abs(_i - 1) * _rad * 0.20, _rad * (0.56 - _i * 0.11), _sd * (0.5 + _i * 0.22) + pi / 2, _lit, _dark, _k);
                    _n++;
                }
            }
            break;
    }
    return _n;
}

// ---------------------------------------------------------------------------------------------------------------
// CARTOUCHE + WORDMARK
// ---------------------------------------------------------------------------------------------------------------

/// @function fsp_plate_title_geom(spec, L, state, k)
/// @description Where the cartouche and the wordmark go: {cart, panel, face, lit, dark, inner, title_h, cap_h, fits,
/// coverage, fallback, subtitle}. The panel is sized to the TITLE on a wide screen (a four-letter word does not get an
/// edge-to-edge banner), never below 55% of the working width. Pure.
function fsp_plate_title_geom(_spec, _L, _state, _k) {
    var _g = fsp_find(fsp_grounds(), _spec.ground), _cart = fsp_find(fsp_cartouches(), _spec.cartouche), _box = _L.title;
    var _head = _L.head_h, _ph = max(10 * _k, _box.h - _head);
    var _sub = (is_struct(_state) && variable_struct_exists(_state, "subtitle") && is_string(_state.subtitle)) ? _state.subtitle : "";
    var _pad_y = _ph * 0.16, _share = (_sub != "") ? 0.26 : 0;
    var _title_h = (_ph - 2 * _pad_y) * (1 - _share), _cap_max = _title_h * 0.86;
    var _nat = fsp_alpha_measure(_spec.title, _spec.hand, _cap_max);
    var _pw = clamp(_nat / max(0.2, 1 - 2 * _cart.pad) + _box.w * 0.04, _box.w * 0.55, _box.w);
    var _panel = { x: _box.x + (_box.w - _pw) * 0.5, y: _box.y + _head, w: _pw, h: _ph };
    // A RAISED wordmark stands on a face DARKER than itself, or letters and panel arrive at the same value.
    var _face = _cart.sunk ? fsp_relief(_g.base, -1, 22) : fsp_relief(_g.base, (_spec.cut == "raised") ? -1 : 1, 18);
    var _pad_x = _panel.w * _cart.pad;
    var _inner = { x: _panel.x + _pad_x, y: _panel.y + _pad_y, w: _panel.w - 2 * _pad_x, h: _panel.h - 2 * _pad_y };
    var _cov = fsp_alpha_coverage(_spec.title, _spec.hand);
    var _fit = fsp_alpha_fit(_spec.title, _spec.hand, _inner.w, _cap_max, 14 * _k);
    return { cart: _cart, panel: _panel, head_h: _head, face: _face, lit: fsp_relief(_g.base, 1, 34), dark: fsp_relief(_g.base, -1, 42), inner: _inner,
        title_h: _title_h, cap_h: min(_fit.cap_h, _cap_max), fits: _fit.fits, coverage: _cov.ratio, fallback: _cov.ratio < 0.6, missing: _cov.missing, subtitle: _sub };
}

/// @function fsp_plate_panel(spec, geom, k)
/// @description Draw the cartouche - the field the wordmark is set in - without the letters.
function fsp_plate_panel(_spec, _gm, _k) {
    var _p = _gm.panel, _face = _gm.face, _lit = _gm.lit, _dark = _gm.dark, _i;
    var _fc = fsp_col(_face), _lc = fsp_col(_lit), _dc = fsp_col(_dark);
    switch (_gm.cart.id) {
        case "tablet":
            var _ch = min(_p.w, _p.h) * 0.035;
            fsp_rect(_p.x, _p.y, _p.w, _p.h, _fc);
            // Sunk: the light falls on the LOWER-RIGHT of a hollow - the reverse of a raised plate.
            fsp_rect_stroke_grad(_p.x + _ch * 0.5, _p.y + _ch * 0.5, _p.w - _ch, _p.h - _ch, _ch, _p.x, _p.y, _p.x + _p.w, _p.y + _p.h, _gm.cart.sunk ? fsp_stops2(_dc, _lc) : fsp_stops2(_lc, _dc));
            break;
        case "lozenge":
            var _c = min(_p.w, _p.h) * 0.16;
            var _ring = [[_p.x + _c, _p.y], [_p.x + _p.w - _c, _p.y], [_p.x + _p.w, _p.y + _p.h * 0.5], [_p.x + _p.w - _c, _p.y + _p.h], [_p.x + _c, _p.y + _p.h], [_p.x, _p.y + _p.h * 0.5]];
            fsp_fill_rings([_ring], _fc);
            fsp_stroke_grad(_ring, max(2 * _k, min(_p.w, _p.h) * 0.030), true, _p.x, _p.y, _p.x + _p.w, _p.y + _p.h, fsp_stops2(_lc, _dc));
            break;
        case "scroll":
            var _roll = _p.w * 0.055;
            fsp_rect(_p.x + _roll, _p.y, _p.w - 2 * _roll, _p.h, _fc);
            for (_i = 0; _i < 2; _i++) {
                var _x = _i ? _p.x + _p.w - _roll * 2 : _p.x;
                fsp_rect_grad(_x, _p.y - _p.h * 0.03, _roll * 2, _p.h * 1.06, _x, _p.y, _x + _roll * 2, _p.y, [[0, _dc, 1], [_i ? 0.45 : 0.55, _lc, 1], [1, _dc, 1]]);
                // the sheet throws a shadow under each curl
                var _sx = _i ? _x - _roll * 0.6 : _x + _roll * 2;
                fsp_rect_grad(_sx, _p.y, _roll * 0.6, _p.h, _sx, _p.y, _sx + _roll * 0.6, _p.y, _i ? fsp_stops2(_dc, _dc, 0, 0.55) : fsp_stops2(_dc, _dc, 0.55, 0));
            }
            fsp__rule(_p.x + _roll * 2.4, _p.y + _p.h * 0.06, _p.w - _roll * 4.8, _lit, _dark, _k);
            fsp__rule(_p.x + _roll * 2.4, _p.y + _p.h * 0.94, _p.w - _roll * 4.8, _lit, _dark, _k);
            break;
        case "pediment":
            var _hh = _gm.head_h;
            if (_hh > 4 * _k) {
                var _tri = [[_p.x - _p.w * 0.02, _p.y], [_p.x + _p.w * 0.5, _p.y - _hh], [_p.x + _p.w * 1.02, _p.y]];
                fsp_fill_rings([_tri], c_white, 1, { x0: _p.x, y0: _p.y - _hh, x1: _p.x + _p.w, y1: _p.y, stops: fsp_stops2(_lc, fsp_col(fsp_mix(_face, _dark, 0.5))) });
                fsp_polyline(_tri, max(1.6 * _k, _p.w * 0.006), _dc, 1, true);
                fsp__rule(_p.x - _p.w * 0.02, _p.y - 2 * _k, _p.w * 1.04, _lit, _dark, _k);
            }
            fsp_rect(_p.x, _p.y, _p.w, _p.h, _fc);
            var _pc = min(_p.w, _p.h) * 0.030;
            fsp_rect_stroke_grad(_p.x + _pc * 0.5, _p.y + _pc * 0.5, _p.w - _pc, _p.h - _pc, _pc, _p.x, _p.y, _p.x + _p.w, _p.y + _p.h, fsp_stops2(_dc, _lc));
            break;
        case "banderole":
            var _tail = _p.w * 0.07, _dip = _p.h * 0.13;
            for (_i = 0; _i < 2; _i++) {
                var _tx = _i ? _p.x + _p.w - _tail : _p.x;
                var _tr = _i ? [[_tx, _p.y + _dip], [_tx + _tail, _p.y], [_tx + _tail, _p.y + _p.h], [_tx, _p.y + _p.h - _dip]]
                             : [[_tx + _tail, _p.y + _dip], [_tx, _p.y], [_tx, _p.y + _p.h], [_tx + _tail, _p.y + _p.h - _dip]];
                fsp_fill_rings([_tr], c_white, 1, { x0: _tx, y0: _p.y, x1: _tx + _tail, y1: _p.y + _p.h, stops: fsp_stops2(fsp_col(fsp_mix(_face, _dark, 0.55)), fsp_col(fsp_mix(_face, _dark, 0.15))) });
            }
            var _main = [[_p.x + _tail * 0.8, _p.y + _dip * 0.4], [_p.x + _p.w - _tail * 0.8, _p.y + _dip * 0.4], [_p.x + _p.w - _tail * 0.8, _p.y + _p.h - _dip * 0.4], [_p.x + _tail * 0.8, _p.y + _p.h - _dip * 0.4]];
            fsp_fill_rings([_main], c_white, 1, { x0: _p.x, y0: _p.y, x1: _p.x, y1: _p.y + _p.h,
                stops: [[0, fsp_col(fsp_mix(_face, _lit, 0.35)), 1], [0.5, _fc, 1], [1, fsp_col(fsp_mix(_face, _dark, 0.30)), 1]] });
            fsp_polyline(_main, max(1.4 * _k, _p.w * 0.004), _dc, 1, true);
            break;
        default:   // open
            fsp__rule(_p.x + _p.w * 0.06, _p.y + _p.h * 0.10, _p.w * 0.88, _lit, _dark, _k);
            fsp__rule(_p.x + _p.w * 0.06, _p.y + _p.h * 0.92, _p.w * 0.88, _lit, _dark, _k);
            break;
    }
}

/// @function fsp_plate_letters(spec, geom, k, [fallback_font])
/// @description CUT the wordmark (and letter the subtitle) into the cartouche. Returns {cap_h, glyphs, boxes, width,
/// fallback, coverage, missing, subtitle_fits}. A title the corpus cannot cut (<60% coverage) is lettered in
/// `fallback_font` with the same cut and separation - never in a stock face.
function fsp_plate_letters(_spec, _gm, _k, _fb_font = fnt_frontispiece_title) {
    var _in = _gm.inner, _cap = _gm.cap_h;
    var _base_y = _in.y + _cap + (_gm.title_h - _cap) * 0.52, _m;
    if (!_gm.fallback) {
        var _w = fsp_alpha_measure(_spec.title, _spec.hand, _cap);
        _m = fsp_alpha_draw_line(_spec.title, { x: _in.x + (_in.w - _w) * 0.5, base_y: _base_y, cap_h: _cap, hand: _spec.hand, cut: _spec.cut, ground: _gm.face, ink: _spec.ink, delta: 64 });
    } else {
        _m = fsp_alpha_draw_line_font(_spec.title, { x: _in.x + _in.w * 0.5, base_y: _base_y, cap_h: _cap * 0.82, hand: _spec.hand, cut: _spec.cut, ground: _gm.face, ink: _spec.ink, delta: 64, font: _fb_font });
    }
    _m.subtitle_fits = true;
    _m.sub_rect = undefined;
    if (_gm.subtitle != "") {
        var _px = max(11 * _k, _cap * 0.24), _track = _cap * 0.10;
        var _f = fsp_fit_tracked(_gm.subtitle, _in.w * 0.9, _px, _track, 10 * _k, fnt_frontispiece);
        if (_f.fits) {
            var _sw = _f.width, _sy = _in.y + _in.h - _in.h * 0.06 - _f.px * 0.80, _sx = _in.x + (_in.w - _sw) * 0.5;
            fsp_tracked(_sx, _sy, _gm.subtitle, _f.px, _f.track, fsp_col(fsp_separate(_spec.ink, _gm.face, 44)), fnt_frontispiece);
            _m.sub_rect = { x: _sx - _f.px * 0.2, y: _sy - _f.px * 0.1, w: _sw + _f.px * 0.4, h: _f.px * 1.35 };
        }
        _m.subtitle_fits = _f.fits;
    }
    _m.cap_h = _cap; _m.fallback = _gm.fallback; _m.coverage = _gm.coverage;
    return _m;
}

/// @function fsp_plate_imprint(spec, L, box, imprint, k)
/// @description The small line at the foot - a studio name, a version, a year. Dropped (never clipped) if it cannot fit.
/// Returns true when it was drawn.
function fsp_plate_imprint(_spec, _L, _box, _imprint, _k) {
    if (!is_string(_imprint) || _imprint == "") return false;
    var _g = fsp_find(fsp_grounds(), _spec.ground);
    var _px = max(10 * _k, min(_box.h, _box.w) * 0.020), _f = fsp_fit_tracked(_imprint, _L.work.w * 0.8, _px, _px * 0.34, 9 * _k, fnt_frontispiece);
    if (!_f.fits) return false;
    fsp_tracked(_L.work.x + (_L.work.w - _f.width) * 0.5, _L.imprint_y - _f.px * 0.80, _imprint, _f.px, _f.track, fsp_col(fsp_separate(_spec.ink, _g.base, 30)), fnt_frontispiece);
    return true;
}

// ---------------------------------------------------------------------------------------------------------------
// THE MENU - the house's own furniture, never a stock window
// ---------------------------------------------------------------------------------------------------------------

/// @function fsp_plate_menu_rects(L, n, k)
/// @description The row rectangles of an n-row menu: [{x, y, w, h}, ...], the row pitch SOLVED from the menu box with
/// a gap, so the last row can never land past the frame. The same rects are what a mouse hit-tests against. Pure.
function fsp_plate_menu_rects(_L, _n, _k) {
    var _box = _L.menu, _out = [];
    if (_n <= 0) return _out;
    var _gap = _box.h * 0.055, _rh = max(14 * _k, (_box.h - _gap * (_n - 1)) / _n);
    for (var _i = 0; _i < _n; _i++) array_push(_out, { x: _box.x, y: _box.y + _i * (_rh + _gap), w: _box.w, h: _rh });
    return _out;
}

/// @function fsp_plate_menu(spec, L, commands, enabled, index, k, [lift])
/// @description Draw the command list with row `index` chosen (-1 for none). `lift` (0..1, default 1) is how far the
/// chosen row has come into its chosen state, for the transition. Returns {rows, row_h}.
function fsp_plate_menu(_spec, _L, _cmds, _en, _index, _k, _lift = 1) {
    var _n = is_array(_cmds) ? array_length(_cmds) : 0;
    if (_n == 0) return { rows: 0, row_h: 0 };
    var _g = fsp_find(fsp_grounds(), _spec.ground);
    var _lit = fsp_relief(_g.base, 1, 32), _dark = fsp_relief(_g.base, -1, 40), _accent = fsp_separate(_spec.accent, _g.base, 42);
    var _rects = fsp_plate_menu_rects(_L, _n, _k), _rh = _rects[0].h;
    var _px0 = max(12 * _k, min(_rh * 0.44, _L.menu.w * 0.075));
    for (var _i = 0; _i < _n; _i++) {
        var _b = _rects[_i], _sel = (_i == _index), _on = !(is_array(_en) && _i < array_length(_en) && _en[_i] == false);
        var _face = _g.base;
        switch (_spec.menu) {
            case "plaques": _face = fsp__menu_plaques(_b, _sel, _lit, _dark, _g, _accent, _k); break;
            case "rules": _face = fsp__menu_rules(_b, _sel, _lit, _dark, _g, _accent, _spec, _k); break;
            case "tabs": _face = fsp__menu_tabs(_b, _sel, _lit, _dark, _g, _accent, _k); break;
            case "column": _face = fsp__menu_column(_b, _sel, _lit, _dark, _accent, _i, _n, _k); break;
            case "cartouches": _face = fsp__menu_cartouches(_b, _sel, _lit, _dark, _g, _accent, _k); break;
            default: _face = fsp__menu_slots(_b, _sel, _lit, _dark, _g, _accent, _k); break;
        }
        // The label's ink is SOLVED against the face it lands on. The accent is a CANDIDATE, not a decision - painting
        // the chosen row in the accent once made it the LEAST readable line on the screen - and the chosen row solves
        // for a higher separation than the rest.
        var _ink = _sel ? fsp_separate(fsp_pick_contrast(_face, [_accent, _spec.ink]), _face, 68) : fsp_separate(_spec.ink, _face, 52);
        if (!_on) _ink = fsp_mix(_ink, _face, 0.55);
        var _name = is_string(_cmds[_i]) ? _cmds[_i] : string(_cmds[_i]);
        var _f = fsp_fit_tracked(_name, _b.w * 0.72, _px0, _px0 * 0.20, 10 * _k, fnt_frontispiece);
        var _tx = _b.x + (_b.w - _f.width) * 0.5 + ((_spec.menu == "plaques" && _sel) ? 0 : 0);
        var _ty = _b.y + _b.h * 0.5 - _f.px * 0.62 - ((_spec.menu == "plaques" && _sel) ? _b.h * 0.06 : 0);
        fsp_tracked(_tx + _k, _ty + _k, _name, _f.px, _f.track, fsp_col(fsp_relief(_face, -1, 26)), fnt_frontispiece);
        fsp_tracked(_tx, _ty, _name, _f.px, _f.track, fsp_col(_ink), fnt_frontispiece);
    }
    return { rows: _n, row_h: _rh };
}

/// @function fsp__menu_slots(b, sel, lit, dark, g, accent, k)
/// @description Sunk slots; the chosen one deepens and takes a pair of cut markers. Returns the face colour. Internal.
/// ⛔ The chosen slot sits 32 luminance levels below the others, not 16: at 16 on dark slate the chosen row moved 52
/// pixels at 640 x 360 (two small markers) and read as unchosen - the suite's "the chosen row visibly moves" went red.
function fsp__menu_slots(_b, _sel, _lit, _dark, _g, _accent, _k) {
    var _face = _sel ? fsp_relief(_g.base, -1, 44) : fsp_relief(_g.base, -1, 12);
    fsp_rect(_b.x, _b.y, _b.w, _b.h, fsp_col(_face));
    var _ch = max(2 * _k, _b.h * 0.10);
    fsp_rect_stroke_grad(_b.x + _ch * 0.5, _b.y + _ch * 0.5, _b.w - _ch, _b.h - _ch, _ch, _b.x, _b.y, _b.x + _b.w, _b.y + _b.h, fsp_stops2(fsp_col(_dark), fsp_col(_lit)));
    if (_sel) {
        for (var _s = 0; _s < 2; _s++) {
            var _x = _s ? _b.x + _b.w - _b.h * 0.36 : _b.x + _b.h * 0.36;
            fsp_fill_rings([[[_x, _b.y + _b.h * 0.28], [_x + (_s ? -1 : 1) * _b.h * 0.28, _b.y + _b.h * 0.5], [_x, _b.y + _b.h * 0.72]]], fsp_col(_accent));
        }
    }
    return _face;
}

/// @function fsp__menu_plaques(b, sel, lit, dark, g, accent, k)
/// @description Raised bevelled plaques; the chosen one lifts, throws a shadow and takes an accent bar. Internal.
function fsp__menu_plaques(_b, _sel, _lit, _dark, _g, _accent, _k) {
    var _face = _sel ? fsp_relief(_g.base, 1, 26) : fsp_relief(_g.base, 1, 10);
    var _off = _sel ? _b.h * 0.06 : 0;
    if (_sel) fsp_rect(_b.x + _off, _b.y + _off, _b.w, _b.h, fsp_col(_dark), 0.55);
    fsp_rect(_b.x, _b.y - _off, _b.w, _b.h, fsp_col(_face));
    var _ch = max(2 * _k, _b.h * 0.11);
    fsp_rect_stroke_grad(_b.x + _ch * 0.5, _b.y - _off + _ch * 0.5, _b.w - _ch, _b.h - _ch, _ch, _b.x, _b.y - _off, _b.x + _b.w, _b.y - _off + _b.h, fsp_stops2(fsp_col(_lit), fsp_col(_dark)));
    if (_sel) fsp_rect(_b.x + _ch, _b.y - _off + _ch, _b.w - 2 * _ch, max(1.4 * _k, _b.h * 0.05), fsp_col(_accent));
    return _face;
}

/// @function fsp__menu_rules(b, sel, lit, dark, g, accent, spec, k)
/// @description No panel: a hairline under each; the chosen one takes a full rule and flanking ornaments. Internal.
function fsp__menu_rules(_b, _sel, _lit, _dark, _g, _accent, _spec, _k) {
    var _y = _b.y + _b.h * 0.86;
    if (_sel) {
        fsp__rule(_b.x, _y, _b.w, _accent, _dark, _k);
        var _id = (array_length(_spec.ornaments) > 1) ? _spec.ornaments[1] : _spec.ornaments[0];
        for (var _s = 0; _s < 2; _s++) {
            fsp_plate_ornament(_id, _s ? _b.x + _b.w * 0.97 : _b.x + _b.w * 0.03, _b.y + _b.h * 0.48, _b.h * 0.22, _s ? pi / 2 : -pi / 2, _accent, _dark, _k);
        }
    } else fsp_seg(_b.x + _b.w * 0.16, _y, _b.x + _b.w * 0.84, _y, _k, fsp_col(_dark), 0.55);
    return _g.base;
}

/// @function fsp__menu_tabs(b, sel, lit, dark, g, accent, k)
/// @description Angled tabs off a spine; the chosen one runs out and takes an accent edge. Internal.
function fsp__menu_tabs(_b, _sel, _lit, _dark, _g, _accent, _k) {
    var _face = _sel ? fsp_relief(_g.base, 1, 24) : fsp_relief(_g.base, -1, 12);
    var _skew = _b.h * 0.42, _out = _sel ? _b.w * 0.06 : 0;
    var _ring = [[_b.x - _out, _b.y], [_b.x + _b.w + _out, _b.y], [_b.x + _b.w + _out - _skew, _b.y + _b.h], [_b.x - _out + _skew, _b.y + _b.h]];
    fsp_fill_rings([_ring], fsp_col(_face));
    fsp_stroke_grad(_ring, max(1.6 * _k, _b.h * 0.07), true, _b.x, _b.y, _b.x + _b.w, _b.y + _b.h, fsp_stops2(fsp_col(_lit), fsp_col(_dark)));
    if (_sel) fsp_fill_rings([[[_b.x - _out, _b.y], [_b.x - _out + _skew * 0.34, _b.y], [_b.x - _out + _skew, _b.y + _b.h], [_b.x - _out + _skew * 0.66, _b.y + _b.h]]], fsp_col(_accent));
    return _face;
}

/// @function fsp__menu_column(b, sel, lit, dark, accent, i, n, k)
/// @description A ruled column with a cut chevron that marks the chosen row. Internal.
function fsp__menu_column(_b, _sel, _lit, _dark, _accent, _i, _n, _k) {
    var _spine = _b.x - _b.w * 0.10;
    if (_i == 0) {
        fsp_seg(_spine, _b.y - _b.h * 0.3, _spine, _b.y + _b.h * 1.24 * _n, 2.2 * _k, fsp_col(_dark));
        fsp_seg(_spine + 1.6 * _k, _b.y - _b.h * 0.3, _spine + 1.6 * _k, _b.y + _b.h * 1.24 * _n, 1.2 * _k, fsp_col(_lit));
    }
    var _face = _sel ? fsp_mix(_dark, _lit, 0.34) : _dark;
    if (_sel) {
        fsp_rect_grad(_b.x, _b.y, _b.w, _b.h, _b.x, _b.y, _b.x + _b.w, _b.y, fsp_stops2(fsp_col(_accent), fsp_col(_accent), 0.30, 0.02));
        fsp_fill_rings([[[_spine + 4 * _k, _b.y + _b.h * 0.28], [_spine + 4 * _k + _b.h * 0.30, _b.y + _b.h * 0.5], [_spine + 4 * _k, _b.y + _b.h * 0.72]]], fsp_col(_accent));
    }
    fsp_seg(_b.x, _b.y + _b.h, _b.x + _b.w, _b.y + _b.h, _k, fsp_col(_dark), _sel ? 0.9 : 0.35);
    return _face;
}

/// @function fsp__menu_cartouches(b, sel, lit, dark, g, accent, k)
/// @description Each command in a miniature cut-cornered cartouche; the chosen one lifts and takes the accent edge.
/// Internal.
function fsp__menu_cartouches(_b, _sel, _lit, _dark, _g, _accent, _k) {
    var _face = _sel ? fsp_relief(_g.base, 1, 22) : fsp_relief(_g.base, -1, 12);
    var _c = _b.h * 0.34;
    var _ring = [[_b.x + _c, _b.y], [_b.x + _b.w - _c, _b.y], [_b.x + _b.w, _b.y + _b.h * 0.5], [_b.x + _b.w - _c, _b.y + _b.h], [_b.x + _c, _b.y + _b.h], [_b.x, _b.y + _b.h * 0.5]];
    fsp_fill_rings([_ring], fsp_col(_face));
    fsp_stroke_grad(_ring, max(1.4 * _k, _b.h * 0.06), true, _b.x, _b.y, _b.x + _b.w, _b.y + _b.h, _sel ? fsp_stops2(fsp_col(_accent), fsp_col(_dark)) : fsp_stops2(fsp_col(_lit), fsp_col(_dark)));
    return _face;
}

// ---------------------------------------------------------------------------------------------------------------
// THE WHOLE SCREEN
// ---------------------------------------------------------------------------------------------------------------

/// @function fsp_plate_draw(spec, box, state, k, [parts])
/// @description Draw a whole title screen into the current target. state: {subtitle, imprint, commands, enabled, index,
/// fallback_font}. `parts` (a struct of booleans, all true by default): {ground, frame, panel, letters, vignette,
/// imprint, menu} - the screen builds its reveal layers by drawing some of them. Returns a report:
/// {layout, geom, title (letters metrics or undefined), vignette_units, imprint, menu}.
function fsp_plate_draw(_spec, _box, _state, _k, _parts = undefined) {
    var _st = is_struct(_state) ? _state : {};
    var _p = is_struct(_parts) ? _parts : {};
    var _on = function(_pp, _name) { return !variable_struct_exists(_pp, _name) || _pp[$ _name]; };
    var _L = fsp_plate_layout(_box, _spec, _st, _k);
    var _gm = fsp_plate_title_geom(_spec, _L, _st, _k);
    var _rep = { layout: _L, geom: _gm, title: undefined, vignette_units: 0, imprint: false, menu: { rows: 0, row_h: 0 } };
    if (_on(_p, "ground")) fsp_plate_ground(_spec, _box, _k);
    if (_on(_p, "frame")) fsp_plate_frame(_spec, _L, _k);
    if (_on(_p, "panel")) fsp_plate_panel(_spec, _gm, _k);
    if (_on(_p, "imprint")) _rep.imprint = fsp_plate_imprint(_spec, _L, _box, variable_struct_exists(_st, "imprint") ? _st.imprint : "", _k);
    if (_on(_p, "letters")) _rep.title = fsp_plate_letters(_spec, _gm, _k, variable_struct_exists(_st, "fallback_font") ? _st.fallback_font : fnt_frontispiece_title);
    if (_on(_p, "vignette")) _rep.vignette_units = fsp_plate_vignette(_spec, _L, _k);
    if (_on(_p, "menu")) _rep.menu = fsp_plate_menu(_spec, _L, variable_struct_exists(_st, "commands") ? _st.commands : [],
        variable_struct_exists(_st, "enabled") ? _st.enabled : [], variable_struct_exists(_st, "index") ? _st.index : 0, _k);
    return _rep;
}
