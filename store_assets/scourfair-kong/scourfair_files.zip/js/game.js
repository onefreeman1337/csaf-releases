/**
 * game.js - SCOURFAIR: layout (two shapes), drawing, input, save/resume and the loop. Every number on screen is read
 * from SIM (sim.js) and the view from the road is drawn by VALE (vale.js); this file decides nothing about the hill.
 *
 * Two logical surfaces, chosen by the viewport's aspect: WIDE 960x600 and TALL 360x640 (one logical pixel is one CSS
 *   pixel on the smallest upright phone that picks it; its type has a FLOOR of 10 and every shrink loop stops there).
 *   The canvas element keeps the surface's aspect (CSS aspect-ratio from --ar), so a tap maps with ONE scale on both axes.
 * Save/resume, never a restart: autosave on every action, every event and every 5 s; the hill keeps greying while you
 *   are away (settled as arithmetic, up to one season) and a line says what happened.
 * No key is ever preventDefault-ed except the arrow keys and Space, so they never scroll the host page: Tab is never
 *   taken, so the embed never traps it.
 */
'use strict';

(function () {
  var cv = document.getElementById('cv');
  var g = cv.getContext('2d');
  var SAVE_KEY = 'scourfair.down.v1';
  var VERSION = '1.0.0';
  var SHAPES = { wide: { W: 960, H: 600 }, tall: { W: 360, H: 640 } };
  var KEYS = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'];
  var shape = 'wide', W = 960, H = 600;
  var SW = SIM.W, SH = SIM.H;

  var C = {
    bg: '#14161a', panel: '#1d2125', panelEdge: '#4c5a52', ink: '#f2efe4', inkDim: '#d2cdbd', inkFaint: '#a6a796',
    gold: '#e8c66a', good: '#a8dc8a', alarm: '#ff8a68', btn: '#262c2d', btnOn: '#3d5240', btnEdge: '#7b8a7c', chalk: '#efece0',
  };
  var SERIF = '"SF Display", Georgia, "Times New Roman", serif';
  var UI = '"SF Body", "Trebuchet MS", Verdana, sans-serif';
  /* the bundled faces are asked for up front, so the first frames measure with the real type rather than the fallback */
  var fontsReady = false;
  (function () {
    var done = function () { fontsReady = true; };
    try {
      if (!document.fonts || !document.fonts.load) { done(); return; }
      Promise.all([document.fonts.load('400 40px "SF Display"', 'SCOURFAIR'), document.fonts.load('500 16px "SF Body"'), document.fonts.load('800 16px "SF Body"')]).then(done, done);
      setTimeout(done, 4000);
    } catch (e) { done(); }
  })();
  var PLATE_KEYS = ['down', 'chalk', 'rammed', 'scrub'];
  var PLATES = {}, platesReady = 0;
  PLATE_KEYS.forEach(function (k) {
    var img = new Image();
    img.onload = function () { try { PLATES[k] = g.createPattern(img, 'repeat'); if (k === 'down' || k === 'chalk') VALE.setPlate(k, img); platesReady++; valeCache = {}; } catch (e) { /* keep the flat colour */ } };
    img.src = 'art/plate_' + k + '.png';
  });
  var FLAT = { down: '#5a8040', chalk: '#ece9dc', rammed: '#f4f2ea', scrub: '#3f5530' };

  var state = {
    screen: 'title', o: null, tab: 'hill', t: 0, speed: 1, help: false, credits: false, confirmNewUntil: 0, lastSaveReal: 0,
    eventsSeen: 0, toast: [], toastQ: [], cut: 0, hill: 0, tool: 'scour', brush: 1, hoverCell: -1, cursor: -1, dust: [],
    upPage: 0, recPage: 0, undo: [], drag: null,
  };

  /* ---------------------------------------------------------------- save */
  var saveFailSaid = false;
  function save() {
    if (!state.o) return;
    try { localStorage.setItem(SAVE_KEY, JSON.stringify({ v: 1, savedAt: Date.now(), paused: !!state.userPaused, o: state.o })); }
    catch (e) { if (!saveFailSaid) { saveFailSaid = true; toast('This browser is blocking saves. Progress will not persist.', 'bad'); } }
  }
  function num(x) { return typeof x === 'number' && isFinite(x); }
  function isObj(x) { return !!x && typeof x === 'object' && !Array.isArray(x); }
  function cellsOk(arr, lo, hi) { if (!Array.isArray(arr) || arr.length !== SW * SH) return false; for (var i = 0; i < arr.length; i++) if (!num(arr[i]) || arr[i] < lo || arr[i] > hi) return false; return true; }
  function validHill(h) { return isObj(h) && cellsOk(h.mask, 0, 1) && cellsOk(h.white, 0, 1) && cellsOk(h.lost, 0, 1) && cellsOk(h.kerb, 0, 1) && cellsOk(h.ram, 0, SIM.YEAR_DAYS * 4); }
  function valid(a) {
    if (!isObj(a) || a.v !== 1) return false;
    if (!num(a.t) || a.t < 0 || !num(a.funds) || a.funds < -1e6 || a.funds > 1e13 || !num(a.earned) || a.earned < 0 || !num(a.seed) || !num(a.scourers) || a.scourers < 1 || a.scourers > 9) return false;
    if (!isObj(a.levels) || !isObj(a.stats) || !Array.isArray(a.events) || !Array.isArray(a.fairs) || !Array.isArray(a.hills) || a.hills.length !== 2) return false;
    for (var k in a.levels) if (!SIM.UPGRADES[k] || a.levels[k] !== 1) return false;
    if (!validHill(a.hills[0]) || !(a.hills[1] === null || validHill(a.hills[1]))) return false;
    if (a.fair !== null && a.fair !== undefined && (!isObj(a.fair) || !num(a.fair.crowd))) return false;
    for (var e = 0; e < a.events.length; e++) { var ev = a.events[e]; if (!isObj(ev) || typeof ev.kind !== 'string' || typeof ev.msg !== 'string') return false; }
    for (var f = 0; f < a.fairs.length; f++) { var fr = a.fairs[f]; if (!isObj(fr) || !num(fr.year) || !Array.isArray(fr.mask) || !Array.isArray(fr.white)) return false; }
    return true;
  }
  function load() {
    try {
      var raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return null;
      var d = JSON.parse(raw);
      if (!d || !valid(d.o)) return null;
      return d;
    } catch (e) { return null; }
  }
  function hasSave() { try { return !!localStorage.getItem(SAVE_KEY); } catch (e) { return false; } }

  /* the message line is clocked to the GAME as well as the wall: a queued message older than STALE_DAYS of hill time is
   * dropped rather than shown as if it were news */
  var TOAST_MIN = 2.5, STALE_DAYS = 4;
  function toastMin() { return TOAST_MIN / Math.sqrt(state.speed || 1); }
  function hillT() { return state.o ? state.o.t : 0; }
  function toast(msg, kind, queued) {
    var top = state.toast[0];
    /* repeats merge only within 8 s of the FIRST one (the window restarted on every repeat, so a daily press
     * counted up to "x151") */
    if (top && top.base === msg && state.t - (top.first || top.at) < 8) { top.n++; top.msg = msg + ' x' + top.n; top.at = state.t; return; }
    for (var q = 0; q < state.toastQ.length; q++) if (state.toastQ[q].base === msg) return;
    var item = { msg: msg, base: msg, n: 1, kind: kind || 'info', at: state.t, first: state.t, sim: hillT() };
    if (queued && top && state.t - top.at < toastMin()) { state.toastQ.push(item); if (state.toastQ.length > 6) state.toastQ.shift(); return; }
    state.toast.unshift(item); if (state.toast.length > 4) state.toast.pop();
  }
  function note(msg, kind) { toast(msg, kind, true); }
  function toastTick() {
    if (!state.toastQ.length) return;
    var top = state.toast[0];
    if (top && state.t - top.at < toastMin()) return;
    var now = hillT(), next = null;
    while (state.toastQ.length) { var cand = state.toastQ.shift(), age = now - (cand.sim || now); if (age <= STALE_DAYS * (cand.kind === 'bad' ? 2 : 1)) { next = cand; break; } }
    if (!next) return;
    next.at = state.t;
    state.toast.unshift(next); if (state.toast.length > 4) state.toast.pop();
  }
  function MIN() { return shape === 'tall' ? 10 : 9; }
  function fs(n) { return shape === 'tall' ? Math.max(10, n) : n; }
  function cap1(s) { s = String(s); return s.charAt(0).toUpperCase() + s.slice(1); }
  function sent(s) { return String(s).replace(/[.\s]+$/, ''); }
  function fmt(n) { var neg = n < 0; n = Math.floor(Math.abs(n)); var s = n >= 1e6 ? (n / 1e6).toFixed(2) + 'M' : n >= 1e4 ? Math.round(n / 1000) + 'k' : String(n); return neg ? '-' + s : s; }
  function pct(x) { return Math.round(x * 100) + '%'; }
  function hash(n) { return SIM.hash(n); }

  /* -------------------------------------------------------------- layout */
  var TAP_TALL = 30;
  function L() {
    if (shape === 'wide') return {
      top: { x: 0, y: 0, w: 960, h: 52 }, strip: { x: 8, y: 56, w: 544, h: 26 }, map: { x: 8, y: 84, cs: 17 },
      side: { x: 560, y: 56, w: 392, h: 334 }, panel: { x: 8, y: 394, w: 944, h: 156 }, bottom: { x: 0, y: 552, w: 960, h: 48 },
    };
    return {
      top: { x: 0, y: 0, w: 360, h: 76 }, strip: { x: 4, y: 78, w: 352, h: 32 }, map: { x: 4, y: 112, cs: 11 },
      side: null, panel: { x: 4, y: 314, w: 352, h: 258 }, bottom: { x: 0, y: 574, w: 360, h: 66 },
    };
  }
  function mapRect() { var r = L().map; return { x: r.x, y: r.y, w: r.cs * SW, h: r.cs * SH, cs: r.cs }; }
  function cellRect(x, y, r) { r = r || mapRect(); return { x: r.x + x * r.cs, y: r.y + y * r.cs, w: r.cs, h: r.cs }; }
  function cellAt(px, py) {
    var r = mapRect();
    if (px < r.x || py < r.y || px >= r.x + r.w || py >= r.y + r.h) return -1;
    return Math.floor((py - r.y) / r.cs) * SW + Math.floor((px - r.x) / r.cs);
  }

  /* ------------------------------------------------------------- drawing */
  var buttons = [];
  function T(s, x, y, size, col, align, weight, family) {
    g.font = (weight || '400') + ' ' + size + 'px ' + (family || UI);
    g.textAlign = align || 'left'; g.textBaseline = 'alphabetic';
    g.fillStyle = col || C.ink;
    g.fillText(s, x, y);
    return g.measureText(s).width;
  }
  function tw(s, size, weight, family) { g.font = (weight || '400') + ' ' + size + 'px ' + (family || UI); return g.measureText(s).width; }
  function rr(x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
  function btn(id, x, y, w, h, label, enabled, on, sub, why, grp) {
    var b = { id: id, x: x, y: y, w: w, h: h, label: label, enabled: enabled !== false, on: !!on, sub: sub, why: why, grp: grp || null };
    buttons.push(b); return b;
  }
  function overlayUp() { var a = state.o; return state.screen !== 'play' || !a || state.help || state.credits || state.userPaused || (a.won && !a.endingSeen); }
  function keyGroup() { if (state.screen === 'title' && !state.help && !state.credits) return 'title'; if (overlayUp()) return null; return 'tab'; }
  /* the number keys press the buttons of the open panel; a panel with more buttons than keys is PAGED (0 turns it) */
  function keyedButtons() {
    var g0 = keyGroup(); if (!g0 || !state.keysSeen) { state.keyPages = 1; return []; }
    var list = buttons.filter(function (b) { return b.grp === g0; });
    var sig = g0 + '|' + state.tab + '|' + state.screen + '|' + shape + '|' + list.length;
    if (state.keySig !== sig) { state.keySig = sig; state.keyPage = 0; }
    /* keys 1-9 press buttons and 0 only ever turns the page, as the help says (with exactly ten buttons, 0
     * pressed the tenth, which on a phone was QUICK SCOUR, spending the day's hands) */
    if (list.length <= 9) { state.keyPages = 1; state.keyPage = 0; return list; }
    var pages = Math.ceil(list.length / 9), p = Math.min(state.keyPage || 0, pages - 1);
    state.keyPages = pages; state.keyPage = p;
    return list.slice(p * 9, p * 9 + 9);
  }
  function keysPaged() { return state.keysSeen && (state.keyPages || 1) > 1 && !!keyGroup(); }
  var hoverPt = null;
  function btnAt(x, y) { for (var i = buttons.length - 1; i >= 0; i--) { var b = buttons[i]; if (x >= b.x && x < b.x + b.w && y >= b.y && y < b.y + b.h) return b; } return null; }
  function hoverNow() { return hoverPt ? btnAt(hoverPt.x, hoverPt.y) : null; }
  function drawButtons() {
    var hb = hoverNow(), keyed = keyedButtons(), mn = MIN();
    for (var i = 0; i < buttons.length; i++) {
      var b = buttons[i];
      if (b.silent) continue;
      g.fillStyle = !b.enabled ? '#1c2021' : b.on ? C.btnOn : (b === hb ? '#343c3b' : C.btn);
      g.strokeStyle = b.on ? C.gold : b.enabled ? C.btnEdge : '#3d4643';
      g.lineWidth = b.on ? 2 : 1;
      rr(b.x, b.y, b.w, b.h, 5); g.fill(); g.stroke();
      if (b.edge) { g.fillStyle = b.edge; g.fillRect(b.x + 1, b.y + 4, 3, b.h - 8); }
      var ki = keyed.indexOf(b), label = b.label ? (ki >= 0 ? KEYS[ki] + '  ' + b.label : b.label) : '';
      b.drawnLabel = label;
      var dim = '#878b80', cx = b.x + b.w / 2, f = fs(b.h >= 30 ? 12 : 11);
      while (f > mn && label && tw(label, f, '700') > b.w - 10) f--;
      if (b.sub2) {
        var s1 = fs(10), s2 = fs(10), gp = 2, tot = f + s1 + s2 + 2 * gp, y0 = b.y + (b.h - tot) / 2;
        while (s1 > mn && tw(b.sub, s1) > b.w - 8) s1--;
        while (s2 > mn && tw(b.sub2, s2) > b.w - 8) s2--;
        T(label, cx, y0 + f * 0.82, f, b.enabled ? C.ink : dim, 'center', '700');
        T(b.sub, cx, y0 + f + gp + fs(10) * 0.82, s1, b.enabled ? (b.subCol || C.gold) : dim, 'center', '400');
        T(b.sub2, cx, y0 + f + gp + fs(10) + gp + fs(10) * 0.82, s2, b.enabled ? (b.sub2Col || C.inkDim) : (b.sub2Col || dim), 'center', '400');
      } else {
        if (label) T(label, cx, b.y + (b.sub ? b.h / 2 - 2 : b.h / 2 + f * 0.36), f, b.enabled ? C.ink : dim, 'center', '700');
        if (b.sub) { var fsub = fs(10); while (fsub > mn && tw(b.sub, fsub) > b.w - 8) fsub--; T(b.sub, cx, b.y + b.h / 2 + fs(10) + 1, fsub, b.enabled ? (b.subCol || C.gold) : dim, 'center', '400'); }
      }
    }
  }
  function lines(s, w) { var words = s.split(' '), line = '', n = 0; for (var i = 0; i < words.length; i++) { var tst = line ? line + ' ' + words[i] : words[i]; if (g.measureText(tst).width > w && line) { n++; line = words[i]; } else line = tst; } return n + (line ? 1 : 0); }
  function wrapText(s, x, y, w, size, col, weight, lh, maxY, align) {
    g.font = (weight || '400') + ' ' + size + 'px ' + UI;
    var words = s.split(' '), line = '';
    for (var i = 0; i < words.length; i++) {
      var tst = line ? line + ' ' + words[i] : words[i];
      if (g.measureText(tst).width > w && line) { if (maxY && y > maxY) { state.cut = 1; return y; } T(line, x, y, size, col, align || 'left', weight); y += lh; line = words[i]; }
      else line = tst;
    }
    if (line) { if (maxY && y > maxY) { state.cut = 1; return y; } T(line, x, y, size, col, align || 'left', weight); y += lh; }
    return y;
  }
  function fitSize(s, w, h, size, min, weight) { for (var sz = size; sz >= min; sz--) { g.font = (weight || '400') + ' ' + sz + 'px ' + UI; if (lines(s, w) * (sz + 3) <= h) return sz; } return 0; }
  function fitWrap(s, x, y, w, h, size, minSize, col, weight, align) {
    var sz = fitSize(s, w, h, size, minSize, weight) || minSize;
    return wrapText(s, x, y + sz, w, sz, col, weight, sz + 3, undefined, align);
  }
  /* one line, shrunk to the floor to fit w; returns its drawn width */
  function T1(s, x, y, w, size, col, align, weight, family) { var f = size; while (f > MIN() && tw(s, f, weight, family) > w) f--; return T(s, x, y, f, col, align, weight, family); }
  function frame(x, y, w, h) { g.fillStyle = C.panel; rr(x, y, w, h, 8); g.fill(); g.strokeStyle = C.panelEdge; g.lineWidth = 1; g.stroke(); }
  function plate(k, x, y, w, h) { g.fillStyle = PLATES[k] || FLAT[k]; g.fillRect(x, y, w, h); }

  /* ------------------------------------------------------------ the vale */
  var valeCache = {};
  /* the view from the road into a small buffer, re-drawn when its signature (hills, season, fair, light) moves or a
   * quarter second has passed (for the clouds and the travellers); scaled up nearest-neighbour by the caller */
  function vale(key, LW, LH, o) {
    var c = valeCache[key];
    if (!c) { var cnv = document.createElement('canvas'); cnv.width = LW; cnv.height = LH; c = valeCache[key] = { cnv: cnv, ctx: cnv.getContext('2d'), img: null, at: -1, sig: '' }; c.img = c.ctx.createImageData(LW, LH); }
    var sig = (o.sig || '') + '|' + o.season + '|' + o.light + '|' + (o.fair || 0) + '|' + platesReady;
    if (c.sig !== sig || state.t - c.at > 0.25) { VALE.render(c.img, LW, LH, o); c.ctx.putImageData(c.img, 0, 0); c.sig = sig; c.at = state.t; }
    return c.cnv;
  }
  function hillSig(a) { var s = 0; for (var k = 0; k < 2; k++) { var h = a && a.hills[k]; if (!h) continue; for (var i = 0; i < h.mask.length; i += 3) s += h.mask[i] * (1 + Math.round(h.white[i] * 8)) * ((i % 97) + 1); } return String(s); }
  function valeOpts(a, light) {
    var tr = a ? SIM.fame(a) * 1.2 : 30;
    return { hills: a ? a.hills : [SIM.newDown(4242).hills[0], null], W: SW, H: SH, LINE: SIM.LINE, season: a ? SIM.season(a) : 0, light: light, t: state.t, travellers: tr, fair: a && a.fair ? a.fair.crowd : 0, seed: a ? a.seed : 7, sig: hillSig(a) };
  }
  function drawVale(key, LW, LH, o, x, y, w, h) {
    var c = vale(key, LW, LH, o);
    g.imageSmoothingEnabled = false; g.drawImage(c, x, y, w, h); g.imageSmoothingEnabled = true;
  }

  /* -------------------------------------------------------------- the hill */
  function turfN(h, i) { return SIM.turfNeighbours(h, i); }
  /* a few grass tufts on a greying cell, on the sides that face the turf: the creep is drawn coming IN from the edge */
  function tufts(h, i, c, w) {
    var n = Math.round((1 - w) * 7); if (n <= 0) return;
    var x = i % SW, y = Math.floor(i / SW), s = c.w / 17;
    var sides = [];
    if (x > 0 && !h.mask[i - 1]) sides.push(0); if (x < SW - 1 && !h.mask[i + 1]) sides.push(1); if (y > 0 && !h.mask[i - SW]) sides.push(2); if (y < SH - 1 && !h.mask[i + SW]) sides.push(3);
    if (!sides.length) sides = [0, 1, 2, 3];
    g.fillStyle = w < SIM.LINE ? '#5f8a3e' : '#6e9a48';
    for (var k = 0; k < n; k++) {
      var sd = sides[k % sides.length], r1 = hash(i * 31 + k * 7), r2 = hash(i * 17 + k * 13) * (0.35 + (1 - w) * 0.5);
      var px = sd === 0 ? r2 : sd === 1 ? 1 - r2 : r1, py = sd === 2 ? r2 : sd === 3 ? 1 - r2 : r1;
      var tx = c.x + px * (c.w - 3 * s), ty = c.y + py * (c.h - 3 * s);
      g.fillRect(tx, ty + s, 1.2 * s, 2 * s); g.fillRect(tx + 1.2 * s, ty, 1.2 * s, 3 * s);
    }
  }
  /* the cut: where a figure cell meets turf, the chalk is a trench cut into the down, lit on its upper left edges and in
   * shadow on its lower right, so the figure stands out of the turf instead of lying on it like tiles; a cell under the
   * line keeps only a faint dark rim, the line it used to draw */
  function relief(h, i, c, w) {
    var x = i % SW, y = Math.floor(i / SW), t = Math.max(1, c.w * 0.12);
    var turf = function (X, Y) { return X < 0 || Y < 0 || X >= SW || Y >= SH || !h.mask[Y * SW + X]; };
    var lo = w >= SIM.LINE ? 0.42 : 0.22, hi = w >= SIM.LINE ? 0.38 : 0.1;
    g.fillStyle = 'rgba(28,40,20,' + lo + ')';
    if (turf(x + 1, y)) g.fillRect(c.x + c.w - t, c.y, t, c.h);
    if (turf(x, y + 1)) g.fillRect(c.x, c.y + c.h - t, c.w, t);
    g.fillStyle = 'rgba(255,252,240,' + hi + ')';
    if (turf(x - 1, y)) g.fillRect(c.x, c.y, 1, c.h);
    if (turf(x, y - 1)) g.fillRect(c.x, c.y, c.w, 1);
  }
  function kerbEdges(h, i, c) {
    var x = i % SW, y = Math.floor(i / SW), t = Math.max(2, c.w * 0.16);
    var out = function (X, Y) { return X < 0 || Y < 0 || X >= SW || Y >= SH || !h.mask[Y * SW + X]; };
    g.fillStyle = '#7a5530';
    if (out(x - 1, y)) g.fillRect(c.x, c.y, t, c.h); if (out(x + 1, y)) g.fillRect(c.x + c.w - t, c.y, t, c.h);
    if (out(x, y - 1)) g.fillRect(c.x, c.y, c.w, t); if (out(x, y + 1)) g.fillRect(c.x, c.y + c.h - t, c.w, t);
    g.fillStyle = '#b08250';
    if (out(x, y - 1)) g.fillRect(c.x, c.y, c.w, 1); if (out(x - 1, y)) g.fillRect(c.x, c.y, 1, c.h);
  }
  function drawHillAt(a, k, r, now, opts) {
    opts = opts || {};
    var h = a.hills[k];
    plate('down', r.x, r.y, r.w, r.h);
    /* the slope: the steep middle of the down sheds chalk faster, so it is drawn a shade darker */
    for (var y = 0; y < SH; y++) { var sl = SIM.SLOPE[y]; g.fillStyle = 'rgba(10,20,8,' + ((sl - 0.8) * 0.16).toFixed(3) + ')'; g.fillRect(r.x, r.y + y * r.cs, r.w, r.cs); }
    /* the season over the turf (spring lush, summer straw, autumn olive, winter frost) and the morning light from the
     * upper left, so the board changes with the year as the vale does */
    var se = SIM.season(a);
    g.fillStyle = ['rgba(120,170,80,0.06)', 'rgba(240,210,120,0.10)', 'rgba(190,120,50,0.12)', 'rgba(225,235,255,0.16)'][se]; g.fillRect(r.x, r.y, r.w, r.h);
    if (!h) return;
    var fresh = k === 1 && a.cutting;
    for (var i = 0; i < SW * SH; i++) {
      if (!h.mask[i]) continue;
      var c = cellRect(i % SW, Math.floor(i / SW), r), w = h.white[i];
      /* a cell just cut on an open cutting is RAW CHALK, dirty with turf, not grass: the drawing must read as a shape the
       * moment it is drawn (new cuts were drawn as turf with an orange box, so a figure could not be seen) */
      if (fresh && w < SIM.LINE) { plate('chalk', c.x, c.y, c.w, c.h); g.fillStyle = 'rgba(112,96,70,' + (0.62 - w * 0.6).toFixed(3) + ')'; g.fillRect(c.x, c.y, c.w, c.h); }
      else if (w < 0.15) { plate('scrub', c.x, c.y, c.w, c.h); g.globalAlpha = 0.3 + Math.min(1, w * 4) * 0.4; plate('chalk', c.x, c.y, c.w, c.h); g.globalAlpha = 1; }
      else if (w < SIM.LINE) { plate('down', c.x, c.y, c.w, c.h); g.globalAlpha = 0.3 + w * 1.1; plate('chalk', c.x, c.y, c.w, c.h); g.globalAlpha = 1; }
      else { plate(h.ram[i] > 0 ? 'rammed' : 'chalk', c.x, c.y, c.w, c.h); g.fillStyle = 'rgba(96,128,70,' + ((1 - w) * 0.62).toFixed(3) + ')'; g.fillRect(c.x, c.y, c.w, c.h); }
      if (w < 0.97 && !(fresh && w < SIM.LINE)) tufts(h, i, c, w);
      relief(h, i, c, w);
      if (h.kerb[i]) kerbEdges(h, i, c);
    }
    /* the cutting: faint pegs at the grid's corners, so the hill reads as a page to draw on without a ruled grid over it */
    if (k === 1 && a.cutting && !opts.noGrid) {
      g.fillStyle = 'rgba(240,236,220,0.22)';
      for (var gx = 1; gx < SW; gx++) for (var gy = 1; gy < SH; gy++) g.fillRect(r.x + gx * r.cs - 0.5, r.y + gy * r.cs - 0.5, 1.5, 1.5);
    }
    var lg = g.createLinearGradient(r.x, r.y, r.x + r.w, r.y + r.h); lg.addColorStop(0, 'rgba(255,244,214,0.10)'); lg.addColorStop(0.55, 'rgba(255,244,214,0)'); lg.addColorStop(1, 'rgba(10,18,10,0.16)');
    g.fillStyle = lg; g.fillRect(r.x, r.y, r.w, r.h);
    if (!opts.noPeople) { drawScourers(a, k, r, now); if (a.fair && k === 0) drawFairOnHill(a, r, now); }
  }
  /* the hired scourers, each on the next stretch of the round they will re-cut */
  function drawScourers(a, k, r, now) {
    var total = 2 * SW * SH, c0 = SIM.sweepCursor(a), found = [];
    for (var st = 0; st < total && found.length < a.scourers * SIM.REACH; st++) {
      var gi = (c0 + st) % total, kk = gi >= SW * SH ? 1 : 0, i = gi % (SW * SH), h = a.hills[kk];
      if (!h || !h.mask[i] || h.kerb[i] || h.white[i] >= 0.999) continue;
      found.push([kk, i]);
    }
    for (var s = 0; s < a.scourers; s++) {
      var f = found[s * SIM.REACH]; if (!f || f[0] !== k) continue;
      var c = cellRect(f[1] % SW, Math.floor(f[1] / SW), r), sc = r.cs / 17, bob = Math.abs(Math.sin(now * 5 + s * 1.7)) * 2 * sc;
      var bx = c.x + c.w * 0.5, by = c.y + c.h * 0.85;
      g.fillStyle = 'rgba(0,0,0,0.25)'; g.fillRect(bx - 4 * sc, by - 1 * sc, 8 * sc, 2 * sc);
      g.fillStyle = ['#7a3c2e', '#3e4a6e', '#5c5a2c', '#6a3d5e'][s % 4]; g.fillRect(bx - 2.5 * sc, by - 9 * sc, 5 * sc, 7 * sc);
      g.fillStyle = '#e2c4a0'; g.fillRect(bx - 1.6 * sc, by - 12.5 * sc, 3.2 * sc, 3.2 * sc);
      g.fillStyle = '#3a2e22'; g.fillRect(bx - 2.4 * sc, by - 13.5 * sc, 4.8 * sc, 1.4 * sc);
      g.fillStyle = '#9a7a52'; g.fillRect(bx + 2.5 * sc, by - 10 * sc + bob, 1.2 * sc, 8 * sc);
      g.fillStyle = '#c8ccd0'; g.fillRect(bx + 1.8 * sc, by - 2.5 * sc + bob, 2.6 * sc, 2.4 * sc);
    }
  }
  /* a fair: tents along the top of the down and the crowd working round the figure */
  function drawFairOnHill(a, r, now) {
    var sc = r.cs / 17, n = Math.min(60, 8 + Math.round(a.fair.crowd / 30));
    for (var t2 = 0; t2 < 5; t2++) {
      var tx = r.x + r.w * (0.08 + t2 * 0.2), ty = r.y + 6 * sc;
      g.fillStyle = t2 % 2 ? '#c8463a' : '#efe8d8'; g.beginPath(); g.moveTo(tx, ty + 14 * sc); g.lineTo(tx + 9 * sc, ty); g.lineTo(tx + 18 * sc, ty + 14 * sc); g.closePath(); g.fill();
      g.fillStyle = 'rgba(0,0,0,0.2)'; g.fillRect(tx + 7 * sc, ty + 8 * sc, 4 * sc, 6 * sc);
      g.fillStyle = '#c8463a'; g.fillRect(tx + 8.5 * sc, ty - 5 * sc, 1, 5 * sc); g.fillRect(tx + 9.5 * sc, ty - 5 * sc + Math.sin(now * 4 + t2) * sc, 5 * sc, 2.5 * sc);
    }
    var h = a.hills[0];
    for (var p = 0; p < n; p++) {
      var i = Math.floor(hash(p * 977 + a.fair.year) * SW * SH), tries = 0;
      while (tries++ < 12 && (h.mask[i] || turfN(h, i) === 8)) i = (i + 37) % (SW * SH);
      var c = cellRect(i % SW, Math.floor(i / SW), r), jx = Math.sin(now * 1.3 + p) * 2 * sc;
      g.fillStyle = ['#b8463a', '#3c4a80', '#d8b860', '#f0ece0', '#6a3a6a'][p % 5];
      g.fillRect(c.x + c.w * 0.4 + jx, c.y + c.h * 0.3, 3 * sc, 5 * sc);
      g.fillStyle = '#e2c4a0'; g.fillRect(c.x + c.w * 0.4 + jx + 0.4 * sc, c.y + c.h * 0.3 - 2.4 * sc, 2.2 * sc, 2.2 * sc);
    }
  }
  function drawMapOverlay(a, r) {
    /* until the first scour by hand, the three greyest cells of the hill on screen pulse: the first minute's question
     * ("what do I click?") answered on the hill itself */
    if (!a.handTaught && a.t < SIM.YEAR_DAYS && a.hills[state.hill]) {
      var cand = bestCells(a, state.hill).map(function (c) { return c[2]; });
      var pulse = 0.5 + 0.5 * Math.sin(state.t * 5);
      cand.slice(0, 3).forEach(function (ci2) { var q = cellRect(ci2 % SW, Math.floor(ci2 / SW), r); g.strokeStyle = 'rgba(232,198,106,' + (0.45 + 0.5 * pulse).toFixed(3) + ')'; g.lineWidth = 2; g.strokeRect(q.x - 1 - pulse * 2, q.y - 1 - pulse * 2, q.w + 2 + pulse * 4, q.h + 2 + pulse * 4); g.lineWidth = 1; });
    }
    var foc = state.hoverCell >= 0 ? state.hoverCell : state.cursor;
    if (foc >= 0) {
      var cells = brushCells(foc);
      /* a dark ring under a gold one: the keyboard cursor stays visible on white chalk and on dark turf */
      cells.forEach(function (i) { var q = cellRect(i % SW, Math.floor(i / SW), r); g.lineWidth = 4; g.strokeStyle = 'rgba(20,24,18,0.75)'; g.strokeRect(q.x + 1, q.y + 1, q.w - 2, q.h - 2); g.lineWidth = 2; g.strokeStyle = C.gold; g.strokeRect(q.x + 1, q.y + 1, q.w - 2, q.h - 2); g.lineWidth = 1; });
    }
    for (var s = state.dust.length - 1; s >= 0; s--) {
      var d = state.dust[s], age = state.t - d.at; if (age > 0.7 || d.hill !== state.hill) { state.dust.splice(s, 1); continue; }
      var q2 = cellRect(d.i % SW, Math.floor(d.i / SW), r), cx = q2.x + q2.w / 2, cy = q2.y + q2.h / 2;
      for (var p = 0; p < 10; p++) { var an = p * 0.63 + d.i, rad = 3 + age * 30 * (0.6 + hash(p + d.i) * 0.8); g.fillStyle = 'rgba(' + d.col + ',' + (1 - age / 0.7).toFixed(3) + ')'; g.fillRect(cx + Math.cos(an) * rad - 1.5, cy + Math.sin(an) * rad - 1.5 - age * 8, 3, 3); }
      /* the number the click made, rising off the cell (a scour was a tint change and seven specks) */
      if (d.pop) { g.save(); g.globalAlpha = Math.max(0, 1 - age / 0.7); T(d.pop, cx, cy - 6 - age * 22, 12, d.popCol || '#fff7dc', 'center', '700'); g.restore(); }
    }
  }

  /* -------------------------------------------------------------- tools */
  function cutting(a) { return !!(a && a.hills[1] && a.cutting && state.hill === 1); }
  function toolsAvail(a) {
    var t = ['scour'];
    if (a.levels.pit) t.push('ram');
    if (a.levels.kerbs) t.push('kerb');
    if (cutting(a)) t.push('cut', 'erase');
    return t;
  }
  function brushCells(i) {
    if (i < 0) return [];
    if (!(state.tool === 'cut' || state.tool === 'erase') || state.brush <= 1) return [i];
    var x = i % SW, y = Math.floor(i / SW), out = [], b = state.brush, o = b === 2 ? 0 : -1;
    for (var dy = 0; dy < b; dy++) for (var dx = 0; dx < b; dx++) { var X = x + dx + o, Y = y + dy + o; if (X >= 0 && Y >= 0 && X < SW && Y < SH) out.push(Y * SW + X); }
    return out;
  }
  /* a tap that misses (turf, or chalk already white) goes to the greyest figure cell near it: a fingertip covers several
   * cells on a phone, and the nearest grey edge is what the player meant */
  function snap(a, k, i, rad, ok) {
    if (ok(i)) return i;
    var x = i % SW, y = Math.floor(i / SW), best = -1, bw = 2;
    for (var dy = -rad; dy <= rad; dy++) for (var dx = -rad; dx <= rad; dx++) { var X = x + dx, Y = y + dy; if (X < 0 || Y < 0 || X >= SW || Y >= SH) continue; var j = Y * SW + X; if (!ok(j)) continue; var w = a.hills[k].white[j] + 0.02 * (Math.abs(dx) + Math.abs(dy)); if (w < bw) { bw = w; best = j; } }
    return best;
  }
  function applyTool(i, dragging) {
    var a = state.o, k = state.hill, h = a.hills[k], w = '', rad = shape === 'tall' ? 2 : 1, done = 0;
    if (!h) { toast('The second hill is not yours yet: it opens with THE SECOND HILL upgrade.', 'bad'); return; }
    if (state.tool === 'cut' || state.tool === 'erase') {
      var on = state.tool === 'cut';
      var before = a.hills[1] ? a.hills[1].mask.slice() : null;
      brushCells(i).forEach(function (j) { if (!SIM.whyNotCut(a, j, on)) { SIM.cut(a, j, on); done++; } });
      /* an undo step is spent only by a stroke that changed something, and starting a stroke on a cell that is already
       * cut says nothing ("Already cut. x2" when adding a limb from the body) */
      if (done) { if (state.strokeUndo !== false && before) { state.undo.push(before); if (state.undo.length > 30) state.undo.shift(); state.strokeUndo = false; } if (on) AUDIO.scour(); else AUDIO.tick(); save(); }
      else if (!dragging) { w = SIM.whyNotCut(a, i, on); if (w && !/already cut|not cut/.test(w)) toast(cap1(w) + '.', 'info'); }
      return;
    }
    if (state.tool === 'scour') {
      var j = snap(a, k, i, dragging ? 0 : rad, function (q) { return !SIM.whyNotScour(a, k, q); });
      if (j < 0) { if (!dragging) { w = SIM.whyNotScour(a, k, i); toast(cap1(w) + '.', a.handLeft < 1 ? 'bad' : 'info'); AUDIO.thud(); } return; }
      w = SIM.scour(a, k, j); if (w) { if (!dragging) toast(cap1(w) + '.', 'bad'); return; }
      a.handTaught = true;
      state.dust.push({ i: j, at: state.t, hill: k, col: '240,236,222', pop: h.white[j] >= SIM.LINE ? '+50%' : '+50% (still grass)', popCol: h.white[j] >= SIM.LINE ? '#fff7dc' : '#ffcf8a' }); AUDIO.scour(); save(); return;
    }
    if (state.tool === 'ram') {
      var j2 = snap(a, k, i, dragging ? 0 : rad, function (q) { return !SIM.whyNotRam(a, k, q) && h.white[q] < 0.999; });
      if (j2 < 0) j2 = i;
      w = SIM.ram(a, k, j2); if (w) { if (!dragging) { toast(cap1(w) + '.', 'bad'); AUDIO.thud(); } return; }
      state.dust.push({ i: j2, at: state.t, hill: k, col: '255,255,248' }); AUDIO.ram(); save(); return;
    }
    if (state.tool === 'kerb') {
      if (dragging) return;
      var j3 = h.mask[i] && !h.kerb[i] ? i : snap(a, k, i, rad, function (q) { return h.mask[q] && !h.kerb[q] && turfN(h, q) > 0; });
      if (j3 < 0) j3 = i;
      w = SIM.kerb(a, k, j3); if (w) { toast(cap1(w) + '.', 'bad'); AUDIO.thud(); return; }
      state.dust.push({ i: j3, at: state.t, hill: k, col: '176,130,80' }); AUDIO.kerb(); save();
    }
  }
  /* where a hand counts: a scour adds +0.5, so a cell far under the line is still grass by the next dawn, while one just
   * under it crosses back over. Cells under the line closest to it first, then the greyest of the rest (
   * worst-first ended every day of the first spring exactly where doing nothing did) */
  function bestCells(a, onlyHill) {
    var out = [];
    for (var k = 0; k < 2; k++) { if (onlyHill !== undefined && k !== onlyHill) continue; var h = a.hills[k]; if (!h) continue; for (var i = 0; i < SW * SH; i++) if (h.mask[i] && h.white[i] < 0.97) { var w = h.white[i]; out.push([w < SIM.LINE ? SIM.LINE - w : 1 + w, k, i]); } }
    out.sort(function (p, q) { return p[0] - q[0] || p[1] - q[1] || p[2] - q[2]; });
    return out;
  }
  /* the day's hands where they count, on both hills at once: one press does a day's scouring (phone and keys) */
  function scourWorst() {
    var a = state.o, n = 0;
    bestCells(a).some(function (c) { if (a.handLeft < 1) return true; if (!SIM.scour(a, c[1], c[2])) { n++; if (c[1] === state.hill) state.dust.push({ i: c[2], at: state.t, hill: c[1], col: '240,236,222' }); } return false; });
    if (!n) { toast(a.handLeft < 1 ? 'Your hands are done for today: they come back at dawn.' : 'Every cell of the figure is already white.', 'info'); AUDIO.tick(); return; }
    a.handTaught = true;
    AUDIO.scour(); toast('You scoured ' + n + ' cell' + (n > 1 ? 's' : '') + ' by hand, the ones just under the line first.', 'good'); save();
  }
  function cellInfo(a, k, i) {
    var h = a.hills[k]; if (!h) return '';
    var x = i % SW, y = Math.floor(i / SW), where = 'Cell ' + (x + 1) + ', ' + (y + 1) + ': ';
    if (!h.mask[i]) return where + 'downland turf.' + (cutting(a) ? ' CUT it to add it to your figure.' : '');
    var n = turfN(h, i), se = SIM.season(a), rate = h.kerb[i] ? 0 : SIM.CREEP[se] * (n / 8) * SIM.SLOPE[y] * (h.ram[i] > 0 ? SIM.CREEP_RAM : 1);
    return where + 'chalk ' + pct(h.white[i]) + ' white, ' + n + ' of 8 sides turf' + (h.kerb[i] ? ', kerbed: it never greys' : ', greys ' + (rate * 100).toFixed(1) + '% a day in ' + SIM.SEASONS[se].toLowerCase()) + (h.ram[i] > 0 ? ', fresh chalk for ' + Math.ceil(h.ram[i]) + ' more days' : '') + '.';
  }

  /* --------------------------------------------------------------- panels */
  function dateLine(a) { var yd = SIM.yday(a), se = SIM.season(a); return SIM.SEASONS[se] + ' day ' + (yd % SIM.SEASON_LEN + 1) + ' · YEAR ' + SIM.year(a); }
  function roadPerDay(a) { var f = SIM.fame(a); return { trav: f * SIM.TRAVEL_K, toll: f * SIM.TRAVEL_K * SIM.TOLL + (a.fair ? a.fair.crowd * 0.4 : 0) }; }
  function drawTop(a) {
    var t = L().top, wide = shape === 'wide';
    g.fillStyle = 'rgba(14,16,18,0.96)'; g.fillRect(t.x, t.y, t.w, t.h);
    var rd = roadPerDay(a);
    if (wide) {
      var wm = T('SCOURFAIR', 12, 34, 26, C.chalk, 'left', '700', SERIF), x0 = 12 + wm + 18;
      T(dateLine(a), x0, 22, fs(13), C.ink, 'left', '700');
      T1(a.fair ? 'THE FAIR IS ON THE HILL: ' + a.fair.crowd + ' people' : nextFairText(a), x0, 41, 470 - x0, fs(11), a.fair ? C.gold : C.inkFaint, 'left', a.fair ? '700' : '400');
      var stats = [['FUNDS', fmt(a.funds), C.gold], ['FAME', fmt(SIM.fame(a)), C.ink], ['ROAD A DAY', '+' + fmt(rd.toll), C.good]], sx = 470;
      for (var k = 0; k < stats.length; k++) { T(stats[k][0], sx + k * 80, 20, 10, C.inkFaint, 'left', '700'); T(stats[k][1], sx + k * 80, 40, 16, stats[k][2], 'left', '700'); }
      var bx = 712; btn('pause', bx, 10, 56, 32, 'PAUSE'); btn('help', bx + 60, 10, 52, 32, 'HELP'); btn('mute', bx + 116, 10, 62, 32, AUDIO.muted() ? 'MUTED' : 'SOUND', true, AUDIO.muted()); btn('speed', bx + 182, 10, 50, 32, state.speed > 1 ? '3x' : '1x', true, state.speed > 1);
    } else {
      T1('SCOURFAIR', 8, 27, 136, 21, C.chalk, 'left', '700', SERIF);
      btn('pause', 150, 4, 52, TAP_TALL, 'PAUSE'); btn('help', 206, 4, 46, TAP_TALL, 'HELP'); btn('mute', 256, 4, 58, TAP_TALL, AUDIO.muted() ? 'MUTED' : 'SOUND', true, AUDIO.muted()); btn('speed', 318, 4, 38, TAP_TALL, state.speed > 1 ? '3x' : '1x', true, state.speed > 1);
      T1(dateLine(a) + (a.fair ? ' · THE FAIR IS ON' : ''), 8, 52, 344, 12, a.fair ? C.gold : C.ink, 'left', '700');
      var st2 = [['FUNDS', fmt(a.funds), C.gold], ['FAME', fmt(SIM.fame(a)), C.ink], ['ROAD', '+' + fmt(rd.toll) + '/day', C.good]];
      for (var q = 0; q < st2.length; q++) T(st2[q][0] + ' ' + st2[q][1], 8 + q * 112, 70, 11, st2[q][2], 'left', '700');
    }
  }
  function nextFairText(a) {
    if (!a.levels.fair) return 'The scouring fair is not restored yet (an upgrade).';
    var y = SIM.year(a), yd = SIM.yday(a), fy = y % SIM.FAIR_EVERY === 0 && yd < SIM.FAIR_DAY ? y : (Math.floor(y / SIM.FAIR_EVERY) + 1) * SIM.FAIR_EVERY;
    var days = (fy - 1) * SIM.YEAR_DAYS + SIM.FAIR_DAY - SIM.day(a);
    return 'Next fair: summer, year ' + fy + ', in ' + days + (days === 1 ? ' day' : ' days') + '.';
  }
  function hillName(a, k) { return k === 0 ? 'THE OLD HORSE' : 'YOUR FIGURE'; }
  function drawStrip(a) {
    var s = L().strip, wide = shape === 'wide', bh = wide ? 22 : TAP_TALL, by = s.y + (s.h - bh) / 2;
    var has2 = !!a.hills[1];
    var b0 = btn('hill:0', s.x, by, wide ? 130 : 112, bh, 'THE OLD HORSE', true, state.hill === 0, undefined, undefined, 'tab');
    var b1 = btn('hill:1', s.x + (wide ? 136 : 116), by, wide ? 120 : 104, bh, 'YOUR FIGURE', has2, state.hill === 1, undefined, 'the second hill opens with THE SECOND HILL upgrade', 'tab');
    b0.info = 'the first hill: the old horse, cut long ago'; b1.info = has2 ? 'the second hill: the figure you cut' : 'the second hill is not yours yet';
    var h = a.hills[state.hill];
    if (h) {
      var m = SIM.metrics(h), tx = s.x + s.w;
      var txt = wide ? (cutting(a) ? 'CUTTING · ' : '') + 'crisp ' + pct(m.crisp) + ' · ' + m.area + ' cells · edge ' + m.perimeter : (cutting(a) ? 'CUT · ' : '') + pct(m.crisp) + ' crisp';
      T1(txt, tx, by + bh / 2 + 4, s.w - (wide ? 262 : 226), fs(11), m.crisp >= SIM.WIN_CRISP ? C.good : m.crisp < 0.6 ? C.alarm : C.ink, 'right', '700');
    }
  }
  function crispBar(x, y, w, v, line) {
    g.fillStyle = '#2b3230'; g.fillRect(x, y, w, 5);
    g.fillStyle = v >= SIM.WIN_CRISP ? C.good : v >= 0.6 ? C.gold : C.alarm; g.fillRect(x, y, w * Math.max(0, Math.min(1, v)), 5);
    if (line) { g.fillStyle = C.ink; g.fillRect(x + w * SIM.WIN_CRISP, y - 2, 1, 9); }
  }
  /* the side panel: the view from the road, both figures' numbers, the next fair and the great scouring's terms */
  function drawStatus(a, s, valeH) {
    var wide = shape === 'wide', x = s.x + 10, w = s.w - 20, y = s.y + 8;
    var vh = valeH, vw = w;
    drawVale(wide ? 'side' : 'sideT', Math.round(vw / 2), Math.round(vh / 2), valeOpts(a, 'day'), x, y, vw, vh);
    g.strokeStyle = '#6a7a6c'; g.lineWidth = 1; g.strokeRect(x - 0.5, y - 0.5, vw + 1, vh + 1);
    T('FROM THE ROAD', x + 6, y + 14, fs(10), 'rgba(20,24,22,0.9)', 'left', '700');
    y += vh + 8;
    var sz = fs(11), lh = sz + 5;
    /* the tall VALE tab has no room for the per-hill lines: the strip above the hill and the checklist below carry them */
    for (var k = 0; k < 2 && wide; k++) {
      var h = a.hills[k];
      T(hillName(a, k), x, y + sz, sz, k === state.hill ? C.gold : C.ink, 'left', '700');
      if (!h) { T1(a.earned >= SIM.UPGRADES.hill2.earned ? 'THE SECOND HILL is for sale (UPGRADES).' : 'Opens when the hill has earned ' + fmt(SIM.UPGRADES.hill2.earned) + '.', x + w, y + sz, w - 110, sz, C.inkFaint, 'right'); y += lh + 4; continue; }
      var m = SIM.metrics(h), f = SIM.fameOf(a, h);
      T('crisp ' + pct(m.crisp), x + w, y + sz, sz, m.crisp >= SIM.WIN_CRISP ? C.good : C.ink, 'right', '700');
      crispBar(x + 118, y + sz - 6, w - 190, m.crisp, true);
      y += lh;
      T1('fame ' + fmt(f) + ' · ' + m.area + ' cells · detail ' + m.detail.toFixed(2) + ' · edge ' + m.perimeter + (h.kerb.some(function (v) { return v; }) ? ' · ' + h.kerb.filter(function (v) { return v; }).length + ' kerbed' : ''), x, y + sz, w, fs(10), C.inkDim);
      y += lh + 3;
    }
    T1(a.fair ? 'THE FAIR: ' + a.fair.crowd + ' people on the hill, scouring for nothing.' : nextFairText(a), x, y + sz, w, sz, a.fair ? C.gold : C.ink, 'left', '700');
    y += lh + 4;
    if (a.won) { T1('THE GREAT SCOURING was held in year ' + SIM.year({ t: a.wonAt }) + '. The hills go on.', x, y + sz, w, sz, C.good, 'left', '700'); return; }
    T('THE GREAT SCOURING, judged when a fair opens:', x, y + sz, fs(10), C.inkFaint, 'left', '700'); y += lh;
    var m0 = SIM.metrics(a.hills[0]), m1 = SIM.metrics(a.hills[1]), f1 = a.hills[1] ? SIM.fameOf(a, a.hills[1]) : 0;
    var rows = [
      [m0.crisp >= SIM.WIN_CRISP, 'the old horse ' + pct(SIM.WIN_CRISP) + ' crisp (now ' + pct(m0.crisp) + ')'],
      [!!a.hills[1] && m1.crisp >= SIM.WIN_CRISP, 'your figure ' + pct(SIM.WIN_CRISP) + ' crisp' + (a.hills[1] ? ' (now ' + pct(m1.crisp) + ')' : '')],
      [!!a.hills[1] && m1.area >= SIM.MIN_OWN_AREA && f1 >= SIM.MIN_OWN_FAME, 'yours ' + SIM.MIN_OWN_AREA + '+ cells, fame ' + SIM.MIN_OWN_FAME + '+' + (a.hills[1] ? ' (' + m1.area + ', ' + fmt(f1) + ')' : '')],
      [(a.hill2Fairs || 0) >= 1, 'yours has stood through one fair'],
    ];
    rows.forEach(function (r0) {
      g.fillStyle = r0[0] ? C.good : '#5a625c'; g.fillRect(x + 1, y + sz - 8, 8, 8);
      if (r0[0]) { g.fillStyle = '#14161a'; g.fillRect(x + 3, y + sz - 6, 4, 4); }
      T1(r0[1], x + 16, y + sz, w - 16, fs(10), r0[0] ? C.good : C.inkDim);
      y += sz + 4;
    });
  }
  var TABS_WIDE = [['hill', 'THE HILL'], ['upgrades', 'UPGRADES'], ['record', 'THE RECORD']];
  var TABS_TALL = [['hill', 'HILL'], ['upgrades', 'UPGRADES'], ['vale', 'THE VALE'], ['record', 'RECORD']];
  function tabs() { return shape === 'wide' ? TABS_WIDE : TABS_TALL; }
  function panelFrame() {
    var p = L().panel, wide = shape === 'wide';
    frame(p.x, p.y, p.w, p.h);
    var tb = tabs(), th = wide ? 26 : TAP_TALL, tw0 = wide ? 130 : (p.w - 12 - (tb.length - 1) * 4) / tb.length;
    tb.forEach(function (t, n) { var b = btn('tab:' + t[0], p.x + 6 + n * (tw0 + 4), p.y + 5, tw0, th, t[1], true, state.tab === t[0], undefined, undefined, 'tab'); b.info = 'open ' + (t[1].indexOf('THE ') === 0 ? '' : 'the ') + t[1].toLowerCase() + ' panel'; });
    if (wide) {
      var a = state.o, hint = guidance(a);
      T1(hint, p.x + p.w - 10, p.y + 22, p.w - 420, fs(11), C.inkFaint, 'right');
    }
    return { x: p.x + 8, y: p.y + th + 10, w: p.w - 16, h: p.h - th - 14 };
  }
  /* the one line of what to do next, read off the hill's own state */
  function guidance(a) {
    if (!a) return '';
    var m0 = SIM.metrics(a.hills[0]);
    /* the number every upgrade opens at is EARNED, never funds, so the upgrades tab says what it stands at */
    if (state.tab === 'upgrades') { var nx = null; SIM.UPGRADE_ORDER.forEach(function (k) { var u = SIM.UPGRADES[k]; if (!nx && !a.levels[k] && a.earned < u.earned) nx = u; }); return 'The hill has earned ' + fmt(a.earned) + ' in all' + (nx ? ': ' + nx.name + ' opens at ' + fmt(nx.earned) + '.' : ': every upgrade is open.'); }
    if (cutting(a)) { var m1 = SIM.metrics(a.hills[1]), fc = SIM.fameIfCrisp(a, a.hills[1]); return m1.area < SIM.MIN_OWN_AREA ? 'Draw your figure: ' + m1.area + ' of ' + SIM.MIN_OWN_AREA + ' cells, fame ' + fmt(fc) + ' of ' + SIM.MIN_OWN_FAME + ' when white. More corners, more fame, more edge to keep.' : fc < SIM.MIN_OWN_FAME ? 'Your figure would draw fame ' + fmt(fc) + ' of ' + SIM.MIN_OWN_FAME + ' when white: give it more corners and limbs.' : 'Scour the new cuts white. The next fair closes the cutting.'; }
    if (a.hills[1] && !a.hills[1].mask.some(function (v) { return v; })) return 'Your hill is empty: REOPEN THE CUTTING to draw a figure.';
    if (!a.levels.spades) return 'Scour the grey edges of the horse: the road pays by its fame.';
    if (m0.crisp < 0.6) return 'The horse is going green: scour its edges before the next fair.';
    if (!a.levels.fair) return 'Save up for THE SCOURING FAIR: the vale comes up the hill.';
    if (!a.hills[1] && a.earned < SIM.UPGRADES.hill2.earned) return 'The second hill is the last act: keep the horse white and save.';
    if (!a.hills[1]) return 'THE SECOND HILL is for sale on the UPGRADES tab: the last act.';
    if (a.levels.kerbs && a.funds >= 1000) return 'Spare funds: kerb the corners (KERB tool). A kerbed cell never greys again.';
    return 'Both figures crisp when a fair OPENS is the great scouring.';
  }
  function modeBtn(id, x, y, w, h, label, sub, enabled, why) { var b = btn('tool:' + id, x, y, w, h, label, enabled, state.tool === id, sub, why, 'tab'); return b; }
  function drawHillTab(a, c) {
    var wide = shape === 'wide', avail = toolsAvail(a);
    if (avail.indexOf(state.tool) < 0) state.tool = 'scour';
    var hands = Math.floor(a.handLeft) + ' of ' + SIM.HAND[a.levels.steel ? 2 : a.levels.spades ? 1 : 0] + ' today';
    var defs = [
      ['scour', 'SCOUR', hands, true, '', 'scour a grey cell by hand: +' + pct(SIM.HAND_AMOUNT) + ' white'],
      ['ram', 'RAM CHALK', a.levels.pit ? SIM.ramLeft(a) + ' left · ' + SIM.RAM_COST : 'not bought', !!a.levels.pit, 'THE CHALK PIT is not bought yet', 'tip fresh chalk on a cell: full white, greys at ' + SIM.CREEP_RAM + 'x for a year'],
      ['kerb', 'KERB', a.levels.kerbs ? SIM.kerbCost(a) + ' funds' : 'not bought', !!a.levels.kerbs, 'KERBS are not bought yet', 'timber edging on a cell: once it is white it never greys again, and each kerb costs more than the last'],
    ];
    var bh = wide ? 40 : 38, gap = 6, x = c.x, y = c.y;
    if (wide) {
      var bw = 132;
      defs.forEach(function (d, n) { var b = modeBtn(d[0], x + n * (bw + gap), y, bw, bh, d[1], d[2], d[3], d[4]); b.info = d[5]; });
      var wb = btn('worst', x + 3 * (bw + gap), y, 150, bh, 'QUICK SCOUR', a.handLeft >= 1, false, 'today\'s hands', a.handLeft >= 1 ? '' : 'your hands are done for today', 'tab'); wb.info = 'spend the rest of today\'s hands where they count: the cells just under the line first, on both hills';
      var tx = x + 3 * (bw + gap) + 150 + 14, tww = c.x + c.w - tx;
      var desc = state.hoverCell >= 0 && !overlayUp() ? cellInfo(a, state.hill, state.hoverCell) : toolText(a);
      fitWrap(desc, tx, y - 2, tww, bh + 4, fs(11), MIN(), C.inkDim);
      var y2 = y + bh + gap;
      if (cutting(a)) drawCutTools(a, x, y2, c.w, 40, 9);
      else if (a.hills[1] && state.hill === 1) { var rb = btn('reopen', x, y2, 200, 40, 'REOPEN THE CUTTING', !SIM.whyNotReopen(a), false, 'redraw your figure', SIM.whyNotReopen(a), 'tab'); rb.info = 'open the cutting again: a changed figure must stand through a fair before one can crown it'; var pb = btn('proclaim', x + 206, y2, 250, 40, 'PROCLAIM THE GREAT SCOURING', !SIM.whyNotProclaim(a), false, fmt(SIM.PROCLAIM_COST) + ' funds · next summer', SIM.whyNotProclaim(a), 'tab'); pb.info = 'bring the vale up the hill next summer instead of waiting for the fourth: it judges both figures as it finds them'; fitWrap('Your figure is cut. Once it has stood through a fair you may PROCLAIM the great scouring for next summer.', x + 466, y2 - 2, c.w - 466, 44, fs(11), MIN(), C.inkFaint); }
      else { var yl = fitWrap(roundText(a), x, y2 - 4, c.w, 18, fs(11), MIN(), C.inkFaint); drawLog(a, x, yl + 2, c.w, c.y + c.h - 2, 2); }
    } else {
      var bw2 = (c.w - gap) / 2;
      defs.forEach(function (d, n) { var b = modeBtn(d[0], x + (n % 2) * (bw2 + gap), y + Math.floor(n / 2) * (bh + gap), bw2, bh, d[1], d[2], d[3], d[4]); b.info = d[5]; });
      var wb2 = btn('worst', x + bw2 + gap, y + bh + gap, bw2, bh, 'QUICK SCOUR', a.handLeft >= 1, false, 'today\'s hands', a.handLeft >= 1 ? '' : 'your hands are done for today', 'tab'); wb2.info = 'spend the rest of today\'s hands where they count: the cells just under the line first, on both hills';
      var y3 = y + 2 * (bh + gap);
      if (cutting(a)) drawCutTools(a, x, y3, c.w, 34, 3);
      else if (a.hills[1] && state.hill === 1) { var hw = (c.w - 6) / 2; var rb2 = btn('reopen', x, y3, hw, 40, 'REOPEN', !SIM.whyNotReopen(a), false, 'the cutting', SIM.whyNotReopen(a), 'tab'); rb2.info = 'open the cutting again'; var pb2 = btn('proclaim', x + hw + 6, y3, hw, 40, 'PROCLAIM', !SIM.whyNotProclaim(a), false, 'the great scouring', SIM.whyNotProclaim(a), 'tab'); pb2.info = 'pay ' + fmt(SIM.PROCLAIM_COST) + ' to bring the vale up the hill next summer instead of waiting for the fourth'; fitWrap(state.hoverCell >= 0 ? cellInfo(a, state.hill, state.hoverCell) : toolText(a), x, y3 + 44, c.w, c.y + c.h - y3 - 44, fs(11), MIN(), C.inkDim); }
      else { var yt = fitWrap(toolText(a) + ' ' + roundText(a), x, y3, c.w, 84, fs(11), MIN(), C.inkDim); drawLog(a, x, yt + 4, c.w, c.y + c.h - 2, 3); }
    }
  }
  /* the hill's recent news, newest first: seasons, wages, fairs, unlocks (the bottom line shows one at a time) */
  function drawLog(a, x, y, w, maxY, max) {
    var sz = fs(10), lh = sz + 4, evs = a.events.slice(-max).reverse(), n = 0;
    if (y + sz > maxY || !evs.length) return;
    g.strokeStyle = 'rgba(255,255,255,0.07)'; g.beginPath(); g.moveTo(x, y + 0.5); g.lineTo(x + w, y + 0.5); g.stroke();
    y += 3;
    /* an entry is drawn whole, wrapped, or not at all: never shrunk past the floor, never run off the panel */
    for (var i = 0; i < evs.length; i++, n++) {
      var e = evs[i], col = e.kind === 'unlock' || e.kind === 'fair' || e.kind === 'win' ? C.gold : /could not pay/.test(e.msg) ? C.alarm : C.inkFaint;
      var d = Math.max(0, Math.floor(SIM.day(a) - e.t)), when = d === 0 ? 'today' : d === 1 ? 'yesterday' : d + ' days ago';
      var s = when + ': ' + e.msg;
      g.font = '400 ' + sz + 'px ' + UI;
      if (y + lines(s, w) * lh > maxY) break;
      y = wrapText(s, x, y + sz, w, sz, col, '400', lh) - sz;
    }
  }
  function drawCutTools(a, x, y, w, bh, perRow) {
    var gap = 6, items = [
      ['tool:cut', 'CUT', state.tool === 'cut', true, '', 'cut turf away: the cell joins your figure (it starts grey, scour it white)'],
      ['tool:erase', 'ERASE', state.tool === 'erase', true, '', 'turf it over: the cell leaves your figure'],
      ['brush', 'BRUSH ' + state.brush + 'x' + state.brush, false, true, '', 'the size of the cut: 1, 2 or 3 cells square'],
      ['preset:giant', 'GIANT', false, true, '', 'start again from the giant'],
      ['preset:stag', 'STAG', false, true, '', 'start again from the stag'],
      ['preset:crane', 'CRANE', false, true, '', 'start again from the crane'],
      ['undo', 'UNDO', false, state.undo.length > 0, 'nothing to undo', 'take back the last stroke'],
      ['clear', 'CLEAR', false, true, '', 'turf the whole hill over and draw from nothing'],
      ['close', 'CLOSE CUTTING', false, !SIM.whyNotClose(a), SIM.whyNotClose(a), 'finish the figure (the next fair closes it anyway, once it can be crowned)'],
    ];
    var rows = Math.ceil(items.length / perRow), bw = (w - (perRow - 1) * gap) / perRow;
    items.forEach(function (it, n) { var r0 = Math.floor(n / perRow), c0 = n % perRow, wdt = bw; var b = btn(it[0], x + c0 * (bw + gap), y + r0 * (bh + gap), wdt, bh, it[1], it[3], it[2], undefined, it[4], 'tab'); b.info = it[5]; });
    return y + rows * (bh + gap);
  }
  function toolText(a) {
    var t = state.tool;
    if (t === 'scour') return (shape === 'tall' ? 'Tap' : 'Click') + ' a grey cell to scour it (+' + pct(SIM.HAND_AMOUNT) + ' white), or drag along an edge. A cell greys by the share of its 8 sides that are turf, so corners grey fastest.';
    if (t === 'ram') return 'Fresh chalk: the cell goes full white and greys at ' + SIM.CREEP_RAM + 'x for a year. The carts bring ' + SIM.RAM_CARTS[a.levels.carts ? 2 : 1] + ' a season, ' + SIM.RAM_COST + ' funds each.';
    if (t === 'kerb') return 'A kerb (' + SIM.kerbCost(a) + ' funds, each dearer than the last) stops the creep on that cell for good; a grey one is re-cut white by the round first. Kerbs pay on the corners: a corner has more turf sides than a straight edge.';
    if (t === 'cut') return 'Draw your figure: corners and limbs bring fame, every edge is upkeep. It needs ' + SIM.MIN_OWN_AREA + '+ cells and fame ' + SIM.MIN_OWN_FAME + '+ when white (now ' + fmt(SIM.fameIfCrisp(a, a.hills[1])) + ').';
    return 'Erase cells to turf them over. Your figure: ' + SIM.metrics(a.hills[1]).area + ' cells, fame ' + fmt(SIM.fameIfCrisp(a, a.hills[1])) + ' when white.';
  }
  function roundText(a) { return 'Your ' + a.scourers + (a.scourers > 1 ? ' scourers walk' : ' scourer walks') + ' the figure on a round, re-cutting ' + SIM.REACH + ' cells each a day to full white' + (a.levels.kerbgang ? '; the kerb gang edges the most exposed cell each season' : '') + '. Wages ' + SIM.WAGE + ' a season each.'; }
  /* on a phone the upgrades page six at a time, so the bought ones go to the back rather than fill page one */
  function upList() { var a = state.o; if (shape !== 'tall' || !a) return SIM.UPGRADE_ORDER; return SIM.UPGRADE_ORDER.filter(function (k) { return !a.levels[k]; }).concat(SIM.UPGRADE_ORDER.filter(function (k) { return !!a.levels[k]; })); }
  function drawUpgrades(a, c) {
    var wide = shape === 'wide', list = upList(), gap = 6;
    var perPage = wide ? 14 : 6, cols = wide ? 7 : 2, bh = wide ? 52 : 52;
    var pages = Math.ceil(list.length / perPage); state.upPage = Math.max(0, Math.min(pages - 1, state.upPage));
    var bw = (c.w - (cols - 1) * gap) / cols;
    list.slice(state.upPage * perPage, state.upPage * perPage + perPage).forEach(function (key, n) {
      var u = SIM.UPGRADES[key], bought = !!a.levels[key], why = SIM.whyNotBuy(a, key), open = a.earned >= u.earned;
      /* a bought upgrade is quiet (no gold "selected" ring); the one a touch player has armed is ringed */
      var b = btn('up:' + key, c.x + (n % cols) * (bw + gap), c.y + Math.floor(n / cols) * (bh + gap), bw, bh, u.name, !why, state.armed === 'up:' + key, bought ? 'BOUGHT' : open ? fmt(u.price) + ' funds' : 'opens at ' + fmt(u.earned) + ' earned', why, 'tab');
      b.info = u.what; if (bought) b.subCol = C.good; else if (!open) b.subCol = C.inkFaint;
    });
    if (pages > 1) {
      var py = c.y + 3 * (bh + gap), pw = (c.w - gap) / 2;
      btn('upprev', c.x, py, pw, 30, 'PREVIOUS', state.upPage > 0, false, undefined, 'this is the first page', 'tab');
      btn('upnext', c.x + pw + gap, py, pw, 30, 'NEXT · page ' + (state.upPage + 1) + ' of ' + pages, state.upPage < pages - 1, false, undefined, 'this is the last page', 'tab');
    }
  }
  /* a figure as it stood at a fair's close, drawn cell by cell (the record keeps the masks and the whiteness) */
  function thumb(mask, white, x, y, s) {
    g.fillStyle = '#3e5a2e'; g.fillRect(x, y, SW * s, SH * s);
    if (!mask) { g.fillStyle = 'rgba(0,0,0,0.25)'; g.fillRect(x, y, SW * s, SH * s); return; }
    for (var i = 0; i < mask.length; i++) { if (!mask[i]) continue; var w = white[i]; g.fillStyle = w >= SIM.LINE ? 'rgb(' + Math.round(176 + 64 * (w - 0.5) * 2) + ',' + Math.round(182 + 56 * (w - 0.5) * 2) + ',' + Math.round(150 + 72 * (w - 0.5) * 2) + ')' : '#7d9a5c'; g.fillRect(x + (i % SW) * s, y + Math.floor(i / SW) * s, s, s); }
  }
  function drawRecord(a, c) {
    var wide = shape === 'wide', sz = fs(11), recs = a.fairs.slice().reverse();
    var y0 = fitWrap('Fairs held ' + a.stats.fairs + ' · cells scoured white (by hand, hire and fair) ' + fmt(a.stats.scoured) + ' · kerbs ' + a.stats.kerbs + ' · carts ' + a.stats.rammed + ' · travellers ' + fmt(a.stats.travellers), c.x, c.y - 2, c.w, wide ? 16 : 30, sz, MIN(), C.inkDim) - sz + 6;
    if (!recs.length) { fitWrap(a.levels.fair ? 'No fair has closed yet. At the close of each one, both figures are drawn here as the vale left them.' : 'THE SCOURING FAIR is not restored yet. When it is, both figures are drawn here at the close of every fair.', c.x, y0, c.w, 44, fs(11), MIN(), C.inkFaint); return; }
    /* one row of three on the wide panel at 3 px a cell (two hills 96x54 each), and on a phone three rows at 1.7: the
     * thumbnails were 40x22 px, too small to read a figure */
    var cols = wide ? 3 : 1, rows = wide ? 1 : 3, per = cols * rows, gap = 8, cw = (c.w - (cols - 1) * gap) / cols, ch = wide ? 62 : 39;
    var pages = Math.ceil(recs.length / per); state.recPage = Math.max(0, Math.min(pages - 1, state.recPage));
    recs.slice(state.recPage * per, state.recPage * per + per).forEach(function (r0, n) {
      var x = c.x + (n % cols) * (cw + gap), y = y0 + Math.floor(n / cols) * (ch + gap), s = wide ? 3 : 1.7;
      g.fillStyle = 'rgba(255,255,255,0.04)'; rr(x, y, cw, ch, 5); g.fill();
      thumb(r0.mask[0], r0.white[0], x + 4, y + 4, s); thumb(r0.mask[1], r0.white[1], x + 8 + SW * s, y + 4, s);
      var tx = x + 14 + 2 * SW * s;
      var tw2 = x + cw - tx - 4, crispTxt = 'crisp ' + pct(r0.crisp[0]) + (r0.crisp[1] !== null ? ' / ' + pct(r0.crisp[1]) : '');
      T1('YEAR ' + r0.year, tx, y + fs(11) + 4, tw2, fs(11), C.gold, 'left', '700');
      if (wide) { T1(fmt(r0.crowd) + ' came', tx, y + fs(11) * 2 + 9, tw2, fs(10), C.inkDim); T1(crispTxt, tx, y + fs(11) * 3 + 13, tw2, fs(10), C.inkDim); }
      else T1(fmt(r0.crowd) + ' came · ' + crispTxt, tx, y + fs(11) * 2 + 9, tw2, fs(10), C.inkDim);
    });
    if (pages > 1) {
      var py = y0 + rows * (ch + gap), pw = (c.w - gap) / 2;
      btn('recprev', c.x, py, pw, wide ? 24 : 30, 'NEWER', state.recPage > 0, false, undefined, 'these are the newest', 'tab');
      btn('recnext', c.x + pw + gap, py, pw, wide ? 24 : 30, 'OLDER', state.recPage < pages - 1, false, undefined, 'these are the oldest', 'tab');
    }
  }
  function drawBottom() {
    var b = L().bottom, wide = shape === 'wide', a = state.o;
    g.fillStyle = 'rgba(14,16,18,0.96)'; g.fillRect(b.x, b.y, b.w, b.h);
    var hb = hoverNow(), msg = null, col = C.inkDim, tm = state.toast[0];
    if (hb && hb.info && !overlayUp()) { msg = cap1(sent(hb.info)) + (hb.enabled ? '.' : hb.why ? '. ' + cap1(sent(hb.why)) + '.' : '.'); col = hb.enabled ? C.ink : C.alarm; }
    else if (tm && state.t - tm.at <= 12) { msg = tm.msg; col = tm.kind === 'bad' ? C.alarm : tm.kind === 'good' ? C.good : C.ink; }
    else if (state.hoverCell >= 0 && a && shape === 'wide' && state.tab !== 'hill') { msg = cellInfo(a, state.hill, state.hoverCell); col = C.inkDim; }
    /* the wide panel header already carries the guidance line, so the bar does not repeat it */
    else if (a && shape === 'tall') { msg = guidance(a); col = C.inkFaint; }
    if (msg) fitWrap(msg, b.x + 12, b.y + 3, b.w - 24, b.h - 8, fs(wide ? 13 : 12), MIN(), col, '400');
  }

  /* --------------------------------------------------------------- screens */
  var titleDown = null;
  function drawTitle() {
    var wide = shape === 'wide', has = hasSave(), armed = has && state.t < state.confirmNewUntil, d = has ? load() : null;
    /* a new hill's title shows the horse freshly scoured, the promise of the game, rather than the grey smudge a new
     * down starts as */
    if (!titleDown) { titleDown = SIM.newDown(4242); titleDown.hills[0].white = titleDown.hills[0].mask.map(function (v) { return v ? 1 : 0; }); }
    var a = d ? d.o : titleDown;
    g.fillStyle = '#101214'; g.fillRect(0, 0, W, H);
    var o = valeOpts(a, 'dawn'); o.season = 0; o.fair = 0;
    if (wide) drawVale('title', 320, 200, o, 0, 0, 960, 600);
    else drawVale('titleT', 180, 220, o, 0, 0, 360, 440);
    var cx = W / 2, ty = wide ? 70 : 52;
    g.save(); g.shadowColor = 'rgba(30,20,40,0.7)'; g.shadowBlur = 14; T('SCOURFAIR', cx, ty, wide ? 64 : 42, C.chalk, 'center', '700', SERIF); g.restore();
    T('Keep the white horse white, then cut your own.', cx, ty + (wide ? 30 : 24), wide ? 18 : 13, '#fff4e0', 'center', '400', SERIF);
    var bw = wide ? 280 : 260, bx = cx - bw / 2, ph = has ? (armed ? 176 : 152) : 112;
    var by = wide ? H - 34 - ph + 12 : 452;
    if (wide) { g.fillStyle = 'rgba(12,14,16,0.8)'; rr(cx - 170, by - 12, 340, ph, 12); g.fill(); }
    else { g.fillStyle = '#121416'; g.fillRect(0, 440, W, H - 440); }
    if (has) { btn('start', bx, by, bw, 40, 'CONTINUE', true, false, undefined, undefined, 'title'); btn('fresh', bx, by + 46, bw, 36, armed ? 'PRESS AGAIN TO START OVER' : 'NEW HILL', true, armed, undefined, undefined, 'title'); }
    else btn('start', bx, by, bw, 44, 'GO UP THE HILL', true, false, undefined, undefined, 'title');
    var y3 = by + (has ? 88 : 52);
    btn('help', bx, y3, bw / 2 - 3, 36, 'HOW TO PLAY', true, false, undefined, undefined, 'title');
    btn('credits', bx + bw / 2 + 3, y3, bw / 2 - 3, 36, 'CREDITS', true, false, undefined, undefined, 'title');
    if (armed) T('A new hill erases your saved one.', cx, y3 + 54, fs(12), C.alarm, 'center');
    g.fillStyle = 'rgba(10,12,14,0.9)'; g.fillRect(0, H - 26, W, 26);
    T1('Free · saves in your browser · by Core Systems Asset Factory', W / 2, H - 9, W - 16, fs(11), C.inkDim, 'center');
  }
  var HELP = [
    ['THE FIGURE AND THE TURF', 'The old horse is cut into the chalk of the down. Every day the turf creeps back: a cell of the figure greys by the share of its 8 sides that are turf, faster in the wet spring and on the steep middle of the slope. A cell under half white reads as grass and breaks the line (drawn as turf with a faint dark rim where the chalk was). Corners grey fastest, so the more intricate a figure, the more it costs to keep.'],
    ['FAME AND THE ROAD', 'Travellers on the vale road pay tolls by the figures\' FAME: detail (edge against size) times how crisp they are times how far they are seen. A crisp, intricate figure draws the road; a grey one draws a trickle. The road pays every day.'],
    ['LABOUR', 'You scour a few cells a day by hand (more with better spades): click or tap a grey cell, drag along an edge, or press QUICK SCOUR. A scour adds half a cell\'s whiteness, so the cells just under the line are where a hand counts most: a cell far under it is still grass by the next dawn. Hired scourers walk the figure on a ROUND, re-cutting 3 cells each a day to full white, and are paid ' + SIM.WAGE + ' a season. A hand the hill cannot pay goes home for the season; the village scourer always stays.'],
    ['CHALK AND KERBS', 'THE CHALK PIT brings carts of fresh chalk: a rammed cell is full white and greys at ' + SIM.CREEP_RAM + 'x for a year. KERBS are timber edging: once it is white a kerbed cell never greys again, each kerb costs ' + SIM.KERB_STEP + ' more than the last, and a corner is where a kerb pays most. Last of all THE KERB GANG edges the most exposed cell for you each season.'],
    ['THE FAIR AND THE GREAT SCOURING', 'Every fourth summer the vale comes up the hill for the scouring fair: a crowd that follows the figures\' fame on the day it opens, scouring for nothing. The vale judges the hills as it finds them, when the fair OPENS: both figures at least ' + pct(SIM.WIN_CRISP) + ' crisp, yours at least ' + SIM.MIN_OWN_AREA + ' cells and famous in its own right, and yours already stood through one fair. That is the great scouring. Once your figure has stood through a fair you may PROCLAIM the great scouring for next summer (' + SIM.PROCLAIM_COST + ' funds) rather than wait for the fourth. Play goes on after it.'],
    ['YOUR OWN FIGURE', 'THE SECOND HILL is yours to cut. Start from the giant, the stag or the crane, or draw: CUT and ERASE with a 1, 2 or 3 cell brush, UNDO, CLEAR. New cuts start grey and must be scoured in. The next fair closes the cutting (if the figure has ' + SIM.MIN_OWN_AREA + ' cells), or close it yourself; reopening it means it must stand through a fair again.'],
    ['AWAY AND RETURN', 'The hill keeps greying while you are away, up to one season, settled as arithmetic. Nothing ever ends the game: a figure gone green can always be scoured back, and a hill that cannot pay its hands still has its old scourer.'],
    ['CONTROLS', 'Click or tap a cell to use the chosen tool; drag to work along a line. From the keyboard: arrow keys move a cursor over the hill and Enter uses the tool; the number keys 1 to 9 press the buttons of the open panel (each shows its number once you use the keys) and 0 turns to the next nine; T moves to the next tab; V switches hill; W quick scour; Esc clears the cursor; F 3x speed, P pause, H help, M sound.'],
  ];
  function drawHelp() {
    g.fillStyle = '#101314'; g.fillRect(0, 0, W, H);
    var wide = shape === 'wide';
    T('HOW TO KEEP A HILL FIGURE', W / 2, wide ? 38 : 34, wide ? 24 : 18, C.chalk, 'center', '700', SERIF);
    var cols = wide ? 2 : 1, gut = 28, x = wide ? 24 : 14, w = (W - 2 * x - gut * (cols - 1)) / cols, top = wide ? 54 : 44, bottom = wide ? H - 70 : H - 76, size = 12;
    var sectH = function (k, sz) { g.font = '400 ' + sz + 'px ' + UI; return 2 * sz + 12 + lines(HELP[k][1], w) * (sz + 4); };
    var pages;
    for (;;) {
      pages = [[[]]]; var y = top;
      for (var k = 0; k < HELP.length; k++) {
        var hh = sectH(k, size), pgc = pages[pages.length - 1];
        if (y + hh > bottom && pgc[pgc.length - 1].length) { if (pgc.length < cols) pgc.push([]); else pages.push([[]]); y = top; }
        pgc = pages[pages.length - 1]; pgc[pgc.length - 1].push(k); y += hh;
      }
      if (pages.length === 1 || size <= (wide ? 11 : 12) || !wide) break;
      size--;
    }
    state.helpPages = pages.length;
    var pg = Math.max(0, Math.min(pages.length - 1, state.helpPage || 0)); state.helpPage = pg;
    pages[pg].forEach(function (col, ci) {
      var yy = top, cx0 = x + ci * (w + gut);
      col.forEach(function (k2) { T(HELP[k2][0], cx0, yy + size + 2, size + 1, C.gold, 'left', '700'); yy = wrapText(HELP[k2][1], cx0, yy + size * 2 + 8, w, size, C.inkDim, '400', size + 4) + 4; });
    });
    var back = state.screen === 'title' ? 'BACK' : 'BACK TO THE HILL';
    if (pages.length > 1) {
      T('page ' + (pg + 1) + ' of ' + pages.length, W / 2, H - 62, fs(10), C.inkFaint, 'center');
      btn('helpprev', 12, H - 52, 86, 40, 'PREVIOUS', pg > 0, false, undefined, 'this is the first page');
      btn('closehelp', 104, H - 52, W - 208, 40, back);
      btn('helpnext', W - 98, H - 52, 86, 40, 'NEXT', pg < pages.length - 1, false, undefined, 'this is the last page');
    } else btn('closehelp', W / 2 - 110, H - 58, 220, 40, back);
  }
  var CREDITS = [
    ['MADE BY', 'Core Systems Asset Factory. SCOURFAIR ' + VERSION + '.'],
    ['PICTURES', 'The ground plates (downland turf, chalk, rammed chalk and scrub) were generated for this game by the studio\'s own procedural pixel engine. The view from the road, the figures on the downs, the scourers, the fair and every cell of the hill are drawn by code written for this game, from the same numbers the game keeps. No image model and no stock art.'],
    ['MUSIC AND SOUND', 'The music is composed for this game as note data and rendered by the studio\'s own synthesiser. Every effect (the spade, the cart and rammer, the kerb, the fair, the church bell, the wind) is synthesised live in the browser. No generative audio model, no sample library.'],
    ['TYPE', 'IM Fell English SC for the titles and Alegreya Sans for the rest, both under the SIL Open Font License; their copyright notices and licence texts are in the fonts folder.'],
    ['AI DISCLOSURE', 'This game was written with AI assistance: its code, its text, and the code that draws every picture. No generative image or audio model was used in it. The vale, its road and its people are invented; the old custom of scouring a hill figure at a fair is real.'],
  ];
  function drawCredits() {
    g.fillStyle = '#101314'; g.fillRect(0, 0, W, H);
    var wide = shape === 'wide', x = wide ? 120 : 16, w = W - 2 * x, y = wide ? 40 : 36;
    T('CREDITS', W / 2, y, wide ? 26 : 20, C.chalk, 'center', '700', SERIF); y += wide ? 22 : 18;
    var size = wide ? 12 : 11;
    CREDITS.forEach(function (c) { T(c[0], x, y + size + 2, size + 1, C.gold, 'left', '700'); y = wrapText(c[1], x, y + size * 2 + 7, w, size, C.inkDim, '400', size + 4) + 2; });
    btn('closecredits', W / 2 - 100, H - 56, 200, 40, 'BACK');
  }
  function drawPause() {
    g.fillStyle = '#101314'; g.fillRect(0, 0, W, H);
    T('PAUSED', W / 2, H / 2 - 30, 44, C.chalk, 'center', '700', SERIF);
    fitWrap('The hill waits until you come back, even if you close the page.', W / 2, H / 2 - 12, W - 40, 36, fs(14), MIN(), C.ink, '400', 'center');
    btn('resume', W / 2 - 100, H / 2 + 30, 200, 42, 'RESUME');
  }
  /* the ending: the vale at dawn with both figures on the downs, and the scouring record beneath it */
  function drawEnding(a) {
    var wide = shape === 'wide', o = valeOpts(a, 'dawn');
    g.fillStyle = '#101214'; g.fillRect(0, 0, W, H);
    if (wide) drawVale('end', 320, 140, o, 0, 0, 960, 420); else drawVale('endT', 180, 160, o, 0, 0, 360, 320);
    var y = wide ? 458 : 356;
    g.save(); g.shadowColor = 'rgba(232,198,106,0.45)'; g.shadowBlur = 14; T('THE GREAT SCOURING', W / 2, y, wide ? 34 : 24, C.gold, 'center', '700', SERIF); g.restore();
    var ws = a.wonStats || {}, m0 = SIM.metrics(a.hills[0]), m1 = SIM.metrics(a.hills[1]), wy = SIM.year({ t: a.wonAt });
    if (!ws.crowd) a.fairs.concat(a.fair ? [a.fair] : []).forEach(function (f) { if (f.year === wy) ws.crowd = f.crowd; });
    y = fitWrap('In year ' + SIM.year({ t: a.wonAt }) + ' the vale came up the hill and found both figures white: the old horse ' + pct(ws.c0 !== undefined ? ws.c0 : m0.crisp) + ' crisp, yours ' + pct(ws.c1 !== undefined ? ws.c1 : m1.crisp) + '. ' + (ws.crowd ? fmt(ws.crowd) + ' people came.' : ''), W / 2, y + 6, W - 40, 40, fs(13), MIN(), C.ink, '400', 'center');
    var all = a.fairs.slice();
    if (ws.mask && !all.some(function (f) { return f.year === wy; })) all.push({ year: wy, mask: ws.mask, white: ws.white });
    var recs = all.slice(-(wide ? 5 : 3)), s = 1.5, cw = 2 * SW * s + 10, tot = recs.length * cw + (recs.length - 1) * 8, x0 = W / 2 - tot / 2;
    recs.forEach(function (r0, n) { var x = x0 + n * (cw + 8); thumb(r0.mask[0], r0.white[0], x, y + 2, s); thumb(r0.mask[1], r0.white[1], x + SW * s + 4, y + 2, s); T('year ' + r0.year, x + cw / 2 - 5, y + SH * s + 16, fs(10), C.inkFaint, 'center'); });
    btn('closeending', W / 2 - 120, H - 50, 240, 40, 'KEEP THE HILLS');
  }

  function render() {
    buttons = []; state.cut = 0;
    g.setTransform(1, 0, 0, 1, 0, 0);
    g.fillStyle = C.bg; g.fillRect(0, 0, W, H);
    if (state.screen === 'title') { drawTitle(); if (state.help) { buttons = []; drawHelp(); } else if (state.credits) { buttons = []; drawCredits(); } drawButtons(); return; }
    var a = state.o;
    if (!a.hills[state.hill]) state.hill = 0;
    var r = mapRect();
    g.save(); rr(r.x - 2, r.y - 2, r.w + 4, r.h + 4, 6); g.clip(); drawHillAt(a, state.hill, r, state.t); drawMapOverlay(a, r); g.restore();
    g.strokeStyle = C.panelEdge; g.lineWidth = 1; rr(r.x - 2, r.y - 2, r.w + 4, r.h + 4, 6); g.stroke();
    drawTop(a); drawStrip(a);
    if (shape === 'wide') { var s = L().side; frame(s.x, s.y, s.w, s.h); drawStatus(a, s, 136); }
    var c = panelFrame(), tb = state.tab;
    if (tb === 'upgrades') drawUpgrades(a, c);
    else if (tb === 'record') drawRecord(a, c);
    else if (tb === 'vale' && shape === 'tall') drawStatus(a, { x: c.x - 8, y: c.y - 6, w: c.w + 16, h: c.h }, 112);
    else { state.tab = tb === 'vale' ? 'hill' : tb; drawHillTab(a, c); }
    drawBottom(); drawButtons();
    if (state.help) { buttons = []; drawHelp(); drawButtons(); return; }
    if (a.won && !a.endingSeen) { buttons = []; drawEnding(a); drawButtons(); return; }
    if (state.userPaused) { buttons = []; drawPause(); drawButtons(); return; }
  }

  /* ------------------------------------------------------------------ tick */
  function tick(dt) {
    state.t += dt;
    toastTick();
    var a = state.o;
    if (state.screen !== 'play' || !a || state.help || state.userPaused || (a.won && !a.endingSeen)) { AUDIO.wind(false); return; }
    var wasWon = a.won;
    SIM.step(a, dt * state.speed / SIM.DAY_SEC);
    /* the figures as the vale found them are kept with the win: the fair that crowned them has not closed yet, so the
     * record would otherwise end one fair short of the year it celebrates */
    if (a.won && !wasWon) { var m0 = SIM.metrics(a.hills[0]), m1 = SIM.metrics(a.hills[1]); a.wonStats = { c0: m0.crisp, c1: m1.crisp, crowd: a.fair ? a.fair.crowd : 0, mask: [a.hills[0].mask.slice(), a.hills[1].mask.slice()], white: [a.hills[0].white.slice(), a.hills[1].white.slice()] }; AUDIO.fanfare(); save(); }
    for (var ei = 0; ei < a.events.length; ei++) {
      var e = a.events[ei];
      if (!(e.seq > state.eventsSeen)) continue;
      state.eventsSeen = e.seq;
      var kind = e.kind === 'unlock' || e.kind === 'win' || e.kind === 'fair' || e.kind === 'proclaim' ? 'good' : 'info';
      if (e.kind === 'season' && /could not pay/.test(e.msg)) kind = 'bad';
      /* a routine season (wages paid) goes to the log, not the message line (a toast every 25 s crowded out
       * the player's own refusals and unlocks); an unpaid one still speaks */
      if (!(e.kind === 'season' && kind !== 'bad')) note(e.msg, kind);
      var snd = { season: 'season', unlock: 'chime', kerb: 'kerb', cut: 'tick' }[e.kind];
      if (e.kind === 'fair') snd = /closed/.test(e.msg) ? 'bell' : 'fair';
      if (snd && AUDIO[snd]) AUDIO[snd]();
      save();
    }
    /* an upgrade the hill can now afford is announced ONCE (a minute in, two upgrades were for sale and the
     * screen looked exactly as it did at second zero) */
    a.toldUp = a.toldUp || {};
    for (var ui = 0; ui < SIM.UPGRADE_ORDER.length; ui++) {
      var uk = SIM.UPGRADE_ORDER[ui];
      if (a.levels[uk] || a.toldUp[uk] || SIM.whyNotBuy(a, uk)) continue;
      a.toldUp[uk] = 1; note(SIM.UPGRADES[uk].name + ' can be bought now, on the UPGRADES tab (' + fmt(SIM.UPGRADES[uk].price) + ' funds).', 'good'); AUDIO.coin();
    }
    AUDIO.wind(true);
    if (Date.now() - state.lastSaveReal > 5000) { state.lastSaveReal = Date.now(); save(); }
  }

  /* ----------------------------------------------------------------- input */
  var actedThisFrame = false;
  function toSurface(ev) { var r = cv.getBoundingClientRect(); return { x: (ev.clientX - r.left) * (W / r.width), y: (ev.clientY - r.top) * (H / r.height) }; }
  cv.addEventListener('pointerdown', function (ev) {
    try { window.focus(); } catch (e) { /* cross-origin parent */ }
    try { cv.focus({ preventScroll: true }); } catch (e) { /* old browser */ }
    AUDIO.unlock();
    if (ev.button !== undefined && ev.button !== 0) return;
    var p = toSurface(ev);
    if (actedThisFrame) return;
    var b = btnAt(p.x, p.y), touch = ev.pointerType === 'touch';
    state.keyArmed = false;
    if (b && touch && b.id.indexOf('up:') === 0 && b.info && (state.armed !== b.id || state.t - state.armedAt > 8)) {
      actedThisFrame = true; state.armed = b.id; state.armedAt = state.t; AUDIO.tick();
      toast(cap1(sent(b.info)) + (b.enabled ? '. Tap again to buy it for ' + b.sub + '.' : b.why && b.why !== 'already bought' ? '. ' + cap1(b.why) + '.' : '.'), b.enabled || b.why === 'already bought' ? 'info' : 'bad');
      return;
    }
    state.armed = null;
    if (b && b.enabled) { actedThisFrame = true; doButton(b); return; }
    if (b && b.why) { actedThisFrame = true; toast(cap1(b.why) + '.', 'bad'); AUDIO.tick(); return; }
    if (!overlayUp()) {
      var i = cellAt(p.x, p.y);
      if (i >= 0) {
        actedThisFrame = true; state.cursor = -1;
        if (state.tool === 'cut' || state.tool === 'erase') state.strokeUndo = true;
        state.drag = { last: i, id: ev.pointerId };
        try { cv.setPointerCapture(ev.pointerId); } catch (e) { /* synthetic event */ }
        applyTool(i, false);
      }
    }
  });
  cv.addEventListener('pointermove', function (ev) {
    var p = toSurface(ev);
    hoverPt = ev.pointerType === 'touch' ? null : p;
    state.hoverCell = overlayUp() || ev.pointerType === 'touch' ? -1 : cellAt(p.x, p.y);
    if (state.drag && !overlayUp()) { var i = cellAt(p.x, p.y); if (i >= 0 && i !== state.drag.last) { state.drag.last = i; applyTool(i, true); } }
  });
  function endDrag() { state.drag = null; }
  cv.addEventListener('pointerup', endDrag);
  cv.addEventListener('pointercancel', endDrag);
  cv.addEventListener('pointerleave', function () { hoverPt = null; state.hoverCell = -1; });
  cv.addEventListener('contextmenu', function (ev) { ev.preventDefault(); });
  /* held keys and a drag end when the page loses focus (a drag must not keep painting after an alt-tab) */
  window.addEventListener('blur', function () { state.drag = null; });
  function pushUndo() { var a = state.o; if (!a || !a.hills[1]) return; state.undo.push(a.hills[1].mask.slice()); if (state.undo.length > 30) state.undo.shift(); }
  function setMask(target) { var a = state.o; for (var i = 0; i < SW * SH; i++) if (!!a.hills[1].mask[i] !== !!target[i]) SIM.cut(a, i, !!target[i]); }
  function press(b) { if (!b) return; if (b.enabled) doButton(b); else if (b.why) { toast(cap1(b.why) + '.', 'bad'); AUDIO.tick(); } }
  window.addEventListener('keydown', function (ev) {
    var k = ev.key, primary = k === 'Enter' || k === ' ';
    if (k === 'ArrowLeft' || k === 'ArrowRight' || k === 'ArrowUp' || k === 'ArrowDown' || k === ' ') ev.preventDefault();
    if (k !== 'Shift' && k !== 'Control' && k !== 'Alt' && k !== 'Meta' && k !== 'Tab') state.keysSeen = true;
    AUDIO.unlock();
    try { render(); } catch (e) { /* the loop's own rescue handles a broken frame */ }
    if (state.help) {
      if (k === 'PageDown' || k === 'PageUp') ev.preventDefault();
      if (k === 'ArrowRight' || k === 'PageDown') { if ((state.helpPage || 0) < (state.helpPages || 1) - 1) { state.helpPage = (state.helpPage || 0) + 1; AUDIO.tick(); } return; }
      if (k === 'ArrowLeft' || k === 'PageUp') { if ((state.helpPage || 0) > 0) { state.helpPage--; AUDIO.tick(); } return; }
      if (k === 'Escape' || primary || k === 'h' || k === 'H' || k === '?') closeHelp(); else if (k === 'm' || k === 'M') AUDIO.toggleMute(); return;
    }
    if (state.credits) { if (k === 'Escape' || primary) { state.credits = false; AUDIO.tick(); } return; }
    if (k === 'm' || k === 'M') { AUDIO.toggleMute(); return; }
    if (state.screen === 'title') {
      var dt = KEYS.indexOf(k);
      if (dt >= 0) { press(keyedButtons()[dt]); return; }
      if (k === 'n' || k === 'N') { doButton({ id: 'fresh' }); return; }
      if (primary) doButton({ id: 'start' }); else if (k === 'h' || k === 'H' || k === '?') openHelp(); return;
    }
    if (state.screen !== 'play' || !state.o) return;
    var a = state.o;
    if (a.won && !a.endingSeen) { if (k === 'Escape' || primary) doButton({ id: 'closeending' }); return; }
    if (state.userPaused) { if (k === 'p' || k === 'P' || k === 'Escape' || primary) { state.userPaused = false; save(); AUDIO.tick(); } return; }
    if (k === 'p' || k === 'P') { state.userPaused = true; save(); AUDIO.tick(); return; }
    if (k === 'h' || k === 'H' || k === '?') { openHelp(); return; }
    if (k === 't' || k === 'T') { var order = tabs().map(function (x) { return x[0]; }); state.tab = order[(order.indexOf(state.tab) + 1) % order.length]; AUDIO.tick(); return; }
    if (k === 'v' || k === 'V') { if (a.hills[1]) { state.hill = 1 - state.hill; AUDIO.tick(); } else toast('The second hill is not yours yet.', 'info'); return; }
    if (k === 'w' || k === 'W') { scourWorst(); return; }
    if (k === 'f' || k === 'F') { state.speed = state.speed > 1 ? 1 : 3; AUDIO.tick(); return; }
    if (k === 'Escape' || k === 'Backspace') { state.cursor = -1; return; }
    var di = KEYS.indexOf(k);
    if (k === '0') { keyedButtons(); if (keysPaged()) { state.keyPage = ((state.keyPage || 0) + 1) % state.keyPages; state.armed = null; AUDIO.tick(); return; } }
    if (di >= 0) {
      var kb = keyedButtons()[di];
      if (!kb) return;
      var spends = /^up:/.test(kb.id);
      if (spends && kb.enabled && kb.info && !(state.armed === kb.id && state.keyArmed && state.t - state.armedAt <= 8)) { state.armed = kb.id; state.armedAt = state.t; state.keyArmed = true; toast(cap1(sent(kb.info)) + '. Press ' + k + ' again to buy it for ' + kb.sub + '.', 'info'); AUDIO.tick(); return; }
      state.armed = null; state.keyArmed = false;
      press(kb); return;
    }
    var mv = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[k];
    if (mv) {
      var cur = state.cursor < 0 ? firstFigureCell(a) : state.cursor;
      var x = Math.max(0, Math.min(SW - 1, cur % SW + (state.cursor < 0 ? 0 : mv[0]))), y = Math.max(0, Math.min(SH - 1, Math.floor(cur / SW) + (state.cursor < 0 ? 0 : mv[1])));
      state.cursor = y * SW + x; return;
    }
    if (primary) {
      if (state.cursor < 0) { state.cursor = firstFigureCell(a); return; }
      if (state.tool === 'cut' || state.tool === 'erase') state.strokeUndo = true;
      applyTool(state.cursor, false);
    }
  });
  function firstFigureCell(a) { var h = a.hills[state.hill]; if (h) for (var i = 0; i < SW * SH; i++) if (h.mask[i]) return i; return 8 * SW + 16; }
  function openHelp() { state.help = true; state.helpPage = 0; }
  function closeHelp() { state.help = false; if (state.pendingToast) { toast(state.pendingToast.msg, state.pendingToast.kind); state.pendingToast = null; } }
  function startPlay(a, fromSave) {
    state.o = a; state.screen = 'play'; state.tab = 'hill'; state.eventsSeen = a.seq || 0; state.cursor = -1; state.hill = 0; state.tool = 'scour'; state.undo = []; state.drag = null;
    /* a new hill opens on the hill itself, with its greyest-useful cells pulsing and one line saying what to do; the help
     * is one key or button away (it opened on 650 words of help) */
    state.help = false; state.helpPage = 0;
    save();
  }
  function awayReport(L0, f0) {
    if (!L0) { toast('Welcome back to the hill.', 'good'); return; }
    toast('While you were away, ' + L0.days + ' days passed on the hill' + (L0.days >= SIM.AWAY_CAP_DAYS ? ' (it counts one season at most)' : '') + ': funds ' + (L0.funds >= 0 ? '+' : '') + L0.funds + '. The old horse is ' + pct(SIM.metrics(state.o.hills[0]).crisp) + ' crisp.', 'good');
  }
  function consumeOwnEvent(a, seqBefore) { if ((a.seq || 0) === seqBefore + 1 && state.eventsSeen >= seqBefore) state.eventsSeen = a.seq; }
  function doButton(b) {
    var a = state.o, w;
    if (b.id === 'start') {
      var d = load(), L0 = null;
      if (d && !d.paused) { try { L0 = SIM.settleAway(d.o, (Date.now() - (d.savedAt || Date.now())) / 1000); } catch (e) { d = null; } }
      if (d && d.paused) { state.userPaused = true; startPlay(d.o, true); toast('The hill waited where you paused it. Nothing happened while you were away.', 'good'); }
      else if (d) { startPlay(d.o, true); state.eventsSeen = d.o.seq || 0; awayReport(L0); }
      else {
        var unreadable = hasSave();
        if (unreadable) { try { localStorage.setItem(SAVE_KEY + '.unreadable', localStorage.getItem(SAVE_KEY)); } catch (e) { /* storage refused */ } }
        startPlay(SIM.newDown(1 + Math.floor(Math.random() * 1e6)), false);
        state.pendingToast = unreadable ? { msg: 'Your saved hill could not be read. It was kept aside, and a new hill begins.', kind: 'bad' }
          : { msg: 'Spring, year 1. The old horse has not been scoured in a generation. ' + (shape === 'tall' ? 'Tap' : 'Click') + ' the pulsing cells: those just under the line are where a hand counts. H for help.', kind: 'good' };
        toast(state.pendingToast.msg, state.pendingToast.kind); state.pendingToast = null;
      }
      AUDIO.tick(); return;
    }
    if (b.id === 'fresh') {
      if (!hasSave()) { doButton({ id: 'start' }); return; }
      if (!(state.t < state.confirmNewUntil)) { state.confirmNewUntil = state.t + 4; return; }
      state.confirmNewUntil = 0; startPlay(SIM.newDown(1 + Math.floor(Math.random() * 1e6)), false); toast('A new hill. Spring, year 1: ' + (shape === 'tall' ? 'tap' : 'click') + ' the pulsing cells to scour them.', 'good'); return;
    }
    if (b.id === 'closehelp') { closeHelp(); return; }
    if (b.id === 'credits') { state.credits = true; AUDIO.tick(); return; }
    if (b.id === 'closecredits') { state.credits = false; AUDIO.tick(); return; }
    if (b.id === 'closeending') { a.endingSeen = true; save(); AUDIO.tick(); return; }
    if (b.id === 'help') { openHelp(); return; }
    if (b.id === 'helpnext') { if ((state.helpPage || 0) < (state.helpPages || 1) - 1) state.helpPage = (state.helpPage || 0) + 1; AUDIO.tick(); return; }
    if (b.id === 'helpprev') { if ((state.helpPage || 0) > 0) state.helpPage--; AUDIO.tick(); return; }
    if (b.id === 'mute') { AUDIO.toggleMute(); return; }
    if (b.id === 'speed') { state.speed = state.speed > 1 ? 1 : 3; AUDIO.tick(); return; }
    if (b.id === 'pause') { state.userPaused = true; save(); AUDIO.tick(); return; }
    if (b.id === 'resume') { state.userPaused = false; save(); AUDIO.tick(); return; }
    if (b.id.indexOf('tab:') === 0) { state.tab = b.id.slice(4); AUDIO.tick(); return; }
    if (b.id === 'upprev') { state.upPage = Math.max(0, state.upPage - 1); AUDIO.tick(); return; }
    if (b.id === 'upnext') { state.upPage++; AUDIO.tick(); return; }
    if (b.id === 'recprev') { state.recPage = Math.max(0, state.recPage - 1); AUDIO.tick(); return; }
    if (b.id === 'recnext') { state.recPage++; AUDIO.tick(); return; }
    if (!a) return;
    if (b.id.indexOf('hill:') === 0) { var hk = +b.id.slice(5); if (a.hills[hk]) { state.hill = hk; AUDIO.tick(); } return; }
    if (b.id.indexOf('tool:') === 0) { state.tool = b.id.slice(5); AUDIO.tick(); return; }
    if (b.id === 'worst') { scourWorst(); return; }
    if (b.id === 'brush') { state.brush = state.brush % 3 + 1; AUDIO.tick(); return; }
    if (b.id === 'undo') { var u = state.undo.pop(); if (u) { setMask(u); AUDIO.tick(); save(); } return; }
    if (b.id === 'clear') { pushUndo(); setMask(new Array(SW * SH).fill(0)); state.tool = 'cut'; AUDIO.tick(); save(); toast('The hill is turfed over: draw from nothing (UNDO brings it back).', 'info'); return; }
    if (b.id.indexOf('preset:') === 0) { pushUndo(); SIM.usePreset(a, b.id.slice(7)); AUDIO.scour(); save(); toast('The ' + b.id.slice(7) + ' is marked out on your hill: its cuts start grey, so scour them in.', 'info'); return; }
    if (b.id === 'close') { var sq = a.seq || 0; w = SIM.closeCutting(a); if (w) { toast(cap1(w) + '.', 'bad'); return; } consumeOwnEvent(a, sq); state.tool = 'scour'; AUDIO.chime(); toast('The cutting is closed. Your figure must stand through a fair before one can crown it.', 'good'); save(); return; }
    if (b.id === 'proclaim') { var sq4 = a.seq || 0; w = SIM.proclaim(a); if (w) { toast(cap1(w) + '.', 'bad'); return; } consumeOwnEvent(a, sq4); AUDIO.fair(); toast('THE GREAT SCOURING is proclaimed for summer, year ' + a.proclaimed + ': have both figures white when the vale arrives.', 'good'); save(); return; }
    if (b.id === 'reopen') { var sq3 = a.seq || 0; w = SIM.reopenCutting(a); if (w) { toast(cap1(w) + '.', 'bad'); return; } consumeOwnEvent(a, sq3); state.tool = 'cut'; state.undo = []; AUDIO.tick(); toast('The cutting is open: redraw your figure.', 'info'); save(); return; }
    if (b.id.indexOf('up:') === 0) {
      var key = b.id.slice(3), sq2 = a.seq || 0; w = SIM.buy(a, key); if (w) { toast(cap1(w) + '.', 'bad'); return; }
      consumeOwnEvent(a, sq2); AUDIO.chime(); AUDIO.coin();
      toast(SIM.UPGRADES[key].name + ': ' + SIM.UPGRADES[key].what, 'good');
      /* buying THE CHALK PIT or KERBS no longer switches the tool under the player (the next click spent funds
       * and could fix a grey cell for good); only the second hill opens on its editor */
      if (key === 'hill2') { state.hill = 1; state.tool = 'cut'; state.tab = 'hill'; state.undo = []; }
      save(); return;
    }
  }

  /* ---------------------------------------------------------------- shape */
  function pickShape() { setShape((window.innerWidth / Math.max(1, window.innerHeight)) < 1 ? 'tall' : 'wide'); }
  function setShape(s) {
    if (!SHAPES[s]) return;
    shape = s; W = SHAPES[s].W; H = SHAPES[s].H;
    if (cv.width !== W) cv.width = W;
    if (cv.height !== H) cv.height = H;
    if (shape === 'wide' && state.tab === 'vale') state.tab = 'hill';
    document.documentElement.style.setProperty('--ar', String(W / H));
  }
  window.addEventListener('resize', pickShape);
  pickShape();

  /* ------------------------------------------------------------------ loop */
  var last = 0, paused = false;
  function loop(ts) {
    requestAnimationFrame(loop);
    if (!last) last = ts;
    var dt = Math.min(0.1, (ts - last) / 1000);
    last = ts;
    if (!paused) { try { tick(dt); actedThisFrame = false; render(); } catch (e) { rescue(e); } }
  }
  function rescue(e) {
    if (state.rescued) return;
    state.rescued = true;
    try { var raw = localStorage.getItem(SAVE_KEY); if (raw) { localStorage.setItem(SAVE_KEY + '.unreadable', raw); localStorage.removeItem(SAVE_KEY); } } catch (x) { /* storage blocked */ }
    state.o = null; state.screen = 'title'; state.help = false; state.userPaused = false; buttons = [];
    state.pendingToast = { msg: 'Something in your saved hill could not be read. It was kept aside, and a new hill begins.', kind: 'bad' };
    setTimeout(function () { state.rescued = false; throw e; }, 0);
  }
  requestAnimationFrame(loop);
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) { state.hiddenAt = Date.now(); state.drag = null; save(); return; }
    var a = state.o, at = state.hiddenAt; state.hiddenAt = 0;
    if (!at || state.screen !== 'play' || !a || (a.won && !a.endingSeen) || state.help || state.userPaused) return;
    var secs = (Date.now() - at) / 1000;
    if (secs < 8) return;
    var L0 = SIM.settleAway(a, secs);
    state.eventsSeen = a.seq || 0;
    awayReport(L0);
    save();
  });

  window.SCOURFAIR = {
    state: state, sim: SIM, version: VERSION,
    isReady: function () { return state.t > 0 && fontsReady; },
    fonts: function () { if (!document.fonts || !document.fonts.check) return null; return { display: document.fonts.check('400 40px "SF Display"', 'SCOURFAIR'), body: document.fonts.check('500 16px "SF Body"'), bold: document.fonts.check('800 16px "SF Body"') }; },
    platesReady: function () { return platesReady; },
    buttons: function () { return buttons.slice(); },
    findButton: function (id) { for (var i = 0; i < buttons.length; i++) if (buttons[i].id === id) return buttons[i]; return null; },
    shape: function () { return { shape: shape, W: W, H: H }; },
    setShape: setShape,
    setPaused: function (p) { paused = !!p; },
    advance: function (sec) { var n = Math.max(1, Math.ceil(sec / 0.05)); for (var i = 0; i < n; i++) tick(sec / n); actedThisFrame = false; render(); },
    newDown: function (seed) { startPlay(SIM.newDown(seed), true); },
    load: function (o) { startPlay(o, true); },
    cellRect: function (x, y) { return cellRect(x, y); }, cellAt: cellAt,
    panels: function () { if (overlayUp() || state.screen !== 'play') return []; var l = L(), m = mapRect(); return [['top', l.top], ['strip', l.strip], ['map', { x: m.x, y: m.y, w: m.w, h: m.h }], ['side', l.side], ['panel', l.panel], ['bottom', l.bottom]].filter(function (p) { return p[1]; }).map(function (p) { return { name: p[0], x: p[1].x, y: p[1].y, w: p[1].w, h: p[1].h }; }); },
    render: render,
  };
})();
