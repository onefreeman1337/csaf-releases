/**
 * sim.js - SCOURFAIR: the rules of keeping a chalk hill figure white, with no drawing in them.
 *
 * THE DOWN: each hill is a grid (W x H cells). A cell of the FIGURE holds a WHITENESS 0..1; every other cell is turf.
 * Every day a figure cell loses whiteness in proportion to the share of its 8 neighbours that are turf (so an EDGE cell
 * greys and an interior one barely does), times the season's creep, times its row's slope. A cell under 0.5 reads as
 * grass and breaks the line. A KERB on a cell stops creep there; RAMMED chalk creeps at a fraction for two years.
 *
 * THE FIGURE: area (cells) sets VISIBILITY from the vale road; detail (perimeter against the square root of area) sets
 * FAME; perimeter (figure cells with a turf neighbour) sets exposure. CRISPNESS = share of figure cells at or over 0.5.
 *
 * LABOUR: you scour by hand (a few cells a day, more with better spades, any cell you choose); hired SCOURERS work the
 * figure in a ROUND, re-cutting REACH cells each a day to full white and moving on, so a cell waits a whole lap between
 * visits and the lap is the figure's creeping cells over the gang's reach (a kerbed cell is off the round). Wages are
 * paid at each season's start. The SCOURING FAIR (every FAIR_EVERY years, a summer week) brings free labour and a crowd
 * that follows the fame at its opening. Travellers on the vale road pay tolls every day by fame.
 *
 * THE GOAL: the second hill is yours to cut; when a fair OPENS, if BOTH figures are at least WIN_CRISP crisp, yours is at
 * least MIN_OWN_AREA cells and famous in its own right, and it has stood through one fair already, the vale has come up
 * to THE GREAT SCOURING and the game is won (the fair's own labour repairs for later; it never sits the exam for you).
 * Play continues after.
 * No game over: a neglected figure greys and can always be scoured back.
 *
 * Units: t is in DAYS. game.js turns seconds into days (DAY_SEC a day at normal speed).
 */
'use strict';

var SIM = (function () {
  var DAY_SEC = 2.5, SEASON_LEN = 10, YEAR_DAYS = 40, STEP = 0.05, AWAY_CAP_DAYS = SEASON_LEN;
  var SEASONS = ['SPRING', 'SUMMER', 'AUTUMN', 'WINTER'];
  var W = 32, H = 18;
  /* whiteness a day for a cell with ALL neighbours turf, by season. At a third of
   * this, one scourer held the horse at 100% from year 2; the wet spring raised again 2026-10-07 with the ROUND, so the
   * corners of an intricate figure out-creep a lap unless they are kerbed or rammed */
  var CREEP = [0.130, 0.025, 0.050, 0.040];
  var REACH = 3;                                   // cells a hired scourer re-cuts to white a day, on the round
  /* rams last a year and the carts bring four (eight) a season: at two years and 6/12 they kept ~96 cells at 0.4x creep
   * and did the kerbs' whole job: rams and kerbs were substitutes */
  var RAM_FACTOR = 0.4, RAM_YEARS = 1;
  var LINE = 0.5;                                  // under this a cell reads as grass
  var HAND = [3, 5, 8];                            // cells a day you scour by hand: bare hands, turf spades, steel spades
  var HAND_AMOUNT = 0.5;                           // whiteness one hand-scour restores
  var WAGE = 30;                                   // funds a scourer a season, paid at the season's start
  var TOLL = 0.5;                                  // funds a traveller
  var TRAVEL_K = 1.2;                              // travellers a day per point of fame
  var FAIR_EVERY = 4, FAIR_DAY = 12, FAIR_LEN = 7; // summer, days 12..18 of the year, every fourth year
  var FAIR_LABOUR = 0.05;                          // scourer-days a day per head of crowd
  var FAIR_SPEND = 0.4;                            // funds a head a day at the fair
  /* the great scouring: both figures crisp, yours big enough AND famous in its own right (a plain block is crisp and
   * cheap and draws nobody: a plain block tied the intricate figure until this floor existed) */
  var WIN_CRISP = 0.9, MIN_OWN_AREA = 60, MIN_OWN_FAME = 12;
  var KERB_COST = 25, RAM_COST = 6, RAM_CARTS = [0, 4, 8];    // cells rammed a season by cart level
  /* every kerb dearer than the last (timber and labour get scarcer): at a flat 25 a player could kerb every cell of both
   * figures by year 8, after which nothing greys and the whole hill stops being a game */
  var KERB_STEP = 5;
  function kerbCost(a) { return KERB_COST + KERB_STEP * ((a.stats && a.stats.kerbs) || 0); }
  var GANG_SPARE = 200;                            // the kerb gang works only when the hill holds this much beyond a kerb
  var START_FUNDS = 60;

  /* the old figure: a long-bodied horse with a beaked head, cut on the first hill ('#'), and its LOST LINES ('+'),
   * grassed over long ago, which the antiquarians reveal */
  var OLD = [
    '................................',
    '........................+++.....',
    '.......................#####....',
    '......................##+.###...',
    '......................##...##...',
    '..##.................##.........',
    '...##..............###..........',
    '....###############.............',
    '.....#############..............',
    '......##.......##...............',
    '.....##.........##..............',
    '....##...........##.............',
    '...##.............##............',
    '..##...............##...........',
    '.##.................##..........',
    '.....................+..........',
    '................................',
    '................................',
  ];
  /* three presets for the second hill (a player who does not want to draw still plays): a giant, a stag, a crane */
  var PRESETS = {
    giant: ['................................', '...............##...............', '..............####..............', '...............##...............', '..........############..........', '.........##...####...##.........', '........##....####....##........', '.......##.....####.....##.......', '..............####..............', '..............####..............', '.............##..##.............', '............##....##............', '...........##......##...........', '..........##........##..........', '.........##..........##.........', '................................', '................................', '................................'],
    stag: ['......#...#.....................', '.......#.#......................', '.....#..##..#...................', '......####.##...................', '.......####.....................', '.......#####....................', '........##########..............', '........############............', '.........###########............', '..........##......##............', '..........##.......##...........', '..........#........#............', '.........##.......##............', '........................................'.slice(0, 32), '................................', '................................', '................................', '................................'],
    /* a crane in flight, wings up and legs trailing: 64 cells, over the great scouring's 60 (the first crane, standing,
     * was 52 cells, so a player who chose it could never be crowned) */
    crane: ['................................', '..##........................##..', '...##......................##...', '....###..................###....', '......###......##......###......', '........###...####...###........', '..........###.####.###..........', '............########............', '.............######.............', '..............####..............', '...............##...............', '..............#..#..............', '.............#....#.............', '................................', '................................', '................................', '................................', '................................'],
  };
  var SLOPE = (function () { var s = []; for (var y = 0; y < H; y++) { var u = y / (H - 1); s.push(0.8 + 0.6 * Math.sin(Math.PI * u)); } return s; })();

  var UPGRADES = {
    spades:    { name: 'TURF SPADES',          earned: 60,   price: 50,   what: 'Scour five cells a day by hand.' },
    scourer2:  { name: 'A SECOND SCOURER',     earned: 120,  price: 40,   what: 'Another pair of hands on the round, at 30 a season.' },
    pit:       { name: 'THE CHALK PIT',        earned: 200,  price: 150,  what: 'Carts: ram four cells a season with fresh chalk that greys slower for a year.' },
    fair:      { name: 'THE SCOURING FAIR',    earned: 320,  price: 200,  what: 'Every fourth summer the vale comes up the hill: free labour, and a crowd by fame.' },
    scourer3:  { name: 'A THIRD SCOURER',      earned: 450,  price: 80,   what: 'Another pair of hands on the round, at 30 a season.' },
    kerbs:     { name: 'KERBS',                earned: 600,  price: 250,  what: 'Lay timber edging on a cell: no creep there, ever. Each kerb costs more than the last.' },
    viewpoint: { name: 'THE VIEWING POINT',    earned: 800,  price: 300,  what: 'A lay-by on the vale road: the figure is seen half as far again.' },
    steel:     { name: 'STEEL SPADES',         earned: 1000, price: 260,  what: 'Scour eight cells a day by hand.' },
    carts:     { name: 'MORE CARTS',           earned: 1200, price: 300,  what: 'Ram eight cells a season.' },
    antiq:     { name: 'THE ANTIQUARIANS',     earned: 1400, price: 350,  what: 'They find the old figure\'s lost lines under the turf: restore them for fame.' },
    train:     { name: 'THE EXCURSION TRAIN',  earned: 1800, price: 450,  what: 'Fair crowds come by rail: half as many again.' },
    scourer4:  { name: 'A FOURTH SCOURER',     earned: 2100, price: 160,  what: 'Another pair of hands on the round, at 30 a season.' },
    /* at earned 2400 / price 600 an attentive player won in year 6 (~9 min at 1x); the second hill is the last act */
    hill2:     { name: 'THE SECOND HILL',      earned: 6000, price: 1500, what: 'The down across the coombe is yours to cut: a giant is marked out to start, or draw your own.' },
    /* the idle path to kerbs: placed early and kerbing daily it over-solved the hill for every way of playing;
     * last and one a season, an idle hill wins late (year 20) and a player who kerbs by hand still wins first */
    kerbgang:  { name: 'THE KERB GANG',        earned: 9000, price: 2000, what: 'Each season they kerb the most exposed cell, when the hill can spare it.' },
  };
  var UPGRADE_ORDER = Object.keys(UPGRADES);

  function hash(n) { n = n | 0; n = (n ^ 61) ^ (n >>> 16); n = n + (n << 3); n = n ^ (n >>> 4); n = Math.imul(n, 0x27d4eb2d); n = n ^ (n >>> 15); return (n >>> 0) / 4294967296; }
  function tt(a) { return a.t + 1e-7; }
  function day(a) { return Math.floor(tt(a)); }
  function yday(a) { return Math.floor(tt(a) % YEAR_DAYS); }
  function year(a) { return Math.floor(tt(a) / YEAR_DAYS) + 1; }
  function season(a) { return Math.floor(yday(a) / SEASON_LEN); }
  function ev(a, kind, msg) { a.seq = (a.seq || 0) + 1; a.events.push({ seq: a.seq, t: a.t, kind: kind, msg: msg }); if (a.events.length > 60) a.events.shift(); }

  function hillFromRows(rows, lostToo) {
    var mask = [], white = [], lost = [];
    for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) {
      var ch = (rows[y] || '')[x] || '.';
      mask.push(ch === '#' ? 1 : 0); lost.push(ch === '+' && lostToo ? 1 : 0); white.push(ch === '#' ? 1 : 0);
    }
    return { mask: mask, white: white, lost: lost, kerb: new Array(W * H).fill(0), ram: new Array(W * H).fill(0) };
  }
  function newDown(seed) {
    var a = {
      v: 1, seed: seed || 1, t: 0, funds: START_FUNDS, earned: 0, levels: {}, scourers: 1, events: [], seq: 0,
      hills: [hillFromRows(OLD, true), null], handLeft: HAND[0], fair: null, fairs: [], won: false, wonAt: null,
      stats: { scoured: 0, wages: 0, tolls: 0, travellers: 0, fairs: 0, rammed: 0, kerbs: 0 },
    };
    /* the old figure has not been scoured in a generation: its edges are grey (deterministic from the seed) */
    var h = a.hills[0];
    for (var i = 0; i < W * H; i++) if (h.mask[i]) { var n = turfNeighbours(h, i); h.white[i] = Math.max(0.15, 0.95 - 0.12 * n - 0.25 * hash(a.seed * 31 + i * 7)); }
    return a;
  }
  function idx(x, y) { return y * W + x; }
  function inside(x, y) { return x >= 0 && y >= 0 && x < W && y < H; }
  function turfNeighbours(h, i) {
    var x = i % W, y = Math.floor(i / W), n = 0;
    for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) { if (!dx && !dy) continue; var X = x + dx, Y = y + dy; if (!inside(X, Y) || !h.mask[idx(X, Y)]) n++; }
    return n;
  }
  function metrics(h) {
    var area = 0, perim = 0, crispN = 0, wsum = 0;
    if (!h) return { area: 0, perimeter: 0, crisp: 0, detail: 0, visibility: 0, whiteness: 0 };
    for (var i = 0; i < W * H; i++) if (h.mask[i]) { area++; wsum += h.white[i]; if (h.white[i] >= LINE) crispN++; if (turfNeighbours(h, i) > 0) perim++; }
    var detail = area ? perim / (4 * Math.sqrt(area)) : 0;
    return { area: area, perimeter: perim, crisp: area ? crispN / area : 0, detail: detail, visibility: Math.sqrt(area / 100), whiteness: area ? wsum / area : 0 };
  }
  /* fame: a grey figure still draws a trickle (the 0.2 floor inside the square, so an idle hill can bootstrap: without
   * it an idle hill sat at 25% crisp earning nothing for 40 years), and DETAIL is weighed steeply (to the 1.5) so an intricate
   * figure is worth its upkeep (without it a plain block tied the intricate figure) */
  function fameOf(a, h) { if (!h) return 0; var m = metrics(h); var c = 0.2 + 0.8 * m.crisp; return 10 * c * c * Math.pow(m.detail, 1.5) * m.visibility * (a.levels.viewpoint ? 1.5 : 1); }
  function fame(a) { return fameOf(a, a.hills[0]) + fameOf(a, a.hills[1]); }

  /* the worst figure cells first (lowest whiteness), ties by index: the order hired labour and fair labour work in */
  function worstCells(a) {
    var out = [];
    for (var k = 0; k < 2; k++) { var h = a.hills[k]; if (!h) continue; for (var i = 0; i < W * H; i++) if (h.mask[i] && h.white[i] < 1) out.push([h.white[i], k, i]); }
    out.sort(function (p, q) { return p[0] - q[0] || p[1] - q[1] || p[2] - q[2]; });
    return out;
  }
  function applyLabour(a, units) {
    var cells = worstCells(a), used = 0;
    for (var j = 0; j < cells.length && units - used > 1e-9; j++) { var h = a.hills[cells[j][1]], i = cells[j][2], take = Math.min(1 - h.white[i], units - used); h.white[i] += take; used += take; }
    a.stats.scoured += used; return used;
  }
  /* the ROUND: hired scourers walk the figure in a fixed order from a.cursor (hill 0 then hill 1, cell order), re-cutting
   * each cell they reach to full white, K cells a day; a white cell is not on the round. Worst-first
   * labour LEVELLED the figure, so a deficit was invisible until every cell crossed the line together (a step); on a
   * round a cell waits a lap, so the share that greys follows the lap's length and the corners' creep */
  function sweepLabour(a, K) {
    var total = 2 * W * H, c = a.cursor || 0, n = 0, used = 0;
    for (var st = 0; st < total && n < K; st++) {
      var g = (c + st) % total, k = g >= W * H ? 1 : 0, i = g % (W * H), h = a.hills[k];
      /* a kerbed cell stays ON the round until it is white: a kerb laid on a grey cell froze it grey for good when the
       * round skipped every kerb (0.22 white stayed 0.22 for three years), and nine such corners could silently cap a
       * figure under the great scouring's line. Once white, a kerbed cell never greys, so the round passes it by */
      if (!h || !h.mask[i] || h.white[i] >= 0.999) continue;
      used += 1 - h.white[i]; h.white[i] = 1; n++; a.cursor = (g + 1) % total;
    }
    a.stats.scoured += used; return used;
  }
  /* the kerb gang: the most exposed unkerbed cell (most turf neighbours, three or more), first by hill then cell order.
   * At five or more the gang ran out of cells to edge with an idle horse still at 81..88% crisp under the 0.9 line; down
   * to three it never runs out. It is NOT a funds sink (25 a season against ~2,000 a year of income) */
  function gangCell(a) {
    var best = null;
    for (var k = 0; k < 2; k++) { var h = a.hills[k]; if (!h) continue; for (var i = 0; i < W * H; i++) { if (!h.mask[i] || h.kerb[i]) continue; var n = turfNeighbours(h, i); if (!best || n > best[0]) best = [n, k, i]; } }
    return best && best[0] >= 3 ? best : null;
  }
  function handLevel(a) { return a.levels.steel ? 2 : a.levels.spades ? 1 : 0; }
  function whyNotScour(a, k, i) {
    var h = a.hills[k]; if (!h) return 'that hill is not yours yet';
    if (!(i >= 0 && i < W * H)) return 'off the down';
    if (!h.mask[i]) return h.lost[i] ? 'a lost line: the antiquarians have not found it yet' : 'that is turf, not the figure';
    if (h.white[i] >= 0.999) return 'that chalk is already white';
    if (a.handLeft < 1) return 'your hands are done for today';
    return '';
  }
  function scour(a, k, i) { var w = whyNotScour(a, k, i); if (w) return w; var h = a.hills[k]; h.white[i] = Math.min(1, h.white[i] + HAND_AMOUNT); a.handLeft -= 1; a.stats.scoured += HAND_AMOUNT; return ''; }
  function whyNotKerb(a, k, i) { var h = a.hills[k]; if (!a.levels.kerbs) return 'KERBS are not bought yet'; if (!h || !h.mask[i]) return 'kerbs go on the figure'; if (h.kerb[i]) return 'that cell is kerbed'; if (a.funds < kerbCost(a)) return 'not enough funds (' + kerbCost(a) + ')'; return ''; }
  function kerb(a, k, i) { var w = whyNotKerb(a, k, i); if (w) return w; a.funds -= kerbCost(a); a.hills[k].kerb[i] = 1; a.stats.kerbs++; return ''; }
  function ramLeft(a) { return RAM_CARTS[a.levels.carts ? 2 : a.levels.pit ? 1 : 0] - (a.rammedThisSeason || 0); }
  function whyNotRam(a, k, i) { var h = a.hills[k]; if (!a.levels.pit) return 'THE CHALK PIT is not bought yet'; if (!h || !h.mask[i]) return 'fresh chalk goes on the figure'; if (ramLeft(a) <= 0) return 'the carts are done for this season'; if (a.funds < RAM_COST) return 'not enough funds (' + RAM_COST + ')'; return ''; }
  function ram(a, k, i) { var w = whyNotRam(a, k, i); if (w) return w; var h = a.hills[k]; a.funds -= RAM_COST; h.white[i] = 1; h.ram[i] = RAM_YEARS * YEAR_DAYS; a.rammedThisSeason = (a.rammedThisSeason || 0) + 1; a.stats.rammed++; return ''; }
  function whyNotBuy(a, key) { var u = UPGRADES[key]; if (!u) return 'no such upgrade'; if (a.levels[key]) return 'already bought'; if (a.earned < u.earned) return 'opens when the hill has earned ' + u.earned; if (a.funds < u.price) return 'not enough funds (' + u.price + ')'; return ''; }
  function buy(a, key) {
    var w = whyNotBuy(a, key); if (w) return w; var u = UPGRADES[key];
    a.funds -= u.price; a.levels[key] = 1;
    if (/^scourer/.test(key)) { a.scourersHired = (a.scourersHired || a.scourers) + 1; a.scourers += 1; }
    if (key === 'antiq') { var h = a.hills[0]; for (var i = 0; i < W * H; i++) if (h.lost[i]) { h.mask[i] = 1; h.white[i] = 0.05; h.lost[i] = 0; } }
    if (key === 'hill2') a.hills[1] = hillFromRows(PRESETS.giant, false), a.hills[1].white = a.hills[1].mask.map(function () { return 0; }), a.cutting = true;
    ev(a, 'unlock', u.name + ': ' + u.what);
    return '';
  }
  /* the second hill: the figure is DRAWN (mask cells toggled) while cutting is open; a newly cut cell starts at 0 white
   * and has to be scoured in like any other. Cutting closes when the player says so (or at the next fair). */
  function whyNotCut(a, i, on) { var h = a.hills[1]; if (!h) return 'the second hill is not yours yet'; if (!a.cutting) return 'the cutting is closed'; if (!(i >= 0 && i < W * H)) return 'off the down'; if (!!h.mask[i] === !!on) return on ? 'already cut' : 'not cut'; return ''; }
  function cut(a, i, on) { var w = whyNotCut(a, i, on); if (w) return w; var h = a.hills[1]; h.mask[i] = on ? 1 : 0; h.white[i] = 0; h.kerb[i] = 0; h.ram[i] = 0; return ''; }
  /* closing the cutting by hand (the next fair would close it anyway, if the figure is big enough) */
  /* a figure can be closed only if it can be crowned: big enough AND famous enough when white (an 8x8 block is 64 cells
   * and fame 6.5, so closing it would have locked the player out of the win) */
  function whyNotClose(a) { if (!a.hills[1]) return 'the second hill is not yours yet'; if (!a.cutting) return 'the cutting is already closed'; var m = metrics(a.hills[1]); if (m.area < MIN_OWN_AREA) return 'your figure needs ' + MIN_OWN_AREA + ' cells to close the cutting (it has ' + m.area + ')'; var fc = fameIfCrisp(a, a.hills[1]); if (fc < MIN_OWN_FAME) return 'your figure would draw fame ' + Math.round(fc) + ' when white and the great scouring needs ' + MIN_OWN_FAME + ': give it more corners and limbs'; return ''; }
  /* proclaiming the great scouring: once your figure has stood through a fair, pay for the vale to come up NEXT summer
   * rather than wait for the fourth (the last act was a dead wait of up to four years with every box ticked) */
  var PROCLAIM_COST = 2500;
  function proclaimYear(a) { return yday(a) < FAIR_DAY ? year(a) : year(a) + 1; }
  function whyNotProclaim(a) { if (a.won) return 'the great scouring has been held'; if (!a.levels.fair) return 'THE SCOURING FAIR is not restored yet'; if (!a.hills[1] || a.cutting) return 'your figure must be cut and the cutting closed first'; if ((a.hill2Fairs || 0) < 1) return 'your figure must stand through one fair first'; if (a.fair) return 'a fair is on the hill now'; if (a.proclaimed) return 'it is proclaimed for summer, year ' + a.proclaimed; if (proclaimYear(a) % FAIR_EVERY === 0) return 'a fair comes next summer anyway'; if (a.funds < PROCLAIM_COST) return 'not enough funds (' + PROCLAIM_COST + ')'; return ''; }
  function proclaim(a) { var w = whyNotProclaim(a); if (w) return w; a.funds -= PROCLAIM_COST; a.proclaimed = proclaimYear(a); ev(a, 'proclaim', 'THE GREAT SCOURING is proclaimed for summer, year ' + a.proclaimed + ': the vale will come up the hill then, and judge both figures as it finds them.'); return ''; }
  function closeCutting(a) { var w = whyNotClose(a); if (w) return w; a.cutting = false; ev(a, 'cut', 'The cutting is closed: your figure is ' + metrics(a.hills[1]).area + ' cells. It must stand through a fair before one can crown it.'); return ''; }
  /* reopening it: a changed figure has stood through nothing, so the count of fairs it stood through starts again */
  function whyNotReopen(a) { if (!a.hills[1]) return 'the second hill is not yours yet'; if (a.cutting) return 'the cutting is open'; if (a.fair) return 'not while the fair is on the hill'; return ''; }
  function reopenCutting(a) { var w = whyNotReopen(a); if (w) return w; a.cutting = true; a.hill2Fairs = 0; ev(a, 'cut', 'The cutting is open again: a changed figure must stand through a fair before one can crown it.'); return ''; }
  /* the fame a hill's figure would draw if every cell of it were white: the editor's honest forecast */
  function fameIfCrisp(a, h) { if (!h) return 0; var c = 0.2 + 0.8 * metrics(h).crisp; return fameOf(a, h) / (c * c); }
  function usePreset(a, name) { if (!a.hills[1] || !a.cutting || !PRESETS[name]) return 'no'; var p = hillFromRows(PRESETS[name], false); a.hills[1].mask = p.mask; a.hills[1].white = p.mask.map(function () { return 0; }); a.hills[1].kerb.fill(0); a.hills[1].ram.fill(0); return ''; }

  function dawn(a) {
    var d = yday(a), s = season(a);
    if (d % SEASON_LEN === 0) {
      a.rammedThisSeason = 0;
      /* wages: the hill pays what it can and an unpaid hand LEAVES for the season, never a debt (a hill that owed its
       * wages fell into a death spiral); the first scourer is the village's old man, who works for his keep when there is no
       * money, so the hill always has one pair of hands: no dead end */
      var hired = a.scourersHired || a.scourers, canPay = Math.max(0, Math.floor(a.funds / WAGE)), paid = Math.min(hired, canPay);
      a.scourers = Math.max(1, paid); a.scourersHired = hired;
      var wage = paid * WAGE; a.funds -= wage; a.stats.wages += wage;
      ev(a, 'season', SEASONS[s] + ', year ' + year(a) + '. Wages ' + wage + ' for ' + paid + ' of ' + hired + ' scourer' + (hired > 1 ? 's' : '') + (paid === 0 && hired > 0 ? ': the hill could not pay its hands, so they went home for the season; the old village scourer works on for his keep' : paid < hired ? ': the hill could not pay the rest, and they went home for the season' : '') + '.');
      if (a.levels.kerbgang && a.funds >= GANG_SPARE + kerbCost(a)) {
        var gc = gangCell(a);
        if (gc) { a.funds -= kerbCost(a); a.hills[gc[1]].kerb[gc[2]] = 1; a.stats.kerbs++; ev(a, 'kerb', 'The kerb gang edged the most exposed cell on ' + (gc[1] ? 'your figure' : 'the old figure') + '.'); }
      }
    }
    /* creep */
    for (var k = 0; k < 2; k++) {
      var h = a.hills[k]; if (!h) continue;
      for (var i = 0; i < W * H; i++) {
        if (!h.mask[i]) continue;
        if (h.ram[i] > 0) h.ram[i] -= 1;
        if (h.kerb[i]) continue;
        var n = turfNeighbours(h, i); if (!n) continue;
        var y = Math.floor(i / W), rate = CREEP[s] * (n / 8) * SLOPE[y] * (h.ram[i] > 0 ? RAM_FACTOR : 1);
        h.white[i] = Math.max(0, h.white[i] - rate);
      }
    }
    /* labour: scourers, then the fair's crowd */
    sweepLabour(a, a.scourers * REACH);
    if (a.fair) applyLabour(a, a.fair.crowd * FAIR_LABOUR);
    /* the road */
    var f = fame(a), trav = TRAVEL_K * f, toll = trav * TOLL;
    if (a.fair) toll += a.fair.crowd * FAIR_SPEND;
    a.funds += toll; a.earned += toll; a.stats.tolls += toll; a.stats.travellers += trav;
    a.handLeft = HAND[handLevel(a)];
    /* the fair */
    if (a.levels.fair && !a.fair && d === FAIR_DAY && (year(a) % FAIR_EVERY === 0 || a.proclaimed === year(a))) {
      a.proclaimed = 0;
      var crowd = Math.round(20 * f * (a.levels.train ? 1.5 : 1));
      a.fair = { opened: a.t, crowd: crowd, fameAtOpen: f, year: year(a) };
      ev(a, 'fair', 'THE SCOURING FAIR: ' + crowd + ' people came up the hill (the figure\'s fame was ' + Math.round(f) + ').');
      /* the exam is the figures AS THE VALE FINDS THEM: the fair's crowd scours at 45..125 whiteness a day, so judged at
       * the close it whitened any hill in a day and nothing before it mattered. Your figure
       * must have stood through one fair already (the first fair after the hill closes the cutting) */
      if (!a.won && greatScouring(a)) { a.won = true; a.wonAt = a.t; ev(a, 'win', 'THE GREAT SCOURING: the vale came up the hill and found both figures white.'); }
    } else if (a.fair && d >= FAIR_DAY + FAIR_LEN) closeFair(a);
  }
  function closeFair(a) {
    var m0 = metrics(a.hills[0]), m1 = metrics(a.hills[1]);
    var rec = { year: a.fair.year, crowd: a.fair.crowd, crisp: [m0.crisp, a.hills[1] ? m1.crisp : null], white: [a.hills[0].white.slice(), a.hills[1] ? a.hills[1].white.slice() : null], mask: [a.hills[0].mask.slice(), a.hills[1] ? a.hills[1].mask.slice() : null] };
    a.fairs.push(rec); if (a.fairs.length > 12) a.fairs.shift();
    a.stats.fairs++; a.fair = null;
    /* your figure must have STOOD THROUGH a fair before one can be the great scouring: the first fair after the hill is
     * yours closes the cutting, the next can crown it (without this an attentive hill won in year 6, ~9 min at 1x).
     * A figure under MIN_OWN_AREA keeps the cutting OPEN: closing it there would leave a hill that can never be crowned
     * (no dead end), so it stands through nothing until it is big enough */
    if (a.hills[1]) {
      if (!a.cutting) a.hill2Fairs = (a.hill2Fairs || 0) + 1;
      else if (!whyNotClose(a)) { a.cutting = false; a.hill2Fairs = (a.hill2Fairs || 0) + 1; ev(a, 'cut', 'The fair closed the cutting: your figure (' + m1.area + ' cells) has stood through this fair, so the next can crown it.'); }
      else { a.hill2Fairs = 0; ev(a, 'cut', 'The cutting stays open: ' + whyNotClose(a) + '.'); }
    } else a.cutting = false;
    ev(a, 'fair', 'The fair closed: the old figure ' + Math.round(m0.crisp * 100) + '% crisp' + (a.hills[1] ? ', yours ' + Math.round(m1.crisp * 100) + '%' : '') + '.');
  }
  function greatScouring(a) {
    if (!a.hills[1]) return false;
    var m0 = metrics(a.hills[0]), m1 = metrics(a.hills[1]);
    return a.hill2Fairs >= 1 && m0.crisp >= WIN_CRISP && m1.crisp >= WIN_CRISP && m1.area >= MIN_OWN_AREA && fameOf(a, a.hills[1]) >= MIN_OWN_FAME;
  }
  function micro(a, dt) { var old = day(a); a.t += dt; if (day(a) !== old) dawn(a); }
  function step(a, dt) { while (dt > 1e-12) { var edge = day(a) + 1 - a.t, h = Math.min(dt, STEP, Math.max(1e-9, edge)); micro(a, h); dt -= h; } }
  function settleAway(a, seconds) { var days = Math.min(AWAY_CAP_DAYS, Math.max(0, seconds / DAY_SEC)); if (days < 0.5) return null; var f0 = a.funds; step(a, days); return { days: Math.round(days * 10) / 10, funds: Math.round(a.funds - f0) }; }

  return {
    DAY_SEC: DAY_SEC, SEASON_LEN: SEASON_LEN, YEAR_DAYS: YEAR_DAYS, SEASONS: SEASONS, W: W, H: H, LINE: LINE, AWAY_CAP_DAYS: AWAY_CAP_DAYS,
    CREEP: CREEP, SLOPE: SLOPE, HAND: HAND, WAGE: WAGE, FAIR_EVERY: FAIR_EVERY, FAIR_DAY: FAIR_DAY, FAIR_LEN: FAIR_LEN, WIN_CRISP: WIN_CRISP, MIN_OWN_AREA: MIN_OWN_AREA, MIN_OWN_FAME: MIN_OWN_FAME,
    KERB_COST: KERB_COST, RAM_COST: RAM_COST, REACH: REACH, GANG_SPARE: GANG_SPARE, RAM_CARTS: RAM_CARTS, UPGRADES: UPGRADES, UPGRADE_ORDER: UPGRADE_ORDER, PRESETS: PRESETS, OLD: OLD,
    hash: hash, day: day, yday: yday, year: year, season: season, idx: idx, turfNeighbours: turfNeighbours, metrics: metrics, fame: fame, fameOf: fameOf,
    newDown: newDown, step: step, settleAway: settleAway, scour: scour, whyNotScour: whyNotScour, kerb: kerb, whyNotKerb: whyNotKerb, ram: ram, whyNotRam: whyNotRam, ramLeft: ramLeft,
    buy: buy, whyNotBuy: whyNotBuy, cut: cut, whyNotCut: whyNotCut, usePreset: usePreset, worstCells: worstCells, gangCell: gangCell, greatScouring: greatScouring,
    closeCutting: closeCutting, whyNotClose: whyNotClose, proclaim: proclaim, whyNotProclaim: whyNotProclaim, proclaimYear: proclaimYear, PROCLAIM_COST: PROCLAIM_COST, kerbCost: kerbCost, KERB_STEP: KERB_STEP, reopenCutting: reopenCutting, whyNotReopen: whyNotReopen, fameIfCrisp: fameIfCrisp, sweepCursor: function (a) { return a.cursor || 0; }, RAM_YEARS: RAM_YEARS, CREEP_RAM: RAM_FACTOR, HAND_AMOUNT: HAND_AMOUNT, TOLL: TOLL, TRAVEL_K: TRAVEL_K,
  };
})();

if (typeof module !== 'undefined') module.exports = SIM;
