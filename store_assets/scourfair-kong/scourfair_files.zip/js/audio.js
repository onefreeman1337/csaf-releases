/**
 * audio.js - SCOURFAIR's sound: effects synthesised live with WebAudio, plus one composed music loop
 * (audio/scourfair_theme.ogg). Effects: a soft tick, a spade biting chalk, a cart of fresh chalk tipped and rammed, a
 * kerb timber knocked in, coins for a purchase, a chime for an unlock, a thud for a refusal, two tones for a season, the
 * fair (a crowd and a fiddle's open strings), the church bell when a fair closes, and the fanfare of the great scouring.
 * A low wind bed sits under the down while you play. Muting is remembered and PAUSES the music (iPhone Safari ignores a
 * media element's volume). Every cue passes a limiter and a soft clip, so a pile-up cannot reach full scale.
 */
'use strict';

var AUDIO = (function () {
  var ctx = null, master = null, muted = false, noiseBuf = null, BUS = 1.6, MUSIC_VOL = 0.26, windNode = null;
  try { muted = localStorage.getItem('scourfair.muted') === '1'; } catch (e) { /* storage blocked */ }
  var music = null;
  function playMusic() {
    if (!music || muted || document.hidden || !music.paused) return;
    var pr = music.play(); if (pr && pr.catch) pr.catch(function () { /* autoplay refused: the next tap retries */ });
  }
  function startMusic() {
    if (music) { playMusic(); return; }
    try { music = new Audio('audio/scourfair_theme.ogg'); music.loop = true; music.volume = MUSIC_VOL; playMusic(); } catch (e) { music = null; }
  }
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) { if (music) music.pause(); if (ctx && ctx.state === 'running') ctx.suspend(); }
    else { playMusic(); if (ctx && ctx.state === 'suspended') ctx.resume(); }
  });
  function unlock() {
    startMusic();
    if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    try {
      ctx = new AC();
      master = ctx.createGain(); master.gain.value = muted ? 0 : BUS;
      var lim = null, safe = null;
      try { lim = ctx.createDynamicsCompressor(); lim.threshold.value = -6; lim.knee.value = 4; lim.ratio.value = 20; lim.attack.value = 0.002; lim.release.value = 0.15; } catch (e) { lim = null; }
      /* a soft clip after the limiter: unity below 0.8, rounding into a 0.952 ceiling above */
      try {
        safe = ctx.createWaveShaper(); var cvv = new Float32Array(2049);
        for (var ci = 0; ci < cvv.length; ci++) { var xx = ci / 1024 - 1, ax = Math.abs(xx), yy = ax < 0.8 ? ax : 0.8 + 0.2 * Math.tanh((ax - 0.8) / 0.2); cvv[ci] = xx < 0 ? -yy : yy; }
        safe.curve = cvv;
      } catch (e) { safe = null; }
      var chain = master;
      if (lim) { chain.connect(lim); chain = lim; }
      if (safe) { chain.connect(safe); chain = safe; }
      chain.connect(ctx.destination);
      noiseBuf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
      /* xorshift32: a float multiply past 2^53 dropped the low bits and the old generator repeated every 10,466 samples
       * (about four times a second), so the wind bed was a buzz; this one does not repeat inside the buffer */
      var d = noiseBuf.getChannelData(0), s = 24680;
      for (var i = 0; i < d.length; i++) { s ^= s << 13; s ^= s >>> 17; s ^= s << 5; d[i] = ((s >>> 0) / 4294967296) * 2 - 1; }
    } catch (e) { ctx = null; }
  }
  function tone(freq, dur, type, vol, slide, delay) {
    if (!ctx || muted) return;
    var t = ctx.currentTime + (delay || 0);
    var o = ctx.createOscillator(), gn = ctx.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(freq, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, freq * slide), t + dur);
    gn.gain.setValueAtTime(0.0001, t); gn.gain.exponentialRampToValueAtTime(vol || 0.2, t + 0.01); gn.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(gn); gn.connect(master); o.start(t); o.stop(t + dur + 0.02);
  }
  function noise(dur, freq, q, vol, sweep, delay, type, attack) {
    if (!ctx || muted || !noiseBuf) return;
    var t = ctx.currentTime + (delay || 0);
    /* the noise buffer is one second long: it LOOPS, or a long cue played from a random offset stops dead part way
     * (the fair's 2.2 s crowd was once audible for under a second) */
    var src = ctx.createBufferSource(); src.buffer = noiseBuf; src.loop = true;
    var f = ctx.createBiquadFilter(); f.type = type || 'bandpass'; f.frequency.setValueAtTime(freq, t); f.Q.value = q || 1;
    if (sweep) f.frequency.exponentialRampToValueAtTime(freq * sweep, t + dur);
    var gn = ctx.createGain(); gn.gain.setValueAtTime(0.0001, t); gn.gain.exponentialRampToValueAtTime(vol || 0.2, t + (attack || 0.02)); gn.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f); f.connect(gn); gn.connect(master); src.start(t, Math.random() * 0.5); src.stop(t + dur + 0.05);
  }
  var API = {
    tick: function () { tone(880, 0.05, 'triangle', 0.06); },
    /* a spade biting chalk: a short gritty scrape and the click of the blade on flint */
    scour: function () { noise(0.16, 2400, 1.4, 0.11, 0.6, 0, 'bandpass', 0.008); noise(0.05, 5200, 3, 0.05, 0.9, 0.11, 'highpass'); tone(320 + Math.random() * 60, 0.04, 'triangle', 0.05, 0.8, 0.02); },
    /* a cart tipped: a low rumble, then three blows of the rammer */
    ram: function () { noise(0.45, 260, 0.8, 0.12, 0.6, 0, 'lowpass', 0.05); for (var i = 0; i < 3; i++) { tone(95, 0.12, 'sine', 0.14, 0.6, 0.35 + i * 0.16); noise(0.06, 900, 1.2, 0.06, 0.6, 0.35 + i * 0.16, 'lowpass'); } },
    /* a kerb timber knocked in: two dry wooden knocks */
    kerb: function () { for (var i = 0; i < 2; i++) { tone(410 - i * 40, 0.07, 'square', 0.05, 0.7, i * 0.13); noise(0.05, 1500, 3, 0.07, 0.7, i * 0.13); } },
    coin: function () { tone(1320, 0.09, 'square', 0.04); tone(1760, 0.18, 'square', 0.035, 1, 0.07); },
    chime: function () { tone(659, 0.35, 'sine', 0.12); tone(988, 0.45, 'sine', 0.09, 1, 0.09); tone(1319, 0.5, 'sine', 0.05, 1, 0.18); },
    thud: function () { tone(140, 0.14, 'triangle', 0.12, 0.6); },
    season: function () { tone(440, 0.3, 'sine', 0.07); tone(587, 0.4, 'sine', 0.06, 1, 0.14); },
    /* the fair opens: three beats of a tabor, a crowd swelling up the hill and a fiddle's open strings */
    fair: function () { for (var b = 0; b < 3; b++) { tone(150, 0.12, 'sine', 0.13, 0.7, b * 0.24); noise(0.05, 1800, 2, 0.05, 0.7, b * 0.24); } noise(2.2, 700, 0.4, 0.06, 1.3, 0, 'bandpass', 0.6); var n = [196, 294, 440, 659]; for (var i = 0; i < n.length; i++) tone(n[i], 0.9, 'sawtooth', 0.025, 1, 0.2 + i * 0.12); },
    /* the church bell when a fair closes */
    bell: function () { tone(523, 2.0, 'sine', 0.09); tone(1046, 1.3, 'sine', 0.035); tone(1567, 0.8, 'sine', 0.015); tone(659, 1.6, 'sine', 0.02, 1, 0.01); },
    fanfare: function () { var n = [294, 370, 440, 587, 740, 880]; for (var i = 0; i < n.length; i++) tone(n[i], 0.7, 'triangle', 0.1, 1, i * 0.15); },
  };
  var SFX_CUES = Object.keys(API);
  /* a low wind over the down while the hill is in play: a looped band of noise, faded in and out */
  API.wind = function (on) {
    if (!ctx || !noiseBuf) return;
    var want = on && !muted ? 0.045 : 0;
    if (!windNode && !want) return;
    if (!windNode) {
      try {
        var src = ctx.createBufferSource(); src.buffer = noiseBuf; src.loop = true;
        var f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 520; f.Q.value = 0.6;
        var gn = ctx.createGain(); gn.gain.value = 0.0001; src.connect(f); f.connect(gn); gn.connect(master); src.start();
        windNode = { src: src, gain: gn, level: 0 };
      } catch (e) { return; }
    }
    if (Math.abs(windNode.level - want) > 1e-4) { windNode.level = want; windNode.gain.gain.setTargetAtTime(Math.max(0.0001, want), ctx.currentTime, 0.8); }
  };
  API.unlock = unlock;
  API.SFX_CUES = SFX_CUES;
  API.toggleMute = function () {
    muted = !muted;
    try { localStorage.setItem('scourfair.muted', muted ? '1' : '0'); } catch (e) { /* storage blocked */ }
    if (master) master.gain.value = muted ? 0 : BUS;
    if (music) { if (muted) music.pause(); else playMusic(); }
    return muted;
  };
  API.muted = function () { return muted; };
  API.musicPlaying = function () { return !!music && !music.paused; };
  return API;
})();
