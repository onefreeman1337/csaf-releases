/**
 * vale.js - SCOURFAIR's view from the road: the two downs with their figures on them, foreshortened on a convex slope,
 * above a vale of fields, hedges, the road, the inn and the church. Drawn pixel by pixel into a small buffer (each screen
 * pixel finds its place on the slope, then its figure cell) and scaled up nearest-neighbour by the caller, so the
 * figures on the downs are the SAME cells the player scours, at the same whiteness.
 * The turf and the chalk are sampled from the game's own ground plates (art/plate_down.png, art/plate_chalk.png).
 */
'use strict';

var VALE = (function () {
  var PL = {};
  /* a plate's pixels, read once from its image (same origin, so the canvas is never tainted) */
  function setPlate(key, img) {
    try {
      var c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
      var x = c.getContext('2d'); x.drawImage(img, 0, 0);
      PL[key] = { w: img.width, h: img.height, d: x.getImageData(0, 0, img.width, img.height).data };
    } catch (e) { /* keep the flat colours */ }
  }
  function px(key, x, y, flat) {
    var p = PL[key]; if (!p) return flat;
    var xx = ((x % p.w) + p.w) % p.w, yy = ((y % p.h) + p.h) % p.h, o = (yy * p.w + xx) * 4;
    return [p.d[o], p.d[o + 1], p.d[o + 2]];
  }
  function mix(a, b, t) { t = t < 0 ? 0 : t > 1 ? 1 : t; return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }
  function mul(a, k) { return [a[0] * k, a[1] * k, a[2] * k]; }
  function hash(n) { n = n | 0; n = (n ^ 61) ^ (n >>> 16); n = n + (n << 3); n = n ^ (n >>> 4); n = Math.imul(n, 0x27d4eb2d); n = n ^ (n >>> 15); return (n >>> 0) / 4294967296; }

  var SKY = {
    dawn: [[46, 52, 98], [128, 98, 132], [246, 176, 124]],
    day: [[[104, 150, 206], [176, 204, 228], [222, 232, 236]], [[86, 140, 208], [168, 202, 232], [232, 234, 222]], [[110, 128, 162], [186, 184, 186], [232, 206, 166]], [[136, 152, 176], [192, 200, 212], [226, 228, 232]]],
  };
  /* field colours by season, and the turf's tint by season (spring lush, summer straw, autumn olive, winter pale) */
  var FIELDS = [
    [[110, 152, 72], [96, 138, 62], [132, 164, 84], [150, 172, 92], [120, 146, 70]],
    [[182, 164, 82], [120, 150, 70], [200, 180, 98], [104, 140, 64], [168, 150, 72]],
    [[150, 118, 68], [118, 108, 62], [172, 142, 88], [98, 110, 60], [136, 96, 58]],
    [[150, 160, 150], [128, 138, 126], [172, 178, 170], [118, 128, 116], [140, 146, 136]],
  ];
  var TURF_TINT = [[1.0, 1.06, 0.94], [1.08, 1.04, 0.86], [1.06, 0.96, 0.84], [1.0, 1.0, 1.04]];
  var CHALK_GREY = [176, 182, 152], HEDGE = [44, 70, 40], ROAD = [204, 192, 158], ROAD_EDGE = [150, 138, 110];

  /* the two downs in a buffer of LW x LH: the old hill (left, nearer) and the second hill (right, a little farther) */
  function downs(LW, LH) {
    return [
      { cx: LW * 0.285, yTop: LH * 0.20, yFoot: LH * 0.715, h0: LW * 0.135, h1: LW * 0.215, spread: 1.6 },
      { cx: LW * 0.735, yTop: LH * 0.255, yFoot: LH * 0.70, h0: LW * 0.12, h1: LW * 0.19, spread: 1.6 },
    ];
  }
  var V0 = 0.15, V1 = 0.93;   // the band of the slope the figure grid occupies (rows 0..H-1)
  function crestY(d, x) { var k = (x - d.cx) / (d.h1 * d.spread); return d.yTop + (d.yFoot - d.yTop) * 0.82 * k * k; }
  function roadY(LW, LH, x) { var top = LH * 0.72; return top + (LH - top) * 0.52 + LH * 0.022 * Math.sin(x / LW * 5.3 + 0.6); }

  /* where a figure cell lands on screen (its centre), for overlays: hill k, cell (cx, cy) */
  function cellPos(LW, LH, k, cxl, cyl, W, H) {
    var d = downs(LW, LH)[k], vv = V0 + (V1 - V0) * ((cyl + 0.5) / H), v = Math.pow(vv, 1.45), half = d.h0 + (d.h1 - d.h0) * vv;
    return { x: d.cx + ((cxl + 0.5) / W - 0.5) * 2 * half, y: d.yTop + v * (d.yFoot - d.yTop) };
  }

  /**
   * render(img, LW, LH, o): img is an ImageData of LW x LH. o = { hills: [h0, h1], W, H, LINE, season 0..3, light 'dawn' |
   * 'day', t (seconds, for the clouds and the road), travellers (a day), fair (crowd or 0), seed }
   */
  function render(img, LW, LH, o) {
    var D = img.data, W = o.W, H = o.H, LINE = o.LINE, se = o.season || 0, dawn = o.light === 'dawn', t = o.t || 0;
    var dl = downs(LW, LH), sky = dawn ? SKY.dawn : SKY.day[se], tint = TURF_TINT[se];
    var sunX = LW * 0.51, sunY = LH * 0.36, sunR = LH * 0.055;
    var valeTop = LH * 0.70;
    for (var y = 0; y < LH; y++) {
      var sy = y / (LH * 0.62);
      var skyC = sy < 0.55 ? mix(sky[0], sky[1], sy / 0.55) : mix(sky[1], sky[2], (sy - 0.55) / 0.45);
      for (var x = 0; x < LW; x++) {
        var c = skyC;
        /* the sun (dawn), low in the coombe between the downs, with its glow */
        if (dawn) { var ds = Math.hypot(x - sunX, (y - sunY) * 1.1); if (ds < sunR) c = [255, 232, 176]; else if (ds < sunR * 4) c = mix(c, [255, 208, 150], 0.38 * (1 - (ds - sunR) / (sunR * 3))); }
        /* clouds: a few long soft bands drifting east */
        var cl = Math.sin((x + t * 2.2) / LW * 9.0 + y / LH * 3) * Math.sin((x + t * 1.3) / LW * 3.7 - y / LH * 11 + 1.3) + 0.35 * Math.sin((x + t * 3.1) / LW * 21 + y / LH * 7);
        if (y < LH * 0.5 && cl > 0.62) c = mix(c, dawn ? [250, 206, 178] : [246, 246, 244], Math.min(0.75, (cl - 0.62) * 2.4) * (1 - y / (LH * 0.5)));
        /* the far ridge behind, in haze */
        var ridge = LH * (0.465 + 0.028 * Math.sin(x / LW * 7.1) + 0.018 * Math.sin(x / LW * 15.3 + 1.1));
        if (y >= ridge) c = mix(mix(sky[2], [86, 112, 96], 0.5), [70, 94, 80], (y - ridge) / (LH * 0.25));
        /* the downs, second hill first so the old (nearer) one overlaps it at the coombe */
        for (var k = 1; k >= 0; k--) {
          var d = dl[k];
          if (y < crestY(d, x) || y > d.yFoot + LH * 0.02) continue;
          var v = Math.max(0, (y - d.yTop) / (d.yFoot - d.yTop)), vv = Math.pow(v, 1 / 1.45), half = d.h0 + (d.h1 - d.h0) * vv;
          var tc = px('down', x * 2 + k * 37, y * 2 + k * 53, [86, 128, 62]);
          tc = [tc[0] * tint[0], tc[1] * tint[1], tc[2] * tint[2]];
          var col = tc;
          var h = o.hills && o.hills[k];
          if (h && vv >= V0 && vv < V1) {
            var u = (x - d.cx) / (2 * half) + 0.5, cyl = Math.floor((vv - V0) / (V1 - V0) * H), cxl = Math.floor(u * W);
            if (u >= 0 && u < 1 && cyl >= 0 && cyl < H) {
              var i = cyl * W + cxl;
              if (h.mask[i]) {
                var wv = h.white[i], ch = px('chalk', x * 2, y * 2, [236, 234, 222]);
                if (h.ram && h.ram[i] > 0) ch = mix(ch, [255, 255, 250], 0.4);
                col = wv >= LINE ? mix(CHALK_GREY, ch, (wv - LINE) / (1 - LINE)) : mix(tc, CHALK_GREY, (wv / LINE) * 0.8);
              }
            }
          }
          /* light: the slope facing the sun is brighter, the crest recedes into haze, the foot darkens into the vale */
          var side = (x - d.cx) / (d.h1 * d.spread), lit = 1 + 0.1 * (k === 0 ? side : -side) - 0.08 * Math.abs(side) - 0.06 * v;
          col = mul(col, lit);
          col = mix(col, dawn ? [150, 128, 140] : sky[2], 0.28 * (1 - vv));
          /* a fair on the hill: tents along the crest and the crowd below the figure */
          if (o.fair && k === 0) {
            var tx = Math.floor((x - d.cx + d.h1) / 7), tentY = crestY(d, x) + LH * 0.035;
            if (tx >= 0 && tx < Math.floor(2 * d.h1 / 7) && hash(tx * 7 + 3) > 0.45 && y >= tentY - 4 && y < tentY && Math.abs((x - d.cx + d.h1) % 7 - 3) <= (y - (tentY - 4))) col = ((x + tx) % 2) ? [208, 70, 58] : [242, 236, 222];
            var clump = 0.5 + 0.5 * Math.sin(x * 0.21 + Math.floor(y / 3) * 1.7) * Math.sin(x * 0.07 + 0.9);
            if (v > 0.74 && v < 0.97 && hash(x * 131 + y * 977) < Math.min(0.07, o.fair / 20000) * clump * 2) col = [[196, 64, 52], [58, 68, 122], [228, 204, 120], [240, 236, 226]][Math.floor(hash(x * 17 + y * 31) * 4)];
          }
          c = col;
          break;
        }
        /* the vale: fields in perspective, hedges between them, trees in the hedges, the chalk road */
        if (y > valeTop && !(y < dl[0].yFoot + LH * 0.02 && y >= crestY(dl[0], x)) && !(y < dl[1].yFoot + LH * 0.02 && y >= crestY(dl[1], x))) {
          var dep = (y - valeTop) / (LH - valeTop), rowF = Math.sqrt(dep) * 5.2, row = Math.floor(rowF);
          var colF = (x / LW - 0.5) / (0.1 + 0.22 * dep) + row * 0.37, cl2 = Math.floor(colF);
          var fc = FIELDS[se][Math.floor(hash(row * 97 + cl2 * 13 + 5) * 5)];
          var plough = hash(row * 31 + cl2 * 7) > 0.55;
          if (plough && ((y + Math.floor(x * 0.3)) % 2 === 0)) fc = mul(fc, 0.9);
          fc = mul(fc, 0.86 + 0.18 * dep);
          var fr = rowF - row, fcc = colF - cl2;
          if (fr < 0.07 / (0.4 + dep) || fcc < 0.035 + 0.02 * (1 - dep)) { fc = HEDGE; if (hash(Math.floor(x / 2) * 41 + row * 11) > 0.84) fc = [30, 52, 30]; }
          var ry = roadY(LW, LH, x), rw = 0.8 + 1.4 * dep;
          if (Math.abs(y - ry) < rw) fc = ROAD; else if (Math.abs(y - ry) < rw + 0.9) fc = ROAD_EDGE;
          c = mix(fc, dawn ? [170, 140, 150] : sky[2], 0.22 * (1 - dep));
        }
        var off = (y * LW + x) * 4;
        D[off] = c[0]; D[off + 1] = c[1]; D[off + 2] = c[2]; D[off + 3] = 255;
      }
    }
    /* the village: the inn by the road, two cottages, the church; drawn as pixels into the same buffer */
    var put = function (x, y, col) { x = Math.round(x); y = Math.round(y); if (x < 0 || y < 0 || x >= LW || y >= LH) return; var off = (y * LW + x) * 4; D[off] = col[0]; D[off + 1] = col[1]; D[off + 2] = col[2]; };
    var house = function (hx, scale, wall, roof, lit) {
      var by = roadY(LW, LH, hx) - 2 - scale, w = Math.max(4, Math.round(6 * scale)), hh = Math.max(3, Math.round(4 * scale));
      for (var yy = 0; yy < hh; yy++) for (var xx = 0; xx < w; xx++) put(hx + xx, by - yy, wall);
      for (var r = 0; r < Math.ceil(w / 2) + 1; r++) for (var xx2 = r - 1; xx2 <= w - r; xx2++) put(hx + xx2, by - hh - r, roof);
      if (lit) { put(hx + 1, by - 1, dawn ? [255, 214, 120] : [80, 70, 60]); put(hx + w - 2, by - 1, dawn ? [255, 214, 120] : [80, 70, 60]); }
      return { x: hx, y: by - hh, w: w };
    };
    var sc = LW / 320;
    var inn = house(LW * 0.43, 1.6 * sc, [226, 214, 190], [128, 62, 50], true);
    house(LW * 0.55, 1.1 * sc, [214, 204, 182], [110, 92, 72], true);
    house(LW * 0.63, 1.0 * sc, [220, 210, 186], [128, 62, 50], false);
    /* the inn's sign and the smoke from its chimney */
    put(inn.x - 2, inn.y + 2, [92, 70, 48]); put(inn.x - 2, inn.y + 3, [92, 70, 48]); put(inn.x - 3, inn.y + 2, [220, 180, 70]);
    for (var s = 0; s < 4; s++) { var ph = ((t * 0.6 + s / 4) % 1); put(inn.x + inn.w - 2 + ph * 3, inn.y - 4 - ph * 9, mix([200, 196, 196], dawn ? [200, 160, 170] : sky[2], ph)); }
    /* the church: a tower and a spire */
    var chx = LW * 0.86, chy = roadY(LW, LH, chx) - 3;
    for (var ty = 0; ty < 9 * sc; ty++) for (var tx2 = 0; tx2 < 3 * sc; tx2++) put(chx + tx2, chy - ty, [176, 172, 164]);
    for (var sp = 0; sp < 6 * sc; sp++) put(chx + 1 * sc, chy - 9 * sc - sp, [120, 118, 116]);
    for (var nb = 0; nb < 6 * sc; nb++) for (var nh = 0; nh < 4 * sc; nh++) put(chx + 3 * sc + nb, chy - nh, [196, 190, 178]);
    /* travellers on the road, both ways, more of them the more famous the hill */
    var n = Math.max(2, Math.min(16, Math.round((o.travellers || 0) / 5) + 2));
    for (var q = 0; q < n; q++) {
      var dir = q % 2 ? 1 : -1, sp2 = 0.012 + 0.01 * hash(q * 13 + 1), tx3 = ((hash(q * 29 + (o.seed || 1)) + dir * t * sp2) % 1 + 1) % 1 * LW;
      var ty3 = roadY(LW, LH, tx3) - 1, cc = [[60, 52, 70], [120, 52, 46], [52, 66, 96], [90, 76, 48]][q % 4];
      put(tx3, ty3, cc); put(tx3, ty3 - 1, [220, 190, 160]);
      if (sc >= 0.9) put(tx3, ty3 - 2, cc);
    }
  }
  return { setPlate: setPlate, render: render, downs: downs, cellPos: cellPos, roadY: roadY, ready: function () { return !!(PL.down && PL.chalk); } };
})();

if (typeof module !== 'undefined') module.exports = VALE;
