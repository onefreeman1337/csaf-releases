/* VAMPIRE'S MORNING ROUTINE — the simulation.
 *
 * ⛔ THERE IS NO CANVAS IN THIS FILE, ON PURPOSE. The sim is a pure function of (state, dt, input),
 * so the harness that has to play the SHIPPED game from title to a real ending (wing §0z — there
 * is no human tester) plays exactly this code rather than a model of it. render.js draws a run;
 * main.js wires input and audio to one. Nothing else may reach in.
 */
'use strict';

/* ── tile classification ────────────────────────────────────────────────────────────────────── */
const FLOORISH = '.,=DKCGU@h';                  // you can stand here
const OPAQUE_TILE = '#B';                       // stops light AND you
const SHOVABLE = { R: 'wardrobe', T: 'table', H: 'chair', X: 'chest', E: 'crate' };
const SHOVE_OPAQUE = { R: true, T: false, H: false, X: false, E: true };  // only tall things cast shade

/* ── save ───────────────────────────────────────────────────────────────────────────────────────
 * ONE localStorage key. A corrupt or absent save starts night 1 rather than throwing: a save file
 * is hostile input, and a game that dies on it is a game that dies on somebody's first visit.
 */
const SAVE_KEY = 'vmr.save.v1';

function blankSave() {
  return { gloam: 0, owned: [], cleared: [], best: {}, night: 0, seen: [] };
}

function loadSave(storage) {
  try {
    const raw = (storage || globalThis.localStorage).getItem(SAVE_KEY);
    if (!raw) return blankSave();
    const s = JSON.parse(raw);
    if (!s || typeof s !== 'object') return blankSave();
    const out = blankSave();
    if (Number.isFinite(s.gloam) && s.gloam >= 0) out.gloam = Math.min(9999, s.gloam | 0);
    if (Array.isArray(s.owned)) out.owned = s.owned.filter((id) => UPGRADES.some((u) => u.id === id));
    if (Array.isArray(s.cleared)) out.cleared = s.cleared.filter((n) => Number.isInteger(n) && n >= 1 && n <= NIGHTS.length);
    if (Array.isArray(s.seen)) out.seen = s.seen.filter((n) => Number.isInteger(n));
    if (s.best && typeof s.best === 'object') {
      for (const [k, v] of Object.entries(s.best)) if (Number.isFinite(v)) out.best[k] = v;
    }
    // The furthest unlocked night, DERIVED from `cleared` rather than trusted from the file, so a
    // hand-edited save cannot skip content into a state the maps do not support.
    out.night = Math.min(NIGHTS.length - 1, out.cleared.length ? Math.max(...out.cleared) : 0);
    return out;
  } catch (e) {
    return blankSave();
  }
}

function writeSave(save, storage) {
  try { (storage || globalThis.localStorage).setItem(SAVE_KEY, JSON.stringify(save)); return true; }
  catch (e) { return false; }   // private mode, quota, a file:// sandbox — never a crash
}

function owns(save, id) { return save.owned.indexOf(id) >= 0; }

/* ── building a night ───────────────────────────────────────────────────────────────────────── */

/**
 * Parse a map into a lit scene.
 *
 * ⛔ SPLIT OUT OF `createRun` SO THE HOW-IT-WORKS DIAGRAMS ARE THE REAL GAME. The help screen used
 * to be thirteen lines of prose describing the light; it now shows four small rooms with the sun
 * actually cast through them. Those rooms are parsed HERE, occluded by `makeSolidFn` and bounced by
 * `makeMirrorFn` — the same three functions a night uses — so a diagram cannot drift from the game
 * it is explaining. light.js already refuses to keep two representations of the raster; this is the
 * same rule one level up, for the room.
 *
 * @param night {map, floor, wall, dawn?, sunFrom?} — a NIGHTS entry, or a HELP_SCENES one.
 */
function buildScene(night) {
  const grid = night.map.map((row) => row.split(''));
  const run = {
    night, nightIndex: 0, save: blankSave(),
    grid,
    t: 0,
    dawn: night.dawn || 60,
    phi: night.sunFrom || 0.5,
    player: { x: 0, y: 0, vx: 0, vy: 0, face: 'down', anim: 0, burn: 0, carrying: 0, dead: false },
    keeper: null,
    windows: [], skylights: [], mirrors: [], garlic: [], chutes: [], shoves: [], coffin: null,
    apertures: [],
    choreT: 0, choreOn: null,
    lidT: 0,
    screen: 'play',            // play | won | burnt | dawn
    events: [],                // one-frame cues the renderer and audio drain
    stats: { shuttered: 0, draped: 0, binned: 0, covered: 0 },
  };

  for (let r = 0; r < grid.length; r++) {
    for (let c = 0; c < grid[r].length; c++) {
      const ch = grid[r][c];
      const x = c * TILE + TILE / 2, y = r * TILE + TILE / 2;
      if (ch === '@') { run.player.x = x; run.player.y = y; grid[r][c] = '.'; }
      else if (ch === 'h') { run.keeper = { x, y, vx: 0, vy: 0, face: 'down', anim: 0, target: null, work: 0 }; grid[r][c] = '.'; }
      else if (ch === 'W') run.windows.push({ c, r, x, y, side: c === 0 ? 'left' : 'right', open: true, doing: 0 });
      else if (ch === 'K') run.skylights.push({ c, r, x, y, open: true });
      else if (ch === 'M') run.mirrors.push({ c, r, x, y, draped: false, doing: 0 });
      else if (ch === 'G') { run.garlic.push({ c, r, x, y, held: false, gone: false }); grid[r][c] = '.'; }
      else if (ch === 'U') run.chutes.push({ c, r, x, y });
      else if (ch === 'C') run.coffin = { c, r, x, y, shut: false };
      else if (SHOVABLE[ch]) { run.shoves.push({ kind: SHOVABLE[ch], x, y, opaque: !!SHOVE_OPAQUE[ch] }); grid[r][c] = '.'; }
    }
  }
  run.apertures = run.windows.map((w) => ({ kind: 'window', side: w.side, x: w.x, y: w.y, open: true, ref: w }))
    .concat(run.skylights.map((k) => ({ kind: 'skylight', side: 'up', x: k.x, y: k.y, open: true, ref: k })));

  run.raster = makeRaster();
  run.total = {
    windows: run.windows.length, mirrors: run.mirrors.length,
    garlic: run.garlic.length, skylights: run.skylights.length,
  };
  recomputeLight(run);
  return run;
}

function createRun(nightIndex, save) {
  const i = Math.max(0, Math.min(NIGHTS.length - 1, nightIndex | 0));
  const run = buildScene(NIGHTS[i]);
  run.nightIndex = i;
  run.save = save;
  run.dawn = NIGHTS[i].dawn + (owns(save, 'dusk') ? 10 : 0);
  return run;
}

/* ── geometry the light and the player both read ────────────────────────────────────────────── */

function tileAt(run, c, r) {
  if (r < 0 || r >= run.grid.length) return '#';
  const row = run.grid[r];
  if (c < 0 || c >= row.length) return '#';
  return row[c];
}

/** Does a light cell stop a ray? Walls, bookcases, drawn shutters, and TALL shoved furniture. */
function makeSolidFn(run) {
  return function solid(lcx, lcy) {
    const px = lcx * LIGHT_CELL + LIGHT_CELL / 2, py = lcy * LIGHT_CELL + LIGHT_CELL / 2;
    const c = (px / TILE) | 0, r = (py / TILE) | 0;
    const ch = tileAt(run, c, r);
    if (OPAQUE_TILE.indexOf(ch) >= 0) return true;
    if (ch === 'M') { const m = run.mirrors.find((q) => q.c === c && q.r === r); if (m && m.draped) return true; }
    for (const s of run.shoves) {
      if (!s.opaque) continue;
      if (Math.abs(s.x - px) < TILE * 0.55 && Math.abs(s.y - py) < TILE * 0.55) return true;
    }
    return false;
  };
}

/** A BARE mirror bounces. A draped one is solid (handled above) — draping deletes the bounce. */
function makeMirrorFn(run) {
  return function mirrorAt(lcx, lcy) {
    const px = lcx * LIGHT_CELL + LIGHT_CELL / 2, py = lcy * LIGHT_CELL + LIGHT_CELL / 2;
    const c = (px / TILE) | 0, r = (py / TILE) | 0;
    const m = run.mirrors.find((q) => q.c === c && q.r === r);
    return !!m && !m.draped;
  };
}

function recomputeLight(run) {
  for (const a of run.apertures) a.open = a.ref.open;
  // A skylight with a tall thing shoved under it is covered — the check is the OCCLUDER, not a flag.
  const solid = makeSolidFn(run);
  for (const a of run.apertures) {
    if (a.kind !== 'skylight') continue;
    a.open = a.ref.open && !solid((a.x / LIGHT_CELL) | 0, (a.y / LIGHT_CELL) | 0);
  }
  castLight(run.raster, run.phi, run.apertures, solid, makeMirrorFn(run));
}

/** Blocked for a MOVING BODY (not for light): walls, bookcases, mirrors, the clock. */
function blockedForBody(run, px, py, ignoreShove) {
  const c = (px / TILE) | 0, r = (py / TILE) | 0;
  const ch = tileAt(run, c, r);
  if (FLOORISH.indexOf(ch) < 0) return true;
  for (const s of run.shoves) {
    if (s === ignoreShove) continue;
    if (Math.abs(s.x - px) < TILE * 0.5 && Math.abs(s.y - py) < TILE * 0.5) return true;
  }
  return false;
}

/* ── the step ───────────────────────────────────────────────────────────────────────────────── */

const PLAYER_R = 9;

function step(run, dt, input) {
  if (run.screen !== 'play') return run;
  dt = Math.min(dt, 1 / 20);              // a tab that was away must not teleport the sun
  run.events.length = 0;
  run.t += dt;

  const frac = Math.min(1, run.t / run.dawn);
  run.phi = run.night.sunFrom + (run.night.sunTo - run.night.sunFrom) * frac;

  movePlayer(run, dt, input);
  if (run.keeper) moveKeeper(run, dt);
  doChores(run, dt, input);
  recomputeLight(run);
  burn(run, dt);

  if (run.t >= run.dawn && run.screen === 'play') { run.screen = 'dawn'; run.events.push('dawn'); }
  return run;
}

function movePlayer(run, dt, input) {
  const p = run.player;
  const speed = 152 * (owns(run.save, 'boots') ? 1.25 : 1);
  let ax = 0, ay = 0;
  if (input.left) ax -= 1;
  if (input.right) ax += 1;
  if (input.up) ay -= 1;
  if (input.down) ay += 1;
  const l = Math.hypot(ax, ay);
  if (l > 0) {
    ax /= l; ay /= l;
    p.face = Math.abs(ax) > Math.abs(ay) ? (ax < 0 ? 'left' : 'right') : (ay < 0 ? 'up' : 'down');
    p.anim += dt * 9;
  } else {
    p.anim = 0;
  }
  // momentum: you are fast, heavy and clumsy, which is the joke and also the physics
  const accel = 1100, drag = 9.5;
  p.vx += ax * accel * dt; p.vy += ay * accel * dt;
  p.vx -= p.vx * Math.min(1, drag * dt); p.vy -= p.vy * Math.min(1, drag * dt);
  const sp = Math.hypot(p.vx, p.vy);
  if (sp > speed) { p.vx = p.vx / sp * speed; p.vy = p.vy / sp * speed; }

  moveBody(run, p, p.vx * dt, p.vy * dt, true);
  pickUpGarlic(run);
}

/** Axis-separated movement so sliding along a wall works; `canShove` gives the player their shove. */
function moveBody(run, b, dx, dy, canShove) {
  for (const [ax, d] of [['x', dx], ['y', dy]]) {
    if (!d) continue;
    const nx = b.x + (ax === 'x' ? d : 0), ny = b.y + (ax === 'y' ? d : 0);
    const probeX = nx + (ax === 'x' ? Math.sign(d) * PLAYER_R : 0);
    const probeY = ny + (ax === 'y' ? Math.sign(d) * PLAYER_R : 0);
    let hit = null;
    if (canShove) {
      for (const s of run.shoves) {
        if (Math.abs(s.x - probeX) < TILE * 0.5 && Math.abs(s.y - probeY) < TILE * 0.5) { hit = s; break; }
      }
    }
    if (hit) {
      const force = (owns(run.save, 'grip') ? 1.5 : 1) * 0.62;
      const sx = hit.x + (ax === 'x' ? d * force : 0), sy = hit.y + (ax === 'y' ? d * force : 0);
      // A pushed thing needs its own four corners clear, or a wardrobe walks through a wall.
      let ok = true;
      for (const [ox, oy] of [[-13, -13], [13, -13], [-13, 13], [13, 13]]) {
        if (blockedForBody(run, sx + ox, sy + oy, hit)) { ok = false; break; }
      }
      if (ok) { hit.x = sx; hit.y = sy; run.events.push('shove'); }
      else { if (ax === 'x') b.vx = 0; else b.vy = 0; continue; }
    }
    /* `hit` is ignored in the final test on purpose. A shoved thing moves LESS than the shover
     * (force < 1, which is what makes heavy things feel heavy), so testing against it would block
     * the player on the very object they just moved and pushing would stutter one frame in two. */
    if (!blockedForBody(run, probeX, probeY, hit)) { b[ax] = ax === 'x' ? nx : ny; }
    else if (ax === 'x') b.vx = 0; else b.vy = 0;
  }
}

function pickUpGarlic(run) {
  const cap = owns(run.save, 'pockets') ? 2 : 1;
  if (run.player.carrying >= cap) return;
  for (const g of run.garlic) {
    if (g.held || g.gone) continue;
    if (Math.hypot(g.x - run.player.x, g.y - run.player.y) < 22) {
      g.held = true; run.player.carrying += 1; run.events.push('pickup');
      if (run.player.carrying >= cap) return;
    }
  }
}

/* ── chores ─────────────────────────────────────────────────────────────────────────────────────
 * One HOLD verb for everything, because a game with a different key per chore is a game that is
 * about its controls. `nearestChore` is the ONE reach rule; the HUD, the prompt and the action all
 * read it, so what the game offers and what it does cannot drift apart (master §2b).
 */
function nearestChore(run) {
  const p = run.player;
  let best = null, bestD = 44;
  const consider = (kind, obj, extra) => {
    const d = Math.hypot(obj.x - p.x, obj.y - p.y);
    if (d < bestD) { bestD = d; best = { kind, obj, extra }; }
  };
  for (const w of run.windows) if (w.open) consider('shutter', w);
  for (const m of run.mirrors) if (!m.draped) consider('drape', m);
  if (p.carrying > 0) for (const u of run.chutes) consider('chute', u);
  if (run.coffin && choresLeft(run) === 0) consider('lid', run.coffin);
  return best;
}

/* ⚠️ A SKYLIGHT IS A HAZARD, NOT A LINE ON THE LIST, and that is a design decision rather than an
 * omission. Requiring one to be covered would mean requiring a wardrobe to be shoved across a room
 * under a clock, which is a fine PUZZLE and a miserable OBLIGATION — miss the shove and the night
 * is unwinnable with two minutes still on it. As a hazard it is a spatial problem instead: the pool
 * opens in the middle of the night, you route around it, and covering it is worth GLOAM if you have
 * the seconds spare. INPUT WELCOME (ledger B7) — the alternative was to keep it mandatory and give
 * skylights their own shorter timer. */
function choresLeft(run) {
  let n = 0;
  for (const w of run.windows) if (w.open) n += 1;
  for (const m of run.mirrors) if (!m.draped) n += 1;
  for (const g of run.garlic) if (!g.gone) n += 1;
  return n;
}

function choreSeconds(run, kind) {
  const base = CHORE_SECS[kind];
  const quick = owns(run.save, 'hands') ? 2 / 3 : 1;
  const deep = kind === 'lid' && owns(run.save, 'deep') ? 0.5 : 1;
  return base * quick * deep;
}

function doChores(run, dt, input) {
  const near = nearestChore(run);
  run.choreOn = near;
  if (!near || !input.act) { run.choreT = 0; return; }
  run.choreT += dt;
  if (run.choreT < choreSeconds(run, near.kind)) return;
  run.choreT = 0;
  if (near.kind === 'shutter') { near.obj.open = false; run.stats.shuttered += 1; run.events.push('shutter'); }
  else if (near.kind === 'drape') { near.obj.draped = true; run.stats.draped += 1; run.events.push('drape'); }
  else if (near.kind === 'chute') {
    let n = 0;
    for (const g of run.garlic) if (g.held) { g.held = false; g.gone = true; n += 1; }
    run.player.carrying = 0; run.stats.binned += n; run.events.push('chute');
  } else if (near.kind === 'lid') {
    run.coffin.shut = true; run.screen = 'won'; run.events.push('won');
    awardGloam(run);
  }
}

/* ── Mrs Ashgrove ───────────────────────────────────────────────────────────────────────────────
 * The second agent in the room, and the reason night 5 onward is a different game: she re-opens
 * shutters. She is not hostile and she never touches the player — she just undoes work, which
 * turns a checklist into something you have to hold.
 */
function moveKeeper(run, dt) {
  const k = run.keeper;
  const shut = run.windows.filter((w) => !w.open);
  if (!k.target || (k.target.open !== false)) {
    k.target = shut.length ? shut[(run.t * 0.21 | 0) % shut.length] : null;
    k.work = 0;
  }
  if (!k.target) { k.anim = 0; return; }
  const dx = k.target.x - k.x, dy = k.target.y - k.y;
  const d = Math.hypot(dx, dy);
  if (d > 26) {
    const sp = 52;
    k.face = Math.abs(dx) > Math.abs(dy) ? (dx < 0 ? 'left' : 'right') : (dy < 0 ? 'up' : 'down');
    k.anim += dt * 5;
    const wasX = k.x, wasY = k.y;
    moveBody(run, k, (dx / d) * sp * dt, (dy / d) * sp * dt, false);
    /* She cannot shove, so a wardrobe in a doorway would pin her against it forever and the whole
     * second-agent system would quietly stop existing with every check still green. If she has not
     * actually moved for two seconds, she gives up on that window and picks another. */
    k.stuck = (Math.hypot(k.x - wasX, k.y - wasY) < 0.4) ? (k.stuck || 0) + dt : 0;
    if (k.stuck > 2) { k.target = null; k.stuck = 0; }
  } else {
    k.work += dt;
    if (k.work >= (owns(run.save, 'bell') ? 6.0 : 3.0)) {
      k.target.open = true; k.work = 0; k.target = null; run.events.push('unshutter');
    }
  }
}

/* ── burning ────────────────────────────────────────────────────────────────────────────────── */

function burn(run, dt) {
  const p = run.player;
  const lit = lightAt(run.raster, p.x, p.y);
  const tolerance = 2.6 + (owns(run.save, 'cloak') ? 2 : 0);
  if (lit > BURN_AT) {
    p.burn += dt * (0.5 + lit) / tolerance;
    if (p.burn >= 1) { p.burn = 1; p.dead = true; run.screen = 'burnt'; run.events.push('burnt'); }
    else run.events.push('sizzle');
  } else {
    p.burn = Math.max(0, p.burn - dt * 0.34);
  }
}

/* ── payout ─────────────────────────────────────────────────────────────────────────────────── */

function awardGloam(run) {
  const s = run.stats;
  /* `covered` is DERIVED, never counted as it happens: a skylight is covered when an occluder is
   * standing under it, and that thing can be shoved away again. Incrementing a counter on the
   * frame a wardrobe first passed under the hole would pay for work the player then undid. */
  s.covered = run.apertures.filter((a) => a.kind === 'skylight' && !a.open).length;
  const chores = s.shuttered + s.draped + s.binned + s.covered;
  const left = Math.max(0, run.dawn - run.t);
  let g = chores * GLOAM.perChore + Math.floor(left / 10) * GLOAM.perTenSecondsLeft;
  const id = run.night.id;
  if (run.save.cleared.indexOf(id) < 0) { g += GLOAM.firstClear; run.save.cleared.push(id); }
  run.payout = { chores, timeLeft: left, gloam: g };
  run.save.gloam += g;
  const key = 'n' + id;
  if (!(key in run.save.best) || left > run.save.best[key]) run.save.best[key] = left;
  run.save.night = Math.min(NIGHTS.length - 1, Math.max(...run.save.cleared));
}

function buy(save, id) {
  const u = UPGRADES.find((q) => q.id === id);
  if (!u) return 'no such upgrade';
  if (owns(save, id)) return 'already owned';
  for (const n of u.needs) if (!owns(save, n)) return 'needs ' + n;
  if (save.gloam < u.cost) return 'not enough gloam';
  save.gloam -= u.cost;
  save.owned.push(id);
  return null;
}

if (typeof module !== 'undefined') {
  module.exports = {
    SAVE_KEY, blankSave, loadSave, writeSave, owns, buildScene, createRun, step, buy,
    nearestChore, choresLeft, choreSeconds, recomputeLight, tileAt, makeSolidFn, makeMirrorFn, PLAYER_R,
  };
}
