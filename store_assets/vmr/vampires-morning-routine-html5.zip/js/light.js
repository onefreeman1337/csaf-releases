/* VAMPIRE'S MORNING ROUTINE — the light.
 *
 * THIS FILE IS THE GATE 2 CLAIM. Vampire games treat daylight as a timer or a zone; here it is a
 * simulated object with a real direction, occluded by whatever is standing where it is standing
 * and redirected by mirrors the player can shove. The lethal region of the room is therefore a
 * function of where every physical object currently is.
 *
 * ⛔ THE RASTER IS THE ONLY REPRESENTATION. It is what the renderer draws AND what the burn check
 * samples. Two representations of one fact is the defect class this factory keeps paying for
 * (master §2b), so there is exactly one here and both consumers read it.
 *
 * THE SUN IS AN AZIMUTH, NOT A SWEEP OF ARBITRARY NUMBERS.
 *   phi runs roughly 0.3 -> 2.85 radians across a night: sunrise in the east, through overhead,
 *   to the west. Light travels along D = (cos phi, sin phi).
 *   - A window in the LEFT wall faces east: it is lit while cos(phi) > 0.
 *   - A window in the RIGHT wall faces west: it is lit while cos(phi) < 0.
 *   - A skylight faces up: it is lit near the MIDDLE of the arc, when sin(phi) is high — which is
 *     exactly when both side walls are at their weakest. The two threats hand off to each other,
 *     and that handoff is the night's shape.
 * The sun being one angle is what makes the danger legible: a player who can see which way the
 * shafts lean can predict which room dies next.
 */
'use strict';

const LIGHT_CELL = 16;                       // half a tile
const LCOLS = (960 / LIGHT_CELL) | 0;        // 60
const LROWS = (17 * 32 / LIGHT_CELL) | 0;    // 34
const MAX_BOUNCE = 2;                        // a hall of mirrors cannot hang the frame
const STEP = 8;                              // half a light cell, so a diagonal ray skips nothing
const RAYS_PER_APERTURE = 5;
const SKYLIGHT_ELEVATION = 0.55;             // sin(phi) above which a skylight burns

/** Danger at which the player starts to cook. Below this a cell is glow, not sun. */
const BURN_AT = 0.30;

function makeRaster() {
  return { w: LCOLS, h: LROWS, v: new Float32Array(LCOLS * LROWS) };
}

/**
 * Cast the whole room's light into `raster`.
 *
 * @param raster    reused Float32Array wrapper — cleared here, never reallocated per frame
 * @param phi       the sun's azimuth in radians
 * @param apertures [{kind:'window'|'skylight', side:'left'|'right', x, y, open:bool}] in PIXELS
 * @param solid     (cx, cy) -> true when that light cell stops a ray  (READ LIVE, every frame:
 *                  this is the whole point — a shoved wardrobe carves a new shadow immediately)
 * @param mirrorAt  (cx, cy) -> true when a BARE mirror occupies that light cell
 */
function castLight(raster, phi, apertures, solid, mirrorAt) {
  raster.v.fill(0);
  const dx = Math.cos(phi), dy = Math.sin(phi);
  const elevation = dy;                       // 0 at the horizon, 1 overhead

  for (const a of apertures) {
    if (!a.open) continue;                    // a shuttered window is deleted AT ITS SOURCE

    if (a.kind === 'window') {
      // Facing test: a wall only takes sun from its own side of the sky.
      const facing = a.side === 'left' ? dx : -dx;
      if (facing <= 0.05) continue;
      const strength = Math.min(1, facing * 1.35);
      // Rays are spread across the aperture's 32px width, along the wall (vertically).
      for (let i = 0; i < RAYS_PER_APERTURE; i++) {
        const t = (i + 0.5) / RAYS_PER_APERTURE;
        const sx = a.x + (a.side === 'left' ? 6 : -6);
        const sy = a.y - 16 + t * 32;
        march(raster, sx, sy, a.side === 'left' ? Math.abs(dx) : -Math.abs(dx), dy, strength, 0, solid, mirrorAt, false);
      }
    } else {
      // A skylight is a hole in the ROOF: it burns only while the sun is high, and the pool it
      // drops LEANS with the sun rather than sitting under the hole.
      if (elevation <= SKYLIGHT_ELEVATION) continue;
      const strength = Math.min(1, (elevation - SKYLIGHT_ELEVATION) / (1 - SKYLIGHT_ELEVATION) * 1.5);
      const lean = (1 - elevation) * 90;
      const px = a.x + dx * lean, py = a.y + dy * lean;
      stamp(raster, px, py, 26 + 10 * strength, strength, solid);
    }
  }
}

/**
 * March one ray, depositing into the raster, reflecting off bare mirrors.
 *
 * ⛔⛔ `inMirror` IS NOT A TIDY-UP, IT IS THE MIRROR MECHANIC. Without it this function reflected a
 * ray and then IMMEDIATELY reflected it back, because a mirror occupies a 32px tile and the ray
 * advances 8px per step — so the recursive march's very first step was still inside the same glass.
 * Reflecting about y=x twice is the identity, so every mirror in the game passed light straight
 * through on its original heading at 61% strength.
 *
 * MEASURED before the fix (`Internal_Ops/_probe_mirror_bounce.js`): `mirrorAt` answered yes **3.2
 * times per ray**, a room with a bare mirror and the same room with NO mirror produced **identical
 * rasters — 41 lit cells each, zero cells different in either direction** — and night 3, whose whole
 * lesson is *"MIRRORS. A bare one throws the light on somewhere new"*, had **0 cells lit because of
 * a mirror at five different sun angles**. The store copy, three nights' teach lines and this
 * file's own header all asserted a mechanic that did not happen, and every gate in the project was
 * green over it, because they all asked whether the SUN mattered and none asked whether the GLASS
 * did.
 *
 * A ray therefore carries whether it is currently inside glass: it bounces on entry, and cannot
 * bounce again until it has left. Two separate mirrors still hand light to each other (night 7),
 * which is what MAX_BOUNCE is for — and that budget was previously being eaten by a mirror
 * bouncing off itself.
 */
function march(raster, x, y, dx, dy, strength, bounce, solid, mirrorAt, inMirror) {
  const len = Math.hypot(dx, dy) || 1;
  dx /= len; dy /= len;
  for (let s = 0; s < 200; s++) {
    x += dx * STEP; y += dy * STEP;
    const cx = (x / LIGHT_CELL) | 0, cy = (y / LIGHT_CELL) | 0;
    if (cx < 0 || cy < 0 || cx >= LCOLS || cy >= LROWS) return;
    const onGlass = mirrorAt(cx, cy);
    if (onGlass && !inMirror && bounce < MAX_BOUNCE) {
      /* A 45-degree glass: D' = (Dy, Dx), which is the plane the mirror sprite actually draws.
       * ONE rule for every mirror in the game, because a reflector the player cannot predict is
       * noise rather than a puzzle piece. */
      march(raster, x, y, dy, dx, strength * 0.78, bounce + 1, solid, mirrorAt, true);
      return;
    }
    if (!onGlass) inMirror = false;            // out the other side; the next pane may bounce again
    if (solid(cx, cy)) return;                 // occluded — the shadow behind it is free
    const i = cy * LCOLS + cx;
    if (raster.v[i] < strength) raster.v[i] = strength;
    // one cell of bleed either side, so a shaft has an edge rather than a staircase
    if (cx + 1 < LCOLS && raster.v[i + 1] < strength * 0.55) raster.v[i + 1] = strength * 0.55;
    if (cx > 0 && raster.v[i - 1] < strength * 0.55) raster.v[i - 1] = strength * 0.55;
  }
}

/** A soft round pool, used by skylights. Respects occluders so a wardrobe under it really works. */
function stamp(raster, px, py, radius, strength, solid) {
  const c0 = Math.max(0, ((px - radius) / LIGHT_CELL) | 0);
  const c1 = Math.min(LCOLS - 1, ((px + radius) / LIGHT_CELL) | 0);
  const r0 = Math.max(0, ((py - radius) / LIGHT_CELL) | 0);
  const r1 = Math.min(LROWS - 1, ((py + radius) / LIGHT_CELL) | 0);
  for (let cy = r0; cy <= r1; cy++) for (let cx = c0; cx <= c1; cx++) {
    if (solid(cx, cy)) continue;
    const d = Math.hypot((cx + 0.5) * LIGHT_CELL - px, (cy + 0.5) * LIGHT_CELL - py) / radius;
    if (d > 1) continue;
    const v = strength * (1 - d * d);
    const i = cy * LCOLS + cx;
    if (raster.v[i] < v) raster.v[i] = v;
  }
}

/** Sample the raster in PIXEL space — the burn check and the renderer use this same function. */
function lightAt(raster, px, py) {
  const cx = (px / LIGHT_CELL) | 0, cy = (py / LIGHT_CELL) | 0;
  if (cx < 0 || cy < 0 || cx >= LCOLS || cy >= LROWS) return 0;
  return raster.v[cy * LCOLS + cx];
}

if (typeof module !== 'undefined') {
  module.exports = { LIGHT_CELL, LCOLS, LROWS, BURN_AT, SKYLIGHT_ELEVATION, makeRaster, castLight, lightAt };
}
