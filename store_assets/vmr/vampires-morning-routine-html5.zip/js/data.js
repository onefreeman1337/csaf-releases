/* VAMPIRE'S MORNING ROUTINE — nights, chores and the upgrade tree.
 *
 * Everything authored lives here so the sim never has a magic number in it, and so the difficulty
 * curve is a table somebody can read rather than a feeling somebody had.
 *
 * BOARD: 30 x 17 tiles of 32px = 960 x 544, plus a 56px HUD = 960 x 600.
 *
 * MAP LEGEND (one char per tile — the maps are hand-laid, never random, so difficulty is authored)
 *   #  wall (opaque, solid)          .  floor            ,  rug (floor, cosmetic)
 *   =  chequer floor (cosmetic)      W  window           K  skylight (in the FLOOR band = a hole
 *   M  mirror (solid, reflects)         above; cannot be shuttered, must be covered)
 *   C  coffin (the goal)             G  garlic (pick up) U  chute (put garlic down here)
 *   R  wardrobe (shovable, opaque)   T  table (shovable) H  chair (shovable)
 *   B  bookcase (solid, opaque)      X  chest (shovable) L  candelabra (solid, small)
 *   O  clock (solid)                 D  door (open gap, cosmetic) E  crate (shovable)
 *   @  the vampire's start           h  the housekeeper's start
 */
'use strict';

const TILE = 32, COLS = 30, ROWS = 17, HUD = 56;
const BOARD_W = COLS * TILE, BOARD_H = ROWS * TILE;

/* ── the eight nights ──────────────────────────────────────────────────────────────────────────
 * ONE NEW NOUN PER NIGHT (design doc, Gate 4 unlock pacing). `teach` is the line the night opens
 * with; it names the new noun and nothing else, because a tutorial that says three things says
 * none of them.
 *
 * `dawn` is the night's length in seconds — the sun angle is a pure function of elapsed/dawn, so
 * this one number IS the difficulty dial for the whole light system.
 */
const NIGHTS = [
  {
    id: 1,
    name: 'The Long Landing',
    teach: 'WINDOWS. Shut them before the sun finds them.',
    dawn: 80,
    sunFrom: 0.55, sunTo: 1.30,
    map: [
      '##############################',
      '#..BBB...L.........O....BBB..#',
      '#..,,,,,,,,..................#',
      '#..,,,,,,,,........T.........#',
      'W..,,,,,,,,..................W',
      '#..,,,,,,,@..........H.......#',
      '#............................#',
      '#.........................E..#',
      '#............................#',
      '#..............T.............#',
      '#...R........................#',
      'W............................W',
      '#...................,,,,,,,..#',
      '#.........H.........,,,,,,,..#',
      '#........C..........,,,,,,,..#',
      '#..BB....L..........B.BBB....#',
      '##############################',
    ],
    floor: 'board', wall: 'plaster',
  },
  {
    id: 2,
    name: 'Somebody Has Been Cooking',
    teach: 'GARLIC. Carry it to the chute. You cannot shut a smell.',
    dawn: 115,
    sunFrom: 0.48, sunTo: 1.50,
    map: [
      '##############################',
      '#..........#........#........#',
      '#....G.....#........#....T...#',
      '#..........#........#........#',
      'W..........#...D....#........W',
      '#..........#........#........#',
      '#..........##########........#',
      '#.........@..................#',
      '#............................#',
      '#..###.##........######......#',
      '#..#....#........#....#......#',
      'W..#....#........#..G.#......W',
      '#..#..U.#........#....#......#',
      '#..######........###.##......#',
      '#..........C.................#',
      '#............................#',
      '##############################',
    ],
    floor: 'board', wall: 'plaster',
  },
  {
    id: 3,
    name: 'Vanity, Vanity',
    teach: 'MIRRORS. A bare one throws the light on somewhere new.',
    dawn: 98,
    sunFrom: 0.42, sunTo: 1.80,
    /* ⛔ THE MIRROR THAT TEACHES MIRRORS USED TO SIT ABOVE THE WINDOW. Light from a wall window
     * travels DOWN, always, so a mirror on a row above every window is unreachable by construction
     * and this night's whole lesson could not be shown. MEASURED (`_probe_mirror_nights.js
     * --place 2 6,2`): at (2,6) a mirror redirects light at 16 of 31 sun angles instead of 0, and
     * moves more than twice as much light as the placement that scores best on angles alone.
     * ⚠️ The first two candidates the search offered were both illegal and it could not say so: at
     * (1,5) the mirror throws light onto the SPAWN inside the eight second grace, and next to a
     * window it walls off the only tile a player can shut that window from — a mirror is solid to a
     * body. The search enforces both of the project's own map gates now. */
    map: [
      '##############################',
      '#=====================......=#',
      '#=====================...G..=#',
      '#=====================......=#',
      'W=====================......=W',
      '#............................#',
      '#.M..T.......................#',
      '#...............B......M.....#',
      '#...............B............#',
      '#...@...........B............#',
      '#............................#',
      'W..........,,,,,,,,,,........W',
      '#..........,,,,,,,,,,....U...#',
      '#..........,,,,,,,,,,........#',
      '#.....M....,,,,,,,,,,........#',
      '#.......C....................#',
      '##############################',
    ],
    floor: 'chequer', wall: 'plaster',
  },
  {
    id: 4,
    name: 'They Put A Hole In The Roof',
    teach: 'A SKYLIGHT. No shutter reaches it. Shove something under it.',
    dawn: 80,
    sunFrom: 0.40, sunTo: 2.05,
    map: [
      '##############################',
      '#..........................R.#',
      '#....K...............K.......#',
      '#............................#',
      'W......@R....................W',
      '#............................#',
      '#............G...............#',
      '#............................#',
      '#....BBBB..........BBBB......#',
      '#..................,,,,,,....#',
      '#........K.........,,,,,,....#',
      'W..................,,,,,,....W',
      '#.....R............,,,,,,....#',
      '#..........U.................#',
      '#..............C.............#',
      '#............................#',
      '##############################',
    ],
    floor: 'board', wall: 'stone',
  },
  {
    id: 5,
    name: 'The Help',
    teach: 'MRS ASHGROVE. She means well. She opens the shutters.',
    dawn: 114,
    sunFrom: 0.38, sunTo: 2.25,
    map: [
      '##############################',
      '#....................#.......#',
      '#..M.................#...h...#',
      '#....................#.......#',
      'W......@.............D.......W',
      '#............................#',
      '#...........T................#',
      '#...........................G#',
      '#....BBBBBB..........X.......#',
      '#............................#',
      '#........K.........,,,,,,....#',
      'W..................,,,,,,....W',
      '#.....R....U.......,,,,,,....#',
      '#..................,,,,,,....#',
      '#..............C.............#',
      '#............................#',
      '##############################',
    ],
    floor: 'board', wall: 'plaster',
  },
  {
    id: 6,
    name: 'The Cellar Stair',
    teach: 'The cellar is cold and the sun is low. Everything at once now.',
    dawn: 155,
    sunFrom: 0.35, sunTo: 2.45,
    map: [
      '##############################',
      '#.G..#..............#........#',
      '#....#.....M........#....M...#',
      '#....#@.............#........#',
      'W....D..............D........W',
      '#............................#',
      '#........K.........K.........#',
      '#............................#',
      '#..BBBBBB......X.....BBBB....#',
      '#............................#',
      '#...........,,,,,,,,,........#',
      'W....R......,,,,,,,,,....h...W',
      '#...........,,,,,,,,,........#',
      '#.....U.....,,,,,,,,,........#',
      '#.........C..................#',
      '#..........................G.#',
      '##############################',
    ],
    floor: 'stone', wall: 'stone',
  },
  {
    id: 7,
    name: 'An Unhelpful Amount Of Glass',
    teach: 'Two mirrors can hand the light to each other. Drape them.',
    dawn: 200,
    sunFrom: 0.33, sunTo: 2.62,
    /* ⛔ THIS NIGHT'S TEACH LINE PROMISES A SECOND BOUNCE AND THE MAP DELIVERED ONE AT ZERO SUN
     * ANGLES. Both row-1 mirrors were above every window, so no ray could ever reach them (see
     * night 3). MEASURED (`_probe_mirror_nights.js --pair 6`, scored on the 0.78^2 attenuation that
     * only twice-bounced light can carry): moving the (2,1) pane to (1,11), beside the lower window
     * and in line with the pane at (2,13), produces twice-bounced light at 5 of 25 angles, up to 36
     * cells. The pane left at (20,1) stays a chore, which is the other half of what a mirror is.
     * ⚠️ (1,11) was the search's own top answer and it is ILLEGAL: it is the only tile from which
     * the window at (0,11) can be shut, and a mirror is solid to a body, so the night became
     * unfinishable. (1,12) is one row down, keeps every chore reachable, and still pairs with the
     * pane at (2,13). */
    map: [
      '##############################',
      '#===================M========#',
      '#============================#',
      '#=====G======================#',
      'W============================W',
      '#............................#',
      '#.........X.....X............#',
      '#............................#',
      '#@.BBB....K.........K....BBB.#',
      '#............................#',
      '#=====,,,,,,,,,,,,,,,,=======#',
      'W=====,,,,,,,,,,,,,,,,=======W',
      '#M====,,,,,,,,,,,,,,,,==h====#',
      '#=M===,,,,,,,,,,,,,,,,=====M=#',
      '#=========C==================#',
      '#=====U======================#',
      '##############################',
    ],
    floor: 'chequer', wall: 'plaster',
  },
  {
    id: 8,
    name: 'The Last Morning',
    teach: 'Everything, and the shortest night of the year.',
    dawn: 190,
    sunFrom: 0.30, sunTo: 2.82,
    map: [
      '##############################',
      '#.M..#....K....#....K...#..M.#',
      '#....#.........#........#....#',
      '#..G.D.@.......D........D..G.#',
      'W............................W',
      '#........X..........X........#',
      '#............................#',
      '#..BBBB....M....M....BBBB....#',
      '#............................#',
      '#=====,,,,,,,,,,,,,,,,=======#',
      'W=====,,,,,,,,,,,,,,,,===h===W',
      '#=====,,,,,,,,,,,,,,,,=======#',
      '#..R..,,,,,,,,,,,,,,,,....R..#',
      '#=========U=======C==========#',
      '#=M=======================M==#',
      '#..........G.................#',
      '##############################',
    ],
    floor: 'chequer', wall: 'stone',
  },
];

/* ── the upgrade tree ──────────────────────────────────────────────────────────────────────────
 * Nine, bought with GLOAM, with REAL prerequisites so the tree is a tree and not a shopping list
 * (design doc, Gate 4). Each one changes a number the sim already reads — none of them is a
 * cosmetic or a second currency.
 */
const UPGRADES = [
  { id: 'boots', name: 'Silent Boots', cost: 3, needs: [], blurb: 'You move a quarter faster.' },
  { id: 'cloak', name: 'Long Cloak', cost: 5, needs: ['boots'], blurb: 'The sun takes two extra seconds to finish you.' },
  { id: 'grip', name: 'Dead Mans Grip', cost: 4, needs: ['boots'], blurb: 'Shove furniture half again as hard.' },
  { id: 'sense', name: 'Cellar Sense', cost: 6, needs: ['grip'], blurb: 'Chores you have not done glow through walls.' },
  { id: 'deep', name: 'Deep Box', cost: 8, needs: ['cloak'], blurb: 'The lid shuts in half the time.' },
  { id: 'bell', name: 'Bell', cost: 9, needs: ['sense'], blurb: 'Mrs Ashgrove works half as fast.' },
  { id: 'hands', name: 'Quick Hands', cost: 6, needs: ['grip'], blurb: 'Every chore is done in two thirds the time.' },
  { id: 'pockets', name: 'Deep Pockets', cost: 5, needs: ['hands'], blurb: 'Carry two braids of garlic at once.' },
  { id: 'dusk', name: 'Read The Sky', cost: 12, needs: ['bell', 'deep'], blurb: 'The night starts a full ten seconds earlier.' },
];

/* ── the gloam tree's SHAPE, authored ──────────────────────────────────────────────────────────
 * The nine upgrades above are a real DAG with nine dependency edges, and the shop used to throw all
 * of that away and print a 3x3 grid of text cards. It is drawn as a tree now, with the sigils
 * art.js already generates (`sig_boots` .. `sig_dusk`) — nine 30x30 marks that were shipped inside
 * bits.png and drawn by nothing, i.e. generated art the player never saw.
 *
 * ⛔ THE POSITIONS ARE HAND-PLACED AND THEY ARE DATA, not constants buried in the painter, because
 * a gate has to be able to read them: `_suites.js` asserts every box is inside the panel, that no
 * two boxes touch, and that no edge segment crosses a box it is not attached to. A tidy-looking
 * auto-layout that quietly runs an edge through a node is exactly the defect this wing has paid for
 * in menus twice (§3e-1, §3e-3).
 *
 * Rows are the tree's DEPTH. `dusk` needs both `bell` (row 3) and `deep` (row 2), so one edge spans
 * two rows and is elbowed down the left gutter at x=71 — chosen because the leftmost row-3 box
 * starts at x=161, so the channel is 60px clear of it.
 */
const TREE = {
  panel: { x: 12, y: 86, w: 598, h: 462 },
  detail: { x: 622, y: 86, w: 326, h: 462 },
  box: { w: 60, h: 76 },        // a 60x60 sigil at scale 2, over a 16px caption strip
  rowPitch: 92,
  gutter: 71,                   // x of the channel the one two-row edge runs down
  nodes: {
    boots: { row: 0, x: 311 },
    cloak: { row: 1, x: 191 },
    grip: { row: 1, x: 431 },
    deep: { row: 2, x: 71 },
    sense: { row: 2, x: 311 },
    hands: { row: 2, x: 551 },
    bell: { row: 3, x: 191 },
    pockets: { row: 3, x: 551 },
    dusk: { row: 4, x: 311 },
  },
};

/* ── the how-it-works diagrams ─────────────────────────────────────────────────────────────────
 * FOUR REAL ROOMS, parsed by `buildScene` and lit by `castLight` — not illustrations of the light,
 * the light. The help screen used to be thirteen lines of prose about sunlight on a black
 * background, which is the flat menu screen this wing keeps losing Gate 1 to (§3e).
 *
 * Each map is 7x7 and everything outside it is wall (`tileAt` returns '#' out of range), so a ray
 * cannot leave a diagram. `phi` is the sun's azimuth and the two ranges are NOT arbitrary:
 *   - A left-wall window needs cos(phi) > 0, and its beam gets steeper as phi grows. 0.35..0.62
 *     keeps the shaft crossing the whole room, and keeps it away from 45 degrees where a mirror
 *     whose plane is y=x reflects a ray onto itself and appears to do nothing.
 *   - A skylight needs sin(phi) > 0.55 (light.js SKYLIGHT_ELEVATION), so it cannot share the
 *     windows' range at all. That is not a layout problem, it is the night's actual shape — the
 *     side walls and the roof hand the danger to each other — so the fourth panel says so.
 */
const HELP_SCENES = [
  {
    /* The control: nothing in the room but the beam and somebody standing where it goes. The two
     * panels are a controlled pair — same room, same sun, one of them has furniture in it — so the
     * vampire burns HERE and does not burn NEXT DOOR, and the player is told why by looking. */
    id: 'beam',
    caption: 'THE SUN IS A REAL BEAM AND IT MOVES.',
    phi: [0.35, 0.62],
    floor: 'board', wall: 'plaster',
    map: ['#######',
      'W.....#',
      '#.....#',
      '#...@.#',
      '#.....#',
      '#.....#',
      '#######'],
  },
  {
    /* ⛔ THE OCCLUDER IS AT COLUMN 2 AND THAT IS ARITHMETIC, NOT TASTE. The beam leaves the window
     * at y=48 and drops between 0.365 and 0.717 rows per column across this phi range, so at the
     * centre of column 2 it is at y=69..90 — inside row 2 for the WHOLE sweep. One column further
     * out it spans three rows and slides off whatever is standing there, which is exactly how the
     * first build of this diagram shipped a "shadow" panel with the beam passing over the wardrobe. */
    id: 'shadow',
    caption: 'SHOVE SOMETHING IN. THE SHADOW BEHIND IT IS YOURS.',
    phi: [0.35, 0.62],
    floor: 'board', wall: 'plaster',
    /* ⚠️ THE VAMPIRE STANDS AT (4,3), THE SAME TILE HE STANDS ON IN THE BARE ROOM NEXT DOOR, and
     * that is the whole design of the pair: identical room, identical sun, identical spot, and the
     * only difference between burning and not is the wardrobe. His first position was (5,4), where
     * he was safe because the beam does not reach that far — the panel would have illustrated
     * standing out of the way and captioned it as standing in a shadow. The control in
     * `_suites.js` caught it by deleting the furniture and finding the spot still dark. Chosen off
     * the measured table in `_probe_help_light.js`: at (4,3) the bare room reads 0.55 / 1.00 / 1.00
     * across the sweep against a 0.30 burn threshold, and the occluded room reads 0.00 at all three. */
    map: ['#######',
      'W.....#',
      '#.R...#',
      '#.E.@.#',
      '#.....#',
      '#.....#',
      '#######'],
  },
  {
    id: 'mirror',
    caption: 'A BARE MIRROR THROWS IT SOMEWHERE NEW.',
    phi: [0.35, 0.62],
    floor: 'board', wall: 'plaster',
    map: ['#######',
      'W.....#',
      '#.M...#',
      '#.....#',
      '#.....#',
      '#.....#',
      '#######'],
  },
  {
    id: 'skylight',
    caption: 'LATER THE SUN IS OVERHEAD. COVER THE HOLE.',
    phi: [0.85, 1.35],
    floor: 'stone', wall: 'stone',
    /* The wardrobe is parsed at (4,4) and then STOOD UNDER the right-hand skylight by the help
     * screen, because a tile holds one character and covering a hole is a shove, not a map symbol.
     * `recomputeLight` closes an aperture whose cell is solid, so the cover is the game's own rule
     * rather than a flag set for the diagram. */
    map: ['#######',
      '#.....#',
      '#.K.K.#',
      '#....@#',
      '#...R.#',
      '#.....#',
      '#######'],
    coverSkylight: 1,           // index into run.skylights that the wardrobe is stood under
  },
];

/* Chore timings, in seconds, before Quick Hands. These are the panic dial. */
const CHORE_SECS = { shutter: 1.15, drape: 1.35, chute: 0.9, lid: 2.2 };

/* GLOAM paid at the end of a night: one per chore done, plus a bonus for time left on the clock. */
const GLOAM = { perChore: 1, perTenSecondsLeft: 1, firstClear: 3 };

if (typeof module !== 'undefined') {
  module.exports = { TILE, COLS, ROWS, HUD, BOARD_W, BOARD_H, NIGHTS, UPGRADES, CHORE_SECS, GLOAM, TREE, HELP_SCENES };
}
