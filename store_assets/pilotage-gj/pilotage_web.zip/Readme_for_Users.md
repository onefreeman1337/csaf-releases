# PILOTAGE

**Bring the fishing fleet home. Every boat needs a mooring of her own, and a boat once moored stays.**

At dusk a fishing fleet comes home to an anchorage among the islands. You run the pilot launch: you take each boat in
tow and bring her to a free mooring, and once she is moored she is there for good. Every boat is towed the shortest way
through the channels, round every island, and the whole fleet's towing is scored against the least it could possibly be.

---

## How to play

| | |
| --- | --- |
| **Arrow keys** or **WASD** | **HOLD** a direction to steer the pilot launch through the channels. |
| **Mouse** or **touchscreen** | **Hold a finger (or the mouse button) where you want to go**: the launch steers there, round any island in the way. Move your finger and she changes course. **Tap the launch** to act where she is (the same as Z). |
| **Z** / **Enter** / **Space** | on a waiting boat: take her in tow. On a free mooring with a boat in tow: moor her there (it asks first: **Z** again to moor, **X** to change your mind). On the boat you are towing: cast her line off. On another waiting boat: put the line on her instead. On the cards: start, next anchorage, retry |
| **X** / **Esc** | back; while steering it pauses (press it again to give up); on a result it shows the best tows (after bronze or better) or a clue (after LONG TOWS); from there, X again goes back to the anchorages |
| **P** | pause |
| **M** | mute (remembered between sessions) |
| **Left / Right**, on the anchorage screen | the previous or next anchorage (the next opens on bronze or better) |
| **Up**, on the anchorage screen | the harbour log: every anchorage you have brought home, with its medal |
| **Down**, on the anchorage screen | the rules card (also shown before your first anchorage) |
| **Swipe**, on a touchscreen | on the anchorage screen and the cards, a swipe is the arrow key in its direction: swipe left or right to change anchorage, up for the harbour log, down for the rules |
| **Buttons under the screen** | Z (tow / moor), X, P and M, for touch and mouse players |

## The numbers

- **TOW** (while a boat is on your line) is how far she would be towed **if you moored her where the launch is now**:
  her shortest way through the channels from where she waited. Where the launch steers on the way does not matter;
  only which mooring she ends up on.
- **TOWED** (when no boat is on the line) is the fleet's towing so far.
- **PAR** (shown as `PAR n FOR ALL`) is the least towing the whole fleet could possibly need, every boat on a mooring
  of her own. It is computed exactly, by the game's own code, over every way of pairing boats with moorings, not
  guessed.

The nearest free mooring is honest, but it only knows the boat you are towing. Taking the closest boat to the closest
mooring, again and again, strands a far boat with a far mooring at the end.

An island in the way makes a tow longer than it looks. You can take a boat in tow, steer to a mooring you are not sure
of and read TOW there without mooring her; casting her off costs nothing. Measuring the doubtful tows is part of the
game.

## Medals

When the last boat is moored the fleet is home and the anchorage is scored against its par, in steps of towing:

- **GOLD**: the par itself, the least towing there is.
- **SILVER**: two steps over par.
- **BRONZE**: four steps over par.
- **LONG TOWS**: more than that. The next anchorage opens on bronze or better, so try again.

Why steps of two? The channels are a grid, so every way of pairing boats with moorings adds up to par, or par plus
two, or par plus four, and so on. Nothing ever lands one step over.

## Seeing the best tows

After an anchorage of **bronze or better**, **X** shows the least towing: every boat on her best mooring and every tow
drawn dark, with your own tows that differ drawn pale beneath. After **LONG TOWS**, **X** shows a clue instead: how
many boats the least towing moves to another mooring, and one of them, ringed where she waited. Every least plan moves
the ringed boat. Which of the others move, and where they all go, is still yours to find.

## The fleet

Every boat in every fleet is drawn by the game from her own design: her rig (a leg-of-mutton, a gaff, a sloop, a cutter,
a lateen or a square sail), her sail cloth (tan, white or tarred), her hull and her heading. No two in a fleet are alike.
A waiting boat has her sail up; a moored boat has her sail furled and her masthead lamp lit. The launch is the one boat
with an engine and a wheelhouse, and its corners blink.

---

## Editions

**The free edition** (playable in your browser) is ten anchorages.

**The full game** (the download) is forty anchorages, a harbour log for all of them, and an ending.

## Running the download

The download is a single portable `.exe`: there is no installer, you just double-click it. Like any portable app
built this way, it unpacks itself into your temporary folder while it runs, and it keeps your best towing and your
mute setting in your user profile's app-data folder (`%APPDATA%\Pilotage`).

---

## Credits

Made by **Core Systems Asset Factory**.

**AI disclosure.** The code, art and text of this game were produced with generative AI assistance. The music and
sound effects are **procedural synthesis from note data** (oscillators and envelopes, written out as notes) and are
not the output of a generative audio model.

Every anchorage is generated by the game's own code (`js/anchorage.js`, drawn by `js/art.js`), and the least towing
for each is computed by that same code. The browser edition's source is unminified in its `js/` folder; the Windows
download packs the same files inside the app.
