/**
 * anchorage.js — PILOTAGE. The anchorage generator, the proved-least towing, and the one number at the pilot's bow.
 *
 * ⛔ THE GENERATOR IS THE CANDIDATE SCREEN'S, VERBATIM (Wings/Auxiliary/Research/games_pass235/screen.js, mode
 *    `assign`, variant `base`): same RNG, same draws in the same order, same refusals, so every number in the screen
 *    (P2 25.5% · P3 5.4% · P4 94.0% over seeds 0..199; replication 200..399) describes these anchorages.
 *    Internal_Ops/verify_anchorage.js REQUIRES all 400 screened rows to reproduce exactly (k, optimum, and the three
 *    arms' costs), with a shifted-seed red arm. The ONLY additions draw no random number: `kind[]` (quay / island,
 *    for the picture), `reach[]` (the water the pilot can steer on) and the tow routes.
 * ⛔ THE BOARD MUST STAY AN ARCHIPELAGO (aux boardGeometryLaw, MEASURED): one harbour mouth killed the gap (P3 0.0%),
 *    two mouths 2.0%. The gap lives in the number of distinct routes. Never "improve" this generator into a harbour.
 *
 * An anchorage: 20x15 cells. The bottom row is the quay (land); 3-6 islands. 7-8 fishing boats wait in open water
 * (not touching land) in the upper two thirds; as many free moorings lie on water cells that touch land. Every
 * boat needs a mooring of its own. A tow runs along the shortest channel (4-way, round every island) from where the
 * boat waits to her mooring. The fleet's towing = the sum of its tows. The least towing any one-to-one assignment
 * could give (exact, a DP over subsets of moorings) is the par.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.ANCHORAGE = api;
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const W = 20, H = 15, N = W * H;
  const WATER = 0, QUAY = 1, ISLAND = 2;

  // ---- verbatim from the screen ---------------------------------------------------------------------------------
  function rng(seed) { let a = (seed + 0x9e3779b9) >>> 0; return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  const nbrs = (u) => { const x = u % W, y = (u / W) | 0; return [x > 0 ? u - 1 : -1, x < W - 1 ? u + 1 : -1, y > 0 ? u - W : -1, y < H - 1 ? u + W : -1].filter((v) => v >= 0); };
  const bfs = (land, s) => { const d = new Int16Array(N).fill(-1); d[s] = 0; const q = [s]; for (let i = 0; i < q.length; i++) { const u = q[i]; for (const v of nbrs(u)) if (!land[v] && d[v] < 0) { d[v] = d[u] + 1; q.push(v); } } return d; };
  const man = (a, b) => Math.abs(a % W - b % W) + Math.abs(((a / W) | 0) - ((b / W) | 0));

  function generate(seed) {
    const r = rng(seed * 2654435761 % 4294967291 + 23), ri = (lo, hi) => lo + Math.floor(r() * (hi - lo + 1));
    for (let attempt = 0; attempt < 400; attempt++) {
      const land = new Uint8Array(N);
      for (let x = 0; x < W; x++) land[(H - 1) * W + x] = 1;
      for (let b = ri(3, 6); b-- > 0;) { const cx = ri(1, W - 2), cy = ri(1, H - 4), rw = ri(1, 3), rh = ri(1, 2);
        for (let y = cy - rh; y <= cy + rh; y++) for (let x = cx - rw; x <= cx + rw; x++) if (x >= 0 && y >= 0 && x < W && y < H - 1 && r() < 0.85) land[y * W + x] = 1; }
      const k = ri(7, 8);
      const coast = [], open = [];
      for (let c = 0; c < N; c++) if (!land[c]) { (nbrs(c).some((v) => land[v]) ? coast : open).push(c); }
      const used = []; const ok = (c) => used.every((p) => man(p, c) >= 2);
      const take = (pool, m) => { const out = []; let guard = 0; while (out.length < m && guard++ < 6000) { const c = pool[ri(0, pool.length - 1)]; if (!ok(c)) continue; used.push(c); out.push(c); } return out.length === m ? out : null; };
      const boatsPool = open.filter((c) => ((c / W) | 0) <= H - 5);
      const berthPool = coast;
      if (boatsPool.length < k + 4 || berthPool.length < k + 4) continue;
      const boats = take(boatsPool, k); if (!boats) continue; const berths = take(berthPool, k); if (!berths) continue;
      const nodes = boats.concat(berths);
      const f = nodes.map((c) => bfs(land, c));
      if (nodes.some((a, i) => nodes.some((b) => f[i][b] < 0))) continue;
      const D = nodes.map((a, i) => nodes.map((b) => f[i][b]));
      // ---- additions: no random draw below this line ----------------------------------------------------------
      const kind = new Uint8Array(N); for (let c = 0; c < N; c++) kind[c] = !land[c] ? WATER : (((c / W) | 0) === H - 1 ? QUAY : ISLAND);
      const reach = new Uint8Array(N); for (let c = 0; c < N; c++) if (f[0][c] >= 0) reach[c] = 1;   // the water connected to the fleet
      const boatAt = new Int16Array(N).fill(-1); boats.forEach((c, i) => { boatAt[c] = i; });
      const berthAt = new Int16Array(N).fill(-1); berths.forEach((c, j) => { berthAt[c] = j; });
      return { seed, k, land, kind, reach, boats, berths, nodes, D, field: f, boatAt, berthAt };
    }
    throw new Error('no anchorage for seed ' + seed);
  }

  /** Total towing of an assignment: asg[i] = the mooring index boat i is towed to. */
  function cost(A, asg) { let s = 0; for (let i = 0; i < A.k; i++) s += A.D[i][A.k + asg[i]]; return s; }
  /** One tow: boat i to mooring j. */
  function tow(A, i, j) { return A.D[i][A.k + j]; }
  /** THE ONE NUMBER at the pilot's bow: the tow if boat i were moored on `cell` (the channel distance). -1 = no way. */
  function towTo(A, i, cell) { return A.field[i][cell]; }

  /** The proved-least towing: the screen's optimum() DP over subsets of moorings, plus the assignment it achieves.
   *  `prefer` (optional, an assignment) breaks ties toward agreeing with it, so the clue's COUNT of boats to move is
   *  the fewest any least plan needs. (⛔ REVIEW 2026-09-28 defect 4: a tie-break maximises AGREEMENT; it does not
   *  prove any single boat is moved by EVERY least plan — that is what clue()'s mustMove computes, with bestWith.) */
  const solveCache = new Map();
  function solve(A, prefer) {
    const key = prefer ? null : A.seed;
    if (key !== null && solveCache.has(key)) return solveCache.get(key);
    const k = A.k, M = 1 << k, BIG = 1000;
    const dp = new Float64Array(M).fill(Infinity), via = new Int16Array(M).fill(-1); dp[0] = 0;
    for (let m = 0; m < M; m++) {
      if (dp[m] === Infinity) continue; let i = 0; for (let t = m; t; t &= t - 1) i++; if (i >= k) continue;
      for (let j = 0; j < k; j++) if (!(m & (1 << j))) {
        const v = dp[m] + A.D[i][k + j] * (prefer ? BIG : 1) - (prefer && prefer[i] === j ? 1 : 0);
        if (v < dp[m | (1 << j)]) { dp[m | (1 << j)] = v; via[m | (1 << j)] = j; }
      }
    }
    const asg = new Array(k); let m = M - 1;
    for (let i = k - 1; i >= 0; i--) { const j = via[m]; asg[i] = j; m &= ~(1 << j); }
    const out = { cost: cost(A, asg), asg };
    if (key !== null) solveCache.set(key, out);
    return out;
  }

  /** The least towing for the whole fleet GIVEN boat i is moored on mooring j (the DP with that one pairing forced). */
  function bestWith(A, i, j) {
    const k = A.k, M = 1 << k, dp = new Float64Array(M).fill(Infinity); dp[0] = 0;
    for (let m = 0; m < M; m++) {
      if (dp[m] === Infinity) continue; let b = 0; for (let t = m; t; t &= t - 1) b++; if (b >= k) continue;
      for (let q = 0; q < k; q++) if (!(m & (1 << q))) { if (b === i && q !== j) continue; const v = dp[m] + A.D[b][k + q]; if (v < dp[m | (1 << q)]) dp[m | (1 << q)] = v; }
    }
    return dp[M - 1];
  }
  /** THE CLUE after a loss (REVIEW 2026-09-28, defects 3 and 4). `asg` = the player's plan.
   *  - `moves`: the FEWEST boats any least plan moves off the player's moorings (solve with the tie-break toward the
   *    player's plan). This is only a COUNT.
   *  - `mustMove`: the boats that EVERY least plan moves — boat i is in it iff no least plan keeps her on the player's
   *    mooring (bestWith > par). So "she wants another mooring" is true of every best answer, never of just one.
   *  - `ringed`: ONE boat to ring — from `mustMove` (the one with the longest tow in the player's plan); only if that
   *    set is empty (two different least plans disagree about every boat) one the nearest least plan moves, flagged. */
  function clue(A, asg) {
    const par = solve(A).cost, near = solve(A, asg);
    let moves = 0; for (let i = 0; i < A.k; i++) if (near.asg[i] !== asg[i]) moves++;
    const mustMove = []; for (let i = 0; i < A.k; i++) if (bestWith(A, i, asg[i]) > par) mustMove.push(i);
    const pool = mustMove.length ? mustMove : near.asg.map((j, i) => (j !== asg[i] ? i : -1)).filter((i) => i >= 0);
    let ringed = -1; for (const i of pool) if (ringed < 0 || A.D[i][A.k + asg[i]] > A.D[ringed][A.k + asg[ringed]]) ringed = i;
    return { moves, mustMove, ringed, everyBestPlan: mustMove.length > 0 };
  }

  /** The tow route from boat i's waiting cell to `cell`: walked back down the boat's own distance field. */
  function route(A, i, cell) {
    const d = A.field[i]; if (d[cell] < 0) return [];
    const out = [cell]; let u = cell, guard = 0;
    while (d[u] > 0 && guard++ < N) {
      let nx = -1; for (const v of nbrs(u)) if (d[v] === d[u] - 1) { nx = v; break; }
      if (nx < 0) break; u = nx; out.push(u);
    }
    return out.reverse();
  }

  /** Where the pilot launch lies at the start: the reachable water cell nearest the middle of the quay (no boat, no
   *  mooring on it). */
  function startCell(A) {
    let best = -1, bd = Infinity;
    for (let c = 0; c < N; c++) { if (!A.reach[c] || A.boatAt[c] >= 0 || A.berthAt[c] >= 0) continue; const x = c % W, y = (c / W) | 0, dd = (x - 9.5) ** 2 + 3 * (y - 13) ** 2; if (dd < bd) { bd = dd; best = c; } }
    return best;
  }

  return { W, H, N, WATER, QUAY, ISLAND, rng, generate, cost, tow, towTo, solve, bestWith, clue, route, startCell, nbrs };
}));
