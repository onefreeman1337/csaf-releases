/**
 * sound.js — PILOTAGE's audio (forked from MILLWRIGHT's, itself from ROOTWORK's and NIGHT PLOUGH's; the same two laws below).
 *
 * ⛔⛔ TWO WING LAWS SET THE WHOLE SHAPE OF THIS FILE, AND BOTH WERE PAID FOR BY SHIPPED DEFECTS:
 *
 *  §2a — "USE AN <audio> ELEMENT" IS NECESSARY AND NOT SUFFICIENT. The paid desktop build loads
 *        from file://, where fetch and XHR are both blocked outright. Music therefore plays from
 *        a BARE <audio> element with its own `volume`, OUT of the WebAudio graph. ⛔ NEVER set
 *        crossOrigin and NEVER feed the element to createMediaElementSource — on file:// both
 *        give silence in the paid download, which is the worst possible place for it.
 *
 *  §8a-4 — A CUE GATED ON THE MUSIC'S READINESS IS SWALLOWED. Every SFX cue is gated on its own
 *        requirement and nothing else: an AudioContext in state 'running'. The SFX are synthesised
 *        from oscillators at cue time, so there is no buffer to wait for at all.
 *
 * ⚠ Procedural synthesis is NOT generative AI (wing §0-ART): no Sounds tag on the listing. The
 *   music loop is rendered by Kernel/capture/make_audio.js from a note spec we wrote — our own
 *   IP, no licence, no model.
 */
(function (root) {
  'use strict';

  var ctx = null, muted = false, music = null, wantMusic = false;

  function ac() {
    if (ctx) return ctx;
    var AC = root.AudioContext || root.webkitAudioContext;
    if (!AC) return null;
    try { ctx = new AC(); } catch (e) { ctx = null; }
    return ctx;
  }

  /** ⛔ No autoplay. The first real input starts the context; called from every input path. */
  function unlock() {
    var c = ac();
    if (c && c.state === 'suspended') c.resume();
    if (music && wantMusic && music.paused && !muted) {
      var p = music.play();
      if (p && p.catch) p.catch(function () { /* autoplay refused: the next press tries again */ });
    }
  }

  function voice(o) {
    var c = ac();
    if (!c || c.state !== 'running' || muted) return false;   // ⛔ its OWN requirement, nothing else
    var t = c.currentTime + (o.delay || 0);
    var g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, o.gain), t + (o.attack || 0.005));
    g.gain.exponentialRampToValueAtTime(0.0001, t + o.dur);
    g.connect(c.destination);
    var src;
    if (o.noise) {
      var n = Math.max(1, Math.floor(c.sampleRate * o.dur));
      var buf = c.createBuffer(1, n, c.sampleRate);
      var d = buf.getChannelData(0), last = 0;
      for (var i = 0; i < n; i++) { var w = Math.random() * 2 - 1; last = last * 0.86 + w * 0.14; d[i] = o.bright ? w : last * 3; }
      src = c.createBufferSource(); src.buffer = buf;
      if (o.filter) { var f = c.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = o.filter; f.Q.value = 1.4; src.connect(f); f.connect(g); }
      else src.connect(g);
    } else {
      src = c.createOscillator();
      src.type = o.type || 'square';
      src.frequency.setValueAtTime(o.f0, t);
      if (o.f1 && o.f1 !== o.f0) src.frequency.exponentialRampToValueAtTime(Math.max(1, o.f1), t + o.dur);
      src.connect(g);
    }
    src.start(t);
    src.stop(t + o.dur + 0.02);
    return true;
  }

  var CUES = {
    ok:         function () { voice({ type: 'triangle', f0: 330, f1: 660, dur: 0.12, gain: 0.08 }); },
    page:       function () { voice({ type: 'square', f0: 420, f1: 520, dur: 0.045, gain: 0.05 }); },
    start:      function () { voice({ type: 'sawtooth', f0: 147, f1: 147, dur: 0.35, gain: 0.05 }); voice({ type: 'sawtooth', f0: 220, f1: 220, dur: 0.35, gain: 0.03 }); },  // the launch's horn
    step:       function () { voice({ type: 'square', f0: 70, f1: 60, dur: 0.035, gain: 0.03 }); voice({ noise: true, filter: 260, dur: 0.03, gain: 0.02 }); },  // the engine's putter
    bump:       function () { voice({ type: 'sine', f0: 90, f1: 50, dur: 0.12, gain: 0.1 }); voice({ noise: true, filter: 400, dur: 0.08, gain: 0.04 }); },     // hull on rock / quay / locked
    tow:        function () {                                                                                    // a line thrown and made fast: a rope creak and a tap
      voice({ type: 'sawtooth', f0: 200, f1: 150, dur: 0.18, gain: 0.03 });
      voice({ type: 'triangle', f0: 660, f1: 660, dur: 0.08, gain: 0.06, delay: 0.16 });
    },
    cast:       function () { voice({ type: 'sawtooth', f0: 150, f1: 220, dur: 0.15, gain: 0.025 }); },       // the line let go
    moor:       function () {                                                                                    // the ship's bell, struck twice, and the chain
      [0, 0.28].forEach(function (d) { voice({ type: 'sine', f0: 880, f1: 874, dur: 0.9, gain: 0.07, delay: d }); voice({ type: 'sine', f0: 2210, f1: 2200, dur: 0.4, gain: 0.02, delay: d }); });
      for (var i = 0; i < 4; i++) voice({ noise: true, bright: true, filter: 1800, dur: 0.05, gain: 0.03, delay: 0.1 + i * 0.07 });
    },
    home:       function () { voice({ type: 'sawtooth', f0: 110, f1: 104, dur: 1.4, gain: 0.05, attack: 0.15 }); voice({ type: 'sawtooth', f0: 165, f1: 156, dur: 1.4, gain: 0.03, attack: 0.15 }); },  // the harbour's foghorn: the fleet is in
    done:       function () {
      [392, 494, 587, 784].forEach(function (f, i) { voice({ type: 'triangle', f0: f, f1: f, dur: 0.22, gain: 0.08, delay: i * 0.11 }); });
      voice({ type: 'sine', f0: 1175, f1: 1568, dur: 0.5, gain: 0.04, delay: 0.44 });
    },
    late:       function () { voice({ type: 'triangle', f0: 330, f1: 147, dur: 0.7, gain: 0.08 }); voice({ noise: true, filter: 250, dur: 0.5, gain: 0.03 }); },
  };

  /** ⛔ Counted, never silent: an unknown cue id is a defect, not a no-op. */
  var unknown = {};
  function cue(id) {
    var f = CUES[id];
    if (!f) { unknown[id] = (unknown[id] || 0) + 1; return false; }
    f();
    return true;
  }

  /** ⛔ §2a: a BARE element, its own volume, never in the WebAudio graph, no crossOrigin. */
  function attachMusic(el) {
    music = el;
    if (!music) return;
    music.loop = true;
    music.volume = muted ? 0 : 0.42;
    wantMusic = true;
  }

  /** ⛔ Mute drives el.volume EXPLICITLY, in the same edit that sets the flag. */
  function setMuted(m) {
    muted = !!m;
    if (music) {
      music.volume = muted ? 0 : 0.42;
      if (muted) music.pause();
      else if (wantMusic) { var p = music.play(); if (p && p.catch) p.catch(function () {}); }
    }
    try { root.localStorage.setItem('PILOTAGE_MUTE', muted ? '1' : '0'); } catch (e) { /* private mode */ }
  }

  function restoreMuted() {
    try { return root.localStorage.getItem('PILOTAGE_MUTE') === '1'; } catch (e) { return false; }
  }

  root.PSOUND = {
    cue: cue, unlock: unlock, setMuted: setMuted, restoreMuted: restoreMuted,
    attachMusic: attachMusic, unknown: unknown,
    state: function () { return { ctx: ctx ? ctx.state : 'none', muted: muted, music: !!music }; },
    CUES: CUES,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.PSOUND;
}(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this)));
